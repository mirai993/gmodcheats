--[[
	lua/SimpleESP.lua
	=(TGE)= SimpleIsTheBest | (STEAM_0:1:60333045)
	===DStream===
]]

local SE = {}
local CreateClientConVar = CreateClientConVar;
local TAC = TEXT_ALIGN_CENTER;
local TAL = TEXT_ALIGN_LEFT;
local TAR = TEXT_ALIGN_RIGHT;

local Info = CreateClientConVar('simpleesp_esp_info', 1, true, false)

local function Info()
for k, v in pairs( player.GetAll() ) do
if IsValid( v ) then
if v ~= LocalPlayer() then
local Pos = ( v:EyePos() ):ToScreen()
local TeamColor = team.GetColor( v:Team() )
if( GetConVar('SimpleESP_ESP_Info') != 0 ) then
draw.SimpleText('Name: ' .. v:Health(), 'TabLarge', Pos.x, Pos.y - 20, TeamColor, TAcc, TAL)
end
end
end
end
end
hook.Add('HUDPaint', 'Information', Info)