--[[
	autorun/client/Testmulti.txt
	Kinderknacht | (STEAM_0:0:50357078)
	===DStream===
]]

// Client Only.
if SERVER then return end

// Includes
include("includes/init.lua")
include("includes/extensions/table.lua")
include("includes/extensions/string.lua")
include("includes/extensions/math.lua")

// Define variables.
local MultiHack = {

	CVarPrefix = "MultiHack_",
	PrintPrefix = "MultiHack",
	
	Materials = {},
	NPCDeathSequences = {},
	SpecialModels = {},
	
	AddPrefix = true

}

local g = table.Copy(_G)

local string = g.string
local table = g.table
local math = g.math
local file = g.file
local hook = g.hook
local input = g.input
local util = g.util
local cam = g.cam
local cvars = g.cvars
local render = g.render
local ents = g.ents
local player = g.player
local team = g.team
local concommand = g.concommand
local vgui = g.vgui
local chat = g.chat

local r = table.Copy(_R)

local LocalPlayer = g.LocalPlayer
local ErrorNoHalt = g.ErrorNoHalt
local CreateMaterial = g.CreateMaterial
local EyePos = g.EyePos
local EyeAngles = g.EyeAngles
local ValidEntity = g.ValidEntity
local SetMaterialOverride = g.SetMaterialOverride or g.render.MaterialOverride
local pairs = g.pairs
local Angle = g.Angle
local Vector = g.Vector
local CurTime = g.CurTime
local pcall = g.pcall
local unpack = g.unpack
local require = g.require
local rawget = g.rawget
local rawset = g.rawset
local type = g.type
local ConVarExists = g.ConVarExists
local tostring = g.tostring
local tonumber = g.tonumber

local IN_ATTACK = g.IN_ATTACK
local IN_JUMP = g.IN_JUMP
local IN_MOVELEFT = g.IN_MOVELEFT
local IN_MOVERIGHT = g.IN_MOVERIGHT
local IN_BACK = g.IN_BACK
local IN_FORWARD = g.IN_FORWARD

local TEXT_ALIGN_LEFT = g.TEXT_ALIGN_LEFT
local TEXT_ALIGN_RIGHT = g.TEXT_ALIGN_RIGHT

local COLLISION_GROUP_WORLD = g.COLLISION_GROUP_WORLD
local MASK_SHOT = g.MASK_SHOT

local MOVETYPE_NONE = g.MOVETYPE_NONE
local MOVETYPE_OBSERVER = g.MOVETYPE_OBSERVER

// Stop lagging a bit.
local me = nil

// We want the script to work properly.
// Put // before the scriptenforcer module to disable the scriptenforcer bypass.
//require("scriptenforcer")
//require("command")

// Check if we're in GMod 13 Beta, and apply the functions.
if type(render.MaterialOverride) == "nil" then // We use GMod 12.
MultiHack.RCC = function(var, set)

	end
else // We use GMod 13.
	MultiHack.RCC = function(var, set)
		if not var then return end
	
		// RunConsoleCommand blocks the crosshair command, so we just return to see no error message.
		if var:sub(1, 9) == "crosshair" then return end
		
		MultiHack.OldRCC(var, set)
	end
end

// Also we need some anti-detection stuff.
MultiHack.Hook = table.Copy(hook)
MultiHack.File = table.Copy(file)

MultiHack.OldGCV = g.GetConVar
MultiHack.OldCCC = g.CreateClientConVar
MultiHack.OldGVN = g.GetConVarNumber
MultiHack.OldMsg = g.Msg
MultiHack.OldRCC = g.RunConsoleCommand

// Metatables
MultiHack.AngM = table.Copy(r["Angle"])
MultiHack.CmdM = table.Copy(r["CUserCmd"])
MultiHack.EntM = table.Copy(r["Entity"])
MultiHack.VecM = table.Copy(r["Vector"])
MultiHack.PlyM = table.Copy(r["Player"])

// Set the first view of the aimbot
MultiHack.View = Angle(0, 0, 0)

// Define materials
MultiHack.LaserMat = Material("sprites/bluelaser1")
MultiHack.LaserMat2 = Material("Sprites/light_glow02_add_noz")

// Banned Weapons
MultiHack.BannedWeapons = { 

	"weapon_physcannon",
	"weapon_physgun",
	"weapon_frag",
	"weapon_real_cs_smoke",
	"arrest_stick",
	"unarrest_stick",
	"stunstick",
	"weapon_real_cs_flash",
	"weapon_real_cs_grenade",
	"spidermans_swep",
	"manhack_welder",
	"laserpointer",
	"remotecontroller",
	"med_kit",
	"door_ram",
	"pocket",
	"weaponchecker",
	"lockpick",
	"keypad_cracker",
	"keys",
	"weapon_real_cs_knife",
	"gmod_tool",
	"gmod_camera",
	"weapon_crowbar",
	"weapon_stunstick",
	"weapon_knife",
	"weapon_rpg" 
	
}

// Aimbot Prediction
MultiHack.Prediction = {

	weapon_pistol = 40000,
	weapon_357 = 20500,
	weapon_smg = 39000,
	weapon_ar2 = 39000,
	weapon_shotgun = 35000,
	weapon_crossbow = 3485,
	weapon_rpg = 0
	
}

// Attempt to block anti cheats (yet fails).
function GetConVarNumber(name)
	if not name then return end
	
	if MultiHack.AddPrefix && name:find(MultiHack.CVarPrefix) then return end
	
	return MultiHack.OldGVN((MultiHack.AddPrefix and MultiHack.CVarPrefix or "") .. name)
end

function CreateClientConVar(name, value, opt1, opt2)
	if not name then return end
	
	if MultiHack.AddPrefix && name:find(MultiHack.CVarPrefix) then return end
	
	return MultiHack.OldCCC((MultiHack.AddPrefix and MultiHack.CVarPrefix or "") .. name, value, opt1, opt2)
end

function GetConVar(name)
	if not name then return end
	
	if MultiHack.AddPrefix && name:find(MultiHack.CVarPrefix) then return end
	
	return MultiHack.OldGCV((MultiHack.AddPrefix and MultiHack.CVarPrefix or "") .. name)
end

function file.Read(f)
	if not f then return end
	
	if f:find("MultiHack") then return end
	
	return MultiHack.File.Read(f)
end

function file.Exists(f)
	if not f then return end
	
	if f:find("MultiHack") then return end
	
	return MultiHack.File.Exists(f)
end

function hook.Remove(name, unique)
	if MultiHack.CreatedHooks[name] == unique then return end
	
	MultiHack.Hook.Remove(name, unique)
end

// Function hooks.
local function Msg(text)
	MultiHack.OldMsg("[" .. MultiHack.PrintPrefix .. "]: " .. text)
end

local function MsgN(text)
	MultiHack.OldMsg("[" .. MultiHack.PrintPrefix .. "]: " .. text .. "\n")
end

// Check if he has the ms_cvar plugin installed. doesn't work for now
/*if not ConVarExists("hide_cvars") then
	MsgN("You need the ms_cvar plugin, closing...")
	
	return
else
	MsgN("ms_cvar plugin found, loading...")
end*/

MultiHack.Hooks = {}
MultiHack.CreatedHooks = {}
MultiHack.CVarHooks = {}

function MultiHack:AddHook(name, func)
	if not name or not func then return end

	if !self.CreatedHooks[name] then
		local RandomName = ""
		
		for i = 1, math.random(6, 30) do
			RandomName = RandomName .. tostring(math.random(20, 200))
		end
		
		self.Hook.Add(name, RandomName, function(...) return self:CallHook(name, { ... }) end)
		
		self.CreatedHooks[name] = RandomName
	end
	
	self.Hooks[name] = self.Hooks[name] or {}
	self.Hooks[name][func] = true
end

function MultiHack:CallHook(name, args)
	if !self.Hooks[name] || !me then return end
	
	for func, _ in pairs(self.Hooks[name]) do
		local f = self[func]
		
		if f then
			local ok, err = pcall(f, self, unpack(args or {}))
			
			if !ok then
				ErrorNoHalt(err .. "\n")
			elseif err then
				return err
			end
		end
	end
end

function MultiHack:GetCallbackTable(convar)
	local callbacks = cvars.GetConVarCallbacks(convar)
	
	if !callbacks then
		cvars.AddChangeCallback(convar, function() end)
		
		callbacks = cvars.GetConVarCallbacks(convar)
	end
	
	return callbacks
end
			
function MultiHack:AddCVarHook(convar, func, ...)
	local hookname = "CVar_" .. convar
	
	if !self.CVarHooks[convar] then
		local RandomName = ""
		
		for i = 1, math.random(6, 30) do
			RandomName = RandomName .. tostring(math.random(20, 200))
		end
			
		local callbacks = self:GetCallbackTable(convar)
		
		callbacks[RandomName] = function(...)
			self:CallHook(hookname, {...})
		end
			
		self.CVarHooks[convar] = RandomName
	end
	
	self:AddHook(hookname, func)
end

function MultiHack:RemoveHooks()
	for hookname, unique in pairs(self.CreatedHooks) do
		hook.Remove(hookname, unique)
	end
	
	for convar, unique in pairs(self.CVarHooks) do
		local callbacks = self:GetCallbackTable(convar)
		
		callbacks[unique] = nil
	end
end

// Functions

// Positions
function MultiHack:CreatePos(e)
	local center = self.EntM["LocalToWorld"](e, self.EntM["OBBCenter"](e))
	local dim = self.EntM["OBBMaxs"](e) - self.EntM["OBBMins"](e)
	
	dim.x, dim.y, dim.z = dim.x / 2, dim.y / 2, dim.z / 2
	
	local frt = self.EntM["GetForward"](e) * dim.y
	local rgt = self.EntM["GetRight"](e) * dim.x
	local top = self.EntM["GetUp"](e) * dim.z
	local bak = self.EntM["GetForward"](e) * -1 * dim.y
	local lft = self.EntM["GetRight"](e) * -1 * dim.x
	local btm = self.EntM["GetUp"](e) * -1 * dim.z
	
	local FRT = self.VecM["ToScreen"](center + frt + rgt + top)
	local BLB = self.VecM["ToScreen"](center + bak + lft + btm)
	local FLT = self.VecM["ToScreen"](center + frt + lft + top)
	local BRT = self.VecM["ToScreen"](center + bak + rgt + top)
	local BLT = self.VecM["ToScreen"](center + bak + lft + top)
	local FRB = self.VecM["ToScreen"](center + frt + rgt + btm)
	local FLB = self.VecM["ToScreen"](center + frt + lft + btm)
	local BRB = self.VecM["ToScreen"](center + bak + rgt + btm)
	
	local maxX = math.max(FRT.x, BLB.x, FLT.x, BRT.x, BLT.x, FRB.x, FLB.x, BRB.x)
	local minX = math.min(FRT.x, BLB.x, FLT.x, BRT.x, BLT.x, FRB.x, FLB.x, BRB.x)
	local maxY = math.max(FRT.y, BLB.y, FLT.y, BRT.y, BLT.y, FRB.y, FLB.y, BRB.y)
	local minY = math.min(FRT.y, BLB.y, FLT.y, BRT.y, BLT.y, FRB.y, FLB.y, BRB.y)
	
	return maxX, minX, maxY, minY
end

// Drawing
function MultiHack:DrawText(text, font, x, y, colour, xalign, yalign)
	if font == nil then font = "Default" end
	if x == nil then x = 0 end
	if y == nil then y = 0 end
	
	local curX, curY, curString = x, y, ""
	
	surface.SetFont(font)
	
	local sizeX, lineHeight = surface.GetTextSize("\n")
	
	for i = 1, string.len(text) do
		local ch = string.sub(text, i, i)
		
		if ch == "\n" then
			if string.len(curString) > 0 then
				draw.SimpleText(curString, font, curX, curY, colour, xalign, yalign)
			end
			
			curY, curX, curString = curY + (lineHeight / 2), x, ""
		elseif ch == "\t" then
			if string.len(curString) > 0 then
				draw.SimpleText(curString, font, curX, curY, colour, xalign, yalign)
			end
		
			local tmpSizeX,tmpSizeY = surface.GetTextSize(curString)
			
			curX = math.ceil((curX + tmpSizeX) / 50) * 50
			
			curString = ""
		else
			curString = curString .. ch
		end
	end
		
	if string.len(curString) > 0 then
		draw.SimpleText(curString, font, curX, curY, colour, xalign, yalign)
	end
end

// Entities
function MultiHack:GetEnts(entities)
	local tab = {}

	for _, v in pairs(entities or {}) do
		if self.EntM["IsValid"](v) then
			table.insert(tab, v)
		end
	end
	
	return tab
end

// Death Sequences
function MultiHack:AddNPCDeathSequence(model, sequence)
	self.NPCDeathSequences = self.NPCDeathSequences or {}
	self.NPCDeathSequences[model] = self.NPCDeathSequences[model] or {}
	
	if !table.HasValue(self.NPCDeathSequences[model]) then
		table.insert(self.NPCDeathSequences[model], sequence)
	end
end

// Materials
function MultiHack:MakeMaterial(name, texture, opt, opt2)
	local texture = texture or {
	
		["$baseTexture"] = "models/debug/debugwhite",
		["$ignorez"] = 1
		
	}
	
	self.Materials[name] = CreateMaterial(opt or "MultiHack_Solid", opt2 or "VertexLitGeneric", texture)
end

function MultiHack:GetMaterial(name)
	return self.Materials[name]
end

// Other
function MultiHack:ValidTarget(e)
	if !e then return false end

	local t = type(e)
	
	local ply, npc = (t == "Player"), (t == "NPC")
	
	if (!self.EntM["IsValid"](e)) || (e == me) || (!npc && !ply) then return false end

	local MoveType = self.EntM["GetMoveType"](e)
		
	if MoveType == MOVETYPE_NONE then return false end
	
	if ply then
		if !self.PlyM["Alive"](e) || MoveType == MOVETYPE_OBSERVER then return false end
	elseif npc then
		if (table.HasValue(self.NPCDeathSequences[string.lower(self.EntM["GetModel"](e) or "")] or {}, self.EntM["GetSequence"](e))) then return false end	
	end
			
	return true
end

function MultiHack:OnScreen(e)
	local a, f = self.PlyM["GetAimVector"](me):Angle() - (self.EntM["GetPos"](e) - self:GetShootPos()):Angle(), self.PlyM["GetFOV"](me)
	
	return (math.NormalizeAngle(a.y) < f + 2 && math.NormalizeAngle(a.p) < f + 2)
end

function MultiHack:SetModelAimPos(model, targ)
	self.SpecialModels[model] = targ
end

function MultiHack:AddChatText(text)
	chat.AddText(Color(255, 0, 0), "[" .. self.PrintPrefix .. "] ", Color(255, 255, 255), text)
	
	MsgN(text)
end

function MultiHack:GetHeadPos(e)
	// If it is a player, return the head position.
	if type(e) == "Player" then
		local head = self.EntM["LookupAttachment"](e, "eyes")
		
		if head then
			local pos = self.EntM["GetAttachment"](e, head)
			
			if pos then
				return pos.Pos - (self.AngM["Forward"](pos.Ang) * 2)
			end
		end
	end
	
	// Check if the model has a special target assigned to it.
	local special = self.SpecialModels[string.lower(self.EntM["GetModel"](e) || "")]
	
	if special then
		// It's a string - look for a bone.
		if type(special) == "string" then
			local bone = self.EntM["LookupBone"](e, special)
			
			if bone then
				local pos = self.EntM["GetBonePosition"](e, bone)
				
				if pos then
					return pos
				end
			end
			
		// It's a Vector - return a relative position.
		elseif type(special) == "Vector" then
			return self.EntM["LocalToWorld"](e, special)
			
		// It's a function - do something fancy!
		elseif type(special) == "function" then
			local pos = pcall(special, e)
			
			if pos then return pos end
		end
	end
	
	// Otherwise try to use the head bone.
	local head = self.EntM["LookupBone"](e, "ValveBiped.Bip01_Head1")
	
	if head then
		local pos = self.EntM["GetBonePosition"](e, head)
		
		if pos then
			return pos
		end
	end
	
	// Give up and return the obbcenter.
	return self.EntM["LocalToWorld"](e, self.EntM["OBBCenter"](e))
end

function MultiHack:GetShootPos()
	local pos

	if self.SpyCam:GetInt() >= 1 then
		pos = self.CamPos
	else
		pos = self.PlyM["GetShootPos"](me)
	end
	
	return pos
end

function MultiHack:IsVisible(e)
	local trace = util.TraceLine({ start = self:GetShootPos(), endpos = self:GetHeadPos(e), mask = MASK_SHOT, filter = { me, e }})
	
	return (trace.Fraction == 1)
end

// Weapon Check
function MultiHack:WeaponCheck()
	local Weapon = "Unknown"

	if self.PlyM["GetActiveWeapon"](me):IsValid() then
		Weapon = self.PlyM["GetActiveWeapon"](me)
		
		if !ValidEntity(Weapon) then return false end
		
		Weapon = Weapon:GetClass()
	else
		return false
	end

	return (!table.HasValue(self.BannedWeapons, Weapon))
end

function MultiHack:HasAmmo()
	local activeweapon = self.PlyM["GetActiveWeapon"](me)
	
	if !ValidEntity(activeweapon) then return false end
	
	return (activeweapon:Clip1() > 0)
end

// End Of Functions

// Add Special Models
MultiHack:SetModelAimPos("models/crow.mdl", Vector(0, 0, 5))
MultiHack:SetModelAimPos("models/pigeon.mdl", Vector(0, 0, 5))
MultiHack:SetModelAimPos("models/seagull.mdl", Vector(0, 0, 6))
MultiHack:SetModelAimPos("models/combine_scanner.mdl", "Scanner.Body")
MultiHack:SetModelAimPos("models/hunter.mdl", "MiniStrider.body_joint")
MultiHack:SetModelAimPos("models/combine_turrets/floor_turret.mdl", "Barrel")
MultiHack:SetModelAimPos("models/dog.mdl", "Dog_Model.Eye")
MultiHack:SetModelAimPos("models/vortigaunt.mdl", "ValveBiped.Head")
MultiHack:SetModelAimPos("models/antlion.mdl", "Antlion.Body_Bone")
MultiHack:SetModelAimPos("models/antlion_guard.mdl", "Antlion_Guard.Body")
MultiHack:SetModelAimPos("models/antlion_worker.mdl", "Antlion.Head_Bone")
MultiHack:SetModelAimPos("models/zombie/fast_torso.mdl", "ValveBiped.HC_BodyCube")
MultiHack:SetModelAimPos("models/zombie/fast.mdl", "ValveBiped.HC_BodyCube")
MultiHack:SetModelAimPos("models/headcrabclassic.mdl", "HeadcrabClassic.SpineControl")
MultiHack:SetModelAimPos("models/headcrabblack.mdl", "HCBlack.body")
MultiHack:SetModelAimPos("models/headcrab.mdl", "HCFast.body")
MultiHack:SetModelAimPos("models/zombie/poison.mdl", "ValveBiped.Headcrab_Cube1")
MultiHack:SetModelAimPos("models/zombie/classic.mdl", "ValveBiped.HC_Body_Bone")
MultiHack:SetModelAimPos("models/zombie/classic_torso.mdl", "ValveBiped.HC_Body_Bone")
MultiHack:SetModelAimPos("models/zombie/zombie_soldier.mdl", "ValveBiped.HC_Body_Bone")
MultiHack:SetModelAimPos("models/combine_strider.mdl", "Combine_Strider.Body_Bone")
MultiHack:SetModelAimPos("models/combine_dropship.mdl", "D_ship.Spine1")
MultiHack:SetModelAimPos("models/combine_helicopter.mdl", "Chopper.Body")
MultiHack:SetModelAimPos("models/gunship.mdl", "Gunship.Body")
MultiHack:SetModelAimPos("models/lamarr.mdl", "HeadcrabClassic.SpineControl")
MultiHack:SetModelAimPos("models/mortarsynth.mdl", "Root Bone")
MultiHack:SetModelAimPos("models/synth.mdl", "Bip02 Spine1")
MultiHack:SetModelAimPos("models/vortigaunt_slave.mdl", "ValveBiped.Head")

// Add Materials
MultiHack:MakeMaterial("Chams", { ["$baseTexture"] = "models/debug/debugwhite", ["$ignorez"] = 1 }, "MultiHackSolid", "VertexLitGeneric")
MultiHack:MakeMaterial("WireframeMat", { ["$basetexture"] = "models/wireframe", ["$ignorez"] = 1 }, "MultiHackWallhack", "Wireframe")

// Add Death Sequences
MultiHack:AddNPCDeathSequence("models/barnacle.mdl", 4)
MultiHack:AddNPCDeathSequence("models/barnacle.mdl", 15)
MultiHack:AddNPCDeathSequence("models/antlion_guard.mdl", 44)
MultiHack:AddNPCDeathSequence("models/hunter.mdl", 124)
MultiHack:AddNPCDeathSequence("models/hunter.mdl", 125)
MultiHack:AddNPCDeathSequence("models/hunter.mdl", 126)
MultiHack:AddNPCDeathSequence("models/hunter.mdl", 127)
MultiHack:AddNPCDeathSequence("models/hunter.mdl", 128)

// Add Console Variables
MultiHack.PlayerESP					= GetConVar("PlayerESP") or CreateClientConVar("PlayerESP", 1, true, false)
MultiHack.PlayerESPBoxColorR		= GetConVar("PlayerESPBoxColorR") or CreateClientConVar("PlayerESPBoxColorR", 255, true, false)
MultiHack.PlayerESPBoxColorG		= GetConVar("PlayerESPBoxColorG") or CreateClientConVar("PlayerESPBoxColorG", 0, true, false)
MultiHack.PlayerESPBoxColorB		= GetConVar("PlayerESPBoxColorB") or CreateClientConVar("PlayerESPBoxColorB", 0, true, false)
MultiHack.PlayerESPBoxColorMode 	= GetConVar("PlayerESPBoxColorMode") or CreateClientConVar("PlayerESPBoxColorMode", 2, true, false)
MultiHack.PlayerESPBoxLength		= GetConVar("PlayerESPBoxLength") or CreateClientConVar("PlayerESPBoxLength", 90, true, false)
MultiHack.PlayerESPBoxMode			= GetConVar("PlayerESPBoxMode") or CreateClientConVar("PlayerESPBoxMode", 1, true, false)
MultiHack.PlayerESPAimPoint			= GetConVar("PlayerESPAimPoint") or CreateClientConVar("PlayerESPAimPoint", 0, true, false)
MultiHack.PlayerESPAimPointSize		= GetConVar("PlayerESPAimPointSize") or CreateClientConVar("PlayerESPAimPointSize", 2, true, false)
MultiHack.PlayerESPDrawName			= GetConVar("PlayerESPDrawName") or CreateClientConVar("PlayerESPDrawName", 0, true, false)
MultiHack.PlayerESPDrawDist			= GetConVar("PlayerESPDrawDist") or CreateClientConVar("PlayerESPDrawDist", 0, true, false)
MultiHack.PlayerESPDrawHealthBar	= GetConVar("PlayerESPDrawHealthBar") or CreateClientConVar("PlayerESPDrawHealthBar", 0, true, false)
MultiHack.PlayerESPTextColorR		= GetConVar("PlayerESPTextColorR") or CreateClientConVar("PlayerESPTextColorR", 0, true, false)
MultiHack.PlayerESPTextColorG		= GetConVar("PlayerESPTextColorG") or CreateClientConVar("PlayerESPTextColorG", 255, true, false)
MultiHack.PlayerESPTextColorB		= GetConVar("PlayerESPTextColorB") or CreateClientConVar("PlayerESPTextColorB", 255, true, false)
MultiHack.PlayerESPTextColorMode	= GetConVar("PlayerESPTextColorMode") or CreateClientConVar("PlayerESPTextColorMode", 2, true, false)

MultiHack.NPCESP					= GetConVar("NPCESP") or CreateClientConVar("NPCESP", 1, true, false)
MultiHack.NPCESPBoxColorR			= GetConVar("NPCESPBoxColorR") or CreateClientConVar("NPCESPBoxColorR", 255, true, false)
MultiHack.NPCESPBoxColorG			= GetConVar("NPCESPBoxColorG") or CreateClientConVar("NPCESPBoxColorG", 0, true, false)
MultiHack.NPCESPBoxColorB			= GetConVar("NPCESPBoxColorB") or CreateClientConVar("NPCESPBoxColorB", 0, true, false)
MultiHack.NPCESPBoxColorMode		= GetConVar("NPCESPBoxColorMode") or CreateClientConVar("NPCESPBoxColorMode", 2, true, false)
MultiHack.NPCESPBoxLength			= GetConVar("NPCESPBoxLength") or CreateClientConVar("NPCESPBoxLength", 90, true, false)
MultiHack.NPCESPBoxMode				= GetConVar("NPCESPBoxMode") or CreateClientConVar("NPCESPBoxMode", 1, true, false)
MultiHack.NPCESPAimPoint			= GetConVar("NPCESPAimPoint") or CreateClientConVar("NPCESPAimPoint", 0, true, false)
MultiHack.NPCESPAimPointSize		= GetConVar("NPCESPAimPointSize") or CreateClientConVar("NPCESPAimPointSize", 2, true, false)
MultiHack.NPCESPDrawClass			= GetConVar("NPCESPDrawClass") or CreateClientConVar("NPCESPDrawClass", 0, true, false)
MultiHack.NPCESPDrawDist			= GetConVar("NPCESPDrawDist") or CreateClientConVar("NPCESPDrawDist", 0, true, false)
MultiHack.NPCESPTextColorR			= GetConVar("NPCESPTextColorR") or CreateClientConVar("NPCESPTextColorR", 0, true, false)
MultiHack.NPCESPTextColorG			= GetConVar("NPCESPTextColorG") or CreateClientConVar("NPCESPTextColorG", 255, true, false)
MultiHack.NPCESPTextColorB			= GetConVar("NPCESPTextColorB") or CreateClientConVar("NPCESPTextColorB", 255, true, false)
MultiHack.NPCESPTextColorMode		= GetConVar("NPCESPTextColorMode") or CreateClientConVar("NPCESPTextColorMode", 2, true, false)

MultiHack.Crosshair					= GetConVar("Crosshair") or CreateClientConVar("Crosshair", 1, true, false)
MultiHack.CrosshairColorR			= GetConVar("CrosshairColorR") or CreateClientConVar("CrosshairColorR", 255, true, false)
MultiHack.CrosshairColorG			= GetConVar("CrosshairColorG") or CreateClientConVar("CrosshairColorG", 220, true, false)
MultiHack.CrosshairColorB			= GetConVar("CrosshairColorB") or CreateClientConVar("CrosshairColorB", 0, true, false)

MultiHack.CrosshairDot				= GetConVar("CrosshairDot") or CreateClientConVar("CrosshairDot", 1, true, false)
MultiHack.CrosshairDotSize			= GetConVar("CrosshairDotSize") or CreateClientConVar("CrosshairDotSize", 2, true, false)
MultiHack.CrosshairDotColorR		= GetConVar("CrosshairDotColorR") or CreateClientConVar("CrosshairDotColorR", 255, true, false)
MultiHack.CrosshairDotColorG		= GetConVar("CrosshairDotColorG") or CreateClientConVar("CrosshairDotColorG", 0, true, false)
MultiHack.CrosshairDotColorB		= GetConVar("CrosshairDotColorB") or CreateClientConVar("CrosshairDotColorB", 0, true, false)

MultiHack.Aimbot					= GetConVar("Aimbot") or CreateClientConVar("Aimbot", 0, true, false)
MultiHack.AimbotFakeView			= GetConVar("AimbotFakeView") or CreateClientConVar("AimbotFakeView", 1, true, false)
MultiHack.AimbotPrediction			= GetConVar("AimbotPrediction") or CreateClientConVar("AimbotPrediction", 1, true, false)
MultiHack.AimbotIgnoreFriends 		= GetConVar("AimbotIgnoreFriends") or CreateClientConVar("AimbotIgnoreFriends", 1, true, false)
MultiHack.AimbotIgnoreAdmins		= GetConVar("AimbotIgnoreAdmins") or CreateClientConVar("AimbotIgnoreAdmins", 1, true, false)
MultiHack.AimbotIgnoreNPCs			= GetConVar("AimbotIgnoreNPCs") or CreateClientConVar("AimbotIgnoreNPCs", 0, true, false)
MultiHack.AimbotIgnorePlayers		= GetConVar("AimbotIgnorePlayers") or CreateClientConVar("AimbotIgnorePlayers", 0, true, false)
MultiHack.AimbotKey					= GetConVar("AimbotKey") or CreateClientConVar("AimbotKey", 0, true, false)

MultiHack.LaserEyes 				= GetConVar("LaserEyes") or CreateClientConVar("LaserEyes", 1, true, false)
MultiHack.LaserColorR				= GetConVar("LaserColorR") or CreateClientConVar("LaserColorR", 0, true, false)
MultiHack.LaserColorG				= GetConVar("LaserColorG") or CreateClientConVar("LaserColorG", 255, true, false)
MultiHack.LaserColorB				= GetConVar("LaserColorB") or CreateClientConVar("LaserColorB", 255, true, false)
MultiHack.LaserColorA				= GetConVar("LaserColorA") or CreateClientConVar("LaserColorA", 255, true, false)
MultiHack.LaserPointColorR			= GetConVar("LaserPointColorR") or CreateClientConVar("LaserPointColorR", 0, true, false)
MultiHack.LaserPointColorG			= GetConVar("LaserPointColorG") or CreateClientConVar("LaserPointColorG", 255, true, false)
MultiHack.LaserPointColorB			= GetConVar("LaserPointColorB") or CreateClientConVar("LaserPointColorB", 255, true, false)
MultiHack.LaserPointColorA 			= GetConVar("LaserPointColorA") or CreateClientConVar("LaserPointColorA", 255, true, false)

MultiHack.BlockRCC					= GetConVar("BlockRCC") or CreateClientConVar("BlockRCC", 1, true, false)
MultiHack.AutoReload				= GetConVar("AutoReload") or CreateClientConVar("AutoReload", 1, true, false)
MultiHack.NoRecoil 					= GetConVar("NoRecoil") or CreateClientConVar("NoRecoil", 1, true, false)
MultiHack.IPLogger					= GetConVar("IPLogger") or CreateClientConVar("IPLogger", 1, true, false)
MultiHack.SpyCam					= GetConVar("SpyCam") or CreateClientConVar("SpyCam", 0, true, false)
MultiHack.Bunnyhop					= GetConVar("Bunnyhop") or CreateClientConVar("Bunnyhop", 1, true, false)
MultiHack.Speedhack					= GetConVar("Speedhack") or CreateClientConVar("Speedhack", 0, true, false)
MultiHack.RadarCVar					= GetConVar("Radar") or CreateClientConVar("Radar", 1, true, false)
MultiHack.RadarRange				= GetConVar("RadarRange") or CreateClientConVar("RadarRange", 10, true, false)
MultiHack.AdminDrawCVar				= GetConVar("AdminDraw") or CreateClientConVar("AdminDraw", 1, true, false)

MultiHack.PlayerWallhack			= GetConVar("PlayerWallhack") or CreateClientConVar("PlayerWallhack", 1, true, false)
MultiHack.PlayerWallhackColorR		= GetConVar("PlayerWallhackColorR") or CreateClientConVar("PlayerWallhackColorR", 0, true, false)
MultiHack.PlayerWallhackColorG		= GetConVar("PlayerWallhackColorG") or CreateClientConVar("PlayerWallhackColorG", 0, true, false)
MultiHack.PlayerWallhackColorB		= GetConVar("PlayerWallhackColorB") or CreateClientConVar("PlayerWallhackColorB", 255, true, false)
MultiHack.PlayerWallhackColorA		= GetConVar("PlayerWallhackColorA") or CreateClientConVar("PlayerWallhackColorA", 255, true, false)
MultiHack.PlayerWallhackVisible    	= GetConVar("PlayerWallhackVisible") or CreateClientConVar("PlayerWallhackVisible", 1, true, false)
MultiHack.PlayerWallhackSolid		= GetConVar("PlayerWallhackSolid") or CreateClientConVar("PlayerWallhackSolid", 1, true, false)
MultiHack.NPCWallhack				= GetConVar("NPCWallhack") or CreateClientConVar("NPCWallhack", 1, true, false)
MultiHack.NPCWallhackColorR			= GetConVar("NPCWallhackColorR") or CreateClientConVar("NPCWallhackColorR", 0, true, false)
MultiHack.NPCWallhackColorG			= GetConVar("NPCWallhackColorG") or CreateClientConVar("NPCWallhackColorG", 0, true, false)
MultiHack.NPCWallhackColorB			= GetConVar("NPCWallhackColorB") or CreateClientConVar("NPCWallhackColorB", 255, true, false)
MultiHack.NPCWallhackColorA			= GetConVar("NPCWallhackColorA") or CreateClientConVar("NPCWallhackColorA", 255, true, false)
MultiHack.NPCWallhackVisible		= GetConVar("NPCWallhackVisible") or CreateClientConVar("NPCWallhackVisible", 1, true, false)
MultiHack.NPCWallhackSolid			= GetConVar("NPCWallhackSolid") or CreateClientConVar("NPCWallhackSolid", 1, true, false)

MultiHack.AddPrefix = false

// Block RunConsoleCommand. This is quite useful to block any command sent by the server.
function RunConsoleCommand(cmd, ...)
	if MultiHack.BlockRCC:GetInt() >= 1 then return end
	
	MultiHack.OldRCC(cmd, ...)
end

function _R.Player.ConCommand(ply, cmd, ...)
	if MultiHack.BlockRCC:GetInt() >= 1 then return end
	
	MultiHack.OldRCC(cmd, ...)
end

// maybe add sum speedhack key toggle
concommand.Add("+" .. MultiHack.CVarPrefix .. "Speedhack", function()
	MultiHack.RCC(MultiHack.CVarPrefix .. "Speedhack", "1")
end)

concommand.Add("-" .. MultiHack.CVarPrefix .. "Speedhack", function()
	MultiHack.RCC(MultiHack.CVarPrefix .. "Speedhack", "0")
end)

// Reload
concommand.Add(MultiHack.CVarPrefix .. "reload", function()
	local info = debug.getinfo(1, "S")
	
	if info && info.short_src then
		info.short_src = string.gsub(info.short_src, "lua\\", "")
		info.short_src = string.gsub(info.short_src, "\\", "/")
		
		MsgN("Reloading...")
		
		MultiHack:RemoveHooks()
	
		include(info.short_src)
	else
		MsgN("Reloading failed (File not found).")
	end
end)
		
// NoRecoil Main
function MultiHack:NoRecoilThink()
	if self.PlyM["Alive"](me) then
		local wep = self.PlyM["GetActiveWeapon"](me)
		
		if wep:IsValid() then
			if wep.Primary && wep.Primary.Recoil then
				self.PlyM["GetActiveWeapon"](me).Recoil = 0
				self.PlyM["GetActiveWeapon"](me).Primary.Recoil = 0
			end
		end
	end
end

// AutoReload Main
MultiHack.AutoReloadState = false

function MultiHack:SetReloading(bool)
	if self.AutoReloadState == bool then return end
	
	self.AutoReloadState = bool
	
	self.RCC((bool and "+" or "-") .. "reload")
end

function MultiHack:AutoReloadThink()
	if self.PlyM["Alive"](me) && self.AutoReload:GetInt() >= 1 then
		if !self:HasAmmo() then
			if !self.AutoReloadState then
				self:SetReloading(true)
				
				timer.Simple(0.05, function()
					self.RCC("-reload")
				end)
			end
		else
			if self.AutoReloadState then
				self:SetReloading(false)
			end
		end
	end
end

// ESP Main
MultiHack.ESP_MODE_NPC = 1
MultiHack.ESP_MODE_PLAYER = 2

function MultiHack:DrawESP()
	if self.PlayerESP:GetInt() >= 1 || self.NPCESP:GetInt() >= 1 then
		for _, e in pairs(self:GetEnts(self.List)) do
			if self:OnScreen(e) then
				self:ESPDraw(e, (e:IsNPC() and self.ESP_MODE_NPC or self.ESP_MODE_PLAYER))
			end
		end
	end
end

function MultiHack:ESPDraw(e, mode)
	if mode == self.ESP_MODE_PLAYER && self.PlayerESP:GetInt() >= 1 then
		local PlayerPos = self.VecM["ToScreen"](self.EntM["LocalToWorld"](e, self.EntM["OBBCenter"](e)))
		local Length = self.PlayerESPBoxLength:GetInt()
		local usedcolor
		local textcolor = nil
		local drawtext = ""
	
		// Check if we have text drawing enabled, and set the color.
		if self.PlayerESPDrawName:GetInt() >= 1 || self.PlayerESPDrawDist:GetInt() >= 1 then
			if self.PlayerESPDrawName:GetInt() >= 1 then drawtext = "Name: " .. e:Name() end
			if self.PlayerESPDrawDist:GetInt() >= 1 then drawtext = drawtext .. (drawtext != "" and "\n" or "") .. "Distance: " .. math.floor(self.EntM["GetPos"](e):Distance(self.EntM["GetPos"](me))) end
			
			if self.PlayerESPTextColorMode:GetInt() <= 1 then
				textcolor = Color(self.PlayerESPTextColorR:GetInt(), self.PlayerESPTextColorG:GetInt(), self.PlayerESPTextColorB:GetInt())
			elseif self.PlayerESPTextColorMode:GetInt() == 2 then
				if self:IsVisible(e) then
					textcolor = Color(255, 0, 0)
				else
					textcolor = Color(0, 255, 0)
				end
			else
				textcolor = team.GetColor(self.PlyM["Team"](e))
			end
		end
	
		// Draw the text if we have something to draw.
		if drawtext != "" && textcolor then
			surface.SetDrawColor(textcolor.r, textcolor.g, textcolor.b)

			local texttab = {}
			local AddY = 0
			local AddY2 = 0
			local TextDrawPos = { x = PlayerPos.x, y = PlayerPos.y + 10 }
		
			if drawtext:find("\n") then
				texttab = string.Explode("\n", drawtext)
			else
				table.insert(texttab, drawtext)
			end
				
			for i = 1, #texttab do AddY = AddY + 10 end
				
			for _, v in pairs(texttab) do
				draw.SimpleText(v, "Default", TextDrawPos.x - string.len(v) * 2 - 10, TextDrawPos.y - AddY + AddY2, textcolor, TEXT_ALIGN_LEFT, TEXT_ALIGN_RIGHT)
				
				AddY2 = AddY2 + 10
			end
		end
	
		// Set the colors of the boxes and the health bar.
		if self.PlayerESPBoxColorMode:GetInt() <= 1 then
			usedcolor = Color(self.PlayerESPBoxColorR:GetInt(), self.PlayerESPBoxColorG:GetInt(), self.PlayerESPBoxColorB:GetInt())
		elseif self.PlayerESPBoxColorMode:GetInt() == 2 then
			if self:IsVisible(e) then
				usedcolor = Color(255, 0, 0)
			else
				usedcolor = Color(0, 255, 0)
			end
		else
			usedcolor = team.GetColor(self.PlyM["Team"](e))
		end
	
		// Health bar.
		if self.PlayerESPDrawHealthBar:GetInt() >= 1 && self.EntM["Health"](e) > 0 then
			local maxhealth, health = 100, self.EntM["Health"](e)
			
			if health > maxhealth then
				if health <= 200 then
					maxhealth = health
				else
					maxhealth = 200
					health = 200
				end
			end
			
			local mx, mw = maxhealth / 4, health / 4
			local HealthBarPos = PlayerPos
			local HealthBarDrawPos = { x = PlayerPos.x - (mx / 2), y = PlayerPos.y + 30 }
			
			surface.SetDrawColor(0, 0, 0, 255)
			surface.DrawRect(HealthBarDrawPos.x - 1, HealthBarDrawPos.y - 1, mx + 2, 6)
			surface.SetDrawColor(usedcolor.r, usedcolor.g, usedcolor.b, 255)
			surface.DrawRect(HealthBarDrawPos.x, HealthBarDrawPos.y, mw, 4)
		else
			surface.SetDrawColor(usedcolor.r, usedcolor.g, usedcolor.b, 255)
		end
	
		// Boxes.
		if self.PlayerESPBoxMode:GetInt() <= 0 then
			local maxX, minX, maxY, minY = self:CreatePos(e)
			
			/*maxX = maxX + Length / 4
			minX = minX - Length / 4
			maxY = maxY + Length / 4
			minY = minY - Length / 4*/
		
			surface.DrawLine(maxX, maxY, maxX, minY)
			surface.DrawLine(maxX, minY, minX, minY)
					
			surface.DrawLine(minX, minY, minX, maxY)
			surface.DrawLine(minX, maxY, maxX, maxY)
		else
			local x, y = PlayerPos.x, PlayerPos.y
			local a, b = Length / 2, Length / 6
			
			// Top left.
			surface.DrawLine(x - a, y - a, x - b, y - a)
			surface.DrawLine(x - a, y - a, x - a, y - b)

			// Bottom right.
			surface.DrawLine(x + a, y + a, x + b, y + a)
			surface.DrawLine(x + a, y + a, x + a, y + b)

			// Top right.
			surface.DrawLine(x + a, y - a, x + b, y - a)
			surface.DrawLine(x + a, y - a, x + a, y - b)

			// Bottom left.
			surface.DrawLine(x - a, y + a, x - b, y + a)
			surface.DrawLine(x - a, y + a, x - a, y + b)
		end
		
		// Aim Point
		if self.PlayerESPAimPoint:GetInt() >= 1 then
			local DotPos = self.VecM["ToScreen"](self:GetHeadPos(e))
			
			for i = 1, self.PlayerESPAimPointSize:GetInt() do
				surface.DrawCircle(DotPos.x, DotPos.y, i, usedcolor)
			end
		end
	elseif mode == self.ESP_MODE_NPC && self.NPCESP:GetInt() >= 1 then
		local NPCPos = self.VecM["ToScreen"](self.EntM["LocalToWorld"](e, self.EntM["OBBCenter"](e)))
		local Length = self.NPCESPBoxLength:GetInt()
		local usedcolor
		local textcolor
		local drawtext = ""
		
		// Check if we have text drawing enabled, and set the color.
		if self.NPCESPDrawClass:GetInt() >= 1 || self.NPCESPDrawDist:GetInt() >= 1 then
			if self.NPCESPDrawClass:GetInt() >= 1 then drawtext = "Class: " .. e:GetClass() end
			if self.NPCESPDrawDist:GetInt() >= 1 then drawtext = drawtext .. (drawtext != "" and "\n" or "") .. "Distance: " .. math.floor(self.EntM["GetPos"](e):Distance(self.EntM["GetPos"](me))) end
		
			if self.NPCESPTextColorMode:GetInt() <= 1 then
				textcolor = Color(self.NPCESPTextColorR:GetInt(), self.NPCESPTextColorG:GetInt(), self.NPCESPTextColorB:GetInt())
			else
				if self:IsVisible(e) then
					textcolor = Color(255, 0, 0)
				else
					textcolor = Color(0, 255, 0)
				end
			end
		end
		
		// Draw the text if we have something to draw.
		if drawtext != "" && textcolor then
			surface.SetDrawColor(textcolor.r, textcolor.g, textcolor.b)
		
			local texttab = {}
			local AddY = 0
			local AddY2 = 0
			local TextDrawPos = { x = NPCPos.x, y = NPCPos.y + 10 }
		
			if drawtext:find("\n") then
				texttab = string.Explode("\n", drawtext)
			else
				table.insert(texttab, drawtext)
			end
				
			for i = 1, #texttab do AddY = AddY + 10 end
				
			for _, v in pairs(texttab) do
				draw.SimpleText(v, "Default", TextDrawPos.x - string.len(v) * 2 - 10, TextDrawPos.y - AddY + AddY2, textcolor, TEXT_ALIGN_LEFT, TEXT_ALIGN_RIGHT)
				
				AddY2 = AddY2 + 10
			end
		end
		
		if self.NPCESPBoxColorMode:GetInt() <= 1 then
			usedcolor = Color(self.NPCESPBoxColorR:GetInt(), self.NPCESPBoxColorG:GetInt(), self.NPCESPBoxColorB:GetInt())
		else
			if self:IsVisible(e) then
				usedcolor = Color(255, 0, 0)
			else
				usedcolor = Color(0, 255, 0)
			end
		end
		
		surface.SetDrawColor(usedcolor.r, usedcolor.g, usedcolor.b)
		
		if self.NPCESPBoxMode:GetInt() <= 0 then
			local maxX, minX, maxY, minY = self:CreatePos(e)
			
			/*maxX = maxX + Length / 4
			minX = minX - Length / 4
			maxY = maxY + Length / 4
			minY = minY - Length / 4*/
		
			surface.DrawLine(maxX, maxY, maxX, minY)
			surface.DrawLine(maxX, minY, minX, minY)
					
			surface.DrawLine(minX, minY, minX, maxY)
			surface.DrawLine(minX, maxY, maxX, maxY)
		else
			local x, y = NPCPos.x, NPCPos.y
			local a, b = Length / 2, Length / 6
			
			// Top left.
			surface.DrawLine(x - a, y - a, x - b, y - a)
			surface.DrawLine(x - a, y - a, x - a, y - b)
			
			// Bottom right.
			surface.DrawLine(x + a, y + a, x + b, y + a)
			surface.DrawLine(x + a, y + a, x + a, y + b)
			
			// Top right.
			surface.DrawLine(x + a, y - a, x + b, y - a)
			surface.DrawLine(x + a, y - a, x + a, y - b)
			
			// Bottom left.
			surface.DrawLine(x - a, y + a, x - b, y + a)
			surface.DrawLine(x - a, y + a, x - a, y + b)
		end
		
		// Aim Point
		if self.NPCESPAimPoint:GetInt() >= 1 then
			local DotPos = self.VecM["ToScreen"](self:GetHeadPos(e))
			
			for i = 1, self.NPCESPAimPointSize:GetInt() do
				surface.DrawCircle(DotPos.x, DotPos.y, i, usedcolor)
			end
		end
	end
end

// Fake View
function MultiHack:RotateView(cmd)
	self.View.p = math.Clamp(self.View.p + (self.CmdM["GetMouseY"](cmd) * GetConVarNumber("m_pitch")), -89, 89)
	self.View.y = math.NormalizeAngle(self.View.y + (self.CmdM["GetMouseX"](cmd) * -GetConVarNumber("m_yaw")))
end

function MultiHack:FakeView(ply, origin, angles, FOV)
	if GetViewEntity() != me then return end
	
	if self.AimbotFakeView:GetInt() <= 0 || (self.Aimbot:GetInt() <= 0) then self.View = self.EntM["EyeAngles"](me) end
	
	local base = self:CalcView(ply, origin, self.View, FOV) or {}
	
	base.angles = base.angles or (self.AngleTo or self.View)
	
	if self.NoRecoil:GetInt() >= 1 then base.angles.r = 0 end
	
	return base
end

// Update Entity List
function MultiHack:UpdateLists()
	self.NPCList = {}
	self.PlayerList = {}
	self.List = {}

	for k, v in pairs(player.GetAll()) do
		// Players
		if self:ValidTarget(v) && v:IsPlayer() then
			table.insert(self.PlayerList, v)
			table.insert(self.List, v)
		end
	end
	
	for k, v in pairs(ents.GetAll()) do
		// NPCs
		if self:ValidTarget(v) && v:IsNPC() then
			table.insert(self.NPCList, v)
			table.insert(self.List, v)
		end
	end
end

// Aimbot
MultiHack.AimbotAttackState = false
MultiHack.AimbotState = (MultiHack.Aimbot:GetInt() >= 1 and 1 or 0)
MultiHack.NextShot = 0

MultiHack.NotAuto = { "weapon_pistol", "weapon_rpg", "weapon_357", "weapon_crossbow", "weapon_deagle", "weapon_glock", "weapon_fiveseven" }

function MultiHack:IsSemiAuto(weap)
	return (weap.Primary && !weap.Primary.Automatic) || table.HasValue(self.NotAuto, self.EntM["GetClass"](weap))
end

function MultiHack:SetShooting(bool, ucmd)
	if self.AimbotAttackState == bool then return end
	
	self.AimbotAttackState = bool
	
	if self.AimbotKey:GetInt() <= 0 then
		self.RCC((bool and "+" or "-") .. "attack")
	else
		if bool then
			self.CmdM["SetButtons"](ucmd, self.CmdM["GetButtons"](ucmd) | IN_ATTACK)
		else
			self.CmdM["SetButtons"](ucmd, self.CmdM["GetButtons"](ucmd) & (0xFFFF - IN_ATTACK))
		end
	end
end

function MultiHack:CheckOK(e, IgnoreAdmins, IgnoreFriends, IgnorePlayers, IgnoreNPCs)
	if e:IsPlayer() then
		if IgnorePlayers then return false end
		if IgnoreAdmins && (self.PlyM["IsAdmin"](e) || self.PlyM["IsSuperAdmin"](e)) then return false end
		if IgnoreFriends && self.PlyM["GetFriendStatus"](e) == "friend" then return false end
	end
	
	// It's a NPC, return true if ignoring npcs is off, otherwise false.
	return IgnoreNPCs == false
end

function MultiHack:AimbotEnabled(ucmd)
	if self.Aimbot:GetInt() >= 1 then
		if self.AimbotKey:GetInt() >= 1 then
			return ((self.CmdM["GetButtons"](ucmd) & IN_ATTACK) > 0)
			//return ((ucmd:GetButtons() & IN_ATTACK) > 0)
		end
		
		return true
	end
	
	return false
end

function MultiHack:AimbotThink(cmd)
	local enabled = self:AimbotEnabled(cmd)
	local IgnorePlayers, IgnoreNPCs = self.AimbotIgnorePlayers:GetInt() >= 1, self.AimbotIgnoreNPCs:GetInt() >= 1

	if self.AimbotState == 0 && enabled then
		self.View = self.EntM["EyeAngles"](me)
		self.AimbotState = 1
		
		self:SetShooting(false, cmd)
	elseif self.AimbotState == 1 && !enabled then
		self.CmdM["SetViewAngles"](cmd, self.View * 1)
		
		self.AimbotState = 0
		
		self:SetShooting(false, cmd)
	end
	
	if enabled && (!IgnorePlayers || !IgnoreNPCs) && self.PlyM["Alive"](me) && self:HasAmmo() && self:WeaponCheck() && !self.PlyM["InVehicle"](me) then
		local currtarget, pos, Target, Aim = {}, self.EntM["GetPos"](me), nil, nil
		
		for _, e in pairs(self:GetEnts(self.List)) do
			if self:IsVisible(e) && self:CheckOK(e, IgnoreAdmins, IgnoreFriends, IgnorePlayers, IgnoreNPCs) then
				local dist = pos:Distance(self.EntM["GetPos"](e))
				
				if !currtarget[2] then
					currtarget = { e, dist }
				else
					if dist < currtarget[2] then
						currtarget = { e, dist }
					end
				end
			end
		end
		
		if currtarget[1] then Target = currtarget[1] end
		
		// Look for visible players/npcs. This check fails if players/npcs are standing in eachother,
		// so I implemeted the other trace check.
		if Target then
			Aim = self:GetHeadPos(Target)
				
			if self.AimbotPrediction:GetInt() >= 1 then
				local position, weapon = self.EntM["GetPos"](me), self.PlyM["GetActiveWeapon"](me)
				local speed, distance = position:Distance(position + self.EntM["GetVelocity"](me)), position:Distance(self.EntM["GetPos"](Target))
					
				local p, t = Vector(0, 0, 0), Vector(0, 0, 0)
					
				if distance < 4000 && speed > 0 then p = self.EntM["GetVelocity"](me) * distance / (speed * distance * 0.125) end
				if weapon:IsWeapon() && self.Prediction[weapon:GetClass()] != 0 then t = self.EntM["GetVelocity"](Target) * distance / (self.Prediction[weapon:GetClass()] || 150000) end
					
				Aim = Aim - p + t
			end
				
			Aim = (Aim - self:GetShootPos()):GetNormal():Angle()
			
			Aim.p = math.NormalizeAngle(Aim.p)
			Aim.y = math.NormalizeAngle(Aim.y)
		else
			// Look for the entity trace.
			local trace = util.TraceLine({ start = self:GetShootPos(), endpos = self:GetShootPos() + (self.PlyM["GetAimVector"](me) * 999999999) })
			local t = type(trace.Entity)
			
			if self.ValidTarget(trace.Entity) && (t == "Player" || t == "NPC") then
				Aim = self:GetHeadPos(trace.Entity)
				
				if self.AimbotPrediction:GetInt() >= 1 then
					local position, weapon = self.EntM["GetPos"](me), self.PlyM["GetActiveWeapon"](me)
					local speed, distance = position:Distance(position + self.EntM["GetVelocity"](me)), position:Distance(self.EntM["GetPos"](trace.Entity))
						
					local p, t = Vector(0, 0, 0), Vector(0, 0, 0)
						
					if distance < 4000 && speed > 0 then p = self.EntM["GetVelocity"](me) * distance / (speed * distance * 0.125) end
					if weapon:IsWeapon() && self.Prediction[weapon:GetClass()] != 0 then t = self.EntM["GetVelocity"](trace.Entity) * distance / (self.Prediction[weapon:GetClass()] || 150000) end
						
					Aim = Aim - p + t
				end
				
				Aim = self.VecM["Angle"](self.VecM["GetNormal"](Aim - self:GetShootPos()))
			
				Aim.p = math.NormalizeAngle(Aim.p)
				Aim.y = math.NormalizeAngle(Aim.y)
			end
		end
		
		if Aim then // Only aim if we have a target!
			// Shoot if we have a target!
			if CurTime() >= self.NextShot then
				self.NextShot = CurTime() + 0.1
					
				self:SetShooting(true, cmd)
					
				// If we're semi-auto, we want to stop holding down fire.
				if self:IsSemiAuto(self.PlyM["GetActiveWeapon"](me)) then
					timer.Simple(0.05, function() self:SetShooting(false, cmd) end)
				end
			end
		
			self.CmdM["SetViewAngles"](cmd, Aim)
		else
			// If the aimbot has no target and is still attacking, we should stop firing.
			if self.AimbotAttackState then
				self:SetShooting(false, cmd)
			end
			
			if self.AimbotFakeView:GetInt() >= 1 then self.CmdM["SetViewAngles"](cmd, EyeAngles()) end
		end
	else
		// If the aimbot is not enabled and still attacking, we should stop firing.
		if self.AimbotAttackState then
			self:SetShooting(false, cmd)
		end
		
		// Y U NO STOP BUGGING?!
		if enabled || (self.Aimbot:GetInt() >= 1 && self.AimbotKey:GetInt() >= 1) then
			if self.AimbotFakeView:GetInt() >= 1 then self.CmdM["SetViewAngles"](cmd, EyeAngles()) end
		end
	end
	
	// Change the players movement to be relative to their view instead of their aim.
	local move = Vector(self.CmdM["GetForwardMove"](cmd), self.CmdM["GetSideMove"](cmd), 0)
	local norm = self.VecM["GetNormal"](move)
	local set = self.AngM["Forward"](self.VecM["Angle"](norm) + (self.EntM["EyeAngles"](me) - self.View * 1)) * self.VecM["Length"](move)
					
	self.CmdM["SetForwardMove"](cmd, set.x)
	self.CmdM["SetSideMove"](cmd, set.y)
end

// Crosshair
function MultiHack:DrawCrosshair()
	if (self.Crosshair:GetInt() >= 1 || self.CrosshairDot:GetInt() >= 1) && self.PlyM["Alive"](me) && !self.PlyM["InVehicle"](me) then
		if GetConVarNumber("crosshair") == 1 then self.RCC("crosshair", "0") end
	
		local W, H = surface.ScreenWidth() / 2, surface.ScreenHeight() / 2
	
		if self.Crosshair:GetInt() >= 1 then
			surface.CreateFont("HL2Cross", 44, 430, true, false, "hl2c_crosshair")
		
			draw.SimpleText("(", "hl2c_crosshair", W - 15, H, Color(MultiHack.CrosshairColorR:GetInt(), MultiHack.CrosshairColorG:GetInt(), MultiHack.CrosshairColorB:GetInt(), 255), 2, 1)
			draw.SimpleText(")", "hl2c_crosshair", W + 15, H, Color(MultiHack.CrosshairColorR:GetInt(), MultiHack.CrosshairColorG:GetInt(), MultiHack.CrosshairColorB:GetInt(), 255), 0, 1)
		end
		
		if self.CrosshairDot:GetInt() >= 1 then
			for i = 1, self.CrosshairDotSize:GetInt() do
				surface.DrawCircle(W, H, i, Color(MultiHack.CrosshairDotColorR:GetInt(), MultiHack.CrosshairDotColorG:GetInt(), MultiHack.CrosshairDotColorB:GetInt()))
			end
		end
	else
		if GetConVarNumber("crosshair") == 0 then self.RCC("crosshair", "1") end
	end
end

// Radar
function MultiHack:Radar()
	local BackGround = vgui.Create("DFrame")
	
	BackGround:SetSize(200, 200)
	BackGround:SetPos(0, 0)
	BackGround:SetTitle("MultiHack - Radar")
	BackGround:SetVisible(self.RadarCVar:GetInt() >= 1 and true or false)
	BackGround:SetDraggable(true)
	BackGround:ShowCloseButton(false)
	BackGround:MakePopup()
	
	local w, h = BackGround:GetWide(), BackGround:GetTall()
	local xn, yn = surface.ScreenWidth(), surface.ScreenHeight()
	
	BackGround.Paint = function()
		draw.RoundedBox(4, 0, 0, w, h, Color(200, 0, 0, 200))
		draw.RoundedBox(2, 2, 2, w - 4, 21, Color(50, 50, 50, 200))
		
		// Radar Function
		local range = self.RadarRange:GetInt()
		
		local radar = {}
		radar.h		= h - 32
		radar.w		= w - 12
		radar.org	= range * 100
		
		local x, y = xn / 2, yn / 2
		
		local hlfX, hlfY = (w / 2), (h / 2) + 10
		local color = Color(0, 0, 200, 200)
		
		surface.SetDrawColor(Color(50, 50, 50, 255))
		surface.DrawLine(hlfX, hlfY - 95, hlfX, hlfY + 90)
		surface.DrawLine(hlfX - 100, hlfY, hlfX + 100, hlfY)
		
		for _, e in pairs(self:GetEnts(self.List)) do
			local s = 6
			local plyfov = self.PlyM["GetFOV"](me) / (70 / 1.13)
			local zpos, npos = self.EntM["GetPos"](me).z - (self.EntM["GetPos"](e).z), (self.EntM["GetPos"](me) - self.EntM["GetPos"](e))
					
			npos:Rotate(Angle(180, (self.EntM["EyeAngles"](me).y) * -1, -180))
					
			local iY = npos.y * (radar.h / ((radar.org * (plyfov * (xn / yn))) + zpos * (plyfov * (xn / yn))))
			local iX = npos.x * (radar.w / ((radar.org * (plyfov * (xn / yn))) + zpos * (plyfov * (xn / yn))))
					
			local pX = (radar.w / 2)
			local pY = (radar.h / 2)
					
			local posX = pX - iY - (s / 2) + 6
			local posY = pY - iX - (s / 2) + 26
						
			if iX < (radar.h / 2) && iY < (radar.w / 2) && iX > (-radar.h / 2) && iY > (-radar.w / 2) then
				draw.RoundedBox(0, posX, posY, s, s, color)
			end
		end	
	end
	
	local BSheet = vgui.Create("DPropertySheet", BackGround)
	
	BSheet:SetSize(w - 10, h - 30)
	BSheet:SetPos(5, 25)
	BSheet.Paint = function()
		draw.RoundedBox(8, 0, 0, BSheet:GetWide(), BSheet:GetTall(), Color(50, 50, 50, 75))
	end
	
	BackGround:SetMouseInputEnabled(false)
	BackGround:SetKeyboardInputEnabled(false)

	return BackGround
end

// Admin draw
function MultiHack:AdminDraw()
	local BackGround = vgui.Create("DFrame")
	
	local W, H = 200, 50
	
	BackGround:SetSize(W, H)
	BackGround:SetPos(surface.ScreenWidth() - 200, 0)
	BackGround:SetTitle("MultiHack - Admins")
	BackGround:SetVisible(self.AdminDrawCVar:GetInt() >= 1 and true or false)
	BackGround:SetDraggable(true)
	BackGround:ShowCloseButton(false)
	BackGround:MakePopup()
	BackGround.Paint = function()
		draw.RoundedBox(4, 0, 0, BackGround:GetWide(), BackGround:GetTall(), Color(200, 0, 0, 200))
		draw.RoundedBox(2, 2, 2, BackGround:GetWide() - 4, 21, Color(50, 50, 50, 200))

		local adminstr = ""
		local AddH = -10
		
		for _, e in pairs(self:GetEnts(self.PlayerList)) do
			if self.PlyM["IsSuperAdmin"](e) || self.PlyM["IsAdmin"](e) then
				adminstr = adminstr .. (adminstr != "" and "\n" or "") .. e:Name() .. (self.PlyM["IsSuperAdmin"](e) and " [SA]" or " [NA]")
				
				AddH = AddH + 10
			end
		end
		
		if AddH == -10 then AddH = 0 end
		if adminstr == "" then adminstr = "No admins found." end

		// Set the size of the admin list.
		if AddH > 0 then
			if BackGround:GetTall() != (H + AddH) then
				BackGround:SetSize(W, H + AddH)
			end
		else
			if BackGround:GetWide() != W then
				BackGround:SetSize(W, H)
			end
		end
		
		if self.BSheet then
			if AddH > 0 then
				if self.BSheet:GetTall() != (H + AddH - 30) then
					self.BSheet:SetSize(W - 10, H + AddH - 30)
				end
			else
				if self.BSheet:GetTall() != (H - 30) then
					self.BSheet:SetSize(W - 10, H - 30)
				end
			end
		end
		
		// Draw the admins into the box.
		self:DrawText(adminstr, "Default", 10, 27, Color(255, 255, 255, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_RIGHT)
	end
	
	local BSheet = vgui.Create("DPropertySheet", BackGround)
	
	BSheet:SetSize(W - 10, H - 30)
	BSheet:SetPos(5, 25)
	BSheet.Paint = function()
		draw.RoundedBox(8, 0, 0, BSheet:GetWide(), BSheet:GetTall(), Color(50, 50, 50, 75))
	end
	
	BackGround:SetMouseInputEnabled(false)
	BackGround:SetKeyboardInputEnabled(false)
	
	return BackGround, BSheet
end

// Menu
function MultiHack:Menu()
	// Background size
	local BackGroundSize = { surface.ScreenWidth() - 280, surface.ScreenHeight() - 310 }
	local BackGroundColor = { Color(0, 0, 200, 200), Color(50, 50, 50, 200), Color(50, 50, 50, 150) }
	
	// Button positions
	local ButtonPos = { 10, 40 }
	local ButtonSize = { 70, 30 }
	local ButtonAdd = 40
	
	// Text color
	local TextColor = Color(255, 255, 255, 255)
	
	// Text position
	local TextPos = { 10, 20 }
	local TextAdd = 20
	
	// Slider add
	local SliderAdd = 40
	local SliderPos = { 200, 20 }
	
	// Background
	local BackGround = vgui.Create("DFrame")
	
	BackGround:SetSize(BackGroundSize[1] / 2, BackGroundSize[2] / 3)
	BackGround:SetPos(BackGroundSize[1] / 2 - BackGround:GetWide() / 2 , BackGroundSize[2] / 2 - BackGround:GetTall() / 2)
	BackGround:SetTitle("MultiHack - Menu")
	BackGround:SetVisible(false)
	BackGround:SetDraggable(true)
	BackGround:ShowCloseButton(false)
	BackGround:MakePopup()
	BackGround.Paint = function()
		draw.RoundedBox(4, 0, 0, BackGround:GetWide(), BackGround:GetTall(), BackGroundColor[1])
		draw.RoundedBox(2, 2, 2, BackGround:GetWide() - 4, 21, BackGroundColor[2])
	end

	local BackGround2 = vgui.Create("DPropertySheet", BackGround)
	
	BackGround2:SetSize(BackGroundSize[1] / 2 - 10, BackGroundSize[2] / 3 - 30)
	BackGround2:SetPos(5, 25)
	BackGround2.Paint = function()
		draw.RoundedBox(8, 0, 0, BackGround2:GetWide(), BackGround2:GetTall(), BackGroundColor[3])
	end
	
	// Make things easier
	local function AddToMenu(typ, opt1, opt2, opt3, opt4, opt5, opt6, opt7, opt8, opt9)
		if not typ then return nil end
		
		typ = string.lower(typ)
		
		if typ == "box" then
			local CheckBox = vgui.Create("DCheckBoxLabel", opt1)
			
			CheckBox:SetPos(TextPos[1], TextPos[2] + TextAdd * opt5)
			CheckBox:SetParent(opt1)
			CheckBox:SetText(opt2)
			CheckBox:SetConVar(self.CVarPrefix .. opt3)
			CheckBox:SetValue(GetConVarNumber(self.CVarPrefix .. opt3))
			CheckBox:SetTextColor(TextColor)
			CheckBox:SizeToContents()
		elseif typ == "button" then
			local MenuButton = vgui.Create("DLabel", opt1)
			
			MenuButton:SetPos(0, 10)
			MenuButton:SetParent(opt1)
			MenuButton:SetText("")
			
			return MenuButton
		elseif typ == "slider" then
			local MenuSlider = vgui.Create("DNumSlider", opt1)
			
			MenuSlider:SetParent(opt1)
			MenuSlider:SetWide(opt4)
			MenuSlider:SetText(opt2)
			MenuSlider:SetConVar(self.CVarPrefix .. opt5)
			MenuSlider:SetValue(GetConVarNumber(self.CVarPrefix .. opt5))
			MenuSlider:SetMin(opt6)
			MenuSlider:SetMax(opt7)
			MenuSlider:SetDecimals(opt8 or 0)
			MenuSlider:SetPos(SliderPos[1], SliderPos[2] + SliderAdd * opt3)
		elseif typ == "slider2" then
			local MenuSlider = vgui.Create("DNumSlider", opt1)
			
			MenuSlider:SetWide(opt4)
			MenuSlider:SetText(opt2)
			MenuSlider:SetConVar(self.CVarPrefix .. opt5)
			MenuSlider:SetValue(GetConVarNumber(self.CVarPrefix .. opt5))
			MenuSlider:SetMin(opt6)
			MenuSlider:SetMax(opt7)
			MenuSlider:SetDecimals(opt8 or 0)
			MenuSlider:SetPos(SliderPos[1] + 130, SliderPos[2] + SliderAdd * opt3)
		end
	end
	
	// Dem tabs
	local AimbotTab = AddToMenu("button", BackGround2)
	local PlayerESPTab = AddToMenu("button", BackGround2)
	local NPCESPTab = AddToMenu("button", BackGround2)
	local WallhackTab = AddToMenu("button", BackGround2)
	local CrosshairTab = AddToMenu("button", BackGround2)
	local LaserTab = AddToMenu("button", BackGround2)
	local MiscTab = AddToMenu("button", BackGround2)
	
	// Aimbot
	AddToMenu("box", AimbotTab, "Enabled", "Aimbot", true, 0)
	AddToMenu("box", AimbotTab, "Predict", "AimbotPrediction", true, 1)
	AddToMenu("box", AimbotTab, "Fake View", "AimbotFakeView", true, 2)
	AddToMenu("box", AimbotTab, "Ignore Friends", "AimbotIgnoreFriends", true, 3)
	AddToMenu("box", AimbotTab, "Ignore Admins", "AimbotIgnoreAdmins", true, 4)
	AddToMenu("box", AimbotTab, "Ignore NPCs", "AimbotIgnoreNPCs", true, 5)
	AddToMenu("box", AimbotTab, "Ignore Players", "AimbotIgnorePlayers", true, 6)
	AddToMenu("box", AimbotTab, "Aim Key", "AimbotKey", true, 7)
	
	// Player ESP
	AddToMenu("box", PlayerESPTab, "Enabled", "PlayerESP", false, 0)
	AddToMenu("box", PlayerESPTab, "Aim Point", "PlayerESPAimPoint", false, 1)
	AddToMenu("box", PlayerESPTab, "Special Box", "PlayerESPBoxMode", false, 2)
	AddToMenu("box", PlayerESPTab, "Draw Name", "PlayerESPDrawName", false, 3)
	AddToMenu("box", PlayerESPTab, "Draw Distance", "PlayerESPDrawDist", false, 4)
	AddToMenu("box", PlayerESPTab, "Draw Health Bar", "PlayerESPDrawHealthBar", false, 5)
	AddToMenu("slider", PlayerESPTab, "Box Color R", 0, 120, "PlayerESPBoxColorR", 0, 255, 0, false)
	AddToMenu("slider", PlayerESPTab, "Box Color G", 1, 120, "PlayerESPBoxColorG", 0, 255, 0, false)
	AddToMenu("slider", PlayerESPTab, "Box Color B", 2, 120, "PlayerESPBoxColorB", 0, 255, 0, false)
	AddToMenu("slider", PlayerESPTab, "Box Col. Mode", 3, 120, "PlayerESPBoxColorMode", 1, 3, 0, false)
	AddToMenu("slider2", PlayerESPTab, "Text Color R", 0, 120, "PlayerESPTextColorR", 0, 255, 0, false)
	AddToMenu("slider2", PlayerESPTab, "Text Color G", 1, 120, "PlayerESPTextColorG", 0, 255, 0, false)
	AddToMenu("slider2", PlayerESPTab, "Text Color B", 2, 120, "PlayerESPTextColorB", 0, 255, 0, false)
	AddToMenu("slider2", PlayerESPTab, "Text Col. Mode", 3, 120, "PlayerESPTextColorMode", 1, 3, 0, false)
	
	// NPC ESP
	AddToMenu("box", NPCESPTab, "Enabled", "NPCESP", false, 0)
	AddToMenu("box", NPCESPTab, "Aim Point", "NPCESPAimPoint", false, 1)
	AddToMenu("box", NPCESPTab, "Special Box", "NPCESPBoxMode", false, 2)
	AddToMenu("box", NPCESPTab, "Draw Class", "NPCESPDrawClass", false, 3)
	AddToMenu("box", NPCESPTab, "Draw Distance", "NPCESPDrawDist", false, 4)
	AddToMenu("slider", NPCESPTab, "Box Color R", 0, 120, "NPCESPBoxColorR", 0, 255, 0, false)
	AddToMenu("slider", NPCESPTab, "Box Color G", 1, 120, "NPCESPBoxColorG", 0, 255, 0, false)
	AddToMenu("slider", NPCESPTab, "Box Color B", 2, 120, "NPCESPBoxColorB", 0, 255, 0, false)
	AddToMenu("slider", NPCESPTab, "Box Col. Mode", 3, 120, "NPCESPBoxColorMode", 1, 3, 0, false)
	AddToMenu("slider2", NPCESPTab, "Text Color R", 0, 120, "NPCESPTextColorR", 0, 255, 0, false)
	AddToMenu("slider2", NPCESPTab, "Text Color G", 1, 120, "NPCESPTextColorG", 0, 255, 0, false)
	AddToMenu("slider2", NPCESPTab, "Text Color B", 2, 120, "NPCESPTextColorB", 0, 255, 0, false)
	AddToMenu("slider2", NPCESPTab, "Text Col. Mode", 3, 120, "NPCESPTextColorMode", 1, 2, 0, false)
	
	// Wallhack
	AddToMenu("box", WallhackTab, "Player Wallhack", "PlayerWallhack", false, 0)
	AddToMenu("box", WallhackTab, "Only draw if not visible", "PlayerWallhackVisible", false, 1)
	AddToMenu("box", WallhackTab, "Players Solid", "PlayerWallhackSolid", false, 2)
	AddToMenu("box", WallhackTab, "NPC Wallhack", "NPCWallhack", false, 3)
	AddToMenu("box", WallhackTab, "Only draw if not visible", "NPCWallhackVisible", false, 4)
	AddToMenu("box", WallhackTab, "NPCs Solid", "NPCWallhackSolid", false, 5)
	AddToMenu("slider", WallhackTab, "Pl. WH. Col. R", 0, 120, "PlayerWallhackColorR", 0, 255, 0, false)
	AddToMenu("slider", WallhackTab, "Pl. WH. Col. G", 1, 120, "PlayerWallhackColorG", 0, 255, 0, false)
	AddToMenu("slider", WallhackTab, "Pl. WH. Col. B", 2, 120, "PlayerWallhackColorB", 0, 255, 0, false)
	AddToMenu("slider", WallhackTab, "Pl. WH. Col. A", 3, 120, "PlayerWallhackColorA", 0, 255, 0, false)
	AddToMenu("slider2", WallhackTab, "NPC WH. Col. R", 0, 120, "NPCWallhackColorR", 0, 255, 0, false)
	AddToMenu("slider2", WallhackTab, "NPC WH. Col. G", 1, 120, "NPCWallhackColorG", 0, 255, 0, false)
	AddToMenu("slider2", WallhackTab, "NPC WH. Col. B", 2, 120, "NPCWallhackColorB", 0, 255, 0, false)
	AddToMenu("slider2", WallhackTab, "NPC WH. Col. A", 3, 120, "NPCWallhackColorA", 0, 255, 0, false)
	
	// Crosshair
	AddToMenu("box", CrosshairTab, "HL2 Crosshair", "Crosshair", false, 0)
	AddToMenu("box", CrosshairTab, "Crosshair Dot", "CrosshairDot", false, 1)
	AddToMenu("slider", CrosshairTab, "C. Color R", 0, 120, "CrosshairColorR", 0, 255, 0, false)
	AddToMenu("slider", CrosshairTab, "C. Color G", 1, 120, "CrosshairColorG", 0, 255, 0, false)
	AddToMenu("slider", CrosshairTab, "C. Color B", 2, 120, "CrosshairColorB", 0, 255, 0, false)
	AddToMenu("slider2", CrosshairTab, "C. Dot Col. R", 0, 120, "CrosshairDotColorR", 0, 255, 0, false)
	AddToMenu("slider2", CrosshairTab, "C. Dot Col. G", 1, 120, "CrosshairDotColorG", 0, 255, 0, false)
	AddToMenu("slider2", CrosshairTab, "C. Dot Col. B", 2, 120, "CrosshairDotColorB", 0, 255, 0, false)
	AddToMenu("slider2", CrosshairTab, "C. Dot Size", 3, 120, "CrosshairDotSize", 1, 30, 0, false)
	
	// Lasers
	AddToMenu("box", LaserTab, "Laser Eyes", "LaserEyes", false, 0)
	AddToMenu("slider", LaserTab, "L. Color R", 0, 120, "LaserColorR", 0, 255, 0, false)
	AddToMenu("slider", LaserTab, "L. Color G", 1, 120, "LaserColorG", 0, 255, 0, false)
	AddToMenu("slider", LaserTab, "L. Color B", 2, 120, "LaserColorB", 0, 255, 0, false)
	AddToMenu("slider", LaserTab, "L. Color A", 3, 120, "LaserColorA", 0, 255, 0, false)
	AddToMenu("slider2", LaserTab, "L. Point C. R", 0, 120, "LaserPointColorR", 0, 255, 0, false)
	AddToMenu("slider2", LaserTab, "L. Point C. G", 1, 120, "LaserPointColorG", 0, 255, 0, false)
	AddToMenu("slider2", LaserTab, "L. Point C. B", 2, 120, "LaserPointColorB", 0, 255, 0, false)
	AddToMenu("slider2", LaserTab, "L. Point C. A", 3, 120, "LaserPointColorA", 0, 255, 0, false)
	
	// Misc
	AddToMenu("box", MiscTab, "No Recoil", "NoRecoil", false, 0)
	AddToMenu("box", MiscTab, "Auto Reload", "AutoReload", false, 1)
	AddToMenu("box", MiscTab, "Bunnyhop", "Bunnyhop", false, 2)
	AddToMenu("box", MiscTab, "Radar", "Radar", false, 3)
	AddToMenu("box", MiscTab, "Show Admins", "AdminDraw", false, 4)
	AddToMenu("box", MiscTab, "Spy Cam", "SpyCam", false, 5)
	AddToMenu("box", MiscTab, "IP Logger", "IPLogger", false, 6)
	AddToMenu("box", MiscTab, "Block RunConsoleCommand", "BlockRCC", false, 7)
	AddToMenu("slider", MiscTab, "Radar Range", 0, 120, "RadarRange", 1, 120, 0, false)
	
	// Finally add dem sheets
	BackGround2:AddSheet("Aimbot", AimbotTab, "gui/silkicons/star", false, false, "A basic Aimbot" )
	BackGround2:AddSheet("Player ESP", PlayerESPTab, "gui/silkicons/star", false, false, "ESP for Players")
	BackGround2:AddSheet("NPC ESP", NPCESPTab, "gui/silkicons/star", false, false, "ESP for NPCs")
	BackGround2:AddSheet("Wallhack", WallhackTab, "gui/silkicons/star", false, false, "Wireframe / Chams")
	BackGround2:AddSheet("Crosshair", CrosshairTab, "gui/silkicons/star", false, false, "Custom Crosshair")
	BackGround2:AddSheet("Laser", LaserTab, "gui/silkicons/star", false, false, "Eye Lasers")
	BackGround2:AddSheet("Misc", MiscTab, "gui/silkicons/star", false, false, "Miscellaneous")
	
	// Maybe controll the menu
	BackGround:SetMouseInputEnabled(true)
	BackGround:SetKeyboardInputEnabled(true)

	return BackGround
end

concommand.Add("+" .. MultiHack.CVarPrefix .. "Menu", function()
	MultiHack.M:SetVisible(true)
	
	if MultiHack.R then
		MultiHack.R:SetMouseInputEnabled(true)
		MultiHack.R:SetKeyboardInputEnabled(true)
	end
	
	if MultiHack.A then
		MultiHack.A:SetMouseInputEnabled(true)
		MultiHack.A:SetKeyboardInputEnabled(true)
	end
end)

concommand.Add("-" .. MultiHack.CVarPrefix .. "Menu", function()
	MultiHack.M:SetVisible(false)
	
	if MultiHack.R then
		MultiHack.R:SetMouseInputEnabled(false)
		MultiHack.R:SetKeyboardInputEnabled(false)
	end
	
	if MultiHack.A then
		MultiHack.A:SetMouseInputEnabled(false)
		MultiHack.A:SetKeyboardInputEnabled(false)
	end
end)

// Some extra thinks, yay!
function MultiHack:HUDThink()
	local RadarCVar = self.RadarCVar:GetInt()
	local AdminDrawCVar = self.AdminDrawCVar:GetInt()
	
	// Radar
	if self.R then
		if self.R:IsVisible() && RadarCVar <= 0 then
			self.R:SetVisible(false)
		elseif !self.R:IsVisible() && RadarCVar >= 1 then
			self.R:SetVisible(true)
		end
	end
	
	// Admin Draw
	if self.A then
		if self.A:IsVisible() && AdminDrawCVar <= 0 then
			self.A:SetVisible(false)
		elseif !self.A:IsVisible() && AdminDrawCVar >= 1 then
			self.A:SetVisible(true)
		end
	end
end

// Bunnyhop main
function MultiHack:BunnyhopThink(ucmd)
	if self.Bunnyhop:GetInt() >= 1 then
		if self.PlyM["Alive"](me) && !self.PlyM["InVehicle"](me) && (self.CmdM["GetButtons"](ucmd) & IN_JUMP) > 0 then
			if self.EntM["IsOnGround"](me) then
				self.CmdM["SetButtons"](ucmd, self.CmdM["GetButtons"](ucmd) | IN_JUMP)
			else
				self.CmdM["SetButtons"](ucmd, self.CmdM["GetButtons"](ucmd) & (0xFFFF - IN_JUMP))
			end
		end
	end
end

// Wallhack main
function MultiHack:WallhackThink()
	local playerw, npcw, playervis, npcvis = self.PlayerWallhack:GetInt() >= 1, self.NPCWallhack:GetInt() >= 1, self.PlayerWallhackVisible:GetInt() >= 1, self.NPCWallhackVisible:GetInt() >= 1

	if playerw || npcw then
		cam.Start3D(EyePos(), EyeAngles())
	
		for _, e in pairs(self:GetEnts(self.List)) do
			local t = type(e)
		
			local isnpc, isplayer, color = (t == "NPC"), (t == "Player")
			
			if ((isnpc && npcw) || (isplayer && playerw)) then
				local vis = self:IsVisible(e)
				
				if ((!vis && playerw && isplayer && playervis) || (!playervis && isplayer) || (!vis && npcw && isnpc && npcvis) || (!npcvis && isnpc)) then
					if isnpc then
						color = Color(self.NPCWallhackColorR:GetInt(), self.NPCWallhackColorG:GetInt(), self.NPCWallhackColorB:GetInt(), self.NPCWallhackColorA:GetInt())
					else
						color = Color(self.PlayerWallhackColorR:GetInt(), self.PlayerWallhackColorG:GetInt(), self.PlayerWallhackColorB:GetInt(), self.PlayerWallhackColorA:GetInt())
					end
					
					if isnpc then
						SetMaterialOverride(self.NPCWallhackSolid:GetInt() <= 0 && self:GetMaterial("WireframeMat") || self:GetMaterial("Chams"))
					else
						SetMaterialOverride(self.PlayerWallhackSolid:GetInt() <= 0 && self:GetMaterial("WireframeMat") || self:GetMaterial("Chams"))
					end
					
                    render.SetColorModulation(color.r / 255, color.g / 255, color.b / 255)
                    render.SetBlend(color.a / 255)
					
					self.EntM["DrawModel"](e)
					
                    SetMaterialOverride()
				end
			end
		end
		
		cam.End3D()
	end
end

// Speedhack main
function MultiHack:SpeedhackThink()
	if GetConVarNumber("ms_host_timescale") == 1.0 && self.Speedhack:GetInt() >= 1 then
		self.RCC("ms_host_timescale", "10")
	elseif GetConVarNumber("ms_host_timescale") == 10 && self.Speedhack:GetInt() <= 0 then
		self.RCC("ms_host_timescale", "1.0")
	end
end

// Laser Eyes Main
function MultiHack:LaserEyesThink()
	if self.LaserEyes:GetInt() >= 1 && self.PlyM["Alive"](me) && !self.PlyM["InVehicle"](me) && self.SpyCam:GetInt() <= 0 then
		cam.Start3D(EyePos(), EyeAngles())
		
		local ViewModel = self.PlyM["GetViewModel"](me)
		local ActiveWeapon = self.PlyM["GetActiveWeapon"](me)
		
		if ViewModel && ValidEntity(ActiveWeapon) && ValidEntity(ViewModel) then
			if ActiveWeapon:GetClass() != "weapon_physgun" then
				local AI = ViewModel:LookupAttachment("muzzle")
				
				if(AI == 0) then
					AI = ViewModel:LookupAttachment("1")
				end
				
				local trace = util.TraceLine(util.GetPlayerTrace(me))
				
				if(ViewModel:GetAttachment(AI)) then
					render.SetMaterial(self.LaserMat)
					render.DrawBeam(ViewModel:GetAttachment(AI).Pos, trace.HitPos, 4, 0, 12.5, Color(self.LaserColorR:GetInt(), self.LaserColorG:GetInt(), self.LaserColorB:GetInt(), self.LaserColorA:GetInt()))

					render.SetMaterial(self.LaserMat2)
					render.DrawQuadEasy(trace.HitPos, (EyePos() - trace.HitPos):GetNormal(), 25, 25, Color(self.LaserPointColorR:GetInt(), self.LaserPointColorG:GetInt(), self.LaserPointColorB:GetInt(), self.LaserPointColorA:GetInt()))
				end
			end
		end
		
		cam.End3D()
	end
end

// Spy camera
MultiHack.SpyCamState = (MultiHack.SpyCam:GetInt() >= 1 and 1 or 0)

function MultiHack:StopMove(ucmd)
	local enabled = self.SpyCam:GetInt() >= 1

	if self.SpyCamState == 1 && !enabled then
		self.SpyCamState = 0
	elseif MultiHack.SpyCamState == 0 && enabled then
		self.SpyCamState = 1
		
		self.CamPos = self.PlyM["EyePos"](me)
	end

	if enabled then
		self.CmdM["SetForwardMove"](ucmd, 0)
		self.CmdM["SetSideMode"](ucmd, 0)
		self.CmdM["SetUpMove"](ucmd, 0)
	end
end

function MultiHack:CalcView(ply, origin, angles, fov)
	local view = {}

	if self.SpyCam:GetInt() <= 0 then
		view.origin = origin
		view.angles = angles
		view.fov = fov
	else
		if not self.CamPos then self.CamPos = self.EntM["EyePos"](me) end
	
		angles = angles:Forward()
		
		local trace
		
		if self.PlyM["KeyDown"](me, IN_FORWARD) then
			trace = util.TraceLine({ start = self.CamPos, endpos = self.CamPos + angles * FrameTime() * 200, mask = COLLISION_GROUP_WORLD })
			
			self.CamPos = trace.HitPos
		end
		
		if self.PlyM["KeyDown"](me, IN_BACK) then
			trace = util.TraceLine({ start = self.CamPos, endpos = self.CamPos + angles * FrameTime() * -200, mask = COLLISION_GROUP_WORLD })
			
			self.CamPos = trace.HitPos
		end
		
		if self.PlyM["KeyDown"](me, IN_MOVELEFT) then
			trace = util.TraceLine({ start = self.CamPos, endpos = self.CamPos + self.VecM["Angle"](angles):Right() * FrameTime() * -200, mask = COLLISION_GROUP_WORLD })
			
			self.CamPos = trace.HitPos
		end
		
		if self.PlyM["KeyDown"](me, IN_MOVERIGHT) then
			trace = util.TraceLine({ start = self.CamPos, endpos = self.CamPos + self.VecM["Angle"](angles):Right() * FrameTime() * 200, mask = COLLISION_GROUP_WORLD })
			
			self.CamPos = trace.HitPos
		end
		
		view.origin = self.CamPos
		view.angles = self.VecM["Angle"](angles)
		view.fov = fov
	end
	
	return view
end

// IP Logger
function MultiHack:GetIPTable()
	if !file.Exists(self.PrintPrefix .. "_IPs.txt") then file.Write(self.PrintPrefix .. "_IPs.txt", "") end
	
	local tab, t, p = {}, nil, string.Explode("\n", file.Read(self.PrintPrefix .. "_IPs.txt") or "")
	
	if p && #p > 0 then
		for k, v in pairs(p) do
			t = string.Explode("'s IP Address is: ", v)
		  
			if t then
				tab[t[1]] = t[2]
			end
		end
	end
	
	return tab
end

MultiHack.IPList = MultiHack:GetIPTable()

function MultiHack:PlayerConnect(name, ip)
	if self.IPLogger:GetInt() >= 1 then
		self.IPList[string.gsub(name, "'s IP Address is: ", "")] = ip
		
		local ips = ""
		
		for k, v in pairs(self.IPList) do
			ips = ips .. k .. "'s IP Address is: " ..v.. " \n"
		end
		
		file.Write(self.PrintPrefix .. "_IPs.txt", ips)
		
		self:AddChatText(tostring(name .. "'s IP Address is: " .. ip .. "."))
	end
end

// Add hook functions for less lag
function MultiHack:ThinkHooks()
	self:UpdateLists()
	self:NoRecoilThink()
	self:AutoReloadThink()
	self:HUDThink()
	self:SpeedhackThink()
end

function MultiHack:HUDPaintHooks()
	self:DrawESP()
	self:DrawCrosshair()
end

function MultiHack:CreateMoveHooks(ucmd)
	self:AimbotThink(ucmd)
	self:RotateView(ucmd)
	self:BunnyhopThink(ucmd)
	self:StopMove(ucmd)
end

function MultiHack:RenderScreenspaceEffectsHooks()
	self:LaserEyesThink()
	self:WallhackThink()
end

// Timers
timer.Create("CheckMe", .1, 0, function()
	if LocalPlayer():IsValid() then
		// Set the "me" variable to the local player
		me = LocalPlayer()
		
		// Initialize the menu
		MultiHack.M = MultiHack:Menu()
		MultiHack.A, MultiHack.BSheet = MultiHack:AdminDraw()
		MultiHack.R = MultiHack:Radar()
		
		// Speedhack stuff
		if not ConVarExists("ms_host_timescale") then
			MultiHack.RCC("hide_cvars")
			MultiHack.RCC("ms_sv_cheats", "1")
		end
		
		// The script has successfully loaded, obviously.
		MsgN("Thank you for using " .. MultiHack.PrintPrefix .. ", " .. MultiHack.PlyM["Name"](me) .. "!")
		MsgN("Command Prefix: \"" .. MultiHack.CVarPrefix .. "\".")
		
		// Destroy the "CheckMe"-Timer.
		timer.Destroy("CheckMe")
	end
end)

// Add dem hooks
MultiHack:AddHook("Think", "ThinkHooks")
MultiHack:AddHook("HUDPaint", "HUDPaintHooks")
MultiHack:AddHook("CreateMove", "CreateMoveHooks")
MultiHack:AddHook("RenderScreenspaceEffects", "RenderScreenspaceEffectsHooks")
MultiHack:AddHook("CalcView", "FakeView") // Since we have only 1 function for this, we don't need to add a extra function.
MultiHack:AddHook("PlayerConnect", "PlayerConnect") // Same here.