// legacy

local legacy = {G = {}}
legacy.features = {}

-- Copy the _G table so we can forward a detoured function to the og one
_G.table.CopyFromTo(_G, legacy.G)

-- create cvars
legacy.cvars = {
    -- {"example",1} first one is the name of the cvar, second is the auto value (1 is true, 2 is false, if its a slider just set it to the value it is and if its a dropdown use a string)
    
    --aimbot
    {"aimbot", 0},
    --{"aimkey", 0},

    -- Misc
    {"bunnyhop", 0},
    {"autoStrafe_type", "off"},
    {"circleStrafe_speed", 50},

    -- Colors
    colors = {
    }
}

for k,v in ipairs(legacy.cvars) do
    if(IsColor(v[1]) or IsColor(v[2])) then continue end -- Don't create a color cvar lol
    CreateClientConVar("legacy_" .. v[1],v[2],false,false) -- Create the cvar
end 

// Menu

local menumain = {} -- Use so we can call it in the toggle hook without it going BVHAB



local function AddCheckBox(dtype, parent, tooltip, o1, o2, o3, o4, o5, o6, o7, o8, o9)
    local text, cvar, x, y = o1, o2, o3, o4;
    local dele = vgui.Create("DCheckBoxLabel", parent);
    dele:SetText(text);
    dele:SetConVar(cvar);
    dele:SetValue(GetConVar(cvar):GetBool());
    dele:SetPos(x, y);
    dele:SizeToContents();
    dele:SetTextColor(Color(0,0,0));
    if(tooltip ~= "") then
        dele:SetTooltip(tooltip);
    end
end

local function AddBinder(frame,x,y,sizex,sizey,tooltip,cvar)
    local binder = vgui.Create( "DBinder", frame );
    binder:SetSize( sizex, sizey);
    binder:SetPos( x, y );
    binder:SetTooltip(tooltip);
    binder:SetConVar(cvar);
end

local function AddSlider(dtype,text,pnl,tooltip,x,y,cvar,min,max,wide,dec)
    local dele = vgui.Create("DNumSlider", pnl);
    dele:SetPos(x, y);
    dele:SetWide(wide);
    dele:SetText("");
    dele:SetMin(math.Round(min));
    dele:SetMax(math.Round(max));
    dele:SetDecimals(dec);
    dele:SetConVar(cvar);
    if(tooltip ~= "") then
        dele:SetTooltip(tooltip);
    end
    dele:SetValue(GetConVar(cvar):GetInt())
end 


local function AddColorSetting(parent,x,y,valtoset)

    local clrx = x + 30
    local clry = y - 35

    if(x == 33 or y == 33) then 
        clry = clry + 30
    end

    -- automatic x and y calculation
    -- input would be the normal checkbox x and y pos
    /*

    Removed cuz didn't work with the checkbox diffrent lengths.

    */

    if(valtoset == 10) then 
        clrx = x - 15
        clry = y + 15         
    end

    y = y + 1

    local colorpicker = vgui.Create("DRGBPicker", parent)
    colorpicker:SetPos(clrx + 15.00, clry)
    colorpicker:SetSize(10, 75)
    colorpicker:SetRGB(legacy.cvars.colors[valtoset])
    local colorcube = vgui.Create("DColorCube", parent)
    colorcube:SetPos(clrx + 25, clry)
    colorcube:SetSize(75, 75)
    function colorpicker:OnChange(col)
        
        local h = ColorToHSV(col)
        local _, s, v = ColorToHSV(colorcube:GetRGB())
        
        col = HSVToColor(h, s, v)
        colorcube:SetColor(col)
        legacy.cvars.colors[valtoset] = col
    end
    function colorcube:OnUserChanged(col)
        legacy.cvars.colors[valtoset] = col
    end
    colorcube:SetVisible(false)
    colorpicker:SetVisible(false)
    local clrpickerbutton = vgui.Create( "DButton", parent ) // Create the button and parent it to the frame
    clrpickerbutton:SetText( "" )					// Set the text on the button
    clrpickerbutton:SetPos( x, y )					// Set the position on the frame
    clrpickerbutton:SetSize( 25, 12 )					// Set the size
    clrpickerbutton.DoClick = function()				// A custom function run when clicked ( note the . instead of : )

        if(colorcube:IsVisible()) then 
        colorcube:SetVisible(false)
        colorpicker:SetVisible(false)
        else
        colorcube:SetVisible(true)
        colorpicker:SetVisible(true)
        end
    end
    clrpickerbutton.Paint = function(self,w,h)
        surface.SetDrawColor(legacy.cvars.colors[valtoset])
        surface.DrawRect(0, 0, w, h)
        surface.SetDrawColor(Color(0,0,0))
        surface.DrawOutlinedRect(0, 0, w, h)
    end
end

local function AddLabel(txt,x,y,par)
    local DLabel = vgui.Create( "DLabel", par )
    DLabel:SetPos( x, y )
    DLabel:SetText( txt )
    DLabel:SetColor(Color(0,0,0)) -- set color
    DLabel:SetAutoStretchVertical(true) -- stop this shit from goi..
end

local function AddImportantLabel(txt,x,y,par)
    local DLabel = vgui.Create( "DLabel", par )
    DLabel:SetPos( x, y )
    DLabel:SetText( txt )
    DLabel:SetColor(Color(0,0,0)) -- set color
    DLabel:SetAutoStretchVertical(true) -- stop this shit from goi..
    DLabel:SetFont('Trebuchet18')
end

local function AddButton(txt,x,y,sizex,sizey,parrent,func)
    local DermaButton = vgui.Create( "DButton", parrent ) // Create the button and parent it to the frame
    DermaButton:SetText( txt )					// Set the text on the button
    DermaButton:SetPos( x, y )					// Set the position on the frame
    DermaButton:SetSize( sizex, sizey )					// Set the size
    DermaButton.DoClick = func
end

local function AddDropbox(pnl,x,y,cmd,choices)
    local DComboBox = vgui.Create( "DComboBox", pnl )
    DComboBox:SetPos( x, y )

    local maxlen = 0
    for k,v in ipairs(choices) do 
          if(isstring(v)) then 
            if(string.len(v) > maxlen) then 
                maxlen = string.len(v)
            end
         end
    end

    local sizex = maxlen * 10

    if(sizex > 150) then 
    sizex = sizex / 1.5
    end

    sizex = sizex + 2

    DComboBox:SetSize( sizex, 20 )

    for k,v in ipairs(choices) do 
        DComboBox:AddChoice(v)
    end

    DComboBox:ChooseOption(GetConVar(cmd):GetString(),1)

    DComboBox.OnSelect = function( self, index, value )
        RunConsoleCommand(cmd, value)
    end

end 

local function NumberWang(pnl,x,y,min,max,cvar)
    local DNumberWang = vgui.Create( "DNumberWang", pnl )
    DNumberWang:SetPos( x, y )
    DNumberWang:SetSize( 40, 15 )
    DNumberWang:SetMin(min)
    DNumberWang:SetMax(max)
    DNumberWang:SetText("")
    DNumberWang:SetValue(GetConVar(cvar):GetInt())
    DNumberWang:SetConVar(cvar)
end

local opt =  {
    // {1,"TEST",1,"test.",5,"r","lua_log_sv"},
    // {1,"TEST2",1,"test2.",5,"l","lua_log_sv"},
    // {2,"TEST2",1,"test2.",15,"l","lua_networkvar_bytespertick", 0, 20, 0},
    // {4, "TEST I LBL", 45, "r", 1},
    // {3, "TEST LBL", 45, "l", 1},
    // {5, 65, 1, "lua_networkvar_bytespertick", "r",0,5},
    // {7,1,95,"Test Button", 75,15,function() MsgN("hello") end},
    // {6, 1, 95, "lua_error_url", {"test","test2"}, "r"},
    // {8, 1, 95, "r", "Test ToolTip", "lua_error_url"},
    // {9,1,95,"l",1},

    //ragebot
    {1,"aimbot:",1,"allows you to hit p",5,"L","legacy_aimbot"},
    {8, 1, 25, "L", "aimkey", "legacy_aimkey"},


    //misc
    {1,"Bhop",4,"allows you to hold the space bar to bhop",5,"L","legacy_bunnyhop"},
    {6, 4, 25, "legacy_autoStrafe_type", {"off","normal","directional"}, "L"},
    {2,"CircleStrafe speed:",4,"the speed that it turns when circle strafing (will affect radius)",40,"l","legacy_circleStrafe_speed", 1, 100, 0},


}

surface.CreateFont("AzonixR", { -- Create the font for our menu title
    font = "Azonix", -- Use the font name not the file name (Azonix instead of AzonixNormal.tft)
	extended = false,
	size = 16,
	weight = 200,
})

local function createMenu()
    menumain.umenu = vgui.Create("DFrame");
    menumain.umenu:SetSize(500, 350); -- Size
    menumain.umenu:Center();
    menumain.umenu:ShowCloseButton(false);
    menumain.umenu:SetTitle("");
    menumain.umenu:MakePopup();

    menumain.umenu.Paint = function(self,w,h)
        draw.RoundedBox(2, 0, 0, 920, 700, Color(17, 17, 17)) -- Rounded cuz it looks nice?
    end 

    local DLabel = vgui.Create( "DLabel", menumain.umenu ) -- Title
    DLabel:SetPos( 217, 5 )
    DLabel:SetFont("AzonixR")
    DLabel:SetText( "Legacy" )
    DLabel:SizeToContents()
    DLabel:SetColor(Color(255,255,255)) -- Color
    DLabel:SetAutoStretchVertical(true) -- Stop it from not being tall enough
    
    local sheet = vgui.Create( "DColumnSheet", menumain.umenu ) -- Create the tabs
    sheet:Dock( FILL )
    sheet:SetFontInternal("AzonixR")
    sheet.Paint = function(self,w,h)
        draw.RoundedBox(2, 0, 0, 920, 700, Color(17, 17, 17))
    end

    local tabs = {
        "tab1panel",
        "tab2panel",
        "tab3panel",
        "tab4panel",
        "tab5panel",
    }

    for k,v in pairs(tabs) do 
        tabs[k] = vgui.Create( "DPanel" )
        tabs[k]:Dock(FILL)
        -- tabs[k].Paint = function() :C
        --     draw.RoundedBox(2, 0, 0, 920, 700, Color(17, 17, 17))
        --     surface.SetDrawColor(30, 30, 30)
        -- end
    end

    sheet:AddSheet( "Rage", tabs[1], "icon16/bomb.png",false,false )
    sheet:AddSheet( "Antiaim", tabs[2], "icon16/status_busy.png",false,false )
    sheet:AddSheet( "Visual", tabs[3], "icon16/eye.png",false,false )
    sheet:AddSheet( "Misc", tabs[4 ], "icon16/asterisk_orange.png",false,false )
    sheet:AddSheet( "Config", tabs[5], "icon16/cog.png",false,false)

    -- Actually creating the menu
    for k,v in pairs(opt) do 
        if(v[1] == 1) then 
            local dockside = 5
            if(v[6] == "r") then 
                dockside = 250
            end
            -- fyi args are: 
            -- dtype, parent, tooltip, text, cvar, x, y
            AddCheckBox("Checkbox", tabs[v[3]], v[4], v[2], v[7], dockside, v[5]);
        elseif(v[1] == 2) then 
            local dockside = -107
            if(v[6] == "r") then 
                dockside = 213
            end
            -- fyi args are : 
            -- dtype,text,pnl,tooltip,x,y,cvar,min,max,wide,dec
            AddSlider("Slider", v[2], tabs[v[3]], v[4], dockside, v[5], v[7], v[8], v[9], 250, v[10] )
        elseif(v[1] == 3) then 
            local dockside = 5
            if(v[4] == "r") then 
                dockside = 250
            end

            AddLabel(v[2],dockside,v[3],tabs[v[5]])
        elseif(v[1] == 4) then 
            local dockside = 5
            if(v[4] == "r") then 
                dockside = 250
            end

            AddImportantLabel(v[2],dockside,v[3],tabs[v[5]])
        elseif(v[1] == 5) then 
            local dockside = 5
            if(v[5] == "r") then 
                dockside = 250
            end

            NumberWang(tabs[v[3]],dockside,v[2],v[6],v[7],v[4])
        elseif(v[1] == 6) then 

            local dockside = 5
            if(v[6] == "r") then 
                dockside = 250
            end

            AddDropbox(tabs[v[2]],dockside,v[3],v[4],v[5])
        elseif(v[1] == 7) then 

            local dockside = 5
            if(v[6] == "r") then 
                dockside = 250
            end

            AddButton(v[4],dockside,v[3],v[5],v[6],tabs[v[2]],v[7])

        elseif(v[1] == 8) then 

            local dockside = 5
            if(v[4] == "r") then 
                dockside = 250
            end

            AddBinder(tabs[v[2]],dockside,v[3],100,20,v[5],v[6])

        elseif(v[1] == 9) then 

            local dockside = 5
            if(v[4] == "r") then 
                dockside = 250
            end

            AddColorSetting(tabs[v[2]],dockside,v[3],v[5])

        end
    end

end

createMenu()

local toggle = true 
hook.Add("Think", "toggleKey", function() -- I have no idea how I managed to make this ngl (I just went "OH" and then proceeded to not think about it until it was finished.)
    if input.IsKeyDown(KEY_INSERT) and not toggle then
        toggle = true
        menumain.umenu:SetVisible(not menumain.umenu:IsVisible())
        gui.EnableScreenClicker(menumain.umenu:IsVisible())
    elseif not input.IsKeyDown(KEY_INSERT) then
        toggle = false
    end
end)

-- features and hooks to call them and shit idk

legacy.features.Bhop = {}
legacy.features.AutoStrafe = {}
legacy.features.AimBot = {}

legacy.features.AimBot.find_target = function()
    legacy.features.AimBot.current_target = NULL
    for k,v in ipairs(player.GetAll()) do
        --check all players to see if they are a valid target once a target is found continue to check the rest to see if there is a better target
        if (v:Alive() && v:IsValid() && v != LocalPlayer()) then -- in the future make this if shootable with an auto wall function
            if (legacy.features.AimBot.current_target == NULL) then
                legacy.features.AimBot.current_target = v
            elseif (LocalPlayer():GetPos():Distance(v:GetPos()) < LocalPlayer():GetPos():Distance(legacy.features.AimBot.current_target:GetPos())) then -- in the future make this an option between health priority and maybe genarate a number based on multple things ( :
                legacy.features.AimBot.current_target = v
            end
        end
    end
    return (legacy.features.AimBot.current_target)
end

legacy.features.AimBot.aim_func = function(cmd)
    --time to hit p ( :
    --if (legacy.G.input.IsKeyDown(KEY_E) && GetConVar("legacy_aimbot"):GetBool()) then --GetConVar("legacy_aimkey"):GetInt()
        --print ("aimkey down")

        --if (legacy.features.AimBot.find_target() != NULL) then

            --local head = legacy.features.AimBot.current_target:LookupBone("ValveBiped.Bip01_Head1") --change to a choice of hitboxes and maybe a priority list of hitboxes
            --cmd:SetEyeAngles(legacy.features.AimBot.current_target:GetBonePosition(head) - cmd:GetViewAngles())
            --legacy.G.RunConsoleCommand("+attack") -- very very very very shit needs to be fixed
            --legacy.G.RunConsoleCommand("-attack")
        --end
    --end
end

legacy.features.Bhop.func = function()
    if (GetConVar("legacy_bunnyhop"):GetBool()) then
        if (LocalPlayer():IsOnGround() && legacy.G.input.IsKeyDown(KEY_SPACE)) then
            legacy.G.RunConsoleCommand("+jump")
            legacy.G.timer.Create("endhop", (1/500), 0, function() -- after 1 tick
                legacy.G.RunConsoleCommand("-jump") -- stops player from getting stuck on the ground if they die
                legacy.G.timer.Destroy("endhop")
            end)
        end
    end
end

legacy.features.AutoStrafe.switch = false
legacy.features.AutoStrafe.endtimer = false

legacy.features.AutoStrafe.func = function(cmd)
    if (GetConVar("legacy_autoStrafe_type"):GetString() == "directional") then -- auto strafes even if the player is not moving the mouse
        if (LocalPlayer():IsOnGround() == false) then
            if (legacy.features.AutoStrafe.switch) then
                cmd:SetViewAngles(cmd:GetViewAngles() + Angle(0,1,0)) -- strafe right
                cmd:SetSideMove(-10^4)
                legacy.features.AutoStrafe.switch = false
            else
                cmd:SetViewAngles(cmd:GetViewAngles() - Angle(0,1,0)) -- strafe left
                cmd:SetSideMove(10^4)
                legacy.features.AutoStrafe.switch = true
            end
            cmd:SetForwardMove( cmd:GetForwardMove() * 10000) -- move the player forward

            --add some sort of fix movement pls ( ;
        end

    elseif (GetConVar("legacy_autoStrafe_type"):GetString() == "normal") then -- just based on mouse movements
        if (LocalPlayer():IsOnGround() == false) then
            if (cmd:GetMouseX() < 0) then
                cmd:SetSideMove(-10^4)
            elseif (cmd:GetMouseX() > 0) then
                cmd:SetSideMove(10^4)
            end

            if (legacy.G.input.IsKeyDown(KEY_A)) then -- circle strafe time ( :
                --circle strafe to the left
                cmd:SetViewAngles(cmd:GetViewAngles() + Angle(0,(GetConVar("legacy_circleStrafe_speed"):GetInt()/100),0))
                cmd:SetSideMove(-10^4)

                --add some sort of fix movement pls ( ;

            elseif (legacy.G.input.IsKeyDown(KEY_D)) then
                --circle strafe to the right
                cmd:SetViewAngles(cmd:GetViewAngles() - Angle(0,(GetConVar("legacy_circleStrafe_speed"):GetInt()/100),0))
                cmd:SetSideMove(10^4)

                --add some sort of fix movement pls ( ;
            end
        end
    end
end

hook.Add("CreateMove", "createmove_features", function(cmd) 

    legacy.features.Bhop.func()
    legacy.features.AutoStrafe.func(cmd)
    
    --legacy.features.AimBot.aim_func(cmd)

end)