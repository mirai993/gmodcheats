--[[
	CS-147207507324224
	GreedyGoat1337™ | (STEAM_0:0:26567268)
	===BootyBucket===
]]

--[[
 _ _____ _ 
 (_) / ____| (_) 
 _ | (___ _ __ _ _ __ ___ _ _ 
 | | \___ \ | '_ \ | | | '_ \ / _ \ | | | |
 | | ____) | | | | | | | | |_) | | __/ | |_| |
 |_| |_____/ |_| |_| |_| | .__/ \___| \__,_|
 | | 
 |_| 
]]

if SERVER then return end
if hook or concommand then
MsgN("[iHack] Warning: This server has an anticheat.")
end

include ( "includes/compat.lua" )
include ( "includes/util.lua" )
include ( "includes/util/sql.lua" )
require ( "concommand" )
require ( "saverestore" )
require ( "gamemode" )
require ( "weapons" )
require ( "hook" )
require ( "timer" )
require ( "schedule" )
require ( "scripted_ents" )
require ( "player_manager" )
require ( "numpad" )
require ( "team" )
require ( "undo" )
require ( "cleanup" )
require ( "duplicator" )
require ( "constraint" )
require ( "construct" ) 
require ( "filex" )
require ( "vehicles" )
require ( "usermessage" )
require ( "list" )
require ( "cvars" )
require ( "http" )
require ( "datastream" )
require ( "draw" )
require ( "markup" )
require ( "effects" )
require ( "killicon" )
require ( "spawnmenu" )
require ( "controlpanel" )
require ( "presets" )
require ( "cookie" )
include( "includes/util/model_database.lua" )
include( "includes/util/vgui_showlayout.lua" )
include( "includes/util/tooltips.lua" ) 
include( "includes/util/client.lua" )
include( "gmsave.lua" )

local plymeta = FindMetaTable( "Player" )
local convarmeta = FindMetaTable( "ConVar" )
local entmeta = FindMetaTable( "Entity" )
local _CV = table.Copy( cvars )
local _SR = table.Copy( string )
local player = player
local ents = ents
local Color = Color
local Material = Material
local pcall = pcall
local math = math
local string = string
local debug = debug
local table = table
local pcall = pcall
local error = error
local ErrorNoHalt = ErrorNoHalt
local MsgN = MsgN
local Msg = Msg
local print = print
local surface = surface
local util = util
local type = type
local RunConsoleCommand = RunConsoleCommand
local CreateClientConVar = CreateClientConVar
local CreateConVar = CreateConVar
local pairs = pairs
local ipairs = ipairs
local SortedPairs = SortedPairs

local RandomStrings = {}
local Characters = {
"A","B","C","D","E","F","G","H","I","J",
"K","L","M","N","O","P","Q","R","S","T",
"U","V","W","X","Y","Z","1","2","3","4",
"5","6","7","8","9","_","-","=","+","(",
")","<",">","?","/","'",";","!","@","#",
"$","%","^","&","*","~","`","{","}","|"
}

local function RndString()
local str = ""
for i=1, math.random(6,12) do
str = str..Characters[math.random( 1, #Characters )]
end
if RandomStrings[str] then
return RndString()
else
RandomStrings[str] = true
return str
end
end

--[[
if file.Find("lua/includes/modules/gm_ih_cv2.dll") then
require("ih_cv2")
cvar2.SetValue( "sv_cheats", 1 )

concommand.Add( "iHack_FullBright", function()
if !FullBright then
cvar2.SetValue( "host_framerate", 1 )
MsgN("FullBright Enabled")
FullBright = true
else
cvar2.SetValue( "mat_fullbright", 0 )
MsgN("FullBright Disabled")
FullBright = false
end
end)

concommand.Add( "+ihack_speedhack", function()
cvar2.SetValue( "host_framerate", 7.5 )
Speed = true
end)

concommand.Add( "-ihack_speedhack", function()
cvar2.SetValue( "host_framerate", 0 )
Speed = false
end)

concommand.Add( "ihack_speedhack", function()
if !SpeedToggle then
cvar2.SetValue( "host_framerate", 7.5 )
SpeedToggle = true
else
cvar2.SetValue( "host_framerate", 0 )
SpeedToggle = false
end
end)
end
--]]

local Aimbot_IgnorePlayers = CreateClientConVar("_ihack_aimbot_ignoreplayers", 0 , true , false)
local Aimbot_IgnoreNPCs = CreateClientConVar("_ihack_aimbot_ignorenpcs", 0 , true , false)
local Aimbot_IgnoreSteamFriends = CreateClientConVar("_ihack_aimbot_ignorefriends", 0 , true , false)
local Aimbot_IgnoreAdmins = CreateClientConVar("_ihack_aimbot_ignoreadmins", 0 , true , false)
local Aimbot_FriendlyFire = CreateClientConVar("_ihack_aimbot_friendlyfire", 0 , true , false )
local Aimbot_NoSpread = CreateClientConVar("_ihack_aimbot_nospread", 0, true , false)
local Aimbot_AutoShoot = CreateClientConVar("_ihack_aimbot_auto", 0, true , false)
local Aimbot_FakeView = CreateClientConVar("_ihack_aimbot_fakeview", 0, true , false)

local ESP_Enabled = CreateClientConVar("_ihack_esp", 0 , true , false)
local ESP_NPCs = CreateClientConVar("_ihack_esp_npcs", 0 , true , false)
local ESP_Players = CreateClientConVar("_ihack_esp_players", 0 , true , false)
local ESP_Weapons = CreateClientConVar("_ihack_esp_weapons", 0 , true , false)
local ESP_Charms = CreateClientConVar("_ihack_esp_charms", 0 , true , false)

local TTT_ShowBodys = CreateClientConVar("_ihack_ttt_showbodys", 0, true , false)
local TTT_IgnoreFellowTraitors = CreateClientConVar("_ihack_ttt_ignorefellowtraitors", 0, true , false)
local TTT_IgnoreFellowDetectives = CreateClientConVar("_ihack_ttt_ignorefellowdetectives", 0, true , false)

local Misc_FOV = CreateClientConVar("_ihack_misc_fov", 0, true , false)
local Misc_AlwaysNoSpread = CreateClientConVar("_ihack_misc_alwaysnospread", 0, true , false)

local CustomMsg = false
local NoSpreadHere = false

local CustomCones = {
["#HL2_SMG1"] = Vector( -0.04362, -0.04362, -0.04362 ),
["#HL2_Pistol"] = Vector( -0.0100, -0.0100, -0.0100 ),
["#HL2_Pulse_Rifle"] = Vector( -0.02618, -0.02618, -0.02618 ),
["#HL2_Shotgun"] = Vector( -0.08716, -0.08716, -0.08716 )
}

if file.Find("lua/includes/modules/gmcl_ih_ns.dll") then
NoSpreadHere = true

local tblNormalConeWepBases = {
["weapon_cs_base"] = true
}

local function GetCone(wep)
local cone = wep.Cone
if not cone and type(wep.Primary) == "table" and type(wep.Primary.Cone) == "number" then
cone = wep.Primary.Cone
end
if not cone then cone = 0 end
if type(wep.Base) == "string" and tblNormalConeWepBases[wep.Base] then return cone end
if wep:GetClass() == "ose_turretcontroller" then return 0 end
return cone or 0
end

if !NoSpreadLoaded then
require("ih_ns")
NoSpreadLoaded = true
end

local nospread = hl2_shotmanip
local prediction = hl2_ucmd_getprediciton
_G.hl2_shotmanip = nil
_G.hl2_ucmd_getprediciton = nil
local currentseed, cmd2, seed = currentseed or 0, 0, 0
local wep, vecCone, valCone

function PredictSpread( cmd, aimAngle )
if !prediction then return aimAngle end
local cmd2, seed = prediction( cmd )
local currentseed = 0, 0, 0
if ( cmd2 != 0 ) then currentseed = seed end
local wep = LocalPlayer():GetActiveWeapon()
local vecCone, valCone = Vector( 0, 0, 0 )
if ( ValidEntity( wep ) ) then
if ( wep.Initialize or ( wep.Base and wep.Base == "weapon_perp_base")) then
valCone = wep.Primary and wep.Primary.Cone or 0
if( tonumber( valCone ) ) then
vecCone = Vector( -valCone, -valCone, -valCone )
elseif( type( valCone ) == "Vector" ) then
vecCone = -1 * valCone
end
else
local pn = wep:GetPrintName()
if ( CustomCones[pn] ) then vecCone = CustomCones[pn] end
end
end
return nospread( currentseed or 0, ( aimAngle or LocalPlayer():GetAimVector():Angle() ):Forward(), vecCone ):Angle()
end
end

function Visible( Victim )
trace1 = {}
trace1.start = LocalPlayer():GetShootPos()
trace1.endpos = Victim:GetBonePosition( Victim:LookupBone( "ValveBiped.Bip01_Head1" ) )
trace1.mask = MASK_SHOT
trace1.filter = {Victim , LocalPlayer()}
Main1 = util.TraceLine(trace1)
if !Main1.Hit then return true end
end

local deathSequences = {
["models/barnacle.mdl"] = { 4, 15 },
["models/antlion_guard.mdl"] = { 44 },
["models/hunter.mdl"] = { 124, 125, 126, 127, 128 }
}

function Valid( Victim )
if ( Victim:IsPlayer() ) then
if ( !ValidEntity( Victim ) or LocalPlayer() == Victim ) then return false end
if ( GAMEMODE.Name ) == "Trouble in Terrorist Town" then
if ( TTT_IgnoreFellowTraitors:GetBool() and Victim:IsTraitor() and LocalPlayer():IsTraitor() ) then return false end
if ( TTT_IgnoreFellowDetectives:GetBool() and Victim:IsDetective() and LocalPlayer():IsDetective() ) then return false end
end
if ( Aimbot_IgnorePlayers:GetBool() ) then return false end
if ( Victim:Team() == TEAM_SPECTATOR or Victim:Team() == TEAM_SPEC ) then return false end
if ( !Victim:Alive() or Victim:Health() <= 0 ) then return false end
if ( Victim:Team() == LocalPlayer():Team() and GetConVarNumber("_ihack_aimbot_Friendlyfire") != 1 ) then return false end
if ( Aimbot_IgnoreSteamFriends:GetBool() and Victim:GetFriendStatus() == "friend" ) then return false end
if ( Aimbot_IgnoreAdmins:GetBool() and Victim:IsAdmin() ) then return false end
if ( Victim:InVehicle() ) then return false end
elseif ( Victim:IsNPC() ) then
if ( !ValidEntity( Victim ) ) then return false end
if ( Aimbot_IgnoreNPCs:GetBool() ) then return false end
local model = string.lower( Victim:GetModel() or "" )
if ( table.HasValue( deathSequences[ model ] or {}, Victim:GetSequence() ) ) then return false end
if ( Victim:GetMoveType() == MOVETYPE_NONE ) then return false end
if ( Victim:GetClass() == "npc_turret_floor" ) then return false end
if ( Victim:GetClass() == "npc_dog" ) then return false end
end
return true
end

function GetTarget()
local target2 = { 0, 0 }
for k, v in ipairs( ents.GetAll() ) do
if v:IsPlayer() or v:IsNPC() then
if Visible(v) and Valid(v) then
local targetpos = ( v:EyePos() - LocalPlayer():EyePos() ):Normalize()
targetpos = targetpos - LocalPlayer():GetAimVector()
targetpos = targetpos:Length()
targetpos = math.abs( targetpos )
if targetpos < target2[2] or target2[1] == 0 then
target2 = {v, targetpos}
end
end
end
end
return target2[1]
end

local Bones = {
["models/zombie/classic.mdl"] = "ValveBiped.HC_Body_Bone",
["models/zombie/classic.mdl"] = "ValveBiped.HC_Body_Bone",
["models/zombie/classic_torso.mdl"] = "ValveBiped.HC_Body_Bone",
["models/zombie/fast.mdl"] = "ValveBiped.HC_BodyCube",
["models/zombie/fast_torso.mdl"] = "ValveBiped.HC_BodyCube",
["models/zombie/poison.mdl"] = "ValveBiped.Bip01_Spine4",
["models/zombie/zombie_soldier.mdl"] = "ValveBiped.HC_Body_Bone",
["models/vortigaunt_slave.mdl"] = "ValveBiped.Head",
["models/vortigaunt.mdl"] = "ValveBiped.Head",
["models/lamarr.mdl"] = "HeadcrabClassic.SpineControl",
["models/headcrab.mdl"] = "HCFast.body",
["models/headcrabblack.mdl"] = "HCBlack.body",
["models/headcrabclassic.mdl"] = "HeadcrabClassic.SpineControl",
["models/headcrabblack.mdl"] = "HCBlack.body",
["models/antlion.mdl"] = "Antlion.Body_Bone",
["models/antlion_guard.mdl"] = "Antlion_Guard.Body",
["models/antlion_worker.mdl"] = "Antlion.Head_Bone"
}

function ChooseBone()
local Victim = GetTarget()
if ( Victim != 0 and ( Victim:IsNPC() or Victim:IsPlayer() ) ) then
if ( Bones[Victim:GetModel()] ) then
return Bones[Victim:GetModel()] 
end
return "ValveBiped.Bip01_Head1" 
end
end

local FakeView = Angle(0,0,0)
local aim = aim
local aimtar = aimtar

hook.Add( "CreateMove", RndString() .. "", function( ucmd )
if !LocalPlayer() then return end
local MouseFixUp = Angle( ucmd:GetMouseY() * GetConVarNumber("m_pitch"), ucmd:GetMouseX() * -GetConVarNumber("m_yaw") ) or Angle(0,0,0)
FakeView = FakeView + MouseFixUp
iHackViewAngle = FakeView
if NoSpreadHere and ( ucmd:GetButtons() & IN_ATTACK > 0 ) and Misc_AlwaysNoSpread:GetBool() then
iHackAngleNSConstant = PredictSpread( ucmd, FakeView )
iHackAngleNSConstant.p = math.NormalizeAngle( iHackAngleNSConstant.p )
iHackAngleNSConstant.y = math.NormalizeAngle( iHackAngleNSConstant.y )
if aimtar == nil then ucmd:SetViewAngles( iHackAngleNSConstant ) end
elseif Aimbot_FakeView:GetBool() then
FakeView.p = math.NormalizeAngle( FakeView.p )
FakeView.y = math.NormalizeAngle( FakeView.y )
if aimtar == nil then ucmd:SetViewAngles( FakeView ) end
end
if aim then
local victim = GetTarget()
if victim == 0 or victim == LocalPlayer() then aimtar = nil return end
local view = victim:GetBonePosition( victim:LookupBone( "" .. ChooseBone() .. "" ))
if view then
view = view + victim:GetVelocity() / 45 - LocalPlayer():GetVelocity() / 45
iHackAngle = ( view - LocalPlayer():GetShootPos() ):Angle()
if NoSpreadHere and Aimbot_NoSpread:GetBool() then
iHackAngle = PredictSpread( ucmd, iHackAngle )
end
iHackAngle.p = math.NormalizeAngle( iHackAngle.p )
iHackAngle.y = math.NormalizeAngle( iHackAngle.y ) 
iHackAngle.r = 0
ucmd:SetViewAngles( iHackAngle )
end
if Aimbot_FakeView:GetBool() then
local move = Vector(ucmd:GetForwardMove(), ucmd:GetSideMove(), 0)
local norm = (move):GetNormal()
local set = ((norm:Angle() + (LocalPlayer():EyeAngles() - FakeView)):Forward()) * move:Length()
ucmd:SetForwardMove(set.x)
ucmd:SetSideMove(set.y)
else
iHackViewAngle = iHackAngle
end
if victim:IsPlayer() then
aimtar = victim:Nick()
else
aimtar = victim:GetClass()
end
end
end)
concommand.Add( "+ihack_aimbot", function() aim = true end)
concommand.Add( "-ihack_aimbot", function() aim = false aimtar = nil RunConsoleCommand("-attack") end)

hook.Add( "CalcView", RndString() .. "", function( ply, pos, angles, fov )
local view = {}
view.origin = pos
if !Aimbot_FakeView:GetBool() and !Misc_AlwaysNoSpread:GetBool() then
view.angles = angles
else
view.angles = iHackViewAngle
end
if Misc_FOV:GetBool() then
view.fov = Misc_FOV:GetInt()
end
return view
end)

hook.Add( "PostGamemodeLoaded", RndString() .. "", function()
surface.CreateFont( "coolvetica", 12, 800, true, false, "iHack_Font" )

hook.Add( "PostDrawOpaqueRenderables", RndString() .. "", function()
local ply = LocalPlayer()
local vm = ply:GetViewModel()
if ply and vm then
local firstpos = ply:GetAttachment(ply:LookupAttachment("eyes")) 
local secondpos = ply:GetEyeTrace().HitPos
if firstpos and aimtar != nil then
cam.Start3D(EyePos(), EyeAngles())
render.SetMaterial(Material("sprites/bluelaser1"))
render.DrawBeam(firstpos.Pos, secondpos, 12, 0, 0, Color( 50, 205, 50 ))
cam.End3D()
end
end
end)

hook.Add( "RenderScreenspaceEffects", RndString() .. "", function()
for k,v in pairs(ents.GetAll()) do
if ( ESP_Charms:GetBool() and v:IsValid() ) then
if ((v:IsPlayer() and v:Alive() and v:Team() != TEAM_SPECTATOR and v:Team() != TEAM_SPEC) or (v:IsNPC() and v:GetMoveType() != MOVETYPE_NONE and v:GetClass() != "npc_combine_camera") ) then
cam.Start3D(EyePos(), EyeAngles())
cam.IgnoreZ(true)
render.SuppressEngineLighting( true )
entmeta.SetMaterial(v, "ihack")
render.SetColorModulation( 0, 0, 1 )
v:DrawModel()
render.SetColorModulation( 1, 1, 1 )
entmeta.SetMaterial(v, v:GetMaterial())
render.SuppressEngineLighting( false )
cam.IgnoreZ(false)
cam.End3D()
end
if ( (v:IsWeapon() and v:GetMoveType() == 0 ) or ( GAMEMODE.Name == "Trouble in Terrorist Town" and v:GetClass() == "prop_ragdoll" and CORPSE.GetPlayerNick(v, false) != false) ) then
cam.Start3D( EyePos() , EyeAngles() )
cam.IgnoreZ(true)
render.SuppressEngineLighting( true )
entmeta.SetMaterial(v, "ihack")
render.SetColorModulation( 0, 1, 0 )
v:DrawModel()
render.SetColorModulation( 1, 1, 1 )
entmeta.SetMaterial(v, v:GetMaterial())
render.SuppressEngineLighting( false )
cam.IgnoreZ(false)
cam.End3D()
end
end
end
end)

hook.Add( "HUDPaint", RndString() .. "", function()
if aim and aimtar == nil then
draw.SimpleTextOutlined( "Scanning...", "TargetIDSmall", ScrW() / 2, ScrH() / 2 + 25, Color( 255, 0, 0, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, .5, Color( 30, 30, 30, 165 ) )
elseif aim and aimtar != nil then
draw.SimpleTextOutlined( "Locked! ( " .. aimtar .. " )", "TargetIDSmall", ScrW() / 2, ScrH() / 2 + 25, Color( 25, 255, 25, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, .5, Color( 30, 30, 30, 165 ) )
end
for k,v in pairs(ents.GetAll()) do
if ValidEntity( v ) then
if v:IsWeapon() and v:GetMoveType() != 0 and ESP_Weapons:GetBool() then
WeaponPos = v:EyePos():ToScreen()
WeaponName = v:GetPrintName()
WeaponName = string.gsub( WeaponName, "#HL2_", "" )
WeaponName = string.gsub( WeaponName, "#GMOD_", "" )
WeaponName = string.gsub( WeaponName, "_name", "" )
WeaponName = string.gsub( WeaponName, "grenade_", "" )
draw.SimpleTextOutlined( WeaponName, "iHack_Font", WeaponPos.x, WeaponPos.y, Color( 255, 0, 0, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, Color( 30, 30, 30, 165 ) )
end
local model = string.lower( v:GetModel() or "" )
if (v:IsNPC() and v:GetMoveType() != MOVETYPE_NONE and ESP_NPCs:GetBool()) then
if !(table.HasValue( deathSequences[ model ] or {}, v:GetSequence() )) then
NPCPos = v:EyePos():ToScreen()
NPCName = v:GetClass()
NPCName = string.gsub( NPCName, "npc_", "" )
NPCName = string.gsub( NPCName, "monster_", "" )
draw.SimpleTextOutlined( NPCName, "iHack_Font", NPCPos.x, NPCPos.y, Color( 255, 30, 40 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, Color( 30, 30, 30, 165 ) )
end
end
if (v:IsPlayer() and v != LocalPlayer() and v:Alive() and ESP_Players:GetBool()) then
PlayerPos = v:EyePos():ToScreen()
if GAMEMODE.Name == "Trouble in Terrorist Town" then
if v:GetNWBool("disguised", false) then
draw.SimpleTextOutlined( "" .. v:Nick() .. " (Disquised)", "iHack_Font", PlayerPos.x, PlayerPos.y - 10, Color( 50, 205, 50 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, Color( 30, 30, 30, 165 ) )
else
draw.SimpleTextOutlined( v:Nick(), "iHack_Font", PlayerPos.x, PlayerPos.y - 10, Color( 50, 205, 50 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, Color( 30, 30, 30, 165 ) )
end
if v:IsDetective() then
draw.SimpleTextOutlined( "Detective", "iHack_Font", PlayerPos.x, PlayerPos.y, Color( 50, 50, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, Color( 30, 30, 30, 165 ) )
end
else
draw.SimpleTextOutlined( v:Nick(), "iHack_Font", PlayerPos.x, PlayerPos.y - 10, Color( 50, 205, 50 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, Color( 30, 30, 30, 165 ) )
end
end
if (GAMEMODE.Name == "Trouble in Terrorist Town" and v:GetClass() == "prop_ragdoll" and CORPSE.GetPlayerNick(v, false) != false and TTT_ShowBodys:GetBool()) then
if CORPSE.GetFound(v, false) or !DetectiveMode() then
text = CORPSE.GetPlayerNick(v, "A Terrorist")
else
text = "" .. CORPSE.GetPlayerNick(v, "A Terrorist") .. " (Unidentified)"
end
BodyPos = v:EyePos():ToScreen()
draw.SimpleTextOutlined( text, "iHack_Font", BodyPos.x+1, BodyPos.y+1, Color( 255, 30, 40 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, .4, Color( 30, 30, 30, 165 ) )
end
end
end
end)
end)

hook.Add("Think", RndString() .. "", function()
if Aimbot_AutoShoot:GetBool() then
if aim and aimtar == nil then
RunConsoleCommand( "-attack" )
end
if aimtar != nil then
if !Firing then
RunConsoleCommand( "+attack" )
Firing = true
else
RunConsoleCommand( "-attack" ) 
Firing = false
end
end
end
end)

hook.Add("Think", "bhop", function()
if bhop then
if LocalPlayer():OnGround() then
RunConsoleCommand("+jump")
timer.Simple( 0.1, function() 
RunConsoleCommand("-jump") 
end)
end
end
end)
concommand.Add( "+ihack_bhop", function() bhop = true end)
concommand.Add( "-ihack_bhop", function() bhop = false end)

function OpenTheMenu()
BaseiHackMenu = vgui.Create( "DFrame" )
BaseiHackMenu:SetPos( ScrW() / 2 - 200 , ScrH() / 2 - 175 )
BaseiHackMenu:SetSize( 400 , 350 )
BaseiHackMenu:SetTitle( "iHack Menu" )
BaseiHackMenu:SetVisible( true )
BaseiHackMenu:SetDraggable( true )
BaseiHackMenu:ShowCloseButton( true )
BaseiHackMenu:MakePopup()

local iHackMenu = vgui.Create( "DPropertySheet" )
iHackMenu:SetParent( BaseiHackMenu )
iHackMenu:SetPos( 5 , 25 )
iHackMenu:SetSize( 390 , 320 )

local ESPBox1 = vgui.Create( "DCheckBoxLabel")
ESPBox1:SetParent( iHackMenu )
ESPBox1:SetText( "ESP NPCs" )
ESPBox1:SetConVar( "_iHack_ESP_NPCs" ) 
ESPBox1:SetPos( 20 , 20 )
ESPBox1:SetValue( GetConVarNumber( "_iHack_ESP_NPCs" ) )
ESPBox1:SetTextColor( Color( 0 , 0 , 0 , 255 ) )
ESPBox1:SizeToContents()

local ESPBox2 = vgui.Create( "DCheckBoxLabel")
ESPBox2:SetParent( iHackMenu )
ESPBox2:SetText( "ESP Players" )
ESPBox2:SetConVar( "_iHack_ESP_Players" ) 
ESPBox2:SetPos( 20 , 40 )
ESPBox2:SetValue( GetConVarNumber( "_iHack_ESP_Players" ) )
ESPBox2:SetTextColor( Color( 0 , 0 , 0 , 255 ) )
ESPBox2:SizeToContents()

local ESPBox3 = vgui.Create( "DCheckBoxLabel")
ESPBox3:SetParent( iHackMenu )
ESPBox3:SetText( "ESP Weapons" )
ESPBox3:SetConVar( "_iHack_ESP_Weapons" ) 
ESPBox3:SetPos( 20 , 60 )
ESPBox3:SetValue( GetConVarNumber( "_iHack_ESP_Weapons" ) )
ESPBox3:SetTextColor( Color( 0 , 0 , 0 , 255 ) )
ESPBox3:SizeToContents()

local ESPBox4 = vgui.Create( "DCheckBoxLabel")
ESPBox4:SetParent( iHackMenu )
ESPBox4:SetText( "ESP Charms" )
ESPBox4:SetConVar( "_iHack_ESP_Charms" ) 
ESPBox4:SetPos( 20 , 80 )
ESPBox4:SetValue( GetConVarNumber( "_iHack_ESP_Charms" ) )
ESPBox4:SetTextColor( Color( 0 , 0 , 0 , 255 ) )
ESPBox4:SizeToContents()

local ESPBox5 = vgui.Create( "DCheckBoxLabel")
ESPBox5:SetParent( iHackMenu )
ESPBox5:SetText( "ESP Show TTT Bodys" )
ESPBox5:SetConVar( "_iHack_TTT_ShowBodys" ) 
ESPBox5:SetPos( 20 , 100 )
ESPBox5:SetValue( GetConVarNumber( "_iHack_TTT_ShowBodys" ) )
ESPBox5:SetTextColor( Color( 0 , 0 , 0 , 255 ) )
ESPBox5:SizeToContents()

if NoSpreadHere then 
local NSBox = vgui.Create( "DCheckBoxLabel")
NSBox:SetParent( iHackMenu )
NSBox:SetText( "Misc Always No Spread" )
NSBox:SetConVar( "_iHack_Misc_AlwaysNoSpread" ) 
NSBox:SetPos( 20 , 140 )
NSBox:SetValue( GetConVarNumber( "_iHack_Misc_AlwaysNoSpread" ) )
NSBox:SetTextColor( Color( 0 , 0 , 0 , 255 ) )
NSBox:SizeToContents()
end

local FOVSlider = vgui.Create( "DNumSlider")
FOVSlider:SetParent( iHackMenu )
FOVSlider:SetText( "Field Of Fov" )
FOVSlider:SetWide( 150 )
FOVSlider:SetMin( 0 )
FOVSlider:SetMax( 160 )
FOVSlider:SetDecimals( 0 )
FOVSlider:SetPos( 220 , 10 )
FOVSlider:SetConVar( "_iHack_Misc_FOV" )

local AimbotBox1 = vgui.Create( "DCheckBoxLabel")
AimbotBox1:SetParent( iHackMenu )
AimbotBox1:SetText( "Aimbot Ignore Players" )
AimbotBox1:SetConVar( "_ihack_aimbot_IgnorePlayers" ) 
AimbotBox1:SetPos( 220 , 60 )
AimbotBox1:SetValue( GetConVarNumber( "_ihack_aimbot_IgnorePlayers" ) )
AimbotBox1:SetTextColor( Color( 0 , 0 , 0 , 255 ) )
AimbotBox1:SizeToContents() 

local AimbotBox2 = vgui.Create( "DCheckBoxLabel")
AimbotBox2:SetParent( iHackMenu )
AimbotBox2:SetText( "Aimbot Ignore NPCs" )
AimbotBox2:SetConVar( "_ihack_aimbot_IgnoreNPCs" ) 
AimbotBox2:SetPos( 220 , 80 )
AimbotBox2:SetValue( GetConVarNumber( "_ihack_aimbot_IgnoreNPCs" ) )
AimbotBox2:SetTextColor( Color( 0 , 0 , 0 , 255 ) )
AimbotBox2:SizeToContents() 

local AimbotBox3 = vgui.Create( "DCheckBoxLabel")
AimbotBox3:SetParent( iHackMenu )
AimbotBox3:SetText( "Aimbot Ignore Friends" )
AimbotBox3:SetConVar( "_ihack_aimbot_IgnoreFriends" ) 
AimbotBox3:SetPos( 220 , 100 )
AimbotBox3:SetValue( GetConVarNumber( "_ihack_aimbot_IgnoreFriends" ) )
AimbotBox3:SetTextColor( Color( 0 , 0 , 0 , 255 ) )
AimbotBox3:SizeToContents()

local AimbotBox4 = vgui.Create( "DCheckBoxLabel")
AimbotBox4:SetParent( iHackMenu )
AimbotBox4:SetText( "Aimbot Ignore Admins" )
AimbotBox4:SetConVar( "_ihack_aimbot_ignoreadmins" ) 
AimbotBox4:SetPos( 220 , 120 )
AimbotBox4:SetValue( GetConVarNumber( "_ihack_aimbot_ignoreadmins" ) )
AimbotBox4:SetTextColor( Color( 0 , 0 , 0 , 255 ) )
AimbotBox4:SizeToContents()

local AimbotBox5 = vgui.Create( "DCheckBoxLabel")
AimbotBox5:SetParent( iHackMenu )
AimbotBox5:SetText( "Aimbot FriendlyFire" )
AimbotBox5:SetConVar( "_ihack_aimbot_friendlyfire" ) 
AimbotBox5:SetPos( 220 , 140 )
AimbotBox5:SetValue( GetConVarNumber( "_ihack_aimbot_friendlyfire" ) )
AimbotBox5:SetTextColor( Color( 0 , 0 , 0 , 255 ) )
AimbotBox5:SizeToContents()

local AimbotBox6 = vgui.Create( "DCheckBoxLabel")
AimbotBox6:SetParent( iHackMenu )
AimbotBox6:SetText( "Aimbot Auto Shoot" )
AimbotBox6:SetConVar( "_ihack_aimbot_auto" ) 
AimbotBox6:SetPos( 220 , 160 )
AimbotBox6:SetValue( GetConVarNumber( "_ihack_aimbot_auto" ) )
AimbotBox6:SetTextColor( Color( 0 , 0 , 0 , 255 ) )
AimbotBox6:SizeToContents()

local AimbotBox7 = vgui.Create( "DCheckBoxLabel")
AimbotBox7:SetParent( iHackMenu )
AimbotBox7:SetText( "Aimbot Fake View" )
AimbotBox7:SetConVar( "_ihack_aimbot_fakeview" ) 
AimbotBox7:SetPos( 220 , 180 )
AimbotBox7:SetValue( GetConVarNumber( "_ihack_aimbot_fakeview" ) )
AimbotBox7:SetTextColor( Color( 0 , 0 , 0 , 255 ) )
AimbotBox7:SizeToContents()

if NoSpreadHere then
local AimbotBox = vgui.Create( "DCheckBoxLabel")
AimbotBox:SetParent( iHackMenu )
AimbotBox:SetText( "Aimbot No Spread" )
AimbotBox:SetConVar( "_ihack_aimbot_nospread" ) 
AimbotBox:SetPos( 220 , 200 )
AimbotBox:SetValue( GetConVarNumber( "_ihack_aimbot_nospread" ) )
AimbotBox:SetTextColor( Color( 0 , 0 , 0 , 255 ) )
AimbotBox:SizeToContents()
end

end
concommand.Add( "ihack_menu", OpenTheMenu )

concommand.Add( "ihack_customstatus", function()
MsgN("Server: "..GetHostName().. "")
MsgN("Map: " ..game.GetMap().. "")
MsgN("Gamemode: "..GAMEMODE.Name.."\n")
MsgN("Date: " ..tostring(os.date("%m/%d/%y")).. "")
MsgN("Time: " ..tostring(os.date("%I:%M %p")).. "\n")
for k,v in pairs(player.GetAll()) do
MsgN("Name: "..v:Nick().."")
MsgN("SteamID: "..v:SteamID().."")
MsgN("UserGroup: "..v:GetNWString("UserGroup").."")
MsgN("Ping: "..v:Ping().."\n")
end
end)

concommand.Add( "ihack_allents", function()
for k,v in pairs(ents.GetAll()) do
print(v:GetClass())
end
end)

concommand.Add( "ihack_allhooks", function()
PrintTable(hook.GetTable())
end)

concommand.Add( "ihack_lua_scriptrun", function(ply, cmd, args)
include(args)
end)

concommand.Add( "ihack_lua_stringrun", function(ply, cmd, args)
RunString(table.concat(args, " "))
end)

local RCCWhitelist = {
"gm_giveswep",
"gm_spawn",
"gm_spawnswep",
"gm_spawnvehicle",
"gm_showteam",
"gm_spawnsent",
"gmod_spawnnpc",
"gmod_physiterations",
"gmod_admin_cleanup",
"gmod_cleanup",
"gmod_undonum",
"gmod_npc_weapon",
"rep_sbox_godmode",
"rep_sbox_noclip",
"rep_sbox_weapons",
"rep_sv_voiceenable",
"egp_scrwh",
"inv_buy",
"urestrict",
"adv_duplicator_height",
"adv_duplicator_angle",
"adv_duplicator_pastefrozen",
"adv_duplicator_pastewoconst",
"adv_duplicator_LimitedGhost",
"adv_duplicator_worldOrigin",
"adv_duplicator_worldAngles",
"ev_setchatstate",
"sbox_noclip",
"sbox_weapons",
"sbox_godmode",
"sbox_plpldamage",
"ttt_spectate",
"myinfo_bytes",
"ttt_mute_team_check",
"_ttt_request_serverlang",
"isnipeu_fov",
"isnipeu_auto",
"ttt_equipswitch",
"wepswitch",
"ulx_vote",
"r_cleardecals",
"ttt_call_detective",
"ttt_cl_traitorpopup",
"ttt_cl_traitorpopup_close",
"ttt_order_equipment",
"ttt_cl_idlepopup",
"ttt_spectator_mode",
"ttt_resend_bought",
"ttt_quickslot",
"ttt_radar_scan",
"ttt_dropammo",
"ttt_dropweapon",
"ttt_spec_use",
"ttt_mute_team",
"ttt_radio",
"_ttt_radio_send",
"lastinv",
"use",
"_deathrec",
"ks_buyitem",
"ks_vipselect",
"sv_gravity",
"phys_timescale",
"xgui",
"ulx",
"_u",
"cl_playermodel",
"cl_detaildist",
"cl_drawthrusterseffects",
"cl_drawhoverballs",
"cl_drawcameras",
"cl_showhints",
"ttt_c4_config",
"ttt_c4_pickup",
"seensplash",
"playx_spawn",
"playx_use_jw",
"playx_force_low_framerate",
"playx_ignore_length",
"playx_uri",
"playx_open",
"ordershipment",
"changeteam",
"changeclass",
"spec_next",
"spec_prev",
"r_decals",
"r_lod",
"r_shadows",
"r_drawdetailprops",
"fog_override",
"fog_start",
"fog_startskybox",
"fog_end",
"fog_endskybox",
"fog_color_r",
"fog_color_g",
"fog_color_b",
"physgun_drawbeams",
"ai_disabled",
"ai_keepragdolls",
"ai_ignoreplayers",
"npc_citizen_auto_player_squad",
"voteforchange",
"votegamemode",
"votemap",
"votecontinue",
"perk_buy",
"+jump",
"-jump",
"+attack",
"-attack",
"_xgui",
"+voicerecord",
"-voicerecord",
"spp_check",
"spp_admin",
"spp_use",
"spp_edmg",
"spp_pgr",
"spp_awp",
"spp_dpd",
"spp_dae",
"spp_delay",
"_ihack_esp",
"_ihack_esp_npcs",
"_ihack_esp_players",
"_ihack_esp_weapons",
"_ihack_esp_charms",
"_ihack_esp_laser",
"_ihack_aimbot_ignoreplayers",
"_ihack_aimbot_ignorenpcs",
"_ihack_aimbot_ignorefriends",
"_ihack_aimbot_ignoreadmins",
"_ihack_aimbot_friendlyfire",
"_ihack_aimbot_auto",
"_ihack_aimbot_fakeview",
"_ihack_aimbot_nospread",
"_ihack_misc_alwaysnospread",
"_ihack_misc_fov",
"_ihack_misc_disconnectmsg",
"_ihack_ttt_showbodys",
"_ihack_ttt_ignorefellowdetectives",
"_ihack_ttt_ignorefellowtraitors",
"gmod_tool",
"axis_forcelimit",
"axis_torquelimit",
"axis_hingefriction",
"axis_nocollide",
"ballsocket_forcelimit",
"ballsocket_torquelimit",
"ballsocket_nocollide",
"ballsocket_adv_forcelimit",
"ballsocket_adv_torquelimit",
"ballsocket_adv_xmin",
"ballsocket_adv_xmax",
"ballsocket_adv_ymin",
"ballsocket_adv_ymax",
"ballsocket_adv_zmin",
"ballsocket_adv_zmax",
"ballsocket_adv_xfric",
"ballsocket_adv_yfric",
"ballsocket_adv_zfric",
"ballsocket_adv_onlyrotation",
"ballsocket_adv_nocollide",
"ballsocket_ez_forcelimit",
"ballsocket_ez_torquelimit",
"ballsocket_ez_nocollide",
"elastic_constant",
"elastic_damping",
"elastic_rdamping",
"elastic_width",
"elastic_stretch_only",
"balloon_ropelength",
"balloon_force",
"balloon_r",
"balloon_g",
"balloon_b",
"button_keygroup",
"dynamite_group",
"dynamite_damage",
"dynamite_delay",
"dynamite_delay_add",
"emitter_key",
"emitter_delay",
"emitter_toggle",
"emitter_starton",
"hoverball_speed",
"hoverball_keyup",
"hoverball_keydn",
"hoverball_resistance",
"hoverball_strength",
"ignite_length",
"lamp_ropelength",
"lamp_r",
"lamp_g",
"lamp_b",
"lamp_key",
"light_ropelength",
"light_r",
"light_g",
"light_b",
"light_brightness",
"light_size",
"light_key",
"magnetise_strength",
"magnetise_maxobjects",
"magnetise_nopull",
"magnetise_allowrot",
"magnetise_alwayson",
"magnetise_toggleon",
"magnetise_group",
"physprop_gravity_toggle",
"spawner_key",
"spawner_delay",
"thruster_force",
"thruster_keygroup",
"thruster_keygroup_back",
"thruster_toggle",
"thruster_collision",
"thruster_damageable",
"turret_key",
"turret_numbullets",
"turret_damage",
"turret_spread",
"turret_force",
"turret_delay",
"turret_toggle",
"wheel_fwd",
"wheel_bck",
"wheel_torque",
"wheel_forcelimit",
"wheel_friction",
"wheel_nocollide",
"wheel_toggle"
}

local _GCN = GetConVarNumber
local _GCS = GetConVarString
local _CVGI = convarmeta.GetInt
local _CVGB = convarmeta.GetBool
local _CC = plymeta.ConCommand
local _RCC = RunConsoleCommand
local _UMIncomingMessage = usermessage.IncomingMessage
local _HookAdd = hook.Add
local _HookRem = hook.Remove
local _CCA = concommand.Add
local _CCR = concommand.Remove
local _Include = include
local _Require = require
local _PlaySound = surface.PlaySound
local _FileTime = file.Time
local _FileExistsEx = file.ExistsEx
local _FileExists = file.Exists
local _FileSize = file.Size
local _FileRead = file.Read
local _FileFind = file.Find
local _FileFindDir = file.FindDir
local _FileTFind = file.TFind
local _FindInLua = file.FindInLua
local _FileRename = file.Rename
local _RunString = RunString

function surface.PlaySound( file )
if string.find( string.lower(file), "go_alert2a.wav" ) or 
string.find( string.lower(file), "breathe_loop1.wav" ) or
string.find( string.lower(file), "fz_scream1.wav" ) or 
string.find( string.lower(file), "ping.wav" ) then
MsgN("Blocked [surface.PlaySound]: " .. file .. "" )
return
end
MsgN("[surface.PlaySound]: " .. file .. "" )
return _PlaySound( file )
end

function RunConsoleCommand( cmd, ... )
if !table.HasValue( RCCWhitelist, string.lower(cmd) ) then
for k, v in pairs( {...} ) do
MsgN("Blocked [RunConsoleCommand]: ('" .. cmd .. " " .. v .. "')" ) 
end
return
end
return _RCC( cmd, ... )
end

function plymeta.ConCommand( ply, cmd )
if !string.find( string.lower(cmd), "gmod_tool" ) and
!string.find( string.lower(cmd), "playx_gui") and
!string.find( string.lower(cmd), "ulx") and
!string.find( string.lower(cmd), "wire_keyboard" ) then
MsgN( "Blocked [ConCommand]: ('" .. cmd .. "')" ) 
return
end
return _CC( ply, cmd )
end

function usermessage.IncomingMessage( mn, um, ... )
if string.find( string.lower(mn), "ulx_blind" ) or
string.find( string.lower(mn), "ulib_sound" ) or
string.find( string.lower(mn), "ulx_gag" ) then
MsgN("Blocked [usermessage.IncomingMessage]: " .. mn .. "")
return
end
if !string.find( string.lower(mn), "clmb" ) then
MsgN("[usermessage.IncomingMessage]: " .. mn .. "")
end
return _UMIncomingMessage( mn, um, ... )
end

function datastream.StreamToServer( handler, data, callback )
MsgN("[datastream.StreamToServer]: " .. handler .. "") 
return _StreamToServer( handler, data, callback )
end

function hook.Add( typ, name, func )
if name != nil then
if string.find( string.lower(name), "ulx_blind" ) or
string.find( string.lower(name), "stuneffect" ) or
string.find( string.lower(name), "flasheffect" ) or
string.find( string.lower(name), "perpcarmovement" ) or
string.find( string.lower(name), "perpsettingsrdl" ) or
string.find( string.lower(name), "antibb" ) then
MsgN("Blocked [hook.Add]: " .. name .. " [" .. typ .. "]" ) 
return
end
MsgN( "[hook.Add]: " .. name .. " [" .. typ .. "]" ) 
return _HookAdd( typ, name, func )
else
MsgN( "[hook.Add]: [" .. typ .. "]" )
return _HookAdd( typ, func )
end
end

function hook.Remove( typ, name )
MsgN( "[hook.Remove]: " .. name .. " [" .. typ .. "]" ) 
return _HookRem( typ, name )
end

function concommand.Add( name, func )
if name != "ulx" and name != "xgui" then 
MsgN( "[concommand.Add]: " .. name .. "" ) 
end
return _CCA( name, func )
end

function concommand.Remove( name, func )
MsgN( "[concommand.Remove]: " .. name .. "" ) 
return _CCR( name, func )
end

function include( name )
if !string.find( string.lower(name), "shared" ) then
MsgN( "[include]: " .. name .. "" )
end
return _Include( name )
end

function require( name )
MsgN( "[require]: " .. name .. "" )
return _Require( name )
end

function cvars.AddChangeCallback( cvar, callback )
if string.find( string.lower(cvar), "sv_cheats" ) then return 0 end
if string.find( string.lower(cvar), "mat_fullbright" ) then return 0 end
if string.find( string.lower(cvar), "r_drawparticles" ) then return 1 end
if string.find( string.lower(cvar), "host_framerate" ) then return 0 end
if string.find( string.lower(cvar), "sv_allow_voice_from_file" ) then return 0 end
if string.find( string.lower(cvar), "r_drawothermodels" ) then return 1 end
MsgN( "[cvars.AddChangeCallback]: " .. cvar .. "" )
return _CV.AddChangeCallback( cvar, callback )
end

function GetConVarNumber( cvar )
if string.find( string.lower(cvar), "sv_cheats" ) then return 0 end
if string.find( string.lower(cvar), "mat_fullbright" ) then return 0 end
if string.find( string.lower(cvar), "r_drawparticles" ) then return 1 end
if string.find( string.lower(cvar), "host_framerate" ) then return 0 end
if string.find( string.lower(cvar), "sv_allow_voice_from_file" ) then return 0 end
if string.find( string.lower(cvar), "r_drawothermodels" ) then return 1 end
return _GCN( cvar )
end
 
function GetConVarString( cvar )
if string.find( string.lower(cvar), "sv_cheats" ) then return 0 end
if string.find( string.lower(cvar), "mat_fullbright" ) then return 0 end
if string.find( string.lower(cvar), "r_drawparticles" ) then return 1 end
if string.find( string.lower(cvar), "host_framerate" ) then return 0 end
if string.find( string.lower(cvar), "sv_allow_voice_from_file" ) then return 0 end
if string.find( string.lower(cvar), "r_drawothermodels" ) then return 1 end
return _GCS( cvar )
end

function convarmeta.GetInt( cvar )
if string.find( string.lower(cvar:GetName()), "sv_cheats" ) then return 0 end
if string.find( string.lower(cvar:GetName()), "r_drawparticles" ) then return 1 end
if string.find( string.lower(cvar:GetName()), "host_framerate" ) then return 1 end
if string.find( string.lower(cvar:GetName()), "sv_allow_voice_from_file" ) then return 0 end
if string.find( string.lower(cvar:GetName()), "r_drawothermodels" ) then return 1 end
return _CVGI( cvar )
end
 
function convarmeta.GetBool( cvar )
if string.find( string.lower(cvar:GetName()), "sv_cheats" ) then return false end
if string.find( string.lower(cvar:GetName()), "r_drawparticles" ) then return true end
if string.find( string.lower(cvar:GetName()), "host_framerate" ) then return true end
if string.find( string.lower(cvar:GetName()), "sv_allow_voice_from_file" ) then return false end
if string.find( string.lower(cvar:GetName()), "r_drawothermodels" ) then return true end
return _CVGB( cvar )
end

function file.Time( file )
if string.find( string.lower(file), "hack" ) or 
string.find( string.lower(file), "gmcl_" ) or
string.find( string.lower(file), "gm_ih_" ) then
MsgN( "Blocked [file.Time]: " .. file .. "" ) 
return
end
MsgN( "[file.Time]: " .. file .. "" )
return _FileTime( file )
end

function file.ExistsEx( file )
if string.find( string.lower(file), "hack" ) or 
string.find( string.lower(file), "gmcl_" ) or
string.find( string.lower(file), "gm_ih_" ) then
MsgN( "Blocked [file.ExistsEx]: " .. file .. "" ) 
return
end
MsgN( "[file.ExistsEx]: " .. file .. "" )
return _FileExistsEx( file )
end

function file.Exists( file )
if string.find( string.lower(file), "hack" ) or 
string.find( string.lower(file), "gmcl_" ) or
string.find( string.lower(file), "gm_ih_" ) then
MsgN( "Blocked [file.Exists]: " .. file .. "" ) 
return
end
MsgN( "[file.Exists]: " .. file .. "" )
return _FileExists( file )
end

function file.Size( file )
if string.find( string.lower(file), "hack" ) or 
string.find( string.lower(file), "gmcl_" ) or
string.find( string.lower(file), "gm_ih_" ) then
MsgN( "Blocked [file.Size]: " .. file .. "" ) 
return
end
MsgN( "[file.Size]: " .. file .. "" )
return _FileSize( file )
end

function file.Rename( file, newname )
if string.find( string.lower(file), "hack" ) or 
string.find( string.lower(file), "gmcl_" ) or
string.find( string.lower(file), "gm_ih_" ) then
MsgN( "Blocked [file.Rename]: " .. file .. "" ) 
return
end
MsgN( "[file.Rename]: " .. file .. "" )
return _FileRename( file, newname )
end

function file.Read( file )
if string.find( string.lower(file), "hack" ) or 
string.find( string.lower(file), "gmcl_" ) or
string.find( string.lower(file), "gm_ih_" ) then
MsgN( "Blocked [file.Read]: " .. file .. "" ) 
return
end
MsgN( "[file.Read]: " .. file .. "" )
return _FileRead(file)
end

function file.FindInLua( path )
local filelist = _FindInLua( path )
MsgN( "[file.FindInLua]: " .. path .. "" )
for k, v in pairs( filelist ) do
if string.find( string.lower(v), "hack" ) or 
string.find( string.lower(v), "gmcl_" ) or
string.find( string.lower(v), "gm_ih_" ) then
MsgN( "Blocked [file.FindInLua]: " .. path .. " returning file " .. v .. "" )
table.remove( filelist, k )
end
end
return filelist
end

function file.Find( path )
local filelist = _FileFind( path )
MsgN( "[file.Find]: " .. path .. "" )
for k, v in pairs( filelist ) do
if string.find( string.lower(v), "hack" ) or 
string.find( string.lower(v), "gmcl_" ) or
string.find( string.lower(v), "gm_ih_" ) then
MsgN( "Blocked [file.Find]: " .. path .. " returning file " .. v .. "" )
table.remove( filelist, k )
end
end
return filelist
end

function file.FindDir( dir )
local filelist = _FileFindDir( dir )
MsgN( "[file.FindDir]: " .. dir .. "" )
for k, v in pairs( filelist ) do
if string.find( string.lower(v), "hack" ) or 
string.find( string.lower(v), "gmcl_" ) or
string.find( string.lower(v), "gm_ih_" ) then
MsgN( "Blocked [file.FindDir]: " .. dir .. " returning file " .. v .. "" )
table.remove( filelist, k )
end
end
return filelist
end

function file.TFind( path, callback )
local callpath = debug.getinfo(2)['short_src']
if callpath then
return _FileTFind( path, function( path, folders, files )
MsgN( "[file.TFind]: " .. path .. "" )
for k , v in pairs(folders) do
if string.find( string.lower(v), "backup" ) then
MsgN( "Blocked [file.Find]: " .. path .. " returning folder " .. v .. "" )
table.remove( folders, k )
end
end
for k , v in pairs(files) do
if string.find( string.lower(v), "hack" ) or 
string.find( string.lower(v), "gmcl_" ) or
string.find( string.lower(v), "gm_ih_" ) then
MsgN( "Blocked [file.TFind]: " .. path .. " returning file " .. v .. "" )
table.remove( files, k )
end
end
return callback( path, tableSetKeys(folders), tableSetKeys(files) )
end)
end
return _FileTFind( path, function( path , folders , files )
return callback( path, folders , files )
end)
end
