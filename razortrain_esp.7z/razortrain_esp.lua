CreateClientConVar("rz_esp", 1, true, false)
CreateClientConVar("rz_espname", 1, true, false)
CreateClientConVar("rz_esptype", 1, true, false) -- 1 for normal, 2 for truncated, 3 for initials

-- RGB color values
CreateClientConVar("esp_r", 0, true, false)
CreateClientConVar("esp_g", 255, true, false)
CreateClientConVar("esp_b", 0, true, false)

local function font()
    surface.CreateFont("ESPLarge", {
        font = "Default",
        size = 12,
        weight = 250,
        antialias = false,
    })
end
font()

local function initial(name)
    local initials = ""
    for word in string.gmatch(name, "%S+") do
        initials = initials .. string.sub(word, 1, 1)
    end
    return initials
end

local function isVisible(pos)
    local trace = util.TraceLine({
        start = LocalPlayer():EyePos(),
        endpos = pos,
        filter = LocalPlayer(),
        mask = MASK_SHOT
    })
    return trace.Fraction == 1
end

local function esp()
    if GetConVarNumber("rz_esp") == 1 then
        local r = GetConVarNumber("esp_r")
        local g = GetConVarNumber("esp_g")
        local b = GetConVarNumber("esp_b")

        for k, v in pairs(player.GetAll()) do
            if v ~= LocalPlayer() and v:Alive() and team.GetName(v:Team()) ~= "Spectator" then
                local headposition = v:EyePos() + Vector(0, 0, 10)
                if isVisible(headposition) then
                    local screenposition = headposition:ToScreen()

                    if GetConVarNumber("rz_espname") == 1 then
                        local name = string.upper(v:Name())
                        local displayname = name

                        local esptype = GetConVarNumber("rz_esptype")
                        if esptype == 2 then
                            displayname = string.sub(name, 1, math.floor(#name / 2)) .. ".." -- Truncate to half the name
                        elseif esptype == 3 then
                            displayname = initial(name)
                        end

                        surface.SetFont("ESPLarge")
                        local textwidth, textheight = surface.GetTextSize(displayname)
                        draw.SimpleTextOutlined(
                            displayname,
                            "ESPLarge",
                            screenposition.x - textwidth / 2,
                            screenposition.y - textheight / 2,
                            Color(r, g, b, 255),
                            TEXT_ALIGN_CENTER,
                            TEXT_ALIGN_CENTER,
                            1,
                            Color(0, 0, 0, 255)
                        )
                    end
                end
            end
        end
    end
end

hook.Add("HUDPaint", "esp", esp)

concommand.Add("rz_espcolor", function(ply, cmd, args)
    if #args == 3 then
        local r = tonumber(args[1])
        local g = tonumber(args[2])
        local b = tonumber(args[3])
        if r and g and b then
            RunConsoleCommand("esp_r", r)
            RunConsoleCommand("esp_g", g)
            RunConsoleCommand("esp_b", b)
            print("ESP color set to:", r, g, b)
        else
            print("Invalid RGB values")
        end
    else
        print("Usage: rz_espcolor <r> <g> <b>")
    end
end)


-- Define a table to store excluded SteamIDs
local excludedSteamIDs = {}

-- Function to check if a SteamID is excluded
local function isSteamIDExcluded(steamID)
    return table.HasValue(excludedSteamIDs, steamID)
end

-- Function to add a SteamID to the exclusion list
local function ExcludeSteamID(ply, cmd, args)
    local steamID = args[1]
    if steamID then
        table.insert(excludedSteamIDs, steamID)
        print("SteamID " .. steamID .. " added to exclusion list.")
    else
        print("Usage: exclude_steamid <SteamID>")
    end
end
concommand.Add("exclude_steamid", ExcludeSteamID)

-- Function to remove a SteamID from the exclusion list
local function IncludeSteamID(ply, cmd, args)
    local steamID = args[1]
    if steamID then
        for i, id in ipairs(excludedSteamIDs) do
            if id == steamID then
                table.remove(excludedSteamIDs, i)
                print("SteamID " .. steamID .. " removed from exclusion list.")
                return
            end
        end
        print("SteamID " .. steamID .. " not found in exclusion list.")
    else
        print("Usage: include_steamid <SteamID>")
    end
end
concommand.Add("include_steamid", IncludeSteamID)

-- ESP rendering function
local function DrawESP()
    -- Your existing ESP rendering code here
end

-- Command to toggle ESP on or off
local function ToggleESP(ply, cmd, args)
    if args[1] == "1" then
        hook.Add("HUDPaint", "DrawESP", DrawESP)
        print("ESP enabled.")
    else
        hook.Remove("HUDPaint", "DrawESP")
        print("ESP disabled.")
    end
end
concommand.Add("toggle_esp", ToggleESP)