

function RunHax()

require("cvar2")

--Localising Vars--
TB = {}

TB.Aim = 0

local Time = 0

TB.EyeAngles = Angle(0,0,0)

TB.StoredAngle = Angle(0,0,0)

TB.SpinBotTog = 0

TB.AngleRestored = 0

local TBRCC = RunConsoleCommand

local TBPCC = _R.Player.ConCommand

local TBGInt = _R.ConVar.GetInt

local TBGBool = _R.ConVar.GetBool

local TBGCVS = GetConVarString

local TBGCVN = GetConVarNumber

local CC = cvar2

TB.CCAdd = concommand.Add

TB.Ang = Angle(0,0,0)

local CreateClientConVar = CreateClientConVar

local TC = timer.Create

local TS = timer.Simple

local math = math

local spawnmenu = spawnmenu

local string = string

local surface = surface

local table = table

local timer = timer

local ents = ents

local file = file

local hook = hook

local team = team

local cam = cam

local gui = gui

local render = render

local util = util

local vgui = vgui

local concommand = concommand

local cvars = cvars

local debug = debug

local Friends = {}

local pllist = {}

local BoneList = {}

local LocalPlayer = LocalPlayer
-------------------
CC.SetValue("sv_cheats",1)
--Customized funcs--
function TB.DrawWB(x,y,text,color)

	return draw.WordBox( 0, x, y, text, "Default", color, Color(255,255,255,255) )
	
end

function TB.DrawCircle(x,y,size,color)

	surface.SetDrawColor(color)

	for i = 1,360 do
	
		surface.DrawLine(x+math.sin(math.rad(i))*size,y+math.cos(math.rad(i))*size,x+math.sin(math.rad(i)+0.1)*size,y+math.cos(math.rad(i)+0.1)*size)
	
	end
	
end

function TB.ScreenLength(x,y)

	return math.sqrt(x^2+y^2)
	
end

local function PlayerGetByName( stringent )

	for k,v in pairs(ents.GetAll()) do
	
		if v:IsPlayer() then
		
			if v:Name() == stringent then
			
				return v
				
			end
			
		end
		
	end
	
end

function GetConVarNumber( var )

	if var == "host_timescale" then return 1 end
	
	if var == "sv_scriptenforcer" then return 1 end
	
	if var == "sv_cheats" then return 0 end
	
	return TBGCVN( var )

end

function GetConVarString( var )

	if var == "host_timescale" then return "1" end
	
	if var == "sv_scriptenforcer" then return "1" end
	
	if var == "sv_cheats" then return "0" end
	
	return TBGCVS( var )

end

function  _R.ConVar.GetBool( var )

	if( var:GetName() == "sv_cheats" ) then return false end
	
	if( var:GetName() == "sv_scriptenforcer" ) then return true end
	
	if( var:GetName() == "host_timescale" ) then return true end
	
	return TBGBool( var )
	
end

function _R.ConVar.GetInt( var )

	if( var:GetName() == "sv_cheats" ) then return 0 end
	
	if( var:GetName() == "sv_scriptenforcer" ) then return 1 end
	
	if( var:GetName() == "host_timescale" ) then return 1 end
	
	return TBGInt( var )
	
end

function Error( ... ) end

function error( ... ) end

function ErrorNoHalt( ... ) end

--------------------

------Con Vars------
TB.CCAdd("+TB_Aim",function()

	TB.Aim = 1
	
	Time = 0
	
	if TBGCVN("TB_FakeView") == 1 then 
	
		TB.StoredAngle = LocalPlayer():EyeAngles()
	
	end
	
	TB.Ang = LocalPlayer():EyeAngles()
	
	TB.AngleRestored = 0

end)

TB.CCAdd("-TB_Aim",function()

	TB.Aim = 0
	
	TBRCC("-attack")

end)


CreateClientConVar( "TB_AimFov", 180, false, false )

CreateClientConVar( "TB_AimTeam", 1, false, false )

CreateClientConVar( "TB_NameTags", 0, false, false )

CreateClientConVar( "TB_NTAdmin", 1, false, false )

CreateClientConVar( "TB_NTHealth", 1, false, false )

CreateClientConVar( "TB_NTAlpha", 150, false, false )

CreateClientConVar( "TB_FakeView", 1, false, false )

CreateClientConVar( "TB_TargetPlayers", 1, false, false )

CreateClientConVar( "TB_TargetNPCs", 1, false, false )

CreateClientConVar( "TB_BlockRCC", 1, false, false )

CreateClientConVar( "TB_AntiSnap", 0, false, false )

CreateClientConVar( "TB_AntiSnapSpeed", 1, false, false )
--------------------

BoneList["models/combine_scanner.mdl"] = "Scanner.Body"	
		
BoneList["models/hunter.mdl"] = "MiniStrider.body_joint"

BoneList["models/combine_turrets/floor_turret.mdl"] = "Barrel"	

BoneList["models/dog.mdl"] = "Dog_Model.Eye"

BoneList["models/antlion.mdl"] = "Antlion.Body_Bone"

BoneList["models/antlion_guard.mdl"] = "Antlion_Guard.Body" 			

BoneList["models/antlion_worker.mdl"] = "Antlion.Head_Bone" 			

BoneList["models/zombie/fast_torso.mdl"] = "ValveBiped.HC_BodyCube"	

BoneList["models/zombie/fast.mdl"] = "ValveBiped.HC_BodyCube"		

BoneList["models/headcrabclassic.mdl"] = "HeadcrabClassic.SpineControl"

BoneList["models/headcrabblack.mdl"] = "HCBlack.body"				

BoneList["models/headcrab.mdl"] = "HCFast.body"					

BoneList["models/zombie/poison.mdl"] = "ValveBiped.Headcrab_Cube1"

BoneList["models/zombie/classic.mdl"] = "ValveBiped.HC_Body_Bone"	

BoneList["models/zombie/classic_torso.mdl"] = "ValveBiped.HC_Body_Bone"

BoneList["models/zombie/zombie_soldier.mdl"] = "ValveBiped.HC_Body_Bone" 

BoneList["models/combine_strider.mdl"] = "Combine_Strider.Body_Bone"			
	
BoneList["models/lamarr.mdl"] = "HeadcrabClassic.SpineControl"

function TB.GetHeadPos( ent )

	local model = ent:GetModel() or ""
	
	if string.find(model,"crow") or string.find(model,"seagull") or string.find(model,"pigeon") then
	
        return ent:LocalToWorld(ent:OBBCenter() + Vector(0,0,-5))
		
    elseif ent:GetAttachment(ent:LookupAttachment("eyes")) ~= nil and ent:IsPlayer() then
	
        return ent:GetAttachment(ent:LookupAttachment("eyes")).Pos+Vector(0,0,0)
		
    elseif BoneList[ent:GetModel()] then
	
		return ent:GetBonePosition(ent:LookupBone( BoneList[ent:GetModel()] || "ValveBiped.Bip01_Head1"))
		
	else
	
		return ent:EyePos()-Vector(0,0,10)
		
    end
		
end

local LAng

function TB.FovCheck( ent, fov )

	if fov == 0 or fov == 180 then return true end
	
	if ValidEntity( ent ) then
	
		if TBGCVN("TB_FakeView") == 0 then
	
			LAng = LocalPlayer():EyeAngles()
	
		else
		
			LAng = TB.StoredAngle
		
		end
		
		if math.NormalizeAngle( ( TB.GetHeadPos( ent ) - LocalPlayer():GetShootPos()):Angle().y - LAng.y ) > fov then return false end
	
		if math.NormalizeAngle( ( TB.GetHeadPos( ent ) - LocalPlayer():GetShootPos()):Angle().y - LAng.y ) < -fov then return false end

		if math.NormalizeAngle( ( TB.GetHeadPos( ent ) - LocalPlayer():GetShootPos()):Angle().p - LAng.p ) < -fov then return false end

		if math.NormalizeAngle( ( TB.GetHeadPos( ent ) - LocalPlayer():GetShootPos()):Angle().p - LAng.p ) > fov then return false end
		
		
		
	end

	return true

end

function TB.FovCheckNoCursor( ent, fov )

	if fov == 0 or fov == 180 then return true end
	
	if ValidEntity( ent ) then
	
		if math.NormalizeAngle( ( TB.GetHeadPos( ent ) - LocalPlayer():GetShootPos()):Angle().y - LocalPlayer():EyeAngles().y ) > fov then return false end
	
		if math.NormalizeAngle( ( TB.GetHeadPos( ent ) - LocalPlayer():GetShootPos()):Angle().y - LocalPlayer():EyeAngles().y ) < -fov then return false end

		if math.NormalizeAngle( ( TB.GetHeadPos( ent ) - LocalPlayer():GetShootPos()):Angle().p - LocalPlayer():EyeAngles().p ) < -fov then return false end

		if math.NormalizeAngle( ( TB.GetHeadPos( ent ) - LocalPlayer():GetShootPos()):Angle().p - LocalPlayer():EyeAngles().p ) > fov then return false end
	
	end

	return true

end

function TB.Visible(ent)

    local tracedata = {}
	
    tracedata.start = LocalPlayer():GetShootPos()
	
    tracedata.endpos = TB.GetHeadPos(ent)
	
    tracedata.filter = {LocalPlayer(),ent}
	
    tracedata.mask = MASK_SHOT
	
    local trace = util.TraceLine(tracedata)
	
    return trace.Fraction == 1 and true or false
	
end

function TB.Team(e)

	if TBGCVN("TB_AimTeam") == 0 then

		if e:IsPlayer() then
	
			if e:Team() == LocalPlayer():Team() then return false end
		
		end
		
	end
	
	return true

end

function TB.Flags(e)

    if e:IsPlayer() then
	
        if !e:IsValid() then return false end
		
        if not e:Alive() and e:Health() < 1 then return false end
		
		if e:GetMoveType() == MOVETYPE_OBSERVER then return false end
		
        if e == LocalPlayer() then return false end    
		
		if TBGCVN("TB_TargetPlayers") == 0 then return false end
		
        return true
		
    end
	
    if e:IsNPC() then
	
        if e:GetMoveType() == 0 then return false end
		
		if TBGCVN("TB_TargetNPCs") == 0 then return false end
		
        return true
		
    end
	
    return false
	
end

function TB.Targets()

	local TTbl = {}

	for k,v in pairs(ents.GetAll()) do
	
		if TB.Flags(v) == true and not table.HasValue(Friends,v) then
		
			table.insert(TTbl,v)
			
		end
		
	end

	return TTbl
	
end

function ClosestTarget()
	
    local cent = {0,0}
	
	local pos = LocalPlayer():GetPos()
	
	local ang = LocalPlayer():GetAimVector()
	
		for k, e in pairs(TB.Targets()) do
			
				if TB.FovCheck(e,TBGCVN("TB_AimFov")) and TB.Team(e) and TB.Visible(e) then
				
					local d = ( e:GetPos() - pos ):Normalize()
				
					d = d - ang
				
					d = d:Length()
			
					d = math.abs(d)
			
					if ( d < cent[2] ) or ( cent[1] == 0 ) then
				
						cent = {e,d}
			
					end
				
				end
			
		end
		
	if type(cent[1]) == "number" then 
	
		return LocalPlayer()
		
	else
	
		return cent[1]
		
	end
	
end

local SetViewAngles = _R.CUserCmd.SetViewAngles

function TB.Think()

	for k,v in pairs(Friends) do
	
		if not ValidEntity(v) then table.remove(Friends,k) end
	
	end

	if TB.Aim == 1 then

		if TB.FovCheckNoCursor(ClosestTarget(),3.5) then

			TBRCC("+attack")
		
		else
		
			TBRCC("-attack")
		
		end

	end

end
hook.Add("Think","TBThink",TB.Think)

function TB.FakeView(cmd)

	if TBGCVN("TB_FakeView") == 1 then

		TB.StoredAngle.p = math.Clamp(TB.StoredAngle.p + (cmd:GetMouseY() * 0.022), -89, 89)
	
		TB.StoredAngle.y = math.NormalizeAngle(TB.StoredAngle.y + (cmd:GetMouseX() * 0.022 * -1))
	
		TB.StoredAngle.r = 0
		
	end
	
end
hook.Add("CreateMove", "TBFakeView", TB.FakeView)

local SetViewAngles = _R.CUserCmd.SetViewAngles



function TB.AimHook( cmd )
	
	if TBGCVN("TB_AntiSnap") == 1 then
	
		TB.Ang.y = math.ApproachAngle(TB.Ang.y,(TB.GetHeadPos(ClosestTarget()) - LocalPlayer():GetShootPos() ):Angle().y,TBGCVN("TB_AntiSnapSpeed")*0.05) 
		
		TB.Ang.p = math.ApproachAngle(TB.Ang.p,(TB.GetHeadPos(ClosestTarget()) - LocalPlayer():GetShootPos() ):Angle().p,TBGCVN("TB_AntiSnapSpeed")*0.05) 
	
	else
	
		TB.Ang = ( TB.GetHeadPos(ClosestTarget()) - LocalPlayer():GetShootPos() ):Angle()
	
	end
	
	if TB.Aim > 0 then
	
		if ClosestTarget() != LocalPlayer() then
	
			SetViewAngles( cmd, TB.Ang )
			
			Time = Time + 1
		
		end
		
		print(Time)
		
	else
	
	if TBGCVN("TB_FakeView") == 1 then
	
		if TB.AngleRestored == 0 and TBGCVN("TB_AntiSnap") == 0 then
		
			SetViewAngles( cmd, TB.StoredAngle )
			
			TB.AngleRestored = 1
			
		end
		
	end
	
	end
	
	if TB.Aim > 0 and TBGCVN("TB_FakeView") == 1 then	
	
		local Forward = ((Vector(cmd:GetForwardMove(), cmd:GetSideMove(), 0):GetNormal():Angle() + (cmd:GetViewAngles() - TB.StoredAngle)):Forward() * Vector(cmd:GetForwardMove(), cmd:GetSideMove(), 0):Length())
		
		cmd:SetForwardMove(Forward.x)
		
		cmd:SetSideMove(Forward.y)
		
	end

end
hook.Add("CreateMove","TBAim",TB.AimHook)

function TB.CalcView(ply, pos, angles, fov)

    local view = {}
	
    view.origin = pos
	
	if TB.Aim == 1 and GetViewEntity() == LocalPlayer() and TBGCVN("TB_AntiSnap") == 0 and TBGCVN("TB_FakeView") == 1 then
	
		view.angles = TB.StoredAngle
	
	end
	
    view.fov = fov
 
    return view
	
end
hook.Add("CalcView", "TBCalcView", TB.CalcView)

function TB.NoRecoil()

	if not LocalPlayer():GetActiveWeapon().Primary then return end

	LocalPlayer():GetActiveWeapon().Primary.Recoil = 0

	LocalPlayer():GetActiveWeapon().Secondary.Recoil = 0

end

hook.Add("Think","TBRecoil",TB.NoRecoil)

function TB.ShowFOV()

	TB.DrawCircle(ScrW()/2,ScrH()/2,TBGCVN("TB_AimFov")*10,Color(255,255,255,155))

end

hook.Add("HUDPaint","TBFov",TB.ShowFOV)

function TB.NameTags()

	if TBGCVN("TB_NameTags") == 1 then
	
		for k,v in pairs(player.GetAll()) do
		
		
		
			if v:Name() != LocalPlayer():Name() then
			
				TB.DrawWB(v:GetShootPos():ToScreen().x-surface.GetTextSize( v:Name() ) /2,v:GetShootPos():ToScreen().y-33,v:Name(),Color(team.GetColor(v:Team()).r,team.GetColor(v:Team()).g,team.GetColor(v:Team()).b,TBGCVN("TB_NTAlpha")))
				
				if TBGCVN("TB_NTAdmin") == 1 and v:IsAdmin() and not v:IsSuperAdmin() then
				
					TB.DrawWB(v:GetShootPos():ToScreen().x-surface.GetTextSize( "Admin" ) /2,v:GetShootPos():ToScreen().y-46,"Admin",Color(250,50,50,TBGCVN("TB_NTAlpha")))
				
				end
				
				if TBGCVN("TB_NTAdmin") == 1 and v:IsSuperAdmin() then
				
					TB.DrawWB(v:GetShootPos():ToScreen().x-surface.GetTextSize( "Super Admin" ) /2,v:GetShootPos():ToScreen().y-46,"Super Admin",Color(250,50,50,TBGCVN("TB_NTAlpha")))
				
				end
				
				if TBGCVN("TB_NTHealth") == 1 then
				
					TB.DrawWB(v:GetShootPos():ToScreen().x-surface.GetTextSize( "Health: "..v:Health() ) /2,v:GetShootPos():ToScreen().y-20,"Health: "..v:Health(),Color(50,50,50,TBGCVN("TB_NTAlpha")))
				
				end
				
			end
			
		end
		
	end
	
end
hook.Add("HUDPaint","TBNames",TB.NameTags)
--------VGUI--------
	local DermaPanel = vgui.Create( "DFrame" )
	
	DermaPanel:SetPos( ScrW()/2-185,ScrH()/2-133 )
	
	DermaPanel:SetSize( 0, 0 )
	
	DermaPanel:SetTitle( "" )
	
	DermaPanel:SetDraggable( false )
	
	DermaPanel:ShowCloseButton( true )
	
	DermaPanel:MakePopup()
	
	DermaPanel:SetVisible( false )

	concommand.Add("-TB_Menu",function()

		DermaPanel:SetVisible(false)

	end)

	TB.CCAdd("+TB_menu",function()

	DermaPanel:SetVisible( true )

	end)
	
	Pan = vgui.Create( "DPropertySheet" )
	
	Pan:SetParent(DermaPanel)
	
	Pan:SetPos( ScrW()/2-185,ScrH()/2-133 )
	
	Pan:SetSize( 370, 270 )
	
	Pan:SetFadeTime(1)
	
	Pan:MakePopup()
	
	Pan.Paint = function( Pan )
	
		draw.RoundedBox( 0, 5, 20, Pan:GetWide()-36.5, Pan:GetTall()-50, Color( 0, 0 ,0 ,255 ) ) 
		
	end
	
	function AddBackground( panel )
	
		local background = vgui.Create("DImage", panel )
		
		background:SetMaterial( Material( "vgui/hackbg" ) )
		
		background:SetPos(0,0)
		
		background:SetSize(Pan:GetWide()-36.5, Pan:GetTall()-50)
		
	end
	
	
	local DermaParent = vgui.Create( "DLabel", Pan )

	DermaParent:SetPos(4,0)

	DermaParent:SetText("")

	AddBackground(DermaParent)
	
	
	local DermaParent2 = vgui.Create( "DLabel", Pan )

	DermaParent2:SetPos(4,0)

	DermaParent2:SetText("")
	
	AddBackground(DermaParent2)
	

	local DermaParent3 = vgui.Create( "DLabel", Pan )

	DermaParent3:SetPos(4,0)

	DermaParent3:SetText("")
	
	AddBackground(DermaParent3)
	

	local DermaParent4 = vgui.Create( "DLabel", Pan )

	DermaParent4:SetPos(4,0)

	DermaParent4:SetText("")
	
	AddBackground(DermaParent4)
	

	Pan:AddSheet( "General", DermaParent, "gui/silkicons/box", false, false, "General Settings" )

	Pan:AddSheet( "Aimbot", DermaParent2, "gui/silkicons/group", false, false, "Aimbot Settings" )

	Pan:AddSheet( "Aimbot Friends", DermaParent3, "gui/silkicons/heart", false, false, "Aimbot Friend List" )

	Pan:AddSheet( "TeeHack Info", DermaParent4, "gui/silkicons/user", false, false, "Information Of Each Player" )

	
	local CheckBox = vgui.Create( "DCheckBoxLabel", DermaParent )
	
    CheckBox:SetPos(10,0)
	
    CheckBox:SetText("Name Tags")
	
	CheckBox:SetConVar("TB_NameTags")
	
    CheckBox:SizeToContents()
	 
	 
	local CheckBox = vgui.Create( "DCheckBoxLabel", DermaParent )
	
    CheckBox:SetPos(10,25)
	
    CheckBox:SetText("Name Tags Show Admins")
	
	CheckBox:SetConVar("TB_NTAdmin")
	
    CheckBox:SizeToContents()
	
	 
	local CheckBox = vgui.Create( "DCheckBoxLabel", DermaParent )
	
    CheckBox:SetPos(10,50)
	
    CheckBox:SetText("Name Tags Show Health")
	
	CheckBox:SetConVar("TB_NTHealth")
	
    CheckBox:SizeToContents()
	
	
	local NumSlider = vgui.Create( "DNumSlider", DermaParent )
	
	NumSlider:SetPos( 10,75 )
	
	NumSlider:SetWide( 150 )
	
	NumSlider:SetText( "Name Tag Alpha" )

	NumSlider:SetMin( 0 ) 
	
	NumSlider:SetMax( 255 ) 
	
	NumSlider:SetDecimals( 0 ) 
	
	NumSlider:SetConVar( "TB_NTAlpha" )
	
	
	local CheckBox = vgui.Create( "DCheckBoxLabel", DermaParent )
	
    CheckBox:SetPos(10,120)
	
    CheckBox:SetText("Show Particles")
	
	CheckBox:SetConVar("r_drawparticles")
	
    CheckBox:SizeToContents()
	

	local CheckBox = vgui.Create( "DCheckBoxLabel", DermaParent )
	
    CheckBox:SetPos(10,145)
	
    CheckBox:SetText("Full Bright")
	
	CheckBox:SetConVar("mat_fullbright")
	
    CheckBox:SizeToContents()

	
	local Icon = vgui.Create("DModelPanel", DermaParent)
	
	Icon:SetModel(LocalPlayer():GetModel())
	
	Icon:SetAnimated(true)
	
	Icon:SetPos(150,10)
	
	Icon:SetSize(175,175)

	Icon:SetAmbientLight( Vector( 255, 255, 255 ) )
	
	Icon.Entity:SetPos(Icon.Entity:GetPos()+Vector(-20,0,0))
	
	
	local Label3 = vgui.Create("DLabel", DermaParent2)
	 
    Label3:SetText("Max Aimbot Feild Of View")
	 
    Label3:SizeToContents() 
	 
	Label3:SetPos(10,0)
	
	
	local Wang = vgui.Create( "DNumberWang", DermaParent2 )
	 
	Wang:SetPos( 10, 20 )
 
	Wang:SetMinMax( 0 , 180 )
	 
	Wang:SetWide(120)
	 
	Wang:SetDecimals(0)
	 
	Wang:SetConVar("TB_AimFov")
	 
	 
	local CheckBox = vgui.Create( "DCheckBoxLabel", DermaParent2 )
	
    CheckBox:SetPos(10,55)
	
    CheckBox:SetText("Friendly Fire")
	
	CheckBox:SetConVar("TB_AimTeam")
	
    CheckBox:SizeToContents()
	
	
	local CheckBox = vgui.Create( "DCheckBoxLabel", DermaParent2 )
	
    CheckBox:SetPos(10,80)
	
    CheckBox:SetText("Target Players")
	
	CheckBox:SetConVar("TB_TargetPlayers")
	
    CheckBox:SizeToContents()
	

	local CheckBox = vgui.Create( "DCheckBoxLabel", DermaParent2 )
	
    CheckBox:SetPos(10,105)
	
    CheckBox:SetText("Target NPCs")
	
	CheckBox:SetConVar("TB_TargetNPCs")
	
    CheckBox:SizeToContents()
	

	local CheckBox = vgui.Create( "DCheckBoxLabel", DermaParent2 )
	
    CheckBox:SetPos(10,130)
	
    CheckBox:SetText("Aimbot Anti Snap")
	
	CheckBox:SetConVar("TB_AntiSnap")
	
    CheckBox:SizeToContents()
	

	local dLabel = vgui.Create("DLabel", DermaParent2)
	 
    dLabel:SetText("Aimbot Anti Snap Speed")
	 
    dLabel:SizeToContents() 
	 
	dLabel:SetPos(13,150)
	
	
	local Wang = vgui.Create( "DNumberWang", DermaParent2 )
	 
	Wang:SetPos( 10, 165 )
 
	Wang:SetMinMax( 1 , 50 )
	 
	Wang:SetWide(120)
	 
	Wang:SetDecimals(0)
	 
	Wang:SetConVar("TB_AntiSnapSpeed")
	
	
	local CheckBox = vgui.Create( "DCheckBoxLabel", DermaParent2 )
	
    CheckBox:SetPos(10,195)
	
    CheckBox:SetText("Aimbot Fake View")
	
	CheckBox:SetConVar("TB_FakeView")
	
    CheckBox:SizeToContents()
	

	for k,v in pairs(player.GetAll()) do

		if not table.HasValue(Friends,v) and not table.HasValue(pllist,v) then
		
			table.insert(pllist,v)
			
		end
		
	end

	

	local dLabel = vgui.Create("DLabel", DermaParent3)
	
	dLabel:SetFont("defaultbold")
	 
    dLabel:SetText("All Players")
	 
    dLabel:SizeToContents() 
	 
	dLabel:SetPos(40,5)
	
	
	local dLabel = vgui.Create("DLabel", DermaParent3)
	
	dLabel:SetFont("defaultbold")
	 
    dLabel:SetText("All Friends")
	 
    dLabel:SizeToContents() 
	 
	dLabel:SetPos(220,5)
	
	
	local ComboBox
	
	local ComboBox2
	
	function ComBox()
	
		ComboBox = vgui.Create( "DComboBox", DermaParent3 )
	
		ComboBox:SetPos( 10, 25 )
	
		ComboBox:SetSize( 130, 185 )
	
		ComboBox:SetMultiple( false )
	
		ComboBox:EnableVerticalScrollbar( true )
	
		for k,v in pairs(player.GetAll()) do
	
			if ValidEntity(v) and not table.HasValue(Friends,v) then
		
				ComboBox:AddItem( v:Name() ) 
			
			end
		
		end
	
	end
	
	function ComBox2()
	
		ComboBox2 = vgui.Create( "DComboBox", DermaParent3 )
	
		ComboBox2:SetPos( 188, 25 )
	
		ComboBox2:SetSize( 130, 185 )
	
		ComboBox2:SetMultiple( false )
	
		ComboBox2:EnableVerticalScrollbar( true )
	
		for k,v in pairs(Friends) do
	
			if ValidEntity(v) then
		
				ComboBox2:AddItem( v:Name() ) 
			
			end
		
		end
	
	end
	
	ComBox() 
				
	ComBox2()
	
	local buttona = vgui.Create( "DButton", DermaParent3 )
	
	buttona:SetSize( 40, 30 )
	
	buttona:SetPos( 144, 70 )
	
	buttona:SetText( ">" )
	
	buttona.DoClick = function( buttona )
	
		if #ComboBox:GetSelectedItems()==0 then LocalPlayer():ChatPrint("Select a player then retry") return end

		for k,v in pairs(ComboBox:GetSelectedItems()) do
		
			if ValidEntity(PlayerGetByName(v:GetValue())) then
		
				if not table.HasValue(Friends,PlayerGetByName(v:GetValue())) then
			
					table.insert(Friends,PlayerGetByName(v:GetValue()))
				
					LocalPlayer():ChatPrint("Added "..v:GetValue().." to aimbot friends!")
				
				end
			
			end
			
		end
		
		ComBox() 
				
		ComBox2()
	
	end
	
	
	local buttonb = vgui.Create( "DButton", DermaParent3 )
	
	buttonb:SetSize( 40, 30 )
	
	buttonb:SetPos( 144, 130 )
	
	buttonb:SetText( "<" )
	
	buttonb.DoClick = function( buttonb )
	
		if #ComboBox2:GetSelectedItems()==0 then LocalPlayer():ChatPrint("Select a player then retry") return end
		
		for a,b in pairs(ComboBox2:GetSelectedItems()) do
		
			for c,d in pairs(Friends) do
			
				if ValidEntity(d) then
			
					if b:GetValue() == d:Name() then
				
						table.remove(Friends,c)
					
						table.insert(pllist,d)
					
					end
				
				end
				
			end
			
		end
		
		ComBox() 
				
		ComBox2()
		
	end
	
	
	local InfoLabel = vgui.Create("DLabel",DermaParent4)
	
	http.Get("http://www.luatee.com/HaxRoot/info.html","",function(data)
	
		InfoLabel:SetText(data)
	
		InfoLabel:SizeToContents()
	
	end)
	
	InfoLabel:SetPos(10,10)
	

function TB.DrawFL()

	TB.DrawWB(1040,2,"TB Friends:",Color(50,50,50,50))

	for k,v in pairs(Friends) do

		if k > 0 then
	
		if ValidEntity(v) then
		
			TB.DrawWB(1100,k*12-10,v:Name(),Color(50,50,50,50))
			
		end
	
		end

	end

end
hook.Add("HUDPaint","TBFriends",TB.DrawFL)

function TB.Bhop()

	if LocalPlayer():IsOnGround() then
	
		TBRCC("+jump")
		
	elseif not LocalPlayer():IsOnGround() and LocalPlayer():GetMoveType() == MOVETYPE_WALK then
	
		TBRCC("-jump")
			
	end
	
end
TB.CCAdd("+TB_Bhop",function()

	TBRCC("+jump")

	hook.Add("Think","TBBhop",TB.Bhop)

end)

TB.CCAdd("-TB_Bhop",function()

	TBRCC("-jump")

	hook.Remove("Think","TBBhop")

end)
local nt = 0
function TB.RapidFire()

	if nt < 2 then
	
		nt = nt + 1
		
	else
	
		nt = 1
		
	end
	
	if nt ~= 1 then
	
		TBRCC("+attack")
		
	elseif nt ~= 2 then
	
		TBRCC("-attack")
		
	end
	
end

TB.CCAdd("+TB_RapidFire",function() hook.Add("Think","TBRapidFire",TB.RapidFire) end)

TB.CCAdd("-TB_RapidFire",function() hook.Remove("Think","TBRapidFire") TBRCC("-attack") end)

TB.CCAdd("+TB_Speed",function() cvar2.SetValue("host_timescale",5) end)

TB.CCAdd("-TB_Speed",function() cvar2.SetValue("host_timescale",1) end)

local TBTogg = 0

function TB.WallHack()

	if TBTogg == 1 then

		for k,v in pairs(ents.GetAll()) do
		
			if v:IsNPC() or v:IsPlayer() then
			
				cam.Start3D(EyePos(),EyeAngles())
				
				cam.IgnoreZ(true)
				
					v:DrawModel()
					
				cam.IgnoreZ(false)
					
				cam.End3D()
			
			end
		
		end
	
	end

end
hook.Add("HUDPaint","TBWallHack",TB.WallHack)

TB.CCAdd("TB_WallHack",function() if TBTogg != 1 then TBTogg = 1 elseif TBTogg == 1 then TBTogg = 0 end end)

local ConTbl = {}

local ConCTbl = {}

local ConsoleColor = Color(255,255,255,255)

TB.CCAdd("TB_Console",function()

	local DPan = vgui.Create( "DFrame" )
	
	DPan:SetSize(500,400)
	
	DPan:SetPos(ScrW()/2-250,ScrH()/2-200)
	
	DPan:ShowCloseButton( true )
	
	DPan:SetDraggable( true )
	
	DPan:SetTitle("TeeBot Console")
	
	DPan:MakePopup() 
	
	DPan:SetVisible(false)
	

	local ConsoleBox = vgui.Create("DTextEntry", DPan)
	
	ConsoleBox:SetMultiline(true)
	
	ConsoleBox:SetSize(480,340) 
	
	ConsoleBox:SetEditable(false)
	
	ConsoleBox:SetPos(10,25)
	
	ConsoleBox.Paint = function()
	
		surface.SetDrawColor(70,70,70,255)
		
		surface.DrawRect(0,0,480,340)
		
		surface.SetDrawColor(0,0,0,255)
		
		surface.DrawOutlinedRect(0,0,480,340)
		
		for k,v in pairs(ConTbl) do
		
			surface.SetTextColor(ConCTbl[k])
			
			surface.SetTextPos(4,k*15-13)
			
			surface.DrawText( v )
			
		end
		
	end

	
	local TextEntry = vgui.Create("DTextEntry", DPan)
	
	TextEntry:SetMultiline(false)
	
	TextEntry:SetSize(480,20) 
	
	TextEntry:SetPos(10,370)
	
	TextEntry:SetEnterAllowed( true )
	
	TextEntry.OnEnter = function()
	
		local ST = string.ToTable(TextEntry:GetValue())
	
			if string.find(TextEntry:GetValue(),"textcolor") and #ST == 21 then
	
				ConsoleColor = Color(ST[1+10]..ST[2+10]..ST[3+10],ST[5+10]..ST[6+10]..ST[7+10],ST[9+10]..ST[10+10]..ST[11+10],255)
	
			end
	
		table.insert(ConCTbl,ConsoleColor)
	
		if string.sub(TextEntry:GetValue(),1,5) == "clear" then
	
			table.Empty(ConTbl)
	
			table.Empty(ConCTbl)
	
		else
	
			table.insert(ConTbl,"] "..TextEntry:GetValue())
	
		end
	
		if string.sub(TextEntry:GetValue(),1,3) == "lua" then
	
			RunString(string.sub(TextEntry:GetValue(),5,#ST))
	
		else
	
			LocalPlayer():ConCommand(TextEntry:GetValue())
	
		end
	
		for k,v in pairs(ConTbl) do
	
			if k > 22 then
	
				table.remove(ConTbl,k-22)
	
				table.remove(ConCTbl,k-22)
	
			end
	
		end

		TextEntry:SetValue("")
	
	end

end)



	local DPan = vgui.Create( "DFrame" )
	
	DPan:SetSize(1100,900)
	
	DPan:SetPos(ScrW()/2-550,ScrH()/2-450)
	
	DPan:ShowCloseButton( false )
	
	DPan:SetDraggable( true )
	
	DPan:SetTitle("TeeBot Browser")
	
	DPan:MakePopup() 
	
	DPan.Paint = function()
	
		draw.RoundedBox( 10, 0, 0, 1100, 900, Color( 55, 55, 55, 255 ) )
	
		draw.RoundedBox( 6, 98, 28, 954, 24, Color( 241, 241, 241, 255 ) )
	
	end
	
	DPan:SetVisible(false)

	
	HTML = vgui.Create("HTML", DPan)
	
	HTML:SetPos(10,60)
	
	HTML:SetSize(1080, 830)
	
	HTML:OpenURL("http://www.google.com")
	
	
	local TextEntryt = vgui.Create("DTextEntry", DPan)
	
	TextEntryt:SetMultiline(false)
	
	TextEntryt:SetSize(950,20) 
	
	TextEntryt:SetPos(100,30)
	
	TextEntryt:SetValue("http://www.google.com")
	
	TextEntryt:SetEnterAllowed( true )
	
	TextEntryt.OnEnter = function()
	
		HTML:OpenURL(TextEntryt:GetValue())
	
	end
	
	local p = TextEntryt.Paint
	
	TextEntryt.Paint = function() 
	
		p( TextEntryt  ) 
	
		surface.SetDrawColor( 241, 241, 241, 255 )
	
		surface.DrawOutlinedRect( 0, 0, 950, 20 )
	
	end
	


	
	HTML.OpeningURL = function(url, target)
	
		TextEntryt:SetValue(target)
	
	end
	
	local DButtont = vgui.Create("DImageButton", DPan)
	
	DButtont:SetPos(1055,7)
	
	DButtont:SetSize(18,12)
	
	DButtont:SetMaterial("VGUI/MinimizeButton")
	
	DButtont.DoClick = function()
	
		DPan:SetVisible(false)
	
	end
	
	
	local DButtont = vgui.Create("DImageButton", DPan)
	
	DButtont:SetPos(1070,3)
	
	DButtont:SetSize(18,18)
	
	DButtont:SetMaterial("VGUI/ExitButton")
	
	DButtont.DoClick = function()
	
		HTML:OpenURL("http://www.google.com")
	
		DPan:SetVisible(false)
	
	end

	
	local DButtont = vgui.Create("DImageButton", DPan)
	
	DButtont:SetPos(37,25)
	
	DButtont:SetSize(30,30)
	
	DButtont:SetMaterial("VGUI/ForwardButton")
	
	DButtont.DoClick = function()

		HTML:HTMLForward()
	
	end
	
	local DButtont = vgui.Create("DImageButton", DPan)
	
	DButtont:SetPos(7,25)
	
	DButtont:SetSize(30,30)
	
	DButtont:SetMaterial("VGUI/BackButton")
	
	DButtont.DoClick = function()
		
		HTML:HTMLBack()
	
	end
	
	local DButtont = vgui.Create("DImageButton", DPan)
	
	DButtont:SetPos(1055,27.5)
	
	DButtont:SetSize(25,25)
	
	DButtont:SetMaterial("VGUI/ForwardButton")
	
	DButtont.DoClick = function()
	
		HTML:OpenURL(TextEntryt:GetValue())
	
	end

	
concommand.Add("TB_Browser",function()

	DPan:SetVisible(true)

end)
	
end
--[[

]]