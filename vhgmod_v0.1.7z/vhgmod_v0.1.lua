print([[
     __________________
   /                    \
  |     vH for GMoD      |
  |----------------------|
  |     by BENBOOST9     |
  |----------------------|
  |   for Septagotius    |
   \ __________________ /
    |                  |
    |     Loaded       |
    |__________________|
          ________________________________________________
         |          Better than most gmod hacks.          |
         |           B-Aim, B-ESP, Menu like vH.          |
         |   Used same colors as valveHacks for the menu. |
         |___________________   __________________________|
                             | |
                             | |
                _____________| |_______________          _________________________
               |          Features:            |        |      Coming soon:       |
               |          NoRecoil             |        |        Configs          |
               |           Aimbot              |________|        BunnyHop         |
               |          Key Menu              ________          Chams           |
               |           Aimbot              |        |      Music player       |
               |_______________________________|        | YouTube player and more |
                                                        |_________________________|
]])
local lol = {}
lol["STEAM_0:0:1784149549"] = true
lol["STEAM_0:1:27314649"] = true
local CL = LocalPlayer()
local wep = LocalPlayer():GetActiveWeapon()
local NoSpreadHere=false
if lol[LocalPlayer():SteamID()] then
else
print("You are not able to use this.")
return false
end
local PredictSpread = function() end
if #file.Find("../lua/includes/modules/gmcl_dec0.dll")>=1 then
NoSpreadHere=true

local MoveSpeed = 1

mysetupmove = function(objPl, move)
    if move then
        MoveSpeed = (move:GetVelocity():Length())/move:GetMaxSpeed()
    end
end

local ID_GAMETYPE = ID_GAMETYPE or -1
local GameTypes = {
    {check=function ()
        return string.find(GAMEMODE.Name,"Garry Theft Auto") ~= nil
    end,getcone=function (wep,cone)
        if type(wep.Base) == "string" then
            if wep.Base == "civilian_base" then
                local scale = cone
                if CL:KeyDown(IN_DUCK) then
        scale = math.Clamp(cone/1.5,0,10)
                elseif CL:KeyDown(IN_WALK) then
        scale = cone
                elseif (CL:KeyDown(IN_SPEED) or CL:KeyDown(IN_JUMP)) then
        scale = cone + (cone*2)
                elseif (CL:KeyDown(IN_FORWARD) or CL:KeyDown(IN_BACK) or CL:KeyDown(IN_MOVELEFT) or CL:KeyDown(IN_MOVERIGHT)) then
        scale = cone + (cone*1.5)
                end
                scale = scale + (wep:GetNWFloat("Recoil",0)/3)
                return Vector(scale,0,0)
            end
        end
        return Vector(cone,cone,cone)
    end},
    {check=function ()
        return type(TEAM_ZOMBIE) == "number" and type(TEAM_SURVIVORS) == "number" and string.find(GAMEMODE.Name,"Zombie Survival") ~= nil and type(NUM_WAVES) == "number"
    end,getcone=function (wep,cone)
        if wep:GetNetworkedBool("Ironsights",false) then
            if CL:Crouching() then
                return wep.ConeIronCrouching or cone
            end
            return wep.ConeIron or cone
        elseif 25 < LocalPlayer():GetVelocity():Length() then
            return wep.ConeMoving or cone
        elseif CL:Crouching() then
            return wep.ConeCrouching or cone
        end
        return cone
    end},
    {check=function ()
        return type(TEAM_ZOMBIE) == "number" and type(TEAM_SURVIVORS) == "number" and string.find(GAMEMODE.Name,"Zombie Survival") ~= nil
    end,getcone=function (wep,cone)
        if CL:GetVelocity():Length() > 25 then
            return wep.ConeMoving or cone
        elseif CL:Crouching() then
            return wep.ConeCrouching or cone
        end
        return cone
    end},
    {check=function ()
        return type(gamemode.Get("ZombRP")) == "table" or type(gamemode.Get("DarkRP")) == "table"
    end,getcone=function (wep, cone)
        if type(wep.Base) == "string" and (wep.Base == "ls_snip_base" or wep.Base == "ls_snip_silencebase") then
            if CL:GetNWInt( "ScopeLevel", 0 ) > 0 then 
                print("using scopecone")
                return wep.Primary.Cone
            end
            print("using unscoped cone")
            return wep.Primary.UnscopedCone
        end
        if type(wep.GetIronsights) == "function" and wep:GetIronsights() then
            return cone
        end
        return cone + .05
    end},
    {check=function ()
        return (GAMEMODE.Data == "falloutmod" and type(Music) == "table")
    end,getcone=function(wep,cone)
        if wep.Primary then
            local LastShootTime = wep.Weapon:GetNetworkedFloat( "LastShootTime", 0 ) 
            local lastshootmod = math.Clamp(wep.LastFireMax + 1 - math.Clamp( (CurTime() - LastShootTime) * wep.LastFireModifier, 0.0, wep.LastFireMax ), 1.0,wep.LastFireMaxMod) 
            local accuracy = wep.Primary.Accuracy
            if CL:IsMoving() then accuracy = accuracy * wep.MoveModifier end
            if wep.Weapon:GetNetworkedBool( "Ironsights", false ) then accuracy = accuracy * 0.75 end
            accuracy = accuracy * ((16-(Skills.Marksman or 1))/11)
            if CL:KeyDown(IN_DUCK) then
                return accuracy*wep.CrouchModifier*lastshootmod
            else
                return accuracy*lastshootmod
            end
        end
    end}
}
Check = function()
    for k, v in pairs(GameTypes) do
        if v.check() then
            ID_GAMETYPE = k
            break
        end
    end
end

concommand.Add("raidbot_predictcheck", function () Check() print("GameType = ["..ID_GAMETYPE.."]") end)

local tblNormalConeWebases = {
    ["weapon_cs_base"] = true
}
local function GetCone(wep)
    local cone = wep.Cone
    if not cone and type(wep.Primary) == "table" and type(wep.Primary.Cone) == "number" then
        cone = wep.Primary.Cone
    end
    if wep:GetClass() == "ose_turretcontroller" then return 0 end
    return cone or 0
end

require("dec0")
local currentseed, cmd2, seed = currentseed or 0, 0, 0
local wep, vecCone, valCone
PredictSpread = function(cmd,aimAngle)
    cmd2, seed = hl2_ucmd_getpr3diction(cmd)
    if cmd2 ~= 0 then
        currentseed = seed
    end
    wep = LocalPlayer():GetActiveWeapon()
    vecCone = Vector(0,0,0)
    if wep and wep:IsValid() and type(wep.Initialize) == "function" then
        valCone = GetCone(wep)
        if( tonumber( valCone ) ) then
        vecCone = Vector( -valCone, -valCone, -valCone )
        elseif( type( valCone ) == "Vector" ) then
        vecCone = -1 * valCone
        end
    end
	if wep:GetClass() == "weapon_smg1" then
	vecCone = Vector(-0.04362,-0.04362,-0.04362)
	elseif wep:GetClass() == "weapon_pistol" then
	vecCone = Vector( -0.0100, -0.0100, -0.0100 )
	elseif wep:GetClass() == "weapon_ar2" then
	vecCone = Vector( -0.02618, -0.02618, -0.02618 )
	elseif wep:GetClass() == "weapon_shotgun" then
	vecCone = Vector( -0.08716, -0.08716, -0.08716 )
	elseif wep:GetClass() == "weapon_iceaxe" then
	vecCone = Vector(-0.15,-0.15,-0.15)
	elseif wep:GetClass() == "weapon_sniper" then
	vecCone = Vector(-0.1,-0.1,0)
	elseif wep:GetClass() == "weapon_hmg1" then
	vecCone = Vector(-0.07,-0.07,-0.07)
	elseif wep:GetClass() == "weapon_smg2" then
	vecCone = Vector(-0.07,-0.07,-0.07)
	elseif wep:GetClass() == "weapon_ar1" then
	vecCone = Vector(-0.07,-0.07,0)
	elseif wep:GetClass() == "weapon_oicw" then
	if wep.Zoom == 0 then
	vecCone = Vector(-0.07,-0.07,-0.07)
	else
	vecCone = Vector(-0.01,-0.01,-0.01)
	end
	elseif wep:GetClass() == "weapon_bsmg1" then
	vecCone = Vector(-0.04362,-0.04362,-0.04362)
	elseif wep:GetClass() == "mill_deagle" then
	vecCone = Vector(-0.5,-0.5,-0.5)
	elseif wep:GetClass() == "weapon_para" then
	vecCone = Vector(-0.05,-0.05,0)
	elseif wep:GetClass() == "awp" then
	vecCone = Vector(-0.05,-0.05,0)
	end
	cne = -vecCone.x
    return hl2_manipshot(currentseed or 0, (aimAngle or CL:GetAimVector():Angle()):Forward(), vecCone):Angle()
end
else
PredictSpread = function(cmd,aimAngle)
return aimAngle
end
end
local vH = {}
vH.aim = 1
vH.esp = 0
vH.cross = 1
vH.radar = 0
vH.nospread = 1
vH.dontaimteam = 0
vH.autoshoot = 1
vH.norecval = 1
local function changenorecval()
if vH.norecval > 19 then
vH.norecval = 1
else
vH.norecval = vH.norecval + 1
end
end
local function box( e )
	local ply, pos = LocalPlayer(), nil
	local center = e:LocalToWorld( e:OBBCenter() )
	local min, max = e:OBBMins(), e:OBBMaxs()
	local dim = max - min
	local z = max + min
	
	local frt	= ( e:GetForward() ) * ( dim.y / 2 )
	local rgt	= ( e:GetRight() ) * ( dim.x / 2 )
	local top	= ( e:GetUp() ) * ( dim.z / 2 )
	local bak	= ( e:GetForward() * -1 ) * ( dim.y / 2 )
	local lft	= ( e:GetRight() * -1 ) * ( dim.x / 2 )
	local btm	= ( e:GetUp() * -1 ) * ( dim.z / 2 )
	
	local d, v = math.Round( e:GetPos():Distance( ply:GetShootPos() ) )
	v = d / 30
	
	pos = e:LocalToWorld( top + top ) + Vector( 0, 0, v + 10 )
	if ( e:IsWeapon() ) then pos = e:LocalToWorld( e:OBBCenter() ) end
	
	local FRT 	= center + frt + rgt + top; FRT = FRT:ToScreen()
	local BLB 	= center + bak + lft + btm; BLB = BLB:ToScreen()
	local FLT	= center + frt + lft + top; FLT = FLT:ToScreen()
	local BRT 	= center + bak + rgt + top; BRT = BRT:ToScreen()
	local BLT 	= center + bak + lft + top; BLT = BLT:ToScreen()
	local FRB 	= center + frt + rgt + btm; FRB = FRB:ToScreen()
	local FLB 	= center + frt + lft + btm; FLB = FLB:ToScreen()
	local BRB 	= center + bak + rgt + btm; BRB = BRB:ToScreen()
	
	pos = pos:ToScreen()
	
	local maxX = math.max( FRT.x,BLB.x,FLT.x,BRT.x,BLT.x,FRB.x,FLB.x,BRB.x )
	local minX = math.min( FRT.x,BLB.x,FLT.x,BRT.x,BLT.x,FRB.x,FLB.x,BRB.x )
	local maxY = math.max( FRT.y,BLB.y,FLT.y,BRT.y,BLT.y,FRB.y,FLB.y,BRB.y)
	local minY = math.min( FRT.y,BLB.y,FLT.y,BRT.y,BLT.y,FRB.y,FLB.y,BRB.y )
	
	return maxX, minX, maxY, minY
end

aimmodels = {
        ["models/combine_scanner.mdl"] = "Scanner.Body",
        ["models/hunter.mdl"] = "MiniStrider.body_joint",
        ["models/combine_turrets/floor_turret.mdl"] = "Barrel",
        ["models/dog.mdl"] = "Dog_Model.Eye",
        ["models/antlion.mdl"] = "Antlion.Body_Bone",
        ["models/antlion_guard.mdl"] = "Antlion_Guard.Body",
        ["models/antlion_worker.mdl"] = "Antlion.Head_Bone",
        ["models/zombie/fast_torso.mdl"] = "ValveBiped.HC_BodyCube",
        ["models/zombie/fast.mdl"] = "ValveBiped.HC_BodyCube",
        ["models/headcrabclassic.mdl"] = "HeadcrabClassic.SpineControl",
        ["models/headcrabblack.mdl"] = "HCBlack.body",
        ["models/headcrab.mdl"] = "HCFast.body",
        ["models/zombie/poison.mdl"] = "ValveBiped.Headcrab_Cube1",
        ["models/zombie/classic.mdl"] = "ValveBiped.HC_Body_Bone",
        ["models/zombie/classic_torso.mdl"] = "ValveBiped.HC_Body_Bone",
        ["models/zombie/zombie_soldier.mdl"] = "ValveBiped.HC_Body_Bone",
        ["models/combine_strider.mdl"] = "Combine_Strider.Body_Bone",
        ["models/lamarr.mdl"] = "HeadcrabClassic.SpineControl"
}
local function HeadPos(ply) 
    if ValidEntity(ply) then 
	local bone = (aimmodels[ ply:GetModel() ] or "ValveBiped.Bip01_Head1")
	local hbone = ply:LookupBone(bone) 
        return ply:GetBonePosition(hbone) 
    else return end 
end
local function Visible(ply) 
    local trace = {start = LocalPlayer():GetShootPos(),endpos = HeadPos(ply),filter = {LocalPlayer(), ply}} 
    local tr = util.TraceLine(trace) 
    if tr.Fraction == 1 then 
        return true 
    else 
        return false 
    end     
end
local predictvec = Vector(0,0,0)
local tar = nil
local current = 1
local correctView = Angle( 0, 0, 0 )
local silent = Angle( 0, 0, 0 )
local view = Angle( 0, 0, 0 )
local SetViewAngles = _R["CUserCmd"].SetViewAngles
local function checkteam(pl)
if vH.dontaimteam == 1 then
if LocalPlayer():Team() == pl:Team() then
return false
end
else
return true
end
end
local cppweaps = {}
cppweaps["weapon_357"] = true
cppweaps["weapon_smg1"] = true
cppweaps["weapon_ar2"] = true
cppweaps["weapon_shotgun"] = true
cppweaps["weapon_pistol"] = true
cppweaps["weapon_crossbow"] = true
cppweaps["weapon_rpg"] = true

local function anglepunch()
if cppweaps[LocalPlayer():GetActiveWeapon():GetClass()] then
return (((LocalPlayer():GetPunchAngle( )) or Angle(0,0,0))*(vH.norecval/10))
else
return Angle(0,0,0)
end
end

local function Bot( u )
		local ply = LocalPlayer()
		if LocalPlayer():Alive() then
		local ply = LocalPlayer()
		local mouse = Angle(u:GetMouseY() * GetConVarNumber("m_pitch"), u:GetMouseX() * -GetConVarNumber("m_yaw"),0) or Angle(0,0,0)
        correctView = correctView + mouse
		end
		correctView.p = math.Clamp(math.NormalizeAngle( correctView.p ),-89,89)
		correctView.y = math.NormalizeAngle( correctView.y )
		if vH.nospread == 2 then
			view = PredictSpread(u,correctView)
		else
			view = correctView
		end
			view.r = 0
		--view.p = math.NormalizeAngle( view.p )
		--view.y = math.NormalizeAngle( view.y )
		SetViewAngles( u, view-anglepunch())
				for k, NPCs in pairs(ents.FindByClass("npc_*")) do
		if vH.aim==1 then else return end
		if Visible(NPCs) then
		if NPCs:IsNPC() then if NPCs.IsDead == true then return false end end
		if NPCs:GetMoveType() == MOVETYPE_NONE then return false end
		local targetheadpos = HeadPos(NPCs)
		local velocity = NPCs:GetVelocity() or Vector(0,0,0)
		local velocityplayer = ply:GetVelocity() or Vector(0,0,0)
		if NPCs:GetMoveType() == MOVETYPE_NONE then return end
		local ang = (((targetheadpos + velocity*2*FrameTime())- (ply:GetShootPos()+velocityplayer*2*FrameTime())):Angle())
		correctView = ang
		if vH.autoshoot == 1 then
			RunConsoleCommand( "+attack" )
			timer.Simple( 0.1, function() RunConsoleCommand( "-attack" ) end )
		end
		if (vH.nospread == 1) or (vH.nospread == 2) then
			ang = PredictSpread(u,ang)
			ang.r = 0
		end
		SetViewAngles( u, ang-anglepunch() )
		end
		end
		for k, plys in pairs(player.GetAll()) do
		if !(vH.aim==1) then return end
				if plys != LocalPlayer() then
				local ply = LocalPlayer()
				if Visible(plys) then
				if plys:Health() > 0 then
			if !plys:Alive() && !(plys:Health() > 0) then return end
			if plys:GetMoveType() == MOVETYPE_NONE then return end
			if checkteam(plys) then
			local targetheadpos = HeadPos(plys)
			local velocity = plys:GetVelocity() or Vector(0,0,0)
			local velocityplayer = ply:GetVelocity() or Vector(0,0,0)
			local ply = LocalPlayer()
			local targetheadpos = HeadPos(plys)
			local targetPos = (((targetheadpos + velocity*2*FrameTime())- (ply:GetShootPos()+velocityplayer*2*FrameTime())):Angle())
			local ang = targetPos
			correctView = ang
			if vH.autoshoot == 1 then
				RunConsoleCommand( "+attack" )
				timer.Simple( 0.1, function() RunConsoleCommand( "-attack" ) end )
			end
			targetPos.z = 0
			LocalPlayer():GetActiveWeapon().SetNextPrimaryFire( LocalPlayer():GetActiveWeapon() )
			if (vH.nospread == 1) or (vH.nospread == 2) then
			ang = PredictSpread(u,targetPos)
			ang.r = 0
			end
			SetViewAngles(u,ang-anglepunch())
end
end
end
end
end
end
hook.Add("CreateMove","nospreadnaim",Bot)
	local function NoRecoil( u, o )
		return { origin = o, angles = correctView}
	end
	hook.Add( "CalcView","lol", NoRecoil )

local varmenu = {}
varmenu.current = 1
varmenu.showmenu = 0
local radar = {}
local function drawbradar()
surface.SetDrawColor( 68, 68, 68, 255 ); 
surface.DrawRect( 0, 0, 200, 200 ); 
surface.SetDrawColor( 90, 106, 79, 255 ); 
surface.DrawOutlinedRect( 0, 0, 200, 200 ); 
surface.DrawLine( 10, 100, 190, 100 ); 
surface.DrawLine( 100, 10, 100, 190 ); 
--Default values
radar.w = 200
radar.h = 200
radar.x = 0
radar.y = 0
radar.alphascale = 0.6
radar.bgcolor = Color(255,0,0,255)
radar.fgcolor = Color(0,0,255,255)
radar.dangercolour = Color(220,0,0,255)
radar.dangerblipcolour = Color(255,255,0,255)
radar.screendetail = 64
radar.screenrotation = 0
radar.hazardmode = false    --doesnt work

radar.radius = 5000

radar.player_show = true
radar.player_color = Color(0,150,255,255)
surface.CreateFont("Arial",64,400,false,false,"RadarPlayerLabel")
radar.player_fontcolor = Color(255,255,255,255)
radar.player_showname = true
radar.player_showhealth = true
radar.player_showarmor = false --TO DO
radar.player_showammo = true


radar.scanfor = {"player", "blastfungus", "rpg_missile", "crossbow_bolt", "npc_", "sent_", "prop_vehicle_"}		-- What should the radar look for?  Accepts partial names.
radar.dangerous = {"sent_nuke_missile", "sent_nuke_detpack"}    --doesnt work

radar.bgcolorbak = radar.bgcolor
radar.fgcolorbak = radar.fgcolor
radar.player_colorbak = radar.player_color


local color_ascale = function(col,scale) return Color(col.r,col.g,col.b,col.a*scale) end

	local ETable = {}
	local PulseRadar = false

	local lpl = LocalPlayer()
	
	
	if ( radar.player_show ) then
	local vertices = {}
	for i=1,radar.screendetail do
		local shift = math.fmod(CurTime()*radar.screenrotation,360)
		local sizescale = 1
		local tab = {}
		tab.x = radar.x+radar.w/2 + math.cos(math.Deg2Rad((360/radar.screendetail)*i+shift)) * radar.w/2 * sizescale
		tab.y = radar.y+radar.h/2 + math.sin(math.Deg2Rad((360/radar.screendetail)*i+shift)) * radar.h/2 * sizescale
		tab.u = 0
		tab.v = 0
		table.insert(vertices,tab)
	end
	local players = {}

	for k,ent in pairs(ents.GetAll()) do

			if ent:IsValid() then
				local type = ent:GetClass()

				for k, v in ipairs(radar.scanfor) do
					if string.find(type,v) then
						table.insert(players,ent)
					end
				end
			end
		end
		for i, pl in ipairs(players) do
			local cx = radar.x+radar.w/2
			local cy = radar.y+radar.h/2
			local vdiff = pl:GetPos()-lpl:GetPos()
			local dummy = nil
				if pl:IsPlayer() then
					if ( pl:Alive() and lpl~=pl ) then
						local px = (vdiff.x/radar.radius)
						local py = (vdiff.y/radar.radius)
						local z = math.sqrt( px*px + py*py )
						local phi = math.Deg2Rad( math.Rad2Deg( math.atan2( px, py ) ) - math.Rad2Deg( math.atan2( lpl:GetAimVector().x, lpl:GetAimVector().y ) ) - 90 )
						px = math.cos(phi)*z
						py = math.sin(phi)*z
						draw.RoundedBox( 0, cx+px*radar.w/2-4, cy+py*radar.h/2-4, 8, 8, color_ascale(radar.player_color,255) )
						surface.SetDrawColor( 0,0,0,255 )
						surface.DrawOutlinedRect( cx+px*radar.w/2-4, cy+py*radar.h/2-4, 8, 8)
						if radar.player_showname then
							draw.DrawText(pl:Name(), "Default", cx+px*radar.w/2, cy+py*radar.h/2+8, color_ascale(radar.player_fontcolor,radar.alphascale), TEXT_ALIGN_CENTER)
						end
						if radar.player_showhealth then
							draw.RoundedBox( 0, cx+px*radar.w/2-12, cy+py*radar.h/2+20, (math.min(100,pl:Health())/100)*24, 4, Color(255,0,0,255) )
						end
						if radar.player_showammo then
							if (lpl:GetActiveWeapon().Clip1~=nil and lpl:GetActiveWeapon():Clip1() > 0) then
								draw.RoundedBox( 0, cx+px*radar.w/2-12, cy+py*radar.h/2+26, math.min(1,(lpl:GetAmmoCount(lpl:GetActiveWeapon():GetPrimaryAmmoType())/lpl:GetActiveWeapon():Clip1()))*24, 4, Color(255,200,0,255) ) --BUGGED?
							else
								draw.RoundedBox( 0, cx+px*radar.w/2-12, cy+py*radar.h/2+26, 24, 4, Color(255,200,0,255) )
							end
						end
					end
				end
				if ((not pl:IsPlayer()) and pl:IsValid() ) then

				    local isDangerous = false
					if ( radar.hazardmode ) then
						for k,v in ipairs(radar.dangerous) do
						    if (pl:GetClass() == v) then
						        table.insert(ETable,pl)
						        isDangerous = true
							end
						end
					end
					
					local px = (vdiff.x/radar.radius)
					local py = (vdiff.y/radar.radius)
					local z = math.sqrt( px*px + py*py )
					local phi = math.Deg2Rad( math.Rad2Deg( math.atan2( px, py ) ) - math.Rad2Deg( math.atan2( lpl:GetAimVector().x, lpl:GetAimVector().y ) ) - 90 )
					px = math.cos(phi)*z
					py = math.sin(phi)*z

					if (isDangerous == false) then
						draw.RoundedBox( 0, cx+px*radar.w/2-4, cy+py*radar.h/2-4, 8, 8, color_ascale(radar.player_color,255) )
						surface.SetDrawColor( 0,0,0,255 )
						surface.DrawOutlinedRect( cx+px*radar.w/2-4, cy+py*radar.h/2-4, 8, 8)
					if pl:IsNPC() then
						if( Visible(pl) ) then
                        drawColor = Color( 255, 0, 0, 255 )
						else
                        drawColor = Color( 0, 255, 255, 255 )
						end
						draw.RoundedBox( 0, cx+px*radar.w/2-4, cy+py*radar.h/2-4, 8, 8, drawColor )
						surface.SetDrawColor( 0,0,0,255 )
						surface.DrawOutlinedRect( cx+px*radar.w/2-4, cy+py*radar.h/2-4, 8, 8)
					end
					end


					if radar.player_showname then

						local nametag = ""
						if string.find(pl:GetClass(),"blastfungus") then nametag = ""
						elseif string.find(pl:GetClass(),"npc_") then nametag = string.sub(pl:GetClass(),5)
						elseif string.find(pl:GetClass(),"sent_") then nametag = string.sub(pl:GetClass(),6)
						elseif string.find(pl:GetClass(),"prop_vehicle_") then nametag = string.sub(pl:GetClass(),14)
						else nametag = pl:GetClass()
						end

						local nametable = string.Explode("_",nametag)
						nametag = table.concat(nametable," ")
						local nametag1 = string.sub(nametag,0,1)
						local nametag2 = string.sub(nametag,2)
						nametag1 = string.upper(nametag1)
						nametag = nametag1..nametag2


					end
				end
   			end
	 	end
   		local count = table.Count(ETable)
   		
   		if ( count > 0 ) then
   		for k,pl in ipairs(ETable) do
   			local cx = radar.x+radar.w/2
			local cy = radar.y+radar.h/2
			local vdiff = pl:GetPos()-lpl:GetPos()
			
   			local px = (vdiff.x/radar.radius)
			local py = (vdiff.y/radar.radius)
			local z = math.sqrt( px*px + py*py )
			local phi = math.Deg2Rad( math.Rad2Deg( math.atan2( px, py ) ) - math.Rad2Deg( math.atan2( lpl:GetAimVector().x, lpl:GetAimVector().y ) ) - 90 )
			px = math.cos(phi)*z
			py = math.sin(phi)*z
			draw.RoundedBox( 0, (cx+px*radar.w/2-8), (cy+py*radar.h/2-8), 16, 16, color_ascale(radar.dangerblipcolour,255) )
			surface.SetDrawColor( 0,0,0,255 )
			surface.DrawOutlinedRect( cx+px*radar.w/2-4, cy+py*radar.h/2-4, 8, 8)
		end
			
			radar.bgcolor = Color(255,255,255,0)
			radar.fgcolor = Color(60,60,60,100)
			
			PulseRadar = true
		end
end
local function drawesp() 
if vH.esp == 1 then
        for k, v in pairs(ents.GetAll()) do 
            if( ValidEntity(v) and v ~= LocalPlayer() ) then
                if( v:IsNPC() ) then 
                    local drawColor = Color(255, 255, 255, 255); 
                    local drawPosit = v:GetPos():ToScreen(); 
                    local vis = ""
                    if( Visible(v) ) then 
						vis = "Visible"
                        drawColor = Color( 255, 0, 0, 255 ); 
                    else 
						vis = "Invisible"
                        drawColor = Color( 0, 255, 255, 255 ); 
                    end 
					surface.SetDrawColor(drawColor)
					local head = HeadPos(v):ToScreen()
					local maxX, minX, maxY, minY = box(v)
					local lol = maxY-minY
					surface.DrawLine( maxX, maxY, maxX, minY )
					surface.DrawLine( maxX, minY, minX, minY )
					
					surface.DrawLine( minX, minY, minX, maxY )
					surface.DrawLine( minX, maxY, maxX, maxY )
                    local textData = {} 
                     
                    textData.pos = {} 
                    textData.pos[1] = drawPosit.x; 
                    textData.pos[2] = maxY+10; 
                    textData.color = drawColor; 
                    textData.text = v:GetClass(); 
                    textData.font = "DefaultFixed"; 
                    textData.xalign = TEXT_ALIGN_CENTER; 
                    textData.yalign = TEXT_ALIGN_CENTER; 
                    draw.Text( textData ); 
                    textData.pos = {} 
                    textData.pos[1] = drawPosit.x; 
                    textData.pos[2] = maxY+25; 
                    textData.color = drawColor; 
                    textData.text = vis; 
                    textData.font = "DefaultFixed"; 
                    textData.xalign = TEXT_ALIGN_CENTER; 
                    textData.yalign = TEXT_ALIGN_CENTER; 
                    draw.Text( textData );
					elseif( v:IsPlayer() and v:Health() > 0 and v:Alive() ) then 
                    local drawColor = team.GetColor(v:Team()); 
                    local drawPosit = v:GetPos():ToScreen(); 
                     
                    if( Visible(v) ) then 
                        drawColor.a = 255; 
                    else 
                        drawColor.r = 255 - drawColor.r; 
                        drawColor.g = 255 - drawColor.g; 
                        drawColor.b = 255 - drawColor.b; 
                    end 
                    surface.SetDrawColor(drawColor)
                    local textData = {} 
                    local maxX, minX, maxY, minY = box(v)
					local lol = maxY-minY
					surface.SetDrawColor(drawColor)
					surface.DrawLine( maxX, maxY, maxX, minY )
					surface.DrawLine( maxX, minY, minX, minY )
					
					surface.DrawLine( minX, minY, minX, maxY )
					surface.DrawLine( minX, maxY, maxX, maxY )
                    textData.pos = {} 
                    textData.pos[1] = drawPosit.x; 
                    textData.pos[2] = maxY+10; 
                    textData.color = drawColor; 
                    textData.text = v:GetName(); 
                    textData.font = "DefaultFixed"; 
                    textData.xalign = TEXT_ALIGN_CENTER; 
                    textData.yalign = TEXT_ALIGN_CENTER; 
                     
                    draw.Text( textData ); 
					local max_armor = 100; 
                     
                    if( v:Armor() > max_armor ) then 
                       max_armor = v:Armor(); 
                    end 
                     
                    local mx = max_armor; 
                    local mw = v:Armor(); 
                    local drw = mw / lol
                    local drawPosHealth = drawPosit; 
					surface.SetDrawColor(0,0,0,255)
					surface.DrawRect(maxX+2,minY-1,6,lol+2)
					surface.SetDrawColor(255-(mw*2+50),mw*2+50,0,255)
					surface.DrawRect(maxX+3,minY-(mw/drw)+(mx/drw),4,mw/drw)
					local max_health = 100; 
                     
                    if( v:Health() > max_health ) then 
						max_health = v:Health(); 
                    end 
                    
                    local mx = max_health; 
                    local mw = v:Health(); 
                    local drw = mx / lol
                    local drawPosHealth = drawPosit; 
					surface.SetDrawColor(0,0,0,255)
					surface.DrawRect(minX-8,minY-1,6,lol+2)
					surface.SetDrawColor(255-(mw*2+50),mw*2+50,0,255)
					surface.DrawRect(minX-7,minY-(mw/drw)+(mx/drw),4,mw/drw)
					end
					end
					end
    end 
	end
local function lol()
		--esp
		if vH.esp == 1 then
		drawesp()
		end
		--menu
		if varmenu.showmenu == 1 then
		local g, b = Color( 180, 180, 180, 255 ), Color( 0, 0, 0, 255 )
	    surface.SetDrawColor( 90, 106, 79, 255 ); 
		surface.DrawRect( ScrW()/2-100, 0, 200, 16*8+1 ); 
		surface.SetDrawColor( 68, 68, 68, 255 ); 
		surface.DrawRect( ScrW()/2-99, 18, 198, 16*7-3 ); 
		surface.SetDrawColor( 75, 81, 71, 255 ); 
		if varmenu.current == 1 then
		surface.DrawRect(ScrW()/2-99,16,198,16); 
		elseif varmenu.current == 2 then
		surface.DrawRect(ScrW()/2-99,16*2,198,16); 
		elseif varmenu.current == 3 then
		surface.DrawRect(ScrW()/2-99,16*3,198,16); 
		elseif varmenu.current == 4 then
		surface.DrawRect(ScrW()/2-99,16*4,198,16); 
		elseif varmenu.current == 5 then
		surface.DrawRect(ScrW()/2-99,16*5,198,16); 
		elseif varmenu.current == 6 then
		surface.DrawRect(ScrW()/2-99,16*6,198,16); 
		elseif varmenu.current == 7 then
		surface.DrawRect(ScrW()/2-99,16*7,198,16); 
		end
		draw.SimpleTextOutlined( "valveHacks for GMOD by BB9", "Default", ScrW()/2, 16/2, Color( 180, 180, 180, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, Color( 0, 0, 0, 255 ) )
		draw.SimpleTextOutlined( "Aimbot: "..vH.aim, "Default", ScrW()/2-80, 16/2+16, Color( 255, 255, 255, 255 ), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER, 1, Color( 0, 0, 0, 255 ) )
		draw.SimpleTextOutlined( "Crosshair: "..vH.cross, "Default", ScrW()/2-80, 16/2+(16*2), Color( 255, 255, 255, 255 ), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER, 1, Color( 0, 0, 0, 255 ) )
		draw.SimpleTextOutlined( "ESP: "..vH.esp, "Default", ScrW()/2-80, 16/2+(16*3), Color( 255, 255, 255, 255 ), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER, 1, Color( 0, 0, 0, 255 ) )
		draw.SimpleTextOutlined( "Radar: "..vH.radar, "Default", ScrW()/2-80, 16/2+(16*4), Color( 255, 255, 255, 255 ), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER, 1, Color( 0, 0, 0, 255 ) )
		draw.SimpleTextOutlined( "NoSpread: "..vH.nospread, "Default", ScrW()/2-80, 16/2+(16*5), Color( 255, 255, 255, 255 ), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER, 1, Color( 0, 0, 0, 255 ) )
		draw.SimpleTextOutlined( "NoRecoil Value: "..(vH.norecval/10), "Default", ScrW()/2-80, 16/2+(16*6), Color( 255, 255, 255, 255 ), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER, 1, Color( 0, 0, 0, 255 ) )
		end
		--crosshair
		if vH.cross == 1 then
		surface.SetDrawColor( 255, 255, 255, 255 ); 
		surface.DrawLine(ScrW()/2-15,ScrH()/2,ScrW()/2-5,ScrH()/2)
		surface.DrawLine(ScrW()/2+5,ScrH()/2,ScrW()/2+15,ScrH()/2)
		surface.DrawLine(ScrW()/2,ScrH()/2+5,ScrW()/2,ScrH()/2+15)
		surface.DrawLine(ScrW()/2,ScrH()/2-15,ScrW()/2,ScrH()/2-5)
		end
		--radar
		if vH.radar == 1 then
		drawbradar()
		end
		end
hook.Add("HUDPaint","menuespandcrosshair",lol)
local timerruns = 1
function KeyPress()
if timerruns == 1 then
timer.Simple(0.1,function () KeyPress() end)
end
    if( input.IsKeyDown( KEY_DELETE ) ) then
	timerruns = 0
	print("Destroyed timer")
	end
    if( input.IsKeyDown( KEY_INSERT ) ) then
	if varmenu.showmenu == 0 then
	varmenu.showmenu = 1
	else
	varmenu.showmenu = 0
	end
    end
	if varmenu.showmenu == 1 then
	if( input.IsKeyDown( KEY_DOWN ) ) then
	if varmenu.current == 1 then
	varmenu.current = 2
	elseif varmenu.current == 2 then
	varmenu.current = 3
	elseif varmenu.current == 3 then
	varmenu.current = 4
	elseif varmenu.current == 4 then
	varmenu.current = 5
	elseif varmenu.current == 5 then
	varmenu.current = 6
	elseif varmenu.current == 6 then
	varmenu.current = 7
	elseif varmenu.current == 7 then
	varmenu.current = 1
	end
	end
	if( input.IsKeyDown( KEY_UP ) ) then
	if varmenu.current == 7 then
	varmenu.current = 6
	elseif varmenu.current == 6 then
	varmenu.current = 5
	elseif varmenu.current == 5 then
	varmenu.current = 4
	elseif varmenu.current == 4 then
	varmenu.current = 3
	elseif varmenu.current == 3 then
	varmenu.current = 2
	elseif varmenu.current == 2 then
	varmenu.current = 1
	elseif varmenu.current == 1 then
	varmenu.current = 7
	end
	end
	if( input.IsKeyDown( KEY_RIGHT ) ) then
	if varmenu.current == 1 then
	if vH.aim == 1 then
	vH.aim = 0
	else
	vH.aim = 1
	end
	elseif varmenu.current == 2 then
	if vH.cross == 1 then
	vH.cross = 0
	else
	vH.cross = 1
	end
	elseif varmenu.current == 3 then
	if vH.esp == 1 then
	vH.esp = 0
	else
	vH.esp = 1
	end
	elseif varmenu.current == 4 then
	if vH.radar == 1 then
	vH.radar = 0
	else
	vH.radar = 1
	end
	elseif varmenu.current == 5 then
	if vH.nospread == 1 then
	vH.nospread = 2
	elseif vH.nospread == 2 then
	vH.nospread = 0
	else
	vH.nospread = 1
	end
	elseif varmenu.current == 6 then
	changenorecval()
	elseif varmenu.current == 7 then
	if vH.autoshoot == 1 then
	vH.autoshoot = 0
	else
	vH.autoshoot = 1
	end
	end
	end
	end
	end
KeyPress()