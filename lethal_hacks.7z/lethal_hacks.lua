function DermaCode()
concommand.Add("lethal_menu", DermaPanel)


local DermaPanel = vgui.Create( "DFrame" ) -- Frame
DermaPanel:SetPos( 50,50 ) -- Pos
DermaPanel:SetSize( 1000, 900 ) -- Size of frame
DermaPanel:SetTitle( "Lethal's Hack Menu" ) -- Title of the frame
DermaPanel:SetVisible( true )
DermaPanel:SetDraggable( true ) -- Something, K?
DermaPanel:ShowCloseButton( true ) -- Show the close button?
DermaPanel:MakePopup() -- Frame

local DermaButton1 = vgui.Create( "DButton" )
DermaButton:SetParent( DermaPanel ) -- Parent
DermaButton:SetText( "Suicide" )
DermaButton:SetPos( 25, 50 )
DermaButton:SetSize( 150, 50 )
DermaButton.DoClick = function ()
    RunConsoleCommand( "kill" ) -- Kill
end

local DermaButton2 = vgui.Create( "DButton" )
DermaButton:SetParent( DermaPanel ) -- Parent?
DermaButton:SetText( "Aimbot" )
DermaButton:SetPos( 25, 60 )
DermaButton:SetSize( 150, 50 )
DermaButton.DoClick = function ()
    RunConsoleCommand( "lethal_aimbot" ) -- Aimbot
end

local DermaButton3 = vgui.Create( "DButton" )
DermaButton:SetParent( DermaPanel ) -- Parent?
DermaButton:SetText( "Propkilling Boost" )
DermaButton:SetPos( 25, 70 )
DermaButton:SetSize( 150, 50 )
DermaButton.DoClick = function ()
    RunConsoleCommand( "lethal_rotate" ) -- Aimbot
concommand.Add("lethal_menu", DermaPanel)
CreatClientConVar("lethal_menu", "1", true, false)
	end
	