--[[
	lua/l33thack.lua
	SimpleIsTheBest | (STEAM_0:1:60333045)
	===DStream===
]]

/*
	gay copey pastey cheat v8
	
	credz:
	ph0ne
	fr1kin
	noPE
*/
if( !CLIENT ) then 
	return end
	
if( NYX ) then 
	_G['NYX'] = nil;
end

require( "nyx" );

_nyx['Init']();

local NYX 		= {};
NYX['keys']		= {};
NYX['detours']	= {};
NYX['hooks']	= {};
NYX['coners']	= {}; // heh boners
NYX['distance'] = 9999999999;
NYX['target']	= nil;
NYX['aimpos']	= Angle( 0, 0, 0 );
NYX['aiming']	= false;
NYX['speeding'] = false;
NYX['admins']	= false;
NYX['testing']	= false;

function NYX:BindKey( key, _var, _mouse )
    NYX['keys'][key] = { var = _var, mouse = _mouse };
end

NYX:BindKey( MOUSE_MIDDLE, 'admins', true );
NYX:BindKey( KEY_LALT, 'speeding', false );
NYX:BindKey( KEY_CAPSLOCK, 'aiming', false );
NYX:BindKey( KEY_F, 'testing', false ); // something i use when working on shit

surface['CreateFont']( "fonty", { font = "Lucida Console", size	= 12, antialias	= false } );

function NYX:IsAdmin( v )
	if( v:IsAdmin() 
	|| v:IsSuperAdmin() 
	|| v:IsUserGroup( "Admin" ) 
	|| v:IsUserGroup( "admin" ) 
	|| v:IsUserGroup( "Owner" ) 
	|| v:IsUserGroup( "owner" ) 
	|| v:IsUserGroup( "SuperAdmin" ) 
	|| v:IsUserGroup( "superadmin" ) 
	|| v:IsUserGroup( "Operator" ) 
	|| v:IsUserGroup( "operator" ) 
	|| v:IsUserGroup( "Moderator" ) 
	|| v:IsUserGroup( "moderator" ) ) then
		return true;
	end
	
	return false;
end

function NYX.Draw()
	local listpos = ScrH() / 3.5;
	
	for k, v in pairs( ents['GetAll']() ) do
		if( v:IsPlayer() ) then
			if( v:Alive() && v:Team() != TEAM_SPECTATOR && v != LocalPlayer() && !_nyx['IsDormant']( v:EntIndex() ) ) then
				local col	= ( v == NYX['target'] ) && Color( 255, 255, 255, 255 ) || Color( 10, 130, 255, 255 );
				
				if( v:GetFriendStatus() == "friend" ) then
					col = Color( 100, 255, 0, 255 );
				end
				
				local bot 		= ( v:GetPos() + Vector( 0, 0, 20 ) ):ToScreen();
				local top 		= ( v:GetPos() + Vector( 0, 0, 50 ) ):ToScreen();
				local height 	= ( bot['y'] - top['y'] );
				local width 	= ( height / 2 );
				surface['SetDrawColor']( col );
				surface['DrawOutlinedRect']( top['x'] - width, top['y'], width * 2, height );
				
				surface['SetDrawColor']( 0, 0, 0, 255 );
				surface['DrawOutlinedRect']( top['x'] - width - 1, top['y'] - 1, width * 2 + 2, height + 2 );
				surface['DrawOutlinedRect']( top['x'] - width + 1, top['y'] + 1, width * 2 - 2, height - 2 );
				
				draw['SimpleTextOutlined']( v:Nick(), "fonty", top['x'], top['y'] - 8, col, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, Color( 0, 0, 0, 255 ) );
			end
			
			if( !NYX['admins'] ) then
				if( v:GetObserverTarget() == LocalPlayer() ) then
					local col = ( NYX:IsAdmin( v ) ) && Color( 255, 80, 80, 255 ) || Color( 255, 255, 255, 255 );
					draw['SimpleTextOutlined']( v:Nick(), "fonty", 2, listpos, col, TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT, 1, Color( 0, 0, 0, 255 ) );
					
					listpos = listpos + 12;
				end
			else
				if( NYX:IsAdmin( v ) ) then
					draw['SimpleTextOutlined']( v:Nick(), "fonty", 2, listpos, Color( 255, 80, 80, 255 ), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT, 1, Color( 0, 0, 0, 255 ) );
					
					listpos = listpos + 12;
				end
			end
		else
			if( v['CanBuy'] ) then
				local pos = v:GetPos():ToScreen();
				local col;
				
				if( table['HasValue']( v['CanBuy'], ROLE_TRAITOR ) ) then
					col = Color( 255, 80, 80, 255 );
				else
					col = Color( 0, 100, 255, 255 );
				end
				
				local class = string['gsub']( v:GetClass(), "weapon_ttt_", "" );
				draw['SimpleTextOutlined']( class, "fonty", pos['x'], pos['y'], col, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, Color( 0, 0, 0, 255 ) );
			end
		end
	end
end

NYX['attachments'] =
{
	"eyes",
	"forward",
	"head",
};

function NYX:GetAimPos( e )
	for k, v in pairs( NYX['attachments'] ) do
		if( e:LookupAttachment( v ) ) then
			local att = e:GetAttachment( e:LookupAttachment( v ) );
			if( att ) then
				return att['Pos'];
			end
		end
	end
	
	return ( e:LocalToWorld( e:OBBCenter() ) );
end

function NYX:IsVisible( v )
	local tracedata = 
	{ 
		start 	= LocalPlayer():GetShootPos(),
		endpos 	= NYX:GetAimPos( v ), 
		filter 	= { LocalPlayer(), v },
		mask 	= MASK_SHOT 
	};
						
	local trace = util['TraceLine']( tracedata );
	
	return ( trace['Fraction'] == 1 );
end

function NYX:ValidTarget( v )
	if( _nyx['IsDormant']( v:EntIndex() ) ) then
		return false;
	end
	
	if( !v:Alive() ) then
		return false;
	end 
	
	if( v:Team() == TEAM_SPECTATOR ) then
		return false;
	end
	
	if( v == LocalPlayer() ) then
		return false;
	end
	
	if( v:GetFriendStatus() == "friend" ) then
		return false;
	end
	
	if( string['find']( string['lower']( GAMEMODE['Name'] ), "trouble in terror" ) ) then
		if( v:IsTraitor() ) then
			return false;
		end
	end
	
	local col = v:GetColor();
	
	if( string['find']( string['lower']( GAMEMODE['Name'] ), "stronghold" ) ) then
		if( col['a'] < 255 ) then
			return false;
		end
	end
	
	if( !NYX:IsVisible( v ) ) then
		return false;
	end
	
	return true;
end

function NYX:FindTarget()
	// reset aim data before looping through players
	NYX['target'] 	= nil;
	NYX['distance'] = 9999999;
	
	if( !NYX['aiming'] ) then
		return end
		
	for k, v in pairs( player['GetAll']() ) do
		if( NYX:ValidTarget( v ) ) then
			local distance = math['deg']( math['acos']( LocalPlayer():GetAimVector():Dot( ( NYX:GetAimPos( v ) - LocalPlayer():GetShootPos() ):GetNormal() ) ) );
			if( distance < NYX['distance'] ) then
				NYX['target'] 	= v;
				NYX['distance'] = distance;
				local pred;
				
				if( !NYX['testing'] ) then
					pred = ( ( v:GetVelocity() / 50 - LocalPlayer():GetVelocity() / 50 ) - Vector( 0, 0, 0 ) );
				else
					pred = ( v:GetVelocity() * v:GetPos():Distance( LocalPlayer():GetPos() ) / 3110 );
				end
				
				local pos = NYX:GetAimPos( v )
				
				NYX['aimpos'] 	= ( ( pos + pred ) - LocalPlayer():EyePos() ):Angle();
					
				NYX['aimpos']['p'] = math['NormalizeAngle']( NYX['aimpos']['p'] );
				NYX['aimpos']['y'] = math['NormalizeAngle']( NYX['aimpos']['y'] );
				NYX['aimpos']['r'] = 0;
			end
		end
	end
end

function NYX:KeyEvent()
    for k, v in pairs( NYX['keys'] ) do
        if( v['mouse'] ) then
			if( input['IsMouseDown']( k ) ) then
				NYX[v['var']] = true;
			else
				NYX[v['var']] = false;
			end
		else
			if( input['IsKeyDown']( k ) ) then
				NYX[v['var']] = true;
			else
				NYX[v['var']] = false;
			end
		end
			
    end
end

function NYX.Think()
	NYX:FindTarget();
	NYX:KeyEvent();
end

function NYX.CalcView( ply, origin, angles, fov )
	local view = GAMEMODE:CalcView( ply, origin, angles, fov ) || {};
	// i'll do something with this later
	return view;
end

function NYX:Detour( old, new )
	NYX['detours'][new] = old;
	return new;
end

local _R = debug['getregistry'](); // sdfsdfsdfsd

_R['Entity']['FireBullets'] = NYX:Detour( _R['Entity']['FireBullets'], function( ent, bullet )
	NYX['coners'][LocalPlayer():GetActiveWeapon():GetPrintName()] = bullet['Spread'];
	return NYX['detours'][_R['Entity']['FireBullets']]( ent, bullet );
end )

//_G['hook']['Call'] = NYX:Detour( _G['hook']['Call'], function( name, gm, ... )
//	MsgN( name );
//	return NYX['detours'][_G['hook']['Call']]( name, gm, ... );
//end )

NYX['cones'] = 
{
	["#HL2_SMG1"] 			= Vector( -0.04362, -0.04362, -0.04362 ),
	["#HL2_Pistol"] 		= Vector( -0.0100, -0.0100, -0.0100 ),
	["#HL2_Pulse_Rifle"] 	= Vector( -0.02618, -0.02618, -0.02618 ),
	["#HL2_Shotgun"] 		= Vector( -0.08716, -0.08716, -0.08716 ),
};

function NYX:NoSpread( cmd, ang )
	wep 				= LocalPlayer():GetActiveWeapon();
	vecCone, valCone 	= Vector( 0, 0, 0 );
	
	if( wep:IsValid() ) then
		if( NYX['coners'][wep:GetPrintName()] ) then
			valCone = NYX['coners'][wep:GetPrintName()];
			if( tonumber( valCone ) ) then
				vecCone =  Vector( -valCone, -valCone, -valCone );
			elseif( type( valCone ) == "Vector" ) then
				vecCone = -1 * valCone;
			end
		else
			if( NYX['cones'][wep:GetPrintName()] ) then 
				vecCone = NYX['cones'][wep:GetPrintName()]; 
			end
		end
	end
	
	return ( _nyx['RemoveSpread']( cmd, ang, vecCone ) ):Angle();
end

function NYX.CreateMove( cmd )
	if( NYX['aiming'] && NYX['target'] ) then
		local ang = NYX:NoSpread( cmd, NYX['aimpos'] )
		
		ang['p'] = math['NormalizeAngle']( ang['p'] );
		ang['y'] = math['NormalizeAngle']( ang['y'] );
		ang['r'] = 0;
		
		_nyx['SetViewAngles']( cmd, ang );
		
		cmd:SetButtons( bit['bor']( cmd:GetButtons(), IN_ATTACK ) );
	end
	
	_nyx['Bunnyhop']( cmd, LocalPlayer():IsOnGround(), LocalPlayer():GetMoveType() );
	
	_nyx['Speedhack']( NYX['speeding'] );
end

// detouring hook.Call/Run wasn't working for all hooks so i'm settling for this
function NYX:AddHook( name, callback )
	local gay = tostring( math['random']( 0.666, 666 ) * math['random']( 0.666, 666 ) ); // 666 hail satan my parents dont understand me fuck the system
    hook['Add']( name, gay, callback );
end

NYX:AddHook( "DrawOverlay", NYX['Draw'] );
NYX:AddHook( "Think", NYX['Think'] );
NYX:AddHook( "CalcView", NYX['CalcView'] );
NYX:AddHook( "CreateMove", NYX['CreateMove'] );