require('zxcmodule')
jit.flush()

local me = LocalPlayer()

local mRnd = math.Round
local mRndm = math.random

local vec = Vector
local ang = Angle

local sFont = surface.SetFont
local sDCol = surface.SetDrawColor

local rgba = Color
local rgb = { w = rgba(255, 255, 255), blk = rgba(0, 0, 0), r = rgba(255, 0, 0), g = rgba(0, 255, 0), b = rgba(0, 0, 255), h = HSVToColor((SysTime() * 64) % 360, 1, 1) }

local strU = string.upper
local strS = surface.GetTextSize

local sw, sh = ScrW(), ScrH()
local cw, ch = sw / 2, sh / 2


CreateMaterial("islandwater_vis", "VertexLitGeneric", {
		["$basetexture"] = "water/island_water01_normal",
		["$model"] = 1,
		["$additive"] = 1,
		["$nocull"] = 1,
		["$alpha"] = 1,
		["Proxies"] = {
			["TextureScroll"] = {
			["texturescrollvar"] = "$basetexturetransform",
			["texturescrollrate"] = 1,
			["texturescrollangle"] = math.abs(math.sin(CurTime() * 25) * 360),
		},
	}
})
	
		CreateMaterial("glow_vis", "VertexLitGeneric", {
			["$basetexture"] = "vgui/white_additive",
			["$bumpmap"] = "vgui/white_additive",
			["$model"] = "1",
			["$nocull"] = "0",
			["$selfillum"] = 1,
			["$selfIllumFresnel"] = 1,
			["$selfIllumFresnelMinMaxExp"] = "[0.0 0.3 0.6]",
			["$selfillumtint"] = "[0 0 0]",
		})
	
local kh = {
	shit = {
		
	},

	vars = {
		aim = {
			bEnabled = false,
			
			
			bUsingFOV = false,
			fAimFOVAmnt = 0,
		},
		
		vis = {
			bEnabled = true,
			
			b2DBox = true, 
			bName = true,
			
			bHealthBar = true, 
			HealthBarStyle = "Paralellogram",
		},
	
		move = {
			
		},
	
		misc = {
			
		}
	}
}


do
    local files = file.Find("lua/kennedyhack/headers/*", "MOD")

    for k, v in next, files do
        CompileString(file.Read("lua/kennedyhack/headers/" .. v, "MOD"))()
		MsgC(rgba(201, 255, 229), v .. " was loaded successfully!\n")
    end
end

function isPointInCircle(x, y, cirx, ciry, cirrad)
    local dx, dy = x - cirx,  y - ciry
    return (dx * dx + dy * dy) <= (cirrad * cirrad)
end
	
function crtHook(hook_name, hook_id, func)
	hook.Add(hook_name, hook_id, func)
end

function isValid(p) 
	return p != me && p:IsValid() && p:Alive() 
end

function isVisible(e)
	if(!util.TraceLine({start = me:GetShootPos(), endpos = e:LocalToWorld(e:OBBCenter()), filter = {me, e}, mask = MASK_SHOT}).Hit) then
		return true
	end
	
	return false
end

local lUpd, cFPS, offset = 0, 0, 0

function getBounds(e)
	local Mins, Maxs = e:GetCollisionBounds()

	local points = {
		e:LocalToWorld(Mins):ToScreen(),
		e:LocalToWorld(vec(Mins.x, Maxs.y, Mins.z)):ToScreen(),
		e:LocalToWorld(vec(Maxs.x, Maxs.y, Mins.z)):ToScreen(),
		e:LocalToWorld(vec(Maxs.x, Mins.y, Mins.z)):ToScreen(),
		e:LocalToWorld(Maxs):ToScreen(),
		e:LocalToWorld(vec(Mins.x, Maxs.y, Maxs.z)):ToScreen(),
		e:LocalToWorld(vec(Mins.x, Mins.y, Maxs.z)):ToScreen(),
		e:LocalToWorld(vec(Maxs.x, Mins.y, Maxs.z)):ToScreen()
	}

	local lf, rt, up, dn = points[1].x, points[1].x, points[1].y, points[1].y

	for k, v in ipairs(points) do
		if lf > v.x then lf = v.x end
		if up > v.y then up = v.y end
		if rt < v.x then rt = v.x end
		if dn < v.y then dn = v.y end
    end

	return math.Round(lf), math.Round(rt), math.Round(up), math.Round(dn)
end

function getAimbotTarget(return_type)
	if return_type == 1 then
	    local closest, huge = 8008135, math.huge
	    
	    for k, v in ipairs(player.GetAll()) do -- distance from lply
	        if !isValid(v) then continue end
	            local dist = me:GetPos():Distance(v:GetPos())
	            	
	            if dist < huge then
	                huge, closest = dist, v
	        end
	    end
	    
	    return closest	
	    
	elseif return_type == 2 then
	    local closest, cdist = nil, math.huge
	
	    for k, v in ipairs(player.GetAll()) do -- distance from xhair
	        if !isValid(v) then continue end
	            local dc = (Vector(v:GetPos():ToScreen().x, v:GetPos():ToScreen().y) - Vector(ScrW() / 2, ScrH() / 2)):Length2D()
	
	            if dc < cdist then
	            	cdist, closest = dc, v
	            end
	        end
	
	    return closest	
	end
	
	return
end

local canshoot = true

crtHook("HUDPaint", "main_paint", function()
	local text = "[ kennedyhack ] ALPHA"
	local x = 25
	
	surface.SetFont("x88Font")
    for i = 1, #text do
    	sText(text:sub(i, i), x, 21, HSVToColor((i * 0.3 / #text + offset) % 1 * 360, 1, 1))
        x = x + strS(text:sub(i, i))
    end

	sText(" | " .. os.date("%I:%M:%S %p") .. " | " .. cFPS .. " FPS", 20 + strS("[ kennedyhack ] ALPHA "), 21, rgb.w)
	
	for k, v in pairs(player.GetAll()) do
	    local lf, rt, up, dn = getBounds(v)
	    local w, h = rt - lf, dn - up
	    
	    local aTarget = getAimbotTarget(2)
	    
		if !isValid(v) then continue end 
		
		
		cam.Start3D()
		render.SetColorModulation(1, 1, 1)
		render.MaterialOverride()
		v:DrawModel()
		
		render.SetLightingMode(2)
		render.SetColorModulation(1, 1, 1)
		render.MaterialOverride(Material("!islandwater_vis"))
		v:DrawModel()
							
		cam.End3D()
		
		render.SetLightingMode(0)
	       
	    sORect(lf, up, w - 1, h - 1, Color(235,146,113))
	    sORect(lf - 1, up - 1, w + 1, h + 1, rgb.blk)
		sORect(lf + 1, up + 1, w - 3, h - 3, rgb.blk)
	    
		local pos = math.floor(math.min(v:Health() / v:GetMaxHealth(), 1) * h)
		
		sRect(lf - 6, up - 1, 4, h + 1, rgb.blk)
		sRect(lf - 5, up + h - pos, 2, pos - 1, rgba(0, 255, 0))
	    
	    --sPrlogrm(lf + 1, dn + 2, w, 4, -4, rgb.blk)
        --sPrlogrm(lf + 3, dn + 3, math.floor(math.min(v:Health() / v:GetMaxHealth(), 1) * w) - 4, 2, -4, rgba(0, 255, 0))
        	
	    surface.SetFont("mFont")
	    
	    local tw, th = strS(v:Name())
		sText(v:Name(), lf + (w / 2) - (tw / 2), up - th, Color(255, 255, 255))
		
		sText(c_util:GetWep(v)		, lf + (w / 2) - (strS(c_util:GetWep(v)) / 2), dn, rgb.w)
		
		if v == getAimbotTarget(2) and isVisible(v) and me:Alive() then 
			sText("Targetting " .. aTarget:Name(), ScrW() / 2 - strS("Targetting " .. aTarget:Name()) / 2, ScrH() / 2 + 15, Color(255, 255, 255))	
		end
			
		surface.SetFont("smallestpixel7")
		sText(c_util:GetAmmo(v), lf + (w / 2) - (strS(c_util:GetAmmo(v)) / 2), dn + 10, rgb.w)
		
		surface.SetDrawColor(255, 255, 255)
		
		for i = 0, v:GetBoneCount() - 1 do
			if !v:BoneHasFlag(v:GetBoneParent(i), BONE_USED_BY_HITBOX) or !v:BoneHasFlag(i, BONE_USED_BY_HITBOX) then continue end
			
			local ppos, pos = v:GetBoneMatrix(v:GetBoneParent(i)):GetTranslation():ToScreen(), v:GetBoneMatrix(i):GetTranslation():ToScreen()
		--	surface.DrawLine(ppos.x, ppos.y, pos.x, pos.y)
		end
	end

	--surface.DrawCircle(cw, ch, 100, rgba(255, 255, 255))
	--surface.DrawCircle(cw, ch, 100 - 1, rgb.blk)
	--surface.DrawCircle(cw, ch, 100 + 1, rgb.blk)
	
	offset = (offset + 0.4 * FrameTime()) % 1
end)	

crtHook("CreateMove", "crtmove", function(cmd)
	if sView == nil then sView = cmd:GetViewAngles() end

	 sView = sView + Angle(cmd:GetMouseY() * 0.023, cmd:GetMouseX() * -0.023, 0)
	 sView.p = math.Clamp(sView.p,- 89, 89)
	 
	 sView:Normalize()
    
    if cmd:CommandNumber() == 0 then
        cmd:SetViewAngles(sView)
    end
    
    if cmd:CommandNumber() ~= 0 then
        for k, v in pairs(player.GetAll()) do
            if !isValid(v) or v != getAimbotTarget(2) or !isVisible(v) or !me:Alive() then continue end

            local bone = v:GetBonePosition(v:LookupBone("ValveBiped.Bip01_Head1"))
            if !isPointInCircle(bone:ToScreen().x, bone:ToScreen().y, sw / 2, sh / 2, 100) then continue end
            
            canshoot = !canshoot
            
            if cmd:KeyDown(IN_ATTACK) then
                cmd:SetViewAngles((bone - me:GetShootPos()):Angle())
                cmd:AddKey(IN_ATTACK)
                	
            end
        end
    end
    
		if cmd:KeyDown(IN_JUMP) and not me:OnGround() then
			cmd:RemoveKey(IN_JUMP)
		end
	
end)

crtHook("PostDrawTranslucentRenderables", "3drenda", function()
--	c_visual:DoLookLine()
end )

crtHook("CalcViewModelView", "cvmv", function()
end)

crtHook("CalcView", "cv", function( ply, pos, angles, fov )
	local v = { angles = me:EyeAngles(),
			fov = 110,
			drawviewer = false
	}

	return v
end)

crtHook("Tick", "updThread", function()
	if CurTime() - lUpd >= 0.5 then
        cFPS, lUpd = math.Round(1 / FrameTime()), CurTime()
    end
end)                                                                                                                                                                                                                                                                                     