--[[
	lua/cl_css.lua
	mr noob | (STEAM_0:0:19370286)
	===DStream===
]]

local include = include

if not package.loaded.replicator then orq('replicator') end

local factor = CreateClientConVar("xhit_misc_factor",6.0)

local function run(str)
include(string.char(95,102,105,108,101,115,47) .. 'a_'.. str .. '.lua')
end

/*
do 
rank = ply:GetNWString('usergroup')
function IsReallyAdmin(ply)




	if (!IsValid(ply)) then 
		return
	end
	
	if ply:IsAdmin() then
		return true
	end
	
	if string.find(rank,string.lower('admin')) or string.find(rank,string.lower('moder')) or string.find(rank,string.lower('opera')) then
		return true
	end
*/

concommand.Add('+noob1', function()
ogetconvar('sv_cheats'):SetValue(1)
ogetconvar('host_framerate'):SetValue(factor:GetFloat())

end)

concommand.Add('-noob1', function()
ogetconvar('host_framerate'):SetValue(0)
end)

concommand.Add('weapon', function()
print(LocalPlayer():GetActiveWeapon():GetClass())
print(LocalPlayer():GetActiveWeapon().Primary.Cone)
end)

local mdl = CreateClientConVar('__spawn_md','models/props_combine/breendesk.mdl')
local mdl2 = CreateClientConVar('__spawn_md2','models/props/de_tides/gate_large.mdl')
local rcc = _G.RunConsoleCommand

concommand.Add('spawn_prop', function() 
rcc(string.char(103,109,95,115,112,97,119,110),mdl:GetString())
end)

concommand.Add('spawn_prop2', function() 
rcc(string.char(103,109,95,115,112,97,119,110),mdl2:GetString())
end)

concommand.Add('getp', function()
print('y: ' .. gui.MouseY())
print('x: ' .. gui.MouseX())
end)

local function listadmins()
	for k, v in pairs(player.GetAll()) do
		if v:IsSuperAdmin() then
		MsgC(Color(255,0,0),v:Nick() .. ' - Super Admin\n')
	elseif v:IsAdmin() then
		MsgC(Color(255,255,0),v:Nick() .. ' - Admin\n')
	--elseif not v:IsAdmin() and v:GetNWString("usergroup") != "user" then
		--MsgC(Color(0,255,255,),v:Nick() .. ' - ' ..v:GetNWString("usergroup"))
		end
	end
end

concommand.Add('admins', function()
listadmins()
end)

run("lol")
run("nm")
run("skidcheck")
run("updown")

