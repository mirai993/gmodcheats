--[[
	lua/cl_simplehack.lua
	SimpleIsTheBest | (STEAM_0:1:60333045)
	===DStream===
]]

if ( SERVER ) then return end

require("cvar3")

local cvar2 = {}
cvar2.SetValue = function(var, value)
	GetConVar(var):SetValue(value)
end

print('RAINBOWS')
local Colors				= {}
Red							= Color(255,0,0,255);
Black						= Color(0,0,0,255);
Green						= Color(0,255,0,255);
White						= Color(255,255,255,255);
Blue						= Color(0,0,255,255);
Cyan						= Color(0,255,255,255);
Pink 						= Color(255,0,255,255);
Blue						= Color(0,0,255,255);
Grey						= Color(100,100,100,255);
Gold						= Color(255,228,0,255);
Lblue						= Color(155,205,248);
Lgreen						= Color(174,255,0);
Iceblue						= Color(116,187,251,255);


local _G					= table.Copy(_G)

local math 					= _G.math
local string 				= _G.string
local hook 					= _G.hook
local table 				= _G.table
local timer 				= _G.timer
local surface 				= _G.surface
local concommand 			= _G.concommand
local cvars 				= _G.cvars
local ents 					= _G.ents
local player 				= _G.player
local team 					= _G.team
local util 					= _G.util
local draw 					= _G.draw
local usermessage 			= _G.usermessage
local vgui 					= _G.vgui
local http 					= _G.http
local cam 					= _G.cam
local render 				= _G.render

local MsgN 					= _G.MsgN
local Msg 					= _G.Msg
local Vector 				= _G.Vector
local Angle 				= _G.Angle
local pairs 				= _G.pairs
local ipairs 				= _G.ipairs
local CreateSound 			= _G.CreateSound
local setmetatable 			= _G.setmetatable
local Sound 				= _G.Sound
local print 				= _G.print
local pcall 				= _G.pcall
local type 					= _G.type
local LocalPlayer 			= _G.LocalPlayer
local KeyValuesToTable 		= _G.KeyValuesToTable
local TableToKeyValues 		= _G.TableToKeyValues
local Color 				= _G.Color
local CreateClientConVar 	= _G.CreateClientConVar
local ErrorNoHalt 			= _G.ErrorNoHalt
local IsValid 				= _G.IsValid
local CreateMaterial 		= _G.CreateMaterial
local tonumber 				= _G.tonumber
local tostring 				= _G.tostring
local CurTime			 	= _G.CurTime
local FrameTime 			= _G.FrameTime
local ScrW 					= _G.ScrW
local ScrH 					= _G.ScrH
local SetClipboardText 		= _G.SetClipboardText
local GetHostName 			= _G.GetHostName
local unpack 				= _G.unpack
local AddConsoleCommand 	= _G.AddConsoleCommand 
local require				= _G.require
local include				= _G.include

local MOVETYPE_OBSERVER 	= _G.MOVETYPE_OBSERVER
local MOVETYPE_NONE 		= _G.MOVETYPE_NONE
local TEXT_ALIGN_LEFT 		= _G.TEXT_ALIGN_LEFT
local TEXT_ALIGN_TOP 		= _G.TEXT_ALIGN_TOP
local TEXT_ALIGN_RIGHT 		= _G.TEXT_ALIGN_RIGHT
local TEXT_ALIGN_BOTTOM		= _G.TEXT_ALIGN_BOTTOM
local IN_JUMP 				= _G.IN_JUMP
local IN_FORWARD 			= _G.IN_FORWARD
local IN_BACK 				= _G.IN_BACK
local IN_MOVERIGHT 			= _G.IN_MOVERIGHT
local IN_MOVELEFT 			= _G.IN_MOVELEFT
local IN_SPEED 				= _G.IN_SPEED
local IN_DUCK 				= _G.IN_DUCK
local TEAM_SPECTATOR 		= 1002

-- old [copy]
local old_filecdir 			= file.CreateDir;
local old_filedel 			= file.Delete;
local old_fileexist 		= file.Exists;
local old_fileexistex 		= file.ExistsEx;
local old_filefind 			= file.Find;
local old_filefinddir 		= file.FindDir;
local old_filefindil 		= file.FindInLua;
local old_fileisdir			= file.IsDir;
local old_fileread 			= file.Read;
local old_filerename 		= file.Rename;
local old_filesize 			= file.Size;
local old_filetfind			= file.TFind;
local old_filetime 			= file.Time;
local old_filewrite 		= file.Write;
local old_dbginfo 			= debug.getinfo;
local old_dbginfo 			= debug.getupvalue;
local old_cve 				= ConVarExists;
local old_gcv 				= GetConVar;
local old_gcvn 				= GetConVarNumber;
local old_gcvs 				= GetConVarString;
local old_rcc 				= RunConsoleCommand;
local old_hookadd			= hook.Add;
local old_hookrem 			= hook.Remove;
local old_ccadd				= concommand.Add;
local old_ccrem 			= concommand.Remove;
local old_cvaracc 			= cvars.AddChangeCallback;
local old_cvargcvc 			= cvars.GetConVarCallbacks;
local old_cvarchange 		= cvars.OnConVarChanged;
local old_require			= require;
local old_eccommand 		= engineConsoleCommand;

local Simple = {}

local info		= CreateClientConVar('Simple_ESP_Info', 					0, true, false)
local box 		= CreateClientConVar('Simple_ESP_Box', 						0, true, false)
local box 		= CreateClientConVar('Simple_ESP_Skeleton', 				0, true, false)
local box 		= CreateClientConVar('Simple_ESP_Tracer', 					0, true, false)
local cross		= CreateClientConVar('Simple_ESP_Crosshair',		 		0, true, false)
local ctype		= CreateClientConVar('Simple_ESP_Crosshair_Type',			"Dot", true, false)
local ctype		= CreateClientConVar('Simple_ESP_Ents',						0, true, false)
local ctype		= CreateClientConVar('Simple_ESP_ESPDistance',				1000, true, false)
local ctype		= CreateClientConVar('Simple_esp_visiblecheck',				1, true, false)

local playerm   = CreateClientConVar('Simple_RENDER_PlayerModel',		 	0, true, false)
local chams 	= CreateClientConVar('Simple_RENDER_Chams',		 			0, true, false)

local bunny		= CreateClientConVar('Simple_MISC_Bunnyhop',		 		0, true, false)


local recoil	= CreateClientConVar('Simple_Remove_Recoil',		 		0, true, false)
local skybox	= CreateClientConVar('Simple_Remove_SkyBox',		 		0, true, false)

local Cheats 	= CreateClientConVar('Simple_Bypass_Cheats',		 		0, true, false)
local Bright 	= CreateClientConVar('Simple_Bypass_Fullbright',		 	0, true, false)

local Speed 	= CreateClientConVar('Simple_Speed_speed',	3.5, true, false)

-- Fonts
surface.CreateFont("Trebuchet19gh",		 		{font= "TabLarge", size=13, weight=700})
surface.CreateFont("ESPFont",					{font = "ScoreboardText", size = 17, weight = 0, antialias = 0})
surface.CreateFont("ESPFont_Small",				{font = "Default", size = 12, weight = 200, antialias = 0})
surface.CreateFont("Logo",						{font = "akbar", size = 21, weight = 400, antialias = 0})
surface.CreateFont("Simple_ScoreboardText",		{font = "ScoreboardText", size = 15, weight = 700, antialias = 0})
surface.CreateFont("Simple_coolvetica",			{font = "coolvetica", size = 16, weight = 500, antialias = 0})
surface.CreateFont("Simple_hvh",				{font = "ScoreboardTextt", size = 15, weight = 1000, antialias = 1})
surface.CreateFont("OutLine",					{font = "DefaultFixedOutline", size = 14, weight = 400, antialias = 1})

--Crosshair
local x = ScrW() / 2 --Crosshair
local y = ScrH() / 2 --Crosshair
local gap = 0 --Crosshair Gap
local length = 5 --Crosshair Length

Simple.ents					= { -- ents to be picked up by entity esp, add more if you want.
"ent_pot",
"npc_vendor",
"weapon_perp_glock",
"ent_item",
"ent_prop_item",
"sent_spawnpoint",
"spawned_weapon",
"spawned_shipment",
"weed_plant",
"gift",
"spawned_money",
"base_item",
"weapon_mad_m4",
"weapon_mad_deagle",
"weapon_mad_ak47",
"sapphire_money_printer",
"amethyst_money_printer",
"topaz_money_printer",
"emerald_money_printer",
"msc_scrapnug",
"food_rawant",
"ent_resource",
"food_rawhead",
"gmodz_item", -- TPS DayZ
"drug_plant",
}

/*************************
Name: CreatePos
Purpose: Create a position
Credits: BaconBot
***************************/
print('Pos on your mom!')
function CreatePos(v)
local ply = LocalPlayer()
local center = v:LocalToWorld( v:OBBCenter() )
local min, max = v:OBBMins(), v:OBBMaxs()
local dim = max - min	local z = max + min	
local frt	= ( v:GetForward() ) * ( dim.y / 2 )
local rgt	= ( v:GetRight() ) * ( dim.x / 2 )
local top	= ( v:GetUp() ) * ( dim.z / 2 )
local bak	= ( v:GetForward() * -1 ) * ( dim.y / 2 )
local lft	= ( v:GetRight() * -1 ) * ( dim.x / 2 )
local btm	= ( v:GetUp() * -1 ) * ( dim.z / 2 )
local s = 1
local FRT 	= center + frt / s + rgt / s + top / s; FRT = FRT:ToScreen()
local BLB 	= center + bak / s + lft / s + btm / s; BLB = BLB:ToScreen()
local FLT	= center + frt / s + lft / s + top / s; FLT = FLT:ToScreen()
local BRT 	= center + bak / s + rgt / s + top / s; BRT = BRT:ToScreen()
local BLT 	= center + bak / s + lft / s + top / s; BLT = BLT:ToScreen()
local FRB 	= center + frt / s + rgt / s + btm / s; FRB = FRB:ToScreen()
local FLB 	= center + frt / s + lft / s + btm / s; FLB = FLB:ToScreen()
local BRB 	= center + bak / s + rgt / s + btm / s; BRB = BRB:ToScreen()	
local z = 100
if ( v:Health() <= 50 ) then z = 100 end
local x, y = ( ( v:Health() / 100 ) ), 1
if ( v:Health() <= 0 ) then x = 1 end
local FRT3 	= center + frt + rgt + top / x; FRT3 = FRT3; FRT3 = FRT3:ToScreen()
local BLB3 	= center + bak + lft + btm / x; BLB3 = BLB3; BLB3 = BLB3:ToScreen()
local FLT3	= center + frt + lft + top / x; FLT3 = FLT3; FLT3 = FLT3:ToScreen()
local BRT3 	= center + bak + rgt + top / x; BRT3 = BRT3; BRT3 = BRT3:ToScreen()
local BLT3 	= center + bak + lft + top / x; BLT3 = BLT3; BLT3 = BLT3:ToScreen()
local FRB3 	= center + frt + rgt + btm / x; FRB3 = FRB3; FRB3 = FRB3:ToScreen()
local FLB3 	= center + frt + lft + btm / x; FLB3 = FLB3; FLB3 = FLB3:ToScreen()
local BRB3 	= center + bak + rgt + btm / x; BRB3 = BRB3; BRB3 = BRB3:ToScreen()	
local x, y, z = 1.1, 0.9, 1
local FRT2 	= center + frt / y + rgt / z + top / x; FRT2 = FRT2:ToScreen()
local BLB2 	= center + bak / y + lft / z + btm / x; BLB2 = BLB2:ToScreen()
local FLT2	= center + frt / y + lft / z + top / x; FLT2 = FLT2:ToScreen()
local BRT2 	= center + bak / y + rgt / z + top / x; BRT2 = BRT2:ToScreen()
local BLT2 	= center + bak / y + lft / z + top / x; BLT2 = BLT2:ToScreen()
local FRB2 	= center + frt / y + rgt / z + btm / x; FRB2 = FRB2:ToScreen()
local FLB2 	= center + frt / y + lft / z + btm / x; FLB2 = FLB2:ToScreen()
local BRB2 	= center + bak / y + rgt / z + btm / x; BRB2 = BRB2:ToScreen()	
local maxX = math.max( FRT.x,BLB.x,FLT.x,BRT.x,BLT.x,FRB.x,FLB.x,BRB.x )
local minX = math.min( FRT.x,BLB.x,FLT.x,BRT.x,BLT.x,FRB.x,FLB.x,BRB.x )
local maxY = math.max( FRT.y,BLB.y,FLT.y,BRT.y,BLT.y,FRB.y,FLB.y,BRB.y )
local minY = math.min( FRT.y,BLB.y,FLT.y,BRT.y,BLT.y,FRB.y,FLB.y,BRB.y )
local minYhp2 = math.min( FRT.y,BLB.y,FLT.y,BRT.y,BLT.y,FRB.y,FLB.y,BRB.y )
local maxXhp = math.max( FRT3.x,BLB3.x,FLT3.x,BRT3.x,BLT3.x,FRB3.x,FLB3.x,BRB3.x )
local minXhp = math.min( FRT3.x,BLB3.x,FLT3.x,BRT3.x,BLT3.x,FRB3.x,FLB3.x,BRB3.x )
local maxYhp = math.max( FRT3.y,BLB3.y,FLT3.y,BRT3.y,BLT3.y,FRB3.y,FLB3.y,BRB3.y )
local minYhp = math.min( FRT3.y,BLB3.y,FLT3.y,BRT3.y,BLT3.y,FRB3.y,FLB3.y,BRB3.y )	
local maxX2 = math.max( FRT2.x,BLB2.x,FLT2.x,BRT2.x,BLT2.x,FRB2.x,FLB2.x,BRB2.x )
local minX2 = math.min( FRT2.x,BLB2.x,FLT2.x,BRT2.x,BLT2.x,FRB2.x,FLB2.x,BRB2.x )
local maxY2 = math.max( FRT2.y,BLB2.y,FLT2.y,BRT2.y,BLT2.y,FRB2.y,FLB2.y,BRB2.y )
local minY2 = math.min( FRT2.y,BLB2.y,FLT2.y,BRT2.y,BLT2.y,FRB2.y,FLB2.y,BRB2.y )
return maxX, minX, maxY, minY, maxX2, minX2, maxY2, minY2, minYhp, maxYhp
end

/*
Name: Custom ENT
*/
function IsCustomEnt( entclass )
	return table.HasValue( Simple.ents, entclass )
end

/*************************************
Name: PlayerVisible
Purpose: Check if a player is visible
*************************************/
local function CanSee(ent)    
	local tr = {};	
	tr.start = LocalPlayer():GetShootPos();
	tr.endpos = ent:GetPos() + Vector(0, 0, 5)
	tr.filter = {LocalPlayer(), ent};
	tr.mask = MASK_SHOT;	
    local trace = util.TraceLine(tr) ;
    if (trace.Fraction == 1) then 
        return true;
    else 
        return false; 
    end     
end

-- OnScreen and IsCloseEnough check
function OnScreen(ent)
	local a, f = debug.getregistry().Player["GetAimVector"](LocalPlayer()):Angle() - (ent:GetPos() - LocalPlayer():GetShootPos()):Angle(), debug.getregistry().Player["GetFOV"](LocalPlayer())	
	return (math.NormalizeAngle(a.y) < f + 2 && math.NormalizeAngle(a.p) < f + 2)
end
function IsCloseEnough(ent)
	local dist = ent:GetPos():Distance( LocalPlayer():GetPos() )
	if( dist <= GetConVarNumber("Simple_ESP_ESPDistance") and ent:GetPos() != Vector( 0, 0, 0 ) ) and OnScreen(ent) then
		return true
	end
	return false	
end

-- Visible Check
local function GetBoxColor(e)
	if( GetConVarNumber("Simple_esp_visiblecheck") == 1 ) then
		if CanSee(e) then
			return Color(0,255,0)
		elseif !CanSee(e) then
			return Color(255,0,0)
		end
	end
end

/*************************
Name: Derma shit
Purpose: Anything Derma
***************************/
function AddCheckBox( text, cvar, parent, x, y, tt )
local checkbox = vgui.Create( "DCheckBoxLabel", parent )
checkbox:SetPos( x, y )
checkbox:SetText( text )
checkbox:SetConVar( cvar )
checkbox:SetTextColor(white)
checkbox:SetTooltip( tt or "No Tool Tip" )
checkbox:SizeToContents()	
end

// AddSlider for the derma
function AddSlider( text, cvar, parent, min, max, decimals, x, y, wide, tt )
local slider = vgui.Create( "DNumSlider" )
slider:SetParent( parent )
slider:SetPos( x, y )
slider:SetWide( wide )
slider:SetText( text )
--slider:SetTextColor(BLACK)
slider:SetMin( min ) 
slider:SetMax( max ) 
slider:SetDecimals( decimals ) 
slider:SetConVar( cvar )
slider:SetTooltip( tt or "No Tool Tip" )
end

Gradient = surface.GetTextureID( "gui/gradient" )
function DrawBox( x, y, wide, tall, dropsize )
	draw.RoundedBoxEx( 4, x, y, wide, dropsize, iceblue, true, true, false, false )
	draw.RoundedBoxEx( 4, x, y + dropsize, wide, tall - dropsize, Color( 0, 0, 0, 100 ), false, false, true, true )
end

function RENDER()
	if GetConVarNumber( "Simple_RENDER_playermodel" ) >= 1 then
		for k, v in pairs(ents.GetAll()) do
			if IsValid( v ) then
				if v:IsPlayer() or v:IsNPC() then
					v:SetMaterial( "" )
					cam.Start3D( EyePos(), EyeAngles() )
					v:DrawModel()
					cam.End3D()
				end
			end
		end
	end
	if GetConVarNumber( "Simple_RENDER_chams" ) >= 1 then
			for k, v in pairs(ents.GetAll()) do
				if IsValid( v ) then
					if v:IsPlayer() or v:IsNPC() then
						v:SetMaterial( "models/debug/debugwhite" )
						cam.Start3D( EyePos(), EyeAngles() )
						v:DrawModel()
						cam.End3D()
					end
				end
			end
		end
	end
hook.Add( "HUDPaint", "render", Render )


function ESP()
	for k, e in pairs( player.GetAll() ) do
local TeamColor = team.GetColor(e:Team())
local HPColor = Color(255,255,255,255)
local Dist = e:GetPos():Distance(LocalPlayer():GetPos());
local wep = "Unknown"
local SteamID = e:SteamID()
local Name = e:Nick()
local InfoCol = white
if GetConVarNumber("Simple_PERP_RPNames") == 1 then
	Name = e:GetRPName()
else
	Name = e:Nick()
end
local maxX, minX, maxY, minY, maxX2, minX2, maxY2, minY2, minYhp, maxYhp = CreatePos( e )
-- This is bad
if e:Health() >= 90 then HPColor = Color(0,255,0,255)
	elseif e:Health() >= 70 then HPColor = Color(255,255,0,255)
	elseif e:Health() >= 50 then HPColor = Color(255,165,0,255)
	elseif e:Health() >= 30 then HPColor = Color(255,140,0,255)
	elseif e:Health() >= 20 then HPCOlor = Color(255, 255, 255, 255)
	elseif e:Health() >= 10 then HPColor = Color(255,0,0,255)
	else HPColor = Color(255,0,0,255)
end
draw.SimpleTextOutlined("xInstantHook v2.0 for Garry's Mod", "Logo", 25,15,Color(255,255,255,255),5,1,1,black)
if ( e:IsPlayer() && e:Alive() && e != LocalPlayer() && IsCloseEnough(e) ) then
			if e:GetActiveWeapon() != nil then
				if type(e:GetActiveWeapon()) == "Weapon" then
					if e:GetActiveWeapon() and e:GetActiveWeapon():IsValid() then
						wep = e:GetActiveWeapon():GetPrintName()
						
							-- ESP INFO
							if GetConVarNumber("Simple_ESP_Info") == 1 then
								draw.SimpleTextOutlined( "N: " ..e:Name(), "ESPFont", maxX2, minY2, Red, 4,1,1, Blue)
								draw.SimpleTextOutlined( "H: " .. e:Health(), "ESPFont", maxX2, minY2 + 20, HPColor, 4,1, 1, black )
								draw.SimpleTextOutlined( "D: " .. math.floor(Dist), "ESPFont", maxX2, minY2 + 40, Red, 4,1,1, Blue)
								draw.SimpleTextOutlined( "W: " .. wep, "ESPFont", maxX2, minY2 + 60, Red, 4,1,1, Blue)
							end								
								if e:GetFriendStatus() == "friend" then
									draw.SimpleTextOutlined( "[Friend]", "ESPFont", maxX2, minY2 - 20, Red, 4,1,1, Blue)
								end
								if e:IsAdmin() then
									draw.SimpleText( "-[Admin]-", 'ESPFont', Pos.x, Pos.y - 40, Red, TEXT_ALIGN_CENTER );
								end
							end
							-- ESP BOX --
							if GetConVarNumber("Simple_ESP_Box") == 1 then
								surface.SetDrawColor(GetBoxColor(e))				
								surface.DrawLine( maxX, maxY, maxX, minY )
								surface.DrawLine( maxX, minY, minX, minY )					
								surface.DrawLine( minX, minY, minX, maxY )
								surface.DrawLine( minX, maxY, maxX, maxY )
							end
							-- ESP SKELETON --
							local bones = {
							{ S = "ValveBiped.Bip01_Head1", E = "ValveBiped.Bip01_Neck1" },
							{ S = "ValveBiped.Bip01_Neck1", E = "ValveBiped.Bip01_Spine4" },
							{ S = "ValveBiped.Bip01_Spine4", E = "ValveBiped.Bip01_Spine2" },
							{ S = "ValveBiped.Bip01_Spine2", E = "ValveBiped.Bip01_Spine1" },
							{ S = "ValveBiped.Bip01_Spine1", E = "ValveBiped.Bip01_Spine" },
							{ S = "ValveBiped.Bip01_Spine", E = "ValveBiped.Bip01_Pelvis" },
							
							{ S = "ValveBiped.Bip01_Spine4", E = "ValveBiped.Bip01_L_UpperArm" },
							{ S = "ValveBiped.Bip01_L_UpperArm", E = "ValveBiped.Bip01_L_Forearm" },
							{ S = "ValveBiped.Bip01_L_Forearm", E = "ValveBiped.Bip01_L_Hand" },

							{ S = "ValveBiped.Bip01_Spine4", E = "ValveBiped.Bip01_R_UpperArm" },
							{ S = "ValveBiped.Bip01_R_UpperArm", E = "ValveBiped.Bip01_R_Forearm" },
							{ S = "ValveBiped.Bip01_R_Forearm", E = "ValveBiped.Bip01_R_Hand" },

							{ S = "ValveBiped.Bip01_Pelvis", E = "ValveBiped.Bip01_L_Thigh" },
							{ S = "ValveBiped.Bip01_L_Thigh", E = "ValveBiped.Bip01_L_Calf" },
							{ S = "ValveBiped.Bip01_L_Calf", E = "ValveBiped.Bip01_L_Foot" },
							{ S = "ValveBiped.Bip01_L_Foot", E = "ValveBiped.Bip01_L_Toe0" },

							{ S = "ValveBiped.Bip01_Pelvis", E = "ValveBiped.Bip01_R_Thigh" },
							{ S = "ValveBiped.Bip01_R_Thigh", E = "ValveBiped.Bip01_R_Calf" },
							{ S = "ValveBiped.Bip01_R_Calf", E = "ValveBiped.Bip01_R_Foot" },
							{ S = "ValveBiped.Bip01_R_Foot", E = "ValveBiped.Bip01_R_Toe0" },
							}
							if GetConVarNumber("Simple_ESP_Skeleton") == 1 then
								for k, v in pairs( bones ) do
									local sPos, ePos = e:GetBonePosition( e:LookupBone( v.S ) ):ToScreen(), e:GetBonePosition( e:LookupBone( v.E ) ):ToScreen()
										if e:IsPlayer() and !e:IsNPC() then
											surface.SetDrawColor(team.GetColor(e:Team()))
										end
										surface.DrawLine(sPos.x,sPos.y,ePos.x,ePos.y)
								end
							end
							-- ESP TRACER --
							if GetConVarNumber("Simple_ESP_Tracer") == 1 then	
								cam.Start3D( EyePos() , EyeAngles())
								render.SetMaterial( Material( "trails/laser" ) )
								StartPos = LocalPlayer():GetActiveWeapon():GetPos()
								EndPos = e:GetBonePosition(e:LookupBone("ValveBiped.Bip01_Head1"))
								render.DrawBeam(StartPos, EndPos , 3, 0, 0, Color(0,255,0,255))
								cam.End3D()
							end
							
							-- ESP CROSSHAIR --
							if GetConVarNumber("Simple_ESP_Crosshair") == 1 then
								if GetConVarString("Simple_ESP_Crosshair_Type") == "Spinning" then
									local x, y = ScrW() / 2, ScrH() / 2	
									local Speed = 1
									surface.SetDrawColor( 255, 0, 0, 255 )
									CHPosx = math.Clamp(LocalPlayer():GetEyeTrace().HitPos:ToScreen().x,0,ScrW())
									CHPosy = math.Clamp(LocalPlayer():GetEyeTrace().HitPos:ToScreen().y,0,ScrH())
									mathsin = math.sin(CurTime()*Speed)*4
									mathcos = math.cos(CurTime()*Speed)*4
									mathsin2 = math.sin(CurTime()*Speed+0.1)*4
									mathcos2 = math.cos(CurTime()*Speed+0.1)*4
									mathsin3 = math.sin(CurTime()*Speed-0.1)*4
									mathcos3 = math.cos(CurTime()*Speed-0.1)*4
									surface.DrawLine( CHPosx+mathcos*2,CHPosy+mathsin*2,CHPosx+mathcos*5,CHPosy+mathsin*5 );
									surface.DrawLine( CHPosx-mathcos*2,CHPosy-mathsin*2,CHPosx-mathcos*5,CHPosy-mathsin*5 );
									surface.DrawLine( CHPosx+mathsin*2,CHPosy-mathcos*2,CHPosx+mathsin*5,CHPosy-mathcos*5 );
									surface.DrawLine( CHPosx-mathsin*2,CHPosy+mathcos*2,CHPosx-mathsin*5,CHPosy+mathcos*5 );
								elseif GetConVarString("Simple_ESP_Crosshair_Type") == "Jewish" then
									surface.SetDrawColor( 255, 0, 0, 255 )
									surface.DrawLine(ScrW()/2, ScrH()/2, ScrW()/2 + 20, ScrH()/2)
									surface.DrawLine(ScrW()/2 + 20, ScrH()/2, ScrW()/2 + 20, ScrH()/2 + 20)
									surface.DrawLine(ScrW()/2 , ScrH()/2, ScrW()/2 - 20, ScrH()/2)
									surface.DrawLine(ScrW()/2 - 20 , ScrH()/2, ScrW()/2 - 20, ScrH()/2 - 20)
									surface.DrawLine(ScrW()/2, ScrH()/2, ScrW()/2, ScrH()/2 - 20)
									surface.DrawLine(ScrW()/2, ScrH()/2 - 20, ScrW()/2 + 20, ScrH()/2 - 20)
									surface.DrawLine(ScrW()/2, ScrH()/2, ScrW()/2, ScrH()/2 + 20)
									surface.DrawLine(ScrW()/2, ScrH()/2 + 20, ScrW()/2 - 20, ScrH()/2 + 20)
								elseif GetConVarString("Simple_ESP_Crosshair_Type") == "Basic" then
									local x, y, s = ScrW() / 2, ScrH() / 2, 10
									surface.SetDrawColor( 255, 0, 0, 255 )
									surface.DrawLine( x, y - s, x, y + s )
									surface.DrawLine( x - s, y, x + s, y )
								elseif GetConVarString("Simple_ESP_Crosshair_Type") == "X-Cross" then
									local x, y, w = ScrW() / 2, ScrH() / 2, 7
									surface.SetDrawColor( 255, 0, 0, 255 )
									surface.DrawLine(x - w, y - w, x + w, y + w)
									surface.DrawLine(x - w, y + w, x + w, y - w)
								elseif GetConVarString("Simple_ESP_Crosshair_Type") == "Dot" then
								draw.RoundedBox( 4, ( ScrW() / 2 ) - 3, ( ScrH() / 2 ) - 3, 7, 7, Color( 255, 255, 255, 255 ) )
								elseif GetConVarString("Simple_ESP_Crosshair_Type") == "CSS" then
								        local g = 5
										local s, x, y, l = 10, ScrW() / 2, ScrH() / 2, g + 15
										surface.SetDrawColor( 255, 0, 0, 255 )
										surface.DrawLine( x - l, y, x - g, y )
										surface.DrawLine( x + l, y, x + g, y )
										surface.DrawLine( x, y - l, x, y - g )
										surface.DrawLine( x, y + l, x, y + g )
								elseif GetConVarString("Simple_ESP_Crosshair_Type") == "Cross Boxed" then
									surface.SetDrawColor( 255, 0, 0, 255 )
										surface.DrawLine( x - length, y, x - gap, y )
										surface.DrawLine( x + length, y, x + gap, y )
										surface.DrawLine( x, y - length, x, y - gap )
										surface.DrawLine( x, y + length, x, y + gap )
										surface.DrawOutlinedRect( x - length - 2, y - length - 2, ( length + 2 ) * 2 + 1, ( length + 2 ) * 2 + 1 )
										surface.DrawLine(ScrW() / 2 - 30, ScrH() / 2, ScrW() / 2 + 32 , ScrH() / 2)
										surface.DrawLine(ScrW() / 2 - 0, ScrH() / 2 - 30, ScrW() / 2 - 0 , ScrH() / 2 + 32)
										draw.RoundedBox( 4, ( ScrW() / 2 ) - 3, ( ScrH() / 2 ) - 3, 7, 7, Color( 0, 0, 0, 50 ) )
								end
							end
							if GetConVarNumber("Simple_MISC_CSNoclip") == 1 then
								me_pos = LocalPlayer():EyePos():ToScreen()
								draw.SimpleText("You are here!", "Trebuchet19gh", me_pos.x,me_pos.y +10, red, 4, 1 )
							end
					end
				end
			end
		end
	for _, v in ipairs( ents.GetAll() ) do
		if( v:IsValid() and IsCustomEnt( v:GetClass() )) then
			if GetConVarNumber("Simple_ESP_Ents") == 1 then
				local wepn = v:GetClass()
				local wname = string.Replace(wepn,"weapon_","")
				wname = string.Replace(wname,"_"," ")
				wname = string.upper(wname)
				local entpos = v:GetPos():ToScreen()
				draw.SimpleTextOutlined(wname, "Trebuchet19gh", entpos.x + 50, entpos.y - 15, red, TEXT_ALIGN_CENTER, TEXT_ALIGN_LEFT, .6, black )
			end
		end                    
	end
end
hook.Add('HUDPaint', 'ESP', ESP)
/*
Name: Got to go fast
Purpose: Damn could you go any faster
*/

speedon = function()
GetConVar('sv_cheats'):SetValue( Speed:GetFloat() )
GetConVar('host_timescale'):SetValue(5.0)
end

speedoff = function()
GetConVar('host_timescale'):SetValue(1.0)
GetConVar('sv_cheats'):SetValue(0)
end
concommand.Add("+speedhack", speedon)
concommand.Add("-speedhack", speedoff)

/*
Name: Oh no the sky
Purpose: ;c
*/
function RemoveSky()
        if GetConVarNumber("Simple_Remove_skybox") >= 1 then
        GetConVar('gl_clear'):SetValue(1)
        GetConVar('r_drawskybox'):SetValue(0)
        GetConVar('r_3dsky'):SetValue(0)
        else
        GetConVar('gl_clear'):SetValue(0)
        GetConVar('r_drawskybox'):SetValue(1)
        GetConVar('r_3dsky'):SetValue(0)
        end
end
hook.Add( 'HUDPaint', 'BlackSky', RemoveSky );

function Bunnyhop()
if GetConVarNumber( "Simple_MISC_Bunnyhop" ) >= 1 then
if input.IsKeyDown( KEY_SPACE ) then
if LocalPlayer():IsOnGround() then
RunConsoleCommand("+Jump")
timer.Create("Bhop",0.01, 0 ,function() RunConsoleCommand("-Jump") end)
                        end
                end
                        end
                                end
hook.Add("Think", "immabunny", Bunnyhop)

function recoil()
	if GetConVarNumber("Simple_Remove_recoil") == 1 then
		local wep = LocalPlayer():GetActiveWeapon() 
			if LocalPlayer():GetActiveWeapon().Primary then
				LocalPlayer():GetActiveWeapon().Primary.Recoil = 0
			else
			if LocalPlayer():GetActiveWeapon().Primary then
				LocalPlayer():GetActiveWeapon().Primary.Recoil = 1.5
			end
		end
	end
end
hook.Add('Think', 'Recoil', recoil)

-- Sv_Cheats
function sv_cheats()
	if GetConVarNumber("Simple_Bypass_Cheats") >= 1 then
		GetConVar("sv_cheats"):SetValue(1)
	else
		GetConVar("sv_cheats"):SetValue(0)
	end
end
hook.Add( "Think", "sv_cheats", sv_cheats )



function mat_fullbright()
	if GetConVarNumber("Simple_Bypass_Fullbright") >= 1 then
		GetConVar("mat_fullbright"):SetValue(1)
	else
		GetConVar("mat_fullbright"):SetValue(0)
	end
end
hook.Add( "Think", "mat_fullbright", mat_fullbright )

/* Derma Menu */
local function ShowFrame()

Frame = vgui.Create("DFrame")
Frame:SetSize( 450 , 400 )
Frame:SetPos( ScrW() / 3 - Frame:GetWide() / 3 , ScrH() / 2 - Frame:GetTall() / 2  )
Frame:SetTitle("Simple [Hack] By OverDone")
Frame:SetVisible( true )
Frame:ShowCloseButton( false )
Frame.Paint = function()
    draw.RoundedBox( 8, 0, 0, Frame:GetWide(), Frame:GetTall(), Color( 0, 255, 0, 110 ) )
end
Frame:MakePopup()

local BSheet = vgui.Create("DPropertySheet" , Frame)
BSheet:SetSize( 440 , 370 )
BSheet:SetPos( 5 , 25 )
BSheet.Paint = function()
    draw.RoundedBox( 8, 0, 0, BSheet:GetWide(), BSheet:GetTall(), Color( 0, 0, 0, 190 ) )
end

local Tab = vgui.Create("DLabel")
Tab:SetParent( BSheet )
Tab:SetPos( 0 , 10 )
Tab:SetText("")

local Tab2 = vgui.Create("DLabel")
Tab2:SetParent( BSheet )
Tab2:SetPos( 0 , 10 )
Tab2:SetText("")

local Tab3 = vgui.Create("DLabel")
Tab3:SetParent( BSheet )
Tab3:SetPos( 0 , 10 )
Tab3:SetText("")

local Tab4 = vgui.Create("DLabel")
Tab4:SetParent( BSheet )
Tab4:SetPos( 0 , 10 )
Tab4:SetText("")

local Tab5 = vgui.Create("DLabel")
Tab5:SetParent( BSheet )
Tab5:SetPos( 0 , 10 )
Tab5:SetText("")

local Aim3 = vgui.Create( "DCheckBoxLabel")
Aim3:SetText( "[Render] Wallhack" )
Aim3:SetConVar( "Simple_RENDER_PlayerModel" ) 
Aim3:SetParent( Tab )
Aim3:SetPos( 10 , 20 )
Aim3:SetValue( GetConVarNumber("Simple_RENDER_PlayerModel") )
Aim3:SetTextColor( Color(255 , 255 , 255 , 255 ) )
Aim3:SizeToContents()

local Aim3 = vgui.Create( "DCheckBoxLabel")
Aim3:SetText( "[Render] Chams" )
Aim3:SetConVar( "Simple_RENDER_chams" ) 
Aim3:SetParent( Tab )
Aim3:SetPos( 10 , 40 )
Aim3:SetValue( GetConVarNumber("Simple_RENDER_chams") )
Aim3:SetTextColor( Color(255 , 255 , 255 , 255 ) )
Aim3:SizeToContents()

local Aim3 = vgui.Create( "DCheckBoxLabel")
Aim3:SetText( "[ESP] Info" )
Aim3:SetConVar( "Simple_ESP_Info" ) 
Aim3:SetParent( Tab2 )
Aim3:SetPos( 10 , 20 )
Aim3:SetValue( GetConVarNumber("Simple_ESP_Info") )
Aim3:SetTextColor( Color(255 , 255 , 255 , 255 ) )
Aim3:SizeToContents()

local Aim3 = vgui.Create( "DCheckBoxLabel")
Aim3:SetText( "[ESP] Box" )
Aim3:SetConVar( "Simple_ESP_Box" ) 
Aim3:SetParent( Tab2 )
Aim3:SetPos( 10 , 40 )
Aim3:SetValue( GetConVarNumber("Simple_ESP_Box") )
Aim3:SetTextColor( Color(255 , 255 , 255 , 255 ) )
Aim3:SizeToContents()

local Aim3 = vgui.Create( "DCheckBoxLabel")
Aim3:SetText( "[ESP] Skeleton" )
Aim3:SetConVar( "Simple_ESP_Skeleton" ) 
Aim3:SetParent( Tab2 )
Aim3:SetPos( 10 , 60 )
Aim3:SetValue( GetConVarNumber("Simple_ESP_Skeleton") )
Aim3:SetTextColor( Color(255 , 255 , 255 , 255 ) )
Aim3:SizeToContents()

local Aim3 = vgui.Create( "DCheckBoxLabel")
Aim3:SetText( "[ESP] Crosshair" )
Aim3:SetConVar( "Simple_ESP_Crosshair" ) 
Aim3:SetParent( Tab2 )
Aim3:SetPos( 10 , 80 )
Aim3:SetValue( GetConVarNumber("Simple_ESP_Crosshair") )
Aim3:SetTextColor( Color(255 , 255 , 255 , 255 ) )
Aim3:SizeToContents()

local ESPLabel4 = vgui.Create("DLabel")
ESPLabel4:SetParent( Tab2 )
ESPLabel4:SetPos(150,20)
ESPLabel4:SetText("Crosshair Type")
ESPLabel4:SetTextColor(Color(255,255,255,255))
ESPLabel4:SizeToContents()

local CrosshairList = vgui.Create( "DComboBox", Tab2)
CrosshairList:SetPos(150,40)
CrosshairList:SetSize( 82, 20 )
CrosshairList:AddChoice("Spinning")
CrosshairList:AddChoice("Jewish")
CrosshairList:AddChoice("Basic")
CrosshairList:AddChoice("X-Cross")
CrosshairList:AddChoice("Dot")
CrosshairList:AddChoice("CSS")
CrosshairList:AddChoice("Cross Boxed")
CrosshairList.OnSelect = function(self)
	RunConsoleCommand("Simple_ESP_Crosshair_Type",self:GetValue())
end

local Aim3 = vgui.Create( "DCheckBoxLabel")
Aim3:SetText( "[ESP] Ents" )
Aim3:SetConVar( "Simple_ESP_Ents" ) 
Aim3:SetParent( Tab2 )
Aim3:SetPos( 10 , 100 )
Aim3:SetValue( GetConVarNumber("Simple_ESP_Ents") )
Aim3:SetTextColor( Color(255 , 255 , 255 , 255 ) )
Aim3:SizeToContents()

local Aim3 = vgui.Create( "DCheckBoxLabel")
Aim3:SetText( "[Misc] BunnyHop" )
Aim3:SetConVar( "Simple_MISC_Bunnyhop" ) 
Aim3:SetParent( Tab3 )
Aim3:SetPos( 10 , 20 )
Aim3:SetValue( GetConVarNumber("Simple_MISC_Bunnyhop") )
Aim3:SetTextColor( Color(255 , 255 , 255 , 255 ) )
Aim3:SizeToContents()

local Aim3 = vgui.Create( "DCheckBoxLabel")
Aim3:SetText( "[Bypass] SV_Cheats" )
Aim3:SetConVar( "Simple_Bypass_Cheats" ) 
Aim3:SetParent( Tab4 )
Aim3:SetPos( 10 , 20 )
Aim3:SetValue( GetConVarNumber("Simple_Bypass_Cheats") )
Aim3:SetTextColor( Color(255 , 255 , 255 , 255 ) )
Aim3:SizeToContents()

local Aim3 = vgui.Create( "DCheckBoxLabel")
Aim3:SetText( "[Bypass] Fullbright" )
Aim3:SetConVar( "Simple_Bypass_Fullbright" ) 
Aim3:SetParent( Tab4 )
Aim3:SetPos( 10 , 40 )
Aim3:SetValue( GetConVarNumber("Simple_Bypass_Fullbright") )
Aim3:SetTextColor( Color(255 , 255 , 255 , 255 ) )
Aim3:SizeToContents()

BSheet:AddSheet( "Render", Tab, "gui/silkicons/star", false, false, 		"Render" )
BSheet:AddSheet( "ESP", Tab2, "gui/silkicons/check_on", false, false, 		"Wallhacks/ESP" )
BSheet:AddSheet( "Misc", Tab3, "gui/silkicons/world", false, false, 		"Misc" )
BSheet:AddSheet( "Bypass", Tab4, "gui/silkicons/world", false, false, 		"Misc" )
BSheet:AddSheet( "Speedhack", Tab5, "gui/silkicons/wrench", false, false, 	"Gotta go fast" )
end

concommand.Add("+Simple_Menu",ShowFrame)
concommand.Add("-Simple_Menu",function()
Frame:SetVisible( false )
end)
 
concommand.Add("Simple_Menu_Reload",function()
ShowFrame()
end)

function hooks_createmove(ucmd)
Aimbot(ucmd);
end
