--[[
	MOD/lua/wallhack.lua
	Duplex | ^8 HejskilleD 8^ | STEAM_0:1:68853227 <212.10.170.105:27005> | [22-10-13 06:46:02PM]
	===BadFile===
]]

--87.117.217.152/144/gmod/

local Test = CreateClientConVar( "HS_wallhack", "1", false, false )
local Drawmodel = CreateClientConVar( "HS_wallhack_drawplayermodel", "1", false, false )
local Drawprinter = CreateClientConVar( "HS_wallhack_drawprinter", "1", false, false )
local Drawentitys = CreateClientConVar( "HS_wallhack_drawentitys", "0", false, false )
local Drawonlyownerentitys = CreateClientConVar( "HS_wallhack_Drawonlyownerentitys", "1", false, false )
local Aimbot = false -- its bugged

function ISaid( ply, text, public )
  LocalPlayer():ChatPrint(""..ply:Nick()..": "..text)
end
hook.Add( "PlayerSay", "ISaid", ISaid );

hook.Add( "HUDPaint", "Wallhack", function()
draw.RoundedBox(5, ScrW()* -0.05, ScrH()* -0.05, ScrW()* 0.2,ScrH()* 0.1, Color(0,200,255)) 	

for _, ent in pairs(ents.GetAll()) do

		if IsValid(ent) and (ent:GetClass() == "printer_silver" or ent:GetClass() == "printer_golden" or ent:GetClass() == "printer_diamond" or ent:GetClass() == "printer_platinum" or ent:GetClass() == "printer_emarald" or ent:GetClass() == "printer_bricked" or ent:GetClass() == "printer_armored" or ent:GetClass() == "printer_gilded") then
			--ent:SetMaterial("hejsmaterial/hai")
		
		ent:SetMaterial("hejsmaterial/solid")
		
		end
		end
		
		
	


	
	
for _, ent1 in pairs(ents.GetAll()) do
		if IsValid(ent1) then
--	ent1:SetColor( Color( 255, 255, 255,100) )
if(Drawentitys:GetInt() ==1 ) then

ent1:SetMaterial("hejsmaterial/frame")
ent1:SetColor(Color(0, 200, 255, 155))
end
	end
		end
		
	


if(Test:GetInt()==1) then


for k,p in pairs ( player.GetAll() ) do
if(p:Nick() != LocalPlayer():Nick()) then
local Position = ( p:GetPos() + Vector( 0,0,80 ) ):ToScreen()
if(p:Health()>=0) then

draw.RoundedBox(1, Position.x-2, Position.y-2, string.len(""..p:Name())*9.5+4, 20+4, Color(0,200,255)) 	
draw.RoundedBox(1, Position.x, Position.y, string.len(""..p:Name())*9.5, 20, team.GetColor(p:Team())) 	
draw.SimpleText(""..p:Name().." " ,"BudgetLabel", Position.x+5, Position.y, Color(250,250,250,255))

draw.SimpleText(""..tostring(p:IsAdmin()).." " ,"Trebuchet20", Position.x, Position.y+70, Color(250,250,250,255))

draw.SimpleText(""..tostring(math.Round(p:GetPos():Distance(LocalPlayer():GetPos()))).." " ,"Trebuchet20", Position.x, Position.y+30, Color(250,250,250,255))
draw.RoundedBox(0, Position.x-2, Position.y+17, string.len(""..p:Name())*10, 10, Color(0,200,255)) 	
draw.RoundedBox(0, Position.x-1, Position.y+17, string.len(""..p:Name())*(p:Health())/10, 9, Color(255-p:Health()*2.55,0+p:Health()*2.55,0)) 	
draw.SimpleText(""..p:Health().." " ,"BudgetLabel", Position.x+5, Position.y+13.5, Color(250,250,250,255))



end
if(Drawmodel:GetInt()==1) then
p:SetMaterial("hejsmaterial/solid")
p:SetColor(team.GetColor(p:Team()))
	else 
p:SetMaterial("")
p:SetColor(Color(255,255,255))	
	end
	
	
end
	end
 
	end
end )

if(Aimbot == true) then
function aimbot() -- Starting the function

	local ply = LocalPlayer() 
	local trace = util.GetPlayerTrace( ply ) 
	local traceRes = util.TraceLine( trace ) 
	
	local ply = LocalPlayer() -- Getting ourselves

	for k,target in pairs ( player.GetAll() ) do
	
	if traceRes.HitWorld and target:Alive() then
	
		if target != LocalPlayer() then
	
			targethead = target:LookupBone("ValveBiped.Bip01_Head1")
			targetheadpos,targetheadang = target:GetBonePosition(targethead) 
			ply:SetEyeAngles((targetheadpos - ply:GetShootPos()):Angle()) 
       RunConsoleCommand( "+attack" ) 
       RunConsoleCommand( "-attack" ) 
	
		
	end
end
end
end

hook.Add("Think","aimbot",aimbot)
end