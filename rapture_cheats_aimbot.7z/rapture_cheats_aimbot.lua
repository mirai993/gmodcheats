function dist(d,e)
	local distn = math.Round(d:GetPos():Distance(e:GetPos()))
	local d = 99999
	local targ = {}
	if distn <= d then
		table.insert(targ,e)
		d = distn
	end
	local first_t = targ[1]
	return first_t,d
end
 
CreateClientConVar("gat_aim",0,false,false)
hook.Add("Think","AutoAimBot", function()
	local aim = 0
	local gay = {}
	if GetConVarNumber("gat_aim") == 0 then return end
	for k,v in pairs(player.GetAll()) do
		if v != LocalPlayer() and v:Alive() then
			local tr,dis = dist(LocalPlayer(),v)
			table.insert(gay,{targ = tr,distance = dis})
			if dis <= gay[1].distance then
				local targethead = tr:LookupBone("ValveBiped.Bip01_Head1") -- In this aimbot we only aim for the head.
				local targetheadpos,targetheadang = tr:GetBonePosition(targethead) -- Get the position/angle of the head.
				LocalPlayer():SetEyeAngles((targetheadpos - LocalPlayer():GetShootPos()):Angle()) -- And finally, we snap our aim to the head of the target.
			end
		end
	end
end)