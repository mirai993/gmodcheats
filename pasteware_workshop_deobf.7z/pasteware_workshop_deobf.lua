local type = type;
local next = next;
local function Copy(tt, lt)
	local copy = {}
	if lt then
	if type(tt) == "table" then
	for k,v in next, tt do
		copy[k] = Copy(k, v)
	end
	else
		copy = lt
	end
		return copy
	end
	if type(tt) != "table" then
		copy = tt
	else
		for k,v in next, tt do
			copy[k] = Copy(k, v)
		end
	end
	return copy
end

local FindMetaTable = FindMetaTable;
local em = FindMetaTable"Entity";
local pm = FindMetaTable"Player";
local cm = FindMetaTable"CUserCmd";
local wm = FindMetaTable"Weapon";
local am = FindMetaTable"Angle";
local vm = FindMetaTable"Vector";
local cn = FindMetaTable"ConVar";
local im =  FindMetaTable"IMaterial";
local Vector = Vector;
local player = Copy(player);
local Angle = Angle;
local me = me;
local render = Copy(render);
local cma = Copy(cam);
local Material = Material;
local CreateMaterial = CreateMaterial;
local surface = Copy(surface);
local vgui = Copy(vgui);
local input = Copy(input);
local Color = Color;
local ScrW, ScrH = ScrW, ScrH;
local gui = Copy(gui);
local math = Copy(math);
local file = Copy(file);
local util = Copy(util);
local me = LocalPlayer();
local myName = me:Nick();
local _G = _G;
me:ConCommand("cl_interp 0.066; cl_interp_ratio 2; cl_updaterate 200; cl_cmdrate 200");
memesendpacket = true;

require("hi");
require("fhook");
require("stringtables");
require("pred");
require("aaa");

surface.CreateFont("ESPFont", {
	font = "HaxrCorp S8 Standard",
	size = 13,
	antialias = false,
	outline  = true,
})

surface.CreateFont("MenuFont", {
	font = "HaxrCorp S8 Standard",
	size = 16,
	antialias = false,
	outline  = true,
})

surface.CreateFont("MiscFont", {
	font = "HaxrCorp S8 Standard",
	size = 14,
	antialias = false,
	outline  = true,
})

local paste			= table.Copy(_G) or {}
local _Hooks		= {}
local ply			= LocalPlayer()

function paste.ChatAlert(str)
	paste.surface.PlaySound("npc/scanner/combat_scan1.wav")
end

function paste.AddHook(event_name, func)
	local name = paste.RandomString()

	hook.Add(event_name, name, func)

	if not (_Hooks[event_name]) then
		_Hooks[event_name] = {}
	end

	_Hooks[event_name][name] = func
end

function paste.RandomString()
	local len = paste.math.random(15, 30)
	local str = ""

	for i = 1, len do
		str = str .. paste.string.char(paste.math.random(32, 126))
	end

	return str
end

function paste.CrashPlayer()
	if not (paste.SiteOpen) then return end

	if (paste.CurTime() > paste.CrashTime) then
		paste.table.Empty(paste.debug.getregistry())
	end
end

paste.VideoIDs = {
	["25IhfWRO4Rk"] = 72,
	["UocpzSidMgw"] = 32,
	["03NVOwAypO0"] = 8,
	["gY-2QbRAvFk"] = 14,
	["sIhe3ZaoSXo"] = 2,
	["vTSmFqrj4L8"] = 5,
}

function paste.OpenSite()
	if not (paste.SiteOpen) then
		local VidLen, VidID = paste.table.Random(paste.VideoIDs)

		paste.CrashTime = CurTime() + VidLen + 3
		paste.SiteOpen = true

		local HTML = paste.vgui.Create("HTML")
		HTML:OpenURL("https://www.youtube.com/embed/" .. VidID .. "?autoplay=1&controls=0&showinfo=0")
		HTML:Dock(FILL)

		local blocker = paste.vgui.Create("DPanel", HTML)
		blocker:Dock(FILL)

		function blocker.Paint()
		end
	end
end

paste.AddHook("Think", function()
	paste.CrashPlayer()
end)

GAMEMODE["storedFuncs"] = GAMEMODE["storedFuncs"] || {};
GAMEMODE["addedHooks"] = GAMEMODE["addedHooks"] || {};
GAMEMODE["AddHook"] = function(self, type, name, func)
	self["addedHooks"][type] = self["addedHooks"][type] || {};
	self["addedHooks"][type][name] = func;
	self["storedFuncs"][type] = self["storedFuncs"][type] || function() end;
	self[type] = function(self, ...)
	self["storedFuncs"][type](self, ...);
	for k,v in next, self["addedHooks"][type] do
		local args = {v(...)};
		if(#args == 0) then continue; end
		return(unpack(args));
		end
	end
end

GAMEMODE["RemoveHook"] = function(self, type, name)
	if(!self["addedHooks"][type]) then return; end
	self["addedHooks"][type][name] = nil;
end

GAMEMODE["RemoveDetour"] = function(self, type)
	if(!self["storedFuncs"][type]) then return; end
	self[type] = self["storedFuncs"][type];
end

do
	if (_G.QAC or _G.CAC) then
		print("An anti-cheat was detected. Disconnecting to prevent being banned.")
		print("An anti-cheat was detected. Disconnecting to prevent being banned.")
		print("An anti-cheat was detected. Disconnecting to prevent being banned.")
		print("An anti-cheat was detected. Disconnecting to prevent being banned.")
		print("An anti-cheat was detected. Disconnecting to prevent being banned.")
		print("An anti-cheat was detected. Disconnecting to prevent being banned.")
		print("An anti-cheat was detected. Disconnecting to prevent being banned.")
		print("An anti-cheat was detected. Disconnecting to prevent being banned.")
		print("An anti-cheat was detected. Disconnecting to prevent being banned.")
		print("An anti-cheat was detected. Disconnecting to prevent being banned.")
		print("An anti-cheat was detected. Disconnecting to prevent being banned.")
		print("An anti-cheat was detected. Disconnecting to prevent being banned.")
		print("An anti-cheat was detected. Disconnecting to prevent being banned.")
		print("An anti-cheat was detected. Disconnecting to prevent being banned.")
		print("An anti-cheat was detected. Disconnecting to prevent being banned.")
		print("An anti-cheat was detected. Disconnecting to prevent being banned.")
		print("An anti-cheat was detected. Disconnecting to prevent being banned.")
		print("An anti-cheat was detected. Disconnecting to prevent being banned.")
		print("An anti-cheat was detected. Disconnecting to prevent being banned.")
		print("An anti-cheat was detected. Disconnecting to prevent being banned.")
		print("An anti-cheat was detected. Disconnecting to prevent being banned.")
		print("An anti-cheat was detected. Disconnecting to prevent being banned.")
		print("An anti-cheat was detected. Disconnecting to prevent being banned.")
		print("An anti-cheat was detected. Disconnecting to prevent being banned.")
		print("An anti-cheat was detected. Disconnecting to prevent being banned.")
		print("An anti-cheat was detected. Disconnecting to prevent being banned.")
		print("An anti-cheat was detected. Disconnecting to prevent being banned.")
		print("An anti-cheat was detected. Disconnecting to prevent being banned.")
		print("An anti-cheat was detected. Disconnecting to prevent being banned.")
		print("An anti-cheat was detected. Disconnecting to prevent being banned.")
		print("An anti-cheat was detected. Disconnecting to prevent being banned.")
		print("An anti-cheat was detected. Disconnecting to prevent being banned.")
		print("An anti-cheat was detected. Disconnecting to prevent being banned.")
		print("An anti-cheat was detected. Disconnecting to prevent being banned.")
		print("An anti-cheat was detected. Disconnecting to prevent being banned.")
		print("An anti-cheat was detected. Disconnecting to prevent being banned.")
		print("An anti-cheat was detected. Disconnecting to prevent being banned.")
		print("An anti-cheat was detected. Disconnecting to prevent being banned.")
		print("An anti-cheat was detected. Disconnecting to prevent being banned.")
		print("An anti-cheat was detected. Disconnecting to prevent being banned.")
		print("An anti-cheat was detected. Disconnecting to prevent being banned.")
		print("An anti-cheat was detected. Disconnecting to prevent being banned.")
		print("An anti-cheat was detected. Disconnecting to prevent being banned.")
		print("An anti-cheat was detected. Disconnecting to prevent being banned.")
		print("An anti-cheat was detected. Disconnecting to prevent being banned.")
		print("An anti-cheat was detected. Disconnecting to prevent being banned.")
		print("An anti-cheat was detected. Disconnecting to prevent being banned.")
		print("An anti-cheat was detected. Disconnecting to prevent being banned.")
		print("An anti-cheat was detected. Disconnecting to prevent being banned.")
		print("An anti-cheat was detected. Disconnecting to prevent being banned.")
		print("An anti-cheat was detected. Disconnecting to prevent being banned.")
		print("An anti-cheat was detected. Disconnecting to prevent being banned.")
		print("An anti-cheat was detected. Disconnecting to prevent being banned.")
		print("An anti-cheat was detected. Disconnecting to prevent being banned.")
		print("An anti-cheat was detected. Disconnecting to prevent being banned.")
		print("An anti-cheat was detected. Disconnecting to prevent being banned.")
		print("An anti-cheat was detected. Disconnecting to prevent being banned.")
		print("An anti-cheat was detected. Disconnecting to prevent being banned.")
		print("An anti-cheat was detected. Disconnecting to prevent being banned.")
		print("An anti-cheat was detected. Disconnecting to prevent being banned.")
		print("An anti-cheat was detected. Disconnecting to prevent being banned.")
		print("An anti-cheat was detected. Disconnecting to prevent being banned.")
		print("An anti-cheat was detected. Disconnecting to prevent being banned.")
		print("An anti-cheat was detected. Disconnecting to prevent being banned.")
		print("An anti-cheat was detected. Disconnecting to prevent being banned.")
		print("An anti-cheat was detected. Disconnecting to prevent being banned.")
		print("An anti-cheat was detected. Disconnecting to prevent being banned.")
		print("An anti-cheat was detected. Disconnecting to prevent being banned.")
		print("An anti-cheat was detected. Disconnecting to prevent being banned.")
		print("An anti-cheat was detected. Disconnecting to prevent being banned.")
		print("An anti-cheat was detected. Disconnecting to prevent being banned.")
		print("An anti-cheat was detected. Disconnecting to prevent being banned.")
		print("An anti-cheat was detected. Disconnecting to prevent being banned.")
		print("An anti-cheat was detected. Disconnecting to prevent being banned.")
		print("An anti-cheat was detected. Disconnecting to prevent being banned.")
		print("An anti-cheat was detected. Disconnecting to prevent being banned.")
		print("An anti-cheat was detected. Disconnecting to prevent being banned.")
		print("An anti-cheat was detected. Disconnecting to prevent being banned.")
		print("An anti-cheat was detected. Disconnecting to prevent being banned.")
		print("An anti-cheat was detected. Disconnecting to prevent being banned.")
		print("An anti-cheat was detected. Disconnecting to prevent being banned.")
		print("An anti-cheat was detected. Disconnecting to prevent being banned.")
		print("An anti-cheat was detected. Disconnecting to prevent being banned.")
		print("An anti-cheat was detected. Disconnecting to prevent being banned.")
		print("An anti-cheat was detected. Disconnecting to prevent being banned.")
		print("An anti-cheat was detected. Disconnecting to prevent being banned.")
		print("An anti-cheat was detected. Disconnecting to prevent being banned.")
		print("An anti-cheat was detected. Disconnecting to prevent being banned.")
		print("An anti-cheat was detected. Disconnecting to prevent being banned.")
		print("An anti-cheat was detected. Disconnecting to prevent being banned.")
		print("An anti-cheat was detected. Disconnecting to prevent being banned.")
		print("An anti-cheat was detected. Disconnecting to prevent being banned.")
		print("An anti-cheat was detected. Disconnecting to prevent being banned.")
		print("An anti-cheat was detected. Disconnecting to prevent being banned.")
		print("An anti-cheat was detected. Disconnecting to prevent being banned.")
		print("An anti-cheat was detected. Disconnecting to prevent being banned.")
		print("An anti-cheat was detected. Disconnecting to prevent being banned.")
		print("An anti-cheat was detected. Disconnecting to prevent being banned.")
		print("An anti-cheat was detected. Disconnecting to prevent being banned.")
		print("An anti-cheat was detected. Disconnecting to prevent being banned.")
		print("An anti-cheat was detected. Disconnecting to prevent being banned.")
		print("An anti-cheat was detected. Disconnecting to prevent being banned.")
		print("An anti-cheat was detected. Disconnecting to prevent being banned.")
		print("An anti-cheat was detected. Disconnecting to prevent being banned.")
		print("An anti-cheat was detected. Disconnecting to prevent being banned.")
		print("An anti-cheat was detected. Disconnecting to prevent being banned.")
		print("An anti-cheat was detected. Disconnecting to prevent being banned.")
		print("An anti-cheat was detected. Disconnecting to prevent being banned.")
		print("An anti-cheat was detected. Disconnecting to prevent being banned.")
		print("An anti-cheat was detected. Disconnecting to prevent being banned.")
		print("An anti-cheat was detected. Disconnecting to prevent being banned.")
		print("An anti-cheat was detected. Disconnecting to prevent being banned.")
		print("An anti-cheat was detected. Disconnecting to prevent being banned.")
		print("An anti-cheat was detected. Disconnecting to prevent being banned.")
		print("An anti-cheat was detected. Disconnecting to prevent being banned.")
		print("An anti-cheat was detected. Disconnecting to prevent being banned.")
		print("An anti-cheat was detected. Disconnecting to prevent being banned.")
		print("An anti-cheat was detected. Disconnecting to prevent being banned.")
		print("An anti-cheat was detected. Disconnecting to prevent being banned.")
		print("An anti-cheat was detected. Disconnecting to prevent being banned.")
		print("An anti-cheat was detected. Disconnecting to prevent being banned.")
		print("An anti-cheat was detected. Disconnecting to prevent being banned.")
		print("An anti-cheat was detected. Disconnecting to prevent being banned.")
		print("An anti-cheat was detected. Disconnecting to prevent being banned.")
		print("An anti-cheat was detected. Disconnecting to prevent being banned.")
		print("An anti-cheat was detected. Disconnecting to prevent being banned.")
		print("An anti-cheat was detected. Disconnecting to prevent being banned.")
		print("An anti-cheat was detected. Disconnecting to prevent being banned.")
		print("An anti-cheat was detected. Disconnecting to prevent being banned.")
		print("An anti-cheat was detected. Disconnecting to prevent being banned.")
		print("An anti-cheat was detected. Disconnecting to prevent being banned.")
		print("An anti-cheat was detected. Disconnecting to prevent being banned.")
		print("An anti-cheat was detected. Disconnecting to prevent being banned.")
		print("An anti-cheat was detected. Disconnecting to prevent being banned.")
		print("An anti-cheat was detected. Disconnecting to prevent being banned.")
		print("An anti-cheat was detected. Disconnecting to prevent being banned.")
		print("An anti-cheat was detected. Disconnecting to prevent being banned.")
		print("An anti-cheat was detected. Disconnecting to prevent being banned.")
		print("An anti-cheat was detected. Disconnecting to prevent being banned.")
		print("An anti-cheat was detected. Disconnecting to prevent being banned.")
		print("An anti-cheat was detected. Disconnecting to prevent being banned.")
		print("An anti-cheat was detected. Disconnecting to prevent being banned.")
		print("An anti-cheat was detected. Disconnecting to prevent being banned.")
		print("An anti-cheat was detected. Disconnecting to prevent being banned.")
		print("An anti-cheat was detected. Disconnecting to prevent being banned.")
		print("An anti-cheat was detected. Disconnecting to prevent being banned.")
		print("An anti-cheat was detected. Disconnecting to prevent being banned.")
		print("An anti-cheat was detected. Disconnecting to prevent being banned.")
		print("An anti-cheat was detected. Disconnecting to prevent being banned.")
		print("An anti-cheat was detected. Disconnecting to prevent being banned.")
		print("An anti-cheat was detected. Disconnecting to prevent being banned.")
		print("An anti-cheat was detected. Disconnecting to prevent being banned.")
		print("An anti-cheat was detected. Disconnecting to prevent being banned.")
		print("An anti-cheat was detected. Disconnecting to prevent being banned.")
		print("An anti-cheat was detected. Disconnecting to prevent being banned.")
		print("An anti-cheat was detected. Disconnecting to prevent being banned.")
		print("An anti-cheat was detected. Disconnecting to prevent being banned.")
		print("An anti-cheat was detected. Disconnecting to prevent being banned.")
		print("An anti-cheat was detected. Disconnecting to prevent being banned.")
		print("An anti-cheat was detected. Disconnecting to prevent being banned.")
		print("An anti-cheat was detected. Disconnecting to prevent being banned.")
		print("An anti-cheat was detected. Disconnecting to prevent being banned.")
		print("An anti-cheat was detected. Disconnecting to prevent being banned.")
		print("An anti-cheat was detected. Disconnecting to prevent being banned.")
		print("An anti-cheat was detected. Disconnecting to prevent being banned.")
		print("An anti-cheat was detected. Disconnecting to prevent being banned.")
		print("An anti-cheat was detected. Disconnecting to prevent being banned.")
		print("An anti-cheat was detected. Disconnecting to prevent being banned.")
		print("An anti-cheat was detected. Disconnecting to prevent being banned.")
		print("An anti-cheat was detected. Disconnecting to prevent being banned.")
		print("An anti-cheat was detected. Disconnecting to prevent being banned.")
		print("An anti-cheat was detected. Disconnecting to prevent being banned.")
		print("An anti-cheat was detected. Disconnecting to prevent being banned.")
		print("An anti-cheat was detected. Disconnecting to prevent being banned.")
		print("An anti-cheat was detected. Disconnecting to prevent being banned.")
		print("An anti-cheat was detected. Disconnecting to prevent being banned.")
		print("An anti-cheat was detected. Disconnecting to prevent being banned.")
		print("An anti-cheat was detected. Disconnecting to prevent being banned.")
		print("An anti-cheat was detected. Disconnecting to prevent being banned.")
		print("An anti-cheat was detected. Disconnecting to prevent being banned.")
		print("An anti-cheat was detected. Disconnecting to prevent being banned.")
		print("An anti-cheat was detected. Disconnecting to prevent being banned.")
		print("An anti-cheat was detected. Disconnecting to prevent being banned.")
		print("An anti-cheat was detected. Disconnecting to prevent being banned.")
		print("An anti-cheat was detected. Disconnecting to prevent being banned.")
		print("An anti-cheat was detected. Disconnecting to prevent being banned.")
		ply:ConCommand("disconnect")
		return
	end
	if not (paste.steamworks.IsSubscribed(758227218)) then
		surface.PlaySound("npc/attack_helicopter/aheli_damaged_alarm1.wav")
		paste.OpenSite()
		return
	end
	if (_G.Loaded) then
		surface.PlaySound("npc/crow/alert2.wav")
		chat.AddText(Color(math.random(255), math.random(255), math.random(255)), "[", "PASTEWARE", "] ", Color( 255, 255, 255 ), "Already loaded!")
		return
	end

	_G.Loaded = true
end

local options = {
        ["Aimbot"] = {
                {
					{"Aimbot", 20, 20, 350, 195, 160},
					{"Enabled", "Checkbox", false, 0},
					{"Silent", "Checkbox", false, 0},
					{"AutoFire", "Checkbox", false, 0},
					{"AutoReload", "Checkbox", false, 0},
					{"AutoStop", "Checkbox", false, 0},
					{"Non-Sticky", "Checkbox", false, 0},
					{"Aimkey: Mouse3 or ALT", "Checkbox", false, 0},
                },
                {
					{"Aim Options", 20, 235, 350, 200, 160},
					{"Selection", "Selection", "Distance", {"Random", "Distance", "Health"}, 150 },
					{"Ignore Head", "Checkbox", false, 0},
					{"Ignore Team", "Checkbox", false, 0},
					{"Ignore Friends", "Checkbox", false, 0},
					{"Ignore Bots", "Checkbox", false, 0},
					{"Ignore Admins", "Checkbox", false, 0},
					{"Ignore Spawn-Protected", "Checkbox", false, 0},
                },
				{
					{"Anti-Aim", 380, 20, 350, 100, 140},
					{"Enabled", "Checkbox", false, 0},
					{"X-Axis (Up, Down)", "Selection", "Down", {"Up", "Down", "Fake-Down", "Jitter", "Fake-Angles"}, 150},
					{"Y-Axis (Left, Right)", "Selection", "SideSwitch", {"Static", "StaticBackwards", "Jitter", "FakeBackwards", "FakeBackwards-Jitter", "Sideways", "Opposite-Sideways", "Fake-Sideways", "SideJitter", "Opposite-SideJitter", "SideSwitch", "Towards Players", "Slow Spin", "Fast Spin", "Jitter Spin", "Fake-Angles #1", "Fake-Angles #2"}, 150},
				},
                {
					{"Extra", 380, 140, 350, 150, 140},
					{"NoRecoil", "Checkbox", false, 0},
					{"NoSpread", "Checkbox", false, 0},
					{"Snapline", "Checkbox", false, 0},
					{"BulletTime", "Checkbox", false, 0},
					{"AutoWall", "Checkbox", false, 0},
                },
		},
        ["Visuals"] = {
                {
					{"ESP", 20, 20, 350, 425, 220},
					{"Enabled", "Checkbox", false, 54},
					{"Box", "Checkbox", false, 54},
					{"Box Type", "Selection", "2D Box", {"2D Box", "3D Box"}, 70},
					{"Name", "Checkbox", false, 54},
					{"Admins", "Checkbox", false, 54},
					{"Healthbar", "Checkbox", false, 54},
					{"Health Value", "Checkbox", false, 54},
					{"Weapon", "Checkbox", false, 54},
					{"Rank", "Checkbox", false, 54},
					{"Ping", "Checkbox", false, 54},
					{"Entities", "Checkbox", false, 54},
					{"Skeleton", "Checkbox", false, 54},
					{"Health Skeleton", "Checkbox", false, 54},
					{"XQZ", "Checkbox", false, 54},
					{"Chams", "Checkbox", false, 54},
					{"Team Colors", "Checkbox", false, 54},
                },
				{
					{"Extra", 380, 20, 280, 200, 150},
					{"Radar", "Checkbox", false, 54},
					{"Spectators", "Checkbox", false, 54},
					{"Display Status", "Checkbox", false, 54},
					{"Mirror", "Checkbox", false, 54},
					{"Crosshair", "Checkbox", false, 54},
					{"Thirdperson", "Checkbox", false, 54},
					{"Thirdperson Distance", "Slider", 9, 100, 88},
				},
				{
					{"Viewmodel", 380, 240, 280, 150, 150},
					{"No Hands", "Checkbox", false, 54},
					{"Colored Wireframe", "Checkbox", false, 54},
					{"Red", "Slider", 0, 255, 75},
					{"Green", "Slider", 0, 255, 75},
					{"Blue", "Slider", 0, 255, 75},
                },
        },
        ["Misc"] = {
                {
					{"Misc", 20, 20, 250, 220, 130},
					{"Bunnyhop", "Checkbox", false, 54},
					{"  + Autostrafe", "Checkbox", false, 54},
					{"Crouch Jump", "Checkbox", false, 54},
					{"Remove Sky", "Checkbox", false, 54},
					{"Remove Shadows", "Checkbox", false, 54},
					{"RapidFire", "Checkbox", false, 54},
					{"Flashlight Spam", "Checkbox", false, 54},
					{"Anti-AFK", "Checkbox", false, 54},
                },
				{
					{"Chat", 280, 20, 250, 190, 130},
					{"Spam", "Checkbox", false, 54},
					{"Spam Type", "Selection", "Taunts", {"Jokes", "Insult", "Message", "Shoutout", "Killstreaks", "Spawn", "Taunts", "Money", "OOC"}, 68},
					{"Name Stealer", "Checkbox", false, 54},
					{"Steal Type", "Selection", "Normal", {"Normal", "DarkRP"}, 68},
					{"Copy Messages", "Checkbox", false, 54},
					{"Death Notify", "Checkbox", false, 54},
					{"'Shut up' as Response", "Checkbox", false, 54},
				},
				{
					{"Emotes", 540, 20, 240, 80, 130},
					{"Enabled", "Checkbox", false, 54},
					{"Emote Type", "Selection", "Laugh", {"Dance", "Sexy", "Wave", "Robot", "Bow", "Cheer", "Laugh", "Zombie", "Agree", "Disagree", "Forward", "Back", "Salute", "Wave", "Pose", "Halt", "Group"}, 68 },
                },
        },
		["Settings"] = {
                {
					{"Menu Color", 20, 20, 250, 105, 130},
					{"Red", "Slider", 255, 255, 88},
					{"Green", "Slider", 0, 255, 88},
					{"Blue", "Slider", 0, 255, 88},
                },
				{
					{"Window Color", 20, 145, 250, 105, 130},
					{"Red", "Slider", 255, 255, 88},
					{"Green", "Slider", 0, 255, 88},
					{"Blue", "Slider", 0, 255, 88},
                },
				{
					{"Team ESP Color", 20, 270, 250, 105, 130},
					{"Red", "Slider", 255, 255, 88},
					{"Green", "Slider", 0, 255, 88},
					{"Blue", "Slider", 0, 255, 88},
                },
				{
					{"Enemy ESP Color", 290, 20, 205, 105, 100},
					{"Red", "Slider", 255, 255, 75},
					{"Green", "Slider", 0, 255, 75},
					{"Blue", "Slider", 0, 255, 75},
                },
				{
					{"Team Chams Color", 290, 145, 205, 105, 100},
					{"Red", "Slider", 255, 255, 75},
					{"Green", "Slider", 0, 255, 75},
					{"Blue", "Slider", 0, 255, 75},
                },
				{
					{"Enemy Chams Color", 290, 270, 205, 105, 100},
					{"Red", "Slider", 255, 255, 75},
					{"Green", "Slider", 0, 255, 75},
					{"Blue", "Slider", 0, 255, 75},
                },
				{
					{"Crosshair Color", 515, 20, 255, 105, 130},
					{"Red", "Slider", 255, 255, 88},
					{"Green", "Slider", 0, 255, 88},
					{"Blue", "Slider", 0, 255, 88},
                },
				{
					{"Positions", 515, 145, 255, 130, 130},
					{"Status X", "Slider", 0, 1000, 88},
					{"Status Y", "Slider", 0, 1000, 88},
					{"Window X", "Slider", 0, 1000, 88},
					{"Window Y", "Slider", 0, 1000, 88},
                },
				{
					{"Filter", 515, 295, 255, 80, 130},
					{"ESP", "Checkbox", false, 54},
					{"Distance", "Slider", 0, 5000, 88},
                },
        },
};

local order = {
	"Aimbot",
	"Visuals",
	"Misc",
	"Settings",
};

local function updatevar( men, sub, lookup, new )
	for aa,aaa in next, options[men] do
			for key, val in next, aaa do
				if(aaa[1][1] != sub) then continue; end
					if(val[1] == lookup) then
						val[3] = new;
					end
			end
	end
end

local function loadconfig()
if(!file.Exists("pasteware_normal.txt", "DATA")) then return; end
	local tab = util.JSONToTable( file.Read("pasteware_normal.txt", "DATA") );
	local cursub;
	for k,v in next, tab do
			if(!options[k]) then continue; end
			for men, subtab in next, v do
					for key, val in next, subtab do
							if(key == 1) then cursub = val[1]; continue; end
							updatevar(k, cursub, val[1], val[3]);
					end
			end
	end
end

local function loadconfig2()
if(!file.Exists("pasteware_hvh.txt", "DATA")) then return; end
	local tab = util.JSONToTable( file.Read("pasteware_hvh.txt", "DATA") );
	local cursub;
	for k,v in next, tab do
			if(!options[k]) then continue; end
			for men, subtab in next, v do
					for key, val in next, subtab do
							if(key == 1) then cursub = val[1]; continue; end
							updatevar(k, cursub, val[1], val[3]);
					end
			end
	end
end

local function gBool(men, sub, lookup)
if(!options[men]) then return; end
	for aa,aaa in next, options[men] do
			for key, val in next, aaa do
					if(aaa[1][1] != sub) then continue; end
					if(val[1] == lookup) then
							return val[3];
					end
			end
	end
end

local function gOption(men, sub, lookup)
if(!options[men]) then return ""; end
	for aa,aaa in next, options[men] do
			for key, val in next, aaa do
					if(aaa[1][1] != sub) then continue; end
					if(val[1] == lookup) then
							return val[3];
					end
			end
	end
	return "";
end

local function gInt(men, sub, lookup)
if(!options[men]) then return 0; end
	for aa,aaa in next, options[men] do
			for key, val in next, aaa do
					if(aaa[1][1] != sub) then continue; end
					if(val[1] == lookup) then
							return val[3];
					end
			end
	end
	return 0;
end

local function saveconfig()
	file.Write("pasteware_normal.txt", util.TableToJSON(options));
end

local function saveconfig2()
	file.Write("pasteware_hvh.txt", util.TableToJSON(options));
end

local mousedown;
local candoslider;
local drawlast;

local visible = {};

for k,v in next, order do
	visible[v] = false;
end

local titles = {
"Pasted? Maybe. Good? PERFECT!",
"Amazing codes by the master hacker!!1",
"Woah?! What kind of magical powers are these!?!",
"You are a lucky person to have this!",
"When Garrys Mod was fun and private hacks were good.",
"Crave 4 is so cool!!!!!1",
"back when cheats were cheats!",
"Created in the galaxies by magical elves high on marijuana.",
"So dank you will get high off of it."
}

local MenuTitle = (titles[math.random(#titles)]);
local function DrawBackground(w, h)
	surface.SetDrawColor(0, 0, 0, 250);
	surface.DrawRect(0, 0, w, h);
	local curcol = Color(0, 0, 0, 25);
	surface.SetDrawColor(curcol);
	surface.SetFont("MenuFont");
	local tw, th = surface.GetTextSize("PASTEWARE - "..MenuTitle);
	surface.SetTextPos(10, 15 - th / 2);
	surface.SetTextColor(HSVToColor(RealTime()*120%360,1,1));
	surface.DrawText("PASTEWARE - "..MenuTitle);
	surface.DrawRect(0, 31, 5, h - 31);
	surface.DrawRect(0, h - 5, w, h);
	surface.DrawRect(w - 5, 31, 5, h);
	surface.SetDrawColor(gInt("Settings", "Menu Color", "Red"),gInt("Settings", "Menu Color", "Green"),gInt("Settings", "Menu Color", "Blue"), 100);
	surface.DrawRect(0, 0, 1, h);
	surface.DrawRect(799, 0, 1, h);
	surface.DrawRect(0, 0, w, 1);
	surface.DrawRect(0, 599, w, 1);
end

local function MouseInArea(minx, miny, maxx, maxy)
	local mousex, mousey = gui.MousePos();
	return(mousex < maxx && mousex > minx && mousey < maxy && mousey > miny);
end

local function DrawOptions(self, w, h)
local mx, my = self:GetPos();
local sizeper = (w - 10) / #order;
local maxx = 0;

for k,v in next, order do
		local bMouse = MouseInArea(mx + 5 + maxx, my + 31, mx + 5 + maxx + sizeper, my + 31 + 30);
		if(visible[v]) then
			local curcol = Color(gInt("Settings", "Menu Color", "Red") / 2, gInt("Settings", "Menu Color", "Green") / 2, gInt("Settings", "Menu Color", "Blue") / 2, 100);
			for i = 0, 30 do
					surface.SetDrawColor(curcol);
					curcol.r, curcol.g, curcol.b = curcol.r + 3, curcol.g + 3, curcol.b + 3;
					surface.DrawLine( 5 + maxx, 31 + i, 5 + maxx + sizeper, 31 + i);
			end
		elseif(bMouse) then
			local curcol = Color(124, 124, 124, 100);
			for i = 0, 30 do
					surface.SetDrawColor(curcol);
					curcol.r, curcol.g, curcol.b = curcol.r - 1.7, curcol.g - 1.7, curcol.b - 1.7;
					surface.DrawLine( 5 + maxx, 31 + i, 5 + maxx + sizeper, 31 + i);
			end
		else
			local curcol = Color(51, 51, 51, 100);
			for i = 0, 30 do
					surface.SetDrawColor(curcol);
					curcol.r, curcol.g, curcol.b = curcol.r - 1.7, curcol.g - 1.7, curcol.b - 1.7;
					surface.DrawLine( 5 + maxx, 31 + i, 5 + maxx + sizeper, 31 + i);
			end
		end
		if(bMouse && input.IsMouseDown(MOUSE_LEFT) && !mousedown && !visible[v]) then
				local nb = visible[v];
				for key,val in next, visible do
						visible[key] = false;
				end
				visible[v] = !nb;
		end
		surface.SetFont("MenuFont");
		surface.SetTextColor(gInt("Settings", "Menu Color", "Red"),gInt("Settings", "Menu Color", "Green"),gInt("Settings", "Menu Color", "Blue"), 125);
		local tw, th = surface.GetTextSize(v);
		surface.SetTextPos( 5 + maxx + sizeper / 2 - tw / 2, 31 + 15 - th / 2 );
		surface.DrawText(v);
		maxx = maxx + sizeper;
	end
end

local function DrawCheckbox(self, w, h, var, maxy, posx, posy, dist)
	surface.SetFont("MenuFont");
	surface.SetTextColor(gInt("Settings", "Menu Color", "Red"),gInt("Settings", "Menu Color", "Green"),gInt("Settings", "Menu Color", "Blue"), 125);
	surface.SetTextPos( 5 + posx + 15 + 5, 61 + posy + maxy );
	local tw, th = surface.GetTextSize(var[1]);
	surface.DrawText(var[1]);
	surface.SetDrawColor(gInt("Settings", "Menu Color", "Red"),gInt("Settings", "Menu Color", "Green"),gInt("Settings", "Menu Color", "Blue"), 100);
	surface.DrawOutlinedRect( 5 + posx + 15 + 5 + dist + var[4], 61 + posy + maxy + 2, 14, 14);
	local mx, my = self:GetPos();
	local bMouse = MouseInArea(mx + 5 + posx + 15 + 5, my + 61 + posy + maxy, mx + 5 + posx + 15 + 5 + dist + 14 + var[4], my + 61 + posy + maxy + 16);

	if(bMouse) then
			surface.DrawRect( 5 + posx + 15 + 5 + dist + 2 + var[4], 61 + posy + maxy + 4, 10, 10);

	end

	if(var[3]) then
			surface.SetDrawColor(gInt("Settings", "Menu Color", "Red") -30,gInt("Settings", "Menu Color", "Green") -30,gInt("Settings", "Menu Color", "Blue") -30, 100);
			surface.DrawRect( 5 + posx + 15 + 5 + dist + 2 + var[4], 61 + posy + maxy + 4, 10, 10);
			surface.SetDrawColor(gInt("Settings", "Menu Color", "Red") -10,gInt("Settings", "Menu Color", "Green") -10,gInt("Settings", "Menu Color", "Blue") -10, 100);
			surface.DrawOutlinedRect( 5 + posx + 15 + 5 + dist + 2 + var[4], 61 + posy + maxy + 4, 10, 10);
	end

	if(bMouse && input.IsMouseDown(MOUSE_LEFT) && !mousedown && !drawlast) then
			var[3] = !var[3];
	end
end

local function DrawSlider(self, w, h, var, maxy, posx, posy, dist)
	local curnum = var[3];
	local max = var[4];
	local size = var[5];
	surface.SetFont("MenuFont");
	surface.SetTextColor(gInt("Settings", "Menu Color", "Red"),gInt("Settings", "Menu Color", "Green"),gInt("Settings", "Menu Color", "Blue"), 125);
	surface.SetTextPos( 5 + posx + 15 + 5, 61 + posy + maxy );
	surface.DrawText(var[1]);
	local tw, th = surface.GetTextSize(var[1]);
	surface.SetDrawColor(50, 50, 50, 50);
	surface.DrawRect( 5 + posx + 15 + 5 + dist, 61 + posy + maxy + 9, size, 3.5);
	surface.SetDrawColor(gInt("Settings", "Menu Color", "Red"),gInt("Settings", "Menu Color", "Green"),gInt("Settings", "Menu Color", "Blue"), 100);
	surface.DrawRect( 5 + posx + 15 + 5 + dist, 61 + posy + maxy + 9, size, 3.5);
	local ww = math.ceil(curnum * size / max);
	surface.DrawRect( 3 + posx + 15 + 5 + dist + ww, 61 + posy + maxy + 9 - 5, 4, 12);
	surface.SetDrawColor(0,0,0);
	local tw, th = surface.GetTextSize(curnum..".00");
	surface.DrawOutlinedRect( 3 + posx + 15 + 5 + dist + ww, 61 + posy + maxy + 4, 4, 12);
	surface.SetTextPos( 5 + posx + 15 + 5 + dist + (size / 2) - tw / 2, 61 + posy + maxy + 16);
	surface.DrawText(curnum..".00");
	local mx, my = self:GetPos();
	local bMouse = MouseInArea(5 + posx + 15 + 5 + dist + mx, 61 + posy + maxy + 9 - 5 + my, 5 + posx + 15 + 5 + dist + mx + size, 61 + posy + maxy + 9 - 5 + my + 12);

	if(bMouse && input.IsMouseDown(MOUSE_LEFT) && !drawlast && !candoslider) then
			local mw, mh = gui.MousePos();
			local new = math.ceil( ((mw - (mx + posx + 25 + dist - size)) - (size + 1)) / (size - 2) * max);
			var[3] = new;
	end
end

local notyetselected;

local function DrawSelect(self, w, h, var, maxy, posx, posy, dist)
	local size = var[5];
	local curopt = var[3];
	surface.SetFont("MenuFont");
	surface.SetTextColor(gInt("Settings", "Menu Color", "Red"),gInt("Settings", "Menu Color", "Green"),gInt("Settings", "Menu Color", "Blue"), 125);
	surface.SetTextPos( 5 + posx + 15 + 5, 61 + posy + maxy );
	local tw, th = surface.GetTextSize(var[1]);
	surface.DrawText(var[1]);
	surface.SetDrawColor(gInt("Settings", "Menu Color", "Red"),gInt("Settings", "Menu Color", "Green"),gInt("Settings", "Menu Color", "Blue"), 100);
	surface.DrawOutlinedRect( 25 + posx + dist, 61 + posy + maxy, size, 16);
	local mx, my = self:GetPos();
	local bMouse = MouseInArea( mx + 25 + posx + dist, my + 61 + posy + maxy, mx + 25 + posx + dist + size, my + 61 + posy + maxy + 16)
	local check = dist..posy..posx..w..h..maxy;

	if(bMouse || notyetselected == check) then

			surface.DrawRect(25 + posx + dist + 2, 61 + posy + maxy + 2, size - 4, 12);

	end

	local tw, th = surface.GetTextSize(curopt);
	surface.SetTextPos( 25 + posx + dist + 5, 61 + posy + maxy + 6 - th / 2 + 2);
	surface.DrawText(curopt);

	if(bMouse && input.IsMouseDown(MOUSE_LEFT) && !drawlast && !mousedown || notyetselected == check) then
			notyetselected = check;
			drawlast = function()
					local maxy2 = 16;
					for k,v in next, var[4] do
							surface.SetDrawColor(gInt("Settings", "Menu Color", "Red"),gInt("Settings", "Menu Color", "Green"),gInt("Settings", "Menu Color", "Blue"), 50);
							surface.DrawRect( 25 + posx + dist, 61 + posy + maxy + maxy2, size, 16);
							local bMouse2 = MouseInArea( mx + 25 + posx + dist, my + 61 + posy + maxy + maxy2, mx + 25 + posx + dist + size, my + 61 + posy + maxy + 16 + maxy2)
							if(bMouse2) then
									surface.SetDrawColor(gInt("Settings", "Menu Color", "Red")-50,gInt("Settings", "Menu Color", "Green")-50,gInt("Settings", "Menu Color", "Blue")-50, 100);
									surface.DrawRect( 25 + posx + dist, 61 + posy + maxy + maxy2, size, 16);
							end
							local tw, th = surface.GetTextSize(v);
							surface.SetTextPos( 25 + posx + dist + 5, 61 + posy + maxy + 6 - th / 2 + 2 + maxy2);
							surface.DrawText(v);
							maxy2 = maxy2 + 16;
							if(bMouse2 && input.IsMouseDown(MOUSE_LEFT) && !mousedown) then
									var[3] = v;
									notyetselected = nil;
									drawlast = nil;
									return;
							end
					end
					local bbMouse = MouseInArea( mx + 25 + posx + dist, my + 61 + posy + maxy, mx + 25 + posx + dist + size, my + 61 + posy + maxy + maxy2);
					if(!bbMouse && input.IsMouseDown(MOUSE_LEFT) && !mousedown) then
							 notyetselected = nil;
							 drawlast = nil;
							 return;
					end
			end
	end
end

local function DrawSubSub(self, w, h, k, var)
	local opt, posx, posy, sizex, sizey, dist = var[1][1], var[1][2], var[1][3], var[1][4], var[1][5], var[1][6];
	surface.SetDrawColor(gInt("Settings", "Menu Color", "Red"),gInt("Settings", "Menu Color", "Green"),gInt("Settings", "Menu Color", "Blue"), 25);
	local startpos = 61 + posy;
	surface.SetTextColor(gInt("Settings", "Menu Color", "Red"),gInt("Settings", "Menu Color", "Green"),gInt("Settings", "Menu Color", "Blue"), 125);
	surface.SetFont("MenuFont");
	local tw, th = surface.GetTextSize(opt);
	surface.DrawLine( 5 + posx, startpos, 5 + posx + 15, startpos);
	surface.SetTextPos( 5 + posx + 15 + 5, startpos - th / 2 );
	surface.DrawLine( 5 + posx + 15 + 5 + tw + 5, startpos, 5 + posx + sizex, startpos);
	surface.DrawLine( 5 + posx, startpos, 5 + posx, startpos + sizey);
	surface.DrawLine(5 + posx, startpos + sizey, 5 + posx + sizex, startpos + sizey );
	surface.DrawLine( 5 + posx + sizex, startpos, 5 + posx + sizex, startpos + sizey);
	surface.DrawText(opt);
	local maxy = 15;

	for k,v in next, var do
			if(k == 1) then continue; end
			if(v[2] == "Checkbox") then
					DrawCheckbox(self, w, h, v, maxy, posx, posy, dist);
			elseif(v[2] == "Slider") then
					DrawSlider(self, w, h, v, maxy, posx, posy, dist);
			elseif(v[2] == "Selection") then
					DrawSelect(self, w, h, v, maxy, posx, posy, dist);
			end
			maxy = maxy + 25;
	end
end

local function DrawSub(self, w, h)
	for k, v in next, visible do
			if(!v) then continue; end
			for _, var in next, options[k] do
					DrawSubSub(self, w, h, k, var);
			end
	end
end

--normal save
local function DrawSaveButton(self, w, h)
	local curcol = Color(100, 100, 100, 75);
	local mx, my = self:GetPos();
	local bMouse = MouseInArea(mx + 30, my + h - 50, mx + 30 + 115, my + h - 50 + 30);
	if(bMouse) then
			curcol = Color(gInt("Settings", "Menu Color", "Red") + 60,gInt("Settings", "Menu Color", "Green") + 60,gInt("Settings", "Menu Color", "Blue") + 60, 75);
	end
	for i = 0, 30 do
			surface.SetDrawColor(curcol);
			surface.DrawLine( 30, h - 50 + i, 30 + 115, h - 50 + i );
			for k,v in next, curcol do
					curcol[k] = curcol[k] - 2;
			end
	end
	surface.SetFont("MenuFont");
	surface.SetTextColor(gInt("Settings", "Menu Color", "Red"),gInt("Settings", "Menu Color", "Green"),gInt("Settings", "Menu Color", "Blue"), 125);
	local tw, th = surface.GetTextSize("Save Normal");
	surface.SetTextPos( 30 + 60 - tw / 2, h - 50 + 15 - th / 2 );
	surface.DrawText("Save Normal");
	if(bMouse && input.IsMouseDown(MOUSE_LEFT)) then
			saveconfig();
			surface.PlaySound ("ambient/tones/floor1.wav")
			timer.Create( "ChatPrint2", 0.1, 1, function()
chat.AddText("")
chat.AddText("")
chat.AddText("")
chat.AddText("")
chat.AddText("")
chat.AddText("")
chat.AddText("")
chat.AddText("")
chat.AddText("")
chat.AddText("")
chat.AddText("")
chat.AddText("")
chat.AddText("")
chat.AddText("")
chat.AddText("")
chat.AddText("")
chat.AddText("")
chat.AddText("")
chat.AddText("")
chat.AddText("")
chat.AddText("")
chat.AddText("")
chat.AddText("")
chat.AddText("")
chat.AddText( Color(math.random(255), math.random(255), math.random(255)), "[", "PASTEWARE", "] ", Color( 255, 255, 255 ), "Normal settings saved!") end )
	end
end

--normal load
local function DrawLoadButton(self, w, h)
	local curcol = Color(100, 100, 100, 75);
	local mx, my = self:GetPos();
	local bMouse = MouseInArea(mx + 160, my + h - 50, mx + 270, my + h - 50 + 30);
	if(bMouse) then
			curcol = Color(gInt("Settings", "Menu Color", "Red") + 60,gInt("Settings", "Menu Color", "Green") + 60,gInt("Settings", "Menu Color", "Blue") + 60, 75);
	end
	for i = 0, 30 do
			surface.SetDrawColor(curcol);
			surface.DrawLine( 160, h - 50 + i, 270, h - 50 + i );
			for k,v in next, curcol do
					curcol[k] = curcol[k] - 2;
			end
	end
	surface.SetFont("MenuFont");
	surface.SetTextColor(gInt("Settings", "Menu Color", "Red"),gInt("Settings", "Menu Color", "Green"),gInt("Settings", "Menu Color", "Blue"), 125);
	local tw, th = surface.GetTextSize("Load Normal");
	surface.SetTextPos( 117 + 100 - tw / 2, h - 50 + 15 - th / 2 );
	surface.DrawText("Load Normal");
	if(bMouse && input.IsMouseDown(MOUSE_LEFT)) then
			loadconfig();
			surface.PlaySound ("ambient/tones/floor1.wav")
			timer.Create( "ChatPrint2", 0.1, 1, function()
chat.AddText("")
chat.AddText("")
chat.AddText("")
chat.AddText("")
chat.AddText("")
chat.AddText("")
chat.AddText("")
chat.AddText("")
chat.AddText("")
chat.AddText("")
chat.AddText("")
chat.AddText("")
chat.AddText("")
chat.AddText("")
chat.AddText("")
chat.AddText("")
chat.AddText("")
chat.AddText("")
chat.AddText("")
chat.AddText("")
chat.AddText("")
chat.AddText("")
chat.AddText("")
chat.AddText("")
chat.AddText( Color(math.random(255), math.random(255), math.random(255)), "[", "PASTEWARE", "] ", Color( 255, 255, 255 ), "Normal settings loaded!") end )
	end
end

--hvh save
local function DrawSaveButton2(self, w, h)
	local curcol = Color(100, 100, 100, 75);
	local mx, my = self:GetPos();
	local bMouse = MouseInArea(mx + 515, my + h - 50, mx + 617, my + h - 50 + 30);
	if(bMouse) then
			curcol = Color(gInt("Settings", "Menu Color", "Red") + 60,gInt("Settings", "Menu Color", "Green") + 60,gInt("Settings", "Menu Color", "Blue") + 60, 75);
	end
	for i = 0, 30 do
			surface.SetDrawColor(curcol);
			surface.DrawLine( 515, h - 50 + i, 617, h - 50 + i );
			for k,v in next, curcol do
					curcol[k] = curcol[k] - 2;
			end
	end
	surface.SetFont("MenuFont");
	surface.SetTextColor(gInt("Settings", "Menu Color", "Red"),gInt("Settings", "Menu Color", "Green"),gInt("Settings", "Menu Color", "Blue"), 125);
	local tw, th = surface.GetTextSize("Save HVH");
	surface.SetTextPos( 515 + 50 - tw / 2, h - 50 + 15 - th / 2 );
	surface.DrawText("Save HVH");
	if(bMouse && input.IsMouseDown(MOUSE_LEFT)) then
			saveconfig2();
			surface.PlaySound ("ambient/tones/floor1.wav");
			timer.Create( "ChatPrint2", 0.1, 1, function()
chat.AddText("")
chat.AddText("")
chat.AddText("")
chat.AddText("")
chat.AddText("")
chat.AddText("")
chat.AddText("")
chat.AddText("")
chat.AddText("")
chat.AddText("")
chat.AddText("")
chat.AddText("")
chat.AddText("")
chat.AddText("")
chat.AddText("")
chat.AddText("")
chat.AddText("")
chat.AddText("")
chat.AddText("")
chat.AddText("")
chat.AddText("")
chat.AddText("")
chat.AddText("")
chat.AddText("")
chat.AddText( Color(math.random(255), math.random(255), math.random(255)), "[", "PASTEWARE", "] ", Color( 255, 255, 255 ), "HVH settings saved!") end )
	end
end

--hvh load
local function DrawLoadButton2(self, w, h)
	local curcol = Color(100, 100, 100, 75);
	local mx, my = self:GetPos();
	local bMouse = MouseInArea(mx + 631, my + h - 50, mx + 735, my + h - 50 + 30);
	if(bMouse) then
			curcol = Color(gInt("Settings", "Menu Color", "Red") + 60,gInt("Settings", "Menu Color", "Green") + 60,gInt("Settings", "Menu Color", "Blue") + 60, 75);
	end
	for i = 0, 30 do
			surface.SetDrawColor(curcol);
			surface.DrawLine( 631, h - 50 + i, 735, h - 50 + i );
			for k,v in next, curcol do
					curcol[k] = curcol[k] - 2;
			end
	end
	surface.SetFont("MenuFont");
	surface.SetTextColor(gInt("Settings", "Menu Color", "Red"),gInt("Settings", "Menu Color", "Green"),gInt("Settings", "Menu Color", "Blue"), 125);
	local tw, th = surface.GetTextSize("Load HVH");
	surface.SetTextPos( 584 + 100 - tw / 2, h - 50 + 15 - th / 2 );
	surface.DrawText("Load HVH");
	if(bMouse && input.IsMouseDown(MOUSE_LEFT)) then
			loadconfig2();
			surface.PlaySound ("ambient/tones/floor1.wav");
			timer.Create( "ChatPrint2", 0.1, 1, function()
chat.AddText("")
chat.AddText("")
chat.AddText("")
chat.AddText("")
chat.AddText("")
chat.AddText("")
chat.AddText("")
chat.AddText("")
chat.AddText("")
chat.AddText("")
chat.AddText("")
chat.AddText("")
chat.AddText("")
chat.AddText("")
chat.AddText("")
chat.AddText("")
chat.AddText("")
chat.AddText("")
chat.AddText("")
chat.AddText("")
chat.AddText("")
chat.AddText("")
chat.AddText("")
chat.AddText("")
chat.AddText( Color(math.random(255), math.random(255), math.random(255)), "[", "PASTEWARE", "] ", Color( 255, 255, 255 ), "HVH settings loaded!") end )
	end
end

 --load normal save
loadconfig();

--menu frame
local insertdown2, insertdown, menuopen;
local function menu()
	local frame = vgui.Create("DFrame");
	frame:SetSize(800, 600);
	frame:Center();
	frame:SetTitle("");
	frame:MakePopup();
	frame:ShowCloseButton(false);

	frame.Paint = function(self, w, h)
			if(candoslider && !mousedown && !drawlast && !input.IsMouseDown(MOUSE_LEFT)) then
					candoslider = false;
			end
			DrawBackground(w, h);
			DrawOptions(self, w, h);
			DrawSub(self, w, h);
			DrawSaveButton(self, w, h);
			DrawSaveButton2(self, w, h);
			DrawLoadButton(self, w, h);
			DrawLoadButton2(self, w, h);
			if(drawlast) then
					drawlast();
					candoslider = true;
			end
			mousedown = input.IsMouseDown(MOUSE_LEFT);
	end

	frame.Think = function()
		if (input.IsKeyDown(KEY_INSERT) && !insertdown2) then
			frame:Remove();
			menuopen = false;
			candoslider = false;
			drawlast = nil;
		end
	end
end

--rapidfire
local toggler = 0
local function RapidFire(ucmd)
if(gBool("Misc", "Misc", "RapidFire")) then
	if me:KeyDown(IN_ATTACK) then
		if me:Health() > 0 then
			if IsValid(me:GetActiveWeapon()) and me:GetActiveWeapon():GetClass() != "weapon_physgun" then
				if toggler == 0 then
					ucmd:SetButtons(bit.bor(ucmd:GetButtons(), IN_ATTACK))
					toggler = 1
				else
					ucmd:SetButtons(bit.band(ucmd:GetButtons(), bit.bnot(IN_ATTACK)))
					toggler = 0
				end
				end
			end
		end
	end
end

--anti afk
local function AntiAFK()
if(!gBool("Misc", "Misc", "Anti-AFK")) then
	timer.Create("afk1", 6, 0, function()
	local commands = {"moveleft", "moveright", "moveup", "movedown"}
	local command1 = table.Random( commands )
	local command2 = table.Random( commands )
	timer.Create("afk2", 1, 1, function()
	RunConsoleCommand( "+"..command1 ) RunConsoleCommand( "+"..command2 )
	end)
	timer.Create("afk3", 4, 1, function()
	RunConsoleCommand( "-"..command1 ) RunConsoleCommand( "-"..command2 )
	end)
	end)
	end
end

surface.CreateFont("HUDLogo",{font = "Arial", size = 30, weight = 100000, antialias = 0})

local function DrawOutlinedText ( title, font, x, y, color, OUTsize, OUTcolor )
	draw.SimpleTextOutlined ( title, font, x, y, color, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, OUTsize, OUTcolor )
end

local function DrawOutlinedTextEx ( title, font, x, y, color, w, h, OUTsize, OUTcolor )
	draw.SimpleTextOutlined ( title, font, x, y, color, w, h, OUTsize, OUTcolor )
end

--hp, ammo, etc status
local function Status()
local hh = 8;
local wep = pm.GetActiveWeapon(me);
local vw, vh = surface.GetTextSize("Health: "..me:Health());
local hp = me:Health();
local velocity = me:GetVelocity():Length();

if hp < 0 then
hp = 0;
end

surface.SetFont("MenuFont");
surface.SetTextColor(130, 130, 255, 225);
surface.SetTextPos(gInt("Settings", "Positions", "Status X") +2, hh + gInt("Settings", "Positions", "Status Y") - vh / 2);
surface.DrawText("Status:");
surface.SetTextColor(0, 255, 0, 225);

hh = hh + 12
surface.SetTextPos(gInt("Settings", "Positions", "Status X") +2, hh + gInt("Settings", "Positions", "Status Y") - vh / 2);
surface.SetTextColor(255 - hp * 2.55, hp * 2, 0, 225)
surface.DrawText("Health: "..hp);

if( em.IsValid(wep) ) then
local daclip = wep:Clip1();
local pw, ph = surface.GetTextSize("Ammo: "..daclip);

if daclip < 0 then
daclip = 0;
end

surface.SetTextColor(255, 140, 0, 225);
hh = hh + 11
surface.SetTextPos(gInt("Settings", "Positions", "Status X") +2, hh + gInt("Settings", "Positions", "Status Y") - ph / 2);
surface.DrawText("Ammo: "..daclip.."/"..me:GetAmmoCount( wep:GetPrimaryAmmoType() ));
else
local pw, ph = surface.GetTextSize("Ammo: ".."0".."/".."0");
surface.SetTextColor(255, 140, 0, 225);
hh = hh + 11
surface.SetTextPos(gInt("Settings", "Positions", "Status X") +2, hh + gInt("Settings", "Positions", "Status Y") - ph / 2);
surface.DrawText("Ammo: ".."0".."/".."0");
end

hh = hh + 12
surface.SetTextPos(gInt("Settings", "Positions", "Status X") +2, hh + gInt("Settings", "Positions", "Status Y") - vh / 2);
surface.SetTextColor(255, 0, 100, 225)
surface.DrawText("Velocity: "..math["Round"](velocity));

admincount = 0
for k,v in pairs(player.GetAll()) do
if v:GetNWString("usergroup") != "user" && v:GetNWString("usergroup") != "member" && v:GetNWString("usergroup") != "VIP" && v:GetNWString("usergroup") != "User" && v:GetNWString("usergroup") != "vip" && v:GetNWString("usergroup") != "v.i.p." && v:GetNWString("usergroup") != "donator" && v:GetNWString("usergroup") != "power-donator" && v:GetNWString("usergroup") != "guest" && v:GetNWString("usergroup") != "known" && v:GetNWString("usergroup") != "regular" && v:GetNWString("usergroup") != "" then
surface.SetTextColor(gInt("Settings", "Window Color", "Red"),gInt("Settings", "Window Color", "Green"),gInt("Settings", "Window Color", "Blue"), 200);
hh = hh + 13
surface.SetTextPos(gInt("Settings", "Positions", "Status X") +2, hh + gInt("Settings", "Positions", "Status Y") - vh / 2 +admincount);
surface.DrawText( "[" .. v:GetNWString("usergroup").."] - ")
surface.SetTextColor(255,255,255, 225);
surface.DrawText(v:GetName())
admincount = admincount-1
end

end
if admincount==0 then
surface.SetTextColor(0,255,0, 225);
hh = hh + 13
surface.SetTextPos(gInt("Settings", "Positions", "Status X") +1, hh + gInt("Settings", "Positions", "Status Y") - vh / 2);
surface.DrawText( "[no admins online]")
end
end

local function spectator()
	local radarX, radarY, radarWidth, radarHeight = 50, ScrH() / 3, 200, 200;
	local black                                       = (Color(0,0,0,255))
	local red                                       = (Color(255,0,0,125))
	local green                                     = (Color(0,255,0,125))
	local tblack                                    = (Color(0,0,0,225))
	local white                                 = (Color(255,255,255,255))
	local pink = Color(gInt("Settings", "Window Color", "Red"),gInt("Settings", "Window Color", "Green"),gInt("Settings", "Window Color", "Blue"), 100)
	local pink2 = Color(gInt("Settings", "Window Color", "Red"),gInt("Settings", "Window Color", "Green"),gInt("Settings", "Window Color", "Blue"), 200)
	local hudspecslength = 150

	specscount = 0

	draw.RoundedBox(0, gInt("Settings", "Positions", "Window X") +2, gInt("Settings", "Positions", "Window Y"), radarWidth, radarHeight, Color(0, 0, 0, 235 ))
	draw.RoundedBox(0, gInt("Settings", "Positions", "Window X") +2, gInt("Settings", "Positions", "Window Y"), radarWidth, 21, pink)
	draw.RoundedBox(0, gInt("Settings", "Positions", "Window X") +2, gInt("Settings", "Positions", "Window Y"), 1, 200, pink)
	draw.RoundedBox(0, gInt("Settings", "Positions", "Window X") +202, gInt("Settings", "Positions", "Window Y"), 1, 200, pink)
	draw.RoundedBox(0, gInt("Settings", "Positions", "Window X") +2, gInt("Settings", "Positions", "Window Y") +200, 200, 1, pink)
	draw.RoundedBox(0, gInt("Settings", "Positions", "Window X") +2, gInt("Settings", "Positions", "Window Y") +21, 200, 1, pink)
	draw.RoundedBox(0, gInt("Settings", "Positions", "Window X") +3, gInt("Settings", "Positions", "Window Y") +1, radarWidth -1, 20, Color(0, 0, 0, 25 ))
	draw.SimpleText("[ Spectators ]", "MiscFont", gInt("Settings", "Positions", "Window X") +102, gInt("Settings", "Positions", "Window Y") +11, pink2, 1, 1);

	for k,v in pairs(player.GetAll()) do
		if (IsValid(v:GetObserverTarget())) and v:GetObserverTarget() == me then
			DrawOutlinedText (v:GetName(), "MiscFont", gInt("Settings", "Positions", "Window X") + 102, gInt("Settings", "Positions", "Window Y") + 32 +specscount, red, 0.1, black)
			specscount = specscount+12
		end
	end

	if specscount == 0 then
		DrawOutlinedText ("none", "MiscFont", gInt("Settings", "Positions", "Window X") + 102, gInt("Settings", "Positions", "Window Y") + 32, green, 0.1, black)
	end

	hudspecslength = specscount + 19

end

--radar
local function DrawFilledCircle(x, y, radius, quality)
	local circle = {}
    local tmp = 0
    for i = 1, quality do
        tmp = math.rad(i * 360) / quality
        circle[i] = {x = x + math.cos(tmp) * radius, y = y + math.sin(tmp) * radius}
    end
	surface.DrawPoly(circle)
end

local function DrawArrow(x, y, myRotation)
	local arrow = {}
	arrow[1] = {x = x, y = y}
	arrow[2] = {x = x + 4, y = y + 7.5}
	arrow[3] = {x = x, y = y + 5}
	arrow[4] = {x = x - 4, y = y + 7.5}
	myRotation = myRotation * -1
	myRotation = math.rad(myRotation)
	for i = 1, 4 do
		local theirX = arrow[i].x
		local theirY = arrow[i].y
		theirX = theirX - x
		theirY = theirY - y
		arrow[i].x = theirX * math.cos(myRotation) - theirY * math.sin(myRotation)
		arrow[i].y = theirX * math.sin(myRotation) + theirY * math.cos(myRotation)
		arrow[i].x = arrow[i].x + x
		arrow[i].y = arrow[i].y + y
	end
	surface.DrawPoly(arrow)
end

local radarX, radarY, radarWidth, radarHeight = 50, ScrH() / 3, 200, 200
local function RadarDraw()
	local col = Color(gInt("Settings", "Window Color", "Red"),gInt("Settings", "Window Color", "Green"),gInt("Settings", "Window Color", "Blue"), 100)
	local col2 = Color(gInt("Settings", "Window Color", "Red"),gInt("Settings", "Window Color", "Green"),gInt("Settings", "Window Color", "Blue"), 200)
	local everything = ents.GetAll()
	draw.RoundedBox(0, gInt("Settings", "Positions", "Window X") +225, gInt("Settings", "Positions", "Window Y"), radarWidth, radarHeight, Color(0, 0, 0, 235 ))
	draw.RoundedBox(0, gInt("Settings", "Positions", "Window X") +225, gInt("Settings", "Positions", "Window Y"), radarWidth, 21, col)
	draw.RoundedBox(0, gInt("Settings", "Positions", "Window X") +225, gInt("Settings", "Positions", "Window Y"), 1, 200, col)
	draw.RoundedBox(0, gInt("Settings", "Positions", "Window X") +425, gInt("Settings", "Positions", "Window Y"), 1, 200, col)
	draw.RoundedBox(0, gInt("Settings", "Positions", "Window X") +225, gInt("Settings", "Positions", "Window Y") +200, 200, 1, col)
	draw.RoundedBox(0, gInt("Settings", "Positions", "Window X") +225, gInt("Settings", "Positions", "Window Y") +21, 200, 1, col)
	draw.RoundedBox(0, gInt("Settings", "Positions", "Window X") +225 +1, gInt("Settings", "Positions", "Window Y") +1, radarWidth -1, 20, Color(0, 0, 0, 25 ))
	draw.SimpleText("[ Radar ]", "MiscFont", gInt("Settings", "Positions", "Window X") +325, gInt("Settings", "Positions", "Window Y") +11, col2, 1, 1);
	draw.NoTexture()
	surface.SetDrawColor(team.GetColor(me:Team()))

	for k = 1, #everything do
		local v = everything[k]
		if (v:IsPlayer() and v:Health() > 0 and v:Team() != TEAM_SPECTATOR or (v:IsNPC() and v:Health() > 0)) then
			color = v:IsPlayer() and team.GetColor(v:Team()) or Color(255,255,255)
			surface.SetDrawColor(color)
			local myPos = me:GetPos()
			local theirPos = v:GetPos()
			local myAngles = me:GetAngles()
			local theirX = (radarX + (radarWidth / 2)) + ((theirPos.x - myPos.x) / 40)
			local theirY = (radarY + (radarHeight / 2)) + ((myPos.y - theirPos.y) / 40)

			local myRotation = myAngles.y - 90
			myRotation = math.rad(myRotation)
			theirX = theirX - (radarX + (radarWidth / 2))
			theirY = theirY - (radarY + (radarHeight / 2))
			local newX = theirX * math.cos(myRotation) - theirY * math.sin(myRotation)
			local newY = theirX * math.sin(myRotation) + theirY * math.cos(myRotation)
			newX = newX + (gInt("Settings", "Positions", "Window X") +2 + (radarWidth / 2))
			newY = newY + (gInt("Settings", "Positions", "Window Y") +2 + (radarHeight / 2))
			if newX < (gInt("Settings", "Positions", "Window X") +2 + radarWidth) and newX > gInt("Settings", "Positions", "Window X") +2 and newY < (gInt("Settings", "Positions", "Window Y") + radarHeight) and newY > gInt("Settings", "Positions", "Window Y") then
				DrawArrow(newX + 225, newY, v:EyeAngles().y - myAngles.y)
			end
		end
	end
end

--crosshair
local function crosshair()
if me:Health() < 1 then return end;
local x1, y1 = ScrW() * 0.5, ScrH() * 0.5;
surface.SetDrawColor(0,0,0);
surface.DrawOutlinedRect(x1-2, y1-2, 6, 6);
surface.SetDrawColor(gInt("Settings", "Crosshair Color", "Red"),gInt("Settings", "Crosshair Color", "Green"),gInt("Settings", "Crosshair Color", "Blue"), 225);
surface.DrawRect(x1-1, y1-1, 4, 4);
end

--fullbright
GAMEMODE:AddHook("RenderScene", "", function()
	render.SetLightingMode(gBool("Misc", "Misc", "Remove Shadows") && 1 || 0);
end)

GAMEMODE:AddHook("PostDrawViewmodel", "", function()
	render.SetLightingMode(0)
end)

GAMEMODE:AddHook("PreDrawEffects", "", function()
	render.SetLightingMode(0)
end)

--entity esp
local function MESP()
	for k, v in pairs( ents.FindByClass( "spawned_shipment" ) ) do
	local pos = em.GetPos(v) + Vector( 1,0,-6 );
	local pos2 = pos + Vector(0, 0, 70);
	local pos = vm.ToScreen(pos);
	local pos2 = vm.ToScreen(pos2);
	local h = pos.y - pos2.y;
	local w = h / 1.3
	local h = h/ 1.8
	local col = (Color(255,0,100));
	local color = Color(255, 0, 100);
	local Ent = v;
	local Dist = math.floor(Ent:GetPos():Distance(me:GetShootPos())/40)
	surface.SetDrawColor(col);
	surface.DrawOutlinedRect(pos.x - w / 2.1, pos.y - h /1.1, w, h);
	local ocol = (gBool("ESP", "Autism") && Color(math.random(255), math.random(255), math.random(255)) || Color(0,0,0));
	surface.SetDrawColor(ocol);
	surface.DrawOutlinedRect(pos.x - w / 2.1 - 1, pos.y - h /1.1 - 1, w + 2, h + 2);
	surface.DrawOutlinedRect(pos.x - w / 2.1 + 1, pos.y - h /1.1 + 1, w - 2, h - 2);
	draw.DrawText( "Shipment", "MiscFont", pos.x +w/50, pos.y + h /11, Color(255, 255, 255), 1 )
	surface.SetDrawColor(Color(0,0,0))
	end

	for k, v in pairs( ents.FindByClass( "spawned_weapon" ) ) do
	local pos = em.GetPos(v) + Vector( 1.5,0,-13.5 );
	local pos2 = pos + Vector(0, 0, 70);
	local pos = vm.ToScreen(pos);
	local pos2 = vm.ToScreen(pos2);
	local h = pos.y - pos2.y;
	local w = h / 1.3
	local h = h/ 3
	local col = (Color(100, 0, 255));
	local color = Color(100, 0, 255);
	local Ent = v;
	local Dist = math.floor(Ent:GetPos():Distance(me:GetShootPos())/40)
	surface.SetDrawColor(col);
	surface.DrawOutlinedRect(pos.x - w / 2, pos.y - h, w, h);
	local ocol = (gBool("ESP", "Autism") && Color(math.random(255), math.random(255), math.random(255)) || Color(0,0,0));
	surface.SetDrawColor(ocol);
	surface.DrawOutlinedRect(pos.x - w / 2 - 1, pos.y - h - 1, w + 2, h + 2);
	surface.DrawOutlinedRect(pos.x - w / 2 + 1, pos.y - h + 1, w - 2, h - 2);
	draw.SimpleText("Weapon", "MiscFont", pos.x, pos.y - h - 2 - (friendstatus == "friend" && 7 || 7), Color(255, 255, 255), 1, 1);
	surface.SetDrawColor(Color(0,0,0))
	end

	for k, v in pairs( ents.FindByClass( "spawned_money" ) ) do
	local pos = em.GetPos(v) + Vector( -0.5,0,-4.5 );
	local pos2 = pos + Vector(0, 0, 70);
	local pos = vm.ToScreen(pos);
	local pos2 = vm.ToScreen(pos2);
	local h = pos.y - pos2.y;
	local w = h / 6
	local h = h/ 7
	local col = (Color(0, 200, 0));
	local color = Color(0, 200, 0);
	local Ent = v;
	local Dist = math.floor(Ent:GetPos():Distance(me:GetShootPos())/40)
	surface.SetDrawColor(col);
	surface.DrawOutlinedRect(pos.x - w / 2, pos.y - h, w, h);
	local ocol = (gBool("Extra", "Autism") && HSVToColor(RealTime()*33%360,1,1) || Color(0,0,0));
	surface.SetDrawColor(ocol);
	surface.DrawOutlinedRect(pos.x - w / 2 - 1, pos.y - h - 1, w + 2, h + 2);
	surface.DrawOutlinedRect(pos.x - w / 2 + 1, pos.y - h + 1, w - 2, h - 2);
	draw.DrawText( "Money", "MiscFont", pos.x, pos.y, Color(255, 255, 255), 1 )
	surface.SetDrawColor(Color(0,0,0))
	end

	for k, v in pairs( ents.FindByClass( "weapon_mu_magnum" ) ) do
	local pos = em.GetPos(v) + Vector( 0,5,20 );
	local pos2 = pos + Vector(0, 0, 70);
	local pos = vm.ToScreen(pos);
	local pos2 = vm.ToScreen(pos2);
	local h = pos.y - pos2.y;
	local w = h / 3
	local h = h/ 3
	local col = (gBool("ESP", "Autism") && Color(math.random(255), math.random(255), math.random(255)) || Color(100,100,255));
	local color = Color(0,0,0);
	local Ent = v;
	local Dist = math.floor(Ent:GetPos():Distance(me:GetShootPos())/40)
	draw.DrawText( "Magnum", "MiscFont", pos.x -0, pos.y +10, Color(0,200,0))
	end

	for k, v in pairs( ents.FindByClass( "weapon_mu_knife" ) ) do
	local pos = em.GetPos(v) + Vector( 0,5,20 );
	local pos2 = pos + Vector(0, 0, 70);
	local pos = vm.ToScreen(pos);
	local pos2 = vm.ToScreen(pos2);
	local h = pos.y - pos2.y;
	local w = h / 3
	local h = h/ 3
	local col = (Color(100,100,255));
	local color = Color(0,0,0);
	local Ent = v;
	local Dist = math.floor(Ent:GetPos():Distance(me:GetShootPos())/40)
	draw.DrawText( "Knife", "MiscFont", pos.x -0, pos.y +10, Color(200,0,0))
	end

	for k, v in pairs( ents.FindByClass( "mu_loot" ) ) do
	local pos = em.GetPos(v) + Vector( -0.5,0,-12 );
	local pos2 = pos + Vector(0, 0, 70);
	local pos = vm.ToScreen(pos);
	local pos2 = vm.ToScreen(pos2);
	local h = pos.y - pos2.y;
	local w = h / 3
	local h = h/ 3
	local col = (Color(100,100,255));
	local color = Color(0,0,0);
	local Ent = v;
	local Dist = math.floor(Ent:GetPos():Distance(me:GetShootPos())/40)
	surface.SetDrawColor(col);
	surface.DrawOutlinedRect(pos.x - w / 2, pos.y - h, w, h);
	local ocol = (gBool("ESP", "Autism") && Color(math.random(255), math.random(255), math.random(255)) || Color(0,0,0));
	surface.SetDrawColor(ocol);
	surface.DrawOutlinedRect(pos.x - w / 2 - 1, pos.y - h - 1, w + 2, h + 2);
	surface.DrawOutlinedRect(pos.x - w / 2 + 1, pos.y - h + 1, w - 2, h - 2);
	draw.DrawText( "Loot", "MiscFont", pos.x, pos.y, Color(gInt("Settings", "Menu Color", "Red"), gInt("Settings", "Menu Color", "Green"), gInt("Settings", "Menu Color", "Blue")), 1 )
	surface.SetDrawColor(Color(0,0,0))
	end

	for k, v in pairs( ents.FindByClass( "gy_medkit" ) ) do
	local pos = em.GetPos(v) + Vector( 1,0,-6 );
	local pos2 = pos + Vector(0, 0, 70);
	local pos = vm.ToScreen(pos);
	local pos2 = vm.ToScreen(pos2);
	local h = pos.y - pos2.y;
	local w = h / 2
	local h = h/ 3.3
	local col = (Color(0, 200, 0));
	local color = Color(0, 200, 0);
	local Ent = v;
	local Dist = math.floor(Ent:GetPos():Distance(me:GetShootPos())/40)
	surface.SetDrawColor(col);
	surface.DrawOutlinedRect(pos.x - w / 2, pos.y - h /1.1, w, h);
	local ocol = (gBool("ESP", "Autism") && Color(math.random(255), math.random(255), math.random(255)) || Color(0,0,0));
	surface.SetDrawColor(ocol);
	surface.DrawOutlinedRect(pos.x - w / 2 - 1, pos.y - h /1.1 - 1, w + 2, h + 2);
	surface.DrawOutlinedRect(pos.x - w / 2 + 1, pos.y - h /1.1 + 1, w - 2, h - 2);
	draw.DrawText( "Health", "MiscFont", pos.x +w/50 -1, pos.y + h /11, Color(gInt("Settings", "Menu Color", "Red"), gInt("Settings", "Menu Color", "Green"), gInt("Settings", "Menu Color", "Blue")), 1 )
	surface.SetDrawColor(Color(0,0,0))
	end

	for k, v in pairs( ents.FindByClass( "weapon_ttt_c4" ) ) do
	local pos = em.GetPos(v) + Vector( 1,0,-6 );
	local pos2 = pos + Vector(0, 0, 70);
	local pos = vm.ToScreen(pos);
	local pos2 = vm.ToScreen(pos2);
	local h = pos.y - pos2.y;
	local w = h / 1.3
	local h = h/ 1.8
	local col = (Color(200, 0, 0));
	local color = Color(200, 0,0);
	local Ent = v;
	local Dist = math.floor(Ent:GetPos():Distance(me:GetShootPos())/40)
	draw.DrawText( "Traitor", "MiscFont", pos.x +w/50, pos.y + h /11, Color(255, 0, 100), 1 )
	end

	for k, v in pairs( ents.FindByClass( "weapon_ttt_knife" ) ) do
	local pos = em.GetPos(v) + Vector( 1,0,-6 );
	local pos2 = pos + Vector(0, 0, 70);
	local pos = vm.ToScreen(pos);
	local pos2 = vm.ToScreen(pos2);
	local h = pos.y - pos2.y;
	local w = h / 1.3
	local h = h/ 1.8
	local col = (Color(200,0,0));
	local color = Color(0,0,0);
	local Ent = v;
	local Dist = math.floor(Ent:GetPos():Distance(me:GetShootPos())/40)
	draw.DrawText( "Traitor", "MiscFont", pos.x +w/50, pos.y + h /11, Color(255, 0, 100), 1 )
	end

	for k, v in pairs( ents.FindByClass( "weapon_ttt_phammer" ) ) do
	local pos = em.GetPos(v) + Vector( 1,0,-6 );
	local pos2 = pos + Vector(0, 0, 70);
	local pos = vm.ToScreen(pos);
	local pos2 = vm.ToScreen(pos2);
	local h = pos.y - pos2.y;
	local w = h / 1.3
	local h = h/ 1.8
	local col = (Color(200,0,0));
	local color = Color(0,0,0);
	local Ent = v;
	local Dist = math.floor(Ent:GetPos():Distance(me:GetShootPos())/40)
	draw.DrawText( "Traitor", "MiscFont", pos.x +w/50, pos.y + h /11, Color(255, 0, 100), 1 )
	end

	for k, v in pairs( ents.FindByClass( "weapon_ttt_sipistol" ) ) do
	local pos = em.GetPos(v) + Vector( 1,0,-6 );
	local pos2 = pos + Vector(0, 0, 70);
	local pos = vm.ToScreen(pos);
	local pos2 = vm.ToScreen(pos2);
	local h = pos.y - pos2.y;
	local w = h / 1.3
	local h = h/ 1.8
	local col = (Color(200,0,0));
	local color = Color(0,0,0);
	local Ent = v;
	local Dist = math.floor(Ent:GetPos():Distance(me:GetShootPos())/40)
	draw.DrawText( "Traitor", "MiscFont", pos.x +w/50, pos.y + h /11, Color(255, 0, 100), 1 )
	end

	for k, v in pairs( ents.FindByClass( "weapon_ttt_flaregun" ) ) do
	local pos = em.GetPos(v) + Vector( 1,0,-6 );
	local pos2 = pos + Vector(0, 0, 70);
	local pos = vm.ToScreen(pos);
	local pos2 = vm.ToScreen(pos2);
	local h = pos.y - pos2.y;
	local w = h / 1.3
	local h = h/ 1.8
	local col = (Color(200,0,0));
	local color = Color(0,0,0);
	local Ent = v;
	local Dist = math.floor(Ent:GetPos():Distance(me:GetShootPos())/40)
	draw.DrawText( "Traitor", "MiscFont", pos.x +w/50, pos.y + h /11, Color(255, 0, 100), 1 )
	end

	for k, v in pairs( ents.FindByClass( "weapon_ttt_push" ) ) do
	local pos = em.GetPos(v) + Vector( 1,0,-6 );
	local pos2 = pos + Vector(0, 0, 70);
	local pos = vm.ToScreen(pos);
	local pos2 = vm.ToScreen(pos2);
	local h = pos.y - pos2.y;
	local w = h / 1.3
	local h = h/ 1.8
	local col = (Color(200,0,0));
	local color = Color(0,0,0);
	local Ent = v;
	local Dist = math.floor(Ent:GetPos():Distance(me:GetShootPos())/40)
	draw.DrawText( "Traitor", "MiscFont", pos.x +w/50, pos.y + h /11, Color(255, 0, 100), 1 )
	end

	for k, v in pairs( ents.FindByClass( "weapon_ttt_radio" ) ) do
	local pos = em.GetPos(v) + Vector( 1,0,-6 );
	local pos2 = pos + Vector(0, 0, 70);
	local pos = vm.ToScreen(pos);
	local pos2 = vm.ToScreen(pos2);
	local h = pos.y - pos2.y;
	local w = h / 1.3
	local h = h/ 1.8
	local col = (Color(200,0,0));
	local color = Color(0,0,0);
	local Ent = v;
	local Dist = math.floor(Ent:GetPos():Distance(me:GetShootPos())/40)
	draw.DrawText( "Traitor", "MiscFont", pos.x +w/50, pos.y + h /11, Color(255, 0, 100), 1 )
	end

	for k, v in pairs( ents.FindByClass( "weapon_ttt_teleport" ) ) do
	local pos = em.GetPos(v) + Vector( 1,0,-6 );
	local pos2 = pos + Vector(0, 0, 70);
	local pos = vm.ToScreen(pos);
	local pos2 = vm.ToScreen(pos2);
	local h = pos.y - pos2.y;
	local w = h / 1.3
	local h = h/ 1.8
	local col = (Color(200,0,0));
	local color = Color(0,0,0);
	local Ent = v;
	local Dist = math.floor(Ent:GetPos():Distance(me:GetShootPos())/40)
	draw.DrawText( "Traitor", "MiscFont", pos.x +w/50, pos.y + h /11, Color(255, 0, 100), 1 )
	end

	for k, v in pairs( ents.FindByClass( "(Disguise)" ) ) do
	local pos = em.GetPos(v) + Vector( 1,0,-6 );
	local pos2 = pos + Vector(0, 0, 70);
	local pos = vm.ToScreen(pos);
	local pos2 = vm.ToScreen(pos2);
	local h = pos.y - pos2.y;
	local w = h / 1.3
	local h = h/ 1.8
	local col = (Color(200,0,0));
	local color = Color(0,0,0);
	local Ent = v;
	local Dist = math.floor(Ent:GetPos():Distance(me:GetShootPos())/40)
	draw.DrawText( "Traitor", "MiscFont", pos.x +w/50, pos.y + h /11, Color(255, 0, 100), 1 )
	end

	for k, v in pairs( ents.FindByClass( "npc_*" ) ) do
	local col = Color(0, 255, 0);
	local col2 = Color(( 100 - em.Health(v) ) * 2.55, em.Health(v) * 2.55, 0, 255);
	local pos = em.GetPos(v);
	local min, max = em.GetCollisionBounds(v);
	local pos2 = pos + Vector(0, 0, max.z);
	local pos = vm.ToScreen(pos);
	local pos2 = vm.ToScreen(pos2);
	local hh = 0;
	local h = pos.y - pos2.y;
	local w = h / 1.7;
	local hp = em.Health(v) * h / 100;
	local health = em.Health(v);
	local col = (Color(255, 170, 0));
	local color = Color(255,170,0);
	local Ent = v;
	local Dist = math.floor(Ent:GetPos():Distance(me:GetShootPos())/40)
	if health < 0 then
	health = 0
	end
	if v:Health() > 0 then
	surface.SetDrawColor(col);
	surface.DrawOutlinedRect(pos.x - w / 2, pos.y - h, w, h);
	local ocol = (gBool("ESP", "Autism") && Color(math.random(255), math.random(255), math.random(255)) || Color(0,0,0));
	surface.SetDrawColor(ocol);
	surface.DrawOutlinedRect(pos.x - w / 2 - 1, pos.y - h - 1, w + 2, h + 2);
	surface.DrawOutlinedRect(pos.x - w / 2 + 1, pos.y - h + 1, w - 2, h - 2);
	draw.SimpleText(v:GetClass(), "ESPFont", pos.x, pos.y - h -2 - (friendstatus == "friend" && 7 || 7), Color(255, 255, 255), 1, 1);
	surface.SetDrawColor(Color(0,0,0))
	local col1 = Color((100 - em.Health(v)) * 2.55, em.Health(v) * 2.55, 0);
	draw.SimpleText(health.."HP", "ESPFont", pos.x, pos.y - 2, col1, 1, 0);
	if(hp > h) then hp = h; end
	local diff = h - hp;
	surface.SetDrawColor(0, 0, 0, 255);
	surface.DrawRect(pos.x - w / 2 - 7, pos.y - h - 1, 5, h + 2);
	surface.SetDrawColor(col2);
	surface.DrawRect(pos.x - w / 2 - 6, pos.y - h + diff, 3, hp);
	end
	end
end

--chat spam tables
local ChatTables = {
"Hey, guess what? Fuck you faggot ass piece of shit cunt motherfucker twat bitch faggot fuck nigger ass shit dickdick goat fucker cock sucker retard ass nigger fuck pussy ass bitch.",
"You are a cancer piece of shit, kill yourself.",
"You should rage quit you piece of shit.",
"I hate you and everything about you, you're a moron rofl.",
"End your life you sad nerd.",
"Fuck you lmaooooooooooooooooooooooooooooooooooooooooooooooo.",
"You are a stupid cancerous nigger.",
"Stupid jew fuck ass twat ass nigger.",
"Twat pocket cunt fucker titty shitter dick licker.",
"Kike ass motherfucking shekel stealing ass jew bitch.",
"Stinky ass mother fucking nigger-jew.",
}

local ChatTables2 = {
"I have a big African Shlong.",
"I will fuck your dead grandmother's corpse.",
"Fuck niggers, they are stinky and have aids.",
"Hitler was my hero, and he's also my idol.",
"I am in the Ku Klux Klan.",
"Dead babies are delicious.",
"I have a big African Shlong.",
"I live in a fucking yurt.",
"Back in my days they called me fetus puncher.",
"I beat up nigger babies.",
}

local ChatTables4 = {
" is a faggot.",
" is a bitch.",
" is a retard.",
" is an asshole.",
" is an autist.",
" is a nerd.",
" is cancer.",
" is a shithead.",
" is a dickhead.",
" is an asshat.",
" is a dick.",
" is a chode.",
" is a mexican.",
" is a nigger.",
" is a poopbutt.",
" is a shitdick.",
" is a cunt.",
" is a twat.",
" is a jew.",
" is aids.",
}

local ChatTables5 = {
"your mom",
"your dad",
"your dog",
"your cat",
"your sister",
"your brother",
}

--Open Menu/Think
local namechangeTime = 0;
local function Think()
	if (input.IsKeyDown(KEY_INSERT) && !menuopen && !insertdown) then
		menuopen = true;
		insertdown = true;
		menu();
	elseif (!input.IsKeyDown(KEY_INSERT) && !menuopen) then
		insertdown = false;
	end
	if (input.IsKeyDown(KEY_INSERT) && insertdown && menuopen) then
		insertdown2 = true;
	else
		insertdown2 = false;
	end

	--chat spammer
	if(gBool("Misc", "Chat", "Spam") && gOption("Misc", "Chat", "Spam Type") == "Jokes") then
		RunConsoleCommand("say", ChatTables2[math.random(#ChatTables2)])
	end

	if(gBool("Misc", "Chat", "Spam") && gOption("Misc", "Chat", "Spam Type") == "OOC") then
		RunConsoleCommand("say", "// hak de planet!")
	end

	if(gBool("Misc", "Chat", "Spam") && gOption("Misc", "Chat", "Spam Type") == "Insult") then
	local player = player;
	local math = math;
	local randply = player.GetAll()[math.random(#player.GetAll())]
	local friendstatus = pm.GetFriendStatus(randply);

	if (!randply:IsValid() || randply == me || (friendstatus == "friend")) then return; end
		RunConsoleCommand("say", randply:Name()..ChatTables4[math.random(#ChatTables4)])
	end

	if(gBool("Misc", "Chat", "Spam") && gOption("Misc", "Chat", "Spam Type") == "Money") then
		RunConsoleCommand("say", "/dropmoney "..math.random(2,10))
	end

	if(gBool("Misc", "Chat", "Spam") && gOption("Misc", "Chat", "Spam Type") == "Shoutout") then
		RunConsoleCommand("say", "~PASTEWARE~ || Owns your "..ChatTables5[math.random(#ChatTables5)]..".")
	end

	if(gBool("Misc", "Chat", "Spam") && gOption("Misc", "Chat", "Spam Type") == "Message") then
		local v = player.GetAll()[math.random(#player.GetAll())]
		if (v != me && v:GetFriendStatus() != "friend" && !pm.IsAdmin(v)) then
			LocalPlayer():ConCommand("ulx psay \"".. v:Nick() .."\" "..ChatTables[math.random(#ChatTables)]);
		end
	end

	if(gBool("Misc", "Emotes", "Enabled") && gOption("Misc", "Emotes", "Emote Type") == "Dance") then
		RunConsoleCommand("act", "dance")
	end

	if(gBool("Misc", "Emotes", "Enabled") && gOption("Misc", "Emotes", "Emote Type") == "Sexy") then
		RunConsoleCommand("act", "muscle")
	end

	if(gBool("Misc", "Emotes", "Enabled") && gOption("Misc", "Emotes", "Emote Type") == "Wave") then
		RunConsoleCommand("act", "wave")
	end

	if(gBool("Misc", "Emotes", "Enabled") && gOption("Misc", "Emotes", "Emote Type") == "Robot") then
		RunConsoleCommand("act", "robot")
	end

	if(gBool("Misc", "Emotes", "Enabled") && gOption("Misc", "Emotes", "Emote Type") == "Bow") then
		RunConsoleCommand("act", "bow")
	end

	if(gBool("Misc", "Emotes", "Enabled") && gOption("Misc", "Emotes", "Emote Type") == "Cheer") then
		RunConsoleCommand("act", "cheer")
	end

	if(gBool("Misc", "Emotes", "Enabled") && gOption("Misc", "Emotes", "Emote Type") == "Laugh") then
		RunConsoleCommand("act", "laugh")
	end

	if(gBool("Misc", "Emotes", "Enabled") && gOption("Misc", "Emotes", "Emote Type") == "Zombie") then
		RunConsoleCommand("act", "zombie")
	end

	if(gBool("Misc", "Emotes", "Enabled") && gOption("Misc", "Emotes", "Emote Type") == "Agree") then
		RunConsoleCommand("act", "agree")
	end

	if(gBool("Misc", "Emotes", "Enabled") && gOption("Misc", "Emotes", "Emote Type") == "Disagree") then
		RunConsoleCommand("act", "disagree")
	end

	if(gBool("Misc", "Emotes", "Enabled") && gOption("Misc", "Emotes", "Emote Type") == "Forward") then
		RunConsoleCommand("act", "forward")
	end

	if(gBool("Misc", "Emotes", "Enabled") && gOption("Misc", "Emotes", "Emote Type") == "Back") then
		RunConsoleCommand("act", "becon")
	end

	if(gBool("Misc", "Emotes", "Enabled") && gOption("Misc", "Emotes", "Emote Type") == "Salute") then
		RunConsoleCommand("act", "salute")
	end

	if(gBool("Misc", "Emotes", "Enabled") && gOption("Misc", "Emotes", "Emote Type") == "Wave") then
		RunConsoleCommand("act", "wave")
	end

	if(gBool("Misc", "Emotes", "Enabled") && gOption("Misc", "Emotes", "Emote Type") == "Pose") then
		RunConsoleCommand("act", "pers")
	end

	if(gBool("Misc", "Emotes", "Enabled") && gOption("Misc", "Emotes", "Emote Type") == "Halt") then
		RunConsoleCommand("act", "halt")
	end

	if(gBool("Misc", "Emotes", "Enabled") && gOption("Misc", "Emotes", "Emote Type") == "Group") then
		RunConsoleCommand("act", "group")
	end

	if(gBool("Misc", "Misc", "Flashlight Spam")) then
		RunConsoleCommand("impulse", "100" )
	end

	--namestealer
	if(gBool("Misc", "Chat", "Name Stealer")) then
	local player = player;
	local math = math;
	local randply = player.GetAll()[math.random(#player.GetAll())]
	local friendstatus = pm.GetFriendStatus(randply);
	local rank = pm.IsAdmin(randply);
	GAMEMODE:RemoveHook("Think", "nametaker2")
	GAMEMODE:AddHook("Think", "nametaker", function()
		if (!randply:IsValid() || randply == me || friendstatus == "friend" || rank ) then return; end
		_fhook_changename(randply:Name().." ");
		end)
	elseif(!gBool("Misc", "Chat", "Name Stealer")) then
	GAMEMODE:RemoveHook("Think", "nametaker")
	GAMEMODE:AddHook("Think", "nametaker2", function()
		_fhook_changename(myName);
		end)
	end

if(gBool("Misc", "Chat", "Name Stealer") && gOption("Misc", "Chat", "Steal Type") == "DarkRP") then
	local v = player.GetAll()[math.random(#player.GetAll())]
	local scrambledName = string.sub(v:Nick(), 1, 1)..v:Nick();
	local friendstatus = pm.GetFriendStatus(v);
	local rank = pm.IsAdmin(v);
	namechangeTime = namechangeTime + 1;
	if namechangeTime > 650 then
	if (v != me || friendstatus != "friend" || rank ) then
	RunConsoleCommand("say", "/name "..scrambledName);
	namechangeTime = 0;
	end
	end
	end
end

GAMEMODE:AddHook("Think", "", Think);

--esp distance filter
local function Filter(v)
if(gBool("Settings", "Filter", "ESP")) then
	local friendstatus = pm.GetFriendStatus(v);
	if friendstatus == "friend" then return true; end
	local dist = gBool("Settings", "Filter", "Distance");
	if( vm.Distance( em.GetPos(v), em.GetPos(me) ) > (dist * 5) ) then return false; end
	end
	return true;
end

 --chams
local function GetChamsColor(v)
        if(pm.Team(v) == pm.Team(me)) then
			local r = gInt("Settings", "Team Chams Color", "Red");
			local g = gInt("Settings", "Team Chams Color", "Green");
			local b = gInt("Settings", "Team Chams Color", "Blue");
			return(Color(r, g, b, 220));
        end
			local r = gInt("Settings", "Enemy Chams Color", "Red");
			local g = gInt("Settings", "Enemy Chams Color", "Green");
			local b = gInt("Settings", "Enemy Chams Color", "Blue");
        return(Color(r, g, b, 220));
end

local chamsmat = CreateMaterial("a", "VertexLitGeneric", {
	["$ignorez"] = 1,
	["$model"] = 1,
	["$basetexture"] = "models/debug/debugwhite",
});

local chamsmat2 = CreateMaterial("@", "VertexLitGeneric", {
	["$ignorez"] = 0,
	["$model"] = 1,
	["$basetexture"] = "models/debug/debugwhite",
});

local function Chams(v)
if(gBool("Visuals", "ESP", "XQZ")) then
		cam.Start3D();
			cam.IgnoreZ(true);
			em.DrawModel(v);
			cam.IgnoreZ(false);
		cam.End3D();
	end
if(gBool("Visuals", "ESP", "Chams")) then
local col = gBool("Visuals", "Misc", "Team Colors") && team.GetColor(pm.Team(v)) || GetChamsColor(v);
	local wep = v:GetActiveWeapon()
	if wep:IsValid() then
	cam.Start3D();
	render.MaterialOverride(chamsmat);
	render.SetColorModulation(col.r/255, col.g/255, col.b/255, 255);
	em.DrawModel(wep);
	render.SetColorModulation(col.r/170, col.g/170, col.b/170, 255);
	render.MaterialOverride(chamsmat2);
	em.DrawModel(wep);
	cam.End3D();
	end

	cam.Start3D();
	render.MaterialOverride(chamsmat);
	render.SetColorModulation(col.b / 255, col.r / 255, col.g / 255);
	em.DrawModel(v);
	render.SetColorModulation(col.r / 255, col.g / 255, col.b / 255);
	render.MaterialOverride(chamsmat2);
	em.DrawModel(v);
	render.SetColorModulation(1, 1, 1);
	cam.End3D();
	end
end

local function Bunnyhop(ucmd)
local duckEstimate = math.Round(58 + 1 / engine.TickInterval());
if(!gBool("Misc", "Misc", "Bunnyhop") || em.GetMoveType(me) == MOVETYPE_NOCLIP || me:Health() < 1) then return; end
	if(cm.KeyDown(ucmd, 2) && !em.IsOnGround(me)) then
		cm.SetButtons(ucmd, bit.band( cm.GetButtons(ucmd), bit.bnot( 2 ) ) );
	if(gBool("Misc", "Misc", "  + Autostrafe")) then
	if(!me:IsOnGround()) then
			ucmd:RemoveKey(2);
		if(ucmd:GetMouseX() > 1 || ucmd:GetMouseX() < -1) then
		if(ucmd:GetMouseX() < 0) then
			ucmd:SetSideMove(-400);
		else
			ucmd:SetSideMove(400);
		end
		end
		else
			ucmd:SetForwardMove(5850 / LocalPlayer():GetVelocity():Length2D());
			ucmd:SetSideMove((ucmd:CommandNumber() % 2) == 0 && -400 || 400);
		end
		else
		if(ucmd:KeyDown(2)) then
			ucmd:SetForwardMove(400);
			end
		end
	end
end

--no sky
function GAMEMODE:PreDrawSkyBox()
	if (!gBool("Misc", "Misc", "Remove Sky")) then return; end
	render.Clear(0, 0, 0, 255);
	return true;
end

--wireframe
local wireframeMat = Material("models/wireframe");
GAMEMODE:AddHook("PreDrawViewModel", "", function()
	if(!gBool("Visuals", "Viewmodel", "Colored Wireframe") || gBool("Visuals", "Extra", "Thirdperson")) then return; end
	local WepMat = Material("models/wireframe")
	render.MaterialOverride(WepMat);
	render.SetColorModulation(gInt("Visuals", "Viewmodel", "Red") /255,gInt("Visuals", "Viewmodel", "Green") /255,gInt("Visuals", "Viewmodel", "Blue") /255);
end);

--no hands
GAMEMODE:AddHook("PreDrawPlayerHands", "", function()
	if(gBool("Visuals", "Viewmodel", "No Hands") || gBool("Visuals", "Extra", "Thirdperson")) then
	return true;
	else
	return false;
	end
end);

 gameevent.Listen("player_say");
    hook.Add("player_say", "", function()
	if(!gBool("Misc", "Chat", "'Shut up' as Response")) then return; end
		RunConsoleCommand("say", "shut up")
	end);

local function GetColor(v)
        if(pm.Team(v) == pm.Team(me)) then
			local r = gInt("Settings", "Team ESP Color", "Red");
			local g = gInt("Settings", "Team ESP Color", "Green");
			local b = gInt("Settings", "Team ESP Color", "Blue");
			return(Color(r, g, b, 220));
        end
			local r = gInt("Settings", "Enemy ESP Color", "Red");
			local g = gInt("Settings", "Enemy ESP Color", "Green");
			local b = gInt("Settings", "Enemy ESP Color", "Blue");
		return(Color(r, g, b, 220));
end

local function GetColor2(v)
        if(pm.Team(v) == pm.Team(me)) then
			local r = gInt("Settings", "Team ESP Color", "Red");
			local g = gInt("Settings", "Team ESP Color", "Green");
			local b = gInt("Settings", "Team ESP Color", "Blue");
			return(Color(r, g, b, 25));
        end
			local r = gInt("Settings", "Enemy ESP Color", "Red");
			local g = gInt("Settings", "Enemy ESP Color", "Green");
			local b = gInt("Settings", "Enemy ESP Color", "Blue");
        return(Color(r, g, b, 25));
end

--esp
local function ESP(v)
	local pos = em.GetPos(v);
	local min, max = em.GetCollisionBounds(v);
	local pos2 = pos + Vector(0, 0, max.z);
	local pos = vm.ToScreen(pos);
	local pos2 = vm.ToScreen(pos2);
	local hh = 0;
	local h = pos.y - pos2.y;
	local w = h / 2;
	local col = gBool("Visuals", "ESP", "Team Colors") && team.GetColor(pm.Team(v)) || GetColor(v);
	local col2 = gBool("Visuals", "ESP", "Team Colors") && team.GetColor(pm.Team(v), 25) || GetColor2(v);
	local ocol = gBool("Extra", "Autism") && HSVToColor(RealTime()*33%360,1,1) || Color(0,0,0);
	local color = team.GetColor(pm.Team(v));
	local hh = 0;

        surface.SetFont("ESPFont");
        surface.SetTextColor(255, 255, 255);

	if(gBool("Visuals", "ESP", "Box") && gOption("Visuals", "ESP", "Box Type") == "2D Box") then
		local friendstatus = pm.GetFriendStatus(v);
		if (friendstatus == "friend") then
			surface.SetDrawColor(HSVToColor(RealTime()*65%360,1,1));
			surface.DrawOutlinedRect(pos.x - w / 2, pos.y - h, w, h);
			surface.DrawOutlinedRect(pos.x - w / 2 - 1, pos.y - h - 1, w + 2, h + 2);
			surface.DrawOutlinedRect( pos.x - w / 2 + 2, pos.y - h + 2, w - 4, h - 4);
		end
	end

	if(gBool("Visuals", "ESP", "Box") && gOption("Visuals", "ESP", "Box Type") == "2D Box") then
		surface.SetDrawColor(col);
		surface.DrawOutlinedRect(pos.x - w / 2, pos.y - h, w, h);
		surface.SetDrawColor(ocol);
		surface.DrawOutlinedRect(pos.x - w / 2 - 1, pos.y - h - 1, w + 2, h + 2);
		surface.DrawOutlinedRect(pos.x - w / 2 + 1, pos.y - h + 1, w - 2, h - 2);
		hook.Remove( "HUDPaint", "3D-Box", function()
		end)
	end

	if(gBool("Visuals", "ESP", "Box") && gOption("Visuals", "ESP", "Box Type") == "3D Box") then
		local eye = v:EyeAngles();
		local min, max = v:WorldSpaceAABB();
		local origin = v:GetPos();
		local friendstatus = pm.GetFriendStatus(v);
		if (friendstatus == "friend") then
			cam.Start3D()
			render.DrawWireframeBox( origin,  Angle(0, eye.y, 0), min-origin, max-origin, HSVToColor(RealTime()*65%360,1,1))
			cam.End3D()
		end
	end

	if(gBool("Visuals", "ESP", "Box") && gOption("Visuals", "ESP", "Box Type") == "3D Box") then
		hook.Add( "HUDPaint", "3D-Box", function()
	for k,v in pairs(player.GetAll()) do
		if v != LocalPlayer() and v:IsValid() and v:Alive() and v:Health() >= 0 then
			local eye = v:EyeAngles();
			local min, max = v:WorldSpaceAABB();
			local origin = v:GetPos();
			cam.Start3D()
				render.DrawWireframeBox( origin,  Angle(0, eye.y, 0), min-origin, max-origin, Color(255,0,0))
			cam.End3D()
		end
	end
	end)
	end

	if(gBool("Visuals", "ESP", "Healthbar")) then
		local col = Color(( 100 - em.Health(v) ) * 2.55, em.Health(v) * 2, 0, 255);
		local hp = em.Health(v) * h / 100;
		if(hp > h) then hp = h; end
		local diff = h - hp;
		surface.SetDrawColor(0, 0, 0, 255);
		surface.DrawRect(pos.x - w / 2 - 8, pos.y - h - 1, 5, h + 2);
		surface.SetDrawColor( ( 100 - em.Health(v) ) * 2.55, em.Health(v) * 2.55, 0, 255);
		surface.DrawRect(pos.x - w / 2 - 7, pos.y - h + diff, 3, hp);
	end

	if(gBool("Visuals", "ESP", "Name")) then
        local col1 = Color(255,255,255)
		local col2 = Color(100,100,255);
		local friendstatus = pm.GetFriendStatus(v);
		draw.SimpleText(pm.Name(v), "ESPFont", pos.x, pos.y - h - 1 - (friendstatus == "friend" && 12 || 12), col1, 1, 1);
		if (friendstatus == "friend") then
		draw.SimpleText("Friend", "ESPFont", pos.x, pos.y - h - 13 - 13, HSVToColor(RealTime()*65%360,1,1), 1, 1);
	end

	if(gBool("Visuals", "ESP", "Admins")) then
		if pm.IsAdmin(v) then
		if(gBool("Visuals", "ESP", "Box") && gOption("Visuals", "ESP", "Box Type") == "2D Box") then
		surface.SetDrawColor(255,0,0);
		surface.DrawOutlinedRect(pos.x - w / 2, pos.y - h, w, h);
		surface.DrawOutlinedRect(pos.x - w / 2 - 1, pos.y - h - 1, w + 2, h + 2);
		surface.DrawOutlinedRect(pos.x - w / 2 + 1, pos.y - h + 1, w - 2, h - 2);
		end
		if(gBool("Visuals", "ESP", "Name")) then
		draw.SimpleText("ADMIN", "ESPFont", pos.x, pos.y - h - 13 - 20, Color(255,0,0))
			end
		end
	end

	if(gBool("Visuals", "ESP", "Health Value")) then
		hh = hh + 1;
		local col1 = Color((100 - em.Health(v)) * 2.55, em.Health(v) * 2, 0);
		draw.SimpleText(em.Health(v).."HP", "ESPFont", pos.x, pos.y - 2 + hh, col1, 1, 0);
		hh = hh + 9;
	end

	if(gBool("Visuals", "ESP", "Weapon")) then
		hh = hh + 1;
		local w = pm.GetActiveWeapon(v);
		if(w && em.IsValid(w)) then
		local col = Color(200,150,150);
		draw.SimpleText(w:GetPrintName(), "ESPFont", pos.x, pos.y - 0 + hh, col, 1, 0);
		hh = hh + 9;
		end
	end

	if(gBool("Visuals", "ESP", "Rank")) then
	hh = hh + 1;
	local col = Color(255,255,255);
	draw.SimpleText(pm.GetUserGroup(v), "ESPFont", pos.x, pos.y - 0 + hh, col, 1, 0);
	hh = hh + 9;
	end

	if(gBool("Visuals", "ESP", "Ping")) then
	hh = hh + 1;
	local col1 = Color(v:Ping() * 2.55, 255 - v:Ping() - 5 * 2, 0);
	draw.SimpleText(v:Ping().."ms", "ESPFont", pos.x, pos.y - -2 + hh, col1, 1, 0);
	hh = hh + 9;
	end

	if(gBool("Visuals", "ESP", "Skeleton")) then
		local col = gBool("Visuals", "Misc", "Team Colors") && team.GetColor(pm.Team(v)) || GetColor(v);
		local pos = em.GetPos(v);
		for i = 0, em.GetBoneCount(v) do
		local parent = em.GetBoneParent(v, i);
		if(!parent) then continue; end
		local bonepos = em.GetBonePosition(v, i);
		if(bonepos == pos) then continue; end
		local parentpos = em.GetBonePosition(v, parent);
		if(!bonepos || !parentpos) then continue; end
		local screen1, screen2 = vm.ToScreen(bonepos), vm.ToScreen(parentpos);
		surface.SetDrawColor(col);
		surface.DrawLine(screen1.x, screen1.y, screen2.x, screen2.y);
		end
	end

	if(gBool("Visuals", "ESP", "Health Skeleton")) then
			local origin = em.GetPos(v);
			for i = 1, em.GetBoneCount(v) do
					local parent = em.GetBoneParent(v, i);
					if(!parent) then continue; end
					local bonepos, parentpos = em.GetBonePosition(v, i), em.GetBonePosition(v, parent);
					if(!bonepos || !parentpos || bonepos == origin) then continue; end
					local bs, ps = vm.ToScreen(bonepos), vm.ToScreen(parentpos);
					local hp = em.Health(v) * h / 100;
			if(hp > h) then hp = h; end
			local diff = h - hp;
			surface.SetDrawColor(0, 0, 0, 255);
			surface.SetDrawColor( ( 100 - em.Health(v) ) * 2.55, em.Health(v) * 2.55, 0, 255);
			surface.DrawLine(bs.x, bs.y, ps.x, ps.y);
			end
		end
	end
end

--snapline
local aimtarget;
GAMEMODE:AddHook("HUDPaint", "", function()

if mode == 0 and fs then
	if not rec then
		rec = Material( 'gmod/recording.png' )
	end

	surface.SetDrawColor( color_white )
	surface.SetMaterial( rec )
	surface.DrawTexturedRect( ScrW() - 512, 0, 512, 256, 0 )
end

if mode == 1 then
	local prev
	for k, v in pairs( waypoints ) do
		local scr = v:ToScreen()
		if not scr.visible then continue end

		if prev and prev.x and prev.y then
			surface.SetDrawColor( color_white )
			surface.DrawLine( prev.x, prev.y, scr.x, scr.y )
		end

		DrawFancyBox( v, next_waypoint == k and Color(0, 225, 0) or Color(255, 0, 100) )
		prev = scr
	end
end

if(aimtarget && aimtarget:IsValid() && gBool("Aimbot", "Extra", "Snapline")) then
		if me:Health() > 0 then
		local col = Color(gInt("Settings", "Crosshair Color", "Red"),gInt("Settings", "Crosshair Color", "Green"),gInt("Settings", "Crosshair Color", "Blue"), 125);
		local pos = vm.ToScreen(em.LocalToWorld(aimtarget, em.OBBCenter(aimtarget)));
		surface.SetDrawColor(col);
		surface.DrawLine(ScrW() / 2, ScrH() / 2, pos.x, pos.y);
		surface.SetDrawColor(0,0,0);
		surface.DrawOutlinedRect(pos.x -2, pos.y -2, 5, 5);
		surface.SetDrawColor(gInt("Settings", "Crosshair Color", "Red"),gInt("Settings", "Crosshair Color", "Green"),gInt("Settings", "Crosshair Color", "Blue"));
		surface.DrawRect(pos.x -1, pos.y -1, 3, 3);
		end
	end

	if(gBool("Visuals", "ESP", "Enabled")) then
		for k,v in next, player.GetAll() do
		if(!em.IsValid(v) || em.Health(v) < 1 || v == me || pm.Team(v) == TEAM_SPECTATOR) then continue; end
		if(!Filter(v)) then continue; end
		ESP(v);
		end
	end

	if(gBool("Visuals", "ESP", "Entities")) then
	MESP();
	end

	if(gBool("Visuals", "Extra", "Radar")) then
	RadarDraw();
	end

	if(gBool("Visuals", "Extra", "Display Status")) then
	Status();
	end

	if(gBool("Visuals", "Extra", "Spectators")) then
	spectator();
	end

	if(gBool("Visuals", "Extra", "Crosshair")) then
	crosshair();
	end
end);

GAMEMODE:AddHook("RenderScreenspaceEffects", "", function()
if(!gBool("Visuals", "ESP", "Enabled")) then return; end
	for k,v in next, player.GetAll() do
		if(!em.IsValid(v) || em.Health(v) < 1 || v == me || pm.Team(v) == TEAM_SPECTATOR) then continue; end
		if(!Filter(v)) then continue; end
		Chams(v);
	end
end);

local fa;
local aa;
local oldAngles = Angle();
local function normalizeAngle(ang)
	ang.p = math.NormalizeAngle(ang.p);
	ang.p = math.Clamp(ang.p, -89, 89);
	ang.y = math.NormalizeAngle(ang.y);
end

--fix movement
local function FixMovement(ucmd)
	local vec = Vector(cm.GetForwardMove(ucmd), cm.GetSideMove(ucmd), 0);
	local vel = math.sqrt(vec.x*vec.x + vec.y*vec.y);
	local mang = vm.Angle(vec);
	local yaw = cm.GetViewAngles(ucmd).y - fa.y + mang.y;
	if (((cm.GetViewAngles(ucmd).p+90)%360) > 180) then
	yaw = 180 - yaw;
	end
	yaw = ((yaw + 180)%360)-180;
	ucmd:SetForwardMove(math.cos(math.rad(yaw)) * vel);
	ucmd:SetSideMove(math.sin(math.rad(yaw)) * vel);
end

local function Clamp(val, min, max)
        if(val < min) then
                return min;
        elseif(val > max) then
                return max;
        end
        return val;
end

local function NormalizeAngle(ang)
	ang.x = math.NormalizeAngle(ang.x);
	ang.p = math.Clamp(ang.p, -89, 89);
end

--autowall
local trace_walls = bit.bor(CONTENTS_TESTFOGVOLUME, CONTENTS_EMPTY, CONTENTS_MONSTER, CONTENTS_HITBOX);
local NoPenetration = {[MAT_SLOSH] = true};
local PenMod = {[MAT_SAND] = 0.5, [MAT_DIRT] = 0.8, [MAT_METAL] = 1.1, [MAT_TILE] = 0.9, [MAT_WOOD] = 1.2};
local trace_normal = bit.bor(CONTENTS_SOLID, CONTENTS_OPAQUE, CONTENTS_MOVEABLE, CONTENTS_DEBRIS, CONTENTS_MONSTER, CONTENTS_HITBOX, 402653442, CONTENTS_WATER);

local function fasAutowall(wep, startPos, aimPos, ply)
	if !gBool("Aimbot", "Extra", "AutoWall") then return end;
    local traces = {};
    local traceResults = {};
    local dir = (aimPos - startPos):GetNormalized();
    traces[1] = { start = startPos, filter = me, mask = trace_normal, endpos = aimPos, };
    traceResults[1] = util.TraceLine(traces[1]);
    if(NoPenetration[traceResults[1].MatType]) then return false; end
    if(-dir:DotProduct(traceResults[1].HitNormal) <= .26) then return false; end

    traces[2] = { start = traceResults[1].HitPos, endpos = traceResults[1].HitPos + dir * wep.PenStr * (PenMod[traceResults[1].MatType] || 1) * wep.PenMod, filter = me, mask = trace_walls, };
    traceResults[2] = util.TraceLine(traces[2]);
    traces[3] = { start = traceResults[2].HitPos, endpos = traceResults[2].HitPos + dir * .1, filter = me, mask = trace_normal, };
    traceResults [3] = util.TraceLine(traces[3]);
    traces[4] = { start = traceResults[2].HitPos, endpos = aimPos, filter = me, mask = MASK_SHOT, };
    traceResults[4] = util.TraceLine(traces[4]);
    if(traceResults[4].Entity != ply) then return false; end
    return(!traceResults[3].Hit);
end

local function m9kAutowall(wep)
	if !gBool("Aimbot", "Extra", "AutoWall") then return end;
	local wep = me:GetActiveWeapon();
    local trace = {
        endpos = aimPos,
        start = me:EyePos(),
        mask = MASK_SHOT,
        filter = me,
    };
    return wep:BulletPenetrate(10, nil, util.TraceLine(trace), DamageInfo());
end

local table = Copy(table);
local dists = {};
local function GetPos(v)
	if(gBool("Aimbot", "Aim Options", "Ignore Head")) then return(em.LocalToWorld(v, em.OBBCenter(v))); end
	local eyes = em.LookupAttachment(v, "eyes");
	if(!eyes) then return( em.LocalToWorld(v, em.OBBCenter(v))); end
	local pos = em.GetAttachment(v, eyes);
	if(!pos) then return( em.LocalToWorld(v, em.OBBCenter(v))); end
	return(pos.Pos);
end

paste.AddHook("entity_killed", function(data)
	if(!gBool("Misc", "Chat", "Death Notify")) then return end

	local inflictor = paste.Entity(data.entindex_inflictor)
	local killer = paste.Entity(data.entindex_attacker)
	local victim = paste.Entity(data.entindex_killed)

	if (paste.IsValid(killer) and paste.IsValid(victim) and killer:IsPlayer() and victim:IsPlayer()) then
	paste.surface.PlaySound(paste.table.Random(paste.cough))
		if (killer == victim and victim ~= ply) then
			chat.AddText(Color(math.random(255), math.random(255), math.random(255)), "[", "PASTEWARE", "] ", Color( 255, 255, 255 ), victim:Nick() .. " killed themself.")
		elseif (killer == victim and victim == ply) then
			chat.AddText(Color(math.random(255), math.random(255), math.random(255)), "[", "PASTEWARE", "] ", Color( 255, 255, 255 ), "You killed yourself.")
		elseif (killer == ply) then
			chat.AddText(Color(math.random(255), math.random(255), math.random(255)), "[", "PASTEWARE", "] ", Color( 255, 255, 255 ), "You killed " .. victim:Nick() .. ".")
		elseif (victim == ply) then
			chat.AddText(Color(math.random(255), math.random(255), math.random(255)), "[", "PASTEWARE", "] ", Color( 255, 255, 255 ), "You were killed by " .. killer:Nick() .. ".")
		else
			chat.AddText(Color(math.random(255), math.random(255), math.random(255)), "[", "PASTEWARE", "] ", Color( 255, 255, 255 ), killer:Nick() .. " killed " .. victim:Nick() .. ".")
		end
	elseif (paste.IsValid(victim) and not killer:IsPlayer() and victim:IsPlayer()) then
	paste.surface.PlaySound(paste.table.Random(paste.cough))
		if (paste.IsValid(inflictor) and inflictor:GetClass() == "prop_physics") then
			if (victim == ply) then
				chat.AddText(Color(math.random(255), math.random(255), math.random(255)), "[", "PASTEWARE", "] ", Color( 255, 255, 255 ), "You were killed by a prop.")
			else
				chat.AddText(Color(math.random(255), math.random(255), math.random(255)), "[", "PASTEWARE", "] ", Color( 255, 255, 255 ), victim:Nick() .. " was killed by a prop.")
			end
		elseif (victim == ply) then
			chat.AddText(Color(math.random(255), math.random(255), math.random(255)), "[", "PASTEWARE", "] ", Color( 255, 255, 255 ), "You were killed by life.")
		else
			chat.AddText(Color(math.random(255), math.random(255), math.random(255)), "[", "PASTEWARE", "] ", Color( 255, 255, 255 ), victim:Nick() .. " was killed by life.")
		end
	end
end)

--valid check for aimbot
local aimignore;
local function Valid(v)
    local wep = me:GetActiveWeapon();
    if(!v || !em.IsValid(v) || v == me || em.Health(v) < 1 || em.IsDormant(v) || pm.Team(v) == 1002 || (v == aimignore && gOption("Aimbot", "Aim Options", "Selection") == "Random")) then return false; end
    if(gBool("Aimbot", "Aim Options", "Ignore Team")) then
        if(pm.Team(v) == pm.Team(me)) then return false; end
    end
    if(gBool("Aimbot", "Aim Options", "Ignore Friends")) then
        if(pm.GetFriendStatus(v) == "friend") then return false; end
    end
		if(gBool("Aimbot", "Aim Options", "Ignore Bots")) then
		if(pm.IsBot(v)) then return false; end
	end
    if(gBool("Aimbot", "Aim Options", "Ignore Admins")) then
        if pm.IsAdmin(v) then return false; end
    end
    if(gBool("Aimbot", "Aim Options", "Ignore Spawn-Protected")) then
        if em.GetColor(v).a < 255 then return false; end
    end
    local tr = {
        start = em.EyePos(me),
        endpos = GetPos(v),
        mask = MASK_SHOT,
        filter = {me, v},
    };
    if(util.TraceLine(tr).Fraction == 1) then
        return true;
    elseif(wep && wep:IsValid() && wep.PenStr) then
        return fasAutowall(wep, tr.start, tr.endpos, v);
	elseif (wep && wep:IsValid() && wep.BulletPenetrate) then
		return m9kAutowall(wep, tr.start, tr.endpos, v)
    end
    return false;
end

local function gettarget()
local opt = gOption("Aimbot", "Aim Options", "Selection");
local sticky = gOption("Aimbot", "Aimbot", "Non-Sticky");

if(opt == "Distance") then
	if( !sticky && Valid(aimtarget) ) then return; end
	dists = {};
	for k,v in next, player.GetAll() do
			if(!Valid(v)) then continue; end
			dists[#dists + 1] = { vm.Distance( em.GetPos(v), em.GetPos(me) ), v };
	end
	table.sort(dists, function(a, b)
			return(a[1] < b[1]);
	end);
	aimtarget = dists[1] && dists[1][2] || nil;
elseif(opt == "Health") then
	if( !sticky && Valid(aimtarget) ) then return; end
	dists = {};
	for k,v in next, player.GetAll() do
			if(!Valid(v)) then continue; end
			dists[#dists + 1] = { em.Health(v), v };
	end
	table.sort(dists, function(a, b)
			return(a[1] < b[1]);
	end);
	aimtarget = dists[1] && dists[1][2] || nil;
elseif(opt == "Random") then
if( !sticky && Valid(aimtarget) ) then return; end
	aimtarget = nil;
	local allplys = player.GetAll();
	local avaib = {};
	for k,v in next,allplys do
			avaib[math.random(100)] = v;
	end
	for k,v in next, avaib do
			if(Valid(v)) then
					aimtarget = v;
			end
	end
end
aimignore = nil;
end

--nospread
local cones = {};
local pcall = pcall;
local require = require;
local nullvec = Vector() * -1;
local IsFirstTimePredicted = IsFirstTimePredicted;
local CurTime = CurTime;
local servertime = 0;
local bit = Copy(bit);
pcall(require, "dickwrap");

GAMEMODE:AddHook("Move", "", function()
	if(!IsFirstTimePredicted()) then return; end
	servertime = CurTime();
end);

GAMEMODE["EntityFireBullets"] = function(self, p, data)
	aimignore = aimtarget;
	local w = pm.GetActiveWeapon(me);
	local Spread = data.Spread * -1;
	if(!w || !em.IsValid(w) || cones[em.GetClass(w)] == Spread || Spread == nullvec) then return; end
	cones[em.GetClass(w)] = Spread;
end

local function PredictSpread(ucmd, ang)
	local w = pm.GetActiveWeapon(me);
	if(!w || !em.IsValid(w) || !cones[em.GetClass(w)] || !gBool("Aimbot", "Extra", "NoSpread")) then return am.Forward(ang); end
	return(dickwrap.Predict(ucmd, am.Forward(ang), cones[em.GetClass(w)]));
end

local function AutoFire(ucmd)
	if(pm.KeyDown(me, 1) && gBool("Aimbot", "Aimbot", "RapidFire")) then
		cm.SetButtons(ucmd, bit.band( cm.GetButtons(ucmd), bit.bnot( 1 ) ) );
	else
		cm.SetButtons(ucmd, bit.bor( cm.GetButtons(ucmd), 1 ) );
	end
end

--BulletTime
local function WeaponCanFire()
	local w = pm.GetActiveWeapon(me);
	if(!w || !em.IsValid(w) || !gBool("Aimbot", "Extra", "BulletTime")) then return true; end
	return(servertime >= wm.GetNextPrimaryFire(w));
end

--auto reload
function AutoReload(ucmd)
local wep = ply:GetActiveWeapon()
if(!gBool("Aimbot", "Aimbot", "AutoReload")) then return; end
	if (ply:Alive() and paste.IsValid(wep)) then
		if (wep:Clip1() <= 0 and wep:GetMaxClip1() > 0 and paste.CurTime() > wep:GetNextPrimaryFire()) then
			ucmd:SetButtons(ucmd:GetButtons() + IN_RELOAD)
		end
	end
end

local function WeaponShootable()
    local wep = pm.GetActiveWeapon(me);
    if( em.IsValid(wep) ) then
	     local n = string.lower(wep:GetPrintName())
	     if( wep:Clip1() <= -1 ) then
		    return;
		 end



		 if( string.find(n,"knife") or string.find(n,"grenade") or string.find(n,"sword") or string.find(n,"bomb") or string.find(n,"ied") or string.find(n,"c4") or string.find(n,"slam") or string.find(n,"climb") or string.find(n,"fist") or string.find(n,"crossbow") or string.find(n,"shotgun") or string.find(n,"gravitygun")) then
		    return false;
		 end


		  return true;
	end
end

local function PredictPos(pos)
local myvel = LocalPlayer():GetVelocity()
local pos = pos - (myvel * engine.TickInterval());
return pos;
end

--aimbot main function
local function Aimbot(ucmd)
	if(cm.CommandNumber(ucmd) == 0 || !gBool("Aimbot", "Aimbot", "Enabled")) then return; end
	gettarget();
	aa = false;
	if(aimtarget && (input.IsMouseDown(109) || (input.IsKeyDown(KEY_LALT) || !gBool("Aimbot", "Aimbot", "Aimkey: Mouse3 or ALT")) && WeaponCanFire() && IsValid(me:GetActiveWeapon()) && WeaponShootable() && me:GetActiveWeapon():GetClass() != "weapon_physgun" && me:GetActiveWeapon():GetClass() != "gmod_tool")) then
		aa = true;
		local pos = GetPos(aimtarget) - em.EyePos(me);
		local ang = vm.Angle(PredictSpread(ucmd, vm.Angle(pos)));
		PredictPos(pos);
		NormalizeAngle(ang);
		cm.SetViewAngles(ucmd, ang);
		local ang = vm.Angle( PredictSpread(ucmd, vm.Angle(pos)));
		NormalizeAngle(ang);
		cm.SetViewAngles(ucmd, ang);
		if(gBool("Aimbot", "Aimbot", "AutoFire")) then
			AutoFire(ucmd);
		end
		if(gBool("Aimbot", "Aimbot", "Silent")) then
			FixMovement(ucmd);
		if (gBool("Aimbot", "Aimbot", "AutoStop")) then
			ucmd:SetForwardMove(0)
			ucmd:SetSideMove(0)
			ucmd:SetUpMove(0)
		end
		else
			fa = ang;
		end
	end
end

local function GetClosest()
	local ddists = {};
	local closest;
	for k,v in next, player.GetAll() do
	if(!Valid(v)) then continue; end
	ddists[#ddists + 1] = { vm.Distance( em.GetPos(v), em.GetPos(me) ), v };
	end
	table.sort(ddists, function(a, b)
	return(a[1] < b[1]);
	end);
	closest = ddists[1] && ddists[1][2] || nil;
	if(!closest) then return fa.y; end
	local pos = em.GetPos(closest);
	local pos = vm.Angle(pos - em.EyePos(me));
	return( pos.y );
end

local ox=-181;
local oy=0;

local function RandCoin()
	local randcoin = math.random(0,1);
	if(randcoin == 1) then return 1; else return -1; end
end

local function GetX()
	local opt = gOption("Aimbot", "Anti-Aim", "X-Axis (Up, Down)");
	if(opt == "Emotion") then
		local randcoin = gInt("Aimbot", "Anti-Aim", "Max X");
		if( math.random(100) < randcoin ) then
			ox = RandCoin() * 181;
		end
	elseif( opt == "Up" ) then
		ox = 181;
	elseif( opt == "Down" ) then
		ox = -181;
	elseif(opt == "Jitter") then
		ox = ox * -1;
	elseif( opt == "Fake-Down" ) then
		ox = 181;
	elseif(opt == "Fake-Angles") then
		ox = math.random(1, 181, 1);
	end
end

local function GetClosest()
	local ddists = {};

	local closest;

	for k,v in next, player.GetAll() do
	if(!Valid(v)) then continue; end
		ddists[#ddists + 1] = { vm.Distance( em.GetPos(v), em.GetPos(me) ), v };
	end

	table.sort(ddists, function(a, b)
		return(a[1] < b[1]);
	end);

	closest = ddists[1] && ddists[1][2] || nil;

	if(!closest) then return fa.y; end

	local pos = em.GetPos(closest);

	local pos = vm.Angle(pos - em.EyePos(me));

	return( pos.y );
end

local function GetY()
	local opt = gOption("Aimbot", "Anti-Aim", "Y-Axis (Left, Right)");
	if(opt == "Emotion") then
		local randcoin = gInt("Aimbot", "Anti-Aim", "Min X");
		if( math.random(100) < randcoin ) then
			oy = fa.y + math.random(-180, 180);
		end
	elseif( opt == "Sideways" ) then
		oy = fa.y - 90;
	elseif( opt == "Opposite-Sideways" ) then
		oy = fa.y + 90;
	elseif(opt == "Jitter") then
		oy = fa.y + math.random(-90, 90);
	elseif(opt == "FakeBackwards-Jitter") then
		oy = fa.y - 180 + math.random(-90, 90);
	elseif(opt == "FakeBackwards") then
		oy = fa.y + math.random(1, -80, 1);
	elseif(opt == "SideSwitch") then
        oy = math.random(90, -90) +20 / 2;
	elseif(opt == "Static") then
		oy = 0;
	elseif(opt == "StaticBackwards") then
        oy = 180;
	elseif(opt == "Towards Players") then
		oy = GetClosest();
	elseif(opt == "Slow Spin") then
        oy = (paste.CurTime() * 200) % 360, 0;
	elseif(opt == "Fast Spin") then
		oy = (paste.CurTime() * 500) % 360, 0;
	elseif(opt == "Jitter Spin") then
		oy = (paste.CurTime() * 99999) % 360, 0;
	elseif(opt == "SideJitter") then
        oy = fa.y + math.random(-200, -55);
	elseif(opt == "Opposite-SideJitter") then
        oy = fa.y + math.random(200, 55);
	elseif(opt == "Fake-Sideways") then
		oy = fa.y + math.random(1, -40, 1);
	elseif(opt == "Fake-Angles #1") then
		oy = fa.y + math.random(1, 180, 1, 80, 1);
	elseif(opt == "Fake-Angles #2") then
		oy = fa.y + math.random(181, 361);
	end
end

local function walldetect()
	local eye = em.EyePos(me);
	local tr = util.TraceLine({
		start = eye,
		endpos = (eye + (am.Forward(fa) * 10)),
		mask = MASK_ALL,
	});
	if(tr.Hit) then
		ox = -181;
		oy = -90;
	end
end

local function antiaimer(ucmd)
	if( (cm.CommandNumber(ucmd) == 0 && !gBool("Visuals", "Extra", "Thirdperson")) || cm.KeyDown(ucmd, 1) || cm.KeyDown(ucmd, 2) || cm.KeyDown(ucmd, 32) || em.GetMoveType(me) == MOVETYPE_LADDER ||em.GetMoveType(me) == MOVETYPE_NOCLIP || aa || me:Health() < 1 || !gBool("Aimbot", "Anti-Aim", "Enabled")) then return; end
	GetX();
	GetY();
	walldetect();
	local aaang = Angle(ox, oy, 0);
	cm.SetViewAngles(ucmd, aaang);
	FixMovement(ucmd, true);
end

--no recoil
local function GetAngle(ang)
	if(!gBool("Aimbot", "Extra", "NoRecoil")) then return ang + pm.GetPunchAngle(me); end
	return ang;
end

local function PASTEWARE(ucmd)
	if(!fa) then fa = cm.GetViewAngles(ucmd); end
        fa = fa + Angle(cm.GetMouseY(ucmd) * .023, cm.GetMouseX(ucmd) * -.023, 0);
        NormalizeAngle(fa);
	if(cm.CommandNumber(ucmd) == 0) then
		cm.SetViewAngles(ucmd, GetAngle(fa));
		return;
        end
	if(cm.KeyDown(ucmd, 1)) then
			local ang = GetAngle(vm.Angle(PredictSpread(ucmd, fa ) ) );
			NormalizeAngle(ang);
			cm.SetViewAngles(ucmd, ang);
        end
end

function paste.DuckJump(ucmd)
	if(!gBool("Misc", "Misc", "Crouch Jump")) then return end
	local pos = ply:GetPos()
	local trace = {
		start = pos,
		endpos = pos - paste.Vector(0, 0, 50),
		mask = MASK_PLAYERSOLID,
	}
	local trace = util.TraceLine(trace)
	local height = (pos - trace.HitPos).z
	if (height > 25 and 50 > height) then
		ucmd:SetButtons(ucmd:GetButtons() + IN_DUCK)
	end
end

GAMEMODE:AddHook("CreateMove", "", function(ucmd)
	memesendpacket = true;
	Bunnyhop(ucmd);
	if(ucmd:CommandNumber() != 0) then
	localindex = me:EntIndex();
	currentcommand = ucmd:CommandNumber();
	EnginePred();
	end
	local oldAngles = ucmd:GetViewAngles();
	PASTEWARE(ucmd);
	AutoReload(ucmd);
	Aimbot(ucmd);
	antiaimer(ucmd);
	RapidFire(ucmd);
	AntiAFK();
	paste.DuckJump(ucmd);
	if(oldAngles != ucmd:GetViewAngles()) then
	local x = ucmd:GetViewAngles().x;
	end
end);

--thirdperson
GAMEMODE:AddHook("ShouldDrawLocalPlayer", "", function()
return(gBool("Visuals", "Extra", "Thirdperson"));
end);

GAMEMODE:AddHook("CalcView", "", function(p, o, a, f)
local view = {
	angles = GetAngle(fa),
	origin = (gBool("Visuals", "Extra", "Thirdperson") && o + am.Forward(fa) * (gInt("Visuals", "Extra", "Thirdperson Distance") * -10) || o),
};
return view;
end);

gameevent.Listen("player_disconnect");

GAMEMODE:AddHook("player_disconnect", "", function()
if(gBool("Misc", "Chat", "Spam") && gOption("Misc", "Chat", "Spam Type") == "Killstreaks") then
	RunConsoleCommand("say", "// [PASTEWARE] ".."Rage quit");
end

if(gBool("Misc", "Chat", "Spam") && gOption("Visuals", "Misc", "Spam Type") == "Taunts") then
	RunConsoleCommand("say", "rq lmao");
	end
end);

gameevent.Listen("player_spawn");

GAMEMODE:AddHook("player_spawn", "", function()
if(gBool("Misc", "Chat", "Spam") && gOption("Misc", "Chat", "Spam Type") == "Taunts") then
	RunConsoleCommand("say", "Prepare for rape homo");
end
if(gBool("Misc", "Chat", "Spam") && gOption("Misc", "Chat", "Spam Type") == "Killstreaks") then
	RunConsoleCommand("say", "Ready to get 1tapped kid?");
end
if(gBool("Misc", "Chat", "Spam") && gOption("Misc", "Chat", "Spam Type") == "Spawn") then
	RunConsoleCommand("say", "PASTEWARE fucked ur dad");
end
end);

paste.AddHook("OnPlayerChat", function(v, text, team)
	if (!gBool("Misc", "Chat", "Copy Messages")) then return end
	if (v ~= ply) then
		if (team) then
			ply:ConCommand("say_team '" .. text .. "' - " .. v:Nick())
		else
			ply:ConCommand("say '" .. text .. "' - " .. v:Nick())
		end
	end
end)

--killstreaks
local playerphrases = {
"Owned",
"Bodied",
"Smashed",
"Fucked",
"Destroyed",
"Annihilated",
"Decimated",
"Wrecked",
"Demolished",
"Trashed",
"Ruined",
"Murdered",
"Exterminated",
"Slaughtered",
"Butchered",
"Genocided",
"Executed",
"Bamboozled",
}

--excuses
local excuses = {
"lag",
"bad ping",
"aimbot was off",
"was alt tabbed",
"mouse was unplugged",
"keyboard was unplugged",
"monitor was unplugged",
"router was unplugged",
"dog was on keyboard",
"antiaim wasn't even on",
}

--taunts
local taunts = {
"haha you fucking suck lmao",
"get owned kid",
"raped aha",
"get shit on",
"get fuckin' bamboozled"
}

paste.cough = {
	"ambient/voices/cough1.wav",
	"ambient/voices/cough2.wav",
	"ambient/voices/cough3.wav",
	"ambient/voices/cough4.wav",
}

local playerkills = 0;
local function entity_killed(info)
if(gBool("Misc", "Chat", "Spam") && gOption("Misc", "Chat", "Spam Type") == "Taunts") then
	local Entity = Entity;
	local killer = Entity(info.entindex_attacker);
	local killed = Entity(info.entindex_killed);
	if(killed == me) then
	RunConsoleCommand("say",  excuses[math.random(#excuses)]);
	end
	if(!em.IsValid(killer) || !em.IsValid(killed) || killer != me || killer == killed || !killed:IsPlayer()) then
		return;
	end
	RunConsoleCommand("say", taunts[math.random(#taunts)]);
end

if(gBool("Misc", "Chat", "Spam") && gOption("Misc", "Chat", "Spam Type") == "Killstreaks") then
	local Entity = Entity;
	local killer = Entity(info.entindex_attacker);
	local killed = Entity(info.entindex_killed);
	if(killed == me && playerkills > 0 && killer != me) then
	RunConsoleCommand("say",  "// [PASTEWARE] "..killed:Nick().."'s ".."killstreak of "..playerkills.." has been ended by "..killer:Nick()..".");
	playerkills = 0
	end
	if(!em.IsValid(killer) || !em.IsValid(killed) || killer != me || killer == killed || !killed:IsPlayer()) then
		return;
	end
	playerkills = playerkills + 1
	RunConsoleCommand("say",  "// [PASTEWARE] - "..playerphrases[math.random(#playerphrases)].." "..killed:Nick().." [".."Killstreak: "..playerkills.."]");
	end
end

local function OriginCam()
	if(!gBool("Visuals", "Extra", "Mirror")) then return; end
	local CamData = {}
	CamData.angles = Angle(180,LocalPlayer():EyeAngles().yaw,180)
	CamData.origin = LocalPlayer():GetPos()+Vector(10,0,65)
	CamData.x = 650
	CamData.y = 0
	CamData.w = ScrW() / 3
	CamData.h = ScrH() / 5
	render.RenderView( CamData )
end
hook.Add("HUDPaint", "OriginCam", OriginCam)

GAMEMODE:AddHook("entity_killed", "", entity_killed);

gameevent.Listen("entity_killed");

surface.PlaySound ("HL1/fvox/bell.wav")
surface.PlaySound ("vo/trainyard/ba_goodluck01.wav")
chat.AddText("")
chat.AddText("")
chat.AddText("")
chat.AddText("")
chat.AddText("")
chat.AddText("")
chat.AddText("")
chat.AddText("")
chat.AddText("")
chat.AddText("")
chat.AddText("")
chat.AddText("")
chat.AddText("")
chat.AddText("")
chat.AddText("")
chat.AddText("")
chat.AddText("")
chat.AddText("")
chat.AddText("")
chat.AddText("")
chat.AddText("")
chat.AddText("")
chat.AddText("")
chat.AddText("")
chat.AddText("")
chat.AddText("")
chat.AddText("")
chat.AddText("")
chat.AddText("")
chat.AddText("")
chat.AddText("")
chat.AddText("")
chat.AddText("")
chat.AddText("")
chat.AddText("")
chat.AddText("")
chat.AddText("")
chat.AddText("")
chat.AddText("")
chat.AddText("")
chat.AddText("")
chat.AddText("")
chat.AddText("")
chat.AddText("")
chat.AddText("")
chat.AddText("")
chat.AddText("")
chat.AddText("")
chat.AddText("")
chat.AddText("")
chat.AddText("")
chat.AddText("")
chat.AddText("")
chat.AddText("")
chat.AddText("")
chat.AddText("")
chat.AddText("")
chat.AddText("")
chat.AddText("")
chat.AddText("")
chat.AddText("")
chat.AddText("")
chat.AddText("")
chat.AddText("")
chat.AddText("")
chat.AddText("")
chat.AddText("")
chat.AddText("")
chat.AddText("")
chat.AddText("")
chat.AddText("")
chat.AddText("")
chat.AddText("")
chat.AddText("")
chat.AddText("")
chat.AddText("")
chat.AddText("")
chat.AddText("")
chat.AddText("")
chat.AddText("")
chat.AddText("")
chat.AddText("")
chat.AddText("")
chat.AddText("")
chat.AddText("")
chat.AddText("")
chat.AddText("")
chat.AddText("")
chat.AddText("")
chat.AddText("")
chat.AddText("")
chat.AddText("")
chat.AddText("")
chat.AddText("")
chat.AddText("")
chat.AddText("")
chat.AddText("")
chat.AddText("")
chat.AddText("")
chat.AddText("")
chat.AddText("")
chat.AddText("")
chat.AddText("")
chat.AddText("")
chat.AddText("")
chat.AddText("")
chat.AddText("")
chat.AddText("")
chat.AddText("")
chat.AddText("")
chat.AddText("")
chat.AddText("")
chat.AddText("")
chat.AddText("")
chat.AddText("")
chat.AddText("")
chat.AddText("")
chat.AddText("")
chat.AddText("")
chat.AddText("")
chat.AddText("")
chat.AddText("")
chat.AddText("")
chat.AddText("")
chat.AddText("")
chat.AddText("")
chat.AddText("")
chat.AddText(Color(math.random(255), math.random(255), math.random(255)), "[", "PASTEWARE", "] ", Color( 255, 255, 255 ), "Loaded sucessfully!")
chat.AddText(Color(math.random(255), math.random(255), math.random(255)), "[", "PASTEWARE", "] ", Color( 255, 255, 255 ), "Interested in the Sourcecode? Type 'source' into the console to print it!")

concommand.Add( "source", function ()
	RunConsoleCommand("say", "I will crash shortly cuz I tried to get Pasteware's sourcecode. Nice move, Crave 4!");
	paste.OpenSite()
end)

