--[[
	integra/integra.lua
	ReaxkuTheFox | (STEAM_0:0:28107216)
	===DStream===
]]

if SERVER then return end

/*
	Integra v2.1
	- Better Anti-Cheat avoidance. (Better, not 100% chance of avoidance)
	- Better quality.
*/

function Color(r, g, b, a)
	return {r = r or 0, g = g or 0, b = b or 0, a = a or 0}
end

local draw = require("draw")
local hook = require("hook")
local concommand = require("concommand")

local m_CreateClientConVar = CreateClientConVar
local m_SetMaterialOverride = SetMaterialOverride

local _T = {}
	_T.CMDPrefix = "int"
	_T.ConVars = {}
	_T.Hooks = {}
	_T.ValidEntities = {}
	_T.ValidPlayers = {}
	_T.IsActive = m_CreateClientConVar(_T.CMDPrefix .. "_" .. "enabled", 1, true, false)

local m_hook = {}
	m_hook.Add = hook.Add
	m_hook.Remove = hook.Remove

local m_surface = {}
	m_surface.CreateFont = surface.CreateFont
	m_surface.DrawLine = surface.DrawLine
	m_surface.DrawRect = surface.DrawRect
	m_surface.GetTextSize = surface.GetTextSize
	m_surface.SetFont = surface.SetFont
	m_surface.SetDrawColor = surface.SetDrawColor

local m_draw = {}
local draw = draw

function m_draw.SimpleText(text, font, x, y, col, xalign, yalign)
	if (x > -20 and x < ScrW() + 20) and (y > -20 and y < ScrH() + 20) then
		draw.SimpleText(text, font, x, y, col, xalign, yalign)
	end
end

function m_draw.SimpleTextOutlined(text, font, x, y, col, xalign, yalign, olsize, olcolor)
	if (x > -20 and x < ScrW() + 20) and (y > -20 and y < ScrH() + 20) then
		draw.SimpleTextOutlined(text, font, x, y, col, xalign, yalign, olsize, olcolor)
	end
end

local m_cam = {}
	m_cam.IgnoreZ = cam.IgnoreZ
	m_cam.End2D = cam.End2D
	m_cam.End3D = cam.End3D
	m_cam.End3D2D = cam.End3D2D
	m_cam.Start2D = cam.Start2D
	m_cam.Start3D = cam.Start3D
	m_cam.Start3D2D = cam.Start3D2D

local m_RunConsoleCommand = RunConsoleCommand

local m_concommand = {}
	m_concommand.Add = concommand.Add

local m_render = {}
	m_render.DrawBeam = render.DrawBeam
	m_render.SetBlend = render.SetBlend
	m_render.SetColorModulation = render.SetColorModulation
	m_render.SetMaterial = render.SetMaterial
	m_render.SuppressEngineLighting = render.SuppressEngineLighting

function _T:AddCommand(cmd, func)
	m_concommand.Add(self.CMDPrefix .. "_" .. cmd, function(p, c, a) func(a) end)
end

function _T:MakeRand()
	local round = math.random(1, 99999999)
	return round
end

function _T:Hook(type, func, convar, default)
	local rand = self:MakeRand()

	if convar != nil then
		_T:CreateConVar(convar, default)
	end

	m_hook.Add(type, tostring(rand), function(...)
		if self.IsActive:GetBool() then
			if convar != nil then
				if _T:GetConVar(convar):GetBool() then
					local value = func(...)
					if value != nil then
						return value
					end
				end
			else
				local value = func(...)
					if value != nil then
						return value
					end
			end
		end
	end)
	table.insert(self.Hooks, {type = type, id = rand})
end

function _T:AddBindCommand(cmd, func, htype, on_callback, off_callback)
	local on = false
	_T:Hook(htype, function()
		if on then
			func()
		end
	end)
	m_concommand.Add("+" .. _T.CMDPrefix .. "_" .. cmd, function(p, c, a)
		on = true
		if on_callback != nil then
			on_callback(a)
		end
	end)
	m_concommand.Add("-" .. _T.CMDPrefix .. "_" .. cmd, function(p, c, a)
		on = false
		if off_callback != nil then
			off_callback(a)
		end
	end)
end

_T:Hook("Think", function()
	_T.ValidEntities = {}
	_T.ValidPlayers = {}

	for k, v in pairs(ents.GetAll()) do
		if ValidEntity(v) then
			_T.ValidEntities[k] = v
		end
	end

	for k, v in pairs(player.GetAll()) do
		if ValidEntity(v) then
			_T.ValidPlayers[k] = v
		end
	end
end)

_T:AddCommand("clearhooks", function()
	for k, v in pairs(_T.Hooks) do
		m_hook.Remove(v.type, v.id)
	end
end)

function _T:CreateConVar(cmd, default)
	table.insert(_T.ConVars, {cmd = cmd, value = m_CreateClientConVar(_T.CMDPrefix .. "_" .. cmd, default, true, false)})
end
_T:CreateConVar("enabled", 1)

function _T:GetConVar(cmd)
	for k, v in pairs(_T.ConVars) do
		if v.cmd == cmd then
			return v.value
		end
	end
end

function _T:GetHeadPos(ply)
	if ValidEntity(ply) then
		local hp = ply:GetBonePosition(ply:LookupBone("ValveBiped.Bip01_Head1"))
		if hp != nil then
			return hp
		else
			hp = ply:EyePos()
			if hp != nil then
				return hp
			else
				return ply:GetPos() + Vector(0, 64, 0)
			end
		end
	end
	return Vector(0, 0, 0)
end

function _T:IsVisible(ent)
	if ValidEntity(ent) then
		local tr = {}
			tr.start = EyePos()
			tr.endpos = ent:GetPos()
			if ent:IsPlayer() or ent:IsNPC() then
				tr.endpos = _T:GetHeadPos(ent)
			end
			tr.mask = MASK_SHOT
			tr.filter = LocalPlayer()
		local trace = util.TraceLine(tr)

		if trace.Entity == ent then
			return true
		else
			return false
		end
	else
		return false
	end
end

// X-Ray Vision

local XRAY_SOLID_MAT = Material("models/debug/debugwhite")
local XRAY_WIREFRAME_MAT = Material("models/wireframe")

local XRayValidEnts = {}
	XRayValidEnts["prop_door_rotating"] = {col = {r = 1, g = 1, b = 1}, blend = 0.5}
	XRayValidEnts["prop_dynamic"] = {col = {r = 0.5, g = 0.5, b = 1}, mat = XRAY_SOLID_MAT, blend = 0.5}
	XRayValidEnts["prop_static"] = {col = {r = 0.5, g = 0.5, b = 1}, mat = XRAY_SOLID_MAT, blend = 0.5}
	XRayValidEnts["prop_physics"] = {col = {r = 0.5, g = 1, b = 0}, mat = XRAY_SOLID_MAT, blend = 0.5}

local XRayEnts = {}

local function AddXRayEnt(ent)
	if ValidEntity(ent) then
		for k, v in pairs(XRayValidEnts) do
			if string.match(string.lower(k), string.lower(ent:GetClass())) then
				if #XRayEnts + 1 > _T:GetConVar("xray_maxents"):GetInt() then
					XRayEnts[1] = {ent = ent, col = v.col, mat = v.mat}
				else
					table.insert(XRayEnts, {ent = ent, col = v.col, mat = v.mat})
				end
				break
			end
		end
	end
end
_T:CreateConVar("xray_maxents", 128)
_T:CreateConVar("xray_transparency", 50)

local function FindXRayEntities()
	XRayEnts = {}
	for k, v in pairs(_T.ValidEntities) do
		if ValidEntity(v) then
			local isAlreadyIn = false
			for _k, _v in pairs(XRayEnts) do
				if _v.ent == v then
					isAlreadyIn = true
				end
			end

			if not isAlreadyIn then
				AddXRayEnt(v)
			end
		end
	end
end

_T:Hook("OnEntityCreated", AddXRayEnt)

local function RenderXRay()
	m_cam.Start3D(EyePos(), EyeAngles())
	m_cam.IgnoreZ(true)
	m_render.SuppressEngineLighting(true)

	for k, v in pairs(XRayEnts) do
		if ValidEntity(v.ent) then
			m_SetMaterialOverride(v.mat)
			m_render.SetColorModulation(v.col.r, v.col.g, v.col.b)
			m_render.SetBlend(_T:GetConVar("xray_transparency"):GetInt() / 100)
			v.ent:DrawModel()
		end
	end
	
	for k, v in pairs(_T.ValidPlayers) do
		if ValidEntity(v) and v != LocalPlayer() then
			if v:Alive() then
				m_cam.IgnoreZ(true)
					m_SetMaterialOverride(XRAY_WIREFRAME_MAT)
					m_render.SetColorModulation(0, 0.5, 1)
					m_render.SetBlend(_T:GetConVar("xray_transparency"):GetInt() / 100)
					v:DrawModel()
				m_cam.IgnoreZ(false)
			end
		end
	end

	for k, v in pairs(_T.ValidEntities) do
		if ValidEntity(v) then
			if v:IsNPC() then
				m_SetMaterialOverride(XRAY_SOLID_MAT)
				m_render.SetColorModulation(1, 0.5, 0.5)
				m_render.SetBlend(_T:GetConVar("xray_transparency"):GetInt() / 100)
				v:DrawModel()
			end
		end
	end

	m_SetMaterialOverride()
	m_render.SetColorModulation(1, 1, 1)
	m_render.SetBlend(1)
	m_render.SuppressEngineLighting(false)
	m_cam.IgnoreZ(false)
	m_cam.End3D()
end
_T:Hook("RenderScreenspaceEffects", RenderXRay, "xray_enabled", 1)

local XRayToggleMode = 0
local XRayMaxEnts = 0

local function CheckXRayEntities()
	if XRayToggleMode != tonumber(_T:GetConVar("xray_enabled"):GetBool()) then
		XRayToggleMode = tonumber(not tobool(XRayToggleMode))
		if XRayToggleMode == 1 then
			FindXRayEntities()
		end
	end

	if XRayMaxEnts != _T:GetConVar("xray_maxents"):GetInt() then
		FindXRayEntities()
		XRayMaxEnts = _T:GetConVar("xray_maxents"):GetInt()
	end

	for k, v in pairs(XRayEnts) do
		if not ValidEntity(v.ent) then
			table.remove(XRayEnts, k)
		else
			if #XRayEnts > _T:GetConVar("xray_maxents"):GetInt() then
				table.remove(XRayEnts, k)
			end
		end
	end
end
_T:Hook("Think", CheckXRayEntities)

local LaserMaterial = Material("tripmine_laser")

local function DrawLaser()
	m_cam.Start3D(EyePos(), EyeAngles())
		for k, v in pairs(_T.ValidPlayers) do
			if ValidEntity(v) and v != LocalPlayer() then
				local pos = v:EyePos()
				local endpos = v:GetEyeTrace().HitPos

				m_render.SetMaterial(LaserMaterial)

				if _T:GetConVar("laser_eyetracer"):GetBool() then
					m_render.DrawBeam(pos, endpos, 10, 1, 1, Color(255, 0, 0, 255))
				end

				if _T:GetConVar("laser_skytracer"):GetBool() then
					local tr = {}
						tr.start = v:EyePos()
						tr.endpos = v:EyePos() + Vector(0, 0, 8192)
						tr.filter = v
					local trace = util.TraceLine(tr)

					m_cam.IgnoreZ(true)
						m_render.DrawBeam(pos, trace.HitPos, 15, 1, 1, Color(0, 255, 0, 255))
					m_cam.IgnoreZ(false)
				end
			end
		end
	m_cam.End3D()
end
_T:Hook("RenderScreenspaceEffects", DrawLaser, "laser_enabled", 1)
_T:CreateConVar("laser_eyetracer", 1)
_T:CreateConVar("laser_skytracer", 1)

_T:AddCommand("rotate", function()
	local ang = EyeAngles()
		ang.r = 0

	LocalPlayer():SetEyeAngles(Angle(ang.p, ang.y - 180, 0))
end)

local Air = false
local function DoBhop()
	if LocalPlayer():IsOnGround() and LocalPlayer():WaterLevel() < 2 then
		if Air then
			m_RunConsoleCommand("-jump")
			Air = false
		else
			m_RunConsoleCommand("+jump")
			Air = true
		end
	end
end

_T:AddBindCommand("bhop", DoBhop, "Tick", function() if LocalPlayer():WaterLevel() != 0 then m_RunConsoleCommand("+jump") end end, function() Air = false m_RunConsoleCommand("-jump") end)

local CCommand = ""
local CSpamToggleMode = false

local function StartCSpam(command)
	CCommand = command[1]
end

local function DoCSpam()
	if string.match(CCommand, "+") then
		if CSpamToggleMode then
			m_RunConsoleCommand(string.Replace(CCommand, "+", "-"))
			CSpamToggleMode = false
		else
			m_RunConsoleCommand(CCommand)
			CSpamToggleMode = true
		end
	else
		m_RunConsoleCommand(CCommand)
	end
end

local function EndCSpam()
	if string.match(CCommand, "+") then
		m_RunConsoleCommand(string.Replace(CCommand, "+", "-"))
	end
end

_T:AddBindCommand("commandspam", DoCSpam, "Tick", StartCSpam, EndCSpam)

local function DrawESP()
	local drawFunc = m_draw.SimpleText
	if _T:GetConVar("esp_outlinedtext"):GetBool() then
		drawFunc = m_draw.SimpleTextOutlined
	end

	m_cam.Start3D(EyePos(), EyeAngles())
	m_cam.Start2D()
		for k, v in pairs(_T.ValidPlayers) do
			if ValidEntity(v) and v != LocalPlayer() then
				local yAlign = 0
				local headpos = _T:GetHeadPos(v)
					headpos = headpos:ToScreen()

				local drawData = {}
				local health = math.Round(v:Health()) .. "%"
				if v:Health() <= 0 then health = "DEAD" end

				local dist = math.Round(v:EyePos():Distance(EyePos()))

				local weapon = "nil"

				if IsValid(v:GetActiveWeapon()) then
					weapon = v:GetActiveWeapon().PrintName or v:GetActiveWeapon():GetClass()
				end

				table.insert(drawData, {key = "Health", value = health})
				table.insert(drawData, {key = "Distance", value = dist})
				table.insert(drawData, {key = "Weapon", value = weapon})

				yAlign = yAlign - 15 - (#drawData * 11)

				if _T:GetConVar("esp_onlyname"):GetBool() then
					yAlign = -15
				end

				local rank = ""
				if v:IsAdmin() and not v:IsSuperAdmin() then
					rank = "Admin"
				elseif v:IsSuperAdmin() then
					rank = "Super Admin"
				end

				local namefont = "EspPlayerText"
				if v:SteamID() == "STEAM_0:1:33687954" then
					// I'm UNIQUE!
					namefont = "EspPlayerTextAnthrax"
				end
				m_surface.SetFont(namefont)
				local nametext_size = m_surface.GetTextSize(v:Nick())
				m_surface.SetFont("EspAdminText")
				local admintext_size = m_surface.GetTextSize(" (" .. rank .. ")")

				if rank == "" then admintext_size = 0 end

				local namecol = Color(255, 102, 102, 255)

				if v:GetFriendStatus() == "friend" then
					namecol = Color(102, 255, 0, 255)
				elseif v:SteamID() == "STEAM_0:1:33687954" then
					// I'm UNIQUE!
					local sine = math.sin(CurTime() * 5)
					if v:GetFriendStatus() == "friend" then
						namecol = Color(102 - (sine * 30), 255 - (sine * 80), 0, 255)
					else
						namecol = Color(204 - (sine * 80), 102 - (sine * 40), 102 - (sine * 40), 255)
					end
					drawFunc("Integra: ", "EspAdminText", headpos.x - ((nametext_size + admintext_size) / 2), headpos.y + yAlign, Color(153, 153, 255, 255), TEXT_ALIGN_RIGHT, TEXT_ALIGN_TOP, 1, Color(0, 0, 0, 255))
				end
				drawFunc(v:Nick(), namefont, headpos.x - ((nametext_size + admintext_size) / 2), headpos.y + yAlign, namecol, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP, 1, Color(0, 0, 0, 255))
				if rank != "" then
					drawFunc(" (" .. rank .. ")", "EspAdminText", headpos.x - ((nametext_size + admintext_size) / 2) + nametext_size, headpos.y + yAlign, Color(153, 153, 255, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP, 1, Color(0, 0, 0, 255))
				end

				if not _T:GetConVar("esp_onlyname"):GetBool() then
					for k, v in ipairs(drawData) do
						m_surface.SetFont("EspInfoText")
						local keysize = m_surface.GetTextSize(v.key .. ":")
						local valuesize = m_surface.GetTextSize(" " .. v.value)

						drawFunc(v.key .. ":", "EspInfoText", headpos.x - ((keysize + valuesize) / 2), headpos.y + yAlign + 4 + (k * 11), Color(255, 204, 204, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP, 1, Color(0, 0, 0, 255))
						drawFunc(" " .. v.value, "EspInfoText", headpos.x - ((keysize + valuesize) / 2) + keysize, headpos.y + yAlign + 4 + (k * 11), Color(204, 204, 255, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP, 1, Color(0, 0, 0, 255))
					end
				end
			end
		end
	m_cam.End2D()
	m_cam.End3D()
end
_T:Hook("HUDPaint", DrawESP, "esp_enabled", 1)
_T:CreateConVar("esp_outlinedtext", 1)
_T:CreateConVar("esp_onlyname", 0)

m_surface.CreateFont("Segoe UI", 15, 700, false, false, "EspPlayerText")
m_surface.CreateFont("Impact", 17, 400, false, false, "EspPlayerTextAnthrax")
m_surface.CreateFont("Arial", 13, 700, false, false, "EspAdminText")
m_surface.CreateFont("Arial", 13, 700, false, false, "EspInfoText")

local function DrawCH()
	local hitpos = LocalPlayer():GetEyeTrace().HitPos
	local dist = EyePos():Distance(hitpos) / 900

	local pos = hitpos:ToScreen()

	m_surface.SetDrawColor(Color(255, 0, 0, 153))
	m_surface.DrawLine(pos.x - 16 - dist, pos.y, pos.x - 8 - dist, pos.y)
	m_surface.DrawLine(pos.x + 8 + dist, pos.y, pos.x + 16 + dist, pos.y)
	m_surface.DrawLine(pos.x, pos.y - 16 - dist, pos.x, pos.y - 8 - dist)
	m_surface.DrawLine(pos.x, pos.y + 8 + dist, pos.x, pos.y + 16 + dist)
end

_T:Hook("HUDPaint", DrawCH, "crosshair_enabled", 1)

local ABTarget
local ABAiming = false

local function GetABTarget()
	ABTarget = nil
	local PossibleTargets = {}

	if _T:GetConVar("aimbot_targetplayers"):GetBool() then
		for k, v in pairs(_T.ValidPlayers) do
			if ValidEntity(v) and v != LocalPlayer() then
				if _T:GetHeadPos(v):Distance(EyePos()) < _T:GetConVar("aimbot_maxdist"):GetFloat() then
					if _T:IsVisible(v) then
						local valid = true
						if not v:Alive() then
							valid = false
						end
						if not _T:GetConVar("aimbot_targetsteamfriends"):GetBool() then
							if v:GetFriendStatus() == "friend" then
								valid = false
							end
						end
						if not _T:GetConVar("aimbot_targetteammates"):GetBool() then
							if v:Team() == LocalPlayer():Team() then
								valid = false
							end
						end
						if valid then
							table.insert(PossibleTargets, v)
						end
					end
				end
			end
		end
	end

	if _T:GetConVar("aimbot_targetnpcs"):GetBool() then
		for k, v in pairs(_T.ValidEntities) do
			if ValidEntity(v) and v != LocalPlayer() then
				if v:IsNPC() then
					if _T:GetHeadPos(v):Distance(EyePos()) < _T:GetConVar("aimbot_maxdist"):GetFloat() then
						if _T:IsVisible(v) then
							table.insert(PossibleTargets, v)
						end
					end
				end
			end
		end
	end

	if _T:GetConVar("aimbot_targetprops"):GetBool() then
		for k, v in pairs(_T.ValidEntities) do
			if ValidEntity(v) and v != LocalPlayer() then
				if v:GetClass() == "prop_physics" then
					if v:GetPos():Distance(EyePos()) < _T:GetConVar("aimbot_maxdist"):GetFloat() then
						if _T:IsVisible(v) then
							table.insert(PossibleTargets, v)
						end
					end
				end
			end
		end
	end

	local BestTarget
	local NearTargets = {}

	for k, v in pairs(PossibleTargets) do
		if ValidEntity(v) then
			local ang = (v:GetPos() - EyePos()):Angle()
				if v:IsPlayer() or v:IsNPC() then
					ang = (_T:GetHeadPos(v) - EyePos()):Angle()
				end
				ang.p = 0
			local eyeang = EyeAngles()
				eyeang.p = 0
			local dist = eyeang:Forward():Distance(ang:Forward()) * 90
			if dist <= _T:GetConVar("aimbot_maxangle"):GetFloat() then
				table.insert(NearTargets, {ent = v, ang = dist})
			end
		end
	end

	table.SortByMember(NearTargets, "ang", function(a, b) return a > b end)
	if NearTargets[1] != nil then
		BestTarget = NearTargets[1].ent
	end

	if ValidEntity(BestTarget) then
		ABTarget = BestTarget
	end
end

local AutoFireToggleMode = false

local function ABThink()
	if ValidEntity(ABTarget) then
		if _T:IsVisible(ABTarget) then
			local pos = ABTarget:GetPos()
			if ABTarget:IsPlayer() or ABTarget:IsNPC() then
				pos = _T:GetHeadPos(ABTarget)
			end

			if _T:GetConVar("aimbot_velocitypredict"):GetBool() then
				pos = pos + (ABTarget:GetVelocity() / 1100) - (LocalPlayer():GetVelocity() / 1100)
			end

			local ang = (pos - EyePos()):Angle()
			LocalPlayer():SetEyeAngles(ang)

			if _T:GetConVar("aimbot_autofire"):GetBool() then
				if AutoFireToggleMode then
					m_RunConsoleCommand("-attack")
					AutoFireToggleMode = false
				else
					m_RunConsoleCommand("+attack")
					AutoFireToggleMode = true
				end
			end
		else
			if _T:GetConVar("aimbot_autofire"):GetBool() then
				m_RunConsoleCommand("-attack")
				AutoFireToggleMode = false
			end
			GetABTarget()
		end
	else
		if _T:GetConVar("aimbot_autofire"):GetBool() then
			m_RunConsoleCommand("-attack")
			AutoFireToggleMode = false
		end
		GetABTarget()
	end
end

_T:AddBindCommand("aimbot", ABThink, "Think", function() ABAiming = true AutoFireToggleMode = false end, function()
	ABAiming = false
	ABTarget = nil
	AutoFireToggleMode = false
	if _T:GetConVar("aimbot_autofire"):GetBool() then
		m_RunConsoleCommand("-attack")
	end
end)

local function DrawAimbot()
	local pos_x = ScrW() / 2
	local pos_y = (ScrH() / 2) + 20

	local sine = 3 + (math.sin(CurTime() * 5) * 2)

	if ABAiming then
		if ValidEntity(ABTarget) then
			if ABTarget:IsPlayer() then
				m_draw.SimpleTextOutlined("Target locked: " .. ABTarget:Nick(), "AimbotText", pos_x, pos_y, Color(102 + (102 / sine), 102 + (102 / sine), 204 + (204 / sine), 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP, 1, Color(0, 0, 0, 255))
			else
				m_draw.SimpleTextOutlined("Target locked: " .. ABTarget:GetClass() .. " (" .. ABTarget:GetModel() .. ")", "AimbotText", pos_x, pos_y, Color(102 + (102 / sine), 102 + (102 / sine), 204 + (204 / sine), 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP, 1, Color(0, 0, 0, 255))
			end
		else
			m_draw.SimpleTextOutlined("Scanning for targets...", "AimbotText", pos_x, pos_y, Color(204 + (204 / sine), 102 + (102 / sine), 102 + (102 / sine), 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP, 1, Color(0, 0, 0, 255))
		end
	end
end
_T:Hook("HUDPaint", DrawAimbot)

_T:CreateConVar("aimbot_autofire", 1)
_T:CreateConVar("aimbot_maxangle", 360)
_T:CreateConVar("aimbot_maxdist", 8192)
_T:CreateConVar("aimbot_targetnpcs", 0)
_T:CreateConVar("aimbot_targetplayers", 1)
_T:CreateConVar("aimbot_targetprops", 0)
_T:CreateConVar("aimbot_targetsteamfriends", 0)
_T:CreateConVar("aimbot_targetteammates", 1)
_T:CreateConVar("aimbot_velocitypredict", 1)

m_surface.CreateFont("Arial", 20, 700, true, false, "AimbotText")

local MENU_TABS = {}
	MENU_TABS[1] = "Aimbot"
	MENU_TABS[2] = "ESP"
	MENU_TABS[3] = "Lasers"
	MENU_TABS[4] = "X-Ray"
	MENU_TABS[5] = "Integra"

local MENU_ITEMS = {}
	table.insert(MENU_ITEMS, {tab = "Aimbot", convar = "aimbot_autofire", text = "Autofire", t = "boolean"})
	table.insert(MENU_ITEMS, {tab = "Aimbot", convar = "aimbot_maxangle", text = "Max angle", t = "float", min = 0, max = 360})
	table.insert(MENU_ITEMS, {tab = "Aimbot", convar = "aimbot_maxdist", text = "Max distance", t = "float", min = 0, max = 16384})
	table.insert(MENU_ITEMS, {tab = "Aimbot", convar = "aimbot_targetnpcs", text = "Target NPCs", t = "boolean"})
	table.insert(MENU_ITEMS, {tab = "Aimbot", convar = "aimbot_targetplayers", text = "Target players", t = "boolean"})
	table.insert(MENU_ITEMS, {tab = "Aimbot", convar = "aimbot_targetprops", text = "Target props", t = "boolean"})
	table.insert(MENU_ITEMS, {tab = "Aimbot", convar = "aimbot_targetsteamfriends", text = "Target STEAM friends", t = "boolean"})
	table.insert(MENU_ITEMS, {tab = "Aimbot", convar = "aimbot_targetteammates", text = "Target team-mates", t = "boolean"})
	table.insert(MENU_ITEMS, {tab = "Aimbot", convar = "aimbot_velocitypredict", text = "Velocity Prediction", t = "boolean"})
	table.insert(MENU_ITEMS, {tab = "ESP", convar = "esp_enabled", text = "Enable ESP", t = "boolean"})
	table.insert(MENU_ITEMS, {tab = "ESP", convar = "esp_onlyname", text = "Only show name", t = "boolean"})
	table.insert(MENU_ITEMS, {tab = "ESP", convar = "esp_outlinedtext", text = "Outlined text", t = "boolean"})
	table.insert(MENU_ITEMS, {tab = "Lasers", convar = "laser_enabled", text = "Enable Lasers", t = "boolean"})
	table.insert(MENU_ITEMS, {tab = "Lasers", convar = "laser_eyetracer", text = "Eye/View Tracer", t = "boolean"})
	table.insert(MENU_ITEMS, {tab = "Lasers", convar = "laser_skytracer", text = "Sky Tracer", t = "boolean"})
	table.insert(MENU_ITEMS, {tab = "X-Ray", convar = "xray_enabled", text = "Enable X-Ray", t = "boolean"})
	table.insert(MENU_ITEMS, {tab = "X-Ray", convar = "xray_maxents", text = "Max Entities", t = "int", min = 1, max = 512})
	table.insert(MENU_ITEMS, {tab = "X-Ray", convar = "xray_transparency", text = "Entity Transparency", t = "int", min = 0, max = 100})
	table.insert(MENU_ITEMS, {tab = "Integra", convar = "enabled", text = "Enable Integra", t = "boolean"})
	table.insert(MENU_ITEMS, {tab = "Integra", convar = "crosshair_enabled", text = "Enable crosshair", t = "boolean"})
local function DrawGradientRectH(x, y, w, h, col1, col2)
	local segments = 1 / h

	for i = 0, h do
		local col = Color((col1.r - (col1.r - col2.r) * segments * i), (col1.g - (col1.g - col2.g) * segments * i), (col1.b - (col1.b - col2.b) * segments * i), (col1.a - (col1.a - col2.a) * segments * i))
		m_surface.SetDrawColor(col)
		m_surface.DrawLine(x, y + i, x + w, y + i)
	end
end

local function ShowIntMenu()
	local Frame = vgui.Create("DFrame")
		Frame:SetSize(600, 300)
		Frame:Center()
		Frame:SetTitle("Integra Menu")
		Frame:SetSizable(false)
		Frame:SetDraggable(false)
		Frame:MakePopup()
		function Frame:Paint()
			Derma_DrawBackgroundBlur(self, self.m_fCreateTime)
			m_surface.SetDrawColor(Color(0, 0, 0, 192))
			m_surface.DrawRect(0, 0, self:GetWide(), self:GetTall())
			m_surface.SetDrawColor(Color(102, 0, 0, 192))
			m_surface.DrawRect(0, 0, self:GetWide(), 22)
		end
	local TabList = vgui.Create("DColumnSheet", Frame)
		TabList:SetSize(Frame:GetWide() - 40, Frame:GetTall() - 40)
		TabList:SetPos(10, 30)
		TabList.ButtonOnly = true
		function TabList.Content:Paint()
		end
		for k, v in pairs(MENU_TABS) do
			local panel = vgui.Create("DPanelList", TabList)
			local p_Item = TabList:AddSheet(v, panel , "gui/silkicons/box")
				panel:SetSize(TabList:GetWide() - 200, TabList:GetTall() - 10)
				panel:SetSpacing(5)
				panel:SetPadding(5)
				function panel:Paint()
					m_surface.SetDrawColor(Color(0, 0, 0, 102))
					m_surface.DrawRect(0, 0, self:GetWide(), self:GetTall())
				end

			for _k, _v in pairs(MENU_ITEMS) do
				if _v.tab == v then
					if _v.t == "boolean" then
						local Item = vgui.Create("DCheckBoxLabel")
							Item:SetText(_v.text)
							Item:SetValue(_T:GetConVar(_v.convar):GetBool())
							function Item:OnChange(value)
								local num = 0
								if value then num = 1 end
								m_RunConsoleCommand(_T.CMDPrefix .. "_" .. _v.convar, num)
							end
							Item:SizeToContents()
						panel:AddItem(Item)
					elseif _v.t == "int" then
						local Item = vgui.Create("DNumSlider")
							Item:SetText(_v.text)
							Item:SetMin(_v.min)
							Item:SetMax(_v.max)
							Item:SetValue(_T:GetConVar(_v.convar):GetInt())
							Item:SetDecimals(0)
							function Item:OnValueChanged(value)
								m_RunConsoleCommand(_T.CMDPrefix .. "_" .. _v.convar, value)
							end
						panel:AddItem(Item)
					elseif _v.t == "float" then
						local Item = vgui.Create("DNumSlider")
							Item:SetText(_v.text)
							Item:SetMin(_v.min)
							Item:SetMax(_v.max)
							Item:SetValue(_T:GetConVar(_v.convar):GetFloat())
							Item:SetDecimals(2)
							function Item:OnValueChanged(value)
								m_RunConsoleCommand(_T.CMDPrefix .. "_" .. _v.convar, value)
							end
						panel:AddItem(Item)
					end
				end
			end
		end
		TabList.Navigation:SetWidth(180)
		for k, v in pairs(TabList.Items) do
			v.Button:SetHeight(30)
			v.Button:DockMargin(0, 0, 0, 0)
			if v.Button.m_Image then
				v.Button.m_Image.SetImage = function() end
				v.Button.m_Image.Paint = function() end
			end
			function v.Button:Paint()
				local color = Color(0, 51, 102, 255)
				if TabList:GetActiveButton() == v.Button then
					color = Color(0, 102, 204, 255)
				end
				if self.Depressed then
					color = Color(color.r - (color.r / 6), color.g - (color.g / 6), color.b - (color.b / 6), 255)
				elseif self.Hovered and TabList:GetActiveButton() != v.Button then
					color = Color(color.r + (color.r / 6), color.g + (color.g / 6), color.b + (color.b / 6), 255)
				end
				color.a = 255
				DrawGradientRectH(0, 0, self:GetWide(), self:GetTall(), color, Color(color.r + (color.r / 4), color.g + (color.g / 4), color.b + (color.b / 4), 255))
			end
		end
end

_T:AddCommand("menu", ShowIntMenu)