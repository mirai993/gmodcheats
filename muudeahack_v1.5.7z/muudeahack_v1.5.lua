﻿    local TopFrame
    local AimbotButton
    local NoSpreadButton
    local RapidFireOffButton
    local RapidFireButton
    local SpeedhackButton
    local BypasserButton
    local NoclipButton
    local MorbusButton
     
    local X = -50
    local Y = -100
     
    local KeyPos =  {      
            {X+5, Y+100, 25, 25, -2.2, 3.45, 1.3, -0},
            {X+37.5, Y+100, 25, 25, -0.6, 1.85, 1.3, -0},
            {X+70, Y+100, 25, 25, 1.0, 0.25, 1.3, -0},
     
            {X+5, Y+132.5, 25, 25, -2.2, 3.45, 2.9, -1.6},
            {X+37.5, Y+132.5, 25, 25, -0.6, 1.85, 2.9, -1.6},
            {X+70, Y+132.5, 25, 25, 1.0, 0.25, 2.9, -1.6},
     
            {X+5, Y+165, 25, 25, -2.2, 3.45, 4.55, -3.3},
            {X+37.5, Y+165, 25, 25, -0.6, 1.85, 4.55, -3.3},
            {X+70, Y+165, 25, 25, 1.0, 0.25, 4.55, -3.3},
     
            {X+5, Y+67.5, 50, 25, -2.2, 4.7, -0.3, 1.6},
            {X+60, Y+67.5, 35, 25, 0.3, 1.65, -0.3, 1.6}
    }
     
    local function FindDisplayText(ent)
            if ent.GetDisplayText then
                    return ent:GetDisplayText()
            else
                    return ent.Entity:GetNetworkedInt("keypad_num")
            end
    end
     
    local function FindStatus(ent)
            if ent.GetStatus then
                    return ent:GetStatus()
            elseif ent.Entity:GetNetworkedBool("keypad_access") and ent.Entity:GetNetworkedBool("keypad_showaccess") then
                    return 1
            elseif not ent.Entity:GetNetworkedBool("keypad_access") and ent.Entity:GetNetworkedBool("keypad_showaccess") then
                    return 2
            else
                    return 0
            end
    end
     
    hook.Add("Think", "Somethingoranotherthatissomething", function()
            for k,v in pairs(player.GetAll()) do
                    local kp = v:GetEyeTrace().Entity
                    if IsValid(kp) and (string.find(kp:GetClass(), "keypad") and not(string.find(v:GetClass(), "cracker") or string.find(v:GetClass(), "checker"))) and v:EyePos():Distance(kp:GetPos()) <= 70 then
                            kp.tempCode = kp.tempCode or ""
                            kp.tempText = kp.tempText or ""
                            kp.tempStatus = kp.tempStatus or 0
                           
                            if (FindDisplayText(kp) != kp.tempText) or (FindStatus(kp) != kp.tempStatus) then
                                    kp.tempText = FindDisplayText(kp)
                                    kp.tempStatus = FindStatus(kp)
                                   
                                    local tr = util.TraceLine({
                                            start = v:EyePos(),
                                            endpos = v:GetAimVector() * 32 + v:EyePos(),
                                            filter = v
                                    })
                                   
                                    local pos = kp:WorldToLocal(tr.HitPos)
                                   
                                    for i,p in pairs(KeyPos) do
                                            local x = (pos.y - p[5]) / (p[5] + p[6])
                                            local y = 1 - (pos.z + p[7]) / (p[7] + p[8])
                                           
                                            if (x >= 0 and y >= 0 and x <= 1 and y <= 1) then
                                                    if i == 11 then
                                                            if kp.tempStatus == 1 then
                                                                    kp.code = kp.tempCode
                                                                    kp.tempCode = ""
                                                            elseif kp.tempStatus == 2 then
                                                                    kp.tempCode = ""
                                                            end
                                                    elseif i == 10 then
                                                            kp.tempCode = ""
                                                    elseif i > 0 then
                                                            kp.tempCode = kp.tempCode..i
                                                    end
                                            end
                                    end
                            end
                    end
            end
    end)
     
    hook.Add( "HUDPaint", "somethingoranotherthatissomethingelse", function()
            local e = LocalPlayer():GetEyeTrace().Entity
            if IsValid(e) and string.find(e:GetClass(), "keypad") then
                    local text = e.code or "Not Found"
                    draw.WordBox( 8, ScrW() / 2, ScrH() / 2, text, "Default", Color(50,50,75,100), Color(255,255,255,255) )
            end
           
            for k,v in pairs(ents.GetAll()) do
                    if IsValid(v) then
                            if string.find(v:GetClass(), "keypad") and not(string.find(v:GetClass(), "cracker") or string.find(v:GetClass(), "checker")) then
                                    if v != e then
                                            local pos = v:GetPos():ToScreen()
                                            if IsValid(v) and v.code then
                                                    draw.RoundedBox( 4, pos.x-5, pos.y-5, 20, 20, Color( 0, 255, 0, 150 ) )
                                            else
                                                    draw.RoundedBox( 4, pos.x-5, pos.y-5, 20, 20, Color( 255, 0, 0, 150 ) )
                                            end
                                    end
                            end
                    end
            end
    end)
     
    function muudeahack()
    TopFrame = vgui.Create('DFrame')
    TopFrame:SetSize(170, 260)
    TopFrame:SetPos(5, 5)
    TopFrame:SetTitle('Muudea Hack v1.5')
    TopFrame:SetDeleteOnClose(false)
    TopFrame:MakePopup()
     
    AimbotButton = vgui.Create('DButton')
    AimbotButton:SetSize(160, 25)
    AimbotButton:SetPos(5, 90)
    AimbotButton:SetText('Aimbot')
    AimbotButton:SetVisible('true')
    AimbotButton:SetParent( TopFrame )
    AimbotButton.DoClick = function()
    hook.Add( "Think", "ThinkAboutIt", function()
            if input.IsKeyDown(KEY_T) then
                    local closest = nil
                   
                    local hitpos = LocalPlayer():GetEyeTrace()
                   
                    for k, v in pairs( ents.FindInSphere(hitpos.HitPos,500) ) do
                            if v:IsPlayer() and v != LocalPlayer() then
                                    if v:Alive() then
                                            closest = v
                                    end
                            end
                    end
                   
                    if closest and closest:IsPlayer() and closest:Alive() then
                            local head = closest:LookupBone("ValveBiped.Bip01_Head1")
                            local headpos, headang = closest:GetBonePosition(head)
                           
                            LocalPlayer():SetEyeAngles( (headpos-LocalPlayer():GetShootPos()):Angle() )
                            end
                    end
            end)
    end
    NoSpreadButton = vgui.Create('DButton')
    NoSpreadButton:SetSize(160, 25)
    NoSpreadButton:SetPos(5, 180)
    NoSpreadButton:SetText('No Spread')
    NoSpreadButton:SetVisible('true')
    NoSpreadButton:SetParent( TopFrame );
    NoSpreadButton.DoClick = function()
    require( "nospread" )
     
    local NormalCones                       = {
            [ "weapon_cs_base" ]    = true,
            [ "weapon_zs_base" ]    = true,
    }
     
    local HL2Cones                          = {
            [ "weapon_pistol" ]     = Vector( 0.0100, 0.0100, 0.0100 ),
            [ "weapon_smg1" ]               = Vector( 0.04362, 0.04362, 0.04362 ),
            [ "weapon_ar2" ]                = Vector( 0.02618, 0.02618, 0.02618 ),
            [ "weapon_shotgun" ]    = Vector( 0.08716, 0.08716, 0.08716 ),
    }
     
    function GetCone( wep )
            if !IsValid( wep ) then return 0 end
           
            if HL2Cones[ wep:GetClass() ] then return HL2Cones[ wep:GetClass() ] end
            if NormalCones[ wep.Base ] then return wep.Cone or wep.Primary.Cone or 0 end
           
            local Cone = wep.Cone
           
            if !Cone then
                    Cone = wep.Primary and wep.Primary.Cone or 0
            end
           
            return Cone
    end
     
    function PredictSpread( cmd, ang )
    local w = LocalPlayer():GetActiveWeapon()
    local vecCone, valCone = Vector( 0, 0, 0 )
            if ( w && w:IsValid() && ( type( w.Initialize ) == "function" ) ) then
                    valCone = GetCone( w )                    
                    if ( type( valCone ) == "number" ) then
                            vecCone = Vector( -valCone, -valCone, -valCone )                      
                    elseif ( type( valCone ) == "Vector" ) then
                            vecCone = valCone * -1    
                    elseif bit.band( cmd:GetButtons(), IN_SPEED ) or bit.band( cmd:GetButtons(), IN_JUMP ) then
                            vecCone = valCone + (cone * 2 )                        
                    end
            else
                    if ( w:IsValid() ) then
                            local class = w:GetClass()
                            if ( HL2Cones[ class ] ) then
                                    vecCone = HL2Cones[ class ]
                            end
                    end
            end
    return DS_manipulateShot( DS_md5PseudoRandom( DS_getUCMDCommandNumber( cmd ) ), ang:Forward(), vecCone ):Angle()
    end
     
    local angles = Angle( 0, 0, 0 )
     
    function GetAngles()
            if ( !ValidEntity( LocalPlayer() ) ) then return end
            angles = LocalPlayer():EyeAngles()
    end
     
    function Parkinsons( ucmd )
            angles.p = math.NormalizeAngle( angles.p )
            angles.y = math.NormalizeAngle( angles.y )
           
            local correct = 1
            angles.y = math.NormalizeAngle( angles.y + ( ucmd:GetMouseX() * -0.022 * correct ) )
            angles.p = math.Clamp( angles.p + ( ucmd:GetMouseY() * 0.022 * correct ), -89, 90 )
            ucmd:SetViewAngles( angles )
           
            if ( ucmd:GetButtons() && IN_ATTACK > 0 ) then
                    local FakeAngle = PredictSpread( ucmd, angles )
                    FakeAngle.p = math.NormalizeAngle( FakeAngle.p )
                    FakeAngle.y = math.NormalizeAngle( FakeAngle.y )
                    ucmd:SetViewAngles( FakeAngle )
            end
    end
     
    function CalcView( ply, origin, angles, FOV )
            local ply = LocalPlayer()
            local w = ply:GetActiveWeapon()
           
            local wep = ply:GetActiveWeapon()
            if wep.Primary then wep.Primary.Recoil = 0 end
            if wep.Secondary then wep.Secondary.Recoil = 0 end
            local view = GAMEMODE:CalcView( ply, origin, angles, zoomFOV ) || {}
            view.angles = angles
            view.angles.r = 0
            view.fov = zoomFOV
            return view
    end
     
    hook.Add( "CalcView", "I hate making hook names", CalcView )
    hook.Add( "CreateMove", "YouHaveParkinsons", Parkinsons )
    end
    RapidFireOffButton = vgui.Create('DButton')
    RapidFireOffButton:SetSize(140, 16)
    RapidFireOffButton:SetPos(15, 240)
    RapidFireOffButton:SetText('Rapid Fire Off')
    RapidFireOffButton:SetVisible('true')
    RapidFireOffButton:SetParent( TopFrame );
    RapidFireOffButton.DoClick = function()
    RunConsoleCommand("-muudearapidfire")
    end
    RapidFireButton = vgui.Create('DButton')
    RapidFireButton:SetSize(160, 25)
    RapidFireButton:SetPos(5, 210)
    RapidFireButton:SetText('Rapid Fire')
    RapidFireButton:SetParent( TopFrame );
    RapidFireButton.DoClick = function()
	require("cvar3")
	
	function Rapidfire()     
	local Shoot = false
	GetConVar("sv_cheats"):SetValue(1)
	GetConVar("host_timescale"):SetValue(5)
    if Shoot == false then
    RunConsoleCommand("+attack")
    Shoot = true
    elseif Shoot == true then
    RunConsoleCommand("-attack")
    Shoot = false
    end
    end
    concommand.Add("+muudearapidfire", Rapidfire)
	RunConsoleCommand("+muudearapidfire")
    function RemoveSpeedShoot()
            hook.Remove("Think", "SpeedShoot")
            RunConsoleCommand("-attack")
			GetConVar("host_timescale"):SetValue(1)
    end
	concommand.Add("-muudearapidfire", RemoveSpeedShoot)
	end
    SpeedhackButton = vgui.Create('DButton')
    SpeedhackButton:SetSize(160, 25)
    SpeedhackButton:SetPos(5, 150)
    SpeedhackButton:SetText('Speedhack')
    SpeedhackButton:SetVisible('true')
    SpeedhackButton:SetParent( TopFrame );
    SpeedhackButton.DoClick = function()
    require("cvar3")
    CreateClientConVar("muudea_setspeed", 2)
     
    concommand.Add("muudeaspeed+", function()
            RunConsoleCommand("muudea_setspeed", ""..GetConVarNumber("muudea_setspeed") + 0.5)
            timer.Simple(0.25, function()
                    chat.AddText("Speed is: "..GetConVarNumber("muudea_setspeed").."x normal")
             end)
    end)
    concommand.Add("muudeaspeed-", function()
            RunConsoleCommand("muudea_setspeed", ""..GetConVarNumber("muudea_setspeed") - 0.5)
            timer.Simple(0.25, function()
                    chat.AddText("SpeedHack Speed is Now: "..GetConVarNumber("muudea_setspeed").."x normal")
             end)
    end)
     
     
    concommand.Add("+muudeaspeed", function()
            GetConVar("sv_cheats"):SetValue(1)
            GetConVar("host_timescale"):SetValue(GetConVarNumber("muudea_setspeed"))
    end)
     
    concommand.Add("-muudeaspeed", function()
            GetConVar("host_timescale"):SetValue(1)
    end)
    end
    BypasserButton = vgui.Create('DButton')
    BypasserButton:SetSize(160, 25)
    BypasserButton:SetPos(5, 120)
    BypasserButton:SetText('Bypasser')
    BypasserButton:SetVisible('true')
    BypasserButton:SetParent( TopFrame );
    BypasserButton.DoClick = function()
    require("cvar3")
    GetConVar("sv_allowcslua"):SetFlags(0)
    GetConVar("sv_cheats"):SetFlags(0)
    GetConVar("sv_allowcslua"):SetValue(1)
    GetConVar("sv_cheats"):SetValue(1)
    end
	InfoLabel = vgui.Create('DLabel')
    InfoLabel:SetPos(40, 30)
    InfoLabel:SetText('Muudea Hack v1.5\n  muudea@live.ca')
    InfoLabel:SizeToContents()
	InfoLabel:SetParent( TopFrame );
    NoclipButton = vgui.Create('DButton')
    NoclipButton:SetSize(160, 25)
    NoclipButton:SetPos(5, 60)
    NoclipButton:SetText('Client Noclip')
    NoclipButton:SetVisible('true')
    NoclipButton:SetParent( TopFrame );
    NoclipButton.DoClick = function()
    local SW = {}
    SW.Enabled = false
    SW.ViewOrigin = Vector( 0, 0, 0 )
    SW.ViewAngle = Angle( 0, 0, 0 )
    SW.Velocity = Vector( 0, 0, 0 )
     
    function SW.CalcView( ply, origin, angles, fov )
            if ( !SW.Enabled ) then return end
            if ( SW.SetView ) then
                    SW.ViewOrigin = origin
                    SW.ViewAngle = angles
                   
                    SW.SetView = false
            end
            return { origin = SW.ViewOrigin, angles = SW.ViewAngle }
    end
    hook.Add( "CalcView", "SpiritWalk", SW.CalcView )
     
    function SW.CreateMove( cmd )
            if ( !SW.Enabled ) then return end
           
            // Add and reduce the old velocity.
            local time = FrameTime()
            SW.ViewOrigin = SW.ViewOrigin + ( SW.Velocity * time )
            SW.Velocity = SW.Velocity * 0.95
           
            // Rotate the view when the mouse is moved.
            local sensitivity = 0.022
            SW.ViewAngle.p = math.Clamp( SW.ViewAngle.p + ( cmd:GetMouseY() * sensitivity ), -89, 89 )
            SW.ViewAngle.y = SW.ViewAngle.y + ( cmd:GetMouseX() * -1 * sensitivity )
           
            // What direction we're going to move in.
          local add = Vector( 0, 0, 0 )
          local ang = SW.ViewAngle
          if ( cmd:KeyDown( IN_FORWARD ) ) then add = add + ang:Forward() end
          if ( cmd:KeyDown( IN_BACK ) ) then add = add - ang:Forward() end
          if ( cmd:KeyDown( IN_MOVERIGHT ) ) then add = add + ang:Right() end
          if ( cmd:KeyDown( IN_MOVELEFT ) ) then add = add - ang:Right() end
          if ( cmd:KeyDown( IN_JUMP ) ) then add = add + ang:Up() end
          if ( cmd:KeyDown( IN_DUCK ) ) then add = add - ang:Up() end
       
          // Speed.
          add = add:GetNormal() * time * 500
          if ( cmd:KeyDown( IN_SPEED ) ) then add = add * 2 end
       
          SW.Velocity = SW.Velocity + add
       
          // This stops us looking around crazily while spiritwalking.
          if ( SW.LockView == true ) then
                  SW.LockView = cmd:GetViewAngles()
          end
          if ( SW.LockView ) then
                  cmd:SetViewAngles( SW.LockView )
          end
       
          // This stops us moving while spiritwalking.
          cmd:SetForwardMove( 0 )
          cmd:SetSideMove( 0 )
          cmd:SetUpMove( 0 )
    end
    hook.Add( "CreateMove", "SpiritWalk", SW.CreateMove )
     
          SW.Enabled = !SW.Enabled
          SW.LockView = SW.Enabled
          SW.SetView = true
       
          local status = { [ true ] = "ON", [ false ] = "OFF" }
          print( "Muudea NoClip Enabled!" )
                   end
    concommand.Add( "sw_pos", function() print( SW.ViewOrigin ) end )
	end
	concommand.Add("openmuudeahack", muudeahack )
    chat.AddText(Color( 255, 50, 63 ), "Muudea Hack Loaded! - muudea@live.ca")
    chat.PlaySound()