--[[
	MOD/lua/ownhack.lua
	Flamme | STEAM_0:1:13419931 <62.107.46.178:27005> | [28-10-13 09:23:43PM]
	===BadFile===
]]

for I = 1,100 do
	surface.CreateFont("HFont-"..I, {
		size = I,
		weight = 500,
		antialias = true,
		shadow = false,
		font = "Trebuchet MS"})
		
	surface.CreateFont("HFontAwe-"..I, {
		font = "Tahoma",
		size = I,
		weight = 600,
		antialias = true
	})	
end
local Table = {}
Table["X"] = ScrW()
Table["Y"] = ScrH()
Table["Wallhack"] = false
hook.Add("Think","Valgfritnavn",function()
	--http://maurits.tv/data/garrysmod/wiki/wiki.garrysmod.com/indexa077.html
	--local wait=1
	if(input.IsKeyDown(KEY_PAGEDOWN)) then
		--timer.Simple(2,function() wait=0 end)
		
			if IsValid(Table["Frame"]) then
				Table["Frame"]:Remove()
			else
				local FramePos=Vector(Table["X"]*0.66,Table["Y"]*0.01,0)
				local FrameScale=Vector(Table["X"]/3,Table["Y"]/3,0)
				Table["Frame"] = vgui.Create("DFrame")
				Table["Frame"]:SetSize(FrameScale.x,FrameScale.y)
				Table["Frame"]:SetPos(FramePos.x,FramePos.y)
				Table["Frame"]:SetTitle("Hack")
				Table["Frame"]:MakePopup()
				
				Table["Button"] = vgui.Create("DButton",Table["Frame"])			
				Table["Button"]:SetSize(FrameScale.x*0.25,FrameScale.y*0.25)			
				Table["Button"]:SetPos(FramePos.x+10,FramePos.Y+10)			
				Table["Button"]:SetText("Text")
				Table["Button"].DoClick = function()		
					Table["Wallhack"] = !Table["Wallhack"]			
				end
			end	
	end
end)
hook.Add( "HUDPaint", "Valgfritnavnigen", function()
	if Table["Wallhack"] then
		for k,ply in ipairs(player.GetAll()) do		
		
			Table["Text"] = "Name: "..ply:GetName()		
			
			surface.SetFont("HFontAwe-20")
			
			Table["Textsize"] = surface.GetTextSize(Table["Text"])+20
			
			Table["Pos"] = ply:GetPos():ToScreen()
			
			draw.SimpleText(Table["Text"],"HFontAwe-20",Table["Pos"].x,Table["Pos"].y,Color(0,200,0,255),1)
			
			draw.RoundedBox( 5 ,Table["Pos"].x-(Table["Textsize"]/2), Table["Pos"].y, Table["Textsize"], 25 ,Color(70,70,70,150) )	
		end
	end
end)