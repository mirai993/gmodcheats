--[[
	MOD/lua/WoodHack.lua [#10967 (#11306), 3517940778, UID:3531822058]
	Neko nya | STEAM_0:0:90984434 <79.239.1.57:27005> | [02.07.14 04:15:56AM]
	===BadFile===
]]

-- Made By WoodHack™ - L34K3D 8Y K0RK1P00 (3P!C)

// Locals
local _G                                = table.Copy( _G )
local _R                                = _G.debug.getregistry()
local math                              = _G.math
local string                            = _G.string
local hook                              = _G.hook
local table                             = _G.table
local timer                             = _G.timer
local surface                           = _G.surface
local concommand                        = _G.concommand
local CreateClientConVar 				= _G.CreateClientConVar
local cvars                             = _G.cvars
local ents                              = _G.ents
local player                            = _G.player
local team                              = _G.team
local util                              = _G.util
local draw                              = _G.draw
local usermessage                       = _G.usermessage
local vgui                              = _G.vgui
local http                              = _G.http
local cam                               = _G.cam
local render                            = _G.render
local MsgN                              = _G.MsgN
local Msg                               = _G.Msg
local Vector                            = _G.Vector
local Angle                             = _G.Angle
local pairs                             = _G.pairs
local ipairs                            = _G.ipairs
local CreateSound                       = _G.CreateSound
local setmetatable                      = _G.setmetatable
local Sound                             = _G.Sound
local print                             = _G.print
local pcall                             = _G.pcall
local type                              = _G.type
local require							= _G.require
local tostring 							= _G.tostring
local LocalPlayer                       = _G.LocalPlayer
local KeyValuesToTable      		    = _G.KeyValuesToTable
local TableToKeyValues     			    = _G.TableToKeyValues
local Color                             = _G.Color

local GCVN 								= GetConVarNumber;
local GCV								= GetConVar;
local CCCV 								= CreateClientConVar;
local RCC 								= RunConsoleCommand;
local HOOKADD 							= hook.Add;
local HOOKREMOVE 						= hook.Remove;
local ADDCVCALLBACK 					= cvars.AddChangeCallback;
local CCADD 							= concommand.Add;
local WoodHack 							= LocalPlayer()

// ConVars
CCCV("WoodHack_Aimbot", 1, true, false)
CCCV("WoodHack_Triggerbot", 1, true, false)
CCCV("WoodHack_NoRecoil", 1, true, false)
CCCV("WoodHack_Wallhack", 1, true, false)
CCCV("WoodHack_Crosshair", 1, true, false)
CCCV("WoodHack_Bunnyhop", 1, true, false)

// Random Name Func
WoodHack.Chars = {
"A",
"B",
"C",
"D",
"E",
"F",
"G",
"H",
"I",
"J",
"K",
"L",
"M",
"N",
"O",
"P",
"Q",
"R",
"S",
"T",
"U",
"V",
"W",
"X",
"Y",
"Z",
"1",
"2",
"3",
"4",
"5",
"6",
"7",
"8",
"9"
 }
 
WoodHack.RandomName = function(amount)
        local toReturn = ""
        local amount = amount or 10
        for i = 1, amount do
                if math.random(0, 1) == 0 then
                        toReturn = toReturn..string.lower(table.Random(WoodHack.Chars))
                else
                        toReturn = toReturn..table.Random(WoodHack.Chars)
                end
        end
        return toReturn
end

HOOKADD("Think", WoodHack.RandomName(math.random(10,15)), function()
cunta = math.random(0,255)
cuntb = math.random(0,255)
cuntc = math.random(0,255)
cuntd = math.random(0,1000)
cunte = math.random(0,1000)
end)

// Aimbot
HOOKADD("Think", WoodHack.RandomName(math.random(10,15)), function()
if GCVN("WoodHack_Aimbot") >= 1 then
	local trace = util.GetPlayerTrace( WoodHack )
	local traceRes = util.TraceLine( trace )
	if traceRes.HitNonWorld then
		local target = traceRes.Entity
		if target:IsPlayer() then
			local targethead = target:LookupBone("ValveBiped.Bip01_Head1")
			local targetheadpos,targetheadang = target:GetBonePosition(targethead)
			local eyes = WoodHack:SetEyeAngles((targetheadpos - WoodHack:GetShootPos()):Angle())
		end
	end
end
end)

// Triggerbot
HOOKADD("CreateMove", WoodHack.RandomName(math.random(10,15)), function(cmd)
if GCVN("WoodHack_Triggerbot") >= 1 then
	local trace = util.GetPlayerTrace( WoodHack )
	local traceRes = util.TraceLine( trace )
	local target = traceRes.Entity
	if traceRes.HitNonWorld then
		local target = traceRes.Entity
		if target:IsPlayer() or target:IsNPC() then
			if shoot == 0 then
			cmd:SetButtons(bit.bor(cmd:GetButtons(), IN_ATTACK))
			shoot = 1
		else
			cmd:SetButtons(bit.band(cmd:GetButtons(), bit.bnot(IN_ATTACK)))
			shoot = 0
		end
		end	
	end
	end
end)

// Wall Hack
HOOKADD( "HUDPaint", WoodHack.RandomName(math.random(10,15)), function()

	for k,v in pairs (player.GetAll()) do
	if GCVN("WoodHack_Wallhack") >= 1 then
                        if v ~= WoodHack then
		if WoodHack:Alive() then
		local Position = ( v:GetPos() + Vector( 0,0,80 ) ):ToScreen()
		draw.DrawText( v:Name(), "ChatFont", Position.x, Position.y, Color( cunta, cuntb, cuntc, 255), 1 )
		else
end
end
end
end

if GCVN("WoodHack_Wallhack") >= 1 then
for k,v in pairs ( player.GetAll() ) do
 
        local Position = ( v:GetPos() + Vector( 0,0,80 ) ):ToScreen()
        local Name = ""
 
        if v == WoodHack then Name = "" else Name = v:Name() end
 
end
end

// Crosshair
if GCVN("WoodHack_Crosshair") >= 1 then
surface.SetDrawColor(cunta, cuntb, cuntc, 255)
surface.DrawLine(ScrW() / 2 - 10, ScrH() / 2, ScrW() / 2 + 11 , ScrH() / 2)
surface.DrawLine(ScrW() / 2 - 0, ScrH() / 2 - 10, ScrW() / 2 - 0 , ScrH() / 2 + 11)
local target = WoodHack:GetEyeTrace().Entity
	if target:IsValid() then
		if target:IsPlayer() or target:IsNPC() then
		local x, y, w = ScrW() / 2, ScrH() / 2, 14
		surface.SetDrawColor(cunta, cuntb, cuntc, 255) 
		surface.DrawLine(x - w, y - w, x + w, y + w)
		surface.DrawLine(x - w, y + w, x + w, y - w)	
		end
	end
end

// Bounding Box
local function coordinates( ent )
local min, max = ent:OBBMins(), ent:OBBMaxs()
local corners = {
        Vector( min.x, min.y, min.z ),
        Vector( min.x, min.y, max.z ),
        Vector( min.x, max.y, min.z ),
        Vector( min.x, max.y, max.z ),
        Vector( max.x, min.y, min.z ),
        Vector( max.x, min.y, max.z ),
        Vector( max.x, max.y, min.z ),
        Vector( max.x, max.y, max.z )
}

local minX, minY, maxX, maxY = ScrW() * 6, ScrH() * 6, 0, 0
for _, corner in pairs( corners ) do
        local onScreen = ent:LocalToWorld( corner ):ToScreen()
        minX, minY = math.min( minX, onScreen.x ), math.min( minY, onScreen.y )
        maxX, maxY = math.max( maxX, onScreen.x ), math.max( maxY, onScreen.y )
end
 
return minX, minY, maxX, maxY
end

if GCVN("WoodHack_Wallhack") >= 1 then
for k,v in pairs(player.GetAll()) do
    local x1,y1,x2,y2 = coordinates(v)
    surface.SetDrawColor(cunta, cuntb, cuntc, 255)
	
    surface.DrawLine( x1, y1, math.min( x1 + 5, x2 ), y1 )
    surface.DrawLine( x1, y1, x1, math.min( y1 + 5, y2 ) )
 
 
    surface.DrawLine( x2, y1, math.max( x2 - 5, x1 ), y1 )
    surface.DrawLine( x2, y1, x2, math.min( y1 + 5, y2 ) )
 
 
    surface.DrawLine( x1, y2, math.min( x1 + 5, x2 ), y2 )
    surface.DrawLine( x1, y2, x1, math.max( y2 - 5, y1 ) )
	
	
    surface.DrawLine( x2, y2, math.max( x2 - 5, x1 ), y2 )
    surface.DrawLine( x2, y2, x2, math.max( y2 - 5, y1 ) )
	end
end

draw.DrawText("Thanks for using WoodHack! We, at WoodHack™ would like to say thank you to all the beta testers of our new hack!", "Default", cuntd, cunte, stupidcolor, TEXT_ALIGN_CENTER)

stupidcolor = Color(math.random(0,255),math.random(0,255),math.random(0,255), 255)

// Notification
if GCVN("WoodHack_Aimbot") >= 1 then
	draw.DrawText("Aimbot Enabled", "Default", 10, 0, stupidcolor, TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT)
else
	draw.DrawText("Aimbot Disabled", "Default", 10, 0, stupidcolor, TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT)
end

if GCVN("WoodHack_Triggerbot") >= 1 then
	draw.DrawText("Triggerbot Enabled", "Default", 10, 15, stupidcolor, TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT)
else
	draw.DrawText("Triggerbot Disabled", "Default", 10, 15, stupidcolor, TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT)
end

if GCVN("WoodHack_NoRecoil") >= 1 then
	draw.DrawText("NoRecoil Enabled", "Default", 10, 30, stupidcolor, TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT)
else
	draw.DrawText("NoRecoil Disabled", "Default", 10, 30, stupidcolor, TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT)
end

if GCVN("WoodHack_Wallhack") >= 1 then
	draw.DrawText("Wallhack Enabled", "Default", 10, 45, stupidcolor, TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT)
else
	draw.DrawText("Wallhack Disabled", "Default", 10, 45, stupidcolor, TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT)
end

if GCVN("WoodHack_Bunnyhop") >= 1 then
	draw.DrawText("Bunnyhop Enabled", "Default", 10, 60, stupidcolor, TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT)
else
	draw.DrawText("Bunnyhop Disabled", "Default", 10, 60, stupidcolor, TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT)
end

end)

// Visual NoRecoil
HOOKADD( "CalcView", WoodHack.RandomName(math.random(10,15)), function( ply, pos, angles, fov )
if WoodHack:Alive() then
	if GCVN("WoodHack_NoRecoil") >= 1 then
		if WoodHack:GetActiveWeapon().Primary then
			WoodHack:GetActiveWeapon().Primary.Recoil = 0
			end
				return GAMEMODE:CalcView( ply, WoodHack:EyePos(), WoodHack:EyeAngles(), fov, 0.1 );
			else
		if WoodHack:GetActiveWeapon().Primary then
			WoodHack:GetActiveWeapon().Primary.Recoil = 0.1
			end
		end
	end
end)

// NoRecoil
if GCVN("WoodHack_NoRecoil") >= 1 then
    if IsValid(WoodHack:GetActiveWeapon()) then
		local weapon = WoodHack:GetActiveWeapon()
            if weapon.Primary then
            weapon.OldRecoil = weapon.OldRecoil or weapon.Primary.Recoil or weapon.Recoil
            weapon.Primary.Recoil = 0
            weapon.Recoil = 0
        else
            weapon.OldRecoil = weapon.OldRecoil or weapon.Recoil
            weapon.Recoil = 0
			end
        end
            elseif IsValid(WoodHack:GetActiveWeapon()) then
            local weapon = WoodHack:GetActiveWeapon()
                if weapon.Primary then
                weapon.Primary.Recoil = weapon.OldRecoil or weapon.Primary.Recoil or weapon.Recoil
                weapon.Recoil = weapon.OldRecoil or weapon.Recoil or weapon.Primary.Recoil
            else
                weapon.Recoil = weapon.OldRecoil or weapon.Recoil
            end
        end

// Bunnyhop
HOOKADD("CreateMove", WoodHack.RandomName(math.random(10,15)), function(cmd)
	if GCVN("WoodHack_Bunnyhop") >= 1 and cmd:KeyDown(IN_JUMP) then
		cmd:SetButtons(cmd:GetButtons() - IN_JUMP)
	if GCVN("WoodHack_Bunnyhop") >= 1 and WoodHack:OnGround() then
		cmd:SetButtons(cmd:GetButtons() + IN_JUMP)
		end
	end
end)

// 180 Spin
CCADD("WoodHack_Spin", function() WoodHack:SetEyeAngles(WoodHack:EyeAngles()+Angle(0,180,0)) end)

// Noise
RCC("play", "garrysmod/balloon_pop_cute.wav")
WoodHack:ChatPrint("Made by WoodHack™")
WoodHack:ChatPrint("Bypassing Anti-Cheats!")
WoodHack:ChatPrint("WoodHack Loaded Sucessfully!")