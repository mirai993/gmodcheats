--[[
	MOD/lua/eeasspee.lua
	are yoMy balls a botnet | STEAM_0:1:25681613 <68.35.220.66:27005> | [19-10-13 02:18:15AM]
	===BadFile===
]]

// lua_run_cl hook.Add("Think", "     ", function() LocalPlayer():ConCommand("_DarkRP_Doanimation 1627") end)


//random shit from my old lua hack I patched together after the gm13 update.  This is pretty much obsolete.

//local butterflieee8D = "?�??????�?�?"

//Initialize main table
local Valkyrie = {
    //Main thingsa
    vars = {},
    binds = {},
    hooks = {},
    cmds = {},
    consolecmds = {},
    data = {
        fnlog = {},
        keys = {},
        mappoints
    },
    settings = {
        dontlog = {}
    },
    badmaterials = {
        skybox = {},
        ropes = {},
    },
    props = {
        cats = {}
    },
    detectors = {
        spawneddetectors = {},
        presetdetectors = {},
        logs = {}
    },
    internallist = {
        friends = {},
        enemies = {},
        unaffiliated = {},
    },
    blacklist = {
    },
    whitelist = {
    }
}
local Theme = {                 //Theme table
    //Menu vars
        //Colors
        {"maintabmenucolors_mainbackground_r", 0},
        {"maintabmenucolors_mainbackground_g", 0},
        {"maintabmenucolors_mainbackground_b", 0},
        {"maintabmenucolors_mainbackground_a", 240},
        {"maintabmenucolors_mainbackgroundborder_r", 0},
        {"maintabmenucolors_mainbackgroundborder_g", 225},
        {"maintabmenucolors_mainbackgroundborder_b", 255},
        {"maintabmenucolors_mainbackgroundborder_a", 255},

        //Configs (size, settings, etc)
        {"menuconfig_bottomthingy_pinch", 30},


    //ESP/Wallhack/HUD Elements
        //Colors
        {"me_eyel_r", 255},
        {"me_eyel_g", 0},
        {"me_eyel_b", 0},
        {"ply_eyel_r", 0},
        {"ply_eyel_g", 200},
        {"ply_eyel_b", 255},
        {"ply_enemy_r", 255},
        {"ply_enemy_g", 0},
        {"ply_enemy_b", 0},
        {"ply_friend_r", 0},
        {"ply_friend_g", 255},
        {"ply_friend_b", 0},
        {"ply_unaffiliated_r", 255},
        {"ply_unaffiliated_g", 0},
        {"ply_unaffiliated_b", 0},
        {"npc_enemy_r"},
        {"npc_enemy_g"},
        {"npc_enemy_b"},
        {"npc_friend_r"},
        {"npc_friend_g"},
        {"npc_friend_b"},
        {"prop_tracepth_r", 255},
        {"prop_tracepth_g", 255},
        {"prop_tracepth_b", 255},
        {"ply_tracepth_r", 255},
        {"ply_tracepth_g", 0},
        {"ply_tracepth_b", 0},
}
Valkyrie.vars = {       //"convar" table.  Indents indicate that the variable is a toggle or something related to the convar above it.

    //Main
    {"main_steamfriendsarefriends", 1},         //Steam friends automatically get added to the friend table
    {"main_fucktheman", 1},                     //Admins or groups that are specified as bad automatically get added to the enemy table

    //Esp Vars
        //Color types
        {"esp_textcolor", "Internal List"},
        {"esp_boxcolor", "Internal List"},

        //On/Off
        {"esp_players", 1},
        {"esp_shownames", 1},
        {"esp_showdead", 0},
        {"esp_showboxes", 1},
        {"esp_showhealth", 1},
        {"esp_showweapons", 1},
        {"esp_showdistance", 0},
        {"esp_drawbox", 1},
        {"esp_draweyetrace", 1},
        {"esp_drawskytrace", 0},
        {"esp_drawfloortrace", 0},

        {"esp_showthreats", 1},
        {"esp_showmoneyprinters", 1},
        {"esp_showshipments", 1},
        {"esp_showmoney", 1},
        {"esp_showc4", 1},
        {"esp_showkeypads", 1},
        {"esp_showmappoints", 1},
        {"esp_showspawnedweapons", 1},
            {"esp_showspawnedweapons_useresolver", 1},
        {"esp_showcustoments", 0},

    //Propminge Vars
    {"prop_spawnbannedprops", 1},
    {"prop_viewcam", 0},
    {"prop_showspawnedprops", 1},
    {"prop_playertracer", 0},
    {"prop_proptracer", 0},
    {"prop_birdtracer", 0},

    //Misc Vars
    {"misc_stealallnames", 0},
    {"misc_announcespectators", 1},
}

local BadStuff = {
    "npc_grenade_frag", 
    "npc_satchel",
    "crossbow_bolt", 
    "rpg_missile", 
    "grenade_ar2", 
    "prop_combine_ball", 
    "hunter_flechette", 
    "ent_flashgrenade", 
    "ent_explosivegrenade", 
    "ent_smokegrenade"
}

local SafeWeapons = {
    //"weapon_physgun", 
    "gmod_tool", 
    //"weapon_physcannon", 
    "physgun_beam", 
    "pocket", 
    "keys", 
    "gmod_camera", 
    "camera"
}

local MoneyPrinterModels = { 
    "money_printer", 
    "reg_money_printer", 
    "platinum_printer", 
    "silver_printer", 
    "premium_printer", 
    "golden_printer", 
    "diamond_printer", 
    "titanium_printer", 
    "zz_money_printer", 
    "money_printer_commercial", 
    "money_printer_industrial", 
    "gold_printer", 
    "iron_printer", 
    "rusty_printer", 
    "nuclear_printer", 
    "average_money_printer", 
    "portable_money_printer", 
    "small_money_printer", 
    "big_portable_money_printer", 
    "vip_money_printer", 
    "emerald_money_printer"
}

Valkyrie.data.mappoints = {     //Inspired by deco's feature.  Oh yeah, and most of these points are c+p (as of now, anyway)
    {"zs_gu_caves", "Secret Button", 325, -631.5, -141.5},
    {"zs_frostydeath_v1", "Strange Button", -505, -433.5, 119},
    {"zs_citadel_b4", "Some Button", 450, -232.5, 875},
    {"zs_uglyfort_nowater", "Some button", 1375.5, 1996.5, 54.5},
    {"zs_storm_b1", "lol", -422.5, -476, 60},
    {"zs_gu_hamlet_v2", "I will survive!", 782.91, 1322.75, -568.5},
    {"zs_gu_hamlet_v2", "Secret Teleport", 2192.37, -768.19, -468},
    {"zs_gu_hamlet_v2", "Secret Button", 2314.52, -724.05, -385.51},
    {"zs_gu_hamlet_v2", "Secret Teleport 2", -1734.36, -377, -138.68},
    {"zs_gu_hamlet_v2", "Secret Teleport 3", 436.64, 337.11, -519.98},
    {"zs_gu_hamlet_v2", "Secret Button 2", -1803.34 -575.5 -151.34},
    {"gm_atomic", "Gnome", -8928.7119, -4031.9475, -12906.1807},
    {"zs_minifactory_v4_2", "REEEEEEH", 1988, 496, 128},
    {"zm_forgotten_town", "Some Door", -2832, 1696, -146},
    {"zs_farmhouse", "Some Breakable Thing", 616, -492, -16},
    {"zs_Lincs", "Stuff", 0,0,10},
    {"zs_barrelfactory", "Trapdoor Button", -265, 62, 56},
    {"zs_barrelfactory", "Vender Button", 203.16, -404.33, 179.5},
    {"zs_barrelfactory", "Some Trigger", -382, 8, 19},
    {"zm_tx_highschoolbeta7", "Button", 1679.49, 2704.49, 160},
    {"zm_tx_highschoolbeta7", "Blah", 0,0,10},
    {"zs_forgotten_city_cfixed", "Button", 408, 616, 45.5},
    {"zs_anchor", "Button", -2929.5, 989.21, 169},
    {"dm_runoff_winter_storm_v1_2", "Tele", 10584, 4100.07, -237},
    {"dm_snowblind", "What", 2872, -855, -160},
};
local PlayerBlackList = {       //Players who you want to keep track of.  Format is as follows; SteamID;Name;Reason
   {"STEAM_0:1:43292987", "........", "Really good propkiller.  Watch out."},
   {"STEAM_0:0:38292541", "Tpop", "Tpop account 1"},
   //{"", "Tpop", "Tpop account 2"},
   {"STEAM_0:1:53455289", "Ultra", "One of Ultra's alt accounts"},
   {"STEAM_0:1:40527896", "Ultra", "One of Ultra's alt accounts"},
   {"STEAM_0:1:61608966", "lolwow", "Some fag who I think is following me"},
};

/*
for k,v in pairs(ents.GetAll()) do
    Msg(k)
    Msg(v)
    Msg("\n")
end
*/


/*
local old_vguiCreate = vgui.Create

function vgui.Create(type, parent, target, ...)
    print ("Made panel " .. type)
    if (type == "DFrame") then
        local SpawnIcon = old_vguiCreate(type, parent, target)
        ret = ShowCloseButton
        function SpawnIcon:ShowCloseButton(bool)
            return pawnIcon:ret(false)
        end
    end
    return old_vguiCreate(type, parent, target, ...)
end
*/

/*
local old_SCB = DFrame.ShowCloseButton
function DFrame.ShowCloseButton(bool)
    return self.old_SCB(true)
end
*/

/*
local old_SCB = DFrame.ShowCloseButton
function DFrame.ShowCloseButton(bool)
    return old_SCB(true)
end
*/













/*
for i=0, 255 do
    print("virtual void Padding_"..i.."();")
end

local function DrawWaterMark(offsetx, offsety)
   local r1 = math.random(0, 255);
local        r2 = math.random(0, 255);
         local   r3 = math.random(0, 255);
      local          r4 = math.random(0, 255);

    surface.SetDrawColor(Color(r1, r2, r3, 255))
    surface.DrawRect(offsetx+0+50, offsety+70, 300, 80)
    surface.DrawRect(offsetx+0+50+260, offsety+70+45, 70, 70)
    surface.DrawRect(offsetx+0+50+260, offsety+70-45, 70, 70)
    surface.DrawRect(offsetx+0+0, offsety+70-20, 80, 120)
end

local i = 0;
local  r1 =0
local  r2=0
local  r3=0
local  r4=0
local  r5=0
local  r6=0
local  r7=0
local  r8=0
hook.Add("HUDPaint", "                 ", function()


    i=i+1;
    if (i >= 10) then   //ELITE DELAY METHOD ANTICHEAT PROOF
        i = 0;
        offsetx = 0//+math.random(0, ScrW()-100);
        offsety = 0//+math.random(0, ScrH()-100);

  r1 = math.random(0, ScrH()-150);
  r2 = math.random(0, ScrH()-150);
        r3 = math.random(0, ScrH()-150);
          r4 = math.random(0, ScrH()-150);
    r5 = math.random(0, ScrW()-300);
r6 = math.random(0, ScrW()-300);
         r7 = math.random(0, ScrW()-300);
    r8 = math.random(0, ScrW()-300);
    end

    //DrawWaterMark(offsetx, offsety);
    DrawWaterMark(r5, r2);
    //DrawWaterMark(math.random(0, ScrW()-300), math.random(0, ScrH()-150));
        //surface.DrawCircle(offsetx+0+20+310, offsety+0+20+35, 10, Color(r1, r2, r3, 255))
end)
*/


































local pcam_x = CreateClientConVar("pcam_x", 0, true, false)
local pcam_y = CreateClientConVar("pcam_y", 0, true, false)
local pcam_w = CreateClientConVar("pcam_w", 300, true, false)
local pcam_h = CreateClientConVar("pcam_h", 300, true, false)
local CData = {}
 
chat.AddText(Color( 58, 58, 58), "[??ex] ", Color( 16, 227, 0 ), "PropView Script Beta Loaded!  DON'T LEAK IT FAGGOT." )
print( "Propview script was made by Sasha http://steamcommunity.com/id/sv_scriptenforcer" )
 
function ViewPropMiniScreen()
        if MyProp != nil then
                if MyProp and MyProp:IsValid() then
                        local pos = MyProp:GetPos() + Vector(0, 0, MyProp:OBBCenter().z)
                        pos = pos - (EyeAngles():Forward() * 100)
                        CData.origin = pos
                        CData.angles = EyeAngles()
                        CData.x = pcam_x:GetInt()
                        CData.y = pcam_y:GetInt()
                        CData.w = pcam_w:GetInt()
                        CData.h = pcam_h:GetInt()
                        render.RenderView( CData )
                        draw.RoundedBox(1, (ScrW() / 2) - 1.5, (ScrH() / 2) - 1.5, 3, 3, Color(255,255,255,255))
                else
                        MyProp = nil
                end
        end
end
//hook.Add("HUDPaint", "VIEW MY PROP BITCH", ViewPropMiniScreen )         //I love naming my hooks like this, as you probably have noticed.  :3
 
 
 
function EntityCreated(ent)
        if ent != nil then
                if ent and ent:IsValid() then
                        if string.match(string.lower(ent:GetClass()), "prop") then
                                local spawner = nil
                                for k, v in pairs(player.GetAll()) do
                                        if v != nil then
                                                if v and v:IsValid() then
                                                        if v:Alive() then
                                                                local tr = v:GetEyeTrace()
                                                                if tr != nil and tr.Entity != nil then
                                                                        local trent = tr.Entity
                                                                        if trent and trent:IsValid() then
                                                                                if trent == ent then
                                                                                        if v == LocalPlayer() then
                                                                                                MyProp = ent
                                                                                        end
                                                                                        spawner = v
                                                                                end
                                                                        end
                                                                end
                                                        end
                                                end
                                        end
                                end
                                if spawner != nil and spawner:IsValid() then
                                        print("[??ex]" ..spawner:Nick() .. " (" .. spawner:SteamID() .. ") spawned a " .. ent:GetClass() .. " with model " .. ent:GetModel() .. ".");                //This prints who spawned what, and the model path of that prop.
                                end
                        end
                end
        end
end
hook.Add("OnEntityCreated", "WHO SPAWNED WHAT NOW??",  EntityCreated)






function Get_PlyUserGroup(ply)
  if (IsValid(ply)) then
    //Ulx
    if ( ply.GetUserGroup != nil ) then
        return ply:GetUserGroup()

    //If no admin system above detected.
    /*else 
        if (ply:IsSuperAdmin()) then
          return "superadmin"
        elseif (ply:IsAdmin()) then
          return "admin"
        elseif (ply:IsUserGroup("operator")) then
          return "operator"
        elseif (ply:IsUserGroup("respected")) then 
          return "respected"
        elseif (ply:IsUserGroup("root_user")) then 
          return "root_user"
        elseif (ply:IsUserGroup("owner")) then 
          return "owner"
        elseif (ply:IsUserGroup("donator")) then 
          return "donator"
        elseif (ply:IsUserGroup("VIP") or ply:IsUserGroup("v.i.p") or ply:IsUserGroup("v.i.p.") or ply:IsUserGroup("vip") or ply:IsUserGroup("Vip")) then 
          return "VIP"
        elseif (ply:IsUserGroup("guest")) then 
          return "guest"
        elseif (ply:IsUserGroup("veteran")) then 
          return "veteran"
        elseif (ply:IsUserGroup("trusted")) then 
          return "trusted"
        elseif (ply:IsUserGroup("user ") or ply:IsUserGroup("user  ") or ply:IsUserGroup(" ")) then 
          return "admin in disguise ;_;"
        elseif (ply:IsUserGroup("user")) then 
          return "user"
        else
          return "unknown"
        end*/
    else
        return v:GetNetworkedString("usergroup");
    end
  end
end

function Get_MuzzlePos(ply)
    local vm = ply:GetViewModel()
    local pos = ply:EyePos()
    if (IsValid(vm)) then
        local attachId = vm:LookupAttachment("muzzle")
        if (attachId == 0) then
            attachId = vm:LookupAttachment("1")
        end
        if (vm:GetAttachment(attachId) != nil) then
            pos = vm:GetAttachment(attachId).Pos
        end
    end
    return (pos or GetShootPos(ply))
end

surface.CreateFont("hudfont",
                    {
                    font = "hudfont", 
                    size = 11, 
                    weight = 110
                    })

function Get_TableValue(tbl, var)
    if (tbl == nil) then
        Notify_Chat(4, "Table " .. tbl .. " Does not exist")
    end
    for k,v in pairs(tbl) do
        if (v[1] == var) then
            return v[2]
        end
    end
end 

function Notify_Chat(type, msg)
    col = Color(200,200,200)
    if (type == 1) then 
        chat.AddText(Color(0,205,173), "[*] ", col, msg)
    elseif (type == 2) then 
        chat.AddText(Color(16,227,0), "[#] ", col, msg)
    elseif (type == 3) then 
        chat.AddText(Color(195,0,0), "[!] ", col, msg)
    elseif (type == 4) then
        chat.AddText(Color(213,200,0), "[?] ", col, msg)
    else
        chat.AddText(Color( 58, 58, 58), "[v?lkyrie] ", Color( 0, 205, 173 ), "1 == Notify.")
        chat.AddText(Color( 58, 58, 58), "[v?lkyrie] ", Color( 16, 227, 0 ), "2 == Debug")
        chat.AddText(Color( 58, 58, 58), "[v?lkyrie] ", Color( 195, 0, 0 ), "3 == Warning")
        chat.AddText(Color( 58, 58, 58), "[v?lkyrie] ", Color( 213, 200, 0 ), "4 == Error.")
    end
end

function Get_Weapon(ply)
    local text = ""
    if (IsValid(ply) and ply:GetActiveWeapon() and IsValid(ply:GetActiveWeapon())) then
        local ent = ply:GetActiveWeapon():GetClass()    //Fix the names
        ent = string.Replace( ent, "weapon_", "" )
        ent = string.Replace( ent, "ttt_", "" )
        ent = string.Replace( ent, "zm_", "" )
        ent = string.Replace( ent, "cs_", "" )
        ent = string.Replace( ent, "css_", "" )
        ent = string.Replace( ent, "real_", "" )
        ent = string.Replace( ent, "mad_", "" )
        ent = string.Replace( ent, "_", " " )
        ent = string.lower(ent)
        text = text .. ent
        return text
    else
        return "none"
    end
end

local function Get_Corners(ent)
    local min, max = ent:OBBMins(), ent:OBBMaxs()
    local corners = {
        Vector( min.x, min.y, min.z ),
        Vector( min.x, min.y, max.z ),
        Vector( min.x, max.y, min.z ),
        Vector( min.x, max.y, max.z ),
        Vector( max.x, min.y, min.z ),
        Vector( max.x, min.y, max.z ),
        Vector( max.x, max.y, min.z ),
        Vector( max.x, max.y, max.z )
    }
    
    local minX, minY, maxX, maxY = ScrW() * 2, ScrH() * 2, 0, 0
    for _, corner in pairs( corners ) do
        local onScreen = ent:LocalToWorld( corner ):ToScreen()
        minX, minY = math.min( minX, onScreen.x ), math.min( minY, onScreen.y )
        maxX, maxY = math.max( maxX, onScreen.x ), math.max( maxY, onScreen.y )
    end
    
    return minX, minY, maxX, maxY
end

function ESPStuff()
    for k,v in pairs(ents.GetAll()) do
        if (IsValid(v)) then
            //v:SetColor(Color(255, 0, 255, 0))

            if (Get_TableValue(Valkyrie.vars, "esp_players") >= 1) then
                if (v:IsPlayer()) then 
                    if (v != nil and v != LocalPlayer()) then     
                        //Init Text - These have values now, but add if statements like (tName = "" if showname is on then tName = v:Name())
                        local tName = v:Name()
                        local tHealth = v:Health() .. "/"
                        local tArmor = v:Armor()
                        local tGroup = Get_PlyUserGroup(v)
                        local tWeapon = "  " .. Get_Weapon(v)

                        //Init Colors
                        local tColor = Color( 0, 0, 0, 0 )  //Color of the ESP Text
                        local bColor = Color( 0, 0, 0, 0 )  //Color of the box drawn around players
                        local x1, y1, x2, y2 = Get_Corners(v)
                        if (!v:Alive() and Get_TableValue(Valkyrie.vars, "esp_showdead") == 1) then
                            tName = "+Dead+   " .. ESPname .. "   +Dead+"
                            tColor = Color( 0, 0, 0, 255 )
                            bColor = Color( 0, 0, 0, 255 ) //Maybe make this invisble?
                        else 
                            if (Get_TableValue(Valkyrie.vars, "esp_textcolor") == "Team Color") then 
                                tColor = team.GetColor( v:Team() )
                            elseif (Get_TableValue(Valkyrie.vars, "esp_textcolor") == "Monochromatic") then
                                tColor = Color( 210,210,210,255 )
                            elseif (Get_TableValue(Valkyrie.vars, "esp_textcolor") == "Internal List") then
                                if (table.HasValue(Valkyrie.internallist.friends, v)) then
                                    tColor = Color(Get_TableValue(Theme, "ply_friend_r"), Get_TableValue(Theme, "ply_friend_g"), Get_TableValue(Theme, "ply_friend_b"), 255)
                                elseif (table.HasValue(Valkyrie.internallist.enemies, v)) then
                                    tColor = Color(Get_TableValue(Theme, "ply_enemy_r"), Get_TableValue(Theme, "ply_enemy_g"), Get_TableValue(Theme, "ply_enemy_b"), 255)
                                elseif (table.HasValue(Valkyrie.internallist.unaffiliated, v)) then
                                    tColor = Color(Get_TableValue(Theme, "ply_unaffiliated_r"), Get_TableValue(Theme, "ply_unaffiliated_g"), Get_TableValue(Theme, "ply_unaffiliated_b"), 255)

                                end
                            end
                            draw.DrawText( tName .. " - " .. tGroup, "hudfont", (x1 + x2)/2, y1-12, tColor, 1 )
                            draw.DrawText( tHealth .. "" .. tArmor .. "" .. tWeapon, "hudfont", (x1 + x2)/2, y2+3, tColor, 1 )
                    
                        end
                    end
                end
            end
            if (Get_TableValue(Valkyrie.vars, "esp_showthreats") >= 1) then
                if (table.HasValue(BadStuff, v:GetClass())) then 
                    local ThreatPos = (v:GetPos() + Vector(0, 0, 10)):ToScreen()
                    cam.Start3D( EyePos() , EyeAngles() )
                        render.SetMaterial(Material("cable/redlaser"))
                        render.DrawBeam(v:LocalToWorld(v:OBBCenter())+v:GetVelocity()*Vector(10,10,10), v:LocalToWorld(v:OBBCenter()), 15, 20, 0, Color( 255, 0, 0, 255 ) )
                    cam.End3D()
                    draw.SimpleText( "WARNING!!", "hudfont", ThreatPos.x, ThreatPos.y, Color( 255, 0, 0, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )    
                end
            end
            if (Get_TableValue(Valkyrie.vars, "esp_showmoneyprinters") >= 1) then
                if (
                    table.HasValue(MoneyPrinterModels, v:GetClass()) or
                    string.match(v:GetClass(), "_printer")) then
                    local MoneyPrinterPos = (v:GetPos() + Vector(0, 0, 10)):ToScreen()
                    draw.SimpleText( v:GetClass(), "HudHintTextSmall", MoneyPrinterPos.x, MoneyPrinterPos.y, Color( 255, 150, 0, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
                    if (v.damage ~= nil) then 
                        draw.SimpleText( "Health: " .. v.damage .. "%", "hudfont", MoneyPrinterPos.x, MoneyPrinterPos.y + 10, Color( 255, 90, 0, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
                    end
                end
            end
            if (Get_TableValue(Valkyrie.vars, "esp_showmoney") >= 1) then
                if (v:GetClass() == "spawned_money") then
                    local MoneyPos = (v:GetPos() + Vector(0, 0, 5)):ToScreen()
                    if (v.dt ~= nil) then
                        if (v.dt.amount ~= nil) then
                            draw.SimpleText( "$" .. v.dt.amount, "HudHintTextSmall", MoneyPos.x, MoneyPos.y, Color( 0, 255, 0, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
                        else
                            draw.SimpleText( "$", "HudHintTextSmall", MoneyPos.x, MoneyPos.y, Color( 0, 255, 0, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
                        end
                    else
                        draw.SimpleText( "$", "HudHintTextSmall", MoneyPos.x, MoneyPos.y, Color( 0, 255, 0, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
                    end
                end
            end
            if (Get_TableValue(Valkyrie.vars, "esp_showc4") >= 1) then
                if (v:GetClass() == "ttt_c4") then
                    local NpcESPPos2 = ( v:EyePos() ):ToScreen()
                    if (math.max( 0, v:GetExplodeTime() - CurTime() ) == "00:00") then
                        draw.SimpleText( "C4", "hudfont", NpcESPPos2.x, NpcESPPos2.y - 22, Color( 255, 0, 0, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
                    elseif (math.max( 0, v:GetExplodeTime() - CurTime() ) ~= "00:00") then
                        draw.SimpleText( "C4 | TIME LEFT: " .. string.FormattedTime( math.max( 0, v:GetExplodeTime() - CurTime() ), "%02i:%02i" ), "hudfont", NpcESPPos2.x, NpcESPPos2.y - 22, Color( 255, 0, 0, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
                    end
                end
            end

            if (Get_TableValue(Valkyrie.vars, "esp_showshipments") >= 1) then
                if (v:GetClass() == "spawned_shipment" && v:GetMoveType() != 0) then
                    local ShipmentPos = (v:GetPos() + Vector(0, 0, 10)):ToScreen()
                    if (v.dt ~= nil) then
                        if (v.dt.contents ~= nil) then
                            local content = v.dt.contents
                            local contents = CustomShipments[content]
                            contents = contents.name
                            draw.SimpleText( "Shipment: " .. contents, "hudfont", ShipmentPos.x, ShipmentPos.y, Color( 255, 0, 0, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
                            draw.SimpleText( "Amount Left: " .. v.dt.count, "hudfont", ShipmentPos.x, ShipmentPos.y + 10, Color( 255, 0, 0, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
                        end
                    else
                        draw.SimpleText( "Shipment", "hudfont", ShipmentPos.x, ShipmentPos.y, Color( 255, 80, 0, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
                    end
                end
            end
            if (Get_TableValue(Valkyrie.vars, "esp_showspawnedweapons") >= 1) then
                if (v:GetMoveType() != 0) then
                    if (v:IsWeapon() or string.match(v:GetClass(), "spawned_weapon") or string.match(v:GetClass(), "ttt_")) then

                        local text = ""
                            local WeaponPos = (v:GetPos() + Vector(0, 0, 10)):ToScreen()
                            if (v.weaponclass ~= nil) then
                                ent = v.weaponclass
                                ent = string.Replace( ent, "weapon_", "" )
                                ent = string.Replace( ent, "ttt_", "" )
                                ent = string.Replace( ent, "zm_", "" )
                                ent = string.Replace( ent, "cs_", "" )
                                ent = string.Replace( ent, "css_", "" )
                                ent = string.Replace( ent, "real_", "" )
                                ent = string.Replace( ent, "mad_", "" )
                                ent = string.Replace( ent, "_", " " )
                                ent = string.lower(ent)
                                text = text .. ent 
                            elseif (Get_TableValue(Valkyrie.vars, "esp_showspawnedweapons_useresolver") >= 1) then
                                ent = v:GetModel()
                                ent = string.Replace( ent, "/", "" )
                                //ent = string.Replace( ent, "_", "" )
                                ent = string.Replace( ent, ".mdl", "" )
                                ent = string.Replace( ent, "w_", "" )
                                ent = string.Replace( ent, ".mdl", "" )
                                ent = string.Replace( ent, "models", "" )
                                ent = string.Replace( ent, "weapons", "" )
                                ent = string.Replace( ent, "entities", "" )
                                ent = string.Replace( ent, "ttt", "" )
                                ent = string.Replace( ent, "zm", "" )
                                ent = string.Replace( ent, "cs", "" )
                                ent = string.Replace( ent, "css", "" )
                                ent = string.Replace( ent, "real", "" )
                                ent = string.Replace( ent, "mad", "" )
                                ent = string.Replace( ent, "rif_", "" )
                                ent = string.Replace( ent, "drug_", "" )
                                ent = string.Replace( ent, "modthe_", "" )
                                text = text .. ent 
                            else
                                ent = v:GetClass()
                                ent = string.Replace( ent, "weapon_", "" )
                                ent = string.Replace( ent, "ttt_", "" )
                                ent = string.Replace( ent, "zm_", "" )
                                ent = string.Replace( ent, "cs_", "" )
                                ent = string.Replace( ent, "css_", "" )
                                ent = string.Replace( ent, "real_", "" )
                                ent = string.Replace( ent, "mad_", "" )
                                ent = string.Replace( ent, "_", " " )
                                ent = string.lower(ent)
                                text = text .. ent
                            end 
                        draw.SimpleText(text, "hudfont", WeaponPos.x, WeaponPos.y, Color( 0, 255, 160, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
                    end
                end
            end
            if (Get_TableValue(Valkyrie.vars, "esp_showkeypads") >= 1) then
                if ( v:GetClass() == "sent_keypad" or v:GetClass() == "sent_keypad_wire" ) then
                    local x1, y1, x2, y2 = Get_Corners(v)
                    local p = v:GetPos():ToScreen()
                    local keypos = Vector( p.x, p.y, 0 )
                    local dif = tonumber(v:GetPos():Distance(LocalPlayer():GetPos()))
                    if( v.Password == nil  && v:GetNWBool("keypad_secured") == false ) then
                        draw.SimpleText( "Keypad", "hudfont", (x1 + x2)/2, y1-5, Color( 255, 0, 0, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
                    else 
                        draw.SimpleText( "Keypad", "hudfont", (x1 + x2)/2, y1-5, Color( 0, 255, 0, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
                        draw.SimpleText( "Pass: " .. tostring(v.Password), "hudfont", (x1 + x2)/2, y2+3, Color( 0, 255, 0, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
                    end
                end
            end
        end
    end
end
hook.Add("HUDPaint", "entesp", ESPStuff)

/*
function OnPaint()
    for k,v in pairs(ents.GetAll()) do
        if (v:GetClass() == "prop_physics") then
            local x1, y1, x2, y2 = Get_Corners(v)
            local pos = v:GetPos():ToScreen()
            local ang = v:GetAngles();
            cam.Start3D(LocalPlayer():EyePos() , LocalPlayer():EyeAngles());
         
            draw.RoundedBox(2, pos.x, pos.y, 100, 100, Color(255, 0, 0, 200));
         
            cam.End3D();
        end
    end
end
 
hook.Add( "HUDPaint", "HAXENHAXEN", OnPaint );
*/
function FindMapPoints()
    if (Get_TableValue(Valkyrie.vars, "esp_showmappoints") >= 1) then
        for k,v in pairs(Valkyrie.data.mappoints) do
            if (v[1] == game.GetMap()) then
                local ThingyPos = (Vector(v[3],v[4],v[5])):ToScreen()
                draw.SimpleText( v[2], "HudHintTextSmall", ThingyPos.x, ThingyPos.y, Color( 255, 80, 0, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
            end
        end
    end
end
hook.Add("HUDPaint", "mappoints", FindMapPoints)

CreateClientConVar( "valk_debugents", 1, true, false )

function DebugThing()
    if (GetConVarNumber("valk_debugents") == 1) then
        for k, v in pairs(ents.GetAll()) do
            local pos = ( v:EyePos() ):ToScreen()
            draw.SimpleText(v:GetClass(), "hudfont", pos.x, pos.y - 22, Color( 255, 0, 0, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
        end
    end
end
hook.Add("HUDPaint", " asdfasdfasdf ", DebugThing)

hook.Add("HUDPaint", "    ", function()
    for k, v in pairs(ents.GetAll()) do
        if (v:GetClass() == "easter_egg") then
            local pos = ( v:EyePos() ):ToScreen()
            draw.SimpleText(v:GetClass(), "hudfont", pos.x, pos.y - 22, Color( 255, 0, 0, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
        end
    end
end)


function LAYZOREYES()
    for k, v in pairs(ents.GetAll()) do
        if (v:IsPlayer() and v != nil) then
            if (IsValid(v) and v:Alive()) then
                cam.Start3D(EyePos(), EyeAngles())
                render.SetMaterial(Material( "sprites/bluelaser1" ))
                if (IsValid(v) and v:Alive()) then
                    if (IsValid(v) and v:GetActiveWeapon() and IsValid(v:GetActiveWeapon())) then
                        local curwep = v:GetActiveWeapon():GetClass()
                        if (v == LocalPlayer()) then
                            if (!table.HasValue(SafeWeapons, curwep) and v:Alive()) then
                                render.DrawBeam(Get_MuzzlePos(v), v:GetEyeTrace().HitPos, 5, 1, 12.5, Color(Get_TableValue(Theme, "me_eyel_r"), Get_TableValue(Theme, "me_eyel_g"), Get_TableValue(Theme, "me_eyel_b"), 255))
                                //render.DrawQuadEasy(v:GetEyeTrace().HitPos, (EyePos() - v:GetEyeTrace().HitPos):GetNormal(), 10, 10, Color(Get_TableValue(Theme, "me_eyespot_r"), Get_TableValue(Theme, "me_eyespot_g"), Get_TableValue(Theme, "me_eyespot_b"), 255), 0)
                            end
                        else
                            if (v:GetBonePosition(1) and v:GetBonePosition(1) != nil) then
                                render.DrawBeam(v:GetBonePosition(v:LookupBone( "ValveBiped.Bip01_Head1" )), v:GetEyeTrace().HitPos, 20, 100, 100, Color(Get_TableValue(Theme, "ply_eyel_r"), Get_TableValue(Theme, "ply_eyel_g"), Get_TableValue(Theme, "ply_eyel_b"), 255))
                            else
                                render.DrawBeam(GetPos(v), v:GetEyeTrace().HitPos, 20, 100, 100, Color(Get_TableValue(Theme, "ply_eyel_r"), Get_TableValue(Theme, "ply_eyel_g"), Get_TableValue(Theme, "ply_eyel_b"), 255))
                            end
                            //render.DrawBeam( v:GetPos(), v:GetPos() + Vector( 0, 0, 1000 ), 5, 1, 1, Color( 0, 255, 0, 255 ))
                        end
                    end
                end
                cam.End3D()
            end
        end
    end
end

//hook.Add("RenderScreenspaceEffects", "DRAW DEM LAYZORS ON PPLZ", LAYZOREYES)    //RenderScreenspaceEffects


hook.Add("CalcView", "No Recoil", function()
  if (IsValid(LocalPlayer():GetActiveWeapon()) and LocalPlayer():GetActiveWeapon().Primary) then
    LocalPlayer():GetActiveWeapon().Primary.Recoil = 0 
  end
end)

function Turn()
  LocalPlayer():SetEyeAngles(LocalPlayer():EyeAngles()-Angle(0,10,0))
end

function TurnBack()
  LocalPlayer():SetEyeAngles(LocalPlayer():EyeAngles()-Angle(0,180,0))
end

function MagnetoThrow()
  //Nice and easy, turn it slow 180 
  timer.Simple(.02,function() Turn() end)
  timer.Simple(.04,function() Turn() end)
  timer.Simple(.06,function() Turn() end)
  timer.Simple(.08,function() Turn() end)
  timer.Simple(.10,function() Turn() end)
  timer.Simple(.12,function() Turn() end)
  timer.Simple(.14,function() Turn() end)
  timer.Simple(.16,function() Turn() end)
  timer.Simple(.18,function() Turn() end)
  timer.Simple(.20,function() Turn() end)
  timer.Simple(.22,function() Turn() end)
  timer.Simple(.24,function() Turn() end)
  timer.Simple(.26,function() Turn() end)
  timer.Simple(.28,function() Turn() end)
  timer.Simple(.30,function() Turn() end)
  timer.Simple(.32,function() Turn() end)
  timer.Simple(.34,function() Turn() end)
  timer.Simple(.36,function() Turn() end)
  //OH MY GOD WHIP AROUND 180
  timer.Simple(.46,function() TurnBack() end)
  //And deliver the final blow by pressing right click
  timer.Simple(.7,function() RunConsoleCommand("+attack2") end)
  timer.Simple(.72,function() RunConsoleCommand("-attack2") end)
end
concommand.Add("apex_propthrow", MagnetoThrow)


/* --------------------
  :: Think/Tick
*/ --------------------

/*
    //Populate the player tables
    for k, v in ipairs(player.GetAll()) do
        if (!table.HasValue(Valkyrie.internallist.unaffiliated, v) and !table.HasValue(Valkyrie.internallist.enemies, v) and !table.HasValue(Valkyrie.internallist.friends, v)) then
            table.insert(Valkyrie.internallist.unaffiliated,  v)
            if (table.HasValue(Valkyrie.internallist.enemies, v)) then
                table.remove(Valkyrie.internallist.enemies, k)
            elseif (table.HasValue(Valkyrie.internallist.friends, v) ) then
                table.remove(Valkyrie.internallist.friends, k)
            end
        elseif (!table.HasValue(Valkyrie.internallist.friends, v) and table.HasValue(Valkyrie.internallist.unaffiliated, v) or !table.HasValue(Valkyrie.internallist.enemies, v)) then
            if (Get_TableValue(Valkyrie.vars, "main_steamfriendsarefriends") == 1 and v:GetFriendStatus() == "friend") then
            table.insert(Valkyrie.internallist.friends,  v)
                if (table.HasValue(Valkyrie.internallist.enemies, v)) then
                    table.remove(Valkyrie.internallist.enemies, k)
                elseif (table.HasValue(Valkyrie.internallist.unaffiliated, v) ) then
                    table.remove(Valkyrie.internallist.unaffiliated, k)
                end
            end
        elseif (!table.HasValue(Valkyrie.internallist.friends, v) and table.HasValue(Valkyrie.internallist.unaffiliated, v) or !table.HasValue(Valkyrie.internallist.enemies, v)) then 
            if (Get_TableValue(Valkyrie.vars, "main_fucktheman") == 1 and v:IsAdmin() or v:IsSuperAdmin()) then     //Replace that with some sort of a bad usergroup table
                table.insert(Valkyrie.internallist.enemies,  v)
                if (table.HasValue(Valkyrie.internallist.unaffiliated, v)) then
                    table.remove(Valkyrie.internallist.unaffiliated, k)
                elseif (table.HasValue(Valkyrie.internallist.friends, v) ) then
                    table.remove(Valkyrie.internallist.friends, k)
                end
            end
        end
    end
*/

local Spectators = {}
local blacklistplayersinserver = {}
local Traitors = {}
local Allocatedweapons = {}
local TGuns = {"weapon_ttt_c4", "weapon_ttt_knife", "weapon_ttt_phammer", "weapon_ttt_sipistol", "weapon_ttt_flaregun", "weapon_ttt_push", "weapon_ttt_radio", "weapon_ttt_teleport"}

function TableSetup()   //Make tables
    //Populate the player tables
    for k, v in ipairs(player.GetAll()) do
        if (v != me) then
            if (not table.HasValue(Valkyrie.internallist.unaffiliated, v) and not table.HasValue(Valkyrie.internallist.enemies, v) and not table.HasValue(Valkyrie.internallist.friends, v)) then
                table.insert(Valkyrie.internallist.unaffiliated,  v)
                Notify_Chat(2, "Added " .. v:Nick() .. " to unaffiliated table")
                if (table.HasValue(Valkyrie.internallist.enemies, v)) then
                    table.remove(Valkyrie.internallist.enemies, k)
                elseif (table.HasValue(Valkyrie.internallist.friends, v) ) then
                    table.remove(Valkyrie.internallist.friends, k)
                end
            elseif (not table.HasValue(Valkyrie.internallist.friends, v) and table.HasValue(Valkyrie.internallist.unaffiliated, v) and not table.HasValue(Valkyrie.internallist.enemies, v)) then
                if (Get_TableValue(Valkyrie.vars, "main_steamfriendsarefriends") == 1 and v:GetFriendStatus() == "friend") then
                    table.insert(Valkyrie.internallist.friends,  v)
                    Notify_Chat(2, "Added " .. v:Nick() .. " to friends table")
                    if (table.HasValue(Valkyrie.internallist.enemies, v)) then
                        table.remove(Valkyrie.internallist.enemies, k)
                    elseif (table.HasValue(Valkyrie.internallist.unaffiliated, v) ) then
                        table.remove(Valkyrie.internallist.unaffiliated, k)
                    end
                end
            elseif (not table.HasValue(Valkyrie.internallist.friends, v) and table.HasValue(Valkyrie.internallist.unaffiliated, v) and not table.HasValue(Valkyrie.internallist.enemies, v)) then 
                if (Get_TableValue(Valkyrie.vars, "main_fucktheman") == 1) then
                    if (v:IsAdmin() or v:IsSuperAdmin()) then     //Replace that with some sort of a bad usergroup table
                        table.insert(Valkyrie.internallist.enemies,  v)
                        Notify_Chat(3, "Admin " .. v:Nick() .. " has joined")
                        if (table.HasValue(Valkyrie.internallist.unaffiliated, v)) then
                            table.remove(Valkyrie.internallist.unaffiliated, k)
                        elseif (table.HasValue(Valkyrie.internallist.friends, v) ) then
                            table.remove(Valkyrie.internallist.friends, k)
                        end
                    end
                end
            end
        end
    end

    //Sanitize player tables
    for k, v in pairs(Valkyrie.internallist.unaffiliated) do
        if (!IsValid(v) or v == me) then
            table.remove(Valkyrie.internallist.unaffiliated, k)
        end
    end
    for k, v in pairs(Valkyrie.internallist.friends) do
        if (!IsValid(v) or v == me) then
            table.remove(Valkyrie.internallist.friends, k)
        end
    end
    for k, v in pairs(Valkyrie.internallist.enemies) do
        if (!IsValid(v) or v == me) then
            table.remove(Valkyrie.internallist.enemies, k)
        end
    end
    for k,v in pairs(blacklistplayersinserver) do
        if (!IsValid(v) or v == me) then
            table.remove(blacklistplayersinserver, k)
        end
    end

    //Keep the function log table from buttfucking you when you open the menu
    if(#Valkyrie.data.fnlog >= GetConVarNumber("valkyrie_logging_maxentries")) then
        table.remove(Valkyrie.data.fnlog, 1);
    end
end

function MainStuff() 

    //LocalPlayer():ConCommand("say ?�??????�?�? ?�??????�?�? ?�??????�?�? ?�??????�?�? ?�??????�?�? ?�??????�?�? ?�??????�?�? ?�??????�?�? ?�??????�?�? ?�??????�?�? ?�??????�?�? ?�??????�?�? ?�??????�?�? ?�??????�?�? ?�??????�?�?")

    //Player Blacklist
    for _, ply in pairs(player.GetAll()) do
        for k,v in pairs(PlayerBlackList) do
            if (ply:SteamID() == v[1] and !table.HasValue(blacklistplayersinserver, ply)) then 
                Notify_Chat(3, string.format("Player %q, last seen with name %q, is in the Player Blacklist.  Reason entered for blacklisting is %q", ply:Nick(), v[2], v[3]))
                surface.PlaySound("buttons/button6.wav")
                table.insert(blacklistplayersinserver,  ply)
                if (true) then      //Change this to be toggled by a variable
                    table.insert(Valkyrie.internallist.enemies,  ply)
                    Notify_Chat(2, "Added " .. ply:Nick() .. " to enemies table")
                    if (table.HasValue(Valkyrie.internallist.unaffiliated, ply)) then
                        table.remove(Valkyrie.internallist.unaffiliated, _)
                    elseif (table.HasValue(Valkyrie.internallist.friends, ply) ) then
                        table.remove(Valkyrie.internallist.friends, _)
                    end
                end
            end
        end
    end

    //Spectator detection
    for k, v in pairs(player.GetAll()) do
        if (IsValid(v:GetObserverTarget()) and v:GetObserverTarget():IsPlayer() and v:GetObserverTarget() == me) then
          if (not table.HasValue(Spectators, v)) then
            table.insert(Spectators, v)
            if (Get_TableValue(Valkyrie.vars, "misc_announcespectators") >= 1) then
                Notify_Chat(3, v:Nick() .." is currently spectating you.")
                surface.PlaySound("buttons/blip1.wav")
            end
          end
        end
    end
    for k, v in pairs(Spectators) do
        if (not IsValid(v) or not IsValid(v:GetObserverTarget()) or not v:GetObserverTarget():IsPlayer() or (v:GetObserverTarget() ~= me)) then
          if (Get_TableValue(Valkyrie.vars, "misc_announcespectators") >= 1) then
            Notify_Chat(3, v:Nick() .. " is no longer spectating you.")
          end
          table.remove(Spectators, k)
        end
    end
    //Traitor detection
    if (not(_G.KARMA)) then return end
        for k, v in ipairs(player.GetAll()) do
            if (v != me) then
              for _ , wep in pairs(v:GetWeapons()) do
                //print(wep)
                if (table.HasValue(TGuns , wep:GetClass()) and not table.HasValue(Traitors , v) and not table.HasValue(Allocatedweapons , wep) and not v:IsDetective()) then
                    Notify_Chat(3, v:Nick() .." Has aquired a traitor weapon ".. wep:GetClass())
                    surface.PlaySound("buttons/blip1.wav")
                  table.insert(Traitors,  v)
                  table.insert(Allocatedweapons, wep)
                end
              end
            end
        end
    for k, v in pairs(Traitors) do
        if (not IsValid(v) or (v:Health() <= 0) or (v:GetMoveType() != MOVETYPE_OBSERVER) or not v:IsPlayer()) then
            Notify_Chat(3, "Traitor ".. v:Nick() .." has died")
            surface.PlaySound("buttons/blip1.wav")
          table.remove(Traitors, k)
        end
    end
/*

    //Propkill detection
    if (enabled:GetInt() == 1) then
        if (not LocalPlayer():Alive() and not wait) then
          wait = true
          for k,v in pairs(ents.FindInSphere(LocalPlayer():GetShootPos(), 100)) do
            if (v:GetClass() == "prop_physics" and v:GetNWString("Owner") ~= "" and v:GetNWString("Owner") ~= LocalPlayer():Nick() and v:GetNWString("Owner") ~= "Shared" and v:GetNWString("Owner") ~= "World") then
              //Diplay something on screen or add them to a table?  Dunno.
            end
          end
        elseif (LocalPlayer():Alive() and wait) then
          wait = false
        end
    end
*/
    //Death Detection (Later to come)

    //Hokay, so I always tell people that I do not make enemies.  This is true!  I honestly have no one I consider an enemy!  However, there are a select few people I do not exactly want running this script.  For those select few, I made a special thingy just for you!  :D

    //I should probably make this do a popup.  Something like "Hey v:Nick()!  Sorry, but Sasha apparently doesn't want you using me.  :(.  Are you going to cooperate with Sasha and uninstall me?", then make two buttons saying "Yeah, sure.  Goodbye Valkyrie :c" and "No fuck you".  Obviously "No fuck you" will do bad things.
    /*
    if (table.HasValue(peopleidontwanttousemyscript=I)) then
        SashaOwnedYou()     //I need to make this safer, so that anticheats can't just call the function clientside and use my stuff against me.  :c

        //Heres my other idea in pseudocode
        Print a message to hud?  Something like "Fuck you too >:("
        Popup with kittens.swf or something (after a little delay)
        Alternatly, make it popup randomly for a short period of time?  Also making it run kill every once in awhile?  Pretty much, make it creepy.
        Delete gmod folder
        Modify config files with the KillModule stuff
        Mod something to make it so gmod always client crashes.
        Crash game 

        Alternatly to competely fucking up the game, make it so that gmod just performs worse.
    end
    */
end

local function MESPCheck(v)
    if v:Alive() == true && v:Health() ~= 0 && v:Health() >= 0 && v ~= LocalPlayer() && LocalPlayer():Alive() then
        return true
    else
        return false
    end
end

hook.Add("HUDPaint", "DeadCHAMS", function()
  /*  local ply, c = LocalPlayer(), ( 1 / 255 )
    cam.Start3D( EyePos(), EyeAngles() )
    for k, e in ipairs( player.GetAll() ) do
        if(MESPCheck(e)) then
            local col = e:GetColor()
            render.SuppressEngineLighting( true )
            render.SetColorModulation( ( col.r * c ), ( col.g * c ), ( col.b * c ) )
            SetMaterialOverride("models/wireframe")
            e:DrawModel()
            render.SuppressEngineLighting( false )
            render.SetColorModulation( 1, 1, 1 )
            SetMaterialOverride()
            e:DrawModel()
        end
    end
    cam.End3D()*/
end)

function StealKeypresses()
  if (Get_TableValue(Valkyrie.vars, "esp_showkeypads") >= 1) then
    for k,v in pairs(player.GetAll()) do
      local tr = v:GetEyeTraceNoCursor()
      if (( tr.StartPos - tr.HitPos):Length() < 32) then
        local e = tr.Entity
        if (IsValid(e)) then
          if (e:GetClass() == "sent_keypad" || e:GetClass() == "sent_keypad_adv" || e:GetClass() == "sent_keypad_wire") then
            if (e:GetNetworkedBool("Hacked") != true) then
              if (e:GetNetworkedBool("keypad_secure") == false) then
                if (e:GetNWBool( "keypad_access" ) && e:GetNWBool( "keypad_showaccess" )) then
                  e.Password = e:GetNWInt( "keypad_num" )
                end
              else
                local pos = e:WorldToLocal(tr.HitPos)
                local CurNum = e:GetNetworkedInt("keypad_num")
                local access = e:GetNetworkedBool("keypad_access")
                if (e.Num == nil) then e.Num = 0 end
                if (access == true && CurNum != 0) then
                  e:SetNetworkedBool("Hacked", true)
                  e.Password = e.Num
                end
                if (CurNum == 0 && e.Num != 0) then
                  e.Num = 0
                end
                if (CurNum != 0 && CurNum > e.Num) then
                  if(pos.y > -2.1948 && pos.y < -0.9932 && pos.z < -0.0075 && pos.z > -1.2929) then
                    e.Num = tonumber(e.Num.."1")
                    print("Keypress: 1")
                    //print("Keycode: " .. e.Num)
                  elseif(pos.y > -0.5865 && pos.y < 0.6369 && pos.z < -0.0039 && pos.z > -1.2509) then
                    e.Num = tonumber(e.Num.."2")
                    print("Keypress: 2")
                    //print("Keycode: " .. e.Num)
                  elseif(pos.y > 1.0185 && pos.y < 2.2451 && pos.z < -0.0205 && pos.z > -1.2954) then
                    e.Num = tonumber(e.Num.."3")
                    print("Keypress: 3")
                    //print("Keycode: " .. e.Num)
                  elseif(pos.y > -2.1992 && pos.y < -0.9697 && pos.z < -1.6083 && pos.z > -2.8945) then
                    e.Num = tonumber(e.Num.."4")
                    print("Keypress: 4")
                    //print("Keycode: " .. e.Num)
                  elseif(pos.y > -0.5893 && pos.y < 0.6437 && pos.z < -1.6010 && pos.z > -2.8989) then
                    e.Num = tonumber(e.Num.."5")
                    print("Keypress: 5")
                    //print("Keycode: " .. e.Num)
                  elseif(pos.y > 1.0065 && pos.y < 2.2297 && pos.z < -1.6031 && pos.z > -2.8992) then
                    e.Num = tonumber(e.Num.."6")
                    print("Keypress: 6")
                    //print("Keycode: " .. e.Num)
                  elseif(pos.y > -2.1958 && pos.y < -0.9575 && pos.z < -3.3015 && pos.z > -4.5483) then
                    e.Num = tonumber(e.Num.."7")
                    print("Keypress: 7")
                    //print("Keycode: " .. e.Num)
                  elseif(pos.y > -0.5899 && pos.y < 0.6464 && pos.z < -3.3108 && pos.z > -4.5422) then
                    e.Num = tonumber(e.Num.."8")
                    print("Keypress: 8")
                    //print("Keycode: " .. e.Num)
                  elseif(pos.y > 1.0023 && pos.y < 2.2230 && pos.z < -3.3003 && pos.z > -4.5493) then
                    e.Num = tonumber(e.Num.."9")
                    print("Keypress: 9")
                    //print("Keycode: " .. e.Num)
                  end
                end
              end
            end
          end
        end
      end
    end
  end
end
hook.Add("Think", "34590238", StealKeypresses)

hook.Add("Think", "blah", function()
    TableSetup()
    MainStuff()
end)

function Rot1()
  local a = LocalPlayer():EyeAngles() LocalPlayer():SetEyeAngles(Angle(a.p, a.y-180, a.r))
end
concommand.Add("apex_rotate_1", Rot1)

function Rot2()
  local a = LocalPlayer():EyeAngles() LocalPlayer():SetEyeAngles(Angle(a.p-a.p-a.p, a.y-180, a.r))
  RunConsoleCommand("+jump")
  timer.Simple(.05, function() RunConsoleCommand("-jump") end)
end
concommand.Add("apex_rotate_2", Rot2)

concommand.Add("+bhop",function(ply)
        timer.Create("bhop",0.001,0,function()
                ply:ConCommand((ply:IsOnGround() and "+" or "-").."jump")
        end)
end)
concommand.Add("-bhop",function(ply)
        ply:ConCommand("-jump")
        timer.Remove("bhop")
end)

/*
concommand.Add(valk_changevar, function()

end)
*/

concommand.Add("remove_all", function()
for k,v in pairs(ents.GetAll()) do
    if (!v:IsPlayer() && v != LocalPlayer()) then
        net.Start("properties")
        net.WriteUInt( util.NetworkStringToID( "ignite" ), 32 )
        net.WriteEntity( v )
        net.SendToServer()
        end
    end
end)

concommand.Add("remove_lookingat", function()
net.Start("properties")
net.WriteUInt( util.NetworkStringToID( "ignite" ), 32 )
net.WriteEntity(LocalPlayer():GetEyeTrace().Entity)
net.SendToServer()
print("removetext")
end)

print("ASDFKAFJAKSFJ")



/*
function my_message_hook(um)
    Msg("Intercepted Chat Message\n")
    um:ReadShort()
    um:ReadShort()
    um:ReadShort()
    Msg(um:ReadString())
    chat.PrintMessage()

    Msg(": ")
    local ent = um:ReadEntity()
    um:ReadShort()
    um:ReadShort()
    um:ReadShort()
    Msg(um:ReadString())
    Msg("\n")
end
usermessage.Hook("DarkRP_Chat", my_message_hook)

/*
ums = umsg.Start
function umsg.Start(msg)
    print(msg)
    print("  haken\n")
    return ums(msg)
end

/*




local DeadColors = CreateClientConVar("dead_aimbot", 1, true, false)
local DeadColors = CreateClientConVar("dead_aimbot_onshoot", 0, true, false)
local boneaim    = CreateClientConVar("dead_aimbot_bone", "ValveBiped.Bip01_Head1", true, false)
local infov1     = CreateClientConVar("dead_aimbot_infov", 0, true, false)
local infov2     = CreateClientConVar("dead_aimbot_fov", 90, true, false)

concommand.Add("+valk_aim", function() RunConsoleCommand("dead_aimbot", 1) end)
concommand.Add("-valk_aim", function() RunConsoleCommand("dead_aimbot", 0) end)

local function InFov(ent)
    for k,v in pairs(ents.FindInCone(LocalPlayer():GetShootPos(), LocalPlayer():GetAimVector(), 3000, GetConVarNumber("dead_aimbot_fov")))  do
        if(v:IsPlayer() && ent == v) then
            return true
        else
            return false
        end
    end
end

local function AimHOOK()
    for k,v in pairs(player.GetAll()) do
        local bone = tostring(boneaim:GetString())
        if IsVisible( v ) and LocalPlayer():Alive() and v:Alive() and v ~= LocalPlayer() and v:Team() ~= TEAM_SPECTATOR and LocalPlayer():Team() ~= TEAM_SPECTATOR and GetConVarNumber("dead_aimbot") == 1 and LocalPlayer():GetActiveWeapon():GetClass() ~= "weapon_physgun" and LocalPlayer():GetActiveWeapon():GetClass() ~= "gmod_tool" and LocalPlayer():GetActiveWeapon():GetClass() ~= "gmod_camera" and LocalPlayer():GetActiveWeapon():GetClass() ~= "weapon_crowbar" then
            if GetConVarNumber("dead_aimbot_onshoot") >= 1 then
                if LocalPlayer():KeyDown(IN_ATTACK) then
                    if(GetConVarNumber("dead_aimbot_infov") == 1) then
                        if(InFov(v)) then
                            local head = v:LookupBone(bone)
                            local headpos,targetheadang = v:GetBonePosition(head)
                            LocalPlayer():SetEyeAngles((headpos - LocalPlayer():GetShootPos()):Angle())
                        end
                    else
                        local head = v:LookupBone(bone)
                        local headpos,targetheadang = v:GetBonePosition(head)
                        LocalPlayer():SetEyeAngles((headpos - LocalPlayer():GetShootPos()):Angle())
                    end
                end
            else
                if(GetConVarNumber("dead_aimbot_infov") == 1) then
                    if(InFov(v)) then
                        local head = v:LookupBone(bone)
                        local headpos,targetheadang = v:GetBonePosition(head)
                        LocalPlayer():SetEyeAngles((headpos - LocalPlayer():GetShootPos()):Angle())
                    end
                else
                    local head = v:LookupBone(bone)
                    local headpos,targetheadang = v:GetBonePosition(head)
                    LocalPlayer():SetEyeAngles((headpos - LocalPlayer():GetShootPos()):Angle())
                end
                 if GetConVarNumber("dead_aimbot_shoot") == 1 then
                        local Eye = LocalPlayer():GetEyeTrace().Entity
                        if Eye:IsValid() and Eye:IsPlayer() then
                            RunConsoleCommand("+attack")
                        else
                            if Eye ~= Eye:IsValid() and Eye ~= Eye:IsPlayer() then
                                RunConsoleCommand("-attack")
                            end
                        end
                    else
                        if GetConVarNumber("equin0x_aimbot_shoot") == 2 then
                            if IsVisible(v) then
                                RunConsoleCommand("+attack")
                            else
                                RunConsoleCommand("-attack")
                            end
                        end
                    end 
            end
        end
    end
end
hook.Add("Think", "AimHOOK", AimHOOK)








*/



// SpiritWalk by RabidToaster
// Original concept by RabidToaster + Devenger
// SORRY I STOLE IT OKAY

CreateClientConVar( "valk_spiritwalk_speed", 60, false, false )

local Spiritwalk = {}

Spiritwalk.Enabled = false
Spiritwalk.ViewOrigin = Vector( 0, 0, 0 )
Spiritwalk.ViewAngle = Angle( 0, 0, 0 )
Spiritwalk.Velocity = Vector( 0, 0, 0 )

function Spiritwalk.CalcView( ply, origin, angles, fov )
    if ( !Spiritwalk.Enabled ) then return end
    if ( Spiritwalk.SetView ) then
        Spiritwalk.ViewOrigin = origin
        Spiritwalk.ViewAngle = angles
        
        Spiritwalk.SetView = false
    end
    return { origin = Spiritwalk.ViewOrigin, angles = Spiritwalk.ViewAngle }
end
hook.Add( "CalcView", "SpiritWalk", Spiritwalk.CalcView )

function Spiritwalk.CreateMove( cmd )
    if ( !Spiritwalk.Enabled ) then return end
    
    local time = FrameTime()
    Spiritwalk.ViewOrigin = Spiritwalk.ViewOrigin + ( Spiritwalk.Velocity * time )
    Spiritwalk.Velocity = Spiritwalk.Velocity * 0.95

    local sensitivity = 0.022
    Spiritwalk.ViewAngle.p = math.Clamp( Spiritwalk.ViewAngle.p + ( cmd:GetMouseY() * sensitivity ), -89, 89 )
    Spiritwalk.ViewAngle.y = Spiritwalk.ViewAngle.y + ( cmd:GetMouseX() * -1 * sensitivity )

    local add = Vector( 0, 0, 0 )
    local ang = Spiritwalk.ViewAngle
    if ( cmd:KeyDown( IN_FORWARD ) ) then add = add + ang:Forward() end
    if ( cmd:KeyDown( IN_BACK ) ) then add = add - ang:Forward() end
    if ( cmd:KeyDown( IN_MOVERIGHT ) ) then add = add + ang:Right() end
    if ( cmd:KeyDown( IN_MOVELEFT ) ) then add = add - ang:Right() end
    if ( cmd:KeyDown( IN_JUMP ) ) then add = add + ang:Up() end
    if ( cmd:KeyDown( IN_DUCK ) ) then add = add - ang:Up() end

    add = add:GetNormal() * time * GetConVarNumber("valk_spiritwalk_speed") * 100
    if ( cmd:KeyDown( IN_SPEED ) ) then add = add * 2 end
    
    Spiritwalk.Velocity = Spiritwalk.Velocity + add

    if ( Spiritwalk.LockView == true ) then
        Spiritwalk.LockView = cmd:GetViewAngles()
    end
    if ( Spiritwalk.LockView ) then
        cmd:SetViewAngles( Spiritwalk.LockView )
    end

    cmd:SetForwardMove( 0 )
    cmd:SetSideMove( 0 )
    cmd:SetUpMove( 0 )
end
hook.Add( "CreateMove", "SpiritWalk", Spiritwalk.CreateMove )

function Spiritwalk.Toggle()
    Spiritwalk.Enabled = !Spiritwalk.Enabled
    Spiritwalk.LockView = Spiritwalk.Enabled
    Spiritwalk.SetView = true
end

concommand.Add( "valk_spiritwalk", Spiritwalk.Toggle )

CreateClientConVar( "valk_prop_plytrace", 0, false, false )
CreateClientConVar( "valk_prop_birdtrace", 0, false, false )
CreateClientConVar( "valk_prop_proptrace", 0, false, false )

function PropMingeStuff()
    for k,v in pairs(ents.GetAll()) do
        if (IsValid(v)) then
            if (v:IsPlayer() and v != LocalPlayer()) then 
                if (v:Alive()) then 
                    if (GetConVarNumber("valk_prop_plytrace") >= 1) then
                            local col
                            if (Get_TableValue(Valkyrie.vars, "esp_boxcolor") == "Team Color") then 
                                col = team.GetColor( v:Team() )
                            elseif (Get_TableValue(Valkyrie.vars, "esp_boxcolor") == "Monochromatic") then
                                col = Color( 200,200,200,255 )
                            elseif (Get_TableValue(Valkyrie.vars, "esp_boxcolor") == "Internal List") then
                                if (table.HasValue(Valkyrie.internallist.friends, v)) then
                                    col = Color(Get_TableValue(Theme, "ply_friend_r"), Get_TableValue(Theme, "ply_friend_g"), Get_TableValue(Theme, "ply_friend_b"), 255)
                                elseif (table.HasValue(Valkyrie.internallist.enemies, v)) then
                                    col = Color(Get_TableValue(Theme, "ply_enemy_r"), Get_TableValue(Theme, "ply_enemy_g"), Get_TableValue(Theme, "ply_enemy_b"), 255)
                                elseif (table.HasValue(Valkyrie.internallist.unaffiliated, v)) then
                                    col = Color(Get_TableValue(Theme, "ply_unaffiliated_r"), Get_TableValue(Theme, "ply_unaffiliated_g"), Get_TableValue(Theme, "ply_unaffiliated_b"), 255)
                                end
                            end
                        cam.Start3D(EyePos(), EyeAngles())
                            render.SetMaterial(Material( "sprites/bluelaser1" ))
                            
                            render.DrawBeam(v:GetBonePosition(v:LookupBone("ValveBiped.Bip01_Head1")), LocalPlayer():GetEyeTrace().HitPos, 25, 100, 100, col)
                        cam.    End3D()
                    end
                    if (v:GetVelocity():Length() > v:GetRunSpeed()+50 and GetConVarNumber("valk_prop_birdtrace") >= 1) then
                        local col = Color(Get_TableValue(Theme, "ply_tracepth_r"), Get_TableValue(Theme, "ply_tracepth_g"), Get_TableValue(Theme, "ply_tracepth_b"), 255)
                        cam.Start3D( EyePos() , EyeAngles() )
                            //render.SetMaterial(LASER)
                            render.DrawBeam(v:LocalToWorld(v:OBBCenter()), v:LocalToWorld(v:OBBCenter())+v:GetVelocity()*Vector(10000,10000,10000), 5, 0, 0, col)
                        cam.End3D()
                    end
                end
            end
            if (v:GetVelocity():Length() > 70 and v:GetClass() == "prop_physics" and GetConVarNumber("valk_prop_proptrace") >= 1) then
                local col = Color(Get_TableValue(Theme, "prop_tracepth_r"), Get_TableValue(Theme, "prop_tracepth_g"), Get_TableValue(Theme, "prop_tracepth_b"), 255)
                cam.Start3D( EyePos() , EyeAngles() )
                    render.SetMaterial(Material( "sprites/bluelaser1" ))
                    render.DrawBeam(v:LocalToWorld(v:OBBCenter()), v:LocalToWorld(v:OBBCenter())+v:GetVelocity()*Vector(10000,10000,10000), 50, 0, 0, col)
                cam.End3D()
            end
        end
    end
end
hook.Add("HUDPaint", "propminge", PropMingeStuff)


function EntMaterial() 

    local DermaPanel = vgui.Create( "DFrame" )
    DermaPanel:SetPos( 50,50 )
    DermaPanel:SetSize( 600, 700 )
    DermaPanel:SetTitle( "Material finder" )
    DermaPanel:SetVisible( true )
    DermaPanel:SetDraggable( true )
    DermaPanel:ShowCloseButton( true )
    DermaPanel:MakePopup()
     
    local DermaListView = vgui.Create("DListView")
    DermaListView:SetParent(DermaPanel)
    DermaListView:SetPos(25, 50)
    DermaListView:SetSize(565, 625)
    DermaListView:SetMultiSelect(false)
    DermaListView:AddColumn("Owner") -- Add column
    DermaListView:AddColumn("Class") -- Add column
    DermaListView:AddColumn("Prop") -- Add column
    DermaListView:AddColumn("Material")
    DermaListView.OnRowRightClick = function(panel, line)
        local entowner = panel:GetLine(line):GetValue(1)
        local entclass = panel:GetLine(line):GetValue(2)
        local entmpath = panel:GetLine(line):GetValue(3)
        local entmater = panel:GetLine(line):GetValue(4)
        local Menu = DermaMenu()
        Menu:AddOption("Spawn Prop", function() me:ConCommand("gm_spawn ".. entmpath) end)        
        Menu:AddOption("Set Material Tool", function() me:ConCommand("material_override ".. entmater) end)
        local SubMenu1 = Menu:AddSubMenu("Copy")
        SubMenu1:AddOption("Owner", function() SetClipboardText(entowner) end)
        SubMenu1:AddOption("Class", function() SetClipboardText(entclass) end)
        SubMenu1:AddOption("Prop", function() SetClipboardText(entmpath) end)
        SubMenu1:AddOption("Material", function() SetClipboardText(entmater) end)
        SubMenu1:AddOption("All", function() SetClipboardText(entowner .. "  |  " .. entclass .. "  |  " .. entmpath .. " |  " .. entmater) end)
            //SubMenu1:AddOption
        Menu:Open()
    end
     
    for k,v in pairs(ents.GetAll()) do
        DermaListView:AddLine(v:GetOwner(),v:GetClass(),v:GetModel(),v:GetMaterial()) -- Add lines
    end
end
concommand.Add("entlist", EntMaterial)

concommand.Add("+speeed", function() RunConsoleCommand("spoofed_host_timescale", 5.0) end)
concommand.Add("-speeed", function() RunConsoleCommand("spoofed_host_timescale", 1.0) end)







--[NH] Player Aimbot
--Coded By Fisheater
--1/14/11

local friendslist = {} 
local NeonAim = 0
 
CreateClientConVar( "valk_AimBot_IgnoreSteamFriends", 1, true, false )
CreateClientConVar( "valk_AimBot_AimMode", 2, true, false )
CreateClientConVar( "valk_AimBot_AimBone", 1, true, false )
CreateClientConVar( "valk_AimBot_AimOffset", 0, true, false )
CreateClientConVar( "valk_AimBot_NoRecoil", 1, true, false )
CreateClientConVar( "valk_AimBot_Friendlyfire", 1, true, false )
CreateClientConVar( "valk_AimBot_IgnoreAdmins", 1, true, false )
CreateClientConVar( "valk_AimBot_IgnoreFriends", 0, true, false )
CreateClientConVar( "valk_AimBot_SmoothAimSpeed", 2, true, false )
CreateClientConVar( "valk_AimBot_SmoothAimEnabled", 0, true, false )
 
RunConsoleCommand( "valk_AimBot_AimMode", tonumber( GetConVarNumber( "valk_AimBot_AimMode" ) ) )
 
concommand.Add( "+valk_aim", function()
NeonAim = 1
end )
 
concommand.Add( "-valk_aim", function()
NeonAim = 0
end )
 
function IsVisible( ent )
local tracer = {}
tracer.start = LocalPlayer():GetShootPos()
tracer.endpos = ent:GetShootPos()
tracer.filter = { LocalPlayer(), ent }
tracer.mask = MASK_SHOT
local trace = util.TraceLine( tracer )
if trace.Fraction >= 1 then return true else return false end
end
 
function Exceptions( ent124 )
if GetConVarNumber( "valk_AimBot_IgnoreSteamFriends" ) == 1 then
if ent124:GetFriendStatus() != "friend" then return true end
else return true
        end
end
 
function Exceptions2( entt124 )
if GetConVarNumber( "valk_AimBot_Friendlyfire" ) == 0 then
if entt124:Team() != LocalPlayer():Team() then return true end
else return true
        end
end
 
function Exceptions3( enta124 )
if GetConVarNumber( "valk_AimBot_IgnoreAdmins" ) == 1 then
if enta124:IsAdmin() or enta124:IsSuperAdmin() then return false else return true end
else
return true
        end
end
 
function Exceptions4( v12 )
if GetConVarNumber( "valk_AimBot_IgnoreFriends" ) < 1 then return true end
if #friendslist < 1 then return true end
for k1, v1 in pairs( friendslist ) do
if v12:Nick() ~= v1 then
return true
else
return false
                end
        end
end
 
function ClosestTarget()
local target = { NULL, 0 }
for k, v in ipairs( player.GetAll() ) do
if IsValid( v ) then
 
if v ~= LocalPlayer() then
 
if IsVisible( v ) then
 
if v:Team() ~= TEAM_SPECTATOR and v:Team() ~= "1001" and v:Team() ~= "1002" then
if v:Health() > 0 and v:Alive() then
if !v:InVehicle() then
if IsVisible( v ) then
if Exceptions( v ) then
if Exceptions2( v ) then
if Exceptions3( v ) then
if Exceptions4( v ) then
local distance = v:GetPos() - LocalPlayer():GetPos()
distance = distance:Length()
distance = math.abs( distance )
if ( distance < target[2] or target[1] == NULL ) then
target = { v, distance }
                                                                                                end
                                                                                        end
                                                                                end
                                                                        end
                                                                end
                                                        end
                                                end
                                        end    
                                end
                        end
                end
        end
end
if IsValid( target[1] ) then
if target[1] != LocalPlayer() then
return target[1]
else
return LocalPlayer()
                end
        end
end
 
function ClosestTarget2()
local pos = LocalPlayer():GetPos()
local ang = LocalPlayer():GetAimVector()
local target2 = { NULL, 0 }
for k, v in ipairs( player.GetAll() ) do
if IsValid( v ) then
if v ~= LocalPlayer() then
 
if IsVisible( v ) then
 
if v:Team() ~= TEAM_SPECTATOR and v:Team() ~= TEAM_UNASSIGNED and v:Team() ~= TEAM_CONNECTING then
if v:Health() > 0 and v:Alive() then
if !v:InVehicle() then
if Exceptions( v ) then
if Exceptions2( v ) then
if Exceptions3( v ) then
if Exceptions4( v ) then
local crosshair =  v:GetPos() - pos
if crosshair == nil then
    print("FUCK")
end
crosshair = crosshair - ang
crosshair = crosshair:Length()
crosshair = math.abs( crosshair )
if ( crosshair < target2[2] ) or ( target2[1] == NULL ) then
target2 = { v, crosshair }
                                                                                        end
                                                                                end
                                                                        end
                                                                end
                                                        end    
                                                end
                                        end
                                end
                        end
                end
        end
end
 
if IsValid( target2[1] ) then
if target2[1] != LocalPlayer() then
return target2[1]
else
return LocalPlayer()
                end
        end
end
 
hook.Add( "Think", "NeonNoRecoil", function()
if GetConVarNumber( "valk_AimBot_NoRecoil" ) >= 1 then
if LocalPlayer():GetActiveWeapon().Primary then
LocalPlayer():GetActiveWeapon().Primary.Recoil = 0
                end
        end
end )
                               
function Target()
if GetConVarNumber( "valk_AimBot_AimMode" ) >= 2 then
return ClosestTarget2()
elseif GetConVarNumber( "valk_AimBot_AimMode" ) <= 1 then
return ClosestTarget()
        end
end
 
hook.Add( "Think", "TriggerBot1", function()
if GetConVarNumber( "valk_AimBot_TriggerBot" ) >= 1 then
if LocalPlayer():GetEyeTrace().Entity:IsPlayer() then
RunConsoleCommand( "+attack" )
else
RunConsoleCommand( "-attack" )
                end
        end
end )
 
--------------------------------------------------------------
local w = ScrW() / 2 - 28
local h = ScrH() / 2 - 55
 
CreateClientConVar( "valk_AimBot_ShowAimStatus", 1, true, false )
 
function AimBoat()
 
if NeonAim == 1 then
 
if !Target() then
if GetConVarNumber( "valk_AimBot_ShowAimStatus" ) >= 1 then
draw.SimpleText( "Scanning...", "hudfont", w, h, Color( 0, 255, 0, 255 ), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT )
        end
end
 
if Target() and IsValid( Target() ) then
 
local BonePos
local TarAng
 
if GetConVarNumber( "valk_AimBot_AimBone" ) <= 0 then
BonePos = Target():GetBonePosition( Target():LookupBone( "ValveBiped.Bip01_Head1" ) ) + Vector( 0, 0, tonumber( GetConVarNumber( "valk_AimBot_AimOffset" ) ) )
elseif GetConVarNumber( "valk_AimBot_AimBone" ) == 1 then
BonePos = Target():GetBonePosition( Target():LookupBone( "ValveBiped.Bip01_Head1" ) ) + Vector( 0, 0, tonumber( GetConVarNumber( "valk_AimBot_AimOffset" ) ) )
elseif GetConVarNumber( "valk_AimBot_AimBone" ) == 2 then
BonePos = Target():GetBonePosition( Target():LookupBone( "ValveBiped.Bip01_Neck1" ) ) + Vector( 0, 0, tonumber( GetConVarNumber( "valk_AimBot_AimOffset" ) ) )
elseif GetConVarNumber( "valk_AimBot_AimBone" ) == 3 then
BonePos = Target():GetBonePosition( Target():LookupBone( "ValveBiped.Bip01_Spine4" ) ) + Vector( 0, 0, tonumber( GetConVarNumber( "valk_AimBot_AimOffset" ) ) )
elseif GetConVarNumber( "valk_AimBot_AimBone" ) == 4 then
BonePos = Target():GetBonePosition( Target():LookupBone( "ValveBiped.Bip01_Spine2" ) ) + Vector( 0, 0, tonumber( GetConVarNumber( "valk_AimBot_AimOffset" ) ) )
elseif GetConVarNumber( "valk_AimBot_AimBone" ) == 5 then
BonePos = Target():GetBonePosition( Target():LookupBone( "ValveBiped.Bip01_Spine1" ) ) + Vector( 0, 0, tonumber( GetConVarNumber( "valk_AimBot_AimOffset" ) ) )
elseif GetConVarNumber( "valk_AimBot_AimBone" ) == 4 then
BonePos = Target():GetBonePosition( Target():LookupBone( "ValveBiped.Bip01_Spine" ) ) + Vector( 0, 0, tonumber( GetConVarNumber( "valk_AimBot_AimOffset" ) ) )
elseif GetConVarNumber( "valk_AimBot_AimBone" ) >= 5 then
BonePos = Target():GetBonePosition( Target():LookupBone( "ValveBiped.Bip01_Spine" ) ) + Vector( 0, 0, tonumber( GetConVarNumber( "valk_AimBot_AimOffset" ) ) )
end
 
BonePos = BonePos + Target():GetVelocity() / 50 - LocalPlayer():GetVelocity() / 50
 
TarAng = ( BonePos - LocalPlayer():GetShootPos() ):Angle()
 
TarAng.p = math.NormalizeAngle( TarAng.p )
TarAng.y = math.NormalizeAngle( TarAng.y )
TarAng.r = 0
 
if GetConVarNumber( "valk_AimBot_SmoothAimEnabled" ) >= 1 then
 
local Angle1 = LocalPlayer():EyeAngles()
local Smooth1 = math.Approach( LocalPlayer():EyeAngles().p, TarAng.p, GetConVarNumber( "valk_AimBot_SmoothAimSpeed" ) )
local Smooth2 = math.Approach( LocalPlayer():EyeAngles().y, TarAng.y, GetConVarNumber( "valk_AimBot_SmoothAimSpeed" ) )
 
LocalPlayer():SetEyeAngles( Angle( Smooth1, Smooth2, 0 ) )
 
if GetConVarNumber( "valk_AimBot_ShowAimStatus" ) >= 1 then
draw.SimpleText( "Target Locked!", "hudfont", w, h, Color( 255, 0, 0, 255 ), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT )
draw.SimpleText( "TARGET: " .. Target():Nick(), "hudfont", w, h + 15, Color( 255, 0, 0, 255 ), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT )
end
 
else
 
LocalPlayer():SetEyeAngles( Angle( TarAng.p, TarAng.y, 0 ) )
 
if GetConVarNumber( "valk_AimBot_ShowAimStatus" ) >= 1 then
draw.SimpleText( "Target Locked!", "hudfont", w, h, Color( 255, 0, 0, 255 ), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT )
draw.SimpleText( "Target: " .. Target():Nick(), "hudfont", w, h + 15, Color( 255, 0, 0, 255 ), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT )
end
 
if !LocalPlayer():GetEyeTrace().Entity:IsPlayer() then return end
 
                        end
                end
        end
end
hook.Add( "HUDPaint", "NeonHackAimBoat", AimBoat )





surface.CreateFont("thing",
                    {
                    font = "thing", 
                    size = 13, 
                    weight = 110
                    })
local AllowGunColEdit = false
local Toggle = false

function Manager()
local DermaPanel = vgui.Create("DFrame") -- Creates the frame itself
DermaPanel:SetPos(300,300) -- Position on the players screen
DermaPanel:SetSize(300,350) -- Size of the frame
DermaPanel:SetTitle("Physgun Manager :: Made by Sasha C=") -- Title of the frame
DermaPanel:SetVisible(true)
DermaPanel:SetDraggable(true) -- Draggable by mouse?
DermaPanel:ShowCloseButton(true) -- Show the close button?
DermaPanel:MakePopup() -- Show the frame
local Blah1 = vgui.Create("DCheckBoxLabel", DermaPanel)
Blah1:SetPos(175,30)
Blah1:SetText("")
Blah1:SetValue(0)
Blah1:SetToolTip("Toggling this allows you to edit your physgun color with the thingy below")
Blah1:SizeToContents()
Blah1.OnChange = function(pself, fvalue)
    if (fvalue == true and AllowGunColEdit == false) then
        AllowGunColEdit = true
    else
        AllowGunColEdit = false
    end
end

local Blah2 = vgui.Create("DLabel", DermaPanel)
Blah2:SetPos(175+19,30+3)
Blah2:SetColor(Color(255,255,255,255))
Blah2:SetFont("ConsoleText")
Blah2:SetText("Edit Physgun Color")
Blah2:SizeToContents()
local colorCube = vgui.Create( "DColorCube", DermaPanel)
colorCube:SetPos(175,50)
colorCube:SetSize(70,70)
colorCube:SetColor( Color( 255, 0, 0, 255 ))
colorCube:SetBaseRGB( Color( 255, 0, 0 ) )
colorCube.OnUserChanged = function()
LocalPlayer():ConCommand("cl_weaponcolor " ..colorCube:GetRGB().r.. " " ..colorCube:GetRGB().g.. " " ..colorCube:GetRGB().b)
end
local DRGBBar = vgui.Create( "DRGBPicker" )
DRGBBar:SetParent( DermaPanel )
DRGBBar:SetPos(250,50)
DRGBBar:SetSize(25,70)
DRGBBar.OnChange = function(ctrl, col)
colorCube:SetBaseRGB(col)    
end
function CreateCheckbox(text, convar, tooltip, parent, x, y, r, g, b)
    local Blah1 = vgui.Create("DCheckBoxLabel", parent)
    Blah1:SetPos(x,y)
    Blah1:SetText("")
    Blah1:SetToolTip(tooltip)
    Blah1:SetConVar(convar)
    Blah1:SizeToContents()

    local Blah2 = vgui.Create("DLabel", parent)
    Blah2:SetPos(x+19,y)
    Blah2:SetColor(Color(r,g,b,255))
    Blah2:SetFont(text)
    Blah2:SetText(text)
    Blah2:SizeToContents()
end
function CreateSlider(text, convar, tooltip, parent, min, max, d, l, x, y, r, g, b)
    local Blah1 = vgui.Create("Slider", parent)
    Blah1:SetPos(x,y)
    Blah1:SetSize(170,50)
    Blah1:SetText("")
    Blah1:SetToolTip(tooltip)
    Blah1:SetMin(min) -- Minimum number of the slider
    Blah1:SetMax(max) -- Maximum number of the slider
    Blah1:SetDecimals(d) -- Sets a decimal. Zero means it's a whole number
    Blah1:SetConVar(convar)

    local Blah2 = vgui.Create("DLabel", parent)
    Blah2:SetPos(x+3,y+1)
    Blah2:SetColor(Color(r,g,b,255))
    Blah2:SetFont("thing")
    Blah2:SetText(text)
    Blah2:SizeToContents()
    CreateCheckbox("Toggle Halo", "physgun_halo","Toggles the halo that appears around your props when you physgun them", DermaPanel, 5, 30, 200, 200, 200)

CreateSlider("Pull Slowness", "physgun_teleportDistance", "This sets how slow props move when you have them physgunned", DermaPanel, 0, 9001, 1, 200, 5, 110, 200, 200, 200)
CreateSlider("Pull Slowness", "physgun_teleportDistance", "This sets how slow props move when you have them physgunned", DermaPanel, 0, 9001, 1, 200, 5, 110, 200, 200, 200)
end
end
concommand.Add("physgun_manager", Manager)

/*
local asdf = 9001
local cunts = 1337
function IHateNewbCodersLikeYou(this, is, why)
    print("I hate you because:\n")
    if () then
        if () then

        end
    elseif () then

    else

    end
end
*/

/*
function sashaismymasteresp(ent)
    if !IsValid(ent) then return end

    if !IsValid(ply) then return end

    if ent:IsPlayer() then
    if ent:Alive() == true then
    local col = Color(25, 25, 255, 255)
    local mat = "models/debug/debugwhite"
    end
    end
end

hook.Add("HUDPaint", "mygayesp", function()
for k, v in pairs(ents.GetAll()) do
ESPFuncHere(v)
*/

















/*
local idk = {
    "ammo",
    "behind you",
    "better reload",
    "bullshit",
    "cheese",
    "combine",
    "coming",
    "cops",
    "cp",
    "cps",
    "cut it",
    "dont tell me",
    "dejavu",
    "excuse me",
    "fantastic",
    "figures",
    "finally",
    "follow",
    "focus",
    "freeman",
    "get down",
    "get in",
    "get out",
    "good god",
    "gosh",
    "got one",
    "gotta reload",
    "gtfo",
    "hacks",
    "hax",
    "haxx",
    "help",
    "here they come",
    "hello, hey, hi",
    "heads up",
    "he's dead",
    "how about that",
    "i know",
    "ill stay here",
    "im busy",
    "im with you",
    "isnt good",
    "incoming",
    "it cant be",
    "it is ok",
    "kay",
    "lead on",
    "lets go",
    "never can tell",
    "nice",
    "not good",
    "not sure",
    "now what",
    "oh no",
    "omg",
    "ok",
    "oops",
    "over here",
    "over there",
    "pardon me",
    "please no",
    "right on",
    "run",
    "same here",
    "shut up",
    "spread the word",
    "stop it",
    "stop looking at me",
    "sorry",
    "take cover",
    "take this medkit",
    "task at hand",
    "talking to me",
    "thats you",
    "this cant be",
    "this is bad",
    "too much info",
    "uh oh",
    "wait",
    "wait for me",
    "wait for us",
    "wanna bet",
    "watch out",
    "we're done for",
    "what now",
    "whatever you say",
    "whats the use",
    "whats the point",
    "whoops",
    "why go on",
    "why telling me",
    "yeah",
    "you and me both",
    "you never know",
    "you sure",
}

hook.Add("Think", "", function()
    LocalPlayer():ConCommand("say " ..table.Random(idk))
    //LocalPlayer():ConCommand("say cheese")
end)
*/