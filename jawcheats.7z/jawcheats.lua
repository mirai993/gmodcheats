--[[
	MOD/lua/jaw.lua [#5467 (#5467), 933137573, UID:4048926917]
	Johnny183 | STEAM_0:1:42279954 <151.225.120.230:27005> | [25.07.14 10:06:50PM]
	===BadFile===
]]

///////////////////////////////////////////////////
//                                               //
//       ////////////                            // 
//          //                                   //
//         //            //\\             //     //
//        /\\           //  \\           //      //
//       // \\         //    \\         //       //
//      //   \\       //      \\       //        //
//     ///////\\     //        \\     //         //
// /////       \\|///          \\\|///           //
//                                               //
/////////////////////////////////////////////////// JaWCheats

// CONCOMMANDS LIST
// jaw_aimbot
// jaw_triggerbot
// jaw_esp


// Aimbot

local Aimbot = CreateClientConVar( "jaw_aimbot", 0, true, false )

hook.Add( "Think", "Aimbot", function()
    if Aimbot:GetInt() == 1 then
        local players = player.GetAll()
        local ply = LocalPlayer()
        local trace = util.GetPlayerTrace( ply )
        local traceRes = util.TraceLine( trace )
        if traceRes.HitNonWorld then
            local target = traceRes.Entity
            if target:IsPlayer() then
                local targethead = target:LookupBone("ValveBiped.Bip01_Head1")
                local targetheadpos, targetheadang = target:GetBonePosition(targethead)
                ply:SetEyeAngles((targetheadpos - ply:GetShootPos()):Angle())
            end
        end
    end
end )



// Trigger Bot
 

local TriggerBot = CreateClientConVar( "jaw_triggerbot", 0, true, false )
 
hook.Add( "Think", "Triggerbot", function()
    local Target = LocalPlayer():GetEyeTrace().Entity
    
    if TriggerBot:GetInt() == 1 and LocalPlayer():Alive() and LocalPlayer():GetActiveWeapon():IsValid() and ( Target:IsPlayer() or Target:IsNPC() ) then
 
        if !Firing then
 
            RunConsoleCommand( "+attack" )
            LocalPlayer():GetActiveWeapon().SetNextPrimaryFire( LocalPlayer():GetActiveWeapon() )
            Firing = true
 
        else
 
            RunConsoleCommand( "-attack" ) 
            Firing = false
 
        end
 
    end
 
end )


// ESP

local ESP = CreateClientConVar( "jaw_esp", 0, true, false )

hook.Add( "Think", "ESP", function()
    if ESP:GetInt() == 1 then
            print("ESP Loaded")
        local function MESPCheck(v)
                if v:Alive() == true && v:Health() ~= 0 && v:Health() >= 0 && v ~= LocalPlayer() && LocalPlayer():Alive() then
                        return true
                else
                        return false
                end
        end


        hook.Add( "HUDPaint", "aimbot.Wallhack", function()
        for k,v in pairs ( player.GetAll() ) do
 
                local Position = ( v:GetPos() + Vector( 0,0,80 ) ):ToScreen()
                local Name = ""
 
                if v == LocalPlayer() then Name = "" else Name = v:Name() end
 
        end
 
        end )
 
        local shouldDraw = true
 
        local hzCross = CreateClientConVar("HZ_Crosshair","0",false)
 
        function Crosshair1()
        surface.SetDrawColor(team.GetColor(LocalPlayer():Team()))
        surface.DrawLine(ScrW() / 2 - 10, ScrH() / 2, ScrW() / 2 + 11 , ScrH() / 2)
        surface.DrawLine(ScrW() / 2 - 0, ScrH() / 2 - 10, ScrW() / 2 - 0 , ScrH() / 2 + 11)
        end
        hook.Add("HUDPaint","CustomCross",Crosshair1)

        local function coordinates( ent )
        local min, max = ent:OBBMins(), ent:OBBMaxs()
        local corners = {
                Vector( min.x, min.y, min.z ),
                Vector( min.x, min.y, max.z ),
                Vector( min.x, max.y, min.z ),
                Vector( min.x, max.y, max.z ),
                Vector( max.x, min.y, min.z ),
                Vector( max.x, min.y, max.z ),
                Vector( max.x, max.y, min.z ),
                Vector( max.x, max.y, max.z )
        }
 
        local minX, minY, maxX, maxY = ScrW() * 2, ScrH() * 2, 0, 0
        for _, corner in pairs( corners ) do
                local onScreen = ent:LocalToWorld( corner ):ToScreen()
                minX, minY = math.min( minX, onScreen.x ), math.min( minY, onScreen.y )
                maxX, maxY = math.max( maxX, onScreen.x ), math.max( maxY, onScreen.y )
        end
 
        return minX, minY, maxX, maxY
        end
        hook.Add("HUDPaint", "Example", function()
        for k,v in pairs(player.GetAll()) do
                local x1,y1,x2,y2 = coordinates(v)
                print(tostring(team.GetColor(v:Team())))
                surface.SetDrawColor(color_white)
 
 
                surface.DrawLine( x1, y1, math.min( x1 + 5, x2 ), y1 )
                surface.DrawLine( x1, y1, x1, math.min( y1 + 5, y2 ) )
 
 
                surface.DrawLine( x2, y1, math.max( x2 - 5, x1 ), y1 )
                surface.DrawLine( x2, y1, x2, math.min( y1 + 5, y2 ) )
 
 
                surface.DrawLine( x1, y2, math.min( x1 + 5, x2 ), y2 )
                surface.DrawLine( x1, y2, x1, math.max( y2 - 5, y1 ) )
 
 
                surface.DrawLine( x2, y2, math.max( x2 - 5, x1 ), y2 )
                surface.DrawLine( x2, y2, x2, math.max( y2 - 5, y1 ) )
        end
        end)

        local struc = {}
        struc.pos = {}
        struc.pos[1] = 100
        struc.pos[2] = 200
        struc.color = Color(255,0,0,255)
        struc.text = "Hello World"
        struc.font = "DefaultFixed"
        struc.xalign = TEXT_ALIGN_CENTER
        struc.yalign = TEXT_ALIGN_CENTER
        draw.Text( struc )
    end
end )