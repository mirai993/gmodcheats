local cathack = {Menu = {tabs = {}, b = {}}}
local menu = cathack.Menu
 
cathack.Settings = {
        aimbot                  = true;
        aimbot_fov              = 5;
        aimbot_bone             = "ValveBiped.Bip01_Head1";
       
        triggerbot              = true;
       
        esp                             = true;
        esp_ply                 = true;
        esp_ply_name    = true;
        esp_ply_rank    = true;
        esp_ply_health  = true;
        esp_ply_dist    = true;
        esp_player_dist = 2000;
        esp_ent                 = true;
        esp_ent_dist    = 2000;
       
        darkrp_god              = false;
        flashlight_spam = true;
        bunnyhop                = false;
}
 
 
 
cathack.Whitelist = {
}
cathack.Entities = {
        "money_printer";
        "spawned_money";
        "ent_pot_leaf";
        "ent_coca_leaf";
        "topaz_money_printer";
        "sapphire_money_printer";
        "ruby_money_printer";
        "emerald_money_printer";
        "amethyst_money_printer";
        "drug_pot_seeds";
        "perp_di";
}
cathack.Phrases = {
        "Syko is a fucking psycho";
        "Syko will rape you";
        "Roarax is a nigger";
        "dude wtf anticheat cant touch me";
        "$10 for hake";
        "lol i code html";
}
 
cathack.Bones = {
        head = "ValveBiped.Bip01_Head1";
        spine = "ValveBiped.Bip01_Spine";
}
 
surface.CreateFont("Trebuchet19cat", {font="TabLarge", size=13, weight=700})
surface.CreateFont("Trebuchetcat", {font="TabLarge", size=10, weight=700})
 
function cathack.CloneTable( src ) --cbot
        local new = {}
        for k, v in pairs( src ) do
                local newf = rawget(src, k);
                if( type( newf ) == "table" and v ~= src ) then
                        new[k] = cathack.CloneTable( v );
                else
                        new[k] = newf;
                end
        end
 
        return new;
end
 
cathack.table                   = cathack.CloneTable( table );
cathack.hook                    = cathack.CloneTable( hook );
cathack.math                    = cathack.CloneTable( math );
cathack.surface                 = cathack.CloneTable( surface );
cathack.draw                    = cathack.CloneTable( draw );
 
local table                     = cathack.table;
local hook                              = cathack.hook;
local math                              = cathack.math;
local surface                   = cathack.surface;
local draw                              = cathack.draw;
 
function cathack.GetShootPos(ent)
        local eyes = ent:LookupAttachment("eyes");
        if(eyes ~= 0) then
                eyes = ent:GetAttachment(eyes);
                if(eyes and eyes.Pos) then
                        return eyes.Pos, eyes.Ang;
                end
        end
end
 
function cathack.GetVisible(ent)
        local pos = LocalPlayer():GetShootPos()
        local ang = LocalPlayer():GetAimVector()
        local trace = {start = LocalPlayer():GetShootPos(), endpos = cathack.GetShootPos(ent), filter = {LocalPlayer(), ent}, mask = 1174421507};
        local tr = util.TraceLine(trace);
        return(tr.Fraction == 1);
end
 
function cathack.Whitelisted(ent)
        if table.HasValue(cathack.Whitelist, ent:SteamID())     then return true
        else return false end
end
 
function cathack.Target(v)
        if v:IsPlayer() then
                if (cathack.GetVisible(v) and (not cathack.Whitelisted(v)) and v:Alive() and (v:Health() > 0) and v:Team() ~= TEAM_SPECTATOR) then
                        if (v ~= LocalPlayer() and LocalPlayer():Alive() and LocalPlayer():Team() ~= TEAM_SPECTATOR) then
                                if string.find(gmod.GetGamemode().Name, "Stronghold") then
                                        if (v:Team() ~= LocalPlayer():Team()) then
                                                return true
                                        end
                                else
                                        return true
                                end
                        end
                end
        end
        return false
end
 
function cathack.ESP(typ, v)
        if typ == "player" then
                if v:Alive() && v:Health() >= 1 && v ~= LocalPlayer() && /*LocalPlayer():Alive() &&*/ LocalPlayer():Team() ~= TEAM_SPECTATOR then
                        return true
                else
                        return false
                end
        elseif typ == "entity" then
                if IsValid(v) then
                        return true
                end
        end
end
 
function cathack.Rank(v)
        if v:IsAdmin() or v:IsSuperAdmin() then
                return "[A] "
        else return "" end
end
 
function cathack.Get(value)
        if not(cathack.Settings[value]) then return end
       
        if cathack.Settings[value] == true then
                return "enabled"
        elseif cathack.Settings[value] == false then
                return "disabled"
        elseif cathack.Settings[value] == "ValveBiped.Bip01_Head1" then
                return "head"
        elseif cathack.Settings[value] == "ValveBiped.Bip01_Spine4" then
                return "spine"
        else
                return cathack.Settings[value]
        end
end
 
function cathack.Set(value, value2)
        if value2 == "enabled" then
                cathack.Settings[value] = true
        elseif value2 == "disabled" then
                cathack.Settings[value] = false
        elseif value2 == "head" then
                cathack.Settings[value] = "ValveBiped.Bip01_Head1"
        elseif value2 == "spine" then
                cathack.Settings[value] = "ValveBiped.Bip01_Spine4"
        else
                cathack.Settings[value] = value2
        end
end
 
function cathack.GetBone()
        local b = cathack.Settings["aimbot_bone"]
        if b == "head" then
                return cathack.Bones["head"]
        elseif b == "spine" then
                return cathack.Bones["spine"]
        end
        return nil
end
 
function cathack.CreateTab(txt, szw, szh, psw, psh, parent, func)
        if(not parent) then return; end
        local panel = vgui.Create("DPanel", menu.frame);
        panel:SetPos(120,25);
        panel:SetSize(375,405);
        if menu.curwin == txt then panel:SetVisible(true) else panel:SetVisible(false) end
        panel.Paint = function()
                local line = "__________________________________________________________________________"
                surface.SetDrawColor( 00, 00, 00, 255 )
                surface.DrawRect( 0, 0, panel:GetWide(), panel:GetTall() )
                surface.CreateFont("shmenufont", {font="coolvetica", size=64, weight=500});
                surface.CreateFont("shmenufont2", {font="coolvetica", size=24, weight=500});
                draw.SimpleText(txt, "shmenufont", 10, 10, Color(255, 00, 00, 235), TEXT_ALIGN_LEFT);
                --draw.SimpleText(line, "MenuLarge", 50, 60, Color(0,0,0,255), TEXT_ALIGN_CENTER)
                if txt == "ESP" then
                        draw.SimpleText("Player ESP", "shmenufont2", 5, 100, Color(255,00,00,235), TEXT_ALIGN_LEFT);
                        draw.SimpleText("Entity ESP", "shmenufont2", 5, 250, Color(255,00,00,235), TEXT_ALIGN_LEFT);
                end
        end
        local button = vgui.Create("DButton", parent);
        button:SetText(txt);
        button:SetSize(szw, szh);
        button:SetPos(psw, psh);
        button.Paint = function(self) derma.SkinHook("PaintOver", "Button", self) end
        button:SetVisible(true);
        button.DoClick = func or function()
                for k,v in pairs(menu.tabs) do
                        if v ~= panel then
                                v:SetVisible(false)
                        end
                end
                panel:SetVisible(true)
                menu.curwin = txt
                surface.PlaySound("ambient/levels/canals/drip4.wav");
        end
        return panel, button;
end
 
function cathack.AddFeature(parent, id, typ, text, val, option1, option2, option3, option4, option5)
        if not(parent) or not(typ) then return; end
        local posy = (55+(id*25))
        if typ == "button" then
                if cathack.Settings[val] == nil then return end
                if text ~= nil then
                        local label = vgui.Create("DLabel", parent)
                        label:SetText(text)
                        label:SetPos(5,posy)
                        label:SizeToContents(false)
                end
 
                local button = vgui.Create("DButton", parent)
                if cathack.Get(val) == option1 then
                        button:SetText(option1)
                else
                        button:SetText(option2)
                end
                button:SetSize(80,20)
                if id == 0 then
                        button:SetPos(285,45)
                else
                        button:SetPos(285,posy)
                end
                button.DoClick = function()
                        if button:GetText() == option1 then
                                button:SetText(option2); cathack.Set(val, option2)
                        else
                                button:SetText(option1); cathack.Set(val, option1)
                        end
                end
                return button, label
        elseif typ == "dbutton" then
                local button = vgui.Create("DButton", parent)
                button:SetPos(option1,option2)
                button:SetSize(option3,option4)
                button:SetText(text)
                button.DoClick = option5
                return button
        elseif typ == "slider" then
                local slider = vgui.Create("DNumSlider", parent)
                slider:SetPos(5, posy-10)
                slider:SetText(text)
                slider:SetMinMax(option1, option2)
                slider:SetWide(372.5)
                slider:SetDecimals( 0 )
                slider:SetValue(cathack.Get(val))
                slider.OnValueChanged = function(panel, value)
                        local c = tonumber(value)
                        cathack.Set(val, math****und(c))
                end
                return slider;
        elseif typ == "label" then
                local label = vgui.Create("DLabel", parent)
                label:SetText(text)
                label:SetPos(5,posy)
                label:SizeToContents(false)
        end
end
 
function cathack.DrMenu()
        if(menu.frame) then menu.frame:Remove(); end
       
        menu.frame = vgui.Create("DFrame");
        menu.frame:SetPos(ScrW()/2-184, ScrH()/2-155);
        menu.frame:SetSize(500, 435);
        menu.frame:SetTitle("vHack @ CodingLizzard Beta "..cathack.Phrases[math.random(1, table.Count(cathack.Phrases))]);
        menu.frame:SetVisible(true);
        menu.frame:SetDraggable(true);
        menu.frame:SetSizable(false);
        menu.frame:ShowCloseButton(false);
        menu.frame:SetBackgroundBlur(true)
        menu.frame:MakePopup();
 
        menu.buttons = vgui.Create("DPanel", menu.frame)
        menu.buttons:SetPos(5, 25)
        menu.buttons:SetSize(110,405)
        menu.buttons.Paint = function()
                surface.SetDrawColor(50,50,255,255)
                surface.DrawRect(0, 0, menu.buttons:GetWide(), menu.buttons:GetTall())
        end
 
        menu.tabs.aimbot, menu.b.aimbot =       cathack.CreateTab("Aimbot", 80, 20, 15, 10, menu.buttons)
        menu.tabs.pesp, menu.b.pesp             =       cathack.CreateTab("ESP", 80, 20, 15, 35, menu.buttons)
        menu.tabs.wh, menu.b.wh                 =       cathack.CreateTab("Wallhack", 80, 20, 15, 60, menu.buttons)
        menu.tabs.misc, menu.b.misc             =       cathack.CreateTab("Misc", 80, 20, 15, 85, menu.buttons)
       
        local mta = menu.tabs.aimbot
        local mtp = menu.tabs.pesp
        local mtw = menu.tabs.wh
        local mtm = menu.tabs.misc
        -- aimbot tab
        cathack.AddFeature(mta, 1, "button", "Aimbot", "aimbot", "enabled", "disabled")
        cathack.AddFeature(mta, 2, "button", "Aim-bone", "aimbot_bone", "head", "spine")
        cathack.AddFeature(mta, 3, "slider", "Aim FOV", "aimbot_fov", 1, 180)
        cathack.AddFeature(mta, 4, "button", "Triggerbot", "triggerbot", "enabled", "disabled")
       
        -- esp tab
        cathack.AddFeature(mtp, 0, "button", nil, "esp", "enabled", "disabled")
       
        cathack.AddFeature(mtp, 2, "button", "Enabled", "esp_player", "enabled", "disabled")
        cathack.AddFeature(mtp, 3, "button", "Show Name", "esp_ply_name", "enabled", "disabled")
        cathack.AddFeature(mtp, 4, "button", "Show Rank", "esp_ply_rank", "enabled", "disabled")
        cathack.AddFeature(mtp, 5, "button", "Show Health", "esp_ply_health", "enabled", "disabled")
        cathack.AddFeature(mtp, 6, "button", "Show Distance", "esp_ply_dist", "enabled", "disabled")
        cathack.AddFeature(mtp, 7, "slider", "Distance", "esp_player_dist", 0, 16000)
        cathack.AddFeature(mtp, 9, "button", "Enabled", "esp_ent", "enabled", "disabled")
        cathack.AddFeature(mtp, 10, "slider", "Distance", "esp_ent_dist", 0, 16000)
       
        -- misc tab
        cathack.AddFeature(mtm, 1, "button", "Flashlight Spam", "flashlight_spam", "enabled", "disabled")
        cathack.AddFeature(mtm, 2, "button", "DarkRP God Exploit", "darkrp_god", "enabled", "disabled")
        cathack.AddFeature(mtm, 3, "button", "Bunnyhop", "bunnyhop", "enabled", "disabled")
end
 
hook.Add("Think", "catMENU", function()
        if(input.IsKeyDown(KEY_TAB) && input.IsKeyDown(KEY_Q) && !menu.frame)then
                cathack.DrMenu()
        elseif(menu.frame && input.IsKeyDown(KEY_ESCAPE))then
                menu.frame:Remove(); menu.frame = nil
                cathack.Menu = {}
        end
end)
 
hook.Add("Think", "catBOT", function()
        -- triggerbot
        if(cathack.Settings["triggerbot"] && input.IsKeyDown(KEY_B)) then
                local pos = LocalPlayer():GetShootPos()
                local ang = LocalPlayer():GetAimVector()
                local tracedata = {}
                tracedata.start = pos
                tracedata.endpos = pos+(ang*9999999999999)
                local trace = util.TraceLine(tracedata)
                if(trace.HitNonWorld) then
                        target = trace.Entity
                        if(target:IsPlayer() and (not cathack.Whitelisted(target))) then
                                RunConsoleCommand("+attack")
                                timer.Simple(0.000000000000000000001, function() RunConsoleCommand("-attack") end)
                        end
                end
        end
        -- aimbot [ need bone changing support ]
        if(cathack.Settings["aimbot"] && input.IsKeyDown(KEY_B)) /*or cathack.Settings["alert"]*/ then
                for k,v in pairs(player.GetAll()) do
                        /*if cathack.Settings["aimbot"] && input.IsKeyDown(KEY_B) then*/
                        local bone = cathack.Settings["aimbot_bone"];
                                if cathack.Target(v) then
                                        local head = v:LookupBone(bone)
                                        local fov = cathack.Settings["aimbot_fov"]
                                        if fov == 0 then
                                                local headpos,targetheadang = v:GetBonePosition(head)
                                                LocalPlayer():SetEyeAngles((headpos - LocalPlayer():GetShootPos()):Angle())
                                        else
                                                local lpang = LocalPlayer():GetAngles();
                                                local ang = (v:GetPos() - LocalPlayer():GetPos()):Angle();
                                                local ady = math.abs(math.NormalizeAngle(lpang.y - ang.y))
                                                local adp = math.abs(math.NormalizeAngle(lpang.p - ang.p ))
                                                if not(ady > fov or adp > fov) then
                                                        local headpos,targetheadang = v:GetBonePosition(head)
                                                        if headpos != nil and targetheadang != nil then
                                                        LocalPlayer():SetEyeAngles((headpos - LocalPlayer():GetShootPos()):Angle())
                                                        end
                                                end
                                        end
                                end
                               
                        --end
                        /*if cathack.Settings["alert"] then
                                local d = cathack.Settings["alert_dist"]
                                if v ~= LocalPlayer() and (v:GetPos():Distance(LocalPlayer():GetPos()) < d) then
                                       
                                end
                        end*/
                end
        end
        if cathack.Settings["flashlight_spam"] and input.IsKeyDown(KEY_O) then
                RunConsoleCommand("impulse", "100")
        end
       
        if cathack.Settings["darkrp_god"] and LocalPlayer():Health() < 100 and LocalPlayer():Alive() then
                RunConsoleCommand("say", "/buyhealth")
        end
       
        if cathack.Settings["bunnyhop"] and input.IsKeyDown(KEY_SPACE) then
                if(LocalPlayer():OnGround())then
                        LocalPlayer():ConCommand("+jump")
                        timer.Simple(0.01, function()
                                LocalPlayer():ConCommand("-jump")
                        end)
                end
        end
end)
 
 
 
 
hook.Add("HUDPaint", "catHUD", function()
        if cathack.Settings["esp"] then
                for k,v in pairs(ents.GetAll()) do
                        if cathack.Settings["esp_ply"] && v:IsPlayer() then
                                if(cathack.ESP("player", v) and v:GetPos():Distance(LocalPlayer():GetPos()) < (cathack.Settings["esp_player_dist"]))then
                                        local ESP = (v:EyePos()):ToScreen()
                                        local name,health,rank,col,distance = "","","","",""
                                        local outcol = Color(0,0,0,255)
                                        local white = Color(255,255,255,255)
                                        local outcol2 = outcol
                                        if cathack.Settings["esp_ply_name"] then
                                                if v.GetRPName then name = v:GetRPName()
                                                else name = v:Nick() end
                                        end
                                        if v:Nick() ~= name then rank = " "..v:Nick() end
                                        if cathack.Settings["esp_ply_rank"] then
                                                if v:IsSuperAdmin() then
                                                        rank = "[Super Admin]"..rank
                                                elseif v:IsAdmin() then
                                                        rank = "[Admin]"..rank
                                                elseif v:IsUserGroup("moderator") or v:IsUserGroup("mod") then
                                                        rank = "[Moderator]"..rank
                                                elseif v:IsUserGroup("vip") or v:IsUserGroup("donator") then
                                                        rank = "[Donator]"..rank
                                                end
                                        end
                                        if cathack.Settings["esp_ply_health"] then
                                                health = v:Health().."H - "..v:Armor().."A"
                                        end
                                        if cathack.Settings["esp_ply_dist"] then
                                                distance = v:GetPos():Distance(LocalPlayer():GetPos())
                                                distance = math****und(distance).." m"
                                        end
                                        col = team.GetColor(v:Team())
                                        if(col.r <= 50 and col.g <= 50 and col.b <= 50) then
                                                outcol2 = Color(200,200,200,255)
                                        end
                                        if col.a <= 50 then
                                                col = Color(col.r,col.g,col.b, 255)
                                        end
                                        draw.SimpleTextOutlined(rank, "Trebuchetcat", ESP.x, ESP.y -46, col, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, outcol2)
                                        draw.SimpleTextOutlined(name, "Trebuchet19cat", ESP.x, ESP.y - 34, col, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, outcol2)
                                        draw.SimpleTextOutlined(health, "Trebuchetcat", ESP.x, ESP.y -22, white, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, outcol)
                                        draw.SimpleTextOutlined(distance, "Trebuchetcat", ESP.x, ESP.y - 10, white, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, outcol)
                                end
                        end
                        if (cathack.Settings["esp_ent"] and cathack.ESP("entity", v) and (v:GetPos():Distance(LocalPlayer():GetPos()) < cathack.Settings["esp_ent_dist"]))then
                                for k,e in pairs(cathack.Entities) do
                                        if e == v:GetClass() then
                                                local ESP = (v:EyePos()):ToScreen()
                                                draw.SimpleTextOutlined(v:GetClass(), "Trebuchet19cat", ESP.x, ESP.y - 46, Color(255,0,0,255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, Color(0,0,0,255))
                                        end
                                end
                        end
                end
        end
end)
 
 
 
concommand.Add("defcon", function()
        local z = {"player"}
        local t = {}
        for k,v in pairs(ents.GetAll()) do
                if not table.HasValue(t, v:GetClass()) then
                        table.insert(t, v:GetClass())
                end
        end
        for e,x in pairs(t) do
                if !table.HasValue(z, x) then
                        print(x)
                end
        end
end)
 
concommand.Add("cathack", function()
        local darkrpvar = true
        print("Player Cash Amounts")
        for k,v in pairs(player.GetAll()) do
                if not(v.DarkRPVars and v.DarkRPVars.money)and(darkrpvar == true) then
                        darkrpvar = false
                end
                if v ~= LocalPlayer() then
                        print("    "..v:Nick().." : "..tostring(v.DarkRPVars.money))
                end
        end
        if darkrpvar == false then
                print("    Unable to get player cash amounts.")
        end
end)
 
concommand.Add("catapult", function()
        PrintTable(player.GetAll()[3]:GetTable())
end)