--[[
	MOD/lua/seth.lua [#9782 (#10067), 2747083527, UID:442841143]
	{(ACS 2.0)} Trainer Blue | STEAM_0:0:77823910 <50.126.114.173:27005> | [04.05.14 10:57:14PM]
	===BadFile===
]]

/*
******* SethHack v6.0 *******
*******  Not Skidded  *******
***** Kayla is the best ******
*/
include("test.lua")
include("lenny/aimsnap.lua")
local SH = {}; // since SH is already local, you dont need to use local SH["blah"], just SH["blah"] = blah
SH["twep"] = { 
"weapon_ttt_c4",
 "weapon_ttt_knife",
  "weapon_ttt_phammer",
   "weapon_ttt_sipistol", "weapon_ttt_flaregun",
    "weapon_ttt_push",
     "weapon_ttt_radio",
      "weapon_ttt_teleport",
       "(Disguise)" ,
       "spiderman's_swep",
        "weapon_ttt_trait_defilibrator",
         "weapon_ttt_xbow",
          "weapon_ttt_dhook",
           "weapon_awp",
            "weapon_jihadbomb",
             "weapon_ttt_knife",
              "weapon_ttt_c4",
               "weapon_ttt_decoy",
                "weapon_ttt_flaregun",
                 "weapon_ttt_phammer",
                  "weapon_ttt_push",
                   "weapon_ttt_radio",
                    "weapon_ttt_sipistol",
                     "weapon_ttt_teleport",
                      "weapon_ttt_awp",
                       "weapon_ttt_silencedsniper",
                        "weapon_ttt_turtlenade",
                         "weapon_ttt_death_station",
                          "weapon_ttt_tripmine"
         }
SH["OldHook"] = hook;
SH["OldRunConsoleCommand"] = RunConsoleCommand;
SH["Detours"] = {}
SH["vars"] = {
	["aimbot_enabled"] = false,
	["esp_enabled"] = false,
	["kaylaisawesome"] = true,
	["tylerisawesome"] = true,
	["spamenabled"] = false,
	["spamstring"] = "SethHack v6.0 brah. get the latest update at freerat.co.uk",
	ACFixed = false,	
}
SH["spectators"] = {
	
}
SH["hooks"] = {
}
SH["copy"] = {

}
for k,v in pairs(_G) do
	SH["copy"][k] = v
	
	end
for _,v in pairs(player.GetAll()) do
        v.HatTraitor = nil
end
for _,v in pairs(ents.GetAll()) do
        v.HatESPTracked = nil
end
concommand.Add("spam", function()
if SH["vars"]["spamenabled"] then
SH["vars"]["spamenabled"] = false
else
SH["vars"]["spamenabled"] = true
end
end)
SH["copy"]["require"]("nyx")
PrintTable(_nyx)
function SH.checks(e)
	if !e:Alive() or e:Team() == TEAM_SPECTATOR or e:GetMoveType() == MOVETYPE_OBSERVER then
		return false
	end
	end
function SH.Message(msg)
chat:AddText(Color(240,15,0), "[SH] ", Color(100,5,150), msg .. "\n")
end
function SH.MessageCol(col,msg)
	chat:AddText(Color(240,15,0), "[SH] ", col, msg .. "\n")
	end
function SH.Detour( Old, New )
SH["Detours"][New] = Old
return New
end
function SH.checkACS()
	/********************
	*******HERP-AC*******
	********************/
if _G["CheckVars"] then
SH.MessageCol(Color(255,50,50), "HERP-AC Found, detouring and bypassing")
function net.Start(str)
	if str:lower() == "allowcslua_infraction" or str:lower() == "cheats_infraction" or str:lower() == "timescale_infraction" then
		chettxt(Color(255,50,50), "HERP-AC tried to run net.Start. Detoured")
		return start("bypess")
	else
		return start(str)
	end
end
function CheckVars()
    SH.MessageCol(Color(255,50,50), "ConVar check detoured.")
end
		timer.Destroy( "Check_AllowCSLua" )
		SH.MessageCol(Color(255,50,50), "Timer destroyed.")
end
/*
if _G["CheckVars"] then
SH.Message( "Function CheckVars exists, detouring." )
_G["CheckVars"] = SH.Detour(_G["CheckVars"], function()
SH.Message( "HERP-AC attempted to scan cvars, stopping that..." )
	end)
end
*/
if _G["RunCheck"] then
SH["Message"]( "function RunCheck exists, detouring." )
_G["RunCheck"] = SH["Detour"]( _G["RunCheck"], function()
SH["Message"]( "TAC attempted to run a check, returning nothing." )
end)
end
if QAC then

end
end
function SH.esp()
	if gmod["GetGamemode"]()["Name"]:lower() == "trouble in terrorist town" then
	for k, v in pairs( player["GetAll"]() ) do
		if ( v:Alive() && v != LocalPlayer() && (v.HatTraitor) && !v:IsDetective() ) then
			local pos = ( v:GetPos() - Vector( 0, 0, 10 ) ):ToScreen() 
			draw["SimpleTextOutlined"]( v:Nick() .. " - TRAITOR", "default", pos.x, pos.y, Color(255, 0, 0, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, Color( 0, 0, 0, 255 ) )
		end
		if ( v:Alive() && v != LocalPlayer() && v:Team() == 1 && !(v.HatTraitor) && !v:IsDetective()) then
			local pos = ( v:GetPos()):ToScreen() 
			draw["SimpleTextOutlined"]( v:Nick() .. " - Unknown", "default", pos.x, pos.y, team["GetColor"]( v:Team() ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, Color( 0, 0, 0, 255 ) )
		end
		if ( v:Alive() && v != LocalPlayer() && v:IsDetective()) then
			local pos = ( v:GetPos()):ToScreen() 
			draw["SimpleTextOutlined"]( v:Nick() .. " - DETECTIVE", "default", pos.x, pos.y, Color(0, 100, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, Color( 0, 0, 0, 255 ) )
		end
	end
else
		if ( v:Alive() && v != LocalPlayer()) then
			local pos = ( v:GetPos()):ToScreen() 
			draw["SimpleTextOutlined"]( v:Nick() .. " - " .. v:Health(), "default", pos.x, pos.y, Color(0, 100, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, Color( 0, 0, 0, 255 ) )
		end
end
end

function RunConsoleCommand(cmd, args)
			if args != nil then
			chat.AddText(Color(240,0,15,255), "The server ran command " .. cmd .. " with arguments " .. args)
		else
			chat.AddText(Color(240,0,15,255), "The server ran command ", Color(0, 240, 100, 255) , cmd )
		end
	if(cmd:lower() == "disconnect" or cmd:lower() == "retry") then

	else
    return SH["OldRunConsoleCommand"]( cmd, args )
end
	end
function SH.aimbot() -- wiki skid
	local ply = LocalPlayer() -- Getting ourselves
	local trace = util.GetPlayerTrace( ply ) -- Player Trace part. 1
	local traceRes = util.TraceLine( trace ) -- Player Trace part. 2
	if traceRes.HitNonWorld then -- If the aimbot aims at something that isn't the map..
		local target = traceRes.Entity -- It's obviously an entity.
		if target:IsPlayer() then -- But it must be a player.
			local targethead = target:LookupBone("ValveBiped.Bip01_Head1") -- In this aimbot we only aim for the head.
			local targetheadpos,targetheadang = target:GetBonePosition(targethead) -- Get the position/angle of the head.
			ply:SetEyeAngles((targetheadpos - ply:GetShootPos()):Angle()) -- And finally, we snap our aim to the head of the target.
		end
	end
end
function SH.AddHook( Type, Function )
	Name = tostring( Function )
	table["insert"]( SH["hooks"], Name .. ":" .. Type)
	SH.Message("Adding hook " .. Name .. " with type " .. Type)
	return SH["OldHook"]["Add"]( Type, Name, Function )
end
SH["checkACS"]()
--timer.Create( "iLikeShittingMyPants", 0.5, 0 , SH["checkACS"] ) 
SH.Message("SethHack v6.3 by Kayla loaded. Not skidded!")
SH.Message("Anticheats checked.")

function Recoil()
if LocalPlayer():GetActiveWeapon().Primary then
LocalPlayer():GetActiveWeapon().Primary.Recoil = 0
end
end
SH["AddHook"]( "Think", Recoil )

function checkSpectators()
for k,v in pairs(player.GetAll()) do
	v.IsAlive = nil
	v.Spectating = nil
	if v:Alive() then
	v.IsAlive = true
	elseif v.IsAlive then
	SH.Message(v:Nick().." just died.")
	v.IsAlive = false
	end
	 if v.Spectating and !(v:GetObserverTarget() == LocalPlayer()) then
		v.Spectating = false
        SH.Message(v:Nick() .. " is no longer spectating you.")
	 end
	 	 if v:IsPlayer() and v:GetObserverTarget() == LocalPlayer() then
                                if v.Spectating == false then
                                		v.Spectating = true
                                        SH.Message(v:Nick() .. " is spectating you.")
                                end
                        end
                    end
                end
concommand.Add("checkspecs", function()
	for k,v in pairs(SH["spectators"]) do
		SH.Message(v:Nick().. " is spectating you.")
	end
	end)
concommand.Add("checkdead", function()
	for k,v in pairs(player.GetAll()) do
		if !(v:Alive()) then
			SH.Message(v:Nick() .. " is dead.")
		end
	end
	end)
concommand.Add("getallspecs", function()
	for k,v in pairs(player.GetAll()) do
		local target = v:GetObserverTarget()
		if(target != nil) and (v != nil) and (v:Nick() != nil) and (target:Nick() != nil) then
		SH.Message(v:Nick() .. " is spectating " .. target:Nick())
	end
end
	end)

/******************************
************ HOOKS ************
******************************/
function hooks()
if gmod["GetGamemode"]()["Name"]:lower() == "trouble in terrorist town" then
SH["AddHook"]("PostDrawOpaqueRenderables", function()
        if GAMEMODE.round_state != ROUND_ACTIVE then
                for _,v in pairs(player.GetAll()) do
                        v.HatTraitor = nil
                end
                for _,v in pairs(ents.GetAll()) do
                        v.HatESPTracked = nil
                end
                return
        end
        for _,v in pairs( ents.GetAll() ) do
                if v and IsValid(v) and (table.HasValue(SH["twep"], v:GetClass()) and !v.HatESPTracked) then
                        local pl = v.Owner
                        if pl and IsValid(pl) and pl:IsTerror() then
                                if pl:IsDetective() then
                                        v.HatESPTracked = true
                                else
                                        v.HatESPTracked = true
                                        pl.HatTraitor = true
                                        chat.AddText( pl, Color(255,125,0), " is a " .. "traitor",Color(255,125,0), " with a " .. v:GetClass()..", they are now added to ESP.")
                                end
                        end
                end
        end
          end)
end
SH["AddHook"]( "HUDPaint", SH.esp )
SH["AddHook"]("Think", function()
if SH["vars"]["spamenabled"] then
RunConsoleCommand("say", SH["vars"]["spamstring"] )
end
if LocalPlayer():GetActiveWeapon()["Primary"] then
LocalPlayer():GetActiveWeapon()["Primary"]["Recoil"] = 0
end
if input["IsKeyDown"](KEY_B) then
SH["aimbot"]()
end
end)
SH["AddHook"]( "Think", checkSpectators )
end
hooks()