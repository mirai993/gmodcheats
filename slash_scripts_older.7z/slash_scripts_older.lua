--Sup noob, looking at the source code eh? well heres some credits
--Smeee - bullying me 
--Dark - Teaching me alot about Lua
--Jynxx - "borrowed" some functions until I can be bothered to recode
--Cae - "borrowed" some functions until I can be bothered to recode

local menu_X = 0
local menu_Y = 0
local ItemColour = Color(249, 237, 4, 255)

local menu_pointer_Y = 10

local binds = {}
local bindsdebug = {}
local features_table = {}
font = "custom_font1"
surface.CreateFont( "custom_font1", {
	font = "Courier New", --  Use the font-name which is shown to you by your operating system Font Viewer, not the file name
	extended = false,
	size = 20,
	weight = 300,
	blursize = 0,
	scanlines = 0,
	outline = true,
})

surface.CreateFont( "custom_font2", {
	font = "CloseCaption_Bold", --  Use the font-name which is shown to you by your operating system Font Viewer, not the file name
	extended = false,
	underline = true,
	size = 20,
	weight = 300,
	blursize = 0,
	scanlines = 0,
	outline = true,
})
surface.CreateFont( "custom_font4", {
	font = "CloseCaption_Bold", --  Use the font-name which is shown to you by your operating system Font Viewer, not the file name
	extended = false,
	underline = false,
	size = 20,
	weight = 300,
	blursize = 0,
	scanlines = 0,
	outline = true,
})
surface.CreateFont( "custom_font3", {
	font = "Courier New", --  Use the font-name which is shown to you by your operating system Font Viewer, not the file name
	extended = false,
	underline = false,
	size = 15,
	weight = 300,
	blursize = 0,
	scanlines = 0,
	outline = true,
})
-- thank you cae for these
local function addBind(key, action)
    if binds[key] then
        print("bind for " .. tostring(key) .. " already exists, overiding anyways.")
    end

    binds[key] = action
    bindsdebug[key] = false
end

function binds_think()
    for i, v in pairs(binds) do
        if input.IsKeyDown(i) and not bindsdebug[i] then
            v()
            bindsdebug[i] = true
        elseif not input.IsKeyDown(i) then
            bindsdebug[i] = false
        end
    end
end
---------------------

local function create_convars()
	CreateClientConVar("ss_menu", "1", true, false)
	CreateClientConVar("ss_esp_text", "0", true, false)
	CreateClientConVar("ss_esp_xray", "0", true, false)
	CreateClientConVar("ss_esp_physgun", "0", true, false)
	CreateClientConVar("ss_esp_tracers", "0", true, false)
	CreateClientConVar("ss_misc_bhop", "0", true, false)
	CreateClientConVar("ss_xray_usewireframe", "1", true, false)
	CreateClientConVar("ss_fov", "90", true, false)
end

local function flip_convar(convar)
  if GetConVarNumber(convar) == 1 then RunConsoleCommand(convar, 0) end
  if GetConVarNumber(convar) == 0 then RunConsoleCommand(convar, 1) end
end
---menu creation
local function draw_pointer()
	
	draw.DrawText("-->", font, menu_X - 50, menu_pointer_Y, Color (255,255,255,255))
end

local function add_menuitem(text, _color, font, var, is_adjustable)
	
	draw.DrawText(text, font, menu_X, menu_Y, _color)
	if var != nil then
		table.insert(features_table, menu_Y .. " " .. text)	
		var_color = Color( 255, 255, 255, 255 )
		var_text = "???"
		if var == 1 || var == true then
			var_color = Color( 0, 255, 0, 255 )
			var_text = "ON"
		end
		if var == 0 || var == false then
			var_color = Color( 255, 0, 0, 255 )
		    var_text = "OFF" 
		end
		if is_adjustable == true then var_text = GetConVarNumber(var) end
	    draw.DrawText(var_text, font, menu_X + 300, menu_Y, var_color)
	end
	menu_Y = menu_Y + 30
end

local function draw_menu()
   features_table = {} 
   menu_X = 100
   menu_Y = 10 
   add_menuitem("Slash Scripts", Color( 187, 10, 252, 255), "custom_font2")
   if GetConVarNumber("ss_menu") != 1 then return end
   draw.DrawText("Hello " .. LocalPlayer():Nick() .. "!", "custom_font4", menu_X + 120, menu_Y - 30,Color( 12, 192, 252, 255) )
   add_menuitem("", Color( 187, 10, 252, 255), "custom_font2")
   add_menuitem("Visuals:", Color( 187, 10, 252, 255), "custom_font2")
   add_menuitem("ss_esp_text", ItemColour, font, GetConVarNumber("ss_esp_text"))
   add_menuitem("ss_esp_xray", ItemColour, font, GetConVarNumber("ss_esp_xray"))
   add_menuitem("ss_xray_usewireframe", ItemColour, font, GetConVarNumber("ss_xray_usewireframe"))
   add_menuitem("ss_esp_physgun", ItemColour, font, GetConVarNumber("ss_esp_physgun"))
   add_menuitem("ss_esp_tracers", ItemColour, font, GetConVarNumber("ss_esp_tracers"))
   add_menuitem("ss_fov", ItemColour, font, "ss_fov", true )
   add_menuitem("", Color( 187, 10, 252, 255), "custom_font2")
   add_menuitem("Misc:", Color( 187, 10, 252, 255), "custom_font2")
   add_menuitem("ss_misc_bhop", ItemColour, font, GetConVarNumber("ss_misc_bhop"))
end
---

---handle input
local function HandleUp()
	menu_pointer_Y = menu_pointer_Y - 30
end
 
local function HandleDown()
	menu_pointer_Y = menu_pointer_Y + 30
end

local function HandleFlip()
	for k,v in ipairs( features_table ) do
		v_split = string.Split(v, " ")
		if v_split[2] == "ss_fov" then
			 current_value = GetConVarNumber(v_split[2])
			 RunConsoleCommand(v_split[2], current_value + 10)
			 return 
		end
		
		if tostring(v_split[1]) == tostring(menu_pointer_Y) then
		   flip_convar(v_split[2])
		end 
	 end
end

local function HandleReverse()
	for k,v in ipairs( features_table ) do
		v_split = string.Split(v, " ")
		if v_split[2] == "ss_fov" then
			 current_value = GetConVarNumber(v_split[2])
		     RunConsoleCommand(v_split[2], current_value - 10)
		end
	 end
end
---
local function create_binds()
	addBind(KEY_UP, HandleUp)
	addBind(KEY_DOWN, HandleDown)
	addBind(KEY_RIGHT, HandleFlip)
	addBind(KEY_LEFT, HandleReverse)
end


---visual features
local function NoDrawPhysGun()
	if( IsValid( LocalPlayer():GetViewModel() ) ) then             
		LocalPlayer():GetViewModel():SetNoDraw( tobool(GetConVarNumber("ss_esp_physgun")) )     
	end
end

local esp_y = 0

local function ESP()
	for k, v in pairs( player.GetAll() ) do
		esp_y = 0
		local pos = ( v:GetShootPos() + Vector( 0, 0, LocalPlayer():GetShootPos():Distance( v:GetShootPos() ) / 30 ) ):ToScreen() -- thanks jynxx (or falco idk who did this first)
		
		if GetConVarNumber( "ss_esp_text" ) == 1  then
			esp_y = pos.y
			if v ~= LocalPlayer() and v:Health() > 0 and v:Team() ~= TEAM_SPECTATOR then 
			   draw.DrawText(v:Nick(), "custom_font3", pos.x, esp_y, Color(255,255,255,255))	   
			   esp_y = esp_y + 10
			   if v:IsTyping() == true then 
			      draw.DrawText("IsTyping", "custom_font3", pos.x, esp_y, Color(255,255,255,255))
			   end 

			end

		end


		if GetConVarNumber( "ss_esp_tracers" ) == 1 and v:Team() ~= TEAM_SPECTATOR  then
			cam.Start3D()
			if v ~= LocalPlayer() and v:Health() > 0 then 
				render.DrawLine(v:GetPos(), LocalPlayer():GetPos(), Color(255, 0, 0, 255))
			end
			cam.End3D()
		end
	end
end

local function FOV()
	local view = {}
	view.fov = GetConVarNumber("ss_fov")
	return view
end

local function xray()
	for i, v in pairs(ents.FindByClass("prop_physics")) do
		if GetConVarNumber( "ss_esp_xray" ) == 1 and not v:IsDormant() then
			cam.Start3D()
			cam.IgnoreZ(true)
			render.SuppressEngineLighting(true)
			render.SetBlend(0.55)
			render.SetColorModulation(1, 0, 0)
			v:DrawModel()
			v:SetRenderMode(RENDERMODE_TRANSALPHA)
			if GetConVarNumber( "ss_xray_usewireframe") == 1 then v:SetMaterial("models/wireframe") end
			if GetConVarNumber( "ss_xray_usewireframe") == 0 then v:SetMaterial("models/weapons/v_toolgun/screen_bg") end -- models/weapons/v_toolgun/screen_bg 
			v:SetColor(ColorAlpha(v:GetColor(), 0))
			render.MaterialOverride()
			render.SuppressEngineLighting(false)
			cam.End3D()
		end
	end

	for i, v in pairs(player.GetAll()) do
		if GetConVarNumber( "ss_esp_xray" ) == 1 and not v:IsDormant() then
			cam.Start3D()
			cam.IgnoreZ(true)
			render.SuppressEngineLighting(true)
			render.SetBlend(1)
			render.SetColorModulation(0, 1, 0)
			v:DrawModel()
			v:SetRenderMode(RENDERMODE_TRANSALPHA)
			v:SetMaterial("models/wireframe") -- models/weapons/v_toolgun/screen_bg 
			v:SetColor(ColorAlpha(v:GetColor(), 0))
			render.MaterialOverride()
			render.SuppressEngineLighting(false)
			cam.End3D()
		end
	end


end
---

---misc features

local function movement(cmd)
	if GetConVarNumber("ss_misc_bhop") == 1 then
      if LocalPlayer():IsOnGround() then return end
      if cmd:KeyDown(IN_JUMP) then
        cmd:RemoveKey(IN_JUMP)
	  end
    end
end

---

local function create_hooks()
	hook.Add("HUDPaint", "", draw_menu)
	hook.Add("HUDPaint", "Point", draw_pointer)
	hook.Add("HUDPaint", "Physgun", NoDrawPhysGun)
	hook.Add("HUDPaint", "ESP", ESP)
	hook.Add("Think", "", binds_think)
	hook.Add("HUDPaint", "xray", xray)
	hook.Add("CreateMove", "movement", movement)
	hook.Add("CalcView", "fov", FOV)
end

local function init()
	create_convars()
	create_binds()
	create_hooks()

	print("[SS] Loaded.")
end


init()
local function rotate()
	LocalPlayer():SetEyeAngles( Angle( LocalPlayer():EyeAngles().p, LocalPlayer():EyeAngles().y - 180, LocalPlayer():EyeAngles().r ) )
end
concommand.Add("rotateshot", function() -- creates a concommand with a function 
	if hook.GetTable().CalcView["180shot"] then -- will look through the hook table and if it finds 180shot then do
		rotate() -- rotate, which is above in my script, this is just calling its function
		hook.Remove("CalcView", "180shot") -- not entirely sure why its doing this, i think its doing this right after the 180shot has been done
		timer.Destroy("180shot") -- will remove the timer as 180shot has been done, I THINK
		return
	end

	hook.Add("CalcView", "180shot", function(ply, origin, angle, fov)
		local view = {} -- creating an empty table called view
		view.origin = origin -- adding origin too the viewe table
		view.angles = angle - Angle(0,180,0) -- adding angles in the view table with the vector angle 0 angle(0,180,0)
		view.fov = fov -- does nothing too the fov but adds the fov into the table

		if not LocalPlayer():KeyDown(IN_ATTACK) then -- it the local player isnt holding down the attack key then
			hook.Remove("CalcView", "180shot") -- removes the hook cause the player isnt holding the attack key
			rotate() -- will rotate
			timer.Destroy("180shot") -- will remove the timer as 180shot has been done, I THINK
		end

		return view -- returns the view table with all the new shit it has to do 
	end)
	rotate() -- rotates
	timer.Create("180shot", 5, 1, function() -- creates a timer with a function
		hook.Remove("CalcView", "180shot") -- removes the hook as 180shot hsa been done
		rotate() -- rotates
	end)
end)
-- im very confused on a fair bit of this, as i get better at lua ill learn how to do all this myself, but for now this will work
