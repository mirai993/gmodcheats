--[[
	lua/WIP_Hack.lua
	SimpleIsTheBest | (STEAM_0:1:60333045)
	===DStream===
]]

--[[
Credits:
Mr. OverDone - The Hack
Kelse - No Spread Module
Tyler - Some Coding
HeX - Help
--]]

-- Don't run this on the server
if ( not CLIENT ) then
	chat.AddText(Color(255, 0, 0, 255), 'Running Server-Side' )
else
	chat.AddText(Color(0, 255, 0, 255), 'Running Client-Side' )
end

------------------
require('cvar3')
------------------

-- Locals
local WIP 			= {}
local G		 		= table.Copy( _G )
local ents 			= _G.ents
WIP.version			= "1.3.2"
WIP.hooks					= {}
WIP.concommands			= {}
WIP.convars				= {} 
WIP.timers					= {}
WIP.spectators				= {}
WIP.admins					= {} 
WIP.version				= "4.2.7"
WIP.log					= {}
WIP.files					= {"WIP.lua","log.txt","gmcl_cvar3_win32.dll","gmcl_hera_win32.dll"}
WIP.traitors				= {}

local _G					= table.Copy( _G )
local _R					= _G.debug.getregistry()

local math 					= _G.math
local string 				= _G.string
local hook 					= _G.hook
local table 				= _G.table
local timer 				= _G.timer
local surface 				= _G.surface
local concommand 			= _G.concommand
local cvars 				= _G.cvars
local ents 					= _G.ents
local player 				= _G.player
local team 					= _G.team
local util 					= _G.util
local draw 					= _G.draw
local usermessage 			= _G.usermessage
local vgui 					= _G.vgui
local http 					= _G.http
local cam 					= _G.cam
local render 				= _G.render

local MsgN 					= _G.MsgN
local Msg 					= _G.Msg
local Vector 				= _G.Vector
local Angle 				= _G.Angle
local pairs 				= _G.pairs
local ipairs 				= _G.ipairs
local CreateSound 			= _G.CreateSound
local setmetatable 			= _G.setmetatable
local Sound 				= _G.Sound
local print 				= _G.print
local pcall 				= _G.pcall
local type 					= _G.type
local LocalPlayer 			= _G.LocalPlayer
local KeyValuesToTable 		= _G.KeyValuesToTable
local TableToKeyValues 		= _G.TableToKeyValues
local Color 				= _G.Color
local CreateClientConVar 	= _G.CreateClientConVar
local ErrorNoHalt 			= _G.ErrorNoHalt
local IsValid 				= _G.IsValid
local CreateMaterial 		= _G.CreateMaterial
local tonumber 				= _G.tonumber
local tostring 				= _G.tostring
local CurTime			 	= _G.CurTime
local FrameTime 			= _G.FrameTime
local ScrW 					= _G.ScrW
local ScrH 					= _G.ScrH
local SetClipboardText 		= _G.SetClipboardText
local GetHostName 			= _G.GetHostName
local unpack 				= _G.unpack
local AddConsoleCommand 	= _G.AddConsoleCommand 
local require				= _G.require
local include				= _G.include

local MOVETYPE_OBSERVER 	= _G.MOVETYPE_OBSERVER
local MOVETYPE_NONE 		= _G.MOVETYPE_NONE
local TEXT_ALIGN_LEFT 		= _G.TEXT_ALIGN_LEFT
local TEXT_ALIGN_TOP 		= _G.TEXT_ALIGN_TOP
local TEXT_ALIGN_RIGHT 		= _G.TEXT_ALIGN_RIGHT
local TEXT_ALIGN_BOTTOM		= _G.TEXT_ALIGN_BOTTOM
local IN_JUMP 				= _G.IN_JUMP
local IN_FORWARD 			= _G.IN_FORWARD
local IN_BACK 				= _G.IN_BACK
local IN_MOVERIGHT 			= _G.IN_MOVERIGHT
local IN_MOVELEFT 			= _G.IN_MOVELEFT
local IN_SPEED 				= _G.IN_SPEED
local IN_DUCK 				= _G.IN_DUCK
local TEAM_SPECTATOR 		= 1002

-- old [copy]
local old_filecdir 			= file.CreateDir;
local old_filedel 			= file.Delete;
local old_fileexist 		= file.Exists;
local old_fileexistex 		= file.ExistsEx;
local old_filefind 			= file.Find;
local old_filefinddir 		= file.FindDir;
local old_filefindil 		= file.FindInLua;
local old_fileisdir			= file.IsDir;
local old_fileread 			= file.Read;
local old_filerename 		= file.Rename;
local old_filesize 			= file.Size;
local old_filetfind			= file.TFind;
local old_filetime 			= file.Time;
local old_filewrite 		= file.Write;
local old_dbginfo 			= debug.getinfo;
local old_dbginfo 			= debug.getupvalue;
local old_timerc			= timer.Create;
local old_cve 				= ConVarExists;
local old_gcv 				= GetConVar;
local old_gcvn 				= GetConVarNumber;
local old_gcvs 				= GetConVarString;
local old_rcc 				= RunConsoleCommand;
local old_hookadd			= hook.Add;
local old_hookrem 			= hook.Remove;
local old_ccadd				= concommand.Add;
local old_ccrem 			= concommand.Remove;
local old_cvaracc 			= cvars.AddChangeCallback;
local old_cvargcvc 			= cvars.GetConVarCallbacks;
local old_cvarchange 		= cvars.OnConVarChanged;
local old_require			= require;
local old_eccommand 		= engineConsoleCommand;
local old_rs				= RunString;
local old_ccmd				= _R.Player.ConCommand;
local old_include			= include;
local old_usermsginc		= usermessage.IncomingMessage;

-- Tables
local Colors		= {}
Red							= Color(255,0,0,255);
Black						= Color(0,0,0,255);
Green						= Color(0,255,0,255);
White						= Color(255,255,255,255);
Blue						= Color(0,0,255,255);
Cyan						= Color(0,255,255,255);
Pink 						= Color(255,0,255,255);
Blue						= Color(0,0,255,255);
Grey						= Color(100,100,100,255);
Gold						= Color(255,228,0,255);
Lblue						= Color(155,205,248);
Lgreen						= Color(174,255,0);
Iceblue						= Color(116,187,251,255);

WIP.espbones = {
{ S = "ValveBiped.Bip01_Head1", E = "ValveBiped.Bip01_Neck1" },
{ S = "ValveBiped.Bip01_Neck1", E = "ValveBiped.Bip01_Spine4" },
{ S = "ValveBiped.Bip01_Spine4", E = "ValveBiped.Bip01_Spine2" },
{ S = "ValveBiped.Bip01_Spine2", E = "ValveBiped.Bip01_Spine1" },
{ S = "ValveBiped.Bip01_Spine1", E = "ValveBiped.Bip01_Spine" },
{ S = "ValveBiped.Bip01_Spine", E = "ValveBiped.Bip01_Pelvis" },
{ S = "ValveBiped.Bip01_Spine4", E = "ValveBiped.Bip01_L_UpperArm" },
{ S = "ValveBiped.Bip01_L_UpperArm", E = "ValveBiped.Bip01_L_Forearm" },
{ S = "ValveBiped.Bip01_L_Forearm", E = "ValveBiped.Bip01_L_Hand" },
{ S = "ValveBiped.Bip01_Spine4", E = "ValveBiped.Bip01_R_UpperArm" },
{ S = "ValveBiped.Bip01_R_UpperArm", E = "ValveBiped.Bip01_R_Forearm" },
{ S = "ValveBiped.Bip01_R_Forearm", E = "ValveBiped.Bip01_R_Hand" },
{ S = "ValveBiped.Bip01_Pelvis", E = "ValveBiped.Bip01_L_Thigh" },
{ S = "ValveBiped.Bip01_L_Thigh", E = "ValveBiped.Bip01_L_Calf" },
{ S = "ValveBiped.Bip01_L_Calf", E = "ValveBiped.Bip01_L_Foot" },
{ S = "ValveBiped.Bip01_L_Foot", E = "ValveBiped.Bip01_L_Toe0" },
{ S = "ValveBiped.Bip01_Pelvis", E = "ValveBiped.Bip01_R_Thigh" },
{ S = "ValveBiped.Bip01_R_Thigh", E = "ValveBiped.Bip01_R_Calf" },
{ S = "ValveBiped.Bip01_R_Calf", E = "ValveBiped.Bip01_R_Foot" },
{ S = "ValveBiped.Bip01_R_Foot", E = "ValveBiped.Bip01_R_Toe0" },
}

WIP.ents					= { -- ents to be picked up by entity esp, add more if you want.
"ent_pot",
"npc_vendor",
"weapon_perp_glock",
"ent_item",
"ent_prop_item",
"sent_spawnpoint",
"spawned_weapon",
"spawned_shipment",
"weed_plant",
"gift",
"spawned_money",
"base_item",
"weapon_ak47_dayz",
"weapon_mp5_dayz",
"weapon_deagle_dayz",
"sapphire_money_printer",
"amethyst_money_printer",
"topaz_money_printer",
"emerald_money_printer",
"msc_scrapnug",
"food_rawant",
"ent_resource",
"food_rawhead",
"gmodz_item", -- TPS DayZ
"drug",
}


-- CreateConVars
CreateClientConVar('WIP_ESP_Distance', 	1000, true, false)
CreateClientConVar('WIP_ESP_Info', 		0, true, false)
CreateClientConVar('WIP_ESP_Box', 		1, true, false)
CreateClientConVar('WIP_ESP_Box_Type', 	'3d', true, false)
CreateClientConVar('WIP_ESP_Skeleton', 0, true, false)
CreateClientConVar('WIP_ESP_Laser', 0, true, false)
CreateClientConVar('WIP_ESP_Crosshair', 0, true, false)
CreateClientConVar('WIP_ESP_Crosshair_Type', 'Swastika', true, false)

-- Chat
-- ChatAdd
function WIP.ChatAdd(msg)
	print("[WIP] "..msg)
end

function WIP.ChatAdd(dosound,col,msg)
	if col then
		col = col
	end
chat.AddText( 
iceblue, 
"[WIP] ", 
col, msg)
if dosound == sound then
		local beep = Sound( "/buttons/button17.wav" )
		local beepsound = CreateSound( LocalPlayer(), beep )
		beepsound:Play()
	end
end

-- CheckUpdate
function WIP:CheckUpdate()
WIP.ChatAdd("Checking cheat version...")
	http.Fetch("https://dl.dropboxusercontent.com/u/91139226/WIP/version.txt", function(body, len, headers, code) 
		if body == WIP.version then 
			WIP.ChatAdd(sound, green, "Your version of WIP is up to date! You are currently running veresion "..WIP.version) 
		else
			WIP.ChatAdd(sound, red, "Your version of WIP is outdated! Please update to version "..body)
		end 
	end)
end
WIP:CheckUpdate()

function WIP:DoUpdate()
	WIP.ChatAdd(false, green, "Please visit https://dl.dropbox.com/u/150309237/WIP/WIP.lua for the latest update of the cheat.")
end


--[[ 
Pos 
Credits:
Tyler
BaconBot
--]]
function WIP:CreatePos(e)
local ply = LocalPlayer()
local ang = Angle( 0, LocalPlayer():EyeAngles().y, 0 )
local nom = e:GetPos()
local center = e:LocalToWorld( e:OBBCenter() )
local min, max = e:OBBMins(), e:OBBMaxs()
local dim = max - min	local z = max + min	
local frt	= ( e:GetForward() ) * ( dim.y / 2 )
local rgt	= ( e:GetRight() ) * ( dim.x / 2 )
local top	= ( e:GetUp() ) * ( dim.z / 2 )
local bak	= ( e:GetForward() * -1 ) * ( dim.y / 2 )
local lft	= ( e:GetRight() * -1 ) * ( dim.x / 2 )
local btm	= ( e:GetUp() * -1 ) * ( dim.z / 2 )
local s = 1
local FRT 	= center + frt / s + rgt / s + top / s; FRT = FRT:ToScreen()
local BLB 	= center + bak / s + lft / s + btm / s; BLB = BLB:ToScreen()
local FLT	= center + frt / s + lft / s + top / s; FLT = FLT:ToScreen()
local BRT 	= center + bak / s + rgt / s + top / s; BRT = BRT:ToScreen()
local BLT 	= center + bak / s + lft / s + top / s; BLT = BLT:ToScreen()
local FRB 	= center + frt / s + rgt / s + btm / s; FRB = FRB:ToScreen()
local FLB 	= center + frt / s + lft / s + btm / s; FLB = FLB:ToScreen()
local BRB 	= center + bak / s + rgt / s + btm / s; BRB = BRB:ToScreen()	
local z = 100
if ( e:Health() <= 50 ) then z = 100 end
local x, y = ( ( e:Health() / 100 ) ), 1
if ( e:Health() <= 0 ) then x = 1 end
local FRT3 	= center + frt + rgt + top / x; FRT3 = FRT3; FRT3 = FRT3:ToScreen()
local BLB3 	= center + bak + lft + btm / x; BLB3 = BLB3; BLB3 = BLB3:ToScreen()
local FLT3	= center + frt + lft + top / x; FLT3 = FLT3; FLT3 = FLT3:ToScreen()
local BRT3 	= center + bak + rgt + top / x; BRT3 = BRT3; BRT3 = BRT3:ToScreen()
local BLT3 	= center + bak + lft + top / x; BLT3 = BLT3; BLT3 = BLT3:ToScreen()
local FRB3 	= center + frt + rgt + btm / x; FRB3 = FRB3; FRB3 = FRB3:ToScreen()
local FLB3 	= center + frt + lft + btm / x; FLB3 = FLB3; FLB3 = FLB3:ToScreen()
local BRB3 	= center + bak + rgt + btm / x; BRB3 = BRB3; BRB3 = BRB3:ToScreen()	
local x, y, z = 1.1, 0.9, 1
local FRT2 	= center + frt / y + rgt / z + top / x; FRT2 = FRT2:ToScreen()
local BLB2 	= center + bak / y + lft / z + btm / x; BLB2 = BLB2:ToScreen()
local FLT2	= center + frt / y + lft / z + top / x; FLT2 = FLT2:ToScreen()
local BRT2 	= center + bak / y + rgt / z + top / x; BRT2 = BRT2:ToScreen()
local BLT2 	= center + bak / y + lft / z + top / x; BLT2 = BLT2:ToScreen()
local FRB2 	= center + frt / y + rgt / z + btm / x; FRB2 = FRB2:ToScreen()
local FLB2 	= center + frt / y + lft / z + btm / x; FLB2 = FLB2:ToScreen()
local BRB2 	= center + bak / y + rgt / z + btm / x; BRB2 = BRB2:ToScreen()	
local maxX = math.max( FRT.x,BLB.x,FLT.x,BRT.x,BLT.x,FRB.x,FLB.x,BRB.x )
local minX = math.min( FRT.x,BLB.x,FLT.x,BRT.x,BLT.x,FRB.x,FLB.x,BRB.x )
local maxY = math.max( FRT.y,BLB.y,FLT.y,BRT.y,BLT.y,FRB.y,FLB.y,BRB.y )
local minY = math.min( FRT.y,BLB.y,FLT.y,BRT.y,BLT.y,FRB.y,FLB.y,BRB.y )
local minYhp2 = math.min( FRT.y,BLB.y,FLT.y,BRT.y,BLT.y,FRB.y,FLB.y,BRB.y )
local maxXhp = math.max( FRT3.x,BLB3.x,FLT3.x,BRT3.x,BLT3.x,FRB3.x,FLB3.x,BRB3.x )
local minXhp = math.min( FRT3.x,BLB3.x,FLT3.x,BRT3.x,BLT3.x,FRB3.x,FLB3.x,BRB3.x )
local maxYhp = math.max( FRT3.y,BLB3.y,FLT3.y,BRT3.y,BLT3.y,FRB3.y,FLB3.y,BRB3.y )
local minYhp = math.min( FRT3.y,BLB3.y,FLT3.y,BRT3.y,BLT3.y,FRB3.y,FLB3.y,BRB3.y )	
local maxX2 = math.max( FRT2.x,BLB2.x,FLT2.x,BRT2.x,BLT2.x,FRB2.x,FLB2.x,BRB2.x )
local minX2 = math.min( FRT2.x,BLB2.x,FLT2.x,BRT2.x,BLT2.x,FRB2.x,FLB2.x,BRB2.x )
local maxY2 = math.max( FRT2.y,BLB2.y,FLT2.y,BRT2.y,BLT2.y,FRB2.y,FLB2.y,BRB2.y )
local minY2 = math.min( FRT2.y,BLB2.y,FLT2.y,BRT2.y,BLT2.y,FRB2.y,FLB2.y,BRB2.y )
local mon = nom + Vector( 0, 0, LocalPlayer():OBBMaxs()[3] )			
local BOXPOS1 = Vector( 16, 16, 0 )
BOXPOS1:Rotate( ang )
BOXPOS1 = ( nom + BOXPOS1 ):ToScreen()
local BOXPOS2 = Vector( 16, -16, 0 )
BOXPOS2:Rotate( ang )
BOXPOS2 = ( nom + BOXPOS2 ):ToScreen()
local BOXPOS3 = Vector( -16, -16, 0 )
BOXPOS3:Rotate( ang )
BOXPOS3 = ( nom + BOXPOS3 ):ToScreen()
local BOXPOS4 = Vector( -16, 16, 0 )
BOXPOS4:Rotate( ang )
BOXPOS4 = ( nom + BOXPOS4 ):ToScreen()
local BOXPOS5 = Vector( 16, 16, 0 )
BOXPOS5:Rotate( ang )
BOXPOS5 = ( mon + BOXPOS5 ):ToScreen()
local BOXPOS6 = Vector( 16, -16, 0 )
BOXPOS6:Rotate( ang )
BOXPOS6 = ( mon + BOXPOS6 ):ToScreen()
local BOXPOS7 = Vector( -16, -16, 0 )
BOXPOS7:Rotate( ang )
BOXPOS7 = ( mon + BOXPOS7 ):ToScreen()
local BOXPOS8 = Vector( -16, 16, 0 )
BOXPOS8:Rotate( ang )
BOXPOS8 = ( mon + BOXPOS8 ):ToScreen()
return maxX, minX, maxY, minY, maxX2, minX2, maxY2, minY2, minYhp, maxYhp, BOXPOS1, BOXPOS2, BOXPOS3, BOXPOS4, BOXPOS5, BOXPOS6, BOXPOS7, BOXPOS8
end

/*************************************
Name: PlayerVisible
Purpose: Check if a player is visible
*************************************/
local function CanSee(ent)    
	local tr = {};	
	tr.start = LocalPlayer():GetShootPos();
	tr.endpos = ent:GetPos() + Vector(0, 0, 5)
	tr.filter = {LocalPlayer(), ent};
	tr.mask = MASK_SHOT;	
    local trace = util.TraceLine(tr) ;
    if (trace.Fraction == 1) then 
        return true;
    else 
        return false; 
    end     
end

/**********************************
Name: GetColors
Purpose: Make a cool color!
***********************************/
local function GetColorCrosshair()
	if LocalPlayer():GetEyeTrace().Entity:IsPlayer() then
		return 0,255,0,255
	end
	if LocalPlayer():GetEyeTrace().Entity:IsNPC() then
		return 0,0,255,255
	end
	return team.GetColor(LocalPlayer():Team())
end

local function GetColorVisible(e)
	if CanSee(e) then
		return 0,255,0,255
	end
	if !CanSee(e) then
		return 255,0,0,255
	end
end

/*********************
Name: IsVehicle
Purpose: Find vehicles
*********************/
function WIP.IsVehicle( e )	
	local ply = LocalPlayer()	
	if ( string.find( e:GetClass(), "prop_vehicle_" ) && ply:GetMoveType() ~= 0 ) then
		return true
	end
	return false
end

/***************************
Name: SetColors
Purpose: Set Colors
****************************/
function WIP:IsCustomEnt( entclass )
	return table.HasValue( WIP.ents, entclass )
end

function SetColors(e)
	local ply, class, model = LocalPlayer(), e:GetClass(), e:GetModel()
	local col	
	if ( e:IsPlayer() ) then
		col = Color(0,255,0,255)
	elseif ( e:IsNPC() ) then 
		col = Color( 255, 0, 0, 20 )		
	elseif WIP:IsCustomEnt( e:GetClass() ) then
		col = Color( 0, 200, 255, 50 )		
	else
		col = Color( 255, 255, 255, 255 )		
	end	
	return col
end

-- OnScreen and IsCloseEnough check
function OnScreen(ent)
	local a, f = debug.getregistry().Player["GetAimVector"](LocalPlayer()):Angle() - (ent:GetPos() - LocalPlayer():GetShootPos()):Angle(), debug.getregistry().Player["GetFOV"](LocalPlayer())	
	return (math.NormalizeAngle(a.y) < f + 2 && math.NormalizeAngle(a.p) < f + 2)
end
function IsCloseEnough(ent)
	local dist = ent:GetPos():Distance( LocalPlayer():GetPos() )
	if( dist <= GetConVarNumber("WIP_ESP_Distance") and ent:GetPos() != Vector( 0, 0, 0 ) ) then
		return true
	end
	return false	
end

--[[ 
Name: Main Core ESP
--]]

-- Box Color
local function GetBoxColor(e)
	if Aimon == 1 and LockedTarg != nil and LockedTarg == e then
		return Color(0,255,255)
	elseif CanSee(e) then
		return Color(0,255,0)
	elseif !CanSee(e) then
		return Color(255,0,0)
	else
		return Color(255,255,255)
	end
end

-- ESP
WIP.ents					= { -- ents to be picked up by entity esp, add more if you want.
"ent_pot",
"npc_vendor",
"weapon_perp_glock",
"ent_item",
"ent_prop_item",
"sent_spawnpoint",
"spawned_weapon",
"spawned_shipment",
"weed_plant",
"gift",
"spawned_money",
"base_item",
"weapon_ak47_dayz",
"weapon_mp5_dayz",
"weapon_deagle_dayz",
"sapphire_money_printer",
"amethyst_money_printer",
"topaz_money_printer",
"emerald_money_printer",
"msc_scrapnug",
"food_rawant",
"ent_resource",
"food_rawhead",
"gmodz_item", -- TPS DayZ
"drug_plant",
}


function ESP()
for k, e in pairs( player.GetAll() ) do
local TeamColor = team.GetColor(e:Team())
local HPColor;
local Dist = e:GetPos():Distance(LocalPlayer():GetPos());
local wep = "Unknown"
local SteamID = e:SteamID()
local Name = e:Nick()
local InfoCol = white
local maxX, minX, maxY, minY, maxX2, minX2, maxY2, minY2, minYhp, maxYhp, BOXPOS1, BOXPOS2, BOXPOS3, BOXPOS4, BOXPOS5, BOXPOS6, BOXPOS7, BOXPOS8 = WIP:CreatePos( e )

if( GetConVar('WIP_ESP_Info') == 1 && IsCloseEnough(v) ) then
draw.SimpleTextOutlined( "Name", "TabLarge", maxX2, minY2, TeamColor, 4, 1, 1, Black)
draw.SimpleTextOutlined( "Health: " .. e:Health(), "TabLarge", maxX2, minY2 + 10, TeamColor, 4,1, 1, Black )
draw.SimpleTextOutlined( "Distance: " .. math.floor(Dist), "TabLarge", maxX2, minY2 + 20, TeamColor, 4, 1, 1, Black )
if e:IsAdmin() then
draw.SimpleTextOutlined( "Distance: " .. math.floor(Dist), "TabLarge", maxX2, minY2 + 30, Red, 4, 1, 1, Black )
if e:GetFriendStatus() == 'friend' then
draw.SimpleTextOutlined( "Distance: " .. math.floor(Dist), "TabLarge", maxX2, minY2 + 4, Blue, 4, 1, 1, Black )
end
end
end
if GetConVarNumber("WIP_ESP_Box") == 1 && IsCloseEnough(e) then
	if GetConVarString("WIP_ESP_Box_Type") == "2d" then
		surface.SetDrawColor(GetBoxColor(e))				
		surface.DrawLine( maxX, maxY, maxX, minY )
		surface.DrawLine( maxX, minY, minX, minY )					
		surface.DrawLine( minX, minY, minX, maxY )
		surface.DrawLine( minX, maxY, maxX, maxY )
	elseif GetConVarString("WIP_ESP_Box_Type") == "3d" then	
		surface.SetDrawColor(GetBoxColor(e))
		-- thanks nano
		surface.DrawLine( BOXPOS1.x, BOXPOS1.y, BOXPOS2.x, BOXPOS2.y )
		surface.DrawLine( BOXPOS2.x, BOXPOS2.y, BOXPOS3.x, BOXPOS3.y )
		surface.DrawLine( BOXPOS3.x, BOXPOS3.y, BOXPOS4.x, BOXPOS4.y )
		surface.DrawLine( BOXPOS4.x, BOXPOS4.y, BOXPOS1.x, BOXPOS1.y )
		
		surface.DrawLine( BOXPOS5.x, BOXPOS5.y, BOXPOS6.x, BOXPOS6.y )
		surface.DrawLine( BOXPOS6.x, BOXPOS6.y, BOXPOS7.x, BOXPOS7.y )
		surface.DrawLine( BOXPOS7.x, BOXPOS7.y, BOXPOS8.x, BOXPOS8.y )
		surface.DrawLine( BOXPOS8.x, BOXPOS8.y, BOXPOS5.x, BOXPOS5.y )
			
		surface.DrawLine( BOXPOS1.x, BOXPOS1.y, BOXPOS5.x, BOXPOS5.y )
		surface.DrawLine( BOXPOS2.x, BOXPOS2.y, BOXPOS6.x, BOXPOS6.y )
		surface.DrawLine( BOXPOS3.x, BOXPOS3.y, BOXPOS7.x, BOXPOS7.y )
		surface.DrawLine( BOXPOS4.x, BOXPOS4.y, BOXPOS8.x, BOXPOS8.y )
	end
end
	if GetConVarNumber("WIP_ESP_Skeleton") == 1 && IsCloseEnough(e) then
		for k, v in pairs( WIP.espbones ) do
			local sPos, ePos = e:GetBonePosition( e:LookupBone( v.S ) ):ToScreen(), e:GetBonePosition( e:LookupBone( v.E ) ):ToScreen()
				if e:IsPlayer() and !e:IsNPC() then
					surface.SetDrawColor(team.GetColor(e:Team()))
				end
					surface.DrawLine(sPos.x,sPos.y,ePos.x,ePos.y)
				end
			end
				-- ESP TRACER --
				if GetConVarNumber("WIP_ESP_Laser") == 1 and LocalPlayer():Alive() then
					local LaserColor = Color(255,0,0,255)
				if Aimon == 1 and LockedTarg != nil and LockedTarg != LocalPlayer() then
					LaserColor = Color(0,255,0,255)
				else
					LaserColor = LaserColor
						end
				local ViewModel = LocalPlayer():GetViewModel()
				local Attach = ViewModel:LookupAttachment("1")
				if ( Attach == 0 ) then Attach = ViewModel:LookupAttachment("muzzle") end
				if !LocalPlayer():Alive() then return end;
				if( LocalPlayer():Alive() || LocalPlayer():GetActiveWeapon() == NULL ) then
				if( !table.HasValue( WIP.laser, LocalPlayer():GetActiveWeapon():GetClass() ) ) then
				local tr = util.TraceLine(util.GetPlayerTrace(LocalPlayer()));
				cam.Start3D( EyePos() , EyeAngles())								
				-- Laser
				StartPos = ViewModel:GetAttachment( Attach ).Pos
				EndPos = LocalPlayer():GetEyeTrace().HitPos
				render.SetMaterial( Material( "trails/laser" ) )
				render.DrawBeam(StartPos, EndPos , 3, 0, 0, LaserColor)								
				-- End
				render.SetMaterial(Material("Sprites/light_glow02_add_noz"))
				render.DrawQuadEasy(tr.HitPos, (EyePos() - tr.HitPos), 10, 10, LaserColor, 0 )
			cam.End3D()
		end
	end
end
							
							-- ESP CROSSHAIR --
if GetConVarNumber("WIP_ESP_Crosshair") == 1 and GetConVarNumber("WIP_MISC_Thirdperson") == 0 then
	if GetConVarString("WIP_ESP_Crosshair_Type") == "Spinning" then
		local x, y = ScrW() / 2, ScrH() / 2	
		local Speed
		surface.SetDrawColor(GetColorCrosshair()) 
		CHPosx = math.Clamp(LocalPlayer():GetEyeTrace().HitPos:ToScreen().x,0,ScrW())
		CHPosy = math.Clamp(LocalPlayer():GetEyeTrace().HitPos:ToScreen().y,0,ScrH())
		mathsin = math.sin(CurTime()*Speed)*4
		mathcos = math.cos(CurTime()*Speed)*4
		mathsin2 = math.sin(CurTime()*Speed+0.1)*4
		mathcos2 = math.cos(CurTime()*Speed+0.1)*4
		mathsin3 = math.sin(CurTime()*Speed-0.1)*4
		mathcos3 = math.cos(CurTime()*Speed-0.1)*4
		surface.DrawLine( CHPosx+mathcos*2,CHPosy+mathsin*2,CHPosx+mathcos*5,CHPosy+mathsin*5 );
		surface.DrawLine( CHPosx-mathcos*2,CHPosy-mathsin*2,CHPosx-mathcos*5,CHPosy-mathsin*5 );
		surface.DrawLine( CHPosx+mathsin*2,CHPosy-mathcos*2,CHPosx+mathsin*5,CHPosy-mathcos*5 );
		surface.DrawLine( CHPosx-mathsin*2,CHPosy+mathcos*2,CHPosx-mathsin*5,CHPosy+mathcos*5 );
	elseif GetConVarString("WIP_ESP_Crosshair_Type") == "Swastika" then
		surface.SetDrawColor(red)
		surface.DrawLine(ScrW()/2, ScrH()/2, ScrW()/2 + 20, ScrH()/2)
		surface.DrawLine(ScrW()/2 + 20, ScrH()/2, ScrW()/2 + 20, ScrH()/2 + 20)
		surface.DrawLine(ScrW()/2 , ScrH()/2, ScrW()/2 - 20, ScrH()/2)
		surface.DrawLine(ScrW()/2 - 20 , ScrH()/2, ScrW()/2 - 20, ScrH()/2 - 20)
		surface.DrawLine(ScrW()/2, ScrH()/2, ScrW()/2, ScrH()/2 - 20)
		surface.DrawLine(ScrW()/2, ScrH()/2 - 20, ScrW()/2 + 20, ScrH()/2 - 20)
		surface.DrawLine(ScrW()/2, ScrH()/2, ScrW()/2, ScrH()/2 + 20)
		surface.DrawLine(ScrW()/2, ScrH()/2 + 20, ScrW()/2 - 20, ScrH()/2 + 20)
	elseif GetConVarString("WIP_ESP_Crosshair_Type") == "Basic" then
		local x, y, s = ScrW() / 2, ScrH() / 2, 10
		surface.SetDrawColor(GetColorCrosshair()) 
		surface.DrawLine( x, y - s, x, y + s )
		surface.DrawLine( x - s, y, x + s, y )
	elseif GetConVarString("WIP_ESP_Crosshair_Type") == "Diagonal" then
		local x, y, w = ScrW() / 2, ScrH() / 2, 7
		surface.SetDrawColor(GetColorCrosshair()) 
		surface.DrawLine(x - w, y - w, x + w, y + w)
		surface.DrawLine(x - w, y + w, x + w, y - w)									
	end
end
end
end
hook.Add('HUDPaint', 'ESPShit', ESP)
