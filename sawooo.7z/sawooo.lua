local ang;
local besttar = false 
local me = LocalPlayer()
local fov = 100
local slient = true
local aim = true
local enabled = true 
local smoothness = 5 
local aimBone = "ValveBiped.Bip01_Head1" 
local aimKey = KEY_F 
local accuracy = 0.01 

hook.Add("Think", "Aimbot", function()
    if enabled and input.IsKeyDown(aimKey) then
        local ply = LocalPlayer()
        local target = ply:GetEyeTrace().Entity
        
        if IsValid(target) and target:IsPlayer() then
            local headPos = target:GetBonePosition(target:LookupBone(aimBone))
            local angles = (headPos - ply:EyePos()):Angle()
            ply:SetEyeAngles(Lerp(smoothness * FrameTime(), ply:EyeAngles(), angles))
        end
    end
end)

hook.Add("CreateMove", "FixMovement", function(cmd)
    if enabled and input.IsKeyDown(aimKey) then
        cmd:SetForwardMove(0)
        cmd:SetSideMove(0)
    end
end)

if slient == true and aim == true then
hook.Add("CreateMove", "", function(ucmd)
	if(!ang) then ang = ucmd:GetViewAngles(); end
	ang = ang + Angle(ucmd:GetMouseY() * .023, ucmd:GetMouseX() * -.023, 0);
	ang.x = math.NormalizeAngle(ang.x);
	ang.p = math.Clamp(ang.p, -89, 89);
	if(ucmd:CommandNumber() == 0) then
		ucmd:SetViewAngles(ang);
		return;
	end
	local target = nil

hook.Add("CreateMove", "sawooo", function(cmd)
    besttar = false 

        local plys = player.GetAll()
        local bestdistance = math.huge 

        for i = 1, #plys do
            if plys[i] == me or not plys[i]:Alive() or plys[i]:IsDormant() then continue end 

            local tr = util.TraceLine({
                start = me:EyePos(),
                endpos = plys[i]:GetPos() + plys[i]:OBBCenter(),
                filter = me,
                mask = MASK_SHOT,
            })

            if tr.Entity ~= plys[i] then continue end

            if (plys[i]:GetPos()):DistToSqr(me:GetPos()) < bestdistance then
                besttar = plys[i]
            end
        end


    if not besttar then return end 

    if not me:Alive() or not IsValid(me) then return end 

    local w = me:GetActiveWeapon() 

    if not IsValid(w) then return end
    if not w.GetShootPosAndDir then return end 

    local enemyPos = besttar:GetBonePosition(besttar:LookupBone("ValveBiped.Bip01_Head1"))
    local eyePos = me:EyePos() 
    local shootpos, shootdir, dirangle = w:GetShootPosAndDir()

    local diff = dirangle - cmd:GetViewAngles()
    diff:Normalize()

    local ang = (enemyPos - shootpos):Angle() - diff
    ang:Normalize()
    ang.r = 0 

    local viewAng = (enemyPos - shootpos):GetNormalized():Angle()
    local fovDiff = math.abs(math.AngleDifference(viewAng.yaw, cmd:GetViewAngles().yaw))
    if fovDiff > fov then
        return
    end

    cmd:SetViewAngles(ang)
end)
end);

end

if slient == false and aim == true then

hook.Add("CreateMove", "sawooo", function(cmd)
    besttar = false 
 if input.IsKeyDown(KEY_F) then
        local plys = player.GetAll()
        local bestdistance = math.huge 

        for i = 1, #plys do
            if plys[i] == me or not plys[i]:Alive() or plys[i]:IsDormant() then continue end 

            local tr = util.TraceLine({
                start = me:EyePos(),
                endpos = plys[i]:GetPos() + plys[i]:OBBCenter(),
                filter = me,
                mask = MASK_SHOT,
            })

            if tr.Entity ~= plys[i] then continue end

            if (plys[i]:GetPos()):DistToSqr(me:GetPos()) < bestdistance then
                besttar = plys[i]
            end
        end
    end


    if not besttar then return end 

    if not me:Alive() or not IsValid(me) then return end 

    local w = me:GetActiveWeapon() 

    if not IsValid(w) then return end
    if not w.GetShootPosAndDir then return end 

    local enemyPos = besttar:GetBonePosition(besttar:LookupBone("ValveBiped.Bip01_Neck1"))
    local eyePos = me:EyePos() 
    local shootpos, shootdir, dirangle = w:GetShootPosAndDir()

    local diff = dirangle - cmd:GetViewAngles()
    diff:Normalize()

    local ang = (enemyPos - shootpos):Angle() - diff
    ang:Normalize()
    ang.r = 0 

    local viewAng = (enemyPos - shootpos):GetNormalized():Angle()
    local fovDiff = math.abs(math.AngleDifference(viewAng.yaw, cmd:GetViewAngles().yaw))
    if fovDiff > fov then
        return
    end

    cmd:SetViewAngles(ang)
end)
else
	hook.Remove("CreateMove", "sawooo")
end