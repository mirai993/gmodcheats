-- LMAOBOX FOR GMOD BY LENN
-- This is for my friends. do not send to anyone without my permission.








if loadcheatdenied == 5 then
for i = 1,500 do
print("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n")
end
error("Could not open, read, write to the directory")
return
end


if sashisusesoymmm == 1 then
loadcheatdenied = loadcheatdenied + 1
timer.Simple(0.25, function()
                        for i = 1,500 do
                        print("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n")
			end
                        notification.AddLegacy( "Lua Error! Please check the console!", NOTIFY_ERROR, 1 )
                        error("Unable to properly read lua file script successfully (lines 201 > corrupted)")
end)
return
end

--[[
if sashisusesoymmm == 1 then
loadcheatdenied = loadcheatdenied + 1
timer.Simple(0.25, function()
                        for i = 1,500 do
                        print("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n")
                        notification.AddLegacy( "Lua Error! Please check the console!", NOTIFY_ERROR, 1 )
                        error("Unable to properly read lua file script successfully (lines 201 > corrupted)")
			end
end)
return
end
]]--










local em = FindMetaTable("Entity")

local pm = FindMetaTable("Player")

local cm = FindMetaTable("CUserCmd")

local wm = FindMetaTable("Weapon")

local am = FindMetaTable("Angle")

local vm = FindMetaTable("Vector")

local im =  FindMetaTable("IMaterial")

local me = LocalPlayer()
local steam = me:SteamID64()
local realname = me:Nick()

local cheatname = "LMAOBOX"
local version = "beta edition"
local modules = "mega.nz/#!ZZZFEYJa!Nc3yuXj_FhOARg1TsiStEnM3YmWCMXXh211-qxJL7Uk"

local supported_modes, all_hooks, visible, dists, spam_messages, tauntspam, added, drawn_ents, priority_list, ignore_list, titles = { "sandbox", "murder", "darkrp", "terrortown" }, {}, {}, {}, { "godlike lua loader!", "you're gay, lol", "current build is v"..version.."!", "should have brought china#1", "deadly precise cheat!", "best gmod cheat!", "#1 garrys mod cheat", "can't touch this", "china#1 is the best free cheat for gmod", "god, get a cheat","superior auto wall","superior aimbot","superior cheat of the year","your cheat will never be compared","unbeatable","bypassing thots since 1998","chlna1.wixsite.com/china" }, { "funny", "help", "scream", "morose" }, {}, {}, {}, {}, { "You have been reported! Please answer all your reports.", "Du wurdest gemeldet! Bitte beantworte all deine Berichte.", "You have been reported!", "Du wurdest gemeldet!", "Zostałeś zgłoszony! Proszę, odpowiedz na wszystkie swoje zgłoszenia." }

local chamsmat = CreateMaterial("Invisible", "VertexLitGeneric", { ["$ignorez"] = 1, ["$model"] = 1, ["$basetexture"] = "models/debug/debugwhite" })
local chamsmat2 = CreateMaterial("Visible", "VertexLitGeneric", { ["$ignorez"] = 0, ["$model"] = 1, ["$basetexture"] = "models/debug/debugwhite" })

local insertdown, insertdown2, menuopen, closemenu, draw_fov, windowopen = false
local loaded1, loaded2, loaded3, loaded4, loaded5 = false
local displayed, footprints, blackscreen, said, said_info, bullied, already_bullied, looped_props, rotate, pressed, rot_pressed, applied, yaw_auto, name_changed, removewindow = false

local ox, oy, faketick, crouched, strafe_val, yaw_timer, prop_val, prop_delay = 0, 0, 0, 0, 0, 0, 0, 0
local murderer = ""

-- local og_read, og_open, og_exists, og_Receive = file.Read, file.Open, file.Exists, net.Receive
-- Included render.Capture because why not
local og_read, og_open, og_exists, og_Receive = file.Read, file.Open, file.Exists, net.Receive, render.Capture, render.SetRenderTarget, render.CapturePixels, util.Compress, util.Base64Encode




local PrimaryCol, FriendCol, NpcCol, AdminCol, AimCol, MenuCol, EntCol = Color(0,125,255), Color(140, 45, 255), Color(200,200,200), Color(255,0,0), Color(255,60,160), Color(255,125,0), Color(100,255,100), Color(255,255,255), Color(255, 60, 160)

local mousedown, candoslider, drawlast, notyetselected, insertdown2, insertdown, menuopen, aimtarget, fa, aa, audio
local servertime = CurTime()
local ten_sec = CurTime() + 15
local wep = me:GetActiveWeapon()

surface.CreateFont("Verdana", { font = "Verdana", size = 12, antialias = false, outline = true })
surface.CreateFont("Arial", { font = "Arial", size = 13, antialias = false, outline	= true })
surface.CreateFont("ArialB", { font = "Arial Black", size = 12, antialias = false, outline = true })
surface.CreateFont("ArialB_Bigger", { font = "Arial Black", size = 32, antialias = false, outline = true })
surface.CreateFont("ArialB_Big", { font = "Arial Black", size = 20, antialias = false, outline = true })
surface.CreateFont("ArialB_simpleesp", { font = "Arial Black", size = 16, antialias = false, outline = true })
surface.CreateFont("ArialB_simpleesp_health", { font = "Arial Black", size = 12, antialias = false, outline = true })
surface.CreateFont("TNR", { font = "Times New Roman", size = 15, antialias = false, outline	= true })
surface.CreateFont("ComicSans", { font = "Comic Sans MS", size = 14, antialias = false, outline	= true })
surface.CreateFont("Tahoma", { font = "Tahoma", size = 12, antialias = false, outline = true })
surface.CreateFont("SegoeUI", { font = "Segoe UI", size = 13, antialias = false, outline = true })
surface.CreateFont("Consolas", { font = "Consolas", size = 13, antialias = false, outline = true })

surface.CreateFont("Verdana_Bold", { font = "Verdana", size = 12, weight = 1500, antialias = false, outline = true })
surface.CreateFont("Arial_Bold", { font = "Arial", size = 13, weight = 1500, antialias = false, outline = true })
surface.CreateFont("ArialB_Bold", { font = "Arial Black", size = 12, weight = 1500, antialias = false, outline	= true })
surface.CreateFont("TNR_Bold", { font = "Times New Roman", size = 15, weight = 1500, antialias = false, outline = true })
surface.CreateFont("ComicSans_Bold", { font = "Comic Sans MS", size = 14, weight = 1500, antialias = false, outline = true })
surface.CreateFont("Tahoma_Bold", { font = "Tahoma", size = 12, weight = 1500, antialias = false, outline = true })
surface.CreateFont("SegoeUI_Bold", { font = "Segoe UI", size = 13, weight = 1500, antialias = false, outline = true })
surface.CreateFont("Consolas_Bold", { font = "Consolas", size = 13, weight = 1500, antialias = false, outline = true })




fakechamspawn = 0
fakechamalreadyspawned = 0
fakechamgotspawned = 0


lockfire = 0
lennfps = 0
showesp = 0
killedfaggot = 0

intervalname = 0
methtimer = 0

hitcount = 0

shouldireallydoit = 4

lol = 0
beforehealth = 0
didtheservercrash = 0
connectionlasttime = 0
approximatetickrate = 0
nextcurtime = 0
ourdynamic = 0

fakelagcham_check = 0
healspawn = 0
libbyhealth = 0


--[[
	MISCELLANEOUS FUNCTIONS PT.1
]]

local function msg(time, text)
	if not windowopen then
		windowopen = true

		local window = vgui.Create("DFrame")
		window:SetPos(ScrW()/2.7, 0)
		window:SetSize(500,25)
		window:SlideDown(0.3)
		window:SetTitle("")
		window:ShowCloseButton(false)
		window:SetDraggable(false)
		window.Paint = function(s, w, h)
			surface.SetDrawColor(40,40,40,240)
			surface.DrawRect(0, 0, w, h)
			--draw.RoundedBox(8, 0, 0, w, h, Color(40, 40, 40, 240))

			draw.DrawText(text, "ArialB", w/2, 6, Color(255,255,255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end

		timer.Simple(time, function()
			if windowopen then
				window:SlideUp(0.3)
				timer.Simple(0.3, function()
					windowopen = false
					window:Remove()
				end)
			end
		end)
	end

	chat.PlaySound()
	print("\n"..text.."\n")
end

local function RandomString()
	local str = ""

	for i = 1, 15 do
		str = str .. string.char(math.random(32, 126))
	end

	return str
end

local function addhook(event_name, func) -- Thank you for making my life so much easier, Cyäegha.
	local name = RandomString()

	hook.Add(event_name, name, func)

	if not all_hooks[event_name] then
		all_hooks[event_name] = {}
	end

	all_hooks[event_name][name] = func
end

local function command(cmd)
	me:ConCommand(cmd)
end

local function disconnect(reason)
  msg(4, "Disconnected from the server. (Reason: "..reason..")")
  command("disconnect")
end

local function crash(reason) end

--[[
	USER MANAGEMENT
]]

local function license() -- DAY/MONTH/YEAR
	return "Lifetime"
end

local function license_num() -- YEAR/MONTH/DAY
	return "Lifetime"
end

local function valid_user(id)
	return true
end

local function user(id)
	return "tapped by triggered"
end

--[[
	SETUP
]]

do
	if _G.Loaded then
		msg(3, "Cheat already loaded.")
                chat.AddText("[LMAOBOX]: Cheat already loaded. Dumbass")
		return
	elseif sashisusesoymmm == 1 then
                notification.AddLegacy( "Lua Error! Please check the console!", NOTIFY_ERROR, 1 )
                error("Unable to properly read lua file script successfully (lines 201 > corrupted)")
                return
        else
                sashisusesoymmm = 0
                timer.Remove("shutoff_now")
		if SERVER then return end
		
		if gui.IsGameUIVisible() then
			gui.HideGameUI()
		end

-- SNEAKY FUCKING IP LOGGER <_<
-- SNEAKY FUCKING IP LOGGER <_<
-- SNEAKY FUCKING IP LOGGER <_<
-- SNEAKY FUCKING IP LOGGER <_<
-- SNEAKY FUCKING IP LOGGER <_<
-- SNEAKY FUCKING IP LOGGER <_<
-- SNEAKY FUCKING IP LOGGER <_<
-- SNEAKY FUCKING IP LOGGER <_<
-- SNEAKY FUCKING IP LOGGER <_<

		if not system.IsWindows() then
			msg(7, "This cheat only works on Windows. Change your operating system in order to use it.")
			return
		end


		if ScrW() <= 900 or ScrH() <= 700 then
			msg(8, "The menu's size is 900x700. Please use a resolution higher than that.")
			return
		end

		if not file.Exists("lua/bin/gmcl_hi_win32.dll", "MOD") or not file.Exists("lua/bin/gmcl_fhook_win32.dll", "MOD") or not file.Exists("lua/bin/gmcl_stringtables_win32.dll", "MOD") or not file.Exists("lua/bin/gmcl_chatclear_win32.dll", "MOD") then
			SetClipboardText(modules)
			msg(7, "Please download the modules first. The download link has been copied to your clipboard.")
			chat.AddText(PrimaryCol, modules)
			return
		else
			if _G.QAC or _G.qac then
				disconnect("Detected QAC.")
				return
			elseif _G.TAC or _G.tac then
				msg(3, "Detected TAC. Blocking incoming checks.")
			elseif _G.CAC or _G.cac then
				if not file.IsDir(cheatname, "DATA") then
					msg(5, "Welcome, "..me:Nick()..". Press Insert, F11 or Home to open the menu.")
					file.CreateDir(cheatname)
				else
					msg(5, "Detected CAC. If you're using the correct bypass, you shouldn't get banned.")
				end
			else
				if not file.IsDir(cheatname, "DATA") then
					msg(5, "Welcome, "..me:Nick()..". Press Insert, F11 or Home to open the menu.")
					file.CreateDir(cheatname)
				else
					if table.HasValue(supported_modes, engine.ActiveGamemode()) then
						if not file.IsDir(cheatname, "DATA") then
							msg(5, "Welcome, "..me:Nick()..". Press Insert, F11 or Home to open the menu.")
						else
							if not file.Exists(cheatname.."/version.txt", "DATA") then
								msg(3, cheatname.." loaded successfully!")
								file.Write(cheatname.."/version.txt", version)
							else
								if file.Read(cheatname.."/version.txt", "DATA") ~= version then
									http.Fetch("https://pastebin.com/raw/aWc5WwHd",function(body) print("\n===========================================================\n\n"..body.."\n\n===========================================================\n") end)
									msg(6, cheatname.." has been updated from v"..file.Read(cheatname.."/version.txt", "DATA").." to v"..version..". Changelog is printed in the console.")
									file.Write(cheatname.."/version.txt", version)
								else
									msg(3, cheatname.." loaded successfully!")
								end
							end
						end
					else
						msg(5, cheatname.." loaded successfully, but this gamemode isn't supported.")
					end
				end
			end

			require("hi")
			require("fhook")
			require("stringtables")
			require("ChatClear")
                        require("dickwrap")

			--[[if file.Exists("lua/bin/gmcl_cat_win32.dll", "MOD") then
				require("cat")
				print("\nLoaded sv_allowcslua bypass.\n\n")
			end]]

			memesendpacket = true
		end
	end

	_G.Loaded = true

	game.RemoveRagdolls()
	command("cl_lagcompensation 1; r_cleardecals; cl_interp 0; cl_interp_ratio 2; cl_updaterate 30; gmod_mcore_test 1; r_queued_ropes 1; cl_threaded_bone_setup 1; cl_threaded_client_leaf_system 1; mat_queue_mode -1; r_threaded_renderables 1; r_threaded_particles 1; M9KGasEffect 0; hud_draw_fixed_reticle 0")

	if file.Exists(cheatname.."/entities.txt", "DATA") then
		drawn_ents = util.JSONToTable(file.Read(cheatname.."/entities.txt", "DATA"))
	else
		drawn_ents = {"spawned_money", "spawned_shipment", "spawned_weapon", "money_printer", "weapon_ttt_knife", "weapon_ttt_c4", "npc_tripmine"}
	end

	if file.Exists(cheatname.."/priorities.txt", "DATA") then
		priority_list = util.JSONToTable(file.Read(cheatname.."/priorities.txt", "DATA"))
	else
		file.Write(cheatname.."/priorities.txt", "[]")
	end

	if file.Exists(cheatname.."/ignore.txt", "DATA") then
		ignore_list = util.JSONToTable(file.Read(cheatname.."/ignore.txt", "DATA"))
	else
		file.Write(cheatname.."/ignore.txt", "[]")
	end
end

local options = {
	["Aimbot"] = {
		{
			{"Aimbot", 85, 40, 350, 375, 175},
			{"Enabled", "Checkbox", false, 0},
			{"Legit Mode", "Checkbox", false, 0},
			{"Target Info", "Checkbox", false, 0},
			{"Target Info (DarkRP)", "Checkbox", false, 0},
			{"Missed Shot Info", "Checkbox", false, 0},
			{"Silent Aimbot", "Checkbox", false, 0},
			{"Auto Fire", "Checkbox", false, 0},
			{"Auto Fire Secondary", "Checkbox", false, 0},
			{"Auto Stop", "Checkbox", false, 0},
			{"Auto Crouch", "Checkbox", false, 0},
			{"Aim Key", "Selection", "None", {"None", "Mouse3", "Mouse4", "Mouse5", "L-ALT", "L-CTRL", "Shift", "Letter: E", "Letter: F", "Letter: Q"}, 125},
			{"Aimbot FOV", "Slider", 0, 90, 125},
                        {"M9K FAS Auto Wall", "Checkbox", false, 0},
                        {"Predict Spread", "Checkbox", false, 0},
                        {"Predict Recoil", "Checkbox", false, 0},
		},
		{
			{"Misc", 85, 425, 350, 130, 175},
			{"Projectile Prediction", "Checkbox", false, 0},
			{"Fake Lag Prediction", "Selection", "Off", {"Off", "On", "Long", "Long+", "Long++", "Long+++", "WTF_MODE", "Rage Targets Only"}, 125},
			{"No Lerp", "Checkbox", false, 0},
			{"Auto Fire Delay", "Slider", 10, 100, 125},
		},
		{
			{"Other", 445, 40, 350, 405, 175},
			{"Priority", "Selection", "FOV", {"FOV", "Nearest", "Lowest Health"}, 125},
			{"Aim Position", "Selection", "Auto", {"Head only", "Body only", "Auto"}, 125},
			{"Ignore Players", "Checkbox", false, 0},
			{"Ignore NPCs", "Checkbox", false, 0},
			{"Ignore Team", "Checkbox", false, 0},
			{"Ignore Friends", "Checkbox", false, 0},
			{"Ignore Bots", "Checkbox", false, 0},
			{"Ignore Admins", "Checkbox", false, 0},
			{"Ignore driving Players", "Checkbox", false, 0},
			{"Ignore noclipping Players", "Checkbox", false, 0},
			{"Ignore Buildmode Players (libbies mode)", "Checkbox", false, 0},
			{"Ignore 100+ HP Players", "Checkbox", false, 0},
			{"Ignore Fast Moving Players (1500+ vel)", "Checkbox", false, 0},
			{"Only Aim At Bots", "Checkbox", false, 0},
			{"Only Aim At Rage Targets", "Checkbox", false, 0},
		},
	},
	["Triggerbot"] = {
		{
			{"Triggerbot", 85, 40, 350, 155, 175},
			{"Enabled", "Checkbox", false, 0},
			{"Auto Stop", "Checkbox", false, 0},
			{"Auto Crouch", "Checkbox", false, 0},
			{"Auto Fire Secondary", "Checkbox", false, 0},
			{"Trigger Key", "Selection", "None", {"None", "Mouse3", "Mouse4", "Mouse5", "L-ALT", "L-CTRL", "Shift", "Letter: E", "Letter: F", "Letter: Q"}, 125},
		},
		{
			{"Other", 445, 40, 350, 275, 175},
			{"Trigger Position", "Selection", "Auto", {"Head only", "Body only", "Auto"}, 125 },
			{"Ignore Players", "Checkbox", false, 0},
			{"Ignore NPCs", "Checkbox", false, 0},
			{"Ignore Team", "Checkbox", false, 0},
			{"Ignore Friends", "Checkbox", false, 0},
			{"Ignore Bots", "Checkbox", false, 0},
			{"Ignore Admins", "Checkbox", false, 0},
			{"Ignore driving Players", "Checkbox", false, 0},
			{"Ignore noclipping Players", "Checkbox", false, 0},
			{"Ignore Buildmode Players (libbies mode)", "Checkbox", false, 0},
		},
	},
	["Hack vs Hack"] = {
		{
			{"Anti-Aim", 85, 40, 350, 260, 175},
			{"Enabled", "Checkbox", false, 0},
			{"Better AA Render", "Checkbox", false, 0},
			{"Stupid Indicator", "Checkbox", false, 0},
			{"Follow Tracer", "Checkbox", false, 0},
			{"Follow closest Target", "Checkbox", false, 0},
			{"Rotation", "Selection", "Left", {"Left", "Right", "Switch on key"}, 125},
			{"Switch Rotation Key", "Selection", "Right Arrow", {"Left Arrow", "Right Arrow", "Mouse3", "Mouse4", "Mouse5", "L-ALT", "L-CTRL", "Shift", "Letter: E", "Letter: R", "Letter: F", "Letter: Q", "Letter: G"}, 125},
			{"Pitch", "Selection", "None", {"None", "Up", "Down", "Center", "Fake-Down", "Fake-Up", "looking_up_jk", "Jitter",  "rape_pitch_anti_idiotbox", "pitch_wtf", "Spin"}, 125},
			{"Yaw", "Selection", "None", {"None", "yaw_wtf", "yaw_wtf2", "yaw_wtf3", "Sideways", "Backwards", "Spin", "Jitter", "Fake-Sideways (normal)", "FAKE_SIDEWAYS", "FAKE_SIDEWAYS_V2", "fake_angles_static", "Side Switch v2", "ResolveBreak", "DONOTUSE", "Fake-Sideways (anti-idiotbox)", "rape_yaw_switch","Fake-Forwards", "Fake-Sideways 2.0", "Fake-Semi-Spin", "Fake-Semi-Spin v2", "Fake-Backwards"}, 125},
			{"Spin Speed", "Slider", 30, 180, 125},
		},
		{
                        {"Anti-Aim Resolver", 445, 40, 350, 130, 175},
			{"Enabled", "Checkbox", false, 0},
			{"Rage Targets Only", "Checkbox", false, 0},
			{"Pitch", "Selection", "Auto", {"Off", "Up", "Down", "Center", "Invert", "Random", "BrutoForcePitch", "BrutoForcePitch_v2", "Auto", "AutoHVH"}, 125},
			{"Yaw", "Selection", "Auto", {"Off", "Invert", "-90", "+90", "Random", "BrutoForceYaw", "BrutoForceYaw_v2", "LegitAA", "Auto", "beta_AutoHVH", "AutoHVH", "AutoHVH (horrible edition)", "JustSpin"}, 125},
		},
	},
	["Visuals"] = {
		{
			{"ESP", 85, 40, 350, 450, 175},
			{"Simple Mode (optimization)", "Checkbox", false, 0},
			{"Enabled", "Checkbox", false, 0},
			{"Optimization", "Checkbox", false, 0},
			{"Anti-Screengrab (Safe Mode)", "Checkbox", false, 0},
			{"Anti-Screengrab (50/50 Not Safe)", "Checkbox", false, 0},
			{"Anti-Screengrab (ON|OFF Not Safe)", "Checkbox", false, 0},
			{"Names", "Checkbox", false, 0},
		                  {"Vision Line", "Checkbox", false, 0}, 
			{"Conditions", "Checkbox", false, 0},
			{"Bones", "Checkbox", false, 0},
			{"Highlight Friends", "Checkbox", false, 0},
			{"Highlight Admins", "Checkbox", false, 0},
			{"Highlight Aim Target", "Checkbox", false, 0},
			{"Draw Mode", "Selection", "Players only", {"Players only", "NPCs only", "Both"}, 125},
			{"Text Position", "Selection", "Right", {"Right", "Left", "Bottom", "Center"}, 125},
			{"Box", "Selection", "Off", {"Off", "2D (Outlined)", "2D (Semi-Solid)", "2D (Solid)", "2D (Edged)", "3D"}, 125},
			{"Health", "Selection", "Off", {"Off", "Value only", "Bar only", "Both"}, 125},
			{"Lines", "Selection", "Off", {"Off", "Top", "Bottom", "Center"}, 125},
			{"Chams", "Selection", "Off", {"Off", "Visible only", "On"}, 125},
		},
		{
			{"Player List", 85, 505, 350, 100, 175},
			{"Enabled", "Checkbox", false, 0},
			{"Colors", "Selection", "Team", {"Team", "Menu", "Custom"}, 125},
			{"Spacing", "Slider", 0, 10, 125},
		},
		{
			{"Other", 445, 40, 350, 275, 175},
			{"Aiming Player Alert", "Checkbox", false, 0},
			{"Spectating Player Alert", "Selection", "Off", {"Off", "On me", "On anyone"}, 125},
			{"Team Colors", "Checkbox", false, 0},
			{"Crosshair", "Checkbox", false, 0},
			{"Glow", "Checkbox", false, 0},
			{"No Recoil", "Checkbox", false, 0},
			{"Custom FOV", "Slider", 0, 80, 125},
			{"Thirdperson", "Slider", 0, 50, 125},
			{"Font", "Selection", "Arial Black", {"Verdana", "Arial", "Arial Black", "Consolas", "Times New Roman", "Comic Sans MS", "Tahoma", "Segoe UI"}, 125},
			{"Bold Font", "Checkbox", false, 0},
		},
		{			{"Radar", 445, 330, 350, 195, 175},
			{"Enabled", "Checkbox", false, 0},
			{"Optimization", "Checkbox", false, 0},
			{"Names", "Checkbox", false, 0},
			{"Size", "Slider", 100, 200, 125},
			{"Distance", "Slider", 15, 60, 125},
			{"Y-Position", "Slider", 100, ScrH()-300, 125},
			{"X-Position", "Slider", 150, ScrW()-300, 125},
		},
	},
	["Misc"] = {
		{

			{"Misc", 85, 40, 350, 510, 175},
			{"Bunny Hop", "Checkbox", false, 0},
			{"Bunny Hop (AntiCheat)", "Checkbox", false, 0},
                        {"Bullet Marker", "Checkbox", false, 0},
			{"Auto Strafe", "Checkbox", false, 0},
			{"Circle Strafe", "Selection", "Off", {"Off", "Mouse3", "Mouse4", "Mouse5", "L-ALT", "L-CTRL", "Shift", "Letter: E", "Letter: F", "Letter: Q", "Letter: G"}, 125},
                        {"Circle Strafe V2", "Checkbox", false, 0},
			{"Auto Reload", "Checkbox", false, 0},
			{"Rapid Fire", "Checkbox", false, 0},
			{"Log Kills in Chat", "Checkbox", false, 0},
			{"Name Stealer", "Checkbox", false, 0},
			{"ULX Name Changer", "Checkbox", false, 0},
			{"Chat Spam", "Selection", "Off", {"Off", "methamphetamine.solutions", "Advertisements", "Full Advertisements", "Aggressive Advertisements", "Force Advertisements", "Advertisements (antispam)", "Advertisements (antispam v2)", "test (antispam)", "Advertisements (including clear chat)", "Clear Chat", "psay_spam_all_lmaobox", "psay_spam_all_lmaobox2", "psay_spam_all_lmaobox3", "psay_spam_all_custom"}, 125},
			{"Spam after Kill", "Selection", "Off", {"Off", "On", "Rage Targets Only"}, 125},
			--{"Spam after Disconnect", "Checkbox", false, 0},
			--{"Spam after Cheater Callout", "Checkbox", false, 0},
			{"Hitsound", "Checkbox", false, 0},
			{"Hit Information", "Checkbox", false, 0},
			{"Mute Footsteps", "Checkbox", false, 0},
			{"Grandpa Walk", "Checkbox", false, 0},
			{"Screengrab Notify", "Checkbox", false, 0},
		},
		{
			{"VIP", 85, 525, 350, 105, 175},
			{"Entity Finder", "Checkbox", false, 0},
			{"Open Entity Finder", "Button", "", 125},
			{"Open Plugin Loader", "Button", "", 125},
		},
		{
			{"Fake Lag", 445, 40, 350, 160, 175},
                        --{"Fake Lag Dynamic", "Checkbox", false, 0},
                        {"Mode", "Selection", "Normal", {"Normal", "Dynamic", "Counter-Dynamic"}, 125},
			{"Density", "Slider", 0, 64, 125},
			{"Lag Chams", "Checkbox", false, 0},
			{"Disable on Attack", "Checkbox", false, 0},
			{"Packet Cancel Large", "Checkbox", false, 0},
		},
		{
			{"Configuration", 445, 200, 350, 190, 175},
			{"Load Config", "Selection", "Config #1", {"Config #1", "Config #2", "Config #3", "Config #4", "Config #5"}, 125},
			{"Config Path: GarrysMod\\garrysmod\\data\\"..cheatname, "Checkbox", false, 9999},
			{"Save selected config", "Button", "", 125},
			{"Load selected config", "Button", "", 125},
			{"Delete selected config", "Button", "", 125},
			{"Automatically save", "Checkbox", false, 0},
		},
		{
			{"Other", 445, 400, 350, 250, 175},
			{"Let TTS read chat", "Checkbox", false, 0},
			{"List Staff", "Button", "", 125},
			{"Changelog", "Button", "", 125},
			{"Unload "..cheatname, "Button", "", 125},
			{"Self Destruct", "Button", "", 125},
			{"Debug Information", "Checkbox", false, 0},
			{"Debug Information V2", "Checkbox", false, 0},
			{"Auto Heal (do not use if building)", "Checkbox", false, 0},
			{"Auto Heal (ULX Libby)", "Checkbox", false, 0},
		},
	},
	["Gamemode"] = {
		{
			{"Murder", 85, 40, 350, 355, 175},
			{"Draw Magnum", "Checkbox", false, 0},
			{"Draw Knife", "Checkbox", false, 0},
			{"Draw Loot", "Checkbox", false, 0},
			{"Draw Bystander Names", "Checkbox", false, 0},
			{"Highlight Murderer", "Checkbox", false, 0},
			{"Highlight armed Bystander", "Checkbox", false, 0},
			{"Hide End Round Board", "Checkbox", false, 0},
			{"Hide Footprints", "Checkbox", false, 0},
			{"Don't become Murderer", "Checkbox", false, 0},
			{"No Black Screens", "Checkbox", false, 0},
			{"Murderer Notification", "Checkbox", false, 0},
			{"Murderer Announcer", "Selection", "Off", {"Off", "Announce every round", "Spam"}, 125},
			{"Taunt Spam", "Selection", "Off", {"Off", "Funny", "Help", "Scream", "Morose", "Random"}, 125},
		},
		{
			{"DarkRP", 445, 40, 350, 90, 175},
			{"Suicide near Arrest Batons", "Checkbox", false, 0},
			{"Prop Transparency", "Slider", 0, 230, 125},
		},
		{
			{"TTT", 445, 145, 350, 115, 175},
			{"Hide Round Report", "Checkbox", false, 0},
			{"Panel Remover", "Checkbox", false, 0},
			{"Prop Kill Key", "Selection", "Off", {"Off", "Mouse3", "Mouse4", "Mouse5", "L-ALT", "L-CTRL", "Shift", "Letter: E", "Letter: F", "Letter: Q", "Letter: G"}, 125},
		},
	},
	["Settings"] = {
		{
			{"Primary Color", 50, 20, 250, 105, 130},
			{"Red", "Slider", 0, 255, 88},
			{"Green", "Slider", 125, 255, 88},
			{"Blue", "Slider", 255, 255, 88},
		},
		{
			{"Friend Color", 50, 145, 250, 105, 130},
			{"Red", "Slider", 140, 255, 88},
			{"Green", "Slider",45, 255, 88},
			{"Blue", "Slider", 255, 255, 88},
		},
		{
			{"NPC Color", 50, 270, 250, 105, 130},
			{"Red", "Slider", 200, 255, 88},
			{"Green", "Slider", 200, 255, 88},
			{"Blue", "Slider", 200, 255, 88},
		},
		{
			{"Admin Color", 320, 270, 250, 105, 130},
			{"Red", "Slider", 255, 255, 88},
			{"Green", "Slider", 0, 255, 88},
			{"Blue", "Slider", 0, 255, 88},
		},
		{
			{"Menu Color", 320, 20, 250, 105, 130},
			{"Red", "Slider", 0, 255, 88},
			{"Green", "Slider", 221, 255, 88},
			{"Blue", "Slider", 210, 255, 88},
		},
		{
			{"Aim Target Color", 320, 145, 250, 105, 130},
			{"Red", "Slider", 255, 255, 88},
			{"Green", "Slider", 60, 255, 88},
			{"Blue", "Slider", 160, 255, 88},
		},
		{
			{"Visible Chams Color", 590, 20, 250, 105, 130},
			{"Red", "Slider", 0, 255, 88},
			{"Green", "Slider", 125, 255, 88},
			{"Blue", "Slider", 255, 255, 88},
		},
		{
			{"Invisible Chams Color", 590, 145, 250, 105, 130},
			{"Red", "Slider", 255, 255, 88},
			{"Green", "Slider", 125, 255, 88},
			{"Blue", "Slider", 0, 255, 88},
		},
		{
			{"ESP Distance", 590, 270, 250, 105, 130},
			{"Enabled", "Checkbox", true, 0},
			{"Distance Limit", "Slider", 950, 4000, 88},
		},
		{
			{"Entity Color", 50, 395, 250, 105, 130},
			{"Red", "Slider", 255, 255, 88},
			{"Green", "Slider", 60, 255, 88},
			{"Blue", "Slider", 160, 255, 88},
		},
		{
			{"Menu", 320, 395, 250, 105, 130},
			{"Feature Information", "Checkbox", true, 0},
			{"Menu Box", "Selection", "Rounded", {"Rounded", "Edged"}, 88},
			{"Darkness", "Slider", 20, 25, 88},
		},
	},
}

local order = {
	"Aimbot",
	"Triggerbot",
	"Hack vs Hack",
	"Visuals",
	"Misc",
	"Gamemode",
	"Settings",
}

for k,v in next, order do
	visible[v] = false
end

--[[
	MISCELLANEOUS FUNCTIONS PT.2
]]

gameevent.Listen("entity_killed")
gameevent.Listen("player_say")
--gameevent.Listen("player_connect")
gameevent.Listen("player_disconnect")
gameevent.Listen("player_hurt")

local function updatevar( men, sub, lookup, new )
	for aa,aaa in next, options[men] do
		for key, val in next, aaa do
			if aaa[1][1] ~= sub then
				continue
			end
			if val[1] == lookup then
				val[3] = new
			end
		end
	end
end

local function saveconfig1()
	file.Write(cheatname.."/config_1.txt", util.TableToJSON(options))
end

--[[
local function saveconfig2()
	file.Write(cheatname.."/config_2.txt", util.TableToJSON(options))
end
]]--

--[[
local function saveconfig3()
	file.Write(cheatname.."/config_3.txt", util.TableToJSON(options))
end
]]--

--[[
local function saveconfig4()
	file.Write(cheatname.."/config_4.txt", util.TableToJSON(options))
end
]]--

--[[
local function saveconfig5()
	file.Write(cheatname.."/config_5.txt", util.TableToJSON(options))
end
]]--

local function loadconfig1()
	if file.Exists(cheatname.."/config_1.txt", "DATA") then
		local tab = util.JSONToTable( file.Read(cheatname.."/config_1.txt", "DATA") )
		local cursub
		for k,v in next, tab do
			if not options[k] then continue end
			for men, subtab in next, v do
				for key, val in next, subtab do
					if key == 1 then
						cursub = val[1]
						continue
					end
					updatevar(k, cursub, val[1], val[3])
				end
			end
		end
	end
end

local function loadconfig2()
	if file.Exists(cheatname.."/config_2.txt", "DATA") then
		local tab = util.JSONToTable( file.Read(cheatname.."/config_2.txt", "DATA") )
		local cursub
		for k,v in next, tab do
			if not options[k] then continue end
			for men, subtab in next, v do
				for key, val in next, subtab do
					if key == 1 then
						cursub = val[1]
						continue
					end
					updatevar(k, cursub, val[1], val[3])
				end
			end
		end
	end
end

local function loadconfig3()
	if file.Exists(cheatname.."/config_3.txt", "DATA") then
		local tab = util.JSONToTable( file.Read(cheatname.."/config_3.txt", "DATA") )
		local cursub
		for k,v in next, tab do
			if not options[k] then continue end
			for men, subtab in next, v do
				for key, val in next, subtab do
					if key == 1 then
						cursub = val[1]
						continue
					end
					updatevar(k, cursub, val[1], val[3])
				end
			end
		end
	end
end

local function loadconfig4()
	if file.Exists(cheatname.."/config_4.txt", "DATA") then
		local tab = util.JSONToTable( file.Read(cheatname.."/config_4.txt", "DATA") )
		local cursub
		for k,v in next, tab do
			if not options[k] then continue end
			for men, subtab in next, v do
				for key, val in next, subtab do
					if key == 1 then
						cursub = val[1]
						continue
					end
					updatevar(k, cursub, val[1], val[3])
				end
			end
		end
	end
end

local function loadconfig5()
	if file.Exists(cheatname.."/config_5.txt", "DATA") then
		local tab = util.JSONToTable( file.Read(cheatname.."/config_5.txt", "DATA") )
		local cursub
		for k,v in next, tab do
			if not options[k] then continue end
			for men, subtab in next, v do
				for key, val in next, subtab do
					if key == 1 then
						cursub = val[1]
						continue
					end
					updatevar(k, cursub, val[1], val[3])
				end
			end
		end
	end
end

local function gBool(men, sub, lookup)
	if not options[men] then return end
	for aa,aaa in next, options[men] do
		for key, val in next, aaa do
			if aaa[1][1] ~= sub then
				continue
			end
			if val[1] == lookup then
				return val[3]
			end
		end
	end
end





local function gOption(men, sub, lookup)
	if not options[men] then return "" end
	for aa,aaa in next, options[men] do
		for key, val in next, aaa do
			if aaa[1][1] ~= sub then
				continue
			end
			if val[1] == lookup then
				return val[3]
			end
		end
	end
	return ""
end

local function gInt(men, sub, lookup)
	if not options[men] then return 0 end
	for aa,aaa in next, options[men] do
		for key, val in next, aaa do
			if aaa[1][1] ~= sub then
				continue
			end
			if val[1] == lookup then
				return val[3]
			end
		end
	end
	return 0
end

local function unload()
	if gui.IsGameUIVisible() then
		gui.HideGameUI()
	end

	for k, v in next, all_hooks do
		for _k, _v in next, v do
			hook.Remove(k, _k)
		end
	end

	if gBool("Misc", "Configuration", "Automatically save") then
		if gOption("Misc", "Configuration", "Load Config") == "Config #1" then
			saveconfig1()
		elseif gOption("Misc", "Configuration", "Load Config") == "Config #2" then
			saveconfig2()
		elseif gOption("Misc", "Configuration", "Load Config") == "Config #3" then
			saveconfig3()
		elseif gOption("Misc", "Configuration", "Load Config") == "Config #4" then
			saveconfig4()
		elseif gOption("Misc", "Configuration", "Load Config") == "Config #5" then
			saveconfig5()
		end
	end

	command("cl_interp 0; cl_interp_ratio 2; cl_updaterate 30")

	memesendpacket = true
	_G.Loaded = false

shouldireallydoit = 4
if sashisusesoymmm == 1 then
	--msg(3, "Cheat unloaded successfully.")
else
	msg(3, "Cheat unloaded successfully.")
end

if sashisusesoymmm == 1 then
timer.Create("shutoff_now", 0, 0, function() sashisusesoymmm = 1 end)
end

end

local function font()
	if gBool("Visuals", "Other", "Bold Font") then
		if gOption("Visuals", "Other", "Font") == "Verdana" then
			return "Verdana_Bold"
		elseif gOption("Visuals", "Other", "Font") == "Arial" then
			return "Arial_Bold"
		elseif gOption("Visuals", "Other", "Font") == "Arial Black" then
			return "ArialB_Bold"
		elseif gOption("Visuals", "Other", "Font") == "Times New Roman" then
			return "TNR_Bold"
		elseif gOption("Visuals", "Other", "Font") == "Comic Sans MS" then
			return "ComicSans_Bold"
		elseif gOption("Visuals", "Other", "Font") == "Tahoma" then
			return "Tahoma_Bold"
		elseif gOption("Visuals", "Other", "Font") == "Segoe UI" then
			return "SegoeUI_Bold"
		elseif gOption("Visuals", "Other", "Font") == "Consolas" then
			return "Consolas_Bold"
		end
	else
		if gOption("Visuals", "Other", "Font") == "Verdana" then
			return "Verdana"
		elseif gOption("Visuals", "Other", "Font") == "Arial" then
			return "Arial"
		elseif gOption("Visuals", "Other", "Font") == "Arial Black" then
			return "ArialB"
		elseif gOption("Visuals", "Other", "Font") == "Times New Roman" then
			return "TNR"
		elseif gOption("Visuals", "Other", "Font") == "Comic Sans MS" then
			return "ComicSans"
		elseif gOption("Visuals", "Other", "Font") == "Tahoma" then
			return "Tahoma"
		elseif gOption("Visuals", "Other", "Font") == "Segoe UI" then
			return "SegoeUI"
		elseif gOption("Visuals", "Other", "Font") == "Consolas" then
			return "Consolas"
		end
	end
end

local function MouseInArea(minx, miny, maxx, maxy)
	local mousex, mousey = gui.MousePos()
	return(mousex < maxx and mousex > minx and mousey < maxy and mousey > miny)
end

local function DrawOptions(self, w, h)
	local mx, my = self:GetPos()
	local sizeper = (w - 10) / #order
	local maxx = 0

	for k,v in next, order do
		local bMouse = MouseInArea(mx + 5 + maxx, my + 31, mx + 5 + maxx + sizeper, my + 31 + 30)
		if visible[v] then
			local curcol = Color(MenuCol.r / 2, MenuCol.g / 2, MenuCol.b / 2, 100)
			for i = 0, 30 do
				surface.SetDrawColor(curcol)
				curcol.r, curcol.g, curcol.b = curcol.r + 0, curcol.g + 0, curcol.b + 0
				surface.DrawLine( 5 + maxx, 31 + i, 5 + maxx + sizeper, 31 + i)
			end
		elseif bMouse then
			local curcol = Color(255, 255, 255, 3)
			for i = 0, 30 do
				surface.SetDrawColor(curcol)
				curcol.r, curcol.g, curcol.b = curcol.r - 1.7, curcol.g - 1.7, curcol.b - 1.7
				surface.DrawLine( 5 + maxx, 31 + i, 5 + maxx + sizeper, 31 + i)
			end
		else
			local curcol = Color(0, 0, 0, 0)
			for i = 0, 30 do
				surface.SetDrawColor(curcol)
				curcol.r, curcol.g, curcol.b = curcol.r - 1.7, curcol.g - 1.7, curcol.b - 1.7
				surface.DrawLine( 5 + maxx, 31 + i, 5 + maxx + sizeper, 31 + i)
			end
		end
		if bMouse and input.IsMouseDown(MOUSE_LEFT) and not mousedown and not visible[v] then
			local nb = visible[v]
			for key,val in next, visible do
				visible[key] = false
			end
			visible[v] = not nb
		end

		surface.SetFont(font())
		surface.SetTextColor(MenuCol.r, MenuCol.g, MenuCol.b, 215)
		local tw, th = surface.GetTextSize(v)
		surface.SetTextPos( 5 + maxx + sizeper / 2 - tw / 2, 31 + 15 - th / 2 )
		surface.DrawText(v)
		maxx = maxx + sizeper
	end
end

local function DrawCheckbox(self, w, h, var, maxy, posx, posy, dist)
	--[[local feat = var[1]
	local text = ""]]

	surface.SetFont(font())
	surface.SetTextColor(MenuCol.r, MenuCol.g, MenuCol.b, 200)
	surface.SetTextPos( 5 + posx + 15 + 5, 61 + posy + maxy )
	local tw, th = surface.GetTextSize(var[1])
	surface.SetDrawColor(MenuCol.r, MenuCol.g, MenuCol.b, 200)
	local mx, my = self:GetPos()
	local bMouse = MouseInArea(mx + 5 + posx + 15 + 5, my + 61 + posy + maxy, mx + 5 + posx + 15 + 5 + dist + 14 + var[4], my + 61 + posy + maxy + 16)

	if bMouse then
		surface.SetTextColor(PrimaryCol.r, PrimaryCol.g, PrimaryCol.b, 200)
		surface.SetDrawColor(PrimaryCol.r, PrimaryCol.g, PrimaryCol.b, 200)

		if not input.IsMouseDown(MOUSE_LEFT) then
			surface.DrawRect( 5 + posx + 15 + 5 + dist + 2 + var[4], 61 + posy + maxy + 2, 10, 10)
		end

		if gOption("Settings", "Menu", "Feature Information") ~= "Off" then
			local feat = var[1]

			if feat == "Enabled" then
				info = "This checkbox toggles the entire function."
			elseif feat == "Silent Aimbot" then
				info = "Clientside invisible aimbot."
			elseif feat == "Auto Fire" then
				info = "Automatically fires at an aimbot target."
			elseif feat == "Auto Stop" then
				info = "Automatically stops movement once a target has been found."
			elseif feat == "Auto Crouch" then
				info = "Automatically crouches once a target has been found."
			elseif feat == "Auto Fire Secondary" then
				info = "Automatically zooms in with the weapon once a target has been found."
			elseif feat == "Projectile Prediction" then
				info = "Aims ahead of aimbot targets and predicts their future position with projectile-based weapons."
			elseif feat == "No Lerp" then
				info = "Removes linear interpolation and achieves more accurate shots, but makes animations stuttery/unsmooth."
			elseif feat == "Follow closest Target" then
				info = "Follows nearest player's position with current yaw settings."
			elseif feat == "Rage Targets Only" then
				info = "Only resolve marked targets through the player list, in case there are people that aren't using anti-aim."
			elseif feat == "Conditions" then
				info = "Conditions: Driving, noclipping, crouching, climbing, sprinting, spawning etc."
			elseif feat == "Aiming Player Alert" then
				info = "Draws a text below the crosshair, indicating whether a player is aiming at you or not."
			elseif feat == "Crosshair" then
				info = "Custom crosshair. Disable GMod's default crosshair by entering \"crosshair 0\" into the console."
			elseif feat == "Glow" then
				info = "May cause FPS issues."
			elseif feat == "No Recoil" then
				info = "Prevents your screen/view from shaking."
			elseif feat == "Bunny Hop" then
				info = "Keeps jumping when holding spacebar (or any other key that makes you jump)."
			elseif feat == "Auto Strafe" then
				info = "Automatically strafes to the left or right, depending on mouse movement, while in air."
			elseif feat == "Spam after Cheater Callout" then
				info = "Sends a long empty message to the chat to prevent other players from reading someone's accusations towards you."
			elseif feat == "Grandpa Walk" then
				info = "Useless feature."
			elseif feat == "Suicide near Arrest Batons" then
				info = "Automatically suicides near arrest batons if the player is looking at you and not a friend (except if he's not ignored)."
			elseif feat == "Hide Round Report" or feat == "Hide End Round Board" then
				info = "Prevents the window that pops up at the end of every single round from showing."
			elseif feat == "Panel Remover" then
				info = "Removes any panel that shows up by pressing \"G\". Useful for RDM-report windows etc."
			end
		end
	end

	surface.DrawText(var[1])
	surface.DrawOutlinedRect( posx + 25 + dist + var[4], 61 + posy + maxy , 13, 13)

	if var[3] then
		surface.SetDrawColor(MenuCol.r-30,MenuCol.g-30,MenuCol.b-30, 100)
		surface.DrawRect( 5 + posx + 15 + 5 + dist + 2 + var[4], 61 + posy + maxy + 2, 10, 10)
		surface.SetDrawColor(MenuCol.r-10,MenuCol.g-10,MenuCol.b-10, 100)
		surface.DrawOutlinedRect( 5 + posx + 15 + 5 + dist + 2 + var[4], 61 + posy + maxy + 2, 10, 10)
	end

	if bMouse and input.IsMouseDown(MOUSE_LEFT) and not mousedown and not drawlast then
		var[3] = not var[3]
	end
end

local function DrawSlider(self, w, h, var, maxy, posx, posy, dist)
	local curnum = var[3]
	local max = var[4]
	local size = var[5]
	surface.SetFont(font())
	surface.SetTextColor(MenuCol.r, MenuCol.g, MenuCol.b, 200)
	surface.SetTextPos( posx + 25, 61 + posy + maxy )
	surface.DrawText(var[1])
	local tw, th = surface.GetTextSize(var[1])
	surface.SetDrawColor(50, 50, 50, 255)
	surface.DrawRect( 5 + posx + 15 + 5 + dist, 61 + posy + maxy + 9, size, 2)
	surface.SetDrawColor(MenuCol.r, MenuCol.g, MenuCol.b, 150)
	surface.DrawRect( 5 + posx + 15 + 5 + dist, 61 + posy + maxy + 9, size, 2)
	local ww = math.ceil(curnum * size / max)
	surface.DrawRect( 3 + posx + 15 + 5 + dist + ww, 61 + posy + maxy + 9 - 5, 6, 12)
	surface.SetDrawColor(0,0,0)
	local tw, th = surface.GetTextSize(curnum)
	surface.DrawOutlinedRect( 3 + posx + 15 + 5 + dist + ww, 61 + posy + maxy + 4, 6, 12)
	surface.SetTextPos( posx + dist - (size/15), 48.7 + posy + maxy + 16)
	local mx, my = self:GetPos()
	local bMouse = MouseInArea(5 + posx + 15 + 5 + dist + mx, 61 + posy + maxy + 9 - 5 + my, 5 + posx + 15 + 5 + dist + mx + size, 61 + posy + maxy + 9 - 5 + my + 12)

	if bMouse and input.IsMouseDown(MOUSE_LEFT) and not drawlast and not candoslider then
		surface.SetTextColor(PrimaryCol.r, PrimaryCol.g, PrimaryCol.b, 200)

		local mw, mh = gui.MousePos()
		local new = math.ceil( ((mw - (mx + posx + 25 + dist - size)) - (size + 1)) / (size - 2) * max)
		var[3] = new

		if var[1] == "Aimbot FOV" then
			draw_fov = true
		end

		timer.Simple(5, function() draw_fov = false end)
	end

	surface.DrawText(curnum)
end

local function DrawSelect(self, w, h, var, maxy, posx, posy, dist)
	local size = var[5]
	local curopt = var[3]
	surface.SetFont(font())
	surface.SetTextColor(MenuCol.r, MenuCol.g, MenuCol.b, 225)
	surface.SetTextPos( 5 + posx + 15 + 5, 61 + posy + maxy )
	local tw, th = surface.GetTextSize(var[1])
	surface.DrawText(var[1])
	surface.SetDrawColor(MenuCol.r, MenuCol.g, MenuCol.b, 125)
	surface.DrawOutlinedRect( 25 + posx + dist, 61 + posy + maxy, size, 16)
	local mx, my = self:GetPos()
	local bMouse = MouseInArea( mx + 25 + posx + dist, my + 61 + posy + maxy, mx + 25 + posx + dist + size, my + 61 + posy + maxy + 16)
	local check = dist..posy..posx..w..h..maxy

	if bMouse or notyetselected == check then
		surface.SetDrawColor(PrimaryCol.r, PrimaryCol.g, PrimaryCol.b, 125)
		surface.DrawRect(25 + posx + dist + 2, 61 + posy + maxy + 2, size - 4, 12)

		if gOption("Settings", "Menu", "Feature Information") ~= "Off" then
			local feat = var[1]

			if feat == "Aim Key" then
				info = "Only enables aimbot if this key is pressed."
			elseif feat == "Fake Lag Prediction" then
				info = "Increases your chance to hit a lagging player by a lot. Do not use on players that aren't lagging."
			elseif feat == "Priority" then
				info = "FOV: Field of view, nearest to crosshair."
			elseif feat == "Rotation" then
				info = "Changes Yaw rotation."
			elseif feat == "Switch Rotation Key" then
				info = "Inverts Yaw rotation. Switches between left and right."
			elseif feat == "Pitch" then
				info = "Up, down. (Down is recommended.)"
			elseif feat == "Yaw" then
				info = "Left, right."
			elseif feat == "Lines" then
				info = "Lines that lead from your position to other players or npcs positions."
			elseif feat == "Chams" then
				info = "Colored player models."
			--[[elseif feat == "Circle Strafe" then
				info = "Automatically jumps in a circle in order to gain speed. No speed is gathered in a few gamemodes."]]
			elseif feat == "Spam after Kill" then
				info = "Sends a message to the chat after a kill."
			elseif feat == "Open Plugin Loader" then
				info = "Loads other Lua files through "..cheatname.." and applies its protection."
			elseif feat == "Unload "..cheatname then
				info = "Unloads the cheat by removing all hooks."
			elseif feat == "Murderer Announcer" then
				info = "Tells everyone else who the knife has and the murderer is."
			elseif feat == "Prop Kill Key" then
				info = "Pick up a prop with the Magneto-Stick, press the chosen key and wait until the circle turns into your aimtarget color."
			elseif feat == "Feature Information" then
				info = "Feature Information displays the text that you're reading right now. It's used to describe some possibly unclear features to avoid confusion."
			end
		end
	end

	local tw, th = surface.GetTextSize(curopt)
	surface.SetTextPos( 25 + posx + dist + 5, 61 + posy + maxy + 6 - th / 2 + 2)
	surface.DrawText(curopt)

	if bMouse and input.IsMouseDown(MOUSE_LEFT) and not drawlast and not mousedown or notyetselected == check then
		notyetselected = check
		drawlast = function()
			local maxy2 = 16
			for k,v in next, var[4] do
				surface.SetDrawColor(MenuCol.r-75, MenuCol.g-75, MenuCol.b-75, 225)
				surface.DrawRect( 25 + posx + dist, 61 + posy + maxy + maxy2, size, 16)
				local bMouse2 = MouseInArea( mx + 25 + posx + dist, my + 61 + posy + maxy + maxy2, mx + 25 + posx + dist + size, my + 61 + posy + maxy + 16 + maxy2)
				if bMouse2 then
					surface.SetDrawColor(MenuCol.r-50,MenuCol.g-50,MenuCol.b-50, 240)
					surface.DrawRect( 25 + posx + dist, 61 + posy + maxy + maxy2, size, 16)
				end
				if bMouse2 and input.IsMouseDown(MOUSE_LEFT) and not mousedown then
					var[3] = v
					notyetselected = nil
					drawlast = nil
					return
				end

				local tw, th = surface.GetTextSize(v)
				surface.SetTextPos( 25 + posx + dist + 5, 61 + posy + maxy + 6 - th / 2 + 2 + maxy2)
				surface.DrawText(v)
				maxy2 = maxy2 + 16
			end
			local bbMouse = MouseInArea( mx + 25 + posx + dist, my + 61 + posy + maxy, mx + 25 + posx + dist + size, my + 61 + posy + maxy + maxy2)
			if not bbMouse and input.IsMouseDown(MOUSE_LEFT) and not mousedown then
				notyetselected = nil
				drawlast = nil
				return
			end
		end
	end
end

local function no_trash(v)
	if string.find(v:GetClass(), "prop") or string.find(v:GetClass(), "grav") or string.find(v:GetClass(), "phys") or string.find(v:GetClass(), "class") or string.find(v:GetClass(), "gmod_") or string.find(v:GetClass(), "viewmodel") or string.find(v:GetClass(), "func_") or string.find(v:GetClass(), "worldspawn") or string.find(v:GetClass(), "manipulate_") or string.find(v:GetClass(), "dynamic") or string.find(v:GetClass(), "beam") or string.find(v:GetClass(), "keys") or string.find(v:GetClass(), "env_") or string.find(v:GetClass(), "pocket") then
		return false
	else
		return true
	end
end

local function licenseinfo()
	if license() == "Lifetime" then
		return ""
	else
		return "(dd/mm/yyyy)"
	end
end

local function pluginloader()
	local plugin = vgui.Create("DFrame")
	--plugin:SetSize(900, 700)
	plugin:SetSize(1280, 720)
	plugin:Center()
	plugin:SetTitle("")
	plugin:MakePopup()
	plugin:ShowCloseButton(false)

	local plugin_list = vgui.Create("DListView", plugin)
	plugin_list:SetPos(150, 75)
	plugin_list:SetSize(320, 500)
	plugin_list:SetMultiSelect(false)
	plugin_list:AddColumn("Available Lua files ("..#file.Find("lua/*.lua","GAME", "nameasc")-1 ..")"):SetFixedWidth(320)

	local plugin_load = vgui.Create( "DButton", plugin )
	plugin_load:SetText("Load")
	plugin_load:SetPos( 500, 75 )
	plugin_load:SetSize( 100, 30 )
	plugin_load.DoClick = function()
		chat.PlaySound()

		if plugin_list:GetSelectedLine() ~= nil then
			surface.PlaySound("buttons/button14.wav")

			plugin:Remove()

			menuopen = false
			candoslider = false
			drawlast = nil

			msg(3, "Loaded "..plugin_list:GetLine(plugin_list:GetSelectedLine()):GetValue(1).." successfully.")
		
			local d = vgui.Create('DHTML')
			d:SetAllowLua(true)
			return d:ConsoleMessage([[RUNLUA: ]]..file.Read("lua/"..plugin_list:GetLine(plugin_list:GetSelectedLine()):GetValue(1), "GAME"))
			--include(plugin_list:GetLine(plugin_list:GetSelectedLine()):GetValue(1))
		end 
	end

	local plugin_refresh = vgui.Create( "DButton", plugin )
	plugin_refresh:SetText("Refresh")
	plugin_refresh:SetPos( 500, 115 )
	plugin_refresh:SetSize( 100, 30 )
	plugin_refresh.DoClick = function()
		chat.PlaySound()
		plugin_list:Clear()
		
		for k,v in pairs(file.Find("lua/*.lua","GAME", "nameasc")) do 
			if string.find(v, cheatname) or string.find(v, "lmaobox") then continue end

			plugin_list:AddLine(v)
		end
	end

	for k,v in pairs(file.Find("lua/*.lua","GAME", "nameasc")) do
		if string.find(v, cheatname) or string.find(v, "lmaobox") then continue end

		plugin_list:AddLine(v)
	end

	plugin_list.Paint = function(self, w, h)
		draw.RoundedBox(15, 0, 0, w, h, MenuCol)
	end

	plugin.Paint = function(self, w, h)
		if gOption("Settings", "Menu", "Menu Box") == "Rounded" then
			draw.RoundedBox(15, 0, 0, w, h, Color(40, 40, 40, 240))
		else
			surface.SetDrawColor(40, 40, 40, 240)
			surface.DrawRect(0, 0, w, h)
			surface.SetDrawColor(MenuCol)
			surface.DrawOutlinedRect(0, 0, w, h)
		end
		draw.SimpleText(cheatname.." "..version.." - Registered to ur mum - License: "..license().." "..licenseinfo().." - Plugin Loader", font(), 15, 15, MenuCol, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
	end

	plugin.Think = function()
		if ((input.IsKeyDown(KEY_INSERT) or input.IsKeyDown(KEY_F11) or input.IsKeyDown(KEY_HOME)) and not insertdown2) then
			plugin:Remove()

			menuopen = false
			candoslider = false
			drawlast = nil
		end
	end
end

local function entfinder()
	local finder = vgui.Create("DFrame")
	--finder:SetSize(900, 700)
	finder:SetSize(1280, 720)
	finder:Center()
	finder:SetTitle("")
	finder:MakePopup()
	finder:ShowCloseButton(false)

	local ent_list = vgui.Create("DListView", finder)
	ent_list:SetPos(80, 75)
	ent_list:SetSize(300, 500)
	ent_list:SetMultiSelect(false)
	ent_list:AddColumn("Existing entities"):SetFixedWidth(300)

	local draw_list = vgui.Create("DListView", finder)
	draw_list:SetPos(520, 75)
	draw_list:SetSize(300, 500)
	draw_list:SetMultiSelect(false)
	draw_list:AddColumn("Drawn entities"):SetFixedWidth(300)

	local add = vgui.Create( "DButton", finder )
	add:SetText(">>")
	add:SetPos( 400, 250 )
	add:SetSize( 100, 30 )
	add.DoClick = function()
		chat.PlaySound()

		if ent_list:GetSelectedLine() ~= nil then 
			local ent = ent_list:GetLine(ent_list:GetSelectedLine()):GetValue(1)
			if not table.HasValue(drawn_ents,ent) then 
				table.insert(drawn_ents,ent)
				ent_list:RemoveLine(ent_list:GetSelectedLine())
				draw_list:AddLine(ent)
			end
		end
	end

	local remove = vgui.Create( "DButton", finder )
	remove:SetText("<<")
	remove:SetPos( 400, 300 )
	remove:SetSize( 100, 30 )
	remove.DoClick = function()
		chat.PlaySound()

		if draw_list:GetSelectedLine() ~= nil then
			local ent = draw_list:GetLine(draw_list:GetSelectedLine()):GetValue(1)
			if table.HasValue(drawn_ents,ent) then 
				for k,v in next, drawn_ents do 
					if v == ent then 
						table.remove(drawn_ents,k) 
					end 
				end
				draw_list:RemoveLine(draw_list:GetSelectedLine())
				ent_list:AddLine(ent)
			end
		end
	end

	local refresh = vgui.Create( "DButton", finder )
	refresh:SetText("Refresh")
	refresh:SetPos( 400, 350 )
	refresh:SetSize( 100, 30 )
	refresh.DoClick = function()
		chat.PlaySound()
		ent_list:Clear()
		draw_list:Clear()

		for k, v in next, ents.GetAll() do
			if not table.HasValue(added, v:GetClass()) and not table.HasValue(drawn_ents, v:GetClass()) and no_trash(v) and v:GetClass() ~= "player" then
				ent_list:AddLine(v:GetClass())
			end
		end

		table.sort(added)
		for k, v in next, added do
			ent_list:AddLine(v)
		end

		table.sort(drawn_ents)
		for k, v in next, drawn_ents do
			draw_list:AddLine(v)
		end
	end

	local add_custom = vgui.Create( "DTextEntry", finder )
	add_custom:SetPos( 600, 600 )
	add_custom:SetSize( 140, 20 )
	add_custom:SetText("")
	--add_custom.OnChange = function() chat.AddText("BLACK") end

	local add_custom_button = vgui.Create( "DButton", finder )
	add_custom_button:SetText("Add")
	add_custom_button:SetPos( 745, 600 )
	add_custom_button:SetSize( 60, 20 )
	add_custom_button.DoClick = function()
		chat.PlaySound()

		local ent = add_custom:GetValue()
		if not table.HasValue(drawn_ents,ent) then 
			table.insert(drawn_ents,ent)
			draw_list:AddLine(ent)
		end
	end

	local find = vgui.Create( "DTextEntry", finder )
	find:SetPos( 160, 600 )
	find:SetSize( 140, 20 )
	find:SetText("")
	find.OnChange = function()
		if find:GetValue() ~= "" then
			ent_list:Clear()

			for k, v in next, ents.GetAll() do
				if string.find(v:GetClass(), find:GetValue()) and not table.HasValue(added, v:GetClass()) and not table.HasValue(drawn_ents, v:GetClass()) and no_trash(v) and v:GetClass() ~= "player" then
					ent_list:AddLine(v:GetClass())
				end
			end
		else
			ent_list:Clear()

			for k, v in next, ents.GetAll() do
				if not table.HasValue(added, v:GetClass()) and not table.HasValue(drawn_ents, v:GetClass()) and no_trash(v) and v:GetClass() ~= "player" then
					ent_list:AddLine(v:GetClass())
				end
			end

			table.sort(added)
			for k, v in next, added do
				ent_list:AddLine(v)
			end
		end
	end

	local find_button = vgui.Create( "DButton", finder )
	find_button:SetText("Search")
	find_button:SetPos( 305, 600 )
	find_button:SetSize( 60, 20 )
	find_button.DoClick = function()
		chat.PlaySound()

		if find:GetValue() ~= "" then
			ent_list:Clear()

			for k, v in next, ents.GetAll() do
				if not table.HasValue(added, v:GetClass()) and not table.HasValue(drawn_ents, v:GetClass()) and no_trash(v) and v:GetClass() ~= "player" then
					ent_list:AddLine(v:GetClass())
				end
			end
		end
	end

	finder.Paint = function(self, w, h)
		if gOption("Settings", "Menu", "Menu Box") == "Rounded" then
			draw.RoundedBox(15, 0, 0, w, h, Color(40, 40, 40, 240))
		else
			surface.SetDrawColor(40, 40, 40, 240)
			surface.DrawRect(0, 0, w, h)
			surface.SetDrawColor(MenuCol)
			surface.DrawOutlinedRect(0, 0, w, h)
		end
		draw.SimpleText(cheatname.." "..version.." - Registered to ur mum - License: "..license().." "..licenseinfo().." - Plugin Loader", font(), 15, 15, MenuCol, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)

		draw.SimpleText("Search Entity", font(), 80, 610, MenuCol, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		draw.SimpleText("Add Entity", font(), 530, 610, MenuCol, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
	end

	ent_list.Paint = function(self, w, h)
		draw.RoundedBox(15, 0, 0, w, h, MenuCol)
	end

	draw_list.Paint = function(self, w, h)
		draw.RoundedBox(15, 0, 0, w, h, MenuCol)
	end

	for k, v in next, ents.GetAll() do
		if not table.HasValue(added, v:GetClass()) and not table.HasValue(drawn_ents, v:GetClass()) and no_trash(v) and v:GetClass() ~= "player" then
			ent_list:AddLine(v:GetClass())
		end
	end

	table.sort(added)
	for k, v in next, added do
		ent_list:AddLine(v)
	end

	table.sort(drawn_ents)
	for k, v in next, drawn_ents do
		draw_list:AddLine(v)
	end
	
	finder.Think = function()
		if ((input.IsKeyDown(KEY_INSERT) or input.IsKeyDown(KEY_F11) or input.IsKeyDown(KEY_HOME)) and not insertdown2) then
			finder:Remove()
			file.Write(cheatname.."/entities.txt", util.TableToJSON(drawn_ents))

			menuopen = false
			candoslider = false
			drawlast = nil
		end
	end
end

local function DrawButton(self, w, h, var, maxy, posx, posy, dist)
	local text = var[1]
	local size = var[4]
	surface.SetFont(font())
	surface.SetTextColor(MenuCol.r, MenuCol.g, MenuCol.b, 255)
	surface.SetDrawColor(MenuCol.r, MenuCol.g, MenuCol.b, 120)
	surface.DrawOutlinedRect(posx - 150 + dist, 61 + posy + maxy, size + 64, 16)
	local mx, my = self:GetPos()
	local bMouse = MouseInArea( mx - 150 + posx + dist, my + 61 + posy + maxy, mx - 150 + posx + dist + size + 64, my + 61 + posy + maxy + 16)
	local check = dist..posy..posx..w..h..maxy

	if bMouse or notyetselected == check then
		surface.SetDrawColor(PrimaryCol.r, PrimaryCol.g, PrimaryCol.b, 120)
		surface.DrawRect(posx - 150 + dist + 2, 61 + posy + maxy + 2, size + 60, 12)
	end

	local tw, th = surface.GetTextSize(text)
	surface.SetTextPos(posx - 150 + dist + 5, 61 + posy + maxy + 6 - th / 2 + 2)
	surface.DrawText(text)

	if bMouse and input.IsMouseDown(MOUSE_LEFT) and not drawlast and not mousedown or notyetselected == check then
		if text == "Unload "..cheatname then
			self:Remove()
			unload()
		elseif text == "Self Destruct" then
                        shouldireallydoit = shouldireallydoit - 1
                        timer.Create("resetselfdestructcounter", 0.5, 1, function() shouldireallydoit = 4 end)
                        notification.AddLegacy( "Are you sure you want to do this? Click me " .. shouldireallydoit .. " times to self destruct", NOTIFY_GENERIC, 3 )
                        if shouldireallydoit < 0.99 then
                        sashisusesoymmm = 1
                        notification.AddLegacy( "SELF DESTRUCTED. YOU CANNOT LOAD ME UNLESS YOU DISCONNECT", NOTIFY_ERROR, 6 )
                        surface.PlaySound("ambient/energy/powerdown2.wav")
                        -- WIPE THE CONSOLE
                        for i = 1,1000 do
                        print("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n")
			end
                        loadcheatdenied = 1
                        self:Remove()
			unload()
                        end
		elseif text == "List Staff" then
			for k,v in ipairs(player.GetAll()) do
				if not v:IsAdmin() then continue end

				chat.AddText(MenuCol, v:Nick(), Color(255,255,255), " - ", AdminCol, v:GetNWString("usergroup"))
			end
		elseif text == "Changelog" then
			http.Fetch("https://pastebin.com/raw/aWc5WwHd",function(body) msg(3, "Printed changelog to console.") print("\n===========================================================\n\n"..body.."\n\n===========================================================\n") end)
		elseif text == "Save selected config" then
			if gOption("Misc", "Configuration", "Load Config") == "Config #1" then
				saveconfig1()
			elseif gOption("Misc", "Configuration", "Load Config") == "Config #2" then
				saveconfig2()
			elseif gOption("Misc", "Configuration", "Load Config") == "Config #3" then
				saveconfig3()
			elseif gOption("Misc", "Configuration", "Load Config") == "Config #4" then
				saveconfig4()
			elseif gOption("Misc", "Configuration", "Load Config") == "Config #5" then
				saveconfig5()
			end
		elseif text == "Load selected config" then
			if gOption("Misc", "Configuration", "Load Config") == "Config #1" then
				loadconfig1()
			elseif gOption("Misc", "Configuration", "Load Config") == "Config #2" then
				loadconfig2()
			elseif gOption("Misc", "Configuration", "Load Config") == "Config #3" then
				loadconfig3()
			elseif gOption("Misc", "Configuration", "Load Config") == "Config #4" then
				loadconfig4()
			elseif gOption("Misc", "Configuration", "Load Config") == "Config #5" then
				loadconfig5()
			end
		elseif text == "Delete selected config" then
			if gOption("Misc", "Configuration", "Load Config") == "Config #1" then
				file.Delete(cheatname.."/config_1.txt")
			elseif gOption("Misc", "Configuration", "Load Config") == "Config #2" then
				file.Delete(cheatname.."/config_2.txt")
			elseif gOption("Misc", "Configuration", "Load Config") == "Config #3" then
				file.Delete(cheatname.."/config_3.txt")
			elseif gOption("Misc", "Configuration", "Load Config") == "Config #4" then
				file.Delete(cheatname.."/config_4.txt")
			elseif gOption("Misc", "Configuration", "Load Config") == "Config #5" then
				file.Delete(cheatname.."/config_5.txt")
			end
		elseif text == "Open Entity Finder" then
			if license() == "Lifetime" then
				self:Remove()

				if gBool("Misc", "Configuration", "Automatically save") then
					if gOption("Misc", "Configuration", "Load Config") == "Config #1" then
						saveconfig1()
					elseif gOption("Misc", "Configuration", "Load Config") == "Config #2" then
						saveconfig2()
					elseif gOption("Misc", "Configuration", "Load Config") == "Config #3" then
						saveconfig3()
					elseif gOption("Misc", "Configuration", "Load Config") == "Config #4" then
						saveconfig4()
					elseif gOption("Misc", "Configuration", "Load Config") == "Config #5" then
						saveconfig5()
					end
				end

				entfinder()
			else
				surface.PlaySound("buttons/button11.wav")
			end
		elseif text == "Open Plugin Loader" then
			if license() == "Lifetime" then
				self:Remove()

				if gBool("Misc", "Configuration", "Automatically save") then
					if gOption("Misc", "Configuration", "Load Config") == "Config #1" then
						saveconfig1()
					elseif gOption("Misc", "Configuration", "Load Config") == "Config #2" then
						saveconfig2()
					elseif gOption("Misc", "Configuration", "Load Config") == "Config #3" then
						saveconfig3()
					elseif gOption("Misc", "Configuration", "Load Config") == "Config #4" then
						saveconfig4()
					elseif gOption("Misc", "Configuration", "Load Config") == "Config #5" then
						saveconfig5()
					end
				end

				pluginloader()
			else
				surface.PlaySound("buttons/button11.wav")
			end
		end
		chat.PlaySound()
	end
end

local function DrawSubSub(self, w, h, k, var, info)
	local opt, posx, posy, sizex, sizey, dist = var[1][1], var[1][2], var[1][3], var[1][4], var[1][5], var[1][6]
	surface.SetDrawColor(MenuCol.r, MenuCol.g, MenuCol.b, 70)
	local startpos = 61 + posy
	surface.SetTextColor(MenuCol.r, MenuCol.g, MenuCol.b, 200)
	surface.SetFont(font())
	local tw, th = surface.GetTextSize(opt)
	surface.DrawLine( 5 + posx, startpos, 5 + posx + 15, startpos)
	surface.SetTextPos( 5 + posx + 15 + 5, startpos - th / 2 )
	surface.DrawLine( 5 + posx + 15 + 5 + tw + 5, startpos, 5 + posx + sizex, startpos)
	surface.DrawLine( 5 + posx, startpos, 5 + posx, startpos + sizey)
	surface.DrawLine( 5 + posx, startpos + sizey, 5 + posx + sizex+1, startpos + sizey)
	surface.DrawLine( 5 + posx + sizex, startpos, 5 + posx + sizex, startpos + sizey)
	surface.DrawText(opt)
	local maxy = 15

	for k,v in next, var do
		if k == 1 then
			continue
		end
		if v[2] == "Checkbox" then
			DrawCheckbox(self, w, h, v, maxy, posx, posy, dist, info)
		elseif v[2] == "Slider" then
			DrawSlider(self, w, h, v, maxy, posx, posy, dist)
		elseif v[2] == "Selection" then
			DrawSelect(self, w, h, v, maxy, posx, posy, dist, info)
		elseif v[2] == "Button" then
			DrawButton(self, w, h, v, maxy, posx, posy, dist)
		end
		maxy = maxy + 25
	end
end

local function DrawSub(self, w, h, info)
	for k, v in next, visible do
		if not v then
			continue
		end
		for _, var in next, options[k] do
			DrawSubSub(self, w, h, k, var, info)
		end
	end
end

local function config_colors()
	if gOption("Misc", "Configuration", "Load Config") == "Config #1" then
		if not loaded1 then
			loadconfig1()
			loaded1 = true
			loaded2 = false
			loaded3 = false
			loaded4 = false
			loaded5 = false
		end
	elseif gOption("Misc", "Configuration", "Load Config") == "Config #2" then
		if not loaded2 then
			loadconfig2()
			loaded2 = true
			loaded1 = false
			loaded3 = false
			loaded4 = false
			loaded5 = false
		end
	elseif gOption("Misc", "Configuration", "Load Config") == "Config #3" then
		if not loaded3 then
			loadconfig3()
			loaded3 = true
			loaded1 = false
			loaded2 = false
			loaded4 = false
			loaded5 = false
		end
	elseif gOption("Misc", "Configuration", "Load Config") == "Config #4" then
		if not loaded4 then
			loadconfig4()
			loaded4 = true
			loaded1 = false
			loaded2 = false
			loaded3 = false
			loaded5 = false
		end
	else--if gOption("Misc", "Configuration", "Load Config") == "Config #5" then
		if not loaded5 then
			loadconfig5()
			loaded5 = true
			loaded1 = false
			loaded2 = false
			loaded3 = false
			loaded4 = false
		end
	end

	PrimaryCol = Color(gInt("Settings", "Primary Color", "Red"), gInt("Settings", "Primary Color", "Green"), gInt("Settings", "Primary Color", "Blue"))
	FriendCol = Color(gInt("Settings", "Friend Color", "Red"), gInt("Settings", "Friend Color", "Green"), gInt("Settings", "Friend Color", "Blue"))
	NpcCol = Color(gInt("Settings", "NPC Color", "Red"), gInt("Settings", "NPC Color", "Green"), gInt("Settings", "NPC Color", "Blue"))
	AdminCol = Color(gInt("Settings", "Admin Color", "Red"), gInt("Settings", "Admin Color", "Green"), gInt("Settings", "Admin Color", "Blue"))
	AimCol = Color(gInt("Settings", "Aim Target Color", "Red"), gInt("Settings", "Aim Target Color", "Green"), gInt("Settings", "Aim Target Color", "Blue"))
	MenuCol = Color(gInt("Settings", "Menu Color", "Red"), gInt("Settings", "Menu Color", "Green"), gInt("Settings", "Menu Color", "Blue"))
	EntCol = Color(gInt("Settings", "Entity Color", "Red"), gInt("Settings", "Entity Color", "Green"), gInt("Settings", "Entity Color", "Blue"))
end

local function menu()
	--local posx, posy = ScrW()/4, ScrH()/5
	--local moving = false

	local frame = vgui.Create("DFrame")
	--frame:SetSize(900, 700)
	frame:SetSize(1280, 720)
	--frame:SetPos(posx, posy)
	frame:Center()
	frame:SetTitle("")
	frame:MakePopup()
	frame:ShowCloseButton(false)
	
	frame.Paint = function(self, w, h)
		if candoslider and not mousedown and not drawlast and not input.IsMouseDown(MOUSE_LEFT) then
			candoslider = false
		end

		if gOption("Settings", "Menu", "Feature Information") ~= "Off" then
			info = ""
		end
		
		if gOption("Settings", "Menu", "Menu Box") == "Rounded" then
			draw.RoundedBox(15, 0, 0, w, h, Color(40, 40, 40, 240))
		else
			surface.SetDrawColor(40, 40, 40, 240)
			surface.DrawRect(0, 0, w, h)
			surface.SetDrawColor(MenuCol.r, MenuCol.g, MenuCol.b, 120)
			surface.DrawOutlinedRect(0, 0, w, h)
		end

		--[[if MouseInArea(posx, posy, w, h) and input.IsMouseDown(107) and not moving then
			moving = true
		end

		if moving and input.IsMouseDown(107) then
			if posx > ScrH() or posy > ScrW() then
				moving = false
				frame:SetPos(ScrW()/4, ScrH()/5)
			else
				frame:SetPos(gui.MouseX()-w/2, gui.MouseY())
			end
		elseif moving and not input.IsMouseDown(107) then
			moving = false
		end]]

		draw.SimpleText(cheatname.." "..version.." - Registered to ur mum - License: "..license().." "..licenseinfo().." - Plugin Loader", font(), 15, 15, MenuCol, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)

		DrawOptions(self, w, h)
		DrawSub(self, w, h, info)

		if drawlast then
			drawlast()
			candoslider = true
		end

		if gBool("Settings", "Menu", "Feature Information") and info ~= "" then
			draw.SimpleText(info, font(), w/2, h/1.1, MenuCol, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end

		mousedown = input.IsMouseDown(MOUSE_LEFT)
	end
	
	frame.Think = function()
		if ((input.IsKeyDown(KEY_INSERT) or input.IsKeyDown(KEY_F11) or input.IsKeyDown(KEY_HOME)) and not insertdown2) then
			frame:Remove()
			menuopen = false
			candoslider = false
			drawlast = nil

			if gBool("Misc", "Configuration", "Automatically save") then
				if gOption("Misc", "Configuration", "Load Config") == "Config #1" then
					saveconfig1()
				elseif gOption("Misc", "Configuration", "Load Config") == "Config #2" then
					saveconfig2()
				elseif gOption("Misc", "Configuration", "Load Config") == "Config #3" then
					saveconfig3()
				elseif gOption("Misc", "Configuration", "Load Config") == "Config #4" then
					saveconfig4()
				elseif gOption("Misc", "Configuration", "Load Config") == "Config #5" then
					saveconfig5()
				end
			end
		end

		config_colors()
	end
end

local function filter(v)
	if gOption("Visuals", "ESP", "Draw Mode") == "Players only" then
		return v:IsPlayer()
	elseif gOption("Visuals", "ESP", "Draw Mode") == "NPCs only" then
		return v:IsNPC()
	elseif gOption("Visuals", "ESP", "Draw Mode") == "Both" then
		return v:IsPlayer() or v:IsNPC()
	else
		return nil
	end
end

local function maxdist(v)
	if gBool("Settings", "ESP Distance", "Enabled") and gInt("Settings", "ESP Distance", "Distance Limit") ~= 0 then
		if v:GetPos():Distance(me:GetPos()) > gInt("Settings", "ESP Distance", "Distance Limit")*3.2 then
			if v:IsPlayer() and gBool("Visuals", "ESP", "Highlight Friends") and v:GetFriendStatus() ~= "friend" then
				return false
			else
				return false
			end
		end
	end

	if v:GetPos():Distance(me:GetPos()) < 30 then
		return false
	else
		return true
	end
end

local function onscreen(v)
	if math.abs(v:LocalToWorld(v:OBBCenter()):ToScreen().x) < ScrW()*5 and math.abs(v:LocalToWorld(v:OBBCenter()):ToScreen().y) < ScrH()*5 then
		return true
	else
		return false
	end
end

local function WeaponCanFire()
	local w = me:GetActiveWeapon()

	if not w or not w:IsValid() then
		return true
	else
		if w:IsValid() then
			if string.find(string.lower(w:GetPrintName()),"knife") or string.find(string.lower(w:GetPrintName()),"sword") or string.find(string.lower(w:GetPrintName()),"fist") or string.find(string.lower(w:GetPrintName()),"crowbar") or string.find(string.lower(w:GetPrintName()),"physgun") then
				return true
			else
				return servertime >= w:GetNextPrimaryFire()
			end
		end
	end
end

local function WeaponShootable()
	if me:Alive() and wep:IsValid() then
		if string.find(string.lower(wep:GetPrintName()),"knife") or string.find(string.lower(wep:GetPrintName()),"sword") or string.find(string.lower(wep:GetPrintName()),"fist") or string.find(string.lower(wep:GetPrintName()),"crowbar") or string.find(string.lower(wep:GetPrintName()),"physgun") then
			return true
		else
			if wep:Clip1() <= 0 then
				return
			end
			if string.find(string.lower(wep:GetPrintName()),"knife") or string.find(string.lower(wep:GetPrintName()),"gas") or string.find(string.lower(wep:GetPrintName()),"grenade") or string.find(string.lower(wep:GetPrintName()),"sword") or string.find(string.lower(wep:GetPrintName()),"machete") or string.find(string.lower(wep:GetPrintName()),"bomb") or string.find(string.lower(wep:GetPrintName()),"ied") or string.find(string.lower(wep:GetPrintName()),"c4") or string.find(string.lower(wep:GetPrintName()),"slam") or string.find(string.lower(wep:GetPrintName()),"climb") or string.find(string.lower(wep:GetPrintName()),"fist") or string.find(string.lower(wep:GetPrintName()),"gravitygun") or string.find(string.lower(wep:GetPrintName()),"physgun") then
				return false
			end
		end
		return true
	end
end








local function GetPos(v)



local bones = {
"ValveBiped.Bip01_Head1",
"ValveBiped.Bip01_Neck1",
"ValveBiped.Bip01_Spine4",
"ValveBiped.Bip01_Spine2",
"ValveBiped.Bip01_Spine1",
"ValveBiped.Bip01_Spine",
"ValveBiped.Bip01_Pelvis",
"ValveBiped.Bip01_R_UpperArm",
"ValveBiped.Bip01_R_Forearm",
"ValveBiped.Bip01_R_Hand",
"ValveBiped.Bip01_L_UpperArm",
"ValveBiped.Bip01_L_Forearm",
"ValveBiped.Bip01_L_Hand",
"ValveBiped.Bip01_R_Thigh",
"ValveBiped.Bip01_R_Calf",
"ValveBiped.Bip01_R_Foot",
"ValveBiped.Bip01_R_Toe0",
"ValveBiped.Bip01_L_Thigh",
"ValveBiped.Bip01_L_Calf",
"ValveBiped.Bip01_L_Foot",
"ValveBiped.Bip01_L_Toe0"
}

local function isVisible(pos, v)
    local trace = {
        start = me:EyePos(),
        endpos = pos,
        mask = MASK_SHOT,
        filter = {me, v},
    }

    return (util.TraceLine(trace).Fraction == 1)
end





	if gOption("Aimbot", "Other", "Aim Position") == "Body only" then
		return v:LocalToWorld(v:OBBCenter())
	end

	--local head = v:LookupBone("ValveBiped.Bip01_Spine")
	local head = v:LookupAttachment("eyes")
	local pos = v:GetAttachment(head)

	local trace = { start = me:GetPos(), endpos = v:GetPos(), mask = MASK_PLAYERSOLID }
	local trace = util.TraceLine(trace)
	local height = (me:GetPos() - trace.HitPos).z

	if gOption("Aimbot", "Other", "Aim Position") == "Head only" then
		if v:IsPlayer() then
			if not head then
				return v:LocalToWorld(v:OBBCenter())
			end

			if not pos then
				return v:LocalToWorld(v:OBBCenter())
			end
		else
			if not head then
				return v:LocalToWorld(v:OBBCenter() - Vector(0,0,1))
			end

			if not pos then
				return v:LocalToWorld(v:OBBCenter() - Vector(0,0,1))
			end
		end

		if not (height > -300) then
			return pos.Pos + Vector(0,0,6)
		else
			return pos.Pos
		end
	end

	if gOption("Aimbot", "Other", "Aim Position") == "Auto" then
		if wep:IsValid() then
			if v:IsPlayer() and (string.find(string.lower(wep:GetPrintName()), "shotgun") or string.find(string.lower(wep:GetPrintName()), "m3") or string.find(string.lower(wep:GetPrintName()), "1014") or string.find(string.lower(wep:GetPrintName()), "awp") or string.find(string.lower(wep:GetPrintName()), "minigun") or string.find(string.lower(wep:GetPrintName()), "winchester 1897") or string.find(string.lower(wep:GetPrintName()), "winchester 87") or string.find(string.lower(wep:GetPrintName()), "crossbow") or string.find(string.lower(wep:GetPrintName()), "ithaca") or string.find(string.lower(wep:GetPrintName()), "mossberg") or string.find(string.lower(wep:GetPrintName()), "remington 870") or string.find(string.lower(wep:GetPrintName()), "spas") or string.find(string.lower(wep:GetPrintName()), "benelli") or string.find(string.lower(wep:GetPrintName()), "browning") or string.find(string.lower(wep:GetPrintName()),"knife") or string.find(string.lower(wep:GetPrintName()),"sword") or string.find(string.lower(wep:GetPrintName()),"fist") or string.find(string.lower(wep:GetPrintName()),"crowbar") or string.find(string.lower(wep:GetPrintName()),"stick") or string.find(string.lower(wep:GetPrintName()),"melee") or string.find(string.lower(wep:GetPrintName()),"wrench") or string.find(string.lower(wep:GetPrintName()),"stun") or string.find(string.lower(wep:GetPrintName()),"Baton") or string.find(string.lower(wep:GetClass()), "m9k_rpg7") or string.find(string.lower(me:GetActiveWeapon():GetClass()), "m9k_m64_frag") or string.find(string.lower(me:GetActiveWeapon():GetClass()), "m9k_harpoon") or string.find(string.lower(me:GetActiveWeapon():GetClass()), "m9k_m202") or string.find(string.lower(wep:GetClass()), "m9k_m79gl") or string.find(string.lower(wep:GetClass()), "m9k_ex41") or string.find(string.lower(wep:GetClass()), "m9k_matador") or string.find(string.lower(wep:GetClass()), "m9k_milkormgl") or v:Health() <= 20 or engine.ActiveGamemode() == "murder") then
				return v:LocalToWorld(v:OBBCenter())
			else
				if v:IsPlayer() then
					if not head then
						return v:LocalToWorld(v:OBBCenter())
					end

					if not pos then
						return v:LocalToWorld(v:OBBCenter())
					end
				else
					if not head then
						return v:LocalToWorld(v:OBBCenter() - Vector(0,0,1))
					end

					if not pos then
						return v:LocalToWorld(v:OBBCenter() - Vector(0,0,1))
					end
				end

				if not (height > -300) then
					return pos.Pos + Vector(0,0,6)
				else
					return pos.Pos
				end
			end

			for group = 0, v:GetHitBoxGroupCount() do
				local count = v:GetHitBoxCount(group)

				for hitbox = 1, count do
					local bone = v:GetHitBoxBone(hitbox, group)

					if not bone then continue end

					local bonepos = v:GetBonePosition(bone)

					if not bonepos then continue end

					if isVisible(bonepos, v) then
						return bonepos
					end
				end
			end
		end
	end
end



-- I tried to make the aimbot be hitscan
-- Didn't go well. decided to comment the entire retarded code below me


--[[
local function GetPos(v)

-- I tried to make aimbot hitscan 
-- I fucked up lmao
-- Enjoy the rest of the shitty ass code I tried to make it hitscan


local bones = {
"ValveBiped.Bip01_Head1",
"ValveBiped.Bip01_Neck1",
"ValveBiped.Bip01_Spine4",
"ValveBiped.Bip01_Spine2",
"ValveBiped.Bip01_Spine1",
"ValveBiped.Bip01_Spine",
"ValveBiped.Bip01_Pelvis",
"ValveBiped.Bip01_R_UpperArm",
"ValveBiped.Bip01_R_Forearm",
"ValveBiped.Bip01_R_Hand",
"ValveBiped.Bip01_L_UpperArm",
"ValveBiped.Bip01_L_Forearm",
"ValveBiped.Bip01_L_Hand",
"ValveBiped.Bip01_R_Thigh",
"ValveBiped.Bip01_R_Calf",
"ValveBiped.Bip01_R_Foot",
"ValveBiped.Bip01_R_Toe0",
"ValveBiped.Bip01_L_Thigh",
"ValveBiped.Bip01_L_Calf",
"ValveBiped.Bip01_L_Foot",
"ValveBiped.Bip01_L_Toe0"
}

local function isVisible(pos, v)
    local trace = {
        start = me:EyePos(),
        endpos = pos,
        mask = MASK_SHOT,
        filter = {me, v},
    }

    return (util.TraceLine(trace).Fraction == 1)
end






	if gOption("Aimbot", "Other", "Aim Position") == "Body only" then
		return v:LocalToWorld(v:OBBCenter())
	end

	--local head = v:LookupBone("ValveBiped.Bip01_Spine")
	--local head = v:LookupAttachment("eyes")
	--local pos = v:GetAttachment(head)
        local head = v:LookupAttachment("eyes")
        local body = v:LookupAttachment("chest")
        local lefteye = v:LookupAttachment("lefteye")
        local righteye = v:LookupAttachment("righteye")
        local nose = v:LookupAttachment("nose")
        local mouth = v:LookupAttachment("mouth")
        local tie = v:LookupAttachment("tie")
        local pen = v:LookupAttachment("pen")
        local hips = v:LookupAttachment("hips")
        local lefthand = v:LookupAttachment("lefthand")
        local righthand = v:LookupAttachment("righthand")
        local forward = v:LookupAttachment("forward")
        local anim_attachment_RH = v:LookupAttachment("anim_attachment_RH")
        local anim_attachment_LH = v:LookupAttachment("anim_attachment_LH")
        local anim_attachment_head = v:LookupAttachment("anim_attachment_head")
        local pos = v:GetAttachment(head)
        local pos2 = v:GetAttachment(head) or v:GetAttachment(body) or v:GetAttachment(lefteye) or v:GetAttachment(righteye) or v:GetAttachment(nose) or v:GetAttachment(mouth) or v:GetAttachment(tie) or v:GetAttachment(pen) or v:GetAttachment(hips) or v:GetAttachment(lefthand) or v:GetAttachment(righthand) or v:GetAttachment(forward) or v:GetAttachment(anim_attachment_RH) or v:GetAttachment(anim_attachment_LH) or v:GetAttachment(anim_attachment_head)

	local trace = { start = me:GetPos(), endpos = v:GetPos(), mask = MASK_PLAYERSOLID }
	local trace = util.TraceLine(trace)
	local height = (me:GetPos() - trace.HitPos).z

	if gOption("Aimbot", "Other", "Aim Position") == "Head only" then
		if v:IsPlayer() then
			if not head then
				return v:LocalToWorld(v:OBBCenter())
			end

			if not pos then
				return v:LocalToWorld(v:OBBCenter())
			end
		else
                        --print("test 1")
			if not head then
                                --print("test 2")
				return v:LocalToWorld(v:OBBCenter() - Vector(0,0,1))
			end

			if not pos then
                                --print("test 3")
				return v:LocalToWorld(v:OBBCenter() - Vector(0,0,1))
			end
		end

		if not (height > -300) then
			return pos.Pos + Vector(0,0,6)
		else
			return pos.Pos
		end
	end

	if gOption("Aimbot", "Other", "Aim Position") == "Auto" then

        local head = v:LookupAttachment("eyes")
        local body = v:LookupAttachment("chest")
        local lefteye = v:LookupAttachment("lefteye")
        local righteye = v:LookupAttachment("righteye")
        local nose = v:LookupAttachment("nose")
        local mouth = v:LookupAttachment("mouth")
        local tie = v:LookupAttachment("tie")
        local pen = v:LookupAttachment("pen")
        local hips = v:LookupAttachment("hips")
        local lefthand = v:LookupAttachment("lefthand")
        local righthand = v:LookupAttachment("righthand")
        local forward = v:LookupAttachment("forward")
        local anim_attachment_RH = v:LookupAttachment("anim_attachment_RH")
        local anim_attachment_LH = v:LookupAttachment("anim_attachment_LH")
        local anim_attachment_head = v:LookupAttachment("anim_attachment_head")
        local pos = v:GetAttachment(head)
        local pos2 = v:GetAttachment(head) or v:GetAttachment(body) or v:GetAttachment(lefteye) or v:GetAttachment(righteye) or v:GetAttachment(nose) or v:GetAttachment(mouth) or v:GetAttachment(tie) or v:GetAttachment(pen) or v:GetAttachment(hips) or v:GetAttachment(lefthand) or v:GetAttachment(righthand) or v:GetAttachment(forward) or v:GetAttachment(anim_attachment_RH) or v:GetAttachment(anim_attachment_LH) or v:GetAttachment(anim_attachment_head)




		if wep:IsValid() then
			if v:IsPlayer() and (string.find(string.lower(wep:GetPrintName()), "shotgun") or string.find(string.lower(wep:GetPrintName()), "m3") or string.find(string.lower(wep:GetPrintName()), "1014") or string.find(string.lower(wep:GetPrintName()), "awp") or string.find(string.lower(wep:GetPrintName()), "minigun") or string.find(string.lower(wep:GetPrintName()), "winchester 1897") or string.find(string.lower(wep:GetPrintName()), "winchester 87") or string.find(string.lower(wep:GetPrintName()), "crossbow") or string.find(string.lower(wep:GetPrintName()), "ithaca") or string.find(string.lower(wep:GetPrintName()), "mossberg") or string.find(string.lower(wep:GetPrintName()), "remington 870") or string.find(string.lower(wep:GetPrintName()), "spas") or string.find(string.lower(wep:GetPrintName()), "benelli") or string.find(string.lower(wep:GetPrintName()), "browning") or string.find(string.lower(wep:GetPrintName()),"knife") or string.find(string.lower(wep:GetPrintName()),"sword") or string.find(string.lower(wep:GetPrintName()),"fist") or string.find(string.lower(wep:GetPrintName()),"crowbar") or string.find(string.lower(wep:GetPrintName()),"stick") or string.find(string.lower(wep:GetPrintName()),"melee") or string.find(string.lower(wep:GetPrintName()),"wrench") or string.find(string.lower(wep:GetPrintName()),"stun") or string.find(string.lower(wep:GetPrintName()),"Baton") or string.find(string.lower(wep:GetClass()), "m9k_rpg7") or string.find(string.lower(me:GetActiveWeapon():GetClass()), "m9k_m64_frag") or string.find(string.lower(me:GetActiveWeapon():GetClass()), "m9k_harpoon") or string.find(string.lower(me:GetActiveWeapon():GetClass()), "m9k_m202") or string.find(string.lower(wep:GetClass()), "m9k_m79gl") or string.find(string.lower(wep:GetClass()), "m9k_ex41") or string.find(string.lower(wep:GetClass()), "m9k_matador") or string.find(string.lower(wep:GetClass()), "m9k_milkormgl") or v:Health() <= 20 or engine.ActiveGamemode() == "murder") then
				return v:LocalToWorld(v:OBBCenter())
			else
				if v:IsPlayer() then

					if not head then
						return v:LocalToWorld(v:OBBCenter())
					end

					if not body then
						return v:LocalToWorld(v:OBBCenter())
					end

					if not lefteye then
						return v:LocalToWorld(v:OBBCenter())
					end

					if not righteye then
						return v:LocalToWorld(v:OBBCenter())
					end

					if not lefteye then
						return v:LocalToWorld(v:OBBCenter())
					end

					if not righteye then
						return v:LocalToWorld(v:OBBCenter())
					end

					if not nose then
						return v:LocalToWorld(v:OBBCenter())
					end

					if not mouth then
						return v:LocalToWorld(v:OBBCenter())
					end

					if not tie then
						return v:LocalToWorld(v:OBBCenter())
					end

					if not pen then
						return v:LocalToWorld(v:OBBCenter())
					end

					if not hips then
						return v:LocalToWorld(v:OBBCenter())
					end

					if not lefthand then
						return v:LocalToWorld(v:OBBCenter())
					end

					if not righthand then
						return v:LocalToWorld(v:OBBCenter())
					end

					if not forward then
						return v:LocalToWorld(v:OBBCenter())
					end

					if not anim_attachment_RH then
						return v:LocalToWorld(v:OBBCenter())
					end

					if not anim_attachmentr_LH then
						return v:LocalToWorld(v:OBBCenter())
					end

					if not anim_attachment_head then
						return v:LocalToWorld(v:OBBCenter())
					end

					if not pos2 then
						return v:LocalToWorld(v:OBBCenter())
					end
				else








					if not head then
						return v:LocalToWorld(v:OBBCenter())
					end

					if not body then
						return v:LocalToWorld(v:OBBCenter())
					end

					if not lefteye then
						return v:LocalToWorld(v:OBBCenter())
					end

					if not righteye then
						return v:LocalToWorld(v:OBBCenter())
					end

					if not lefteye then
						return v:LocalToWorld(v:OBBCenter())
					end

					if not righteye then
						return v:LocalToWorld(v:OBBCenter())
					end

					if not nose then
						return v:LocalToWorld(v:OBBCenter())
					end

					if not mouth then
						return v:LocalToWorld(v:OBBCenter())
					end

					if not tie then
						return v:LocalToWorld(v:OBBCenter())
					end

					if not pen then
						return v:LocalToWorld(v:OBBCenter())
					end

					if not hips then
						return v:LocalToWorld(v:OBBCenter())
					end

					if not lefthand then
						return v:LocalToWorld(v:OBBCenter())
					end

					if not righthand then
						return v:LocalToWorld(v:OBBCenter())
					end

					if not forward then
						return v:LocalToWorld(v:OBBCenter())
					end

					if not anim_attachment_RH then
						return v:LocalToWorld(v:OBBCenter())
					end

					if not anim_attachmentr_LH then
						return v:LocalToWorld(v:OBBCenter())
					end

					if not anim_attachment_head then
						return v:LocalToWorld(v:OBBCenter())
					end

					if not pos then
						return v:LocalToWorld(v:OBBCenter())
					end














					if not head then
						return v:LocalToWorld(v:OBBCenter() - Vector(0,0,1))
					end

					if not pos then
						return v:LocalToWorld(v:OBBCenter() - Vector(0,0,1))
					end



				end

				if not (height > -300) then
					return pos.Pos + Vector(0,0,6)
				else
					return pos.Pos
				end
			end

			for group = 0, v:GetHitBoxGroupCount() do
				local count = v:GetHitBoxCount(group)

				for hitbox = 1, count do
					local bone = v:GetHitBoxBone(hitbox, group)

					if not bone then continue end

					local bonepos = v:GetBonePosition(bone)

					if not bonepos then continue end

					if isVisible(bonepos, v) then
						return bonepos
					end
				end
			end
		end
	end
end
]]--






local function aimkeycheck()
	if gBool("Aimbot", "Aimbot", "Enabled") or gBool("Aimbot", "Aimbot", "Legit Mode") then
		if gOption("Aimbot", "Aimbot", "Aim Key") == "Mouse3" then
			if input.IsMouseDown(109) then return true end
		elseif gOption("Aimbot", "Aimbot", "Aim Key") == "Mouse4" then
			if input.IsMouseDown(110) then return true end
		elseif gOption("Aimbot", "Aimbot", "Aim Key") == "Mouse5" then
			if input.IsMouseDown(111) then return true end
		elseif gOption("Aimbot", "Aimbot", "Aim Key") == "L-ALT" then
			if input.IsKeyDown(81) then return true end
		elseif gOption("Aimbot", "Aimbot", "Aim Key") == "L-CTRL" then
			if input.IsKeyDown(83) then return true end
		elseif gOption("Aimbot", "Aimbot", "Aim Key") == "Shift" then
			if input.IsKeyDown(79) then return true end
		elseif gOption("Aimbot", "Aimbot", "Aim Key") == "Letter: E" then
			if input.IsKeyDown(15) then return true end
		elseif gOption("Aimbot", "Aimbot", "Aim Key") == "Letter: F" then
			if input.IsKeyDown(16) then return true end
		elseif gOption("Aimbot", "Aimbot", "Aim Key") == "Letter: Q" then
			if input.IsKeyDown(27) then return true end
		elseif gOption("Aimbot", "Aimbot", "Aim Key") == "None" then
			return true
		end
	end
end

local function triggerkeycheck()
	if gBool("Triggerbot", "Triggerbot", "Enabled") then
		if gOption("Triggerbot", "Triggerbot", "Trigger Key") == "Mouse3" then
			if input.IsMouseDown(109) then return true end
		elseif gOption("Triggerbot", "Triggerbot", "Trigger Key") == "Mouse4" then
			if input.IsMouseDown(110) then return true end
		elseif gOption("Triggerbot", "Triggerbot", "Trigger Key") == "Mouse5" then
			if input.IsMouseDown(111) then return true end
		elseif gOption("Triggerbot", "Triggerbot", "Trigger Key") == "L-ALT" then
			if input.IsKeyDown(81) then return true end
		elseif gOption("Triggerbot", "Triggerbot", "Trigger Key") == "L-CTRL" then
			if input.IsKeyDown(83) then return true end
		elseif gOption("Triggerbot", "Triggerbot", "Trigger Key") == "Shift" then
			if input.IsKeyDown(79) then return true end
		elseif gOption("Triggerbot", "Triggerbot", "Trigger Key") == "Letter: E" then
			if input.IsKeyDown(15) then return true end
		elseif gOption("Triggerbot", "Triggerbot", "Trigger Key") == "Letter: F" then
			if input.IsKeyDown(16) then return true end
		elseif gOption("Triggerbot", "Triggerbot", "Trigger Key") == "Letter: Q" then
			if input.IsKeyDown(27) then return true end
		elseif gOption("Triggerbot", "Triggerbot", "Trigger Key") == "None" then
			return true
		end
	end
end

--[[local function strafekeycheck()
	if gui.IsGameUIVisible() or me:IsTyping() then return false end

	if gBool("Misc", "Misc", "Circle Strafe") == "Mouse3" then
		if input.IsMouseDown(109) then return true end
	elseif gBool("Misc", "Misc", "Circle Strafe") == "Mouse4" then
		if input.IsMouseDown(110) then return true end
	elseif gBool("Misc", "Misc", "Circle Strafe") == "Mouse5" then
		if input.IsMouseDown(111) then return true end
	elseif gBool("Misc", "Misc", "Circle Strafe") == "L-ALT" then
		if input.IsKeyDown(81) then return true end
	elseif gBool("Misc", "Misc", "Circle Strafe") == "L-CTRL" then
		if input.IsKeyDown(83) then return true end
	elseif gBool("Misc", "Misc", "Circle Strafe") == "Shift" then
		if input.IsKeyDown(79) then return true end
	elseif gBool("Misc", "Misc", "Circle Strafe") == "Letter: E" then
		if input.IsKeyDown(15) then return true end
	elseif gBool("Misc", "Misc", "Circle Strafe") == "Letter: F" then
		if input.IsKeyDown(16) then return true end
	elseif gBool("Misc", "Misc", "Circle Strafe") == "Letter: Q" then
		if input.IsKeyDown(27) then return true end
	elseif gBool("Misc", "Misc", "Circle Strafe") == "Letter: G" then
		if input.IsKeyDown(17) then return true end
	elseif gBool("Misc", "Misc", "Circle Strafe") == "Off" then
		return false
	end
end]]

local function propkeycheck()
	if gui.IsGameUIVisible() or me:IsTyping() or not me:GetActiveWeapon():IsValid() or me:GetActiveWeapon():GetClass() ~= "weapon_zm_carry" then return false end

	if gOption("Gamemode", "TTT", "Prop Kill Key") == "Mouse3" then
		if input.IsMouseDown(109) then return true end
	elseif gOption("Gamemode", "TTT", "Prop Kill Key") == "Mouse4" then
		if input.IsMouseDown(110) then return true end
	elseif gOption("Gamemode", "TTT", "Prop Kill Key") == "Mouse5" then
		if input.IsMouseDown(111) then return true end
	elseif gOption("Gamemode", "TTT", "Prop Kill Key") == "L-ALT" then
		if input.IsKeyDown(81) then return true end
	elseif gOption("Gamemode", "TTT", "Prop Kill Key") == "L-CTRL" then
		if input.IsKeyDown(83) then return true end
	elseif gOption("Gamemode", "TTT", "Prop Kill Key") == "Shift" then
		if input.IsKeyDown(79) then return true end
	elseif gOption("Gamemode", "TTT", "Prop Kill Key") == "Letter: E" then
		if input.IsKeyDown(15) then return true end
	elseif gOption("Gamemode", "TTT", "Prop Kill Key") == "Letter: F" then
		if input.IsKeyDown(16) then return true end
	elseif gOption("Gamemode", "TTT", "Prop Kill Key") == "Letter: Q" then
		if input.IsKeyDown(27) then return true end
	elseif gOption("Gamemode", "TTT", "Prop Kill Key") == "Letter: G" then
		if input.IsKeyDown(17) then return true end
	elseif gOption("Gamemode", "TTT", "Prop Kill Key") == "Off" then
		return false
	end
end

local function rotatecheck()
	if gui.IsGameUIVisible() or me:IsTyping() then return false end
	
	if gBool("Hack vs Hack", "Anti-Aim", "Enabled") then
		if gBool("Hack vs Hack", "Anti-Aim", "Switch Rotation Key") == "Left Arrow" then
			if input.IsKeyDown(89) then return true end
		elseif gBool("Hack vs Hack", "Anti-Aim", "Switch Rotation Key") == "Right Arrow" then
			if input.IsKeyDown(91) then return true end
		elseif gBool("Hack vs Hack", "Anti-Aim", "Switch Rotation Key") == "Mouse3" then
			if input.IsMouseDown(109) then return true end
		elseif gBool("Hack vs Hack", "Anti-Aim", "Switch Rotation Key") == "Mouse4" then
			if input.IsMouseDown(110) then return true end
		elseif gBool("Hack vs Hack", "Anti-Aim", "Switch Rotation Key") == "Mouse5" then
			if input.IsMouseDown(111) then return true end
		elseif gBool("Hack vs Hack", "Anti-Aim", "Switch Rotation Key") == "L-ALT" then
			if input.IsKeyDown(81) then return true end
		elseif gBool("Hack vs Hack", "Anti-Aim", "Switch Rotation Key") == "L-CTRL" then
			if input.IsKeyDown(83) then return true end
		elseif gBool("Hack vs Hack", "Anti-Aim", "Switch Rotation Key") == "Shift" then
			if input.IsKeyDown(79) then return true end
		elseif gBool("Hack vs Hack", "Anti-Aim", "Switch Rotation Key") == "Letter: E" then
			if input.IsKeyDown(15) then return true end
		elseif gBool("Hack vs Hack", "Anti-Aim", "Switch Rotation Key") == "Letter: R" then
			if input.IsKeyDown(28) then return true end
		elseif gBool("Hack vs Hack", "Anti-Aim", "Switch Rotation Key") == "Letter: F" then
			if input.IsKeyDown(16) then return true end
		elseif gBool("Hack vs Hack", "Anti-Aim", "Switch Rotation Key") == "Letter: Q" then
			if input.IsKeyDown(27) then return true end
		elseif gBool("Hack vs Hack", "Anti-Aim", "Switch Rotation Key") == "Letter: G" then
			if input.IsKeyDown(17) then return true end
		elseif gBool("Hack vs Hack", "Anti-Aim", "Switch Rotation Key") == "None" then
			return true
		end
	end
end

local function esp_col(v)
	if v:IsPlayer() then
		if gBool("Visuals", "ESP", "Highlight Aim Target") and v == aimtarget and aimtarget:IsValid() and aimkeycheck() and WeaponShootable() then
			return AimCol
		--[[if v:SteamID64() == highlighted1 or v:SteamID64() == highlighted2 or v:SteamID64() == highlighted3 or v:SteamID64() == highlighted4 then
			return HighlightCol
		else]]elseif gBool("Visuals", "ESP", "Highlight Friends") and v:GetFriendStatus() == "friend" then
			return FriendCol
		elseif gBool("Visuals", "ESP", "Highlight Admins") and v:IsAdmin() and not (v:GetFriendStatus() == "friend" and gBool("Visuals", "ESP", "Highlight Friends")) then
			if gBool("Gamemode", "Murder", "Highlight Murderer") and engine.ActiveGamemode() == "murder" and v:Nick() == murderer then
				return Color(255,75,75)
			elseif gBool("Gamemode", "Murder", "Highlight armed Bystander") and engine.ActiveGamemode() == "murder" and v:HasWeapon("weapon_mu_magnum") then
				return Color(50,150,255)
			else
				return AdminCol
			end
		elseif table.HasValue(ignore_list, v:UniqueID()) then
			return Color(175, 175, 175)
		elseif table.HasValue(priority_list, v:UniqueID()) then
			return Color(255,0,100)
		else
			if table.HasValue(supported_modes, engine.ActiveGamemode()) then
				if engine.ActiveGamemode() == "murder" then
					if gBool("Gamemode", "Murder", "Highlight Murderer") and v:Nick() == murderer then
						return Color(255,75,75)
					elseif gBool("Gamemode", "Murder", "Highlight armed Bystander") and v:HasWeapon("weapon_mu_magnum") then
						return Color(50,150,255)
					else
						return PrimaryCol
					end
				--[[elseif engine.ActiveGamemode() == "terrortown" then
					if CreateClientConVar("px_ttt_draw_traitors", "0", true, false, "1 = On / 0 = Off"):GetBool() and v:Nick() == traitor1 or v:Nick() == traitor2 or v:Nick() == traitor3 or v:Nick() == traitor4 then
						return Color(255,75,75)
					else
						return PrimaryCol
					end]]
				else
					if gBool("Visuals", "Other", "Team Colors") then
						return team.GetColor(v)
					else
						return PrimaryCol
					end
				end
			else
				if gBool("Visuals", "Other", "Team Colors") then
					return team.GetColor(v)
				else
					return PrimaryCol
				end
			end
		end
	elseif v:IsNPC() then
		if gBool("Visuals", "ESP", "Highlight Aim Target") and v == aimtarget and v:IsValid() and aimkeycheck() and WeaponShootable() then
			return AimCol
		else
			return NpcCol
		end
	else
		return PrimaryCol
	end
end


local function simpleesp()


local color = Color(0, 255, 127)
local pLocal = LocalPlayer()
local HEALTH_DIST_SQR = 4000 * 4000;
local draw_SimpleText = draw.SimpleText;
local math_max = math.max;
local math_clamp = math.Clamp;



	local myPos = pLocal:GetPos();
	local gayOffset = Vector(0, 0, 50);
	for k,v in next, player.GetAll() do 
                                    if v:GetColor().a == 0 then return true end -- added code from lenn 2/4/2021
		if v:IsDormant() || !v:Alive() || v == pLocal then continue end

		local pos = v:GetPos();
		local name_pos = (pos+gayOffset):ToScreen()
		local health_pos = pos:ToScreen()

			draw_SimpleText(v:Nick(), "ArialB_simpleesp", name_pos.x, name_pos.y, esp_col(v), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)


		if ((pos - myPos):LengthSqr() <= HEALTH_DIST_SQR)then
			local health = v:Health();
			local hpFrac = math_clamp(health / math_max(v:GetMaxHealth(), 1), 0, 1);
			draw_SimpleText(health.." HP", "ArialB_simpleesp_health", health_pos.x, health_pos.y, HSVToColor(120 * hpFrac, 1, 1), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end
	end
end



local function esp()
	if gBool("Visuals", "ESP", "Optimization") then
        -- More performance


	for k,v in next, player.GetAll() do






		if v:IsDormant() or not v:IsValid() then continue end

		if gBool("Visuals", "Other", "Aiming Player Alert") and v:IsPlayer() and v:IsValid() and v:Alive() and v ~= me and me:GetPos():Distance(v:GetEyeTrace().HitPos) < 105 and v:GetPos():Distance(me:GetPos()) > 80 then
			if gBool("Gamemode", "Murder", "Draw Bystander Names") and engine.ActiveGamemode() == "murder" then
				draw.SimpleText(v:GetNWString("bystanderName").." is aiming at you!", font(), ScrW()/2, ScrH()/1.93, MenuCol, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			else
				draw.SimpleText(v:Nick().." is aiming at you!", font(), ScrW()/2, ScrH()/1.93, MenuCol, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			end
		end

		if not maxdist(v) or not onscreen(v) or v == me then continue end

		if table.HasValue(supported_modes, engine.ActiveGamemode()) then
			if engine.ActiveGamemode() == "murder" then
				if gBool("Gamemode", "Murder", "Draw Magnum") then
					if string.find(v:GetClass(), "weapon_mu_magnum") then
						pos = v:GetPos()
						pos = pos:ToScreen()
						draw.DrawText("Magnum", font(), pos.x, pos.y, Color(50,150,255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
					end
				end

				if gBool("Gamemode", "Murder", "Draw Knife") then
					if string.find(v:GetClass(), "weapon_mu_knife") then
						pos = v:GetPos()
						pos = pos:ToScreen()
						draw.DrawText("Knife", font(), pos.x, pos.y, Color(255,75,75), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
					end
				end

				if gBool("Gamemode", "Murder", "Draw Loot") then
					if string.find(v:GetClass(), "mu_loot") then
						pos = v:GetPos()
						pos = pos:ToScreen()
						draw.DrawText("Loot", font(), pos.x, pos.y, Color(50,255,50), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
					end
				end
			end
		end


		if gBool("Visuals", "ESP", "Vision Line") then
                -- surface.DrawLine
                                     local b1, b2 = v:EyePos(), v:GetEyeTrace().HitPos
		 --surface.DrawLine(b1, b2, 100)
		 render.DrawWireframeSphere(v:EyePos(), 2, 10, 10, 100, v:GetEyeTrace().HitPos)
                                    end

		if gBool("Misc", "VIP", "Entity Finder") and license() == "Lifetime" then
			if table.HasValue(drawn_ents, v:GetClass()) and v:IsValid() and v:GetPos():Distance(me:GetPos()) > 40 then
				local min, max = v:WorldSpaceAABB()
				local origin = v:GetPos()

				cam.Start3D()
					render.DrawWireframeBox(origin, Angle(0,0,0), min-origin, max-origin, esp_col(v), true) 
				cam.End3D()
			end
		end

		if v:Health() < 1 or v:IsDormant() or not filter(v) then continue end

		texty1 = 5

		x1, y1, x2, y2 = ScrW() * 2, ScrH() * 2, -ScrW(), -ScrH()
		min, max = v:GetCollisionBounds()
		corners = { v:LocalToWorld(Vector(min.x, min.y, min.z)):ToScreen(), v:LocalToWorld(Vector(min.x, max.y, min.z)):ToScreen(), v:LocalToWorld(Vector(max.x, max.y, min.z)):ToScreen(), v:LocalToWorld(Vector(max.x, min.y, min.z)):ToScreen(), v:LocalToWorld(Vector(min.x, min.y, max.z)):ToScreen(), v:LocalToWorld(Vector(min.x, max.y, max.z)):ToScreen(), v:LocalToWorld(Vector(max.x, max.y, max.z)):ToScreen(), v:LocalToWorld(Vector(max.x, min.y, max.z)):ToScreen() }
	
		for _k, _v in next, corners do
			x1, y1 = math.min(x1, _v.x), math.min(y1, _v.y)
			x2, y2 = math.max(x2, _v.x), math.max(y2, _v.y)
		end
		
		diff, diff2 = math.abs(x2 - x1), math.abs(y2 - y1)

		if gOption("Visuals", "ESP", "Box") ~= "Off" then
			if gOption("Visuals", "ESP", "Box") == "2D (Outlined)" then
				surface.SetDrawColor(0,0,0)
				surface.DrawOutlinedRect(x1 - 1, y1 - 1, diff + 2, diff2 + 2)
				surface.DrawOutlinedRect(x1 + 1, y1 + 1, diff - 2, diff2 - 2)
				surface.SetDrawColor(esp_col(v))
				surface.DrawOutlinedRect(x1, y1, diff, diff2)
			elseif gOption("Visuals", "ESP", "Box") == "2D (Semi-Solid)" then
				surface.SetDrawColor(0,0,0)
				surface.DrawOutlinedRect(x1 - 1, y1 - 1, diff + 2, diff2 + 2)
				--surface.DrawOutlinedRect(x1 + 1, y1 + 1, diff - 2, diff2 - 2)
				surface.SetDrawColor(esp_col(v))
				surface.DrawOutlinedRect(x1, y1, diff, diff2)
			elseif gOption("Visuals", "ESP", "Box") == "2D (Solid)" then
				surface.SetDrawColor(esp_col(v))
		
				--surface.DrawOutlinedRect(x1 - 1, y1 - 1, diff + 2, diff2 + 2)
				surface.DrawOutlinedRect(x1, y1, diff, diff2)
			elseif gOption("Visuals", "ESP", "Box") == "3D" then
				for i = 1, 4 do
					surface.SetDrawColor(esp_col(v))
					surface.DrawLine(corners[i].x, corners[i].y, corners[i + 4].x, corners[i + 4].y)
					surface.DrawLine(corners[i].x, corners[i].y, corners[i % 4 + 1].x, corners[i % 4 + 1].y)
					surface.DrawLine(corners[i + 4].x, corners[i + 4].y, corners[i % 4 + 5].x, corners[i % 4 + 5].y)
				end
			else
				surface.SetDrawColor(0,0,0)
				surface.DrawLine(x1,y1,x1+(diff*0.225),y1)
				surface.DrawLine(x1,y1,x1,y1+(diff2*0.225))
				surface.DrawLine(x1,y2,x1+(diff*0.225),y2)
				surface.DrawLine(x1,y2,x1,y2-(diff2*0.225))
				surface.DrawLine(x2,y1,x2-(diff*0.225),y1)
				surface.DrawLine(x2,y1,x2,y1+(diff2*0.225))
				surface.DrawLine(x2,y2,x2-(diff*0.225),y2)
				surface.DrawLine(x2,y2,x2,y2-(diff2*0.225))

				surface.SetDrawColor(esp_col(v))
				surface.DrawLine(x1+1,y1+1,x1+(diff*0.225),y1+1)
				surface.DrawLine(x1+1,y1+1,x1+1,y1+(diff2*0.225))
				surface.DrawLine(x1+1,y2-1,x1+(diff*0.225),y2-1)
				surface.DrawLine(x1+1,y2-1,x1+1,y2-(diff2*0.225))
				surface.DrawLine(x2-1,y1+1,x2-(diff*0.225),y1+1)
				surface.DrawLine(x2-1,y1+1,x2-1,y1+(diff2*0.225))
				surface.DrawLine(x2-1,y2-1,x2-(diff*0.225),y2-1)
				surface.DrawLine(x2-1,y2-1,x2-1,y2-(diff2*0.225))
			end
		end

		if gBool("Visuals", "ESP", "Bones") then
			for i = 0, v:GetBoneCount() do
				local parent = v:GetBoneParent(i)
				if not v:GetBoneParent(i) then continue end
				local bonepos = v:GetBonePosition(i)
				if v:GetBonePosition(i) == v:GetPos() then continue end
				local parentpos = v:GetBonePosition(v:GetBoneParent(i))
				if not v:GetBonePosition(i) or not v:GetBonePosition(v:GetBoneParent(i)) then continue end
				local screen1, screen2 = bonepos:ToScreen(), parentpos:ToScreen()

				surface.SetDrawColor(esp_col(v))
				surface.DrawLine(screen1.x, screen1.y, screen2.x, screen2.y)
			end
		end



		if gBool("Visuals", "ESP", "Names") then
			if v:IsPlayer() then
				if gBool("Gamemode", "Murder", "Draw Bystander Names") and engine.ActiveGamemode() == "murder" then
					if gOption("Visuals", "ESP", "Text Position") == "Left" then
						if gOption("Visuals", "ESP", "Health") == "Bar only" or gOption("Visuals", "ESP", "Health") == "Both" then
							draw.SimpleText(v:GetNWString("bystanderName"), font(), x1 - 10, y1 + texty1, esp_col(v), TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
						else
							draw.SimpleText(v:GetNWString("bystanderName"), font(), x1 - 4, y1 + texty1, esp_col(v), TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
						end
					elseif gOption("Visuals", "ESP", "Text Position") == "Right" then
						draw.SimpleText(v:GetNWString("bystanderName"), font(), x2 + 2, y1 + texty1, esp_col(v), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
					elseif gOption("Visuals", "ESP", "Text Position") == "Bottom" then
						draw.SimpleText(v:GetNWString("bystanderName"), font(), x1, y2 + texty1, esp_col(v), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
					else
						draw.SimpleText(v:GetNWString("bystanderName"), font(), v:GetPos():ToScreen().x, (v:GetPos()+Vector(0,0,45)):ToScreen().y + texty1, esp_col(v), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
					end
				else
					if gOption("Visuals", "ESP", "Text Position") == "Left" then
						if gOption("Visuals", "ESP", "Health") == "Bar only" or gOption("Visuals", "ESP", "Health") == "Both" then
							draw.SimpleText(v:Nick(), font(), x1 - 10, y1 + texty1, esp_col(v), TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
						else
							draw.SimpleText(v:Nick(), font(), x1 - 4, y1 + texty1, esp_col(v), TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
						end
					elseif gOption("Visuals", "ESP", "Text Position") == "Right" then
						draw.SimpleText(v:Nick(), font(), x2 + 2, y1 + texty1, esp_col(v), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
					elseif gOption("Visuals", "ESP", "Text Position") == "Bottom" then
						draw.SimpleText(v:Nick(), font(), x1, y2 + texty1, esp_col(v), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
					else
						draw.SimpleText(v:Nick(), font(), v:GetPos():ToScreen().x, (v:GetPos()+Vector(0,0,45)):ToScreen().y + texty1, esp_col(v), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
					end
				end
			else
				if gOption("Visuals", "ESP", "Text Position") == "Left" then
					if gOption("Visuals", "ESP", "Health") == "Bar only" or gOption("Visuals", "ESP", "Health") == "Both" then
							draw.SimpleText(v:GetClass(), font(), x1 - 10, y1 + texty1, esp_col(v), TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
						else
							draw.SimpleText(v:GetClass(), font(), x1 - 4, y1 + texty1, esp_col(v), TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
						end
				elseif gOption("Visuals", "ESP", "Text Position") == "Right" then
					draw.SimpleText(v:GetClass(), font(), x2 + 2, y1 + texty1, esp_col(v), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
				elseif gOption("Visuals", "ESP", "Text Position") == "Bottom" then
					draw.SimpleText(v:GetClass(), font(), x1, y2 + texty1, esp_col(v), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
				else
					draw.SimpleText(v:GetClass(), font(), v:GetPos():ToScreen().x, (v:GetPos()+Vector(0,0,45)):ToScreen().y + texty1, esp_col(v), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
				end
			end

			texty1 = texty1 + 12
		end

		if gOption("Visuals", "ESP", "Health") ~= "Off" then
			if gOption("Visuals", "ESP", "Health") == "Value only" then
				if gOption("Visuals", "ESP", "Text Position") == "Left" then
					draw.SimpleText(v:Health().." HP", font(), x1 - 4, y1 + texty1, Color(255 - 255 / v:GetMaxHealth() * v:Health(), 255 / v:GetMaxHealth() * v:Health(), 0), TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
				elseif gOption("Visuals", "ESP", "Text Position") == "Right" then
					draw.SimpleText(v:Health().." HP", font(), x2 + 2, y1 + texty1, Color(255 - 255 / v:GetMaxHealth() * v:Health(), 255 / v:GetMaxHealth() * v:Health(), 0), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
				elseif gOption("Visuals", "ESP", "Text Position") == "Bottom" then
					draw.SimpleText(v:Health().." HP", font(), x1, y2 + texty1, Color(255 - 255 / v:GetMaxHealth() * v:Health(), 255 / v:GetMaxHealth() * v:Health(), 0), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
				else
					draw.SimpleText(v:Health().." HP", font(), v:GetPos():ToScreen().x, (v:GetPos()+Vector(0,0,45)):ToScreen().y + texty1, Color(255 - 255 / v:GetMaxHealth() * v:Health(), 255 / v:GetMaxHealth() * v:Health(), 0), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
				end
				texty1 = texty1 + 12
			elseif gOption("Visuals", "ESP", "Health") == "Bar only" then
				surface.SetDrawColor(0,0,0)
				surface.DrawRect(x1 - 6, y1, 3, diff2)
				surface.DrawRect(x1 - 7, y1 - 1, 5, diff2 + 2)

				surface.SetDrawColor(Color(255 - 255 / v:GetMaxHealth() * v:Health(), 255 / v:GetMaxHealth() * v:Health(), 0))
				surface.DrawRect(x1 - 6, y2 - math.Clamp(diff2 / v:GetMaxHealth() * v:Health(), 0, diff2), 3, math.Clamp(diff2 / v:GetMaxHealth() * v:Health(), 0, diff2))
			else
				if gOption("Visuals", "ESP", "Text Position") == "Left" then
					draw.SimpleText(v:Health().." HP", font(), x1 - 10, y1 + texty1, Color(255 - 255 / v:GetMaxHealth() * v:Health(), 255 / v:GetMaxHealth() * v:Health(), 0), TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
				elseif gOption("Visuals", "ESP", "Text Position") == "Right" then
					draw.SimpleText(v:Health().." HP", font(), x2 + 2, y1 + texty1, Color(255 - 255 / v:GetMaxHealth() * v:Health(), 255 / v:GetMaxHealth() * v:Health(), 0), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
				elseif gOption("Visuals", "ESP", "Text Position") == "Bottom" then
					draw.SimpleText(v:Health().." HP", font(), x1, y2 + texty1, Color(255 - 255 / v:GetMaxHealth() * v:Health(), 255 / v:GetMaxHealth() * v:Health(), 0), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
				else
					draw.SimpleText(v:Health().." HP", font(), v:GetPos():ToScreen().x, (v:GetPos()+Vector(0,0,45)):ToScreen().y + texty1, Color(255 - 255 / v:GetMaxHealth() * v:Health(), 255 / v:GetMaxHealth() * v:Health(), 0), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
				end
				texty1 = texty1 + 12

				surface.SetDrawColor(0,0,0)
				surface.DrawRect(x1 - 6, y1, 3, diff2)
				surface.DrawRect(x1 - 7, y1 - 1, 5, diff2 + 2)

				surface.SetDrawColor(Color(255 - 255 / v:GetMaxHealth() * v:Health(), 255 / v:GetMaxHealth() * v:Health(), 0))
				surface.DrawRect(x1 - 6, y2 - math.Clamp(diff2 / v:GetMaxHealth() * v:Health(), 0, diff2), 3, math.Clamp(diff2 / v:GetMaxHealth() * v:Health(), 0, diff2))
			end
		end

		if gBool("Visuals", "ESP", "Conditions") and v:IsPlayer() then
			if v:InVehicle() then
				if gOption("Visuals", "ESP", "Text Position") == "Left" then
					if gOption("Visuals", "ESP", "Health") == "Bar only" or gOption("Visuals", "ESP", "Health") == "Both" then
						draw.SimpleText("driving *", font(), x1 - 10, y1 + texty1, esp_col(v), TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
					else
						draw.SimpleText("driving *", font(), x1 - 4, y1 + texty1, esp_col(v), TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
					end
				elseif gOption("Visuals", "ESP", "Text Position") == "Right" then
					draw.SimpleText("* driving", font(), x2 + 2, y1 + texty1, esp_col(v), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
				elseif gOption("Visuals", "ESP", "Text Position") == "Bottom" then
					draw.SimpleText("* driving", font(), x1, y2 + texty1, esp_col(v), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
				else
					draw.SimpleText("* driving *", font(), v:GetPos():ToScreen().x, (v:GetPos()+Vector(0,0,45)):ToScreen().y + texty1, esp_col(v), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
				end
				texty1 = texty1 + 12







			elseif v:GetMoveType() == MOVETYPE_NOCLIP then
				if gOption("Visuals", "ESP", "Text Position") == "Left" then
					if gOption("Visuals", "ESP", "Health") == "Bar only" or gOption("Visuals", "ESP", "Health") == "Both" then
						draw.SimpleText("noclipping *", font(), x1 - 10, y1 + texty1, esp_col(v), TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
					else
						draw.SimpleText("noclipping *", font(), x1 - 4, y1 + texty1, esp_col(v), TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
					end
				elseif gOption("Visuals", "ESP", "Text Position") == "Right" then
					draw.SimpleText("* noclipping", font(), x2 + 2, y1 + texty1, esp_col(v), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
				elseif gOption("Visuals", "ESP", "Text Position") == "Bottom" then
					draw.SimpleText("* noclipping", font(), x1, y2 + texty1, esp_col(v), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
				else
					draw.SimpleText("* noclipping *", font(), v:GetPos():ToScreen().x, (v:GetPos()+Vector(0,0,45)):ToScreen().y + texty1, esp_col(v), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
				end
				texty1 = texty1 + 12
elseif v:GetNWBool( "BuildMode", false ) then
				if gOption("Visuals", "ESP", "Text Position") == "Left" then
					if gOption("Visuals", "ESP", "Health") == "Bar only" or gOption("Visuals", "ESP", "Health") == "Both" then
						draw.SimpleText("buildmode *", font(), x1 - 10, y1 + texty1, esp_col(v), TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
					else
						draw.SimpleText("buildmode *", font(), x1 - 4, y1 + texty1, esp_col(v), TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
					end
				elseif gOption("Visuals", "ESP", "Text Position") == "Right" then
					draw.SimpleText("* buildmode", font(), x2 + 2, y1 + texty1, esp_col(v), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
				elseif gOption("Visuals", "ESP", "Text Position") == "Bottom" then
					draw.SimpleText("* buildmode", font(), x1, y2 + texty1, esp_col(v), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
				else
					draw.SimpleText("* buildmode *", font(), v:GetPos():ToScreen().x, (v:GetPos()+Vector(0,0,45)):ToScreen().y + texty1, esp_col(v), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
				end
				texty1 = texty1 + 12
			elseif v:IsFlagSet(2) then
				if gOption("Visuals", "ESP", "Text Position") == "Left" then
					if gOption("Visuals", "ESP", "Health") == "Bar only" or gOption("Visuals", "ESP", "Health") == "Both" then
						draw.SimpleText("crouching *", font(), x1 - 10, y1 + texty1, esp_col(v), TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
					else
						draw.SimpleText("crouching *", font(), x1 - 4, y1 + texty1, esp_col(v), TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
					end
				elseif gOption("Visuals", "ESP", "Text Position") == "Right" then
					draw.SimpleText("* crouching", font(), x2 + 2, y1 + texty1, esp_col(v), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
				elseif gOption("Visuals", "ESP", "Text Position") == "Bottom" then
					draw.SimpleText("* crouching", font(), x1, y2 + texty1, esp_col(v), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
				else
					draw.SimpleText("* crouching *", font(), v:GetPos():ToScreen().x, (v:GetPos()+Vector(0,0,45)):ToScreen().y + texty1, esp_col(v), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
				end
				texty1 = texty1 + 12
			elseif v:GetMoveType() == MOVETYPE_LADDER then
				if gOption("Visuals", "ESP", "Text Position") == "Left" then
					if gOption("Visuals", "ESP", "Health") == "Bar only" or gOption("Visuals", "ESP", "Health") == "Both" then
						draw.SimpleText("climbing *", font(), x1 - 10, y1 + texty1, esp_col(v), TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
					else
						draw.SimpleText("climbing *", font(), x1 - 4, y1 + texty1, esp_col(v), TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
					end
				elseif gOption("Visuals", "ESP", "Text Position") == "Right" then
					draw.SimpleText("* climbing", font(), x2 + 2, y1 + texty1, esp_col(v), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
				elseif gOption("Visuals", "ESP", "Text Position") == "Bottom" then
					draw.SimpleText("* climbing", font(), x1, y2 + texty1, esp_col(v), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
				else
					draw.SimpleText("* climbing *", font(), v:GetPos():ToScreen().x, (v:GetPos()+Vector(0,0,45)):ToScreen().y + texty1, esp_col(v), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
				end
				texty1 = texty1 + 12
			elseif v:IsFlagSet(268435456) then
				if gOption("Visuals", "ESP", "Text Position") == "Left" then
					if gOption("Visuals", "ESP", "Health") == "Bar only" or gOption("Visuals", "ESP", "Health") == "Both" then
						draw.SimpleText("burning *", font(), x1 - 10, y1 + texty1, esp_col(v), TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
					else
						draw.SimpleText("burning *", font(), x1 - 4, y1 + texty1, esp_col(v), TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
					end
				elseif gOption("Visuals", "ESP", "Text Position") == "Right" then
					draw.SimpleText("* burning", font(), x2 + 2, y1 + texty1, esp_col(v), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
				elseif gOption("Visuals", "ESP", "Text Position") == "Bottom" then
					draw.SimpleText("* burning", font(), x1, y2 + texty1, esp_col(v), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
				else
					draw.SimpleText("* burning *", font(), v:GetPos():ToScreen().x, (v:GetPos()+Vector(0,0,45)):ToScreen().y + texty1, esp_col(v), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
				end
				texty1 = texty1 + 12
			elseif v:GetColor(v).a < 255 then
				if gOption("Visuals", "ESP", "Text Position") == "Left" then
					if gOption("Visuals", "ESP", "Health") == "Bar only" or gOption("Visuals", "ESP", "Health") == "Both" then
						draw.SimpleText("spawning *", font(), x1 - 10, y1 + texty1, esp_col(v), TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
					else
						draw.SimpleText("spawning *", font(), x1 - 4, y1 + texty1, esp_col(v), TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
					end
				elseif gOption("Visuals", "ESP", "Text Position") == "Right" then
					draw.SimpleText("* spawning", font(), x2 + 2, y1 + texty1, esp_col(v), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
				elseif gOption("Visuals", "ESP", "Text Position") == "Bottom" then
					draw.SimpleText("* spawning", font(), x1, y2 + texty1, esp_col(v), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
				else
					draw.SimpleText("* spawning *", font(), v:GetPos():ToScreen().x, (v:GetPos()+Vector(0,0,45)):ToScreen().y + texty1, esp_col(v), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
				end
				texty1 = texty1 + 12
			elseif v:GetMoveType() == MOVETYPE_OBSERVER then
				if gOption("Visuals", "ESP", "Text Position") == "Left" then
					if gOption("Visuals", "ESP", "Health") == "Bar only" or gOption("Visuals", "ESP", "Health") == "Both" then
						draw.SimpleText("spectating *", font(), x1 - 10, y1 + texty1, esp_col(v), TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
					else
						draw.SimpleText("spectating *", font(), x1 - 4, y1 + texty1, esp_col(v), TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
					end
				elseif gOption("Visuals", "ESP", "Text Position") == "Right" then
					draw.SimpleText("* spectating", font(), x2 + 2, y1 + texty1, esp_col(v), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
				elseif gOption("Visuals", "ESP", "Text Position") == "Bottom" then
					draw.SimpleText("* spectating", font(), x1, y2 + texty1, esp_col(v), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
				else
					draw.SimpleText("* spectating *", font(), v:GetPos():ToScreen().x, (v:GetPos()+Vector(0,0,45)):ToScreen().y + texty1, esp_col(v), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
				end
				texty1 = texty1 + 12
			elseif v:IsSprinting() then
				if gOption("Visuals", "ESP", "Text Position") == "Left" then
					if gOption("Visuals", "ESP", "Health") == "Bar only" or gOption("Visuals", "ESP", "Health") == "Both" then
						draw.SimpleText("sprinting *", font(), x1 - 10, y1 + texty1, esp_col(v), TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
					else
						draw.SimpleText("sprinting *", font(), x1 - 4, y1 + texty1, esp_col(v), TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
					end
				elseif gOption("Visuals", "ESP", "Text Position") == "Right" then
					draw.SimpleText("* sprinting", font(), x2 + 2, y1 + texty1, esp_col(v), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
				elseif gOption("Visuals", "ESP", "Text Position") == "Bottom" then
					draw.SimpleText("* sprinting", font(), x1, y2 + texty1, esp_col(v), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
				else
					draw.SimpleText("* sprinting *", font(), v:GetPos():ToScreen().x, (v:GetPos()+Vector(0,0,45)):ToScreen().y + texty1, esp_col(v), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
				end
				texty1 = texty1 + 12
			end
		end

		if gBool("Aimbot", "Misc", "Projectile Prediction") and me:GetActiveWeapon():IsValid() and v == aimtarget and aimtarget:IsValid() and WeaponShootable() then
			local predictedpos
			local pos = v:LocalToWorld(v:OBBCenter()):ToScreen()

			if v:GetVelocity():Length() >= 20 then
				surface.SetDrawColor(esp_col(v))

				if string.find(string.lower(me:GetActiveWeapon():GetPrintName()), "crossbow") then
					if aimtarget:GetPos():Distance(me:GetPos()) <= 1100 then
						predictedpos = (GetPos(aimtarget) + aimtarget:GetVelocity() * ((aimtarget:GetPos():Distance(me:GetPos())/1600)+me:Ping()/950) + Vector(0,0,aimtarget:GetPos():Distance(me:GetPos())/110)):ToScreen()
					else
						predictedpos = (GetPos(aimtarget) + aimtarget:GetVelocity() * ((aimtarget:GetPos():Distance(me:GetPos())/3215)+me:Ping()/950) + Vector(0,0,aimtarget:GetPos():Distance(me:GetPos())/110)):ToScreen()
					end

					surface.DrawLine(pos.x, pos.y, predictedpos.x, predictedpos.y)
					--surface.DrawLine(x1+diff/2, y1+diff2-2, predictedpos.x, predictedpos.y)
				elseif string.find(string.lower(me:GetActiveWeapon():GetClass()), "m9k_rpg7") or string.find(string.lower(me:GetActiveWeapon():GetClass()), "m9k_m202") then
					if aimtarget:GetPos():Distance(me:GetPos()) <= 2600 then
						predictedpos = (GetPos(aimtarget) + aimtarget:GetVelocity() * ((aimtarget:GetPos():Distance(me:GetPos())/4500)+me:Ping()/950) - Vector(0,0,25)):ToScreen()
					elseif aimtarget:GetPos():Distance(me:GetPos()) <= 4000 then
						predictedpos = (GetPos(aimtarget) + aimtarget:GetVelocity() * ((aimtarget:GetPos():Distance(me:GetPos())/4500)+me:Ping()/950) + Vector(0,0,aimtarget:GetPos():Distance(me:GetPos())/110)):ToScreen()
					else
						predictedpos = (GetPos(aimtarget) + aimtarget:GetVelocity() * ((aimtarget:GetPos():Distance(me:GetPos())/4500)+me:Ping()/950) + Vector(0,0,aimtarget:GetPos():Distance(me:GetPos())/90)):ToScreen()
					end

					surface.DrawLine(pos.x, pos.y, predictedpos.x, predictedpos.y)
				elseif string.find(string.lower(wep:GetClass()), "m9k_ex41") or string.find(string.lower(wep:GetClass()), "m9k_m79gl") then
					if aimtarget:GetPos():Distance(me:GetPos()) <= 1100 then
						predictedpos = (GetPos(aimtarget) + aimtarget:GetVelocity() * ((aimtarget:GetPos():Distance(me:GetPos())/2550)+me:Ping()/950) - Vector(0,0,25)):ToScreen()
					elseif aimtarget:GetPos():Distance(me:GetPos()) <= 4000 then
						predictedpos = (GetPos(aimtarget) + aimtarget:GetVelocity() * ((aimtarget:GetPos():Distance(me:GetPos())/2130)+me:Ping()/950) + Vector(0,0,aimtarget:GetPos():Distance(me:GetPos())/35)):ToScreen()
					elseif aimtarget:GetPos():Distance(me:GetPos()) <= 7000 then
						predictedpos = (GetPos(aimtarget) + aimtarget:GetVelocity() * ((aimtarget:GetPos():Distance(me:GetPos())/2130)+me:Ping()/950) + Vector(0,0,aimtarget:GetPos():Distance(me:GetPos())/13)):ToScreen()
					else
						predictedpos = (GetPos(aimtarget) + aimtarget:GetVelocity() * ((aimtarget:GetPos():Distance(me:GetPos())/2670)+me:Ping()/950) + Vector(0,0,aimtarget:GetPos():Distance(me:GetPos())/6)):ToScreen()
					end

					surface.DrawLine(pos.x, pos.y, predictedpos.x, predictedpos.y)
				elseif string.find(string.lower(wep:GetClass()), "m9k_matador") then
					if aimtarget:GetPos():Distance(me:GetPos()) <= 2600 then
						predictedpos = (GetPos(aimtarget) + aimtarget:GetVelocity() * ((aimtarget:GetPos():Distance(me:GetPos())/6500)+me:Ping()/950) - Vector(0,0,25)):ToScreen()
					elseif aimtarget:GetPos():Distance(me:GetPos()) <= 4000 then
						predictedpos = (GetPos(aimtarget) + aimtarget:GetVelocity() * ((aimtarget:GetPos():Distance(me:GetPos())/6500)+me:Ping()/950) + Vector(0,0,aimtarget:GetPos():Distance(me:GetPos())/110)):ToScreen()
					else
						predictedpos = (GetPos(aimtarget) + aimtarget:GetVelocity() * ((aimtarget:GetPos():Distance(me:GetPos())/6500)+me:Ping()/950) + Vector(0,0,aimtarget:GetPos():Distance(me:GetPos())/90)):ToScreen()
					end

					surface.DrawLine(pos.x, pos.y, predictedpos.x, predictedpos.y)
				elseif string.find(string.lower(wep:GetClass()), "m9k_milkormgl") then
					if aimtarget:GetPos():Distance(me:GetPos()) <= 1100 then
						predictedpos = (GetPos(aimtarget) + aimtarget:GetVelocity() * ((aimtarget:GetPos():Distance(me:GetPos())/2500)+me:Ping()/950) - Vector(0,0,25)):ToScreen()
					elseif aimtarget:GetPos():Distance(me:GetPos()) <= 4000 then
						predictedpos = (GetPos(aimtarget) + aimtarget:GetVelocity() * ((aimtarget:GetPos():Distance(me:GetPos())/2000)+me:Ping()/950) + Vector(0,0,aimtarget:GetPos():Distance(me:GetPos())/43)):ToScreen()
					elseif aimtarget:GetPos():Distance(me:GetPos()) <= 7000 then
						predictedpos = (GetPos(aimtarget) + aimtarget:GetVelocity() * ((aimtarget:GetPos():Distance(me:GetPos())/2460)+me:Ping()/950) + Vector(0,0,aimtarget:GetPos():Distance(me:GetPos())/38)):ToScreen()
					else
						predictedpos = (GetPos(aimtarget) + aimtarget:GetVelocity() * ((aimtarget:GetPos():Distance(me:GetPos())/2580)+me:Ping()/950) + Vector(0,0,aimtarget:GetPos():Distance(me:GetPos())/17.5)):ToScreen()
					end

					surface.DrawLine(pos.x, pos.y, predictedpos.x, predictedpos.y)
				elseif string.find(string.lower(wep:GetClass()), "m9k_m61_frag") then
					predictedpos = (GetPos(aimtarget) + aimtarget:GetVelocity() * ((aimtarget:GetPos():Distance(me:GetPos())/650)+me:Ping()/950) - Vector(0,0,225) + Vector(0,0,aimtarget:GetPos():Distance(me:GetPos())/4)):ToScreen()

					surface.DrawLine(pos.x, pos.y, predictedpos.x, predictedpos.y)
				elseif string.find(string.lower(wep:GetClass()), "m9k_harpoon") then
					if aimtarget:GetPos():Distance(me:GetPos()) <= 1200 then
						predictedpos = (GetPos(aimtarget) + aimtarget:GetVelocity() * ((aimtarget:GetPos():Distance(me:GetPos())/2300)+me:Ping()/950) + Vector(0,0,aimtarget:GetPos():Distance(me:GetPos())/20) - me:GetVelocity()/50):ToScreen()
					elseif aimtarget:GetPos():Distance(me:GetPos()) <= 1750 then
						predictedpos = (GetPos(aimtarget) + aimtarget:GetVelocity() * ((aimtarget:GetPos():Distance(me:GetPos())/2000)+me:Ping()/950) + Vector(0,0,aimtarget:GetPos():Distance(me:GetPos())/8) - me:GetVelocity()/50):ToScreen()
					elseif aimtarget:GetPos():Distance(me:GetPos()) <= 2000 then
						predictedpos = (GetPos(aimtarget) + aimtarget:GetVelocity() * ((aimtarget:GetPos():Distance(me:GetPos())/1500)+me:Ping()/950) + Vector(0,0,aimtarget:GetPos():Distance(me:GetPos())/5) - me:GetVelocity()/50):ToScreen()
					else
						predictedpos = (GetPos(aimtarget) + aimtarget:GetVelocity() * ((aimtarget:GetPos():Distance(me:GetPos())/900)+me:Ping()/950) + Vector(0,0,aimtarget:GetPos():Distance(me:GetPos())/3) - me:GetVelocity()/50):ToScreen()
					end

					surface.DrawLine(pos.x, pos.y, predictedpos.x, predictedpos.y)
				end
			end
		end

		if gOption("Visuals", "ESP", "Lines") ~= "Off" then
			local pos = v:LocalToWorld(v:OBBCenter()):ToScreen()
			surface.SetDrawColor(esp_col(v))

			if gBool("Visuals", "ESP", "Lines") == "Bottom" then
				surface.DrawLine(ScrW() / 2, ScrH(), pos.x, pos.y)
			elseif gBool("Visuals", "ESP", "Lines") == "Top" then
				surface.DrawLine(ScrW() / 2, 0, pos.x, pos.y)
			else
				surface.DrawLine(ScrW() / 2, ScrH()/2, pos.x, pos.y)
			end
		end

		if gBool("Visuals", "Other", "Glow") then
			halo.Add({v}, esp_col(v), 0.8, 0.8, 1, true, true)
		end
	end









        else
        -- Getting literally every entity in the map can really drop your frames
	for k,v in next, ents.GetAll() do
        --print("[LMAOBOX]: Optimization is disabled")






		if v:IsDormant() or not v:IsValid() then continue end

		if gBool("Visuals", "Other", "Aiming Player Alert") and v:IsPlayer() and v:IsValid() and v:Alive() and v ~= me and me:GetPos():Distance(v:GetEyeTrace().HitPos) < 105 and v:GetPos():Distance(me:GetPos()) > 80 then
			if gBool("Gamemode", "Murder", "Draw Bystander Names") and engine.ActiveGamemode() == "murder" then
				draw.SimpleText(v:GetNWString("bystanderName").." is aiming at you!", font(), ScrW()/2, ScrH()/1.93, MenuCol, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			else
				draw.SimpleText(v:Nick().." is aiming at you!", font(), ScrW()/2, ScrH()/1.93, MenuCol, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			end
		end

		if not maxdist(v) or not onscreen(v) or v == me then continue end

		if table.HasValue(supported_modes, engine.ActiveGamemode()) then
			if engine.ActiveGamemode() == "murder" then
				if gBool("Gamemode", "Murder", "Draw Magnum") then
					if string.find(v:GetClass(), "weapon_mu_magnum") then
						pos = v:GetPos()
						pos = pos:ToScreen()
						draw.DrawText("Magnum", font(), pos.x, pos.y, Color(50,150,255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
					end
				end

				if gBool("Gamemode", "Murder", "Draw Knife") then
					if string.find(v:GetClass(), "weapon_mu_knife") then
						pos = v:GetPos()
						pos = pos:ToScreen()
						draw.DrawText("Knife", font(), pos.x, pos.y, Color(255,75,75), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
					end
				end

				if gBool("Gamemode", "Murder", "Draw Loot") then
					if string.find(v:GetClass(), "mu_loot") then
						pos = v:GetPos()
						pos = pos:ToScreen()
						draw.DrawText("Loot", font(), pos.x, pos.y, Color(50,255,50), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
					end
				end
			end
		end


		if gBool("Visuals", "ESP", "Vision Line") then
                                     local b1, b2 = v:EyePos(), v:GetEyeTrace().HitPos
		 render.DrawLine(b1, b2, teamcol)
		 render.DrawWireframeSphere(b2, 2, 10, 10, teamcol, b2)
                                    end

		if gBool("Misc", "VIP", "Entity Finder") and license() == "Lifetime" then
			if table.HasValue(drawn_ents, v:GetClass()) and v:IsValid() and v:GetPos():Distance(me:GetPos()) > 40 then
				local min, max = v:WorldSpaceAABB()
				local origin = v:GetPos()

				cam.Start3D()
					render.DrawWireframeBox(origin, Angle(0,0,0), min-origin, max-origin, esp_col(v), true) 
				cam.End3D()
			end
		end

		if v:Health() < 1 or v:IsDormant() or not filter(v) then continue end

		texty1 = 5

		x1, y1, x2, y2 = ScrW() * 2, ScrH() * 2, -ScrW(), -ScrH()
		min, max = v:GetCollisionBounds()
		corners = { v:LocalToWorld(Vector(min.x, min.y, min.z)):ToScreen(), v:LocalToWorld(Vector(min.x, max.y, min.z)):ToScreen(), v:LocalToWorld(Vector(max.x, max.y, min.z)):ToScreen(), v:LocalToWorld(Vector(max.x, min.y, min.z)):ToScreen(), v:LocalToWorld(Vector(min.x, min.y, max.z)):ToScreen(), v:LocalToWorld(Vector(min.x, max.y, max.z)):ToScreen(), v:LocalToWorld(Vector(max.x, max.y, max.z)):ToScreen(), v:LocalToWorld(Vector(max.x, min.y, max.z)):ToScreen() }
	
		for _k, _v in next, corners do
			x1, y1 = math.min(x1, _v.x), math.min(y1, _v.y)
			x2, y2 = math.max(x2, _v.x), math.max(y2, _v.y)
		end
		
		diff, diff2 = math.abs(x2 - x1), math.abs(y2 - y1)

		if gOption("Visuals", "ESP", "Box") ~= "Off" then
			if gOption("Visuals", "ESP", "Box") == "2D (Outlined)" then
				surface.SetDrawColor(0,0,0)
				surface.DrawOutlinedRect(x1 - 1, y1 - 1, diff + 2, diff2 + 2)
				surface.DrawOutlinedRect(x1 + 1, y1 + 1, diff - 2, diff2 - 2)
				surface.SetDrawColor(esp_col(v))
				surface.DrawOutlinedRect(x1, y1, diff, diff2)
			elseif gOption("Visuals", "ESP", "Box") == "2D (Semi-Solid)" then
				surface.SetDrawColor(0,0,0)
				surface.DrawOutlinedRect(x1 - 1, y1 - 1, diff + 2, diff2 + 2)
				--surface.DrawOutlinedRect(x1 + 1, y1 + 1, diff - 2, diff2 - 2)
				surface.SetDrawColor(esp_col(v))
				surface.DrawOutlinedRect(x1, y1, diff, diff2)
			elseif gOption("Visuals", "ESP", "Box") == "2D (Solid)" then
				surface.SetDrawColor(esp_col(v))
		
				--surface.DrawOutlinedRect(x1 - 1, y1 - 1, diff + 2, diff2 + 2)
				surface.DrawOutlinedRect(x1, y1, diff, diff2)
			elseif gOption("Visuals", "ESP", "Box") == "3D" then
				for i = 1, 4 do
					surface.SetDrawColor(esp_col(v))
					surface.DrawLine(corners[i].x, corners[i].y, corners[i + 4].x, corners[i + 4].y)
					surface.DrawLine(corners[i].x, corners[i].y, corners[i % 4 + 1].x, corners[i % 4 + 1].y)
					surface.DrawLine(corners[i + 4].x, corners[i + 4].y, corners[i % 4 + 5].x, corners[i % 4 + 5].y)
				end
			else
				surface.SetDrawColor(0,0,0)
				surface.DrawLine(x1,y1,x1+(diff*0.225),y1)
				surface.DrawLine(x1,y1,x1,y1+(diff2*0.225))
				surface.DrawLine(x1,y2,x1+(diff*0.225),y2)
				surface.DrawLine(x1,y2,x1,y2-(diff2*0.225))
				surface.DrawLine(x2,y1,x2-(diff*0.225),y1)
				surface.DrawLine(x2,y1,x2,y1+(diff2*0.225))
				surface.DrawLine(x2,y2,x2-(diff*0.225),y2)
				surface.DrawLine(x2,y2,x2,y2-(diff2*0.225))

				surface.SetDrawColor(esp_col(v))
				surface.DrawLine(x1+1,y1+1,x1+(diff*0.225),y1+1)
				surface.DrawLine(x1+1,y1+1,x1+1,y1+(diff2*0.225))
				surface.DrawLine(x1+1,y2-1,x1+(diff*0.225),y2-1)
				surface.DrawLine(x1+1,y2-1,x1+1,y2-(diff2*0.225))
				surface.DrawLine(x2-1,y1+1,x2-(diff*0.225),y1+1)
				surface.DrawLine(x2-1,y1+1,x2-1,y1+(diff2*0.225))
				surface.DrawLine(x2-1,y2-1,x2-(diff*0.225),y2-1)
				surface.DrawLine(x2-1,y2-1,x2-1,y2-(diff2*0.225))
			end
		end

		if gBool("Visuals", "ESP", "Bones") then
			for i = 0, v:GetBoneCount() do
				local parent = v:GetBoneParent(i)
				if not v:GetBoneParent(i) then continue end
				local bonepos = v:GetBonePosition(i)
				if v:GetBonePosition(i) == v:GetPos() then continue end
				local parentpos = v:GetBonePosition(v:GetBoneParent(i))
				if not v:GetBonePosition(i) or not v:GetBonePosition(v:GetBoneParent(i)) then continue end
				local screen1, screen2 = bonepos:ToScreen(), parentpos:ToScreen()

				surface.SetDrawColor(esp_col(v))
				surface.DrawLine(screen1.x, screen1.y, screen2.x, screen2.y)
			end
		end


		if gBool("Visuals", "ESP", "Names") then
			if v:IsPlayer() then
				if gBool("Gamemode", "Murder", "Draw Bystander Names") and engine.ActiveGamemode() == "murder" then
					if gOption("Visuals", "ESP", "Text Position") == "Left" then
						if gOption("Visuals", "ESP", "Health") == "Bar only" or gOption("Visuals", "ESP", "Health") == "Both" then
							draw.SimpleText(v:GetNWString("bystanderName"), font(), x1 - 10, y1 + texty1, esp_col(v), TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
						else
							draw.SimpleText(v:GetNWString("bystanderName"), font(), x1 - 4, y1 + texty1, esp_col(v), TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
						end
					elseif gOption("Visuals", "ESP", "Text Position") == "Right" then
						draw.SimpleText(v:GetNWString("bystanderName"), font(), x2 + 2, y1 + texty1, esp_col(v), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
					elseif gOption("Visuals", "ESP", "Text Position") == "Bottom" then
						draw.SimpleText(v:GetNWString("bystanderName"), font(), x1, y2 + texty1, esp_col(v), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
					else
						draw.SimpleText(v:GetNWString("bystanderName"), font(), v:GetPos():ToScreen().x, (v:GetPos()+Vector(0,0,45)):ToScreen().y + texty1, esp_col(v), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
					end
				else
					if gOption("Visuals", "ESP", "Text Position") == "Left" then
						if gOption("Visuals", "ESP", "Health") == "Bar only" or gOption("Visuals", "ESP", "Health") == "Both" then
							draw.SimpleText(v:Nick(), font(), x1 - 10, y1 + texty1, esp_col(v), TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
						else
							draw.SimpleText(v:Nick(), font(), x1 - 4, y1 + texty1, esp_col(v), TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
						end
					elseif gOption("Visuals", "ESP", "Text Position") == "Right" then
						draw.SimpleText(v:Nick(), font(), x2 + 2, y1 + texty1, esp_col(v), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
					elseif gOption("Visuals", "ESP", "Text Position") == "Bottom" then
						draw.SimpleText(v:Nick(), font(), x1, y2 + texty1, esp_col(v), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
					else
						draw.SimpleText(v:Nick(), font(), v:GetPos():ToScreen().x, (v:GetPos()+Vector(0,0,45)):ToScreen().y + texty1, esp_col(v), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
					end
				end
			else
				if gOption("Visuals", "ESP", "Text Position") == "Left" then
					if gOption("Visuals", "ESP", "Health") == "Bar only" or gOption("Visuals", "ESP", "Health") == "Both" then
							draw.SimpleText(v:GetClass(), font(), x1 - 10, y1 + texty1, esp_col(v), TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
						else
							draw.SimpleText(v:GetClass(), font(), x1 - 4, y1 + texty1, esp_col(v), TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
						end
				elseif gOption("Visuals", "ESP", "Text Position") == "Right" then
					draw.SimpleText(v:GetClass(), font(), x2 + 2, y1 + texty1, esp_col(v), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
				elseif gOption("Visuals", "ESP", "Text Position") == "Bottom" then
					draw.SimpleText(v:GetClass(), font(), x1, y2 + texty1, esp_col(v), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
				else
					draw.SimpleText(v:GetClass(), font(), v:GetPos():ToScreen().x, (v:GetPos()+Vector(0,0,45)):ToScreen().y + texty1, esp_col(v), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
				end
			end

			texty1 = texty1 + 12
		end

		if gOption("Visuals", "ESP", "Health") ~= "Off" then
			if gOption("Visuals", "ESP", "Health") == "Value only" then
				if gOption("Visuals", "ESP", "Text Position") == "Left" then
					draw.SimpleText(v:Health().." HP", font(), x1 - 4, y1 + texty1, Color(255 - 255 / v:GetMaxHealth() * v:Health(), 255 / v:GetMaxHealth() * v:Health(), 0), TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
				elseif gOption("Visuals", "ESP", "Text Position") == "Right" then
					draw.SimpleText(v:Health().." HP", font(), x2 + 2, y1 + texty1, Color(255 - 255 / v:GetMaxHealth() * v:Health(), 255 / v:GetMaxHealth() * v:Health(), 0), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
				elseif gOption("Visuals", "ESP", "Text Position") == "Bottom" then
					draw.SimpleText(v:Health().." HP", font(), x1, y2 + texty1, Color(255 - 255 / v:GetMaxHealth() * v:Health(), 255 / v:GetMaxHealth() * v:Health(), 0), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
				else
					draw.SimpleText(v:Health().." HP", font(), v:GetPos():ToScreen().x, (v:GetPos()+Vector(0,0,45)):ToScreen().y + texty1, Color(255 - 255 / v:GetMaxHealth() * v:Health(), 255 / v:GetMaxHealth() * v:Health(), 0), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
				end
				texty1 = texty1 + 12
			elseif gOption("Visuals", "ESP", "Health") == "Bar only" then
				surface.SetDrawColor(0,0,0)
				surface.DrawRect(x1 - 6, y1, 3, diff2)
				surface.DrawRect(x1 - 7, y1 - 1, 5, diff2 + 2)

				surface.SetDrawColor(Color(255 - 255 / v:GetMaxHealth() * v:Health(), 255 / v:GetMaxHealth() * v:Health(), 0))
				surface.DrawRect(x1 - 6, y2 - math.Clamp(diff2 / v:GetMaxHealth() * v:Health(), 0, diff2), 3, math.Clamp(diff2 / v:GetMaxHealth() * v:Health(), 0, diff2))
			else
				if gOption("Visuals", "ESP", "Text Position") == "Left" then
					draw.SimpleText(v:Health().." HP", font(), x1 - 10, y1 + texty1, Color(255 - 255 / v:GetMaxHealth() * v:Health(), 255 / v:GetMaxHealth() * v:Health(), 0), TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
				elseif gOption("Visuals", "ESP", "Text Position") == "Right" then
					draw.SimpleText(v:Health().." HP", font(), x2 + 2, y1 + texty1, Color(255 - 255 / v:GetMaxHealth() * v:Health(), 255 / v:GetMaxHealth() * v:Health(), 0), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
				elseif gOption("Visuals", "ESP", "Text Position") == "Bottom" then
					draw.SimpleText(v:Health().." HP", font(), x1, y2 + texty1, Color(255 - 255 / v:GetMaxHealth() * v:Health(), 255 / v:GetMaxHealth() * v:Health(), 0), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
				else
					draw.SimpleText(v:Health().." HP", font(), v:GetPos():ToScreen().x, (v:GetPos()+Vector(0,0,45)):ToScreen().y + texty1, Color(255 - 255 / v:GetMaxHealth() * v:Health(), 255 / v:GetMaxHealth() * v:Health(), 0), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
				end
				texty1 = texty1 + 12

				surface.SetDrawColor(0,0,0)
				surface.DrawRect(x1 - 6, y1, 3, diff2)
				surface.DrawRect(x1 - 7, y1 - 1, 5, diff2 + 2)

				surface.SetDrawColor(Color(255 - 255 / v:GetMaxHealth() * v:Health(), 255 / v:GetMaxHealth() * v:Health(), 0))
				surface.DrawRect(x1 - 6, y2 - math.Clamp(diff2 / v:GetMaxHealth() * v:Health(), 0, diff2), 3, math.Clamp(diff2 / v:GetMaxHealth() * v:Health(), 0, diff2))
			end
		end

		if gBool("Visuals", "ESP", "Conditions") and v:IsPlayer() then
			if v:InVehicle() then
				if gOption("Visuals", "ESP", "Text Position") == "Left" then
					if gOption("Visuals", "ESP", "Health") == "Bar only" or gOption("Visuals", "ESP", "Health") == "Both" then
						draw.SimpleText("driving *", font(), x1 - 10, y1 + texty1, esp_col(v), TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
					else
						draw.SimpleText("driving *", font(), x1 - 4, y1 + texty1, esp_col(v), TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
					end
				elseif gOption("Visuals", "ESP", "Text Position") == "Right" then
					draw.SimpleText("* driving", font(), x2 + 2, y1 + texty1, esp_col(v), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
				elseif gOption("Visuals", "ESP", "Text Position") == "Bottom" then
					draw.SimpleText("* driving", font(), x1, y2 + texty1, esp_col(v), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
				else
					draw.SimpleText("* driving *", font(), v:GetPos():ToScreen().x, (v:GetPos()+Vector(0,0,45)):ToScreen().y + texty1, esp_col(v), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
				end
				texty1 = texty1 + 12
			elseif v:GetMoveType() == MOVETYPE_NOCLIP then
				if gOption("Visuals", "ESP", "Text Position") == "Left" then
					if gOption("Visuals", "ESP", "Health") == "Bar only" or gOption("Visuals", "ESP", "Health") == "Both" then
						draw.SimpleText("noclipping *", font(), x1 - 10, y1 + texty1, esp_col(v), TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
					else
						draw.SimpleText("noclipping *", font(), x1 - 4, y1 + texty1, esp_col(v), TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
					end
				elseif gOption("Visuals", "ESP", "Text Position") == "Right" then
					draw.SimpleText("* noclipping", font(), x2 + 2, y1 + texty1, esp_col(v), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
				elseif gOption("Visuals", "ESP", "Text Position") == "Bottom" then
					draw.SimpleText("* noclipping", font(), x1, y2 + texty1, esp_col(v), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
				else
					draw.SimpleText("* noclipping *", font(), v:GetPos():ToScreen().x, (v:GetPos()+Vector(0,0,45)):ToScreen().y + texty1, esp_col(v), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
				end
				texty1 = texty1 + 12
			elseif v:IsFlagSet(2) then
				if gOption("Visuals", "ESP", "Text Position") == "Left" then
					if gOption("Visuals", "ESP", "Health") == "Bar only" or gOption("Visuals", "ESP", "Health") == "Both" then
						draw.SimpleText("crouching *", font(), x1 - 10, y1 + texty1, esp_col(v), TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
					else
						draw.SimpleText("crouching *", font(), x1 - 4, y1 + texty1, esp_col(v), TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
					end
				elseif gOption("Visuals", "ESP", "Text Position") == "Right" then
					draw.SimpleText("* crouching", font(), x2 + 2, y1 + texty1, esp_col(v), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
				elseif gOption("Visuals", "ESP", "Text Position") == "Bottom" then
					draw.SimpleText("* crouching", font(), x1, y2 + texty1, esp_col(v), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
				else
					draw.SimpleText("* crouching *", font(), v:GetPos():ToScreen().x, (v:GetPos()+Vector(0,0,45)):ToScreen().y + texty1, esp_col(v), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
				end
				texty1 = texty1 + 12
			elseif v:GetMoveType() == MOVETYPE_LADDER then
				if gOption("Visuals", "ESP", "Text Position") == "Left" then
					if gOption("Visuals", "ESP", "Health") == "Bar only" or gOption("Visuals", "ESP", "Health") == "Both" then
						draw.SimpleText("climbing *", font(), x1 - 10, y1 + texty1, esp_col(v), TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
					else
						draw.SimpleText("climbing *", font(), x1 - 4, y1 + texty1, esp_col(v), TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
					end
				elseif gOption("Visuals", "ESP", "Text Position") == "Right" then
					draw.SimpleText("* climbing", font(), x2 + 2, y1 + texty1, esp_col(v), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
				elseif gOption("Visuals", "ESP", "Text Position") == "Bottom" then
					draw.SimpleText("* climbing", font(), x1, y2 + texty1, esp_col(v), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
				else
					draw.SimpleText("* climbing *", font(), v:GetPos():ToScreen().x, (v:GetPos()+Vector(0,0,45)):ToScreen().y + texty1, esp_col(v), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
				end
				texty1 = texty1 + 12
			elseif v:IsFlagSet(268435456) then
				if gOption("Visuals", "ESP", "Text Position") == "Left" then
					if gOption("Visuals", "ESP", "Health") == "Bar only" or gOption("Visuals", "ESP", "Health") == "Both" then
						draw.SimpleText("burning *", font(), x1 - 10, y1 + texty1, esp_col(v), TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
					else
						draw.SimpleText("burning *", font(), x1 - 4, y1 + texty1, esp_col(v), TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
					end
				elseif gOption("Visuals", "ESP", "Text Position") == "Right" then
					draw.SimpleText("* burning", font(), x2 + 2, y1 + texty1, esp_col(v), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
				elseif gOption("Visuals", "ESP", "Text Position") == "Bottom" then
					draw.SimpleText("* burning", font(), x1, y2 + texty1, esp_col(v), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
				else
					draw.SimpleText("* burning *", font(), v:GetPos():ToScreen().x, (v:GetPos()+Vector(0,0,45)):ToScreen().y + texty1, esp_col(v), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
				end
				texty1 = texty1 + 12
			elseif v:GetColor(v).a < 255 then
				if gOption("Visuals", "ESP", "Text Position") == "Left" then
					if gOption("Visuals", "ESP", "Health") == "Bar only" or gOption("Visuals", "ESP", "Health") == "Both" then
						draw.SimpleText("spawning *", font(), x1 - 10, y1 + texty1, esp_col(v), TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
					else
						draw.SimpleText("spawning *", font(), x1 - 4, y1 + texty1, esp_col(v), TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
					end
				elseif gOption("Visuals", "ESP", "Text Position") == "Right" then
					draw.SimpleText("* spawning", font(), x2 + 2, y1 + texty1, esp_col(v), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
				elseif gOption("Visuals", "ESP", "Text Position") == "Bottom" then
					draw.SimpleText("* spawning", font(), x1, y2 + texty1, esp_col(v), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
				else
					draw.SimpleText("* spawning *", font(), v:GetPos():ToScreen().x, (v:GetPos()+Vector(0,0,45)):ToScreen().y + texty1, esp_col(v), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
				end
				texty1 = texty1 + 12
			elseif v:GetMoveType() == MOVETYPE_OBSERVER then
				if gOption("Visuals", "ESP", "Text Position") == "Left" then
					if gOption("Visuals", "ESP", "Health") == "Bar only" or gOption("Visuals", "ESP", "Health") == "Both" then
						draw.SimpleText("spectating *", font(), x1 - 10, y1 + texty1, esp_col(v), TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
					else
						draw.SimpleText("spectating *", font(), x1 - 4, y1 + texty1, esp_col(v), TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
					end
				elseif gOption("Visuals", "ESP", "Text Position") == "Right" then
					draw.SimpleText("* spectating", font(), x2 + 2, y1 + texty1, esp_col(v), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
				elseif gOption("Visuals", "ESP", "Text Position") == "Bottom" then
					draw.SimpleText("* spectating", font(), x1, y2 + texty1, esp_col(v), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
				else
					draw.SimpleText("* spectating *", font(), v:GetPos():ToScreen().x, (v:GetPos()+Vector(0,0,45)):ToScreen().y + texty1, esp_col(v), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
				end
				texty1 = texty1 + 12
			elseif v:IsSprinting() then
				if gOption("Visuals", "ESP", "Text Position") == "Left" then
					if gOption("Visuals", "ESP", "Health") == "Bar only" or gOption("Visuals", "ESP", "Health") == "Both" then
						draw.SimpleText("sprinting *", font(), x1 - 10, y1 + texty1, esp_col(v), TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
					else
						draw.SimpleText("sprinting *", font(), x1 - 4, y1 + texty1, esp_col(v), TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
					end
				elseif gOption("Visuals", "ESP", "Text Position") == "Right" then
					draw.SimpleText("* sprinting", font(), x2 + 2, y1 + texty1, esp_col(v), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
				elseif gOption("Visuals", "ESP", "Text Position") == "Bottom" then
					draw.SimpleText("* sprinting", font(), x1, y2 + texty1, esp_col(v), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
				else
					draw.SimpleText("* sprinting *", font(), v:GetPos():ToScreen().x, (v:GetPos()+Vector(0,0,45)):ToScreen().y + texty1, esp_col(v), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
				end
				texty1 = texty1 + 12
			end
		end

		if gBool("Aimbot", "Misc", "Projectile Prediction") and me:GetActiveWeapon():IsValid() and v == aimtarget and aimtarget:IsValid() and WeaponShootable() then
			local predictedpos
			local pos = v:LocalToWorld(v:OBBCenter()):ToScreen()

			if v:GetVelocity():Length() >= 20 then
				surface.SetDrawColor(esp_col(v))

				if string.find(string.lower(me:GetActiveWeapon():GetPrintName()), "crossbow") then
					if aimtarget:GetPos():Distance(me:GetPos()) <= 1100 then
						predictedpos = (GetPos(aimtarget) + aimtarget:GetVelocity() * ((aimtarget:GetPos():Distance(me:GetPos())/1600)+me:Ping()/950) + Vector(0,0,aimtarget:GetPos():Distance(me:GetPos())/110)):ToScreen()
					else
						predictedpos = (GetPos(aimtarget) + aimtarget:GetVelocity() * ((aimtarget:GetPos():Distance(me:GetPos())/3215)+me:Ping()/950) + Vector(0,0,aimtarget:GetPos():Distance(me:GetPos())/110)):ToScreen()
					end

					surface.DrawLine(pos.x, pos.y, predictedpos.x, predictedpos.y)
					--surface.DrawLine(x1+diff/2, y1+diff2-2, predictedpos.x, predictedpos.y)
				elseif string.find(string.lower(me:GetActiveWeapon():GetClass()), "m9k_rpg7") or string.find(string.lower(me:GetActiveWeapon():GetClass()), "m9k_m202") then
					if aimtarget:GetPos():Distance(me:GetPos()) <= 2600 then
						predictedpos = (GetPos(aimtarget) + aimtarget:GetVelocity() * ((aimtarget:GetPos():Distance(me:GetPos())/4500)+me:Ping()/950) - Vector(0,0,25)):ToScreen()
					elseif aimtarget:GetPos():Distance(me:GetPos()) <= 4000 then
						predictedpos = (GetPos(aimtarget) + aimtarget:GetVelocity() * ((aimtarget:GetPos():Distance(me:GetPos())/4500)+me:Ping()/950) + Vector(0,0,aimtarget:GetPos():Distance(me:GetPos())/110)):ToScreen()
					else
						predictedpos = (GetPos(aimtarget) + aimtarget:GetVelocity() * ((aimtarget:GetPos():Distance(me:GetPos())/4500)+me:Ping()/950) + Vector(0,0,aimtarget:GetPos():Distance(me:GetPos())/90)):ToScreen()
					end

					surface.DrawLine(pos.x, pos.y, predictedpos.x, predictedpos.y)
				elseif string.find(string.lower(wep:GetClass()), "m9k_ex41") or string.find(string.lower(wep:GetClass()), "m9k_m79gl") then
					if aimtarget:GetPos():Distance(me:GetPos()) <= 1100 then
						predictedpos = (GetPos(aimtarget) + aimtarget:GetVelocity() * ((aimtarget:GetPos():Distance(me:GetPos())/2550)+me:Ping()/950) - Vector(0,0,25)):ToScreen()
					elseif aimtarget:GetPos():Distance(me:GetPos()) <= 4000 then
						predictedpos = (GetPos(aimtarget) + aimtarget:GetVelocity() * ((aimtarget:GetPos():Distance(me:GetPos())/2130)+me:Ping()/950) + Vector(0,0,aimtarget:GetPos():Distance(me:GetPos())/35)):ToScreen()
					elseif aimtarget:GetPos():Distance(me:GetPos()) <= 7000 then
						predictedpos = (GetPos(aimtarget) + aimtarget:GetVelocity() * ((aimtarget:GetPos():Distance(me:GetPos())/2130)+me:Ping()/950) + Vector(0,0,aimtarget:GetPos():Distance(me:GetPos())/13)):ToScreen()
					else
						predictedpos = (GetPos(aimtarget) + aimtarget:GetVelocity() * ((aimtarget:GetPos():Distance(me:GetPos())/2670)+me:Ping()/950) + Vector(0,0,aimtarget:GetPos():Distance(me:GetPos())/6)):ToScreen()
					end

					surface.DrawLine(pos.x, pos.y, predictedpos.x, predictedpos.y)
				elseif string.find(string.lower(wep:GetClass()), "m9k_matador") then
					if aimtarget:GetPos():Distance(me:GetPos()) <= 2600 then
						predictedpos = (GetPos(aimtarget) + aimtarget:GetVelocity() * ((aimtarget:GetPos():Distance(me:GetPos())/6500)+me:Ping()/950) - Vector(0,0,25)):ToScreen()
					elseif aimtarget:GetPos():Distance(me:GetPos()) <= 4000 then
						predictedpos = (GetPos(aimtarget) + aimtarget:GetVelocity() * ((aimtarget:GetPos():Distance(me:GetPos())/6500)+me:Ping()/950) + Vector(0,0,aimtarget:GetPos():Distance(me:GetPos())/110)):ToScreen()
					else
						predictedpos = (GetPos(aimtarget) + aimtarget:GetVelocity() * ((aimtarget:GetPos():Distance(me:GetPos())/6500)+me:Ping()/950) + Vector(0,0,aimtarget:GetPos():Distance(me:GetPos())/90)):ToScreen()
					end

					surface.DrawLine(pos.x, pos.y, predictedpos.x, predictedpos.y)
				elseif string.find(string.lower(wep:GetClass()), "m9k_milkormgl") then
					if aimtarget:GetPos():Distance(me:GetPos()) <= 1100 then
						predictedpos = (GetPos(aimtarget) + aimtarget:GetVelocity() * ((aimtarget:GetPos():Distance(me:GetPos())/2500)+me:Ping()/950) - Vector(0,0,25)):ToScreen()
					elseif aimtarget:GetPos():Distance(me:GetPos()) <= 4000 then
						predictedpos = (GetPos(aimtarget) + aimtarget:GetVelocity() * ((aimtarget:GetPos():Distance(me:GetPos())/2000)+me:Ping()/950) + Vector(0,0,aimtarget:GetPos():Distance(me:GetPos())/43)):ToScreen()
					elseif aimtarget:GetPos():Distance(me:GetPos()) <= 7000 then
						predictedpos = (GetPos(aimtarget) + aimtarget:GetVelocity() * ((aimtarget:GetPos():Distance(me:GetPos())/2460)+me:Ping()/950) + Vector(0,0,aimtarget:GetPos():Distance(me:GetPos())/38)):ToScreen()
					else
						predictedpos = (GetPos(aimtarget) + aimtarget:GetVelocity() * ((aimtarget:GetPos():Distance(me:GetPos())/2580)+me:Ping()/950) + Vector(0,0,aimtarget:GetPos():Distance(me:GetPos())/17.5)):ToScreen()
					end

					surface.DrawLine(pos.x, pos.y, predictedpos.x, predictedpos.y)
				elseif string.find(string.lower(wep:GetClass()), "m9k_m61_frag") then
					predictedpos = (GetPos(aimtarget) + aimtarget:GetVelocity() * ((aimtarget:GetPos():Distance(me:GetPos())/650)+me:Ping()/950) - Vector(0,0,225) + Vector(0,0,aimtarget:GetPos():Distance(me:GetPos())/4)):ToScreen()

					surface.DrawLine(pos.x, pos.y, predictedpos.x, predictedpos.y)
				elseif string.find(string.lower(wep:GetClass()), "m9k_harpoon") then
					if aimtarget:GetPos():Distance(me:GetPos()) <= 1200 then
						predictedpos = (GetPos(aimtarget) + aimtarget:GetVelocity() * ((aimtarget:GetPos():Distance(me:GetPos())/2300)+me:Ping()/950) + Vector(0,0,aimtarget:GetPos():Distance(me:GetPos())/20) - me:GetVelocity()/50):ToScreen()
					elseif aimtarget:GetPos():Distance(me:GetPos()) <= 1750 then
						predictedpos = (GetPos(aimtarget) + aimtarget:GetVelocity() * ((aimtarget:GetPos():Distance(me:GetPos())/2000)+me:Ping()/950) + Vector(0,0,aimtarget:GetPos():Distance(me:GetPos())/8) - me:GetVelocity()/50):ToScreen()
					elseif aimtarget:GetPos():Distance(me:GetPos()) <= 2000 then
						predictedpos = (GetPos(aimtarget) + aimtarget:GetVelocity() * ((aimtarget:GetPos():Distance(me:GetPos())/1500)+me:Ping()/950) + Vector(0,0,aimtarget:GetPos():Distance(me:GetPos())/5) - me:GetVelocity()/50):ToScreen()
					else
						predictedpos = (GetPos(aimtarget) + aimtarget:GetVelocity() * ((aimtarget:GetPos():Distance(me:GetPos())/900)+me:Ping()/950) + Vector(0,0,aimtarget:GetPos():Distance(me:GetPos())/3) - me:GetVelocity()/50):ToScreen()
					end

					surface.DrawLine(pos.x, pos.y, predictedpos.x, predictedpos.y)
				end
			end
		end

		if gOption("Visuals", "ESP", "Lines") ~= "Off" then
			local pos = v:LocalToWorld(v:OBBCenter()):ToScreen()
			surface.SetDrawColor(esp_col(v))

			if gBool("Visuals", "ESP", "Lines") == "Bottom" then
				surface.DrawLine(ScrW() / 2, ScrH(), pos.x, pos.y)
			elseif gBool("Visuals", "ESP", "Lines") == "Top" then
				surface.DrawLine(ScrW() / 2, 0, pos.x, pos.y)
			else
				surface.DrawLine(ScrW() / 2, ScrH()/2, pos.x, pos.y)
			end
		end

		if gBool("Visuals", "Other", "Glow") then
			halo.Add({v}, esp_col(v), 0.8, 0.8, 1, true, true)
		end
	end


-- end for stuff
end






end

local function aimfov()
	local center = Vector(ScrW()/2, ScrH()/2, 0)
	local scale = Vector(gInt("Aimbot","Aimbot","Aimbot FOV")*11.8, gInt("Aimbot","Aimbot","Aimbot FOV")*11.8, 0)
	local segmentdist = 360 / (2 * math.pi * math.max(scale.x, scale.y)/2)

	surface.SetDrawColor(MenuCol)

	for a = 0, 360 - segmentdist, segmentdist do
		surface.DrawLine(center.x + math.cos( math.rad( a ) ) * scale.x, center.y - math.sin( math.rad( a ) ) * scale.y, center.x + math.cos( math.rad( a + segmentdist ) ) * scale.x, center.y - math.sin( math.rad( a + segmentdist ) ) * scale.y)
	end
end

local function specalert()
	local spectators = 0

	for k, v in next, player.GetAll() do
		if not v:GetObserverTarget() or not v:GetObserverTarget():IsValid() or not v:GetObserverTarget():IsPlayer() or not me:Alive() then continue end

		if gOption("Visuals", "Other", "Spectating Player Alert") == "On me" then
			if v:GetObserverTarget() == me then
				draw.SimpleText(v:Nick(), ArialB_Bigger, ScrW()/2, ScrH()/15 + spectators, PrimaryCol, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
				spectators = spectators + 13
			end
		else
			if v:GetObserverTarget() == me then
				draw.SimpleText(v:Nick().." > "..v:GetObserverTarget():Nick(), ArialB_Bigger, ScrW()/2, ScrH()/15 + spectators, AimCol, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
			else
				draw.SimpleText(v:Nick().." > "..v:GetObserverTarget():Nick(), ArialB_Bigger, ScrW()/2, ScrH()/15 + spectators, PrimaryCol, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
			end
			spectators = spectators + 13
		end
	end

	if spectators > 0 then
		draw.SimpleText("Spectators (".. spectators/13 ..")", ArialB_Bigger, ScrW()/2, ScrH()/15 - 13, MenuCol, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
	end
end

local function radar()
	local radar_size, radar_scale, radar_x, radar_y = 100 + gInt("Visuals", "Radar", "Size"), 10 + gInt("Visuals", "Radar", "Distance") + me:GetVelocity():Length()/35, gInt("Visuals", "Radar", "X-Position"), gInt("Visuals", "Radar", "Y-Position")

	local cpos = me:GetPos()
	local ang = math.rad(fa.y - 90)
	local cos, sin = math.cos(ang), math.sin(ang)

	-- Old: local ang = math.rad(me:EyeAngles().y - 90)

	local radar_center_x = radar_x + radar_size * 0.5
	local radar_center_y = radar_y + radar_size * 0.5

	surface.SetDrawColor(0, 0, 0, 220)
	surface.DrawRect(radar_x-1, radar_y-1, radar_size+2, radar_size+2) -- Background

	--[[surface.SetDrawColor(0,0,0)
	surface.DrawOutlinedRect(radar_x-1, radar_y-1, radar_size+2, radar_size+2) -- Outline  ]]

	surface.SetDrawColor(MenuCol)
	surface.DrawOutlinedRect(radar_x, radar_y, radar_size, radar_size) -- Outline
	surface.DrawLine(radar_center_x, radar_y, radar_center_x, radar_y + radar_size) -- Y Axis
	surface.DrawLine(radar_x, radar_center_y, radar_x + radar_size, radar_center_y) -- X Axis

	render.SetScissorRect(radar_x + 1, radar_y + 1, radar_x + radar_size - 1, radar_y + radar_size - 1, true)

	for k,v in next, ents.GetAll() do
		if v:IsDormant() or not v:IsValid() or not maxdist(v) or v:Health() < 1 or v:IsDormant() or v == me or not filter(v) then continue end

		local pos = cpos - v:GetPos()
		pos.x = pos.x / radar_scale
		pos.y = pos.y / radar_scale

		local transx, transy = radar_center_x - pos.x, radar_center_y + pos.y
		local dx, dy = transx - radar_center_x, transy - radar_center_y

		transx = radar_center_x + (dx * cos - dy * sin)
		transy = radar_center_y + (dx * sin + dy * cos)

		surface.SetDrawColor(esp_col(v))
		surface.DrawRect(transx - 3, transy - 3, 12, 12)
		surface.SetDrawColor(0,0,0)
		surface.DrawOutlinedRect(transx - 3, transy - 3, 12, 12)

		if gBool("Visuals", "Radar", "Names") then
			if v:IsPlayer() then
				if gBool("Gamemode", "Murder", "Draw Bystander Names") and engine.ActiveGamemode() == "murder" then
					draw.SimpleText(v:GetNWString("bystanderName"), font(), transx+2, transy - 9, esp_col(v), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
				else
					draw.SimpleText(v:Nick(), font(), transx+2, transy - 9, esp_col(v), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
				end
			else
				draw.SimpleText(v:GetClass(), font(), transx+2, transy - 9, esp_col(v), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			end
		end
	end

	render.SetScissorRect(0, 0, 0, 0, false)
end

local function prioritize(v)
	if table.HasValue(ignore_list, v:UniqueID()) then
		table.RemoveByValue(ignore_list, v:UniqueID())
	elseif table.HasValue(priority_list, v:UniqueID()) then
		table.RemoveByValue(priority_list, v:UniqueID())
	else
		table.insert(priority_list, v:UniqueID())
	end

	file.Write(cheatname.."/priorities.txt", util.TableToJSON(priority_list))
	file.Write(cheatname.."/ignore.txt", util.TableToJSON(ignore_list))
end

local function ignore(v)
	if table.HasValue(priority_list, v:UniqueID()) then
		table.RemoveByValue(priority_list, v:UniqueID())
	elseif table.HasValue(ignore_list, v:UniqueID()) then
		table.RemoveByValue(ignore_list, v:UniqueID())
	else
		table.insert(ignore_list, v:UniqueID())
	end

	file.Write(cheatname.."/priorities.txt", util.TableToJSON(priority_list))
	file.Write(cheatname.."/ignore.txt", util.TableToJSON(ignore_list))
end

local function priority(v)
	if table.HasValue(priority_list, v:UniqueID()) then
		return "Rage (Highlight only)"
	elseif table.HasValue(ignore_list, v:UniqueID()) then
		return "Ignore"
	else
		return "Normal"
	end
end

local function playerlist()
	local pos_x, pos_y = ScrW()/1.34, ScrH()/5.5
	local number = 1
	local offset = 14 + gInt("Visuals", "Player List", "Spacing")

	surface.SetDrawColor(MenuCol.r, MenuCol.g, MenuCol.b, 100)
	surface.DrawRect(pos_x, pos_y, 350, 15)

	surface.SetDrawColor(0,0,0)
	surface.DrawOutlinedRect(pos_x, pos_y, 350, 15)
	surface.DrawOutlinedRect(pos_x, pos_y, 30, 15)
	surface.DrawOutlinedRect(pos_x+29, pos_y, 180, 15)

	draw.SimpleText("#", font(), pos_x+5, pos_y, Color(255,255,255), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT)
	draw.SimpleText("Username", font(), pos_x+35, pos_y, Color(255,255,255), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT)
	draw.SimpleText("Priority", font(), pos_x+214, pos_y, Color(255,255,255), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT)

	for k,v in next, player.GetAll() do
		if v == me or not v:IsValid() or player.GetCount() > 30 then continue end
		if MouseInArea(pos_x, pos_y+offset, pos_x+350, pos_y+offset+14) then -- 350 to 209 if u only wanna highlight username part
			if input.IsMouseDown(107) then
				if MouseInArea(pos_x+30, pos_y+offset, pos_x+209, pos_y+offset+14) and not v:IsBot() then
					gui.OpenURL("http://steamcommunity.com/profiles/"..v:SteamID64().."/")
				elseif MouseInArea(pos_x+209, pos_y+offset, pos_x+350, pos_y+offset+14) and not pressed then
					prioritize(v)
					pressed = true
				end
			elseif input.IsMouseDown(108) then
				if MouseInArea(pos_x+30, pos_y+offset, pos_x+209, pos_y+offset+14) and not v:IsBot() then
					SetClipboardText("http://steamcommunity.com/profiles/"..v:SteamID64().."/")
				elseif MouseInArea(pos_x+209, pos_y+offset, pos_x+350, pos_y+offset+14) and not pressed then
					ignore(v)
					pressed = true
				end
			else
				pressed = false
			end

			if gOption("Visuals", "Player List", "Colors") == "Team" then
				if table.HasValue(ignore_list, v:UniqueID()) then
					surface.SetDrawColor(175, 175, 175)
				elseif table.HasValue(priority_list, v:UniqueID()) then
					surface.SetDrawColor(255,0,100)
				else
					surface.SetDrawColor(team.GetColor(v))
				end
			elseif gOption("Visuals", "Player List", "Colors") == "Menu" then
				if table.HasValue(ignore_list, v:UniqueID()) then
					surface.SetDrawColor(175, 175, 175)
				elseif table.HasValue(priority_list, v:UniqueID()) then
					surface.SetDrawColor(255,0,100)
				else
					surface.SetDrawColor(MenuCol)
				end
			else
				surface.SetDrawColor(esp_col(v))
			end
		else
			if gOption("Visuals", "Player List", "Colors") == "Team" then
				if table.HasValue(ignore_list, v:UniqueID()) then
					surface.SetDrawColor(175, 175, 175,100)
				elseif table.HasValue(priority_list, v:UniqueID()) then
					surface.SetDrawColor(255,0,100,100)
				else
					surface.SetDrawColor(team.GetColor(v:Team()).r, team.GetColor(v:Team()).g, team.GetColor(v:Team()).b, 100)
				end
			elseif gOption("Visuals", "Player List", "Colors") == "Menu" then
				if table.HasValue(ignore_list, v:UniqueID()) then
					surface.SetDrawColor(175, 175, 175,100)
				elseif table.HasValue(priority_list, v:UniqueID()) then
					surface.SetDrawColor(255,0,100,100)
				else
					surface.SetDrawColor(MenuCol.r, MenuCol.g, MenuCol.b, 100)
				end
			else
				surface.SetDrawColor(esp_col(v).r, esp_col(v).g, esp_col(v).b, 100)
			end
		end

		surface.DrawRect(pos_x, pos_y+offset, 350, 15)

		surface.SetDrawColor(0,0,0)
		surface.DrawOutlinedRect(pos_x, pos_y+offset, 350, 15)
		surface.DrawOutlinedRect(pos_x, pos_y+offset, 30, 15)
		surface.DrawOutlinedRect(pos_x+29, pos_y+offset, 180, 15)

		draw.SimpleText(number, font(), pos_x+5, pos_y+offset, Color(255,255,255), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT)
		draw.SimpleText(v:Nick(), font(), pos_x+35, pos_y+offset, Color(255,255,255), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT)
		draw.SimpleText(priority(v), font(), pos_x+214, pos_y+offset, Color(255,255,255), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT)

		offset = offset + 14 + gInt("Visuals", "Player List", "Spacing")
		number = number + 1
	end
end

local function chams_col(v, vis)
	if vis then
		if gBool("Visuals", "ESP", "Highlight Aim Target") and v == aimtarget and aimtarget:IsValid() and aimkeycheck() and WeaponShootable() then
			return AimCol.r/255, AimCol.g/255, AimCol.b/255
		else
			return gInt("Settings", "Visible Chams Color", "Red")/255, gInt("Settings", "Visible Chams Color", "Green")/255, gInt("Settings", "Visible Chams Color", "Blue")/255
		end
	else
		return gInt("Settings", "Invisible Chams Color", "Red")/255, gInt("Settings", "Invisible Chams Color", "Green")/255, gInt("Settings", "Invisible Chams Color", "Blue")/255
	end
end

local function chams()
	for k,v in next, ents.GetAll() do

		if v:IsDormant() or not v:IsValid() or not maxdist(v) or v:Health() < 1 or v:IsDormant() or v == me or not filter(v) or not onscreen(v) then continue end

		cam.Start3D()
			if gOption("Visuals", "ESP", "Chams") == "On" then
				render.MaterialOverride(chamsmat)
				render.SetColorModulation(chams_col(v, false))
				v:DrawModel()
			end

			render.SetColorModulation(chams_col(v, true))
			render.MaterialOverride(chamsmat2)
			v:DrawModel(v)
		cam.End3D()
	end
end

local function murder_misc()
	if gBool("Gamemode", "Murder", "Hide End Round Board") then
		if not displayed then
			function GAMEMODE:DisplayEndRoundBoard(data) return end
			displayed = true
		end
	end
	if gBool("Gamemode", "Murder", "Don't become Murderer") then
		if GAMEMODE.RoundStage ~= 1 then
			function GAMEMODE:SetAmMurderer(bool) return false end
		end
	end
	if gBool("Gamemode", "Murder", "Hide Footprints") then
		if not footprints then
			function GAMEMODE:DrawFootprints() return end
			footprints = true
		end
	end
	if gBool("Gamemode", "Murder", "No Black Screens") then
		--function GAMEMODE:RenderDeathOverlay() return end
		if not blackscreen then
			function GAMEMODE:RenderScreenspaceEffects() return end
			function GAMEMODE:PostDrawHUD() return end
			blackscreen = true
		end
	end
	if gOption("Gamemode", "Murder", "Taunt Spam") ~= "Off" and me:Alive() then
		if gOption("Gamemode", "Murder", "Taunt Spam") == "Funny" then
			command("mu_taunt funny")
		end
		if gOption("Gamemode", "Murder", "Taunt Spam") == "Help" then
			command("mu_taunt help")
		end
		if gOption("Gamemode", "Murder", "Taunt Spam") == "Scream" then
			command("mu_taunt scream")
		end
		if gOption("Gamemode", "Murder", "Taunt Spam") == "Morose" then
			command("mu_taunt morose")
		end
		if gOption("Gamemode", "Murder", "Taunt Spam") == "Random" then
			command("mu_taunt "..tauntspam[math.random(#tauntspam)])
		end
	end

	for k,v in next, player.GetAll() do
		if not v:IsValid() or v:Health() < 1 or v:IsDormant() or v == me then continue end

		if GAMEMODE.RoundStage == 1 then
			if v:HasWeapon("weapon_mu_knife") then
				murderer = v:Nick()
				if gOption("Gamemode", "Murder", "Murderer Announcer") ~= "Off" and me:Alive() and v:GetFriendStatus() ~= "friend" and not me:HasWeapon("weapon_mu_knife") and not said then
					if gOption("Gamemode", "Murder", "Murderer Announcer") == "Spam" then
						command("say "..v:GetNWString("bystanderName").." is the murderer this round!")
						said = false
					else
						timer.Create("Delay", 12, 1, function() command("say "..v:GetNWString("bystanderName").." is the murderer this round!") end)
						said = true
					end
				end
				if gBool("Gamemode", "Murder", "Murderer Notification") and me:Alive() and not said_info then
					if v:GetFriendStatus() == "friend" then
						msg(10, "Your friend, "..v:GetNWString("bystanderName").." ("..v:Nick()..") is the murderer this round.")
					else
						msg(10, v:GetNWString("bystanderName").." ("..v:Nick()..") is the murderer this round.")
					end
					said_info = true
				end
			elseif me:HasWeapon("weapon_mu_knife") then
				murderer = me:Nick()
				if not already_bullied then
					if v:HasWeapon("weapon_mu_magnum") then
						bullied = v:GetNWString("bystanderName")
					else
						bullied = player.GetAll()[math.random(#player.GetAll())]:GetNWString("bystanderName")
					end
					already_bullied = true
				end
				if gOption("Gamemode", "Murder", "Murderer Announcer") ~= "Off" and me:Alive() and v:GetFriendStatus() ~= "friend" and not said then
					if gOption("Gamemode", "Murder", "Murderer Announcer") == "Spam" then
						command("say "..bullied.." is the murderer this round!")
						said = false
					else
						timer.Create("Delay", 12, 1, function() command("say "..bullied.." is the murderer this round!") end)
						said = true
					end
				end
				if gBool("Gamemode", "Murder", "Murderer Notification") and me:Alive() and not said_info then 
					msg(10, "You are the murderer this round.")
					said_info = true
				end
			end
		else
			murderer = ""
			bullied = ""
			already_bullied = false
			said = false
			said_info = false
		end
	end
end

local function darkrp_misc()
	if gBool("Gamemode", "DarkRP", "Suicide near Arrest Batons") and me:Alive() and me:Health() > 0 then
		for k,v in next, player.GetAll() do
			if not v:IsValid() or v:Health() < 1 or v:IsDormant() or v == me then continue end
			if gBool("Aimbot", "Other", "Ignore Friends") and v:GetFriendStatus() == "friend" then continue end

			if v:GetPos():Distance(me:GetPos()) < 95 and v:GetActiveWeapon():GetClass() == "arrest_stick" and me:GetPos():Distance(v:GetEyeTrace().HitPos) < 105 then
				command("kill")
			end
		end
	end

	if gInt("Gamemode", "DarkRP", "Prop Transparency") ~= 0 then
		for k, v in next, ents.FindByClass("prop_physics") do
			v:SetRenderMode(RENDERMODE_TRANSCOLOR)
			v:SetKeyValue("renderfx", 0)
			v:SetColor(Color(255, 255, 255, gInt("Gamemode", "DarkRP", "Prop Transparency")))
		end
		if looped_props then
			looped_props = false
		end
	else
		if not looped_props then
			for k, v in next, ents.FindByClass("prop_physics") do
				v:SetColor(Color(255, 255, 255, 255))
			end
			looped_props = true
		end
	end
end

local function CheckChild(pan)
	if pan and pan:IsValid() and not menuopen then
		removewindow = true

		if input.IsKeyDown(17) then
			if pan.GetTitle then
				msg(3, "Removed \""..pan:GetTitle().."\".")
			end
			pan:Remove()
			return
		end

		for k, v in pairs(pan:GetChildren()) do
			if input.IsKeyDown(17) then
				if v.GetTitle then
					msg(3, "Removed \""..v:GetTitle().."\".")
				end
				v:Remove()
				return
			end

			if #v:GetChildren() > 0 then
				CheckChild(v)
			end
		end
	else
		if removewindow then
			removewindow = false
		end
	end
end

local function ttt_misc()
	if gBool("Gamemode", "TTT", "Hide Round Report") then
		if not displayed then
			function CLSCORE:ShowPanel() return end
			displayed = true
		end
	end
	if gBool("Gamemode", "TTT", "Panel Remover") then
		local pan = vgui.GetHoveredPanel()

		CheckChild(pan)
	end
end

--[[local function target()
	if WeaponShootable() then
		if not aimtarget and aimkeycheck() then
			draw.SimpleText("Target: ...", font(), ScrW() / 2, ScrH() / 2 + 50, PrimaryCol, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		elseif not aimtarget and not aimkeycheck() then
			draw.SimpleText("Target: ?", font(), ScrW() / 2, ScrH() / 2 + 50, PrimaryCol, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		else
			if aimtarget:IsValid() then
				if aimtarget:IsPlayer() then
					if gBool("Visuals", "ESP", "Highlight Aim Target") then
						draw.SimpleText("Target: "..aimtarget:Nick(), font(), ScrW() / 2, ScrH() / 2 + 50, AimCol, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
					else
						draw.SimpleText("Target: "..aimtarget:Nick(), font(), ScrW() / 2, ScrH() / 2 + 50, PrimaryCol, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
					end
				else
					if gBool("Visuals", "ESP", "Highlight Aim Target") then
						draw.SimpleText("Target: "..aimtarget:GetClass(), font(), ScrW() / 2, ScrH() / 2 + 50, AimCol, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
					else
						draw.SimpleText("Target: "..aimtarget:GetClass(), font(), ScrW() / 2, ScrH() / 2 + 50, PrimaryCol, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
					end
				end
			end
		end
	else
		draw.SimpleText("Target: ?", font(), ScrW() / 2, ScrH() / 2 + 50, PrimaryCol, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
end]]

local function nophys()
	if gBool("Hack vs Hack", "Anti-Aim", "Enabled") or not me:Alive() or me:Health() < 1 then
		return false
	end

	if me:GetActiveWeapon():IsValid() and me:GetActiveWeapon():GetClass() == "weapon_physgun" then
		return true
	else
		return false
	end
end

local function FixMovement(cmd)
	-- NOT NEEDED -- if me:GetActiveWeapon():GetClass() == "weapon_zm_carry" then return end
	
	local vec = Vector(cmd:GetForwardMove(), cmd:GetSideMove(), 0)
	local vel = math.sqrt(vec.x*vec.x + vec.y*vec.y)
	local mang = vec:Angle()
	local yaw = cmd:GetViewAngles().y - fa.y + mang.y

	if ((cmd:GetViewAngles().p+90)%360) > 180 then
		yaw = 180 - yaw
	end

	yaw = ((yaw + 180)%360)-180
	cmd:SetForwardMove(math.cos(math.rad(yaw)) * vel)
	cmd:SetSideMove(math.sin(math.rad(yaw)) * vel)
end

--[[local function Clamp(val, min, max)
	if val < min then
		return min
	elseif val > max then
		return max
	end
	return val
end]]

local function NormalizeAngle(ang)
	if not nophys() then
		ang.x = math.NormalizeAngle(ang.x)
		ang.p = math.Clamp(ang.p, -89, 89)
	end
end

local function aim_filter(v)
	if not gBool("Aimbot", "Other", "Ignore Players") and gBool("Aimbot", "Other", "Ignore NPCs") then
		return v:IsPlayer()
	elseif not gBool("Aimbot", "Other", "Ignore NPCs") and gBool("Aimbot", "Other", "Ignore Players") then
		return v:IsNPC()
	elseif not gBool("Aimbot", "Other", "Ignore Players") and not gBool("Aimbot", "Other", "Ignore NPCs") then
		return v:IsPlayer() or v:IsNPC()
	else
		return nil
	end
end

local function trigger_filter(v)
	if not gBool("Triggerbot", "Other", "Ignore Players") and gBool("Triggerbot", "Other", "Ignore NPCs") then
		return v:IsPlayer()
	elseif not gBool("Triggerbot", "Other", "Ignore NPCs") and gBool("Triggerbot", "Other", "Ignore Players") then
		return v:IsNPC()
	elseif not gBool("Triggerbot", "Other", "Ignore Players") and not gBool("Triggerbot", "Other", "Ignore NPCs") then
		return v:IsPlayer() or v:IsNPC()
	else
		return nil
	end
end

local function Valid(v)
	if not v or not v:IsValid() or v == me or v:Health() < 1 or v:IsDormant() or not aim_filter(v) then return false end

	if v:IsPlayer() then
		if gBool("Aimbot", "Other", "Ignore Friends") then
			if v:GetFriendStatus() == "friend" or v:SteamID64() == "76561197972182214" then return false end
		end

		if gBool("Aimbot", "Other", "Ignore Bots") then
			if v:IsBot() then return false end
		end

		if gBool("Aimbot", "Other", "Ignore Admins") then
			if v:IsAdmin() then return false end
		end

		if gBool("Aimbot", "Other", "Ignore driving Players") then
			if v:InVehicle() then return false end
		end

		if gBool("Aimbot", "Other", "Ignore noclipping Players") then
			if v:GetMoveType(v) == MOVETYPE_NOCLIP then return false end
		end

		if gBool("Aimbot", "Other", "Ignore Buildmode Players (libbies mode)") then
			--if v:GetColor().a < 255 then return false end
                        if v:GetNWBool( "BuildMode", false ) then return false end
		end

                if gBool("Aimbot", "Other", "Ignore Fast Moving Players (1500+ vel)") then
                if v:GetVelocity():Length() > 1500 then return false end
                end

		if gBool("Aimbot", "Other", "Ignore 100+ HP Players") then
			--if v:GetColor().a < 255 then return false end
                        if v:Health() > 101 then return false end
		end

		if gBool("Aimbot", "Other", "Only Aim At Bots") then
                        if not v:IsBot() then return false end
		end

		if gBool("Aimbot", "Other", "Only Aim At Rage Targets") then
                        if not table.HasValue(priority_list, v:UniqueID()) then return false end
		end

		if v:Team() == TEAM_SPECTATOR or v:Team() == TEAM_CONNECTING then
			return false
		end

		if table.HasValue(ignore_list, v:UniqueID()) then
			return false
		end

		if gBool("Aimbot", "Other", "Ignore Team") then
			if engine.ActiveGamemode() == "terrortown" then
				return true
			elseif engine.ActiveGamemode() == "murder" then
				if not me:HasWeapon("weapon_mu_knife") and v:Nick() ~= murderer and GAMEMODE.RoundStage == 1 then
					return false
				end
			elseif v:Team() == me:Team() and engine.ActiveGamemode() ~= "sandbox" then
				return false
			elseif v:Team() == me:Team() and engine.ActiveGamemode() ~= "darkrp" then
				return false
			end
		end
	end

	if wep:IsValid() then
		local wepname = wep:GetPrintName()
		if string.find(string.lower(wepname),"axe") or string.find(string.lower(wepname),"knife") or string.find(string.lower(wepname),"sword") or string.find(string.lower(wepname),"fist") or string.find(string.lower(wepname),"crowbar") or string.find(string.lower(wepname),"stick") or string.find(string.lower(wepname),"melee") or string.find(string.lower(wepname),"wrench") or string.find(string.lower(wepname),"stun") or string.find(string.lower(wepname),"Baton") then
			if string.find(string.lower(wepname),"fist") then
				if v:GetPos():Distance(me:GetPos()) > 50 then return false end
			else
				if engine.ActiveGamemode() == "murder" or engine.ActiveGamemode() == "terrortown" then
					if v:GetPos():Distance(me:GetPos()) > 65 then return false end
				else
					if v:GetPos():Distance(me:GetPos()) > 80 then return false end
				end
			end
		else
			if wep:Clip1() <= 0 then
				return
			end
		end

		--[[if string.find(string.lower(v:GetActiveWeapon():GetPrintName()),"crowbar") and v then
			return false
		end]] -- idfk how to check if he's attacking


-- aimbotgundistance
		if string.find(string.lower(wepname),"smg") or string.find(string.lower(wepname),"pulse-rifle") or string.find(string.lower(wepname),"9mm pistol") or string.find(string.lower(wep:GetClass()), "m9k_m61_frag") or string.find(string.lower(wep:GetClass()), "m9k_harpoon") then
			if v:GetPos():Distance(me:GetPos()) > (80000 * 5) then return false end
		elseif string.find(string.lower(wepname), "shotgun") or string.find(string.lower(wepname), "m3") or string.find(string.lower(wepname), "1014") or string.find(string.lower(wepname), "minigun") or string.find(string.lower(wepname), "winchester 1897") or string.find(string.lower(wepname), "winchester 87") or string.find(string.lower(wepname), "ithaca") or string.find(string.lower(wepname), "mossberg") or string.find(string.lower(wepname), "remington 870") or string.find(string.lower(wepname), "spas") or string.find(string.lower(wepname), "benelli") or string.find(string.lower(wepname), "browning") then
			if v:GetPos():Distance(me:GetPos()) > (80000 * 5) then return false end
		elseif string.find(string.lower(wepname), "crossbow") or string.find(string.lower(wep:GetClass()), "m9k_rpg7") or string.find(string.lower(me:GetActiveWeapon():GetClass()), "m9k_m202") or string.find(string.lower(wep:GetClass()), "m9k_m79gl") or string.find(string.lower(wep:GetClass()), "m9k_ex41") or string.find(string.lower(wep:GetClass()), "m9k_matador") or string.find(string.lower(wep:GetClass()), "m9k_milkormgl") then
			if v:GetPos():Distance(me:GetPos()) > (80000 * 5) then return false end
		else
			if v:GetPos():Distance(me:GetPos()) > (80000 * 5) then return false end
		end
	end






local function FASAutowall(wep, startPos, aimPos, ply)
	if not gBool("Aimbot", "Aimbot", "M9K FAS Auto Wall") then return end
    local traces = {}
    local traceResults = {}
    local dir = (aimPos - startPos):GetNormalized()
    traces[1] = {start = startPos, filter = me, mask = trace_normal, endpos = aimPos,}
    traceResults[1] = util.TraceLine(traces[1])
    if(NoPenetration[traceResults[1].MatType]) then return false end
    if( - dir:DotProduct(traceResults[1].HitNormal) <= .26) then return false end
    traces[2] = {start = traceResults[1].HitPos, endpos = traceResults[1].HitPos + dir * wep.PenStr * (PenMod[traceResults[1].MatType] or 1) * wep.PenMod, filter = me, mask = trace_walls,}
    traceResults[2] = util.TraceLine(traces[2])
    traces[3] = {start = traceResults[2].HitPos, endpos = traceResults[2].HitPos + dir * .1, filter = me, mask = trace_normal,}
    traceResults [3] = util.TraceLine(traces[3])
    traces[4] = {start = traceResults[2].HitPos, endpos = aimPos, filter = me, mask = MASK_SHOT,}
    traceResults[4] = util.TraceLine(traces[4])
    if(traceResults[4].Entity ~= ply) then return false end
    return(not traceResults[3].Hit)
end

local function M9KAutowall(wep)
	if not gBool("Aimbot", "Aimbot", "M9K FAS Auto Wall") then return end
	local wep = me:GetActiveWeapon()
    local trace = {
        endpos = aimPos, 
        start = me:EyePos(), 
        mask = MASK_SHOT, 
        filter = me, 
    }
    return wep:BulletPenetrate(10, nil, util.TraceLine(trace), DamageInfo())
end







	local tr = { start = me:EyePos(), endpos = GetPos(v), mask = MASK_SHOT, filter = {me, v} }
	if util.TraceLine(tr).Fraction == 1 then
                --print("HITSCAN")
		return true
	elseif wep and wep:IsValid() and wep.PenStr and gBool("Aimbot", "Aimbot", "M9K FAS Auto Wall") then
                --print("fas autowall")
		--return FASAutowall(wep, tr.start, tr.endpos, v)
	elseif wep and wep:IsValid() and wep.BulletPenetrate and gBool("Aimbot", "Aimbot", "M9K FAS Auto Wall") then
                --print("m9k autowall")
		return M9KAutowall(wep, tr.start, tr.endpos, v)
	end
	return false
end

local function trigger_Valid(v)
	if not v or not v:IsValid() or v == me or v:Health() < 1 or v:IsDormant() or not aim_filter(v) then return false end

	if v:IsPlayer() then
		if gBool("Triggerbot", "Other", "Ignore Friends") then
			if v:GetFriendStatus() == "friend" or v:SteamID64() == "76561197972182214" then return false end
		end

		if gBool("Triggerbot", "Other", "Ignore Bots") then
			if v:IsBot() then return false end
		end

		if gBool("Triggerbot", "Other", "Ignore Admins") then
			if v:IsAdmin() then return false end
		end

		if gBool("Triggerbot", "Other", "Ignore driving Players") then
			if v:InVehicle() then return false end
		end

		if gBool("Triggerbot", "Other", "Ignore noclipping Players") then
			if v:GetMoveType(v) == MOVETYPE_NOCLIP then return false end
		end

		if gBool("Triggerbot", "Other", "Ignore Buildmode Players (libbies mode)") then
			if v:GetNWString("BuildMode") then return false end
		end

		if v:Team() == TEAM_SPECTATOR or v:Team() == TEAM_CONNECTING then
			return false
		end

		if table.HasValue(ignore_list, v:UniqueID()) then
			return false
		end

		if gBool("Aimbot", "Other", "Ignore Team") then
			if engine.ActiveGamemode() == "terrortown" then
				return true
			elseif engine.ActiveGamemode() == "murder" then
				if not me:HasWeapon("weapon_mu_knife") and v:Nick() ~= murderer and GAMEMODE.RoundStage == 1 then
					return false
				end
			elseif v:Team() == me:Team() and engine.ActiveGamemode() ~= "sandbox" then
				return false
			end
		end
	end

	if wep:IsValid() then
		local wepname = wep:GetPrintName()
		if string.find(string.lower(wepname),"axe") or string.find(string.lower(wepname),"knife") or string.find(string.lower(wepname),"sword") or string.find(string.lower(wepname),"fist") or string.find(string.lower(wepname),"crowbar") or string.find(string.lower(wepname),"stick") or string.find(string.lower(wepname),"melee") or string.find(string.lower(wepname),"wrench") or string.find(string.lower(wepname),"stun") or string.find(string.lower(wepname),"Baton") then
			if string.find(string.lower(wepname),"fist") then
				if v:GetPos():Distance(me:GetPos()) > (13 * 5) then return false end
			else
				if engine.ActiveGamemode() == "murder" or engine.ActiveGamemode() == "terrortown" then
					if v:GetPos():Distance(me:GetPos()) > (11 * 5) then return false end
				else
					if v:GetPos():Distance(me:GetPos()) > (18 * 5) then return false end
				end
			end
		else
			if wep:Clip1() <= 0 then
				return
			end
		end

		if string.find(string.lower(wepname),"smg") or string.find(string.lower(wepname),"pulse-rifle") or string.find(string.lower(wepname),"9mm pistol") then
			if v:GetPos():Distance(me:GetPos()) > (80000 * 5) then return false end
		elseif string.find(string.lower(wepname), "shotgun") or string.find(string.lower(wepname), "m3") or string.find(string.lower(wepname), "1014") or string.find(string.lower(wepname), "minigun") or string.find(string.lower(wepname), "winchester 1897") or string.find(string.lower(wepname), "winchester 87") or string.find(string.lower(wepname), "ithaca") or string.find(string.lower(wepname), "mossberg") or string.find(string.lower(wepname), "remington 870") or string.find(string.lower(wepname), "spas") or string.find(string.lower(wepname), "benelli") or string.find(string.lower(wepname), "browning") then
			if v:GetPos():Distance(me:GetPos()) > (80000 * 5) then return false end
		else
			if v:GetPos():Distance(me:GetPos()) > (80000 * 5) then return false end
		end
	end

	local tr = { start = me:EyePos(), endpos = GetPos(v), mask = MASK_SHOT, filter = {me, v} }
	if util.TraceLine(tr).Fraction == 1 then
		return true
	--[[elseifwep and wep:IsValid() and wep.PenStr then
		return fasAutowall(wep, tr.start, tr.endpos, v)
	elseif wep and wep:IsValid() and wep.BulletPenetrate then
		return m9kAutowall(wep, tr.start, tr.endpos, v)]]
	end
	return false
end

local function aa_Valid(v)
	if not v or not v:IsValid() or v == me or v:Health() < 1 or v:IsDormant() or not aim_filter(v) then return false end

	if v:IsPlayer() then
		if gBool("Aimbot", "Other", "Ignore Friends") then
			if v:GetFriendStatus() == "friend" or v:SteamID64() == "76561197972182214" then return false end
		end

		if gBool("Aimbot", "Other", "Ignore Bots") then
			if v:IsBot() then return false end
		end

		if gBool("Aimbot", "Other", "Ignore Admins") then
			if v:IsAdmin() then return false end
		end

		if gBool("Aimbot", "Other", "Ignore driving Players") then
			if v:InVehicle() then return false end
		end

		if gBool("Aimbot", "Other", "Ignore noclipping Players") then
			if v:GetMoveType(v) == MOVETYPE_NOCLIP then return false end
		end

		if v:Team() == TEAM_SPECTATOR or v:Team() == TEAM_CONNECTING then
			return false
		end

		if table.HasValue(ignore_list, v:UniqueID()) then
			return false
		end

		if gBool("Aimbot", "Other", "Ignore Team") then
			if engine.ActiveGamemode() == "terrortown" then
				return true
			elseif engine.ActiveGamemode() == "murder" then
				if not me:HasWeapon("weapon_mu_knife") and v:Nick() ~= murderer and GAMEMODE.RoundStage == 1 then
					return false
				end
			elseif v:Team() == me:Team() and engine.ActiveGamemode() ~= "sandbox" then
				return false
			elseif v:Team() == me:Team() and engine.ActiveGamemode() ~= "darkrp" then
				return false
			end
		end
	end

	return true
end

local function check_alive(v)
	if v:IsValid() then
		if v:IsPlayer() then
			return v:Alive()
		else
			return v:Health() > 0
		end
	end
end

function CrosshairAim()
	dists = {}
		local x, y = ScrW(), ScrH()
		local AngA, AngB = 0
		for k, v in next, ents.GetAll() do
			if(!Valid(v)) then continue end
			
			local EyePos = v:EyePos():ToScreen()
			dists[#dists + 1] = {math.Dist(x / 2, y / 2, EyePos.x, EyePos.y), v}
		end
		table.sort(dists, function(a, b)
			return(a[1] < b[1])
		end)
	aimtarget = dists[1] && dists[1][2] || nil
end



local function gettarget()
	if gOption("Aimbot", "Other", "Priority") == "Nearest" then
		dists = {}
		for k,v in next, ents.GetAll() do
			if not Valid(v) then continue end
			dists[#dists + 1] = { v:GetPos():Distance(me:GetPos()), v }
		end
		table.sort(dists, function(a, b)
			return(a[1] < b[1])
		end)
		aimtarget = dists[1] and dists[1][2] or nil
	elseif gOption("Aimbot", "Other", "Priority") == "Lowest Health" then
		dists = {}
		for k,v in next, ents.GetAll() do
			if not Valid(v) then continue end
			dists[#dists + 1] = { v:Health(), v }
		end
		table.sort(dists, function(a, b)
			return(a[1] < b[1])
		end)
		aimtarget = dists[1] and dists[1][2] or nil
	else
		dists = {}
		for k,v in next, ents.GetAll() do
			if not Valid(v) then continue end
			--dists[#dists + 1] = { v:GetPos():Distance(me:GetEyeTrace().HitPos), v }
			aimtarget = dists[1] and dists[1][2] or nil
			dists[#dists + 1] = { math.Dist(ScrW() / 2, ScrH() / 2, v:EyePos():ToScreen().x, v:EyePos():ToScreen().y), v }
		end
		table.sort(dists, function(a, b)
			return(a[1] < b[1])
		end)
		aimtarget = dists[1] and dists[1][2] or nil
	end
end


local cones = {}

local nullvec = Vector() * - 1


GAMEMODE["EntityFireBullets"] = function(self, p, data)
	aimignore = aimtarget
	local w = pm.GetActiveWeapon(me)
	local Spread = data.Spread * - 1
	if(not w or not em.IsValid(w) or cones[em.GetClass(w)] == Spread or Spread == nullvec) then return end
	cones[em.GetClass(w)] = Spread
end



local function PredictSpread(cmd, ang)
	local w = pm.GetActiveWeapon(me)
	if(not w or not em.IsValid(w) or not cones[em.GetClass(w)] or not gBool("Aimbot", "Aimbot", "Predict Spread")) then return am.Forward(ang) end
	return (dickwrap.Predict(cmd, am.Forward(ang), cones[em.GetClass(w)]))
end






local function fakelag(cmd, choke, send)
	if gBool("Misc", "Fake Lag", "Disable on Attack") and me:KeyDown(IN_ATTACK) then
		return
	end

	if cmd:CommandNumber() == 0 then
		return true
	end

	if not Choke then
		choke = gInt("Misc", "Fake Lag", "Density") + 0.7
	end

	if not Send then
		send = 0
	end

	faketick = faketick + 1

	if faketick > (choke + send) then
		faketick = 0
	end

	if not (send >= faketick) then
		memesendpacket = false
	end

	flsend = send

	return true
end



local function fakelagcounterdynamic(cmd, choke, send)
	if gBool("Misc", "Fake Lag", "Disable on Attack") and me:KeyDown(IN_ATTACK) then
		return
	end

	if cmd:CommandNumber() == 0 then
		return true
	end

	if not Choke then
                vels = ( me:GetVelocity():Length() / 200 ) 
		choke = vels
                print("fakelag counter-dynamic value: " .. vels .. " velocity: " .. me:GetVelocity():Length() .. "")
                fakelagcham_check = fakelagcham_check + 1
	end

	if not Send then
		send = 0
	end

	faketick = faketick + 1

	if faketick > (choke + send) then
		faketick = 0
	end

	if not (send >= faketick) then
		memesendpacket = false
	end

	flsend = send

	return true
end

local function fakelagdynamic(cmd, choke, send)
	if gBool("Misc", "Fake Lag", "Disable on Attack") and me:KeyDown(IN_ATTACK) then
		return
	end

	if cmd:CommandNumber() == 0 then
		return true
	end

	if not Choke then
                velocities = me:GetVelocity():Length()
                if velocities > 0 and velocities < 250 then
                ourdynamic = 14
                fakelagcham_check = fakelagcham_check + 1
                end 
                if velocities > 250 and velocities < 400 then
                ourdynamic = 13                fakelagcham_check = fakelagcham_check + 1
                end 
                if velocities > 400 and velocities < 600 then
                ourdynamic = 12
                fakelagcham_check = fakelagcham_check + 1
                end 
                if velocities > 600 and velocities < 800 then
                ourdynamic = 11
                fakelagcham_check = fakelagcham_check + 1
                end 
                if velocities > 800 and velocities < 1000 then
                ourdynamic = 10
                fakelagcham_check = fakelagcham_check + 1
                end 
                if velocities > 1000 and velocities < 1200 then
                ourdynamic = 9
                fakelagcham_check = fakelagcham_check + 1
                end 
                if velocities > 1200 and velocities < 1400 then
                ourdynamic = 8
                fakelagcham_check = fakelagcham_check + 1
                end 
                if velocities > 1400 and velocities < 1600 then
                ourdynamic = 7
                fakelagcham_check = fakelagcham_check + 1
                end 
                if velocities > 1600 and velocities < 1800 then
                ourdynamic = 6
                fakelagcham_check = fakelagcham_check + 1
                end 
                if velocities > 1800 and velocities < 2000 then
                ourdynamic = 5
                fakelagcham_check = fakelagcham_check + 1
                end 
                if velocities > 2000 and velocities < 3000 then
                ourdynamic = 4
                fakelagcham_check = fakelagcham_check + 1
                end 
                if velocities > 3000 then
                ourdynamic = 2
                fakelagcham_check = fakelagcham_check + 1
                end 
		choke = ourdynamic
                print("fakelag dynamic value: " .. ourdynamic .. " velocity: " .. me:GetVelocity():Length() .. "")
	end

	if not Send then
		send = 0
	end

	faketick = faketick + 1

	if faketick > (choke + send) then
		faketick = 0
	end

	if not (send >= faketick) then
		memesendpacket = false
	end

	flsend = send

	return true
end












local function prediction(aimtarget)
	if gBool("Aimbot", "Misc", "Projectile Prediction") then
		if string.find(string.lower(wep:GetPrintName()), "crossbow") then
			if aimtarget:GetPos():Distance(me:GetPos()) <= 1100 then
				return (GetPos(aimtarget) + aimtarget:GetVelocity() * ((aimtarget:GetPos():Distance(me:GetPos())/1600)+me:Ping()/950) + Vector(0,0,aimtarget:GetPos():Distance(me:GetPos())/110) - me:GetVelocity()/50) 
			else
				return (GetPos(aimtarget) + aimtarget:GetVelocity() * ((aimtarget:GetPos():Distance(me:GetPos())/3215)+me:Ping()/950) + Vector(0,0,aimtarget:GetPos():Distance(me:GetPos())/110) - me:GetVelocity()/50) 
			end
		elseif string.find(string.lower(wep:GetClass()), "m9k_rpg7") or string.find(string.lower(me:GetActiveWeapon():GetClass()), "m9k_m202") then
			if aimtarget:GetPos():Distance(me:GetPos()) <= 2600 then
				return (GetPos(aimtarget) + aimtarget:GetVelocity() * ((aimtarget:GetPos():Distance(me:GetPos())/4500)+me:Ping()/950) - Vector(0,0,25) - me:GetVelocity()/50) 
			elseif aimtarget:GetPos():Distance(me:GetPos()) <= 4000 then
				return (GetPos(aimtarget) + aimtarget:GetVelocity() * ((aimtarget:GetPos():Distance(me:GetPos())/4500)+me:Ping()/950) + Vector(0,0,aimtarget:GetPos():Distance(me:GetPos())/110) - me:GetVelocity()/50) 
			else
				return (GetPos(aimtarget) + aimtarget:GetVelocity() * ((aimtarget:GetPos():Distance(me:GetPos())/4500)+me:Ping()/950) + Vector(0,0,aimtarget:GetPos():Distance(me:GetPos())/90) - me:GetVelocity()/50) 
			end
		elseif string.find(string.lower(wep:GetClass()), "m9k_ex41") or string.find(string.lower(wep:GetClass()), "m9k_m79gl") then
			if aimtarget:GetPos():Distance(me:GetPos()) <= 1100 then
				return (GetPos(aimtarget) + aimtarget:GetVelocity() * ((aimtarget:GetPos():Distance(me:GetPos())/2550)+me:Ping()/950) - Vector(0,0,25) - me:GetVelocity()/50) 
			elseif aimtarget:GetPos():Distance(me:GetPos()) <= 4000 then
				return (GetPos(aimtarget) + aimtarget:GetVelocity() * ((aimtarget:GetPos():Distance(me:GetPos())/2130)+me:Ping()/950) + Vector(0,0,aimtarget:GetPos():Distance(me:GetPos())/35) - me:GetVelocity()/50) 
			elseif aimtarget:GetPos():Distance(me:GetPos()) <= 7000 then
				return (GetPos(aimtarget) + aimtarget:GetVelocity() * ((aimtarget:GetPos():Distance(me:GetPos())/2130)+me:Ping()/950) + Vector(0,0,aimtarget:GetPos():Distance(me:GetPos())/13) - me:GetVelocity()/50) 
			else
				return (GetPos(aimtarget) + aimtarget:GetVelocity() * ((aimtarget:GetPos():Distance(me:GetPos())/2670)+me:Ping()/950) + Vector(0,0,aimtarget:GetPos():Distance(me:GetPos())/6) - me:GetVelocity()/50) 
			end
		elseif string.find(string.lower(wep:GetClass()), "m9k_matador") then
			if aimtarget:GetPos():Distance(me:GetPos()) <= 2600 then
				return (GetPos(aimtarget) + aimtarget:GetVelocity() * ((aimtarget:GetPos():Distance(me:GetPos())/6500)+me:Ping()/950) - Vector(0,0,25) - me:GetVelocity()/50) 
			elseif aimtarget:GetPos():Distance(me:GetPos()) <= 4000 then
				return (GetPos(aimtarget) + aimtarget:GetVelocity() * ((aimtarget:GetPos():Distance(me:GetPos())/6500)+me:Ping()/950) + Vector(0,0,aimtarget:GetPos():Distance(me:GetPos())/110) - me:GetVelocity()/50) 
			else
				return (GetPos(aimtarget) + aimtarget:GetVelocity() * ((aimtarget:GetPos():Distance(me:GetPos())/6500)+me:Ping()/950) + Vector(0,0,aimtarget:GetPos():Distance(me:GetPos())/90) - me:GetVelocity()/50) 
			end
		elseif string.find(string.lower(wep:GetClass()), "m9k_milkormgl") then
			if aimtarget:GetPos():Distance(me:GetPos()) <= 1100 then
				return (GetPos(aimtarget) + aimtarget:GetVelocity() * ((aimtarget:GetPos():Distance(me:GetPos())/2500)+me:Ping()/950) - Vector(0,0,25) - me:GetVelocity()/50) 
			elseif aimtarget:GetPos():Distance(me:GetPos()) <= 4000 then
				return (GetPos(aimtarget) + aimtarget:GetVelocity() * ((aimtarget:GetPos():Distance(me:GetPos())/2000)+me:Ping()/950) + Vector(0,0,aimtarget:GetPos():Distance(me:GetPos())/43) - me:GetVelocity()/50) 
			elseif aimtarget:GetPos():Distance(me:GetPos()) <= 7000 then
				return (GetPos(aimtarget) + aimtarget:GetVelocity() * ((aimtarget:GetPos():Distance(me:GetPos())/2460)+me:Ping()/950) + Vector(0,0,aimtarget:GetPos():Distance(me:GetPos())/38) - me:GetVelocity()/50) 
			else
				return (GetPos(aimtarget) + aimtarget:GetVelocity() * ((aimtarget:GetPos():Distance(me:GetPos())/2580)+me:Ping()/950) + Vector(0,0,aimtarget:GetPos():Distance(me:GetPos())/17.5) - me:GetVelocity()/50) 
			end
		elseif string.find(string.lower(wep:GetClass()), "m9k_m61_frag") then
			return (GetPos(aimtarget) + aimtarget:GetVelocity() * ((aimtarget:GetPos():Distance(me:GetPos())/650)+me:Ping()/950) - Vector(0,0,225) + Vector(0,0,aimtarget:GetPos():Distance(me:GetPos())/4) - me:GetVelocity()/50) 
		elseif string.find(string.lower(wep:GetClass()), "m9k_harpoon") then
			if aimtarget:GetPos():Distance(me:GetPos()) <= 1200 then
				return (GetPos(aimtarget) + aimtarget:GetVelocity() * ((aimtarget:GetPos():Distance(me:GetPos())/2300)+me:Ping()/950) + Vector(0,0,aimtarget:GetPos():Distance(me:GetPos())/20) - me:GetVelocity()/50) 
			elseif aimtarget:GetPos():Distance(me:GetPos()) <= 1750 then
				return (GetPos(aimtarget) + aimtarget:GetVelocity() * ((aimtarget:GetPos():Distance(me:GetPos())/2000)+me:Ping()/950) + Vector(0,0,aimtarget:GetPos():Distance(me:GetPos())/8) - me:GetVelocity()/50) 
			elseif aimtarget:GetPos():Distance(me:GetPos()) <= 2000 then
				return (GetPos(aimtarget) + aimtarget:GetVelocity() * ((aimtarget:GetPos():Distance(me:GetPos())/1500)+me:Ping()/950) + Vector(0,0,aimtarget:GetPos():Distance(me:GetPos())/5) - me:GetVelocity()/50) 
			else
				return (GetPos(aimtarget) + aimtarget:GetVelocity() * ((aimtarget:GetPos():Distance(me:GetPos())/900)+me:Ping()/950) + Vector(0,0,aimtarget:GetPos():Distance(me:GetPos())/3) - me:GetVelocity()/50) 
			end
		else
			if gOption("Aimbot", "Misc", "Fake Lag Prediction") ~= "Off" then
				if gOption("Aimbot", "Misc", "Fake Lag Prediction") == "Rage Targets Only" then
					if table.HasValue(priority_list, aimtarget:UniqueID()) then
						return (GetPos(aimtarget) + aimtarget:GetVelocity() / 200 - me:GetVelocity()/50) 
					else
						return (GetPos(aimtarget) - aimtarget:GetVelocity() / 170.5 - me:GetVelocity()/50) 
					end
				else
					return (GetPos(aimtarget) + aimtarget:GetVelocity() / 200 - me:GetVelocity()/50) 
				end
			else
				return (GetPos(aimtarget) - aimtarget:GetVelocity() / 170.5 - me:GetVelocity()/50) 
			end
		end
	else
		if gOption("Aimbot", "Misc", "Fake Lag Prediction") ~= "Off" then
			if gOption("Aimbot", "Misc", "Fake Lag Prediction") == "Rage Targets Only" then
				if table.HasValue(priority_list, aimtarget:UniqueID()) then
					return (GetPos(aimtarget) + aimtarget:GetVelocity() / 200 - me:GetVelocity()/50) 
				else
					return (GetPos(aimtarget) - aimtarget:GetVelocity() / 170.5 - me:GetVelocity()/50) 
				end
			else
				return (GetPos(aimtarget) + aimtarget:GetVelocity() / 200 - me:GetVelocity()/50) 
			end
		else
			return (GetPos(aimtarget) - aimtarget:GetVelocity() / 170.5 - me:GetVelocity()/50) 
		end
	end
end

local function prediction2(aimtarget)
-- AT LEAST YOU DON'T MISS WITH REVOLVER AS SHOWN IN THE IDIOTBOX REVIEW BY CRAVE
			--return (GetPos(aimtarget) - aimtarget:GetVelocity() / 1 - me:GetVelocity()/1) - me:EyePos()
			return (GetPos(aimtarget) - aimtarget:GetVelocity() / 170.5 - me:GetVelocity()/50) 
end

--[[
-- probably sucks but give it a try. at least would you?
local function PredictPos(pos)
	local myvel = LocalPlayer():GetVelocity()
		local pos = pos - (myvel * engine.TickInterval())
	return pos
end
]]--



local function aimbot(cmd)


--print("okay? the function is being called")




	if gBool("Aimbot", "Aimbot", "Silent Aimbot") and gInt("Visuals", "Other", "Thirdperson") == 0 then
		if cmd:CommandNumber() == 0 then return end
	end

	gettarget()
	aa = false

	if gBool("Aimbot", "Aimbot", "Auto Stop") and aimtarget and check_alive(aimtarget) and aimtarget:IsValid() and aimkeycheck() and WeaponShootable() then
		cmd:SetForwardMove(0)
		cmd:SetSideMove(0)
	end

	if gBool("Aimbot", "Aimbot", "Auto Crouch") and aimtarget and check_alive(aimtarget) and aimtarget:IsValid() and aimkeycheck() and WeaponShootable() and not cmd:KeyDown(IN_DUCK) then
		cmd:SetButtons(cmd:GetButtons() + IN_DUCK)
	end

	if gBool("Aimbot", "Aimbot", "Auto Fire Secondary") and aimtarget and check_alive(aimtarget) and aimtarget:IsValid() and aimkeycheck() and WeaponShootable() and not cmd:KeyDown(IN_ATTACK2) then
		cmd:SetButtons(cmd:GetButtons() + IN_ATTACK2)
	end

	--if aimtarget and check_alive(aimtarget) and aimtarget:IsValid() and aimkeycheck() and WeaponShootable() and WeaponCanFire() then
	if aimtarget and check_alive(aimtarget) and aimtarget:IsValid() and aimkeycheck() and WeaponCanFire() then
-- Incase
                --[[
                local pos = prediction(aimtarget) - em.EyePos(me) 
                local pos = GetPos(aimtarget) - em.EyePos(me)
                ]]--

                -- Cannot use prediction(aimtarget) for now. must use GetPos(aimtarget) until there is a fix
                --local pos = GetPos(aimtarget) - em.EyePos(me) 
                --local pos = (GetPos(aimtarget) - aimtarget:GetVelocity() / 170.5 - em:GetVelocity()/50) - em.EyePos(me)





                -- Get mother fucking target position + include some prediction
                --local pos = prediction2(aimtarget) - em.EyePos(me)
                local pos = prediction(aimtarget) - em.EyePos(me)
		-- predict spread when aimbotting!
		local ang = vm.Angle(PredictSpread(cmd, vm.Angle(pos)))

		if gInt("Aimbot", "Aimbot", "Aimbot FOV") ~= 0 and gOption("Aimbot", "Other", "Priority") == "FOV" then
			for k,v in next, ents.GetAll() do
				if not Valid(v) then continue end

				local CalcX = ang.x - fa.x
				local CalcY = ang.y - fa.y

				if CalcY < 0 then CalcY = CalcY * -1 end	
				if CalcX < 0 then CalcX = CalcX * -1 end
				if CalcY > 360 then CalcY = CalcY - 360 end
				if CalcX > 360 then CalcX = CalcX - 360 end
				if CalcY > 180 then CalcY = 360 - CalcY end
				if CalcX > 180 then CalcX = 360 - CalcX end

				if CalcX <= gInt("Aimbot","Aimbot","Aimbot FOV") and CalcY <= gInt("Aimbot","Aimbot","Aimbot FOV") then
					if gBool("Aimbot", "Aimbot", "Auto Fire") and not gBool("Hack vs Hack", "Anti-Aim", "Enabled") and not gBool("Hack vs Hack", "Anti-Aim Resolver", "Enabled") and not gBool("Misc", "Fake Lag", "Enabled") then
						if me:IsSprinting() then
							command("-speed")
						end
						if WeaponShootable() and not string.find(string.lower(wep:GetPrintName()),"knife") and not string.find(string.lower(wep:GetPrintName()),"sword") and not string.find(string.lower(wep:GetPrintName()),"fist") and not string.find(string.lower(wep:GetPrintName()),"crowbar") then
							memesendpacket = false
						end
					end

					if gBool("Aimbot", "Aimbot", "Auto Fire") then
                                                if IsValid(aimtarget) then
                                                beforehealth = aimtarget:Health()
                                                end
						cmd:SetButtons(IN_ATTACK)
                                                timer.Create("didihit", ( me:Ping()/ 950 ), 1, function()
	                                        if gBool("Aimbot", "Aimbot", "Missed Shot Info") then
                                                if IsValid(aimtarget) then
                                                if aimtarget:Health() == beforehealth then
                                                chat.AddText( Color(255, 152, 255), "Missed! Bad hitreg or aimbot missed (User had health " .. beforehealth .. " his health: " .. aimtarget:Health() .. ")")
                                                end
                                                end
                                                end
                                                end)
					end

					if gBool("Aimbot", "Aimbot", "Silent Aimbot") then
						FixMovement(cmd)
					else
						fa = ang
					end


					NormalizeAngle(ang)
					cmd:SetViewAngles(ang)





                                        
				else
					return
				end
			end
		else

			NormalizeAngle(ang)
			cmd:SetViewAngles(ang)

			if gBool("Aimbot", "Aimbot", "Auto Fire") and not gBool("Hack vs Hack", "Anti-Aim", "Enabled") and not gBool("Hack vs Hack", "Anti-Aim Resolver", "Enabled") and not gBool("Misc", "Fake Lag", "Enabled") then
				if me:IsSprinting() then
					command("-speed")
				end
				if WeaponShootable() and not string.find(string.lower(wep:GetPrintName()),"knife") and not string.find(string.lower(wep:GetPrintName()),"sword") and not string.find(string.lower(wep:GetPrintName()),"fist") and not string.find(string.lower(wep:GetPrintName()),"crowbar") then
					memesendpacket = false
				end
			end

			if gBool("Aimbot", "Aimbot", "Auto Fire") then
                                                if IsValid(aimtarget) then
                                                beforehealth = aimtarget:Health()
                                                end
				                cmd:SetButtons(cmd:GetButtons() + IN_ATTACK)
                                                timer.Create("didihit", ( me:Ping()/ 950 ), 1, function()
	                                        if gBool("Aimbot", "Aimbot", "Missed Shot Info") then
                                                if IsValid(aimtarget) then
                                                if aimtarget:Health() == beforehealth then
                                                chat.AddText( Color(255, 152, 255), "Missed! Bad hitreg or aimbot missed (User had health " .. beforehealth .. " his health: " .. aimtarget:Health() .. ")")
                                                end
                                                end
                                                end
                                                end)
			end

			if gBool("Aimbot", "Aimbot", "Silent Aimbot") then
				FixMovement(cmd)
			else
				fa = ang
			end
		end
	end
	aa = true
end




local function crosshair()
	local width, height = ScrW() / 2, ScrH() / 2
	
	if hitmarker then
		surface.SetDrawColor(255,255,255)
	else
		surface.SetDrawColor(0,0,0)
	end

	surface.DrawLine(width - 10, height - 10, width + 10, height + 10)
	surface.DrawLine(width + 10, height - 10, width - 10, height + 10)

	if aimkeycheck() and WeaponShootable() then
		surface.SetDrawColor(AimCol)
	elseif triggerkeycheck() and WeaponShootable() then
		surface.SetDrawColor(MenuCol)
	else
		surface.SetDrawColor(PrimaryCol)
	end

	surface.DrawLine(width - 5, height - 5, width + 5, height + 5)
	surface.DrawLine(width + 5, height - 5, width - 5, height + 5)
end

local function triggerfilter(hitbox)
	if gOption("Triggerbot", "Other", "Trigger Position") == "Head only" then
		return hitbox == 0
	elseif gOption("Triggerbot", "Other", "Trigger Position") == "Body only" then
		return hitbox == 16
	else
		return hitbox ~= nil
	end
end

local function triggerbot(cmd)
	td = {start = me:GetShootPos(), endpos = me:GetShootPos() + me:EyeAngles():Forward() * 65535, filter = me, mask = MASK_SHOT, mask}
	tr = util.TraceLine(td)
	v = tr.Entity

	local trace = me:GetEyeTraceNoCursor()
	local hitbox = trace.HitBox

	if not trigger_Valid(v) or not trigger_filter(v) or not triggerfilter(hitbox) or (aimkeycheck() and gBool("Aimbot", "Aimbot", "Auto Fire")) then return end

	--[[if engine.ActiveGamemode() == "terrortown" then
		if GetRoundState() == ROUND_ACTIVE then
			if wep:Clip1() == 0 or not wep:IsValid() then return end
		end
	else
		if wep:Clip1() == 0 or not wep:IsValid() then return end
	end]]

	if gBool("Triggerbot", "Triggerbot", "Auto Stop") and v and check_alive(v) and v:IsValid() and triggerkeycheck() and WeaponShootable() then
		cmd:SetForwardMove(0)
		cmd:SetSideMove(0)
	end

	if gBool("Triggerbot", "Triggerbot", "Auto Crouch") and v and check_alive(v) and v:IsValid() and triggerkeycheck() and WeaponShootable() and not cmd:KeyDown(IN_DUCK) then
		cmd:SetButtons(cmd:GetButtons() + IN_DUCK)
	end

	if gBool("Triggerbot", "Triggerbot", "Auto Fire Secondary") and v and check_alive(v) and v:IsValid() and triggerkeycheck() and WeaponShootable() and not cmd:KeyDown(IN_ATTACK2) then
		cmd:SetButtons(cmd:GetButtons() + IN_ATTACK2)
	end

	if v and check_alive(v) and v:IsValid() and triggerkeycheck() and WeaponShootable() and WeaponCanFire() then
		triggerbot_active = true

		if toggler == 0 then
			cmd:SetButtons(cmd:GetButtons() + IN_ATTACK)
			toggler = 1
		else
			cmd:SetButtons(cmd:GetButtons() + IN_ATTACK)
			toggler = 0
		end
	else
		triggerbot_active = false
	end
end

local function GetClosest()
	local ddists = {}
	local closest

	for k,v in next, player.GetAll() do
		if not aa_Valid(v) then continue end

		ddists[#ddists + 1] = { v:GetPos():Distance(me:GetPos()), v }
	end

	table.sort(ddists, function(a, b)
		return a[1] < b[1]
	end)

	closest = ddists[1] and ddists[1][2] or nil

	if not closest then
		return fa.y
	end

	local pos = closest:GetPos()
	local pos = (pos - me:EyePos()):Angle()

	return pos.y
end

local function pitch()
		local opt = gOption("Hack vs Hack", "Anti-Aim", "Pitch")

	if opt == "None" then
		ox = fa.x
	elseif opt == "Up" then
		if gOption("Hack vs Hack", "Anti-Aim", "Yaw") == "Fake-Sideways" or gOption("Hack vs Hack", "Anti-Aim", "Yaw") == "Fake-Forwards" or gOption("Hack vs Hack", "Anti-Aim", "Yaw") == "Fake-Backwards" or gOption("Hack vs Hack", "Anti-Aim", "Yaw") == "Spin" then
			--ox = 3856
			ox = -120 - math.sin(CurTime()*10)*5
		else
			ox = -89
		end
	elseif opt == "Down" then
		if gOption("Hack vs Hack", "Anti-Aim", "Yaw") == "Fake-Sideways" or gOption("Hack vs Hack", "Anti-Aim", "Yaw") == "Fake-Forwards" or gOption("Hack vs Hack", "Anti-Aim", "Yaw") == "Fake-Backwards" or gOption("Hack vs Hack", "Anti-Aim", "Yaw") == "Spin" then
			--ox = -3856
			ox = 120 + math.sin(CurTime()*10)*5
		else
			ox = 89
		end
	elseif opt == "Center" then
		if gOption("Hack vs Hack", "Anti-Aim", "Yaw") == "Fake-Sideways" or gOption("Hack vs Hack", "Anti-Aim", "Yaw") == "Fake-Forwards" or gOption("Hack vs Hack", "Anti-Aim", "Yaw") == "Fake-Backwards" or gOption("Hack vs Hack", "Anti-Aim", "Yaw") == "Spin" then
			ox = 169 + math.sin(CurTime()*3)*5
		else
			ox = 0
		end
	elseif opt == "Fake-Down" then
		ox = 180.001
	elseif opt == "Fake-Up" then
		ox = -540.000005
	elseif opt == "looking_up_jk" then
	                  ox = math.random(-18, -200)
	elseif opt == "rape_pitch_anti_idiotbox" then
		ox = math.random(179.99999999999999999999999999999999999, 180.000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001)
	elseif opt == "pitch_wtf" then
		ox = 360
	elseif opt == "Jitter" then
		ox = math.random(-90, 90)
	elseif opt == "Spin" then
		ox = math.sin(CurTime()*gInt("Hack vs Hack", "Anti-Aim", "Spin Speed")/8)*60
	end
end

local function yaw()
	local opt = gOption("Hack vs Hack", "Anti-Aim", "Yaw")

	if gOption("Hack vs Hack", "Anti-Aim", "Pitch") == "Fake-Down" then return end
	if gOption("Hack vs Hack", "Anti-Aim", "Pitch") == "Fake-Up" then return end

	if opt == "None" then
		oy = fa.y
	elseif opt == "Sideways" then
		if gOption("Hack vs Hack", "Anti-Aim", "Rotation") == "Left" then
			if gBool("Hack vs Hack", "Anti-Aim", "Follow closest Target") then
				oy = GetClosest() + 90
			else
				oy = fa.y + 90
			end
		elseif gOption("Hack vs Hack", "Anti-Aim", "Rotation") == "Right" then
			if gBool("Hack vs Hack", "Anti-Aim", "Follow closest Target") then
				oy = GetClosest() - 90
			else
				oy = fa.y - 90
			end
		elseif rotate then
			if gBool("Hack vs Hack", "Anti-Aim", "Follow closest Target") then
				oy = GetClosest() + 90
			else
				oy = fa.y + 90
			end
		else
			if gBool("Hack vs Hack", "Anti-Aim", "Follow closest Target") then
				oy = GetClosest() - 90
			else
				oy = fa.y - 90
			end
		end
	elseif opt == "Backwards" then
		if gBool("Hack vs Hack", "Anti-Aim", "Follow closest Target") then
			oy = GetClosest() + 180
		else
			oy = fa.y + 180
		end



	elseif opt == "Spin" then
		if gOption("Hack vs Hack", "Anti-Aim", "Rotation") == "Right" then
			oy = CurTime() * (-gInt("Hack vs Hack", "Anti-Aim", "Spin Speed")*23) % 350, 1
		elseif gOption("Hack vs Hack", "Anti-Aim", "Rotation") == "Left" then
			oy = CurTime() * (gInt("Hack vs Hack", "Anti-Aim", "Spin Speed")*23) % 350, 1
		elseif rotate then
			oy = CurTime() * (-gInt("Hack vs Hack", "Anti-Aim", "Spin Speed")*23) % 350, 1
		else
			oy = CurTime() * (gInt("Hack vs Hack", "Anti-Aim", "Spin Speed")*23) % 350, 1
		end

	elseif opt == "Fake-Semi-Spin" then
	oy = CurTime() * (-gInt("Hack vs Hack", "Anti-Aim", "Spin Speed")*-23) % -350, 1
        ox = math.random(-180,-190)

	elseif opt == "Fake-Semi-Spin v2" then
	oy = CurTime() * (-gInt("Hack vs Hack", "Anti-Aim", "Spin Speed")*-23) % -350, 1
        ox = 180.001



	elseif opt == "Jitter" then
		oy = fa.y + math.random(-180, 180)

                 elseif opt == "ResolveBreak" then
                oy = GetClosest() + 90 + CurTime() * ( 110 *1) % 60, 1
                ox = -180.00000000000000000001

                 elseif opt == "DONOTUSE" then
                oy = GetClosest() + 90 + CurTime() * ( 110 *1) % -0, 1
                ox = -180.00000000000000000001



                  elseif opt == "wtf" then
                  oy = fa.y + math.random(-180, 180)
                  timer.Simple(1, function() ox = fa.y + math.random(-180, 180) end)

	elseif opt == "rape_yaw_switch" then
		oy = math.sin(CurTime()*90/1)*90

                  elseif opt == "Side Switch" then
		oy = math.random( - 631, 631)

                  elseif opt == "Side Switch v2" then
		oy = math.random( -90, 90)

                  elseif opt == "Anti-Anti-ResolverPitch" then
                  ox = 541
                  oy = math.sin(CurTime()*math.random(-1, 1)/8)*60


                  elseif opt == "Resolver Breaker" then
                  ox = 179.087929
                  oy = 90 - GetClosest();

	elseif opt == "Fake-Sideways (normal)" then
		if gBool("Hack vs Hack", "Anti-Aim", "Follow closest Target") then
			if gOption("Hack vs Hack", "Anti-Aim", "Rotation") == "Right" then
				--oy = GetClosest() + math.random(-85, -100)
				oy = GetClosest() - 90 - math.sin(CurTime()*10)*5
			elseif gOption("Hack vs Hack", "Anti-Aim", "Rotation") == "Left" then
				oy = GetClosest() + 90 + math.sin(CurTime()*10)*5
elseif rotate then
				oy = GetClosest() - 90 - math.sin(CurTime()*2.5)*75
			else
                                                                        --ox = math.random(-90, -91)
                                ox = math.random(89, 80) 
  				oy = GetClosest() - 90  + math.Rand(60,120);
			end
		else
			if gOption("Hack vs Hack", "Anti-Aim", "Rotation") == "Right" then
				--oy = GetClosest() + math.random(-85, -100)
			                  ox = math.random(180.929780, 90.929780)
				oy = GetClosest() + -90  + math.Rand(-20,20);
			elseif gOption("Hack vs Hack", "Anti-Aim", "Rotation") == "Left" then
				ox = math.random(180.929780, 90.929780)
				oy = GetClosest() - 90  + math.Rand(-20,20);
			elseif rotate then
				oy = fa.y - 90 - math.sin(CurTime()*10)*5
			else
				oy = fa.y + 90 + math.sin(CurTime()*10)*5
			end
		end


	elseif opt == "Fake-Sideways 2.0" then
	oy = GetClosest() - 90 - math.sin(CurTime()*32)*32


	elseif opt == "fake_angles" then
		if gBool("Hack vs Hack", "Anti-Aim", "Follow closest Target") then
			if gOption("Hack vs Hack", "Anti-Aim", "Rotation") == "Right" then
				--oy = GetClosest() + math.random(-85, -100)
				oy = GetClosest() - 90 - math.sin(CurTime()*10)*5
			elseif gOption("Hack vs Hack", "Anti-Aim", "Rotation") == "Left" then
				oy = GetClosest() + 90 + math.sin(CurTime()*10)*5
elseif rotate then
				oy = GetClosest() - 90 - math.sin(CurTime()*2.5)*75
			else
                                                                        ox = math.random(-90, -91)
				oy = GetClosest() - 90  + math.Rand(60,120);
			end
		else
			if gOption("Hack vs Hack", "Anti-Aim", "Rotation") == "Right" then
				--oy = GetClosest() + math.random(-85, -100)
			                  ox = math.random(180.929780, 90.929780)
				oy = GetClosest() + -90  + math.Rand(-1,1);
			elseif gOption("Hack vs Hack", "Anti-Aim", "Rotation") == "Left" then
				ox = math.random(180.929780, 90.929780)
				oy = GetClosest() - 90  + math.Rand(-1,1);
			elseif rotate then
				oy = fa.y - 90 - math.sin(CurTime()*10)*5
			else
				oy = fa.y + 90 + math.sin(CurTime()*10)*5
			end
		end

	

	elseif opt == "FAKE_STATIC" then
		if gBool("Hack vs Hack", "Anti-Aim", "Follow closest Target") then
			if gOption("Hack vs Hack", "Anti-Aim", "Rotation") == "Right" then
				--oy = GetClosest() + math.random(-85, -100)
				oy = GetClosest() - 90 - math.sin(CurTime()*10)*5
			elseif gOption("Hack vs Hack", "Anti-Aim", "Rotation") == "Left" then
				oy = GetClosest() + 90 + math.sin(CurTime()*10)*5
elseif rotate then
				oy = GetClosest() - 90 - math.sin(CurTime()*2.5)*75
			else
                                                                        --ox = math.random(-90, -91)
                                ox = math.random(89, 80) 
  				oy = GetClosest() - 90  + math.Rand(60,120);
			end
		else
			if gOption("Hack vs Hack", "Anti-Aim", "Rotation") == "Right" then
				--oy = GetClosest() + math.random(-85, -100)
			                  ox = math.random(180.929780, 181)
				oy = GetClosest() + -90  + math.Rand(-0.001,0.001);
			elseif gOption("Hack vs Hack", "Anti-Aim", "Rotation") == "Left" then
				ox = math.random(180.929780, 181)
				oy = GetClosest() - 90  + math.Rand(-0.001,0.001);
			elseif rotate then
				oy = fa.y - 90 - math.sin(CurTime()*10)*5
			else
				oy = fa.y + 90 + math.sin(CurTime()*10)*5
			end
		end


	elseif opt == "FAKE_SIDEWAYS" then
		if gBool("Hack vs Hack", "Anti-Aim", "Follow closest Target") then
			if gOption("Hack vs Hack", "Anti-Aim", "Rotation") == "Right" then
				--oy = GetClosest() + math.random(-85, -100)
				oy = GetClosest() - 90 - math.sin(CurTime()*16)*64
			elseif gOption("Hack vs Hack", "Anti-Aim", "Rotation") == "Left" then
				oy = GetClosest() - 90 - math.sin(CurTime()*16)*64
elseif rotate then
				oy = GetClosest() - 90 - math.sin(CurTime()*16)*64
			else
                                                                        --ox = math.random(-90, -91)
			        				ox = math.random(-181, -181)
				oy = GetClosest() - 90 - math.sin(CurTime()*16)*32
			end
		else
			if gOption("Hack vs Hack", "Anti-Aim", "Rotation") == "Right" then
				--oy = GetClosest() + math.random(-85, -100)
			        				ox = math.random(-181, -182)
				oy = GetClosest() - 90 - math.sin(CurTime()*16)*64
			elseif gOption("Hack vs Hack", "Anti-Aim", "Rotation") == "Left" then
			        				ox = math.random(-181, -182)
				oy = GetClosest() - 90 - math.sin(CurTime()*16)*64
			elseif rotate then
				oy = GetClosest() - 90 - math.sin(CurTime()*16)*64
			else
				oy = GetClosest() - 90 - math.sin(CurTime()*16)*64
			end
		end

	elseif opt == "FAKE_SIDEWAYS_V2" then
		if gBool("Hack vs Hack", "Anti-Aim", "Follow closest Target") then
			if gOption("Hack vs Hack", "Anti-Aim", "Rotation") == "Right" then
				--oy = GetClosest() + math.random(-85, -100)
				oy = GetClosest() - 90 - math.sin(CurTime()*32)*32
			elseif gOption("Hack vs Hack", "Anti-Aim", "Rotation") == "Left" then
				oy = GetClosest() - 90 - math.sin(CurTime()*32)*32
elseif rotate then
				oy = GetClosest() - 90 - math.sin(CurTime()*32)*32
			else
                                                                        --ox = math.random(-90, -91)
			        				ox = math.random(-181, -179)
				oy = GetClosest() - 90 - math.sin(CurTime()*32)*32
			end
		else
			if gOption("Hack vs Hack", "Anti-Aim", "Rotation") == "Right" then
				--oy = GetClosest() + math.random(-85, -100)
			        				ox = math.random(-181, -179)
				oy = GetClosest() - 90 - math.sin(CurTime()*32)*32
			elseif gOption("Hack vs Hack", "Anti-Aim", "Rotation") == "Left" then
			        				ox = math.random(-181, -179)
				oy = GetClosest() - 90 - math.sin(CurTime()*32)*32
			elseif rotate then
				oy = GetClosest() - 90 - math.sin(CurTime()*32)*32
			else
				oy = GetClosest() - 90 - math.sin(CurTime()*32)*32
			end
		end


	elseif opt == "yaw_wtf" then
                           ox = 180.001
                           if math.random(1, 75) == 25 then
			   oy = GetClosest() - 89
                           end
                           if math.random(1, 75) == 25 then
		           oy = GetClosest() - -89
                           end

	elseif opt == "yaw_wtf2" then
                           ox = 180.001
                           if math.random(1, 2) == 2 then
			   oy = GetClosest() - 89
                           end
                           if math.random(1, 2) == 1 then
		           oy = GetClosest() - -89
                           end

	elseif opt == "yaw_wtf3" then
                           ox = 180.001
                           if math.random(1,6) == 3 then
			   oy = -90
		           timer.Simple(0.01, function() oy = 0 end)
                           end

                          


	elseif opt == "FAKE_STATIC 2" then
		if gBool("Hack vs Hack", "Anti-Aim", "Follow closest Target") then
			if gOption("Hack vs Hack", "Anti-Aim", "Rotation") == "Right" then
				--oy = GetClosest() + math.random(-85, -100)
				oy = GetClosest() - 90 - math.sin(CurTime()*10)*5
			elseif gOption("Hack vs Hack", "Anti-Aim", "Rotation") == "Left" then
				oy = GetClosest() + 90 + math.sin(CurTime()*10)*5
elseif rotate then
				oy = GetClosest() - 90 - math.sin(CurTime()*2.5)*75
			else
                                                                        --ox = math.random(-90, -91)
                                ox = math.random(89, 80) 
  				oy = GetClosest() - 90  + math.Rand(60,120);
			end
		else
			if gOption("Hack vs Hack", "Anti-Aim", "Rotation") == "Right" then
				--oy = GetClosest() + math.random(-85, -100)
			                  ox = math.random(180.929780, 179)
				oy = GetClosest() + -90  + math.Rand(-0.001,0.001);
			elseif gOption("Hack vs Hack", "Anti-Aim", "Rotation") == "Left" then
				ox = math.random(180.929780, 179)
				oy = GetClosest() - 90  + math.Rand(-0.001,0.001);
			elseif rotate then
				oy = fa.y - 90 - math.sin(CurTime()*10)*5
			else
				oy = fa.y + 90 + math.sin(CurTime()*10)*5
			end
		end


	elseif opt == "FAKE_STATIC" then
		if gBool("Hack vs Hack", "Anti-Aim", "Follow closest Target") then
			if gOption("Hack vs Hack", "Anti-Aim", "Rotation") == "Right" then
				--oy = GetClosest() + math.random(-85, -100)
				oy = GetClosest() - 90 - math.sin(CurTime()*10)*5
			elseif gOption("Hack vs Hack", "Anti-Aim", "Rotation") == "Left" then
				oy = GetClosest() + 90 + math.sin(CurTime()*10)*5
elseif rotate then
				oy = GetClosest() - 90 - math.sin(CurTime()*2.5)*75
			else
                                                                        --ox = math.random(-90, -91)
                                ox = math.random(89, 80) 
  				oy = GetClosest() - 90  + math.Rand(60,120);
			end
		else
			if gOption("Hack vs Hack", "Anti-Aim", "Rotation") == "Right" then
				--oy = GetClosest() + math.random(-85, -100)
			                  ox = math.random(-180.929780, -179)
				oy = GetClosest() + -90  + math.Rand(-0.001,0.001);
			elseif gOption("Hack vs Hack", "Anti-Aim", "Rotation") == "Left" then
				ox = math.random(180.929780, 179)
				oy = GetClosest() - 90  + math.Rand(-0.001,0.001);
			elseif rotate then
				oy = fa.y - 90 - math.sin(CurTime()*10)*5
			else
				oy = fa.y + 90 + math.sin(CurTime()*10)*5
			end
		end


elseif opt == "Fake-Sideways (anti-idiotbox)" then
		if gBool("Hack vs Hack", "Anti-Aim", "Follow closest Target") then
			if gOption("Hack vs Hack", "Anti-Aim", "Rotation") == "Right" then
				--oy = GetClosest() + math.random(-85, -100)
				oy = GetClosest() - 90 - math.sin(CurTime()*10)*5
			elseif gOption("Hack vs Hack", "Anti-Aim", "Rotation") == "Left" then
				oy = GetClosest() + 90 + math.sin(CurTime()*10)*5
elseif rotate then
				oy = GetClosest() - 90 - math.sin(CurTime()*2.5)*75
			else
                                                                        ox = math.random(-18, -200)
				oy = GetClosest() - 90  + math.Rand(60,120);
			end
		else
			if gOption("Hack vs Hack", "Anti-Aim", "Rotation") == "Right" then
				--oy = GetClosest() + math.random(-85, -100)
			                  ox = 180.999999
				oy = GetClosest() + -90  + math.Rand(-5,5);
			elseif gOption("Hack vs Hack", "Anti-Aim", "Rotation") == "Left" then
				ox = 180.999999
				oy = GetClosest() - 90  + math.Rand(-5,5);
			elseif rotate then
				oy = fa.y - 90 - math.sin(CurTime()*10)*5
			else
				oy = fa.y + 90 + math.sin(CurTime()*10)*5
			end
		end

	elseif opt == "Fake-Forwards" then
		if gBool("Hack vs Hack", "Anti-Aim", "Follow closest Target") then
			if gOption("Hack vs Hack", "Anti-Aim", "Rotation") == "Right" then
				oy = GetClosest() + 180 + math.sin(CurTime()*1)*5
			elseif gOption("Hack vs Hack", "Anti-Aim", "Rotation") == "Left" then
				oy = GetClosest() + 180 - math.sin(CurTime()*1)*5
       		elseif rotate then
				oy = GetClosest() + 180 + math.sin(CurTime()*1)*5
			else
				oy = GetClosest() + 180 - math.sin(CurTime()*1)*5
			end
		else
			if gOption("Hack vs Hack", "Anti-Aim", "Rotation") == "Right" then
				oy = fa.y + 180 + math.sin(CurTime()*1)*5
			elseif gOption("Hack vs Hack", "Anti-Aim", "Rotation") == "Left" then
				oy = fa.y + 180 - math.sin(CurTime()*1)*5
			elseif rotate then
				oy = fa.y + 180 + math.sin(CurTime()*1)*5
			else
				oy = fa.y + 180 - math.sin(CurTime()*1)*5
			end
		end
	elseif opt == "Fake-Backwards" then
		if gBool("Hack vs Hack", "Anti-Aim", "Follow closest Target") then
			if gOption("Hack vs Hack", "Anti-Aim", "Rotation") == "Right" then
				oy = GetClosest() + math.sin(CurTime()*10)*5
			elseif gOption("Hack vs Hack", "Anti-Aim", "Rotation") == "Left" then
				oy = GetClosest() - math.sin(CurTime()*10)*5
			elseif rotate then
				oy = GetClosest() + math.sin(CurTime()*10)*5
			else
				oy = GetClosest() - math.sin(CurTime()*10)*5
			end
		else
			if gOption("Hack vs Hack", "Anti-Aim", "Rotation") == "Right" then
				oy = fa.y + math.sin(CurTime()*10)*5
			elseif gOption("Hack vs Hack", "Anti-Aim", "Rotation") == "Left" then
				oy = fa.y - math.sin(CurTime()*10)*5
			elseif rotate then
				oy = fa.y + math.sin(CurTime()*10)*5
			else
				oy = fa.y - math.sin(CurTime()*10)*5
			end
		end
	end
end

local function antiaim(cmd)
	if (cmd:KeyDown(IN_ATTACK) and wep:Clip1() ~= 0) or me:WaterLevel() > 1 or me:GetMoveType() == MOVETYPE_LADDER or me:GetMoveType() == MOVETYPE_NOCLIP or string.find(string.lower(wep:GetPrintName()),"grenade") or propkeycheck() or not me:Alive() then return end

	if gInt("Visuals", "Other", "Thirdperson") == 0 --[[and gOption("Misc", "Misc", "Circle Strafe") ~= "Off" and strafekeycheck()]] and cmd:CommandNumber() == 0 then
		return
	elseif gInt("Visuals", "Other", "Thirdperson") == 0 and cmd:CommandNumber() == 0 then
		return
	end
	
	if gOption("Hack vs Hack", "Anti-Aim", "Rotation") == "Switch on key" then
		if rotatecheck() and not rot_pressed then
			rot_pressed = true
			rotate = not rotate
		elseif not rotatecheck() and rot_pressed then
			rot_pressed = false
		end	
	end

	pitch()
	yaw()

	--[[oy = fa.y + (bool and 85 or 95)
	bool = not bool]]

	local aaang = Angle(ox, oy, 0)
	cmd:SetViewAngles(aaang)
	FixMovement(cmd, true)
end

local function propkill(cmd)
	if gInt("Visuals", "Other", "Thirdperson") ~= 0 --[[and gOption("Misc", "Misc", "Circle Strafe") ~= "Off" and strafekeycheck()]] and cmd:CommandNumber() == 0 then
		return
	elseif gInt("Visuals", "Other", "Thirdperson") == 0 and cmd:CommandNumber() == 0 then
		return
	end

	if propkeycheck() then
		ox = fa.x - 27

		if prop_val < 180 then
			oy = fa.y + prop_val
			prop_val = prop_val + 3
		else
			oy = fa.y + 180
		end

		local aaang = Angle(ox, oy, 0)
		cmd:SetViewAngles(aaang)
		FixMovement(cmd, true)
	else
		if prop_val > 0 then
			prop_val = 0
			--cmd:SetButtons(cmd:GetButtons() + IN_ATTACK2)

			prop_delay = CurTime() + 0.5
		end

		if prop_delay >= CurTime() then
			ox = -17
			oy = fa.y

			local aaang = Angle(ox, oy, 0)
			cmd:SetViewAngles(aaang)
			FixMovement(cmd, true)
		else
			prop_delay = 0
		end
	end
end



local function GetAngle(ang)
		if not gBool("Aimbot", "Aimbot", "Predict Recoil") then 
			return ang + pm.GetPunchAngle(me)
		else
			return ang
		end
end

--[[
local function GetAngle(ang)
	if not nophys() then
		if not gBool("Visuals", "Other", "No Recoil") then
			return ang + me:GetPunchAngle()
		else
			return ang
		end
	end
end
]]--






local function nospread(cmd)


	if(!fa) then 
		fa = cm.GetViewAngles(cmd)
	end
    fa = fa + Angle(cm.GetMouseY(cmd) * .023, cm.GetMouseX(cmd) * - .023, 0)
    NormalizeAngle(fa)
    if(cm.CommandNumber(cmd) == 0) then
			cm.SetViewAngles(cmd, GetAngle(fa))
			return
		end
	if(cm.KeyDown(cmd, 1)) then
			local ang = GetAngle(vm.Angle(PredictSpread(cmd, fa)))
			NormalizeAngle(ang)
			cm.SetViewAngles(cmd, ang)
    end
end


local function bunnyhop(cmd)
	buttons = cmd:GetButtons()
	if cmd:KeyDown(IN_JUMP) and me:IsValid() and me:GetMoveType() ~= MOVETYPE_NOCLIP and me:Alive() then
		if not me:IsOnGround() then
			buttons = bit.band(buttons, bit.bnot(IN_JUMP))
		end
		cmd:SetButtons(buttons)
	end
end


local function bunnyhopac(cmd)
	buttons = cmd:GetButtons()
	if cmd:KeyDown(IN_JUMP) and me:IsValid() and me:GetMoveType() ~= MOVETYPE_NOCLIP and me:Alive() then
		buttons = bit.band(buttons, bit.bnot(IN_JUMP))
                if math.random(1,2) == 2 then
		cmd:SetButtons(buttons)
                end
	end
end


local function bulletmarker(cmd)

tracerTable = {}
hitmarkerTable = {}

me = LocalPlayer()

hook.Add("PreDrawOpaqueRenderables", "DrawTracerBeam", function ()
        for k,v in next, tracerTable do
        if(v[3] <= 0) then
            table.remove(tracerTable, k);
            continue;
        end
        tracerTable[k][3] = tracerTable[k][3] - FrameTime();
        local pos1, pos2 = v[1], v[2];
        cam.Start3D();
        render.SetMaterial(Material( "cable/physbeam" ))
        render.DrawBeam(v[1], v[2], 4, 1, 1, v[4])
        cam.End3D();
    end
end)

hook.Add("HUDPaint", "DrawTracer",function ()
    for k, v in next, hitmarkerTable do
        local pos = v[1]:ToScreen()

        if(v[2] <= 0) then
            table.remove(hitmarkerTable, k);
            continue;
        end
        v[2] = v[2] - FrameTime()
        surface.SetDrawColor(0, 161, 255)
        surface.DrawLine( pos.x - 8, pos.y - 8, pos.x - 4, pos.y - 4 )
        surface.DrawLine( pos.x - 8, pos.y + 8, pos.x - 4, pos.y + 4 )
        surface.DrawLine( pos.x + 8, pos.y - 8, pos.x + 4, pos.y - 4 )
        surface.DrawLine( pos.x + 8, pos.y + 8, pos.x + 4, pos.y + 4 )
    end
end)

hook.Add("PlayerTraceAttack", "BulletTracer", function (ent, dmg, dir, trace)
    if(!IsFirstTimePredicted()) then return; end

    local vHitPos, vSrc;
    vHitPos = trace.HitPos;
    vSrc = trace.StartPos;

    table.insert(tracerTable, {vHitPos, vSrc, 5, Color(0, 255, 0), me:EyeAngles()});
    table.insert(hitmarkerTable, {vHitPos, 1})
end)

gameevent.Listen("player_hurt")
hook.Add("player_hurt", "Hitmarker", function (data)
    if(data.attacker != me:UserID()) then return end
    sound.PlayFile("ambient/alarms/klaxon1.wav", "mono", function()
    end)
end)

end

local function autostrafe(cmd)
	if me:IsOnGround() or me:KeyDown(IN_MOVELEFT) or me:KeyDown(IN_MOVERIGHT) or me:KeyDown(IN_FORWARD) or me:KeyDown(IN_BACK) or me:GetMoveType() == MOVETYPE_NOCLIP or me:WaterLevel() > 1 or not me:Alive() then return end

	--[[if cmd:GetMouseX() < -5 then
		cmd:SetSideMove(-me:GetVelocity():Length()-400)
	elseif cmd:GetMouseX() > 5 then
		cmd:SetSideMove(me:GetVelocity():Length()+400)
	else
		cmd:SetForwardMove(400)
		cmd:SetSideMove(math.random(-10000,10000))
	end]]

	if cmd:GetMouseX(ucmd) < -5 then
		cmd:SetSideMove(-400)
	elseif cmd:GetMouseX() > 5 then
		cmd:SetSideMove(400)
	else
		cmd:SetForwardMove(5850 / me:GetVelocity():Length2D())
		cmd:SetSideMove(cmd:CommandNumber() % 2 == 0 and -400 or 400)
	end
end

--[[local function strafefix(cmd, ang)
	local angs = cmd:GetViewAngles()
	local fa = fa

	if ang then
		fa = ang
	end

	local viewang = Angle(0, angs.y, 0)
	local fix = Vector(cmd:GetForwardMove(), cmd:GetSideMove(), 0)
	fix = (fix:Angle() + (viewang - fa)):Forward() * fix:Length()
	
	if angs.p > 90 or angs.p < -90 then
		fix.x = -fix.x
	end
	
	cmd:SetForwardMove(fix.x)
	cmd:SetSideMove(fix.y)
end

local function circlestrafe(cmd)
                  print("yes")
	if cmd:CommandNumber() == 0 then return end
                  print("no")

	command("-walk; +speed")

	local min = 1.25
	local max = 5.25
	local mult = 0.01

	strafe_val = strafe_val + math.Clamp((me:GetVelocity():Length2D() * mult), min, max)
	math.NormalizeAngle(strafe_val)

	if not me:IsOnGround() then
                                    print("gaming")
		cmd:SetForwardMove(10^4)
		cmd:SetSideMove(0)
		strafefix(cmd, Angle(fa.p, strafe_val, 0))
	elseif me:IsOnGround() and not cmd:KeyDown(IN_JUMP) then
		cmd:SetButtons(cmd:GetButtons() + IN_JUMP)
	end

	command("-speed")
end]]


aidsman = {}
aidsman.CircleStrafeVal = 0
aidsman.CircleStrafeSpeed = 1

aidsman.strafing = false
function aidsman.CreateVariable(name, default) CreateClientConVar("aidsman".. "_".. name, default, false, false) end




aidsman.CreateVariable("circlestrafe", "0")

	function aidsman.FixMove(cmd, rotation)
		aidsman.rot_cos = math.cos(rotation)
		aidsman.rot_sin = math.sin(rotation)
		aidsman.cur_forwardmove = cmd:GetForwardMove()
		aidsman.cur_sidemove = cmd:GetSideMove()
		cmd:SetForwardMove(((aidsman.rot_cos * aidsman.cur_forwardmove) - (aidsman.rot_sin * aidsman.cur_sidemove)))
		cmd:SetSideMove(((aidsman.rot_sin * aidsman.cur_forwardmove) + (aidsman.rot_cos * aidsman.cur_sidemove)))
	end




local function smallcirclestrafe(cmd)
		if ( input.IsMouseDown(MOUSE_5) ) then
			aidsman.CircleStrafeVal = aidsman.CircleStrafeVal + 1
		    if((aidsman.CircleStrafeVal > 0) && ((aidsman.CircleStrafeVal / aidsman.CircleStrafeSpeed) > 361)) then
				aidsman.CircleStrafeVal = 0
			end
			aidsman.FixMove(cmd, math.rad((aidsman.CircleStrafeVal - engine.TickInterval())))
			return(false)
		else
			aidsman.CircleStrafeVal = 0
		end
		return(true)
end


aidsman = {}
aidsman.CircleStrafeVal = 0
aidsman.CircleStrafeSpeed = 1

aidsman.strafing = false
function aidsman.CreateVariable(name, default) CreateClientConVar("aidsman".. "_".. name, default, false, false) end




aidsman.CreateVariable("circlestrafe", "0")

	function aidsman.FixMove(cmd, rotation)
		aidsman.rot_cos = math.cos(rotation)
		aidsman.rot_sin = math.sin(rotation)
		aidsman.cur_forwardmove = cmd:GetForwardMove()
		aidsman.cur_sidemove = cmd:GetSideMove()
		cmd:SetForwardMove(((aidsman.rot_cos * aidsman.cur_forwardmove) - (aidsman.rot_sin * aidsman.cur_sidemove)))
		cmd:SetSideMove(((aidsman.rot_sin * aidsman.cur_forwardmove) + (aidsman.rot_cos * aidsman.cur_sidemove)))
	end



local function CircleStrafeV2(cmd)
		if ( input.IsMouseDown(MOUSE_5) ) then
			aidsman.CircleStrafeVal = aidsman.CircleStrafeVal + aidsman.CircleStrafeSpeed
		    if((aidsman.CircleStrafeVal > 0) && ((aidsman.CircleStrafeVal / aidsman.CircleStrafeSpeed) > 361)) then
				aidsman.CircleStrafeVal = 0
			end
			aidsman.FixMove(cmd, math.rad((aidsman.CircleStrafeVal - engine.TickInterval())))
			return(false)
		else
			aidsman.CircleStrafeVal = 0
		end
		return(true)
end


local function rapid(cmd)
	if engine.ActiveGamemode() == "terrortown" then
		if GetRoundState() ~= ROUND_ACTIVE or GetRoundState() == ROUND_PREP then return end
	end


			if me:KeyDown(IN_ATTACK) then
				if string.find(string.lower(wep:GetPrintName()),"dual") then
					cmd:RemoveKey(IN_ATTACK) cmd:SetButtons(cmd:GetButtons() + IN_ATTACK2)
				else
					cmd:RemoveKey(IN_ATTACK)
				end
			end
		end

local function autoreload(cmd)
	if engine.ActiveGamemode() == "terrortown" then
		if GetRoundState() ~= ROUND_ACTIVE or GetRoundState() == ROUND_PREP then return end
	end

	if wep:Clip1() ~= 0 then
		if not cmd:KeyDown(IN_ATTACK) or not aimkeycheck() then
			if wep:IsValid() then
				if wep:Clip1() == 0 and wep:GetMaxClip1() > 0 and CurTime() > wep:GetNextPrimaryFire() then
					cmd:SetButtons(cmd:GetButtons() + IN_RELOAD)
				end
			else
				return
			end
		end
	else
		if wep:GetMaxClip1() > 0 and CurTime() > wep:GetNextPrimaryFire() then
			cmd:SetButtons(cmd:GetButtons() + IN_RELOAD)
		end
	end
end

local function show_aa(cmd)
	if not fa then
		fa = cmd:GetViewAngles()
	end

	fa = fa + Angle(cmd:GetMouseY() * .023, cmd:GetMouseX() * -.023, 0)
	NormalizeAngle(fa)

	if cmd:CommandNumber() == 0 then
		if not nophys() then
			cmd:SetViewAngles(GetAngle(fa))
			return
		end
	end
end

local function skipad()
	if MOTDgd or MOTDGD then
		function MOTDgd.GetIfSkip()
			msg(3, "Blocked an advertisement.")
			return true
		end
	end
end

function GAMEMODE:HUDShouldDraw() return true end

local function death_log(data)
	local killer = Entity(data.entindex_attacker)
	local victim = Entity(data.entindex_killed)

	if killer:IsValid() and victim:IsValid() and killer:IsPlayer() and victim:IsPlayer() and me:GetActiveWeapon():IsValid() then
		if killer == victim and victim ~= me then
			--chat.AddText(MenuCol, " "..victim:Nick().." killed themself.")
notification.AddLegacy( "[LMAOBOX] " .. victim:Nick() .. " killed themself", NOTIFY_HINT, 6 ) 
		elseif killer == victim and victim == me then
			--chat.AddText(MenuCol, " You killed yourself.")
notification.AddLegacy( "[LMAOBOX] You died.", NOTIFY_GENERIC, 3 ) 
		elseif killer == me then
			--chat.AddText(MenuCol, " You killed "..victim:Nick()..".")
notification.AddLegacy( "[LMAOBOX] Killed " .. victim:Nick() .. "", NOTIFY_GENERIC, 6 ) 
		elseif victim == me then
			--chat.AddText(MenuCol, " You were killed by "..killer:Nick()..".")
notification.AddLegacy( "[LMAOBOX] Got killed by " .. killer:Nick() .. "", NOTIFY_GENERIC, 3 ) 
		else
			--chat.AddText(MenuCol, " "..killer:Nick().." killed "..victim:Nick()..".")
notification.AddLegacy( "[LMAOBOX] " .. killer:Nick() .. " killed " .. victim:Nick() .. "", NOTIFY_ERROR, 3 ) 
		end

		chat.PlaySound()
	end
end


--[[
render.Capture = function() return "WWW.LMAOBOX.NET" end
render_Capture = function() return "WWW.LMAOBOX.NET" end
render.CapturePixels = function() return "WWW.LMAOBOX.NET" end
render_CapturePixels = function() return "WWW.LMAOBOX.NET" end
capture = function() return "WWW.LMAOBOX.NET" end
cl_rtxappend = function() return "WWW.LMAOBOX.NET" end
cl_rtxappend2 = function() return "WWW.LMAOBOX.NET" end
render.SetRenderTarget = function() return "WWW.LMAOBOX.NET" end
render_SetRenderTarget = function() return "WWW.LMAOBOX.NET" end
]]--









rendercapture = function() print("blocked libby screengrab") return "go fuck yourself: WWW.LMAOBOX.NET" end
screengrab = function() print("lua function: screengrab blocked") surface.PlaySound("buttons/button7.wav") return "go fuck yourself: WWW.LMAOBOX.NET" end
render_capture = function() print("lua function: render_capture blocked")  surface.PlaySound("buttons/button7.wav") return "go fuck yourself: WWW.LMAOBOX.NET" end
screen_grab = function() print("lua function: screen_grab blocked")  surface.PlaySound("buttons/button7.wav") return "go fuck yourself: WWW.LMAOBOX.NET" end
screencap = function() print("lua function: screencap blocked")  surface.PlaySound("buttons/button7.wav") return "go fuck yourself: WWW.LMAOBOX.NET" end
screen_cap = function() print("lua function: screen_cap blocked")  surface.PlaySound("buttons/button7.wav") return "go fuck yourself: WWW.LMAOBOX.NET" end
screencapture = function() print("lua function: screencapture blocked")  surface.PlaySound("buttons/button7.wav") return "go fuck yourself: WWW.LMAOBOX.NET" end
screen_capture = function() print("lua function: screen_capture blocked")  surface.PlaySound("buttons/button7.wav") return "go fuck yourself: WWW.LMAOBOX.NET" end
rtx = function() print("lua function: rtx blocked") surface.PlaySound("buttons/button7.wav") return "go fuck yourself: WWW.LMAOBOX.NET" end
cap = function() print("lua function: cap blocked") surface.PlaySound("buttons/button7.wav") return "go fuck yourself: WWW.LMAOBOX.NET" end







render.Capture = function() print("lua function: render.Capture (common) blocked")   surface.PlaySound("buttons/button7.wav") return "go fuck yourself: WWW.LMAOBOX.NET" end
render_Capture = function() print("lua function: render_Capture blocked")  surface.PlaySound("buttons/button7.wav") return "go fuck yourself: WWW.LMAOBOX.NET" end
render.CapturePixels = function() print("lua function: render.CapturePixels (common) blocked")  surface.PlaySound("buttons/button7.wav") return "go fuck yourself: WWW.LMAOBOX.NET" end
render_CapturePixels = function() print("lua function: render_CapturePixels blocked")  surface.PlaySound("buttons/button7.wav") return "go fuck yourself: WWW.LMAOBOX.NET" end
capture = function() print("lua function: capture blocked")  surface.PlaySound("buttons/button7.wav") return "go fuck yourself: WWW.LMAOBOX.NET" end
cl_rtxappend = function() print("lua function: cl_rtxappend blocked") surface.PlaySound("buttons/button7.wav") return "go fuck yourself: WWW.LMAOBOX.NET" end
cl_rtxappend2 = function() print("lua function: cl_rtxappend2 blocked") surface.PlaySound("buttons/button7.wav") return "go fuck yourself: WWW.LMAOBOX.NET" end
render.SetRenderTarget = function() print("lua function: render.SetRenderTarget (common) blocked") surface.PlaySound("buttons/button7.wav") return "go fuck yourself: WWW.LMAOBOX.NET" end
render_SetRenderTarget = function() print("lua function: render_SetRenderTarget blocked") surface.PlaySound("buttons/button7.wav") return "go fuck yourself: WWW.LMAOBOX.NET" end

function file.Read(name, path)
	if string.find(name, cheatname..".lua") or string.find(name, "lmaobox") then
if sashisusesoymmm == 0 then
		print("\nAn attempt to perform file.Read on \""..name.."\" has been made.\n")
end
 
if sashisusesoymmm == 0 then
               timer.Create("warn", 0.5, 1, function() surface.PlaySound("ambient/tones/pipes2.wav") chat.AddText("[lmaobox_alert]: warning, an attempt to perform a file thing on " .. name .. " has been made. (blocked) watch out your script is being checked on!") end)
end

local fuckoff_fileintruder = {

"OK! HERE IS THE FILE.READ THAT YOU RECEIVED: You are not going to read me you motherfucker: WWW.LMAOBOX.NET",
"OK! HERE IS THE FILE.READ THAT YOU RECEIVED: Fuck off cunt: WWW.LMAOBOX.NET",
"OK! HERE IS THE FILE.READ THAT YOU RECEIVED: There is no reading this funny: WWW.LMAOBOX.NET",
"OK! HERE IS THE FILE.READ THAT YOU RECEIVED: Why are you viewing this: WWW.LMAOBOX.NET",
"OK! HERE IS THE FILE.READ THAT YOU RECEIVED: Blocked: WWW.LMAOBOX.NET",
"OK! HERE IS THE FILE.READ THAT YOU RECEIVED: You'll never get anything from this file: WWW.LMAOBOX.NET"

}

if sashisusesoymmm == 0 then		
return "" .. table.Random(fuckoff_fileintruder) .. " " .. math.random(100000000,999999999) .. ""
else
return "Could not read the file"
end

	else
		return og_read(name, path)
	end
end

function file.Open(name, mode, path)
	if string.find(name, cheatname..".lua") or string.find(name, "lmaobox") then
if sashisusesoymmm == 0 then
		print("\nAn attempt to perform file.Open on \""..name.."\" has been made.\n")
end

if sashisusesoymmm == 0 then
                timer.Create("warn", 0.5, 1, function() surface.PlaySound("ambient/tones/pipes2.wav") chat.AddText("[lmaobox_alert]: warning, an attempt to perform a file thing on " .. name .. " has been made. (blocked) watch out your script is being checked on!") end)
end

local fuckoff_fileintruder = {

"OK! HERE IS THE FILE.OPEN THAT YOU RECEIVED: You are not going to open me you motherfucker: WWW.LMAOBOX.NET",
"OK! HERE IS THE FILE.OPEN THAT YOU RECEIVED: Fuck off cunt: WWW.LMAOBOX.NET",
"OK! HERE IS THE FILE.OPEN THAT YOU RECEIVED: There is no opening this funny: WWW.LMAOBOX.NET",
"OK! HERE IS THE FILE.OPEN THAT YOU RECEIVED: Why are you opening this: WWW.LMAOBOX.NET",
"OK! HERE IS THE FILE.OPEN THAT YOU RECEIVED: Blocked: WWW.LMAOBOX.NET",
"OK! HERE IS THE FILE.OPEN THAT YOU RECEIVED: You'll never get anything from this file: WWW.LMAOBOX.NET"

}

if sashisusesoymmm == 0 then		
return "" .. table.Random(fuckoff_fileintruder) .. " " .. math.random(100000000,999999999) .. ""
else
return "Could not open the file"
end

	else
		return og_open(name, mode, path)
	end
end

function file.Exists(name, path)
	if string.find(name, cheatname..".lua") or string.find(name, "lmaobox") then
if sashisusesoymmm == 0 then
		print("\nAn attempt to perform file.Exists on \""..name.."\" has been made.\n")
end
if sashisusesoymmm == 0 then
                timer.Create("warn", 0.5, 1, function() surface.PlaySound("ambient/tones/pipes2.wav")  chat.AddText("[lmaobox_alert]: warning, an attempt to perform a file thing on " .. name .. " has been made. (blocked) watch out your script is being checked on!") end)
end		

local fuckoff_fileintruder = {

"OK! HERE IS THE FILE.EXISTS THAT YOU RECEIVED: You are not going to check me you motherfucker: WWW.LMAOBOX.NET",
"OK! HERE IS THE FILE.EXISTS THAT YOU RECEIVED: Fuck off cunt: WWW.LMAOBOX.NET",
"OK! HERE IS THE FILE.EXISTS THAT YOU RECEIVED: There is no checking this funny: WWW.LMAOBOX.NET",
"OK! HERE IS THE FILE.EXISTS THAT YOU RECEIVED: Why are you checking this: WWW.LMAOBOX.NET",
"OK! HERE IS THE FILE.EXISTS THAT YOU RECEIVED: Blocked: WWW.LMAOBOX.NET",
"OK! HERE IS THE FILE.EXISTS THAT YOU RECEIVED: You'll never get anything from this file: WWW.LMAOBOX.NET"

}


if sashisusesoymmm == 0 then		
return "" .. table.Random(fuckoff_fileintruder) .. " " .. math.random(100000000,999999999) .. ""
else
return "Could not check the file"
end

	else
		return og_exists(name, path)
	end
end

function fakeqacpart()
	net.Start( "screengrab_part")
	net.WriteUInt(4, 32)
	net.WriteData("000000000000000000000000", 4)
	net.SendToServer()
end

--function net.Receive(str, func)
--	if str == "screengrab_part" then
--		fakeqacpart()
--		return
--	end
--
--	return og_Receive(str,func)
--end

--function net.Start(str)
--	if str == "screengrab_start" then
--		return
--	end
--end

local function hook_exists(name, identifier)
	for k, v in next, hook.GetTable() do
		if k == name then
			for a, b in next, v do
				if a == identifier then
					return true
				end
			end
			return false
		end
	end
end

local spam2_messages = {

"WWW.LMAOBOX.NET - BEST GMOD CHEAT!",
"GET GOOD, GET LMAOBOX",
"WWW.LMAOBOX.NET - WAY TO THE TOP!"

}

local randomletters = {

"a",
"b",
"c",
"d",
"e",
"f",
"g",
"h",
"i",
"j",
"k",
"l",
"m",
"n",
"o",
"p",
"q",
"r",
"s",
"t",
"u",
"v",
"w",
"x",
"y",
"z"

}

local randomletterscap = {

"A",
"B",
"C",
"D",
"E",
"F",
"G",
"H",
"I",
"J",
"K",
"L",
"M",
"N",
"O",
"P",
"Q",
"R",
"S",
"T",
"U",
"V",
"W",
"X",
"Y",
"Z"

}




local function chatspam()

	if gOption("Misc", "Misc", "Chat Spam") == "Advertisements (antispam)" then
		if engine.ActiveGamemode() == "darkrp" then

                        if math.random(1,100) == 50 then
			command("say // " .. table.Random(spam2_messages) .. " " .. table.Random(randomletters) .. "" .. math.random(1,9) .. "" .. table.Random(randomletters) .. "" .. math.random(1,9) .. "" .. table.Random(randomletters) .. "")
                        end
		else
                        if math.random(1,100) == 50 then
			command("say " .. table.Random(spam2_messages) .. " " .. table.Random(randomletters) .. "" .. math.random(1,9) .. "" .. table.Random(randomletters) .. "" .. math.random(1,9) .. "" .. table.Random(randomletters) .. "")
                        end
		end
         end


	if gOption("Misc", "Misc", "Chat Spam") == "Advertisements (antispam v2)" then
		if engine.ActiveGamemode() == "darkrp" then

                        if math.random(1,200) == 100 then
			command("say // " .. table.Random(spam2_messages) .. " " .. table.Random(randomletterscap) .. "" .. math.random(1,9) .. "" .. table.Random(randomletterscap) .. "" .. math.random(1,9) .. "" .. table.Random(randomletterscap) .. "")
                        end
		else
                        if math.random(1,200) == 100 then
			command("say " .. table.Random(spam2_messages) .. " " .. table.Random(randomletterscap) .. "" .. math.random(1,9) .. "" .. table.Random(randomletterscap) .. "" .. math.random(1,9) .. "" .. table.Random(randomletterscap) .. "")
                        end
		end
         end


	if gOption("Misc", "Misc", "Chat Spam") == "test (antispam)" then
		if engine.ActiveGamemode() == "darkrp" then

                        if math.random(1,100) == 50 then
			command("say // test " .. table.Random(randomletters) .. "" .. math.random(1,9) .. "" .. table.Random(randomletters) .. "" .. math.random(1,9) .. "" .. table.Random(randomletters) .. "")
                        end
		else
                        if math.random(1,100) == 50 then
			command("say test " .. table.Random(randomletters) .. "" .. math.random(1,9) .. "" .. table.Random(randomletters) .. "" .. math.random(1,9) .. "" .. table.Random(randomletters) .. "")
                        end
		end
         end




if gOption("Misc", "Misc", "Chat Spam") == "methamphetamine.solutions" then
methtimer = methtimer + 1
		if engine.ActiveGamemode() == "darkrp" then

                        if methtimer == 100 then
command("say // addicting the innocent since 2018 - methamphetamine.solutions")
end
if methtimer == 200 then
command("say // your cheat will never compare - methamphetamine.solutions")
end
if methtimer == 300 then
command("say // can't touch this - methamphetamine.solutions")
end
if methtimer == 400 then
command("say // #1 garry's mod cheat - methamphetamine.solutions")
end
if methtimer == 500 then
command("say // your ac owned - methamphetamine.solutions")
end
if methtimer == 600 then
command("say // should have brought meth - methamphetamine.solutions")
end
if methtimer == 700 then
command("say // now rewritten!- methamphetamine.solutions")
end
if methtimer == 800 then
command("say // should have used a condom - methamphetamine.solutions")
methtimer = 0
end


		else
                       



if methtimer == 100 then
command("say addicting the innocent since 2018 - methamphetamine.solutions")
end
if methtimer == 200 then
command("say your cheat will never compare - methamphetamine.solutions")
end
if methtimer == 300 then
command("say can't touch this - methamphetamine.solutions")
end
if methtimer == 400 then
command("say #1 garry's mod cheat - methamphetamine.solutions")
end
if methtimer == 500 then
command("say your ac owned - methamphetamine.solutions")
end
if methtimer == 600 then
command("say should have brought meth - methamphetamine.solutions")
end
if methtimer == 700 then
command("say now rewritten!- methamphetamine.solutions")
end
if methtimer == 800 then
command("say should have used a condom - methamphetamine.solutions")
methtimer = 0
end






		end
         end












	if gOption("Misc", "Misc", "Chat Spam") == "Advertisements (including clear chat)" then
		if engine.ActiveGamemode() == "darkrp" then

                        if math.random(1,100) == 50 then
			command("say // " .. table.Random(spam2_messages) .. "")
                        end
                        if math.random(1,100) == 50 then
			ChatClear.OOC()
                        end
		else
                        if math.random(1,100) == 50 then
			command("say " .. table.Random(spam2_messages) .. "")
                        end
                        if math.random(1,100) == 50 then
			ChatClear.OOC()
                        end
		end
         end



	if gOption("Misc", "Misc", "Chat Spam") == "Advertisements" then
		if engine.ActiveGamemode() == "darkrp" then
			command("say // "..spam2_messages[math.random(#spam2_messages)])
		else
			command("say "..spam2_messages[math.random(#spam2_messages)])
		end
	end






	if gOption("Misc", "Misc", "Chat Spam") == "Full Advertisements" then



local anarchyv1234 = {
"GET GOOD, GET LMAOBOX!",
"LMAOBOX - WAY TO THE TOP!",
"WWW.LMAOBOX.NET - BEST TF2 FREE HACK!",
"EPIC VISUALS AND AIMBOT",
"LMAOBOX - NO SKILL",
"DOWNLOAD LMAOBOX NOW AT WWW.LMAOBOX.NET",
"BEST CHEATS IN THE WORLD",
"BECOME A PRO TODAY!",
"LMAOBOX - THE SUPERIOR CHEAT",
"UNDETECTED CHEATS FOR TF2",
"KARMA ISN'T A ANSWER - WWW.LMAOBOX.NET",
"THE BEST TF2 EXPERIENCE",
"BE A GAMER",
"GAMERS USE LMAOBOX",
"DOWNLOAD NOW TODAY! -  WWW.LMAOBOX.NET",
"NOOB - TO - PRO, WWW.LMAOBOX.NET",
"SUPER PRO MODS NO EXPLOITING INCLUDED",
"WWW.LMAOBOX.NET",
"COMING TO GMOD - WWW.LMAOBOX.NET",
"COMING TO CSGO - WWW.LMAOBOX.NET",
"COMING TO TF2 - WWW.LMAOBOX.NET",
"COMING TO CSS - WWW.LMAOBOX.NET",
"THE GLOBAL CHEAT FOR ALL SOURCE GAMES",
"UNDETECTED TO THIS DAY, NO BANS",
"GET THE PREMIUM VERSION FOR 20$!",
"THIS IS NOT A HACK, ITS A HUD MOD!",
"SPREAD THE WORD, MOTHERFUCKERS - WWW.LMAOBOX.NET",
"LMAOBOX, THE TOTALLY NOT A PASTE CHEAT",
"GET IT NOW YOU FAGGET",
"BEST ANTI-CHEAT PROTECTION!!1!!!!!1!1!1!1111111!",
"THE GLOBAL CHEAT FOR VALVE SOURCE GAMES",
"THE CHEAT FOR: CSGO, GMOD, TF2, AND CSS",
"LMAOBOX - BEST SUPERIOR GLOBAL CHEAT OF ALL-TIME!",
"BECOME A USER, TODAY! - WWW.LMAOBOX.NET",
"VALVE CAN'T STOP US - WWW.LMAOBOX.NET",
"LMAOBOX - UNSTOPPABLE TF2 CHEAT OF 2021",
"LMAOBOX - AGAINST THE TF BOTS",



}


		if engine.ActiveGamemode() == "darkrp" then


                        if math.random(100,200) == 100 then
			command("say // " .. table.Random(anarchyv1234) .. "")
end
		else
                        if math.random(100,200) == 100 then
			command("say " .. table.Random(anarchyv1234) .. "")
end
		end
	end




	if gOption("Misc", "Misc", "Chat Spam") == "Aggressive Advertisements" then



local aggressiveadvertise = {

"GET GOOD GET FUCKING LMAOBOX GET GOOD GET FUCKING LMAOBOX --> LMAOBOX.NET",
"WWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWW",
"WELCOME TO THE BEST FUCKING SERVER EVER --> LMAOBOX.NET",
"GET LAUGHING MY ASS OUT BOX BEST FUCKING CHEATS --> LMAOBOX.NET",
"WITH LIBRE CHATSPAM BYPASS --> LMAOBOX.NET",
"WE'RE GOING FUCKING RAVE! --> LMAOBOX.NET",
"PROJECT VALOR --> LMAOBOX.NET",
"GET GOOD. GET LMAOBOX --> LMAOBOX.NET",
"LMAOBOX.NET --> LMAOBOX.NET",
"OWN EVERYONE. BECOME A SUPERIOR --> LMAOBOX.NET",
"BEST OPTION. BECOME A LEGIT --> LMAOBOX.NET",
"YES! YES! YES! --> LMAOBOX.NET",
"GOOD AIMBOT, GOOD CHEAT, GOOD STUFF WITH A LOT OF SHIT --> LMAOBOX.NET",
"THE AFFORDABLE FUCKING CHEAT THAT YOU'LL NEVER REGRET --> LMAOBOX.NET",
"GO GET YOUR FUCKING CHEAT RIGHT NOW YOU FUCKING FAGGOT I HAVE YOUR IP --> LMAOBOX.NET",
"NIGGERNIGGERNIGGERNIGGERNIGGERNIGGERNIGGERNIGGERNIGGERNIGGERNIGGERNIGGERNIGGERNIGGERNIGGERNIGGERNIGGERNIGGERNIGGERNIGGERNIGGERNIGGERNIGGER",
"GET GOOD GET LMAOBOX! GET GOOD GET LMAOBOX! GET GOOD GET LMAOBOX! GET GOOD GET LMAOBOX! GET GOOD GET LMAOBOX! GET GOOD GET LMAOBOX!",
"IF YOU DON'T HAVE LMAOBOX YOU'RE A WHORE! BUT IF YOU'RE A CHEATER I CAN SUPPORT YOU!",
"WE'RE NOW SELLING OUR CHEATS AT GARRY'S MOD --> LMAOBOX.NET",
"I HAVE NOW TAKEN CONTROL OF THIS SERVER --> LMAOBOX.NET",
"GET GOOD GET LMAOBOX YOU FUCKING NIGGERS GET GOOD GET LMAOBOX YOU FUCKING NIGGERS GET GOOD GET LMAOBOX YOU FUCKING NIGGERS GET GOOD GET LMAOBOX YOU FUCKING NIGGERS",
"WHAT HAPPENED? YOU GOT FUCKED FAGGOT. GET GOOD GET LMAOBOX!",
"LOOKS LIKE YOU HAVE NO CHOICE BUT TO GET THE BEST AFFORDABLE CHEAT YOU WILL EVER NEED: WWW.LMAOBOX.NET",
"START PRAYING BOY. START SCREAMING THE WORD LMAOBOX AND ADVERTISE OUR SHIT EVEN MORE!",
"WHY DON'T YOU JUST GET THE CHEAT. IT'LL BOOST YOUR GAMEPLAY EXPERIENCE AND YOUR EGO!",
"WE GIVE OUT THE BEST STEROIDS FOR YOUR GMOD. IT'S CALLED WWW.LMAOBOX.NET",




}



if math.random(1,50) == 25 then
                        local user = player.GetAll()[math.random(#player.GetAll())] 
			command("ulx psay " .. user:Nick() .. " " .. table.Random(aggressiveadvertise) .. "") 
end
		if engine.ActiveGamemode() == "darkrp" then


                        if math.random(1,50) == 25 then
			command("say // " .. table.Random(aggressiveadvertise) .. "")
end





		else
                        if math.random(1,50) == 25 then
			command("say " .. table.Random(aggressiveadvertise) .. "")
end


		end
	end







	if gOption("Misc", "Misc", "Chat Spam") == "Force Advertisements" then
                local usernick = player.GetAll()[math.random(#player.GetAll())] 
		if engine.ActiveGamemode() == "darkrp" then
			command("say // " .. usernick:Name() .. " "..spam2_messages[math.random(#spam2_messages)])
		else
			command("say " .. usernick:Nick() .. " "..spam2_messages[math.random(#spam2_messages)])
		end
	end

	if gOption("Misc", "Misc", "Chat Spam") == "psay_spam_all_lmaobox" then
                        local usernick = player.GetAll()[math.random(#player.GetAll())] 
                        if v == me then return end
			command("ulx psay " .. usernick:Nick() .. " " .. table.Random(spam2_messages) .. "") 
                       
        end
	

	if gOption("Misc", "Misc", "Chat Spam") == "psay_spam_all_lmaobox2" then
                        if math.random(1,50) == 25 then
                        local usernick = player.GetAll()[math.random(#player.GetAll())] 
                        if v == me then return end
                        timer.Create("lolspamthefuckout", 0.01, 20, function() 	command("ulx psay " .. usernick:Nick() .. " " .. table.Random(spam2_messages) .. "")  end)
                        end
          end


if gOption("Misc", "Misc", "Chat Spam") == "psay_spam_all_lmaobox3" then
                        if math.random(1,20) == 10 then
                        local usernick = player.GetAll()[math.random(#player.GetAll())] 
                        if v == me then return end
                        timer.Create("lolspamthefuckout", 0.01, 5, function() 	command("ulx psay " .. usernick:Nick() .. " " .. table.Random(spam2_messages) .. "")  end)
                        end
end



if gOption("Misc", "Misc", "Chat Spam") == "psay_spam_all_custom" then


local steam1 = {

"A",
"B",
"C",
"D",
"E",
"F",
"G",
"H",
"I",
"J",
"K",
"L",
"M",
"N",
"O",
"P",
"Q",
"R",
"S",
"T",
"U",
"V",
"W",
"X",
"Y",
"Z",
"1",
"2",
"3",
"4",
"5",
"6",
"7",
"8",
"9",
"0",


}




                        if math.random(1,20) == 10 then
                        local usernick = player.GetAll()[math.random(#player.GetAll())] 
                        if v == me then return end
                        timer.Create("lolspamthefuckout", 0.01, 5, function() 	command("ulx psay " .. usernick:Nick() .. " {" .. math.random(100,999) .. " WWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWW  " .. math.random(100,999) .. "}")  end)
                        end
end



if gOption("Misc", "Misc", "Chat Spam") == "Chat Clear" then
		if engine.ActiveGamemode() == "darkrp" then
			ChatClear.OOC()
		else
			ChatClear.Run()
		end
	end

end

local function entityname()
	if util.TraceLine(util.GetPlayerTrace(me)).Entity:IsValid() then
		return util.TraceLine(util.GetPlayerTrace(me)).Entity:GetClass()
	else
		return "None"
	end
end

local function spam_kill(data)
	local killer = Entity(data.entindex_attacker)
	local killed = Entity(data.entindex_killed)

	if not killer:IsValid() or not killed:IsValid() or killer ~= me or killer == killed or not killed:IsPlayer() then return end
	if gBool("Aimbot", "Other", "Ignore Friends") then if killed:GetFriendStatus() == "friend" then return end end

	local default = { killed:Nick()..", do you even lift?", "Sit down, "..killed:Nick()..".", "Faggot.", "Owned!", "Rekt!!!", "1tapped.", "Ez tbh.", "Ez!", "Later, "..killed:Nick()..".", "Noob.", "Right into your face, "..killed:Nick()..".", "Into your face, pal.", killed:Nick().." with that negative IQ!", "Gay kid." }
	--local hvh = { "ez resolve, "..killed:Nick(), "noob", "pCheat", "stop using bad paste!!!!!", "10/10 cheat", "where can I get that perfect cheat", "wow!", "ez", "1", "ezzzz", "tfw resolved", "wow! rekt!", "owned!!", "u got OWNED "..killed:Nick().."!!!!!" }

	if gOption("Misc", "Misc", "Spam after Kill") == "On" then
		command("say "..default[math.random(#default)])
	elseif gOption("Misc", "Misc", "Spam after Kill") == "Rage Targets Only" and table.HasValue(priority_list, killed:UniqueID()) then
		command("say "..default[math.random(#default)])
	--[[elseif gOption("Misc", "Misc", "Spam after Kill") == "HvH Resolved Angle" and gBool("Hack vs Hack", "Anti-Aim Resolver", "Enabled") and gBool("Aimbot", "Aimbot", "Auto Fire") then
		command("say Resolved: "..killed:Nick().." - Pitch: "..gOption("Hack vs Hack", "Anti-Aim Resolver", "Pitch").." ("..math["Round"](pitch)..") - Yaw: "..gOption("Hack vs Hack", "Anti-Aim Resolver", "Yaw").." ("..math["Round"](yaw)..")")]]
	end
end

local function namesteal()
	local random_player = player.GetAll()[math.random(#player.GetAll())]

	if random_player:IsValid() and random_player ~= me and random_player:GetFriendStatus() ~= "friend" then
		if engine.ActiveGamemode() == "darkrp" then
			changetime = changetime + 1

			if changetime > 500 then
				me:ConCommand("say /name "..random_player:Name().."​")
				changetime = 0
			end
		elseif engine.ActiveGamemode() == "terrortown" then
			if GetRoundState() ~= ROUND_ACTIVE and GetRoundState() ~= ROUND_PREP then
				_fhook_changename(random_player:Name().."​")
			end
		else
			_fhook_changename(random_player:Name().."​")
		end

		if not name_changed then
			name_changed = true
		end

		stolenname = random_player:Name()
	end
end






addhook("Move", function()
	--if not IsFirstTimePredicted() then return end

	if gBool("Aimbot", "Aimbot", "Auto Fire") and gInt("Aimbot", "Misc", "Auto Fire Delay") ~= 0 then
		servertime = CurTime() - gInt("Aimbot", "Misc", "Auto Fire Delay")/100
	else
		servertime = CurTime()
	end
end)


addhook("Think", function()
	if (input.IsKeyDown(KEY_INSERT) or input.IsKeyDown(KEY_F11) or input.IsKeyDown(KEY_HOME)) and not menuopen and not insertdown then
		menuopen = true
		insertdown = true
		menu()
	elseif not (input.IsKeyDown(KEY_INSERT) or input.IsKeyDown(KEY_F11) or input.IsKeyDown(KEY_HOME)) and not menuopen then
		insertdown = false
	end
	if (input.IsKeyDown(KEY_INSERT) or input.IsKeyDown(KEY_F11) or input.IsKeyDown(KEY_HOME)) and insertdown and menuopen then
		insertdown2 = true
	else
		insertdown2 = false
	end

	if _G.CheckVars then
		_G.CheckVars = function()
			return
		end
	end

	if _G.RunCheck then
		_G.RunCheck = function()
			return
		end
	end



	if table.HasValue(supported_modes, engine.ActiveGamemode()) then
		if engine.ActiveGamemode() == "murder" then
			murder_misc()
		elseif engine.ActiveGamemode() == "darkrp" then
			darkrp_misc()
		elseif engine.ActiveGamemode() == "terrortown" then
			ttt_misc()
		end
	end

	if gOption("Misc", "Misc", "Chat Spam") ~= "Off" then
		chatspam()
	end

	skipad()

	if hook_exists("HUDPaint", "ulx_blind") then
		hook.Remove("HUDPaint", "ulx_blind")
		msg(3, "Blocked a blinding attempt.")
	end

	if gBool("Aimbot", "Misc", "No Lerp") then
		if not applied then
			command("cl_interp 0; cl_interp_ratio 0; cl_updaterate 99999")
			applied = true
		end
	else
		if applied then
			command("cl_interp 0; cl_interp_ratio 2; cl_updaterate 30")
			applied = false
		end
	end

	if gBool("Misc", "Misc", "Name Stealer") then
		namesteal()
	else
		if name_changed and me:Nick() ~= realname then
			if engine.ActiveGamemode() == "darkrp" then
				me:ConCommand("say /name "..realname)
			elseif engine.ActiveGamemode() == "terrortown" then
				if GetRoundState() ~= ROUND_ACTIVE and GetRoundState() ~= ROUND_PREP then
					_fhook_changename(realname)
				end
			else
				_fhook_changename(realname)
			end

			name_changed = false
		end
	end
end)






addhook("RenderScreenspaceEffects", function()
	if gBool("Visuals", "ESP", "Enabled") and gOption("Visuals", "ESP", "Chams") ~= "Off" then
		chams()
	end
end)


local function autoheal(cmd)
if me:Health() < 99.999 then
healspawn = healspawn + 1

if healspawn < 1.1 then
chat.AddText( Color(255, 152, 255), "Automatically healing: " .. me:Health() .. "")
end

	local anotherang = Angle(89, 0, 0)
	cmd:SetViewAngles(anotherang)
        if healspawn < 3 then
        command("gm_spawnsent item_healthkit")
        timer.Simple(0.045, function()RunConsoleCommand("gmod_undo") end)
        end
        if healspawn > 3 then
        command("gm_spawnsent item_healthkit")
        end
else
healspawn = 0
end
end

local function autoheallibby(cmd)
if me:Health() < 499.999 then
libbyhealth = libbyhealth + 1
if libbyhealth > 3 then
command("ulx hp ^ 500")
libbyhealth = 0
end
end
end



addhook("CreateMove", function(cmd)
	memesendpacket = true
	wep = me:GetActiveWeapon()

	if me:Health() < 1 or not me:Alive() then return end

	show_aa(cmd)

	if cmd:CommandNumber() ~= 0 then
		localindex = me:EntIndex()
		currentcommand = cmd:CommandNumber()
	end

	if gBool("Triggerbot", "Triggerbot", "Enabled") then
		triggerbot(cmd)
	end

	--if gInt("Misc", "Fake Lag", "Density") ~= 0 and not gBool("Hack vs Hack", "Anti-Aim", "Enabled") then

        local opt = gOption("Misc", "Fake Lag", "Mode")
	if opt == "Normal" and gInt("Misc", "Fake Lag", "Density") ~= 0 then
		fakelag(cmd)
	end

        local opt = gOption("Misc", "Fake Lag", "Mode")
	if opt == "Counter-Dynamic" then
		fakelagcounterdynamic(cmd)
	end

        local opt = gOption("Misc", "Fake Lag", "Mode")
	if opt == "Dynamic" then
		fakelagdynamic(cmd)
	end

packetcancel = function() memesendpacket = false return true end

packetcancellarge = function() for i = 1000,5000 do memesendpacket = false return true end end


	if gBool("Misc", "Fake Lag", "Packet Cancel") then
		packetcancel()
	end

	if gBool("Misc", "Fake Lag", "Packet Cancel Large") then
		packetcancellarge()
	end

	if gBool("Misc", "Misc", "Bunny Hop") then
		bunnyhop(cmd)
	end


        if gBool("Misc", "Other", "Auto Heal (do not use if building)") then
        autoheal(cmd)
        end


        if gBool("Misc", "Other", "Auto Heal (ULX Libby)")  then
        autoheallibby(cmd)
        end


	if gBool("Misc", "Misc", "Bunny Hop (AntiCheat)") then
		bunnyhopac(cmd)
	end


	if gBool("Aimbot", "Aimbot", "Predict Spread") then
		nospread(cmd)
	end

	if gBool("Misc", "Misc", "Bullet Marker") then

        if math.random(1,100) == "50" then
        hook.Remove("PreDrawOpaqueRenderables", "DrawTracerBeam")
        hook.Remove("HUDpaint", "DrawTracer")
        hook.Remove("PlayerTraceAttack", "BulletTracer")
        end


        else
        
        bulletmarker(cmd)


	end

	if gBool("Misc", "Misc", "Auto Strafe") --[[and not strafekeycheck()]] then
		autostrafe(cmd)
	end

	if gOption("Misc", "Misc", "Circle Strafe") ~= "Off" and strafekeycheck() then
		circlestrafe(cmd)
	end


	if gBool("Misc", "Misc", "Circle Strafe V2") then
		CircleStrafeV2(cmd)
	end

	if gBool("Misc", "Misc", "Circle Strafe Small") then
		smallcirclestrafe(cmd)
	end
	if gBool("Misc", "Misc", "Rapid Fire") then
		rapid(cmd)
	end

	if gBool("Misc", "Misc", "Auto Reload") and wep:IsValid() then
		autoreload(cmd)
	end

	if gBool("Misc", "Misc", "Grandpa Walk") then
		if me:KeyDown(IN_DUCK) then
			if crouched <= 5 then
				cmd:SetButtons(cmd:GetButtons() + IN_DUCK)
			elseif crouched >= 25 then
				crouched = 0
			end
			crouched = crouched + 1
		else
			if crouched <= 5 then
				cmd:SetButtons(cmd:GetButtons() + IN_DUCK)
			elseif crouched >= 12.5 then
				crouched = 0
			end
			crouched = crouched + 1
		end
	end

        if gBool("Misc", "Misc", "Duck and Duck") then
		if me:KeyDown(IN_DUCK) then
			if crouched <= 5 then
				cmd:SetButtons(cmd:GetButtons() + IN_DUCK)
			elseif crouched >= 50 then
				crouched = 0
			end
			crouched = crouched + 1
		else
			if crouched <= 25 then
				cmd:SetButtons(cmd:GetButtons() + IN_DUCK)
			elseif crouched >= 50 then
				crouched = 0
			end
			crouched = crouched + 1
		end
	end

	local oldAngles = cmd:GetViewAngles()

	if gBool("Aimbot", "Aimbot", "Enabled") and wep:IsValid() then
		aimbot(cmd)
	end

	if gBool("Aimbot", "Aimbot", "Target Info") and wep:IsValid() then  
        lol = lol + 1
                --[[
		chat.AddText("Target: " .. aimtarget:Nick() .. "")
                chat.AddText("Health: " .. aimtarget:Health() .. "")
                chat.AddText("Armor: " .. aimtarget:Armor() .. "")
                ]]--

                if lol > 100 then
                if IsValid(aimtarget) then
                if aimtarget:IsValid() then

                if aimtarget:IsNPC() then
                notification.AddLegacy( "Target: " .. aimtarget:GetClass() .. "", NOTIFY_HINT, 1 )
                notification.AddLegacy( "Health: " .. aimtarget:Health() .. "", NOTIFY_HINT, 1 )
                lol = 0
                end

                if aimtarget:IsPlayer() then
                notification.AddLegacy( "Target: " .. aimtarget:Name() .. " [" .. aimtarget:SteamID() .. "]", NOTIFY_HINT, 1 )
                notification.AddLegacy( "Health: " .. aimtarget:Health() .. " Armor: " .. aimtarget:Armor() .. "", NOTIFY_HINT, 1 )
                lol = 0
                end

                end
                end
end

	end

	if gBool("Aimbot", "Aimbot", "Target Info (DarkRP)") and wep:IsValid() then  
        lol = lol + 1
                --[[
		chat.AddText("Target: " .. aimtarget:Nick() .. "")
                chat.AddText("Health: " .. aimtarget:Health() .. "")
                chat.AddText("Armor: " .. aimtarget:Armor() .. "")
                ]]--

                if lol > 100 then
                if IsValid(aimtarget) then

                if aimtarget:IsNPC() then
                notification.AddLegacy( "Target: " .. aimtarget:GetClass() .. "", NOTIFY_HINT, 1 )
                notification.AddLegacy( "Health: " .. aimtarget:Health() .. "", NOTIFY_HINT, 1 )
                lol = 0
                end

                if aimtarget:IsPlayer() then
                notification.AddLegacy( "Target: " .. aimtarget:Nick() .. " [" .. aimtarget:SteamID() .. "]", NOTIFY_HINT, 1 )
                notification.AddLegacy( "Health: " .. aimtarget:Health() .. " Armor: " .. aimtarget:Armor() .. "", NOTIFY_HINT, 1 )
                lol = 0
                end

                end
                end

	end

local function SmoothAim(ang) 
	if gBool("Aimbot", "Aimbot", "Legit Mode") then
		ang.y = math.NormalizeAngle(ang.y) 	
		ang.p = math.NormalizeAngle(ang.p) 	
		eyeang = LocalPlayer():EyeAngles()

		local smooth = math.random(2,30)
		if((eyeang.y - ang.y) * - 1 > 180 && eyeang.y < 0) 
		then eyeang.y = eyeang.y + 360 end 	if((ang.y - eyeang.y) * - 1 > 180 && ang.y < 0) then ang.y = ang.y + 360 end 	
		eyeang.y = eyeang.y + (ang.y - eyeang.y) / smooth 	eyeang.x = eyeang.x + (ang.x - eyeang.x) / smooth 	eyeang.r = 0 	
		return eyeang else return ang

	end 
end

local function fuckinghell(cmd)

--print("okay? the function is being called")




	if gBool("Aimbot", "Aimbot", "Silent Aimbot") and gInt("Visuals", "Other", "Thirdperson") == 0 then
		if cmd:CommandNumber() == 0 then return end
	end

	gettarget()
	aa = false

	if gBool("Aimbot", "Aimbot", "Auto Stop") and aimtarget and check_alive(aimtarget) and aimtarget:IsValid() and aimkeycheck() then
		cmd:SetForwardMove(0)
		cmd:SetSideMove(0)
	end

	if gBool("Aimbot", "Aimbot", "Auto Crouch") and aimtarget and check_alive(aimtarget) and aimtarget:IsValid() and aimkeycheck() and not cmd:KeyDown(IN_DUCK) then
		cmd:SetButtons(cmd:GetButtons() + IN_DUCK)
	end

	if gBool("Aimbot", "Aimbot", "Auto Fire Secondary") and aimtarget and check_alive(aimtarget) and aimtarget:IsValid() and aimkeycheck() and not cmd:KeyDown(IN_ATTACK2) then
		cmd:SetButtons(cmd:GetButtons() + IN_ATTACK2)
	end

	--if aimtarget and check_alive(aimtarget) and aimtarget:IsValid() and aimkeycheck() and WeaponShootable() and WeaponCanFire() then
	if aimtarget and check_alive(aimtarget) and aimtarget:IsValid() and aimkeycheck() then
-- Incase
                --[[
                local pos = prediction(aimtarget) - em.EyePos(me) 
                local pos = GetPos(aimtarget) - em.EyePos(me)
                ]]--

                -- Cannot use prediction(aimtarget) for now. must use GetPos(aimtarget) until there is a fix
                --local pos = GetPos(aimtarget) - em.EyePos(me) 
                --local pos = (GetPos(aimtarget) - aimtarget:GetVelocity() / 170.5 - em:GetVelocity()/50) - em.EyePos(me)





		--local pos = GetPos(aimtarget) - em.EyePos(me) 
                --local ang = Angle( pos:Angle().p - math.Rand( -0.01, 0.01 ) , pos:Angle().y - math.Rand( -0.01, 0.01 ) , pos:Angle().r )
                --local ang = vm.Angle(PredictSpread(pCmd, vm.Angle(pos)))


                  local pos = prediction(aimtarget) - em.EyePos(me) 
                  local ang = Angle( vm.Angle(PredictSpread(pCmd, vm.Angle(pos))).p - math.Rand( -0.1, 0.1 ) , vm.Angle(PredictSpread(pCmd, vm.Angle(pos))).y - math.Rand( -0.1, 0.1 ) , pos:Angle().r )



		if gInt("Aimbot", "Aimbot", "Aimbot FOV") ~= 0 and gOption("Aimbot", "Other", "Priority") == "FOV" then
			for k,v in next, player.GetAll() do
				if not Valid(v) then continue end

				local CalcX = ang.x - fa.x
				local CalcY = ang.y - fa.y

				if CalcY < 0 then CalcY = CalcY * -1 end	
				if CalcX < 0 then CalcX = CalcX * -1 end
				if CalcY > 360 then CalcY = CalcY - 360 end
				if CalcX > 360 then CalcX = CalcX - 360 end
				if CalcY > 180 then CalcY = 360 - CalcY end
				if CalcX > 180 then CalcX = 360 - CalcX end

				if CalcX <= gInt("Aimbot","Aimbot","Aimbot FOV") and CalcY <= gInt("Aimbot","Aimbot","Aimbot FOV") then
					if gBool("Aimbot", "Aimbot", "Auto Fire") and not gBool("Hack vs Hack", "Anti-Aim", "Enabled") and not gBool("Hack vs Hack", "Anti-Aim Resolver", "Enabled") and not gBool("Misc", "Fake Lag", "Enabled") then
					end

					if gBool("Aimbot", "Aimbot", "Auto Fire") then
                                                if math.random(1,2) == 2 then
						cmd:SetButtons(IN_ATTACK)
                                                end
					end

					if gBool("Aimbot", "Aimbot", "Silent Aimbot") then
						FixMovement(cmd)
					else
						fa = ang
					end
					NormalizeAngle(ang)

		local ang = SmoothAim(ang)
		cm.SetViewAngles(cmd, ang)


                  -- At random times change your view angles very fast
                  if math.random(1,50) == 25 then
                  local randomang = ( Angle( LocalPlayer():EyeAngles().p - math.Rand( -0.25, 0.25 ) , LocalPlayer():EyeAngles().y - math.Rand( -0.25, 0.25 ) , LocalPlayer():EyeAngles().r ) )
                                        for i = 1,10 do
					NormalizeAngle(randomang)
					cmd:SetViewAngles(randomang)
                                        end
                  end

                  if math.random(1,200) == 100 then
                  local randomang = ( Angle( LocalPlayer():EyeAngles().p - math.Rand( -2.5, 0 ) , LocalPlayer():EyeAngles().y - math.Rand( -0.75, 0.75 ) , LocalPlayer():EyeAngles().r ) )
                                        for i = 1,20 do
                                        if math.random(1,6) == 3 then
					NormalizeAngle(randomang)
					cmd:SetViewAngles(randomang)
                                        end
                                        end
                  end



				else
					return
				end
			end
		else

			NormalizeAngle(ang)

		local ang = SmoothAim(ang)
		cm.SetViewAngles(cmd, ang)


                  -- At random times change your view angles very fast
                  if math.random(1,50) == 25 then
                  local randomang = ( Angle( LocalPlayer():EyeAngles().p - math.Rand( -0.25, 0.25 ) , LocalPlayer():EyeAngles().y - math.Rand( -0.25, 0.25 ) , LocalPlayer():EyeAngles().r ) )
                                        for i = 1,10 do
					NormalizeAngle(randomang)
					cmd:SetViewAngles(randomang)
                                        end
                  end

                  if math.random(1,200) == 100 then
                  local randomang = ( Angle( LocalPlayer():EyeAngles().p - math.Rand( -2.5, 0 ) , LocalPlayer():EyeAngles().y - math.Rand( -0.75, 0.75 ) , LocalPlayer():EyeAngles().r ) )
                                        for i = 1,20 do
                                        if math.random(1,6) == 3 then
					NormalizeAngle(randomang)
					cmd:SetViewAngles(randomang)
                                        end
                                        end
                  end



			if gBool("Aimbot", "Aimbot", "Auto Fire") and not gBool("Hack vs Hack", "Anti-Aim", "Enabled") and not gBool("Hack vs Hack", "Anti-Aim Resolver", "Enabled") and not gBool("Misc", "Fake Lag", "Enabled") then
			end

			if gBool("Aimbot", "Aimbot", "Auto Fire") then
                                if math.random(1,2) == 2 then
				cmd:SetButtons(cmd:GetButtons() + IN_ATTACK)
                                end
			end

			if gBool("Aimbot", "Aimbot", "Silent Aimbot") then
				FixMovement(cmd)
			else
				fa = ang
			end
		end
	end
	aa = true
end




	if gBool("Aimbot", "Aimbot", "Legit Mode") then
        fuckinghell(cmd)
	end


	if gBool("Hack vs Hack", "Anti-Aim", "Enabled") and wep:IsValid() and wep:GetClass() ~= "weapon_zm_carry" then
		antiaim(cmd)
	end

	if engine.ActiveGamemode() == "terrortown" and gOption("Gamemode", "TTT", "Prop Kill Key") ~= "Off" and wep:IsValid() and wep:GetClass() == "weapon_zm_carry" then
		propkill(cmd)
	end

	if oldAngles ~= cmd:GetViewAngles() then
		local x = cmd:GetViewAngles().x
	end
end)


addhook("entity_killed", function(data)
	if gOption("Misc", "Misc", "Spam after Kill") ~= "Off" then
		spam_kill(data)
	end

	if gBool("Misc", "Misc", "Log Kills in Chat") then
		death_log(data)
	end
end)

addhook("player_hurt", function(data)
	if gBool("Misc", "Misc", "Hitsound") then
		if data.attacker == me:UserID() then
			surface.PlaySound("buttons/button10.wav")
		end
	end
end)

addhook("player_hurt", function(data)
	if gBool("Misc", "Misc", "Hit Information") then
		if data.attacker == me:UserID() then
                        hitcount = hitcount + 1
                        timer.Create("lmaobox_resethitcount", 1, 1, function() hitcount = 0 end)
			notification.AddLegacy( "[LMAOBOX] HIT, Count: " .. hitcount .. ". HEALTH: " .. data.health .. "", NOTIFY_ERROR, 1.5 ) 
		end
	end
end)

addhook("player_disconnect", function(data)
	if gBool("Misc", "Misc", "Spam after Disconnect") then
		local name = data.name
		local steamid = data.networkid
		local quit = { "bruh, "..name.." deadass rq", "rq", "rekt", "owned", "noob rq, his steam: "..steamid }
		
		if (engine.ActiveGamemode() == "darkrp") then
			command("say /ooc "..quit[math.random(#quit)])
		else
			command("say "..quit[math.random(#quit)])
		end
	end
end)

addhook("ShouldDrawLocalPlayer", function()
	return gInt("Visuals", "Other", "Thirdperson") > 0
end)

addhook("PlayerFootstep", function()
	return gBool("Misc", "Misc", "Mute Footsteps")
end)


addhook("HUDPaint", function()

if gBool("Visuals", "ESP", "Simple Mode (optimization)") then

simpleesp()

end

end)






addhook("HUDPaint", function()
	if gBool("Visuals", "ESP", "Enabled") then


if gBool("Visuals", "ESP", "Anti-Screengrab (Safe Mode)") then
showesp = showesp + 1
--print("" .. showesp .. "")
if showesp > 40 then
	 esp()
showesp = 0

end

elseif gBool("Visuals", "ESP", "Anti-Screengrab (50/50 Not Safe)") then
showesp = math.random(1,11)
if showesp > 10.01 then
	 esp()
end

elseif gBool("Visuals", "ESP", "Anti-Screengrab (ON|OFF Not Safe)") then
showesp = showesp + 1
if showesp > 5 then
esp()
showesp = 0
end

else
esp()
end
		if propkeycheck() then
			if prop_val >= 180 then
				surface.DrawCircle(ScrW()/2, ScrH()/1.8, 80 + me:GetVelocity():Length()/4, AimCol)
			else
				surface.DrawCircle(ScrW()/2, ScrH()/1.8, 80 + me:GetVelocity():Length()/4, MenuCol)
			end

			--[[if prop_val >= 180 then
				if gOption("Gamemode", "TTT", "Prop Kill Status Indicator") == "3D Circle" or gOption("Gamemode", "TTT", "Prop Kill Status Indicator") == "2D and 3D" then
					cam.Start3D()
						if gOption("Gamemode", "TTT", "Prop Kill Status Indicator") == "3D Circle" then
							render.DrawWireframeSphere(me:GetEyeTrace().HitPos, 15 + me:GetVelocity():Length()/8, 5, 5, AimCol, false )
						else
							surface.DrawCircle(ScrW()/2, ScrH()/1.8, 80 + me:GetVelocity():Length()/4, AimCol)
							render.DrawWireframeSphere(me:GetEyeTrace().HitPos, 15 + me:GetVelocity():Length()/8, 5, 5, AimCol, false )
						end
					cam.End3D()
				else
					surface.DrawCircle(ScrW()/2, ScrH()/1.8, 80 + me:GetVelocity():Length()/4, AimCol)
				end
			else
				if gOption("Gamemode", "TTT", "Prop Kill Status Indicator") == "3D Circle" or gOption("Gamemode", "TTT", "Prop Kill Status Indicator") == "2D and 3D" then
					cam.Start3D()
						if gOption("Gamemode", "TTT", "Prop Kill Status Indicator") == "3D Circle" then
							render.DrawWireframeSphere(me:GetEyeTrace().HitPos, 15 + me:GetVelocity():Length()/8, 5, 5, MenuCol, false )
						else
							surface.DrawCircle(ScrW()/2, ScrH()/1.8, 80 + me:GetVelocity():Length()/4, MenuCol)
							render.DrawWireframeSphere(me:GetEyeTrace().HitPos, 15 + me:GetVelocity():Length()/8, 5, 5, MenuCol, false )
						end
					cam.End3D()
				else
					surface.DrawCircle(ScrW()/2, ScrH()/1.8, 80 + me:GetVelocity():Length()/4, MenuCol)
				end
			end]]
		end
	end





	if gInt("Settings", "Menu", "Darkness") > 0 and menuopen then
		surface.SetDrawColor(0,0,0,gInt("Settings", "Menu", "Darkness")*10)
		surface.DrawRect(0,0,ScrW(),ScrH())
	end
	if gOption("Visuals", "Other", "Spectating Player Alert") ~= "Off" then
		specalert()
	end
	if gBool("Visuals", "Other", "Crosshair") then
		crosshair()
	end
	if gBool("Visuals", "Radar", "Enabled") and me:Alive() and not (me:Team() == TEAM_SPECTATOR or me:Team() == TEAM_CONNECTING) then
		radar()
	end
	if gInt("Aimbot", "Aimbot", "Aimbot FOV") ~= 0 and draw_fov then
		aimfov()
	end
	if gBool("Visuals", "Player List", "Enabled") and menuopen and ScrW() >= 1600 or ScrH() >= 1400 then
		playerlist()
	end

	--[[if gBool("Settings", "Menu", "Enabled Features Notice") and CurTime() < ten_sec then
		local ten_sec_txt = 24

		draw.SimpleText("Enabled Features Notice: "..math["Round"](ten_sec - CurTime()), font(), ScrW()/2, ScrH()/1.8, MenuCol, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		if gBool("Aimbot", "Aimbot", "Enabled") then
			draw.SimpleText("Aimbot - FOV: "..gInt("Aimbot", "Aimbot", "Aimbot FOV"), font(), ScrW()/2, ScrH()/1.8+ten_sec_txt, MenuCol, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			ten_sec_txt = ten_sec_txt + 12
		end
		if gBool("Triggerbot", "Triggerbot", "Enabled") then
			draw.SimpleText("Triggerbot", font(), ScrW()/2, ScrH()/1.8+ten_sec_txt, MenuCol, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			ten_sec_txt = ten_sec_txt + 12
		end
		if gBool("Hack vs Hack", "Anti-Aim", "Enabled") then
			draw.SimpleText("Anti-Aim", font(), ScrW()/2, ScrH()/1.8+ten_sec_txt, MenuCol, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			ten_sec_txt = ten_sec_txt + 12
		end
		if gOption("Misc", "Misc", "Chat Spam") ~= "Off" then
			draw.SimpleText("Chat Spam - "..gOption("Misc", "Misc", "Chat Spam"), font(), ScrW()/2, ScrH()/1.8+ten_sec_txt, MenuCol, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			ten_sec_txt = ten_sec_txt + 12
		end
		if gOption("Misc", "Misc", "Spam after Kill") ~= "Off" then
			draw.SimpleText("Spam after Kill - "..gOption("Misc", "Misc", "Spam after Kill"), font(), ScrW()/2, ScrH()/1.8+ten_sec_txt, MenuCol, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			ten_sec_txt = ten_sec_txt + 12
		end
		if gBool("Misc", "Misc", "Spam after Disconnect") then
			draw.SimpleText("Spam after Disconnect", font(), ScrW()/2, ScrH()/1.8+ten_sec_txt, MenuCol, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			ten_sec_txt = ten_sec_txt + 12
		end
		if gBool("Misc", "Misc", "Spam after Cheater Callout") then
			draw.SimpleText("Spam after Cheater Callout", font(), ScrW()/2, ScrH()/1.8+ten_sec_txt, MenuCol, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			ten_sec_txt = ten_sec_txt + 12
		end
		draw.SimpleText("Features disabled during timer.", font(), ScrW()/2, ScrH()/1.8+ten_sec_txt+12, MenuCol, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end]]

	if gBool("Gamemode", "TTT", "Panel Remover") and removewindow then
		draw.SimpleText("Press \"G\" to remove this window.", font(), ScrW()/2, ScrH()/10, MenuCol, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end

	if gBool("Misc", "Other", "Debug Information") then
		draw.SimpleText("Build: "..version.."\t\tHealth: "..me:Health().."/"..me:GetMaxHealth().."\t\tVelocity: "..math["Round"](me:GetVelocity():Length()).."\t\tServer: "..GetHostName().."\t\tGamemode: "..engine.ActiveGamemode().."\t\tPlayers: "..player.GetCount().."/"..game.MaxPlayers().."\t\tMap: "..game.GetMap().."\t\tEntity: "..entityname().."\t\tEntities: "..math["Round"](ents.GetCount()-player.GetCount()*12).."\t\tFPS: "..math["Round"](1/FrameTime()).."\t\tPing: "..me:Ping().."\t\tDate: "..os.date("%d %b %Y").."\t\tTime: "..os.date("%H:%M:%S"), font(), 50, 15, Color(255,255,255), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
	end


if gBool("Misc", "Other", "Debug Information V2") then
		draw.SimpleText("WELCOME TO LMAOBOX " .. me:Name() .. "", "ArialB_Bigger", 50, 50, Color(255,255,255), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		draw.SimpleText("WE ARE AT BUILD: " .. version .. "", "ArialB_Big", 50, 75, Color(255,255,255), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		draw.SimpleText("HEALTH: " .. me:Health() .. " OUT OF " .. me:GetMaxHealth() .. "", "ArialB_Big", 50, 100, Color(255,255,255), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
                draw.SimpleText("VELOCITY: "..math["Round"](me:GetVelocity():Length()).."", "ArialB_Big", 50, 125, Color(255,255,255), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
                draw.SimpleText("SERVER WE'RE ON: " .. GetHostName() .. "", "ArialB_Big", 50, 150, Color(255,255,255), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
                draw.SimpleText("GAMEMODE: " .. engine.ActiveGamemode() .. "", "ArialB_Big", 50, 175, Color(255,255,255), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
                draw.SimpleText("PLAYERS: " .. player.GetCount() .. " OUT OF " .. game.MaxPlayers() .. "", "ArialB_Big", 50, 200, Color(255,255,255), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)



if math.random(1,50) == 25 then
lennfps = 0
lennfps = math["Round"](1/FrameTime())
end

                draw.SimpleText("FPS: " .. lennfps .. "", "ArialB_Big", 50, 225, Color(255,255,255), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
                draw.SimpleText("PING: " .. me:Ping() .. "", "ArialB_Big", 50, 250, Color(255,255,255), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
                draw.SimpleText("TICKRATE: " .. ( 1 / engine.ServerFrameTime() ) .. "", "ArialB_Big", 50, 275, Color(255,255,255), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)

                draw.SimpleText("PITCH: " .. me:EyeAngles().x .. "", "ArialB_Big", 50, 350, Color(255,255,255), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
                draw.SimpleText("YAW: " .. me:EyeAngles().y .. "", "ArialB_Big", 50, 375, Color(255,255,255), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)


                draw.SimpleText("LOOKING AT ENTITY: " .. entityname() .. "", "ArialB_Big", 50, 450, Color(255,255,255), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
                draw.SimpleText("CHOKING PACKETS: " .. faketick .. "", "ArialB_Big", 50, 475, Color(255,255,255), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
                draw.SimpleText("MADE BY OFFICIAL LMAOBOX DEVELOPER", "ArialB_Big", 50, 500, Color(255,255,255), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)


local tickrate = ( 1 / engine.ServerFrameTime() )
if tickrate > 20 and tickrate < 33 then
                draw.SimpleText("SERVER LAG: MINIMAL", "ArialB_Big", 50, 300, Color(255,255,255), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
end
if tickrate > 33 then
                draw.SimpleText("SERVER LAG: NONE", "ArialB_Big", 50, 300, Color(255,255,255), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
end
if tickrate > 10.01 and tickrate < 19.99 then
                draw.SimpleText("SERVER LAG: MEDIUM", "ArialB_Big", 50, 300, Color(255,255,255), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
end
if tickrate < 10 and tickrate > 5.01 then
                draw.SimpleText("SERVER LAG: PRETTY BAD", "ArialB_Big", 50, 300, Color(255,255,255), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
end
if tickrate < 5 and tickrate > 2.11 then
                draw.SimpleText("SERVER LAG: BAD", "ArialB_Big", 50, 300, Color(255,255,255), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
end
if tickrate < 2.1 then
                draw.SimpleText("SERVER LAG: VERY BAD", "ArialB_Big", 50, 300, Color(255,255,255), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
end


if me:EyeAngles().x < -89 then
                draw.SimpleText("FAKE ANGLES PITCH: YEAH (up real, down fake)", "ArialB_Big", 50, 400, Color(255,255,255), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
elseif me:EyeAngles().x > 89.1 then
                draw.SimpleText("FAKE ANGLES PITCH: YEAH (down real, up or center fake)", "ArialB_Big", 50, 400, Color(255,255,255), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
else
                draw.SimpleText("FAKE ANGLES PITCH: NOPE", "ArialB_Big", 50, 400, Color(255,255,255), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
end



	end






end)

addhook("CalcView", function(me, pos, ang, fov)
	if me:Alive() then
		if gInt("Visuals", "Other", "Custom FOV") ~= 0 and gInt("Visuals", "Other", "Thirdperson") == 0 and me:Alive() then
			local view = {}
			view.origin = pos
			view.angles = angles

			view.fov = 60 + gInt("Visuals", "Other", "Custom FOV")

			if gBool("Aimbot", "Aimbot", "Predict Recoil") and me:GetMoveType() ~= MOVETYPE_OBSERVER then
				view.origin = me:EyePos()
				view.angles = me:EyeAngles()
			end

			return view
		else
			local view = {}
			view.angles = GetAngle(fa)
			view.origin = gInt("Visuals", "Other", "Thirdperson") ~= 0 and pos + Angle(fa):Forward() * (gInt("Visuals", "Other", "Thirdperson") * -10) or pos

			return view
		end
	end
end)

addhook("OnPlayerChat", function(player, text, team, dead)
	if gBool("Misc", "Other", "Let TTS read chat") and player:SteamID64() ~= steam then
		command("stopsound")
		sound.PlayURL("http://translate.google.com/translate_tts?ie=UTF-8&client=tw-ob&q="..player:Nick().." says, "..text.."&tl=en", "mono", function(chan, num, str) boy = chan end)
	end

	if gBool("Misc", "Misc", "Spam after Cheater Callout") and player ~= me and player:GetFriendStatus() ~= "friend" then
		if string.find(string.lower(text), "walls") or string.find(string.lower(text), "hax") or string.find(string.lower(text), "script") or string.find(string.lower(text), "idiotbox") or string.find(string.lower(text), "lmaobox") or string.find(string.lower(text), "lua") or string.find(string.lower(text), "bunny") or string.find(string.lower(text), "hop") or string.find(string.lower(text), "cheat") or string.find(string.lower(text), "esp") or string.find(string.lower(text), "hack") or string.find(string.lower(text), "bot") or string.find(string.lower(text), "aim") then
			if engine.ActiveGamemode() == "darkrp" then
				ChatClear.OOC()
			else
				ChatClear.Run()
			end
		end
	end
end)

addhook("PreDrawOpaqueRenderables", function() -- or "RenderScene"
	if gBool("Hack vs Hack", "Anti-Aim Resolver", "Enabled") and gBool("Aimbot", "Aimbot", "Auto Fire") then
		for k,v in next, player.GetAll() do
			if not aa_Valid(v) then continue end

			if gBool("Hack vs Hack", "Anti-Aim Resolver", "Rage Targets Only") then
				if not table.HasValue(priority_list, v:UniqueID()) then continue end
			end

			local pitch = v:EyeAngles().x
			local yaw = v:EyeAngles().y
			local roll = 0

                        --print("" .. v:Nick() .. "'s pitch: " .. v:EyeAngles().x .. "")

			if gOption("Hack vs Hack", "Anti-Aim Resolver", "Pitch") ~= "Off" then
				if gOption("Hack vs Hack", "Anti-Aim Resolver", "Pitch") == "Up" then
					pitch = -90
				elseif gOption("Hack vs Hack", "Anti-Aim Resolver", "Pitch") == "BrutoForcePitch" then
                                        pitch = math.sin(CurTime()*60/8)*60
                                        print("[LMAOBOX]: brutoforce mode (pitch) enabled")
				elseif gOption("Hack vs Hack", "Anti-Aim Resolver", "Pitch") == "BrutoForcePitch_v2" then
                                        pitch = math.sin(CurTime()*120/8)*60
                                        print("[LMAOBOX]: brutoforce mode (pitch_v2) enabled")
				elseif gOption("Hack vs Hack", "Anti-Aim Resolver", "Pitch") == "Down" then
					pitch = 90
				elseif gOption("Hack vs Hack", "Anti-Aim Resolver", "Pitch") == "Center" then
					pitch = 0
				elseif gOption("Hack vs Hack", "Anti-Aim Resolver", "Pitch") == "Invert" then
					pitch = -pitch
				elseif gOption("Hack vs Hack", "Anti-Aim Resolver", "Pitch") == "Random" then
					pitch = math.random(-90,90)
				elseif gOption("Hack vs Hack", "Anti-Aim Resolver", "Pitch") == "AutoHVH" then
print("" .. v:Nick() .. " " .. v:EyeAngles().x .. " " .. v:EyeAngles().y .. "")
						if pitch > 88 and pitch < 89.9 then
						pitch = -89
                                        print("[LMAOBOX AutoHVH]: " .. v:Nick() .. " resolved to 90 pitch (up) info: LOOKING DOWN. BUT MAY BE UP --> " .. v:EyeAngles().x .. "")
					end
                                                -- yeah it just has to be 271 for a reason.
						if pitch > 200 and pitch < 280  then
						pitch = 89
                                        print("[LMAOBOX AutoHVH]: " .. v:Nick() .. " resolved to 90 pitch (down) info: LOOKING UP. BUT MAY BE DOWN --> " .. v:EyeAngles().x .. "")
					end
						if pitch > -179 then
						pitch = -89
                                        print("[LMAOBOX AutoHVH]: " .. v:Nick() .. " resolved to 90 pitch (up) info: LOOKING DOWN (v2). BUT MAY BE UP --> " .. v:EyeAngles().x .. "")
					end
					if pitch > -20 and pitch < 20  then
						pitch = math.sin(CurTime()*60/8)*60
                                        print("[LMAOBOX AutoHVH]: " .. v:Nick() .. " resolved to random spinning pitch (up and down) info: LOOKING CENTER, BUT MAY BE UP OR DOWN --> " .. v:EyeAngles().x .. "")
					end
					if pitch > 180 and pitch < 270  then
						pitch = 90
                                        print("[LMAOBOX AutoHVH]: " .. v:Nick() .. " resolved to 90 pitch (down) info: ILLEGAL EYE ANGLES EXCEED 179 --> " .. v:EyeAngles().x .. "")
					end
					if pitch > -180 and pitch < -270  then
						pitch = -90
                                        print("[LMAOBOX AutoHVH]: " .. v:Nick() .. " resolved to 90 pitch (up) info: ILLEGAL EYE ANGLES EXCEED -179 --> " .. v:EyeAngles().x .. "")
					end

--[[
					if pitch > -178 and pitch < -89.001  then
						pitch = 90
                                        print("[LMAOBOX AutoHVH]: " .. v:Nick() .. " resolved to 90 pitch (down) info: EYE ANGLES EXCEED LIMITS --> " .. v:EyeAngles().x .. "")
					end
					if pitch > 89.001 and pitch < 178  then
						pitch = -90
                                        print("[LMAOBOX AutoHVH]: " .. v:Nick() .. " resolved to 90 pitch (up) info: EYE ANGLES EXCEED LIMITS --> " .. v:EyeAngles().x .. "")
					end
]]--
				else


					if pitch <= 20 and pitch >= -10 then
						pitch = 90
                                        print("[LMAOBOX]: " .. v:Nick() .. " resolved to 90 pitch (up) info: " .. v:EyeAngles().x .. "")
					end




-- pitch resolver method 2.0





--[[

											if(pitch >= 89 && pitch < 180 && pitch != 181 && pitch ) then
													pitch = 89
                                                                                                        print("[LMAOBOX]: " .. v:Nick() .. " resolved to 89 pitch (up) info: " .. v:EyeAngles().x .. "")
											elseif(pitch >= 181) then
                                                                                                        print("[LMAOBOX]: " .. v:Nick() .. " resolved to -89 pitch (down) info: " .. v:EyeAngles().y .. "")
													pitch = -89
											end


]]--



				end
			end

			if gOption("Hack vs Hack", "Anti-Aim Resolver", "Yaw") ~= "Off" then
				if gOption("Hack vs Hack", "Anti-Aim Resolver", "Yaw") == "Invert" then
					yaw = yaw + 180
				elseif gOption("Hack vs Hack", "Anti-Aim Resolver", "Yaw") == "BrutoForceYaw" then
					yaw = yaw + 180 + math.sin(CurTime()*11.25)*90
                                        print("[LMAOBOX]: brutoforce mode (yaw) enabled")
				elseif gOption("Hack vs Hack", "Anti-Aim Resolver", "Yaw") == "BrutoForceYaw_v2" then
					yaw = yaw + 180 + math.sin(CurTime()*22.5)*90
                                        print("[LMAOBOX]: brutoforce mode (yaw_v2) enabled")
				elseif gOption("Hack vs Hack", "Anti-Aim Resolver", "Yaw") == "LegitAA" then
					yaw = yaw + math.sin(CurTime()*11.25)*90
				elseif gOption("Hack vs Hack", "Anti-Aim Resolver", "Yaw") == "-90" then
					yaw = yaw - 90
				elseif gOption("Hack vs Hack", "Anti-Aim Resolver", "Yaw") == "+90" then
					yaw = yaw + 90
				elseif gOption("Hack vs Hack", "Anti-Aim Resolver", "Yaw") == "Random" then
					yaw = math.random(-180, 180)
				elseif gOption("Hack vs Hack", "Anti-Aim Resolver", "Yaw") == "beta_AutoHVH" then
					yaw = yaw + math.random(90,180)
                                elseif gOption("Hack vs Hack", "Anti-Aim Resolver", "Yaw") == "JustSpin" then
                                yaw = CurTime() * (20*23) % 350, 1
                                elseif gOption("Hack vs Hack", "Anti-Aim Resolver", "Yaw") == "AutoHVH" then


                                if math.random(1,6) == 3 then
                                yaw = yaw - 90
                                end

                                if math.random(1,6) == 3 then
                                yaw = yaw + 90
                                end

                                if math.random(1,3) == 1 then
                                yaw = yaw + 180
                                end
                                




				elseif gOption("Hack vs Hack", "Anti-Aim Resolver", "Yaw") == "AutoHVH (horrible edition)" then
                                       -- better to just use the original (Auto) for yaw instead of this dumbass shit I decided to make incase there are cheaters that don't use (LUA) to change their angles


                                       -- fuckman123
                                        --print("" .. v:Nick() .. ": " .. v:EyeAngles().y .. " " .. yaw .. "")
 



                                        if yaw > 85 and yaw < 95 then

                                        local aidsv1 = {
                                        "90",
                                        "-100"
                                        }
 
                                        yaw = yaw + table.Random(aidsv1)





                                        print("[LMAOBOX AUTOHVH]: " .. v:Nick() .. " resolved to random yaw switching (right, left) info: " .. v:EyeAngles().y .. "")
                                        end


                                        if yaw > 269 and yaw < 271 then

                                        local aidsv2 = {
                                        "90",
                                        "-100"
                                        }
 
                                        yaw = yaw + table.Random(aidsv2)





                                        print("[LMAOBOX AUTOHVH]: " .. v:Nick() .. " resolved to random yaw switching (right, left) info: " .. v:EyeAngles().y .. "")
                                        end

                                        if yaw > 175 and yaw < 185 then

                                        local aidsv3 = {
                                        "90",
                                        "-90"
                                        }
 
                                        yaw = yaw + table.Random(aidsv3)





                                        print("[LMAOBOX AUTOHVH]: " .. v:Nick() .. " resolved to random yaw switching (right, left) info: " .. v:EyeAngles().y .. "")
                                        end










					--yaw = yaw + 180
				else
					--[[if not yaw_auto then
						yaw = yaw + 180
					else
						yaw = yaw
					end

					if CurTime() > yaw_timer then
						yaw_timer = CurTime() + 2.5
						yaw_auto = not yaw_auto
					end]]

					roll = v:EyeAngles().z
				end
			end


			v:SetPoseParameter("aim_pitch", math.NormalizeAngle(pitch))
			v:SetPoseParameter("head_pitch", math.NormalizeAngle(pitch))

			v:SetPoseParameter("body_yaw", 0)
			v:SetPoseParameter("aim_yaw", 0)

			v:SetRenderAngles(Angle(0, math.NormalizeAngle(yaw) + math.NormalizeAngle(roll), 0))
			v:InvalidateBoneCache()
		end
	end




	if gBool("Hack vs Hack", "Anti-Aim", "Enabled") then
		--me:SetRenderAngles(Angle(0, me:EyeAngles().y, 0))
	end
	if gBool("Hack vs Hack", "Anti-Aim", "Better AA Render") then
	me:SetRenderAngles(Angle(0, me:EyeAngles().y, 0))
	end
	if gBool("Hack vs Hack", "Anti-Aim", "Stupid Indicator") then
        fakechamremove = 0

        if math.random(1,10) == 5 then
        indicatoraa()
        end

        else

        fakechamremove = 1
        end


function indicatoraa( ply )
timer.Create("indicatoraa_lmaobox", 0, 0, function() 
	local fakecham = ents.CreateClientProp()

	fakecham:SetPos( LocalPlayer():GetPos() )
	fakecham:SetModel( "models/player/kleiner.mdl" )
        fakecham:SetMaterial( "models/wireframe")


        local yawang = LocalPlayer():GetAngles().y
        local pitchang = LocalPlayer():GetAngles().x
        --print("pitch: " .. pitchang .. " yaw: " .. yawang .. "")


if gOption("Hack vs Hack", "Anti-Aim", "Yaw") == "ResolveBreak" then
        fakecham:SetRenderAngles( Angle(0, yawang + 0 ) )
elseif gOption("Hack vs Hack", "Anti-Aim", "Yaw") == "Fake-Semi-Spin" then
        fakecham:SetRenderAngles( Angle(0, yawang + 0 ) )
else
        fakecham:SetRenderAngles( Angle(0, yawang + -180 ) )
end

         
        --print("" .. LocalPlayer():EyeAngles() .. "")
        --fakecham:SetColor( Color( 0, 178, 178 ) )
        fakecham:SetColor( Color( 0, 255, 63 ) )
	--fakecham:SetParent( ply )
        -- 5
        fakecham:SetSequence( 4 )
	fakecham:Spawn()
  
timer.Simple(0.025, function() if fakecham:IsValid() then fakecham:Remove() end end)

if fakechamremove == 1 then
if fakecham:IsValid() then
fakecham:Remove()
end
end

end)
end





	if gBool("Misc", "Fake Lag", "Lag Chams") then
        if gInt("Misc", "Fake Lag", "Density") == 14 then
	fakelagchamspawned = 0

function fakelagcham( ply )
	local fakelagcham = ents.CreateClientProp()
	fakelagcham:SetPos( LocalPlayer():GetPos() )
	fakelagcham:SetModel( "models/player/kleiner.mdl" )
        fakelagcham:SetMaterial( "models/shiny")



        local yawang = LocalPlayer():GetAngles().y
        local pitchang = LocalPlayer():GetAngles().x
        --print("pitch: " .. pitchang .. " yaw: " .. yawang .. "")


        fakelagcham:SetRenderAngles( Angle(0, yawang + 0 ) )

         
        --print("" .. LocalPlayer():EyeAngles() .. "")
	--fakelagcham:SetParent( ply )
        -- 5
        fakelagcham:SetColor( Color( 255, 0, 63 ) )
        fakelagcham:SetSequence( 4 )
	fakelagcham:Spawn()
        timer.Simple(0.5, function() fakelagcham:Remove()  fakelagchamspawned = fakelagchamspawned - 1 end)


end


if faketick > 13 then
fakelagcham()
end


	end
end













	if gBool("Misc", "Fake Lag", "Lag Chams") then
        if gInt("Misc", "Fake Lag", "Density") == 15 then
	fakelagchamspawned = 0

function fakelagcham( ply )
	local fakelagcham = ents.CreateClientProp()
	fakelagcham:SetPos( LocalPlayer():GetPos() )
	fakelagcham:SetModel( "models/player/kleiner.mdl" )
        fakelagcham:SetMaterial( "models/shiny")



        local yawang = LocalPlayer():GetAngles().y
        local pitchang = LocalPlayer():GetAngles().x
        --print("pitch: " .. pitchang .. " yaw: " .. yawang .. "")


        fakelagcham:SetRenderAngles( Angle(0, yawang + 0 ) )

         
        --print("" .. LocalPlayer():EyeAngles() .. "")
	--fakelagcham:SetParent( ply )
        -- 5
        fakelagcham:SetColor( Color( 255, 0, 63 ) )
        fakelagcham:SetSequence( 4 )
	fakelagcham:Spawn()
        timer.Simple(0.5, function() fakelagcham:Remove()  fakelagchamspawned = fakelagchamspawned - 1 end)


end


if faketick > 14 then
fakelagcham()
end


	end
end


























if gBool("Misc", "Fake Lag", "Lag Chams") then
        if gInt("Misc", "Fake Lag", "Density") == 13 then
	fakelagchamspawned = 0

function fakelagcham( ply )
	local fakelagcham = ents.CreateClientProp()
	fakelagcham:SetPos( LocalPlayer():GetPos() )
	fakelagcham:SetModel( "models/player/kleiner.mdl" )
        fakelagcham:SetMaterial( "models/shiny")



        local yawang = LocalPlayer():GetAngles().y
        local pitchang = LocalPlayer():GetAngles().x
        --print("pitch: " .. pitchang .. " yaw: " .. yawang .. "")


        fakelagcham:SetRenderAngles( Angle(0, yawang + 0 ) )

         
        --print("" .. LocalPlayer():EyeAngles() .. "")
	--fakelagcham:SetParent( ply )
        -- 5
        fakelagcham:SetColor( Color( 255, 0, 63 ) )
        fakelagcham:SetSequence( 4 )
	fakelagcham:Spawn()
        timer.Simple(0.5, function() fakelagcham:Remove()  fakelagchamspawned = fakelagchamspawned - 1 end)


end


if faketick > 12 then
fakelagcham()
end


	end
end

if gBool("Misc", "Fake Lag", "Lag Chams") then
        if gInt("Misc", "Fake Lag", "Density") == 12 then
	fakelagchamspawned = 0

function fakelagcham( ply )
	local fakelagcham = ents.CreateClientProp()
	fakelagcham:SetPos( LocalPlayer():GetPos() )
	fakelagcham:SetModel( "models/player/kleiner.mdl" )
        fakelagcham:SetMaterial( "models/shiny")



        local yawang = LocalPlayer():GetAngles().y
        local pitchang = LocalPlayer():GetAngles().x
        --print("pitch: " .. pitchang .. " yaw: " .. yawang .. "")


        fakelagcham:SetRenderAngles( Angle(0, yawang + 0 ) )

         
        --print("" .. LocalPlayer():EyeAngles() .. "")
	--fakelagcham:SetParent( ply )
        -- 5
        fakelagcham:SetColor( Color( 255, 0, 63 ) )
        fakelagcham:SetSequence( 4 )
	fakelagcham:Spawn()
        timer.Simple(0.5, function() fakelagcham:Remove()  fakelagchamspawned = fakelagchamspawned - 1 end)


end


if faketick > 11 then
fakelagcham()
end


	end
end

if gBool("Misc", "Fake Lag", "Lag Chams") then
        if gInt("Misc", "Fake Lag", "Density") == 11 then
	fakelagchamspawned = 0

function fakelagcham( ply )
	local fakelagcham = ents.CreateClientProp()
	fakelagcham:SetPos( LocalPlayer():GetPos() )
	fakelagcham:SetModel( "models/player/kleiner.mdl" )
        fakelagcham:SetMaterial( "models/shiny")



        local yawang = LocalPlayer():GetAngles().y
        local pitchang = LocalPlayer():GetAngles().x
        --print("pitch: " .. pitchang .. " yaw: " .. yawang .. "")


        fakelagcham:SetRenderAngles( Angle(0, yawang + 0 ) )

         
        --print("" .. LocalPlayer():EyeAngles() .. "")
	--fakelagcham:SetParent( ply )
        -- 5
        fakelagcham:SetColor( Color( 255, 0, 63 ) )
        fakelagcham:SetSequence( 4 )
	fakelagcham:Spawn()
        timer.Simple(0.5, function() fakelagcham:Remove()  fakelagchamspawned = fakelagchamspawned - 1 end)


end


if faketick > 10 then
fakelagcham()
end


	end
end

if gBool("Misc", "Fake Lag", "Lag Chams") then
        if gInt("Misc", "Fake Lag", "Density") == 10 then
	fakelagchamspawned = 0

function fakelagcham( ply )
	local fakelagcham = ents.CreateClientProp()
	fakelagcham:SetPos( LocalPlayer():GetPos() )
	fakelagcham:SetModel( "models/player/kleiner.mdl" )
        fakelagcham:SetMaterial( "models/shiny")



        local yawang = LocalPlayer():GetAngles().y
        local pitchang = LocalPlayer():GetAngles().x
        --print("pitch: " .. pitchang .. " yaw: " .. yawang .. "")


        fakelagcham:SetRenderAngles( Angle(0, yawang + 0 ) )

         
        --print("" .. LocalPlayer():EyeAngles() .. "")
	--fakelagcham:SetParent( ply )
        -- 5
        fakelagcham:SetColor( Color( 255, 0, 63 ) )
        fakelagcham:SetSequence( 4 )
	fakelagcham:Spawn()
        timer.Simple(0.5, function() fakelagcham:Remove()  fakelagchamspawned = fakelagchamspawned - 1 end)


end


if faketick > 9 then
fakelagcham()
end


	end
end


if gBool("Misc", "Fake Lag", "Lag Chams") then
        if gInt("Misc", "Fake Lag", "Density") == 9 then
	fakelagchamspawned = 0

function fakelagcham( ply )
	local fakelagcham = ents.CreateClientProp()
	fakelagcham:SetPos( LocalPlayer():GetPos() )
	fakelagcham:SetModel( "models/player/kleiner.mdl" )
        fakelagcham:SetMaterial( "models/shiny")



        local yawang = LocalPlayer():GetAngles().y
        local pitchang = LocalPlayer():GetAngles().x
        --print("pitch: " .. pitchang .. " yaw: " .. yawang .. "")


        fakelagcham:SetRenderAngles( Angle(0, yawang + 0 ) )

         
        --print("" .. LocalPlayer():EyeAngles() .. "")
	--fakelagcham:SetParent( ply )
        -- 5
        fakelagcham:SetColor( Color( 255, 0, 63 ) )
        fakelagcham:SetSequence( 4 )
	fakelagcham:Spawn()
        timer.Simple(0.5, function() fakelagcham:Remove()  fakelagchamspawned = fakelagchamspawned - 1 end)


end


if faketick > 8 then
fakelagcham()
end


	end
end



if gBool("Misc", "Fake Lag", "Lag Chams") then
        if gInt("Misc", "Fake Lag", "Density") == 8 then
	fakelagchamspawned = 0

function fakelagcham( ply )
	local fakelagcham = ents.CreateClientProp()
	fakelagcham:SetPos( LocalPlayer():GetPos() )
	fakelagcham:SetModel( "models/player/kleiner.mdl" )
        fakelagcham:SetMaterial( "models/shiny")



        local yawang = LocalPlayer():GetAngles().y
        local pitchang = LocalPlayer():GetAngles().x
        --print("pitch: " .. pitchang .. " yaw: " .. yawang .. "")


        fakelagcham:SetRenderAngles( Angle(0, yawang + 0 ) )

         
        --print("" .. LocalPlayer():EyeAngles() .. "")
	--fakelagcham:SetParent( ply )
        -- 5
        fakelagcham:SetColor( Color( 255, 0, 63 ) )
        fakelagcham:SetSequence( 4 )
	fakelagcham:Spawn()
        timer.Simple(0.5, function() fakelagcham:Remove()  fakelagchamspawned = fakelagchamspawned - 1 end)


end


if faketick > 7 then
fakelagcham()
end


	end
end

if gBool("Misc", "Fake Lag", "Lag Chams") then
        if gInt("Misc", "Fake Lag", "Density") == 6 then
	fakelagchamspawned = 0

function fakelagcham( ply )
	local fakelagcham = ents.CreateClientProp()
	fakelagcham:SetPos( LocalPlayer():GetPos() )
	fakelagcham:SetModel( "models/player/kleiner.mdl" )
        fakelagcham:SetMaterial( "models/shiny")



        local yawang = LocalPlayer():GetAngles().y
        local pitchang = LocalPlayer():GetAngles().x
        --print("pitch: " .. pitchang .. " yaw: " .. yawang .. "")


        fakelagcham:SetRenderAngles( Angle(0, yawang + 0 ) )

         
        --print("" .. LocalPlayer():EyeAngles() .. "")
	--fakelagcham:SetParent( ply )
        -- 5
        fakelagcham:SetColor( Color( 255, 0, 63 ) )
        fakelagcham:SetSequence( 4 )
	fakelagcham:Spawn()
        timer.Simple(0.5, function() fakelagcham:Remove()  fakelagchamspawned = fakelagchamspawned - 1 end)


end


if faketick > 5 then
fakelagcham()
end


	end
end

if gBool("Misc", "Fake Lag", "Lag Chams") then
        if gInt("Misc", "Fake Lag", "Density") == 5 then
	fakelagchamspawned = 0

function fakelagcham( ply )
	local fakelagcham = ents.CreateClientProp()
	fakelagcham:SetPos( LocalPlayer():GetPos() )
	fakelagcham:SetModel( "models/player/kleiner.mdl" )
        fakelagcham:SetMaterial( "models/shiny")



        local yawang = LocalPlayer():GetAngles().y
        local pitchang = LocalPlayer():GetAngles().x
        --print("pitch: " .. pitchang .. " yaw: " .. yawang .. "")


        fakelagcham:SetRenderAngles( Angle(0, yawang + 0 ) )

         
        --print("" .. LocalPlayer():EyeAngles() .. "")
	--fakelagcham:SetParent( ply )
        -- 5
        fakelagcham:SetColor( Color( 255, 0, 63 ) )
        fakelagcham:SetSequence( 4 )
	fakelagcham:Spawn()
        timer.Simple(0.5, function() fakelagcham:Remove()  fakelagchamspawned = fakelagchamspawned - 1 end)


end


if faketick > 4 then
fakelagcham()
end


	end
end

if gBool("Misc", "Fake Lag", "Lag Chams") then
        if gInt("Misc", "Fake Lag", "Density") == 3 then
	fakelagchamspawned = 0

function fakelagcham( ply )
	local fakelagcham = ents.CreateClientProp()
	fakelagcham:SetPos( LocalPlayer():GetPos() )
	fakelagcham:SetModel( "models/player/kleiner.mdl" )
        fakelagcham:SetMaterial( "models/shiny")



        local yawang = LocalPlayer():GetAngles().y
        local pitchang = LocalPlayer():GetAngles().x
        --print("pitch: " .. pitchang .. " yaw: " .. yawang .. "")


        fakelagcham:SetRenderAngles( Angle(0, yawang + 0 ) )

         
        --print("" .. LocalPlayer():EyeAngles() .. "")
	--fakelagcham:SetParent( ply )
        -- 5
        fakelagcham:SetColor( Color( 255, 0, 63 ) )
        fakelagcham:SetSequence( 4 )
	fakelagcham:Spawn()
        timer.Simple(0.5, function() fakelagcham:Remove()  fakelagchamspawned = fakelagchamspawned - 1 end)


end


if faketick > 2 then
fakelagcham()
end


	end
end


-- Dynamic and Counter-Dynamic


if gBool("Misc", "Fake Lag", "Lag Chams") then
        local opt = gOption("Misc", "Fake Lag", "Mode")
	if opt == "Counter-Dynamic" then
	fakelagchamspawned = 0

function fakelagcham( ply )
	local fakelagcham = ents.CreateClientProp()
	fakelagcham:SetPos( LocalPlayer():GetPos() )
	fakelagcham:SetModel( "models/player/kleiner.mdl" )
        fakelagcham:SetMaterial( "models/shiny")



        local yawang = LocalPlayer():GetAngles().y
        local pitchang = LocalPlayer():GetAngles().x
        --print("pitch: " .. pitchang .. " yaw: " .. yawang .. "")


        fakelagcham:SetRenderAngles( Angle(0, yawang + 0 ) )

         
        --print("" .. LocalPlayer():EyeAngles() .. "")
	--fakelagcham:SetParent( ply )
        -- 5
        fakelagcham:SetColor( Color( 255, 0, 63 ) )
        fakelagcham:SetSequence( 4 )
	fakelagcham:Spawn()
        timer.Simple(0.5, function() fakelagcham:Remove()  fakelagchamspawned = fakelagchamspawned - 1 end)


end


                if fakelagcham_check > vels then 
                fakelagcham()
                fakelagcham_check = 0
                end


	end
end


if gBool("Misc", "Fake Lag", "Lag Chams") then
        local opt = gOption("Misc", "Fake Lag", "Mode")
	if opt == "Dynamic" then
	fakelagchamspawned = 0

function fakelagcham( ply )
	local fakelagcham = ents.CreateClientProp()
	fakelagcham:SetPos( LocalPlayer():GetPos() )
	fakelagcham:SetModel( "models/player/kleiner.mdl" )
        fakelagcham:SetMaterial( "models/shiny")



        local yawang = LocalPlayer():GetAngles().y
        local pitchang = LocalPlayer():GetAngles().x
        --print("pitch: " .. pitchang .. " yaw: " .. yawang .. "")


        fakelagcham:SetRenderAngles( Angle(0, yawang + 0 ) )

         
        --print("" .. LocalPlayer():EyeAngles() .. "")
	--fakelagcham:SetParent( ply )
        -- 5
        fakelagcham:SetColor( Color( 255, 0, 63 ) )
        fakelagcham:SetSequence( 4 )
	fakelagcham:Spawn()
        timer.Simple(0.5, function() fakelagcham:Remove()  fakelagchamspawned = fakelagchamspawned - 1 end)


end

                velocities = me:GetVelocity():Length()
                if velocities > 0 and velocities < 250 then
                if fakelagcham_check > 13 then fakelagcham() fakelagcham_check = 0 end
                end 
                if velocities > 0 and velocities < 250 then
                if fakelagcham_check > 12 then fakelagcham() fakelagcham_check = 0 end
                end 
                if velocities > 250 and velocities < 400 then                
                if fakelagcham_check > 11 then fakelagcham() fakelagcham_check = 0 end
                end 
                if velocities > 400 and velocities < 600 then
                if fakelagcham_check > 10 then fakelagcham() fakelagcham_check = 0 end
                end 
                if velocities > 600 and velocities < 800 then
                if fakelagcham_check > 9 then fakelagcham() fakelagcham_check = 0 end
                end 
                if velocities > 800 and velocities < 1000 then
                if fakelagcham_check > 8 then fakelagcham() fakelagcham_check = 0 end
                end 
                if velocities > 1000 and velocities < 1200 then
                if fakelagcham_check > 7 then fakelagcham() fakelagcham_check = 0 end
                end 
                if velocities > 1200 and velocities < 1400 then
                if fakelagcham_check > 6 then fakelagcham() fakelagcham_check = 0 end
                end 
                if velocities > 1400 and velocities < 1600 then
                if fakelagcham_check > 5 then fakelagcham() fakelagcham_check = 0 end
                end 
                if velocities > 1600 and velocities < 1800 then
                if fakelagcham_check > 4 then fakelagcham() fakelagcham_check = 0 end
                end 
                if velocities > 1800 and velocities < 2000 then
                if fakelagcham_check > 3 then fakelagcham() fakelagcham_check = 0 end
                end 
                if velocities > 2000 and velocities < 3000 then
                if fakelagcham_check > 2 then fakelagcham() fakelagcham_check = 0 end
                end 
                if velocities > 3000 then
                if fakelagcham_check > 1 then fakelagcham() fakelagcham_check = 0 end
                end 


	end
end














if gBool("Hack vs Hack", "Anti-Aim", "Follow Tracer") then


function followtracer( ply )
	local followtracer = ents.CreateClientProp()
	followtracer:SetPos( LocalPlayer():GetPos() )
	followtracer:SetModel( "models/hunter/blocks/cube025x025x025.mdl" )
        followtracer:SetMaterial( "models/wireframe")

         
        --print("" .. LocalPlayer():EyeAngles() .. "")
        followtracer:SetColor( Color( 0, 255, 63 ) )

	followtracer:Spawn()
        timer.Simple(1, function() if followtracer:IsValid() then followtracer:Remove() end end)




end

followtracer()


--chat.AddText("fake chams enabled: red is followtracer")


	end


end)

--[[addhook("PreDrawPlayerHands", function()
	return gBool("Visuals", "Viewmodel", "Hide Hands")
end)

local Weapon = CreateMaterial("Weapon", "VertexLitGeneric", {
	["$basetexture"] = "models/debug/debugwhite",
	["$color2"] = {1, 1, 1},
})

local function Condition(condition, t, f)
	if (condition) then
		return t
	else
		return f
	end
end

addhook("PreDrawViewModel", function(vm, me, wep)
	if gBool("Visuals", "Viewmodel", "Hide Weapon") then
		render.MaterialOverrideByIndex(0, Condition(true, Material("tools/toolsnodraw"), nil))
	end
end)]]

do
	config_colors()
end

-- incase

function render.Capture()
print("Fucked potential screengrab function render.Capture")
return "fuck you"
end

function render.SetRenderTarget()
--print("Fucked potential screengrab function render.SetRenderTarget")
return "fuck you"
end

function render.CapturePixels()
print("Fucked potential screengrab function render.CapturePixels")
return "fuck you"
end

function util.Compress()
print("Fucked potential screengrab function util.Compress")
return "fuck you"
end

function util.Base64Encode()
print("Fucked potential screengrab function util.Base64Encode")
return "fuck you"
end

function quality()
print("Fucked potential screengrab function quality")
return "fuck you"
end


-- Libby stuff


function rendercapture()
print("Libby / Iced Coffees NSA screengrab fucked (rendercapture)")
return "fuck you"
end


function utilcompress()
print("Libby / Iced Coffees NSA screengrab fucked (utilcompress)")
return "fuck you"
end


function utilbase64encode()
print("Libby / Iced Coffees NSA screengrab fucked (utilbase64encode)")
return "fuck you"
end

quality = 0.000000000000000000000000000001

RunConsoleCommand("sg_optout","1")


surface.CreateFont("SegoeUI_big", { font = "Segoe UI", size = 40, weight = 1500, antialias = false, outline = true })
hook.Add("HUDPaint","lmaobox_losingconnectionwarning", function()

if didtheservercrash > 20 then
connectionlasttime = 48
draw.SimpleText( "I think we just lost connection to the server. Time since last connection: " .. connectionlasttime .. "", "SegoeUI_big", ScrW() /2 +math.random(-1,1), ScrH() /4 +math.random(-1,1) +64, Color(255, 152, 255), TEXT_ALIGN_CENTER)
end

end)

--[[
hook.Add("Tick","fuckshit_test", function()


nextcurtime = nextcurtime + 1



approximatetickrate = ( 1 / engine.ServerFrameTime() )
print("" .. approximatetickrate .. "")


if nextcurtime > 100 then

if nextcurtime > 150 then

if math.random(1,10) == 5 then
if approximatetickrate == ( 1 / engine.ServerFrameTime() ) then
didtheservercrash = didtheservercrash + 1
print("??? lost connection ??? " .. didtheservercrash .. "")

end
end
end

nextcurtime = 0

end
end)
]]--





-- Could use this tmrw 9/17/2021 (connection lost check thingy i must make) ( me():Ping()/ 950 )


-- Anti-chatspam for Libby

timer.Create("fuckoff_antichatspam", 0.1, 0, function()
chatcounts = 0
tries = 999
end)





