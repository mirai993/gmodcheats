chat.AddText(Color(255,0,255),"##",Color(0,255,255),"[FMurder]!")
chat.AddText(Color(255,0,255),"##",Color(0,255,255),"Made by FusionXNova")
chat.AddText(Color(255,0,255),"##",Color(0,255,255),"<3 MPGH")

FMurder_Version = "BETA v0.21"
local FMurder = {
WHLoot = false,
WHPlayer = false,
BunnyHop = false,
Aimbot = false,
Aimbot_AutoAim = false,
Aimbot_AutoShoot = false,
Aimbot_IsFiring = false,
}

FMurder.BoneTable = {}
FMurder.BoneTable[1]="ValveBiped.Bip01_Head1"
FMurder.BoneTable[2]="ValveBiped.Bip01_Neck1"
FMurder.BoneTable[3]="ValveBiped.Bip01_Spine4"
FMurder.BoneTable[4]="ValveBiped.Bip01_Spine2"
FMurder.BoneTable[5]="ValveBiped.Bip01_Spine1"
FMurder.BoneTable[6]="ValveBiped.Bip01_Spine"
FMurder.BoneTable[7]="ValveBiped.Bip01_R_UpperArm"
FMurder.BoneTable[8]="ValveBiped.Bip01_R_Forearm"
FMurder.BoneTable[9]="ValveBiped.Bip01_R_Hand"
FMurder.BoneTable[10]="ValveBiped.Bip01_L_UpperArm"
FMurder.BoneTable[11]="ValveBiped.Bip01_L_Forearm"
FMurder.BoneTable[12]="ValveBiped.Bip01_L_Hand"
FMurder.BoneTable[13]="ValveBiped.Bip01_R_Thigh"
FMurder.BoneTable[14]="ValveBiped.Bip01_R_Calf"
FMurder.BoneTable[15]="ValveBiped.Bip01_R_Foot"
FMurder.BoneTable[16]="ValveBiped.Bip01_R_Toe0"
FMurder.BoneTable[17]="ValveBiped.Bip01_L_Thigh"
FMurder.BoneTable[18]="ValveBiped.Bip01_L_Calf"
FMurder.BoneTable[19]="ValveBiped.Bip01_L_Foot"
FMurder.BoneTable[20]="ValveBiped.Bip01_L_Toe0"






DAH_MAT = CreateMaterial(tostring(math.random(-100007700,10000770)/2), "VertexLitGeneric", { ["$basetexture"] = "models/debug/debugwhite", ["$model"] = 1, ["$ignorez"] = 1 })


local function GetMurderer()
	for k,v in pairs(player.GetAll()) do
		for l,b in pairs(v:GetWeapons()) do
			if(b:GetClass() == "weapon_mu_knife") then
				local col = v:GetPlayerColor() or Vector()
				col = Color(col.x * 255, col.y * 255, col.z * 255)
				col.a = 255
				return v, col
			end
		end
	end
end

local function GetSecret()
	for k,v in pairs(player.GetAll()) do
		for l,b in pairs(v:GetWeapons()) do
			if(b:GetClass() == "weapon_mu_magnum") then
				local col = v:GetPlayerColor() or Vector()
				col = Color(col.x * 255, col.y * 255, col.z * 255)
				col.a = 255
				return v, col
			end
		end
	end
end
--SHOW MURDERER IN CHAT
function FMurder.ShowInChat()
	local murderer, murderercolor = GetMurderer()
	chat.AddText(Color(0,255,255),"[FMurder] ",murderercolor,murderer:Name() .. ", " .. murderer:GetBystanderName(),Color(255,255,255), " is the murderer!")
	local secret, secretcolor = GetSecret()
	chat.AddText(Color(0,255,255),"[FMurder] ",secretcolor,secret:Name() .. ", " .. secret:GetBystanderName(),Color(255,255,255), " has a secret weapon!")
end
--ONROUNDSTART
net.Receive("chattext_msg", function (len)
	local msgs = {}
		while true do
		local i = net.ReadUInt(8)
		if i == 0 then break end
		local str = net.ReadString()
		local col = net.ReadVector()
		table.insert(msgs, Color(col.x, col.y, col.z))
		table.insert(msgs, str)
	end
	if(msgs[2] == "A new round has started") then
		timer.Create(tostring(math.random(-1000000,1000000)),2,1,function()
			FMurder.ShowInChat()
		end)
	end
	chat.AddText(unpack(msgs))
end)
--WALLHACK
hook.Add("RenderScreenspaceEffects",tostring(math.random(-1000000,1000000)-1),function()
	if(FMurder.WHLoot == 0 or FMurder.WHPlayer == 0) then return false end
	cam.Start3D()
	cam.IgnoreZ(true)
	render.SuppressEngineLighting(true)
	render.SetModelLighting(4,255,255,255)
	render.MaterialOverride(DAH_MAT)
	--START PLAYER WH
	if(FMurder.WHPlayer) then
	for k,ply in pairs(player.GetAll()) do
		if(ply:Health() > 0) then
		local hasknife=false
		local hasmagnum=false
		for k0,weapon in pairs(ply:GetWeapons()) do
			if(weapon:GetClass() == "weapon_mu_knife") then
				hasknife=true
			end
			if(weapon:GetClass() == "weapon_mu_magnum") then
				hasmagnum=true
			end
		end
		if(hasknife) then
		render.SetColorModulation(1,0,0)
		ply:DrawModel()
		elseif(hasmagnum) then
		render.SetColorModulation(0,0,1)
		ply:DrawModel()
		else
		render.SetColorModulation(1,1,1)
		ply:DrawModel()
		end
		end
	end
	end
	--ENDPLAYERWH
	--STARTLOOTWH
	if(FMurder.WHLoot) then
		for k, ent in pairs(ents.FindByClass("mu_loot")) do
			render.SetColorModulation(0,1,0)
			ent:DrawModel()
		end
	end
	--ENDLOOTWH
	cam.IgnoreZ(false)
	render.SuppressEngineLighting(false)
	cam.End3D()
end)
--MENU


local FM_isOpen = false
hook.Add("Think",tostring(math.random(-999999999,9999999999)),function()
	if(!input.IsKeyDown(KEY_INSERT)) then return end
	if(FM_isOpen == true) then return end
	FM_isOpen = true
	local FMurderPanel = vgui.Create( "DFrame" )
	FMurderPanel:SetPos(ScrW()/2-200,ScrH()/2-200)
	FMurderPanel:SetSize(400,400)
	FMurderPanel:SetTitle("FMurder " .. FMurder_Version)
	FMurderPanel:SetVisible(true)
	FMurderPanel:SetDraggable(true)
	FMurderPanel:ShowCloseButton(true)
	FMurderPanel.OnClose = function()
		FM_isOpen = false
	end
	FMurderPanel:MakePopup()
	
	local FM_PropertySheet = vgui.Create( "DPropertySheet" )
	FM_PropertySheet:SetParent(FMurderPanel)
	FM_PropertySheet:SetPos(5,22)
	FM_PropertySheet:SetSize(FMurderPanel:GetWide()-10,FMurderPanel:GetTall()-27)
	
	local FM_Hacks = vgui.Create( "DPanelList" )
	FM_Hacks:SetPos(5,5)
	FM_Hacks:SetSpacing(2)
	FM_Hacks:SetSize(385,368)
	FM_Hacks:EnableVerticalScrollbar(true)
	FM_Hacks:EnableHorizontal(false)
	--Start Chams Menu
	local FM_Chams_Collapsible = vgui.Create( "DCollapsibleCategory" , FM_Hacks)
	FM_Chams_Collapsible:SetPos(0,0)
	FM_Chams_Collapsible:SetSize(375,500)
	FM_Chams_Collapsible:SetExpanded(false)
	FM_Chams_Collapsible:SetLabel("Chams")
	FM_Hacks:AddItem(FM_Chams_Collapsible)
	
	local FM_Chams_List = vgui.Create( "DPanelList" , FM_Chams_Collapsible)
	FM_Chams_List:SetAutoSize(true)
	FM_Chams_List:SetSpacing(5)
	FM_Chams_List:EnableVerticalScrollbar(true)
	FM_Chams_List:EnableHorizontal(false)
	FM_Chams_List.Paint = function()
		draw.RoundedBox(2,0,0,FM_Chams_List:GetWide(),FM_Chams_List:GetTall(),Color(0,0,0,128))
	end
	FM_Chams_Collapsible:SetContents(FM_Chams_List)
	
	local FM_PlayerChams = vgui.Create( "DCheckBoxLabel" , FM_Chams_List)
	FM_PlayerChams:SetText("Player Chams")
	FM_PlayerChams:SetSize(100,20)
	FM_PlayerChams:SetValue(WHPlayer)
	FM_PlayerChams.OnChange = function(self, value)
		if(value) then FMurder.WHPlayer=true else FMurder.WHPlayer=false end
	end
	FM_Chams_List:AddItem(FM_PlayerChams)
	
	local FM_LootChams = vgui.Create( "DCheckBoxLabel" , FM_Chams_List)
	FM_LootChams:SetText("Loot Chams")
	FM_LootChams:SetSize(100,20)
	FM_LootChams:SetValue(WHLoot)
	FM_LootChams.OnChange = function(self, value)
		if(value) then FMurder.WHLoot=true else FMurder.WHLoot=false end
	end
	FM_Chams_List:AddItem(FM_PlayerChams)
	--End Chams Menu
	--
	--
	--Start Player Cheats Menu
	local FM_Player_Collapsible = vgui.Create( "DCollapsibleCategory" , FM_Hacks)
	FM_Player_Collapsible:SetPos(0,0)
	FM_Player_Collapsible:SetSize(375,500)
	FM_Player_Collapsible:SetExpanded(false)
	FM_Player_Collapsible:SetLabel("Player Cheats")
	FM_Hacks:AddItem(FM_Player_Collapsible)
	
	local FM_Player_List = vgui.Create( "DPanelList" , FM_Player_Collapsible)
	FM_Player_List:SetAutoSize(true)
	FM_Player_List:SetSpacing(5)
	FM_Player_List:EnableVerticalScrollbar(true)
	FM_Player_List:EnableHorizontal(false)
	FM_Player_List.Paint = function()
		draw.RoundedBox(2,0,0,FM_Player_List:GetWide(),FM_Player_List:GetTall(),Color(0,0,0,128))
	end
	FM_Player_Collapsible:SetContents(FM_Player_List)
	
	local FM_BunnyHop = vgui.Create( "DCheckBoxLabel" , FM_Player_List)
	FM_BunnyHop:SetText("BunnyHop")
	FM_BunnyHop:SetSize(100,20)
	FM_BunnyHop:SetValue(BunnyHop)
	FM_BunnyHop.OnChange = function(self, value)
		if(value) then FMurder.BunnyHop=true else FMurder.BunnyHop=false end
	end
	FM_Player_List:AddItem(FM_BunnyHop)
	--End Player Cheats Menu
	--
	--
	--Start Aimbot Menu
	local FM_Aimbot_Collapsible = vgui.Create( "DCollapsibleCategory" , FM_Hacks)
	FM_Aimbot_Collapsible:SetPos(0,0)
	FM_Aimbot_Collapsible:SetSize(375,500)
	FM_Aimbot_Collapsible:SetExpanded(false)
	FM_Aimbot_Collapsible:SetLabel("Aimbot")
	FM_Hacks:AddItem(FM_Aimbot_Collapsible)
	
	local FM_Aimbot_List = vgui.Create( "DPanelList" , FM_Aimbot_Collapsible)
	FM_Aimbot_List:SetAutoSize(true)
	FM_Aimbot_List:SetSpacing(5)
	FM_Aimbot_List:EnableVerticalScrollbar(true)
	FM_Aimbot_List:EnableHorizontal(false)
	FM_Aimbot_List.Paint = function()
		draw.RoundedBox(2,0,0,FM_Aimbot_List:GetWide(),FM_Aimbot_List:GetTall(),Color(0,0,0,128))
	end
	FM_Aimbot_Collapsible:SetContents(FM_Aimbot_List)
	
	local FM_Aimbot = vgui.Create( "DCheckBoxLabel" , FM_Aimbot_List)
	FM_Aimbot:SetText("Aimbot")
	FM_Aimbot:SetSize(100,20)
	FM_Aimbot:SetValue(Aimbot)
	FM_Aimbot.OnChange = function(self, value)
		if(value) then FMurder.Aimbot=true else FMurder.Aimbot=false end
	end
	FM_Aimbot_List:AddItem(FM_Aimbot)
	
	local FM_Aimbot_AutoShoot = vgui.Create( "DCheckBoxLabel" , FM_Aimbot_List)
	FM_Aimbot_AutoShoot:SetText("AutoShoot")
	FM_Aimbot_AutoShoot:SetSize(100,20)
	FM_Aimbot_AutoShoot:SetValue(Aimbot_AutoShoot)
	FM_Aimbot_AutoShoot.OnChange = function(self, value)
		if(value) then FMurder.Aimbot_AutoShoot=true else FMurder.Aimbot_AutoShoot=false end
	end
	FM_Aimbot_List:AddItem(FM_Aimbot_AutoShoot)
	
	
	FM_PropertySheet:AddSheet("Hacks",FM_Hacks,"icon16/application_xp_terminal.png",false,false,"Choose hacks etc.")
	
	
end)

hook.Add("CreateMove",tostring(math.random(-999999999,9999999999)),function(cmd)
	if(FMurder.BunnyHop or FMurder.Aimbot) then local ply = LocalPlayer() end
	if(FMurder.BunnyHop) then
		if(cmd:KeyDown(IN_JUMP)) then
			if(ply:IsOnGround()) then
				cmd:SetButtons(cmd:GetButtons() , IN_JUMP)
			elseif(!ply:IsOnGround()) then
				cmd:SetButtons(cmd:GetButtons()-IN_JUMP)
			end
		end
	end
	if(FMurder.Aimbot) then
		ply=LocalPlayer()
		local murderer, murderercolor = GetMurderer()
		if(murderer== nil) then return end
		local murdererbonepos
		local murdererboneangle
		local tracesuccessful = false
		for k,v in pairs(FMurder.BoneTable) do
			local murdererbone = murderer:LookupBone(v)
			murdererbonepos, murdererboneangle = murderer:GetBonePosition(murdererbone)
				local tracedata = {
				start=ply:GetShootPos(),
				endpos=murdererbonepos,
				filter=ply
				}
				local trace = util.TraceLine(tracedata)
				if(trace.HitNonWorld) then
					if(trace.Entity == murderer) then
						tracesuccessful = true
						break
					end
				end
		end
		if(tracesuccessful and !(LocalPlayer():Health() <= 0) and LocalPlayer():GetActiveWeapon():GetClass() == "weapon_mu_magnum") then
			local aimangle = (Vector(murdererbonepos.x,murdererbonepos.y,murdererbonepos.z) - ply:GetShootPos()):Angle()
			aimangle = Angle(aimangle.pitch,aimangle.yaw,aimangle.roll)
			cmd:SetViewAngles(aimangle)
			if(FMurder.Aimbot_AutoShoot) then
				if(!FMurder.Aimbot_IsFiring) then
					RunConsoleCommand("+attack")
					FMurder.Aimbot_IsFiring=true
				else
					RunConsoleCommand("-attack")
					FMurder.Aimbot_IsFiring=false
				end
			end
		else
			if(FMurder.Aimbot_IsFiring) then
				RunConsoleCommand("-attack")
			end
		end
	end
end)


