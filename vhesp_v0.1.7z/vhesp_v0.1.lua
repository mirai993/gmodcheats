--[[
	esp.lua
	This Toast is traitor | (STEAM_0:0:43676365)
	===DStream===
]]

if not (CLIENT) then return end
print([[
 ________
| vHEsp  |
|________|
]])
local ver = "0.1"
local namealign = 0
local aimmodels
aimmodels = {
        ["models/combine_scanner.mdl"] = "Scanner.Body",
        ["models/hunter.mdl"] = "MiniStrider.body_joint",
        ["models/combine_turrets/floor_turret.mdl"] = "Barrel",
        ["models/dog.mdl"] = "Dog_Model.Eye",
        ["models/antlion.mdl"] = "Antlion.Body_Bone",
        ["models/antlion_guard.mdl"] = "Antlion_Guard.Body",
        ["models/antlion_worker.mdl"] = "Antlion.Head_Bone",
        ["models/zombie/fast_torso.mdl"] = "ValveBiped.HC_BodyCube",
        ["models/zombie/fast.mdl"] = "ValveBiped.HC_BodyCube",
        ["models/headcrabclassic.mdl"] = "HeadcrabClassic.SpineControl",
        ["models/headcrabblack.mdl"] = "HCBlack.body",
        ["models/headcrab.mdl"] = "HCFast.body",
        ["models/zombie/poison.mdl"] = "ValveBiped.Headcrab_Cube1",
        ["models/zombie/classic.mdl"] = "ValveBiped.HC_Body_Bone",
        ["models/zombie/classic_torso.mdl"] = "ValveBiped.HC_Body_Bone",
        ["models/zombie/zombie_soldier.mdl"] = "ValveBiped.HC_Body_Bone",
        ["models/combine_strider.mdl"] = "Combine_Strider.Body_Bone",
        ["models/lamarr.mdl"] = "HeadcrabClassic.SpineControl"
}
local function HeadPos(ply) 
    if ValidEntity(ply) then 
if (ply:GetClass()=="npc_tripmine") && (ply:GetClass()=="npc_satchel") && (ply:GetClass()=="npc_grenade_frag") then
return false
end
local pos
local usingAttachments
	if ( ply:GetAttachment( ply:LookupAttachment( "eyes" ) ) ) then
		pos = ply:GetAttachment( ply:LookupAttachment( "eyes" ) ).Pos;
	elseif ( ply:GetAttachment( ply:LookupAttachment( "forward" ) ) ) then
		pos = ply:GetAttachment( ply:LookupAttachment("forward") ).Pos;
	elseif ( ply:GetAttachment( ply:LookupAttachment( "head" ) ) ) then
		pos = ply:GetAttachment( ply:LookupAttachment( "head" ) ).Pos;
	else
	local bone = (aimmodels[ ply:GetModel() ] or "ValveBiped.Bip01_Head1")
	local hbone = ply:LookupBone(bone) 
        pos = ply:GetBonePosition(hbone) 
	end
	return pos
    else return end 
end
function OnEntityCreated( ent )
if ValidEntity(ent) then
     if ( (ent:GetClass() == "npc_tripmine") or (ent:GetClass() == "npc_satchel")) then
          chat.AddText( Color(255,0,0,255),"[vHEsp] ",Color(0,255,255,255)," Planted a SLAM." )
     end
end
end
hook.Add("OnEntityCreated","OnEntityCreated",OnEntityCreated)
function GAMEMODE:PlayerAuthed( ply, stid, unid )
if ply:IsAdmin() or ply:IsSuperAdmin() then
	chat.AddText(Color(255,0,0,255),"[vHEsp]",Color(255,255,0,255)," Admin ",Color(0,255,255,255),ply:Name(),Color(0,0,255,255)," ("..stid.." - "..unid..") ",Color(255,255,255,255)," is connected.")
else 
	chat.AddText(Color(255,0,0,255),"[vHEsp]",Color(255,255,0,255)," Player ",Color(0,255,255,255),ply:Name(),Color(0,0,255,255)," ("..stid.." - "..unid..") ",Color(255,255,255,255)," is connected.")
end
end
local function Visible(ply) 
    local trace = {start = LocalPlayer():GetShootPos(),endpos = HeadPos(ply),filter = {LocalPlayer(), ply}} 
    local tr = util.TraceLine(trace) 
	local u = LocalPlayer():GetCurrentCommand( )
		if (u:GetButtons() & IN_ATTACK > 0) then
		--[[if tr.MatType == 87 then
		local trace2 = {start = (tr.HitPos*2),endpos = HeadPos(ply),filter = {LocalPlayer(), ply}} 
		local tr2 = util.TraceLine(trace) 
		if tr2.Fraction == 1 then 
        return true 
		else 
		local trace3 = {start = (tr.HitPos/2),endpos = HeadPos(ply),filter = {LocalPlayer(), ply}} 
		local tr3 = util.TraceLine(trace) 
		if tr3.Fraction == 1 then 
        return true 
		else 
        return false 
		end 
		end
	return true		
	end]]--
	--return true
	end
if tr.Fraction == 1 then 
return true 
else
	return false
end    
end
local function box( e )
	local ply, pos = LocalPlayer(), nil
	local center = e:LocalToWorld( e:OBBCenter() )
	local min, max = e:OBBMins(), e:OBBMaxs()
	local dim = max - min
	local z = max + min
	
	local frt	= ( e:GetForward() ) * ( dim.y / 2 )
	local rgt	= ( e:GetRight() ) * ( dim.x / 2 )
	local top	= ( e:GetUp() ) * ( dim.z / 2 )
	local bak	= ( e:GetForward() * -1 ) * ( dim.y / 2 )
	local lft	= ( e:GetRight() * -1 ) * ( dim.x / 2 )
	local btm	= ( e:GetUp() * -1 ) * ( dim.z / 2 )
	
	local d, v = math.Round( e:GetPos():Distance( ply:GetShootPos() ) )
	v = d / 30
	
	pos = e:LocalToWorld( top + top ) + Vector( 0, 0, v + 10 )
	if ( e:IsWeapon() ) then pos = e:LocalToWorld( e:OBBCenter() ) end
	
	local FRT 	= center + frt + rgt + top; FRT = FRT:ToScreen()
	local BLB 	= center + bak + lft + btm; BLB = BLB:ToScreen()
	local FLT	= center + frt + lft + top; FLT = FLT:ToScreen()
	local BRT 	= center + bak + rgt + top; BRT = BRT:ToScreen()
	local BLT 	= center + bak + lft + top; BLT = BLT:ToScreen()
	local FRB 	= center + frt + rgt + btm; FRB = FRB:ToScreen()
	local FLB 	= center + frt + lft + btm; FLB = FLB:ToScreen()
	local BRB 	= center + bak + rgt + btm; BRB = BRB:ToScreen()
	
	pos = pos:ToScreen()
	
	local maxX = math.max( FRT.x,BLB.x,FLT.x,BRT.x,BLT.x,FRB.x,FLB.x,BRB.x )
	local minX = math.min( FRT.x,BLB.x,FLT.x,BRT.x,BLT.x,FRB.x,FLB.x,BRB.x )
	local maxY = math.max( FRT.y,BLB.y,FLT.y,BRT.y,BLT.y,FRB.y,FLB.y,BRB.y)
	local minY = math.min( FRT.y,BLB.y,FLT.y,BRT.y,BLT.y,FRB.y,FLB.y,BRB.y )
	
	return maxX, minX, maxY, minY
end
local cppweaps = {}
cppweaps["weapon_357"] = true
cppweaps["weapon_smg1"] = true
cppweaps["weapon_ar2"] = true
cppweaps["weapon_shotgun"] = true
cppweaps["weapon_pistol"] = true
cppweaps["weapon_crossbow"] = true
cppweaps["weapon_rpg"] = true
local cppweapsrec = {}
cppweapsrec["weapon_357"] = 0.8
cppweapsrec["weapon_smg1"] = 1
cppweapsrec["weapon_ar2"] = 1.03
cppweapsrec["weapon_shotgun"] = 1
cppweapsrec["weapon_pistol"] = 1
cppweapsrec["weapon_crossbow"] = 1

local function anglepunch()
if (!(LocalPlayer():GetActiveWeapon() == nil) && ValidEntity(LocalPlayer():GetActiveWeapon())) then
if cppweaps[LocalPlayer():GetActiveWeapon():GetClass()] then
return (((LocalPlayer():GetPunchAngle( )) or Angle(0,0,0))*(cppweapsrec[LocalPlayer():GetActiveWeapon():GetClass()] or 0.8))
else
return Angle(0,0,0)
end
else
return Angle(0,0,0)
end
end

local function validtarget(entz)
if !ValidEntity(entz) then return false end
for k,v in pairs(dontaim) do
if entz:GetClass() == v then return false end
end
if entz:IsPlayer() then if checkteam(entz) then else return false end end
if !(entz:IsPlayer() or entz:IsNPC()) then return false end
if entz == LocalPlayer() then return false end
if !Visible(entz) then return false end
if entz:IsPlayer() then if !(entz:Alive()) then return false end end
if entz:GetMoveType() == MOVETYPE_NONE then return false end
return true
end
local function validtargetesp(entz)
if !(entz:IsPlayer() or entz:IsNPC()) then return false end
if entz == LocalPlayer() then return false end
if entz:IsNPC() then 
if entz.IsDead == true then
return false
end
if entz:GetMoveType() == MOVETYPE_NONE then return false end
if entz:IsPlayer() then if entz:Health() < 1 then return false end end
if entz:IsNPC() then if entz.IsDead == true then return false end end
if entz:GetMoveType() == MOVETYPE_NONE then return false end
return true
end
end
local function validtarget2(entz)
if !ValidEntity(entz) then return false end
if !(entz:IsPlayer() or entz:IsNPC()) then return false end
if entz == LocalPlayer() then return false end
if entz:IsNPC() then 
if entz.IsDead == true then
return false
end
end
if entz:IsPlayer() then if entz:Health() < 1 then return false end end
if entz:IsPlayer() then if !checkteam(entz) then return false end end
if entz:IsNPC() then if entz.IsDead == true then return false end end
return true
end
local cppweaps = {}
cppweaps["weapon_357"] = true
cppweaps["weapon_smg1"] = true
cppweaps["weapon_ar2"] = true
cppweaps["weapon_shotgun"] = true
cppweaps["weapon_pistol"] = true
cppweaps["weapon_crossbow"] = true
cppweaps["weapon_rpg"] = true
local cppweapsrec = {}
cppweapsrec["weapon_357"] = 0.8
cppweapsrec["weapon_smg1"] = 1
cppweapsrec["weapon_ar2"] = 1.03
cppweapsrec["weapon_shotgun"] = 1
cppweapsrec["weapon_pistol"] = 1
cppweapsrec["weapon_crossbow"] = 1
local function anglepunch()
if (!(LocalPlayer():GetActiveWeapon() == nil) && ValidEntity(LocalPlayer():GetActiveWeapon())) then
if cppweaps[LocalPlayer():GetActiveWeapon():GetClass()] then
return (((LocalPlayer():GetPunchAngle( )) or Angle(0,0,0))*(cppweapsrec[LocalPlayer():GetActiveWeapon():GetClass()] or 0.8))
else
return Angle(0,0,0)
end
else
return Angle(0,0,0)
end
end
local PredictWeapons = {
		["weapon_crossbow"] = 3110,
	}

local function WeaponPrediction( e, pos )
	local ply = LocalPlayer()
	if ( ValidEntity( e ) && ( type( e:GetVelocity() ) == "Vector" ) ) then
	if ValidEntity(ply:GetActiveWeapon()) then
		local dis, wep = e:GetPos():Distance( ply:GetPos() ), ply:GetActiveWeapon():GetClass()
		if ( wep && PredictWeapons[ wep ]  ) then
			local t = (dis / 3500) + 0.05
					local mul = 0.0075
					local pos = ( pos + e:GetVelocity() * t )
			pos = pos - (e:GetVelocity() * mul)
			local crossbowspeed = (LocalPlayer():GetCurrentCommand():GetViewAngles()):Forward() * 3500
			local time2crossbow = (pos:Length() - LocalPlayer():GetPos():Length() )/(((crossbowspeed):Length()) - ((e:GetVelocity()):Length()))
			pos.z = pos.z
			return pos
		end
	end
	end
	return pos
end
local function prediction( tar, compensate )
	local ply = LocalPlayer()
		local tarFrames, plyFrames = ( FrameTime() / 25 ), ( FrameTime() / 66 )
		return compensate + ( (( (tar:GetVelocity()) * ( tarFrames ) )or Vector(0,0,0)) - ( (ply:GetVelocity()) * ( plyFrames ) or Vector(0,0,0)) )
		--return compensate + tar:GetVelocity() * (1/66) - LocalPlayer():GetVelocity() * (1/66)
end
local function drawesp() 
		if input.IsKeyDown( KEY_SPACE ) then
			if LocalPlayer():IsOnGround() then
			RunConsoleCommand("+Jump") 
			timer.Create("Bhop",0.01, 0 ,function() RunConsoleCommand("-Jump") end)
			end
		end
                    local textData = {} 
                    textData.pos = {} 
                    textData.pos[1] = 10; 
                    textData.pos[2] = 10; 
                    textData.color = drawColor; 
                    textData.text = "vHESP "..ver 
                    textData.font = "DefaultFixed"; 
                    textData.xalign = TEXT_ALIGN_LEFT; 
                    textData.yalign = TEXT_ALIGN_CENTER; 
                    draw.Text( textData ); 
        for k, v in pairs(ents.GetAll()) do 
            if( ValidEntity(v) and v ~= LocalPlayer() ) then
                if( v:IsNPC() ) then 
--[[				if validtargetesp(v) then
                    local drawColor = Color(255, 255, 255, 255); 
                    local drawPosit = v:GetPos():ToScreen(); 
                    local vis = ""
                    if( Visible(v) ) then 
						vis = "Visible"
                        drawColor = Color( 255, 0, 0, 255 ); 
                    else 
						vis = "Invisible"
                        drawColor = Color( 0, 255, 255, 255 ); 
                    end
					drawColor = Color( 255, 255, 0, 255 ); 
					surface.SetDrawColor(drawColor)
					local head = HeadPos(v):ToScreen()
					local maxX, minX, maxY, minY = box(v)
					local lol = maxY-minY
					local minz, maxz = v:OBBMins(), v:OBBMaxs()
					minz = (v:GetPos()+minz):ToScreen()
					maxz = (v:GetPos()+maxz):ToScreen()
					surface.DrawLine( maxX, maxY, maxX, minY )
					surface.DrawLine( maxX, minY, minX, minY )
					
					surface.DrawLine( minX, minY, minX, maxY )
					surface.DrawLine( minX, maxY, maxX, maxY )

                    local textData = {} 
                     
                    textData.pos = {} 
                    textData.pos[1] = drawPosit.x; 
                    textData.pos[2] = maxY+10; 
                    textData.color = drawColor; 
                    textData.text = v:GetClass(); 
                    textData.font = "DefaultFixed"; 
                    textData.xalign = TEXT_ALIGN_CENTER; 
                    textData.yalign = TEXT_ALIGN_CENTER; 
                    draw.Text( textData ); 
                    textData.pos = {}
					end]]--
					elseif( v:IsPlayer() and v:Health() > 0 and v:Alive() ) then 
					local textData = {} 
					 textData.pos = {} 
                    local drawColor = team.GetColor(v:Team()); 
                    local drawPosit = v:GetPos():ToScreen(); 
                    local targetheadpos = HeadPos(v)
					targetheadpos = WeaponPrediction( v, targetheadpos )
					targetheadpos = prediction( v, targetheadpos )
					targetheadpos = targetheadpos:ToScreen()
					surface.SetDrawColor(Color(255,0,0,255))
					surface.DrawLine( targetheadpos.x-10, targetheadpos.y, targetheadpos.x+10, targetheadpos.y )
					surface.DrawLine( targetheadpos.x, targetheadpos.y-10, targetheadpos.x, targetheadpos.y+10 )
                    if( Visible(v) ) then 
                        drawColor.a = 255; 
                    else 
                        drawColor.r = 255 - drawColor.r; 
                        drawColor.g = 255 - drawColor.g; 
                        drawColor.b = 255 - drawColor.b; 
                    end 
                    surface.SetDrawColor(drawColor)
                    local textData = {} 
                    local maxX, minX, maxY, minY = box(v)
					local lol = maxY-minY
					surface.SetDrawColor(drawColor)
					surface.DrawLine( maxX, maxY, maxX, minY )
					surface.DrawLine( maxX, minY, minX, minY )
					
					surface.DrawLine( minX, minY, minX, maxY )
					surface.DrawLine( minX, maxY, maxX, maxY )
					
					--[[if namealign == 1 then
                    textData.pos = {} 
                    textData.pos[1] = drawPosit.x; 
                    textData.pos[2] = minY-40; 
                    textData.color = drawColor; 
                    textData.text = v:GetName(); 
                    textData.font = "DefaultFixed"; 
                    textData.xalign = TEXT_ALIGN_CENTER; 
                    textData.yalign = TEXT_ALIGN_CENTER; 
                    draw.Text( textData );
					else]]
					local textData = {} 
					textData.pos = {} 
                    textData.pos[1] = drawPosit.x; 
                    textData.pos[2] = maxY+10; 
                    textData.color = drawColor; 
                    textData.text = v:GetName(); 
                    textData.font = "DefaultFixed"; 
                    textData.xalign = TEXT_ALIGN_CENTER; 
                    textData.yalign = TEXT_ALIGN_CENTER; 
                    draw.Text( textData );
					--end
					
					textData.pos[1] = drawPosit.x; 
                    textData.pos[2] = minY-30; 
                    textData.color = drawColor; 
                    textData.text = team.GetName(v:Team()); 
                    textData.font = "DefaultFixed"; 
                    textData.xalign = TEXT_ALIGN_CENTER; 
                    textData.yalign = TEXT_ALIGN_CENTER; 
					draw.Text( textData ); 
					
					textData.pos[1] = drawPosit.x; 
                    textData.pos[2] = minY-20; 
                    textData.color = drawColor; 
                    textData.text = v:SteamID(); 
                    textData.font = "DefaultFixed"; 
                    textData.xalign = TEXT_ALIGN_CENTER; 
                    textData.yalign = TEXT_ALIGN_CENTER; 
					draw.Text( textData ); 
					if v:IsAdmin() or v:IsSuperAdmin() or v:IsBot() then
					local admstring
					if v:IsAdmin() then
					admstring = "Admin"
					end
					if v:IsSuperAdmin() then
					admstring = "Super Admin"
					end
					if v:IsBot() then
					admstring = "Bot"
					end
					textData.pos[1] = drawPosit.x; 
                    textData.pos[2] = minY-10; 
                    textData.color = drawColor; 
                    textData.text = admstring; 
                    textData.font = "DefaultFixed"; 
                    textData.xalign = TEXT_ALIGN_CENTER; 
                    textData.yalign = TEXT_ALIGN_CENTER; 
					draw.Text( textData ); 
					end
					textData.pos[1] = minX-8; 
                    textData.pos[2] = minY+((maxY-minY)/2); 
                    textData.color = drawColor; 
                    textData.text = "HP: "..v:Health(); 
                    textData.font = "DefaultFixed"; 
                    textData.xalign = TEXT_ALIGN_RIGHT; 
                    textData.yalign = TEXT_ALIGN_CENTER; 
					draw.Text( textData ); 
					
					textData.pos[1] = maxX+8; 
                    textData.pos[2] = minY+((maxY-minY)/2); 
                    textData.color = drawColor; 
                    textData.text = "AP: "..v:Armor(); 
                    textData.font = "DefaultFixed"; 
                    textData.xalign = TEXT_ALIGN_LEFT; 
                    textData.yalign = TEXT_ALIGN_CENTER; 
					draw.Text( textData ); 
					
					local max_armor = 100; 
                     
                    if( v:Armor() > max_armor ) then 
                       max_armor = v:Armor(); 
                    end 
                    if v:GetActiveWeapon() then if ValidEntity(v:GetActiveWeapon()) then
					if v:GetActiveWeapon():GetClass() == "weapon_ak47" then
					draw.SimpleText( "b" , "CSKillIcons", drawPosit.x, maxY+35, drawColor, TEXT_ALIGN_CENTER, TEXT_ALIGN_LEFT, 1)
					elseif v:GetActiveWeapon():GetClass() == "weapon_para" then
					draw.SimpleText( "z" , "CSKillIcons", drawPosit.x, maxY+35, drawColor, TEXT_ALIGN_CENTER, TEXT_ALIGN_LEFT, 1)
					elseif v:GetActiveWeapon():GetClass() == "weapon_mp5" then
					draw.SimpleText( "x" , "CSKillIcons", drawPosit.x, maxY+35, drawColor, TEXT_ALIGN_CENTER, TEXT_ALIGN_LEFT, 1)
					elseif v:GetActiveWeapon():GetClass() == "weapon_m4" then
					draw.SimpleText( "w" , "CSKillIcons", drawPosit.x, maxY+35, drawColor, TEXT_ALIGN_CENTER, TEXT_ALIGN_LEFT, 1)
					elseif v:GetActiveWeapon():GetClass() == "weapon_glock" then
					draw.SimpleText( "c" , "CSKillIcons", drawPosit.x, maxY+35, drawColor, TEXT_ALIGN_CENTER, TEXT_ALIGN_LEFT, 1)
					elseif v:GetActiveWeapon():GetClass() == "weapon_tmp" then
					draw.SimpleText( "d" , "CSKillIcons", drawPosit.x, maxY+35, drawColor, TEXT_ALIGN_CENTER, TEXT_ALIGN_LEFT, 1)
					elseif v:GetActiveWeapon():GetClass() == "weapon_deagle" then
					draw.SimpleText( "f" , "CSKillIcons", drawPosit.x, maxY+35, drawColor, TEXT_ALIGN_CENTER, TEXT_ALIGN_LEFT, 1)
					elseif v:GetActiveWeapon():GetClass() == "weapon_pumpshotgun" then
					draw.SimpleText( "k" , "CSKillIcons", drawPosit.x, maxY+35, drawColor, TEXT_ALIGN_CENTER, TEXT_ALIGN_LEFT, 1)
					end
					end
					end
					if v:Alive() then
					local center = Vector( x,y, 0 )
                    local mx = max_armor; 
                    local mw = v:Armor(); 
                    local drw = mx / lol
                    local drawPosHealth = drawPosit; 
					surface.SetDrawColor(0,0,0,255)
					surface.DrawRect(maxX+2,minY-1,6,lol+2)
					surface.SetDrawColor(0,0,255,255)
					surface.DrawRect(maxX+3,minY-(mw/drw)+(mx/drw),4,mw/drw)
					local max_health = 100; 
                     
                    if( v:Health() > max_health ) then 
						max_health = v:Health(); 
                    end 
                    
                    local mx = max_health; 
                    local mw = v:Health(); 
                    local drw = mx / lol
                    local drawPosHealth = drawPosit; 
					surface.SetDrawColor(0,0,0,255)
					surface.DrawRect(minX-8,minY-1,6,lol+2)
					surface.SetDrawColor(255-(mw*2+50),mw*2+50,0,255)
					surface.DrawRect(minX-7,minY-(mw/drw)+(mx/drw),4,mw/drw)
					end
	elseif v:GetClass() == "npc_tripmine" then
	local drawPosit = v:GetPos():ToScreen(); 
	local textData = {}
	textData.pos = {} 
    textData.pos[1] = drawPosit.x; 
    textData.pos[2] = drawPosit.y; 
    textData.color = Color(0,150,255); 
    textData.text = "S.L.A.M. !!!"; 
    textData.font = "DefaultFixed"; 
    textData.xalign = TEXT_ALIGN_CENTER; 
    textData.yalign = TEXT_ALIGN_CENTER; 
    draw.Text( textData );
	end
    end 
	end
	end
hook.Add("HUDPaint","drawesp",drawesp)
local timerruns = 1
local function unhookz()
timerruns = 0
	hook.Remove( "HUDPaint","drawesp" )
	print("Unloaded Hooks")
end
local function KeyPress()
if timerruns == 1 then
timer.Simple(0.1,function () KeyPress() end)
end
    if( input.IsKeyDown( KEY_DELETE ) ) then
	timerruns = 0
	print("Destroyed timer")
unhookz()
	print("Unloaded Hooks")
	end
    end
KeyPress()