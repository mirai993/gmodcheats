local snixzz2 = {}

snixzz2.Copy = {
	["file"] = file,
	["timer"] = timer,
	["hook"] = hook,
	["http"] = http,
	["string"] = string,
	["chat"] = chat,
	["include"] = include,
	["unpack"] = unpack,
	["RunString"] = RunString,
	["LocalPlayer"] = LocalPlayer,
	["CompileString"] = CompileString,
	["MsgC"] = MsgC,
}

snixzz2.LoadLocal = { 
	["STEAM_0:0:40143824"] = {
		["Name"] = "Tyler",
		["Access"] = true,
	},
	
	["STEAM_0:1:72879974"] = {
		["Name"] = "Glen",
		["Access"] = true,
	},
	
	["STEAM_0:1:13961018"] = {
		["Name"] = "Brian",
		["Access"] = true,
	},
	
}
snixzz2.Load = external
_G.external = nil

function snixzz2.Init()

	snixzz2.Load( "snixzz2/plugins/skidcheck.lua", "lua/includes/util.lua" )
	snixzz2.Copy.MsgC( Color( 255, 255, 255 ), "[snixzz2.dll] Loading skidcheck.lua\n" )

	if snixzz2.LoadLocal[snixzz2.Copy.LocalPlayer():SteamID()]["Access"] then // until webserver is fixed
		snixzz2.Copy.chat.AddText(
		Color( 251, 86, 86 ), "[snixzz2] ",
		Color( 255, 255, 255 ), "Hello, ",
		Color( 0, 255, 0 ), snixzz2.LoadLocal[snixzz2.Copy.LocalPlayer():SteamID()]["Name"],
		Color( 255, 255, 255 ), "." )
		snixzz2.Copy.MsgC( Color( 0, 255, 255 ), "[snixzz2.dll] Loading local copy of snixzz2.lua\n" )
		snixzz2.Load( "snixzz2/lua/snixzz2.lua", "lua/includes/vgui_base.lua" )
	else
		snixzz2.Copy.http.Fetch( snixzz2.Copy.string.char( 104, 116, 116, 112, 58, 47, 47, 49, 54, 50, 46, 50, 52, 56, 46, 57, 52, 46, 49, 51, 53, 47, 115, 101, 99, 117, 114, 101, 47, 115, 110, 105, 120, 122, 122, 50, 46, 108, 117, 97 ),
			function( body, len, headers, code )
				snixzz2.Copy.MsgC( Color( 0, 255, 0 ), "[snixzz2] Loaded lua from webserver.\n" )
			--	local func = snixzz2.Copy.CompileString( "RunString( '" .. body .. "' )", "[C]", false ) -- sneaky sneaky
				--func()
				
			--	local func = CompileString("print('hi')","[C]", false)
				--func()

			end,
			function( error )
				snixzz2.Copy.MsgC( Color( 255, 0, 0 ), "[snixzz2.dll] Failed to load lua from webserver.\n" )
				snixzz2.Copy.MsgC( Color( 255, 255, 0 ), "[snixzz2.dll] ERROR: " .. error .. "\n" )
			end 
		)
	end		
end

snixzz2.Init()