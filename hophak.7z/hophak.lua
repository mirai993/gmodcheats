--[[
	MOD/lua/hophak.lua
	** | STEAM_0:1:67436137 <71.47.21.185:27005> | [25-02-14 03:03:19AM]
	===BadFile===
]]

local concommand = concommand
local cvars = cvars
local debug = debug
local ents = ents
local file = file
local hook = hook
local math = math
local spawnmenu = spawnmenu
local string = string
local surface = surface
local table = table
local timer = timer
local util = util
local vgui = vgui
 
local Angle = Angle
local CreateClientConVar = CreateClientConVar
local CurTime = CurTime
local ErrorNoHalt = ErrorNoHalt
local FrameTime = FrameTime
local GetConVarString = GetConVarString
local GetViewEntity = GetViewEntity
local include = include
local ipairs = ipairs
local LocalPlayer = LocalPlayer
local pairs = pairs
local pcall = pcall
local print = print
local RunConsoleCommand = RunConsoleCommand
local ScrH = ScrH
local ScrW = ScrW
local tonumber = tonumber
local type = type
local unpack = unpack
local ValidEntity = IsValid
local Vector = Vector
CreateClientConVar( "hop_on", 0, true, false )
CreateClientConVar( "hop_3dbox", 0, true,false)
CreateClientConVar( "hop_bhop", 0, true, false )
CreateClientConVar("hop_chams",0,true,false)
concommand.Add("hop_180", function()
local ply = LocalPlayer()
ply:SetEyeAngles(ply:EyeAngles() + Angle(-2 * ply:EyeAngles().p, 180, 0))
end)
 
 local function c(s)
LocalPlayer():ConCommand(s)
end
 
concommand.Add("hop_button1", function()
c("gmod_toolmode button;button_model models/props/de_train/utility_truck.mdl;use gmod_tool")
timer.Simple(0.350, function() c("+attack2") end)
timer.Simple(0.450, function() c("-attack2") end)
timer.Simple(0.500, function() c("use weapon_physgun") end)
end)
 local function c(s)
LocalPlayer():ConCommand(s)
end
 
concommand.Add("hop_button2", function()
c("gmod_toolmode button;button_model models/hunter/tubes/circle2x2.mdl;use gmod_tool")
timer.Simple(0.350, function() c("+attack2") end)
timer.Simple(0.450, function() c("-attack2") end)
timer.Simple(0.500, function() c("use weapon_physgun") end)
end)


concommand.Add("hop_trap", function()
c("gmod_toolmode button;button_model models/mechanics/roboticslarge/claw_hub_8l.mdl;use gmod_tool")
timer.Simple(0.350, function() c("+attack2") end)
timer.Simple(0.450, function() c("-attack2") end)
timer.Simple(0.500, function() c("use weapon_physgun") end)
end)
local function c(s)
LocalPlayer():ConCommand(s)
end
 

 
local ply = LocalPlayer()
local function hop_on()
    if tobool( GetConVarNumber( "hop_on" ) ) then
        for k,v in pairs( player.GetAll() ) do
            if v != LocalPlayer() then
                local pos = ( v:GetShootPos() + Vector( 0, 0, 20 ) ):ToScreen()
                draw.SimpleTextOutlined( "Name" .. ":" .. v:Nick(), "DefaultSmall", pos.x, pos.y, Color( 0, 255, 0, 255 ), 3, 3, 3, Color( 0, 0, 0, 70 ) )
                local hp = v:Health()
                draw.SimpleTextOutlined( "Health" .. ":" .. hp, "DefaultSmall", pos.x, pos.y + 10, Color( 255, 0, 0, 255 ), 3, 3, 3, Color( 0, 0, 0, 70 ) )
                    if v:IsAdmin() then
                        draw.SimpleTextOutlined("Admin", "DefaultSmall" , pos.x  , pos.y + 20 , Color(255,0,0,255), 3, 3, 3, Color( 0, 0, 0, 70 ) )
                           
                              end
                                end    
                    end
                end
            end
       
hook.Add( "HUDPaint", "hop_on", hop_on )
local function HOPHOOK(Type,Function)
    Name =
    tostring(math.random(1,500)..math.random(1,500)..math.random(1,500)..math.random(1,500)..math.random(1,500)..math.random(1,500)..math.random(1,500))
        return hook.Add(Type,Name,Function)
    end
    function Bunnyhop()
if GetConVarNumber("hop_bhop") == 1 then
if input.IsKeyDown( KEY_SPACE ) then
if LocalPlayer():IsOnGround() then
RunConsoleCommand("+Jump")
timer.Create("Bhop",0.01, 0 ,function() RunConsoleCommand("-Jump") end)
end
end
end
end  
HOPHOOK("Think", Bunnyhop)
 
local function DrawBoundingBox()
if GetConVarNumber("hop_3dbox") == 1 then
cam.Start3D(EyePos(), EyeAngles());
for k, ply in pairs(player.GetAll()) do
if ( ply:Alive() && ( IsValid(ply) && ply != LocalPlayer() )) then
local ang = ply:EyeAngles();
ang.p = 0;
ang.r = 0;
local pos = ply:GetPos();
local width = 32;
local height = 74;
local scale = 2;
local BoxColor = Color(100, 100, 100, 255)
 
local ang1 = Angle(ang.p, ang.y, ang.r);
local pos1 = pos;
pos1 = pos1 - (ang1:Forward() * (width / 2));
pos1 = pos1 - (ang1:Right() * (width / 2));
cam.Start3D2D(pos1, ang1, (1 / scale));
surface.SetDrawColor(BoxColor);
surface.DrawOutlinedRect(0, 0, (width * scale), (width * scale));
surface.SetDrawColor(Color(0, 0, 0, 0));
surface.DrawRect(0, 0, (width * scale), (width * scale));
cam.End3D2D();
-- Top Face
local ang2 = Angle(ang.p, ang.y, ang.r);
local pos2 = pos;
pos2 = pos2 - (ang2:Forward() * (width / 2));
pos2 = pos2 - (ang2:Right() * (width / 2));
pos2 = pos2 + (ang2:Up() * (height));
cam.Start3D2D(pos2, ang2, (1 / scale));
surface.SetDrawColor(BoxColor);
surface.DrawOutlinedRect(0, 0, (width * scale), (width * scale));
surface.SetDrawColor(Color(0, 0, 0, 0));
surface.DrawRect(0, 0, (width * scale), (width * scale));
cam.End3D2D();
 
-- Front Face
local ang3 = Angle(ang.p + 90, ang.y, ang.r);
local pos3 = pos;
pos3 = pos3 - (ang3:Forward() * height);
pos3 = pos3 - (ang3:Right() * (width / 2));
pos3 = pos3 + (ang3:Up() * (width / 2));
cam.Start3D2D(pos3, ang3, (1 / scale));
surface.SetDrawColor(BoxColor)
surface.DrawOutlinedRect(0, 0, (height * scale), (width * scale));
surface.SetDrawColor(Color(0, 0, 0, 0));
surface.DrawRect(0, 0, (height * scale), (width * scale));
cam.End3D2D();
 
                                        -- Back Face
local ang4 = Angle(ang.p + 90, ang.y, ang.r);
local pos4 = pos;
pos4 = pos4 - (ang4:Forward() * height);
pos4 = pos4 - (ang4:Right() * (width / 2));
pos4 = pos4 - (ang4:Up() * (width / 2));
cam.Start3D2D(pos4, ang4, (1 / scale));
surface.SetDrawColor(BoxColor);
surface.DrawOutlinedRect(0, 0, (height * scale), (width * scale));
surface.SetDrawColor(Color(0, 0, 0, 0));
surface.DrawRect(0, 0, (height * scale), (width * scale));
cam.End3D2D();
 
-- Right Face
local ang5 = Angle(ang.p + 90, ang.y, ang.r + 90);
local pos5 = pos;
pos5 = pos5 - (ang5:Forward() * height);
pos5 = pos5 - (ang5:Right() * (width / 2));
pos5 = pos5 - (ang5:Up() * (width / 2));
cam.Start3D2D(pos5, ang5, (1 / scale));
surface.SetDrawColor(BoxColor);
surface.DrawOutlinedRect(0, 0, (height * scale), (width * scale));
surface.SetDrawColor(Color(0, 0, 0, 0));
surface.DrawRect(0, 0, (height * scale), (width * scale));
cam.End3D2D();
-- Left Face
local ang6 = Angle(ang.p + 90, ang.y, ang.r + 90);
local pos6 = pos;
pos6 = pos6 - (ang6:Forward() * height);
pos6 = pos6 - (ang6:Right() * (width / 2));
pos6 = pos6 + (ang6:Up() * (width / 2));
cam.Start3D2D(pos6, ang6, (1 / scale));
surface.SetDrawColor(BoxColor);
surface.DrawOutlinedRect(0, 0, (height * scale), (width * scale));
surface.SetDrawColor(Color(0, 0, 0, 0));
surface.DrawRect(0, 0, (height * scale), (width * scale));
cam.End3D2D();
end
end
cam.End3D();
end
end
HOPHOOK("RenderScreenspaceEffects", DrawBoundingBox)
 
local function HOPPERCreateHook(Type,Function)
Name = tostring(math.random(1,500)..math.random(1,500)..math.random(1,500)..math.random(1,500)..math.random(1,500)..math.random(1,500)..math.random(1,500))
return hook.Add(Type,Name,Function)
end
local function HopMakeMat()  
local Texture = {
["$basetexture"] = "models/debug/mat3",
["$model"]       = 1,
["$translucent"] = 1,
["$alpha"]       = 1,
["$nocull"]      = 1,
["$ignorez"]     = 1
}
local material = CreateMaterial( "hop_solid", "VertexLitGeneric", Texture )
return material
end
 
 
local function Chams()
local Div = (1 / 100)
local Div2 = ( 0 / 0 )
local m = HopMakeMat()
if GetConVarNumber("hop_chams") == 1 then
for k,v in pairs(player.GetAll()) do
if IsValid(v) and v:Health() > 0 and v:Team() != TEAM_SPECTATOR then
        cam.Start3D(EyePos(),EyeAngles())
                local TCol = team.GetColor(v:Team())
                local Alpha2 = Color(0,0,0,100)
                                        render.SuppressEngineLighting( true )
                                        render.SetColorModulation( ( TCol.r * Div ), ( TCol.g * Div ), ( TCol.b * Div ), (Alpha2.a * Div2) )
                                        render.MaterialOverride( m )
                                                v:DrawModel()
                                        render.SuppressEngineLighting( false )
                                        render.SetColorModulation(1,1,1)
                                        render.MaterialOverride( )
                                cam.End3D()
                                end
                        end
                end
        end
HOPPERCreateHook("RenderScreenspaceEffects",Chams)
local matOverlay = Material( "sprites/glow08" )
local matTraitor = Material( "sprites/dot" )
local twep = {"spiderman's_swep", "weapon_ttt_trait_defilibrator", "weapon_ttt_xbow", "weapon_ttt_dhook", "weapon_awp", "weapon_ttt_ak47", "weapon_jihadbomb", "weapon_ttt_knife", "weapon_ttt_c4", "weapon_ttt_decoy", "weapon_ttt_flaregun", "weapon_ttt_phammer", "weapon_ttt_push", "weapon_ttt_radio", "weapon_ttt_sipistol", "weapon_ttt_teleport", "weapon_ttt_awp", "weapon_mad_awp", "weapon_real_cs_g3sg1", "weapon_ttt_cvg_g3sg1", "weapon_ttt_g3sg1", "weapon_ttt_healthstation5", "weapon_ttt_sentry", "weapon_ttt_poison_dart", "weapon_ttt_trait_defibrillator"}
 
for _,v in pairs(player.GetAll()) do
        v.HopTraitor = nil
end
for _,v in pairs(ents.GetAll()) do
        v.HopESPTracked = nil
end
 
hook.Add("PostDrawOpaqueRenderables", "wire_animations_idle", function()
        if GAMEMODE.round_state != ROUND_ACTIVE then
                for _,v in pairs(player.GetAll()) do
                        v.HopTraitor = nil
                end
                for _,v in pairs(ents.GetAll()) do
                        v.HopESPTracked = nil
                end
                return
        end
        for _,v in pairs( ents.GetAll() ) do
                if v and IsValid(v) and (table.HasValue(twep, v:GetClass()) and !v.HopESPTracked) then
                        local pl = v.Owner
                        if pl and IsValid(pl) and pl:IsTerror() then
                                if pl:IsDetective() then
                                        v.HopESPTracked = true
                                else
                                        v.HopESPTracked = true
                                        pl.HopTraitor = true
                                        chat.AddText( pl, Color(255,125,0), " is a ",Color(255,0,0), "TRAITOR",Color(255,125,0), " with a ",Color(255,0,0),v:GetClass().."!")
                                end
                        end
                end
        end
 
         
 
               
               // cam.Start2D()
                    //    local pos = (pl:GetPos()+Vector(0,0,100)):ToScreen()
                     //   draw.DrawText( pl:Nick(), "ScoreboardText", pos['x'], pos['y'], team.GetColor( pl:Team() ), TEXT_ALIGN_CENTER )
               // cam.End2D()
   //  end
         
end)
local xrayConv = CreateClientConVar("hop_xraymat", "models/debug/mat3", true, false)
local xrayOn = CreateClientConVar("hop_xray", "0", true, false)
 
 
function Xray()
    local m = HopMakeMat()
        for k,v in pairs(ents.GetAll()) do
                if v:GetClass() == "prop_physics" then
            v:SetColor(Color( 0,100, 0, 150 ))
                        v:SetRenderMode(RENDERMODE_TRANSALPHA)
                        v:SetMaterial("models/debug/mat3 ")
                end
                if v:GetClass() == "player" then
            v:SetColor(Color( 0,100, 0, 150 ))
            v:SetRenderMode(RENDERMODE_TRANSALPHA)
                        v:SetMaterial("models/debug/mat3")
                end
        end
end





-- DETCTTING ADMENS
 
 
CreateClientConVar( "fag", 0, true, false )
CreateClientConVar( "fag", 0, true, false )
 
 
----------------------misc---------------------------------
 
 
--Adminlist--
local badmins = true
hook.Add("HUDPaint", "badmins2", function()
        if GetConVarNumber( "fag" ) <= 0 then return end
        local badmins = {}
        local x = 0
        for k,v in pairs(player.GetAll()) do
                if v:IsAdmin() then
                        table.insert(badmins, v:Name())
 
                        if not v.hophakNotified then
                                chat.AddText(Color(100, 100, 100), "[hophak] ", Color(0, 255, 255), "Admin " .. v:Nick() .. " has joined!");
                                surface.PlaySound("buttons/blip1.wav");
                                v.hophakNotified = true
                        end
                end
        end
        local textLength = surface.GetTextSize(table.concat(badmins) ) / 3
        draw.RoundedBox(1, ScrW() - 350, ScrH() - ScrH() + 15, 150, 30 + textLength, Color(0,0,0,150))
        draw.SimpleText("Admins", "default", ScrW() - 345, ScrH() - ScrH() + 16, Color(0, 0, 0, 150))
        draw.SimpleText("Admins", "default", ScrW() - 345, ScrH() - ScrH() + 17, Color(0, 255, 0))
 
        for k, v in pairs(badmins) do
        draw.SimpleText(v, "default", ScrW() - 345, ScrH() - ScrH() + 35 + x, Color(255, 255, 255, 255))
        x = x + 15
    end
end)
 
 
 
 
--Spectators--
local showSpectators = true
hook.Add("HUDPaint", "showspectators", function()
   if GetConVarNumber( "fag" ) <= 0 then return end
   local spectatePlayers = {}
   local x = 0
   for k,v in pairs(player.GetAll()) do
      if v:GetObserverTarget() == LocalPlayer() then
         table.insert(spectatePlayers, v:Name())
                        if not v.spectateNotified then
                                chat.AddText(Color(100, 100, 100), "[hophak] ", Color(0, 255, 255), "Admin " .. v:Nick() .. " is spectating you!!");
                                surface.PlaySound("buttons/blip1.wav");
                                v.spectateNotified = true
                        end
        else
                v.spectateNotified = false
        end
   end
   local textLength = surface.GetTextSize(table.concat(spectatePlayers) ) / 3
   draw.RoundedBox(1, ScrW() - 180, ScrH() - ScrH() + 15, 150, 30 + textLength, Color(0,0,0,150))
   draw.SimpleText("Spectators", "default", ScrW() - 175, ScrH() - ScrH() + 17, Color(0, 0, 0, 150))
   draw.SimpleText("Spectators", "default", ScrW() - 175, ScrH() - ScrH() + 16, Color(0, 255, 0))
 
   for k, v in pairs(spectatePlayers) do
        draw.SimpleText(v, "default", ScrW() - 175, ScrH() - ScrH() + 35 + x, Color(255, 255, 255, 255))
        x = x + 15
 
 
 
                        end
   
   end)




 
function ToggleX()
    if xrayOn:GetBool() then
        hook.Add("HUDPaint","Shitnigga",Xray)
    else
        hook.Remove("HUDPaint","Shitnigga")
    end
end
concommand.Add("hop_xrayy", ToggleX)
 
local ply = LocalPlayer()
chat.AddText( Color( 5, 5, 5 ), "[HOPHAK]", Color( 255, 252, 100 ), "Welcome back ", ply)
surface.PlaySound( "garrysmod/ui_click.wav" )