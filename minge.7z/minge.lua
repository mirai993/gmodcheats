--[[
#            _____                    _____                    _____                    _____                   _____          
#           /\    \                  /\    \                  /\    \                  /\    \                 /\    \         
#          /::\____\                /::\    \                /::\____\                /::\    \               /::\    \        
#         /::::|   |                \:::\    \              /::::|   |               /::::\    \             /::::\    \       
#        /:::::|   |                 \:::\    \            /:::::|   |              /::::::\    \           /::::::\    \      
#       /::::::|   |                  \:::\    \          /::::::|   |             /:::/\:::\    \         /:::/\:::\    \     
#      /:::/|::|   |                   \:::\    \        /:::/|::|   |            /:::/  \:::\    \       /:::/__\:::\    \    
#     /:::/ |::|   |                   /::::\    \      /:::/ |::|   |           /:::/    \:::\    \     /::::\   \:::\    \   STOP UDTAING IT WTFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF
#    /:::/  |::|___|______    ____    /::::::\    \    /:::/  |::|   | _____    /:::/    / \:::\    \   /::::::\   \:::\    \  
#   /:::/   |::::::::\    \  /\   \  /:::/\:::\    \  /:::/   |::|   |/\    \  /:::/    /   \:::\ ___\ /:::/\:::\   \:::\    \ 
#  /:::/    |:::::::::\____\/::\   \/:::/  \:::\____\/:: /    |::|   /::\____\/:::/____/  ___\:::|    /:::/__\:::\   \:::\____\
#  \::/    / ~~~~~/:::/    /\:::\  /:::/    \::/    /\::/    /|::|  /:::/    /\:::\    \ /\  /:::|____\:::\   \:::\   \::/    /
#   \/____/      /:::/    /  \:::\/:::/    / \/____/  \/____/ |::| /:::/    /  \:::\    /::\ \::/    / \:::\   \:::\   \/____/ 
#               /:::/    /    \::::::/    /                   |::|/:::/    /    \:::\   \:::\ \/____/   \:::\   \:::\    \     
#              /:::/    /      \::::/____/                    |::::::/    /      \:::\   \:::\____\      \:::\   \:::\____\    dicks
#             /:::/    /        \:::\    \                    |:::::/    /        \:::\  /:::/    /       \:::\   \::/    /    
#            /:::/    /          \:::\    \                   |::::/    /          \:::\/:::/    /         \:::\   \/____/     
#           /:::/    /            \:::\    \                  /:::/    /            \::::::/    /           \:::\    \         
#          /:::/    /              \:::\____\                /:::/    /              \::::/    /             \:::\____\        
#          \::/    /                \::/    /                \::/    /                \::/____/               \::/    /        
#           \/____/                  \/____/                  \/____/                                          \/____/         
#                                                                                                                              nigger
--Private script cus fuck everyone

--A small server minging script made by ''Divine Astral Shield and ''Element, still a work in progress.

--]]

--[[ ChangeLog: Please list any changes made here, in order by time made.
5/30/13
Added physgun randomizer!
Added GUI: Minge_Menu

5/31/13
Fixed up menu a bit more lel

6/1/13
Fixed menu more
added sky lasers
Lasers now match colors

jan-feb 2014 
-tacremove(Removes tac.)
--fixed keypadhack to not lag and work better
--Doesnt run on MENU
--Added bypasses to certain servers/Anti-Cheats(most dont work without load b4 autorun.)
--Made cheat faster, Replaced Thinks with CreateMove
--You can also mess with server exploits with the EXPLOIT menu. enjoy.

--]]

--doesnt run on server or menu
if( !CLIENT ) then
        return;
 end
include("kypdhk.lua")
//include("rifk.lua")
include("pklttt.lua")
include("autorun/client/FalcoUtilities.lua")
surface.CreateFont("MingeFont", { size = 13, weight = 10, antialias = true, font = "Arial", outline = true})
surface.CreateFont("MingeFont2", { size = 14, weight = 12, antialias = false, font = "Arial", outline = true})
surface.CreateFont("MingeFont3", { size = 30, weight = 12, antialias = false, font = "Arial", outline = true})
//surface.CreateFont("MingeFont4", { size = 1, weight = 12, antialias = false, font = "Arial", outline = true})
--[[

-------------BOOLS-------------

--]]
BotName = "MNG_"
ACK = CreateClientConVar(BotName .. "KillAntiCheats", 1, true, true)
spd = CreateClientConVar(BotName .. "spd", 1, true, true)
SpamTextTog = CreateClientConVar( BotName .. "SpamToggle",0,true,true)
SpamText = CreateClientConVar( BotName .. "Spam_text", "/advert Nigger tits", true, true)
FriendNotify = CreateClientConVar( BotName .. "FriendNotify",1,true,true)
AdminNotify = CreateClientConVar( BotName .. "AdminNotify",1,true,true)
MingeNotify = CreateClientConVar( BotName .. "MingeNotify",1,true,true)
shouldESP = CreateClientConVar( BotName .."ESP_boxes", 1, true, false)
ESPNames = CreateClientConVar( BotName .. "ESP_names",1,true,true)
FallDamageWarning = CreateClientConVar( BotName .. "falldamagewarning",1,true,true)
AutoBuyHP = CreateClientConVar( BotName .. "AutoBuyHP",1,true,true)
PhysGunColors = CreateClientConVar( BotName .. "physguncolors",1,true,true)
Bhop = CreateClientConVar( BotName .. "Bhop",1,true,true)
Lasers = CreateClientConVar( BotName .. "lasereyes",1,true,true )
DropMoneySpam = CreateClientConVar( BotName .. "MoneySpam",1,true,true )
Skylaserbool = CreateClientConVar( BotName .. "skylasers",0,true,true )
--old name toggle
--ListToggle = CreateClientConVar( BotName .. "player_names",1,true,true)

--[[

-------------ELEBOT SHIT-------------

--]]
cmdStr = "elebot" --Elebot boxes shit
offset = CreateClientConVar(cmdStr.."_offset", 24, true, false)
targetTeam = CreateClientConVar(cmdStr.."_targetteam", 0, true, false)
simpleColors = CreateClientConVar(cmdStr.."_simplecolors", 1, true, false)
maxView = CreateClientConVar(cmdStr.."_maxview", 4800, true, false)
minView = CreateClientConVar(cmdStr.."_minview", 120, true, false)
boxSize = CreateClientConVar(cmdStr.."_boxsize", 10, true, false)
filledBox = CreateClientConVar(cmdStr.."_filledbox", 0, true, false)
showAdmin = CreateClientConVar(cmdStr.."_showadmin", 1, true, false)
surface.CreateFont("ElebotPlayerInfo", { size = 14, weight = 500, antialias = true, font = "Coolvetica"})
surface.CreateFont("ElebotPlayerTitle", { size = 14, weight = 500, antialias = true, font = "Coolvetica"})




--[[

-------------TABLES-------------

--]]
NamesList = {} 
local Menu = {}
NameChar = CreateClientConVar( BotName .. "Name_char", " ", true, true)

-- this shit was way too long. Made it smaller.
GenericNames = 
{
"Jimmy","Huehue","TheScumbag","Nope","John","Smokeweed202","[BN] The Nig",
"Akujo","Tyler","iluvfriedchikun","headaccessible","sledderbass","jubilantpaddleball",
"shamefulpaltry","congressoxbird","hoodlumplum","prisonerstruggling","yoghurtcurling",
"pruningwindow","lanternrag","scrapedalert","doppingmean","wedgespatula","grapesgrotesque",
"synonymousmessy","flutteringtoy","lamegordon","tooparty","hollytips","applebaseball",
"hobbledehoybones","bodaciousjealous","morbidbolivian","anusshock","stomachslangwhanger",
"occiputcall","irispaper","versedmany","toffeebaton","deceitcream","cakecheesecake",
"winbook","wakeproperty","humiliatedair","impalafirst","bugslash","feastostrich",
"targetrangale","mypop","chocolatemasons","rollerwhimsical","lumpycheese","calmbash",
"gurgleenthralled","australianbutterflyfish","cannedpick","rambunctiousnails",
"sillyblocked"
}
--this too
Coolphysguncolors = 
{
"1 0 123","123 1 12345","1 123 12345","11111111111111111111111111111111 1 0","1 12345 123",
"11111111111111111111111111111 11111111111111111111111111111 11111111111111111111111111111",
"0 0 0","0 255 0","255 0 0","0 255 255","89 90 255"
}

MingeList = 
{
"STEAM_0:1:52695624", --Test subject, working.
"STEAM_0:0:45775162",
"STEAM_0:0:41102628",
"STEAM_0:1:18598141", --"taj"
"STEAM_0:1:37082430", --"panda"
"STEAM_0:0:43549312", --cookiezgamer
"STEAM_0:0:59075603",
"STEAM_0:1:43059018",
"STEAM_0:0:57600624", --fail minges
}

--[[

-------------FUNCTION CITY-------------

--]]

function nametog()
pnamesToggle = !pnamesToggle
	if pnamesToggle then 
		chat.AddText(Color(255,0,0), "[MINGE] Taking player names...")
	else
		chat.AddText(Color(255,0,0), "[MINGE] Taking generic names...")
	end
end
concommand.Add( BotName .. "Player_NameToggle", nametog )

function nametest() --Note: Sometimes you will get the RP /name errors like too short or long, name taken, etc.
	--if (ListToggle:GetBool() == true) then
	if (pnamesToggle) then
		for k,v in pairs(player.GetAll()) do 
			if (!v:IsAdmin()) then table.insert(NamesList,0,v:Nick()) end 	
		end
	RunConsoleCommand("say","/name " .. table.Random(NamesList) .. NameChar:GetString())
	else RunConsoleCommand("say","/name " .. table.Random(GenericNames))
	end
end
concommand.Add( BotName .. "ChangeTheName", nametest)

function nametesttimer()
	timer.Create("Changenametimer",6,0,nametest)
	chat.AddText(Color(255,0,0), "Name changing periodically.")
	chat.PlaySound()
	hook.Remove("Think","asda9s80da80d9")
	hook.Remove("Think","niggerjewspam3")
end
concommand.Add( BotName .. "ChangeTheName_TimerON",nametesttimer)


function nametesttimer_off()
	timer.Destroy("Changenametimer",6,0,nametest)
	chat.AddText(Color(255,0,0), "Name changing off.")
	chat.PlaySound()
end
concommand.Add( BotName .. "ChangeTheName_TimerOFF",nametesttimer_off)



function dropmoneyspam()
	if DropMoneySpam:GetBool() == true then
		RunConsoleCommand("say","/dropmoney 2")
	end
end
hook.Add("Think","asda9s80da80d9", dropmoneyspam)


function Spamthis()
	if SpamTextTog:GetBool() == true then
			RunConsoleCommand("say", SpamText:GetString())
	end
end
hook.Add("Think","niggerjewspam3",Spamthis)

function Spamthis_off()
	hook.Remove("Think","niggerjewspam3")
end
concommand.Add( BotName .. "SpamThis_off",Spamthis_off)



function Randomizenigga()
    if PhysGunColors:GetBool() == true then
        if LocalPlayer():Alive() == false then
            RunConsoleCommand("cl_weaponcolor",tostring(table.Random(Coolphysguncolors)))
        end
    end
end
hook.Add("Think","asdaisjd23232",Randomizenigga)


function laserdicks()
	cam.Start3D(EyePos(),EyeAngles())
	if Lasers:GetBool() then
		cam.IgnoreZ(true)
		for k,v in pairs(player.GetAll()) do
			if v != LocalPlayer() and v:Alive() then
				local laserstartpos = v:EyePos()
				local laserendpos = v:GetEyeTrace().HitPos
				if v:IsAdmin() then theircolor = Color(255,0,0) else theircolor = Color(0,255,0) end
				if table.HasValue(MingeList,v:SteamID()) then theircolor = Color(255,255,0) end
				if v:GetFriendStatus() == "friend" then theircolor = Color(0,255,255) end
				render.SetMaterial(Material("tripmine_laser"))
				render.DrawBeam(laserstartpos, laserendpos, 10, 1, 1, theircolor)
			end
		end
	end
	cam.End3D()
end
hook.Add("RenderScreenspaceEffects","laserdicks",laserdicks)

function dancecity()
hook.Add("Think","yesz77",function()
RunConsoleCommand("act","dance")
end)
end
concommand.Add( BotName .. "dance", dancecity )

function skylasers()
	if Skylaserbool:GetBool() then
		cam.Start3D(EyePos(),EyeAngles())
		cam.IgnoreZ(true)
		for k,v in pairs(player.GetAll()) do
			if v != LocalPlayer() and v:Alive() then
				local skylaserstart = v:EyePos()
				local skylaserend = skylaserstart + Vector(0,0,10000000000)
				if v:IsAdmin() then theircolor = Color(255,0,0) else theircolor = Color(0,255,0) end
				if table.HasValue(MingeList,v:SteamID()) then theircolor = Color(255,255,0) end
				if v:GetFriendStatus() == "friend" then theircolor = Color(0,255,255) end
				render.SetMaterial(Material("trails/laser"))
				render.DrawBeam(skylaserstart, skylaserend, 20, 1, 1, theircolor)
			end
		end
		cam.End3D()
	end
end
hook.Add("RenderScreenspaceEffects","skylaserhook",skylasers)




--[[

------------Bool hooks----------

--]]
hook.Add( "HUDPaint", "FriendNotify", function()
	if (FriendNotify:GetBool() == true) then
		for k,v in pairs ( player.GetAll() ) do
			if v:GetFriendStatus() == "friend" then
				local Position = ( v:GetPos() + Vector( 0,0,20 ) ):ToScreen()
				draw.DrawText( "FRIEND", "MingeFont", Position.x, Position.y , Color( 0, 255, 255, 255 ), 1 )
			end
		end
	end
end)

hook.Add( "HUDPaint", "AdminNotify", function()
	if (AdminNotify:GetBool() == true) then
		for k,v in pairs ( player.GetAll() ) do
			if v:IsAdmin() then
				local Position = ( v:GetPos() + Vector( 0,0,20 ) ):ToScreen()
				draw.DrawText( "ADMIN", "MingeFont", Position.x, Position.y , Color( 255, 0, 0, 255 ), 1 )
			end
		end
	end
end)

hook.Add( "Think", "ABHPee", function()
	if (AutoBuyHP:GetBool() == true) then
		if (LocalPlayer():Health() <= 50 and LocalPlayer():Alive())then
			RunConsoleCommand("say","/buyhealth")
		end
	end
end)

--BEST BHOP 2013
local ClientOnGround = function()
    local ground = LocalPlayer():GetGroundEntity()
    if IsValid(ground) or ground:IsWorld() or LocalPlayer():IsOnGround() then
        return true
    end
    return false
end
hook.Add("CreateMove", "l2hopbr0", function(ucmd)
if (Bhop:GetBool() == true) then
    if (bit.band(ucmd:GetButtons(), IN_JUMP) > 0) then
        if not ClientOnGround() then
            ucmd:SetButtons(bit.band(ucmd:GetButtons(), bit.bnot(IN_JUMP)))
        end
    end
end
end)

function fasttog()
fast = !fast

 hook.Add("Think","\0\0\0\0", function()
	if fast and spd:GetBool() == true then 
		local seed = 0.2;
		local magic_seed = (seed / RealFrameTime());
		--if( input.IsKeyDown( KEY_F ) ) then
		RunConsoleCommand( '_host_framerate', tostring( magic_seed ) );
		//chat.AddText(Color(255,0,0), "[MINGE] goin fast")
	else
		//chat.AddText(Color(255,0,0), "[MINGE] goin slow")
		RunConsoleCommand( '_host_framerate', '0' );
	end
 end)

end
concommand.Add( BotName .. "Speed", fasttog )

--[[
--betterspeedthing
--ty for help deep
hook.Add("Think","\0\0\0\0", function()
	local seed = 0.3;
	local magic_seed = (seed / RealFrameTime());
	if (spd:GetBool() == true) then
		--if( input.IsKeyDown( KEY_F ) ) then
			RunConsoleCommand( '_host_framerate', tostring( magic_seed ) );
	else
			RunConsoleCommand( '_host_framerate', '0' );
	end
end)
--]]
--Boxes and Admin List. Ripped from somewhere else, blow me.
local function PaintTargets()
        if (!shouldESP:GetBool()) then return end
        local adminList = "";
        for k,v in pairs (ents.GetAll()) do
                if v:IsNPC() then
                        local pos = (v:GetPos() + Vector(0, 0, offset:GetFloat())):ToScreen()
                       
                        if v:OBBMaxs().z < offset:GetFloat() then
                                pos = (v:GetPos() + Vector(0, 0, v:OBBMaxs().z * 0.25)):ToScreen()
                        end
                       
                        if (pos.visible) then
                                local alpha = math.Clamp((maxView:GetFloat() - v:GetPos():Distance(LocalPlayer():GetShootPos())) * (255 / (maxView:GetFloat() - minView:GetFloat())), 30, 255)
                                draw.SimpleText(string.gsub(v:GetClass(), "npc_", ""), "ElebotPlayerTitle",  pos.x, pos.y, Color(0, 255, 0, alpha), 1, 1)
                                local boxCenter = (v:GetPos() + Vector(0, 0, v:OBBMaxs().z)):ToScreen()
                                local bL = boxSize:GetFloat()
                                if (filledBox:GetBool() && bL != 0) then
                                        draw.RoundedBox(1, boxCenter.x - bL, boxCenter.y - bL, bL * 2, bL * 2, Color(0, 255, 0, alpha))
                                else
                                        if (!filledBox:GetBool() && bL != 0) then
                                                local bL = boxSize:GetFloat()
                                                surface.SetDrawColor(0, 255, 0, alpha)
                                                surface.DrawLine(boxCenter.x - bL, boxCenter.y + bL, boxCenter.x - bL, boxCenter.y - bL) //Left vertical
                                                surface.DrawLine(boxCenter.x - bL, boxCenter.y + bL, boxCenter.x + bL, boxCenter.y + bL) //Bottom horizontal
                                                surface.DrawLine(boxCenter.x + bL, boxCenter.y - bL, boxCenter.x - bL, boxCenter.y - bL) // Top horizontal
                                                surface.DrawLine(boxCenter.x + bL, boxCenter.y - bL, boxCenter.x + bL, boxCenter.y + bL) //Right vertical
                                        end
                                end
                        end
                else
                        if v:IsPlayer() then
                                local pos = (v:GetPos() + Vector(0, 0, offset:GetFloat())):ToScreen()
                               
                                if string.find(v:GetModel(), "crab") or string.find(v:GetModel(), "torso") then
                                        pos = (v:GetPos() + Vector(0, 0, v:OBBMaxs().z * 0.25)):ToScreen()
                                end
                               
                                if (pos.visible and v != LocalPlayer() and v.Nick and v.Health and v.GetActiveWeapon and v:GetActiveWeapon().GetPrintName) then
                                        local alpha = math.Clamp((maxView:GetFloat() - v:GetPos():Distance(LocalPlayer():GetShootPos())) * (255 / (maxView:GetFloat() - minView:GetFloat())), 30, 255)
                                        local tcol// = team.GetColor(v:Team())
                                        if (simpleColors:GetBool()) then
                                                if (v:Team() == LocalPlayer():Team()) then
                                                        tcol = Color(0,255,0, alpha)
                                                else
                                                        tcol = Color(0,255,0, alpha)
                                                end
												
												if v:IsAdmin() then
													tcol = Color(255,0,0)
												end
												
												if v:GetFriendStatus() == "friend" then
													tcol = Color(0,255,255)
												end
                                        else
                                                tcol = team.GetColor(v:Team())
                                                tcol = Color(tcol.r, tcol.g, tcol.b, alpha)
                                        end
                                       
                                     
                                        local boxCenter = ((v:GetPos() + Vector(0, 0, v:OBBMaxs().z * 0.9))):ToScreen()
                                        local bL = boxSize:GetFloat()
                                        if (filledBox:GetBool() && bL != 0) then
                                                draw.RoundedBox(1, boxCenter.x - bL, boxCenter.y - bL, bL * 2, bL * 2, tcol)
                                        else
                                                if (!filledBox:GetBool() && bL != 0) then
                                                        surface.SetDrawColor(tcol.r, tcol.g, tcol.b, alpha)
                                                        surface.DrawLine(boxCenter.x - bL, boxCenter.y + bL, boxCenter.x - bL, boxCenter.y - bL) //Left vertical
                                                        surface.DrawLine(boxCenter.x - bL, boxCenter.y + bL, boxCenter.x + bL, boxCenter.y + bL) //Bottom horizontal
                                                        surface.DrawLine(boxCenter.x + bL, boxCenter.y - bL, boxCenter.x - bL, boxCenter.y - bL) // Top horizontal
                                                        surface.DrawLine(boxCenter.x + bL, boxCenter.y - bL, boxCenter.x + bL, boxCenter.y + bL) //Right vertical
                                                end
                                        end
                                end
                               
                                if v:IsAdmin() or v:IsSuperAdmin() then
                                        adminList = adminList..", "..v:Nick()
                                end
 
                               
                        end
                end
        end
       
        if (showAdmin:GetBool()) then
                if (adminList != "") then
                        adminList = string.sub(adminList, 3, string.len(adminList))
                        draw.SimpleText("Admins: "..adminList, "ElebotPlayerInfo", ScrW() * 0.8, ScrH() * 0.2, Color(255, 255, 0, 200), 1, 1)
                else
                        draw.SimpleText("No admins here!", "ElebotPlayerInfo", ScrW() * 0.8, ScrH() * 0.2, Color(0, 255, 255, 200), 1, 1)
                end
        end
end




--testing stuff

HookList = {}

function testing()

PrintTable( hook.GetTable().HUDPaint )
abc = string.format( 'player: %s, health: %i', LocalPlayer():Nick(), LocalPlayer():Health() );
print( abc );
--[[
hook.Remove("HUDaint",FPP_HUDPaint);
hook.Remove("HUDaint",DrawPlantInfo);
hook.Remove("HUDaint",DarkRP_Mod_HUDPaint);
hook.Remove("HUDaint",DrawReportInfo);
hook.Remove("HUDaint",ps_Ticker);
hook.Remove("HUDaint",FPP_HUDPaint);
hook.Remove("HUDaint",FPP_HUDPaint);
armor_piece_full	=	function: 0x59ce5f30
PlayerOptionDraw	=	function: 0x1cb76248
FriendNotify	=	function: 0x6af2fab8
NamesOnTEHHeads	=	function: 0x7032b340
DrawLaws	=	function: 0x5f194e30
DrawPowderInfo	=	function: 0x37226d68
SW.HUDPaint	=	function: 0x30ddddd0
DrawRecordingIcon	=	function: 0x3a6ab288
DrawZombieInfo	=	function: 0x3a5278c0
somethingoranotherthatissomethingelse	=	function: 0x68ace830
DrawPlantInfo	=	function: 0x59cef468
DrawReportInfo	=	function: 0x35ccade8
PaintTargets	=	function: 0x39d79528
MingeNotify	=	function: 0x59f9fa60
FallDamageWarning	=	function: 0x5a23fd20
ESPNames	=	function: 0x5a27f6c0
AdminNotify	=	function: 0x5a0cdce0
armor_piece	=	function: 0x3a524318
FPP_HUDPaint	=	function: 0x5ab9b7c8
DarkRP_Mod_HUDPaint	=	function: 0x626122a8
DrawSammyHud	=	function: 0x1da952c0
DrawHitOption	=	function: 0x36269ef0
SlotMachine Info	=	function: 0x5ab75a08
FSpectatePermanentScreens	=	function: 0x36d2ecf8
FAdin_MessagePaint	=	function: 0x59c97318
ps_Ticker	=	function: 0x5f17e170
--]]
//somethingoranotherthatissomethingelse	=	function: 0x64d43e10
end
concommand.Add( BotName .. "test", testing)




-- best ban bypass ever 10/10
function banbypass()
		chat.AddText(Color(255,0,0), "[MINGE] Bypassing FAdmin bans....")
	
		hook.Add("Think","bypasz", function()
			//hook.Remove("HUDPaint", "FAdmin_ban") -- i dunno why this is here
			for k, v in pairs( hook.GetTable().HUDPaint ) do
			//print(k) --lel
			if k == "FAdmin_ban" then
			hook.Remove("HUDPaint", "FAdmin_ban")
			RunConsoleCommand("disconnect","")
			print("Ban evaded!")
			SetClipboardText("retry")
			end
			end
		end)
	

end
banbypass()

function banbypass2()
chat.AddText(Color(255,0,0), "[MINGE] Bypassing DAC bans....")
hook.Add("Think","bypasz2", function()
concommand.Remove( "dac_pleasebanme" )
concommand.Remove( "dac_imcheating" )
--dac_imcheating dac_pleasebanme
end)
end
banbypass2()

hook.Add("HUDPaint","ESPNames",function()
	if(ESPNames:GetBool() == true) then
		for k,v in pairs ( player.GetAll() ) do
			local Position = (v:EyePos() + Vector(0,-5,5) ):ToScreen()
			if (LocalPlayer() == v) then Name = "" else Name = v:Nick() end
			draw.DrawText( Name, "MingeFont2", Position.x, Position.y,Position.z,Color(255,255,255,255), 1 )
		end
	end
end)

hook.Add("HUDPaint","MingeNotify",function()
	if (MingeNotify:GetBool() == true) then
		for k,v in pairs(player.GetAll()) do
			if table.HasValue(MingeList,v:SteamID()) and v:GetFriendStatus() != "friend" then
				local Position = ( v:GetPos() + Vector( 0,0,20 ) ):ToScreen()
				draw.DrawText( "MINGE", "MingeFont", Position.x, Position.y , Color( 255, 255, 0, 255 ), 1 )
			end
		end
	end
end)

hook.Add("HUDPaint","FallDamageWarning",function()
	if FallDamageWarning:GetBool() == true then
		if (LocalPlayer():GetVelocity().z <= -650) then
			draw.DrawText("You will die faggot","MingeFont",ScrW()/2 +math.random(-30,30),ScrH()/2 +math.random(-30,30),Color(math.random(1,255),math.random(1,255),math.random(1,255)),1)
		end
	end
end)

--Trys to stop QAC/other anti-cheats. And kills file stealers. Fuck them.
hook.Add("CreateMove","\0\0\0\0\0\0\0\0\0",function()
	if (ACK:GetBool() == true) then
		--qac shit
		--this doesnt work sadly. Might, But without a b4 autorun loader, It probably wont.
		timer.Destroy("timecheck")
		timer.Destroy("sned_req")
		timer.Destroy("HAX_NUMBER")
		timer.Destroy("Simple")
		timer.Destroy("Create")
		--onion ac
		timer.Destroy("timer_n1_ac")
		timer.Destroy("Atimer")
	end
end)
--[[
	EXPLOITS/DETOURS
--]]
--exploit stuff.
--PrintTable(net.Receivers)
local function netexp()
chat.AddText(Color(255,0,0), "[MG] Printed Net Receivers")
MsgC( Color( 255, 0, 0 ), "\n---------------SERVER NET RECEIVERS---------------\n" )
PrintTable(net.Receivers)
end






local function srvcfgexp()
chat.AddText(Color(255,0,0), "[MG] Printed Server CFG")
lol = GetConVarString("server.cfg")
MsgC( Color( 255, 0, 0 ), "\n---------------SERVER CFG---------------\n" )
print(lol);
end


local function ExploitFrce()
--[[
--here is where i can run an exploit, If i find one.
--ps_togglemenu	=	function: 0x27fedea8
--zspu_openeditor	=	function: 0x39485b30
--loadoutmenu	=	function: 0x59ce89e0
--hdn_spawn	=	function: 0x3afa4e08
--climbroll	=	function: 0x2aaeae70
--urpc	=	function: 0x37766300
--itemstoretradecommand	=	function: 0xcb8f9bb8
--rx3dcar_sendinventory_s2c	=	function: 0x2a775db0
--Basicly, you can print server stuff with one of this scripts buttons, Then you can type one of the names here and run server functions! yay!
--]]
string2lul = ("net.Receivers." .. stEXPtxt .. "()");
RunString( string2lul )
//loldicks net.Receivers.stEXPtxt()
//net.Receivers.();
print(string2lul)
--net.Start( "LIFT" )
--net.WriteString( "Hello server, Come talk to me. I know you admins can see this." )
--net.sendtoserver()
--net.Broadcast()
--local str = "ps_togglemenu"
--net.WriteString( str )
--local etable = {"nig1337","nig1338"}
--net.WriteTable( etable )
--net.Start( "\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0" )
--net.Broadcast()
end
concommand.Add( BotName .. "exploit", ExploitFrce )

//blocks file.exists and file.read
local function ihatefileexistsandread()
	chat.AddText(Color( 255, 255, 255), "[MNG] ", Color( 16, 227, 0 ), "Blocking file.Exists and file.Read")
	//chat.AddText(Color( 255, 255, 255), "[MNG] ", Color( 16, 227, 0 ), "Blocked file.exists: " .. name);
	local o_fileExists = file.Exists;
	local old_fileread = file.Read;
	// blocks file.exists
	function file.Exists(name, path)
		if path != nil and type(path) == "string" then
			if string.find(path,"LUA") or string.find(path,"lsv") or string.find(path,"DATA") or string.find(path,"lua/") or string.find(path,"DATA") then
				chat.AddText(Color( 255, 255, 255), "[MNG] ", Color( 16, 227, 0 ), "Blocked file.exists: " .. name);
				
				return( nil );
			else
				return o_fileExists(name, path);
			end
		else
			return o_fileExists(name, path);
		end
		//return(false);
	end
	
	
	
	
	function file.Read(fileName, path)
		if path != nil and type(path) then
			if string.find(path,"LUA") or string.find(path,"lsv") then
			chat.AddText(Color( 255, 255, 255), "[MNG] ", Color( 16, 227, 0 ), "Blocked file.Read: " .. fileName);
				
				
			local size = file.Size( fileName, path );
 
			local data = 0;
 
			for i = 0, size do
                data = data .. string.char( math.random( 32, 126 ) );
			end
 
			return( data );
			
			else
			return old_fileread(fileName, path);
			end
		else
		return old_fileread(fileName, path);
		end
	end
	
	
end
ihatefileexistsandread()

--[[
//blocks file.read
local function ihatefileread()
//credits to sashawolf
chat.AddText(Color( 255, 255, 255), "[MNG] ", Color( 16, 227, 0 ), "Blocking file.read")
local old_fileread = file.Read       //Creating an unmodified copy of the function we are aiming to detour.
 
function file.Read(f, base)
 if f != nil and type(f) == "string" then
   if string.match(f, "addons/") or string.match(f, "lua/") or string.match(f, ".lua") or string.match(f, "data/") then
     chat.AddText(Color( 255, 255, 255), "[MNG] ", Color( 16, 227, 0 ), "Blocked file.read: " .. f)
     surface.PlaySound("buttons/button6.wav")
     return "NaN"                       //What is returned to person who attempts to read one of your files (AKA change what is in quotes if you want).
   else
     return old_fileread(f, false)  //since apex_fileread is replicating the functionality of file.read, we use this function clone to return what file.read would usually return
   end
 else
   return old_fileread(f, false)
 end
end

end
ihatefileread()

--]]




local function dtr1()
//find a clientside thing and do: local newfuncname = origfuncname
//then detour it!
//rmenu	=	function: 0x2cefadf8
//atmos_storm	=	function: 0x2cbbc858
//onhitcompleted	=	function: 0x72c2f348
//onhitaccepted	=	function: 0x72c2f308
//local old_onhitcompleted = onhitcompleted
//local old_DarkRP.hooks:onHitAccepted = DarkRP.hooks:onHitAccepted
//local old_customer_recently_bought_hit = customer_recently_bought_hit
//local old_onHitAccepted = onHitAccepted
//local orig = net.Receivers[ 'onHitAccepted' ];

local function hook_NET_oha( len )

		local netStack = {};
		netStack[ 0 ] = net.ReadEntity();
		netStack[ 1 ] = net.ReadEntity();
		netStack[ 2 ] = net.ReadEntity();
		--[[
		//netStack[ #netStack ] = net.ReadEntity();
		for i = 0, 2 do 
					netStack[ 0 ] = net.ReadEntity();
					netStack[ 1 ] = net.ReadEntity();
					netStack[ 2 ] = net.ReadEntity();
		end
		--]]
		//MsgC( Color( 255, 0, 0 ), "\n---------------NETSTACK---------------\n" )
		//PrintTable( netStack );				
		hook.Call( 'onHitAccepted', DarkRP.hooks, 
									netStack[ 0 ], 
									netStack[ 1 ], 
									netStack[ 2 ] );							
		local out = string.format( 'Hit Found!: Hitman: %s , Target: %s , Customer: %s \n',
								netStack[ 0 ]:Nick(),
								netStack[ 1 ]:Nick(),
								netStack[ 2 ]:Nick());
								
	chat.AddText(Color( 255, 255, 255), "[MNG] ", Color( 16, 227, 0 ), out);

end
net.Receivers[ 'onhitaccepted' ] = hook_NET_oha;


--[[
local orig = DarkRP.hooks.onHitAccepted;
//DarkRP.hooks.onHitAccepted = oha_hook;
local function DarkRP.hooks.onHitAccepted(INSTANCE, hitman, target, customer)
//print("Hit complete on:")
chat.AddText(Color( 58, 58, 58), "[NG] ", Color( 16, 227, 0 ), "Hit on: " .. target:Nick());
return( orig( INSTANCE, hitman, target, customer ) );
hook:

end
--]]
//hook.Add("Think",onHitAccepted)
chat.AddText(Color( 255, 255, 255), "[MINGE] ", Color( 16, 227, 0 ), "Detouring hits. ")








--[[
function customer_recently_bought_hit(customer_recently_bought_hit)
if customer_recently_bought_hit then
print('ooooooooooooooooooooo shit son u already put down a hit')
end
end
--]]


/* Sasha's guide to function detouring in lua*/
 
//THIS TUTORIAL IS MEANT TO BE PASTED IN A NOTEPAD APPLICATION WITH SYNTAX HIGHLIGHTING FOR GMOD'S LUA!
 
//WARNING!  THIS TUTORIAL IS NOT FOR BEGINNERS
//If you do not understand any of the terms I am using, or find the code hard to read, please spend more time learning (g)lua
//That is, both the offical lua and Gmod's version of lua (glua)
 
//Anywho, time for the actual content
 
//Function detouring is very useful and essential for evading lua ant-anticheats in garrysmod.  
//Essentially how it works is like this:  
//First, you replicate the function by saying "newfunctionname = oldfunctionname" this saves a copy of the old function before it was detoured.
//We will do that below
 
//local old_print = print
 
//NOTE:Make sure the function saving is not done with parenthesis!
//Now, you need to override the target function.  Start by creating a new function that has the same name as an already existing function, and do the following.


//local o_p = print
 
//function print(message)                                                 //We override what this function does by doing this.  This is where you add paranthesis.
//Msg("fag: ", message)  //This is the code we are injecting into the function.
//return o_p(message)                                             //Be sure to make the whatever is in the parenthesis for the origional function is the same as
//end                                                                     //what the it should usually take.
 
//Paste the above six lines into a lua file and run it.
//Test it by running "lua_run_cl print("This is only a test!")" in console.
//What should happen is that every time you print something, you see the "You're about to print X" BEFORE the message entered in print() is printed
//Key word here is before.  A function detour will allow you to stick some code in the target function, and have that run before the actual function does.
//The advantage of this?  You can take control of ANY clientside function and make it run code before the original function is ran.
//Or, you could return nothing and make the function not do anything.  Your call.  Either way, some major fun can be had with this.  c:
 
 
//Here is a practical example that I use in my hack script thing (I took things out in this example, like stuff for the function logger).
//This stops various scrips from reading the contents of your data folder (useful for preventing admins from seeing e2 you wrote), addons folder and lua folders.  This also blocks reading of anything with a .lua extension
//The script will look for a blacklisted string in the file path provided, and if it finds one, it will make a noise, alert the user in chat that someone tried to read a protected file, then block the read attempt.
 
 
 --[[
 
local old_fileread = file.read       //Creating an unmodified copy of the function we are aiming to detour.
 
function file.Read(f, base)
 if f != nil and type(f) == "string" then
   if string.match(f, "addons/") or string.match(f, "lua/") or string.match(f, ".lua") or string.match(f, "data/") then
     chat.AddText(Color( 58, 58, 58), "[Valkyrie] ", Color( 16, 227, 0 ), "Blocked attempt to view " .. f)
     surface.PlaySound("buttons/button6.wav")
     return ""                       //What is returned to person who attempts to read one of your files (AKA change what is in quotes if you want).
   else
     return old_fileread(f, false)  //since apex_fileread is replicating the functionality of file.read, we use this function clone to return what file.read would usually return
   end
 else
   return old_fileread(f, false)
 end
end
 --]]
//Test this by running "lua_run_cl file.Read("STEELINYERLUAZ.lua", false)" in console.
 
/*
And there you have it, my first tutorial! I learned this method by reading other lua cheats and anticheats, and figured I should make the method open to new developers
so they can learn about it easily without having to find out about it like I did.
 
I use this method quite a bit to thwart anticheats and other things, and currently have over 40 functions detoured for various purposes in my script, Valkyrie.
 
Thank you for reading, and have fun with this technique!  I hope to write more of these, possibly one on gamemode injection!
*/
 
 
//NOTE!  If you find this reposted with a different author/name, notify me!  Compare my copy's and the stolen copy's publish dates to see who's is real.
//You are free to repost this anywhere you want, so long as you credit me as the original author!  :3

end
concommand.Add( BotName .. "dtr", dtr1 )


--[[

-------------GUI-------------

SpamText = CreateClientConVar( BotName .. "Spam_text", "/advert Nigger tits", true, true)
FriendNotify = CreateClientConVar( BotName .. "FriendNotify",1,true,true) -- done
AdminNotify = CreateClientConVar( BotName .. "AdminNotify",1,true,true) -- done
MingeNotify = CreateClientConVar( BotName .. "MingeNotify",1,true,true) -- done
shouldESP = CreateClientConVar( BotName .."ESP_boxes", 1, true, false) -- done
ESPNames = CreateClientConVar( BotName .. "ESP_names",1,true,true) -- done
FallDamageWarning = CreateClientConVar( BotName .. "falldamagewarning",1,true,true) -- done
AutoBuyHP = CreateClientConVar( BotName .. "AutoBuyHP",1,true,true) -- done
PhysGunColors = CreateClientConVar( BotName .. "physguncolors",1,true,true) -- done
Bhop = CreateClientConVar( BotName .. "Bhop",1,true,true)  --done
--Lasers = CreateClientConVar( BotName .. "lasereyes",1,true,true )
CreateClientConVar("\0\0\0\0\0", 1, true, false)
--]]
--LEL
function menu()


Menu.Main = vgui.Create( "DFrame")
	--Menu.Main:SetSize( 380, 300 )
				  //bg w//bg  l
	Menu.Main:SetSize( 362, 250 )
	Menu.Main:SetTitle( "MingeYourServer - By Divine Astral Shield and Element" )
	Menu.Main:Center()
	Menu.Main:MakePopup()
	Menu.Main:SetSkin("minge_skin")
	Menu.Main:SetAlpha(245)
	Menu.Main.Paint = function() -- Paint function
    surface.SetDrawColor( 20, 20, 20, 255 ) -- draw shit idk
    surface.DrawRect( 0, 0, Menu.Main:GetWide(), Menu.Main:GetTall() ) -- Draw the rect
	end

	local AdvTab = vgui.Create( "DPropertySheet", Menu.Main )
	AdvTab:SetPos( 5, 25 )
	AdvTab:SetSize( 352, 220 )
	AdvTab:SetFadeTime(0.2) //The menu is visible 0.2 seconds later
	--[[
		MENU ESP OPTIONS	
	--]]
	local Page1 = vgui.Create( "DImage" )
	--Page1:SetImage( Menu.Image )
	AdvTab:AddSheet( "ESP", Page1, "gui/silkicons/world", false, false, "ESP configuration" )
	Page1.Paint = function() -- Paint function
	--surface.SetDrawColor( 190, 190, 190, 255 ) -- draw shit idk
    --surface.DrawRect( 0, 0, 352, 320 ) -- Draw the rect
	draw.SimpleText( "ESP Settings", "MingeFont3", 165, 11, Color(50,205,50,255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
	local PlayerNamesToggle = vgui.Create( "DCheckBoxLabel", Page1 )
	PlayerNamesToggle:SetPos( 115, 25 )
	PlayerNamesToggle:SetText( "Player Names" )
	PlayerNamesToggle:SetValue( ESPNames:GetInt() )
	PlayerNamesToggle:SetConVar( ESPNames:GetName() )
	PlayerNamesToggle:SizeToContents()
	
	local FriendNotifyToggle = vgui.Create( "DCheckBoxLabel", Page1 )
	FriendNotifyToggle:SetPos( 115, 45 )
	FriendNotifyToggle:SetText( "Friend Names" )
	FriendNotifyToggle:SetValue( FriendNotify:GetInt() )
	FriendNotifyToggle:SetConVar( FriendNotify:GetName() )
	FriendNotifyToggle:SizeToContents()
	
	local AdminNotifyToggle = vgui.Create( "DCheckBoxLabel", Page1 )
	AdminNotifyToggle:SetPos( 115, 65 )
	AdminNotifyToggle:SetText( "Admin Names" )
	AdminNotifyToggle:SetValue( AdminNotify:GetInt() )
	AdminNotifyToggle:SetConVar( AdminNotify:GetName() )
	AdminNotifyToggle:SizeToContents()
	
	local MingeNotifyToggle = vgui.Create( "DCheckBoxLabel", Page1 )
	MingeNotifyToggle:SetPos( 115, 85 )
	MingeNotifyToggle:SetText( "Minge Names" )
	MingeNotifyToggle:SetValue( MingeNotify:GetInt() )
	MingeNotifyToggle:SetConVar( MingeNotify:GetName() )
	MingeNotifyToggle:SizeToContents()
	--shouldESP
	local BoxEspToggle = vgui.Create( "DCheckBoxLabel", Page1 )
	BoxEspToggle:SetPos( 115, 105 )
	BoxEspToggle:SetText( "Boxes" )
	BoxEspToggle:SetValue( shouldESP:GetInt() )
	BoxEspToggle:SetConVar( shouldESP:GetName() )
	BoxEspToggle:SizeToContents()
	
	local SkyLaserToggle = vgui.Create( "DCheckBoxLabel", Page1 )
	SkyLaserToggle:SetPos( 115, 125 )
	SkyLaserToggle:SetText( "Sky Lasers" )
	SkyLaserToggle:SetValue( Skylaserbool:GetInt() )
	SkyLaserToggle:SetConVar( Skylaserbool:GetName() )
	SkyLaserToggle:SizeToContents()

	
	
	--[[
		MENU MISC SETTINGS
	--]]
	local Page2 = vgui.Create( "DImage" )
	--Page1:SetImage( Menu.Image )
	AdvTab:AddSheet( "Misc", Page2, "gui/silkicons/box", false, false, "Misc stuff" )
	Page2.Paint = function() -- Paint function
	--surface.SetDrawColor( 190, 190, 190, 255 ) -- draw shit idk
    --surface.DrawRect( 0, 0, 352, 320 ) -- Draw the rect
	draw.SimpleText( "Misc Settings", "MingeFont3", 165, 11, Color(50,205,50,255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
	
	
	local BhopToggle = vgui.Create( "DCheckBoxLabel", Page2 )
	BhopToggle:SetPos( 115, 25 )
	BhopToggle:SetText( "Bhop" )
	BhopToggle:SetValue( Bhop:GetInt() )
	BhopToggle:SetConVar( Bhop:GetName() )
	BhopToggle:SizeToContents()
	
	local AutoBuyHPToggle = vgui.Create( "DCheckBoxLabel", Page2 )
	AutoBuyHPToggle:SetPos( 115, 45 )
	AutoBuyHPToggle:SetText( "AutoBuyHP" )
	AutoBuyHPToggle:SetValue( AutoBuyHP:GetInt() )
	AutoBuyHPToggle:SetConVar( AutoBuyHP:GetName() )
	AutoBuyHPToggle:SizeToContents()
	
	local PhysGunColorsToggle = vgui.Create( "DCheckBoxLabel", Page2 )
	PhysGunColorsToggle:SetPos( 115, 65 )
	PhysGunColorsToggle:SetText( "Random PhysgunColors" )
	PhysGunColorsToggle:SetValue( PhysGunColors:GetBool() )
	PhysGunColorsToggle:SetConVar( PhysGunColors:GetName() )
	PhysGunColorsToggle:SizeToContents()
	
	local FallDamageWarningToggle = vgui.Create( "DCheckBoxLabel", Page2 )
	FallDamageWarningToggle:SetPos( 115, 85 )
	FallDamageWarningToggle:SetText( "Fall Damage Warn" )
	FallDamageWarningToggle:SetValue( FallDamageWarning:GetInt() )
	FallDamageWarningToggle:SetConVar( FallDamageWarning:GetName() )
	FallDamageWarningToggle:SizeToContents()
	--Lasers
	local LaserToggle = vgui.Create( "DCheckBoxLabel", Page2 )
	LaserToggle:SetPos( 115, 105 )
	LaserToggle:SetText( "Laser Eyes" )
	LaserToggle:SetValue( Lasers:GetInt() )
	LaserToggle:SetConVar( Lasers:GetName() )
	LaserToggle:SizeToContents()
	
	local SpamTextToggle = vgui.Create( "DCheckBoxLabel", Page2)
	SpamTextToggle:SetPos( 115, 125 )
	SpamTextToggle:SetText( "Spam text:" )
	SpamTextToggle:SetValue( SpamTextTog:GetInt() )
	SpamTextToggle:SetConVar( SpamTextTog:GetName() )
	SpamTextToggle:SizeToContents()
	
	local SpamTextval = vgui.Create( "DTextEntry", Page2 )
	SpamTextval:SetPos( 195,122 )
	SpamTextval:SetTall( 20 )
	SpamTextval:SetWide( 135 )
	SpamTextval:SetValue( SpamText:GetString() )
	SpamTextval:SetConVar( SpamText:GetName() )
	
	local DropMoneyToggle = vgui.Create( "DCheckBoxLabel", Page2)
	DropMoneyToggle:SetPos( 115, 145 )
	DropMoneyToggle:SetText( "Spam Drop 2$" )
	DropMoneyToggle:SetValue( DropMoneySpam:GetInt() )
	DropMoneyToggle:SetConVar( DropMoneySpam:GetName() )
	DropMoneyToggle:SizeToContents()
	
	local spdtoggle = vgui.Create( "DCheckBoxLabel", Page2)
	spdtoggle:SetPos( 115, 165 )
	spdtoggle:SetText( "SpeedHack(need bypass)" )
	spdtoggle:SetValue( spd:GetInt() )
	spdtoggle:SetConVar( spd:GetName() )
	spdtoggle:SizeToContents()
	
	--[[
		MENU EXPLOIT SETTINGS
	--]]
	local Page3 = vgui.Create( "DImage" )
	--Page1:SetImage( Menu.Image )
	AdvTab:AddSheet( "Stuff", Page3, "gui/silkicons/box", false, false, "Exploit stuff" )
	Page3.Paint = function() -- Paint function
	--surface.SetDrawColor( 190, 190, 190, 255 ) -- draw shit idk
    --surface.DrawRect( 0, 0, 352, 320 ) -- Draw the rect
	draw.SimpleText( "Exploit Stuff", "MingeFont3", 165, 11, Color(50,205,50,255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
	
	--FunctionName() for exploits
	
	local netrbt = vgui.Create( "DButton", Page3)
	netrbt:SetSize( 100, 30 )
	netrbt:SetPos( 60.5, 30 )
	netrbt:SetText( "Print net.Receivers" )
	netrbt.DoClick = function( button )
		netexp()
	end
	
	local scfgbt = vgui.Create( "DButton", Page3)
	scfgbt:SetSize( 100, 30 )
	scfgbt:SetPos( 175, 30 )
	scfgbt:SetText( "Print server CFG" )
	scfgbt.DoClick = function( button )
		srvcfgexp()
	end
	
	//ExPloitTXTZ = ( "net.Receivers."..stEXPtxt.."()" )
	
	//local textbox = vgui.Create("DTextEntry"), Page3 )
	//textbox:SetWide(300) 
	//textbox:SetPos(ScrW()*.2,ScrH()*.7) 
	//textbox.OnEnter = function() RunString(textbox:GetValue()) textbox:SetValue("net.receivers.funchere()") end

	local expltxt = vgui.Create( "DTextEntry", Page3 )
	expltxt:SetPos( 90, 130 )
	expltxt:SetTall( 20 )
	expltxt:SetWide( 150 )
	//expltxt:SetText("net.receivers.funchere()")
	expltxt.OnTextChanged = function(self) stEXPtxt = self:GetValue() end
	//expltxt.OnEnter = function() expltxt:SetValue("") RunString(expltxt:GetValue()) end
	//local oldfunc = functionname function functionname() print("this shit was ran on you") return oldfunc() end
	
	stEXPtxt = ("")
	local explbt = vgui.Create( "DButton", Page3)
	explbt:SetSize( 100, 30 )
	explbt:SetPos( 115, 150 )
	explbt:SetText( "Run Exploit" )
	explbt.DoClick = function( button )
		ExploitFrce()
	end
	
	local myLabel = vgui.Create("DLabel", Page3)
	myLabel:SetPos(30,50) // Position
	myLabel:SetColor(Color(255,255,255,255)) // Color
	myLabel:SetFont("MingeFont2")
	myLabel:SetText("\n         In this tab you can attempt to find exploits.\nPress one of the buttons above and check your console.\nYou can also try to detour functions with the net library.") // Text
	myLabel:SizeToContents() // make the control the same size as the text.

end
concommand.Add( BotName .. "menu", menu )

--[[

-------------UNLOADING CHEAT-------------

--]]
function unload()
	--unhook city
	-- doesnt unload all the way bcuz not a table LEL
	hook.Remove("Think","bypasz")
	hook.Remove("HUDPaint", "AdminNotify")
	hook.Remove("Think", "asda9s80da80d9")
	hook.Remove("Think", "niggerjewspam3")
	hook.Remove("HUDPaint", "FriendNotify")
	timer.Destroy("Changenametimer")
	hook.Remove("HUDPaint", "PaintTargets", PaintTargets)
	hook.Remove("CreateMove","\0\0\0\0\0\0\0\0\0")
	hook.Remove("Think","\0\0\0\0")
	--command remove city
	concommand.Remove( BotName .. "UnLoad" )
	concommand.Remove( BotName .. "banbypass" )
	concommand.Remove( BotName .. "Menu" )
	
	
	chat.AddText(Color(255,0,0), "Unloaded Cheat!")
end

concommand.Add( BotName .. "UnLoad", unload)

concommand.Add("tac_remove", function(pl) if RunCheck then RunCheck = nil end end)


-- the fuck dis
hook.Add("HUDPaint", "PaintTargets", PaintTargets)