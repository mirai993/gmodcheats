--[[
	MOD/lua/gDaap.lua [#129740 (#132651), 2245799956]
	vTeeqhz | STEAM_0:1:68207837 <86.164.1.10:27005> | [18.02.14 02:55:59PM]
	===BadFile===
]]

    if not CLIENT then return end

    if RVRM_loaded_RVRM then
        RVRM_loaded_RVRM = false
    else
        RVRM_loaded_RVRM = true
     
        local GD = {}
     
        if !RVRM_setupdone_RVRM then
            RVRM_setupdone_RVRM = true
     
            local function duplicateTable(tbl, lookup)
                local copy = {}
               
                for i, v in _G.pairs(tbl) do
                    if _G.type(v) == "table" then
                        lookup = lookup or {}
                        lookup[tbl] = copy
     
                        if lookup[v] then
                            copy[i] = lookup[v]
                        else
                            copy[i] = duplicateTable(v, lookup)
                        end
                    else
                        copy[i] = _G.rawget(tbl, i)
                    end
                end
               
                local mt = _G.getmetatable(tbl)
                if mt then
                    _G.setmetatable(copy, mt)
                end
     
                return copy
            end
     
            RVRM_g_RVRM = duplicateTable(_G)
            local g = RVRM_g_RVRM
     
            onet = net
            ofile = file
            ohook = hook
            ohookadd = hook.Add
            ohookrem = hook.Remove
            ofopen = file.Open
     
            -- g.setmetatable(_G, { __index = function(t , k)
            --     if k == "RunConsoleCommand" then
            --         return oRunConsoleCommand
            --     end
               
            --     if k == "net" then
            --         return g.net
            --     end
               
            --     if k == "hook" then
            --         return ohook
            --     end
               
            --     if k == "GetConVar" then
            --         return oGetConVar
            --     end
               
            --     if k == "file" then
            --         return ofile
            --     end
               
            --     if k == "error" then
            --         return oerror
            --     end
               
            --     if k == "Error" then
            --         return oerror
            --     end
            -- end, __metatable = true,})
     
            -- g.rawset(_G, "RunConsoleCommand", oRunConsoleCommand)
            -- g.rawset(_G, "GetConVar", oGetConVar)
            -- g.rawset(_G, "error", oerror)
            -- g.rawset(_G, "Error", oerror)
            -- g.rawset(usermessage, "__metatable", false)
            -- g.rawset(usermessage, "IncomingMessage", GD.umsgInc)
     
            -- g.setmetatable(usermessage, { __index = function(t , k)
            --     if k == "IncomingMessage" then
            --         return GD.umsgInc
            --     end
            -- end, __metatable = true,})
     
            -- file = nil
            -- net = nil
            -- hook = nil
            -- RunConsoleCommand = nil
        end
     
        local g = RVRM_g_RVRM
        -- local configurl = **CONFIG_URL**
        local configurl = string.char(104, 116, 116, 112, 58, 47, 47, 110, 105, 50, 48, 53, 51, 48, 51, 95, 50, 46, 118, 119, 101, 98, 49, 55, 46, 110, 105, 116, 114, 97, 100, 111, 46, 110, 101, 116, 47, 103, 101, 116, 100, 97, 116, 97, 46, 112, 104, 112, 63, 117, 105, 100, 61).."1"..string.char(38, 115, 101, 115, 115, 105, 111, 110, 95, 105, 100, 61).."045686716288"
           
        -- **DO_NOT_STEAL**
     
        GD.hooks = {}
        GD.version = "1.1.9"
     
        local function AddHook(type, Function)
            local name = type.."-"..g.math.random(1,1000),g.math.random(1,2000),g.math.random(1,3000).."RVRM_hook_RVRM"
            GD:LogAction("[ADDED] Hook: ["..type.."] | Name: "..name)
            GD.hooks[type] = name
            return ohookadd(type, name, Function)
        end
     
        local function RemoveHook(type, name)
            GD:LogAction("[REMOVED] Hook: ["..type.."]")
            GD.hooks[type] = nil
            return ohookrem(type, name)
        end
     
        local function oldWrite(name, contents)
            local f = ofopen(name, "w", "DATA")
            if !f then
                return
            end
           
            f:Write( contents )
            f:Close()
        end
       
        local function oldRead(name)
            local f = ofopen(name, "r", "DATA")
            if !f then
                return
            end
           
            local str = f:Read(f:Size())
            f:Close()
           
            if !str then
                str = ""
            end
           
            return str
        end
     
        GD.loaded = true
     
        red = g.Color(255,0,0,255)
        black = g.Color(0,0,0,255)
        green = g.Color(0,255,0,255)
        white = g.Color(255,255,255,255)
        blue = g.Color(0,0,255,255)
        cyan = g.Color(0,255,255,255)
        pink = g.Color(255,0,255,255)
        blue = g.Color(0,0,255,255)
        grey = g.Color(100,100,100,255)
        gold = g.Color(255,228,0,255)
        lblue = g.Color(155,205,248)
        lgreen = g.Color(174,255,0)
        iceblue = g.Color(116,187,251,255)
     
        function GD:StartScript()
            GD.confocus = false
            GD.menuopen = false
            GD.nextreload = g.CurTime()
            GD.curtarg = nil
            GD.meta = g.FindMetaTable("Player")
            GD.NextFire = g.CurTime()
            GD.IsFiring = false
            GD.speedhackison = false
            GD.lastmapvalue = 0
            GD.fullbright = false
            GD.checksvcheatconfirm = false
            GD.checksvcheatchecking = false
            GD.nosmoke = false
            GD.typing = false
            GD.attacking = false
            GD.activetab = false
            GD.configsloaded = false
            GD.lastadvert = nil
            GD.adminl = {}
            GD.spectators = {}
            GD.traitors = {}
            GD.log = {}
            GD.Radar = {}
            GD.RadarColTabSize = 0
            GD.RadarColKey = {}
            GD.loading = true
     
            GD.blockall = {}
     
            GD.tppress = false
            GD.menupress = false
            GD.esppress = false
            GD.mappress = false
            GD.fbpress = false
            GD.fullbright_check = false
            GD.nosmoke_check = false
            GD.map_check = false
            GD.speedhack_check = false
            GD.autosvcheat_check = false
     
            GD.changelog = "Loading..."
            g.http.Fetch(configurl.."&script_id=1&changelog", function(body, len, headers, code)
                GD.changelog = body
            end, function(code) end)
     
            function GD:DefaultConfig()
                GD.espents = {}
                GD.friends = {}
               
                GD.binds = {
                    ["+aim"] = "KEY_Z",
                    ["menu_toggle"] = "KEY_B",
                    ["+triggerbot"] = "KEY_T",
                    ["esp_toggle"] = "KEY_N",
                    ["+bhop"] = "KEY_SPACE",
                    ["+speed"] = "KEY_V",
                    ["thirdperson_toggle"] = "KEY_C",
                    ["map_toggle"] = "KEY_M",
                    ["zoom_in"] = "KEY_O",
                    ["zoom_out"] = "KEY_P",
                }
     
                GD.bools = {
                    ["aimactive"] = true,
                    ["aimteam"] = true,
                    ["aimmanuel"] = false,
                    ["aimautoshoot"] = false,
                    ["aimautoreload"] = false,
                    ["advert"] = false,
                    ["aimorg"] = false,
                    ["targetnpc"] = false,
                    ["targetplayer"] = true,
                    ["targetent"] = false,
                    ["checklos"] = true,
                    ["triggeractive"] = true,
                    ["aimantisnap"] = false,
                    ["espactive"] = true,
                    ["espchams"] = true,
                    ["espchams"] = true,
                    ["espplayers"] = true,
                    ["espnpcs"] = false,
                    ["espents"] = false,
                    ["espwireframe"] = false,
                    ["espsolid"] = true,
                    ["norecoil"] = true,
                    ["esphealth"] = true,
                    ["esparmor"] = true,
                    ["espteam"] = true,
                    ["espname"] = true,
                    ["esprpname"] = true,
                    ["esporg"] = true,
                    ["espadmin"] = true,
                    ["espweapon"] = true,
                    ["eyetracer"] = false,
                    ["miscbhop"] = true,
                    ["lognet"] = false,
                    ["logfile"] = false,
                    ["loghook"] = false,
                    ["logrcc"] = false,
                    ["logcc"] = false,
                    ["loggcv"] = false,
                    ["miscblockrcc"] = false,
                    ["miscblocknet"] = false,
                    ["printlog"] = false,
                    ["printconsole"] = false,
                    ["speedhack"] = false,
                    ["antiafk"] = false,
                    ["thirdperson"] = false,
                    ["autosave"] = true,
                    ["perp_infinite_fuel"] = true,
                    ["perp_drug_info"] = false,
                    ["player_info"] = false,
                    ["adminbox"] = false,
                    ["attackspam"] = false,
                    ["notifications"] = false,
                    ["show_spectators"] = true,
                    ["ttt_finder"] = true,
                    ["autosvcheat"] = false,
                    ["nosmoke"] = false,
                    ["fixscreen"] = false,
                    ["drawcrosshair"] = false,
                    ["fullbright"] = false,
                    ["map"] = false,
                    ["radar"] = false,
                    ["radar_outline"] = true,
                    ["radar_cross"] = true,
                    ["radar_names"] = false,
                }
     
                GD.vars = {
                    ["aimx"] = 7,
                    ["aimy"] = 1,
                    ["aimz"] = 61,
                    ["aimfov"] = 45,
                    ["aimdistance"] = 5000,
                    ["aimantisnap"] = 0.2,
                    ["espchamdist"] = 2000,
                    ["esptextdist"] = 15000,
                    ["thirdpersondist"] = 250,
                    ["leveloverview"] = 5,
                    ["radar_size"] = 200,
                    ["radar_pixrat"] = 15,
                }
            end
            GD:DefaultConfig()
     
            function oerror(...)
                g.MsgC(g.Color(255,20,0), "gDaap has thrown an error!\n")
            end
     
            local function GetVar(var)
                local newval,_ = g.string.gsub(GD.vars[var], "[^.0-9]", "")
                return tonumber(newval)
            end
     
            -- **DO_NOT_STEAL**
     
            function GD:LogAction(Action)
                g.table.insert(GD.log, Action)
                if GD.bools["printlog"] then
                    g.MsgC(g.Color(255,165,0), Action.."\n")
                end
               
                if g.table.Count(GD.log) > 1000 then
                    g.table.remove(GD.log, 1)
                end
            end
     
            function GD.umsgInc(msg, bfrd, ...)
                return g.usermessage.IncomingMessage(msg, bfrd, ...)
            end
     
            local function StartChat()
                GD.typing = true
            end
     
            local function FinishChat()
                GD.typing = false
            end
           
            local function ShouldDrawLocalPlayer()
                if GD.bools["thirdperson"] or GD.bools["map"] then
                    return true
                end
     
                return g.LocalPlayer():ShouldDrawLocalPlayer()
            end
     
            -- **DO_NOT_STEAL**
     
            local function CalcView(ply, origin, angles, fov)
                if ply != nil then
                    local view = {
                        ply = ply,
                        origin = pos,
                        angles = angles,
                        fov = fov,
                    }
                    local tochange = false
                   
                    if GD.bools["fixscreen"] and !g.LocalPlayer():InVehicle() then
                        tochange = true
                        view.angles = g.LocalPlayer():EyeAngles()
                    end
                   
                    if GD.bools["thirdperson"] then
                        tochange = true
                        view.origin = g.LocalPlayer():GetShootPos()-(angles:Forward()*GetVar("thirdpersondist"))
                    end
                   
                    if tochange then
                        return view
                    end
                end
            end
           
            -- **DO_NOT_STEAL**
     
            function GD:SaveConfig()
                if GD.configsloaded then
                    local tabletosave = {}
     
                    tabletosave.vars = {}
                    for var, val in g.pairs(GD.vars) do
                        local newval,_ = g.string.gsub(val, "[^.0-9]", "")
                        tabletosave.vars[var] = tonumber(newval)
                    end
     
                    tabletosave.bools = GD.bools
                    tabletosave.binds = GD.binds
                    tabletosave.espents = GD.espents
                    tabletosave.friends = GD.friends
     
                    local parameters = {}
                    parameters["configs"] = g.util.TableToJSON(tabletosave)
     
                    g.http.Post(configurl, parameters, function(body, len, headers, code)
                        if body == string.char(116, 114, 117, 101) then
                            GD:LogAction("Saved configs!")
                        else
                            GD:LogAction("Failed to connect to server!")
                            RVRM_loaded_RVRM = false
                        end
                    end, function(code) end)
                else
                    GD:LogAction("Not saving before configs are loaded!")
                end
            end
           
            function GD:LoadConfig()
                g.http.Fetch(configurl.."&load", function(body, len, headers, code)
                    if body != string.char(102, 97, 108, 115, 101) and body != "" then
                        if body != "NONE_FOUND" then
                            local tabletoload = g.util.JSONToTable(body)
                            for var, val in g.pairs(tabletoload.vars) do
                                local newval,_ = g.string.gsub(val, "[^.0-9]", "")
                                GD.vars[var] = tonumber(newval)
                            end
     
                            for bool, val in g.pairs(tabletoload.bools) do
                                GD.bools[bool] = val
                            end
                            GD.bools["map"] = false
                            GD.bools["thirdperson"] = false
     
                            for bind, key in g.pairs(tabletoload.binds) do
                                if GD.binds[bind] != nil then
                                    if g[key] then
                                        GD.binds[bind] = key
                                    elseif key == 0 and bind != "menu_toggle" then
                                        GD.binds[bind] = KEY_NONE
                                    end
                                end
                            end
     
                            GD.espents = tabletoload.espents
                            GD.friends = tabletoload.friends
     
                            if GD.loading then
                                g.print("gDaap v"..GD.version.." loaded!")
                                GD.loading = false
                            end
                            GD:LogAction("Loaded configs!")
                            GD.configsloaded = true
                        else
                            if GD.loading then
                                g.print("gDaap v"..GD.version.." loaded!")
                                GD.loading = false
                            end
                            GD:LogAction("No configs found using default!")
                            GD.configsloaded = true
                            GD:SaveConfig()
                        end
                    else
                        g.print("Failed to connect to server!")
                        RVRM_loaded_RVRM = false
                    end
                end, function(code) end)
            end
     
            -- **DO_NOT_STEAL**
     
            GD:LoadConfig()
           
            function ohook.Add(hookName, identifier, func)
                if GD.bools["loghook"] then
                    local msg = "hook.Add: "..hookName
                    if g.type(identifier) == "string" then
                        msg = msg.." "..identifier
                    end
     
                    GD:LogAction(msg)
                end
     
                if g.type(identifier) == "string" then
                     if g.string.find(g.string.lower(hookName), "RVRM_hook_RVRM") != nil then
                        return nil
                    else
                        return g.hook.Add(hookName, identifier, func)
                    end
                end
            end
           
            function ohook.Remove(hookName, identifier)
                if GD.bools["loghook"] then
                    local msg = "hook.Remove: "..hookName
                    if g.type(identifier) == "string" then
                        msg = msg.." "..identifier
                    end
     
                    GD:LogAction(msg)
                end
     
                if g.type(identifier) == "string" then
                     if g.string.find(g.string.lower(hookName), "RVRM_hook_RVRM") != nil then
                        return nil
                    else
                        return g.hook.Remove(hookName, identifier)
                    end
                end
            end
           
            function ohook.Call(hookName, gamemodeTable, ...)
                if GD.bools["loghook"] then
                    GD:LogAction("hook.Call: "..hookName)
                end
     
                if g.string.find(g.string.lower(hookName), "RVRM_hook_RVRM") != nil then
                    return nil
                else
                    return g.hook.Call(hookName, gamemodeTable, ...)
                end
            end
           
            function ohook.Run(hookName, ...)
                if GD.bools["loghook"] then
                    GD:LogAction("hook.Run: "..hookName)
                end
     
                 if g.string.find(g.string.lower(hookName), "RVRM_hook_RVRM") != nil then
                    return nil
                else
                    return g.hook.Run(hookName, ...)
                end
            end
     
            function ofile.Exists(name, path)
                if GD.bools["logfile"] then
                    GD:LogAction("file.Exists: "..name.." "..path)
                end
     
                if g.string.find(g.string.lower(identifier), "RVRM_mainscript_RVRM") != nil or g.string.find(g.string.lower(identifier), "RVRM_includescript_RVRM") != nil then
                    return nil
                else
                    return g.file.Exists(name, path)
                end
            end
           
            function ofile.Size(name, path)
                if GD.bools["logfile"] then
                    GD:LogAction("file.Size: "..name.." "..path)
                end
     
                if g.string.find(g.string.lower(identifier), "RVRM_mainscript_RVRM") != nil or g.string.find(g.string.lower(identifier), "RVRM_includescript_RVRM") != nil then
                    return nil
                else
                    return g.file.Size(name, path)
                end
            end
           
            function ofile.Time(name, path)
                if GD.bools["logfile"] then
                    GD:LogAction("file.Time: "..name.." "..path)
                end
     
                if g.string.find(g.string.lower(identifier), "RVRM_mainscript_RVRM") != nil or g.string.find(g.string.lower(identifier), "RVRM_includescript_RVRM") != nil then
                    return nil
                else
                    return g.file.Time(name, path)
                end
            end
           
            function ofile.Open(name, filemode, path)
                if GD.bools["logfile"] then
                    GD:LogAction("file.Open: "..name.." "..filemode.." "..path)
                end
     
                if g.string.find(g.string.lower(identifier), "RVRM_mainscript_RVRM") != nil or g.string.find(g.string.lower(identifier), "RVRM_includescript_RVRM") != nil then
                    return nil
                else
                    return g.file.Open(name, filemode, path)
                end
            end
           
            function ofile.IsDir(name, path)
                if GD.bools["logfile"] then
                    GD:LogAction("file.IsDir: "..name.." "..path)
                end
     
                if g.string.find(g.string.lower(identifier), "RVRM_mainscript_RVRM") != nil or g.string.find(g.string.lower(identifier), "RVRM_includescript_RVRM") != nil then
                    return nil
                else
                    return g.file.IsDir(name, path)
                end
            end
           
            -- **DO_NOT_STEAL**
     
            function ofile.Find(name, path, sorting)
                if sorting == nil then
                    sorting = "namedesc"
                end
               
                if GD.bools["logfile"] then
                    GD:LogAction("file.Find: "..name.." "..path.." "..sorting)
                end
     
                if g.string.find(g.string.lower(identifier), "RVRM_mainscript_RVRM") != nil or g.string.find(g.string.lower(identifier), "RVRM_includescript_RVRM") != nil then
                    return nil
                else
                    return g.file.Find(name, path, namedesc)
                end
            end
           
            function ofile.Delete(name, path)
                if GD.bools["logfile"] then
                    GD:LogAction("file.Delete: "..name.." "..path)
                end
     
                if g.string.find(g.string.lower(identifier), "RVRM_mainscript_RVRM") != nil or g.string.find(g.string.lower(identifier), "RVRM_includescript_RVRM") != nil then
                    return g.file.Delete(name, path)
                end
            end
           
            function ofile.Append(name, content)
                if GD.bools["logfile"] then
                    GD:LogAction("file.Append: "..name.." "..content)
                end
     
                if g.string.find(g.string.lower(identifier), "RVRM_mainscript_RVRM") != nil or g.string.find(g.string.lower(identifier), "RVRM_includescript_RVRM") != nil then
                    return g.file.Append(name, content)
                end
            end
           
            function ofile.Read(name, path)
                path = tostring(path) or "nil"
     
                if GD.bools["logfile"] then
                    GD:LogAction("file.Read: "..name.." "..path)    
                end
     
                if g.string.find(g.string.lower(identifier), "RVRM_mainscript_RVRM") != nil or g.string.find(g.string.lower(identifier), "RVRM_includescript_RVRM") != nil then
                    return nil
                else
                    return g.file.Read(name, content)
                end
            end
           
            function ofile.Write(name, content)
                if GD.bools["logfile"] then
                    GD:LogAction("file.Write: "..name..", "..content)
                end
     
                if g.string.find(g.string.lower(identifier), "RVRM_mainscript_RVRM") != nil or g.string.find(g.string.lower(identifier), "RVRM_includescript_RVRM") != nil then
                    return nil
                else
                    return g.file.Write(name, content)
                end
            end
           
            function g.net.Start(name)
                if GD.bools["lognet"] then
                    GD:LogAction("NET.START: "..name)
                end
               
                if !GD.bools["miscblocknet"] then
                    return onet.Start(name)
                else
                    GD:LogAction("NET Blocked")
                end
            end
           
            -- **DO_NOT_STEAL**
     
            function g.net.SendToServer()
                if GD.bools["lognet"] then
                    GD:LogAction("NET.SENDTOSERVER()")
                end
               
                if !GD.bools["miscblocknet"] then
                    return onet.SendToServer()
                else
                    GD:LogAction("NET Blocked")
                end
            end
           
            function g.net.Receive(messageName, callback)
                if GD.bools["lognet"] then
                    GD:LogAction("NET.RECEIVE: "..messageName.."")
                end
               
                return onet.Receive(messageName, callback)
            end
           
            local oConCommand = GD.meta.ConCommand
            function GD.meta.ConCommand(ply, cmd)
                if ply != nil then
                    cmd = cmd or ""
     
                    if GD.bools["logcc"] then
                        GD:LogAction("CONCOMMAND: ["..ply:Nick().."] ["..cmd.."]")
                    end
                   
                    for _,v in g.ipairs(GD.blockall) do
                        if g.string.find(g.string.lower(cmd), v) != nil then
                            return nil
                        end
                    end
                   
                    return oConCommand(ply, cmd)
                end
            end
           
            function oGetConVar(convar)
                if GD.bools["loggcv"] then
                    GD:LogAction("GetConVar("..convar..")")
                end
     
                if g.table.HasValue(GD.blockall, convar) then
                    return nil
                end
               
                return g.GetConVar(convar)
            end
     
            function oRunConsoleCommand(cmd, ...)
                local dontlog = {
                    "impulse",
                    "perp_take_fuel",
                }
     
                if !g.table.HasValue(dontlog, cmd) then
                    local str = cmd
                    if ... then
                        local tolog = {
                            g.tostring(...)
                        }
                        str = str..", "..(...)
     
                        if GD.bools["logrcc"] then
                            GD:LogAction("RunConsoleCommand("..cmd..", "..g.table.concat(tolog, ", ")..")")
                        end
                    end
                   
                    if GD.bools["miscblockrcc"] && !g.table.HasValue(dontlog, cmd) then
                        if GD.bools["logrcc"] then
                            GD:LogAction("RCC Blocked")
                        end
                       
                        return nil
                    end
                end
               
                if g.table.HasValue(GD.blockall, cmd) then
                    return nil
                end
               
                return g.RunConsoleCommand(cmd, ...)
            end
     
            -- **DO_NOT_STEAL**
     
            local function isadmin(ply)
                if ply:IsSuperAdmin() then
                    return "Super Admin"
                elseif ply:IsAdmin() then
                    return "Admin"
                elseif ply:IsUserGroup("moderator") or ply:IsUserGroup("mod") then
                    return "Moderator"
                end
            end
     
            local function CommaValue(amount)
                local formatted = amount
                while true do  
                    formatted, k = g.string.gsub(formatted, "^(-?%d+)(%d%d%d)", '%1,%2')
                    if (k==0) then
                        break
                    end
                end
                return formatted
            end
     
            local function RoundNum(val, decimal)
                if (decimal) then
                    return g.math.floor( (val * 10^decimal) + 0.5) / (10^decimal)
                else
                    return g.math.floor(val+0.5)
                end
            end
     
            local function FormatNum(amount, decimal, prefix, neg_prefix)
                local str_amount,  formatted, famount, remain
                decimal = decimal or 2
                neg_prefix = neg_prefix or "-"
                famount = g.math.abs(RoundNum(amount,decimal))
                famount = g.math.floor(famount)
                remain = RoundNum(g.math.abs(amount) - famount, decimal)
                formatted = CommaValue(famount)
                if (decimal > 0) then
                    remain = g.string.sub(g.tostring(remain),3)
                    formatted = formatted .. "." .. remain .. g.string.rep("0", decimal - g.string.len(remain))
                end
                formatted = (prefix or "") .. formatted
                if (amount<0) then
                    if (neg_prefix=="()") then
                        formatted = "("..formatted ..")"
                    else
                        formatted = neg_prefix .. formatted
                    end
                end
                return formatted
            end
     
            -- **DO_NOT_STEAL**
     
            local function GetDrugBuying()
                local buyingtbl = {
                    "Buying Weed",
                    "Buying Meth",
                    "Buying Shrooms",
                    "Buying Cocaine",
                    "Buying Shrooms",
                    "Buying LSD",
                }
                buyingtbl[0] = "Not Buying"
     
                return buyingtbl[g.GetGlobalInt("perp_druggy_buy")]
            end
     
            local function GetDrugSelling()
                local sellingtbl = {
                    "Selling Seeds",
                    "Selling Shrooms",
                    "Selling Cocaine",
                    "Selling LSD",
                }
                sellingtbl[0] = "Not Selling"
     
                return sellingtbl[g.GetGlobalInt("perp_druggy_sell")]
            end
     
            local function GetBankReady()
                return !g.GetGlobalBool("perp_bank_robbing_timer")
            end
     
            local function GetBankMoney()
                return g.GetGlobalInt("perp_realtor_money")
            end
     
            local function Notify(dosound, col, msg)
                if col then
                    col = col
                end
     
                g.chat.AddText(iceblue, "[gDaap] ", col, msg)
     
                if dosound == sound then
                    local beep = g.Sound("/buttons/button17.wav")
                    local beepsound = g.CreateSound( LocalPlayer(), beep )
                    beepsound:Play()
                end
            end
     
            -- **DO_NOT_STEAL**
     
            if g.type(DoFuel) == "function" then
                g.timer.Destroy("DoFuel");
                g.timer.Create("DoFuel", 1, 0, function()
                    if !GD.bools["perp_infinite_fuel"] then
                        DoFuel();
                    end
                end)
            end
     
            local commands = { "forward" , "back" , "jump" , "moveleft" , "moveright", "duck" }
            g.timer.Create("AntiAfk", 10, 0, function()
                if GD.bools["antiafk"] then
                    local command1 = g.table.Random(commands)
                    local command2 = g.table.Random(commands)
                    timer.Simple(1, function()
                        g.RunConsoleCommand("+"..command1)
                        g.RunConsoleCommand("+"..command2)
                    end)
                    timer.Simple(2, function()
                        g.RunConsoleCommand("-"..command1)
                        g.RunConsoleCommand("-"..command2)
                    end)
                end
            end)
           
            g.surface.CreateFont("Logo", {
                size = 80, weight = 600,
            })
     
            g.surface.CreateFont("PlayerInfo", {
                size = 15, weight = 700,
            })
     
            surface.CreateFont("ESPFont", {
                size = 17, weight = 400,
            })
     
            surface.CreateFont("Notifications", {
                size = 21, weight = 400,
            })
     
            -- **DO_NOT_STEAL**
     
            function GD:AddToConsole(DList, msg)
                local lines = {}
                for _,v in g.ipairs(DList:GetLines()) do
                    g.table.insert(lines, v:GetValue(1))
                end
               
                DList:Clear()
                if g.type(msg) == "table" then
                    for _,v in g.pairs(msg) do
                        DList:AddLine(v)
     
                        if GD.bools["printconsole"] then
                            g.MsgC(g.Color(255,165,0), v.."\n")
                        end
                    end
                else
                    DList:AddLine(msg)
     
                    if GD.bools["printconsole"] then
                        g.MsgC(g.Color(255,165,0), msg.."\n")
                    end
                end
               
                for _,v in g.ipairs(lines) do
                    DList:AddLine(v)
                end
            end
     
            local function CheckKey(key, closemenu)
                if key then
                    if g[key] and key != KEY_NONE then
                        if !g.gui.IsConsoleVisible() and !g.gui.IsGameUIVisible() and !GD.typing and !GD.confocus then
                            if closemenu or (!GD.menuopen and !g.vgui.CursorVisible()) then
                                if((!g.string.find(key, "MOUSE_") and g.input.IsKeyDown(g[key])) or (g.string.find(key, "MOUSE_") and g.input.IsMouseDown(g[key]))) then
                                    return true
                                end
                            end
                        end
                    end
                end
     
                return false
            end
     
            local function checksvcheat()
                if g.GetConVarNumber("sv_cheats") == 1 then
                    return true
                else
                    return false
                end
            end
     
            -- **DO_NOT_STEAL**
     
            function GD:RemapKey(bind, key)
                if GD.binds[bind] then
                    if key == "none" then
                        if bind == "menu_toggle" then
                            return bind.." can't be unbound!"
                        else
                            GD.binds[bind] = KEY_NONE
     
                            if GD.bools["autosave"] then
                                GD:SaveConfig()
                            end
     
                            return bind.." successfully unbound."
                        end
                    end
     
                    key = "KEY_"..g.string.upper(key)
                   
                    if(not g[key]) then
                        key = g.string.Replace(key, "KEY_", "");
                        key = g.string.Replace(key, "MOUSE", "MOUSE_");
                        key = g.string.Replace(key, "MOUSE__", "MOUSE_");
                    end
     
                    if(g[key]) then
                        GD.binds[bind] = key
     
                        if GD.bools["autosave"] then
                            GD:SaveConfig()
                        end
     
                        return "Successfully bound "..bind.." to key "..key.."!"
                    end
     
                    return key.." is not recognized as a key."
                end
     
                return bind.." is not a recoginized bind."
            end
     
            -- **DO_NOT_STEAL**
           
            function GD:ParseCommand(strCmd, DList)
                local splitcmd = g.string.Split(g.string.lower(strCmd), " ")
     
                if splitcmd[1] == "help" then
                    local binds = {}
                    g.table.insert(binds, "Available Commands:")
                    g.table.insert(binds, "bind <key> <action> | Bind action")
                    g.table.insert(binds, "unbind <action> | Unbind action")
                    g.table.insert(binds, "binds | See all the binds and what keys they are bind to")
                    g.table.insert(binds, "save | Save configs")
                    g.table.insert(binds, "load | Load configs")
                    g.table.insert(binds, "reset | Reset configs to default")
                    g.table.insert(binds, "perpinfo | Perp info (Drug dealer, bank info, etc..)")
                    g.table.insert(binds, "blowc4 | TTT Blow all c4s")
                    g.table.insert(binds, "give <id> <howmany> | Give yourself 'fake' perp item")
                    g.table.insert(binds, "listitems | Show a list of all the items you can give yourself")
                    g.table.insert(binds, "lookup <name> | Show id by name EX: 'lookup ak47'")
                    g.table.insert(binds, "healme | PERP Heal you (same as when talking to the doctor)")
                    g.table.insert(binds, "fixlegs | PERP Fix legs (same as when talking to the doctor)")
                    g.table.insert(binds, "listadmins | List all the admins online")
                    g.table.insert(binds, "listplayers | List all players online")
                    g.table.insert(binds, "playerinfo [steamid|userid] | Returns info about a specific player")
                    g.table.insert(binds, "Available Actions:")
                    for k,v in g.pairs(GD.binds) do
                        g.table.insert(binds, k)
                    end
                   
                    return binds
                elseif splitcmd[1] == "save" then
                    GD:SaveConfig()
                    return "Saved configs!"
                elseif splitcmd[1] == "load" then
                    GD:LoadConfig()
                    return "Loaded configs!"
                elseif splitcmd[1] == "reset" then
                    GD:DefaultConfig()
                    return "Config reset successfully!"
                elseif splitcmd[1] == "perpinfo" then
                    local perpinfo = {}
                    g.table.insert(perpinfo, "Druggy info:")
                    g.table.insert(perpinfo, GetDrugBuying())
                    g.table.insert(perpinfo, GetDrugSelling())
                    g.table.insert(perpinfo, "Bank rob info:")
     
                    if GetBankMoney() != 0 then
                        g.table.insert(perpinfo, "Bank rob info:")
                       
                        if GetBankReady() then
                            g.table.insert(perpinfo, "Bank is ready to rob!")
                        else
                            g.table.insert(perpinfo, "Bank is not ready to rob!")
                        end
                        g.table.insert(perpinfo, "Money in bank: "..FormatNum( GetBankMoney(), 2, "$" ))
                    end
     
                    return perpinfo
                elseif splitcmd[1] == "blowc4" then
                    if g.gmod.GetGamemode().Name != "Trouble in Terrorist Town" then
                        return "Gamemode does not appear to be TTT!";
                    end
                   
                    if(g.LocalPlayer():IsTraitor()) then
                        return "Cannot do this as traitor!";
                    end
                   
                    for k, v in g.pairs(g.ents.FindByClass("ttt_c4")) do
                        g.RunConsoleCommand("ttt_c4_disarm", v:EntIndex(), g.math.random(1000, 5000));
                    end
                   
                    return "Blown all C4!"
                elseif splitcmd[1] == "list_traitors" then
                    local traitors = {}
                    g.table.insert(traitors, "All traitors:")
     
                    if g.table.Count(GD.traitors) > 0 then
                        for k, v in g.pairs(GD.traitors) do
                            g.table.insert(traitors, "Name: "..v:Nick())
                        end
                    else
                        g.table.insert(traitors, "No traitors found!")
                    end
     
                    return traitors
                elseif splitcmd[1] == "healme" then
                    g.RunConsoleCommand("perp2_encrypt3D_medic_resetHealth")
                    return "You got healed!"
                elseif splitcmd[1] == "fixlegs" then
                    g.RunConsoleCommand("perp2_encrypt3D_medic_resetCrippled")
                    return "Legs fixed!"
                elseif splitcmd[1] == "listadmins" then
                    local admins = {}
                    local adminfound = false
                    g.table.insert(admins, "All admins:")
                    for _,v in g.pairs(g.player.GetAll()) do
                        local rank = isadmin(v)
     
                        if rank then
                            adminfound = true
                            g.table.insert(admins, "UserID: "..v:UserID().." - Name: "..v:Nick().." - Rank: "..rank.." - SteamID: "..v:SteamID())
                        end
                    end
     
                    if !adminfound then
                        g.table.insert(admins, "No admins found!")
                    end
     
                    return admins
                elseif splitcmd[1] == "listplayers" then
                    local players = {}
                    g.table.insert(players, "All players:")
                    for _,v in g.pairs(g.player.GetAll()) do
                        local rank = isadmin(v) or "Player"
     
                        g.table.insert(players, "UserID: "..v:UserID().." - Name: "..v:Nick().." - Rank: "..rank.." - SteamID: "..v:SteamID())
                    end
     
                    return players
                elseif splitcmd[1] == "playerinfo" then
                    local user = g.LocalPlayer()
                    local playerinfo = {}
                    g.table.insert(playerinfo, "Player info:")
                    if splitcmd[2] then
                        user = false
                        for _,v in g.pairs(g.player.GetAll()) do
                            if g.tostring(v:SteamID()) == g.tostring(splitcmd[2]) or g.tostring(v:UserID()) == g.tostring(splitcmd[2]) then
                                user = v
                            end
                        end
     
                        if user == false then
                            g.table.insert(playerinfo, "No player found!")
                            return playerinfo
                        end
                    end
                   
                    local rank = isadmin(user) or "Player"
                    g.table.insert(playerinfo, "UserID: "..user:UserID())
                    g.table.insert(playerinfo, "Name: "..user:Nick())
                    g.table.insert(playerinfo, "SteamID: "..user:SteamID())
                    g.table.insert(playerinfo, "UniqueID: "..user:UniqueID())
                    g.table.insert(playerinfo, "Rank: "..rank)
                    g.table.insert(playerinfo, "HP: "..user:Health())
                    g.table.insert(playerinfo, "Armor: "..user:Armor())
                    if g.IsValid(user:GetActiveWeapon()) then
                        g.table.insert(playerinfo, "Weapon: "..user:GetActiveWeapon():GetClass())
                    end
     
                    if g.type(user.GetBank) == "function" and user == g.LocalPlayer() then
                        local bankinfo = user:GetBank()
                        if bankinfo then
                            g.table.insert(playerinfo, "Bank: "..FormatNum(bankinfo, 2, "$"))
                        end
                    end
                   
                    return playerinfo
                elseif splitcmd[1] == "give" then
                    if splitcmd[2] then
                        local howmany = 1
                        if splitcmd[3] then
                            howmany = splitcmd[3]
                        end
     
                        id = g.tonumber(splitcmd[2])
                        howmany = g.tonumber(splitcmd[3])
     
                        if ITEM_DATABASE[id] == nil then
                            for k, v in g.pairs(ITEM_DATABASE) do
                                local strippedname = g.string.lower(g.string.gsub(g.string.gsub(g.string.gsub(v.Name, " ", ""), "'", ""), "-", ""))
                                if g.string.find(strippedname, splitcmd[id]) then
                                    id = v.ID
                                end
                            end
                        end
     
                        if ITEM_DATABASE[id] != nil then
                            g.LocalPlayer():GiveItem(g.tonumber(id), g.tonumber(howmany));
                            return "Gave you "..howmany..' of "'..ITEM_DATABASE[id].Name..'"'
                        else
                            return "Item doesn't exist!"
                        end
                    else
                        return "give <id> [howmany]"
                    end
                elseif splitcmd[1] == "listitems" then
                    local items = {}
                    g.table.insert(items, "All perp items:")
                    if ITEM_DATABASE then
                        for k, v in g.pairs(ITEM_DATABASE) do
                            g.table.insert(items, v.ID.." - "..v.Name)
                        end
                    else
                        g.table.insert(items, "No items found!")
                    end
                    return items
                elseif splitcmd[1] == "lookup" then
                    if splitcmd[2] then
                        local founditems = {}
                        g.table.insert(founditems, "Found perp items:")
                        if ITEM_DATABASE then
                            for k, v in g.pairs(ITEM_DATABASE) do
                                local strippedname = g.string.lower(g.string.gsub(g.string.gsub(g.string.gsub(v.Name, " ", ""), "'", ""), "-", ""))
                                if g.string.find(strippedname, splitcmd[2]) then
                                    g.table.insert(founditems, v.ID.." - "..v.Name)
                                end
                            end
     
                            if g.next(founditems) != nil then
                                return founditems
                            else
                                g.table.insert(founditems, "No items found!")
                            end
                        else
                            g.table.insert(founditems, "No items found!")
                        end
     
                        return founditems
                    else
                        return "lookup <name>"
                    end
                elseif splitcmd[1] == "bind" then
                    if splitcmd[2] and splitcmd[3] then
                        return GD:RemapKey(splitcmd[3], splitcmd[2])
                    else
                        return "bind <key> <action>"
                    end
                elseif splitcmd[1] == "binds" then
                    local binds = {}
                    g.table.insert(binds, "All binds:")
                    for bind, key in g.pairs(GD.binds) do
                        if key == 0 then
                            key = "none"
                        end
                       
                        g.table.insert(binds, bind.." = "..key)
                    end
                    return binds
                elseif splitcmd[1] == "unbind" then
                    if splitcmd[2] then
     
                        return GD:RemapKey(splitcmd[2], "none")
                    else
                        return "unbind <action>"
                    end
                end
               
                return "Unkown Command!"
            end
           
            function attack()
                if !GD.attacking then
                    GD.attacking = true
                    g.RunConsoleCommand("RVRM_start_attack_RVRM")
                    g.timer.Simple(0.00001, function()
                        g.RunConsoleCommand("RVRM_stop_attack_RVRM")
                        local wep = g.LocalPlayer():GetActiveWeapon()
                        g.timer.Simple(((wep.Primary and wep.Primary.Delay) or 0.001), function()
                            GD.attacking = false
                        end)
                    end)
                end
            end
     
            function GD:AutoReload()
                local wep = g.LocalPlayer():GetActiveWeapon()
     
                if g.LocalPlayer():Alive() and g.IsValid(wep) and wep:GetClass() != "weapon_physgun" and wep.Primary != nil then
                    if wep:Clip1() <= 0 and wep.Primary.ClipSize != 0 and g.LocalPlayer():GetAmmoCount(wep.Primary.Ammo) > 0 then
                        if GD.nextreload <= g.CurTime() then
                            GD.nextreload = g.CurTime() + 3
     
                            g.RunConsoleCommand("RVRM_start_reload_RVRM")
                            g.timer.Simple(0.1, function()
                                g.RunConsoleCommand("RVRM_stop_reload_RVRM")
                            end)
                        end
                    end
                end
            end
           
            -- **DO_NOT_STEAL**
     
            function GD:HasLOS(ent, pos)
                if !GD.bools["checklos"] then
                    return true
                end
               
                local trace = {
                    start = g.LocalPlayer():GetShootPos(), endpos = pos, filter = {
                        g.LocalPlayer(), ent
                    }, mask = 1174421507
                }
               
                local tr = g.util.TraceLine(trace)
               
                return tr.Fraction == 1
            end
           
            function GD:ReadyShoot(ent)
                if ent == g.LocalPlayer() then
                    return false
                end
               
                if !g.IsValid(ent) then
                    return false
                end
               
                if ent:IsPlayer() and (!ent:Alive() or ent:Health() <= 0) then
                    return false
                end
               
                if ent:GetPos():Distance(g.LocalPlayer():GetPos()) >= GetVar("aimdistance") then
                    return false
                end
               
                local fov = GetVar("aimfov")
                local ady = 0
                if fov != 180 then
                    local lpang = g.LocalPlayer():GetAngles()
                    local ang = (ent:GetPos() - g.LocalPlayer():GetPos()):Angle()
                    local angel = g.math.NormalizeAngle(lpang.y - ang.y)
                    if g.isnumber(angel) then
                        ady = g.math.abs(angel)
                    end
                    local angel = g.math.NormalizeAngle(lpang.p - ang.p)
                    local adp = 0
                    if g.isnumber(angel) then
                        local adp = g.math.abs(angel)
                    end
                   
                    if (ady > fov or adp > fov) then
                        return false
                    end
                end
               
                return true, ady
            end
           
            function GD:Aimbot()
                if !CheckKey(GD.binds["+aim"]) then
                    GD.curtarg = nil
                end
               
                if g.LocalPlayer():Alive() then
                    local targ, aimpos = GD:FindTarget()
                    if targ and CheckKey(GD.binds["+aim"]) and !CheckKey(GD.binds["+triggerbot"]) then
                        local ang = (aimpos-g.LocalPlayer():GetShootPos()):Angle()
     
                        if GD.bools["aimantisnap"] then
                            ang = GD:Smoothang(ang)
                        end
     
                        ang.p, ang.y, ang.r = g.math.NormalizeAngle(ang.p), g.math.NormalizeAngle(ang.y), g.math.NormalizeAngle(ang.r)
                        g.LocalPlayer():SetEyeAngles(ang)
     
                        if GD.bools["aimautoshoot"] then
                            attack()
                        end
                    end
                end
            end
           
            -- **DO_NOT_STEAL**
     
            GD.Bones = {
                "ValveBiped.Bip01_Head1",
                "ValveBiped.Bip01_Neck1",
                "ValveBiped.Bip01_Spine4",
                "ValveBiped.Bip01_Spine2",
                "ValveBiped.Bip01_Spine1",
                "ValveBiped.Bip01_Spine",
                "ValveBiped.Bip01_R_UpperArm",
                "ValveBiped.Bip01_R_Forearm",
                "ValveBiped.Bip01_R_Hand",
                "ValveBiped.Bip01_L_UpperArm",
                "ValveBiped.Bip01_L_Forearm",
                "ValveBiped.Bip01_L_Hand",
                "ValveBiped.Bip01_R_Thigh",
                "ValveBiped.Bip01_R_Calf",
                "ValveBiped.Bip01_R_Foot",
                "ValveBiped.Bip01_R_Toe0",
                "ValveBiped.Bip01_L_Thigh",
                "ValveBiped.Bip01_L_Calf",
                "ValveBiped.Bip01_L_Foot",
                "ValveBiped.Bip01_L_Toe0"
            }
     
            function GD:FindToLook(target)
                local tolook = nil
     
                if !GD.bools["aimmanuel"] then
                    for k = 1, #GD.Bones do
                        if target:LookupBone(GD.Bones[k]) then
                            tolook = target:GetBonePosition(target:LookupBone(GD.Bones[k]))
                               
                            if GD.Bones[k] == "ValveBiped.Bip01_Head1" then
                                tolook = tolook + Vector(0, 0, 3)
                            end
                           
                            if GD:HasLOS(target, tolook) then
                                break
                            else
                                tolook = nil
                            end
                        end
                    end
                end
     
                if tolook == nil then
                    tolook = target:GetPos() + g.Vector(GetVar("aimx"), GetVar("aimy"), GetVar("aimz"))
                end
     
                return tolook
            end
     
            function GD:FindTarget()
                local tolook = nil
                local tolookg = nil
                if g.IsValid(GD.curtarg) and CheckKey(GD.binds["+aim"]) and !CheckKey(GD.binds["+triggerbot"]) and (!GD.curtarg:IsPlayer() or g.team.GetName(GD.curtarg:Team()) != "Spectators") then
                    tolook = GD:FindToLook(GD.curtarg)
                   
                    local readyshoot, cyaw = GD:ReadyShoot(GD.curtarg)
                    if GD:HasLOS(GD.curtarg, tolook) and readyshoot then
                        return GD.curtarg, tolook
                    else
                        GD.curtarg = nil
                        return false
                    end
                else
                    GD.curtarg = nil
                end
               
                local bestfov = 360
                for _,v in g.ipairs(g.ents.GetAll()) do
                    if g.IsValid(v) and (GD.bools["targetnpc"] and v:IsNPC()) or (GD.bools["targetplayer"] and v:IsPlayer() and g.team.GetName(v:Team()) != "Spectators") or (GD.bools["targetent"] and g.table.HasValue(GD.espents, v:GetClass())) then
                        tolook = GD:FindToLook(v)
                       
                        local teamcheck = true
                        local orgcheck = true
                       
                        if v:IsPlayer() then
                            if !GD.bools["aimteam"] and v:Team() == g.LocalPlayer():Team() then
                                teamcheck = false
                            end
     
                            if !GD.bools["aimorg"] and g.type(v.GetOrganizationName) == "function" then
                                if v:GetOrganizationName() == g.LocalPlayer():GetOrganizationName() then
                                    orgcheck = false
                                end
                            end
                        end
                       
                        local readyshoot, cyaw = GD:ReadyShoot(v)
                        if GD:HasLOS(v, tolook) and v != g.LocalPlayer() and readyshoot and (teamcheck) and (orgcheck) and (!v:IsPlayer() or !g.table.HasValue(GD.friends, v:SteamID())) then
                            if cyaw < bestfov then
                                bestfov = cyaw
                                tolookg = tolook
                                GD.curtarg = v
     
                                break
                            end
                        end
                    end
                end
               
                return GD.curtarg,tolookg
            end
           
            function GD:Smoothang(ang)
                ang.p = g.math.NormalizeAngle(ang.p)
                ang.y = g.math.NormalizeAngle(ang.y)
                lpang = g.LocalPlayer():EyeAngles()
                local as = GetVar("aimantisnap")
                lpang.p = g.math.Approach(lpang.p, ang.p, as)
                lpang.y = g.math.Approach(lpang.y, ang.y, as)
                lpang.r = 0
                ang = lpang
               
                return ang
            end
     
            -- **DO_NOT_STEAL**
     
            function GD:TriggerBot(ucmd)
                if CheckKey(GD.binds["+triggerbot"]) and !CheckKey(GD.binds["+aim"]) then
                    local Ent = g.LocalPlayer():GetEyeTrace().Entity
                    if g.IsValid(Ent) and ((Ent:IsPlayer() and Ent:Alive() and not Ent:GetObserverTarget() and GD.bools["targetplayer"] and not g.table.HasValue(GD.friends, Ent:SteamID())) or (Ent:IsNPC() and GD.bools["targetnpc"])) and Ent != g.LocalPlayer() then
                        GD.IsFiring = true
                        attack()
                    else
                        GD.IsFiring = false
                    end
                else
                    GD.IsFiring = false
                end
            end
     
            function GD:Bhop(ucmd)
                if CheckKey(GD.binds["+bhop"]) and g.LocalPlayer():GetMoveType() != MOVETYPE_NOCLIP then
                    if g.LocalPlayer():OnGround() then
                        g.RunConsoleCommand("RVRM_start_jump_RVRM")
                        g.timer.Simple(0, function()
                            g.RunConsoleCommand("RVRM_stop_jump_RVRM")
                        end)
                    end
                end
            end
           
            function GD:ShowMenu()
                local back = g.vgui.Create("DFrame")
                back:SetSize(520,300)
                back:ShowCloseButton(false)
                back:Center()
                back:MakePopup()
     
                back.Paint = function()
                    g.draw.RoundedBox(0, 0, 0, back:GetWide(), back:GetTall(), g.Color(0, 0, 0, 0))
                end
               
                local tablist = g.vgui.Create( "DPropertySheet", back )
                tablist:SetPos(0, 0)
                tablist:SetSize(back:GetWide(), back:GetTall())
     
                local function AddCheckItem(dpanel, bool, text, x, y)
                    local checkbox = g.vgui.Create("DCheckBoxLabel", dpanel)
                    checkbox:SetPos(x, y)
                    checkbox:SetText(text)
                    checkbox:SizeToContents()
                    checkbox:SetTextColor(Color(255,255,255))
                    checkbox:SetChecked(GD.bools[bool])
                    checkbox.OnChange = function(chk)
                        GD.bools[bool] = checkbox:GetChecked()
                    end
     
                    return checkbox
                end
               
                local function AddNumItem(dpanel, var, text, min ,max, width, x, y, decimals)
                    local numslider = g.vgui.Create("DNumSlider", dpanel)
                    numslider:SetText(text)
                    numslider:SetWide(width)
                    numslider:SetDecimals(decimals)
                    numslider:SetMin(min)
                    numslider:SetMax(max)
                    numslider:SetPos(x, y)
                    numslider:SetValue(GetVar(var))
                    numslider.OnValueChanged = function(p, v)
                        GD.vars[var] = v
                    end
     
                    return numslider
                end
               
                local dpanelinfo = g.vgui.Create( "DPanelList" )
                dpanelinfo:SetName("info_tab")
                dpanelinfo:SetPos( 2,27 )
                dpanelinfo:SetSize( tablist:GetWide()-4, tablist:GetTall()-29 )
                dpanelinfo:SetSpacing( 5 )
                dpanelinfo:EnableHorizontal( false )
                dpanelinfo:EnableVerticalScrollbar( false )
     
                dpanelinfo.Paint = function()
                    g.draw.SimpleText("gDaap", "Logo", 25, 1, g.Color(0,30,255,255), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT)
                    g.draw.SimpleText("v"..GD.version, "Logo", 265, 1, g.Color(0,255,30,255), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT)
                end
     
                local tab = ""
                for var=0, 5 do
                   tab = tab..string.char(32)
                end
     
                local dchangelog = g.vgui.Create("DListView", dpanelinfo)
                dchangelog:SetPos(5,100)
                dchangelog:SetMultiSelect(false)
                dchangelog:SetSize(dpanelinfo:GetWide()-20,dpanelinfo:GetTall()-110)
                dchangelog:AddColumn("Changelog")
     
                for number, line in g.pairs(g.string.Explode("\n", GD.changelog)) do
                    if line != "" then
                        if !(g.string.sub(line, 0, 1) == "v" and g.string.sub(line, g.string.len(line)) == ":") then
                            line = tab..line
                        end
     
                        dchangelog:AddLine(line)
                    end
                end
     
                local dpanelaim = g.vgui.Create("DPanelList")
                dpanelaim:SetName("aim_tab")
                dpanelaim:SetPos(2,27)
                dpanelaim:SetSize(tablist:GetWide()-4, tablist:GetTall()-29)
                dpanelaim:SetSpacing(5)
                dpanelaim:EnableHorizontal(false)
                dpanelaim:EnableVerticalScrollbar(false)
               
                local dpanelesp = g.vgui.Create("DPanelList")
                dpanelesp:SetName("esp_tab")
                dpanelesp:SetPos(2,27)
                dpanelesp:SetSize(tablist:GetWide()-4, tablist:GetTall()-29)
                dpanelesp:SetSpacing(5)
                dpanelesp:EnableHorizontal(false)
                dpanelesp:EnableVerticalScrollbar(false)
               
                local dpanelmisc = g.vgui.Create("DPanelList")
                dpanelmisc:SetName("misc_tab")
                dpanelmisc:SetPos(2,27)
                dpanelmisc:SetSize(tablist:GetWide()-4, tablist:GetTall()-29)
                dpanelmisc:SetSpacing(5)
                dpanelmisc:EnableHorizontal(false)
                dpanelmisc:EnableVerticalScrollbar(false)
               
                local dpanelents = g.vgui.Create("DPanelList")
                dpanelents:SetName("ents_tab")
                dpanelents:SetPos(2,27)
                dpanelents:SetSize(tablist:GetWide()-4, tablist:GetTall()-29)
                dpanelents:SetSpacing(5)
                dpanelents:EnableHorizontal(false)
                dpanelents:EnableVerticalScrollbar(false)
               
                local allents = g.vgui.Create("DListView", dpanelents)
                allents:SetPos(2,2)
                allents:SetMultiSelect(false)
                allents:SetSize(dpanelents:GetWide()/2-50,dpanelents:GetTall()-10)
                allents:AddColumn("Not On ESP")
               
                local addedent = {}
                for _,v in g.ipairs(ents.GetAll()) do
                    if !g.table.HasValue(addedent, v:GetClass()) and !g.table.HasValue(GD.espents, v:GetClass()) and v:GetClass() != "player" then
                        allents:AddLine(v:GetClass())
                        g.table.insert(addedent, v:GetClass())
                    end
                end
               
                local custents = g.vgui.Create("DListView", dpanelents)
                custents:SetPos(dpanelents:GetWide()/2+50,2)
                custents:SetMultiSelect(false)
                custents:SetSize(dpanelents:GetWide()/2-65,dpanelents:GetTall()-10)
                custents:AddColumn("On ESP")
                for _,v in g.pairs(GD.espents) do
                    custents:AddLine(v)
                end
               
                local add = g.vgui.Create("DButton", dpanelents)
                add:SetText("-->")
                add:SetSize(50,20)
                add:SetPos(dpanelents:GetWide()/2-(add:GetWide()/2), dpanelents:GetTall()/2-10)
                add.DoClick = function()
                    local line = allents:GetSelectedLine()
                    if line != nil then
                        local eclass = allents:GetLine(line):GetValue(1)
                        if !g.table.HasValue(GD.espents, eclass) then
                            g.table.insert(GD.espents, eclass)
                            custents:AddLine(eclass)
                            allents:RemoveLine(line)
                        end
                    end
                end
               
                local remove = g.vgui.Create("DButton", dpanelents)
                remove:SetText("<--")
                remove:SetSize(50,20)
                remove:SetPos(dpanelents:GetWide()/2-(add:GetWide()/2), dpanelents:GetTall()/2+10)
                remove.DoClick = function()
                    local line = custents:GetSelectedLine()
                    if line != nil then
                        local eclass = custents:GetLine(line):GetValue(1)
                        if g.table.HasValue(GD.espents, eclass) then
                            for k,v in g.pairs(GD.espents) do
                                if v == eclass then
                                    g.table.remove(GD.espents, k)
                                end
                            end
                           
                            allents:AddLine(eclass)
                            custents:RemoveLine(line)
                        end
                    end
                end
               
                local dpanellog = g.vgui.Create("DPanelList")
                dpanellog:SetName("log_tab")
                dpanellog:SetPos(2,27)
                dpanellog:SetSize(tablist:GetWide()-4, dpanelents:GetTall()-10)
                dpanellog:SetSpacing(5)
                dpanellog:EnableHorizontal(false)
                dpanellog:EnableVerticalScrollbar(false)
               
                local dlog = g.vgui.Create("DListView", dpanellog)
                dlog:SetPos(122,2)
                dlog:SetMultiSelect(false)
                dlog:SetSize(dpanellog:GetWide()-139,dpanellog:GetTall()-3)
                dlog:AddColumn("Log")
                for i=#GD.log,1,-1 do
                    dlog:AddLine(GD.log[i])
                end
               
                local clear = g.vgui.Create("DButton", dpanellog)
                clear:SetText("Clear")
                clear:SetSize(100, 20)
                clear:SetPos(5, 205)
                clear.DoClick = function()
                    dlog:Clear()
                    GD.log = {}
                end
     
                local update = g.vgui.Create("DButton", dpanellog)
                update:SetText("Update")
                update:SetSize(100, 20)
                update:SetPos(5, 230)
                update.DoClick = function()
                    dlog:Clear()
                    for i=#GD.log,1,-1 do
                        dlog:AddLine(GD.log[i])
                    end
                end
     
                local dpanelfriends = g.vgui.Create("DPanelList")
                dpanelfriends:SetName("friends_tab")
                dpanelfriends:SetPos( 2,27 )
                dpanelfriends:SetSize( tablist:GetWide()-4, tablist:GetTall()-29 )
                dpanelfriends:SetSpacing( 5 )
                dpanelfriends:EnableHorizontal( false )
                dpanelfriends:EnableVerticalScrollbar( false )
               
                local notfriends = g.vgui.Create("DListView", dpanelfriends)
                notfriends:SetPos(2,2)
                notfriends:SetMultiSelect(false)
                notfriends:SetSize(dpanelfriends:GetWide()/2-50,dpanelfriends:GetTall()-10)
                notfriends:AddColumn("Enemies")
                for _,v in g.pairs(g.player.GetAll()) do
                    if !g.table.HasValue(GD.friends, v:SteamID()) and v != g.LocalPlayer() then
                        notfriends:AddLine(v:Nick())
                    end
                end
               
                local friends = g.vgui.Create("DListView", dpanelfriends)
                friends:SetPos(dpanelfriends:GetWide()/2+50,2)
                friends:SetMultiSelect(false)
                friends:SetSize(dpanelfriends:GetWide()/2-65,dpanelfriends:GetTall()-10)
                friends:AddColumn("Friends")
                for _,v in g.pairs(g.player.GetAll()) do
                    if g.table.HasValue(GD.friends, v:SteamID()) and v != g.LocalPlayer() then
                        friends:AddLine(v:Nick())
                    end
                end
               
                local addfriend = g.vgui.Create("DButton", dpanelfriends)
                addfriend:SetText("-->")
                addfriend:SetSize(50,20)
                addfriend:SetPos(dpanelfriends:GetWide()/2-(addfriend:GetWide()/2), dpanelfriends:GetTall()/2-10)
                addfriend.DoClick = function()
                    local line = notfriends:GetSelectedLine()
                    if line != nil then
                        local plyname = notfriends:GetLine(line):GetValue(1)
                        for _,v in g.ipairs(g.player.GetAll()) do
                            if plyname == v:Nick() and !g.table.HasValue(GD.friends, v:SteamID()) then
                                g.table.insert(GD.friends, v:SteamID())
                                friends:AddLine(plyname)
                                notfriends:RemoveLine(line)
                            end
                        end
                    end
                end
               
                local removefriend = g.vgui.Create("DButton", dpanelfriends)
                removefriend:SetText("<--")
                removefriend:SetSize(50,20)
                removefriend:SetPos(dpanelfriends:GetWide()/2-(removefriend:GetWide()/2), dpanelfriends:GetTall()/2+10)
                removefriend.DoClick = function()
                    local line = friends:GetSelectedLine()
                    if line != nil then
                        local plyname = friends:GetLine(line):GetValue(1)
                        for _,v in g.ipairs(g.player.GetAll()) do
                            if plyname == v:Nick() and g.table.HasValue(GD.friends, v:SteamID()) then
                                local toremove = 0
                                for k,g in g.pairs(GD.friends) do
                                    if g == v:SteamID() then
                                        toremove = k
                                    end
                                end
                               
                                g.table.remove(GD.friends, toremove)
                                notfriends:AddLine(plyname)
                                friends:RemoveLine(line)
                            end
                        end
                    end
                end
     
                local dpanelcon = g.vgui.Create("DPanelList")
                dpanelcon:SetName("con_tab")
                dpanelcon:SetPos(2,27)
                dpanelcon:SetSize(tablist:GetWide()-4, dpanelcon:GetTall()-10)
                dpanelcon:SetSpacing(5)
                dpanelcon:EnableHorizontal(false)
                dpanelcon:EnableVerticalScrollbar(false)
               
                DList = g.vgui.Create("DListView", dpanelcon)
                DList:SetPos(2,24)
                DList:SetSize(tablist:GetWide()-19,tablist:GetTall()-63)
                DList:AddColumn("Console")
               
                local txt = g.vgui.Create("DTextEntry", dpanelcon)
                txt:SetWide(tablist:GetWide()-130)
                txt:SetPos(2,2)
               
                txt.OnGetFocus = function()
                    GD.confocus = true
                end
               
                txt.OnLoseFocus = function()
                    GD.confocus = false
                end
               
                txt.OnEnter = function()
                    GD:AddToConsole(DList, "] "..txt:GetValue())
                    GD:AddToConsole(DList, GD:ParseCommand(txt:GetValue(), DList))
     
                    txt:SetText("")
                   
                    g.timer.Create("requestfocus_delay", 0.1, 1, function()
                        txt:RequestFocus()
                    end)
                end
               
                AddCheckItem(dpanelaim, "aimactive", "Aimbot Active", 5, 5)
                AddCheckItem(dpanelaim, "triggeractive", "Triggerbot Active", 5, 30)
                AddCheckItem(dpanelaim, "aimteam", "Aim At Team", 5, 55)
                AddCheckItem(dpanelaim, "aimorg", "Aim at PEPR org", 5, 80)
                AddCheckItem(dpanelaim, "checklos", "Check LOS", 5, 105)
                AddCheckItem(dpanelaim, "aimautoshoot", "Auto-Shoot", 5, 130)
                AddCheckItem(dpanelaim, "aimautoreload", "Auto-Reload", 5, 155)
                AddCheckItem(dpanelaim, "targetnpc", "Target NPC's", 5, 180)
                AddCheckItem(dpanelaim, "targetplayer", "Target Players", 5, 205)
                AddCheckItem(dpanelaim, "targetent", "Target Ents", 5, 230)
     
                AddCheckItem(dpanelesp, "espactive", "ESP Active", 5, 5)
                AddCheckItem(dpanelesp, "espplayers", "Show Players", 5, 30)
                AddCheckItem(dpanelesp, "espnpcs", "Show NPCs", 5, 55)
                AddCheckItem(dpanelesp, "espents", "Show Ents", 5, 80)
                AddCheckItem(dpanelesp, "esphealth", "Show Health", 5, 105)
                AddCheckItem(dpanelesp, "esparmor", "Show Armor", 5, 130)
                AddCheckItem(dpanelesp, "espteam", "Show Team", 5, 155)
                AddCheckItem(dpanelesp, "espadmin", "Show Rank", 5, 180)
                AddCheckItem(dpanelesp, "espweapon", "Show Weapon", 5, 205)
                AddCheckItem(dpanelesp, "espname", "Show name", 5, 230)
                AddCheckItem(dpanelesp, "esprpname", "PERP Show rp name", 150, 5)
                AddCheckItem(dpanelesp, "esporg", "PERP Show org", 150, 30)
     
                AddCheckItem(dpanelesp, "espchams", "Wallhack Active", 150, 80)
                AddCheckItem(dpanelesp, "espwireframe", "Wireframe Wallhack", 150, 105)
                AddCheckItem(dpanelesp, "espsolid", "Solid Wallhack", 150, 130)
     
                AddCheckItem(dpanelesp, "eyetracer", "Eye tracer", 150, 180)
                AddCheckItem(dpanelesp, "drawcrosshair", "Always draw crosshair", 150, 205)
                GD.nosmoke_check = AddCheckItem(dpanelesp, "nosmoke", "No smoke/fire*", 150, 230)
     
                AddNumItem(dpanelesp, "espchamdist", "Cham Distance", 0, 20000, 150, 340, 5, 0)
                AddNumItem(dpanelesp, "esptextdist", "ESP Distance", 0, 20000, 150, 340, 30, 0)
     
                AddCheckItem(dpanelesp, "radar", "Enable radar", 340, 80)
                AddCheckItem(dpanelesp, "radar_outline", "Radar outline", 340, 105)
                AddCheckItem(dpanelesp, "radar_cross", "Radar cross", 340, 130)
                AddCheckItem(dpanelesp, "radar_names", "Radar names", 340, 155)
                AddNumItem(dpanelesp, "radar_size", "Radar size", 200, 500, 150, 340, 180, 0)
                AddNumItem(dpanelesp, "radar_pixrat", "Radar pixrat", 15, 100, 150, 340, 205, 0)
     
                AddCheckItem(dpanellog, "lognet", "Log Net", 5, 5)
                AddCheckItem(dpanellog, "logfile", "Log File", 5, 30)
                AddCheckItem(dpanellog, "loghook", "Log Hook", 5, 55)
                AddCheckItem(dpanellog, "logrcc", "Log RCC", 5, 80)
                AddCheckItem(dpanellog, "logcc", "Log ConCommand", 5, 105)
                AddCheckItem(dpanellog, "loggcv", "Log GetConVar", 5, 130)
                AddCheckItem(dpanellog, "printlog", "Show In Console", 5, 155)
     
                AddCheckItem(dpanelcon, "printconsole", "Show In Console", 395, 5)
     
                AddCheckItem(dpanelmisc, "miscbhop", "Enable Bunnyhop", 5, 5)
                GD.speedhack_check = AddCheckItem(dpanelmisc, "speedhack", "Speedhack Enabled*", 5, 30)
                AddCheckItem(dpanelmisc, "norecoil", "No-Recoil", 5, 55)
                AddCheckItem(dpanelmisc, "fixscreen", "Remove screen shake", 5, 80)
                AddCheckItem(dpanelmisc, "adminbox", "Show admin box", 5, 105)
                AddCheckItem(dpanelmisc, "player_info", "Show own player info", 5, 130)
                AddCheckItem(dpanelmisc, "keypad_logger", "DarkRP Keypad logger", 5, 155)
                AddCheckItem(dpanelmisc, "ttt_finder", "TTT Show traitors", 5, 180)
                AddCheckItem(dpanelmisc, "perp_drug_info", "PERP Show info", 5, 205)
                AddCheckItem(dpanelmisc, "perp_infinite_fuel", "PERP Infinite fuel", 5, 230)
     
                AddCheckItem(dpanelmisc, "thirdperson", "Third Person", 180, 5)
                GD.fullbright_check = AddCheckItem(dpanelmisc, "fullbright", "Fullbright*", 180, 30)
                AddCheckItem(dpanelmisc, "notifications", "Notifications bar", 180, 55)
                AddCheckItem(dpanelmisc, "show_spectators", "Show spectators", 180, 80)
                AddCheckItem(dpanelmisc, "miscblockrcc", "Block RCC", 180, 105)
                AddCheckItem(dpanelmisc, "miscblocknet", "Block Net", 180, 130)
                GD.map_check = AddCheckItem(dpanelmisc, "map", "Show map*", 180, 155)
                AddCheckItem(dpanelmisc, "antiafk", "Anti afk", 180, 180)
                GD.autosvcheat_check = AddCheckItem(dpanelmisc, "autosvcheat", "Auto sv_cheats *", 180, 205)
                AddCheckItem(dpanelmisc, "autosave", "Auto Save Configs", 180, 230)
     
                AddCheckItem(dpanelmisc, "attackspam", "Left click spam", 340, 5)
                AddCheckItem(dpanelmisc, "advert", "Advert for gDaap", 340, 30)
     
                AddNumItem(dpanelaim, "aimfov", "FOV", 1, 180, 150, 340, 5, 0)
                AddNumItem(dpanelaim, "aimdistance", "Distance", 0, 20000, 150, 340, 30, 0)
     
                AddCheckItem(dpanelaim, "aimantisnap", "Anti-Snap", 340, 95)
                AddNumItem(dpanelaim, "aimantisnap", "Anti-Snap Speed", 0, 20, 150, 340, 105, 1)
     
                AddCheckItem(dpanelaim, "aimmanuel", "Aim manuel X, Y, Z", 340, 165)
                AddNumItem(dpanelaim, "aimx", "X Offset", 0, 256, 150, 340, 180, 0)
                AddNumItem(dpanelaim, "aimy", "Y Offset", 0, 256, 150, 340, 205, 0)
                AddNumItem(dpanelaim, "aimz", "Z Offset", 0, 256, 150, 340, 230, 0)
     
                local info_tab = tablist:AddSheet("Info", dpanelinfo, "icon16/star.png", false, false, "Generel info")
                local aim_tab = tablist:AddSheet("Aimbot", dpanelaim, "icon16/user.png", false, false, "Aimbot Settings")
                local esp_tab = tablist:AddSheet("ESP/Wallhack", dpanelesp, "icon16/picture_edit.png", false, false, "ESP/Wallhack Settings")
                local ent_tab = tablist:AddSheet("Entities", dpanelents, "icon16/brick_add.png", false, false, "Entities")
                local misc_tab = tablist:AddSheet("Misc", dpanelmisc, "icon16/world.png", false, false, "Miscellaneous Settings")
                local log_tab = tablist:AddSheet("Log", dpanellog, "icon16/folder_go.png", false, false, "RCC/Net Logs")
                local friends_tab = tablist:AddSheet("Friends", dpanelfriends, "icon16/group.png", false, false, "Friends List")
                local con_tab = tablist:AddSheet("Console", dpanelcon, "icon16/page.png", false, false, "gDaap Console")
               
                local tabs = {
                    ["info_tab"] = info_tab,
                    ["aim_tab"] = aim_tab,
                    ["esp_tab"] = esp_tab,
                    ["ents_tab"] = ent_tab,
                    ["misc_tab"] = misc_tab,
                    ["log_tab"] = log_tab,
                    ["friends_tab"] = friends_tab,
                    ["con_tab"] = con_tab,
                }
     
                back.Think = function()
                    if CheckKey(GD.binds["menu_toggle"], true) and !GD.menupress then
                        GD.menuopen = false
                        GD.activetab = tablist:GetActiveTab():GetPanel():GetName()
                        back:Close()
                        GD.fullbright_check = false
                        GD.nosmoke_check = false
                        GD.map_check = false
                        GD.speedhack_check = false
                        GD.autosvcheat_check = false
     
                        if GD.bools["autosave"] then
                            GD:SaveConfig()
                        end
     
                        GD.menupress = true
                    end
                end
     
                if GD.activetab then
                    tablist:SetActiveTab(tabs[GD.activetab].Tab)
                end
            end
     
            -- **DO_NOT_STEAL**
     
            local function TurnOffAutoSvCheat()
                GD.checksvcheatchecking = false
                GD.checksvcheatconfirm = false
                GD.bools["autosvcheat"] = false
                Notify(true, red, "Sorry but 'Auto sv_cheats' won't work for some reason.")
                if GD.autosvcheat_check != false then
                    GD.autosvcheat_check:SetValue(0)
                end
            end
     
            local function CheckCheat()
                if GD.bools["autosvcheat"] then
                    if GD.checksvcheatconfirm then
                        if GD.fullbright or GD.nosmoke or GD.lastmapvalue != 0 or GD.speedhackison then
                            if !checksvcheat() then
                                g.RunConsoleCommand("RVRM_turncheaton_RVRM")
                                GD:LogAction("[Auto sv_cheats] Turned sv_cheats on")
                            end
                        elseif checksvcheat() then
                            g.RunConsoleCommand("RVRM_turncheatoff_RVRM")
                            GD:LogAction("[Auto sv_cheats] Turned sv_cheats off")
                        end
                    else
                        CheckAutoSvCheats()
                        g.timer.Simple(0.3, function()
                            CheckCheat()
                        end)
                    end
                end
            end
     
            local X = -50
            local Y = -100
            local keypad_KeyPos =  {      
                {X+5, Y+100, 25, 25, -2.2, 3.45, 1.3, -0},
                {X+37.5, Y+100, 25, 25, -0.6, 1.85, 1.3, -0},
                {X+70, Y+100, 25, 25, 1.0, 0.25, 1.3, -0},
         
                {X+5, Y+132.5, 25, 25, -2.2, 3.45, 2.9, -1.6},
                {X+37.5, Y+132.5, 25, 25, -0.6, 1.85, 2.9, -1.6},
                {X+70, Y+132.5, 25, 25, 1.0, 0.25, 2.9, -1.6},
         
                {X+5, Y+165, 25, 25, -2.2, 3.45, 4.55, -3.3},
                {X+37.5, Y+165, 25, 25, -0.6, 1.85, 4.55, -3.3},
                {X+70, Y+165, 25, 25, 1.0, 0.25, 4.55, -3.3},
         
                {X+5, Y+67.5, 50, 25, -2.2, 4.7, -0.3, 1.6},
                {X+60, Y+67.5, 35, 25, 0.3, 1.65, -0.3, 1.6}
            }
             
            local function keypad_FindDisplayText(ent)
                if ent.GetDisplayText then
                    return ent:GetDisplayText()
                else
                    return ent.Entity:GetNetworkedInt("keypad_num")
                end
            end
             
            local function keypad_FindStatus(ent)
                if ent.GetStatus then
                    return ent:GetStatus()
                elseif ent.Entity:GetNetworkedBool("keypad_access") and ent.Entity:GetNetworkedBool("keypad_showaccess") then
                    return 1
                elseif not ent.Entity:GetNetworkedBool("keypad_access") and ent.Entity:GetNetworkedBool("keypad_showaccess") then
                    return 2
                else
                    return 0
                end
            end
     
            function CheckAutoSvCheats()
                if GD.bools["autosvcheat"] and !GD.checksvcheatconfirm and !GD.checksvcheatchecking then
                    GD.checksvcheatchecking = true
                    g.RunConsoleCommand("RVRM_turncheaton_RVRM")
                    g.timer.Simple(0.1, function()
                        if !checksvcheat() then
                            TurnOffAutoSvCheat()
                        else
                            g.RunConsoleCommand("RVRM_turncheatoff_RVRM")
                            g.timer.Simple(0.1, function()
                                if checksvcheat() then
                                    TurnOffAutoSvCheat()
                                else
                                    GD.checksvcheatchecking = false
                                    GD.checksvcheatconfirm = true
     
                                    GD.fullbright = false
                                    GD.nosmoke = false
                                    GD.lastmapvalue = 0
                                    GD.speedhackison = false
                                end
                            end)
                        end
                    end)
                end
            end
     
            local TWeapons = {}
            local UsedWeapons = {}
            if g.gmod.GetGamemode().Name == "Trouble in Terrorist Town" then
                for k,v in g.pairs(weapons.GetList()) do
                    if v.CanBuy != nil then
                        if g.table.HasValue(v.CanBuy, 1) and !g.table.HasValue(TWeapons, v.ClassName) then
                            g.table.insert(TWeapons, v.ClassName)
                        end
                    end
                end
            end
     
            local function TTTPrepareRound()
                GD.traitors = {}
                UsedWeapons = {}
            end
     
            local function IsATraitor(ply)
                local found = false
                if ply != nil then
                    for k, v in g.pairs(GD.traitors) do
                        if v == ply then
                            found = true
                            break
                        end
                    end
                end
     
                return found
            end
     
            local function Think()
                local ply = g.LocalPlayer()
     
                if GD.bools["aimactive"] then
                    GD:Aimbot(ucmd)
                end
     
                if GD.bools["advert"] then
                    if GD.lastadvert == nil or GD.lastadvert <= g.os.time()-600 then
                        g.RunConsoleCommand("say", 'gDaap - Once you go hack, you never go back! http://mpgh.net/')
                        GD.lastadvert = g.os.time()
                    end
                elseif GD.lastadvert != nil then
                    GD.lastadvert = nil
                end
     
                if GD.bools["ttt_finder"] then
                    if g.gmod.GetGamemode().Name == "Trouble in Terrorist Town" then
                        if !IsATraitor(ply) then
                            for _,v in g.pairs(g.player.GetAll()) do
                                if v != ply then
                                    if !v:IsDetective() then
                                        if g.team.GetName(v:Team()) ~= "Spectators" then
                                            for wepk, wepv in g.pairs(TWeapons) do
                                                for entk, entv in g.pairs(g.ents.FindByClass(wepv)) do
                                                    if g.IsValid(entv) and !g.table.HasValue(UsedWeapons, entv) then
                                                        local EntPos = (entv:GetPos() - g.Vector(0,0,35))
                                                        if v:GetPos():Distance(EntPos) <= 1 then
                                                            Notify(true, pink, v:Nick() .. " has traitor weapon: " .. wepv)
                                                           
                                                            if !g.table.HasValue(GD.traitors, v) and !v:IsDetective() then
                                                                g.table.insert(GD.traitors, v)
                                                            end
     
                                                            if !g.table.HasValue(UsedWeapons, entv) then
                                                                g.table.insert(UsedWeapons, entv)
                                                            end
                                                        end
                                                    end
                                                end
                                            end
                                        end
                                    end
                                end
                            end
                        end
                    end
                end
     
                for _,v in g.pairs(g.player.GetAll()) do
                    if GD.bools["keypad_logger"] then
                        local kp = v:GetEyeTrace().Entity
                        if g.IsValid(kp) and (g.string.find(kp:GetClass(), "keypad") and not(g.string.find(v:GetClass(), "cracker") or g.string.find(v:GetClass(), "checker"))) and v:EyePos():Distance(kp:GetPos()) <= 70 then
                            kp.tempCode = kp.tempCode or ""
                            kp.tempText = kp.tempText or ""
                            kp.tempStatus = kp.tempStatus or 0
                           
                            if (keypad_FindDisplayText(kp) != kp.tempText) or (keypad_FindStatus(kp) != kp.tempStatus) then
                                kp.tempText = keypad_FindDisplayText(kp)
                                kp.tempStatus = keypad_FindStatus(kp)
                               
                                local tr = g.util.TraceLine({
                                    start = v:EyePos(),
                                    endpos = v:GetAimVector() * 32 + v:EyePos(),
                                    filter = v
                                })
                               
                                local pos = kp:WorldToLocal(tr.HitPos)
                               
                                for i,p in g.pairs(keypad_KeyPos) do
                                    local x = (pos.y - p[5]) / (p[5] + p[6])
                                    local y = 1 - (pos.z + p[7]) / (p[7] + p[8])
                                   
                                    if (x >= 0 and y >= 0 and x <= 1 and y <= 1) then
                                        if i == 11 then
                                            if kp.tempStatus == 1 then
                                                kp.code = kp.tempCode
                                                kp.tempCode = ""
                                            elseif kp.tempStatus == 2 then
                                                kp.tempCode = ""
                                            end
                                        elseif i == 10 then
                                            kp.tempCode = ""
                                        elseif i > 0 then
                                            kp.tempCode = kp.tempCode..i
                                        end
                                    end
                                end
                            end
                        end
                    end
     
                    if isadmin(v) && !g.table.HasValue(GD.adminl, v) then
                        g.table.insert(GD.adminl, v)
                        g.surface.PlaySound("buttons/blip1.wav")
                        Notify(true, red, v:Nick().." has joined the game as an "..isadmin(v).."!")
                    end
     
                    if g.IsValid(v:GetObserverTarget()) and v:GetObserverTarget():IsPlayer() and v:GetObserverTarget() == g.LocalPlayer() then
                        if not g.table.HasValue(GD.spectators, v) then
                            g.table.insert(GD.spectators, v);
                            if GD.bools["show_spectators"] then
                                Notify(true, red, v:Nick().." is now spectating you!")
                                g.surface.PlaySound("buttons/blip1.wav")
                            end
                        end
                    end
                end
     
                for k, v in g.pairs(GD.spectators) do
                    if not g.IsValid(v) or not g.IsValid(v:GetObserverTarget()) or not v:GetObserverTarget():IsPlayer() or (v:GetObserverTarget() ~= g.LocalPlayer()) then
                        g.table.remove(GD.spectators, k);
                        if GD.bools["show_spectators"] then
                            Notify(true, green, v:Nick().." is no longer spectating you!")
                        end
                    end
                end
               
                for k,v in g.pairs(GD.adminl) do
                    if !g.IsValid(v) then
                        GD.adminl[k] = nil
                    end
                end
     
                if !GD.bools["autosvcheat"] and GD.checksvcheatconfirm then
                    GD.checksvcheatconfirm = false
                end
     
                if (GD.bools["fullbright"] or GD.bools["nosmoke"] or GD.bools["map"] or GD.bools["speedhack"]) and !checksvcheat() and !GD.bools["autosvcheat"] then
                    Notify(true, red, "You need to set 'sv_cheats' to '1' or enable 'Auto sv_cheats' to use this!")
                    GD.bools["fullbright"] = false
                    GD.bools["nosmoke"] = false
                    GD.bools["map"] = false
                    GD.bools["speedhack"] = false
     
                    if GD.fullbright_check != false then
                        GD.fullbright_check:SetValue(0)
                    end
                    if GD.nosmoke_check != false then
                        GD.nosmoke_check:SetValue(0)
                    end
                    if GD.map_check != false then
                        GD.map_check:SetValue(0)
                    end
                    if GD.speedhack_check != false then
                        GD.speedhack_check:SetValue(0)
                    end
                end
     
                if GD.bools["fullbright"] and !GD.fullbright then
                    GD.fullbright = true
                    CheckCheat()
                    g.RunConsoleCommand("RVRM_turnfullbrighton_RVRM")
                elseif !GD.bools["fullbright"] and GD.fullbright then
                    g.RunConsoleCommand("RVRM_turnfullbrightoff_RVRM")
                    GD.fullbright = false
                    CheckCheat()
                end
     
                if GD.bools["nosmoke"] and !GD.nosmoke then
                    GD.nosmoke = true
                    CheckCheat()
                    g.RunConsoleCommand("r_drawparticles", 0)
                elseif !GD.bools["nosmoke"] and GD.nosmoke then
                    g.RunConsoleCommand("r_drawparticles", 1)
                    GD.nosmoke = false
                    CheckCheat()
                end
     
                if GD.bools["map"] then
                    if GD.lastmapvalue != GetVar("leveloverview") then
                        GD.lastmapvalue = GetVar("leveloverview")
                        CheckCheat()
                        g.RunConsoleCommand("cl_leveloverview", GetVar("leveloverview"))
                    end
                elseif GD.lastmapvalue > 0 then
                    g.RunConsoleCommand("cl_leveloverview", 0)
                    GD.lastmapvalue = 0
                    CheckCheat()
                end
     
                if CheckKey(GD.binds["zoom_in"]) and !CheckKey(GD.binds["zoom_out"]) then
                    if GD.bools["map"] then
                        if GetVar("leveloverview") > 1 then
                            GD.vars["leveloverview"] = GetVar("leveloverview")-1
                        end
                    elseif GD.bools["thirdperson"] then
                        if GetVar("thirdpersondist") > 20 then
                            GD.vars["thirdpersondist"] = GetVar("thirdpersondist")-10
                        end
                    end
                end
     
                if CheckKey(GD.binds["zoom_out"]) and !CheckKey(GD.binds["zoom_in"]) then
                    if GD.bools["map"] then
                        if GetVar("leveloverview") < 100 then
                            GD.vars["leveloverview"] = GetVar("leveloverview")+1
                        end
                    elseif GD.bools["thirdperson"] then
                        if GetVar("thirdpersondist") < 2500 then
                            GD.vars["thirdpersondist"] = GetVar("thirdpersondist")+10
                        end
                    end
                end
     
                if CheckKey(GD.binds["map_toggle"]) and !GD.mappress then
                    GD.mappress = true
                    GD.bools["map"] = !GD.bools["map"]
                end
               
                if !CheckKey(GD.binds["map_toggle"]) then
                    GD.mappress = false
                end
     
                if CheckKey(GD.binds["menu_toggle"]) and !GD.menupress then
                    GD.menupress = true
                    GD:ShowMenu()
                    GD.menuopen = true
                end
     
                if !CheckKey(GD.binds["menu_toggle"], true) then
                    GD.menupress = false
                end
               
                if CheckKey(GD.binds["esp_toggle"]) and !GD.esppress then
                    GD.esppress = true
                    GD.bools["espactive"] = !GD.bools["espactive"]
                end
               
                if !CheckKey(GD.binds["esp_toggle"]) then
                    GD.esppress = false
                end
               
                if CheckKey(GD.binds["thirdperson_toggle"]) and !GD.tppress then
                    GD.tppress = true
                    GD.bools["thirdperson"] = !GD.bools["thirdperson"]
                end
               
                if !CheckKey(GD.binds["thirdperson_toggle"]) then
                    GD.tppress = false
                end
               
                if CheckKey(GD.binds["fullbright"]) and !GD.fbpress then
                    GD.fbpress = true
                    GD.bools["fullbright"] = !GD.bools["fullbright"]
                end
               
                if !CheckKey(GD.binds["fullbright"]) then
                    GD.fbpress = false
                end
               
                if GD.bools["speedhack"] and CheckKey(GD.binds["+speed"]) then
                    if !GD.speedhackison then
                        GD.speedhackison = true
                        CheckCheat()
                        g.RunConsoleCommand("RVRM_turnspeedhackon_RVRM")
                    end
                elseif GD.speedhackison then
                    g.RunConsoleCommand("RVRM_turnspeedhackoff_RVRM")
                    GD.speedhackison = false
                    CheckCheat()
                end
     
                if !RVRM_loaded_RVRM then
                    if !RVRM_loadedinsecuremode_RVRM then
                        GD.loaded = false
                        GD:SaveConfig()
                        for type, name in g.pairs(GD.hooks) do
                            RemoveHook(type, name)
                        end
                        g.RunConsoleCommand("RVRM_turncheatoff_RVRM")
                        g.timer.Destroy("AntiAfk")
                        if g.type(DoFuel) == "function" then
                            g.timer.Destroy("DoFuel");
                            g.timer.Create("DoFuel", 1, 0, function()
                                DoFuel()
                            end)
                        end
                        g.print("gDaap unloaded!")
                    else
                        RVRM_loaded_RVRM = true
                        g.print("Can't unload gDaap when in secure mode!")
                    end
                end
            end
     
            -- **DO_NOT_STEAL**
     
            local function CreateMove(cmd)
                local ply = g.LocalPlayer()
                local wep = ply:GetActiveWeapon()
     
                if GD.bools["attackspam"] then
                    if CheckKey("MOUSE_LEFT") then
                        attack()
                    end
                end
     
                if GD.bools["aimautoreload"] then
                    GD:AutoReload()
                end
               
                if GD.bools["triggeractive"] then
                    GD:TriggerBot(ucmd)
                end
               
                if g.IsValid(wep) and wep.Primary and !ply:InVehicle() then
                    if GD.bools["drawcrosshair"] then
                        if wep.DrawCrosshair != true then
                            wep.OldDrawCrosshair = false
                            wep.DrawCrosshair = true
                        end
                    else
                        if wep.OldDrawCrosshair == false then
                            wep.DrawCrosshair = wep.OldDrawCrosshair
                        end
                    end
     
                    if GD.bools["norecoil"] then
                        if wep.Recoil != 0 then
                            wep.OldRecoil = wep.Recoil
                            wep.Recoil = 0
                        end
                        if wep.Primary.Recoil != 0 then
                            wep.Primary.OldRecoil = wep.Primary.Recoil
                            wep.Primary.Recoil = 0
                        end
                        if wep.Secondary.Recoil != 0 then
                            wep.Secondary.OldRecoil = wep.Secondary.Recoil
                            wep.Secondary.Recoil = 0
                        end
     
                        if wep.Spread != 0.1 then
                            wep.OldSpread = wep.Spread
                            wep.Spread = 0.1
                        end
                        if wep.Primary.Spread != 0.1 then
                            wep.Primary.OldSpread = wep.Primary.Spread
                            wep.Primary.Spread = 0.1
                        end
                        if wep.Primary.Spread != 0.1 then
                            wep.Secondary.OldSpread = wep.Secondary.Spread
                            wep.Primary.Spread = 0.1
                        end
     
                        if wep.Cone != 0 then
                            wep.OldCone = wep.Cone
                            wep.Cone = 0
                        end
                        if wep.Primary.Cone != 0 then
                            wep.Primary.OldCone = wep.Primary.Cone
                            wep.Primary.Cone = 0
                        end
                        if wep.Secondary.Cone != 0 then
                            wep.Secondary.OldCone = wep.Secondary.Cone
                            wep.Secondary.Cone = 0
                        end
                    else
                        wep.OldRecoil = wep.OldRecoil or wep.Recoil
                        wep.Recoil = wep.OldRecoil
                        wep.Primary.OldRecoil = wep.Primary.OldRecoil or wep.Primary.Recoil
                        wep.Primary.Recoil = wep.Primary.OldRecoil
                        wep.Secondary.OldRecoil = wep.Secondary.OldRecoil or wep.Secondary.Recoil
                        wep.Secondary.Recoil = wep.Secondary.OldRecoil
     
                        wep.OldSpread = wep.OldSpread or wep.Spread
                        wep.Spread = wep.OldSpread
                        wep.Primary.OldSpread = wep.Primary.OldSpread or wep.Primary.Spread
                        wep.Primary.Spread = wep.Primary.OldSpread
                        wep.Secondary.OldSpread = wep.Secondary.OldSpread or wep.Secondary.Spread
                        wep.Secondary.Spread = wep.Secondary.OldSpread
     
                        wep.OldCone = wep.OldCone or wep.Cone
                        wep.Cone = wep.OldCone
                        wep.Primary.OldCone = wep.Primary.OldCone or wep.Primary.Cone
                        wep.Primary.Cone = wep.Primary.OldCone
                        wep.Secondary.OldCone = wep.Secondary.OldCone or wep.Secondary.Cone
                        wep.Secondary.Cone = wep.Secondary.OldCone
                    end
                end
               
                if(GD.bools["miscbhop"]) then
                    GD:Bhop()
                end
            end
     
            function GD.RadarGenerateColours(amount)
                GD.RadarColKey = {};
     
                local red = g.math.ceil(amount / 3);
                local green = g.math.Round(amount / 3);
                local blue = g.math.floor(amount / 3);
     
                for i = 1, amount do
                    if g.player.GetAll()[i] != g.LocalPlayer() then
                        if red > 0 then
                            GD.RadarColKey[i] = g.Color(255 / red, 0, 0, 255);
                            red = red - 1;
                        elseif green > 0 then
                            GD.RadarColKey[i] = g.Color(0, 255 / green, 0, 255);
                            green = green - 1;
                        elseif blue > 0 then
                            GD.RadarColKey[i] = g.Color(0, 0, 255 / blue, 255);
                            blue = blue - 1;
                        end
                    end
                end
     
                GD.RadarColTabSize = amount;
            end
     
            local function HUDPaint()
                if GD.bools["keypad_logger"] then
                    for k,v in g.pairs(g.ents.GetAll()) do
                        if g.IsValid(v) then
                            if g.string.find(v:GetClass(), "keypad") and not(g.string.find(v:GetClass(), "cracker") or g.string.find(v:GetClass(), "checker")) then
                                if v != e then
                                    local pos = v:GetPos():ToScreen()
                                    if g.IsValid(v) and v.code then
                                        g.draw.WordBox(1, pos.x-5, pos.y-5, v.code, "Default", g.Color(0, 255, 0, 150), g.Color(255,255,255,255))
                                    else
                                        g.draw.WordBox(1, pos.x-5, pos.y-5, "Not Found", "Default", g.Color(255, 0, 0, 150), g.Color(255,255,255,255))
                                    end
                                end
                            end
                        end
                    end
                end
     
                if GD.bools["espchams"] or GD.bools["eyetracer"] then
                    local campos = g.EyePos()
                    local camangle = g.EyeAngles()
     
                    if g.gmod.GetGamemode().Name == "Trouble in Terrorist Town" then
                        campos = g.LocalPlayer():EyePos()
                        camangle = g.LocalPlayer():EyeAngles()
                    end
     
                    g.cam.Start3D(campos, camangle)
                    for _,v in g.pairs(g.ents.GetAll()) do
                        if GD.bools["eyetracer"] then
                            if v != g.LocalPlayer() and g.IsValid(v) and v:IsPlayer() and v:Alive() and g.team.GetName(v:Team()) != "Spectators" then
                                g.render.SetMaterial(Material("cable/physbeam"))
                                local head = v:LookupBone("ValveBiped.Bip01_Head1")
                                if head then
                                    g.render.DrawBeam(v:GetBonePosition(head), v:GetEyeTrace().HitPos , 5, 0, 0, g.Color(255,255,255, 255))
                                end
                            end
                        end
     
                        if GD.bools["espchams"] then
                            if g.IsValid(v) and ((GD.bools["espnpcs"] and v:IsNPC() and v:Health() > 0) or (GD.bools["espplayers"] and v:IsPlayer() and v:Alive() and g.team.GetName(v:Team()) != "Spectators")) and v != g.LocalPlayer() and v:GetPos():Distance(g.LocalPlayer():GetPos()) <= GetVar("espchamdist") then
                                local chamcol = g.Color(134,13,255,255)
                                if v:IsPlayer() then
                                    chamcol = g.team.GetColor(v:Team()) or g.Color(134,13,255,255)
                                end
                               
                                if GD.bools["espwireframe"] then
                                    v:SetMaterial("models/wireframe")
                                elseif GD.bools["espsolid"] then
                                    v:SetMaterial("models/debug/debugwhite")
                                end
                               
                                g.render.SetColorModulation(chamcol.r / 255, chamcol.g / 255, chamcol.b / 255)
                                g.render.SetBlend(chamcol.a / 255)
                                v:SetColor(chamcol)
                                v:DrawModel()
                                v:SetColor(Color(255,255,255))
                                v:SetMaterial("")
                            end
                        end
                    end
                    g.cam.End3D()
                end
     
                if GD.bools["espactive"] then
                    for _,v in g.pairs(g.ents.GetAll()) do
                        if (GD.bools["espplayers"] and v:IsPlayer() and v:Alive() and g.team.GetName(v:Team()) != "Spectators") and v != g.LocalPlayer() and v:GetPos():Distance(g.LocalPlayer():GetPos()) <= GetVar("esptextdist") then
                            local pos = (v:GetPos()+g.Vector(0,0,45)):ToScreen()
                            local nametocall = v:Nick()
                            local rankcol = g.Color(150,0,255,255)
                            local y = -10
                            local invertedy = 12
                           
                            local rank = isadmin(v)
                            if !rank then
                                rank = "Player"
                            end
                           
                            local color = g.Color(255,255,255,255)
                            local namecol = color
     
                            if g.type(v.GetRPName) == "function" and GD.bools["esprpname"] then
                                if v:Nick() != v:GetRPName() then
                                    g.draw.SimpleText(v:GetRPName(), "BudgetLabel", pos.x, pos.y + y+invertedy, green, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
                                    invertedy = invertedy +12
                                else
                                    namecol = green
                                end
                            end
     
                            if g.type(v.GetOrganizationName) == "function" and GD.bools["esporg"] then
                                if v:GetOrganizationName() != nil then
                                    g.draw.SimpleText(v:GetOrganizationName(), "BudgetLabel", pos.x, pos.y + y+invertedy, blue, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
                                end
                            end
     
                            if GD.bools["espname"] then
                                g.draw.SimpleText(v:Nick(), "BudgetLabel", pos.x, pos.y + y, namecol, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
                                y = y -12
                            end
                           
                            if GD.bools["esphealth"] then
                                g.draw.SimpleText("H: "..v:Health(), "BudgetLabel", pos.x, pos.y + y, color, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
                                y = y -12
                            end
                           
                            if GD.bools["esparmor"] then
                                g.draw.SimpleText("A: "..v:Armor(), "BudgetLabel", pos.x, pos.y + y, color, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
                                y = y -12
                            end
                           
                            if GD.bools["espteam"] then
                                g.draw.SimpleText(g.team.GetName(v:Team()), "BudgetLabel", pos.x, pos.y + y, g.team.GetColor(v:Team()), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
                                y = y -12
                            end
                           
                            if GD.bools["espadmin"] then
                                g.draw.SimpleText(rank, "BudgetLabel", pos.x, pos.y + y, rankcol, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
                                y = y - 12
                            end
                           
                            if g.IsValid(v:GetActiveWeapon()) and GD.bools["espweapon"] then
                                g.draw.SimpleText(v:GetActiveWeapon():GetClass(), "BudgetLabel", pos.x, pos.y + y, g.Color(67,120,54), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
                                y = y - 12
                            end
     
                            if g.gmod.GetGamemode().Name == "Trouble in Terrorist Town" then
                                if IsATraitor(v) then
                                    g.draw.SimpleText("[TRAITOR]", "BudgetLabel", pos.x, pos.y + y, red, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
                                elseif v:IsDetective() then
                                    g.draw.SimpleText("[DETECTIVE]", "BudgetLabel", pos.x, pos.y + y, blue, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
                                end
                            end
                        end
                       
                        if (GD.bools["espnpcs"] and v:IsNPC() and v:Health() > 0) then
                            local y = -10
                            local pos = (v:GetPos()+g.Vector(0,0,45)):ToScreen()
                            local textcol = g.Color(65,180,10,255)
                            g.draw.SimpleText(v:GetClass(), "BudgetLabel", pos.x, pos.y + y, textcol, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
                            y = y - 12
                           
                            if GD.bools["esphealth"] then
                                g.draw.SimpleText("H: "..v:Health(), "BudgetLabel", pos.x, pos.y + y, textcol, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
                            end
                        end
                       
                        if g.table.HasValue(GD.espents, v:GetClass()) and GD.bools["espents"] then
                            local pos = (v:GetPos()+g.Vector(0,0,35)):ToScreen()
                            g.draw.SimpleText(v:GetClass(), "BudgetLabel", pos.x, pos.y, Color(255,0,0), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
                        end
                    end
                end
     
                if GD.bools["aimactive"] and CheckKey(GD.binds["+aim"]) and !CheckKey(GD.binds["+triggerbot"]) then
                    g.surface.SetFont("Notifications");
                   
                    g.surface.SetTextColor(not GD.curtarg and g.Color(255, 15, 15, 255) or g.Color(25, 255, 25, 255));
                   
                    local w,h = g.ScrW(), g.ScrH();
                    g.surface.SetTextPos(w/2-70, h/2+15);
                   
                    g.surface.DrawText(not GD.curtarg and "Aimbot scanning..." or "Aimbot locked!");
                end
     
                if GD.bools["triggeractive"] and CheckKey(GD.binds["+triggerbot"]) and !CheckKey(GD.binds["+aim"]) then
                    g.surface.SetFont("Notifications");
                   
                    g.surface.SetTextColor(not GD.IsFiring and g.Color(255, 15, 15, 255) or g.Color(25, 255, 25, 255));
                   
                    local w,h = g.ScrW(), g.ScrH();
                    g.surface.SetTextPos(w/2-80, h/2+15);
                   
                    g.surface.DrawText(not GD.IsFiring and "Triggerbot scanning..." or "Triggerbot firing!");
                end
     
                local total_y = 10
     
                if GD.bools["notifications"] then
                    g.draw.RoundedBoxEx(0, 0, 0, 10000, 30, g.Color(0, 0, 0,100), false, false, false, false)
                   
                    local text = ""
     
                    if GD.bools["aimactive"] then
                        text = text.."Aimbot: ON"
                    else
                        text = text.."Aimbot: OFF"
                    end
     
                    if GD.bools["triggeractive"] then
                        text = text.."| TriggerBot: ON"
                    else
                        text = text.."| TriggerBot: OFF"
                    end
                   
                    if GD.bools["aimautoshoot"] then
                        text = text.."| Autoshoot: ON"
                    else
                        text = text.."| Autoshoot: OFF"
                    end
                   
                    if GD.bools["norecoil"] then
                        text = text.."| No Recoil: ON"
                    else
                        text = text.."| No Recoil: OFF"
                    end
                   
                    if GD.bools["aimteam"] then
                        text = text.."| Target Team: ON"
                    else
                        text = text.."| Target Team: OFF"
                    end
                   
                    if GD.bools["checklos"] then
                        text = text.."| Check LOS: ON"
                    else
                        text = text.."| Check LOS: OFF"
                    end
                   
                    if GD.speedhackison then
                        text = text.."| SpeedHack: ON"
                    else
                        text = text.."| SpeedHack: OFF"
                    end
     
                    if GD.bools["thirdperson"] then
                        text = text.."| Thirdperson: ON"
                    else
                        text = text.."| Thirdperson: OFF"
                       
                    end
     
                    g.draw.SimpleText(text, "Notifications", 5, 5, g.Color(255, 255, 255, 255))
     
                    total_y = total_y + 30
                end
     
                if GD.bools["perp_drug_info"] then
                    g.draw.RoundedBoxEx( 4, 17, total_y, 122, 20, g.Color(116,187,251,255), true, true, false, false)
                    g.draw.SimpleText("Perp info:", "ESPFont", 78, total_y + 18, white, TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
     
                    g.draw.SimpleText(GetDrugBuying(), "ESPFont", 78, total_y + 40, white, TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
                    g.draw.SimpleText(GetDrugSelling(), "ESPFont", 78, total_y + 60, white, TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
     
                    local height = 45
                    if GetBankReady() and GetBankMoney() != 0 then
                        g.draw.SimpleText("Bank ready!", "ESPFont", 78, total_y + 85, green, TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP )
                        g.draw.SimpleText("Money to rob: ", "ESPFont", 78, total_y + 105, green, TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
                        g.draw.SimpleText(FormatNum(GetBankMoney(), 2, "$"), "ESPFont", 78, total_y + 125, green, TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
     
                        height = height+65
                    end
                    g.draw.RoundedBoxEx(4, 17, total_y + 20, 122, height, Color( 0, 0, 0, 100 ), false, false, true, true)
     
                    total_y = total_y + height + 20 + 10
                end
     
                if GD.bools["player_info"] then
                    g.draw.SimpleText("HP: "..g.LocalPlayer():Health(), "PlayerInfo", 30, total_y + 20, white, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
                    g.draw.SimpleText("Armor: "..g.LocalPlayer():Armor(), "PlayerInfo", 30, total_y + 40, white, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
     
                    local bankinfo = false
                    if g.type(g.LocalPlayer().GetBank) == "function" then
                        bankinfo = g.LocalPlayer():GetBank()
                        if bankinfo then
                            g.draw.SimpleText("Bank: "..FormatNum(bankinfo, 2, "$"), "PlayerInfo", 30, total_y + 60, white, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
                        end
                    end
     
                    if bankinfo then
                        g.draw.RoundedBox(0, 17, total_y, 175, 65, g.Color(0,0,0,70))
                        total_y = total_y + 75
                    else
                        g.draw.RoundedBox(0, 17, total_y, 175, 45, g.Color(0,0,0,70))
                        total_y = total_y + 55
                    end
                end
     
                if GD.bools["adminbox"] then
                    local adminfound = false
                    local height = 20
                    g.draw.SimpleText("All admins:", "PlayerInfo", 30, total_y + 20, white, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
                    total_y = total_y + 20
                    for _,v in g.pairs(g.player.GetAll()) do
                        local rank = isadmin(v)
     
                        if rank then
                            adminfound = true
                            g.draw.SimpleText(v:Nick(), "PlayerInfo", 30, total_y + 20, white, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
                            total_y = total_y + 20
                            height = height + 20
                        end
                    end
     
                    if !adminfound then
                        g.draw.SimpleText("No admins found!", "PlayerInfo", 30, total_y + 15, white, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
                        total_y = total_y + 20
                        height = height + 20
                    end
     
                    g.draw.RoundedBox(0, 17, total_y-height, 175, height+5, g.Color(0,0,0,70))
                end
     
                if #g.player.GetAll() != GD.RadarColTabSize then
                    GD.RadarGenerateColours(#g.player.GetAll())
                end
     
                if GD.bools["radar"] then
                    local size = GetVar("radar_size")
                    local fov  = GetVar("radar_pixrat")
                    local x = ScrW()-size-5
                    local y = 5
                    if GD.bools["notifications"] then
                        y = 35
                    end
     
                    g.surface.SetDrawColor( g.Color( 0, 0, 0, 150 ))
                    g.surface.DrawRect(x, y, size, size)
     
                    if GD.bools["radar_outline"] then
                        x = x -2
                        g.surface.SetDrawColor( 255, 255, 255, 200)
     
                        g.surface.DrawRect(x, y, size, 2)
                        g.surface.DrawRect(x, y, 2, size)
                        g.surface.DrawRect(x + size-1, y, 2, size)
                        g.surface.DrawRect(x, y + (size - 2), size, 2)
                    end
     
                    if GD.bools["radar_cross"] then
                        g.surface.DrawRect(x + size - (size * 0.50), y, 1, size )
                        g.surface.DrawRect(x, y + size - (size * 0.50), size, 1)
                    end
     
                    for key, ply in g.pairs(g.player.GetAll()) do
                        if ply != g.LocalPlayer() and ply:Alive() and g.team.GetName(ply:Team()) != "Spectators" and GD.RadarColKey[key] then
                            local lx = g.LocalPlayer():GetPos().x - ply:GetPos().x
                            local ly = g.LocalPlayer():GetPos().y - ply:GetPos().y
     
                            local ang = g.EyeAngles().y
     
                            local cos = g.math.cos(g.math.rad(-ang))
                            local sin = g.math.sin(g.math.rad(-ang))
     
                            local px = (ly * cos) + (lx * sin)
                            local py = (lx * cos) - (ly * sin)
     
                            px = px / fov
                            py = py / fov
     
                            px = g.math.Clamp(px, -(size * 0.50), size * 0.50)
                            py = g.math.Clamp(py, -(size * 0.50), size * 0.50)
     
                            if GD.bools["radar_names"] then
                                local col = GD.RadarColKey[key]
                                local name = g.player.GetAll()[key]:Nick()
                                g.draw.SimpleText(name, "default", x + size - (size * 0.50) + px - 3, y + size - (size * 0.50) + py - 3, col, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
                            else
                                g.surface.SetDrawColor(GD.RadarColKey[key])
                                g.surface.DrawRect(x + size - (size * 0.50) + px - 3, y + size - (size * 0.50) + py, 7, 1)
                                g.surface.DrawRect(x + size - (size * 0.50) + px, y + size - (size * 0.50) + py - 3, 1, 7)
                            end
                        end
                    end
                end
            end
     
            -- **DO_NOT_STEAL**
     
            RVRM_securemode_RVRM = true
            if RVRM_securemode_RVRM then
                RVRM_loadedinsecuremode_RVRM = true
                g.print("Loading gDaap in secure mode...")
                function GAMEMODE:Think()
                    return Think()
                end
                function GAMEMODE:CreateMove()
                    return CreateMove()
                end
                function GAMEMODE:HUDPaint()
                    return HUDPaint()
                end
                function GAMEMODE:CalcView(ply, origin, angles, fov)
                    return CalcView(ply, origin, angles, fov)
                end
                function GAMEMODE:ShouldDrawLocalPlayer(ply)
                    return ShouldDrawLocalPlayer(ply)
                end
                function GAMEMODE:StartChat()
                    return StartChat()
                end
                function GAMEMODE:FinishChat()
                    return FinishChat()
                end
                if g.gmod.GetGamemode().Name == "Trouble in Terrorist Town" then
                    function GAMEMODE:TTTPrepareRound()
                        return TTTPrepareRound()
                    end
                end
            else
                g.print("Loading gDaap...")
                AddHook("Think", Think)
                AddHook("CreateMove", CreateMove)
                AddHook("HUDPaint", HUDPaint)
                AddHook("CalcView", CalcView)
                AddHook("ShouldDrawLocalPlayer", ShouldDrawLocalPlayer)
                AddHook("StartChat", StartChat)
                AddHook("FinishChat", FinishChat)
                if g.gmod.GetGamemode().Name == "Trouble in Terrorist Town" then
                    AddHook("TTTPrepareRound", TTTPrepareRound)
                end
            end
        end
     
        GD:StartScript()
     
        -- **DO_NOT_STEAL**
    end