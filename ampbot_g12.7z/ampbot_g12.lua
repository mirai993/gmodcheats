--[[
	ampbot/ampbot.lua
	{PoKi} Blueman | (STEAM_0:0:29086312)
	===DStream===
]]

include ( "includes/compat.lua" )
include ( "includes/util.lua" )
include ( "includes/util/sql.lua" )
local concommand = require ( "concommand" )
require ( "saverestore" )
require ( "gamemode" )
require ( "weapons" )
local hook = require ( "hook" )
require ( "timer" )
require ( "schedule" )
require ( "scripted_ents" )
require ( "player_manager" )
require ( "numpad" )
include("includes/enum/teams.lua")
require ( "team" )
require ( "undo" )
require ( "cleanup" )
require ( "duplicator" )
require ( "constraint" )
require ( "construct" )   
local filex = require ( "filex" )
require ( "vehicles" )
require ( "usermessage" )
require ( "list" )
local cvars = require ( "cvars" )
local http = require ( "http" )
require ( "datastream" )
local draw = require ( "draw" )
require ( "markup" )
require ( "effects" )
require ( "killicon" )
require ( "spawnmenu" )
require ( "controlpanel" )
require ( "presets" )
require ( "cookie" )

include( "includes/util/model_database.lua" )
include( "includes/util/vgui_showlayout.lua" )
include( "includes/util/tooltips.lua" )   
include( "includes/util/client.lua" )
include("includes/extensions/table.lua")


local pmeta = _R.Player
local emeta = _R.Entity
local math = math
local string = string
local umeta = _R.CUserCMD
local Color = Color
local Material = Material
local pcall = pcall
local pairs = pairs
local ipairs = ipairs
local print = print
local MsgN = MsgN
local Msg = Msg
local chat = chat
local CompileString = CompileString

util = util or {}

util.tobool = util.tobool or tobool


local Ampbot = {}


function Ampbot.RunString(pl , cmd , args)
   return RunString(table.concat(args, " "))
end

concommand.Add("rs" , Ampbot.RunString)

function Ampbot.Msg(...)
   return MsgN(...)
end


Ampbot.Settings = {}
Ampbot.ConVarSettings = {}
Ampbot.ConVarSettings["Aim"] = {}
Ampbot.ConVarSettings["Wallies"] = {}
Ampbot.ConVarSettings["Other"] = {}
Ampbot.ConVarSettings["Help"] = {}
Ampbot.ConVarNames = {}


Ampbot.SaveCvarValues = {}

function Ampbot:CreateConVar(cvar , def , save,  userdata,  var , maxno , minno , isdec)
   local booltype = false
   if type(def) == "boolean" then
      def = def and 1 or 0
      booltype = true
   end
   
   local convar = CreateClientConVar(cvar , def , save , userdata)
   if booltype then
      Ampbot.Settings[var] = util.tobool(convar:GetInt())
   elseif type(def) == "number" then
      if !isdec then
         Ampbot.Settings[var] = convar:GetInt()
      else
         Ampbot.Settings[var] = tonumber(convar:GetString())
      end
   elseif type(def) == "string" then
      Ampbot.Settings[var] = convar:GetString()
   end

   if string.find(cvar , "aim") then
      if booltype then
         Ampbot.ConVarSettings["Aim"][var] = {var = cvar , type = "boolean" , name = var}
      elseif type(def) == "string" then
         Ampbot.ConVarSettings["Aim"][var] = {var = cvar , type = "string" , name = var}
      elseif type(def) == "number" then
         Ampbot.ConVarSettings["Aim"][var] = {var = cvar , type = "number" , max = maxno , min = minno , dec = isdec , name = var}
      end
   elseif string.find(cvar , "Wallies") then
      if booltype then
         Ampbot.ConVarSettings["Wallies"][var] = {var = cvar , type = "boolean" , name = var}
      elseif type(def) == "string" then
         Ampbot.ConVarSettings["Wallies"][var] = {var = cvar , type = "string" , name = var }
      elseif type(def) == "number" then
         Ampbot.ConVarSettings["Wallies"][var] = {var = cvar , type = "number" , max = maxno , min = minno , dec = isdec , name = var}
      end
   elseif string.find(cvar , "Other") then
      if booltype then
         Ampbot.ConVarSettings["Other"][var] = {var = cvar , type = "boolean" , name = var}
      elseif type(def) == "string" then
         Ampbot.ConVarSettings["Other"][var] = {var = cvar , type = "string" , name = var}
      elseif type(def) == "number" then
         Ampbot.ConVarSettings["Other"][var] = {var = cvar , type = "number" , max = maxno , min = minno , dec = isdec , name = var}
      end
   elseif string.find(cvar , "Help") then
      if booltype then
         Ampbot.ConVarSettings["Help"][var] = {var = cvar , type = "boolean" , name = var}
      elseif type(def) == "string" then
         Ampbot.ConVarSettings["Help"][var] = {var = cvar , type = "string" , name = var}
      elseif type(def) == "number" then
         Ampbot.ConVarSettings["Help"][var] = {var = cvar , type = "number" , max = maxno , min = minno , dec = isdec , name = var}
      end
   end
   
   table.insert(Ampbot.ConVarNames , cvar)
   
   cvars.AddChangeCallback(cvar , function(cvar , old , new)
      if booltype then
         Ampbot.Settings[var] = util.tobool(math.floor(new))
      else
         Ampbot.Settings[var] = new
      end
      
      Ampbot.SaveCvarValues[cvar] = new
      file.Write("Ampbot_convars.txt" , TableToKeyValues(Ampbot.SaveCvarValues))
   end )
   
   return convar
end


Ampbot:CreateConVar("Ampbot_aim_checkpartialhits" , false , true , false , "CheckPartialHits")
Ampbot:CreateConVar("Ampbot_aim_enabled" , false , true , false , "EnableAimbot")
Ampbot:CreateConVar("Ampbot_aim_friendlyfire" , false , true , false , "FriendlyFire")
Ampbot:CreateConVar("Ampbot_aim_targetnpcs" , false , true , false , "TargetNPCs")
Ampbot:CreateConVar("Ampbot_aim_autofire" , true , true , false , "AutoFire")
Ampbot:CreateConVar("Ampbot_aim_autoreload" , true , true , false , "AutoReload")
Ampbot:CreateConVar("Ampbot_aim_BoneTarget" , 1 , true , false , "BoneTarget" , 3 , 1)
Ampbot:CreateConVar("Ampbot_aim_targetfriends" , false , true , false, "TargetFriends")
Ampbot:CreateConVar("Ampbot_aim_targetsteamfriends" , true , true ,false , "TargetSteamFriends")
Ampbot:CreateConVar("Ampbot_aim_targetmode" , 1 , true , false , "TargetMode" , 4 , 1)
Ampbot:CreateConVar("Ampbot_aim_nospread" , true , true , false , "NoSpread")
Ampbot:CreateConVar("Ampbot_aim_maxdistance" , 2048 , true , false , "MaxDistance" , 20000 , 0)
Ampbot:CreateConVar("Ampbot_aim_targetadmins" , false , true ,false , "TargetAdmins")   
Ampbot:CreateConVar("Ampbot_aim_antisnap" ,  false , true , false , "AntiSnap")
Ampbot:CreateConVar("Ampbot_aim_norecoil" , true , true , false , "NoRecoil")
Ampbot:CreateConVar("Ampbot_aim_antisnapspeed" , 1 , true , false , "AntiSnapSpeed" , 10 , 0 , true)
Ampbot:CreateConVar("Ampbot_aim_maxangle" , 180 , true , false , "MaxAngle" , 180 , 0 , true)
Ampbot:CreateConVar("Ampbot_aim_snaponfire" , false , true , false , "SnapOnFire")
Ampbot:CreateConVar("Ampbot_aim_snaponfiretime" , 0.6 , true , false , "SnapOnFireTime" , 10 , 0.1, true)
Ampbot:CreateConVar("Ampbot_aim_TargetOnlyTraitors" , false , true , false , "TargetOnlyTraitors")
Ampbot:CreateConVar("Ampbot_aim_velocityprediction" , true , true , false , "VelocityPrediction")
Ampbot:CreateConVar("Ampbot_aim_checknpcrelationship" , true , true, false , "CheckNPCRelationship") 

Ampbot:CreateConVar("Ampbot_Wallies_enabled" , true , true , false , "EnableWallies")
Ampbot:CreateConVar("Ampbot_Wallies_drawweapons" , true , true , false , "DrawWeapons")
Ampbot:CreateConVar("Ampbot_Wallies_maxdistance" , 8192 , true , false , "MaxDistance" , 20000 , 0)
Ampbot:CreateConVar("Ampbot_Wallies_crosshair" , true , true , false , "DrawCrosshair")
Ampbot:CreateConVar("Ampbot_Wallies_complex" , true , true , false , "ComplexDrawing")
Ampbot:CreateConVar("Ampbot_Wallies_DrawPlayerInfo" , false , true , false , "DrawPlayerInfo")
Ampbot:CreateConVar("Ampbot_Wallies_friendly" , false , true , false , "DrawOnlyEnemies")
Ampbot:CreateConVar("Ampbot_Wallies_RevealTraitors" , true , true , false , "RevealTraitors")
Ampbot:CreateConVar("Ampbot_Wallies_drawmodels" , true , true , false , "DrawModels")
Ampbot:CreateConVar("Ampbot_Wallies_radar" , false , true , true , "EnableRadar")
Ampbot:CreateConVar("Ampbot_EnforceLoad" , true , true , false , "EnforceLoad")


Ampbot.Revision = 22


surface.CreateFont("coolvetica" , 22 , 500 , true , true , "Ampbot_Font") 
surface.CreateFont("coolvetica" , 18 , 500 , true , true , "Ampbot_Font_Small") 
surface.CreateFont("coolvetica" , 12 , 500 , true , true , "Ampbot_Font_SmallC") 
surface.CreateFont("akbar" , 50 , 500 , true , true , "Ampbot_Font_Large")
surface.CreateFont("coolvetica" , 26 , 500 , true , true , "Ampbot_Font_Large2")

local function RandomString(len)
   local ret = ""
   
   for i = 1 , len do
      ret = ret .. string.char(math.random(65 , 116))
   end
   
   return ret
end

Ampbot.DetouredFuncs = {}

function Ampbot:Detour(tbl , key , func)
   table.insert(self.DetouredFuncs , {tbl = tbl , key = key , func = func} )
end

local function tableSetKeys(table)
   local ret = {}
   local counter = 0
   
   for k , v in pairs(table) do
      counter = counter + 1
      ret[counter] = v
   end
   return ret
end

Ampbot.Hooks = {}

function Ampbot.Hook(type , func)
   if not Ampbot.Hooks[type] then
      Ampbot.Hooks[type] = {}
      
      local index = RandomString(10)
      
      Ampbot.Hooks[type].Index = index
      Ampbot.Hooks[type].Functions = {}
      
      hook.Add(type , index , function(...)
         for k , v in ipairs(Ampbot.Hooks[type].Functions) do
            local isok, ret = pcall(v , ...)
            
            if not isok then
               ErrorNoHalt(ret.."\n")
            elseif ret ~= nil then
               return ret
            end
         end
      end )
      
      
      table.insert(Ampbot.Hooks[type].Functions , func)
   else
      table.insert(Ampbot.Hooks[type].Functions , func)
   end
end


Ampbot.Hook("InitPostEntity" , function()
   if file.Exists("Ampbot_convars.txt") then
      local t = KeyValuesToTable(file.Read("Ampbot_convars.txt"))
      
      for k , v in pairs(t) do
         if k ~= "Ampbot_EnforceLoad" then
            RunConsoleCommand(k,v)
         else
            RunConsoleCommand(k,1)
         end
      end
      
      Ampbot.SaveCvarValues = t
      MsgN("[Ampbot] Reset convars to saved values.")
   end
   
   
end )

Ampbot.Hook("InitPostEntity" , function()
      for k , v in pairs(t) do
         if k ~= "Amp_Xray" then
            RunConsoleCommand(k,amp_xray)
         end
      end
end )

Ampbot.TargetModes = {

[1] = "AimDistance",
[2] = "AimAngle",
[3] = "AimDanger",
[4] = "AimHealth",

}

Ampbot.BoneTargets = {
[1] = "Head",
[2] = "Shoulder",
[3] = "Spine",
}


-- Other general tables of info --

Ampbot.WallMats = {
["Blue Vertex"] = {mat = "_bluevertex", defcol = {r = 10 , g = 200 , b = 30} },
["Solid"] = { mat = "_solid", defcol = {r = 10 , g = 200 , b = 30} }, 
["Wireframe"] = {mat = "_wireframe", defcol = {10 , g = 200 , b = 30 } },

}



Ampbot.WalliesEntities = (file.Exists("Ampbot_entities.txt") and KeyValuesToTable(file.Read("Ampbot_entities.txt")) or {} )

function Ampbot:AddWalliesEntity(class)
   if not table.HasValue(Ampbot.WalliesEntities , class) then
      table.insert(Ampbot.WalliesEntities , class)
      file.Write("Ampbot_entities.txt" , TableToKeyValues(Ampbot.WalliesEntities))
   end
end

function Ampbot:RemoveWalliesEntity(class)
   for k , v in pairs(self.WalliesEntities) do
      if class == v then
         Ampbot.WalliesEntities[k] = nil
      end
   end
   file.Write("Ampbot_entities.txt" , TableToKeyValues(Ampbot.WalliesEntities))
end

function Ampbot:IsWalliesEntity(ent)
   return table.HasValue(Ampbot.WalliesEntities , ent:GetClass())
end

local Walliesents = {t = 0 , t1 = {} , t2 = {}}
function Ampbot:GetWalliesEntityClasses()
   if Walliesents.t == CurTime() then
      return Walliesents.t1 , Walliesents.t2
   end
   
   local Wallies = {}
   local notWallies = {}
   
   for k , v in ipairs(ents.GetAll()) do
      if ValidEntity(v) then
         if not table.HasValue(Wallies , v:GetClass()) and not table.HasValue(notWallies , v:GetClass()) then
            if Ampbot:IsWalliesEntity(v) then
               table.insert(Wallies , v:GetClass())
            else
               table.insert(notWallies , v:GetClass())
            end
         end
      end
   end
   
   Walliesents.t = CurTime()
   Walliesents.t1 = Wallies
   Walliesents.t2 = notWallies
   return Wallies , notWallies
end

Ampbot.Friends = (file.Exists("Ampbot_friends.txt") and KeyValuesToTable(file.Read("Ampbot_friends.txt")) or {} )

function Ampbot:AddFriend(pl)
   if ValidEntity(pl) and pl != LocalPlayer() then
      table.insert(Ampbot.Friends , pl:SteamID())
      file.Write("Ampbot_friends.txt" , TableToKeyValues(Ampbot.Friends))
   end
end

function Ampbot:RemoveFriend(pl)
   if ValidEntity(pl) then
      for k , v in pairs(Ampbot.Friends) do
         if string.Trim(v) == pl:SteamID() then
            Ampbot.Friends[k] = nil
         end
      end
      PrintTable(Ampbot.Friends)
      file.Write("Ampbot_friends.txt" , TableToKeyValues(Ampbot.Friends))
   end
end

function Ampbot:AddFriendByName(nick)
   for k , v in ipairs(player.GetAll()) do
      if string.find(string.lower(v:Nick()) , string.lower(nick)) then
         Ampbot:AddFriend(v)
         break
      end
   end
end

function Ampbot:RemoveFriendByName(nick)
   for k , v in ipairs(player.GetAll()) do
      if string.find(string.lower(v:Nick()) , string.lower(nick)) then
         Ampbot:RemoveFriend(v)
         break
      end
   end
end

function Ampbot:GetFriends()
   local friends = {}
   local notfriends = {}
   
   for k , v in ipairs(player.GetAll()) do
      if self:IsPlayerFriend(v) then
         table.insert(friends , v)
      elseif v != LocalPlayer() then
         table.insert(notfriends , v)
      end
   end
   
   return friends, notfriends
end


function Ampbot:IsPlayerFriend(pl)
   local steamid = (pl.SteamID and pl:SteamID() or "")
   return table.HasValue(Ampbot.Friends , steamid)
end


local gmod_GetWeapons = _R['Player'].GetWeapons

local TGuns = {"weapon_ttt_c4", "weapon_ttt_knife", "weapon_ttt_phammer", "weapon_ttt_sipistol", "weapon_ttt_flaregun", "weapon_ttt_push", "weapon_ttt_radio", "weapon_ttt_teleport"}
local traitors = {}
local allocatedweapons = {}
local cleared = false
function Ampbot:CheckTraitors()
   if not GAMEMODE or not GAMEMODE.Name or not string.find(GAMEMODE.Name , "Trouble in Terror") or not Ampbot.Settings.RevealTraitors then return end
   
   for k , pl in ipairs(player.GetAll()) do
      if pl != LocalPlayer() then
         for _ , wep in pairs(gmod_GetWeapons(pl)) do
            if table.HasValue(TGuns , wep:GetClass()) and not table.HasValue(traitors , pl) and not table.HasValue(allocatedweapons , wep) and not pl:IsDetective() then
               chat.AddText(Color(50 , 205 , 50) , "[Ampbot] " ,  Color(235 , 235 , 235) , string.format("Player %s has collected traitor weapon %s" , pl:Nick() , wep:GetClass()) )
               table.insert(traitors,  pl)
               table.insert(allocatedweapons , wep)
               cleared = false
            end
         end
      end
      if table.HasValue(traitors , pl) and !( pl:Health() > 0 or pl:GetMoveType() != MOVETYPE_OBSERVER ) then
         chat.AddText(Color(50 , 205 , 50) , "[Ampbot] " ,  Color(235 , 235 , 235) , string.format("Traitor %s has died" , pl:Nick()))
         for a , b in pairs(traitors) do
            if b == pl then
               traitors[a] = nil
            end
         end
      end
   end
end

Ampbot.Hook("Think" , Ampbot.CheckTraitors)

function Ampbot:PrintTraitors()
   MsgN("--------------------------------------")
   print("Name" , "Health" , "Distance")
   for k , v in ipairs(traitors) do
      print(v:Nick() , v:Health() , v:GetPos():Distance(LocalPlayer():GetPos()))
   end
   print(#traitors.." of total ".. math.floor(#player.GetAll() / 4).." traitors detected.")
   MsgN("--------------------------------------")
end

concommand.Add("Ampbot_printtraitors" , Ampbot.PrintTraitors)

function Ampbot:IsTraitor(pl)
   return table.HasValue(traitors , pl)
end

local umsg = usermessage.IncomingMessage

function usermessage.IncomingMessage(name , um , ...)
   if name == "ttt_role" then
      MsgN("[Ampbot] Clearing traitors - round end.")
      for k , v in pairs(traitors) do
         if ValidEntity(v) then
            chat.AddText(Color(50 , 205 , 50) , "[Ampbot] " ,  Color(235 , 235 , 235) , string.format("Removing traitor %s - the round has ended." , v:Nick()))
         end
         traitors[k] = nil
      end
   end
   
   return umsg(name , um , ...)
end
Ampbot:Detour("usermessage" , "IncomingMessage" , umsg)

function Ampbot:GetPlayerDanger(pl)
   return 1
end

function Ampbot:GetAllTargets()
   local ret = {}
   for k , v in ipairs(ents.GetAll()) do
      if ValidEntity(v) then
         if LocalPlayer() != v and v:IsPlayer() or v:IsNPC() or string.find(v:GetClass() , "npc") then
            if !(v:IsPlayer() and v:Health() <= 0 and v:GetMoveType() != 0)  and !( (v:IsNPC() or string.find(v:GetClass() , "npc")) and v:GetMoveType() == 0) then
               if ( (LocalPlayer():GetPos():Distance(v:GetPos()) < tonumber(Ampbot.Settings.MaxDistance)) or tonumber(Ampbot.Settings.MaxDistance) == 0 ) then
                  if !(!Ampbot.Settings.FriendlyFire and (v.Team and v:Team() == LocalPlayer():Team())) then
                     if (Ampbot.Settings.TargetNPCs or !v:IsNPC() or not string.find(v:GetClass() , "npc")) and !(Ampbot.Settings.CheckNPCRelationship and (v:IsNPC() and !IsEnemyEntityName(v:GetClass()))) then--and (Ampbot.Settings.CheckNPCRelationship or !(v:IsNPC() and IsEnemyEntityName(v:GetClass()))) then
                        if Ampbot.Settings.TargetSteamFriends or (!v.GetFriendStatus or v:GetFriendStatus() != "friend") then
                           if !(Ampbot.Settings.TargetAdmins and (v.IsAdmin and v:IsAdmin())) then
                              if ( not Ampbot:IsPlayerFriend(v) or Ampbot.Settings.TargetFriends ) then
                                 if string.find(string.lower(GAMEMODE.Name) , "terror") then
                                    if LocalPlayer():IsTraitor() and not v:IsTraitor() then
                                       table.insert(ret , v)
                                    elseif not LocalPlayer():IsTraitor() and Ampbot:IsTraitor(v) then
                                       table.insert(ret , v)
                                    elseif not Ampbot.Settings.TargetOnlyTraitors then
                                       table.insert(ret , v)
                                    end
                                 else
                                    table.insert(ret , v)
                                 end
                              end
                           end
                        end
                     end
                  end
               end
            end
         end
      end
   end
   return ret
end

--[[]]
      
      
function Ampbot:GetAllWalliesEntities()
   local ret = {}
   for k , v in ipairs(ents.GetAll()) do
      if ValidEntity(v) then
         if v:IsPlayer() or v:IsNPC() or table.HasValue(Ampbot.WalliesEntities , v:GetClass()) and v != LocalPlayer() or (Ampbot.Settings.DrawWeapons and (v:IsWeapon() or string.find(v:GetClass() , "weapon")))  then
            if !(v.Team and (v:Team() == LocalPlayer():Team()) and Ampbot.Settings.DrawOnlyEnemies) then
               if ( (tonumber(Ampbot.Settings.MaxDistance) == 0) or (tonumber(v:GetPos():Distance(LocalPlayer():GetPos())) < tonumber(Ampbot.Settings.MaxDistance))) then
                  if (v:IsPlayer() or v:IsNPC()) and v:GetMoveType() != 0 and v:GetMoveType() != 10 then
                     table.insert(ret , v)
                  elseif not v:IsPlayer() and not v:IsNPC() then
                     table.insert(ret , v)
                  end
               end
            end
         end
      end
   end
   return ret
end

-- Sort function worked well. I'll use it too.

function Ampbot:GetSortedTargets()
   local targets = self:GetAllTargets()
   
   local sort = {}
   
   local myang = LocalPlayer():GetAngles()
   
   for k , v in ipairs(targets) do
      local ang = (v:GetPos() - LocalPlayer():GetPos()):Angle()
      local angdiffy = math.abs(math.NormalizeAngle( myang.y - ang.y ) )
      local angdiffp = math.abs(math.NormalizeAngle( myang.p - ang.p ) )
      
      if (angdiffy < tonumber(Ampbot.Settings.MaxAngle) and angdiffp < tonumber(Ampbot.Settings.MaxAngle)) or tonumber(Ampbot.Settings.MaxAngle) == 0 then
         table.insert(sort , {ent = v , dist = LocalPlayer():GetPos():Distance(v:GetPos()) , health = v:Health() , ang = angdiffy , danger = Ampbot:GetPlayerDanger(v) })
      end
   end
   
   
   local targetmode = Ampbot.Settings.TargetMode
   if self.TargetModes[math.floor(targetmode)] then
      targetmode = self.TargetModes[math.floor(targetmode)]
      local nearestmember
      
      if targetmode == "AimDistance" then
         table.SortByMember(sort , "dist" , function(a , b) return a > b end )
      elseif targetmode == "AimHealth" then
         table.SortByMember(sort , "health" , function(a , b) return a > b end )
      elseif targetmode == "AimAngle" then
         table.SortByMember(sort , "ang" , function(a , b) return a < b end )
      elseif targetmode == "AimDanger" then
         table.SortByMember(sort , "danger" , function(a , b) return a < b end )
      end
   end
   
   return sort
end

local bvis = {t = 0 , ent}
local alternatechecks = {
[1] = "ValveBiped.Bip01_L_Forearm",
[2] = "ValveBiped.Bip01_R_Forearm",
[3] = "ValveBiped.Bip01_L_Calf",
[4] = "ValveBiped.Bip01_R_Calf",
}

function Ampbot:GetBestVisibleTarget()
   if bvis.t == CurTime() and bvis.pos then
      return bvis.ent , bvis.pos
   elseif bvis.t == CurTime() then
      return bvis.ent
   end
   
      local targets = self:GetSortedTargets()
   if Ampbot.Settings.IgnoreLOS then
      if targets[1] then
         return targets[1].ent
      end
   end
   
   for k , v in ipairs(targets) do
      local pos = Ampbot:GetBestBonePos(v.ent)
      pos = Ampbot:GetWeaponPredictionPos(pos , v.ent)
      local trace = {}
      trace.start = LocalPlayer():GetShootPos()
      trace.endpos = pos
      trace.mask = 1174421507
      trace.filter = {LocalPlayer() , v.ent}

      local tr = util.TraceLine(trace)
      if not tr.Hit then
         bvis.t = CurTime()
         bvis.ent = v.ent
         bvis.pos = nil
         return v.ent
      end
   end
   
   if Ampbot.Settings.CheckPartialHits then
      for k , v in ipairs(targets) do
         for a , b in ipairs(alternatechecks) do
            local bone = v.ent:LookupBone(b)
            if bone then
               local pos , angle = v.ent:GetBonePosition(bone)
               
               if pos then
                  local trace = {}
                  trace.start = LocalPlayer():GetShootPos()
                  trace.endpos = Ampbot:GetWeaponPredictionPos(pos , v.ent)
                  trace.mask = 1174421507
                  trace.filter = {LocalPlayer() , v.ent}

                  local tr = util.TraceLine(trace)
                  if not tr.Hit then
                     bvis.t = CurTime()
                     bvis.ent = v.ent
                     bvis.pos = pos
                     return v.ent , pos
                  end
               end
            end
         end
      end
   end
end

local weapons = {
["weapon_crossbow"] = 3110,
}

function Ampbot:GetWeaponPredictionPos(pos , pl)
   if ValidEntity(pl) and type(pl:GetVelocity()) == "Vector" and pl.GetPos and type(pl:GetPos()) == "Vector" then
      local distance = LocalPlayer():GetPos():Distance(pl:GetPos())
      local weapon = (LocalPlayer().GetActiveWeapon and (ValidEntity(LocalPlayer():GetActiveWeapon()) and LocalPlayer():GetActiveWeapon():GetClass()))
      
      if weapon and weapons[weapon] then
         local time = distance / weapons[weapon]
         return pos + pl:GetVelocity() * time
      elseif Ampbot.Settings.VelocityPrediction then
         
         if LocalPlayer():GetVelocity():Length() > 100 then
            pos = pos - Vector(0 , 0 , LocalPlayer():GetVelocity():Length() / 220)
         end
         
         return pos + pl:GetVelocity() * 0.0067 - LocalPlayer():GetVelocity() * 0.0067 -- ( pl:GetVelocity() / 47 - LocalPlayer():GetVelocity() / 47 )--+ ( pl.GetVelocity and pl:GetVelocity() * 0.0025 * LocalPlayer():Ping() )
         
      end
      
      return pos
   end
   return pos
end


Ampbot.Attachments = {

["Head"] = "eyes",
["Spine"] = "chest",
}

Ampbot.Bones = {
["Head"] = {


["models/zombie/classic.mdl"] = "ValveBiped.HC_Body_Bone" ,
["models/zombie/fast.mdl"] = "ValveBiped.HC_BodyCube",
["models/zombie/poison.mdl"] = "ValveBiped.Bip01_Spine4" , 
["other"] = "ValveBiped.Bip01_Head1",
},

["Spine"] = {

["other"] = "ValveBiped.Bip01_Spine",

} ,

["Shoulder"] = {

["other"] = "ValveBiped.Bip01_R_Shoulder",

},
}

function Ampbot:GetBestBonePos(ent)
   local bonetype = Ampbot.BoneTargets[math.floor(tonumber(Ampbot.Settings.BoneTarget))]
   if self.Attachments[bonetype] then
      local attach = ent:LookupAttachment(self.Attachments[bonetype])
      if attach then
         local p = ent:GetAttachment(attach)
         if p then
            if p.Pos then
               return Ampbot:GetWeaponPredictionPos(p.Pos , ent) , p.Ang
            end
            --return p.Pos
         end
      end
   end
   if self.Bones[bonetype] then
      local boneid = ent:LookupBone(self.Bones[bonetype][ent:GetModel()] or self.Bones[bonetype]["other"])
      local pos , ang = ent:GetBonePosition(boneid)
      
      if pos then
         pos, ang = Ampbot:GetWeaponPredictionPos(pos , ent) , ang
         return pos , ang
      end
   else
      for k , v in pairs(self.Bones) do   
         local boneid = ent:LookupBone(v[ent:GetModel()] or v["other"])
         if boneid then
            local pos , ang = ent:GetBonePosition(boneid)
            --pos = pos - (1/ent:GetVelocity())
            --pos = pos - (20/ent:GetVelocity())
            pos , ang = Ampbot:GetWeaponPredictionPos(pos , ent), ang
            
            if pos then
               return pos , ang
            end
         end
      end
   end
end


function Ampbot:GetAntisnapAngle(ang)
   local p , y , r = ang.p , ang.y , ang.r
   
   local curang = LocalPlayer():EyeAngles()
   local speed = tonumber(Ampbot.Settings.AntiSnapSpeed)
   local retangle = Angle(0 , 0 , 0)
   
   retangle.p = math.Approach( math.NormalizeAngle(curang.p) ,  math.NormalizeAngle(p), speed)
   retangle.y = math.Approach( math.NormalizeAngle(curang.y) ,  math.NormalizeAngle(y), speed)
   retangle.r = 0
   
   return Angle(retangle.p , retangle.y , retangle.r)
end

local set = false

local dontreload = {"weapon_physgun" , "weapon_gravgun" , "gmod_tool"}


Ampbot.NextFire = 0
Ampbot.CUserCMDNum = 0
Ampbot.NextReload = 0
function Ampbot.CreateMove(ucmd)
   Ampbot.CUserCMDNum = Ampbot.CUserCMDNum + 1
   
   if Ampbot.Settings.EnableAimbot and ( !Ampbot.Settings.SnapOnFire or Ampbot.IsFireButtonDown ) then
      local targ  , pos = Ampbot:GetBestVisibleTarget()
      
      if (type(targ) == "Player" or type(targ) == "NPC") and ValidEntity(targ) and type(pos) != "Vector" then
         local pos , ang = Ampbot:GetBestBonePos(targ)
         Ampbot.TargetLocked = targ
         if pos then
            local a = (pos - LocalPlayer():EyePos()):Angle()
            
            if Ampbot.Settings.AntiSnap then
               a = Ampbot:GetAntisnapAngle(a)
            end
            
            Ampbot.RealAngle = a
            
            if Ampbot.PredictSpread and Ampbot.Settings.NoSpread then
               a = Ampbot.PredictSpread(ucmd , a)
            end
            
            local p , y , r = a.p , a.y , a.r
            p , y , r = math.NormalizeAngle(p) , math.NormalizeAngle(y) , math.NormalizeAngle(r)
            
            ucmd:SetViewAngles( Angle(p , y , r) )
         end
      elseif (type(targ) == "Player" or type(targ) == "NPC") and ValidEntity(targ) and type(pos) == "Vector" then
         local a = (pos - LocalPlayer():EyePos()):Angle()
         
         if Ampbot.Settings.AntiSnap then
            a = Ampbot:GetAntisnapAngle(a)
         end
            
         Ampbot.TargetLocked = targ
         Ampbot.RealAngle = a
         
         if Ampbot.PredictSpread and Ampbot.Settings.NoSpread then
            a = Ampbot.PredictSpread(ucmd , a)
         end
         
         
         local p , y , r = a.p , a.y , a.r
         p , y , r = math.NormalizeAngle(p) , math.NormalizeAngle(y) , math.NormalizeAngle(r)
         ucmd:SetViewAngles( Angle(p , y , r) )
         
      else
         Ampbot.TargetLocked = false
      end
   elseif Ampbot.TargetLocked then
      Ampbot.TargetLocked = false
   end
   
   if Ampbot.Settings.AutoFire and Ampbot.TargetLocked and Ampbot.NextFire <= Ampbot.CUserCMDNum  then
      if Ampbot.Settings.AntiSnap then
         local target = Ampbot.TargetLocked
         
         if target then
            local myang = LocalPlayer():EyeAngles()
            local ang = (target:GetPos() - LocalPlayer():GetPos()):Angle()
            local angdiffy = math.abs(math.NormalizeAngle( myang.y - ang.y ) )
            local angdiffp = math.abs(math.NormalizeAngle( myang.p - ang.p ) )
      
            if angdiffy < 4 and angdiffp < 4 then
               Ampbot.Firing = true
               ucmd:SetButtons( ucmd:GetButtons() | IN_ATTACK )
               Ampbot.NextFire = Ampbot.CUserCMDNum + 2
            end
         end
      else
         Ampbot.NextFire = Ampbot.CUserCMDNum + 2
         
         if Ampbot.Settings.UCMDFire then
            ucmd:SetButtons( ucmd:GetButtons() | IN_ATTACK )
         else
            RunConsoleCommand("+attack")
         end
      end
   elseif  Ampbot.NextFire > Ampbot.CUserCMDNum and not Ampbot.Settings.UCMDFire then
      RunConsoleCommand("-attack")
   end
   
   if Ampbot.Settings.AutoReload and (LocalPlayer and LocalPlayer() and ValidEntity(LocalPlayer():GetActiveWeapon())) and Ampbot.NextReload < CurTime()then
      if LocalPlayer():GetActiveWeapon():Clip1() <= 0 and not table.HasValue(dontreload , LocalPlayer():GetActiveWeapon():GetClass()) then
         ucmd:SetButtons(ucmd:GetButtons() | IN_RELOAD)   
         Ampbot.NextReload = CurTime() + 5
      end
   end
end

Ampbot.Hook("CreateMove" , Ampbot.CreateMove)

Ampbot.WalliesDraw = {
{method = "Nick" , prefix = "" , boolmethod = {"IsPlayer"} , suffix = "" , font = "Ampbot_Font" , default = "#nick" , offset = {x = 0 , y = -5} , colour = Color(255 , 0 , 0 , 255) } ,
{method = "Health" , boolmethod = {"IsPlayer" , "IsNPC"}, prefix = "Health: " , suffix = "" , font = "Ampbot_Font_Small" , default = "#health" , offset = {x = 0 , y = 15} , exception = function(ent) return !Ampbot.Settings.DrawTextInfo end ,  },
{method = "Armor" , prefix = "Armour: " , suffix = "" , font = "Ampbot_Font_Small" , default = "#armour" , offset = {x = 0 , y = 15} , exception = function(ent) return !Ampbot.Settings.DrawTextInfo end , } ,
{method = "IsAdmin" , prefix = "Admin " , suffix = "" , font = "Ampbot_Font_Small" , default = "#admin" , offset = {x = 0 , y = 15} , exception = function(ent) return !Ampbot.Settings.DrawTextInfo or !ent:IsAdmin() end , colour = Color(220 , 0 , 0 , 255)} ,
{method = "GetClass" , prefix = "Class: " , suffix = "" , font = "Ampbot_Font_Small" , default = "#nil" , offset = {x = 0 , y = 15 } , exception = function(ent) if type(ent) == "Weapon" and ent.Owner:IsPlayer() or !Ampbot.Settings.DrawTextInfo or ent:IsPlayer() then return true else return false end end ,},
{method = "IsPlayer" , prefix = "TRAITOR" , suffix = "" , font = "Ampbot_Font_Small" , default = "#traitor" , offset = {x = 0 , y = 15} , exception = function(ent) return (!Ampbot:IsTraitor(ent) or !Ampbot.Settings.RevealTraitors or (ent.IsDetective and ent:IsDetective())) end , colour = Color(220 , 70 , 0) , } ,
{method = "IsPlayer" , prefix = "DETECTIVE" , suffix = "" , font = "Ampbot_Font_Small" , default = "#detective" , offset = {x = 0 , y = 15} , exception = function(ent) return (!ent.IsDetective or !ent:IsDetective()) end , colour = Color(20 , 0 , 255 , 255) , } ,
}

function Ampbot.HUDPaint()
   if Ampbot.Settings.EnableWallies then
      for k , v in ipairs(Ampbot:GetAllWalliesEntities()) do
         if LocalPlayer() != v  and (v:IsPlayer() and v:Health() > 0 or not v:IsPlayer()) and v:GetMoveType() != MOVETYPE_OBSERVER and v:GetMoveType() != MOVETYPE_NONE  and (v:GetPos():Distance(LocalPlayer():GetPos()) <= tonumber(Ampbot.Settings.MaxDistance) or tonumber(Ampbot.Settings.MaxDistance) == 0 ) then
            local pos = v:EyePos() + Vector(0 , 0 , 25)
            local spos = pos:ToScreen()
            local startpos = {x = spos.x , y = spos.y}
            if spos.visible then 
               for a , b in pairs(Ampbot.WalliesDraw) do
                  local ret = true
                  if b.boolmethod then
                     for c , d in pairs(b.boolmethod) do
                        if v[d](v) == true then
                           ret = false
                        end
                     end
                  else
                     ret = false
                  end
                  if v[b.method] and not ( ret ) and not (b.exception and b.exception(v)) then
                     local x , y = spos.x , spos.y
                     
                     startpos.x = startpos.x + b.offset.x 
                     startpos.y = startpos.y + b.offset.y
                     
                     local methodresult = v[b.method](v)
                     if type(methodresult) == "boolean" then
                        methodresult = ""
                     end
                     
                     draw.SimpleText((b.prefix or "") .. (methodresult or b.default) .. (b.suffix or "") , b.font , startpos.x , startpos.y , (b.colour or Color(0 , 255 , 0 , 255)) , TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
                  end
               end
            end
         end
      end
   end
   
   if Ampbot.Settings.EnableAimbot then
      if Ampbot.TargetLocked then
         draw.SimpleText("Found ("..(Ampbot.TargetLocked.Nick and Ampbot.TargetLocked:Nick() or Ampbot.TargetLocked:GetClass() )..")" , "Ampbot_Font" , ScrW() / 2 , ScrH() / 2 + 15 , Color(255 , 0 , 0 , 255) , TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
      else
         draw.SimpleText("Searching" , "Ampbot_Font" , ScrW() / 2 , ScrH() / 2 + 15 , Color(56 , 186 , 255 , 200) , TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
      end
   end
end

Ampbot.Hook("HUDPaint" , Ampbot.HUDPaint)
Ampbot.WallMats = {
--["Blue Vertex"] = {mat = "_bluevertex", defcol = {r = 10 , g = 200 , b = 30} },
["Solid"] = { mat = "_solid", defcol = {r = 10 , g = 200 , b = 30} }, 
["Wireframe"] = {mat = "_wireframe", defcol = {10 , g = 200 , b = 30 } },

}

function Ampbot.DrawModels()
   if Ampbot.Settings.EnableWallies and Ampbot.Settings.DrawModels then
      cam.Start3D(EyePos() , EyeAngles())
         for k , v in ipairs(Ampbot:GetAllWalliesEntities()) do
            if LocalPlayer() != v and (LocalPlayer():GetPos():Distance(v:GetPos()) < tonumber(Ampbot.Settings.MaxDistance) or tonumber(Ampbot.Settings.MaxDistance) == 0 ) then
               if Ampbot.Settings.ComplexDrawing then
                  local typ = Ampbot.Settings.WallhackMaterial
                  local smat
                  if Ampbot.WallMats[typ] then
                     smat = "Ampbot/Ampbot"..Ampbot.WallMats[typ].mat
                  else
                     smat = "Ampbot/Ampbot_Solid"
                  end
                  
                  local drawc = Color(0 , 0 , 0 , 0)
                  local oldmat
                  local draw = false
                  if type(v) == "Player" and v:Health() > 0 and v:GetMoveType() != MOVETYPE_OBSERVER then
                     oldmat = v:GetMaterial()
                     drawc = team.GetColor(v:Team())
                     
                     if string.find(string.lower(GAMEMODE.Name) , "terror") then
                        if Ampbot:IsTraitor(v) and not LocalPlayer():IsTraitor() and not v:IsDetective() then
                           drawc = Color(56 , 186 , 255, 255)
                        elseif LocalPlayer():IsTraitor() and v:IsTraitor() then
                           drawc = Color(255 , 125 , 0 , 255)
                        elseif v:IsDetective() then
                           drawc = Color(0 , 0 , 255 , 255)
                        end
                     end
                     draw = true
                  elseif type(v) == "NPC" and v:GetMoveType() != MOVETYPE_NONE then
                     if IsEnemyEntityName(v:GetClass()) or v:GetClass() == "npc_metropolice" then
                        drawc = Color(255 , 20 , 255)
                     else
                        drawc = Color(20 , 255 , 255)
                     end
                     oldmat = v:GetMaterial()
                     draw = true
                  elseif type(v) == "Weapon" or string.find(v:GetClass() , "weapon") then
                     oldmat = v:GetMaterial()
                     drawc = Color(0 , 255 , 255)
                     draw = true
                  elseif not v:IsPlayer() and not v:IsNPC() and not v:IsWeapon() and not string.find(v:GetClass() , "weapon") then
                     oldmat = v:GetMaterial()
                     drawc = Color(120, 0 , 120)
                     draw = true
                     
                  end
                  if draw then
                     render.SuppressEngineLighting( true )
                     render.SetColorModulation( (drawc.r/255), (drawc.g/255), (drawc.b/255) )
                     v:SetModelScale(Vector(1.1,1.1,1))
                     v:SetMaterial(smat)
                     v:DrawModel()
                     render.SuppressEngineLighting( false )
                     render.SetColorModulation( 1, 1, 1 )
                     v:SetModelScale(Vector(1,1,1))
                     v:SetMaterial(mat)
                     v:DrawModel()
                  end
               elseif (v:IsPlayer() and v:Health() > 0) or (v:IsNPC() and v:GetMoveType() != 0) or (!v:IsNPC() and !v:IsPlayer()) then
                  cam.IgnoreZ(true)
                     render.SuppressEngineLighting(true)
                        v:DrawModel()
                     render.SuppressEngineLighting(false)
                  cam.IgnoreZ(false)
               end
            end
         end
      cam.End3D()
   end
end

Ampbot.Hook("RenderScreenspaceEffects" , Ampbot.DrawModels)

function Ampbot.CorrectView(pl , org , ang , fov)
   if Ampbot.TargetLocked then
      local view = {}
      view.origin = org
      view.angles = Ampbot.RealAngle
      view.fov = ((Ampbot.Settings.ZoomToCurrentTarget and Ampbot.Settings.ZoomFactor != 0) and (90 / (1 + (1 * Ampbot.Settings.ZoomFactor)) ) or fov)
      return view
   end
end

Ampbot.Hook("CalcView" , Ampbot.CorrectView)

function Ampbot:NoRecoil()
   if Ampbot.Settings.NoRecoil then
      if ValidEntity(LocalPlayer():GetActiveWeapon()) and (LocalPlayer():GetActiveWeapon().Primary and LocalPlayer():GetActiveWeapon().Primary.Recoil != 0) then
         LocalPlayer():GetActiveWeapon().OldRecoil = LocalPlayer():GetActiveWeapon().Recoil or (LocalPlayer():GetActiveWeapon().Primary and LocalPlayer():GetActiveWeapon().Primary.Recoil)
         LocalPlayer():GetActiveWeapon().Recoil = 0
         LocalPlayer():GetActiveWeapon().Primary.Recoil = 0
      end
   elseif ValidEntity(LocalPlayer():GetActiveWeapon()) and (LocalPlayer():GetActiveWeapon().Primary and LocalPlayer():GetActiveWeapon().Primary.Recoil == 0) and LocalPlayer():GetActiveWeapon().OldRecoil then
      LocalPlayer():GetActiveWeapon().Recoil = LocalPlayer():GetActiveWeapon().OldRecoil
      LocalPlayer():GetActiveWeapon().Primary.Recoil = LocalPlayer():GetActiveWeapon().OldRecoil
   end
end

Ampbot.Hook("Think" , Ampbot.NoRecoil)

Ampbot.IsFireButtonDown = false
local lastfiretime = 0

function Ampbot.GetFireButton()
   if ValidEntity(LocalPlayer()) then
      if LocalPlayer():KeyDown(IN_ATTACK) then
         lastfiretime = CurTime()
         Ampbot.IsFireButtonDown = true
      elseif lastfiretime + (ValidEntity(LocalPlayer():GetActiveWeapon()) and (LocalPlayer():GetActiveWeapon():GetTable().Primary and LocalPlayer():GetActiveWeapon():GetTable().Primary.Delay or math.max(0.05 , Ampbot.Settings.SnapOnFireTime) ) or 0.2) < CurTime() then
         Ampbot.IsFireButtonDown = false
      end
   end
end

Ampbot.Hook("Think" , Ampbot.GetFireButton)


concommand.Add("Ampbot_aim_toggle" , function()   
   RunConsoleCommand("Ampbot_aim_enabled" , Ampbot.Settings.EnableAimbot and 0 or 1)
end )

concommand.Add("+Ampbot_aim" , function()
   RunConsoleCommand("Ampbot_aim_enabled" , 1)
end )

concommand.Add("-Ampbot_aim" , function()
   RunConsoleCommand("Ampbot_aim_enabled" , 0)
end )

concommand.Add("Ampbot_Wallies_toggle" , function()
   RunConsoleCommand("Ampbot_Wallies_enabled" , Ampbot.Settings.EnableWallies and 0 or 1)
end )

concommand.Add("+Ampbot_Wallies" , function()
   RunConsoleCommand("Ampbot_Wallies_enabled" , 1)
end )

concommand.Add("-Ampbot_Wallies" , function()
   RunConsoleCommand("Ampbot_Wallies_enabled" , 0)
end )

concommand.Add("Ampbot_reload" , function(p , c , a)
   if Ampbot then
      print("Ampbot is currently Reloading")
      for k , v in pairs(Ampbot.Hooks) do
         --hook.GetTable()[k][v] = nil
         hook.Remove(k , v.Index)
         MsgN("Ampbot has Removed hook "..k.."("..v.Index..")")
      end
      
      for k , v in pairs(Ampbot.DetouredFuncs) do
         _G[v.tbl][v.key] = v.func
      end
      
      if Ampbot.Menu then Ampbot.Menu:Remove() end
      
      concommand.Remove("Ampbot_menu")
      concommand.Remove("Ampbot_reload")
      
      noerr , ret = pcall(include , "ampbot/ampbot.lua")
      
      if not noerr then
         ErrorNoHalt(ret.."\n")
      end
      print("Ampbot Successfully loaded!")
      
   end
end )

Ampbot.MenuItems = { 
{label = "Aimbot" , objects = function()

local dpanel = vgui.Create("DPanel")
dpanel:SetPos(151 , 23)
dpanel:SetSize(Ampbot.Menu:GetWide() - 151 , Ampbot.Menu:GetTall() - 23)
dpanel.Paint = function()
      surface.SetDrawColor( 30, 30, 30, 190 )    
      surface.DrawRect( 0, 0, dpanel:GetWide(), dpanel:GetTall() )    
      surface.SetDrawColor( 40, 40, 40, 190 )    
      surface.DrawOutlinedRect( 0, 0, dpanel:GetWide(), dpanel:GetTall() )
   end

local dlabel = vgui.Create("DLabel")
dlabel:SetText("Ampbot")
dlabel:SetTextColor(Color(130, 130 , 130))
dlabel:SetFont("Ampbot_Font_Large")
local texw, texh = surface.GetTextSize("Ampbot Beta V2")
dlabel:SetPos((Ampbot.Menu:GetWide() - 151 - 123 ) / 3.5 , -30)
dlabel:SetSize(150 + 500 , texh + 80)
dlabel:SetParent(dpanel)

local dlabel3 = vgui.Create("DLabel")
dlabel3:SetText("Beta")
dlabel3:SetTextColor(Color(0, 91 , 255))
dlabel3:SetFont("Ampbot_Font_Large")
local texw, texh = surface.GetTextSize("Beta")
dlabel3:SetPos((Ampbot.Menu:GetWide() - 151 - 123 ) / 1.4 , -30)
dlabel3:SetSize(150 + 500 , texh + 80)
dlabel3:SetParent(dpanel)

local dlabel4 = vgui.Create("DLabel")
dlabel4:SetText("V2")
dlabel4:SetTextColor(Color(130, 130 , 130))
dlabel4:SetFont("Ampbot_Font_Large")
local texw, texh = surface.GetTextSize("V1")
dlabel4:SetPos((Ampbot.Menu:GetWide() - 151 - 123 ) / 1.02 , -30)
dlabel4:SetSize(150 + 500 , texh + 80)
dlabel4:SetParent(dpanel)

local dlabel2 = vgui.Create("DLabel")
dlabel2:SetText("Aimbot Settings")
dlabel2:SetTextColor(Color(100, 100 , 100))
dlabel2:SetFont("Ampbot_Font")
local texw, texh = surface.GetTextSize("Aimbot Settings")
dlabel2:SetPos((Ampbot.Menu:GetWide() - 151 - 123 ) / 2 , -6)
dlabel2:SetSize(150 + 15 , texh + 80)
dlabel2:SetParent(dpanel)

local dpanellist = vgui.Create("DPanelList")
dpanellist:SetPos(0 , texh + 25)
dpanellist:SetParent(dpanel)
dpanellist:SetSize((Ampbot.Menu:GetWide() - 151) / 2 - 100, Ampbot.Menu:GetTall() - texh - 26 - 30)
dpanellist:EnableVerticalScrollbar(true)
dpanellist:EnableHorizontal( false )
dpanellist:SetSpacing( 5 )
dpanellist.Paint = function() end

local friends_false = vgui.Create("DComboBox")
friends_false:SetParent(dpanel)
friends_false:SetPos(((Ampbot.Menu:GetWide() - 151) / 2 )- 90 , texh + 55 )
friends_false:SetSize(90 , 120 )
friends_false.OldItem = friends_false.SelectItem


friends_false.OldPaint = friends_false.Paint
friends_false.Paint = function(...)
   for k , v in pairs(friends_false:GetItems()) do
      if ValidEntity(v.Player) then
         v:SetText(v.Player:Nick())
      else
         v:Remove()
      end
   end
   return friends_false.OldPaint(...)
end

local friends_true = vgui.Create("DComboBox")
friends_true:SetParent(dpanel)
friends_true:SetPos(((Ampbot.Menu:GetWide() - 151) / 2 )- 90 + friends_false:GetWide() + 25 , texh + 55 )
friends_true:SetSize(90 , 120 )
friends_true.OldItem = friends_true.SelectItem

friends_true.OldPaint = friends_true.Paint
friends_true.Paint = function(...)
   for k , v in pairs(friends_true:GetItems()) do
      if ValidEntity(v.Player) then
         v:SetText(v.Player:Nick())
      else
         v:Remove()
      end
   end
   return friends_true.OldPaint(...)
end

function PopulateCombo()
   if friends_false and friends_false:IsValid() then
      friends_false:Clear()
      friends_true:Clear()
      
      local friends , notfriends = Ampbot:GetFriends()
      
      for k , v in pairs(friends) do
         local it = friends_true:AddItem(v:Nick())
         it.Player = v
      end
      
      for k , v in pairs(notfriends) do
         local it = friends_false:AddItem(v:Nick())
         it.Player = v
      end
   end
end

friends_true.SelectItem = function(self , item , multi)
   local pl = item.Player
   print("Ampbot is removing player "..pl:Nick().. " from the aim friends list.")
   Ampbot:RemoveFriend(pl)
   
   PopulateCombo()
end

friends_false.SelectItem = function(self , item,  multi)
   local pl = item.Player
   print("Ampbot is adding  player "..pl:Nick().. " to the aim friends list.")
   Ampbot:AddFriend(pl)
   
   PopulateCombo()
end

function AddPlayer(pl)
   --print("Ampbot: Entity created: " , pl)
   if pl:IsPlayer() then
      PopulateCombo()
   end
end
Ampbot.Hook("OnEntityCreated" , AddPlayer )

function RemovePlayer(pl)
   if pl:IsPlayer() then
      timer.Simple(0.1 , PopulateCombo)
   end
end
Ampbot.Hook("EntityRemoved" , RemovePlayer )

local dlabel = vgui.Create("DLabel")
dlabel:SetText("Enemies")
dlabel:SetTextColor(Color(70, 70 , 70))
dlabel:SetFont("Ampbot_Font")
local texw, texh = surface.GetTextSize("Enemies")
dlabel:SetPos(((Ampbot.Menu:GetWide() - 151) / 2 ) - 45 - 86 / 2.5 , friends_false:GetPos() - 100)
dlabel:SetSize(86 + 20 , texh + 15)
dlabel:SetParent(dpanel)

local dlabel = vgui.Create("DLabel")
dlabel:SetText("Allies")
dlabel:SetTextColor(Color(70, 70 , 70))
dlabel:SetFont("Ampbot_Font")
local texw, texh = surface.GetTextSize("Allies")
dlabel:SetPos(((Ampbot.Menu:GetWide() - 151) / 2 ) + 55 - 57 / 6 , friends_false:GetPos() - 100)
dlabel:SetSize(57 + 20 , texh + 15)
dlabel:SetParent(dpanel)

local dlabel2 = vgui.Create("DLabel")
dlabel2:SetText(" Unlite 2012 | Ampbot Beta V2 ")
dlabel2:SetTextColor(Color(58, 140 , 255))
dlabel2:SetFont("Ampbot_Font_SmallC")
local texwa, texha = surface.GetTextSize("�Ampbot")
dlabel2:SetPos((Ampbot.Menu:GetWide() - 91 - 190 ) / 0.97 , 384)
dlabel2:SetSize(texwa + 150 , texha + 120)
dlabel2:SetParent(dpanel)

local dpanellist2 = vgui.Create("DPanelList")
dpanellist2:SetPos(((Ampbot.Menu:GetWide() - 151) / 2 ) - 90 , 200)
dpanellist2:SetParent(dpanel)
dpanellist2:SetSize((Ampbot.Menu:GetWide() - 151 )/ 2 + 60 , 190)
dpanellist2:EnableVerticalScrollbar(true)
dpanellist2:EnableHorizontal( true )
dpanellist2:SetSpacing( 5 )
dpanellist2.Paint = function() end
local friends , notfriends = Ampbot:GetFriends()
for k , v in ipairs(friends) do
   local item = friends_true:AddItem(v:Nick())
   item.Player = v
end

for k , v in ipairs(notfriends) do
   local item = friends_false:AddItem(v:Nick())
   item.Player = v
end

local pos = texh + 20

local dmultichoice = vgui.Create("DMultiChoice")
dmultichoice:SetPos(355 , 125)
dmultichoice:SetSize(100 , 20)
dmultichoice:SetText(Ampbot.TargetModes[Ampbot.Settings.TargetMode] or (print(Ampbot.Settings.BoneTarget) or ""))

dmultichoice.OnSelect = function(self , ind , val)
   RunConsoleCommand("Ampbot_aim_targetmode" , ind)
end

for k , v in ipairs(Ampbot.TargetModes) do
   dmultichoice:AddChoice(v)
end
dmultichoice:SetParent(dpanel)

local dlabel = vgui.Create("DLabel")
dlabel:SetPos(355 , 105)
dlabel:SetSize(150 , 25)
dlabel:SetFont("Ampbot_Font_Small")
dlabel:SetText("Target Preference")
dlabel:SetTextColor(Color(70, 70 , 70))
dlabel:SetParent(dpanel)

local dmultichoice = vgui.Create("DMultiChoice")
dmultichoice:SetPos(355 , 75)
dmultichoice:SetSize(100 , 20)
dmultichoice:SetText(Ampbot.BoneTargets[Ampbot.Settings.BoneTarget] or (print(Ampbot.Settings.BoneTarget) or ""))

dmultichoice.OnSelect = function(self , ind , val)
   RunConsoleCommand("Ampbot_aim_BoneTarget" , ind)
end

dmultichoice:SetParent(dpanel)

for k , v in ipairs(Ampbot.BoneTargets) do
   dmultichoice:AddChoice(v)
end

local dlabel = vgui.Create("DLabel")
dlabel:SetPos(355 , 55)
dlabel:SetSize(150 , 25)
dlabel:SetFont("Ampbot_Font_Small")
dlabel:SetText("Bone Targeting")
dlabel:SetTextColor(Color(70, 70 , 70))
dlabel:SetParent(dpanel)


for k , v in SortedPairs(Ampbot.ConVarSettings.Aim) do
   if Ampbot.ConVarSettings["Aim"][k].type == "boolean" then
      if Ampbot.ConVarSettings["Aim"][k] and Ampbot.ConVarSettings["Aim"][k].var then
         local dcheckbox = vgui.Create("DCheckBoxLabel")
         dcheckbox:SetSize(125 , 20)
         dcheckbox:SetText(k)
      --   dcheckbox:SetConVar(Ampbot.ConVarSettings["Aim"][k].var)
         --dcheckbox:SetValue(GetConVar(Ampbot.ConVarSettings["Aim"][k].var):GetString())
         
         dcheckbox:SetValue(Ampbot.Settings[k])
         dpanellist:AddItem(dcheckbox)
         
         dcheckbox.LastChange = 0
         dcheckbox.OnChange = function()
            if dcheckbox.LastChange < CurTime()  then 
               dcheckbox.LastChange = CurTime() + 0.1
               --print(string.format("setting %s to %d: OnChange" , Ampbot.ConVarSettings["Aim"][k].var , dcheckbox:GetChecked() and 1 or 0))
               dcheckbox:SetValue(util.tobool(dcheckbox:GetChecked() and 1 or 0))
               RunConsoleCommand(Ampbot.ConVarSettings["Aim"][k].var , dcheckbox:GetChecked() and 1 or 0)
            end
         end
         
         cvars.AddChangeCallback(Ampbot.ConVarSettings["Aim"][k].var , function(c , o , n)
            if dcheckbox.LastChange < CurTime() then
               dcheckbox.LastChange = CurTime() + 0.1
               --print(string.format("setting %s to %d: Callback" , c , n))
               dcheckbox:SetValue(util.tobool(n))
            end
         end )
         
         
         pos = pos + 30
      else
         ErrorNoHalt("[Ampbot] 1285: Error - Aim ConVar setting nil. (".. k ..")\n")
      end
   elseif Ampbot.ConVarSettings["Aim"][k].type == "number" then
      local dnumslider = vgui.Create("DNumSlider")
      dnumslider:SetWide(130)
      dnumslider:SetPos(5 , 0)
      dnumslider:SetText(k)
      dnumslider:SetMin((Ampbot.ConVarSettings["Aim"][k].min) or 0)
      dnumslider:SetMax((Ampbot.ConVarSettings["Aim"][k].max) or 1)
      
      if !Ampbot.ConVarSettings["Aim"][k].dec then
         dnumslider:SetDecimals(0)
      else
         dnumslider:SetDecimals(1)
      end
      
      --dnumslider:SetValue(GetConVar(Ampbot.ConVarSettings["Aim"][k].var):GetString())
      
      dnumslider:SetValue(Ampbot.Settings[k])
      
      dnumslider.LastChange = 0
      --print(Ampbot.ConVarSettings["Aim"][k].var)
      dnumslider.ValueChanged = function(self , new)
         if dnumslider.LastChange < CurTime()  then 
            dnumslider.LastChange = CurTime() + 0.1
            --print(string.format("setting %s to %d: OnChange" , Ampbot.ConVarSettings["Aim"][k].var , new))
            dnumslider:SetValue(new)
            RunConsoleCommand(Ampbot.ConVarSettings["Aim"][k].var , new)
         end
      end
      
      cvars.AddChangeCallback(Ampbot.ConVarSettings["Aim"][k].var , function(c , o , n)
         if dnumslider.LastChange < CurTime() then
            dnumslider.LastChange = CurTime() + 0.1
            --print(string.format("setting %s to %d: Callback" , c , n))
            dnumslider:SetValue(n)
         end
      end )
      
      --dnumslider:SetConVar(Ampbot.ConVarSettings["Aim"][k].var)
      dpanellist2:AddItem(dnumslider)
   end
end
return dpanel
end ,},

{label = "Wallies" , objects = function()


local dpanel = vgui.Create("DPanel")
dpanel:SetPos(151 , 23)
dpanel:SetSize(Ampbot.Menu:GetWide() - 151 , Ampbot.Menu:GetTall() - 23)
dpanel.Paint = function()
      surface.SetDrawColor( 30, 30, 30, 190 )    
      surface.DrawRect( 0, 0, dpanel:GetWide(), dpanel:GetTall() )    
      surface.SetDrawColor( 40, 40, 40, 190 )    
      surface.DrawOutlinedRect( 0, 0, dpanel:GetWide(), dpanel:GetTall() )
   end
local dlabel = vgui.Create("DLabel")
dlabel:SetText("Wallie Settings")
dlabel:SetTextColor(Color(100, 100 , 100))
dlabel:SetFont("Ampbot_Font_Large2")
local texw, texh = surface.GetTextSize("Wallie Settings")
dlabel:SetPos((Ampbot.Menu:GetWide() - 151 - texw ) / 2 , 0)
dlabel:SetSize(texw + 180 , texh + 35)
dlabel:SetParent(dpanel)

local dpanellist = vgui.Create("DPanelList")
dpanellist:SetPos(0 , texh + 25)
dpanellist:SetParent(dpanel)
dpanellist:SetSize((Ampbot.Menu:GetWide() - 151) / 2 - 100, Ampbot.Menu:GetTall() - texh - 26 - 30)
dpanellist:EnableVerticalScrollbar(true)
dpanellist:EnableHorizontal( false )
dpanellist:SetSpacing( 5 )
dpanellist.Paint = function() end

local Wallies_false = vgui.Create("DComboBox")
Wallies_false:SetParent(dpanel)
Wallies_false:SetPos(((Ampbot.Menu:GetWide() - 151) / 2 )- 90 , texh + 55 )
Wallies_false:SetSize(150 , 120 )
Wallies_false.OldItem = Wallies_false.SelectItem

local Wallies_true = vgui.Create("DComboBox")
Wallies_true:SetParent(dpanel)
Wallies_true:SetPos(((Ampbot.Menu:GetWide() - 151) / 2 )- 90 + Wallies_false:GetWide() + 0 , texh + 55 )
Wallies_true:SetSize(135 , 120 )
Wallies_true.OldItem = Wallies_true.SelectItem

local dlabel2 = vgui.Create("DLabel")
dlabel2:SetText(" Unlite 2012 | Ampbot Beta V2 ")
dlabel2:SetTextColor(Color(58, 140 , 255))
dlabel2:SetFont("Ampbot_Font_SmallC")
local texwa, texha = surface.GetTextSize("�Ampbot")
dlabel2:SetPos((Ampbot.Menu:GetWide() - 91 - 190 ) / 0.97 , 384)
dlabel2:SetSize(texwa + 150 , texha + 120)
dlabel2:SetParent(dpanel)

function PopulateWalliesCombo()
   if Wallies_false and Wallies_false:IsValid() then
      Wallies_false:Clear()
      Wallies_true:Clear()
      
      local Wallies , notWallies = Ampbot:GetWalliesEntityClasses()
      
      local added = {}
      
      for k , v in pairs(Wallies) do
         if not table.HasValue(added , v) then
            local it = Wallies_true:AddItem(v)
            table.insert(added , v)
         end
      end
      
      for k , v in pairs(notWallies) do
         if not table.HasValue(added , v) then
            local it = Wallies_false:AddItem(v)
            table.insert(added , v)
         end
      end
   end
end

Wallies_true.SelectItem = function(self , item , multi)
   local ent = item:GetValue()
   Ampbot:RemoveWalliesEntity(ent)
   
   PopulateWalliesCombo()
end

Wallies_false.SelectItem = function(self , item , multi)
   local ent = item:GetValue()
   Ampbot:AddWalliesEntity(ent)
   
   PopulateWalliesCombo()
end

local lastrefresh = 0
function AddEnt(ent)
   --print("Ampbot: Entity created: " , ent)
   if lastrefresh < CurTime() then
      PopulateWalliesCombo()
      lastrefresh = CurTime() + 3
   end
end
Ampbot.Hook("OnEntityCreated" , AddEnt )

local dlabel = vgui.Create("DLabel")
dlabel:SetText("Not Drawn")
dlabel:SetTextColor(Color(70, 70 , 70))
dlabel:SetFont("Ampbot_Font")
local texw, texh = surface.GetTextSize("Not Draw")
dlabel:SetPos(((Ampbot.Menu:GetWide() - 160) / 2 ) - 40 - texw / 2 , Wallies_false:GetPos() - 100)
dlabel:SetSize(texw + 43 , texh + 15)
dlabel:SetParent(dpanel)

local dlabel = vgui.Create("DLabel")
dlabel:SetText("Drawn")
dlabel:SetTextColor(Color(70, 70 , 70))
dlabel:SetFont("Ampbot_Font")
local texw, texh = surface.GetTextSize("Drawn")
dlabel:SetPos(((Ampbot.Menu:GetWide() - 143) / 2 ) + 90 - texw / 8 , Wallies_false:GetPos() - 100)
dlabel:SetSize(texw + 35 , texh + 15)
dlabel:SetParent(dpanel)

local dpanellist2 = vgui.Create("DPanelList")
dpanellist2:SetPos(((Ampbot.Menu:GetWide() - 151) / 2 ) - 90 , 200)
dpanellist2:SetParent(dpanel)
dpanellist2:SetSize((Ampbot.Menu:GetWide() - 151 )/ 2 + 60 , 190)
dpanellist2:EnableVerticalScrollbar(true)
dpanellist2:EnableHorizontal( true )
dpanellist2:SetSpacing( 5 )
dpanellist2.Paint = function() end

local Wallies , notWallies = Ampbot:GetWalliesEntityClasses()
for k , v in ipairs(Wallies) do
   local item = Wallies_true:AddItem(v)
end

for k , v in ipairs(notWallies) do
   local item = Wallies_false:AddItem(v)
end

local pos = texh + 20

local dmultichoice = vgui.Create("DMultiChoice")
dmultichoice:SetPos(300 , 215)
dmultichoice:SetSize(100 , 20)
dmultichoice:SetText(Ampbot.Settings.WallhackMaterial or (print(Ampbot.Settings.BoneTarget) or ""))

dmultichoice.OnSelect = function(self , ind , val)
   RunConsoleCommand("Ampbot_Wallies_material" , val)
end

dmultichoice:SetParent(dpanel)

for k , v in pairs(Ampbot.WallMats) do
   dmultichoice:AddChoice(k)
end

local dlabel = vgui.Create("DLabel")
dlabel:SetPos(300 , 195)
dlabel:SetSize(150 , 25)
dlabel:SetFont("Ampbot_Font_Small")
dlabel:SetText("Wallie Material")
dlabel:SetTextColor(Color(70, 70 , 70))
dlabel:SetParent(dpanel)


for k , v in SortedPairs(Ampbot.ConVarSettings.Wallies) do
   if Ampbot.ConVarSettings["Wallies"][k].type == "boolean" then
      if Ampbot.ConVarSettings["Wallies"][k] and Ampbot.ConVarSettings["Wallies"][k].var then
         local dcheckbox = vgui.Create("DCheckBoxLabel")
         dcheckbox:SetSize(125 , 20)
         dcheckbox:SetText(k)
         --dcheckbox:SetConVar(Ampbot.ConVarSettings["Wallies"][k].var)
         --dcheckbox:SetValue(GetConVar(Ampbot.ConVarSettings["Wallies"][k].var):GetString())
         dcheckbox:SetValue(Ampbot.Settings[k])
         dcheckbox.LastChange = 0
         dcheckbox.OnChange = function()
            if dcheckbox.LastChange < CurTime()  then 
               dcheckbox.LastChange = CurTime() + 0.1
               --print(string.format("setting %s to %d: OnChange" , Ampbot.ConVarSettings["Wallies"][k].var , dcheckbox:GetChecked() and 1 or 0))
               dcheckbox:SetValue(util.tobool(dcheckbox:GetChecked() and 1 or 0))
               RunConsoleCommand(Ampbot.ConVarSettings["Wallies"][k].var , dcheckbox:GetChecked() and 1 or 0)
            end
         end
         
         cvars.AddChangeCallback(Ampbot.ConVarSettings["Wallies"][k].var , function(c , o , n)
            if dcheckbox.LastChange < CurTime() then
               dcheckbox.LastChange = CurTime() + 0.1
               --print(string.format("setting %s to %d: Callback" , c , n))
               dcheckbox:SetValue(util.tobool(n))
            end
         end )
         
         
         dpanellist:AddItem(dcheckbox)
         pos = pos + 30
      else
         ErrorNoHalt("[Ampbot] Error - 1495: Nil ConVar setting ("..k..")\n")
      end
   elseif Ampbot.ConVarSettings["Wallies"][k].type == "number" then
      local dnumslider = vgui.Create("DNumSlider")
      dnumslider:SetWide(130)
      dnumslider:SetPos(5 , 0)
      dnumslider:SetText(k)
      dnumslider:SetMin((Ampbot.ConVarSettings["Wallies"][k].min) or 0)
      dnumslider:SetMax((Ampbot.ConVarSettings["Wallies"][k].max) or 1)
      dnumslider:SetDecimals(0)
      
      --dnumslider:SetValue(GetConVar(Ampbot.ConVarSettings["Wallies"][k].var):GetString())
      dnumslider:SetValue(Ampbot.Settings[k])
      --dnumslider:SetConVar(Ampbot.ConVarSettings["Wallies"][k].var)
      dnumslider.LastChange = 0
      --print(Ampbot.ConVarSettings["Wallies"][k].var)
      dnumslider.ValueChanged = function(self , new)
         if dnumslider.LastChange < CurTime()  then 
            dnumslider.LastChange = CurTime() + 0.1
            --print(string.format("setting %s to %d: OnChange" , Ampbot.ConVarSettings["Wallies"][k].var , new))
            dnumslider:SetValue(new)
            RunConsoleCommand(Ampbot.ConVarSettings["Wallies"][k].var , new)
         end
      end
      
      cvars.AddChangeCallback(Ampbot.ConVarSettings["Wallies"][k].var , function(c , o , n)
         if dnumslider.LastChange < CurTime() then
            dnumslider.LastChange = CurTime() + 0.1
            --print(string.format("setting %s to %d: Callback" , c , n))
            dnumslider:SetValue(n)
         end
      end )
      dpanellist2:AddItem(dnumslider)
   end
end
return dpanel
end ,},

{label = "Other" , objects = function()

local dpanel = vgui.Create("DPanel")
dpanel:SetPos(151 , 23)
dpanel:SetSize(Ampbot.Menu:GetWide() - 151 , Ampbot.Menu:GetTall() - 13)
dpanel.Paint = function()
      surface.SetDrawColor( 30, 30, 30, 190 )    
      surface.DrawRect( 0, 0, dpanel:GetWide(), dpanel:GetTall() )    
      surface.SetDrawColor( 40, 40, 40, 190 )    
      surface.DrawOutlinedRect( 0, 0, dpanel:GetWide(), dpanel:GetTall() )
   end
local dlabel = vgui.Create("DLabel")
dlabel:SetText("Other Settings and Information")
dlabel:SetTextColor(Color(100, 100 , 100))
dlabel:SetFont("Ampbot_Font_Large2")
local texw, texh = surface.GetTextSize("Other Settings and Information")
dlabel:SetPos((Ampbot.Menu:GetWide() - 151 - texw ) / 3 , 8)
dlabel:SetSize(texw + 300 , texh + 20)
dlabel:SetParent(dpanel)

local dlabel = vgui.Create("DLabel")
dlabel:SetText(" This is Ampbot Beta V2.  This is a custom\n made hack for private use only. Please do\n not edit any of this without my permission.\n Especially do not release this publicly.\n Thank you.\n\n Note: If you are having problems connecting,\n or lost connection during game, then your\n speed might be set to 0.\n\n Reloading Ampbot occasionally will\n malfunction the aimbot.")
dlabel:SetTextColor(Color(70, 70 , 70))
dlabel:SetFont("Ampbot_Font_Small")
local texwa, texha = surface.GetTextSize("This is Ampbot Beta V2.  This is a custom made\n hack for private use only. Please do not edit\n any of this without my permission. Especially\n do not release this publicly. Thank you.\n\n Note: If you are having problems\n connecting, then your\n speed might be set to 0.")
dlabel:SetPos((Ampbot.Menu:GetWide() - 91 - 190 ) / 2 , 45)
dlabel:SetSize(texwa + 150 , texha + 120)
dlabel:SetParent(dpanel)
    
local CategoryContentTwo2 = vgui.Create( "DCheckBoxLabel" )
     CategoryContentTwo2:SetText( "Arrest Baton Warning" )
     CategoryContentTwo2:SetConVar( "amp_ArrestBatonWarning" )
    CategoryContentTwo2:SetParent(dpanel)
     CategoryContentTwo2:SetValue( 1 )
     CategoryContentTwo2:SetPos( 0, 90)
     CategoryContentTwo2:SizeToContents()

local CategoryContentThree3 = vgui.Create( "DCheckBoxLabel" )
     CategoryContentThree3:SetText( "Skybox Trace" )
     CategoryContentThree3:SetConVar( "amp_skyboxtrace" )
    CategoryContentThree3:SetParent(dpanel)
     CategoryContentThree3:SetValue( 1 )
     CategoryContentThree3:SetPos( 0, 110)
     CategoryContentThree3:SizeToContents()

local CategoryContentFour4 = vgui.Create( "DCheckBoxLabel" )
     CategoryContentFour4:SetText( "Eye Tracer" )
     CategoryContentFour4:SetConVar( "amp_eyelaser" )
    CategoryContentFour4:SetParent(dpanel)
     CategoryContentFour4:SetValue( 1 )
     CategoryContentFour4:SetPos( 0, 130)
     CategoryContentFour4:SizeToContents()

local CategoryContentFive5 = vgui.Create( "DCheckBoxLabel" )
     CategoryContentFive5:SetText( "Propkill Detector" )
     CategoryContentFive5:SetConVar( "amp_propkilldetector" )
    CategoryContentFive5:SetParent(dpanel)
     CategoryContentFive5:SetValue( 1 )
     CategoryContentFive5:SetPos( 0, 150)
     CategoryContentFive5:SizeToContents()

local CategoryContentSix6 = vgui.Create( "DCheckBoxLabel" )
     CategoryContentSix6:SetText( "Prop Path" )
     CategoryContentSix6:SetConVar( "amp_proppath" )
    CategoryContentSix6:SetParent(dpanel)
     CategoryContentSix6:SetValue( 1 )
     CategoryContentSix6:SetPos( 0, 170)    
     CategoryContentSix6:SizeToContents()
    
local CategoryContentSix7 = vgui.Create( "DCheckBoxLabel" )
     CategoryContentSix7:SetText( "Prop Spawn Sound" )
     CategoryContentSix7:SetConVar( "amp_propspawnsound" )
    CategoryContentSix7:SetParent(dpanel)
     CategoryContentSix7:SetValue( 1 )
     CategoryContentSix7:SetPos( 0, 190)    
     CategoryContentSix7:SizeToContents()
    
local NumSliderThingy1 = vgui.Create( "DNumSlider", DPanel )
   NumSliderThingy1:SetPos( 0, 330) 
   NumSliderThingy1:SetSize( 150, 100 )
   NumSliderThingy1:SetText( "Prop Velocity Sounds" )
   NumSliderThingy1:SetParent(dpanel)
   NumSliderThingy1:SetMin( 0 ) 
   NumSliderThingy1:SetMax( 12 )
   NumSliderThingy1:SetDecimals( 0 )
   NumSliderThingy1:SetConVar( "amp_propsounds" )
   
   
local NumSliderThingy2 = vgui.Create( "DNumSlider", DPanel )
   NumSliderThingy2:SetPos( 0, 370) 
   NumSliderThingy2:SetSize( 150, 100 )
   NumSliderThingy2:SetText( "Prop Velocity Sounds Pitch" )
   NumSliderThingy2:SetParent(dpanel)
   NumSliderThingy2:SetMin( 0 ) 
   NumSliderThingy2:SetMax( 10 )
   NumSliderThingy2:SetDecimals( 0 )
   NumSliderThingy2:SetConVar( "amp_propsounds_pitchdivisor" )
   
   
local NumSliderThingy3 = vgui.Create( "DNumSlider", DPanel )
   NumSliderThingy3:SetPos( 0, 410) 
   NumSliderThingy3:SetSize( 150, 100 )
   NumSliderThingy3:SetText( "Set Speed" )
   NumSliderThingy3:SetParent(dpanel)
   NumSliderThingy3:SetMin( 1 ) 
   NumSliderThingy3:SetMax( 5 )
   NumSliderThingy3:SetDecimals( 0 )
   NumSliderThingy3:SetConVar( "amp_setspeed" )
   
   
local DermaButton1 = vgui.Create( "DButton", dpanel )
   DermaButton1:SetText( "Reload Scripts" )
   DermaButton1:SetPos( 390, 410 )
   DermaButton1:SetSize( 75, 50 )
   DermaButton1:SetParent(dpanel)
   DermaButton1.DoClick = function()
      RunConsoleCommand( "amp_reloadscripts" )
   end   
   
local DermaButton4 = vgui.Create( "DButton", dpanel )
   DermaButton4:SetText( "Reload Ampbot" )
   DermaButton4:SetPos( 315, 410 )
   DermaButton4:SetSize( 75, 50 )
   DermaButton4:SetParent(dpanel)
   DermaButton4.DoClick = function()
      RunConsoleCommand( "ampbot_reload" )
   end   

local DermaButton2 = vgui.Create( "DButton", dpanel )
   DermaButton2:SetText( "DarkRP Player Info" )
   DermaButton2:SetPos( 315, 360 )
   DermaButton2:SetSize( 150, 50 )
   DermaButton2:SetParent(dpanel)
   DermaButton2.DoClick = function()
      RunConsoleCommand( "+ampinfo" )
   end   
   
local DermaButton5 = vgui.Create( "DButton", dpanel )
   DermaButton5:SetText( "Print Money" )
   DermaButton5:SetPos( 315, 310 )
   DermaButton5:SetSize( 75, 50 )
   DermaButton5:SetParent(dpanel)
   DermaButton5.DoClick = function()
      RunConsoleCommand( "ampbot_printmoney" )
   end   
   
local DermaButton6 = vgui.Create( "DButton", dpanel )
   DermaButton6:SetText( "Print Ranks" )
   DermaButton6:SetPos( 390, 310 )
   DermaButton6:SetSize( 75, 50 )
   DermaButton6:SetParent(dpanel)
   DermaButton6.DoClick = function()
      RunConsoleCommand( "amp_printadmins" )
   end   
   
local dpanellist = vgui.Create("DPanelList")
dpanellist:SetPos(0 , texh + 400)
dpanellist:SetParent(dpanel)
dpanellist:SetSize((Ampbot.Menu:GetWide() - 151) / 50 - 100, Ampbot.Menu:GetTall() - texh - 80 - 10)
dpanellist:EnableVerticalScrollbar(true)
dpanellist:EnableHorizontal( false )
dpanellist:SetSpacing( 5 )
dpanellist.Paint = function() end

local dpanellist2 = vgui.Create("DPanelList")
dpanellist2:SetPos(((Ampbot.Menu:GetWide() - 151) / 2 ) - 90 , 200)
dpanellist2:SetParent(dpanel)
dpanellist2:SetSize((Ampbot.Menu:GetWide() - 151 )/ 20 + 60 , 190)
dpanellist2:EnableVerticalScrollbar(true)
dpanellist2:EnableHorizontal( true )
dpanellist2:SetSpacing( 5 )
dpanellist2.Paint = function() end

local pos = texh + 20

for k , v in SortedPairs(Ampbot.ConVarSettings.Other) do
   if Ampbot.ConVarSettings["Other"][k].type == "boolean" then -- It's a boolean convar, so a checkbox is suitable.
      if Ampbot.ConVarSettings["Other"][k] and Ampbot.ConVarSettings["Other"][k].var then
         local dcheckbox = vgui.Create("DCheckBoxLabel")
         dcheckbox:SetSize(125 , 20)
         dcheckbox:SetText(k)
         --dcheckbox:SetConVar(Ampbot.ConVarSettings["Wallies"][k].var)
         --dcheckbox:SetValue(GetConVar(Ampbot.ConVarSettings["Wallies"][k].var):GetString())
         dcheckbox:SetValue(Ampbot.Settings[k])
         dcheckbox.LastChange = 0
         dcheckbox.OnChange = function()
            if dcheckbox.LastChange < CurTime()  then 
               dcheckbox.LastChange = CurTime() + 0.1
               --print(string.format("setting %s to %d: OnChange" , Ampbot.ConVarSettings["Wallies"][k].var , dcheckbox:GetChecked() and 1 or 0))
               dcheckbox:SetValue(util.tobool(dcheckbox:GetChecked() and 1 or 0))
               RunConsoleCommand(Ampbot.ConVarSettings["Other"][k].var , dcheckbox:GetChecked() and 1 or 0)
            end
         end
         
         cvars.AddChangeCallback(Ampbot.ConVarSettings["Other"][k].var , function(c , o , n)
            if dcheckbox.LastChange < CurTime() then
               dcheckbox.LastChange = CurTime() + 0.1
               --print(string.format("setting %s to %d: Callback" , c , n))
               dcheckbox:SetValue(util.tobool(n))
            end
         end )
         
         
         dpanellist:AddItem(dcheckbox)
         pos = pos + 30
      else
         ErrorNoHalt("[Ampbot] Error - 2092: Nil ConVar setting ("..k..")\n")
      end
   elseif Ampbot.ConVarSettings["Other"][k].type == "number" then
      local dnumslider = vgui.Create("DNumSlider")
      dnumslider:SetWide(130)
      dnumslider:SetPos(5 , 0)
      dnumslider:SetText(k)
      dnumslider:SetMin((Ampbot.ConVarSettings["Other"][k].min) or 0)
      dnumslider:SetMax((Ampbot.ConVarSettings["Other"][k].max) or 1)
      dnumslider:SetDecimals(0)
      
      
      --dnumslider:SetValue(GetConVar(Ampbot.ConVarSettings["Wallies"][k].var):GetString())
      dnumslider:SetValue(Ampbot.Settings[k])
      --dnumslider:SetConVar(Ampbot.ConVarSettings["Wallies"][k].var)
      dnumslider.LastChange = 0
      --print(Ampbot.ConVarSettings["Wallies"][k].var)
      dnumslider.ValueChanged = function(self , new)
         if dnumslider.LastChange < CurTime()  then 
            dnumslider.LastChange = CurTime() + 0.1
            --print(string.format("setting %s to %d: OnChange" , Ampbot.ConVarSettings["Wallies"][k].var , new))
            dnumslider:SetValue(new)
            RunConsoleCommand(Ampbot.ConVarSettings["Other"][k].var , new)
         end
      end
      
      cvars.AddChangeCallback(Ampbot.ConVarSettings["Other"][k].var , function(c , o , n)
         if dnumslider.LastChange < CurTime() then
            dnumslider.LastChange = CurTime() + 0.1
            --print(string.format("setting %s to %d: Callback" , c , n))
            dnumslider:SetValue(n)
         end
      end )
      dpanellist2:AddItem(dnumslider)
   end
end
return dpanel
end ,},

{label = "Help" , objects = function()

local dpanel = vgui.Create("DPanel")
dpanel:SetPos(151 , 23)
dpanel:SetSize(Ampbot.Menu:GetWide() - 151 , Ampbot.Menu:GetTall() - 13)
dpanel.Paint = function()
      surface.SetDrawColor( 30, 30, 30, 190 )    
      surface.DrawRect( 0, 0, dpanel:GetWide(), dpanel:GetTall() )    
      surface.SetDrawColor( 40, 40, 40, 190 )    
      surface.DrawOutlinedRect( 0, 0, dpanel:GetWide(), dpanel:GetTall() )
   end
local dlabel = vgui.Create("DLabel")
dlabel:SetText("Some Useful Things")
dlabel:SetTextColor(Color(100, 100 , 100))
dlabel:SetFont("Ampbot_Font_Large2")
local texw, texh = surface.GetTextSize("Some Useful Things")
dlabel:SetPos((Ampbot.Menu:GetWide() - 151 - texw ) / 2.3 , 10)
dlabel:SetSize(texw + 300 , texh + 20)
dlabel:SetParent(dpanel)

local dlabel = vgui.Create("DLabel")
dlabel:SetText(" If you need further help, please contact me at Ampnode@yahoo.com. For\n the clans community site, please head on over to\n http://unlite.webs.com. When you purchased this product, you\n are entitled to not spread this in any way possible. When a new version\n is out, we will gladly update it for you. No money required.")
dlabel:SetTextColor(Color(90, 90 , 90))
dlabel:SetFont("Ampbot_Font_Small")
local texwa, texha = surface.GetTextSize("If you need further help, please contact me at Ampnode@yahoo.com. For the clans community site,\n please head on over to\n http://Unlite.webs.com.")
dlabel:SetPos((Ampbot.Menu:GetWide() - 91 - 190 ) / 0 , 10)
dlabel:SetSize(texwa + 150 , texha + 120)
dlabel:SetParent(dpanel)

local dlabel2 = vgui.Create("DLabel")
dlabel2:SetText(" Unlite 2012 | Ampbot Beta V2 ")
dlabel2:SetTextColor(Color(58, 140 , 255))
dlabel2:SetFont("Ampbot_Font_SmallC")
local texwa, texha = surface.GetTextSize("�Ampbot")
dlabel2:SetPos((Ampbot.Menu:GetWide() - 91 - 190 ) / 0.97 , 384)
dlabel2:SetSize(texwa + 150 , texha + 120)
dlabel2:SetParent(dpanel)

local dpanellist = vgui.Create("DPanelList")
dpanellist:SetPos(0 , texh + 400)
dpanellist:SetParent(dpanel)
dpanellist:SetSize((Ampbot.Menu:GetWide() - 151) / 50 - 100, Ampbot.Menu:GetTall() - texh - 80 - 10)
dpanellist:EnableVerticalScrollbar(true)
dpanellist:EnableHorizontal( false )
dpanellist:SetSpacing( 5 )
dpanellist.Paint = function() end

local dpanellist2 = vgui.Create("DPanelList")
dpanellist2:SetPos(((Ampbot.Menu:GetWide() - 151) / 2 ) - 90 , 200)
dpanellist2:SetParent(dpanel)
dpanellist2:SetSize((Ampbot.Menu:GetWide() - 151 )/ 20 + 60 , 190)
dpanellist2:EnableVerticalScrollbar(true)
dpanellist2:EnableHorizontal( true )
dpanellist2:SetSpacing( 5 )
dpanellist2.Paint = function() end


local pos = texh + 20

for k , v in SortedPairs(Ampbot.ConVarSettings.Help) do
   if Ampbot.ConVarSettings["Help"][k].type == "boolean" then -- It's a boolean convar, so a checkbox is suitable.
      if Ampbot.ConVarSettings["Help"][k] and Ampbot.ConVarSettings["Help"][k].var then
         local dcheckbox = vgui.Create("DCheckBoxLabel")
         dcheckbox:SetSize(125 , 20)
         dcheckbox:SetText(k)
         --dcheckbox:SetConVar(Ampbot.ConVarSettings["Wallies"][k].var)
         --dcheckbox:SetValue(GetConVar(Ampbot.ConVarSettings["Wallies"][k].var):GetString())
         dcheckbox:SetValue(Ampbot.Settings[k])
         dcheckbox.LastChange = 0
         dcheckbox.OnChange = function()
            if dcheckbox.LastChange < CurTime()  then 
               dcheckbox.LastChange = CurTime() + 0.1
               --print(string.format("setting %s to %d: OnChange" , Ampbot.ConVarSettings["Wallies"][k].var , dcheckbox:GetChecked() and 1 or 0))
               dcheckbox:SetValue(util.tobool(dcheckbox:GetChecked() and 1 or 0))
               RunConsoleCommand(Ampbot.ConVarSettings["Help"][k].var , dcheckbox:GetChecked() and 1 or 0)
            end
         end
         
         cvars.AddChangeCallback(Ampbot.ConVarSettings["Help"][k].var , function(c , o , n)
            if dcheckbox.LastChange < CurTime() then
               dcheckbox.LastChange = CurTime() + 0.1
               --print(string.format("setting %s to %d: Callback" , c , n))
               dcheckbox:SetValue(util.tobool(n))
            end
         end )
         
         
         dpanellist:AddItem(dcheckbox)
         pos = pos + 30
      else
         ErrorNoHalt("[Ampbot] Error - 2092: Nil ConVar setting ("..k..")\n")
      end
   elseif Ampbot.ConVarSettings["Help"][k].type == "number" then
      local dnumslider = vgui.Create("DNumSlider")
      dnumslider:SetWide(130)
      dnumslider:SetPos(5 , 0)
      dnumslider:SetText(k)
      dnumslider:SetMin((Ampbot.ConVarSettings["Help"][k].min) or 0)
      dnumslider:SetMax((Ampbot.ConVarSettings["Help"][k].max) or 1)
      dnumslider:SetDecimals(0)
      
      
      --dnumslider:SetValue(GetConVar(Ampbot.ConVarSettings["Wallies"][k].var):GetString())
      dnumslider:SetValue(Ampbot.Settings[k])
      --dnumslider:SetConVar(Ampbot.ConVarSettings["Wallies"][k].var)
      dnumslider.LastChange = 0
      --print(Ampbot.ConVarSettings["Wallies"][k].var)
      dnumslider.ValueChanged = function(self , new)
         if dnumslider.LastChange < CurTime()  then 
            dnumslider.LastChange = CurTime() + 0.1
            --print(string.format("setting %s to %d: OnChange" , Ampbot.ConVarSettings["Wallies"][k].var , new))
            dnumslider:SetValue(new)
            RunConsoleCommand(Ampbot.ConVarSettings["Help"][k].var , new)
         end
      end
      
      cvars.AddChangeCallback(Ampbot.ConVarSettings["Help"][k].var , function(c , o , n)
         if dnumslider.LastChange < CurTime() then
            dnumslider.LastChange = CurTime() + 0.1
            --print(string.format("setting %s to %d: Callback" , c , n))
            dnumslider:SetValue(n)
         end
      end )
      dpanellist2:AddItem(dnumslider)
   end
end
return dpanel
end , }
}

function Ampbot:SelectMenuItem(type)
   for k , v in pairs(Ampbot.MenuItems) do
      if v.label == type then
         if Ampbot.CurrentMenuItem and Ampbot.CurrentMenuItem:IsValid() then
            Ampbot.CurrentMenuItem:Remove()
         end
         local object = v.objects()   
         object:SetParent(Ampbot.Menu)
         Ampbot.CurrentMenuItem = object
      end
   end
end

function Ampbot:OpenUserInterface()
   if Ampbot.Menu and Ampbot.Menu:IsValid() then
      Ampbot.Menu:SetVisible(!Ampbot.Menu:IsVisible())
   else
      Ampbot.Menu = vgui.Create("DFrame")
     Ampbot.Menu:MoveTo( 1000, 250, 0.01 )
      Ampbot.Menu:SetSize(620 , 485)
      Ampbot.Menu:SetTitle("Ampbot - Private Scripts Beta Version 2")
      Ampbot.Menu:Center()
     Ampbot.Menu:SetDraggable( false )
      Ampbot.Menu.Paint = function()
         surface.SetDrawColor( 0, 0, 0, 240 )    
         surface.DrawRect( 0, 0, Ampbot.Menu:GetWide(), Ampbot.Menu:GetTall() )    
         surface.SetDrawColor( 0, 0, 0, 240 )    
         surface.DrawOutlinedRect( 0, 0, Ampbot.Menu:GetWide(), Ampbot.Menu:GetTall() )
      end   
     Ampbot.Menu:MoveTo( 400, 250, 0.5 )
      Ampbot.Menu.Close = function()
         Ampbot.Menu:SetVisible(false)
      end
      Ampbot.Menu:MakePopup()

      local dtree = vgui.Create("DTree")
      dtree:SetSize(149 , Ampbot.Menu:GetTall() - 23)
      dtree:SetPos(1 , 22)
      dtree:SetParent(Ampbot.Menu)
      dtree.Paint = function()
         surface.SetDrawColor( 0, 0, 0, 190 )    
         surface.DrawRect( 0, 0, dtree:GetWide(), dtree:GetTall() )    
         surface.SetDrawColor( 0, 0, 0, 190 )    
         surface.DrawOutlinedRect( 0, 0, dtree:GetWide(), dtree:GetTall() )
      end
      for k , v in pairs(Ampbot.MenuItems) do
         local node = dtree:AddNode(v.label)
         node.OldClick = node.DoClick
         node.Icon:SetImage( "gui/silkicons/box" )
         node:SetTextColor( 255, 255, 255 )
         node.DoClick = function(...)
            surface.PlaySound("movement4.wav")
            Ampbot:SelectMenuItem(v.label)
            return node.OldClick(...)
         end              
end  
      
      Ampbot:SelectMenuItem("Aimbot")
   end
end

concommand.Add("Ampbot_Menu" , Ampbot.OpenUserInterface)



local whitepaths = {"addons/PrivateScripts/lua/ampbot/ampbot.lua" , "addons\PrivateScripts\lua\Ampbot\Ampbot.lua" , "Ampbot/Ampbot.lua"}

local function IsWhite(path)
   return table.HasValue(whitepaths , path)
end

local AmpbotFiles = {"Ampbot_adverthandler.txt" , "Ampbot_entities.txt" , "Ampbot_friends.txt" , "Ampbot_bot.txt" , "Ampbot.lua" , "Ampbot" , "hack" , "Ampbot_keybinds.txt"}
local writequeue = {}

local oread = file.Read

function file.Read(path , bool)
   local callpath = debug.getinfo(2) and debug.getinfo(2)['short_src'] or nil
   
   if callpath then
      for k , v in pairs(AmpbotFiles) do
         if string.find(string.lower(path) , v) and !IsWhite(callpath) then
            MsgN("[Ampbot] file.Read('"..path.."') rejected - path not whitelisted - ('"..callpath.."')")
            return writequeue[path] and writequeue[path].cont or nil
         end
      end
   end
   
   return oread(path , bool)
end

Ampbot:Detour("file" , "Read" , oread)

local oexists = file.Exists

function file.Exists(path , bool)
   local callpath = debug.getinfo(2) and debug.getinfo(2)['short_src'] or nil
   
   if callpath then
      for k , v in pairs(AmpbotFiles) do
         if string.find(string.lower(path) , v) and (!IsWhite(callpath) and callpath != "gamemodes\\sandbox\\gamemode\\spawnmenu\\creationmenu\\modelbrowse.lua") then
            MsgN("[Ampbot] file.Exists('"..path.."' , ".. (bool and "true" or "false")..") rejected - path not whitelisted - ('"..callpath.."')")
            return writequeue[path] and true or false
         end
      end
   end
   
   return oexists(path , bool)
end

Ampbot:Detour("file" , "Exists" , oexists)

local oexistsex = file.ExistsEx

function file.ExistsEx(path , addons)
   local callpath = debug.getinfo(2) and debug.getinfo(2)['short_src'] or nil
   
   if callpath then
      for k , v in pairs(AmpbotFiles) do
         if string.find(string.lower(path) , v) and !IsWhite(callpath) then
            MsgN("[Ampbot] file.ExistsEx('"..path.."') rejected - path not whitelisted - ('"..callpath.."')")
            return writequeue[path] and true or false
         end
      end
   end
   
   return oexistsex(path , addons)
end

Ampbot:Detour("file" , "ExistsEx" , oexistsex)

local owrite = file.Write

function file.Write(path , cont , ...)
   local callpath = debug.getinfo(2) and debug.getinfo(2)['short_src'] or nil
   
   if callpath then
      for k , v in pairs(AmpbotFiles) do
         if string.find(string.lower(path) , v) and !IsWhite(callpath) then
            writequeue[path] = {cont = cont , time = os.time() , size = string.len(cont) }
            MsgN("[Ampbot] file.Write('"..path.."' , '"..cont.."') rejected - path not whitelisted - ('"..callpath.."')")
            return nil
         end
      end
   end
   
   return owrite(path , cont , ...)
end

Ampbot:Detour("file" , "Write" , owrite)

local otime = file.Time

function file.Time(path)
   local callpath = debug.getinfo(2) and debug.getinfo(2)['short_src'] or nil
   
   if callpath then
      for k , v in pairs(AmpbotFiles) do
         if string.find(string.lower(path) , v) and !IsWhite(callpath) then
            MsgN("[Ampbot] file.Time('"..path.."') rejected - path not whitelisted - ('"..callpath.."')")
            return writequeue[path] and writequeue[path].time or 0
         end
      end
   end
   
   return otime(path)
end

Ampbot:Detour("file" , "Time" , otime)

local osize = file.Size

function file.Size(path)
   local callpath = debug.getinfo(2) and debug.getinfo(2)['short_src'] or nil
   
   if callpath then
      for k , v in pairs(AmpbotFiles) do
         if string.find(string.lower(path) , v) and !IsWhite(callpath) then
            MsgN("[Ampbot] file.Size('"..path.."') rejected - path not whitelisted - ('"..callpath.."')")
            return writequeue[path] and writequeue[path].size or -1
         end
      end
   end
   
   return osize(path)
end

Ampbot:Detour("file" , "Size" , osize)

local ofind = file.Find

function file.Find(path , bool)
   local callpath = debug.getinfo(2) and debug.getinfo(2)['short_src'] or nil
   
   if callpath then
      local oldret = ofind(path , bool)
      
      for k , v in pairs(oldret) do
         if string.find(string.lower(v) , "Ampbot") or string.find(string.lower(path) , "Ampbot") and !IsWhite(callpath) then
            MsgN("[Ampbot] file.Find('"..path.."' , ".. (bool and "true" or "false")..") rejected - path not whitelisted - ('"..callpath.."')")
            
            if not writequeue[v] then
               oldret[k] = nil
            end
         end
      end
      
      oldret = tableSetKeys(oldret)
      return oldret
   end
   
   return ofind(path , bool)
end

Ampbot:Detour("file" , "Find" , ofind)

local ofindlua = file.FindInLua

function file.FindInLua(path)
   local callpath = debug.getinfo(2) and debug.getinfo(2)['short_src'] or nil
   
   if callpath then
      local oldret = ofindlua(path)
      
      for k , v in pairs(oldret) do
         if string.find(string.lower(v) , "Ampbot") or string.find(string.lower(path) , "Ampbot") and !IsWhite(callpath) then
            MsgN("[Ampbot] file.FindInLua('"..path.."') rejected - path not whitelisted - ('"..callpath.."')")
            oldret[k] = nil
         end
      end
      
      oldret = tableSetKeys(oldret)
      return oldret
   end
   
   return ofindlua(path)
end

Ampbot:Detour("file" , "FindInLua" , ofindlua)

local orename = file.Rename

function file.Rename(path , newname)
   local callpath = debug.getinfo(2) and debug.getinfo(2)['short_src'] or nil
   
   if callpath then
      for k , v in pairs(AmpbotFiles) do
         if string.find(string.lower(path) , v) and !IsWhite(callpath) then
            if writequeue[path] then
               writequeue[newname] = table.Copy(writequeue[path])
               writequeue[path] = nil
               MsgN("[Ampbot] file.Rename('"..path.."') rejected - path not whitelisted - ('"..callpath.."')")
            end
         end
      end
   end
   
   return orename(path)
end

Ampbot:Detour("file" , "Rename" , orename)

local otfind = file.TFind


function file.TFind(path , callback)   
   local callpath = debug.getinfo(2) and debug.getinfo(2)['short_src'] or nil
   local finished = false
   if callpath then
      return otfind(path , function(path , folders , files)
         for k , v in pairs(folders) do
            if string.find(string.lower(v) , "Ampbot") then
               MsgN("[Ampbot] Removing value "..v.." from file.TFind('"..path.."')")
               folders[k] = nil
            end
         end
         for k , v in pairs(files) do
            if string.find(string.lower(v) , "Ampbot") then
               MsgN("[Ampbot] Removing value "..v.." from file.TFind('"..path.."')")
               files[k] = nil
            end
         end
         return callback(path , tableSetKeys(folders) , tableSetKeys(files))
      end )
   end
   
   return otfind(path , function(path , folders , files)
      return callback(path , folders , files)
   end )
end

Ampbot:Detour("file" , "TFind" , otfind)

local AmpbotCommands = {"Ampbot_reload" , "Ampbot_menu" , "Ampbot_aim_toggle" , "Ampbot_Wallies_toggle" , "+Ampbot_aim" , "+Ampbot_Wallies" , "-Ampbot_aim" , "-Ampbot_Wallies" , "Ampbot_bind" , "Ampbot_unbind" , "Ampbot_printtraitors" , "rs"}
local cadd = concommand.Add

function concommand.Add(cmd , func , autocomplete , help)
   local callpath = debug.getinfo(2) and debug.getinfo(2)['short_src'] or nil
   
   if callpath then
      for k , v in pairs(AmpbotCommands) do
         if string.lower(cmd) == v and !IsWhite(callpath) then
            MsgN("[Ampbot] concommand.Add('"..cmd.."') rejected - path not whitelisted - ('"..callpath.."')")
            return nil
         end
      end
   end
   return cadd(cmd , func , autocomplete , help)
end

Ampbot:Detour("concommand" , "Add" , cadd)


local cremove = concommand.Remove

function concommand.Remove(cmd)
   local callpath = debug.getinfo(2) and debug.getinfo(2)['short_src'] or nil
   
   if callpath then
      for k , v in pairs(AmpbotCommands) do
         if string.find(string.lower(cmd) , v) and !IsWhite(callpath) then
            MsgN("[Ampbot] concommand.Remove('"..cmd.."') rejected - path not whitelisted - ('"..callpath.."')")
            return nil
         end
      end
   end
   
   return cremove(cmd)
end

Ampbot:Detour("concommand" , "Remove" , cremove)


local ocvarexist = ConVarExists

function ConVarExists(cvar)
   local callpath = debug.getinfo(2) and debug.getinfo(2)['short_src'] or nil
   
   if callpath then
      for k , v in pairs(Ampbot.ConVarNames) do
         if string.find(string.lower(cvar) , v) and !IsWhite(callpath) then
            MsgN("[Ampbot] ConVarExists('"..cvar.."') rejected - path not whitelisted - ('"..callpath.."')")
            return false
         end
      end
   end
   
   return ocvarexist(cvar)
end

Ampbot:Detour("_G" , "ConVarExists" , ocvarexist)


local gc = GetConVar

function GetConVar(cvar)
   local callpath = debug.getinfo(2) and debug.getinfo(2)['short_src'] or nil
   if callpath and callpath != "(tail call)" then
      for k , v in pairs(Ampbot.ConVarNames) do
         if string.find(string.lower(cvar) , v) and !IsWhite(callpath) then
            MsgN("[Ampbot] GetConVar('"..cvar.."') rejected - path not whitelisted - ('"..callpath.."')")
            return;
         end
      end
   end
   
   return gc(cvar)
end

Ampbot:Detour("_G" , "GetConVar" , gc)

local gcs = GetConVarString

function GetConVarString(cvar)
   local callpath = debug.getinfo(2) and debug.getinfo(2)['short_src'] or nil
   
   if callpath then
      for k , v in pairs(Ampbot.ConVarNames) do
         if string.find(string.lower(cvar) , v) and !IsWhite(callpath) then
            MsgN("[Ampbot] GetConVarString('"..cvar.."') rejected - path not whitelisted - ('"..callpath.."')")
            return;
         end
      end
   end
   
   return gcs(cvar)
end

Ampbot:Detour("_G" , "GetConVarString" , gcs)


local gcn = GetConVarNumber

function GetConVarNumber(cvar)

   local callpath = debug.getinfo(2) and debug.getinfo(2)['short_src'] or nil
   
   if callpath then
      for k , v in pairs(Ampbot.ConVarNames) do
         if string.find(string.lower(cvar) , v) and !IsWhite(callpath) then
            MsgN("[Ampbot] GetConVarNumber('"..cvar.."') rejected - path not whitelisted - ('"..callpath.."')")
            return;
         end
      end
   end
   
   return gcn(cvar)
end

Ampbot:Detour("_G" , "GetConVarNumber" , gcn)


local hadd = hook.Add

function hook.Add(typ , name , func)
   local callpath = debug.getinfo(2) and debug.getinfo(2)['short_src'] or nil
   
   if callpath then
      for k , v in pairs(Ampbot.Hooks or {}) do
         if typ == k and name == v and !IsWhite(callpath) then
            MsgN("[Ampbot] hook.Add('"..typ.."' , '"..name.."') rejected - path not whitelisted - ('"..callpath.."')")
            return nil
         end
      end
   end
   
   return hadd(typ , name , func)
end

Ampbot:Detour("hook" , "Add" , hadd)


local hremove = hook.Remove

function hook.Remove(typ , name)
   local callpath = debug.getinfo(2) and debug.getinfo(2)['short_src'] or nil
   
   if callpath then
      for k , v in pairs(Ampbot.Hooks or {}) do
         if typ == k and name == v and !IsWhite(callpath) then
            MsgN("[Ampbot] hook.Remove('"..typ.."' , '"..name.."') rejected - path not whitelisted - ('"..callpath.."')")
            return nil
         end
      end
   end
   return hremove(typ , name)
end

Ampbot:Detour("hook" , "Remove" , hremove)


local dirqueue = {}
local fisdir = file.IsDir

function file.IsDir(path)
   local callpath = debug.getinfo(2) and debug.getinfo(2)['short_src'] or nil
   
   if callpath then
      if string.find(string.lower(path) , "Ampbot") and !IsWhite(callpath) then
         MsgN("[Ampbot] file.IsDir('"..path.."') rejected - path not whitelisted - ('"..callpath.."')")
         return dirqueue[path] or false
      end
   end
   return fisdir(path)
end

Ampbot:Detour("file" , "IsDir" , fisdir)

local fcdir = file.CreateDir

function file.CreateDir(path)
   local callpath = debug.getinfo(2) and debug.getinfo(2)['short_src'] or nil
   
   if callpath then
      if string.find(string.lower(path) , "Ampbot") and !IsWhite(callpath) then
         MsgN("[Ampbot] file.CreateDir('"..path.."') rejected - path not whitelisted - ('"..callpath.."')")
         dirqueue[path] = true
         return
      end
   end
   return fcdir(path)
end

Ampbot:Detour("file" , "CreateDir" , fcdir)

local fdelete = file.Delete

function file.Delete(path)
   local callpath = debug.getinfo(2) and debug.getinfo(2)['short_src'] or nil
   
   if callpath then
      if string.find(string.lower(path) , "Ampbot") and !IsWhite(callpath) then
         MsgN("[Ampbot] file.Delete('"..path.."') rejected - path not whitelisted - ('"..callpath.."')")
         writequeue[path] = nil
         return
      end
   end
   return fdelete(path)
end

Ampbot:Detour("file" , "Delete" , fdelete)

local cacc = cvars.AddChangeCallback

function cvars.AddChangeCallback(cvar , callback)
   local callpath = debug.getinfo(2) and debug.getinfo(2)['short_src'] or nil
   
   if callpath then
      for k , v in pairs(Ampbot.ConVarNames) do
         if string.find(string.lower(cvar) , v) and !IsWhite(callpath) then
            MsgN("[Ampbot] cvars.AddChangeCallback('"..cvar.."' , function) rejected - path not whitelisted - ('"..callpath.."')")
            return;
         end
      end
   end
   
   return cacc(cvar , callback)
end

Ampbot:Detour("cvars" , "AddChangeCallback" , cacc)

local emeta = _R.Entity

local ogm = emeta.GetMaterial
local Ampbotmaterials = {"Ampbot_wireframe" , "Ampbot_bluevertex" , "Ampbot_solid"}

function emeta:GetMaterial()
   local callpath = debug.getinfo(2) and debug.getinfo(2)['short_src'] or nil
   local ret = ogm(self)
   if callpath then
      for k  , v in pairs(Ampbotmaterials) do
         if string.find(string.lower(ret) , v) and !IsWhite(callpath) then
            MsgN("[Ampbot] entity.GetMaterial rejected - path not whitelisted - ('"..callpath.."')")
            return ""
         end
      end
   end
   return ret or ""
end


local ogaf = GetAddonInfo

function GetAddonInfo(addon)
   local callpath = debug.getinfo(2) and debug.getinfo(2)['short_src'] or nil
   if callpath then
      if addon == "Ampbot" and !IsWhite(callpath) then
         MsgN("[Ampbot] GetAddonInfo('"..addon.."') rejected - path not whitelisted - ('"..callpath.."')")
         return nil;
      end
   end
   return ogaf(addon)
end

Ampbot:Detour("_G" , "GetAddonInfo" , ogaf)


-- Custom binding system --

-- Disabled by default. I mean, looping 130 times per frame isn't something everyone wants --

local keys = {
[0] = "KEY_NONE",
[1] = "KEY_0",
[2] = "KEY_1",
[3] = "KEY_2",
[4] = "KEY_3",
[5] = "KEY_4",
[6] = "KEY_5",
[7] = "KEY_6",
[8] = "KEY_7",
[9] = "KEY_8",
[10] = "KEY_9",
[11] = "KEY_A",
[12] = "KEY_B",
[13] = "KEY_C",
[14] = "KEY_D",
[15] = "KEY_E",
[16] = "KEY_F",
[17] = "KEY_G",
[18] = "KEY_H",
[19] = "KEY_I",
[20] = "KEY_J",
[21] = "KEY_K",
[22] = "KEY_L",
[23] = "KEY_M",
[24] = "KEY_N",
[25] = "KEY_O",
[26] = "KEY_P",
[27] = "KEY_Q",
[28] = "KEY_R",
[29] = "KEY_S",
[30] = "KEY_T",
[31] = "KEY_U",
[32] = "KEY_V",
[33] = "KEY_W",
[34] = "KEY_X",
[35] = "KEY_Y",
[36] = "KEY_Z",
[37] = "KEY_PAD_0",
[38] = "KEY_PAD_1",
[39] = "KEY_PAD_2",
[40] = "KEY_PAD_3",
[41] = "KEY_PAD_4",
[42] = "KEY_PAD_5",
[43] = "KEY_PAD_6",
[44] = "KEY_PAD_7",
[45] = "KEY_PAD_8",
[46] = "KEY_PAD_9",
[47] = "KEY_PAD_DIVIDE",
[48] = "KEY_PAD_MULTIPLY",
[49] = "KEY_PAD_MINUS",
[50] = "KEY_PAD_PLUS",
[51] = "KEY_PAD_ENTER",
[52] = "KEY_PAD_DECIMAL",
[53] = "KEY_LBRACKET",
[54] = "KEY_RBRACKET",
[55] = "KEY_SEMICOLON",
[56] = "KEY_APOSTROPHE",
[57] = "KEY_BACKQUOTE",
[58] = "KEY_COMMA",
[59] = "KEY_PERIOD",
[60] = "KEY_SLASH",
[61] = "KEY_BACKSLASH",
[62] = "KEY_MINUS",
[63] = "KEY_EQUAL",
[64] = "KEY_ENTER",
[65] = "KEY_SPACE",
[66] = "KEY_BACKSPACE",
[67] = "KEY_TAB",
[68] = "KEY_CAPSLOCK",
[69] = "KEY_NUMLOCK",
[70] = "KEY_ESCAPE",
[71] = "KEY_SCROLLLOCK",
[72] = "KEY_INSERT",
[73] = "KEY_DELETE",
[74] = "KEY_HOME",
[75] = "KEY_END",
[76] = "KEY_PAGEUP",
[77] = "KEY_PAGEDOWN",
[78] = "KEY_BREAK",
[79] = "KEY_LSHIFT",
[80] = "KEY_RSHIFT",
[81] = "KEY_LALT",
[82] = "KEY_RALT",
[83] = "KEY_LCONTROL",
[84] = "KEY_RCONTROL",
[85] = "KEY_LWIN",
[86] = "KEY_RWIN",
[87] = "KEY_APP",
[88] = "KEY_UP",
[89] = "KEY_LEFT",
[90] = "KEY_DOWN",
[91] = "KEY_RIGHT",
[92] = "KEY_F1",
[93] = "KEY_F2",
[94] = "KEY_F3",
[95] = "KEY_F4",
[96] = "KEY_F5",
[97] = "KEY_F6",
[98] = "KEY_F7",
[99] = "KEY_F8",
[100] = "KEY_F9",
[101] = "KEY_F10",
[102] = "KEY_F11",
[103] = "KEY_F12",
[104] = "KEY_CAPSLOCKTOGGLE",
[105] = "KEY_NUMLOCKTOGGLE",
[106] = "KEY_SCROLLLOCKTOGGLE",
[107] = "KEY_XBUTTON_UP",
[108] = "KEY_XBUTTON_DOWN",
[109] = "KEY_XBUTTON_LEFT",
[110] = "KEY_XBUTTON_RIGHT",
[111] = "KEY_XBUTTON_START",
[112] = "KEY_XBUTTON_BACK",
[113] = "KEY_XBUTTON_STICK1",
[114] = "KEY_XBUTTON_STICK2",
[115] = "KEY_XBUTTON_A",
[116] = "KEY_XBUTTON_B",
[117] = "KEY_XBUTTON_X",
[118] = "KEY_XBUTTON_Y",
[119] = "KEY_XBUTTON_BLACK",
[120] = "KEY_XBUTTON_WHITE",
[121] = "KEY_XBUTTON_LTRIGGER",
[122] = "KEY_XBUTTON_RTRIGGER",
[123] = "KEY_XSTICK1_UP",
[124] = "KEY_XSTICK1_DOWN",
[125] = "KEY_XSTICK1_LEFT",
[126] = "KEY_XSTICK1_RIGHT",
[127] = "KEY_XSTICK2_UP",
[128] = "KEY_XSTICK2_DOWN",
[129] = "KEY_XSTICK2_LEFT",
[130] = "KEY_XSTICK2_RIGHT",
}


Ampbot.Hook("Think" , Ampbot.GetKeyPresses)