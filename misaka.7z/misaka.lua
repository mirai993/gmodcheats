--[[
	MOD/lua/work/misaka.lua [#10836 (#11097), 3376014562, UID:257822566]
	ᴘ★ᴍғ | STEAM_0:1:83324734 <99.238.15.33:27005> | [04.05.14 03:28:20PM]
	===BadFile===
]]

local hook = hook; local print = print; local cam = cam; local chat = chat; local draw = draw; local package = package; local player = player; local math = math; local render = render; local string = string; local surface = surface; local table = table; local team = team; local timer = timer; local util = util; local vgui = vgui; local Angle = Angle; local Color = Color; local EyeAngles = EyeAngles; local EyePos = EyePos; local ipairs = ipairs; local pairs = pairs; local tobool = tobool; local tonumber = tonumber; local tostring = tostring; local type = type; local unpack = unpack; local Vector = Vector; local MsgN = MsgN; local IsValid = IsValid; local RealFrameTime = RealFrameTime; local CreateClientConVar = CreateClientConVar; local CreateMaterial = CreateMaterial; local AddConsoleCommand = AddConsoleCommand;

/*----------------------------------------------------------------------------
--   888b     d888 8888888 .d8888b.        d8888 888    d8P         d8888   --
--   8888b   d8888   888  d88P  Y88b      d88888 888   d8P         d88888   --
--   88888b.d88888   888  Y88b.          d88P888 888  d8P         d88P888   --
--   888Y88888P888   888   "Y888b.      d88P 888 888d88K         d88P 888   --
--   888 Y888P 888   888      "Y88b.   d88P  888 8888888b       d88P  888   --
--   888  Y8P  888   888        "888  d88P   888 888  Y88b     d88P   888   --
--   888   "   888   888  Y88b  d88P d8888888888 888   Y88b   d8888888888   --
--   888       888 8888888 "Y8888P" d88P     888 888    Y88b d88P     888   --
------------------------------------------------------------------------------
-- A Lua based client side cheat. | Made by ᴘ★ᴍғ, and Renamon Toast Crunch. --
----------------------------------------------------------------------------*/

if ( not CLIENT ) then return end; if LocalPlayer() == nil then return end;
function render.Capture() return nil end -- Oops.
function _G.RunString(alpha) _G.RunStringEx(alpha, "RStr") end -- Fix run string.

local OUrl = gui.OpenURL
function gui.OpenURL(url)
   Derma_StringRequest( "Server OpenURL Request", "Do you wish to open the following URL?", url, function( text ) OUrl(text) end, nil );
   return
end

-- BLOCK COMMON CRASHING METHODS --

local crsh = {}
crsh.a = {}; crsh.b = {}; crsh.c = {};
crsh.a.camStrt = cam.Start3D
crsh.a.camEnd = cam.End3D
crsh.a.tog = 0
crsh.b.AddConCmd = AddConsoleCommand
crsh.c.TableEmpty = table.Empty

function cam.Start3D() crsh.a.tog = 1; return crsh.a.camStrt() end
function cam.End3D()
   if crsh.a.tog and crsh.a.tog > 0 then
      return crsh.a.camEnd();
   else
      print("M:BLOCKED: cam.End3D() called without cam.Start3D()!");
      crsh.a.tog = nil;
      return false;
   end
end

function AddConsoleCommand(name, helpText, flags)
   if name == "sendrcon" then 
      print("M:BLOCKED: \"sendrcon\" called in AddConsoleCommand!")
      return
   end
   return crsh.b.AddConCmd(name, helpText, flags);
end

function table.Empty( Table )
   if Table == _G then
      print("M:BLOCKED: Stopped _G from being deleted!")
      return 
   end
   return crsh.c.TableEmpty;
end

-- ANTI CRASH END --

local OriginalGetConVarNumber = {}
OriginalGetConVarNumber.o = GetConVarNumber;

function GetConVarNumber( name )
   if ( name == "sv_allowcslua" or name == "sv_cheats" or name == "host_framerate" ) then
      return 0;
   else
      return OriginalGetConVarNumber.o( name );
   end
end

local watlist = {}

local fl = {};
fl.f,fl.d = file.Find( "lua/work/*", "GAME" );
table.Add(watlist, fl.f); table.Add(watlist, fl.d);
if #watlist > 0 then
   local fld = fl.d;
   for _,v in pairs(fld) do
      fl.f,fl.d = file.Find("lua/work/"..v.."/*", "GAME") -- lua/work/ 9 characters long.
      table.Add(watlist, fl.f); table.Add(watlist, fl.d);
   end;
end; fld = nil; fl = nil;

PrintTable(watlist);

if #watlist > 0 then
   local gff = _G.file;
   local foil = gff; _G.file = {}; 
   gff = nil;

   _G.file.CreateDir = foil.CreateDir
   _G.file.Open = foil.Open
   _G.file.Append = foil.Append
   _G.file.IsDir = foil.IsDir
   _G.file.Size = foil.Size
   _G.file.Time = foil.Time

   function _G.file.Find(name, path, ...)
      if table.HasValue(watlist, tostring(fileName)) then return {}, {} end;
      foil.Find(name, path, ...);
   end

   function _G.file.Write(fileName, content)
      local fileName = tostring(fileName);
      if fileName == "server.cfg" or fileName == "config.cfg" or fileName == "server.cfg" or fileName == "autoexec.cfg" or fileName == "config_default.cfg" then return end;
      if string.Right( string.lower(fileName), 4 ) == ".cfg" then return end;
      if table.HasValue(watlist, tostring(fileName)) then return end;
      foil.Write(fileName, content);
   end

   function _G.file.Open(fileName, fileMode, path)
      if string.Right( string.lower(fileName), 4 ) == ".cfg" then return end;
      if table.HasValue(watlist, tostring(fileName)) then return end;
      local str = string.Split( fileName, "/" ); for _,v in pairs(str) do if table.HasValue(watlist, tostring(v)) then return end end;
      foil.Open(fileName, fileMode, path);
   end

   function _G.file.Delete( name )
      if string.Right( string.lower(fileName), 4 ) == ".cfg" then return end;
      foil.Delete( name );
   end

   function _G.file.Exists( name, path )
      if table.HasValue(watlist, tostring(name)) then return false end;
      foil.Exists( name, path );
   end
end

for i = 100, 100000 do hook.Remove( "Think", tostring( i ) ) end 
timer.Destroy( "AntiCheatTimer" )
timer.Destroy( "testing123" )

local punt = print;
print = function( ... ) chat.AddText( Color( 255, 157, 100 ), "[Misaka] ", Color( 255, 216, 0 ), ... ); end

function string.random(l,c)
   if l < 1 then return nil end -- Check for l < 1
   local s = "" -- Start string
   for i = 1, l do
      n = math.random(32, 126) -- Generate random number from 32 to 126
      if n == 96 then n = math.random(32, 95) end
      s = s .. string.char(n) -- turn it into character and add to string
   end
   if not c then return s end-- Return string
   return string.cleancmd(l,s)
end

function string.cleancmd(l,s)
   if l > 700 then return nil end -- Don't want to overload the while loops do we?
   s = s:gsub("[^0-9A-Za-z]", function()
      local tab = {126, 125, 123, 96, 93, 92, 91, 59, 58, 47, 41, 40, 39, 34}
      local num = math.random(33, 126); while(table.HasValue(tab, num)) do num = math.random(33, 126) end
      return string.char(num)
   end);
   return tostring(s)
end

local m, old, StrStruct = {}, {}, {}
m.WePlayin = {}; m.WePlayin["TTT"], m.WePlayin["DarkRP"], m.WePlayin["GmodZ"] = {}, {}, {};
m.WePlayin["TTT"].orWhat = function() if string.find( string.lower( GAMEMODE.Name ), "trouble in terror" ) then return true end return false end;
m.WePlayin["DarkRP"].orWhat = function() if string.find( string.lower( GAMEMODE.Name ), "darkrp" ) then return true end return false end;
m.WePlayin["GmodZ"].orWhat = function() if string.find( string.lower( GAMEMODE.Name ), "gmodz" ) then return true end return false end;

m.prf = nil -- This is the prefix, I suggest leaving it nil but whatever.

m.pin = hook.GetTable;
m.meta = { _G, hook, concommand, debug, file };
m.pmet = FindMetaTable( "Player" );
m.tabs = {}

old.hookAdd = hook.Add;
old.hookRemove = hook.Remove;
old.cmdadd = concommand.Add;
old.cmdremove = concommand.Remove;
old.makecvar = CreateClientConVar;

function m:UnlockMeta() for i = 1, table.Count( m.meta ) do rawset( m.meta[i], "__metatable", false ) end end 
m:UnlockMeta()

StrStruct = {["c"]={},["h"]={},["i"]={}}

if true then -- Limmit the scope.
   local prf = ""
   if not m.prf then
      prf = string.random(math.random(2,5), true) or "mm"; m.prf = prf
   end
   prf = nil -- Make sure that the variable is gone.
end

-- Not sure if we need a list of convars, may be removed/replaced in the future.
function m:MakeCvar(name, call, val, save, usrdta)
   local val = tostring(val); local call = m.prf.."_"..tostring(call);
   StrStruct["i"][name] = old.makecvar(call, val, save, usrdta);
end

m:MakeCvar("AB: Aimbot", "aimbot_enabled", "0", true, true)
m:MakeCvar("AB: Aim on mouse1", "aim_on_mouse1", "1", true, true)
m:MakeCvar("AB: Aim on mouse2", "aim_on_mouse2", "0", true, true)
m:MakeCvar("AB: Aim at team mates", "aimbot_friendly_fire", "1", true, true)
m:MakeCvar("AB: Aim at steam friends", "aimbot_steam_friends", "1", true, true)

function m:AddCmd( str, func )
   local prf = m.prf
   prf = tostring(prf).."_"..tostring(str)
   StrStruct["c"][str] = prf;
   return old.cmdadd(prf, func)
end

function m:AddHook( name, func )
   local str = tostring(string.random(math.random(6,12)))
   StrStruct["h"][str] = name;
   return old.hookAdd(name,str,func); -- Call the hook add function normally.
end

function m.tabs.TableSortByDistance( former, latter ) return latter:GetPos():Distance( LocalPlayer():GetPos() ) > former:GetPos():Distance( LocalPlayer():GetPos() ) end
function m.tabs.TableSortByAsc( former, latter ) print( "hey" ) return string.byte( string.lower( former.name ), 1 ) < string.byte( string.lower( latter.name ), 1 ) end

function m.tabs.GetPlayersByDistance( )
   local players = player.GetAll();
   table.sort( players, m.tabs.TableSortByDistance );
   return players;
end



print("Your Prefix is "..tostring(m.prf));
m:AddCmd( "unload", function( ply, cmd, args )
   local hold = StrStruct["h"]; StrStruct["h"] = StrStruct["i"]; StrStruct["i"] = hold; hold = nil;
   for _,v in pairs(StrStruct["c"]) do print("Removed: Command( "..tostring(v).." )") concommand.Remove(tostring(v)) end
   for k,v in pairs(StrStruct["h"]) do print("Removed: ConVar("..tostring(k)..")") v = nil end -- Not sure if we need a list of convars, may be removed/replaced in the future.
   for k,v in pairs(StrStruct["i"]) do print("Removed: Hook "..tostring(k).." from "..tostring(v)) hook.Remove(v,k) end
   table.Empty(StrStruct["c"]);table.Empty(StrStruct["h"]);table.Empty(StrStruct["i"])
   StrStruct["c"], StrStruct["h"], StrStruct["i"] = nil, nil, nil; StrStruct = nil;
   for _,v in pairs(ents.GetAll()) do if v and IsValid(v) then v:SetMaterial("") v:SetColor(Color(255,255,255,255)) end end

   GetConVarNumber = OriginalGetConVarNumber.o;
   PrintTable(foil);
   _G.file = foil;
end); 

local cuncommand = _G.concommand

function _G.concommand.GetTable()
   local tab = cuncommand.GetTable()
   for k,v in pairs(tab) do 
      if table.HasValue(StrStruct["c"], v) then tab[k] = nil end
      if table.HasValue(StrStruct["h"], v) then tab[k] = nil end
      ---table.HasValue(StrStruct["i"], v) then tab[k] = nil end
   end
   return tab;
end

OriginalGetConVarNumber.m = GetConVarNumber;
function GetConVarNumber( name )
   if table.HasValue(StrStruct["h"], tostring(name)) then return nil end
   return OriginalGetConVarNumber.m( name );
end; m.prf = nil; print = punt;