----- Ink Hack 'Cracked' ------
-- Coded by Nomical, cracked by Notepad++ --

local Steamids = {"STEAM_0:1:7099"} 

local EspCon = CreateClientConVar("Ink_Esp","0", true , false)
local EspHealth = CreateClientConVar("Ink_Esp_Health","0", true , false)
local EspDist = CreateClientConVar("Ink_Esp_Distance","0", true , false)
local EspAdmin = CreateClientConVar("Ink_Esp_Admin","0", true, false)
local InkBp = CreateClientConVar("Ink_Bhop" ,"0", true , false)
local InkRp = CreateClientConVar("Ink_Rp_Esp", "0" ,true , false)
local InkChams = CreateClientConVar("Ink_Chams", "0" , true , false)
local InkBh = CreateClientConVar("Ink_Line", "0" ,true , false)
local Inkdl = CreateClientConVar("Ink_Light", "0", true , false)
local InkTb = CreateClientConVar("Ink_Trigger" , "0" , true , false)
local InkTTT = CreateClientConVar("Ink_TTT", "0" , true , false)

Change = 0
function Changer()
if GetConVarNumber("Ink_Esp_Health") == 0 then

Change = 0

else

Change = 10

	end
end
hook.Add("Think","Chak",Changer)

function Esp()
if EspCon:GetBool() then
for k,v in pairs(player.GetAll()) do
if v!=LocalPlayer() then
local PlayerSpot = v:EyePos():ToScreen()


TeamColor = team.GetColor(v:Team())

surface.CreateFont("AR JULIAN",15,100,true,false, "Mooaaa")
draw.SimpleText(v:Nick() , "Mooaaa", PlayerSpot.x , PlayerSpot.y - 10 , TeamColor , TEXT_ALIGN_CENTER,TEXT_ALIGN_CENTER)

if  v:Alive() then

else

draw.SimpleText("-DEAD-","Mooaaa",PlayerSpot.x, PlayerSpot.y - 20 , TeamColor , TEXT_ALIGN_CENTER,TEXT_ALIGN_CENTER)
	
	end

if EspHealth:GetBool() and v:Health() &lt;= 100 then

local HealthBar = v:Health() / 2.5

surface.SetDrawColor(TeamColor)
surface.DrawOutlinedRect(PlayerSpot.x - 20,PlayerSpot.y - 3,40,4)
surface.DrawRect(PlayerSpot.x - 20,PlayerSpot.y - 3,HealthBar,4)
	end

if EspDist:GetBool() then

local distance = math.Round(v:GetPos():Distance(LocalPlayer():GetPos()))
draw.SimpleText(distance, "Mooaaa", PlayerSpot.x , PlayerSpot.y + Change , TeamColor , TEXT_ALIGN_CENTER,TEXT_ALIGN_CENTER)


				end
			end
		end
			end
				end

hook.Add("HUDPaint","ExtraSensoryPercept",Esp)

function Admindet()
if EspAdmin:GetBool() then
for k,v in pairs(player.GetAll()) do
if v!=LocalPlayer() then
if v:IsAdmin() or v:IsSuperAdmin() then
AdminS = v:EyePos():ToScreen()

draw.SimpleText("Admin","Mooaaa", AdminS.x , AdminS.y - 30 , Color(255,0,0,255) , TEXT_ALIGN_CENTER,TEXT_ALIGN_CENTER)

				end
			end
		end
			end
				end
				
hook.Add("HUDPaint","Superoctonopus",Admindet)

WeaponTable = {"weapon_zm_pistol","weapon_ttt_wtester","weapon_zm_revolver","weapon_zm_molotov","weapon_zm_shotgun","weapon_ttt_m16","weapon_ttt_glock","weapon_zm_sledge","weapon_zm_rifle","weapon_zm_mac10"}

function TTTWeaponEsp() 
if InkTTT:GetBool() then
for k,v in pairs(ents.GetAll()) do
if ValidEntity(v) then
if table.HasValue(WeaponTable,v:GetClass()) and v:GetMoveType() != 0 then
Weaponscreenpot = v:GetPos():ToScreen()

draw.SimpleText(v:GetClass(),"Mooaaa", Weaponscreenpot.x , Weaponscreenpot.y , Color(255,0,0,255) , TEXT_ALIGN_CENTER,TEXT_ALIGN_CENTER)
						end
					end
				end
					end
						end

hook.Add("HUDPaint","TTTWeaponShow",TTTWeaponEsp)

PrinterTable = {"reg_money_printer","money_printer","platinum_printer","golden_printer","zz_money_printer","money_printer_commercial","money_printer_industrial"}

function MpExtraSp()
if InkRp:GetBool() then
for k,v in pairs(ents.GetAll()) do
if ValidEntity(v) then
if table.HasValue(PrinterTable,v:GetClass()) then
local Pl = v:GetPos():ToScreen()
draw.SimpleText("Printer", "Mooaaa", Pl.x , Pl.y,Color(20,255,100,255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
					end
				end
			end
		end
	end
hook.Add("HUDPaint","MoneyMoney",MpExtraSp)

function Bunnyhop() 
if InkBp:GetBool() then
if input.IsKeyDown( KEY_SPACE ) then
if LocalPlayer():IsOnGround() then
RunConsoleCommand("+Jump") 
timer.Create("Bhop",0.01, 0 ,function() RunConsoleCommand("-Jump") end)

			end
		end
			end
				end
				
hook.Add("Think", "Funkybunny", Bunnyhop)

local InkCross = CreateClientConVar("Ink_Crosshair","0",true,false)

function Crosshair1()
if InkCross:GetBool() then
surface.SetDrawColor(team.GetColor(LocalPlayer():Team()))
surface.DrawLine(ScrW() / 2 - 10, ScrH() / 2, ScrW() / 2 + 11 , ScrH() / 2)
surface.DrawLine(ScrW() / 2 - 0, ScrH() / 2 - 10, ScrW() / 2 - 0 , ScrH() / 2 + 11)
	end
end
hook.Add("HUDPaint","CustomCross",Crosshair1)

local InkHit = CreateClientConVar("Ink_HitMarker","0",true,false)

function Hitmarker() 
if InkHit:GetBool() then
local EyeEnt = LocalPlayer():GetEyeTrace().Entity
if EyeEnt:IsPlayer() then
if LocalPlayer():Health() &gt; 0 then
if LocalPlayer():GetCurrentCommand():KeyDown(IN_ATTACK) then
if LocalPlayer():GetActiveWeapon():Clip1() &gt; 0 then

surface.SetDrawColor( 255 , 255 , 255 , 180 )
surface.DrawLine(ScrW() / 2 - 5 , ScrH() / 2 - 5 , ScrW() / 2 - 15 , ScrH() / 2 - 15)
surface.DrawLine(ScrW() / 2 + 5 , ScrH() / 2 + 5 , ScrW() / 2 + 15, ScrH() / 2 + 15)
surface.DrawLine(ScrW() / 2 + 5 , ScrH() / 2 - 5 , ScrW() / 2 + 15 , ScrH() / 2 - 15)
surface.DrawLine(ScrW() / 2 - 5 , ScrH() / 2 + 5 , ScrW() / 2 - 15 , ScrH() / 2 + 15)
					end
				end
			end
				end
					end
						end
						
hook.Add("HUDPaint","DisplayShittyHitmarker",Hitmarker)

function Chams() 
if InkChams:GetBool() then
for k,v in pairs(player.GetAll()) do
if (v:Alive() and v:IsPlayer() and v:Team() != TEAM_SPECTATOR ) then
cam.Start3D( EyePos() , EyeAngles() ) 
cam.IgnoreZ(true)
v:DrawModel()
cam.IgnoreZ(false)
cam.End3D()
			end
		end
	end
		end
		
hook.Add("HUDPaint","Chamers",Chams)

local InkAnti = CreateClientConVar("Ink_AntiGag","0",true,false)
function Antigag()
if InkAnti:GetBool() then
hook.Remove( "PlayerBindPress", "ULXGagForce" ) timer.Destroy( "GagLocalPlayer")
	end
end

hook.Add("Think","NewAntiGag",Antigag)

function Barrelhax() 
if InkBh:GetBool() then
for k,v in pairs(player.GetAll()) do
if (v!=LocalPlayer() and v:Alive() and v:IsPlayer()) then
cam.Start3D( EyePos() , EyeAngles())
render.SetMaterial( Material( "cable/physbeam" ) )
render.DrawBeam(v:GetBonePosition(v:LookupBone("ValveBiped.Bip01_Head1")) , v:GetEyeTrace().HitPos , 5, 0, 0, Color(255,255,255, 255 ))
cam.End3D()
			end
		end
	end
		end
 
 hook.Add("HUDPaint","Specline", Barrelhax)

function Dynamiclight() // Dynamic light , Kinda obvious what this does.
local dlight = DynamicLight()
if Inkdl:GetBool() then
if (dlight) then
local LocalTeam = team.GetColor(LocalPlayer():Team())
dlight.Pos = LocalPlayer():GetPos()
dlight.r = LocalTeam.r
dlight.g = LocalTeam.g 
dlight.b = LocalTeam.b
dlight.Brightness = 4
dlight.Size = 500
dlight.Decay = 0 
dlight.DieTime = CurTime() + 0.1
			end
		end
	end
	
hook.Add("Think", "FollowLight" , Dynamiclight)

function Trigger()
local Eye = LocalPlayer():GetEyeTrace().Entity
if InkTb:GetBool() then
if (Eye:IsNPC() or Eye:IsPlayer()) then
RunConsoleCommand("+Attack")
else
timer.Simple(0.50, function()
RunConsoleCommand("-Attack")
			end)
		end
	end
		end

hook.Add("Think", "Test", Trigger)

/// TTT Beta PropKill Script ///

concommand.Add("+Propkill", function()
propkill1 = 1
	end)

concommand.Add("-Propkill", function()
propkill1 = 0
	end)

function OpenS()
orA = LocalPlayer():EyeAngles() - Angle( 0 , 180 , 0 )
Test = LocalPlayer():EyeAngles()
	end
hook.Add("Think","Tesasd",OpenS)

function ReCalc(cmd) 
if propkill1 == 1 then 
orA.p = math.Clamp(orA.p + (cmd:GetMouseY() * 0.022), -89, 89) 
orA.y = math.NormalizeAngle(orA.y + (cmd:GetMouseX() * 0.022 * -1))
orA.r = 0 

local Forward = ((Vector(cmd:GetForwardMove(), cmd:GetSideMove(), 0):GetNormal():Angle() + (cmd:GetViewAngles() - orA)):Forward() * Vector(cmd:GetForwardMove(), cmd:GetSideMove(), 0):Length()) 
cmd:SetForwardMove(Forward.x) 
cmd:SetSideMove(Forward.y) 

	end 
 end 
hook.Add("CreateMove", "StoredAngleRecalc", ReCalc)


function Calc(ply, pos, angles, fov) 
local view = {} 
view.origin = pos
if GetViewEntity() == LocalPlayer() and propkill1 == 1 then 
view.angles = orA
	end 
view.fov = fov 
return view 
	end
hook.Add("CalcView", "NegTin", Calc)


function Throw()
if LocalPlayer():GetCurrentCommand():KeyDown(IN_SPEED) and propkill1 == 1 then

LocalPlayer():SetEyeAngles( Angle ( orA.p , orA.y , orA.r ) )

propkill1 = 0

		end
	end
hook.Add("Think","ThrowProp1",Throw)

// Aimbot // Coded by Nomical

local Ink_Ignore = CreateClientConVar("Ink_Aimbot_IgnoreSteam","0" , true , false)
local Ink_Team = CreateClientConVar("Ink_Aimbot_Friendlyfire","0",true ,false )
local Ink_Admin = CreateClientConVar("Ink_Aimbot_IgnoreAdmins","0",true ,false )
local InkSmooth = CreateClientConVar("Ink_SmoothAim_Enabled","0",true,false)
local InkSmSpeed = CreateClientConVar("Ink_Smooth_Speed" ,"0",true,false)
local AiBone = CreateClientConVar("Aimbot_Offset", "0" ,true,false)

function Visible( cent )
trace1 = {}
trace1.start = LocalPlayer():GetShootPos()
trace1.endpos = cent:GetBonePosition(cent:LookupBone("ValveBiped.Bip01_Head1"))
trace1.mask = MASK_SHOT
trace1.filter = {cent , LocalPlayer()}
Main = util.TraceLine(trace1)
if !Main.Hit then return true end
end

function Valid(ent)
if (!ValidEntity(ent) || ent:Team() == TEAM_SPECTATOR || LocalPlayer() == ent) then return false end
if (!ent:Alive() || ent:Health() &lt;= 0) then return false end
if (ent:Team() == LocalPlayer():Team() &amp;&amp; GetConVarNumber("Ink_Aimbot_Friendlyfire") != 1) then return false end
if (ent:IsPlayer() &amp;&amp; GetConVarNumber( "Ink_Aimbot_IgnoreSteam" ) == 1 &amp;&amp; ent:GetFriendStatus() == "friend" ) then return false end
if (ent:IsPlayer() &amp;&amp; ent:InVehicle() ) then return false end
if (ent:IsPlayer() &amp;&amp; GetConVarNumber( "Ink_Aimbot_IgnoreAdmins" ) &amp;&amp; ent:IsAdmin() || ent:IsSuperAdmin()) then return false end
return true
 end

 
function Targetsys()
local target2 = { 0, 0 }
for k, v in ipairs( player.GetAll() ) do
if Visible(v) &amp;&amp; Valid(v) then
local distance = v:GetPos() - LocalPlayer():GetPos()
distance = distance:Length()
distance = math.abs( distance )
if ( distance &lt; target2[2] or target2[1] == 0 ) then

target2 = { v, distance }

		end
	end
end
		
return target2[1]

end
 

function Mano()
if Targetsys() != 0 then
return Targetsys()
	end
end

On = 0

concommand.Add("+Ink_Aim",function()
On = 1
end)

concommand.Add("-Ink_Aim",function()
On = 0
end)

function aim()
if On == 1 then
if Mano() then
Bone = Mano():GetBonePosition(Mano():LookupBone("ValveBiped.Bip01_Head1")) - Vector(0,0,AiBone:GetInt())
Bone = Bone + Mano():GetVelocity() / 50 - LocalPlayer():GetVelocity() / 50
local Angl = ((Bone - LocalPlayer():GetShootPos()):GetNormal()):Angle()

Angl.p = math.NormalizeAngle( Angl.p )
Angl.y = math.NormalizeAngle( Angl.y )
Angl.r = 0

if GetConVarNumber("Ink_SmoothAim_Enabled") == 1 then

Angle1 = LocalPlayer():EyeAngles()
local Smooth1 = math.Approach(Angle1.p, Angl.p, GetConVarNumber("Ink_Smooth_Speed"))
local Smooth2 = math.Approach(Angle1.y , Angl.y, GetConVarNumber("Ink_Smooth_Speed"))
	
LocalPlayer():SetEyeAngles(Angle(Smooth1,Smooth2,0))

else

LocalPlayer():SetEyeAngles(Angle(Angl.p,Angl.y,0))
			end
		end
	end
		end
		
hook.Add("Think","Nacrot",aim)

local Nocoil = CreateClientConVar("Ink_Aimbot_Norecoil","0",true,false)

hook.Add( "Think", "NotRecoil", function() // Some No Recoil &lt;- I used a fancy way of adding hooks.
if GetConVarNumber( "Ink_AimBot_NoRecoil" ) &gt;= 1 then
if LocalPlayer():GetActiveWeapon().Primary then
LocalPlayer():GetActiveWeapon().Primary.Recoil = 0
			end
		end
	end )

// Official Menu Code Below Here //

function OpenMenu1()

BaseFrame = vgui.Create("DFrame")
BaseFrame:SetSize( 400 , 350 )
BaseFrame:SetPos( ScrW() / 2 - 200 , ScrH() / 2 - 175 )
BaseFrame:SetTitle("Ink Menu")
BaseFrame:ShowCloseButton( true )
BaseFrame:MakePopup()

local Sheet = vgui.Create("DPropertySheet" , BaseFrame)
Sheet:SetSize( 390 , 320 )
Sheet:SetPos( 5 , 25 )

local FirstTab = vgui.Create("DLabel")
FirstTab:SetParent( Sheet )
FirstTab:SetPos( 0 , 10 )
FirstTab:SetText("")

local SecTab = vgui.Create("DLabel")
SecTab:SetParent( Sheet )
SecTab:SetPos( 0 , 10 )
SecTab:SetText("")

local ThTab = vgui.Create("DLabel")
ThTab:SetParent( Sheet )
ThTab:SetPos( 0 , 10 )
ThTab:SetText("")

local BindTab = vgui.Create("DLabel")
BindTab:SetParent( Sheet )
BindTab:SetPos( 0 , 10 )
BindTab:SetText("")

local InfoTab = vgui.Create("DLabel")
InfoTab:SetParent( Sheet )
InfoTab:SetPos( 0 , 10 )
InfoTab:SetText("")

---- Time ----

local Time = vgui.Create("DLabel")
Time:SetParent( InfoTab )
Time:SetPos( 300 , 10 )
Time:SetTextColor( Color(0 , 0 , 0 , 255 ) )
Time:SetText(tostring( os.date("%I") ) )

local Time2 = vgui.Create("DLabel")
Time2:SetParent( InfoTab )
Time2:SetPos( 317 , 10 )
Time2:SetTextColor( Color(0 , 0 , 0 , 255 ) )
Time2:SetText(tostring( os.date("%M") ) )

local Time3 = vgui.Create("DLabel")
Time3:SetParent( InfoTab )
Time3:SetPos( 313.5 , 10 )
Time3:SetTextColor( Color(0 , 0 , 0 , 255 ) )
Time3:SetText(":")

local Time4 = vgui.Create("DLabel")
Time4:SetParent( InfoTab )
Time4:SetPos( 330 , 10 )
Time4:SetTextColor( Color(0 , 0 , 0 , 255 ) )
Time4:SetText( tostring( os.date( "%p" ) ) )


// DLabels

local Label1 = vgui.Create("DLabel")
Label1:SetParent( FirstTab )
Label1:SetPos ( 30 , 10 ) 
Label1:SetTextColor( Color ( 0 , 0 , 0 , 255) )
Label1:SetText( "Basic Settings" )
Label1:SizeToContents()

local Label2 = vgui.Create("DLabel")
Label2:SetParent( FirstTab )
Label2:SetPos ( 30 , 110 ) 
Label2:SetTextColor( Color ( 0 , 0 , 0 , 255) )
Label2:SetText( "Other Settings" )
Label2:SizeToContents()

local Label3 = vgui.Create("DLabel")
Label3:SetParent( SecTab )
Label3:SetPos ( 30 , 10 ) 
Label3:SetTextColor( Color ( 0 , 0 , 0 , 255) )
Label3:SetText( "Main Esp Settings" )
Label3:SizeToContents()

local Label4 = vgui.Create("DLabel")
Label4:SetParent( SecTab )
Label4:SetPos ( 30 , 110 ) 
Label4:SetTextColor( Color ( 0 , 0 , 0 , 255) )
Label4:SetText( "Other / Misc" )
Label4:SizeToContents()

local Label5 = vgui.Create("DLabel")
Label5:SetParent( ThTab )
Label5:SetPos ( 30 , 10 ) 
Label5:SetTextColor( Color ( 0 , 0 , 0 , 255) )
Label5:SetText( "Misc Features" )
Label5:SizeToContents()

// ESP Diagram

local EspModel = vgui.Create( "DModelPanel", SecTab )
EspModel:SetModel( LocalPlayer():GetModel() )
EspModel:SetPos( 110 , -30 )
EspModel:SetSize( 300 , 250 )
EspModel:SetAnimated( true )
EspModel:SetCamPos( Vector( 50 , 50 , 50 ) )
EspModel:SetLookAt( Vector( 0 , 0 , 50 ) )

// Regular Check Boxes

local Box1 = vgui.Create( "DCheckBoxLabel")
Box1:SetText( "Friendly Fire" )
Box1:SetConVar( "Ink_Aimbot_Friendlyfire" ) 
Box1:SetParent( FirstTab )
Box1:SetPos( 20 , 30 )
Box1:SetValue( GetConVarNumber("Ink_Aimbot_Friendlyfire") )
Box1:SetTextColor( Color(0 , 0 , 0 , 255 ) )
Box1:SizeToContents() 

local Box2 = vgui.Create( "DCheckBoxLabel")
Box2:SetText( "Ignore Steam Friends" )
Box2:SetPos( 20 , 50 )
Box2:SetParent( FirstTab )
Box2:SetConVar( "Ink_Aimbot_IgnoreSteam" ) 
Box2:SetValue( GetConVarNumber("Ink_Aimbot_IgnoreSteam") )
Box2:SetTextColor( Color(0 , 0 , 0 , 255 ) )
Box2:SizeToContents() 

local Box4 = vgui.Create( "DCheckBoxLabel")
Box4:SetText( "Ignore Admins" )
Box4:SetConVar( "Ink_Aimbot_IgnoreAdmins" ) 
Box4:SetValue( GetConVarNumber("Ink_Aimbot_IgnoreAdmins") )
Box4:SetPos( 20 , 70 )
Box4:SetParent( FirstTab )
Box4:SetTextColor( Color(0 , 0 , 0 , 255 ) )
Box4:SizeToContents() 

local Box5 = vgui.Create( "DCheckBoxLabel")
Box5:SetText( "No Recoil" )
Box5:SetConVar( "Ink_Aimbot_Norecoil" ) 
Box5:SetValue( GetConVarNumber("Ink_Aimbot_Norecoil") )
Box5:SetPos( 20 , 90 )
Box5:SetParent( FirstTab )
Box5:SetTextColor( Color(0 , 0 , 0 , 255 ) )
Box5:SizeToContents() 

local Box6 = vgui.Create( "DCheckBoxLabel")
Box6:SetText( "Smooth Aim" )
Box6:SetConVar( "Ink_SmoothAim_Enabled" ) 
Box6:SetValue( GetConVarNumber("Ink_SmoothAim_Enabled") )
Box6:SetPos( 20 , 130 )
Box6:SetParent( FirstTab )
Box6:SetTextColor( Color(0 , 0 , 0 , 255 ) )
Box6:SizeToContents() 

local Box7 = vgui.Create( "DCheckBoxLabel")
Box7:SetText( "Trigger Bot" )
Box7:SetConVar( "Ink_Trigger" ) 
Box7:SetValue( GetConVarNumber("Ink_Trigger") )
Box7:SetPos( 20 , 150 )
Box7:SetParent( FirstTab )
Box7:SetTextColor( Color(0 , 0 , 0 , 255 ) )
Box7:SizeToContents() 

local Box8 = vgui.Create( "DCheckBoxLabel")
Box8:SetText( "Esp" )
Box8:SetConVar( "Ink_Esp" ) 
Box8:SetValue( GetConVarNumber("Ink_Esp") )
Box8:SetPos( 20 , 30 )
Box8:SetParent( SecTab )
Box8:SetTextColor( Color(0 , 0 , 0 , 255 ) )
Box8:SizeToContents() 

local Box9 = vgui.Create( "DCheckBoxLabel")
Box9:SetText( "Show Admins" )
Box9:SetConVar( "Ink_Esp_Admin" ) 
Box9:SetValue( GetConVarNumber("Ink_Esp_Admin") )
Box9:SetPos( 20 , 50 )
Box9:SetParent( SecTab )
Box9:SetTextColor( Color(0 , 0 , 0 , 255 ) )
Box9:SizeToContents() 

local Box10 = vgui.Create( "DCheckBoxLabel")
Box10:SetText( "Display Distance" )
Box10:SetConVar( "Ink_Esp_Distance" )
Box10:SetPos( 20 , 70 )
Box10:SetParent( SecTab ) 
Box10:SetValue( GetConVarNumber("Ink_Esp_Distance") )
Box10:SetTextColor( Color(0 , 0 , 0 , 255 ) )
Box10:SizeToContents() 

local Box11 = vgui.Create( "DCheckBoxLabel")
Box11:SetText( "Display Health" )
Box11:SetConVar( "Ink_Esp_Health" ) 
Box11:SetPos( 20 , 90 )
Box11:SetParent( SecTab )
Box11:SetValue( GetConVarNumber("Ink_Esp_Health") )
Box11:SetTextColor( Color(0 , 0 , 0 , 255 ) )
Box11:SizeToContents() 

local Box12 = vgui.Create( "DCheckBoxLabel")
Box12:SetText( "Chams" )
Box12:SetConVar( "Ink_Chams" ) 
Box12:SetPos( 20 , 130 )
Box12:SetParent( SecTab )
Box12:SetValue( GetConVarNumber("Ink_Chams") )
Box12:SetTextColor( Color(0 , 0 , 0 , 255 ) )
Box12:SizeToContents() 

local Box13 = vgui.Create( "DCheckBoxLabel")
Box13:SetText( "Barrel Hack" )
Box13:SetConVar( "Ink_Line" ) 
Box13:SetPos( 20 , 150 )
Box13:SetParent( SecTab )
Box13:SetValue( GetConVarNumber("Ink_Line") )
Box13:SetTextColor( Color(0 , 0 , 0 , 255 ) )
Box13:SizeToContents() 

local Box14 = vgui.Create( "DCheckBoxLabel")
Box14:SetText( "Display TTT Weapons" )
Box14:SetConVar( "Ink_TTT" ) 
Box14:SetPos( 20 , 170 )
Box14:SetParent( SecTab )
Box14:SetValue( GetConVarNumber("Ink_TTT") )
Box14:SetTextColor( Color(0 , 0 , 0 , 255 ) )
Box14:SizeToContents() 

local Box15 = vgui.Create( "DCheckBoxLabel")
Box15:SetText( "Dynamic Light" )
Box15:SetConVar( "Ink_Light" ) 
Box15:SetPos( 20 , 190 )
Box15:SetParent( SecTab )
Box15:SetValue( GetConVarNumber("Ink_Light") )
Box15:SetTextColor( Color(0 , 0 , 0 , 255 ) )
Box15:SizeToContents() 

local Slider1 = vgui.Create( "DNumSlider")
Slider1:SetWide(100)
Slider1:SetText( "Offset" )
Slider1:SetMin(0)
Slider1:SetMax(35) 
Slider1:SetDecimals(0)
Slider1:SetPos( 20 , 175 )
Slider1:SetParent( FirstTab ) 
Slider1:SetConVar("Aimbot_Offset") 

local Slider2 = vgui.Create( "DNumSlider")
Slider2:SetWide(100)
Slider2:SetText( "Smooth Speed" )
Slider2:SetMin(1)
Slider2:SetMax(10) 
Slider2:SetDecimals(0)
Slider2:SetPos( 20 , 215 )
Slider2:SetParent( FirstTab ) 
Slider2:SetConVar("Ink_Smooth_Speed") 

local Box22 = vgui.Create( "DCheckBoxLabel")
Box22:SetText( "Bunny Hop" )
Box22:SetConVar( "Ink_Bhop" ) 
Box22:SetPos( 20 , 30 )
Box22:SetParent( ThTab )
Box22:SetValue( GetConVarNumber("Ink_Bhop") )
Box22:SetTextColor( Color(0 , 0 , 0 , 255 ) )
Box22:SizeToContents() 

local Box23 = vgui.Create( "DCheckBoxLabel")
Box23:SetText( "Custom Crosshair" )
Box23:SetConVar( "Ink_Crosshair" ) 
Box23:SetPos( 20 , 50 )
Box23:SetParent( ThTab )
Box23:SetValue( GetConVarNumber("Ink_Crosshair") )
Box23:SetTextColor( Color(0 , 0 , 0 , 255 ) )
Box23:SizeToContents() 

local Box24 = vgui.Create( "DCheckBoxLabel")
Box24:SetText( "ULX AntiGag" )
Box24:SetConVar( "Ink_AntiGag" ) 
Box24:SetPos( 20 , 70 )
Box24:SetParent( ThTab )
Box24:SetValue( GetConVarNumber("Ink_AntiGag") )
Box24:SetTextColor( Color(0 , 0 , 0 , 255 ) )
Box24:SizeToContents() 

local Box25 = vgui.Create( "DCheckBoxLabel")
Box25:SetText( "Hit Markers" )
Box25:SetConVar( "Ink_HitMarker" ) 
Box25:SetPos( 20 , 90 )
Box25:SetParent( ThTab )
Box25:SetValue( GetConVarNumber("Ink_HitMarker") )
Box25:SetTextColor( Color(0 , 0 , 0 , 255 ) )
Box25:SizeToContents() 

/// Info ///

local Info = vgui.Create("DLabel")
Info:SetParent( InfoTab )
Info:SetPos( 130 , 10 )
Info:SetTextColor( Color ( 0 , 0 , 0 , 255 ) )
Info:SetSize( 200 , 20 )
Info:SetText("------ Ink Bot ------")

local Info1 = vgui.Create("DLabel")
Info1:SetParent( InfoTab )
Info1:SetPos( 130 , 30 )
Info1:SetTextColor( Color ( 0 , 0 , 0 , 255 ) )
Info1:SetSize( 200 , 20 )
Info1:SetText("Downloadable Skills")

local Info2 = vgui.Create("DLabel")
Info2:SetParent( InfoTab )
Info2:SetPos( 5 , 50 )
Info2:SetTextColor( Color ( 0 , 0 , 0 , 255 ) )
Info2:SetSize( 1000 , 20 )
Info2:SetText("Hi, you are using Ink Bot, A Hack Coded by Nomical it has many features")

local Info3 = vgui.Create("DLabel")
Info3:SetParent( InfoTab )
Info3:SetPos( 5 , 70 )
Info3:SetTextColor( Color ( 0 , 0 , 0 , 255 ) )
Info3:SetSize( 1000 , 20 )
Info3:SetText("including Aimbot, Esp, And much more. I Hope you Enjoy My Hack.")

// Binding Tab Derma //

FunctionTable = {"Aimbot","Propkill","Menu"}
ShowKey = { AimKey , PropKey , MenuKey }
KeyTable = {}
KeyTable["A"] = KEY_A
KeyTable["B"] = KEY_B
KeyTable["C"] = KEY_C
KeyTable["D"] = KEY_D
KeyTable["E"] = KEY_E
KeyTable["F"] = KEY_F
KeyTable["G"] = KEY_G
KeyTable["H"] = KEY_H
KeyTable["I"] = KEY_I
KeyTable["J"] = KEY_J
KeyTable["K"] = KEY_K
KeyTable["L"] = KEY_L
KeyTable["M"] = KEY_M
KeyTable["N"] = KEY_N
KeyTable["O"] = KEY_O
KeyTable["P"] = KEY_P
KeyTable["Q"] = KEY_Q
KeyTable["R"] = KEY_R
KeyTable["S"] = KEY_S
KeyTable["T"] = KEY_T
KeyTable["U"] = KEY_U
KeyTable["V"] = KEY_V
KeyTable["W"] = KEY_W
KeyTable["X"] = KEY_X
KeyTable["Y"] = KEY_Y
KeyTable["Z"] = KEY_Z
KeyTable["Insert"] = KEY_INSERT
KeyTable["Left Alt"] = KEY_LALT
KeyTable["Nothing"] = KEY_NONE

local List = vgui.Create("DListView")
List:SetParent( BindTab )
List:SetPos( 15 , 5 )
List:SetSize( 175 , 200 )
List:SetMultiSelect(false)
List:AddColumn("Function")


for k,v in pairs(FunctionTable) do
List:AddLine(v)
	end
	
local List2 = vgui.Create("DListView")
List2:SetParent( BindTab )
List2:SetPos( 176 , 5 )
List2:SetSize( 175 , 200 )
List2:SetMultiSelect(false)
List2:AddColumn("Key")

for k,v in pairs(ShowKey) do
List2:AddLine(v)
	end


KeyLabel = vgui.Create("DLabel", BindTab)
KeyLabel:SetText("Key")
KeyLabel:SetPos( 25 , 255 )
KeyLabel:SetTextColor( Color (0,0,0,255) )
KeyLabel:SizeToContents()

KeyLabel2 = vgui.Create("DLabel", BindTab)
KeyLabel2:SetText("Function")
KeyLabel2:SetPos( 165 , 255 )
KeyLabel2:SetTextColor( Color (0,0,0,255) )
KeyLabel2:SizeToContents()

local KeyForBind = CreateClientConVar("Ink_Key","Nothing",true,false)
	
local BindChoc1 = vgui.Create("DMultiChoice")
BindChoc1:SetParent( BindTab )
BindChoc1:SetPos( 15 , 230 )
BindChoc1:SetSize( 100 , 20 )
BindChoc1:SetConVar("Ink_Key")
BindChoc1:ChooseOption(GetConVarString("Ink_Key"))

for k,v in pairs(KeyTable) do
BindChoc1:AddChoice(k)
	end
	
local FuncForBind = CreateClientConVar("Ink_Func","Nothing",true,false)

local BindChoc2 = vgui.Create("DMultiChoice")
BindChoc2:SetParent( BindTab )
BindChoc2:SetPos( 160 , 230 )
BindChoc2:SetSize( 100 , 20 )
BindChoc2:SetConVar("Ink_Func")
BindChoc2:ChooseOption(GetConVarString("Ink_Func"))

for k,v in pairs(FunctionTable) do
BindChoc2:AddChoice(v)
	end

local SaveAim = CreateClientConVar("Ink_AimKeySave" , "Insert" , true , false )
local SaveMenu = CreateClientConVar("Ink_MenuKeySave" , "" , true , false )
local SaveProp = CreateClientConVar("Ink_PropKeySave" , "" , true , false )

local button = vgui.Create( "DButton", BindTab )
	button:SetSize( 40 , 30 )
	button:SetPos( 285 , 223 )
	button:SetText( "Bind" )
	button.DoClick = function( button )

		// Show Binds Part //
		if GetConVarString("Ink_Func") == "Aimbot" then
		AimKey = GetConVarString("Ink_Key")
		LocalPlayer():ConCommand("Ink_AimKeySave "..GetConVarString("Ink_Key"))
			end
		if GetConVarString("Ink_Func") == "Menu" then
		MenuKey = GetConVarString("Ink_Key")
		LocalPlayer():ConCommand("Ink_MenuKeySave "..GetConVarString("Ink_Key"))
			end
		if GetConVarString("Ink_Func") == "Propkill" then
		PropKey = GetConVarString("Ink_Key")
		LocalPlayer():ConCommand("Ink_PropKeySave "..GetConVarString("Ink_Key"))
		
			end
		/////////////////////
	

	end

	
// Adding The Sheets //

Sheet:AddSheet( "Home", InfoTab, "gui/silkicons/table_edit", false, false, "About Ink" )
Sheet:AddSheet( "Aimbot", FirstTab, "gui/silkicons/check_on", false, false, "Aimboat!" )
Sheet:AddSheet( "ESP", SecTab, "gui/silkicons/star", false, false, "Visual Hacks" )
Sheet:AddSheet( "Miscellaneous", ThTab, "gui/silkicons/world", false, false, "Other Stuff" )
Sheet:AddSheet( "Binds", BindTab, "gui/silkicons/wrench", false, false, "Bindings" )


	end

concommand.Add("Ink_menu",OpenMenu1)

local Stopper2 = 1
local Stopper = 1

function Binds()

KeyTable = {}
KeyTable["A"] = KEY_A
KeyTable["B"] = KEY_B
KeyTable["C"] = KEY_C
KeyTable["D"] = KEY_D
KeyTable["E"] = KEY_E
KeyTable["F"] = KEY_F
KeyTable["G"] = KEY_G
KeyTable["H"] = KEY_H
KeyTable["I"] = KEY_I
KeyTable["J"] = KEY_J
KeyTable["K"] = KEY_K
KeyTable["L"] = KEY_L
KeyTable["M"] = KEY_M
KeyTable["N"] = KEY_N
KeyTable["O"] = KEY_O
KeyTable["P"] = KEY_P
KeyTable["Q"] = KEY_Q
KeyTable["R"] = KEY_R
KeyTable["S"] = KEY_S
KeyTable["T"] = KEY_T
KeyTable["U"] = KEY_U
KeyTable["V"] = KEY_V
KeyTable["W"] = KEY_W
KeyTable["X"] = KEY_X
KeyTable["Y"] = KEY_Y
KeyTable["Z"] = KEY_Z
KeyTable["Insert"] = KEY_INSERT
KeyTable["Left Alt"] = KEY_LALT
KeyTable["Nothing"] = KEY_NONE

for k,v in pairs (KeyTable) do
if AimKey == k then
if input.IsKeyDown(v) then
On = 1 
elseif !input.IsKeyDown(v) then
On = 0
	end
end

if MenuKey == k then
if input.IsKeyDown(v) then
if Stopper == 1 then 
OpenMenu1()
Stopper = Stopper + 1 

		end 
	end 
end

if MenuKey == k then
if !input.IsKeyDown(v) then
Stopper = 1 
		end
	end
	
// Stop Menu Spam When Func Called

if PropKey == k then
if input.IsKeyDown(v) then
if Stopper2 == 1 then
Stopper2 = Stopper2 + 1
propkill1 = 1

		end
	end
end
	
if PropKey == k then
if !input.IsKeyDown(v) then
Stopper2 = 1 
propkill1 = 0
	end
end
// Stop Flipout For PropKill Func
	

// End Func And For Loop //	
	end	
end

hook.Add("Think","ActiveBinds",Binds)

function LoadBinds()
AimKey = GetConVarString("Ink_AimKeySave")
MenuKey = GetConVarString("Ink_MenuKeySave")
PropKey = GetConVarString("Ink_PropKeySave")

end
LoadBinds()

// End Hax Func</pre>


