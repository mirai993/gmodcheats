--This has been in my Pastebin for a long time, and I am no longer developing it.
--This is my first lua script, so it sucks ass. Enjoy.

if SERVER then return end
/*
 _   _                                   _   _                           
( ) ( ) _                               ( ) ( ) _        _               
| `\| |(_)   __     __     __   _ __    | | | |(_)  ___ (_)   _     ___  
| , ` || | /'_ `\ /'_ `\ /'__`\( '__)   | | | || |/',__)| | /'_`\ /' _ `\
| |`\ || |( (_) |( (_) |(  ___/| |      | \_/ || |\__, \| |( (_) )| ( ) |
(_) (_)(_)`\__  |`\__  |`\____)(_)      `\___/'(_)(____/(_)`\___/'(_) (_)
          ( )_) |( )_) |                                                 
           \___/' \___/'
Special thanks to:
-fr1kin
-Discord                                                 
*/


local hook = hook
local CreateClientConVar = CreateClientConVar 
local GetConVarNumber = GetConVarNumber 
CreateClientConVar("NV_ESP_Enabled",0,true,false)
CreateClientConVar("NV_ESP_Health",0,true,false)
CreateClientConVar("NV_ESP_Admin",0,true,false)
CreateClientConVar("NV_ESP_Money",0,true,false)
CreateClientConVar("NV_Vis_Asus",0,true,false)
CreateClientConVar("NV_Vis_XQZ",0,true,false)
CreateClientConVar("NV_Vis_Chams",0,true,false)
CreateClientConVar("NV_Vis_Crosshair",0,true,false)
CreateClientConVar("NV_Vis_Prop_Chams",0,true,false)
CreateClientConVar("NV_Vis_Prop_XQZ",0,true,false)

local Vector = Vector
local Color = Color

surface.CreateFont("MS Reference Sans Serif",12,100,true,false, "ESPFont") 
surface.CreateFont("Trebuchet22",10,100,true,false, "DRPFont") 

local RED = Color(255,0,0)
local GREEN = Color(0,255,0)
local BLUE = Color(0,0,255)
local WHITE = Color(255,255,255)

local function ChamsMaterials()

local Texture = {
  ["$basetexture"] = "models/debug/debugwhite",
  ["$model"]       = 1,
  ["$translucent"] = 1,
  ["$alpha"]       = 1,
  ["$nocull"]      = 1,
  ["$ignorez"]  = 1
}
   
local mat = CreateMaterial( "Solid", "VertexLitGeneric", Texture )
return mat
end

local function ESP()
	if GetConVarNumber("NV_ESP_Enabled") == 1 then
		for k,v in pairs(player.GetAll()) do 
		local Pos = v:GetPos() + Vector(0,0,70)
		Pos = Pos:ToScreen() 
		local TEAMCOL = team.GetColor(v:Team())
			if v == LocalPlayer() or v:Team() == TEAM_SPECTATOR then continue end 
			if v:Alive() and v:Health() > 0 then 
				draw.SimpleText(v:Name() ,"ESPFont" ,Pos.x ,Pos.y ,TEAMCOL ,TEXT_ALIGN_LEFT) 
				if GetConVarNumber("NV_ESP_Health") == 1 then
					draw.SimpleText("H: " .. v:Health() ,"ESPFont" ,Pos.x ,Pos.y + 10 ,TEAMCOL ,TEXT_ALIGN_LEFT) 
				if GetConVarNumber("NV_ESP_Admin") == 1 then
					if v:IsAdmin() then
						draw.SimpleText("KKK" ,"ESPFont" ,Pos.x ,Pos.y + 20 ,RED ,TEXT_ALIGN_LEFT) 
						end
					end
				end
			end
		end
	end
end 
hook.Add("HUDPaint","ESP",ESP)

local function DarkRP()
	if GetConVarNumber("NV_ESP_Money") == 1 then
		for k,v in pairs(ents.GetAll()) do 
		local DPos = v:GetPos():ToScreen() 
			if v:GetClass() == "spawned_money" then 
				draw.SimpleText("$" .. v.dt.amount ,"DRPFont" ,DPos.x ,DPos.y ,BLUE ,TEXT_ALIGN_CENTER)
			end
		end
	end
end
hook.Add("HUDPaint","DarkRP",DarkRP)

/**********************
		Visual
**********************/

local function Asus() 
	if GetConVarNumber("NV_Vis_Asus") == 1 then
		for k,v in pairs(ents.GetAll()) do 
			if v:GetClass() == "worldspawn" then 
			cam.Start3D( EyePos() , EyeAngles() ) 
				cam.IgnoreZ(true) 
				render.SetBlend(1-80/255) 
				v:DrawModel() 
				cam.IgnoreZ(false)
			cam.End3D()
			end
		end
	end
end
hook.Add("RenderScreenspaceEffects","Asus",Asus)
local function XQZ()
	if GetConVarNumber("NV_Vis_XQZ") == 1 then
		for k,v in pairs(player.GetAll()) do 
			if v:Alive() and v:Health() > 0 then 
				cam.Start3D( EyePos() , EyeAngles() ) 
					cam.IgnoreZ(true) 
					render.SetColorModulation((WHITE.r * 1/255), (WHITE.g * 1/255), (WHITE.b * 1/255)) 
					v:DrawModel() 
					cam.IgnoreZ(false) 
				cam.End3D() 
			end
		end
	end
end
hook.Add("RenderScreenspaceEffects","XQZ",XQZ)
local function Chams()
	if GetConVarNumber("NV_Vis_Chams") == 1 then
		for k,v in pairs(player.GetAll()) do 
		local TEAMCOL = team.GetColor(v:Team()) 
			if v:Alive() and v:Health() > 0 then 
				cam.Start3D( EyePos() , EyeAngles() ) 
					render.SuppressEngineLighting(true) 
					render.SetColorModulation((TEAMCOL.r * 1/255), (TEAMCOL.g * 1/255), (TEAMCOL.b * 1/255)) 
					SetMaterialOverride(ChamsMaterials()) 
					v:DrawModel()
					render.SuppressEngineLighting(false) 
					render.SetColorModulation(1,1,1) 
					SetMaterialOverride() 
				cam.End3D() 
			end
		end
	end
end
hook.Add("RenderScreenspaceEffects","Chams",Chams)
local function PropXQZ()
	if GetConVarNumber("NV_Vis_Prop_XQZ") == 1 then
		for k,v in pairs(ents.GetAll()) do 
			if v:GetClass() == "prop_physics" then 
				cam.Start3D( EyePos() , EyeAngles() )
					cam.IgnoreZ(true) 
					v:DrawModel() 
					cam.IgnoreZ(false) 
				cam.End3D() 
			end
		end
	end
end
hook.Add("RenderScreenspaceEffects","PropXQZ",PropXQZ)
local function PropChams()
	if GetConVarNumber("NV_Vis_Prop_Chams") == 1 then
		for k,v in pairs(ents.GetAll()) do 
			if v:GetClass() == "prop_physics" then 
				cam.Start3D( EyePos() , EyeAngles() ) 
					render.SuppressEngineLighting(true) 
					render.SetColorModulation((GREEN.r * 1/255), (GREEN.g * 1/255), (GREEN.b * 1/255)) 
					SetMaterialOverride(ChamsMaterials()) 
					v:DrawModel() 
					render.SuppressEngineLighting(false) 
					render.SetColorModulation(1,1,1) 
					SetMaterialOverride() 
				cam.End3D() 
			end
		end
	end
end
hook.Add("RenderScreenspaceEffects","propchams",PropChams)

local function Crosshair()
	if GetConVarNumber("NV_Vis_Crosshair") == 1 then
		surface.SetDrawColor(255,0,0)
		surface.DrawLine( ScrW()/2 - 12, ScrH()/2, ScrW()/2 - 2, ScrH()/2 )
        surface.DrawLine( ScrW()/2 + 12, ScrH()/2, ScrW()/2 + 2, ScrH()/2 )
        surface.DrawLine( ScrW()/2, ScrH()/2 - 12, ScrW()/2, ScrH()/2 - 2 )
        surface.DrawLine( ScrW()/2, ScrH()/2 + 12, ScrW()/2, ScrH()/2 + 2 )
	end
end
hook.Add("HUDPaint","Crosshair",Crosshair)