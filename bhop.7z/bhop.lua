--[[
	MOD/lua/anotherbhopscript.lua
	'cREO | STEAM_0:0:14290904 <85.218.231.57:27005> | [05-12-13 09:04:13PM]
	===BadFile===
]]

  local bhop
hook.Add("Think", "bhop", function()
if bhop then
     if (input.IsKeyDown( KEY_SPACE ) ) then
        if LocalPlayer():IsOnGround() then
            RunConsoleCommand("+jump")
            HasJumped = 1
        else
            RunConsoleCommand("-jump")
            HasJumped = 0
        end
    elseif bhop and LocalPlayer():IsOnGround() then
        if HasJumped == 1 then
            RunConsoleCommand("-jump")
            HasJumped = 0
        end
    end
end
end)

concommand.Add("bhop_toggle", function()
if bhop then
    bhop = !bhop
    LocalPlayer():ChatPrint("Bhop turned OFF")
else
    bhop = !bhop
    LocalPlayer():ChatPrint("Bhop turned ON")
end
end)
