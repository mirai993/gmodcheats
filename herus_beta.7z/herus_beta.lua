

    require"dyx"

    local me,ply = LocalPlayer()

    if not ConVarExists("herus_hs_sv_cheats") then
            me:ConCommand("hs_spoofcvar sv_cheats")
    end

    timer.Simple(0.1,function()
            RunConsoleCommand("herus_hs_sv_cheats","1")
    end)

    if not ConVarExists("herus_hs_host_timescale") then
            me:ConCommand("hs_spoofcvar host_timescale")
    end

    RunConsoleCommand("herus_hs_host_timescale","1")
    RunConsoleCommand("cl_csr_hit_effects","0")
    RunConsoleCommand("cl_csr_extra_muzzle_flash","0")

    local Vector,Angle = Vector,Angle

    local getall = player.GetAll
    local traceline = util.TraceLine

    local eyepos

    if not firebullets then
            firebullets = debug.getregistry().Entity.FireBullets
    end

    local wep = function() return me:GetActiveWeapon() end

    local spreads = {["weapon_pistol"] = Vector(0.01,0.01,0),
    ["weapon_smg1"] = Vector(0.04362,0.04362,0),
    ["weapon_ar2"] = Vector(0.02618,0.02618,0),}

    debug.getregistry().Entity.FireBullets = function(ent,bullet)
            if not spreads[wep():GetClass()] then
                    spreads[wep():GetClass()] = bullet.Spread
            end
            return firebullets(ent,bullet)
    end

    local ms = Angle()

    local function mouse(c)
            ms = ms + Angle(c:GetMouseY() * 0.022,-c:GetMouseX() * 0.022,0)
            ms.p = math.Clamp(ms.p,-89,89.9)
    end

    local function transform(a,x)
            local b = Vector(0,0,0)
            local m1,m2,m3 = x[1],x[2],x[3]
            local vec1 = Vector(m1[1],m1[2],m1[3])
            local vec2 = Vector(m2[1],m2[2],m2[3])
            local vec3 = Vector(m3[1],m3[2],m3[3])
            b.x = a:Dot(vec1) + m1[4]
            b.y = a:Dot(vec2) + m2[4]
            b.z = a:Dot(vec3) + m3[4]
            return b
    end

    local function position(v)
            local pos = v:LocalToWorld(v:OBBCenter())
            //if true then return pos end
            local wepon = wep()
            if wepon != NULL and wepon.Primary and v:Health() <= wepon.Primary.Damage then return pos end
            local bone = v:LookupBone("ValveBiped.Bip01_Head1")
            if not bone then return pos end
            if not v:GetBonePosition(bone) then return pos end
            local matrix = v:GetBoneMatrix(bone)
            if not matrix then return pos end
            local min,max = v:GetHitBoxBounds(0,0)
            matrix = matrix:ToTable()
            min = transform(min,matrix)
            max = transform(max,matrix)
            pos = (min + max) * 0.5
            local aa = v:EyeAngles()
            if aa.p < -89 then
                    pos.z = max.z - 6
            end
            return pos + ((v:GetVelocity() * 0.00672724) - (me:GetVelocity() * 0.0087775))
    end

    local function insight(v,vec)
            local tr = {}
            tr.start = me:GetShootPos()
            tr.endpos = vec
            tr.filter = {v,me}
            tr.mask = 1174421507
            local trace = traceline(tr)
            return trace.Fraction == 1
    end

    local function valid(v)
            if not input.IsKeyDown(55) then return false end
            if v == me then return false end
            if v:Health() < 1 then return false end
            if _nyx.IsDormant(v:EntIndex()) then return false end
            //if v:GetFriendStatus() == "friend" then return false end
            //if v:GetNWString("usergroup") != "user" then return false end
            if v:GetColor().a < 255 then return false end
            if v:InVehicle() then return false end
            if not v:GetMoveType() == bit.bor(2,8) then return false end
            return true
    end

    local function targets()
            local k = getall()
            local dist1 = 2147483647
            for i=1,#k do
                    local v = k[i]
                    if not valid(v) then continue end
                    local pos = position(v)
                    if not insight(v,pos) then continue end
                    local dist2 = (me:GetPos() - v:GetPos()):LengthSqr()
                    if dist1 < dist2 then continue end
                    ply = v
                    eyepos = pos
                    dist1 = dist2
            end
    end

    local function angles(c)
            ply = nil
            targets()
            if not ply then return ms end
            local ang = (eyepos - me:GetShootPos()):Angle()
            c:SetButtons(c:GetButtons() + 1)
            return ang
    end

    local function hl2()
            local class = wep():GetClass()
            if class == "weapon_pistol" then return true end
            if class == "weapon_357" then return true end
            if class == "weapon_smg1" then return true end
            if class == "weapon_ar2" then return true end
            return false
    end

    local function punch()
            if wep() == NULL then return Angle() end
            if string.find(string.lower(wep():GetClass()), "fas2") or hl2() then
                    return me:GetPunchAngle()
            end
            return Angle()
    end

    local function aimbot(c)
            if c:CommandNumber() == 0 then return end
            me.voice_battery = 100
            mouse(c)
            local ult = angles(c) - punch()
            ult = _nyx.RemoveSpread(c,ult,(IsValid(wep()) and spreads[wep():GetClass()]) and -spreads[wep():GetClass()] or Vector()):Angle()
            ult.p = ult.p > 180 and ult.p - 360 or ult.p
            ult.r = 0
            _nyx.SetViewAngles(c,ult)
            if me:GetMoveType() == 2 then
                    local side = Vector(c:GetForwardMove(), c:GetSideMove(), 0)
                    side = ((side:GetNormal()):Angle() + (c:GetViewAngles() - ms)):Forward() * side:Length()
                    c:SetForwardMove(side.x)
                    c:SetSideMove(side.y)
                    _nyx.Bunnyhop(c,me:OnGround())
            end
            //c:SetMouseWheel(-1337)
    end
    hook.Add("CreateMove","aimbot",aimbot)

    local function calc(ply,origin,angles)
            local view = {}
            view.angles = ms//me:GetAimVector():Angle()
            view.vm_angles = ms
            view.origin = origin
            view.fov = 75
            return view
    end
    hook.Add("CalcView","calc",calc)

    local SimpleTextOutlined = draw.SimpleTextOutlined
    local GetColor = team.GetColor
    local SetDrawColor = surface.SetDrawColor
    local DrawLine = surface.DrawLine

    local w,h = ScrW()*0.5,ScrH()*0.5

    surface.CreateFont("genericfont",{
    name = "Fixedsys",
    size = 14,
    weight = 600,
    antialias = true})

    local function esp()
            local k = getall()
            for i=1,#k do
                    local v = k[i]
                    if not IsValid(v) or v == me then continue end
                    local obb = v:LocalToWorld(v:OBBCenter()):ToScreen()
                    SimpleTextOutlined(
                    v:Name(),
                    "genericfont",
                    obb.x,obb.y,
                    v:Health() < 1 and Color(0,0,0) or GetColor(v:Team()),
                    1,1,
                    1,Color(0,0,0,105))
            end
    end
    hook.Add("HUDPaint","esp",esp)

    local nametime = 0
    local change

    local name = me:Name()
    local namechange = false

    local function think()
            if input.IsKeyDown(KEY_F5) and change then
                    namechange = not namechange
                    change = false
            end
            if not input.IsKeyDown(KEY_F5) then change = true end
            if namechange and nametime < RealTime() then
                    local k = player.GetAll()
                    for i=1,#k do
                            local v = k[math.random(#k)]
                            if string.find(me:Name(),v:Name()) == nil then
                                    me:ConCommand("hs_namechange "..v:Name()..((math.random(2) == 1) and " " or "  "))
                                    break
                            end
                    end
                    nametime = RealTime() + GetConVarNumber("sv_namechange_cooldown_seconds")
            end
    end
    hook.Add("Think","thinkHACKER",think)