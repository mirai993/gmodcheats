--[[
	lua/Titanium.lua.txt [#31750, 1868176692, UID:1292405585]
	Granny Basher | STEAM_0:0:107971845 <92.20.206.15:27005> | [26.04.15 07:45:16PM]
	===BadFile===
]]

/*
 
Titanium v1, also known as cdbot v3.2
 
This will be the last thing i'm releasing, as i'm leaving gmod.
 
For better or worse.
 
~cdriza
 
Gave my account to someone else.
 
R.I.P. cdriza
 
2014-2015
 
Credits:
        cdriza - big codes (esp, norecoil, attack function, fixing valid check, other codes)
        Fami - g_pHooks/aimbot/valid check
        Im Friendly - huge codes/speeding shit up/testing
        nox aim_flex - testing
        Hafnium - sexy bone esp ok
        And everyone else who helped out!
*/
 
// Localization - Sp33d
 
// libaries mabe
local debug = debug
local chat = chat
local surface = surface
local cam = cam
local draw = draw
local render = render
local util = util
local table = table
local math = math
local concommand = concommand
local input = input
local team = team
local hook = hook
local ents = ents
local vgui = vgui
local player = player
local net = net
local notification = notification
 
// globals?
local Angle = Angle
local Color = Color
local require = require
local Entity = Entity
local IsValid = IsValid
local GetConVar = GetConVar
local FindMetaTable = FindMetaTable
local tobool = tobool
local LocalPlayer = LocalPlayer
local RunConsoleCommand = RunConsoleCommand
local CreateClientConVar = CreateClientConVar
local GetConVarNumber = GetConVarNumber
local pairs = pairs
local Material = Material
local unpack = unpack
local tonumber = tonumber
local tostring = tostring
local type = type
local Vector = Vector
local RunString = RunString
local ScrW = ScrW
local ScrH = ScrH
local MsgC = MsgC
 
// meta tables ????????????
local __eq = __eq
local __tostring = __tostring
local __gc = __mul
local __index = __index
local __concat = __concat
local __newindex = __newindex
local __add = __add
local __sub = __sub
local __div  = __div
local __call = __call
local __pow = __pow
local __unm = __unm
local __lt = __lt
local __le = __le
local __mode = __mode
local __metatable = __metatable
 
// shits bout to get real
 
local _R = debug.getregistry();
local _G = _G;
 
// supercheetstuffs
local GetTeam = _R.Player.Team;
local InVehicle = _R.Player.InVehicle;
local IsAlive = _R.Player.Alive;
local LocalToWorld = _R.Entity.LocalToWorld;
local GetOBBCenter = _R.Entity.OBBCenter;
local GetCenter = function(x) if !x then return; end return LocalToWorld(x,GetOBBCenter(x)); end;
local EyePos = _R.Entity.EyePos;
local ToAngles = _R.Vector.Angle;
local IsDormant = _R.Entity.IsDormant;
local GetWeapon = _R.Player.GetActiveWeapon;
local ply = LocalPlayer();
local CalcViewAngle = Angle();
local CMDNum = 0;
local loadtime = 0;
local aim_target = nil;
local attacking = false;
local attacking2 = false;
local tacbypass = false;
local oRCC = RunConsoleCommand;
 
// 100% useful timer
 
timer.Create("Titanium.timers.load.loadtime", 0.1, 0, function()
        loadtime = loadtime + 0.1
end )
 
// Defining stuff OK
 
local TL = {
        vars = {
                aim_enabled = true,
                aim_bonescan = true,
                aim_team = true,
                aim_specs = false,
                aim_specs_only = false,
                esp_enabled = true,
                esp_bones = true,
                esp_chams = false,
        },
       
        cones = {
                [ "weapon_smg1" ] = Vector( -0.04362, -0.04362, -0.04362 ),
                [ "weapon_ar2" ] = Vector( -0.02618, -0.02618, 0.02618 ),
                [ "weapon_shotgun" ] = Vector( -0.08716, -0.08716, -0.08716 ),
                [ "weapon_pistol" ] = Vector( -0.01, -0.01, -0.01),
        },
       
        TAC_Cmds = {
                "tac_debug_cmds",
                "tac_debug_hooks",
                "tac",
        },
       
        // Credits: NanoHack lua - because i'm lazy
       
        Bones = {
                Head = 'ValveBiped.Bip01_Head1',
                Neck = 'ValveBiped.Bip01_Neck1',
                Spine = 'ValveBiped.Bip01_Spine',
                Spine1 = 'ValveBiped.Bip01_Spine1',
                Spine2 = 'ValveBiped.Bip01_Spine2',
                Spine3 = 'ValveBiped.Bip01_Spine3',
                Spine4 = 'ValveBiped.Bip01_Spine4',
                [ 'R Hand' ] = 'ValveBiped.Bip01_R_Hand',
                [ 'L Hand' ] = 'ValveBiped.Bip01_L_Hand',
                [ 'R Calf' ] = 'ValveBiped.Bip01_R_Calf',
                [ 'R Foot' ] = 'ValveBiped.Bip01_R_Foot',
                [ 'R Toes' ] = 'ValveBiped.Bip01_R_Toe0',
                [ 'L Calf' ] = 'ValveBiped.Bip01_L_Calf',
                [ 'L Foot' ] = 'ValveBiped.Bip01_L_Foot',
                [ 'L Toes' ] = 'ValveBiped.Bip01_L_Toe0',
                [ 'L Thigh' ] = 'ValveBiped.Bip01_L_Thigh',
                [ 'R Thigh' ] = 'ValveBiped.Bip01_R_Thigh',
                [ 'L Forearm' ] = 'ValveBiped.Bip01_L_Forearm',
                [ 'R Forearm' ] = 'ValveBiped.Bip01_R_Forearm',
                [ 'L Upperarm' ] = 'ValveBiped.Bip01_L_UpperArm',
                [ 'R Upperarm' ] = 'ValveBiped.Bip01_R_UpperArm'
        },
}
 
// ok what does it look like
 
surface.CreateFont("TL.font", {
        font = "Arial",
        size = 15
} )
 
// :^)
 
function TL.Notify(msg)
        surface.PlaySound("buttons/button6.wav"); --:^)
        notification.AddLegacy(msg, NOTIFY_GENERIC, 4);
        //chat.AddText(Color(0,0,255,255),"[Titanium] ", Color(240,240,240), msg); :(
end;
 
// NOTHING TO SEE HERE!
 
function TL.Nothing()
end
 
// big hooks
 
TL.CheatHooks = {
        ["CreateMove"] = {},
        ["CalcView"] = {},
        ["HUDPaint"] = {}
};
 
// bigger unloasiaonononajaodfhsdfvhas HOW 2 SPELL
 
function TL.Unload()
       
        if tacbypass == false then
                local hooked_vfuncname = "CreateMove"
                        for i = 1, #TL.CheatHooks[hooked_vfuncname] do local hook_name = TL.CheatHooks[hooked_vfuncname][i]; hook.Remove(hooked_vfuncname, hook_name); TL.Notify("Hook Removed: "..hooked_vfuncname.." ('"..hook_name.."')"); table.remove(TL.CheatHooks[hooked_vfuncname],i); end
                hooked_vfuncname = "CalcView"
                        for i = 1, #TL.CheatHooks[hooked_vfuncname] do local hook_name = TL.CheatHooks[hooked_vfuncname][i]; hook.Remove(hooked_vfuncname, hook_name); TL.Notify("Hook Removed: "..hooked_vfuncname.." ('"..hook_name.."')"); table.remove(TL.CheatHooks[hooked_vfuncname],i); end
                hooked_vfuncname = "HUDPaint"
                        for i = 1, #TL.CheatHooks[hooked_vfuncname] do local hook_name = TL.CheatHooks[hooked_vfuncname][i]; hook.Remove(hooked_vfuncname, hook_name); TL.Notify("Hook Removed: "..hooked_vfuncname.." ('"..hook_name.."')"); table.remove(TL.CheatHooks[hooked_vfuncname],i); end
                aim_target = nil;
       
                concommand.Remove("TL_menu")
                concommand.Remove("TL_unload")
        elseif tacbypass == true then
                GAMEMODE.CreateMove = TL.Nothing;
                GAMEMODE.HUDPaint = TL.Nothing;
                GAMEMODE.CalcView = TL.Nothing;
        end
       
        TL.Notify("Unloaded!")
end
 
// done explaining ok
 
local oldFireBullets = _R.Entity.FireBullets;
 
_R.Entity.FireBullets = function(i, bullet)
        if TL.cones[LocalPlayer():GetActiveWeapon():GetClass()] != bullet.Spread then
                TL.cones[LocalPlayer():GetActiveWeapon():GetClass()] = bullet.Spread
        end
       
        oldFireBullets(i, bullet)
end
 
function TL.Esp()
        for k,v in pairs(player.GetAll()) do
                local min = (v:GetPos() + Vector(0, 0, 1)):ToScreen();
                local max = (v:GetPos() + Vector(0, 0, 70)):ToScreen();
                local hit = (min.y - max.y);
                local wid = (hit / 2.5)
                        if (v != ply and v:Alive() and TL.vars["esp_enabled"] and v:Health() > 0) then
                                local ESP = (v:EyePos()):ToScreen()
                                draw.DrawText(v:Name(), "TL.font", ESP.x -25, ESP.y -56, team.GetColor(v:Team()), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT)
                                draw.DrawText("Rank: "..v:GetUserGroup(), "TL.font", ESP.x -25, ESP.y -44, Color(255, 255, 255, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT)
                               
                                if(v:GetActiveWeapon():IsValid()) then
                                        draw.DrawText("Weapon: " ..v:GetActiveWeapon():GetClass(), "TL.font", ESP.x -25, ESP.y -32, Color(255, 255, 255, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT)
                                end
                               
                                surface.SetDrawColor(team.GetColor(v:Team()))
                                surface.DrawOutlinedRect(max.x - (wid / 2) - 1, max.y - 1, wid + 2, hit + 2);
                                draw.RoundedBox(0, max.x - (wid/1.5) + 1, max.y + 1, (wid-2)/10, (hit-2)*0.01 * v:Health(), Color(0,200,0,255))
                               
                                if TL.vars["esp_bones"] then
                                        local FirstBone, SecondBone
 
                                        FirstBone = v:GetBonePosition( 0 ):ToScreen()
                                        SecondBone = v:GetBonePosition( 5 ):ToScreen()
                                        surface.DrawLine(FirstBone.x, FirstBone.y, SecondBone.x, SecondBone.y)
 
                                        FirstBone = v:GetBonePosition( 5 ):ToScreen()
                                        SecondBone = v:GetBonePosition( 9 ):ToScreen()
                                        surface.DrawLine(FirstBone.x, FirstBone.y, SecondBone.x, SecondBone.y)
 
                                        FirstBone = v:GetBonePosition( 9 ):ToScreen()
                                        SecondBone = v:GetBonePosition( 10 ):ToScreen()
                                        surface.DrawLine(FirstBone.x, FirstBone.y, SecondBone.x, SecondBone.y)
 
                                        FirstBone = v:GetBonePosition( 10 ):ToScreen()
                                        SecondBone = v:GetBonePosition( 11 ):ToScreen()
                                        surface.DrawLine(FirstBone.x, FirstBone.y, SecondBone.x, SecondBone.y)
 
                                        FirstBone = v:GetBonePosition( 5 ):ToScreen()
                                        SecondBone = v:GetBonePosition( 14 ):ToScreen()
                                        surface.DrawLine(FirstBone.x, FirstBone.y, SecondBone.x, SecondBone.y)
 
                                        FirstBone = v:GetBonePosition( 14 ):ToScreen()
                                        SecondBone = v:GetBonePosition( 15 ):ToScreen()
                                        surface.DrawLine(FirstBone.x, FirstBone.y, SecondBone.x, SecondBone.y)
 
                                        FirstBone = v:GetBonePosition( 15 ):ToScreen()
                                        SecondBone = v:GetBonePosition( 16 ):ToScreen()
                                        surface.DrawLine(FirstBone.x, FirstBone.y, SecondBone.x, SecondBone.y)
 
                                        FirstBone = v:GetBonePosition( 0 ):ToScreen()
                                        SecondBone = v:GetBonePosition( 22 ):ToScreen()
                                        surface.DrawLine(FirstBone.x, FirstBone.y, SecondBone.x, SecondBone.y)
 
                                        FirstBone = v:GetBonePosition( 22 ):ToScreen()
                                        SecondBone = v:GetBonePosition( 23 ):ToScreen()
                                        surface.DrawLine(FirstBone.x, FirstBone.y, SecondBone.x, SecondBone.y)
 
 
                                        FirstBone = v:GetBonePosition( 23 ):ToScreen()
                                        SecondBone = v:GetBonePosition( 25 ):ToScreen()
                                        surface.DrawLine(FirstBone.x, FirstBone.y, SecondBone.x, SecondBone.y)
 
 
                                        FirstBone = v:GetBonePosition( 0 ):ToScreen()
                                        SecondBone = v:GetBonePosition( 18 ):ToScreen()
                                        surface.DrawLine(FirstBone.x, FirstBone.y, SecondBone.x, SecondBone.y)
 
 
                                        FirstBone = v:GetBonePosition( 18 ):ToScreen()
                                        SecondBone = v:GetBonePosition( 19 ):ToScreen()
                                        surface.DrawLine(FirstBone.x, FirstBone.y, SecondBone.x, SecondBone.y)
 
                                        FirstBone = v:GetBonePosition( 19 ):ToScreen()
                                        SecondBone = v:GetBonePosition( 21 ):ToScreen()
                                        surface.DrawLine(FirstBone.x, FirstBone.y, SecondBone.x, SecondBone.y)
                                end
                               
                                if TL.vars["esp_chams"] then
                                        cam.Start3D()
                                        cam.IgnoreZ(true)
                                        render.MaterialOverride(Material("models/debug/debugwhite"))
                                        render.SuppressEngineLighting( true )
                               
                                        local col = Color(0, 110, 255)
                               
                                        render.SetColorModulation(col.r/255, col.g/255, col.b/255)
                                        v:DrawModel()
                                        render.SetColorModulation( 1, 1, 1 )
                                        render.SuppressEngineLighting( false )
                                        render.MaterialOverride(0)
                                        cam.IgnoreZ(false)
 
                                        cam.End3D()
                                end
                        end
                end
end
 
function TL.Crosshair()
        local x = ScrW() / 2.0023
        local y = ScrH() / 2.001
        surface.SetDrawColor(50, 150, 255, 255)
        surface.DrawRect(x, y, 3, 3, 0)
end
 
function TL.NoRecoil()
        local ply = LocalPlayer()
        local weapon = ply:GetActiveWeapon()
       
        if weapon.Primary then
       
                if weapon.Primary.Recoil then
                        weapon.Primary.Recoil = 0
                end
               
                if weapon.Primary.KickUp then
                        weapon.Primary.KickUp = 0
                        weapon.Primary.KickDown = 0
                        weapon.Primary.KickHorizontal = 0
                end
        end
end
 
function TL.IsVisible(vPosition, aim_target)
        local __trace = {}
        local ply = LocalPlayer()
        local gsp = ply:GetShootPos()
               
        local _trace = {
                [ "start" ] = gsp,
                [ "endpos" ] = vPosition,
                [ "filter" ] = ply,
                [ "mask" ] = MASK_SHOT
        }
       
        local trace = util.TraceLine( _trace, __trace )
       
        return (trace.Fraction == 1 or trace.Entity == aim_target)
end
 
function TL.Attack(cmd)
        local ply = LocalPlayer()
        local weapon = ply:GetActiveWeapon()
       
        if IsValid(wep) and weapon.Primary and (weapon.Primary.Automatic == true) then
                cmd:SetButtons(bit.bor(cmd:GetButtons(), IN_ATTACK))
                attacking = true
        else
                if attacking then
                        cmd:RemoveKey(IN_ATTACK)
                        attacking = false
                else
                        cmd:SetButtons(bit.bor(cmd:GetButtons(), IN_ATTACK))
                        attacking = true
                end
        end
       
        if IsValid(wep) and weapon.Primary and (weapon.Primary.Automatic == false) then
                cmd:SetButtons(bit.bor(cmd:GetButtons(), IN_ATTACK))
                attacking2 = true
        else
                if attacking2 then
                        cmd:RemoveKey(IN_ATTACK)
                        attacking2 = false
                else
                        cmd:SetButtons(bit.bor(cmd:GetButtons(), IN_ATTACK))
                        attacking2 = true
                end
        end
end
 
function TL.GetAimArea(pEnt)
        local forward = Vector()
        local eyes = Vector()
       
        if !TL.vars["aim_bonescan"] then
                if pEnt:LookupAttachment("eyes") != 0 then
                        return pEnt:GetAttachment(pEnt:LookupAttachment("eyes")).Pos
                end
        else
                if pEnt:LookupAttachment("eyes") != 0 and TL.IsVisible(pEnt:GetAttachment(pEnt:LookupAttachment("eyes")).Pos, pEnt) then
                        return pEnt:GetAttachment(pEnt:LookupAttachment("eyes")).Pos
                else           
                        for k,v in pairs(TL.Bones) do
                                if pEnt:LookupBone(v) then
                                        if TL.IsVisible(pEnt:GetBonePosition(pEnt:LookupBone(v)), pEnt) then
                                                return pEnt:GetBonePosition(pEnt:LookupBone(v))
                                        end
                                end
                        end
                end
        end
       
        return pEnt:GetPos() + pEnt:OBBCenter()
end
 
function TL.ValidTarget(pEnt)
        if (!pEnt) then return false; end
       
        if (IsDormant(pEnt)) then return false; end
       
        if pEnt:IsPlayer() then
                if (pEnt == ply) then return false; end
       
                if (!IsAlive(pEnt)) then return false; end
               
                if (InVehicle(pEnt)) then return false; end
 
                if (GetTeam(pEnt) == TEAM_SPECTATOR) and !TL.vars["aim_specs"] and !TL.vars["aim_specs_only"] then return false; end
               
                if (GetTeam(pEnt) != TEAM_SPECTATOR) and TL.vars["aim_specs_only"] then return false; end
               
                if !TL.vars["aim_team"] then
                        if pEnt:Team() == ply:Team() then return false; end
                end
               
                if !TL.IsVisible(TL.GetAimArea(pEnt), pEnt) then return false; end
               
        end
       
        return true;
end
 
function TL.AimThread()
        aim_target = nil;
        local pPlayers = player.GetAll();
        for i = 1, #pPlayers do local pEnt = pPlayers[i];
                if (!TL.ValidTarget(pEnt)) then continue; end
                aim_target = pEnt;
        end
end
 
function TL.GetAimPos(pEnt, cmd)
        local AimArea = TL.GetAimArea(pEnt)
       
        if cmd:CommandNumber() > CMDNum then
                CMDNum = cmd:CommandNumber()
                AimArea = (AimArea - ply:GetVelocity() * engine.TickInterval())
        end
       
        return AimArea;
end
 
function TL.Aimb0t(cmd)
        if (aim_target ~= nil) and TL.vars["aim_enabled"] then
                local vPosition = TL.GetAimPos(aim_target, cmd);
                local aAngles = ToAngles(vPosition - EyePos(ply))
                //aAngles = TL.PredSpread(cmd, aAngles) lolno
                aAngles.p = math.NormalizeAngle(aAngles.p);
                aAngles.y = math.NormalizeAngle(aAngles.y);
                       
                cmd:SetViewAngles(aAngles);
                TL.Attack(cmd);
        end
end
 
function TL.BunnyHop(cmd)
        local ply = LocalPlayer()
       
        if ply:IsOnGround() and cmd:KeyDown(IN_JUMP) then
                cmd:SetButtons( bit.bor(cmd:GetButtons(), IN_JUMP) )
        else
                cmd:RemoveKey(IN_JUMP)
        end
end
 
function TL.Menu(player, command, arguments)
        local Main = vgui.Create("DFrame")
        Main:SetSize(400, 230)
        Main:SetTitle("")
        Main:Center()
        Main:MakePopup()
        Main:ShowCloseButton(true)
        Main.Paint = function( self )
                draw.RoundedBox(0, 0, 0, self:GetWide(), self:GetTall(), Color( 50, 50, 50 ))
                draw.RoundedBox(0, 0, 0, self:GetWide(), 25, Color(50, 50, 200))
                draw.SimpleText("Titanium", "BudgetLabel", self:GetWide() / 2, 12.5, Color(255,255,255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
               
                surface.SetDrawColor(Color(75,75,75))
                surface.DrawLine(115, 25, 115, self:GetTall())
                surface.DrawLine(115, self:GetTall() - 55, self:GetWide(), self:GetTall() - 55)
                draw.SimpleText("Menu made by Im Friendly", "BudgetLabel", 120, self:GetTall() - 50, Color(255,255,255))
                draw.SimpleText("Hack made by cdriza", "BudgetLabel", 120, self:GetTall() - 30, Color(255,255,255))
        end
       
                local AimEnabled = vgui.Create("DCheckBoxLabel", Main)
        AimEnabled:SetPos(122, 33)
        AimEnabled:SetText("Aimbot Enabled")
        AimEnabled:SetVisible(false)
        AimEnabled:SetValue(TL.vars["aim_enabled"])
        AimEnabled:SizeToContents()
        AimEnabled.OnChange = function(self)
                TL.vars["aim_enabled"] = tobool(self:GetChecked())
        end
       
        local AimBoneScan = vgui.Create("DCheckBoxLabel", Main)
        AimBoneScan:SetPos(122, 52)
        AimBoneScan:SetText("pBoneScan")
        AimBoneScan:SetVisible(false)
        AimBoneScan:SetValue(TL.vars["aim_bonescan"])
        AimBoneScan:SizeToContents()
        AimBoneScan.OnChange = function(self)
                TL.vars["aim_bonescan"] = tobool(self:GetChecked())
        end
       
        local AimTeam = vgui.Create("DCheckBoxLabel", Main)
        AimTeam:SetPos(122, 71)
        AimTeam:SetText("Aim at Team")
        AimTeam:SetVisible(false)
        AimTeam:SetValue(TL.vars["aim_team"])
        AimTeam:SizeToContents()
        AimTeam.OnChange = function(self)
                TL.vars["aim_team"] = tobool(self:GetChecked())
        end
       
        local AimIgnoreSpec = vgui.Create("DCheckBoxLabel", Main)
        AimIgnoreSpec:SetPos(122, 90)
        AimIgnoreSpec:SetText("Aim at Spectators")
        AimIgnoreSpec:SetVisible(false)
        AimIgnoreSpec:SetValue(TL.vars["aim_specs"])
        AimIgnoreSpec:SizeToContents()
        AimIgnoreSpec.OnChange = function(self)
                TL.vars["aim_specs"] = tobool(self:GetChecked())
        end
         
         local AimOnlySpec = vgui.Create("DCheckBoxLabel", Main)
        AimOnlySpec:SetPos(122, 109)
        AimOnlySpec:SetText("Aim Only at Spectators")
        AimOnlySpec:SetVisible(false)
        AimOnlySpec:SetValue(TL.vars["aim_specs_only"])
        AimOnlySpec:SizeToContents()
        AimOnlySpec.OnChange = function(self)
                TL.vars["aim_specs_only"] = tobool(self:GetChecked())
        end
       
        local EspEnabled = vgui.Create("DCheckBoxLabel", Main)
        EspEnabled:SetPos(122, 33)
        EspEnabled:SetText("ESP Enabled")
        EspEnabled:SetVisible(false)
        EspEnabled:SetValue(TL.vars["esp_enabled"])
        EspEnabled:SizeToContents()
        EspEnabled.OnChange = function(self)
                TL.vars["esp_enabled"] = tobool(self:GetChecked())
        end
       
        local EspBone = vgui.Create("DCheckBoxLabel", Main)
        EspBone:SetPos(122, 52)
        EspBone:SetText("Bone ESP")
        EspBone:SetVisible(false)
        EspBone:SetValue(TL.vars["esp_bones"])
        EspBone:SizeToContents()
        EspBone.OnChange = function(self)
                TL.vars["esp_bones"] = tobool(self:GetChecked())
        end
       
        local EspChams = vgui.Create("DCheckBoxLabel", Main)
        EspChams:SetPos(122, 71)
        EspChams:SetText("ESP pChams ")
        EspChams:SetVisible(false)
        EspChams:SetValue(TL.vars["esp_chams"])
        EspChams:SizeToContents()
        EspChams.OnChange = function(self)
                TL.vars["esp_chams"] = tobool(self:GetChecked())
        end
       
        local AimButton = vgui.Create("DButton", Main)
        AimButton:SetSize(100, 80)
        AimButton:SetPos(7, 40)
        AimButton:SetText("")
        AimButton.Paint = function(self)
                draw.RoundedBox(0, 0, 0, self:GetWide(), self:GetTall(), Color(100, 100, 255))
                draw.SimpleText("Aimbot", "BudgetLabel", self:GetWide() / 2, self:GetTall() / 2, Color(255, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        end
        AimButton.DoClick = function(self)
                AimEnabled:SetVisible(true)
                AimBoneScan:SetVisible(true)
                AimTeam:SetVisible(true)
                AimIgnoreSpec:SetVisible(true)
                AimOnlySpec:SetVisible(true)
               
                EspEnabled:SetVisible(false)
                EspBone:SetVisible(false)
                EspChams:SetVisible(false)
        end
       
        local EspButton = vgui.Create("DButton", Main)
        EspButton:SetSize(100, 80)
        EspButton:SetPos(7, 136)
        EspButton:SetText("")
        EspButton.Paint = function(self)
                draw.RoundedBox(0, 0, 0, self:GetWide(), self:GetTall(), Color(100, 100, 255))
                draw.SimpleText("Visuals", "BudgetLabel", self:GetWide() / 2, self:GetTall() / 2, Color(255, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        end
        EspButton.DoClick = function(self)
                AimEnabled:SetVisible(false)
                AimBoneScan:SetVisible(false)
                AimTeam:SetVisible(false)
                AimIgnoreSpec:SetVisible(false)
                AimOnlySpec:SetVisible(false)
               
                EspEnabled:SetVisible(true)
                EspBone:SetVisible(true)
                EspChams:SetVisible(true)
        end
end
 
local function hooked_CreateMove(cmd)
 
        TL.BunnyHop(cmd);
       
        TL.AimThread();
 
        TL.Aimb0t(cmd);
       
        TL.NoRecoil();
       
        CalcViewAngle = cmd:GetViewAngles();
 
end
 
local function hooked_HUDPaint()
       
        TL.Esp();
       
        TL.Crosshair();
       
end
 
local function hooked_CalcView(ply, origin, angles, fov)
        local pWeapon = GetWeapon(ply);
        if ( pWeapon.Primary ) then pWeapon.Primary.Recoil = 0.0; end
        if ( pWeapon.Secondary ) then pWeapon.Secondary.Recoil = 0.0; end
       
        local view = {}
        view.angles = CalcViewAngle;
        view.angles.r = 0;
        view.vm_angles = view.angles;
       
        return view;
end
 
function TL.AddHook(hooked_vfuncname,hooked_nfunc)
        local random_hookname = tostring(math.random(666,133769420));
        hook.Add(hooked_vfuncname, random_hookname, hooked_nfunc);
        TL.Notify("Hook Added: "..hooked_vfuncname.." ('"..random_hookname.."')");
        table.insert(TL.CheatHooks[hooked_vfuncname],random_hookname)
end
 
function TL.Check()
        if ulx then
                print("[Titanium] ULX is installed! (THREAT LEVEL: NONE)")
               
                if ulx.screengrab then
                        print("[Titanium] ULX Screengrab found! (THREAT LEVEL: MEDIUM)")
                else
                        print("[Titanium] ULX Screengrab not found!")
                end
        else
                print("[Titanium] ULX not found!")
        end
       
        if qac or qac then
                print("[Titanium] Quack Anti Cheat found! (THREAT LEVEL: MEDIUM)")
        end
       
        if cac or cac or CAC or CAC then
                print("[Titanium] Cake Anti Cheat found! (THREAT LEVEL: VERY HIGH!)")
                print("[Titanium] Leaving...")
                RunConsoleCommand("disconnect")
        end
       
        if LeyAC or LeyAC or leyac or leyac then
                print("[Titanium] LeyAC found! (THREAT LEVEL: VERY HIGH!)")
                print("[Titanium] Leaving...")
                RunConsoleCommand("disconnect")
        end
       
        if TLac or TLAC then
                print("[Titanium] TLriza Anti Cheat found! (THREAT LEVEL: MEDIUM)")
        end
       
        if dac or DAC or DAC or dac then
                print("[Titanium] Daz Anti Cheat found! (THREAT LEVEL: VERY LOW)")
        end
       
        for k,v in pairs(concommand.GetTable()) do
                if TL.TAC_Cmds[k] then
                        print("[Titanium] Tyler's Anti Cheat found! (THREAT LEVEL: MEDIUM)")
                        print("[Titanium] Switching into TAC Bypass mode.")
                        tacbypass = true
                end
        end
end
 
function render.Capture()
        TL.Notify("Blocked screengrab attempt!")
        print("Blocked render.Capture()")
        return util.Base64Encode(util.CRC("DO YOU BELIEVE IN MAGIC"))
end
 
function render.CapturePixels()
        TL.Notify("Blocked screengrab attempt!")
        print("Blocked render.CapturePixels()")
        return util.Base64Encode("did you know that garry claimed to detect atees autism? sadly he did did not.")
end
 
function RunConsoleCommand(args)
        if args == "editor_toggle" or args == "net_start 1" or args == "mm_select_session" or args == "__screenshot_internal" or args == "quit" or args == "quitnoconfirm" or args == "disconnect" or args == "banme" or args == "aacp" or args == "kickme" then
                TL.Notify("Blocked RunConsoleCommand: " .. args)
        else
                oRCC(args)
        end
end
 
TL.Check()
 
if tacbypass == false then
        chat.AddText(Color(0,0,255,255),"[Titanium Loader] ", Color(240,240,240), "Loaded version 1! [RIP CDRIZA]");
        TL.AddHook("CreateMove", hooked_CreateMove);
        TL.AddHook("CalcView", hooked_CalcView);
        TL.AddHook("HUDPaint", hooked_HUDPaint);
 
        concommand.Add("Titanium_unload", function() TL.Unload() end);
        concommand.Add("Titanium_menu", function() TL.Menu() end);
       
        notification.AddProgress("lolwut", "Titanium v1 loaded in " .. tostring(loadtime) .. " seconds!")
 
        timer.Destroy("Titanium.timers.load.loadtime")
       
        timer.Simple(5, function()
                notification.Kill("lolwut")
        end )
       
elseif tacbypass == true then
        chat.AddText(Color(0,0,255,255),"[Titanium Loader] ", Color(240,240,240), "Loaded version 1! [RIP CDRIZA]");
        GAMEMODE.CreateMove = hooked_CreateMove;
        GAMEMODE.CalcView = hooked_CalcView;
        GAMEMODE.HUDPaint = hooked_HUDPaint;
               
        concommand.Remove("tac_debug_cmds");
        concommand.Remove("tac_debug_hooks");
               
        concommand.Add("tac_debug_cmds", function() TL.Unload() end);
        concommand.Add("tac_debug_hooks", function() TL.Menu() end);
       
        timer.Destroy("Titanium.timers.load.loadtime")
       
        TL.Notify("Loaded in TAC-Secure mode!");
        TL.Notify("Check console for new concommands!");
               
        print("[Titanium] New ConCommands: ")
        print("tac_debug_cmds = UNLOAD")
        print("tac_debug_hooks = MENU")
        print("-------------------------")
end
 
chat.AddText(Color(0,0,255,255),"[Titanium Loader]", Color(240,240,240), "Loading Titanium v1! [RIP CDRIZA]");