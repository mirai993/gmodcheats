--[[
	MOD/lua/privatehack.lua
	Duplex | ^8 HejskilleD 8^ | STEAM_0:1:68853227 <212.10.170.105:27005> | [28-10-13 09:25:57PM]
	===BadFile===
]]

local Openmenu = CreateClientConVar("Hejskilled_openmenu", "0", false, false)
local Frame
local Canspawn = true
local Frame1
local Canpress = true
local Lockon
local IgnoreT = {}
local GPass = {}
local Pass = {}
local Keyuse = {}
local CanP = {}
local Ent = {}
local FunctionT = {}

CreateConVar("rpgod",0)

local DupeMenu
local ButtonD = {{},{},{},{}}
local AutoDupeProp
local AutoDupeOn = false
local AutoDupeTime = 5
local AutoDupeDis = 0
local AutoDupeDisS = 0

local Timebeforeopening = 0
local DupeProp 
local DupeVec = Vector(0,0,0)
local DupeDis = 0
local DupeNumber = 0
local DupeNumberH = 0
local Interval = 300
local OldString = "#This is duped with hejskilled's Glua Duper! \n#Server: "..GetHostName().." \n#Ip: "..GetConVarString("ip").."\n@persist Count:number Interval:number VecOff:vector Spawnpos:vector O:entity PropSolid:number Spawnone2:number ".."\n@model models/items/combine_rifle_ammo01.mdl \n	interval(Interval) \n Count = Count + 1 \n Vecoff = vec(0,0,0) \n Interval = 500 \n PropSolid = 0 \n Spawnone2 = 0 \n#Spawning props \nif(first()) {\n	E = entity()\n	O = owner()\n} \n"
local DupeString = OldString


local function DrawButtonGui(X,Y,ColU,ColI)
	local ButtonOutGui = {{},{},{},{}}
	ButtonOutGui[1]["x"] = 10
	ButtonOutGui[1]["y"] = 0
	ButtonOutGui[1]["u"] = 0 
	ButtonOutGui[1]["v"] = 0
	ButtonOutGui[2]["x"] = X+10
	ButtonOutGui[2]["y"] = 0
	ButtonOutGui[2]["u"] = 1 
	ButtonOutGui[2]["v"] = 0
	ButtonOutGui[3]["x"] = X
	ButtonOutGui[3]["y"] = Y
	ButtonOutGui[3]["u"] = 0
	ButtonOutGui[3]["v"] = 0
	ButtonOutGui[4]["x"] = 0
	ButtonOutGui[4]["y"] = Y
	ButtonOutGui[4]["u"] = 0 
	ButtonOutGui[4]["v"] = 0	
	local ButtonInGui = {{},{},{},{}}
	ButtonInGui[1]["x"] = 12
	ButtonInGui[1]["y"] = 2
	ButtonInGui[1]["u"] = 0 	
	ButtonInGui[1]["v"] = 0
	ButtonInGui[2]["x"] = X+12
	ButtonInGui[2]["y"] = 2
	ButtonInGui[2]["u"] = 1 
	ButtonInGui[2]["v"] = 0
	ButtonInGui[3]["x"] = X+2
	ButtonInGui[3]["y"] = Y+2
	ButtonInGui[3]["u"] = 0
	ButtonInGui[3]["v"] = 0
	ButtonInGui[4]["x"] = 2
	ButtonInGui[4]["y"] = Y+2
	ButtonInGui[4]["u"] = 0 
	ButtonInGui[4]["v"] = 0			
	draw.NoTexture()						
	surface.SetDrawColor( ColI)				
	surface.DrawPoly( ButtonOutGui )		
	draw.NoTexture()						
	surface.SetDrawColor( ColU)				
	surface.DrawPoly( ButtonInGui )			
end

--if GetConVarNumber("rpgod") == 1 then
--		if LocalPlayer():Health() < 100 then
--			LocalPlayer():ConCommand("say /buyhealth") 
--		end
--	end
for I = 1,100 do
	surface.CreateFont("HFont-"..I, {
		size = I,
		weight = 500,
		antialias = true,
		shadow = false,
		font = "Trebuchet MS"})
		
	surface.CreateFont("HFontAwe-"..I, {
		font = "Tahoma",
		size = I,
		weight = 600,
		antialias = true
	})	
end





local AimT = {}
local Derma = {}
	
	
	
concommand.Add("hs_turnaround", function()
	LocalPlayer():ConCommand("gm_spawn models/props_c17/FurnitureWashingmachine001a.mdl")
	timer.Simple(0.1, function()
		RunConsoleCommand("+jump")
		LocalPlayer():SetEyeAngles(Angle(0,LocalPlayer():GetAimVector():Angle().y+180,0))
	end)
	timer.Simple(0.2, function()
		RunConsoleCommand("-jump")
	end)
end)
	
	
	
	
	
	
	
	
	
hook.Add("Think","------2-----",function()


	if input.IsKeyDown(KEY_DELETE) then
		if !IsValid(DupeMenu) then
			DupeMenu = vgui.Create( "DFrame" )
		end
		DupeMenu:SetSize( 600,  325)
		DupeMenu:SetPos(ScrW() * 0.5-300, ScrH() * 0.5-162.5 )
		DupeMenu:SetTitle( "" )
		DupeMenu:ShowCloseButton(true)
		DupeMenu:MakePopup(  )
		DupeMenu.Paint = function() 
			draw.RoundedBox( 0, 0, 0, 600, 325, Color( 10, 100, 10, 100 ) )
			surface.SetDrawColor( 0, 0, 0, 255 )
			surface.DrawOutlinedRect( 0, 0, 600, 325)			
			draw.SimpleText("Hackclient" ,"HFont-24", 20, 15, Color(255,255,255,255))
			draw.SimpleText("HejskilleD<3" ,"HFont-16", 130, 25, Color(0,0,0,255))
			draw.RoundedBox( 12, 5, 50, 600-10, 500-250, Color( 50, 50, 50, 190 ) )		
			draw.RoundedBox( 4, 20, 130, 150, 5, Color( 0, 200, 0, 255 ) )				
			draw.RoundedBox( 4, 20+(AutoDupeTime*2), 130-5, 5, 15, Color( 0, 0, 0, 255 ) )	
			draw.SimpleText("Time: "..AutoDupeTime ,"HFont-16", 30, 140, Color(255,255,255,255))
		end
		local StartDupe = vgui.Create("DButton",DupeMenu)
		StartDupe:SetPos(25,60)
		StartDupe:SetSize(155,30)
		StartDupe:SetText("")
		StartDupe.Paint = function()
			
			if AutoDupeOn then
				DrawButtonGui(155,30,Color(0,200,0),Color(200,200,200))
			else		
				DrawButtonGui(155,30,Color(200,0,0),Color(200,200,200))
			end			
		
			
		end
		StartDupe.DoClick = function()
			AutoDupeOn = !AutoDupeOn
			if AutoDupeOn == false then
				if IsValid(AutoDupeProp) then
					AutoDupeProp:Remove()
				end
			else
				if !IsValid(AutoDupeProp) then
					AutoDupeProp = ents.CreateClientProp()
					AutoDupeProp:SetModel("models/XQM/Rails/gumball_1.mdl")
					AutoDupeProp:SetModelScale( AutoDupeDis/15, 0 )
					AutoDupeProp:SetPos(LocalPlayer():GetEyeTrace().HitPos)
					AutoDupeProp:SetMaterial("models/props_combine/health_charger_glass")
					AutoDupeProp:SetColor(Color(0,200,0,100))
					AutoDupeProp:Activate()
					AutoDupeProp:Spawn()
				end
			end
		end
		local StartDupe = vgui.Create("DButton",DupeMenu)
		StartDupe:SetPos(25,95)
		StartDupe:SetSize(75,30)
		StartDupe:SetText("")
		StartDupe.Paint = function()
			ButtonD[1]["x"] = 10
			ButtonD[1]["y"] = 0
			ButtonD[1]["u"] = 0 
			ButtonD[1]["v"] = 0
			ButtonD[2]["x"] = 70
			ButtonD[2]["y"] = 0
			ButtonD[2]["u"] = 1 
			ButtonD[2]["v"] = 0
			ButtonD[3]["x"] = 60
			ButtonD[3]["y"] = 25
			ButtonD[3]["u"] = 0
			ButtonD[3]["v"] = 0
			ButtonD[4]["x"] = 0
			ButtonD[4]["y"] = 25
			ButtonD[4]["u"] = 0 
			ButtonD[4]["v"] = 0			
			draw.NoTexture()						
			surface.SetDrawColor( Color(200,200,200))				
			surface.DrawPoly( ButtonD )					
			ButtonD[1]["x"] = 12
			ButtonD[1]["y"] = 2
			ButtonD[1]["u"] = 0 
			ButtonD[1]["v"] = 0
			ButtonD[2]["x"] = 72
			ButtonD[2]["y"] = 2
			ButtonD[2]["u"] = 1 
			ButtonD[2]["v"] = 0
			ButtonD[3]["x"] = 62
			ButtonD[3]["y"] = 27
			ButtonD[3]["u"] = 0
			ButtonD[3]["v"] = 0
			ButtonD[4]["x"] = 2
			ButtonD[4]["y"] = 27
			ButtonD[4]["u"] = 0 
			ButtonD[4]["v"] = 0			
			draw.NoTexture()				
			surface.SetDrawColor( Color(100,100,0))				
			surface.DrawPoly( ButtonD )	
			draw.SimpleText("Add + " ,"HFont-20", 11, 0, Color(0,0,0,255))		
			draw.SimpleText("Add + " ,"HFont-20", 12, 1, Color(255,255,255,255))					
		end
		StartDupe.DoClick = function()
			if AutoDupeTime <= 55 then
				AutoDupeTime = AutoDupeTime +5
			end
		end
		local StartDupe = vgui.Create("DButton",DupeMenu)
		StartDupe:SetPos(25+80,95)
		StartDupe:SetSize(75,30)
		StartDupe:SetText("")
		StartDupe.Paint = function()
			ButtonD[1]["x"] = 10
			ButtonD[1]["y"] = 0
			ButtonD[1]["u"] = 0 
			ButtonD[1]["v"] = 0
			ButtonD[2]["x"] = 70
			ButtonD[2]["y"] = 0
			ButtonD[2]["u"] = 1 
			ButtonD[2]["v"] = 0
			ButtonD[3]["x"] = 60
			ButtonD[3]["y"] = 25
			ButtonD[3]["u"] = 0
			ButtonD[3]["v"] = 0
			ButtonD[4]["x"] = 0
			ButtonD[4]["y"] = 25
			ButtonD[4]["u"] = 0 
			ButtonD[4]["v"] = 0			
			draw.NoTexture()						
			surface.SetDrawColor( Color(200,200,200))				
			surface.DrawPoly( ButtonD )				
			ButtonD[1]["x"] = 12
			ButtonD[1]["y"] = 2
			ButtonD[1]["u"] = 0 
			ButtonD[1]["v"] = 0
			ButtonD[2]["x"] = 72
			ButtonD[2]["y"] = 2
			ButtonD[2]["u"] = 1 
			ButtonD[2]["v"] = 0
			ButtonD[3]["x"] = 62
			ButtonD[3]["y"] = 27
			ButtonD[3]["u"] = 0
			ButtonD[3]["v"] = 0
			ButtonD[4]["x"] = 2
			ButtonD[4]["y"] = 27
			ButtonD[4]["u"] = 0 
			ButtonD[4]["v"] = 0			
			draw.NoTexture()				
			surface.SetDrawColor( Color(100,100,0))				
			surface.DrawPoly( ButtonD )	
			draw.SimpleText("Min - " ,"HFont-20", 11, 0, Color(0,0,0,255))		
			draw.SimpleText("Min - " ,"HFont-20", 12, 1, Color(255,255,255,255))					
		end
		StartDupe.DoClick = function()
			if AutoDupeTime >= 10 then
				AutoDupeTime = AutoDupeTime -5
			end
		end
		local StartDupe = vgui.Create("DButton",DupeMenu)
		StartDupe:SetPos(25,95+65)
		StartDupe:SetSize(155,30)
		StartDupe:SetText("")
		StartDupe.Paint = function()
			ButtonD[1]["x"] = 10
			ButtonD[1]["y"] = 0
			ButtonD[1]["u"] = 0 
			ButtonD[1]["v"] = 0
			ButtonD[2]["x"] = 150
			ButtonD[2]["y"] = 0
			ButtonD[2]["u"] = 1 
			ButtonD[2]["v"] = 0
			ButtonD[3]["x"] = 140
			ButtonD[3]["y"] = 25
			ButtonD[3]["u"] = 0
			ButtonD[3]["v"] = 0
			ButtonD[4]["x"] = 0
			ButtonD[4]["y"] = 25
			ButtonD[4]["u"] = 0 
			ButtonD[4]["v"] = 0			
			draw.NoTexture()						
			surface.SetDrawColor( Color(200,200,200))				
			surface.DrawPoly( ButtonD )		
			
			ButtonD[1]["x"] = 12
			ButtonD[1]["y"] = 2
			ButtonD[1]["u"] = 0 
			ButtonD[1]["v"] = 0
			ButtonD[2]["x"] = 152
			ButtonD[2]["y"] = 2
			ButtonD[2]["u"] = 1 
			ButtonD[2]["v"] = 0
			ButtonD[3]["x"] = 142
			ButtonD[3]["y"] = 27
			ButtonD[3]["u"] = 0
			ButtonD[3]["v"] = 0
			ButtonD[4]["x"] = 2
			ButtonD[4]["y"] = 27
			ButtonD[4]["u"] = 0 
			ButtonD[4]["v"] = 0			
			draw.NoTexture()				
			surface.SetDrawColor( Color(100,100,0))				
			surface.DrawPoly( ButtonD )	
			draw.SimpleText("Selected Distance." ,"HFont-20", 11, 0, Color(0,0,0,255))		
			draw.SimpleText("Selected Distance." ,"HFont-20", 12, 1, Color(255,255,255,255))					
		end
		StartDupe.DoClick = function()
			if IsValid(AutoDupeProp) then
				DupeMenu:Close()
			end
		end	
		local PlayerE = vgui.Create("DButton",DupeMenu)
		PlayerE:SetPos(250,95)
		PlayerE:SetSize(75,30)
		PlayerE:SetText("")
		PlayerE.Paint = function()
			if FunctionT[5] then
				DrawButtonGui(63,28,Color(0,100,0),Color(200,200,200))	
			else
				DrawButtonGui(63,28,Color(100,0,0),Color(200,200,200))		
			end
			draw.SimpleText("Player" ,"HFont-20", 11, 0, Color(0,0,0,255))		
			draw.SimpleText("Player" ,"HFont-20", 12, 1, Color(255,255,255,255))					
		end
		PlayerE.DoClick = function()	
			FunctionT[5] = !FunctionT[5]			
		end
		local MoneyE = vgui.Create("DButton",DupeMenu)
		MoneyE:SetPos(250,130)
		MoneyE:SetSize(75,30)
		MoneyE:SetText("")
		MoneyE.Paint = function()
			if FunctionT[6] then
				DrawButtonGui(63,28,Color(0,100,0),Color(200,200,200))	
			else
				DrawButtonGui(63,28,Color(100,0,0),Color(200,200,200))		
			end
			draw.SimpleText("Props" ,"HFont-20", 11, 0, Color(0,0,0,255))		
			draw.SimpleText("Props" ,"HFont-20", 12, 1, Color(255,255,255,255))					
		end
		MoneyE.DoClick = function()	
			FunctionT[6] = !FunctionT[6]			
		end
		local ModelE = vgui.Create("DButton",DupeMenu)
		ModelE:SetPos(250,165)
		ModelE:SetSize(75,30)
		ModelE:SetText("")
		ModelE.Paint = function()
			if FunctionT[7] then
				DrawButtonGui(63,28,Color(0,100,0),Color(200,200,200))	
			else
				DrawButtonGui(63,28,Color(100,0,0),Color(200,200,200))		
			end
			draw.SimpleText("Model" ,"HFont-20", 11, 0, Color(0,0,0,255))		
			draw.SimpleText("Model" ,"HFont-20", 12, 1, Color(255,255,255,255))					
		end
		ModelE.DoClick = function()	
			FunctionT[7] = !FunctionT[7]			
		end
		local HealthE = vgui.Create("DButton",DupeMenu)
		HealthE:SetPos(250,200)
		HealthE:SetSize(75,30)
		HealthE:SetText("")
		HealthE.Paint = function()
			if FunctionT[8] then
				DrawButtonGui(63,28,Color(0,100,0),Color(200,200,200))	
			else
				DrawButtonGui(63,28,Color(100,0,0),Color(200,200,200))		
			end
			draw.SimpleText("Health" ,"HFont-20", 11, 0, Color(0,0,0,255))		
			draw.SimpleText("Health" ,"HFont-20", 12, 1, Color(255,255,255,255))					
		end
		HealthE.DoClick = function()	
			FunctionT[8] = !FunctionT[8]			
		end
		local AimposE = vgui.Create("DButton",DupeMenu)
		AimposE:SetPos(250,235)
		AimposE:SetSize(75,30)
		AimposE:SetText("")
		AimposE.Paint = function()
			if FunctionT[9] then
				DrawButtonGui(63,28,Color(0,100,0),Color(200,200,200))	
			else
				DrawButtonGui(63,28,Color(100,0,0),Color(200,200,200))		
			end
			draw.SimpleText("Aimpos" ,"HFont-20", 11, 0, Color(0,0,0,255))		
			draw.SimpleText("Aimpos" ,"HFont-20", 12, 1, Color(255,255,255,255))					
		end
		AimposE.DoClick = function()	
			FunctionT[9] = !FunctionT[9]			
		end
		local ShipmentE = vgui.Create("DButton",DupeMenu)
		ShipmentE:SetPos(250+80,95)
		ShipmentE:SetSize(75,30)
		ShipmentE:SetText("")
		ShipmentE.Paint = function()
			if FunctionT[2] then
				DrawButtonGui(63,28,Color(0,100,0),Color(200,200,200))	
			else
				DrawButtonGui(63,28,Color(100,0,0),Color(200,200,200))		
			end
			
			draw.SimpleText("Shipment" ,"HFont-20", 11, 0, Color(0,0,0,255))		
			draw.SimpleText("Shipment" ,"HFont-20", 12, 1, Color(255,255,255,255))					
		end
		ShipmentE.DoClick = function()	
			FunctionT[2] = !FunctionT[2]			
		end
		local PrinterE = vgui.Create("DButton",DupeMenu)
		PrinterE:SetPos(250+80,130)
		PrinterE:SetSize(75,30)
		PrinterE:SetText("")
		PrinterE.Paint = function()
								
						
			if FunctionT[3] then
				DrawButtonGui(63,28,Color(0,100,0),Color(200,200,200))	
			else
				DrawButtonGui(63,28,Color(100,0,0),Color(200,200,200))		
			end
			
			draw.SimpleText("Printer" ,"HFont-20", 11, 0, Color(0,0,0,255))		
			draw.SimpleText("Printer" ,"HFont-20", 12, 1, Color(255,255,255,255))					
		end
		PrinterE.DoClick = function()	
			FunctionT[3] = !FunctionT[3]			
		end
		local EveryE = vgui.Create("DButton",DupeMenu)
		EveryE:SetPos(250+80,165)
		EveryE:SetSize(75,30)
		EveryE:SetText("")
		EveryE.Paint = function()
			if FunctionT[4] then
				DrawButtonGui(63,28,Color(0,100,0),Color(200,200,200))	
			else
				DrawButtonGui(63,28,Color(100,0,0),Color(200,200,200))		
			end
			draw.SimpleText("Every" ,"HFont-20", 11, 0, Color(0,0,0,255))		
			draw.SimpleText("Every" ,"HFont-20", 12, 1, Color(255,255,255,255))					
		end
		EveryE.DoClick = function()	
			FunctionT[4] = !FunctionT[4]			
		end	
		local AimE = vgui.Create("DButton",DupeMenu)
		AimE:SetPos(250+160,95)
		AimE:SetSize(75,30)
		AimE:SetText("")
		AimE.Paint = function()
			if FunctionT[20] then
				DrawButtonGui(63,28,Color(0,100,0),Color(200,200,200))	
			else
				DrawButtonGui(63,28,Color(100,0,0),Color(200,200,200))		
			end
				
			draw.SimpleText("Aim" ,"HFont-20", 11, 0, Color(0,0,0,255))		
			draw.SimpleText("Aim" ,"HFont-20", 12, 1, Color(255,255,255,255))					
		end
		AimE.DoClick = function()	
			FunctionT[20] = !FunctionT[20]			
		end
		local SpecE = vgui.Create("DButton",DupeMenu)
		SpecE:SetPos(250+240,95)
		SpecE:SetSize(75,30)
		SpecE:SetText("")
		SpecE.Paint = function()
			if FunctionT[21] then
				DrawButtonGui(63,28,Color(0,100,0),Color(200,200,200))	
			else
				DrawButtonGui(63,28,Color(100,0,0),Color(200,200,200))		
			end
				
			draw.SimpleText("Spectate" ,"HFont-20", 11, 0, Color(0,0,0,255))		
			draw.SimpleText("Spectate" ,"HFont-20", 12, 1, Color(255,255,255,255))					
		end
		SpecE.DoClick = function()	
			FunctionT[21] = !FunctionT[21]	
			if FunctionT[21] then
				AimT["Pos"] = LocalPlayer():GetPos()
			end
		end
		
		
	end
	if !IsValid(DupeProp) then
		DupeProp = ents.CreateClientProp()
	end
	DupeProp:SetModel("models/XQM/Rails/gumball_1.mdl")
	DupeProp:SetModelScale( DupeDis/15, 0 )
	DupeProp:SetPos(DupeVec)
	DupeProp:SetMaterial("models/props_combine/health_charger_glass")
	DupeProp:SetColor(Color(0,200,255,20))
	DupeProp:Activate()
	DupeProp:Spawn()	
	if input.IsKeyDown(KEY_LALT) then
		if DupeVec == Vector(0,0,0) then
			DupeVec = LocalPlayer():GetEyeTrace().HitPos		
		else
			DupeDis = DupeVec:Distance(LocalPlayer():GetEyeTrace().HitPos)
		end
	end	
	if input.IsKeyDown(KEY_HOME) then
		DupeProp:Remove()
		DupeString = OldString
		DupeNumber = 0
		DupeNumberH = 0
		DupeVec = Vector(0,0,0)
		DupeDis = 0
	end
	if input.IsKeyDown(KEY_INSERT) then
		if DupeVec != Vector(0,0,0) then	
			local DupeProps = ents.FindInSphere(DupeVec,DupeDis)	
			chat.AddText(Color(0,200,0),"[Glua-Duper]",Color(255,255,255),": You started a duplication!")
			for k,v in ipairs(ents.GetAll()) do 	
				if v:GetPos():Distance(DupeVec) <= DupeDis then			
					if v:GetModel() != "models/XQM/Rails/gumball_1.mdl" then					
						if IsValid(v) then 								
							if string.sub(string.lower(v:GetClass()),1,5) == "prop_" then
								DupeNumber = DupeNumber +1
								DupeString = (DupeString .."\n \n if(Count=="..tostring(DupeNumber)..") {")						
								DupeString = (DupeString .."\n    P = propSpawn(\""..tostring(v:GetModel()).."\",0)")						
								DupeString = (DupeString .."\n    P:setPos(vec("..string.gsub(tostring(v:GetPos())," ",",")..")+Vecoff)")
								DupeString = (DupeString .."\n    P:setAng(ang("..string.gsub(tostring(v:GetAngles())," ",",").."))")							
								DupeString = (DupeString .."\n    P:propFreeze(1)")
								DupeString = (DupeString .."\n    P:setMaterial(\""..tostring(v:GetMaterial()).."\")")							
								DupeString = (DupeString .."\n    P:setColor(vec4("..tostring(v:GetColor().r)..","..tostring(v:GetColor().g)..","..tostring(v:GetColor().b)..","..tostring(v:GetColor().a).."))")
								DupeString = (DupeString .."\n    setName(\"Spawned: \n"..tostring(v:GetModel()).."\n vec("..string.gsub(tostring(v:GetPos())," ",",")..") \n ang("..string.gsub(tostring(v:GetAngles())," ",",")..") \n"..DupeNumberH.."\n Type: Prop \n Time Elapsed: 0 \n Time Spent: 0 \")")
								DupeString = (DupeString .."\n    if(PropSolid==1) {")
								DupeString = (DupeString .."\n       	P:propNotSolid(1)")	
								DupeString = (DupeString .."\n    }")
								DupeString = (DupeString .."\n}")						
							end						
							if string.lower(v:GetClass()) == "gmod_wire_hologram" then
								DupeNumberH = DupeNumberH +1
								DupeString = (DupeString .."\n \n if(Count=="..DupeNumberH..") {")						
								DupeString = (DupeString .."\n 	       holoCreate("..DupeNumberH..")")
								DupeString = (DupeString .."\n 	       holoPos("..DupeNumberH..",vec("..string.gsub(tostring(v:GetPos())," ",",")..")+Vecoff)")
								DupeString = (DupeString .."\n 	       holoAng("..DupeNumberH..",ang("..string.gsub(tostring(v:GetAngles())," ",",").."))")
								DupeString = (DupeString .."\n    	   holoMaterial("..DupeNumberH..",\""..tostring(v:GetMaterial()).."\")")	
								DupeString = (DupeString .."\n    	   holoColor("..DupeNumberH..",vec4("..tostring(v:GetColor().r)..","..tostring(v:GetColor().g)..","..tostring(v:GetColor().b)..","..tostring(v:GetColor().a).."))")						
								DupeString = (DupeString .."\n    	   holoModel("..DupeNumberH..",\""..tostring(v:GetModel()).."\")")	
								DupeString = (DupeString .."\n    	   holoScale("..DupeNumberH..",vec("..tostring(tonumber(v.scale.x))..","..tostring(tonumber(v.scale.y))..","..tostring(tonumber(v.scale.z)).."))")
								DupeString = (DupeString .."\n         setName(\"Spawned: \n"..tostring(v:GetModel()).."\n vec("..string.gsub(tostring(v:GetPos())," ",",")..") \n ang("..string.gsub(tostring(v:GetAngles())," ",",")..") \n"..DupeNumberH.."\n Type: Holo \" )")
								DupeString = (DupeString .."\n}")						
							end					
						end
					end
				end
			end
			DupeString = (DupeString .."\n \n if(Count=="..tostring(DupeNumber+1)..") {")
			DupeString = (DupeString .."\n \n printColor(vec(0,200,0),\"[Glua-Duper]\",vec(255,255,255),\": Contraption finshed spawning "..DupeNumber.." total prop.\")")
			DupeString = (DupeString .."\n \n setName(\"Done Spawning\")")
			--DupeString = (DupeString .."\n \n selfDestruct()")
			DupeString = (DupeString .."\n}")
			timer.Simple(Timebeforeopening ,function() 
				Derma_StringRequest("Filename.", "Insert the name of the dupe!", "", function(a) 
					if file.Exists("Expression2/".."Glua_duper".."/"..string.gsub(tostring(a)," ","_")..".txt","DATA") then
						local RandomN = math.random(1,5000)
						chat.AddText(Color(0,200,0),"[Glua-Duper]",Color(255,255,255),": "..string.gsub(tostring(a)," ","_").." have been saved, Renamed to "..string.gsub(tostring(a)," ","_").."_"..tostring(RandomN))
						file.Write( "Expression2/".."Glua_duper".."/"..string.gsub(tostring(a)," ","_").."_"..tostring(RandomN)..".txt", DupeString)	
					else
						chat.AddText(Color(0,200,0),"[Glua-Duper]",Color(255,255,255),": "..string.gsub(tostring(a)," ","_").." have been saved!")
						file.Write( "Expression2/".."Glua_duper".."/"..string.gsub(tostring(a)," ","_")..".txt", DupeString)	
					end			
					file.Write( "Expression2/".."Glua_duper".."/"..string.gsub("LastDupe"," ","_")..".txt", DupeString)					
					DupeProp:Remove()
					DupeString = OldString
					DupeNumber = 0
					DupeNumberH = 0
					DupeVec = Vector(0,0,0)
					DupeDis = 0				
				end)		
			end)			
		end
		DupeProp:Remove()
		DupeVec = Vector(0,0,0)
	end
end)


hook.Add( "PostPlayerDraw", "DrawName", function() 
	for k,self in pairs(ents.GetAll()) do
		if self:GetModel() == "models/hunter/triangles/1x1x2carved025.mdl-1111" then
			local Pos = self:GetPos()
			local Ang = self:GetAngles()					
			Ang:RotateAroundAxis(Ang:Up(), 45)
			Ang:RotateAroundAxis(Ang:Right(), 0)
			Ang:RotateAroundAxis(Ang:Forward(), 90)
			cam.Start3D2D(Pos - Ang:Right() *8 - Ang:Forward() *5 + Ang:Up() *10, Ang, 0.11)		
				draw.RoundedBox( 4, -130, -400, 420, 800, Color(70,70,70,255) )			
				draw.RoundedBox( 16, -110, -370, 420-40, 100, Color(0,149,200,255) )			
			cam.End3D2D()
		end
	end
end)


hook.Add("Think","----------df-",function()

	

	for k,ply in pairs(player.GetAll()) do	
		if IsValid(ply:GetEyeTrace().Entity) then
			if ply:GetEyeTrace().Entity:GetModel() == "models/props_lab/keypad.mdl" then
				Ent[ply] = ply:GetEyeTrace().Entity	
				local localAxis = (Ent[ply]:GetPos() - ply:GetEyeTrace().HitPos)
				local Pos1 = Ent[ply]:WorldToLocal(Vector(localAxis.x,localAxis.y,localAxis.z)+ Ent[ply]:GetPos()) 	
				
				if ply:KeyDown(IN_USE) and (CanP[ply] == false or CanP[ply] == nil) then
					CanP[ply] =true
					timer.Simple(0.5,function()		
						CanP[ply]  = false
					end)
					if Pos1.y <= 2.2 and Pos1.y >= 1 and  Pos1.z >= 0 and Pos1.z <= 1.2 then
						if Pass[ply] == nil then
							Pass[ply] = "1"
						else
							Pass[ply] = (Pass[ply].."1")
						end
					end
					if Pos1.y <= 2.2 and Pos1.y >= 1 and  Pos1.z >= 1.6 and Pos1.z <= 3 then
						if Pass[ply] == nil then
							Pass[ply] = "4"
						else
							Pass[ply] = (Pass[ply].."4")
						end
					end
					if Pos1.y <= 2.2 and Pos1.y >= 1 and  Pos1.z >= 3.2 and Pos1.z <= 4.6 then
						if Pass[ply] == nil then
							Pass[ply] = "7"
						else
							Pass[ply] = (Pass[ply].."7")
						end
					end
					if Pos1.y >= -0.7 and Pos1.y <= 0.6 and  Pos1.z >= 0 and Pos1.z <= 1.2 then
						if Pass[ply] == nil then
							Pass[ply] = "2"
						else
							Pass[ply] = (Pass[ply].."2")
						end
					end
					if Pos1.y >= -0.7 and Pos1.y <= 0.6 and  Pos1.z >= 1.6 and Pos1.z <= 3 then
						if Pass[ply] == nil then
							Pass[ply] = "5"
						else
							Pass[ply] = (Pass[ply].."5")
						end
					end
					if Pos1.y >= -0.7 and Pos1.y <= 0.6 and  Pos1.z >= 3.2 and Pos1.z <= 4.6 then
						if Pass[ply] == nil then
							Pass[ply] = "8"
						else
							Pass[ply] = (Pass[ply].."8")
						end
					end
					if Pos1.y <= -1 and Pos1.y >= -2.4 and  Pos1.z >= 0 and Pos1.z <= 1.2 then
						if Pass[ply] == nil then
							Pass[ply] = "3"
						else
							Pass[ply] = (Pass[ply].."3")
						end
					end
					if Pos1.y <= -1 and Pos1.y >= -2.4 and  Pos1.z >= 1.6 and Pos1.z <= 3 then
						if Pass[ply] == nil then
							Pass[ply] = "6"
						else
							Pass[ply] = (Pass[ply].."6")
						end
					end
					if Pos1.y <= -1 and Pos1.y >= -2.4 and  Pos1.z >= 3.2 and Pos1.z <= 4.6 then
						if Pass[ply] == nil then
							Pass[ply] = "9"
						else
							Pass[ply] = (Pass[ply].."9")
						end
					end
					if Pos1.y <= 2.3 and Pos1.y >= -0.3 and  Pos1.z >= -1.7 and Pos1.z <= -0.4 then
						Pass[ply] = nil
					end
					if Pos1.y <= -0.4 and Pos1.y >= -2.4 and  Pos1.z >= -1.7 and Pos1.z <= -0.3 then
						if Pass[ply] != nil then
							chat.AddText(Color(0,200,200),"[Key]: ",team.GetColor(ply:Team()),"("..ply:Nick()..")",Color(255,255,255)," Entered "..tostring(Pass[ply]))
							table.insert(GPass,{keypad = Ent[ply],Code = Pass[ply]})
							Pass[ply] = nil
						end
					end
				end
			end
		end
	end
end)


local ply = FindMetaTable("Player")
function ply:HSame(ent) 
	if !IsValid(ent) then return end
	local tracedata = {}
	tracedata.start = self:GetShootPos()+Vector(0,0,0)
	tracedata.endpos = ent:GetShootPos()+Vector(0,0,0)
	local trace = util.TraceLine( tracedata )
	local Return = true
	if self == ent then
		Return = false
	end
	if trace.HitWorld then
		Return = false
	end	
	if IsValid(trace.Entity) then	
		if not trace.Entity:IsPlayer() then
			Return = false
		end
	end
	return Return
end
function ply:HSameH(ent) 
	local tracedata = {}
	tracedata.start = self:GetPos()+Vector(0,0,0)
	tracedata.endpos = ent:GetPos()+Vector(0,0,0)
	local trace = util.TraceLine( tracedata )
	local Return = true
	if self == ent then
		Return = false
	end
	if trace.HitWorld then
		Return = false
	end	
	if IsValid(trace.Entity) then	
		Return = false	
	end
	return Return
end


local Data = {}




function MyCalcView(ply, pos, angles, fov)
	if FunctionT[21] then
		AimT["Calc"] = (AimT["Calc"] or AimT["Pos"])
		if ply:KeyDown(IN_FORWARD) then
			AimT["Calc"] = (AimT["Calc"] - LocalPlayer():GetAimVector() * 20)			
		end
		if ply:KeyDown(IN_BACK) then
			AimT["Calc"] = (AimT["Calc"] + LocalPlayer():GetAimVector() * 20)			
		end
		if ply:KeyDown(IN_SPEED) then			
			AimT["Calc"] = (AimT["Calc"] - LocalPlayer():GetAimVector() * 100)			
		end
		Data["endpos"] = AimT["Calc"]
		--Print(LocalPlayer():GetAimVector())
		--Print("S: "..tostring(AimT["Calc"]))
		local view = {}
		
		Data["pos"] = AimT["Pos"] - Data["endpos"]
		view.origin = Data["pos"]
		view.angles = angles
		view.fov = fov
	 
		return view
	end
end
 
hook.Add("CalcView", "MyCalcView", MyCalcView)






for k,ply in pairs(player.GetAll()) do
	local Money = ply.DarkRPVars.money
	if not Money then Money = "" end
	print(ply:Name().." : $"..Money)


end
function GenerateWedge(angle,x,y,q,ang,rad)
    local circle = {}
    circle[1] = {x = x,y = y}
    local tmp = 0
    for i=2,2 + q do
        circle[i] = {x = x + math.cos(math.rad((angle/q)*(i-2) + ang))*rad, y = y + math.sin(math.rad((angle/q)*(i-2) + ang))*rad};
    end
    return circle;
end

hook.Add( "HUDPaint", "Wallhack", function()
	surface.SetMaterial(Material("vgui/white"))					
	surface.SetDrawColor(Color(0,0,200))
	surface.DrawPoly(GenerateWedge(0,200,200,360/2,180,10))		












	if true == true then
		for k,ent in pairs(ents.GetAll()) do
			if IsValid(ent) then			
				if FunctionT[2] then
					local Position = ( ent:GetPos() + Vector( 0,0,0 ) ):ToScreen()
					if(string.find(string.lower(ent:GetClass()),"shipment",1,true) != nil) then 
									
						ent:SetMaterial("hejsmaterial/solid")
						ent:SetColor(Color(255,199,0))	
					end
				end
				if FunctionT[3] then
					local Position = ( ent:GetPos() + Vector( 0,0,0 ) ):ToScreen()
					if(string.find(string.lower(ent:GetClass()),"printer",1,true) != nil) then 
						
						ent:SetMaterial("hejsmaterial/solid")
						ent:SetColor(Color(255,199,0))	
					end
				end
				if FunctionT[4] then
					local Position = ( ent:GetPos() + Vector( 0,0,0 ) ):ToScreen()			
					if ent:GetMaterial() != "" then
						surface.SetFont("HFont-16")
						local Text = surface.GetTextSize(ent:GetModel())
						draw.RoundedBox(0, Position.x-2, Position.y-22, Text+40, 20, Color(0,0,0,200)) 				
						draw.SimpleText("Mat: "..ent:GetModel().." " ,"HFont-16", Position.x-2, Position.y-2, Color(250,250,250,255))					
					end				
					surface.SetFont("HFont-16")
					local Text = surface.GetTextSize((ent:GetModel() or "Nothing"))
					draw.RoundedBox(0, Position.x-2, Position.y-22, Text+40, 20, Color(0,0,0,200)) 				
					draw.SimpleText("Model: "..(ent:GetClass() or "Nothing") .." " ,"HFont-16", Position.x-2, Position.y-22, Color(250,250,250,255))	
				end		
				if FunctionT[6] then
					if ent:GetClass() == "prop_physics" then		
						ent:SetMaterial("hejsmaterial/frame")
						ent:SetColor(Color(0,200,0))
					end					
				end
				
				if FunctionT[5] then
					local ply = ent
					if ply:IsPlayer() then
						if ply != LocalPlayer() then
							local PasT = {}
							local Position = (ply:GetPos()+Vector(0,0,80+(10+(LocalPlayer():GetPos():Distance(ply:GetPos()))/12) or 0)):ToScreen()
							
							local Cross = {{},{},{}}
							
							Cross[1]["x"] = -20+Position.x
							Cross[1]["y"] = 10+Position.y
							Cross[1]["u"] = 0 
							Cross[1]["v"] = 0
							Cross[2]["x"] = 20+Position.x
							Cross[2]["y"] = 10+Position.y
							Cross[2]["u"] = 1 
							Cross[2]["v"] = 0
							Cross[3]["x"] = 0+Position.x
							Cross[3]["y"] = 20+Position.y
							Cross[3]["u"] = 0
							Cross[3]["v"] = 0
							PasT[1] = Color(200-math.Clamp(ply:Health()*2,0,200),math.Clamp(ply:Health()*2,0,200),0)
							if !ply:Alive() then PasT[1] = Color(200,0,0) end
							draw.NoTexture()						
							surface.SetDrawColor( PasT[1])				
							surface.DrawPoly( Cross )	
							if ply:IsAdmin() then
								draw.SimpleText(ply:Name() ,"HFont-15",Position.x-40 ,Position.y , Color(0,200,255,255),1)	
							else
								draw.SimpleText(ply:Name() ,"HFont-15",Position.x-40 ,Position.y , Color(255,255,255,255),1)	
							end
							if FunctionT[9] then
								local Position = ( ply:GetPos() + Vector( 0,0,70 ) ):ToScreen()				
								local AimPosition = ( ply:GetEyeTrace().HitPos ):ToScreen()							
								surface.DrawLine( Position.x, Position.y, AimPosition.x , AimPosition.y )								
							end		
							
							--if math.Round(math.sin(CurTime()*300)*360) >= 360 then
								
								if IsValid(ply) then
									if !LocalPlayer():HSame(ply) then
										ply:SetMaterial("hejsmaterial/solid")				
									else
										ply:SetMaterial("")
										
									end								
								end
						
							--end
						end
					end
				end					
			end
		end		
	end
	

	
end)

local Friends = {}
table.insert(Friends,"STEAM_0:0:24363871")
table.insert(Friends,"STEAM_0:0:37636563")
table.insert(Friends,"STEAM_0:1:13419931")
table.insert(Friends,"STEAM_0:0:22065621")

local IgnoreWeps = {}
table.insert(IgnoreWeps,"gmod_tool")
table.insert(IgnoreWeps,"weapon_physcannon")
table.insert(IgnoreWeps,"weapon_physgun")
table.insert(IgnoreWeps,"weapon_keypadchecker")
table.insert(IgnoreWeps,"keys")
table.insert(IgnoreWeps,"pocket")
table.insert(IgnoreWeps,"lockpick")
--table.insert(IgnoreWeps,"keypad_cracker")


















hook.Add("Think","---xasd",function()
	local Data = {}
	Data["ply"] = LocalPlayer()
	Data["target"] = nil
	Data["maxdis"] = 0
	if Data["ply"]:Alive() then				
		for k,v in pairs(player.GetAll()) do	
			Data["target"] = v
			if IsValid(Data["target"]) and FunctionT[9] then
				if Data["ply"]:HSame(Data["target"]) then
					if Data["target"] != Data["ply"] then	
						if Data["target"]:Alive() then						
							if !table.HasValue(Friends,Data["target"]:SteamID()) then								 
								if IsValid(Data["ply"]:GetActiveWeapon()) then
									if !table.HasValue(IgnoreWeps,Data["ply"]:GetActiveWeapon():GetClass()) then
										if input.IsMouseDown(MOUSE_LEFT) then
											local targetheadpos,targetheadang = Data["target"]:GetBonePosition(Data["target"]:LookupBone("ValveBiped.Bip01_Head1"))	-Vector(0,0,(Data["ply"]:GetActiveWeapon().Primary.Recoil or 0))														
											Data["ply"]:SetEyeAngles((targetheadpos - Data["ply"]:GetShootPos()):Angle())												
										end		
									end									
								end
							end						
						end
					end		
				end
			end
		end
	end
end)






