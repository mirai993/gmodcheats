// hack 5/30/2014
// it does not have a name
surface.CreateFont("EspInfoText",{ font = "coolectiva rg", size = 14, weight = 700, shadow = false, antialias = true  })
RunConsoleCommand( "cl_csr_extra_muzzle_flash", "0" )
RunConsoleCommand( "cl_csr_css_nag", "0" )
RunConsoleCommand( "viewmodel_fov", 20 )
-- ConVars --
CreateClientConVar( "chams", 0, true, false )

local psaystring = "noob"	
local me,ply,eyepos = LocalPlayer()
 
local getall = player.GetAll
local traceline = util.TraceLine
 
local Vector,Angle = Vector,Angle
local math,input,next = math,input,next
 
local settings = {
[97] = true,
[98] = true,
[99] = false,
[100] = false}
 
if not firebullets then
        firebullets = debug.getregistry().Entity.FireBullets
end
 
local spreads = {["weapon_pistol"] = Vector(0.01,0.01,0),
["weapon_smg1"] = Vector(0.04362,0.04362,0),
["weapon_ar2"] = Vector(0.02618,0.02618,0)}
 
debug.getregistry().Entity.FireBullets = function(ent,bullet)
        local wepon = me:GetActiveWeapon()
        if not spreads[wepon:GetClass()] then
                spreads[wepon:GetClass()] = bullet.Spread
        end
        return firebullets(ent,bullet)
end
 
local function transform(a,x)
        local b = Vector(0,0,0)
        local m1,m2,m3 = x[1],x[2],x[3]
        local vec1 = Vector(m1[1],m1[2],m1[3])
        local vec2 = Vector(m2[1],m2[2],m2[3])
        local vec3 = Vector(m3[1],m3[2],m3[3])
        b.x = a:Dot(vec1) + m1[4]
        b.y = a:Dot(vec2) + m2[4]
        b.z = a:Dot(vec3) + m3[4]
        return b
end
 
local function position(v)
        local pos = v:LocalToWorld(v:OBBCenter())
        local bone = v:GetHitBoxBone(0,0)
        if not bone then return pos end
        if not v:GetBonePosition(bone) then return pos end
        local matrix = v:GetBoneMatrix(bone)
        if not matrix then return pos end
        local min,max = v:GetHitBoxBounds(0,0)
        matrix = matrix:ToTable()
        min = transform(min,matrix)
        max = transform(max,matrix)
        pos = (min + max) * 0.5
        return pos + ((v:GetVelocity() * 0.00672724) - (me:GetVelocity() * 0.0087775))
end
 
local function insight(v,vec)
        local tr = {}
        tr.start = me:GetShootPos()
        tr.endpos = vec
        tr.filter = {v,me}
        tr.mask = 1174421507
        local trace = traceline(tr)
        return trace.Fraction == 1
end
 
local function valid(v)
        if not input.IsKeyDown(85) then return false end
        if v == me then return false end
        if v:Health() < 1 then return false end
        if settings[98] and v:GetFriendStatus() == "friend" then return false end
        if settings[99] and v:Team() == me:Team() then return false end
        if v:InVehicle() then return end
        if not v:GetMoveType() == bit.bor(2,8) then return false end
        return true
end
 
local function targets()
        local dist1 = 2147483647
        for k,v in next, getall() do
                if not valid(v) then continue end
                local pos = position(v)
                if not insight(v,pos) then continue end
                local dist2 = (me:GetPos() - v:GetPos()):LengthSqr()
                if dist1 < dist2 then continue end
                dist1 = dist2
                ply = v
                eyepos = pos
        end
end
 
local function angles(c)
        ply = nil
        targets()
        if not ply then return end
        local ang = (eyepos - me:GetShootPos()):Angle()
        c:SetButtons(c:GetButtons() + 1)
        return ang
end
 
local function automatic()
        local wepon = me:GetActiveWeapon()
        if wepon == NULL then return false end
        if not wepon.Primary then return false end
        return not wepon.Primary.Automatic
end
 
local function hl2(wepon)
        if wepon == NULL then return false end
        local class = wepon:GetClass()
        if class == "weapon_pistol" then return true end
        if class == "weapon_357" then return true end
        if class == "weapon_smg1" then return true end
        if class == "weapon_ar2" then return true end
        return false
end
 
local function punch()
        local wepon = me:GetActiveWeapon()
        if wepon == NULL then return Angle() end
        if string.find(string.lower(wepon:GetClass()), "fas2") or hl2(wepon) then
                return me:GetPunchAngle()
        end
        return Angle()
end
 
local ms = Angle()
local sens = GetConVarNumber("sensitivity") * 0.022
local fire
 
local function aimbot(c)
        if c:CommandNumber() == 0 then return end
        ms = ms + Angle(c:GetMouseY() * sens,-c:GetMouseX() * sens,0)
        ms.p = math.Clamp(ms.p,-89,89)
        local ult = (angles(c) or ms) - punch()
        local wepon = me:GetActiveWeapon()
        ult.p = ult.p > 180 and ult.p - 360 or ult.p
        ult.r = 0
        c:SetViewAngles( ult )
        if c:KeyDown(1) and automatic() then
                if not fire then c:SetButtons(c:GetButtons() - 1) end
                fire = not fire
        end
        if me:GetMoveType() == 2 then
                local side = Vector(c:GetForwardMove(), c:GetSideMove(), 0)
                side = ((side:GetNormal()):Angle() + (c:GetViewAngles() - Angle(0,ms.y,0))):Forward() * side:Length()
                c:SetForwardMove(side.x)
                c:SetSideMove(side.y)
        end
end
hook.Add("CreateMove","aimbot",aimbot)
 
local function calc(ply,origin,angles)
        local view = {}
        view.angles = ms
        view.vm_angles = ms
        view.origin = origin
        view.fov = 130
        return view
end
hook.Add("CalcView","calc",calc)

local function No_Recoil()
    if me and me:GetActiveWeapon() and me:GetActiveWeapon().Primary then
        me:GetActiveWeapon().Primary.Recoil = 0
        me:GetActiveWeapon().Primary.Cone = 0
        me:GetActiveWeapon().Primary.Spread = 0
    end
end
hook.Add( "CreateMove", "No_Recoil", No_Recoil )

local change = {
[97] = false,
[98] = false,
[99] = false,
[100] = false}
 
local nametime,spamtime = 0,0
local query = debug.getregistry().Player.query



local w,h = ScrW()*0.01,ScrH()*0.5
local green,red = Color(0,255,0),Color(255,0,0) 
local function Text_Above_PLYS()
    draw.SimpleText("Change names - F5","DermaDefaultBold",w,h*0.8,settings[96] and green or red)
    draw.SimpleText("Draw ESP - F6","DermaDefaultBold",w,h*0.85,settings[97] and green or red)
    draw.SimpleText("Ignore friends - F7","DermaDefaultBold",w,h*0.9,settings[98] and green or red)
    draw.SimpleText("Ignore teammates - F8","DermaDefaultBold",w,h*0.95,settings[99] and green or red)
    draw.SimpleText("Chat spam - F9","DermaDefaultBold",w,h*1,settings[100] and green or red)
    local fags = player.GetAll()
    for k,v in pairs(fags) do
        if v != me and v:Alive() then
            local loc = v:LocalToWorld(v:OBBCenter()):ToScreen()
            local rank = v:GetNWString( "usergroup" )
            local hp = v:Health()
            local freind = v:GetFriendStatus() == "freind"
            local color = team.GetColor( v:Team() )
            draw.SimpleText( v:Name(), "EspInfoText", loc.x, loc.y, color, TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP  )
            if rank != "user" then
                    draw.SimpleText( "[" .. rank .. "]", "EspInfoText", loc.x, loc.y -10, color, TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP  )
            end
        end
    end
end
hook.Add( "HUDPaint", "Text_Above_PLYS", Text_Above_PLYS )



local function Chams()
if GetConVar( "chams"):GetInt() == 1 then
 local ply, fullbright = LocalPlayer(), false
 for k,v in pairs(player.GetAll()) do
  if IsValid(v) then
   cam.Start3D( EyePos(), EyeAngles() )
   cam.IgnoreZ( true )
   v:DrawModel()
   render.SuppressEngineLighting( false )
   cam.IgnoreZ( false )
   cam.End3D()
   end
  end
 end
end
hook.Add("RenderScreenspaceEffects", "Chams", Chams)
--[[



    XRay



--]]


--= Mats =--
local storedColors = {};
local storedMaterials = {};
local storedRenderModes = {};

-- Setting shit
local function setIfNonExistant(ent)
    if(!storedMaterials[ent] and !storedColors[ent]) then
        storedMaterials[ent] = ent:GetMaterial();
        storedColors[ent] = ent:GetColor();
        storedRenderModes[ent] = ent:GetRenderMode();
    end
end

local function XRay()
    for i,v in pairs( ents.GetAll() ) do
        if v:IsValid() then
            setIfNonExistant(v);
            if v:GetClass() == "prop_physics" then
                v:SetColor( Color(  113, 236, 30, 150 ) )
                v:SetMaterial( "debug/debugportals" )
                v:SetRenderMode(RENDERMODE_TRANSALPHA)
            end
            if v:GetClass() == "player" then
                v:SetColor( Color( 25, 133, 236, 155 ) )
                v:SetMaterial( "debug/debugportals" ) 
                v:SetRenderMode(RENDERMODE_TRANSALPHA)
            end
            if v:GetClass() == "gmod_button" then
                v:SetColor( Color( 220, 162, 24, 100 ) )
                v:SetMaterial( "debug/debugportals" )
                v:SetRenderMode(RENDERMODE_TRANSALPHA)
            end
            if v:GetClass() == "prop_door_rotating" then
                v:SetColor( Color( 255, 255, 255, 0 ) )
                    v:SetMaterial( "debug/debugportals" )
                v:SetRenderMode(RENDERMODE_TRANSALPHA)
	        end
            if v:GetClass() == "spawned_weapon" then
                v:SetColor( Color( 255, 255, 255, 255 ) )
                v:SetMaterial( "debug/debugportals" )
                v:SetRenderMode(RENDERMODE_TRANSALPHA)
            end
        end
    end
end


local function TurnOffXRay()
    for i,v in pairs(ents.GetAll()) do
        if(IsValid(v)) then
            if(storedMaterials[v]) then
                v:SetMaterial(storedMaterials[v]);
            end
            if(storedColors[v]) then
                v:SetColor(storedColors[v]);
            end
            if(storedRenderModes[v]) then
                v:SetRenderMode(storedRenderModes[v]);
            end
        end
    end
    storedColors = {};
    storedMaterials = {};
    storedRenderModes = {};
end


local xRayOn = false
concommand.Add("styles_xray", function(client, command, arguments)
    if(xRayOn) then
        hook.Remove( "RenderScene", "XRay" )
        TurnOffXRay();
        surface.PlaySound( "buttons/button19.wav" )
        xRayOn = false;
    else
        surface.PlaySound( "buttons/button1.wav" )
        hook.Add( "RenderScene", "XRay", XRay )
        xRayOn = true;
    end
end )



   


local function nerd()
	surface.SetDrawColor(team.GetColor( me:Team()))
	surface.DrawLine(ScrW() / 2 - 12, ScrH() / 2, ScrW() / 2 + 12 , ScrH() / 2)
	surface.DrawLine(ScrW() / 2 - 0, ScrH() / 2 - 5, ScrW() / 2 - 0 , ScrH() / 2 + 5)
end
hook.Add( "HUDPaint", "crosshair", nerd )



CreateClientConVar( "fag", 0, true, false )
CreateClientConVar( "fag", 0, true, false )


local me  = LocalPlayer()
----------------------misc---------------------------------

--Spectators--
local showSpectators = true
hook.Add("HUDPaint", "showspectators", function()
   if GetConVarNumber( "fag" ) <= 0 then return end
   local spectatePlayers = {}
   local x = 0
   for k,v in pairs(player.GetAll()) do
      if v:GetObserverTarget() == LocalPlayer() then 
         table.insert(spectatePlayers, v:Name())
			if not v.spectateNotified then
				chat.AddText( Color(0, 255, 255), v:Nick() .. " is spectating you!!");
            			timer.Simple(1, function()
                            surface.PlaySound("buttons/blip1.wav");
                        end)
				v.spectateNotified = true
			end
	else
		v.spectateNotified = false
	end
   end
   local textLength = surface.GetTextSize(table.concat(spectatePlayers) ) / 3
   draw.RoundedBox(1, ScrW() - 180, ScrH() - ScrH() + 15, 150, 30 + textLength, Color(0,0,0,150))
   draw.SimpleText("Spectators", "Default", ScrW() - 175, ScrH() - ScrH() + 17, Color(0, 0, 0, 150))
   draw.SimpleText("Spectators", "Default", ScrW() - 175, ScrH() - ScrH() + 16, Color(0, 255, 0))

   for k, v in pairs(spectatePlayers) do
        draw.SimpleText(v, "Default", ScrW() - 175, ScrH() - ScrH() + 35 + x, Color(255, 255, 255, 255))
        x = x + 15



			end
   
   end)
   

local psaystring = "noob"

local strings = {
"noob",
"fag"}

 
local function think()
        for i=96,100 do
                if input.IsKeyDown(i) and change[i] then
                        change[i] = false
                        settings[i] = not settings[i]
                end
                if not input.IsKeyDown(i) then change[i] = true end
        end
        if settings[96] and nametime < RealTime() then
                for k,v in next, getall() do
                        if string.find(me:Name(),v:Name()) then continue end
                        if string.len(v:Name()) == 32 then continue end
                        if string.find(me:Name(),v:Name()) == nil then
                                me:ConCommand("hs_namechange "..v:Name().." ")
                                break
                        end
                end
                nametime = RealTime() + GetConVarNumber("sv_namechange_cooldown_seconds")
        end
        if settings[100] then
                if query and query(me,"ulx psay") then
                        if spamtime > RealTime() then return end
                        for k,v in next, getall() do
                                if v == me then continue end
                                me:ConCommand("ulx psay \""..v:Name().."\" "..psaystring)
                        end
                        spamtime = RealTime() + 0.1
                else
                        if GAMEMODE.Name == "DarkRP" then
                                me:ConCommand("say /ooc "..strings[math.random(#strings)])
                        else
                                me:ConCommand("say "..strings[math.random(#strings)])
                        end
                end
        end
end
hook.Add("Think","thinkHACKER",think)


concommand.Add( "+dance", function()
     timer.Create("animating", 2, 0, function() RunConsoleCommand("_DarkRP_DoAnimation", "1616") end)
end)

concommand.Add( "-dance", function()
    timer.Destroy( "animating")
end)