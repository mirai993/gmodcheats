// Global variables 
local GlobalVars = { CurTime = 0, FrameTime = 0, TickCount = 0, LastCommand = 0, ServerFrame = 0, Online = 0, TimeString = "" }

GlobalVars.HostName     = GetHostName()
GlobalVars.HostAddress  = game.GetIPAddress()
GlobalVars.HostMap      = game.GetMap()
GlobalVars.TickInterval = engine_lib.TickInterval()
GlobalVars.TickRate     = math_Floor( 1 / GlobalVars.TickInterval )

// Console variables
local ConsoleVars = {}

ConsoleVars.DefaultVars = {
    "sv_maxusrcmdprocessticks", "sv_namechange_cooldown_seconds", "name", 
    "sv_maxvelocity", "sv_airaccelerate", "sv_accelerate", "sv_friction", "sv_stopspeed", "sv_gravity",
    "r_aspectratio", "cl_forwardspeed", "cl_sidespeed", "climbswep2_maxjumps",
    "sensitivity", "m_yaw", "m_pitch",
}

function ConsoleVars.List( var, isstr )
    local Obj = GetConsoleVar( var )

    if not Obj then
        ConsoleVars[ var ] = false
        return
    end

    ConsoleVars[ var ] = {
        var = Methods.ConVar[ "Get" .. ( isstr and "String" or "Float" ) ]( Obj ),
        flags = Methods.ConVar.GetFlags( Obj )
    }
end

function ConsoleVars.Force( var, set )
    ded.ConVarSetFlags( var, 0 )
        RunCommand( var, ToString( set ) )
    ded.ConVarSetFlags( var, ConsoleVars[ var ].flags )
end

function ConsoleVars.Update()
    for i = 1, #ConsoleVars.DefaultVars do
        ConsoleVars.List( ConsoleVars.DefaultVars[ i ] )
    end

    ConsoleVars.List( "sv_skyname", true )
end

ConsoleVars.Update()

// Jeeeeezyyyyy math ( extended well and actually true, approved by Stephie Hawking )
local MathEx = {}

function MathEx.Average( nums )
    local sum = 0

    for i = 1, #nums do
        sum = sum + nums[ i ]
    end

    return sum / #nums
end

function MathEx.Remap( val, inmax, outmax )
    return math_Ceil( val / inmax * outmax )
end

function MathEx.TimeToTicks( time )
    return math_Floor( 0.5 + time / GlobalVars.TickInterval )
end

function MathEx.TicksToTime( ticks )
    return GlobalVars.TickInterval * ticks
end

function MathEx.RoundToTick( Time )
    return MathEx.TicksToTime( MathEx.TimeToTicks( Time ) )
end

// Vector extension 
local AngleVec = { TempAngle = Angle(), TempVector = Vector(), NullVec = Vector(), PositiveVec = Vector( 1, 1, 1 ) }

function AngleVec.Abs( vec )
    vec.x = math_Floor( vec.x )
    vec.y = math_Floor( vec.y )
    vec.z = math_Floor( vec.z )

    return vec 
end

function AngleVec.SumString( vec )
    return string_format( VectorPattern, vec.x, vec.y, vec.z )
end

function AngleVec.CalcDir( start, finish )
    AngleVec.TempAngle = Methods.Vector.Angle( start - finish )
    Methods.Angle.Normalize( AngleVec.TempAngle )

    return AngleVec.TempAngle
end

function AngleVec.AngToPixels( start, finish )
    local Dist = start - finish
    Methods.Angle.Normalize( Dist )

    return Dist.y / ( ConsoleVars.m_yaw.var * ConsoleVars.sensitivity.var ), Dist.x / ( ConsoleVars.m_pitch.var * ConsoleVars.sensitivity.var )
end

// Mouse data 
local Mouse = { x = 0, y = 0 }

function Mouse.InRect( x, y, w, h, focus )
    if focus and not Mouse.InFocusedFrame then
        return false 
    end 

    w = x + w 
    h = y + h 

    return ( Mouse.x >= x and Mouse.x <= w ) and ( Mouse.y >= y and Mouse.y <= h )
end

function Mouse.PixelsToAngles( x, y )
    AngleVec.TempAngle.x = x * ( ConsoleVars.m_yaw.var * ConsoleVars.sensitivity.var )
    AngleVec.TempAngle.y = y * ( ConsoleVars.m_pitch.var * ConsoleVars.sensitivity.var )
    AngleVec.TempAngle.r = 0
    Methods.Angle.Normalize( AngleVec.TempAngle )

    return AngleVec.TempAngle
end

// Screen data 
local ScrEx = { Width = ScrW(), Height = ScrH(), Get = {}, Scaled = {} }
ScrEx.CenterX = math_Floor( ScrEx.Width * 0.5 )
ScrEx.CenterY = math_Floor( ScrEx.Height * 0.5 )

ScrEx.Fonts = {
    { "Veranda", { font = "Verdana", size = 12, antialias = false, outline = true }, 12 },
    { "TabFont", { font = "Verdana", size = 16, weight = 100 }, 16 },
    { "MenuFont", { font = "Verdana", size = 15, weight = 350 }, 16 },
    { "LogoText", { font = "Verdana", size = 42, weight = 500 }, 42 },
}

ScrEx.Default = {
    FrameWidth  = 782,
    FrameHeight = 856,
}

function ScrEx.Adjust( var )
    return var * ( ScrEx.Height / 1024 )
end

function ScrEx.Scale( var )
    if IsNumber( var ) then
        local it = var 

        var = function() 
            return ScrEx.Adjust( it ) 
        end
    end

    local Index = #ScrEx.Scaled + 1
    ScrEx.Scaled[ Index ] = { var(), var }

    return ScrEx.Scaled[ Index ][ 1 ]
end

function ScrEx.Update()
    ScrEx.Width   = ScrW() 
    ScrEx.Height  = ScrH() 
    ScrEx.CenterX = math_Floor( ScrEx.Width * 0.5 )
    ScrEx.CenterY = math_Floor( ScrEx.Height * 0.5 ) 

    for i = 1, #ScrEx.Scaled do
        ScrEx.Scaled[ i ][ 1 ] = ScrEx.Scaled[ i ][ 2 ]()
    end

    for i = 1, #ScrEx.Fonts do
        ScrEx.Fonts[ i ][ 2 ].size = ScrEx.Adjust( ScrEx.Fonts[ i ][ 3 ] )
        surface_CreateFont( ScrEx.Fonts[ i ][ 1 ], ScrEx.Fonts[ i ][ 2 ] )
    end

    for Key, Val in Pairs( ScrEx.Default ) do
        ScrEx.Get[ Key ] = ScrEx.Scale( Val )
    end
end

ScrEx.Update()

// Insanely unholy color extension 
local ColorEx = { Cache = {}, Trans = {}, SinSpeed = 128, SinMin = 128 }

function ColorEx.Update( r, g, b, a, index )
    index = index or #ColorEx.Cache + 1
    a = a or 255

    ColorEx.Cache[ index ] = {  
        r = r, g = g, b = b, a = a,
        x = r / 255, y = g / 255, z = b / 255, q = a / 255, 
    }

    return ColorEx.Cache[ index ] 
end

function ColorEx.UpdateTrans( fr, sr, fg, sg, fb, sb, s, a, index )
    index = index or #ColorEx.Trans + 1
    a = a or 255
    s = s or 1

    ColorEx.Trans[ index ] = {
        fr = fr, sr = sr, 
        fg = fg, sg = sg, 
        fb = fb, sb = sb,
        r = 0, g = 0, b = 0,
        x = 0, y = 0, z = 0,
        a = a, q = a / 255,
        s = s
    }

    return ColorEx.Trans[ index ], index
end

function ColorEx.Transit( index )
    local Col = ColorEx.Trans[ index ]
    local Sin = math_Abs( math_Sin( GlobalVars.CurTime * Col.s ) )

    Col.r = Col.fr * ( 1 - Sin ) + Col.sr * Sin
    Col.g = Col.fg * ( 1 - Sin ) + Col.sg * Sin
    Col.b = Col.fb * ( 1 - Sin ) + Col.sb * Sin

    Col.x = Col.r / 255
    Col.y = Col.g / 255
    Col.z = Col.b / 255
end

function ColorEx.GetVector( index, trans )
    local T = trans and ColorEx.Trans[ index ] or ColorEx.Cache[ index ]
    return T.x, T.y, T.z
end 

function ColorEx.GetRGBA( index, trans )
    local T = trans and ColorEx.Trans[ index ] or ColorEx.Cache[ index ]
    return T.r, T.g, T.b, T.a
end 

ColorEx.Rainbow = ColorEx.Update( 255, 255, 255, 255 )
ColorEx.LastTeam = ColorEx.Update( 255, 255, 255, 255 )

// Input extension 
local InputEx = { WasDown = {}, IsDown = {}, IsPressed = {} }

for i = 1, 113 do 
    InputEx.WasDown[ i ] = false 
    InputEx.IsDown[ i ] = false 
    InputEx.IsPressed[ i ] = false 
end

function InputEx.IsKeyDown( key )
    if key >= 107 then 
        return input_IsMouseDown( key ) 
    end

    return input_IsKeyDown( key )
end

function InputEx.IsBindDown( key )
    if not input_LookupBinding( key ) then 
        return false 
    end 

    return input_IsKeyDown( input_GetKeyCode( input_LookupBinding( key ) ) ) 
end

// Context data 
local Context = { x = 0, y = 0, w = 0, h = 0, g = 0, str = "", b = false }


// Draw extension 
local DrawEx = { SizeData = {}, Output = {}, Font = "" }

function DrawEx.SetFont( font ) 
    if not DrawEx.SizeData[ font ] then
        DrawEx.SizeData[ font ] = {}
    end

    DrawEx.Font = font 
    surface_SetFont( font )
end

function DrawEx.GetTextSize( str )
    if DrawEx.SizeData[ DrawEx.Font ][ str ] then
        DrawEx.Output = DrawEx.SizeData[ DrawEx.Font ][ str ]
        return DrawEx.Output.x, DrawEx.Output.y 
    end

    local tw, th = surface_GetTextSize( str )

    DrawEx.SizeData[ DrawEx.Font ][ str ] = { x = tw, y = th }

    return tw, th 
end 

function DrawEx.DrawText( str, x, y )
    surface_SetTextPos( x, y )
    surface_DrawText( str )
end

// Material system 
local MaterialEx = {}

function MaterialEx.Cache( str )
    if MaterialEx[ str ] then 
        return MaterialEx[ str ]
    end

    MaterialEx[ str ] = Material( str )

    return MaterialEx[ str ]
end

// Table extension 
local TableEx = {}

function TableEx.ListNumeric( tbl, func )
    for i = 1, #tbl do
        func( i )
    end
end


// Settings 

ColorEx.UpdateTrans( 225, 128, 255, 128, 128, 255, 1, 255 )
ColorEx.UpdateTrans( 255, 0, 0, 0, 0, 255, 1, 255 )

local Settings = { 
    Vars = {
        Var = false,
        Int = 10,
        Int1 = 5,
        Int2 = 15,
        CVar = 1
    }, 
    Colors = {
        Var = { ColorEx.Update( 255, 65, 65, 255 ), 1, 1 },
        Var1 = { ColorEx.Update( 65, 255, 65, 255 ), 1, 1 },
        Var2 = { ColorEx.Update( 65, 65, 255, 255 ), 1, 1 },
        Var3 = { ColorEx.Update( 255, 65, 65, 255 ), 2, 1 },

    }, 
    TransColors = {
        "Penis", "Police"
    }, 
    Binds = {
        { State = false, Trapping = false, Show = true, Key = -1, Mode = 1 },
    },
    Theme = {
        SolidBackground = { ColorEx.Update( 16, 16, 16, 255 ), 1, 1 },
        FadeBackground  = { ColorEx.Update( 24, 24, 24, 255 ), 1, 1 },
        SolidHeader     = { ColorEx.Update( 32, 32, 32, 255 ), 1, 1 },

        ActiveTexture   = { ColorEx.Update( 64, 64, 64, 255 ), 1, 1 },
        HoveredTexture  = { ColorEx.Update( 48, 48, 48, 255 ), 1, 1 },
        FadeTexture     = { ColorEx.Update( 40, 40, 40, 255 ), 1, 1 },

        SolidOutline    = { ColorEx.Update( 72, 72, 72, 255 ), 1, 1 },
        FadeOutline     = { ColorEx.Update( 86, 86, 86, 255 ), 1, 1 },

        SolidCheckHover = { ColorEx.Update( 36, 36, 36, 255 ), 1, 1 },

        ActiveText      = { ColorEx.Update( 132, 132, 132, 255 ), 1, 1 },
        HoveredText     = { ColorEx.Update( 116, 116, 116, 255 ), 1, 1 },
        NormalText      = { ColorEx.Update( 96, 96, 96, 255 ), 1, 1 },
        HighlightedText = { ColorEx.Update( 86, 86, 86, 255 ), 1, 1 },
        FadeText        = { ColorEx.Update( 74, 74, 74, 255 ), 1, 1 },
    }

}


Settings.DynamicColors = {
    [ 2 ] = function( i ) return ColorEx.Rainbow end,
    [ 3 ] = function( i ) return ColorEx.LastTeam end,
    [ 4 ] = function( i ) return ColorEx.Trans[ i ] end,
}

function Settings.GetColor( var )
    local tbl = var[ 1 ]

    if Settings.DynamicColors[ var[ 2 ] ] then
        tbl = Settings.DynamicColors[ var[ 2 ] ]( var[ 3 ] )
    end

    return tbl.r, tbl.g, tbl.b, tbl.a
end

function Settings.GetVector( var )
    local tbl = var[ 1 ]

    if Settings.DynamicColors[ var[ 2 ] ] then
        tbl = Settings.DynamicColors[ var[ 2 ] ]( var[ 3 ] )
    end

    return tbl.x, tbl.y, tbl.z
end

// User interface 
local InterfaceEx = {}
InterfaceEx.IsHoveringPanel = false
InterfaceEx.InteractActive = false
InterfaceEx.Frames = {}
InterfaceEx.ShowMenu = false
InterfaceEx.ShowHome = false
InterfaceEx.ThemeBoxes = {}
InterfaceEx.ThemeBoxW  = 252

InterfaceEx.Hint = false

function InterfaceEx.StartThemeBox( StrName, SubTabs )
    if not InterfaceEx.ThemeBoxes[ Context.g ] then
        InterfaceEx.ThemeBoxes[ Context.g ] = 0
    end

    local Tw, Th = DrawEx.GetTextSize( StrName )

    surface_SetDrawColor( Settings.GetColor( Settings.Theme.SolidHeader ) )
    surface_DrawRect( Context.x, Context.y, InterfaceEx.ThemeBoxW, 20 )

    surface_SetDrawColor( Settings.GetColor( Settings.Theme.SolidOutline ) )
    surface_DrawOutlinedRect( Context.x, Context.y, InterfaceEx.ThemeBoxW, InterfaceEx.ThemeBoxes[ Context.g ] )
    surface_DrawRect( Context.x, Context.y + 20, InterfaceEx.ThemeBoxW, 1 )

    if SubTabs then
        SubTabs = InterfaceEx.SubTabs[ SubTabs ]

        local inrect 
        local x = Context.x
        local w = math_Floor( InterfaceEx.ThemeBoxW / #SubTabs.Tabs )

        for i = 1, #SubTabs.Tabs do
            Tw, Th = DrawEx.GetTextSize( SubTabs.Tabs[ i ] )
            inrect = Mouse.InRect( x + w * ( i - 1 ), Context.y, w, 20 )

            surface_DrawRect( x + w * ( i - 1 ), Context.y, 1, 21 )
            surface_SetTextColor( Settings.GetColor( Settings.Theme[ SubTabs.Active == i and "NormalText" or "FadeText" ] ) ) 
            surface_SetTextPos( ( x + w * ( i - 1 ) ) + w / 2 - Tw / 2, Context.y + 2 )
            surface_DrawText( SubTabs.Tabs[ i ] )

            if inrect and InputEx.IsPressed[ MOUSE_LEFT ] then
                SubTabs.Active = i
            end
        end

        Context.x = Context.x + 4
        Context.y = Context.y + Th + 8
        Context.h = Th + 6

        SubTabs.Draw[ SubTabs.Active ]( Context.x, Context.y )
    else
        surface_SetTextColor( Settings.GetColor( Settings.Theme.NormalText ) ) 
        surface_SetTextPos( Context.x + InterfaceEx.ThemeBoxW / 2 - Tw / 2, Context.y + 2 )
        surface_DrawText( StrName )

        Context.x = Context.x + 4
        Context.y = Context.y + Th + 8
        Context.h = Th + 6
    end
end

function InterfaceEx.EndThemeBox()
    InterfaceEx.ThemeBoxes[ Context.g ] = Context.h + 3

    Context.g = Context.g + 1
    Context.y = Context.y + 4
    Context.x = Context.x - 4 
end

function InterfaceEx.Spacer()
    surface_SetDrawColor( Settings.GetColor( Settings.Theme.SolidOutline ) )
    surface_DrawRect( Context.x - 4, Context.y, InterfaceEx.ThemeBoxW, 1 )

    Context.y = Context.y + 4
    Context.h = Context.h + 4
end


InterfaceEx.BindVars = false
InterfaceEx.ColorVars = false

InterfaceEx.ElementData = {}

// Simple hint panel 
function InterfaceEx.DisplayHint( Str )
    local Frame = InterfaceEx.FindFrame( "Hint" )
    local Tw, Th = DrawEx.GetTextSize( Str )

    InterfaceEx.Hint = Str

    Frame.w = Tw + 16
    Frame.h = Th + 8

    Frame.x = Mouse.x
    Frame.y = Mouse.y + 24

    if Frame.x + Frame.w > ScrEx.Width then
        Frame.x = Frame.x - Frame.w
    end

    if Frame.y + Frame.h > ScrEx.Height then
        Frame.y = Frame.y - Frame.h * 2
    end

    Frame.LastInteract = GlobalVars.CurTime + 2
end

InterfaceEx.ActiveWidth = InterfaceEx.ThemeBoxW - 8

// Checkbox
InterfaceEx.ShouldExtend = {}
InterfaceEx.ExtenderID = 0
InterfaceEx.CheckboxSize = 14
InterfaceEx.CheckboxMark = 10

function InterfaceEx.Checkbox( Str, Var, Hint, Tbl, Override, PostDraw )
    Tbl = Tbl or Settings.Vars

    local IsActive = Tbl[ Var ]
    local InRect = Mouse.InRect( Context.x, Context.y, InterfaceEx.ActiveWidth - 32, InterfaceEx.CheckboxSize, true )

    surface_SetDrawColor( Settings.GetColor( Settings.Theme.SolidOutline ) )
    surface_DrawOutlinedRect( Context.x, Context.y, InterfaceEx.CheckboxSize, InterfaceEx.CheckboxSize )

    if IsActive or InRect then
        surface_SetDrawColor( Settings.GetColor( Settings.Theme[ IsActive and "SolidOutline" or "SolidCheckHover" ] ) )
        surface_DrawRect( Context.x + 2, Context.y + 2, InterfaceEx.CheckboxMark, InterfaceEx.CheckboxMark )
    end
    
    surface_SetTextColor( Settings.GetColor( Settings.Theme[ IsActive and "NormalText" or InRect and "HighlightedText" or "FadeText" ] ) ) 
    surface_SetTextPos( Context.x + InterfaceEx.CheckboxSize + 2, Context.y - 1 )
    surface_DrawText( Str )

    if InRect then
        if Hint then
            InterfaceEx.DisplayHint( Hint )
        end

        if InputEx.IsPressed[ MOUSE_LEFT ] then
            Tbl[ Var ] = not Tbl[ Var ]

            if Override then 
                Override( Tbl[ Var ] ) 
            end 
        end

        InterfaceEx.InteractActive = true
    end

    local Extended = false
    if PostDraw then
        InRect = Mouse.InRect( Context.x + InterfaceEx.ActiveWidth - 32, Context.y, 32, InterfaceEx.CheckboxSize, true )

        surface_SetTextPos( Context.x + InterfaceEx.ActiveWidth - 14, Context.y - 1 )
        surface_DrawText( InterfaceEx.ShouldExtend[ InterfaceEx.ExtenderID ] and "▲" or "▼" )

        if InRect then
            if InputEx.IsPressed[ MOUSE_LEFT ] then
                InterfaceEx.ShouldExtend[ InterfaceEx.ExtenderID ] = not InterfaceEx.ShouldExtend[ InterfaceEx.ExtenderID ]
            end

            InterfaceEx.InteractActive = true
        end

        Extended = InterfaceEx.ShouldExtend[ InterfaceEx.ExtenderID ]
        InterfaceEx.ExtenderID = InterfaceEx.ExtenderID + 1
    end

    Context.y = Context.y + InterfaceEx.CheckboxSize + 3
    Context.h = Context.h + InterfaceEx.CheckboxSize + 3

    if Extended and PostDraw then
        InterfaceEx.Spacer()
        PostDraw( Context.x, Context.y )
        InterfaceEx.Spacer()
    end
end 

// Button
function InterfaceEx.Button( Str, Func, Hint )
    local InRect = Mouse.InRect( Context.x, Context.y, InterfaceEx.ActiveWidth, 20 )
    local Tw, Th = DrawEx.GetTextSize( Str )

    surface_SetDrawColor( Settings.GetColor( Settings.Theme.SolidOutline ) )
    surface_DrawOutlinedRect( Context.x, Context.y, InterfaceEx.ActiveWidth, 20 )

    surface_SetTextColor( Settings.GetColor( Settings.Theme[ ( InputEx.IsDown[ MOUSE_LEFT ] and InRect ) and "NormalText" or InRect and "HighlightedText" or "FadeText" ] ) ) 
    surface_SetTextPos( Context.x + InterfaceEx.ActiveWidth / 2 - Tw / 2, Context.y + 2 )
    surface_DrawText( Str )

    if InRect then
        if Hint then
            InterfaceEx.DisplayHint( Hint )
        end

        if InputEx.IsPressed[ MOUSE_LEFT ] then
            Func()
        end

        InterfaceEx.InteractActive = true
    end

    Context.y = Context.y + 23
    Context.h = Context.h + 23
end

function InterfaceEx.MultiButton( Data )
    surface_SetDrawColor( Settings.GetColor( Settings.Theme.SolidOutline ) )
    surface_DrawOutlinedRect( Context.x, Context.y, InterfaceEx.ActiveWidth, 20 ) 

    local Width = math_Ceil( InterfaceEx.ActiveWidth / #Data )
    local Shift = Context.x
    local CData, InRect, Tw, Th
    for i = 1, #Data do
        CData = Data[ i ]
        InRect = Mouse.InRect( Shift, Context.y, Width, 20 )
        Tw, Th = DrawEx.GetTextSize( CData.Str )
        
        if i < #Data then
            surface_DrawRect( Shift + Width, Context.y, 1, 20 ) 
        end

        surface_SetTextColor( Settings.GetColor( Settings.Theme[ ( InputEx.IsDown[ MOUSE_LEFT ] and InRect ) and "NormalText" or InRect and "HighlightedText" or "FadeText" ] ) ) 
        surface_SetTextPos( Shift + Width / 2 - Tw / 2, Context.y + 2 )
        surface_DrawText( CData.Str )

        if InRect then
            if CData.Hint then
                InterfaceEx.DisplayHint( CData.Hint )
            end
    
            if InputEx.IsPressed[ MOUSE_LEFT ] then
                CData.Func()
            end
    
            InterfaceEx.InteractActive = true
        end

        Shift = Shift + Width
    end

    Context.y = Context.y + 23
    Context.h = Context.h + 23
end

// Sliders  
function InterfaceEx.Slider( Str, Symbol, Var, Hint, Tbl, Dec, Min, Max, Override )
    Tbl = Tbl or Settings.Vars

    local Current   = Tbl[ Var ]
    local SymbolStr = string_format( "%G %s", Current, Symbol )
    local Tw, Th    = DrawEx.GetTextSize( SymbolStr )

    local MouseInRect = Mouse.InRect( Context.x, Context.y, InterfaceEx.ThemeBoxW, 30 )

    surface_SetTextColor( Settings.GetColor( Settings.Theme[ MouseInRect and "NormalText" or "FadeText" ] ) )

    surface_SetTextPos( Context.x, Context.y )
    surface_DrawText( Str )

    surface_SetTextPos( Context.x + InterfaceEx.ThemeBoxW - 9 - Tw, Context.y )
    surface_DrawText( SymbolStr )

    surface_SetDrawColor( Settings.GetColor( Settings.Theme.SolidOutline ) )
    surface_DrawOutlinedRect( Context.x, Context.y + 16, InterfaceEx.ThemeBoxW - 9, 10 )
    surface_DrawRect( Context.x + 2, Context.y + 18, ( ( Current - Min ) / ( Max - Min ) ) * ( InterfaceEx.ThemeBoxW - 13 ), 6 )

    if MouseInRect then
        if Hint then
            InterfaceEx.DisplayHint( Hint )
        end

        if InputEx.IsDown[ MOUSE_LEFT ] then
            Tbl[ Var ] = math_Round( Min + ( ( Mouse.x - Context.x ) / ( Context.x + InterfaceEx.ThemeBoxW - 9 - Context.x ) ) * ( Max - Min ), Dec )
            Tbl[ Var ] = math_Clamp( Tbl[ Var ], Min, Max )

            if Override then
                Override( Tbl[ Var ] )
            end
        end
        
        InterfaceEx.InteractActive = true
    end

    Context.y = Context.y + 30
    Context.h = Context.h + 30
end

function InterfaceEx.CenteredSlider( Str, Symbol, Var, Hint, Tbl, Dec, Min, Max, Override )
    Tbl = Tbl or Settings.Vars

    local Current   = Tbl[ Var ]
    local SymbolStr = string_format( "%G %s", Current, Symbol )
    local Tw, Th    = DrawEx.GetTextSize( SymbolStr )

    local HalfLen   = math_Ceil( ( InterfaceEx.ThemeBoxW - 13 ) / 2 )
    local Length    = ( ( math_Abs( Current ) ) / ( ( Current < 0 ) and math_Abs( Min ) or Max ) ) * HalfLen
    local Start     = ( Current < 0 ) and Context.x + 2 + HalfLen - Length or Context.x + 1 + HalfLen
    
    local MouseInRect = Mouse.InRect( Context.x, Context.y, InterfaceEx.ThemeBoxW, 30 )

    surface_SetTextColor( Settings.GetColor( Settings.Theme[ MouseInRect and "NormalText" or "FadeText" ] ) )

    surface_SetTextPos( Context.x, Context.y )
    surface_DrawText( Str )

    surface_SetTextPos( Context.x + InterfaceEx.ThemeBoxW - 9 - Tw, Context.y )
    surface_DrawText( SymbolStr )

    surface_SetDrawColor( Settings.GetColor( Settings.Theme.SolidOutline ) )
    surface_DrawOutlinedRect( Context.x, Context.y + 16, InterfaceEx.ThemeBoxW - 9, 10 )
    surface_DrawRect( Start, Context.y + 18, Length, 6 )

    if MouseInRect then
        if Hint then
            InterfaceEx.DisplayHint( Hint )
        end

        if InputEx.IsDown[ MOUSE_LEFT ] then
            Tbl[ Var ] = math_Round( Min + ( ( Mouse.x - Context.x ) / ( Context.x + InterfaceEx.ThemeBoxW - 9 - Context.x ) ) * ( Max - Min ), Dec )
            Tbl[ Var ] = math_Clamp( Tbl[ Var ], Min, Max )

            if Override then
                Override( Tbl[ Var ] )
            end
        end
        
        InterfaceEx.InteractActive = true
    end

    Context.y = Context.y + 30
    Context.h = Context.h + 30
end

function InterfaceEx.DoubleSlider( Str, Symbol, First, Second, Hint, Tbl, Dec, Min, Max, Override )
    Tbl = Tbl or Settings.Vars

    local FirstVar, SecondVar = Tbl[ First ], Tbl[ Second ]
    local SymbolStr = string_format( "%G/%G %s", FirstVar, SecondVar, Symbol )
    local Tw, Th    = DrawEx.GetTextSize( SymbolStr )

    local MouseInRect = Mouse.InRect( Context.x, Context.y, InterfaceEx.ThemeBoxW, 30 )

    surface_SetTextColor( Settings.GetColor( Settings.Theme[ MouseInRect and "NormalText" or "FadeText" ] ) )

    surface_SetTextPos( Context.x, Context.y )
    surface_DrawText( Str )

    surface_SetTextPos( Context.x + InterfaceEx.ThemeBoxW - 9 - Tw, Context.y )
    surface_DrawText( SymbolStr )

    local Ratio  = Max - Min
    local Width  = InterfaceEx.ThemeBoxW - 13
    local Start  = Context.x + 2 + ( ( FirstVar - Min ) / Ratio ) * Width
    local Length = Context.x + 2 + ( ( SecondVar - Min ) / Ratio ) * Width

    if FirstVar != Min then
        Length = Length + 1
    end

    surface_SetDrawColor( Settings.GetColor( Settings.Theme.SolidOutline ) )
    surface_DrawOutlinedRect( Context.x, Context.y + 16, InterfaceEx.ThemeBoxW - 9, 10 )
    surface_DrawRect( Start, Context.y + 18, Length - Start, 6 )

    if MouseInRect then 
        if Hint then
            InterfaceEx.DisplayHint( Hint )
        end

        if InputEx.IsDown[ MOUSE_LEFT ] then 
            Tbl[ First ] = math_Round( Min + ( ( Mouse.x - Context.x ) / ( Context.x + InterfaceEx.ThemeBoxW - 9 - Context.x ) ) * ( Max - Min ), Dec )
            Tbl[ First ] = math_Clamp( Tbl[ First ], Min, Tbl[ Second ] + Dec )

            if Override then
                Override( Tbl[ First ] )
            end
        elseif InputEx.IsDown[ MOUSE_RIGHT ] then
            Tbl[ Second ] = math_Round( Min + ( ( Mouse.x - Context.x ) / ( Context.x + InterfaceEx.ThemeBoxW - 9 - Context.x ) ) * ( Max - Min ), Dec )
            Tbl[ Second ] = math_Clamp( Tbl[ Second ], Tbl[ First ] + Dec, Max )

            if Override then
                Override( Tbl[ Second ] )
            end
        end

        InterfaceEx.InteractActive = true
    end

    Context.y = Context.y + 30
    Context.h = Context.h + 30
end

// Combo box
InterfaceEx.ComboVars = false

function InterfaceEx.ComboBox( Str, Var, Hint, Options, Multi, Tbl ) 
    Tbl = Tbl or Settings.Vars

    local MouseInRect = Mouse.InRect( Context.x, Context.y + 16, InterfaceEx.ThemeBoxW - 9, 20 )
    local MultiStr = "None"

    surface_SetTextColor( Settings.GetColor( Settings.Theme[ MouseInRect and "NormalText" or "FadeText" ] ) )

    surface_SetTextPos( Context.x, Context.y )
    surface_DrawText( Str )

    surface_SetDrawColor( Settings.GetColor( Settings.Theme.SolidOutline ) )
    surface_DrawOutlinedRect( Context.x, Context.y + 16, InterfaceEx.ThemeBoxW - 9, 20 )
    surface_DrawRect( Context.x + InterfaceEx.ThemeBoxW - 29, Context.y + 16, 1, 20 )

    if Multi then
        for i = 1, #Options do
            if not Tbl[ Var .. Options[ i ] ] then continue end 
            local Sep = ", "

            if MultiStr == "None" then 
                MultiStr = "" 
                Sep = ""
            end

            MultiStr = MultiStr .. Sep .. Options[ i ]
        end
    end 

    surface_SetTextPos( Context.x + 4, Context.y + 18 )
    surface_DrawText( Multi and string_sub( MultiStr, 1, 34 ) or Options[ Tbl[ Var ] ] )

    surface_SetTextPos( Context.x + InterfaceEx.ThemeBoxW - 26, Context.y + 18 )
    surface_DrawText( "▼" )

    if MouseInRect then 
        if Hint then
            InterfaceEx.DisplayHint( Hint )
        end

        if InputEx.IsPressed[ MOUSE_LEFT ] then
            InterfaceEx.FindFrame( "Menu" ).LastInteract = GlobalVars.CurTime - 1

            local SubFrame = InterfaceEx.FindFrame( "Combo" )

            InterfaceEx.ComboVars = { Var, Options, Multi, Tbl }

            SubFrame.x = Context.x
            SubFrame.y = Context.y + 35
            SubFrame.h = ( #Options * 16 ) + 2
            SubFrame.w = InterfaceEx.ThemeBoxW - 9
    
            SubFrame.LastInteract = GlobalVars.CurTime
        end

        InterfaceEx.InteractActive = true
    end

    Context.y = Context.y + 40
    Context.h = Context.h + 40
end

function InterfaceEx.ComboSelector( Str, Var, Hint, Options, Tbl )
    Tbl = Tbl or Settings.Vars

    local MouseInRect = Mouse.InRect( Context.x, Context.y + 16, InterfaceEx.ThemeBoxW - 9, 20 )
    local Tw, Th = DrawEx.GetTextSize( Options[ Tbl[ Var ] ] )

    surface_SetTextColor( Settings.GetColor( Settings.Theme[ MouseInRect and "NormalText" or "FadeText" ] ) )

    surface_SetTextPos( Context.x, Context.y )
    surface_DrawText( Str )

    surface_SetDrawColor( Settings.GetColor( Settings.Theme.SolidOutline ) )
    surface_DrawOutlinedRect( Context.x, Context.y + 16, InterfaceEx.ThemeBoxW - 9, 20 )

    surface_DrawRect( Context.x + 19, Context.y + 16, 1, 20 )
    surface_DrawRect( Context.x + InterfaceEx.ThemeBoxW - 29, Context.y + 16, 1, 20 )

    surface_SetTextPos( Context.x + InterfaceEx.ThemeBoxW / 2 - Tw / 2, Context.y + 17 )
    surface_DrawText( Options[ Tbl[ Var ] ] )

    surface_SetTextPos( Context.x + InterfaceEx.ThemeBoxW - 23, Context.y + 17 )
    surface_DrawText( ">" )

    surface_SetTextPos( Context.x + 5, Context.y + 17 )
    surface_DrawText( "<" )

    if MouseInRect then 
        if Hint then
            InterfaceEx.DisplayHint( Hint )
        end

        if InputEx.IsPressed[ MOUSE_LEFT ] then
            if Mouse.InRect( Context.x, Context.y + 16, 20, 20 ) then
                Tbl[ Var ] = ( Tbl[ Var ] - 1 ) % ( #Options + 1 )

                if Tbl[ Var ] < 1 then
                    Tbl[ Var ] = #Options
                end
            elseif Mouse.InRect( Context.x + InterfaceEx.ThemeBoxW - 20, Context.y + 16, 20, 20 ) then
                Tbl[ Var ] = ( Tbl[ Var ] + 1 ) % ( #Options + 1 )
                Tbl[ Var ] = math_Max( 1, Tbl[ Var ] )
            end 
        end

        InterfaceEx.InteractActive = true
    end

    Context.y = Context.y + 40
    Context.h = Context.h + 40
end

function InterfaceEx.ComboVariance( Str, Var, Hint, Options, Tbl )
    Tbl = Tbl or Settings.Vars

    local MouseInRect = Mouse.InRect( Context.x, Context.y + 16, InterfaceEx.ThemeBoxW - 9, 20 )
    local Tw, Th 

    surface_SetTextColor( Settings.GetColor( Settings.Theme[ MouseInRect and "NormalText" or "FadeText" ] ) )

    surface_SetTextPos( Context.x, Context.y )
    surface_DrawText( Str )

    surface_SetDrawColor( Settings.GetColor( Settings.Theme.SolidOutline ) )
    surface_DrawOutlinedRect( Context.x, Context.y + 16, InterfaceEx.ThemeBoxW - 9, 20 )

    local Shift = Context.x
    local Width = math_Ceil( ( InterfaceEx.ThemeBoxW - 9 ) / #Options )
    for i = 1, #Options do
        Tw, Th = DrawEx.GetTextSize( Options[ i ] )

        surface_SetTextColor( Settings.GetColor( Settings.Theme[ ( Tbl[ Var ] == i and "ActiveText" ) or ( InRect and "HoveredText" ) or "NormalText" ] ) )
        surface_SetTextPos( Shift + Width / 2 - Tw / 2, Context.y + 17 )
        surface_DrawText( Options[ i ] ) 

        surface_SetDrawColor( Settings.GetColor( Settings.Theme.SolidOutline ) )
        surface_DrawRect( Shift, Context.y + 16, 1, 20 )

        MouseInRect = Mouse.InRect( Shift, Context.y + 16, Width, 20 )

        if MouseInRect then 
            if Hint then
                InterfaceEx.DisplayHint( Hint )
            end

            if InputEx.IsPressed[ MOUSE_LEFT ] then
                Tbl[ Var ] = i
            end
    
            InterfaceEx.InteractActive = true
        end

        Shift = Shift + Width
    end

    Context.y = Context.y + 40
    Context.h = Context.h + 40
end

// Coordinate graph
function InterfaceEx.CoGraph( Str, Hint, VarX, VarY, MinX, MinY, MaxX, MaxY, Dec )
    local Height = math_Ceil( ( InterfaceEx.ThemeBoxW - 9 ) / 2 )
    local Tw, Th 

    local MouseInRect = Mouse.InRect( Context.x, Context.y + 16, InterfaceEx.ThemeBoxW - 9, Height )
    
    surface_SetTextColor( Settings.GetColor( Settings.Theme[ MouseInRect and "NormalText" or "FadeText" ] ) )
    surface_SetTextPos( Context.x, Context.y )
    surface_DrawText( Str )

    local SymbolStr = string_format( "x: %G y: %G", Settings.Vars[ VarX ], Settings.Vars[ VarY ] )
    local Tw, Th    = DrawEx.GetTextSize( SymbolStr )

    surface_SetTextPos( Context.x + InterfaceEx.ThemeBoxW - Tw - 13, Context.y )
    surface_DrawText( SymbolStr )

    surface_SetDrawColor( Settings.GetColor( Settings.Theme.SolidOutline ) )
    surface_DrawOutlinedRect( Context.x, Context.y + 16, InterfaceEx.ThemeBoxW - 9, Height )

    local PosX = ( ( Settings.Vars[ VarX ] - MinX ) / ( MaxX - MinX ) ) * ( InterfaceEx.ThemeBoxW - 9 )
    local PosY = ( ( Settings.Vars[ VarY ] - MinY ) / ( MaxY - MinY ) ) * Height

    surface_DrawRect( Context.x + PosX, Context.y + 16, 1, Height )
    surface_DrawRect( Context.x, Context.y + PosY + 16, InterfaceEx.ThemeBoxW - 9, 1 )

    Context.y = Context.y + 16
    if MouseInRect then
        if Hint then
            InterfaceEx.DisplayHint( Hint )
        end

        if InputEx.IsDown[ MOUSE_LEFT ] then
            Settings.Vars[ VarX ] = math_Round( MinX + ( ( Mouse.x - Context.x ) / ( Context.x + InterfaceEx.ThemeBoxW - 9 - Context.x ) ) * ( MaxX - MinX ), Dec )
            Settings.Vars[ VarX ] = math_Clamp( Settings.Vars[ VarX ], MinX, MaxY )

            Settings.Vars[ VarY ] = math_Round( MinY + ( ( Mouse.y - Context.y ) / ( Context.y + Height - Context.y ) ) * ( MaxY - MinY ), Dec )
            Settings.Vars[ VarY ] = math_Clamp( Settings.Vars[ VarY ], MinY, MaxY )
        end
        
        InterfaceEx.InteractActive = true
    end

    Context.y = Context.y + Height + 4
    Context.h = Context.h + Height + 20
end

// Binder / Picker
function InterfaceEx.ColorPicker( Str, Vars, Tbl )
    Tbl = Tbl or Settings.Colors

    local InRect = Mouse.InRect( Context.x, Context.y, InterfaceEx.ActiveWidth, InterfaceEx.CheckboxSize, true )

    surface_SetTextColor( Settings.GetColor( Settings.Theme[ InRect and "NormalText" or "FadeText" ] ) ) 
    surface_SetTextPos( Context.x, Context.y - 1 )
    surface_DrawText( Str )

    local Shift = Context.x + InterfaceEx.ThemeBoxW - InterfaceEx.CheckboxSize - 9
    for i = 1, #Vars do
        InRect = Mouse.InRect( Shift, Context.y, InterfaceEx.CheckboxSize, InterfaceEx.CheckboxSize )

        surface_SetDrawColor( 255, 255, 255 )
        surface_SetMaterial( MaterialEx.Cache( "gui/alpha_grid.png" ) )
        surface_DrawTexturedRect( Shift, Context.y, InterfaceEx.CheckboxSize, InterfaceEx.CheckboxSize )

        surface_SetDrawColor( Settings.GetColor( Tbl[ Vars[ i ] ] ) )

        surface_DrawRect( Shift, Context.y, InterfaceEx.CheckboxSize, InterfaceEx.CheckboxSize )

        surface_SetDrawColor( Settings.GetColor( Settings.Theme.SolidOutline ) )
        surface_DrawOutlinedRect( Shift, Context.y, InterfaceEx.CheckboxSize, InterfaceEx.CheckboxSize )

        if InRect then
            if InputEx.IsPressed[ MOUSE_LEFT ] then
                InterfaceEx.FindFrame( "Menu" ).LastInteract = GlobalVars.CurTime - 2

                local SubFrame = InterfaceEx.FindFrame( "Picker" )

                InterfaceEx.ColorVars = Tbl[ Vars[ i ] ]

                SubFrame.x = Context.x
                SubFrame.y = Context.y + 35
        
                SubFrame.LastInteract = GlobalVars.CurTime + 1
            end

            InterfaceEx.InteractActive = true
        end

        Shift = Shift - InterfaceEx.CheckboxSize - 2
    end

    Context.y = Context.y + InterfaceEx.CheckboxSize + 3
    Context.h = Context.h + InterfaceEx.CheckboxSize + 3
end

function InterfaceEx.BindPicker( Str, Bind )
    local InRect = Mouse.InRect( Context.x, Context.y, InterfaceEx.ActiveWidth, InterfaceEx.CheckboxSize, true )
    local KeyStr = Settings.Binds[ Bind ].Trapping and "WAITING..." or Settings.Binds[ Bind ].Key >= 0 and string_upper( input_lib.GetKeyName( Settings.Binds[ Bind ].Key ) ) or "NONE"
    local Tw, Th = DrawEx.GetTextSize( KeyStr )

    surface_SetTextColor( Settings.GetColor( Settings.Theme[ InRect and "NormalText" or "FadeText" ] ) ) 

    surface_SetTextPos( Context.x, Context.y - 1 )
    surface_DrawText( Str )

    surface_SetTextPos( Context.x + InterfaceEx.ThemeBoxW - Tw - 17, Context.y - 1 )
    surface_DrawText( KeyStr )

    surface_SetDrawColor( Settings.GetColor( Settings.Theme.SolidOutline ) )
    surface_DrawOutlinedRect( Context.x + InterfaceEx.ThemeBoxW - Tw - 25, Context.y, Tw + 16, InterfaceEx.CheckboxSize + 1 )

    if InRect then
        if InputEx.IsPressed[ MOUSE_LEFT ] then
            InterfaceEx.FindFrame( "Menu" ).LastInteract = GlobalVars.CurTime - 2

            local SubFrame = InterfaceEx.FindFrame( "Binder" )

            InterfaceEx.BindVars = { Settings.Binds[ Bind ], Bind }

            SubFrame.x = Context.x
            SubFrame.y = Context.y + 35
        
            SubFrame.LastInteract = GlobalVars.CurTime + 1
        end

        InterfaceEx.InteractActive = true
    end

    Context.y = Context.y + InterfaceEx.CheckboxSize + 3
    Context.h = Context.h + InterfaceEx.CheckboxSize + 3
end

function InterfaceEx.CreateFrame( Name, NumWidth, NumHeight, FrameWidth, FrameHeight, CanMove, CanDraw, OnDraw, PostDraw, OnlyDraw )
    local Index = #InterfaceEx.Frames + 1

    InterfaceEx.Frames[ Index ] = {
        UniqueName = Name,

        x = 0,
        y = 0,
        w = NumWidth or 0,     
        h = NumHeight or 0,
        TempW = FrameWidth or "FrameWidth", 
        TempH = FrameHeight or "FrameHeight",

        CanMove = IsBool( CanMove ) and function() return CanMove end or CanMove,
        CanDraw = CanDraw or false, 
        OnDraw = OnDraw,
        PostDraw = PostDraw, 

        LastInteract = 0,
        OldX = 0,
        OldY = 0,

        SkipSort = OnlyDraw,
    }

    return Index
end

function InterfaceEx.FindFrame( UniqueName )
    for i = 1, #InterfaceEx.Frames do
        if InterfaceEx.Frames[ i ].UniqueName == UniqueName then
            return InterfaceEx.Frames[ i ]
        end 
    end

    return false
end 

function InterfaceEx.NormalSort( a, b )   
    return a.LastInteract < b.LastInteract 
end

function InterfaceEx.ReversedSort( a, b ) 
    return a.LastInteract > b.LastInteract 
end

function InterfaceEx.Render()
    local CurrentMouseX, CurrentMouseY = input_GetCursorPos()
    local Frame 

    table_sort( InterfaceEx.Frames, InterfaceEx.ReversedSort )

    local Focused = "Menu" 

    for i = 1, #InterfaceEx.Frames do
        if InterfaceEx.Frames[ i ].SkipSort then 
            continue
        end 

        Focused = InterfaceEx.Frames[ i ].UniqueName 

        break
    end

    table_sort( InterfaceEx.Frames, InterfaceEx.NormalSort )

    for i = 1, #InterfaceEx.Frames do
        Frame = InterfaceEx.Frames[ i ]

        if not ( IsBool( Frame.CanDraw ) and Frame.CanDraw or Frame.CanDraw() ) then continue end

        
        Mouse.InFocusedFrame = Focused == Frame.UniqueName
        InterfaceEx.Frames[ i ].OnDraw( InterfaceEx.Frames[ i ], Focused == Frame.UniqueName )
    end

    table_sort( InterfaceEx.Frames, InterfaceEx.ReversedSort )

    for i = 1, #InterfaceEx.Frames do
        Frame = InterfaceEx.Frames[ i ]

        if Frame.SkipSort then continue end 

        if Frame.PostDraw then
            Frame.PostDraw()
        end

        if not ( IsBool( Frame.CanDraw ) and Frame.CanDraw or Frame.CanDraw() ) then continue end
        
        if Mouse.InRect( Frame.x, Frame.y , Frame.w, Frame.h ) then        
            if input_IsMouseDown( MOUSE_LEFT ) and not InterfaceEx.IsHoveringPanel and not InterfaceEx.InteractActive then
                if ( IsBool( Frame.CanMove ) and Frame.CanMove or Frame.CanMove() ) then
                    Frame.x = Frame.x + ( CurrentMouseX - Mouse.x )
                    Frame.y = Frame.y + ( CurrentMouseY - Mouse.y )
                end
                
                Frame.LastInteract = GlobalVars.CurTime
            end
    
            InterfaceEx.IsHoveringPanel = true
        end
    
        Frame.OldX = Frame.x
        Frame.OldY = Frame.y
    end

    InterfaceEx.IsHoveringPanel = false
    InterfaceEx.InteractActive = false

    Context.g = 0

    Mouse.x, Mouse.y = CurrentMouseX, CurrentMouseY
end

function InterfaceEx.Update()
    for i = 1, #InterfaceEx.Frames do
        InterfaceEx.Frames[ i ].w = IsNumber( InterfaceEx.Frames[ i ].TempW ) and InterfaceEx.Frames[ i ].TempW or ScrEx.Get[ InterfaceEx.Frames[ i ].TempW ]
        InterfaceEx.Frames[ i ].h = IsNumber( InterfaceEx.Frames[ i ].TempH ) and InterfaceEx.Frames[ i ].TempH or ScrEx.Get[ InterfaceEx.Frames[ i ].TempH ]
    end
end

function InterfaceEx.FrameThink()
    if not InputEx.IsPressed[ KEY_DELETE ] then return end 
    InterfaceEx.ShowMenu = not InterfaceEx.ShowMenu
    gui_EnableScreenClicker( InterfaceEx.ShowMenu )
end

InterfaceEx.SubTabs = {
    { 
        Active = 1, 
        Tabs = { "Player", "Entity", "Misc" },
        Draw = {
            function( x, y ) 
                
            end,
            function( x, y ) 
                
            end,
            function( x, y ) 
                
            end,
        }
    },
}

InterfaceEx.ActiveTab = 1 
InterfaceEx.Tabs = {
    {
        Name = "Combat", 
        Active = 1, 

        Draw = function( x, y )

        end
    },
    {
        Name = "Visuals",
        Active = 1,

        Draw = function( x, y )
            InterfaceEx.StartThemeBox( "Theme boxie", 1 )
            InterfaceEx.EndThemeBox()
        end
    },
    {
        Name = "Render",
        Active = 1,

        Draw = function( x, y )

        end
    },
    {
        Name = "Misc",
        Active = 1,

        Draw = function( x, y )

        end
    },
    {
        Name = "Settings",
        Active = 1,

        Draw = function( x, y )
            InterfaceEx.StartThemeBox( "Theme boxie" )
           

            

            InterfaceEx.EndThemeBox()

            Context.y = y 
            Context.x = Context.x + 257

            InterfaceEx.StartThemeBox( "Sub tabs" )

            InterfaceEx.EndThemeBox()

            Context.y = y 
            Context.x = Context.x + 257

            InterfaceEx.StartThemeBox( "Theme colors" )

            InterfaceEx.ColorPicker( "Background", { "SolidBackground", "FadeBackground", "SolidHeader" }, Settings.Theme )
            InterfaceEx.ColorPicker( "Texture", { "ActiveTexture", "HoveredTexture", "FadeTexture", "SolidCheckHover" }, Settings.Theme )
            InterfaceEx.ColorPicker( "Outline", { "SolidOutline", "FadeOutline", "FadeTexture" }, Settings.Theme )
            InterfaceEx.ColorPicker( "Text", { "ActiveText", "HoveredText", "NormalText", "HighlightedText", "FadeText" }, Settings.Theme )

            InterfaceEx.EndThemeBox()
        end
    },
    {
        Name = "Lists",
        Active = 1,

        Draw = function( x, y )
            InterfaceEx.StartThemeBox( "Theme boxie" )
           
            InterfaceEx.Checkbox( "Something coooool", "Var", "Looks like some cool feature :3", nil, false, function() InterfaceEx.Slider( "Some cool slider", "®", "Int", false, nil, 0, -30, 15 ) end )

            InterfaceEx.Spacer()

            InterfaceEx.Button( "Click at me :3", function() print( 1337 ) end, "OwO whats dat?!" )
            InterfaceEx.MultiButton( { {Str = "Shadow"}, {Str = "Is"}, {Str = "Nigger"} } )

            InterfaceEx.Spacer()
            InterfaceEx.Slider( "Some cool slider", "®", "Int", false, nil, 0, -30, 15 )
            InterfaceEx.CenteredSlider( "Centered slider", "ms", "Int", false, nil, 0, -30, 15 )
            InterfaceEx.DoubleSlider( "Double one", "t", "Int1", "Int2", false, nil, 2, -5, 23 )

            InterfaceEx.Spacer()

            InterfaceEx.ComboBox( "Combobox", "CVar", false, { "Penis", "Dick", "Cock" } )
            InterfaceEx.ComboSelector( "Combobox", "CVar", false, { "Penis", "Dick", "Cock" } )
            InterfaceEx.ComboVariance( "Combobox", "CVar", false, { "Penis", "Dick", "Cock" } )

            InterfaceEx.Spacer()

            InterfaceEx.CoGraph( "Graph", false, "Int1", "Int2", -30, -30, 15, 15, 1 )

            InterfaceEx.Spacer()

            InterfaceEx.ColorPicker( "Coloc picker example", { "Var", "Var1", "Var2", "Var3" } )
            InterfaceEx.BindPicker( "Binder blah blah blah", 1 )

            InterfaceEx.EndThemeBox()

            /*Context.y = y 
            Context.x = Context.x + 257

            InterfaceEx.StartThemeBox( "Sub tabs", 1 )
            Context.h = 256
            InterfaceEx.EndThemeBox()

            Context.y = y 
            Context.x = Context.x + 257

            InterfaceEx.StartThemeBox( "TEST" )
            
            InterfaceEx.EndThemeBox()*/
        end
    },
}

function InterfaceEx.FrameRender( self, focus )
    local x, y, w, h = self.x, self.y, self.w, self.h
    local data, subdata, inrect, shift, tw, th, pad, spad

    render_SetScissorRect( x, y, x + w, y + h, true )

    surface_SetDrawColor( Settings.GetColor( Settings.Theme.SolidBackground ) )
    surface_DrawRect( x, y, w, h )
    
    surface_SetDrawColor( Settings.GetColor( Settings.Theme.SolidOutline ) )
    surface_DrawOutlinedRect( x, y, w, h, 4 )
    surface_DrawRect( x, y + 4, w, 22 )

    surface_SetDrawColor( Settings.GetColor( Settings.Theme.FadeOutline ) )
    surface_DrawOutlinedRect( x, y, w, h, 1 )
    surface_DrawOutlinedRect( x + 3, y + 3, w - 6, h - 6, 1 )
    surface_DrawRect( x + 3, y + 25, w - 6, 1 )
    surface_DrawRect( x + 3, y + 51, w - 6, 1 )

    surface_SetDrawColor( Settings.GetColor( Settings.Theme.FadeBackground ) )
    surface_DrawRect( x + 4, y + 26, w - 8, 25 )

    surface_SetMaterial( MaterialEx.Cache( "vgui/gradient_up" ) )
    surface_SetDrawColor( Settings.GetColor( Settings.Theme.FadeTexture ) )
    surface_DrawTexturedRect( x + 4, y + 26, w - 8, 25 )
    
    DrawEx.SetFont( "MenuFont" )

    surface_SetTextColor( Settings.GetColor( Settings.Theme.NormalText ) )
    DrawEx.DrawText( "Ultimate for Gmod x64", x + 310, y + 7 )

    InterfaceEx.ExtenderID = 0

    shift = x + 4

    for i = 1, #InterfaceEx.Tabs do
        data = InterfaceEx.Tabs[ i ]
        inrect = Mouse.InRect( shift, y + 26, 125, 25 )

        if InterfaceEx.ActiveTab == i or inrect then
            surface_SetDrawColor( Settings.GetColor( Settings.Theme[ ( InterfaceEx.ActiveTab == i and "ActiveTexture" ) or ( inrect and "HoveredTexture" ) ] ) )
            surface_SetMaterial( MaterialEx.Cache( "vgui/gradient_down" ) )
            surface_DrawTexturedRect( shift, y + 26, 125, 25 )
        end
            
        tw, th = DrawEx.GetTextSize( data.Name )

        surface_SetTextColor( Settings.GetColor( Settings.Theme[ ( InterfaceEx.ActiveTab == i and "ActiveText" ) or ( inrect and "HoveredText" ) or "NormalText" ] ) )
        DrawEx.DrawText( data.Name, shift + 62 - tw / 2, y + 30 )

        if inrect and focus and InputEx.IsPressed[ MOUSE_LEFT ] then
            InterfaceEx.ActiveTab = i
        end
        
        shift = shift + 125
    end

    inrect = Mouse.InRect( shift, y + 26, 24, 25 )

    if InterfaceEx.ShowHome or inrect then
        surface_SetDrawColor( Settings.GetColor( Settings.Theme[ ( InterfaceEx.ShowHome and "ActiveTexture" ) or ( inrect and "HoveredTexture" ) ] ) )
        surface_SetMaterial( MaterialEx.Cache( "vgui/gradient_down" ) )
        surface_DrawTexturedRect( shift, y + 26, 24, 25 )
    end
        
    surface_SetDrawColor( Settings.GetColor( Settings.Theme[ ( InterfaceEx.ShowHome and "ActiveText" ) or ( inrect and "HoveredText" ) or "NormalText" ] ) )
    surface_SetMaterial( MaterialEx.Cache( "gui/html/home" ) )
    surface_DrawTexturedRect( shift, y + 26, 24, 25 )

    if inrect and focus and InputEx.IsPressed[ MOUSE_LEFT ] then
        InterfaceEx.ShowHome = not InterfaceEx.ShowHome 
    end

    Context.x = x + 8 
    Context.y = y + 56

    InterfaceEx.Tabs[ InterfaceEx.ActiveTab ].Draw( Context.x, Context.y )

    render_SetScissorRect( 0, 0, 0, 0, false )
end 

function InterfaceEx.HintRender( self, focus )
    local x, y, w, h = self.x, self.y, self.w, self.h
    DrawEx.SetFont( "MenuFont" )

    surface_SetDrawColor( Settings.GetColor( Settings.Theme.SolidBackground ) )
    surface_DrawRect( x, y, w, h )
    
    surface_SetDrawColor( Settings.GetColor( Settings.Theme.SolidOutline ) )
    surface_DrawOutlinedRect( x, y, w, h, 1 )
    surface_SetTextColor( Settings.GetColor( Settings.Theme.NormalText ) )
    DrawEx.DrawText( InterfaceEx.Hint, x + 8, y + 4 )

    self.LastInteract = GlobalVars.CurTime + 10
    InterfaceEx.Hint = false 
end

function InterfaceEx.ComboRender( self, focus )
    local x, y, w, h = self.x, self.y, self.w, self.h
    DrawEx.SetFont( "MenuFont" )

    surface_SetDrawColor( Settings.GetColor( Settings.Theme.SolidBackground ) )
    surface_DrawRect( x, y, w, h )
    
    surface_SetDrawColor( Settings.GetColor( Settings.Theme.SolidOutline ) )
    surface_DrawOutlinedRect( x, y, w, h, 1 )

    local Vars = InterfaceEx.ComboVars
    local Tbl = Vars[ 4 ]

    for i = 1, #Vars[ 2 ] do
        local InRect = Mouse.InRect( x, y + ( i - 1 ) * 16, InterfaceEx.ThemeBoxW - 9, 16 ) 

        surface_SetTextColor( Settings.GetColor( Settings.Theme[ ( ( Vars[ 3 ] and Tbl[ Vars[ 1 ] .. Vars[ 2 ][ i ] ] or Tbl[ Vars[ 1 ] ] == i ) and "ActiveText" ) or ( InRect and "HoveredText" ) or "NormalText" ] ) )
        surface_SetTextPos( x + 4, y + ( i - 1 ) * 16 )
        surface_DrawText( Vars[ 2 ][ i ] )

        if InRect and InputEx.IsPressed[ MOUSE_LEFT ] then
            if Vars[ 3 ] then
                Tbl[ Vars[ 1 ] .. Vars[ 2 ][ i ] ] = not Tbl[ Vars[ 1 ] .. Vars[ 2 ][ i ] ]
            else
                Tbl[ Vars[ 1 ] ] = i
                InterfaceEx.ComboVars = false
            end
        end 
    end

    if not focus then
        InterfaceEx.ComboVars = false
    end
end

function InterfaceEx.BinderRender( self, focus )
    local x, y, w, h = self.x, self.y, self.w, self.h
    local Bind = InterfaceEx.BindVars[ 2 ]

    surface_SetDrawColor( Settings.GetColor( Settings.Theme.SolidBackground ) )
    surface_DrawRect( x, y, w, h )
    
    surface_SetDrawColor( Settings.GetColor( Settings.Theme.SolidOutline ) )
    surface_DrawOutlinedRect( x, y, w, h, 4 )
    surface_DrawRect( x, y + 4, w, 22 )

    surface_SetDrawColor( Settings.GetColor( Settings.Theme.FadeOutline ) )
    surface_DrawOutlinedRect( x, y, w, h, 1 )
    surface_DrawOutlinedRect( x + 3, y + 3, w - 6, h - 6, 1 )
    surface_DrawRect( x + 3, y + 25, w - 6, 1 )

    DrawEx.SetFont( "MenuFont" )

    surface_SetTextColor( Settings.GetColor( Settings.Theme.NormalText ) )
    DrawEx.DrawText( "Bind manager", x + 85, y + 7 )

    Context.x = x + 8
    Context.y = y + 30

    InterfaceEx.Checkbox( "Show in bindlist", "Show", nil, Settings.Binds[ Bind ] )
    InterfaceEx.ComboVariance( "Method", "Mode", nil, { "Hold", "Toggle", "Always" }, Settings.Binds[ Bind ] )

    Context.y = Context.y - 1

    surface_DrawOutlinedRect( Context.x, Context.y, InterfaceEx.ThemeBoxW - 9, 20, 1 )
    
    local keyName = Settings.Binds[ Bind ].Trapping and "WAITING..." or Settings.Binds[ Bind ].Key >= 0 and string_upper( input_lib.GetKeyName( Settings.Binds[ Bind ].Key ) ) or "NONE"
    local Tw, Th = DrawEx.GetTextSize( keyName )
    local InRect = Mouse.InRect( Context.x, Context.y, InterfaceEx.ThemeBoxW - 9, 20 )
    local Trapping = input_lib.IsKeyTrapping() and Settings.Binds[ Bind ].Trapping

    surface_SetTextColor( Settings.GetColor( Settings.Theme[ ( Trapping and "ActiveText" ) or ( InRect and "HoveredText" ) or "NormalText" ] ) )
    surface_SetTextPos( Context.x + ( InterfaceEx.ThemeBoxW - 9 ) / 2 - Tw / 2, Context.y + 1 )
    surface_DrawText( keyName )

    if Trapping then
        local code = input_lib.CheckKeyTrapping()

        if code then
            Settings.Binds[ Bind ].Key = code == KEY_ESCAPE and -1 or code
            Settings.Binds[ Bind ].Trapping = false
        end
    end

    if InRect then
        if InputEx.IsPressed[ MOUSE_LEFT ] then
            input_lib.StartKeyTrapping()
            Settings.Binds[ Bind ].Trapping = not Settings.Binds[ Bind ].Trapping 
        elseif InputEx.IsPressed[ MOUSE_RIGHT ] then
            Settings.Binds[ Bind ].Key = -1
            Settings.Binds[ Bind ].Trapping = false
        end
    end

    if not focus then
        InterfaceEx.BindVars = false
    end
end

function InterfaceEx.GradientBar( Data, Var, VecVar )
    surface_SetDrawColor( Var == "r" and 255 or 0, Var == "g" and 255 or 0, Var == "b" and 255 or 0 )
    surface_DrawRect( Context.x, Context.y, 243, 12 )

    surface_SetDrawColor( 0, 0, 0 )
    surface_SetMaterial( MaterialEx.Cache( "vgui/gradient-l" ) )
    surface_DrawTexturedRect( Context.x, Context.y, 243, 12 )

    local InRect = Mouse.InRect( Context.x, Context.y, 243, 12 )
    if InputEx.IsDown[ MOUSE_LEFT ] and InRect then
        Data[ Var ] = math_Round( ( ( Mouse.x - Context.x ) / ( Context.x + 243 - Context.x ) ) * ( 255 ), 0 )
        Data[ Var ] = math_Clamp( Data[ Var ], 0, 255 )

        Data[ VecVar ] = Data[ Var ] / 255 

        InterfaceEx.InteractActive = true
    end

    surface_SetDrawColor( 255, 255, 255 )
    surface_DrawRect( Context.x + math_Floor( Data[ Var ] / 255 * 242 ), Context.y, 1, 12 )

    surface_SetDrawColor( Settings.GetColor( Settings.Theme.SolidOutline ) )
    surface_DrawOutlinedRect( Context.x, Context.y, 243, 12, 1 )

    Context.y = Context.y + 16
end
function InterfaceEx.PickerRender( self, focus )
    local x, y, w, h = self.x, self.y, self.w, self.h

    local Tbl  = InterfaceEx.ColorVars
    local Data = InterfaceEx.ColorVars[ 1 ]
    local R, G, B, A = Settings.GetColor( Tbl )

    surface_SetDrawColor( Settings.GetColor( Settings.Theme.SolidBackground ) )
    surface_DrawRect( x, y, w, h )
    
    surface_SetDrawColor( Settings.GetColor( Settings.Theme.SolidOutline ) )
    surface_DrawOutlinedRect( x, y, w, h, 4 )
    surface_DrawRect( x, y + 4, w, 22 )

    surface_SetDrawColor( Settings.GetColor( Settings.Theme.FadeOutline ) )
    surface_DrawOutlinedRect( x, y, w, h, 1 )
    surface_DrawOutlinedRect( x + 3, y + 3, w - 6, h - 6, 1 )
    surface_DrawRect( x + 3, y + 25, w - 6, 1 )

    DrawEx.SetFont( "MenuFont" )

    surface_SetTextColor( Settings.GetColor( Settings.Theme.NormalText ) )
    DrawEx.DrawText( "Color picker", x + 89, y + 7 )

    Context.x = x + 8
    Context.y = y + 30

    surface_SetDrawColor( R, G, B )
    surface_DrawRect( Context.x, Context.y, 48, 24 )

    surface_SetDrawColor( 255 - R, 255 - G, 255 - B )
    surface_DrawRect( Context.x, Context.y + 24, 48, 24 )

    surface_SetDrawColor( Settings.GetColor( Settings.Theme.SolidOutline ) )
    surface_DrawOutlinedRect( Context.x, Context.y, 48, 48, 1 )

    DrawEx.DrawText( string_format( "RGBA : %i %i %i %i", R, G, B, A ), x + 64, y + 30 )
    DrawEx.DrawText( string_format( "HEX : %s", string_format( HexPattern, R, G, B ) ), x + 64, y + 46 ) 

    local InRect = Mouse.InRect( Context.x, Context.y + 24, 48, 24 )

    if InRect and InputEx.IsPressed[ MOUSE_LEFT ] then
        Data.r = 255 - Data.r
        Data.g = 255 - Data.g
        Data.b = 255 - Data.b
    
        Data.x = 1 - Data.x
        Data.y = 1 - Data.y
        Data.z = 1 - Data.z
    end

    Context.y = Context.y + 52

    surface_SetDrawColor( 255, 255, 255 )
    surface_SetMaterial( MaterialEx.Cache( "gui/alpha_grid.png" ) )
    surface_DrawTexturedRect( Context.x, Context.y, 243, 16 )

    surface_SetDrawColor( R, G, B )
    surface_SetMaterial( MaterialEx.Cache( "vgui/gradient-r" ) )
    surface_DrawTexturedRect( Context.x, Context.y, 243, 16 )

    InRect = Mouse.InRect( Context.x, Context.y, 243, 16 )

    if InputEx.IsDown[ MOUSE_LEFT ] and InRect then
        Data.a = math_Round( ( ( Mouse.x - Context.x ) / ( Context.x + 243 - Context.x ) ) * 255, 0 )
        Data.a = math_Clamp( Data.a, 0, 255 )

        Data.q = Data.a / 255
        InterfaceEx.InteractActive = true
    end

    surface_SetDrawColor( 255, 255, 255 )
    surface_DrawRect( Context.x + math_Floor( Data.a / 255 * 242 ), Context.y, 1, 16 )

    surface_SetDrawColor( Settings.GetColor( Settings.Theme.SolidOutline ) )
    surface_DrawOutlinedRect( Context.x, Context.y, 243, 16, 1 )

    Context.y = Context.y + 20

    InterfaceEx.GradientBar( Data, "r", "x" )
    InterfaceEx.GradientBar( Data, "g", "y" )
    InterfaceEx.GradientBar( Data, "b", "z" )

    surface_SetDrawColor( 255, 255, 255 )
    surface_SetMaterial( MaterialEx.Cache( "gui/colors.png" ) )
    surface_lib.DrawTexturedRectRotated( ( Context.x + 122 ), Context.y + 8, 16, 243, 270 )

    surface_SetDrawColor( Settings.GetColor( Settings.Theme.SolidOutline ) )
    surface_DrawOutlinedRect( Context.x, Context.y, 243, 16, 1 )

    InRect = Mouse.InRect( Context.x, Context.y, 243, 16 )

    if InputEx.IsDown[ MOUSE_LEFT ] and InRect then
        local Len = math_Round( ( ( Mouse.x - Context.x ) / ( Context.x + 243 - Context.x ) ) * ( 255 ), 0 )
        local HSV = HueToColor( Len * 1.53, 1, 1 )

        Data.r = math_Clamp( HSV.r, 0, 255 )
        Data.g = math_Clamp( HSV.g, 0, 255 )
        Data.b = math_Clamp( HSV.b, 0, 255 )
    
        Data.x = Data.r / 255
        Data.y = Data.g / 255
        Data.z = Data.b / 255

        InterfaceEx.InteractActive = true
    end 

    Context.y = Context.y + 16

    InterfaceEx.ComboVariance( "Method", 2, nil, { "Static", "Rainbow", "Team", "Gradient" }, Tbl )
    InterfaceEx.ComboSelector( "Gradient", 3, false, Settings.TransColors, Tbl )

    if not focus then
        InterfaceEx.ColorVars = false
    end
end

function InterfaceEx.HomeRender( self, focus )
    local x, y, w, h = self.x, self.y, self.w, self.h

    surface_SetDrawColor( Settings.GetColor( Settings.Theme.SolidBackground ) )
    surface_DrawRect( x, y, w, h )

    surface_SetDrawColor( Settings.GetColor( Settings.Theme.FadeBackground ) )
    surface_DrawRect( x, y, w - 8, h )

    surface_SetDrawColor( Settings.GetColor( Settings.Theme.SolidOutline ) )
    surface_DrawRect( x, y, 86, h )

    surface_SetDrawColor( Settings.GetColor( Settings.Theme.FadeOutline ) )
    surface_DrawOutlinedRect( x, y, w, h, 1 )
    surface_DrawOutlinedRect( x, y, 86, h, 1 )

    DrawEx.SetFont( "MenuFont" )

    surface_SetTextColor( Settings.GetColor( Settings.Theme.NormalText ) )
    DrawEx.DrawText( "Utilities", x + 18, y + 4 )
end

InterfaceEx.CreateFrame( "Menu", 900, 700, "FrameWidth", "FrameHeight", true, function() return InterfaceEx.ShowMenu end, InterfaceEx.FrameRender, InterfaceEx.FrameThink )
InterfaceEx.CreateFrame( "Home", ScrEx.Width, 24, ScrEx.Width, 24, false, function() return InterfaceEx.ShowHome and InterfaceEx.ShowMenu end, InterfaceEx.HomeRender )
InterfaceEx.CreateFrame( "Hint", 128, 56, 128, 56, false, function() return IsString( InterfaceEx.Hint ) end, InterfaceEx.HintRender, false, true )
InterfaceEx.CreateFrame( "Combo", 0, 0, 0, 0, false, function() return IsTable( InterfaceEx.ComboVars ) end, InterfaceEx.ComboRender )
InterfaceEx.CreateFrame( "Binder", 259, 114, 259, 114, true, function() return IsTable( InterfaceEx.BindVars ) end, InterfaceEx.BinderRender )
InterfaceEx.CreateFrame( "Picker", 259, 251, 259, 251, true, function() return IsTable( InterfaceEx.ColorVars ) end, InterfaceEx.PickerRender )
 
InterfaceEx.Update()
 






// 

































// Hooks 
local HooksEx = { List = {} }

function HooksEx.Add( event, func )
    HooksEx.List[ #HooksEx.List + 1 ] = { event, string_upper( event ), func }

    hook_Add( event, string_upper( event ), func )
end

HooksEx.Add( "Think", function()
    local HSV = HueToColor( ( GlobalVars.CurTime * ColorEx.SinSpeed ) % 360, 1, 1 )

    for i = 1, 113 do 
        InputEx.IsDown[ i ] = InputEx.IsKeyDown( i ) 
        InputEx.IsPressed[ i ] = InputEx.WasDown[ i ] != InputEx.IsDown[ i ] and not InputEx.IsDown[ i ] 
        InputEx.WasDown[ i ] = InputEx.IsKeyDown( i ) 
    end

    GlobalVars.CurTime = CurTime()
    GlobalVars.FrameTime = FrameTime()

    ColorEx.Rainbow = ColorEx.Update( math_Max( ColorEx.SinMin, HSV.r ), math_Max( ColorEx.SinMin, HSV.g ), math_Max( ColorEx.SinMin, HSV.b ), 255, 1 )
    TableEx.ListNumeric( ColorEx.Trans, ColorEx.Transit )
end )

HooksEx.Add( "DrawOverlay", function()
    InterfaceEx.Render()

end )

HooksEx.Add( "OnScreenSizeChanged", function( oldw, oldh, neww, nehh )
    ScrEx.Update()
    InterfaceEx.Update()
end )


/*
Days, months, years - time doesn't matter anymore. I have never been here, and I will never be. No matter what I do, I will not get off the path, I do not know where it leads. Only the dust of dead stars lights up the path for thousands of years. I'm not the first nor the last, but out of billions, I am the only one worth this. Let the light rest in the depths of the abyss and darkness be lit with light. I, I am eternity. I am the path. I am truth
*/