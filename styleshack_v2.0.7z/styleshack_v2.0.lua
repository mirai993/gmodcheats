--[[
	Leaked by Fami Harukaze :^) - https://www.youtube.com/user/INTELINSIDECHANNEL
]]

--[[

 ____ _______   ___     _____ ____  _   _    _    _____ _  ____     ______     _    _     ____  _   _    _    
/ ___|_   _\ \ / / |   | ____/ ___|| | | |  / \  | ____| |/ /\ \   / /___ \   / \  | |   |  _ \| | | |  / \   
\___ \ | |  \ V /| |   |  _| \___ \| |_| | / _ \ |  _| | ' /  \ \ / /  __) | / _ \ | |   | |_) | |_| | / _ \  
 ___) || |   | | | |___| |___ ___) |  _  |/ ___ \| |___| . \   \ V /  / __/ / ___ \| |___|  __/|  _  |/ ___ \ 
|____/ |_|   |_| |_____|_____|____/|_| |_/_/   \_\_____|_|\_\   \_/  |_____/_/   \_\_____|_|   |_| |_/_/   \_\
                                                                                                              
                
    


]]

--= Greeting =--

chat.AddText( Color( 26, 98, 222 ), "[Styles Hack] ", color_white, "Hack loaded!" )
surface.PlaySound( "buttons/blip1.wav" )



--= Localizing =--
local me,ply = LocalPlayer()
local table = table
local util = util
local input = input
local player = player
local Vector,Angle = Vector,Angle
local eyepos
local wep = function() return me:GetActiveWeapon() end
local ms = Angle()
local fire
txt = draw.SimpleText


--= Console Commands and ConVars =--
RunConsoleCommand("cl_csr_hit_effects","0")
RunConsoleCommand("cl_csr_extra_muzzle_flash","0")
CreateClientConVar( "styles_esp", 0, true, false )
CreateClientConVar( "styles_crosshair", 0, true, false )
local ESP_ON = GetConVar( "styles_esp" ):GetInt() == 1 
 
local ms = Angle()
 
local function mouse(c)
        ms = ms + Angle(c:GetMouseY() * 0.022,-c:GetMouseX() * 0.022,0)
        ms.p = math.Clamp(ms.p,-89,89.9)
end
 
local function transform(a,x)
        local b = Vector(0,0,0)
        local m1,m2,m3 = x[1],x[2],x[3]
        local vec1 = Vector(m1[1],m1[2],m1[3])
        local vec2 = Vector(m2[1],m2[2],m2[3])
        local vec3 = Vector(m3[1],m3[2],m3[3])
        b.x = a:Dot(vec1) + m1[4]
        b.y = a:Dot(vec2) + m2[4]
        b.z = a:Dot(vec3) + m3[4]
        return b
end


--= Head Pos =-- 
local function position(v)
        local pos
        if v:LookupBone("ValveBiped.Bip01_Head1") and v:GetBonePosition(v:LookupBone("ValveBiped.Bip01_Head1")) and v:GetBoneMatrix(v:LookupBone("ValveBiped.Bip01_Head1")) then
                local min,max = v:GetHitBoxBounds(0,0)
                matrix = v:GetBoneMatrix(v:LookupBone("ValveBiped.Bip01_Head1"))
                matrix = matrix:ToTable()
                min = transform(min,matrix)
                max = transform(max,matrix)
                pos = (min + max) * 0.5
                local aimvec = v:GetAimVector()
                if aimvec.x > 89 and aimvec.x < 91 then
                        pos.z = max.z - 6
                end
        else
                pos = v:LocalToWorld(v:OBBCenter())
        end
        return pos + ((v:GetVelocity() * 0.00672724) - (me:GetVelocity() * 0.0087775))
end



--= Insight =-- 
local function insight(v,vec)
        local tr = {}
        tr.start = me:GetShootPos()
        tr.endpos = vec
        tr.filter = {v,me}
        tr.mask = MASK_SHOT
        local trace = util.TraceLine(tr)
        return trace.Fraction == 1
end



--= Distance =-- 
local function distance(a,b)
        return (a:GetPos() - me:GetPos()):LengthSqr() < (b:GetPos() - me:GetPos()):LengthSqr()
end


--= Who were aiming for =-- 
local function targets()
        local k = player.GetAll()
        table.sort(k,distance)
        for i=1,#k do
                local v = k[i]
                --if not input.IsKeyDown(27) then continue end
                if v == me then continue end
                if v:Health() < 1 then continue end
                -- if v:GetFriendStatus() == "friend" then continue end
                //if v:Team() == me:Team() then continue end
                //if v:GetNWString("usergroup") != "user" then continue end
                //if v:IsAdmin() then continue end
                if v:GetColor().a < 255 then continue end
                if v:InVehicle() then continue end
                if v:GetMoveType() == bit.bor(MOVETYPE_NONE,MOVETYPE_OBSERVER) then continue end
                local pos = position(v)
                if not insight(v,pos) then continue end
                ply = v
                eyepos = pos
                break
        end
end


--= Dynamicity =-- 
local function hl2()
        local class = wep():GetClass()
        if class == "weapon_pistol" then return true end
        if class == "weapon_357" then return true end
        if class == "weapon_smg1" then return true end
        if class == "weapon_ar2" then return true end
        return false
end



--= Checking if automatic =-- 
local function automatic()
        if not wep() == NULL and wep.Primary then
                return wep.Primary.Automatic
        end
        return false
end
 
local fire
 

--= Angles =--
local function angles(c)
        ply = nil
        targets()
        if not ply then return ms end
        local ang = (eyepos - me:GetShootPos()):Angle()
        c:SetButtons(c:GetButtons() + 1)
        return ang
end


--= Setting Angles =-- 
local function setang(c,ang)
        c:SetViewAngles(ang)
end



--= FAS Punch angles =-- 
local function punch()
        if wep() == NULL then return Angle() end
        if string.find(string.lower(wep():GetClass()), "fas2") or hl2() then
                return me:GetPunchAngle()
        end
        return Angle()
end


--= Aimbot =-- 
local function aimbot(c)
        me.voice_battery = 100
        mouse(c)
        local ult = angles(c) - punch()
        ult.p = ult.p > 180 and ult.p - 360 or ult.p
        ult.r = 0
        setang(c,ult)
        if me:GetMoveType() == MOVETYPE_WALK then
                local side = Vector(c:GetForwardMove(), c:GetSideMove(), 0)
                side = ((side:GetNormal()):Angle() + (c:GetViewAngles() - ms)):Forward() * side:Length()
                c:SetForwardMove(side.x)
                c:SetSideMove(side.y)
        end
end
hook.Add("CreateMove","aimbot",aimbot)


--= Calcview =-- 
local function calc(ply,origin,angles)
        local view = {}
        view.angles = ms
        view.vm_angles = ms
        view.origin = origin
        view.fov = 100 
        return view
end
hook.Add("CalcView","calc",calc)
 
local w,h = ScrW()*0.48,ScrH()*0.01


--= ESP =--
local function Text_ESP()
  local players = player.GetAll()
  --if ESP_ON then
    for k,v in pairs(players) do
      if v != me and v:IsValid() and v:Alive() then
        local sname = v:Nick()
        local nigger = (v:EyePos()):ToScreen()
        local rank = v:GetUserGroup()
        txt( sname, "TargetIDSmall", nigger.x, nigger.y, color_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP )
        if rank == "user" then
          txt( "", "TargetIDSmall", nigger.x, nigger.y -10, color_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP )
        elseif 
          txt( "[" .. rank .. "]", "TargetIDSmall", nigger.x, nigger.y -10, color_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP ) then
        end
      end
    end
  --end
end
hook.Add( "HUDPaint", "Text_ESP", Text_ESP )  
















--[[

Xray

--]]

--= Materials =--
local storedColors = {};
local storedMaterials = {};
local storedRenderModes = {};



--= Finding Mats =--
local function setIfNonExistant(ent)
  if(!storedMaterials[ent] and !storedColors[ent]) then
    storedMaterials[ent] = ent:GetMaterial();
    storedColors[ent] = ent:GetColor();
    storedRenderModes[ent] = ent:GetRenderMode();
  end
end





--= Xray =--
local function XRay()
  for i,v in pairs( ents.GetAll() ) do
    if v:IsValid() then
      setIfNonExistant(v);
      if v:GetClass() == "prop_physics" then
        v:SetColor( Color( 8, 188, 62, 100 ) )
        v:SetMaterial( "mat2" )
        v:SetRenderMode(RENDERMODE_TRANSALPHA)
      end
    end
  end
end

local function XRay2()
  for i,v in pairs( ents.GetAll() ) do
    if v:IsValid() then
      setIfNonExistant(v);
      if v:GetClass() == "player" then
        v:SetColor( Color( 8, 74, 188, 200 ) )
        v:SetMaterial( "mat2" )
        v:SetRenderMode(RENDERMODE_TRANSALPHA)
      end
    end
  end
end

local function XRay3()
  for i,v in pairs( ents.GetAll() ) do
    if v:IsValid() then
      setIfNonExistant(v);
      if v:GetClass() == "gmod_button" then
        v:SetColor( Color( 154, 44, 10, 100 ) )
        v:SetMaterial( "mat2" )
        v:SetRenderMode( RENDERMODE_TRANSALPHA )
      end
    end
  end
end


--= Setting mats to its original color =--
local function TurnOffXRay()
  for i,v in pairs(ents.GetAll()) do
    if(IsValid(v)) then
      if(storedMaterials[v]) then
        v:SetMaterial(storedMaterials[v]);
      end
      if(storedColors[v]) then
        v:SetColor(storedColors[v]);
      end
      if(storedRenderModes[v]) then
        v:SetRenderMode(storedRenderModes[v]);
      end
    end
  end
  storedColors = {};
  storedMaterials = {};
  storedRenderModes = {};
end


concommand.Add("styles_xray", function(client, command, arguments)
    if(xRayOn) then
      hook.Remove( "RenderScene", "XRay" )
      hook.Remove( "RenderScene", "XRay2" )
      hook.Remove( "RenderScene", "XRay3" );
      TurnOffXRay();
      xRayOn = false;
    else
      hook.Add( "RenderScene", "XRay", XRay )
      hook.Add( "RenderScene", "XRay2", XRay2 )
      hook.Add( "RenderScene", "XRay3", XRay3 )
      xRayOn = true;
  end
end )