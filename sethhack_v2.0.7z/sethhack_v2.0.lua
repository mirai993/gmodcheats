--I sense anger in seths ass....

if( SERVER ) then return end
 
package.loaded.wshl = nil
 
TEAM_CONNECTING =       0
TEAM_UNASSIGNED =       1001
TEAM_SPECTATOR  =       1002
 
include("includes/init.lua")
include("includes/extensions/table.lua")
 
require("datastream")
 
local SH = {}
 
SH.cmds   = {}
SH.hooks  = {}
SH.sqlite = {}
 
SH.aimfriends = {}
SH.aimteams = {}
SH.teamlist = {}
 
SH.traitors = {}
SH.admins = {}
 
SH.esp_ents = {}
 
SH.vars = {
        aim = false,
        bhop  = false,
        speed = false,
        firing = false,
        aimtarg = nil,
        tlock = false,
        menuh = 285,
        menuw = 378,
}
 
SH.aimmodels = {
        ["models/combine_scanner.mdl"] = "Scanner.Body",
        ["models/hunter.mdl"] = "MiniStrider.body_joint",
        ["models/combine_turrets/floor_turret.mdl"] = "Barrel",
        ["models/dog.mdl"] = "Dog_Model.Eye",
        ["models/antlion.mdl"] = "Antlion.Body_Bone",
        ["models/antlion_guard.mdl"] = "Antlion_Guard.Body",
        ["models/antlion_worker.mdl"] = "Antlion.Head_Bone",
        ["models/zombie/fast_torso.mdl"] = "ValveBiped.HC_BodyCube",
        ["models/zombie/fast.mdl"] = "ValveBiped.HC_BodyCube",
        ["models/headcrabclassic.mdl"] = "HeadcrabClassic.SpineControl",
        ["models/headcrabblack.mdl"] = "HCBlack.body",
        ["models/headcrab.mdl"] = "HCFast.body",
        ["models/zombie/poison.mdl"] = "ValveBiped.Headcrab_Cube1",
        ["models/zombie/classic.mdl"] = "ValveBiped.HC_Body_Bone",
        ["models/zombie/classic_torso.mdl"] = "ValveBiped.HC_Body_Bone",
        ["models/zombie/zombie_soldier.mdl"] = "ValveBiped.HC_Body_Bone",
        ["models/combine_strider.mdl"] = "Combine_Strider.Body_Bone",
        ["models/lamarr.mdl"] = "HeadcrabClassic.SpineControl"
}
 
SH.funcs = {
        ForceCVar = SH_SETCVAR,
        hl2_ucmd_getprediction = hl2_ucmd_getprediction,
        hl2_shotmanip = hl2_shotmanip,
        ModuleVer = SH_MODULEVERSION or 0
}
 
//local ofcv = SH.funcs.ForceCVar
//function SH.funcs.ForceCVar(cv, str)
        //if(string.find(GetHostName(), "ExiledServers") || string.find(GetHostName(), "SniperBoys") || string.find(GetHostName(), "[BG] Biased")) then
                //if(ValidEntity(LocalPlayer())) then
                     //   LocalPlayer():ChatPrint("Speedhack is disabled due to anticheat. Sorry!");
               // end
              //  return
       // end
        //return ofcv(cv, str)
//end
 
SH.cvars = {
        { "_sh_esp", 1,},
        { "_sh_esp_dist", 7500 },
        { "_sh_esp_extdist", 2500 },
        { "_sh_esp_colorvisible", 0 },
        { "_sh_esp_showdist", 1 },
        { "_sh_esp_showgangs", 1 },
        { "_sh_showadmins", 1 },
        { "_sh_wallhack", 1 },
        { "_sh_wallhack_dist", 2048 },
        { "_sh_entwallhack", 1 },
        { "_sh_esp_filter", "" },
        { "_sh_esp_traceent", 0 },
        { "_sh_chams", 0 },
        { "_sh_speedhack_speed", 7 },
        { "_sh_friendlyfire", 1 },
        { "_sh_nospread", 1 },
        { "_sh_maxfov", 180 },
        { "_sh_antisnap", 0 },
        { "_sh_antisnapspeed", 2 },
        { "_sh_targetplayers", 1 },
        { "_sh_targetnpcs", 1 },
        { "_sh_targettraitors", 0 },
        { "_sh_ignorefriends", 0 },
        { "_sh_ignorenowep", 0 },
        { "_sh_aim_filter", "" },
        { "_sh_dclos", 0 },
        { "_sh_aimoffset", 0 },
        { "_sh_misshots", 0 },
        { "_sh_triggerbot", 1 },
        { "_sh_triggerbot_as", 0 },
        { "_sh_predict", 1 },
        { "_sh_predictlevel", 45 },
        { "_sh_autoreload", 1 },
        { "_sh_logging", 0 },
        { "_sh_thirdperson", 0 },
        { "_sh_thirdperson_dist", 10 },
        { "_sh_fullbright", 0 },
        { "_sh_blockrcc", 0 },
        { "_sh_fov", 0 },
        { "_sh_disablecalcview", 0 },
        { "_sh_showips", 1 },
        { "_sh_ulxungag", 1 },
        { "_sh_panicmode", 0 },
        { "_sh_enabled", 1 },
}
 
SH.tvars = {}
 
SH_SETCVAR = nil
SH_MODULEVERSION = nil
SH_RUNSCRIPT = nil
hl2_ucmd_getprediction = nil
hl2_shotmanip = nil
 
local oRCC  = RunConsoleCommand
local oECC  = engineConsoleCommand
 
local oMsgN = MsgN
local oPCC  = _R.Player.ConCommand
 
local oCVGI = _R.ConVar.GetInt
local oCVGB = _R.ConVar.GetBool
local oGCVN = GetConVarNumber
local oGCVS = GetConVarString
 
local oC  = table.Copy( concommand )
local oT  = table.Copy( timer )
local oH  = table.Copy( hook )
local oCV = table.Copy( cvars )
local oS  = table.Copy( sql )
local oSR = table.Copy( string )
local oM  = table.Copy( math )
local oF  = table.Copy( file )
local oD  = table.Copy( debug )
local oHTTP = table.Copy( http )
local oUM = table.Copy( usermessage )
local oDS = table.Copy( datastream )
 
local oRQE = require
local oINC = include
 
local player = player
local ents = ents
 
local me = nil
local MFrame = nil
 
local EyeAngles = EyeAngles
local tostring = tostring
local tonumber = tonumber
local EyePos = EyePos
local ipairs = ipairs
local pairs = pairs
local print = print
local pcall = pcall
local getmetatable = getmetatable
local setmetatable = setmetatable
local AddConsoleCommand = AddConsoleCommand
 
local PD_Float = 0
 
print("SethHack V2 Loaded. Module version " .. SH.funcs.ModuleVer .. ".");
 
if( !oS.TableExists("SethHackV2_Options") ) then
        oS.Query("CREATE TABLE SethHackV2_Options( Option varchar(255), Value varchar(255), PRIMARY KEY(Option) )")
end
 
if( !oS.TableExists("SethHackV2_ESPEnts") ) then
        oS.Query("CREATE TABLE SethHackV2_ESPEnts( Ent TEXT, PRIMARY KEY(Ent) )")
end
 
function SH.sqlite.SetVar( option, value )
        oS.Query( string.format("REPLACE INTO SethHackV2_Options ( Option, Value ) VALUES ( '%s', '%s' )", tostring( option ), tostring( value ) ) )
end
 
function SH.sqlite.NewQuery(qy, ...)
        oS.Query(string.format(qy, ...));
end
 
function SH.sqlite.GetVar( option )
        local tab = oS.Query("SELECT * FROM SethHackV2_Options") or {}
        for k, v in pairs( tab ) do
                if( v.Option == option ) then
                        return v.Value
                end
        end
end
 
local function randomString()
        math.randomseed(CurTime());
        local ret = "";
        local len = math.random(5, 25);
        for i = 0, len do
                local ch = string.char(math.random(97, 122));
                ret = ret .. ch;
        end
        ret = ret .. "shcvar";
        return ret;
end
 
for k, v in pairs( SH.cvars ) do
        local nn = randomString();
        CreateClientConVar( nn, SH.sqlite.GetVar( v[1] ) or v[2], false, false );
        SH.tvars[v[1]] = {}
        SH.tvars[v[1]][1] = type( v[1] ) == "number" && GetConVarNumber( nn ) || GetConVarString( nn )
        SH.tvars[v[1]][2] = nn;
        oCV.AddChangeCallback(nn, function( cvar, old, new )
                SH.tvars[v[1]][1] = new
                SH.sqlite.SetVar( v[1], new )
        end )
        oC.Add(v[1], function(ply, cmd, args)
                if(args[1]) then
                        RunConsoleCommand(nn, args[1]);
                else
                        print(v[1], GetConVarNumber(nn));
                end
        end);
end
 
function SH.funcs.GetCVNum( cvar )
        return tonumber( SH.tvars[cvar][1] or 0 )
end
 
function SH.funcs.GetCVStr( cvar )
        return tostring( SH.tvars[cvar][1] or "" )
end
 
local q = oS.Query("SELECT * FROM SethHackV2_ESPEnts")
if(q && type(q) == "table" && #q >=1) then
        for k, v in pairs(q) do
                if(v.Ent) then
                        table.insert(SH.esp_ents, v.Ent)
                        print("Loaded custom ent " .. v.Ent .. " from SQL.");
                end
        end
end
 
/* Hooks and ConCommands */
local oldHookCall = hook.Call
 
local function newHookCall( name, gm, ... )
        if( SH.hooks[ name ] && SH.funcs.GetCVNum("_sh_panicmode") != 1) then
                oH.Call( name, gm, unpack( arg ) )
                return SH.hooks[ name ]( unpack( arg ) )
        end
        return oH.Call( name, gm, unpack( arg ) )
end
 
hook = {}
 
setmetatable( hook, 
        { __index = function( t, k )
                if( k == "Call" ) then 
                        return newHookCall      
                end
                return oH[ k ] end,
                
                __newindex = function( t, k, v ) 
                        if( k == "Call" ) then 
                                if( v != newHookCall ) then 
                                        oldHookCall = v 
                                end 
                                return
                        end
                        oH[k] = v 
                end,
                __metatable = true
        }
)
 
setmetatable( _G, 
        {       
                __index = function(t, k)
                        if(k == "concommand") then
                                return oC;
                        end
                        if(k == "require") then
                                return oRQE;
                        end
                        if(k == "include") then
                                return oINC;
                        end
                end,
                __metatable = true;
        }
)
 
local PD_SafeModules = {}
table.insert( PD_SafeModules, "includes/modules/gm_sqlite.dll")
table.insert( PD_SafeModules, "includes/modules/gm_sqlite_linux.dll")
table.insert( PD_SafeModules, "includes/modules/gm_sqlite_osx.dll")
 
function engineConsoleCommand( ply, cmd, args )
        local lc = oSR.lower( cmd )
        if( SH.cmds[lc] ) then
                SH.cmds[lc]( ply, cmd, args )
                return true
        end
        return oECC( ply, cmd, args )
end
 
function SH:RegisterHook( name, func )
        SH.hooks[ name ] = func
end
 
function SH:RegisterCommand( name, func )
        SH.cmds[ name ] = func
        AddConsoleCommand( name )
end
 
/* Anti-detection */
function file.Exists( fn, ad )
        if( !fn ) then return end
        if( oSR.find( fn, "sethhack.lua" ) || oSR.find( fn, "wshl.dll" ) || oSR.find( fn, "deco.dll" ) || oSR.find( fn, "libcurl.dll" ) || oSR.find( fn, "zlib1.dll") || oSR.find( fn, "YOUR DLL")) then
                return
        end
        if( SH.funcs.GetCVNum("_sh_logging") == 1 ) then
                print("file.Exists: " .. fn )
        end
        return oF.Exists( fn, ad )
end
 
//function file.IsDir( dir )
        //if( !dir ) then return end
       // print("file.IsDir:", dir)
       // if( dir == "../materials/SethHack" || dir == "../materials/SHV2" ) then 
       //         print("file.IsDir blocked")
         //       return 
       // end
       // return oF.IsDir( dir )
//end

 
function file.Read( fn, ad )
        if( !fn ) then return end
        if( oSR.find( fn, "sethhack.lua" ) || oSR.find( fn, "wshl.dll" ) || oSR.find( fn, "deco.dll" ) || oSR.find( fn, "libcurl.dll" ) || oSR.find( fn, "zlib1.dll") ) then
                return
        end
        if( SH.funcs.GetCVNum("_sh_logging") == 1 ) then
                print("file.Read: " .. fn )
        end
        return oF.Read( fn, ad )
end
 
function file.Size( fn )
        if( !fn ) then return end
        if( oSR.find( fn, "sethhack.lua" ) || oSR.find( fn, "wshl.dll" ) || oSR.find( fn, "deco.dll" ) || oSR.find( fn, "libcurl.dll" ) || oSR.find( fn, "zlib1.dll") ) then
                return -1
        end
        if( SH.funcs.GetCVNum("_sh_logging") == 1 ) then
                print("file.Size: " .. fn )
        end
        return oF.Size( fn )
end
 
function file.Time( fn )
        if( !fn ) then return end
        if( oSR.find( fn, "sethhack.lua" ) || oSR.find( fn, "wshl.dll" ) || oSR.find( fn, "deco.dll" ) || oSR.find( fn, "libcurl.dll" ) || oSR.find( fn, "zlib1.dll") ) then
                return 0
        end
        if( SH.funcs.GetCVNum("_sh_logging") == 1 ) then
                print("file.Time: " .. fn )
        end
        return oF.Time( fn )
end
 
function file.Find( fn )
        local tab = oF.Find( fn )
        for k, v in pairs( tab ) do
                if( oSR.find( v, "sethhack.lua" ) || oSR.find( v, "wshl.dll" ) || oSR.find( v, "deco.dll" ) || oSR.find( v, "SHV2" ) || oSR.find( fn, "libcurl.dll" ) || oSR.find( fn, "zlib1.dll") ) then
                        table.remove( tab, k )
                end
        end
        if( SH.funcs.GetCVNum("_sh_logging") == 1 ) then
                print("file.Find: " .. fn )
        end
        return tab
end
 
function file.FindInLua( fn )
        local tab = oF.FindInLua( fn )
        for k, v in pairs( tab ) do
                if( oSR.find( v, "sethhack.lua" ) || oSR.find( v, "wshl.dll" ) || oSR.find( v, "deco.dll" ) || oSR.find( fn, "libcurl.dll" ) || oSR.find( fn, "zlib1.dll") ) then
                        table.remove( tab, k )
                end
        end
        if( SH.funcs.GetCVNum("_sh_logging") == 1 ) then
                print("file.FindInLua: " .. fn )
        end
        return tab
end
 
// DS
 
function datastream.StreamToServer( handler, data, callback )
        if( SH.funcs.GetCVNum("_sh_logging") == 1 ) then
                print("datastream:", handler)
        end
        return oDS.StreamToServer( handler, data, callback )
end
 
//Convars
function GetConVarNumber( cvar )
        if( cvar == "sv_cheats" ) then return 0 end
        if( cvar == "sv_scriptenforcer" ) then return 1 end
        if( cvar == "host_timescale" ) then return 1 end
        if( cvar == "sv_allow_voice_from_file" ) then return 0 end
        if( cvar == "r_drawothermodels" ) then return 1 end
        return oGCVN( cvar )
end
 
function GetConVarString( cvar )
        if( cvar == "sv_cheats" ) then return "0" end
        if( cvar == "sv_scriptenforcer" ) then return "1" end
        if( cvar == "host_timescale" ) then return "1" end
        if( cvar == "sv_allow_voice_from_file" ) then return "0" end
        if( cvar == "r_drawothermodels" ) then return "1" end
        return oGCVS( cvar )
end
 
function _R.ConVar.GetInt( cvar )
        if( cvar:GetName() == "sv_cheats" ) then return 0 end
        if( cvar:GetName() == "sv_scriptenforcer" ) then return 1 end
        if( cvar:GetName() == "host_timescale" ) then return 1 end
        if( cvar:GetName() == "sv_allow_voice_from_file" ) then return 0 end
        if( cvar:GetName() == "r_drawothermodels" ) then return 1 end
        return oCVGI( cvar )
end
 
function _R.ConVar.GetBool( cvar )
        if( cvar:GetName() == "sv_cheats" ) then return false end
        if( cvar:GetName() == "sv_scriptenforcer" ) then return true end
        if( cvar:GetName() == "host_timescale" ) then return true end
        if( cvar:GetName() == "sv_allow_voice_from_file" ) then return false end
        if( cvar:GetName() == "r_drawothermodels" ) then return true end
        return oCVGB( cvar )
end
 
local blockRCC = {"_____b__c", "___m", "sc", "bg", "bm", "kickme", "gw_iamacheater", "imafaggot", "birdcage_browse"}
 
function RunConsoleCommand( cmd, ... )
        if(table.HasValue(blockRCC, cmd)) then 
                //print("RCC Blocked: " .. cmd)
                return 
        end
        
        if( SH.funcs.GetCVNum("_sh_logging") == 1 && !oSR.find( cmd, "sh_" ) && oSR.find(cmd, "shcvar") && !oSR.find( cmd, "wire_keyboard_press" ) && !oSR.find( cmd, "cnc" ) ) then
                print("RunConsoleCommand: ", cmd, ... )
        end
        if( cmd == "debug_init_callback" ) then
                local c = tostring(PD_Float)
                local e = ".dll"
                local r = ""
                for k, v in pairs( PD_SafeModules ) do
                        if( v:sub( -4, -1 ) == e ) then
                                if( r != "" ) then r = r .. "|" end
                                r = r .. util.CRC( c .. v )
                        end
                end
                return oRCC( cmd, c, r )
        end
        if( SH.funcs.GetCVNum("_sh_blockrcc") != 1 || oSR.find( cmd, "sh_" ) || oSR.find( cmd, "shcvar") ) then
                return oRCC( cmd, ... )
        end
end
 
function _R.Player.ConCommand( ply, cmd )
        if( SH.funcs.GetCVNum("_sh_logging") == 1 && !oSR.find( cmd, "sh_" ) && !oSR.find(cmd, "shcvar") && !oSR.find( cmd, "wire_keyboard_press" ) && !oSR.find( cmd, "cnc" ) ) then
                print("RunConsoleCommand: " .. cmd )
        end
        if( SH.funcs.GetCVNum("_sh_blockrcc") != 1 || oSR.find( cmd, "sh_" ) || oSR.find(cmd, "shcvar") ) then
                return oPCC( ply, cmd )
        end
end
 
function sql.TableExists( tbl )
        if( tbl == "SethHackV2_Options" ) then return false end
        return oS.TableExists( tbl )    
end
 
function cvars.AddChangeCallback(cvar, callback)
        if(cvar == "sv_cheats" || cvar == "host_timescale" || cvar == "r_drawothermodels") then return end
        print("cvars.AddChangeCallback:", tostring(cvar));
        return oCV.AddChangeCallback(cvar, callback)
end
 
function debug.getinfo(func)
        if(SH.funcs.GetCVNum("_sh_logging") == 1) then
                print("Debug.getinfo")
        end
        local nt = {
                nups = 0,
                what = "C",
                func = "function: 0x00000",
                lastlinedefined = -1,
                source = "[C]",
                currentline = -1,
                namewhat = "",
                linedefined = -1,
                short_src = "[C]"
        }
        return nt
end
 
function string.Find(str, pat, ind, plain)
        if(str == "+sh_menu" && pat == "menu") then
                return false
        end
        return oSR.Find(str, pat, ind, plain)
end
 
function usermessage.IncomingMessage( name, um, ... )
        if( name == "ttt_role" ) then
                SH.traitors = {}
        end
        if( name == "debug_start" ) then
                PD_Float = um:ReadFloat()
        end
        return oUM.IncomingMessage( name, um, ... )
end
 
if( SH.funcs.GetCVNum("_sh_enabled") != 1 ) then
        print("SH Disabled..")
        return
end
 
oT.Create("SH.checkMe", .1, 0, function()
        if( LocalPlayer():IsValid() ) then
                me = LocalPlayer()
                g_LocalPlayer = me
                oT.Destroy("SH.checkMe")
        end
end )
 
function SH:SetVar( var, val )
        SH.vars[var] = val
end
 
/* Bunnyhop */
function SH.Bunnyhop()
        if( SH.vars["bhop"] ) then
                if( me:OnGround() ) then
                        oRCC("+jump")
                        oT.Simple( .1, function() oRCC("-jump") end )
                end
        end
end
 
SH:RegisterCommand("+sh_bhop", function() SH:SetVar("bhop",true) end )
SH:RegisterCommand("-sh_bhop", function() SH:SetVar("bhop",false) end )
SH:RegisterHook( "Think", SH.Bunnyhop )
 
local tWeps = {"weapon_ttt_c4", "weapon_ttt_knife", "weapon_ttt_phammer", "weapon_ttt_sipistol"};
local safe_GetWeapons = _R.Player.GetWeapons    
 
function SH.Tick()
        if(!ValidEntity(me)) then return end
        _G.NAUGHTY_PLAYER = false //gangwars
        if( ulx && ulx.gagUser ) then
                if( SH.funcs.GetCVNum("_sh_ulxungag") == 1 ) then
                        ulx.gagUser(false)
                end
        end
        for k, v in pairs( SH.traitors ) do
                if( !ValidEntity( v ) ) then
                        table.remove( SH.traitors, k )
                end
        end
        for k, v in pairs( SH.admins ) do
                if( !ValidEntity( v ) ) then
                        table.remove( SH.admins, k )
                end
        end
        for k, v in ipairs( player.GetAll() ) do
                if( v:Alive() && !table.HasValue( SH.traitors, v ) ) then
                        for x, y in pairs(safe_GetWeapons(v)) do
                                if(ValidEntity(y)) then
                                        if(table.HasValue(tWeps, y:GetClass())) then
                                                table.insert( SH.traitors, v )
                                                chat.AddText( Color( 100, 100, 100 ), "[SethHack] ", Color( 255, 10, 10 ), v:Nick() .. " is a traitor!" )
                                        end
                                end
                        end
                end
                if(v:IsAdmin() && !table.HasValue(SH.admins, v) && v != me) then
                        table.insert(SH.admins, v)
                        chat.AddText( Color( 100, 100, 100 ), "[SethHack] ", Color( 0, 255, 255 ), "Admin " .. v:Nick() .. " has joined!" )
                        surface.PlaySound("buttons/blip1.wav")
                end
        end
end
SH:RegisterHook("Tick", SH.Tick )
 
SH:RegisterCommand("sh_print_traitors", function()
        oMsgN("Traitors:")
        for k, v in pairs( SH.traitors ) do
                oMsgN("Name: " .. v:Nick() )
        end
end )
 
/* Wallhack */
function SH.Wallhack()
        if( !me ) then return end
        if( SH.funcs.GetCVNum("_sh_wallhack") != 1 ) then return end
        cam.Start3D( EyePos(), EyeAngles() )
                for k, v in ipairs( ents.GetAll() ) do
                        if( ValidEntity( v ) && v != me ) then
                                local valid = ((v:IsPlayer() && v:Alive() && v:Health() > 0) || (v:IsNPC() && v:GetMoveType() != 0) || table.HasValue(SH.esp_ents, v:GetClass()));
                                if(!valid) then continue; end
                                if ( v:GetPos() - me:GetPos() ):Length() <= SH.funcs.GetCVNum("_sh_wallhack_dist") then
                                        cam.IgnoreZ( true )
                                                v:DrawModel()
                                        cam.IgnoreZ( false )
                                end
                        end
                end
        cam.End3D()
end
 
SH:RegisterHook("RenderScreenspaceEffects", SH.Wallhack )
 
/* ESP */
function SH.ESP()
        if( !me ) then return end
        if( SH.funcs.GetCVNum("_sh_esp") != 1 ) then return end
        for k, v in ipairs( player.GetAll() ) do
                local dist = v:GetPos():Distance( me:GetPos() )
                if( ValidEntity( v ) && v:Alive() && v != me && dist < SH.funcs.GetCVNum("_sh_esp_dist") ) then
                        if(SH.funcs.GetCVStr("_sh_esp_filter") != "") then
                                if(!string.find(string.lower(v:Nick()), string.lower(SH.funcs.GetCVStr("_sh_esp_filter")))) then
                                        continue;
                                end
                        end
                        
                        local pos = v:EyePos():ToScreen()
                        local rank = ""
                        local wep = ""
                        if( v:IsAdmin() ) then rank = " [A]" end 
                        if( v:IsSuperAdmin() ) then rank = " [SA]" end
                        if( ValidEntity( v:GetActiveWeapon() ) ) then
                                wep = v:GetActiveWeapon():GetPrintName().." | "
                                wep = string.gsub( wep, "#HL2_", "" )
                                wep = string.gsub( wep, "#GMOD_", "" )
                        end
                        local esp_col = team.GetColor(v:Team())
                        local traitor = table.HasValue( SH.traitors, v ) && "*TRAITOR* " || ""
                        if( traitor != "" ) then esp_col = Color(255,0,0,255) end
                        traitor = (v:GetNWString("gang_name") != "" && SH.funcs.GetCVNum("_sh_esp_showgangs") == 1) && v:GetNWString("gang_name") .. " | " || ""
                        if( SH.funcs.GetCVNum("_sh_esp_colorvisible") == 1 && SH.funcs.HasLOS( v ) ) then esp_col = Color(255,0,0,255) end
                        
                        draw.SimpleTextOutlined( traitor .. v:Nick() .. rank, "DefaultSmall", pos.x - 30, pos.y - 20, esp_col, TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT, .6, Color( 30, 30, 30, 165 ) )
                        if( dist < SH.funcs.GetCVNum("_sh_esp_extdist") ) then
                                local d = (SH.funcs.GetCVNum("_sh_esp_showdist") == 1) && " | D: " .. math.Round(tostring(dist)) || ""
                                draw.SimpleTextOutlined( wep .. v:Health() .. "hp" .. d, "DefaultSmall", pos.x - 30, pos.y - 8, esp_col, TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT, .6, Color( 30, 30, 30, 165 ) )
                        end
                end
        end
        
        for _, v in ipairs( ents.GetAll() ) do
                for k, t in pairs( SH.esp_ents ) do
                        if( v:IsValid() && v:GetClass() == t ) then
                                local pos = v:GetPos() + Vector( 0, 0, 50 )
                                pos = pos:ToScreen()
                                draw.SimpleTextOutlined( t, "DefaultSmall", pos.x - 30, pos.y - 8, Color( 255, 0, 0, 255 ), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT, .6, Color( 30, 30, 30, 165 ) )                    
                        end
                end
                
                if(SH.funcs.GetCVNum("_sh_esp_traceent") == 1) then
                        local trace = util.TraceLine(util.GetPlayerTrace(me))
                        if(ValidEntity(trace.Entity)) then
                                surface.SetFont("HUDNumber")
                                surface.SetTextColor(100, 255, 100, 255)
                                surface.SetTextPos(ScrW() / 2 - 200, ScrH() / 2 - 450)
                                surface.DrawText(trace.Entity:GetClass())
                        end
                end
        end
end
 
function SH.Info()
        local w = ScrW() / 2 - 28
        local h = ScrH() / 2 + 15
        if( SH.vars.aim && !SH.vars.aimtarg ) then
                draw.SimpleTextOutlined( "Scanning...", "TargetIDSmall", w, h, Color( 255, 0, 0, 255 ), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT, .5, Color( 30, 30, 30, 165 ) )
        elseif( SH.vars.aim && ValidEntity( SH.vars.aimtarg ) ) then
                if( SH.vars.aimtarg:IsPlayer() && SH.vars.aimtarg:Alive() || SH.vars.aimtarg:IsNPC() && SH.vars.aimtarg:GetMoveType() != 0 ) then
                        w = w + 10
                        draw.SimpleTextOutlined( "Locked!", "TargetIDSmall", w, h, Color( 25, 255, 25, 255 ), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT, .5, Color( 30, 30, 30, 165 ) )
                end
        end
        
        if( SH.funcs.GetCVNum("_sh_showadmins") == 1 ) then
                local admins = {}
                local int = 0
                for k, v in ipairs( player.GetAll() ) do
                        if( v:IsAdmin() && v:IsSuperAdmin() ) then
                                table.insert( admins, v:Nick() .. " (SA)" )
                        elseif( v:IsAdmin() && !v:IsSuperAdmin() ) then
                                table.insert( admins, v:Nick() .. " (A)" )
                        end
                end
                local txtsize = surface.GetTextSize( table.concat( admins ) ) / 3
                draw.RoundedBox( 1, ScrW() - 200, ScrH() - ScrH() + 15, 150, 30 + txtsize, Color( 0, 0, 0, 150 ) )
                draw.SimpleText("Admins", "ScoreboardText", ScrW() - 155, ScrH() - ScrH() + 16, Color( 255, 255, 255, 255 ) )
                for k, v in pairs( admins ) do
                        draw.SimpleText(v, "ScoreboardText", ScrW() - 155, ScrH() - ScrH() + 35 + int, Color( 255, 255, 255, 255 ) )
                        int = int + 15
                end
        end
end
 
function SH.HUDPaint()
        SH.ESP()
        SH.Info()
end
 
SH:RegisterHook( "HUDPaint", SH.HUDPaint )
 
/* Speedhack */
function SH.Speedhack()
        SH.funcs.ForceCVar( CreateConVar( "sv_cheats", ""), "1" )
        if( SH.vars.speed ) then
                SH.funcs.ForceCVar( CreateConVar( "host_timescale", ""), SH.funcs.GetCVStr("_sh_speedhack_speed") )
        else
                SH.funcs.ForceCVar( CreateConVar( "host_timescale", ""), "1" )
        end
        speed = !speed
end
 
SH:RegisterCommand("+sh_speed", function() SH:SetVar("speed",true ) SH.Speedhack() end )
SH:RegisterCommand("-sh_speed", function() SH:SetVar("speed",false ) SH.Speedhack() end )
 
SH:RegisterCommand("sh_togglevar", function(ply, cmd, args)
        local cc = args[1];
        if(!cc) then
                print("invalid format");
                return;
        end
        
        local cn = SH.tvars[cc]
        if(!cn) then
                print("invalid cvar");
                return;
        end
        
        cn = cn[2];
        
        if(GetConVarNumber(cn) == 0) then
                RunConsoleCommand(cn, 1);
        else
                RunConsoleCommand(cn, 0);
        end
end)
        
SH:RegisterCommand("sh_togglespeed", function() 
        if( !SH.vars.speed ) then
                oRCC("+sh_speed")
        else
                oRCC("-sh_speed")
        end
end )
 
local SetButtons = _R["CUserCmd"].SetButtons
local GetButtons = _R["CUserCmd"].GetButtons
 
function SH.Autoreload( uc )
        if( !me ) then return end
        if( SH.funcs.GetCVNum("_sh_autoreload") != 1 ) then return end
        if( me:Alive() && me:GetActiveWeapon() && me:GetActiveWeapon():IsValid() ) then
                if( me:GetActiveWeapon():Clip1() <= 0 ) then
                        SetButtons( uc, GetButtons( uc ) | IN_RELOAD )
                end
        end
end 
 
local CustomCones = {}
CustomCones["#HL2_SMG1"]        = Vector( -0.04362, -0.04362, -0.04362 )
CustomCones["#HL2_Pistol"]      = Vector( -0.0100, -0.0100, -0.0100 )
CustomCones["#HL2_Pulse_Rifle"] = Vector( -0.02618, -0.02618, -0.02618 )
CustomCones["#HL2_Shotgun"]     = Vector( -0.08716, -0.08716, -0.08716 )
 
/* No-spread */
function SH.funcs.PredictSpread( cmd, aimAngle )
        local cmd2, seed = SH.funcs--hl2_ucmd_getprediction( cmd )
        local currentseed = 0, 0, 0
        if( cmd2 != 0 ) then currentseed = seed end
        local wep = me:GetActiveWeapon()
        local vecCone, valCone = Vector( 0, 0, 0 )
        if( ValidEntity( wep ) ) then
                if( wep.Initialize || (wep.Base && wep.Base == "weapon_perp_base")) then
                        valCone = wep.Primary && wep.Primary.Cone || 0
                        if( tonumber( valCone ) ) then
                                vecCone = Vector( -valCone, -valCone, -valCone )
                        elseif( type( valCone ) == "Vector" ) then
                                vecCone = -1 * valCone
                        end
                else
                        local pn = wep:GetPrintName()
                        if( CustomCones[pn] ) then vecCone = CustomCones[pn] end
                end
        end
        return SH.funcs.hl2_shotmanip( currentseed || 0, ( aimAngle || me:GetAimVector():Angle() ):Forward(), vecCone ):Angle()
end
 
function SH.funcs.GetShootPos( ent )
        local eyes = ent:LookupAttachment("eyes")
        if( eyes != 0 ) then
                eyes = ent:GetAttachment( eyes )
                if( eyes && eyes.Pos ) then
                        return eyes.Pos, eyes.Ang
                end
        end
        local bone = ent:LookupBone( SH.aimmodels[ ent:GetModel() ] || "ValveBiped.Bip01_Head1")
        local pos, ang = ent:GetBonePosition( bone )
        return pos, ang
end
 
function SH.funcs.HasLOS( ent )
        if( SH.funcs.GetCVNum("_sh_dclos") == 1 ) then return true end
        local trace = { start = me:GetShootPos(), endpos = ent:GetBonePosition( ent:LookupBone("ValveBiped.Bip01_Head1") ), filter = { me, ent }, mask = 1174421507 }
        local tr = util.TraceLine( trace )
        return( tr.Fraction == 1 )
end
 
function SH.funcs.HasLOS2( ent )
        local trace = { start = me:GetShootPos(), endpos = ent:GetBonePosition( ent:LookupBone("ValveBiped.Bip01_Head1") ), filter = { me, ent }, mask = 1174421507 }
        local tr = util.TraceLine( trace )
        return( tr.Fraction == 1 )
end
 
function SH.funcs.CanShoot( ent )
        if( !ValidEntity( ent ) || !ent:IsNPC() && !ent:IsPlayer() || me == ent ) then return false end
        if( ent:GetMoveType() == 0 ) then return false end
        if( ent:IsPlayer() && !ent:Alive() ) then return false end
        if( ent:IsPlayer() && ent:Health() <= 0 ) then return false end
        //if( ent:IsPlayer() && ent:InVehicle() ) then return false end
        if(ent:IsPlayer() && SH.funcs.GetCVNum("_sh_targettraitors") == 1 && #SH.traitors > 0 && !table.HasValue(SH.traitors, ent)) then return false end
        if( ent:IsPlayer() && ent:Team() == me:Team() && SH.funcs.GetCVNum("_sh_friendlyfire") != 1 ) then return false end
        if( ent:IsPlayer() && SH.funcs.GetCVNum("_sh_targetplayers") != 1 ) then return false end
        if( ent:IsNPC() && SH.funcs.GetCVNum("_sh_targetnpcs") != 1 ) then return false end
        if( ent:IsPlayer() && SH.funcs.GetCVNum("_sh_ignorefriends") == 1 && ent:GetFriendStatus() == "friend" ) then return false end
        if( ent:IsPlayer() && SH.funcs.GetCVNum("_sh_ignorenowep") == 1 && !ValidEntity(ent:GetActiveWeapon()) ) then return false end
        if( ent:IsPlayer() && SH.funcs.GetCVStr("_sh_aim_filter") != "" ) then
                if(!string.find(string.lower(ent:Nick()), string.lower(SH.funcs.GetCVStr("_sh_aim_filter")))) then 
                        return false
                end
        end
        
        if( ent:IsPlayer() && table.HasValue( SH.aimfriends, ent ) ) then return false end
        if( ent:IsPlayer() ) then
                for k, v in pairs( SH.aimteams ) do
                        if( v == team.GetName( ent:Team() ) ) then
                                return false
                        end
                end
        end
        local fov = SH.funcs.GetCVNum("_sh_maxfov")
        if( fov != 180 ) then
                local lpang = me:GetAngles()
                local ang = ( ent:GetPos() - me:GetPos() ):Angle()
                local ady = math.abs( math.NormalizeAngle( lpang.y - ang.y ) )
                local adp = math.abs( math.NormalizeAngle( lpang.p - ang.p ) )
                if( ady > fov || adp > fov ) then return false end
        end
        return true
end
 
function SH.funcs.GetAimTarg()
        if( SH.funcs.CanShoot( SH.vars.aimtarg ) && SH.funcs.HasLOS( SH.vars.aimtarg ) ) then return SH.vars.aimtarg else SH.vars.aimtarg = nil end
        local position = me:EyePos()
        local angle = me:GetAimVector()
        local tar = { 0, 0 }
        local tab = SH.funcs.GetCVNum("_sh_targetnpcs") == 1 && ents.GetAll() || player.GetAll()
        for k, v in ipairs( tab ) do
                if( SH.funcs.CanShoot( v ) && SH.funcs.HasLOS( v ) ) then
                        local plypos = v:EyePos()
                        local difr = ( plypos - position ):Normalize()
                        difr = difr - angle
                        difr = difr:Length()
                        difr = math.abs( difr )
                        if( difr < tar[2] || tar[1] == 0 ) then
                                tar = { v, difr }       
                        end     
                end
        end
        return tar[1]
end
 
/* Triggerbot */
function SH.Triggerbot( uc )
        if( SH.funcs.GetCVNum("_sh_triggerbot") != 1 ) then return end
        if(!ValidEntity(me)) then return end
        if( !me:Alive() ) then return end
        local ent = me:GetEyeTrace().Entity;
        
        if((SH.vars.tlock && SH.vars.aim && ValidEntity(SH.vars.aimtarg) && SH.funcs.HasLOS2(SH.vars.aimtarg)) || (SH.funcs.GetCVNum("_sh_triggerbot_as") == 1 && ValidEntity(ent) && (ent:IsPlayer() || ent:IsNPC()) && SH.funcs.CanShoot(ent)) && !SH.vars.firing) then
                oRCC("+attack")
                SH:SetVar("firing",true)
                oT.Simple( me:GetActiveWeapon().Primary and me:GetActiveWeapon().Primary.Delay or 0.05, function()
                        oRCC("-attack")
                        SH:SetVar("firing",false)
                end )
        end
end
 
SH:RegisterCommand("+sh_triggerbot", function()
        oRCC("_sh_triggerbot", "1");
end);
 
SH:RegisterCommand("-sh_triggerbot", function()
        oRCC("_sh_triggerbot", "0");
end);
 
function SH.funcs.Antisnap( ang )
        ang.p = math.NormalizeAngle( ang.p )
        ang.y = math.NormalizeAngle( ang.y )
        lpang = me:EyeAngles()
        lpang.p = math.Approach(lpang.p, ang.p, SH.funcs.GetCVNum("_sh_antisnapspeed"))
        lpang.y = math.Approach(lpang.y, ang.y, SH.funcs.GetCVNum("_sh_antisnapspeed"))
        lpang.r = 0
        ang = lpang
        return ang      
end
 
local SetViewAngles = _R["CUserCmd"].SetViewAngles
 
/* Aimbot */
function SH.Aimbot( uc )
        if( !me ) then return end       
        if( !SH.vars.aim ) then return end
        
        local ply = SH.funcs.GetAimTarg()
        
        if( ply == 0 ) then SH.vars.tlock = false return end
        
        SH:SetVar("aimtarg",ply)
        
        local pos, ang = SH.funcs.GetShootPos( ply )
        local spos = me:GetShootPos()
        
        if(SH.funcs.GetCVNum("_sh_predict") == 1) then
                local pr = SH.funcs.GetCVNum("_sh_predictlevel")
                pos = pos + ( ply:GetVelocity() / pr - me:GetVelocity() / pr ) - Vector( 0, 0, SH.funcs.GetCVNum("_sh_aimoffset") )
        end
        
        if( SH.funcs.GetCVNum("_sh_misshots") == 1 && me:KeyDown( IN_ATTACK ) && math.random( 1, 5 ) == 1 ) then 
                pos = pos - Vector( 15, 15, 15 ) 
        end
        
        ang = ( pos-spos ):Angle()
        
        if( SH.funcs.GetCVNum("_sh_nospread") == 1 ) then
                ang = SH.funcs.PredictSpread( uc, ang )
        end
        
        ang.p = math.NormalizeAngle( ang.p )
        ang.y = math.NormalizeAngle( ang.y )
        
        if( SH.funcs.GetCVNum("_sh_antisnap") == 1 ) then
                ang = SH.funcs.Antisnap( ang )
        end
        
        ang.r = 0
        
        SH:SetVar("tlock",true)
        
        SetViewAngles( uc, ang )
end
 
SH:RegisterCommand("+sh_aim", function() SH:SetVar("aim",true) end )
SH:RegisterCommand("-sh_aim", function() 
        SH:SetVar("aim",false) SH:SetVar("aimtarg",nil)
end )
 
SH:RegisterCommand("sh_toggleaim", function() 
        if( !SH.vars.aim ) then
                SH:SetVar("aim",true)
        else
                SH:SetVar("aim",false)
                SH:SetVar("aimtarg",nil)
        end
end )
 
function SH.CreateMove( uc )
        SH.Aimbot( uc )
        SH.Triggerbot( uc )
        SH.Autoreload( uc )
end
 
SH:RegisterHook("CreateMove", SH.CreateMove )
 
function SH.CalcView( ply, pos, angles, fov )
        if( !me ) then return end
        if( ValidEntity( me:GetActiveWeapon() ) && me:GetActiveWeapon().Primary && SH.funcs.GetCVNum("_sh_panicmode") != 1) then
                me:GetActiveWeapon().Primary.Recoil = 0
        end
        if( SH.funcs.GetCVNum("_sh_disablecalcview") == 1 ) then
                return GAMEMODE:CalcView( ply, pos, angles, fov )
        end
        if( SH.funcs.GetCVNum("_sh_thirdperson") == 1 ) then
                return( { origin = pos - ( angles:Forward() * ( 50 + SH.funcs.GetCVNum("_sh_thirdperson_dist") ) ) } )
        end
        if( SH.funcs.GetCVNum("_sh_fov") != 0 ) then
                return( { fov = SH.funcs.GetCVNum("_sh_fov") } )
        end
        return GAMEMODE:CalcView( ply, pos, angles, fov )
end
 
SH:RegisterHook("CalcView", SH.CalcView )
 
/* Force initial convars */
function SH.InitPostEntity()
        SH.funcs.ForceCVar( CreateConVar( "sv_cheats", ""), "1" ) // Commented out for KAC
        SH.funcs.ForceCVar( CreateConVar( "sv_allow_voice_from_file", ""), "1" )
        if( SH.funcs.GetCVNum("_sh_fullbright") == 1 ) then
                SH.funcs.ForceCVar( CreateConVar( "sv_cheats", ""), "1" )
                SH.funcs.ForceCVar( CreateConVar( "mat_fullbright", ""), "1" )
        end
        if( SH.funcs.GetCVNum("_sh_chams") == 1 ) then
                SH.funcs.ForceCVar( CreateConVar( "sv_cheats", ""), "1" )
                SH.funcs.ForceCVar( CreateConVar( "r_drawothermodels", ""), "2" )
        end
        
        for k, v in pairs( team.GetAllTeams() ) do
                if( k != 0 && k != 1001 && k != 1002 ) then
                        table.insert( SH.teamlist, v )
                end
        end
end
 
SH:RegisterHook("InitPostEntity", SH.InitPostEntity )
 
cvars.AddChangeCallback(SH.tvars["_sh_fullbright"][2], function( cvar, old, new )
        SH.funcs.ForceCVar( CreateConVar( "sv_cheats", ""), "1" )
        SH.funcs.ForceCVar( CreateConVar( "mat_fullbright", ""), tostring( new ) )
end )
 
cvars.AddChangeCallback(SH.tvars["_sh_chams"][2], function( cvar, old, new )
        SH.funcs.ForceCVar( CreateConVar( "sv_cheats", ""), "1" )
        SH.funcs.ForceCVar( CreateConVar( "r_drawothermodels", ""), tostring( new + 1 ) )
end )
 
function SH.ThirdPerson_SDLP()
        return( SH.funcs.GetCVNum("_sh_thirdperson") == 1 )
end
 
SH:RegisterHook( "ShouldDrawLocalPlayer", SH.ThirdPerson_SDLP )
 
function SH.funcs.AddTracePlayer()
        if(!ValidEntity(me)) then return end
        local ent = me:GetEyeTrace().Entity
        if(!ValidEntity(ent) || !ent:IsPlayer()) then return end
        
        if(table.HasValue(SH.aimfriends, ent)) then
                for k, v in pairs(SH.aimfriends) do
                        if(v == ent) then
                                table.remove(SH.aimfriends, k)
                                break
                        end
                end
        else
                table.insert(SH.aimfriends, ent)
        end
 
        me:ChatPrint("Added/Removed " .. ent:Nick() .. " to friends!")
end
 
SH:RegisterCommand("sh_addtracebuddy", SH.funcs.AddTracePlayer)
 
function SH.funcs.RunScripts()
        for k, v in pairs(file.FindInLua('shrun/*.lua')) do
                local rf = file.Read('../lua/shrun/' .. v);
                RunString(rf);
                print("Running:", v);
        end
end
 
SH:RegisterCommand("sh_runscripts", SH.funcs.RunScripts)
 
local function fentsGetAll()
        local t = {}
        for k, v in ipairs(ents.GetAll()) do
                if(!ValidEntity(v)) then
                        continue;
                end
                if(!table.HasValue(t, v:GetClass())) then
                        table.insert(t, v:GetClass())
                end
        end
        return t
end
 
function SH.funcs.AddBackground( panel,w,h )
        local backg = vgui.Create("DImage", panel )
        //backg:SetMaterial( Material( "SHV2/menu_backg.vtf" ) )
        backg:SetPos(0,0)
        backg:SetSize(w,h)
end
 
function SH.funcs.CreateOption( dtype, parent, tooltip, o1, o2, o3, o4, o5, o6, o7, o8 )
        if( dtype == "Checkbox" ) then
                dtype = "DCheckBoxLabel"
                local text, cvar, x, y = o1, o2, o3, o4
                local dele = vgui.Create( dtype, parent )
                dele:SetText( text )
                dele:SetConVar( SH.tvars[cvar][2] )
                dele:SetValue( SH.funcs.GetCVNum( cvar ) )
                dele:SetPos( x, y )
                dele:SizeToContents()
                dele:SetTextColor( color_white )
                if( tooltip != "" ) then
                        dele:SetTooltip( tooltip )
                end
        elseif( dtype == "Slider" ) then
                dtype = "DNumSlider"
                local text, cvar, dec, min, max, wide, x, y = o1, o2, o3, o4, o5, o6, o7, o8
                local dele = vgui.Create( dtype, parent )
                dele:SetPos( x, y )
                dele:SetWide( wide )
                dele:SetText( text )
                dele:SetMin( min )
                dele:SetMax( max )
                dele:SetDecimals( dec )
                dele:SetConVar( SH.tvars[cvar][2] )
                if( tooltip != "" ) then
                        dele:SetTooltip( tooltip )
                end
        elseif( dtype == "Label" ) then
                dtype = "DLabel"
                local text, x, y = o1, o2, o3
                local dele = vgui.Create( dtype, parent )
                dele:SetPos( x, y )
                dele:SetText( text )
                dele:SizeToContents()
                dele:SetTextColor( color_white )
        end
end
 
function SH.Menu()
        local PTab = {}
        local tabs = {}
        
        local MenuH = SH.vars.menuh
        local MenuW = SH.vars.menuw
        
        for k, v in pairs( SH.aimfriends ) do
                if( !ValidEntity( v ) ) then
                        table.remove( SH.aimfriends, k )
                end
        end
        
        MFrame = vgui.Create( "DPropertySheet" )
        MFrame:SetParent( MFrame )
        MFrame:SetPos( ScrW() / 2 - 185, ScrH() / 2 - 133 )
        MFrame:SetSize( MenuW, MenuH )
        MFrame:SetFadeTime( .8 )
        MFrame:SetVisible( true )
        MFrame:MakePopup()
        function MFrame:Paint() 
                draw.RoundedBox( 0, 0, 0, self:GetWide(), self:GetTall(), Color( 0, 0 ,0 ,220 ) ) 
        end
        
        /* Menu Tabs */
        tabs.aimbot = vgui.Create("DLabel", MFrame )
        tabs.aimbot:SetPos(0,0)
        tabs.aimbot:SetText("")
        SH.funcs.AddBackground( tabs.aimbot, MenuW, MenuH )
        
        tabs.friends = vgui.Create("DLabel", MFrame )
        tabs.friends:SetPos(0,0)
        tabs.friends:SetText("")
        SH.funcs.AddBackground( tabs.friends, MenuW, MenuH )
        
        tabs.teams = vgui.Create("DLabel", MFrame )
        tabs.teams:SetPos(0,0)
        tabs.teams:SetText("")
        SH.funcs.AddBackground( tabs.teams, MenuW, MenuH )
        
        tabs.espents = vgui.Create("DLabel", MFrame)
        tabs.espents:SetPos(0,0)
        tabs.espents:SetText("")
        SH.funcs.AddBackground(tabs.espents, MenuW, MenuH)
        
        tabs.esp = vgui.Create("DLabel", MFrame )
        tabs.esp:SetPos(0,0)
        tabs.esp:SetText("")
        SH.funcs.AddBackground( tabs.esp, MenuW, MenuH )
        
        tabs.misc = vgui.Create("DLabel", MFrame )
        tabs.misc:SetPos(0,0)
        tabs.misc:SetText("")
        SH.funcs.AddBackground( tabs.misc, MenuW, MenuH )
        
        tabs.info = vgui.Create("DLabel", MFrame )
        tabs.info:SetPos(0,0)
        tabs.info:SetText("")
        SH.funcs.AddBackground( tabs.info, MenuW, MenuH )
 
        /* Background and bar for first tab */
        local shlogo = vgui.Create( "DImage", tabs.aimbot )
        //shlogo:SetImage("SHV2/menu_logo.vtf")
        shlogo:SetSize( 256, 256 )
        shlogo:SetPos( 130, -110 )
        
        local mbar = vgui.Create( "DImage", tabs.aimbot )
        //mbar:SetImage("SHV2/menu_bar.vtf")
        mbar:SetSize( 256, 256 )
        mbar:SetPos( -125, -110 )
        
        MFrame:AddSheet( "Aimbot", tabs.aimbot, nil, false, false )
        MFrame:AddSheet( " Friends", tabs.friends, nil, false, false )
        MFrame:AddSheet( " Teams", tabs.teams, nil, false, false )
        MFrame:AddSheet( "ESP Ents", tabs.espents, nil, false, false )
        MFrame:AddSheet( "ESP/Wallhack", tabs.esp, nil, false, false )
        MFrame:AddSheet( " Misc", tabs.misc, nil, false, false )
        MFrame:AddSheet( " Info", tabs.info, nil, false, false )
        
        /* Options for aimbot tab */
        SH.funcs.CreateOption( "Checkbox", tabs.aimbot, "Automatically fires when locked on to an enemy", "Triggerbot", "_sh_triggerbot", 5, 30 )
        SH.funcs.CreateOption( "Checkbox", tabs.aimbot, "Automatically fires when looking at an enemy (does not require aimbot)", "Triggerbot (Always Shoot)", "_sh_triggerbot_as", 5, 50 )
        SH.funcs.CreateOption( "Checkbox", tabs.aimbot, "Predicts the spread on weapons, making them more accurate", "Nospread", "_sh_nospread", 5, 70 )
        SH.funcs.CreateOption( "Checkbox", tabs.aimbot, "Smoothly turns your aim to face the target", "Antisnap", "_sh_antisnap", 5, 90 )
        SH.funcs.CreateOption( "Checkbox", tabs.aimbot, "Allows the aimbot to target members of your team", "Friendly Fire", "_sh_friendlyfire", 5, 110 )
        SH.funcs.CreateOption( "Checkbox", tabs.aimbot, "Allows the aimbot to target players", "Target Players", "_sh_targetplayers", 5, 130 )
        SH.funcs.CreateOption( "Checkbox", tabs.aimbot, "Allows the aimbot to target NPCs", "Target NPCs", "_sh_targetnpcs", 5, 150 )
        SH.funcs.CreateOption( "Checkbox", tabs.aimbot, "Stops the aimbot from targetting Steam friends", "Ignore Steam Friends", "_sh_ignorefriends", 5, 170 )
        SH.funcs.CreateOption( "Checkbox", tabs.aimbot, "Makes some shots miss to make the aimbot appear more legit", "Randomly Miss Shots", "_sh_misshots", 5, 190 )
        SH.funcs.CreateOption( "Checkbox", tabs.aimbot, "Do not target players who don't have a weapon", "Ignore Weaponless Players", "_sh_ignorenowep", 5, 210 )
        SH.funcs.CreateOption( "Checkbox", tabs.aimbot, "Allows the aimbot to target people through walls and other objects", "Don't check LOS", "_sh_dclos", 5, 230 )
 
        SH.funcs.CreateOption( "Slider", tabs.aimbot, "Targets a certain amount down from the target's head", "Aim Offset", "_sh_aimoffset", 1, 0, 50, 150, 200, 110 )
        SH.funcs.CreateOption( "Slider", tabs.aimbot, "Controls how far around your aimbot can target people (degrees)", "Max FOV", "_sh_maxfov", 0, 1, 180, 150, 200, 155 )
        SH.funcs.CreateOption( "Slider", tabs.aimbot, "Controls the speed of the Antisnap", "Antisnap Speed", "_sh_antisnapspeed", 1, 0, 20, 150, 200, 200 )
        
        SH.funcs.CreateOption( "Label", tabs.friends, nil, "Friends", 50, 10 )
        SH.funcs.CreateOption( "Label", tabs.friends, nil, "Players", 260, 10 )
        
        SH.funcs.CreateOption( "Label", tabs.teams, nil, "Whitelist", 50, 10 )
        SH.funcs.CreateOption( "Label", tabs.teams, nil, "Teams", 260, 10 )
        
        SH.funcs.CreateOption( "Label", tabs.espents, nil, "List", 50, 10 )
        SH.funcs.CreateOption( "Label", tabs.espents, nil, "Entities", 260, 10 )
        
        SH.funcs.CreateOption( "Checkbox", tabs.esp, "Show player's name, health, weapon, and more above their head", "ESP", "_sh_esp", 5, 5 )
        SH.funcs.CreateOption( "Checkbox", tabs.esp, "Colors visible players red on the ESP", "Color Visible Players", "_sh_esp_colorvisible", 5, 25 )
        SH.funcs.CreateOption( "Checkbox", tabs.esp, "Allows you to see players and NPCs through walls and other objects", "Wallhack", "_sh_wallhack", 5, 45 )
        SH.funcs.CreateOption( "Checkbox", tabs.esp, "Removes all dark places from the map, making everything bright", "Fullbright", "_sh_fullbright", 5, 65 )
        SH.funcs.CreateOption( "Checkbox", tabs.esp, "Turns players, props, weapons, and more into wireframe", "Wireframe Chams", "_sh_chams", 5, 85 )
        SH.funcs.CreateOption( "Checkbox", tabs.esp, "Shows a list of admins and superadmins in the top right of the screen", "Show Admins", "_sh_showadmins", 5, 105 )
        SH.funcs.CreateOption( "Checkbox", tabs.esp, "Shows the current trace entity at the top of your screen", "Show Trace Entity", "_sh_esp_traceent", 5, 125 )
        SH.funcs.CreateOption( "Checkbox", tabs.esp, "Shows a players distance on the esp", "Show Distance", "_sh_esp_showdist", 5, 145 )
        SH.funcs.CreateOption( "Checkbox", tabs.esp, "Shows custom entities through walls and other objects", "Entity Wallhack", "_sh_entwallhack", 5, 165 )
        SH.funcs.CreateOption( "Checkbox", tabs.esp, "Shows players GangWars gangs", "Show GangWars Gangs", "_sh_esp_showgangs", 5, 185 )
        
        SH.funcs.CreateOption( "Slider", tabs.esp, "The maximum distance that players can be for the ESP to show them", "ESP Distance", "_sh_esp_dist", 0, 1, 25000, 150, 200, 120 )
        SH.funcs.CreateOption( "Slider", tabs.esp, "The maximum distance that players can be for the ESP to show extra info", "ESP Extra Info Dist.", "_sh_esp_extdist", 0, 1, 25000, 150, 200, 165 )
        SH.funcs.CreateOption( "Slider", tabs.esp, "The maximum distance that players can be for the Wallhack to show them", "Wallhack Distance", "_sh_wallhack_dist", 0, 1, 25000, 150, 200, 205 )
        
        SH.funcs.CreateOption( "Checkbox", tabs.misc, "Automatically reloads your weapon when you have no ammo", "Autoreload", "_sh_autoreload", 5, 5 )
        SH.funcs.CreateOption( "Checkbox", tabs.misc, "Blocks RunConsoleCommand and :ConCommand() from being used", "Block RunConsoleCommand", "_sh_blockrcc", 5, 25 )
        SH.funcs.CreateOption( "Checkbox", tabs.misc, "Puts your view into thirdperson mode", "Thirdperson", "_sh_thirdperson", 5, 45 )
        SH.funcs.CreateOption( "Checkbox", tabs.misc, "Logs functions such as RunConsoleCommand and file.Exists", "Logging", "_sh_logging", 5, 65 )
        SH.funcs.CreateOption( "Checkbox", tabs.misc, "Show Player's IPs in the console when they connect", "Show IPs", "_sh_showips", 5, 85 )
        SH.funcs.CreateOption( "Checkbox", tabs.misc, "Disables custom view", "Disable CalcView", "_sh_disablecalcview", 5, 105 )
        SH.funcs.CreateOption( "Checkbox", tabs.misc, "Bypass ULX's gag (voicemute) system", "Bypass ULX Gag", "_sh_ulxungag", 5, 125 )
        SH.funcs.CreateOption( "Checkbox", tabs.misc, "Turn off every single SethHack feature", "Panic Mode", "_sh_panicmode", 5, 145 )
        
        SH.funcs.CreateOption( "Slider", tabs.misc, "Your view's field-of-view (FOV). Set to 0 to disable", "Field-Of-View", "_sh_fov", 0, 0, 90, 150, 200, 120 )
        SH.funcs.CreateOption( "Slider", tabs.misc, "The distance that the thirdperson camera is from yourself", "Thirdperson Distance", "_sh_thirdperson_dist", 0, 0, 200, 150, 200, 165 )
        SH.funcs.CreateOption( "Slider", tabs.misc, "The speed of the speedhack", "Speedhack Speed", "_sh_speedhack_speed", 2, 1, 25, 150, 200, 205 )
        
        /* Friends List */
        local FriendsList
        local function FList()
                FriendsList = vgui.Create( "DComboBox", tabs.friends )
                FriendsList:SetPos( 225, 30 )
                FriendsList:SetSize( 110, 175 )
                FriendsList:SetMultiple( false )
                for k, v in pairs( player.GetAll() ) do
                        if( v != me && !table.HasValue( SH.aimfriends, v ) ) then
                                FriendsList:AddItem( v:Nick() )
                        end
                end
        end
        FList()
        
        local FriendsListC
        local function FListC()
                FriendsListC = vgui.Create( "DComboBox", tabs.friends )
                FriendsListC:SetPos( 20, 30 )
                FriendsListC:SetSize( 110, 175 )
                FriendsListC:SetMultiple( false )
                for k, v in pairs( SH.aimfriends ) do
                        FriendsListC:AddItem( v:Nick() )
                end     
        end
        FListC()
        
        local FriendsListAdd = vgui.Create("DButton", tabs.friends )
        FriendsListAdd:SetPos( 250, 215 )
        FriendsListAdd:SetText("Add")
        FriendsListAdd.DoClick = function()
                if( FriendsList:GetSelectedItems() && FriendsList:GetSelectedItems()[1] ) then
                        for k, v in pairs( player.GetAll() ) do
                                if( v:Nick() == FriendsList:GetSelectedItems()[1]:GetValue() ) then
                                        table.insert( SH.aimfriends, v )
                                        me:ChatPrint("Added " .. v:Nick() )     
                                end     
                        end     
                end
                FList()
                FListC()
        end
                
        local FriendsListRem = vgui.Create("DButton", tabs.friends )
        FriendsListRem:SetPos( 45, 215 )
        FriendsListRem:SetText("Remove")
        FriendsListRem.DoClick = function()
                if( FriendsListC:GetSelectedItems() && FriendsListC:GetSelectedItems()[1] ) then
                        for k, v in pairs( SH.aimfriends ) do 
                                if( v:Nick() == FriendsListC:GetSelectedItems()[1]:GetValue() ) then
                                        table.remove( SH.aimfriends, k )
                                        me:ChatPrint("Removed " .. v:Nick() )   
                                end     
                        end
                end
                FListC()
                FList()
        end
        
        local function TList()
                TeamList = vgui.Create( "DComboBox", tabs.teams )
                TeamList:SetPos( 225, 30 )
                TeamList:SetSize( 110, 175 )
                TeamList:SetMultiple( false )
                for k, v in pairs( SH.teamlist ) do
                        if( !table.HasValue( SH.aimteams,v.Name ) ) then
                                TeamList:AddItem( v.Name )
                        end     
                end
        end
        TList()
        
        local TeamListC
        local function TListC()
                TeamListC = vgui.Create( "DComboBox", tabs.teams )
                TeamListC:SetPos( 20, 30 )
                TeamListC:SetSize( 110, 175 )
                TeamListC:SetMultiple( false )
                for k, v in pairs( SH.aimteams ) do
                        TeamListC:AddItem( v )  
                end
        end
                
        TListC()
                
        local TeamListAdd = vgui.Create("DButton", tabs.teams )
        TeamListAdd:SetPos( 250, 215 )
        TeamListAdd:SetText("Add")
        TeamListAdd.DoClick = function()
                if( TeamList:GetSelectedItems() && TeamList:GetSelectedItems()[1] ) then
                        for k, v in pairs( SH.teamlist ) do 
                                if( v.Name == TeamList:GetSelectedItems()[1]:GetValue() ) then
                                        table.insert( SH.aimteams, v.Name )
                                        me:ChatPrint("Added " .. v.Name )       
                                end     
                        end     
                end
                TList()
                TListC()        
        end
                
        local TeamListRem = vgui.Create("DButton", tabs.teams )
        TeamListRem:SetPos( 45, 215 )
        TeamListRem:SetText("Remove")
        TeamListRem.DoClick = function()
                if( TeamListC:GetSelectedItems() && TeamListC:GetSelectedItems()[1] ) then
                        for k, v in pairs( SH.aimteams ) do 
                                if( v == TeamListC:GetSelectedItems()[1]:GetValue() ) then
                                        table.remove( SH.aimteams, k )
                                        me:ChatPrint("Removed " .. v )
                                end
                        end     
                end
                TListC()
                TList()
        end
        
        local function EList()
                EntsList = vgui.Create( "DComboBox", tabs.espents )
                EntsList:SetPos( 225, 30 )
                EntsList:SetSize( 110, 175 )
                EntsList:SetMultiple( false )
                for k, v in pairs( fentsGetAll() ) do
                        if( !SH.esp_ents[v] ) then
                                EntsList:AddItem( v )
                        end     
                end
        end
        EList()
        
        local EntsListC
        local function EListC()
                EntsListC = vgui.Create( "DComboBox", tabs.espents )
                EntsListC:SetPos( 20, 30 )
                EntsListC:SetSize( 110, 175 )
                EntsListC:SetMultiple( false )
                for k, v in pairs( SH.esp_ents ) do
                        EntsListC:AddItem( v )  
                end
        end
                
        EListC()
                
        local EntsListAdd = vgui.Create("DButton", tabs.espents )
        EntsListAdd:SetPos( 250, 215 )
        EntsListAdd:SetText("Add")
        EntsListAdd.DoClick = function()
                if( EntsList:GetSelectedItems() && EntsList:GetSelectedItems()[1] ) then
                        for k, v in pairs( fentsGetAll() ) do 
                                if( v == EntsList:GetSelectedItems()[1]:GetValue() ) then
                                        table.insert(SH.esp_ents, v)
                                        SH.sqlite.NewQuery("REPLACE INTO SethHackV2_ESPEnts(Ent) VALUES('%s')", v);
                                        me:ChatPrint("Added " .. v )
                                end     
                        end     
                end
                EList()
                EListC()        
        end
                
        local EntsListRem = vgui.Create("DButton", tabs.espents )
        EntsListRem:SetPos( 45, 215 )
        EntsListRem:SetText("Remove")
        EntsListRem.DoClick = function()
                if( EntsListC:GetSelectedItems() && EntsListC:GetSelectedItems()[1] ) then
                        for k, v in pairs( SH.esp_ents ) do 
                                if( v == EntsListC:GetSelectedItems()[1]:GetValue() ) then
                                        for x, y in pairs(SH.esp_ents) do if(y == v) then table.remove(SH.esp_ents, tonumber(x)) break; end end
                                        oS.Query("DELETE FROM SethHackV2_ESPEnts WHERE Ent = '" .. v .. "'");
                                        me:ChatPrint("Removed " .. v )
                                end
                        end     
                end
                EListC()
                EList()
        end
        
        local EntsListClr = vgui.Create("DButton", tabs.espents)
        EntsListClr:SetPos(145, 215)
        EntsListClr:SetText("Clear")
        EntsListClr.DoClick = function()
                SH.esp_ents = {}
                oS.Query("DELETE FROM SethHackV2_ESPEnts");
                EListC()
                EList()
        end
        
        local data = [[
       IMMA FUCKING FIRETRUCK~~~~~

        ]]
        
        local ilabel = vgui.Create("DLabel", tabs.info )
        ilabel:SetPos( 10, 5 )
        ilabel:SetText( data )
        ilabel:SizeToContents()
        ilabel:SetTextColor( color_white )
        
end
 
SH:RegisterCommand("sh_togglemenu", function()
        if(MFrame) then
                oRCC("-sh_menu");
        else
                oRCC("+sh_menu");
        end
end)
 
SH:RegisterCommand("+sh_menu", SH.Menu )
SH:RegisterCommand( "-sh_menu", function() 
        if( MFrame ) then 
                MFrame:Remove() MFrame = nil 
        end 
        /* Fixes tooltips staying behind... */
        gui.EnableScreenClicker( false )
        local dframe = vgui.Create("DFrame")
        dframe:SetSize( 0,0 )
        dframe:SetVisible( true )
        dframe:MakePopup()
        oT.Simple( .1, function()
                   dframe:Remove()
        end )
end )