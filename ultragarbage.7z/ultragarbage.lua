// The flame that burns Twice as bright burns half as long.
// And whoever wants to be first must be slave of all UwU.

require( "zxcmodule" )
local registry = ded.PushSpecial( 2 )

// Global functions 
local isstring  = isstring
local istable   = istable
local isnumber  = isnumber
local isbool    = isbool 
local tobool    = tobool
local tostring  = tostring 
local tonumber  = tonumber
local IsValid   = IsValid

local pairs     = pairs
local ipairs    = ipairs

local CurTime   = CurTime
local FrameTime = FrameTime 

local Angle     = Angle 
local Vector    = Vector 
local Player    = Player 
local Entity    = Entity 
local Color     = Color 
local Material  = Material 
 
local IsFirstTimePredicted  = IsFirstTimePredicted 
local ClientsideModel       = ClientsideModel
local CreateMaterial        = CreateMaterial
local GetConVar             = GetConVar
local HSVToColor            = HSVToColor

local RunConCommand = RunConsoleCommand

// Meta tables
local metaAngle    = registry.Angle
local metaVector   = registry.Vector
local metaEntity   = registry.Entity
local metaPlayer   = registry.Player
local metaWeapon   = registry.Weapon
local metaConVar   = registry.ConVar 
local metaCUserCmd = registry.CUserCmd

// Default libs 
local steamworks   = steamworks
local surface      = surface 
local render       = render
local cam          = cam
local math         = math 
local bit          = bit 
local table        = table 
local string       = string
local team         = team
local player       = player
local ents         = ents
local engine       = engine
local util         = util
local vgui         = vgui
local input        = input
local net          = net
local hook         = hook
local gui          = gui
local os           = os

// Lib funcs
local math_Abs                          = math.abs
local math_Acos                         = math.acos
local math_Asin                         = math.asin
local math_Atan                         = math.atan
local math_Atan2                        = math.atan2
local math_Ceil                         = math.ceil
local math_Cos                          = math.cos
local math_Deg                          = math.deg
local math_Floor                        = math.floor
local math_Max                          = math.max
local math_Min                          = math.min
local math_Tan                          = math.tan
local math_Sqrt                         = math.sqrt
local math_Sin                          = math.sin
local math_Random                       = math.random
local math_Randomseed                   = math.randomseed
local math_Rad                          = math.rad
local math_ModF                         = math.modf

local function math_Dist( ax, ay, bx, by )
	local x, y = bx - ax, by - ay

	return x * x + y * y
end

local function math_Average( nums )
    local sum = 0

    for i = 1, #nums do
        sum = sum + nums[ i ]
    end

    return sum / #nums
end

local function math_NormalizeAng( ang )
    return ( a + ang ) % 360 - 180
end

local function math_AngDiff( first, sec )
    local difference = math_NormalizeAng( first - sec )

	return math_Abs( ( difference < 180 ) and difference or difference - 360 )
end

local function math_Rand( min, max )
    return min + ( max - min ) * math_Random()
end

local function math_Round( num, idp )
    local mult = 10 ^ ( idp or 0 )
	return math_Floor( num * mult + 0.5 ) / mult
end

local function math_Clamp( num, min, max )
    return math_Min( math_Max( num, min ), max )
end

local function math_Approach( num, tar, inc )
    return math_Floor( math_Max( num + inc, tar ) )
end

local function math_Lerp( num, tar, inc )
    return math_Floor( math_Max( num + ( tar - num ) * inc ) )
end

local function math_Remap( num, inmax, outmax )
    return math_Ceil( num / inmax * outmax )
end

local bit_Band                          = bit.band
local bit_Bor                           = bit.bor
local bit_Bnot                          = bit.bnot
local bit_Lshift                        = bit.lshift

local surface_CreateFont                = surface.CreateFont
local surface_DrawCircle                = surface.DrawCircle
local surface_DrawLine                  = surface.DrawLine
local surface_DrawOutlinedRect          = surface.DrawOutlinedRect
local surface_DrawPoly                  = surface.DrawPoly
local surface_DrawRect                  = surface.DrawRect
local surface_DrawText                  = surface.DrawText
local surface_DrawTexturedRect          = surface.DrawTexturedRect
local surface_GetTextSize               = surface.GetTextSize
local surface_PlaySound                 = surface.PlaySound
local surface_SetAlphaMultiplier        = surface.SetAlphaMultiplier
local surface_SetDrawColor              = surface.SetDrawColor
local surface_SetFont                   = surface.SetFont
local surface_SetMaterial               = surface.SetMaterial
local surface_SetTextColor              = surface.SetTextColor
local surface_SetTextPos                = surface.SetTextPos

local input_GetCursorPos                = input.GetCursorPos
local input_GetKeyName                  = input.GetKeyName
local input_IsKeyDown                   = input.IsKeyDown
local input_IsMouseDown                 = input.IsMouseDown
local input_LookupBinding               = input.LookupBinding
local input_GetKeyCode                  = input.GetKeyCode
local input_SetCursorPos                = input.SetCursorPos
local input_WasMousePressed             = input.WasMousePressed

local string_find                       = string.find
local string_format                     = string.format
local string_len                        = string.len
local string_lower                      = string.lower
local string_sub                        = string.sub
local string_StartsWith                 = string.StartsWith
local string_Split                      = string.Split
local string_upper                      = string.upper
local lang_GetPhrase                    = language.GetPhrase

local table_concat                      = table.concat
local table_insert                      = table.insert
local table_remove                      = table.remove
local table_sort                        = table.sort
local table_Add                         = table.Add

local render_MaterialOverride           = render.MaterialOverride
local render_SetColorModulation         = render.SetColorModulation
local render_SetBlend                   = render.SetBlend
local render_SuppressEngineLighting     = render.SuppressEngineLighting
local render_DrawBeam                   = render.DrawBeam
local render_SetMaterial                = render.SetMaterial
local render_DrawWireframeBox           = render.DrawWireframeBox
local render_RenderView                 = render.RenderView
local render_Clear                      = render.Clear
local render_BlurRenderTarget           = render.BlurRenderTarget
local render_SetLightingMode            = render.SetLightingMode
local render_SetStencilEnable           = render.SetStencilEnable
local render_SetStencilCompareFunction  = render.SetStencilCompareFunction
local render_SetStencilReferenceValue   = render.SetStencilReferenceValue
local render_DrawScreenQuad             = render.DrawScreenQuad
local render_SetRenderTarget            = render.SetRenderTarget
local render_CopyRenderTargetToTexture  = render.CopyRenderTargetToTexture
local render_SetStencilFailOperation    = render.SetStencilFailOperation
local render_SetStencilZFailOperation   = render.SetStencilZFailOperation
local render_SetStencilPassOperation    = render.SetStencilPassOperation
local render_SetStencilTestMask         = render.SetStencilTestMask
local render_SetStencilWriteMask        = render.SetStencilWriteMask
local render_GetScreenEffectTexture     = render.GetScreenEffectTexture
local render_SetScissorRect             = render.SetScissorRect
local render_DrawTextureToScreen        = render.DrawTextureToScreen
local render_DrawLine                   = render.DrawLine
local render_SetGoalToneMappingScale    = render.SetGoalToneMappingScale
local render_SetModelLighting           = render.SetModelLighting
local render_SetShadowsDisabled         = render.SetShadowsDisabled
local render_DepthRange                 = render.DepthRange
local render_UpdateScreenEffectTexture  = render.UpdateScreenEffectTexture

local cam_Start2D                       = cam.Start2D
local cam_Start3D                       = cam.Start3D
local cam_End2D                         = cam.End2D
local cam_End3D                         = cam.End3D
local cam_IgnoreZ                       = cam.IgnoreZ

local hook_Add                          = hook.Add
local hook_Remove                       = hook.Remove
local hook_GetTable                     = hook.GetTable
local hook_Call                         = hook.Call

local engine_ServerFrameTime            = engine.ServerFrameTime
local util_TraceLine                    = util.TraceLine
local util_TraceHull                    = util.TraceHull
local net_Start                         = net.Start
local net_SendToServer                  = net.SendToServer

local vgui_Create                       = vgui.Create
local vgui_CursorVisible                = vgui.CursorVisible
local gui_EnableScreenClicker           = gui.EnableScreenClicker 
local gui_IsGameUIVisible               = gui.IsGameUIVisible
local gui_OpenURL                       = gui.OpenURL

local team_GetName                      = team.GetName
local team_GetColor                     = team.GetColor
local player_GetAll                     = player.GetAll
local ents_GetAll                       = ents.GetAll

local core = {}

// Screen data 
core.ScreenWidth  = ScrW()
core.ScreenHeight = ScrH()
core.CenterX = math_Floor( core.ScreenWidth / 2 )
core.CenterY = math_Floor( core.ScreenHeight / 2 )

// Convar list 
core.ConVars = {
    "sv_maxusrcmdprocessticks", "sv_namechange_cooldown_seconds", "name", 
    "sv_maxvelocity", "sv_airaccelerate", "sv_accelerate", "sv_friction", "sv_stopspeed", "sv_gravity",
    "r_aspectratio", "cl_forwardspeed", "cl_sidespeed", "climbswep2_maxjumps",
    "sensitivity", "m_yaw", "m_pitch",
}

function core.ListConVar( var, isstr )
    local Obj = GetConVar( var )

    if not Obj then
        core.ConVars[ var ] = false
        return
    end

    core.ConVars[ var ] = {
        var = isstr and Obj:GetString() or Obj:GetFloat(),
        flags = Obj:GetFlags()
    }
end

function core.ForceConVar( var, set )
    ded.ConVarSetFlags( var, 0 )
        RunCommand( var, tostring( set ) )
    ded.ConVarSetFlags( var, core.ConVars[ var ].flags )
end

for i = 1, #core.ConVars do
    core.ListConVar( core.ConVars[ i ] )
end

core.ListConVar( "sv_skyname", true )

// Frequently used
core.ServerRate  = 0 
core.ServerTime  = 0
core.CurTime     = 0
core.FrameTime   = 0 
core.TickCount   = 0 
core.LastCommand = 0
core.TimeString  = ""

core.ServerName = GetHostName()
core.ServerAddr = game_GetIPAddress()
core.ServerMap  = game_GetMap()
core.ServerGM   = engine.ActiveGamemode()

// Math / string vars, temp objects 
core.TempAngle  = Angle()
core.TempVector = Vector()

core.Infinity = 2^1024
core.Radian   = 57.295779513082
core.Pi       = 3.1415926535898

core.VecPattern = "%G %G %G"
core.HexPattern = "#%02X%02X%02X"

// Color extension 
core.CachedColors = {}
core.CachedRamps = {}

function core.SetupColor( r, g, b, a, i )
    i = i or #core.CachedColors + 1
    a = a or 255

    core.CachedColors[ i ] = {  
        r = r, g = g, b = b, a = a,
        x = r / 255, y = g / 255, z = b / 255, q = a / 255, 
    }

    return core.CachedColors[ i ] 
end

function core.SetupRamp( fr, sr, fg, sg, fb, sb, s, a, i )
    i = i or #core.CachedRamps + 1
    a = a or 255
    s = s or 1

    core.CachedRamps[ i ] = {
        fr = fr, sr = sr, fg = fg, sg = sg, fb = fb, sb = sb,
        r = 0, g = 0, b = 0, x = 0, y = 0, z = 0, a = a, q = a / 255,
        s = s
    }

    return core.CachedRamps[ i ], i
end

function core.UpdateRamp( i )
    local col = core.CachedRamps[ i ]
    local sin = math_Abs( math_Sin( core.CurTime * col.s ) )

    col.r = col.fr * ( 1 - Sin ) + col.sr * Sin
    col.g = col.fg * ( 1 - Sin ) + col.sg * Sin
    col.b = col.fb * ( 1 - Sin ) + col.sb * Sin

    col.x = col.r / 255
    col.y = col.g / 255
    col.z = col.b / 255
end

core.Rainbow  = core.SetupColor( 255, 255, 255, 255 )
core.LastTeam = core.SetupColor( 255, 255, 255, 255 )

core.DynamicColors = {
    [ 2 ] = function( i ) return core.Rainbow end,
    [ 3 ] = function( i ) return core.LastTeam end,
    [ 4 ] = function( i ) return core.CachedRamps[ i ] end,
}

function core.GetColor( var )
    local tbl = var[ 1 ]

    if core.DynamicColors[ var[ 2 ] ] then
        tbl = core.DynamicColors[ var[ 2 ] ]( var[ 3 ] )
    end

    return tbl.r, tbl.g, tbl.b, tbl.a
end

function core.GetVector( var )
    local tbl = var[ 1 ]

    if core.DynamicColors[ var[ 2 ] ] then
        tbl = core.DynamicColors[ var[ 2 ] ]( var[ 3 ] )
    end

    return tbl.x, tbl.y, tbl.z
end

// Material optimisation 
core.CachedMaterials = {}

function core.GetMaterial( str )
    if core.CachedMaterials[ str ] then
        return core.CachedMaterials[ str ]
    end

    core.CachedMaterials[ str ] = Material( str )

    return core.CachedMaterials[ str ]
end

// Fonts optimisation
core.Fonts = {}

core.Fonts[ "VerdanaCompact" ] = { font = "Verdana", size = 14 }

for key, val in pairs( core.Fonts ) do
    surface_CreateFont( key, val )
end

// Mouse input 
core.MouseX = 0
core.MouseY = 0
core.MouseF = false

function core.MouseInRect( x, y, w, h, needFocus )
    if needFocus and not core.MouseF then
        return false 
    end 

    w = x + w 
    h = y + h 

    return ( core.MouseX >= x and core.MouseX <= w ) and ( core.MouseY >= y and core.MouseY <= h )
end

// Keyboard input 
core.WasDown = {}
core.IsDown = {}
core.IsPressed = {}

for i = 1, 113 do 
    core.WasDown[ i ] = false
    core.IsDown[ i ] = false
    core.IsPressed[ i ] = false 
end

function core.IsKeyDown( key )
    return ( key >= 107 ) and input_IsMouseDown( key ) or input_IsKeyDown( key )
end

function core.IsBindDown( key )
    return ( not input_LookupBinding( key ) ) and false or input_IsKeyDown( input_GetKeyCode( input_LookupBinding( key ) ) ) 
end 

// Ticks to time 
core.TickInterval = engine.TickInterval()
core.TickRate     = math_Floor( 1 / core.TickInterval )

function core.TimeToTicks( time )
    return math_Floor( 0.5 + time / core.TickInterval )
end

function core.TicksToTime( ticks )
    return core.TickInterval * ticks
end

function core.RoundToTick( Time )
    return core.TicksToTime( core.TimeToTicks( Time ) )
end

// Settings table
local settings = {}

settings.Theme = {
    Background = { core.SetupColor( 16, 16, 16, 255 ), 1, 1 },

    Outline = { core.SetupColor( 72, 72, 72, 255 ), 1, 1 },
    OutlineHighlight = { core.SetupColor( 86, 86, 86, 255 ), 1, 1 },

    Text = { core.SetupColor( 128, 128, 128, 255 ), 1, 1 },
}

// User interface 
core.Context = { x = 0, y = 0, w = 0, h = 0, i = 0 }

core.IsHoveringPanel = false 
core.IsInteracting = false

core.Frames = {}
core.ThemeBoxes = {}

core.UpperPanel = { "Configuration", "Code editor", "Advanced" }

function core.NormalSort( a, b ) 
    return a.LastInteract < b.LastInteract 
end

function core.ReversedSort( a, b ) 
    return a.LastInteract > b.LastInteract 
end

function core.CreateFrame( Name, NumWidth, NumHeight, CanMove, OnDraw, DrawCheck, PostDraw, OnlyDraw )
    local Index = #core.Frames + 1

    core.Frames[ Index ] = {
        UniqueName = Name,

        x = 0,
        y = 0,
        w = NumWidth or 0,     
        h = NumHeight or 0,

        CanMove = isbool( CanMove ) and function() return CanMove end or CanMove,
        CanDraw = false, 
        DrawCheck = DrawCheck,
        OnDraw = OnDraw,
        PostDraw = PostDraw, 

        LastInteract = 0,
        OldX = 0,
        OldY = 0,

        SkipSort = OnlyDraw,
    }

    return Index
end

function core.FindFrame( UniqueName )
    for i = 1, #core.Frames do
        if core.Frames[ i ].UniqueName == UniqueName then
            return core.Frames[ i ]
        end 
    end

    return false
end 

core.ThemeBoxes = {}

function core.StartThemeBox( str )
    if not core.ThemeBoxes[ core.Context.i ] then
        core.ThemeBoxes[ core.Context.i ] = 0
    end

    local Tw, Th = surface_GetTextSize( str )

    surface_SetDrawColor( core.GetColor( settings.Theme.Outline ) )
    surface_DrawOutlinedRect( core.Context.x, core.Context.y, 192, core.ThemeBoxes[ core.Context.i ] )

    surface_SetDrawColor( core.GetColor( settings.Theme.Background ) )
    surface_DrawRect( core.Context.x + 192 / 2 - Tw / 2 - 6, core.Context.y - 6, Tw + 12, Th - 4 )

    surface_SetTextColor( core.GetColor( settings.Theme.Text ) ) 
    surface_SetTextPos( core.Context.x + 192 / 2 - Tw / 2, core.Context.y - 8 )
    surface_DrawText( str )

    core.Context.x = core.Context.x + 4
    core.Context.y = core.Context.y + Th + 14
    core.Context.h = Th + 6
end

function core.EndThemeBox()
    core.ThemeBoxes[ core.Context.i ] = core.Context.h + 3

    core.Context.i = core.Context.i + 1
    core.Context.y = core.Context.y + 4
    core.Context.x = core.Context.x - 4 
end



  



core.MenuStruct = {
    {
        "Combat", 1,
        function( x, y )
            core.StartThemeBox( "str" )
            core.EndThemeBox()

            core.Context.x = core.Context.x + 192 + 4
            core.Context.y = y

            core.StartThemeBox( "str" )
            core.EndThemeBox()

            core.Context.x = core.Context.x + 192 + 4
            core.Context.y = y

            core.StartThemeBox( "str" )
            core.EndThemeBox()

            core.Context.x = core.Context.x + 192 + 4
            core.Context.y = y

            core.StartThemeBox( "str" )
            core.EndThemeBox()
        end
    },
    {
        "Rage", 1,
        function( x, y )

        end
    },
    {
        "Visuals", 1,
        function( x, y )

        end
    },
    {
        "Render", 1,
        function( x, y )

        end
    },
    {
        "Misc", 1,
        function( x, y )

        end
    },
    {
        "Settings", 1,
        function( x, y )

        end
    },
}















 

function core.TabsRender( data, focus )
    local x, y, w, h = data.x, data.y, data.w, data.h 

    surface_SetFont( "VerdanaCompact" )

    surface_SetDrawColor( core.GetColor( settings.Theme.Background ) )
    surface_DrawRect( 0, 0, core.ScreenWidth, 32 )
    surface_SetDrawColor( core.GetColor( settings.Theme.OutlineHighlight ) )
    surface_DrawRect( 0, 28, core.ScreenWidth, 4 )
    surface_SetDrawColor( core.GetColor( settings.Theme.Outline ) )
    surface_DrawRect( 0, 29, core.ScreenWidth, 2 )

    local shift = 2 
    for i = 1, #core.UpperPanel do
        local Tw, Th = surface_GetTextSize( core.UpperPanel[ i ] )

        surface_SetDrawColor( core.GetColor( settings.Theme.OutlineHighlight ) )
        surface_DrawOutlinedRect( shift, 2, Tw + 16, 24, 1 )

        surface_SetTextPos( shift + ( Tw + 16 ) / 2 - Tw / 2, 6 )
        surface_DrawText( core.UpperPanel[ i ] )
        
        if core.MouseInRect( shift, 2, Tw + 16, 24 ) and core.IsPressed[ MOUSE_LEFT ] then
            core.FindFrame( core.UpperPanel[ i ] ).CanDraw = not core.FindFrame( core.UpperPanel[ i ] ).CanDraw
        end

        shift = shift + Tw + 18
    end
end



core.TabW = 792 / #core.MenuStruct
core.CurTab = 1
function core.MenuRender( fdata, focus )
    local x, y, w, h = fdata.x, fdata.y, fdata.w, fdata.h 

    surface_SetFont( "VerdanaCompact" )

    surface_SetDrawColor( core.GetColor( settings.Theme.Background ) )
    surface_DrawRect( x, y, w, h )

    surface_SetDrawColor( core.GetColor( settings.Theme.OutlineHighlight ) )
    surface_DrawOutlinedRect( x, y, w, h, 4 )
    surface_DrawRect( x + 4, y + 28, w - 8, 1 )

    surface_SetDrawColor( core.GetColor( settings.Theme.Outline ) )
    surface_DrawOutlinedRect( x + 1, y + 1, w - 2, h - 2, 2 )
    surface_DrawRect( x + 4, y + 4, w - 8, 24 )

    local shift = x + 4
    for tab = 1, #core.MenuStruct do
        local Tw, Th = surface_GetTextSize( core.MenuStruct[ tab ][ 1 ] )

        local sat = core.CurTab == tab and 128 or 96
        surface_SetTextColor( sat, sat, sat )
        surface_SetDrawColor( sat, sat, sat )

        surface_SetTextPos( shift + core.TabW / 2 - Tw / 2, y + 7 )
        surface_DrawText( core.MenuStruct[ tab ][ 1 ] )

        surface_DrawRect( shift + 2, y + 24, core.TabW - 4, 2 )

        if core.MouseInRect( shift, y + 4, core.TabW, 24 ) and core.IsPressed[ MOUSE_LEFT ] then
            core.CurTab = tab 
        end

        shift = shift + core.TabW
    end

    core.Context.x = x + 10 
    core.Context.y = y + 36
    core.MenuStruct[ core.CurTab ][ 3 ]( x + 10, y + 36 )
end

core.CreateFrame( "Menu", core.ScreenWidth, 32, false, core.TabsRender, false )

core.CreateFrame( "Configuration", 800, 600, true, core.MenuRender, function() return core.FindFrame( "Menu" ).CanDraw end )



// Hooks
local hooks = {}

function hooks.Think()
    core.CurTime     = CurTime()
    core.FrameTime   = FrameTime() 

    for i = 1, 113 do 
        core.IsDown[ i ] = core.IsKeyDown( i ) 
        core.IsPressed[ i ] = core.WasDown[ i ] != core.IsDown[ i ] and not core.IsDown[ i ] 
        core.WasDown[ i ] = core.IsKeyDown( i ) 
    end

    if core.IsPressed[ KEY_DELETE ] then
        core.FindFrame( "Menu" ).CanDraw = not core.FindFrame( "Menu" ).CanDraw
        gui_EnableScreenClicker( core.FindFrame( "Menu" ).CanDraw )
    end
end

function hooks.DrawOverlay()
    local CurrentMouseX, CurrentMouseY = input_GetCursorPos()
    local Frame 

    table_sort( core.Frames, core.ReversedSort )

    local Focused = "Menu" 

    for i = 1, #core.Frames do
        if core.Frames[ i ].SkipSort then 
            continue
        end 

        Focused = core.Frames[ i ].UniqueName 

        break
    end

    table_sort( core.Frames, core.NormalSort )

    core.Context.i = 0

    for i = 1, #core.Frames do
        Frame = core.Frames[ i ]

        if not Frame.CanDraw or ( Frame.DrawCheck and not Frame.DrawCheck() ) then 
            continue 
        end

        core.MouseF = Focused == Frame.UniqueName
        core.Frames[ i ].OnDraw( core.Frames[ i ], Focused == Frame.UniqueName )
    end

    table_sort( core.Frames, core.ReversedSort )

    for i = 1, #core.Frames do
        Frame = core.Frames[ i ]

        if Frame.SkipSort then continue end 

        if Frame.PostDraw then
            Frame.PostDraw()
        end

        if not Frame.CanDraw or ( Frame.DrawCheck and not Frame.DrawCheck() ) then 
            continue 
        end
        
        if core.MouseInRect( Frame.x, Frame.y , Frame.w, Frame.h ) then        
            if input_IsMouseDown( MOUSE_LEFT ) and not core.IsHoveringPanel and not core.InteractActive then
                if ( isbool( Frame.CanMove ) and Frame.CanMove or Frame.CanMove() ) then
                    Frame.x = Frame.x + ( CurrentMouseX - core.MouseX )
                    Frame.y = Frame.y + ( CurrentMouseY - core.MouseY )
                end
                
                Frame.LastInteract = core.CurTime
            end
    
            core.IsHoveringPanel = true
        end
    
        Frame.OldX = Frame.x
        Frame.OldY = Frame.y
    end

    core.IsHoveringPanel = false
    core.InteractActive = false

    core.MouseX = CurrentMouseX
    core.MouseY = CurrentMouseY
end

for key, val in pairs( hooks ) do
    hook_Add( key, key, val )
end