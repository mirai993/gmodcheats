--[[
	autorun/client/mechgear.lua
	tvc | (STEAM_0:1:26814615)
	Date: 19/12/2011 - 03:29:24
]]

--if !MechGear_Module && file.Exists("../lua/includes/modules/gm_mechgear.dll") then
--	require("mechgear")
--end

MechGear = {}
MechGear.Settings = {}
MechGear.SettingsAll = {}

function MechGear.AddSetting(set,def,disp,typ,parent,ext)
	local tab = {}
	tab.Setting = "mechgear_" .. set
	tab.SettingReal = set
	tab.Default = def
	tab.Name = disp
	tab.MenuType = typ
	tab.ExtraInfo = ext
	tab.ConVar = CreateClientConVar("mechgear_" .. set, def, true,false)
	tab.Subs = {}
	if parent then
		if MechGear.SettingsAll[parent] then
			tab.Parent = parent
			tab.ParentTable = MechGear.SettingsAll[parent]
			table.insert(MechGear.SettingsAll[parent].Subs,tab)
		end
	else
		table.insert(MechGear.Settings,tab)
	end
	MechGear.SettingsAll[set]=tab
	
end

function MechGear.AddVGUI(set,disp,typ,parent,ext)
	local tab = {}
	tab.Setting = "mechgear_" .. set
	tab.SettingReal = set
	tab.Name = disp
	tab.MenuType = typ
	tab.ExtraInfo = ext
	tab.Subs = {}
	if parent then
		if MechGear.SettingsAll[parent] then
			tab.Parent = parent
			tab.ParentTable = MechGear.SettingsAll[parent]
			table.insert(MechGear.SettingsAll[parent].Subs,tab)
		end
	else
		table.insert(MechGear.Settings,tab)
	end
	MechGear.SettingsAll[set]=tab
	
end

function MechGear.GetBool(set)
	if MechGear.SettingsAll[set] then
		return MechGear.SettingsAll[set].ConVar:GetBool()
	end
	return false
end

function MechGear.GetInt(set)
	if MechGear.SettingsAll[set] then
		return MechGear.SettingsAll[set].ConVar:GetInt()
	end
	return 0
end

function MechGear.GetString(set)
	if MechGear.SettingsAll[set] then
		return MechGear.SettingsAll[set].ConVar:GetString()
	end
	return ""
end

function MechGear.GetFloat(set)
	if MechGear.SettingsAll[set] then
		return MechGear.SettingsAll[set].ConVar:GetFloat()
	end
	return 0
end

local function createfont(name,s,w,a,i)
	anti,ital = 0,0
	if a then anti = 1 end
	if i then ital = 1 end
	local new_font_name = name .."_".. s .."_".. w .."_".. anti .."_".. ital
	surface.CreateFont(name,s,w,a,i,new_font_name)
	return new_font_name
end

MechGear.AddSetting("mechgear",1,"MechGear","MechGearGlobal")
-- ESP
MechGear.AddSetting("esp",0,"ESP","MechGearGlobal","mechgear")
MechGear.AddSetting("esp_wallhack",1,"Wall Hack","DCheckBoxLabel","esp")
MechGear.AddSetting("esp_showdead",0,"Show Dead","DCheckBoxLabel","esp")
MechGear.AddSetting("esp_spectators",0,"Show Spectators","DCheckBoxLabel","esp")
MechGear.AddSetting("esp_admins",1,"Show Admins","DCheckBoxLabel","esp")
MechGear.AddSetting("esp_useteamcolors",1,"Use Team Colors","DCheckBoxLabel","esp")
MechGear.AddSetting("esp_teammates",1,"Show Team Mates","DCheckBoxLabel","esp")
MechGear.AddSetting("esp_enemys",1,"Show Enemys","DCheckBoxLabel","esp")
MechGear.AddSetting("esp_subtext",1,"Sub Text","DMultiChoice","esp",{"Distance and Health","Weapon Name","Weapon Class","Team Name","Speaking/Muted","Entity Index","User Group","Distance from Crosshair","Real Name","Null"})

MechGear.AddSetting("esp_customents",1,"Custom Entities","DCheckBoxLabel","esp")
MechGear.AddSetting("esp_customents_string","","","DTextEntry","esp")
-- XRay
MechGear.AddSetting("xray",0,"XRay","MechGearGlobal","mechgear")
MechGear.AddSetting("xray_players",1,"Show Players","DCheckBoxLabel","xray")
MechGear.AddSetting("xray_npcs",1,"Show NPCs","DCheckBoxLabel","xray")
MechGear.AddSetting("xray_weapons",1,"Show Weapons","DCheckBoxLabel","xray")
MechGear.AddSetting("xray_fullbright",0,"Fullbright","DCheckBoxLabel","xray")
-- Aimbot
MechGear.AddSetting("aimbot",0,"Aimbot","MechGearGlobal","mechgear")
MechGear.AddSetting("aimbot_onattack",0,"Use Aimbot on +attack","DCheckBoxLabel","aimbot")
MechGear.AddSetting("aimbot_useminimumoncommand",1,"Enable Minimum for +mechgear_shot","DCheckBoxLabel","aimbot")
MechGear.AddSetting("aimbot_minimum",2,"Target Minimum Dis from Crosshair","DNumSlider","aimbot",{Min = 0,Max = 300,Decimals = 0})
-- Thirdperson
MechGear.AddSetting("thirdperson",0,"Thirdperson","MechGearGlobal","mechgear")
MechGear.AddSetting("thirdperson_ignorewalls",0,"Ignore Walls","DCheckBoxLabel","thirdperson")
MechGear.AddSetting("thirdperson_drawplayer",1,"Draw Player","DCheckBoxLabel","thirdperson")
MechGear.AddSetting("thirdperson_length",50,"Length","DNumSlider","thirdperson",{Min = 1,Max = 300,Decimals = 0})
MechGear.AddSetting("thirdperson_ignoreweapons",1,"Ignore Weapons","DCheckBoxLabel","thirdperson")
MechGear.AddSetting("thirdperson_ignoreweapons_string","gmod_tool weapon_physgun weapon_physcannon gmod_camera","","DTextEntry","thirdperson")
-- Crosshair
MechGear.AddSetting("crosshair",0,"Crosshair","MechGearGlobal","mechgear")
MechGear.AddSetting("crosshair_disableold",1,"Disable HL2 Crosshair","DCheckBoxLabel","crosshair")
MechGear.AddSetting("crosshair_eyetrace",0,"Follow Cursor","DCheckBoxLabel","crosshair")
MechGear.AddSetting("crosshair_color","255 0 0 255","Crosshair","DColorMixer","crosshair")
MechGear.AddSetting("crosshair_type",1,"Type","DMultiChoice","crosshair",{"Color Selecter","2 Lines","4 Lines","X Lines","Arrow","Circle"})
-- Spectate
MechGear.AddSetting("spectate",0,"Spectate - UC","MechGearGlobal","mechgear")
MechGear.AddVGUI("spectate_menu","Choose Spectator","DButton","spectate")
-- Encoder
MechGear.AddSetting("encoder",0,"Encoder","MechGearGlobal","mechgear")
MechGear.AddSetting("encoder_code",7,"Code","DNumSlider","encoder",{Min = 1,Max = 255,Decimals = 0})
-- Info
MechGear.AddSetting("developer",0,"Developer","MechGearGlobal","mechgear")
MechGear.AddSetting("developer_positions",1,"Entity Positions","DCheckBoxLabel","developer")
MechGear.AddSetting("developer_entinfo",1,"Entity Info","DCheckBoxLabel","developer")
-- ROFL View - Doesn't really work, and controlling it is hard
MechGear.AddSetting("roflview",0,"ROFL View","DCheckBoxLabel","mechgear")
MechGear.AddSetting("crossbow",0,"Crossbow Bolt Spectator","DCheckBoxLabel","mechgear")
MechGear.AddVGUI("song_list","Song List","DButton","mechgear")


local PANEL = {}

function PANEL:Init()

	self.pnlCanvas 	= vgui.Create( "Panel", self )
	self.pnlCanvas.OnMousePressed = function( self, code ) self:GetParent():OnMousePressed( code ) end
	self.pnlCanvas:SetMouseInputEnabled( true )
	self.pnlCanvas.InvalidateLayout = function() self:InvalidateLayout() end
	
	self.Items = {}
	self.YOffset = 0
	
	self.CheckBoxOpen = true
	
	self.DCheckBox = vgui.Create("DCheckBoxLabel",self)
	self.DCheckBox:SetPos(5,5)
	self.DCheckBox:SetTall(20)
	function self.DCheckBox.OnChange(box,val)
		self.CheckBoxOpen = !val
		self:InvalidateLayout()
		if ValidEntity(MechGear.ConfigMenu) && ValidEntity(MechGear.ConfigMenu.List) then
			MechGear.ConfigMenu.List:InvalidateLayout()
		else
			self:GetParent():InvalidateLayout()
		end
	end
	
	self:SetSpacing( 2 )
	self:SetPadding( 5 )
	self:EnableHorizontal( false )
	self:SetAutoSize( false )
	self:SetDrawBackground( true )
	self:SetBottomUp( false )
	self:SetNoSizing( false )
	
	self:SetMouseInputEnabled( true )
	
	// This turns off the engine drawing
	self:SetPaintBackgroundEnabled( false )
	self:SetPaintBorderEnabled( false )

end

function PANEL:SetCheckBoxInfo(name,convar)
	self.DCheckBox:SetText(name)
	self.DCheckBox:SetConVar(convar)
end

local col = Color(200,50,50,30)
function PANEL:Paint()
	
	local w,h = self:GetSize()
	derma.SkinHook( "Paint", "PanelList", self )
	
	draw.RoundedBox(4,3,3,w - 6,18,col)
	surface.DrawOutlinedRect(0,0,w,h)
	return true
	
end

function PANEL:PerformLayout()

	local Wide = self:GetWide()
	local YPos = 0
	
	if ( !self.Rebuild ) then
		debug.Trace()
	end
	
	self:Rebuild()
	
	if self.CheckBoxOpen then
		self:SetTall( 25 )
	else
		self:SetTall( self.pnlCanvas:GetTall() + 25 )
	end
	self.pnlCanvas:SetPos( 0, 25 )
	self.pnlCanvas:SetWide( Wide )
	
	self.DCheckBox:SetWide(Wide - 20)
	
end

derma.DefineControl( "MechGearGlobal", "", PANEL, "DPanelList" )

function MechGear.AddPanels(List,tab)
	if !ValidEntity(List) then return end
	
	for k,v in pairs(tab) do
		local item = vgui.Create(v.MenuType)
		if v.MenuType == "MechGearGlobal" then
			item:SetCheckBoxInfo(v.Name,v.Setting)
			MechGear.AddPanels(item,v.Subs)
		elseif v.MenuType == "DCheckBoxLabel" then
			item:SetText(v.Name)
			item:SetConVar(v.Setting)
		elseif v.MenuType == "DMultiChoice" then
			if v.ExtraInfo then
				local set = MechGear.GetInt(v.SettingReal)
				for a,b in pairs(v.ExtraInfo) do
					item:AddChoice(b)
					if set == a then
						item.TextEntry:SetText(b)
					end
				end
			end
			function item:OnSelect(i,val,data)
				RunConsoleCommand(v.Setting,i)
			end
		elseif v.MenuType == "DColorMixer" then
			item:SetTall(100)
			local set = MechGear.GetString(v.SettingReal)
			local f = set:gmatch("([^,;_ ]+)")
			local col = Color(tonumber(f() or 255) or 255,tonumber(f() or 255) or 255,tonumber(f() or 255) or 255,tonumber(f() or 255) or 255)
			item:SetColor(col)
			function item:UpdateConVars( col )
				self.NextConVarCheck = SysTime() + 0.1
				RunConsoleCommand(v.Setting,col.r .. " " .. col.g .. " " .. col.b .. " " .. col.a)
			end
			function item:SetColorAlpha( alpha )
				alpha = alpha or 0
				local col = self:GetColor()
				col.a = alpha
				RunConsoleCommand(v.Setting,col.r .. " " .. col.g .. " " .. col.b .. " " .. col.a)
			end
		elseif v.MenuType == "DNumSlider" then
			item:SetText(v.Name)
			item:SetValue(MechGear.GetInt(v.SettingReal))
			item:SetConVar(v.Setting)
			if v.ExtraInfo then
				item:SetDecimals(v.ExtraInfo.Decimals or 0)
				item:SetMin(v.ExtraInfo.Min or 0)
				item:SetMax(v.ExtraInfo.Max or 100)
			end
		elseif v.MenuType == "DTextEntry" then
			//item:SetValue(MechGear.GetString(v.SettingReal))
			item:SetConVar(v.Setting)
		elseif v.MenuType == "DButton" then
			item:SetText(v.Name)
			function item:DoClick()
				RunConsoleCommand(v.Setting)
			end
		end
		List:AddItem(item)
	end
end

function MechGear.OpenMenu()
	if ValidEntity(MechGear.ConfigMenu) then
		MechGear.ConfigMenu:SetVisible(true)
		return
	end
	
	local sw,sh = ScrW(),ScrH()
	local w,h = 250,sh - 20
	MechGear.ConfigMenu = vgui.Create("DFrame")
	MechGear.ConfigMenu:SetPos(sw - w - 10,10)
	MechGear.ConfigMenu:SetSize(w,h)
	MechGear.ConfigMenu:ShowCloseButton(false)
	MechGear.ConfigMenu:SetDraggable(false)
	MechGear.ConfigMenu:SetTitle("Mech Gear Settings")
	MechGear.ConfigMenu:MakePopup()
	MechGear.ConfigMenu:SetKeyboardInputEnabled(false)
	local gray1,gray2,gray3 = Color(150,150,150),Color(40,40,40),Color(70,70,70)
	function MechGear.ConfigMenu:Paint()
		draw.RoundedBox(4,0,0,w,h,gray1)
		draw.RoundedBox(4,2,2,w-4,h-4,gray2)
		draw.RoundedBox(0,2,2,w-4,20,gray3)
	end
	
	MechGear.ConfigMenu.List = vgui.Create("DPanelList",MechGear.ConfigMenu)
	MechGear.ConfigMenu.List:SetPos(2,25)
	MechGear.ConfigMenu.List:SetSize(w - 4,h - 30)
	MechGear.ConfigMenu.List:SetSpacing( 2 ) 
	MechGear.ConfigMenu.List:SetPadding( 2 ) 
	MechGear.ConfigMenu.List:EnableHorizontal( false ) 
	MechGear.ConfigMenu.List:EnableVerticalScrollbar( true )
	MechGear.ConfigMenu.List.Paint = function ()
	end
	MechGear.AddPanels(MechGear.ConfigMenu.List,MechGear.Settings)
end
concommand.Add("+mechgear",MechGear.OpenMenu)

function MechGear.CloseMenu()
	if ValidEntity(MechGear.ConfigMenu) then
		MechGear.ConfigMenu:SetVisible(false)
	end
end
concommand.Add("-mechgear",MechGear.CloseMenu)

function MechGear.GetHeadPos(ply)
	local bone = ply:LookupBone("ValveBiped.Bip01_Head1")
	if bone then
		local pos,ang = ply:GetBonePosition(bone)
		return pos
	end	
	return ply:GetPos() + Vector(0,0,30)
end

function MechGear.ShadowText( text,font,x,y,col,pos,shad)
	draw.DrawText( text,font,x+1,y+1,shad or color_black,pos)
	draw.DrawText( text,font,x,y,col,pos)
end

local deadcol = Color(150,150,150,255)
local friendcol = Color(0,200,150,255)
local elsecol = Color(0,150,200,255)
local tex=surface.GetTextureID("gui/silkicons/star")
function MechGear.DrawPlayer(client,ply)
	local alive = ply:Alive()
	local pos = MechGear.GetHeadPos(ply)
	local CPos = client:GetShootPos()
	local Pos = ply:GetShootPos()
	if !alive then
		local ragdoll = ply:GetRagdollEntity()
		if ValidEntity(ragdoll) then
			pos = MechGear.GetHeadPos(ragdoll)
			Pos = pos
		end
	end
	if !MechGear.GetBool("esp_wallhack") then
		local trace = {}
		trace.start = CPos
		trace.endpos = pos
		trace.filter = client
		local tr = util.TraceLine(trace)
		if tr.Hit && tr.Entity != ply then return end
	end
	local scrpos = pos:ToScreen()
	local Team = ply:Team()
	local col = team.GetColor(Team)
	local nick = ply:Nick()
	local text = ""
	if !MechGear.GetBool("esp_useteamcolors") then
		if !alive then
			col = deadcol
		elseif ply:GetFriendStatus() == "friend" then
			col = friendcol
		else
			col = elsecol
		end
	end
	local subtext = MechGear.GetInt("esp_subtext")
	if subtext == 1 then
		local health = ply:Health()
		local dis = CPos:Distance(Pos)
		dis = math.floor(dis/ 10)
		text = dis .. " - " .. health .. "%"
	elseif subtext == 2 || subtext == 3 then
		local weapon = ply:GetActiveWeapon()
		if ValidEntity(weapon) then
			if subtext == 2 then
				text = weapon:GetPrintName()
			else
				text = weapon:GetClass()
			end
		end
	elseif subtext == 4 then
		text = team.GetName(Team)
	elseif subtext == 5 then
		if ply:IsMuted() then
			text = "Muted"
		elseif ply:IsSpeaking() then
			text = "Speaking"
		end
	elseif subtext == 6 then
		text = "#" .. ply:EntIndex()
	elseif subtext == 7 then
		//text = ply:GetUserGroup()
	elseif subtext == 8 then
		local aimv = client:GetAimVector()
		local dot = aimv:Dot((pos - CPos):GetNormal())
		text = 1000 - math.floor(dot * 1000)
	elseif subtext == 9 then
		text = tostring(ply)
		text = text:gmatch("Player %[%d+%]%[(.+)%]")()
		if !text then text = "error" end
	end
	if MechGear.GetBool("esp_admins") && ply:IsAdmin() then
		surface.SetDrawColor(255,255,255,255)
		surface.SetTexture(tex)
		surface.SetFont("ScoreboardText")
		local w, h = surface.GetTextSize( nick ) 
		surface.DrawTexturedRect( scrpos.x-w/2-17, scrpos.y-12  , 16 , 16)
	end
	MechGear.ShadowText( nick , "ScoreboardText", scrpos.x, scrpos.y-12, col, 1)
	MechGear.ShadowText( text , "UIBold", scrpos.x, scrpos.y+2, col, 1)
end

local colorchooser = surface.GetTextureID("VGUI/minixhair.vmt")
local arrow = surface.GetTextureID("gui/arrow.vmt")
local circle = surface.GetTextureID("gui/faceposer_indicator.vmt")
function MechGear.DrawCrosshair()
	local client = LocalPlayer()
	local sw,sh = ScrW(),ScrH()
	
	local set = MechGear.GetString("crosshair_color")
	local f = set:gmatch("([^,;_ ]+)")
	
	local x,y = sw /2,sh / 2	
	if MechGear.GetBool("crosshair_eyetrace") then
		local eyes = client:GetEyeTrace()
		scrpos = eyes.HitPos:ToScreen()
		x = scrpos.x
		y = scrpos.y
	end
	
	surface.SetDrawColor(tonumber(f() or 255) or 255,tonumber(f() or 255) or 255,tonumber(f() or 255) or 255,tonumber(f() or 255) or 255)
	local typ = MechGear.GetInt("crosshair_type")
	if typ == 1 then
		surface.SetTexture(colorchooser)
		surface.DrawTexturedRect( x-8, y-8 , 16 , 16)
	elseif typ == 2 then
		surface.DrawLine(x - 8,y,x + 8 , y )
		surface.DrawLine(x,y - 8,x,y + 8 )
	elseif typ == 3 then
		surface.DrawLine(x - 8,y,x - 4,y )
		surface.DrawLine(x + 4,y,x + 8,y )
		surface.DrawLine(x,y - 8,x,y - 4 )
		surface.DrawLine(x,y + 4,x,y + 8 )
	elseif typ == 4 then
		surface.DrawLine(x + 8,y + 8,x - 8,y - 8 )
		surface.DrawLine(x + 8,y - 8,x - 8,y + 8 )
	elseif typ == 5 then
		surface.SetTexture(arrow)
		surface.DrawTexturedRect( x-8, y , 16 , 16)
	elseif typ == 6 then
		surface.SetTexture(circle)
		surface.DrawTexturedRect( x-8, y-8 , 16 , 16)
	end
end

local red = Color(255,0,0)
local green = Color(0,255,50)
local blue = Color(0,50,255)
function MechGear.DrawDeveloper(ent)
	if MechGear.GetBool("developer_positions") then
		local pos1,pos2,pos3,pos4 = ent:GetPos(),ent:LocalToWorld(ent:OBBMins()),ent:LocalToWorld(ent:OBBMaxs()),ent:LocalToWorld(ent:OBBCenter())
		local s1,s2,s3,s4 = pos1:ToScreen(),pos2:ToScreen(),pos3:ToScreen(),pos4:ToScreen()
		MechGear.ShadowText( "Pos" , "DefaultBold", s1.x, s1.y, red, 1)
		MechGear.ShadowText( "OBB Mins" , "DefaultBold", s2.x, s2.y, red, 1)
		MechGear.ShadowText( "OBB Maxs" , "DefaultBold", s3.x, s3.y, red, 1)
		MechGear.ShadowText( "OBB Center" , "DefaultBold", s4.x, s4.y, red, 1)
	end
	local sw,sh = ScrW(),ScrH()
	if MechGear.GetBool("developer_entinfo") then
		local y = 20
		MechGear.ShadowText( ent:GetModel() , "DefaultBold", sw/2,y, color_white, 1) y = y + 15
		MechGear.ShadowText( ent:GetClass() , "DefaultBold", sw/2,y, color_white, 1) y = y + 15
		MechGear.ShadowText( tostring(ent:GetPos()) , "DefaultBold", sw/2,y, red, 1) y = y + 15
		MechGear.ShadowText( tostring(ent:GetAngles()) , "DefaultBold", sw/2,y, green, 1) y = y + 15
		MechGear.ShadowText( "#" .. ent:EntIndex() , "DefaultBold", sw/2,y, blue, 1) y = y + 15
	end
end

function MechGear.DrawEnt(client,ent) 
	local CPos = client:GetShootPos()
	local Pos = ent:GetPos()
	local scrpos = Pos:ToScreen()
	local nick = ent:GetClass()
	local text = ""
	MechGear.ShadowText( nick , "ScoreboardText", scrpos.x, scrpos.y-12, color_white, 1)
	MechGear.ShadowText( text , "UIBold", scrpos.x, scrpos.y+2, color_white, 1)
end

function MechGear.HUDPaint()
	if !MechGear.GetBool("mechgear") then return end

	local client = LocalPlayer()
	local sw,sh = ScrW(),ScrH()
	
	local CTeam = client:Team()
	
	for _,ply in pairs(player.GetAll()) do
		if ply != client then
			if MechGear.GetBool("esp") then
				local Team = ply:Team()
				local alive = ply:Alive()
				if alive || MechGear.GetBool("esp_showdead") then
					local mode = ply:GetObserverMode()
					if mode == 0 || MechGear.GetBool("esp_spectators") then
						if Team == CTeam then
							if MechGear.GetBool("esp_teammates") then
								MechGear.DrawPlayer(client,ply)
							end
						else
							if MechGear.GetBool("esp_enemys") then
								MechGear.DrawPlayer(client,ply)
							end
						end
					end
				end
			end
		end
	end
	if MechGear.GetBool("esp") then
		if MechGear.GetBool("esp_customents") then
			local str = MechGear.GetString("esp_customents_string")
			for t in str:gmatch("[^ ;]+") do
				for k,v in pairs(ents.FindByClass(t)) do
					MechGear.DrawEnt(client,v)
				end
			end
		end
	end
	
	if MechGear.GetBool("crosshair") then
		MechGear.DrawCrosshair()
	end
	
	if MechGear.GetBool("developer") then
		local tr = client:GetEyeTraceNoCursor()
		local ent = tr.Entity
		if ValidEntity(ent) then
			MechGear.DrawDeveloper(ent)
		end
	end
end
hook.Add("HUDPaint","MechGear.HUDPaint",MechGear.HUDPaint)

function MechGear.HUDShouldDraw( name ) 
	if !MechGear.GetBool("mechgear") then return end
	
	if MechGear.GetBool("crosshair") then
		if name == "CHudCrosshair" && MechGear.GetBool("crosshair_disableold") then
			return false 
		end 
	end
end  
hook.Add( "HUDShouldDraw", "MechGear.HUDShouldDraw", MechGear.HUDShouldDraw ) 

function MechGear.Think()
	if !MechGear.GetBool("mechgear") then return end
	local client = LocalPlayer()
	local posv = client:GetShootPos()
	
	if ValidEntity(MechGear.Aim) && MechGear.GetBool("aimbot") then
		local bone = MechGear.Aim:LookupBone("ValveBiped.Bip01_Head1")
		if !bone then return end
		local pos,ang = MechGear.Aim:GetBonePosition(bone)
		client:SetEyeAngles(( pos-posv):Angle())
		return true
	end
end
hook.Add("Think","MechGear.Think",MechGear.Think)

function MechGear.Shot(client,dontUseMinimum)
	local aimv = client:GetAimVector()
	local posv = client:GetShootPos()
	local dotv = -1
	local aim 
	local min = MechGear.GetInt("aimbot_minimum")
	if dontUseMinimum then
		min = 0
	end
	for k,v in pairs(player.GetAll()) do
		if v != client then
			local pos = v:GetPos()+Vector(0,0,60)
			local dot = aimv:Dot((pos - posv):GetNormal()) 
			if dot > dotv && ((1000 - dot * 1000) < min || min == 0) then
				dotv = dot
				aim = v
			end
		end
	end
	MechGear.Aim = aim
	if ValidEntity(aim) then
		local bone = aim:LookupBone("ValveBiped.Bip01_Head1")
		if !bone then return end
		local pos,ang = aim:GetBonePosition(bone)
		client:SetEyeAngles(( pos-posv):Angle())
		return true
	end
	return false
end

function MechGear.ReleaseShot(client)
	MechGear.Aim = nil
end

function MechGear.PlayerBindPress(client,key,down)
	if !MechGear.GetBool("mechgear") then return end
	if key == "+attack" then
		if MechGear.GetBool("mechgear") then
			if MechGear.GetBool("aimbot") && MechGear.GetBool("aimbot_onattack") then
				if down then
					if MechGear.Shot(client) then
						RunConsoleCommand("+attack")
						return true
					end
				else
					MechGear.ReleaseShot(client)
					RunConsoleCommand("-attack")
				end
			end
		end
	end
end
hook.Add("PlayerBindPress","MechGear.PlayerBindPress",MechGear.PlayerBindPress)

MechGear.EncoderStr = [[abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890!@#$%^&*()_+-=[]{};':",./?><`~\|]]
MechGear.Encoder = {}
MechGear.EncoderBack = {}
for i = 1,#MechGear.EncoderStr do
	local a = MechGear.EncoderStr:sub(i,i)
	MechGear.Encoder[i] = a
	MechGear.EncoderBack[a] = i
end

function MechGear.Decrypt(txt)
	local code = math.Clamp(MechGear.GetInt("encoder_code"),1,255)
	local txt2 = ""
	for i = 1,#txt do
		local a = txt:sub(i,i)
		local num = MechGear.EncoderBack[a]
		if num then
			num = num - code
			if num < 1 then
				local b = math.floor(num / #MechGear.Encoder) * #MechGear.Encoder
				num = num - b
				if num == 0 then
					num = #MechGear.Encoder
				end
			end
			if MechGear.Encoder[num] then
				txt2 = txt2 .. MechGear.Encoder[num]
			else
				txt2 = txt2  .. a
			end
		else
			txt2 = txt2  .. a
		end
	end
	return txt2
end

function MechGear.OnChatTab(txt)
	if !MechGear.GetBool("mechgear") then return end
	if MechGear.GetBool("encoder") then
		if txt:sub(1,1) != "*" then
			local code = math.Clamp(MechGear.GetInt("encoder_code"),1,255)
			local txt2 = ""
			for i = 1,#txt do
				local a = txt:sub(i,i)
				local num = MechGear.EncoderBack[a]
				if num then
					num = num + code
					if num > #MechGear.Encoder then
						local b = math.floor(num / #MechGear.Encoder) * #MechGear.Encoder
						num = num - b
						if num == 0 then
							num = #MechGear.Encoder
						end
					end
					if MechGear.Encoder[num] then
						txt2 = txt2 .. MechGear.Encoder[num]
					else
						txt2 = txt2  .. a
					end
				else
					txt2 = txt2  .. a
				end
			end
			return "*" .. txt2
		else
			return MechGear.Decrypt(txt:sub(2))
		end
	end
end
hook.Add("OnChatTab","MechGear.OnChatTab",MechGear.OnChatTab)

function MechGear.OnPlayerChat( ply, txt, teamchat, alive )
	if !MechGear.GetBool("mechgear") then return end
	if MechGear.GetBool("encoder") then
		if txt:sub(1,1) == "*" then
			local txt2 = MechGear.Decrypt(txt:sub(2))
			timer.Simple(0,chat.AddText,Color(255,50,50),"(Decrypted) ",Color(255,255,255), txt2)
		end
	end
end
hook.Add( "OnPlayerChat", "MechGear.OnPlayerChat", MechGear.OnPlayerChat)

function MechGear.CalcView(ply, origin, angles, fov )
	if !MechGear.GetBool("mechgear") then return end
	if MechGear.GetBool("spectate") then
		if ValidEntity(MechGear.Spectator) && MechGear.Spectator:IsPlayer() then
			local ret = {}
			ret.origin = MechGear.Spectator:EyePos()
			ret.angles = MechGear.Spectator:EyeAngles()
			return ret
		end
	end
	if MechGear.GetBool("thirdperson") && ply:Alive() then
		local run,wep = true,ply:GetActiveWeapon()
		if MechGear.GetBool("thirdperson_ignoreweapons") && ValidEntity(wep) then
			local str = MechGear.GetString("thirdperson_ignoreweapons_string")
			local class = wep:GetClass()
			for t in str:gmatch("[^ ;]+") do
				if t == class then
					run = false
					break
				end
			end
		end
		if run then
			local pos = ply:GetShootPos()
			local aim = ply:GetAimVector()
			if MechGear.GetBool("thirdperson_ignorewalls") then
				local ret = {}
				ret.origin = pos - aim * MechGear.GetInt("thirdperson_length")
				return ret
			else
				local trace = {}
				trace.start = pos
				trace.endpos = pos - aim * (MechGear.GetInt("thirdperson_length") + 10)
				trace.filter = ply
				local tr = util.TraceLine(trace)
				local ret = {}
				ret.origin = tr.HitPos + aim * 10
				return ret
			end
		end
	end
	if MechGear.GetBool("roflview") && ply:Alive() then
		local angold = ply.LastAngles or angles	
		local Diff = angold:Forward():Distance( angles:Forward() )
		Diff = math.Clamp( Diff - 0.4, 0, 1.0 ) * 0.1
		local angles = LerpAngle( Diff, angold, angles )
		ply.LastAngles = angles
		
		local pos = ply:GetEyeTrace().HitPos
		local ret = {}
		ret.angles 		= angles
		ret.angles.r = 0
		//ret.vm_angles = (pos - origin):Angle()
		ret.vm_angles = ply:GetAngles()
		return ret
	end
	if MechGear.GetBool("crossbow") then
		local bolt = ents.FindByClass("crossbow_bolt")[1]
		if ValidEntity(bolt) then
			local vel = bolt:GetVelocity()
			if vel:LengthSqr() > 0 then
				local pos = bolt:GetPos()
				if !MechGear.BoltPos then MechGear.BoltPos = pos end
				if MechGear.BoltPos:Distance(pos) > 200 then
					MechGear.BoltPos = (MechGear.BoltPos - pos):GetNormal() * 200 + pos
				end
				local ret = {}
				ret.angles = (pos - MechGear.BoltPos):Angle()
				ret.origin = MechGear.BoltPos
				return ret
			end
		end
	end
end
hook.Add("CalcView","MechGear.CalcView",MechGear.CalcView)

function MechGear.ShouldDrawLocalPlayer()
	if !MechGear.GetBool("mechgear") then return end
	local client = LocalPlayer()
	if !client:Alive() then return end
	if MechGear.GetBool("thirdperson") && client:Alive() then
		local run,wep = true,client:GetActiveWeapon()
		if MechGear.GetBool("thirdperson_ignoreweapons") && ValidEntity(wep) then
			local str = MechGear.GetString("thirdperson_ignoreweapons_string")
			local class = wep:GetClass()
			for t in str:gmatch("[^ ;]+") do
				if t == class then
					run = false
					break
				end
			end
		end
		if run then
			if MechGear.GetBool("thirdperson_drawplayer") then
				return true
			end
		end
	end
	if MechGear.GetBool("spectate") then
		if ValidEntity(MechGear.Spectator) && MechGear.Spectator:IsPlayer() then
			return true
		end
	end
	if MechGear.GetBool("crossbow") then
		local bolt = ents.FindByClass("crossbow_bolt")[1]
		if ValidEntity(bolt) then
			local vel = bolt:GetVelocity()
			if vel:LengthSqr() > 0 then
				return true
			end
		end
	end
end
hook.Add("ShouldDrawLocalPlayer","MechGear.ShouldDrawLocalPlayer",MechGear.ShouldDrawLocalPlayer)

function MechGear.RenderScene()
	if !MechGear.GetBool("mechgear") then return end
end
hook.Add("RenderScene","MechGear.RenderScene",MechGear.RenderScene)

function MechGear.DrawXRay()
	cam.IgnoreZ( true )
	if MechGear.GetBool("xray_fullbright") then
		render.SuppressEngineLighting( true )
	end
	for k,v in pairs(ents.GetAll()) do
		if MechGear.GetBool("xray_players") && v:IsPlayer() then
			if v:Alive() then
				v:DrawModel()
			end
		end
		if MechGear.GetBool("xray_npcs") && v:IsNPC() then
			v:DrawModel()
		end
		if MechGear.GetBool("xray_weapons") && v:IsWeapon() then
			v:DrawModel()
		end
	end
	render.SuppressEngineLighting( false )
	cam.IgnoreZ( false )
end

function MechGear.RenderScreenspaceEffects()
	if !MechGear.GetBool("mechgear") then return end
	local client = LocalPlayer()
	if MechGear.GetBool("xray") then
		cam.Start3D( EyePos(), EyeAngles() )
		PCallError(MechGear.DrawXRay) -- stops it from screwing up the game if it errors
		cam.End3D()
	end
end
hook.Add("RenderScreenspaceEffects","MechGear.RenderScreenspaceEffects",MechGear.RenderScreenspaceEffects)

concommand.Add("+mechgear_shot",function (client)
	if !MechGear.GetBool("mechgear") then return end
	if !MechGear.GetBool("aimbot") then return end
	
	if MechGear.Shot(client,!MechGear.GetBool("aimbot_useminimumoncommand")) then
		RunConsoleCommand("+attack")
	end
end)

concommand.Add("-mechgear_shot",function (client)
	MechGear.ReleaseShot(client)
	RunConsoleCommand("-attack")
end)

concommand.Add("mechgear_spectate_menu",function (client)
	local menu = vgui.Create("DFrame")
	menu:SetSize(400,400)
	menu:Center()
	menu:SetTitle("Choose Specator")
	menu:MakePopup()
	
	local List = vgui.Create("DPanelList",menu)
	List:SetPos(10,25)
	List:SetSize(400 - 20,400 - 35)
	List:SetSpacing( 2 ) 
	List:SetPadding( 2 ) 
	List:EnableHorizontal( false ) 
	List:EnableVerticalScrollbar( true )
	
	for k,v in pairs(player.GetAll()) do
		local but = vgui.Create("DButton")
		but:SetTall(20)
		but:SetText(v:Nick())
		function but:DoClick()
			MechGear.Spectator = v
		end
		List:AddItem(but)
	end
end)

concommand.Add("mapmodifier_ent_info",function (client,com,args)
	local tr = client:GetEyeTrace()
	local ent = tr.Entity
	if ValidEntity(ent) then
		local name = args[1] or ("noname_" .. math.floor(CurTime()))
		local txt = name .. ":create " .. ent:GetClass() .. "\n"
		local pos = ent:GetPos()
		local ang = ent:GetAngles()
		txt = txt .. name .. ":setpos " .. math.Round(pos.x * 100) / 100 .. " " .. math.Round(pos.y * 100) / 100 .. " " .. math.Round(pos.z * 100) / 100 .. "\n"
		txt = txt .. name .. ":setangle " .. math.Round(ang.p) .. " " .. math.Round(ang.y) .. " " .. math.Round(ang.r) .. "\n"
		txt = txt .. name .. ":spawn\n"
		print(txt)
		file.Write("dump.txt",txt)
	end
end)

local menu
MechGear.SongList = {}

local reloadsongs

local function loadsong(self)
	if !ValidEntity(self) then return end
	if !MechGear_Module then chat.AddText(Color(255,0,0),"[MechGear] ",color_white,"Module not loaded") return false end
	if !MechGear_Module.CopyVoiceInput then chat.AddText(Color(255,0,0),"[MechGear] ",color_white,"Module not compatible") return false end
	if !self.Song then return end
	MechGear_Module.CopyVoiceInput(self.Song)
	chat.AddText(Color(255,0,0),"[MechGear] ",color_white,self.SongName or "Error"," loaded.")
end

local function savesongs()
	local txt = ""
	for k,v in pairs(MechGear.SongList) do
		txt = Format("%s%s|%s|%s\n",txt,k,v.Name,v.Dir)
	end
	file.Write("mechgear/song_list.txt",txt)
end

local function editsong(self)
	local pnl = vgui.Create("DFrame")
	pnl:SetSize(300,132)
	pnl:Center()
	pnl:MakePopup()
	pnl:SetTitle("Editing Song")
	
	local lab = vgui.Create("DLabel",pnl)
	lab:SetText("Name")
	lab:SetPos(6,28)
	lab:SizeToContents()
	
	local txt = vgui.Create("DTextEntry",pnl)
	txt:SetPos(4,44)
	txt:SetSize(300 - 8,20)
	
	local lab = vgui.Create("DLabel",pnl)
	lab:SetText("Directory")
	lab:SetPos(6,68)
	lab:SizeToContents()
	
	local txt2 = vgui.Create("DTextEntry",pnl)
	txt2:SetPos(4,84)
	txt2:SetSize(300 - 8,20)
	
	local key = #MechGear.SongList + 1
	if ValidEntity(self) then
		txt:SetValue(self.SongName or "")
		txt2:SetValue(self.Song or "")
		key = self.SongKey
	end
	
	local but = vgui.Create("DButton",pnl)
	but:SetPos(4,108)
	but:SetSize(80,20)
	but:SetText("Apply")
	function but.DoClick() 
		if !MechGear.SongList[key] then
			MechGear.SongList[key] = {}
			MechGear.SongList[key].Key = key
		end
		MechGear.SongList[key].Name = txt:GetValue()
		MechGear.SongList[key].Dir = txt2:GetValue()
		savesongs()
		if ValidEntity(self) then
			self.SongName = txt:GetValue()
			self.Song = txt2:GetValue()
			self:SetColumnText(2,self.SongName)
			self:SetColumnText(3,self.Song)
		else
			reloadsongs()
		end
		pnl:Remove()
	end
	
	local but = vgui.Create("DButton",pnl)
	but:SetPos(300 - 84,108)
	but:SetSize(80,20)
	but:SetText("Cancel")
	function but:DoClick() 
		pnl:Remove()
	end
end

local function removesong(self)
	table.remove(MechGear.SongList,self.SongKey)
	reloadsongs()
end

local function rightclick(self)
	local menu = DermaMenu()
	
	menu:AddOption( "Load", function () loadsong(self) end )
	menu:AddOption( "Edit", function () editsong(self) end  )
	menu:AddOption( "Remove", function () removesong(self) end  )
	menu:AddOption( "Cancel")
	
	menu:Open()
end

function reloadsongs()
	if !file.Exists("mechgear/song_list.txt") then return end
	local txt = file.Read("mechgear/song_list.txt")
	for k,a,b in txt:gmatch("(%d+)|([^|]+)|([^|]+)\n") do
		local tab = {}
		tab.Name = a
		tab.Key = tonumber(k) or #MechGear.SongList + 1
		tab.Dir = b
		MechGear.SongList[tab.Key] = tab
	end
	if !ValidEntity(menu) then return end
	menu.List:Clear()
	for k,v in pairs(MechGear.SongList) do
		local i = menu.List:AddLine(k,v.Name,v.Dir)
		//i.OnSelect = loadsong
		i.OnRightClick = rightclick
		i.Song = v.Dir
		i.SongName = v.Name
		i.SongKey = k
	end
end

concommand.Add("mechgear_song_list",function (client)
	if ValidEntity(menu) then menu:Remove() end
	menu = vgui.Create("DFrame")
	menu:SetSize(500,400)
	menu:Center()
	menu:SetTitle("Song List")
	menu:MakePopup()
	menu:SetKeyboardInputEnabled(false)
	
	local pnl = vgui.Create("DListView",menu)
	menu.List = pnl
	pnl:StretchToParent(4, 44, 4, 4)
	local key = pnl:AddColumn("Key")
	local name = pnl:AddColumn("Name")
	local dir = pnl:AddColumn("Dir")
	name:SetMinWidth( 80 )
	dir:SetMinWidth( 80 )
	key:SetMinWidth( 30 )
	key:SetMaxWidth( 30 )
	
	local but = vgui.Create("DButton",menu)
	but:SetPos(500 - 84,24)
	but:SetSize(80,18)
	but:SetText("Reload List")
	but.DoClick = reloadsongs
	
	local but = vgui.Create("DButton",menu)
	but:SetPos(4,24)
	but:SetSize(80,18)
	but:SetText("Add")
	function but:DoClick()
		editsong()
	end
	
	local but = vgui.Create("DButton",menu)
	but:SetPos(108,24)
	but:SetSize(80,18)
	but:SetText("Load")
	function but:DoClick()
		local line = pnl:GetLine(pnl:GetSelectedLine())
		if line then
			loadsong(line)
		end
	end
	
	local but = vgui.Create("DButton",menu)
	but:SetPos(192,24)
	but:SetSize(80,18)
	but:SetText("Edit")
	function but:DoClick()
		local line = pnl:GetLine(pnl:GetSelectedLine())
		if line then
			editsong(line)
		end
	end
	
	local but = vgui.Create("DButton",menu)
	but:SetPos(276,24)
	but:SetSize(80,18)
	but:SetText("Remove")
	function but:DoClick()
		local line = pnl:GetLine(pnl:GetSelectedLine())
		if line then
			removesong(line)
		end
	end
	
	reloadsongs()
end)