-- sublime by @surelyreplica 
if IsInGame() then
    RunConsoleCommand( "disconnect" )
    Msg( "Cant execute runstring in game, try again. \n" )

    return 
end

local bExists = file.Exists( "bin/gmsv_sublime_win64.dll", "LuaMenu" )

if not bExists then
    Msg( "Get latest binary at 'github.com/serejaga/gmsv-sublime-win64' \n" )

    return 
end

local bSucc, sErr = pcall( require, "sublime" )

if not bSucc then
    Msg( "Contact developer @surelyreplica. " .. sErr .. "\n" )
    
    return 
end

-- setup frame 
if pFrame then
    pFrame:Remove()
end

pFrame = vgui.Create( "DPanel" )
pFrame:SetSize( 300, 130 )
pFrame:Center()
pFrame:MakePopup()
pFrame:DockPadding( 8, 24, 8, 8 )

-- frame render 
function pFrame:Paint( w, h )
    -- background 
    surface.SetDrawColor( 16, 16, 16 )
    surface.DrawRect( 0, 0, w, h )

    surface.SetDrawColor( 72, 72, 72 )
    surface.DrawOutlinedRect( 0, 0, w, h )
    surface.DrawRect( 0, 0, w, 24 )

    -- title
    surface.SetTextColor( 128, 128, 128 )
    surface.SetFont( "DefaultFixed" )

    surface.SetTextPos( 112, 6 )
    surface.DrawText( "sublime x64" )
end

-- Release downloader 
local Releases = { "stable", "beta", "dev" }
local sFetch = "https://raw.githubusercontent.com/serejaga/glua-sublime/main/release/sublime-%s.lua"





local bAwait = false 

for i = 1, #Releases do
    local pButton = vgui.Create( "DButton", pFrame )
    pButton:SetTall( 24 )
    pButton:Dock( TOP )
    pButton:DockMargin( 0, 8, 0, 0 )
    pButton:SetText( "" )
    pButton.Label = Releases[ i ]

    function pButton:Paint( w, h )
        surface.SetDrawColor( 72, 72, 72 )
        surface.DrawOutlinedRect( 0, 0, w, h )

        surface.SetTextColor( 128, 128, 128 )
        surface.SetFont( "DefaultFixed" )
    
        local TextWidth, TextHeight = surface.GetTextSize( self.Label )

        surface.SetTextPos( w / 2 - TextWidth / 2, h / 2 - TextHeight / 2 )
        surface.DrawText( self.Label )
    end

    function pButton:DoClick()
        if bAwait then
            return 
        end

        http.Fetch( string.format( sFetch, self.Label ), function( body )
            RunString( body, "sublime.init" )
            pFrame:Remove()
        end )

        bAwait = true 
    end
end