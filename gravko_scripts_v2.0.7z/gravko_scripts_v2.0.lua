--[[
	MOD/lua/gravkoscriptsv2.lua
	Gås"HolmCake | STEAM_0:0:32315212 <86.52.199.230:27005> | [23-12-13 02:25:04AM]
	===BadFile===
]]

surface.PlaySound( "npc/sniper/reload1.wav" )
chat.AddText(Color(0, 255, 0), "Gravko Scripts are now open and ready for use.")
chat.AddText(Color(255, 0, 0), "Bhop is turned ON. Use bhop_toggle to turn OFF.")
chat.AddText(Color(0, 0, 255), "To see all available commands, type gravko_list in console.")
// Gravko Rotate
function gravtate()
local ply = LocalPlayer()
timer.Create("spawn", 0.01, 1, function()
LocalPlayer():ConCommand("gm_spawn models/props_c17/gravestone002a.mdl")
LocalPlayer():ConCommand("+attack")
end)
timer.Create("jump", 0.10, 1, function()
LocalPlayer():ConCommand("+jump")
end)
timer.Create("turnback", 0.2, 1, function() 
local a = LocalPlayer():EyeAngles() LocalPlayer():SetEyeAngles(Angle(a.p-a.p-a.p, a.y-180, a.r))
end)
timer.Create("release", 0.6, 1, function()
LocalPlayer():ConCommand("-attack")
end)
timer.Create("-jumps", 0.3, 1, function()
LocalPlayer():ConCommand("-jump")
end)
timer.Create("undo", 0.6, 1, function()  
LocalPlayer():ConCommand("undo")
end)
end
concommand.Add("gravtate", gravtate)

// Gravko bhop
RunConsoleCommand("bhop_toggle")
local bhop
hook.Add("Think", "bhop", function()
if bhop then
     if (input.IsKeyDown( KEY_SPACE ) ) then
        if LocalPlayer():IsOnGround() then
            RunConsoleCommand("+jump")
            HasJumped = 1
        else
            RunConsoleCommand("-jump")
            HasJumped = 0
        end
    elseif bhop and LocalPlayer():IsOnGround() then
        if HasJumped == 1 then
            RunConsoleCommand("-jump")
            HasJumped = 0
        end
    end
end
end)

concommand.Add("bhop_toggle", function()
if bhop then
    bhop = !bhop
else
    bhop = !bhop
end
end)
// Break fall
-- local ply = LocalPlayer()
--local Angles = LocalPlayer():EyeAngles()
--LocalPlayer():SetEyeAngles(Angle(30, Angles.yaw + 180, Angles.roll))

function gravfall()
local ply = LocalPlayer()
local Angles = LocalPlayer():EyeAngles()
timer.Create("down", 0.01, 1, function()
LocalPlayer():SetEyeAngles(Angle(180, Angles.yaw, Angles.roll))
end)
timer.Create("spawn", 0.03, 1, function()
LocalPlayer():ConCommand("gm_spawn models/props_c17/utilitypole03a.mdl")
end)
timer.Create("undo", 0.3, 1, function()  
LocalPlayer():ConCommand("undo")
end)

timer.Create("turnback", 0.35, 1, function() 
LocalPlayer():SetEyeAngles(Angle(0, Angles.yaw, Angles.roll))
end)
end
concommand.Add("gravfall", gravfall)
// Tell commands
local function gravkolist()
	print("BREAK FALL: gravfall")
	print("BHOP: bhop_toggle")
	print("ROTATE: gravtate")
	print("BOOST UP: gravup")
end
concommand.Add("gravko_list", gravkolist)
// Up boost
// Up boost
function gravup()
local ply = LocalPlayer()
local Angles = LocalPlayer():EyeAngles()

timer.Create("down", 0.01, 1, function()
LocalPlayer():SetEyeAngles(Angle(180, Angles.yaw, Angles.roll))
LocalPlayer():ConCommand("+jump")
LocalPlayer():ConCommand("+attack")
end)

timer.Create("spawn", 0.04, 1, function()
LocalPlayer():ConCommand("gm_spawn models/props/de_inferno/wine_barrel_p8.mdl")
end)

timer.Create("turnback", 0.45, 1, function() 
LocalPlayer():SetEyeAngles(Angle(0, Angles.yaw, Angles.roll))
LocalPlayer():ConCommand("-jump")
end)
timer.Create("undo", 0.5, 1, function()  
LocalPlayer():ConCommand("undo")
LocalPlayer():ConCommand("-attack")
end)
end
concommand.Add("gravup", gravup)