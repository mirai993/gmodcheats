/*

	0xray2
	by 0xymoron
	
	Started December 22nd, 2017. 12:22AM
	
	This was made for fun, I haven't propkilled in years and have no intent to.
	I wanted to make a menu a little differently than I usually do, figured making a new propkill client would be a fun way to do so.
	
	Enjoy 0xray2, this will most likely be the last version to ever be made.
	
*/

local xray = {}

xray.Version = 0.02

xray.Data = file.Exists( "0xray/data.txt", "DATA" ) && util.JSONToTable( file.Read( "0xray/data.txt", "DATA" ) ) or {

	["Vars"] = {
	
		["esp_props"] = { str = "Prop Xray", val = true },
		["esp_ents"] = { str = "Entity Xray", val = false },
	
	},

	["Props"] = {
	
		["models/props/de_tides/gate_large.mdl"] = true,
	
	},
	
	["Entities"] = {
	
		["prop_func_rotating"] = true,
	
	},

}

function xray.Notify( msg )

	MsgC( Color( 0, 255, 255 ), "[0xray] " )
	MsgC( color_white, msg .. "\n" ) 

end

function xray.Init()

	if !file.IsDir( "0xray", "DATA" ) then
		
		file.CreateDir( "0xray" )
		
		xray.Notify( "Created directory 'data/0xray'" )
		
	end
	
	if !file.Exists( "0xray/data.txt", "DATA" ) then
		
		file.Write( "0xray/data.txt", util.TableToJSON( xray.Data ) )
		
		xray.Notify( "Created data file 'data/0xray/data.txt'" )
		
	end

end

function xray.Save()

	file.Write( "0xray/data.txt", util.TableToJSON( xray.Data ) )

	xray.Notify( "Saved data to '0xray/data.txt'" )

end

local trace = {}
local ret
function xray.IsVisible( ent )

	trace.start = LocalPlayer():GetShootPos()
	trace.endpos = ent:GetPos() + Vector( 0, 0, 5 )
	trace.filter = { LocalPlayer(), ent }
	trace.mask = MASK_SHOT
	
	ret = util.TraceLine( trace )
	
	return ret.Fraction == 1
	
end

function xray.GetColor( ent )	

	if ent:GetVelocity():Length() != 0 then	
	
		if !xray.IsVisible( ent ) then
		 
			return Color( 200, 0, 0, 150 )
			
		else
		
			return Color( 0, 200, 0, 150 )
			
		end	
		
	else	
	
		return Color( 200, 200, 0, 150 )
		
	end

end

/*
	
	Hooks
	
*/

xray.Hooks = {}

function xray.Hooks.HUDPaint()
	
	if xray.Data.Vars["esp_props"].val then
	
		for k, v in next, ents.FindByClass( "prop_physics" ) do
		
			if !xray.Data.Props[v:GetModel()] then continue end
			
			local col = xray.GetColor( v )
			
			cam.Start3D( EyePos(), EyeAngles() )
			
				local mat = v:GetMaterial()
				
				render.SuppressEngineLighting( true )
				
				render.SetBlend( 1 )
				
				v:SetMaterial( "models/shiny" )
				
				v:SetNoDraw( true )
				
				render.SetColorModulation( col.r / 255, col.g / 255, col.b / 255, 0.5 )
				
				v:DrawModel()
				
				render.SetColorModulation( 1, 1, 1 )
				
				render.MaterialOverride( nil )
				
				render.SetBlend( 0 )
				
				render.SuppressEngineLighting( false )
				
				v:SetNoDraw( false )
				
				v:SetMaterial( mat )
				
				cam.IgnoreZ( false )
			
			cam.End3D()
		
		end
		
	end

end

/*
	
	Menu
	
*/

xray.Menu = {}
--weapons/physcannon/physcannon_charge.wav
function xray.UI()

	surface.PlaySound( "weapons/pistol/pistol_empty.wav" )
	
	xray.Menu.Sheets = {}
	xray.Menu.Buttons = {}

	xray.Menu.Frame = vgui.Create( "DFrame" )
	xray.Menu.Frame:SetSize( 500, 300 )
	xray.Menu.Frame:Center()
	xray.Menu.Frame:SetTitle( "" )
	xray.Menu.Frame:ShowCloseButton( false )
	xray.Menu.Frame:MakePopup()
	
	xray.Menu.Frame.Paint = function( self, w, h )
	
		draw.RoundedBox( 0, 0, 0, w, h, Color( 0, 255, 255, 128 ) )
		
		draw.RoundedBox( 0, 0, 0, w, 32.5, Color( 132, 132, 132, 195 ) )
		
		draw.SimpleText( "0xray2 v" .. xray.Version .. " - by 0xymoron", "Trebuchet24", 5, 15, color_white, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER )
		
	end
	
	xray.Menu.Close = vgui.Create( "DButton", xray.Menu.Frame )
	xray.Menu.Close:SetText( "X" )
	xray.Menu.Close:SetFont( "Trebuchet18" )
	xray.Menu.Close:SetTextColor( color_white )
	xray.Menu.Close:SetSize( 28, 28 )
	xray.Menu.Close:SetPos( xray.Menu.Frame:GetWide() - 30.25, 2.25 )
	
	xray.Menu.Close.DoClick = function()
		
		surface.PlaySound( "weapons/pistol/pistol_empty.wav" )
	
		xray.Menu.Frame:Close()
	
		xray.Save()
	
	end
	
	xray.Menu.Close.Paint = function( self, w, h )
	
		draw.RoundedBox( 0, 0, 0, w, h, Color( 205, 54, 54, 128 ) )
		
		surface.SetDrawColor( Color( 0, 0, 0, 128 ) )
		
		surface.DrawOutlinedRect( 0, 0, w, h )
	
	end
	
	xray.Menu.Panel = vgui.Create( "DColumnSheet", xray.Menu.Frame )
	xray.Menu.Panel:Dock( FILL )
	
	/*
		
		Settings Tab
		
	*/
	
	xray.Menu.Sheets[1] = vgui.Create( "DPanel", xray.Menu.Panel )
	xray.Menu.Sheets[1]:SetSize( 370, 267.5 )
	xray.Menu.Sheets[1].Paint = function( self, w, h )
	
		draw.RoundedBox( 0, 0, 10, w, h - 10, Color( 132, 132, 132, 195 ) )
	
	end

	xray.Menu.Panel:AddSheet( "Settings", xray.Menu.Sheets[1], "icon16/wrench.png" )

	local cbPos = { x = 5, y = 15 }
	
	for k, v in SortedPairs( xray.Data.Vars ) do
	
		local checkbox = vgui.Create( "DCheckBoxLabel", xray.Menu.Sheets[1] )
		checkbox:SetPos( cbPos.x, cbPos.y )
		checkbox:SetText( xray.Data.Vars[k].str )
		checkbox:SetTextColor( color_white )
		checkbox:SetChecked( xray.Data.Vars[k].val )
		checkbox:SizeToContents()
		
		checkbox.OnChange = function( self )
		
			xray.Notify( "Changed setting '" .. k .. "' from " .. tostring( xray.Data.Vars[k].val ) .. " to " .. tostring( !xray.Data.Vars[k].val ) )
			
			xray.Data.Vars[k].val = checkbox:GetChecked()
			
			surface.PlaySound( "buttons/blip1.wav" )
			
		end
		
		cbPos.y = cbPos.y + 20
	
	end	
	
	/*
		
		Props Tab
		
	*/
	
	xray.Menu.Sheets[2] = vgui.Create( "DPanel", xray.Menu.Panel )
	xray.Menu.Sheets[2]:SetSize( 370, 267.5 )
	xray.Menu.Sheets[2].Paint = function( self, w, h )
	
		draw.RoundedBox( 0, 0, 10, w, h - 10, Color( 132, 132, 132, 195 ) )
	
	end
	
	xray.Menu.Panel:AddSheet( "Props", xray.Menu.Sheets[2], "icon16/bricks.png" )
	
	xray.Menu.Proplist = vgui.Create( "DListView", xray.Menu.Sheets[2] )
	xray.Menu.Proplist:SetSize( 225, xray.Menu.Sheets[2]:GetTall() - 20 )
	xray.Menu.Proplist:SetPos( xray.Menu.Sheets[2]:GetWide() - xray.Menu.Proplist:GetWide() - 5, 15 )
	xray.Menu.Proplist:SetMultiSelect( false )
	
	xray.Menu.Proplist:AddColumn( "Model" )
	
	for k, v in pairs( xray.Data.Props ) do
	
		xray.Menu.Proplist:AddLine( k )
		
	end
	
	xray.Menu.Buttons[1] = vgui.Create( "DButton", xray.Menu.Sheets[2] )
	xray.Menu.Buttons[1]:SetPos( 5, 15 )
	xray.Menu.Buttons[1]:SetSize( 130, 30 )
	xray.Menu.Buttons[1]:SetText( "Add Looking At" )
	xray.Menu.Buttons[1]:SetTextColor( color_white )
	xray.Menu.Buttons[1].DoClick = function()
		
		local entity = LocalPlayer():GetEyeTrace().Entity
		
		if !IsValid( entity ) then
		
			xray.Notify( "Invalid entity." )
		
			return
			
		end
		
		if !xray.Data.Props[entity:GetModel()] then
		
			xray.Data.Props[entity:GetModel()] = true
			
			xray.Menu.Proplist:AddLine( entity:GetModel() )
		
			xray.Notify( "Added model '" .. entity:GetModel() .. "' to prop list" )
			
		else
			
			xray.Notify( "Model already in prop list!" )
			
		end
	
	end
	
	xray.Menu.Buttons[2] = vgui.Create( "DButton", xray.Menu.Sheets[2] )
	xray.Menu.Buttons[2]:SetPos( 5, 50 )
	xray.Menu.Buttons[2]:SetSize( 130, 30 )
	xray.Menu.Buttons[2]:SetText( "Remove Selected" )
	xray.Menu.Buttons[2]:SetTextColor( color_white )
	
	xray.Menu.Buttons[2].DoClick = function()
		
		local line = xray.Menu.Proplist:GetSelectedLine()
		
		if line != nil then
			
			local str = xray.Menu.Proplist:GetLine( line ):GetValue( 1 )  
		
			xray.Data.Props[str] = nil
			
			xray.Menu.Proplist:RemoveLine( line )
		
			xray.Notify( "Removed model '" .. str .. "' from the prop list." )
		
		else
		
			xray.Notify( "Nothing selected!" )
		
		end
	
	end
	
	xray.Menu.Buttons[3] = vgui.Create( "DButton", xray.Menu.Sheets[2] )
	xray.Menu.Buttons[3]:SetPos( 5, 85 )
	xray.Menu.Buttons[3]:SetSize( 130, 30 )
	xray.Menu.Buttons[3]:SetText( "Add All On Map" )
	xray.Menu.Buttons[3]:SetTextColor( color_white )
	
	xray.Menu.Buttons[3].DoClick = function()
		
		for k, v in next, ents.FindByClass( "prop_physics" ) do
		
			if !IsValid( v ) then continue end
		
			if !xray.Data.Props[v:GetModel()] then
				
				xray.Data.Props[v:GetModel()] = true
				
				xray.Menu.Proplist:AddLine( v:GetModel() )
				
				xray.Notify( "Added model '" .. v:GetModel() .. "' to prop list." )
				
			end
		
		end
	
	end
	
	xray.Menu.Buttons[4] = vgui.Create( "DButton", xray.Menu.Sheets[2] )
	xray.Menu.Buttons[4]:SetPos( 5, 120 )
	xray.Menu.Buttons[4]:SetSize( 130, 30 )
	xray.Menu.Buttons[4]:SetText( "Remove All" )
	xray.Menu.Buttons[4]:SetTextColor( color_white )
	
	xray.Menu.Buttons[4].DoClick = function()
		
		for k, v in pairs( xray.Data.Props ) do
		
			xray.Data.Props[k] = nil
			
			xray.Menu.Proplist:Clear()
			
			xray.Notify( "Cleared prop list." )
		
		end
	
	end
	
	/*
		
		Entities Tab
		
	*/
	
	xray.Menu.Sheets[3] = vgui.Create( "DPanel", xray.Menu.Panel )
	xray.Menu.Sheets[3]:SetSize( 370, 267.5 )
	xray.Menu.Sheets[3].Paint = function( self, w, h )
	
		draw.RoundedBox( 0, 0, 10, w, h - 10, Color( 132, 132, 132, 195 ) )
	
	end
	
	xray.Menu.Panel:AddSheet( "Entities", xray.Menu.Sheets[3], "icon16/server.png" )
	
	xray.Menu.Entlist = vgui.Create( "DListView", xray.Menu.Sheets[3] )
	xray.Menu.Entlist:SetSize( 130, xray.Menu.Sheets[3]:GetTall() - 20 )
	xray.Menu.Entlist:SetPos( xray.Menu.Sheets[3]:GetWide() - xray.Menu.Entlist:GetWide() - 5, 15 )
	xray.Menu.Entlist:SetMultiSelect( false )
	
	xray.Menu.Entlist:AddColumn( "Entities" )
	
	for k, v in pairs( xray.Data.Entities ) do
	
		xray.Menu.Entlist:AddLine( k )
		
	end	
	
	xray.Menu.Worldents = vgui.Create( "DListView", xray.Menu.Sheets[3] )
	xray.Menu.Worldents:SetSize( 130, xray.Menu.Sheets[3]:GetTall() - 20 )
	xray.Menu.Worldents:SetPos( 5, 15 )
	xray.Menu.Worldents:SetMultiSelect( false )
	
	xray.Menu.Worldents:AddColumn( "World Entities" )
	
	local allents = {}
	
	for k, v in next, ents.GetAll() do
		
		if allents[v:GetClass()] then continue end
		
		if xray.Data.Entities[v:GetClass()] then continue end
		
		allents[v:GetClass()] = true
		
		xray.Menu.Worldents:AddLine( v:GetClass() )
		
	end	
	
	xray.Menu.Buttons[5] = vgui.Create( "DButton", xray.Menu.Sheets[3] )
	xray.Menu.Buttons[5]:SetPos( xray.Menu.Worldents:GetWide() + 10, 15 )
	xray.Menu.Buttons[5]:SetSize( 90, 30 )
	xray.Menu.Buttons[5]:SetText( "Add Selected" )
	xray.Menu.Buttons[5]:SetTextColor( color_white )
	
	xray.Menu.Buttons[5].DoClick = function()
		
		local line = xray.Menu.Worldents:GetSelectedLine()
		
		if line != nil then
		
			local ent = xray.Menu.Worldents:GetLine( line ):GetValue( 1 )  
			
			if !xray.Data.Entities[ent] then 
			
				xray.Data.Entities[ent] = true
				
				xray.Menu.Entlist:AddLine( ent )
				xray.Menu.Worldents:RemoveLine( line )
			
				xray.Notify( "Added entity '" .. ent .. "' to entity list." )
			
			end
		
		end
	
	end
	
	xray.Menu.Buttons[6] = vgui.Create( "DButton", xray.Menu.Sheets[3] )
	xray.Menu.Buttons[6]:SetPos( xray.Menu.Worldents:GetWide() + 10, 50 )
	xray.Menu.Buttons[6]:SetSize( 90, 30 )
	xray.Menu.Buttons[6]:SetText( "Remove Selected" )
	xray.Menu.Buttons[6]:SetTextColor( color_white )
	
	xray.Menu.Buttons[6].DoClick = function()
		
		local line = xray.Menu.Entlist:GetSelectedLine()
		
		if line != nil then
		
			local ent = xray.Menu.Entlist:GetLine( line ):GetValue( 1 )  
			
			if xray.Data.Entities[ent] then 
			
				xray.Data.Entities[ent] = nil
				
				xray.Menu.Worldents:AddLine( ent )
				xray.Menu.Entlist:RemoveLine( line )
			
				xray.Notify( "Removed entity '" .. ent .. "' from entity list." )
			
			end
		
		end
	
	end	
	
	xray.Menu.Buttons[7] = vgui.Create( "DButton", xray.Menu.Sheets[3] )
	xray.Menu.Buttons[7]:SetPos( xray.Menu.Worldents:GetWide() + 10, 85 )
	xray.Menu.Buttons[7]:SetSize( 90, 30 )
	xray.Menu.Buttons[7]:SetText( "Add All On Map" )
	xray.Menu.Buttons[7]:SetTextColor( color_white )
	
	xray.Menu.Buttons[7].DoClick = function()
		
		local allents = {}
	
		for k, v in next, ents.GetAll() do
		
			if allents[v:GetClass()] then continue end
		
			allents[v:GetClass()] = true
			
			xray.Data.Entities[v:GetClass()] = true
			
			xray.Menu.Entlist:AddLine( v:GetClass() )
			
			xray.Menu.Worldents:Clear()
			
			xray.Notify( "Added entity '" .. v:GetClass() .. "' to entity list." )
		
		end	
	
	end	
	
	xray.Menu.Buttons[8] = vgui.Create( "DButton", xray.Menu.Sheets[3] )
	xray.Menu.Buttons[8]:SetPos( xray.Menu.Worldents:GetWide() + 10, 120 )
	xray.Menu.Buttons[8]:SetSize( 90, 30 )
	xray.Menu.Buttons[8]:SetText( "Remove All" )
	xray.Menu.Buttons[8]:SetTextColor( color_white )
	
	xray.Menu.Buttons[8].DoClick = function()

		for k, v in pairs( xray.Data.Entities ) do
		
			xray.Menu.Worldents:AddLine( k )
		
			xray.Data.Entities[k] = nil
			
			xray.Menu.Entlist:Clear()
		
			xray.Notify( "Removed entity '" .. k .. "' from entity list." )
		
		end	
	
	end	
	
	/*
		
		Modify/Skin Menu Items
		
	*/
	
	for k, v in pairs( xray.Menu.Panel.Items ) do
	
		v.Button.Paint = function( self, w, h )
		
			draw.RoundedBox( 0, 0, 0, w, h, Color( 132, 132, 132, 195 ) )
		
		end
		
		v.Button.DoClick = function()
		
			xray.Menu.Panel:SetActiveButton( v.Button )
		
			surface.PlaySound( "ambient/levels/canals/drip4.wav" )
		
		end
	
	end
	
	for k, v in pairs( xray.Menu.Buttons ) do
	
		v.Paint = function( self, w, h )
		
			draw.RoundedBox( 0, 0, 0, w, h, Color( 0, 0, 0, 195 ) )
		
		end
	
	end
	
end

concommand.Add( "ui", xray.UI )

xray.Init()

hook.Add( "HUDPaint", "0xray2HUDPaint", xray.Hooks.HUDPaint )