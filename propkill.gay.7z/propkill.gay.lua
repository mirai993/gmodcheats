-- Original script "made and edit by Mr Props and Anthr".
concommand.Add("FreshyP_Propkill", function()
local Angles = LocalPlayer():EyeAngles()
LocalPlayer():SetEyeAngles(Angle(30, Angles.yaw + 180, Angles.roll))
timer.Create("spawn", 0.1, 1, function()
LocalPlayer():ConCommand("gm_spawn models/props_junk/sawblade001a.mdl")
LocalPlayer():ConCommand("+attack")
end)
timer.Create("jump", 0.15, 1, function()
LocalPlayer():ConCommand("+jump")
end)
timer.Create("turnback", 0.35, 1, function()   
LocalPlayer():SetEyeAngles(Angle(40, Angles.yaw, Angles.roll))
end)
timer.Create("release", 0.37, 1, function()
LocalPlayer():ConCommand("-attack")
end)
timer.Create("-jummp", 0.3, 1, function()
LocalPlayer():ConCommand("-jump")
end)
timer.Create("undo", 1.2, 1, function()        
LocalPlayer():ConCommand("undo")
end)
end)

concommand.Add("FreshyP_Propkill2", function()
local Angles = LocalPlayer():EyeAngles()
LocalPlayer():SetEyeAngles(Angle(30, Angles.yaw + 180, Angles.roll))
timer.Create("spawn", 0.1, 1, function()
LocalPlayer():ConCommand("gm_spawn models/props_phx/construct/glass/glass_angle360.mdl")
LocalPlayer():ConCommand("+attack")
end)
timer.Create("jump", 0.15, 1, function()
LocalPlayer():ConCommand("+jump")
end)
timer.Create("turnback", 0.35, 1, function()   
LocalPlayer():SetEyeAngles(Angle(40, Angles.yaw, Angles.roll))
end)
timer.Create("release", 0.37, 1, function()
LocalPlayer():ConCommand("-attack")
end)
timer.Create("-jummp", 0.3, 1, function()
LocalPlayer():ConCommand("-jump")
end)
timer.Create("undo", 1.2, 1, function()        
LocalPlayer():ConCommand("undo")
end)
end)

concommand.Add("FreshyP_Propkill3", function()
if LocalPlayer():EyeAngles().p > 15 then 
chat.AddText(
Color(91, 152, 225), "Too ",
Color( 255, 0, 0 ), "Steep!") 
return end
local Angles = LocalPlayer():EyeAngles()
timer.Create("spawn", 0.1, 1, function()
LocalPlayer():ConCommand("gm_spawn models/props/de_train/de_train_roofbeams_01.mdl")
LocalPlayer():ConCommand("+attack")
end)
timer.Create("turn", 0.15, 1, function()
LocalPlayer():SetEyeAngles(Angle(Angles.pitch - 180, Angles.yaw - 180, Angles.roll))
end)
timer.Create("release", 0.2, 1, function()
LocalPlayer():ConCommand("-attack")
end)
end)

concommand.Add("FreshyP_Propkill4", function()
local Angles = LocalPlayer():EyeAngles()
LocalPlayer():SetEyeAngles(Angle(15, Angles.yaw, Angles.roll))
timer.Create("fuckdick", 0.1, 1, function()
LocalPlayer():ConCommand("gm_spawn models/props_phx/construct/metal_plate4x4.mdl")
LocalPlayer():ConCommand("+attack")
end)
timer.Create("turn", 0.2, 1, function()
LocalPlayer():SetEyeAngles(Angle(-70, Angles.yaw, Angles.roll))
end)
timer.Create("release", 0.25, 1, function()
LocalPlayer():ConCommand("-attack")
end)
end)

CreateClientConVar("FreshyP_Propkillspin_model", "models/props/de_tides/gate_large.mdl")
concommand.Add("FreshyP_Propkillspin", function()
if LocalPlayer():EyeAngles().p > 12 then 
chat.AddText(
Color(91, 152, 225), "Too ",
Color( 255, 0, 0 ), "Steep!") 
return end
local Angles = LocalPlayer():EyeAngles()
timer.Create("spawn", 0.1, 1, function()
LocalPlayer():ConCommand("gm_spawn " ..GetConVarString("FreshyP_Propkillspin_model"))
LocalPlayer():ConCommand("+attack")
end)
timer.Create("Rotate", 0.15, 1, function()
	hook.Add("CalcView", "nochange", function(origin, angle, fov)
	local maegic = {}
	maegic.origin = LocalPlayer():GetShootPos()
	maegic.angles = Angle(LocalPlayer():EyeAngles().p, LocalPlayer():EyeAngles().y-180, LocalPlayer():EyeAngles().r)
	maegic.fov = fov
	return maegic
	end)
LocalPlayer():SetEyeAngles(Angle(LocalPlayer():EyeAngles().p, LocalPlayer():EyeAngles().y-180, LocalPlayer():EyeAngles().r))
end)
timer.Create("Rotate2", 0.25, 1, function()   
hook.Remove("CalcView", "nochange")
LocalPlayer():SetEyeAngles(Angle(LocalPlayer():EyeAngles().p, LocalPlayer():EyeAngles().y-180, LocalPlayer():EyeAngles().r))
end)
timer.Create("release", 0.3, 1, function()
LocalPlayer():ConCommand("-attack")
end)
end)

concommand.Add("FreshyP_Propkill5", function()
local Angles = LocalPlayer():EyeAngles()
timer.Create("spawn", 0.1, 1, function()
LocalPlayer():ConCommand("gm_spawn models/props/de_tides/gate_large.mdl")
LocalPlayer():ConCommand("+attack")
end)
timer.Create("turn", 0.15, 1, function()
LocalPlayer():SetEyeAngles(Angle(Angles.pitch - 180, Angles.yaw - 180, Angles.roll))
end)
timer.Create("release", 0.2, 1, function()
LocalPlayer():ConCommand("-attack")
end)
timer.Create("getready", 0.25, 1, function()
LocalPlayer():ConCommand("+attack")
end)
timer.Create("spawn2", 0.3, 1, function()
LocalPlayer():ConCommand("gm_spawn models/props/de_tides/gate_large.mdl")
end)
timer.Create("changeeyeanglesagain", 0.35, 1, function()
LocalPlayer():SetEyeAngles(Angle(Angles.pitch-60, Angles.yaw, Angles.roll))
end)
timer.Create("release2", 0.4, 1, function()
LocalPlayer():ConCommand("-attack")
end)
timer.Create("finishit", 0.8, 1, function()
LocalPlayer():ConCommand("undo")
LocalPlayer():ConCommand("undo")
end)
end)

concommand.Add("FreshyP_PropShieldClose", function()
LocalPlayer():SetEyeAngles(Angle(55, LocalPlayer():EyeAngles().y, LocalPlayer():EyeAngles().r))
LocalPlayer():ConCommand("+attack")
timer.Simple(0.1, function()
LocalPlayer():ConCommand("gm_spawn models/props/de_tides/gate_large.mdl")
end)
timer.Simple(0.15, function()
LocalPlayer():ConCommand("+attack2")
end)
timer.Simple(0.17, function()
LocalPlayer():ConCommand("-attack")
LocalPlayer():ConCommand("-attack2")
LocalPlayer():SetEyeAngles(Angle(LocalPlayer():EyeAngles().p, LocalPlayer():EyeAngles().y, LocalPlayer():EyeAngles().r))
end)
end)

concommand.Add("FreshyP_PropShield", function()
LocalPlayer():ConCommand("+attack")
LocalPlayer():ConCommand("gm_spawn models/props/de_tides/gate_large.mdl")
timer.Simple(0.12, function()
LocalPlayer():ConCommand("+attack2")
end)
timer.Simple(0.15, function()
LocalPlayer():ConCommand("-attack")
LocalPlayer():ConCommand("-attack2")
end)
end)

concommand.Add("FreshyP_PropLaunchForward", function() -- Fixed Kaz's script. It's actually almost the same thing as FreshyP_Rotate4.
LocalPlayer():SetEyeAngles(Angle(9, LocalPlayer():EyeAngles().y-180, LocalPlayer():EyeAngles().r))
LocalPlayer():ConCommand("+attack")
timer.Simple(0.05, function()
LocalPlayer():ConCommand("gm_spawn models/props_c17/clock01.mdl")
end)
timer.Simple(0.15, function()
LocalPlayer():SetEyeAngles(Angle(9, LocalPlayer():EyeAngles().y-180, LocalPlayer():EyeAngles().r))
end)
timer.Simple(0.25, function()
LocalPlayer():SetEyeAngles(Angle(-8, LocalPlayer():EyeAngles().y, LocalPlayer():EyeAngles().r))
end)
timer.Simple(0.5, function()
LocalPlayer():ConCommand("-attack")
LocalPlayer():ConCommand("undo")
end)
end)

concommand.Add("FreshyP_PropJump",function()
LocalPlayer():SetEyeAngles(Angle(90, LocalPlayer():EyeAngles().y, LocalPlayer():EyeAngles().r))
LocalPlayer():ConCommand("+jump")
LocalPlayer():ConCommand("+duck")
LocalPlayer():ConCommand("+attack")
timer.Simple(0.15, function()
LocalPlayer():ConCommand("gm_spawn models/props_phx/construct/glass/glass_angle360.mdl")
LocalPlayer():ConCommand("-jump")
end)
timer.Simple(0.2, function()
LocalPlayer():SetEyeAngles(Angle(7.5, LocalPlayer():EyeAngles().y, LocalPlayer():EyeAngles().r))
end)
timer.Simple(0.4, function()
LocalPlayer():ConCommand("undo")
LocalPlayer():ConCommand("-attack")
LocalPlayer():ConCommand("-duck")
end)
end)

local propjumping = true -- So you don't fuck up and do it twice in a row.
concommand.Add("FreshyP_PropJumpAttack", function()
	if propjumping ~= false then
		propjumping = false
		LocalPlayer():SetEyeAngles(Angle(90, LocalPlayer():EyeAngles().y, LocalPlayer():EyeAngles().r))
		LocalPlayer():ConCommand("+jump")
		LocalPlayer():ConCommand("+duck")
		timer.Simple(0.05, function()
		LocalPlayer():ConCommand("+attack")
		end)
		timer.Simple(0.1, function()
		LocalPlayer():ConCommand("gm_spawn models/props_phx/construct/glass/glass_angle360.mdl")
		LocalPlayer():ConCommand("-jump")
		end)
		timer.Simple(0.2, function()
		LocalPlayer():SetEyeAngles(Angle(7.5, LocalPlayer():EyeAngles().y, LocalPlayer():EyeAngles().r))
		end)
		timer.Simple(0.3, function()
		LocalPlayer():ConCommand("undo")
		LocalPlayer():ConCommand("-duck")
		LocalPlayer():SetEyeAngles(Angle(30, LocalPlayer():EyeAngles().y, LocalPlayer():EyeAngles().r))
		end)
		timer.Simple(0.4, function()
		LocalPlayer():ConCommand("gm_spawn models/props_phx/construct/glass/glass_angle360.mdl")
		end)
		timer.Simple(0.5, function()
		LocalPlayer():SetEyeAngles(Angle(40, LocalPlayer():EyeAngles().y-180, LocalPlayer():EyeAngles().r))
		end)
		timer.Simple(0.6, function()
		LocalPlayer():ConCommand("-attack")
		end)
		timer.Simple(2.35, function()
		LocalPlayer():ConCommand("propland")
		propjumping = true
		end)
	end
end)

local doo = false
local waitfaggot = false
concommand.Add("FreshyP_PropJumpForever", function()
doo = not doo
	if doo == true then
		timer.Create("wowdontdoittwice", 0.001, 0, function()
			if waitfaggot == false then
				local trace = {
				start = LocalPlayer():GetPos(),
				endpos = LocalPlayer():GetPos() + Vector(0, 0, -8192), -- To da ground (Thanks Anthr4x)
				filter = LocalPlayer()
				}
				if LocalPlayer():Alive() then 
					if ((LocalPlayer():GetVelocity().z >= -800) and (LocalPlayer():GetVelocity().z <= 0) and (LocalPlayer():GetPos():Distance(util.TraceLine(trace).HitPos) < 110)) or ((LocalPlayer():GetVelocity().z <= -800) and (LocalPlayer():GetPos():Distance(util.TraceLine(trace).HitPos) < 150)) then
						waitfaggot = true
						LocalPlayer():ConCommand("FreshyP_PropJump")
						timer.Simple(1, function()
						waitfaggot = false
						end)
					end
				end
			end
		end)
	else
		timer.Destroy("wowdontdoittwice")
	end
end)

concommand.Add("FreshyP_Propland", function()
local o = LocalPlayer():EyeAngles()
LocalPlayer():SetEyeAngles(Angle(90, LocalPlayer():EyeAngles().y, LocalPlayer():EyeAngles().r))
LocalPlayer():ConCommand("+attack")
timer.Simple(0.04, function()
LocalPlayer():ConCommand("gm_spawn models/props/cs_militia/fireplace01.mdl")
end)
timer.Simple(0.1, function()
LocalPlayer():ConCommand("undo")
LocalPlayer():ConCommand("-attack")
end)
timer.Simple(0.125, function()
LocalPlayer():SetEyeAngles(o)
end)
end)

concommand.Add("FreshyP_Rotate", function()
LocalPlayer():SetEyeAngles(Angle(LocalPlayer():EyeAngles().p, LocalPlayer():EyeAngles().y-180, LocalPlayer():EyeAngles().r))
end)

concommand.Add("FreshyP_Rotate2", function()
LocalPlayer():SetEyeAngles(Angle(-LocalPlayer():EyeAngles().p, LocalPlayer():EyeAngles().y-180, LocalPlayer():EyeAngles().r))
LocalPlayer():ConCommand("+jump")
timer.Simple(0.01, function()
LocalPlayer():ConCommand("-jump")
end)
end)

CreateClientConVar("FreshyP_Rotate3_Model", "models/Mechanics/robotics/xfoot.mdl")
concommand.Add("FreshyP_Rotate3", function()
LocalPlayer():ConCommand("gm_spawn " ..GetConVarString("FreshyP_Rotate3_Model"))
LocalPlayer():ConCommand("+attack")
timer.Simple(0.05, function()
LocalPlayer():SetEyeAngles(Angle(-LocalPlayer():EyeAngles().p, LocalPlayer():EyeAngles().y-180, LocalPlayer():EyeAngles().r))
LocalPlayer():ConCommand("+jump")
end)
timer.Simple(0.23, function()
LocalPlayer():ConCommand("undo")
LocalPlayer():ConCommand("-attack")
end)
end)

CreateClientConVar("FreshyP_Rotate4_Model", "models/props_lab/citizenradio.mdl")
concommand.Add("FreshyP_Rotate4", function()
LocalPlayer():SetEyeAngles(Angle(LocalPlayer():EyeAngles().p, LocalPlayer():EyeAngles().y-180, LocalPlayer():EyeAngles().r))
LocalPlayer():ConCommand("+attack")
timer.Simple(0.05, function()
LocalPlayer():ConCommand("gm_spawn " ..GetConVarString("FreshyP_Rotate4_Model"))
end)
timer.Simple(0.1, function()
LocalPlayer():SetEyeAngles(Angle(-LocalPlayer():EyeAngles().p, LocalPlayer():EyeAngles().y-180, LocalPlayer():EyeAngles().r))
LocalPlayer():ConCommand("+jump")
end)
timer.Simple(0.11, function()
LocalPlayer():ConCommand("-jump")
end)
timer.Simple(0.25, function()
LocalPlayer():ConCommand("undo")
LocalPlayer():ConCommand("-attack")
end)
end)

local half = true
local full = true
concommand.Add("+FreshyP_Rotate",function()
if half == true then
LocalPlayer():SetEyeAngles(Angle(LocalPlayer():EyeAngles().p, LocalPlayer():EyeAngles().y-180, LocalPlayer():EyeAngles().r))
half = false
full = true
end
end)

concommand.Add("-FreshyP_Rotate",function()
if half == false then
LocalPlayer():SetEyeAngles(Angle(LocalPlayer():EyeAngles().p, LocalPlayer():EyeAngles().y-180, LocalPlayer():EyeAngles().r))
half = true
full = true
end
end)

concommand.Add("+FreshyP_Rotate2",function()
if full == true then
LocalPlayer():SetEyeAngles(Angle(-LocalPlayer():EyeAngles().p, LocalPlayer():EyeAngles().y-180, LocalPlayer():EyeAngles().r))
LocalPlayer():ConCommand("+jump")
timer.Simple(0.01, function()
LocalPlayer():ConCommand("-jump")
end)
end
full = false
half = true
end)

concommand.Add("-FreshyP_Rotate2",function()
if full == false then
LocalPlayer():SetEyeAngles(Angle(-LocalPlayer():EyeAngles().p, LocalPlayer():EyeAngles().y-180, LocalPlayer():EyeAngles().r))
full = true
half = true
end
end)

-- It doesn't work all the time, so shut up.
concommand.Add("FreshyP_Spider", function()
LocalPlayer():ConCommand("+duck")
LocalPlayer():SetEyeAngles(Angle(90, LocalPlayer():EyeAngles().y, LocalPlayer():EyeAngles().r))
timer.Simple(0.05, function()
LocalPlayer():ConCommand("+jump")
end)
timer.Simple(0.1, function()
LocalPlayer():ConCommand("+attack")
end)
timer.Simple(0.2, function()
LocalPlayer():ConCommand("gm_spawn models/props_junk/sawblade001a.mdl")
LocalPlayer():ConCommand("-jump")
LocalPlayer():ConCommand("-duck")
end)
timer.Simple(0.25, function()
LocalPlayer():SetEyeAngles(Angle(10, LocalPlayer():EyeAngles().y, LocalPlayer():EyeAngles().r))
end)
timer.Simple(0.35, function()
LocalPlayer():SetEyeAngles(Angle(0, LocalPlayer():EyeAngles().y, LocalPlayer():EyeAngles().r))
end)
timer.Simple(0.4, function()
LocalPlayer():SetEyeAngles(Angle(-10, LocalPlayer():EyeAngles().y, LocalPlayer():EyeAngles().r))
end)
timer.Simple(0.6, function() 
LocalPlayer():SetEyeAngles(Angle(-20, LocalPlayer():EyeAngles().y-180, LocalPlayer():EyeAngles().r))
end)
timer.Simple(0.8, function()
LocalPlayer():ConCommand("undo")
LocalPlayer():ConCommand("-attack")
end)
end)

concommand.Add("FreshyP_QuickHop", function()
local o = LocalPlayer():EyeAngles()
LocalPlayer():SetEyeAngles(Angle(90, LocalPlayer():EyeAngles().y, LocalPlayer():EyeAngles().r))
LocalPlayer():ConCommand("+attack")
timer.Simple(0.05, function()
LocalPlayer():ConCommand("gm_spawn models/props_phx/gears/spur9.mdl")
end)
timer.Simple(0.1, function()
LocalPlayer():ConCommand("+attack2")
end)
timer.Simple(0.12, function()
LocalPlayer():ConCommand("undo")
LocalPlayer():ConCommand("-attack")
LocalPlayer():ConCommand("-attack2")
LocalPlayer():SetEyeAngles(o)
end)
end)

local fuckface = false
concommand.Add("FreshyP_Propkill_180shot",function() -- It's my own rendition of falco's, don't say I copy pasted it.
LocalPlayer():SetEyeAngles(Angle(LocalPlayer():EyeAngles().p, LocalPlayer():EyeAngles().y-180, LocalPlayer():EyeAngles().r))
fuckface = not fuckface
	if fuckface == true then
		hook.Add("PlayerBindPress", "replace2",function(ply, bind, pressed)
			if bind == "+moveright" and pressed then
				RunConsoleCommand("+moveleft")
				return true
			elseif bind == "+moveright" and not pressed then
				RunConsoleCommand("-moveleft")
				return true
			elseif bind == "+moveleft" and pressed then
				RunConsoleCommand("+moveright")
				return true
			elseif bind == "+moveleft" and not pressed then
				RunConsoleCommand("-moveright")
				return true
			elseif bind == "+forward" and pressed then
				RunConsoleCommand("+back")
				return true
			elseif bind == "+forward" and not pressed then
				RunConsoleCommand("-back")
				return true
			elseif bind == "+back" and pressed then
				RunConsoleCommand("+forward")
				return true
			elseif bind == "+back" and not pressed then
				RunConsoleCommand("-forward")
				return true
			end
		end)
		hook.Add("CalcView", "shit", function(origin, angle, fov)
		local abc = {}
		abc.origin = LocalPlayer():GetShootPos()
		abc.angles = Angle(LocalPlayer():EyeAngles().p,LocalPlayer():EyeAngles().y+180, LocalPlayer():EyeAngles().r)
		--abc.fov = fov <-- Useless
			if not LocalPlayer():KeyDown(IN_ATTACK) then
				hook.Remove("CalcView", "shit")
				hook.Remove("PlayerBindPress", "replace2")
				LocalPlayer():SetEyeAngles(Angle(LocalPlayer():EyeAngles().p, LocalPlayer():EyeAngles().y-180, LocalPlayer():EyeAngles().r))
				fuckface = false
				RunConsoleCommand("-forward") -- So the changing won't be an asshole and stick
				RunConsoleCommand("-back")
				RunConsoleCommand("-moveright")
				RunConsoleCommand("-moveleft")
			end
		return abc
		end)
	else 
		hook.Remove("PlayerBindPress", "replace2")
		hook.Remove("CalcView", "shit")
		RunConsoleCommand("-forward") -- So the changing won't be an asshole and stick
		RunConsoleCommand("-back")
		RunConsoleCommand("-moveright")
		RunConsoleCommand("-moveleft")
	end
end)

local fuckface = false
concommand.Add("FreshyP_Propkill_180bird",function() -- It's my own rendition of falco's, don't say I copy pasted it.
LocalPlayer():SetEyeAngles(Angle(-LocalPlayer():EyeAngles().p, LocalPlayer():EyeAngles().y-180, LocalPlayer():EyeAngles().r))
fuckface = not fuckface
	if fuckface == true then
	LocalPlayer():ConCommand("+jump")
	timer.Simple(0.01, function()
	LocalPlayer():ConCommand("-jump")
	end)
		hook.Add("PlayerBindPress", "replace",function(ply, bind, pressed)
			if bind == "+moveright" and pressed then
				RunConsoleCommand("+moveleft")
				return true
			elseif bind == "+moveright" and not pressed then
				RunConsoleCommand("-moveleft")
				return true
			elseif bind == "+moveleft" and pressed then
				RunConsoleCommand("+moveright")
				return true
			elseif bind == "+moveleft" and not pressed then
				RunConsoleCommand("-moveright")
				return true
			elseif bind == "+forward" and pressed then
				RunConsoleCommand("+back")
				return true
			elseif bind == "+forward" and not pressed then
				RunConsoleCommand("-back")
				return true
			elseif bind == "+back" and pressed then
				RunConsoleCommand("+forward")
				return true
			elseif bind == "+back" and not pressed then
				RunConsoleCommand("-forward")
				return true
			end
		end)
		hook.Add("CalcView", "cunt", function(origin, angle, fov)
		local abc = {}
		abc.origin = LocalPlayer():GetShootPos()
		abc.angles = Angle(-LocalPlayer():EyeAngles().p,LocalPlayer():EyeAngles().y+180, LocalPlayer():EyeAngles().r)
		--abc.fov = fov <-- Useless
			if not LocalPlayer():KeyDown(IN_ATTACK) then
				hook.Remove("CalcView", "cunt")
				hook.Remove("PlayerBindPress", "replace")
				LocalPlayer():SetEyeAngles(Angle(-LocalPlayer():EyeAngles().p, LocalPlayer():EyeAngles().y-180, LocalPlayer():EyeAngles().r))
				fuckface = false
				RunConsoleCommand("-forward") -- So the changing won't be an asshole and stick
				RunConsoleCommand("-back")
				RunConsoleCommand("-moveright")
				RunConsoleCommand("-moveleft")
			end
		return abc
		end)
	else 
		hook.Remove("PlayerBindPress", "replace")
		hook.Remove("CalcView", "cunt")
	RunConsoleCommand("-forward") -- So the changing won't be an asshole and stick
	RunConsoleCommand("-back")
	RunConsoleCommand("-moveright")
	RunConsoleCommand("-moveleft")
	end
end)

local fuckface = false
concommand.Add("FreshyP_Propkill_180bird2",function() -- It's my own rendition of falco's, don't say I copy pasted it.
LocalPlayer():SetEyeAngles(Angle(-LocalPlayer():EyeAngles().p, LocalPlayer():EyeAngles().y-180, LocalPlayer():EyeAngles().r))
fuckface = not fuckface
	if fuckface == true then
	LocalPlayer():ConCommand("+jump")
	timer.Simple(0.01, function()
	LocalPlayer():ConCommand("-jump")
	end)
		hook.Add("PlayerBindPress", "replace",function(ply, bind, pressed)
			if bind == "+moveright" and pressed then
				RunConsoleCommand("+moveleft")
				return true
			elseif bind == "+moveright" and not pressed then
				RunConsoleCommand("-moveleft")
				return true
			elseif bind == "+moveleft" and pressed then
				RunConsoleCommand("+moveright")
				return true
			elseif bind == "+moveleft" and not pressed then
				RunConsoleCommand("-moveright")
				return true
			elseif bind == "+forward" and pressed then
				RunConsoleCommand("+back")
				return true
			elseif bind == "+forward" and not pressed then
				RunConsoleCommand("-back")
				return true
			elseif bind == "+back" and pressed then
				RunConsoleCommand("+forward")
				return true
			elseif bind == "+back" and not pressed then
				RunConsoleCommand("-forward")
				return true
			end
		end)
		hook.Add("CalcView", "cunt", function(origin, angle, fov)
		local abc = {}
		abc.origin = LocalPlayer():GetShootPos()
		abc.angles = Angle(LocalPlayer():EyeAngles().p,LocalPlayer():EyeAngles().y+180, LocalPlayer():EyeAngles().r)
		--abc.fov = fov <-- Useless
			if not LocalPlayer():KeyDown(IN_ATTACK) then
				hook.Remove("CalcView", "cunt")
				hook.Remove("PlayerBindPress", "replace")
				LocalPlayer():SetEyeAngles(Angle(LocalPlayer():EyeAngles().p, LocalPlayer():EyeAngles().y-180, LocalPlayer():EyeAngles().r))
				fuckface = false
				RunConsoleCommand("-forward") -- So the changing won't be an asshole and stick
				RunConsoleCommand("-back")
				RunConsoleCommand("-moveright")
				RunConsoleCommand("-moveleft")
			end
		return abc
		end)
	else 
		hook.Remove("PlayerBindPress", "replace")
		hook.Remove("CalcView", "cunt")
	RunConsoleCommand("-forward") -- So the changing won't be an asshole and stick
	RunConsoleCommand("-back")
	RunConsoleCommand("-moveright")
	RunConsoleCommand("-moveleft")
	end
end)