print("Loaded Before Autorun By Function")
local oprohax = prohax or false
local prohax = {
        filesLoaded = 0;
        new_gamemode__hooks = {};
        gamemode__hooks = {};                               
        old_gamemode__hooks = {};
        OrigFuncs = {};
        FakeFuncs = {};
        CmdHooks = {};
        G = {
        }
};
if (oprohax) then
        print(tostring(oprohax));
end
function prohax.DetourFunc(func, newfunc)
        table.insert(prohax.OrigFuncs, func);
        table.insert(prohax.FakeFuncs, newfunc);
end
function prohax.CopyTable(t, lookup_table)
        if (t == nil) then return nil end
         
        local copy = {}
        setmetatable(copy, getmetatable(t))
        for i,v in pairs(t) do
                if ( !istable(v) ) then
                        copy[i] = v
                else
                        lookup_table = lookup_table or {}
                        lookup_table[t] = copy
                        if lookup_table[v] then
                                copy[i] = lookup_table[v] -- we already copied this table. reuse the copy.
                        else
                                copy[i] = prohax.CopyTable(v,lookup_table) -- not yet copied. copy it.
                        end
                end
        end
        return copy
end
prohax.G = prohax.CopyTable(_G);
setmetatable(_G, {
        ['__index'] = function(self, k)
                if k == "prohax" then
                        return prohax;
                end
        end,
        ['__newindex'] = function(self, k, v)
                prohax.G.rawset(self, k, v);
                if k == "GAMEMODE" then
                        for k,v in pairs(GAMEMODE) do
                                prohax.old_gamemode__hooks[k] = v;
                        end
                        local GMTbl = GAMEMODE;
                        if (not getmetatable(GMTbl)) then
                                setmetatable(GMTbl, {
                                        ['__newindex'] = function(self, k, v)
                                                prohax.old_gamemode__hooks[k] = v;
                                        end,
                                        ['__call'] = function(self, k, id, v)
                                                if (not prohax.gamemode__hooks[k]) then prohax.gamemode__hooks[k] = {}; end
                                                prohax.gamemode__hooks[k][id] = v
                                                if (not prohax.new_gamemode__hooks[k]) then
                                                        prohax.new_gamemode__hooks[k] = function(GM, ...)
                                                                if (prohax.old_gamemode__hooks[k]) then
                                                                        prohax.old_gamemode__hooks[k](GM, ...);
                                                                end
                                                                for k,v in pairs(prohax.gamemode__hooks[k]) do
                                                                        v(...);
                                                                end
                                                        end
                                                        prohax.DetourFunc(prohax.old_gamemode__hooks[k], prohax.new_gamemode__hooks[k]);
                                                end    
                                                prohax.G.rawset(self, k, prohax.new_gamemode__hooks[k]);
                                        end,
                                        ['__index'] = function(self, k)
                                                local returnval = prohax.old_gamemode__hooks[k] or rawget(self, k);
                                                return returnval
                                        end,
                                }
                        );
                        end
                end
        end,
});
function prohax.AddHook(type, id, func)
        GAMEMODE(type, id, func);
end
function prohax.RemoveHook(type, id)
        GAMEMODE(type, id, function() end);
end
prohax.odbginf       = debug.getinfo;
prohax.ogmt          = getmetatable;
 
 
 
local ndbginf = function(func, ...)
        local args = {...};
        local targ = func;
        local arg = args[1] or false;
        for i, fakefunc in pairs(prohax.FakeFuncs) do
                if (func == fakefunc) then
                        targ = prohax.OrigFuncs[i];
                        break;
                end
        end
         
        local tbl = arg and prohax.odbginf(targ, arg) or prohax.odbginf(targ);
        if (tbl.func) then tbl.func = func; end
        return(tbl)
end
 
local ngmt = function(tbl, ...)
if (prohax.G.debug.traceback() and (tbl == _G or tbl == GAMEMODE)) then return nil; end
	return prohax.ogmt(tbl, ...);
end
prohax.DetourFunc(debug.getinfo,   ndbginf);
debug.getinfo   = ndbginf;
prohax.concommand = prohax.CopyTable(concommand)
 
function prohax.RunMenu(str)
        prohax.G.RunStringEx(str, "prohax2M")
end


-----------------
-- Main Coding --
-----------------

timer.Simple(1, function() 
	prohax.concommand = prohax.CopyTable( concommand )
	prohax.concommand.Add( "func_load", function( ply, cmd, args )
		local lua = file.Read( args[1] )
		RunString( lua )
	end )
end )