/*
	(RUSSIAN) AM DENNY =] [65.30.50.13:27005 | STEAM_0:0:40143824]
	DayZ.txt
*/
/*####################################################################################################
This is a script/cheat developed only for use on the DayZ-GMod gamemode
This is a script including: speedhack, item finder, aimbot, ESP, Wallhacks, and other misc features
This is a semi-private script, i'm keeping it semi-private to reduce patching/detection issues
#####################################################################################################*/
local DayZ							= {}
local dayz							= {}
dayz.items							= {"spawned_weapon","base_item"} -- table containing item names
dayz.locations						= {}
dayz.safezones						= {}
dayz.cones							= {} -- these guns have really strange spread cones and range damage
dayz.convars						= {}
dayz.funcs							= {}


local old_hookadd					= hook.Add
local old_rcc						= RunConsoleCommand

function dayz.convars:add(convar,str,save,data)
	return CreateClientConVar("dayz_"..convar,str,true,false), print("added convar: dayz_"..convar.." ["..str.."]")
end

local function GetAdminType(e)
	if e:IsAdmin() && !e:IsSuperAdmin() then
		return " [A] "
	elseif( e:IsSuperAdmin() ) then
		return " [SA] "
	end
	return " "
end

dayz.convars:add("esp_info",0)
dayz.convars:add("esp_box",0)
dayz.convars:add("esp_chams",0)
dayz.convars:add("esp_items_info",0)
dayz.convars:add("esp_items_chams",0)
--dayz.convars:add("misc_autoheal",0)
dayz.convars:add("misc_sh_speed",0)
dayz.convars:add("misc_bhop",0)
dayz.convars:add("esp_dist",2000)

function RunConsoleCommand(cmd,...) -- yeah, lets find exploits
	print("[DayZ]: rcc: "..cmd)
	return old_rcc(cmd,...)
end

function IsCloseEnough(ent)
	local dist = ent:GetPos():Distance( LocalPlayer():GetPos() )
	if( dist <= GetConVarNumber("dayz_esp_dist") and ent:GetPos() != Vector( 0, 0, 0 ) ) then
		return true
	end
	return false	
end

function CreatePos( e )
	local ply = LocalPlayer()
	local center = e:LocalToWorld( e:OBBCenter() )
	local min, max = e:OBBMins(), e:OBBMaxs()
	local dim = max - min
	local z = max + min
	
	local frt	= ( e:GetForward() ) * ( dim.y / 2 )
	local rgt	= ( e:GetRight() ) * ( dim.x / 2 )
	local top	= ( e:GetUp() ) * ( dim.z / 2 )
	local bak	= ( e:GetForward() * -1 ) * ( dim.y / 2 )
	local lft	= ( e:GetRight() * -1 ) * ( dim.x / 2 )
	local btm	= ( e:GetUp() * -1 ) * ( dim.z / 2 )
	
	local FRT 	= center + frt + rgt + top; FRT = FRT:ToScreen()
	local BLB 	= center + bak + lft + btm; BLB = BLB:ToScreen()
	local FLT	= center + frt + lft + top; FLT = FLT:ToScreen()
	local BRT 	= center + bak + rgt + top; BRT = BRT:ToScreen()
	local BLT 	= center + bak + lft + top; BLT = BLT:ToScreen()
	local FRB 	= center + frt + rgt + btm; FRB = FRB:ToScreen()
	local FLB 	= center + frt + lft + btm; FLB = FLB:ToScreen()
	local BRB 	= center + bak + rgt + btm; BRB = BRB:ToScreen()
	
	local maxX = math.max( FRT.x,BLB.x,FLT.x,BRT.x,BLT.x,FRB.x,FLB.x,BRB.x )
	local minX = math.min( FRT.x,BLB.x,FLT.x,BRT.x,BLT.x,FRB.x,FLB.x,BRB.x )
	local maxY = math.max( FRT.y,BLB.y,FLT.y,BRT.y,BLT.y,FRB.y,FLB.y,BRB.y)
	local minY = math.min( FRT.y,BLB.y,FLT.y,BRT.y,BLT.y,FRB.y,FLB.y,BRB.y )
	
	return maxX, minX, maxY, minY
end

function dayz.CreateMaterial()
local BaseInfo = {
["$basetexture"] = "models/debug/debugwhite",
["$model"]       = 1,
["$translucent"] = 1,
["$alpha"]       = 1,
["$nocull"]      = 1,
["$ignorez"]	 = 1
}	
local mat	
if GetConVarString("dayz_esp_chams_type") == "Solid" then
	mat = CreateMaterial( "dayz_solid", "VertexLitGeneric", BaseInfo )
elseif GetConVarString("dayz_esp_chams_type") == "Wireframe" then
	mat = CreateMaterial( "dayz_wire", "Wireframe", BaseInfo )
end
   return mat
end

-- Addhook
local function AddHook(Type,Function)
	Name = Type.." | "..math.random(1,1000),math.random(1,2000),math.random(1,3000) -- Simple hook names
	print("added hook: ["..Type.."] | Name: "..Name.."")
	return old_hookadd(Type,Name,Function)
end

-- RemoveHook
local function RemoveHook(Type,Function)
	print("removed hook: ["..Type.."]")
	return old_hookadd(Type,Function)
end

function Chams()
local mat = dayz.CreateMaterial()
	if GetConVarNumber("dayz_esp_chams") == 1 then
		for k,v in pairs(player.GetAll()) do
			local TCol = Color(255,255,255)
			TCol = team.GetColor( v:Team() )
			if IsValid(v) and v:Health() > 0 and v:Team() != TEAM_SPECTATOR and IsCloseEnough(v) then
			//Players
			cam.Start3D(EyePos(),EyeAngles())
			local TCol = team.GetColor(v:Team())
			render.SuppressEngineLighting( true )
			render.SetColorModulation( ( TCol.r * ( 1 / 255 ) ), ( TCol.g * ( 1 / 255 ) ), ( TCol.b * ( 1 / 255 ) ) )
			render.MaterialOverride( mat )
			v:DrawModel()
			render.SuppressEngineLighting( false )
			render.SetColorModulation(1,1,1)
			render.MaterialOverride( )
			v:DrawModel()
			cam.End3D()
			end
		end
	end
end

function ESP() 
wep = "unknown"
	local ply = LocalPlayer()
	for k, e in pairs( player.GetAll() ) do
		if ( e:IsPlayer() && e:Alive() && e != LocalPlayer() && IsCloseEnough(e) ) then
			local maxX, minX, maxY, minY = CreatePos( e )	
			local Dist = e:GetPos():Distance(LocalPlayer():GetPos());
			surface.SetDrawColor( 0, 255, 0, 255 )
				if e:GetActiveWeapon() != nil then
					if type(e:GetActiveWeapon()) == "Weapon" then
						if e:GetActiveWeapon() and e:GetActiveWeapon():IsValid() then
						wep = e:GetActiveWeapon():GetPrintName()
			// BOX //
			if GetConVarNumber("dayz_esp_box") == 1 then
				surface.DrawLine( maxX, maxY, maxX, minY )
				surface.DrawLine( maxX, minY, minX, minY )					
				surface.DrawLine( minX, minY, minX, maxY )
				surface.DrawLine( minX, maxY, maxX, maxY )
			end
			if GetConVarNumber("dayz_esp_info") == 1 then	
				draw.SimpleTextOutlined(e:Nick(),"Default",maxX + 5,minY,team.GetColor(e:Team()),4,1,1,Color(0,0,0))
				draw.SimpleTextOutlined("Distance: "..math.floor(Dist),"Default",maxX + 5,minY + 10,Color(255,255,255),4,1,1,Color(0,0,0))
				draw.SimpleTextOutlined(e:Health(),"Default",maxX + 5,minY + 20,Color(255,255,255),4,1,1,Color(0,0,0))
				draw.SimpleTextOutlined(wep,"Default",maxX + 5,minY + 30,Color(255,255,255),4,1,1,Color(0,0,0))
			end
					end
				end
			end
		end
	end
end


/************
Radar
************/

function IsCustomEnt( entclass )
	return table.HasValue( dayz.items, entclass )
end

function DayZ.IsVehicle( e )	
	local ply = LocalPlayer()	
	if ( string.find( e:GetClass(), "prop_vehicle_" ) && ply:GetMoveType() ~= 0 ) then
		return true
	end
	return false
end

function DayZ.DrawText( text, font, x, y, colour, xalign, yalign )
	if (font == nil) then font = "Default" end
	if (x == nil) then x = 0 end
	if (y == nil) then y = 0 end	
	local curX = x
	local curY = y
	local curString = ""	
	surface.SetFont(font)
	local sizeX, lineHeight = surface.GetTextSize("\n")	
	for i=1, string.len(text) do
		local ch = string.sub(text,i,i)
		if (ch == "\n") then
			if (string.len(curString) > 0) then
				draw.SimpleText(curString, font, curX, curY, colour, xalign, yalign)
			end			
			curY = curY + (lineHeight/2)
			curX = x
			curString = ""
		elseif (ch == "\t") then
			if (string.len(curString) > 0) then
				draw.SimpleText(curString, font, curX, curY, colour, xalign, yalign)
			end
			local tmpSizeX,tmpSizeY =  surface.GetTextSize(curString)
			curX = math.ceil( (curX + tmpSizeX) / 50 ) * 50
			curString = ""
		else
			curString = curString .. ch
		end
	end	
	if (string.len(curString) > 0) then
		draw.SimpleText(curString, font, curX, curY, colour, xalign, yalign)
	end
end

function SetColors( e )
	local ply, class, model = LocalPlayer(), e:GetClass(), e:GetModel()
	local col	
	if ( e:IsPlayer() ) then
		col = Color(0,255,0,255)
	elseif ( e:IsNPC() ) then 
		col = Color( 255, 0, 0, 20 )		
	elseif IsCustomEnt( e:GetClass() ) then
		col = Color( 0, 200, 255, 50 )		
	else
		col = Color( 255, 255, 255, 255 )		
	end	
	return col
end

function DoChecksRadar( e )
	local ply, val = LocalPlayer(), 0	
	if ( e:IsPlayer() && e:GetMoveType() == MOVETYPE_OBSERVER ) then return false end	
	if ( !e:IsValid() || !e:IsPlayer() && !e:IsNPC() || e == ply ) then return false end
	if ( e:IsPlayer() && !e:Alive() ) then return false end
	if ( e:IsNPC() && e:GetMoveType() == 0 ) then return false end
	return true	
end

local RRadar

function Radar()	
	local Radar = vgui.Create( "DFrame" )
	Radar:SetSize( 250, 250 )	
	local rW, rH, x, y = Radar:GetWide(), Radar:GetTall(), ScrW() / 2, ScrH() / 2	
	local sW, sH = ScrW(), ScrH()
	Radar:SetPos( sW - rW - 0.1, sH - rH - ( sH - rH ) + 0 )
	Radar:SetTitle( "[DayZ] Radar" )
	Radar:SetVisible( true )
	Radar:SetDraggable( true )
	Radar:ShowCloseButton( false )
	Radar:MakePopup()
	Radar.Paint = function()
		draw.RoundedBox( 2, 0, 0, rW, rH, Color( 0, 0, 0, 100 ) )
		surface.SetDrawColor(0,255,0,255)
		surface.DrawOutlinedRect( 0, 0, rW, rH )		
		local ply = LocalPlayer()		
		local radar = {}
		radar.h		= 250
		radar.w		= 250
		radar.org	= 5000		
		local x, y = ScrW() / 2, ScrH() / 2		
		local half = rH / 2
		local xm = half
		local ym = half		
		surface.DrawLine( xm, ym - 100, xm, ym + 100 )
		surface.DrawLine( xm - 100, ym, xm + 100, ym )		
		for k, e in pairs( ents.GetAll() ) do
			if ( DoChecksRadar(e) ) then				
				local s = 6
				local col = SetColors(e)
				local color = Color( col.r, col.g, col.b, 255 )
				local plyfov = ply:GetFOV() / ( 70 / 1.13 )
				local zpos, npos = ply:GetPos().z - ( e:GetPos().z ), ( ply:GetPos() - e:GetPos() )			
				npos:Rotate( Angle( 180, ( ply:EyeAngles().y ) * -1, -180 ) )
				local iY = npos.y * ( radar.h / ( ( radar.org * ( plyfov  * ( ScrW() / ScrH() ) ) ) + zpos * ( plyfov  * (ScrW() / ScrH() ) ) ) )
				local iX = npos.x * ( radar.w / ( ( radar.org * ( plyfov  * ( ScrW() / ScrH() ) ) ) + zpos * ( plyfov  * (ScrW() / ScrH() ) ) ) )								
				local pX = ( radar.w / 2 )
				local pY = ( radar.h / 2 )			
				local posX = pX - iY - ( s / 2 )
				local posY = pY - iX - ( s / 2 )				
				local text = e:GetClass()		
				if ( e:IsPlayer() ) then 
					text = e:Nick() .. " ["..e:Health().."]"
				elseif ( e:IsNPC() ) then
					text = ""
				elseif (IsCustomEnt(e:GetClass())) then
					text = "Item"
				end				
				if iX < ( radar.h / 2 ) && iY < ( radar.w / 2 ) && iX > ( -radar.h / 2 ) && iY > ( -radar.w / 2 ) then				
					draw.RoundedBox( s, posX, posY, s, s, color )
					DayZ.DrawText(
						text,
						"DefaultSmall",
						pX - iY - 4,
						pY - iX - 15 - ( s / 2 ),
						color,
						1,
						TEXT_ALIGN_TOP
					)
				end
			end
		end
	end
	Radar:SetMouseInputEnabled( false )
	Radar:SetKeyboardInputEnabled( false )	
	RRadar = Radar
end
Radar()


function Misc()
	if input.IsKeyDown(KEY_SPACE) then
		if LocalPlayer():IsOnGround() then
			old_rcc("+Jump")
			timer.Create("Bhop",0.01, 0 ,function() old_rcc("-Jump") end)
		end
	end
	if LocalPlayer():GetActiveWeapon().Primary then
		LocalPlayer():GetActiveWeapon().Primary.Recoil = 0
	end
	local gun = LocalPlayer():GetActiveWeapon()
	if IsValid(gun) then
		if gun.data then
			gun.data.Recoil = 0
			gun.data.Cone = 0
			gun.data.Spread = 0
		end
		if gun.Primary then
			gun.Primary.Recoil = 0
			gun.Primary.Cone = 0
			gun.Primary.Spread = 0
		end
	end
end

function hudpaint()
	ESP()
end
AddHook("HUDPaint",hudpaint)

function think()
	Misc()
end
AddHook("Think",think)

function postdraw()
	Chams()
end
AddHook("PostDrawEffects",postdraw)


//##################//
// 		menu		//
//##################//
	
