--[[
	lua/heartbot.lua
	heart | (STEAM_0:1:6930453)
	===DStream===
]]

-----------------------------------------------------
-- i am, in fact, greater than 3.
-----------------------------------------------------


lt3 = {}
lt3.ents = {"money_printer", "spawned_money", "spawned_weapon", "shipment"}
lt3.enemyCols = {}
lt3.enemyCols.r = 255
lt3.enemyCols.g = 0
lt3.enemyCols.b = 0

lt3.enemyColsVis = {}
lt3.enemyColsVis.r = 0
lt3.enemyColsVis.g = 255
lt3.enemyColsVis.b = 0


lt3.aim = {}


local _fov		= CreateClientConVar("h_aim_fov", "5", true, false)
local _los		= CreateClientConVar("h_aim_los", "0", true, false)
local _predict	= CreateClientConVar("h_aim_predict", "1", true, false)
local _rage	= CreateClientConVar("h_aim_rage", "1", true, false)
local _view	= CreateClientConVar("h_aim_view", "1", true, false)
local _recoil	= CreateClientConVar("h_norecoil", "1", true, false)

local seizefire = {
	weapon_crowbar = true,	
	weapon_phycannon = true,
	weapon_physgun = true,
	weapon_pistol = false,
	weapon_357 = false,
	weapon_smg = false,
	weapon_ar2 = false,
	weapon_shotgun = false,
	weapon_crossbow = false,
	weapon_rpg = false,
	weapon_grenade = true,
	gmod_tool = true,
}
local delay = {
	weapon_pistol = 0.25
}
local prediction = {
	weapon_pistol = 40000,
	weapon_357 = 20500,
	weapon_smg = 39000,
	weapon_ar2 = 39000,
	weapon_shotgun = 35000,
	weapon_crossbow = 3485,
	weapon_rpg = 0
}
lt3.toggleChams = false

me = LocalPlayer();

function lt3.addHook(hookname, uniqueid, func)
	--Call the DLL method to add that hook or just do this for now.
	hook.Add(hookname, uniqueid, func);
end

function lt3.addConCommand(cmdname, cmdfunc)
	--Call the DLL method to add that concommand or just do this for now.
	concommand.Add(cmdname, cmdfunc)
end


local COLOR_FRIENDLY = Color(0, 255, 0, 255)
local COLOR_ENEMY = Color(255, 0, 0, 255)
local COLOR_DEAD = Color(40, 40, 40, 255)
local COLOR_TRACKING = Color(0, 255, 255, 255)
local COLOR_OBJECT = Color(255, 255, 255, 255)

local function Normal( a )
	/* Returns a normalized Angle */
	return math.abs(math.NormalizeAngle(a))
end

function lt3.makemat()
	local BaseInfo = {
		["$basetexture"] = "models/debug/debugwhite",
		["$model"]       = 1,
		["$alpha"]       = 1,
		["$nocull"]      = 1,
		["$ignorez"]	 = 1
	}

	local mat = CreateMaterial( "lt3", "VertexLitGeneric", BaseInfo )

	return mat
end

function lt3.GetTargetPos(ent)
	if ent:IsPlayer() then
		if (string.lower(tostring(ent:GetModel())) == "models/player/combine_soldier_prisonguard.mdl" || string.lower(tostring(ent:GetModel())) == 
"models/player/arctic.mdl") then
			attach = ent:GetAttachment(3)
			attach.Pos = attach.Pos-- + Vector(0,0,6)
--			print("DRRRR")
		else
			if (string.lower(tostring(ent:GetModel())) == "models/error.mdl") then
				attach = ent
				attach.Pos = ent:GetPos() + Vector(0,0,40)
				return attach.Pos
			end

			attach = ent:GetAttachment(1)

			if not attach then return end

		end
		
		if lt3.toggleHeadshots and attach then
			return attach.Pos + ent:GetAngles():Forward() * -4
		else
			if attach then
				return attach.Pos
			else 
				if ent:Crouching() then
					return ent:GetPos() + (jewbot_OFFSET * 0.586)
				else
					return ent:GetPos() + jewbot_OFFSET
				end
			end
		end
	else
		return ent:GetPos() + jewbot_OFFSET
	end
end

function lt3.IsVisible(ent)
	local tracedata = {}
		tracedata.start = LocalPlayer():GetShootPos()
		tracedata.endpos = ent:GetPos()
		tracedata.mask = MASK_SHOT
		tracedata.filter = {ply , LocalPlayer()}
	Trace = util.TraceLine(tracedata)
	if Trace.Hit then return false else return true end
end

local function GetBoneScreenPos( yer, bone )
	local pBone = yer:LookupBone(bone)

	if pBone then
    	return yer:GetBonePosition( yer:LookupBone( bone ) ):ToScreen()
    else
    	return yer:GetPos():ToScreen()
    end
end

function lt3.Chams()
	if !lt3.toggleChams then return end
	for k,e in pairs(player.GetAll()) do
		if(e:Alive()) then
			cam.Start3D( EyePos(), EyeAngles() )
			local coltouse = team.GetColor(e:Team())

			if( !lt3.IsVisible(e) ) then
				local mat = lt3.makemat()
				render.SuppressEngineLighting( true )
				render.SetColorModulation( (coltouse.r/255 ), (coltouse.g/255), ( coltouse.b/255 ) )
				render.MaterialOverride( mat )
				e:DrawModel()
				render.SuppressEngineLighting( false )
				render.SetColorModulation(  (lt3.enemyCols.r/255 ), (lt3.enemyCols.g/255), ( coltouse.b/255 )  )
				render.MaterialOverride( mat )
				e:DrawModel()
			elseif(lt3.IsVisible(e) ) then
				local mat = lt3.makemat()
				render.SuppressEngineLighting( true )
				render.SetColorModulation(  (lt3.enemyColsVis.r/255 ), (lt3.enemyColsVis.g/255), ( lt3.enemyColsVis.b/255 )  )
				render.MaterialOverride( mat )
				e:DrawModel()
				render.SuppressEngineLighting( false )
				render.SetColorModulation( (lt3.enemyColsVis.r/255 ), (lt3.enemyColsVis.g/255), ( lt3.enemyColsVis.b/255 ) )
				render.MaterialOverride( mat )
				e:DrawModel()
			end
			cam.End3D( EyePos(), EyeAngles() )

		end
	end
end

function lt3.ESP()
	for k,v in pairs(player.GetAll()) do
		lt3.DrawPlayer(v)

	end
	for _, ent in pairs(ents.GetAll()) do
		if ent:IsValid() then
			for _, b in pairs(lt3.ents) do
				if string.find(string.lower(ent:GetClass()), b) then
					lt3.DrawEnt(ent)
				end
			end
		end
	end
end

function lt3.DrawPlayer(pl)
	if pl == me then return true end
	if pl:Alive()then
		local pos = lt3.GetTargetPos(pl) or pl:GetPos()

		local colortouse = team.GetColor(pl:Team())
		-- if pl:Team() ~= me:Team() then
		-- 	colortouse = team.GetColor(pl:Team())
		-- end


		local BONES = {
		    { "ValveBiped.Bip01_Head1", "ValveBiped.Bip01_Neck1" },
		    { "ValveBiped.Bip01_Neck1", "ValveBiped.Bip01_Pelvis" },
		    { "ValveBiped.Bip01_Neck1", "ValveBiped.Bip01_L_UpperArm" },
		    { "ValveBiped.Bip01_Neck1", "ValveBiped.Bip01_R_UpperArm" },
		    { "ValveBiped.Bip01_L_UpperArm", "ValveBiped.Bip01_L_Forearm" },
		    { "ValveBiped.Bip01_R_UpperArm", "ValveBiped.Bip01_R_Forearm" },
		    { "ValveBiped.Bip01_R_Forearm", "ValveBiped.Bip01_R_Hand" },
		    { "ValveBiped.Bip01_L_Forearm", "ValveBiped.Bip01_L_Hand" },
		    { "ValveBiped.Bip01_Pelvis", "ValveBiped.Bip01_L_Thigh" },
		    { "ValveBiped.Bip01_Pelvis", "ValveBiped.Bip01_R_Thigh" },
		    { "ValveBiped.Bip01_L_Thigh", "ValveBiped.Bip01_L_Calf" },
		    { "ValveBiped.Bip01_R_Thigh", "ValveBiped.Bip01_R_Calf" },
		    { "ValveBiped.Bip01_R_Calf", "ValveBiped.Bip01_R_Foot" },
		    { "ValveBiped.Bip01_L_Calf", "ValveBiped.Bip01_L_Foot" },
		}

	    for k,v in ipairs( BONES ) do
	        pos1 = GetBoneScreenPos( pl, v[1] )
	        pos2 = GetBoneScreenPos( pl, v[2] )
	        surface.SetDrawColor(colortouse)
	        surface.DrawLine( pos1.x, pos1.y, pos2.x, pos2.y )
	    end

	    local mypos = me:GetPos()
	    local distance = pos:Distance(mypos)
		local size = ScrW() * 0.007

		local lplyPos = pos:ToScreen()
		
		draw.SimpleText(pl:GetName(), "ChatFont" , lplyPos.x  , lplyPos.y + size + 10, colortouse , TEXT_ALIGN_CENTER , TEXT_ALIGN_CENTER)
		draw.DrawText("Health "..pl:Health(), "DefaultFixedDropShadow", lplyPos.x, lplyPos.y + size + 30, colortouse, TEXT_ALIGN_LEFT)
		draw.DrawText(""..math.floor(pl:GetPos():Distance(mypos)), "DefaultFixedDropShadow", lplyPos.x, lplyPos.y + size + 54, colortouse, TEXT_ALIGN_LEFT)
		draw.DrawText("Set: "..pl:GetNetworkedString("usergroup", "none"), "DefaultFixedDropShadow", lplyPos.x, lplyPos.y + size + 66, team.GetColor(pl:Team()), TEXT_ALIGN_LEFT)
		local wep = pl:GetActiveWeapon()
		if wep:IsValid() then
			draw.DrawText("Weapon: "..wep:GetClass().." ("..wep:EntIndex()..")", "DefaultFixedDropShadow", lplyPos.x, lplyPos.y + size + 42, colortouse, TEXT_ALIGN_LEFT)
		else
			draw.DrawText("Unarmed", "DefaultFixedDropShadow", lplyPos.x, lplyPos.y + size + 42, colortouse, TEXT_ALIGN_LEFT)
		end
	else
		if not pl then return end

	    local pos = lt3.GetTargetPos(pl):ToScreen()
		if pos.visible then
			local mypos = me:GetPos()
			local size = ScrW() * 0.007
			surface.SetDrawColor(0, 0, 0, 255)
			surface.DrawLine(pos.x - size, pos.y, pos.x + size, pos.y)
			surface.DrawLine(pos.x, pos.y - size, pos.x, pos.y + size)
			draw.SimpleText(pl:Name(), "ChatFont", pos.x, pos.y + size + 10, COLOR_DEAD, TEXT_ALIGN_CENTER)
			draw.SimpleText("** DEAD **", "DefaultFixedDropShadow", pos.x, pos.y + size + 30, COLOR_DEAD, TEXT_ALIGN_CENTER)
			draw.SimpleText("Dist: "..math.floor(pl:GetPos():Distance(mypos)), "DefaultFixedDropShadow", pos.x, pos.y + size + 42, COLOR_DEAD, TEXT_ALIGN_LEFT)
		end
	end
end

function lt3.DrawEnt(ent)
	local pos = ent:GetPos()
	pos = pos:ToScreen()
	if pos.visible then
		local mypos = me:GetPos()
		local size = ScrW() * 0.007
		surface.SetDrawColor(0, 255, 0, 255)
		surface.DrawLine( pos.x - size, pos.y, pos.x + size, pos.y )
		surface.DrawLine( pos.x, pos.y - size, pos.x, pos.y + size)
		draw.SimpleText("< "..ent:GetClass().." >", "ChatFont", pos.x, pos.y + size + 10, COLOR_ENEMY, TEXT_ALIGN_CENTER)
		draw.SimpleText("Health: "..ent:Health(), "DefaultFixedDropShadow", pos.x, pos.y + size + 30, COLOR_OBJECT, TEXT_ALIGN_LEFT)
		draw.SimpleText("Dist: "..math.floor(ent:GetPos():Distance(mypos)), "DefaultFixedDropShadow", pos.x, pos.y + size + 42, COLOR_OBJECT, TEXT_ALIGN_LEFT)
	end
end

function lt3.ValidTarget(e) 
	if ( !e:IsValid() || ( e == me ) || ( !e:IsNPC() && !e:IsPlayer() )) then return false end

	m = e:GetMoveType()	

	if ( m == MOVETYPE_NONE ) then return false end
	if ( e:IsPlayer() ) then
		if ( !e:Alive() ) || ( m == MOVETYPE_OBSERVER )  then return false end
	end
		
	return true
end


local tlUpd = CurTime()
local trgLs = {}
local aimTarget = nil
local aiming = false
local nextshot = 0

local function SimulateShot()
	/* Simulates the shooting of a weapon */
	local w = me:GetActiveWeapon()
	if ( CurTime() < nextshot || !w:IsWeapon() || seizefire[w:GetClass()] ) then return end
	
	local n = (delay[w:GetClass()] || 0.025); if ( w.Primary && w.Primary.Delay ) then n = w.Primary.Delay end
	me:ConCommand("+attack; wait 2; -attack;"); nextshot = CurTime() + n
end


function lt3.aim.selectTarget()
	if ( !aiming || (aimTarget && lt3.ValidTarget(aimTarget)) ) then return end

	aimTarget = nil
	local a = me:GetPos()
	if ( #trgLs == 0 || CurTime() >= tlUpd ) then 
		for _, e in pairs( ents.GetAll() ) do
			if ( lt3.ValidTarget(e) && !table.HasValue(trgLs, e) ) then table.insert(trgLs, e) end
		end
		tlUpd = CurTime() + 0.1
	end
	for _, e in pairs( trgLs ) do
		if ( !e:IsValid() ) then 
			table.remove(trgLs, _)
		elseif ( !aimTarget ) then 
			if(lt3.ValidTarget(e) && lt3.IsVisible(e)) then
				aimTarget = e
			end
			--a = me:GetAimVector():Angle() - (lt3.GetTargetPos(e) - me:GetShootPos()):Angle()
			--if ( Normal(a.y) < _fov:GetInt() && Normal(a.p) < _fov:GetInt() && lt3.IsVisible(e))  then aimTarget = e end 
		end
	end
end

local function GetShootTrace( e )

	local t = {
		start	= me:GetShootPos(),
		endpos		= me:GetShootPos() + (me:GetAimVector() * 163840),
		filter		= { me }
	}

	return util.TraceLine(t)
end
function lt3.aim.Bot( u )
	local viewangle = u:GetViewAngles()

	if ( !aiming || !aimTarget || !lt3.ValidTarget(aimTarget) || _los:GetBool() && lt3.IsVisible(aimTarget) ) then aimTarget = nil; return end

	local vector = lt3.GetTargetPos(aimTarget) - me:GetShootPos()
	if ( _predict:GetBool() ) then
		local position, weapon = me:GetPos(), me:GetActiveWeapon()
		local speed, distance = position:Distance(position + me:GetVelocity()), me:GetPos():Distance(aimTarget:GetPos())
		
		/* Player & Target prediction */
		local p, t = Vector(0, 0, 0), Vector(0, 0, 0)
		if ( distance < 4000 && speed > 0 ) then p = me:GetVelocity() * distance / (speed * distance * 0.125) end
		if ( weapon:IsWeapon() && prediction[weapon:GetClass()] != 0 ) then t = aimTarget:GetVelocity() * distance / (prediction[weapon:GetClass()] || 150000) end
		
		vector = vector - p + t
	end

	u:SetViewAngles(vector:Angle()); viewangle = vector:Angle()
	
	// Shoot {
		if (  u:KeyDown(IN_ATTACK) ) then return end
		
		local t = GetShootTrace(aimTarget)
		if ( t.Entity == aimTarget && (t.HitGroup >= 0 && t.HitGroup <= 3) || _predict:GetBool() && lt3.IsVisible(aimTarget, 0) ) then SimulateShot() end
	// }
end

function lt3.aim.cView()
	if ( !_view:GetBool() ) then return end
	
	local w = me:GetActiveWeapon()
	if ( w.Primary ) then w.Primary.Recoil = 0 end
	
	return { origin = o, angles = viewangle, fov = f }
end

local function AddEnt(ent, b, args)
	table.insert(lt3.ents, args[1])
end

local function RemoveEnt(ent,b,args)
	for k,v in pairs(lt3.ents) do
		if v == args[1] then
			table.remove(k)
		end
	end
end

function lt3.norecoil()
	if(_recoil:GetBool()) then
		if ValidEntity(LocalPlayer():GetActiveWeapon()) and (LocalPlayer():GetActiveWeapon().Primary and LocalPlayer():GetActiveWeapon().Primary.Recoil != 0) then
			LocalPlayer():GetActiveWeapon().OldRecoil = LocalPlayer():GetActiveWeapon().Recoil or (LocalPlayer():GetActiveWeapon().Primary and LocalPlayer():GetActiveWeapon().Primary.Recoil)
			LocalPlayer():GetActiveWeapon().Recoil = 0
			LocalPlayer():GetActiveWeapon().Primary.Recoil = 0
		end
	elseif ValidEntity(LocalPlayer():GetActiveWeapon()) and (LocalPlayer():GetActiveWeapon().Primary and LocalPlayer():GetActiveWeapon().Primary.Recoil == 0) and LocalPlayer():GetActiveWeapon().OldRecoil then
		LocalPlayer():GetActiveWeapon().Recoil = LocalPlayer():GetActiveWeapon().OldRecoil
		LocalPlayer():GetActiveWeapon().Primary.Recoil = LocalPlayer():GetActiveWeapon().OldRecoil
	end
end

lt3.addConCommand("+h_aim", function() aiming = true end)
lt3.addConCommand("-h_aim", function() aiming = false end)
lt3.addConCommand("h_chams", function() lt3.togglechams = !lt3.togglechams end)

lt3.addConCommand("entadd", AddEnt)
lt3.addConCommand("entrem", RemoveEnt)
lt3.addHook("HUDPaint", "ChildPorn", lt3.ESP)
lt3.addHook("CreateMove", "h1", lt3.aim.Bot)
lt3.addHook("Think", "h1", lt3.aim.selectTarget)
lt3.addHook("Think", "h2", lt3.aim.norecoil)
lt3.addHook("CalcView", "h1", lt3.aim.cView)





timer.Create("fix",1,1,function()
lt3.addHook("RenderScreenspaceEffects","re",lt3.Chams)
end)
