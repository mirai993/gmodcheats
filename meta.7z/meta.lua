--[[
	MOD/lua/Meta.lua [#8349 (#8349), 3191466187, UID:3962639149]
	Meta | STEAM_0:1:25812285 <74.103.204.136:27005> | [18.07.14 05:37:34PM]
	===BadFile===
]]

//
/*

	Meta.lua
	
	Purpose: a simple lua hack without using concommands, hooks, timers, or anything global / detectable by common lua anticheats
	
	P.S: I hope this fucking works....
	
	Author: Nautical
*/

// Config

local config = {
	
	esp = true,
	noRecoil = true,
	ignoreSteamFriends = true,
	ignoreAdmins = true,
	highlightFriends = true,
	findTraitors = true,
}

/* Workarounds */

-- Binds

local binds = {}

local function addBind( type,bind,onPress,onRelease,runOnce )

	binds[ #binds + 1 ] = { type = type,bind = bind,onPress = onPress,onRelease = onRelease,runOnce = runOnce,hasRun = false }
end

local function runBinds()

	for k,v in pairs( binds ) do
	
		if ( v.type == "KEY" && input.IsKeyDown( v.bind ) || v.type == "MOUSE" && input.IsMouseDown( v.bind ) ) then
				
			if ( v.runOnce ) then
			
				if ( !v.hasRun ) then
			
					v.onPress()
				end
			else
			
				v.onPress()
			end
			
			v.hasRun = true
		else
		
			if ( v.hasRun ) then
			
				v.hasRun = false
				v.onRelease()
			end
		end
	end
end

-- Timers

local timers = {}
local currentTime = CurTime()

local function addTimer( delay,reps,func )

	timers[ #timers + 1 ] = { delay = delay,reps = reps,repCount = 0,func = func }
end

local function runTimers()

	for k,v in pairs( timers ) do
		
		if ( CurTime() > currentTime + v.delay ) then
			
			v.func()
			
			v.repCount = v.repCount + 1
			
			if ( v.repCount == v.reps ) then
			
				timers[ k ] = nil
			end
		
			currentTime = CurTime()
		end
	end
end

/* Hack code */

-- Player filtering

local espPlayers = {}
local aimbotPlayers = {}

local function filterPlayers()

	espPlayers = {}
	aimbotPlayers = {}
	
	for k,v in pairs( player.GetAll() ) do
		
		if ( v == LocalPlayer() ) then continue end
		if ( !v:Alive() ) then continue end
		if ( v:Team() == TEAM_SPECTATOR ) then continue end
		
		table.insert( espPlayers,v )
		
		if ( config.ignoreSteamFriends && v:GetFriendStatus() == "friend" ) then continue end
		if ( config.ignoreAdmins && v:IsAdmin() ) then continue end
		
		if ( GAMEMODE && GAMEMODE.Name && string.find( GAMEMODE.Name , "Trouble in Terror" ) ) then
		
			if ( v:IsActiveTraitor() ) then continue end // isActiveTraitor only works properly if YOU are traitor, so this will ignore traitor buddies
		end
		
		table.insert( aimbotPlayers,v )
	end
end

-- Traitor scanning

local traitors = {}
local foundTWeps = {}
local foundNormalWeps = {}

local exceptions = { "weapon_ttt_smokegrenade","weapon_ttt_unarmed","weapon_ttt_improvised","weapon_zm_carry","weapon_ttt_m16","weapon_ttt_wtester","weapon_zm_revolver",
"weapon_zm_mac10","weapon_zm_sledge","weapon_zm_improvised","weapon_zm_shotgun","weapon_ttt_glock","weapon_ttt_confgrenade","weapon_zm_rifle","weapon_zm_pistol","weapon_zm_molotov" }

local function scanForTraitors()
	
	if ( !config.findTraitors ) then return end
	if ( !GAMEMODE || !GAMEMODE.Name || !string.find( GAMEMODE.Name , "Trouble in Terror" ) ) then return end
	
	if( GetRoundState() == 4 ) then
	
		traitors = {}
		foundTWeps = {}
		foundNormalWeps = {}
		
	elseif( GetRoundState() == 2 ) then
	
		for k,v in pairs( ents.FindByClass( "weapon_*" ) ) do
		
			if ( table.HasValue( exceptions,v:GetClass() ) ) then continue end
		
			if ( foundNormalWeps[ v:GetClass() ] == nil ) then
			
				foundNormalWeps[ v:GetClass() ] = true
			end
		end
		
	elseif( GetRoundState() == 3 && table.Count( foundNormalWeps ) > 0 ) then
	
		for i,p in pairs( espPlayers ) do
	
			if ( traitors[ p:EntIndex() ] ) then continue end
			if ( p:IsDetective() ) then continue end
			
			if ( p:IsActiveTraitor() ) then
				
				traitors[ p:EntIndex() ] = true
				
				continue
			end
			
			for k,v in pairs( ents.FindByClass( "weapon_*" ) ) do
				
				if ( table.HasValue( exceptions,v:GetClass() ) ) then continue end
				if ( foundTWeps[ v:EntIndex() ] ) then continue end
			
				if ( foundNormalWeps[ v:GetClass() ] == nil ) then // this weapon is new and has not been detected
				
					if ( v:GetPos():Distance( p:GetPos() ) <= 37 ) then
					
						foundTWeps[ v:EntIndex() ] = true
						traitors[ p:EntIndex() ] = true
						
						chat.AddText( Color( 255,0,0,255 ),"Possible traitor: " .. p:Nick() .. " with " .. v:GetClass() )
					end
				end
			end
		end
	end
end

-- Esp

local function drawEsp()

	if ( !config.esp ) then return end

	if ( LocalPlayer():Team() == TEAM_SPECTATOR ) then return end
	
	for k,v in pairs( espPlayers ) do
		
		local pos = ( v:GetPos() + Vector( 0,0,80 ) ):ToScreen()
		
		if ( !pos.visible ) then continue end
		
		local col = team.GetColor( v:Team() )
		
		if ( config.highLightFriends && v:GetFriendStatus() == "friend" && col.a != 150 ) then
		
			col.a = 150
			
		else
		
			col.a = 255
		end
		
		if ( traitors[ v:EntIndex() ] ) then
			
			col = Color( 255,75,0,255 )
		end
		
		draw.SimpleText( v:Nick(),"BudgetLabel",pos.x,pos.y,col,TEXT_ALIGN_CENTER,TEXT_ALIGN_CENTER )
	end
end

-- Aimbot

local function traceHit( ply )

	local tr = {}
	tr.start = LocalPlayer():GetShootPos()
	tr.endpos = ply:EyePos()
	tr.mask = MASK_SHOT
	tr.filter = { LocalPlayer(),ply }
	
	return util.TraceLine( tr ).Hit
end

local function runAimbot()
	
	local bestPly = { 0,nil } // dist to crosshair

	for k,v in pairs( aimbotPlayers ) do
	
		if ( traceHit( v ) ) then continue end
		
		local scrnPos = v:EyePos():ToScreen()
		
		local distance = math.Distance( ScrW() / 2,ScrH() / 2,scrnPos.x,scrnPos.y )
		
		if ( distance < bestPly[ 1 ] || bestPly[ 2 ] == nil ) then
		
			bestPly = { distance,v }
		end
	end
	
	if ( bestPly[ 2 ] == nil ) then return end
	
	local eyePos = bestPly[ 2 ]:GetAttachment( bestPly[ 2 ]:LookupAttachment( "eyes" ) ).Pos + bestPly[ 2 ]:GetVelocity() / 45 - LocalPlayer():GetVelocity() / 45
	
	local ang = ( eyePos - LocalPlayer():GetShootPos() ):Angle()
	ang.y = math.NormalizeAngle( ang.y )
	
	LocalPlayer():SetEyeAngles( ang )
end

-- Remove recoil

local weps = {}

local function removeRecoil()

	if ( !config.noRecoil ) then return end

	local activeWep = LocalPlayer():GetActiveWeapon()
	
	if ( !activeWep:IsValid() ) then return end
	if ( activeWep.Primary == nil ) then return end
	
	if ( weps[ activeWep:GetClass() ] == nil ) then
	
		activeWep.Primary.Recoil = 0
		weps[ activeWep:GetClass() ] = true
	end
end

-- Menu

local function quickCheckBox( text,var,listPanel )

	local myBox = vgui.Create( "DButton" )
	myBox:SetText( text .. " : " .. tostring( config[ var ] ) )
	
	function myBox:DoClick()
	
		config[ var ] = !config[ var ]
		myBox:SetText( text .. " : " .. tostring( config[ var ] ) )
	end
	
	listPanel:AddItem( myBox )
end

local function metaMenu()

	local frame = vgui.Create( "DFrame" )
	frame:SetTitle( "Meta, by Nautical" )
	frame:SetSize( 300,220 )
	frame:Center()
	frame:MakePopup()
	
	local optionList = vgui.Create( "DPanelList" )
	optionList:SetParent( frame )
	optionList:SetPos( 5,30 )
	optionList:SetSize( frame:GetWide() - 10,frame:GetWide() - 35 )
	optionList:SetSpacing( 10 )
	
	quickCheckBox( "Esp","esp",optionList )
	quickCheckBox( "Highlight Friends","highlightFriends",optionList )
	quickCheckBox( "Ignore Steam Friends","ignoreSteamFriends",optionList )
	quickCheckBox( "Ignore Admins","ignoreAdmins",optionList )
	quickCheckBox( "No recoil","noRecoil",optionList )
	quickCheckBox( "Find Traitors","findTraitors",optionList )
end

-- Metatables 

local meta = FindMetaTable( "Player" )

function meta:Health()
	
	filterPlayers()
	drawEsp()
	removeRecoil()
	
	runBinds()
	runTimers()
	
	return 100
end

-- Binds

addBind( "KEY",KEY_INSERT,metaMenu,function() end,true ) // menu

addBind( "KEY",KEY_DELETE,function() // panic button

	function meta:Health()
	
	
		return 100
	end

end,function() end,true )

/*
addBind( "MOUSE",MOUSE_4,function() // speed hack

	RunConsoleCommand( "host_framerate","0.08" )
	
end,function() 

	RunConsoleCommand( "host_framerate","0" )

end,true )
*/

addBind( "MOUSE",MOUSE_5,runAimbot,function() end,false ) // aimbot

addBind( "MOUSE",MOUSE_MIDDLE,function()

	for i = 1,18 do
		
		timer.Simple( i * .02,function()
			
			LocalPlayer():SetEyeAngles( LocalPlayer():EyeAngles() - Angle( 0,10,0 ) )
		end )
		
		if ( i == 18 ) then
		
			timer.Simple( .39,function()
			
				LocalPlayer():SetEyeAngles( LocalPlayer():EyeAngles() + Angle( 0,180,0 ) )
			end )
		end
	end

end,function() end,true )

-- Timers

addTimer( 5,-1,scanForTraitors )
