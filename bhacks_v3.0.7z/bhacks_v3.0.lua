--[[
	MOD/lua/1.lua
	gяєу нєℓℓισѕ | STEAM_0:0:53429341 <66.168.88.138:27006> | [27-10-13 11:39:25PM]
	===BadFile===
]]


if ( SERVER ) then return; end

Version 					= "B-Hacks v3" // Version of B-Hacks
Versionw 					= "B-Hacks v3!" // WelcomeMsg Version
nick 						= LocalPlayer():Nick()

local HeadLines 		= CreateClientConVar ("B-Hacks_HeadLines", 1, true, false)
local EyeLines 			= CreateClientConVar ("B-Hacks_EyeLines", 1, true, false)
local Skybox 			= CreateClientConVar ("B-Hacks_SkyBox", 0, true, false)
local DeathHax 			= CreateClientConVar ("B-Hacks_Sounds_DeathHax", 0, true, false)
local SoundPropThrow 	= CreateClientConVar ("B-Hacks_Sounds_PropThrow", 0, true, false)
local FlashLightSpam 	= CreateClientConVar ("B-Hacks_FlashLightSpam", 0, true, false)

local colors				= {}
red							= Color(255,0,0,255);
black						= Color(0,0,0,255);
green						= Color(0,255,0,255);
white						= Color(255,255,255,255);
blue						= Color(0,0,255,255);
cyan						= Color(0,255,255,255);
pink 						= Color(255,0,255,255);
blue						= Color(0,0,255,255);
grey						= Color(100,100,100,255);
gold						= Color(255,228,0,255);
lblue						= Color(155,205,248);
lgreen						= Color(174,255,0);
iceblue						= Color(116,187,251,255);

local GUI = {}
g = table.Copy(_G)
GUI.CreateMove = GAMEMODE.CreateMove
GUI.HUDPaint = GAMEMODE.HUDPaint

GUI.KeyList = { 
[1] = {char = "m", 		val = KEY_M}, 
[2] = {char = "space",  val = KEY_SPACE},
[4] = {char = "p", 		val = KEY_P},
[3] = {char = "z", 		val = KEY_Z},
}

GUI.Bools = {
["miscbhop"] = true,
["espactive"] = true,
["espchams"] = true,
["espwireframe"] = false,
["espsolid"] = false,
["espplayers"] = true,
["espnpcs"] = true,
["espnick"] = true,
["espfriend"] = true,
["espweapon"] = true,
["esparmor"] = true,
["espadmin"] = true,
["esphealth"] = true,
	["norecoil"] = true
}

GUI.Vars = {
["espchamdist"] = 15000,
["esptextdist"] = 15000
}

GUI.Binds = {
["+bhop"] = KEY_SPACE,
["+spam"] = KEY_P,
["esptoggle"] = KEY_M,
["+menu"] = KEY_5
}

--//   L		H 		R	    //--
--\\	E		 A		 T		\\--
--//	 T		  X		  !		//--
--\\		T	 	S			\\--
--//		 H		 T			//--
--\\		  E		  A			\\--
							
 
local function LeeroyJinkenz() // Leeeeeroy Jinkenz!
	surface.PlaySound("leeroy.wav")
end

local function IGWelcome() // Simple and nice welcome.
	chat.AddText("")
	chat.AddText(blue, "[B-Hacks]", gold, " Welcome to B-Hacks V3 " ..nick, " !")
	chat.AddText(blue, "[B-Hacks]", gold, " All Player/Server info has been printed in console!")
	chat.AddText("")
end
 
 local function Help()
 print("")
 print("-----=Help=-----")
 print("__ClientSideVars__")
 print("")
 print("B-Hacks_FlashLightSpam 1/0 - Upon turning this to 1 holding P will spam the flashlight!")
 print("")
 print("")
 print("_Commands_")
 print("B-Hacks_")
 
 end
 concommand.Add("B-Hacks_Help", Help)
 
local function ConsoleWelcome()
print("-------------------------------------------------------------------------------------------")
print("===========================================================================================")
print("*******************************************************************************************")
print("*******************************************************************************************")
print("===========================================================================================")
print("-------------------------------------------------------------------------------------------")
print(" ")
print("Hello!")
print("Welcome to " ..Versionw)
print("")
print("--------ServerInfo--------")
print("")
print("-=Players=-")
print("")

	for k, v in pairs(player.GetAll()) do
		print("Players: " .. v:GetName() .. " SteamID: " .. v:SteamID() .. " Nick: " .. v:Nick())
	end
	
print("")
print("")

	local Friends = ""
		for k, v in pairs(player.GetAll()) do
			if v:GetFriendStatus() == "friend" then
				Friends = ", " .. v:GetName() .. " :: " .. v:SteamID() .. " :: " .. v:Nick() .. Friends
	end
		end
				if Friends ~= "" then
				print("Friends: " .. string.sub(Friends, 3))
				end
				
print("")
print("-=End of Players=-")
print("")
end

local function printplayers()
print("")
print("-=Players=-")
print("")

	for k, v in pairs(player.GetAll()) do
		print("Players: " .. v:GetName() .. " :: " .. v:SteamID() .. " :: " .. v:Nick())
	end
	
print("")
print("")

	local Friends = ""
		for k, v in pairs(player.GetAll()) do
			if v:GetFriendStatus() == "friend" then
				Friends = ", " .. v:GetName() .. " :: " .. v:SteamID() .. " :: " .. v:Nick() .. Friends
	end
		end
				if Friends ~= "" then
				print("Friends: " .. string.sub(Friends, 3))
				end
				
print("")
print("-=End of Players=-")
print("")
end
concommand.Add("B-Hacks_PrintPlayers",printplayers )

function GAMEMODE:CreateMove(ucmd) // NoRecoil Made by: Simple // Bhop Inspired by Simple... But is SUCKED ASS! So I fixed it :D << Sowwy Simple :/
GUI.CreateMove(ucmd)
	if(GUI.Bools["norecoil"]) then
	local wep = LocalPlayer():GetActiveWeapon()
		if IsValid(wep) and wep.Primary then
			wep.Primary.Recoil = 0
		end
	end
	
		if GUI.Bools["miscbhop"] then 
			if g.input.IsKeyDown(GUI.Binds["+bhop"]) then
				if g.LocalPlayer():OnGround() then g.RunConsoleCommand("+jump")
					timer.Simple(0, function() g.RunConsoleCommand("-jump") 
				end )
			end
		end
	end
end

local function FlashLightSpam()
	if g.input.IsKeyDown(GUI.Binds["+spam"]) then
		RunConsoleCommand("impulse", "100")
	end
end
--hook.Add("Think", "Test", FlashLightSpam)
local function NamesOnHeads()
	local ScrWidth, ScrHeight = ScrW(), ScrH()
	local aimVec = LocalPlayer():GetAimVector()
	local localPos = EyePos()

		local Size = 9

		surface.SetDrawColor(0,0,0,160)
		surface.DrawLine(ScrWidth/2-Size, ScrHeight/2 + 1, ScrWidth/2+Size, ScrHeight/2 + 1)
		surface.DrawLine(ScrWidth/2-Size, ScrHeight/2 - 1, ScrWidth/2+Size, ScrHeight/2 - 1)

		surface.DrawLine(ScrWidth/2 + 1, ScrHeight/2 - Size, ScrWidth/2 + 1, ScrHeight/2 + Size)
		surface.DrawLine(ScrWidth/2 - 1, ScrHeight/2 - Size, ScrWidth/2 - 1, ScrHeight/2 + Size)

		surface.SetDrawColor(255,255,255,255)
		surface.DrawLine(ScrWidth/2 - Size, ScrHeight/2, ScrWidth/2 + Size, ScrHeight/2)
		surface.DrawLine(ScrWidth/2, ScrHeight/2 - Size, ScrWidth/2, ScrHeight/2 + Size)

	end
	concommand.Add("cross", NamesOnHeads)
function ESP() // Esp inspired by Simple Fixed & Added more content by Coke :D
	/*if GUI.Bools["espactive"] then
		cam.Start3D(g.EyePos(), g.EyeAngles() )
			for _, v in g.pairs(ents.GetAll()) do
				if IsValid(v) and ((GUI.Bools["espnpcs"] and v:IsNPC() and v:Health() > 0) or
				(GUI.Bools["espplayers"] and v:IsPlayer() and v:Alive() and g.team.GetName(v:Team() ) != "Spectators" )) and v != g.LocalPlayer() and v:GetPos():Distance(g.LocalPlayer():GetPos()) <= GUI.Vars["espchamdist"] then
					local chamcol = Color(134, 13, 255, 255)
						if v:IsPlayer() then chamcol = g.team.GetColor(v:Team() ) or Color(134,13,255,255)
						end
						if GUI.Bools["espwireframe"] then
						v:SetMaterial("models/wireframe") elseif
						GUI.Bools["espsolid"] then
						v:SetMaterial("models/debug/debugwhite") else
						
						end
						g.render.SetColorModulation(chamcol.r / 255, chamcol.g / 255, chamcol.b / 255 ) 
						g.render.SetBlend(chamcol.a / 255 )
						v:SetColor(chamcol)
						v:DrawModel()
						v:SetColor(Color(255,255,255))
						v:SetMaterial("")
				end
			end
	cam.End3D()*/
for _, v in g.pairs(g.player.GetAll()) do
	if (GUI.Bools["espplayers"] and v:IsPlayer() and v:Alive() and g.team.GetName(v:Team()) != "Spectators") and v != g.LocalPlayer() and v:GetPos():Distance(g.LocalPlayer():GetPos()) <= GUI.Vars["esptextdist"] then
	local y = -10
	local CallName = v:Nick()
	local rank = "User"
	local rankcol = g.Color(150,0,255,255)

		if v:IsUserGroup("Admin") or v:IsUserGroup("admin") then rank = "Admin" rankcol = g.Color(255,10,10,255) elseif
		v:IsUserGroup("SuperAdmin") or v:IsUserGroup("superadmin") or v:IsUserGroup("Super Admin") or v:IsUserGroup("super admin") then rank = "Super Admin" rankcol = g.Color(0,150,255,255) elseif
		v:IsUserGroup("Moderator") or v:IsUserGroup("moderator") then rank = "Moderator" rankcol = g.Color(200,220,12,255) elseif
		v:IsUserGroup("vip") or v:IsUserGroup("VIP") or v:IsUserGroup("donator") then rank = "VIP" rankcol = g.Color(255, 0, 0, 255) elseif
		v:IsUserGroup("operator") or v:IsUserGroup("Operator") then rank = "Operator" rankcol = g.Color(200,220,12,255) elseif
		v:IsUserGroup("member") or v:IsUserGroup("Member") then rank = "Member" rankcol = g.Color(5,255,5) elseif
		v:IsUserGroup("Owner") or v:IsUserGroup("owner") then rank = "Owner" rankcol = g.Color(0,150,255,255)elseif
		v:IsUserGroup("CoOwner") or v:IsUserGroup("coowner") or v:IsUserGroup("Co-Owner") or v:IsUserGroup("co-owner") or v:IsUserGroup("Co Owner") then rank = "Co-Owner" rankcol = g.Color(0,150,255,255) else
		rank = "User" rankcol = Color(255,255,255)
		end

	local color = g.Color(255,255,255,255)
	local ESPPos = (v:GetPos()+g.Vector(0,0,45)):ToScreen()


			if GUI.Bools["esphealth"] then
				g.draw.SimpleText("H: "..v:Health(), "Default", ESPPos.x, ESPPos.y + y, color, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
				y = y -12
			end
				if GUI.Bools["esparmor"] then
					if v:Armor() >= 1 then
					g.draw.SimpleText("A: " ..v:Armor(), "Default", ESPPos.x, ESPPos.y + y, color, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
					y = y -12
				end
			end
			
			if GUI.Bools["espadmin"] then
				g.draw.SimpleText(rank, "Default", ESPPos.x, ESPPos.y + y, rankcol, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
				y = y -12
			end
			
			if GUI.Bools["espfriend"] then
				if v:GetFriendStatus() == "friend" then
					color = g.Color(5,150,255)
					g.draw.SimpleText("Friend", "Default", ESPPos.x, ESPPos.y + y, color, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
					y = y -12
				end
			end
			
			if GUI.Bools["espnick"] then
				local color = g.Color(255,255,255,255)
				g.draw.SimpleText(v:Nick(), "Default", ESPPos.x, ESPPos.y + y, color, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
				y = y -12
			end
		end
	end
	
-----------------------------
	if (GetConVarNumber( "B-Hacks_HeadLines" ) == 1) then
	local neededAngles = Angle(-90, 0, 0)
	cam.Start3D(EyePos(), EyeAngles())
		for k,ply in pairs(player.GetAll()) do
			if ply != LocalPlayer() && ply:Alive() then
			local shootPos = ply:GetShootPos()
			local data = {}
			data.start = shootPos
			data.endpos = shootPos + neededAngles:Forward() * 10000
			data.filter = ply
			local tr = util.TraceLine(data)
			cam.Start3D2D(shootPos, neededAngles, 1)
				if IsValid(tr.Entity) then
				surface.SetDrawColor(255, 140, 0, 255)
				else
				surface.SetDrawColor(0, 255, 0, 255)
				end
			surface.DrawLine(0, 0, tr.HitPos:Distance(shootPos), 0)
			cam.End3D2D()
			end
		end
	cam.End3D()
	else end

end
hook.Add("HUDPaint", "ESP", ESP)

function EyeSight() // FUCK YOU MY BRAIN CANT DO IT NOW! LATER OK LATER!
	for k,v in pairs(player.GetAll()) do
if (GetConVarNumber( "B-Hacks_EyeLines" ) == 1) then
cam.Start3D(EyePos(), EyeAngles())
for k,ply in pairs(player.GetAll()) do
if ply != LocalPlayer() && ply:Alive() then
local shootPos = ply:GetShootPos()
local eyeAngles = ply:EyeAngles()
local data = {}
data.start = shootPos
data.endpos = shootPos + eyeAngles:Forward() * 10000
data.filter = ply
local tr = util.TraceLine(data)
cam.Start3D2D(shootPos, eyeAngles, 1)
if IsValid(tr.Entity) then
surface.SetDrawColor(255, 140, 0, 255)
else
if v:GetFriendStatus() == "friend" then
surface.SetDrawColor(0, 0, 255, 255)
else
surface.SetDrawColor(0, 0, 255, 255)
end
end
surface.DrawLine(0, 0, tr.HitPos:Distance(shootPos), 0)
cam.End3D2D()
end
end
cam.End3D()
else end
end
end
hook.Add("RenderScreenspaceEffects", "EyeSightt", EyeSight)

local function Skybox() // Thought I would like to mention.... Falco your gay!
if (GetConVarNumber( "B-Hacks_SkyBox" ) == 1) then
render.Clear(5, 5, 5, 255)
return true
else
return false
end
end
hook.Add("PreDrawSkyBox", "Meh", Skybox)

local function PropThrow() // Pew!
if (GetConVarNumber( "B-Hacks_Sounds_PropThrow" ) == 1) then
surface.PlaySound("pew.wav")
end
end
hook.Add("PhysgunDrop", "PropThrow2", PropThrow)

local function healtha() // Ban dem haxerz
if (GetConVarNumber( "B-Hacks_Sounds_DeathHax" ) == 1) then
if LocalPlayer():Health() <= 0 then
surface.PlaySound("hacks01.wav")
end
end
end
hook.Add("Think", "HealthHax", healtha)

local function Undoall() // Stfu its easy.
RunConsoleCommand("Undo")
RunConsoleCommand("Undo")
RunConsoleCommand("Undo")
RunConsoleCommand("Undo")
RunConsoleCommand("Undo")
RunConsoleCommand("Undo")
RunConsoleCommand("Undo")
RunConsoleCommand("Undo")
RunConsoleCommand("Undo")
RunConsoleCommand("Undo")
end
concommand.Add("B-Hacks_UndoAll", Undoall)

surface.CreateFont( "Arial", { font = "Arial", size = 18, weight = 400 } )

function DrawVersion() // SHH! YOU HAVE NEVER SEEN THIS! 
	draw.WordBox( 16, 1800, 5, Version,"Arial",Color(0,0,255,150),gold)
end
hook.Add("HUDPaint", "DrawVersion", DrawVersion)

LeeroyJinkenz()
IGWelcome()
ConsoleWelcome()


-- Dont worry this is just temp :/ Someone ddous falco for meh.

local ents = ents
local GetConVarNumber = GetConVarNumber
local GetGlobalInt = GetGlobalInt
local hook = hook
local LocalPlayer = LocalPlayer
local math = math
local pairs = pairs
local player = player
local render = render
local RunConsoleCommand = RunConsoleCommand
local string = string
local surface = surface
local table = table
local timer = timer
local type = type
local util = util
local IsValid = IsValid

local _R = debug.getregistry()
local SetColor = _R.Entity.SetColor
local GetColor = _R.Entity.GetColor
local SetMat = _R.Entity.SetMaterial
local GetMat = _R.Entity.GetMaterial
local GetClass = _R.Entity.GetClass
local GetRagdollEntity = _R.Player.GetRagdollEntity
local SetNoDraw = _R.Entity.SetNoDraw
local GetVelocity = _R.Entity.GetVelocity
local VelLength = _R.Vector.Length

-- XRay variables!
local RayOn = false -- Xray toggle variable
local entityMaterials = {}
local entityColors = {}
local VIEWMODEL = NULL
local NoDraws = {
	["cluaeffect"] = true,
	["fog"] = true,
	["waterlodcontrol"] = true,
	["clientragdoll"] = true,
	["envtonemapcontroller"] = true,
	["entityflame"] = true,
	["func_tracktrain"] = true,
	["env_sprite"] = true,
	["env_spritetrail"] = true,
	["prop_effect"] = true,
	["class c_sun"] = true,
	["class C_ClientRagdoll"] = true,
	["class C_BaseAnimating"] = true,
	["clientside"] = true,
	["illusionary"] = true,
	["shadowcontrol"] = true,
	["keyframe"] = true,
	["wind"] = true,
	["gmod_wire_hologram"] = true,
	["effect"] = true,
	["stasisshield"] = true,
	["shadertest"] = true,
	["portalball"] = true,
	["portalskydome"] = true,
	["cattails"] = true
}

-- cvars // I Was not sticking with his BAD spelling.
local PROPColor 			= CreateClientConVar("B-Hacks_Xray_Prop-Color", "1,0,0,1", true, false) --falco_xrayPROPColor
local PROPBGColor 			= CreateClientConVar("B-Hacks_Xray_Prop-BackGround-Color", "255,0,0,50", true, false) --falco_xrayPROPBGColor
local MINEColor 			= CreateClientConVar("B-Hacks_Xray_Mine-Color", "0,0,255,1", true, false) --falco_xrayMINEColor
local MINEBGColor 			= CreateClientConVar("B-Hacks_Xray_Prop-Mine-BackGround-Color", "0,0,255,40", true, false) --falco_xrayPROPMINEBGColor
local HOLDINGColor 			= CreateClientConVar("B-Hacks_Xray_Holding-Color", "0,0,0,40", true, false) --falco_xrayHOLDINGColor
local PLYColor 				= CreateClientConVar("B-Hacks_Xray_Player-Color", "0,1,0,1", true, false) --falco_xrayPLAYERcolor
local repmat 				= CreateClientConVar("B-Hacks_Xray_Material", "mat1", true, false) --falco_xraymaterial

local cPROPColor 			= Color(unpack(string.Explode(",", PROPColor:GetString())))
local cPROPBGColor 			= Color(unpack(string.Explode(",", PROPBGColor:GetString())))
local cPROPMINEBGColor 		= Color(unpack(string.Explode(",", MINEBGColor:GetString())))
local cPROPHOLDINGColor 	= Color(unpack(string.Explode(",", HOLDINGColor:GetString())))
local cMINEColor 			= Color(unpack(string.Explode(",", MINEColor:GetString())))
local cPLYColor 			= Color(unpack(string.Explode(",", PLYColor:GetString())))
local FRayMat 				= repmat:GetString()

local ExecuteFray

-- Overriding effects!
local OldEffectFunctions = {}
OldEffectFunctions.render_AddBeam = render.AddBeam
OldEffectFunctions.render_DrawSprite = render.DrawSprite
local OLDUtilEffect = util.Effect

local EMITTER = FindMetaTable("CLuaEmitter")
EMITTER.OldAdd = EMITTER.OldAdd or EMITTER.Add
function EMITTER:Add(...)
	if RayOn then
		local returnal = table.Copy(FindMetaTable("CLuaParticle"))
		for k,v in pairs(returnal or {}) do
			if type(v) == "function" then
				returnal[k] = function() end
			end
		end
		return returnal--override all the functions of this FAKE particle to do nothing
	end
	return self:OldAdd(...)
end

function render.AddBeam(...)
	if not RayOn then
		return OldEffectFunctions.render_AddBeam(...)
	end
end

function render.DrawSprite(a,b,c,d,e, ...)
	if not RayOn or e then
		OldEffectFunctions.render_DrawSprite(a,b,c,d, ...)
	end
end

-- Register babygodded players
local babygod, bgodtime
local function RegisterSpawn()
	local Pls = player.GetAll()
	for ply=1, #Pls do
		Health = Pls[ply]:Health()
		if Health < 1 and Pls[ply].Spawned then
			Pls[ply].Spawned = false
			Pls[ply].BabyGod = false
		elseif Health > 0 and not Pls[ply].Spawned then
			Pls[ply].Spawned = true
			Pls[ply].BabyGod = true
			timer.Simple(bgodtime, function()
				if not IsValid(Pls[ply]) then return end
				Pls[ply].BabyGod = false
				if entityColors[Pls[ply]] then entityColors[Pls[ply]] = Color(255,255,255,255) end
			end)
		end
	end
end
hook.Add("InitPostEntity", "a", function()
	babygod = tobool(GetConVarNumber("babygod"))
	bgodtime = tonumber(GetConVarNumber("babygodtime"))
	if babygod then
		hook.Add("Think", "FalcoDetectSpawn", RegisterSpawn)
	end
end)

local function ToggleFRay(ply, cmd, args)
	FRayMat = repmat:GetString()
	RunConsoleCommand("r_cleardecals")

	-- Turn some annoying things off


	-- Turning xray off
	if RayOn then
		surface.PlaySound("buttons/button19.wav")

		local ENTS = ents.GetAll()
		for v = 1, #ENTS do
			if not IsValid(ENTS[v]) then continue end

			SetMat(ENTS[v], entityMaterials[ENTS[v]])
			local z = entityColors[ENTS[v]]
			if z and type(z) == "table" then
				SetColor(ENTS[v], Color(z.r, z.g, z.b, z.a))
			else
				SetColor(ENTS[v], Color(255,255,255,255))
			end


			local model = ENTS[v]:GetModel() or ""
			local class = GetClass(ENTS[v])
			if NoDraws[class] or NoDraws[model] then -- Hide effects
				SetNoDraw(ENTS[v], false)
			end
		end
		entityColors = {}

		hook.Remove("PostDrawOpaqueRenderables", "falco_xray")
		hook.Remove("OnEntityCreated", "FalcoRayEntityInPVS")
		hook.Remove("PreDrawSkyBox", "removeSkybox")

		util.Effect = OLDUtilEffect
	else
		-- Play a nice sound
		surface.PlaySound("buttons/button1.wav")

		-- Get rid of ropes
		for k,v in pairs(ents.FindByClass("class C_RopeKeyframe")) do
			SetColor(v, Color(0,0,0,0))
		end

		-- and effects
		util.Effect = function() end

		local ENTS = ents.GetAll()
		for v = 1, #ENTS do
			ExecFRayOnce(ENTS[v])
		end

		-- Add the rendering hook
		hook.Add("PostDrawOpaqueRenderables", "falco_xray", ExecuteFray)
		hook.Add("OnEntityCreated", "FalcoRayEntityInPVS", function(ent)
			ExecFRayOnce(ent)
		end)
	end
	RayOn = not RayOn
end
concommand.Add("B-Hacks_Xray", ToggleFRay) // Stfu

function ExecFRayOnce(v)
	if not IsValid(v) then return end
	local color = GetColor(v)
	local r,g,b,a = color.r, color.g, color.b, color.a
	local class = GetClass(v)
	local low = string.lower(class)
	local model = v:GetModel() or ""

	-- Set some entities to not draw
	if NoDraws[class] or NoDraws[model] then
		SetNoDraw(v, true)
		return
	end

	v:SetRenderMode(RENDERMODE_TRANSALPHA)
	if v:IsNPC() and (r ~= 0 or g ~= 0 or b ~= 255 or a ~= 255) then
		entityColors[v] = Color(r,g,b,a)
		SetColor(v, Color(0, 0, 255, 30))
	elseif class == "viewmodel" and (r ~= 0 or g ~= 0 or b ~= 0 or a ~= 30)  then
		VIEWMODEL = v
		entityColors[v] = Color(r,g,b,a)
		SetColor(v, Color(0, 0, 0, 30))
		SetMat(v, "mat1")
	elseif string.find(class, "ghost") and a ~= 100 then
		entityColors[v] = Color(r,g,b,a)
		SetColor(v, Color(255,255,255,100))
	elseif (class == "drug_lab" or class == "money_printer") and (r ~= 255 or g ~= 0 or b ~= 100 or a ~= 50) then
		entityColors[v] = Color(r,g,b,a)
		SetColor(v, Color(255, 0, 100, 50))
	elseif class == "prop_physics" or v:IsPlayer() then
		entityColors[v] = Color(r,g,b,a)
	elseif not v:IsPlayer() and not v:IsNPC() and class ~= "prop_physics" and class ~= "prop" and class ~= "drug_lab" and class ~= "money_printer" and class ~= "func_breakable" and class ~= "func_wall" and not v:IsWeapon() and class ~= "viewmodel" and not v.NoXRay and not string.find(class, "ghost") and ( r ~= 255 or g ~= 200 or b ~= 0 or a ~= 100) then
		entityColors[v] = Color(r,g,b,a)
		--SetColor(v, 255, 200, 0, 100)
		SetColor(v, Color(0, 255, 0, 100))
	end
	if class ~= "viewmodel" and GetMat(v) ~= FRayMat and class ~= "func_door" and class ~= "func_door_rotating" and class ~= "prop_door_rotating" and class ~= "func_breakable" and class ~= "func_wall" and not v.NoXRay and not string.find(class, "ghost") then
		entityMaterials[v] = GetMat(v)
		SetMat(v, FRayMat)
	end
end

local ScaleNormal = Vector()
local ScaleOutline1	= Vector()
local function DrawEntityOutline(ent, size, r, g, b, a)
	--size = size or 1.0
	render.SetBlend(a)
	render.SetColorModulation(r, g, b)

	-- First Outline
	--ent:SetModelScale(ScaleOutline1 * size) -- WARNING: RESIZE LAGS
	--SetMaterialOverride("mat4")
	ent:DrawModel()

	-- Revert everything back to how it should be
	render.MaterialOverride(nil)
	--ent:SetModelScale(ScaleNormal)


end

function ExecuteFray()
	if not RayOn then return end

	local PROPS = ents.FindByClass("prop_physics")
	local PLYS = player.GetAll()

	local ang = EyeAngles()
	local eyePos = EyePos()
	cam.Start3D(eyePos, ang)
		for v = 1, #PROPS do
			if IsValid(PROPS[v]) then
				local prop = PROPS[v]

				local IsHolding = LocalPlayer().IsHolding == PROPS[v]

				local r,g,b,a =
					cPROPColor.r,
					cPROPColor.g,
					cPROPColor.b,
					cPROPColor.a

				if PROPS[v].IsMine then
					r, g, b, a = cMINEColor.r, cMINEColor.g, cMINEColor.b, cMINEColor.a or a
				end
				if PROPS[v].IsBreakable and PROPS[v]:IsBreakable() then
					r, g, b = (PROPS[v].IsMine and cMINEColor.r) or 0, 0, 255
				end

				SetColor(PROPS[v], Color(r, g, b, a))
				SetMat(PROPS[v], "mat4")
				if PROPS[v].IsMine then
					local col = IsHolding and cPROPHOLDINGColor or cPROPMINEBGColor
					DrawEntityOutline(PROPS[v], 1.00, col.r/255, col.g/255, col.b/255, col.a/255)
				elseif ang:Forward():Dot(PROPS[v]:GetPos() - eyePos) > 0 then
					DrawEntityOutline(PROPS[v], 1.00, cPROPBGColor.r/255, cPROPBGColor.g/255, cPROPBGColor.b/255, cPROPBGColor.a/255)
				end
				SetMat(PROPS[v], FRayMat)
			end
		end

		for v = 1, #PLYS do
			if IsValid(PLYS[v]) then
				if PLYS[v].BabyGod then
					SetColor(PLYS[v], Color(150,0,255,255))
					if PLYS[v] == LocalPlayer() and IsValid(VIEWMODEL) then
						SetMat(VIEWMODEL, "mat2")
						SetColor(VIEWMODEL, 255,0,0,40)
					end
				else
					if PLYS[v] == LocalPlayer() and IsValid(VIEWMODEL) then
						SetMat(VIEWMODEL, "mat1")
						SetColor(VIEWMODEL, Color(0,0,0,30))
					end
					SetColor(PLYS[v], Color(cPLYColor.r, cPLYColor.g, cPLYColor.b, cPLYColor.a))
				end
				SetMat(PLYS[v], "mat4")
				DrawEntityOutline(PLYS[v], 1.00, 1, 0.2, 0.2, 0.17)
				SetMat(PLYS[v], FRayMat)
				if IsValid(PLYS[v]:GetActiveWeapon()) then
					SetMat(PLYS[v]:GetActiveWeapon(),  "mat4")
					DrawEntityOutline(PLYS[v]:GetActiveWeapon(), 1.00, 1, 0.2, 0.2, 0.17)
				end
			end
			if GetRagdollEntity(PLYS[v]) then
				SetNoDraw(GetRagdollEntity(PLYS[v]), true)
			end
		end
	cam.End3D()

end