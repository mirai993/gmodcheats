--[[
	lua/ddesp.lua
	";exit | (STEAM_0:0:21513525)
	===DStream===
]]

  	local dd = CreateClientConVar("daz_showdruggy", 1, true, false)
  	local g = table.Copy(_G);
  	local ggn = "";

  	surface.CreateFont("DefaultSmallDropShadow", {
		font	= "Tahoma",
		size	= 16,
		weight	= 500,
		shadow	= true,
	}
)	


   function DD()
   		ggn = g.gmod.GetGamemode().Name;
    if(GetConVarNumber("daz_showdruggy") == 1 and ggn and g.string.find(ggn, "PERP") or g.string.find(ggn, "agrp")) then
        g.surface.SetDrawColor(g.Color(25, 25, 25, 225));
       
        g.surface.DrawRect(g.ScrW()-g.ScrW()+15, g.ScrH()-g.ScrH()+5, 175, 60);
       
        g.surface.SetTextColor(g.Color(255, 255, 255, 255));
        g.surface.SetTextPos(g.ScrW()-g.ScrW()+55, g.ScrH()-g.ScrH()+5);
        g.surface.SetFont("DefaultSmallDropShadow");
        g.surface.DrawText("DRUG DEALER");
       
        g.surface.SetFont("DefaultFixedDropShadow");
       
        local buy = "None";
        local sell = "None";
       
        local buyi = g.GetGlobalInt("perp_druggy_buy", 0);
        local selli = g.GetGlobalInt("perp_druggy_sell", 0);
       
        if(g.string.find(ggn, "PERP2") or g.string.find(ggn, "PERP3") or g.string.find(ggn, "PERP4") or g.string.find(ggn, "PERP")) then
            if(buyi == 2) then
                buy = "Meth";
            elseif(buyi == 1) then
                buy = "Weed";
            elseif(buyi == 3) then
                buy = "Shrooms";
            elseif(buyi == 4) then
            	buy = "Coke";
            end
        elseif(g.string.find(ggn, "agrp")) then
            if(buyi == 2) then
                buy = "Meth";
            elseif(buyi == 1) then
                buy = "Weed";
            elseif(buyi == 3) then
                buy = "Hulk";
            elseif(buyi == 4) then
                buy = "LSD";
            elseif(buyi == 5) then
                buy = "Shrooms";
            elseif(buyi == 6) then
                buy = "Cocaine";
            end
        else
            if(buyi == 2) then
                buy = "Weed";
            elseif(buyi == 3) then
                buy = "Shrooms";
            end
        end
       
        if(g.string.find(ggn, "agrp") or g.string.find(ggn, "PERP X2")) then
            if(selli == 1) then
                sell = "Seeds";
            elseif(selli == 2) then
                sell = "LSD";
            elseif(selli == 3) then
                sell = "Hulk";
            elseif(selli == 4) then
                sell = "Shrooms";
            elseif(selli == 5) then
                sell = "Cocaine";
            end
        else
            if(selli == 1) then
                sell = "Seeds";
            elseif(selli == 2) then
                sell = "Shrooms";
            elseif(selli == 3) then
            	sell = "Coke";
            end
        end
       
        surface.SetTextPos(g.ScrW()-g.ScrW()+25, g.ScrH()-g.ScrH()+30);
        surface.DrawText("Currently buying " .. buy);
       
        surface.SetTextPos(g.ScrW()-g.ScrW()+25, g.ScrH()-g.ScrH()+45);
        surface.DrawText("Currently selling  " .. sell);
    end
end
hook.Add("HUDPaint","ASDASDADAS", DD)