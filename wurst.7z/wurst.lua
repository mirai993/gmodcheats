--[[
	h.lua
	DrogenViech | (STEAM_0:0:8615861)
	===DStream===
]]

if not CLIENT then return end


timer.Simple(0,function()
	if util.__TraceLine then
		util.TraceLine = util.__TraceLine
		util.__TraceLine = util.TraceLine
	else
		--timer.Simple(1,fixtraces)
	end
end)

--util.RelativePathToFull = function() return "/home/dev/null/Steam/steamapps/dev/null/garrysmod/garrysmod/." end



-- local highest = Vector(0,0,0)
-- local lowest = Vector(32768,32768,32768)

--surface.CreateFont(font_name,size,weight,antialiasing,additive,new_font_name,drop_shadow,outlined)

surface.CreateFont("Small Fonts",12,400,false,false,"labelfxddd",false,true)
--surface.CreateFont("coolvetica",14,400,false,true,"labelfxddd",false,false)

--local laser = Material("effects/laser_citadel1")--"effects/laser_citadel1"
local arrows = Material("drogenviech/arrows")--"effects/laser_citadel1"
local laser = Material("drogenviech/laser3")--"effects/laser_citadel1"
--local laser = Material("effects/laser_citadel1")--"effects/laser_citadel1"
--local laser = Material("particle/screenspace_fog")--"effects/laser_citadel1"
--surface.CreateFont(String font_name,Number size,Number weight,Boolean antialiasing,Boolean additive,String new_font_name,Boolean drop_shadow,Boolean outlined)

--draw.SimpleText("TEST","ScoreboardText",ScrW()/2,ScrH()/2,Color(0,0,0,255),TEXT_ALIGN_LEFT,TEXT_ALIGN_LEFT,5,Color(255,255,255,255))





local X = -50
local Y = -100
local W = 100
local H = 200

local COLOR_WHITE = Color(255,255,255,255)
local myTrace = {}
local myTraceRes = {}
 myTraceRes.mask = MASK_SOLID_BRUSHONLY
local angleCap = math.cos(math.rad(95/2))

local esp = true
local chams = true
local spin = false
local espteam = true
local flashspam = false

local hitindactor_bhit = false
local hitindactor_ntime = 0
local hitindactor_bsound = false

local npcs = false
local players = true
local props = false
local thirdperson = false

local zielen = false
local bhop = false
local triggerbot = false
local normalattack = false
local superattack = false
local silent = false
local silentshoot = false
local getnewtargettimer = 0
local nattack = false
local nextani = CurTime() + 1
local sattack = false
local silenttime = 1
local allteams = team.GetAllTeams()
local target = nil
local angle = Angle(0,0,0)
local lastang = Angle(0,0,0)
local turnangle = Angle(0,0,0)
local myview = Angle(0,0,0)
local spinflag = false
local zooming = false
local zoom = 90
local gotviewback = false
local hasmaterial = {}
local beams = {}
local debugm = false
local liste = {}
local shootprops = false
local shootprops_current = 0
local shootprops_done = {}
local shootmodel = ""
local shooting = 0
local nospin = {
	"weapon_fishing_rod",
	--"weapon_physgun",
}

local measuredraw = false
local measure1 = nil
local measure2 = nil

local mode = 0
local selected_text = nil
local freeze_labels = false

-- entities for which labels should be shown
local textents = {}
local entstable = {}
local vec_forward = 0
local vec_left = 0
local vec_up = 0
--hook.Add("EntityRemoved","local EntityRemoved",function(ent) local textents[ent] = nil end)



local vecformat = "%.2f,%.2f,%.2f"
function FormatVector(value)
	return string.format(vecformat,value.x,value.y,value.z)
end

function FormatAngle(value)
	return string.format(vecformat,value.p,value.y,value.r)
end

function pairs_sortvalues(tbl,criterion)
	local crit = criterion and
		function(a,b)
			return criterion(tbl[a],tbl[b])
		end
	or
		function(a,b)
			return tbl[a] < tbl[b]
		end

	tmp = {}
	for k,v in pairs(tbl) do table.insert(tmp,k) end
	table.sort(tmp,crit)

	local iter,state,index,k = ipairs(tmp)
	return function()
		index,k = iter(state,index)
		if index == nil then return nil end
		return k,tbl[k]
	end
end

local bones = {
	["models/combine_scanner.mdl"] = "Scanner.Body",
	["models/hunter.mdl"] = "MiniStrider.body_joint",
	["models/combine_turrets/floor_turret.mdl"] = "Barrel",
	["models/dog.mdl"] = "Dog_Model.Eye",
	["models/vortigaunt.mdl"] = "ValveBiped.Head",
	["models/antlion.mdl"] = "Antlion.BodyBone",
	["models/antlion_guard.mdl"] = "Antlion_Guard.Body",
	["models/antlion_worker.mdl"] = "Antlion.Head_Bone",
	["models/zombie/fast_torso.mdl"] = "ValveBiped.HC_BodyCube",
	["models/zombie/fast.mdl"] = "ValveBiped.HC_BodyCube",
	["models/headcrabclassic.mdl"] = "HeadcrabClassic.SpineControl",
	["models/headcrabblack.mdl"] = "HCBlack.body",
	["models/headcrab.mdl"] = "HCFast.body",
	["models/zombie/poison.mdl"] = "ValveBiped.Headcrab_Cube1",
	["models/zombie/classic.mdl"] = "ValveBiped.HC_Body_Bone",
	["models/zombie/classic_torso.mdl"] = "ValveBiped.HC_Body_Bone",
	["models/zombie/zombie_soldier.mdl"] = "ValveBiped.HC_Body_Bone",
	["models/combine_strider.mdl"] = "Combine_Strider.Body_Bone",
	["models/combine_dropship.mdl"] = "D_ship.Spine1",
	["models/combine_helicopter.mdl"] = "Chopper.Body",
	["models/gunship.mdl"] = "Gunship.Body",
	["models/lamarr.mdl"] = "HeadcrabClassic.SpineControl",
	["models/mortarsynth.mdl"] = "Root Bone",
	["models/synth.mdl"] = "Bip02 Spine1",
	["models/vortigaunt_slave.mdl"] = "ValveBiped.Head",
}




local function getpos(ent)
	local bone = "ValveBiped.Bip01_Head1"
	local special = bones[string.lower(ent:GetModel() or "")]

	if special then
		if type(special) == "string" then
			local bone = ent:LookupBone(special)
			if bone then
				local pos = ent:GetBonePosition(bone)
				if pos then return pos end
			end
		elseif type(special) == "Vector" then
			return ent:LocalToWorld(special)
		elseif type(special) == "function" then
			local pos = pcall(special,ent)
			if pos then return pos end
		end
	end

	local head = ent:LookupBone(bone)
	if head then
		local pos = ent:GetBonePosition(head)
		if pos then return pos end
	end
	return ent:LocalToWorld(ent:OBBCenter())
end


local function vistest(ent)
	local trace = {}
	trace.start = LocalPlayer():GetShootPos()
	trace.endpos = getpos(ent)
	trace.filter = player.GetAll()
	trace.mask = MASK_SHOT
	local tr = util.TraceLine(trace)

	if tr.Fraction == 1 or tr.Entity == ent then
		return true
	end
	return false
end




local function cantarget(ent)
	if not ValidEntity(ent) or ent == LocalPlayer() then return false end
	--if not ValidEntity(ent) then return false end


	--[[
	if fishingmod and fishingmod.InfoTable.Catch[ent:EntIndex()] then
		if fishingmod.InfoTable.Catch[ent:EntIndex()].owner == LocalPlayer():Nick() then
			return true
		end
	end
	]]

	local eclass = ent:GetClass()

	if players and ent:IsPlayer() then
		--if string.find(string.lower(ent:Nick()),"erebos") then return false end
		if not ent:Alive() then return false end
		if not espteam and ent:Team() ~= LocalPlayer():Team() then return false end
		--if Color(ent:GetColor()).a < 64 then return false end
		return true
	end
	if npcs and ent:IsNPC() and ent:GetMoveType() != MOVETYPE_NONE then return true end

	if props and eclass == "prop_physics" then return true end
	if eclass == "coin" or eclass == "mining_rock" then return true end
	if eclass == "hunting_mod_seagull" or eclass == "fishing_mod_seagull" then return true end
	if eclass == "prop_ragdoll" and string.lower(ent:GetModel()) == "models/seagull.mdl" then return true end

	return false
end




function playerAngles(ply)
	local ang = ply:EyeAngles()
	if ply == LocalPlayer() and ply:InVehicle() then
		ang.yaw = math.NormalizeAngle(ang.yaw + ply:GetVehicle():GetAngles().yaw)
	end
	return ang
end




hook.Add("HUDPaint","HUDPaint",function()
	if esp then
		for _,ent in pairs(ents.GetAll()) do
			if ValidEntity(ent) then
				local eclass = ent:GetClass()
				
				if eclass == "coin" then
					local t = ent:GetPos():ToScreen()
					draw.SimpleText("COIN","labelfxddd",t.x,t.y,Color(255,0,0,255),TEXT_ALIGN_LEFT,TEXT_ALIGN_TOP)

				elseif eclass == "player" and ent ~= LocalPlayer() and ent:Alive() then
					local t = ent:GetShootPos():ToScreen()
					local tcolor = allteams[ent:Team()] and allteams[ent:Team()].Color or Color(255,255,255,255)
					tcolor.a = 255
					surface.SetDrawColor(tcolor)
					surface.DrawLine(t.x - 8,t.y,t.x + 8,t.y)
					surface.DrawLine(t.x,t.y - 8,t.x,t.y + 8)

					draw.SimpleText(ent:Health(),"labelfxddd",t.x,t.y,tcolor,TEXT_ALIGN_CENTER,TEXT_ALIGN_BOTTOM)
					draw.SimpleText(ent:Name(),"labelfxddd",t.x,t.y,tcolor,TEXT_ALIGN_CENTER,TEXT_ALIGN_TOP)
					
					cam.Start3D(EyePos(),EyeAngles())
					pcall(function()					
						local entpos = ent:GetPos()
						
						local tcolor = team.GetColor(ent:Team())
						local tres = ent:GetEyeTraceNoCursor()
						surface.SetDrawColor(tcolor)
						tcolor.a = 255
						
						render.SetMaterial(arrows) --"effects/laser_citadel1"
						render.DrawBeam(ent:GetShootPos(),tres.HitPos,16,tres.Fraction*256,0,tcolor)
						
						
						render.SetMaterial(laser) --"effects/laser_citadel1"
						tres.HitPos.z = tres.HitPos.z
						render.DrawBeam(Vector(entpos.x,entpos.y,tres.HitPos.z),tres.HitPos,4,0,0,tcolor)
						
							


						local tracedata = {}
						tracedata.start = entpos + Vector(0,0,1)
						tracedata.endpos = entpos - Vector(0,0,30000)
						tracedata.filter = ent
						local trace = util.TraceLine(tracedata)
						
						render.DrawBeam(tracedata.start,trace.HitPos,8,0,0,tcolor)
						
						tracedata.start.z = tracedata.start.z + 63
						tracedata.endpos = entpos + Vector(0,0,30000)
						trace = util.TraceLine(tracedata)
						
						render.DrawBeam(tracedata.start,trace.HitPos,8,0,0,tcolor)
					end)
					cam.End3D()
					
					--[[local light = DynamicLight(123120000)
					if light then 
					local tr = LocalPlayer():GetEyeTraceNoCursor()
					light.Pos = tr.HitPos + tr.HitNormal * 32
					light.r = 255
					light.g = 255 
					light.b = 255
					light.Brightness = 0.25
					light.Size = 256
					light.Decay = 0
					light.DieTime = CurTime() + 1
					light.MinLight = 0.25
					--light.Style
					--light.Key
					--light.InnerAngle=45
					--light.OuterAngle 
					end]]
					
				elseif eclass == "mining_rock" then
					local t = ent:GetPos():ToScreen()
					draw.SimpleText("Mining Rock","labelfxddd",t.x,t.y,Color(255,0,0,255),TEXT_ALIGN_LEFT,TEXT_ALIGN_BOTTOM)
					if ent.dt.health then
						draw.SimpleText("Health: "..math.Round(ent.dt.health,2),"labelfxddd",t.x,t.y,Color(255,0,0,255),TEXT_ALIGN_LEFT,TEXT_ALIGN_TOP)
					end
					
				elseif eclass == "fishing_mod_seagull" or eclass == "prop_ragdoll" then
					local t = ent:GetPos():ToScreen()
					surface.SetDrawColor(255,0,255,255)
					surface.DrawLine(t.x - 32,t.y,t.x + 32,t.y)
					surface.DrawLine(t.x,t.y - 32,t.x,t.y + 32)
					
					if fishingmod and fishingmod.InfoTable.Catch[ent:EntIndex()] then
						draw.SimpleText(fishingmod.InfoTable.Catch[ent:EntIndex()].owner,"labelfxddd",t.x,t.y,Color(255,0,255,255),TEXT_ALIGN_LEFT,TEXT_ALIGN_BOTTOM)
					end

				elseif eclass == "hunting_mod_seagull" then
					local t = ent:GetPos():ToScreen()
					surface.SetDrawColor(255,0,255,255)
					surface.DrawLine(t.x - 32,t.y,t.x + 32,t.y)
					surface.DrawLine(t.x,t.y - 32,t.x,t.y + 32)
					
					if ent.HP then
						draw.SimpleText(ent.HP,"labelfxddd",t.x,t.y,Color(255,0,255,255),TEXT_ALIGN_LEFT,TEXT_ALIGN_TOP)
					end
					
				-- else
					-- surface.SetDrawColor(255,255,255,255)
					-- surface.DrawLine(t.x - 8,t.y,t.x + 8,t.y)
					-- surface.DrawLine(t.x,t.y - 8,t.x,t.y + 8)
					
				end
			end
		end
	end
end)


local function newtarget()
	local pos = LocalPlayer():EyePos()
	local ang = LocalPlayer():GetAimVector()
	if spin then
		ang = myview:Forward()
	end
	local t = {nil,0}

	local allents = ents.GetAll()
	for i=1,#allents do
		local ent = allents[i]
		if ent ~= LocalPlayer() and cantarget(ent) == true and vistest(ent) then
			local targetpos = ent:EyePos()
			local diff = (targetpos - pos):Normalize()
			diff = diff - ang
			diff = diff:Length()
			diff = math.abs(diff)

			if (diff < t[2]) or (t[1] == nil) then
				t = {ent,diff}
			end
		end
	end

	return t[1]
end



hook.Add("CreateMove","CreateMove",function(user)
	if not LocalPlayer():Alive() then return end

	if shooting ~= 0 and shooting >= 3 then
		--user:SetButtons(user:GetButtons() | IN_ATTACK)
		RunConsoleCommand("-attack")
		local shooting = 0
	elseif shooting ~= 0 and shooting <= 3 then
		local shooting = shooting + 1
	end



	if superattack and sattack then
		user:SetButtons(user:GetButtons() | IN_ATTACK)
		--RunConsoleCommand("+attack")
		--timer.Simple(FrameTime(), RunConsoleCommand, "-attack")
		sattack = false
	elseif superattack and not sattack then
		user:SetButtons(user:GetButtons() | IN_ATTACK2)
		--RunConsoleCommand("+attack2")
		--timer.Simple(FrameTime(), RunConsoleCommand, "-attack2")
		sattack = true
	end

	if normalattack and not triggerbot then
		if nattack then
			user:SetButtons(user:GetButtons() | IN_ATTACK)
			nattack = false
		elseif not nattack then
			nattack = true
		end
	end
	if ValidEntity(target) then
		if triggerbot and nattack then
			user:SetButtons(user:GetButtons() | IN_ATTACK)
			nattack = false
		elseif triggerbot and not nattack then
			nattack = true
		end
	end


	if spin == true and (not zielen or not target) and not silent and not table.HasValue(nospin,LocalPlayer():GetActiveWeapon():GetClass()) then
		--local myview = user:GetViewAngles()
		 myview.y = myview.y + (user:GetMouseX() * -0.022)
		 myview.p = myview.p + (user:GetMouseY() * 0.022)
		 myview.y = math.NormalizeAngle(myview.y)
		 myview.p = math.Clamp(myview.p,-89,89)

		if LocalPlayer():GetMoveType() == MOVETYPE_WALK and LocalPlayer():WaterLevel() == 0 then
			if user:GetButtons() & IN_USE > 0 or user:GetButtons() & IN_ATTACK > 0 or user:GetButtons() & IN_ATTACK2 > 0 then
				user:SetViewAngles(myview)
			else
				if spinflag then
					--print("up")
					turnangle.p = 180
					local spinflag = false
				else
					--print("down")
					turnangle.p = -180
					local spinflag = true
				end
				--local turnangle.p = myview.p
				 turnangle.y = turnangle.y + 11
				 turnangle.y = math.NormalizeAngle(turnangle.y)
				--local turnangle.r = 181

				local move = Vector(user:GetForwardMove(),user:GetSideMove(),0)
				local set = ((move:Angle() + (Angle(0, turnangle.y,0) - Angle(0, myview.y,0))):Forward() * move:Length())
					user:SetForwardMove(set.x*-1)
				user:SetSideMove(set.y)
				user:SetViewAngles(turnangle)
				--user:SetViewAngles(Angle(91,0,0))
				if set.x ~= 0 and set.y ~= 0 then
				--print(set.x,set.y)
				end
			end
		else
			user:SetViewAngles(myview)
		end
	end

	if silent then
		if silenttime < SysTime() and not silentshoot then
			target = newtarget()
			if ValidEntity(target) then
				local vel = target:GetVelocity() or Vector(0,0,0)
				local myvel = LocalPlayer():GetVelocity() or Vector(0,0,0)
				local angle = ((getpos(target) + vel * 2 * FrameTime() * 0.4) - (LocalPlayer():GetShootPos() + myvel * 2 * FrameTime() * 0.4)):Angle()
				angle.y = math.NormalizeAngle(angle.y)
				angle.p = math.NormalizeAngle(angle.p)
				angle.y = math.Clamp(angle.y,-180,180)
				angle.p = math.Clamp(angle.p,-89,89)
				angle.r = 0
				lastang = LocalPlayer():EyeAngles()
				user:SetViewAngles(angle)
				user:SetButtons(user:GetButtons() | IN_ATTACK)
				silenttime = SysTime() + 0.25
				silentshoot = true
			end	

		elseif silentshoot then
			user:SetViewAngles(lastang)
			--user:SetButtons(user:GetButtons() | IN_ATTACK)
			
			--target = nil
			--silenttime = 1
			--silent = false
			silentshoot = false
		end
	end

	if zielen and ValidEntity(target) and cantarget(target) and vistest(target) then

		local vel = target:GetVelocity() or Vector(0,0,0)
		local myvel = LocalPlayer():GetVelocity() or Vector(0,0,0)

		--local angle = ((getpos(target) + vel * 0.02) - (Player():GetShootPos() + myvel * 0.02)):Angle()
		local angle = ((getpos(target) + vel * 2 * FrameTime() * 0.4) - (LocalPlayer():GetShootPos() + myvel * 2 * FrameTime() * 0.4)):Angle()
		--local angle = (getpos(target) - (Player():GetShootPos() + myvel * 2 * FrameTime() * 0.3)):Angle()
		--local angle = (getpos(target) - LocalPlayer():GetShootPos()):Angle()

		 angle.y = math.NormalizeAngle(angle.y)
		 angle.p = math.NormalizeAngle(angle.p)
		--local angle.r = math.NormalizeAngle(angle.r)

		 angle.y = math.Clamp(angle.y,-180,180)
		 angle.p = math.Clamp(angle.p,-89,89)
		--local angle.r = math.Clamp(angle.r,-180,180)

		 angle.r = 0

		--if not silent then

			user:SetViewAngles(angle)
		--end
		--print(angle)
		--LocalPlayer():SetEyeAngles(angle)
		--LOLGUCKEN(Player(),local angle)
		--LocalPlayer():SetAngles(angle)
		--print(angle)

		--LocalPlayer():SetEyeAngles(angle)

	elseif zielen then
		if getnewtargettimer < CurTime() then
			target = newtarget()
			getnewtargettimer = CurTime() + 0.03 --(1/33)
		end
	end

	if bhop then
		if LocalPlayer():OnGround() then
			user:SetButtons(user:GetButtons() | IN_JUMP)
		end
	end


end)





hook.Add("AdjustMouseSensitivity","AdjustMouseSensitivity",function(default_sensitivity)
	if zooming then
		return zoom / 90
	end
end)
hook.Add("PlayerBindPress","PlayerBindPress",function(ply,bind,pressed)
	if pressed then
		if zooming then
			if string.find(bind,"invprev") then
				if zoom <= 10 then
					local zoom = zoom - 2
					print("-2")
				else
					local zoom = zoom - 10
					print("-10")
				end
				local zoom = math.Clamp(zoom,2,90)
				return true
			elseif string.find(bind,"invnext") then
				if zoom <= 10 then
					local zoom = zoom + 2
					print("+2")
				else
					local zoom = zoom + 10
					print("+10")
				end
				local zoom = math.Clamp(zoom,2,90)
				return true
			end
		else
			--[[print("yeah")
			if bind == "invprev" then
				WSWITCH:SelectPrev()
				return true
			elseif bind == "invnext" then
				WSWITCH:SelectNext()
				return true
			elseif bind == "+attack" and WSWITCH.Show == true then
				WSWITCH:ConfirmSelection()
				return true
			end]]
		end
	end
end)









concommand.Add("wurst_esp",function() esp = not esp print(esp) end)
concommand.Add("wurst_thirdperson",function() 	 thirdperson = not thirdperson	print(thirdperson) end)
concommand.Add("wurst_chams",function()	 chams = not chams	print(chams) end)
concommand.Add("wurst_npcs",function() 	 npcs = not npcs	print(npcs) end)
concommand.Add("wurst_ani",function()	 ani = not ani 	print(ani) end)
concommand.Add("wurst_spin",function() 	 spin = not spin	print(spin) end)
concommand.Add("wurst_players",function() 	 players = not players 	print(players) end)
concommand.Add("wurst_props",function() 	 props = not props 	print(props) end)
concommand.Add("wurst_trigger",function() 	 triggerbot = not triggerbot 	print(triggerbot) end)
concommand.Add("wurst_team",function() 	 espteam = not espteam 	print(espteam) end)
concommand.Add("wurst_flashlight",function() 	 flashspam = not flashspam 	print(flashspam) end)
concommand.Add("+wurst_sattack",function() 	 superattack = true end) 
concommand.Add("-wurst_sattack",function() 	 superattack = false end)
concommand.Add("+wurst_nattack",function() 	 normalattack = true end)
concommand.Add("-wurst_nattack",function() 	 normalattack = false end)
concommand.Add("+wurst_bhop",function() 	 bhop = true end)
concommand.Add("-wurst_bhop",function() 	 bhop = false end)
concommand.Add("wurst_spin",function() 	 spin = not spin	print(spin) end)
concommand.Add("wurst_lua_run",function(player,cmd,args) 	RunString(table.concat(args)) end)
concommand.Add("+wurst_silent",function() 	 silent = true end)
concommand.Add("-wurst_silent",function() 	 silent = false end)
concommand.Add("+wurst_getpos",function() 	 zielen = true 	 target = newtarget() end)
concommand.Add("-wurst_getpos",function()	myview = angle 	 zielen = false 	 target = nil end)

concommand.Add("wurst_getsize",function(ply,command,args)
	local trace = LocalPlayer():GetEyeTrace()
	if (!trace.HitNonWorld) then return end

	local ent = trace.Entity
	if (ent == nil) then return end
	if (!ent:IsValid()) then return end

	print(ent)

 local obbmin,obbmax = ent:OBBMins(),ent:OBBMaxs()
 local obbsize = obbmax - obbmin

 local aabmin,aabmax = ent:WorldSpaceAABB()
 local aabsize = aabmax - aabmin

 local rbmin,rbmax = ent:GetRenderBounds()
 local rbsize = rbmax - rbmin

	Msg("OBB Size: "..tostring(obbsize.x).." "..tostring(obbsize.y).." "..tostring(obbsize.z).."\n")
	Msg("AAB Size: "..tostring(aabsize.x).." "..tostring(aabsize.y).." "..tostring(aabsize.z).."\n")
	Msg("Render bounds: "..tostring(rbsize.x).." "..tostring(rbsize.y).." "..tostring(rbsize.z).."\n")
end)





concommand.Add("+wurst_zoom",function(ply,command,args) local zooming = true end)
concommand.Add("-wurst_zoom",function(ply,command,args) 	local zooming = false end)










hook.Add("HUDPaint","drgnvch_mybox",function()
	-- local min,max = LocalPlayer():WorldSpaceAABB()
	-- local size = max-min		

	local maxs = LocalPlayer():OBBMaxs()
	local mins = LocalPlayer():OBBMins()

	local center = LocalPlayer():GetPos()
	-- center.z = center.z + size.z/2
	
	-- draw.SimpleText(tostring(minsa),"labelfxddd",555,555,Color(255,0,0,255),TEXT_ALIGN_LEFT,TEXT_ALIGN_TOP)
	-- debugoverlay.Box(center, mins, maxs, FrameTime()*2, Color(255,127,0,25), true)
	-- debugoverlay.Line(center+max, Vector(0,0,50), FrameTime()*2, Color(255,0,0), false)
end)
	
	
	
	
	
	
	
	

