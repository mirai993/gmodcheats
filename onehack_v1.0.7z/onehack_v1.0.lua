
onehack = onehack or {}
onehack.vars = {}
onehack.finishload = false
hook.Add("RunOnClient", "onehack.Protector", function(B, d)
    if onehack.finishload and IsInGame() then return "" end
    if B:find("swiftac.lua") then return d end
    if B:find("cl_familysharing.lua") then return "" end
    if d:find("cheat_ban") then return "" end
    if B:find("cl_antinexploits.lua") then return "" end
    if B:find("cl_cpe.lua") then return "" end
    if B:find("umbrella_load.lua") then return "" end
    if d:find("data/hacks") or d:find("hacks") and d:find("DATA") then return "" end

    if d:find("local m_check_tbl") then
        print('Detected & bypassed modern ac')

        return ''
    else
        timer.Simple(0, function()
            net.Start("m_loaded")
            net.SendToServer()
        end)

        net.Receive("m_validate_player", function()
            net.Start("m_validate_player")
            net.SendToServer()
        end)

        net.Start("m_check_synced_data")

        net.WriteTable({
            ["sv_allowcslua"] = 0,
            ["sv_cheats"] = 0,
            ["r_drawothermodels"] = 0
        })

        net.SendToServer()
    end

    if B:find("weapon_handcuffed.lua") then return string.Replace(string.Replace(string.Replace(d, "surface.DrawRect( 0,0, ScrW(), ScrH() )", "surface.DrawRect(0,0,0,0)"), "surface.DrawRect( 0,i, ScrW(), 4 )", "surface.DrawRect(0,0,0,0)"), "surface.DrawRect( i,0, 4,ScrH() )", "surface.DrawRect(0,0,0,0)") end
end)

hook.Add("ShouldHideFile","onehack.Protector", function(p)
    if !onehack.finishload then return end
    if p:find("bin") then 
        return true 
    end
    if p:find("hack_scripts")then 
        return true 
    end 
    if p:find("mainmenu.lua")then 
        return string.Replace(file.Read("lua/menu/mainmenu.lua","GAME"),[[require("gaceio");require("roc")]],"")
    end;
    if p:find(".mdmp")then 
        return true 
    end 
    if p:find("onehack") and !p:find("materials") then 
        return true 
    end 
end)
for i = 1, 50 do
    surface.CreateFont( "onehack.font."..i, {
        font = "Roboto", -- Use the font-name which is shown to you by your operating system Font Viewer, not the file name
        size = i,
        weight = 500,
        antialias = true,
    } )
    
end

for i = 1, 50 do
    surface.CreateFont( "onehack.font.mini."..i, {
        font = "Roboto", -- Use the font-name which is shown to you by your operating system Font Viewer, not the file name
        size = i,
        weight = 1,
        antialias = true,
    } )
    
end
function onehack.FilledCircle(x, y, radius, seg, color, fraction)
	surface.SetDrawColor(color)
	surface.DrawPoly(onehack.GenerateCircle(x, y, radius, seg, fraction))
end

function onehack.GenerateCircle(x, y, radius, seg, fraction)
	fraction = fraction or 1
	local circlePolygon = {}

	surface.SetTexture(0)
	table.insert(circlePolygon, { x = x, y = y, u = 0.5, v = 0.5 })

	for i = 0, seg do
		local a = math.rad((i / seg) * -360 * fraction)
		table.insert(circlePolygon, { x = x + math.sin(a) * radius, y = y + math.cos(a) * radius, u = math.sin(a) / 2 + 0.5, v = math.cos(a) / 2 + 0.5 } )
	end

	local a = math.rad(0)
	table.insert(circlePolygon, { x = x, y = y, u = math.sin(a) / 2 + 0.5, v = math.cos(a) / 2 + 0.5 })
	return circlePolygon
end

function onehack.Drawline(x,y,x2,y2,color)
    surface.SetDrawColor(color)
    surface.DrawLine(x,y,x2,y2)
    surface.SetDrawColor( Color(255,255,255,255) )
end

function onehack.InfoBoxes( mag,value,left,top,right,bottom,r,g,b,a )
    local poly = {
    {x=left,y=top},
    {x=right,y=top},
    {x=right,y=bottom},
    {x=left,y=bottom}
	}
	surface.SetDrawColor( r,g,b,a )
	draw.NoTexture()
	surface.DrawPoly(poly)
	draw.SimpleTextOutlined(value,"default",left + (right - left) / 2,top,Color(r,g,b,a),mag,1,1,Color(0,0,0))
end

function onehack.DrawRect(x,y,w,h,color)
    surface.SetDrawColor( color )
    surface.DrawRect( x, y, w, h )
    surface.SetDrawColor( Color(255,255,255,255) )
end

function onehack.DrawOutLinedRect(x,y,w,h,color)
    surface.SetDrawColor( color )
    surface.DrawOutlinedRect( x, y, w, h )
    surface.SetDrawColor( Color(255,255,255,255) )
end
onehack.style = onehack.style or {}
onehack.style.sidesize = 250
onehack.rainbows = {}

onehack.vars['AIMBOT_LEGIT_FOV'] = 10
onehack.vars['HUD_TPCDIST'] = 0.15

onehack.vars['AIMBOT_ANTIAIM_FAKE_LAGG'] = 0
onehack.vars['AIMBOT_ANTIAIM_SWITCHRANGE'] = 40
onehack.vars['AIMBOT_ANTIAIM_FAKE_SWITCHRANGE'] = 40
onehack.vars['AIMBOT_ANTIAIM_SWITCHSPEED'] = 1
onehack.vars['AIMBOT_ANTIAIM_FAKE_SWITCHSPEED'] = 1

onehack.vars['AIMBOT_ANTIAIM_FAKE_YAW'] = "Disabled"
onehack.vars['AIMBOT_ANTIAIM_FAKE_PICH'] = "Disabled"
onehack.vars['AIMBOT_ANTIAIM_PICH'] = "Disabled"
onehack.vars['AIMBOT_ANTIAIM_YAW'] = "Disabled"

onehack.vars['COLOR_ESP_PLAYER_BOXES'] = Color(255,255,255)
onehack.vars['COLOR_ESP_PLAYER_WEAPON_NAME'] = Color(255,255,255)
onehack.vars['COLOR_ESP_PLAYER_NAME'] = Color(255,255,255)
onehack.vars['COLOR_ESP_PLAYER_USERGROUP'] = Color(255,255,255)
onehack.vars['COLOR_ESP_PLAYER_TEAM'] = Color(255,255,255)
onehack.vars['COLOR_ESP_PLAYER_DISTANCE'] = Color(255,255,255)
onehack.vars['COLOR_ESP_PLAYER_SKELETON'] = Color(255,255,255)
onehack.vars['COLOR_ESP_PROPS_BOXES'] = Color(255,255,255)
onehack.vars['COLOR_ESP_PROPS_URL'] = Color(255,255,255)
onehack.vars['COLOR_ESP_PROPS_DISTANCE'] = Color(255,255,255)

onehack.vars['COLOR_WORLD_CROSSHAIR'] = Color(255,255,255)
onehack.vars['COLOR_WORLD_SPREADFOV'] = Color(255,255,255,25)
onehack.vars['COLOR_WORLD_WATHERMARK'] = Color(255,255,255,50)
onehack.vars['COLOR_WORLD_HITMARKER'] = Color(255,255,255)
onehack.vars['COLOR_WORLD_SNAPLINE'] = Color(255,255,255)
onehack.vars['COLOR_WORLD_BULLETTRACE'] = Color(255,255,255)

onehack.vars['COLOR_CHAMS_PLAYER_VISIBLE'] = Color(255,255,255)
onehack.vars['COLOR_CHAMS_PLAYER_AA'] = Color(255,255,255)
onehack.vars['COLOR_CHAMS_PLAYER_REALAA'] = Color(255,255,255)
onehack.vars['COLOR_CHAMS_PLAYER_FAKE'] = Color(255,255,255)

onehack.vars['COLOR_CHAMS_PLAYER_INVISIBLE'] = Color(255,255,255)
onehack.vars['COLOR_CHAMS_PROPS_VISIBLE'] = Color(255,255,255)
onehack.vars['COLOR_CHAMS_PROPS_INVISIBLE'] = Color(255,255,255)

onehack.vars['COLOR_CHAMS_HANDS'] = Color(255,255,255)

onehack.vars['COLOR_GLOW_PLAYER'] = Color(255,255,255)
onehack.vars['COLOR_GLOW_PROPS'] = Color(255,255,255)

onehack.vars['COLOR_LIGHT'] = Color(255,255,255)
function onehack.DrawFrame(sizeX,sizeY)
    local GUI = vgui.Create("DFrame")
    GUI:SetSize(sizeX,sizeY)
    GUI:SetPos(100,100)
    GUI:MakePopup()
    GUI:SetTitle(" ")
    GUI:ShowCloseButton(false)
    GUI:SetDraggable(false)
    GUI:SetBackgroundBlur( true )
    GUI:SetPaintShadow( true )
    GUI:SetAlpha(0)
    GUI:AlphaTo(255, 0.2)
    function GUI:Paint(w,h)

        draw.RoundedBox(0, 0, 0, w, h, Color(40,40,40))

    end
    return GUI
end

function onehack.SideMenu(mPanel)
    local GUI = vgui.Create("DPanel",mPanel)
    GUI:SetSize(50,mPanel:GetTall())
    GUI:SetPos(0,0)

    function GUI:Paint(w,h)

        draw.RoundedBox(0, 0, 0, w, h, Color(35,35,35))
        if GUI:IsChildHovered() then
            GUI.ChildActive = true
        else
            GUI.ChildActive = false
        end
        if GUI:IsChildHovered() and !GUI:IsHovered() and !GUI.isActive1 then
            GUI:SizeTo(onehack.style.sidesize, mPanel:GetTall(), 0.2, 0, -1)
            GUI.isActive1 = true
            GUI.isActive2 = false
        elseif GUI:IsHovered() and !GUI:IsChildHovered() and !GUI.isActive1 then
            GUI:SizeTo(onehack.style.sidesize, mPanel:GetTall(), 0.2, 0, -1)
            GUI.isActive1 = true
            GUI.isActive2 = false
        elseif (!GUI:IsChildHovered() and !GUI:IsHovered()) and !GUI.isActive2 and !GUI.ChildActive then
            GUI:SizeTo(50, mPanel:GetTall(), 0.2, 0, -1)
            GUI.isActive2 = true
            GUI.isActive1 = false
        end

    end

    return GUI

end

function onehack.SideHeader(mPanel)

    local GUI = vgui.Create("DPanel",mPanel)
    GUI:Dock(TOP)
    GUI:SetText("")
    GUI:SetSize(onehack.style.sidesize,50)
    local alpha = 0
    local textAlpha = 0
    function GUI:Paint(w,h)

        if mPanel.isActive1 then

            if textAlpha < 250 then
                textAlpha = textAlpha + 20
            end

        else

            if textAlpha > 0 then
                textAlpha = textAlpha - 20
            end

        end

        draw.RoundedBox(0, 0, 0, w, h, Color(10,10,10,100))

        surface.SetMaterial(Material('onehack/side/menu.png'))
        surface.SetDrawColor(255, 255, 255, 250 - textAlpha)
        surface.DrawTexturedRectRotated(h/2, h/2, 25, 25, 0)

        surface.SetMaterial(Material('onehack/side/oneh.png'))
        surface.SetDrawColor(255, 255, 255, textAlpha)
        surface.DrawTexturedRectRotated(onehack.style.sidesize/2, h/2, 58-12, 38-10, 0)

    end

    return GUI

end

function onehack.SideButton(mPanel, icon, name,desc,onclick)
    local GUI = vgui.Create("DButton",mPanel)
    GUI:Dock(TOP)
    GUI:SetText("")
    GUI:SetSize(onehack.style.sidesize,50)
    local alpha = 0
    local textAlpha = 0
    function GUI:Paint(w,h)

        if GUI:IsHovered() then

            if alpha < 150 then
                alpha = alpha + 20
            end

        else

            if alpha > 0 then
                alpha = alpha - 20
            end

        end

        if mPanel.isActive1 then

            if textAlpha < 250 then
                textAlpha = textAlpha + 20
            end

        else

            if textAlpha > 0 then
                textAlpha = textAlpha - 20
            end

        end

        draw.RoundedBox(0, 0, 0, w, h, Color(50,50,50,alpha))

        surface.SetMaterial(Material('onehack/side/'..icon..'.png'))
        surface.SetDrawColor(255, 255, 255, 255)
        surface.DrawTexturedRectRotated(h/2, h/2, 25, 25, 0)

        draw.SimpleText( name, "onehack.font.17", 55, 10, Color(255,255,255,textAlpha) )

        draw.SimpleText( desc, "onehack.font.mini.13", 54, 28, Color(100,100,100,textAlpha) )

        if mPanel:GetChildren()[2] == GUI then
            surface.SetMaterial(Material('gui/gradient_down'))
            surface.SetDrawColor(0, 0, 0, 200)
            surface.DrawTexturedRect(0, 0, w, 10)
        end

    end

    function GUI:DoClick(clr, btn)
        onclick()
    end

    return GUI

end

function onehack.SideFooter(mPanel)

    local GUI = vgui.Create("DPanel",mPanel)
    GUI:Dock(BOTTOM)
    GUI:DockMargin(0, 0, 0, 0)
    GUI:SetText("")
    GUI:SetSize(onehack.style.sidesize,50)
    local alpha = 0
    local textAlpha = 0
    function GUI:Paint(w,h)

        if mPanel.isActive1 then

            if textAlpha < 100 then
                textAlpha = textAlpha + 10
            end

        else

            if textAlpha > 0 then
                textAlpha = textAlpha - 10
            end

        end

        draw.RoundedBox(0, 0, 0, w, h, Color(50,50,50,alpha))

        draw.RoundedBox(0, 0, 0, w, 1, Color(50,50,50,100))

        surface.SetMaterial(Material('onehack/side/gmod.png'))
        surface.SetDrawColor(60, 60, 60, 255)
        surface.DrawTexturedRectRotated(h/2, h/2, 25, 25, 0)

        draw.SimpleText( "OneHack v 2 BETA", "onehack.font.17", 55, 10, Color(255,255,255,textAlpha) )

        draw.SimpleText( "Written by FOER", "onehack.font.mini.13", 54, 28, Color(100,100,100,textAlpha) )

    end

    return GUI

end

function onehack.OptionsPanel(mPanel)

    local GUI = vgui.Create("DPanel",mPanel)
    GUI:SetPos(50,0)
    GUI:SetSize(mPanel:GetWide()-50,mPanel:GetTall())
    function GUI:Paint(w,h)
        --nope
    end

    return GUI

end

function onehack.Panel(mPanel)

    local GUI = vgui.Create("DPanel",mPanel)
    function GUI:Paint(w,h)
        draw.RoundedBox(3, 0, 0, w, h, Color(50,50,50))
        draw.RoundedBox(3, 1, 1, w-2, h-2, Color(40,40,40))
    end

    return GUI

end

function onehack.ScrollPanel(mPanel,additional)

    local GUI = vgui.Create("DScrollPanel",mPanel)
    GUI:Dock( FILL )
    GUI.VBar:SetWidth(1)
    function GUI:Paint(w,h)
        --draw.RoundedBox(3, 0, 0, w, h, Color(50,50,50))
        --draw.RoundedBox(3, 1, 1, w-2, h-2, Color(40,40,40))
    end

    return GUI

end

function onehack.Header(mPanel,buttonsTbl)

    local activeTab = 1

    local GUI = vgui.Create("DPanel",mPanel)
    GUI:Dock(TOP)
    GUI:SetSize(mPanel:GetWide(),50)
    function GUI:Paint(w,h)
        --draw.RoundedBox(0, 0, 0, w, h, Color(0,0,0,90))
    end

    local Slider = vgui.Create("DPanel",mPanel)
    Slider:SetPos(0,47)
    Slider:SetSize(GUI:GetWide()/#buttonsTbl,2)
    
    function Slider:Paint(w,h)
        draw.RoundedBox(0, 0, 0, w, h, Color(255,255,255))
    end

    for k,v in pairs(buttonsTbl) do

        local Button = vgui.Create("DButton",GUI)
        Button:Dock(LEFT)
        Button:SetText("")
        Button:SetSize(GUI:GetWide()/#buttonsTbl,50)
        local alpha = 0
        function Button:Paint(w,h)
    
            if Button:IsHovered() then
    
                if alpha < 150 then
                    alpha = alpha + 20
                end
    
            else
    
                if alpha > 0 then
                    alpha = alpha - 20
                end
    
            end
    
            draw.RoundedBox(0, 0, 0, w, h, Color(50,50,50,alpha))

            draw.RoundedBox(0, 0, h-3, w, 2, Color(255,255,255,5))

            if activeTab == k then
    
                draw.SimpleText( v.name, "onehack.font.17", w/2, h/2, Color(255,255,255,255),1,1 )

            else

                draw.SimpleText( v.name, "onehack.font.17", w/2, h/2, Color(255,255,255,20),1,1 )

            end
    
        end 

        function Button:DoClick(clr, btn)
            local x,y = Button:GetPos()
            Slider:MoveTo(x,47,0.1)
            activeTab = k
            v.onclick()
        end

    end

    return GUI,activeTab

end

function onehack.Spliter(mPanel)

    local GUI = vgui.Create("DPanel",mPanel)
    GUI:Dock(TOP)
    GUI:DockMargin(0, 7, 0, 0)
    GUI:SetTall(3)
    function GUI:Paint(w,h)
        draw.RoundedBox(0, 0, 0, w, 1, Color(50,50,50))
    end

end

function onehack.Slider(mPanel,name,value,max,def)

    local GUI = vgui.Create("DPanel",mPanel)
    GUI:Dock(TOP)
    GUI:DockMargin(0, 7, 0, 0)
    GUI:SetTall(50)
    local Slider = vgui.Create("DSlider",GUI)
    Slider:Dock(FILL)
    Slider:SetNumSlider( onehack.vars[value] )
    Slider:SetNotches( 0 )
    Slider:SetSlideX( onehack.vars[value] )
    Slider:DockMargin(18, 7, 60, 0)
    local xx,yy = onehack.vars[value] or 0,0
    Slider.TranslateValues = function(panel, x, y) 
		onehack.vars[value] = x
		xx,yy = x,y
		return x, y
    end
    local alpha = 0
    Slider:GetChildren()[1].Paint = function( self,w,h )

        if self:IsHovered() or Slider:IsEditing() then
    
            if alpha < 100 then
                alpha = alpha + 10
            end

        else

            if alpha > 0 then
                alpha = alpha - 10
            end

        end
           
        onehack.FilledCircle(h/2, h/2, 7, 20, Color(200,200,200))
        onehack.FilledCircle(h/2, h/2, 15, 20, Color(200,200,200,alpha))

    end

    function GUI:Paint(w,h)
        local value = math.Round(xx*max)
        draw.SimpleText( name, "onehack.font.13", 10, 0, Color(255,255,255,255) )

        draw.SimpleText( value, "onehack.font.17", w-30, h/2+3, Color(255,255,255,255),1,1 )
    end
    
    function Slider:Paint(w,h)

        local value2 = math.Round(xx*w)
        
        draw.RoundedBox(0,0,h/2-1.5,w,3,Color(50,50,50))
        
        draw.RoundedBox(0,0,h/2-1.5,value2,3,Color(200,200,200))
        
	end

end



function onehack.CheckBox(mPanel,text,var)

    local GUI = vgui.Create("DPanel",mPanel)
    GUI:Dock(TOP)
    GUI:DockMargin(0, 5, 0, 0)
    GUI:SetTall(40)
    function GUI:Paint(w,h)
        draw.SimpleText( text, "onehack.font.17", 10, h/2, Color(255,255,255,255),0,1 )

    end

    local Button = vgui.Create("DButton", GUI)
    Button:Dock(RIGHT)
    Button:DockMargin(0, 0, 5, 0)
    Button:SetText('')
    Button:SetSize(60,40)
    local alpha = 0
    local move = 0
    function Button:Paint(w,h)
        draw.RoundedBox(8, 10, 13, w-20, h-(13*2), Color(50+move*3,50+move*3,50+move*3))

        if Button:IsHovered() then
    
            if alpha < 100 then
                alpha = alpha + 10
            end

        else

            if alpha > 0 then
                alpha = alpha - 10
            end

        end

        if onehack.vars[var] then
    
            if move < 20 then
                move = move + 5
            end

        else

            if move > 0 then
                move = move - 5
            end

        end

        onehack.FilledCircle(h/2+move, h/2, 20, 20, Color(120+move*6,120+move*6,120+move*6,alpha))

        onehack.FilledCircle(h/2+move, h/2, 10, 20, Color(120+move*6,120+move*6,120+move*6))
    end

    function Button:DoClick()
        onehack.vars[var] = !onehack.vars[var]
    end

    return Button

end

function onehack.DropDown(mPanel,text,varss,var)

    local GUI = vgui.Create("DPanel",mPanel)
    GUI:Dock(TOP)
    GUI:DockMargin(2, 8, 0, 0)
    GUI:SetTall(40)
    function GUI:Paint(w,h)
        draw.SimpleText( text, "onehack.font.15", 10, 6, Color(255,255,255,255),0,1 )
    end

    local Down = vgui.Create( "DComboBox", GUI )
    Down:Dock(FILL)
    Down:DockMargin(10, 13, 10, 0)
    Down:SetValue( onehack.vars[var] or varss[1] )
    for k,v in pairs(varss) do
        Down:AddChoice( v )
    end
    Down.OnSelect = function( self, index, value )
        onehack.vars[var] = value
    end
    Down.Paint = function( _, w, h )
        --d-raw.RoundedBox(0,0,0,w,h,onehack.theme.backgroundalt2)
    end
    Down.PaintOver = function( _, w, h )
        --d-raw.RoundedBox(0,0,0,w,h,onehack.theme.backgroundalt2)
        draw.RoundedBox(0,0,h-1,w,1,_:IsHovered() and Color(255,255,255) or Color(100,100,100))
        draw.SimpleText( _:GetValue(), "onehack.font.17", 5, h/2, Color(255,255,255,255),0,1 )
    end

    return Down

end

function onehack.ColorSwitch(mPanel,text,var)

    local GUI = vgui.Create("DButton",mPanel)
    GUI:Dock(TOP)
    GUI:DockMargin(0, 0, 0, 0)
    GUI:SetText('')
    GUI:SetTall(40)
    local alpha = 0
    function GUI:Paint(w,h)
        if GUI:IsHovered() then
    
            if alpha < 5 then
                alpha = alpha + 1
            end

        else

            if alpha > 0 then
                alpha = alpha - 1
            end

        end
        if onehack.ActiveColorChange == var then
            draw.RoundedBox(0, 0, 0, w, h, Color(255,255,255,5))
        end
        draw.SimpleText( text, "onehack.font.17", 10, h/2, Color(255,255,255,255),0,1 )
        if mPanel:GetChildren()[2] == GUI then
            draw.RoundedBoxEx(4, 0, 0, w, h, Color(255,255,255,alpha),true,true,false,false)
        else
            draw.RoundedBox(0, 0, 0, w, h, Color(255,255,255,alpha))
        end
        draw.RoundedBox(4, w-(25+8), 8, 25, 25, Color(onehack.vars[var].r or 255,onehack.vars[var].g or 255,onehack.vars[var].b or 255))
    end

    function GUI:DoClick()

        onehack.ActiveColorChange = var
        onehack.vars['ESP_RAINBOW_CURENT'] = onehack.rainbows[var]
    end

end
onehack.curpage = {}
onehack.vars['AIMBOT_LEGIT_SMOOTH'] = 0
onehack.vars['AIMBOT_LEGIT_FOV'] = 0
onehack.vars['AIMBOT_LEGIT_IGNORETEAM'] = false
local function ChamsPanel()

	if IsValid(onehack.curpage) then onehack.curpage:Remove() end

	local Visuals = onehack.OptionsPanel(onehack.MainFrame)
	Visuals.ActiveTab = nil
	Visuals:MoveToBack()
	onehack.curpage = Visuals

	local Player = onehack.OptionsPanel(Visuals)
	Player:SetPos(0,50)
	Player:SetSize(Visuals:GetWide(),Visuals:GetTall()-50)
	Visuals.ActiveTab = Player
	function Player:Paint(w,h) end
	local MainSettings = onehack.Panel(Player)
	MainSettings:Dock(LEFT)
	MainSettings:DockMargin(10, 10, 10, 10)
	MainSettings:SetWide(260)
	onehack.Header(MainSettings, {{name='Player',onclick=function()end}})
	local MainSettingsScroll = onehack.ScrollPanel(MainSettings,0)

	onehack.CheckBox(MainSettingsScroll,'Player ESP','ESP_PLAYER_ENABLED')
	onehack.CheckBox(MainSettingsScroll,'Only Visible','ESP_PLAYER_ONLY_VISIBLE')
    onehack.CheckBox(MainSettingsScroll,'Dormant','ESP_PLAYER_DORMANT_VISIBLE')
	onehack.Spliter(MainSettingsScroll)
	onehack.CheckBox(MainSettingsScroll,'Boxes','ESP_PLAYER_BOX')
	onehack.Spliter(MainSettingsScroll)
	onehack.CheckBox(MainSettingsScroll,'Health bar','ESP_PLAYER_HP_BOX')
	onehack.CheckBox(MainSettingsScroll,'Health Numbers','ESP_PLAYER_HP_NUMBERS')
	onehack.Spliter(MainSettingsScroll)
	onehack.CheckBox(MainSettingsScroll,'Armor bar','ESP_PLAYER_ARMOR_BOX')
	onehack.CheckBox(MainSettingsScroll,'Armor Numbers','ESP_PLAYER_ARMOR_NUMBERS')
	onehack.Spliter(MainSettingsScroll)
	onehack.CheckBox(MainSettingsScroll,'Weapon name','ESP_PLAYER_WEAPON_NAME')
	onehack.CheckBox(MainSettingsScroll,'Player Name','ESP_PLAYER_NAME')
	onehack.CheckBox(MainSettingsScroll,'Usergroup','ESP_PLAYER_USERGROUP')
	onehack.CheckBox(MainSettingsScroll,'Team name','ESP_PLAYER_TEAM')
	onehack.CheckBox(MainSettingsScroll,'Distance','ESP_PLAYER_DISTANCE')
	onehack.CheckBox(MainSettingsScroll,'Skeleton','ESP_PLAYER_SKELETON')
	
	local MainSettings = onehack.Panel(Player)
	MainSettings:Dock(LEFT)
	MainSettings:DockMargin(0, 10, 10, 10)
	MainSettings:SetWide(260)
	onehack.Header(MainSettings, {{name='Props',onclick=function()end}})
	local MainSettingsScroll = onehack.ScrollPanel(MainSettings,80)
	
	onehack.CheckBox(MainSettingsScroll,'Props ESP','ESP_PROPS_ENABLED')
	--onehack.CheckBox(MainSettingsScroll,'Only Visible','ESP_PROPS_ONLY_VISIBLE')
	onehack.Spliter(MainSettingsScroll)
	onehack.CheckBox(MainSettingsScroll,'Boxes','ESP_PROPS_BOX')
	onehack.Spliter(MainSettingsScroll)
	onehack.CheckBox(MainSettingsScroll,'Health bar','ESP_PROPS_HP_BOX')
	onehack.CheckBox(MainSettingsScroll,'Health Numbers','ESP_PROPS_HP_NUMBERS')
	onehack.Spliter(MainSettingsScroll)
	onehack.CheckBox(MainSettingsScroll,'Distance','ESP_PROPS_DISTANCE')
	onehack.CheckBox(MainSettingsScroll,'Prop URL','ESP_PROPS_URL')

	onehack.Header(Visuals, {
		{name='ESP',onclick=function()

			if IsValid(Visuals.ActiveTab) then Visuals.ActiveTab:Remove() end
			local Player = onehack.OptionsPanel(Visuals)
			Player:SetPos(0,50)
			Player:SetSize(Visuals:GetWide(),Visuals:GetTall()-50)
			Visuals.ActiveTab = Player
			function Player:Paint(w,h) 
				--draw.RoundedBox(0, 0, 0, w, h, Color(255,255,0))
			end

			local MainSettings = onehack.Panel(Player)
			MainSettings:Dock(LEFT)
			MainSettings:DockMargin(10, 10, 10, 10)
			MainSettings:SetWide(260)
			onehack.Header(MainSettings, {{name='Player',onclick=function()end}})
			local MainSettingsScroll = onehack.ScrollPanel(MainSettings,0)

            onehack.CheckBox(MainSettingsScroll,'Player ESP','ESP_PLAYER_ENABLED')
            onehack.CheckBox(MainSettingsScroll,'Only Visible','ESP_PLAYER_ONLY_VISIBLE')
            onehack.CheckBox(MainSettingsScroll,'Dormant','ESP_PLAYER_DORMANT_VISIBLE')
            onehack.Spliter(MainSettingsScroll)
            onehack.CheckBox(MainSettingsScroll,'Boxes','ESP_PLAYER_BOX')
            onehack.Spliter(MainSettingsScroll)
            onehack.CheckBox(MainSettingsScroll,'Health bar','ESP_PLAYER_HP_BOX')
            onehack.CheckBox(MainSettingsScroll,'Health Numbers','ESP_PLAYER_HP_NUMBERS')
            onehack.Spliter(MainSettingsScroll)
            onehack.CheckBox(MainSettingsScroll,'Armor bar','ESP_PLAYER_ARMOR_BOX')
            onehack.CheckBox(MainSettingsScroll,'Armor Numbers','ESP_PLAYER_ARMOR_NUMBERS')
            onehack.Spliter(MainSettingsScroll)
            onehack.CheckBox(MainSettingsScroll,'Weapon name','ESP_PLAYER_WEAPON_NAME')
			onehack.CheckBox(MainSettingsScroll,'Player Name','ESP_PLAYER_NAME')
			onehack.CheckBox(MainSettingsScroll,'Usergroup','ESP_PLAYER_USERGROUP')
			onehack.CheckBox(MainSettingsScroll,'Team name','ESP_PLAYER_TEAM')
			onehack.CheckBox(MainSettingsScroll,'Distance','ESP_PLAYER_DISTANCE')
			onehack.CheckBox(MainSettingsScroll,'Skeleton','ESP_PLAYER_SKELETON')
			
			local MainSettings = onehack.Panel(Player)
			MainSettings:Dock(LEFT)
			MainSettings:DockMargin(0, 10, 10, 10)
			MainSettings:SetWide(260)
			onehack.Header(MainSettings, {{name='Props',onclick=function()end}})
			local MainSettingsScroll = onehack.ScrollPanel(MainSettings,80)
			
            onehack.CheckBox(MainSettingsScroll,'Props ESP','ESP_PROPS_ENABLED')
            --onehack.CheckBox(MainSettingsScroll,'Only Visible','ESP_PROPS_ONLY_VISIBLE')
            onehack.Spliter(MainSettingsScroll)
            onehack.CheckBox(MainSettingsScroll,'Boxes','ESP_PROPS_BOX')
            onehack.Spliter(MainSettingsScroll)
            onehack.CheckBox(MainSettingsScroll,'Health bar','ESP_PROPS_HP_BOX')
			onehack.CheckBox(MainSettingsScroll,'Health Numbers','ESP_PROPS_HP_NUMBERS')
			onehack.Spliter(MainSettingsScroll)
			onehack.CheckBox(MainSettingsScroll,'Distance','ESP_PROPS_DISTANCE')
			onehack.CheckBox(MainSettingsScroll,'Prop URL','ESP_PROPS_URL')
		end},
		{name='World',onclick=function()

			if IsValid(Visuals.ActiveTab) then Visuals.ActiveTab:Remove() end
			local World = onehack.OptionsPanel(Visuals)
			World:SetPos(0,50)
			World:SetSize(Visuals:GetWide(),Visuals:GetTall()-50)
			Visuals.ActiveTab = World
			function World:Paint(w,h) 
				--draw.RoundedBox(0, 0, 0, w, h, Color(255,0,0))
			end

			local MainSettings = onehack.Panel(World)
			MainSettings:Dock(LEFT)
			MainSettings:DockMargin(10, 10, 10, 10)
			MainSettings:SetWide(260)
			onehack.Header(MainSettings, {{name='Textures',onclick=function()end}})
			local MainSettingsScroll = onehack.ScrollPanel(MainSettings,180)

			onehack.CheckBox(MainSettingsScroll,'Enabled','WORLD_ENABLED')
			onehack.Spliter(MainSettingsScroll)
			onehack.CheckBox(MainSettingsScroll,'Asus walls','WORLD_ASUSWALLS')
			onehack.Slider(MainSettingsScroll,'Asus wall value','WORLD_ASUSWALLS_NUMB',100,1)

			local MainSettings = onehack.Panel(World)
			MainSettings:Dock(LEFT)
			MainSettings:DockMargin(0, 10, 10, 10)
			MainSettings:SetWide(260)
			onehack.Header(MainSettings, {{name='HUD',onclick=function()end}})
			local MainSettingsScroll = onehack.ScrollPanel(MainSettings,-10)

			onehack.CheckBox(MainSettingsScroll,'Enabled','HUD_ENABLED')
			onehack.Spliter(MainSettingsScroll)
			onehack.CheckBox(MainSettingsScroll,'Crosshair','HUD_CROSSHAIR')
			onehack.Slider(MainSettingsScroll,'Crosshair grap','HUD_CROSSHAIR_GRAP',10,1)
			onehack.Slider(MainSettingsScroll,'Crosshair lenght','HUD_CROSSHAIR_LENGHT',10,1)
			onehack.Spliter(MainSettingsScroll)
			onehack.CheckBox(MainSettingsScroll,'Aim FOV','HUD_VELOCITYFOV')
			onehack.CheckBox(MainSettingsScroll,'Wathermark','HUD_WATHERMARK')
			onehack.CheckBox(MainSettingsScroll,'Hitmarker','HUD_HITMARKER')
			onehack.CheckBox(MainSettingsScroll,'Bullet trace','HUD_BULLETTRACE')
			onehack.CheckBox(MainSettingsScroll,'Snapline','HUD_SNAPLINE')
			onehack.CheckBox(MainSettingsScroll,'No Visual recoil','HUD_NOVISUALRECOIL')
			onehack.Spliter(MainSettingsScroll)
			onehack.CheckBox(MainSettingsScroll,'Thirdpreson','HUD_TPC')
			onehack.Slider(MainSettingsScroll,'Distance','HUD_TPCDIST',100,1)
		end},
		{name='Chams',onclick=function()

			if IsValid(Visuals.ActiveTab) then Visuals.ActiveTab:Remove() end
			local Chams = onehack.OptionsPanel(Visuals)
			Chams:SetPos(0,50)
			Chams:SetSize(Visuals:GetWide(),Visuals:GetTall()-50)
			Visuals.ActiveTab = Chams
			function Chams:Paint(w,h) 
				--draw.RoundedBox(0, 0, 0, w, h, Color(0,255,0))
			end

			local MainSettings = onehack.Panel(Chams)
			MainSettings:Dock(LEFT)
			MainSettings:DockMargin(10, 10, 10, 10)
			MainSettings:SetWide(260)
			onehack.Header(MainSettings, {{name='Player',onclick=function()end}})
			local MainSettingsScroll = onehack.ScrollPanel(MainSettings,80)

			onehack.CheckBox(MainSettingsScroll,'Enabled','CPLAYER_ENABLED')
			onehack.Spliter(MainSettingsScroll)
			onehack.CheckBox(MainSettingsScroll,'Visible chams','CPLAYER_ENABLED_VISIBLE')
			onehack.CheckBox(MainSettingsScroll,'Invisible chams','CPLAYER_ENABLED_INVISIBLE')
			onehack.Spliter(MainSettingsScroll)
			onehack.CheckBox(MainSettingsScroll,'Local chams','CPLAYER_SELFENABLED')
			onehack.CheckBox(MainSettingsScroll,'Hands chams','CPLAYER_HANDCHAMS')

			local MainSettings = onehack.Panel(Chams)
			MainSettings:Dock(LEFT)
			MainSettings:DockMargin(0, 10, 10, 10)
			MainSettings:SetWide(260)
			onehack.Header(MainSettings, {{name='Props',onclick=function()end}})
			local MainSettingsScroll = onehack.ScrollPanel(MainSettings,80)

			onehack.CheckBox(MainSettingsScroll,'Enabled','CPROPS_ENABLED')
			onehack.Spliter(MainSettingsScroll)
			onehack.CheckBox(MainSettingsScroll,'Visible chams','CPROPS_ENABLED_VISIBLE')
			onehack.CheckBox(MainSettingsScroll,'Invisible chams','CPROPS_ENABLED_INVISIBLE')

		end},
		{name='Glow',onclick=function()

			if IsValid(Visuals.ActiveTab) then Visuals.ActiveTab:Remove() end
			local Glow = onehack.OptionsPanel(Visuals)
			Glow:SetPos(0,50)
			Glow:SetSize(Visuals:GetWide(),Visuals:GetTall()-50)
			Visuals.ActiveTab = Glow
			function Glow:Paint(w,h) 
				--draw.RoundedBox(0, 0, 0, w, h, Color(0,0,255))
			end

			local MainSettings = onehack.Panel(Glow)
			MainSettings:Dock(LEFT)
			MainSettings:DockMargin(10, 10, 10, 10)
			MainSettings:SetWide(260)
			onehack.Header(MainSettings, {{name='Player',onclick=function()end}})
			local MainSettingsScroll = onehack.ScrollPanel(MainSettings,80)

			onehack.CheckBox(MainSettingsScroll,'Enabled','GPLAYER_ENABLED')
			onehack.Spliter(MainSettingsScroll)
			onehack.CheckBox(MainSettingsScroll,'Visible glow','GPLAYER_ENABLED_VISIBLE')
			onehack.CheckBox(MainSettingsScroll,'Invisible glow','GPLAYER_ENABLED_INVISIBLE')
			onehack.Spliter(MainSettingsScroll)
			onehack.CheckBox(MainSettingsScroll,'Local glow','GPLAYER_SELFENABLED')
			onehack.Spliter(MainSettingsScroll)
			onehack.CheckBox(MainSettingsScroll,'Dynamic light','GPLAYER_DYNAMICLIGHT')
			onehack.Slider(MainSettingsScroll,'Dynamic light range','GPLAYER_DYNAMICLIGHT_RANGE',100,1)

			local MainSettings = onehack.Panel(Glow)
			MainSettings:Dock(LEFT)
			MainSettings:DockMargin(0, 10, 10, 10)
			MainSettings:SetWide(260)
			onehack.Header(MainSettings, {{name='Props',onclick=function()end}})
			local MainSettingsScroll = onehack.ScrollPanel(MainSettings,80)

			onehack.CheckBox(MainSettingsScroll,'Enabled','GPROPS_ENABLED')
			onehack.Spliter(MainSettingsScroll)
			onehack.CheckBox(MainSettingsScroll,'Visible glow','GPROPS_ENABLED_VISIBLE')
			onehack.CheckBox(MainSettingsScroll,'Invisible glow','GPROPS_ENABLED_INVISIBLE')

		end},

		{name='Colors',onclick=function()

			if IsValid(Visuals.ActiveTab) then Visuals.ActiveTab:Remove() end
			local Colors = onehack.OptionsPanel(Visuals)
			Colors:SetPos(0,50)
			Colors:SetSize(Visuals:GetWide(),Visuals:GetTall()-50)
			Visuals.ActiveTab = Colors
			function Colors:Paint(w,h) 
				--draw.RoundedBox(0, 0, 0, w, h, Color(0,0,255))
			end

			local MainSettings = onehack.Panel(Colors)
			MainSettings:Dock(LEFT)
			MainSettings:DockMargin(10, 10, 10, 10)
			MainSettings:SetWide(260)
			local MainSettingsScroll = onehack.ScrollPanel(MainSettings,-99)

			onehack.ColorSwitch(MainSettingsScroll,"ESP Player boxes","COLOR_ESP_PLAYER_BOXES")
			onehack.ColorSwitch(MainSettingsScroll,"ESP Player Weapon Name","COLOR_ESP_PLAYER_WEAPON_NAME")
			onehack.ColorSwitch(MainSettingsScroll,"ESP Player Weapon Name","COLOR_ESP_PLAYER_NAME")
			onehack.ColorSwitch(MainSettingsScroll,"ESP Player Usergroup","COLOR_ESP_PLAYER_USERGROUP")
			onehack.ColorSwitch(MainSettingsScroll,"ESP Player Team","COLOR_ESP_PLAYER_TEAM")
			onehack.ColorSwitch(MainSettingsScroll,"ESP Player Distance","COLOR_ESP_PLAYER_DISTANCE")
			onehack.ColorSwitch(MainSettingsScroll,"ESP Player Skeleton","COLOR_ESP_PLAYER_SKELETON")
			onehack.ColorSwitch(MainSettingsScroll,"ESP Props boxes","COLOR_ESP_PROPS_BOXES")
			onehack.ColorSwitch(MainSettingsScroll,"ESP Props URL","COLOR_ESP_PROPS_URL")
			onehack.ColorSwitch(MainSettingsScroll,"ESP Props Distance","COLOR_ESP_PROPS_DISTANCE")
			onehack.ColorSwitch(MainSettingsScroll,"HUD Crosshair","COLOR_WORLD_CROSSHAIR")
			onehack.ColorSwitch(MainSettingsScroll,"HUD Spread FOV","COLOR_WORLD_SPREADFOV")
			onehack.ColorSwitch(MainSettingsScroll,"HUD Wathermark","COLOR_WORLD_WATHERMARK")
			onehack.ColorSwitch(MainSettingsScroll,"HUD Hitmarker","COLOR_WORLD_HITMARKER")
			onehack.ColorSwitch(MainSettingsScroll,"HUD Snapline","COLOR_WORLD_SNAPLINE")
			onehack.ColorSwitch(MainSettingsScroll,"HUD Bullet trace","COLOR_WORLD_BULLETTRACE")

			onehack.ColorSwitch(MainSettingsScroll,"Chams Player Visible","COLOR_CHAMS_PLAYER_VISIBLE")
			onehack.ColorSwitch(MainSettingsScroll,"Anti-Aim Real Chams","COLOR_CHAMS_PLAYER_REALAA")
			onehack.ColorSwitch(MainSettingsScroll,"Anti-Aim Fake Chams","COLOR_CHAMS_PLAYER_AA")
			onehack.ColorSwitch(MainSettingsScroll,"Chams Player InVisible","COLOR_CHAMS_PLAYER_INVISIBLE")
			onehack.ColorSwitch(MainSettingsScroll,"Chams Props Visible","COLOR_CHAMS_PROPS_VISIBLE")
			onehack.ColorSwitch(MainSettingsScroll,"Chams Props InVisible","COLOR_CHAMS_PROPS_INVISIBLE")
			onehack.ColorSwitch(MainSettingsScroll,"Chams Hands","COLOR_CHAMS_HANDS")

			onehack.ColorSwitch(MainSettingsScroll,"Glow Player","COLOR_GLOW_PLAYER")
			onehack.ColorSwitch(MainSettingsScroll,"Glow Props","COLOR_GLOW_PROPS")

			onehack.ColorSwitch(MainSettingsScroll,"Light","COLOR_LIGHT")
			
			local MainSettings = onehack.Panel(Colors)
			MainSettings:Dock(TOP)
			MainSettings:DockMargin(0, 10, 10, 10)
			MainSettings:SetSize(260,270)

			local Mixer = vgui.Create( "DColorMixer", MainSettings )
			Mixer:SetSize(240,210)
			Mixer:Dock(TOP)
			Mixer:DockMargin(10, 10, 10, 0)
			Mixer:SetPalette( false )
			Mixer:SetAlphaBar( true )
			Mixer:SetWangs( false )
			Mixer:SetColor( onehack.vars[onehack.ActiveColorChange] or Color(255,255,255) )
			function Mixer:ValueChanged( col )
				onehack.vars[onehack.ActiveColorChange] = col
			end
			local check = onehack.CheckBox(MainSettings,'Rainbow','ESP_RAINBOW_CURENT')
			function check:DoClick()
				onehack.rainbows[onehack.ActiveColorChange] = !onehack.rainbows[onehack.ActiveColorChange]
				onehack.vars['ESP_RAINBOW_CURENT'] = onehack.rainbows[onehack.ActiveColorChange]
			end
		end},
	})

end

local function AimPanel()

	if IsValid(onehack.curpage) then onehack.curpage:Remove() end

	local Aimbot = onehack.OptionsPanel(onehack.MainFrame)
	Aimbot.ActiveTab = nil
	Aimbot:MoveToBack()
	onehack.curpage = Aimbot

	local Legitbot = onehack.OptionsPanel(Aimbot)
	Legitbot:SetPos(0,50)
	Legitbot:SetSize(Aimbot:GetWide(),Aimbot:GetTall()-50)
	Aimbot.ActiveTab = Legitbot
	function Legitbot:Paint(w,h) end

	local MainSettings = onehack.Panel(Legitbot)
	MainSettings:Dock(TOP)
	MainSettings:DockMargin(10, 10, 10, 10)
	MainSettings:SetTall(50)

	onehack.CheckBox(MainSettings,'Enabled','AIMBOT_LEGIT_ENABLED')

	local Options = onehack.Panel(Legitbot)
	Options:Dock(LEFT)
	Options:DockMargin(10, 0, 10, 10)
	Options:SetWide(260)
	onehack.Header(Options, {{name='Options',onclick=function()end}})
	local OptionsScroll = onehack.ScrollPanel(Options,-30)

    onehack.CheckBox(OptionsScroll,'Auto shot','AIMBOT_LEGIT_AUTOSHOT')
	onehack.Slider(OptionsScroll,'FOV','AIMBOT_LEGIT_FOV',180,1)
	onehack.Slider(OptionsScroll,'Smooth','AIMBOT_LEGIT_SMOOTH',100,1)
	onehack.Spliter(OptionsScroll)
	onehack.CheckBox(OptionsScroll,'Ignore team','AIMBOT_LEGIT_IGNORETEAM')
	onehack.CheckBox(OptionsScroll,'Ignore admins','AIMBOT_LEGIT_IGNOREADMINS')
	onehack.CheckBox(OptionsScroll,'Ignore nocliped','AIMBOT_LEGIT_IGNORENOCLIP')
	onehack.Spliter(OptionsScroll)
	onehack.CheckBox(OptionsScroll,'Slient','AIMBOT_LEGIT_SLIENT')
	onehack.CheckBox(OptionsScroll,'No Recoil','AIMBOT_LEGIT_RECOIL')
	onehack.CheckBox(OptionsScroll,'No Spread (OD)','AIMBOT_LEGIT_SPREAD')

	local Settings = onehack.Panel(Legitbot)
	Settings:Dock(LEFT)
	Settings:DockMargin(0, 0, 10, 10)
	Settings:SetWide(260)
	onehack.Header(Settings, {{name='Anti-aim',onclick=function()end}})
	local SettingsScroll = onehack.ScrollPanel(Settings,4)

	onehack.CheckBox(SettingsScroll,'Enabled','AIMBOT_ANTIAIM_ENABLED')
	onehack.CheckBox(SettingsScroll,'Show Real Chams','AIMBOT_ANTIAIM_AACHAMS')
	onehack.Spliter(SettingsScroll)
	onehack.DropDown(SettingsScroll,"Pich",{"Disabled","Jitter","Down","Up"},"AIMBOT_ANTIAIM_PICH")
	onehack.DropDown(SettingsScroll,"Yaw",{"Disabled","Jitter","Switch","Switch + Backward","Switch + 180","Backward","180"},"AIMBOT_ANTIAIM_YAW")
	onehack.Slider(SettingsScroll,'Yaw Switch Range','AIMBOT_ANTIAIM_SWITCHRANGE',180,1)
	onehack.Slider(SettingsScroll,'Fake Yaw Switch Speed','AIMBOT_ANTIAIM_SWITCHSPEED',100,1)
	onehack.Spliter(SettingsScroll)
	onehack.CheckBox(SettingsScroll,'Enable Fake','AIMBOT_ANTIAIM_FAKE_ENABLED')
	onehack.CheckBox(SettingsScroll,'Show Fake Chams','AIMBOT_ANTIAIM_FAACHAMS')
	onehack.DropDown(SettingsScroll,"Fake Pich",{"Disabled","Jitter","Down","Up"},"AIMBOT_ANTIAIM_FAKE_PICH")
	onehack.DropDown(SettingsScroll,"Fake Yaw",{"Disabled","Jitter","Switch","Switch + Backward","Switch + 180","Backward","180"},"AIMBOT_ANTIAIM_FAKE_YAW")
	onehack.Slider(SettingsScroll,'Fake Yaw Switch Range','AIMBOT_ANTIAIM_FAKE_SWITCHRANGE',180,1)
	onehack.Slider(SettingsScroll,'Fake Yaw Switch Speed','AIMBOT_ANTIAIM_FAKE_SWITCHSPEED',100,1)
	onehack.Spliter(SettingsScroll)
	onehack.Slider(SettingsScroll,'Fake Lagg Factor','AIMBOT_ANTIAIM_FAKE_LAGG',100,1)
	onehack.CheckBox(SettingsScroll,'Show Lagg Chams','AIMBOT_ANTIAIM_FAKELAGG')

	onehack.Header(Aimbot, {
		{name='Legitbot',onclick=function()

			if IsValid(Aimbot.ActiveTab) then Aimbot.ActiveTab:Remove() end
			local Legitbot = onehack.OptionsPanel(Aimbot)
			Legitbot:SetPos(0,50)
			Legitbot:SetSize(Aimbot:GetWide(),Aimbot:GetTall()-50)
			Aimbot.ActiveTab = Legitbot
			function Legitbot:Paint(w,h) end

			local MainSettings = onehack.Panel(Legitbot)
			MainSettings:Dock(TOP)
			MainSettings:DockMargin(10, 10, 10, 10)
			MainSettings:SetTall(50)

			onehack.CheckBox(MainSettings,'Enabled','AIMBOT_LEGIT_ENABLED')

			local Options = onehack.Panel(Legitbot)
			Options:Dock(LEFT)
			Options:DockMargin(10, 0, 10, 10)
			Options:SetWide(260)
			onehack.Header(Options, {{name='Options',onclick=function()end}})
			local OptionsScroll = onehack.ScrollPanel(Options,-30)

			onehack.CheckBox(OptionsScroll,'Auto shot','AIMBOT_LEGIT_AUTOSHOT')
			onehack.Slider(OptionsScroll,'FOV','AIMBOT_LEGIT_FOV',180,1)
			onehack.Slider(OptionsScroll,'Smooth','AIMBOT_LEGIT_SMOOTH',100,1)
			onehack.Spliter(OptionsScroll)
			onehack.CheckBox(OptionsScroll,'Ignore team','AIMBOT_LEGIT_IGNORETEAM')
			onehack.CheckBox(OptionsScroll,'Ignore admins','AIMBOT_LEGIT_IGNOREADMINS')
			onehack.CheckBox(OptionsScroll,'Ignore nocliped','AIMBOT_LEGIT_IGNORENOCLIP')
			onehack.Spliter(OptionsScroll)
			onehack.CheckBox(OptionsScroll,'Slient','AIMBOT_LEGIT_SLIENT')
			onehack.CheckBox(OptionsScroll,'No Recoil','AIMBOT_LEGIT_RECOIL')
			onehack.CheckBox(OptionsScroll,'No Spread','AIMBOT_LEGIT_SPREAD')

			local Settings = onehack.Panel(Legitbot)
			Settings:Dock(LEFT)
			Settings:DockMargin(0, 0, 10, 10)
			Settings:SetWide(260)
			onehack.Header(Settings, {{name='Anti-aim',onclick=function()end}})
			local SettingsScroll = onehack.ScrollPanel(Settings,4)

			onehack.CheckBox(SettingsScroll,'Enabled','AIMBOT_ANTIAIM_ENABLED')
			onehack.CheckBox(SettingsScroll,'Show Real Chams','AIMBOT_ANTIAIM_AACHAMS')
			onehack.Spliter(SettingsScroll)
			onehack.DropDown(SettingsScroll,"Pich",{"Disabled","Jitter","Down","Up"},"AIMBOT_ANTIAIM_PICH")
			onehack.DropDown(SettingsScroll,"Yaw",{"Disabled","Jitter","Switch","Switch + Backward","Switch + 180","Backward","180"},"AIMBOT_ANTIAIM_YAW")
			onehack.Slider(SettingsScroll,'Yaw Switch Range','AIMBOT_ANTIAIM_SWITCHRANGE',180,1)
			onehack.Slider(SettingsScroll,'Fake Yaw Switch Speed','AIMBOT_ANTIAIM_SWITCHSPEED',100,1)
			onehack.Spliter(SettingsScroll)
			onehack.CheckBox(SettingsScroll,'Enable Fake','AIMBOT_ANTIAIM_FAKE_ENABLED')
			onehack.CheckBox(SettingsScroll,'Show Fake Chams','AIMBOT_ANTIAIM_FAACHAMS')
			onehack.DropDown(SettingsScroll,"Fake Pich",{"Disabled","Jitter","Down","Up"},"AIMBOT_ANTIAIM_FAKE_PICH")
			onehack.DropDown(SettingsScroll,"Fake Yaw",{"Disabled","Jitter","Switch","Switch + Backward","Switch + 180","Backward","180"},"AIMBOT_ANTIAIM_FAKE_YAW")
			onehack.Slider(SettingsScroll,'Fake Yaw Switch Range','AIMBOT_ANTIAIM_FAKE_SWITCHRANGE',180,1)
			onehack.Slider(SettingsScroll,'Fake Yaw Switch Speed','AIMBOT_ANTIAIM_FAKE_SWITCHSPEED',100,1)
			onehack.Spliter(SettingsScroll)
			onehack.Slider(SettingsScroll,'Fake Lagg Factor','AIMBOT_ANTIAIM_FAKE_LAGG',100,1)
			onehack.CheckBox(SettingsScroll,'Show Lagg Chams','AIMBOT_ANTIAIM_FAKELAGG')
		
		end},

		{name='Trigger',onclick=function()

			if IsValid(Aimbot.ActiveTab) then Aimbot.ActiveTab:Remove() end
			local Trigger = onehack.OptionsPanel(Aimbot)
			Trigger:SetPos(0,50)
			Trigger:SetSize(Aimbot:GetWide(),Aimbot:GetTall()-50)
			Aimbot.ActiveTab = Trigger
			function Trigger:Paint(w,h) end

			local MainSettings = onehack.Panel(Trigger)
			MainSettings:Dock(TOP)
			MainSettings:DockMargin(10, 10, 10, 10)
			MainSettings:SetTall(50)

			onehack.CheckBox(MainSettings,'Enabled','TRIGGER_ENABLED')

		end},

	})

end

local function MiscPanel()

	if IsValid(onehack.curpage) then onehack.curpage:Remove() end

	local Misc = onehack.OptionsPanel(onehack.MainFrame)
	Misc.ActiveTab = nil
	Misc:MoveToBack()
	onehack.curpage = Misc

	local Legitbot = onehack.OptionsPanel(Misc)
	Legitbot:SetPos(0,50)
	Legitbot:SetSize(Misc:GetWide(),Misc:GetTall()-50)
	Misc.ActiveTab = Legitbot
	function Legitbot:Paint(w,h) end

	local Options = onehack.Panel(Legitbot)
	Options:Dock(LEFT)
	Options:DockMargin(10, 10, 10, 10)
	Options:SetWide(260)
	onehack.Header(Options, {{name='Self',onclick=function()end}})
	local OptionsScroll = onehack.ScrollPanel(Options,-30)

	onehack.CheckBox(OptionsScroll,'Auto Bhop','OTHERS_BHOP')
	onehack.CheckBox(OptionsScroll,'Auto Strafe','OTHERS_STRAFE')
	onehack.CheckBox(OptionsScroll,'Flash-Spam','OTHERS_FSPAM')

	local Settings = onehack.Panel(Legitbot)
	Settings:Dock(LEFT)
	Settings:DockMargin(0, 10, 10, 10)
	Settings:SetWide(260)
	onehack.Header(Settings, {{name='Global',onclick=function()end}})
	local SettingsScroll = onehack.ScrollPanel(Settings,4)

	onehack.CheckBox(SettingsScroll,'Soon...','OTHRES_SOON')

	onehack.Header(Misc, {
		{name='Misc',onclick=function()

			if IsValid(Misc.ActiveTab) then Misc.ActiveTab:Remove() end
			local Legitbot = onehack.OptionsPanel(Misc)
			Legitbot:SetPos(0,50)
			Legitbot:SetSize(Misc:GetWide(),Misc:GetTall()-50)
			Misc.ActiveTab = Legitbot
			function Legitbot:Paint(w,h) end

			local Options = onehack.Panel(Legitbot)
			Options:Dock(LEFT)
			Options:DockMargin(10, 10, 10, 10)
			Options:SetWide(260)
			onehack.Header(Options, {{name='Self',onclick=function()end}})
			local OptionsScroll = onehack.ScrollPanel(Options,-30)

			onehack.CheckBox(OptionsScroll,'Auto Bhop','OTHERS_BHOP')
			onehack.CheckBox(OptionsScroll,'Auto Strafe','OTHERS_STRAFE')
			onehack.CheckBox(OptionsScroll,'Flash-Spam','OTHERS_FSPAM')

			local Settings = onehack.Panel(Legitbot)
			Settings:Dock(LEFT)
			Settings:DockMargin(0, 10, 10, 10)
			Settings:SetWide(260)
			onehack.Header(Settings, {{name='Global',onclick=function()end}})
			local SettingsScroll = onehack.ScrollPanel(Settings,4)

			onehack.CheckBox(SettingsScroll,'Soon...','OTHRES_SOON')
		
		end}

	})

end

function onehack.ToggleMenu()
onehack.MainFrame = onehack.DrawFrame(600,550)

onehack.SideFrame = onehack.SideMenu(onehack.MainFrame)

onehack.SideHeader(onehack.SideFrame)

ChamsPanel()

onehack.SideButton(onehack.SideFrame,'chams',"Visuals","Player, World, Chams, Glow",function()

	ChamsPanel()

end)

onehack.SideButton(onehack.SideFrame,'aimbot',"Aimbot","Legitbot, Trigger, Ragebot",function()

	AimPanel()

end)

onehack.SideButton(onehack.SideFrame,'other',"Misc","Other functions",function()

	MiscPanel()

end)

onehack.SideButton(onehack.SideFrame,'lconf',"Load config","Load your config",function()

	if file.Exists("o_conf.dat", "DATA") then
		local data = file.Read("o_conf.dat")
		for k,v in pairs(util.JSONToTable(data)) do
			onehack.vars[k] = v
		end
	end

end)

onehack.SideButton(onehack.SideFrame,'sconf',"Save config","Save your config",function()

	file.Write("o_conf.dat", util.TableToJSON(onehack.vars))

end)

onehack.SideFooter(onehack.SideFrame)
end

local input = input
local timer = timer
hook.Add("Think",'onehack.hooks',function()
	
	if onehack.vars['OTHERS_BHOP'] and input.IsKeyDown( KEY_SPACE ) then
		if LocalPlayer():IsTyping() == false and LocalPlayer():IsOnGround() and LocalPlayer():WaterLevel() <= 1 && LocalPlayer():GetMoveType() != MOVETYPE_LADDER then

	 		RunConsoleCommand("+jump")
	 		timer.Create("Bhop", 0, math.random( .280, .290 ), function()
	 		 	RunConsoleCommand("-jump")
			end)
		end
	end
	if input.IsKeyDown( KEY_F11 ) then
		if not timer.Exists('onehack.MenuIsPressed') then
			if IsValid(onehack.MainFrame) then
				onehack.MainFrame:AlphaTo(0, 0.2)
				timer.Simple(0.2,function()
					onehack.MainFrame:Remove()
				end)
			else
				onehack.ToggleMenu()
			end
			timer.Create('onehack.MenuIsPressed',0.3,1,function() end)
		end
	end
end)
require("bsendpacket")
local TickLagg = 1
function onehack.FakeLag(cmd)
    if onehack.vars['AIMBOT_ANTIAIM_FAKE_LAGG'] and onehack.vars['AIMBOT_ANTIAIM_FAKE_LAGG'] > 0 then
        TickLagg = TickLagg + 1
        bSendPacket = (TickLagg % (math.Round(onehack.vars['AIMBOT_ANTIAIM_FAKE_LAGG']*10+1))) == 0

    else
        bSendPacket = cmd:CommandNumber() % 2 == 1 
    end
end
onehack.Hit = {}
onehack.HitTracers = {}
onehack.Hit.Active = false
onehack.ActiveColorChange = 'none'
function onehack.coordinates( ent )
	local min, max = ent:OBBMins(), ent:OBBMaxs()
	local corners = {
			Vector( min.x, min.y, min.z ),
			Vector( min.x, min.y, max.z ),
			Vector( min.x, max.y, min.z ),
			Vector( min.x, max.y, max.z ),
			Vector( max.x, min.y, min.z ),
			Vector( max.x, min.y, max.z ),
			Vector( max.x, max.y, min.z ),
			Vector( max.x, max.y, max.z )
	}
 
    local minX, minY, maxX, maxY = ScrW() * 2, ScrH() * 2, 0, 0
    for _, corner in pairs( corners ) do
            local onScreen = ent:LocalToWorld( corner ):ToScreen()
            minX, minY = math.min( minX, onScreen.x ), math.min( minY, onScreen.y )
            maxX, maxY = math.max( maxX, onScreen.x ), math.max( maxY, onScreen.y )
    end
    return minX, minY, maxX, maxY
end

function onehack.IsVisible(pOne,pTwo)
	local trace = {
		start = pOne:EyePos(),
		endpos = pTwo:EyePos(),
		filter = {pOne, pTwo},
		mask = MASK_SHOT,
    };
    
    if (util.TraceLine(trace).Fraction == 1 ) then
		return true;
    end
    
    return false;
end

hook.Add("ScalePlayerDamage","onehack.SDamage", function(ply, hitgroup, dmginfo)
	onehack.Hit = {}
	onehack.Hit.Active = true
	onehack.Hit.Pos = LocalPlayer():GetEyeTrace().HitPos
	onehack.Hit.Alpha = 255
    if (onehack.Hit) then timer.Simple(1.3, function() onehack.Hit.Active = false end) end
end)

hook.Add("PlayerTraceAttack", "onehack.DamageTrace", function(ent, dmg, dir, trace)
	if(!IsFirstTimePredicted()) then return; end
	local pos1, pos2;
	pos1 = trace.HitPos;
	pos2 = trace.StartPos;
	table.insert(onehack.HitTracers, {pos1, pos2, 3, onehack.vars['COLOR_WORLD_BULLETTRACE'], LocalPlayer():EyeAngles()});
end);
onehack.SourceSkyname = GetConVar("sv_skyname"):GetString()
onehack.orgskyname = onehack.SourceSkyname
onehack.SourceSkyPre = {"lf", "ft", "rt", "bk", "dn", "up"}
onehack.SourceSkyMat = {
    Material("skybox/".. onehack.SourceSkyname.. "lf"),
    Material("skybox/".. onehack.SourceSkyname.. "ft"),
    Material("skybox/".. onehack.SourceSkyname.. "rt"),
    Material("skybox/".. onehack.SourceSkyname.. "bk"),
    Material("skybox/".. onehack.SourceSkyname.. "dn"),
    Material("skybox/".. onehack.SourceSkyname.. "up")
}
function onehack.ChangeSkybox(skyboxname)
	for i = 1, 6 do
		onehack.D = Material("skybox/".. skyboxname.. onehack.SourceSkyPre[i]):GetTexture("$basetexture")
		onehack.SourceSkyMat[i]:SetTexture("$basetexture", onehack.D)
	end
end

onehack.chamsMaterial = CreateMaterial("a", "VertexLitGeneric", {
	["$ignorez"] = 1,
	["$model"] = 1,
	["$basetexture"] = "models/debug/debugwhite",
})
onehack.chamsMaterialZ = CreateMaterial("@", "VertexLitGeneric", {
	["$ignorez"] = 0,
	["$model"] = 1,
	["$basetexture"] = "models/debug/debugwhite",
})
onehack.chamsHMaterialZ = CreateMaterial("@", "VertexLitGeneric", {
	["$basetexture"] = "models/debug/debugwhite",
	["$model"] = 1,
	["$nocull"]      = 1,
	["$ignorez"] = 1,
	["vertexcolor"] = 1,
	["$color2"] = "{255 255 255}"
})
function onehack.Chams(v,ignorez,color)
	cam.Start3D()

		render.SuppressEngineLighting(true)

		if(ignorez) then

			render.MaterialOverride(onehack.chamsMaterial)
			render.SetColorModulation(color.r/255,color.g/255,color.b/255)
			
			v:DrawModel()

		else

			render.SetColorModulation(color.r/255,color.g/255,color.b/255)
			render.MaterialOverride(onehack.chamsMaterialZ)
		
			v:DrawModel()

		end

	cam.End3D()
end

function onehack.DynamicLights(v,color)
	dlight = DynamicLight(v)
		
	if(dlight) then
		dlight.pos = v:GetPos()-Vector(0,0,1)
		dlight.r = color.r
		dlight.g = color.g
		dlight.b = color.b
		dlight.brightness = (onehack.vars['GPLAYER_DYNAMICLIGHT_RANGE'] or 1) *50
		dlight.Decay = 0.4
		dlight.Size = (onehack.vars['GPLAYER_DYNAMICLIGHT_RANGE'] or 1) * 50
		dlight.DieTime = CurTime() + 0.5
	end
end

function onehack.InFOV(v)
	local sang = LocalPlayer():GetAngles()
	if onehack.vars['AIMBOT_LEGIT_SLIENT'] then
		sang = onehack.fakeangles
	end
    if(360*onehack.vars['AIMBOT_LEGIT_FOV'] < 180) then
        onehack.lpang = sang
        onehack.ang = (v:GetPos() - LocalPlayer():GetPos()):Angle()
        onehack.ady = math.abs(math.NormalizeAngle(onehack.lpang.y - onehack.ang.y))
        onehack.adp = math.abs(math.NormalizeAngle(onehack.lpang.p - onehack.ang.p ))

        if(onehack.ady > 360*onehack.vars['AIMBOT_LEGIT_FOV'] || onehack.adp > 360*onehack.vars['AIMBOT_LEGIT_FOV']) then return(false) end
    end

    return(true)
end

function onehack.PredictPos(pos)
	pos = pos - (LocalPlayer():GetVelocity() * engine.TickInterval())
	return(pos)
end

function onehack.Autofire(ucmd)
	ucmd:SetButtons(bit.bor(ucmd:GetButtons(), 1))
end

function onehack.Visible( ply )
	if (!IsValid( ply )) then return false end
   
	local vecPos, _ = ply:GetBonePosition( ply:LookupBone( "ValveBiped.Bip01_Head1" ) or 12 );
	local trace = { start = LocalPlayer():EyePos(), endpos = vecPos, filter = LocalPlayer(), mask = MASK_SHOT };
	local traceRes = util.TraceLine( trace );
   
	TraceRes = traceRes;
   
	if (traceRes.HitWorld || traceRes.Entity != ply) then return false end;
   
	return true;
end

function onehack.PrepareForAStomping( ply )
    if !ply:IsValid() then return false end

    if ply:GetModel() == "models/crow.mdl" then return ply:LocalToWorld( Vector(0, 0, 5) ) end
	local head = ply:LookupAttachment( "eyes" )
	if head then
		local pos = ply:GetAttachment(head)
		if pos then
			local tpoz = pos.Pos + ply:EyeAngles():Forward() * -1.5
			return tpoz
		end
	end

	local lastresort = ply:LocalToWorld( ply:OBBCenter() )
	if onehack.Visible( ply ) then return lastresort end
    return false
end

function onehack.FixMovment(cmd)

    local move = Vector( cmd:GetForwardMove(), cmd:GetSideMove(), cmd:GetUpMove() )
    local speed = math.sqrt( move.x * move.x + move.y * move.y )
    local mang = move:Angle()
    local yaw = math.rad( cmd:GetViewAngles().y - onehack.fakeangles.y + mang.y )
    cmd:SetForwardMove( (math.cos(yaw) * speed) * 1 )
    cmd:SetSideMove( math.sin(yaw) * speed )

end

function onehack.Silent(ucmd)
	if(!onehack.fakeangles) then onehack.fakeangles = ucmd:GetViewAngles(); end
	onehack.fakeangles = onehack.fakeangles + Angle(ucmd:GetMouseY() * .023, ucmd:GetMouseX() * -.023, 0);
	onehack.fakeangles.x = math.NormalizeAngle(onehack.fakeangles.x);
	onehack.fakeangles.p = math.Clamp(onehack.fakeangles.p, -89, 89);
	if(ucmd:CommandNumber() == 0) then
		ucmd:SetViewAngles(onehack.fakeangles);
		return;
    end
end

local awaitme = CurTime()
local target = nil
function onehack.FroceBackStap(cmd)
	if not onehack.CurTarget and onehack.vars['AIMBOT_FORCEBACKSTAP'] and awaitme < CurTime() then
		local backstap = LocalPlayer():GetEyeTrace().Entity
		local weap = LocalPlayer():GetActiveWeapon()
		if weap:IsValid() and string.find(weap:GetClass(),"csgo") and backstap:IsPlayer() then
			local pose = LocalPlayer():GetEyeTrace().HitPos
			target = backstap
			if target:IsPlayer() and pose:Distance(LocalPlayer():GetPos()) < 80 then
				cmd:SetViewAngles(target:GetPos():Angle())
				cmd:SetButtons(bit.bor(cmd:GetButtons(), 2048))
				cmd:SetViewAngles(target:GetAngles()-Angle(180,0,0))
				awaitme = CurTime() + 1
			end
		end
	end
end

function onehack.AStrafe(cmd)
	if (cmd:KeyDown(IN_JUMP) and onehack.vars['OTHERS_BHOP'] and onehack.vars['OTHERS_STRAFE']) then
		print(cmd:GetMouseX())
		if(cmd:GetMouseX() < 0) then --spinning right
			cmd:SetForwardMove(-1000000)
		elseif(cmd:GetMouseX() > 0) then
			cmd:SetForwardMove(1000000)
		end
	end
end

hook.Add("CreateMove", "onehack.PredirMovment", function(ucmd)
	if input.IsKeyDown(KEY_F) and onehack.vars["OTHERS_FSPAM"] then ucmd:SetImpulse(100) end
	onehack.FakeLag(ucmd)
	onehack.AStrafe(ucmd)
	if onehack.vars['AIMBOT_LEGIT_SLIENT'] or onehack.vars['AIMBOT_ANTIAIM_ENABLED'] then
		if onehack.vars['AIMBOT_ANTIAIM_ENABLED'] then
			onehack.AntiAim(ucmd)
		else
			bSendPacket = true
		end
		onehack.Silent(ucmd)
		onehack.FixMovment(ucmd)
	end
end)

function onehack.SnapRotate(snapendx,snapendy)
	local _x = snapendx - ScrW()/2
	local _y = snapendy - ScrH()/2

	local snapangle = math.deg(math.atan2(_y,_x))

	local x = math.cos(math.rad(snapangle - 90))
	local y = -math.cos(math.rad(snapangle))

	if (x > 0) then
		x = math.ceil(x)
	else
		x = math.floor(x)
	end

	if (y > 0) then
		y = math.ceil(y)
	else
		y = math.floor(y)
	end

	return x, y
end

local onehackRT = GetRenderTarget( "onehackRT" .. os.time(), ScrW(), ScrH() )
 
hook.Add( "RenderScene", "onehack.ASG", function( vOrigin, vAngle, vFOV )
    local view = {
        x = 0,
        y = 0,
        w = ScrW(),
        h = ScrH(),
        dopostprocess = true,
        origin = vOrigin,
        angles = vAngle,
        fov = vFOV,
        drawhud = true,
        drawmonitors = true,
        drawviewmodel = true
    }
 
    render.RenderView( view )
    render.CopyTexture( nil, onehackRT )
 
    cam.Start2D()
        hook.Run( "OnePaint" )
    cam.End2D()
 
    render.SetRenderTarget( onehackRT )
 
    return true
end )
 
hook.Add( "ShutDown", "onehack.ASG", function()
    render.SetRenderTarget()
end )

hook.Add("Think","onehack.RainBow",function()

	local col = HSVToColor( CurTime()*100 % 360, 1, 1 )

	for i, v in next, onehack.rainbows do
		if v  == true then
			onehack.vars[i] = col
		end
	end

end)
local alpha = 0


hook.Add("OnePaint", "onehack.ESP", function()

    if onehack.MainFrame and onehack.MainFrame:IsValid() and alpha < 200 then
        alpha = alpha + 5
    elseif alpha > 0 and not onehack.MainFrame:IsValid() then
        alpha = alpha - 5
    end

    if alpha > 1 then
        surface.SetDrawColor(0,0,0,alpha)
        surface.DrawRect(0,0,ScrW(),ScrH())
    end

    if onehack.vars['ESP_PLAYER_ENABLED'] then

        for k,ply in pairs(player.GetAll()) do

            local left,top,right,bottom = onehack.coordinates(ply)

            local dist = ply:GetPos():Distance(LocalPlayer():GetPos())

            if ply ~= LocalPlayer() and not (ply:IsDormant() and not onehack.vars['ESP_PLAYER_DORMANT_VISIBLE']) and ((onehack.IsVisible(LocalPlayer(),ply) and onehack.vars['ESP_PLAYER_ONLY_VISIBLE']) or not onehack.vars['ESP_PLAYER_ONLY_VISIBLE']) and ply:Alive() then

                if left ~= 0 and right ~= 0 and top ~= 0 and bottom ~= 0 then

                    if onehack.vars['ESP_PLAYER_BOX'] then
                        surface.SetDrawColor(onehack.vars['COLOR_ESP_PLAYER_BOXES'])
                        surface.DrawLine( left, top, right, top )
                        surface.DrawLine( left, top, left, bottom )
                        surface.DrawLine( right, top,  right, bottom )
                        surface.DrawLine( left, bottom, right, bottom )
        
                        surface.SetDrawColor(Color(0,0,0))
                        surface.DrawLine( left-1, top-1, right+1, top-1 )
                        surface.DrawLine( left-1, top-1, left-1, bottom+1 )
                        surface.DrawLine( right+1, top-1, right+1, bottom+1 )
                        surface.DrawLine( left-1, bottom+1, right+1, bottom+1 )
        
                        surface.SetDrawColor(Color(0,0,0))
                        surface.DrawLine( left+1, top+1, right-1, top+1 )
                        surface.DrawLine( left+1, top+1, left+1, bottom-1 )
                        surface.DrawLine( right-1, top+1, right-1, bottom-1 )
                        surface.DrawLine( left+1, bottom-1, right-1, bottom-1 )
                    end


                    if onehack.vars['ESP_PLAYER_HP_BOX'] then
                        local height = bottom - top - 1
                        local hp = math.min(ply:Health(), 100)

                        onehack.InfoBoxes( 0,"", left - 8, bottom - height - 2,left - 2, bottom,0,0,0,255 )
                        onehack.InfoBoxes( 0,"", left - 7, bottom - height - 1,left - 3, bottom-1,0,200,0,30 )
                        if onehack.vars['ESP_PLAYER_HP_NUMBERS'] then
                            onehack.InfoBoxes( 0,ply:Health().."%", left - 7, bottom - (hp / 100) * height - 1,left - 3, bottom-1,255 - (hp*2.55),hp * 2.55,0,255 )
                        else
                            onehack.InfoBoxes( 0,"", left - 7, bottom - (hp / 100) * height - 1,left - 3, bottom-1,255 - (hp*2.55),hp * 2.55,0,255 )
                        end
                    end

                    if onehack.vars['ESP_PLAYER_ARMOR_BOX'] then
                        local height = bottom - top - 1
                        local ar = math.min(ply:Armor(), 100)

                        onehack.InfoBoxes( 0,"", left - 15, bottom - height - 2,left - 10, bottom,0,0,0,255 )
                        onehack.InfoBoxes( 0,"", left - 14, bottom - height - 1,left - 11, bottom-1,19-20,136-20,191-20,100 )
                        if onehack.vars['ESP_PLAYER_ARMOR_NUMBERS'] then
                            onehack.InfoBoxes( 2,ply:Armor().."%", left - 14, bottom - (ar / 100) * height - 1,left - 11, bottom-1,19,136,191,255 )
                        else
                            onehack.InfoBoxes( 2,"", left - 14, bottom - (ar / 100) * height - 1,left - 11, bottom-1,19,136,191,255 )
                        end
                    end

                    if onehack.vars['ESP_PLAYER_WEAPON_NAME'] and ply:GetActiveWeapon():IsValid() then
                        draw.SimpleTextOutlined(ply:GetActiveWeapon():GetPrintName() or ply:GetActiveWeapon():GetClass(),"onehack.font.18",left + (right - left) / 2, bottom + 10,onehack.vars['COLOR_ESP_PLAYER_WEAPON_NAME'],1,1,1,Color(0,0,0))
                    end

                    if onehack.vars['ESP_PLAYER_NAME'] then
                        draw.SimpleTextOutlined(ply:Name(),"onehack.font.18",left + (right - left) / 2, top - 10,onehack.vars['COLOR_ESP_PLAYER_NAME'],1,1,1,Color(0,0,0))
                    end

                    local tabber = 0

                    if onehack.vars['ESP_PLAYER_USERGROUP'] then
                        draw.SimpleTextOutlined(ply:GetUserGroup(),"onehack.font.18",right + 5, top,onehack.vars['COLOR_ESP_PLAYER_USERGROUP'],0,0,1,Color(0,0,0))
                        tabber = tabber + 20
                    end

                    if onehack.vars['ESP_PLAYER_TEAM'] then
                        draw.SimpleTextOutlined(team.GetName(ply:Team()),"onehack.font.18",right + 5, top+tabber,onehack.vars['COLOR_ESP_PLAYER_TEAM'],0,0,1,Color(0,0,0))
                        tabber = tabber + 20
                    end

                    if onehack.vars['ESP_PLAYER_DISTANCE'] then
                        draw.SimpleTextOutlined(math.Round(dist/10).."f","onehack.font.18",right + 5, top+tabber,onehack.vars['COLOR_ESP_PLAYER_DISTANCE'],0,0,1,Color(0,0,0))
                        tabber = tabber + 20
                    end


                    if onehack.vars['ESP_PLAYER_SKELETON'] and dist < 1400 then
                        local Bones = {}
                        local sBones = {
                        "ValveBiped.Bip01_Head1",
                        "ValveBiped.Bip01_Neck1",
                        "ValveBiped.Bip01_Spine4",
                        "ValveBiped.Bip01_Spine2",
                        "ValveBiped.Bip01_Spine1",
                        "ValveBiped.Bip01_Spine",
                        "ValveBiped.Bip01_Pelvis",
                        "ValveBiped.Bip01_R_UpperArm",
                        "ValveBiped.Bip01_R_Forearm",
                        "ValveBiped.Bip01_R_Hand",
                        "ValveBiped.Bip01_L_UpperArm",
                        "ValveBiped.Bip01_L_Forearm",
                        "ValveBiped.Bip01_L_Hand",
                        "ValveBiped.Bip01_R_Thigh",
                        "ValveBiped.Bip01_R_Calf",
                        "ValveBiped.Bip01_R_Foot",
                        "ValveBiped.Bip01_R_Toe0",
                        "ValveBiped.Bip01_L_Thigh",
                        "ValveBiped.Bip01_L_Calf",
                        "ValveBiped.Bip01_L_Foot",
                        "ValveBiped.Bip01_L_Toe0"
                        }
                        local Success = true
                        for k, v in pairs(sBones) do
                            if ply:LookupBone(v) != nil && ply:GetBonePosition(ply:LookupBone(v)) != nil then
                                table.insert( Bones, ply:GetBonePosition(ply:LookupBone(v)):ToScreen() )
                            else
                                Success = false
                            end
                        end
                        surface.SetDrawColor(onehack.vars['COLOR_ESP_PLAYER_SKELETON'])
                        surface.DrawLine( Bones[1].x, Bones[1].y, Bones[2].x, Bones[2].y )
                        surface.DrawLine( Bones[2].x, Bones[2].y, Bones[3].x, Bones[3].y )
                        surface.DrawLine( Bones[3].x, Bones[3].y, Bones[4].x, Bones[4].y )
                        surface.DrawLine( Bones[4].x, Bones[4].y, Bones[5].x, Bones[5].y )
                        surface.DrawLine( Bones[5].x, Bones[5].y, Bones[6].x, Bones[6].y )
                        surface.DrawLine( Bones[6].x, Bones[6].y, Bones[7].x, Bones[7].y )

                        //Legs
                        surface.DrawLine( Bones[7].x, Bones[7].y, Bones[14].x, Bones[14].y )
                        surface.DrawLine( Bones[14].x, Bones[14].y, Bones[15].x, Bones[15].y )
                        surface.DrawLine( Bones[15].x, Bones[15].y, Bones[16].x, Bones[16].y )
                        surface.DrawLine( Bones[16].x, Bones[16].y, Bones[17].x, Bones[17].y )

                        surface.DrawLine( Bones[7].x, Bones[7].y, Bones[18].x, Bones[18].y )
                        surface.DrawLine( Bones[18].x, Bones[18].y, Bones[19].x, Bones[19].y )
                        surface.DrawLine( Bones[19].x, Bones[19].y, Bones[20].x, Bones[20].y )
                        surface.DrawLine( Bones[20].x, Bones[20].y, Bones[21].x, Bones[21].y )

                        //Arms
                        surface.DrawLine( Bones[3].x, Bones[3].y, Bones[8].x, Bones[8].y )
                        surface.DrawLine( Bones[8].x, Bones[8].y, Bones[9].x, Bones[9].y )
                        surface.DrawLine( Bones[9].x, Bones[9].y, Bones[10].x, Bones[10].y )

                        surface.DrawLine( Bones[3].x, Bones[3].y, Bones[11].x, Bones[11].y )
                        surface.DrawLine( Bones[11].x, Bones[11].y, Bones[12].x, Bones[12].y )
                        surface.DrawLine( Bones[12].x, Bones[12].y, Bones[13].x, Bones[13].y )
                    end

                end

            end
            
        end
    end


    if onehack.vars['ESP_PROPS_ENABLED'] then

        for _, prop in pairs( ents.FindByClass( "prop_*" ) ) do

            local left,top,right,bottom = onehack.coordinates(prop)

            local dist = prop:GetPos():Distance(LocalPlayer():GetPos())

            if left ~= 0 and right ~= 0 and top ~= 0 and bottom ~= 0 then

                if onehack.vars['ESP_PROPS_BOX'] then
                    surface.SetDrawColor(onehack.vars['COLOR_ESP_PROPS_BOXES'])
                    surface.DrawLine( left, top, right, top )
                    surface.DrawLine( left, top, left, bottom )
                    surface.DrawLine( right, top,  right, bottom )
                    surface.DrawLine( left, bottom, right, bottom )
    
                    surface.SetDrawColor(Color(0,0,0))
                    surface.DrawLine( left-1, top-1, right+1, top-1 )
                    surface.DrawLine( left-1, top-1, left-1, bottom+1 )
                    surface.DrawLine( right+1, top-1, right+1, bottom+1 )
                    surface.DrawLine( left-1, bottom+1, right+1, bottom+1 )
    
                    surface.SetDrawColor(Color(0,0,0))
                    surface.DrawLine( left+1, top+1, right-1, top+1 )
                    surface.DrawLine( left+1, top+1, left+1, bottom-1 )
                    surface.DrawLine( right-1, top+1, right-1, bottom-1 )
                    surface.DrawLine( left+1, bottom-1, right-1, bottom-1 )
                end


                if onehack.vars['ESP_PROPS_HP_BOX'] then
                    local height = bottom - top - 1
                    local hp = math.min(prop:Health(), 100)

                    onehack.InfoBoxes( 0,"", left - 8, bottom - height - 2,left - 2, bottom,0,0,0,255 )
                    onehack.InfoBoxes( 0,"", left - 7, bottom - height - 1,left - 3, bottom-1,0,200,0,30 )
                    if onehack.vars['ESP_PROPS_HP_NUMBERS'] then
                        onehack.InfoBoxes( 0,prop:Health().."%", left - 7, bottom - (hp / 100) * height - 1,left - 3, bottom-1,255 - (hp*2.55),hp * 2.55,0,255 )
                    else
                        onehack.InfoBoxes( 0,"", left - 7, bottom - (hp / 100) * height - 1,left - 3, bottom-1,255 - (hp*2.55),hp * 2.55,0,255 )
                    end
                end

                if onehack.vars['ESP_PROPS_URL'] then
                    draw.SimpleTextOutlined(prop:GetModel(),"onehack.font.18",left + (right - left) / 2, bottom + 10,onehack.vars['COLOR_ESP_PROPS_URL'],1,1,1,Color(0,0,0))
                end

                if onehack.vars['ESP_PROPS_DISTANCE'] then
                    draw.SimpleTextOutlined(math.Round(dist/10).."f","onehack.font.18",left + (right - left) / 2, top - 10,onehack.vars['COLOR_ESP_PROPS_DISTANCE'],1,1,1,Color(0,0,0))
                end

            end

        end

    end

end)
local mattable = {};
hook.Add("RenderScene", "onehack.WORLD", function()

    if onehack.vars['WORLD_ASUSWALLS'] and onehack.vars['WORLD_ENABLED'] then
        if (#mattable == 0) then
            for k,v in next, game.GetWorld():GetMaterials() do
                mattable[#mattable + 1] = Material(v);
            end
        end

        for k,v in next, mattable do
            v:SetFloat("$alpha", (onehack.vars["WORLD_ASUSWALLS_NUMB"] or 1));
        end
    else
        if (#mattable == 0) then
            for k,v in next, game.GetWorld():GetMaterials() do
                mattable[#mattable + 1] = Material(v);
            end
        end

        for k,v in next, mattable do
            v:SetFloat("$alpha", 1);
        end
    end

end)

hook.Add("CalcView", "onehack.Thirdperson", function(p, o, a, f)
    if onehack.vars['HUD_TPC'] and onehack.vars['HUD_ENABLED'] then
        local lang = LocalPlayer():EyeAngles()
        if onehack.vars['AIMBOT_LEGIT_SLIENT'] or onehack.vars['AIMBOT_ANTIAIM_ENABLED'] then
            lang = onehack.fakeangles
        end
        local tr = util.TraceLine( {
            start = o - lang:Forward() * 2,
            endpos = o - lang:Forward() * (onehack.vars['HUD_TPCDIST']*1000),
            filter = player.GetAll(),
            mask = MASK_SHOT
        } )

        return({
            angles = lang,
            origin = tr.HitPos + lang:Forward() * 20,
            fov = f,
        })
    end
end)

hook.Add("ShouldDrawLocalPlayer", "onehack.Thirdperson", function()
	return(onehack.vars['HUD_TPC'] and onehack.vars['HUD_ENABLED'] )
end)


local alpha = 0
local hight = 0
hook.Add('OnePaint','onehack.HUD',function()
    
    
    --draw.RoundedBox(5, 10, 10, 20, 20, bSendPacket and Color(0,255,0) or Color(255,0,0)) DEV

    if not onehack.vars['HUD_ENABLED'] then return end

    if onehack.vars['HUD_CROSSHAIR'] then
        local p = LocalPlayer():GetEyeTrace().HitPos:ToScreen()
        local x,y = p.x, p.y
        local active_weapon = LocalPlayer():GetActiveWeapon()
        if IsValid(active_weapon) then
            active_weapon = active_weapon:GetClass()
        end
        if LocalPlayer():IsValid() then
            surface.SetDrawColor( onehack.vars['COLOR_WORLD_CROSSHAIR'] )       
            local gap = (onehack.vars['HUD_CROSSHAIR_GRAP'] or 0.4) * 50
            local length = gap + (onehack.vars['HUD_CROSSHAIR_LENGHT'] or 0.4) * 50
            surface.DrawLine( x - length, y, x - gap, y )
            surface.DrawLine( x + length, y, x + gap, y )
            surface.DrawLine( x, y - length, x, y - gap )
            surface.DrawLine( x, y + length, x, y + gap )
        end
    end

    if onehack.vars['HUD_SNAPLINE'] and onehack.CurTarget then

        local pos = onehack.CurTarget:GetShootPos():ToScreen()

        if (math.abs(pos.x) < ScrW()*5 && math.abs(pos.y) < ScrH()*5) then

            draw.NoTexture()
            local offsetx, offsety = onehack.SnapRotate(pos.x, pos.y)
            surface.SetDrawColor(Color(0,0,0))
            surface.DrawLine( ScrW()/2-offsetx,  ScrH()/2-offsety, pos.x-offsetx, pos.y-offsety)

            surface.SetDrawColor(onehack.vars['COLOR_WORLD_SNAPLINE'])
            surface.DrawLine(ScrW()/2, ScrH()/2, pos.x, pos.y)

            surface.SetDrawColor(Color(0,0,0))
            surface.DrawLine( ScrW()/2+offsetx,  ScrH()/2+offsety, pos.x+offsetx, pos.y+offsety)

        end

    end

    if onehack.vars['HUD_VELOCITYFOV'] then

        onehack.FilledCircle(ScrW()/2, ScrH()/2,4624*onehack.vars['AIMBOT_LEGIT_FOV'], 50, onehack.vars['COLOR_WORLD_SPREADFOV'])

    end

    if onehack.vars['HUD_WATHERMARK'] then
        surface.SetFont("DermaDefault")
        local tw,th = surface.GetTextSize("OneHack.su | "..math.Round(1/FrameTime()).." FPS | "..LocalPlayer():Ping().." PING | "..os.date( "%H:%M:%S" , os.time() ).." | "..LocalPlayer():Name())
        tw = tw + 3
        onehack.DrawRect(5,5,10+tw,25,onehack.vars['COLOR_WORLD_WATHERMARK'])
        onehack.DrawRect(9,9,2+tw,17,onehack.vars['COLOR_WORLD_WATHERMARK'])
        onehack.DrawOutLinedRect(5,5,10+tw,25,Color(0,0,0,50))
        onehack.DrawOutLinedRect(9,9,2+tw,17,Color(0,0,0,50))
        draw.SimpleText("OneHack.su | "..math.Round(1/FrameTime()).." FPS | "..LocalPlayer():Ping().." PING | "..os.date( "%H:%M:%S" , os.time() ).." | "..LocalPlayer():Name(),"DermaDefault",13,11,Color(0,0,0))
        draw.SimpleText("OneHack.su | "..math.Round(1/FrameTime()).." FPS | "..LocalPlayer():Ping().." PING | "..os.date( "%H:%M:%S" , os.time() ).." | "..LocalPlayer():Name(),"DermaDefault",12,10,Color(255,255,255))
    end


    for k,v in next, onehack.HitTracers do
        if(v[3] <= 0) then
                table.remove(onehack.HitTracers, k);
                continue;
        end
        onehack.HitTracers[k][3] = onehack.HitTracers[k][3] - FrameTime();
        local pos1, pos2 = v[1], v[2];

        if onehack.vars['HUD_BULLETTRACE'] then
            cam.Start3D();
                    render.DrawLine(pos1, pos2, v[4], true);
            cam.End3D();
        end

        local p = pos1:ToScreen()
        local x,y = p.x, p.y

        if onehack.vars['HUD_HITMARKER'] then
            surface.SetDrawColor( onehack.vars['COLOR_WORLD_HITMARKER'] )       
            surface.DrawLine( x+10, y-10, x+3, y-3 )
            surface.DrawLine( x-10, y-10, x-3, y-3 )

            surface.DrawLine( x+10, y+10, x+3, y+3 )
            surface.DrawLine( x-10, y+10, x-3, y+3 )
        end

    end

end)

hook.Add("CalcView", "onehack.NoRecoil", function(vm)
    if not onehack.vars['HUD_ENABLED'] then return end
	if !LocalPlayer():IsValid() or !LocalPlayer():Alive() or LocalPlayer():GetViewEntity() != LocalPlayer() or LocalPlayer():InVehicle() then return end
	local tps = {}
    if onehack.vars['HUD_NOVISUALRECOIL'] then
        tps.angles = LocalPlayer():EyeAngles()
        return tps
    end
end)

onehack.AntiAimAngle = Angle(0,0,0)
onehack.AntiAimFakeAngle = Angle(0,0,0)
onehack.fakeModelChams = NULL
onehack.fakeAAModelChams = NULL
onehack.FakeLaggModelChams = NULL

local function CopyPoseParams(pEntityFrom, pEntityTo)
    for i = 0, pEntityFrom:GetNumPoseParameters() - 1 do
        local flMin, flMax = pEntityFrom:GetPoseParameterRange(i)
        local sPose = pEntityFrom:GetPoseParameterName(i)
        pEntityTo:SetPoseParameter(sPose, math.Remap(pEntityFrom:GetPoseParameter(sPose), 0, 1, flMin, flMax))
    end
end

function onehack.DrawFakeAngle()
    if(onehack.fakeModelChams == NULL) then
        onehack.fakeModelChams = ClientsideModel(LocalPlayer():GetModel(), 1)
        onehack.fakeModelChams.cs_filter = true
    end
    onehack.fakeModelChams:SetNoDraw(true)
    onehack.fakeModelChams:SetSequence(LocalPlayer():GetSequence())
    onehack.fakeModelChams:SetCycle(LocalPlayer():GetCycle())
        
    onehack.fakeModelChams:SetModel(LocalPlayer():GetModel())
    onehack.fakeModelChams:SetPos(LocalPlayer():GetPos())
        
    CopyPoseParams(LocalPlayer(), onehack.fakeModelChams)

    onehack.fakeModelChams:SetPoseParameter("aim_pitch", onehack.AntiAimAngle.x)
    onehack.fakeModelChams:SetPoseParameter("head_pitch", onehack.AntiAimAngle.x)
    onehack.fakeModelChams:SetPoseParameter("head_yaw", onehack.AntiAimAngle.y)
    onehack.fakeModelChams:SetPoseParameter("aim_yaw", onehack.AntiAimAngle.y)
        
    onehack.fakeModelChams:InvalidateBoneCache()
    onehack.fakeModelChams:SetRenderAngles(Angle(0, onehack.AntiAimAngle.y, 0))
    cam.Start3D()
        if(onehack.fakeModelChams:IsValid()) then
            render.SuppressEngineLighting(true)     
            onehack.fakeModelChams:SetRenderMode(RENDERMODE_TRANSALPHA)
            render.MaterialOverride(onehack.chamsHMaterialZ)
            render.SetColorModulation( onehack.vars['COLOR_CHAMS_PLAYER_REALAA'].r/255,onehack.vars['COLOR_CHAMS_PLAYER_REALAA'].g/255,onehack.vars['COLOR_CHAMS_PLAYER_REALAA'].b/255 )

            render.SetBlend(onehack.vars['COLOR_CHAMS_PLAYER_REALAA'].a/255)

            onehack.fakeModelChams:DrawModel()

            render.SetBlend(1)

            render.SetColorModulation( 1,1,1 )

            render.SuppressEngineLighting(false) 
        end
    cam.End3D()
end

local alpha = 1;
local plus_or_minus = true;
function onehack.DrawFakeAAAngle()
    if(onehack.fakeAAModelChams == NULL) then
        onehack.fakeAAModelChams = ClientsideModel(LocalPlayer():GetModel(), 1)
        onehack.fakeAAModelChams.cs_filter = true
    end
    onehack.fakeAAModelChams:SetNoDraw(true)
    onehack.fakeAAModelChams:SetSequence(LocalPlayer():GetSequence())
    onehack.fakeAAModelChams:SetCycle(LocalPlayer():GetCycle())
        
    onehack.fakeAAModelChams:SetModel(LocalPlayer():GetModel())
    onehack.fakeAAModelChams:SetPos(LocalPlayer():GetPos())
        
    CopyPoseParams(LocalPlayer(),onehack.fakeAAModelChams)

    onehack.fakeAAModelChams:SetPoseParameter("aim_pitch", onehack.AntiAimFakeAngle.x)
    onehack.fakeAAModelChams:SetPoseParameter("head_yaw", onehack.AntiAimFakeAngle.y)
    onehack.fakeAAModelChams:SetPoseParameter("head_pitch", onehack.AntiAimFakeAngle.x)
    onehack.fakeAAModelChams:SetPoseParameter("aim_yaw", onehack.AntiAimFakeAngle.y)
        
    onehack.fakeAAModelChams:InvalidateBoneCache()
    onehack.fakeAAModelChams:SetRenderAngles(Angle(0, onehack.AntiAimFakeAngle.y, 0))
    cam.Start3D()
        if(onehack.fakeAAModelChams:IsValid()) then
            render.SuppressEngineLighting(true)     
            onehack.fakeAAModelChams:SetRenderMode(RENDERMODE_TRANSALPHA)
            render.MaterialOverride(onehack.chamsHMaterialZ)
            render.SetColorModulation( onehack.vars['COLOR_CHAMS_PLAYER_AA'].r/255,onehack.vars['COLOR_CHAMS_PLAYER_AA'].g/255,onehack.vars['COLOR_CHAMS_PLAYER_AA'].b/255 )

            if alpha <= 0 then
                plus_or_minus = !plus_or_minus;
            elseif alpha >= 0.5 then
                plus_or_minus = !plus_or_minus;
            end
            if plus_or_minus then
                alpha = alpha - 0.005
            else
                alpha = alpha + 0.005
            end
            alpha = math.Clamp(alpha, 0, 0.5);
    
            render.SetBlend(alpha)

            onehack.fakeAAModelChams:DrawModel()

            render.SetBlend(1)

            render.SetColorModulation( 1,1,1 )

            render.SuppressEngineLighting(false) 
        end
    cam.End3D()
end

local alpha2 = 1;
local plus_or_minus2 = true;
function onehack.DrawFakeLagg()
    if(onehack.FakeLaggModelChams == NULL) then
        onehack.FakeLaggModelChams = ClientsideModel(LocalPlayer():GetModel(), 1)
        onehack.FakeLaggModelChams.cs_filter = true
    end
    onehack.FakeLaggModelChams:SetNoDraw(true)
    if bSendPacket then
        onehack.FakeLaggModelChams:SetSequence(LocalPlayer():GetSequence())
        onehack.FakeLaggModelChams:SetCycle(LocalPlayer():GetCycle())
        
        onehack.FakeLaggModelChams:SetModel(LocalPlayer():GetModel())
        onehack.FakeLaggModelChams:SetPos(LocalPlayer():GetPos())
        
        CopyPoseParams(LocalPlayer(),onehack.FakeLaggModelChams)
        
        onehack.FakeLaggModelChams:InvalidateBoneCache()
        onehack.FakeLaggModelChams:SetRenderAngles(Angle(0, LocalPlayer():GetAngles().y, 0))
    end
    cam.Start3D()
        if(onehack.FakeLaggModelChams:IsValid()) then
            render.SuppressEngineLighting(true)     
            onehack.FakeLaggModelChams:SetRenderMode(RENDERMODE_TRANSALPHA)
            render.MaterialOverride(onehack.chamsHMaterialZ)
            render.SetColorModulation( onehack.vars['COLOR_CHAMS_PLAYER_FAKE'].r/255,onehack.vars['COLOR_CHAMS_PLAYER_FAKE'].g/255,onehack.vars['COLOR_CHAMS_PLAYER_FAKE'].b/255)

            if alpha2 <= 0 then
                plus_or_minus2 = !plus_or_minus2;
            elseif alpha2 >= 0.5 then
                plus_or_minus2 = !plus_or_minus2;
            end
            if plus_or_minus2 then
                alpha2 = alpha2 - 0.005
            else
                alpha2 = alpha2 + 0.005
            end
            alpha2 = math.Clamp(alpha2, 0, 0.5);
    
            render.SetBlend(alpha2)

            onehack.FakeLaggModelChams:DrawModel()

            render.SetBlend(1)

            render.SetColorModulation( 1,1,1 )

            render.SuppressEngineLighting(false) 
        end
    cam.End3D()
end

hook.Add('RenderScreenspaceEffects','onehack.Chams',function()
    if onehack.vars['AIMBOT_ANTIAIM_ENABLED'] then
        if onehack.vars['AIMBOT_ANTIAIM_AACHAMS'] and onehack.vars['HUD_TPC'] then
            onehack.DrawFakeAngle()
        end
        if onehack.vars['AIMBOT_ANTIAIM_FAKELAGG'] and onehack.vars['HUD_TPC'] and LocalPlayer():GetVelocity():Length() > 50 then
            onehack.DrawFakeLagg()
        end
        if onehack.vars['AIMBOT_ANTIAIM_FAACHAMS'] and onehack.vars['HUD_TPC'] then
            onehack.DrawFakeAAAngle()
        end
    end
    if(onehack.vars['CPLAYER_ENABLED']) then
        for k,v in pairs(player.GetAll()) do
            if (v == LocalPlayer() and onehack.vars['CPLAYER_SELFENABLED']) or v ~= LocalPlayer() then
                if onehack.vars['CPLAYER_ENABLED_INVISIBLE'] then
                    onehack.Chams(v,true,onehack.vars['COLOR_CHAMS_PLAYER_INVISIBLE'])
                end
                if onehack.vars['CPLAYER_ENABLED_VISIBLE'] and ply:IsDormant() then
                    onehack.Chams(v,false,onehack.vars['COLOR_CHAMS_PLAYER_VISIBLE'])
                end
            end
        end
    end

    if(onehack.vars['CPROPS_ENABLED']) then
        for k,v in pairs(ents.FindByClass( "prop_*" )) do
            if onehack.vars['CPROPS_ENABLED_INVISIBLE'] then
                onehack.Chams(v,true,onehack.vars['COLOR_CHAMS_PROPS_INVISIBLE'])
            end
            if onehack.vars['CPROPS_ENABLED_VISIBLE'] then
                onehack.Chams(v,false,onehack.vars['COLOR_CHAMS_PROPS_VISIBLE'])
            end
        end
    end

end)

hook.Add("PreDrawViewModel", "onehack.Chams", function(vm)
	if(onehack.vars['CPLAYER_HANDCHAMS'] and onehack.vars['CPLAYER_ENABLED']) then
        if(!vm) then return; end
        render.SetLightingMode(2);
        for k,v in next, vm:GetMaterials() do
            if(v:find("v_hands")) then
                render.MaterialOverrideByIndex(k - 1, onehack.chamsHMaterialZ);
            else
                render.MaterialOverrideByIndex(k - 1, CreateMaterial("ViewModel_1", "VertexLitGeneric", {
                    ["$basetexture"] = "models/debug/debugwhite",
                    ["$model"] = 1,
                    ["$ignorez"] = 0,
                    ["vertexcolor"] = 1,
                    ["$color2"] = "{"..onehack.vars['COLOR_CHAMS_HANDS'].r.." "..onehack.vars['COLOR_CHAMS_HANDS'].g.." "..onehack.vars['COLOR_CHAMS_HANDS'].b.."}"
                })
                )
            end
        end
    else
        if(!vm) then return; end
        render.SetLightingMode(0);
    end
end)

hook.Add("PostPlayerDraw", "onehack.ChamsFIX", function(vm)
	if(!vm) then return; end
    render.SetLightingMode(0)
    render.SuppressEngineLighting(false)
end)

hook.Add("PostDrawViewModel", "onehack.ChamsFIX", function(vm)
	if(!vm) then return; end
	render.SetLightingMode(0)
	for k,v in next, vm:GetMaterials() do
		render.MaterialOverrideByIndex(k - 1, nil)
	end
end)

hook.Add("Think",'onehack.DLights',function()
    if(!onehack.vars['GPLAYER_ENABLED']) then return end
    if onehack.vars['GPLAYER_DYNAMICLIGHT'] then
        for k,v in pairs(player.GetAll()) do
            if v:IsValid() and v:Alive() then
                onehack.DynamicLights(v,onehack.vars['COLOR_LIGHT'])
            end
        end
    end

end)

hook.Add("PreDrawHalos",'onehack.Halos',function()
    if onehack.vars['GPLAYER_ENABLED_VISIBLE'] and onehack.vars['GPLAYER_ENABLED'] then
        halo.Add(player.GetAll(), onehack.vars['COLOR_GLOW_PLAYER'], 2, 2, 2, true, onehack.vars['GPLAYER_ENABLED_INVISIBLE'])
    end

    if onehack.vars['GPROPS_ENABLED_VISIBLE'] and onehack.vars['GPROPS_ENABLED'] then
        halo.Add(ents.FindByClass( "prop_*" ), onehack.vars['COLOR_GLOW_PROPS'], 2, 2, 2, true, onehack.vars['GPROPS_ENABLED_INVISIBLE'])
    end

end)


onehack.CurTarget = false

local function max(t, fn)
    if #t == 0 then return nil, nil end
    local key, value = 1, t[1]
    for i = 2, #t do
        if fn(value, t[i]) then
            key, value = i, t[i]
        end
    end
    return key, value
end

function onehack.AimTarget()

    local dist = 0

    if not onehack.CurTarget then

        for k,ply in pairs(player.GetAll()) do

            if onehack.Visible(ply) and onehack.InFOV(ply) and ply ~= LocalPlayer() and ( onehack.vars['AIMBOT_LEGIT_IGNORETEAM'] and ply:Team() ~= LocalPlayer():Team() or not onehack.vars['AIMBOT_LEGIT_IGNORETEAM'] ) and ( onehack.vars['AIMBOT_LEGIT_IGNOREADMINS'] and ply:IsAdmin() or not onehack.vars['AIMBOT_LEGIT_IGNOREADMINS'] ) and ( onehack.vars['AIMBOT_LEGIT_IGNORENOCLIP'] and ply:GetMoveType() ~= 8 or not onehack.vars['AIMBOT_LEGIT_IGNORENOCLIP'] ) then

                if dist < ply:GetPos():Distance(LocalPlayer():GetPos()) then

                    dist = ply:GetPos():Distance(LocalPlayer():GetPos())

                    onehack.CurTarget = ply

                end

            end

        end

    end

    if onehack.CurTarget and onehack.CurTarget:IsValid() and onehack.CurTarget:Alive() and onehack.Visible(onehack.CurTarget) and onehack.InFOV(onehack.CurTarget) then
        -- ya xui znaet
    else
        onehack.CurTarget = false
    end

end

local PrimeSala = {}

function onehack.AimBotLogic()
    if IsValid(onehack.CurTarget) and onehack.CurTarget:IsPlayer() and not onehack.InFOV(onehack.CurTarget) then
        onehack.CurTarget = false
    end

    if LocalPlayer():GetActiveWeapon():IsValid() and LocalPlayer():GetActiveWeapon().Primary then
        if not PrimeSala[LocalPlayer():GetActiveWeapon():GetClass()] then
            PrimeSala[LocalPlayer():GetActiveWeapon():GetClass()] = {
                KickUp = LocalPlayer():GetActiveWeapon().Primary.KickUp,
                KickDown = LocalPlayer():GetActiveWeapon().Primary.KickDown,
                KickHorizontal = LocalPlayer():GetActiveWeapon().Primary.KickHorizontal,
                Spread = LocalPlayer():GetActiveWeapon().Primary.Spread,
            }
        end
        if onehack.vars['AIMBOT_LEGIT_RECOIL'] then
            LocalPlayer():GetActiveWeapon().Primary.KickUp = 0
            LocalPlayer():GetActiveWeapon().Primary.KickDown = 0
            LocalPlayer():GetActiveWeapon().Primary.KickHorizontal = 0
        else
            LocalPlayer():GetActiveWeapon().Primary.KickUp = PrimeSala[LocalPlayer():GetActiveWeapon():GetClass()].KickUp
            LocalPlayer():GetActiveWeapon().Primary.KickDown = PrimeSala[LocalPlayer():GetActiveWeapon():GetClass()].KickDown
            LocalPlayer():GetActiveWeapon().Primary.KickHorizontal = PrimeSala[LocalPlayer():GetActiveWeapon():GetClass()].KickHorizontal
        end

        if onehack.vars['AIMBOT_LEGIT_SPREAD'] then
            LocalPlayer():GetActiveWeapon().Primary.Spread = 0
        else
            LocalPlayer():GetActiveWeapon().Primary.Spread = PrimeSala[LocalPlayer():GetActiveWeapon():GetClass()].Spread
        end
        
    end

    if onehack.vars['AIMBOT_LEGIT_ENABLED'] and onehack.vars['AIMBOT_LEGIT_SLIENT'] then
        onehack.AimTarget()
        local tg = onehack.CurTarget
        if tg and tg:GetFriendStatus()!="friend" then
            targetlerp2 = LocalPlayer():EyeAngles()
            local aids2 = onehack.PrepareForAStomping( tg ) - LocalPlayer():GetShootPos()
            aids2 = aids2:Angle()
            if onehack.vars['AIMBOT_LEGIT_SMOOTH'] > 0 then
                targetlerp2 = LerpAngle(FrameTime() * ((1.1*10)-(onehack.vars['AIMBOT_LEGIT_SMOOTH']*10)), targetlerp2, aids2)
                aids2 = targetlerp2
            end
            LocalPlayer():SetEyeAngles(aids2) 
        end
    end
    
end

local emt = FindMetaTable("Entity");

local oFireBullets = oFireBullets || emt.FireBullets;
local cones = {};

function emt.FireBullets(ply, data)
	local wep = ply:GetActiveWeapon():GetClass();
	if (-data.Spread != cones[wep]) then
		cones[wep] = -data.Spread;
	end
	return oFireBullets(ply, data);
end

local function PredictSpread(cmd, ang)
    local wep = LocalPlayer():GetActiveWeapon();
    if (!IsValid(wep) || !cones[wep:GetClass()]) then return ang; end
	wep = wep:GetClass();
    local ang = (dickwrap.Predict(cmd, ang:Forward(), cones[wep])):Angle();
	ang.x, ang.y = math.NormalizeAngle(ang.x), math.NormalizeAngle(ang.y);
	return ang;
end

local waitoiiiinsdf = CurTime()
function onehack.AutoFire(cmd)
    local target = LocalPlayer():GetEyeTrace().Entity
    if target and target:IsValid() and target:IsPlayer() and (onehack.vars['TRIGGER_ENABLED'] or onehack.vars['AIMBOT_LEGIT_AUTOSHOT']) then
        cmd:SetButtons(bit.bor(cmd:GetButtons(), 1))
    end
    local target2 = onehack.CurTarget
    if target2 and target2:IsValid() and target2:IsPlayer() and onehack.vars['AIMBOT_LEGIT_AUTOSHOT'] then
        cmd:SetButtons(bit.bor(cmd:GetButtons(), 1))
    end
end

hook.Add("CreateMove", "onehack.Trigger", onehack.AutoFire)
hook.Add("Think","onehack.AimbotL",onehack.AimBotLogic)

local real_switch = 0
local real_plus = true
local fake_switch = 0
local fake_plus = true
bSendPacket = true
onehack.fakeangles = Angle(0,0,0)
function onehack.AntiAim(cmd)
    if not onehack.CurTarget then
        if real_switch <= -(onehack.vars['AIMBOT_ANTIAIM_SWITCHRANGE']*100) then
            real_plus = !real_plus;
        elseif real_switch >= onehack.vars['AIMBOT_ANTIAIM_SWITCHRANGE']*010 then
            real_plus = !real_plus;
        end
        if real_plus then
            real_switch = real_switch + onehack.vars['AIMBOT_ANTIAIM_SWITCHSPEED'] * 100
        else
            real_switch = real_switch - onehack.vars['AIMBOT_ANTIAIM_SWITCHSPEED'] * 100
        end

        if fake_switch <= -(onehack.vars['AIMBOT_ANTIAIM_SWITCHRANGE']*100) then
            fake_plus = !fake_plus;
        elseif fake_switch >= onehack.vars['AIMBOT_ANTIAIM_SWITCHRANGE']*100 then
            fake_plus = !fake_plus;
        end
        if fake_plus then
            fake_switch = fake_switch + onehack.vars['AIMBOT_ANTIAIM_FAKE_SWITCHSPEED'] * 100
        else
            fake_switch = fake_switch - onehack.vars['AIMBOT_ANTIAIM_FAKE_SWITCHSPEED']* 100
        end

        local yaw = 0
        local pich = 0 

        local fakeyaw = 0
        local fakepich = 0 

        if onehack.vars['AIMBOT_ANTIAIM_PICH'] == "Jitter" then
            pich = math.random(-60, 60)
        elseif onehack.vars['AIMBOT_ANTIAIM_PICH'] == "Switch" then
            pich = pich + anglex/2
        elseif onehack.vars['AIMBOT_ANTIAIM_PICH'] == "Down" then
            pich = 80
        elseif onehack.vars['AIMBOT_ANTIAIM_PICH'] == "Up" then
            pich = -80
        elseif onehack.vars['AIMBOT_ANTIAIM_PICH'] == "Disabled" then
            pich = onehack.fakeangles.x
        end

        if onehack.vars['AIMBOT_ANTIAIM_YAW'] == "Jitter" then
            yaw = math.random(-60, 60)
        elseif onehack.vars['AIMBOT_ANTIAIM_YAW'] == "Switch" then
            yaw = yaw + real_switch
        elseif onehack.vars['AIMBOT_ANTIAIM_YAW'] == "Backward" then
            yaw = onehack.fakeangles.y-180
        elseif onehack.vars['AIMBOT_ANTIAIM_YAW'] == "180" then
            yaw = onehack.fakeangles.y
        elseif onehack.vars['AIMBOT_ANTIAIM_YAW'] == "Switch + Backward" then
            yaw = onehack.fakeangles.y-180 + real_switch
        elseif onehack.vars['AIMBOT_ANTIAIM_YAW'] == "Switch + 180" then
            yaw = onehack.fakeangles.y + real_switch
        elseif onehack.vars['AIMBOT_ANTIAIM_YAW'] == "Disabled" then
            yaw = onehack.fakeangles.y
        end
--------------------------------------------------------------------------------------
        if onehack.vars['AIMBOT_ANTIAIM_FAKE_PICH'] == "Jitter" then
            fakepich = math.random(-60, 60)
        elseif onehack.vars['AIMBOT_ANTIAIM_FAKE_PICH'] == "Switch" then
            fakepich = fakepich + anglex/2
        elseif onehack.vars['AIMBOT_ANTIAIM_FAKE_PICH'] == "Down" then
            fakepich = 80
        elseif onehack.vars['AIMBOT_ANTIAIM_FAKE_PICH'] == "Up" then
            fakepich = -80
        elseif onehack.vars['AIMBOT_ANTIAIM_FAKE_PICH'] == "Disabled" then
            fakepich = onehack.fakeangles.x
        end

        if onehack.vars['AIMBOT_ANTIAIM_FAKE_YAW'] == "Jitter" then
            fakeyaw = math.random(-60, 60)
        elseif onehack.vars['AIMBOT_ANTIAIM_FAKE_YAW'] == "Switch" then
            fakeyaw = fakeyaw + fake_switch
        elseif onehack.vars['AIMBOT_ANTIAIM_FAKE_YAW'] == "Backward" then
            fakeyaw = onehack.fakeangles.y-180
        elseif onehack.vars['AIMBOT_ANTIAIM_FAKE_YAW'] == "180" then
            fakeyaw = onehack.fakeangles.y
        elseif onehack.vars['AIMBOT_ANTIAIM_FAKE_YAW'] == "Switch + Backward" then
            fakeyaw = onehack.fakeangles.y-180 + fake_switch
        elseif onehack.vars['AIMBOT_ANTIAIM_FAKE_YAW'] == "Switch + 180" then
            fakeyaw = onehack.fakeangles.y + fake_switch
        elseif onehack.vars['AIMBOT_ANTIAIM_FAKE_YAW'] == "Disabled" then
            fakeyaw = onehack.fakeangles.y
        end

        if !bSendPacket then
            cmd:SetViewAngles(Angle(pich,yaw,0))
            onehack.AntiAimAngle = cmd:GetViewAngles()
        elseif bSendPacket then
            if onehack.vars['AIMBOT_ANTIAIM_FAKE_ENABLED'] then
                cmd:SetViewAngles(Angle(fakepich,fakeyaw,0))
                onehack.AntiAimFakeAngle = cmd:GetViewAngles()
            end
        end
        
    end
end
onehack.finishload = true