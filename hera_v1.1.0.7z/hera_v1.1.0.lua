--[[
	MOD/lua/abc.lua
	gCore | STEAM_0:0:7912954 <85.250.110.147:27005> | [28-09-13 10:26:52AM]
	===BadFile===
]]

-- hera v1.1 [Fixed to work in GMod 13]
-- if this gets leaked, I don't care much.
-- this will be released when GMod 13 comes out anyways.
if ( SERVER ) then AddCSLuaFile() return end
MsgN("Cock")
 
local Hera = {};
local Version = "2.3";
local RandomColor = Color(math.random(1,255),math.random(1,255),math.random(1,255),255)
-- Localizing commonly used functions for speed
 
for k,v in pairs(_G) do
        local k = v
 
end
 
require("cvar3")
local cvar2 = {}
cvar2.SetValue = function(var, value)
 
        GetConVar(var):SetValue(value)
       
end
 
chat.AddText(
Color(255,69,0,255), "[Hera]: ",
Color(0,255,0,255),"Player Authed: ",
Color(0,255,0,255),""..LocalPlayer():Nick" ","("..LocalPlayer():SteamID" ",")")
 
 
// thanks fr1kin i hate this too
 
 
chat.AddText(
Color(255,69,0,255), "[Hera]: ",
Color(100,100,100,255), "Modules Loaded");
 
chat.AddText(
Color(255,69,0,255), "[Hera]: ",
Color(100,100,100,255), "sv_cheats bypassed");
 
 
 
-- start of cvars
CreateClientConVar("hera_calcview",0,true,false)
CreateClientConVar("hera_esp_info",0,true,false)
CreateClientConVar("hera_esp_box",0,true,false)
CreateClientConVar("hera_esp_chams",0,true,false)
CreateClientConVar("hera_esp_health",0,true,false)
CreateClientConVar("hera_esp_2dbox",0,true,false)
CreateClientConVar("hera_esp_3dbox",0,true,false)
CreateClientConVar("hera_esp_weapons",0,true,false)
CreateClientConVar("hera_misc_crosshair",0,true,false)
CreateClientConVar("hera_misc_bhop",0,true,false)
CreateClientConVar("hera_misc_fullbright",0,true,false)
CreateClientConVar("hera_misc_status",0,true,false)
CreateClientConVar("hera_misc_spammessage","SpamMessage",true,false)
CreateClientConVar("hera_misc_chatspam",0,true,false)
CreateClientConVar("hera_misc_logips",0,true,false)
CreateClientConVar("hera_aim_spinbot",0,true,false)
CreateClientConVar("hera_esp_tracer",0,true,false)
CreateClientConVar("hera_aim_silent",0,true,false)
CreateClientConVar("hera_aim_anti",0,true,false)
CreateClientConVar("hera_aim_toggle",0,true,false)
CreateClientConVar("hera_speedhack_speed",3,true,false)
CreateClientConVar("hera_esp_info_color_r",0,true,false)
CreateClientConVar("hera_esp_info_color_g",0,true,false)
CreateClientConVar("hera_esp_info_color_b",0,true,false)
CreateClientConVar("hera_esp_box_color_r",0,true,false)
CreateClientConVar("hera_esp_box_color_g",0,true,false)
CreateClientConVar("hera_esp_box_color_b",0,true,false)
 
surface.PlaySound("buttons/button19.wav")
chat.AddText(
Color(255,69,0,255), "[Hera]: ",
Color(100,100,100,255), "Loaded")
chat.AddText(
Color(255,69,0,255), "[Hera]: ",
Color(100,100,100,255), "Current Version: "..Version.."")
       
       
       
cvar2.SetValue("sv_cheats","1")
 
local function IsisCreateHook(Type,Function)
Name = tostring(math.random(1,500)..math.random(1,500)..math.random(1,500)..math.random(1,500)..math.random(1,500)..math.random(1,500)..math.random(1,500))
return hook.Add(Type,Name,Function)
end
 
local function HeraMakeMat()   
local Texture = {
["$basetexture"] = "models/debug/debugwhite",
["$model"]       = 1,
["$translucent"] = 1,
["$alpha"]       = 1,
["$nocull"]      = 1,
["$ignorez"]     = 1
}
local material = CreateMaterial( "hera_solid", "VertexLitGeneric", Texture )
return material
end
 
local function Chams()
local Div = (1 / 255)
local Div2 = ( 0 / 0 )
local m = HeraMakeMat()
if GetConVarNumber("hera_esp_chams") == 1 then
for k,v in pairs(player.GetAll()) do
if IsValid(v) and v:Health() > 0 and v:Team() != TEAM_SPECTATOR then
cam.Start3D(EyePos(),EyeAngles())
local TCol = team.GetColor(v:Team())
local Alpha2 = Color(0,0,0,255)
render.SuppressEngineLighting( true )
render.SetColorModulation( ( TCol.r * Div ), ( TCol.g * Div ), ( TCol.b * Div ), (Alpha2.a * Div2) )
render.MaterialOverride( m )
v:DrawModel()
render.SuppressEngineLighting( false )
render.SetColorModulation(1,1,1)
render.MaterialOverride( )
cam.End3D()
end
end
end
end
IsisCreateHook("RenderScreenspaceEffects",Chams)
 
local function Weapons()
if GetConVarNumber("hera_esp_weapons") == 1 then
for k, v in pairs( ents.GetAll() ) do
if IsValid( v ) then
if v:IsWeapon() && v:GetMoveType() != 0 then
if string.sub( v:GetClass(), 1, 7 ) == "weapon_" then
WeaponPos = v:EyePos():ToScreen()
draw.SimpleText( v:GetClass(), "TargetID", WeaponPos.x, WeaponPos.y, Color(0,255,0,255), TEXT_ALIGN_CENTER,
 
TEXT_ALIGN_CENTER )
end
end
end
end
end
end
IsisCreateHook("HUDPaint", Weapons)
 
function Crosshair() -- Thanks Sykranos
if GetConVarNumber("hera_misc_crosshair") == 1 then
surface.SetDrawColor(255,0,0,255)
surface.DrawLine(ScrW()/2, ScrH()/2, ScrW()/2 + 20, ScrH()/2)
surface.DrawLine(ScrW()/2 + 20, ScrH()/2, ScrW()/2 + 20, ScrH()/2 + 20)
surface.DrawLine(ScrW()/2 , ScrH()/2, ScrW()/2 - 20, ScrH()/2)
surface.DrawLine(ScrW()/2 - 20 , ScrH()/2, ScrW()/2 - 20, ScrH()/2 - 20)
surface.DrawLine(ScrW()/2, ScrH()/2, ScrW()/2, ScrH()/2 - 20)
surface.DrawLine(ScrW()/2, ScrH()/2 - 20, ScrW()/2 + 20, ScrH()/2 - 20)
surface.DrawLine(ScrW()/2, ScrH()/2, ScrW()/2, ScrH()/2 + 20)
surface.DrawLine(ScrW()/2, ScrH()/2 + 20, ScrW()/2 - 20, ScrH()/2 + 20)
end
end
IsisCreateHook("HUDPaint", Crosshair)
 
function ESP()
draw.RoundedBox( 8, -10, 0, 10000, 25, Color(255,255,255,100))
draw.SimpleTextOutlined( "Hera " .. "[Private]","Default",1250,5,Color(50,50,50,255),0,0,1,Color(255,69,0,255))
if GetConVarNumber("hera_esp_info") == 1 then
for k, v in pairs( player.GetAll() ) do
if( v:Alive() && v != LocalPlayer() ) then
local Pos = ( v:GetPos() + Vector( 0, 0, 170 ) ):ToScreen();
local Dist = v:GetPos():Distance(LocalPlayer():GetPos());
local wep = "Unknown"
local SteamID = v:SteamID()
local Team = v:Team()
if v:GetActiveWeapon() != nil then
if type(v:GetActiveWeapon()) == "Weapon" then
if v:GetActiveWeapon() and v:GetActiveWeapon():IsValid() then
wep = v:GetActiveWeapon():GetClass()
local InfoColor = Color(GetConVarNumber("hera_esp_info_color_r"),GetConVarNumber("hera_esp_info_color_g"),GetConVarNumber("hera_esp_info_color_b"),255)
draw.SimpleText(v:Name(), "TargetID", Pos.x, Pos.y, InfoColor, TEXT_ALIGN_CENTER )
draw.SimpleText("HP: " .. v:Health(), "TargetID", Pos.x, Pos.y + 12, InfoColor, TEXT_ALIGN_CENTER )
draw.SimpleText("Distance: " .. math.floor(Dist), "TargetID", Pos.x, Pos.y + 22, InfoColor, TEXT_ALIGN_CENTER);
draw.SimpleText("Weapon: " .. wep, "TargetID", Pos.x, Pos.y + 32, InfoColor, TEXT_ALIGN_CENTER );
draw.SimpleText("Team: " ..Team, "TargetID", Pos.x, Pos.y + 42, InfoColor,TEXT_ALIGN_CENTER);
draw.SimpleText("SteamID: " ..SteamID, "TargetID", Pos.x, Pos.y + 52, InfoColor,TEXT_ALIGN_CENTER);
if v:IsAdmin() then
draw.SimpleText("[ADMIN]", "TabLarge", Pos.x, Pos.y - 12, Color(0,255,0,255), TEXT_ALIGN_CENTER );
end
if v:GetFriendStatus() == "friend" then
draw.SimpleText("-Friend-", "TabLarge", Pos.x, Pos.y - 22, Color(0,255,0,255), TEXT_ALIGN_CENTER );
end
end
end
end
end
end
end
end
IsisCreateHook("HUDPaint", ESP)
 
function BarrelHack()
for k, v in pairs( player.GetAll() ) do
if( v:Alive() && v != LocalPlayer() ) then
if GetConVarNumber("hera_esp_tracer") == 0 then return; end
local ViewModel = LocalPlayer():GetViewModel()
local pos = v:GetBonePosition(v:LookupBone("ValveBiped.Bip01_Head1"))
local Attach = ViewModel:LookupAttachment("1")
local Div = (1 / 255)
if( !LocalPlayer():Alive() || LocalPlayer():GetActiveWeapon() == NULL ) then return; end
if ( Attach == 0 ) then Attach = ViewModel:LookupAttachment("muzzle") end
cam.Start3D( EyePos(), EyeAngles() )
render.SetMaterial(Material("tripmine_laser"))
render.DrawBeam( ViewModel:GetAttachment( Attach ).Pos, pos, 10,0,0,team.GetColor( v:Team()))
cam.End3D()
end
end
end
IsisCreateHook("HUDPaint", Barrelhack)
 
function BarrelHackClient()
if GetConVarNumber("hera_esp_tracer") == 0 then return end
local ViewModel2 = LocalPlayer():GetViewModel()
local Attach2 = ViewModel2:LookupAttachment("1")
if( !LocalPlayer():Alive() || LocalPlayer():GetActiveWeapon() == NULL ) then return; end
if ( Attach2 == 0 ) then Attach2 = ViewModel2:LookupAttachment("muzzle") end
cam.Start3D( EyePos(), EyeAngles() )
render.SetMaterial( Material("tripmine_laser"))
render.DrawBeam( ViewModel2:GetAttachment( Attach2 ).Pos, LocalPlayer():GetEyeTrace().HitPos, 5, 0, 0, Color(0,255,0,255))
cam.End3D()
end
IsisCreateHook("RenderScreenspaceEffects", BarrelHackClient)
 
function Health()
if GetConVarNumber("hera_esp_health") == 1 then
for k, v in pairs(ents.GetAll()) do
if IsValid( v ) then
if v ~= LocalPlayer() then
if v:IsPlayer() or v:IsNPC() then
local pos = ( v:GetPos() ):ToScreen()
if v:Health() >= 75 then
HPColor = Color( 0,255,0,255)
elseif v:Health() >= 35 and v:Health() < 75 then
HPColor = Color(255,255,0,255)
elseif v:Health() < 35 then
HPColor = Color(255,0,0,255)
end
draw.RoundedBox( 0, pos.x-17, pos.y+4, 42, 6,Color(0,0,0,255))
draw.RoundedBox( 0, pos.x-16, pos.y+5, 0.4 * math.Clamp( v:Health(), 1, 100 ), 4,HPColor)
end
end
end
end
end
end
IsisCreateHook("HUDPaint", Health)
 
function TwoDBox()
if GetConVarNumber("hera_esp_2dbox") == 1 then
cam.Start3D(EyePos(), EyeAngles());
for k, ply in pairs(player.GetAll()) do
if( ply:Alive() && ( IsValid(ply) && ply != LocalPlayer() )) then
local pos = ply:GetPos();
local width = 32;
local height = 80;
local scale = 1;
local BoxColor = Color(GetConVarNumber("hera_esp_box_color_r"),GetConVarNumber("hera_esp_box_color_g"),GetConVarNumber("hera_esp_box_color_b"),255)
local ang = EyeAngles();
ang.p = ang.p - 90;
pos = pos - (ang:Right() * (width / 2))
cam.Start3D2D(pos, ang, (1 / scale));
surface.SetDrawColor(BoxColor)
surface.DrawOutlinedRect(0, 0, (height * scale), (width * scale));
cam.End3D2D();
end
end
cam.End3D();
end
end
IsisCreateHook("HUDPaint", TwoDBox)
 
 
local function DrawBoundingBox() -- thanks Anthr4x
if GetConVarNumber("hera_esp_3dbox") == 1 then
cam.Start3D(EyePos(), EyeAngles());
for k, ply in pairs(player.GetAll()) do
if ( ply:Alive() && ( IsValid(ply) && ply != LocalPlayer() )) then
local ang = ply:EyeAngles();
ang.p = 0;
ang.r = 0;
local pos = ply:GetPos();
local width = 32;
local height = 74;
local scale = 2;
local BoxColor = Color(GetConVarNumber("hera_esp_box_color_r"),GetConVarNumber("hera_esp_box_color_g"),GetConVarNumber("hera_esp_box_color_b"),255)
 
local ang1 = Angle(ang.p, ang.y, ang.r);
local pos1 = pos;
pos1 = pos1 - (ang1:Forward() * (width / 2));
pos1 = pos1 - (ang1:Right() * (width / 2));
cam.Start3D2D(pos1, ang1, (1 / scale));
surface.SetDrawColor(BoxColor);
surface.DrawOutlinedRect(0, 0, (width * scale), (width * scale));
surface.SetDrawColor(Color(0, 0, 0, 0));
surface.DrawRect(0, 0, (width * scale), (width * scale));
cam.End3D2D();
-- Top Face
local ang2 = Angle(ang.p, ang.y, ang.r);
local pos2 = pos;
pos2 = pos2 - (ang2:Forward() * (width / 2));
pos2 = pos2 - (ang2:Right() * (width / 2));
pos2 = pos2 + (ang2:Up() * (height));
cam.Start3D2D(pos2, ang2, (1 / scale));
surface.SetDrawColor(BoxColor);
surface.DrawOutlinedRect(0, 0, (width * scale), (width * scale));
surface.SetDrawColor(Color(0, 0, 0, 0));
surface.DrawRect(0, 0, (width * scale), (width * scale));
cam.End3D2D();
 
-- Front Face
local ang3 = Angle(ang.p + 90, ang.y, ang.r);
local pos3 = pos;
pos3 = pos3 - (ang3:Forward() * height);
pos3 = pos3 - (ang3:Right() * (width / 2));
pos3 = pos3 + (ang3:Up() * (width / 2));
cam.Start3D2D(pos3, ang3, (1 / scale));
surface.SetDrawColor(BoxColor)
surface.DrawOutlinedRect(0, 0, (height * scale), (width * scale));
surface.SetDrawColor(Color(0, 0, 0, 0));
surface.DrawRect(0, 0, (height * scale), (width * scale));
cam.End3D2D();
 
                                        -- Back Face
local ang4 = Angle(ang.p + 90, ang.y, ang.r);
local pos4 = pos;
pos4 = pos4 - (ang4:Forward() * height);
pos4 = pos4 - (ang4:Right() * (width / 2));
pos4 = pos4 - (ang4:Up() * (width / 2));
cam.Start3D2D(pos4, ang4, (1 / scale));
surface.SetDrawColor(BoxColor);
surface.DrawOutlinedRect(0, 0, (height * scale), (width * scale));
surface.SetDrawColor(Color(0, 0, 0, 0));
surface.DrawRect(0, 0, (height * scale), (width * scale));
cam.End3D2D();
 
-- Right Face
local ang5 = Angle(ang.p + 90, ang.y, ang.r + 90);
local pos5 = pos;
pos5 = pos5 - (ang5:Forward() * height);
pos5 = pos5 - (ang5:Right() * (width / 2));
pos5 = pos5 - (ang5:Up() * (width / 2));
cam.Start3D2D(pos5, ang5, (1 / scale));
surface.SetDrawColor(BoxColor);
surface.DrawOutlinedRect(0, 0, (height * scale), (width * scale));
surface.SetDrawColor(Color(0, 0, 0, 0));
surface.DrawRect(0, 0, (height * scale), (width * scale));
cam.End3D2D();
-- Left Face
local ang6 = Angle(ang.p + 90, ang.y, ang.r + 90);
local pos6 = pos;
pos6 = pos6 - (ang6:Forward() * height);
pos6 = pos6 - (ang6:Right() * (width / 2));
pos6 = pos6 + (ang6:Up() * (width / 2));
cam.Start3D2D(pos6, ang6, (1 / scale));
surface.SetDrawColor(BoxColor);
surface.DrawOutlinedRect(0, 0, (height * scale), (width * scale));
surface.SetDrawColor(Color(0, 0, 0, 0));
surface.DrawRect(0, 0, (height * scale), (width * scale));
cam.End3D2D();
end
end
cam.End3D();
end
end
IsisCreateHook("RenderScreenspaceEffects", DrawBoundingBox)
 
function Dead()
if GetConVarNumber("hera_esp_info") == 1 then
for k, v in pairs( player.GetAll() ) do
if v != LocalPlayer() then
local Pos = ( v:GetPos() + Vector( 0, 0, 100 ) ):ToScreen();
if v:Health() < 1 then
draw.SimpleText( "*Dead* (" .. v:Nick() .. ")", "TargetID", Pos.x, Pos.y - 12, Color( 255, 0, 0, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
end
end
end
end
end
IsisCreateHook("HUDPaint", Dead)
 
function Bunnyhop()
if GetConVarNumber("hera_misc_bhop") == 1 then
if input.IsKeyDown( KEY_SPACE ) then
if LocalPlayer():IsOnGround() then
RunConsoleCommand("+Jump")
timer.Create("Bhop",0.01, 0 ,function() RunConsoleCommand("-Jump") end)
end
end
end
end  
IsisCreateHook("Think", Bunnyhop)
 
function ChatSpam()
local SpamMessage = GetConVarString("hera_misc_spammessage")
if GetConVarNumber("hera_misc_chatspam") == 1 then
RunConsoleCommand("say",""..SpamMessage.."")
end
end
IsisCreateHook("Think", ChatSpam)
 
-- gotta go fast
timer.Create("SpeedHake",2,1,function()
concommand.Add("+Hera_Speed" , function() cvar2.SetValue("sv_Cheats","1") cvar2.SetValue("Host_TimeScale",tostring(GetConVarNumber("Hera_Speedhack_Speed"))) end)
concommand.Add("-Hera_Speed", function() cvar2.SetValue("Host_TimeScale","1") end)
end)
 
function ToggleAim()
if GetConVarNumber("hera_aim_toggle") == 1 then
Aimon = 1
end
end
IsisCreateHook("Think", ToggleAim)
 
 
Spins = {{ pitch = 360 , yaw = -180 , roll = 180 },{ pitch = -360 , yaw = 180 , roll = -180 }}
XAXE = 0
YAXE = 0
Blickrichtung = Angle( 0 , 0 , 0 )
function Spinbot( cmd )
if GetConVarNumber("hera_aim_spinbot") == 0 then return end;
if Aimon == 1 then return end;
local PlayerView = cmd:GetViewAngles()
local pitch = PlayerView.p
local yaw = PlayerView.y
local roll = PlayerView.r
cmd:SetViewAngles(Angle(0,math.random(0,270),math.random(0,180)))
Blickrichtung = cmd:GetViewAngles()
if(Blickrichtung.y < 270 ) then
elseif(Blickrichtung.y > 270 ) then      
end
end
IsisCreateHook("CreateMove", Spinbot)
 
function Mouse( cmd )
XAXE = cmd:GetMouseX()
YAXE = cmd:GetMouseY()*-1
if YAXE or XAXE > 0 then
end
end
IsisCreateHook("CreateMove", Mouse)
value = 180
value2 = 180
function NormaliziseView(ply, pos, angles, fov)
if GetConVarNumber("hera_aim_spinbot") == 0 then return end
local x = gui.MouseX() * - 1
local y = gui.MouseY()
value = value - YAXE
value2 = value2 - XAXE
local view = {}
view.origin = pos
view.angles = angles
view.angles.r = 0
view.angles.p = value
view.angles.y = value2
view.fov = fov
return view
end
IsisCreateHook("CalcView", NormaliziseView)
 
-- thanks Herahack ( I just needed a simple logger, didn't really care how i got it )
local function PlayerConnect( name, ip )
        if GetConVarNumber("hera_misc_logips") == 1 then
        surface.PlaySound("ambient/levels/canals/drip4.wav")
        chat.AddText(
        Color(255,69,0,255), "[Hera] ",
        Color(100,100,100,255), tostring( name .. "'s IP: " .. ip ) )
        end
end
IsisCreateHook("PlayerConnect", PlayerConnect)
       
-- aimbot (direct copy paste from isis)
local Tb  = table.Copy( file )
local Tbs = table.Copy( string )
local ClRcl = CreateClientConVar("Hera_aim_NoRecoil", 1 , true , false)
local ClAimSteam = CreateClientConVar("Hera_Aim_IgnoreSteam",0,true,false)
local ClFriendly = CreateClientConVar("Hera_aim_Friendlyfire",1,true,false)
local CLM = CreateClientConVar("Hera_aim_AutoShoot",1,true,false)
local ClOf = CreateClientConVar("Hera_Aim_Offset",0,true,false)
local ClType = CreateClientConVar("Hera_Aim_AimSpot","Eye",true,false)
local Uw = {}
local Mw = {}
local function PlyPos( ply )
local min = ply:OBBMins()
local max = ply:OBBMaxs()
       
local Spots = {
Vector( min.x, min.y, min.z ),
Vector( min.x, min.y, max.z ),
Vector( min.x, max.y, min.z ),
Vector( min.x, max.y, max.z ),
Vector( max.x, min.y, min.z ),
Vector( max.x, min.y, max.z ),
Vector( max.x, max.y, min.z ),
Vector( max.x, max.y, max.z )
}      
local minX = ScrW() * 2
local minY = ScrH() * 2
local maxX = 0
local maxY = 0
 
        for k,v in pairs( Spots ) do
        local ToScreen = ply:LocalToWorld( v ):ToScreen()
        minX = math.min( minX, ToScreen.x )
        minY = math.min( minY, ToScreen.y )
        maxX = math.max( maxX, ToScreen.x )
        maxY = math.max( maxY, ToScreen.y )
        end
        return minX, minY, maxX, maxY
end
concommand.Add("+Hera_Aim",function()
Aimon = 1
end)
 
concommand.Add("-Hera_Aim",function()
Aimon = 0
end)
 
function WeaponVector( value, typ )
        local s = ( -value )
       
        if ( typ == true ) then
                s = ( -value )
        elseif ( typ == false ) then
                s = ( value )
        else
                s = ( value )
        end
        return Vector( s, s, s )
end
 
local currentseed, cmd2, seed = currentseed || 0, 0, 0
local w, vecCone, valCone = "", Vector( 0, 0, 0 ), Vector( 0, 0, 0 )
 
local CustomCones       = {}
CustomCones.Weapons = {}
CustomCones.Weapons[ "weapon_pistol" ]          = WeaponVector( 0.0100, true )  // HL2 Pistol
CustomCones.Weapons[ "weapon_smg1" ]            = WeaponVector( 0.04362, true ) // HL2 SMG1
CustomCones.Weapons[ "weapon_ar2" ]                     = WeaponVector( 0.02618, true ) // HL2 AR2
CustomCones.Weapons[ "weapon_shotgun" ]         = WeaponVector( 0.08716, true ) // HL2 SHOTGUN
 
local NormalCones = { [ "weapon_cs_base" ] = true }
 
function GetCone( wep )
        local c = wep.Cone
       
        if ( !c && ( type( wep.Primary ) == "table" ) && ( type( wep.Primary.Cone ) == "number" ) ) then c =
 
wep.Primary.Cone end
        if ( !c ) then c = 0 end
        if ( type( wep.Base ) == "string" && NormalCones[ wep.Base ] ) then return c end
        if ( ( wep:GetClass() == "ose_turretcontroller" ) ) then return 0 end
        return c || 0
end
 
local function AimSpot(targ)
        if GetConVarString("Hera_Aim_AimSpot") == "Eye" then
        local eye = targ:LookupAttachment("eyes")
                if eye then
                local pos = targ:GetAttachment(eye)
                        if pos then return pos.Pos end
                end
        end    
        if GetConVarString("Hera_Aim_AimSpot") == "Bone" then
        local bone = targ:LookupBone("ValveBiped.Bip01_Head1")
                if bone then
                local pos = targ:GetBonePosition(bone)
                        if pos then return pos end
                end
        end    
        if GetConVarString("Hera_Aim_AimSpot") == "Center" then
        local center = targ:OBBCenter()
                if center then
                local pos = targ:LocalToWorld(center)
                        if pos then return pos end
                end
        end
       
return targ:LocalToWorld(targ:OBBCenter())  // If Not Anything else just revert to object center.
 
end
 
local function Exception(ent)
        if (ent == LocalPlayer()) then return false end
        if (ent:Team() == TEAM_SPECTATOR) then return false end // No Spectators Please.
        if (ent:GetMoveType() == MOVETYPE_OBSERVER) then return false end // Check MoveType.
        if (!ent:Alive() ) then return false end // Is the player alive?
        if (ent:InVehicle()) then return false end // We Don't want people in vehicles.
        if (ClFriendly:GetInt() == 0 && ent:Team() == LocalPlayer():Team()) then return false end // Friendly fire
        if (ClAimSteam:GetInt() >= 1 && ent:GetFriendStatus() == "friend" ) then return false end // Is It a Steam
return true
end
 
local function Visible(ply)
local tracedata = {}
        tracedata.start = LocalPlayer():GetShootPos()
        tracedata.endpos = AimSpot(ply) - Vector(0,0,ClOf:GetInt())
        tracedata.mask = MASK_SHOT
        tracedata.filter = {ply , LocalPlayer()}
Trace = util.TraceLine(tracedata)
if Trace.Hit then return false else return true end
end
local function IsisAimbot(ucmd)
        if Aimon == 1 then
               
                local ArchAngel = Angle(0,0,0)
                local target;
                local distance = math.huge;
                for _, ply in pairs(player.GetAll()) do
                        if (ply != LocalPlayer() and ply:Alive() and Visible(ply)) then
                                local thedist = ply:GetPos():DistToSqr(LocalPlayer():GetPos());
                                if (thedist < distance) then
                                        distance = thedist;
                                        target = ply;
                                end
                        end
                end
                if target != nil then
                       
                local Aimspot = AimSpot(target) - Vector(0,0,ClOf:GetInt())
                Aimspot = Aimspot + target:GetVelocity() / 45 - LocalPlayer():GetVelocity() / 45
                Angel = (Aimspot - LocalPlayer():GetShootPos()):GetNormal():Angle()
                Angel.p = math.NormalizeAngle( Angel.p )
                Angel.y = math.NormalizeAngle( Angel.y )
 
 
                        ArchAngel = Angle( Angel.p, Angel.y, 0 )
 
                                debug.getregistry()["CUserCmd"].SetViewAngles(ucmd, ArchAngel)
 
                        end
       
        end
end
 
 
local ShouldShoot = false
local function IsisThink()
        if ClRcl:GetInt() >= 1 then
                if LocalPlayer():GetActiveWeapon().Primary then
                LocalPlayer():GetActiveWeapon().Primary.Recoil = 0
                end
        end    
                if CLM:GetInt() >= 1 and Backup != nil and Aimon == 1 then
                        if ShouldShoot then
                        RunConsoleCommand("-Attack")
                        ShouldShoot = false
                        elseif !ShouldShoot then
                        RunConsoleCommand("+Attack")
                        ShouldShoot = true
                        end
                        elseif Aimon == 0 or Backup == nil then
                        if ShouldShoot then
                        RunConsoleCommand("-Attack")
                        ShouldShoot = false
 
                        end
                end
       
end
timer.Create("LoadHooks",2.9,1,function()
IsisCreateHook("CreateMove",IsisAimbot)
IsisCreateHook("Think",IsisThink)
end)
-- because i'm lazy and didn't feel like re-doing this [ripped from cronus]
// Silent aim
Hera.EyeAngles = Angle(0,0,0)
Hera.StoredAngle = Angle(0,0,0)
Hera.AngleRestored = 0
Hera.Ang = Angle(0,0,0)
_G.Scrub = debug.getregistry()["CUserCmd"].SetViewAngles
concommand.Add("FixView", function()
        Hera.FixView = 1
        if GetConVarNumber("hera_aim_silent") == 1 then
        Hera.StoredAngle = LocalPlayer():EyeAngles()   
        end
        Hera.Ang = LocalPlayer():EyeAngles()   
        Hera.AngleRestored = 0
end)
 
 
function Hera.FovCheck( ent, fov )
        if fov == 0 or fov == 180 then return true end 
        if IsValid( ent ) then
                if GetConVarNumber("hera_aim_silent") == 0 then
                        LAng = LocalPlayer():EyeAngles()       
                else           
                        LAng = Hera.StoredAngle        
                end            
                if math.NormalizeAngle( ( Hera.GetHeadPos( ent ) - LocalPlayer():GetShootPos()):Angle().y - LAng.y
 
) > fov then return false end  
                if math.NormalizeAngle( ( Hera.GetHeadPos( ent ) - LocalPlayer():GetShootPos()):Angle().y - LAng.y
 
) < -fov then return false end
                if math.NormalizeAngle( ( Hera.GetHeadPos( ent ) - LocalPlayer():GetShootPos()):Angle().p - LAng.p
 
) < -fov then return false end
                if math.NormalizeAngle( ( Hera.GetHeadPos( ent ) - LocalPlayer():GetShootPos()):Angle().p - LAng.p
 
) > fov then return false end
                               
        end
        return true
end
 
function Hera.FakeView(cmd)
        if GetConVarNumber("hera_aim_silent") == 1 then
                Hera.StoredAngle.p = math.Clamp(Hera.StoredAngle.p + (cmd:GetMouseY() * 0.022), -89, 89)       
                Hera.StoredAngle.y = math.NormalizeAngle(Hera.StoredAngle.y + (cmd:GetMouseX() * 0.022 * -1))
                Hera.StoredAngle.r = 0
        end    
end
IsisCreateHook("CreateMove", Hera.FakeView)
 
local SetViewAngles = debug.getregistry().CUserCmd.SetViewAngles
 
function AimHook( cmd )
if GetConVarNumber("hera_aim_silent") == 1 then        
                local Forward = ((Vector(cmd:GetForwardMove(), cmd:GetSideMove(), 0):GetNormal():Angle() +
 
(cmd:GetViewAngles() - Hera.StoredAngle)):Forward() * Vector(cmd:GetForwardMove(), cmd:GetSideMove(), 0):Length())     
                cmd:SetForwardMove(Forward.x)          
                cmd:SetSideMove(Forward.y)             
        end
end
IsisCreateHook("CreateMove",AimHook)
 
function Hera.CalcView(ply, pos, angles, fov)
    local view = {}    
   view.origin = pos
        if Hera.FixView == 1 and GetViewEntity() == LocalPlayer() and GetConVarNumber("hera_aim_silent") == 1 then     
                view.angles = Hera.StoredAngle 
        end    
   view.fov = fov
    return view
end
IsisCreateHook("CalcView", Hera.CalcView)
 
-- shitty AA
function AA(cmd, u)
local C = LocalPlayer()
if GetConVarNumber("hera_aim_anti") == 1 and ShouldShoot == false then
local d = cmd:GetViewAngles()
cmd:SetViewAngles(cmd:GetViewAngles() * 1)
local v = cmd:GetViewAngles()
cmd:SetViewAngles(Angle(181, v.y, -180))
end
end
IsisCreateHook("CreateMove", AA)
 
 
function Notifications()
local NotifPos = 5
if Aimon == 1 then
draw.SimpleText("Aimbot: ON", "TabLarge", 0,NotifPos, Color(0,255,0,255))
else
draw.SimpleText("Aimbot: OFF", "TabLarge", 0, NotifPos, Color(255,0,0,255))
end
if GetConVarNumber("hera_aim_anti") == 1 then
draw.SimpleText("Anti-Aim: ON", "TabLarge", 80,NotifPos, Color(0,255,0,255))
else
draw.SimpleText("Anti-Aim: OFF", "TabLarge", 80, NotifPos, Color(255,0,0,255))
end
if GetConVarNumber("hera_aim_silent") == 1 then
draw.SimpleText("Silent Aim: ON", "TabLarge", 170,NotifPos, Color(0,255,0,255))
else
draw.SimpleText("Silent Aim: OFF", "TabLarge", 170, NotifPos, Color(255,0,0,255))
end
if GetConVarNumber("hera_aim_norecoil") == 1 then
draw.SimpleText("No Recoil: ON", "TabLarge", 365,NotifPos, Color(0,255,0,255))
else
draw.SimpleText("No Recoil: OFF", "TabLarge", 365,NotifPos, Color(255,0,0,255))
end
if GetConVarNumber("Hera_aim_Friendlyfire") == 1 then
draw.SimpleText("Friendly Fire: ON", "TabLarge", 460,NotifPos, Color(0,255,0,255))
else
draw.SimpleText("Friendly Fire: OFF", "TabLarge", 460,NotifPos, Color(255,0,0,255))
end
if GetConVarNumber("hera_aim_autoshoot") == 1 then
draw.SimpleText("Autoshoot: ON", "TabLarge", 570,NotifPos, Color(0,255,0,255))
else
draw.SimpleText("Autoshoot: OFF", "TabLarge", 570, NotifPos, Color(255,0,0,255))
end
if GetConVarNumber("hera_aim_ignoresteam") == 1 then
draw.SimpleText("Ignore Steam Friends: ON", "TabLarge", 670,NotifPos, Color(0,255,0,255))
else
draw.SimpleText("Ignore Steam Friends: OFF", "TabLarge", 670, NotifPos, Color(255,0,0,255))
end
if GetConVarNumber("host_timescale") >= 1.1 then
draw.SimpleText("SpeedHack: ON", "TabLarge", 840,NotifPos, Color(0,255,0,255))
else
draw.SimpleText("SpeedHack: OFF", "TabLarge", 840, NotifPos, Color(255,0,0,255))
end
end
IsisCreateHook("HUDPaint", Notifications)
 
 
concommand.Add( "hera_menu", function()
        Menu = vgui.Create( "DFrame")
        Menu:SetSize( 390, 450 )
        Menu:SetTitle("Hera")
        Menu:Center()
        Menu:MakePopup()
               
        local AdvTab = vgui.Create( "DPropertySheet", Menu)
        AdvTab:SetPos( 5, 25 )
        AdvTab:SetSize( 380, 415 )
       
        Menu.Image = "HatsuneMiku/mikuleek" -- fuck you
 
        local Page1 = vgui.Create( "DImage" )
        Page1:SetImage( Menu.Image )
        AdvTab:AddSheet( "Aimbot", Page1, "gui/silkicons/bomb", false, false, "Aimbot Settings" )
       
        local Aim1 = vgui.Create( "DCheckBoxLabel", Page1 )
        Aim1:SetPos( 10, 10 )
        Aim1:SetText( "Aimbot Toggle" )
        Aim1:SetConVar("hera_aim_toggle")
        Aim1:SetValue(GetConVarNumber("hera_aim_toggle"))
        Aim1:SizeToContents()
       
        local Aim2 = vgui.Create( "DCheckBoxLabel", Page1 )
        Aim2:SetPos( 10, 30 )
        Aim2:SetText( "Autoshoot" )
        Aim2:SetConVar("Hera_aim_AutoShoot")
        Aim2:SetValue(GetConVarNumber("Hera_aim_AutoShoot"))
        Aim2:SizeToContents()
       
        local Aim3 = vgui.Create( "DCheckBoxLabel", Page1 )
        Aim3:SetPos( 10, 50 )
        Aim3:SetText( "Friendly Fire" )
        Aim3:SetConVar("Hera_aim_Friendlyfire")
        Aim3:SetValue(GetConVarNumber("Hera_aim_Friendlyfire"))
        Aim3:SizeToContents()
       
        local Aim4 = vgui.Create( "DCheckBoxLabel", Page1 )
        Aim4:SetPos( 10, 70 )
        Aim4:SetText( "Ignore Steam Friends" )
        Aim4:SetConVar("Hera_Aim_IgnoreSteam")
        Aim4:SetValue(GetConVarNumber("Hera_Aim_IgnoreSteam"))
        Aim4:SizeToContents()
       
        local Aim6 = vgui.Create( "DCheckBoxLabel", Page1 )
        Aim6:SetPos( 10, 110 )
        Aim6:SetText( "No Recoil" )
        Aim6:SetConVar("Hera_aim_NoRecoil")
        Aim6:SetValue(GetConVarNumber("Hera_aim_NoRecoil"))
        Aim6:SizeToContents()
 
        local Aim7 = vgui.Create( "DCheckBoxLabel", Page1 )
        Aim7:SetPos( 10, 130 )
        Aim7:SetText( "Silent Aim" )
        Aim7:SetConVar("hera_aim_silent")
        Aim7:SetValue(GetConVarNumber("hera_aim_silent"))
        Aim7:SizeToContents()
       
        local Aim8 = vgui.Create( "DCheckBoxLabel", Page1 )
        Aim8:SetPos( 10, 150 )
        Aim8:SetText( "Spinbot" )
        Aim8:SetConVar("hera_aim_spinbot")
        Aim8:SetValue(GetConVarNumber("hera_aim_spinbot"))
        Aim8:SizeToContents()
       
        local Aim9 = vgui.Create( "DCheckBoxLabel", Page1 )
        Aim9:SetPos( 10, 170 )
        Aim9:SetText( "Anti-Aim" )
        Aim9:SetConVar("hera_aim_anti")
        Aim9:SetValue(GetConVarNumber("hera_aim_anti"))
        Aim9:SizeToContents()
       
        local TextAim1 = vgui.Create("DLabel")
        TextAim1:SetText( "Aimspot" )
        TextAim1:SetParent( Page1 )
        TextAim1:SetWide(100)
        TextAim1:SetPos(265,340)
        TextAim1:SetTextColor(Color(255,69,0,255))
       
        local ListAim1 = vgui.Create( "DComboBox" )
        ListAim1:SetPos( 250, 360 )
        ListAim1:SetParent( Page1 )
        ListAim1:SetSize( 100, 20 )
        ListAim1:AddChoice( "Bone" )
        ListAim1:AddChoice( "Center" )
        ListAim1:AddChoice( "Eye" )
        ListAim1:SetConVar( "hera_aim_aimspot" )
       
        local FixView = vgui.Create("DButton")
        FixView:SetPos( 132, 350 )
        FixView:SetParent( Page1 )
        FixView:SetSize( 95, 25 )
        FixView:SetText( "Reset Aim Position" )
        FixView.DoClick = function()
        RunConsoleCommand( "FixView" )
        end
       
        local Page2 = vgui.Create( "DImage" )
        Page2:SetImage( Menu.Image )
        AdvTab:AddSheet( "Wallhack", Page2, "gui/silkicons/group", false, false, "Wallhack Settings" )
 
        local ESP1 = vgui.Create( "DCheckBoxLabel", Page2 )
        ESP1:SetPos( 10, 10 )
        ESP1:SetText( "Player Info" )
        ESP1:SetConVar("hera_esp_info")
        ESP1:SetValue(GetConVarNumber("hera_esp_info"))
        ESP1:SizeToContents()
       
        local ESP2 = vgui.Create( "DCheckBoxLabel", Page2 )
        ESP2:SetPos( 10, 30 )
        ESP2:SetText( "Player Chams" )
        ESP2:SetConVar("hera_esp_chams")
        ESP2:SetValue(GetConVarNumber("hera_esp_chams"))
        ESP2:SizeToContents()
       
        local ESP3 = vgui.Create( "DCheckBoxLabel", Page2 )
        ESP3:SetPos( 10, 50 )
        ESP3:SetText( "Health Bar" )
        ESP3:SetConVar("hera_esp_health")
        ESP3:SetValue(GetConVarNumber("hera_esp_health"))
        ESP3:SizeToContents()
       
        local ESP4 = vgui.Create( "DCheckBoxLabel", Page2 )
        ESP4:SetPos( 10, 70 )
        ESP4:SetText( "2D Player Box" )
        ESP4:SetConVar("hera_esp_2dbox")
        ESP4:SetValue(GetConVarNumber("hera_esp_2dbox"))
        ESP4:SizeToContents()
       
        local ESP5 = vgui.Create( "DCheckBoxLabel", Page2 )
        ESP5:SetPos( 10, 90 )
        ESP5:SetText( "3D Player Box" )
        ESP5:SetConVar("hera_esp_3dbox")
        ESP5:SetValue(GetConVarNumber("hera_esp_3dbox"))
        ESP5:SizeToContents()
 
        local ESP6 = vgui.Create( "DCheckBoxLabel", Page2 )
        ESP6:SetPos( 10, 110 )
        ESP6:SetText( "Tracers" )
        ESP6:SetConVar("hera_esp_tracer")
        ESP6:SetValue(GetConVarNumber("hera_esp_tracer"))
        ESP6:SizeToContents()
       
        local ESP7 = vgui.Create( "DCheckBoxLabel", Page2 )
        ESP7:SetPos( 10, 130 )
        ESP7:SetText( "Weapon Finder" )
        ESP7:SetConVar("hera_esp_weapons")
        ESP7:SetValue(GetConVarNumber("hera_esp_weapons"))
        ESP7:SizeToContents()
 
       
        local Page3 = vgui.Create( "DImage" )
        Page3:SetImage( Menu.Image )
        AdvTab:AddSheet( "Miscellaneous", Page3, "gui/silkicons/world", false, false, "Misc Settings" )
       
        local Misc1 = vgui.Create( "DCheckBoxLabel", Page3 )
        Misc1:SetPos( 10, 10 )
        Misc1:SetText("Crosshair")
        Misc1:SetConVar("hera_misc_crosshair")
        Misc1:SetValue(GetConVarNumber("hera_misc_crosshair"))
        Misc1:SizeToContents()
       
        local Misc2 = vgui.Create( "DCheckBoxLabel", Page3 )
        Misc2:SetPos( 10, 30 )
        Misc2:SetText( "Bunnyhop" )
        Misc2:SetConVar("hera_misc_bhop")
        Misc2:SetValue(GetConVarNumber("hera_misc_bhop"))
        Misc2:SizeToContents()
 
        local Misc4 = vgui.Create( "DCheckBoxLabel", Page3 )
        Misc4:SetPos( 10, 70 )
        Misc4:SetText( "Log IP's" )
        Misc4:SetConVar("hera_misc_logips")
        Misc4:SetValue(GetConVarNumber("hera_misc_logips"))
        Misc4:SizeToContents()
       
        local Misc5 = vgui.Create( "DCheckBoxLabel", Page3 )
        Misc5:SetPos( 10, 90 )
        Misc5:SetText( "Fullbright" )
        Misc5:SetConVar("hera_misc_fullbright")
        Misc5:SetValue(GetConVarNumber("hera_misc_fullbright"))
        Misc5:SizeToContents()
       
        local Misc6 = vgui.Create( "DCheckBoxLabel", Page3 )
        Misc6:SetPos( 10, 110 )
        Misc6:SetText( "Chat Spam" )
        Misc6:SetConVar("hera_misc_chatspam")
        Misc6:SetValue(GetConVarNumber("hera_misc_chatspam"))
        Misc6:SizeToContents()
       
        local Misc7Text = vgui.Create("DLabel")
        Misc7Text:SetText( "Chat Spam Message" )
        Misc7Text:SetParent( Page3 )
        Misc7Text:SetWide(200)
        Misc7Text:SetPos(10,330)
        Misc7Text:SetTextColor(Color(255,69,0,255))
       
        local Misc7 = vgui.Create( "DTextEntry", Page3 )
        Misc7:SetPos( 10, 350 )
        Misc7:SetTall(15)
        Misc7:SetWide(225)
        Misc7:SetConVar("hera_misc_spammessage")
        Misc7:SetValue(GetConVarNumber("hera_misc_chatspam"))
        Misc7:SetEnterAllowed( true )
       
        local Misc8 = vgui.Create( "DButton", Page3 )
        Misc8:SetPos( 270, 350 )
        Misc8:SetSize( 90, 25 )
        Misc8:SetText( "Mute All" )
        Misc8.DoClick = function()
        muteall = !muteall
        for k, v in pairs( player.GetAll() ) do
        if v ~= LocalPlayer() then
        if v:GetFriendStatus() ~= "friend" then
        if muteall then
        v:SetMuted( true )
        else
        end
        end
        end
        end
        end
       
        local Misc9 = vgui.Create( "DButton", Page3 )
        Misc9:SetPos( 270, 320 )
        Misc9:SetSize( 90, 25 )
        Misc9:SetText( "Unmute All" )
        Misc9.DoClick = function()
        unmuteall = !unmuteall
        for k, v in pairs( player.GetAll() ) do
        if v ~= LocalPlayer() then
        if v:GetFriendStatus() ~= "friend" then
        if unmuteall then
        v:SetMuted( false )
        end
        end
        end
        end
        end
       
        local Speedhack = vgui.Create( "DNumSlider" )
        Speedhack:SetPos( 10, 200 )
        Speedhack:SetParent( Page3 )
        Speedhack:SetWide( 200 )
        Speedhack:SetText( "SpeedHack Speed" )
        Speedhack:SetMin( 1 )
        Speedhack:SetMax( 10 )
        Speedhack:SetDecimals( 1 )
        Speedhack:SetConVar( "hera_speedhack_speed" )
       
        local Page4 = vgui.Create( "DImage" )
        Page4:SetImage( Menu.Image )
        AdvTab:AddSheet( "Customize", Page4, "gui/silkicons/wrench", false, false, "Customize The Cheat" )
               
        local Cust1 = vgui.Create( "DNumSlider" )
        Cust1:SetPos( 10, 10 )
        Cust1:SetParent( Page4 )
        Cust1:SetWide( 200 )
        Cust1:SetText( "[ESP Info Color] Red" )
        Cust1:SetMin( 1 )
        Cust1:SetMax( 255 )
        Cust1:SetDecimals( 0 )
        Cust1:SetConVar( "hera_esp_info_color_r" )
               
        local Cust2 = vgui.Create( "DNumSlider" )
        Cust2:SetPos( 10, 50 )
        Cust2:SetParent( Page4 )
        Cust2:SetWide( 200 )
        Cust2:SetText( "[ESP Info Color] Green" )
        Cust2:SetMin( 1 )
        Cust2:SetMax( 255 )
        Cust2:SetDecimals( 0 )
        Cust2:SetConVar( "hera_esp_info_color_g" )
       
        local Cust3 = vgui.Create( "DNumSlider" )
        Cust3:SetPos( 10, 90 )
        Cust3:SetParent( Page4 )
        Cust3:SetWide( 200 )
        Cust3:SetText( "[ESP Info Color] Blue" )
        Cust3:SetMin( 1 )
        Cust3:SetMax( 255 )
        Cust3:SetDecimals( 0 )
        Cust3:SetConVar( "hera_esp_info_color_b" )
       
        local Cust4 = vgui.Create( "DNumSlider" )
        Cust4:SetPos( 10, 130 )
        Cust4:SetParent( Page4 )
        Cust4:SetWide( 200 )
        Cust4:SetText( "[ESP Box Color] Red" )
        Cust4:SetMin( 1 )
        Cust4:SetMax( 255 )
        Cust4:SetDecimals( 0 )
        Cust4:SetConVar( "hera_esp_box_color_r" )
               
        local Cust5 = vgui.Create( "DNumSlider" )
        Cust5:SetPos( 10, 170 )
        Cust5:SetParent( Page4 )
        Cust5:SetWide( 200 )
        Cust5:SetText( "[ESP Box Color] Green" )
        Cust5:SetMin( 1 )
        Cust5:SetMax( 255 )
        Cust5:SetDecimals( 0 )
        Cust5:SetConVar( "hera_esp_box_color_g" )
       
        local Cust6 = vgui.Create( "DNumSlider" )
        Cust6:SetPos( 10, 210 )
        Cust6:SetParent( Page4 )
        Cust6:SetWide( 200 )
        Cust6:SetText( "[ESP Box Color] Blue" )
        Cust6:SetMin( 1 )
        Cust6:SetMax( 255 )
        Cust6:SetDecimals( 0 )
        Cust6:SetConVar( "hera_esp_box_color_b" )
       
        local Page5 = vgui.Create( "DImage" )
        Page5:SetImage( Menu.Image )
        AdvTab:AddSheet( "Info", Page5, "gui/silkicons/information", false, false, "Information" )
       
        local HeraInfoPage
        http.Fetch( "http://dl.dropbox.com/u/28497094/Hera/Info.txt", function(data)
        HeraInfoPage = vgui.Create("DLabel")
        HeraInfoPage:SetPos( 10, 5 )
        HeraInfoPage:SetParent( Page5 )
        HeraInfoPage:SetText( data )
        HeraInfoPage:SizeToContents()
        HeraInfoPage:SetTextColor(Color(255,0,0,255))
        end )
end )