--[[
	lua/multihax/Hackmenu.lua
	Skittles 2.0 | (STEAM_0:1:41711091)
	===DStream===
]]

--Hackers Menu v1.0

function MakeAddToolMenuTabs()
spawnmenu.AddToolTab("Hackmenu", "Hackmenu")
end
hook.Add("AddToolMenuTabs", "MakeAddToolMenuTabs", MakeAddToolMenuTabs)

function UsefullCommands (Panel)
Panel:AddControl("Slider", {Label = "Suicide Health", Command = "aimbot_suicidehealth", Min = "0", Max = "99", Type = "Integer"})
Panel:AddControl("Button", {Label = "Kill yourself", Text = "...", Command = "kill"})
Panel:AddControl("Label", {Text = "ESP"})
Panel:AddControl("Button", {Label = "On", Text = "...", Command = "esp_on"})
Panel:AddControl("Button", {Label = "Off", Text = "...", Command = "esp_off"})
Panel:AddControl("Label", {Text = " NightVision"})
Panel:AddControl("Button", {Label = "Toggle On\Off", Text = "...", Command = "toggle_nightvision"})
Panel:AddControl("Label", {Text = " XrayVision"})
Panel:AddControl("Button", {Label = "Toggle On\Off", Text = "...", Command = "toggle_xrayvision"})
Panel:AddControl("Label", {Text = "AIMBOT"})
Panel:AddControl("Button", {Label = "AIMBOT On", Text = "...", Command = "aimbot_on"})
Panel:AddControl("Button", {Label = "AIMBOT Off", Text = "...", Command = "aimbot_off"})
Panel:AddControl("Button", {Label = "Target Players ONLY", Text = "...", Command = "aimbot_playersonly_on" })
Panel:AddControl("Button", {Label = "*Target Everything", Text = "...", Command = "aimbot_playersonly_off" })
Panel:AddControl("Button", {Label = "Target Enemys ONLY", Text = "...", Command = "aimbot_enemysonly_on" })
Panel:AddControl("Button", {Label = "*Target Enemys OFF", Text = "...", Command = "aimbot_enemysonly_off" })
Panel:AddControl("Button", {Label = "HeadShots ON", Text = "...", Command = "aimbot_headshots_on" })
Panel:AddControl("Button", {Label = "HeadShots OFF", Text = "...", Command = "aimbot_headshots_off" })
Panel:AddControl("Label", {Text = "Camera"})
Panel:AddControl("Button", {Label = "On", Text = "...", Command = "entx_camenable"})
Panel:AddControl("Button", {Label = "Off", Text = "...", Command = "entx_camdisable"})
Panel:AddControl("Label", {Text = "SPAZ"})
Panel:AddControl("Button", {Label = "On", Text = "...", Command = "entx_spazon"})
Panel:AddControl("Button", {Label = "Off", Text = "...", Command = "entx_spazoff"})
Panel:AddControl("Label", {Text = "Extras"})
Panel:AddControl("Button", {Label = "Disconnect", Text = "...", Command = "disconnect"})
Panel:AddControl("Button", {Label = "Shut DOWN", Text = "...", Command = "quit"})
Panel:AddControl("Button", {Label = "OPENCONSOLE", Text = "...", Command = "toggleconsole"})
Panel:AddControl("Button", {Label = "Zo0m IN", Text = "...", Command = "toggle_zoom"})
end 

function PluginInfo(Panel)
Panel:AddControl("Label", {Text = "    HACKMENU FOR NEWBS"})
Panel:AddControl("Label", {Text = ""})
Panel:AddControl("Label", {Text = "Like the GREAT ONE always said"})
Panel:AddControl("Label", {Text = "----HACKS ON , HACKS OFF----"})
Panel:AddControl("Label", {Text = ""})
Panel:AddControl("Label", {Text = "      Hackmenu V1.0"})
Panel:AddControl("Label", {Text = ""})

end


function CreateHackmenu()
spawnmenu.AddToolMenuOption( "Hackmenu", "Usefull", "Usefull Commands", "#Usefull Commands", "", "", UsefullCommands )
spawnmenu.AddToolMenuOption( "Hackmenu", "Plug-In", "Plug-In Info", "#PlugIn Help", "", "", PluginInfo )
end
hook.Add("PopulateToolMenu", "PopulateToolMenu", CreateHackmenu)

--FEEL FREE to USE MY EXAMPLE --