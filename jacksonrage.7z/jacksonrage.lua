/*
	Jackson Cheat 
	
	Credits: 
		anane
		leme 
		homonovus
		solum
		black
*/

jit.flush() -- woot woot

pcall(require, "proxi")

if not proxi then return end

local Data = {
	Environment = {
		_G = _G or getfenv(1),
		_R = proxi._R,

		proxi = proxi,

		net = net,
		
		Vars = {
			Aimbot = {
				Enabled = true,
				
				Key = KEY_E,
				Silent = true,
				AutoShoot = false,
				FireOnKey = true,
				AntiRecoil = true,
				UseContext = false,
				Sticky = false,
				Los = true,
				AutoFire = false,
				
				MultiPoint = true,
				TickMod = false,

				SortMethod = 1,
				
				AimCone = {
					Enabled = false,
					Shape = "Circle",
					FOV = 16,
					Color = nil
				},
		
				TriggerBot = {
					Enabled = true,
					HitBacktrack = false,
					AutoWall = true,
					Crosshair = false,
					RapidFire = true
				},
				
				NoSpread = {
					Enabled = true,
					UseContext = false,
					Seed = true
				},
				
				Backtrack = {
					Enabled = true,
					Amount = 0.2
				},
			
				Resolver = false,
			
				WhiteList = {
					IgnoreWhiteList = true,
					IgnorePlayers = false,
					IgnoreFriends = false,	
					IgnoreTeam = false,
					IgnoreNpcs = false,
					IgnoreBots = false
				}, 

				Friends = {},
				
				AimAtHitboxes = 1
			},
		
			HvH = {
				AntiAim = {
					Enabled = false,
					
					Pitch = 0,
					Yaw = 0,
					
					CustomPitch = 0,
					
					CustomYaw = {
						Real = 0,
						Fake = 0
					},
					
					FollowTarget = false,
					
					SpinSpeed = 40,
					
					Edge = {
						Wall = 0,
						Corner = 90
					},
					
					LbyBreaker = {
						Enabled = false,
		
						Delta = 45,
						LastBreak = 0
					}
				},
				
				FakeLag = {
					Enabled = false,
					Choke = 0,
					Adaptive = false,
					FuckTicks = false
				},
			
				FakeDuck = {
					Enabled = false,
					Key = KEY_PAD_0
				},
			},

			ESP = {
				Enabled = true, 
				
				Box = true,
				Box3D = false,
				Name = true,
				Weapon = false,
				Skeleton = false,
				Flags = true,
				UserGroup = false,
				Avatar = false,
				
				Bones = {
					Enabled = false,
					Lines = false,
					Points = false
				},
				
				Health = {
					Enabled = true,
						
					Bar = true,
					Amount = true
				},
			},
			
			EntityESP = {
				Enabled = false,
		
				Box = false,
				Box3D = false,
				Name = false,
				Weapon = false,
				Skeleton = false,
				HealthBar = false
			},
		
			Visuals = {
				Chams = {
					Player = {
						Enabled = false,
							
						Color = nil,
						Material = "metallic",
						
						OverLay = {
							Enabled = true,
							Color = nil,
							Material = "fireframe"
						},

						Local = {
							ViewModel = {
								Enabled = false,
								Color = nil,
								Material = "fireframe",
							}
						}
					},
						
					Entity = {
						Enabled = false,
							
						Color = nil,
						Material = "metallic",
						
						OverLay = {
							Enabled = true, 
							Color = nil,
							Material = "wireframe"
						}
					}
				},
			
				Backtrack = {
					Enabled = false,
					OnlyAimTarget = false,
					VisualStyle = 0,
					Color = nil
				},
				
				Tracers = {
					Enabled = false,
					Player = false,
					Bullet = false,
					BulletTime = 2
				},
				
				DebugInfo = false,
				
				HitBoxes = {
					Enabled = false,
					LocalPLayer = false,
					Color = nil
				}
			},
		
			Minge = {
				NameStealer = {
					Enabled = false,
					StealRandom = false,
					CurrName = ""
				},
				
				ChatSpam = {
					Enabled = false,
					TypingOverRide = false,
					Mode = "regular"
				},
			
				AutoKick = false,
				FlashLightSpam = false
			},
		
			Miscellaneous = {				
				KillSound = {
					Enabled = false,
					Path = "cheat_sounds/dead.wav"
				},

				Movement = {
					Bhop = true,
					
					AutoStrafe = {
						Enabled = true,
						Mode = 1
					}
				},
			
				ThirdPerson = {
					Enabled = false,
					Distance = 20,
					Y = 0
				},
			
				Freeze = {
					DoubleTap = false,
					Teleport = false,
					TeleportKey = KEY_E
				},
			
				Crosshair = {
					Enabled = true,
					Type = "basic",
					Length = 16,
					Thickness = 4,
					Speed = 4
				},
				
				FOV = {
					Enabled = true,
					Desired = 106
				},

				Hitsound = {
					Enabled = false,
				},
				
				
				RainbowPhys = {
					Enabled = false,
					Frequency = 4
				},
				

			},

			Viewmodel = {
				Changer = {
					Enabled = false,
					VMFOV = 54
				},

			},

		},

		Cache = {
			TickInterval = 0,
			SecondInterval = 0,
			LastPlayerListUpdate = 0,

			ScreenData = {
				ScrW = 0,
				ScrH = 0,

				Center = {
					X = 0,
					Y = 0
				}
			},

			FacingAngle = nil,
			AntiAimAngle = nil,

			TraceData = {},
			TraceOutput = {},

			BulletTracers = {},

			CalcViewData = {},
			EntityData = {},
			ModelData = {},
			WeaponNames = {},

			Colors = {},

			Panels = {
				MainFrame = nil,
				EnvFrame = nil,
				EnvPlayerList = nil,
				EnvEntityList = nil,
				EnvHookList = nil,
				EnvBlockedHookList = nil
			},

			ConVars = {
				NoSpread = {},
				AutoWall = {}
			},

			NetVars = {
				Buildmode = { "BuildMode", "buildmode", "_Kyle_Buildmode" },
				GodMode = { "has_god", "god_mode", "ugod" },
				HvHMode = { "HVHER" },
				Protected = { "LibbyProtectedSpawn", "SH_SZ.Safe", "spawn_protect", "InSpawnZone" }
			},
			
			WeaponData = {
				NoSpread = {
					Cones = {},
					Seeds = {},
					Storage = {}
				},
				
				MeleeGuns = {
					["weapon_crowbar"] = true,
					["weapon_stunstick"] = true,
				
					["tf_weapon_bat"] = true,
					["tf_weapon_fryingpan"] = true,
					["tf_weapon_hamshank"] = true,
					["tf_weapon_knife"] = true,
					["tf_weapon_skullcutter"] = true,	
				},

				AutoShoot = {
					Functions = {},
					BaseFunctions = {},
					
					Classes = {
						Blacklist = { "bomb", "c4", "climb", "fist", "gravity gun", "grenade", "hand", "ied", "knife", "physics gun", "slam", "sword", "tool gun", "vape" },
						Whitelist = { "handgun" }
					}
				},
				
				AutoWall = {
					Limits = {
						["357"] = {144, 4},
						ar2 = {256, 8},
						buckshot = {25, 1},
						pistol = {81, 2},
						smg1 = {196, 5},
						sniperpenetratedround = {400, 12},
						sniperround = {400, 12} -- SWB
					},

					Multipliers = {
						[MAT_SAND] = 0.5,
						[MAT_DIRT] = 0.8,
						[MAT_METAL] = 1.1,
						[MAT_TILE] = 0.9,
						[MAT_WOOD] = 1.2
					},

					Cancellers = {
						[MAT_SLOSH] = true
					},

					Functions = {}
				}
			},

			Tracers = {
				["rb655_nyan_tracer"] = true,
				["impact"] = true,
				["ragdollimpact"] = true,
			},

			Hooks = {
				Active = {},
				Blocked = {},

				Local = {}
			},

			Players = {},
			Entities = {},
			Enums = {},

			iEntityClasses = { "prop_physics", },

			Skyboxes = {},
			SkyTextures =  {}
		}
	}
}

Data.Environment.Cache.TraceData.output = Data.Environment.Cache.TraceOutput

do
	local ENV = Data.Environment

	ENV.rawget = rawget(ENV._G, "rawget")
	ENV.getfenv = ENV.rawget(ENV._G, "getfenv")
	ENV.setfenv = ENV.rawget(ENV._G, "setfenv")
	ENV.type = ENV.rawget(ENV._G, "type")

	ENV.table = {
		Copy = ENV.rawget(ENV._G.table, "Copy")
	}

	-- Sets a function's environment to the environment
	function ENV.RegisterFunction(Function)
		return ENV.setfenv(Function, ENV)
	end

	-- Creates a function in the environment
	function ENV.CreateFunction(Name, Function)
		ENV[Name] = ENV.RegisterFunction(Function)
	end

	-- Localizes something from the global table to the local environment (Auto constructs table layout)
	ENV.CreateFunction("Localize", function(...)
		local Parameters = {...}
		local Found = false
		local Last = "_"
		local Cur = _G
		local LastTable = ENV
		local CurTable = ENV

		for i = 1, #Parameters do
			local v = Parameters[i]

			Last = Cur
			Cur = Cur[v]

			if type(Cur) == "table" then -- Setup environment
				CurTable[v] = rawget(CurTable, v) or {} -- Avoid __index

				LastTable = CurTable
				CurTable = CurTable[v]
				Last = v
			else
				CurTable[v] = Cur
				Found = true

				break
			end
		end

		if not Found then
			LastTable[Last] = table.Copy(Cur)
		end
	end)

	--------------------------- Normal Localization ---------------------------

	-- Enums
	ENV.Localize("FILL")
	ENV.Localize("NODOCK")
	ENV.Localize("HITGROUP_CHEST")
	ENV.Localize("HITGROUP_HEAD")
	ENV.Localize("HITGROUP_STOMACH")
	ENV.Localize("BONE_USED_BY_HITBOX")
	ENV.Localize("MOVETYPE_WALK")
	ENV.Localize("MOVETYPE_NOCLIP")
	ENV.Localize("FL_ONGROUND")
	ENV.Localize("IN_ATTACK")
	ENV.Localize("IN_ATTACK2")
	ENV.Localize("IN_RELOAD")
	ENV.Localize("IN_SPEED")
	ENV.Localize("IN_ZOOM")
	ENV.Localize("IN_JUMP")
	ENV.Localize("IN_DUCK")
	ENV.Localize("IN_USE")
	ENV.Localize("MASK_SHOT")
	ENV.Localize("EF_NODRAW")
	ENV.Localize("OBS_MODE_NONE")
	ENV.Localize("TEAM_SPECTATOR")
	ENV.Localize("RENDERMODE_TRANSALPHA")
	ENV.Localize("RENDERMODE_NORMAL")
	ENV.Localize("GESTURE_SLOT_VCD")
	ENV.Localize("GESTURE_SLOT_CUSTOM")
	ENV.Localize("_MODULES")
	
	ENV.Localize("angle_zero")
	ENV.Localize("vector_origin")

	-- Functions
	ENV.Localize("setmetatable")
	ENV.Localize("assert")
	ENV.Localize("pairs")
	ENV.Localize("ipairs")
	ENV.Localize("SortedPairs")
	ENV.Localize("print")
	ENV.Localize("PrintTable")
	ENV.Localize("error")
	ENV.Localize("rawset")
	ENV.Localize("CompileString")
	ENV.Localize("Entity")
	ENV.Localize("Angle")
	ENV.Localize("Color")
	ENV.Localize("ColorAlpha")
	ENV.Localize("HSVToColor")
	ENV.Localize("CurTime")
	ENV.Localize("IsFirstTimePredicted")
	ENV.Localize("IsValid")
	ENV.Localize("LocalPlayer")
	ENV.Localize("EyePos")
	ENV.Localize("EyeVector")
	ENV.Localize("LerpCW20")
	ENV.Localize("MsgC")
	ENV.Localize("MsgN")
	ENV.Localize("Player")
	ENV.Localize("RealFrameTime")
	ENV.Localize("ScrH")
	ENV.Localize("ScrW")
	ENV.Localize("SysTime")
	ENV.Localize("Vector")
	ENV.Localize("collectgarbage")
	ENV.Localize("next")
	ENV.Localize("tobool")
	ENV.Localize("istable")
	ENV.Localize("tonumber")
	ENV.Localize("tostring")
	ENV.Localize("isvector")
	ENV.Localize("isnumber")
	ENV.Localize("isentity")
	ENV.Localize("isfunction")
	ENV.Localize("isbool")
	ENV.Localize("type")
	ENV.Localize("unpack")
	ENV.Localize("FrameNumber")
	ENV.Localize("Material")
	ENV.Localize("CreateMaterial")
	ENV.Localize("getinfo")
	ENV.Localize("getupvalue")
	ENV.Localize("getupvalues")
	ENV.Localize("module")

	-- Libraries
	ENV.Localize("debug", "setmetatable")
	ENV.Localize("draw", "NoTexture")
	ENV.Localize("engine", "TickInterval")
	ENV.Localize("engine", "TickCount")
	ENV.Localize("coroutine", "create")
	ENV.Localize("coroutine", "resume")
	ENV.Localize("file", "Open")
	ENV.Localize("game", "GetAmmoName")
	ENV.Localize("game", "GetWorld")
	ENV.Localize("gameevent", "Listen")
	ENV.Localize("hook", "Add")
	ENV.Localize("hook", "Run")
	ENV.Localize("hook", "Remove")
	ENV.Localize("hook", "GetTable")
	ENV.Localize("input", "IsButtonDown")
	ENV.Localize("input", "GetCursorPos")
	ENV.Localize("math", "Clamp") -- So many calculations! Must be a math wiz!
	ENV.Localize("math", "Distance")
	ENV.Localize("math", "NormalizeAngle")
	ENV.Localize("math", "AngleDifference")
	ENV.Localize("math", "Rand")
	ENV.Localize("math", "Round")
	ENV.Localize("math", "Truncate")
	ENV.Localize("math", "abs")
	ENV.Localize("math", "acos")
	ENV.Localize("math", "atan")
	ENV.Localize("math", "cos")
	ENV.Localize("math", "deg")
	ENV.Localize("math", "floor")
	ENV.Localize("math", "huge")
	ENV.Localize("math", "max")
	ENV.Localize("math", "min")
	ENV.Localize("math", "pi")
	ENV.Localize("math", "pow")
	ENV.Localize("math", "rad")
	ENV.Localize("math", "sin")
	ENV.Localize("math", "sqrt")
	ENV.Localize("math", "tan")
	ENV.Localize("math", "random")	
	ENV.Localize("math", "atan2")
	ENV.Localize("math", "ceil")
	ENV.Localize("math", "fmod")
	ENV.Localize("math", "randomseed")
	ENV.Localize("player", "GetAll")
	ENV.Localize("player", "GetCount")
	ENV.Localize("string", "Split")
	ENV.Localize("string", "find")
	ENV.Localize("string", "lower")
	ENV.Localize("string", "sub")
	ENV.Localize("string", "char")
	ENV.Localize("surface", "CreateFont")
	ENV.Localize("surface", "DrawCircle")
	ENV.Localize("surface", "DrawOutlinedRect")
	ENV.Localize("surface", "DrawPoly")
	ENV.Localize("surface", "DrawRect")
	ENV.Localize("surface", "GetTextSize")
	ENV.Localize("surface", "GetTextureID")
	ENV.Localize("surface", "SetDrawColor")
	ENV.Localize("surface", "SetTexture")
	ENV.Localize("surface", "DrawLine")
	ENV.Localize("surface", "SetFont")
	ENV.Localize("surface", "SetTextColor")
	ENV.Localize("surface", "SetTextPos")
	ENV.Localize("surface", "DrawText")
	ENV.Localize("render", "GetBlend")
	ENV.Localize("render", "GetViewSetup")
	ENV.Localize("render", "SetMaterial")
	ENV.Localize("render", "DrawBeam")
	ENV.Localize("render", "SetColorModulation")
	ENV.Localize("render", "MaterialOverride")
	ENV.Localize("render", "SetBlend")
	ENV.Localize("render", "SuppressEngineLighting")
	ENV.Localize("render", "DrawWireframeBox")
	ENV.Localize("render", "SetMaterial")
	ENV.Localize("cam", "Start3D")
	ENV.Localize("cam", "Start2D")
	ENV.Localize("cam", "End2D")
	ENV.Localize("cam", "IgnoreZ")
	ENV.Localize("cam", "End3D")
	ENV.Localize("table", "Empty")
	ENV.Localize("table", "IsEmpty")
	ENV.Localize("table", "concat")
	ENV.Localize("table", "insert")
	ENV.Localize("table", "remove")
	ENV.Localize("table", "sort")
	ENV.Localize("table", "Merge")
	ENV.Localize("table", "HasValue")
	ENV.Localize("util", "TraceLine")
	ENV.Localize("util", "TraceHull")
	ENV.Localize("util", "IntersectRayWithOBB")
	ENV.Localize("util", "CRC")
	ENV.Localize("util", "NiceFloat")
	ENV.Localize("util", "AimVector")
	ENV.Localize("util", "Base64Encode")
	ENV.Localize("util", "Compress")
	ENV.Localize("util", "NetworkStringToID")
	ENV.Localize("util", "SharedRandom")
	ENV.Localize("net", "Receive")
	ENV.Localize("vgui", "Create")
	ENV.Localize("vgui", "Register")
	ENV.Localize("vgui", "GetWorldPanel")
	ENV.Localize("vgui", "GetKeyboardFocus")
	ENV.Localize("file", "Exists")
	ENV.Localize("file", "IsDir")
	ENV.Localize("file", "Find")
	ENV.Localize("file", "Read")
	ENV.Localize("file", "Find")
	ENV.Localize("ents", "FindByClass")
	ENV.Localize("ents", "GetAll")
	ENV.Localize("ents", "GetByIndex")
	ENV.Localize("string", "format")
	ENV.Localize("string", "find")
	ENV.Localize("timer", "Create")
	ENV.Localize("timer", "Remove")
	ENV.Localize("timer", "Simple")
	ENV.Localize("concommand", "Add")
	ENV.Localize("concommand", "Remove")
	ENV.Localize("ents", "FindByClass")
	ENV.Localize("ents", "GetAll")
	ENV.Localize("bit", "band")
	ENV.Localize("bit", "bor")
	ENV.Localize("bit", "bxor")
	ENV.Localize("bit", "lshift")
	ENV.Localize("bit", "rshift")
	ENV.Localize("language", "GetPhrase")
	ENV.Localize("weapons", "IsBasedOn")
	ENV.Localize("debugoverlay", "Cross")
	ENV.Localize("debugoverlay", "Box")
	ENV.Localize("debugoverlay", "Line")
	ENV.Localize("scripted_ents", "GetList")
	ENV.Localize("gui", "EnableScreenClicker")
	ENV.Localize("gui", "IsGameUIVisible")
	ENV.Localize("system", "IsWindows")
    ENV.Localize("system", "IsLinux")
    ENV.Localize("system", "IsOSX")
    ENV.Localize("jit", "arch")
    ENV.Localize("package", "loaded")
	ENV.Localize("package", "seeall")
	ENV.Localize("sound", "PlayFile")
	ENV.Localize("weapons", "GetStored")
	ENV.Localize("game", "SinglePlayer")
	ENV.Localize("player_manager", "GetPlayerClasses")
	
	-- Stupid shit
	ENV.NULL = ENV.rawget(_G, "NULL") -- BEEEEEEEEEEEEEEE

	ENV.CustomizableWeaponry = ENV.rawget(ENV._G, "CustomizableWeaponry")
	ENV.CW_AIMING = ENV.rawget(ENV._G, "CW_AIMING")
	ENV.FAS_STAT_CUSTOMIZE = ENV.rawget(ENV._G, "FAS_STAT_CUSTOMIZE")
	ENV.FAS_STAT_SPRINT = ENV.rawget(ENV._G, "FAS_STAT_SPRINT")
	ENV.FAS_STAT_QUICKGRENADE = ENV.rawget(ENV._G, "FAS_STAT_QUICKGRENADE")
	ENV.TFA = ENV.rawget(ENV._G, "TFA")
	ENV.ArcCW = ENV.rawget(ENV._G, "ArcCW")

	ENV.g_pLocalPlayer = ENV.LocalPlayer()

	local Cache = ENV.Cache
	local Vars = ENV.Vars
	
	Cache.Colors.White = ENV.Color(255, 255, 255, 255)
	Cache.Colors.Black = ENV.Color(0, 0, 0, 255)
	Cache.Colors.Red = ENV.Color(255, 0, 0, 255)
	Cache.Colors.Blue = ENV.Color(0, 0, 255, 255)
	Cache.Colors.Green = ENV.Color(0, 255, 0, 255)
	Cache.Colors.Orange = ENV.Color(255, 150, 0, 255)
	Cache.Colors.Gray = ENV.Color(175, 175, 175, 255)
	Cache.Colors.Pink = ENV.Color(255, 0, 200, 255)
	Cache.Colors.Crimson = ENV.Color(175, 0, 42, 255)
	Cache.Colors.Lavender = ENV.Color(165, 125, 255, 255)
	Cache.Colors.Purple = ENV.Color(125, 0, 255, 255)
	Cache.Colors.Teal = ENV.Color(0, 180, 180, 255)
	Cache.Colors.Seafoam = ENV.Color(201, 255, 229)

	Vars.Aimbot.AimCone.Color = ENV.Color(255, 255, 255)
	Vars.Visuals.Chams.Player.Color = ENV.Color(0, 255, 255)
	Vars.Visuals.Chams.Player.OverLay.Color = ENV.Color(255, 0, 0)
	Vars.Visuals.Chams.Player.Local.ViewModel.Color = ENV.Color(255, 0, 0)
	Vars.Visuals.Chams.Entity.Color = ENV.Color(0, 255, 255)
	Vars.Visuals.Chams.Entity.OverLay.Color = ENV.Color(255, 0, 0)
	Vars.Visuals.Backtrack.Color = ENV.Color(0, 255, 255)
	Vars.Visuals.HitBoxes.Color = ENV.Color(0, 255, 255)

	ENV.CreateFunction("Log", function(String, ...)
		MsgC(Cache.Colors.Gray, "[", Cache.Colors.Crimson, "Jackson", Cache.Colors.Gray, "] ", Cache.Colors.Seafoam, string.format(String, ...) .. "\n")
	end)

	ENV.CreateFunction("enum", function(prefix, id)
		if not Cache.Enums[prefix] then
			Cache.Enums[prefix] = {}
		end
	
		if istable(id) and not table.IsEmpty(id) then
			for k,v in next, id do
				enum(prefix, v)
			end
		else
			-- don't put this one in _G, but still populate the enum table
			if id == false then
				table.insert(Cache.Enums[prefix], table.IsEmpty(Cache.Enums[prefix]) and 0 or #Cache.Enums[prefix] + 1, id)
				return
			end
	
			local key = prefix:upper() .. "_" .. id:upper()
			local value = table.IsEmpty(Cache.Enums[prefix]) and 0 or #Cache.Enums[prefix] + 1
			ENV[key] = value
	
			table.insert(Cache.Enums[prefix], value, id)
		end
	end)
	
	ENV.CreateFunction("LoadModules", function(Directory)
		if not file.Exists(Directory, "MOD") and not file.IsDir(Directory, "MOD") then return end
		
		local files = file.Find(string.format("%s/*", Directory), "MOD")

		local ProxiCode = file.Read("jackson_modules/proxi.lua", "LUA") -- run first
		local Q = CompileString(ProxiCode)
		ENV.setfenv(Q, ENV)
		Q()

		Log("Loaded proxi.lua")
		
		for _, v in next, files do
			local code = file.Read(string.format("%s/%s", Directory, v), "MOD")	
			if v == "proxi.lua" then continue end --  dont run twice silly

			local X = CompileString(code)
			ENV.setfenv(X, ENV)
			X()
			
			Log("Loaded %s", v)
		end
	end)

	ENV.LoadModules("lua/jackson_modules") 
	
	ENV.CreateFunction("AddHook", function(Type, Function)
		local Name = tostring({})

		Cache.Hooks.Local[#Cache.Hooks.Local + 1] = {Type, Name}
		Log("Hook Added! [{%s} {%s}]", Type, Name)

		hook.Add(Type, Name, ENV.RegisterFunction(Function))
	end) 
	
	ENV.CreateFunction("AddConCommand", function(Name, Function)
		Log("ConCommand Added! " .. Name)
		
		concommand.Add(Name, ENV.RegisterFunction(Function))
	end)
	
	ENV.Log("Setting up Cache") -- This needs the colors

	ENV.g_bSendPacket = false
	ENV.g_iOriginalSequence = -1
	ENV.g_iPostSequence = -1

	ENV.g_bPseudoNoInterp = false
	ENV.g_bNoPlayerInterp = false
	ENV.g_bSequenceRan = false
	ENV.g_bInEnginePrediction = false
	ENV.g_bShouldEngineViewAngles = true

	ENV.g_vPunchAngle = ENV.Angle()
	ENV.g_vPunchAngleVel = ENV.Angle()

	-- Screen
	Cache.ScreenData.ScrW = ENV.ScrW()
	Cache.ScreenData.ScrH = ENV.ScrH()

	Cache.ScreenData.Center.X = ENV.math.floor(Cache.ScreenData.ScrW / 2)
	Cache.ScreenData.Center.Y = ENV.math.floor(Cache.ScreenData.ScrH / 2)

	-- ConVars
	Cache.ConVars.cl_forwardspeed = ENV.GetConVar("cl_forwardspeed")
	Cache.ConVars.cl_interp = ENV.GetConVar("cl_interp")
	Cache.ConVars.cl_interp_ratio = ENV.GetConVar("cl_interp_ratio")
	Cache.ConVars.cl_interpolate = ENV.GetConVar("cl_interpolate")
	Cache.ConVars.cl_sidespeed = ENV.GetConVar("cl_sidespeed")
	Cache.ConVars.cl_updaterate = ENV.GetConVar("cl_updaterate")


	Cache.ConVars.sv_maxunlag = ENV.GetConVar("sv_maxunlag")
	Cache.ConVars.sv_maxupdaterate = ENV.GetConVar("sv_maxupdaterate")
	Cache.ConVars.sv_minupdaterate = ENV.GetConVar("sv_minupdaterate")
	Cache.ConVars.sv_maxusrcmdprocessticks = ENV.GetConVar("sv_maxusrcmdprocessticks")
	Cache.ConVars.sv_client_max_interp_ratio = ENV.GetConVar("sv_client_max_interp_ratio")
	Cache.ConVars.sv_client_min_interp_ratio = ENV.GetConVar("sv_client_min_interp_ratio")

	Cache.ConVars.fov_desired = ENV.GetConVar("fov_desired")
	Cache.ConVars.m_pitch = ENV.GetConVar("m_pitch")
	Cache.ConVars.m_yaw = ENV.GetConVar("m_yaw")
	Cache.ConVars.view_recoil_tracking = ENV.GetConVar("view_recoil_tracking")

	Cache.ConVars.cl_weaponcolor = ENV.GetConVar("cl_weaponcolor")
	Cache.ConVars.name = ENV.GetConVar("name")
	Cache.ConVars.sv_skyname = ENV.GetConVar("sv_skyname")

	Cache.ConVars.sv_unlag = ENV.GetConVar("sv_unlag")
	Cache.ConVars.sv_maxvelocity = ENV.GetConVar("sv_maxvelocity")
	Cache.ConVars.sv_gravity = ENV.GetConVar("sv_gravity")

	Cache.ConVars.arccw_enable_penetration = ENV.GetConVar("arccw_enable_penetration")
	Cache.ConVars.M9KDisablePenetration = ENV.GetConVar("M9KDisablePenetration")
	Cache.ConVars.sv_tfa_bullet_penetration = ENV.GetConVar("sv_tfa_bullet_penetration")
	Cache.ConVars.sv_tfa_penetration_hardlimit = ENV.GetConVar("sv_tfa_penetration_hardlimit")
	Cache.ConVars.sv_tfa_bullet_penetration_power_mul = ENV.GetConVar("sv_tfa_bullet_penetration_power_mul")

	Cache.ConVars.ai_shot_bias_min = ENV.GetConVar("ai_shot_bias_min")
	Cache.ConVars.ai_shot_bias_max = ENV.GetConVar("ai_shot_bias_max")
	Cache.ConVars.swcs_weapon_sync_seed = ENV.GetConVar("swcs_weapon_sync_seed")
	Cache.ConVars.sv_tfa_recoil_legacy = ENV.GetConVar("sv_tfa_recoil_legacy")

	ENV.g_vPunchAngle = ENV.Angle()
	ENV.g_vPunchAngleVel = ENV.Angle()

	-- Uh
	Cache.TickInterval = ENV.engine.TickInterval()
	Cache.SecondInterval = 1 / Cache.TickInterval
	
	Cache.FacingAngle = ENV.g_pLocalPlayer:EyeAngles()
	Cache.AntiAimAngle = ENV.g_pLocalPlayer:EyeAngles()

	Cache.CalcViewData.Origin = ENV.g_pLocalPlayer:EyePos()
	Cache.CalcViewData.Angles = ENV.g_pLocalPlayer:EyeAngles()
	Cache.CalcViewData.FOV = ENV.g_pLocalPlayer:GetFOV()
	Cache.CalcViewData.ZNear = 3

	Cache.FOVTri = {{x = 0, y = 0}, {x = 0, y = 0}, {x = 0, y = 0}}

	-- setup
	
	ENV.CreateFunction("GetCachedPlayers", function(ValidOnly)
		if ValidOnly then
			local players = {}

			for i = 1, #Cache.Players do
				if not IsValid(Cache.Players[i]) then continue end

				players[#players + 1] = Cache.Players[i]
			end

			return players
		else
			return Cache.Players
		end
	end)

	ENV.CreateFunction("GetSortedPlayers", function()
		local players = GetCachedPlayers(true)
		local lpos = g_pLocalPlayer:GetPos()

		table.sort(players, function(a, b)
			return a:GetPos():DistToSqr(lpos) > b:GetPos():DistToSqr(lpos)
		end)

		return players
	end)

	ENV.Log("Setting up AutoShoot functions")

	Cache.WeaponData.AutoShoot.BaseFunctions.bobs = ENV.RegisterFunction(function(self)
		if self:Clip1() < 1 then return false end
		if self:GetNWBool("Reloading") then return false end

		local Owner = self:GetOwner()

		if not Owner:IsPlayer() then return false end
		if Owner:KeyDown(IN_RELOAD) then return false end

		return true
	end)

	Cache.WeaponData.AutoShoot.BaseFunctions.cw = ENV.RegisterFunction(function(self)
		if self:Clip1() == 0 then return false end
		if not self:canFireWeapon(1) or not self:canFireWeapon(2) or not self:canFireWeapon(3) then return false end
		if self:GetOwner():KeyDown(IN_USE) and rawget(rawget(CustomizableWeaponry, "quickGrenade"), "canThrow")(self) then return false end
		if self.dt.State == CW_AIMING and self.dt.M203Active and self.M203Chamber then return false end
		if self.dt.Safe then return false end
		if self.BurstAmount and self.BurstAmount > 0 then return false end

		return true
	end)

	Cache.WeaponData.AutoShoot.BaseFunctions.fas2 = ENV.RegisterFunction(function(self)
		if self:Clip1() <= 0 then return false end

		local Owner = self:GetOwner()

		if Owner:KeyDown(IN_USE) and self:CanThrowGrenade() then return false end
		if Owner:WaterLevel() >= 3 then return false end

		if self.FireMode == "safe" then return false end
		if self.BurstAmount > 0 and self.dt.Shots >= self.BurstAmount then return false end
		if self.ReloadState ~= 0 then return false end
		if self.dt.Status == FAS_STAT_CUSTOMIZE then return false end
		if self.Cooking or self.FuseTime then return false end
		if self.dt.Status == FAS_STAT_SPRINT or self.dt.Status == FAS_STAT_QUICKGRENADE then return false end
		if self.CockAfterShot and not self.Cocked then return false end

		return true
	end)

	Cache.WeaponData.AutoShoot.BaseFunctions.tfa = ENV.RegisterFunction(function(self)
		local RunResult = hook.Run("TFA_PreCanPrimaryAttack", self)
		if RunResult ~= nil then return RunResult end

		local Status = self:GetStatus()
		local EnumTable = rawget(TFA, "Enum")
		if Status == rawget(EnumTable, "STATUS_RELOADING_WAIT") or Status == rawget(EnumTable, "STATUS_RELOADING") then return false end

		if self:IsSafety() then return false end
		if self:GetSprintProgress() >= 0.1 and not self:GetStatL("AllowSprintAttack", false) then return false end
		if self:GetStatL("Primary.ClipSize") <= 0 and self:Ammo1() < self:GetStatL("Primary.AmmoConsumption") then return false end
		if self:GetPrimaryClipSize(true) > 0 and self:Clip1() < self:GetStatL("Primary.AmmoConsumption") then return false end
		if self:GetStatL("Primary.FiresUnderwater") == false and self:GetOwner():WaterLevel() >= 3 then return false end

		RunResult = hook.Run("TFA_CanPrimaryAttack", self)
		if RunResult ~= nil then return RunResult end

		if self:CheckJammed() then return false end

		return true
	end)

	Cache.WeaponData.AutoShoot.BaseFunctions.arccw = ENV.RegisterFunction(function(self)
		if IsValid(self:GetHolster_Entity()) then return false end
		if self:GetHolster_Time() > 0 then return false end
		if self:GetReloading() then return false end
		if self:GetWeaponOpDelay() > CurTime() then return false end
		if self:GetHeatLocked() then return false end
		if self:GetState() == rawget(ArcCW, "STATE_CUSTOMIZE") then return false end
		if self:BarrelHitWall() > 0 then return false end
		if self:GetNWState() == rawget(ArcCW, "STATE_SPRINT") and not (self:GetBuff_Override("Override_ShootWhileSprint", self.ShootWhileSprint)) then return false end
		if (self:GetBurstCount() or 0) >= self:GetBurstLength() then return false end
		if self:GetNeedCycle() then return false end
		if self:GetCurrentFiremode().Mode == 0 then return false end
		if self:GetBuff_Override("Override_TriggerDelay", self.TriggerDelay) and self:GetTriggerDelta() < 1 then return false end
		if self:GetBuff_Hook("Hook_ShouldNotFire") then return false end
		if self:GetBuff_Hook("Hook_ShouldNotFireFirst") then return false end

		return true
	end)

	ENV.Log("Setting up AutoWall functions")

	-- https://github.com/awesomeusername69420/miscellaneous-gmod-stuff/blob/main/Cheaterino/AutoWallTest.lua

	Cache.WeaponData.AutoWall.Functions.bobs = ENV.RegisterFunction(function(self, TraceData)
		if Cache.ConVars.M9KDisablePenetration:GetBool() then
			return nil
		end

		local DataTable = Cache.WeaponData.AutoWall.Limits[GetWeaponAmmoName(self)]
		if not DataTable then return nil end

		return DataTable[1], DataTable[2]
	end)

	Cache.WeaponData.AutoWall.Functions.tfa = ENV.RegisterFunction(function(self, TraceData)
		if not Cache.ConVars.sv_tfa_bullet_penetration:GetBool() then
			return nil
		end

		local ForceMultiplier = self:GetAmmoForceMultiplier()
		local PenetrationMultiplier = self:GetPenetrationMultiplier(TraceData.MatType)
		local ConVarMultiplier = Cache.ConVars.sv_tfa_bullet_penetration_power_mul:GetFloat()

		local DataTable = Cache.WeaponData.AutoWall.Limits[GetWeaponAmmoName(self)]
		local MaxPen = math.Clamp(DataTable and DataTable[2] or 1, 0, Cache.ConVars.sv_tfa_penetration_hardlimit:GetInt())

		return math.Truncate(((ForceMultiplier / PenetrationMultiplier) * ConVarMultiplier) * 0.9, 5), MaxPen
	end)

	Cache.WeaponData.AutoWall.Functions.arccw = ENV.RegisterFunction(function(self, TraceData)
		if not Cache.ConVars.arccw_enable_penetration:GetBool() then
			return nil
		end

		local DataTable = Cache.WeaponData.AutoWall.Limits[GetWeaponAmmoName(self)]
		return math.pow(self.Penetration, 2), DataTable and DataTable[2] or 1
	end)

	Cache.WeaponData.AutoWall.Functions.cw = ENV.RegisterFunction(function(self, TraceData)
		if not CWCanPenetrate(self, TraceData) then return nil end

		local Strength = self.PenStr * self.PenMod
		local Multiplier = self.PenetrationMaterialInteraction and self.PenetrationMaterialInteraction[TraceData.MatType] or 1
		return math.pow(Strength, 2) + (Strength * Multiplier), 1
	end)

	Cache.WeaponData.AutoWall.Functions.fas2 = ENV.RegisterFunction(function(self, TraceData)
		if not CWCanPenetrate(self, TraceData) then return nil end

		local Strength = self.PenStr * self.PenMod
		local Multiplier = Cache.WeaponData.AutoWall.Multipliers[TraceData.MatType] or 1
		return math.pow(Strength, 2) + (Strength * Multiplier), 1
	end)

	Cache.WeaponData.AutoWall.Functions.swb = ENV.RegisterFunction(function(self, TraceData)
		if not CWCanPenetrate(self, TraceData) then return nil end

		local DataTable = Cache.WeaponData.AutoWall.Limits[GetWeaponAmmoName(self)]
		if not DataTable then return nil end

		local Multiplier = Cache.WeaponData.AutoWall.Multipliers[TraceData.MatType] or 1
		return DataTable[1] * Multiplier * self.PenMod, 1
	end)

	do
		local rand = ENV.UniformRandomStream()

		for iSeed = 0, 255 do
			rand:SetSeed(iSeed)

			local x,y,z = 0, 0, 0
			local bias = 1


			local shotBiasMin = Cache.ConVars.ai_shot_bias_min:GetFloat()
			local shotBiasMax = Cache.ConVars.ai_shot_bias_max:GetFloat()

			local shotBias = ( ( shotBiasMax - shotBiasMin ) * bias ) + shotBiasMin
			local flatness = ENV.math.abs(shotBias) * 0.5

			repeat
				x = rand:RandomFloat(-1, 1) * flatness + rand:RandomFloat(-1, 1) * (1 - flatness)
				y = rand:RandomFloat(-1, 1) * flatness + rand:RandomFloat(-1, 1) * (1 - flatness)

				if shotBias < 0 then
					x = (x >= 0) and 1.0 - x or -1.0 - x
					y = (y >= 0) and 1.0 - y or -1.0 - y
				end

				z = (x * x) + (y * y)
			until z <= 1

			Cache.WeaponData.NoSpread.Seeds[iSeed] = {
				X = x,
				Y = y,
				Z = z
			}
		end
	end

	ENV.Log("Setting up NoSpread class functions")

	Cache.WeaponData.NoSpread.Storage.weapon_glock_hl1_attack = ENV.Vector(0.1, 0.1, 0.1)
	Cache.WeaponData.NoSpread.Storage.weapon_glock_hl1_neutral = ENV.Vector(0.01, 0.01, 0.01)
	Cache.WeaponData.NoSpread.Cones.weapon_glock_hl1 = ENV.RegisterFunction(function(Weapon, Command)
		if Command:KeyDown(IN_ATTACK) then
			return Cache.WeaponData.NoSpread.Storage.weapon_glock_hl1_attack
		else
			return Cache.WeaponData.NoSpread.Storage.weapon_glock_hl1_neutral
		end
	end)

	Cache.WeaponData.NoSpread.Storage.weapon_shotgun_hl1_attack = ENV.Vector(0.17432, 0.04358)
	Cache.WeaponData.NoSpread.Storage.weapon_shotgun_hl1_neutral = ENV.Vector(0.08716, 0.04358)
	Cache.WeaponData.NoSpread.Cones.weapon_shotgun_hl1 = ENV.RegisterFunction(function(Weapon, Command)
		if Command:KeyDown(IN_ATTACK) then
			return Cache.WeaponData.NoSpread.Storage.weapon_shotgun_hl1_attack
		else
			return Cache.WeaponData.NoSpread.Storage.weapon_shotgun_hl1_neutral
		end
	end)

	--[[
		Panel setup
	]]

	local fgui = ENV.fgui

	local MainFrame = fgui.Create("FHFrame")
	MainFrame:SetVisible(false)
	MainFrame:SetTitle("SqueelHack")
	MainFrame:SetSize(600, 700)
	MainFrame:SetDeleteOnClose(false)
	MainFrame:SetX((ScrW() / 2) - MainFrame:GetWide() - 10)
	MainFrame:CenterVertical()
	Cache.Panels.MainFrame = MainFrame
	
	MainFrame._OldPerformLayout = MainFrame.PerformLayout

	MainFrame.PerformLayout = ENV.RegisterFunction(function(self, w, h)
		MainFrame._OldPerformLayout(self, w, h)

		local MainFrameTabs = fgui.Create("FHTabbedMenu", self)
		MainFrameTabs:Dock(FILL)
		MainFrameTabs:SetTabBackground(true)
		
		local MainTabs = MainFrameTabs:AddTabs("Aimbot", "HvH", "ESP", "Visual", "Minge", "Miscellaneous", "ViewmodelChanger")

		/*
			Aimbot Tab
		*/
		
		local AimbotPanel = MainTabs[1]
		
		local AimBotSection = fgui.Create("FHSection", AimbotPanel)
		AimBotSection:SetSize(260, 195)
		AimBotSection:SetPos(5, 5)
		AimBotSection:SetTitle("Aimbot")

		local AimbotEnabled = fgui.Create("FHCheckBox", AimBotSection)
		AimbotEnabled:SetPos(20, 20)
		AimbotEnabled:SetText("Enabled")
		AimbotEnabled:SetVarTable(Vars.Aimbot, "Enabled")
		
		local AimbotSilent = fgui.Create("FHCheckBox", AimBotSection)
		AimbotSilent:SetPos(20, 45)
		AimbotSilent:SetText("Silent Aim")
		AimbotSilent:SetVarTable(Vars.Aimbot, "Silent")

		local AimbotAutoShoot = fgui.Create("FHCheckBox", AimBotSection)
		AimbotAutoShoot:SetPos(20, 70)
		AimbotAutoShoot:SetText("Auto Shoot")
		AimbotAutoShoot:SetVarTable(Vars.Aimbot, "AutoShoot")
		
		local AimbotUseContext = fgui.Create("FHCheckBox", AimBotSection)
		AimbotUseContext:SetPos(20, 95)
		AimbotUseContext:SetText("Use Context")
		AimbotUseContext:SetVarTable(Vars.Aimbot, "UseContext")

		local AimbotAutoFire = fgui.Create("FHCheckBox", AimBotSection)
		AimbotAutoFire:SetPos(20, 120)
		AimbotAutoFire:SetText("AutoFire")
		AimbotAutoFire:SetVarTable(Vars.Aimbot, "AutoFire")
		
		local AimbotMultiPoint = fgui.Create("FHCheckBox", AimBotSection)
		AimbotMultiPoint:SetPos(20, 145)
		AimbotMultiPoint:SetText("MultiPoint")
		AimbotMultiPoint:SetVarTable(Vars.Aimbot, "MultiPoint")
		
		local AimbotAutoShoot = fgui.Create("FHCheckBox", AimBotSection)
		AimbotAutoShoot:SetPos(150, 20)
		AimbotAutoShoot:SetText("Fire On Key")
		AimbotAutoShoot:SetVarTable(Vars.Aimbot, "FireOnKey")
		
		local AimbotKey = fgui.Create("FHBinder", AimBotSection)
		AimbotKey:SetSize(100, 25)
		AimbotKey:SetPos(150, 55)
		AimbotKey:SetLabel("Aim Key")
		AimbotKey:SetVarTable(Vars.Aimbot, "Key")
		
		local AimbotAimAtHitbox = fgui.Create("FHDropDown", AimBotSection)
		AimbotAimAtHitbox:SetSize(100, 20)
		AimbotAimAtHitbox:SetPos(150, 95)
		AimbotAimAtHitbox:AddChoice("Head", AIM_HITBOXES_HEAD)
		AimbotAimAtHitbox:AddChoice("Chest", AIM_HITBOXES_CHEST)
		AimbotAimAtHitbox:AddChoice("Stomach", AIM_HITBOXES_STOMACH)
		AimbotAimAtHitbox:AddChoice("Arms", AIM_HITBOXES_ARMS)
		AimbotAimAtHitbox:AddChoice("Legs", AIM_HITBOXES_ARMS)

		AimbotAimAtHitbox:ChooseOption("Head", AIM_HITBOXES_HEAD)

		AimbotAimAtHitbox.FHOnSelect = ENV.RegisterFunction(function(self, index, value, data)
			Vars.Aimbot.AimAtHitboxes = data
		end)
		
		local AimbotResolver = fgui.Create("FHCheckBox", AimBotSection)
		AimbotResolver:SetPos(150, 120)
		AimbotResolver:SetText("Resolver")
		AimbotResolver:SetVarTable(Vars.Aimbot, "Resolver")
		
		--- Triggerbot
		
		local TriggerBotSection = fgui.Create("FHSection", AimbotPanel)
		TriggerBotSection:SetSize(290, 195)
		TriggerBotSection:SetPos(275, 5)
		TriggerBotSection:SetTitle("TriggerBot")
		
		local TriggerBotEnabled = fgui.Create("FHCheckBox", TriggerBotSection)
		TriggerBotEnabled:SetPos(20, 20)
		TriggerBotEnabled:SetText("Enabled")
		TriggerBotEnabled:SetVarTable(Vars.Aimbot.TriggerBot, "Enabled")
		
		local TriggerBotHitBacktrack = fgui.Create("FHCheckBox", TriggerBotSection)
		TriggerBotHitBacktrack:SetPos(20, 70)
		TriggerBotHitBacktrack:SetText("Hit Backtrack")
		TriggerBotHitBacktrack:SetVarTable(Vars.Aimbot.TriggerBot, "HitBacktrack")
		
		local TriggerBotAutoWall = fgui.Create("FHCheckBox", TriggerBotSection)
		TriggerBotAutoWall:SetPos(20, 120)
		TriggerBotAutoWall:SetText("Auto Wall")
		TriggerBotAutoWall:SetVarTable(Vars.Aimbot.TriggerBot, "AutoWall")
		
		local TriggerBotCrosshair = fgui.Create("FHCheckBox", TriggerBotSection)
		TriggerBotCrosshair:SetPos(20, 170)
		TriggerBotCrosshair:SetText("On Crosshair")
		TriggerBotCrosshair:SetVarTable(Vars.Aimbot.TriggerBot, "Crosshair")
		
		local TriggerBotRapidFire = fgui.Create("FHCheckBox", TriggerBotSection)
		TriggerBotRapidFire:SetPos(20, 145)
		TriggerBotRapidFire:SetText("Rapid Fire")
		TriggerBotRapidFire:SetVarTable(Vars.Aimbot.TriggerBot, "RapidFire")
		
		local TriggerBotForcePacket = fgui.Create("FHCheckBox", TriggerBotSection)
		TriggerBotForcePacket:SetPos(150, 20)
		TriggerBotForcePacket:SetText("Force Packet")
		TriggerBotForcePacket:SetVarTable(Vars.Aimbot.TriggerBot, "ForcePacket")
		
		--- Nospread
		
		local NoSpreadSection = fgui.Create("FHSection", AimbotPanel)
		NoSpreadSection:SetSize(560, 100)
		NoSpreadSection:SetPos(5, 205)
		NoSpreadSection:SetTitle("NoSpread")
		
		local NospreadEnabled = fgui.Create("FHCheckBox", NoSpreadSection)
		NospreadEnabled:SetPos(20, 20)
		NospreadEnabled:SetText("Enabled")
		NospreadEnabled:SetVarTable(Vars.Aimbot.NoSpread, "Enabled")
		
		local NoSpreadUseContext = fgui.Create("FHCheckBox", NoSpreadSection)
		NoSpreadUseContext:SetPos(20, 45)
		NoSpreadUseContext:SetText("Use Context")
		NoSpreadUseContext:SetVarTable(Vars.Aimbot.NoSpread, "UseContext")

		local NoSpreadAntiRecoil = fgui.Create("FHCheckBox", NoSpreadSection)
		NoSpreadAntiRecoil:SetPos(20, 70)
		NoSpreadAntiRecoil:SetText("No Recoil")
		NoSpreadAntiRecoil:SetVarTable(Vars.Aimbot, "AntiRecoil")

		local NospreadEnabled = fgui.Create("FHCheckBox", NoSpreadSection)
		NospreadEnabled:SetPos(150, 20)
		NospreadEnabled:SetText("Seed Nospread")
		NospreadEnabled:SetVarTable(Vars.Aimbot.NoSpread, "Seed")
		
		---- Backtrack
		
		local BackTrackSection = fgui.Create("FHSection", AimbotPanel)
		BackTrackSection:SetSize(560, 100)
		BackTrackSection:SetPos(5, 310)
		BackTrackSection:SetTitle("Backtrack")
		
		local AimbotBackTrack = fgui.Create("FHCheckBox", BackTrackSection)
		AimbotBackTrack:SetPos(20, 20)
		AimbotBackTrack:SetText("Enabled")
		AimbotBackTrack:SetVarTable(Vars.Aimbot.Backtrack, "Enabled")
		
		local AimbotTickMod = fgui.Create("FHCheckBox", BackTrackSection)
		AimbotTickMod:SetPos(20, 45)
		AimbotTickMod:SetText("Tick Mod")
		AimbotTickMod:SetVarTable(Vars.Aimbot, "TickMod")
		
		local AimbotBackTrackAmount = fgui.Create("FHSlider", BackTrackSection)
		AimbotBackTrackAmount:SetText("Backtrack Amount")
		AimbotBackTrackAmount:SetPos(20, 61)
		AimbotBackTrackAmount:SetWide(400)
		AimbotBackTrackAmount:SetMinMax(0, 1)
		AimbotBackTrackAmount:SetDecimals(1)
		AimbotBackTrackAmount:SetVarTable(Vars.Aimbot.Backtrack, "Amount")
		
		--- Adjust Targeting
		
		local AimbotAdjustTargetingSection = fgui.Create("FHSection", AimbotPanel)
		AimbotAdjustTargetingSection:SetSize(560, 175)
		AimbotAdjustTargetingSection:SetPos(5, 415)
		AimbotAdjustTargetingSection:SetTitle("Adjust Targeting")
		
		local AimbotIgnoreWhiteList = fgui.Create("FHCheckBox", AimbotAdjustTargetingSection)
		AimbotIgnoreWhiteList:SetPos(20, 20)
		AimbotIgnoreWhiteList:SetText("Ignore Whitelist")
		AimbotIgnoreWhiteList:SetVarTable(Vars.Aimbot.WhiteList, "IgnoreWhiteList")
		
		local AimbotIgnorePlayers = fgui.Create("FHCheckBox", AimbotAdjustTargetingSection)
		AimbotIgnorePlayers:SetPos(20, 45)
		AimbotIgnorePlayers:SetText("Ignore Players")
		AimbotIgnorePlayers:SetVarTable(Vars.Aimbot.WhiteList, "IgnorePlayers")
		
		local AimbotIgnoreFriends = fgui.Create("FHCheckBox", AimbotAdjustTargetingSection)
		AimbotIgnoreFriends:SetPos(20, 70)
		AimbotIgnoreFriends:SetText("Ignore Friends")
		AimbotIgnoreFriends:SetVarTable(Vars.Aimbot.WhiteList, "IgnoreFriends")
		
		local AimbotIgnoreTeam = fgui.Create("FHCheckBox", AimbotAdjustTargetingSection)
		AimbotIgnoreTeam:SetPos(20, 95)
		AimbotIgnoreTeam:SetText("Ignore Team")
		AimbotIgnoreTeam:SetVarTable(Vars.Aimbot.WhiteList, "IgnoreTeam")
		
		local AimbotIgnoreNpcs = fgui.Create("FHCheckBox", AimbotAdjustTargetingSection)
		AimbotIgnoreNpcs:SetPos(20, 120)
		AimbotIgnoreNpcs:SetText("Ignore Npcs")
		AimbotIgnoreNpcs:SetVarTable(Vars.Aimbot.WhiteList, "IgnoreNpcs")
		
		local AimbotIgnoreBots = fgui.Create("FHCheckBox", AimbotAdjustTargetingSection)
		AimbotIgnoreBots:SetPos(20, 145)
		AimbotIgnoreBots:SetText("Ignore Bots")
		AimbotIgnoreBots:SetVarTable(Vars.Aimbot.WhiteList, "IgnoreBots")
		
		local AimbotAdjustSortMethod = fgui.Create("FHDropDown", AimbotAdjustTargetingSection)
		AimbotAdjustSortMethod:SetSize(100, 20)
		AimbotAdjustSortMethod:SetPos(150, 20)
		AimbotAdjustSortMethod:AddChoice("Crosshair", SORT_TYPE_CROSSHAIR)
		AimbotAdjustSortMethod:AddChoice("Health", SORT_TYPE_HEALTH)
		AimbotAdjustSortMethod:AddChoice("Distance", SORT_TYPE_DISTANCE)

		AimbotAdjustSortMethod:ChooseOption("Crosshair", SORT_TYPE_CROSSHAIR)
		AimbotAdjustSortMethod.FHOnSelect = ENV.RegisterFunction(function(self, index, value, data)
			Vars.Aimbot.SortMethod = data
		end)
		
		local AimbotAdjustAimConeType = fgui.Create("FHDropDown", AimbotAdjustTargetingSection)
		AimbotAdjustAimConeType:SetSize(100, 20)
		AimbotAdjustAimConeType:SetPos(150, 45)
		AimbotAdjustAimConeType:AddChoice("Circle", "Circle")
		AimbotAdjustAimConeType:AddChoice("Triangle", "Triangle")
		AimbotAdjustAimConeType:ChooseOption("Circle", "Circle")
		
		AimbotAdjustAimConeType.FHOnSelect = ENV.RegisterFunction(function(self, index, value, data)
			Vars.Aimbot.AimCone.Shape = data
		end)
		
		local AimbotAdjustAimCone = fgui.Create("FHCheckBox", AimbotAdjustTargetingSection)
		AimbotAdjustAimCone:SetPos(150, 70)
		AimbotAdjustAimCone:SetText("Aim Cone")
		AimbotAdjustAimCone:SetVarTable(Vars.Aimbot.AimCone, "Enabled")

		local AimbotAdjustAimConeFov = fgui.Create("FHSlider", AimbotAdjustTargetingSection)
		AimbotAdjustAimConeFov:SetText("Cone Fov")
		AimbotAdjustAimConeFov:SetPos(150, 86)
		AimbotAdjustAimConeFov:SetWide(400)
		AimbotAdjustAimConeFov:SetMinMax(0, 60)
		AimbotAdjustAimConeFov:SetDecimals(0)
		AimbotAdjustAimConeFov:SetVarTable(Vars.Aimbot.AimCone, "FOV")
		
		local AimbotSticky = fgui.Create("FHCheckBox", AimbotAdjustTargetingSection)
		AimbotSticky:SetPos(150, 120)
		AimbotSticky:SetText("Target Lock")
		AimbotSticky:SetVarTable(Vars.Aimbot, "Sticky")
		
		-- 280 
		local AimbotAimConeColor = fgui.Create("FHColorButton", AimbotAdjustTargetingSection)		
		AimbotAimConeColor:SetPos(280, 20)
		AimbotAimConeColor:SetSize(100, 25)
		AimbotAimConeColor:SetText("Aim Cone Color")
		AimbotAimConeColor:SetVarTable(Vars.Aimbot.AimCone, "Color")
		
		/*
			HvH Tab
		*/
		
		local HvHPanel = MainTabs[2]

		local HvHAntiAimSection = fgui.Create("FHSection", HvHPanel)
		HvHAntiAimSection:SetSize(560, 510)
		HvHAntiAimSection:SetPos(5, 5)
		HvHAntiAimSection:SetTitle("Anti Aim")
		
		local HvHAntiAimEnabled = fgui.Create("FHCheckBox", HvHAntiAimSection)
		HvHAntiAimEnabled:SetPos(20, 20)
		HvHAntiAimEnabled:SetText("Enabled")
		HvHAntiAimEnabled:SetVarTable(Vars.HvH.AntiAim, "Enabled")
		
		local HvHAntiAimPitch = fgui.Create("FHDropDown", HvHAntiAimSection)
		HvHAntiAimPitch:SetSize(100, 20)
		HvHAntiAimPitch:SetPos(45, 45)
		HvHAntiAimPitch:AddChoice("None", ANTIAIM_X_NONE)
		HvHAntiAimPitch:AddChoice("Up", ANTIAIM_X_STATIC_UP)
		HvHAntiAimPitch:AddChoice("Down", ANTIAIM_X_STATIC_DOWN)
		HvHAntiAimPitch:AddChoice("Jitter", ANTIAIM_X_DANCE)
		HvHAntiAimPitch:AddChoice("Front", ANTIAIM_X_FRONT)
		HvHAntiAimPitch:AddChoice("Custom", ANTIAIM_X_CUSTOM)		
		HvHAntiAimPitch:AddChoice("Fake Up", ANTIAIM_X_STATIC_UP_FAKE)
		HvHAntiAimPitch:AddChoice("Fake Down", ANTIAIM_X_STATIC_DOWN_FAKE) 
		HvHAntiAimPitch:AddChoice("Fake Zero Down", ANTIAIM_X_FAKE_ZERO_DOWN)
		HvHAntiAimPitch:ChooseOption("None", ANTIAIM_X_NONE)
		HvHAntiAimPitch.FHOnSelect = ENV.RegisterFunction(function(self, index, value, data)
			Vars.HvH.AntiAim.Pitch = data
		end)
		
		local HvHAntiAimYaw = fgui.Create("FHDropDown", HvHAntiAimSection)
		HvHAntiAimYaw:SetSize(100, 20)
		HvHAntiAimYaw:SetPos(45, 70)
		HvHAntiAimYaw:AddChoice("None", ANTIAIM_Y_NONE)
		HvHAntiAimYaw:AddChoice("Spin Custom", ANTIAIM_Y_SPIN_FAST)
		HvHAntiAimYaw:AddChoice("Spin", ANTIAIM_Y_SPIN_SLOW)
		HvHAntiAimYaw:AddChoice("Jitter", ANTIAIM_Y_JITTER)
		HvHAntiAimYaw:AddChoice("Jitter Backwards", ANTIAIM_Y_JITTER_BACKWARDS)
		HvHAntiAimYaw:AddChoice("Side", ANTIAIM_Y_SIDE)
		HvHAntiAimYaw:AddChoice("Backwards", ANTIAIM_Y_BACKWARDS)
		HvHAntiAimYaw:AddChoice("Forwards", ANTIAIM_Y_FORWARDS) 
		HvHAntiAimYaw:AddChoice("Edge", ANTIAIM_Y_EDGE)
		HvHAntiAimYaw:AddChoice("Fake Edge", ANTIAIM_Y_FAKE_EDGE)
		HvHAntiAimYaw:AddChoice("Static Jitter", ANTIAIM_Y_STATIC_JITTER)
		HvHAntiAimYaw:AddChoice("Fake Forwards", ANTIAIM_Y_FAKE_FORWARDS)
		HvHAntiAimYaw:AddChoice("Fake Sideways", ANTIAIM_Y_FAKE_SIDEWAYS)
		HvHAntiAimYaw:AddChoice("Fake Spin Custom", ANTIAIM_Y_FAKE_SPIN_FAST)
		HvHAntiAimYaw:AddChoice("Fake Spin", ANTIAIM_Y_FAKE_SPIN_SLOW)
		HvHAntiAimYaw:AddChoice("Fake Sin Wave", ANTIAIM_Y_FAKE_SINWAVE)
		HvHAntiAimYaw:AddChoice("Fake Custom", ANTIAIM_Y_FAKE_CUSTOM)
		HvHAntiAimYaw:AddChoice("Fuck Everything Up", ANTIAIM_Y_FAKE_FUCK)
		HvHAntiAimYaw:ChooseOption("None", ANTIAIM_Y_NONE)
		HvHAntiAimYaw.FHOnSelect = ENV.RegisterFunction(function(self, index, value, data)
			Vars.HvH.AntiAim.Yaw = data
		end)
		
		local HvHAntiAimRealPitch = fgui.Create("FHSlider", HvHAntiAimSection)
		HvHAntiAimRealPitch:SetText("Pitch")
		HvHAntiAimRealPitch:SetPos(45, 86)
		HvHAntiAimRealPitch:SetWide(400)
		HvHAntiAimRealPitch:SetMinMax(-90, 90)
		HvHAntiAimRealPitch:SetDecimals(0)
		HvHAntiAimRealPitch:SetVarTable(Vars.HvH.AntiAim, "CustomPitch")
		
		local HvHAntiAimRealPitch = fgui.Create("FHSlider", HvHAntiAimSection)
		HvHAntiAimRealPitch:SetText("Real Yaw")
		HvHAntiAimRealPitch:SetPos(45, 136)
		HvHAntiAimRealPitch:SetWide(400)
		HvHAntiAimRealPitch:SetMinMax(-180, 180)
		HvHAntiAimRealPitch:SetDecimals(0)
		HvHAntiAimRealPitch:SetVarTable(Vars.HvH.AntiAim.CustomYaw, "Real")
		
		local HvHAntiAimFakePitch = fgui.Create("FHSlider", HvHAntiAimSection)
		HvHAntiAimFakePitch:SetText("Fake Yaw")
		HvHAntiAimFakePitch:SetPos(45, 161)
		HvHAntiAimFakePitch:SetWide(400)
		HvHAntiAimFakePitch:SetMinMax(-180, 180)
		HvHAntiAimFakePitch:SetDecimals(0)
		HvHAntiAimFakePitch:SetVarTable(Vars.HvH.AntiAim.CustomYaw, "Fake")
		
		local HvHAntiFollowTarget = fgui.Create("FHCheckBox", HvHAntiAimSection)
		HvHAntiFollowTarget:SetPos(45, 197)
		HvHAntiFollowTarget:SetText("Follow Target")
		HvHAntiFollowTarget:SetVarTable(Vars.HvH.AntiAim, "FollowTarget")
		
		local HvHAntiAimSpinSpeed = fgui.Create("FHSlider", HvHAntiAimSection)
		HvHAntiAimSpinSpeed:SetText("Spin Speed")
		HvHAntiAimSpinSpeed:SetPos(45, 236)
		HvHAntiAimSpinSpeed:SetWide(400)
		HvHAntiAimSpinSpeed:SetMinMax(0, 2000)
		HvHAntiAimSpinSpeed:SetDecimals(0)
		HvHAntiAimSpinSpeed:SetVarTable(Vars.HvH.AntiAim, "SpinSpeed")
		
		local HvHAntiAimSpinSpeed = fgui.Create("FHSlider", HvHAntiAimSection)
		HvHAntiAimSpinSpeed:SetText("Edge Wall")
		HvHAntiAimSpinSpeed:SetPos(45, 260)
		HvHAntiAimSpinSpeed:SetWide(400)
		HvHAntiAimSpinSpeed:SetMinMax(0, 360)
		HvHAntiAimSpinSpeed:SetDecimals(0)
		HvHAntiAimSpinSpeed:SetVarTable(Vars.HvH.AntiAim.Edge, "Wall")
		
		local HvHAntiAimSpinSpeed = fgui.Create("FHSlider", HvHAntiAimSection)
		HvHAntiAimSpinSpeed:SetText("Edge Corner")
		HvHAntiAimSpinSpeed:SetPos(45, 286)
		HvHAntiAimSpinSpeed:SetWide(400)
		HvHAntiAimSpinSpeed:SetMinMax(0, 360)
		HvHAntiAimSpinSpeed:SetDecimals(0)
		HvHAntiAimSpinSpeed:SetVarTable(Vars.HvH.AntiAim.Edge, "Corner")
		
		
		local HvHAntiAimLbyBreaker = fgui.Create("FHCheckBox", HvHAntiAimSection)
		HvHAntiAimLbyBreaker:SetPos(45, 320)
		HvHAntiAimLbyBreaker:SetText("LBY Breaker")
		HvHAntiAimLbyBreaker:SetVarTable(Vars.HvH.AntiAim.LbyBreaker, "Enabled")
		
		local HvHAntiAimLbyBreakerDelta = fgui.Create("FHSlider", HvHAntiAimSection)
		HvHAntiAimLbyBreakerDelta:SetText("Breaker Delta")
		HvHAntiAimLbyBreakerDelta:SetPos(45, 336)
		HvHAntiAimLbyBreakerDelta:SetWide(400)
		HvHAntiAimLbyBreakerDelta:SetMinMax(-90, 90)
		HvHAntiAimLbyBreakerDelta:SetDecimals(0)
		HvHAntiAimLbyBreakerDelta:SetVarTable(Vars.HvH.AntiAim.LbyBreaker, "Delta")
		
		local HvHAntiAimActFakeDuck = fgui.Create("FHCheckBox", HvHAntiAimSection)
		HvHAntiAimActFakeDuck:SetPos(20, 397)
		HvHAntiAimActFakeDuck:SetText("Fake Duck")
		HvHAntiAimActFakeDuck:SetVarTable(Vars.HvH.FakeDuck, "Enabled")
		
		local HvHAntiAimActFakeDuckKey = fgui.Create("FHBinder", HvHAntiAimSection)
		HvHAntiAimActFakeDuckKey:SetSize(100, 25)
		HvHAntiAimActFakeDuckKey:SetPos(45, 427)
		HvHAntiAimActFakeDuckKey:SetLabel("Fake Duck Key")
		HvHAntiAimActFakeDuckKey:SetVarTable(Vars.HvH.FakeDuck, "Key")
		
		local HvHFakeLagSection = fgui.Create("FHSection", HvHPanel)
		HvHFakeLagSection:SetSize(560, 115)
		HvHFakeLagSection:SetPos(5, 520)
		HvHFakeLagSection:SetTitle("Fake Lag")

		local HvHFakeLagEnabled = fgui.Create("FHCheckBox", HvHFakeLagSection)
		HvHFakeLagEnabled:SetPos(20, 20)
		HvHFakeLagEnabled:SetText("Enabled")
		HvHFakeLagEnabled:SetVarTable(Vars.HvH.FakeLag, "Enabled")
		
		local HvHFakeLagChoke = fgui.Create("FHSlider", HvHFakeLagSection)
		HvHFakeLagChoke:SetText("Choke")
		HvHFakeLagChoke:SetPos(45, 31)
		HvHFakeLagChoke:SetWide(400)
		HvHFakeLagChoke:SetMinMax(0, 21)
		HvHFakeLagChoke:SetDecimals(0)
		HvHFakeLagChoke:SetVarTable(Vars.HvH.FakeLag, "Choke")
		
		local HvHFakeLagAdaptive = fgui.Create("FHCheckBox", HvHFakeLagSection)
		HvHFakeLagAdaptive:SetPos(45, 65)
		HvHFakeLagAdaptive:SetText("Adaptive")
		HvHFakeLagAdaptive:SetVarTable(Vars.HvH.FakeLag, "Adaptive")

		local HvHFakeLagFuckTicks = fgui.Create("FHCheckBox", HvHFakeLagSection)
		HvHFakeLagFuckTicks:SetPos(45, 90)
		HvHFakeLagFuckTicks:SetText("FuckTicks")
		HvHFakeLagFuckTicks:SetVarTable(Vars.HvH.FakeLag, "FuckTicks")
		
		/*
			ESP Tab
		*/
		
		local ESPPanel = MainTabs[3]

		local ESPPLayerESPSection = fgui.Create("FHSection", ESPPanel)
		ESPPLayerESPSection:SetSize(270, 315)
		ESPPLayerESPSection:SetPos(5, 5)
		ESPPLayerESPSection:SetTitle("Player ESP")

		local ESPPLayerESPEnabled = fgui.Create("FHCheckBox", ESPPLayerESPSection)
		ESPPLayerESPEnabled:SetPos(20, 20)
		ESPPLayerESPEnabled:SetText("Enabled")
		ESPPLayerESPEnabled:SetVarTable(Vars.ESP, "Enabled")

		local ESPPLayerESPName = fgui.Create("FHCheckBox", ESPPLayerESPSection)
		ESPPLayerESPName:SetPos(40, 45)
		ESPPLayerESPName:SetText("Name ESP")
		ESPPLayerESPName:SetVarTable(Vars.ESP, "Name")

		local ESPPLayerESPBox = fgui.Create("FHCheckBox", ESPPLayerESPSection)
		ESPPLayerESPBox:SetPos(40, 70)
		ESPPLayerESPBox:SetText("Box ESP")
		ESPPLayerESPBox:SetVarTable(Vars.ESP, "Box")

		local ESPPLayerES3DPBox = fgui.Create("FHCheckBox", ESPPLayerESPSection)
		ESPPLayerES3DPBox:SetPos(40, 95)
		ESPPLayerES3DPBox:SetText("3D Box ESP")
		ESPPLayerES3DPBox:SetVarTable(Vars.ESP, "Box3D")

		local ESPPLayerESPWeapon = fgui.Create("FHCheckBox", ESPPLayerESPSection)
		ESPPLayerESPWeapon:SetPos(40, 120)
		ESPPLayerESPWeapon:SetText("Weapon ESP")
		ESPPLayerESPWeapon:SetVarTable(Vars.ESP, "Weapon")

		local ESPPLayerESPHealthEnabled = fgui.Create("FHCheckBox", ESPPLayerESPSection)
		ESPPLayerESPHealthEnabled:SetPos(40, 145)
		ESPPLayerESPHealthEnabled:SetText("Health Information")
		ESPPLayerESPHealthEnabled:SetVarTable(Vars.ESP.Health, "Enabled")

		local ESPPLayerESPHealthBar = fgui.Create("FHCheckBox", ESPPLayerESPSection)
		ESPPLayerESPHealthBar:SetPos(60, 170)
		ESPPLayerESPHealthBar:SetText("Health Bar")
		ESPPLayerESPHealthBar:SetVarTable(Vars.ESP.Health, "Bar")

		local ESPPLayerESPHealthAmount = fgui.Create("FHCheckBox", ESPPLayerESPSection)
		ESPPLayerESPHealthAmount:SetPos(60, 195)
		ESPPLayerESPHealthAmount:SetText("Health Amount")
		ESPPLayerESPHealthAmount:SetVarTable(Vars.ESP.Health, "Amount")

		local ESPPlayerESPSkeleton = fgui.Create("FHCheckBox", ESPPLayerESPSection)
		ESPPlayerESPSkeleton:SetPos(40, 220)
		ESPPlayerESPSkeleton:SetText("Skeleton ESP")
		ESPPlayerESPSkeleton:SetVarTable(Vars.ESP.Bones, "Enabled")

		local ESPPlayerESPFlags = fgui.Create("FHCheckBox", ESPPLayerESPSection)
		ESPPlayerESPFlags:SetPos(40, 245)
		ESPPlayerESPFlags:SetText("Player Flags")
		ESPPlayerESPFlags:SetVarTable(Vars.ESP, "Flags")

		local ESPPlayerESPAvatar = fgui.Create("FHCheckBox", ESPPLayerESPSection)
		ESPPlayerESPAvatar:SetPos(40, 295)
		ESPPlayerESPAvatar:SetText("Avatar")
		ESPPlayerESPAvatar:SetVarTable(Vars.ESP, "Avatar")
		
		-----------------
		
		local ESPEntityESPSection = fgui.Create("FHSection", ESPPanel)
		ESPEntityESPSection:SetSize(280, 315)
		ESPEntityESPSection:SetPos(285, 5)
		ESPEntityESPSection:SetTitle("Entity ESP")
		
		local ESPEntityESPEnabled = fgui.Create("FHCheckBox", ESPEntityESPSection)
		ESPEntityESPEnabled:SetPos(20, 20)
		ESPEntityESPEnabled:SetText("Enabled")
		ESPEntityESPEnabled:SetVarTable(Vars.EntityESP, "Enabled")
		
		local ESPEntityESPName = fgui.Create("FHCheckBox", ESPEntityESPSection)
		ESPEntityESPName:SetPos(40, 95)
		ESPEntityESPName:SetText("Name")
		ESPEntityESPName:SetVarTable(Vars.EntityESP, "Name")

		local ESPEntityESPBox = fgui.Create("FHCheckBox", ESPEntityESPSection)
		ESPEntityESPBox:SetPos(40, 45)
		ESPEntityESPBox:SetText("Box")
		ESPEntityESPBox:SetVarTable(Vars.EntityESP, "Box")

		local ESPEntityESP3DBox = fgui.Create("FHCheckBox", ESPEntityESPSection)
		ESPEntityESP3DBox:SetPos(40, 70)
		ESPEntityESP3DBox:SetText("3D Box")
		ESPEntityESP3DBox:SetVarTable(Vars.EntityESP, "3DBox")

		local ESPEntityWeapon = fgui.Create("FHCheckBox", ESPEntityESPSection)
		ESPEntityWeapon:SetPos(40, 120)
		ESPEntityWeapon:SetText("Weapon")
		ESPEntityWeapon:SetVarTable(Vars.EntityESP, "Weapon")

		local ESPEntitSkeleton = fgui.Create("FHCheckBox", ESPEntityESPSection)
		ESPEntitSkeleton:SetPos(40, 145)
		ESPEntitSkeleton:SetText("Skeleton")
		ESPEntitSkeleton:SetVarTable(Vars.EntityESP, "Skeleton")

		local ESPEntitHealthBar = fgui.Create("FHCheckBox", ESPEntityESPSection)
		ESPEntitHealthBar:SetPos(40, 170)
		ESPEntitHealthBar:SetText("HealthBar")
		ESPEntitHealthBar:SetVarTable(Vars.EntityESP, "HealthBar")

		/*
			Visual Tab
		*/
		
		local VisualPanel = MainTabs[4]
		
		local VisualChamsSection = fgui.Create("FHSection", VisualPanel)
		VisualChamsSection:SetSize(560, 185)
		VisualChamsSection:SetPos(5, 5)
		VisualChamsSection:SetTitle("Chams")
		
		local VisualChamsPlayer = fgui.Create("FHCheckBox", VisualChamsSection)
		VisualChamsPlayer:SetPos(20, 20)
		VisualChamsPlayer:SetText("Player Chams")
		VisualChamsPlayer:SetVarTable(Vars.Visuals.Chams.Player, "Enabled")
		
		
		local VisualChamColor = fgui.Create("FHColorButton", VisualChamsSection)
		VisualChamColor:SetPos(20, 40)
		VisualChamColor:SetSize(100, 25)
		VisualChamColor:SetText("Player Color")
		VisualChamColor:SetVarTable(Vars.Visuals.Chams.Player, "Color")

		local VisualChamMaterial = fgui.Create("FHDropDown", VisualChamsSection)
		VisualChamMaterial:SetSize(100, 20)
		VisualChamMaterial:SetPos(20, 70)
		VisualChamMaterial:AddChoice("Goo", "goo")
		VisualChamMaterial:AddChoice("Flat", "flat")
		VisualChamMaterial:AddChoice("Camo", "camo")
		VisualChamMaterial:AddChoice("Funky", "funky")
		VisualChamMaterial:AddChoice("Water", "water")
		VisualChamMaterial:AddChoice("Cherry", "cherry")
		VisualChamMaterial:AddChoice("Metallic", "metallic")
		VisualChamMaterial:ChooseOption("Metallic", "Metallic")
		
		VisualChamMaterial.FHOnSelect = ENV.RegisterFunction(function(self, index, value, data)
			Vars.Visuals.Chams.Player.Material = data
		end)
		
		local VisualChamPlayerAccentColor = fgui.Create("FHColorButton", VisualChamsSection)
		VisualChamPlayerAccentColor:SetPos(20, 95)
		VisualChamPlayerAccentColor:SetSize(100, 25)
		VisualChamPlayerAccentColor:SetText("OverLay color")
		VisualChamPlayerAccentColor:SetVarTable(Vars.Visuals.Chams.Player.OverLay, "Color")

		local VisualChamPlayerAccentMaterial = fgui.Create("FHDropDown", VisualChamsSection)
		VisualChamPlayerAccentMaterial:SetSize(100, 20)
		VisualChamPlayerAccentMaterial:SetPos(20, 125)
		VisualChamPlayerAccentMaterial:AddChoice("Glow", "glow")
		VisualChamPlayerAccentMaterial:AddChoice("Wireframe", "wireframe")
		VisualChamPlayerAccentMaterial:AddChoice("Glowframe", "glowframe")
		VisualChamPlayerAccentMaterial:AddChoice("Fireframe", "fireframe")
		VisualChamPlayerAccentMaterial:AddChoice("Pulseframe", "pulseframe")
		VisualChamPlayerAccentMaterial:AddChoice("IslandWater", "islandwater")
		VisualChamPlayerAccentMaterial:ChooseOption("Wireframe", "wireframe")
		
		VisualChamPlayerAccentMaterial.FHOnSelect = ENV.RegisterFunction(function(self, index, value, data)
			Vars.Visuals.Chams.Player.OverLay.Material = data
		end)
		
		-------- view mdeopl

		local VisualChamsPlayerViewModel = fgui.Create("FHCheckBox", VisualChamsSection)
		VisualChamsPlayerViewModel:SetPos(280, 20)
		VisualChamsPlayerViewModel:SetText("View Model Chams")
		VisualChamsPlayerViewModel:SetVarTable(Vars.Visuals.Chams.Player.Local.ViewModel, "Enabled")
		
		local VisualChamPlayerWeaponColor = fgui.Create("FHColorButton", VisualChamsSection)
		VisualChamPlayerWeaponColor:SetPos(280, 40)
		VisualChamPlayerWeaponColor:SetSize(100, 25)
		VisualChamPlayerWeaponColor:SetText("VM Color")
		VisualChamPlayerWeaponColor:SetVarTable(Vars.Visuals.Chams.Player.Local.ViewModel, "Color")

		local VisualChamPlayerWeaponMaterial = fgui.Create("FHDropDown", VisualChamsSection)
		VisualChamPlayerWeaponMaterial:SetSize(100, 20)
		VisualChamPlayerWeaponMaterial:SetPos(280, 70)
		VisualChamPlayerWeaponMaterial:AddChoice("Goo", "goo")
		VisualChamPlayerWeaponMaterial:AddChoice("Flat", "flat")
		VisualChamPlayerWeaponMaterial:AddChoice("Glow", "glow")
		VisualChamPlayerWeaponMaterial:AddChoice("Camo", "camo")
		VisualChamPlayerWeaponMaterial:AddChoice("Funky", "funky")
		VisualChamPlayerWeaponMaterial:AddChoice("Water", "water")
		VisualChamPlayerWeaponMaterial:AddChoice("Cherry", "cherry")
		VisualChamPlayerWeaponMaterial:AddChoice("Metallic", "metallic")
		VisualChamPlayerWeaponMaterial:AddChoice("Wireframe", "wireframe")
		VisualChamPlayerWeaponMaterial:AddChoice("Glowframe", "glowframe")
		VisualChamPlayerWeaponMaterial:AddChoice("Fireframe", "fireframe")
		VisualChamPlayerWeaponMaterial:AddChoice("Pulseframe", "pulseframe")
		VisualChamPlayerWeaponMaterial:AddChoice("IslandWater", "islandwater")
		VisualChamPlayerWeaponMaterial:AddChoice("islandframe", "islandframe")

		VisualChamPlayerWeaponMaterial:ChooseOption("Wireframe", "wireframe")
		VisualChamPlayerWeaponMaterial.FHOnSelect = ENV.RegisterFunction(function(self, index, value, data)
			Vars.Visuals.Chams.Player.Local.ViewModel.Material = data
		end)
		
		------ entity chams
		
		local VisualChamsEntity = fgui.Create("FHCheckBox", VisualChamsSection)
		VisualChamsEntity:SetPos(410, 20)
		VisualChamsEntity:SetText("Prop Chams")
		VisualChamsEntity:SetVarTable(Vars.Visuals.Chams.Entity, "Enabled")
		
		local VisualChamColor = fgui.Create("FHColorButton", VisualChamsSection)
		VisualChamColor:SetPos(410, 40)
		VisualChamColor:SetSize(100, 25)
		VisualChamColor:SetText("Prop Color")
		VisualChamColor:SetVarTable(Vars.Visuals.Chams.Entity, "Color")

		local VisualChamMaterial = fgui.Create("FHDropDown", VisualChamsSection)
		VisualChamMaterial:SetSize(100, 20)
		VisualChamMaterial:SetPos(410, 70)
		VisualChamMaterial:AddChoice("Goo", "goo")
		VisualChamMaterial:AddChoice("Flat", "flat")
		VisualChamMaterial:AddChoice("Camo", "camo")
		VisualChamMaterial:AddChoice("Funky", "funky")
		VisualChamMaterial:AddChoice("Water", "water")
		VisualChamMaterial:AddChoice("Cherry", "cherry")
		VisualChamMaterial:AddChoice("Metallic", "metallic")
		VisualChamMaterial:ChooseOption("Metallic", "Metallic")
		
		VisualChamMaterial.FHOnSelect = ENV.RegisterFunction(function(self, index, value, data)
			Vars.Visuals.Chams.Entity.Material = data
		end)
		
		local VisualChamPlayerAccentColor = fgui.Create("FHColorButton", VisualChamsSection)
		VisualChamPlayerAccentColor:SetPos(410, 95)
		VisualChamPlayerAccentColor:SetSize(100, 25)
		VisualChamPlayerAccentColor:SetText("Accent color")
		VisualChamPlayerAccentColor:SetVarTable(Vars.Visuals.Chams.Entity.OverLay, "Color")

		local VisualChamPlayerAccentMaterial = fgui.Create("FHDropDown", VisualChamsSection)
		VisualChamPlayerAccentMaterial:SetSize(100, 20)
		VisualChamPlayerAccentMaterial:SetPos(410, 125)
		VisualChamPlayerAccentMaterial:AddChoice("Glow", "glow")
		VisualChamPlayerAccentMaterial:AddChoice("Wireframe", "wireframe")
		VisualChamPlayerAccentMaterial:AddChoice("Glowframe", "glowframe")
		VisualChamPlayerAccentMaterial:AddChoice("Fireframe", "fireframe")
		VisualChamPlayerAccentMaterial:AddChoice("Pulseframe", "pulseframe")
		VisualChamPlayerAccentMaterial:AddChoice("IslandWater", "islandwater")
		VisualChamPlayerAccentMaterial:ChooseOption("Wireframe", "wireframe")
		
		VisualChamPlayerAccentMaterial.FHOnSelect = ENV.RegisterFunction(function(self, index, value, data)
			Vars.Visuals.Chams.Entity.OverLay.Material = data
		end)

		------
		
		local VisualBacktrackSection = fgui.Create("FHSection", VisualPanel)
		VisualBacktrackSection:SetSize(560, 125)
		VisualBacktrackSection:SetPos(5, 195)
		VisualBacktrackSection:SetTitle("Backtrack")
		
		local ESPBacktrackEnabled = fgui.Create("FHCheckBox", VisualBacktrackSection)
		ESPBacktrackEnabled:SetPos(20, 20)
		ESPBacktrackEnabled:SetText("Show Backtrack")
		ESPBacktrackEnabled:SetVarTable(Vars.Visuals.Backtrack, "Enabled")

		local ESPBacktrackVisualStyle = fgui.Create("FHDropDown", VisualBacktrackSection)
		ESPBacktrackVisualStyle:SetSize(100, 20)
		ESPBacktrackVisualStyle:SetPos(150, 20)
		ESPBacktrackVisualStyle:AddChoice("Hitbox", BACKTRACK_VISUAL_STYLE_HITBOX)
		ESPBacktrackVisualStyle:AddChoice("Ghost", BACKTRACK_VISUAL_STYLE_GHOST)
		ESPBacktrackVisualStyle:ChooseOption("Hitbox", BACKTRACK_VISUAL_STYLE_HITBOX)
		ESPBacktrackVisualStyle.FHOnSelect = ENV.RegisterFunction(function(self, index, value, data)
			Vars.Visuals.Backtrack.VisualStyle = data
		end)
		
		local VisualBacktrackInverseOrder = fgui.Create("FHCheckBox", VisualBacktrackSection)
		VisualBacktrackInverseOrder:SetPos(20, 45)
		VisualBacktrackInverseOrder:SetText("Inverse Order")
		VisualBacktrackInverseOrder:SetVarTable(Vars.Visuals.Backtrack, "InverseOrder")
		
		local VisualBacktrackOnlyAimTarget = fgui.Create("FHCheckBox", VisualBacktrackSection)
		VisualBacktrackOnlyAimTarget:SetPos(20, 70)
		VisualBacktrackOnlyAimTarget:SetText("Only Target")
		VisualBacktrackOnlyAimTarget:SetVarTable(Vars.Visuals.Backtrack, "OnlyAimTarget")
		
		local VisualBacktrackColor = fgui.Create("FHColorButton", VisualBacktrackSection)		
		VisualBacktrackColor:SetPos(20, 90)
		VisualBacktrackColor:SetSize(100, 25)
		VisualBacktrackColor:SetText("Backtrack Color")
		VisualBacktrackColor:SetVarTable(Vars.Visuals.Backtrack, "Color")
		
		------`
		
		local VisualTracerskSection = fgui.Create("FHSection", VisualPanel)
		VisualTracerskSection:SetSize(560, 100)
		VisualTracerskSection:SetPos(5, 325)
		VisualTracerskSection:SetTitle("Tracers")
		
		local VisualPlayerTracers = fgui.Create("FHCheckBox", VisualTracerskSection)
		VisualPlayerTracers:SetPos(20, 20)
		VisualPlayerTracers:SetText("Player Tracers")
		VisualPlayerTracers:SetVarTable(Vars.Visuals.Tracers, "Player")
		
		local VisualBulletTracers = fgui.Create("FHCheckBox", VisualTracerskSection)
		VisualBulletTracers:SetPos(20, 45)
		VisualBulletTracers:SetText("Bullet Tracers")
		VisualBulletTracers:SetVarTable(Vars.Visuals.Tracers, "Bullet")
		
		local VisualBulletTime = fgui.Create("FHSlider", VisualTracerskSection)
		VisualBulletTime:SetText("Bullet Tracer Time")
		VisualBulletTime:SetPos(20, 61)
		VisualBulletTime:SetWide(400)
		VisualBulletTime:SetMinMax(0, 10)
		VisualBulletTime:SetDecimals(0)
		VisualBulletTime:SetVarTable(Vars.Visuals.Tracers, "BulletTime")
		
		-------
		
		local VisualMiscSection = fgui.Create("FHSection", VisualPanel)
		VisualMiscSection:SetSize(560, 135)
		VisualMiscSection:SetPos(5, 430)
		VisualMiscSection:SetTitle("Misc")
		
		local VisualMiscHitBoxes = fgui.Create("FHCheckBox", VisualMiscSection)
		VisualMiscHitBoxes:SetPos(20, 20)
		VisualMiscHitBoxes:SetText("Show HitBoxes")
		VisualMiscHitBoxes:SetVarTable(Vars.Visuals.HitBoxes, "Enabled")
		
		local VisualMiscHitboxLocalPlayer = fgui.Create("FHCheckBox", VisualMiscSection)
		VisualMiscHitboxLocalPlayer:SetPos(20, 45)
		VisualMiscHitboxLocalPlayer:SetText("Show LocalPlayer Hitboxes")
		VisualMiscHitboxLocalPlayer:SetVarTable(Vars.Visuals.HitBoxes, "LocalPlayer")
		
		local VisualMiscHitBoxColor = fgui.Create("FHColorButton", VisualMiscSection)		
		VisualMiscHitBoxColor:SetPos(20, 65)
		VisualMiscHitBoxColor:SetSize(100, 25)
		VisualMiscHitBoxColor:SetText("Hitbox Color")
		VisualMiscHitBoxColor:SetVarTable(Vars.Visuals.HitBoxes, "Color")
		
		local VisualMiscHitBoxes = fgui.Create("FHCheckBox", VisualMiscSection)
		VisualMiscHitBoxes:SetPos(20, 95)
		VisualMiscHitBoxes:SetText("Debug Info")
		VisualMiscHitBoxes:SetVarTable(Vars.Visuals, "DebugInfo")
		
		/*
			Minge tab
		*/
		
		local MingePanel = MainTabs[5]
		
		local MingeNameStealerSection = fgui.Create("FHSection", MingePanel)
		MingeNameStealerSection:SetSize(560, 110)
		MingeNameStealerSection:SetPos(5, 5)
		MingeNameStealerSection:SetTitle("Name Stealer")
		
		local MingeNameStealerEnabled = fgui.Create("FHCheckBox", MingeNameStealerSection)
		MingeNameStealerEnabled:SetPos(20, 20)
		MingeNameStealerEnabled:SetText("Name Stealer")
		MingeNameStealerEnabled:SetVarTable(Vars.Minge.NameStealer, "Enabled")
		
		local MingeNameStealerRandom = fgui.Create("FHButton", MingeNameStealerSection)
		MingeNameStealerRandom:SetSize(150, 22)
		MingeNameStealerRandom:SetPos(20, 40)
		MingeNameStealerRandom:SetText("Steal Random Players Name")
		MingeNameStealerRandom.DoClick = ENV.RegisterFunction(function()
			StealRandom()
		end)
		
		local MingeNameStealerCustom = fgui.Create("FHTextBox", MingeNameStealerSection)
		MingeNameStealerCustom:SetPos(20, 70)
		MingeNameStealerCustom:SetSize(150, 20)
		MingeNameStealerCustom:SetText("Custom Name")
		MingeNameStealerCustom.OnEnter = ENV.RegisterFunction(function(combo, val)	
			ChangeName(val)
		end)
		
		local MingeNameStealerCustom = fgui.Create("FHButton", MingeNameStealerSection)
		MingeNameStealerCustom:SetPos(175, 70)
		MingeNameStealerCustom:SetSize(100, 20)
		MingeNameStealerCustom:SetText('New Line Name')
		MingeNameStealerCustom.DoClick = ENV.RegisterFunction(function()
			ChangeName('\xe2\x80\x8b\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\xe2\x80\x8b')
		end)
		
		local MingeMiscSection = fgui.Create("FHSection", MingePanel)
		MingeMiscSection:SetSize(560, 110)
		MingeMiscSection:SetPos(5, 120)
		MingeMiscSection:SetTitle("Misc")
		
		local MingeAutoKick = fgui.Create("FHCheckBox", MingeMiscSection)
		MingeAutoKick:SetPos(20, 20)
		MingeAutoKick:SetText("Auto Kick")
		MingeAutoKick:SetVarTable(Vars.Minge, "AutoKick")
		
		local MingeFlashSpam = fgui.Create("FHCheckBox", MingeMiscSection)
		MingeFlashSpam:SetPos(20, 45)
		MingeFlashSpam:SetText("Flashlight Spam")
		MingeFlashSpam:SetVarTable(Vars.Minge, "FlashLightSpam")
		
		/*
			Misc Tab
		*/
		
		local MiscellaneousPanel = MainTabs[6]

		local MiscellaneousMovementSection = fgui.Create("FHSection", MiscellaneousPanel)
		MiscellaneousMovementSection:SetSize(135, 100)
		MiscellaneousMovementSection:SetPos(5, 5)
		MiscellaneousMovementSection:SetTitle("Movement")

		local MiscellaneousMovementBhop = fgui.Create("FHCheckBox", MiscellaneousMovementSection)
		MiscellaneousMovementBhop:SetPos(20, 20)
		MiscellaneousMovementBhop:SetText("Bunny Hop")
		MiscellaneousMovementBhop:SetVarTable(Vars.Miscellaneous.Movement, "Bhop")

		local MiscellaneousMovementAutoStrafeEnabled = fgui.Create("FHCheckBox", MiscellaneousMovementSection)
		MiscellaneousMovementAutoStrafeEnabled:SetPos(20, 45)
		MiscellaneousMovementAutoStrafeEnabled:SetText("Auto Strafe")
		MiscellaneousMovementAutoStrafeEnabled:SetVarTable(Vars.Miscellaneous.Movement.AutoStrafe, "Enabled")

		local MiscellaneousMovementAutoStrafeMode = fgui.Create("FHDropDown", MiscellaneousMovementSection)
		MiscellaneousMovementAutoStrafeMode:SetSize(100, 20)
		MiscellaneousMovementAutoStrafeMode:SetPos(20, 70)
		MiscellaneousMovementAutoStrafeMode:AddChoice("Legit", AUTOSTRAFE_MODE_LEGIT)
		MiscellaneousMovementAutoStrafeMode:AddChoice("Rage", AUTOSTRAFE_MODE_RAGE)
		MiscellaneousMovementAutoStrafeMode:ChooseOption("Legit", -1)
		MiscellaneousMovementAutoStrafeMode.FHOnSelect = ENV.RegisterFunction(function(self, index, value, data)
			Vars.Miscellaneous.Movement.AutoStrafe.Mode = data
		end)

		local MiscToggleSections = fgui.Create("FHSection", MiscellaneousPanel)
		MiscToggleSections:SetSize(260, 100)
		MiscToggleSections:SetPos(150, 5)
		MiscToggleSections:SetTitle("Toggles")

		local MiscToggleInterpolation = fgui.Create("FHButton", MiscToggleSections)
		MiscToggleInterpolation:SetSize(120, 22)
		MiscToggleInterpolation:SetPos(20, 20)
		MiscToggleInterpolation:SetText("Toggle Interpolation")
		MiscToggleInterpolation.DoClick = ENV.RegisterFunction(function()
			Cache.ConVars.cl_interpolate:ForceBool(not Cache.ConVars.cl_interpolate:GetBool())
			Log("Toggled Interpolation: %s", Cache.ConVars.cl_interpolate:GetBool())
		end)

		local MiscToggleInterpolation = fgui.Create("FHButton", MiscToggleSections)
		MiscToggleInterpolation:SetSize(120, 22)
		MiscToggleInterpolation:SetPos(20, 45)
		MiscToggleInterpolation:SetText("Pseudo No Interpolation")
		MiscToggleInterpolation.DoClick = ENV.RegisterFunction(function()
			g_bPseudoNoInterp = not g_bPseudoNoInterp
			Log("Toggled Pseudo Interpolation: %s", tobool(g_bPseudoNoInterp))
		end)

		local MiscToggleInterpolation = fgui.Create("FHButton", MiscToggleSections)
		MiscToggleInterpolation:SetSize(120, 22)
		MiscToggleInterpolation:SetPos(20, 70)
		MiscToggleInterpolation:SetText("No Player Interpolation")
		MiscToggleInterpolation.DoClick = ENV.RegisterFunction(function()
			g_bNoPlayerInterp = not g_bNoPlayerInterp
			Log("Toggled Player Interpolation: %s", tobool(g_bNoPlayerInterp))
		end)
		
		local MiscellaneousFreezeSection = fgui.Create("FHSection", MiscellaneousPanel)
		MiscellaneousFreezeSection:SetSize(560, 75)
		MiscellaneousFreezeSection:SetPos(5, 110)
		MiscellaneousFreezeSection:SetTitle("Freezy")
		
		local MiscellaneousFreezeDoubleTap = fgui.Create("FHCheckBox", MiscellaneousFreezeSection)
		MiscellaneousFreezeDoubleTap:SetPos(20, 20)
		MiscellaneousFreezeDoubleTap:SetText("Double Tap")
		MiscellaneousFreezeDoubleTap:SetVarTable(Vars.Miscellaneous.Freeze, "DoubleTap")
		
		local MiscellaneousFreezeDoubleTap = fgui.Create("FHCheckBox", MiscellaneousFreezeSection)
		MiscellaneousFreezeDoubleTap:SetPos(20, 45)
		MiscellaneousFreezeDoubleTap:SetText("Teleport")
		MiscellaneousFreezeDoubleTap:SetVarTable(Vars.Miscellaneous.Freeze, "Teleport")
		
		local MiscellaneousThirdPersonSection = fgui.Create("FHSection", MiscellaneousPanel)
		MiscellaneousThirdPersonSection:SetSize(560, 95)
		MiscellaneousThirdPersonSection:SetPos(5, 190)
		MiscellaneousThirdPersonSection:SetTitle("ThirdPerson")
		
		local MiscellaneousThirdPersonEnabled = fgui.Create("FHCheckBox", MiscellaneousThirdPersonSection)
		MiscellaneousThirdPersonEnabled:SetPos(20, 20)
		MiscellaneousThirdPersonEnabled:SetText("Third Person")
		MiscellaneousThirdPersonEnabled:SetVarTable(Vars.Miscellaneous.ThirdPerson, "Enabled")
		
		local HvHAntiAimActFakeDuckKey = fgui.Create("FHBinder", HvHAntiAimSection)
		HvHAntiAimActFakeDuckKey:SetSize(100, 25)
		HvHAntiAimActFakeDuckKey:SetPos(45, 427)
		HvHAntiAimActFakeDuckKey:SetLabel("Fake Duck Key")
		HvHAntiAimActFakeDuckKey:SetVarTable(Vars.HvH.FakeDuck, "Key")
		
		local MiscellaneousThirdPersonDistance = fgui.Create("FHSlider", MiscellaneousThirdPersonSection)
		MiscellaneousThirdPersonDistance:SetText("Camera Distance")
		MiscellaneousThirdPersonDistance:SetPos(20, 32)
		MiscellaneousThirdPersonDistance:SetWide(400)
		MiscellaneousThirdPersonDistance:SetMinMax(0, 500)
		MiscellaneousThirdPersonDistance:SetDecimals(0)
		MiscellaneousThirdPersonDistance:SetVarTable(Vars.Miscellaneous.ThirdPerson, "Distance")
		
		local MiscellaneousThirdPersonY = fgui.Create("FHSlider", MiscellaneousThirdPersonSection)
		MiscellaneousThirdPersonY:SetText("Camera Y")
		MiscellaneousThirdPersonY:SetPos(20, 57)
		MiscellaneousThirdPersonY:SetWide(400)
		MiscellaneousThirdPersonY:SetMinMax(-180, 180)
		MiscellaneousThirdPersonY:SetDecimals(0)
		MiscellaneousThirdPersonY:SetVarTable(Vars.Miscellaneous.ThirdPerson, "Y")
		
		local CrosshairSection = fgui.Create("FHSection", MiscellaneousPanel)
		CrosshairSection:SetSize(560, 145)
		CrosshairSection:SetPos(5, 290)
		CrosshairSection:SetTitle("Custom Crosshair") 
		
		local CrosshairEnabled = fgui.Create("FHCheckBox", CrosshairSection)
		CrosshairEnabled:SetPos(20, 20)
		CrosshairEnabled:SetText("Custom Crosshair")
		CrosshairEnabled:SetVarTable(Vars.Miscellaneous.Crosshair, "Enabled")
		
		local CrosshairType = fgui.Create("FHDropDown", CrosshairSection)
		CrosshairType:SetSize(100, 20)
		CrosshairType:SetPos(20, 43)
		CrosshairType:AddChoice("Basic Cross", "basic")
		CrosshairType:AddChoice("Fancy Shit", "fancy")
		CrosshairType:ChooseOption("Basic Cross", "basic")
		
		CrosshairType.FHOnSelect = ENV.RegisterFunction(function(self, index, value, data)
			Vars.Miscellaneous.Crosshair.Type = data
		end)
		
		local CrosshairLength = fgui.Create("FHSlider", CrosshairSection)
		CrosshairLength:SetText("Length")
		CrosshairLength:SetPos(20, 61)
		CrosshairLength:SetWide(400)
		CrosshairLength:SetMinMax(0, 200)
		CrosshairLength:SetDecimals(0)
		CrosshairLength:SetVarTable(Vars.Miscellaneous.Crosshair, "Length")
		
		local CrosshairThickness = fgui.Create("FHSlider", CrosshairSection)
		CrosshairThickness:SetText("Thickness")
		CrosshairThickness:SetPos(20, 86)
		CrosshairThickness:SetWide(400)
		CrosshairThickness:SetMinMax(0, 20)
		CrosshairThickness:SetDecimals(0)
		CrosshairThickness:SetVarTable(Vars.Miscellaneous.Crosshair, "Thickness")
		
		local CrosshairSpeed = fgui.Create("FHSlider", CrosshairSection)
		CrosshairSpeed:SetText("Speed")
		CrosshairSpeed:SetPos(20, 111)
		CrosshairSpeed:SetWide(400)
		CrosshairSpeed:SetMinMax(0, 10)
		CrosshairSpeed:SetDecimals(0)
		CrosshairSpeed:SetVarTable(Vars.Miscellaneous.Crosshair, "Speed")
		
		local MiscellaneousSection = fgui.Create("FHSection", MiscellaneousPanel)
		MiscellaneousSection:SetSize(560, 175)
		MiscellaneousSection:SetPos(5, 440)
		MiscellaneousSection:SetTitle("Misc")
		
		local MiscellaneousChangeFOV = fgui.Create("FHCheckBox", MiscellaneousSection)
		MiscellaneousChangeFOV:SetPos(20, 20)
		MiscellaneousChangeFOV:SetText("Custom FOV")
		MiscellaneousChangeFOV:SetVarTable(Vars.Miscellaneous.FOV, "Enabled")

		local MiscellaneousHitsound = fgui.Create("FHCheckBox", MiscellaneousSection)
		MiscellaneousHitsound:SetPos(150, 20)
		MiscellaneousHitsound:SetText("Hit Sound")
		MiscellaneousHitsound:SetVarTable(Vars.Miscellaneous.Hitsound, "Enabled")
		
		local MiscellaneousFOVDesired = fgui.Create("FHSlider", MiscellaneousSection)
		MiscellaneousFOVDesired:SetText("Desired FOV")
		MiscellaneousFOVDesired:SetPos(20, 36)
		MiscellaneousFOVDesired:SetWide(400)
		MiscellaneousFOVDesired:SetMinMax(0, 180)
		MiscellaneousFOVDesired:SetDecimals(0)
		MiscellaneousFOVDesired:SetVarTable(Vars.Miscellaneous.FOV, "Desired")
		
		local MiscellaneousRainbowPhys = fgui.Create("FHCheckBox", MiscellaneousSection)
		MiscellaneousRainbowPhys:SetPos(20, 70)
		MiscellaneousRainbowPhys:SetText("Rainbow Physgun")
		MiscellaneousRainbowPhys:SetVarTable(Vars.Miscellaneous.RainbowPhys, "Enabled")
		
		local MiscellaneousRainbowPhysFrequency = fgui.Create("FHSlider", MiscellaneousSection)
		MiscellaneousRainbowPhysFrequency:SetText("Rainbow Frequency")
		MiscellaneousRainbowPhysFrequency:SetPos(20, 86)
		MiscellaneousRainbowPhysFrequency:SetWide(400)
		MiscellaneousRainbowPhysFrequency:SetMinMax(0, 10)
		MiscellaneousRainbowPhysFrequency:SetDecimals(0)
		MiscellaneousRainbowPhysFrequency:SetVarTable(Vars.Miscellaneous.RainbowPhys, "Frequency")

		local MiscellaneousSkyboxChanger = fgui.Create("FHDropDown", MiscellaneousSection)
		MiscellaneousSkyboxChanger:SetSize(115, 20)
		MiscellaneousSkyboxChanger:SetPos(20, 145)
		MiscellaneousSkyboxChanger:SetText("Skybox Changer")

		for k, _ in pairs(Cache.Skyboxes) do
			MiscellaneousSkyboxChanger:AddChoice(k)
		end

		MiscellaneousSkyboxChanger.FHOnSelect = ENV.RegisterFunction(function(self, index, value) 
			if not Cache.Skyboxes[value] then return end

			SelectedSky = value
			
			for i = 1, #Cache.SkyTextures do
				Cache.SkyTextures[i]:SetTexture("$basetexture", Cache.Skyboxes[SelectedSky][i])
			end 
		end)


	
		local ViewmodelChanger = MainTabs[7]
		
	

		local ViewmodelSection = fgui.Create("FHSection", ViewmodelChanger)
		ViewmodelSection:SetSize(560, 185)
		ViewmodelSection:SetPos(5, 5)
		ViewmodelSection:SetTitle("Viewmodel Changer")

		local Viewmodel = fgui.Create("FHCheckBox", ViewmodelChanger)
		Viewmodel:SetPos(20, 20)
		Viewmodel:SetText("Enable")
		Viewmodel:SetVarTable(Vars.Viewmodel.Changer, "Enabled")

		local ViewmodelFOV = fgui.Create("FHSlider", ViewmodelChanger)
		ViewmodelFOV:SetText("ViewmodelFOV")
		ViewmodelFOV:SetPos(20,35)
		ViewmodelFOV:SetWide(400)
		ViewmodelFOV:SetMinMax(1,180)
		ViewmodelFOV:SetDecimals(0)
		ViewmodelFOV:SetVarTable(Vars.Viewmodel.Changer, "VMFOV")

	end)
	

	--- Player list thing

	local EnvFrame = fgui.Create("FHFrame")
	EnvFrame:SetVisible(false)
	EnvFrame:SetTitle("Environment List")
	EnvFrame:SetSize(700, 600)
	--EnvFrame:ShowCloseButton(false)
	EnvFrame:SetDeleteOnClose(false)
	EnvFrame:SetX((ScrW() / 2) + 10)
	EnvFrame:CenterVertical()
	
	Cache.Panels.EnvFrame = EnvFrame

	EnvFrame._OldPerformLayout = EnvFrame.PerformLayout

	EnvFrame.PerformLayout = ENV.RegisterFunction(function(self, w, h)
		EnvFrame._OldPerformLayout(self, w, h)

		local EnvFrameTabs = fgui.Create("FHTabbedMenu", self)
		EnvFrameTabs:Dock(FILL)
		EnvFrameTabs:SetTabBackground(true)
		local EnvTabs = EnvFrameTabs:AddTabs("Players", "Entities", "Hooks")

		local PlayerPanel = EnvTabs[1]

		local EnvPlayerList = fgui.Create("FHList", PlayerPanel)
		EnvPlayerList:SetSize(670, 264)
		EnvPlayerList:SetMultiSelect(false)
		EnvPlayerList:SetSortable(false)

		Cache.Panels.EnvPlayerList = EnvPlayerList

		local EnvPlayerListIndex = EnvPlayerList:AddColumn("Index")
		EnvPlayerListIndex:SetFixedWidth(50)

		EnvPlayerList:AddColumn("Username")

		local EnvPlayerListPriority = EnvPlayerList:AddColumn("Priority")
		EnvPlayerListPriority:SetFixedWidth(75)

		local EnvPlayerSettings = fgui.Create("FHSection", PlayerPanel)
		EnvPlayerSettings:SetSize(670, 264)
		EnvPlayerSettings:SetPos(0, EnvPlayerList:GetTall() + 10)
		EnvPlayerSettings:SetTitle("Player Settings")

		local EnvPlayerSettingsPanel = EnvPlayerSettings:GetContentFrame()

		local EnvPlayerSettingsInfo = fgui.Create("FHSection", EnvPlayerSettingsPanel)
		EnvPlayerSettingsInfo:SetPos(0, 5)
		EnvPlayerSettingsInfo:SetSize(330, 244)
		EnvPlayerSettingsInfo:SetTitle("Info")

		local EnvPlayerSettingsInfoAvatar = vgui.Create("AvatarImage", EnvPlayerSettingsInfo)
		EnvPlayerSettingsInfoAvatar:SetSize(64, 64)
		EnvPlayerSettingsInfoAvatar:SetPos(EnvPlayerSettingsInfo:GetWide() - EnvPlayerSettingsInfoAvatar:GetWide() - 23, 35)
		EnvPlayerSettingsInfoAvatar:SetPlayer(NULL, 64)

		local EnvPlayerSettingsInfoLabel = fgui.Create("FHLabel", EnvPlayerSettingsInfo)
		EnvPlayerSettingsInfoLabel:SetWide(200)
		EnvPlayerSettingsInfoLabel:SetAutoStretchVertical(true)
		EnvPlayerSettingsInfoLabel:SetPos(10, 25)

		EnvPlayerSettingsInfoAvatar.Paint = ENV.RegisterFunction(function(self, w, h)
			surface.SetDrawColor(fgui.Colors.outline)
			surface.DrawLine(0, 0, w, h)
			surface.DrawLine(w, 0, 0, h)
		end)

		EnvPlayerSettingsInfoAvatar.PaintOver = ENV.RegisterFunction(function(self, w, h)
			surface.SetDrawColor(fgui.Colors.outline)
			surface.DrawOutlinedRect(0, 0, w, h)
		end)

		EnvPlayerSettingsInfoLabel._FHPlayer = NULL
		EnvPlayerSettingsInfoLabel._ThinkTick = 0
		EnvPlayerSettingsInfoLabel._ThinkLimit = Cache.TickInterval * (Cache.SecondInterval / 3)

		EnvPlayerSettingsInfoLabel.UpdateInfo = ENV.RegisterFunction(function(self)
			local ply = self._FHPlayer or NULL

			local valid = IsValid(ply)

			EnvPlayerSettingsInfoAvatar:SetPlayer(ply, 64)

			local name = valid and ply:GetName() or ""
			local id64 = valid and (ply:SteamID64() or "BOT") or ""
			local origin = valid and ply:GetPos() or vector_origin
			local angles = (valid and ply:EyeAngles() or angle_zero):GetFixed()
			local velocity = valid and ply:GetVelocity():Length() or 0

			origin = table.concat({
				util.NiceFloat(math.Round(origin.x)),
				util.NiceFloat(math.Round(origin.y)),
				util.NiceFloat(math.Round(origin.z))
			}, ", ")
			
			angles = table.concat({
				util.NiceFloat(math.Round(angles.pitch)),
				util.NiceFloat(math.Round(angles.yaw)),
				util.NiceFloat(math.Round(angles.roll))
			}, ", ")

			velocity = util.NiceFloat(math.Round(velocity))

			self:SetText(string.format([=[Name: %s
				Steam64: %s
				Origin: (%s)
				Angles: (%s)
				Velocity: %s]=],
				
				name, id64, origin, angles, velocity
			))
		end)

		EnvPlayerSettingsInfoLabel._OldThink = EnvPlayerSettingsInfoLabel.Think

		EnvPlayerSettingsInfoLabel.Think = ENV.RegisterFunction(function(self)
			self._OldThink(self)

			self._ThinkTick = self._ThinkTick + Cache.TickInterval

			if self._ThinkTick >= self._ThinkLimit then
				self:UpdateInfo()
				self._ThinkTick = 0
			end
		end)

		local EnvPlayerSettingsInfoProfile = fgui.Create("FHButton", EnvPlayerSettingsInfo)
		EnvPlayerSettingsInfoProfile:SetSize(100, 22)
		EnvPlayerSettingsInfoProfile:SetPos(EnvPlayerSettingsInfo:GetWide() - EnvPlayerSettingsInfoProfile:GetWide() - 5, 10)
		EnvPlayerSettingsInfoProfile:SetText("Open Profile")

		EnvPlayerSettingsInfoProfile.DoClick = ENV.RegisterFunction(function()
			if not IsValid(EnvPlayerSettingsInfoLabel._FHPlayer) or not EnvPlayerSettingsInfoLabel._FHPlayer:SteamID64() then return end

			gui.OpenURL("https://steamcommunity.com/profiles/" .. EnvPlayerSettingsInfoLabel._FHPlayer:SteamID64())
		end)
		
		local EnvPlayerSettingsControls = fgui.Create("FHSection", EnvPlayerSettingsPanel)
		EnvPlayerSettingsControls:SetSize(325, 244)
		EnvPlayerSettingsControls:SetPos(EnvPlayerSettingsInfo:GetWide() + 5, 5)
		EnvPlayerSettingsControls:SetTitle("Controls")
		
		local EnvPlayerSettingsWhiteList = fgui.Create("FHButton", EnvPlayerSettingsControls)
		EnvPlayerSettingsWhiteList:SetSize(80, 20)
		EnvPlayerSettingsWhiteList:SetPos(20, 20)
		EnvPlayerSettingsWhiteList:SetText("WhiteList")
		EnvPlayerSettingsWhiteList.DoClick = ENV.RegisterFunction(function()
			if not IsValid(EnvPlayerSettingsInfoLabel._FHPlayer) then return end

			Vars.Aimbot.Friends[EnvPlayerSettingsInfoLabel._FHPlayer] = not Vars.Aimbot.Friends[EnvPlayerSettingsInfoLabel._FHPlayer]
		end)
		
		local EnvPlayerSettingsStealName = fgui.Create("FHButton", EnvPlayerSettingsControls)
		EnvPlayerSettingsStealName:SetSize(80, 20)
		EnvPlayerSettingsStealName:SetPos(110, 20)
		EnvPlayerSettingsStealName:SetText("Steal Name")
		EnvPlayerSettingsStealName.DoClick = ENV.RegisterFunction(function()
			if not IsValid(EnvPlayerSettingsInfoLabel._FHPlayer) and not Vars.Minge.NameStealer.Enabled then return end
			
			StealName(EnvPlayerSettingsInfoLabel._FHPlayer)
		end)

		local EnvPlayerSettingsPriority = fgui.Create("FHDropDown", EnvPlayerSettingsControls)
		EnvPlayerSettingsPriority:SetSize(100, 20)
		EnvPlayerSettingsPriority:SetPos(20, 43)
		EnvPlayerSettingsPriority:AddChoice("None", PRIORITY_NONE)
		EnvPlayerSettingsPriority:AddChoice("Low", PRIORITY_LOW)
		EnvPlayerSettingsPriority:AddChoice("Medium", PRIORITY_MEDIUM)
		EnvPlayerSettingsPriority:AddChoice("High", PRIORITY_HIGH)
		EnvPlayerSettingsPriority:AddChoice("Rage", PRIORITY_RAGE)
		EnvPlayerSettingsPriority:ChooseOption("Priority", PRIORITY_NONE)
		
		EnvPlayerSettingsPriority.FHOnSelect = ENV.RegisterFunction(function(self, index, value, data)
			local Player = EnvPlayerSettingsInfoLabel._FHPlayer
			LRagebot.AimPriorities[Player] = data
			Log("%s priorities have been updated to %s", Player, data)
		end)
		
		EnvPlayerList.FHOnRowSelected = ENV.RegisterFunction(function(self, index, row)
			EnvPlayerSettingsInfoLabel._FHPlayer = row._FHPlayer or NULL
			EnvPlayerSettingsInfoLabel:UpdateInfo()
		end)

		local EntitiesPanel = EnvTabs[2]

		local EnvEntityList = fgui.Create("FHList", EntitiesPanel)
		EnvEntityList:SetSize(670, 480)
		EnvEntityList:SetMultiSelect(false)
		EnvEntityList:SetSortable(false)
		EnvEntityList:AddColumn("Class")

		local EnvEntityListPriority = EnvEntityList:AddColumn("Show On ESP")
		EnvEntityListPriority:SetFixedWidth(150)

		local EnvEntityListSection = fgui.Create("FHSection", EntitiesPanel)
		EnvEntityListSection:SetSize(670, 58)
		EnvEntityListSection:SetPos(0, 480)
		EnvEntityListSection:SetTitle("Search for entities")
		
		local EnvEntityTextBox = fgui.Create("FHTextBox", EnvEntityListSection)
		EnvEntityTextBox:SetPos(12, 20)
		EnvEntityTextBox:SetSize(170, 22)
		EnvEntityTextBox:SetText("Search Entities")

		EnvEntityTextBox.m_pList = EnvEntityList
		EnvEntityList.m_pTextbox = EnvEntityTextBox

		EnvEntityList.CacheUpdate = ENV.RegisterFunction(function(self)
			self:Clear()
	
			local Added = {}
	
			for i = 1, #Cache.Entities do
				if not IsValid(Cache.Entities[i]) then continue end
	
				local Class = Cache.Entities[i]:GetClass()
	
				if not Added[Class] then
					self:AddLine(Class, Cache.iEntityClasses[Class] and "True" or "False")
					Added[Class] = true
				end
			end
	
			--for k, _ in pairs(scripted_ents.GetList()) do
			--	if not Added[k] then
			--		self:AddLine(k, Cache.iEntityClasses[k] and "True" or "False")
			--		Added[k] = true
			--	end
			--end
		end)
	
		EnvEntityList.FHOnRowSelected = ENV.RegisterFunction(function(self, _, row)
			Cache.iEntityClasses[row:GetValue(1)] = not Cache.iEntityClasses[row:GetValue(1)]
			--PrintTable(Cache.iEntityClasses)
			self:CacheUpdate()
		end)

		EnvEntityList.Rebuild = ENV.RegisterFunction(function(self, Classes)
			self:Clear()
			self.m_pTextbox:SetValue("")

			self.m_tClasses = Classes or Cache.iEntityClasses
			self.m_pCoroutine = coroutine.create(self:CacheUpdate())
		end)

		function EnvEntityList:Think()
			if self.m_pCoroutine then
				coroutine.resume(self.m_pCoroutine)

				if self.m_bKillCoroutine then
					self.m_bKillCoroutine = false
				end
			end
		end

		EnvEntityTextBox.OnValueChange = ENV.RegisterFunction(function(self, NewValue)
			if self.m_bCalled then return end -- Prevent infinite loop

			if NewValue == "" then -- Textbox was cleared, restore everything
				self.m_bCalled = true
				self.m_pList:Rebuild()
				self.m_bCalled = false

				return
			end

			self.m_pList.m_bKillCoroutine = true -- Stop the current building

			NewValue = NewValue:lower()

			self.m_pList:Clear()

			local Classes = {}	

			for k, v in SortedPairs(Cache.iEntityClasses) do
				if v:find(NewValue, 1, true) then
					Classes[k] = true
				end
			end
				
			self.m_bCalled = true
			self.m_pList:Rebuild(Classes)
			self.m_bCalled = false
		end)
		
		Cache.Panels.EnvEntityList = EnvEntityList
		
		local HooksPanel = EnvTabs[3]
		
		local EnvHookList = fgui.Create("FHList", HooksPanel)
		EnvHookList:SetSize(335, 464)
		EnvHookList:SetMultiSelect(false)
		EnvHookList:SetSortable(false)
		Cache.Panels.EnvHookList = EnvHookList
		
		EnvHookList:AddColumn("Hook Type")
		EnvHookList:AddColumn("Hook Name")
		
		local EnvBlockedHookList = fgui.Create("FHList", HooksPanel)
		EnvBlockedHookList:SetSize(335, 464)
		EnvBlockedHookList:SetPos(335, 0)
		EnvBlockedHookList:SetMultiSelect(false)
		EnvBlockedHookList:SetSortable(false)
		Cache.Panels.EnvBlockedHookList = EnvBlockedHookList
		
		EnvBlockedHookList:AddColumn("Blocked Hook Type")
		EnvBlockedHookList:AddColumn("Blocked Hook Name")
		
		local EnvHookSettings = fgui.Create("FHSection", HooksPanel)
		EnvHookSettings:SetSize(670, 64)
		EnvHookSettings:SetPos(0, EnvHookList:GetTall() + 10)
		EnvHookSettings:SetTitle("Hook Settings")
		
		local function refreshHooks()
			Cache.Panels.EnvHookList:Clear()
			for htype, hooks in pairs(hook.GetTable()) do
				if not istable(hooks) then continue end
                for hname, _ in pairs(hooks) do
                    htype = tostring(htype)
                    hname = tostring(hname)
    
                    Cache.Panels.EnvHookList:AddLine(htype, hname)
                end
            end
        end

		Cache.Panels.EnvHookList.FHOnRowSelected = ENV.RegisterFunction(function(self, index, row)
            for _, v in pairs(self:GetSelected()) do
                local hname = tostring(v:GetValue(1))
                local htype = tostring(v:GetValue(2))

                if not istable(Cache.Hooks.Blocked[htype]) then Cache.Hooks.Blocked[htype] = {} end

                Cache.Hooks.Blocked[htype][hname] = hook.GetTable()[htype][hname]
                hook.Remove(htype, hname)
            end
            refreshHooks()
            refreshBlocked()
        end)
		
        refreshHooks()

		--- for da blocked hooks

		local function refreshBlocked()
            Cache.Panels.EnvBlockedHookList:Clear()
            if not istable(Cache.Hooks.Blocked) then return end
            for htype, hooks in pairs(Cache.Hooks.Blocked) do
                if not istable(hooks) then continue end
                for hname, _ in pairs(hooks) do
                    htype = tostring(htype)
                    hname = tostring(hname)
                    Cache.Panels.EnvBlockedHookList:AddLine(htype, hname)        
                end
            end
        end
            
        Cache.Panels.EnvBlockedHookList.FHOnRowSelecte = ENV.RegisterFunction(function(self, index, row)
            for _, v in pairs(self:GetSelected()) do
                local hname = tostring(v:GetValue(1))
                local htype = tostring(v:GetValue(2))

                hook.Add(htype, hname, Cache.Hooks.Blocked[htype][hname])
                Cache.Hooks.Blocked[htype][hname] = nil
            end
            refreshBlocked()
            refreshHooks()
        end)
        
        refreshBlocked()		
	end)

	MainFrame.OnRemove = ENV.RegisterFunction(function()
		EnvFrame:Remove()
	end)

	MainFrame.OnClose = ENV.RegisterFunction(function()
		EnvFrame:Close()
	end)

	timer.Simple(0, ENV.RegisterFunction(function()
		MainFrame:InvalidateLayout(true)
		EnvFrame:InvalidateLayout(true)
	end))
	
	--[[
		Functurios
	]]
	
	-- Metatable functions
	
	local _Registry = ENV._R

	local meta_an_g = _Registry.Angle
	local meta_cv_g = _Registry.ConVar
	local meta_en_g = _Registry.Entity
	local meta_pl_g = _Registry.Player
	local meta_wn_g = _Registry.Weapon
	
	meta_an_g.GetFixed = ENV.RegisterFunction(function(self)
		return Angle(math.Clamp(math.NormalizeAngle(self.pitch), -89, 89), math.NormalizeAngle(self.yaw), math.NormalizeAngle(self.roll))
	end)

	meta_pl_g.IsProtected = ENV.RegisterFunction(function(self)	
		for i = 1, #Cache.NetVars.Protected do
			if self:GetNWBool(Cache.NetVars.Protected[i]) then
				return true
			end
		end
		
		return false
	end)
		
	meta_pl_g.IsInGodMode = ENV.RegisterFunction(function(self)
		if self:HasGodMode() then return true end

		for i = 1, #Cache.NetVars.GodMode do
			if self:GetNWBool(Cache.NetVars.GodMode[i]) then
				return true
			end
		end

		return false
	end)

	meta_pl_g.IsInBuildMode = ENV.RegisterFunction(function(self)
		for i = 1, #Cache.NetVars.Buildmode do
			if self:GetNWBool(Cache.NetVars.Buildmode[i]) then
				return true
			end
		end

		return false
	end)

	meta_pl_g.IsTargetable = ENV.RegisterFunction(function(self)
		local PlayerTable = Cache.EntityData[self]

		return self ~= g_pLocalPlayer and PlayerTable.Alive and PlayerTable.Team ~= TEAM_SPECTATOR and PlayerTable.ObserverMode == 0 and not PlayerTable.Dormant
	end)

	meta_en_g.GetHealthColor = ENV.RegisterFunction(function(self)
		local DataTable = Cache.EntityData[self]

		local Health = self:Health()
		local ClampedHealth = math.Clamp(Health, 0, DataTable.MaxHealth)
		local Percent = ClampedHealth * (ClampedHealth / DataTable.MaxHealth)

		if Health ~= DataTable.Health or not DataTable.HealthColor then
			DataTable.Health = Health
			DataTable.HealthColor = Color(255 - (Percent * 2.55), Percent * 2.55, 0)
		end

		return DataTable.HealthColor, Percent / ClampedHealth
	end)

	meta_en_g.GetScreenCorners = ENV.RegisterFunction(function(self)
		local Mins = Cache.EntityData[self].Mins
		local Maxs = Cache.EntityData[self].Maxs

		local Coords = { -- I'm sorry garbage collection :(
			self:LocalToWorld(Mins):ToScreen(),
			self:LocalToWorld(Vector(Mins.x, Maxs.y, Mins.z)):ToScreen(),
			self:LocalToWorld(Vector(Maxs.x, Maxs.y, Mins.z)):ToScreen(),
			self:LocalToWorld(Vector(Maxs.x, Mins.y, Mins.z)):ToScreen(),
			self:LocalToWorld(Maxs):ToScreen(),
			self:LocalToWorld(Vector(Mins.x, Maxs.y, Maxs.z)):ToScreen(),
			self:LocalToWorld(Vector(Mins.x, Mins.y, Maxs.z)):ToScreen(),
			self:LocalToWorld(Vector(Maxs.x, Mins.y, Maxs.z)):ToScreen()
		}

		local Left, Right, Top, Bottom = Coords[1].x, Coords[1].x, Coords[1].y, Coords[1].y

		for i = 1, #Coords do -- Pick the best corners
			local v = Coords[i]
			if Left > v.x then Left = v.x end
			if Top > v.y then Top = v.y end
			if Right < v.x then Right = v.x end
			if Bottom < v.y then Bottom = v.y end
		end

		return math.Round(Left), math.Round(Right), math.Round(Top), math.Round(Bottom)
	end)

	meta_pl_g.GetForward = ENV.RegisterFunction(function(self) -- Fix for context menu
		if self ~= g_pLocalPlayer then return meta_en_g.GetForward(self) end

		if g_pLocalPlayer:IsWorldClicking() then
			return gui.ScreenToVector(gui.MouseX(), gui.MouseY())
		end

		return meta_en_g.GetForward(self)
	end)

	meta_pl_g.GetRealEyeTrace = ENV.RegisterFunction(function(self) -- Fix for antiaim
		if self ~= g_pLocalPlayer then return self:GetEyeTrace() end

		return util.TraceLine({
			start = Cache.CalcViewData.Origin,
			endpos = Cache.CalcViewData.Origin + (Cache.CalcViewData.Angles:Forward() * 32767),
			filter = g_pLocalPlayer
		})
	end)

	meta_wn_g.GetBase = ENV.RegisterFunction(function(self)
		if not self.Base then return nil end

		if self.Base:lower():Split("_")[1] == "weapon" then return self.Base:lower():Split("_")[2] end
		return self.Base:lower():Split("_")[1]
	end)

	meta_wn_g.IsBasedOnShort = ENV.RegisterFunction(function(self, base)
		return self:GetBase() == base
	end)

	meta_wn_g.GetNiceName = ENV.RegisterFunction(function(self)
		if not self:IsValid() then return "" end

		local Class = self:GetClass()
		if Cache.WeaponNames[Class] then return Cache.WeaponNames[Class] end

		if self.PrintName then
			Cache.WeaponNames[Class] = language.GetPhrase(self.PrintName)
		else
			Cache.WeaponNames[Class] = self.GetPrintName and language.GetPhrase(self:GetPrintName()) or Class
		end

		return Cache.WeaponNames[Class]
	end)
	
	-- Normal lame functions

	ENV.CreateFunction("GetFOVRadius", function()
		local Max = Vars.Aimbot.AimCone.FOV

		local Ratio = Cache.ScreenData.ScrW / Cache.ScreenData.ScrH

		local AimFOV = Max * (math.pi / 180)
		local GameFOV = Cache.CalcViewData.FOV * (math.pi / 180)
		local ViewFOV = 2 * math.atan(Ratio * (Cache.CalcViewData.ZNear / 2) * math.tan(GameFOV / 2))

		return (math.tan(AimFOV) / math.tan(ViewFOV * 0.5)) * Cache.ScreenData.ScrW
	end)
	
	ENV.CreateFunction("DistanceFromCrosshair", function(Position)
		if not Position then
			return 360, false
		end

		local ScreenPosition = Position:ToScreen()
		local Radius = GetFOVRadius()

		if ScreenPosition.Visible and Radius >= 0 then
			return math.Distance(Cache.ScreenData.Center.X, Cache.ScreenData.Center.Y, ScreenPosition.x, ScreenPosition.y), true
		else
			local Forward = Cache.CalcViewData.Angles:Forward()
			local Direction = (Position - Cache.CalcViewData.Origin):GetNormalized()
			local Degree = math.deg(math.acos(Forward:Dot(Direction)))

			return math.abs(Degree), false
		end
	end)

	ENV.CreateFunction("InFOV", function(Position)
		local Distance, WasW2S = DistanceFromCrosshair(Position)
		
		if Vars.Aimbot.AimCone.Enabled then
			if Vars.Aimbot.AimCone.Shape == "Circle" then 
				if WasW2S then
					local Radius = GetFOVRadius()
					if Radius < 0 then return true end
		
					return Distance <= Radius, Distance
				else
					return Distance <= Vars.Aimbot.AimCone.FOV, Distance
				end
			end
			
			if Vars.Aimbot.AimCone.Shape == "Triangle" then
				return IsPointInTriangle(Position:ToScreen(), Cache.FOVTri), Distance 
			end
		else
			return true, Distance
		end
	end)

	ENV.CreateFunction("OnScreen", function(Entity)
		local Direction = Entity:GetPos() - EyePos()
		local Length = Direction:Length()
		local Radius = Entity:BoundingRadius()

		local Max = math.abs(math.cos(math.acos(Length / math.sqrt((Length * Length) + (Radius * Radius))) + 60 * (math.pi / 180)))

		Direction:Normalize()

		return Direction:Dot(EyeVector()) > Max
	end)
	
	ENV.CreateFunction("ScaleFOVByAspectRatio", function(fovDegrees, ratio)
        local halfAngleRadians = fovDegrees * (0.5 * math.pi / 180.0)
        local halfTanScaled = math.tan(halfAngleRadians) * ratio

        return (180.0 / math.pi) * math.atan(halfTanScaled) * 2.0
    end)
    
    -- returns directional vector towards cursor position in world
    
    ENV.CreateFunction("ScreenToWorld", function(x, y)
        local view = render.GetViewSetup()
        local w, h = view.width, view.height
        local fov = view.fov_unscaled
    
        fov = ScaleFOVByAspectRatio(fov, (w / h) / (4 / 3))
    
        return util.AimVector(view.angles, fov, x, y, w, h)
    end)

	ENV.CreateFunction("GetLerpTime", function()
		if not Cache.ConVars.cl_interpolate:GetBool() then
			return 0
		end

		if Cache.ConVars.sv_minupdaterate and Cache.ConVars.sv_maxupdaterate then
			Cache.ConVars.cl_updaterate = Cache.ConVars.sv_maxupdaterate:GetInt()
		end

		local ratio = Cache.ConVars.cl_interp_ratio:GetFloat()
		if ratio == 0 then
			ratio = 1
		end

		local lerp = Cache.ConVars.cl_interp:GetFloat()
		if Cache.ConVars.sv_client_max_interp_ratio and Cache.ConVars.sv_client_max_interp_ratio and Cache.ConVars.sv_client_min_interp_ratio:GetFloat() ~= 1 then
			ratio = math.Clamp(ratio, Cache.ConVars.sv_client_min_interp_ratio:GetFloat(), Cache.ConVars.sv_client_max_interp_ratio:GetFloat())
		end

		return math.max(lerp, ratio / Cache.ConVars.cl_updaterate)
	end)

	ENV.CreateFunction("Switch", function(TestValue, ...)
		local Default
	
		for _, v in ipairs({...}) do
			if v.Default then
				Default = v.Function
				continue
			end
	
			if TestValue == v.Value then
				v.Function()
				return
			end
		end
	
		if type(Default) == "function" then
			Default()
		end
	end)
	
	ENV.CreateFunction("Case", function(TestValue, Function)
		return {
			Value = TestValue,
			Function = Function
		}
	end)
	
	ENV.CreateFunction("Default", function(Function)
		return {
			Default = true,
			Function = Function
		}
	end)

	ENV.CreateFunction("IsVisible", function(Position, Entity)
		Cache.TraceData.start = g_pLocalPlayer:EyePos()
		Cache.TraceData.endpos = Position
		Cache.TraceData.filter = g_pLocalPlayer
		Cache.TraceData.mask = MASK_SHOT

		util.TraceLine(Cache.TraceData)

		if Cache.TraceOutput.StartSolid then return false end
    	if Cache.TraceOutput.Fraction == 1 then return true end

		if Cache.TraceOutput.Entity == Entity then
			return true, 0, Cache.TraceOutput.Fraction
		elseif Vars.Aimbot.TriggerBot.AutoWall then
			local Weapon = g_pLocalPlayer:GetActiveWeapon()
			if not IsValid(Weapon) then
				return false, 0, Cache.TraceOutput.Fraction
			end

			local Hit, Penetrations = WeaponCanPenetrate(Weapon, Cache.TraceOutput, Entity, Position)
			Hit = Hit or false
			Penetrations = Penetrations or 0
			
			return Hit, Penetrations, Cache.TraceOutput.Fraction
		else
			return false, 0, Cache.TraceOutput.Fraction
		end
	end)

	ENV.CreateFunction("TimeToTick", function(Time)
		return math.floor(0.5 + (Time / Cache.TickInterval)) + math.min(GetLerpTime(), Cache.ConVars.sv_maxunlag:GetInt())
	end)

	ENV.CreateFunction("TickToTime", function(Tick)
		return Cache.TickInterval * Tick
	end)

	ENV.CreateFunction("RoundToTicks", function(flTime)
		return TickToTime(TimeToTick(flTime))
	end)
	
	ENV.CreateFunction("GetServerTime", function()
		return TickToTime(g_pLocalPlayer:GetInternalVariable("m_nTickBase"))
	end)

	ENV.CreateFunction("FixAngle", function(Angle)
		Angle.pitch = math.Clamp(math.NormalizeAngle(Angle.pitch), -89, 89)
		Angle.yaw = math.NormalizeAngle(Angle.yaw)
		Angle.roll = math.NormalizeAngle(Angle.roll)
	end)

	ENV.CreateFunction("CanShoot", function()
		local Weapon = g_pLocalPlayer:GetActiveWeapon()
		if not IsValid(Weapon) then return false end

		local WeaponName = string.lower(Weapon.PrintName or Weapon:GetPrintName())
	
		for i = 1, #Cache.WeaponData.AutoShoot.Classes.Blacklist do
			if string.find(WeaponName, Cache.WeaponData.AutoShoot.Classes.Blacklist[i]) then
				local BreakOuter = false
	
				for i = 1, #Cache.WeaponData.AutoShoot.Classes.Whitelist do
					if string.find(WeaponName, Cache.WeaponData.AutoShoot.Classes.Whitelist[i]) then
						BreakOuter = true
						break
					end
				end
	
				if BreakOuter then continue end
	
				return false
			end
		end
	
		local Base = Weapon:GetBase()
		local BaseCheck = Cache.WeaponData.AutoShoot.BaseFunctions[Base] and Cache.WeaponData.AutoShoot.BaseFunctions[Base](Weapon) or true
	
		return GetServerTime() >= Weapon:GetNextPrimaryFire() and BaseCheck
	end)

	ENV.CreateFunction("ToggleMenu", function()
		local stat = not MainFrame:IsVisible()
		
		EnvFrame:SetVisible(stat)
		MainFrame:SetVisible(stat)
        
        if IsValid(Cache.Panels.EnvEntityList) then
			Cache.Panels.EnvEntityList:CacheUpdate()
		end
		
		if stat then
			EnvFrame:MakePopup()
			MainFrame:MakePopup()
		else
			MainFrame:Close()
		end

		gui.EnableScreenClicker(not stat)
	end)

	----------


	ENV.CreateFunction("UpdatePlayerList", function()
		if not IsValid(Cache.Panels.EnvPlayerList) then return end

		Cache.Panels.EnvPlayerList:Clear()

		local players = GetCachedPlayers(true)

		for i = 1, #players do
			local v = players[i]

			local line = Cache.Panels.EnvPlayerList:AddLine(i, v:GetName(), Vars.Aimbot.Friends[v] == true and "Friend" or "Normal")
			line._FHPlayer = v
		end
	end)

	----------
	
	ENV.CreateFunction("IsMeleeWeapon", function(Weapon)
		if not (IsValid(Weapon) and Weapon:IsWeapon()) then return false end

		local StrClass = Weapon:GetClass()
		if Cache.WeaponData.MeleeGuns[StrClass] then return true end

		return false
	end)

	ENV.CreateFunction("VectorTransform", function(vecIn, matrixIn, vecOut)
		if not matrixIn then return vecIn end

		local vecRet = Vector()

		local one = Vector(matrixIn:GetField(1, 1), matrixIn:GetField(1, 2), matrixIn:GetField(1, 3))
		local two = Vector(matrixIn:GetField(2, 1), matrixIn:GetField(2, 2), matrixIn:GetField(2, 3))
		local three = Vector(matrixIn:GetField(3, 1), matrixIn:GetField(3, 2), matrixIn:GetField(3, 3))

		vecRet.x = vecIn:Dot(one) + matrixIn:GetField(1, 4)
		vecRet.y = vecIn:Dot(two) + matrixIn:GetField(2, 4)
		vecRet.z = vecIn:Dot(three) + matrixIn:GetField(3, 4)

		if vecOut then
			vecOut:Set(vecRet)
			return
		end

		return vecRet
	end)

	-- pasted from black <3
	ENV.CreateFunction("IsTickValid", function(flTime)
		local correct = 0
		local lerpticks = TimeToTick(GetLerpTime())

		correct = correct + proxi.GetFlowIncoming() + proxi.GetFlowOutgoing()
		correct = correct + TickToTime(lerpticks)
		correct = math.Clamp(correct, 0, 1)

		local targettick = TimeToTick(flTime) -- - lerpticks
		local servertick = g_pLocalPlayer:GetInternalVariable("m_nTickBase")
		local deltatime = correct - TickToTime(servertick - targettick)

		return math.abs(deltatime) < 0.2, deltatime
	end)

	---- aim functions

	ENV.TargetAng = Angle(0, 0, 0)

	ENV.CreateFunction("GenerateMultiPoints", function(Pos, Ang, Mins, Maxs)
		local pMins = Vector(Mins.x + 1, Mins.y + 1, Mins.z + 1)
		local pMaxs = Vector(Maxs.x - 1, Maxs.y - 1, Maxs.z - 1)

		local Data = {
			pMins,
			pMaxs,
			Vector(pMins.x, pMins.y, pMaxs.z),
			Vector(pMaxs.x, pMins.y, pMaxs.z),
			Vector(pMaxs.x, pMaxs.y, pMins.z),
			Vector(pMaxs.x, pMins.y, pMins.z),
			Vector(pMins.x, pMaxs.y, pMins.z),
			Vector(pMins.x, pMaxs.y, pMaxs.z)
		}

		for i = 1, #Data do
			Data[i]:Rotate(Ang) -- Make the multipoints follow the hitbox's rotation
			Data[i]:Add(Pos) -- Move them into position from world origin
		end

		return Data
	end)

	ENV.CreateFunction("Sign", function(p1, p2, p3) -- https://en.wikipedia.org/wiki/Barycentric_coordinate_system
		if not p1 or not p2 or not p3 then return 0 end

		return (p1.x - p3.x) * (p2.y - p3.y) - (p2.x - p3.x) * (p1.y - p3.y)
	end)

	ENV.CreateFunction("IsPointInTriangle", function(pt, tri)
		if not pt or not tri then return false end

		local v1, v2, v3 = tri[1], tri[2], tri[3]
		local n, p

		local test1 = Sign(pt, v1, v2)
		local test2 = Sign(pt, v2, v3)
		local test3 = Sign(pt, v3, v1)

		n = test1 < 0 or test2 < 0 or test3 < 0
		p = test1 > 0 or test2 > 0 or test3 > 0

		return not (n and p)
	end)

	ENV.CreateFunction("PredictTargetPosition", function(Position, Entity)
		if not Cache.ConVars.cl_interpolate:GetBool() then return end

		local Velocity = Entity:GetAbsVelocity()
		if Velocity:IsZero() then return end

		local FrameTime = RealFrameTime()

		Velocity:Mul(FrameTime)
		Position:Add(Velocity)
	end)
	
	ENV.CreateFunction("GenerateModelData", function(Model) -- 0572 :)
		Model = Model or "models/error.mdl"

		if Cache.ModelData[Model] then
			return Cache.ModelData[Model]
		end

		local FileStream = file.Open(Model, "rb", "GAME")
		if not FileStream then return Cache.ModelData[Model] end

		local ID = FileStream:Read(4)
		if ID ~= "IDST" then return Cache.ModelData[Model] end

		Log("Parsing model: " .. Model)

		local Data = {}
		Data.Version = FileStream:ReadLong()
		Data.Checksum = FileStream:ReadLong()

		FileStream:Read(64) -- Name

		Data.DataLength = FileStream:ReadLong()

		FileStream:Read(12) -- eyeposition
		FileStream:Read(12) -- illumposition

		FileStream:Read(12) -- hull_min
		FileStream:Read(12) -- hull_max

		FileStream:Read(12) -- view_bbmin
		FileStream:Read(12) -- view_bbmax

		Data.Flags = FileStream:ReadLong()

		-- mstudiobone_t
		Data.BoneCount = FileStream:ReadLong()
		Data.BoneOffset = FileStream:ReadLong() -- BoneIndex

		-- mstudiobonecontroller_t
		Data.BoneControllerCount = FileStream:ReadLong()
		Data.BoneControllerOffset = FileStream:ReadLong()

		-- mstudiobonecontroller_t
		Data.HitboxCount = FileStream:ReadLong()
		Data.HitboxOffset = FileStream:ReadLong()

		FileStream:Seek(Data.HitboxOffset)

		Data.szNameIndex = FileStream:ReadLong()
		Data.HitboxOffsetCount = FileStream:ReadLong()
		Data.HitboxIndex = FileStream:ReadLong()

		FileStream:Seek(Data.HitboxOffset + Data.HitboxIndex)

		Data.Hitboxes = {}

		for i = 1, Data.HitboxOffsetCount do
			local Temp = {}

			Temp.Bone = FileStream:ReadLong()
			Temp.Hitgroup = FileStream:ReadLong()

			Temp.Mins = Vector(FileStream:ReadFloat(), FileStream:ReadFloat(), FileStream:ReadFloat())
			Temp.Maxs = Vector(FileStream:ReadFloat(), FileStream:ReadFloat(), FileStream:ReadFloat())
			Temp.Center = (Temp.Mins + Temp.Maxs) / 2

			Temp.szHitBoxNameIndex = FileStream:ReadLong()

			FileStream:Read(32) -- Unused

			Data.Hitboxes[#Data.Hitboxes + 1] = Temp
		end

		FileStream:Close()

		Cache.ModelData[Model] = Data
		
		return Data
	end)
end

do
	local AddHook = Data.Environment.AddHook
	local AddConCommand = Data.Environment.AddConCommand
	
	Data.Environment.gameevent.Listen("player_connect_client")
	AddHook("player_connect_client", function()
		UpdatePlayerList()
	end)

	Data.Environment.gameevent.Listen("player_disconnect")
	AddHook("player_disconnect", function()
		UpdatePlayerList()
	end)
/*
	Data.Environment.gameevent.Listen("entity_killed")
	AddHook("entity_killed", function(data)
		attacker = ents.GetByIndex(data.entindex_attacker) or NULL
		victim = ents.GetByIndex(data.entindex_killed) or NULL

		if not IsValid(attacker) or not victim:IsPlayer() or victim == attacker then return end

		if attacker == g_pLocalPlayer and Vars.Miscellaneous.KillSound.Enabled then
			timer.Simple(0.1, function()
				sound.PlayFile(Vars.Miscellaneous.KillSound.Path, "mono", function() end)
			end)
		end
	end)
*/
	Data.Environment.gameevent.Listen("player_hurt")
	hook.Add("player_hurt", "", function(data)
		if data.attacker == LocalPlayer():UserID() then
			surface.PlaySound("buttons/rust.wav")
		end
	end)


	AddHook("DispatchEffect", function(strEffectName, pEffectData)
		if not Vars.Visuals.Tracers.Bullet then return end

		if Cache.Tracers[strEffectName:lower()] then
			local bestEnt, bestDist = NULL, math.huge

			if IsFirstTimePredicted() and pEffectData:GetStart():DistToSqr(g_pLocalPlayer:GetShootPos()) <= 1 then
				bestEnt = g_pLocalPlayer
			else
				for k in next, Cache.Entities do
					local ent = Entity(k)
					if not IsValid(ent) then continue end
					if not IsValid(bestEnt) then
						bestEnt = ent
						continue
					end

					if ent:IsPlayer() then
						local entDist = ent:GetShootPos():Distance(pEffectData:GetStart())
						if entDist < bestDist then
							bestDist = entDist
							bestEnt = ent
						end
					end
				end
			end
			
			Cache.BulletTracers[#Cache.BulletTracers + 1] = {
				startpos = pEffectData:GetStart(),
				endpos = pEffectData:GetOrigin(),
				owner = bestEnt,
				started = CurTime(),
			}
		end
	end)
	

	AddHook("PostFrameStageNotify", function(stage)
		if stage == FRAME_NET_UPDATE_END then
			LBacktrack:CollectData()

			if Vars.Aimbot.Resolver and IsValid(LRagebot.CurrTarget) then
				TargetAng = LRagebot.CurrTarget:EyeAngles()
			end

			collectgarbage("step")
		end
	end)

	AddHook("PostDrawTranslucentRenderables", function(depth, sky)
		if depth or sky then return end
		
		if Vars.Visuals.Tracers.Bullet then
			for i, t in ipairs(Cache.BulletTracers) do
				if t.started + Vars.Visuals.Tracers.BulletTime <= CurTime() then
					table.remove(Cache.BulletTracers, i)
					continue
				end
		
				local time_left = (t.started + Vars.Visuals.Tracers.BulletTime) - CurTime()
				local perc_left = time_left / Vars.Visuals.Tracers.BulletTime
				local alpha = 255 * perc_left
				
				local color
				if t.owner == g_pLocalPlayer then
					color = Color(255, 255, 255)
				else
					color = Color(255, 0, 0)
				end

				local material = Material("sprites/physbeam")
				render.SetMaterial(material)
				render.DrawBeam(
					t.startpos,
					t.endpos,
					5,
					1 * perc_left,
					2 * perc_left,
					ColorAlpha(color, alpha)
				)
			end 
		end
		
		if Vars.Visuals.Backtrack.Enabled then
			local flDrawTime = GetLerpTime() - Vars.Aimbot.Backtrack.Amount
		
			for Target, track in next, LBacktrack.Records do
				if Target == g_pLocalPlayer then continue end
				if Vars.Visuals.Backtrack.OnlyAimTarget and (LBacktrack.CurrPlayer ~= Target) then continue end
		
				for iRecordIndex = #track, 1, -1 do
					local record = track[iRecordIndex]
					local flTimeDiff = CurTime() - record.SimTime
		
					if IsTickValid(record.SimTime + TickToTime(1)) and flTimeDiff > flDrawTime then
						if Vars.Visuals.Backtrack.VisualStyle == BACKTRACK_VISUAL_STYLE_HITBOX then
							for iHitBox, tData in next, record.Hitboxes do
								local col = LBacktrack.CurrRecord == record and Cache.Colors.Red or Vars.Visuals.Backtrack.Color
								
								render.DrawWireframeBox(tData.Origin, tData.Rotation, tData.Mins, tData.Maxs, col, false)
							end
						elseif Vars.Visuals.Backtrack.VisualStyle == BACKTRACK_VISUAL_STYLE_GHOST then
							Target:SetRenderOrigin(record.VecOrigin)
							Target:InvalidateBoneCache()
							Target:SetupBones()

							for iBoneIndex, pBoneMatrix in next, record.BoneMatrices do
								-- valid bone
								if Target:GetBoneContents(iBoneIndex) > 0 then
									Target:SetBoneMatrix(iBoneIndex, pBoneMatrix)
								end
							end

							local flOldBlend = render.GetBlend()
							render.SetBlend(0.75)
								Target:SetLOD(3)

								if Vars.Visuals.Chams.Player.Enabled then
									local ChamColor = Vars.Visuals.Chams.Player.Color
									local ChamMaterial = Vars.Visuals.Chams.Player.Material
									
									render.MaterialOverride(Cache.ChamMaterials[ChamMaterial])
									render.SetColorModulation(ChamColor.r / 255, ChamColor.g / 255, ChamColor.b / 255)
								end

								Target:DrawModel()

								Target:SetLOD(-1)
							render.SetBlend(flOldBlend)
						end
					end
				end
			end
		end
	end)

	AddHook("EntityFireBullets", function(Player, Data)
		if Player ~= g_pLocalPlayer then return end
		if not IsFirstTimePredicted() then return end 
		
		local Weapon = Player:GetActiveWeapon()
		if not IsValid(Weapon) then return end

		if isvector(Data.Spread) and not Data.Spread:IsZero() then
			Cache.WeaponData.NoSpread.Cones[Weapon:GetClass()] = Data.Spread
		end
	end)

	AddHook("PostDrawHUD", function()
		local EntsThisFrame = {}

		cam.Start2D() -- Seems pointless, but this actually fixes a major issue caused by the rendering of the Avatar ESP
			local EntitiesThisFrame = {} -- Used to sort the ESP so we don't get visual overlapping issues

			if Vars.ESP.Enabled then
				for i = 1, #Cache.Players do
					if not Cache.Players[i]:IsValid() then continue end

					local PlayerTable = Cache.EntityData[Cache.Players[i]] or UpdatePlayerInfo(Cache.Players[i])
					if not PlayerTable or not PlayerTable.ShouldRender then continue end

					EntitiesThisFrame[#EntitiesThisFrame + 1] = { Cache.Players[i], Vars.ESP }
				end
			end

			if Vars.EntityESP.Enabled then
				--PrintTable(Cache.iEntityClasses)
				for i = 1, #Cache.iEntityClasses do
					local Ents = ents.FindByClass(Cache.iEntityClasses[i])
					print(Cache.iEntityClasses[i])
					for ii = 1, #Ents do
						local EntityTable = Cache.EntityData[Ents[ii]] or UpdateEntityInfo(Ents[ii])
						if not EntityTable or not EntityTable.ShouldRender then continue end

						EntitiesThisFrame[#EntitiesThisFrame + 1] = { Ents[ii], Vars.EntityESP }
					end
				end
			end

			table.sort(EntitiesThisFrame, function(A, B)
				return A[1]:GetPos():DistToSqr(EyePos()) > B[1]:GetPos():DistToSqr(EyePos())
			end)

			for i = 1, #EntitiesThisFrame do
				ESP:Run2D(EntitiesThisFrame[i][1], EntitiesThisFrame[i][2])
			end
		cam.End2D()
		
		if Vars.Miscellaneous.Crosshair.Enabled and not Vars.Miscellaneous.ThirdPerson.Enabled then
			local W = math.Round(Vars.Miscellaneous.Crosshair.Length, 1)
			local H = math.Round(Vars.Miscellaneous.Crosshair.Thickness, 1)
				
			local X = Cache.ScreenData.Center.X
			local Y = Cache.ScreenData.Center.Y
				
			if Vars.Miscellaneous.Crosshair.Type == "basic" then
				local hW = W / 2
				local hH = H / 2
				
				surface.SetDrawColor(Cache.Colors.Black)
				surface.DrawRect(X - hW, Y - hH, W, H)
				surface.DrawRect(X - hH, Y - hW, H, W)
			
				surface.SetDrawColor(Cache.Colors.Red)
				surface.DrawRect(X - hW + 1, Y - hH + 1, W - 2, H - 2)
				surface.DrawRect(X - hH + 1, Y - hW + 1, H - 2, W - 2)
			end
		end
			
		if Vars.Aimbot.AimCone.Enabled then 
			local Color = Vars.Aimbot.AimCone.Color
			if Vars.Aimbot.AimCone.Shape == "Circle" then
				surface.DrawCircle(Cache.ScreenData.Center.X, Cache.ScreenData.Center.Y,  GetFOVRadius(), Color) 
			elseif Vars.Aimbot.AimCone.Shape == "Triangle" then
				local x, y = Cache.ScreenData.ScrW * 0.5, Cache.ScreenData.ScrH * 0.5
				local fovrad = (math.tan(math.rad(Vars.Aimbot.AimCone.FOV)) / math.tan(math.rad(Cache.CalcViewData.FOV * 0.5)) * Cache.ScreenData.ScrW) / 2.6
			
				local t = fovrad * 2.33333333333333333
				local s = x - (t / 2)
				local m = fovrad
				local offset_y = 0 - (fovrad / 3.5)
				
				Cache.FOVTri = {
					{x = s, y = (y + m) + offset_y},
					{x = s + t, y = (y + m) + offset_y},
					{x = x, y = (y - m) + offset_y}
				}		
				
				local v1, v2, v3 = Cache.FOVTri[1], Cache.FOVTri[2], Cache.FOVTri[3]
				
				surface.SetDrawColor(Color)
				
				surface.DrawLine(v1.x, v1.y, v2.x, v2.y)
				surface.DrawLine(v2.x, v2.y, v3.x, v3.y)
				surface.DrawLine(v3.x, v3.y, v1.x, v1.y)	
			end
		end	

		if Vars.Visuals.DebugInfo then 
			ShowInfo() 
		end
	end)


	AddHook("Tick", function()
		local Time = SysTime()

		if Time - Cache.LastPlayerListUpdate >= 0.3 then
			-- Entities

			Cache.Entities = ents.GetAll()

			for i = #Cache.Entities, 1, -1 do
				if Cache.Entities[i]:EntIndex() < 0 then -- Stupid ass entities
					Cache.Entities[i] = nil
				end
			end

			-- Players
			table.Empty(Cache.Players)

			local Players = player.GetAll()

			for i = 1, #Players do
				Cache.Players[#Cache.Players + 1] = Players[i]
			end

			---- menu shit
			
			local doUpdatePlayerList = false

			if IsValid(Cache.Panels.EnvPlayerList) then
				if #Cache.Players ~= #Cache.Panels.EnvPlayerList:GetLines() then
					doUpdatePlayerList = true
				end
			end

			for i = 1, #Cache.Players do
				if not IsValid(Cache.Players[i]) then
					doUpdatePlayerList = true

					break
				end
			end

			if doUpdatePlayerList then
				UpdatePlayerList()
			end

			local InValid = {}
			for k, _ in pairs(Cache.EntityData) do
				if not k:IsValid() then
					InValid[#InValid + 1] = k
				end
			end

			for i = #InValid, 1, -1 do
				Cache.EntityData[InValid[i]] = nil
			end
			
			InValid = nil

			Cache.LastPlayerListUpdate = Time
		end

		-- Collect player data
		for i = 1, #Cache.Players do
			if not Cache.Players[i]:IsValid() then continue end
			UpdatePlayerInfo(Cache.Players[i])
		end

		-- Collect entity data
		for i = 1, #Cache.iEntityClasses do
			local Ents = ents.FindByClass(Cache.iEntityClasses[i])

			for ii = 1, #Ents do
				UpdateEntityInfo(Ents[ii])
			end
		end

		local LRagebot = LRagebot
		if not Vars.Aimbot.Sticky or (Vars.Aimbot.Sticky and not LRagebot:IsViableTarget(LRagebot.CurrTarget)) then
			LRagebot.CurrTarget = LRagebot:GetAimTarget()
		end
		
		---- rainbow physgun
		
		if Vars.Miscellaneous.RainbowPhys.Enabled then
			local col = HSVToColor(Time * (Vars.Miscellaneous.RainbowPhys.Frequency * 15) % 360, 1, 1)
			
			col = Color(col.r, col.g, col.b, col.a)

			g_pLocalPlayer:SetWeaponColor(col:ToVector())
		end
	end)

	AddHook("PrePlayerDraw", function(Player)
		if Player == g_pLocalPlayer then return end

		if g_bPseudoNoInterp then
			if not LBacktrack then
				g_bPseudoNoInterp = false
				return
			end
	
			local track = LBacktrack.Records[Player]
			if not track then return end
	
			local record = track[1] -- fuck it lol
			if not record then return end
	
			Player:InvalidateBoneCache()
			Player:SetRenderOrigin(record.VecOrigin)
			Player:SetPos(record.VecOrigin)
	
			for iBoneIndex, pBoneMatrix in next, record.BoneMatrices do
				if Player:GetBoneContents(iBoneIndex) > 0 then
					Player:SetBoneMatrix(iBoneIndex, pBoneMatrix)
				end
			end
		end
	end)

	AddHook("PreDrawEffects", function()
		local Blend = render.GetBlend()

		if Vars.Visuals.Chams.Player.Enabled then
			for i = 1, #Cache.Players do
				if not Cache.Players[i]:IsValid() then continue end

				local PlayerTable = Cache.EntityData[Cache.Players[i]] or UpdatePlayerInfo(Cache.Players[i])
				if not PlayerTable or not PlayerTable.ShouldRender then continue end
				if not OnScreen(Cache.Players[i]) then continue end

				Chams:DrawChams(Cache.Players[i], Vars.Visuals.Chams.Player)
			end
		end

		if Vars.Visuals.Chams.Entity.Enabled then
			for i = 1, #Cache.iEntityClasses do
				local Ents = ents.FindByClass(Cache.iEntityClasses[i])
				
				for ii = 1, #Ents do
					local EntityTable = Cache.EntityData[Ents[ii]] or UpdateEntityInfo(Ents[ii])
					if not EntityTable or not EntityTable.ShouldRender then continue end
					if not OnScreen(Ents[ii]) then continue end

					Chams:DrawChams(Ents[ii], Vars.Visuals.Chams.Entity)
				end
			end
		end

		if Vars.Visuals.HitBoxes.Enabled then
			for _, v in ipairs(GetSortedPlayers()) do
				if not v:IsTargetable() then continue end
				if not Vars.Visuals.HitBoxes.LocalPlayer and v == g_pLocalPlayer then continue end
				
				HitBoxes(v)
			end
		end
	
		render.SetBlend(Blend)
		render.SetColorModulation(1, 1, 1)
		render.MaterialOverride(nil)
	end)
	
	local IsDrawingChams = false
	AddHook("PreDrawViewModel", function()
		if not Vars.Visuals.Chams.Player.Local.ViewModel.Enabled then return end
		
		local VMColor = Vars.Visuals.Chams.Player.Local.ViewModel.Color
		local VMMaterial = Vars.Visuals.Chams.Player.Local.ViewModel.Material
		
		if IsDrawingChams then
			render.SetColorModulation(VMColor.r / 255, VMColor.g / 255, VMColor.b / 255)
			render.MaterialOverride(Cache.ChamMaterials[VMMaterial])
			render.SetBlend(1)
		end

		render.SetBlend(1)
	end)
		
	AddHook("PostDrawViewModel", function()
		if not Vars.Visuals.Chams.Player.Local.ViewModel.Enabled then return end
		
		render.SetColorModulation(1, 1, 1)
		render.MaterialOverride(nil)
		render.SetBlend(1)
		render.SuppressEngineLighting(false)
		
		if IsDrawingChams then return end

		IsDrawingChams = true
		g_pLocalPlayer:GetViewModel():DrawModel()
		IsDrawingChams = false
	end)

	AddHook("PrePlayerDraw",function(Player)
		if Player ~= g_pLocalPlayer then return end

		if MultiplayerAnimState.Instances[LP_FAKE] then
			MultiplayerAnimState:ApplyCachedPoseParameters(LP_FAKE)
			MultiplayerAnimState:ApplyAnimationLayers(LP_FAKE)

			Player:UseClientSideAnimation(false)
			Player:AnimResetGestureSlot(GESTURE_SLOT_VCD)
			Player:AnimResetGestureSlot(GESTURE_SLOT_CUSTOM)

			Player:SetPoseParameter("head_pitch", 0)
			Player:SetPoseParameter("head_yaw", 0)

			Player:InvalidateBoneCache()
			Player:SetupBones()
		end
	end)

	AddHook("PostPlayerDraw", function(Player)
		if Player ~= g_pLocalPlayer then return end

		if MultiplayerAnimState.Instances[LP_FAKE] then
			MultiplayerAnimState:RestoreAnimationLayers(LP_FAKE)
			Player:InvalidateBoneCache()
			Player:SetupBones()
		end
	end)

	AddHook("InputMouseApply", function(Command, MouseX, MouseY, Angle)
		if not Vars.Aimbot.Silent or g_pLocalPlayer:IsFrozen() then return end
		
		local Weapon = g_pLocalPlayer:GetActiveWeapon()

		if IsValid(Weapon) then
			if Weapon.FreezeMovement and Weapon:FreezeMovement() then return end
			if Weapon:GetClass() == "weapon_physgun" and IsValid(Weapon:GetInternalVariable("m_hGrabbedEntity")) and (Command:KeyDown(IN_USE) or g_pLocalPlayer:KeyDown(IN_USE)) then return end -- Physgun rotating (CUserCmd:KeyDown is jank in this hook)
		end

		Cache.FacingAngle.pitch = Cache.FacingAngle.pitch + (MouseY * Cache.ConVars.m_pitch:GetFloat())
		Cache.FacingAngle.yaw = Cache.FacingAngle.yaw - (MouseX * Cache.ConVars.m_yaw:GetFloat())

		FixAngle(Cache.FacingAngle)
	end)

	AddHook("CreateMove", function(Command)
		if not Vars.Aimbot.Enabled then
			Cache.FacingAngle = Command:GetViewAngles()
		end

		Command:SetViewAngles(Cache.FacingAngle)
	end)

	AddHook("CreateMoveEx", function(Command, SendPacket)
		g_bSendPacket = SendPacket
		g_bShouldEngineViewAngles = true

		g_pCmd = Command
		g_iChokedPackets = proxi.GetChokedCommands()

		if g_pCmd:GetInWorldClicker() then
            local x, y = input.GetCursorPos()
            g_pCmd:SetWorldClickerAngles(ScreenToWorld(x, y))
        end

		if g_bIsMoatServer then
			g_pCmd:SetMouseWheel(127)
		end
		
		if not g_pLocalPlayer:Alive() then return end

		local bIsPredicted = g_pCmd:TickCount() == 0

        if g_bPseudoNoInterp or g_bNoPlayerInterp then
            g_pCmd:SetTickCount(g_pCmd:TickCount() + TimeToTick(GetLerpTime()))
        end

		SMovement:Run(g_pCmd)

		if not bIsPredicted and Vars.HvH.FakeLag.Enabled then
			if Vars.HvH.FakeLag.FuckTicks then FuckTicks() end

			g_bSendPacket = FakeLag(g_bSendPacket)
		end
		
		g_iOriginalSequence = proxi.GetSequenceNumber() or -1
		if g_bHasProxi and not bIsPredicted then
			SequenceFreeze(g_pCmd)
		end
		g_iPostSequence = proxi.GetSequenceNumber() or -1
		
		if g_pCmd:CommandNumber() ~= 0 then 
			if g_bSequenceRan then
				local iSequenceDifference = g_iPostSequence - g_iOriginalSequence
				g_pLocalPlayer:SetDTNetVar("DT_LocalPlayerExclusive->m_nTickBase", g_pLocalPlayer:GetTickBase() - iSequenceDifference)
			end
			
			g_bInEnginePrediction = true
			proxi.StartPrediction(g_pCmd) 
		end
			
		Triggerbot:Run()
		LRagebot:Run()
		LAntiAim:Run()
		LNoSpread:Run()

		if LNoSpread.m_bIsFiringThisTick then
			g_bShouldEngineViewAngles = false
		end

		if Vars.HvH.FakeDuck.Enabled or input.IsButtonDown(Vars.HvH.FakeDuck.Key) then
			g_bSendPacket = FakeDuck(g_pCmd, g_bSendPacket)
		end

		RapidFire(g_pCmd)
		
		if g_bInEnginePrediction and g_pCmd:CommandNumber() ~= 0 then
			proxi.EndPrediction()
			g_bInEnginePrediction = false
		end

		if not IsValid(g_pLocalPlayer:GetVehicle()) then
			RotateMovement(g_pCmd)
		end

		if g_bSendPacket then g_iChokedPackets = 0 end
			
		if g_bSequenceRan then
			g_bSendPacket = true
			g_pCmd:SetCommandNumber(g_iPostSequence)
		end

		if g_pLocalPlayer:IsTyping() then 
			hook.Run("ChatTextChanged", RandomString(18, true))
			/*
			local MySource = debug.getinfo(1).source
			AddHook("ChatTextChanged", function(Text)
				if debug.getinfo(4).source == MySource then return end

				hook.Run("ChatTextChanged", RandomString(Text:len()))
			end)*/
		end

		if g_bSendPacket then
			MultiplayerAnimState.Instances[LP_FAKE].EyePitch = math.NormalizeAngle(g_pCmd:GetViewAngles().p)
			MultiplayerAnimState.Instances[LP_FAKE].EyeYaw = math.NormalizeAngle(g_pCmd:GetViewAngles().y)
		end

		MultiplayerAnimState.Instances[LP_REAL].EyePitch = math.NormalizeAngle(g_pCmd:GetViewAngles().p)
		MultiplayerAnimState.Instances[LP_REAL].EyeYaw = math.NormalizeAngle(g_pCmd:GetViewAngles().y)

		g_bSequenceRan = false
		
		if g_pCmd:TickCount() ~= 0 then
			if not isbool(g_bSendPacket) then
				g_bSendPacket = true
			end
				
			if not isbool(g_bShouldEngineViewAngles) then
				g_bShouldEngineViewAngles = true
			end

			return g_bSendPacket, g_bShouldEngineViewAngles
		end
	end)
		
	AddHook("PreFrameStageNotify", function(stage)
		if stage == FRAME_NET_UPDATE_POSTDATAUPDATE_END and g_bNoPlayerInterp then
			local pWep = g_pLocalPlayer:GetActiveWeapon()
			if IsValid(pWep) then
				proxi.SetInterpolationEnabled(pWep, false)
			end

			local pUseEnt = g_pLocalPlayer:GetUseEntity()
			if IsValid(pUseEnt) then
				proxi.SetInterpolationEnabled(pUseEnt, false)
			end

			for _, v in next, Cache.Players do
				if not IsValid(v) or v == g_pLocalPlayer then continue end

				proxi.SetInterpolationEnabled(v, false)
			end
		end
	end)

	AddHook("FinishMove", function(Player, mv)
		local ang = Player:GetViewPunchAngles()
		local vel = Player:GetViewPunchVelocity()

		g_vPunchAngle = Vector(ang.x, ang.y, ang.z)
		g_vPunchAngleVel = Vector(vel.x, vel.y, vel.z)

		if g_vPunchAngle:LengthSqr() > .001 or g_vPunchAngleVel:LengthSqr() > .001 then
			g_vPunchAngle:Add(g_vPunchAngleVel * Cache.TickInterval)
			local damping = 1 - (9 * Cache.TickInterval)

			if damping < 0 then
				damping = 0
			end

			g_vPunchAngleVel:Mul(damping)
			
			local springForceMagnitude = 65 * Cache.TickInterval
			springForceMagnitude = math.Clamp(springForceMagnitude, 0, 2)
			g_vPunchAngleVel:Sub(g_vPunchAngle * springForceMagnitude)

			g_vPunchAngle:SetUnpacked(math.Clamp(g_vPunchAngle.x, -89, 89), math.Clamp(g_vPunchAngle.y, -179, 179), math.Clamp(g_vPunchAngle.z, -89, 89))

			g_vPunchAngle = Angle(g_vPunchAngle.x, g_vPunchAngle.y, g_vPunchAngle.z)
			g_vPunchAngleVel = Angle(g_vPunchAngleVel.x, g_vPunchAngleVel.y, g_vPunchAngleVel.z)
		else
			g_vPunchAngle = Angle()
			g_vPunchAngleVel = Angle()
		end
	end)

	AddHook("ShouldDrawLocalPlayer", function(Player) -- this hook is pretty retarded
		if Vars.Miscellaneous.ThirdPerson.Enabled then
			if Vars.Miscellaneous.ThirdPerson.Distance > 0 then
				return true
			end
		end
	
		return g_pLocalPlayer:ShouldDrawLocalPlayer()
	end)
	
	AddHook("CalcView", function(Player, Origin, Angles, FOV, ZNear, ZFar, ThisServerIsRetarded)
		if ThisServerRetarded then -- 208.103.169.66
			ZNear = ZFar
			ZFar = ThisServerIsRetarded
		end

		Angles:Set(Cache.FacingAngle)
		if not Vars.Aimbot.AntiRecoil then
			Angles:Add(Player:GetViewPunchAngles()) -- Modify it directly through reference rather than returning
		end

		if Vars.Miscellaneous.ThirdPerson.Enabled then
			Origin:Sub((Cache.FacingAngle - Angle(0, Vars.Miscellaneous.ThirdPerson.Y, 0)):Forward() * Vars.Miscellaneous.ThirdPerson.Distance)
		end

		if Vars.Miscellaneous.FOV.Enabled then
			FOV = Vars.Miscellaneous.FOV.Desired
		end

		-- Collect information
		if not Cache.CalcViewData.Origin then
			Cache.CalcViewData.Origin = Vector(Origin)
		else
			Cache.CalcViewData.Origin:Set(Origin)
		end

		if not Cache.CalcViewData.Angles then
			Cache.CalcViewData.Angles = Angle(Angles)
		else
			Cache.CalcViewData.Angles:Set(Angles)
		end

		Cache.CalcViewData.FOV = FOV
		Cache.CalcViewData.ZNear = ZNear
		Cache.CalcViewData.ZFar = ZFar
	end)

	AddHook("OnScreenSizeChanged", function()
		Cache.ScreenData.ScrW = ScrW()
		Cache.ScreenData.ScrH = ScrH()

		Cache.ScreenData.Center.X = math.floor(Cache.ScreenData.ScrW / 2)
		Cache.ScreenData.Center.Y = math.floor(Cache.ScreenData.ScrH / 2)
	end)

	AddHook("ShutDown", function()
		_G.proxi = proxi
	end)

	--[[
		ConCommands
	]]

	AddConCommand("sh_menu", function()
		ToggleMenu()
	end)
	
	AddConCommand("sh_unload", function()
		for i = 1, #Cache.Hooks.Local do
			local CurrHook = Cache.Hooks.Local[i]
			local Type, Name = CurrHook[1], CurrHook[2]

			Log("Hook Removed [{%s} {%s}]", Type, Name)

			hook.Remove(Type, Name)
		end

		timer.Remove("fgui_SlowTick")
		
		Cache.Panels.MainFrame:Remove()
		Cache.Panels.EnvFrame:Remove()

		concommand.Remove("sh_menu")
		concommand.Remove("sh_unload")

		local CollectGarbage = collectgarbage
		table.Empty(Data.Environment)
		Data.Environment = nil
		CollectGarbage("collect")
	end)
end
