if ( SERVER ) then return end

/*Current Version: 1.0000

o Changelog:
	> Added New Anti-Cheat Protection
	> Added Fade Effect

o Credits:
	> shadowslayer842		- Creator.
	> XyLver Blade			- Menu Maker

COPYRIGHT © FR1KIN FAGGOT CO.

OverDone Private

This is a old script I havent used in months, it's not leaked, it was released to the public.

Removed nospread code because it wouldn't work anyways.

Alot of code could of been copied due to lack of intelligance or plain laziness. 
But it wouldn't matter because I'm not selling it am I.

THIS CONTAINS REALLY NEW SCRIPTS WHEN I SUCKED LUA
--]]-----------------------------------------------------------------------------


--<<---------------------------------->>--
--<< WARNING!!!: EXTREMELY MESSY CODE >>--
--<<---------------------------------->>--

--[[
	Client Commands, Hooks...
	Desc: Main commands, hooks, and more.
--]]
*/

local VersionNumber = "1.0"
local Version 		= "v" .. VersionNumber .. " Public"
local DermaPanel
/*
Msg( "Over Done " .. Version .. " loaded!" )
Msg( "Thanks For using OverDone a hack by HaXoR" )
Msg( "Questions, comments, tell me here http://steamcommunity.com/id/theMoDeR//" )
*/

chat.AddText(
    Color(153,153,152,255), "[OD] ",
    Color(255,0,0,255), "Hack ",
    Color(255,0,0,255), "Loaded ",
	Color(255,0,0,255), "Successfully..." )







//Local ConVars
//Esp
local convar = CreateClientConVar( "l4d_glow", 0, true, false)
local teamcolors = CreateClientConVar( "l4d_teamcolors", 0, true, false)
local passes = CreateClientConVar( "l4d_passes", 0, true, false)
local Warning = CreateClientConVar("od_warnings", 0, true, false)
local lasersight = CreateClientConVar("od_lasersights", 0, true, false)
local Healthbar = CreateClientConVar( "od_healthbar", 0, true, false)
local wallhack = CreateClientConVar( "od_wallhack", 0, true, false)
local barrelhax = CreateClientConVar( "od_lazereyes", 0, true, false)
local playerbox = CreateClientConVar( "od_playerbox", 0, true, false)
local skeleton = CreateClientConVar( "od_skeletonesp", 0, true, false)
//Misc
local Crossair = CreateClientConVar( "od_crosshair", 0, true, false)
local nospread = CreateClientConVar( "od_nospread", 0, true, false)
local Antigag = CreateClientConVar("od_antigag", 0 ,true, false)

//Aimbot












//Main Core Of Code
hook.Add( "HUDPaint", "Wallhack", function()
	if wallhack:GetBool() then 
		for k,v in pairs ( player.GetAll() ) do
			local Position = ( v:GetPos() + Vector( 0,0,85 ) ):ToScreen()
			draw.SimpleTextOutlined( v:Name(), "MenuLarge", Position.x, Position.y, Color(0,0,0,255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, Color(255,255,255,255) ) 
		end
	end
	if Crossair:GetBool() then
		local g = 5
		local s, x, y, l = 10, ScrW() / 2, ScrH() / 2, g + 15
		local hply = LocalPlayer():Health()
		local nply = LocalPlayer():GetName()
		local xhp, yhp = ScrW()/(2) -25, ScrH()/(2) -15
		local xname, yname = ScrW()/(2), ScrH()/(2) +20 
		surface.DrawCircle( x, y, 10, Color(255,0,0,255) ) 		
		surface.DrawLine(ScrW() / 2 - 10, ScrH() / 2, ScrW() / 2 + 11 , ScrH() / 2)
		surface.DrawLine(ScrW() / 2 - 0, ScrH() / 2 - 10, ScrW() / 2 - 0 , ScrH() / 2 + 11)
		draw.SimpleTextOutlined( hply, "MenuLarge", xhp, yhp, Color(0,0,0,255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, Color(255,255,255,255) )
		draw.SimpleTextOutlined( nply, "MenuLarge", xname, yname, Color(255,255,255,255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, Color(0,0,0,255) )
	end
end)

function Barrelhax() 
	if barrelhax:GetBool() then
		for k,v in pairs(player.GetAll()) do
			if (v!=LocalPlayer() and v:Alive() and v:IsPlayer()) then
				cam.Start3D( EyePos() , EyeAngles())
				render.SetMaterial( Material( "cable/physbeam" ) )
				render.DrawBeam(v:GetBonePosition(v:LookupBone("ValveBiped.Bip01_Head1")) , v:GetEyeTrace().HitPos , 5, 0, 0, Color(255,255,255, 255 ))
				cam.End3D()
			end
		end
	end
end
 
 hook.Add("HUDPaint","Specline", Barrelhax)
	
function Antigag()
	if Antigag:GetBool() then
		hook.Remove("PlayerBindPress", "ULXGagForce")
		timer.Destroy("GagLocalPlayer")
	end
end

if Warning:GetInt() >= 1 then
	for k,v in pairs(ents.GetAll()) do		
		if ValidEntity(v) and table.HasValue(Warnings,v:GetClass()) then
				surface.CreateFont("MS Reference Sans Serif", 13, 100,true, false, "IsisEspFonta")
				local Warnpos = v:GetPos():ToScreen()
				draw.SimpleText("*Warning*", "IsisEspFonta" , Warnpos.x  , Warnpos.y , Color(255,150,0,255) , TEXT_ALIGN_CENTER , TEXT_ALIGN_CENTER)
		end
	end
end

	
//Warnings
local Warnings = {
	"grenade_ar2",
	"prop_combine_ball",
	"hunter_flechette",
	"ent_flashgrenade",
	"ent_smokegrenade",
	"ent_explosivegrenade",
	"ttt_confgrenade_proj",
	"ttt_firegrenade_proj",
	"ttt_smokegrenade_proj",
	"npc_grenade_frag",
	"rpg_missile"
}
	
	
	
//------------------------------------------------------------//
//----------------------Laser Sights-------------------------//
local lasersight = false
function lasersight() 	
	if lasersight then		
		local ply = LocalPlayer()
    	local vm = ply:GetViewModel()
		if vm and ValidEntity(ply:GetActiveWeapon()) then
			local attachmentIndex = vm:LookupAttachment("1")
			if attachmentIndex == 0 then
				attachmentIndex = vm:LookupAttachment("muzzle")
			end
            local t = util.GetPlayerTrace(ply)
			local tr = util.TraceLine(t)
			if vm:GetAttachment(attachmentIndex) then
				cam.Start3D(EyePos(), EyeAngles())
					render.SetMaterial(Material("sprites/bluelaser1"))
					render.DrawBeam(vm:GetAttachment(attachmentIndex).Pos, tr.HitPos, 2, 0, 12.5, Color(255, 0, 0, 255))				
					local Size = math.random() * 10
				cam.End3D()
			end
		end
	end
end
//----------------------End Of Laser Sights------------------//	
//----------------------------------------------------------//	
	

Skeleton = {
	// Main body
	{ S = "ValveBiped.Bip01_Head1", E = "ValveBiped.Bip01_Neck1" },
	{ S = "ValveBiped.Bip01_Neck1", E = "ValveBiped.Bip01_Spine4" },
	{ S = "ValveBiped.Bip01_Spine4", E = "ValveBiped.Bip01_Spine2" },
	{ S = "ValveBiped.Bip01_Spine2", E = "ValveBiped.Bip01_Spine1" },
	{ S = "ValveBiped.Bip01_Spine1", E = "ValveBiped.Bip01_Spine" },
	{ S = "ValveBiped.Bip01_Spine", E = "ValveBiped.Bip01_Pelvis" },
	
	// Left Arm
	{ S = "ValveBiped.Bip01_Spine2", E = "ValveBiped.Bip01_L_UpperArm" },
	{ S = "ValveBiped.Bip01_L_UpperArm", E = "ValveBiped.Bip01_L_Forearm" },
	{ S = "ValveBiped.Bip01_L_Forearm", E = "ValveBiped.Bip01_L_Hand" },
	
	// Right Arm
	{ S = "ValveBiped.Bip01_Spine2", E = "ValveBiped.Bip01_R_UpperArm" },
	{ S = "ValveBiped.Bip01_R_UpperArm", E = "ValveBiped.Bip01_R_Forearm" },
	{ S = "ValveBiped.Bip01_R_Forearm", E = "ValveBiped.Bip01_R_Hand" },
	
	// Left leg
	{ S = "ValveBiped.Bip01_Pelvis", E = "ValveBiped.Bip01_L_Thigh" },
	{ S = "ValveBiped.Bip01_L_Thigh", E = "ValveBiped.Bip01_L_Calf" },
	{ S = "ValveBiped.Bip01_L_Calf", E = "ValveBiped.Bip01_L_Foot" },
	{ S = "ValveBiped.Bip01_L_Foot", E = "ValveBiped.Bip01_L_Toe0" },
	
	// Right leg
	{ S = "ValveBiped.Bip01_Pelvis", E = "ValveBiped.Bip01_R_Thigh" },
	{ S = "ValveBiped.Bip01_R_Thigh", E = "ValveBiped.Bip01_R_Calf" },
	{ S = "ValveBiped.Bip01_R_Calf", E = "ValveBiped.Bip01_R_Foot" },
	{ S = "ValveBiped.Bip01_R_Foot", E = "ValveBiped.Bip01_R_Toe0" },
}

function minmax( e )
	local ply, pos = LocalPlayer(), ""
	local center = e:LocalToWorld( e:OBBCenter() )
	local min, max = e:OBBMins(), e:OBBMaxs()
	local dim = max - min
	local z = max + min
	
	local frt	= ( e:GetForward() ) * ( dim.y / 2 )
	local rgt	= ( e:GetRight() ) * ( dim.x / 2 )
	local top	= ( e:GetUp() ) * ( dim.z / 2 )
	local bak	= ( e:GetForward() * -1 ) * ( dim.y / 2 )
	local lft	= ( e:GetRight() * -1 ) * ( dim.x / 2 )
	local btm	= ( e:GetUp() * -1 ) * ( dim.z / 2 )
	
	local FRT 	= center + frt + rgt + top; FRT = FRT:ToScreen()
	local BLB 	= center + bak + lft + btm; BLB = BLB:ToScreen()
	local FLT	= center + frt + lft + top; FLT = FLT:ToScreen()
	local BRT 	= center + bak + rgt + top; BRT = BRT:ToScreen()
	local BLT 	= center + bak + lft + top; BLT = BLT:ToScreen()
	local FRB 	= center + frt + rgt + btm; FRB = FRB:ToScreen()
	local FLB 	= center + frt + lft + btm; FLB = FLB:ToScreen()
	local BRB 	= center + bak + rgt + btm; BRB = BRB:ToScreen()
	
	local maxX = math.max( FRT.x,BLB.x,FLT.x,BRT.x,BLT.x,FRB.x,FLB.x,BRB.x )
	local minX = math.min( FRT.x,BLB.x,FLT.x,BRT.x,BLT.x,FRB.x,FLB.x,BRB.x )
	local maxY = math.max( FRT.y,BLB.y,FLT.y,BRT.y,BLT.y,FRB.y,FLB.y,BRB.y)
	local minY = math.min( FRT.y,BLB.y,FLT.y,BRT.y,BLT.y,FRB.y,FLB.y,BRB.y )
	
	return {maxX, minX, maxY, minY}
end

/* 
function CanSeePlayer(ply)
	local tracedata = {}
	tracedata.start = LocalPlayer():GetPos()
	tracedata.endpos = ply:GetPos()
	tracedata.filter = LocalPlayer()
	local trace = util.TraceLine(tracedata)
	if trace.HitNonWorld then
		return trace.Entity == ply
	end
	return false
end
*/

function CanSeePlayer( pl )
     return util.GetPlayerTrace( LocalPlayer(), LocalPlayer():EyePos() - pl2:EyePos() ) and util.GetPlayerTrace( LocalPlayer(), LocalPlayer():EyePos() - pl2:EyePos() ).Entity == pl2;
end

local function Skeleton(e)	
	if !e:Alive() or e == LocalPlayer() then return end
	for k, v in pairs( Skeleton ) do
		local sPos, ePos = e:GetBonePosition( e:LookupBone( v.S ) ):ToScreen(), e:GetBonePosition( e:LookupBone( v.E ) ):ToScreen()
		
		if CanSeePlayer(e) and e:Team() == LocalPlayer():Team() then
			surface.SetDrawColor( 0, 255, 0, 255 )
		elseif CanSeePlayer(e) then
			surface.SetDrawColor( 0, 0, 255, 255 )
		elseif e:Team() == LocalPlayer():Team() then
			surface.SetDrawColor( 255, 140, 0, 255 )
		else
			surface.SetDrawColor( 255, 0, 0, 255 )
		end
		surface.DrawLine( sPos.x, sPos.y, ePos.x, ePos.y )

		//ply box
	end
	local t = minmax(e)
	surface.DrawLine( t[1], t[3], t[1], t[4] )
	surface.DrawLine( t[1], t[4], t[2], t[4] )
		
	surface.DrawLine( t[2], t[4], t[2], t[3] )
	surface.DrawLine( t[2], t[3], t[1], t[3] )
end

hook.Add("HUDPaint", "SkeletonESP", function()
	for k,v in pairs(player.GetAll()) do
        if v != LocalPlayer() then
		   Skeleton(v)
        end
	end
end)
//End Of Skeleton Esp And PlayerBox//

	//L4d Glow
local MaterialBlurX = Material( "pp/blurx" )
local MaterialBlurY = Material( "pp/blury" )
local MaterialWhite = CreateMaterial( "WhiteMaterial", "VertexLitGeneric", {
    ["$basetexture"] = "color/white",
    ["$vertexalpha"] = "1",
    ["$model"] = "1",
} )
local MaterialComposite = CreateMaterial( "CompositeMaterial", "UnlitGeneric", {
    ["$basetexture"] = "_rt_FullFrameFB",
    ["$additive"] = "1",
} )
 
local RT1 = render.GetBloomTex0()
local RT2 = render.GetBloomTex1()
 
/*------------------------------------
    RenderGlow()
------------------------------------*/
function RenderGlow( entity )
 
    // tell the stencil buffer we're going to write a value of one wherever the model
    // is rendered
    render.SetStencilEnable( true )
    render.SetStencilFailOperation( STENCILOPERATION_KEEP )
    render.SetStencilZFailOperation( STENCILOPERATION_REPLACE )
    render.SetStencilPassOperation( STENCILOPERATION_REPLACE )
    render.SetStencilCompareFunction( STENCILCOMPARISONFUNCTION_ALWAYS )
    render.SetStencilWriteMask( 1 )
    render.SetStencilReferenceValue( 1 )
     
    // this uses a small hack to render ignoring depth while not drawing color
    // i couldn't find a function in the engine to disable writing to the color channels
    // i did find one for shaders though, but I don't feel like writing a shader for this.
    cam.IgnoreZ( true )
        render.SetBlend( 0 )
            SetMaterialOverride( MaterialWhite )
                entity:DrawModel()
            SetMaterialOverride()
        render.SetBlend( 1 )
    cam.IgnoreZ( false )
     
    local w, h = ScrW(), ScrH()
     
    // draw into the white texture
    local oldRT = render.GetRenderTarget()
     
    render.SetRenderTarget( RT1 )
     
        render.SetViewPort( 0, 0, RT1:GetActualWidth(), RT1:GetActualHeight() )
         
        cam.IgnoreZ( true )
         
            render.SuppressEngineLighting( true )
             
            if entity:IsPlayer() then
             
                if teamcolors:GetBool() then
                    local color = team.GetColor( entity:Team() )
                    render.SetColorModulation( color.r/255, color.g/255, color.b/255 )
                else
                    local scale = math.Clamp( entity:Health() / 100, 0, 1 )
                    local r,g,b = (255 - scale * 255), (55 + scale * 200), (50)
                    render.SetColorModulation( r/255, g/255, b/255 )
                end
                 
            else
             
                render.SetColorModulation( 1, 165/255, 0 )
                 
            end
             
                SetMaterialOverride( MaterialWhite )
                    entity:DrawModel()
                SetMaterialOverride()
                 
            render.SetColorModulation( 1, 1, 1 )
            render.SuppressEngineLighting( false )
             
        cam.IgnoreZ( false )
         
        render.SetViewPort( 0, 0, w, h )
    render.SetRenderTarget( oldRT )
     
    // don't need this for the next pass
    render.SetStencilEnable( false )
 
end
 
/*------------------------------------
    RenderScene()
------------------------------------*/
hook.Add( "RenderScene", "ResetGlow", function( Origin, Angles )
 
    local oldRT = render.GetRenderTarget()
    render.SetRenderTarget( RT1 )
        render.Clear( 0, 0, 0, 255, true )
    render.SetRenderTarget( oldRT )
     
end )
 
/*------------------------------------
    RenderScreenspaceEffects()
------------------------------------*/
hook.Add( "RenderScreenspaceEffects", "CompositeGlow", function()
 
    MaterialBlurX:SetMaterialTexture( "$basetexture", RT1 )
    MaterialBlurY:SetMaterialTexture( "$basetexture", RT2 )
    MaterialBlurX:SetMaterialFloat( "$size", 2 )
    MaterialBlurY:SetMaterialFloat( "$size", 2 )
         
    local oldRT = render.GetRenderTarget()
     
    for i = 1, passes:GetFloat() do
     
        // blur horizontally
        render.SetRenderTarget( RT2 )
        render.SetMaterial( MaterialBlurX )
        render.DrawScreenQuad()
 
        // blur vertically
        render.SetRenderTarget( RT1 )
        render.SetMaterial( MaterialBlurY )
        render.DrawScreenQuad()
         
    end
 
    render.SetRenderTarget( oldRT )
     
    // tell the stencil buffer we're only going to draw
    // where the <span class="highlight">player</span> models are not.
    render.SetStencilEnable( true )
    render.SetStencilReferenceValue( 0 )
    render.SetStencilTestMask( 1 )
    render.SetStencilCompareFunction( STENCILCOMPARISONFUNCTION_EQUAL )
    render.SetStencilPassOperation( STENCILOPERATION_ZERO )
     
    // composite the scene
    MaterialComposite:SetMaterialTexture( "$basetexture", RT1 )
    render.SetMaterial( MaterialComposite )
    render.DrawScreenQuad()
 
    // don't need this anymore
    render.SetStencilEnable( false )
     
end )
 
local playerheldweap = nil
 
hook.Add( "PostPlayerDraw", "RenderEntityGlow", function( ply )
    if !convar:GetBool() or ScrW() == ScrH() or OUTLINING_ENTITY then return end
    OUTLINING_ENTITY = true 
    RenderGlow( ply )
    playerheldweap = ply:GetActiveWeapon()
    if IsValid( playerheldweap ) and playerheldweap:IsWeapon() then
        RenderGlow( playerheldweap )
    end
    // prevents recursion time
    OUTLINING_ENTITY = false
	//NO Spread :D
	if nospread:GetBool() then
		if ValidEntity(LocalPlayer():GetActiveWeapon()) and (LocalPlayer():GetActiveWeapon().Primary and LocalPlayer():GetActiveWeapon().Primary.Recoil != 0) then
			LocalPlayer():GetActiveWeapon().OldRecoil = LocalPlayer():GetActiveWeapon().Recoil or (LocalPlayer():GetActiveWeapon().Primary and LocalPlayer():GetActiveWeapon().Primary.Recoil)
			LocalPlayer():GetActiveWeapon().Recoil = 0
			LocalPlayer():GetActiveWeapon().Primary.Recoil = 0
			LocalPlayer():GetActiveWeapon().Spread = 0
			LocalPlayer():GetActiveWeapon().Primary.Spread = 0
			LocalPlayer():GetActiveWeapon().Cone = 0
			LocalPlayer():GetActiveWeapon().Primary.Cone = 0
		end
	end
	//Healthbar
	if Healthbar:GetBool() then
		for k,v in pairs ( player.GetAll() ) do
			if v ~= LocalPlayer() then
				local drawpos1 = (v:GetPos() + Vector(0,0,73)):ToScreen()
				local hp = (v:GetPos() + Vector(0,0,65)):ToScreen()
				local max_health = 100; 
				if( v:Health() > max_health ) then 
					max_health = v:Health(); 
				end
				local mx = max_health / 4; 
				local mw = v:Health() / 4; 
				local drawPosHealth = drawpos1
				drawPosHealth.x = drawPosHealth.x - ( mx / 2 ); 
				drawPosHealth.y = drawPosHealth.y + 10; 
				draw.RoundedBox(4, drawPosHealth.x - 1, hp.y - 1, mx + 2, 4 + 2, Color(0,0,0,255));
				draw.RoundedBox(4, drawPosHealth.x, hp.y, mw, 4, Color(255,255,255,255));
			end
		end
	end
end)

///////////////////////////////Derma//////////////////////////////////
// These are the check boxes
function OverDone()
	if DermaPanel then
		DermaPanel:Remove()
		DermaPanel = nil
	else
		DermaPanel = vgui.Create( "DFrame", "DImage" )
		DermaPanel:SetPos( 200, 200 )
		DermaPanel:SetSize( 500, 500 )
		DermaPanel:SetTitle( "Haxors Hax" )
		DermaPanel:SetVisible( true )
		DermaPanel:SetDraggable( true )
		DermaPanel:ShowCloseButton( true )
		DermaPanel:MakePopup()
		DermaPanel:Center()

		local PSheet = vgui.Create("DPropertySheet",DermaPanel)
		PSheet:SetPos( 5, 30 )
		PSheet:SetSize( 450, 450 )

		local Page1 = vgui.Create("DPanel")
		Page1:SetSize( 340, 415)
		Page1:SetPos(450, 450)
		

		local Page2 = vgui.Create("DPanel")
		Page1:SetSize( 340, 415)
		Page1:SetPos(5, 30)

		local Page3 = vgui.Create("DPanel")
		Page1:SetSize( 340, 415)
		Page1:SetPos(5, 30)

		local Page4 = vgui.Create("DPanel")
		Page1:SetSize( 340, 415)
		Page1:SetPos(5, 30)
		
		local Page5 = vgui.Create("DPanel")
		Page1:SetSize( 340, 415)
		Page1:SetPos(5, 30)

		
	--Esp Check Boxes
		local CheckBoxThing = vgui.Create( "DCheckBoxLabel", Page1 )
		CheckBoxThing:SetPos( 10,50 )
		CheckBoxThing:SetText( "L4d Player Glow" )
		CheckBoxThing:SetConVar( "l4d_glow" ) -- ConCommand must be a 1 or 0 value
		CheckBoxThing:SetValue( GetConVarNumber ( "l4d_glow" ))
		CheckBoxThing:SetTextColor( Color(0 , 0 , 0 , 255 ) )
		CheckBoxThing:SizeToContents() -- Make its size to the contents. Duh?
		
		local CheckBoxThing2 = vgui.Create( "DCheckBoxLabel", Page1 )
		CheckBoxThing2:SetPos( 10,70 )
		CheckBoxThing2:SetText( "L4d Team Color" )
		CheckBoxThing2:SetConVar( "l4d_teamcolors" ) -- ConCommand must be a 1 or 0 value
		CheckBoxThing2:SetValue( GetConVarNumber ( "l4d_teamcolors" ))
		CheckBoxThing2:SetTextColor( Color(0 , 0 , 0 , 255 ) )
		CheckBoxThing2:SizeToContents() -- Make its size to the contents. Duh?
		
		local CheckBoxThing3 = vgui.Create( "DCheckBoxLabel", Page1 )
		CheckBoxThing3:SetPos( 10,90 )
		CheckBoxThing3:SetText( "L4d Passes" )
		CheckBoxThing3:SetConVar( "l4d_passes" ) -- ConCommand must be a 1 or 0 value
		CheckBoxThing3:SetValue( GetConVarNumber ( "l4d_passes" ))
		CheckBoxThing3:SetTextColor( Color(0 , 0 , 0 , 255 ) )
		CheckBoxThing3:SizeToContents() -- Make its size to the contents. Duh?

		local CheckBoxThing4 = vgui.Create( "DCheckBoxLabel", Page1 )
		CheckBoxThing4:SetPos( 10, 110 )
		CheckBoxThing4:SetText( "Healthbar" )
		CheckBoxThing4:SetConVar( "od_healthbar" ) -- ConCommand must be a 1 or 0 value
		CheckBoxThing4:SetValue( GetConVarNumber ( "od_healthbar" ))
		CheckBoxThing4:SetTextColor( Color(0 , 0 , 0 , 255 ) )
		CheckBoxThing4:SizeToContents() -- Make its size to the contents. Duh?
		
		local CheckBoxThing5 = vgui.Create( "DCheckBoxLabel", Page1 )
		CheckBoxThing5:SetPos( 10, 130 )
		CheckBoxThing5:SetText( "CrossHair" )
		CheckBoxThing5:SetConVar( "od_crosshair" ) -- ConCommand must be a 1 or 0 value
		CheckBoxThing5:SetValue( GetConVarNumber ( "od_crosshair" ))
		CheckBoxThing5:SetTextColor( Color(0 , 0 , 0 , 255 ) )
		CheckBoxThing5:SizeToContents() -- Make its size to the contents. Duh?
		
		local CheckBoxThing6 = vgui.Create( "DCheckBoxLabel", Page1 )
		CheckBoxThing6:SetPos( 10, 150 )
		CheckBoxThing6:SetText( "Wallhack" )
		CheckBoxThing6:SetConVar( "od_wallhack" ) -- ConCommand must be a 1 or 0 value
		CheckBoxThing6:SetValue( GetConVarNumber ( "od_wallhack" ))
		CheckBoxThing6:SetTextColor( Color(0 , 0 , 0 , 255 ) )
		CheckBoxThing5:SizeToContents() -- Make its size to the contents. Duh?
		
		local CheckBoxThing7 = vgui.Create( "DCheckBoxLabel", Page1 )
		CheckBoxThing7:SetPos( 10, 170 )
		CheckBoxThing7:SetText( "Lazer Eyes" )
		CheckBoxThing7:SetConVar( "od_lazereyes" ) -- ConCommand must be a 1 or 0 value
		CheckBoxThing7:SetValue( GetConVarNumber ( "od_lazereyes" ))
		CheckBoxThing7:SetTextColor( Color(0 , 0 , 0 , 255 ) )
		CheckBoxThing7:SizeToContents() -- Make its size to the contents. Duh?
		
		local CheckBoxThing8 = vgui.Create( "DCheckBoxLabel", Page1 )
		CheckBoxThing8:SetPos( 10, 190 )
		CheckBoxThing8:SetText( "Playerbox" )
		CheckBoxThing8:SetConVar( "od_playerbox" ) -- ConCommand must be a 1 or 0 value
		CheckBoxThing8:SetValue( GetConVarNumber ( "od_playerbox" ))
		CheckBoxThing8:SetTextColor( Color(0 , 0 , 0 , 255 ) )
		CheckBoxThing8:SizeToContents() -- Make its size to the contents. Duh?
		
		local CheckBoxThing8 = vgui.Create( "DCheckBoxLabel", Page1 )
		CheckBoxThing8:SetPos( 10, 210 )
		CheckBoxThing8:SetText( "Lazer Sights" )
		CheckBoxThing8:SetConVar( "od_lasersights" ) -- ConCommand must be a 1 or 0 value
		CheckBoxThing8:SetValue( GetConVarNumber ( "od_lasersights" ))
		CheckBoxThing8:SetTextColor( Color(0 , 0 , 0 , 255 ) )
		CheckBoxThing8:SizeToContents() -- Make its size to the contents. Duh?
	--Misc Tab
	--Information Tab

		local Info1 = vgui.Create("DLabel")
		Info1:SetParent( Page5 )
		Info1:SetPos( 150 , 30 )
		Info1:SetTextColor( Color ( 0 , 0 , 0 , 255 ) )
		Info1:SetSize( 200 , 20 )
		Info1:SetText("About Over Done")

		local Info2 = vgui.Create("DLabel", Page5)
		Info2:SetParent( Page5 )
		Info2:SetPos( 10 , 50 )
		Info2:SetTextColor( Color ( 0 , 0 , 0 , 255 ) )
		Info2:SetSize( 1000 , 20 )
		Info2:SetText("Hi, Over Done has many features, including playerbox, barrelhax, and l4d glow effects!!!!")

		local Info2 = vgui.Create("DLabel", Page5)
		Info2:SetParent( Page5 )
		Info2:SetPos( 10 , 70 )
		Info2:SetTextColor( Color ( 0 , 0 , 0 , 255 ) )
		Info2:SetSize( 1000 , 20 )
		Info2:SetText("There mabye bugs if you see one or need one fixed bad, pm me on steam...................")

		local Info3 = vgui.Create("DLabel", Page5)
		Info3:SetParent( Page5 )
		Info3:SetPos( 10 , 90 )
		Info3:SetTextColor( Color ( 0 , 0 , 0 , 255 ) )
		Info3:SetSize( 1000 , 20 )
		Info3:SetText("This is the privite version you can get the publice by going to garrysmod.org! Thank you!")

		PSheet:AddSheet( "Esp", Page1, "BaconBot/esp_list", false, false, "Rawrs")
		PSheet:AddSheet( "Aimbot", Page2, "BaconBot/general", false, false, "Shoot them like the skilless guy you are!")
		PSheet:AddSheet( "Miscellaneous", Page3, "BaconBot/misc", false, false, "Explanation about the misc - tooltip")
		PSheet:AddSheet( "Remove", Page4, "BaconBot/false", false, false, "Explanation about the remove - tooltip")
		PSheet:AddSheet( "Information", Page5, "BaconBot/friends", false, false, "Information - tooltip")
	end
end
concommand.Add( "over_done", OverDone )