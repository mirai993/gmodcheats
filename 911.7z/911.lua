--[[
nine_eleven-bot
From Razor
Happy 9/11 Guys
]]

if nine_eleven then 
	_G.rawset(_G, "nine_eleven", nil) 
end

local nine_eleven = {}
nine_eleven.Hooks = {}

nine_eleven.G = _G.table.Copy( _G )

nine_eleven.Bypass = {
	{ cvar = "sv_cheats", val = 1, oval = 0, cc = "bot_changeclass" },
	{ cvar = "sv_allowcslua", val = 1, oval = 0, cc = "bot_flipout" },
	{ cvar = "host_framerate", val = 0, oval = 0, cc = "bot_forceattack2" },
}

nine_eleven.G.require("_cv3")

nine_eleven.Cones = {
	[ "weapon_smg1" ] = nine_eleven.G.Vector( -0.04362, -0.04362, -0.04362 ),
	[ "weapon_ar2" ] = nine_eleven.G.Vector( -0.02618, -0.02618, -0.02618 ),
	[ "weapon_shotgun" ] = nine_eleven.G.Vector( -0.08716, -0.08716, -0.08716 ),
	[ "weapon_pistol" ] = nine_eleven.G.Vector( -0.01, -0.01, -0.01),
}

nine_eleven.CVars = {}

function nine_eleven.Notify(msg)
	nine_eleven.G.MsgC(nine_eleven.G.Color(255,93,0), "[nine_eleven-bot]: ", nine_eleven.G.Color(40,150,20), msg, "\n")
end

for k,v in nine_eleven.G.pairs(nine_eleven.Bypass) do
	if !nine_eleven.G.ConVarExists(v.cc) then continue end
	GetConVar(v.cvar):SetName("nine_eleven_"..v.cvar)
	GetConVar(v.cc):SetName(v.cvar)
	GetConVar(v.cvar):SetValue(v.oval)
	GetConVar(v.cvar):SetFlags(v.oval)
	GetConVar("nine_eleven_"..v.cvar):SetValue(v.val)
	GetConVar("nine_eleven_"..v.cvar):SetFlags(v.val)
	nine_eleven.Notify("Renamed '"..v.cvar.."' to '".."nine_eleven_"..v.cvar.."'.")
end

function nine_eleven.Copy(tab)
	local copy = {}
	local tab_type = nine_eleven.G.type(tab)
	if tab_type == "table" then
		for k,v in nine_eleven.G.pairs(tab) do
			copy[k] = v
		end
	else
		copy = tab
	end
	if copy.MetaName then
		nine_eleven.Notify("Copied Metatable '"..copy.MetaName.."'.")
	end
	return copy
end

function nine_eleven.CreateCvar(c, v)
	nine_eleven.Notify("Created CVar '"..c.."'.")
	nine_eleven.G.CreateClientConVar(c,v)
	nine_eleven.G.table.insert(nine_eleven.CVars, c)
end

nine_eleven.R = nine_eleven.Copy(nine_eleven.G.debug.getregistry())

function nine_eleven.AddHook(ht, hn, hf)
	if !ht or !hn or !hf then return end
	local add_hook = nine_eleven.G.hook and nine_eleven.G.hook.Add or hook and hook.Add or function() print("failed") end
	add_hook(ht, hn, hf)
	if !nine_eleven.Hooks[ht] then
		nine_eleven.Hooks[ht] = {}
	end
	nine_eleven.Hooks[ht][hn] = hf
	nine_eleven.Notify("Added Hook ("..ht..":"..hn..").")
end

nine_eleven.PlyM = nine_eleven.Copy(nine_eleven.G.FindMetaTable("Player"))
nine_eleven.EntM = nine_eleven.Copy(nine_eleven.G.FindMetaTable("Entity"))
nine_eleven.CmdM = nine_eleven.Copy(nine_eleven.G.FindMetaTable("CUserCmd"))
nine_eleven.VecM = nine_eleven.Copy(nine_eleven.G.FindMetaTable("Vector"))
nine_eleven.AngM = nine_eleven.Copy(nine_eleven.G.FindMetaTable("Angle"))

nine_eleven.R.Entity.FireBullets = function(p, bullet)
	local w = nine_eleven.PlyM.GetActiveWeapon(nine_eleven.Me)
	if !nine_eleven.EntM.IsValid(w) then return end
	local class = nine_eleven.EntM.GetClass(w)
	local spread = bullet.Spread
	if !spread then return end
	if nine_eleven.Cones[class] != spread * -1 then
		nine_eleven.Cones[class] = spread * -1
		nine_eleven.Notify("Found Weapon Cone: "..class.." | "..nine_eleven.G.tostring(spread * -1))
	end
end

nine_eleven.G.require("dickwrap")
nine_eleven.G.require("_nyx")

nine_eleven.nyx = nine_eleven.Copy( _nyx )
nine_eleven.dickwrap = nine_eleven.Copy( dickwrap )
nine_eleven.Me = nine_eleven.G.LocalPlayer()

nine_eleven.nyx.Init()
GetConVar("sv_cheats"):SetValue("0")

nine_eleven.Enabled = false
nine_eleven.Target = nil

nine_eleven.CreateCvar("nine_eleven_bhop", 1)
nine_eleven.CreateCvar("nine_eleven_bhop_autostrafe", 0)

local strafe

local oa = nine_eleven.G.Angle()

nine_eleven.CreateCvar("nine_eleven_nospread", 1)
nine_eleven.CreateCvar("nine_eleven_nospread_module", 1)

function nine_eleven.PredictSpread(ucmd, ang)
	local w = nine_eleven.PlyM.GetActiveWeapon(nine_eleven.Me)
	if !nine_eleven.EntM.IsValid(w) then 
		return ang
	end
	local class = nine_eleven.EntM.GetClass(w)
	if !nine_eleven.Cones[class] then
		return ang
	end
	local removespread = nine_eleven.G.GetConVarNumber("nine_eleven_nospread_module") == 1 and nine_eleven.nyx.RemoveSpread or nine_eleven.dickwrap.Predict
	if nine_eleven.G.GetConVarNumber("nine_eleven_nospread_module") != 1 then 
		ang = nine_eleven.AngM.Forward(ang)
	end
	local nospred = nine_eleven.VecM.Angle(removespread(ucmd, ang, nine_eleven.Cones[class]))
	nospred.y = nine_eleven.G.math.NormalizeAngle(nospred.y)
	return nospred
end

nine_eleven.CreateCvar("nine_eleven_targetfriends", 1)
nine_eleven.CreateCvar("nine_eleven_aimbot_nospread", 1)
nine_eleven.CreateCvar("nine_eleven_norecoil", 1)

function nine_eleven.GetPos(ucmd)
	local pos = nine_eleven.EntM.GetAttachment(nine_eleven.Target, nine_eleven.EntM.LookupAttachment(nine_eleven.Target, "eyes"))
	if !pos then
		pos = nine_eleven.EntM.LocalToWorld(nine_eleven.Target, nine_eleven.EntM.OBBCenter(nine_eleven.Target))
	else
		pos = pos.Pos
	end
	pos = pos - nine_eleven.EntM.EyePos(nine_eleven.Me)
	pos = pos + (nine_eleven.EntM.GetVelocity(nine_eleven.Me) * -0.0067)
	if nine_eleven.G.GetConVarNumber("nine_eleven_aimbot_nospread") == 1 then
		return nine_eleven.PredictSpread(ucmd, nine_eleven.VecM.Angle(pos))
	end
	return nine_eleven.VecM.Angle(pos)
end

function nine_eleven.ValidCheck(v)
	if !v then return false end
	if !nine_eleven.EntM.IsValid(v) then return false end
	if v == nine_eleven.Me then return false end
	if nine_eleven.EntM.Health(v) < 1 then return false end
	if nine_eleven.PlyM.Team(v) == 1002 then return false end
	if nine_eleven.EntM.IsDormant(v) then return false end
	if nine_eleven.G.GetConVarNumber("nine_eleven_targetfriends") == 0 then 
		if nine_eleven.PlyM.GetFriendStatus(v) == "friend" then 
			return false 
		end 
	end
	local tr = {}
	local attpos = nine_eleven.EntM.GetAttachment(v, nine_eleven.EntM.LookupAttachment(v, "eyes"))
	if !attpos then
		attpos = nine_eleven.EntM.LocalToWorld(v, nine_eleven.EntM.OBBCenter(v))
	else
		attpos = attpos.Pos
	end	
	tr.endpos = attpos
	tr.start = nine_eleven.EntM.EyePos(nine_eleven.Me)
	tr.mask = 1174421507
	tr.filter = {nine_eleven.Me, v}
	local trace = nine_eleven.G.util.TraceLine(tr)
	return trace.Fraction == 1
end

function nine_eleven.GetTarget()
	local allplys = nine_eleven.G.player.GetAll()
	for i = 1, #allplys do
		local v = allplys[i]
		if !nine_eleven.ValidCheck(v) then
			continue
		end
		nine_eleven.Target = v
		return
	end
end

function nine_eleven.GixMovement(ucmd)
	local side = nine_eleven.G.Vector(nine_eleven.CmdM.GetForwardMove(ucmd), nine_eleven.CmdM.GetSideMove(ucmd), 0)
	side = nine_eleven.AngM.Forward((nine_eleven.VecM.Angle(nine_eleven.VecM.GetNormal(side)) + (nine_eleven.CmdM.GetViewAngles(ucmd) - nine_eleven.G.Angle(0, oa.y, 0)))) * nine_eleven.VecM.Length(side)
	nine_eleven.CmdM.SetForwardMove(ucmd, side.x)
	nine_eleven.CmdM.SetSideMove(ucmd, side.y)
end

nine_eleven.CreateCvar("nine_eleven_aimbot_autoshoot", 1)
nine_eleven.CreateCvar("nine_eleven_antiaim", 0)
nine_eleven.CreateCvar("nine_eleven_fakeshake", 0)

local valid

local boosting = false

function nine_eleven.Aimbot(ucmd)
	if nine_eleven.G.GetConVarNumber("nine_eleven_norecoil") == 1 and !boosting then
		oa = oa + nine_eleven.G.Angle(nine_eleven.CmdM.GetMouseY(ucmd) * 0.023, -nine_eleven.CmdM.GetMouseX(ucmd) * 0.023, 0)
	else
		oa = nine_eleven.CmdM.GetViewAngles(ucmd)
	end
	if nine_eleven.Enabled and nine_eleven.ValidCheck(nine_eleven.Target) then
		valid = true
		local aimpos = nine_eleven.GetPos(ucmd)
		nine_eleven.CmdM.SetViewAngles(ucmd, aimpos)
		nine_eleven.GixMovement(ucmd)
		if nine_eleven.G.GetConVarNumber("nine_eleven_aimbot_autoshoot") == 1 then
			nine_eleven.CmdM.SetButtons(ucmd, nine_eleven.G.bit.bor(nine_eleven.CmdM.GetButtons(ucmd), 1))
		end
	else
		valid = false
		nine_eleven.GetTarget()
		oa.p = nine_eleven.G.math.Clamp(oa.p, -89, 89)
		oa.y = nine_eleven.G.math.NormalizeAngle(oa.y)
		if (nine_eleven.G.GetConVarNumber("nine_eleven_antiaim") == 1 and !nine_eleven.G.input.IsMouseDown(107)) or boosting or (nine_eleven.G.GetConVarNumber("nine_eleven_spinbot") == 1 and !nine_eleven.G.input.IsMouseDown(107)) then return end
		if nine_eleven.G.GetConVarNumber("nine_eleven_norecoil") != 1 then return end
		nine_eleven.CmdM.SetViewAngles(ucmd, oa)
		if nine_eleven.G.GetConVarNumber("nine_eleven_nospread") == 1 then
			local ang = nine_eleven.PredictSpread(ucmd, oa)
			nine_eleven.CmdM.SetViewAngles(ucmd, ang)
		end
		if nine_eleven.G.GetConVarNumber("nine_eleven_fakeshake") == 1 and !nine_eleven.G.input.IsMouseDown(107) then
			nine_eleven.CmdM.SetViewAngles(ucmd, oa + nine_eleven.G.Angle(math.random(-5, 5), math.random(-5, 5), 0))
		end
	end
end

local change

nine_eleven.G.CreateClientConVar("nine_eleven_antiaim_method", 1)

function nine_eleven.AntiAim(ucmd)
	if nine_eleven.G.GetConVarNumber("nine_eleven_antiaim") != 1 or valid or nine_eleven.G.input.IsMouseDown(107) then
		return 
	end
	local val = nine_eleven.G.GetConVarNumber("nine_eleven_antiaim_method")
	if val == 1 then
	nine_eleven.CmdM.SetViewAngles(ucmd, nine_eleven.G.Angle(181, oa.y, 0))
	nine_eleven.CmdM.SetForwardMove(ucmd, nine_eleven.CmdM.GetForwardMove(ucmd) * -1)
	elseif val == 2 then
	nine_eleven.CmdM.SetViewAngles(ucmd, nine_eleven.G.Angle(89, oa.y + nine_eleven.G.math.random(-180,180), 0))
	nine_eleven.GixMovement(ucmd)
	elseif val == 3 then
	nine_eleven.CmdM.SetViewAngles(ucmd, nine_eleven.G.Angle(nine_eleven.G.math.random(-89,89), oa.y + nine_eleven.G.math.random(-180,180), 0))
	nine_eleven.GixMovement(ucmd)
	elseif val == 4 then
	nine_eleven.CmdM.SetViewAngles(ucmd, nine_eleven.G.Angle(-89, oa.y + nine_eleven.G.math.random(-180,180), 0))
	nine_eleven.GixMovement(ucmd)
	elseif val == 5 then
	nine_eleven.CmdM.SetViewAngles(ucmd, nine_eleven.G.Angle(-181, oa.y, 0))
	nine_eleven.CmdM.SetForwardMove(ucmd, nine_eleven.CmdM.GetForwardMove(ucmd) * -1)
	elseif val == 6 then
	local ang = change and 89 or -89
	nine_eleven.CmdM.SetViewAngles(ucmd, nine_eleven.G.Angle(ang, oa.y, 0))
	change = not change
	elseif val == 7 then
	local ang = change and 89 or -89
	nine_eleven.CmdM.SetViewAngles(ucmd, nine_eleven.G.Angle(ang, oa.y + nine_eleven.G.math.random(-180,180), 0))
	nine_eleven.GixMovement(ucmd)
	change = not change
	end
end
		
nine_eleven.AddHook("CreateMove", nine_eleven.G.util.CRC("antiaim"), nine_eleven.AntiAim)
nine_eleven.AddHook("CreateMove", nine_eleven.G.util.CRC("aimb0t"), nine_eleven.Aimbot)

nine_eleven.G.concommand.Add("+nine_eleven_aimbot", function()
	nine_eleven.Enabled = true
end)

nine_eleven.G.concommand.Add("-nine_eleven_aimbot", function()
	nine_eleven.Enabled = false
end)

function nine_eleven.CalcView(ply, origin, angles, fov)
	if nine_eleven.G.GetConVarNumber("nine_eleven_norecoil") != 1 or boosting then return end
	local view = {}
	view.fov = fov
	view.origin = origin
	view.angles = oa
	return view
end

if !nine_eleven.G.engine.IsPlayingDemo() then
	nine_eleven.AddHook("CalcView", nine_eleven.G.util.CRC("calcview"), nine_eleven.CalcView)
end

nine_eleven.CreateCvar("nine_eleven_bhop_autostrafe_method", 1)

function nine_eleven.BHop(ucmd)
	if nine_eleven.G.GetConVarNumber("nine_eleven_bhop") != 1 then return end
	nine_eleven.nyx.Bunnyhop(ucmd, nine_eleven.EntM.IsOnGround(nine_eleven.Me))
	if nine_eleven.G.GetConVarNumber("nine_eleven_bhop_autostrafe") == 1 and !nine_eleven.EntM.IsOnGround(nine_eleven.Me) and nine_eleven.G.input.IsKeyDown(KEY_SPACE) then
		if nine_eleven.G.GetConVarNumber("nine_eleven_bhop_autostrafe_method") == 1 then
			if strafe then
				nine_eleven.CmdM.SetSideMove(ucmd, -1000)
				nine_eleven.CmdM.SetMouseX(ucmd, nine_eleven.CmdM.GetMouseX(ucmd) + 150)
			else
				nine_eleven.CmdM.SetSideMove(ucmd, 1000)
				nine_eleven.CmdM.SetMouseX(ucmd, nine_eleven.CmdM.GetMouseX(ucmd) - 150)
			end
		else
			if nine_eleven.CmdM.GetMouseX(ucmd) < 0 then
				nine_eleven.CmdM.SetSideMove(ucmd, -1000)
			elseif nine_eleven.CmdM.GetMouseX(ucmd) > 0 then
				nine_eleven.CmdM.SetSideMove(ucmd, 1000)
			end
		end
	end
	strafe = not strafe
end

nine_eleven.AddHook("CreateMove", nine_eleven.G.util.CRC("bhop"), nine_eleven.BHop)


nine_eleven.G.surface.CreateFont("HWEOAJSHO", {
	font    = "Terminal",
	size    = 11,
	weight  = 500,
	shadow  = true,
})

nine_eleven.CreateCvar("nine_eleven_esp", 1)
nine_eleven.CreateCvar("nine_eleven_esp_box", 1)
nine_eleven.CreateCvar("nine_eleven_esp_type", 1)
nine_eleven.CreateCvar("nine_eleven_headesp", 1)

function nine_eleven.ESP(v, ply, col)
		if ply and nine_eleven.G.GetConVarNumber("nine_eleven_headesp") == 1 then
			local bone = nine_eleven.EntM.LookupBone(v, "ValveBiped.Bip01_Head1")
			if bone then
				local pos = nine_eleven.VecM.ToScreen(nine_eleven.EntM.GetBonePosition(v, bone))
				nine_eleven.G.surface.SetDrawColor(255,255,255,255)
				nine_eleven.G.surface.DrawOutlinedRect(pos.x, pos.y, 2, 2)
				nine_eleven.G.surface.DrawOutlinedRect(pos.x, pos.y, 1.5, 1.5)
				nine_eleven.G.surface.DrawOutlinedRect(pos.x, pos.y, 1, 1)
			end
		end
		local min,max = nine_eleven.EntM.WorldSpaceAABB(v)
		local diff = max-min
		local pos2 = nine_eleven.G.Vector(0,0,0)
		local pos1 = nine_eleven.G.Vector(0,0,0)
		local pos3 = nine_eleven.G.Vector(0,0,0)
		local pos4 = nine_eleven.G.Vector(0,0,0)
		local pos5 = nine_eleven.G.Vector(0,0,diff.z)
		local pos6 = nine_eleven.G.Vector(0,0,diff.z)
		local pos7 = nine_eleven.G.Vector(0,0,diff.z)
		local pos8 = nine_eleven.G.Vector(0,0,diff.z)
		pos1 = nine_eleven.VecM.ToScreen(pos1 + nine_eleven.EntM.WorldSpaceAABB(v) + nine_eleven.G.Vector(diff.x,diff.y,0))
		pos2 = nine_eleven.VecM.ToScreen(pos2 + nine_eleven.EntM.WorldSpaceAABB(v) + nine_eleven.G.Vector(diff.x,-diff.y/14,0))
		pos3 = nine_eleven.VecM.ToScreen(pos3 + nine_eleven.EntM.WorldSpaceAABB(v) + nine_eleven.G.Vector(-diff.x/14,-diff.y/14,0))
		pos4 = nine_eleven.VecM.ToScreen(pos4 + nine_eleven.EntM.WorldSpaceAABB(v) + nine_eleven.G.Vector(-diff.x/14,diff.y,0))
		pos5 = nine_eleven.VecM.ToScreen(pos5 + nine_eleven.EntM.WorldSpaceAABB(v) + nine_eleven.G.Vector(diff.x,diff.y,0))
		pos6 = nine_eleven.VecM.ToScreen(pos6 + nine_eleven.EntM.WorldSpaceAABB(v) + nine_eleven.G.Vector(diff.x,-diff.y/14,0))
		pos7 = nine_eleven.VecM.ToScreen(pos7 + nine_eleven.EntM.WorldSpaceAABB(v) + nine_eleven.G.Vector(-diff.x/14,-diff.y/14,0))
		pos8 = nine_eleven.VecM.ToScreen(pos8 + nine_eleven.EntM.WorldSpaceAABB(v) + nine_eleven.G.Vector(-diff.x/14,diff.y,0))
		if (ply and nine_eleven.G.GetConVarNumber("nine_eleven_esp_box") == 1 and (nine_eleven.G.GetConVarNumber("nine_eleven_esp_type") == 1))or !ply then
			nine_eleven.G.surface.SetDrawColor(col)
			nine_eleven.G.surface.DrawLine(pos1.x, pos1.y, pos2.x, pos2.y)
			nine_eleven.G.surface.DrawLine(pos2.x, pos2.y, pos3.x, pos3.y)
			nine_eleven.G.surface.DrawLine(pos3.x, pos3.y, pos4.x, pos4.y)
			nine_eleven.G.surface.DrawLine(pos1.x, pos1.y, pos4.x, pos4.y)
			nine_eleven.G.surface.DrawLine(pos1.x, pos1.y, pos5.x, pos5.y)
			nine_eleven.G.surface.DrawLine(pos2.x, pos2.y, pos6.x, pos6.y)
			nine_eleven.G.surface.DrawLine(pos3.x, pos3.y, pos7.x, pos7.y)
			nine_eleven.G.surface.DrawLine(pos4.x, pos4.y, pos8.x, pos8.y)
			nine_eleven.G.surface.DrawLine(pos5.x, pos5.y, pos6.x, pos6.y)
			nine_eleven.G.surface.DrawLine(pos6.x, pos6.y, pos7.x, pos7.y)
			nine_eleven.G.surface.DrawLine(pos7.x, pos7.y, pos8.x, pos8.y)
			nine_eleven.G.surface.DrawLine(pos5.x, pos5.y, pos8.x, pos8.y)
		end
		if nine_eleven.G.GetConVarNumber("nine_eleven_esp_type") == 0 and nine_eleven.G.GetConVarNumber("nine_eleven_esp_box") == 1 then
			local min, max = nine_eleven.EntM.WorldSpaceAABB(v)
			local min, max = nine_eleven.VecM.ToScreen(min), nine_eleven.VecM.ToScreen(max)
			local w = min.y - max.y
			nine_eleven.G.surface.SetDrawColor(col)
			nine_eleven.G.surface.DrawOutlinedRect(max.x - (w/2), max.y, w /2, w)
			local pos = nine_eleven.EntM.GetPos(v) 
			local pos2 = pos + nine_eleven.G.Vector(0,0,65)
			local pos = nine_eleven.VecM.ToScreen(pos)
			local pos2 = nine_eleven.VecM.ToScreen(pos2)
			local Health = nine_eleven.EntM.Health(v)
			local Name = nine_eleven.PlyM.Name(v)
			local we = nine_eleven.PlyM.GetActiveWeapon(v)
			local weapon = nine_eleven.EntM.IsValid(we) and nine_eleven.EntM.GetClass(we) or ""
			local group = nine_eleven.PlyM.GetUserGroup(v) or ""
			local textcol = nine_eleven.G.Color(255,255,255)
			nine_eleven.G.draw.SimpleText("HP:"..Health, "HWEOAJSHO", max.x - (w*.25), pos2.y-13, textcol,1,0)
			nine_eleven.G.draw.SimpleText(Name, "HWEOAJSHO", max.x - (w*.25), pos2.y-26, textcol,1,0)
			nine_eleven.G.draw.SimpleText("Weapon: "..weapon, "HWEOAJSHO", max.x - (w*.25), pos.y - 2,textcol,1,0)
			nine_eleven.G.draw.SimpleText("Rank: "..group, "HWEOAJSHO", max.x - (w*.25), pos.y + 11, textcol,1,0)
			return
		end
		if ply then
			local Position = nine_eleven.EntM.GetPos(v) + nine_eleven.G.Vector(0,0,50)
			Position = nine_eleven.VecM.ToScreen(Position)
			local Health = nine_eleven.EntM.Health(v)
			local Name = nine_eleven.G.string.upper(nine_eleven.PlyM.Name(v))
			local w = nine_eleven.PlyM.GetActiveWeapon(v)
			local weapon = nine_eleven.EntM.IsValid(w) and nine_eleven.EntM.GetClass(w) or ""
			local group = nine_eleven.PlyM.GetUserGroup(v) or ""
			nine_eleven.G.draw.DrawText( Name, "HWEOAJSHO", pos1.x - 10, pos1.y - 20, nine_eleven.G.Color(255,255,255), 0 )
			nine_eleven.G.draw.DrawText( "HEALTH: " .. Health, "HWEOAJSHO", pos1.x - 10, pos1.y - 10, nine_eleven.G.Color(255,255,255), 0 )
			nine_eleven.G.draw.DrawText( "WEAPON: " .. weapon, "HWEOAJSHO", pos1.x - 10, pos1.y + 10, nine_eleven.G.Color(255,255,255), 0 )
			nine_eleven.G.draw.DrawText( "GROUP: "..group,  "HWEOAJSHO", pos1.x - 10, pos1.y, nine_eleven.G.Color(255,255,255), 0 )
		else
			local Position = nine_eleven.EntM.GetPos(v) + nine_eleven.G.Vector(0,0,20)
			Position = nine_eleven.VecM.ToScreen(Position)
			nine_eleven.G.draw.DrawText( nine_eleven.EntM.GetClass(v), "HWEOAJSHO", Position.x, Position.y, nine_eleven.G.Color(255,93,0), 1 )
		end
	end
	
nine_eleven.Ents = {
	"money_printer",
	"spawned_shipment",
	"spawned_money",
	"spawned_weapon",
}

nine_eleven.G.concommand.Add("nine_eleven_entesp_remove", function()
	local eyetrace = nine_eleven.PlyM.GetEyeTrace(nine_eleven.Me).Entity
	local class = nine_eleven.EntM.GetClass(eyetrace)
	if nine_eleven.EntM.IsValid(eyetrace) then
		for k,v in nine_eleven.G.pairs(nine_eleven.Ents) do
			if v == class then
				nine_eleven.G.table.remove(nine_eleven.Ents,k)
				nine_eleven.Notify("Removed "..class.." from the entity list.")
			end
		end
	end
end)

nine_eleven.G.concommand.Add("nine_eleven_entesp_add", function()
	local eyetrace = nine_eleven.PlyM.GetEyeTrace(nine_eleven.Me).Entity
	local class = nine_eleven.EntM.GetClass(eyetrace)
	if nine_eleven.EntM.IsValid(eyetrace) then
		nine_eleven.G.table.insert(nine_eleven.Ents,class)
		nine_eleven.Notify("Added "..class.." to the entity list.")
	end
end)

nine_eleven.CreateCvar("nine_eleven_entesp", 0)

function nine_eleven.ESPLoop()
	if nine_eleven.G.GetConVarNumber("nine_eleven_entesp") == 1 then
		local allents = nine_eleven.G.ents.GetAll()
		for i = 1, #allents do
			local v = allents[i]
			if !nine_eleven.EntM.IsValid(v) then
				continue 
			end
			for k, _ in nine_eleven.G.pairs(nine_eleven.Ents) do
				if string.match(nine_eleven.EntM.GetClass(v), _) then
					nine_eleven.ESP(v, false, nine_eleven.EntM.GetColor(v))
				end
			end
		end
	end
	if nine_eleven.G.GetConVarNumber("nine_eleven_esp") == 1 then
		local allplys = nine_eleven.G.player.GetAll()
		for i = 1, #allplys do
			local v = allplys[i]
			if !nine_eleven.EntM.IsValid(v) or nine_eleven.EntM.Health(v) < 1 or v == nine_eleven.Me then
				continue
			end
			nine_eleven.ESP(v, true, nine_eleven.G.team.GetColor(nine_eleven.PlyM.Team(v)))
		end
	end
end

nine_eleven.AddHook("HUDPaint", nine_eleven.G.util.CRC("esp"), nine_eleven.ESPLoop)

nine_eleven.Words = {
	"dick",
	"cunt",
	"vagina",
	"rdm",
	"nlr",
	"admen",
	"duck",
	"blowjob",
	"anal",
	"rape",
	"9/11",
	"jihad",
	"gay",
	"autism",
	"autistic",
	"anus",
	"ass",
	"twat",
	"dog",
	"cat",
	"bitch",
	"penis",
	"boner",
	"clit",
	"cock",
	"nigga",
	"cum",
	"damn",
	"fuck",
	"dickjuice",
	"douchebag",
	"dumbass",
	"minecraft",
	"cod",
	"gmod",
	"garry",
	"jew",
	"hitler",
	"orgasm",
	"poop",
	"shit",
	"fag",
	"faggot",
	"fucking",
	"handjob",
	"hell",
	"donkey",
	"monkey",
	"dude",
	"nerd",
	"ddos",
	"loser",
	"admin",
	"rp",
	"nice",
	"aimbot",
	"wallhack",
	"esp",
	"hera",
	"donate",
	"weed",
	"aids",
	"loic",
	"udp",
	"swag",
	"skid",
	"hackforums",
	"vac",
	"cheat",
	"hack",
	"mpgh",
	"unkowncheats",
	"lennys",
	"falcos",
	"bot",
	"ahack",
	"bluebot",
	"darkrp",
	"spooky",
	"lua",
	"chams",
	"mlg",
	"meme",
	"wobs",
	"sick",
	"c&p",
	"doge",
	"mum",
	"car",
	"errected",
	"piss",
	"rapist",
	"pedo",
	"hacker",
	"speedhack",
	"hitbox",
	"police",
	"cops",
	"dubstep",
	"hentai",
	"lesbian",
	"nazi",
	"wireshark",
	"cool",
	"tcp",
	"teleport",
	"weird",
	"ugly",
	"cumshot",
	"whore",
	"money",
	"game",
	"kid",
	"rda",
	"abuse",
	"noclip",
	"propclimb",
	"propboost",
	"prop",
	"ip",
	"god",
	"jesus",
	"allah",
	"nospread",
	"norecoil",
	"propkill",
	"propabuse",
	"rekt",
	"sethhack",
	"assfuck",
	"troll",
	"gun",
	"power",
	"drugs",
	"shrek",
	"420",
	"protection",
	"skrillex",
	"fedora",
	"noob",
	"tutorial",
	"180",
	"360",
	"720",
	"rage",
	"quickscope",
	"hardscope",
	"noscope",
	"pingu",
	"baby",
	"fish",
	"plox",
	"nasty",
	"rude",
	"pve",
	"server",
	"pvp",
	"godmode",
	"trickshot",
	"bong",
	"rip",
	"kush",
	"dank",
	"hitmarker",
	"faze",
	"optic",
	"illuminati",
	"internet",
	"9gag",
	"cheeky",
	"computer",
	"dildo",
	"chair",
	"skrub",
	"skrublord",
	"terraria",
	"problem",
	"darude",
	"meth",
	"lads",
	"1v1",
	"pewdiepie",
	"dictator",	
	"milk",
	"swamp",
}

nine_eleven.CreateCvar("nine_eleven_randomchatspam", 0)
nine_eleven.CreateCvar("nine_eleven_randomchatspam_amount", 2)

function nine_eleven.SpamRandomWords()
	if nine_eleven.G.GetConVarNumber("nine_eleven_randomchatspam") != 1 then return end
	local amount = nine_eleven.G.GetConVarNumber("nine_eleven_randomchatspam_amount")
	local word = ""
	for i = 1, amount do
		local part = nine_eleven.G.table.Random(nine_eleven.Words)
		word = word.." "..part
	end
	nine_eleven.PlyM.ConCommand(nine_eleven.Me, "say "..word)
end

nine_eleven.AddHook("Think", nine_eleven.G.util.CRC("autism"), nine_eleven.SpamRandomWords)

nine_eleven.CreateCvar("nine_eleven_chams", 0)

nine_eleven.ChamsMat = nine_eleven.G.CreateMaterial("GA0249aSFJ3","VertexLitGeneric",{
	["$basetexture"] = "models/debug/debugwhite",
	["$model"] = 1,
	["$translucent"] = 1,
	["$alpha"] = 1,
	["$nocull"] = 1,
	["$ignorez"] = 1
}
)

local chams = true

function nine_eleven.Chams()
	if nine_eleven.G.GetConVarNumber("nine_eleven_chams") != 1 or !chams then return end
	local allplys = nine_eleven.G.player.GetAll()
	for i = 1, #allplys do
		local v = allplys[i]
		if !nine_eleven.EntM.IsValid(v) or nine_eleven.EntM.Health(v) < 1 or v == nine_eleven.Me then
			continue
		end
		local col = nine_eleven.G.team.GetColor(nine_eleven.PlyM.Team(v))
		nine_eleven.G.cam.Start3D()
			nine_eleven.G.render.SuppressEngineLighting( true )
			nine_eleven.G.render.SetColorModulation( col.r / 255, col.g / 255, col.b / 255 )
			nine_eleven.G.render.MaterialOverride( nine_eleven.ChamsMat )
			nine_eleven.EntM.DrawModel(v)
			nine_eleven.G.render.SuppressEngineLighting( false )
			nine_eleven.G.render.SetColorModulation(1,1,1)
			nine_eleven.G.render.MaterialOverride( )
			nine_eleven.EntM.DrawModel(v)
		nine_eleven.G.cam.End3D()
	end
end

nine_eleven.AddHook("RenderScreenspaceEffects", nine_eleven.G.util.CRC("chams"), nine_eleven.Chams)

nine_eleven.LaserMat = nine_eleven.G.Material("cable/physbeam")

nine_eleven.CreateCvar("nine_eleven_eyelaser", 0)

function nine_eleven.EyeLaser()
	if nine_eleven.G.GetConVarNumber("nine_eleven_eyelaser") != 1 then return end
	local allplys = nine_eleven.G.player.GetAll()
	for i = 1, #allplys do
		local v = allplys[i]
		if !nine_eleven.EntM.IsValid(v) or nine_eleven.EntM.Health(v) < 1 or v == nine_eleven.Me then
			continue
		end
		nine_eleven.G.cam.Start3D()
			nine_eleven.G.render.SetMaterial(nine_eleven.LaserMat)
			local epos = nine_eleven.EntM.EyePos(v)
			local hitpos = nine_eleven.PlyM.GetEyeTrace(v).HitPos
			nine_eleven.G.render.DrawBeam(epos, hitpos, 10, 1, 1)
		nine_eleven.G.cam.End3D()
	end
end

local oGH = nine_eleven.R.Player.GetHands
local oSH = nine_eleven.R.Player.SetHands
local oGHM = nine_eleven.R.Player.GetHandsModel

nine_eleven.CreateCvar("nine_eleven_nohands", 0)

nine_eleven.R.Player.GetHands = function(...)
	if nine_eleven.G.GetConVarNumber("nine_eleven_nohands") != 1 then
		return oGH(...)
	end
	return nil
end

nine_eleven.R.Player.SetHands = function(...)
	if nine_eleven.G.GetConVarNumber("nine_eleven_nohands") != 1 then
		return oSH(...)
	end
	return nil
end

nine_eleven.R.Player.GetHandsModel = function(...)
	if nine_eleven.G.GetConVarNumber("nine_eleven_nohands") != 1 then
		return oGHM(...)
	end
	return nil
end

nine_eleven.AddHook("HUDPaint", nine_eleven.G.util.CRC("lazor"), nine_eleven.EyeLaser)

nine_eleven.CreateCvar("nine_eleven_tracers", 0)

function nine_eleven.Tracers()
	if nine_eleven.G.GetConVarNumber("nine_eleven_tracers") != 1 then return end
	local allplys = nine_eleven.G.player.GetAll()
	for i = 1, #allplys do
		local v = allplys[i]
		if !nine_eleven.EntM.IsValid(v) or nine_eleven.EntM.Health(v) < 1 or v == nine_eleven.Me then 
			continue 
		end
		local pos = nine_eleven.EntM.LocalToWorld(v, nine_eleven.EntM.OBBCenter(v))
		pos = nine_eleven.VecM.ToScreen(pos)
		if nine_eleven.PlyM.GetFriendStatus(v) == "friend" then
			nine_eleven.G.surface.SetDrawColor(0,255,0)
		elseif nine_eleven.PlyM.IsAdmin(v) then
			nine_eleven.G.surface.SetDrawColor(255,0,0)
		else
			nine_eleven.G.surface.SetDrawColor(0,0,255)
		end
		nine_eleven.G.surface.DrawLine(nine_eleven.G.ScrW() * .5, nine_eleven.G.ScrH() * .5, pos.x, pos.y)
	end
end

nine_eleven.AddHook("HUDPaint", nine_eleven.G.util.CRC("trace"), nine_eleven.Tracers)

nine_eleven.AddHook("Think", nine_eleven.G.util.CRC("voice"), function()
	nine_eleven.Me.voice_battery = 100
end)

local seed = 0.2
local speeding = false

nine_eleven.AddHook("Think", nine_eleven.G.util.CRC("SPEED"), function()
	if speeding then
		local amount = nine_eleven.G.tostring(seed / nine_eleven.G.RealFrameTime())
		nine_eleven.G.RunConsoleCommand("nine_eleven_host_framerate", amount)
	else
		nine_eleven.G.RunConsoleCommand("nine_eleven_host_framerate", "0")
	end
end)

nine_eleven.G.concommand.Add("+nine_eleven_speedhack", function()
	speeding = true
end)

nine_eleven.G.concommand.Add("-nine_eleven_speedhack", function()
	speeding = false
end)

nine_eleven.AddHook("HUDPaint", nine_eleven.G.util.CRC("drawshit"), function()
	nine_eleven.G.draw.SimpleText("nine_eleven-bot", "Default", nine_eleven.G.ScrW() * .08, 0, nine_eleven.G.Color(255,93,0), 2)
end)

nine_eleven.G.concommand.Add("nine_eleven_openscript", function(ply, cmd, args)
	if !args[1] then
		nine_eleven.Notify("Invalid Arguments.")
		return 
	end
	local file = args[1]
	local code = nine_eleven.G.file.Read("lua/"..file, "GAME")
	if !code then
		nine_eleven.Notify("Couldn't read Script, or File not found.")
		return
	end
	nine_eleven.G.print("Running Code:\n"..code)
	nine_eleven.G.pcall(nine_eleven.G.CompileString(code,"nine_eleven-bot"))
end)

nine_eleven.G.concommand.Add("nine_eleven_runlua", function(ply, cmd, args)
	if !args[1] then return end
	local code = nine_eleven.G.table.concat(args, " ")
	nine_eleven.G.print("Running Code:\n"..code)
	nine_eleven.G.pcall(nine_eleven.G.CompileString(code,"nine_eleven-bot"))
end)

nine_eleven.CreateCvar("nine_eleven_rapidfire", 0)

function nine_eleven.Rapidfire(ucmd)
	if nine_eleven.G.GetConVarNumber("nine_eleven_rapidfire") != 1 then return end
	if nine_eleven.PlyM.KeyDown(nine_eleven.Me, 1) then
		nine_eleven.CmdM.SetButtons(ucmd, nine_eleven.G.bit.band(nine_eleven.CmdM.GetButtons(ucmd), -2))
	end
end

nine_eleven.AddHook("CreateMove", nine_eleven.G.util.CRC("rapidfire"), nine_eleven.Rapidfire)


nine_eleven.G.concommand.Add("+nine_eleven_propsurf", function()
	boosting = true
	local a = nine_eleven.EntM.EyeAngles(nine_eleven.Me)
	nine_eleven.PlyM.SetEyeAngles(nine_eleven.Me, a - nine_eleven.G.Angle(0, 180, 0))
	nine_eleven.G.timer.Simple(.05, function()
		nine_eleven.PlyM.ConCommand(nine_eleven.Me, "gm_spawn models/props_building_details/Storefront_Template001a_Bars.mdl")
	end)
	nine_eleven.G.timer.Simple(.1, function()
		nine_eleven.PlyM.ConCommand(nine_eleven.Me, "+attack")
	end)
	nine_eleven.G.timer.Simple(.2, function()
		nine_eleven.PlyM.SetEyeAngles(nine_eleven.Me, a - nine_eleven.G.Angle(0, 360, 0))
	end)
end)

nine_eleven.G.concommand.Add("-nine_eleven_propsurf", function()
	nine_eleven.PlyM.ConCommand(nine_eleven.Me, "undo")
	nine_eleven.PlyM.ConCommand(nine_eleven.Me, "-attack")
	boosting = false
end)

nine_eleven.G.concommand.Add("+nine_eleven_propfly", function()
	boosting = true
	local a = nine_eleven.EntM.EyeAngles(nine_eleven.Me)
	nine_eleven.PlyM.SetEyeAngles(nine_eleven.Me, nine_eleven.G.Angle(35, a.y - 180, 0))
	nine_eleven.G.timer.Simple(.05, function()
		nine_eleven.PlyM.ConCommand(nine_eleven.Me, "gm_spawn models/props_c17/metalPot001a.mdl")
	end)
	nine_eleven.G.timer.Simple(.1, function()
		nine_eleven.PlyM.ConCommand(nine_eleven.Me, "+attack")
		nine_eleven.PlyM.ConCommand(nine_eleven.Me, "+jump")
	end)
	nine_eleven.G.timer.Simple(.2, function()
		nine_eleven.PlyM.ConCommand(nine_eleven.Me, "-jump")
		nine_eleven.PlyM.SetEyeAngles(nine_eleven.Me, nine_eleven.G.Angle(-30, a.y - 360, 0))
	end)
end)

nine_eleven.G.concommand.Add("-nine_eleven_propfly", function()
	nine_eleven.PlyM.ConCommand(nine_eleven.Me, "undo")
	nine_eleven.PlyM.ConCommand(nine_eleven.Me, "-attack")
	boosting = false
end)

nine_eleven.CreateCvar("nine_eleven_xray", 0)
nine_eleven.CreateCvar("nine_eleven_xray_material", 1)

nine_eleven.xmat1 = nine_eleven.G.Material("models/debug/debugwhite")

function nine_eleven.Xray()
	if nine_eleven.G.GetConVarNumber("nine_eleven_xray") != 1 then 
		chams = true
		return 
	end
	chams = false
	local allprops = nine_eleven.G.ents.FindByClass("prop_physics")
	for i = 1, #allprops do
		local v = allprops[i]
		if nine_eleven.EntM.IsValid(v) then
			nine_eleven.G.cam.Start3D()
				nine_eleven.G.render.SuppressEngineLighting( true )
				nine_eleven.G.render.MaterialOverride( nine_eleven.xmat1 )
				nine_eleven.G.render.SetColorModulation( 0, 1, 0)
				nine_eleven.G.render.SetBlend( 120 / 255 )
				nine_eleven.EntM.DrawModel(v)
			nine_eleven.G.cam.End3D()
		end
	end
	local allplys = nine_eleven.G.player.GetAll()
	for i = 1, #allplys do
		local v = allplys[i]
		if !nine_eleven.EntM.IsValid(v) or (nine_eleven.EntM.Health(v) < 1) or v == nine_eleven.Me then
			continue
		end
		nine_eleven.G.cam.Start3D()
			nine_eleven.G.render.SuppressEngineLighting( true )
			nine_eleven.G.render.MaterialOverride( nine_eleven.xmat1 )
			nine_eleven.G.render.SetColorModulation(1, 0, 0)
			nine_eleven.G.render.SetBlend( 140 / 255 )
			nine_eleven.EntM.DrawModel(v)
		nine_eleven.G.cam.End3D()
	end
end

nine_eleven.AddHook("HUDPaint", nine_eleven.G.util.CRC("XRAY"), nine_eleven.Xray)

nine_eleven.LazerMat = nine_eleven.G.Material("cable/redlaser")

nine_eleven.CreateCvar("nine_eleven_weaponlaser", 0)

function nine_eleven.WeaponLaser()
	if nine_eleven.G.GetConVarNumber("nine_eleven_weaponlaser") != 1 then return end
	local w = nine_eleven.PlyM.GetActiveWeapon(nine_eleven.Me)
	local ent = nine_eleven.PlyM.GetViewModel(nine_eleven.Me)
	if w and ent and nine_eleven.EntM.IsValid(w) and nine_eleven.EntM.IsValid(ent) then
		local muzzle = nine_eleven.EntM.GetAttachment(ent, nine_eleven.EntM.LookupAttachment(ent, "muzzle"))
		if !muzzle then return end
		nine_eleven.G.cam.Start3D()
			nine_eleven.G.render.SetMaterial(nine_eleven.LazerMat)
			nine_eleven.G.render.DrawBeam(muzzle.Pos, nine_eleven.PlyM.GetEyeTrace(nine_eleven.Me).HitPos, 5, 0, 10, nine_eleven.G.Color(0,255,0,255))
		nine_eleven.G.cam.End3D()
	end
end

nine_eleven.AddHook("HUDPaint", nine_eleven.G.util.CRC("WeaponLaser"), nine_eleven.WeaponLaser)

nine_eleven.CreateCvar("nine_eleven_triggerbot", 0)

local shoot

function nine_eleven.Triggerbot(ucmd)
	if nine_eleven.G.GetConVarNumber("nine_eleven_triggerbot") != 1 then return end
	local ent = nine_eleven.PlyM.GetEyeTrace(nine_eleven.Me).Entity
	if nine_eleven.EntM.IsValid(ent) and nine_eleven.EntM.GetClass(ent) == "player" and nine_eleven.EntM.Health(ent) > 1 then
		nine_eleven.CmdM.SetButtons(ucmd, nine_eleven.G.bit.bor(nine_eleven.CmdM.GetButtons(ucmd), 1))
	end
end

nine_eleven.AddHook("CreateMove", nine_eleven.G.util.CRC("triggerbot"), nine_eleven.Triggerbot)

function nine_eleven.rand()
	local word = ""
	for i = 1, 3 do
		word = word.." "..nine_eleven.G.table.Random(nine_eleven.Words)
	end
	return word
end


local oRC = nine_eleven.G.render.Capture

nine_eleven.CreateCvar("nine_eleven_antiscreengrab", 1)

render.Capture = function(...) 
	if nine_eleven.G.GetConVarNumber("nine_eleven_antiscreengrab") != 1 then
		return oRC(...)
	end
	nine_eleven.Notify("Blocked an admin from taking a screenshot of your screen.")
	return nil 
end

local oSS = net.Receivers["screengrab_start"]

net.Receivers["screengrab_start"] = function(...)
	if nine_eleven.G.GetConVarNumber("nine_eleven_antiscreengrab") != 1 then
		return oSS(...)
	end
	nine_eleven.Notify("Blocked Screengrab.")
	nine_eleven.G.net.Start("screengrab_start")
		nine_eleven.G.net.WriteUInt(4,32)
	nine_eleven.G.net.SendToServer()
end

local oSP = net.Receivers["screengrab_start"]

net.Receivers["screengrab_part"] = function(...)
	if nine_eleven.G.GetConVarNumber("nine_eleven_antiscreengrab") != 1 then
		return oSP(...)
	end
	nine_eleven.Notify("Blocked Screengrab.")
	nine_eleven.G.net.Start( "screengrab_part")
		nine_eleven.G.net.WriteUInt( 4, 32 )
		nine_eleven.G.net.WriteData( "111111111111111111111111", 4 )
	nine_eleven.G.net.SendToServer()
end

nine_eleven.G.CreateClientConVar("nine_eleven_spinbot", 0)
nine_eleven.G.CreateClientConVar("nine_eleven_spinbot_speed", 5)

function nine_eleven.Spinbot(ucmd)
	if nine_eleven.G.GetConVarNumber("nine_eleven_antiaim") == 1 or valid or nine_eleven.G.input.IsMouseDown(107) or nine_eleven.G.GetConVarNumber("nine_eleven_spinbot") != 1 then return end
	nine_eleven.CmdM.SetViewAngles(ucmd, nine_eleven.CmdM.GetViewAngles(ucmd) + nine_eleven.G.Angle(0,nine_eleven.G.GetConVarNumber("nine_eleven_spinbot_speed"),0))
	nine_eleven.GixMovement(ucmd)
end

nine_eleven.AddHook("CreateMove", nine_eleven.G.util.CRC("spinbot"), nine_eleven.Spinbot)

local mirrordata = {
	x = nine_eleven.G.ScrW() - 500,
	y = 0,
	w = 500,
	h = 250,
}

nine_eleven.Config = {}

nine_eleven.Config["HvH"] = {
	{ "antiaim", 1 },
	{ "aimbot_autoshoot", 1 },
	{ "aimbot_nospread", 1 },
	{ "bhop", 1 },
	{ "bhop_autostrafe", 1 },
	{ "esp", 1 },
	{ "esp_box", 1 },
	{ "chams", 1},
	{ "entesp", 0},
	{ "weaponlaser", 0 },
	{ "eyelaser", 0 },
	{ "esp_type", 1 },
	{ "headesp", 1 },
	{ "nohands", 1 },
	{ "nospread", 1 },
	{ "xray", 0 },
	{ "tracers", 1 },
}

local function loadconfig(name, file)
	if !file then
		if !nine_eleven.Config[name] then
			nine_eleven.Notify("Failed loading config.")
			return
		end
		for k,v in nine_eleven.G.pairs(nine_eleven.Config[name]) do
			nine_eleven.G.RunConsoleCommand("nine_eleven_"..v[1], v[2])
			nine_eleven.Notify("Config Loader: Set '".."nine_eleven_"..v[1].."' to '"..v[2].."'.")
		end
	else
		if !nine_eleven.G.file.Exists("nine_eleven/"..file, "DATA") then
			nine_eleven.Notify("Config '"..file.."' doenst exist!")
		end
		local tab = nine_eleven.G.file.Read("nine_eleven/"..file)
		local tab = nine_eleven.G.util.JSONToTable(tab)
		for k,v in nine_eleven.G.pairs(tab) do
			nine_eleven.G.RunConsoleCommand(v.Cvar, v.Val)
			nine_eleven.Notify("Config Loader: Set '".."nine_eleven_"..v.Cvar.."' to '"..v.Val.."'.")
		end
	end
end

local function safeconfig()
	local namet = nine_eleven.G.vgui.Create("DFrame")
	namet:SetSize(400, 60)
	namet:SetPos((nine_eleven.G.ScrW() / 2) - 630, ScrH() / 2)
	namet:SetTitle("Config Name")
	local namef = nine_eleven.G.vgui.Create("DTextEntry", namet)
	namef:SetPos(5, 30)
	namef:SetSize(390, 25)
	namet:MakePopup()
	local cvartable = {}
	namef.OnEnter = function()
		for k,v in nine_eleven.G.pairs(nine_eleven.CVars) do
			nine_eleven.G.table.insert(cvartable, { Cvar = v, Val = nine_eleven.G.GetConVarString(v) } )
		end
		local tab = nine_eleven.G.util.TableToJSON(cvartable)
		nine_eleven.G.file.Write("nine_eleven/"..namef:GetValue()..".txt", tab)
		nine_eleven.Notify("Saved Config '"..namef:GetValue().."'.")
		namet:Close()
	end
end

local function deleteconfig(v)
	local confirm = nine_eleven.G.vgui.Create("DFrame")
	confirm:SetSize(400, 100)
	confirm:SetTitle("")
	confirm:Center()
	
	local text = nine_eleven.G.vgui.Create("DLabel", confirm)
	text:SetText("Please confirm that you wish to delete config: "..v)
	text:SetPos(5, 25)
	text:SizeToContents()
	
	local confirmbutton = nine_eleven.G.vgui.Create("DButton", confirm)
	local abortbutton = nine_eleven.G.vgui.Create("DButton", confirm)
	
	confirmbutton:SetText("Confirm")
	confirmbutton:SetPos(5, 50)
	confirmbutton:SetSize(120, 40)
	confirmbutton.DoClick = function()
		nine_eleven.G.file.Delete("nine_eleven/"..v, "DATA")
		nine_eleven.Notify("Deleted Config '"..v.."'.")
		confirm:Close()
	end
	
	abortbutton:SetPos(275, 50)
	abortbutton:SetSize(120, 40)
	abortbutton:SetText("Abort")
	abortbutton.DoClick = function()
		confirm:Close()
	end
	
	confirm:MakePopup()
end

nine_eleven.G.concommand.Add("nine_eleven_menu", function()
	local panel = nine_eleven.G.vgui.Create("DFrame")
	panel:SetSize(400, 500)
	panel:SetTitle("nine_eleven-bot || Menu ||"..nine_eleven.rand())
	panel:Center()
	panel:MakePopup()
	
	local sheet = nine_eleven.G.vgui.Create("DPropertySheet", panel)
	sheet:SetPos(5, 30)
	sheet:SetSize(390, 465)
	
	local sheetframe1 = nine_eleven.G.vgui.Create("DFrame", sheet)
	sheetframe1:SetSize(370, 445)
	sheetframe1:SetPos(25, 50)
	sheetframe1:ShowCloseButton(false)
	sheetframe1:SetTitle("A I M B O T")
	
	local sheetframe2 = nine_eleven.G.vgui.Create("DFrame", sheet)
	sheetframe2:SetSize(370, 445)
	sheetframe2:SetPos(25, 50)
	sheetframe2:ShowCloseButton(false)
	sheetframe2:SetTitle("V I S U A L S")
	
	local sheetframe3 = nine_eleven.G.vgui.Create("DFrame", sheet)
	sheetframe3:SetSize(370, 445)
	sheetframe3:SetPos(25, 50)
	sheetframe3:ShowCloseButton(false)
	sheetframe3:SetTitle("M I S C")
	
	local sheetframe4 = nine_eleven.G.vgui.Create("DFrame", sheet)
	sheetframe4:SetSize(370, 445)
	sheetframe4:SetPos(25, 50)
	sheetframe4:ShowCloseButton(false)
	sheetframe4:SetTitle("C R E D I T S")
	
	local sheetframe5 = nine_eleven.G.vgui.Create("DFrame", sheet)
	sheetframe5:SetSize(370, 445)
	sheetframe5:SetPos(25, 50)
	sheetframe5:ShowCloseButton(false)
	sheetframe5:SetTitle("S E T T I N G S")
	
	local text = nine_eleven.G.vgui.Create("DLabel", sheetframe4)
	text:SetPos(5, 30)
	text:SetText(
[[Made by Razor
Allahu Akbar]]
	)
	text:SizeToContents()
	
	local function createbox(pos1, pos2, text, cvar, parent)
		local checkbox = nine_eleven.G.vgui.Create("DCheckBoxLabel", parent)
		checkbox:SetPos(pos1, pos2)
		checkbox:SetText(text)
		checkbox:SetConVar(cvar)
		checkbox:SetValue(nine_eleven.G.GetConVarNumber(cvar))
		checkbox:SizeToContents()
	end	
	
	createbox(5, 30, "NoSpread", "nine_eleven_aimbot_nospread", sheetframe1)
	createbox(5, 50, "Autofire", "nine_eleven_aimbot_autoshoot", sheetframe1)
	createbox(5, 70, "Target Friends", "nine_eleven_targetfriends", sheetframe1)
	createbox(5, 90, "Triggerbot", "nine_eleven_triggerbot", sheetframe1)
	createbox(5, 110, "NoSpread Module (Checked = NYX, Unchecked = Dickwrap)", "nine_eleven_nospread_module", sheetframe1)
	createbox(5, 30, "ESP", "nine_eleven_esp", sheetframe2)
	createbox(5, 50, "ESP Box", "nine_eleven_esp_box", sheetframe2)
	createbox(5, 70, "ESP Type (Checked = 3D, Unchecked = 2D)", "nine_eleven_esp_type", sheetframe2)
	createbox(5, 90, "Entity ESP", "nine_eleven_entesp", sheetframe2)
	createbox(5, 110, "Chams", "nine_eleven_chams", sheetframe2)
	createbox(5, 130, "Anti-Aim", "nine_eleven_antiaim", sheetframe2)
	createbox(5, 150, "NoSpread (All the Time)", "nine_eleven_nospread", sheetframe2)
	createbox(5, 170, "NoRecoil", "nine_eleven_norecoil", sheetframe2)
	createbox(5, 190, "Eye Laser", "nine_eleven_eyelaser", sheetframe2)
	createbox(5, 210, "No Hands", "nine_eleven_nohands", sheetframe2)
	createbox(5, 230, "Tracers", "nine_eleven_tracers", sheetframe2)
	createbox(5, 250, "X-Ray", "nine_eleven_xray", sheetframe2)
	createbox(5, 270, "Weapon Laser", "nine_eleven_weaponlaser", sheetframe2)
	createbox(5, 290, "Head ESP", "nine_eleven_headesp", sheetframe2)
	createbox(5, 310, "Fake Shake", "nine_eleven_fakeshake", sheetframe2)
	createbox(5, 330, "Spinbot", "nine_eleven_spinbot", sheetframe2)
	local text3 = nine_eleven.G.vgui.Create("DLabel", sheetframe2)
	text3:SetPos(5, 350)
	text3:SetText("Spinbot Speed")
	text3:SizeToContents()
	local numberwang2 = nine_eleven.G.vgui.Create("DNumberWang", sheetframe2)
	numberwang2:SetPos(150, 348)
	numberwang2:SetSize(25, 20)
	numberwang2:SetValue(nine_eleven.G.GetConVarNumber("nine_eleven_spinbot_speed"))
	numberwang2:SetConVar("nine_eleven_spinbot_speed")
	numberwang2:SetDecimals(0)
	createbox(5, 30, "BHop", "nine_eleven_bhop", sheetframe3)
	createbox(5, 50, "BHop Autostrafe", "nine_eleven_bhop_autostrafe", sheetframe3)
	createbox(5, 70, "Auto Move Mouse (Autostrafe)", "nine_eleven_bhop_autostrafe_method", sheetframe3)
	createbox(5, 90, "Random Chatspam (Spams Random Words)", "nine_eleven_randomchatspam", sheetframe3)
	createbox(5, 130, "Rapidfire", "nine_eleven_rapidfire", sheetframe3)
	createbox(5, 150, "Anti-Screengrab", "nine_eleven_antiscreengrab", sheetframe3)
	local numberwang = nine_eleven.G.vgui.Create("DNumberWang", sheetframe3)
	numberwang:SetPos(150, 108)
	numberwang:SetSize(25, 20)
	numberwang:SetValue(nine_eleven.G.GetConVarNumber("nine_eleven_randomchatspam_amount"))
	numberwang:SetConVar("nine_eleven_randomchatspam_amount")
	numberwang:SetDecimals(0)
	local text2 = nine_eleven.G.vgui.Create("DLabel", sheetframe3)
	text2:SetPos(5, 110)
	text2:SetText("Amount of words to spam")
	text2:SizeToContents()
	
	local function changetitle()
		nine_eleven.G.timer.Simple(.02, function()
			local succ, err = nine_eleven.G.pcall(function()
				panel:SetTitle("nine_eleven-bot || Menu ||"..nine_eleven.rand())
			end)
			if err then return end
			changetitle()
		end)
	end
	
	changetitle()
	
	local function createbutton(pos1, pos2, text, onclick, parent, size1, size2)
		local button = nine_eleven.G.vgui.Create("DButton", parent)
		button:SetPos(pos1, pos2)
		button:SetSize(size1, size2)
		button:SetText(text)
		button.DoClick = onclick
	end
	
	createbutton(5, 30, "Load HvH Settings", function() loadconfig("HvH") end, sheetframe5, 365, 50)
	createbutton(5, 90, "Save Current Settings", function() safeconfig() end, sheetframe5, 365, 50)
	createbutton(5, 150, "Load Config from file", function()
		local Configs = DermaMenu()
		for k,v in nine_eleven.G.pairs(nine_eleven.G.file.Find("data/nine_eleven/*.txt", "GAME")) do
			Configs:AddOption(v, function() loadconfig(nil, v) end)
		end
		Configs:Open()
	end, 
	sheetframe5, 365, 50)
	
	createbutton(5, 210, "Delete Config", function()
		local Configs = DermaMenu()
		for k,v in nine_eleven.G.pairs(nine_eleven.G.file.Find("data/nine_eleven/*.txt", "GAME")) do
			Configs:AddOption(v, function() deleteconfig(v) end)
		end
		Configs:Open()
	end, 
	sheetframe5, 365, 50)
	
	sheet:AddSheet("Aimbot", sheetframe1, "gui/silkicons/bomb", false, false)
	sheet:AddSheet("Wallhack/ESP/Visual", sheetframe2, "gui/silkicons/box", false, false)
	sheet:AddSheet("Misc.", sheetframe3, "gui/silkicons/wrench", false, false)
	sheet:AddSheet("Configs", sheetframe5, "gui/silkicons/computer", false, false)
	sheet:AddSheet("Credits", sheetframe4, "gui/silkicons/leader", false, false)
end)

nine_eleven.G.notification.AddProgress("nine", "nine_eleven-bot loaded.")

nine_eleven.G.timer.Simple(2, function()
	nine_eleven.G.notification.Kill("nine")
end)

--nine_eleven.G.timer.Destroy("AutomaticHighPingKicker")

nine_eleven.G.file.CreateDir("nine_eleven")