local util = util
local vgui = vgui
local draw = draw
local surface = surface
local table = table
local ents = ents
 
local AE = {}
AE.Ply = LocalPlayer()
AE.Settings = {}
AE.Settings["Active"] = CreateClientConVar("AE_Active", 1, true, false)
AE.Settings["ESP_Active"] = CreateClientConVar("AE_ESP_Active", 1, true, false)
AE.Settings["ESP_Distance_Limit"] = CreateClientConVar("AE_ESP_Distance_Limit", 0, true, false)
AE.Settings["Wallhack_Active"] = CreateClientConVar("AE_Wallhack_Active", 1, true, false)
AE.Settings["Wallhack_Distance_Limit"] = CreateClientConVar("AE_Wallhack_Distance_Limit", 0, true, false)
AE.Settings["Wallhack_Light"] = CreateClientConVar("AE_Wallhack_Light", 1, true, false)
AE.Settings["EntsToShow"] = CreateClientConVar("AE_EntsToShow", "[]", true, false)
 
AE.EntsToShow = util.JSONToTable(AE.Settings["EntsToShow"]:GetString()) or {}
 
concommand.Add("AEnt_Menu", function(ply, cmd, args)
        local temp = {}
       
        local All = ents.GetAll()
        for k = 1, #All do
                local v = All[k]:GetClass()
                local add = true
               
                for i = 1, #AE.EntsToShow do
                        if AE.EntsToShow[i] == v then
                                add = false
                                break
                        end
                end
               
                if add then
                        for i = 1, #temp do
                                if temp[i] == v then
                                        add = false
                                        break
                                end
                        end
                end
               
                if add then
                        table.insert(temp, v)
                end
        end
       
        local main = vgui.Create( "DFrame" )
        main:SetSize( 340, 400 )
        main:Center()
        main:SetTitle( "" )
        main:SetVisible( true )
        main:SetDraggable( true )
        main:ShowCloseButton( true )
        main:MakePopup()
        main.Paint = function()
                draw.RoundedBox( 8, 0, 0, main:GetWide(), main:GetTall(), Color( 0, 0, 0, 150 ) )
        end
       
        local OtherEnts = vgui.Create("DListView", main) //Need this up here so SelectedEnts.DoDoubleClick can reference it.
       
        local SelectedEnts = vgui.Create("DListView", main)
        SelectedEnts:SetSize(150, 200)
        SelectedEnts:SetPos(20, 25)
        SelectedEnts:SetMultiSelect(false)
        SelectedEnts:AddColumn("Ents To Show")
        for k = 1, #AE.EntsToShow do
                SelectedEnts:AddLine(AE.EntsToShow[k])
        end
        SelectedEnts.DoDoubleClick = function(panel, index, line)
                local val = SelectedEnts:GetLine(index):GetValue(1)
                table.insert(temp, val)
                OtherEnts:AddLine(val)
                for k = 1, #AE.EntsToShow do
                        if val == AE.EntsToShow[k] then
                                table.remove(AE.EntsToShow, k)
                                break
                        end
                end
                SelectedEnts:RemoveLine(index)
                AE.Ply:ConCommand("AE_EntsToShow "..util.TableToJSON(AE.EntsToShow))
        end
       
        //local OtherEnts = vgui.Create("DListView", main) - See above where it was actually created
        OtherEnts:SetSize(150, 200)
        OtherEnts:SetPos(170, 25)
        OtherEnts:SetMultiSelect(false)
        OtherEnts:AddColumn("Other Ents")
        for k = 1, #temp do
                OtherEnts:AddLine(temp[k])
        end
        OtherEnts.DoDoubleClick = function(panel, index, line)
                local val = OtherEnts:GetLine(index):GetValue(1)
                table.insert(AE.EntsToShow, val)
                SelectedEnts:AddLine(val)      
                for k = 1, #temp do
                        if val == temp[k] then
                                table.remove(temp, k)
                                break
                        end
                end
                OtherEnts:RemoveLine(index)
                AE.Ply:ConCommand("AE_EntsToShow "..util.TableToJSON(AE.EntsToShow))
        end
       
        local List = vgui.Create("DPanelList", main)
        List:SetPos(20, 235)
        List:SetSize(main:GetWide() - 40, main:GetTall() - 245)
        List:EnableVerticalScrollbar(true)
        List:EnableHorizontal( false )
        List:SetSpacing( 5 )
       
        local Active = vgui.Create("DCheckBoxLabel")
        Active:SetText("Active")
        Active:SetConVar("AE_Active")
        Active:SetValue(AE.Settings["Active"]:GetInt())
        Active:SizeToContents()
        List:AddItem(Active)
       
        local ESP_Active = vgui.Create("DCheckBoxLabel")
        ESP_Active:SetText("ESP - Active")
        ESP_Active:SetConVar("AE_ESP_Active")
        ESP_Active:SetValue(AE.Settings["ESP_Active"]:GetInt())
        ESP_Active:SizeToContents()
        List:AddItem(ESP_Active)
       
        local ESP_DistanceLimit = vgui.Create("DNumSlider")
        ESP_DistanceLimit:SetText("Max Distance - ESP")
        ESP_DistanceLimit:SetMin(0)
        ESP_DistanceLimit:SetMax(6000)
        ESP_DistanceLimit:SetDecimals(0)
        ESP_DistanceLimit:SetConVar("AE_ESP_Distance_Limit")
        List:AddItem(ESP_DistanceLimit)
       
        local Wallhack_Active = vgui.Create("DCheckBoxLabel")
        Wallhack_Active:SetText("Wallhack - Active")
        Wallhack_Active:SetConVar("AE_Wallhack_Active")
        Wallhack_Active:SetValue(AE.Settings["Wallhack_Active"]:GetInt())
        Wallhack_Active:SizeToContents()
        List:AddItem(Wallhack_Active)
       
        local Chams_DistanceLimit = vgui.Create("DNumSlider")
        Chams_DistanceLimit:SetText("Max Distance - Wallhack")
        Chams_DistanceLimit:SetMin(0)
        Chams_DistanceLimit:SetMax(6000)
        Chams_DistanceLimit:SetDecimals(0)
        Chams_DistanceLimit:SetConVar("AE_Wallhack_Distance_Limit")
        List:AddItem(Chams_DistanceLimit)
       
        local Wallhack_Light = vgui.Create("DCheckBoxLabel")
        Wallhack_Light:SetText("Wallhack - Light")
        Wallhack_Light:SetConVar("AE_Wallhack_Light")
        Wallhack_Light:SetValue(AE.Settings["Wallhack_Light"]:GetInt())
        Wallhack_Light:SizeToContents()
        List:AddItem(Wallhack_Light)   
end)
 
hook.Add("HUDPaint", "ShowEnts", function()
        if AE.Settings["Active"]:GetBool() and (AE.Settings["ESP_Active"]:GetBool() or AE.Settings["Wallhack_Active"]:GetBool()) and #AE.EntsToShow > 0 then
                local AllEnts = ents.GetAll()
                for k = 1, #AllEnts do
                        local v = AllEnts[k]
                        for i = 1, #AE.EntsToShow do
                                if v:GetClass() == AE.EntsToShow[i] then
                                        if AE.Settings["Wallhack_Active"]:GetBool() then
                                                if AE.Settings["Wallhack_Distance_Limit"]:GetInt() == 0 or AE.Ply:GetPos():Distance(v:GetPos()) < AE.Settings["Wallhack_Distance_Limit"]:GetInt() then
                                                        cam.Start3D(AE.Ply:EyePos(), AE.Ply:EyeAngles())
                                                                if AE.Settings["Wallhack_Light"]:GetBool() then
                                                                        render.SuppressEngineLighting(true)    
                                                                        v:DrawModel()
                                                                        render.SuppressEngineLighting(false)
                                                                else
                                                                        v:DrawModel()
                                                                end
                                                        cam.End3D()
                                                end
                                        end
                                       
                                        if AE.Settings["ESP_Active"]:GetBool() then
                                                if AE.Settings["ESP_Distance_Limit"]:GetInt() == 0 or AE.Ply:GetPos():Distance(v:GetPos()) < AE.Settings["ESP_Distance_Limit"]:GetInt() then
                                                        surface.SetFont("default")
                                                        surface.SetTextColor(Color(255, 255, 255, 255))
                                                       
                                                        local text = v:GetClass() or "Unknown"
                                                        local W, H = surface.GetTextSize(text)
                                                       
                                                        local PosScreen = v:GetPos():ToScreen()
                                                        surface.SetTextPos( PosScreen.x - W / 2, PosScreen.y )
                                                        surface.DrawText(text)
                                                end
                                        end
                                end
                        end
                end
        end
end)