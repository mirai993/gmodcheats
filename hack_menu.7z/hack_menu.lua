------------------------------------------------------------------------------------
local onegreen = Color(85,255,85,255)
local twogreen = Color(135,255,80,255)
local threegreen = Color(175,255,80,255)
local oneyellow = Color(250,255,80,255)
local oneorange = Color(255,240,80,255)
local twoorange = Color(255,195,80,255)
local onered = Color(255,140,80,255)
local twored = Color(255,110,80,255)
local naxred = Color(255,0,0,255)

------------------------------------------------------------------------------------
surface.CreateFont( "ChalkAnarchyIndicators", {
	font = "CloseCaption_Bold", --  Use the font-name which is shown to you by your operating system Font Viewer, not the file name
	extended = false,
	size = 30,
	weight = 700,
	shadow = true,
	outline = false,
} )
-------------------------------------------------------------------------------------
local ply = LocalPlayer()

local function DrawChromaLine( speed, str, font, x, y )

	surface.SetFont( font )
	surface.SetTextColor( HSVToColor(  ( CurTime() * speed ) % 360, 1, 1 ) )
	surface.SetTextPos( x, y )

	surface.DrawText( str )

end
-------------------------------------------------------------------------------------
local function ex11 ( ply )
    cur_fps = tostring(math.floor(1 / RealFrameTime()))
	local ply = LocalPlayer()	
end

local function ex1 ( ply )
	ex11()
end

hook.Add("HUDPaint", "ex1", ex1)
------------------------------------------------------------------------------------

------------------------------------------------------------------------------------

concommand.Add("A_open", function ( ply )

    local frame = vgui.Create("DFrame")
    frame:SetSize(750,500)
    frame:SetPos( 500, 50 )
    frame:SetTitle("Hack Menu")
    frame:SetVisible(true)
    frame:ShowCloseButton(true)
    frame:MakePopup()
    frame:SetIcon("icon16/emoticon_happy.png")
    frame.Paint = function(s , w , h)
	
	    draw.RoundedBox(0,0,0,w , h,Color(40,40,40,200))
	    draw.RoundedBox(0,2,2,w-4 , h-4,Color(10,15,10,200))
		DrawChromaLine( 50, "_________________________________________________________", "CloseCaption_Bold", 2, 0 )

    end
	

    local ontop = vgui.Create("DFrame" , frame)
    ontop:SetSize(2000,25)
    ontop:SetPos( -2, -1 )
    ontop:SetIcon("icon16/fire.png")
    ontop:SetTitle("55252525252525")
    ontop:SetVisible(true)
    ontop:ShowCloseButton(false)
    ontop:MakePopup()
    ontop:SetDraggable( false )
    ontop.Paint = function(s , w , h)

	    draw.RoundedBox(0,0,0,w , h,Color(40,40,40,200))
	    draw.RoundedBox(0,1,1,w-4 , h-4,Color(10,15,10,200))
	    draw.SimpleText( "Ping: " .. ply:Ping(), "TargetID", 1210, 2, color_white )
		draw.SimpleText( "FPS: " .. cur_fps, "TargetID", 1120, 2, color_white ) 
		DrawChromaLine( 50, "________________________________________________________________________________________________________________________________________________________________________________________________________________________________", "CloseCaption_Bold", 0, 0 )
		
    end

    local sub_categories = vgui.Create("DFrame" , frame)
    sub_categories:SetSize(250,400)
    sub_categories:SetPos( 25, 50 )
    sub_categories:SetIcon("icon16/folder_brick.png")
    sub_categories:SetTitle("Other categories")
    sub_categories:SetVisible(true)
    sub_categories:ShowCloseButton(false)
    sub_categories:MakePopup()
    sub_categories.Paint = function(s , w , h)

	    draw.RoundedBox(0,0,0,w , h,Color(40,40,40,200))
	    draw.RoundedBox(0,2,2,w-4 , h-4,Color(10,15,10,200))

    end
	--Sheet Tab
    local tabs = vgui.Create( "DPropertySheet", frame )
    tabs:Dock( FILL )
    tabs.Paint = function(s , w , h)

	    draw.RoundedBox(0,0,0,w , h,Color(10,10,10,200))
	    draw.RoundedBox(0,2,2,w-4 , h-4,Color(10,15,10,200))

    end	


 
    local tab1panel = vgui.Create( "DPanel", tabs )
	    tab1panel.Paint = function(s , w , h)
        
	    draw.RoundedBox(0,0,0,w , h,Color(40,40,40,200))
	    draw.RoundedBox(0,2,2,w-4 , h-4,Color(10,15,10,200))
		draw.RoundedBox(0,8,8,198 , 408,Color(60,60,60,200))
        draw.RoundedBox(0,10,10, 200, 410,Color(30,35,30,200))
		draw.RoundedBox(0,213,8,198 , 218,Color(60,60,60,200))
        draw.RoundedBox(0,215,10, 200, 220,Color(30,35,30,200))
		draw.RoundedBox(0,213,218,198 , 198,Color(60,60,60,200))
        draw.RoundedBox(0,215,220, 200, 200,Color(30,35,30,200))
		draw.RoundedBox(0,418,218,298 , 198,Color(60,60,60,200))
        draw.RoundedBox(0,420,220, 300, 200,Color(30,35,30,200))
		draw.RoundedBox(0,418,8,298 , 204,Color(60,60,60,200))
        draw.RoundedBox(0,420,10, 300, 206,Color(30,35,30,200))
		
    end
	
    local miscpanel = vgui.Create( "DPanel", tabs)
    miscpanel.Paint = function(s , w , h)
        
	    draw.RoundedBox(0,0,0,w , h,Color(40,40,40,200))
	    draw.RoundedBox(0,2,2,w-4 , h-4,Color(10,15,10,200))
		draw.RoundedBox(0,8,8,198 , 208,Color(60,60,60,200))
        draw.RoundedBox(0,10,10, 200, 210,Color(30,35,30,200))		
		
    end
	
    local hvhpanel = vgui.Create( "DPanel", tabs)
    hvhpanel.Paint = function(s , w , h)
        
	    draw.RoundedBox(0,0,0,w , h,Color(40,40,40,200))
	    draw.RoundedBox(0,2,2,w-4 , h-4,Color(10,15,10,200))
		draw.RoundedBox(0,8,8,198 , 408,Color(60,60,60,200))
        draw.RoundedBox(0,10,10, 200, 410,Color(30,35,30,200))
		
    end
	
    local scriptpanel = vgui.Create( "DPanel", tabs)
    scriptpanel.Paint = function(s , w , h)
        
	    draw.RoundedBox(0,0,0,w , h,Color(40,40,40,200))
	    draw.RoundedBox(0,2,2,w-4 , h-4,Color(10,15,10,200))
		
    end

    local browserpanel = vgui.Create( "DPanel", tabs)
    browserpanel.Paint = function(s , w , h)
        
	    draw.RoundedBox(0,0,0,w , h,Color(40,40,40,200))
	    draw.RoundedBox(0,2,2,w-4 , h-4,Color(10,15,10,200))
		
    end
	
    local steampanel = vgui.Create( "DPanel", tabs)
    steampanel.Paint = function(s , w , h)
        
	    draw.RoundedBox(0,0,0,w , h,Color(40,40,40,200))
	    draw.RoundedBox(0,2,2,w-4 , h-4,Color(10,15,10,200))
		
    end
	
    local darkrptab = vgui.Create( "DPanel", tabs)
    darkrptab.Paint = function(s , w , h)
        
	    draw.RoundedBox(0,0,0,w , h,Color(40,40,40,200))
	    draw.RoundedBox(0,2,2,w-4 , h-4,Color(10,15,10,200))
		
    end
	
    local hudtab = vgui.Create( "DPanel", tabs)
    hudtab.Paint = function(s , w , h)
        
	    draw.RoundedBox(0,0,0,w , h,Color(40,40,40,200))
	    draw.RoundedBox(0,2,2,w-4 , h-4,Color(10,15,10,200))
		
    end
	
    local testtab = vgui.Create( "DPanel", tabs)
    testtab.Paint = function(s , w , h)
        
	    draw.RoundedBox(0,0,0,w , h,Color(40,40,40,200))
	    draw.RoundedBox(0,2,2,w-4 , h-4,Color(10,15,10,200))
		
    end

    local creditstab = vgui.Create( "DPanel", tabs)
    creditstab.Paint = function(s , w , h)
        
	    draw.RoundedBox(0,0,0,w , h,Color(40,40,40,200))
	    draw.RoundedBox(0,2,2,w-4 , h-4,Color(10,15,10,200))
		
    end

    local shootingtab = vgui.Create( "DPanel", tabs)
    shootingtab.Paint = function(s , w , h)
        
	    draw.RoundedBox(0,0,0,w , h,Color(40,40,40,200))
	    draw.RoundedBox(0,2,2,w-4 , h-4,Color(10,15,10,200))
		draw.RoundedBox(0,8,8,198 , 198,Color(60,60,60,200))
        draw.RoundedBox(0,10,10, 200, 200,Color(30,35,30,200))
		
    end

	local DLabel = vgui.Create( "DLabel", tab1panel )
    DLabel:SetPos( 430, 220 )
    DLabel:SetText( "Players:" )
	
	local DLabel = vgui.Create( "DLabel", tab1panel )
    DLabel:SetPos( 425, 12 )
    DLabel:SetText( "World:" )
	
	
	local DLabel = vgui.Create( "DLabel", tab1panel )
    DLabel:SetPos( 425, 120 )
    DLabel:SetText( "Misc:" )
	
	local DLabel = vgui.Create( "DLabel", tab1panel )
    DLabel:SetPos( 15, 12 )
    DLabel:SetText( "cosmetic:" )
    --Visuals Tab Buttons
    local quitbutton = vgui.Create( "DButton", frame )
    quitbutton:SetText( "Quit" )
    quitbutton:SetSize(50,20)
    quitbutton:SetPos( 686, 35 )
    quitbutton:SetConsoleCommand( "disconnect" )
	quitbutton.Paint = function(s , w , h)

	    draw.RoundedBox(0,0,0,w , h,Color(66,66,66,200))
	    draw.RoundedBox(0,2,2,w-4 , h-4,Color(35,35,35,200))

    end
	--Visuals Tab Buttons - Enable button --servertickrate
	local venableline = tab1panel:Add( "DCheckBoxLabel", tab1panel) 
    venableline:SetPos( 15, 30 ) 
    venableline:SetValue( false ) 
	venableline:SetText( "Rainbow line" )
    venableline:SizeToContents()	
	
	local venablewatermark = tab1panel:Add( "DCheckBoxLabel", tab1panel) 
    venablewatermark:SetPos( 15, 50 ) 
    venablewatermark:SetValue( false ) 
	venablewatermark:SetText( "Watermark" )
    venablewatermark:SizeToContents()	
	
	local venablewatermark = tab1panel:Add( "DCheckBoxLabel", tab1panel) 
    venablewatermark:SetPos( 15, 50 ) 
    venablewatermark:SetValue( false ) 
	venablewatermark:SetText( "Watermark" )
    venablewatermark:SizeToContents()
	
	local venablewatermark2 = tab1panel:Add( "DCheckBoxLabel", tab1panel) 
    venablewatermark2:SetPos( 100, 50 ) 
    venablewatermark2:SetValue( false ) 
	venablewatermark2:SetText( "Watermark 2" )
    venablewatermark2:SizeToContents()
    
    local venablestats = tab1panel:Add( "DCheckBoxLabel", tab1panel) 
    venablestats:SetPos( 15, 70 ) 
    venablestats:SetValue( false ) 
	venablestats:SetText( "Enable Stats" )
    venablestats:SizeToContents()	
	
	local DLabel = vgui.Create( "DLabel", tab1panel )
    DLabel:SetPos( 15, 88 )
    DLabel:SetText( "indicators:" )
	
    local pingindicator = tab1panel:Add( "DCheckBoxLabel", tab1panel) 
    pingindicator:SetPos( 15, 110 ) 
    pingindicator:SetValue( false ) 
	pingindicator:SetText( "Ping" )
    pingindicator:SizeToContents()
	
    local servertickrate = tab1panel:Add( "DCheckBoxLabel", tab1panel) 
    servertickrate:SetPos( 15, 130 ) 
    servertickrate:SetValue( false ) 
	servertickrate:SetText( "TickInterval" )
    servertickrate:SizeToContents()
	
	local DLabel = vgui.Create( "DLabel", tab1panel )
    DLabel:SetPos( 225, 10 )
    DLabel:SetText( "Hand Chams:" )
------------------------------------------------------------------------------------------------------------------------	
    local handchamscheckm0 = tab1panel:Add( "DCheckBoxLabel", tab1panel ) 
    handchamscheckm0:SetPos( 222, 33 ) 
    handchamscheckm0:SetValue( false ) 
	handchamscheckm0:SetText( "Wireframe" )
    handchamscheckm0:SizeToContents()

    local handchamscheckm1 = tab1panel:Add( "DCheckBoxLabel", tab1panel ) 
    handchamscheckm1:SetPos( 222, 53 ) 
    handchamscheckm1:SetValue( false ) 
	handchamscheckm1:SetText( "Cubemap" )
    handchamscheckm1:SizeToContents()

    local handchamscheckm2 = tab1panel:Add( "DCheckBoxLabel", tab1panel ) 
    handchamscheckm2:SetPos( 222, 73 ) 
    handchamscheckm2:SetValue( false ) 
	handchamscheckm2:SetText( "Stained" )
    handchamscheckm2:SizeToContents()

    local handchamscheckm3 = tab1panel:Add( "DCheckBoxLabel", tab1panel ) 
    handchamscheckm3:SetPos( 222, 93 ) 
    handchamscheckm3:SetValue( false ) 
	handchamscheckm3:SetText( "Shiny" )
    handchamscheckm3:SizeToContents()

    local handchamscheckm4 = tab1panel:Add( "DCheckBoxLabel", tab1panel ) 
    handchamscheckm4:SetPos( 222, 113 ) 
    handchamscheckm4:SetValue( false ) 
	handchamscheckm4:SetText( "Comball tape" )
    handchamscheckm4:SizeToContents()

    local handchamscheckm5 = tab1panel:Add( "DCheckBoxLabel", tab1panel ) 
    handchamscheckm5:SetPos( 222, 133 ) 
    handchamscheckm5:SetValue( false ) 
	handchamscheckm5:SetText( "Glow" )
    handchamscheckm5:SizeToContents()

    local handchamscheckm6 = tab1panel:Add( "DCheckBoxLabel", tab1panel ) 
    handchamscheckm6:SetPos( 222, 153 ) 
    handchamscheckm6:SetValue( false ) 
	handchamscheckm6:SetText( "PortalBall" )
    handchamscheckm6:SizeToContents()

    local handchamscheckm7 = tab1panel:Add( "DCheckBoxLabel", tab1panel ) 
    handchamscheckm7:SetPos( 222, 173 ) 
    handchamscheckm7:SetValue( false ) 
	handchamscheckm7:SetText( "Tank Glass" )
    handchamscheckm7:SizeToContents()
	
    local handchamscheckm8 = tab1panel:Add( "DCheckBoxLabel", tab1panel ) 
    handchamscheckm8:SetPos( 222, 193 ) 
    handchamscheckm8:SetValue( false ) 
	handchamscheckm8:SetText( "TPrings Globe" )
    handchamscheckm8:SizeToContents()

    local handchamscheckm9 = tab1panel:Add( "DCheckBoxLabel", tab1panel ) 
    handchamscheckm9:SetPos( 315, 33 ) 
    handchamscheckm9:SetValue( false ) 
	handchamscheckm9:SetText( "ScreenScape" )
    handchamscheckm9:SizeToContents()

    local handchamscheckm10 = tab1panel:Add( "DCheckBoxLabel", tab1panel ) 
    handchamscheckm10:SetPos( 315, 53 ) 
    handchamscheckm10:SetValue( false ) 
	handchamscheckm10:SetText( "Frosted Glass" )
    handchamscheckm10:SizeToContents()

    local handchamscheckm11 = tab1panel:Add( "DCheckBoxLabel", tab1panel ) 
    handchamscheckm11:SetPos( 315, 73 ) 
    handchamscheckm11:SetValue( false ) 
	handchamscheckm11:SetText( "Stripes" )
    handchamscheckm11:SizeToContents()

    local handchamscheckm12 = tab1panel:Add( "DCheckBoxLabel", tab1panel ) 
    handchamscheckm12:SetPos( 315, 93 ) 
    handchamscheckm12:SetValue( false ) 
	handchamscheckm12:SetText( "Green" )
    handchamscheckm12:SizeToContents()

    local handchamscheckm13 = tab1panel:Add( "DCheckBoxLabel", tab1panel ) 
    handchamscheckm13:SetPos( 315, 113 ) 
    handchamscheckm13:SetValue( false ) 
	handchamscheckm13:SetText( "Animated Red" )
    handchamscheckm13:SizeToContents()

	local DLabel = vgui.Create( "DLabel", tab1panel )
    DLabel:SetPos( 225, 220 )
    DLabel:SetText( "Gun Chams:" )
------------------------------------------------------------------------------------------------------------------------	
    local gunchamscheckm0 = tab1panel:Add( "DCheckBoxLabel", tab1panel ) 
    gunchamscheckm0:SetPos( 222, 240 ) 
    gunchamscheckm0:SetValue( false ) 
	gunchamscheckm0:SetText( "Wireframe" )
    gunchamscheckm0:SizeToContents()

    local gunchamscheckm1 = tab1panel:Add( "DCheckBoxLabel", tab1panel ) 
    gunchamscheckm1:SetPos( 222, 260 ) 
    gunchamscheckm1:SetValue( false ) 
	gunchamscheckm1:SetText( "Cubemap" )
    gunchamscheckm1:SizeToContents()

    local gunchamscheckm2 = tab1panel:Add( "DCheckBoxLabel", tab1panel ) 
    gunchamscheckm2:SetPos( 222, 280 ) 
    gunchamscheckm2:SetValue( false ) 
	gunchamscheckm2:SetText( "Stained" )
    gunchamscheckm2:SizeToContents()

    local gunchamscheckm3 = tab1panel:Add( "DCheckBoxLabel", tab1panel ) 
    gunchamscheckm3:SetPos( 222, 300 ) 
    gunchamscheckm3:SetValue( false ) 
	gunchamscheckm3:SetText( "Shiny" )
    gunchamscheckm3:SizeToContents()

    local gunchamscheckm4 = tab1panel:Add( "DCheckBoxLabel", tab1panel ) 
    gunchamscheckm4:SetPos( 222, 320 ) 
    gunchamscheckm4:SetValue( false ) 
	gunchamscheckm4:SetText( "Comball tape" )
    gunchamscheckm4:SizeToContents()

    local gunchamscheckm5 = tab1panel:Add( "DCheckBoxLabel", tab1panel ) 
    gunchamscheckm5:SetPos( 222, 340 ) 
    gunchamscheckm5:SetValue( false ) 
	gunchamscheckm5:SetText( "Glow" )
    gunchamscheckm5:SizeToContents()

    local gunchamscheckm6 = tab1panel:Add( "DCheckBoxLabel", tab1panel ) 
    gunchamscheckm6:SetPos( 222, 360 ) 
    gunchamscheckm6:SetValue( false ) 
	gunchamscheckm6:SetText( "PortalBall" )
    gunchamscheckm6:SizeToContents()

    local gunchamscheckm7 = tab1panel:Add( "DCheckBoxLabel", tab1panel ) 
    gunchamscheckm7:SetPos( 320, 240 ) 
    gunchamscheckm7:SetValue( false ) 
	gunchamscheckm7:SetText( "Tank Glass" )
    gunchamscheckm7:SizeToContents()
	
    local gunchamscheckm8 = tab1panel:Add( "DCheckBoxLabel", tab1panel ) 
    gunchamscheckm8:SetPos( 320, 260 ) 
    gunchamscheckm8:SetValue( false ) 
	gunchamscheckm8:SetText( "TPrings Globe" )
    gunchamscheckm8:SizeToContents()

    local gunchamscheckm9 = tab1panel:Add( "DCheckBoxLabel", tab1panel ) 
    gunchamscheckm9:SetPos( 320, 280 ) 
    gunchamscheckm9:SetValue( false ) 
	gunchamscheckm9:SetText( "ScreenScape" )
    gunchamscheckm9:SizeToContents()

    local gunchamscheckm10 = tab1panel:Add( "DCheckBoxLabel", tab1panel ) 
    gunchamscheckm10:SetPos( 320, 300 ) 
    gunchamscheckm10:SetValue( false ) 
	gunchamscheckm10:SetText( "Frosted Glass" )
    gunchamscheckm10:SizeToContents()

    local gunchamscheckm11 = tab1panel:Add( "DCheckBoxLabel", tab1panel ) 
    gunchamscheckm11:SetPos( 320, 320 ) 
    gunchamscheckm11:SetValue( false ) 
	gunchamscheckm11:SetText( "Stripes" )
    gunchamscheckm11:SizeToContents()

    local gunchamscheckm12 = tab1panel:Add( "DCheckBoxLabel", tab1panel ) 
    gunchamscheckm12:SetPos( 320, 340 ) 
    gunchamscheckm12:SetValue( false ) 
	gunchamscheckm12:SetText( "Green" )
    gunchamscheckm12:SizeToContents()

    local gunchamscheckm13 = tab1panel:Add( "DCheckBoxLabel", tab1panel ) 
    gunchamscheckm13:SetPos( 320, 360 ) 
    gunchamscheckm13:SetValue( false ) 
	gunchamscheckm13:SetText( "Animated Red" )
    gunchamscheckm13:SizeToContents()
    --local gunchamscheck = frame:Add( "DCheckBoxLabel" ) --servertickrate
    ---gunchamscheck:SetPos( 235, 110 ) 
    --gunchamscheck:SetValue( false ) 
	--gunchamscheck:SetText( "Viewmodel Chams" )
    --gunchamscheck:SizeToContents()
--------------------------------------------------------------------------------------------------------------------------
	local mat0 = Material("models/wireframe")
    local mat1 = Material("debug/env_cubemap_model")
	local mat2 = Material("models/shadertest/shader5")
    local mat3 = Material("models/shiny")
	local mat4 = Material("Models/effects/comball_tape")
    local mat5 = Material("Models/effects/splodearc_sheet")
	local mat6 = Material("models/props_combine/portalball001_sheet")
    local mat7 = Material("models/props_lab/Tank_Glass001")
	local mat8 = Material("models/props_combine/tprings_globe")
    local mat9 = Material("models/screenspace")
    local mat10 = Material("models/props_c17/frostedglass_01a")
	local mat11 = Material("phoenix_storms/stripes")
    local mat12 = Material("phoenix_storms/wire/pcb_green")
    local mat13 = Material("models/XQM/LightLinesRed_tool")
----------------------------------------------------------------------------------------------------------------------------	
 	function handchamscheckm0:OnChange(venablestatss)
	if (venablestatss) then
        hook.Add("PreDrawPlayerHands", "handchams", function()
            render.SetColorModulation(0,0,1)
            render.MaterialOverride(mat0)
            render.SetBlend(1)
        end)
        hook.Add("PostDrawPlayerHands", "handchams", function()
            render.SetColorModulation(1, 1, 1)
            render.MaterialOverride(Material(""))
            render.SetBlend(1)
        end)
	else
        hook.Add("PreDrawPlayerHands", "handchams", function()
        end)
        hook.Add("PostDrawPlayerHands", "handchams", function()
        end)
	end
    end
	
 	function handchamscheckm1:OnChange(venablestatss)
	if (venablestatss) then
        hook.Add("PreDrawPlayerHands", "handchams", function()
            render.SetColorModulation(1, 1, 1)
            render.MaterialOverride(mat1)
            render.SetBlend(1)
        end)
        hook.Add("PostDrawPlayerHands", "handchams", function()
            render.SetColorModulation(1, 1, 1)
            render.MaterialOverride(Material(""))
            render.SetBlend(1)
        end)
	else
        hook.Add("PreDrawPlayerHands", "handchams", function()
        end)
        hook.Add("PostDrawPlayerHands", "handchams", function()
        end)
	end
    end
	
 	function handchamscheckm2:OnChange(venablestatss)
	if (venablestatss) then
        hook.Add("PreDrawPlayerHands", "handchams", function()
            render.SetColorModulation(1, 1, 1)
            render.MaterialOverride(mat2)
            render.SetBlend(1)
        end)
        hook.Add("PostDrawPlayerHands", "handchams", function()
            render.SetColorModulation(1, 1, 1)
            render.MaterialOverride(Material(""))
            render.SetBlend(1)
        end)
	else
        hook.Add("PreDrawPlayerHands", "handchams", function()
        end)
        hook.Add("PostDrawPlayerHands", "handchams", function()
        end)
	end
    end
	
 	function handchamscheckm3:OnChange(venablestatss)
	if (venablestatss) then
        hook.Add("PreDrawPlayerHands", "handchams", function()
            render.SetColorModulation(0, 1, 1)
            render.MaterialOverride(mat3)
            render.SetBlend(1)
        end)
        hook.Add("PostDrawPlayerHands", "handchams", function()
            render.SetColorModulation(1, 1, 1)
            render.MaterialOverride(Material(""))
            render.SetBlend(1)
        end)
	else
        hook.Add("PreDrawPlayerHands", "handchams", function()
        end)
        hook.Add("PostDrawPlayerHands", "handchams", function()
        end)
	end
    end
	
 	function handchamscheckm4:OnChange(venablestatss)
	if (venablestatss) then
        hook.Add("PreDrawPlayerHands", "handchams", function()
            render.SetColorModulation(1, 1, 1)
            render.MaterialOverride(mat4)
            render.SetBlend(1)
        end)
        hook.Add("PostDrawPlayerHands", "handchams", function()
            render.SetColorModulation(1, 1, 1)
            render.MaterialOverride(Material(""))
            render.SetBlend(1)
        end)
	else
        hook.Add("PreDrawPlayerHands", "handchams", function()
        end)
        hook.Add("PostDrawPlayerHands", "handchams", function()
        end)
	end
    end

 	function handchamscheckm5:OnChange(venablestatss)
	if (venablestatss) then
        hook.Add("PreDrawPlayerHands", "handchams", function()
            render.SetColorModulation(1, 1, 1)
            render.MaterialOverride(mat5)
            render.SetBlend(1)
        end)
        hook.Add("PostDrawPlayerHands", "handchams", function()
            render.SetColorModulation(1, 1, 1)
            render.MaterialOverride(Material(""))
            render.SetBlend(1)
        end)
	else
        hook.Add("PreDrawPlayerHands", "handchams", function()
        end)
        hook.Add("PostDrawPlayerHands", "handchams", function()
        end)
	end
    end
	
 	function handchamscheckm6:OnChange(venablestatss)
	if (venablestatss) then
        hook.Add("PreDrawPlayerHands", "handchams", function()
            render.SetColorModulation(1, 1, 1)
            render.MaterialOverride(mat6)
            render.SetBlend(1)
        end)
        hook.Add("PostDrawPlayerHands", "handchams", function()
            render.SetColorModulation(1, 1, 1)
            render.MaterialOverride(Material(""))
            render.SetBlend(1)
        end)
	else
        hook.Add("PreDrawPlayerHands", "handchams", function()
        end)
        hook.Add("PostDrawPlayerHands", "handchams", function()
        end)
	end
    end
	
 	function handchamscheckm7:OnChange(venablestatss)
	if (venablestatss) then
        hook.Add("PreDrawPlayerHands", "handchams", function()
            render.SetColorModulation(1, 1, 1)
            render.MaterialOverride(mat7)
            render.SetBlend(1)
        end)
        hook.Add("PostDrawPlayerHands", "handchams", function()
            render.SetColorModulation(1, 1, 1)
            render.MaterialOverride(Material(""))
            render.SetBlend(1)
        end)
	else
        hook.Add("PreDrawPlayerHands", "handchams", function()
        end)
        hook.Add("PostDrawPlayerHands", "handchams", function()
        end)
	end
    end

 	function handchamscheckm8:OnChange(venablestatss)
	if (venablestatss) then
        hook.Add("PreDrawPlayerHands", "handchams", function()
            render.SetColorModulation(1, 1, 1)
            render.MaterialOverride(mat8)
            render.SetBlend(1)
        end)
        hook.Add("PostDrawPlayerHands", "handchams", function()
            render.SetColorModulation(1, 1, 1)
            render.MaterialOverride(Material(""))
            render.SetBlend(1)
        end)
	else
        hook.Add("PreDrawPlayerHands", "handchams", function()
        end)
        hook.Add("PostDrawPlayerHands", "handchams", function()
        end)
	end
    end

 	function handchamscheckm9:OnChange(venablestatss)
	if (venablestatss) then
        hook.Add("PreDrawPlayerHands", "handchams", function()
            render.SetColorModulation(1, 1, 1)
            render.MaterialOverride(mat9)
            render.SetBlend(1)
        end)
        hook.Add("PostDrawPlayerHands", "handchams", function()
            render.SetColorModulation(1, 1, 1)
            render.MaterialOverride(Material(""))
            render.SetBlend(1)
        end)
	else
        hook.Add("PreDrawPlayerHands", "handchams", function()
        end)
        hook.Add("PostDrawPlayerHands", "handchams", function()
        end)
	end
    end
	
 	function handchamscheckm10:OnChange(venablestatss)
	if (venablestatss) then
        hook.Add("PreDrawPlayerHands", "handchams", function()
            render.SetColorModulation(1, 1, 1)
            render.MaterialOverride(mat10)
            render.SetBlend(1)
        end)
        hook.Add("PostDrawPlayerHands", "handchams", function()
            render.SetColorModulation(1, 1, 1)
            render.MaterialOverride(Material(""))
            render.SetBlend(1)
        end)
	else
        hook.Add("PreDrawPlayerHands", "handchams", function()
        end)
        hook.Add("PostDrawPlayerHands", "handchams", function()
        end)
	end
    end
	
 	function handchamscheckm11:OnChange(venablestatss)
	if (venablestatss) then
        hook.Add("PreDrawPlayerHands", "handchams", function()
            render.SetColorModulation(1, 1, 1)
            render.MaterialOverride(mat11)
            render.SetBlend(1)
        end)
        hook.Add("PostDrawPlayerHands", "handchams", function()
            render.SetColorModulation(1, 1, 1)
            render.MaterialOverride(Material(""))
            render.SetBlend(1)
        end)
	else
        hook.Add("PreDrawPlayerHands", "handchams", function()
        end)
        hook.Add("PostDrawPlayerHands", "handchams", function()
        end)
	end
    end

 	function handchamscheckm12:OnChange(venablestatss)
	if (venablestatss) then
        hook.Add("PreDrawPlayerHands", "handchams", function()
            render.SetColorModulation(1, 1, 1)
            render.MaterialOverride(mat12)
            render.SetBlend(1)
        end)
        hook.Add("PostDrawPlayerHands", "handchams", function()
            render.SetColorModulation(1, 1, 1)
            render.MaterialOverride(Material(""))
            render.SetBlend(1)
        end)
	else
        hook.Add("PreDrawPlayerHands", "handchams", function()
        end)
        hook.Add("PostDrawPlayerHands", "handchams", function()
        end)
	end
    end
	
 	function handchamscheckm13:OnChange(venablestatss)
	if (venablestatss) then
        hook.Add("PreDrawPlayerHands", "handchams", function()
            render.SetColorModulation(1, 1, 1)
            render.MaterialOverride(mat13)
            render.SetBlend(1)
        end)
        hook.Add("PostDrawPlayerHands", "handchams", function()
            render.SetColorModulation(1, 1, 1)
            render.MaterialOverride(Material(""))
            render.SetBlend(1)
        end)
	else
        hook.Add("PreDrawPlayerHands", "handchams", function()
        end)
        hook.Add("PostDrawPlayerHands", "handchams", function()
        end)
	end
    end
    --Gun Chams
 	function gunchamscheckm0:OnChange(venablestatss)
	if (venablestatss) then
        hook.Add("PreDrawViewModel", "viewmodelchams", function()
            render.SuppressEngineLighting(true)
            render.SetColorModulation(1, 1, 1)
            render.MaterialOverride(mat0)
            render.SetBlend(1)
        end)
        hook.Add("PostDrawViewModel", "viewmodelchams", function()
            render.SetColorModulation(1, 1, 1)
            render.MaterialOverride(Material(""))
            render.SetBlend(1)
            render.SuppressEngineLighting(false)
        end)
	else
        hook.Add("PreDrawViewModel", "viewmodelchams", function()
        end)
        hook.Add("PostDrawViewModel", "viewmodelchams", function()
        end)
	end
    end
 	function gunchamscheckm1:OnChange(venablestatss)
	if (venablestatss) then
        hook.Add("PreDrawViewModel", "viewmodelchams", function()
            render.SuppressEngineLighting(true)
            render.SetColorModulation(1, 1, 1)
            render.MaterialOverride(mat1)
            render.SetBlend(1)
        end)
        hook.Add("PostDrawViewModel", "viewmodelchams", function()
            render.SetColorModulation(1, 1, 1)
            render.MaterialOverride(Material(""))
            render.SetBlend(1)
            render.SuppressEngineLighting(false)
        end)
	else
        hook.Add("PreDrawViewModel", "viewmodelchams", function()
        end)
        hook.Add("PostDrawViewModel", "viewmodelchams", function()
        end)
	end
    end
 	function gunchamscheckm2:OnChange(venablestatss)
	if (venablestatss) then
        hook.Add("PreDrawViewModel", "viewmodelchams", function()
            render.SuppressEngineLighting(true)
            render.SetColorModulation(1, 1, 1)
            render.MaterialOverride(mat2)
            render.SetBlend(1)
        end)
        hook.Add("PostDrawViewModel", "viewmodelchams", function()
            render.SetColorModulation(1, 1, 1)
            render.MaterialOverride(Material(""))
            render.SetBlend(1)
            render.SuppressEngineLighting(false)
        end)
	else
        hook.Add("PreDrawViewModel", "viewmodelchams", function()
        end)
        hook.Add("PostDrawViewModel", "viewmodelchams", function()
        end)
	end
    end
 	function gunchamscheckm3:OnChange(venablestatss)
	if (venablestatss) then
        hook.Add("PreDrawViewModel", "viewmodelchams", function()
            render.SuppressEngineLighting(true)
            render.SetColorModulation(1, 1, 0)
            render.MaterialOverride(mat3)
            render.SetBlend(1)
        end)
        hook.Add("PostDrawViewModel", "viewmodelchams", function()
            render.SetColorModulation(1, 1, 1)
            render.MaterialOverride(Material(""))
            render.SetBlend(1)
            render.SuppressEngineLighting(false)
        end)
	else
        hook.Add("PreDrawViewModel", "viewmodelchams", function()
        end)
        hook.Add("PostDrawViewModel", "viewmodelchams", function()
        end)
	end
    end
 	function gunchamscheckm4:OnChange(venablestatss)
	if (venablestatss) then
        hook.Add("PreDrawViewModel", "viewmodelchams", function()
            render.SuppressEngineLighting(true)
            render.SetColorModulation(1, 1, 1)
            render.MaterialOverride(mat4)
            render.SetBlend(1)
        end)
        hook.Add("PostDrawViewModel", "viewmodelchams", function()
            render.SetColorModulation(1, 1, 1)
            render.MaterialOverride(Material(""))
            render.SetBlend(1)
            render.SuppressEngineLighting(false)
        end)
	else
        hook.Add("PreDrawViewModel", "viewmodelchams", function()
        end)
        hook.Add("PostDrawViewModel", "viewmodelchams", function()
        end)
	end
    end
 	function gunchamscheckm5:OnChange(venablestatss)
	if (venablestatss) then
        hook.Add("PreDrawViewModel", "viewmodelchams", function()
            render.SuppressEngineLighting(true)
            render.SetColorModulation(1, 1, 1)
            render.MaterialOverride(mat5)
            render.SetBlend(1)
        end)
        hook.Add("PostDrawViewModel", "viewmodelchams", function()
            render.SetColorModulation(1, 1, 1)
            render.MaterialOverride(Material(""))
            render.SetBlend(1)
            render.SuppressEngineLighting(false)
        end)
	else
        hook.Add("PreDrawViewModel", "viewmodelchams", function()
        end)
        hook.Add("PostDrawViewModel", "viewmodelchams", function()
        end)
	end
    end
 	function gunchamscheckm6:OnChange(venablestatss)
	if (venablestatss) then
        hook.Add("PreDrawViewModel", "viewmodelchams", function()
            render.SuppressEngineLighting(true)
            render.SetColorModulation(1, 1, 1)
            render.MaterialOverride(mat6)
            render.SetBlend(1)
        end)
        hook.Add("PostDrawViewModel", "viewmodelchams", function()
            render.SetColorModulation(1, 1, 1)
            render.MaterialOverride(Material(""))
            render.SetBlend(1)
            render.SuppressEngineLighting(false)
        end)
	else
        hook.Add("PreDrawViewModel", "viewmodelchams", function()
        end)
        hook.Add("PostDrawViewModel", "viewmodelchams", function()
        end)
	end
    end
 	function gunchamscheckm7:OnChange(venablestatss)
	if (venablestatss) then
        hook.Add("PreDrawViewModel", "viewmodelchams", function()
            render.SuppressEngineLighting(true)
            render.SetColorModulation(1, 1, 1)
            render.MaterialOverride(mat7)
            render.SetBlend(1)
        end)
        hook.Add("PostDrawViewModel", "viewmodelchams", function()
            render.SetColorModulation(1, 1, 1)
            render.MaterialOverride(Material(""))
            render.SetBlend(1)
            render.SuppressEngineLighting(false)
        end)
	else
        hook.Add("PreDrawViewModel", "viewmodelchams", function()
        end)
        hook.Add("PostDrawViewModel", "viewmodelchams", function()
        end)
	end
    end
 	function gunchamscheckm8:OnChange(venablestatss)
	if (venablestatss) then
        hook.Add("PreDrawViewModel", "viewmodelchams", function()
            render.SuppressEngineLighting(true)
            render.SetColorModulation(1, 1, 1)
            render.MaterialOverride(mat8)
            render.SetBlend(1)
        end)
        hook.Add("PostDrawViewModel", "viewmodelchams", function()
            render.SetColorModulation(1, 1, 1)
            render.MaterialOverride(Material(""))
            render.SetBlend(1)
            render.SuppressEngineLighting(false)
        end)
	else
        hook.Add("PreDrawViewModel", "viewmodelchams", function()
        end)
        hook.Add("PostDrawViewModel", "viewmodelchams", function()
        end)
	end
    end
 	function gunchamscheckm9:OnChange(venablestatss)
	if (venablestatss) then
        hook.Add("PreDrawViewModel", "viewmodelchams", function()
            render.SuppressEngineLighting(true)
            render.SetColorModulation(1, 1, 1)
            render.MaterialOverride(mat9)
            render.SetBlend(1)
        end)
        hook.Add("PostDrawViewModel", "viewmodelchams", function()
            render.SetColorModulation(1, 1, 1)
            render.MaterialOverride(Material(""))
            render.SetBlend(1)
            render.SuppressEngineLighting(false)
        end)
	else
        hook.Add("PreDrawViewModel", "viewmodelchams", function()
        end)
        hook.Add("PostDrawViewModel", "viewmodelchams", function()
        end)
	end
    end
 	function gunchamscheckm10:OnChange(venablestatss)
	if (venablestatss) then
        hook.Add("PreDrawViewModel", "viewmodelchams", function()
            render.SuppressEngineLighting(true)
            render.SetColorModulation(1, 1, 1)
            render.MaterialOverride(mat10)
            render.SetBlend(1)
        end)
        hook.Add("PostDrawViewModel", "viewmodelchams", function()
            render.SetColorModulation(1, 1, 1)
            render.MaterialOverride(Material(""))
            render.SetBlend(1)
            render.SuppressEngineLighting(false)
        end)
	else
        hook.Add("PreDrawViewModel", "viewmodelchams", function()
        end)
        hook.Add("PostDrawViewModel", "viewmodelchams", function()
        end)
	end
    end
 	function gunchamscheckm11:OnChange(venablestatss)
	if (venablestatss) then
        hook.Add("PreDrawViewModel", "viewmodelchams", function()
            render.SuppressEngineLighting(true)
            render.SetColorModulation(1, 1, 1)
            render.MaterialOverride(mat11)
            render.SetBlend(1)
        end)
        hook.Add("PostDrawViewModel", "viewmodelchams", function()
            render.SetColorModulation(1, 1, 1)
            render.MaterialOverride(Material(""))
            render.SetBlend(1)
            render.SuppressEngineLighting(false)
        end)
	else
        hook.Add("PreDrawViewModel", "viewmodelchams", function()
        end)
        hook.Add("PostDrawViewModel", "viewmodelchams", function()
        end)
	end
    end
 	function gunchamscheckm12:OnChange(venablestatss)
	if (venablestatss) then
        hook.Add("PreDrawViewModel", "viewmodelchams", function()
            render.SuppressEngineLighting(true)
            render.SetColorModulation(1, 1, 1)
            render.MaterialOverride(mat12)
            render.SetBlend(1)
        end)
        hook.Add("PostDrawViewModel", "viewmodelchams", function()
            render.SetColorModulation(1, 1, 1)
            render.MaterialOverride(Material(""))
            render.SetBlend(1)
            render.SuppressEngineLighting(false)
        end)
	else
        hook.Add("PreDrawViewModel", "viewmodelchams", function()
        end)
        hook.Add("PostDrawViewModel", "viewmodelchams", function()
        end)
	end
    end
 	function gunchamscheckm13:OnChange(venablestatss)
	if (venablestatss) then
        hook.Add("PreDrawViewModel", "viewmodelchams", function()
            render.SuppressEngineLighting(true)
            render.SetColorModulation(1, 1, 1)
            render.MaterialOverride(mat13)
            render.SetBlend(1)
        end)
        hook.Add("PostDrawViewModel", "viewmodelchams", function()
            render.SetColorModulation(1, 1, 1)
            render.MaterialOverride(Material(""))
            render.SetBlend(1)
            render.SuppressEngineLighting(false)
        end)
	else
        hook.Add("PreDrawViewModel", "viewmodelchams", function()
        end)
        hook.Add("PostDrawViewModel", "viewmodelchams", function()
        end)
	end
    end
----------------------------------------------------------------------------------------------------------------------
	function venableline:OnChange(venableliner)
	if (venableliner) then
        hook.Add( "HUDPaint", "VEableRLine", function()

	        DrawChromaLine( 100, "____________________________________________________________________________________________________________________________________________________________________________________________________________", "CloseCaption_Bold", 0, -23 )
	        DrawChromaLine( 100, "____________________________________________________________________________________________________________________________________________________________________________________________________________", "CloseCaption_Bold", 0, -23 )

        end )
	else
        hook.Add( "HUDPaint", "VEableRLine", function()           
            draw.SimpleText( "", "TargetID", 0, 0, color_white )
        end )
	end
	end
	
	function venablestats:OnChange(venablestatss)
	if (venablestatss) then
        hook.Add( "HUDPaint", "VEnableStats", function()
            --DrawChromaLine( 100, "Chalk Anarchy", "TargetID", 5, 5 )
	        DrawChromaLine( 100, "__________", "CloseCaption_Bold", 10, 477 )
	        DrawChromaLine( 100, "__________", "CloseCaption_Bold", 10, 478 )
            draw.RoundedBox( 0, 10, 503, ScrW() / 9.8, ScrH() / 60, Color(35,35,35,255))
            DrawChromaLine( 100, "Stats", "HudHintTextLarge", 55, 503 )
            surface.SetDrawColor(10,10,10,150)
            surface.DrawRect(10, 520, ScrW() / 9.8, ScrH() / 12)
            draw.SimpleText( "Ping", "TargetID", 15, 520, color_white )
	        draw.SimpleText( ply:Ping(), "TargetID", 100, 520, color_white )
            --FPS
            draw.SimpleText( "FPS", "TargetID", 15, 540, color_white )
	        draw.SimpleText( cur_fps, "TargetID", 100, 540, color_white ) 
	        --Frags
            draw.SimpleText( "Frags", "TargetID", 15, 560, color_white )
	        draw.SimpleText( ply:Frags(), "TargetID", 100, 560, color_white ) 
	        --Deaths
            draw.SimpleText( "Deaths", "TargetID", 15, 580, color_white )
	        draw.SimpleText( ply:Deaths(), "TargetID", 100, 580, color_white )
        end )
	else
        hook.Add( "HUDPaint", "VEnableStats", function()           
            draw.SimpleText( "", "TargetID", 0, 0, color_white )
        end )
	end
    end
	
	function venablewatermark:OnChange(venablewatermarker)
	if (venablewatermarker) then
        hook.Add( "HUDPaint", "VEableRWatermark", function()
		
            draw.RoundedBox( 0, 900, 15, 375, 25, Color(35,35,35,200))  
            draw.RoundedBox( 0, 900, 12, 375, 3, Color(102,102,255,230)) 
            draw.SimpleText( ply:Name() .. " Ping: " .. ply:Ping() .. " FPS: " .. cur_fps, "TargetID", 1025, 17, color_white )		
            DrawChromaLine(100, "252552252525", "ChatFont", 905, 17 )				
		
        end )
	else
        hook.Add( "HUDPaint", "VEableRWatermark", function()           

        end )
	end
	end
	
	function venablewatermark2:OnChange(venablewatermark2r)
	if (venablewatermark2r) then	
	
	        local a,b,c,d,e=LocalPlayer(),ply:Name(),engine.ActiveGamemode(),GetHostName(),math.Round(1/engine.TickInterval()-1)
		    local textw="Havoc | "..b.." | "..c.." | "..d.." | "..a:Ping().."ms | "..e.."tick"
			surface.CreateFont("Havoc",{font="Roboto",size=20})
            local polymark = {
	        { x = 25, y = 25 },
           	{ x = 530, y = 25 },
	        { x = 550, y = 85 },
	        { x = 45, y = 85 },
            }

            local polymarkred = {
	        { x = 35, y = 30 },
           	{ x = 525, y = 30 },
	        { x = 540, y = 80 },
	        { x = 50, y = 80 },
            }
			
            local polymark2 = {
	        { x = 45, y = 35 },
           	{ x = 520, y = 35 },
	        { x = 530, y = 75 },
	        { x = 55, y = 75 },
            }			
		
			hook.Add("HUDPaint", "PolygonWatermark", function()
	            surface.SetDrawColor( 25, 25, 25, 200 )
	            draw.NoTexture()
	            surface.DrawPoly( polymark )
				surface.SetDrawColor( 255, 15, 15, 200 )
	            draw.NoTexture()
	            surface.DrawPoly( polymarkred )
				surface.SetDrawColor( 15, 15, 15, 255 )
	            draw.NoTexture()
	            surface.DrawPoly( polymark2 )
				draw.SimpleText(textw,"Havoc",55,45,color_white)
				local warnmat = Material( "icon16/exclamation.png" )
				surface.SetDrawColor( 255, 255, 255, 255 ) -- Set the drawing color
	            surface.SetMaterial( warnmat ) -- Use our cached material
	            surface.DrawTexturedRect( 485, 39, 32, 32 ) -- Actually draw the rectangle
            end )

	else
        hook.Add( "HUDPaint", "PolygonWatermark", function()           

        end )
	end
	end

	function servertickrate:OnChange(servertickratee)
	if (servertickratee) then
        hook.Add( "HUDPaint", "VEnableTick", function()
		
            draw.SimpleText( "Tick: " .. math.Round(1/engine.TickInterval()-1), "ChalkAnarchyIndicators", 15, 730, color_white )
            
        end )
	else
        hook.Add( "HUDPaint", "VEnableTick", function()           
            draw.SimpleText( "", "TargetID", 0, 0, color_white )
        end )
	end
	end

	function pingindicator:OnChange(pingindicatorr)
	if (pingindicatorr) then
        hook.Add( "HUDPaint", "VEableRPingInd", function()
		
            draw.SimpleText( "Ping: " .. ply:Ping(), "ChalkAnarchyIndicators", 15, 700, onegreen )
            if ply:Ping() > 35 then		
                draw.SimpleText( "Ping: " .. ply:Ping(), "ChalkAnarchyIndicators", 15, 700, twogreen )
            end	
            if ply:Ping() > 55 then		
                draw.SimpleText( "Ping: " .. ply:Ping(), "ChalkAnarchyIndicators", 15, 700, threegreen )
            end	
            if ply:Ping() > 75 then		
                draw.SimpleText( "Ping: " .. ply:Ping(), "ChalkAnarchyIndicators", 15, 700, oneyellow )
            end	
            if ply:Ping() > 90 then		
                draw.SimpleText( "Ping: " .. ply:Ping(), "ChalkAnarchyIndicators", 15, 700, oneorange )
            end	
            if ply:Ping() > 120 then		
                draw.SimpleText( "Ping: " .. ply:Ping(), "ChalkAnarchyIndicators", 15, 700, twoorange )
            end	
            if ply:Ping() > 150 then		
                draw.SimpleText( "Ping: " .. ply:Ping(), "ChalkAnarchyIndicators", 15, 700, onered )
            end	
            if ply:Ping() > 180 then		
                draw.SimpleText( "Ping: " .. ply:Ping(), "ChalkAnarchyIndicators", 15, 700, twored )
            end	
            if ply:Ping() > 210 then		
                draw.SimpleText( "Ping: " .. ply:Ping(), "ChalkAnarchyIndicators", 15, 700, naxred )
            end	
        end )
	else
        hook.Add( "HUDPaint", "VEableRPingInd", function()           
            draw.SimpleText( "", "TargetID", 0, 0, color_white )
        end )
	end
	end
----------------------------------------------------------------------------------------------------------------------------------------------------
local weaponparams = {
    ["$basetexture"] = "sprites/physbeam",
    ["$nodecal"] = 1,
    ["$model"] = 1,
    ["$additive"] = 1,
    ["$nocull"] = 1,
    Proxies = {
        TextureScroll = {
            texturescrollvar = "$basetexturetransform",
            texturescrollrate = 0.4,
            texturescrollangle = 70,
        }
    }
}
 
local armparams = {
    ["$basetexture"] = "models/inventory_items/dreamhack_trophies/dreamhack_star_blur",
    ["$nodecal"] = 1,
    ["$model"] = 1,
    ["$additive"] = 1,
    ["$nocull"] = 1,
    Proxies = {
        TextureScroll = {
            texturescrollvar = "$basetexturetransform",
            texturescrollrate = 0.2,
            texturescrollangle = 50,
        }
    }
}
 
 
local IsDrawingGlow = false
local Glow = CreateMaterial("edgeglow","UnlitGeneric",weaponparams)
local GlowTwo = CreateMaterial("edgeglow2","UnlitGeneric", armparams)
----------------------------------------------------------------------------------------------------------------------------------------------------
	local DLabel = vgui.Create( "DLabel", tab1panel )
    DLabel:SetPos( 317, 125 )
    DLabel:SetColor(Color(255, 220, 0))
    DLabel:SetText( "Second mat.:" )
------------------------------------------------------------------------------------------------------------------------	
    local secondarmmat = tab1panel:Add( "DCheckBoxLabel", tab1panel ) 
    secondarmmat:SetPos( 315, 145 ) 
    secondarmmat:SetValue( false ) 
	secondarmmat:SetText( "Enable" )
    secondarmmat:SizeToContents()

	function secondarmmat:OnChange(secondarmmatt)
	if (secondarmmatt) then
        hook.Add("PreDrawPlayerHands", "handtwocolored", function()
		    render.SuppressEngineLighting(true)
			if IsDrawingGlow then
			    render.SetColorModulation(1, 0, 0)
                render.MaterialOverride(GlowTwo)
			else
			    render.SetColorModulation(1, 1, 1)
			end
			render.SetBlend(1)
		end)
		
		hook.Add("PostDrawPlayerHands", "handtwocolored", function()
		    render.SetColorModulation(1, 1, 1)
            render.MaterialOverride(None)
            render.SetBlend(1)
 
            if IsDrawingGlow then return end
 
            IsDrawingGlow = true
            LocalPlayer():GetViewModel():DrawModel()
            IsDrawingGlow = false
		end)		
	else
        hook.Remove("PreDrawPlayerHands", "handtwocolored")
        hook.Remove("PostDrawPlayerHands", "handtwocolored")
	end
	end
    --Gun Two Colored Glow
----------------------------------------------------------------------------------------------------------------------------------------------------
	local DLabel = vgui.Create( "DLabel", tab1panel )
    DLabel:SetPos( 225, 375 )
    DLabel:SetColor(Color(255, 220, 0))
    DLabel:SetText( "Second mat.:" )


    local DermaImageButton = vgui.Create( "DImageButton", tab1panel )
    DermaImageButton:SetPos( 280, 395 )					
    DermaImageButton:SetImage( "icon16/bullet_error.png" )	
    DermaImageButton:SizeToContents()				
    DermaImageButton.DoClick = function()
	    chat.AddText( Color(255,0,0), "Will not work without hand second mat!!" )
    end	
------------------------------------------------------------------------------------------------------------------------	
    local secondgunmat = tab1panel:Add( "DCheckBoxLabel", tab1panel ) 
    secondgunmat:SetPos( 222, 395 ) 
    secondgunmat:SetValue( false ) 
	secondgunmat:SetText( "Enable" )
    secondgunmat:SizeToContents()

	function secondgunmat:OnChange(secondgunmatt)
	if (secondgunmatt) then
        hook.Add("PreDrawViewModel", "guntwocoloredone", function()
		    render.SuppressEngineLighting(true)
			if IsDrawingGlow then
			    render.SetColorModulation(1, 0, 0)
                render.MaterialOverride(Glow)
			else
			    render.SetColorModulation(1, 1, 1)
			end
			render.SetBlend(1)
		end)
		
		hook.Add("PostDrawViewModel", "guntwocoloredp", function()
		    render.SetColorModulation(1, 1, 1)
            if IsDrawingGlow then
            render.MaterialOverride(None)
			render.SetBlend(1)
			render.SuppressEngineLighting(false)
			
			if IsDrawingGlow then return end
			
			IsDrawingGlow = true
			LocalPlayer():GetViewModel():DrawModel()
			IsDrawingGlow = false
			
			end
		end)		
	else
        hook.Remove("PreDrawViewModel", "guntwocoloredone")
        hook.Remove("PostDrawViewModel", "guntwocoloredp")
	end
	end
----------------------------------------------------------------------------------------------------------------------------------------------------
	local DLabel = vgui.Create( "DLabel", tab1panel )
    DLabel:SetPos( 310, 375 )
    DLabel:SetColor(Color(255, 0, 0))
    DLabel:SetText( "Engine:" )
	
    local enginelighting = tab1panel:Add( "DCheckBoxLabel", tab1panel ) 
    enginelighting:SetPos( 320, 395 ) 
    enginelighting:SetValue( false ) 
	enginelighting:SetText( "Supress" )
    enginelighting:SizeToContents()
	
	function enginelighting:OnChange(enginelightingg)
	if (enginelightingg) then
        hook.Add("PreDrawViewModel", "supresslighting", function()
		    render.SuppressEngineLighting(true)
			render.SetColorModulation(1, 1, 1)
            render.MaterialOverride(none)
			render.SetColorModulation(1, 1, 1)
			render.SetBlend(1)
		end)
		
		hook.Add("PostDrawViewModel", "supresslighting", function()
		    render.SetColorModulation(1, 1, 1)
            render.MaterialOverride(None)
            render.SetBlend(1)
		end)		
        hook.Add("PreDrawPlayerHands", "supresslighting", function()
		    render.SuppressEngineLighting(true)
			render.SetColorModulation(1, 1, 1)
            render.MaterialOverride(none)
			render.SetBlend(1)
		end)
		
		hook.Add("PostDrawPlayerHands", "supresslighting", function()
		    render.SetColorModulation(1, 1, 1)
            render.MaterialOverride(None)
            render.SetBlend(1)
		end)	
	else
        hook.Remove("PreDrawPlayerHands", "supresslighting")
        hook.Remove("PostDrawPlayerHands", "supresslighting")
        hook.Remove("PreDrawPlayerHands", "supresslighting")
        hook.Remove("PostDrawPlayerHands", "supresslighting")
	end
	end	
----------------------------------------------------------------------------------------------------------------------------------------------------
    local enable3dbox = tab1panel:Add( "DCheckBoxLabel", tab1panel) 
    enable3dbox:SetPos( 430, 240 ) 
    enable3dbox:SetValue( false ) 
	enable3dbox:SetText( "3D BOX" )
    enable3dbox:SizeToContents()
	



    function enable3dbox:OnChange(enable3dboxx)
	if (enable3dboxx) then
        local boxBorder = team.GetColor(ply:Team())
        hook.Add("PostDrawOpaqueRenderables", "x", function()
            cam.Start3D()
                if true then
                    for k,ply in ipairs(player.GetAll()) do
                        if ply == LocalPlayer() then goto skip end
                        local pos = ply:GetPos()
                        local ang = ply:GetAngles()
                        local mins = ply:OBBMins()
                        local maxs = ply:OBBMaxs()
                        --render.ClearDepth()
                        render.SetColorMaterial()
 
                        local teamCol = Color(0, 0, 0) --or team.GetColor(ply:Team())
                        teamCol.a = 90
                        render.DrawBox(pos,ang,mins,maxs, teamCol)
 
                        mins = pos + mins
                        maxs = pos + maxs
 
                        local b1 = Vector(mins.x, mins.y, mins.z)
                        local b2 = Vector(maxs.x, mins.y, mins.z)
                        local b3 = Vector(maxs.x, maxs.y, mins.z)
                        local b4 = Vector(mins.x, maxs.y, mins.z)
 
                        render.DrawLine(b1, b2, boxBorder)
                        render.DrawLine(b2, b3, boxBorder)
                        render.DrawLine(b3, b4, boxBorder)
                        render.DrawLine(b1, b4, boxBorder)
 
                        local t1 = Vector(mins.x, mins.y, maxs.z)
                        local t2 = Vector(maxs.x, mins.y, maxs.z)
                        local t3 = Vector(maxs.x, maxs.y, maxs.z)
                        local t4 = Vector(mins.x, maxs.y, maxs.z)
 
                        render.DrawLine(t1, t2, boxBorder)
                        render.DrawLine(t2, t3, boxBorder)
                        render.DrawLine(t3, t4, boxBorder)
                        render.DrawLine(t1, t4, boxBorder)
 
                        render.DrawLine(t1, b1, boxBorder)
                        render.DrawLine(t2, b2, boxBorder)
                        render.DrawLine(t3, b3, boxBorder)
                        render.DrawLine(t4, b4, boxBorder)
                        ::skip::
                    end
            
                end
            cam.End3D()
        end)
	else
        hook.Add("PostDrawOpaqueRenderables", "x", function()
  
        end)
	end
	end	
	
   --ESP
   
    local nameespenable = tab1panel:Add( "DCheckBoxLabel", tab1panel) 
    nameespenable:SetPos( 500, 240 ) 
    nameespenable:SetValue( false ) 
	nameespenable:SetText( "Name" )
    nameespenable:SizeToContents()
	
	function nameespenable:OnChange(nameespenablee)
	if (nameespenablee) then
        hook.Add("HUDPaint", "ESP", function ()
 
	        for k, v in pairs(player.GetAll()) do
		
		        if v == LocalPlayer() then continue end -- if the loop finds the localplayer which is you then it will not set a text for you
		        if (v:Alive()) then -- finds out if the player is Alive
 
			    local plypos = v:GetPos() -- gets player position
			    plypos = plypos:ToScreen() -- puts the text in the 3d world
 
		     	surface.SetTextColor( 255, 255, 255, 232) -- Set text color. you can make this any color you want. 	
		    	surface.SetTextPos( plypos.x, plypos.y ) -- Set text position to the player
		    	surface.SetFont( "Default" ) -- Set the font
		    	surface.DrawText( v:Name() ) -- Gets the name of the player and puts it as the text
 
		    end 
	    end
        end)       
	else
    hook.Add("HUDPaint", "ESP", function ()
		
    end)
	end
	end	

    local teambutton = tab1panel:Add( "DCheckBoxLabel", tab1panel) 
    teambutton:SetPos( 500, 260 ) 
    teambutton:SetValue( false ) 
	teambutton:SetText( "Team" )
    teambutton:SizeToContents()
	
	function teambutton:OnChange(teambuttonn)
	if (teambuttonn) then
        hook.Add("HUDPaint", "ESP_Team", function ()
 
	        for k, v in pairs(player.GetAll()) do
		
		        if v == LocalPlayer() then continue end -- if the loop finds the localplayer which is you then it will not set a text for you
		        if (v:Alive()) then -- finds out if the player is Alive
 
			    local plypos = v:GetPos() -- gets player position
			    plypos = plypos:ToScreen() -- puts the text in the 3d world
 
		     	surface.SetTextColor(team.GetColor(ply:Team())) -- Set text color. you can make this any color you want. 	
		    	surface.SetTextPos( plypos.x - 25, plypos.y ) -- Set text position to the player
		    	surface.SetFont( "Default" ) -- Set the font
		    	surface.DrawText( v:Team() ) -- Gets the name of the player and puts it as the text
 
		    end 
	    end
        end)       
	else
    hook.Add("HUDPaint", "ESP_Team", function ()
		
    end)
	end
	end	

    local healthespenable = tab1panel:Add( "DCheckBoxLabel", tab1panel) 
    healthespenable:SetPos( 555, 240 ) 
    healthespenable:SetValue( false ) 
	healthespenable:SetText( "Health" )
    healthespenable:SizeToContents()
	
	function healthespenable:OnChange(healthespenablee)
	if (healthespenablee) then
        hook.Add("HUDPaint", "ESP_Health", function ()
 
	        for k, v in pairs(player.GetAll()) do
		
		        if v == LocalPlayer() then continue end -- if the loop finds the localplayer which is you then it will not set a text for you
		        if (v:Alive()) then -- finds out if the player is Alive
 
			    local plypos = v:GetPos() -- gets player position
			    plypos = plypos:ToScreen() -- puts the text in the 3d world
 
		     	surface.SetTextColor( 0, 255, 0, 232) -- Set text color. you can make this any color you want. 	
		    	surface.SetTextPos( plypos.x, plypos.y +6 ) -- Set text position to the player
		    	surface.SetFont( "Default" ) -- Set the font
		    	surface.DrawText( v:Health() ) -- Gets the name of the player and puts it as the text
 
		    end 
	    end
        end)       
	else
    hook.Add("HUDPaint", "ESP_Health", function ()
		
    end)
	end
	end
   
    local armorespenable = tab1panel:Add( "DCheckBoxLabel", tab1panel) 
    armorespenable:SetPos( 615, 240 ) 
    armorespenable:SetValue( false ) 
	armorespenable:SetText( "Armor" )
    armorespenable:SizeToContents()
	
	function armorespenable:OnChange(armorespenablee)
	if (armorespenablee) then
        hook.Add("HUDPaint", "ESP_Armor", function ()
 
	        for k, v in pairs(player.GetAll()) do
		
		        if v == LocalPlayer() then continue end -- if the loop finds the localplayer which is you then it will not set a text for you
		        if (v:Alive()) then -- finds out if the player is Alive
 
			    local plypos = v:GetPos() -- gets player position
			    plypos = plypos:ToScreen() -- puts the text in the 3d world
 
		     	surface.SetTextColor( 0, 0, 255, 232) -- Set text color. you can make this any color you want. 	
		    	surface.SetTextPos( plypos.x, plypos.y +12 ) -- Set text position to the player
		    	surface.SetFont( "Default" ) -- Set the font
		    	surface.DrawText( v:Armor() ) -- Gets the name of the player and puts it as the text
 
		    end 
	    end
        end)       
	else
    hook.Add("HUDPaint", "ESP_Armor", function ()
		
    end)
	end
	end

    local groupespenable = tab1panel:Add( "DCheckBoxLabel", tab1panel) 
    groupespenable:SetPos( 430, 260 ) 
    groupespenable:SetValue( false ) 
	groupespenable:SetText( "Group" )
    groupespenable:SizeToContents()
	
	function groupespenable:OnChange(groupespenablee)
	if (groupespenablee) then
        hook.Add("HUDPaint", "ESP_Group", function ()
 
	        for k, v in pairs(player.GetAll()) do
		
		        if v == LocalPlayer() then continue end -- if the loop finds the localplayer which is you then it will not set a text for you
		        if (v:Alive()) then -- finds out if the player is Alive
 
			    local plypos = v:GetPos() -- gets player position
			    plypos = plypos:ToScreen() -- puts the text in the 3d world
 
		     	surface.SetTextColor( 255, 100, 100, 232) -- Set text color. you can make this any color you want. 	
		    	surface.SetTextPos( plypos.x, plypos.y +18 ) -- Set text position to the player
		    	surface.SetFont( "Default" ) -- Set the font
		    	surface.DrawText( v:GetUserGroup() ) -- Gets the name of the player and puts it as the text
 
		    end 
	    end
        end)       
	else
    hook.Add("HUDPaint", "ESP_Group", function ()
		
    end)
	end
	end
	
	local weaponpenable = tab1panel:Add( "DCheckBoxLabel", tab1panel) 
    weaponpenable:SetPos( 430, 280 ) 
    weaponpenable:SetValue( false ) 
	weaponpenable:SetText( "Weapon(lag)" )
    weaponpenable:SizeToContents()
	
	function weaponpenable:OnChange(weaponpenablee)
	if (weaponpenablee) then
        hook.Add("HUDPaint", "ESP_Weapon", function ()
 
	        for k, v in pairs(player.GetAll()) do
		
		        if v == LocalPlayer() then continue end 
		        if (v:Alive()) then 
 
			    local plypos = v:GetPos() 
			    plypos = plypos:ToScreen() 
                 
		     	surface.SetTextColor( 255, 100, 100, 232)
		    	surface.SetTextPos( plypos.x, plypos.y +24 ) 
		    	surface.SetFont( "Default" ) 
		    	surface.DrawText( v:GetActiveWeapon().PrintName )
		    end 
	    end
        end)       
	else
    hook.Add("HUDPaint", "ESP_Weapon", function ()	
    end)
	end
	end
	
	local pingesp = tab1panel:Add( "DCheckBoxLabel", tab1panel) 
    pingesp:SetPos( 520, 280 ) 
    pingesp:SetValue( false ) 
	pingesp:SetText( "Ping" )
    pingesp:SizeToContents()
	
	function pingesp:OnChange(pingespe)
	if (pingespe) then
        hook.Add("HUDPaint", "ESP_Ping", function ()
 
	        for k, v in pairs(player.GetAll()) do
		
		        if v == LocalPlayer() then continue end 
		        if (v:Alive()) then 
 
			    local plypos = v:GetPos() 
			    plypos = plypos:ToScreen() 
                 
		     	surface.SetTextColor( 255, 0, 0, 255)
		    	surface.SetTextPos( plypos.x - 10, plypos.y -10 ) 
		    	surface.SetFont( "Default" ) 
		    	surface.DrawText( v:Ping() .. "Ping" )
		    end 
	    end
        end)       
	else
    hook.Add("HUDPaint", "ESP_Ping`", function ()	
    end)
	end
	end


	
    local freecamenabler = tab1panel:Add( "DCheckBoxLabel", tab1panel) 
    freecamenabler:SetPos( 15, 395 ) 
    freecamenabler:SetValue( false ) 
	freecamenabler:SetText( "Free Cam" )
    freecamenabler:SizeToContents()
	
	local DLabel = vgui.Create( "DLabel", tab1panel )
    DLabel:SetPos( 15, 375 )
    DLabel:SetColor(Color(255, 0, 0))
    DLabel:SetText( "View:" )
	
	local DLabel = vgui.Create( "DLabel", tab1panel )
    DLabel:SetPos( 90, 393 )
    DLabel:SetColor(Color(255, 200, 0))
    DLabel:SetText( "(V)" )

    local toplayertracer = tab1panel:Add( "DCheckBoxLabel", tab1panel) 
    toplayertracer:SetPos( 430, 35 ) 
    toplayertracer:SetValue( false ) 
	toplayertracer:SetText( "Enemy Tracer" )
    toplayertracer:SizeToContents()	
--------------------------------------------------------------------------------------------------------------
	function toplayertracer:OnChange(toplayertracerr)
	if (toplayertracerr) then
        local time = 10
        local width = 6

        local ENTITY = FindMetaTable("Entity") --me
        local _GetPos = ENTITY.GetPos
        local CurTime = CurTime
        local table_insert = table.insert
        local table_remove = table.remove
        local cam_Start3D, cam_End3D = cam.Start3D, cam.End3D
        local render_SetMaterial = render.SetMaterial
        local render_DrawBeam = render.DrawBeam
        local ipairs = ipairs
        local IsValid = IsValid
        local Player = Player
        local traces = {}
        local optimize_tbl = {}
        local LocalPlayer = LocalPlayer()
        local offset = Vector(0, 0, 50)
        local color_enemylaser = Color(255, 255, 0)

        gameevent.Listen("player_hurt")
        hook.Add("player_hurt", "player_hurttracer", function(tbl)
            local target = Player(tbl.userid or 0)
            if target ~= LocalPlayer then return end

            local attacker = Player(tbl.attacker or 0)
            if not IsValid(attacker) then return end
    
            if optimize_tbl[attacker] then
                table_remove(traces, optimize_tbl[attacker])
            end
    
            local trace = {}
            trace.time = CurTime() + time
            trace.startpos = _GetPos(attacker) + offset
            trace.endpos = _GetPos(target) + offset
            trace.attacker = attacker
        
            optimize_tbl[attacker] = table_insert(traces, trace)
        end)


        local mat = Material("sprites/physbeama")

        hook.Add("PreDrawEffects", "predrawtracer", function()
            for i = #traces, 1, -1 do
            local trace = traces[i]
        
            if trace.time < CurTime() then
                table_remove(traces, i)
                optimize_tbl[trace.attacker] = nil
                continue
            end
        
            local startpos = trace.startpos
            local endpos = trace.endpos
        
            cam_Start3D()
                render_SetMaterial(mat)
                render_DrawBeam(startpos, endpos, width, 1, 1, color_enemylaser)
            cam_End3D()
        end
    end)       
	else
        hook.Add("PreDrawEffects", "predrawtracer", function()
        end)
	    hook.Add("player_hurt", "player_hurttracer", function()
        end)
	end
	end	
	
    local outlayertracer = tab1panel:Add( "DCheckBoxLabel", tab1panel) 
    outlayertracer:SetPos( 430, 55 ) 
    outlayertracer:SetValue( false ) 
	outlayertracer:SetText( "Dmg Tracer" )
    outlayertracer:SizeToContents()	
--------------------------------------------------------------------------------------------------------------
	function outlayertracer:OnChange(outlayertracerr)
	if (outlayertracerr) then --insert
	    local mat = Material("sprites/physbeama")
        tracerTable = {}
        hook.Add("PreDrawOpaqueRenderables", "DrawTracerBeam", function ()
                for k,v in next, tracerTable do
                if(v[3] <= 0) then
                    table.remove(tracerTable, k);
                    continue;
                end
                tracerTable[k][3] = tracerTable[k][3] - FrameTime();
                local pos1, pos2 = v[1], v[2];
                cam.Start3D();
                render.SetMaterial(mat)
                render.DrawBeam(v[1], v[2], 6, 1, 1, v[4])
                cam.End3D();
            end
        end)
		hook.Add("PlayerTraceAttack", "BulletTracer", function (ent, dmg, dir, trace)
            if(!IsFirstTimePredicted()) then return; end --me
 
            local vHitPos, vSrc;
            vHitPos = trace.HitPos;
            vSrc = trace.StartPos;
 
            table.insert(tracerTable, {vHitPos, vSrc, 5, Color(0, 255, 0), ply:EyeAngles()});
            --table.insert(hitmarkerTable, {vHitPos, 1})
        end)
	else
        hook.Add("PreDrawOpaqueRenderables", "DrawTracerBeam", function()
        end)
	    hook.Add("PlayerTraceAttack", "BulletTracer", function()
        end)
	end
	end	
	
    local hitmarkers = tab1panel:Add( "DCheckBoxLabel", tab1panel) 
    hitmarkers:SetPos( 510, 55 ) 
    hitmarkers:SetValue( false ) 
	hitmarkers:SetText( "Hit Marker" )
    hitmarkers:SizeToContents()	
	
	--[[function hitmarkers:OnChange(hitmarkerss)
	if (hitmarkerss) then 
	    local mat = Material("sprites/physbeama")
        tracerTable = {}
        hook.Add("PreDrawOpaqueRenderables", "DrawTracerBeam", function ()
                for k,v in next, tracerTable do
                if(v[3] <= 0) then
                    table.remove(tracerTable, k);
                    continue;
                end
                tracerTable[k][3] = tracerTable[k][3] - FrameTime();
                local pos1, pos2 = v[1], v[2];
                cam.Start3D();
                render.SetMaterial(mat)
                render.DrawBeam(v[1], v[2], 6, 1, 1, v[4])
                cam.End3D();
            end
        end)
		hook.Add("PlayerTraceAttack", "BulletTracer", function (ent, dmg, dir, trace)
            if(!IsFirstTimePredicted()) then return; end --me
 
            local vHitPos, vSrc;
            vHitPos = trace.HitPos;
            vSrc = trace.StartPos;
 
            table.insert(tracerTable, {vHitPos, vSrc, 5, Color(0, 0, 255), ply:EyeAngles()});
            --table.insert(hitmarkerTable, {vHitPos, 1})
        end)
	else
        hook.Add("PreDrawOpaqueRenderables", "DrawTracerBeam", function()
        end)
	    hook.Add("PlayerTraceAttack", "BulletTracer", function()
        end)
	end
	end	]]
--------------------------------------------------------------------------------------------------------------	
	local DLabel = vgui.Create( "DLabel", tab1panel )
    DLabel:SetPos( 430, 295 )
    DLabel:SetColor(Color(255, 255, 0))
    DLabel:SetText( "2D-ESP:" )
	
--------------------------------------------------------------------------------------------------------------

	local fullbrightbox = tab1panel:Add( "DCheckBoxLabel", tab1panel) 
    fullbrightbox:SetPos( 430, 75 ) 
    fullbrightbox:SetValue( false ) 
	fullbrightbox:SetText( "Fullbright" )
    fullbrightbox:SizeToContents()	
	
	function fullbrightbox:OnChange(fullbrightboxx)
	if (fullbrightboxx) then 
	local LightingModeChanged = false
    hook.Add( "PreRender", "fullbright", function()
    	render.SetLightingMode( 1 )
    	LightingModeChanged = true
    end )

    local function EndOfLightingMod()
	    if LightingModeChanged then
		    render.SetLightingMode( 0 )
		    LightingModeChanged = false
	    end
    end
    hook.Add( "PostRender", "fullbright", EndOfLightingMod )
    hook.Add( "PreDrawHUD", "fullbright", EndOfLightingMod )
	else
	local LightingModeChanged = true
    hook.Add( "PreRender", "fullbright", function()
    	render.SetLightingMode( 0 )
    	LightingModeChanged = false
    end )

    local function EndOfLightingMod()
	    if LightingModeChanged then
		    render.SetLightingMode( 1 )
		    LightingModeChanged = true
	    end
    end
    hook.Add( "PostRender", "fullbright", EndOfLightingMod )
    hook.Add( "PreDrawHUD", "fullbright", EndOfLightingMod )
	end
	end		

--------------------------------------------------------------------------------------------------------------
	function freecamenabler:OnChange(freecamenablerr)
	if (freecamenablerr) then
        freecamAngles = Angle()
        freecamAngles2 = Angle()
        freecamPos = Vector()
        freecamEnabled = false
        freecamSpeed = 3
        keyPressed = false
	  
        hook.Add("CreateMove", "lock_movement", function(ucmd)
            if(freecamEnabled) then
                ucmd:SetSideMove(0)
                ucmd:SetForwardMove(0)
                ucmd:SetViewAngles(freecamAngles2)
                ucmd:RemoveKey(IN_JUMP)
                ucmd:RemoveKey(IN_DUCK)
        
                freecamAngles = (freecamAngles + Angle(ucmd:GetMouseY() * .023, ucmd:GetMouseX() * -.023, 0));
                freecamAngles.p, freecamAngles.y, freecamAngles.x = math.Clamp(freecamAngles.p, -89, 89), math.NormalizeAngle(freecamAngles.y), math.NormalizeAngle(freecamAngles.x);
 
                local curFreecamSpeed = freecamSpeed
                if(input.IsKeyDown(KEY_LSHIFT)) then
                    curFreecamSpeed = freecamSpeed * 2
                end
 
                if(input.IsKeyDown(KEY_W)) then
                    freecamPos = freecamPos + (freecamAngles:Forward() * curFreecamSpeed)
                end
                if(input.IsKeyDown(KEY_S)) then
                    freecamPos = freecamPos - (freecamAngles:Forward() * curFreecamSpeed)
                end
                if(input.IsKeyDown(KEY_A)) then
                    freecamPos = freecamPos - (freecamAngles:Right() * curFreecamSpeed)
                end
                if(input.IsKeyDown(KEY_D)) then
                    freecamPos = freecamPos + (freecamAngles:Right() * curFreecamSpeed)
                end
                if(input.IsKeyDown(KEY_SPACE)) then
                    freecamPos = freecamPos + Vector(0,0,curFreecamSpeed)
                end
                if(input.IsKeyDown(KEY_LCONTROL)) then
                    freecamPos = freecamPos - Vector(0,0,curFreecamSpeed)
                end
         end
    end)
 
    hook.Add("Tick", "checkKeybind", function()
        if(input.IsKeyDown(KEY_V)) then
            if(!keyPressed) then
                print("enable freecam")
                freecamEnabled = !freecamEnabled
                freecamAngles = LocalPlayer():EyeAngles()
                freecamAngles2 = LocalPlayer():EyeAngles()
                freecamPos = LocalPlayer():EyePos()
                keyPressed = true
            end
        else
            keyPressed = false
        end
    end)
 
    hook.Add("CalcView", "freeCam", function(ply, pos, angles, fov)
        local view = {}
        if(freecamEnabled) then
            view = {
                origin = freecamPos,
                angles = freecamAngles,
                fov = fov,
                drawviewer = true
            }
        else
            view = {
                origin = pos,
                angles = angles,
                fov = fov,
                drawviewer = false
            }
        end
 
	    return view
    end)	  
        
	else
    hook.Add("CalcView", "freeCam", function()

    end) 
	hook.Add("Tick", "checkKeybind", function()
	
	end)
	hook.Add("CreateMove", "lock_movement", function()
	
	end)
	end
	end	
	
    local crosshair = tab1panel:Add( "DCheckBoxLabel", tab1panel) 
    crosshair:SetPos( 430, 140 ) 
    crosshair:SetValue( false ) 
	crosshair:SetText( "Force CrossHair" )
    crosshair:SizeToContents()

	function crosshair:OnChange(crosshairr)
	if (crosshairr) then	
        hook.Add( "HUDPaint", "ForceCrossHair", function()    
            draw.RoundedBox(0, (ScrW() / 2) - 2, (ScrH() / 2) - 2, 3, 3, Color(0, 0, 0, 255))
		    draw.RoundedBox(0, (ScrW() / 2) - 1, (ScrH() / 2) - 1, 1, 1, Color(255, 255, 255, 225))
		end)
	else
        hook.Add( "HUDPaint", "ForceCrossHair", function() 
		end)
	end
	end	
	
    local aura = tab1panel:Add( "DCheckBoxLabel", tab1panel) 
    aura:SetPos( 430, 160 ) 
    aura:SetValue( false ) 
	aura:SetText( "CrossHair Sphere" )
    aura:SizeToContents()

	function aura:OnChange(aurar)
	if (aurar) then	
        hook.Add( "HUDPaint", "ForceCrossHair", function()    
            draw.RoundedBox(0, (ScrW() / 2) - 2, (ScrH() / 2) - 2, 3, 3, Color(0, 0, 0, 255))
		    draw.RoundedBox(0, (ScrW() / 2) - 1, (ScrH() / 2) - 1, 1, 1, Color(255, 255, 255, 225))
		end)
	else
        hook.Add( "HUDPaint", "ForceCrossHair", function() 
		end)
	end
	end
---------------------------------------------------------------------------------------------------------------------------------------------------
	local DLabel = vgui.Create( "DLabel", hvhpanel )
    DLabel:SetPos( 15, 10 )
    DLabel:SetColor(Color(255, 0, 0))
    DLabel:SetText( "Animations:" )	
	
	local DLabel = vgui.Create( "DLabel", hvhpanel )
    DLabel:SetPos( 15, 300 )
    DLabel:SetColor(Color(255, 0, 0))
    DLabel:SetText( "Exploits:" )	
	
    local lagdt = hvhpanel:Add( "DCheckBoxLabel", hvhpanel) 
    lagdt:SetPos( 15, 320 ) 
    lagdt:SetValue( false ) 
	lagdt:SetText( "Lag DT(B)" )
    lagdt:SizeToContents()
	
	local warnicon = Material("icon16/bullet_error.png")
	function lagdt:OnChange(lagdtt)
	if (lagdtt) then	
		hook.Add( "HUDPaint", "ExploitWarning", function()    
	    draw.DrawText( "Lag Tap(B)", "TargetID", 1, (ScrW() / 1.5), Color(255,0,0,255), TEXT_ALIGN_LEFT )
        end )
	    hook.Add( "Think", "DT_CKey", function()
		    if (input.IsKeyDown(KEY_B)) then
                for i = 1, 74354 do 
                RunConsoleCommand( "cl_forcepreload", "0" )
                RunConsoleCommand( "cl_forcepreload", "1" )
                end 
				
	    	    RunConsoleCommand("+attack")
 
                timer.Simple(0.5, function() 
                    RunConsoleCommand( "-attack" )
                end)
			end
		end)
	else
	hook.Add( "Think", "DT_CKey", function()
	end)
	hook.Add( "HUDPaint", "ExploitWarning", function()
	end)	
	end
	end		
	
    local lagdodge = hvhpanel:Add( "DCheckBoxLabel", hvhpanel) 
    lagdodge:SetPos( 15, 340 ) 
    lagdodge:SetValue( false ) 
	lagdodge:SetText( "Lag Dodge(V)" )
    lagdodge:SizeToContents()
	
	function lagdodge:OnChange(lagdodgee)
	if (lagdodgee) then	
		hook.Add( "HUDPaint", "ExploitWarning", function()    
	    draw.DrawText( "Lag Dodge(V)", "TargetID", 1, (ScrW() / 1.5), Color(255,0,0,255), TEXT_ALIGN_LEFT )
        end )
	    hook.Add( "Think", "LagDodge", function()
		    if (input.IsKeyDown(KEY_V)) then
                for i = 1, 74354 do 
                RunConsoleCommand( "cl_forcepreload", "0" )
                RunConsoleCommand( "cl_forcepreload", "1" )
                end 
				
	    	    RunConsoleCommand("+forward")
 
                timer.Simple(0.5, function() 
                    RunConsoleCommand( "-forward" )
                end)
			end
		end)
	else
	hook.Add( "Think", "LagDodge", function()
	end)
	hook.Add( "HUDPaint", "ExploitWarning", function()
	end)
	end
	end	
	
	
	
	
---------------------------------------------------------------------------------------------------------------------------------------------------
function getPlayers()
    local plrs = {}
    for k,v in pairs(player.GetAll()) do
        if(v:Alive() and v != LocalPlayer() and !v:IsDormant()) then
            plrs[#plrs + 1] = v
        end
    end
    return plrs
end

	local DLabel = vgui.Create( "DLabel", shootingtab )
    DLabel:SetPos( 120, 12 )
    DLabel:SetColor(Color(255, 0, 0))
    DLabel:SetText( "Enable aimbot" )	
	
	local DLabel = vgui.Create( "DLabel", shootingtab )
    DLabel:SetPos( 120, 23 )
    DLabel:SetColor(Color(255, 0, 0))
    DLabel:SetText( "Press E" )	

    local enableheadaimbot = shootingtab:Add( "DCheckBoxLabel", shootingtab) 
    enableheadaimbot:SetPos( 15, 15 ) 
    enableheadaimbot:SetValue( false ) 
	enableheadaimbot:SetText( "Cursor Aimbot" )
    enableheadaimbot:SizeToContents()
	
    local enablebaim = shootingtab:Add( "DCheckBoxLabel", shootingtab) 
    enablebaim:SetPos( 15, 35 ) 
    enablebaim:SetValue( false ) 
	enablebaim:SetText( "Pelvis Aim" )
    enablebaim:SizeToContents()
	
    local baimenable = shootingtab:Add( "DCheckBoxLabel", shootingtab) 
    baimenable:SetPos( 15, 55 ) 
    baimenable:SetValue( false ) 
	baimenable:SetText( "Neck Aim" )
    baimenable:SizeToContents()
	
    local smartaim = shootingtab:Add( "DCheckBoxLabel", shootingtab) 
    smartaim:SetPos( 85, 55 ) 
    smartaim:SetValue( false ) 
	smartaim:SetText( "Selector Aim" )
    smartaim:SizeToContents()
	
	local aimicons = Material("icon16/bullet_error.png")
	function enableheadaimbot:OnChange(enableheadaimbott)
	if (enableheadaimbott) then
		hook.Add( "HUDPaint", "AIMTargetIndicator", function()    
	    draw.DrawText( "Head Aim", "ChalkAnarchyIndicators", 15, ScrW() / 2, Color(255,0,0,255), TEXT_ALIGN_LEFT )
		surface.SetDrawColor( 255, 255, 255, 255 ) 
      	surface.SetMaterial( aimicons ) 
    	surface.DrawTexturedRect( 140, ScrW() / 2, 32, 32 ) 
        end )
        hook.Add("Tick", "cursorAimbot", function()
		    local targets = getPlayers()
			if(targets and input.IsKeyDown(KEY_E)) then
			    for k,v in pairs(targets) do
				    local ft1,ft2 = engine.ServerFrameTime()
					local pos = (v:GetBonePosition(v:LookupBone("ValveBiped.Bip01_Head1")) + v:GetVelocity() * ft1):ToScreen()
					local oCX,oCY = input.GetCursorPos()
					input.SetCursorPos(pos.x,pos.y)
				end
			end
		end)
	else
        hook.Add("Tick", "cursorAimbot", function() 	
		end)
		hook.Add( "HUDPaint", "AIMTargetIndicator", function()    
        end )
	end
	end		
	
	function enablebaim:OnChange(enablebaimt)
	if (enablebaimt) then
		hook.Add( "HUDPaint", "AIMTargetIndicator", function()    
	    draw.DrawText( "Pelvis Aim", "ChalkAnarchyIndicators", 15, ScrW() / 2, Color(255,0,0,255), TEXT_ALIGN_LEFT )
	    surface.SetDrawColor( 255, 255, 255, 255 ) 
      	surface.SetMaterial( aimicons ) 
    	surface.DrawTexturedRect( 150, ScrW() / 2, 32, 32 )
        end )
        hook.Add("Tick", "cursorBaim", function()
		    local targets = getPlayers()
			if(targets and input.IsKeyDown(KEY_E)) then
			    for k,v in pairs(targets) do
				    local ft1,ft2 = engine.ServerFrameTime()
					local pos = (v:GetBonePosition(v:LookupBone("ValveBiped.Bip01_Pelvis")) + v:GetVelocity() * ft1):ToScreen()
					local oCX,oCY = input.GetCursorPos()
					input.SetCursorPos(pos.x,pos.y)
				end
			end
		end)
	else
        hook.Add("Tick", "cursorBaim", function() 		
		end)
		hook.Add( "HUDPaint", "AIMTargetIndicator", function()    
        end )
	end
	end	
	
	function baimenable:OnChange(baimenablee)
	if (baimenablee) then
		hook.Add( "HUDPaint", "AIMTargetIndicator", function()    
	    draw.DrawText( "Neck Aim", "ChalkAnarchyIndicators", 15, ScrW() / 2, Color(255,0,0,255), TEXT_ALIGN_LEFT )
		surface.SetDrawColor( 255, 255, 255, 255 ) 
      	surface.SetMaterial( aimicons ) 
    	surface.DrawTexturedRect( 130, ScrW() / 2, 32, 32 )
        end )
        hook.Add("Tick", "cursorBaim", function()
		    local targets = getPlayers()
			if(targets and input.IsKeyDown(KEY_E)) then
			    for k,v in pairs(targets) do
				    local ft1,ft2 = engine.ServerFrameTime()
					local pos = (v:GetBonePosition(v:LookupBone("ValveBiped.Bip01_Neck1")) + v:GetVelocity() * ft1):ToScreen()
					local oCX,oCY = input.GetCursorPos()
					input.SetCursorPos(pos.x,pos.y)
				end
			end
		end)
	else
        hook.Add("Tick", "cursorBaim", function() 	
		end)
		hook.Add( "HUDPaint", "AIMTargetIndicator", function()    
        end )			
	end
	end	
	
	function smartaim:OnChange(smartaimm)
	if (smartaimm) then
	hook.Add( "Think", "LagDodge", function()
	    if (input.IsKeyDown(KEY_T)) then
		    hook.Add( "HUDPaint", "AIMTargetIndicator", function()    
	        draw.DrawText( "Head Aim", "ChalkAnarchyIndicators", 15, ScrW() / 2, Color(255,0,0,255), TEXT_ALIGN_LEFT )
		    surface.SetDrawColor( 255, 255, 255, 255 ) 
          	surface.SetMaterial( aimicons ) 
    	    surface.DrawTexturedRect( 140, ScrW() / 2, 32, 32 )
            end )
            hook.Add("Tick", "cursorBaim", function()
		        local targets = getPlayers()
			    if(targets and input.IsKeyDown(KEY_E)) then
			        for k,v in pairs(targets) do
				        local ft1,ft2 = engine.ServerFrameTime()
					    local pos = (v:GetBonePosition(v:LookupBone("ValveBiped.Bip01_Head1")) + v:GetVelocity() * ft1):ToScreen()
					    local oCX,oCY = input.GetCursorPos()
					    input.SetCursorPos(pos.x,pos.y)
				    end
			    end
		    end)
		end
	    if (input.IsKeyDown(KEY_G)) then
		    hook.Add( "HUDPaint", "AIMTargetIndicator", function()    
	        draw.DrawText( "Pelvis Aim", "ChalkAnarchyIndicators", 15, ScrW() / 2, Color(255,0,0,255), TEXT_ALIGN_LEFT )
		    surface.SetDrawColor( 255, 255, 255, 255 ) 
          	surface.SetMaterial( aimicons ) 
    	    surface.DrawTexturedRect( 150, ScrW() / 2, 32, 32 )
            end )
            hook.Add("Tick", "cursorBaim", function()
		        local targets = getPlayers()
			    if(targets and input.IsKeyDown(KEY_E)) then
			        for k,v in pairs(targets) do
				        local ft1,ft2 = engine.ServerFrameTime()
					    local pos = (v:GetBonePosition(v:LookupBone("ValveBiped.Bip01_Pelvis")) + v:GetVelocity() * ft1):ToScreen()
					    local oCX,oCY = input.GetCursorPos()
					    input.SetCursorPos(pos.x,pos.y)
				    end
			    end
		    end)
		end		
	    if (input.IsKeyDown(KEY_H)) then
		    hook.Add( "HUDPaint", "AIMTargetIndicator", function()    
	        draw.DrawText( "Neck Aim", "ChalkAnarchyIndicators", 15, ScrW() / 2, Color(255,0,0,255), TEXT_ALIGN_LEFT )
		    surface.SetDrawColor( 255, 255, 255, 255 ) 
          	surface.SetMaterial( aimicons ) 
    	    surface.DrawTexturedRect( 130, ScrW() / 2, 32, 32 )
            end )
            hook.Add("Tick", "cursorBaim", function()
		        local targets = getPlayers()
			    if(targets and input.IsKeyDown(KEY_E)) then
			        for k,v in pairs(targets) do
				        local ft1,ft2 = engine.ServerFrameTime()
					    local pos = (v:GetBonePosition(v:LookupBone("ValveBiped.Bip01_Neck1")) + v:GetVelocity() * ft1):ToScreen()
					    local oCX,oCY = input.GetCursorPos()
					    input.SetCursorPos(pos.x,pos.y)
				    end
			    end
		    end)
		end
	end)
	else
        hook.Add("Tick", "cursorBaim", function() 	
		end)
		hook.Add( "HUDPaint", "AIMTargetIndicator", function()    
        end )			
	end
	end
	
------------------------------------------------------------------------------------------------------------

------------------------------------------------------------------------------------------------------------

------------------------------------------------------------------------------------------------------------

------------------------------------------------------------------------------------------------------------

------------------------------------------------------------------------------------------------------------

------------------------------------------------------------------------------------------------------------

------------------------------------------------------------------------------------------------------------
	local DLabel = vgui.Create( "DLabel", miscpanel )
    DLabel:SetPos( 15, 10 )
    DLabel:SetColor(Color(255, 255, 255))
    DLabel:SetText( "Self:" )	
	
	local lgbtcolor = miscpanel:Add( "DCheckBoxLabel", miscpanel) 
    lgbtcolor:SetPos( 15, 30 ) 
    lgbtcolor:SetValue( false ) 
	lgbtcolor:SetText( "Rainbow Player" )
    lgbtcolor:SizeToContents()	
	
	function lgbtcolor:OnChange(lgbtcolorr)
	if (lgbtcolorr) then 
    hook.Add("Think", "rgbplayer", function()
        local RainbowPlayer = HSVToColor(CurTime() % 6 * 60, 1, 1)
        LocalPlayer():SetWeaponColor(Vector(RainbowPlayer.r / 255, RainbowPlayer.g / 255, RainbowPlayer.b / 255))
        LocalPlayer():SetPlayerColor(Vector(RainbowPlayer.r / 255, RainbowPlayer.g / 255, RainbowPlayer.b / 255))
    end)
	else
    hook.Add("Think", "rgbplayer", function()

    end)
	end
	end		
	
	local nightmod = miscpanel:Add( "DCheckBoxLabel", miscpanel) 
    nightmod:SetPos( 15, 50 ) 
    nightmod:SetValue( false ) 
	nightmod:SetText( "Black Rect" )
    nightmod:SizeToContents()	
	
	function nightmod:OnChange(nightmodd)
	if (nightmodd) then 
        hook.Add( "HUDPaint", "NightMod", function()    
	        surface.SetDrawColor( 11, 11, 11, 200 )
	        surface.DrawRect( 0, 0, ScrW(), ScrH() )
        end )
	else
    hook.Add("HUDPaint", "NightMod", function()

    end)
	end
	end	

	local logsdmg = miscpanel:Add( "DCheckBoxLabel", miscpanel) 
    logsdmg:SetPos( 15, 70 ) 
    logsdmg:SetValue( false ) 
	logsdmg:SetText( "Damage Logs" )
    logsdmg:SizeToContents()	
	
	function logsdmg:OnChange(logsdmgg)
	if (logsdmgg) then 
        hook.Add( "HUDPaint", "NightMod", function()    
	        surface.SetDrawColor( 11, 11, 11, 200 )
	        surface.DrawRect( 0, 0, ScrW(), ScrH() )
        end )
	else
    hook.Add("HUDPaint", "NightMod", function()

    end)
	end
	end	


	
	
------------------------------------------------------------------------------------------------------------
    --Visuals Tab
    tabs:AddSheet( "Visuals", tab1panel, "icon16/eye.png", false, false, "ESP, Chams, Self, World.")
    tabs:AddSheet( "Shooting", shootingtab, "icon16/gun.png", false, false, "Mom im Ilnaz.")
    tabs:AddSheet( "HvH", hvhpanel, "icon16/exclamation.png", false, false, "Killing kids is fun.")
    tabs:AddSheet( "Scripts", scriptpanel, "icon16/cart_add.png", false, false, "Public and private.")
    tabs:AddSheet( "Browser", browserpanel, "icon16/application_home.png", false, false, "Internet browser.")
    tabs:AddSheet( "Steam", steampanel, "icon16/group.png", false, false, "Steam browser")
    tabs:AddSheet( "DarkRP", darkrptab, "icon16/fire.png", false, false, "Jokes of DarkRP mode.")
    tabs:AddSheet( "HUD", hudtab, "icon16/color_wheel.png", false, false, "Customisation on TOP!")
    tabs:AddSheet( "Test", testtab, "icon16/bug_error.png", false, false, "Can kill ur PC")
    tabs:AddSheet( "Credits", creditstab, "icon16/flag_red.png", false, false, "Real sharp, yeah.")
    tabs:AddSheet( "Misc", miscpanel, "icon16/emoticon_tongue.png", false, false, "Useless stuff...")
	
	

end)
