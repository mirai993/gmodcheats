--[[
	lua/mydikdestroyeredition1.lua
	Sunil "Da Boston Bomb" Tripathi | (STEAM_0:1:37608927)
	===DStream===
]]

// sex by A gay kid stimpy
if SERVER then return end

local sex = {}

local concommand = concommand
local cvars = cvars
local debug = debug
local ents = ents
local file = file
local hook = hook
local math = math
local spawnmenu = spawnmenu
local string = string
local surface = surface
local table = table
local timer = timer
local util = util
local vgui = vgui

local Angle = Angle
local CreateClientConVar = CreateClientConVar
local CurTime = CurTime
local ErrorNoHalt = ErrorNoHalt
local FrameTime = FrameTime
local GetConVarString = GetConVarString
local GetViewEntity = GetViewEntity
local include = include
local ipairs = ipairs
local LocalPlayer = LocalPlayer
local pairs = pairs
local pcall = pcall
local print = print
local RunConsoleCommand = RunConsoleCommand
local ScrH = ScrH
local ScrW = ScrW
local tonumber = tonumber
local type = type
local unpack = unpack
local ValidEnt = ValidEnt
local Vector = Vector
local ValidEntity = ValidEntity
local CUserCmd = CUserCmd

if SERVER then
		return false
	end
do
	local hooks = {}
	local created = {}
	local function CallHook(sex, name, args)
		if !hooks[name] then return end
		for funcName, _ in pairs(hooks[name]) do
			local func = sex[funcName]
			if func then
				local ok, err = pcall(func, sex, unpack(args or {}))
				if !ok then
					ErrorNoHalt(err .. "\n")
				elseif err then
					return err
				end
			end
		end
	end
	local function RandomName()
		local random = ""
		for i = 1, math.random(4, 10) do
			local c = math.random(65, 116)
			if c >= 91 && c <= 96 then c = c + 6 end
			random = random .. string.char(c)
		end
		return random
	end
	local function AddHook(sex, name, funcName)
		// If we haven't got a hook for this yet, make one with a random name and store it.
		// This is so anti-cheats can't detect by hook name, and so we can remove them later.
		if !created[name] then
			local random = RandomName()
			hook.Add(name, random, function(...) return CallHook(sex, name, {...}) end)
			created[name] = random
		end
		
		hooks[name] = hooks[name] or {}
		hooks[name][funcName] = true
	end
	
	local cvarhooks = {}
	local function GetCallbackTable(convar)
		local callbacks = cvars.GetConVarCallbacks(convar)
		if !callbacks then
			cvars.AddChangeCallback(convar, function() end)
			callbacks = cvars.GetConVarCallbacks(convar)
		end
		return callbacks
	end
			
	local function AddCVarHook(sex, convar, funcName, ...)
		local hookName = "CVar_" .. convar
		if !cvarhooks[convar] then
			local random = RandomName()
			
			local callbacks = GetCallbackTable(convar)
			callbacks[random] = function(...)
				CallHook(sex, hookName, {...})
			end
			
			cvarhooks[convar] = random
		end
		AddHook(sex, hookName, funcName)
	end
	
	// Don't let other scripts remove our hooks.
	local oldRemove = hook.Remove
	function hook.Remove(name, unique)
		if created[name] == unique then return end
		oldRemove(name, unique)
	end
	
	// Removes all hooks, useful if reloading the script.
	local function RemoveHooks()
		for hookName, unique in pairs(created) do
			oldRemove(hookName, unique)
		end
		for convar, unique in pairs(cvarhooks) do
			local callbacks = GetCallbackTable(convar)
			callbacks[unique] = nil
		end
	end
	
	// Add copies the script can access.
	sex.AddHook = AddHook
	sex.AddCVarHook = AddCVarHook
	sex.CallHook = CallHook
	sex.RemoveHooks = RemoveHooks
end

concommand.Add("sex_reload", function()
	sex:CallHook("Shutdown")
	print("Removing hooks...")
	sex:RemoveHooks()
	
	local info = debug.getinfo(1, "S")
	if info && info.short_src then
		print("Reloading (" .. info.short_src .. ")...")
		include(info.short_src)
	else
		print("Cannot find der file, reload manually.")
	end
end)

// ##################################################
// MetaTables
// ##################################################
local function GetMeta(name)
	local meta = FindMetaTable(name)
	return meta
	//return table.Copy(_R[name] or {})
end

local AngM = GetMeta("Angle")
local CmdM = GetMeta("CUserCmd")
local EntM = GetMeta("Entity")
local PlyM = GetMeta("Player")
local VecM = GetMeta("Vector")

// ##################################################
// Settings
// ##################################################

do
	local settings = {}
	local function SettingVar(sex, name)
		return (sex.SettingPrefix or "") .. string.lower(name)
	end
	
	local function RandomName()
		local random = ""
		for i = 1, math.random(4, 10) do
			local c = math.random(65, 116)
			if c >= 91 && c <= 96 then c = c + 6 end
			random = random .. string.char(c)
		end
		return random
	end
	
	local function SetSetting(name, _, new)
		if !settings[name] then return end
		local info = settings[name]
		
		if info.Type == "number" then
			new = tonumber(new)
		elseif info.Type == "boolean" then
			new = (tonumber(new) or 0) > 0
		end
		
		info.Value = new
	end
	
	local function CreateSetting(sex, name, desc, default, misc)
		local cvar = SettingVar(sex, name)
		local info = {Name = name, Desc = desc, CVar = cvar, Type = type(default), Value = default}
		
		for k, v in pairs(misc or {}) do
			if !info[k] then info[k] = v end
		end
		
		// Convert default from boolean to number.
		if type(default) == "boolean" then
			default = default and 1 or 0
		end
		
		if !settings[cvar] then
			local tab = cvars.GetConVarCallbacks(cvar)
			if !tab then
				cvars.AddChangeCallback(cvar, function() end)
				tab = cvars.GetConVarCallbacks(cvar)
			end
			
			while true do
				local name = RandomName()
				if !tab[name] then
					tab[name] = SetSetting
					info.Callback = name
					break
				end
			end
		end
		
		settings[cvar] = info
		settings[#settings + 1] = info
		
		// Create the convar.
		CreateClientConVar(cvar, default, (info.Save != false), false)
		SetSetting(cvar, _, GetConVarString(cvar))
	end
	local function GetSetting(sex, name)
		local cvar = SettingVar(sex, name)
		if !settings[cvar] then return end
		return settings[cvar].Value
	end
	local function Shutdown()
		print("Removing settings callbacks...")
		for _, info in ipairs(settings) do
			if info.CVar && info.Callback then
				local tab = cvars.GetConVarCallbacks(info.CVar)
				if tab then
					tab[info.Callback] = nil
				end
			end
		end
	end
	local function SettingsList()
		return table.Copy(settings)
	end
	local function BuildMenu(sex, panel)
		for _, info in ipairs(settings) do
			if info.Show != false then
				if info.MultiChoice then
					local m = panel:MultiChoice(info.Desc or info.CVar, info.CVar)
					for k, v in pairs(info.MultiChoice) do
						m:AddChoice(k, v)
					end
				elseif info.Type == "number" then
					panel:NumSlider(info.Desc or info.CVar, info.CVar, info.Min or -1, info.Max or -1, info.Places or 0)
				elseif info.Type == "boolean" then
					panel:CheckBox(info.Desc or info.CVar, info.CVar)
				elseif info.Type == "string" then
					panel:TextEntry(info.Desc or info.CVar, info.CVar)
				end
			end
		end
	end
	
	sex.SettingPrefix = "sex_"
	sex.CreateSetting = CreateSetting
	sex.Setting = GetSetting
	sex.SettingsList = SettingsList
	sex.BuildMenu = BuildMenu
	
	sex.SettingsShutdown = Shutdown
	sex:AddHook("Shutdown", "SettingsShutdown")
end


// ##################################################
// Targetting - Positions
// ##################################################

sex.ModelTarget = {}
function sex:SetModelTarget(model, targ)
	sex.ModelTarget[model] = targ
end
sex:CreateSetting("aimspot", "aimspot head = 1 pelvis = 8", 1, {Min = 1, Max = 12})
sex:CreateSetting("prioritize", "shoot visible spot", false)
local xd = 1
function sex:BaseTargetPosition(ent)
	
	// Check if the model has a special target assigned to it.	
	local special = sex.ModelTarget[string.lower(EntM["GetModel"](ent) or "")]
	if special then
		// It's a string - look for a bone.
		if type(special) == "string" then
			local bone = EntM["LookupBone"](ent, special)
			if bone then
				local pos = EntM["GetBonePosition"](ent, bone)
				if pos then
					return pos
				end
			end
		// It's a Vector - return a relative position.
		elseif type(special) == "Vector" then
			return EntM["LocalToWorld"](ent, special)
		// It's a function - do something fancy!
		elseif type(special) == "function" then
			local pos = pcall(special, ent)
			if pos then return pos end
		end
	end
	
	
	// Try and use the head bone, found on all of the player + human models.
	local aimspotx = sex:Setting("aimspot")
	local head
	if sex:Setting("prioritize") then
		for k,v in pairs {"ValveBiped.Bip01_Head1","ValveBiped.Bip01_Neck1","ValveBiped.Bip01_Spine4","ValveBiped.Bip01_Spine2","ValveBiped.Bip01_Spine1","ValveBiped.Bip01_Spine","ValveBiped.Bip01_Pelvis",
		"ValveBiped.Bip01_L_Clavicle","ValveBiped.Bip01_L_UpperArm","ValveBiped.Bip01_L_Forearm",
		"ValveBiped.Bip01_L_Hand","ValveBiped.Bip01_R_Clavicle","ValveBiped.Bip01_R_UpperArm","ValveBiped.Bip01_R_Forearm","ValveBiped.Bip01_R_Hand",
		"ValveBiped.Bip01_R_Wrist","ValveBiped.Bip01_L_Wrist","ValveBiped.Bip01_L_Ulna","ValveBiped.Bip01_R_Ulna","ValveBiped.Bip01_R_Thigh","ValveBiped.Bip01_L_Thigh",
		"ValveBiped.Bip01_L_Calf","ValveBiped.Bip01_R_Calf","ValveBiped.Bip01_L_Foot","ValveBiped.Bip01_R_Foot","ValveBiped.Bip01_L_Toe0","ValveBiped.Bip01_R_Toe0"} do 
			//print("For Loop: " .. v)
			head = EntM["LookupBone"](ent, v)
			if head then
				local pos = EntM["GetBonePosition"](ent, head)
				if pos then
					local shootPos = PlyM["GetShootPos"](LocalPlayer())
					//local trace = util.QuickTrace(shootPos,pos*10000000,{ply})
					local trace = util.TraceLine({start = shootPos, endpos = pos, filter = {LocalPlayer()}}) //  filter = {ply, ent}, mask = MASK_SHOT

					if trace.HitNonWorld && trace.Entity == ent then
						//print("returning position for bone: " .. v)
						return pos
					else
						//print("bone: " .. v .. "failed")
						//PrintTable(trace)
					end
				end
			end	
		end
		
	end
	
	if aimspotx == 3 then
		local bone = "ValveBiped.Bip01_Head1"
		head = EntM["LookupBone"](ent, bone)
	elseif aimspotx == 4 then
		local bone = "ValveBiped.Bip01_Neck1"
		head = EntM["LookupBone"](ent, bone)
	elseif aimspotx == 5 then
		local bone = "ValveBiped.Bip01_Spine4"
		head = EntM["LookupBone"](ent, bone)
	elseif aimspotx == 6 then
		local bone = "ValveBiped.Bip01_Spine2"
		head = EntM["LookupBone"](ent, bone)
	elseif aimspotx == 7 then
		local bone = "ValveBiped.Bip01_Spine1"
		head = EntM["LookupBone"](ent, bone)
	elseif aimspotx == 8 then
		local bone = "ValveBiped.Bip01_Spine"
		head = EntM["LookupBone"](ent, bone)
	elseif aimspotx == 9 then
		local bone = "ValveBiped.Bip01_Pelvis"
		head = EntM["LookupBone"](ent, bone)
	elseif aimspotx == 10 then
		local bone = "ValveBiped.Bip01_R_Clavicle"
		head = EntM["LookupBone"](ent, bone)
	elseif aimspotx == 11 then
		local bone = "ValveBiped.Bip01_L_Clavicle"
		head = EntM["LookupBone"](ent, bone)
	elseif aimspotx == 12 then
		local bone = "ValveBiped.Bip01_R_Foot"
		head = EntM["LookupBone"](ent, bone)
	end
	if head then
		local pos = EntM["GetBonePosition"](ent, head)
		if pos then
			return pos
		end
	end
	if type(ent) == "Player" && sex:Setting("aimspot") == 1 then
		local head = EntM["LookupAttachment"](ent, "eyes")
		if head then
			local pos = EntM["GetAttachment"](ent, head)
			if pos then
				return pos.Pos - (AngM["Forward"](pos.Ang) * 2)
			end
		end
	elseif type(ent) == "Player" && sex:Setting("aimspot") == 2 then
		local head = EntM["LookupAttachment"](ent, "chest")
		if head then
			local pos = EntM["GetAttachment"](ent, head)
			if pos then
				return pos.Pos - (AngM["Forward"](pos.Ang) * 2)
			end
		end
	end
	
	// Give up and return the center of the entity.
	return EntM["LocalToWorld"](ent, EntM["OBBCenter"](ent))
	
end
function sex:TargetPosition(ent)
	local targetPos = sex:BaseTargetPosition(ent)
	
	local ply = LocalPlayer()
	if ValidEnt(ply) then

		targetPos = sex:CallHook("TargetPrediction", {ply, ent, targetPos}) or targetPos
		return targetPos
	end
	
	return targetPost
end

sex:SetModelTarget("models/crow.mdl", Vector(0, 0, 5))						// Crow.
sex:SetModelTarget("models/pigeon.mdl", Vector(0, 0, 5)) 					// Pigeon.
sex:SetModelTarget("models/seagull.mdl", Vector(0, 0, 6)) 					// Seagull.
sex:SetModelTarget("models/combine_scanner.mdl", "Scanner.Body") 				// Scanner.
sex:SetModelTarget("models/hunter.mdl", "MiniStrider.body_joint") 			// Hunter.
sex:SetModelTarget("models/combine_turrets/floor_turret.mdl", "Barrel") 		// Turret.
sex:SetModelTarget("models/dog.mdl", "Dog_Model.Eye") 						// Dog.
sex:SetModelTarget("models/vortigaunt.mdl", "ValveBiped.Head") 				// Vortigaunt.
sex:SetModelTarget("models/antlion.mdl", "Antlion.Body_Bone") 					// Antlion.
sex:SetModelTarget("models/antlion_guard.mdl", "Antlion_Guard.Body") 			// Antlion guard.
sex:SetModelTarget("models/antlion_worker.mdl", "Antlion.Head_Bone") 			// Antlion worker.
sex:SetModelTarget("models/zombie/fast_torso.mdl", "ValveBiped.HC_BodyCube") 	// Fast zombie torso.
sex:SetModelTarget("models/zombie/fast.mdl", "ValveBiped.HC_BodyCube") 		// Fast zombie.
sex:SetModelTarget("models/headcrabclassic.mdl", "HeadcrabClassic.SpineControl") // Normal headcrab.
sex:SetModelTarget("models/headcrabblack.mdl", "HCBlack.body") 				// Poison headcrab.
sex:SetModelTarget("models/headcrab.mdl", "HCFast.body") 						// Fast headcrab.
sex:SetModelTarget("models/zombie/poison.mdl", "ValveBiped.Headcrab_Cube1")	 // Poison zombie.
sex:SetModelTarget("models/zombie/classic.mdl", "ValveBiped.HC_Body_Bone")	 // Zombie.
sex:SetModelTarget("models/zombie/classic_torso.mdl", "ValveBiped.HC_Body_Bone") // Zombie torso.
sex:SetModelTarget("models/zombie/zombie_soldier.mdl", "ValveBiped.HC_Body_Bone") // Zombine.
sex:SetModelTarget("models/combine_strider.mdl", "Combine_Strider.Body_Bone") // Strider.
sex:SetModelTarget("models/combine_dropship.mdl", "D_ship.Spine1") 			// Combine dropship.
sex:SetModelTarget("models/combine_helicopter.mdl", "Chopper.Body") 			// Combine helicopter.
sex:SetModelTarget("models/gunship.mdl", "Gunship.Body")						// Combine gunship.
sex:SetModelTarget("models/lamarr.mdl", "HeadcrabClassic.SpineControl")		// Lamarr!
sex:SetModelTarget("models/mortarsynth.mdl", "Root Bone")						// Mortar synth.
sex:SetModelTarget("models/synth.mdl", "Bip02 Spine1")						// Synth.
sex:SetModelTarget("models/vortigaunt_slave.mdl", "ValveBiped.Head")			// Vortigaunt slave.


// ##################################################
// Targetting - General
// ##################################################

sex.NPCDeathSequences = {}
function sex:AddNPCDeathSequence(model, sequence)
	sex.NPCDeathSequences = sex.NPCDeathSequences or {}
	sex.NPCDeathSequences[model] = sex.NPCDeathSequences[model] or {}
	if !table.HasValue(sex.NPCDeathSequences[model]) then
		table.insert(sex.NPCDeathSequences[model], sequence)
	end
end

sex:AddNPCDeathSequence("models/barnacle.mdl", 4)
sex:AddNPCDeathSequence("models/barnacle.mdl", 15)
sex:AddNPCDeathSequence("models/antlion_guard.mdl", 44)
sex:AddNPCDeathSequence("models/hunter.mdl", 124)
sex:AddNPCDeathSequence("models/hunter.mdl", 125)
sex:AddNPCDeathSequence("models/hunter.mdl", 126)
sex:AddNPCDeathSequence("models/hunter.mdl", 127)
sex:AddNPCDeathSequence("models/hunter.mdl", 128)

sex:CreateSetting("targetnpcs", "Target Npcs", false)
sex:CreateSetting("friendlyfire", "Target teammates", false)
sex:CreateSetting("friends", "Dont shoot at friends", true)
sex:CreateSetting("tttmode", "TTT mode", false)
sex:CreateSetting("noadminsplz","Don't shoot admins",false)
sex:CreateSetting("copmode","for perp, dont shoot cops or swat",false)
sex:CreateSetting("noplayers","dont shoot any players",false)
sex:CreateSetting("moneyprintermode", "shoot at printers, make sure LOS is off", false)
sex:CreateSetting("turretmode", "shoot at turrets", false)
sex:CreateSetting("spawnpointmode", "shoot spawn points", false)
sex:CreateSetting("pitfall","shoot pitfall platforms", false)
sex:CreateSetting("noplayers","dont shoot players",false)
sex:CreateSetting("cityrpmode","shoot cityrp props",false)
sex:CreateSetting("fakestationmode", "target a fake gay health station LoL", false)
sex:CreateSetting("nofastzombiesorheadcrabs","nope",false)
sex:CreateSetting("doorbuster","fuck them doors",false)
sex:CreateSetting("anticopmode","fuk da police", false)
sex:CreateSetting("crimmodetdm","kill all cops tdm mode", false)
sex:CreateSetting("shittdmmode","dont shoot any civilians", false)
sex:CreateSetting("copmodetdm","kill all criminals tdm mode", false)
sex:CreateSetting("debugxd","debug dat shit",false)
function sex:IsValidTarget(ent)
	
	if sex:Setting("doorbuster") then
		if string.find(ent:GetClass(),"prop_door_rotating") then
			return true
		end
	end
	if ValidEnt(ent) then
		if sex:Setting("moneyprintermode") then 
			if string.find(ent:GetClass(),"printer") != nil then 
				return true 
			end 
		end
		if sex:Setting("fakestationmode") then
			if string.find(ent:GetClass(),"ttt_jihad_station") != nil then 
				return true 
			end 
		end
		if sex:Setting("pitfall") then 
			if string.find(ent:GetClass(),"pf_platform") != nil then 
				return true 
			end 
		end
		if sex:Setting("turretmode") then 
			if string.find(ent:GetClass(),"auto_turret") != nil then 
				return true 
			end 
		end
		if sex:Setting("spawnpointmode") then 
			if string.find(ent:GetClass(),"spawnpoint") != nil then 
				return true 
			end 
		end
		if sex:Setting("cityrpmode") then 
			if string.find(ent:GetClass(),"cityrp_weedpot") != nil then 
				return true 
			end 
			if string.find(ent:GetClass(),"cityrp_money_printer3") then
				return true
			end
			if string.find(ent:GetClass(),"cityrp_drug_lab3") then
				return true
			end
	end
	end
	if !sex:Setting("targetnpcs") && ent:IsNPC()  then return false end
	if sex:Setting("noplayers") && ent:IsPlayer() then return false end
	if ent:IsNPC() then
			if EntM["GetMoveType"](ent) == MOVETYPE_NONE then return false end // No dead NPCs.
			if sex:Setting("nofastzombiesorheadcrabs") then
				if string.find(ent:GetClass(),"npc_headcrab") || string.find(ent:GetClass(),"npc_fastzombie") || string.find(ent:GetClass(),"npc_headcrab_fast") then
			return false
			end
			end
			// No dying NPCs.
			local model = string.lower(EntM["GetModel"](ent) or "")
			if table.HasValue(sex.NPCDeathSequences[model] or {}, EntM["GetSequence"](ent)) then return false end
			return true
	end
	
	if ValidEnt(ent) then
		if sex:Setting("debugxd") then
			if(ent != nil && ent:IsPlayer()) then
				print("NAME")
				print(ent:GetName())
				print("TEAM")
				print(ent:Team())
				print(" ")
				print(" ")
			end
		end
		local typename = type(ent)
			
		if !ent:IsNPC() && !ent:IsPlayer() then return false end
		if sex:Setting("noplayers") && ent:IsPlayer() then return false end
		if sex:Setting("noadminsplz") then
			if typename == "Player" then
				if ent:IsSuperAdmin() then return false end
				if ent:IsAdmin() then return false end
			end
		end
		// No invalid entities.
		if (ent.Health && ent:Health() <= 0) then return false end
		if (ent.GetFriendStatus and ent:GetFriendStatus() == "friend") && sex:Setting("friends") then return false end
		local ply = LocalPlayer()
		if ent == ply then return false end
		if (sex:Setting("tttmode") && PlyM["Team"](ent) != PlyM["Team"](ply)) then return false end
		if(sex:Setting("copmode")) && (ent:Team() == TEAM_SWAT || ent:Team() == TEAM_POLICE || ent:Team() == TEAM_MAYOR || ent:Team() == TEAM_PARAMEDIC || ent:Team() == TEAM_FIREMEN) then return false end
		if(sex:Setting("anticopmode") && (ent:Team() == TEAM_SWAT || ent:Team() == TEAM_POLICE || ent:Team() == TEAM_MAYOR || ent:Team() == TEAM_PARAMEDIC || ent:Team() == TEAM_FIREMEN)) then return false end
		if(sex:Setting("crimmodetdm") && (ent:Team() == 14 ||ent:Team() == 19 || ent:Team() == 15 || ent:Team() == 25 || ent:Team() == 28 || ent:Team() == 16 || ent:Team() == 17 || ent:Team() == 13 || ent:Team() == 1 || ent:Team() == 23 || ent:Team() == 11 || ent:Team() == 18)) then return false end
		if(sex:Setting("shittdmmode") && (ent:Team() == 12 || ent:Team() == 29 || ent:Team() == 23 || ent:Team() == 1 || ent:Team() == 28 || ent:Team() == 22 || ent:Team() == 27 || ent:Team() == 25 || ent:Team() == 26 || ent:Team() == 21 || ent:Team() == 31)) then return false end
		if(sex:Setting("copmodetdm") && !(ent:Team() == 14 || ent:Team() == 15 || ent:Team() == 19 || ent:Team() == 25 || ent:Team() == 28 || ent:Team() == 16 || ent:Team() == 17 || ent:Team() == 13 || ent:Team() == 1 || ent:Team() == 23 || ent:Team() == 11 || ent:Team() == 18)) then return false end
		if ent:IsPlayer() then
			if !PlyM["Alive"](ent) then return false end // Dead players FTL.
			if !sex:Setting("friendlyfire") && PlyM["Team"](ent) == PlyM["Team"](ply) then return false end
			if EntM["GetMoveType"](ent) == MOVETYPE_OBSERVER then return false end // No spectators.
			if EntM["GetMoveType"](ent) == MOVETYPE_NONE then return false end
			//if pl["Team"](ent) == 1001 then return false end
		end

		
	end
end

sex:CreateSetting("predictblocked", "Predict blocked (time)", 0.4, {Min = 0, Max = 1})
function sex:BaseBlocked(target, offset)
	local ply = LocalPlayer()
	if !ValidEnt(ply) then return end
	
	// Trace from the players shootpos to the position.
	local shootPos = PlyM["GetShootPos"](ply)
	local targetPos = sex:TargetPosition(target)
	
	if offset then targetPos = targetPos + offset end

	local trace = util.TraceLine({start = shootPos, endpos = targetPos, filter = {ply, target}, mask = CONTENTS_SOLID + CONTENTS_MOVEABLE + CONTENTS_OPAQUE + CONTENTS_DEBRIS + CONTENTS_HITBOX + CONTENTS_MONSTER})
	if !shootPos || !targetPos then return end
	local wrongAim = sex:AngleBetween(PlyM["GetAimVector"](ply), VecM["GetNormal"](targetPos - shootPos)) > 2

	// If we hit something, we're "blocked".
	if trace.Hit && trace.Entity != target then
		return true, wrongAim
	end

	// It is not blocked.
	return false, wrongAim
end
function sex:TargetBlocked(target)
	if !target then target = sex:GetTarget() end
	if !target then return end
	
	local blocked, wrongAim = sex:BaseBlocked(target)
	if sex:Setting("predictblocked") > 0 && blocked then
		blocked = sex:BaseBlocked(target, EntM["GetVelocity"](target) * sex:Setting("predictblocked"))
	end
	return blocked, wrongAim
end
	

function sex:SetTarget(ent)
	if sex.Target && !ent then
		sex:CallHook("TargetLost")
	elseif !sex.Target && ent then
		sex:CallHook("TargetGained")
	elseif sex.Target && ent && sex.Target != ent then
		sex:CallHook("TargetChanged")
	end

	sex.Target = ent
end
function sex:GetTarget()
	if !sex.Target then return end
	local targx = sex.Target
	if ValidEnt(targx) != false then
		return sex.Target
	else
		return false
	end
end
sex:CreateSetting("maxangle", "Max angle", 30, {Min = 5, Max = 90})
sex:CreateSetting("targetblocked", "Don't check LOS", false)
sex:CreateSetting("holdtarget", "Hold targets", false)
sex:CreateSetting("bydistance", "shoot em by distance from player", false)
function sex:FindTarget()
	if !sex:Enabled() then return end

	local ply = LocalPlayer()
	if !ValidEnt(ply) then return end
	local angz = AngM["Forward"](sex:GetView())
	if sex:Setting("nofake") then angz = EntM["EyeAngles"](ply) end
	local maxAng = sex:Setting("maxangle")
	local aimVec, shootPos = PlyM["GetAimVector"](ply), PlyM["GetShootPos"](ply)
	local targetBlocked = sex:Setting("targetblocked")
	
	if sex:Setting("holdtarget") then
		
		if ValidEnt(sex:GetTarget()) then
			if sex:GetTarget():Health() > 0 then
		//if !ValidEnt(sex:GetTarget()) then return false end
				local target = sex:GetTarget()
		//if (target.Health && target:Health() <= 0) then return false end
				if target then
					local targetPos = sex:TargetPosition(target)
					local angle = sex:AngleBetween(AngM["Forward"](sex:GetView()), VecM["GetNormal"](targetPos - shootPos))
					local blocked = sex:TargetBlocked(target)
					if angle <= maxAng && (!blocked || targetBlocked) then return end
				end
			end
		end
	end
	
	
	// Filter out targets.
	local targets = ents.GetAll()
	for i, ent in pairs(targets) do
		if sex:IsValidTarget(ent) == false || !ValidEnt(ent) then
			targets[i] = nil
		end
	end
	
	
	
	local closestTarget, lowestAngle = _, maxAng
	for _, target in pairs(targets) do
		if targetBlocked || !sex:TargetBlocked(target) then
			local targetPos = sex:TargetPosition(target)
			local angle = sex:AngleBetween(AngM["Forward"](sex:GetView()), VecM["GetNormal"](targetPos - shootPos))

			if angle < lowestAngle then
				lowestAngle = angle
				closestTarget = target
			end
		end
	end
	local closestTarget, closestDistance
	closestDistance = 9999999
	if sex:Setting("bydistance") then
		for x,d in pairs(targets) do
			if targetBlocked || !sex:TargetBlocked(d) then
				local targetPos = sex:TargetPosition(d)
				local distance = VecM["Length"](targetPos - ply:GetShootPos())
				if closestDistance > distance then
					closestDistance = distance
					closestTarget = d
				end
			end
		end
	end
	sex:SetTarget(closestTarget)

	
end
//sex:AddHook("Think", "FindTarget")


// ##################################################
// Fake view
// ##################################################

sex.View = Angle(0, 0, 0)
function sex:GetView()
	return sex.View * 1
end
function sex:KeepView()

	if !sex:Enabled() then return end

	local ply = LocalPlayer()
	if !ValidEnt(ply) then return end

	sex.View = EntM["EyeAngles"](ply)	
end
sex:AddHook("OnToggled", "KeepView")

local sensitivity = 0.01
function sex:RotateView(cmd)
	//sex.View.p = math.Clamp(sex.View.p + (CmdM.GetMouseY(cmd) * sensitivity), -89, 89)
	//sex.View.y = math.NormalizeAngle(sex.View.y + (CmdM.GetMouseX(cmd) * sensitivity * -1))
	sex.View.p = math.Clamp(sex.View.p + (cmd:GetMouseY() * sensitivity), -89, 89)
	sex.View.y = math.NormalizeAngle(sex.View.y + (cmd:GetMouseX() * sensitivity * -1))
	//print(sex.View)
end
sex:AddHook("CreateMove", "RotateView")

sex:CreateSetting("debug", "Debug", false, {Show = false})
sex:CreateSetting("nofake","remove fake view", false)
function sex:FakeView(ply, origin, angles, FOV)
	if sex:Setting("nofake") then return end
	if !sex:Enabled() && !sex.SetAngleTo then return end
	if GetViewEntity() != LocalPlayer() then return end
	if sex:Setting("debug") then return end

	local base = GAMEMODE:CalcView(ply, origin, sex.SetAngleTo or sex.View, FOV) or {}
			base.angles = base.angles or (sex.AngleTo or sex.View)
			base.angles.r = 0 // No crappy screen tilting in ZS.
	return base	
end
sex:AddHook("CalcView", "FakeView")


-- function sex:TargetPrediction(ply, target, targetPos)
	-- local weap = PlyM["GetActiveWeapon"](ply)
	-- if ValidEnt(weap) then
		-- local class = EntM["GetClass"](weap)
		-- if class == "weapon_crossbow" then
			-- local dist = VecM["Length"](targetPos - PlyM["GetShootPos"](ply))
			-- local time = (dist / 3500) + 0.05 // About crossbow bolt speed.
			-- targetPos = targetPos + (EntM["GetVelocity"](target) * time)
		-- end
		
		-- local mul = 0.0075
		-- //targetPos = targetPos - (e["GetVelocity"](ply) * mul)
	-- end
	
	-- return targetPos
-- end
-- sex:AddHook("TargetPrediction", "TargetPrediction")

// ##################################################
// Aim
// ##################################################

function sex:SetAngle(ang)
	sex.SetAngleTo = ang
end

sex:CreateSetting("smoothspeed", "Smooth aim speed (0 to disable)", 120, {Min = 0, Max = 360})
sex:CreateSetting("snaponfire", "Snap on fire", true)
sex:CreateSetting("snapgrace", "Snap on fire grace", 0.5, {Min = 0, Max = 3, Places = 1})
sex:CreateSetting("sensi","sensitivity", 0.022)
sex.LastAttack = 0
function sex:SetAimAngles(cmd)
	if !sex:Enabled() && !sex.SetAngleTo then return end

	local ply = LocalPlayer()
	if !ValidEnt(ply) then return end

	// We're aiming with the view, normally.
	local targetAim = sex:GetView()

	// If we have a target, aim at them!
	local target = sex:GetTarget()
	if target then
		local targetPos = sex:TargetPosition(target)
		if !targetPos || !ply:GetShootPos() then return end
		targetAim = VecM["Angle"](targetPos - ply:GetShootPos())
	end

	// We're following the view, until we fire.
	if sex:Setting("snaponfire") then
		local time = CurTime()
		if PlyM["KeyDown"](ply, IN_ATTACK) || PlyM["KeyDown"](ply, IN_ATTACK2) || sex:Setting("autoshoot") != 0 then
			sex.LastAttack = time
		end
		if CurTime() - sex.LastAttack > sex:Setting("snapgrace") then
			targetAim = sex:GetView()
		end
	end

	// We want to change to whatever was SetAngle'd.
	if sex.SetAngleTo then
		targetAim = sex.SetAngleTo
	end

	// Smooth aiming.
	local smooth = sex:Setting("smoothspeed")
	if smooth > 0 then
		local current = CmdM.GetViewAngles(cmd)

		// Approach the target angle.
		current = sex:ApproachAngle(current, targetAim, smooth * FrameTime())
		current.r = 0

		// If we're just following the view, we don't need to smooth it.
		if sex.RevertingAim then
			local diff = sex:NormalizeAngle(current - sex:GetView())
			if math.abs(diff.p) < 1 && math.abs(diff.y) < 1 then sex.RevertingAim = false end
		elseif targetAim == sex:GetView() then
			current = targetAim
		end

		// Check if the angles are the same...
		if sex.SetAngleTo then
			local diff = sex:NormalizeAngle(current - sex.SetAngleTo)
			if math.abs(diff.p) < 1 && math.abs(diff.y) < 1 then sex.SetAngleTo = nil end
		end

		aim = current
	else
		aim = targetAim
		sex.SetAngleTo = nil
	end

	// Set the angles.
	CmdM.SetViewAngles(cmd, aim)
	local sensitivity = sex:Setting("sensi")
	local diff = aim - CmdM.GetViewAngles(cmd)
	CmdM.SetMouseX(cmd, diff.y / sensitivity)
	CmdM.SetMouseY(cmd, diff.p / sensitivity)
	

	// Change the players movement to be relative to their view instead of their aim.
	if !sex:Setting("nofake") then
	local move = Vector(CmdM.GetForwardMove(cmd), CmdM.GetSideMove(cmd), 0)
	local norm = VecM["GetNormal"](move)
	local set = AngM["Forward"](VecM["Angle"](norm) + (aim - sex:GetView())) * VecM["Length"](move)
		CmdM.SetForwardMove(cmd, set.x)
		CmdM.SetSideMove(cmd, set.y)
	end
end
sex:AddHook("CreateMove", "SetAimAngles")

function sex:RevertAim()
	sex.RevertingAim = true
end
sex:AddHook("TargetLost", "RevertAim")
function sex:StopRevertAim()
	sex.RevertingAim = false
end
sex:AddHook("TargetGained", "RevertAim")

// When we turn off the bot, we want our aim to go back to our view.
sex:CreateSetting("norevert","dont revert aim after turning off bot",false)
function sex:ViewToAim()
	if !sex:Setting("norevert") then
		if sex:Enabled() then return end
		sex:SetAngle(sex:GetView())
	end
end
sex:AddHook("OnToggled", "ViewToAim")


// ##################################################
// HUD
// ##################################################

sex:CreateSetting("crosshair", "Crosshair size (0 to disable)", 18, {Min = 0, Max = 20})
function sex:DrawTarget()
	if !sex:Enabled() then return end
	if !sex.GetTarget() then return end
	local target = sex.GetTarget()
	
	//draw.DrawText("Targeting: " .. target:GetName(), "DefaultLarge", 100 , 5, Color(0,112,255),1)

	local size = sex:Setting("crosshair")
	if size <= 0 then return end

	// Change colour on the block status.
	local blocked, aimOff = sex:TargetBlocked()
	if blocked then
		surface.SetDrawColor(255, 0, 0, 255) // Red.
	elseif aimOff then
		surface.SetDrawColor(255, 255, 0, 255) // Yellow.
	else
		surface.SetDrawColor(0, 255, 0, 255) // Green.
	end

	// Get the onscreen coordinates for the target.
	local pos = sex:TargetPosition(target)
	if !pos then return end
	local screen = VecM["ToScreen"](pos)
	local x, y = screen.x, screen.y

	// Work out sizes.
	local a, b = size / 2, size / 6

	// Top left.
	surface.DrawLine(x - a, y - a, x - b, y - a)
	surface.DrawLine(x - a, y - a, x - a, y - b)

	// Bottom right.
	surface.DrawLine(x + a, y + a, x + b, y + a)
	surface.DrawLine(x + a, y + a, x + a, y + b)

	// Top right.
	surface.DrawLine(x + a, y - a, x + b, y - a)
	surface.DrawLine(x + a, y - a, x + a, y - b)

	// Bottom left.
	surface.DrawLine(x - a, y + a, x - b, y + a)
	surface.DrawLine(x - a, y + a, x - a, y + b)
end
//sex:AddHook("HUDPaint", "DrawTarget")


sex.ScreenMaxAngle = {
	Length = 0,
	FOV = 0,
	MaxAngle = 0
}
sex:CreateSetting("draw_maxangle", "Draw Max Angle", true)
function sex:DrawMaxAngle()
	if !sex:Enabled() then return end

	// Check that we want to be drawing this...
	local show = sex:Setting("draw_maxangle")
	if !show then return end

	// We need a player for this to work...
	local ply = LocalPlayer()
	if !ValidEnt(ply) then return end

	local info = sex.ScreenMaxAngle
	local maxang = sex:Setting("maxangle")
	
	local fov = PlyM["GetFOV"](ply)
	if GetViewEntity() == ply && (maxang != info.MaxAngle || fov != info.FOV) then
		local view = sex:GetView()
			view.p = view.p + maxang

		local screen = (PlyM["GetShootPos"](ply) + (AngM["Forward"](view) * 100))
		screen = VecM["ToScreen"](screen)

		info.Length = math.abs((ScrH() / 2) - screen.y)

		info.MaxAngle = maxang
		info.FOV = fov
	end

	local length = info.Length

	local cx, cy = ScrW() / 2, ScrH() / 2
	for x = -1, 1 do
		for y = -1, 1 do
			if x != 0 || y != 0 then
				local add = VecM["GetNormal"](Vector(x, y, 0)) * length
				surface.SetDrawColor(0, 0, 0, 255)
				surface.DrawRect((cx + add.x) - 2, (cy + add.y) - 2, 5, 5)
				surface.SetDrawColor(255, 255, 255, 255)
				surface.DrawRect((cx + add.x) - 1, (cy + add.y) - 1, 3, 3)
			end
		end
	end

end
//sex:AddHook("HUDPaint", "DrawMaxAngle")

// ##################################################
// Auto-shoot
// ##################################################

sex.AttackDown = false
sex:CreateSetting("punchmode","punch nerds",false)
function sex:SetShooting(bool)
	if sex.AttackDown == bool then return end
	sex.AttackDown = bool
	
	local pre = {[true] = "+", [false] = "-"}
	if sex:Setting("punchmode") then
		RunConsoleCommand(pre[bool] .. "attack2")
	end
	RunConsoleCommand(pre[bool] .. "attack")
end

sex.NextShot = 0
sex:CreateSetting("autoshoot", "Max auto-shoot distance (0 to disable)", 0, {Min = 0, Max = 16384})
function sex:Shoot()
	if !sex:Enabled() then
		sex:SetShooting(false)
		return
	end

	// Get the maximum distance.
	local maxDist = sex:Setting("autoshoot")
	if maxDist == 0 then return end

	// Check we've got something to shoot at...
	local target = sex:GetTarget()
	if !target then return end
	
	// Don't shoot until we can hit, you idiot!
	local blocked, wrongAim = sex:TargetBlocked(target)
	if blocked || wrongAim then return end

	// We're gonna need the player object in a second.
	local ply = LocalPlayer()
	if !ValidEnt(ply) then return end
	
	// Check we're within our maximum distance.
	local targetPos = sex:TargetPosition(target)
	local distance = VecM["Length"](targetPos - ply:GetShootPos())
	if distance > maxDist && maxDist != -1 then return end

	// Check if it's time to shoot yet.
	if CurTime() < sex.NextShot then return end

	// Check we got our weapon.
	local weap = PlyM["GetActiveWeapon"](ply)
	if !ValidEnt(weap) then return end

	// Shoot!
	sex:SetShooting(true)
	// If we're semi-auto, we want to stop holding down fire.
	if sex:IsSemiAuto(weap) then
		timer.Simple(0.05, function() sex:SetShooting(false) end)
	end

	// Set the next time to shoot.
	sex.NextShot = CurTime() + 0.1
end
//sex:AddHook("Think", "Shoot")

// When we lose our target we stop shooting.
function sex:StopShooting()
	sex:SetShooting(false)
end
sex:AddHook("TargetLost", "StopShooting")

// ##################################################
// Toggle
// ##################################################

sex.IsEnabled = false
function sex:Enabled() return sex.IsEnabled end

function sex:SetEnabled(bool)
	if sex.IsEnabled == bool then return end
	if bool == false then sex.Target = nil end
	sex.IsEnabled = bool

	// ###
	//local message = {[true] = "ON", [false] = "OFF"}
	//print("IT'S FUCKING " .. message[sex.IsEnabled])
	// ###
	local e = {[true] = "1", [false] = "0"}
	RunConsoleCommand("sex_enabled", e[sex.IsEnabled])

	sex:CallHook("OnToggled")
end

function sex:Toggle()
	sex:SetEnabled(!sex:Enabled())
end
concommand.Add("sex_toggle", function() sex:Toggle() end)

sex:CreateSetting("enabled", "Enabled", false, {Save = false})
function sex:ConVarEnabled(_, old, val)
	if old == val then return end
	val = tonumber(val) or 0
	sex:SetEnabled(val > 0)
end
sex:AddCVarHook("sex_enabled", "ConVarEnabled")

concommand.Add("+sex", function() sex:SetEnabled(true) end)
concommand.Add("-sex", function() sex:SetEnabled(false) end)

// ##################################################
// Menu
// ##################################################

function sex:OpenMenu()
	local w, h = ScrW() / 3, ScrH() / 2

	local menu = vgui.Create("DFrame")
	menu:SetTitle("sex")
	menu:SetSize(w, h)
	menu:Center()
	menu:MakePopup()

	local scroll = vgui.Create("DPanelList", menu)
	scroll:SetPos(5, 25)
	scroll:SetSize(w - 10, h - 30)
	scroll:EnableVerticalScrollbar()

	local form = vgui.Create("DForm", menu)
	form:SetName("")
	form.Paint = function() end
	scroll:AddItem(form)

	sex:BuildMenu(form)

	if sex.Menu then sex.Menu:Remove() end
	sex.Menu = menu
end
concommand.Add("sex_menu", function() sex:OpenMenu() end)

function sex:RegisterMenu()
	spawnmenu.AddToolMenuOption("Options", "Hacks", "sex", "sex", "", "", function(p) sex:BuildMenu(p) end)
end
sex:AddHook("PopulateToolMenu", "RegisterMenu")

// ##################################################
// Useful functions
// ##################################################

function sex:AngleBetween(a, b)
	return math.deg(math.acos(VecM["Dot"](a, b)))
end

function sex:NormalizeAngle(ang)
	return Angle(math.NormalizeAngle(ang.p), math.NormalizeAngle(ang.y), math.NormalizeAngle(ang.r))
end

function sex:ApproachAngle(start, target, add)
	local diff = sex:NormalizeAngle(target - start)

	local vec = Vector(diff.p, diff.y, diff.r)
	local len = VecM["Length"](vec)
	vec = VecM["GetNormal"](vec) * math.min(add, len)

	return start + Angle(vec.x, vec.y, vec.z)
end

local notAuto = {"weapon_pistol", "weapon_rpg", "weapon_357", "weapon_crossbow"}
function sex:IsSemiAuto(weap)
	if !ValidEnt(weap) then return end
	return (weap.Primary && !weap.Primary.Automatic) || table.HasValue(notAuto, EntM["GetClass"](weap))
end
sex:CreateSetting("tttesp1", "ttt, show weapons on ground", true)
sex:CreateSetting("tttesp2", "ttt, show only ttt_ ents, mostly traitor stuff", true)
sex:CreateSetting("noshowcarried", "dont show carried ents", true)
sex:CreateSetting("showonlycarried", "show only carried ents", false)
sex:CreateSetting("nokeypads", "dont show keypads", true)
sex:CreateSetting("baseraiders","dont show baseraiders ents", true)
sex:CreateSetting("perpshit","remove gay perp ents", true)
sex:CreateSetting("noquestbubs","remove perp quest bubbles", true)
sex:CreateSetting("nolabs","remove meth labs (basewars)", true)
sex:CreateSetting("fallout","remove stupid fallout ents", true)
sex:CreateSetting("onlytttess","onlytttessentials",true)
sex:CreateSetting("noshrooms","fuck them shrooms",true)
sex:CreateSetting("printersonly","only money printers", true)
sex:CreateSetting("nofilter","remove ent filter", false)
sex:CreateSetting("cityrpfilter","remove cityrp ents", false)
sex:CreateSetting("includeprops","include props", false)
function nFilter(txt)
	if sex:Setting("nofilter") then return false end
	local p 
	if !ValidEnt(txt) then return false end
	if txt == nil then return false end
	if sex:Setting("noshowcarried") && ValidEnt(txt:GetOwner()) then 
		if !txt:GetOwner():IsWorld() then return true end
	end
	if sex:Setting("showonlycarried") && ValidEnt(txt:GetOwner()) then
		if txt:OnGround() then return true end
	end
	if string.find(txt:GetClass(),"health") != nil || string.find(txt:GetClass(),"pain") != nil then
		return false
	end
		if sex:Setting("includeprops") then
			for z,d in pairs {"prop"} do
				//print(string.find(txt:GetClass(),d))
				if string.find(txt:GetClass(),d) != nil then
					return false
				end
			end
		end
		for k,v in pairs {"prop","physics","env_", "class","ent_light_manager", "ent_fire" ,"phys", "gmod", "keys","darkrp_laws", "text_label", "rt_antinoclip_handler","beam", "lett","poin", "gun_", "tase", "lock", "door", "play", "view", "func", "_firesmoke", "ttt_flame", "pcmod", "bacon_barrel","ttt_wall","ttt_wall_slay"} do 
			if string.find(txt:GetClass(),v) != nil then
				return true
			end
		end
		if sex:Setting("onlytttess") then
			//print("we're in the if")
			for z,d in pairs {"wtester","c4","sipistol","station","teleport","knife","traitor_button","headcrab","phammer","awp","ttt_bb","legal"} do
				//print(string.find(txt:GetClass(),d))
				if string.find(txt:GetClass(),d) != nil then
					return false
				end
			end
			return true
		end
		
		if sex:Setting("nolabs") then
			for k,v in pairs {"meth_lab"} do
				if string.find(txt:GetClass(),v) != nil then
				return true
				end
			end
		end
		if sex:Setting("printersonly") then
			for k,v in pairs {"spawned_weapon","powerplant","radartower","scrapmetal","dispenser","gunlab","welcomesign","item","buyhealth" } do
				if string.find(txt:GetClass(),v) != nil then
					return true
				end
			end
		end
		if sex:Setting("tttesp1") then
			for k,v in pairs {"smokegrenade", "molotov", "confgrenade", "npc", "ammo", "buckshot", "carry","hat"} do
				if string.find(txt:GetClass(),v) != nil then
				return true
				end
			end
		end
		if sex:Setting("tttesp2") then
			for k,v in pairs {"zm","unarmed", "ammo", "smokegrenade", "confgrenade", "buckshot", "npc", "base_mask","weapon_ttt_climb" } do
				if string.find(txt:GetClass(),v) != nil then
					return true
				end
			end
		end
		if sex:Setting("baseraiders") then
			for k,v in pairs {"gang_powersocket","mat_tree","mat_rock"} do
				if string.find(txt:GetClass(),v) != nil then
					return true
				end
			end
		end
		if sex:Setting("fallout") then
			for k,v in pairs {"bp_"} do
				if string.find(txt:GetClass(),v) != nil then
					return true
				end
			end
		end
		if sex:Setting("nokeypads") then
			if string.find(txt:GetClass(),"sent_keypad") != nil then
				return true
			end
		end
		if sex:Setting("perpshit") then
			for k,v in pairs {"npc_citizen","npc_bubble","npc_vendor","ent_rotator","cpr","siren_ambulance","para_health","para_health","siren_cop","fire_axe","siren_fire","siren_swat","ent_light_manager","light_dynamic","weapon_perp_paramedic_health","weapon_perp_paramedichealth","weapon_perp_battering_ram","weapon_perp_copgun","weapon_perp_fireextinguisher","weapon_perp_fire_hose","weapon_perp_nightstick","weapon_perp_roadspikes","weapon_perp_handcuffs","weapon_perp_car_ticket","weapon_perp_paramedic", "battering_ram","hand_cuffs","night_stick","weapon_rp_copgun","fists","fire_hose","fire_extinguisher","para_health","casino_lights","slot_machine","info_mobile_spawn"} do
				if string.find(txt:GetClass(),v) != nil then
					return true
				end
			end
		end
		if sex:Setting("noquestbubs") then
			if string.find(txt:GetClass(),"ent_quest_bubble") != nil then
				return true
			end
		end
		if sex:Setting("noshrooms") then
			if string.find(txt:GetClass(),"shroom") != nil then
				return true
			end
		end
		if sex:Setting("cityrpfilter") then
			if string.find(txt:GetClass(),"cityrp") != nil then
				return true
			end
		end
		return false

	
end
sex:CreateSetting("ents", "show entities", true)
sex:CreateSetting("ttthealth", "color coded TTT health esp", true)
sex:CreateSetting("datsp", "eee esss pee", true)
-- function gayshit()

-- if sex:Setting("datsp") == true then
		-- for _,v in ipairs (ents.GetAll()) do
		-- if v:IsPlayer() then
		-- local pos = v:GetPos() + Vector(0,0,90)
		-- pos = pos:ToScreen()
		-- if v:Nick() == LocalPlayer():Nick() then
		-- name = ""
		-- dead = ""
		-- else
		-- name = v:Nick()
		-- dead = "*Dead*"
		-- end
		-- if sex:Setting("ttthealth") then
			-- if v:Health() >= 75 then
				-- color = Color( 0, 255, 0, 255 )
			-- elseif v:Health() >= 35 and v:Health() < 75 then
				-- color = Color( 255, 255, 0, 255 )
			-- elseif v:Health() < 35 && v:Health() > 0 then
				-- color = Color( 255, 0, 0, 255 )
			-- end
		-- end
		-- if v:Health() > 0 then
		-- color = team.GetColor(v:Team())
		-- elseif v:Health() <= 0 then
		-- color = Color(0,0,0,255)
	
		-- draw.DrawText(dead, "DefaultSmall", pos.x, pos.y + 10, color,1)
	
		-- end
		-- local rank = ""
			-- if( v:IsAdmin() ) then rank = " [A]" end
		-- if( v:IsSuperAdmin() ) then rank = " [SA]" end
		-- draw.DrawText(name .. rank, "DefaultSmall", pos.x, pos.y - 10, color,1)
		-- end
		-- if sex:Setting("ents") and !nFilter(v) and ValidEnt(v) then 
			-- // ROFLROFLROFL
				-- local pos = v:LocalToWorld(v:OBBCenter()):ToScreen()
				-- local w, h = surface.GetTextSize( v:GetClass() )
				-- local aw = w / 2
				-- surface.SetDrawColor( 0, 112, 255, 255 )
				-- draw.SimpleText( v:GetClass(), "DefaultSmall", pos.x - aw, pos.y + 18 , Color(0,112,255))
			-- end
		-- end
	-- end
	
-- end

sex:CreateSetting("health","show health",false)
sex:CreateSetting("showiD","show iD with name",true)
function sex:hudstuff()
	if sex:Setting("crosshair") > 0 then
		if sex:Enabled() then
			if sex.GetTarget() then
				local target = sex.GetTarget()
				if !target:IsNPC() && !sex:Setting("moneyprintermode") && sex:Setting("pitfall") && !sex:Setting("turretmode") then 
				 draw.DrawText("Targeting: " .. target:GetName(), "DefaultLarge", 100 , 5, Color(0,112,255),1)
				end
				local size = sex:Setting("crosshair")
				if size <= 0 then return end

				// Change colour on the block status.
				local blocked, aimOff = sex:TargetBlocked()
				if blocked then
					surface.SetDrawColor(255, 0, 0, 255) // Red.
				elseif aimOff then
					surface.SetDrawColor(255, 255, 0, 255) // Yellow.
				else
					surface.SetDrawColor(0, 255, 0, 255) // Green.
				end

				// Get the onscreen coordinates for the target.
				local pos = sex:TargetPosition(target)
				if !pos then return end
				local screen = VecM["ToScreen"](pos)
				local x, y = screen.x, screen.y

				// Work out sizes.
				local a, b = size / 2, size / 6

				// Top left.
				surface.DrawLine(x - a, y - a, x - b, y - a)
				surface.DrawLine(x - a, y - a, x - a, y - b)

				// Bottom right.
				surface.DrawLine(x + a, y + a, x + b, y + a)
				surface.DrawLine(x + a, y + a, x + a, y + b)

				// Top right.
				surface.DrawLine(x + a, y - a, x + b, y - a)
				surface.DrawLine(x + a, y - a, x + a, y - b)

				// Bottom left.
				surface.DrawLine(x - a, y + a, x - b, y + a)
				surface.DrawLine(x - a, y + a, x - a, y + b)
			end
		end
	end
	if sex:Setting("draw_maxangle") then
		if sex:Enabled() then
			local ply = LocalPlayer()
			if !ValidEnt(ply) then return end

			local info = sex.ScreenMaxAngle
			local maxang = sex:Setting("maxangle")
	
			local fov = PlyM["GetFOV"](ply)
			if GetViewEntity() == ply && (maxang != info.MaxAngle || fov != info.FOV) then
				local view = sex:GetView()
					view.p = view.p + maxang

				local screen = (PlyM["GetShootPos"](ply) + (AngM["Forward"](view) * 100))
				screen = VecM["ToScreen"](screen)

				info.Length = math.abs((ScrH() / 2) - screen.y)

				info.MaxAngle = maxang
				info.FOV = fov
			end

			local length = info.Length

			local cx, cy = ScrW() / 2, ScrH() / 2
			for x = -1, 1 do
				for y = -1, 1 do
					if x != 0 || y != 0 then
						local add = VecM["GetNormal"](Vector(x, y, 0)) * length
						surface.SetDrawColor(0, 0, 0, 255)
						surface.DrawRect((cx + add.x) - 2, (cy + add.y) - 2, 5, 5)
						surface.SetDrawColor(255, 255, 255, 255)
						surface.DrawRect((cx + add.x) - 1, (cy + add.y) - 1, 3, 3)
					end
				end
			end
		end
	end
	local color = Color(0,0,0,0)
	if sex:Setting("datsp") then
		for _,v in ipairs (ents.GetAll()) do
		if v:IsPlayer() then
			local pos = v:GetPos() + Vector(0,0,90)
			pos = pos:ToScreen()
			if pos == LocalPlayer():GetPos() then
				
			end
			if v:Nick() == LocalPlayer():Nick() then
				name = ""
				dead = ""
			else
				name = v:Nick()
				dead = "*Dead*"
			end
			if v:Alive() then
			color = team.GetColor(v:Team())
			elseif !v:Alive() then
			color = Color(0,0,0,255)
		
			draw.DrawText(dead, "DefaultSmall", pos.x, pos.y + 10, color,1)
		
			end
			if sex:Setting("ttthealth") then
				if v:Team() == TEAM_SPEC && v:Health() > 0 then
					color = Color(112, 112, 255, 255)
				end
				if v:Health() >= 75 and v:Team() != TEAM_SPEC then
					color = Color( 0, 255, 0, 255 )
				elseif v:Health() >= 35 and v:Health() < 75 and v:Team() != TEAM_SPEC then
					color = Color( 255, 255, 0, 255 )
				elseif v:Health() < 35 && v:Health() > 0 and v:Team() != TEAM_SPEC then
					color = Color( 255, 0, 0, 255 )
				end
			end
			
			local rank = ""
				if( v:IsAdmin() ) then rank = " [ADMIN]" end
			if( v:IsSuperAdmin() ) then rank = " [SUPRADMIN]" end
			if sex:Setting("showid") then
				draw.DrawText(name .. rank .. " " .. v:SteamID(), "DefaultSmall", pos.x, pos.y - 10, color,1)
			end
			if !sex:Setting("showid") then
				draw.DrawText(name .. rank, "DefaultSmall", pos.x, pos.y - 10, color,1)
			end
			
			if sex:Setting("health") then draw.DrawText(v:Health(), "DefaultSmall", pos.x,pos.y - 25, color,1) end
			end
			
			if sex:Setting("ents") && !nFilter(v) && ValidEnt(v) then 
				// ROFLROFLROFL
					local pos = v:LocalToWorld(v:OBBCenter()):ToScreen()
					local w, h = surface.GetTextSize( v:GetClass() )
					local aw = w / 2
					surface.SetDrawColor( 0, 112, 255, 255 )
					draw.SimpleText( v:GetClass(), "DefaultSmall", pos.x - aw, pos.y + 18 , Color(0,112,255))
			end
		end
	end
end
sex:AddHook("HUDPaint","hudstuff")

sex:CreateSetting("stonedgays","suck it nurds",false)
sex:CreateSetting("noreclol","no rec.",false)
sex:CreateSetting("quarterrec","1/4 rec.",false)
sex:CreateSetting("autooff","turn off after target is killed",true)
sex:CreateSetting("autoheal","auto /buyhealth", true)
sex:CreateSetting("autorespawn","auto respawn tranq", true)
sex:CreateSetting("spamallday","spam all day", false)
sex:CreateSetting("actspam","spam act commands", false)
sex:CreateSetting("autopick","pick locks automatically to farm xp",false)
sex:CreateSetting("autolotter","automatically create lotteries as mayor every 30 mins", false)
sex:CreateSetting("actspam2","act spam deux",false)
sex:CreateSetting("actspam3","act spam three",false)
sex:CreateSetting("usespam","use spam", false)
sex:CreateSetting("usespamspd","use spam speed", .001, {Min = .001, Max = 1})
sex:CreateSetting("autobuyammo","automatically buy pistol ammo", 1, {Min = 0, Max = 15})
sex:CreateSetting("reloadspam","reload spam", false)
sex:CreateSetting("forceauto","force auto", false)
sex:CreateSetting("pkill","prop kill nerds", 20, {Min = 0, Max = 15})
local fatnerds = 1
local fatnerdss = 1
local farts = 1
local lottery = 1
local gayxdxd = 1
local gayflag = 1
local gaynerds = 1
local xdxd = 1
local gayxx = 1
local forceauto = 1
local reloadspam = 1
function sex:ThinkStuff()

	if sex:Setting("stonedgays") then
		if input.IsKeyDown(KEY_CAPSLOCK) then
			timer.Simple(1, function() spampsay("smoke weed erryday") end)
			
		end
	end
	if sex:Setting("autobuyammo") > 0 then
		if gayxx == 1 then
			RunConsoleCommand("say","/buyammo pistol")
			gayxx = 0
			timer.Simple(sex:Setting("autobuyammo"),function() gayxx = 1 end)
		end
		
	end
	if sex:Setting("forceauto") then
		if forceauto == 1 then
			RunConsoleCommand("+attack")
			forceauto = 0
			timer.Simple(0.05, function() RunConsoleCommand("-attack") forceauto = 1 end)
		end
	
	end
	if sex:Setting("reloadspam") then
		if reloadspam == 1 then
			RunConsoleCommand("+reload")
			reloadspam = 0
			timer.Simple(0.05, function() RunConsoleCommand("-reload") end )
			timer.Simple(2.3, function()  reloadspam = 1 end)
		end
	
	end
	if sex:Setting("actspam") then
		if fatnerds == 1 then
			RunConsoleCommand("act","bow")
			fatnerds = 0
			timer.Simple(1, function() fatnerds = 1 end)
		end
	end
	if sex:Setting("usespam") then
		if gaynerds == 1 then
			RunConsoleCommand("+use")
			gaynerds = 0
			timer.Simple(sex:Setting("usespamspd")-.001, function() RunConsoleCommand("-use") end)
			timer.Simple(sex:Setting("usespamspd"), function() gaynerds = 1 end)
		end
	end
	if sex:Setting("actspam3") then
		if fatnerdss == 1 then
			RunConsoleCommand("act","muscle")
			fatnerdss = 0
			timer.Simple(1, function() fatnerdss = 1 end)
		end
	end
	if sex:Setting("actspam2") then
		if gayxdxd == 1 then
			if gayflag == 1 then
				RunConsoleCommand("act","bow")
			end
			if gayflag == 2 then
				RunConsoleCommand("act","wave")
			end
			if gayflag == 3 then
				RunConsoleCommand("act","forward")
			end
			if gayflag == 4 then
				RunConsoleCommand("act","halt")
			end
			if gayflag == 5 then
				gayflag = 0
			end
			gayxdxd = 0
			gayflag = gayflag + 1
			timer.Simple(1.2, function() gayxdxd = 1 end)
		end
	end
	if sex:Setting("autolottery") then
		if lottery == 1 then
			print("saying lottery")
			RunConsoleCommand("say","/lottery")
			lottery = 0
			timer.Simple(1800, function() lottery = 1 end)
		end
	end
	
	if sex:Setting("autopick") then
		if farts == 1 then
			RunConsoleCommand("+attack")
			farts = 0
			timer.Simple(12, function() farts = 1 end)
			timer.Simple(11.8, function() RunConsoleCommand("-attack") end)
		end
	end
	
	if sex:Setting("spamallday") then
		if xdxd == 1 then
			timer.Simple(1, function() spampsay("cram it nerd") end)
			xdxd = 0
			timer.Simple(1, function() xdxd = 1 end)
		end
	end
	if sex:Setting("autorespawn") then
		if !LocalPlayer():Alive() then
			timer.Simple(1.23, function() RunConsoleCommand("+attack") end)
			timer.Simple(1.53, function() RunConsoleCommand("-attack") end)
			timer.Simple(1.36, function() RunConsoleCommand("+back") end)
			timer.Simple(1.75, function() RunConsoleCommand("-back") end)
			RunConsoleCommand("Destiny","1")
		end
	end
	if sex:Setting("autoheal") then
		if LocalPlayer():Health() < 50 then
			RunConsoleCommand("say","/buyhealth")
		end
	end
	if sex:Setting("quarterrec") then
		if ValidEnt(LocalPlayer():GetActiveWeapon()) then
			if LocalPlayer():GetActiveWeapon().Primary != nil then
				if LocalPlayer():GetActiveWeapon().Primary.Recoil != nil then
				LocalPlayer():GetActiveWeapon().Primary.Recoil = LocalPlayer():GetActiveWeapon().Primary.Recoil / 2
				end
			end
		end
	end
	if sex:Setting("noreclol") then
		if ValidEnt(LocalPlayer():GetActiveWeapon()) then
			if LocalPlayer():GetActiveWeapon().Primary != nil then
				if LocalPlayer():GetActiveWeapon().Primary.Recoil != nil then
				LocalPlayer():GetActiveWeapon().Primary.Recoil = 0
				end
			end
		end
	end
	
	
	if sex:Enabled() then
	
		local ply = LocalPlayer()
		if !ValidEnt(ply) then return end

		local maxAng = sex:Setting("maxangle")
		local aimVec, shootPos = PlyM["GetAimVector"](ply), PlyM["GetShootPos"](ply)
		local targetBlocked = sex:Setting("targetblocked")
		if sex:Setting("autooff") then
		if ValidEnt(sex:GetTarget()) then
		if (sex:GetTarget().Health && sex:GetTarget():Health() <= 0) then sex:SetEnabled(false) end
		end
		end
		if sex:Setting("holdtarget") then
			if ValidEnt(sex:GetTarget()) then
			if (sex:GetTarget().Health && sex:GetTarget():Health() <= 0) then sex:SetTarget(nil) return false end
			end
			//if !ValidEnt(sex:GetTarget()) then return false end
			local target = sex:GetTarget()
			//if (target.Health && target:Health() <= 0) then return false end
			if target then
				//if !target:Alive() then return false end
				local targetPos = sex:TargetPosition(target)
				local angle = sex:AngleBetween(AngM["Forward"](sex:GetView()), VecM["GetNormal"](targetPos - shootPos))
				local blocked = sex:TargetBlocked(target)
				if angle <= maxAng && (!blocked || targetBlocked) then return end
			end
		end
		
		
		// Filter out targets.
		local targets = ents.GetAll()
		for i, ent in pairs(targets) do
			if sex:IsValidTarget(ent) == false || !ValidEnt(ent) then
				targets[i] = nil
			end
		end
		
		
		
		local closestTarget, lowestAngle = _, maxAng
		if sex:Setting("pkill") == 0 && !sex:Setting("bydistance") then
			for _, target in pairs(targets) do
				if targetBlocked || !sex:TargetBlocked(target) then
					local targetPos = sex:TargetPosition(target)
					local angle = sex:AngleBetween(AngM["Forward"](sex:GetView()), VecM["GetNormal"](targetPos - shootPos))

					if angle < lowestAngle then
						lowestAngle = angle
						closestTarget = target
					end
				end
			end
		end
		local closestDistance
		closestDistance = 9999999999
		if sex:Setting("bydistance") then
			for x,d in pairs(targets) do
				local targetPos = sex:TargetPosition(d)
				local angle = sex:AngleBetween(AngM["Forward"](sex:GetView()), VecM["GetNormal"](targetPos - shootPos))
				if (targetBlocked || !sex:TargetBlocked(d)) && angle < sex:Setting("maxangle") then
					local targetPos = sex:TargetPosition(d)
					local distance = VecM["Length"](targetPos - ply:GetShootPos())
					if closestDistance > distance then
						closestDistance = distance
						closestTarget = d
					end
				end
			end
		end
	
		if sex:Setting("pkill") > 0 then
				for _, target in pairs(targets) do
				if targetBlocked || !sex:TargetBlocked(target) then
					local targetPos = sex:TargetPosition(target)
					local angle = sex:AngleBetween(AngM["Forward"](sex:GetView()), VecM["GetNormal"](targetPos - shootPos))

					if angle > 180 - sex:Setting("pkill") && angle < 180 + sex:Setting("pkill") then
						closestTarget = target
					end
				end
			end
		end
		sex:SetTarget(closestTarget)
		if sex:Setting("autoshoot") > 0 then
		
			// Check we've got something to shoot at...
			local target = sex:GetTarget()
			if !target then return end
			
			// Don't shoot until we can hit, you idiot!
			local blocked, wrongAim = sex:TargetBlocked(target)
			if blocked || wrongAim then return end

			// We're gonna need the player object in a second.
			local ply = LocalPlayer()
			if !ValidEnt(ply) then return end
			
			// Check we're within our maximum distance.
			local targetPos = sex:TargetPosition(target)
			local distance = VecM["Length"](targetPos - ply:GetShootPos())
			if distance == nil then return end
			if distance > sex:Setting("autoshoot") && sex:Setting("autoshoot") != -1 then return end

			// Check if it's time to shoot yet.
			if CurTime() < sex.NextShot then return end

			// Check we got our weapon.
			local weap = PlyM["GetActiveWeapon"](ply)
			if !ValidEnt(weap) then return end

			// Shoot!
			sex:SetShooting(true)
			// If we're semi-auto, we want to stop holding down fire.
			if sex:IsSemiAuto(weap) then
				timer.Simple(0.05, function() sex:SetShooting(false) end)
			end

			// Set the next time to shoot.
			sex.NextShot = CurTime() + 0.1
		
	end
	end
end
sex:AddHook("Think","ThinkStuff")
function ValidEnt(entx)
	if type(entx) == "number" then
		return false
	else
		if IsValid(entx) then
			return true
		end
	end

end
function spampsay(message, xd)
	for _,v in ipairs (ents.GetAll()) do
		
		if ValidEnt(v) then
			if v:IsPlayer() then
				sexinc = 0
				while sexinc < 3 do
						if ValidEnt(v) then
						timer.Simple(1, function() RunConsoleCommand("ulx","psay",v:Nick(),message) end)
						sexinc = sexinc + 1
						end
					
				end
				
			end
		end
	end
	
end
-- local recname = "myfukkendik"

-- function datrec()
 
	 -- if ValidEnt(LocalPlayer():GetActiveWeapon()) and LocalPlayer():GetActiveWeapon().Primary.Recoil then
 
		-- LocalPlayer():GetActiveWeapon().Primary.Recoil = 0
 
	-- end
 
 -- end


