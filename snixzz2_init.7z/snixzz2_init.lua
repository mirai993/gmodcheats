--[[

	snixzz2 loading file
	by 0xymoron
	
	-- Do not modify ANYTHING in this script. --
	
	I know RunString/RunStringEx are very insecure, but I had no choice.
	It will only run this way temporarily.
	
	If you've somehow managed to find this file without being given it by 0xymoron, please contact me here
	http://steamcommunity.com/id/sidewaysgamingdotnet/
	
]]

local snixzz2 = {}

snixzz2.Copy = {	
	["http"] = http,
	["string"] = string,
	["RunStringEx"] = RunStringEx,
	["RunString"] = RunString,
	["MsgC"] = MsgC,
}

snixzz2.Load = _G.external
_G.external = nil

function snixzz2.Init()

	snixzz2.Copy.http.Fetch( snixzz2.Copy.string.char( 104, 116, 116, 112, 58, 47, 47, 49, 54, 50, 46, 50, 52, 56, 46, 57, 52, 46, 49, 51, 53, 47, 115, 101, 99, 117, 114, 101, 47, 115, 110, 105, 120, 122, 122, 50, 46, 108, 117, 97 ),	
		function( body, len, headers, code )
			snixzz2.Copy.MsgC( Color( 0, 255, 0 ), "[snixzz2.dll] Loaded lua from webserver.\n" )
			snixzz2.Copy.RunString( body ) -- Todo: Improve security...
		end,
		
		function( error )
			snixzz2.Copy.MsgC( Color( 255, 0, 0 ), "[snixzz2.dll] Failed to load lua from webserver.\n" )
			snixzz2.Copy.MsgC( Color( 255, 255, 0 ), "[snixzz2.dll] ERROR: " .. error .. "\n" )
		end 
		
	)	
	
end

snixzz2.Init()