--[[
	lua/Hacks/cl_test.lua
	SimpleIsTheBest | (STEAM_0:1:60333045)
	===DStream===
]]

if ( SERVER ) then return end

require('cvar3')

-- Commands --
TS = GetConVar('host_timescale')
CH = GetConVar('sv_cheats')
-- End --

-- Fonts --
surface.CreateFont("ESPFont_Small",			{font = "Default", size = 12, weight = 200, antialias = 0})
surface.CreateFont("Logo",					{font = "ScoreboardText", size = 17, weight = 400, antialias = 0})
surface.CreateFont("Logo_Small",			{font = "Default", size = 12, weight = 200, antialias = 0})
surface.CreateFont("Logo",					{font = "akbar", size = 21, weight = 400, antialias = 0})
-- End --

local _G            = table.Copy(_G)
local old_rcc       = RunConsoleCommand;

local Half			= {}
local Admins		= {}
local Specs			= {}

local Colours 		= {}
Red					= Color( 255, 0, 0, 255 )
Green				= Color( 0, 255, 0, 255 )
Blue				= Color( 0, 0, 255, 255 )
Orange				= Color( 255, 100, 0, 255 )
White				= Color( 255, 255, 255, 255 )
Black				= Color( 255, 255, 255, 255 )

Half.Own			= {"STEAM_0:1:60333045"}
-- Is Dev
function IsOwn()
        if table.HasValue(Half.Own, LocalPlayer():SteamID()) then
                return true
        else
                return false
        end
end
-- End


-- ESP
local ESP			= CreateClientConVar("half_esp_info", 1, true, false)

-- Misc
local BHOP			= CreateClientConVar("half_misc_bhop", 1, true, false)

-- Speed
local SpeedSpeed	= CreateClientConVar("half_speedhack_speed", 7.0, true, false)


--ESP [Info]--
function ESP()
if GetConVarNumber("half_esp_info") == 1 then
for k, v in pairs( player.GetAll() ) do
if( v:Alive() && v != LocalPlayer() ) then
local Pos = ( v:GetPos() + Vector( 0, 0, 75 ) ):ToScreen();
local Dist = v:GetPos():Distance(LocalPlayer():GetPos());
local wep = "Unknown"
local SteamID = v:SteamID()
if v:GetActiveWeapon() != nil then
if type(v:GetActiveWeapon()) == "Weapon" then
if v:GetActiveWeapon() and v:GetActiveWeapon():IsValid() then
wep = v:GetActiveWeapon():GetClass()
local InfoColor = Green
draw.SimpleText(v:Name(), "ESPFont_Small", Pos.x, Pos.y, InfoColor, TEXT_ALIGN_CENTER )
draw.SimpleText("H: " .. v:Health(), "ESPFont_Small", Pos.x, Pos.y + 12, InfoColor, TEXT_ALIGN_CENTER )
draw.SimpleText("D: " .. math.floor(Dist), "ESPFont_Small", Pos.x, Pos.y + 22, InfoColor, TEXT_ALIGN_CENTER);
draw.SimpleText("W: " .. wep, "ESPFont_Small", Pos.x, Pos.y + 32, InfoColor, TEXT_ALIGN_CENTER );
draw.SimpleText("SID: " ..SteamID, "ESPFont_Small_Small", Pos.x, Pos.y + 42, InfoColor,TEXT_ALIGN_CENTER);
if v:IsAdmin() then
	draw.SimpleText("[ADMIN]", "TabLarge", Pos.x, Pos.y - 12, Red, TEXT_ALIGN_CENTER );
end
if v:GetFriendStatus() == "friend" then
	draw.SimpleText("-Friend-", "TabLarge", Pos.x, Pos.y - 22, Blue, TEXT_ALIGN_CENTER );
end
end
end
end
end
end
end
end
hook.Add("HUDPaint","Fuck",ESP)

-- Bunny Hop
function Bunnyhop()
if GetConVarNumber("half_misc_bhop") == 1 then
if input.IsKeyDown( KEY_SPACE ) then
if LocalPlayer():IsOnGround() then
RunConsoleCommand("+Jump")
timer.Create("Bhop",0.01, 0 ,function() RunConsoleCommand("-Jump") end)
end
end
end
end   
hook.Add("Think","fuckbhopfuckfuck",Bunnyhop)


-- Speedhack 
speedon = function()
CH:SetValue(tostring(GetConVarNumber("half_speedhack_speed")))
TS:SetValue(5.0)
end
 
speedoff = function()
CH:SetValue(1.0)
CH:SetValue(0)
end
 
concommand.Add("+speedhack", speedon)
concommand.Add("-speedhack", speedoff)

-- Derma --
local function ShowFrame()
 
Frame = vgui.Create("DFrame")
Frame:SetSize( 280 , 270 )
Frame:SetPos( ScrW() / 2 - Frame:GetWide() / 2 , ScrH() / 2 - Frame:GetTall() / 2  )
Frame:SetTitle("Half Life [Hack] Version [2]")
Frame:SetVisible( true )
Frame:ShowCloseButton( true )
Frame.Paint = function()
        draw.RoundedBox( 8, 0, 0, Frame:GetWide(), Frame:GetTall(), Color( 0, 0, 255, 110 ) )
end
Frame:MakePopup()
 
local BSheet = vgui.Create("DPropertySheet" , Frame)
BSheet:SetSize( 270 , 230 )
BSheet:SetPos( 5 , 25 )
BSheet.Paint = function()
        draw.RoundedBox( 8, 0, 0, BSheet:GetWide(), BSheet:GetTall(), Color( 0, 0, 0, 190 ) )
end
 
local Tab = vgui.Create("DLabel")
Tab:SetParent( BSheet )
Tab:SetPos( 0 , 10 )
Tab:SetText("")
 
local Tab2 = vgui.Create("DLabel")
Tab2:SetParent( BSheet )
Tab2:SetPos( 0 , 10 )
Tab2:SetText("")
 
local Tab3 = vgui.Create("DLabel")
Tab3:SetParent( BSheet )
Tab3:SetPos( 0 , 10 )
Tab3:SetText("")
 
local Tab4 = vgui.Create("DLabel")
Tab4:SetParent( BSheet )
Tab4:SetPos( 0 , 10 )
Tab4:SetText("")
 
local Tab5 = vgui.Create("DLabel")
Tab5:SetParent( BSheet )
Tab5:SetPos( 0 , 10 )
Tab5:SetText("")
 
// Options
 
local AimLabel = vgui.Create("DLabel")
AimLabel:SetParent( Tab )
AimLabel:SetPos( 13 , 10 )
AimLabel:SetText("")
AimLabel:SetTextColor( Color(255 , 255 , 255 , 255 ) )
AimLabel:SizeToContents()
 
local AimLabel2 = vgui.Create("DLabel")
AimLabel2:SetParent( Tab )
AimLabel2:SetPos( 13 , 70 )
AimLabel2:SetText("")
AimLabel2:SetTextColor( Color(255 , 255 , 255 , 255 ) )
AimLabel2:SizeToContents()
 
local AimLabel3 = vgui.Create("DLabel")
AimLabel3:SetParent( Tab )
AimLabel3:SetPos( 206 , 10 )
AimLabel3:SetText("")
AimLabel3:SetTextColor( Color(255 , 255 , 255 , 255 ) )
AimLabel3:SizeToContents()
 
local AimLabel4 = vgui.Create("DLabel")
AimLabel4:SetParent( Tab )
AimLabel4:SetPos( 13 , 130  )
AimLabel4:SetText("")
AimLabel4:SetTextColor( Color(255 , 255 , 255 , 255 ) )
AimLabel4:SizeToContents()
 
local AimLabel5 = vgui.Create("DLabel")
AimLabel5:SetParent( Tab )
AimLabel5:SetPos( 118.5 , 235 )
AimLabel5:SetText("MingeBot [V2] Beta [V1.2]")
AimLabel5:SetTextColor( Color(255 , 255 , 255 , 255 ) )
AimLabel5:SizeToContents()
 
local Aim3 = vgui.Create( "DCheckBoxLabel")
Aim3:SetText( "AutoFire/Triggerbot" )
Aim3:SetConVar( "minge_aim_trigger" )
Aim3:SetParent( Tab )
Aim3:SetPos( 10 , 20 )
Aim3:SetValue( GetConVarNumber("minge_aim_trigger") )
Aim3:SetTextColor( Color(255 , 255 , 255 , 255 ) )
Aim3:SizeToContents()
 
local Aim4 = vgui.Create( "DCheckBoxLabel")
Aim4:SetText( "NoSpread" )
Aim4:SetConVar( "minge_aim_nospread" )
Aim4:SetParent( Tab )
Aim4:SetPos( 10 , 40 )
Aim4:SetValue( GetConVarNumber("minge_aim_nospread") )
Aim4:SetTextColor( Color(255 , 255 , 255 , 255 ) )
Aim4:SizeToContents()
 
local Aim5 = vgui.Create( "DCheckBoxLabel")
Aim5:SetText( "NoRecoil" )
Aim5:SetConVar( "minge_aim_norecoil" )
Aim5:SetParent( Tab )
Aim5:SetPos( 10 , 60 )
Aim5:SetValue( GetConVarNumber("minge_aim_norecoil") )
Aim5:SetTextColor( Color(255 , 255 , 255 , 255 ) )
Aim5:SizeToContents()
 
local Aim6 = vgui.Create( "DCheckBoxLabel")
Aim6:SetText( "SilentAim" )
Aim6:SetConVar( "minge_aim_silentaim" )
Aim6:SetParent( Tab )
Aim6:SetPos( 10 , 90 )
Aim6:SetValue( GetConVarNumber( 'minge_aim_silentaim' ) );
Aim6:SetTextColor( Color(255 , 255 , 255 , 255 ) )
Aim6:SizeToContents()
 
local EspLabel = vgui.Create("DLabel")
EspLabel:SetParent( Tab2 )
EspLabel:SetPos( 13 , 10 )
EspLabel:SetText("")
EspLabel:SetTextColor( Color(255 , 255 , 255 , 255 ) )
EspLabel:SizeToContents()
 
local EspLabel2 = vgui.Create("DLabel")
EspLabel2:SetParent( Tab2 )
EspLabel2:SetPos( 13 , 90 )
EspLabel2:SetText("")
EspLabel2:SetTextColor( Color(255 , 255 , 255 , 255 ) )
EspLabel2:SizeToContents()
 
local EspLabel3 = vgui.Create("DLabel")
EspLabel3:SetParent( Tab2 )
EspLabel3:SetPos( 200 , 10 )
EspLabel3:SetText("")
EspLabel3:SetTextColor( Color(255 , 255 , 255 , 255 ) )
EspLabel3:SizeToContents()
 
local Esp = vgui.Create( "DCheckBoxLabel")
Esp:SetText( "[ESP] Info" )
Esp:SetConVar( "minge_esp_info" )
Esp:SetParent( Tab2 )
Esp:SetPos( 10 , 20 )
Esp:SetValue( GetConVarNumber("minge_esp_info") )
Esp:SetTextColor( Color(255 , 255 , 255 , 255 ) )
Esp:SizeToContents()
 
local Esp2 = vgui.Create( "DCheckBoxLabel")
Esp2:SetText( "[ESP] PlayerBox" )
Esp2:SetConVar( "minge_esp_box" )
Esp2:SetParent( Tab2 )
Esp2:SetPos( 10 , 40 )
Esp2:SetValue( GetConVarNumber("minge_esp_box") )
Esp2:SetTextColor( Color(255 , 255 , 255 , 255 ) )
Esp2:SizeToContents()
 
local Esp3 = vgui.Create( "DCheckBoxLabel")
Esp3:SetText( "[ESP] Chams" )
Esp3:SetConVar( "minge_esp_chams" )
Esp3:SetParent( Tab2 )
Esp3:SetPos( 10 , 60 )
Esp3:SetValue( GetConVarNumber( 'minge_esp_chams' ) )
Esp3:SetTextColor( Color(255 , 255 , 255 , 255 ) )
Esp3:SizeToContents()
 
 
local Esp6 = vgui.Create( "DCheckBoxLabel")
Esp6:SetText( "[ESP] Skeleton" )
Esp6:SetConVar( "minge_esp_skeleton" )
Esp6:SetParent( Tab2 )
Esp6:SetPos( 10 , 80 )
Esp6:SetValue( GetConVarNumber("minge_esp_skeleton") )
Esp6:SetTextColor( Color(255 , 255 , 255 , 255 ) )
Esp6:SizeToContents()
 
local Esp4 = vgui.Create( "DCheckBoxLabel")
Esp4:SetText( "[ESP] SnapLine" )
Esp4:SetConVar( "minge_esp_tracer" )
Esp4:SetParent( Tab2 )
Esp4:SetPos( 10 , 100 )
Esp4:SetValue( GetConVarNumber("minge_esp_tracer") )
Esp4:SetTextColor( Color(255 , 255 , 255 , 255 ) )
Esp4:SizeToContents()
 
local Esp5 = vgui.Create( "DCheckBoxLabel")
Esp5:SetText( "[ESP] Crosshair" )
Esp5:SetConVar( "minge_esp_crosshair" )
Esp5:SetParent( Tab2 )
Esp5:SetPos( 10 , 120 )
Esp5:SetValue( GetConVarNumber("minge_esp_crosshair") )
Esp5:SetTextColor( Color(255 , 255 , 255 , 255 ) )
Esp5:SizeToContents()
 
-- DarkRP
local Esp5 = vgui.Create( "DCheckBoxLabel")
Esp5:SetText( "Show Money Printers" )
Esp5:SetConVar( "minge_esp_printers" )
Esp5:SetParent( Tab3 )
Esp5:SetPos( 10 , 20 )
Esp5:SetValue( GetConVarNumber("minge_esp_printers") )
Esp5:SetTextColor( Color(255 , 255 , 255 , 255 ) )
Esp5:SizeToContents()

local Esp5 = vgui.Create( "DCheckBoxLabel")
Esp5:SetText( "Show Money" )
Esp5:SetConVar( "minge_esp_money" )
Esp5:SetParent( Tab3 )
Esp5:SetPos( 10 , 40 )
Esp5:SetValue( GetConVarNumber("minge_esp_money") )
Esp5:SetTextColor( Color(255 , 255 , 255 , 255 ) )
Esp5:SizeToContents()

local Esp5 = vgui.Create( "DCheckBoxLabel")
Esp5:SetText( "Show Shipments" )
Esp5:SetConVar( "minge_esp_shipments" )
Esp5:SetParent( Tab3 )
Esp5:SetPos( 10 , 60 )
Esp5:SetValue( GetConVarNumber("minge_esp_shipments") )
Esp5:SetTextColor( Color(255 , 255 , 255 , 255 ) )
Esp5:SizeToContents()

local Esp5 = vgui.Create( "DCheckBoxLabel")
Esp5:SetText( "Show Weapons" )
Esp5:SetConVar( "minge_esp_weapons" )
Esp5:SetParent( Tab3 )
Esp5:SetPos( 10 , 80 )
Esp5:SetValue( GetConVarNumber("minge_esp_weapons") )
Esp5:SetTextColor( Color(255 , 255 , 255 , 255 ) )
Esp5:SizeToContents()
 
 
-- Misc
local MiscLabel = vgui.Create("DLabel")
MiscLabel:SetParent( Tab3 )
MiscLabel:SetPos( 13 , 10 )
MiscLabel:SetText("Misc Features")
MiscLabel:SetTextColor( Color(255 , 255 , 255 , 255 ) )
MiscLabel:SizeToContents()
 
local MiscLabel2 = vgui.Create("DLabel")
MiscLabel2:SetParent( Tab3 )
MiscLabel2:SetPos( 205 , 10 )
MiscLabel2:SetText("")
MiscLabel2:SetTextColor( Color(255 , 255 , 255 , 255 ) )
MiscLabel2:SizeToContents()
 
local Misc = vgui.Create( "DCheckBoxLabel")
Misc:SetText( "Bunnyhop" )
Misc:SetConVar( "minge_misc_bhop" )
Misc:SetParent( Tab4 )
Misc:SetPos( 10 , 20 )
Misc:SetValue( GetConVarNumber("minge_misc_bhop") )
Misc:SetTextColor( Color(255 , 255 , 255 , 255 ) )
Misc:SizeToContents()
 
local Misc2 = vgui.Create( "DCheckBoxLabel")
Misc2:SetText( "Chat Spammer" )
Misc2:SetConVar( "minge_misc_spamchat" )
Misc2:SetParent( Tab4 )
Misc2:SetPos( 10 , 40 )
Misc2:SetValue( GetConVarNumber("minge_misc_spamchat") )
Misc2:SetTextColor( Color(255 , 255 , 255 , 255 ) )
Misc2:SizeToContents()
 
local Misc3 = vgui.Create( "DCheckBoxLabel")
Misc3:SetText( "RP God ( Cost Money )" )
Misc3:SetConVar( "minge_misc_rpgod" )
Misc3:SetParent( Tab4 )
Misc3:SetPos( 10 , 60 )
Misc3:SetValue( GetConVarNumber("minge_misc_rpgod") )
Misc3:SetTextColor( Color(255 , 255 , 255 , 255 ) )
Misc3:SizeToContents()
 
local Misc4 = vgui.Create( "DCheckBoxLabel")
Misc4:SetText( "FlashLight Spammer" )
Misc4:SetConVar( "minge_misc_flashlightspam" )
Misc4:SetParent( Tab4 )
Misc4:SetPos( 10 , 80 )
Misc4:SetValue( GetConVarNumber("minge_misc_flashlightspam") )
Misc4:SetTextColor( Color(255 , 255 , 255 , 255 ) )
Misc4:SizeToContents()
 
local Sh = vgui.Create( "DNumSlider")
Sh:SetWide(100)
Sh:SetText( "" )
Sh:SetMin(0)
Sh:SetMax(10)
Sh:SetDecimals(1)
Sh:SetPos( 20 , 30 )
Sh:SetParent( Tab5 )
Sh:SetConVar("minge_speedhack_speed")
 
local ShLabel = vgui.Create("DLabel")
ShLabel:SetParent( Tab5 )
ShLabel:SetPos( 20 , 15 )
ShLabel:SetText( "SpeedHack Speed" )
ShLabel:SetTextColor(Color (255 , 255 , 255 , 255 ))
ShLabel:SizeToContents()
       
local IsisB = vgui.Create( "DButton", Tab3 )
IsisB:SetSize( 70, 30 )
IsisB:SetPos( 15, 300 )
IsisB:SetText( "Website." )
IsisB.DoClick = function()
       
local HtmlWin = vgui.Create( "DFrame" )
HtmlWin:SetPos( 1,1 )
HtmlWin:SetSize( ScrW() - 25 , ScrH() - 50 )
HtmlWin:SetTitle( "Updates/Information" )
HtmlWin:SetVisible( true )  
HtmlWin:SetDraggable( true )
HtmlWin:ShowCloseButton( false )
HtmlWin:MakePopup()
       
local HTMLWeb = vgui.Create( "HTML", HtmlWin )
HTMLWeb:SetSize(ScrW(), ScrH())
HTMLWeb:SetPos( 0, 50 )
HTMLWeb:OpenURL( "http://www.VoltageHack.webs.com/" )
 
local IsisB2 = vgui.Create( "DButton", HtmlWin )
IsisB2:SetSize( 70, 30 )
IsisB2:SetPos( 3, 5 )
IsisB2:SetText( "Minimize" )
IsisB2.DoClick = function()
HtmlWin:SetVisible(false)
        end    
local IsisB3 = vgui.Create( "DButton")
IsisB3:SetSize( 80,30 )
IsisB3:SetPos( ScrW() - 85, 35 )
IsisB3:SetText( "Hack Main Page" )
IsisB3.DoClick = function()
HtmlWin:SetVisible(true)
        end    
       
       
end
 
 
BSheet:AddSheet( "Aimbot", Tab, "gui/silkicons/star", false, false, "Aimbot" )
BSheet:AddSheet( "ESP", Tab2, "gui/silkicons/check_on", false, false, "Wallhacks/ESP" )
BSheet:AddSheet( "DarkRP", Tab3, "gui/silkicons/check_on", false, false, "RolePlay Wallhacks" )
BSheet:AddSheet( "Misc", Tab4, "gui/silkicons/world", false, false, "Misc" )
BSheet:AddSheet( "Speedhack", Tab5, "gui/silkicons/wrench", false, false, "Gotta go fast" )
end
concommand.Add("+HL_Menu",ShowFrame)
concommand.Add("-HL_Menu",function()
Frame:SetVisible( false )
end)
 
concommand.Add("MB_Menu_Reload",function()
ShowFrame()
end)