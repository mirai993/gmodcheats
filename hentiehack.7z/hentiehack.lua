--[[
	hentie/hack.lua
	Hen Tie | (STEAM_0:0:20261128)
	===DStream===
]]


disco = {}
disco.lerp = 0.25
disco.auto = false

local HAX = {}
oldGM = oldGM or {}

local aimbotWhite = CreateMaterial( "aimbotWhiteMat", "UnlitGeneric", {
    ["$basetexture"] = "color/white",
} )

function VectorToLPCameraScreen( vDir, iScreenW, iScreenH, angCamRot, fFoV )
	local d = 4 * iScreenH / ( 6 * math.tan( 0.5 * fFoV ) )
	local fdp = angCamRot:Forward():Dot( vDir );
 
	if fdp == 0 then
		return 0, 0, -1
	end
 
	local vProj = ( d / fdp ) * vDir;
 
	local x = 0.5 * iScreenW + angCamRot:Right():Dot( vProj )
	local y = 0.5 * iScreenH - angCamRot:Up():Dot( vProj )
 
	local iVisibility
	if fdp < 0 then
		iVisibility = -1
	elseif x < 0 || x > iScreenW || y < 0 || y > iScreenH then
		iVisibility = 0
	else
		iVisibility = 1
	end
 
	return x, y, iVisibility
end

local zoom = 0
function ToScreen( Origin )
	return VectorToLPCameraScreen( ( Origin - EyePos() ):GetNormal(), ScrW(), ScrH(), EyeAngles(), math.rad( LocalPlayer():GetFOV()-zoom ) )
end

/*function HAX:CalcView( pl, pos, angles, fov )

	if HOOKING then return end
	HOOKING = true
	local view = hook.Call( "CalcView", GAMEMODE, pl, pos, angles, fov )
	HOOKING = false

	view.fov = pl:GetFOV() - zoom
	
	return view
end*/
 
function HAX:AdjustMouseSensitivity( default )
	return math.Clamp( ((90-zoom)/60), 0.01, 1 )
end
 
local GRENADE_TIMER = 3
function HAX:OnEntityCreated( ent )
	if not ValidEntity( ent ) then return end
	if ent:GetClass() == "npc_grenade_frag" then
		ent.Timer = CurTime() + GRENADE_TIMER
	end
end

local playersToDraw = {}
local melons = {}
local closest
local lastang = Angle(0,0,0)
local lastmousedown = false
local lastpox, lastposy = 0, 0
function HAX:Think()

	--playersToDraw = ents.FindByClass( "npc_*" )
	
	for _,pl in pairs( playersToDraw ) do
		if not ValidEntity( pl ) or pl:IsEffectActive( EF_NODRAW ) then continue end
		melons[pl] = melons[pl] or ClientsideModel( "models/props_junk/watermelon01.mdl" )
	end
	
	if input.IsKeyDown( KEY_LALT ) then
		zoom = zoom + 300*FrameTime()
		if zoom > 60 then zoom = 60 end
	else
		zoom = zoom - 300*FrameTime()
		if zoom < 0 then zoom = 0 end
	end
	
	if input.IsMouseDown( MOUSE_MIDDLE ) and not lastmousedown and not disco.auto then
	
		if not ValidEntity( closest ) or closest:IsEffectActive( EF_NODRAW ) then
			local lastDistance = 1024
			local lastPos = nil
			for _,pl in pairs( playersToDraw ) do
				if not ValidEntity( pl ) or pl:IsEffectActive( EF_NODRAW ) then continue end
				local head = pl:LookupBone("ValveBiped.Bip01_Head1")
				local pos, ang = pl:GetBonePosition( head )
				local x, y = VectorToLPCameraScreen( ( pos - EyePos() ):GetNormal(), ScrW(), ScrH(), EyeAngles(), math.rad( LocalPlayer():GetFOV() ) )
				if x < 0 or y < 0 or x > ScrW() or y > ScrH() then continue end
				local dist = math.Distance( x, y, ScrW()/2, ScrH()/2 )
				if dist < lastDistance then
					closest = pl
					lastDistance = dist
					lastPos = pos
				end
			end
		end
		
	end
	lastmousedown = input.IsMouseDown( MOUSE_MIDDLE )
	
	if input.IsMouseDown( MOUSE_MIDDLE ) then
		
		if disco.auto and ( not ValidEntity( closest ) or closest:IsEffectActive( EF_NODRAW ) ) then
			local lastDistance = 1024
			local lastPos = nil
			for _,pl in pairs( playersToDraw ) do
				if not ValidEntity( pl ) or pl:IsEffectActive( EF_NODRAW ) then continue end
				local head = pl:LookupBone("ValveBiped.Bip01_Head1")
				local pos, ang = pl:GetBonePosition( head )
				local x, y = VectorToLPCameraScreen( ( pos - EyePos() ):GetNormal(), ScrW(), ScrH(), EyeAngles(), math.rad( LocalPlayer():GetFOV() ) )
				if x < 0 or y < 0 or x > ScrW() or y > ScrH() then continue end
				local dist = math.Distance( x, y, ScrW()/2, ScrH()/2 )
				if dist < lastDistance then
					closest = pl
					lastDistance = dist
					lastPos = pos
				end
			end
		end
		
		if ValidEntity( closest ) and not closest:IsEffectActive( EF_NODRAW )  then
			local head = closest:LookupBone("ValveBiped.Bip01_Head1")
			local pos, ang = closest:GetBonePosition( head )
			local posx, posy = ToScreen(pos)
			local norm = ( Vector( posx, posy, 0 ) - Vector( ScrW()/2, ScrH()/2, 0 ) ):GetNormal()
			gui.SetMousePos( ScrW()/2+norm.x*5, ScrH()/2+norm.y*5 )
		end
		
	else
		//lastang = cmd:GetViewAngles()
		closest = nil
	end
	
end

local tblNormalConeWepBases = {
        ["weapon_cs_base"] = true
}

local function GetCone(wep)
        local cone = wep.Cone
        if not cone and type(wep.Primary) == "table" and type(wep.Primary.Cone) == "number" then
                cone = wep.Primary.Cone
        end
        if not cone then cone = 0 end
        --CHeck if wep is HL2 then return corresponding cone
        if type(wep.Base) == "string" and tblNormalConeWepBases[wep.Base] then return cone end
        if wep:GetClass() == "ose_turretcontroller" then return 0 end
        --if ID_GAMETYPE ~= -1 then return GameTypes[ID_GAMETYPE].getcone(wep,cone) end
        return cone or 0
end

function HAX:CreateMove( cmd )


	/*if cmd:GetButtons() & IN_ATTACK > 0 then
		local cmd_id = sthp_command_number(cmd)
		local seed = sthp_MD5_PseudoRandom(cmd_id)
		if cmd_id ~= 0 then
			MsgN( seed )
			local wep = LocalPlayer():GetActiveWeapon()
			local vecCone = Vector(0,0,0)
			if wep and wep:IsValid() and type(wep.Initialize) == "function" then
				local valCone = GetCone( wep )
				if type(valCone) == "number" then
						vecCone = Vector(-valCone,-valCone,-valCone)
				elseif type(valCone) == "Vector" then
						vecCone = -1*valCone
				end
			end
			--local new_ang = sthp_manipulate_shot( seed or 0, LocalPlayer():GetAimVector(), vecCone ):Angle()
			local new_ang = sthp_PredictSpread( seed or 0, vecCone, ( cmd:GetViewAngles():Right() ), ( cmd:GetViewAngles():Up() ) ):Angle()
			new_ang.p = math.NormalizeAngle( new_ang.p )
			new_ang.y = math.NormalizeAngle( new_ang.y )
			cmd:SetViewAngles( new_ang )
		end
	end*/
	
end

local drawing = false
function HAX:PreDrawOpaqueRenderables()

	if drawing then return nil end
	playersToDraw = ents.FindByClass( "npc_*" )

end

function HAX:PrePlayerDraw( pl )

	if drawing then return nil end
	table.insert( playersToDraw, pl )

end

function HAX:PostPlayerDraw( pl )

	if drawing then return nil end
	table.insert( playersToDraw, pl )

end

local tooFar = {}
function HAX:PostDrawTranslucentRenderables()

	if drawing then return end
	
	drawing = true
	cam.Start3D( EyePos(), EyeAngles() )
	render.ClearStencil()
	render.SetStencilEnable( true )
	render.SetStencilFailOperation( STENCILOPERATION_REPLACE )
	render.SetStencilZFailOperation( STENCILOPERATION_REPLACE )
	render.SetStencilPassOperation( STENCILOPERATION_KEEP )
	render.SetStencilCompareFunction( STENCILCOMPARISONFUNCTION_ALWAYS )
	render.SetStencilReferenceValue( 1 )
	for _,pl in pairs( playersToDraw ) do
		if not ValidEntity( pl ) or pl:IsEffectActive( EF_NODRAW ) then continue end
		render.SuppressEngineLighting( true )
		render.SetBlend( 0.3 )
		pl:DrawModel()
		render.SetBlend( 1)
		render.SuppressEngineLighting( false )
	end
	render.SetStencilFailOperation( STENCILOPERATION_KEEP )
	render.SetStencilZFailOperation( STENCILOPERATION_REPLACE )
	render.SetStencilPassOperation( STENCILOPERATION_REPLACE )
	render.SetStencilCompareFunction( STENCILCOMPARISONFUNCTION_ALWAYS )
	render.SetStencilReferenceValue( 2 )
	for _,pl in pairs( playersToDraw ) do
		if not ValidEntity( pl ) or pl:IsEffectActive( EF_NODRAW ) then continue end
		render.SuppressEngineLighting( true )
		render.SetBlend( 0.3 )
		melon = melons[ pl ]
		if not melon then continue end
		local head = pl:LookupBone("ValveBiped.Bip01_Head1")
		local pos, ang = pl:GetBonePosition( head )
		melon:SetPos( pos+ang:Forward()*2 )
		melon:SetAngles( ang )
		melon:SetColor( 0,0,0,0 )
		melon:SetModelScale( Vector( 0.6, 0.6, 0.6 ) )
		melon:DrawModel()
		render.SetBlend( 1)
		render.SuppressEngineLighting( false )
	end
	
	render.SetStencilCompareFunction( STENCILCOMPARISONFUNCTION_EQUAL )
	render.SetStencilPassOperation( STENCILOPERATION_REPLACE )
	render.SetStencilReferenceValue( 1 )
 
	render.SetBlend( 0.35 )
	render.SetColorModulation( 1, 0, 0 )
	cam.IgnoreZ( true )
	SetMaterialOverride( aimbotWhite )
	for _,pl in pairs( playersToDraw ) do
		if not ValidEntity( pl ) or pl:IsEffectActive( EF_NODRAW ) then continue end
		local pos = pl:LocalToWorld(Vector(0,0,pl:OBBMaxs().z))
		local dist = pos:Distance( EyePos() )
		render.SetBlend( dist/1500 )
		pl:DrawModel()
	end
	render.SetStencilCompareFunction( STENCILCOMPARISONFUNCTION_EQUAL )
	render.SetStencilPassOperation( STENCILOPERATION_REPLACE )
	render.SetStencilReferenceValue( 2 )
	render.SetBlend( 0.25 )
	render.SetColorModulation( 0, 1, 0 )
	for _,pl in pairs( playersToDraw ) do
		if not ValidEntity( pl ) or pl:IsEffectActive( EF_NODRAW ) then continue end
		melon = melons[ pl ]
		if not melon then continue end
		melon:DrawModel()
	end
	render.SetColorModulation( 1, 1, 1 )
	SetMaterialOverride( )
	cam.IgnoreZ( false )
	render.SetBlend( 1)
 
	render.SetStencilEnable( false )
 
	cam.End3D()
	
	tooFar = {}
	for _,pl in pairs( playersToDraw ) do
		if not ValidEntity( pl ) or pl:IsEffectActive( EF_NODRAW ) then continue end
		local ang = EyeAngles()
		ang:RotateAroundAxis( ang:Forward(), 90 )
		ang:RotateAroundAxis( ang:Right(), 90 )
		
		cam.IgnoreZ( true )
		local pos = pl:LocalToWorld(Vector(0,0,pl:OBBMaxs().z+10))
		local dist = pos:Distance( EyePos() )
		local text = pl:GetClass()
		if pl:IsPlayer() then
			if string.len( pl:Nick() ) > 10 then
				text = string.sub( pl:Nick(), 1, 10 ).."..".." ("..pl:Health()..")"
			else
				text = pl:Nick().." ("..pl:Health()..")"
			end
		elseif pl.Timer then
			text = text .. " (" .. tostring( math.floor(( pl.Timer - CurTime() )*10) ) .. ")"
		end
		if dist < 200 then
			cam.Start3D2D( pos, ang, 0.5 )
				draw.DrawText( text, "DefaultFixedOutline", 2, 2, Color( 255, 255, 255, 200-(dist/10) ), TEXT_ALIGN_CENTER )
			cam.End3D2D()
		else
			cam.Start3D2D( pos, ang, dist/350 )
				draw.DrawText( text, "DefaultFixedOutline", 2, 2, Color( 255, 255, 255, 200-(dist/10) ), TEXT_ALIGN_CENTER )
			cam.End3D2D()
		end
		cam.IgnoreZ( false )
	end
	drawing = false
	
end

function HAX:HUDPaint()

	local i = 1
	for _,pl in pairs( player.GetAll() ) do
		if pl:GetObserverTarget() != LocalPlayer() then continue end
		draw.DrawText( pl:Nick(), "DefaultFixedOutline", 5, 5+i*10, Color( 255, 255, 255, 255 ), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP )
		i = i + 1
	end

	if ValidEntity( LocalPlayer() ) and ValidEntity( LocalPlayer():GetActiveWeapon() ) and LocalPlayer():GetActiveWeapon():GetClass() == "weapon_frag" then
		local pos = EyePos()+EyeAngles():Forward()*18+EyeAngles():Right()*8
		local forward = EyeAngles():Forward()
		forward.z = forward.z + 0.1;
		local lastPos = pos
		local vel = LocalPlayer():GetVelocity() + forward * 1520
		local accel = 9.8
		for time=0,50 do
			local cur_vel = vel - Vector( 0,0,600 )*(time/15)
			local next_pos = pos + cur_vel*(time/15)
			local trRes = util.TraceHull( { start = lastPos, endpos = next_pos, filter = LocalPlayer(), mins = -Vector( 2.8,2.8,2.8 ), maxs = Vector( 2.8,2.8,2.8 ) } )
			local x, y = ToScreen( lastPos )
			local x2, y2 = ToScreen( trRes.HitPos )
			lastPos = next_pos
			local wallTrace = util.TraceLine( { start = EyePos(), endpos = lastPos, filter = LocalPlayer() } )
			local wallTrace2 = util.TraceLine( { start = EyePos(), endpos = trRes.HitPos, filter = LocalPlayer() } )
			if wallTrace.Hit or wallTrace2.Hit then
				surface.SetDrawColor( 255, 0, 0, 255 - time*10 )
			else
				surface.SetDrawColor( 255, 255, 255, 255 - time*10 )
			end
			surface.DrawLine( x, y, x2, y2 )
			if trRes.Hit then break end
		end
		
		local pos = EyePos()+EyeAngles():Forward()*18+EyeAngles():Right()*8-EyeAngles():Up()*8
		local forward = EyeAngles():Forward()
		forward.z = forward.z + 0.1;
		local lastPos = pos
		local vel = LocalPlayer():GetVelocity() + forward * 400 + Vector( 0,0,50 )
		local accel = 9.8
		for time=0,50 do
			local cur_vel = vel - Vector( 0,0,600 )*(time/15)
			local next_pos = pos + cur_vel*(time/15)
			local trRes = util.TraceHull( { start = lastPos, endpos = next_pos, filter = LocalPlayer(), mins = -Vector( 2.8,2.8,2.8 ), maxs = Vector( 2.8,2.8,2.8 ) } )
			local x, y = ToScreen( lastPos )
			local x2, y2 = ToScreen( trRes.HitPos )
			lastPos = next_pos
			local wallTrace = util.TraceLine( { start = EyePos(), endpos = lastPos, filter = LocalPlayer() } )
			local wallTrace2 = util.TraceLine( { start = EyePos(), endpos = trRes.HitPos, filter = LocalPlayer() } )
			if wallTrace.Hit or wallTrace2.Hit then
				surface.SetDrawColor( 255, 0, 0, 255 - time*10 )
			else
				surface.SetDrawColor( 255, 255, 255, 255 - time*10 )
			end
			surface.DrawLine( x, y, x2, y2 )
			if trRes.Hit then break end
		end
	end

end

/* The core of the hack is below here: */

if not GM and GAMEMODE then
	for name,func in pairs( HAX ) do
		oldGM[name] = oldGM[name] or GAMEMODE[name]
		GAMEMODE[name] = function(...) local ret = func(...) if ret != nil then return ret end return oldGM[name](...) end
	end
elseif GM and not GAMEMODE then
	for name,func in pairs( HAX ) do
		oldGM[name] = oldGM[name] or GM[name]
		GM[name] = function(...) local ret = func(...) if ret != nil then return ret end return oldGM[name](...) end
	end
end