/*
	A simple murder gamemode cheat
	Yes, i'm aware there are a few of these, but they're messy, detectable, and ugly.
	
	Updated: 12/23/13
	http://steamcommunity.com/id/thinkurfunnykid/
*/

// To change a setting, change "true" to "false"
local hack = {}
hack["Settings"] = {
	["OutlineFont"] = true, // Draw a black outline around the font?
	["Font"] = "default",
	["OutlineBox"] = true,
}
hack["Colors"] = {
	["Red"] = Color( 255, 0, 0, 255 ),
	["White"] = Color( 255, 255, 255, 255 ),
	["Green"] = Color( 0, 255, 50, 255 ),
	["Black"] = Color( 0, 0, 0, 255 ),
}
hack["Weapons"] = {
	"Knife",
	"Magnum",
}

function hack.AddHook( Type, Function )
	Name = tostring( math["random"]( 0.666, 666 ) * math["random"]( 0.666, 666 ) ) -- Undetectable, yet edgy hook names
	return hook["Add"]( Type, Name, Function )
end

function hack.FindMurders()
end

function hack.GetColor( v )
	local color = v:GetPlayerColor()
	return Color( color.x * 255, color.y * 255, color.z * 255 )
end
	
function hack.ESP()
	for k, v in pairs( ents["GetAll"]() ) do
		if IsValid( v ) then
		
			local Bottom = ( v:GetPos() + Vector( 0, 0, 1 ) ):ToScreen()
			local Top = ( v:GetPos() + Vector( 0, 0, 69 ) ):ToScreen()
			local Height = ( Bottom.y - Top.y )
			local Width = ( Height / 2 )
			
			if ( v:IsPlayer() && v:Alive() ) then
				for _, wep in pairs( v:GetWeapons() ) do
				
					// Draw weapons on players.
					if table["HasValue"]( hack["Weapons"], wep:GetPrintName() ) then
						draw["SimpleTextOutlined"]( wep:GetPrintName(), hack["Settings"]["Font"], Top.x, Top.y - 20, hack["Colors"]["Red"], TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, hack["Colors"]["Black"] )
					end
						
					// Draw name and health	
					if hack["Settings"]["OutlineFont"] == true then
						draw["SimpleTextOutlined"]( v:GetBystanderName() .. " - " .. v:Health(), hack["Settings"]["Font"], Top.x, Top.y - 10, hack["GetColor"]( v ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, hack["Colors"]["Black"] )
					else
						draw["SimpleText"]( v:GetBystanderName() .. " - " .. v:Health(), hack["Settings"]["Font"], Top.x, Top.y - 10, hack["GetColor"]( v ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
					end
					
					// Bounding box
					surface.SetDrawColor( hack["GetColor"]( v ) )
					surface.DrawOutlinedRect( Top.x - Width, Top.y, Width * 2, Height )
					if hack["Settings"]["OutlineBox"] == true then
						surface.SetDrawColor( hack["Colors"]["Black"] )
						surface.DrawOutlinedRect( Top.x - Width - 1, Top.y - 1, Width * 2 + 2, Height + 2 )
						surface.DrawOutlinedRect( Top.x - Width + 1, Top.y + 1, Width * 2 - 2, Height - 2 )
					end
					
				end
				
			// Loot finder
			elseif v:GetClass() == "mu_loot" then
				draw["SimpleText"]( "Loot", hack["Settings"]["Font"], Top.x, Top.y + 20, hack["Colors"]["Green"], TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
				halo["Add"]( {v}, hack["Colors"]["Green"], 1, 1, 5, true, true )
			end
		end
	end
end

hack["AddHook"]( "HUDPaint", hack["ESP"] )