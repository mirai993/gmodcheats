-- Welcome to StormBot by Flapadar, Pcwizdan and Fr1kin --

-- Just a little note, everything in here has to be standard lua (So as we can compile it) - Flap
-- So no C that garry added basically right?
-- Yeah
-- Start date 09/29/11 --
local enabled = true
if SERVER or not enabled then return end
local sb_startTime=SysTime()
print("Stormbot loading...")

-- Local for testing -- 
storm = {}

local DEBUG=true

local function printd(...) if DEBUG then print(...) end end

-- Flap to PC - below func will mess up type() calls on colours we pass. Wouldn't it be easier catching Color as it is created?
--rgba -PC
-- type will return table, not Color. / Flap - PC ALREADY KNOW THIS...
local function Color(...)
	local nArgs=select('#',...)
	if nArgs==1 then
		return (...) --a Color object (which is just a table like this below
	elseif nArgs==3 then --without alpha channel
		return {r= (select(1,...)), g= (select(2,...)), b= (select(3,...))}
	elseif nArgs==4 then --with alpha channel
		return {r= (select(1,...)), g= (select(2,...)), b= (select(3,...)), a= (select(4,...))}
	end
end

-- Util funcs / Flapadar 1/10/11
local function CopyTable(tbl)
	local r = {}
	for k , v in pairs(tbl) do
		if type(v) ~= "table" then
			r[k] = v
		else
			r[k] = CopyTable(v)
		end
	end
	return r
end

local function randomString(len)
	local r = ""
	for i = 1 , len do
		r = r .. string.char(math.random(65,119))
	end
	return r
end

storm.CopyTable = CopyTable
storm.randomString = randomString
storm.debug = storm.CopyTable(debug)
storm.table = storm.CopyTable(table)
storm.string= storm.CopyTable(string)
storm.math  = storm.CopyTable(math)
storm.surface = storm.CopyTable(surface)

storm.COLOR={} --setup color saving table, dont make tables of colors in hooks (thats slow)
local RunConsoleCommand = RunConsoleCommand
--[[

Function Overrides
29/09/11
-Flapadar

]]

storm.overrides = {}

local function debugOverride(func,override)
	storm.overrides[override] = func
end

local function stormGetInfo(func , ...)
	if not func then return end
	
	if storm.overrides[func] then
		local r = storm.overrides[debug.getinfo](storm.overrides[func] , ...)
		r.func = func
		return r
	else
		return storm.overrides[debug.getinfo](func , ...)
	end
end 
debugOverride(debug.getinfo , stormGetInfo)
debug.getinfo = stormGetInfo

local function stormGetUpVal(func , num, ...)
	if not func then return end
	
	if storm.overrides[func] then
		return storm.overrides[debug.getupvalue](storm.overrides[func] , ...)
	else
		return storm.overrides[debug.getupvalue](func , ...)
	end
end
debugOverride(debug.getupvalue ,  stormGetUpVal)
debug.getupvalue = stormGetUpVal

storm.packages = {}
storm.setpackages = {}
local function preRequire(module,editfunc)
	storm.packages[module] = editfunc
end

local req = require
local function stormReq(module)
	if not storm.setpackages[module] then
		print("Require: " .. module)
		if storm.packages[module] then
			local r = req(module)
			local override = storm.packages[module](r)
			print(override)
			_G[module] = override
			package.loaded[module] = override
			storm.setpackages[module] = override
			return override
		end
		return req(module)
	else
		return storm.setpackages[module]
	end
end
debugOverride(require,stormReq)
require = stormReq

storm.hooks = {}

function storm:Hook(type,func,index)
	storm.hooks[type] = storm.hooks[type] or {} --Verify table is created if no hook table exists
	local index = index or randomString(5) --use provided index or a randomised string
	storm.hooks[type][index] = func
end

local hook_list
function storm.Call(type,gm,...)
	hook_list = storm.hooks[type]
	if hook_list then
		local r;
		for sIndex , fCall in pairs(hook_list) do
			local isok , ret = pcall(fCall,...)
			if not isok then
				ErrorNoHalt("[StormBot] "..type.." | " .. sIndex .. ": "..ret.."\n")
				-- Debug info is stripped when code is compiled.
				-- So we can't get exact line numbers, etc
			else
				if ret == true then
					return true;
				else
					r = ret
				end
			end
		end
		return r
	end
	-- Do some hook stuff
	-- Call through all our hooked functions and pass the params.
end

local oldHookCall = function() end
local function stormHookCall(type,gm,...)
	storm.Call(type,gm,...)
	return oldHookCall(type,gm,...)
end

preRequire("hook" , function(mod)
	print("preRequire('hook') has been called!")
	--print(mod.Call)
	oldHookCall = mod.Call
	--print(oldHookCall)
	debugOverride(mod.Call,stormHookCall)
	mod.Call = stormHookCall
	return mod
end )

-- File Handling -- 
-- "I rammed my cock right down its throat" -- 
-- Flap --

storm.file = CopyTable(file)
local cexists = ConVarExists


storm.SaveSettings = {}

function storm:SaveData(key,val)
	storm.SaveSettings[key] = val
	storm.file.Write("storm/settings.txt" , glon.encode(storm.SaveSettings))
end

storm.SavedConVars = {}

storm:Hook("InitPostEntity" , function()
	local c = glon.decode(storm.file.Read("storm/settings.txt"))

	if c and c.convars then
		for k , v in pairs(c.convars) do
			if k and v and k ~= "" then
				if cexists(k) then
					RunConsoleCommand(k,v) -- rcc? where?
					storm.SavedConVars[k] = v
				end
			end
		end
		MsgN("[StormBot] Previous settings loaded.")
	end
end,"storm settings" )
	



-- ConVar creation --
-- We'll use a system of fake convars that are actually commands. --
-- Far easier to block anticheat access to --

-- Flap

storm.commands = {}

function storm.concommandAdd(name,func,auto)
	storm.commands[name:lower()]={func,auto}
end

function storm.concommandRemove(name)
	storm.commands[name:lower()] = nil
end

local convars = {}

local function AddChangeCallback(convar , callback)
	table.insert(convars , {c=convar , cb=callback,v=GetConVar(convar):GetString()})
end

--local cv = preRequire("cvars")

local function stormOCC(name,old,new)
	local found = false
	for k , v in pairs(convars) do
		if v.c:lower () == name:lower() then
			v.cb(name,old,new)
			found = true
		end
	end
	
	
	return found and nil or storm.OldConVarC(name,old,new)
end

preRequire("cvars" , function(cv)
	storm.OldConVarC = cv.OnConVarChanged
	debugOverride(cv.OnConVarChanged,stormOCC)
	cv.OnConVarChanged = stormOCC
	return cv
end )

storm.convars = {}
storm.convarsettings = {["ESP"]={},["Aim"]={},["Misc"]={}}
--take a leaf from faphack's book --
storm.settings = {}
function storm.CreateConVar(cvar,clean_name,var,desc,def,max,min,dec)
	local handler = randomString(10)
	storm.convars[handler] = cvar
	
	local convar = CreateConVar(handler , def , {SERVER_CANNOT_QUERY})
	storm.concommandAdd(cvar,function(pl,cmd,args) RunConsoleCommand(handler,unpack(args)) end )
	
	
	-- Yes, this is from faphack. But it worked well. --
	local booltype = false
	if type(def) == "boolean" then
		def = def and 1 or 0
		booltype = true
	end
	
	if booltype then
		storm.settings[var] = tobool(convar:GetInt())
	elseif type(def) == "number" then
		if not isdec then
			storm.settings[var] = convar:GetInt()
		else
			storm.settings[var] = tonumber(convar:GetString())
		end
	elseif type(def) == "string" then
		storm.settings[var] = convar:GetString()
	end

	if string.find(cvar , "aim") then
		if booltype then
			storm.convarsettings["Aim"][var] = {var = cvar , type = "boolean" , name = var,clean=clean,desc=desc}
		elseif type(def) == "string" then
			storm.convarsettings["Aim"][var] = {var = cvar , type = "string" , name = var,clean=clean,desc=desc}
		elseif type(def) == "number" then
			storm.convarsettings["Aim"][var] = {var = cvar , type = "number" , max = max , min = min , dec = isdec , name = var,clean=clean,desc=desc}
		end
	elseif string.find(cvar , "esp") then
		if booltype then
			storm.convarsettings["ESP"][var] = {var = cvar , type = "boolean" , name = var,clean=clean,desc=desc}
		elseif type(def) == "string" then
			storm.convarsettings["ESP"][var] = {var = cvar , type = "string" , name = var ,clean=clean,desc=desc}
		elseif type(def) == "number" then
			storm.convarsettings["ESP"][var] = {var = cvar , type = "number" , max = max , min = min , dec = isdec , name = var,clean=clean,desc=desc}
		end
	else
		if booltype then
			storm.convarsettings["Misc"][var] = {var = cvar , type = "boolean" , name = var,clean=clean,desc=desc}
		elseif type(def) == "string" then
			storm.convarsettings["Misc"][var] = {var = cvar , type = "string" , name = var,clean=clean,desc=desc}
		elseif type(def) == "number" then
			storm.convarsettings["Misc"][var] = {var = cvar , type = "number" , max = max , min = min , dec = isdec , name = var,clean=clean,desc=desc}
		end
	end
	
	AddChangeCallback(cvar , function(cvar , old , new)
		if booltype then
			storm.convarsettings[var] = tobool(storm.math.floor(new))
		else
			storm.convarsettings[var] = new
		end
		
		storm.SavedConVars[cvar] = new
		storm:SaveData("convars" , storm.SavedConVars)
		-- ^ should add a glon saving system for stuff.
		-- why glon, who ever came up with english encoding instead of by numbers.
		-- It's better it not being very readable so as people don't try editing it manually. 
	end )
	
	return convar

end

local econc = engineConsoleCommand

storm.blacklistcommmands = {

	["aafk_return"] = function(...)
		local tbl={...}
		local val = tbl[1]
		storm.AAFK_RETURN_KEY=val
		-- ripped from below.
	end,
	
	--[[["dir_list"] = function (pl,cmd,args)
		econc(pl,cmd,"options_menu.lua");
		-- this is how you would do it. However, sending an empty table would be detectable so i'll leave it commented for now
		
		--RunConsoleCommand("dir_list","options_menu.lua") --absolutely nothing
		
		-- This is uh.. an infinite loop. /Flap
		make it able to send a command out without it being caught by blacklist and bypassing it for the bot.
		
	end,]]
	-- Etc.
}
-- For concommand we should hook the engine functions --

-- engineConsoleCommand and engineCommandComplete --

local function stormEngineConC(pl,cmd,args)
	if storm.blacklistcommands[cmd:lower()] then
		storm.blacklistcommands[cmd:lower()](pl,cmd,args)
		return
	end
	local path = storm.debug.getinfo(2).short_src
	if path == "[C]" and storm.string.find(cmd,"storm_") then
		if storm.commands[cmd:lower()] then
			return storm.commands[cmd:lower()][1](pl,cmd,args)
		end
	else
		-- Don't call anything. This is from an anticheat.
		-- Log something so as people know (Once we write a lua log)
	end
	return econc(pl,cmd,args)
end
debugOverride(engineConsoleCommand,stormEngineConC)
--engineConsoleCommand = stormEngineConC


local ecc = engineCommandComplete
local function stormEngineCC(cmd,args)
	local path = storm.debug.getinfo(2).short_src
	if path == "[C]" then
		local lcmd = storm.string.lower(cmd)
		if storm.commands[lcmd] then
			return storm.commands[lcmd][2](cmd,args)
		end
	else
		-- Don't call anything. This is from an anticheat.
		-- Log something so as people know (Once we write a lua log)
	end
	return ecc(cmd,args)
end
debugOverride(engineCommandComplete,stormEngineCC)
--engineConsoleCommand = stormEngineCC


-- START OBJECT CODE WITH LOCALPLAYER AND LOTS OF FUN
--[[ Initialize CL which stores localplayer
	stop calling LocalPlayer() and use a variable which is faster in theory but makes sense.
	-PC
]]
local CL
local NAME="LocalPlayer Store/Init"
--[[ useless we use CalcView now...it sends us localplayer in a parameter
storm:Hook("OnEntityCreated",function (objEnt) if objEnt:IsPlayer() and objEnt==LocalPlayer() and not ValidEntity(CL) then CL = objEnt end end,NAME)
storm:Hook("InitPostEntity",function ()	if not ValidEntity(CL) then	CL = LocalPlayer() end end,NAME)
storm:Hook("Think",function () if not CL then CL = LocalPlayer() end end,"set LocalPlayer")
]]

--[[
	START HUD code detailing view orientation and options like that. after this segment starts visual drawn shit on the HUD being initialized.
]]
storm.HUD={}
storm.HUD.Zoom= { --hold a key and it will increase fov value to a limit click it again to stop, this system is being coded
	Active=false, --set this to when a key is down
	Value=90,
	Rate=2
}
storm.HUD.Hitmark = {
	mark_stay=2,
	targets={}
} --this is the hitmark feature for ripping COD style stuff.
storm.HUD.viewang = nil
storm.HUD.StopViewRolling = false --connect this to a command
storm.HUD.FreeViewing = false

local function SetEntityColorAuto(objPl) --going to modify this later to be more ambiguous...
	if "color by team"=="enabled" then
		local team = team.GetColor( objPl:Team() )
		surface.SetDrawColor( team.r, team.g, team.b, 255 )
	else
		if objPl:Team() == CL:Team() then --same team as me.
			surface.SetDrawColor(storm.COLOR.friendly)
		else
			surface.SetDrawColor(storm.COLOR.enemy)
		end
	end
end

local function GetEntityColor(objPl)
	if "color by team"=="enabled" then
		return team.GetColor(objPl:Team())
	else
		if objPl:Team() == CL:Team() then --same team as me.
			return storm.COLOR.friendly
		else
			return storm.COLOR.enemy
		end
	end
end

local function VMFlipFix(vmAng,viewAng)
	viewAng = viewAng or RenderAngles() -- renderangles is not updated fast enough to be a permanent alternative, so send calcview'd angle for fast/accuracy
	return Angle(vmAng.p,viewAng.y - (vmAng.y - viewAng.y),vmAng.r)
end

storm:Hook("CalcView",function (objPl, origin, angles, fov)
	if not objPl or not ValidEntity(objPl) then return end -- this means localplayer hasn't initialized yet so dont run any code here
	if not CL then CL=objPl end -- Set CL some way --THIS IS HOW WE DO IT
	local func = GAMEMODE.CalcView --grab the GAME coded calcview
	local data={}
	if type(func) == "function" then --verify the gamemode isnt wacky and changed the CalcView function to some table or something.
		data = func(GAMEMODE,objPl,origin,angles,fov)
	end
	if type(data) ~= "table" then data = {} end --make sure data is a table
	
	if storm.HUD.Zoom.Active then --when Active(a key is pressed down and held, upon depress this value is false) this segment zooms the entire screen in at a rate
		storm.HUD.Zoom.Value=storm.math.max(8,storm.HUD.Zoom.Value - tonumber(storm.HUD.Zoom.Rate or 10)*FrameTime())
	end
	
	if storm.HUD.Zoom.Value < 90 then data.fov = storm.HUD.Zoom.Value end
	if not objPl:InVehicle() then
		if storm.HUD.viewang and storm.HUD.FreeViewing then
			data.angles = storm.HUD.viewang --value shared with other functions THIS IS THE VIEWANG WE HAVE OUR EYES POINTED TO.
		else
			data.angles = objPl:EyeAngles()
		end
		if data.angles and storm.HUD.StopViewRolling then data.angles.r = 0 end --stop rolling of the view from some gamemodes
		local wep = objPl:GetActiveWeapon()
		if ValidEntity(wep) and wep:GetClass() ~= "weapon_physgun" then
			if wep.ViewModelFlip then
				data.vm_angles = VMFlipFix(Angle(angles.p,angles.y,0),data.angles)
			else
				data.vm_angles = angles
			end
			--print(1)
			data.vm_angles=EyeAngles()-(data.vm_angles-data.angles)
			data.vm_origin=data.vm_origin or EyePos()
			data.vm_origin=EyePos()-(data.vm_origin-data.origin)
		end
	end
	if data.angles or data.fov then	return data	end
end,"main CalcView")

local HackProps = {} --conversion table
storm.HUD.NPCWeapon={}
storm.HUD.GLOBALEntityList={
	["Players"]={},
	["NPCs"]={},
	["Vehicles"]={},
	["PlayerWeaponsEq"]={},
	["NPCWeaponsEq"]={},
	["WeaponsGnd"]={},
	["Props"]={},
	["Entities"]={}
}
storm.HUD.ESPEntityList=storm.CopyTable(storm.HUD.GLOBALEntityList) --contains all entities for render
storm.HUD.ESPRender=storm.CopyTable(storm.HUD.GLOBALEntityList)--this contains preallocated and 'filtered' objects to be displayed
for k,v in pairs(storm.HUD.ESPRender) do v.list={} v.draw=true v.maxdist=5000 end --initialize some variables

--TODO REMOVE WHEN PRODUCTION
function GetLists()
	print("ESPEntityList=")
	PrintTable(storm.HUD.ESPEntityList)
	print("ESPRender=")
	PrintTable(storm.HUD.ESPRender)
end
local players_update,npcs_update,weps_update
storm:Hook("Think",function () --update render lists
	if not CL or not ValidEntity(CL) then return end
	local my_pos=CL:GetPos()
	players_update=false
	npcs_update=false
	--print('thinking')
	if storm.HUD.ESPRender.Players.draw then --only calculate and update requirements when drawing the players
		for objPl, bVis in pairs(storm.HUD.ESPEntityList.Players) do
			if not ValidEntity(objPl) or objPl==CL then
				storm.HUD.ESPEntityList.Players[objPl]=nil --delete if it is gone now
			else
				local bVisNew=objPl:Alive() and objPl:GetPos():Distance(my_pos) < storm.HUD.ESPRender.Players.maxdist
				if bVisNew~=bVis then
					players_update=true
					storm.HUD.ESPEntityList.Players[objPl]=bVisNew
					storm.HUD.ESPEntityList.PlayerWeaponsEq[objPl:GetActiveWeapon()]=bVisNew
					print('updated player visibility on '..tostring(objPl))
				end
			end
		end
		if players_update then
			printd("player update (in Think Wallhack+ESP qualifier filter)")
			storm.HUD.ESPRender.Players.list = {} --clear it out then write it all
			storm.HUD.ESPRender.PlayerWeaponsEq.list={}
			for objPl, bDraw in pairs(storm.HUD.ESPEntityList.Players) do
				if bDraw then 
					storm.HUD.ESPRender.Players.list[objPl]=true
					storm.HUD.ESPRender.PlayerWeaponsEq.list[objPl:GetActiveWeapon()]=true --quick hack, what if weapon is shitty and we want to NOT draw it (we need to move weaponseq processing to another statement area in this block. -PC - TODO
				end
			end
			players_update=false
		end
	end
	
	if storm.HUD.ESPRender.NPCs.draw then
		for objNPC, bVis in pairs(storm.HUD.ESPEntityList.NPCs) do
			if not ValidEntity(objNPC) then
				storm.HUD.ESPEntityList.NPCs[objNPC]=nil --delete if it is gone now
			else
				local bVisNew=(objNPC:GetMoveType()~=0) and objNPC:GetPos():Distance(my_pos) < storm.HUD.ESPRender.NPCs.maxdist
				--print("NPC visnew="..tostring(bVisNew))
				if bVisNew~=bVis then
					npcs_update=true
					storm.HUD.ESPEntityList.NPCs[objNPC]=bVisNew
					if ValidEntity(storm.HUD.NPCWeapon[objNPC]) then
						storm.HUD.ESPEntityList.NPCWeaponsEq[ storm.HUD.NPCWeapon[objNPC] ]=bVisNew
					end
				end
			end
		end
		if npcs_update then
			printd("npc update (in Think Wallhack+ESP qualifier filter)")
			storm.HUD.ESPRender.NPCs.list = {}
			storm.HUD.ESPRender.NPCWeaponsEq.list={}
			for objNPC, bDraw in pairs(storm.HUD.ESPEntityList.NPCs) do
				if bDraw then
					storm.HUD.ESPRender.NPCs.list[objNPC]=true
					if ValidEntity(storm.HUD.NPCWeapon[objNPC]) then
						storm.HUD.ESPRender.NPCWeaponsEq.list[storm.HUD.NPCWeapon[objNPC]]=true
					end
				end
			end
			npcs_update=false
		end
		--TODO: NPC weapon drawing.
	end
	
	if storm.HUD.ESPRender.WeaponsGnd.draw then
		for objWepGnd, bVis in pairs(storm.HUD.ESPEntityList.WeaponsGnd) do
			if not ValidEntity(objWepGnd) or ValidEntity(objWepGnd:GetOwner()) then
				objWepProp=HackProps[objWepGnd]
				if ValidEntity(objWepProp) then
					objWepProp:Remove()
				end
				storm.HUD.ESPEntityList.WeaponsGnd[objWepGnd]=nil
				weps_update=true
			else
				local bVisNew=objWepGnd:GetPos():Distance(my_pos) < storm.HUD.ESPRender.WeaponsGnd.maxdist
				if bVisNew~=bVis then
					weps_update=true
					storm.HUD.ESPEntityList.WeaponsGnd[objWepGnd]=bVisNew
				end
			end
		end
		
		if weps_update then
			storm.HUD.ESPRender.WeaponsGnd.list={}
			for objWepGnd,bDraw in pairs(storm.HUD.ESPEntityList.WeaponsGnd) do
				if bDraw then
					storm.HUD.ESPRender.WeaponsGnd.list[objWepGnd]=true
				end
			end
			weps_update=false
		end
	end
	
	

	--TODO: syncronize player weapon and npcweapon equipped to add to list with the holding entity -PC
	--TODO: Before we become any more unoptimized, change table.insert method to just null out elements when they are false instead (dont change table size so often, its intensive) -PC
end,"Wallhack + ESP qualifier filter")

local fAlpha = 1/255
local function WallhackDraw(objEnt,col,matWall,matDraw,bZdraw,colDraw)
	--print('wallhack draw')
	objEnt:SetNoDraw(false)
		render.SetColorModulation(col.r*fAlpha,col.g*fAlpha,col.b*fAlpha)
		render.SuppressEngineLighting(true)
		SetMaterialOverride(matWall)
		objEnt:DrawModel()
		SetMaterialOverride(0)
		if bZdraw then
			render.SetColorModulation(colDraw.r*fAlpha,colDraw.g*fAlpha,colDraw.b*fAlpha)
			SetMaterialOverride(matDraw)
			objEnt:DrawModel()
			SetMaterialOverride(0)
		else --dont suppress light here, we draw normal model ontop of ignorez model
			render.SetColorModulation(.7,.7,.7)
			objEnt:DrawModel()
		end
		render.SuppressEngineLighting(false)
	objEnt:SetNoDraw(true)
end

--incorporate wallhack materials we program slightly ourselves in the vtf

--local MAT_WIREFRAME = Material("raidbot/wireframe")
--local MAT_WIREFRAME_WITHZ = Material("raidbot/wireframe_withz")
local matWALL=CreateMaterial("wall","UnlitGeneric",{
	['$basetexture']='models/debug/debugwhite',
	['$ignorez']=1,
	['$nocull']=1,
	--['$model']=1
})
local matDRAW=CreateMaterial("draw","UnlitGeneric",{ --this texture is not ignoring z, so it is just a paint that doesnt show through walls.
	['$basetexture']='models/debug/debugwhite',
	['$model']=1,
	['$ignorez']=0,
})
local matPROP=CreateMaterial("prop_draw","VertexLitGeneric",{
	['$basetexture']='models/debug/debugwhite',
	['$ignorez']=1,
})
local matWIRE=CreateMaterial("draw wire","Wireframe",{
	['$basetexture']='models/wireframe',
	['$ignorez']=1,
})
local matWIREZ=CreateMaterial("draw wire w/z","Wireframe",{
	['$basetexture']='models/wireframe',
	['$ignorez']=0,
})

--[[
cvar callback on the esp viewmodel_alpha
		if cc.GetVar('esp_viewmodel') and ValidEntity(CL:GetViewModel()) then
			CL:GetViewModel():SetColor(255,255,255,cc.GetVar('esp_viewmodel_alpha')*255)
		end
]]

--storm.CreateConVar("esp_viewmodel_alpha","Weapon Alpha","weaponalpha","Weapon alpha 0-255",255,255,0)
--[[AddChangeCallback("esp_viewmodel_alpha", function(cvar , old , new)
	if tonumber(new) then new=tonumber(new) end
	CL:GetViewModel():SetColor(255,255,255,new)
end)]]


local function SetupHackProp(objEnt)
	local objDraw = ents.Create("prop_physics") --SECURE ents.Create
	objDraw:SetModel(objEnt:GetModel())
	objDraw:SetPos(objEnt:GetPos())
	objDraw:SetAngles(objEnt:GetAngles())
	objDraw:Spawn()
	HackProps[objEnt]=objDraw
	
	--HackProps[objEnt]=ClientsideModel(objEnt:GetModel(),RENDERGROUP_OPAQUE)
	
end


do
local col
local matLaser=Material("sprites/bluelaser1")
	storm:Hook("RenderScreenspaceEffects",function () --TODO
		if not CL or not storm.HUD.ESPRender.Players.draw then return end
		--render.SetBlend(PLAYER_ALPHA_WALLHACK)
		--mat = Condition(PLAYER_WIREFRAME_ON,MAT_WIREFRAME,MAT_FILL)
		cam.Start3D(EyePos(),EyeAngles())
		for objPl, v in pairs(storm.HUD.ESPRender.Players.list) do
			--print(objPl)
			--objPl:GetPos():ToScreen()
			--surface.
			--Should we clean the table if its an invalid ent (it got removed or bot got kicked/player got kicked)
			if ValidEntity(objPl) then
				col=GetEntityColor(objPl)
				WallhackDraw(objPl,col,matWALL,matDRAW,false,nil)
				local t = util.GetPlayerTrace(objPl)
				local tr=util.TraceLine(t)
				render.SetMaterial(matLaser)
				render.DrawBeam(objPl:GetPos()+Vector(0,0,72),tr.HitPos,2,0,12.5,col)
				
			end
		end
		cam.End3D()
		--render.SetBlend(1)
	end,"Render wallhack players")

end

storm:Hook("HUDPaint",function ()
	if not CL or not storm.HUD.ESPRender.NPCs.draw then return end
	for objNPC, v in pairs(storm.HUD.ESPRender.NPCs.list) do
		if ValidEntity(objNPC) then
			local strData = tostring(objNPC)
			surface.SetDrawColor(255,0,0,160)
			surface.SetFont("Normal")
			local w, h = surface.GetTextSize(strData)
			local ts = (objNPC:GetPos()+Vector(0,0,72)):ToScreen() --position this more precisely
			surface.DrawRect(ts.x - w*.5, ts.y-h*.5,w,h)
			draw.SimpleText(strData,"Normal",ts.x,ts.y,color_white,TEXT_ALIGN_CENTER,TEXT_ALIGN_CENTER)
		end
	end
end,"draw npcs")

local AlertAdmins={}
local function AlertAdminJoin(objPl)
	AlertAdmins[objPl]=SysTime()
end

storm:Hook("HUDPaint",function ()
	for k, v in pairs(AlertAdmins) do
		local pos=k:GetPos():ToScreen()
		local s="Group:"
		if k:GetNWString('usergroup','user')~='user' then
			s=s..k:GetNWString('usergroup')
		elseif k:IsSuperAdmin() then
			s=s.."SuperAdmin"
		elseif k:IsAdmin() then
			s=s.."Admin"
		end
		draw.DrawText(s,"Normal",pos.x,pos.y,color_white,TEXT_ALIGN_CENTER)
	end
end,"draw admin alert")

storm:Hook("HUDPaint",function ()
	if not CL or not storm.HUD.ESPRender.Players.draw then return end
	for objPl, v in pairs(storm.HUD.ESPRender.Players.list) do
		if ValidEntity(objPl) then
			render.SetViewPort(0,0,ScrW(),ScrH())
			local strData = tostring(objPl:GetName())
			surface.SetDrawColor(0,255,0,160)
			surface.SetFont("Normal")
			local w, h = surface.GetTextSize(strData)
			local ts = (objPl:GetPos()+Vector(0,0,72)):ToScreen() --position this more precisely
			surface.DrawRect(ts.x - w*.5, ts.y-h*.5,w,h)
			draw.SimpleText(strData,"Normal",ts.x,ts.y,color_white,TEXT_ALIGN_CENTER,TEXT_ALIGN_CENTER)
		end
	end
end,"draw players")

storm.COLOR.weaponheld=Color(0,0,255,255)
storm:Hook("RenderScreenspaceEffects",function ()
	if not CL or not storm.HUD.ESPRender.NPCs.draw then return end --kill if not localplayer initialized or NPCs set to true
	--if not CL then return end
	--print('lol')
	cam.Start3D(EyePos(),EyeAngles())
	for objNPC, v in pairs(storm.HUD.ESPRender.NPCs.list) do
		if ValidEntity(objNPC) then
			--storm.HUD.ESPRender.NPCs.wallhack = true/false
			--storm.HUD.ESPRender.NPCs.wallhack_wireframe=true/false will use solid if wireframe off
			--render.SetBlend(storm.HUD.ESP.....alpha)

			WallhackDraw(objNPC,Color(255,0,0,255),matWALL,matDRAW,false,nil)
			if objNPC.GetActiveWeapon and ValidEntity(objNPC:GetActiveWeapon()) then
				WallhackDraw(objNPC:GetActiveWeapon(),storm.COLOR.weaponheld,matPROP,matDRAW,false,nil)
			end
			--[[local t = util.GetPlayerTrace(objNPC)
			local tr=util.TraceLine(t)
			render.SetMaterial(matLaser)
			render.DrawBeam(objNPC:GetPos()+Vector(0,0,72),tr.HitPos,2,0,12.5,col)]]
			--render.SetBlend(1)
		end
	end
	cam.End3D()
end,"Render wallhack npcs")

storm:Hook("RenderScreenspaceEffects",function ()
	if not CL or not storm.HUD.ESPRender.Vehicles.draw then return end
	for objVec, v in pairs(storm.HUD.ESPRender.Vehicles.list) do
		if ValidEntity(objVec) then
			
		end
	end
end,"Render wallhack vehicles")

storm:Hook("RenderScreenspaceEffects",function ()
	if not CL then return end
	cam.Start3D(EyePos(),EyeAngles())
	for objWepEq, v in pairs(storm.HUD.ESPRender.PlayerWeaponsEq.list) do
		if ValidEntity(objWepEq) then
			WallhackDraw(objWepEq,storm.COLOR.weaponheld,matPROP,matDRAW,false,nil)
		end
	end
	for objWepEq, v in pairs(storm.HUD.ESPRender.NPCWeaponsEq.list) do
		if ValidEntity(objWepEq) then
			WallhackDraw(objWepEq,storm.COLOR.weaponheld,matPROP,matDRAW,false,nil)
		end
	end
	cam.End3D()
end,"Render wallhack weapons equipped")

storm.COLOR.weapon=Color(160,32,240)
storm:Hook("RenderScreenspaceEffects",function ()
	if not CL or not storm.HUD.ESPRender.WeaponsGnd.draw then return end
	local objWepProp
	cam.Start3D(EyePos(),EyeAngles())
	for objWepGnd, v in pairs(storm.HUD.ESPRender.WeaponsGnd.list) do
		if ValidEntity(objWepGnd) then
			objWepProp=HackProps[objWepGnd]
			if ValidEntity(objWepProp) then
			--if objWepProp
			objWepGnd:SetNoDraw(true)
			--objWepProp:SetRenderOrigin(objWepGnd:GetPos())
			--objWepProp:SetRenderAngles(objWepGnd:GetAngles())
			objWepProp:SetPos(objWepGnd:GetPos())
			objWepProp:SetAngles(objWepGnd:GetAngles())
			WallhackDraw(objWepProp,storm.COLOR.weapon,matPROP,matDRAW,false --[[needs to be a cvar variable for drawing visible color overlay when not behind walls]],nil)
			end
			--objWepProp:SetRenderOrigin(nil)
			--objWepProp:SetRenderAngles(nil)
		end
	end
	cam.End3D()
end,"Render wallhack weapons ground")

--HITMARK code
storm.HUD.ESPHitMark={}
do
local MAX_HITMARK_TIME=2
storm:Hook("PlayerTraceAttack",function (objPl,dmg,dir,trace)
	if dmg:GetAttacker()==CL then
		table.insert(storm.HUD.ESPHitMark,{time=SysTime(),pos=dmg:GetDamagePosition()})
	end
	print("hit target")
end,"HitMark hook")

storm:Hook("HUDPaint",function ()
	if not CL then return end
	for k, v in pairs(storm.HUD.ESPHitMark) do
		if SysTime()-v.time>4 then
			storm.HUD.ESPHitMark[k]=nil
		else
			local pos=v.pos:ToScreen()
			surface.SetDrawColor(255,255,255,math.Clamp((1-(SysTime()-v.time)/MAX_HITMARK_TIME)*255,0,255))
			surface.DrawLine(pos.x-5,pos.y,pos.x+5,pos.y)
			surface.DrawLine(pos.x,pos.y+5,pos.x,pos.y-5)
		end
	end
end,"draw hitmarks")
end
	--[[ --PC snippet for part of the wallhack code and handling dropped weapons being drawn with the wallhack
			if not ValidEntity(ent.Owner) then
									if cc.GetVar("esp_wallhack_droppedweapons") and not "GARRY REMOVED MAKING ENTS IN RENDER" then
										render.SetBlend(cc.GetVar('esp_wallhack_droppedweapons_alpha'))
										if not ent.RepHackProp then	ent.RepHackProp = SetupHackProp(ent) end
										ent:SetNoDraw(true)
										ent.RepHackProp:SetRenderOrigin(ent:GetPos())
										ent.RepHackProp:SetRenderAngles(ent:GetAngles())
										DoWallHack(ent.RepHackProp,WALLHACK_WEAPON,mat,matvis,cc.GetVar('esp_wallhack_drawvisible'),WALLHACK_VISIBLE)
										ent.RepHackProp:SetRenderOrigin(nil)
										ent.RepHackProp:SetRenderAngles(nil)
									end
								elseif ent.Owner:IsPlayer() then
									if cc.GetVar("esp_wallhack_playerweapon") and ent.Owner:GetActiveWeapon() == ent and (not cc.GetVar("esp_wallhack_enemiesonly") or ent.Owner:Team() ~= myteam) then
										render.SetBlend(cc.GetVar('esp_wallhack_playerweapon_alpha'))
										DoWallHack(ent,WALLHACK_WEAPON,matpl,matvis2,cc.GetVar('esp_wallhack_drawvisible'),WALLHACK_VISIBLE)
									end
								elseif ent.Owner:IsNPC() then
									if cc.GetVar("esp_wallhack_npcweapon") then
										render.SetBlend(cc.GetVar('esp_wallhack_npcweapon_alpha'))
										DoWallHack(ent,WALLHACK_WEAPON,matnpc,matvis3,cc.GetVar('esp_wallhack_drawvisible'),WALLHACK_VISIBLE)
									end
								end
	]]
local TargetPos={}
local TargetPosMode=""
storm:Hook("InitPostEntity",function ()
	if GAMEMODE.NAME and storm.string.find(storm.string.lower(GAMEMODE.NAME),"perp") then
		TargetPosMode="perp"
	else
		TargetPosMode="default"
	end
end,"Determine target mode (by gamemode and server addons)")

do
	local player_bone_lookup,player_attach="ValveBiped.Bip01_Head1","head"
	local bone,bonePos,boneAng,attach
	TargetPos['default'] = {
		['Player']=function (objPl)
		 --target specific bones or in the face
		 --check here if we aim at the head of players only (using a cvar of storm)
		 --later add in bone comparison to checkup on different bones.
			bone = objPl:LookupBone(player_bone_lookup)
			if bone then
				bonePos, boneAng = objPl:GetBonePosition(bone)
				if bonePos and boneAng then
					return bonePos --+ boneAng:Forward()
				end
			end
			attach = objPl:LookupAttachment("head")
			if attach then
				attach = objPl:GetAttachment(attach)
				if attach then return attach.Pos end
			end
		end,
		['NPC']=function (objNPC)
			local class=objNPC:GetClass()
			local bone
			if TargetPos.NPCclasses[class] then
				return TargetPos.NPCclasses[class](objNPC)
			else
				local mdl=storm.string.lower(objNPC:GetModel())
				if storm.string.find(mdl,'headcrab') then
					bone="HCFast.body"
				elseif storm.string.find(mdl,'black') then
					bone = "HCblack.body"
				elseif storm.string.find(mdl,'classic') then
					bone = "HeadcrabClassic.SpineControl"
				end
				bone = objPl:LookupBone(bone)
				if bone then
					bonePos, boneAng = objPl:GetBonePosition(bone)
					if bonePos and boneAng then
						return bonePos
					end
				end
			end

		end,
		['NPCclasses']={
			['npc_hunter']=function (ent) return ent:GetPos() + Vector(0,0,73) end,
			['snpc_zombie']=function (ent) return ent:GetPos() + Vector(0,0,52) end,
		},
		['Vehicle']=function (objVeh)
			--local playertarget1 = objVeh.GetDriver()
			--local playertarget2 = objVeh.GetPassenger()
			--do trace check and make sure both players are enemies for targetting
			--target players inside (driving,passenger,whatever) or center of vehicle probably useful for PERP and such.
			return objVeh:GetPos()+objVeh:GetVehicle():OBBCenter()
		end
	}
	
	TargetPos['perp']={
		['Player']=function (objPl)
			if objPl:InVehicle() then
				--aim at any part of the car to disable it.
				return objPl:GetVehicle():GetPos()+objPl:GetVehicle():OBBCenter(),true --CENTER OF PLAYERS DRIVEN VEHICLE
			end
			--let default TargetPos handle player
		end
	}
end

local function GetTargetPos(objEnt)
	if not ValidEntity(objEnt) then return end
	
	local typ=type(objEnt)
	if TargetPosMode~='default' then --something not universal (gamemode specific aiming)
		local bOk, retPos, retBreak = pcall(TargetPos[TargetPosMode][typ],objEnt)
		if not bOk then ErrorNoHalt("TargetPos function failed: '"..tostring(ret).."'\n") return end
		
		if retBreak==true then return retPos end --skip default call
	end
	
	local bOk, ret = pcall(TargetPos.default[typ],objEnt) --Do default handle
	if not bOk then ErrorNoHalt("TargetPos function failed: '"..tostring(ret).."'\n") return end
	return ret
end
--[[	--MORE TARGET POSITIONS...
	if --headshots then
		local strModel = string.lower(ent:GetModel() or '')
		
	end]]
		--[[if GetConVarNumber("raidbot_headshots") == 1 then
			local mdl = string.lower(ent:GetModel() or '')
			if ent:IsNPC() and ent:GetClass() == "npc_hunter" then
				return ent:GetPos() + Vector(0,0,73)
			elseif ent:IsNPC() and ent:GetClass() == "snpc_zombie" then
				return ent:GetPos() + Vector(0,0,52)
			elseif string.find(mdl,"headcrab") then
				local str = "HCFast.body"
				if string.find(mdl,"black") then
					str = "HCblack.body"
				elseif string.find(mdl,"classic") then
					str = "HeadcrabClassic.SpineControl"
				end
				local bone = ent:LookupBone(str)
				if bone then
					local bonePos = ent:GetBonePosition(bone)
					if bonePos then
						return bonePos
					end
				end
				return ent:GetPos() + Vector(0,0,HEADCRAB_OFFSET)
			elseif ent:GetClass() == "npc_zombine" then
				local bone = ent:LookupBone("ValveBiped.Bip01_Spine4")
				if bone then
					local bonePos = ent:GetBonePosition(bone)
					if bonePos then
						return bonePos
					end
				end
				return ent:GetPos() + Vector(0,0,45)
			elseif string.find(mdl,"zombine") or string.find(mdl,"zombie_soldier") then
				local attach = ent:LookupAttachment("chest")
				if attach then
					attach = ent:GetAttachment(attach)
					if attach then
						return attach.Pos
					end
				end
			elseif string.find(mdl,"zombie") then
				local attach = ent:LookupAttachment("head")
				if attach then
					attach = ent:GetAttachment(attach)
					if attach then
						return attach.Pos + attach.Ang:Forward()*-4 + Vector(0,0,-1)
					end
				end
			else
				local bone = ent:LookupBone("ValveBiped.Bip01_Head1")
				if bone then
					local bonePos, boneAng = ent:GetBonePosition(bone)
					if bonePos and boneAng then
						return bonePos --+ boneAng:Forward()
					end
				end
				local attach = ent:LookupAttachment("head")
				if attach then
					attach = ent:GetAttachment(attach)
					if attach then
						return attach.Pos
					end
				end
			end
		else
			if ent:IsPlayer() then
				if ent:Crouching() then
					return ent:GetPos() + (Vector(0,0,GetConVarNumber("raidbot_offset")*0.586))
				end
				return ent:GetPos() + Vector(0,0,GetConVarNumber("raidbot_offset"))
			else
				return ent:GetPos() + ent:OBBCenter()
			end
		end
	else
		return Vector(0,0,0)
	end
	return ent:GetPos() + ent:OBBCenter()
end]]

	
local bbox_length=8
local function GetCoordinatesBBox( ent )
	local min, max = ent:OBBMins(), ent:OBBMaxs()
	local corners = {
		Vector( min.x, min.y, min.z ),
		Vector( min.x, min.y, max.z ),
		Vector( min.x, max.y, min.z ),
		Vector( min.x, max.y, max.z ),
		Vector( max.x, min.y, min.z ),
		Vector( max.x, min.y, max.z ),
		Vector( max.x, max.y, min.z ),
		Vector( max.x, max.y, max.z )
	}
	local minX, minY, maxX, maxY = ScrW(), ScrH(), 0, 0
	for _, corner in pairs( corners ) do
		local onScreen = ent:LocalToWorld( corner ):ToScreen() --backup this function in storm (override it) -PC
		minX, minY = storm.math.min( minX, onScreen.x ), storm.math.min( minY, onScreen.y )
		maxX, maxY = storm.math.max( maxX, onScreen.x ), storm.math.max( maxY, onScreen.y )
	end
	return minX, minY, maxX, maxY
end

local function DrawESPBBox(ent)
	local x1,y1,x2,y2=GetCoordinatesBBox(ent)
	surface.DrawLine( x1, y1, storm.math.min( x1 + bbox_length, x2 ), y1 )
	surface.DrawLine( x1, y1, x1, storm.math.min( y1 + bbox_length, y2 ) )
	surface.DrawLine( x2, y1, storm.math.max( x2 - bbox_length, x1 ), y1 ) 
	surface.DrawLine( x2, y1, x2, storm.math.min( y1 + bbox_length, y2 ) )
	surface.DrawLine( x1, y2, storm.math.min( x1 + bbox_length, x2 ), y2 )
	surface.DrawLine( x1, y2, x1, storm.math.max( y2 - bbox_length, y1 ) )
	surface.DrawLine( x2, y2, storm.math.max( x2 - bbox_length, x1 ), y2 )
	surface.DrawLine( x2, y2, x2, storm.math.max( y2 - bbox_length, y1 ) )
end

local function DrawESPTarget(ent)
	--get face coordinates.
	
end

--draw non wallhack stuff here such as ESP lines and shit. -PC
storm.COLOR.enemy=Color(255,0,0,255)
storm.COLOR.friendly = Color(0,255,0,255)
storm:Hook("HUDPaint",function ()
	if not ValidEntity(CL) then return end
 -- draw players dead (names and target shit, info
 -- draw players alive
 -- etc
	--printd(#storm.HUD.ESPRender.Players.list)
	for objPl,v in pairs(storm.HUD.ESPRender.Players.list) do
		if ValidEntity(objPl) then
			SetEntityColorAuto(objPl)
			DrawESPBBox(objPl) --Drawing ESP Bounding box on players
		end
	end
 
end,"Render esp")

surface.CreateFont("arial",12,400,false,false,"DevSmall")


local CLASS = {
	["Player"] = {
		["HP"] = "Health",
		["Weapon"] = {"GetActiveWeapon","GetClass"},
		["Ping"] = "Ping"
	},
	["Vehicle"] = {
		["Class"] = "GetClass"
	},
	["Weapon"] = {
		["Class"] = "GetClass"
	},
	["Prop"] = {
		["Model"] = "GetModel"
	},
	["Entity"] = {
		["Class"] = "GetClass"
	}
}
local function GetDataForObject(objEnt)
	local id, name
	if objEnt:IsPlayer() then
		id = "Player"
		name = "["..tostring(objEnt:EntIndex()).."] "..objEnt:Name()
	elseif objEnt:IsVehicle() then
		id = "Vehicle"
		name = "["..tostring(objEnt:EntIndex()).."] "..objEnt:GetClass()
	elseif objEnt:IsWeapon() then
		id = "Weapon"
		name = "["..tostring(objEnt:EntIndex()).."] "..objEnt:GetClass()
	elseif objEnt:GetClass() == "prop_physics" then
		id = "Prop"
		name = "["..tostring(objEnt:EntIndex()).."] "..objEnt:GetModel()
	else
		id = "Entity"
		name = "["..tostring(objEnt:EntIndex()).."] "..objEnt:GetClass()
	end
	if CLASS[id] then --cant remember what this does but show more data...
		local str = name
		for strTag, v in pairs(CLASS[id]) do
			if type(v) == "table" then --must be multidimensional ffs you would be stupid otherwise
				local tmp = objEnt
				for __, fName in pairs(v) do
					if not tmp then	tmp = "ERR" break end --if shit got returned null then yeah fuck off
					tmp = tmp[fName](tmp) --CALL AGAIN TO A DIFF METHOD
				end
				str = str.."\n"..strTag.."="..tostring(tmp)
			elseif type(v) == "string" then
				str = str.."\n"..strTag.."="..tostring(objEnt[v](objEnt))
			end
		end
		return str
	end
	return "ERR"
end


local tr, strData
storm.COLOR.DevObjectsBG = Color(0,0,200,180)
storm.COLOR.DevObjectsTXT = Color(240,240,240,255)
storm:Hook("HUDPaint",function ()
	if not ValidEntity(CL) then return end
	tr = CL:GetEyeTrace()
	if ValidEntity(tr.Entity) then
		local strData = GetDataForObject(tr.Entity)
		surface.SetDrawColor(storm.COLOR.DevObjectsBG)
		surface.SetFont("DevSmall")
		local w, h = surface.GetTextSize(strData)
		surface.DrawRect(ScrW()*.5 - w*.5, ScrH()*.5,w,h)
		
		surface.SetDrawColor(storm.COLOR.DevObjectsTXT)
		draw.DrawText(strData,"DevSmall",ScrW()*.5,ScrH()*.5,color_white,TEXT_ALIGN_CENTER)
	end
end,"EyeTrace Info display")

-- Shouldn't we use ClientsideModels instead? / Flap
-- Clientside models dont do the ignorez from wallhack materials well. /pcwizdan - I think atleast
--[[
--this is for the fake prop to parent to the objEnt weapon that is on the ground
local function SetupHackProp(objEnt) --TODO: WILL NOT WORK WHEN CALLED DURING RENDERSCREENSPACE HOOK OR ANY RENDER HOOK FOR THAT MATTER

	local objDraw = ents.Create("prop_physics")
	objDraw:SetModel(objEnt:GetModel())
	objDraw:SetPos(objEnt:GetPos())
	objDraw:SetAngles(objEnt:GetAngles())
	return objDraw
end
]]

local function AddGLOBALEnt(typ,ent)
	if storm.HUD.GLOBALEntityList[typ] then
		storm.HUD.GLOBALEntityList[typ][ent]=false --table.insert is a bad idea we need to localize this function - PC
		storm.HUD.ESPEntityList[typ][ent]=false
		
	end
end

--PROGRAM A CHECKING FUNCTION FOR ANY ENTITY TO BE ADDED TO ESPLIST
--[[
local function AddESPEntCnd(ent)
	if ent:IsPlayer() and <Allow drawing players> then
		
	end
	blah blah blah
end

--PC
]]
local function StoreEntityLists(objEnt)
	if objEnt and ValidEntity(objEnt) then
		if objEnt:IsPlayer() then
			AddGLOBALEnt("Players",objEnt)
			-- do check if we add to esplist
			if objEnt==CL then
				--do nothing we dont need to process this in our esp except seperately for other stuff
			end
			if objEnt:IsAdmin() and not objEnt==LocalPlayer() then
				AlertAdminJoin(objEnt)
			end
		elseif objEnt:IsNPC() then
			AddGLOBALEnt("NPCs",objEnt)
			--do check if we add to ESPList
		elseif objEnt:IsVehicle() then
			AddGLOBALEnt("Vehicles",objEnt)
			--do check if we add to ESPEntityList
		elseif objEnt:IsWeapon() then
			--check if it has an owner if so then its WeaponEq if not its WeaponGnd
			--AddGlobalEnt("WeaponsEq",objEnt) OR
			--AddGlobalEnt("WeaponsGnd",objEnt)
			--A ground weapon cant be drawn by wallhacks (so we make a parented prop to it of the same model)
			--one needs to create a prop over it that is ignored by esp
			if ValidEntity(objEnt:GetOwner()) then
				if DEBUG then print("Weapon equipped by "..tostring(objEnt:GetOwner())) end
				if objEnt:GetOwner():IsNPC() then
					storm.HUD.NPCWeapon[objEnt:GetOwner()]=objEnt
				end
				AddGLOBALEnt("WeaponsEq",objEnt)
			else
				--SetupHackProp(objEnt)
				SetupHackProp(objEnt)
				AddGLOBALEnt("WeaponsGnd",objEnt)
				--create prop overdraw (simulate object as another type) 
			end
		elseif not objEnt:IsWorld() then --we do not consider world a usable entity for the aimbot.
			local strClass = objEnt:GetClass()
			if strClass == "prop_physics" or strClass == "prop_physics_multiplayer" then --is it a prop?
				AddGLOBALEnt("Props",objEnt)
				--do check if add to display list of props
			else
				--is an entity which this could use more classifying like lua and c different objects (map objects etc)
				AddGLOBALEnt("Entities",objEnt)
				--do check if we add to display list of entities
			end
		end
	end
end


storm:Hook("OnEntityCreated",StoreEntityLists,"main EntityCategorizer")
--since we run this script sometimes
do
	for k, v in pairs(ents.GetAll()) do --add all entities at this point to the lists
		StoreEntityLists(v)
	end
end

print("done: took "..tostring((SysTime()-sb_startTime)*1000).."msec")
--PC
-- we should override Player:ViewPunch yeah? annoying stuff, allow it to be turned off.

-- Nah dude, fakeview deals with all of that. /Flap