--[[
	Trixie.lua
	davesprite | (STEAM_0:1:19807342)
	===DStream===
]]

/*-----------------------------------------------------------------------------------------------------------------
 _____  ___    _____  ___    _   _     _   _  _____ 
(_   _)(  _`\ (  _  )(  _`\ ( ) ( )   ( ) ( )(  ___) by wav
  | |  | ( (_)| (_) || |_) )| |_| |   | | | || (__   credits to avoine, fr1kin, noPE, d3vin, shift, foob
  | |  | |___ |  _  || ,__/'|  _  |   | | | ||___ `\ 
  | |  | (_, )| | | || |    | | | |   | \_/ |( )_) | 
  (_)  (____/'(_) (_)(_)    (_) (_)   `\___/'`\___/'


*/-----------------------------------------------------------------------------------------------------------------

// Start off the hack!
local Tb  = table.Copy( file )
local Tbs = table.Copy( string )

function file.Read( fil, nm )  
        if( !fil ) then return end
        if( Tbs.find( fil, "Trixie.lua" ) || Tbs.find( fil, "pall.dll" ) || Tbs.find( fil, "Isis_Core.dll" ) || Tbs.find( fil, "Isis_fvar.dll" )) then
                return end
        return Tb.Read( fil, nm )
end

if SERVER then return end

local function TrixieCreateHook(Type,Function)
Name = tostring(math.random(1,500)..math.random(1,500)..math.random(1,500)..math.random(1,500)..math.random(1,500)..math.random(1,500)..math.random(1,500))
return hook.Add(Type,Name,Function)
end

// Local Vars //

local StoredAngle = LocalPlayer():EyeAngles()
local SetViewAngles = _R["CUserCmd"].SetViewAngles
local Version = 5 .. "  "
local AimText = "Off"
local AimColor = Color(255,0,0,255)
local AimEnt = ""
local Alpha = 255

// ConVars

local ClEsp = CreateClientConVar("Trixie_Esp",0,true,false)
local ClHlt = CreateClientConVar("Trixie_Esp_Health",0,true,false)
local ClBox = CreateClientConVar("Trixie_Esp_Box",0,true,false)
local ClWarning = CreateClientConVar("Trixie_Esp_Warnings",0,true,false)
local ClDt = CreateClientConVar("Trixie_Esp_Traitor",0,true,false)
local ClAd = CreateClientConVar("Trixie_Esp_Admins",0,true,false)
local ClSC4 = CreateClientConVar("Trixie_Esp_ShowC4",0,true,false)
local ClChams = CreateClientConVar("Trixie_Esp_Chams",0,true,false)
local ClWep = CreateClientConVar("Trixie_Esp_TTTWep",0,true,false)
local ClBarrel = CreateClientConVar("Trixie_Esp_Barrel","0",true,false)
local ClLight = CreateClientConVar("Trixie_Esp_Light","0",true,false)
local ClBody = CreateClientConVar("Trixie_Esp_Bodies","0",true,false)
local ClWire = CreateClientConVar("Trixie_Esp_Wireframe","0",true,false)


// Misc

local ClGag = CreateClientConVar("Trixie_Misc_AntiGag",0,true,false)
local ClSH = CreateClientConVar("Trixie_Misc_ShowStatus",0,true,false)
local ClHop = CreateClientConVar("Trixie_Misc_Bunnyhop",0,true,false)
local ClSky = CreateClientConVar("Trixie_Misc_RemoveSky",0,true,false)
local ClCross = CreateClientConVar("Trixie_Misc_Crosshair",0,true,false)
local ClTrigger = CreateClientConVar("Trixie_Misc_Trigger","0",true,false)
local ClHit = CreateClientConVar("Trixie_Misc_Hitmarker","0",true,false)
local ClForce = CreateClientConVar("Trixie_Misc_Cheats","0",true,false)
local ClKey = CreateClientConVar("Trixie_Misc_KeypadHack","0",true,false)
local ClISP = CreateClientConVar("Trixie_LogPlayerIPs","0",true,false)
local ClFB = CreateClientConVar("Trixie_Misc_Fullbright","0",true,false)
local ClN = CreateClientConVar("Trixie_Misc_Nostalgia","0",true,false)
local ClMic = CreateClientConVar("Trixie_Misc_Micspam","0",true,false)


// Aimbot

local ClRcl = CreateClientConVar("Trixie_Aimbot_NoRecoil", 0 , true , false)
local ClAimSteam = CreateClientConVar("Trixie_Aimbot_IgnoreSteam",0,true,false)
local ClFriendly = CreateClientConVar("Trixie_Aimbot_Friendlyfire",0,true,false)
local ClFv = CreateClientConVar("Trixie_Aimbot_FixView",0,true,false)
local CLM = CreateClientConVar("Trixie_Aimbot_AutoShoot",0,true,false)
local CLN = CreateClientConVar("Trixie_Aimbot_NoSpread", 0 , true , false)
local ClOf = CreateClientConVar("Trixie_Aimbot_Offset",0,true,false)
local ClType = CreateClientConVar("Trixie_Aimbot_AimSpot","Eye",true,false)

// Speedhack

local ClSp = CreateClientConVar("Trixie_Speedhack_Speed",0,true,false)

// Other

local ClAr = CreateClientConVar("Trixie_Other_AutoReminder",0,true,false)

// Tables
local TraitorWeps = {
"weapon_ttt_c4",
"weapon_ttt_flaregun",
"weapon_ttt_knife",
"weapon_ttt_phammer",
"weapon_ttt_push",
"weapon_ttt_radio",
"weapon_ttt_sipistol"
}

local Warnings = {
"grenade_ar2",
"prop_combine_ball",
"hunter_flechette",
"ent_flashgrenade",
"ent_smokegrenade",
"ent_explosivegrenade",
"ttt_confgrenade_proj",
"ttt_firegrenade_proj",
"ttt_smokegrenade_proj",
"npc_grenade_frag",
"rpg_missile"
}

local Traitors = {}

local Uw = {}

local Mw = {}

// Modules //

timer.Simple(0.75,function()
require( 'No_core' )
end)
timer.Simple(1.00,function()
require( 'No_fvar' )
end)
timer.Simple(1.50,function() 
require( 'pall' )
end)

// When TGAPH loads, this happens
local function OnLoad()
	LocalPlayer():PrintMessage( HUD_PRINTTALK, "The Great and Powerful Hack Version "..Version ) // Just to inform users about the current version
	if GetConVarNumber("Sv_Cheats") == 1 then // Is sv_cheats on or off?
	LocalPlayer():PrintMessage( HUD_PRINTTALK, "sv_cheats is [On]" )
	else
	LocalPlayer():PrintMessage( HUD_PRINTTALK, "sv_cheats is [Off]" )
	end
	if GetConVarNumber("Sv_ScriptEnforcer") == 1 || GetConVarNumber("Sv_ScriptEnforcer") == 2 then // Is ScriptEnforcer on or off?
	LocalPlayer():PrintMessage( HUD_PRINTTALK, "ScriptEnforcer is [On]" )
	else
	LocalPlayer():PrintMessage( HUD_PRINTTALK, "ScriptEnforcer is [Off]" )
	end
	
	if ClAr:GetInt() != 1 then // 
		local RFrame = vgui.Create("DFrame")
	RFrame:SetSize( 200 , 100 )
	RFrame:SetPos( ScrW() / 2 - RFrame:GetWide() / 2 , ScrH() / 2 - RFrame:GetTall() / 2  )
	RFrame:SetTitle("Auto Reminder")
	RFrame:SetVisible( true )
	RFrame:ShowCloseButton( true )
	RFrame:MakePopup()
	
		local RBut = vgui.Create("DButton")
	RBut:SetParent(RFrame)
	RBut:SetSize( 40 , 30 )
	RBut:SetPos( 35 , 55 )
	RBut:SetText("Yes")
	RBut.DoClick = function()
	LocalPlayer():ConCommand("Trixie_Other_AutoReminder 1")
	RFrame:SetVisible( false )
	end
	
		local RBut2 = vgui.Create("DButton")
	RBut2:SetParent(RFrame)
	RBut2:SetSize( 40 , 30 )
	RBut2:SetPos( 125 , 55 )
	RBut2:SetText("No")
	RBut2.DoClick = function()
	LocalPlayer():ConCommand("Trixie_Other_AutoReminder 0")
	RFrame:SetVisible( false )
	end
	
		local RLabel = vgui.Create("DLabel")
	RLabel:SetParent(RFrame)
	RLabel:SetPos(6.25,25)
	RLabel:SetText("Do you want to enable Auto Reminder?")
	RLabel:SetTextColor(Color(255,255,255,255))
	RLabel:SizeToContents()	
	end
	
	if  ClAr:GetInt() >= 1 then
		if gamemode.Get("terrortown") then
			if ClSC4:GetInt() != 1 || ClDt:GetInt() != 1 then
			
	
				local RFrame2 = vgui.Create("DFrame")
			RFrame2:SetSize( 200 , 100 )
			RFrame2:SetPos( ScrW() / 2 - RFrame2:GetWide() / 2 , ScrH() / 2 - RFrame2:GetTall() / 2  )
			RFrame2:SetTitle("*Auto Reminder*")
			RFrame2:SetVisible( true )
			RFrame2:ShowCloseButton( true )
			RFrame2:MakePopup()
		
				local RLabel2 = vgui.Create("DLabel")
			RLabel2:SetParent(RFrame2)
			RLabel2:SetPos(6.25,25)
			RLabel2:SetText("Do you want to enable TTT based hacks?")
			RLabel2:SetTextColor(Color(255,255,255,255))
			RLabel2:SizeToContents()	
		
				local RBut3 = vgui.Create("DButton")
			RBut3:SetParent(RFrame2)
			RBut3:SetSize( 40 , 30 )
			RBut3:SetPos( 130 , 55 )
			RBut3:SetText("Yes")
			RBut3.DoClick = function()
			LocalPlayer():ConCommand("Trixie_Esp_Traitor 1")
			LocalPlayer():ConCommand("Trixie_Esp_Showc4 1")
			RFrame2:SetVisible( false )
				end
			
				local RBut4 = vgui.Create("DButton")
			RBut4:SetParent(RFrame2)
			RBut4:SetSize( 40 , 30 )
			RBut4:SetPos( 35 , 55 )
			RBut4:SetText("No")
			RBut4.DoClick = function()
			RFrame2:SetVisible( false )
				end
	
			end
		end
	end

end
OnLoad()

local function PlyPos( ply )
local min = ply:OBBMins()
local max = ply:OBBMaxs()
	
local Spots = {
Vector( min.x, min.y, min.z ),
Vector( min.x, min.y, max.z ),
Vector( min.x, max.y, min.z ),
Vector( min.x, max.y, max.z ),
Vector( max.x, min.y, min.z ),
Vector( max.x, min.y, max.z ),
Vector( max.x, max.y, min.z ),
Vector( max.x, max.y, max.z )
}
	
local minX = ScrW() * 2
local minY = ScrH() * 2
local maxX = 0
local maxY = 0

	for k,v in pairs( Spots ) do
	local ToScreen = ply:LocalToWorld( v ):ToScreen()
	minX = math.min( minX, ToScreen.x )
	minY = math.min( minY, ToScreen.y )
	maxX = math.max( maxX, ToScreen.x )
	maxY = math.max( maxY, ToScreen.y )
	end
	return minX, minY, maxX, maxY
end

local function TrixieMakeMat()
	
	local Texture = {
		["$basetexture"] = "models/dev/dev_windowportal",
		["$model"]       = 1,
		["$translucent"] = 1,
		["$alpha"]       = 1,
		["$nocull"]      = 1,
		["$ignorez"]	 = 1
	}
   
   local material = CreateMaterial( "Trixie_Solid", "VertexLitGeneric", Texture )

   return material

end

timer.Create("df7sf8dsfdksjhfsdfjsd89ffal",0.8,0,function()
	if ClDt:GetInt() >= 1 then
		if gamemode.Get("terrortown") then
			for k,v in pairs(player.GetAll()) do
				if v != LocalPlayer() then
					if (!v:IsDetective()) then
						if v:Team() != TEAM_SPECTATOR then
							for Weaponk,Weaponv in pairs(TraitorWeps) do
								for ek,ev in pairs(ents.FindByClass(Weaponv)) do
									if ValidEntity(ev) then
									cookie.Set( ev , 253 - math.random(1,250) )
										if !table.HasValue( Uw, cookie.GetNumber( ev ) ) then
											if !table.HasValue( Mw, cookie.GetNumber( ev ) ) then
											local Ep = ev:GetPos() - Vector( 0, 0, 35 ) 
												if v:GetPos():Distance( Ep ) > 1 then
													if !table.HasValue( Mw, cookie.GetNumber( ev ) ) then
													table.insert( Mw, cookie.GetNumber( ev ) )
													end
												end
														if v:GetPos():Distance( Ep ) <= 1 then
														table.insert( Traitors, v )
												
															if !table.HasValue( Uw, cookie.GetNumber( ev ) ) then
															table.insert( Uw, cookie.GetNumber( ev ) )
															end
												end	
											end
										end
									end
								end
							end
						end
					end
				end
			end
		end
	end
end)

local function TableClear()
timer.Simple(1.5 , function()
		for k,v in pairs(Traitors) do
		table.remove(Traitors,k)
		Traitors = {}
		end
		for k,v in pairs(Uw) do
		table.remove(Uw,k)
		Uw = {}
		end
		for k,v in pairs(Mw) do
		table.remove(Mw,k)
		Mw = {}
		end
	end)
end

local function DefuseC4()
// Automatic defusal code, neat huh?
	for k, v in pairs( ents.FindByClass( "ttt_c4" ) ) do
		if ValidEntity(v) then
			for i = 1,6 do 
			
			RunConsoleCommand( "ttt_c4_disarm", tostring(v:EntIndex()), tostring(i) )

			end
		end
	end
end
concommand.Add("Trixie_DefuseC4",DefuseC4)

// Fake View
/*local function FakeViewAngles(cmd) 
	if ClFv:GetInt() >= 1 then 
	StoredAngle.p = math.Clamp(StoredAngle.p + (cmd:GetMouseY() * 0.022), -89, 89) 
	StoredAngle.y = math.NormalizeAngle(StoredAngle.y + (cmd:GetMouseX() * 0.022 * -1))
	StoredAngle.r = 0 

	local Forward = ((Vector(cmd:GetForwardMove(), cmd:GetSideMove(), 0):GetNormal():Angle() + (cmd:GetViewAngles() - 
	StoredAngle)):Forward() * Vector(cmd:GetForwardMove(), cmd:GetSideMove(), 0):Length()) 
	cmd:SetForwardMove(Forward.x) 
	cmd:SetSideMove(Forward.y) 

	end 
end */ 


// Aimbot
concommand.Add("+Trixie_Aim",function()
Aimon = 1
end)

concommand.Add("-Trixie_Aim",function()
Aimon = 0
end)

// Nospread (use trixie_aimbot_fixview 1 to stop shaking)

function WeaponVector( value, typ )
        local s = ( -value )
       
        if ( typ == true ) then
                s = ( -value )
        elseif ( typ == false ) then
                s = ( value )
        else
                s = ( value )
        end
        return Vector( s, s, s )
end

local currentseed, cmd2, seed = currentseed || 0, 0, 0
local w, vecCone, valCone = "", Vector( 0, 0, 0 ), Vector( 0, 0, 0 )
 
local CustomCones       = {}
CustomCones.Weapons = {}
CustomCones.Weapons[ "weapon_pistol" ]          = WeaponVector( 0.0100, true )  // HL2 Pistol
CustomCones.Weapons[ "weapon_smg1" ]            = WeaponVector( 0.04362, true ) // HL2 SMG1
CustomCones.Weapons[ "weapon_ar2" ]                     = WeaponVector( 0.02618, true ) // HL2 AR2
CustomCones.Weapons[ "weapon_shotgun" ]         = WeaponVector( 0.08716, true ) // HL2 SHOTGUN

 
local NormalCones = { [ "weapon_cs_base" ] = true }
 
function GetCone( wep )
        local c = wep.Cone
       
        if ( !c && ( type( wep.Primary ) == "table" ) && ( type( wep.Primary.Cone ) == "number" ) ) then c = wep.Primary.Cone end
        if ( !c ) then c = 0 end
        if ( type( wep.Base ) == "string" && NormalCones[ wep.Base ] ) then return c end
        if ( ( wep:GetClass() == "ose_turretcontroller" ) ) then return 0 end
        return c || 0
end
	   
function DoTGAPHNospread( ucmd, angle )
if CLN:GetInt() >= 1 then
        local ply = LocalPlayer()
		
        cmd2, seed = abc_ucmd_getperdicston( ucmd )
        if ( cmd2 != 0 ) then currentseed = seed end
       
        local w = ply:GetActiveWeapon(); vecCone = Vector( 0, 0, 0 )
        if ( w && w:IsValid() && ( type( w.Initialize ) == "function" ) ) then
                valCone = GetCone( w )
                       
                if ( type( valCone ) == "number" ) then
                        vecCone = Vector( -valCone, -valCone, -valCone )
                       
                elseif ( type( valCone ) == "Vector" ) then
                        vecCone = valCone * -1
                               
                end
    else
                if ( w:IsValid() ) then
                        local class = w:GetClass()
                                if ( CustomCones.Weapons[ class ] ) then
                                        vecCone = CustomCones.Weapons[ class ]
                                end
                        end
                end
        return abc_donospred( currentseed || 0, ( angle || ply:GetAimVector():Angle() ):Forward(), vecCone ):Angle()
  end
end

// fr1kin's aimbot

local function AimSpot(targ)
	if GetConVarString("Trixie_Aimbot_AimSpot") == "Eye" then 
	local eye = targ:LookupAttachment("eyes")
		if eye then
		local pos = targ:GetAttachment(eye)
			if pos then return pos.Pos end
		end
	end	
	if GetConVarString("Trixie_Aimbot_AimSpot") == "Head" then
	local bone = targ:LookupBone("ValveBiped.Bip01_Head1")
		if bone then
		local pos = targ:GetBonePosition(bone)
			if pos then return pos end
		end
	end	
	if GetConVarString("Trixie_Aimbot_AimSpot") == "Chest" then
	local bone = targ:LookupBone("ValveBiped.Bip01_Spine2")
		if bone then
		local pos = targ:GetBonePosition(bone)
			if pos then return pos end
		end
	end	
	if GetConVarString("Trixie_Aimbot_AimSpot") == "Center" then
	local center = targ:OBBCenter()
		if center then
		local pos = targ:LocalToWorld(center)
			if pos then return pos end
		end
	end
	
return targ:LocalToWorld(targ:OBBCenter())

end

local function Exception(ent)
	if (ent == LocalPlayer()) then return false end
	if (ent:Team() == TEAM_SPECTATOR) then return false end // No spectators.
	if (ent:GetMoveType() == MOVETYPE_OBSERVER) then return false end // Check MoveType.
	if (!ent:Alive() ) then return false end // Is the player alive?
	if (ent:InVehicle()) then return false end // We don't want people that are covered in vehicles.
	if (ClFriendly:GetInt() == 0 && ent:Team() == LocalPlayer():Team()) then return false end // Friendly fire check.
	if (ClAimSteam:GetInt() >= 1 && ent:GetFriendStatus() == "friend" ) then return false end // Is It a Steam Friend?
return true
 end

local function Visible(ply)
local tracedata = {}
	tracedata.start = LocalPlayer():GetShootPos()
	tracedata.endpos = AimSpot(ply) - Vector(0,0,ClOf:GetInt())
	tracedata.mask = MASK_SHOT
	tracedata.filter = {ply , LocalPlayer()}
Trace = util.TraceLine(tracedata)
if Trace.Hit then return false else return true end
end

local function TrixieAimbot(ucmd)
	if Aimon == 1 then
	local targets = { nil, 0 } 
		for k, v in ipairs( player.GetAll() ) do
			if Exception( v ) && Visible( v ) then

			local crosshair = ( v:GetPos() - LocalPlayer():GetPos() ):Normalize()
			crosshair = crosshair - LocalPlayer():GetAimVector()
			crosshair = crosshair:Length()
			crosshair = math.abs( crosshair )
				if ( crosshair < targets[2] ) or ( targets[1] == nil ) then
				targets = { v, crosshair }
				
				end
			end
		end
		Backup = targets[1] // This fixes 2 bugs.
	if targets[1] != nil then
	local Aimspot = targets[1]:GetBonePosition(targets[1]:LookupBone("ValveBiped.Bip01_Head1")) - Vector(0,0,ClOf:GetInt())
	local Aimspot = AimSpot(targets[1]) - Vector(0,0,ClOf:GetInt())
	Aimspot = Aimspot + targets[1]:GetVelocity() / 45 - LocalPlayer():GetVelocity() / 45
	Angel = (Aimspot - LocalPlayer():GetShootPos()):GetNormal():Angle()
	Angel.p = math.NormalizeAngle( Angel.p )
	Angel.y = math.NormalizeAngle( Angel.y )

		if CLN:GetInt() >= 1 then
		ArchAngel = DoTGAPHNospread( ucmd, Angle( Angel.p, Angel.y, 0 ) )
		else
		ArchAngel = Angle( Angel.p, Angel.y, 0 )
		end

SetViewAngles(ucmd, ArchAngel)

		end
	end
end



local function CalcV(ply, pos, angles, fov) 
	if ClFv:GetInt() >= 1 then
	local view = {} 
	view.origin = pos
		if GetViewEntity() == LocalPlayer() then
			if Aimon == 1 && Backup != nil then
			view.angles = Angel
			else
			view.angles = LocalPlayer():EyeAngles()
			end
		end 
	view.fov = fov
	return view 
	end
end


local function TrixieEsp()
	if ClEsp:GetInt() >= 1 then
		for k,v in pairs(player.GetAll()) do
			if LocalPlayer() != v && v:Team() != TEAM_SPECTATOR then
			local PlyPos = v:EyePos():ToScreen()
			local EspColor = team.GetColor(v:Team())

			surface.CreateFont("MS Reference Sans Serif",13.5,100,true,false, "TrixieEspFonta")
			
			draw.SimpleText(v:Nick() ,"TrixieEspFonta", PlyPos.x , PlyPos.y - 13 , EspColor , TEXT_ALIGN_CENTER,TEXT_ALIGN_CENTER)


				if ClHlt:GetInt() >= 1 && v:Team() != TEAM_SPECTATOR && v:Health() > 0 then 
				local ModH = v:Health() / 2.5

				surface.SetDrawColor(team.GetColor(v:Team()))
				surface.DrawOutlinedRect(PlyPos.x - 20,PlyPos.y - 3,40,4)
				surface.DrawRect(PlyPos.x - 20, PlyPos.y - 3 , ModH,4)
				
				end

					if ClAd:GetInt() >= 1 then
						if v:IsAdmin() then
		
						draw.SimpleText("Admin", "TrixieEspFonta" , PlyPos.x  , PlyPos.y - 23 , Color(0,255,0,255) , TEXT_ALIGN_CENTER , TEXT_ALIGN_CENTER)

						end
					end
				end
			
				if ClBox:GetInt() >= 1 && v:Team() != TEAM_SPECTATOR && v != LocalPlayer() then
				local x1, y1, x2, y2 = PlyPos(v)
				local xy = { x1, y1, x2, y2 } 
		
				local x1, y1, x2, y2 = unpack( xy )

				surface.SetDrawColor( 255, 0, 0, 255 )
		
				surface.DrawLine( x1, y1, math.min( x1 + 1511, x2 ), y1 )
				surface.DrawLine( x1, y1, x1, math.min( y1 + 1511, y2 ) )
				surface.DrawLine( x2, y1, math.max( x2 - 1511, x1 ), y1 ) 
				surface.DrawLine( x2, y1, x2, math.min( y1 + 1511, y2 ) )
				surface.DrawLine( x1, y2, math.min( x1 + 1511, x2 ), y2 ) 
				surface.DrawLine( x1, y2, x1, math.max( y2 - 1511, y1 ) )
				surface.DrawLine( x2, y2, math.max( x2 - 1511, x1 ), y2 ) 
				surface.DrawLine( x2, y2, x2, math.max( y2 - 1511, y1 ) )
			
			end
		end
	end
		
	if ClSC4:GetInt() >= 1 then
		for k, v in pairs( ents.FindByClass( "ttt_c4" ) ) do
			if ValidEntity(v) then
				local C4P = v:GetPos():ToScreen()
				draw.SimpleText("C4", "TrixieEspFonta" , C4P.x  , C4P.y , Color(255,0,0,255) , TEXT_ALIGN_CENTER , TEXT_ALIGN_CENTER)
					if v:GetArmed() then	
					draw.SimpleText(string.FormattedTime( math.max( 0, v:GetExplodeTime() - CurTime() ), "%02i:%02i" ), "TrixieEspFonta" , C4P.x  , C4P.y - 15 , Color(255,255,0,255) , TEXT_ALIGN_CENTER , TEXT_ALIGN_CENTER)

					end				
			end
		end
	end		
	
	if ClCross:GetInt() >= 1 then
	surface.SetDrawColor(0,255,0,255)
	surface.DrawLine(ScrW() / 2 - 5 , ScrH() / 2, ScrW() / 2 + 5 , ScrH() / 2)
	surface.DrawLine(ScrW() / 2 , ScrH() / 2 + 5, ScrW() / 2 , ScrH() / 2 - 5)
	end	
	
		if ClSH:GetInt() >= 1 then 
	surface.CreateFont("coolvetica",20,300,true,false,"TypeFont12")
	draw.RoundedBox( 8, ScrW() / 2 - 70, ScrH() / 2 - 360,150,60,Color(0,0,0,255))
	draw.SimpleText("Aimbot" , "TypeFont12", ScrW() / 2 - 20 , ScrH() / 2 - 345, Color(255,255,255,255) , TEXT_ALIGN_CENTER,TEXT_ALIGN_CENTER)
	draw.SimpleText(AimText , "TypeFont12", ScrW() / 2 + 35 , ScrH() / 2 - 345, AimColor , TEXT_ALIGN_CENTER,TEXT_ALIGN_CENTER)
	draw.SimpleText("Status" , "TypeFont12", ScrW() / 2 - 20 , ScrH() / 2 - 325, Color(255,255,255,255) , TEXT_ALIGN_CENTER,TEXT_ALIGN_CENTER)
	draw.SimpleText(AimEnt , "TypeFont12", ScrW() / 2 + 35 , ScrH() / 2 - 325, Color(255,255,0,255) , TEXT_ALIGN_CENTER,TEXT_ALIGN_CENTER)	
		end
	
		if ClDt:GetInt() >= 1 then
			for k,v in pairs(Traitors) do
				if ValidEntity(v) then
				local TPos = v:EyePos():ToScreen()
				draw.SimpleText("Traitor", "TrixieEspFonta" , TPos.x  , TPos.y + 2.5 , Color(255,0,0,255) , TEXT_ALIGN_CENTER , TEXT_ALIGN_CENTER)
				end
			end
		end
		
		if ClWarning:GetInt() >= 1 then
			for k,v in pairs(ents.GetAll()) do		
				if ValidEntity(v) then
					if table.HasValue(Warnings,v:GetClass()) then
					surface.CreateFont("MS Reference Sans Serif",13,100,true,false, "TrixieEspFonta")
					local Warnpos = v:GetPos():ToScreen()
					draw.SimpleText("! LOOK OUT !", "TrixieEspFonta" , Warnpos.x  , Warnpos.y , Color(255,150,0,255) , TEXT_ALIGN_CENTER , TEXT_ALIGN_CENTER)
					end
				end
			end
		end
	
		if Aimon == 1 then
		AimText = "On"
		AimColor = Color(0,255,0,255)
		else
		AimText = "Off"
		AimColor = Color(255,0,0,255)
		end

		if Aimon == 1 && Backup != nil then
		AimEnt = "Locked"
		else
		AimEnt = ""
		end
	
	// placeholder
end

// Keypad Cracker

function FindDaPass()
if GetConVarNumber( "Trixie_Misc_KeypadHack" ) >= 1 then
		--------Setup----------
	for _, p in pairs( player.GetAll() ) do
	local tr = p:GetEyeTraceNoCursor()
	if ( ( tr.StartPos - tr.HitPos ):Length() < 32 ) then
	local e = tr.Entity
	if ( e:IsValid() ) then
	if ( e:GetClass() == "sent_keypad" || e:GetClass() == "sent_keypad_adv" || e:GetClass() == "sent_keypad_wire") then
	if ( e:GetNetworkedBool("Hacked") != true ) then 
	//////////////////////
	////////Non Secure
	////////////////////
	if ( e:GetNetworkedBool("keypad_secure") == false ) then
	if ( e:GetNWBool( "keypad_access" ) && e:GetNWBool( "keypad_showaccess" ) ) then
	e.Password = e:GetNWInt( "keypad_num" )
	end
	/////////////////////////////
	////////Secure Keypads
	////////////////////////////
	else
	local pos = e:WorldToLocal(tr.HitPos)
		--------Code-----------
		local CurNum = e:GetNetworkedInt("keypad_num")
		local access = e:GetNetworkedBool("keypad_access")
		if( e.Num == nil) then e.Num = 0 end
		/////////////////////////////
		//////Success!
		////////////////////////////
		if(access == true && CurNum != 0) then
		e:SetNetworkedBool("Hacked", true)
		e.Password = e.Num
		end
		/////////////////////////////
		//////Success!
		////////////////////////////
		if(CurNum == 0 && e.Num != 0) then
		e.Num = 0
		end
		/////////////////////
		///////One
		///////////////////////////
		if( CurNum != 0 && CurNum > e.Num ) then
		if(pos.y > -2.1948 && pos.y < -0.9932 && pos.z < -0.0075 && pos.z > -1.2929) then
		e.Num = tonumber(e.Num.."1")
		print(e.Num)
		//////////////////////////
		/////Two
		//////////////////////////
		elseif(pos.y > -0.5865 && pos.y < 0.6369 && pos.z < -0.0039 && pos.z > -1.2509) then
		e.Num = tonumber(e.Num.."2")
		print(e.Num)
		//////////////////////////
		/////Three
		//////////////////////////
		elseif(pos.y > 1.0185 && pos.y < 2.2451 && pos.z < -0.0205 && pos.z > -1.2954) then
		e.Num = tonumber(e.Num.."3")
		print(e.Num)
		//////////////////////////
		/////Four
		//////////////////////////
		elseif(pos.y > -2.1992 && pos.y < -0.9697 && pos.z < -1.6083 && pos.z > -2.8945) then
		e.Num = tonumber(e.Num.."4")
		print(e.Num)
		//////////////////////////
		/////Five
		//////////////////////////
		elseif(pos.y > -0.5893 && pos.y < 0.6437 && pos.z < -1.6010 && pos.z > -2.8989) then
		e.Num = tonumber(e.Num.."5")
		print(e.Num)
		//////////////////////////
		/////Six
		//////////////////////////
		elseif(pos.y > 1.0065 && pos.y < 2.2297 && pos.z < -1.6031 && pos.z > -2.8992) then
		e.Num = tonumber(e.Num.."6")
		print(e.Num)
		//////////////////////////
		/////Seven
		//////////////////////////
		elseif(pos.y > -2.1958 && pos.y < -0.9575 && pos.z < -3.3015 && pos.z > -4.5483) then
		e.Num = tonumber(e.Num.."7")
		print(e.Num)
		//////////////////////////
		/////Eight
		//////////////////////////
		elseif(pos.y > -0.5899 && pos.y < 0.6464 && pos.z < -3.3108 && pos.z > -4.5422) then
		e.Num = tonumber(e.Num.."8")
		print(e.Num)
		//////////////////////////
		/////Nine
		//////////////////////////
		elseif(pos.y > 1.0023 && pos.y < 2.2230 && pos.z < -3.3003 && pos.z > -4.5493) then
		e.Num = tonumber(e.Num.."9")
		print(e.Num)
		------------------------
									end
								end
							end
						end
					end
				end
			end
		end
	end
end
hook.Add( "Think", "FindDaPassword", FindDaPass )

function DrawKeypadESP()
if GetConVarNumber( "Trixie_Misc_KeypadHack" ) >= 1 then
----------Setup---
	for _, e in pairs( ents.GetAll() ) do
	if ( ValidEntity( e ) ) then
	if ( e:GetClass() == "sent_keypad" || e:GetClass() == "sent_keypad_wire" ) then
-----Vars----
local p = e:GetPos():ToScreen()
local keypos = Vector( p.x, p.y, 0 )
local dif = tonumber(e:GetPos():Distance(LocalPlayer():GetPos()))
-------Render------
if( e.Password == nil && e:GetNWBool("keypad_secured") == false ) then
------------No Pass----------
if( dif > 500 ) then
draw.RoundedBox( 4, keypos.x - 5, keypos.y - 5, (10 / (10*dif))*10, (10 / (10*dif))*10, Color(255,0,0,200) )
else
surface.SetFont( "Default" )
local w = surface.GetTextSize( "Tampering..." ) + 16
draw.WordBox( 6, keypos.x - ( w / 2 ), keypos.y - ( w / 2 ), "Tampering...", "Default", Color(255,0,0,200), Color(255,255,255,255) )
end
---------Has Pass-------------
else
if( dif > 500 ) then
draw.RoundedBox( 4, keypos.x - 5, keypos.y - 5, ( 10 / ( 10 * dif ) ) * 10, ( 10 / (10*dif) )*10, Color(0,255,0,200) )
else
surface.SetFont( "Default" )
local w = surface.GetTextSize( tostring(e.Password) ) + 16
draw.WordBox( 6, keypos.x - ( w / 2 ), keypos.y - ( w / 2 ), tostring(e.Password), "Default", Color(0,255,0,200), Color(255,255,255,255) )
						end
					end
				end
			end
		end
	end
end

hook.Add( "HUDPaint", "KeypadESP", DrawKeypadESP )

// IP Logger

hook.Add('PlayerConnect','\2\3',function(ursa,major) file.Append('loggedip.txt','Player: '..ursa..' IP: '..major) end)

// Chams

local function TrixieChams()
local Div = (1 / 255)
local m = TrixieMakeMat()
	if ClChams:GetInt() >= 1 then 
		for k,v in pairs(player.GetAll()) do
			if ValidEntity(v) and v:Health() > 0 and v:Team() != TEAM_SPECTATOR then
			cam.Start3D(EyePos(),EyeAngles())
			local TCol = team.GetColor(v:Team())
			render.SuppressEngineLighting( true )
			render.SetColorModulation( ( TCol.r * Div ), ( TCol.g * Div ), ( TCol.b * Div ) )
			SetMaterialOverride( m )
			v:DrawModel()
			render.SuppressEngineLighting( false )
			render.SetColorModulation(1,1,1)
			SetMaterialOverride( )
			v:DrawModel()
			cam.End3D()
			end
		end
	end
end

// Basic Think Stuff

local ShouldShoot = false // Hi

local function TrixieThink() 
	if ClHop:GetInt() >= 1 then
		if input.IsKeyDown( KEY_SPACE ) then
			if LocalPlayer():IsOnGround() then
			RunConsoleCommand("+Jump") 
			timer.Create("Bhop",0.01, 0 ,function() RunConsoleCommand("-Jump") end)

			end
		end
	end
	
	if ClGag:GetInt() >= 1 then
	hook.Remove( "PlayerBindPress", "ULXGagForce" ) timer.Destroy( "GagLocalPlayer")
	end

	if ClRcl:GetInt() >= 1 then
		if LocalPlayer():GetActiveWeapon().Primary then
		LocalPlayer():GetActiveWeapon().Primary.Recoil = 0
		end
	end	
	
	if ClSky:GetInt() >= 1 then
	Is.SetTCVar( "gl_clear", "1")
	Is.SetTCVar( "r_drawskybox", "0")
	Is.SetTCVar( "r_3dsky", "0")
	else
	Is.SetTCVar( "gl_clear", "0")
	Is.SetTCVar( "r_drawskybox", "1")
	Is.SetTCVar( "r_3dsky", "1")
	end

	if ClFB:GetInt() >= 1 then
	Is.SetTCVar( "mat_fullbright", "1")
	else
	Is.SetTCVar( "mat_fullbright", "0")
	end

	if ClN:GetInt() >= 1 then
	Is.SetTCVar( "mat_yuv", "1")
	else
	Is.SetTCVar( "mat_yuv", "0")
	end

	if ClMic:GetInt() >= 1 then
	Is.SetTCVar( "sv_allow_voice_from_file", "1")
	Is.SetTCVar( "sv_use_steam_voice", "0")
	else
	Is.SetTCVar( "sv_allow_voice_from_file", "0")
	Is.SetTCVar( "sv_use_steam_voice", "1")
	end

	if ClWire:GetInt() >= 1 then
	Is.SetTCVar( "r_drawothermodels", "2")
	else
	Is.SetTCVar( "r_drawothermodels", "1")
	end
	
		if CLM:GetInt() >= 1 and Backup != nil and Aimon == 1 then
			if ShouldShoot then
			RunConsoleCommand("-Attack")
			ShouldShoot = false
			elseif !ShouldShoot then
			RunConsoleCommand("+Attack")
			ShouldShoot = true
			end
			elseif Aimon == 0 or Backup == nil then
			if ShouldShoot then
			RunConsoleCommand("-Attack")
			ShouldShoot = false

			end
		end
	
end	

// UNORGANIZED STUFF

concommand.Add( "Trixie_Enable_ForcedCheats", function()
Is.SetTCVar( "sv_cheats", "1" )
end )

concommand.Add( "Trixie_Disable_ForcedCheats", function()
Is.SetTCVar( "sv_cheats", "0" )
end )

// noPE's hitmarker

function MLGHitmarker()
if ClHit:GetBool() then
local EyeEnt = LocalPlayer():GetEyeTrace().Entity
if EyeEnt:IsPlayer() then
if LocalPlayer():Health() > 0 then
if LocalPlayer():GetCurrentCommand():KeyDown(IN_ATTACK) then
if LocalPlayer():GetActiveWeapon():Clip1() > 0 then

surface.SetDrawColor( 255 , 255 , 255 , 180 )
surface.DrawLine(ScrW() / 2 - 5 , ScrH() / 2 - 5 , ScrW() / 2 - 15 , ScrH() / 2 - 15)
surface.DrawLine(ScrW() / 2 + 5 , ScrH() / 2 + 5 , ScrW() / 2 + 15, ScrH() / 2 + 15)
surface.DrawLine(ScrW() / 2 + 5 , ScrH() / 2 - 5 , ScrW() / 2 + 15 , ScrH() / 2 - 15)
surface.DrawLine(ScrW() / 2 - 5 , ScrH() / 2 + 5 , ScrW() / 2 - 15 , ScrH() / 2 + 15)
					end
				end
			end
				end
					end
						end
						
hook.Add("HUDPaint","DisplayShittyHitmarker",MLGHitmarker)

// Quick Propkill Script

concommand.Add("Trixie_Quick_Propkill",function() 
timer.Simple(.01,function()
LocalPlayer():SetEyeAngles(LocalPlayer():EyeAngles() - Angle(0,10,0))
end)
timer.Simple(.02,function()
LocalPlayer():SetEyeAngles(LocalPlayer():EyeAngles() - Angle(0,10,0))
end)
timer.Simple(.03,function()
LocalPlayer():SetEyeAngles(LocalPlayer():EyeAngles() - Angle(0,10,0)) 
end)
timer.Simple(.04,function()
LocalPlayer():SetEyeAngles(LocalPlayer():EyeAngles() - Angle(0,10,0))
end)
timer.Simple(.05,function()
LocalPlayer():SetEyeAngles(LocalPlayer():EyeAngles() - Angle(0,10,0))
end)
timer.Simple(.06,function()
LocalPlayer():SetEyeAngles(LocalPlayer():EyeAngles() - Angle(0,10,0))
end)
timer.Simple(.07,function()
LocalPlayer():SetEyeAngles(LocalPlayer():EyeAngles() - Angle(0,10,0))
end)
timer.Simple(.08,function()
LocalPlayer():SetEyeAngles(LocalPlayer():EyeAngles() - Angle(0,10,0))
end)
timer.Simple(.09,function()
LocalPlayer():SetEyeAngles(LocalPlayer():EyeAngles() - Angle(0,10,0))
end)
timer.Simple(.10,function()
LocalPlayer():SetEyeAngles(LocalPlayer():EyeAngles() - Angle(0,10,0))
end)
timer.Simple(.11,function()
LocalPlayer():SetEyeAngles(LocalPlayer():EyeAngles() - Angle(0,10,0))
end)
timer.Simple(.12,function()
LocalPlayer():SetEyeAngles(LocalPlayer():EyeAngles() - Angle(0,10,0))
end)
timer.Simple(.13,function()
LocalPlayer():SetEyeAngles(LocalPlayer():EyeAngles() - Angle(0,10,0))
end)
timer.Simple(.14,function()
LocalPlayer():SetEyeAngles(LocalPlayer():EyeAngles() - Angle(0,10,0))
end)
timer.Simple(.15,function()
LocalPlayer():SetEyeAngles(LocalPlayer():EyeAngles() - Angle(0,10,0))
end)
timer.Simple(.16,function()
LocalPlayer():SetEyeAngles(LocalPlayer():EyeAngles() - Angle(0,10,0))
end)
timer.Simple(.17,function()
LocalPlayer():SetEyeAngles(LocalPlayer():EyeAngles() - Angle(0,10,0))
end)
timer.Simple(.19,function()
LocalPlayer():SetEyeAngles(LocalPlayer():EyeAngles() - Angle(0,10,0))
end)
timer.Simple(.25,function()
LocalPlayer():SetEyeAngles(LocalPlayer():EyeAngles() - Angle(0,180,0))
end)
end)

// Triggerbot

function Trigger()
local Eye = LocalPlayer():GetEyeTrace().Entity
if ClTrigger:GetBool() then
if (Eye:IsNPC() or Eye:IsPlayer()) then
RunConsoleCommand("+Attack")
else
timer.Simple(0.50, function()
RunConsoleCommand("-Attack")
			end)
		end
	end
		end

hook.Add("Think", "Test", Trigger)

// TTT Weapon ESP

WeaponTable = {"weapon_zm_pistol","weapon_ttt_wtester","weapon_zm_revolver","weapon_zm_molotov","weapon_zm_shotgun","weapon_ttt_m16","weapon_ttt_glock","weapon_zm_sledge","weapon_zm_rifle","weapon_zm_mac10","weapon_ttt_knife","weapon_ttt_c4","weapon_ttt_flaregun","weapon_ttt_radio","weapon_ttt_sipistol"}

function TTTWeaponEsp()  // Shows all the weapons listed, add more if you're enough of a dick to look into this LUA
if ClWep:GetBool() then
for k,v in pairs(ents.GetAll()) do
if ValidEntity(v) then
if table.HasValue(WeaponTable,v:GetClass()) and v:GetMoveType() != 0 then
Weaponscreenpot = v:GetPos():ToScreen()

draw.SimpleText(v:GetClass(),"TrixieEspFonta", Weaponscreenpot.x , Weaponscreenpot.y , Color(255,0,0,255) , TEXT_ALIGN_CENTER,TEXT_ALIGN_CENTER)
						end
					end
				end
					end
						end

hook.Add("HUDPaint","TTTWeaponShow",TTTWeaponEsp)

// Body ESP

Ragdolls = {"hl2mp_ragdoll","prop_ragdoll"}

function TTTRagdollEsp()
if ClBody:GetBool() then
for k,v in pairs(ents.GetAll()) do
if ValidEntity(v) then
if table.HasValue(Ragdolls,v:GetClass()) and v:GetMoveType() != 0 then
bodies = v:GetPos():ToScreen()

draw.SimpleText(v:GetClass(),"TrixieEspFonta", bodies.x , bodies.y , Color(255,0,0,255) , TEXT_ALIGN_CENTER,TEXT_ALIGN_CENTER)
						end
					end
				end
					end
						end

hook.Add("HUDPaint","TTTBodies",TTTRagdollEsp)

// Barrel View

function Barrelhax()
if ClBarrel:GetBool() then
for k,v in pairs(player.GetAll()) do
if (v!=LocalPlayer() and v:Alive() and v:IsPlayer()) then
cam.Start3D( EyePos() , EyeAngles())
render.SetMaterial( Material( "cable/physbeam" ) )
render.DrawBeam(v:GetBonePosition(v:LookupBone("ValveBiped.Bip01_Head1")) , v:GetEyeTrace().HitPos , 5, 0, 0, Color(255,255,255, 255 ))
cam.End3D()
			end
		end
	end
		end
 
hook.Add("HUDPaint","Specline", Barrelhax)

// Dynamic Lights

function Dynamiclight()
local dlight = DynamicLight()
if ClLight:GetBool() then
if (dlight) then
local LocalTeam = team.GetColor(LocalPlayer():Team())
dlight.Pos = LocalPlayer():GetPos()
dlight.r = LocalTeam.r
dlight.g = LocalTeam.g 
dlight.b = LocalTeam.b
dlight.Brightness = 4 
dlight.Size = 500
dlight.Decay = 0 
dlight.DieTime = CurTime() + 0.1
			end
		end
	end
	
hook.Add("Think", "FollowLight" , Dynamiclight)

// Speedhack //

timer.Create("AddSpeed",2,1,function()
concommand.Add("+Trixie_Speed" , function() Is.SetTCVar("sv_Cheats","1") Is.SetTCVar("Host_TimeScale",tostring(GetConVarNumber("Trixie_Speedhack_Speed"))) end)
concommand.Add("-Trixie_Speed", function() Is.SetTCVar("Host_TimeScale","1") Is.SetTCVar("sv_Cheats","0") end)
end)

// Hooks // 

timer.Create("LoadHooks",2.9,1,function()
TrixieCreateHook("CreateMove",TrixieAimbot)
TrixieCreateHook("CalcView",CalcV)
TrixieCreateHook("Think",TrixieThink)
TrixieCreateHook("HUDPaint",TrixieEsp)
TrixieCreateHook("RenderScreenspaceEffects",TrixieChams)
TrixieCreateHook("TTTPrepareRound",TableClear)
TrixieCreateHook("PlayerConnect",PlayerConnect)
end)

/// Derma GUI ///

local function ShowFrame()

Frame = vgui.Create("DFrame")
Frame:SetSize( 450 , 360 )
Frame:SetPos( ScrW() / 2 - Frame:GetWide() / 15 , ScrH() / 3 - Frame:GetTall() / 30  )
Frame:SetTitle("The Great And Powerful Hack V5 - Defeating Ursa Majors since 2012!")
Frame:SetVisible( true )
Frame:ShowCloseButton( true )
Frame.Paint = function()
	draw.RoundedBox( 10, 0, 0, Frame:GetWide(), Frame:GetTall(), Color( 135, 206, 250, 170 ) )
end
Frame:MakePopup()

local BSheet = vgui.Create("DPropertySheet" , Frame)
BSheet:SetSize( 440 , 330 )
BSheet:SetPos( 5 , 25 )
BSheet.Paint = function()
	draw.RoundedBox( 10, 0, 0, BSheet:GetWide(), BSheet:GetTall(), Color( 0, 50, 128, 150 ) )
end

local BSheet2 = vgui.Create("DPropertySheet" , Frame)
BSheet2:SetSize( 447 , 1 )
BSheet2:SetPos( 4 , 47 )
BSheet2.Paint = function()
	draw.RoundedBox( 10, 0, 0, BSheet2:GetWide(), BSheet2:GetTall(), Color( 0, 20, 128, 150 ) )
end

local Tab = vgui.Create("DLabel")
Tab:SetParent( BSheet )
Tab:SetPos( 0 , 10 )
Tab:SetText("")

local Tab2 = vgui.Create("DLabel")
Tab2:SetParent( BSheet )
Tab2:SetPos( 0 , 10 )
Tab2:SetText("")

local Tab3 = vgui.Create("DLabel")
Tab3:SetParent( BSheet )
Tab3:SetPos( 0 , 10 )
Tab3:SetText("")

local Tab4 = vgui.Create("DLabel")
Tab4:SetParent( BSheet )
Tab4:SetPos( 0 , 10 )
Tab4:SetText("")

local Tab5 = vgui.Create("DLabel")
Tab5:SetParent( BSheet )
Tab5:SetPos( 0 , 10 )
Tab5:SetText("")

// Options

local AimLabel = vgui.Create("DLabel")
AimLabel:SetParent( Tab )
AimLabel:SetPos( 13 , 10 )
AimLabel:SetText("Main Options")
AimLabel:SetTextColor( Color(255 , 255 , 255 , 255 ) )
AimLabel:SizeToContents()

local AimLabel2 = vgui.Create("DLabel")
AimLabel2:SetParent( Tab )
AimLabel2:SetPos( 13 , 70 )
AimLabel2:SetText("Secondary Options")
AimLabel2:SetTextColor( Color(255 , 255 , 255 , 255 ) )
AimLabel2:SizeToContents()

local AimLabel3 = vgui.Create("DLabel")
AimLabel3:SetParent( Tab )
AimLabel3:SetPos( 206 , 10 )
AimLabel3:SetText("Other Assists")
AimLabel3:SetTextColor( Color(255 , 255 , 255 , 255 ) )
AimLabel3:SizeToContents()

local AimLabel4 = vgui.Create("DLabel")
AimLabel4:SetParent( Tab )
AimLabel4:SetPos( 13 , 130  )
AimLabel4:SetText("Removals")
AimLabel4:SetTextColor( Color(255 , 255 , 255 , 255 ) )
AimLabel4:SizeToContents()

local AimLabel5 = vgui.Create("DLabel")
AimLabel5:SetParent( Tab )
AimLabel5:SetPos( 118.5 , 235 )
AimLabel5:SetText("Attatchment Selection")
AimLabel5:SetTextColor( Color(255 , 255 , 255 , 255 ) )
AimLabel5:SizeToContents()

local Aim = vgui.Create( "DCheckBoxLabel")
Aim:SetText( "Friendly Fire" )
Aim:SetConVar( "Trixie_Aimbot_Friendlyfire" ) 
Aim:SetParent( Tab )
Aim:SetPos( 10 , 30 )
Aim:SetValue( GetConVarNumber("Trixie_Aimbot_Friendlyfire") )
Aim:SetTextColor( Color(255 , 0 , 0 , 255 ) )
Aim:SizeToContents() 

local Aim2 = vgui.Create( "DCheckBoxLabel")
Aim2:SetText( "Ignore Steam Friends" )
Aim2:SetConVar( "Trixie_Aimbot_IgnoreSteam" ) 
Aim2:SetParent( Tab )
Aim2:SetPos( 10 , 50 )
Aim2:SetValue( GetConVarNumber("Trixie_Aimbot_IgnoreSteam") )
Aim2:SetTextColor( Color(255 , 0 , 0 , 255 ) )
Aim2:SizeToContents() 

local Aim3 = vgui.Create( "DCheckBoxLabel")
Aim3:SetText( "Autoshoot" )
Aim3:SetConVar( "Trixie_Aimbot_AutoShoot" ) 
Aim3:SetParent( Tab )
Aim3:SetPos( 10 , 90 )
Aim3:SetValue( GetConVarNumber("Trixie_Aimbot_AutoShoot") )
Aim3:SetTextColor( Color(255 , 0 , 0 , 255 ) )
Aim3:SizeToContents() 

local Aim4 = vgui.Create( "DCheckBoxLabel")
Aim4:SetText( "Spread" )
Aim4:SetConVar( "Trixie_Aimbot_Nospread" ) 
Aim4:SetParent( Tab )
Aim4:SetPos( 10 , 150 )
Aim4:SetValue( GetConVarNumber("Trixie_Aimbot_NoSpread") )
Aim4:SetTextColor( Color(255 , 0 , 0 , 255 ) )
Aim4:SizeToContents() 

local Aim5 = vgui.Create( "DCheckBoxLabel")
Aim5:SetText( "Recoil" )
Aim5:SetConVar( "Trixie_Aimbot_NoRecoil" ) 
Aim5:SetParent( Tab )
Aim5:SetPos( 10 , 170 )
Aim5:SetValue( GetConVarNumber("Trixie_Aimbot_NoRecoil") )
Aim5:SetTextColor( Color(255 , 0 , 0 , 255 ) )
Aim5:SizeToContents() 

local Aim6 = vgui.Create( "DCheckBoxLabel")
Aim6:SetText( "Triggerbot" )
Aim6:SetConVar( "Trixie_Misc_Trigger" ) 
Aim6:SetValue( GetConVarNumber("Trixie_Misc_Trigger") )
Aim6:SetParent( Tab )
Aim6:SetPos( 205 , 30 )
Aim6:SetTextColor( Color(255 , 0 , 0 , 255 ) )
Aim6:SizeToContents() 

local Aim7 = vgui.Create( "DCheckBoxLabel")
Aim7:SetText( "Fix NoSpread Shaking" )
Aim7:SetConVar( "Trixie_Aimbot_FixView" ) 
Aim7:SetParent( Tab )
Aim7:SetPos( 205 , 50 )
Aim7:SetValue( GetConVarNumber("Trixie_Aimbot_FixView") )
Aim7:SetTextColor( Color(255 , 0 , 0 , 255 ) )
Aim7:SizeToContents() 

local AList = vgui.Create( "DMultiChoice", Tab)
AList:SetPos( 120 , 250)
AList:SetSize( 100, 20 )
AList:SetConVar("Trixie_Aimbot_AimSpot")
AList:AddChoice("Eye")
AList:AddChoice("Head")
AList:AddChoice("Chest")
AList:AddChoice("Center")

local EspLabel = vgui.Create("DLabel")
EspLabel:SetParent( Tab2 )
EspLabel:SetPos( 13 , 10 )
EspLabel:SetText("Main Esp Options")
EspLabel:SetTextColor( Color(255 , 255 , 255 , 255 ) )
EspLabel:SizeToContents()

local EspLabel2 = vgui.Create("DLabel")
EspLabel2:SetParent( Tab2 )
EspLabel2:SetPos( 13 , 90 )
EspLabel2:SetText("Secondary Esp Options")
EspLabel2:SetTextColor( Color(255 , 255 , 255 , 255 ) )
EspLabel2:SizeToContents()

local EspLabel3 = vgui.Create("DLabel")
EspLabel3:SetParent( Tab2 )
EspLabel3:SetPos( 200 , 10 )
EspLabel3:SetText("TTT Esp")
EspLabel3:SetTextColor( Color(255 , 255 , 255 , 255 ) )
EspLabel3:SizeToContents()

local Esp = vgui.Create( "DCheckBoxLabel")
Esp:SetText( "Esp On / Off" )
Esp:SetConVar( "Trixie_Esp" ) 
Esp:SetParent( Tab2 )
Esp:SetPos( 10 , 30 )
Esp:SetValue( GetConVarNumber("Trixie_Esp") )
Esp:SetTextColor( Color(255 , 0 , 0 , 255 ) )
Esp:SizeToContents() 

local Esp2 = vgui.Create( "DCheckBoxLabel")
Esp2:SetText( "Chams" )
Esp2:SetConVar( "Trixie_Esp_Chams" ) 
Esp2:SetParent( Tab2 )
Esp2:SetPos( 10 , 110 )
Esp2:SetValue( GetConVarNumber("Trixie_Esp_Chams") )
Esp2:SetTextColor( Color(255 , 0 , 0 , 255 ) )
Esp2:SizeToContents() 

local Esp3 = vgui.Create( "DCheckBoxLabel")
Esp3:SetText( "Box ESP" )
Esp3:SetConVar( "Trixie_Esp_Box" ) 
Esp3:SetParent( Tab2 )
Esp3:SetPos( 10 , 130 )
Esp3:SetValue( GetConVarNumber(255 , 255 , 255 , 255 ) )
Esp3:SetTextColor( Color(255 , 0 , 0 , 255 ) )
Esp3:SizeToContents() 

local EspX = vgui.Create( "DCheckBoxLabel")
EspX:SetText( "Warnings" )
EspX:SetConVar( "Trixie_Esp_Warnings" ) 
EspX:SetParent( Tab2 )
EspX:SetPos( 10 , 150 )
EspX:SetValue( GetConVarNumber("Trixie_Esp_Warnings") )
EspX:SetTextColor( Color(255 , 0 , 0 , 255 ) )
EspX:SizeToContents() 

local EspY = vgui.Create( "DCheckBoxLabel")
EspY:SetText( "Dynamic Light" )
EspY:SetConVar( "Trixie_Esp_Light" ) 
EspY:SetPos( 10 , 170 )
EspY:SetParent( Tab2 )
EspY:SetValue( GetConVarNumber("Trixie_Esp_Light") )
EspY:SetTextColor( Color(255 , 0 , 0 , 255 ) )
EspY:SizeToContents() 

local EspXXX = vgui.Create( "DCheckBoxLabel")
EspXXX:SetText( "Barrel View" )
EspXXX:SetConVar( "Trixie_Esp_Barrel" ) 
EspXXX:SetPos( 10 , 190 )
EspXXX:SetParent( Tab2 )
EspXXX:SetValue( GetConVarNumber("Trixie_Esp_Barrel") )
EspXXX:SetTextColor( Color(255 , 0 , 0 , 255 ) )
EspXXX:SizeToContents() 

local EspXYZ = vgui.Create( "DCheckBoxLabel")
EspXYZ:SetText( "Wireframe" )
EspXYZ:SetConVar( "Trixie_Esp_Wireframe" ) 
EspXYZ:SetPos( 10 , 210 )
EspXYZ:SetParent( Tab2 )
EspXYZ:SetValue( GetConVarNumber("Trixie_Esp_Wireframe") )
EspXYZ:SetTextColor( Color(255 , 0 , 0 , 255 ) )
EspXYZ:SizeToContents() 

local Esp4 = vgui.Create( "DCheckBoxLabel")
Esp4:SetText( "Health Bar" )
Esp4:SetConVar( "Trixie_Esp_Health" ) 
Esp4:SetParent( Tab2 )
Esp4:SetPos( 10 , 50 )
Esp4:SetValue( GetConVarNumber("Trixie_Esp_Health") )
Esp4:SetTextColor( Color(255 , 0 , 0 , 255 ) )
Esp4:SizeToContents() 

local Esp5 = vgui.Create( "DCheckBoxLabel")
Esp5:SetText( "Show Administrators" )
Esp5:SetConVar( "Trixie_Esp_Admins" ) 
Esp5:SetParent( Tab2 )
Esp5:SetPos( 10 , 70 )
Esp5:SetValue( GetConVarNumber("Trixie_Esp_Admins") )
Esp5:SetTextColor( Color(255 , 0 , 0 , 255 ) )
Esp5:SizeToContents() 

local Esp6 = vgui.Create( "DCheckBoxLabel")
Esp6:SetText( "Traitor ESP" )
Esp6:SetConVar( "Trixie_Esp_Traitor" ) 
Esp6:SetParent( Tab2 )
Esp6:SetPos( 205 , 30 )
Esp6:SetValue( GetConVarNumber("Trixie_Esp_Traitor") )
Esp6:SetTextColor( Color(255 , 0 , 0 , 255 ) )
Esp6:SizeToContents() 

local Esp7 = vgui.Create( "DCheckBoxLabel")
Esp7:SetText( "C4 ESP" )
Esp7:SetConVar( "Trixie_Esp_ShowC4" ) 
Esp7:SetParent( Tab2 )
Esp7:SetPos( 205 , 50 )
Esp7:SetValue( GetConVarNumber("Trixie_Esp_ShowC4") )
Esp7:SetTextColor( Color(255 , 0 , 0 , 255 ) )
Esp7:SizeToContents() 

local Esp8 = vgui.Create( "DCheckBoxLabel")
Esp8:SetText( "Weapon ESP" )
Esp8:SetConVar( "Trixie_Esp_TTTWep" ) 
Esp8:SetPos( 205 , 70 )
Esp8:SetParent( Tab2 )
Esp8:SetValue( GetConVarNumber("Trixie_Esp_TTTWep") )
Esp8:SetTextColor( Color(255 , 0 , 0 , 255 ) )
Esp8:SizeToContents() 

local Esp9 = vgui.Create( "DCheckBoxLabel")
Esp9:SetText( "Body ESP" )
Esp9:SetConVar( "Trixie_Esp_TTTWep" ) 
Esp9:SetPos( 205 , 90 )
Esp9:SetParent( Tab2 )
Esp9:SetValue( GetConVarNumber("Trixie_Esp_Bodies") )
Esp9:SetTextColor( Color(255 , 0 , 0 , 255 ) )
Esp9:SizeToContents() 

local MiscLabel = vgui.Create("DLabel")
MiscLabel:SetParent( Tab3 )
MiscLabel:SetPos( 13 , 10 )
MiscLabel:SetText("Misc Features")
MiscLabel:SetTextColor( Color(255 , 255 , 255 , 255 ) )
MiscLabel:SizeToContents()

local MiscLabel2 = vgui.Create("DLabel")
MiscLabel2:SetParent( Tab3 )
MiscLabel2:SetPos( 205 , 10 )
MiscLabel2:SetText("Extras / Removals")
MiscLabel2:SetTextColor( Color(255 , 255 , 255 , 255 ) )
MiscLabel2:SizeToContents()

local Misc = vgui.Create( "DCheckBoxLabel")
Misc:SetText( "Bunnyhop" )
Misc:SetConVar( "Trixie_Misc_Bunnyhop" ) 
Misc:SetParent( Tab3 )
Misc:SetPos( 10 , 30 )
Misc:SetValue( GetConVarNumber("Trixie_Misc_Bunnyhop") )
Misc:SetTextColor( Color(255 , 0 , 0 , 255 ) )
Misc:SizeToContents() 

local Misc2 = vgui.Create( "DCheckBoxLabel")
Misc2:SetText( "ULX Antigag" )
Misc2:SetConVar( "Trixie_Misc_AntiGag" ) 
Misc2:SetParent( Tab3 )
Misc2:SetPos( 10 , 50 )
Misc2:SetValue( GetConVarNumber("Trixie_Misc_AntiGag") )
Misc2:SetTextColor( Color(255 , 0 , 0 , 255 ) )
Misc2:SizeToContents() 

local MiscF = vgui.Create( "DCheckBoxLabel")
MiscF:SetText( "Fullbright" )
MiscF:SetConVar( "Trixie_Misc_Fullbright" ) 
MiscF:SetParent( Tab3 )
MiscF:SetPos( 10 , 70 )
MiscF:SetValue( GetConVarNumber("Trixie_Misc_Fullbright") )
MiscF:SetTextColor( Color(255 , 0 , 0 , 255 ) )
MiscF:SizeToContents() 

local MiscN = vgui.Create( "DCheckBoxLabel")
MiscN:SetText( "Nostalgia Mode" )
MiscN:SetConVar( "Trixie_Misc_Nostalgia" ) 
MiscN:SetParent( Tab3 )
MiscN:SetPos( 10 , 90 )
MiscN:SetValue( GetConVarNumber("Trixie_Misc_Nostalgia") )
MiscN:SetTextColor( Color(255 , 0 , 0 , 255 ) )
MiscN:SizeToContents() 

local MiscMI = vgui.Create( "DCheckBoxLabel")
MiscMI:SetText( "Enable Micspam" )
MiscMI:SetConVar( "Trixie_Misc_Micspam" ) 
MiscMI:SetParent( Tab3 )
MiscMI:SetPos( 10 , 110 )
MiscMI:SetValue( GetConVarNumber("Trixie_Misc_Micspam") )
MiscMI:SetTextColor( Color(255 , 0 , 0 , 255 ) )
MiscMI:SizeToContents() 

local Misc3 = vgui.Create( "DCheckBoxLabel")
Misc3:SetText( "Crosshair" )
Misc3:SetConVar( "Trixie_Misc_Crosshair" ) 
Misc3:SetParent( Tab3 )
Misc3:SetPos( 200 , 30 )
Misc3:SetValue( GetConVarNumber("Trixie_Misc_Crosshair") )
Misc3:SetTextColor( Color(255 , 0 , 0 , 255 ) )
Misc3:SizeToContents() 

local Misc4 = vgui.Create( "DCheckBoxLabel")
Misc4:SetText( "No Sky" )
Misc4:SetConVar( "Trixie_Misc_RemoveSky" ) 
Misc4:SetParent( Tab3 )
Misc4:SetPos( 200 , 50 )
Misc4:SetValue( GetConVarNumber("Trixie_Misc_RemoveSky") )
Misc4:SetTextColor( Color(255 , 0 , 0 , 255 ) )
Misc4:SizeToContents() 

local Misc5 = vgui.Create( "DCheckBoxLabel")
Misc5:SetText( "Status" )
Misc5:SetConVar( "Trixie_Misc_ShowStatus" ) 
Misc5:SetParent( Tab3 )
Misc5:SetPos( 200 , 70 )
Misc5:SetValue( GetConVarNumber("Trixie_Misc_ShowStatus") )
Misc5:SetTextColor( Color(255 , 0 , 0 , 255 ) )
Misc5:SizeToContents() 

local Misc5 = vgui.Create( "DCheckBoxLabel")
Misc5:SetText( "COD Hitmarker" )
Misc5:SetConVar( "Trixie_Misc_Hitmarker" ) 
Misc5:SetParent( Tab3 )
Misc5:SetPos( 200 , 90 )
Misc5:SetValue( GetConVarNumber("Trixie_Misc_Hitmarker") )
Misc5:SetTextColor( Color(255 , 0 , 0 , 255 ) )
Misc5:SizeToContents() 

local Misc6 = vgui.Create( "DCheckBoxLabel")
Misc6:SetText( "Force Cheats" )
Misc6:SetConVar( "Trixie_Misc_Cheats" ) 
Misc6:SetParent( Tab3 )
Misc6:SetPos( 200 , 110 )
Misc6:SetValue( GetConVarNumber("Trixie_Misc_Cheats") )
Misc6:SetTextColor( Color(255 , 0 , 0 , 255 ) )
Misc6:SizeToContents() 

local About1 = vgui.Create("DLabel")
About1:SetParent( Tab5 )
About1:SetPos( 13 , 10 )
About1:SetText( "<< The Great and Powerful Hack V5 " )
About1:SetTextColor( Color(255 , 255 , 255 , 255 ) )
About1:SizeToContents() 

local AboutR = vgui.Create("DLabel")
AboutR:SetParent( Tab5 )
AboutR:SetPos( 13 , 20 )
AboutR:SetText( "<< Coded by wav " )
AboutR:SetTextColor( Color(255 , 255 , 255 , 255 ) )
AboutR:SizeToContents() 

local About2 = vgui.Create("DLabel")
About2:SetParent( Tab5 )
About2:SetPos( 13 , 60 )
About2:SetText( "<< Thanks to: >>" )
About2:SetTextColor( Color(255 , 255 , 255 , 255 ) )
About2:SizeToContents() 

local About3 = vgui.Create("DLabel")
About3:SetParent( Tab5 )
About3:SetPos( 13 , 80 )
About3:SetText( "<< fr1kin - coded the aimbot" )
About3:SetTextColor( Color(255 , 0 , 0 , 255 ) )
About3:SizeToContents() 

local About3 = vgui.Create("DLabel")
About3:SetParent( Tab5 )
About3:SetPos( 13 , 90 )
About3:SetText( "<< d3vin - helped with cvar forcing" )
About3:SetTextColor( Color(255 , 0 , 0 , 255 ) )
About3:SizeToContents() 

local About3 = vgui.Create("DLabel")
About3:SetParent( Tab5 )
About3:SetPos( 13 , 100 )
About3:SetText( "<< noPE - COD hitmarker" )
About3:SetTextColor( Color(255 , 0 , 0 , 255 ) )
About3:SizeToContents() 

local About3 = vgui.Create("DLabel")
About3:SetParent( Tab5 )
About3:SetPos( 13 , 110 )
About3:SetText( "<< avoine - helped with velocity prediction" )
About3:SetTextColor( Color(255 , 0 , 0 , 255 ) )
About3:SizeToContents() 

local About4 = vgui.Create("DLabel")
About4:SetParent( Tab5 )
About4:SetPos( 260 , 60 )
About4:SetText( "<< Special thanks to: >>" )
About4:SetTextColor( Color(255 , 255 , 255 , 255 ) )
About4:SizeToContents() 

local About5 = vgui.Create("DLabel")
About5:SetParent( Tab5 )
About5:SetPos( 260 , 80 )
About5:SetText( "<< shift - beta testing, ideas" )
About5:SetTextColor( Color(255 , 0 , 0 , 255 ) )
About5:SizeToContents() 

local AboutF = vgui.Create("DLabel")
AboutF:SetParent( Tab5 )
AboutF:SetPos( 260 , 90 )
AboutF:SetText( "<< foob - beta testing, feedback" )
AboutF:SetTextColor( Color(255 , 0 , 0 , 255 ) )
AboutF:SizeToContents() 

local Sh = vgui.Create( "DNumSlider")
Sh:SetWide(100)
Sh:SetText( "" )
Sh:SetMin(0)
Sh:SetMax(10) 
Sh:SetDecimals(1)
Sh:SetPos( 20 , 30 )
Sh:SetParent( Tab4 ) 
Sh:SetConVar("Trixie_Speedhack_speed")

local ShLabel = vgui.Create("DLabel")
ShLabel:SetParent( Tab4 )
ShLabel:SetPos( 20 , 15 )
ShLabel:SetText( "Speed Controller" )
ShLabel:SetTextColor(Color (255 , 255 , 255 , 255 ))
ShLabel:SizeToContents()

// Other Unrelated Derma Options

local TrixieB = vgui.Create( "DButton", Tab3 )
TrixieB:SetSize( 70, 30 )
TrixieB:SetPos( 15, 300 )
TrixieB:SetText( "Radio" )
TrixieB.DoClick = function()
	
local HtmlWin = vgui.Create( "DFrame" )
HtmlWin:SetPos( 1,1 )
HtmlWin:SetSize( ScrW() - 25 , ScrH() - 50 )
HtmlWin:SetTitle( "Ursa Major Radio" )
HtmlWin:SetVisible( true )  
HtmlWin:SetDraggable( true )
HtmlWin:ShowCloseButton( false )
HtmlWin:MakePopup()
	
local HTMLWeb = vgui.Create( "HTML", HtmlWin )
HTMLWeb:SetSize(ScrW(), ScrH())
HTMLWeb:SetPos( 0, 50 )
HTMLWeb:OpenURL( "http://www.pandora.com/" ) // Built-in Pandora

local TrixieB2 = vgui.Create( "DButton", HtmlWin )
TrixieB2:SetSize( 70, 30 )
TrixieB2:SetPos( 3, 5 )
TrixieB2:SetText( "Minimize" )
TrixieB2.DoClick = function()
HtmlWin:SetVisible(false)
	end	
local TrixieB3 = vgui.Create( "DButton")
TrixieB3:SetSize( 80,30 )
TrixieB3:SetPos( ScrW() - 85, 35 )
TrixieB3:SetText( "Show Pandora" )
TrixieB3.DoClick = function()
HtmlWin:SetVisible(true)
	end	
	
	
end


// Menu tabs!

BSheet:AddSheet( "Aimbot", Tab, "gui/silkicons/star", false, false, "One click headshots." )
BSheet:AddSheet( "ESP", Tab2, "gui/silkicons/user", false, false, "I saw your shadow, I swear!" )
BSheet:AddSheet( "Other", Tab3, "gui/silkicons/world", false, false, "Other assorted things." )
BSheet:AddSheet( "Speedhack", Tab4, "gui/silkicons/car", false, false, "Gotta go fast!" )
BSheet:AddSheet( "About", Tab5, "gui/silkicons/heart", false, false, "Give credit where credit is due." )
end
concommand.Add("+Trixie_Menu",ShowFrame)
concommand.Add("-Trixie_Menu",function()
Frame:SetVisible( false )
end)

concommand.Add("Trixie_Menu",function()
ShowFrame()
end)