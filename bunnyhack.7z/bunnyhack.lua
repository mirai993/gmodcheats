--[[
	lua/autorun/client/bhop.lua
	";exit | (STEAM_0:0:21513525)
	===DStream===
]]

hook.Add("CreateMove","-____________________- bunny hack",function(cmd)
if bit.band( cmd:GetButtons(), IN_JUMP ) ~= 0 then
if !LocalPlayer():IsOnGround() then
cmd:SetButtons( bit.band( cmd:GetButtons(), bit.bnot( IN_JUMP ) ) )
end
end
end)