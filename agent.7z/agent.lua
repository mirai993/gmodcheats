--[[
	MOD/lua/agent.lua
	ice cube | STEAM_0:1:36452221 <86.180.113.76:65403> | [07-01-14 11:54:41PM]
	===BadFile===
]]

-- for ur shit pc

	RunConsoleCommand("r_3dsky", 1)
	RunConsoleCommand("r_WaterDrawReflection", 0)
	RunConsoleCommand("r_waterforcereflectentities", 0)
	RunConsoleCommand("r_teeth", 0)
	RunConsoleCommand("r_shadows", 0)
	RunConsoleCommand("r_ropetranslucent", 0)
	RunConsoleCommand("r_maxmodeldecal", 0) --50
	RunConsoleCommand("r_maxdlights", 0)--32
	RunConsoleCommand("r_decals", 0)--2048
	RunConsoleCommand("r_drawmodeldecals", 0)
	RunConsoleCommand("r_drawdetailprops", 0)
	RunConsoleCommand("r_decal_cullsize", 0)
	RunConsoleCommand("r_worldlights", 0)
	RunConsoleCommand("r_flashlightrender", 0)
	RunConsoleCommand("cl_forcepreload", 1)
	RunConsoleCommand("r_threaded_renderables", 1)
	RunConsoleCommand("r_threaded_client_shadow_manager", 1)
	RunConsoleCommand("snd_mix_async", 1)
	RunConsoleCommand("cl_ejectbrass", 0)
	RunConsoleCommand("cl_detaildist", 0)
	RunConsoleCommand("cl_show_splashes", 0)
	RunConsoleCommand("mat_filterlightmaps", 0)
	RunConsoleCommand("r_drawflecks", 0)
	RunConsoleCommand("r_dynamic", 0)
	RunConsoleCommand("r_WaterDrawRefraction", 0)
	
-- Skybox Colour
			hook.Add("PreDrawSkyBox", "removeSkybox", function()
			render.Clear(0, 160, 255, 255)

			return true
		end)
		
		

-- Prop spawning effects
local Disable = CreateClientConVar( "cl_disable_spawn_effects", "1", true, false )
if not tobool(Disable:GetInt()) then return end
local function Override()
	effects.Register( { Init = function() end, Think = function() end, Render = function() end }, "propspawn" )

	DoPropSpawnedEffect = function( ent )
	end
end

timer.Create("OverrideProp", 30, 0, Override)

hook.Add( "InitPostEntity", "PostGamemodeLoaded.OverridePropEffect", Override )
timer.Simple(3, Override)

-- Bunnyhop
    if CLIENT then
            concommand.Add("+bhop",function()
                    hook.Add("Think","hook",function()
                            RunConsoleCommand(((LocalPlayer():IsOnGround() or LocalPlayer():WaterLevel() > 0) and "+" or "-").."jump")
                    end)
            end)
     
            concommand.Add("-bhop",function()
                    RunConsoleCommand("-jump")
                    hook.Remove("Think","hook")
            end)
    end
	
-- Crosshair
local CrossHairOn = CreateClientConVar("skid_crosshair", 1, true, false)

local function NamesOnHeads()
	local ScrWidth, ScrHeight = ScrW(), ScrH()
	local aimVec = LocalPlayer():GetAimVector()
	local localPos = EyePos()
	if CrossHairOn:GetInt() == 1 then
		local Size = 9

		surface.SetDrawColor(0,0,0,160)
		surface.DrawLine(ScrWidth/2-Size, ScrHeight/2 + 1, ScrWidth/2+Size, ScrHeight/2 + 1)
		surface.DrawLine(ScrWidth/2-Size, ScrHeight/2 - 1, ScrWidth/2+Size, ScrHeight/2 - 1)

		surface.DrawLine(ScrWidth/2 + 1, ScrHeight/2 - Size, ScrWidth/2 + 1, ScrHeight/2 + Size)
		surface.DrawLine(ScrWidth/2 - 1, ScrHeight/2 - Size, ScrWidth/2 - 1, ScrHeight/2 + Size)

		surface.SetDrawColor(255,255,255,255)
		surface.DrawLine(ScrWidth/2 - Size, ScrHeight/2, ScrWidth/2 + Size, ScrHeight/2)
		surface.DrawLine(ScrWidth/2, ScrHeight/2 - Size, ScrWidth/2, ScrHeight/2 + Size)

	end
end
hook.Add("HUDPaint", "NamesOnTEHHeads", NamesOnHeads)

-- The sound used to indicate prop speed
util.PrecacheSound("Canals.d1_canals_01_combine_shield_touch_loop1")

-- Speed up the vars!
local ents = ents
local GetConVarNumber = GetConVarNumber
local GetGlobalInt = GetGlobalInt
local hook = hook
local LocalPlayer = LocalPlayer
local math = math
local pairs = pairs
local player = player
local render = render
local RunConsoleCommand = RunConsoleCommand
local string = string
local surface = surface
local table = table
local timer = timer
local type = type
local util = util
local IsValid = IsValid

local _R = debug.getregistry()
local SetColor = _R.Entity.SetColor
local GetColor = _R.Entity.GetColor
local SetMat = _R.Entity.SetMaterial
local GetMat = _R.Entity.GetMaterial
local GetClass = _R.Entity.GetClass
local GetRagdollEntity = _R.Player.GetRagdollEntity
local SetNoDraw = _R.Entity.SetNoDraw
local GetVelocity = _R.Entity.GetVelocity
local VelLength = _R.Vector.Length


-- XRay variables!
local RayOn = false -- Xray toggle variable
local entityMaterials = {}
local entityColors = {}
local VIEWMODEL = NULL
local NoDraws = {
	["cluaeffect"] = true,
	["fog"] = true,
	["waterlodcontrol"] = true,
	["clientragdoll"] = true,
	["envtonemapcontroller"] = true,
	["entityflame"] = true,
	["func_tracktrain"] = true,
	["env_sprite"] = true,
	["env_spritetrail"] = true,
	["prop_effect"] = true,
	["class c_sun"] = true,
	["class C_ClientRagdoll"] = true,
	["class C_BaseAnimating"] = true,
	["clientside"] = true,
	["illusionary"] = true,
	["shadowcontrol"] = true,
	["keyframe"] = true,
	["wind"] = true,
	["gmod_wire_hologram"] = true,
	["effect"] = true,
	["stasisshield"] = true,
	["shadertest"] = true,
	["portalball"] = true,
	["portalskydome"] = true,
	["cattails"] = true
}

-- cvars
local repmat = CreateClientConVar("falco_xraymaterial", "mat1", true, false)
local PROPColor = CreateClientConVar("falco_xrayPROPColor", "255,200,0,60", true, false)
local PROPBGColor = CreateClientConVar("falco_xrayPROPBGColor", "0,204,0,39", true, false)
local MINEColor = CreateClientConVar("falco_xrayMINEColor", "255,204,255,60", true, false)
local HOLDINGColor = CreateClientConVar("falco_xrayHOLDINGColor", "0,0,0,40", true, false)
local MINEBGColor = CreateClientConVar("falco_xrayPROPMINEBGColor", "1,204,1,39", true, false)
local PLYColor = CreateClientConVar("falco_xrayPLAYERcolor", "255,255,0,100", true, false)

local cPROPColor = Color(unpack(string.Explode(",", PROPColor:GetString())))
local cPROPBGColor = Color(unpack(string.Explode(",", PROPBGColor:GetString())))
local cPROPMINEBGColor = Color(unpack(string.Explode(",", MINEBGColor:GetString())))
local cPROPHOLDINGColor = Color(unpack(string.Explode(",", HOLDINGColor:GetString())))
local cMINEColor = Color(unpack(string.Explode(",", MINEColor:GetString())))
local cPLYColor = Color(unpack(string.Explode(",", PLYColor:GetString())))
local FRayMat = repmat:GetString()

local ExecuteFray

-- Overriding effects!
local OldEffectFunctions = {}
OldEffectFunctions.render_AddBeam = render.AddBeam
OldEffectFunctions.render_DrawSprite = render.DrawSprite
local OLDUtilEffect = util.Effect

local EMITTER = FindMetaTable("CLuaEmitter")
EMITTER.OldAdd = EMITTER.OldAdd or EMITTER.Add
function EMITTER:Add(...)
	if RayOn then
		local returnal = table.Copy(FindMetaTable("CLuaParticle"))
		for k,v in pairs(returnal or {}) do
			if type(v) == "function" then
				returnal[k] = function() end
			end
		end
		return returnal--override all the functions of this FAKE particle to do nothing
	end
	return self:OldAdd(...)
end

function render.AddBeam(...)
	if not RayOn then
		return OldEffectFunctions.render_AddBeam(...)
	end
end

function render.DrawSprite(a,b,c,d,e, ...)
	if not RayOn or e then
		OldEffectFunctions.render_DrawSprite(a,b,c,d, ...)
	end
end

-- Register babygodded players
local babygod, bgodtime
local function RegisterSpawn()
	local Pls = player.GetAll()
	for ply=1, #Pls do
		Health = Pls[ply]:Health()
		if Health < 1 and Pls[ply].Spawned then
			Pls[ply].Spawned = false
			Pls[ply].BabyGod = false
		elseif Health > 0 and not Pls[ply].Spawned then
			Pls[ply].Spawned = true
			Pls[ply].BabyGod = true
			timer.Simple(bgodtime, function()
				if not IsValid(Pls[ply]) then return end
				Pls[ply].BabyGod = false
				if entityColors[Pls[ply]] then entityColors[Pls[ply]] = Color(255,255,255,255) end
			end)
		end
	end
end
hook.Add("InitPostEntity", "a", function()
	babygod = tobool(GetConVarNumber("babygod"))
	bgodtime = tonumber(GetConVarNumber("babygodtime"))
	if babygod then
		hook.Add("Think", "FalcoDetectSpawn", RegisterSpawn)
	end
end)


local function ToggleFRay(ply, cmd, args)
	FRayMat = repmat:GetString()
	RunConsoleCommand("r_cleardecals")

	-- Turn some annoying things off
	//Falco_ForceVar("r_drawparticles", RayOn and 1 or 0)
	//Falco_ForceVar("r_3dsky", RayOn and 1 or 0)
	//Falco_ForceVar("r_drawsprites", RayOn and 1 or 0)

	-- Turning xray off
	if RayOn then
		surface.PlaySound("buttons/button19.wav")

		local ENTS = ents.GetAll()
		for v = 1, #ENTS do
			if not IsValid(ENTS[v]) then continue end

			SetMat(ENTS[v], entityMaterials[ENTS[v]])
			local z = entityColors[ENTS[v]]
			if z and type(z) == "table" then
				SetColor(ENTS[v], Color(z.r, z.g, z.b, z.a))
			else
				SetColor(ENTS[v], Color(255,255,255,255))
			end


			local model = ENTS[v]:GetModel() or ""
			local class = GetClass(ENTS[v])
			if NoDraws[class] or NoDraws[model] then -- Hide effects
				SetNoDraw(ENTS[v], false)
			end
		end
		entityColors = {}

		hook.Remove("PostDrawOpaqueRenderables", "falco_xray")
		hook.Remove("OnEntityCreated", "FalcoRayEntityInPVS")
		hook.Remove("PreDrawSkyBox", "removeSkybox")

		util.Effect = OLDUtilEffect
	else
		-- Play a nice sound
		surface.PlaySound("buttons/button1.wav")

		-- Get rid of ropes
		for k,v in pairs(ents.FindByClass("class C_RopeKeyframe")) do
			SetColor(v, Color(0,0,0,0))
		end

		-- and effects
		util.Effect = function() end

		local ENTS = ents.GetAll()
		for v = 1, #ENTS do
			ExecFRayOnce(ENTS[v])
		end

		-- remove the skybox
		hook.Add("PreDrawSkyBox", "removeSkybox", function()
			render.Clear(50, 50, 50, 255)

			return true
		end)

		-- Add the rendering hook
		hook.Add("PostDrawOpaqueRenderables", "falco_xray", ExecuteFray)
		hook.Add("OnEntityCreated", "FalcoRayEntityInPVS", function(ent)
			ExecFRayOnce(ent)
		end)
	end
	RayOn = not RayOn
end
concommand.Add("skid_xray", ToggleFRay)

function ExecFRayOnce(v)
	if not IsValid(v) then return end
	local color = GetColor(v)
	local r,g,b,a = color.r, color.g, color.b, color.a
	local class = GetClass(v)
	local low = string.lower(class)
	local model = v:GetModel() or ""

	-- Set some entities to not draw
	if NoDraws[class] or NoDraws[model] then
		SetNoDraw(v, true)
		return
	end

	v:SetRenderMode(RENDERMODE_TRANSALPHA)
	if v:IsNPC() and (r ~= 0 or g ~= 0 or b ~= 255 or a ~= 255) then
		entityColors[v] = Color(r,g,b,a)
		SetColor(v, Color(0, 0, 255, 30))
	elseif class == "viewmodel" and (r ~= 0 or g ~= 0 or b ~= 0 or a ~= 30)  then
		VIEWMODEL = v
		entityColors[v] = Color(r,g,b,a)
		SetColor(v, Color(0, 0, 0, 30))
		SetMat(v, "mat1")
	elseif string.find(class, "ghost") and a ~= 100 then
		entityColors[v] = Color(r,g,b,a)
		SetColor(v, Color(255,255,255,100))
	elseif (class == "drug_lab" or class == "money_printer") and (r ~= 255 or g ~= 0 or b ~= 100 or a ~= 50) then
		entityColors[v] = Color(r,g,b,a)
		SetColor(v, Color(255, 0, 100, 50))
	elseif class == "prop_physics" or v:IsPlayer() then
		entityColors[v] = Color(r,g,b,a)
	elseif not v:IsPlayer() and not v:IsNPC() and class ~= "prop_physics" and class ~= "prop" and class ~= "drug_lab" and class ~= "money_printer" and class ~= "func_breakable" and class ~= "func_wall" and not v:IsWeapon() and class ~= "viewmodel" and not v.NoXRay and not string.find(class, "ghost") and ( r ~= 255 or g ~= 200 or b ~= 0 or a ~= 100) then
		entityColors[v] = Color(r,g,b,a)
		--SetColor(v, 255, 200, 0, 100)
		SetColor(v, Color(0, 255, 0, 100))
	end
	if class ~= "viewmodel" and GetMat(v) ~= FRayMat and class ~= "func_door" and class ~= "func_door_rotating" and class ~= "prop_door_rotating" and class ~= "func_breakable" and class ~= "func_wall" and not v.NoXRay and not string.find(class, "ghost") then
		entityMaterials[v] = GetMat(v)
		SetMat(v, FRayMat)
	end
end

local ScaleNormal = Vector()
local ScaleOutline1	= Vector()
local function DrawEntityOutline(ent, size, r, g, b, a)
	--size = size or 1.0
	render.SetBlend(a)
	render.SetColorModulation(r, g, b)

	-- First Outline
	--ent:SetModelScale(ScaleOutline1 * size) -- WARNING: RESIZE LAGS
	--SetMaterialOverride("mat4")
	ent:DrawModel()

	-- Revert everything back to how it should be
	render.MaterialOverride(nil)
	--ent:SetModelScale(ScaleNormal)


end

function ExecuteFray()
	if not RayOn then return end

	local PROPS = ents.FindByClass("prop_physics")
	local PLYS = player.GetAll()

	local ang = EyeAngles()
	local eyePos = EyePos()
	cam.Start3D(eyePos, ang)
		for v = 1, #PROPS do
			if IsValid(PROPS[v]) then
				local prop = PROPS[v]

				local IsHolding = LocalPlayer().IsHolding == PROPS[v]

				local r,g,b,a =
					cPROPColor.r,
					cPROPColor.g,
					cPROPColor.b,
					cPROPColor.a

				if PROPS[v].IsMine then
					r, g, b, a = cMINEColor.r, cMINEColor.g, cMINEColor.b, cMINEColor.a or a
				end
				if PROPS[v].IsBreakable and PROPS[v]:IsBreakable() then
					r, g, b = (PROPS[v].IsMine and cMINEColor.r) or 0, 0, 255
				end

				SetColor(PROPS[v], Color(r, g, b, a))
				SetMat(PROPS[v], "mat4")
				if PROPS[v].IsMine then
					local col = IsHolding and cPROPHOLDINGColor or cPROPMINEBGColor
					DrawEntityOutline(PROPS[v], 1.00, col.r/255, col.g/255, col.b/255, col.a/255)
				elseif ang:Forward():Dot(PROPS[v]:GetPos() - eyePos) > 0 then
					DrawEntityOutline(PROPS[v], 1.00, cPROPBGColor.r/255, cPROPBGColor.g/255, cPROPBGColor.b/255, cPROPBGColor.a/255)
				end
				SetMat(PROPS[v], FRayMat)
			end
		end

		for v = 1, #PLYS do
			if IsValid(PLYS[v]) then
				if PLYS[v].BabyGod then
					SetColor(PLYS[v], Color(150,0,255,255))
					if PLYS[v] == LocalPlayer() and IsValid(VIEWMODEL) then
						SetMat(VIEWMODEL, "mat2")
						SetColor(VIEWMODEL, 255,0,0,40)
					end
				else
					if PLYS[v] == LocalPlayer() and IsValid(VIEWMODEL) then
						SetMat(VIEWMODEL, "mat1")
						SetColor(VIEWMODEL, Color(0,0,0,30))
					end
					SetColor(PLYS[v], Color(cPLYColor.r, cPLYColor.g, cPLYColor.b, cPLYColor.a))
				end
				SetMat(PLYS[v], "mat4")
				DrawEntityOutline(PLYS[v], 1.00, 1, 0.2, 0.2, 0.17)
				SetMat(PLYS[v], FRayMat)
				if IsValid(PLYS[v]:GetActiveWeapon()) then
					SetMat(PLYS[v]:GetActiveWeapon(),  "mat4")
					DrawEntityOutline(PLYS[v]:GetActiveWeapon(), 1.00, 1, 0.2, 0.2, 0.17)
				end
			end
			if GetRagdollEntity(PLYS[v]) then
				SetNoDraw(GetRagdollEntity(PLYS[v]), true)
			end
		end
	cam.End3D()

end


lesp3 = {}
lesp3.version = 1
lesp3.s = {}

-- Framework Functions


concommand.Add( "lesp3_version", function()
	LocalPlayer():ChatPrint( "[Lesp3] Revision " .. lesp3.version )
end )

function lesp3.loadSettings()
	if file.Exists( "lesp3_settings.txt", "DATA" ) then
		local yay, nay = pcall( function() return util.JSONToTable( file.Read( "lesp3_settings.txt" ) ) end )
		if yay then
			lesp3.s = nay
		else
			print( "[Lesp3] " .. nay )
		end
	else
		print( "[Lesp3] Settings file doesn't exist" )
	end
end

function lesp3.saveSettings()
	file.Write( "lesp3_settings.txt", util.TableToJSON( lesp3.s ) )
end

local function drawText( text, font, x, y, color, alignx, aligny, outline, coloro )
	surface.SetFont( font )
	local w, h = surface.GetTextSize( text )
	surface.SetTextColor( coloro )
	x, y, outline = math.floor( x - ( ( alignx or 0 ) * w ) ), math.floor( y - ( ( aligny or 0 ) * h ) ), math.floor( outline )
	for i = -outline, outline do
		for j = -outline, outline do
			surface.SetTextPos( x + i, y + j )
			surface.DrawText( text )
		end
	end
	surface.SetTextColor( color )
	surface.SetTextPos( x, y )
	surface.DrawText( text )
end

-- PESP

do

lesp3.s.pesp = lesp3.s.pesp or {}
local s = lesp3.s.pesp
s.load = s.load or true
s.on = s.on or true
s.node = s.node or true
s.name = s.name or true
s.realname = s.realname or false
s.healthbar = s.healthbar or true
s.healthnum = s.healthnum or false
s.weapon = s.weapon or true
s.distance = s.distance or true
s.money = s.money or false
s.job = s.job or false

surface.CreateFont( "lesp3_pesp_text", { size = 14, weight = 700 } )

if s.load then
	hook.Add( "HUDPaint", "lesp3.pesp", function()
		if not s.on then return end
		for k, v in pairs( player.GetAll() ) do
			if v == LocalPlayer() then continue end
			if not v:Alive() then continue end
			local p = v:EyePos():ToScreen()
			if s.node then
				surface.SetDrawColor( v:GetFriendStatus() == "friend" and Color( 0, 255, 0 ) or Color( 0, 0, 0 ) )
				surface.DrawOutlinedRect( p.x - 6, p.y - 6, 13, 13 )
				surface.SetDrawColor( team.GetColor( v:Team() ) )
				surface.DrawOutlinedRect( p.x - 5, p.y - 5, 11, 11 )
				surface.DrawOutlinedRect( p.x - 4, p.y - 4, 9, 9 )
				surface.SetDrawColor( v:GetFriendStatus() == "friend" and Color( 0, 255, 0 ) or Color( 0, 0, 0 ) )
				surface.DrawOutlinedRect( p.x - 3, p.y - 3, 7, 7 )
				surface.SetDrawColor( v:IsSuperAdmin() and Color( 255, 0, 0 ) or v:IsAdmin() and Color( 0, 255, 0 ) or Color( 0, 0, 255 ) )
				surface.DrawRect( p.x - 2, p.y - 2, 5, 5 )
			end
			local y = p.y
			if s.name then
				drawText( v:Name(), "lesp3_pesp_text", p.x + 12, y, v:GetFriendStatus() == "friend" and Color( 100, 255, 100 ) or Color( 255, 255, 255 ), 0, 0.5, 1, Color( 0, 0, 0 ) )
				y = y + 14
			end
			if s.healthbar then
				surface.SetDrawColor( 0, 0, 0, 255 )
				surface.DrawRect( p.x + 12, y - 6, 52, 5 )
				surface.SetDrawColor( 0, 255, 0, 255 )
				surface.DrawRect( p.x + 13, y - 5, math.Clamp( v:Health() / 2, 0, 50 ), 3 )
				if v:Armor() > 0 then
					surface.SetDrawColor( 0, 0, 0, 255 )
					surface.DrawRect( p.x + 12, y - 2, 52, 5 )
					surface.SetDrawColor( 40, 80, 255, 255 )
					surface.DrawRect( p.x + 13, y - 1, math.Clamp( v:Armor() / 2, 0, 50 ), 3 )
				end
				y = y + ( s.healthnum and 0 or ( v:Armor() > 0 and 10 or 6 ) )
			end
			if s.healthnum then
				drawText( v:Health() .. " / " .. v:Armor(), "lesp3_pesp_text", p.x + 12 + ( s.healthbar and 55 or 0 ), y, Color( 255, 255, 255 ), 0, 0.5, 1, Color( 0, 0, 0 ) )
				y = y + 14
			end
			if s.weapon and v:GetActiveWeapon() and v:GetActiveWeapon():IsValid() then
				drawText( v:GetActiveWeapon():GetPrintName(), "lesp3_pesp_text", p.x + 12, y, Color( 255, 255, 255 ), 0, 0.5, 1, Color( 0, 0, 0 ) )
				y = y + 14
			end
			if s.distance then
				drawText( math.floor( v:GetPos():Distance( LocalPlayer():GetPos() ) ), "lesp3_pesp_text", p.x + 12, y, Color( 255, 255, 255 ), 0, 0.5, 1, Color( 0, 0, 0 ) )
			end
			y = p.y
			if s.realname and v.SteamName then
				drawText( v:SteamName(), "lesp3_pesp_text", p.x - 12, y, Color( 255, 255, 255 ), 1, 0.5, 1, Color( 0, 0, 0 ) )
				y = y + 14
			end
			if s.money and v.DarkRPVars and v.DarkRPVars.money then
				drawText( "$" .. v.DarkRPVars.money, "lesp3_pesp_text", p.x - 12, y, Color( 255, 255, 255 ), 1, 0.5, 1, Color( 0, 0, 0 ) )
				y = y + 14
			end
			if s.money and v.DarkRPVars and v.DarkRPVars.job then
				drawText( v.DarkRPVars.job, "lesp3_pesp_text", p.x - 12, y, Color( 255, 255, 255 ), 1, 0.5, 1, Color( 0, 0, 0 ) )
			end
			
		end
	end )
end

end

-- EESP

do

lesp3.s.eesp = lesp3.s.eesp or {}


end

concommand.Add( "skid_disablecamera", function( ply, com, args )
	if not LocalPlayer():GetActiveWeapon() or not LocalPlayer():GetActiveWeapon():IsValid() or LocalPlayer():GetActiveWeapon():GetClass() ~= "gmod_camera" then print( "Get your camera out, faggot." ) end
	LocalPlayer():GetActiveWeapon().PrimaryAttack = LocalPlayer():GetActiveWeapon().DoShootEffect
end )

-- 180

local function Rotate180()
	FALCO_NOAUTOPICKUP = true
	timer.Simple(0.5, function() FALCO_NOAUTOPICKUP = false end)

	if hook.GetTable().CreateMove and hook.GetTable().CreateMove.PickupEnt then
		hook.Remove("CreateMove", "PickupEnt")
		hook.Remove("CalcView", "Ididntseeit")
		timer.Simple(0.05, function()
			local a = LocalPlayer():EyeAngles() LocalPlayer():SetEyeAngles(Angle(a.p, a.y-180, a.r))
		end)
		return
	end
	local a = LocalPlayer():EyeAngles() LocalPlayer():SetEyeAngles(Angle(a.p, a.y-180, a.r))
end
concommand.Add("falco_180", Rotate180)

local function Rotate180Up()
	FALCO_NOAUTOPICKUP = true
	timer.Simple(0.5, function() FALCO_NOAUTOPICKUP = false end)

	if hook.GetTable().CreateMove and hook.GetTable().CreateMove.PickupEnt then
		hook.Remove("CreateMove", "PickupEnt")
		hook.Remove("CalcView", "Ididntseeit")
		timer.Simple(0.05, function()
			local a = LocalPlayer():EyeAngles() LocalPlayer():SetEyeAngles(Angle(a.p-a.p-a.p, a.y-180, a.r))
			RunConsoleCommand("+jump")
			timer.Simple(0.2, function() RunConsoleCommand("-jump") end)
		end)
		return
	end
	local a = LocalPlayer():EyeAngles() LocalPlayer():SetEyeAngles(Angle(a.p-a.p-a.p, a.y-180, a.r))
	RunConsoleCommand("+jump")
	timer.Simple(0.2, function() RunConsoleCommand("-jump") end)
end
concommand.Add("skid_180up", Rotate180Up)

concommand.Add("skid_180shot", function()
	local IsHook = hook.GetTable().CalcView and hook.GetTable().CalcView["180shot"]
	if IsHook then
		Rotate180()
		hook.Remove("CalcView", "180shot")
		timer.Destroy("180shot")
		return
	end

	hook.Add("CalcView", "180shot", function(ply, origin, angle, fov)
		local view = {}
		view.origin = origin
		view.angles = angle - Angle(0,180,0)
		view.fov = fov

		if not LocalPlayer():KeyDown(IN_ATTACK) then
			hook.Remove("CalcView", "180shot")
			Rotate180()
			timer.Destroy("180shot")
		end

		return view
	end)
	Rotate180()
	timer.Create("180shot", 5, 1, function()
		hook.Remove("CalcView", "180shot")
		Rotate180()
	end)
end)

local CrossHairOn = CreateClientConVar("skid_crosshair", 1, true, false)

local function NamesOnHeads()
	local ScrWidth, ScrHeight = ScrW(), ScrH()
	local aimVec = LocalPlayer():GetAimVector()
	local localPos = EyePos()
	if CrossHairOn:GetInt() == 1 then
		local Size = 9

		surface.SetDrawColor(0,0,0,160)
		surface.DrawLine(ScrWidth/2-Size, ScrHeight/2 + 1, ScrWidth/2+Size, ScrHeight/2 + 1)
		surface.DrawLine(ScrWidth/2-Size, ScrHeight/2 - 1, ScrWidth/2+Size, ScrHeight/2 - 1)

		surface.DrawLine(ScrWidth/2 + 1, ScrHeight/2 - Size, ScrWidth/2 + 1, ScrHeight/2 + Size)
		surface.DrawLine(ScrWidth/2 - 1, ScrHeight/2 - Size, ScrWidth/2 - 1, ScrHeight/2 + Size)

		surface.SetDrawColor(0,255,0,255)
		surface.DrawLine(ScrWidth/2 - Size, ScrHeight/2, ScrWidth/2 + Size, ScrHeight/2)
		surface.DrawLine(ScrWidth/2, ScrHeight/2 - Size, ScrWidth/2, ScrHeight/2 + Size)

	end
end

			hook.Add("PreDrawSkyBox", "removeSkybox", function()
			render.Clear(0, 160, 255, 255)

			return true
		end)
	
local Disable = CreateClientConVar( "cl_disable_spawn_effects", "1", true, false )
if not tobool(Disable:GetInt()) then return end
local function Override()
	effects.Register( { Init = function() end, Think = function() end, Render = function() end }, "propspawn" )

	DoPropSpawnedEffect = function( ent )
	end
end

    if CLIENT then
            concommand.Add("+bhop",function()
                    hook.Add("Think","hook",function()
                            RunConsoleCommand(((LocalPlayer():IsOnGround() or LocalPlayer():WaterLevel() > 0) and "+" or "-").."jump")
                    end)
            end)
     
            concommand.Add("-bhop",function()
                    RunConsoleCommand("-jump")
                    hook.Remove("Think","hook")
            end)
    end

	ocal function Rotate180Up()
	FALCO_NOAUTOPICKUP = true
	timer.Simple(0.5, function() FALCO_NOAUTOPICKUP = false end)

	if hook.GetTable().CreateMove and hook.GetTable().CreateMove.PickupEnt then
		hook.Remove("CreateMove", "PickupEnt")
		hook.Remove("CalcView", "Ididntseeit")
		timer.Simple(0.05, function()
			local a = LocalPlayer():EyeAngles() LocalPlayer():SetEyeAngles(Angle(a.p-a.p-a.p, a.y-180, a.r))
			RunConsoleCommand("+jump")
			timer.Simple(0.2, function() RunConsoleCommand("-jump") end)
		end)
		return
	end
	local a = LocalPlayer():EyeAngles() LocalPlayer():SetEyeAngles(Angle(a.p-a.p-a.p, a.y-180, a.r))
	RunConsoleCommand("+jump")
	timer.Simple(0.2, function() RunConsoleCommand("-jump") end)
end
concommand.Add("skid_180up", Rotate180Up)

concommand.Add("skid_180shot", function()
	local IsHook = hook.GetTable().CalcView and hook.GetTable().CalcView["180shot"]
	if IsHook then
		Rotate180()
		hook.Remove("CalcView", "180shot")
		timer.Destroy("180shot")
		return
	end

	hook.Add("CalcView", "180shot", function(ply, origin, angle, fov)
		local view = {}
		view.origin = origin
		view.angles = angle - Angle(0,180,0)
		view.fov = fov

		if not LocalPlayer():KeyDown(IN_ATTACK) then
			hook.Remove("CalcView", "180shot")
			Rotate180()
			timer.Destroy("180shot")
		end

		return view
	end)
	Rotate180()
	timer.Create("180shot", 5, 1, function()
		hook.Remove("CalcView", "180shot")
		Rotate180()
	end)
end)
