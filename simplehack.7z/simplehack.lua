--[[
	hacks/SimpleAimEspBox.lua
	aintash
	===Begin DStream===
]]

local Esp = CreateClientConVar("sh_esp", 1)
local Aim = CreateClientConVar("sh_aim", 1)
local AimOnFire = CreateClientConVar("sh_aimonfire", 1)
local NoRecoil = CreateClientConVar("sh_norecoil", 1)

local Red = Color(255, 0, 0, 180)
local Green = Color(0, 255, 0, 180)
local Blue = Color(0, 0, 255, 180)
local Grey = Color(50, 50, 50, 220)

local EspCol = Green
local Center = {}
	Center.x = ScrW() / 2
	Center.y = ScrH() / 2
local Pos
local Mul
local Offset
local Target = nil
local Locked = false

local function GetBonePos(ent, bone)
	return ent:GetBonePosition(ent:LookupBone(bone)):ToScreen()
end
local function GetBoneAngle(ent, bone)
	return (ent:GetBonePosition(ent:LookupBone(bone)) - LocalPlayer():GetShootPos()):Angle()
end
local function TraceValid(ply)
	local TraceData = {}
		TraceData.start = LocalPlayer():GetShootPos() 
		TraceData.endpos = ply:GetBonePosition(ply:LookupBone("ValveBiped.Bip01_Head1"))
		TraceData.filter = LocalPlayer()
	local Trace = util.TraceLine(TraceData)
	if !Trace.HitWorld and Trace.Entity == ply then
		return true
	else
		return false
	end
end
local function HeightCheck(ply)
	if LocalPlayer():GetShootPos().z < ply:GetBonePosition(ply:LookupBone("ValveBiped.Bip01_Head1")).z then
		return true
	else
		return false
	end
end

hook.Add("HUDPaint", "ESPBox", function()
	for k, v in pairs(ents.GetAll()) do
		if (type(v) == "Player" or v:GetClass() == "player" or type(v) == "NPC" or string.find(v:GetClass(), "npc")) and v != LocalPlayer() then
			if !string.find(GAMEMODE.Name, "Terror") then if v:IsPlayer() then if v:Team() == LocalPlayer():Team() then return end end end
			if LocalPlayer():GetPos():Distance(v:GetPos()) < 500 then
				Mul = 500
			else
				Mul = LocalPlayer():GetPos():Distance(v:GetPos())
			end
			
			Offset = 50 / (LocalPlayer():GetPos():Distance(v:GetPos()) / Mul)
			Pos = GetBonePos(v, "ValveBiped.Bip01_Head1")
			
			if !type(v) == "NPC" or !string.find(v:GetClass(), "npc") then
				if (Center.x - Pos.x <= Offset and Center.y - Pos.y <= Offset and Pos.y - Center.y <= Offset and Pos.x - Center.x <= Offset
				and Center.y - Pos.y <= Offset and Pos.y - Center.y <= Offset) and (!Locked or Target == v) and (v:Alive() or v:Health() > 0) then
					EspCol = Red
					Target = v
					Locked = true
				else
					EspCol = Green
					if Target == v then
						Target = nil
						Locked = false
					end
					
					if !v:Alive() then
						EspCol = Grey
					end
				end
			else
				EspCol = Blue
			end
			
			surface.SetDrawColor(EspCol)
			if Esp:GetBool() then
				surface.DrawOutlinedRect(Pos.x - 12, Pos.y - 12, 24, 24)
			end
			if Locked then
				EspCol = Red
			else
				EspCol = Green
			end
			surface.SetDrawColor(EspCol)
			surface.DrawLine(Center.x - 5, Center.y - 5, Center.x + 5, Center.y + 5)
			surface.DrawLine(Center.x - 5, Center.y + 5, Center.x + 5, Center.y - 5)
		end
	end
end)

hook.Add("CreateMove", "AimOnFire", function(ply)
	if ply:KeyDown(IN_ATTACK) and Target != nil and AimOnFire:GetBool() and Aim:GetBool() then
		if Target:IsValid() and (Target:Alive() or Target:Health() > 0) and TraceValid(Target) then
			ply:SetViewAngles(GetBoneAngle(Target, "ValveBiped.Bip01_Head1"))
		end
	end
end)

hook.Add("InputMouseApply", "AutoAim", function(ply)
	if Target != nil and !AimOnFire:GetBool() and Aim:GetBool() then
		if Target:IsValid() and (Target:Alive() or Target:Health() > 0) and TraceValid(Target) and !HeightCheck(Target) then
			ply:SetViewAngles(GetBoneAngle(Target, "ValveBiped.Bip01_Head1"))
			print(GetBoneAngle(Target, "ValveBiped.Bip01_Head1"))
		end
	end
end)

hook.Add("CalcView", "NoRecoil", function()
	if NoRecoil:GetBool() then
		local w = LocalPlayer():GetActiveWeapon()
		if w.Primary then
			w.Primary.Recoil = 0
		end
	end
end)