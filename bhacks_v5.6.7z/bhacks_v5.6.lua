//if ( SERVER ) then return; end

local Version 					= "B-Hacks v5.6" // Version of B-Hacks
local Versionw 					= "B-Hacks v5.6!" // WelcomeMsg Version
local nick 						= LocalPlayer():Nick()

local HeadLasers 				= CreateClientConVar ("B-Hacks_Lasers_HeadLasers", 1, true, false)
local EyeLasers 				= CreateClientConVar ("B-Hacks_Lasers_EyeLasers", 1, true, false)
local Skybox 					= CreateClientConVar ("B-Hacks_Misc_BlackSkyBox", 0, true, false)
local FlashLightSpam 			= CreateClientConVar ("B-Hacks_Misc_FlashLightSpam", 0, true, false)
local BunnyHopConVar 			= CreateClientConVar ("B-Hacks_Misc_Bhop", 1, true, false)
local NoRecoil					= CreateClientConVar ("B-Hacks_Misc_NoRecoil", 1, true, false)
local ESPActive					= CreateClientConVar ("B-Hacks_ESP_Active", 1, true, false)
local ESPNick					= CreateClientConVar ("B-Hacks_ESP_ShowNick", 1, true, false)
local ESPFriend					= CreateClientConVar ("B-Hacks_ESP_ShowFriend", 1, true, false)
local ESPAdmin					= CreateClientConVar ("B-Hacks_ESP_ShowRank", 1, true, false)
local ESPHealth					= CreateClientConVar ("B-Hacks_ESP_ShowHealth", 1, true, false)
local ESPArmor					= CreateClientConVar ("B-Hacks_ESP_ShowArmor", 0, true, false)
local Crosshair					= CreateClientConVar ("B-Hacks_ESP_Crosshair", 1, true, false)
local XrayPlayer				= CreateClientConVar ("B-Hacks_Xray_Player", 1, true, false)
local XrayWireframe				= CreateClientConVar ("B-Hacks_Xray_Active", 1, true, false)
local XrayPlayerSolid			= CreateClientConVar ("B-Hacks_Xray_Player_Solid", 1, true, false)
local XrayPlayerTeamColors		= CreateClientConVar ("B-Hacks_Xray_Player_TeamColors", 1, true, false)
local Propkillmode				= CreateClientConVar ("B-Hacks_PropKillMode", 0, true, false)

local colors					= {}
red								= Color(255,0,0,255);
black							= Color(0,0,0,255);
green							= Color(0,255,0,255);
white							= Color(255,255,255,255);
blue							= Color(0,0,255,255);
cyan							= Color(0,255,255,255);
pink 							= Color(255,0,255,255);
blue							= Color(0,0,255,255);
grey							= Color(100,100,100,255);
gold							= Color(255,228,0,255);
lblue							= Color(155,205,248);
lgreen							= Color(174,255,0);
iceblue							= Color(116,187,251,255);

local tblFonts = { } -- 41-51 from facepunch
g = table.Copy(_G)

tblFonts["ESPFont"] = {
	font = "Default",
	size = 16,
	weight = 900,
}

tblFonts["Trebuchet25"] = {
	font = "Trebuchet MS",
	size = 21,
	weight = 50,
}

tblFonts["MenuItem"] = {
	font = "Lucida Console",
	size = 20,
	weight = 500,
}


for k,v in SortedPairs( tblFonts ) do
	surface.CreateFont( k, tblFonts[k] );
end
	
--//   L		H 		R	    //--
--\\	E		 A		 T		\\--
--//	 T		  X		  !		//--
--\\		T	 	S			\\--
--//		 H		 T			//--
--\\		  E		  A			\\--
							
							
local function IGWelcome() // Simple and nice welcome.
	chat.AddText("")
	chat.AddText(blue, "[B-Hacks]", gold, " Welcome to ", Version )  // ..nick, " !")
	chat.AddText(blue, "[B-Hacks]", gold, " All Player/Server info has been printed in console!")
	chat.AddText("")
end

 local function Help()
 print("")
 print("-----=Help=-----")
 print("__ClientSideVars__")
 print("")
 print("B-Hacks_FlashLightSpam 1/0 - Upon turning this to 1 holding P will spam the flashlight!")
 print("")
 print("_Commands_")
 print("B-Hacks_")
 
 end
 concommand.Add("B-Hacks_Help", Help)
 /*
local function playermodels() 
for k,v in pairs(player.GetAll()) do 
v:SetModel("self")
end
end
hook.Add("Thinks", "FPeople", playermodels)
*/
local function ConsoleWelcome()
print(" ")
print("Hello!")
print("Welcome to " ..Versionw)
print("")
print("---=== Server Info ===---")
print("")
print( "Your Ping:", LocalPlayer():Ping() )
print("")
print("")
print("")
print("")
print("")
print("-= Players =-")
print("")

	for k, v in pairs(player.GetAll()) do
		print("Player:     " .. v:GetName() .. " :: " .. v:SteamID() .. " :: " .. v:Nick() .. "\n")
	end
	
print("\n")
print("\n")

	local Friends = ""
		for k, v in pairs(player.GetAll()) do
			if v:GetFriendStatus() == "friend" then
				Friends = ", " .. v:GetName() .. " :: " .. v:SteamID() .. " :: " .. v:Nick() .. Friends
	end
		end
				if Friends ~= "" then
				print("Friend:     " .. string.sub(Friends, 3))
				end
				
print("\n")
print("\n")
end

local function PrintPlayers()
print("\n")
print("-=Players=-\n")
print("\n")

	for k, v in pairs(player.GetAll()) do
		print("Player:     " .. v:GetName() .. " :: " .. v:SteamID() .. " :: " .. v:Nick() .. "\n")
	end
	
print("\n")
print("\n")

	local Friends = ""
		for k, v in pairs(player.GetAll()) do
			if v:GetFriendStatus() == "friend" then
				Friends = ", " .. v:GetName() .. " :: " .. v:SteamID() .. " :: " .. v:Nick() .. Friends
	end
		end
				if Friends ~= "" then
				print("Friend:     " .. string.sub(Friends, 3))
				end
				
print("\n")
print("\n")
end
concommand.Add("B-Hacks_PrintPlayers", PrintPlayers )

function GAMEMODE:CreateMove() // NoRecoil Made by: Simple
	if(GetConVarNumber("B-Hacks_NoRecoil") == 1) then
	local wep = LocalPlayer():GetActiveWeapon()
		if IsValid(wep) and wep.Primary then
			wep.Primary.Recoil = 0
		end
	end
end

local function BunnyHop()
if ( BunnyHopConVar:GetBool() ) then
if ( input.IsKeyDown( KEY_SPACE ) ) then
if ( LocalPlayer():OnGround() ) then
RunConsoleCommand( "+jump" )
else
RunConsoleCommand( "-jump" )
end
else
RunConsoleCommand( "-jump" )
end
end
end
hook.Add( "Think", "asdasdasda", BunnyHop )

function ESP()
	if (GetConVarNumber("B-Hacks_Xray_Player") == 1) and (GetConVarNumber("B-Hacks_Xray_Active") == 1) then
		for k, v in pairs(ents.FindByClass("player")) do
			if (GetConVarNumber("B-Hacks_Xray_Player_Solid") == 1) and (GetConVarNumber("B-Hacks_Xray_Player_TeamColors") == 1) and v:IsPlayer() and v:Alive() then
				local playercolor = g.team.GetColor(v:Team() ) or Color(134,13,255,255)
				cam.Start3D(g.EyePos(), g.EyeAngles() )
				g.render.SetColorModulation(playercolor.r / 255, playercolor.g / 255, playercolor.b / 255 ) 
				g.render.SetBlend(playercolor.a / 0.5 )
				v:SetMaterial("models/debug/debugwhite")
				v:SetColor(playercolor)
				v:DrawModel()
				cam.End3D()
			end
		end
	end

			//	((GetConVarNumber("B-Hacks_Xray_Player") == 1) and v:IsPlayer() and v:Alive() and g.team.GetName(v:Team() ) != "Spectators" ) then
				//	local chamcol = Color(134, 13, 255, 255)
			//			if v:IsPlayer() then chamcol = Color(255,13,0) //g.team.GetColor(v:Team() ) or Color(134,13,255,255)



for _, v in g.pairs(g.player.GetAll()) do
	if ((GetConVarNumber("B-Hacks_ESP_Active") == 1) and v:IsPlayer() and v:Alive() and g.team.GetName(v:Team()) != "Spectators") and v != g.LocalPlayer() then
	local y = -10
	local CallName = v:Nick()
	local rank = "User"
	local rankcol = g.Color(150,0,255,255)

		if v:IsUserGroup("Admin") or v:IsUserGroup("admin") or v:IsUserGroup("adminpluss") then rank = "Admin" rankcol = g.Color(255,10,10,255) elseif
		v:IsUserGroup("AdminVip") or v:IsUserGroup("adminvip") or v:IsUserGroup("vipadmin") or v:IsUserGroup("VipAdmin") then rank = "Admin" rankcol = g.Color(255,10,10,255) elseif
		v:IsUserGroup("SuperAdmin") or v:IsUserGroup("superadmin") or v:IsUserGroup("Super Admin") or v:IsUserGroup("super admin") then rank = "Super Admin" rankcol = g.Color(0,150,255,255) elseif
		v:IsUserGroup("Moderator") or v:IsUserGroup("moderator") or v:IsUserGroup("mod") then rank = "Moderator" rankcol = g.Color(200,220,12,255) elseif
		v:IsUserGroup("vip") or v:IsUserGroup("VIP") or v:IsUserGroup("donator") or v:IsUserGroup("Silver VIP") or v:IsUserGroup("Diamond VIP") then rank = "VIP" rankcol = g.Color(255, 0, 0, 255) elseif
		v:IsUserGroup("operator") or v:IsUserGroup("Operator") then rank = "Operator" rankcol = g.Color(200,220,12,255) elseif
		v:IsUserGroup("member") or v:IsUserGroup("Member") then rank = "Member" rankcol = g.Color(5,255,5) elseif
		v:IsUserGroup("Respected") or v:IsUserGroup("respected") then rank = "respected" rankcol = g.Color(5,255,5) elseif
		v:IsUserGroup("Owner") or v:IsUserGroup("owner") then rank = "Owner" rankcol = g.Color(0,150,255,255)elseif
		v:IsUserGroup("CoOwner") or v:IsUserGroup("coowner") or v:IsUserGroup("Co-Owner") or v:IsUserGroup("co-owner") or v:IsUserGroup("Co Owner") then rank = "Co-Owner" rankcol = g.Color(0,150,255,255) else
		rank = "User" rankcol = Color(255,255,255)
		end

	local color = g.Color(255,255,255,255)
	local ESPPos = (v:GetPos()+g.Vector(0,0,45)):ToScreen()
	
			if (GetConVarNumber("B-Hacks_ESP_ShowHealth") == 1) then
				g.draw.SimpleText("H: "..v:Health(), "ESPFont", ESPPos.x, ESPPos.y + y, color, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
				y = y -16
			end
				if (GetConVarNumber("B-Hacks_ESP_ShowArmor") == 1) then
					if v:Armor() >= 1 then
					g.draw.SimpleText("A: " ..v:Armor(), "ESPFont", ESPPos.x, ESPPos.y + y, color, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
					y = y -16
				end
			end
			
			if (GetConVarNumber("B-Hacks_ESP_ShowRank") == 1) then
				g.draw.SimpleText(rank, "ESPFont", ESPPos.x, ESPPos.y + y, rankcol, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
				y = y -16
			end
			
			if (GetConVarNumber("B-Hacks_ESP_ShowFriend") == 1) then
				if v:GetFriendStatus() == "friend" then
					color = g.Color(5,150,255)
					g.draw.SimpleText("Friend", "ESPFont", ESPPos.x, ESPPos.y + y, color, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
					y = y -16
				end
			end
			
			if (GetConVarNumber("B-Hacks_ESP_ShowNick") == 1) then
				local color = g.Color(255,255,255,255)
				g.draw.SimpleText(v:Nick(), "ESPFont", ESPPos.x, ESPPos.y + y, color, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
				y = y -1
			end
		end
	end
	
-----------------------------
	if (GetConVarNumber( "B-Hacks_Lasers_HeadLasers" ) == 1) then
	local neededAngles = Angle(-90, 0, 0)
	cam.Start3D(EyePos(), EyeAngles())
		for k,ply in pairs(player.GetAll()) do
			if ply != LocalPlayer() && ply:Alive() then
			local shootPos = ply:GetShootPos()
			local data = {}
			data.start = shootPos
			data.endpos = shootPos + neededAngles:Forward() * 10000
			data.filter = ply
			local tr = util.TraceLine(data)
			cam.Start3D2D(shootPos, neededAngles, 1)
				if IsValid(tr.Entity) then
				surface.SetDrawColor(255, 140, 0, 255)
				else
				surface.SetDrawColor(255, 0, 0, 255)
				end
				surface.DrawLine(0, 0, tr.HitPos:Distance(shootPos), 0)
				cam.End3D2D()
				end
		end
	cam.End3D()
	else end
end
hook.Add("RenderScreenspaceEffects", "ESP", ESP)

local function Crosshair()
	if (GetConVarNumber("B-Hacks_ESP_Crosshair") == 1) then
	local x = ScrW() / 2
	local y = ScrH() / 2
	local gap = 1
	local length = gap + 15

	surface.SetDrawColor( 255, 0, 0, 255 )
	surface.DrawLine( x - length, y, x - gap, y )
	surface.DrawLine( x + length, y, x + gap, y )
	surface.DrawLine( x, y - length, x, y - gap )
	surface.DrawLine( x, y + length, x, y + gap )
	end
end
hook.Add("RenderScreenspaceEffects", "CrossHair", Crosshair)

function EyeSight()
for k,v in pairs(player.GetAll()) do
if (GetConVarNumber( "B-Hacks_Lasers_EyeLasers" ) == 1) then
cam.Start3D(EyePos(), EyeAngles())
for k,ply in pairs(player.GetAll()) do
if ply != LocalPlayer() && ply:Alive() then
local shootPos = ply:GetShootPos()
local eyeAngles = ply:EyeAngles()
local data = {}
data.start = shootPos
data.endpos = shootPos + eyeAngles:Forward() * 10000
data.filter = ply
local tr = util.TraceLine(data)
cam.Start3D2D(shootPos, eyeAngles, 1)
if IsValid(tr.Entity) then
surface.SetDrawColor(255, 140, 0, 255)
else
if v:GetFriendStatus() == "friend" then
surface.SetDrawColor(0, 0, 255, 255)
else
surface.SetDrawColor(0, 0, 255, 255)
end
end
surface.DrawLine(0, 0, tr.HitPos:Distance(shootPos), 0)
cam.End3D2D()
end
end
cam.End3D()
else end
end
end
hook.Add("RenderScreenspaceEffects", "EyeSightt", EyeSight)

local function Skybox() // Thought I would like to mention.... Falco your gay!
if (GetConVarNumber( "B-Hacks_Misc_BlackSkyBox" ) == 1) then
render.Clear(5, 5, 5, 255)
return true
else
return false
end
end
hook.Add("PreDrawSkyBox", "Meh", Skybox)

/* Fixing
local function PropThrow() // Pew!
if (GetConVarNumber( "B-Hacks_Sounds_PropThrow" ) == 1) then
surface.PlaySound("pew.wav")
end
end
hook.Add("PhysgunDrop", "PropThrow2", PropThrow)
*/

local XrayActive = CreateClientConVar ("B-Hacks_Xray_Active", 0, true, false)
local XrayDoors = CreateClientConVar ("B-Hacks_Xray_Doors", 1, true, false) // prop_door_rotating
local XrayProps = CreateClientConVar ("B-Hacks_Xray_Props", 1, true, false)
local XrayPlayers = CreateClientConVar ("B-Hacks_Xray_Players", 1, true, false)

local function XrayProps()
	if (GetConVarNumber( "B-Hacks_Xray_Props" ) == 1) and (GetConVarNumber( "B-Hacks_Xray_Active" ) == 1) then
	cam.Start3D(g.EyePos(), g.EyeAngles() )	
		for NProps, Props in g.pairs(ents.FindByClass("prop_physics")) do
		local chamcol = Color(50, 255, 50, 40)
		g.render.SetColorModulation(chamcol.r / 255, chamcol.g / 255, chamcol.b / 255, chamcol.a / 30 ) 
		g.render.SetBlend(chamcol.a / 400 )
		Props:SetRenderMode(RENDERMODE_TRANSALPHA)
		Props:SetMaterial("mat2")//CWireframe
		Props:SetColor(chamcol)
		Props:DrawModel()
		end
	cam.End3D()
	else
for NProps, Props in g.pairs(ents.FindByClass("prop_physics")) do
	Props:SetMaterial(self)
	hook.Remove("XrayProps")
	end
end
end
hook.Add("PostDrawOpaqueRenderables", "XrayProps", XrayProps)//PostDrawOpaqueRenderables



local function XrayPlayers()
	if (GetConVarNumber( "B-Hacks_Xray_Player" ) == 1) and (GetConVarNumber( "B-Hacks_Xray_Active" ) == 1) then
	cam.Start3D(g.EyePos(), g.EyeAngles() )
		for NPlayers, Players in g.pairs(ents.FindByClass("player")) do
		local chamcol = Color(255, 0, 0, 10)
		g.render.SetColorModulation(chamcol.r / 255, chamcol.g / 255, chamcol.b / 255, chamcol.a / 30 )
		g.render.SetBlend(chamcol.a / 100 )
		Players:SetMaterial("mat2")
		Players:SetColor(chamcol)
		Players:DrawModel()
		end
	cam.End3D()
	else
for NPlayers, Players in g.pairs(ents.FindByClass("player")) do
	Players:SetMaterial(self)
	hook.Remove("XrayPlayers")
	end
end
end
hook.Add("RenderScreenspaceEffects", "XrayPlayers", XrayPlayers)

local function PropSurf()
			RunConsoleCommand("+attack")
		local a = LocalPlayer():EyeAngles() LocalPlayer():SetEyeAngles(Angle(a.p-a.p-a.p, a.y-180, a.r))
		RunConsoleCommand("+jump")
			timer.Simple(0.4, function() RunConsoleCommand("-attack") end)
			timer.Simple(0.4, function() RunConsoleCommand("undo") end)
			timer.Simple(0.2, function() RunConsoleCommand("-jump") end)
		end
concommand.Add("B-Hacks_PropSurf", PropSurf)

local function Undoall() // Stfu its easy.
RunConsoleCommand("Undo")
RunConsoleCommand("Undo")
RunConsoleCommand("Undo")
RunConsoleCommand("Undo")
RunConsoleCommand("Undo")
RunConsoleCommand("Undo")
RunConsoleCommand("Undo")
RunConsoleCommand("Undo")
RunConsoleCommand("Undo")
RunConsoleCommand("Undo")
end
concommand.Add("B-Hacks_UndoAll", Undoall)

surface.CreateFont( "Arial", { font = "Arial", size = 20, weight = 200 } )

local function DrawVersion() // SHH! YOU HAVE NEVER SEEN THIS! 
	draw.WordBox( 14, 1798, 0, Version,"Arial",Color(0,0,255,150),gold)
end
hook.Add("HUDPaint", "DrawVersion", DrawVersion)

local function Health() // SHH! YOU HAVE NEVER SEEN THIS! 
	draw.WordBox( 14, 2, 0,"Health: " ..LocalPlayer():Health() .. "   " .. LocalPlayer():Nick() .."   " .. "Armor: " ..LocalPlayer():Armor(),"Arial",Color(0,0,255,150),gold)
end
hook.Add("HUDPaint", "DrawHealth", Health)

IGWelcome()
ConsoleWelcome()

function MainMenu()

	// Frames \\
	
	MainFrame = vgui.Create( "DFrame" ) -- Main Frame
	MainFrame:SetPos( 50, 50 )
	MainFrame:SetSize( 1800, 825 ) -- <> || ^V
	MainFrame:SetTitle( "B-Hacks V5.6" )
	MainFrame:SetVisible( true )
	MainFrame:SetDraggable( false )
	MainFrame:ShowCloseButton( false )
	MainFrame:MakePopup()
	MainFrame.Paint = function()
		surface.SetDrawColor( 32, 32, 32, 250 )
		surface.DrawRect( 0, 0, MainFrame:GetWide(), MainFrame:GetTall() )
	end
	
	SecondFrame = vgui.Create( "DFrame" )
	SecondFrame:SetPos( 50, 50 )
	SecondFrame:SetSize( 1800, 820 ) -- <> || ^V
	SecondFrame:SetTitle( "B-Hacks V5.6" )
	SecondFrame:SetVisible( false )
	SecondFrame:SetDraggable( false )
	SecondFrame:ShowCloseButton( false )
	SecondFrame:MakePopup()
	SecondFrame.Paint = function()
    surface.SetDrawColor( 6, 6, 6, 250 )
    surface.DrawRect( 0, 0, SecondFrame:GetWide(), SecondFrame:GetTall() )
	end

	ThirdFrame = vgui.Create( "DFrame" )
	ThirdFrame:SetPos( 50, 50 )
	ThirdFrame:SetSize( 1800, 820 ) -- <> || ^V
	ThirdFrame:SetTitle( "B-Hacks V5.6" )
	ThirdFrame:SetVisible( false )
	ThirdFrame:SetDraggable( false )
	ThirdFrame:ShowCloseButton( false )
	ThirdFrame:MakePopup()
	ThirdFrame.Paint = function()
    surface.SetDrawColor( 6, 6, 6, 250 )
    surface.DrawRect( 0, 0, ThirdFrame:GetWide(), ThirdFrame:GetTall() )
	end
	
	FourthFrame = vgui.Create( "DFrame" )
	FourthFrame:SetPos( 50, 50 )
	FourthFrame:SetSize( 1800, 820 ) -- <> || ^V
	FourthFrame:SetTitle( "B-Hacks V5.6" )
	FourthFrame:SetVisible( false )
	FourthFrame:SetDraggable( false )
	FourthFrame:ShowCloseButton( false )
	FourthFrame:MakePopup()
	FourthFrame.Paint = function()
    surface.SetDrawColor( 6, 6, 6, 250 )
    surface.DrawRect( 0, 0, FourthFrame:GetWide(), FourthFrame:GetTall() )
	end
	
	FifthFrame = vgui.Create( "DFrame" )
	FifthFrame:SetPos( 50, 50 )
	FifthFrame:SetSize( 1800, 820 ) -- <> || ^V
	FifthFrame:SetTitle( "B-Hacks V5.6" )
	FifthFrame:SetVisible( false )
	FifthFrame:SetDraggable( false )
	FifthFrame:ShowCloseButton( false )
	FifthFrame:MakePopup()
	FifthFrame.Paint = function()
    surface.SetDrawColor( 6, 6, 6, 250 )
    surface.DrawRect( 0, 0, FifthFrame:GetWide(), FifthFrame:GetTall() )
	end
	
	SixthFrame = vgui.Create( "DFrame" )
	SixthFrame:SetPos( 50, 50 )
	SixthFrame:SetSize( 1800, 820 ) -- <> || ^V
	SixthFrame:SetTitle( "B-Hacks V5.6" )
	SixthFrame:SetVisible( false )
	SixthFrame:SetDraggable( false )
	SixthFrame:ShowCloseButton( false )
	SixthFrame:MakePopup()
	SixthFrame.Paint = function()
    surface.SetDrawColor( 6, 6, 6, 250 )
    surface.DrawRect( 0, 0, SixthFrame:GetWide(), SixthFrame:GetTall() )
	end
	
	// Buttons \\
	
	local CloseButtonMainFrame = vgui.Create( "Button", MainFrame )
        CloseButtonMainFrame:SetSize( 1700, 35 )
        CloseButtonMainFrame:SetPos( 70, 2 )
        CloseButtonMainFrame:SetVisible( true )
        CloseButtonMainFrame:SetText( "Close Menu" )
		CloseButtonMainFrame.Paint = function()
			surface.SetDrawColor( 25, 25, 25, 255 )
			surface.DrawRect( 0, 4, CloseButtonMainFrame:GetWide(), CloseButtonMainFrame:GetTall() )
		end
        function CloseButtonMainFrame:OnMousePressed()
			MainFrame:SetVisible( false )
        end
		
	local CloseButtonSecondFrame = vgui.Create( "Button", SecondFrame )
        CloseButtonSecondFrame:SetSize( 1700, 35 )
        CloseButtonSecondFrame:SetPos( 70, 2 )
        CloseButtonSecondFrame:SetVisible( true )
        CloseButtonSecondFrame:SetText( "Close Menu" )
		CloseButtonSecondFrame.Paint = function()
			surface.SetDrawColor( 10, 10, 240, 200 )
			surface.DrawRect( 0, 4, CloseButtonSecondFrame:GetWide(), CloseButtonSecondFrame:GetTall() )
		end
        function CloseButtonSecondFrame:OnMousePressed()
			SecondFrame:SetVisible( false )
        end
		
	local CloseButtonThirdFrame = vgui.Create( "Button", ThirdFrame )
        CloseButtonThirdFrame:SetSize( 1700, 35 )
        CloseButtonThirdFrame:SetPos( 70, 2 )
        CloseButtonThirdFrame:SetVisible( true )
        CloseButtonThirdFrame:SetText( "Close Menu" )
		CloseButtonThirdFrame.Paint = function()
			surface.SetDrawColor( 10, 10, 240, 200 )
			surface.DrawRect( 0, 4, CloseButtonThirdFrame:GetWide(), CloseButtonThirdFrame:GetTall() )
		end
        function CloseButtonThirdFrame:OnMousePressed()
			ThirdFrame:SetVisible( false )
        end
		
	local CloseButtonFourthFrame = vgui.Create( "Button", FourthFrame )
        CloseButtonFourthFrame:SetSize( 1700, 35 )
        CloseButtonFourthFrame:SetPos( 70, 2 )
        CloseButtonFourthFrame:SetVisible( true )
        CloseButtonFourthFrame:SetText( "Close Menu" )
		CloseButtonFourthFrame.Paint = function()
			surface.SetDrawColor( 10, 10, 240, 200 )
			surface.DrawRect( 0, 4, CloseButtonFourthFrame:GetWide(), CloseButtonFourthFrame:GetTall() )
		end
        function CloseButtonFourthFrame:OnMousePressed()
			FourthFrame:SetVisible( false )
        end
		
	local CloseButtonFifthFrame = vgui.Create( "Button", FifthFrame )
        CloseButtonFifthFrame:SetSize( 1700, 35 )
        CloseButtonFifthFrame:SetPos( 70, 2 )
        CloseButtonFifthFrame:SetVisible( true )
        CloseButtonFifthFrame:SetText( "Close Menu" )
		CloseButtonFifthFrame.Paint = function()
			surface.SetDrawColor( 10, 10, 240, 200 )
			surface.DrawRect( 0, 4, CloseButtonFifthFrame:GetWide(), CloseButtonFifthFrame:GetTall() )
		end
        function CloseButtonFifthFrame:OnMousePressed()
			FifthFrame:SetVisible( false )
        end
		
	local CloseButtonSixthFrame = vgui.Create( "Button", SixthFrame )
        CloseButtonSixthFrame:SetSize( 1700, 35 )
        CloseButtonSixthFrame:SetPos( 70, 2 )
        CloseButtonSixthFrame:SetVisible( true )
        CloseButtonSixthFrame:SetText( "Close Menu" )
		CloseButtonSixthFrame.Paint = function()
			surface.SetDrawColor( 10, 10, 240, 200 )
			surface.DrawRect( 0, 4, CloseButtonSixthFrame:GetWide(), CloseButtonSixthFrame:GetTall() )
		end
        function CloseButtonSixthFrame:OnMousePressed()
			SixthFrame:SetVisible( false )
        end
		
		// Tabs \\
		
	local NextTabButtonMainFrame = vgui.Create( "Button", MainFrame )
        NextTabButtonMainFrame:SetSize( 50, 710 )
        NextTabButtonMainFrame:SetPos( 1720, 40 )
        NextTabButtonMainFrame:SetVisible( true )
        NextTabButtonMainFrame:SetText( "Next Tab" )
		NextTabButtonMainFrame.Paint = function()
			surface.SetDrawColor( 25, 25, 25, 255 )
			surface.DrawRect( 0, 4, NextTabButtonMainFrame:GetWide(), NextTabButtonMainFrame:GetTall() )
		end
        function NextTabButtonMainFrame:OnMousePressed()
			MainFrame:SetVisible( false )
			SecondFrame:SetVisible( true )
        end

	local BackTabButtonSecondFrame = vgui.Create( "Button", SecondFrame )
        BackTabButtonSecondFrame:SetSize( 50, 700 )
        BackTabButtonSecondFrame:SetPos( 70, 40 )
        BackTabButtonSecondFrame:SetVisible( true )
        BackTabButtonSecondFrame:SetText( "Back Tab" )
		BackTabButtonSecondFrame.Paint = function()
			surface.SetDrawColor( 25, 25, 25, 255 )
			surface.DrawRect( 0, 4, BackTabButtonSecondFrame:GetWide(), BackTabButtonSecondFrame:GetTall() )
		end
        function BackTabButtonSecondFrame:OnMousePressed()
			SecondFrame:SetVisible( false )
			MainFrame:SetVisible( true )
        end
		
	local BackTabButtonThirdFrame = vgui.Create( "Button", ThirdFrame )
        BackTabButtonThirdFrame:SetSize( 50, 700 )
        BackTabButtonThirdFrame:SetPos( 70, 40 )
        BackTabButtonThirdFrame:SetVisible( true )
        BackTabButtonThirdFrame:SetText( "Back Tab" )
		BackTabButtonThirdFrame.Paint = function()
			surface.SetDrawColor( 10, 10, 240, 200 )
			surface.DrawRect( 0, 4, BackTabButtonThirdFrame:GetWide(), BackTabButtonThirdFrame:GetTall() )
		end
        function BackTabButtonThirdFrame:OnMousePressed()
			SecondFrame:SetVisible( false )
			ThirdFrame:SetVisible( false )
			MainFrame:SetVisible( true )
        end
		
	local BackTabButtonFourthFrame = vgui.Create( "Button", FourthFrame )
        BackTabButtonFourthFrame:SetSize( 50, 700 )
        BackTabButtonFourthFrame:SetPos( 70, 40 )
        BackTabButtonFourthFrame:SetVisible( true )
        BackTabButtonFourthFrame:SetText( "Back Tab" )
		BackTabButtonFourthFrame.Paint = function()
			surface.SetDrawColor( 10, 10, 240, 200 )
			surface.DrawRect( 0, 4, BackTabButtonFourthFrame:GetWide(), BackTabButtonFourthFrame:GetTall() )
		end
        function BackTabButtonFourthFrame:OnMousePressed()
			SecondFrame:SetVisible( false )
			ThirdFrame:SetVisible( false )
			FourthFrame:SetVisible( false )
			MainFrame:SetVisible( true )
        end
		
	local BackTabButtonFifthFrame = vgui.Create( "Button", FifthFrame )
        BackTabButtonFifthFrame:SetSize( 50, 700 )
        BackTabButtonFifthFrame:SetPos( 70, 40 )
        BackTabButtonFifthFrame:SetVisible( true )
        BackTabButtonFifthFrame:SetText( "Back Tab" )
		BackTabButtonFifthFrame.Paint = function()
			surface.SetDrawColor( 10, 10, 240, 200 )
			surface.DrawRect( 0, 4, BackTabButtonFifthFrame:GetWide(), BackTabButtonFifthFrame:GetTall() )
		end
        function BackTabButtonFifthFrame:OnMousePressed()
			SecondFrame:SetVisible( false )
			ThirdFrame:SetVisible( false )
			FourthFrame:SetVisible( false )
			FifthFrame:SetVisible( false )
			MainFrame:SetVisible( true )
        end
		
	local BackTabButtonSixthFrame = vgui.Create( "Button", SixthFrame )
        BackTabButtonSixthFrame:SetSize( 50, 700 )
        BackTabButtonSixthFrame:SetPos( 70, 40 )
        BackTabButtonSixthFrame:SetVisible( true )
        BackTabButtonSixthFrame:SetText( "Back Tab" )
		BackTabButtonSixthFrame.Paint = function()
			surface.SetDrawColor( 10, 10, 240, 200 )
			surface.DrawRect( 0, 4, BackTabButtonSixthFrame:GetWide(), BackTabButtonSixthFrame:GetTall() )
		end
        function BackTabButtonSixthFrame:OnMousePressed()
			SecondFrame:SetVisible( false )
			ThirdFrame:SetVisible( false )
			FourthFrame:SetVisible( false )
			FifthFrame:SetVisible( false )
			SixthFrame:SetVisible( false )
			MainFrame:SetVisible( true )
        end
		
		// Disconnect Buttons \\
		
	local DisconnectMainFrame = vgui.Create( "Button", MainFrame )
        DisconnectMainFrame:SetSize( 400, 55 )
        DisconnectMainFrame:SetPos( 1370, 755 )
        DisconnectMainFrame:SetVisible( true )
        DisconnectMainFrame:SetText( "Disconnect From Server" )
		DisconnectMainFrame.Paint = function()
			surface.SetDrawColor( 25, 25, 25, 255 )
			surface.DrawRect( 0, 4, DisconnectMainFrame:GetWide(), DisconnectMainFrame:GetTall() )
		end
        function DisconnectMainFrame:OnMousePressed()
			LocalPlayer():ConCommand("Disconnect")
        end
		
	local DisconnectSecondFrame = vgui.Create( "Button", SecondFrame )
        DisconnectSecondFrame:SetSize( 400, 55 )
        DisconnectSecondFrame:SetPos( 1370, 755 )
        DisconnectSecondFrame:SetVisible( true )
        DisconnectSecondFrame:SetText( "Disconnect From Server" )
		DisconnectSecondFrame.Paint = function()
			surface.SetDrawColor( 244, 10, 10, 200 )
			surface.DrawRect( 0, 4, DisconnectSecondFrame:GetWide(), DisconnectSecondFrame:GetTall() )
		end
        function DisconnectSecondFrame:OnMousePressed()
			LocalPlayer():ConCommand("Disconnect")
        end
		
	local DisconnectThirdFrame = vgui.Create( "Button", ThirdFrame )
        DisconnectThirdFrame:SetSize( 400, 55 )
        DisconnectThirdFrame:SetPos( 1370, 755 )
        DisconnectThirdFrame:SetVisible( true )
        DisconnectThirdFrame:SetText( "Disconnect From Server" )
		DisconnectThirdFrame.Paint = function()
			surface.SetDrawColor( 244, 10, 10, 200 )
			surface.DrawRect( 0, 4, DisconnectThirdFrame:GetWide(), DisconnectThirdFrame:GetTall() )
		end
        function DisconnectThirdFrame:OnMousePressed()
			LocalPlayer():ConCommand("Disconnect")
        end
		
	local DisconnectFourthFrame = vgui.Create( "Button", FourthFrame )
        DisconnectFourthFrame:SetSize( 400, 55 )
        DisconnectFourthFrame:SetPos( 1370, 755 )
        DisconnectFourthFrame:SetVisible( true )
        DisconnectFourthFrame:SetText( "Disconnect From Server" )
		DisconnectFourthFrame.Paint = function()
			surface.SetDrawColor( 244, 10, 10, 200 )
			surface.DrawRect( 0, 4, DisconnectFourthFrame:GetWide(), DisconnectFourthFrame:GetTall() )
		end
        function DisconnectFourthFrame:OnMousePressed()
			LocalPlayer():ConCommand("Disconnect")
        end
		
	local DisconnectFifthFrame = vgui.Create( "Button", FifthFrame )
        DisconnectFifthFrame:SetSize( 400, 55 )
        DisconnectFifthFrame:SetPos( 1370, 755 )
        DisconnectFifthFrame:SetVisible( true )
        DisconnectFifthFrame:SetText( "Disconnect From Server" )
		DisconnectFifthFrame.Paint = function()
			surface.SetDrawColor( 244, 10, 10, 200 )
			surface.DrawRect( 0, 4, DisconnectFifthFrame:GetWide(), DisconnectFifthFrame:GetTall() )
		end
        function DisconnectFifthFrame:OnMousePressed()
			LocalPlayer():ConCommand("Disconnect")
        end
		
	local DisconnectSixthFrame = vgui.Create( "Button", SixthFrame )
        DisconnectSixthFrame:SetSize( 400, 55 )
        DisconnectSixthFrame:SetPos( 1370, 755 )
        DisconnectSixthFrame:SetVisible( true )
        DisconnectSixthFrame:SetText( "Disconnect From Server" )
		DisconnectSixthFrame.Paint = function()
			surface.SetDrawColor( 244, 10, 10, 200 )
			surface.DrawRect( 0, 4, DisconnectSixthFrame:GetWide(), DisconnectSixthFrame:GetTall() )
		end
        function DisconnectSixthFrame:OnMousePressed()
			LocalPlayer():ConCommand("Disconnect")
        end
		
		// BuyHealth Buttons \\
		
	local BuyHealthMainFrame = vgui.Create( "Button", MainFrame )
        BuyHealthMainFrame:SetSize( 400, 55 )
        BuyHealthMainFrame:SetPos( 70, 755 )
        BuyHealthMainFrame:SetVisible( true )
        BuyHealthMainFrame:SetText( "BuyHealth" )
		BuyHealthMainFrame.Paint = function()
			surface.SetDrawColor( 25, 25, 25, 255 )
			surface.DrawRect( 0, 4, BuyHealthMainFrame:GetWide(), BuyHealthMainFrame:GetTall() )
		end
        function BuyHealthMainFrame:OnMousePressed()
			LocalPlayer():ConCommand("say /buyhealth")
        end

	local BuyHealthSecondFrame = vgui.Create( "Button", SecondFrame )
        BuyHealthSecondFrame:SetSize( 400, 55 )
        BuyHealthSecondFrame:SetPos( 70, 755 )
        BuyHealthSecondFrame:SetVisible( true )
        BuyHealthSecondFrame:SetText( "BuyHealth" )
		BuyHealthSecondFrame.Paint = function()
			surface.SetDrawColor( 10, 10, 244, 200 )
			surface.DrawRect( 0, 4, BuyHealthSecondFrame:GetWide(), BuyHealthSecondFrame:GetTall() )
		end
        function BuyHealthSecondFrame:OnMousePressed()
			LocalPlayer():ConCommand("say /buyhealth")
        end
		
	local BuyHealthThirdFrame = vgui.Create( "Button", ThirdFrame )
        BuyHealthThirdFrame:SetSize( 400, 55 )
        BuyHealthThirdFrame:SetPos( 70, 755 )
        BuyHealthThirdFrame:SetVisible( true )
        BuyHealthThirdFrame:SetText( "BuyHealth" )
		BuyHealthThirdFrame.Paint = function()
			surface.SetDrawColor( 10, 10, 244, 200 )
			surface.DrawRect( 0, 4, BuyHealthThirdFrame:GetWide(), BuyHealthThirdFrame:GetTall() )
		end
        function BuyHealthThirdFrame:OnMousePressed()
			LocalPlayer():ConCommand("say /buyhealth")
        end
		
	local BuyHealthFourthFrame = vgui.Create( "Button", FourthFrame )
        BuyHealthFourthFrame:SetSize( 400, 55 )
        BuyHealthFourthFrame:SetPos( 70, 755 )
        BuyHealthFourthFrame:SetVisible( true )
        BuyHealthFourthFrame:SetText( "BuyHealth" )
		BuyHealthFourthFrame.Paint = function()
			surface.SetDrawColor( 10, 10, 244, 200 )
			surface.DrawRect( 0, 4, BuyHealthFourthFrame:GetWide(), BuyHealthFourthFrame:GetTall() )
		end
        function BuyHealthFourthFrame:OnMousePressed()
			LocalPlayer():ConCommand("say /buyhealth")
        end
		
	local BuyHealthFifthFrame = vgui.Create( "Button", FifthFrame )
        BuyHealthFifthFrame:SetSize( 400, 55 )
        BuyHealthFifthFrame:SetPos( 70, 755 )
        BuyHealthFifthFrame:SetVisible( true )
        BuyHealthFifthFrame:SetText( "BuyHealth" )
		BuyHealthFifthFrame.Paint = function()
			surface.SetDrawColor( 10, 10, 244, 200 )
			surface.DrawRect( 0, 4, BuyHealthFifthFrame:GetWide(), BuyHealthFifthFrame:GetTall() )
		end
        function BuyHealthFifthFrame:OnMousePressed()
			LocalPlayer():ConCommand("say /buyhealth")
        end
		
	local BuyHealthSixthFrame = vgui.Create( "Button", SixthFrame )
        BuyHealthSixthFrame:SetSize( 400, 55 )
        BuyHealthSixthFrame:SetPos( 70, 755 )
        BuyHealthSixthFrame:SetVisible( true )
        BuyHealthSixthFrame:SetText( "BuyHealth" )
		BuyHealthSixthFrame.Paint = function()
			surface.SetDrawColor( 10, 10, 244, 200 )
			surface.DrawRect( 0, 4, BuyHealthSixthFrame:GetWide(), BuyHealthSixthFrame:GetTall() )
		end
        function BuyHealthSixthFrame:OnMousePressed()
			LocalPlayer():ConCommand("say /buyhealth")
        end

		// Admin To Me Buttons \\
		
	local AdminToMeMainFrame = vgui.Create( "Button", MainFrame )
        AdminToMeMainFrame:SetSize( 400, 55 )
        AdminToMeMainFrame:SetPos( 700, 755 )
        AdminToMeMainFrame:SetVisible( true )
        AdminToMeMainFrame:SetText( "Admin To Me" )
		AdminToMeMainFrame.Paint = function()
			surface.SetDrawColor( 25, 25, 25, 255 )
			surface.DrawRect( 0, 4, AdminToMeMainFrame:GetWide(), AdminToMeMainFrame:GetTall() )
		end
        function AdminToMeMainFrame:OnMousePressed()
			LocalPlayer():ConCommand("say @Admin To Me")
        end
		
	local AdminToMeSecondFrame = vgui.Create( "Button", SecondFrame )
        AdminToMeSecondFrame:SetSize( 400, 55 )
        AdminToMeSecondFrame:SetPos( 700, 755 )
        AdminToMeSecondFrame:SetVisible( true )
        AdminToMeSecondFrame:SetText( "Admin To Me" )
		AdminToMeSecondFrame.Paint = function()
			surface.SetDrawColor( 10, 244, 10, 200 )
			surface.DrawRect( 0, 4, AdminToMeSecondFrame:GetWide(), AdminToMeSecondFrame:GetTall() )
		end
        function AdminToMeSecondFrame:OnMousePressed()
			LocalPlayer():ConCommand("say @Admin To Me")
        end
		
	local AdminToMeThirdFrame = vgui.Create( "Button", ThirdFrame )
        AdminToMeThirdFrame:SetSize( 400, 55 )
        AdminToMeThirdFrame:SetPos( 700, 755 )
        AdminToMeThirdFrame:SetVisible( true )
        AdminToMeThirdFrame:SetText( "Admin To Me" )
		AdminToMeThirdFrame.Paint = function()
			surface.SetDrawColor( 10, 244, 10, 200 )
			surface.DrawRect( 0, 4, AdminToMeThirdFrame:GetWide(), AdminToMeThirdFrame:GetTall() )
		end
        function AdminToMeThirdFrame:OnMousePressed()
			LocalPlayer():ConCommand("say @Admin To Me")
        end
		
	local AdminToMeFourthFrame = vgui.Create( "Button", FourthFrame )
        AdminToMeFourthFrame:SetSize( 400, 55 )
        AdminToMeFourthFrame:SetPos( 700, 755 )
        AdminToMeFourthFrame:SetVisible( true )
        AdminToMeFourthFrame:SetText( "Admin To Me" )
		AdminToMeFourthFrame.Paint = function()
			surface.SetDrawColor( 10, 244, 10, 200 )
			surface.DrawRect( 0, 4, AdminToMeFourthFrame:GetWide(), AdminToMeFourthFrame:GetTall() )
		end
        function AdminToMeFourthFrame:OnMousePressed()
			LocalPlayer():ConCommand("say @Admin To Me")
        end
		
	local AdminToMeFifthFrame = vgui.Create( "Button", FifthFrame )
        AdminToMeFifthFrame:SetSize( 400, 55 )
        AdminToMeFifthFrame:SetPos( 700, 755 )
        AdminToMeFifthFrame:SetVisible( true )
        AdminToMeFifthFrame:SetText( "Admin To Me" )
		AdminToMeFifthFrame.Paint = function()
			surface.SetDrawColor( 10, 244, 10, 200 )
			surface.DrawRect( 0, 4, AdminToMeFifthFrame:GetWide(), AdminToMeFifthFrame:GetTall() )
		end
        function AdminToMeFifthFrame:OnMousePressed()
			LocalPlayer():ConCommand("say @Admin To Me")
        end
		
	local AdminToMeSixthFrame = vgui.Create( "Button", SixthFrame )
        AdminToMeSixthFrame:SetSize( 400, 55 )
        AdminToMeSixthFrame:SetPos( 700, 755 )
        AdminToMeSixthFrame:SetVisible( true )
        AdminToMeSixthFrame:SetText( "Admin To Me" )
		AdminToMeSixthFrame.Paint = function()
			surface.SetDrawColor( 10, 244, 10, 200 )
			surface.DrawRect( 0, 4, AdminToMeSixthFrame:GetWide(), AdminToMeSixthFrame:GetTall() )
		end
        function AdminToMeSixthFrame:OnMousePressed()
			LocalPlayer():ConCommand("say @Admin To Me")
        end
		
		// GmodWiki Buttons \\
		
	local GmodWikiOneMainFrame = vgui.Create( "Button", MainFrame )
        GmodWikiOneMainFrame:SetSize( 200, 25 )
        GmodWikiOneMainFrame:SetPos( 1130, 755 )
        GmodWikiOneMainFrame:SetVisible( true )
        GmodWikiOneMainFrame:SetText( "Gmod Wiki #1" )
		GmodWikiOneMainFrame.Paint = function()
			surface.SetDrawColor( 25, 25, 25, 255 )
			surface.DrawRect( 0, 4, GmodWikiOneMainFrame:GetWide(), GmodWikiOneMainFrame:GetTall() )
		end
        function GmodWikiOneMainFrame:OnMousePressed()
			MainFrame:SetVisible( false )
			SecondFrame:SetVisible( false )
			ThirdFrame:SetVisible( true )
        end
		
	local GmodWikiOneSecondFrame = vgui.Create( "Button", SecondFrame )
        GmodWikiOneSecondFrame:SetSize( 200, 25 )
        GmodWikiOneSecondFrame:SetPos( 1130, 755 )
        GmodWikiOneSecondFrame:SetVisible( true )
        GmodWikiOneSecondFrame:SetText( "Gmod Wiki #1" )
		GmodWikiOneSecondFrame.Paint = function()
			surface.SetDrawColor( 218, 229, 2, 200 )
			surface.DrawRect( 0, 4, GmodWikiOneSecondFrame:GetWide(), GmodWikiOneSecondFrame:GetTall() )
		end
        function GmodWikiOneSecondFrame:OnMousePressed()
			MainFrame:SetVisible( false )
			SecondFrame:SetVisible( false )
			ThirdFrame:SetVisible( true )
        end
		
	local GmodWikiOneThirdFrame = vgui.Create( "Button", ThirdFrame )
        GmodWikiOneThirdFrame:SetSize( 200, 25 )
        GmodWikiOneThirdFrame:SetPos( 1130, 755 )
        GmodWikiOneThirdFrame:SetVisible( true )
        GmodWikiOneThirdFrame:SetText( "Gmod Wiki #1" )
		GmodWikiOneThirdFrame.Paint = function()
			surface.SetDrawColor( 218, 229, 2, 200 )
			surface.DrawRect( 0, 4, GmodWikiOneThirdFrame:GetWide(), GmodWikiOneThirdFrame:GetTall() )
		end
        function GmodWikiOneThirdFrame:OnMousePressed()
			MainFrame:SetVisible( false )
			SecondFrame:SetVisible( false )
			FourthFrame:SetVisible( false )
			FifthFrame:SetVisible( false )
			ThirdFrame:SetVisible( true )
        end
		
	local GmodWikiOneFourthFrame = vgui.Create( "Button", FourthFrame )
        GmodWikiOneFourthFrame:SetSize( 200, 25 )
        GmodWikiOneFourthFrame:SetPos( 1130, 755 )
        GmodWikiOneFourthFrame:SetVisible( true )
        GmodWikiOneFourthFrame:SetText( "Gmod Wiki #1" )
		GmodWikiOneFourthFrame.Paint = function()
			surface.SetDrawColor( 218, 229, 2, 200 )
			surface.DrawRect( 0, 4, GmodWikiOneFourthFrame:GetWide(), GmodWikiOneFourthFrame:GetTall() )
		end
        function GmodWikiOneFourthFrame:OnMousePressed()
			MainFrame:SetVisible( false )
			SecondFrame:SetVisible( false )
			FifthFrame:SetVisible( false )
			FourthFrame:SetVisible( false )
			ThirdFrame:SetVisible( true )
        end

	local GmodWikiOneFifthFrame = vgui.Create( "Button", FifthFrame )
        GmodWikiOneFifthFrame:SetSize( 200, 25 )
        GmodWikiOneFifthFrame:SetPos( 1130, 755 )
        GmodWikiOneFifthFrame:SetVisible( true )
        GmodWikiOneFifthFrame:SetText( "Gmod Wiki #1" )
		GmodWikiOneFifthFrame.Paint = function()
			surface.SetDrawColor( 218, 229, 2, 200 )
			surface.DrawRect( 0, 4, GmodWikiOneFifthFrame:GetWide(), GmodWikiOneFifthFrame:GetTall() )
		end
        function GmodWikiOneFifthFrame:OnMousePressed()
			MainFrame:SetVisible( false )
			SecondFrame:SetVisible( false )
			FourthFrame:SetVisible( false )
			FifthFrame:SetVisible( false )
			ThirdFrame:SetVisible( true )
        end
		
	local GmodWikiOneSixthFrame = vgui.Create( "Button", SixthFrame )
        GmodWikiOneSixthFrame:SetSize( 200, 25 )
        GmodWikiOneSixthFrame:SetPos( 1130, 755 )
        GmodWikiOneSixthFrame:SetVisible( true )
        GmodWikiOneSixthFrame:SetText( "Gmod Wiki #1" )
		GmodWikiOneSixthFrame.Paint = function()
			surface.SetDrawColor( 218, 229, 2, 200 )
			surface.DrawRect( 0, 4, GmodWikiOneSixthFrame:GetWide(), GmodWikiOneSixthFrame:GetTall() )
		end
        function GmodWikiOneSixthFrame:OnMousePressed()
			MainFrame:SetVisible( false )
			SecondFrame:SetVisible( false )
			FourthFrame:SetVisible( false )
			FifthFrame:SetVisible( false )
			SixthFrame:SetVisible( false )
			ThirdFrame:SetVisible( true )
        end
		
		// Gmod Wiki 2 Buttons \\
		
	local GmodWikiTwoButtonMainFrame = vgui.Create( "Button", MainFrame )
        GmodWikiTwoButtonMainFrame:SetSize( 200, 25 )
        GmodWikiTwoButtonMainFrame:SetPos( 1130, 785 )
        GmodWikiTwoButtonMainFrame:SetVisible( true )
        GmodWikiTwoButtonMainFrame:SetText( "Gmod Wiki #2" )
		GmodWikiTwoButtonMainFrame.Paint = function()
			surface.SetDrawColor( 25, 25, 25, 255 )
			surface.DrawRect( 0, 4, GmodWikiTwoButtonMainFrame:GetWide(), GmodWikiTwoButtonMainFrame:GetTall() )
		end
        function GmodWikiTwoButtonMainFrame:OnMousePressed()
			MainFrame:SetVisible( false )
			SecondFrame:SetVisible( false )
			ThirdFrame:SetVisible( false )
			FifthFrame:SetVisible( false  )
			FourthFrame:SetVisible( true )
        end
		
	local GmodWikiTwoButtonSecondFrame = vgui.Create( "Button", SecondFrame )
        GmodWikiTwoButtonSecondFrame:SetSize( 200, 25 )
        GmodWikiTwoButtonSecondFrame:SetPos( 1130, 785 )
        GmodWikiTwoButtonSecondFrame:SetVisible( true )
        GmodWikiTwoButtonSecondFrame:SetText( "Gmod Wiki #2" )
		GmodWikiTwoButtonSecondFrame.Paint = function()
			surface.SetDrawColor( 218, 229, 2, 200 )
			surface.DrawRect( 0, 4, GmodWikiTwoButtonSecondFrame:GetWide(), GmodWikiTwoButtonSecondFrame:GetTall() )
		end
        function GmodWikiTwoButtonSecondFrame:OnMousePressed()
			MainFrame:SetVisible( false )
			SecondFrame:SetVisible( false )
			ThirdFrame:SetVisible( false )
			FifthFrame:SetVisible( false )
			FourthFrame:SetVisible( true )
        end
		
	local GmodWikiTwoButtonThirdFrame = vgui.Create( "Button", ThirdFrame )
        GmodWikiTwoButtonThirdFrame:SetSize( 200, 25 )
        GmodWikiTwoButtonThirdFrame:SetPos( 1130, 785 )
        GmodWikiTwoButtonThirdFrame:SetVisible( true )
        GmodWikiTwoButtonThirdFrame:SetText( "Gmod Wiki #2" )
		GmodWikiTwoButtonThirdFrame.Paint = function()
			surface.SetDrawColor( 218, 229, 2, 200 )
			surface.DrawRect( 0, 4, GmodWikiTwoButtonThirdFrame:GetWide(), GmodWikiTwoButtonThirdFrame:GetTall() )
		end
        function GmodWikiTwoButtonThirdFrame:OnMousePressed()
			MainFrame:SetVisible( false )
			SecondFrame:SetVisible( false )
			ThirdFrame:SetVisible( false )
			FifthFrame:SetVisible( false )
			FourthFrame:SetVisible( true )
        end
		
	local GmodWikiTwoButtonFourthFrame = vgui.Create( "Button", FourthFrame )
        GmodWikiTwoButtonFourthFrame:SetSize( 200, 25 )
        GmodWikiTwoButtonFourthFrame:SetPos( 1130, 785 )
        GmodWikiTwoButtonFourthFrame:SetVisible( true )
        GmodWikiTwoButtonFourthFrame:SetText( "Gmod Wiki #2" )
		GmodWikiTwoButtonFourthFrame.Paint = function()
			surface.SetDrawColor( 218, 229, 2, 200 )
			surface.DrawRect( 0, 4, GmodWikiTwoButtonFourthFrame:GetWide(), GmodWikiTwoButtonFourthFrame:GetTall() )
		end
        function GmodWikiTwoButtonFourthFrame:OnMousePressed()
			MainFrame:SetVisible( false )
			SecondFrame:SetVisible( false )
			ThirdFrame:SetVisible( false )
			FifthFrame:SetVisible( false )
			FourthFrame:SetVisible( true )
        end
		
	local GmodWikiTwoButtonFifthFrame = vgui.Create( "Button", FifthFrame )
        GmodWikiTwoButtonFifthFrame:SetSize( 200, 25 )
        GmodWikiTwoButtonFifthFrame:SetPos( 1130, 785 )
        GmodWikiTwoButtonFifthFrame:SetVisible( true )
        GmodWikiTwoButtonFifthFrame:SetText( "Gmod Wiki #2" )
		GmodWikiTwoButtonFifthFrame.Paint = function()
			surface.SetDrawColor( 218, 229, 2, 200 )
			surface.DrawRect( 0, 4, GmodWikiTwoButtonFifthFrame:GetWide(), GmodWikiTwoButtonFifthFrame:GetTall() )
		end
        function GmodWikiTwoButtonFifthFrame:OnMousePressed()
			MainFrame:SetVisible( false )
			SecondFrame:SetVisible( false )
			ThirdFrame:SetVisible( false )
			FifthFrame:SetVisible( false )
			FourthFrame:SetVisible( true )
        end
		
	local GmodWikiTwoButtonSixthFrame = vgui.Create( "Button", SixthFrame )
        GmodWikiTwoButtonSixthFrame:SetSize( 200, 25 )
        GmodWikiTwoButtonSixthFrame:SetPos( 1130, 785 )
        GmodWikiTwoButtonSixthFrame:SetVisible( true )
        GmodWikiTwoButtonSixthFrame:SetText( "Gmod Wiki #2" )
		GmodWikiTwoButtonSixthFrame.Paint = function()
			surface.SetDrawColor( 218, 229, 2, 200 )
			surface.DrawRect( 0, 4, GmodWikiTwoButtonSixthFrame:GetWide(), GmodWikiTwoButtonSixthFrame:GetTall() )
		end
        function GmodWikiTwoButtonSixthFrame:OnMousePressed()
			MainFrame:SetVisible( false )
			SecondFrame:SetVisible( false )
			ThirdFrame:SetVisible( false )
			SixthFrame:SetVisible( false )
			FifthFrame:SetVisible( false )
			FourthFrame:SetVisible( true )
        end
		
		// Google Buttons \\
		

		// Youtube Buttons \\
		
	local YoutubeButtonMainFrame = vgui.Create( "Button", MainFrame )
        YoutubeButtonMainFrame:SetSize( 200, 25 )
        YoutubeButtonMainFrame:SetPos( 485, 785 )
        YoutubeButtonMainFrame:SetVisible( true )
        YoutubeButtonMainFrame:SetText( "Youtube" )
		YoutubeButtonMainFrame.Paint = function()
			surface.SetDrawColor( 25, 25, 25, 255 )
			surface.DrawRect( 0, 4, YoutubeButtonMainFrame:GetWide(), YoutubeButtonMainFrame:GetTall() )
		end
        function YoutubeButtonMainFrame:OnMousePressed()
			MainFrame:SetVisible( false )
			SecondFrame:SetVisible( false )
			ThirdFrame:SetVisible( false )
			FourthFrame:SetVisible( false )
			FifthFrame:SetVisible( false )
			SixthFrame:SetVisible( true )
        end

	local YoutubeButtonSecondFrame = vgui.Create( "Button", SecondFrame )
        YoutubeButtonSecondFrame:SetSize( 200, 25 )
        YoutubeButtonSecondFrame:SetPos( 485, 785 )
        YoutubeButtonSecondFrame:SetVisible( true )
        YoutubeButtonSecondFrame:SetText( "Youtube" )
		YoutubeButtonSecondFrame.Paint = function()
			surface.SetDrawColor( 218, 229, 2, 200 )
			surface.DrawRect( 0, 4, YoutubeButtonSecondFrame:GetWide(), YoutubeButtonSecondFrame:GetTall() )
		end
        function YoutubeButtonSecondFrame:OnMousePressed()
			MainFrame:SetVisible( false )
			SecondFrame:SetVisible( false )
			ThirdFrame:SetVisible( false )
			FourthFrame:SetVisible( false )
			FifthFrame:SetVisible( false )
			SixthFrame:SetVisible( true )
        end
				
	local YoutubeButtonThirdFrame = vgui.Create( "Button", ThirdFrame )
        YoutubeButtonThirdFrame:SetSize( 200, 25 )
        YoutubeButtonThirdFrame:SetPos( 485, 785 )
        YoutubeButtonThirdFrame:SetVisible( true )
        YoutubeButtonThirdFrame:SetText( "Youtube" )
		YoutubeButtonThirdFrame.Paint = function()
			surface.SetDrawColor( 218, 229, 2, 200 )
			surface.DrawRect( 0, 4, YoutubeButtonThirdFrame:GetWide(), YoutubeButtonThirdFrame:GetTall() )
		end
        function YoutubeButtonThirdFrame:OnMousePressed()
			MainFrame:SetVisible( false )
			SecondFrame:SetVisible( false )
			ThirdFrame:SetVisible( false )
			FourthFrame:SetVisible( false )
			FifthFrame:SetVisible( false )
			SixthFrame:SetVisible( true )
        end
		
	local YoutubeButtonFourthFrame = vgui.Create( "Button", FourthFrame )
        YoutubeButtonFourthFrame:SetSize( 200, 25 )
        YoutubeButtonFourthFrame:SetPos( 485, 785 )
        YoutubeButtonFourthFrame:SetVisible( true )
        YoutubeButtonFourthFrame:SetText( "Youtube" )
		YoutubeButtonFourthFrame.Paint = function()
			surface.SetDrawColor( 218, 229, 2, 200 )
			surface.DrawRect( 0, 4, YoutubeButtonFourthFrame:GetWide(), YoutubeButtonFourthFrame:GetTall() )
		end
        function YoutubeButtonFourthFrame:OnMousePressed()
			MainFrame:SetVisible( false )
			SecondFrame:SetVisible( false )
			ThirdFrame:SetVisible( false )
			FourthFrame:SetVisible( false )
			FifthFrame:SetVisible( false )
			SixthFrame:SetVisible( true )
        end
		
	local YoutubeButtonFifthFrame = vgui.Create( "Button", FifthFrame )
        YoutubeButtonFifthFrame:SetSize( 200, 25 )
        YoutubeButtonFifthFrame:SetPos( 485, 785 )
        YoutubeButtonFifthFrame:SetVisible( true )
        YoutubeButtonFifthFrame:SetText( "Youtube" )
		YoutubeButtonFifthFrame.Paint = function()
			surface.SetDrawColor( 218, 229, 2, 200 )
			surface.DrawRect( 0, 4, YoutubeButtonFifthFrame:GetWide(), YoutubeButtonFifthFrame:GetTall() )
		end
        function YoutubeButtonFifthFrame:OnMousePressed()
			MainFrame:SetVisible( false )
			SecondFrame:SetVisible( false )
			ThirdFrame:SetVisible( false )
			FourthFrame:SetVisible( false )
			FifthFrame:SetVisible( false )
			SixthFrame:SetVisible( true )
        end
				
	local YoutubeButtonSixthFrame = vgui.Create( "Button", SixthFrame )
        YoutubeButtonSixthFrame:SetSize( 200, 25 )
        YoutubeButtonSixthFrame:SetPos( 485, 785 )
        YoutubeButtonSixthFrame:SetVisible( true )
        YoutubeButtonSixthFrame:SetText( "Youtube" )
		YoutubeButtonSixthFrame.Paint = function()
			surface.SetDrawColor( 218, 229, 2, 200 )
			surface.DrawRect( 0, 4, YoutubeButtonSixthFrame:GetWide(), YoutubeButtonSixthFrame:GetTall() )
		end
        function YoutubeButtonSixthFrame:OnMousePressed()
			MainFrame:SetVisible( false )
			SecondFrame:SetVisible( false )
			ThirdFrame:SetVisible( false )
			FourthFrame:SetVisible( false )
			FifthFrame:SetVisible( false )
			SixthFrame:SetVisible( true )
        end
		
		// Main Menu Stuff \\
		local ESPText = vgui.Create( "DLabel", MainFrame )
		ESPText:SetPos( 70, 60 )
		ESPText:SetText( "ESP Toggles" )
		ESPText:SetFont("MenuItem")
		ESPText:SetColor(Color(255,255,255,255)) // Color
		ESPText:SizeToContents()

		local XrayText = vgui.Create( "DLabel", MainFrame )
		XrayText:SetPos( 300, 60 )
		XrayText:SetText( "Xray Toggles" )
		XrayText:SetFont("MenuItem")
		XrayText:SetColor(Color(255,255,255,255)) // Color
		XrayText:SizeToContents()
		
		// ESP Toggles
	local ESPActiveCheckBoxMainFrame = vgui.Create( "DCheckBoxLabel", MainFrame )
		ESPActiveCheckBoxMainFrame:SetPos( 71, 90 )
		ESPActiveCheckBoxMainFrame:SetText( "ESP Active" )
		ESPActiveCheckBoxMainFrame:SetConVar( "B-Hacks_ESP_Active" )
		ESPActiveCheckBoxMainFrame:SizeToContents()
		
	local ESPNickNameCheckBoxMainFrame = vgui.Create( "DCheckBoxLabel", MainFrame )
		ESPNickNameCheckBoxMainFrame:SetPos( 100, 115 )
		ESPNickNameCheckBoxMainFrame:SetText( "Show Name" )
		ESPNickNameCheckBoxMainFrame:SetConVar( "B-Hacks_ESP_ShowNick" )
		ESPNickNameCheckBoxMainFrame:SizeToContents()
		
	local ESPShowHealthCheckBoxMainFrame = vgui.Create( "DCheckBoxLabel", MainFrame )
		ESPShowHealthCheckBoxMainFrame:SetPos( 100, 135 )
		ESPShowHealthCheckBoxMainFrame:SetText( "Show Health" )
		ESPShowHealthCheckBoxMainFrame:SetConVar( "B-Hacks_ESP_ShowHealth" )
		ESPShowHealthCheckBoxMainFrame:SizeToContents()
		
	local ESPShowArmorCheckBoxMainFrame = vgui.Create( "DCheckBoxLabel", MainFrame )
		ESPShowArmorCheckBoxMainFrame:SetPos( 100, 155 )
		ESPShowArmorCheckBoxMainFrame:SetText( "Show Armor" )
		ESPShowArmorCheckBoxMainFrame:SetConVar( "B-Hacks_ESP_ShowArmor" )
		ESPShowArmorCheckBoxMainFrame:SizeToContents()
		
	local ESPShowFriendsCheckBoxMainFrame = vgui.Create( "DCheckBoxLabel", MainFrame )
		ESPShowFriendsCheckBoxMainFrame:SetPos( 100, 175 )
		ESPShowFriendsCheckBoxMainFrame:SetText( "Show Friends" )
		ESPShowFriendsCheckBoxMainFrame:SetConVar( "B-Hacks_ESP_ShowFriend" )
		ESPShowFriendsCheckBoxMainFrame:SizeToContents()
		
	local ESPShowRankCheckBoxMainFrame = vgui.Create( "DCheckBoxLabel", MainFrame )
		ESPShowRankCheckBoxMainFrame:SetPos( 100, 195 )
		ESPShowRankCheckBoxMainFrame:SetText( "Show Ranks" )
		ESPShowRankCheckBoxMainFrame:SetConVar( "B-Hacks_ESP_ShowRank" )
		ESPShowRankCheckBoxMainFrame:SizeToContents()
		
		// Xray Toggles
	local XrayActiveCheckBoxMainFrame = vgui.Create( "DCheckBoxLabel", MainFrame )
		XrayActiveCheckBoxMainFrame:SetPos( 299, 90 )
		XrayActiveCheckBoxMainFrame:SetText( "Xray Active" )
		XrayActiveCheckBoxMainFrame:SetConVar( "B-Hacks_Xray_Active" )
		XrayActiveCheckBoxMainFrame:SizeToContents()

	local XrayPropsCheckBoxMainFrame = vgui.Create( "DCheckBoxLabel", MainFrame )
		XrayPropsCheckBoxMainFrame:SetPos( 326, 115 )
		XrayPropsCheckBoxMainFrame:SetText( "Xray Players" )
		XrayPropsCheckBoxMainFrame:SetConVar( "B-Hacks_Xray_Players" )
		XrayPropsCheckBoxMainFrame:SizeToContents()
		
	local XrayDoorsCheckBoxMainFrame = vgui.Create( "DCheckBoxLabel", MainFrame )
		XrayDoorsCheckBoxMainFrame:SetPos( 326, 135 )
		XrayDoorsCheckBoxMainFrame:SetText( "Xray Props" )
		XrayDoorsCheckBoxMainFrame:SetConVar( "B-Hacks_Xray_Props" )
		XrayDoorsCheckBoxMainFrame:SizeToContents()
		
	local XrayPlayersCheckBoxMainFrame = vgui.Create( "DCheckBoxLabel", MainFrame )
		XrayPlayersCheckBoxMainFrame:SetPos( 326, 155 )
		XrayPlayersCheckBoxMainFrame:SetText( "Xray Doors" )
		XrayPlayersCheckBoxMainFrame:SetConVar( "B-Hacks_Xray_Doors" )
		XrayPlayersCheckBoxMainFrame:SizeToContents()
		
		// Player Stats
	local PlayerStats = vgui.Create("DListView", SecondFrame)
		PlayerStats:SetSize(1640, 695)
		PlayerStats:SetPos(130, 45)
		PlayerStats:SetMultiSelect(false)
		PlayerStats:AddColumn("Name")
		PlayerStats:AddColumn("SteamID")
		PlayerStats:AddColumn("Money")
		PlayerStats:AddColumn("Health")
		PlayerStats:AddColumn("Friend")
		PlayerStats:AddColumn("Is Admin")
		PlayerStats:AddColumn("Is SuperAdmin")
		PlayerStats.Paint = function()
			surface.SetDrawColor( 120, 120, 120, 250 )
			surface.DrawRect( 0, 0, PlayerStats:GetWide(), PlayerStats:GetTall() )
		end

	for k,v in pairs(player.GetAll()) do
		money = "" or v.DarkRPVars.money
		PlayerStats:AddLine(v:Nick(), v:SteamID(), money, v:Health(), v:GetFriendStatus(), v:IsAdmin(), v:IsSuperAdmin()) -- Add lines
	end
	
	GmodWikiOne = vgui.Create( "HTML", ThirdFrame )
	GmodWikiOne:SetPos( 130,45 )
	GmodWikiOne:SetSize( 1640, 695 )
	GmodWikiOne:OpenURL( "http://wiki.garrysmod.com" )
	
	GmodWikiTwo = vgui.Create( "HTML", FourthFrame )
	GmodWikiTwo:SetPos( 130,45 )
	GmodWikiTwo:SetSize( 1640, 695 )
	GmodWikiTwo:OpenURL( "http://maurits.tv/data/garrysmod/wiki/wiki.garrysmod.com/index4875.html" )
	
	Google = vgui.Create( "HTML", FifthFrame )
	Google:SetPos( 130,45 )
	Google:SetSize( 1640, 695 )
	Google:OpenURL( "http://Google.com" )
	
	Youtube = vgui.Create( "HTML", SixthFrame )
	Youtube:SetPos( 130,45 )
	Youtube:SetSize( 1640, 695 )
	Youtube:OpenURL( "http://Youtube.com" )
end

function OpenMainMenu()
MainFrame:SetVisible(true)
end
concommand.Add("OpenMainMenu", OpenMainMenu)

concommand.Add("MainMenu", MainMenu)

 function Show()
 MainFrame:SetVisible(true)
 end
 concommand.Add("Show", Show)

function CloseHTML()
SixthFrame:SetVisible(true)
end
concommand.Add("Dev_CloseHTML", CloseHTML)