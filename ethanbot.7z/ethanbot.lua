--[[
	lua/eb_mu.lua
	EthanTheGreat | (STEAM_0:1:8343226)
	Date: 14/5/2012 - 17:39:49
]]

local scrW, scrH = ScrW( ), ScrH( )
local scrCW, scrCH = ( ScrW( ) / 2 ), ( ScrH( ) / 2 )

local function rotatePos( Xpos, Ypos, angle )
	if ( !Xpos or !Ypos or !angle ) then return end
	
	local angle = math.rad( angle )
	local newX = (( math.cos( angle ) * Xpos ) - ( math.sin( angle ) * Ypos ))
	local newY = (( math.cos( angle ) * Ypos ) + ( math.sin( angle ) * Xpos ))
	
	return { x = newX, y = newY }
end

function MergeTable( table_ONE, table_TWO )
	if type( table_ONE ) != "table" then return end
	if type( table_TWO ) != "table" then return end

	for k, v in pairs( table_TWO ) do
		table.insert( table_ONE, v )
	end
end




local EthanBot = { }

-- AIMBOT --
	local EBAimbot = { }
		EBAimbot.IsAimbotEnabled = false
		EBAimbot.KeepTargetingEnabled = false
		EBAimbot.TargetUsingLOS = true
		EBAimbot.TargetOpposingTeams = false
		EBAimbot.TargetNPCs = false
		EBAimbot.TargetEntities = { Enabled = false, TargetTable = { } }
		EBAimbot.AvoidTargetingSteamFriends = false
		EBAimbot.AutoShoot = { Enabled = true, AttackDeToggle = true }
		EBAimbot.AntiSnap = { Enabled = false, Value = 3 }
		EBAimbot.FieldOfView = { Enabled = true, Value = 300 }
		EBAimbot.BoneNumSelection = 1
		EBAimbot.BoneList = {
			{ PrintName = "Head", BoneName = "ValveBiped.Bip01_Head1", DiagramPos = { x = ( scrH * 0.4 ), y = ( scrH * 0.05 ) }},
			{ PrintName = "Neck", BoneName = "ValveBiped.Bip01_Neck1", DiagramPos = { x = ( scrH * 0.4 ), y = ( scrH * 0.125 ) }},
			{ PrintName = "Spine_001", BoneName = "ValveBiped.Bip01_Spine4", DiagramPos = { x = ( scrH * 0.4 ), y = ( scrH * 0.15 ) }},
			{ PrintName = "Spine_002", BoneName = "ValveBiped.Bip01_Spine2", DiagramPos = { x = ( scrH * 0.4 ), y = ( scrH * 0.2 ) }},
			{ PrintName = "Spine_003", BoneName = "ValveBiped.Bip01_Spine1", DiagramPos = { x = ( scrH * 0.4 ), y = ( scrH * 0.25 ) }},
			{ PrintName = "Spine_004", BoneName = "ValveBiped.Bip01_Spine", DiagramPos = { x = ( scrH * 0.4 ), y = ( scrH * 0.35 ) }},
			{ PrintName = "Pelvis", BoneName = "ValveBiped.Bip01_Pelvis", DiagramPos = { x = ( scrH * 0.4 ), y = ( scrH * 0.4 ) }}
		}
		EBAimbot.WhiteListPlayers = { Blacklist = false, Table = { } }
	local EBEsp = { }
		EBEsp.WallhackEnabled = true
		EBEsp.Wallchams = { Enabled = true, SelectedMat = 1, Materials = {
			CreateMaterial( "eb_chams_debug", "UnlitGeneric", { ["$basetexture"] = "models/debug/debugwhite", ["$ignorez"] = 1, ["$model"] = 1 } ),
			CreateMaterial( "eb_chams_wareframe", "Wireframe", { ["$basetexture"] = "models/wireframe", ["$ignorez"] = 1, ["$model"] = 1 } )
		} }
		EBEsp.CrosshairEnabled = true
		EBEsp.EyeLasersEnabled = false
		EBEsp.ESPEntities = { Enabled = true, Table = { } }
	local EBUflScpts = { }
		EBUflScpts.NoSpreadAndNoRecoil = { Enabled = true, Table = { } }
		EBUflScpts.MuteCurrentWeaponSound = { Enabled = false, WeaponSounds = { } }
		EBUflScpts.DisableDataStreams = false
		EBUflScpts.DisableConsoleCommands = false
--	
-- DERMA --
	local EBDerma = { }
		EBDerma.CurrentSelection = false
		EBDerma.SelectionTabButtons = { } 
		EBDerma.SelectionTabPanels = { }
			EBDerma.AimbotPanelContents = { }
			EBDerma.ESPPanelContents = { }
			EBDerma.UsefulScriptsPanelContents = { }
--
-- STORED SETTINGS --
	if file.Exists( "EthanBot/settings.txt" ) then
		local storedData = glon.decode( file.Read( "EthanBot/settings.txt" ))
		
		EBAimbot = storedData[1]
			EBAimbot.TargetEntities.Table = { }
			EBAimbot.WhiteListPlayers.Table = { }
		EBEsp = storedData[2]
			EBEsp.Wallchams = { Enabled = true, SelectedMat = 1, Materials = {
				CreateMaterial( "eb_chams_debug", "UnlitGeneric", { ["$basetexture"] = "models/debug/debugwhite", ["$ignorez"] = 1, ["$model"] = 1 } ),
				CreateMaterial( "eb_chams_wareframe", "Wireframe", { ["$basetexture"] = "models/wireframe", ["$ignorez"] = 1, ["$model"] = 1 } )
			} }
			EBEsp.ESPEntities.Table = { }
		EBUflScpts = storedData[3]
			EBUflScpts.NoSpreadAndNoRecoil.Table = { }
			EBUflScpts.MuteCurrentWeaponSound.WeaponSounds = { }
			
		print( "[EBOT]: Your settings have been loaded!" )
	else
		file.Write( "EthanBot/settings.txt", glon.encode( { EBAimbot, EBEsp, EBUflScpts } ))
		
		print( "[EBOT]: This must be your first time using Ethan-Bot, good luck and remember to check your dua!" )
	end
--	
-- AIMBOT FUNCTIONS/HOOKS --
	function EBAimbot.GetAimTargetPos( target )
		if ( !target or !ValidEntity( target )) then return ( LocalPlayer( ):GetPos( ) + ( LocalPlayer( ):EyeAngles( ):Forward( ) * 1000 )) end
		
		return ( target:GetBonePosition( target:LookupBone( EBAimbot.BoneList[EBAimbot.BoneNumSelection].BoneName )) or target:GetPos( ))
	end
		
	function EBAimbot.GetBestTarget( targetTable )
		local bestTargetData = { false, false }
		
		for _, target in pairs( targetTable ) do
			if ValidEntity( target ) then
				local distanceCHtoTarget = math.Distance( EBAimbot.GetAimTargetPos( target ):ToScreen( ).x, EBAimbot.GetAimTargetPos( target ):ToScreen( ).y, scrCW, scrCH )
				local skipTarget = false
				local traceDataReturn = util.TraceLine( {
					start = LocalPlayer( ):GetShootPos( ),
					endpos = EBAimbot.GetAimTargetPos( target ),
					filter = { LocalPlayer( ), target },
					mask = 1174421507
				} )
					
				if target:IsPlayer( ) and target:GetObserverMode( ) != 0 then skipTarget = true end
					
				if EBAimbot.TargetOpposingTeams and target:IsPlayer( ) and target:Team( ) == LocalPlayer( ):Team( ) then skipTarget = true end
				if EBAimbot.TargetUsingLOS and traceDataReturn.Hit then skipTarget = true end
				if EBAimbot.TargetUsingLOS then if target:IsPlayer( ) and target:GetVehicle( ) != traceDataReturn.Entity then skipTarget = true end end
				if EBAimbot.AvoidTargetingSteamFriends and target:IsPlayer( ) and target:GetFriendStatus( ) == "friend" then skipTarget = true end
					
				if ( !target or !ValidEntity( target )) then skipTarget = true end
				if target:Health( ) < 0 then skipTarget = true end
				if target:IsPlayer( ) and !target:Alive( ) then skipTarget = true end
				if !ValidEntity( target ) or !target:IsValid( ) then skipTarget = true end
				
				if !EBAimbot.WhiteListPlayers.Blacklist then
					for steamID, _ in pairs( EBAimbot.WhiteListPlayers.Table ) do if target:IsPlayer( ) and steamID == target:SteamID( ) then skipTarget = true end end
				end
				
				
				if !skipTarget and LocalPlayer( ) != target then
					if ( distanceCHtoTarget < EBAimbot.FieldOfView.Value or !EBAimbot.FieldOfView.Enabled ) then
						if bestTargetData[1] == false then
							bestTargetData = { distanceCHtoTarget, target }
						elseif bestTargetData[1] > distanceCHtoTarget then
							bestTargetData = { distanceCHtoTarget, target }
						end
					end
				end
			end
		end
		
		return bestTargetData[2]
	end
	function EBAimbot.ThinkHook( )
		if input.IsMouseDown( MOUSE_MIDDLE ) and !input.IsKeyDown( 74 ) and !EBAimbot.IsAimbotEnabled then EBAimbot.IsAimbotEnabled = true elseif EBAimbot.IsAimbotEnabled then EBAimbot.IsAimbotEnabled = false end
	
		local targetTable = player.GetAll( )
			if EBAimbot.WhiteListPlayers.Blacklist then targetTable = EBAimbot.WhiteListPlayers.Table end
			if EBAimbot.TargetNPCs then MergeTable( targetTable, ents.FindByClass( "npc*" )) end
			if EBAimbot.TargetEntities.Enabled then for entityClass, _ in pairs( EBAimbot.TargetEntities.TargetTable ) do MergeTable( targetTable, ents.FindByClass( entityClass )) end end
			
		if EBAimbot.AutoShoot.Enabled and !EBAimbot.AutoShoot.AttackDeToggle then
			EBAimbot.AutoShoot.AttackDeToggle = true
			RunConsoleCommand( "-ATTACK" )
		end			
		
		if !EBAimbot.GetBestTarget( targetTable ) then return end
		if !EBAimbot.IsAimbotEnabled and !EBAimbot.KeepTargetingEnabled then return end
	
		local target = EBAimbot.GetBestTarget( targetTable )
		
		local AimAngle = ( EBAimbot.GetAimTargetPos( target ) - LocalPlayer( ):GetShootPos( )):Angle( )
			if EBAimbot.AntiSnap.Enabled then
				local CurrentAngle = LocalPlayer( ):EyeAngles( )
				
				AimAngle = Angle( 
					math.ApproachAngle( CurrentAngle.p, AimAngle.p, EBAimbot.AntiSnap.Value ),
					math.ApproachAngle( CurrentAngle.y, AimAngle.y, EBAimbot.AntiSnap.Value ),
					0
				)
			end
		
		LocalPlayer( ):SetEyeAngles( AimAngle )
		
		if EBAimbot.AutoShoot.Enabled and EBAimbot.AutoShoot.AttackDeToggle then
			EBAimbot.AutoShoot.AttackDeToggle = false
			RunConsoleCommand( "+ATTACK" )
		end
			
		
	end; hook.Add( "Think", "EBAimbot.ThinkHook", EBAimbot.ThinkHook );

	function EBAimbot.HUDPaintHook( )
		if ( input.IsMouseDown( MOUSE_MIDDLE ) or EBAimbot.KeepTargetingEnabled or input.IsKeyDown( 74 ) or EBDerma.CurrentSelection == "Aimbot Settings" ) then
			surface.SetDrawColor( 0, 0, 0, 255 )
				for INDEX = 0, 32 do
					local normalizedRotatedPos = rotatePos( EBAimbot.FieldOfView.Value, 0, ( INDEX * 11.25 ))
					local notchAlpha = 255
						if !EBAimbot.FieldOfView.Enabled then notchAlpha = 0 end
					
					surface.SetDrawColor( 0, 0, 0, notchAlpha )
						surface.DrawRect((( normalizedRotatedPos.x + scrCW ) - 3 ), (( normalizedRotatedPos.y + scrCH ) - 3 ), 6, 6 )
					surface.SetDrawColor( 255, 255, 255, notchAlpha )
						surface.DrawRect((( normalizedRotatedPos.x + scrCW ) - 2 ), (( normalizedRotatedPos.y + scrCH ) - 2 ), 4, 4 )
				end
		end
	end; hook.Add( "HUDPaint", "EBAimbot.HUDPaintHook", EBAimbot.HUDPaintHook );
--
-- ESP FUNCTIONS/HOOKS --
	function EBEsp.HUDPaintHook( )
		if EBEsp.ESPEntities.Enabled then
			local ESPEntitesTable = { }
				if table.Count( EBEsp.ESPEntities.Table ) > 0 then
					for entityClass, _ in pairs( EBEsp.ESPEntities.Table ) do MergeTable( ESPEntitesTable, ents.FindByClass( entityClass )) end
				end
				
			for _, entity in pairs( ESPEntitesTable ) do
				cam.Start3D( EyePos( ), EyeAngles( ))
					SetMaterialOverride( EBEsp.Wallchams.Materials[EBEsp.Wallchams.SelectedMat] )
							render.SetColorModulation( 1, 1, 1 )
								entity:DrawModel( )
							render.SetColorModulation( 1, 1, 1 )
					SetMaterialOverride( 0 )
				cam.End3D( )
				
				entity:SetColor( Color( 255, 255, 255, 255 ))
				
				local textPosition = entity:GetPos( ):ToScreen( )
				local textString = entity:GetClass( )
				
				surface.SetTextColor( 255, 255, 255, 255 )
					surface.SetFont( "ConsoleText" )
						local textWidth, _ = surface.GetTextSize( textString );
							surface.SetTextPos(( textPosition.x - ( textWidth * 0.5 )), textPosition.y ); surface.DrawText( textString );
			end
		end
		
		for _, npc in pairs( ents.FindByClass( "npc*" )) do
			if EBEsp.Wallchams.Enabled and npc:Health( ) >= 0 then
				cam.Start3D( EyePos( ), EyeAngles( ))
					SetMaterialOverride( EBEsp.Wallchams.Materials[EBEsp.Wallchams.SelectedMat] )
							render.SetColorModulation( 1, 1, 1 )
								npc:DrawModel( )
							render.SetColorModulation( 1, 1, 1 )
					SetMaterialOverride( 0 )
				cam.End3D( )
				
				npc:SetColor( Color( 255, 255, 255, 255 ))
			end
		end
		for _, ply in pairs( player.GetAll( )) do
			if ply != LocalPlayer( ) then
				local teamColor = team.GetColor( ply:Team( ))
			
				if EBEsp.EyeLasersEnabled and ply:GetObserverMode( ) == 0 and ply:Alive( ) then
					cam.Start3D( EyePos( ), EyeAngles( ))
						render.SetMaterial( Material( "cable/redlaser" ))
						render.DrawBeam( ply:GetBonePosition( ply:LookupBone( "ValveBiped.Bip01_Head1" )), util.TraceLine( util.GetPlayerTrace( ply )).HitPos, 5, 1, 1, Color( 255, 255, 255, 255 ))
					cam.End3D( )
				end
			
				if EBEsp.WallhackEnabled then
					local textPosition = ply:GetPos( ):ToScreen( )
					local textString = ply:Nick( )
					
					surface.SetTextColor( teamColor.r, teamColor.g, teamColor.b, 255 )
						surface.SetFont( "ConsoleText" )
							local textWidth, _ = surface.GetTextSize( textString );
								surface.SetTextPos(( textPosition.x - ( textWidth * 0.5 )), textPosition.y ); surface.DrawText( textString );
				end
				
				if EBEsp.Wallchams.Enabled and ply:GetObserverMode( ) == 0 and ply:Alive( ) then
					cam.Start3D( EyePos( ), EyeAngles( ))
						SetMaterialOverride( EBEsp.Wallchams.Materials[EBEsp.Wallchams.SelectedMat] )
							render.SetColorModulation(( teamColor.r / 255 ), ( teamColor.g / 255 ), ( teamColor.b / 255 ))
								ply:DrawModel( )
							render.SetColorModulation( 1, 1, 1 )
						SetMaterialOverride( 0 )
					cam.End3D( )
				end
			end
			
			if EBEsp.CrosshairEnabled then
				surface.SetDrawColor( 255, 255, 255, 255 )
					surface.DrawLine((( scrW / 2 ) - 10 ), ( scrH / 2 ), (( scrW / 2 ) + 10), ( scrH / 2 ))
					surface.DrawLine(( scrW / 2 ), (( scrH / 2 ) - 10 ), ( scrW / 2 ), (( scrH / 2 ) + 10 ))
			end
		end
	end; hook.Add( "HUDPaint", "EBEsp.HUDPaintHook", EBEsp.HUDPaintHook );

-- USEFUL SCRIPTS FUNCTIONS/HOOKS --
	function EBUflScpts.ThinkHook( )
		local ActiveWeapon = LocalPlayer( ):GetActiveWeapon( )

		if !EBUflScpts.NoSpreadAndNoRecoil.Enabled and EBUflScpts.NoSpreadAndNoRecoil.Table[ActiveWeapon:GetClass( )] then
			local weaponData = EBUflScpts.NoSpreadAndNoRecoil.Table[ActiveWeapon:GetClass( )]
		
			LocalPlayer( ):GetActiveWeapon( ).Recoil = weaponData[1]; LocalPlayer( ):GetActiveWeapon( ).Primary.Recoil = weaponData[2];
			LocalPlayer( ):GetActiveWeapon( ).Spread = weaponData[3]; LocalPlayer( ):GetActiveWeapon( ).Primary.Spread = weaponData[4];
			LocalPlayer( ):GetActiveWeapon( ).Cone = weaponData[5]; LocalPlayer( ):GetActiveWeapon( ).Primary.Cone = weaponData[6];
			
			EBUflScpts.NoSpreadAndNoRecoil.Table[ActiveWeapon:GetClass( )] = nil
		elseif EBUflScpts.NoSpreadAndNoRecoil.Enabled and LocalPlayer( ):GetActiveWeapon( ).Primary then
			EBUflScpts.NoSpreadAndNoRecoil.Table[ActiveWeapon:GetClass( )] = {
				ActiveWeapon.Recoil, ActiveWeapon.Primary.Recoil,
				ActiveWeapon.Spread, ActiveWeapon.Primary.Spread,
				ActiveWeapon.Cone, ActiveWeapon.Primary.Cone
			}
			
			LocalPlayer( ):GetActiveWeapon( ).Recoil = 0; LocalPlayer( ):GetActiveWeapon( ).Primary.Recoil = 0;
			LocalPlayer( ):GetActiveWeapon( ).Spread = 0; LocalPlayer( ):GetActiveWeapon( ).Primary.Spread = 0;
			LocalPlayer( ):GetActiveWeapon( ).Cone = 0; LocalPlayer( ):GetActiveWeapon( ).Primary.Cone = 0;
		end
		
		if LocalPlayer( ):GetActiveWeapon( ).Primary and LocalPlayer( ):GetActiveWeapon( ).Primary.Sound then
			if EBUflScpts.MuteCurrentWeaponSound.Enabled and !EBUflScpts.MuteCurrentWeaponSound.WeaponSounds[ActiveWeapon:GetClass( )] then
				EBUflScpts.MuteCurrentWeaponSound.WeaponSounds[ActiveWeapon:GetClass( )] = LocalPlayer( ):GetActiveWeapon( ).Primary.Sound
				
				LocalPlayer( ):GetActiveWeapon( ).Primary.Sound = ""
			elseif !EBUflScpts.MuteCurrentWeaponSound.Enabled and EBUflScpts.MuteCurrentWeaponSound.WeaponSounds[ActiveWeapon:GetClass( )] then
				LocalPlayer( ):GetActiveWeapon( ).Primary.Sound = EBUflScpts.MuteCurrentWeaponSound.WeaponSounds[ActiveWeapon:GetClass( )]
				
				EBUflScpts.MuteCurrentWeaponSound.WeaponSounds[ActiveWeapon:GetClass( )] = nil
			end
		end
	end; hook.Add( "Think", "EBUflScpts.ThinkHook", EBUflScpts.ThinkHook );
	
	local oldDataStreamToServers = datastream.StreamToServer
		function datastream.StreamToServer( HANDLER, DATA, CALLBACK )
			if EBUflScpts.DisableDataStreams then return end
			
			oldDataStreamToServers( HANDLER, DATA, CALLBACK )
		end
		
	local oldConCommand = _R.Player.ConCommand
	local oldRunConsoleCommand = RunConsoleCommand
		function _R.Player.ConCommand( PLAYER, COMMAND )
			if EBUflScpts.DisableConsoleCommands then print( "ConCommand Blocked: "..COMMAND ) return end
			
			oldConCommand( PLAYER, COMMAND )
		end
		function RunConsoleCommand( ... )
			if EBUflScpts.DisableConsoleCommands then print( "RunConsoleCommand Blocked: "..string.Implode( " ", { ... } )) return end
			
			oldRunConsoleCommand( unpack( { ... }, 1 ))
		end

--

-- DERMA FUNCTIONS --
	EBDerma.MainDFrame = vgui.Create( "DFrame" )
		EBDerma.MainDFrame:SetSize( scrW, ( scrH * 0.1 ))
		EBDerma.MainDFrame:SetPos( 0, ( scrH * -0.1 ))
		EBDerma.MainDFrame:SetTitle( "" )
		EBDerma.MainDFrame:SetVisible( false )
		EBDerma.MainDFrame:SetDraggable( false )
		EBDerma.MainDFrame:SetDeleteOnClose( false )
		EBDerma.MainDFrame:ShowCloseButton( false )
		EBDerma.MainDFrame.Paint = function( )
			local panelW, panelT = EBDerma.MainDFrame:GetWide( ), ( EBDerma.MainDFrame:GetTall( ))
		
			surface.SetDrawColor( 40, 40, 40, 255 )
				surface.DrawRect( 0, 0, panelW, panelT )
			surface.SetDrawColor( 30, 30, 30, 255 )
				if !EBDerma.CurrentSelection then
					surface.DrawLine( 0, ( panelT - 1 ), panelW, ( panelT - 1 ))
				else
					local curSelPanPosX, curSelPanPosY = EBDerma.SelectionTabPanels[EBDerma.CurrentSelection]:GetPos( )
					
					surface.DrawLine( 0, ( panelT - 1 ), curSelPanPosX, ( panelT - 1 ) )
					surface.DrawLine(( curSelPanPosX + ( scrW * 0.1 )), ( panelT - 1 ), scrW, ( panelT - 1 ))
				end
			
			surface.SetDrawColor( 30, 30, 30, 255 )
				for INDEX = 1, 9 do
					local lineXPos = (( INDEX * ( scrW * 0.1 )) - 1 )
					
					surface.DrawLine( lineXPos, 10, lineXPos, ( scrH * 0.1 ))
				end
		end
	function EBDerma.GenerateTabStructure( posB, posP, text )
		EBDerma.SelectionTabPanels[text] = vgui.Create( "DFrame", EBDerma.MainDFrame )
			EBDerma.SelectionTabPanels[text]:SetSize(( scrW - posP.x ), ( scrW * 0.8 ))
			EBDerma.SelectionTabPanels[text]:SetPos( posP.x, posP.y )
			EBDerma.SelectionTabPanels[text]:SetTitle( "" )
			EBDerma.SelectionTabPanels[text]:SetVisible( false )
			EBDerma.SelectionTabPanels[text]:SetDraggable( false )
			EBDerma.SelectionTabPanels[text]:SetDeleteOnClose( false )
			EBDerma.SelectionTabPanels[text]:ShowCloseButton( false )
			EBDerma.SelectionTabPanels[text].Paint = function( )
				surface.SetDrawColor( 40, 40, 40, 255 )
					surface.DrawRect( 0, 0, ( scrW * 0.3 ), ( scrH * 0.17 ))
			end
	
		EBDerma.SelectionTabButtons[text] = vgui.Create( "DButton", EBDerma.MainDFrame )
			EBDerma.SelectionTabButtons[text]:SetSize(( scrW * 0.1 ), ( scrH * 0.1 ))
			EBDerma.SelectionTabButtons[text]:SetPos( posB.x, posB.y )
			EBDerma.SelectionTabButtons[text]:SetText( text )
			EBDerma.SelectionTabButtons[text].DoClick = function( )
				for _, panel in pairs( EBDerma.SelectionTabPanels ) do if panel:IsVisible( ) and panel != EBDerma.SelectionTabPanels[text] then panel:Close( ) end end
			
				if !EBDerma.SelectionTabPanels[text]:IsVisible( ) then
					EBDerma.SelectionTabPanels[text]:MakePopup( )
					EBDerma.SelectionTabPanels[text]:SetVisible( true )
					EBDerma.CurrentSelection = text
				else
					EBDerma.SelectionTabPanels[text]:Close( )
					EBDerma.CurrentSelection = false
				end
			end
			EBDerma.SelectionTabButtons[text].Paint = function( )
				local panelW, panelT = EBDerma.SelectionTabButtons[text]:GetWide( ), EBDerma.SelectionTabButtons[text]:GetTall( )
				local cursorPosX, cursorPosY = EBDerma.SelectionTabButtons[text]:GetPos( )
				
				if cursorPosX < gui.MouseX( ) and gui.MouseX( ) < ( cursorPosX + panelW ) and cursorPosY < gui.MouseY( ) and gui.MouseY( ) < ( cursorPosY + panelT ) then
					surface.SetDrawColor( 150, 150, 150, 50 )
						surface.DrawRect( 0, 0, panelW, panelT )
				end
			end
	end
	
	EBDerma.GenerateTabStructure( { x = 0, y = 0 }, { x = 0, y = ( scrH * 0.1 ) }, "Aimbot Settings", function( ) end )
		EBDerma.AimbotPanelContents.KeepTargetingEnabledBool = vgui.Create( "DCheckBoxLabel", EBDerma.SelectionTabPanels["Aimbot Settings"] )
			EBDerma.AimbotPanelContents.KeepTargetingEnabledBool:SetSize( 180, 15 )
			EBDerma.AimbotPanelContents.KeepTargetingEnabledBool:SetPos( 10, 20 )
			EBDerma.AimbotPanelContents.KeepTargetingEnabledBool:SetText( "Keep Targeting Enabled" )
			if EBAimbot.KeepTargetingEnabled then EBDerma.AimbotPanelContents.KeepTargetingEnabledBool:SetValue( 1 ) end
			EBDerma.AimbotPanelContents.KeepTargetingEnabledBool.OnChange = function( ) if EBAimbot.KeepTargetingEnabled then EBAimbot.KeepTargetingEnabled = false else EBAimbot.KeepTargetingEnabled = true end end
		EBDerma.AimbotPanelContents.UseLOSBool = vgui.Create( "DCheckBoxLabel", EBDerma.SelectionTabPanels["Aimbot Settings"] )
			EBDerma.AimbotPanelContents.UseLOSBool:SetSize( 180, 15 )
			EBDerma.AimbotPanelContents.UseLOSBool:SetPos( 10, 40 )
			EBDerma.AimbotPanelContents.UseLOSBool:SetText( "Use LOS System" )
			if EBAimbot.TargetUsingLOS then EBDerma.AimbotPanelContents.UseLOSBool:SetValue( 1 ) end
			EBDerma.AimbotPanelContents.UseLOSBool.OnChange = function( ) if EBAimbot.TargetUsingLOS then EBAimbot.TargetUsingLOS = false else EBAimbot.TargetUsingLOS = true end end
		EBDerma.AimbotPanelContents.AttackOpposingTeamBool = vgui.Create( "DCheckBoxLabel", EBDerma.SelectionTabPanels["Aimbot Settings"] )
			EBDerma.AimbotPanelContents.AttackOpposingTeamBool:SetSize( 180, 15 )
			EBDerma.AimbotPanelContents.AttackOpposingTeamBool:SetPos( 10, 60 )
			EBDerma.AimbotPanelContents.AttackOpposingTeamBool:SetText( "Target Opposing Team(s) Only" )
			if EBAimbot.TargetOpposingTeams then EBDerma.AimbotPanelContents.AttackOpposingTeamBool:SetValue( 1 ) end
			EBDerma.AimbotPanelContents.AttackOpposingTeamBool.OnChange = function( ) if EBAimbot.TargetOpposingTeams then EBAimbot.TargetOpposingTeams = false else EBAimbot.TargetOpposingTeams = true end end
		EBDerma.AimbotPanelContents.TargetNPCsBool = vgui.Create( "DCheckBoxLabel", EBDerma.SelectionTabPanels["Aimbot Settings"] )
			EBDerma.AimbotPanelContents.TargetNPCsBool:SetSize( 180, 15 )
			EBDerma.AimbotPanelContents.TargetNPCsBool:SetPos( 10, 80 )
			EBDerma.AimbotPanelContents.TargetNPCsBool:SetText( "Target NPCs" )
			if EBAimbot.TargetNPCs then EBDerma.AimbotPanelContents.TargetNPCsBool:SetValue( 1 ) end
			EBDerma.AimbotPanelContents.TargetNPCsBool.OnChange = function( ) if EBAimbot.TargetNPCs then EBAimbot.TargetNPCs = false else EBAimbot.TargetNPCs = true end end
		EBDerma.AimbotPanelContents.AvoidTargetingSteamFriendsBool = vgui.Create( "DCheckBoxLabel", EBDerma.SelectionTabPanels["Aimbot Settings"] )
			EBDerma.AimbotPanelContents.AvoidTargetingSteamFriendsBool:SetSize( 180, 15 )
			EBDerma.AimbotPanelContents.AvoidTargetingSteamFriendsBool:SetPos( 10, 100 )
			EBDerma.AimbotPanelContents.AvoidTargetingSteamFriendsBool:SetText( "Avoid Targeting Steam Friends" )
			if EBAimbot.AvoidTargetingSteamFriends then EBDerma.AimbotPanelContents.AvoidTargetingSteamFriendsBool:SetValue( 1 ) end
			EBDerma.AimbotPanelContents.AvoidTargetingSteamFriendsBool.OnChange = function( ) if EBAimbot.AvoidTargetingSteamFriends then EBAimbot.AvoidTargetingSteamFriends = false else EBAimbot.AvoidTargetingSteamFriends = true end end
		EBDerma.AimbotPanelContents.AutoShootBool = vgui.Create( "DCheckBoxLabel", EBDerma.SelectionTabPanels["Aimbot Settings"] )
			EBDerma.AimbotPanelContents.AutoShootBool:SetSize( 180, 15 )
			EBDerma.AimbotPanelContents.AutoShootBool:SetPos( 10, 120 )
			EBDerma.AimbotPanelContents.AutoShootBool:SetText( "Auto-Shoot Targets" )
			if EBAimbot.AutoShoot.Enabled then EBDerma.AimbotPanelContents.AutoShootBool:SetValue( 1 ) end
			EBDerma.AimbotPanelContents.AutoShootBool.OnChange = function( ) if EBAimbot.AutoShoot.Enabled then EBAimbot.AutoShoot.Enabled = false else EBAimbot.AutoShoot.Enabled = true end end
		EBDerma.AimbotPanelContents.FOVMaxRadiusNumSlider = vgui.Create( "DNumSlider", EBDerma.SelectionTabPanels["Aimbot Settings"] ) -- EBAimbot.FieldOfView.Enabled
			EBDerma.AimbotPanelContents.FOVMaxRadiusNumSlider:SetSize( 220, 19 )
			EBDerma.AimbotPanelContents.FOVMaxRadiusNumSlider:SetPos(( scrW * 0.15 ), 15 )
			EBDerma.AimbotPanelContents.FOVMaxRadiusNumSlider:SetValue( 300 ); EBDerma.AimbotPanelContents.FOVMaxRadiusNumSlider:SetDecimals( 0 );
			EBDerma.AimbotPanelContents.FOVMaxRadiusNumSlider:SetMin( 75 ); EBDerma.AimbotPanelContents.FOVMaxRadiusNumSlider:SetMax( scrH * 0.5 );
			EBDerma.AimbotPanelContents.FOVMaxRadiusNumSlider:SetText( "" )
			EBDerma.AimbotPanelContents.FOVMaxRadiusNumSlider.OnValueChanged = function( ) EBAimbot.FieldOfView.Value = EBDerma.AimbotPanelContents.FOVMaxRadiusNumSlider:GetValue( ) end
		EBDerma.AimbotPanelContents.FOVToggleBool = vgui.Create( "DCheckBoxLabel", EBDerma.SelectionTabPanels["Aimbot Settings"] )
			EBDerma.AimbotPanelContents.FOVToggleBool:SetSize( 180, 15 )
			EBDerma.AimbotPanelContents.FOVToggleBool:SetPos(( scrW * 0.15 ), 20 )
			EBDerma.AimbotPanelContents.FOVToggleBool:SetText( "FOV Radius From Crosshair" )
			if EBAimbot.FieldOfView.Enabled then EBDerma.AimbotPanelContents.FOVToggleBool:SetValue( 1 ) end
			EBDerma.AimbotPanelContents.FOVToggleBool.OnChange = function( ) if EBAimbot.FieldOfView.Enabled then EBAimbot.FieldOfView.Enabled = false else EBAimbot.FieldOfView.Enabled = true end end
		EBDerma.AimbotPanelContents.AntiSnapNumSlider = vgui.Create( "DNumSlider", EBDerma.SelectionTabPanels["Aimbot Settings"] ) -- EBAimbot.FieldOfView.Enabled
			EBDerma.AimbotPanelContents.AntiSnapNumSlider:SetSize( 220, 19 )
			EBDerma.AimbotPanelContents.AntiSnapNumSlider:SetPos(( scrW * 0.15 ), 35 )
			EBDerma.AimbotPanelContents.AntiSnapNumSlider:SetValue( 1 ); EBDerma.AimbotPanelContents.AntiSnapNumSlider:SetDecimals( 0 );
			EBDerma.AimbotPanelContents.AntiSnapNumSlider:SetMin( 1 ); EBDerma.AimbotPanelContents.AntiSnapNumSlider:SetMax( 10 );
			EBDerma.AimbotPanelContents.AntiSnapNumSlider:SetText( "" )
			EBDerma.AimbotPanelContents.AntiSnapNumSlider.OnValueChanged = function( ) EBAimbot.AntiSnap.Value = EBDerma.AimbotPanelContents.AntiSnapNumSlider:GetValue( ) end
		EBDerma.AimbotPanelContents.AntiSnapBool = vgui.Create( "DCheckBoxLabel", EBDerma.SelectionTabPanels["Aimbot Settings"] )
			EBDerma.AimbotPanelContents.AntiSnapBool:SetSize( 180, 15 )
			EBDerma.AimbotPanelContents.AntiSnapBool:SetPos(( scrW * 0.15 ), 40 )
			EBDerma.AimbotPanelContents.AntiSnapBool:SetText( "Anti-Snap" )
			if EBAimbot.AntiSnap.Enabled then EBDerma.AimbotPanelContents.AntiSnapBool:SetValue( 1 ) end
			EBDerma.AimbotPanelContents.AntiSnapBool.OnChange = function( ) if EBAimbot.AntiSnap.Enabled then EBAimbot.AntiSnap.Enabled = false else EBAimbot.AntiSnap.Enabled = true end end
		EBDerma.AimbotPanelContents.TargetEntitiesDropDownMenu = vgui.Create( "DMultiChoice", EBDerma.SelectionTabPanels["Aimbot Settings"] )
			EBDerma.AimbotPanelContents.TargetEntitiesDropDownMenu:SetSize( 220, 20 )
			EBDerma.AimbotPanelContents.TargetEntitiesDropDownMenu:SetPos(( scrW * 0.15 ), 55 )
			EBDerma.AimbotPanelContents.TargetEntitiesDropDownMenu:SetText( "      Targeted Entity List" )
			EBDerma.AimbotPanelContents.TargetEntitiesDropDownMenu:SetEditable( false )
			EBDerma.AimbotPanelContents.TargetEntitiesDropDownMenu.OnSelect = function( _, index, text )
				if EBAimbot.TargetEntities.TargetTable[text] then EBAimbot.TargetEntities.TargetTable[text] = nil else EBAimbot.TargetEntities.TargetTable[text] = true end
				
				EBDerma.AimbotPanelContents.TargetEntitiesDropDownMenu.UpdateLines( )
			end
			function EBDerma.AimbotPanelContents.TargetEntitiesDropDownMenu.UpdateLines( )
				local EntitiesAlreadyAdded = { }
				
				EBDerma.AimbotPanelContents.TargetEntitiesDropDownMenu:Clear( )
				EBDerma.AimbotPanelContents.TargetEntitiesDropDownMenu:SetText( "      Targeted Entity List" )
				
				for _, entity in pairs( ents.GetAll( )) do if entity and ValidEntity( entity ) and !EntitiesAlreadyAdded[entity:GetClass( )] then EntitiesAlreadyAdded[entity:GetClass( )] = false end end
				
				for entityClass, _ in SortedPairs( EntitiesAlreadyAdded ) do
					if entityClass != "player" and entityClass != "viewmodel" and entityClass != "physgun_beam" and !string.find( entityClass, "class " ) and !string.find( entityClass, "weapon_" ) and !string.find( entityClass, "gmod_" ) and !string.find( entityClass, "npc_" ) then
						EBDerma.AimbotPanelContents.TargetEntitiesDropDownMenu:AddChoice( entityClass )
					end
				end
			end
			EBDerma.AimbotPanelContents.TargetEntitiesBool = vgui.Create( "DCheckBoxLabel", EBDerma.SelectionTabPanels["Aimbot Settings"] )
				EBDerma.AimbotPanelContents.TargetEntitiesBool:SetSize( 15, 15 )
				EBDerma.AimbotPanelContents.TargetEntitiesBool:SetPos((( scrW * 0.15 ) + 2 ), 58.5 )
				EBDerma.AimbotPanelContents.TargetEntitiesBool:SetText( "" )
				if EBAimbot.TargetEntities.Enabled then EBDerma.AimbotPanelContents.TargetEntitiesBool:SetValue( 1 ) end
				EBDerma.AimbotPanelContents.TargetEntitiesBool.OnChange = function( ) if EBAimbot.TargetEntities.Enabled then EBAimbot.TargetEntities.Enabled = false else EBAimbot.TargetEntities.Enabled = true end end
			EBDerma.AimbotPanelContents.WhiteListDropDownMenu = vgui.Create( "DMultiChoice", EBDerma.SelectionTabPanels["Aimbot Settings"] )
				EBDerma.AimbotPanelContents.WhiteListDropDownMenu:SetSize( 220, 20 )
				EBDerma.AimbotPanelContents.WhiteListDropDownMenu:SetPos(( scrW * 0.15 ), 75 )
				EBDerma.AimbotPanelContents.WhiteListDropDownMenu:SetText( "      Player Whitelist (Aimbot Filter)" )
				EBDerma.AimbotPanelContents.WhiteListDropDownMenu:SetEditable( false )
				EBDerma.AimbotPanelContents.WhiteListDropDownMenu.OnSelect = function( _, index, text )
					EBDerma.AimbotPanelContents.WhiteListDropDownMenu.UpdateLines( )
					
					for _, ply in pairs( player.GetAll( )) do
						if ply:Nick( ) == text then
							if EBAimbot.WhiteListPlayers.Table[ply:SteamID( )] then
								EBAimbot.WhiteListPlayers.Table[ply:SteamID( )] = nil
							else
								EBAimbot.WhiteListPlayers.Table[ply:SteamID( )] = ply
							end
							
							break
						end
					end
				end
				function EBDerma.AimbotPanelContents.WhiteListDropDownMenu.UpdateLines( )
					EBDerma.AimbotPanelContents.WhiteListDropDownMenu:Clear( )
					if !EBAimbot.WhiteListPlayers.Blacklist then
						EBDerma.AimbotPanelContents.WhiteListDropDownMenu:SetText( "      Player Whitelist (Aimbot Filter)" )
					else
						EBDerma.AimbotPanelContents.WhiteListDropDownMenu:SetText( "      Player Blacklist (Target Only)" )
					end
				
					for _, ply in SortedPairs( player.GetAll( )) do
						if ply != LocalPlayer( ) then
							EBDerma.AimbotPanelContents.WhiteListDropDownMenu:AddChoice( ply:Nick( ))
						end
					end
				end
			EBDerma.AimbotPanelContents.WhiteListToBlackListBool = vgui.Create( "DCheckBoxLabel", EBDerma.SelectionTabPanels["Aimbot Settings"] )
				EBDerma.AimbotPanelContents.WhiteListToBlackListBool:SetSize( 15, 15 )
				EBDerma.AimbotPanelContents.WhiteListToBlackListBool:SetPos((( scrW * 0.15 ) + 2 ), 78.5 )
				EBDerma.AimbotPanelContents.WhiteListToBlackListBool:SetText( "" )
				if EBAimbot.WhiteListPlayers.Blacklist then EBDerma.AimbotPanelContents.WhiteListToBlackListBool:SetValue( 1 ) end
				EBDerma.AimbotPanelContents.WhiteListToBlackListBool.OnChange = function( )
					if EBAimbot.WhiteListPlayers.Blacklist then
						EBDerma.AimbotPanelContents.WhiteListDropDownMenu:SetText( "      Player Whitelist (Aimbot Filter)" )
						EBAimbot.WhiteListPlayers.Blacklist = false
					else
						EBDerma.AimbotPanelContents.WhiteListDropDownMenu:SetText( "      Player Blacklist (Target Only)" )
						EBAimbot.WhiteListPlayers.Blacklist = true
					end
				end
			EBDerma.AimbotPanelContents.TargetBoneDropDownMenu = vgui.Create( "DMultiChoice", EBDerma.SelectionTabPanels["Aimbot Settings"] )
				EBDerma.AimbotPanelContents.TargetBoneDropDownMenu:SetSize( 220, 20 )
				EBDerma.AimbotPanelContents.TargetBoneDropDownMenu:SetPos(( scrW * 0.15 ), 95 )
				EBDerma.AimbotPanelContents.TargetBoneDropDownMenu:SetText( "Player Bone Selection" )
				EBDerma.AimbotPanelContents.TargetBoneDropDownMenu:SetEditable( false )
				EBDerma.AimbotPanelContents.TargetBoneDropDownMenu.OnSelect = function( _, index, text ) EBAimbot.BoneNumSelection = index EBDerma.AimbotPanelContents.TargetBoneDropDownMenu:SetText( "Player Bone Selection" ) end
				for boneNum, BoneData in pairs( EBAimbot.BoneList ) do EBDerma.AimbotPanelContents.TargetBoneDropDownMenu:AddChoice( BoneData.PrintName ) end
			EBDerma.AimbotPanelContents.PresentPlayerModel = vgui.Create( "DModelPanel", EBDerma.SelectionTabPanels["Aimbot Settings"] )
				EBDerma.AimbotPanelContents.PresentPlayerModel:SetPos(( scrW * 0.6 ), 0 )
				EBDerma.AimbotPanelContents.PresentPlayerModel:SetSize(( scrH * 0.8 ), ( scrH * 0.8 ))
				EBDerma.AimbotPanelContents.PresentPlayerModel:SetModel( "models/kleiner.mdl" )
				EBDerma.AimbotPanelContents.PresentPlayerModel:SetCamPos( Vector( 75, 0, 35 ))
				EBDerma.AimbotPanelContents.PresentPlayerModel:SetLookAt( Vector( 0, 0, 35 ))
				EBDerma.AimbotPanelContents.PresentPlayerModel.LayoutEntity = function( Entity )
					EBDerma.AimbotPanelContents.PresentPlayerModel:GetEntity( ):ResetSequence( EBDerma.AimbotPanelContents.PresentPlayerModel:GetEntity( ):LookupSequence( "ragdoll" ))
				end
				EBDerma.AimbotPanelContents.PresentPlayerModel.PaintOver = function( )
					surface.SetDrawColor( 0, 0, 0, 255 )
					surface.DrawRect(( EBAimbot.BoneList[EBAimbot.BoneNumSelection].DiagramPos.x - 4 ), ( EBAimbot.BoneList[ EBAimbot.BoneNumSelection ].DiagramPos.y - 6 ), 12, 12 )
					surface.SetDrawColor( 255, 255, 255, 255 )
						surface.DrawRect(( EBAimbot.BoneList[EBAimbot.BoneNumSelection].DiagramPos.x - 2 ), ( EBAimbot.BoneList[ EBAimbot.BoneNumSelection ].DiagramPos.y - 4 ), 8, 8 )
				end
		EBDerma.GenerateTabStructure( { x = ( scrW * 0.1 ), y = 0 }, { x = ( scrW * 0.1 ), y = ( scrH * 0.1 ) }, "ESP Settings", function( ) end )
			EBDerma.ESPPanelContents.WallhackESPBool = vgui.Create( "DCheckBoxLabel", EBDerma.SelectionTabPanels["ESP Settings"] )
				EBDerma.ESPPanelContents.WallhackESPBool:SetSize( 180, 15 )
				EBDerma.ESPPanelContents.WallhackESPBool:SetPos( 10, 20 )
				EBDerma.ESPPanelContents.WallhackESPBool:SetText( "Wallhacks" )
				if EBEsp.WallhackEnabled then EBDerma.ESPPanelContents.WallhackESPBool:SetValue( 1 ) end
				EBDerma.ESPPanelContents.WallhackESPBool.OnChange = function( ) if EBEsp.WallhackEnabled then EBEsp.WallhackEnabled = false else EBEsp.WallhackEnabled = true end end
			EBDerma.ESPPanelContents.EyelasersBool = vgui.Create( "DCheckBoxLabel", EBDerma.SelectionTabPanels["ESP Settings"] )
				EBDerma.ESPPanelContents.EyelasersBool:SetSize( 180, 15 )
				EBDerma.ESPPanelContents.EyelasersBool:SetPos( 10, 40 )
				EBDerma.ESPPanelContents.EyelasersBool:SetText( "Eye Lasers" )
				if EBEsp.EyeLasersEnabled then EBDerma.ESPPanelContents.EyelasersBool:SetValue( 1 ) end
				EBDerma.ESPPanelContents.EyelasersBool.OnChange = function( ) if EBEsp.EyeLasersEnabled then EBEsp.EyeLasersEnabled = false else EBEsp.EyeLasersEnabled = true end end
			EBDerma.ESPPanelContents.CrosshairBool = vgui.Create( "DCheckBoxLabel", EBDerma.SelectionTabPanels["ESP Settings"] )
				EBDerma.ESPPanelContents.CrosshairBool:SetSize( 180, 15 )
				EBDerma.ESPPanelContents.CrosshairBool:SetPos( 10, 60 )
				EBDerma.ESPPanelContents.CrosshairBool:SetText( "Crosshair" )
				if EBEsp.CrosshairEnabled then EBDerma.ESPPanelContents.CrosshairBool:SetValue( 1 ) end
				EBDerma.ESPPanelContents.CrosshairBool.OnChange = function( ) if EBEsp.CrosshairEnabled then EBEsp.CrosshairEnabled = false else EBEsp.CrosshairEnabled = true end end
			EBDerma.ESPPanelContents.ChamsOptionsDropDownMenu = vgui.Create( "DMultiChoice", EBDerma.SelectionTabPanels["ESP Settings"] )
				EBDerma.ESPPanelContents.ChamsOptionsDropDownMenu:SetSize( 220, 20 )
				EBDerma.ESPPanelContents.ChamsOptionsDropDownMenu:SetPos( 10, 77.5 )
				EBDerma.ESPPanelContents.ChamsOptionsDropDownMenu:SetText( "      Chams" )
				EBDerma.ESPPanelContents.ChamsOptionsDropDownMenu:SetEditable( false )
				EBDerma.ESPPanelContents.ChamsOptionsDropDownMenu.OnSelect = function( _, index, text ) EBEsp.Wallchams.SelectedMat = index EBDerma.ESPPanelContents.ChamsOptionsDropDownMenu:SetText( "      Chams" ) end
				EBDerma.ESPPanelContents.ChamsOptionsDropDownMenu:AddChoice( "Debug White" )
				EBDerma.ESPPanelContents.ChamsOptionsDropDownMenu:AddChoice( "Wireframe" )
			EBDerma.ESPPanelContents.ChamsBool = vgui.Create( "DCheckBoxLabel", EBDerma.SelectionTabPanels["ESP Settings"] )
				EBDerma.ESPPanelContents.ChamsBool:SetSize( 15, 15 )
				EBDerma.ESPPanelContents.ChamsBool:SetPos( 12, 80 )
				EBDerma.ESPPanelContents.ChamsBool:SetText( "" )
				if EBEsp.Wallchams.Enabled then EBDerma.ESPPanelContents.ChamsBool:SetValue( 1 ) end
				EBDerma.ESPPanelContents.ChamsBool.OnChange = function( ) if EBEsp.Wallchams.Enabled then EBEsp.Wallchams.Enabled = false else EBEsp.Wallchams.Enabled = true end end
		EBDerma.ESPPanelContents.ESPEntitiesDropDownMenu = vgui.Create( "DMultiChoice", EBDerma.SelectionTabPanels["ESP Settings"] )
			EBDerma.ESPPanelContents.ESPEntitiesDropDownMenu:SetSize( 220, 20 )
			EBDerma.ESPPanelContents.ESPEntitiesDropDownMenu:SetPos( 10, 97.5 )
			EBDerma.ESPPanelContents.ESPEntitiesDropDownMenu:SetText( "      ESP Entities" )
			EBDerma.ESPPanelContents.ESPEntitiesDropDownMenu:SetEditable( false )
			EBDerma.ESPPanelContents.ESPEntitiesDropDownMenu.OnSelect = function( _, index, text )
				if EBEsp.ESPEntities.Table[text] then EBEsp.ESPEntities.Table[text] = nil else EBEsp.ESPEntities.Table[text] = true end
				
				EBDerma.ESPPanelContents.ESPEntitiesDropDownMenu.UpdateLines( )
			end
			function EBDerma.ESPPanelContents.ESPEntitiesDropDownMenu.UpdateLines( )
				local EntitiesAlreadyAdded = { }
				
				EBDerma.ESPPanelContents.ESPEntitiesDropDownMenu:Clear( )
				EBDerma.ESPPanelContents.ESPEntitiesDropDownMenu:SetText( "      ESP Entities" )
				
				for _, entity in pairs( ents.GetAll( )) do if entity and ValidEntity( entity ) and !EntitiesAlreadyAdded[entity:GetClass( )] then EntitiesAlreadyAdded[entity:GetClass( )] = false end end
				
				for entityClass, _ in SortedPairs( EntitiesAlreadyAdded ) do
					if entityClass != "player" and entityClass != "viewmodel" and entityClass != "physgun_beam" and !string.find( entityClass, "class " ) and !string.find( entityClass, "gmod_" ) and !string.find( entityClass, "npc_" ) then
						EBDerma.ESPPanelContents.ESPEntitiesDropDownMenu:AddChoice( entityClass )
					end
				end
			end
			EBDerma.ESPPanelContents.ESPEntitiesBool = vgui.Create( "DCheckBoxLabel", EBDerma.SelectionTabPanels["ESP Settings"] )
				EBDerma.ESPPanelContents.ESPEntitiesBool:SetSize( 15, 15 )
				EBDerma.ESPPanelContents.ESPEntitiesBool:SetPos( 12, 100 )
				EBDerma.ESPPanelContents.ESPEntitiesBool:SetText( "" )
				if EBEsp.ESPEntities.Enabled then EBDerma.ESPPanelContents.ESPEntitiesBool:SetValue( 1 ) end
				EBDerma.ESPPanelContents.ESPEntitiesBool.OnChange = function( ) if EBEsp.ESPEntities.Enabled then EBEsp.ESPEntities.Enabled = false else EBEsp.ESPEntities.Enabled = true end end
		EBDerma.GenerateTabStructure( { x = ( scrW * 0.2 ), y = 0 }, { x = ( scrW * 0.2 ), y = ( scrH * 0.1 ) }, "Useful Scripts", function( ) end )
			EBDerma.UsefulScriptsPanelContents.NoSpreadAndNoRecoilToggle = vgui.Create( "DCheckBoxLabel", EBDerma.SelectionTabPanels["Useful Scripts"] )
				EBDerma.UsefulScriptsPanelContents.NoSpreadAndNoRecoilToggle:SetSize( 180, 15 )
				EBDerma.UsefulScriptsPanelContents.NoSpreadAndNoRecoilToggle:SetPos( 10, 20 )
				EBDerma.UsefulScriptsPanelContents.NoSpreadAndNoRecoilToggle:SetText( "No Spread && No Recoil" )
				if EBUflScpts.NoSpreadAndNoRecoil.Enabled then EBDerma.UsefulScriptsPanelContents.NoSpreadAndNoRecoilToggle:SetValue( 1 ) end
				EBDerma.UsefulScriptsPanelContents.NoSpreadAndNoRecoilToggle.OnChange = function( ) if EBUflScpts.NoSpreadAndNoRecoil.Enabled then EBUflScpts.NoSpreadAndNoRecoil.Enabled = false else EBUflScpts.NoSpreadAndNoRecoil.Enabled = true end end
			EBDerma.UsefulScriptsPanelContents.MuteCurrentWeaponSoundToggle = vgui.Create( "DCheckBoxLabel", EBDerma.SelectionTabPanels["Useful Scripts"] )
				EBDerma.UsefulScriptsPanelContents.MuteCurrentWeaponSoundToggle:SetSize( 180, 15 )
				EBDerma.UsefulScriptsPanelContents.MuteCurrentWeaponSoundToggle:SetPos( 10, 40 )
				EBDerma.UsefulScriptsPanelContents.MuteCurrentWeaponSoundToggle:SetText( "Mute Active Weapon" )
				if EBUflScpts.MuteCurrentWeaponSound.Enabled then EBDerma.UsefulScriptsPanelContents.MuteCurrentWeaponSoundToggle:SetValue( 1 ) end
				EBDerma.UsefulScriptsPanelContents.MuteCurrentWeaponSoundToggle.OnChange = function( ) if EBUflScpts.MuteCurrentWeaponSound.Enabled then EBUflScpts.MuteCurrentWeaponSound.Enabled = false else EBUflScpts.MuteCurrentWeaponSound.Enabled = true end end
			EBDerma.UsefulScriptsPanelContents.DisableDataStreamsToggle = vgui.Create( "DCheckBoxLabel", EBDerma.SelectionTabPanels["Useful Scripts"] )
				EBDerma.UsefulScriptsPanelContents.DisableDataStreamsToggle:SetSize( 180, 15 )
				EBDerma.UsefulScriptsPanelContents.DisableDataStreamsToggle:SetPos( 10, 60 )
				EBDerma.UsefulScriptsPanelContents.DisableDataStreamsToggle:SetText( "Disable Datastreams" )
				if EBUflScpts.DisableDataStreams then EBDerma.UsefulScriptsPanelContents.DisableDataStreamsToggle:SetValue( 1 ) end
				EBDerma.UsefulScriptsPanelContents.DisableDataStreamsToggle.OnChange = function( ) if EBUflScpts.DisableDataStreams then EBUflScpts.DisableDataStreams = false else EBUflScpts.DisableDataStreams = true end end
			EBDerma.UsefulScriptsPanelContents.DisableConsoleCommandsToggle = vgui.Create( "DCheckBoxLabel", EBDerma.SelectionTabPanels["Useful Scripts"] )
				EBDerma.UsefulScriptsPanelContents.DisableConsoleCommandsToggle:SetSize( 180, 15 )
				EBDerma.UsefulScriptsPanelContents.DisableConsoleCommandsToggle:SetPos( 10, 80 )
				EBDerma.UsefulScriptsPanelContents.DisableConsoleCommandsToggle:SetText( "Disable Console Commands" )
				if EBUflScpts.DisableConsoleCommands then EBDerma.UsefulScriptsPanelContents.DisableConsoleCommandsToggle:SetValue( 1 ) end
				EBDerma.UsefulScriptsPanelContents.DisableConsoleCommandsToggle.OnChange = function( ) if EBUflScpts.DisableConsoleCommands then EBUflScpts.DisableConsoleCommands = false else EBUflScpts.DisableConsoleCommands = true end end
			
		function EBDerma.ThinkHook( )
			local panelPosX, panelPosY = EBDerma.MainDFrame:GetPos( )
		
			if panelPosY != 0 then
				EBDerma.MainDFrame:SetPos( 0, math.Approach( panelPosY, 0, 10 ))
			end
			if input.IsKeyDown( 74 ) and !EBDerma.MainDFrame:IsVisible( ) then
				EBDerma.MainDFrame:MakePopup( ); EBDerma.MainDFrame:SetVisible( true );
				EBDerma.MainDFrame:SetPos( 0, ( scrH * -0.1 ))
				
				/* Run Shit */
					EBDerma.AimbotPanelContents.TargetEntitiesDropDownMenu.UpdateLines( )
					EBDerma.AimbotPanelContents.WhiteListDropDownMenu.UpdateLines( )
					EBDerma.ESPPanelContents.ESPEntitiesDropDownMenu.UpdateLines( )
			elseif !input.IsKeyDown( 74 ) and EBDerma.MainDFrame:IsVisible( ) then
				for _, panel in pairs( EBDerma.SelectionTabPanels ) do if panel:IsVisible( ) and panel != EBDerma.SelectionTabPanels[text] then panel:Close( ) end end
				EBDerma.CurrentSelection = false
				EBDerma.MainDFrame:Close( )
				
				/* Run Shit */
					if EBDerma.AimbotPanelContents.TargetEntitiesDropDownMenu.Menu then EBDerma.AimbotPanelContents.TargetEntitiesDropDownMenu.Menu:Remove( ) end
					if EBDerma.AimbotPanelContents.TargetBoneDropDownMenu.Menu then EBDerma.AimbotPanelContents.TargetBoneDropDownMenu.Menu:Remove( ) end
					if EBDerma.AimbotPanelContents.WhiteListDropDownMenu.Menu then EBDerma.AimbotPanelContents.WhiteListDropDownMenu.Menu:Remove( ) end
					if EBDerma.ESPPanelContents.ChamsOptionsDropDownMenu.Menu then EBDerma.ESPPanelContents.ChamsOptionsDropDownMenu.Menu:Remove( ) end
					if EBDerma.ESPPanelContents.ESPEntitiesDropDownMenu.Menu then EBDerma.ESPPanelContents.ESPEntitiesDropDownMenu.Menu:Remove( ) end
					
					file.Write( "EthanBot/settings.txt", glon.encode( { EBAimbot, EBEsp, EBUflScpts } ))
			end
			
				if EBDerma.AimbotPanelContents.TargetEntitiesDropDownMenu.Menu and EBDerma.AimbotPanelContents.TargetEntitiesDropDownMenu.Menu:IsValid( ) then
					EBDerma.AimbotPanelContents.TargetEntitiesDropDownMenu.Menu.PaintOver = function( )
						local lineNum = 0
						
						for _, lineText in pairs( EBDerma.AimbotPanelContents.TargetEntitiesDropDownMenu.Choices ) do
							if EBAimbot.TargetEntities.TargetTable[lineText] then
								surface.SetDrawColor( 0, 0, 0, 255 ); surface.SetTexture( surface.GetTextureID( "gui/silkicons/check_on_s" ));
									surface.DrawTexturedRect( 1, (( lineNum * 18 ) + 2 ), 16, 16 )
							end
							
							lineNum = ( lineNum + 1 )
						end
					end
				end
				if EBDerma.AimbotPanelContents.TargetBoneDropDownMenu.Menu and EBDerma.AimbotPanelContents.TargetBoneDropDownMenu.Menu:IsValid( ) then
					EBDerma.AimbotPanelContents.TargetBoneDropDownMenu.Menu.PaintOver = function( )
						surface.SetDrawColor( 0, 0, 0, 255 ); surface.SetTexture( surface.GetTextureID( "gui/silkicons/check_on_s" ));
							surface.DrawTexturedRect( 1, ((( EBAimbot.BoneNumSelection - 1 ) * 18 ) + 2 ), 16, 16 )
					end
				end
				if EBDerma.AimbotPanelContents.WhiteListDropDownMenu.Menu and EBDerma.AimbotPanelContents.WhiteListDropDownMenu.Menu:IsValid( ) then
					EBDerma.AimbotPanelContents.WhiteListDropDownMenu.Menu.PaintOver = function( )
						local lineNum = 0
						
						for _, lineText in pairs( EBDerma.AimbotPanelContents.WhiteListDropDownMenu.Choices ) do
							for _, ply in pairs( EBAimbot.WhiteListPlayers.Table ) do
								if lineText == ply:Nick( ) then
									surface.SetDrawColor( 0, 0, 0, 255 ); surface.SetTexture( surface.GetTextureID( "gui/silkicons/check_on_s" ));
										surface.DrawTexturedRect( 1, (( lineNum * 18 ) + 2 ), 16, 16 )
								end
							end
							
							lineNum = ( lineNum + 1 )
						end
					end
				end
				if EBDerma.ESPPanelContents.ChamsOptionsDropDownMenu.Menu and EBDerma.ESPPanelContents.ChamsOptionsDropDownMenu.Menu:IsValid( ) then
					EBDerma.ESPPanelContents.ChamsOptionsDropDownMenu.Menu.PaintOver = function( )
						surface.SetDrawColor( 0, 0, 0, 255 ); surface.SetTexture( surface.GetTextureID( "gui/silkicons/check_on_s" ));
							surface.DrawTexturedRect( 1, ((( EBEsp.Wallchams.SelectedMat - 1 ) * 18 ) + 2 ), 16, 16 )
					end
				end
				if EBDerma.ESPPanelContents.ESPEntitiesDropDownMenu.Menu and EBDerma.ESPPanelContents.ESPEntitiesDropDownMenu.Menu:IsValid( ) then
					EBDerma.ESPPanelContents.ESPEntitiesDropDownMenu.Menu.PaintOver = function( )
						local lineNum = 0
						
						for _, lineText in pairs( EBDerma.ESPPanelContents.ESPEntitiesDropDownMenu.Choices ) do
							if EBEsp.ESPEntities.Table[lineText] then
								surface.SetDrawColor( 0, 0, 0, 255 ); surface.SetTexture( surface.GetTextureID( "gui/silkicons/check_on_s" ));
									surface.DrawTexturedRect( 1, (( lineNum * 18 ) + 2 ), 16, 16 )
							end
							
							lineNum = ( lineNum + 1 )
						end
					end
				end
		end; hook.Add( "Think", "EBDerma.ThinkHook", EBDerma.ThinkHook );
		
		-- function EBDerma.HUDPaintHook( )
		-- end; hook.Add( "HUDPaint", "EBDerma.HUDPaintHook", EBDerma.HUDPaintHook );
--