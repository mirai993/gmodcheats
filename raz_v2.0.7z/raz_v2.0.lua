--[[
	MOD/lua/razor.lua [#33194 (#34430), 4063362817, UID:4046935001]
	Function ;DDDD | STEAM_0:0:73336033 <188.226.158.240:27005> | [11.07.14 08:35:17PM]
	===BadFile===
]]

--[[

 _____             ______       ___
|  __ \     /\    |___  /      |__ \
| |__) |   /  \      / /  __   __ ) |
|  _  /   / /\ \    / /   \ \ / // /
| | \ \  / ____ \  / /__   \ V // /_
|_|  \_\/_/    \_\/_____|   \_/|____|


   _      ___ __  __         _   __  __      _ _   _ _            _
  /_\    / __|  \/  |___  __| | |  \/  |_  _| | |_(_) |_  __ _ __| |__
 / _ \  | (_ | |\/| / _ \/ _` | | |\/| | || | |  _| | ' \/ _` / _| / /
/_/ \_\  \___|_|  |_\___/\__,_| |_|  |_|\_,_|_|\__|_|_||_\__,_\__|_\_\

						--[ Public Edition ]--
________________________________________________________________________


Update notes:

Improved Aimbot speed. Alot. Like - really alot.
Improved Overall Speed.

]]

--[[
Prep
]]

local _G						=	table.Copy(_G);
local math						=	_G.math;
local table						=	_G.table;
local timer						=	_G.timer;
local _R						=	_G.debug.getregistry();
local GetTeam					=	_R.Player.Team;
local InVehicle					=	_R.Player.InVehicle;
local _IsAlive					=	_R.Player.Alive;
local EyePos					=	_R.Entity.EyePos;
local VecToAng					=	_R.Vector.Angle;
local GetClass					=	_G.GetClass;
local GetActiveWeapon			=	_G.GetActiveWeapon;
local _OldValid					=	_G.IsValid;
local _IsValid					=	_R.Player.IsValid;
local _randomprefix				=	_G.math.random(10,1000).."".._G.math.random(99,9999) -- I'm not using this YET!
local cam						=	_G.cam;
local SetMaterial				=	_G.SetMaterial;
local render					=	_G.render;
local DrawModel					=	_G.DrawModel;
local WorldSpaceAABB			=	_G.WorldSpaceAABB;
local LocalPlayer				=	_G.LocalPlayer;
local GetConVar					=	_G.GetConVar;
local Vector					=	_G.Vector;
local Angle						=	_G.Angle;
local Color						=	_G.Color;
local GetBonePosition			=	_G.GetBonePosition;
local LookupBone				=	_G.LookupBone;
local Me						=	_G.LocalPlayer()
local surface					=	_G.surface;
local team						=	_G.team;
local Team						=	_G.Team;
local chat						=	_G.chat;
local pairs						=	_G.pairs;
local Alive						=	_G.Alive;
local IsValid					=	_G.IsValid;
local GetModel					=	_G.GetModel;
local GetPos					=	_G.GetPos;
local Name						=	_G.Name;
local Health					=	_G.Health;
local ToScreen					=	_G.ToScreen;
local GetFriendStatus			=	_G.GetFriendStatus;
local draw						=	_G.draw;
local IsOnGround				=	_G.IsOnGround;
local IsTyping					=	_G.IsTyping;
local input						=	_G.input;
local ents						=	_G.ents;
local player					=	_G.player;
local IsPlayer					=	_G.IsPlayer;
local IsNPC						=	_G.IsNPC;
local GetAngles					=	_G.GetAngles;
local vgui						=	_G.vgui;
local GetConVarString			=	_G.GetConVarString;
local razv2						=	{}

razv2.BadCmds					=	{
	"dac_pleasebanme",
	"dac_imcheating",
	"__ac",
	"blade_client_check",
	"blade_client_detected_message",
	"disconnect",
	"exit",
	"unbindall",
	"retry",
}

razv2.skeletonbones = {
	-- Head to legs
	{ B = "ValveBiped.Bip01_Head1", Bs = "ValveBiped.Bip01_Neck1" },
	{ B = "ValveBiped.Bip01_Neck1", Bs = "ValveBiped.Bip01_Spine4" },
	{ B = "ValveBiped.Bip01_Spine4", Bs = "ValveBiped.Bip01_Spine2" },
	{ B = "ValveBiped.Bip01_Spine2", Bs = "ValveBiped.Bip01_Spine1" },
	{ B = "ValveBiped.Bip01_Spine1", Bs = "ValveBiped.Bip01_Pelvis" },
	-- Left Leg
	{ B = "ValveBiped.Bip01_Pelvis", Bs = "ValveBiped.Bip01_L_Thigh" },
	{ B = "ValveBiped.Bip01_L_Thigh", Bs = "ValveBiped.Bip01_L_Calf" },
	{ B = "ValveBiped.Bip01_L_Calf", Bs = "ValveBiped.Bip01_L_Foot" },
	{ B = "ValveBiped.Bip01_L_Foot", Bs = "ValveBiped.Bip01_L_Toe0" },
	-- Right Leg
	{ B = "ValveBiped.Bip01_Pelvis", Bs = "ValveBiped.Bip01_R_Thigh" },
	{ B = "ValveBiped.Bip01_R_Thigh", Bs = "ValveBiped.Bip01_R_Calf" },
	{ B = "ValveBiped.Bip01_R_Calf", Bs = "ValveBiped.Bip01_R_Foot" },
	{ B = "ValveBiped.Bip01_R_Foot", Bs = "ValveBiped.Bip01_R_Toe0" },
	-- Left Arm
	{ B = "ValveBiped.Bip01_Spine4", Bs = "ValveBiped.Bip01_L_UpperArm" },
	{ B = "ValveBiped.Bip01_L_UpperArm", Bs = "ValveBiped.Bip01_L_Forearm" },
	{ B = "ValveBiped.Bip01_L_Forearm", Bs = "ValveBiped.Bip01_L_Hand" },
	-- Right Arm
	{ B = "ValveBiped.Bip01_Spine4", Bs = "ValveBiped.Bip01_R_UpperArm" },
	{ B = "ValveBiped.Bip01_R_UpperArm", Bs = "ValveBiped.Bip01_R_Forearm" },
	{ B = "ValveBiped.Bip01_R_Forearm", Bs = "ValveBiped.Bip01_R_Hand" }
}

for k,v in pairs(player.GetAll()) do
	if v.Whitelisted == nil then
		v.Whitelisted = false
	end
end

--_G.require("_cv3") Not allowed on GMod Workshop

local Cvars = {
	{ Name = "razv2_chams", Value = 0 },
	{ Name = "razv2_esp", Value = 0 },
	{ Name = "razv2_bhop", Value = 0 },
	{ Name = "razv2_removeskybox", Value = 0},
	{ Name = "razv2_rapidfire", Value = 0 },
	{ Name = "razv2_skeleton", Value = 0 },
	{ Name = "razv2_propwh", Value = 0 },
	{ Name = "razv2_chatspam_message", Value = "I love RAZ v2" },
	{ Name = "razv2_chatspam", Value = 0 },
	{ Name = "razv2_traces", Value = 0 },
	{ Name = "razv2_aimbot_fov", Value = 90 },
	{ Name = "razv2_targetteam", Value = 1 },
	{ Name = "razv2_targetfriends", Value = 0 },
	{ Name = "razv2_rpact", Value = 0 },
	{ Name = "razv2_entesp", Value = 0 },
	{ Name = "razv2_fov_enable", Value = 0 },
	{ Name = "razv2_fov", Value = 90 },
	{ Name = "razv2_triggerbot", Value = 0},
	{ Name = "razv2_aimbot_autosnap", Value = 0},
	{ Name = "razv2_aimbot_autoshoot", Value = 0},
	{ Name = "razv2_fullbright", Value = 0 },
	{ Name = "razv2_flashlightspam", Value = 0 },
	{ Name = "razv2_antiaim", Value = 0},
	{ Name = "razv2_los", Value = 0 },
}

--local ForceVars   			     =	{
--	{ Name = "sv_cheats", NewName = "razv2_sv_cheats", Value = 1, CCToReplace = "bot_changeclass" },
--	{ Name = "sv_allowcslua", NewName = "razv2_sv_allowcslua", Value = 1, CCToReplace = "bot_flipout" },
--	{ Name = "mat_fullbright", NewName = "razv2_mat_fullbright", Value = 0, CCToReplace = "bot_crouch" },
--}

for k,v in _G.pairs(Cvars) do
	_G.CreateClientConVar(v.Name, v.Value)
	_G.chat.AddText(_G.Color(0,255,0), "Added Cvar: ", _G.Color(255,0,0), ""..v.Name)
end


local function _AddHook(Type, Name, Function)
	_G.chat.AddText(_G.Color(0,255,0), "Added Hook: ", _G.Color(255,0,0), Type.." | "..Name)
	_G.hook.Add(Type, Name, Function)
end

local function _RemoveHook(Type, Name)
	_G.chat.AddText(_G.Color(0,255,0), "Removed Hook: ", _G.Color(255,0,0), Type.." | "..Name)
	_G.hook.Remove(Type, Name)
end

--[[local function bypazz()
	for k,v in _G.pairs(ForceVars) do
		local newname = v.NewName
		local name = v.Name
		local oldval = _G.GetConVarNumber(name)
		local newval = v.Value
		local chto = v.CCToReplace
		local canexec = true
		if !(_G.ConVarExists(chto)) then
			canexec = false
		end
		if (canexec) then
			_G.GetConVar(name):SetName(newname)
			_G.GetConVar(newname):SetValue(newval)
			_G.GetConVar(newname):SetFlags(newval)
			_G.GetConVar(chto):SetName(name)
			_G.GetConVar(name):SetValue(oldval)
			_G.GetConVar(name):SetFlags(oldval)
			chat.AddText(Color(0,255,0), "Renamed ", Color(255,0,0), v.Name.." ",Color(0,255,0),"to ", Color(255, 0, 0), newname)
		end
	end
end

bypazz()]]

--[[
Visibility Checks
]]

local function IsVisible(e)
	local tr = {}
	tr.start = LocalPlayer():GetShootPos()
	tr.endpos = e:GetBonePosition(e:LookupBone("ValveBiped.Bip01_Head1"))
	tr.filter = {LocalPlayer(), e}
	tr.mask = MASK_SHOT
	local trace = util.TraceLine(tr)
	if (trace.Fraction == 1) then
		return true
	else
		return false
	end
end

local function IsVisibleesp(e)
	local tr = {}
	tr.start = LocalPlayer():GetShootPos()
	tr.endpos = e:GetPos() + Vector(0,0,5)
	tr.filter = {LocalPlayer(), e}
	tr.mask = MASK_SHOT
	local trace = util.TraceLine(tr)
	if (trace.Fraction == 1) then
		return true
	else
		return false
	end
end

local function getcolc(e)
	local tr = {}
	tr.start = LocalPlayer():GetShootPos()
	tr.endpos = e:GetPos() + Vector(0,0,35)
	tr.filter = {LocalPlayer(), e}
	tr.mask = MASK_SHOT
	local trace = util.TraceLine(tr)
	if (trace.Fraction == 1) then
		return Color(0,255,0)
	else
		return Color(0,0,255)
	end
end

function InFOV(e)
	local aimfov = GetConVarNumber("razv2_aimbot_fov")
	if aimfov == 360 then
		return true
	end
	local myang = LocalPlayer():GetAngles()
	infovbone = "ValveBiped.Bip01_Head1"
	local targetang = (e:GetBonePosition(e:LookupBone(infovbone)) - LocalPlayer():EyePos()):Angle()
	local calc1 = math.abs( math.NormalizeAngle( myang.y - targetang.y ) )
	local calc2 = math.abs( math.NormalizeAngle( myang.p - targetang.p ) )
	if (calc1 > aimfov || calc2 > aimfov) then
		return false
	end
	return true
end

--[[
Chams
]]

local function chams()
	for k,v in _G.pairs(_G.player.GetAll()) do
		if v:IsValid() and v:Alive() and v != _G.LocalPlayer() then
			cam.Start3D()
				local col = getcolc(v)
				v:SetMaterial("models/debug/debugwhite")
				render.SetColorModulation(col.r / 255, col.g / 255, col.b / 255)
				render.SetBlend(col.a / 255)
				v:DrawModel()
			cam.End3D()
		end
	end
end

_RemoveHook("HUDPaint", "NoChamshere")

if _G.GetConVarNumber("razv2_chams") == 1 then
	_AddHook("HUDPaint", "NoChamshere", chams)
end

_G.cvars.AddChangeCallback("razv2_chams", function()
	if _G.GetConVarNumber("razv2_chams") == 1 then
		_AddHook("HUDPaint", "NoChamshere", chams)
	else
		_RemoveHook("HUDPaint", "NoChamshere")
		cam.Start3D()
			for k,v in _G.pairs(player.GetAll()) do
				v:SetMaterial("")
				render.SetColorModulation(1,1,1)
			end
		cam.End3D()
	end
end)

--[[
Aimbot
]]

local Aimboton = false
local AimbotTarget = nil;

local function ValidCheck(targ)
	if !(targ) then return false; end
	if targ:IsPlayer() then
		if targ == Me then
			return false
		end
		if (targ.Whitelisted) then
			return false
		end
		if !(InFOV(targ)) then
			return false
		end
		if !(_IsAlive(targ)) then
			return false
		end
		if !(IsVisible(targ)) then
			return false
		end
		if targ:Team() == TEAM_SPECTATOR then
			return false
		end
		if _G.GetConVarNumber("razv2_targetteam") == 0 then
			if targ:Team() == LocalPlayer():Team() then
				return false
			end
		end
		if _G.GetConVarNumber("razv2_targetfriends") == 0 then
			if targ:GetFriendStatus() == "friend" then
				return false
			end
		end
		if targ:GetModel() == "" or targ:GetModel() == "models/error" or targ:GetModel() == "models/player" then
			return false
		end
	end
	if !(targ:IsPlayer()) then
		return
	end
	return true
end

local function gettarget(v)
	AimbotTarget = nil;
	local allplys = _G.player.GetAll()
	for i = 1, #allplys do local targ = allplys[i];
		if !(ValidCheck(targ)) then continue; end
		AimbotTarget = targ
	end

end

local function aim(ucmd)
	if !(Aimboton) then
		return
	end
	gettarget()

	if AimbotTarget != nil then
		local getpos = AimbotTarget:GetBonePosition(AimbotTarget:LookupBone("ValveBiped.Bip01_Head1"))
		local ang = VecToAng(getpos - EyePos(Me))
		ang.p, ang.y = _G.math.NormalizeAngle(ang.p), _G.math.NormalizeAngle(ang.y)
		ucmd:SetViewAngles(ang)
		if _G.GetConVarNumber("razv2_aimbot_autoshoot") == 1 then
			local EyeEnt = LocalPlayer():GetEyeTrace().Entity
			if EyeEnt:IsPlayer() then
				ucmd:SetButtons( bit.bor( ucmd:GetButtons(), IN_ATTACK ) )
			end
		end
	end
end

_G.RunConsoleCommand("razv2_aimbot_autosnap", 0)

_AddHook("CreateMove", "Raz_Ai_mb_ot", aim)

_G.concommand.Add("+razv2_aim", function()
	Aimboton = true
end)

_G.concommand.Add("-razv2_aim", function()
	Aimboton = false
end)

_G.cvars.AddChangeCallback("razv2_aimbot_autosnap", function()
	if _G.GetConVarNumber("razv2_aimbot_autosnap") == 1 then
		Aimboton = true
	else
		Aimboton = false
	end
end)

local function fuckrecoil()
	if LocalPlayer():GetActiveWeapon().Primary then
		LocalPlayer():GetActiveWeapon().Primary.Recoil = 0
		LocalPlayer():GetActiveWeapon().Primary.Cone = 0
		LocalPlayer():GetActiveWeapon().Primary.Spread = 0
		LocalPlayer():GetActiveWeapon().Primary.Force = 0
	end
end

_AddHook("CreateMove", "FuckYouRecoilRazBeatsYou", fuckrecoil)

--[[
ESP
]]


local function NOESPFUCLYOU()

	for k,v in _G.pairs(_G.player.GetAll()) do
		if v:IsValid() and v:Alive() and v != Me and v:GetModel() != "" then
			local min,max = v:WorldSpaceAABB()
			local diff = max-min
			local pos2 = Vector(0,0,0)
			local pos1 = Vector(0,0,0)
			local pos3 = Vector(0,0,0)
			local pos4 = Vector(0,0,0)
			local pos5 = Vector(0,0,diff.z)
			local pos6 = Vector(0,0,diff.z)
			local pos7 = Vector(0,0,diff.z)
			local pos8 = Vector(0,0,diff.z)

			pos1 = (pos1 + v:WorldSpaceAABB() + Vector(diff.x,diff.y,0)):ToScreen()
			pos2 = (pos2 + v:WorldSpaceAABB() + Vector(diff.x,-diff.y/14,0)):ToScreen()
			pos3 = (pos3 + v:WorldSpaceAABB() + Vector(-diff.x/14,-diff.y/14,0)):ToScreen()
			pos4 = (pos4 + v:WorldSpaceAABB() + Vector(-diff.x/14,diff.y,0)):ToScreen()
			pos5 = (pos5 + v:WorldSpaceAABB() + Vector(diff.x,diff.y,0)):ToScreen()
			pos6 = (pos6 + v:WorldSpaceAABB() + Vector(diff.x,-diff.y/14,0)):ToScreen()
			pos7 = (pos7 + v:WorldSpaceAABB() + Vector(-diff.x/14,-diff.y/14,0)):ToScreen()
			pos8 = (pos8 + v:WorldSpaceAABB() + Vector(-diff.x/14,diff.y,0)):ToScreen()

			surface.SetDrawColor(0,0,255,255)
			surface.DrawLine(pos1.x, pos1.y, pos2.x, pos2.y)
			surface.DrawLine(pos2.x, pos2.y, pos3.x, pos3.y)
			surface.DrawLine(pos3.x, pos3.y, pos4.x, pos4.y)
			surface.DrawLine(pos1.x, pos1.y, pos4.x, pos4.y)
			surface.DrawLine(pos1.x, pos1.y, pos3.x, pos3.y)
			surface.DrawLine(pos2.x, pos2.y, pos4.x, pos4.y)

			surface.SetDrawColor(team.GetColor(v:Team()))

			surface.DrawLine(pos1.x, pos1.y, pos5.x, pos5.y)
			surface.DrawLine(pos2.x, pos2.y, pos6.x, pos6.y)
			surface.DrawLine(pos3.x, pos3.y, pos7.x, pos7.y)
			surface.DrawLine(pos4.x, pos4.y, pos8.x, pos8.y)

			surface.SetDrawColor(90,20,50,255)

			surface.DrawLine(pos5.x, pos5.y, pos6.x, pos6.y)
			surface.DrawLine(pos6.x, pos6.y, pos7.x, pos7.y)
			surface.DrawLine(pos7.x, pos7.y, pos8.x, pos8.y)
			surface.DrawLine(pos5.x, pos5.y, pos8.x, pos8.y)
			surface.DrawLine(pos5.x, pos5.y, pos7.x, pos7.y)
			surface.DrawLine(pos6.x, pos6.y, pos8.x, pos8.y)

		end
	end
end


if _G.GetConVarNumber("razv2_esp") == 1 then
	_AddHook("HUDPaint", "raz_no_box_esp_fucku", NOESPFUCLYOU)
end

_G.cvars.AddChangeCallback("razv2_esp", function()
	if _G.GetConVarNumber("razv2_esp") == 1 then
		_AddHook("HUDPaint", "raz_no_box_esp_fucku", NOESPFUCLYOU)
	else
		_RemoveHook("HUDPaint", "raz_no_box_esp_fucku")
	end
end)

local function NOESPINFOFUCKU()
	for k,v in pairs(_G.player.GetAll()) do
		if v:IsValid() and v:Alive() and v != Me then
			local Position = ( v:GetPos() + Vector( 0,0,60 ) ):ToScreen()
			local Position2 = ( v:GetPos() + Vector( 0,0,80 ) ):ToScreen()
			local Position3 = ( v:GetPos() + Vector( 0,0,100 ) ):ToScreen()
			local Position4 = ( v:GetPos() + Vector( 0,0,120 ) ):ToScreen()
			local Position5 = ( v:GetPos() + Vector( 0,0,120 ) ):ToScreen()
			local pname = " "
			if v:Health() > 0 and v:GetActiveWeapon():IsValid() and v:GetActiveWeapon() then
				pname = v:GetActiveWeapon():GetPrintName()
			else
				pname = ""
			end
			draw.SimpleText(v:Name(), "Default",Position.x, Position.y, Color(255,0,0,255), 1)
			draw.SimpleText("Health: "..v:Health(), "Default", Position2.x, Position2.y, Color(150,0,255,255), 1)
			draw.SimpleText("Weapon: "..pname, "Default",  Position3.x, Position3.y, Color(255,0,255,255), 1)
			if v:GetFriendStatus() == "friend" then
				draw.SimpleText("FRIEND", "Default",  Position4.x, Position4.y, Color(150,255,150,255), 1)
			end
		end
	end
end

if _G.GetConVarNumber("razv2_esp") == 1 then
	_AddHook("HUDPaint", "RAZ_NO_ESP_INFO_FUCK_OFF", NOESPINFOFUCKU)
end

_G.cvars.AddChangeCallback("razv2_esp", function()
	if _G.GetConVarNumber("razv2_esp") == 1 then
		_AddHook("HUDPaint", "RAZ_NO_ESP_INFO_FUCK_OFF", NOESPINFOFUCKU)
	else
		_RemoveHook("HUDPaint", "RAZ_NO_ESP_INFO_FUCK_OFF")
	end
end)

--[[
BHop
]]

local function NOBHOPUFUCK(ucmd)
	if !(input.IsKeyDown( KEY_SPACE )) then
		return
	end
	if !(_G.LocalPlayer():IsOnGround()) then
		ucmd:SetButtons(bit.band(ucmd:GetButtons(), bit.bnot(IN_JUMP)))
	end
end

if _G.GetConVarNumber("razv2_bhop") == 1 then
	_AddHook("CreateMove", "RAZ_NOBHOP_HERE_UFUCK", NOBHOPUFUCK)
end

_G.cvars.AddChangeCallback("razv2_bhop", function()
	if _G.GetConVarNumber("razv2_bhop") == 1 then
		_AddHook("CreateMove", "RAZ_NOBHOP_HERE_UFUCK", NOBHOPUFUCK)
	else
		_RemoveHook("CreateMove", "RAZ_NOBHOP_HERE_UFUCK")
	end
end)

--[[
Remove The Skybox
]]
--[[
local function FUCKUIDONTREMOVESKYBOX()
	GetConVar("gl_clear"):SetValue(1)
	GetConVar("r_drawskybox"):SetValue(0)
	GetConVar("r_3dsky"):SetValue(0)
end

if _G.GetConVarNumber("razv2_removeskybox") == 1 then
	_AddHook("Think", "RemoveSkybox", FUCKUIDONTREMOVESKYBOX)
end

_G.cvars.AddChangeCallback("razv2_removeskybox", function()
	if _G.GetConVarNumber("razv2_removeskybox") == 1 then
		_AddHook("Think", "RemoveSkybox", FUCKUIDONTREMOVESKYBOX)
	else
		GetConVar("gl_clear"):SetValue(0)
		GetConVar("r_drawskybox"):SetValue(1)
		GetConVar("r_3dsky"):SetValue(1)
		_RemoveHook("Think", "RemoveSkybox")
	end
end)]]

--[[
Rapidfire
]]

local function fukidontrapidfire()
	if !(LocalPlayer():IsTyping()) then
		if !(doit) then
			_G.RunConsoleCommand("-attack")
		end
		if input.IsMouseDown(MOUSE_LEFT) and (doit) then
			_G.RunConsoleCommand("+attack")
			doit = false
		elseif input.IsMouseDown(MOUSE_LEFT) and !(doit) then
			_G.RunConsoleCommand("-attack")
			doit = true
		end
	end
end

if _G.GetConVarNumber("razv2_rapidfire") == 1 then
	_AddHook("Think", "TotallyNoRapidfire", fukidontrapidfire)
end

_G.cvars.AddChangeCallback("razv2_rapidfire", function()
	if _G.GetConVarNumber("razv2_rapidfire") == 1 then
		_AddHook("Think", "TotallyNoRapidfire", fukidontrapidfire)
	else
		_RemoveHook("Think", "TotallyNoRapidfire")
	end
end)

--[[
Speedhack
]]
--[[
concommand.Add("+razv2_speedhack", function()
	GetConVar("host_framerate"):SetValue(4)
end)

concommand.Add("-razv2_speedhack", function()
	GetConVar("host_framerate"):SetValue(0)
end)
]]
--[[
Skeleton
]]

local function skeleton()
	for k,v in pairs(_G.player.GetAll()) do
		if v:GetModel() != "models/error.mdl" and v:GetModel() != "models/player.mdl" and v:GetModel() != "" and v:Alive() and v:IsValid() and v != Me then
			for _, b in pairs(razv2.skeletonbones) do
				if v:Team() == TEAM_SPECTATOR then
					return
				end
				local spos1, spos2 = v:GetBonePosition( v:LookupBone( b.B ) ):ToScreen(), v:GetBonePosition( v:LookupBone( b.Bs ) ):ToScreen()
				surface.SetDrawColor(team.GetColor(v:Team()))
				surface.DrawLine(spos1.x, spos1.y, spos2.x, spos2.y)
			end
		end
	end
end

if _G.GetConVarNumber("razv2_skeleton") == 1 then
	_AddHook("HUDPaint", "NotASingleSkeletonDrawn", skeleton)
end

_G.cvars.AddChangeCallback("razv2_skeleton", function()
	if _G.GetConVarNumber("razv2_skeleton") == 1 then
		_AddHook("HUDPaint", "NotASingleSkeletonDrawn", skeleton)
	else
		_RemoveHook("HUDPaint", "NotASingleSkeletonDrawn")
	end
end)

--[[
Admin Check
]]

local function CheckAdmin(e)
	if e:IsAdmin() and !(e:IsSuperAdmin()) then
		return "Admin"
	end
	if e:IsSuperAdmin() then
		return "Superadmin"
	end
	return "User"
end

local function ShowMeTheAdmins()
	for k,v in pairs(_G.player.GetAll()) do
		if v:IsValid() and v != Me then
			local adminstat = CheckAdmin(v)
			print(v:Name().." - "..adminstat)
		end
	end
end

concommand.Add("razv2_admincheck", ShowMeTheAdmins)

--[[
Whitelist
taken over from RAZ v1
]]


local whitelist = {}

local function shitlist()
	local frame = vgui.Create("DFrame")
	frame:SetSize(500,500)
	frame:Center()
	frame:MakePopup()
	frame:SetTitle("RAZ v2 || Shitlist")

	local list1 = vgui.Create("DListView")
	list1:SetParent(frame)
	list1:SetPos(5, 40)
	list1:SetSize(230, 450)
	list1:SetMultiSelect(false)
	list1:AddColumn("Name")
	list1:AddColumn("SteamID")

	local list2 = vgui.Create("DListView")
	list2:SetParent(frame)
	list2:SetPos(260, 40)
	list2:SetSize(230, 450)
	list2:SetMultiSelect(false)
	list2:AddColumn("Name")
	list2:AddColumn("SteamID")

	local label = vgui.Create("DLabel")
	label:SetParent(frame)
	label:SetPos(80,25)
	label:SetText("Not on whitelist")
	label:SizeToContents()

	local label2 = vgui.Create("DLabel")
	label2:SetParent(frame)
	label2:SetPos(350,25)
	label2:SetText("On whitelist")
	label2:SizeToContents()

	local at = vgui.Create("DButton",frame)
	at:SetSize(20,20)
	at:SetPos(240,250)
	at:SetText("+")
	at.DoClick = function()
		if list1:GetSelectedLine() != nil then
			local i1 = list1:GetLine(list1:GetSelectedLine()):GetValue(2)
			local i2 = list1:GetLine(list1:GetSelectedLine()):GetValue(1)
			for k,v in pairs(player.GetAll()) do
				if v:Name() == i2 then
					if !(v.Whitelisted) then
						v.Whitelisted = true
						list1:RemoveLine(list1:GetSelectedLine())
						list2:AddLine(i2, i1)
					end
				end
			end
		end
	end

	local rm = vgui.Create("DButton",frame)
	rm:SetSize(20,20)
	rm:SetPos(240,270)
	rm:SetText("-")
	rm.DoClick = function()
		if list2:GetSelectedLine() != nil then
			local i1 = list2:GetLine(list2:GetSelectedLine()):GetValue(2)
			local i2 = list2:GetLine(list2:GetSelectedLine()):GetValue(1)
			for k,v in pairs(player.GetAll()) do
				if v:Name() == i2 then
					if (v.Whitelisted) then
						v.Whitelisted = false
						list2:RemoveLine(list2:GetSelectedLine())
						list1:AddLine(i2, i1)
					end
				end
			end
		end
	end


	for k,v in pairs(player.GetAll()) do
		if !(v:SteamID() == LocalPlayer():SteamID()) then
			if !(v.Whitelisted) then
				list1:AddLine(v:Name(), v:SteamID())
			else
				list2:AddLine(v:Name(), v:SteamID())
			end
		end
	end
end

_G.concommand.Add("razv2_shitlist", shitlist)

--[[
PropWH
Taken over and improved from RAZ v1
]]

local function propwh()
	for k,v in pairs(_G.ents.GetAll()) do
		if v:GetClass() == "prop_physics" and v:IsValid() then
			cam.Start3D()
				v:SetMaterial("models/wireframe")
				local col = Color(255, 93, 0, 255)
				render.SetColorModulation(col.r / 255, col.g / 255, col.b / 255)
				render.SetBlend(col.a / 255)
				v:DrawModel()
			cam.End3D()
		end
	end
end


if _G.GetConVarNumber("razv2_propwh") == 1 then
	_AddHook("HUDPaint", "NoPropWHhere", propwh)
end

_G.cvars.AddChangeCallback("razv2_propwh", function()
	if _G.GetConVarNumber("razv2_propwh") == 1 then
		_AddHook("HUDPaint", "NoPropWHhere", propwh)
	else
		_RemoveHook("HUDPaint", "NoPropWHhere")
		cam.Start3D()
			for k,v in pairs(_G.ents.GetAll()) do
				if v:IsValid() and v:GetClass() == "prop_physics" then
					v:SetMaterial("")
					render.SetColorModulation(1,1,1)
					render.SetBlend(1)
				end
			end
		cam.End3D()
	end
end)

--[[
Chatspam
]]

_G.RunConsoleCommand("razv2_chatspam", 0)

local delaysay = false

local function spamthechat()
	local saymsg = GetConVarString("razv2_chatspam_message")
	if saymsg == nil then
		saymsg = "I love RAZ v2"
	end
	if !(delaysay) then
		delaysay = true
		timer.Simple(2, function()
			delaysay = false
		end)
		LocalPlayer():ConCommand("say "..saymsg)
	end
end

if _G.GetConVarNumber("razv2_chatspam") == 1 then
	_AddHook("Think", "ImAChatspam", propwh)
end

_G.cvars.AddChangeCallback("razv2_chatspam", function()
	if _G.GetConVarNumber("razv2_chatspam") == 1 then
		_AddHook("Think", "ImAChatspam", spamthechat)
		delaysay = false
	else
		_RemoveHook("Think", "ImAChatspam")
		delaysay = false
	end
end)

--[[
Traces
taken from RAZ v1
]]

local function traceline()
	for k,v in pairs(_G.player.GetAll()) do
		if _G.GetConVarNumber("razv2_targetteam") == 0 then
			if v:Team() == LocalPlayer():Team() and (v.Targetable) then
				v.Targetable = false
			else
				v.Targetable = true
			end
		end
		if _G.GetConVarNumber("razv2_targetfriends") == 0 then
			if v:GetFriendStatus() == "friend" then
				v.Targetable = false
			else
				v.Targetable = true
			end
		end
		if !(v.Targetable) then
			return
		end
		if (v.Whitelisted) then
			v.Targetable = false
		else
			v.Targetable = true
		end
		if !(v.Targetable) then
			return
		end
		if (v.Targetable) then
			if v:IsValid() and v != LocalPlayer() and v:Alive() and IsVisible(v) and InFOV(v) and v:GetModel() != "" and v:GetModel() != "models/error.mdl" and v:GetModel() != "models/player.mdl" then
				local TBone = ""
				local TBonepos = ""
				TBone = v:LookupBone("ValveBiped.Bip01_Head1")
				TBonepos = (v:GetBonePosition(TBone)):ToScreen()
				surface.SetDrawColor(255,0,0,255)
				surface.DrawLine(ScrW() / 2, ScrH() / 2, TBonepos.x, TBonepos.y)
			end
		end
	end
end

if _G.GetConVarNumber("razv2_traces") == 1 then
	_AddHook("HUDPaint", "WhatsATrace", traceline)
end

_G.cvars.AddChangeCallback("razv2_traces", function()
	if _G.GetConVarNumber("razv2_traces") == 1 then
		_AddHook("HUDPaint", "WhatsATrace", traceline)
	else
		_RemoveHook("HUDPaint", "WhatsATrace")
		for k,v in pairs(player.GetAll()) do
			v.Targetable = nil
		end
	end
end)

--[[
Entesp
ported from RAZ v1
]]

trackents = { -- Add Entities to track here, or use ingame function.
"printer",
"spawned_",
"weapon_ttt_awp",
"weapon_jihadbomb",
"weapon_ttt_death_station",
"weapon_ttt_flaregun",
"weapon_ttt_knife",
"weapon_ttt_phammer",
"weapon_ttt_push",
"weapon_perp_glock",
"m9k_ammo_",
"weapon_ttt_health_station",
"weapon_ttt_c4",
"weapon_ttt_decoy",
}



local espcolor = ""

local function entityesp()
	for k,v in pairs(ents.GetAll()) do
		for i,s in pairs(trackents) do
			if v:IsValid() and string.find(v:GetClass(),s) then
				local ang = Angle(0, v:GetAngles().y, 0)
				local i,x = v:WorldSpaceAABB()
				local diff = x-i
				local pos = (v:GetPos()+Vector(0,0,20)):ToScreen()
				local pos2 = Vector(0,0,0)
				local pos1 = Vector(0,0,0)
				local pos3 = Vector(0,0,0)
				local pos4 = Vector(0,0,0)
				local pos5 = Vector(0,0,diff.z)
				local pos6 = Vector(0,0,diff.z)
				local pos7 = Vector(0,0,diff.z)
				local pos8 = Vector(0,0,diff.z)

				pos1 = (pos1 + v:WorldSpaceAABB() + Vector(diff.x,diff.y,0)):ToScreen()
				pos2 = (pos2 + v:WorldSpaceAABB() + Vector(diff.x,-diff.y/14,0)):ToScreen()
				pos3 = (pos3 + v:WorldSpaceAABB() + Vector(-diff.x/14,-diff.y/14,0)):ToScreen()
				pos4 = (pos4 + v:WorldSpaceAABB() + Vector(-diff.x/14,diff.y,0)):ToScreen()
				pos5 = (pos5 + v:WorldSpaceAABB() + Vector(diff.x,diff.y,0)):ToScreen()
				pos6 = (pos6 + v:WorldSpaceAABB() + Vector(diff.x,-diff.y/14,0)):ToScreen()
				pos7 = (pos7 + v:WorldSpaceAABB() + Vector(-diff.x/14,-diff.y/14,0)):ToScreen()
				pos8 = (pos8 + v:WorldSpaceAABB() + Vector(-diff.x/14,diff.y,0)):ToScreen()
				surface.SetDrawColor(0,0,0)

				surface.DrawLine(pos1.x,pos1.y,pos2.x,pos2.y)
				surface.DrawLine(pos2.x,pos2.y,pos3.x,pos3.y)
				surface.DrawLine(pos3.x,pos3.y,pos4.x,pos4.y)
				surface.DrawLine(pos1.x,pos1.y,pos4.x,pos4.y)

				surface.SetDrawColor(255,0,0)

				surface.DrawLine(pos1.x,pos1.y,pos5.x,pos5.y)
				surface.DrawLine(pos2.x,pos2.y,pos6.x,pos6.y)
				surface.DrawLine(pos3.x,pos3.y,pos7.x,pos7.y)
				surface.DrawLine(pos4.x,pos4.y,pos8.x,pos8.y)

				surface.SetDrawColor(0,0,255)

				surface.DrawLine(pos5.x,pos5.y,pos6.x,pos6.y)
				surface.DrawLine(pos6.x,pos6.y,pos7.x,pos7.y)
				surface.DrawLine(pos7.x,pos7.y,pos8.x,pos8.y)
				surface.DrawLine(pos8.x,pos8.y,pos5.x,pos5.y)

				cam.Start3D()
					v:SetMaterial("models/wireframe")
					if !(IsVisibleesp(v)) then
						espcolor = Color(255,191,0,255)
					else
						espcolor = Color(63,127,0,255)
					end
					render.SetColorModulation(espcolor.r / 255, espcolor.g / 255, espcolor.b / 255)
					render.SetBlend( espcolor.a / 255 )
					v:DrawModel()
				cam.End3D()
				draw.SimpleText(v:GetClass(), "Default", pos.x, pos.y, Color(255,255,255,255), 1)
			end
		end
	end
end

if _G.GetConVarNumber("razv2_entesp") == 1 then
	_AddHook("HUDPaint", "Ent-ESPZ", entityesp)
end

_G.cvars.AddChangeCallback("razv2_entesp", function()
	if _G.GetConVarNumber("razv2_entesp") == 1 then
		_AddHook("HUDPaint", "Ent-ESPZ", entityesp)
	else
		_RemoveHook("HUDPaint", "Ent-ESPZ")
		for k,v in pairs(ents.GetAll()) do
			for i,s in pairs(trackents) do
				if v:IsValid() and string.find(v:GetClass(),s) then
					cam.Start3D()
						v:SetMaterial("")
						render.SetColorModulation(1,1,1)
						render.SetBlend(1)
					cam.End3D()
				end
			end
		end
	end
end)


local function addentity()
	if LocalPlayer():GetEyeTrace().Entity:IsValid() and !(LocalPlayer():GetEyeTrace().Entity:IsPlayer()) then
		table.insert(trackents, LocalPlayer():GetEyeTrace().Entity:GetClass())
		print("Added "..LocalPlayer():GetEyeTrace().Entity:GetClass().." to the entity list.")
	end
end

local function removeentity()
	if LocalPlayer():GetEyeTrace().Entity:IsValid() and !(LocalPlayer():GetEyeTrace().Entity:IsPlayer()) then
		for k,v in pairs(trackents) do
			if v == LocalPlayer():GetEyeTrace().Entity:GetClass() then
				table.remove(trackents,k)
				print("Removed "..LocalPlayer():GetEyeTrace().Entity:GetClass().." from the entity list.")
				cam.Start3D()
					for i,s in pairs(ents.GetAll()) do
						if s:GetClass() == LocalPlayer():GetEyeTrace().Entity:GetClass() then
							s:SetMaterial("")
							render.SetColorModulation(1,1,1)
							render.SetBlend(1)
						end
					end
				cam.End3D()
			end
		end
	end
end

_G.concommand.Add("razv2_entesp_add", addentity)
_G.concommand.Add("razv2_entesp_remove", removeentity)

--[[
RP-Act
]]

local actdelay = false

local acttable = {
	{ Act = ACT_GMOD_TAUNT_LAUGH, Delay = 6.3 },
	{ Act = ACT_GMOD_TAUNT_PERSISTENCE, Delay = 3.1 },
	{ Act = ACT_GMOD_GESTURE_DISAGREE, Delay = 2.7 },
	{ Act = ACT_GMOD_GESTURE_AGREE, Delay = 2.7},
	{ Act = ACT_GMOD_GESTURE_WAVE, Delay = 3.7 },
	{ Act = ACT_GMOD_GESTURE_BECON, Delay = 3.4 },
	{ Act = ACT_GMOD_TAUNT_MUSCLE, Delay = 13 },
	{ Act = ACT_GMOD_GESTURE_BOW, Delay = 3 },
}

local function rpact()
	if GAMEMODE.Name != "DarkRP" then
		LocalPlayer():ChatPrint("You're not playing DarkRP!")
		_G.RunConsoleCommand("razv2_rpact", 0)
		return
	end
	if !(actdelay) then
		local act = table.Random(acttable)
		_G.RunConsoleCommand("_DarkRP_DoAnimation", act.Act)
		actdelay = true
		timer.Simple(act.Delay, function()
			actdelay = false
		end)
	end
end

RunConsoleCommand("razv2_rpact", 0)

cvars.AddChangeCallback("razv2_rpact", function()
	if _G.GetConVarNumber("razv2_rpact") == 1 then
		_AddHook("Think", "rp_act", rpact)
		actdelay = false
	else
		_RemoveHook("Think", "rp_act", rpact)
		actdelay = false
	end
end)

--[[
Reset function
]]

concommand.Add("razv2_reseteverything", function()
	for k,v in pairs(Cvars) do
		RunConsoleCommand(v.Name, v.Value)
	end
end)

--[[
FOV-Changer
]]

local function ChangeMyFov(ply, ori, ang, fov)
	local view = {}
	view.fov = _G.GetConVarNumber("razv2_fov")
	return view
end

if _G.GetConVarNumber("razv2_fov_enable") == 1 then
	_AddHook("CalcView", "OPFOVChanger", ChangeMyFov)
end

_G.cvars.AddChangeCallback("razv2_fov_enable", function()
	if _G.GetConVarNumber("razv2_fov_enable") == 1 then
		_AddHook("CalcView", "OPFOVChanger", ChangeMyFov)
	else
		_RemoveHook("CalcView", "OPFOVChanger")
	end
end)

--[[
Triggerbot
]]

local function trigger(ucmd)
	if !(_G.GetConVarNumber("razv2_triggerbot") == 1) then
		return
	end
	local EyeEnt = LocalPlayer():GetEyeTrace().Entity
	if EyeEnt:IsPlayer() then
		ucmd:SetButtons( bit.bor( ucmd:GetButtons(), IN_ATTACK ) )
	end
end


_AddHook( "CreateMove", "ThisIsNoTriggerbot", trigger)

--[[
Fullbright
]]
--[[
local function fullbright()
	_G.GetConVar("razv2_mat_fullbright"):SetValue(1)
end

if _G.GetConVarNumber("razv2_fullbright") == 1 then
	_AddHook("Think", "Fullbright", fullbright)
end

_G.cvars.AddChangeCallback("razv2_fullbright", function()
	if _G.GetConVarNumber("razv2_fullbright") == 1 then
		_AddHook("Think", "Fullbright", fullbright)
	else
		_RemoveHook("Think", "Fullbright")
		_G.GetConVar("razv2_mat_fullbright"):SetValue(0)
	end
end)]]

--[[
Flashlight Spam
Also taken over from RAZ v1
]]

local function spamflashlight()
	if LocalPlayer():IsTyping() then
		return
	end
	if input.IsKeyDown(KEY_F) then
		timer.Simple(0.01, function()
			RunConsoleCommand("impulse", "100")
		end)
		timer.Simple(0.02, function()
			RunConsoleCommand("impulse", "100")
		end)
	end
end

if _G.GetConVarNumber("razv2_flashlightspam") == 1 then
	_AddHook("CreateMove", "IlikeMyFlashlight", spamflashlight)
end

_G.cvars.AddChangeCallback("razv2_flashlightspam", function()
	if _G.GetConVarNumber("razv2_flashlightspam") == 1 then
		_AddHook("CreateMove", "IlikeMyFlashlight", spamflashlight)
	else
		_RemoveHook("CreateMove", "IlikeMyFlashlight")
	end
end)

--[[
Anti-Aim
]]

local function aa(ucmd)
	if _G.GetConVarNumber("razv2_antiaim") == 0 then
		return
	end
	if !(input.IsMouseDown(MOUSE_LEFT)) and !(input.IsMouseDown(MOUSE_RIGHT)) then
		ucmd:SetViewAngles(Angle(-181, ucmd:GetViewAngles().y, 0))
	end
end

_AddHook("CreateMove", "DontAimbotMe", aa)

--[[
Aim Line
]]

local function aimline()
	for k,v in pairs(player.GetAll()) do
		if v:IsValid() and v:Alive() and v != LocalPlayer() then
			local ang = Angle( 0, v:EyeAngles().y, 0 )
			local boonepos = (v:GetShootPos()):ToScreen()
			local booneendpos = Vector(100,0,0)
			booneendpos:Rotate( ang )
			booneendpos = (booneendpos + v:GetShootPos()):ToScreen()
			surface.SetDrawColor(255,0,0,255)
			surface.DrawLine(boonepos.x, boonepos.y, booneendpos.x, booneendpos.y)
		end
	end
end

if _G.GetConVarNumber("razv2_los") == 1 then
	_AddHook("HUDPaint", "LineOfSight", aimline)
end

_G.cvars.AddChangeCallback("razv2_los", function()
	if _G.GetConVarNumber("razv2_los") == 1 then
		_AddHook("HUDPaint", "LineOfSight", aimline)
	else
		_RemoveHook("HUDPaint", "LineOfSight")
	end
end)
