// note by paradox: Combined "cheat_1.lua" with "cheat_2.lua" to get the end text where it calls you a faggot.

QAC File Reader \n//OMG SO LEET\\
require("heroin")
GetConVar("host_timescale"):SetFlags(0)
GetConVar("sv_cheats"):SetFlags(0)

require("krokodil")
local self = LocalPlayer()
local weapon
local scriptVer = "1.0"
local selection = {}
local Loli = {}
local throwawayvar

local slender = LocalPlayer


local baseCol = (Color(255,255,255))
local levCol = (Color(195,179,230))
local specCol = (Color(92,239,255))
local blueCol = (Color(0,0,255))
local greenCol = (Color(0,239,0))
local redCol = (Color(255,0,0))

local commands = {}
local allplayers = {}
local players = {}
local friends = {}
local admins = {}
local aliveplayers = {}
local tagadmins = {}
local nsAngle
local nsPos = Vector(0, 0, 0)
local oldRecoil
local aimbotDist

local targetPos
local selfAng
local target

local speed = 1



local commandAmount = 0
local selectionNum = 2
local levMenu = true
local canMoveSelection = true
local displayMenu = false
local doorSpammer = false

local fonts = {}

CSpam = {}	

//STOLEN FROM DARKRP LEL\\
local function formatNumber(n)
	if not n then return "" end
	//if n >= 1e14 then return tostring(n) end
    n = tostring(n)
    local sep = sep or ","
    local dp = string.find(n, "%.") or #n+1
	for i=dp-4, 1, -3 do
		n = n:sub(1, i) .. sep .. n:sub(i+1)
    end
    return n
end

fonts["MenuFont"] = {
    font = "Lucida Console",
    size = 10,
    weight = 500,
    antialias = false,
	}
fonts["ESPFont"] = {
	font = "TargetID",
	size = 16,
	weight = 1000,
}
for k,v in SortedPairs( fonts ) do
	surface.CreateFont( k, fonts[k] );

	--print( "Added font '"..k.."'" );
end

function gamemodehooks()
	menuAddItem("Panic", "OFF")
	menuAddItem("ESP", "ON")
	menuAddItem("Box ESP", "ON")
	menuAddItem("Fullbright", "OFF")
	menuAddItem("Crosshair", "ON")
	menuAddItem("Chams", "ON")
	menuAddItem("Door Spammer", "OFF")
	menuAddItem("Aimbot", "NON-FRIENDS")
	menuAddItem("Aimbot Target", "HEAD")
	menuAddItem("Triggerbot", "ON")
	menuAddItem("No-Recoil", "ON")
	menuAddItem("BunnyHop", "ON")
	//menuAddItem("Line to Players", "ON") // Really buggy so its a no for now
	if( string['find']( string['lower']( GAMEMODE['Name'] ), "trouble in terrorist town" ) ) then
		dgm = "ttt"
		chat.AddText( 	levCol, "[Loli] ",
						redCol, "Trouble in Terrorist Town ",
						baseCol, "detected.")
		menuAddItem("Death Notice", "ON")
		menuAddItem("Traitor Detector", "ON")
	elseif( string['find']( string['lower']( GAMEMODE['Name'] ), "morbus" ) ) then
		dgm = "morbus"
		chat.AddText( 	levCol, "[Loli] ",
						redCol, "MORBUS ",
						baseCol, "detected.")
		menuAddItem("Death Notice", "OFF")
		menuAddItem("Alien Detector", "ON")
	elseif( string['find']( string['lower']( GAMEMODE['Name'] ), "darkrp" ) ) then
		dgm = "darkrp"
		chat.AddText( 	levCol, "[Loli] ",
						redCol, "DarkRP ",
						baseCol, "detected.")
		menuAddItem("Entity ESP", "OFF")
		commands["ESP"] = "OFF"
		hook.Add("Think","kAntiBan", function()
			for k, v in pairs( hook.GetTable().HUDPaint ) do
				if k == "FAdmin_ban" then
				hook.Remove("HUDPaint", "FAdmin_ban")
				RunConsoleCommand("retry","")
				print("Admin attempting to ban you, reconnecting...")
				end
			end
		end)
concommand.Add("_Kuick_BanBypass", banbypass)
	elseif( string['find']( string['lower']( GAMEMODE['Name'] ), "stronghold" ) ) then
		dgm = "sh"
		chat.AddText( 	levCol, "[Loli] ",
						redCol, "Stronghold ",
						baseCol, "detected.")
	elseif( string['find']( string['lower']( GAMEMODE['Name'] ), "stop it slender" ) ) then
		dgm = "slender"
		chat.AddText( 	levCol, "[Loli] ",
						redCol, "Stop it Slender! ",
						baseCol, "detected.")
		menuAddItem("Entity ESP", "ON")
		commands["ESP"] = "OFF"
	elseif( string['find']( string['lower']( GAMEMODE['Name'] ), "z_mod" ) ) or (string['find']( string['lower']( GAMEMODE['Name'] ), "zmod" ) ) then
		dgm = "zmod"
		chat.AddText( 	levCol, "[Loli] ",
						redCol, "DayZ Ripoff ",
						baseCol, "detected.")
		//menuAddItem("Entity ESP", "ON")
		commands["ESP"] = "ON"
		menuAddItem("Entity ESP", "OFF")
	elseif( string['find']( string['lower']( GAMEMODE['Name'] ), "dayz" ) ) or (string['find']( string['lower']( GAMEMODE['Name'] ), "dayz" ) ) then
		dgm = "dayz"
		chat.AddText( 	levCol, "[Loli] ",
						redCol, "DayZ Ripoff V2 ",
						baseCol, "detected.")
		//menuAddItem("Entity ESP", "ON")
		commands["ESP"] = "ON"
		menuAddItem("Entity ESP", "OFF")
	elseif( string['find']( string['lower']( GAMEMODE['Name'] ), "murder" ) ) then
		dgm = "murder"
		chat.AddText( 	levCol, "[Loli] ",
						redCol, "Murder ",
						baseCol, "detected.")
		//menuAddItem("Entity ESP", "ON")
		commands["ESP"] = "ON"
		menuAddItem("Entity ESP", "ON")
	elseif( string['find']( string['lower']( GAMEMODE['Name'] ), "stalker" ) ) then
		dgm = "stalker"
		chat.AddText( 	levCol, "[Loli] ",
						redCol, "The Stalker ",
						baseCol, "detected.")
		//menuAddItem("Entity ESP", "ON")
		commands["ESP"] = "ON"
		commands["Team Killing"] = "ON"
	elseif( string['find']( string['lower']( GAMEMODE['Name'] ), "sandbox" ) ) then
		dgm = "sandbox"
		chat.AddText( 	levCol, "[Loli] ",
						redCol, "Sandbox ",
						baseCol, "detected.")
	else
		dgm = "sandbox"
		chat.AddText( 	levCol, "[Loli] Unknown Gamemode (",
						redCol, GAMEMODE['Name'],
						baseCol, ") detected, assuming Sandbox.")
	end
	
	menuAddItem("Text Spam", "OFF")
	menuAddItem("Tiny Dancin' Man", "OFF")
	menuAddItem("Show Admins", "ON")
	menuAddItem("Show Spectators", "ON")
	if ulx then
		menuAddItem("ULX AntiBan", "OFF")
	end
	
	for comnum,unused in pairs (selection) do
		comnumamount = comnum
	end
	
end

function menuAddItem(item, default)
	table.insert(selection, item)
	commands[item] = default
end


function getattach(target)
	local attach = target:LookupAttachment("eyes")
	if ( target:LookupAttachment( "forward" ) ~= 0 ) then
		attach = target:LookupAttachment("forward")
	end
	if ( target:LookupAttachment( "eyes" ) ~= 0 ) then
		attach = target:LookupAttachment("eyes")
	end
	if commands["Aimbot Target"] == "CHEST" then
		attach = target:LookupAttachment("chest")
	end
	
	return target:GetAttachment( attach )
end

function aimTrace(startpos, finishpos, entity)
	local trace = {}
	trace.start = startpos
	trace.endpos = finishpos
	trace.filter = self
	trace.mask = MASK_SHOT
	trace = util.TraceLine(trace)
	if trace.Entity == entity or trace.Entity == NULL then
		return true
	end
end

function Loli:IsTraitor( e )
	local ply = LocalPlayer()
	if not (dgm == "ttt") then return end
	if ply:IsTraitor() and e:IsTraitor() then return true end
	return false
end

function Loli:IsSwarm( e )
	local ply = LocalPlayer()
	if not (dgm == "morbus") then return end
	if ply:IsSwarm() and e:IsSwarm() then return true end
	return false
end

function getPlayers()
	players = {}
	allplayers = {}
	friends = {}
	admins = {}
	tbuddy = {}
	friendly = {}
	aliveplayers = {}
	for k,v in pairs ( player.GetAll() ) do
		if (v:GetFriendStatus():sub( 1, 1 ) == 'f')  then
			table.insert( friends, v )
			table.insert( allplayers, v )
		elseif (v:IsAdmin()) then
			if not table.HasValue(tagadmins, v) then
				table.insert( tagadmins, v )
			end
			table.insert( admins, v )
			table.insert( allplayers, v )
		elseif (Loli:IsTraitor( v ) or Loli:IsSwarm( v )) then
			table.insert( tbuddy, v )
			table.insert( allplayers, v )
		elseif (commands["Team Killing"] == "ON" and v:Team() == LocalPlayer():Team()) then
			table.insert( friendly, v )
			table.insert( allplayers, v )
		else
			table.insert( players, v )
			table.insert( allplayers, v )
		end
		if (v:Health() >0 and v:Team() != TEAM_SPECTATOR and v != LocalPlayer()) and aimTrace(self:EyePos(), v:EyePos(), v) then
			if commands["Aimbot"] == "EVERYONE" then
				table.insert( aliveplayers, v )
			elseif commands["Aimbot"] == "NON-FRIENDS" and not (table.HasValue( friends, v ) or table.HasValue( tbuddy, v ) or table.HasValue( friendly, v )) then
				table.insert( aliveplayers, v )
			elseif commands["Aimbot"] == "NON-FRIENDS/ADMINS" and not (table.HasValue( admins, v ) or table.HasValue( friends, v ) or table.HasValue( tbuddy, v ) or table.HasValue( friendly, v )) then
				table.insert( aliveplayers, v )
			elseif commands["Aimbot"] == "NON-FRIENDS" and (dgm == "morbus") and not (table.HasValue( friends, v ) or table.HasValue( tbuddy, v ) or table.HasValue( traitors, v ) or table.HasValue( friendly, v )) then
				table.insert( aliveplayers, v )
			elseif commands["Aimbot"] == "NON-FRIENDS/ADMINS" and (dgm == "morbus") and not (table.HasValue( admins, v ) or table.HasValue( friends, v ) or table.HasValue( tbuddy, v ) or table.HasValue( traitors, v ) or table.HasValue( friendly, v )) then
				table.insert( aliveplayers, v )
			end
		end
	end
end

function welcomeMessage()
	chat.AddText(	levCol, "[Loli] ",
					baseCol, "LoliScript Version [",
					specCol, scriptVer,
					baseCol, "] loaded!\n",
					
					levCol, "[Loli] ",
					baseCol, "Welcome, ",
					greenCol, self:Name(),
					//baseCol, ". Type ",
					//redCol, "levhelp ",
					//baseCol, "into console for commands!\n",
					
					levCol, "\n[Loli] ",
					baseCol, "Remember, ",
					redCol, "DO NOT ",
					baseCol, "redistribute this.")
					chat.PlaySound()
	gamemodehooks()
	

end
welcomeMessage()


function getMenuKeys()
	if canMoveSelection then
		if levMenu == true and (input.IsKeyDown(KEY_UP))then
			selectionNum = selectionNum - 1
			canMoveSelection = false
			timer.Simple(0.1, canMoveMenuSelection)
		elseif levMenu == true and (input.IsKeyDown(KEY_DOWN))then
			selectionNum = selectionNum + 1
			canMoveSelection = false
			timer.Simple(0.1, canMoveMenuSelection)
		elseif levMenu == true and (input.IsKeyDown(KEY_RIGHT) or input.IsKeyDown(KEY_LEFT))then
			if commands[selection[selectionNum]] == "ON" then
				commands[selection[selectionNum]] = "OFF"
			elseif commands[selection[selectionNum]] == "OFF" then
				commands[selection[selectionNum]] = "ON"
			elseif tonumber(commands[selection[selectionNum]]) then
				if input.IsKeyDown(KEY_RIGHT) then
					commands[selection[selectionNum]] = commands[selection[selectionNum]] + 1
				elseif input.IsKeyDown(KEY_LEFT) then
					commands[selection[selectionNum]] = commands[selection[selectionNum]] - 1
				end
			elseif commands[selection[selectionNum]] == "NONE" then
				commands[selection[selectionNum]] = "EVERYONE"
			elseif commands[selection[selectionNum]] == "EVERYONE" then
				commands[selection[selectionNum]] = "NON-FRIENDS"
			elseif commands[selection[selectionNum]] == "NON-FRIENDS" then
				commands[selection[selectionNum]] = "NON-FRIENDS/ADMINS"
			elseif commands[selection[selectionNum]] == "NON-FRIENDS/ADMINS" then
				commands[selection[selectionNum]] = "NONE"	
			elseif commands[selection[selectionNum]] == "HEAD" then
				commands[selection[selectionNum]] = "CHEST"
			elseif commands[selection[selectionNum]] == "CHEST" then
				commands[selection[selectionNum]] = "HEAD"	
			end
			canMoveSelection = false
			timer.Simple(0.1, canMoveMenuSelection)
		end
		if selectionNum < 1 then
			selectionNum = comnumamount
			canMoveSelection = false
			timer.Simple(0.1, canMoveMenuSelection)
		elseif selectionNum > comnumamount then
			selectionNum = 1
			canMoveSelection = false
			timer.Simple(0.1, canMoveMenuSelection)
		end
		
	end
end
hook.Add("CreateMove","getMenuKeys",getMenuKeys)

function canMoveMenuSelection()
	canMoveSelection = true
end

function shouldDisplayMenu()
	
	if !displayMenu then
		displayMenu = true
	elseif displayMenu then
		displayMenu = false
	end
end
concommand.Add( "loliMenu", shouldDisplayMenu)


local oldGetWeapons = debug.getregistry().Player.GetWeapons
local traitors = {}
local alienweps = {}
function TraitorFinder()
	if commands["Alien Detector"] == "ON" then
		local aliveplayers = {}
		for k,v in pairs(player.GetAll()) do
			if v:Alive() and v:Team() != TEAM_SPECTATOR then
				table.insert(aliveplayers, v)
			end
		end
		if aliveplayers then
			for k,v in pairs(aliveplayers) do
				if v:GetActiveWeapon():IsValid() then
					weapon = v:GetActiveWeapon()
					if (weapon:GetClass() == "weapon_mor_swarm" or weapon:GetClass() == "weapon_mor_brood") and not table.HasValue(traitors, v) then
						table.insert(traitors, v)
						chat.AddText( 	levCol, "[Loli] ",
										redCol, v:Nick(),
										baseCol, " is an Alien!, ",
										specCol, weapon)
					end
				end
				if table.HasValue(traitors, v) and (v:Health() <= 0 or v:Team() == TEAM_SPECTATOR) then
					for l, y in pairs(traitors) do
						table.remove(traitors, l)
					end
				end
			end
		end
	elseif dgm == "murder" then
		local aliveplayers = {}
		for k,v in pairs(player.GetAll()) do
			if v:Alive() and v:Team() != TEAM_SPECTATOR then
				table.insert(aliveplayers, v)
			end
		end
		if aliveplayers then
			for k,v in pairs(aliveplayers) do
				if v:GetActiveWeapon():IsValid() then
					weapon = v:GetActiveWeapon()
					if (weapon:GetClass() == "weapon_mu_knife" or weapon:GetClass() == "NoWep") and not table.HasValue(traitors, v) then
						table.insert(traitors, v)
						chat.AddText( 	levCol, "[Loli] ",
										redCol, v:Nick(),
										baseCol, " is the murderer!, ",
										specCol, weapon)
					end
				end
				if table.HasValue(traitors, v) and (v:Health() <= 0 or v:Team() == TEAM_SPECTATOR) then
					for l, y in pairs(traitors) do
						table.remove(traitors, l)
					end
				end
			end
		end
	elseif commands["Traitor Detector"] == "ON" then
		local aliveplayers = {}
		for k,v in pairs(player.GetAll()) do
			if v:Alive() and v:Team() != TEAM_SPECTATOR and v != LocalPlayer() then
				table.insert(aliveplayers, v)
			end
		end
		if aliveplayers then
			for k,v in pairs(aliveplayers) do
				if v:GetActiveWeapon():IsValid() then
					weapon = v:GetActiveWeapon()
					if weapon.CanBuy and (weapon.CanBuy[1] == 1) and not table.HasValue(traitors, v) and not v:IsActiveDetective() then
						table.insert(traitors, v)
						chat.AddText( 	levCol, "[Loli] ",
										redCol, v:Nick(),
										baseCol, " has a traitor weapon, ",
										specCol, weapon)
					end
				end
				if table.HasValue(traitors, v) and (v:Health() <= 0 or v:Team() == TEAM_SPECTATOR) then
					for l, y in pairs(traitors) do
						table.remove(traitors, l)
					end
				end
			end
		end
	end
end

deadplayers = {}
function ShowDeaths()
	if commands["Death Notice"] == "ON" and commands["Panic"] == "OFF" then
		for k,v in pairs(player.GetAll()) do
			if (v:Health() <= 0 or v:Team() == TEAM_SPECTATOR) and not table.HasValue(deadplayers, v) and v != LocalPlayer() then
				chat.AddText( 	levCol, "[Loli] ",
								baseCol, "Player ",
								greenCol, v:Name(),
								baseCol, " is dead.")
				table.insert(deadplayers, v)
				chat.PlaySound()
			end
		end
	end
end

function ClearTables()
	timer.Simple(1, ClearTables2)
end
hook.Add("TTTBeginRound", "ClearTables", ClearTables)

function CreateRoleHelp(role)
	timer.Simple(1, ClearTables2)
end

function DrawDistortionAlien()
	return
end

function DrawDistortion()
	return
end

function ClearTables2()
	traitors = {}
	deadplayers = {}
end


function boxESP()
	if commands["Box ESP"] == "ON" and commands["Panic"] == "OFF" then
		if dgm == "darkrp" then
			for k,v in pairs (allplayers) do
				if(v:Health() >0 and v:Team() != TEAM_SPECTATOR and v != LocalPlayer()) then
					local T1 = ( v:GetPos() + Vector( -18,-18, 68 ) ):ToScreen()
					local T2 = ( v:GetPos() + Vector( 18,-18, 68 ) ):ToScreen()
					local T3 = ( v:GetPos() + Vector( 18,18, 68 ) ):ToScreen()
					local T4 = ( v:GetPos() + Vector( -18,18, 68 ) ):ToScreen()
					
					local B1 = ( v:GetPos() + Vector( -18,-18, 0 ) ):ToScreen()
					local B2 = ( v:GetPos() + Vector( 18,-18, 0 ) ):ToScreen()
					local B3 = ( v:GetPos() + Vector( 18,18, 0 ) ):ToScreen()
					local B4 = ( v:GetPos() + Vector( -18,18, 0 ) ):ToScreen()
					
					if table.HasValue(friends, v) then
						surface.SetDrawColor( 0, 255, 0, 255 )
					elseif table.HasValue(admins, v) then
						surface.SetDrawColor( 204, 0, 255, 255 )
					else
						surface.SetDrawColor(team.GetColor(v:Team()))
					end
					surface.DrawLine(T1.x, T1.y, T2.x, T2.y)
					surface.DrawLine(T2.x, T2.y, T3.x, T3.y)
					surface.DrawLine(T3.x, T3.y, T4.x, T4.y)
					surface.DrawLine(T4.x, T4.y, T1.x, T1.y)
					
					surface.DrawLine(B1.x, B1.y, B2.x, B2.y)
					surface.DrawLine(B2.x, B2.y, B3.x, B3.y)
					surface.DrawLine(B3.x, B3.y, B4.x, B4.y)
					surface.DrawLine(B4.x, B4.y, B1.x, B1.y)
					
					surface.DrawLine(B1.x, B1.y, T1.x, T1.y)
					surface.DrawLine(B2.x, B2.y, T2.x, T2.y)
					surface.DrawLine(B3.x, B3.y, T3.x, T3.y)
					surface.DrawLine(B4.x, B4.y, T4.x, T4.y)
				end
			end
		elseif dgm == "ttt" then
			for k,v in pairs (allplayers) do
				if(v:Health() >0 and v:Team() != TEAM_SPECTATOR and v != LocalPlayer()) then
					local T1 = ( v:GetPos() + Vector( -18,-18, 75 ) ):ToScreen()
					local T2 = ( v:GetPos() + Vector( 18,-18, 75 ) ):ToScreen()
					local T3 = ( v:GetPos() + Vector( 18,18, 75 ) ):ToScreen()
					local T4 = ( v:GetPos() + Vector( -18,18, 75 ) ):ToScreen()
					
					local B1 = ( v:GetPos() + Vector( -18,-18, 0 ) ):ToScreen()
					local B2 = ( v:GetPos() + Vector( 18,-18, 0 ) ):ToScreen()
					local B3 = ( v:GetPos() + Vector( 18,18, 0 ) ):ToScreen()
					local B4 = ( v:GetPos() + Vector( -18,18, 0 ) ):ToScreen()
					
					if table.HasValue(friends, v) then
						surface.SetDrawColor( 0, 255, 0, 255 )
					elseif table.HasValue(admins, v) then
						surface.SetDrawColor( 204, 0, 255, 255 )
					elseif v:IsActiveDetective() then
						surface.SetDrawColor( 0, 0, 255, 255 )
					elseif table.HasValue(traitors, v) then
						surface.SetDrawColor( 255, 0, 0, 255 )
					else
						surface.SetDrawColor( 255, 204, 0, 255 )
					end
					surface.DrawLine(T1.x, T1.y, T2.x, T2.y)
					surface.DrawLine(T2.x, T2.y, T3.x, T3.y)
					surface.DrawLine(T3.x, T3.y, T4.x, T4.y)
					surface.DrawLine(T4.x, T4.y, T1.x, T1.y)
					
					surface.DrawLine(B1.x, B1.y, B2.x, B2.y)
					surface.DrawLine(B2.x, B2.y, B3.x, B3.y)
					surface.DrawLine(B3.x, B3.y, B4.x, B4.y)
					surface.DrawLine(B4.x, B4.y, B1.x, B1.y)
					
					surface.DrawLine(B1.x, B1.y, T1.x, T1.y)
					surface.DrawLine(B2.x, B2.y, T2.x, T2.y)
					surface.DrawLine(B3.x, B3.y, T3.x, T3.y)
					surface.DrawLine(B4.x, B4.y, T4.x, T4.y)
				end
			end
		elseif dgm == "morbus" then
			for k,v in pairs (allplayers) do
				if(v:Health() >0 and v:Team() != TEAM_SPECTATOR and v != LocalPlayer()) then
					local T1 = ( v:GetPos() + Vector( -18,-18, 75 ) ):ToScreen()
					local T2 = ( v:GetPos() + Vector( 18,-18, 75 ) ):ToScreen()
					local T3 = ( v:GetPos() + Vector( 18,18, 75 ) ):ToScreen()
					local T4 = ( v:GetPos() + Vector( -18,18, 75 ) ):ToScreen()
					
					local B1 = ( v:GetPos() + Vector( -18,-18, 0 ) ):ToScreen()
					local B2 = ( v:GetPos() + Vector( 18,-18, 0 ) ):ToScreen()
					local B3 = ( v:GetPos() + Vector( 18,18, 0 ) ):ToScreen()
					local B4 = ( v:GetPos() + Vector( -18,18, 0 ) ):ToScreen()
					
					if table.HasValue(friends, v) then
						surface.SetDrawColor( 0, 255, 0, 255 )
					elseif table.HasValue(admins, v) then
						surface.SetDrawColor( 204, 0, 255, 255 )
					elseif table.HasValue(traitors, v) then
						surface.SetDrawColor( 255, 0, 0, 255 )
					else
						surface.SetDrawColor( 255, 204, 0, 255 )
					end
					surface.DrawLine(T1.x, T1.y, T2.x, T2.y)
					surface.DrawLine(T2.x, T2.y, T3.x, T3.y)
					surface.DrawLine(T3.x, T3.y, T4.x, T4.y)
					surface.DrawLine(T4.x, T4.y, T1.x, T1.y)
					
					surface.DrawLine(B1.x, B1.y, B2.x, B2.y)
					surface.DrawLine(B2.x, B2.y, B3.x, B3.y)
					surface.DrawLine(B3.x, B3.y, B4.x, B4.y)
					surface.DrawLine(B4.x, B4.y, B1.x, B1.y)
					
					surface.DrawLine(B1.x, B1.y, T1.x, T1.y)
					surface.DrawLine(B2.x, B2.y, T2.x, T2.y)
					surface.DrawLine(B3.x, B3.y, T3.x, T3.y)
					surface.DrawLine(B4.x, B4.y, T4.x, T4.y)
				end
			end
		elseif dgm == "slender" then
			for k,v in pairs (allplayers) do
				if(v:Health() >0 and v:Team() != TEAM_SPECTATOR and v != LocalPlayer()) then
					local T1 = ( v:GetPos() + Vector( -18,-18, 75 ) ):ToScreen()
					local T2 = ( v:GetPos() + Vector( 18,-18, 75 ) ):ToScreen()
					local T3 = ( v:GetPos() + Vector( 18,18, 75 ) ):ToScreen()
					local T4 = ( v:GetPos() + Vector( -18,18, 75 ) ):ToScreen()
					
					local B1 = ( v:GetPos() + Vector( -18,-18, 0 ) ):ToScreen()
					local B2 = ( v:GetPos() + Vector( 18,-18, 0 ) ):ToScreen()
					local B3 = ( v:GetPos() + Vector( 18,18, 0 ) ):ToScreen()
					local B4 = ( v:GetPos() + Vector( -18,18, 0 ) ):ToScreen()
					
					if table.HasValue(friends, v) then
						surface.SetDrawColor( 0, 255, 0, 255 )
					elseif table.HasValue(admins, v) then
						surface.SetDrawColor( 204, 0, 255, 255 )
					elseif (v:Team() == 4) or (team.GetName(v:Team()) == "Slenderman") or (v:Team() == TEAM_SLENDER) then
						surface.SetDrawColor( 255, 0, 0, 255 )
						slender = v
					else
						surface.SetDrawColor( 255, 204, 0, 255 )
					end
					surface.DrawLine(T1.x, T1.y, T2.x, T2.y)
					surface.DrawLine(T2.x, T2.y, T3.x, T3.y)
					surface.DrawLine(T3.x, T3.y, T4.x, T4.y)
					surface.DrawLine(T4.x, T4.y, T1.x, T1.y)
					
					surface.DrawLine(B1.x, B1.y, B2.x, B2.y)
					surface.DrawLine(B2.x, B2.y, B3.x, B3.y)
					surface.DrawLine(B3.x, B3.y, B4.x, B4.y)
					surface.DrawLine(B4.x, B4.y, B1.x, B1.y)
					
					surface.DrawLine(B1.x, B1.y, T1.x, T1.y)
					surface.DrawLine(B2.x, B2.y, T2.x, T2.y)
					surface.DrawLine(B3.x, B3.y, T3.x, T3.y)
					surface.DrawLine(B4.x, B4.y, T4.x, T4.y)
				end
			end
		else
			for k,v in pairs (allplayers) do
				if(v:Health() >0 and v:Team() != TEAM_SPECTATOR and v != LocalPlayer()) then
					local T1 = ( v:GetPos() + Vector( -18,-18, 68 ) ):ToScreen()
					local T2 = ( v:GetPos() + Vector( 18,-18, 68 ) ):ToScreen()
					local T3 = ( v:GetPos() + Vector( 18,18, 68 ) ):ToScreen()
					local T4 = ( v:GetPos() + Vector( -18,18, 68 ) ):ToScreen()
					
					local B1 = ( v:GetPos() + Vector( -18,-18, 0 ) ):ToScreen()
					local B2 = ( v:GetPos() + Vector( 18,-18, 0 ) ):ToScreen()
					local B3 = ( v:GetPos() + Vector( 18,18, 0 ) ):ToScreen()
					local B4 = ( v:GetPos() + Vector( -18,18, 0 ) ):ToScreen()
					
					if table.HasValue(friends, v) then
						surface.SetDrawColor( 0, 255, 0, 255 )
					elseif table.HasValue(admins, v) then
						surface.SetDrawColor( 204, 0, 255, 255 )
					else
						surface.SetDrawColor( 255, 204, 0, 255 )
					end
					surface.DrawLine(T1.x, T1.y, T2.x, T2.y)
					surface.DrawLine(T2.x, T2.y, T3.x, T3.y)
					surface.DrawLine(T3.x, T3.y, T4.x, T4.y)
					surface.DrawLine(T4.x, T4.y, T1.x, T1.y)
					
					surface.DrawLine(B1.x, B1.y, B2.x, B2.y)
					surface.DrawLine(B2.x, B2.y, B3.x, B3.y)
					surface.DrawLine(B3.x, B3.y, B4.x, B4.y)
					surface.DrawLine(B4.x, B4.y, B1.x, B1.y)
					
					surface.DrawLine(B1.x, B1.y, T1.x, T1.y)
					surface.DrawLine(B2.x, B2.y, T2.x, T2.y)
					surface.DrawLine(B3.x, B3.y, T3.x, T3.y)
					surface.DrawLine(B4.x, B4.y, T4.x, T4.y)
				end
			end
		end
	end
end

function boxESPDrawLine( point1, point2, point3, point4, entity)
end

function lineToPlayers()
	if commands["Line to Players"] == "ON" then
		if dgm == "sandbox" then
		surface.SetDrawColor( 0, 255, 0, 255 )
			for k,v in pairs (players) do
				local PlayerPoint = ( Vector( ScrW()/2,ScrH()-50, 0 ) )
				local TargetPoint = ( v:GetPos() + Vector( 0, 0, 34 ) ):ToScreen()
				if(v:Health() >0 and v:Team() != TEAM_SPECTATOR) then
					surface.DrawLine(PlayerPoint.x, PlayerPoint.y, TargetPoint.x, TargetPoint.y)
				end
			end
		else
		end
	end
end

function textESP()
local espCol
	if commands["ESP"] == "ON" and commands["Panic"] == "OFF" then
		for k,v in pairs (allplayers) do
			if(v:Health() >0 and v:Team() != TEAM_SPECTATOR and v != LocalPlayer()) then
				targetOrigin = v:GetPos()
				targetPos = Vector(targetOrigin.x, targetOrigin.y, targetOrigin.z):ToScreen()
				if v:GetActiveWeapon():IsValid() then
					espWeapon = v:GetActiveWeapon():GetClass()
				else
					espWeapon = "NoWep"
				end
				if dgm == "ttt" then
					local statusPos = Vector(targetOrigin.x, targetOrigin.y, targetOrigin.z):ToScreen()
					local curStatus
					if table.HasValue(friends, v) then
						espCol = Color( 0, 255, 0, 255 )
						if v:IsActiveDetective() then
							curStatus = "Detective"
							espCol = Color( 0, 0, 255, 255 )
						elseif table.HasValue(traitors, v) then
							espCol = Color( 255, 0, 0, 255 )
							curStatus = "Traitor"
						else
							espCol = Color( 255, 255, 0, 255 )
							curStatus = "Innocent?"
						end
					elseif table.HasVaalue(admins, v) then
						espCol = Color( 255, 0, 255, 255 )
						if v:IsActiveDetective() then
							curStatus = "Detective"
							espCol = Color( 0, 0, 255, 255 )
						elseif table.HasValue(traitors, v) then
							espCol = Color( 255, 0, 0, 255 )
							curStatus = "Traitor"
						else
							espCol = Color( 255, 255, 0, 255 )
							curStatus = "Innocent?"
						end
					elseif v:IsActiveDetective() then
						espCol = Color( 0, 0, 255, 255 )
						curStatus = "Detective"
					elseif table.HasValue(traitors, v) then
						espCol = Color( 255, 0, 0, 255 )
						curStatus = "Traitor"
					else
						espCol = Color( 255, 255, 0, 255 )
						curStatus = "Innocent?"
					end
					draw.DrawText(curStatus, "ESPFont", statusPos.x, statusPos.y+50, espCol, TEXT_ALIGN_CENTER)
				elseif dgm == "darkrp" then
					local statusPos = Vector(targetOrigin.x, targetOrigin.y, targetOrigin.z):ToScreen()
					if table.HasValue(friends, v) then
						espCol = Color( 0, 255, 0, 255 )
					elseif table.HasValue(admins, v) then
						espCol = Color( 255, 0, 255, 255 )
					else
						espCol = team.GetColor(v:Team())
					end
					draw.DrawText("$"..formatNumber(v.DarkRPVars.money), "ESPFont", statusPos.x, statusPos.y+50, espCol, TEXT_ALIGN_CENTER)
				else //assume sandbox
					if table.HasValue(friends, v) then
						espCol = Color( 0, 255, 0, 255 )
					elseif table.HasValue(admins, v) then
						espCol = Color( 255, 0, 255, 255 )
					else
						espCol = Color( 255, 255, 0, 255 )
					end
				end
				if dgm == "morbus" then
					draw.DrawText(v:GetFName() .. " (" .. v:Name() .. ")" .. "\n" .. v:Health() .. "\n" .. espWeapon, "ESPFont", targetPos.x, targetPos.y, espCol, TEXT_ALIGN_CENTER)
				else
					draw.DrawText(v:Name() .. "\n" .. v:Health() .. "\n" .. espWeapon, "ESPFont", targetPos.x, targetPos.y, espCol, TEXT_ALIGN_CENTER)			
				end
			end
		end
	end
end

function entityESP()
	if commands["Entity ESP"] == "ON" and commands["Panic"] == "OFF" then
		if dgm == "darkrp" then
			for k,v in pairs(ents.GetAll()) do
				if v:IsValid() then
					entPos = v:GetPos():ToScreen()
					if string.find(tostring(v:GetClass()), "printer") then
						draw.WordBox(4, entPos.x, entPos.y, v:GetClass(), "ESPFont", Color(50,50,50,200), Color(0,225,0))
					elseif v:GetClass() == "spawned_money" then
						draw.WordBox(4, entPos.x, entPos.y, "$"..tostring(formatNumber(v:Getamount())), "ESPFont", Color(50,50,50,200), Color(0,225,0))
					elseif v:GetClass() == "spawned_shipment" then
						contents = CustomShipments[v:Getcontents()]
						contents = contents.name
						draw.WordBox(4, entPos.x, entPos.y, "Shipment: "..contents, "ESPFont", Color(50,50,50,200), Color(225,0,0))
					elseif v:GetClass() == "spawned_weapon" then
						local wepname = string.Explode("/", v:GetModel())
						local wepname = string.Explode(".", wepname[3])
						draw.WordBox(4, entPos.x, entPos.y, wepname[1], "ESPFont", Color(50,50,50,200), Color(225,0,0))
					end
				end
			end
		elseif dgm == "slender" then
			for k,v in pairs(ents.GetAll()) do
				if v:IsValid() then
					entPos = v:GetPos():ToScreen()
					if string.find(tostring(v:GetClass()), "page") and not v.Taken then
						draw.WordBox(4, entPos.x, entPos.y, v:GetClass(), "ESPFont", Color(50,50,50,200), Color(0,225,0))
					end
				end
			end
		elseif dgm == "murder" then
			for k,v in pairs(ents.GetAll()) do
				if v:IsValid() then
					entPos = v:GetPos():ToScreen()
					if (string.find(tostring(v:GetClass()), "weapon_mu_knife")) or (string.find(tostring(v:GetClass()), "mu_loot")) or (string.find(tostring(v:GetClass()), "weapon_mu_magnum")) and not v.Taken then
						draw.WordBox(4, entPos.x, entPos.y, v:GetClass(), "ESPFont", Color(50,50,50,200), Color(0,225,0))
					end
				end
			end
		elseif dgm == "dayz" then
			for k,v in pairs(ents.GetAll()) do
				if v:IsValid() then
					entPos = v:GetPos():ToScreen()
					if (string.find(tostring(v:GetClass()), "weapon_")) and not v.Taken then
						draw.WordBox(4, entPos.x, entPos.y, v:GetClass(), "ESPFont", Color(50,50,50,200), Color(0,225,0))
					end
				end
			end
		elseif dgm == "zmod" then
			for k,v in pairs(ents.GetAll()) do
				if v:IsValid() then
					entPos = v:GetPos():ToScreen()
					local entname = string.Explode("_", v:GetClass())
					if entname[1] == "fur" then
						draw.WordBox(4, entPos.x, entPos.y, entname[2], "ESPFont", Color(50,50,50,200), Color(225,0,0))
					elseif entname[1] == "zweap" then
						draw.WordBox(4, entPos.x, entPos.y, entname[2], "ESPFont", Color(50,50,50,200), Color(0,225,0))
					elseif entname[2] == "ammo" then
						draw.WordBox(4, entPos.x, entPos.y, entname[3], "ESPFont", Color(50,50,50,200), Color(200,200,225))
					end
				end
			end
		end
	end
end

function eyeLines()
	if commands["Eye Lines"] == "ON" then
		if dgm == "sandbox" then
			for k,v in pairs (allplayers) do
				if(v:Health() >0 and v:Team() != TEAM_SPECTATOR and v != LocalPlayer()) then
				end
			end
		end
	end
end

textdata = file.Read("spamlines.txt", "DATA")
lines = string.Explode("\n", textdata)
 
for i, line in ipairs(lines) do
	CSpam[i] = line
	spamLine = i 
end

function textSpam()
	local SpamMessage = CSpam[math.random(spamLine)]
	if commands["Text Spam"] == "ON" and commands["Panic"] == "OFF" then
		if ( gmod.GetGamemode().Name ) == "Trouble in Terrorist Town" then
			if LocalPlayer():Alive() then
				RunConsoleCommand("say", SpamMessage)
			elseif LocalPlayer():Team() == TEAM_SPECTATOR then
				RunConsoleCommand("say_team", SpamMessage)
			else
				RunConsoleCommand("say_team", SpamMessage)
			end
		else
			RunConsoleCommand("say", SpamMessage)
		end
	end
end

function C4ESP()
for k, v in pairs( ents.FindByClass( "ttt_c4" ) ) do
if IsValid( v ) then
 
if (commands["ESP"] == "ON" and commands["Panic"] == "OFF") then
 
local C4ESPPos = ( v:GetPos() ):ToScreen()
 
if !v:GetArmed() then
draw.SimpleText( "C4", "MenuFont", C4ESPPos.x, C4ESPPos.y - 22, Color( 255, 0, 0, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
end
 
if v:GetArmed() then
draw.SimpleText( "C4 Time until Explosion: " .. string.FormattedTime( math.max( 0, v:GetExplodeTime() - CurTime() ), "%02i:%02i" ), "MenuFont", C4ESPPos.x, C4ESPPos.y - 22, Color( 255, 0, 0, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
   end
end
 
if v:GetPos():Distance( LocalPlayer():GetPos() ) < 1000 and v:GetArmed() then
draw.DrawText( "In range of C4 explosion!", "MenuFont", ScrW() / 2 / 2 +60, ScrH()/2 * 2 - 20, Color( 255, 0, 0, 255 ), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT, 1, Color( 255, 255, 255, 255 ) )
         end
      end
end
end	  
hook.Add( "HUDPaint", "C4ESP", C4ESP )

function dance()
if commands["Tiny Dancin' Man"] == "ON" and commands["Panic"] == "OFF" then
       RunConsoleCommand("act", "dance")
end
end
timer.Create( "dancin", 4.6, 0, dance)

function bHop()
	if commands["BunnyHop"] == "ON" and commands["Panic"] == "OFF" and (LocalPlayer():Alive() or LocalPlayer():Team() != TEAM_SPECTATOR) then
		if input.IsKeyDown( KEY_SPACE ) then
			if LocalPlayer():IsOnGround() then
				RunConsoleCommand("+jump")
			else
				RunConsoleCommand("-jump")
			end
		else
			RunConsoleCommand("-jump")
		end
	end
end

hook.Add("RenderScreenspaceEffects", "texthelper", function()
        if (commands["Chams"] == "ON" and commands["Panic"] == "OFF") then
                local everything = ents.GetAll()
                for k = 1, #everything do
                        local v = everything[k]
                       
                        if v != LocalPlayer() then
                                cam.Start3D(EyePos(), EyeAngles())
                                        if v:IsPlayer() and v:Alive() and v:Team() != TEAM_SPECTATOR then
                                                local color = Color(0, 255, 0, 255)
                                                if v:IsPlayer() then
                                                        color = team.GetColor(v:Team())
                                                        if (dgm == "ttt") then
                                                                if v:IsActiveDetective() then
                                                                        color = Color(0, 0, 255, 255)
                                                                elseif table.HasValue(traitors, v) then
                                                                        color = Color(255, 0, 0, 255)
                                                                else
                                                                        color = Color(0, 255, 0, 255)
                                                                end
                                                        end
                                                end
                                                render.SuppressEngineLighting(true)
                                                render.SetColorModulation(color.r/255, color.g/255, color.b/255, 1)
                                                render.MaterialOverride(CreateMaterial("mymaterial", "VertexLitGeneric", { ["$basetexture"] = "models/debug/debugwhite", ["$model"] = 1, ["$ignorez"] = 1 }))
                                                v:DrawModel()
                                               
                                                render.SetColorModulation((color.r + 150)/250, (color.g + 150)/250, (color.b + 150)/255, 1)                                            
                                                if IsValid(v:GetActiveWeapon()) then
                                                        v:GetActiveWeapon():DrawModel()
                                                end
                                               
                                                render.SetColorModulation(1, 1, 1, 1)
                                                render.MaterialOverride()
                                                render.SetModelLighting(4, color.r/255, color.g/255, color.b/255)
                                                v:DrawModel()
                                                render.SuppressEngineLighting(false)
/*                                        elseif table.HasValue(entitychams, v:GetClass()) then                                  
                                                render.SuppressEngineLighting(true)    
                                                render.SetColorModulation(color.r/255, color.g/255, color.b/255, 1)
                                                render.MaterialOverride(CreateMaterial("mymaterial", "VertexLitGeneric", { ["$basetexture"] = "models/debug/debugwhite", ["$model"] = 1, ["$ignorez"] = 1 }))
                                                v:DrawModel()  
                                                render.SetColorModulation(1, 1, 1, 1)
                                                render.MaterialOverride()
                                                render.SetModelLighting(4, color.r/255, color.g/255, color.b/255)
                                                v:DrawModel()
                                                render.SuppressEngineLighting(false)*/
                                        end
                                cam.End3D()
                        end
                end
        end
end)

--[[function noSpread(cmd)
	local wep
	local nsClamp
	if commands["No-Spread"] == "ON" and input.IsMouseDown(MOUSE_LEFT) then	
		if self:GetActiveWeapon():IsValid() and self:GetActiveWeapon().Primary then
			nsPos = self:GetEyeTrace().HitPos	
			local wep = self:GetActiveWeapon()
			nsAngle = (nsPos - self:GetShootPos()):Angle()
			oldAng = nsAngle
			local cone = Vector(-wep.Primary.Cone, -wep.Primary.Cone, 0)
			nsAngle = DS_manipulateShot(DS_md5PseudoRandom(DS_getUCMDCommandNumber(cmd)), nsAngle:Forward(), cone):Angle()
			//cmd:SetViewAngles(nsAngle)
			print(wep:GetNextPrimaryFire())
		end	
	end
end
hook.Add("CreateMove", "noSpread", noSpread)]]

function noRecoil() // did this while drunk dont judge me
	if (self:Health() >0 and self:Team() != TEAM_SPECTATOR) then
		if commands["No-Recoil"] == "ON" and self:GetActiveWeapon():IsValid() and self:GetActiveWeapon().Primary then
			wep = self:GetActiveWeapon()
			if wep.Primary.Recoil != 0 then
				oldRecoil = wep.Primary.Recoil
			end
			wep.Primary.Recoil = 0
		elseif oldRecoil and self:GetActiveWeapon():IsValid() and self:GetActiveWeapon().Primary then
			wep = self:GetActiveWeapon()
			wep.Primary.Recoil = oldRecoil	
		end
	end
end
hook.Add("CreateMove", "voices", noRecoil)

local targetPos
local selfAng
function Aimbot(cmd)
	target = nil
	if (self:Health() >0 and self:Team() != TEAM_SPECTATOR) then
		if commands["Aimbot"] != "NONE" and self:GetActiveWeapon():IsValid() and (input.IsMouseDown(MOUSE_RIGHT)) then
			for k,v in pairs (aliveplayers) do
				if target == nil then
					target = v
				end
				if not target:IsValid() then
					target = v
				end
				if not target:Alive() and v:Alive() then
					target = v
				end
				aimbotDist = math.deg( math.acos( self:GetAimVector():Dot( ( getattach(target).Pos - self:GetShootPos() ):GetNormal() ) ) )
				if math.deg( math.acos( self:GetAimVector():Dot( ( getattach(target).Pos - self:GetShootPos() ):GetNormal() ) ) ) > aimbotDist then
					target = v
					aimbotDist = math.deg( math.acos( self:GetAimVector():Dot( ( getattach(target).Pos - self:GetShootPos() ):GetNormal() ) ) )
				end
				if not (getattach(target)) then
					return
				end
				targetPos = Vector((getattach(target)).Pos.x,(getattach(target)).Pos.y,(getattach(target)).Pos.z)
				selfAng = (targetPos - self:GetShootPos()):Angle()
					if self:GetActiveWeapon():IsValid() and self:GetActiveWeapon().Primary and self:GetActiveWeapon().Primary.Cone then
						local cone = Vector(-self:GetActiveWeapon().Primary.Cone, -self:GetActiveWeapon().Primary.Cone, 0)
						selfAng = DS_manipulateShot(DS_md5PseudoRandom(DS_getUCMDCommandNumber(cmd)), selfAng:Forward(), cone):Angle()
					end
				cmd:SetViewAngles(selfAng)
				if commands["Triggerbot"] == "ON" then
					RunConsoleCommand("+attack")
					timer.Simple(0.01, function() RunConsoleCommand("-attack") end)
				end
			end
		end
	end
end
hook.Add("CreateMove", "voices2", Aimbot)

hook.Add( "Think", "Triggerbot", function()
    local Target = LocalPlayer():GetEyeTrace().Entity
    if LocalPlayer():Alive() and LocalPlayer():GetActiveWeapon():IsValid() and commands["Triggerbot"] == "ON" and input.IsMouseDown(MOUSE_MIDDLE) and ( Target:IsPlayer() or Target:IsNPC() ) then
        if !Firing then
            RunConsoleCommand( "+attack" )
            Firing = true
		end
    elseif Firing then
		RunConsoleCommand( "-attack" ) 
        Firing = false
	end
end )

function viewFix(ply, pos2, angles, fov)
	if commands["No-Recoil"] == "ON" and commands["Panic"] == "OFF" then
		local view = {}
		view.angles = ((self:GetEyeTrace().HitPos) - self:GetShootPos()):Angle()
		return view
	end
end
hook.Add("CalcView", "viewFix", viewFix)

function slendirDistance()
	--[[ if dgm == "slender" then
		if slender != LocalPlayer() and (LocalPlayer():Team() != TEAM_SPECTATOR) and (LocalPlayer():Alive()) then
			local distance
			local playerPos = LocalPlayer():GetPos()
			local slenderPos = slender:GetPos()
			distance = playerPos:Distance(slenderpos)
			if distance < 1000 then
				surface.SetDrawColor( 255, 50, 50, 255)
			else
				surface.SetDrawColor( 50, 255, 50, 255)
			end
			surface.SetFont( "ESPFont" )
			surface.SetTextPos( ScrW - 70, ScrH - 63 )
			surface.DrawText( distance )
		end
	end ]]
end



function HUD()
	local baseCol = (Color(255,255,255))
	local selectMenu1 = (Color( 0, 0, 0, 230))
	local selectMenu2 = (Color( 200, 200, 200, 230))
	
	local menuBaseX = 50
	local menuBaseY = 50
	local menuBaseW = 200
	local menuBaseH = 25
	
	if displayMenu then
		for k,v in pairs ( selection ) do
			local loliH = k * 25 
			surface.SetTexture(surface.GetTextureID("gui/loliscript/loli"))
			surface.SetDrawColor( Color( 255, 255, 255, 255 ) )
			surface.DrawTexturedRect(menuBaseX - 154,menuBaseY,507,loliH + 25)
		end
		surface.SetDrawColor( 50, 50, 50, 230)
		surface.DrawRect(menuBaseX , menuBaseY, menuBaseW, menuBaseH )
		draw.DrawText("LoliScript Version ".. scriptVer, "MenuFont", (menuBaseX+(menuBaseW/2)), (menuBaseY+(menuBaseH/5)), baseCol,TEXT_ALIGN_CENTER)
	
		for k,v in pairs ( selection ) do
			newMenuPos = (menuBaseY+menuBaseH+commandAmount)
			local a = tostring(commands[v])
			if v == selection[selectionNum] then
				surface.SetDrawColor(selectMenu2)
				selectionTextCol = (Color( 0, 0, 0, 255))
			else
				surface.SetDrawColor(selectMenu1)
				selectionTextCol = (Color( 255, 255, 255, 255))
			end
			surface.DrawRect(menuBaseX , newMenuPos , menuBaseW, menuBaseH )
			commandAmount = commandAmount + menuBaseH
			draw.DrawText(v, "MenuFont", (menuBaseX+10), newMenuPos+7, selectionTextCol,TEXT_ALIGN_LEFT)
			draw.DrawText(a, "MenuFont", (menuBaseX+menuBaseW-10), newMenuPos+7, selectionTextCol,TEXT_ALIGN_RIGHT)
		end
	
		commandAmount = 0
	end
	getPlayers()
	TraitorFinder()
	ShowDeaths()
	textESP()
	boxESP()
	textSpam()
	bHop()
	entityESP()
	slendirDistance()
	Lolihair()
	//lineToPlayers()
end
hook.Add( "HUDPaint", "HUD", HUD)

function Lolihair()
	if commands["Crosshair"] == "ON" then
		 surface.SetDrawColor( Color(0, 225, 0, 255) )
		 surface.SetMaterial( Material("gui/loliscript/crosshair.png") )
		 surface.DrawTexturedRect(ScrW() / 2 - 50, ScrH() / 2 - 48, 100, 100)
	 end
 end

specspectators = {}
specadmins = {}
specsuperadmins = {}


function Spectate()
        for k, v in pairs(player.GetAll()) do
                if (IsValid(v:GetObserverTarget()) and v:GetObserverTarget():IsPlayer() and v:GetObserverTarget() == LocalPlayer()) then
                        if(not table.HasValue(specspectators, v)) then
                                table.insert(specspectators, v);
								chat.AddText( levCol, "[Loli] ", baseCol, "Player ", greenCol, v:Name(), baseCol, " has begun to spectate you.")
                                surface.PlaySound("buttons/blip1.wav")
                                end
                        end
                end
        
// stopping spec crashes with lua errors				
//        for k, v in pairs(specspectators) do
//                if (not IsValid(v) or not IsValid(v:GetObserverTarget()) or not v:GetObserverTarget():IsPlayer() or (v:GetObserverTarget() ~= LocalPlayer())) then
//						if isnumber(k) then
//							table.remove(specspectators, k);
//									chat.AddText( levCol, "[Loli] ", baseCol, "Player ", greenCol, v:Name(), baseCol, " has stopped spectating you.")
//							end
//						end
//                end
				
				
				for k, v in pairs(player.GetAll()) do
                        if (v:IsSuperAdmin() and not table.HasValue(specsuperadmins, v)) then
                                table.insert(specsuperadmins, v);
                                chat.AddText( levCol, "[Loli] ", baseCol, "Super Admin ", greenCol, v:Name(), baseCol, " has joined the game.")
                                surface.PlaySound("buttons/button11.wav");
								
                        end
                end
				
                for k, v in pairs(player.GetAll()) do
                        if (v:IsAdmin() and not table.HasValue(specadmins, v) and not v:IsSuperAdmin()) then
                                table.insert(specadmins, v);
                                chat.AddText( levCol, "[Loli] ", baseCol, "Admin ", greenCol, v:Name(), baseCol, " has joined the game.")
                                surface.PlaySound("buttons/button11.wav");
								
                        end
                end
				

 
end
hook.Add("Think", "Spectate", Spectate)

hook.Add("HUDPaint", "ShowAdminss", function()
if (commands["Show Admins"] == "ON" and commands["Panic"] == "OFF") then
if ( gmod.GetGamemode().Name ) == "PERP" or ( gmod.GetGamemode().Name ) == "RealityRoleplay" then
			local Adminy = 140
			local Admintext = 145
		else
			local Adminy = 40
			local Admintext = 45
end
local Admins = {}
local x = 0
for k,v in pairs(player.GetAll()) do
if v:IsAdmin() or v:IsSuperAdmin() then
table.insert(Admins, v:Name())
end
end
textLength = surface.GetTextSize(table.concat(Admins) ) / 6
draw.RoundedBox(0, ScrW() / 2 * 2 - 125, 40, 100, 80 + textLength, Color( 0, 0, 0, 230))
draw.RoundedBox(2, ScrW() / 2 * 2 - 125, 40, 100, 20, Color( 50, 50, 50, 230) )
draw.SimpleText("Admins", "MenuFont", ScrW() /2 * 2 -75, 45, Color(255,255,255), TEXT_ALIGN_CENTER )
for k, v in pairs(Admins) do
draw.SimpleText(v, "MenuFont", ScrW() / 2 * 2 -75, 45 + 25 + x, Color(255,255,255), TEXT_ALIGN_CENTER)
x = x + 15
end
end

if commands["Show Spectators"] == "ON" and ( gmod.GetGamemode().Name ) == "PERP" or ( gmod.GetGamemode().Name ) == "RealityRoleplay" and (commands["Show Admins"] == "ON") then
			Specy = 240 
			Spectext = 245
		elseif commands["Show Spectators"] == "ON" and ( gmod.GetGamemode().Name ) == "PERP" or ( gmod.GetGamemode().Name ) == "RealityRoleplay" or (commands["Show Admins"] == "ON") then
			Specy = 140
			Spectext = 145
		else
			Specy = 40
			Spectext = 45
end
					
if (commands["Show Spectators"] == "ON" and commands["Panic"] == "OFF") then
local Spectators = {}
local x = 0
for k,v in pairs(player.GetAll()) do
if (IsValid(v:GetObserverTarget()) and v:GetObserverTarget():IsPlayer() and v:GetObserverTarget() == LocalPlayer()) and not table.HasValue(Spectators, v:Name()) then
table.insert(Spectators, v:Name())
end
end
textLength2 = surface.GetTextSize(table.concat(Spectators) ) / 6
draw.RoundedBox(0, ScrW() / 2 * 2 - 125, Specy + textLength, 100, 80 + textLength2, Color( 0, 0, 0, 230))
draw.RoundedBox( 2, ScrW() / 2 * 2 - 125, Specy + textLength, 100, 20, Color( 50, 50, 50, 230) )

draw.SimpleText("Spectators", "MenuFont", ScrW() /2 * 2 - 75, Spectext + textLength, Color(255,255,255), TEXT_ALIGN_CENTER )
for k, v in pairs(Spectators) do
draw.SimpleText(v, "MenuFont", ScrW() / 2 * 2 - 75, Spectext + 25 + x +textLength, Color(255,255,255), TEXT_ALIGN_CENTER)
x = x + 15
end
end
end)

-- KCalc
-- Throws Shit in TTT

CreateClientConVar("Calc_OneKey", 1, true, false)
local nigenabled = 0
local throwlength = 0
function f_CalcPeek(ply, pos, angles, fov)
    local view = {}

    view.origin = pos-(angles:Forward()*0)

   local m = LocalPlayer():EyeAngles()
            view.angles = Angle(m.p,m.y+180, m.r)
    view.fov = fov

    return view
end


local function togal()
if nigenabled == 0 then
nigenabled = 1
hook.Add("CalcView", "CalcPeek", f_CalcPeek)
surface.PlaySound("buttons/button3.wav")
 chat.AddText(Color(255,150,0),"Ready...")
else

hook.Remove("CalcView", "CalcPeek")
if GetConVarNumber("Calc_OneKey") > 0 then

	local auge = LocalPlayer():EyeAngles()
 LocalPlayer():SetEyeAngles(LocalPlayer():EyeAngles()-Angle(0,180,0))
  surface.PlaySound("buttons/button14.wav")
   chat.AddText(Color(0,255,0),"Thrown!")

end
	nigenabled = 0
end

end

concommand.Add("ToggleNiggers",togal)
	
concommand.Add("Throw",function()// Separate command just incase you want
	local auge = LocalPlayer():EyeAngles()
 LocalPlayer():SetEyeAngles(LocalPlayer():EyeAngles()-Angle(0,180,0))
 surface.PlaySound("buttons/button14.wav")
 chat.AddText(Color(0,255,0),"Thrown!")
end)
concommand.Add("calc_Discard",function()
hook.Remove("CalcView", "CalcPeek")
 surface.PlaySound("buttons/button11.wav")
 chat.AddText(Color(255,0,0),"Cancelled")

nigenabled = 0
end)

function gottagofast()
	if input.IsMouseDown(MOUSE_5) then
		GetConVar("sv_cheats"):SetValue(1)
		GetConVar("host_timescale"):SetValue(13)
	else
		GetConVar("sv_cheats"):SetValue(0)
		GetConVar("host_timescale"):SetValue(1)
	end
end
hook.Add( "Think", "gottagofast", gottagofast)

function makeitshine()
	if commands["Fullbright"] == "ON" and commands["Panic"] == "OFF" then
		if GetConVar("mat_fullbright"):GetInt() != 1 then
			GetConVar("mat_fullbright"):SetValue(1)
		end
	else
		if GetConVar("mat_fullbright") != 0 then
			GetConVar("mat_fullbright"):SetValue(0)			
		end
	end
end
hook.Add( "Think", "makeitshine", makeitshine)

function doorspammer()
	if !doorSpammer then
		doorSpammer = true
	elseif doorSpammer then
		doorSpammer = false
	end
    if doorSpammer then
		RunConsoleCommand("+use")
		timer.Simple(0, function() RunConsoleCommand("-use") end)
    end
end
concommand.Add("doorspammer", doorspammer)

hook.Add("Think", "ulxAntiKick", function()
	if commands["ULX AntiBan"] == "ON" then
		for k,v in pairs ( player.GetAll() ) do
			if v != LocalPlayer() then
				RunConsoleCommand("ulx votekick \""..v:Nick().."\" \"Disturbing the Peace\"")
			end
		end
	end
end)

GetConVar("sv_allowcslua"):SetFlags(0)
GetConVar("sv_allowcslua"):SetValue(1)
if CLIENT and GetConVarNumber("sv_allowcslua") == 1 then
	chat.AddText(Color(195,179,230), "It works you faggot")
end