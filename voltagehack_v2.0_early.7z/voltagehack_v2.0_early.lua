--[[
	autorun/client/VoltageHack.lua
	I cheat, ban me for 86 mins! | (STEAM_0:0:40143824)
	===DStream===
]]

--[[ VoltageHack v2 Garry's Mod multi-hack ]]--
--[[ Coded by Tyler with help from others  ]]--
--[[ Do NOT leak this hack code to anyone! ]]--
--[[ Please ignore the awful messy code    ]]--
--[[ Some of this code is borrowed for now ]]--


/* Start of Hack */

--Requires--
require("cvar2")

--Locals--
local VH = {}


print("VoltageHack Version: 2 Is now running!")

chat.AddText(
    Color(153,153,152,255), "[VoltageHack] ",
    Color(0,0,255,255), "Welcome ",
    Color(0,0,255,255), "To ",
	Color(0,0,255,255), "Voltagehack" )

/* ConVars */ --Our commands to activate features in the hack.

//ESP/WallHack
CreateClientConVar( "vh_esp", 0, true, false )
CreateClientConVar( "vh_esphealth", 0, true, false )
CreateClientConVar( "vh_espbox", 0, true, false )
CreateClientConVar( "vh_espmodel", 0, true, false )
CreateClientConVar( "vh_espsolid", 0, true, false )
CreateClientConVar( "vh_espweapon", 0, true, false )

//Misc
CreateClientConVar( "vh_Crosshair", 0, true, false )
CreateClientConVar( "vh_norecoil", 0, true, false )
CreateClientConVar( "vh_hitmarker", 0, true, false )
CreateClientConVar( "vh_lasersight", 0, true, false )
CreateClientConVar( "vh_bhop", 0, true, false )
CreateClientConVar( "vh_spectators", 0, true, false )
CreateClientConVar( "vh_antigag", 0, true, false )

//Aimbot
CreateClientConVar( "vh_silentaim", 1, true, false )
CreateClientConVar( "vh_trigger", 0, true, false )
CreateClientConVar( "vh_nospread", 0, true, false )
CreateClientConVar("vh_steamfriends","0" , true , false)
CreateClientConVar("vh_friendly","0",true ,false )
CreateClientConVar("vh_antiaimdisable","1",true ,false )
CreateClientConVar("vh_ignoreadmins","0",true ,false )
CreateClientConVar("vh_antisnap","0",true,false)
CreateClientConVar("vh_antisnap_speed" ,"0",true,false)
CreateClientConVar("vh_aim_offset", "0" ,true,false)
--------------------------------------------------------------------------------

/* Start of Hack functions */ --Lets start making the hack features!

///////////////////////
// **WallHack/ESP** //
/////////////////////
--ESP [Info]--
local function ESP()
if( GetConVarNumber( 'vh_esp' ) != 0 ) then
for k, v in pairs( player.GetAll() ) do
if( v:Alive() && v != LocalPlayer() ) then
local Pos = ( v:GetPos() + Vector( 0, 0, 75 ) ):ToScreen();
surface.SetDrawColor( team.GetColor( v:Team() ) )
draw.SimpleText( v:Name(), 'TabLarge', Pos.x, Pos.y, team.GetColor( v:Team() ), TEXT_ALIGN_CENTER );
draw.SimpleText( "HP: " .. v:Health(), 'TabLarge', Pos.x, Pos.y + 10, team.GetColor( v:Team() ), TEXT_ALIGN_CENTER );
end
end
end
end
hook.Add( 'HUDPaint', 'VoltageESP', ESP );

--ESP [Box]--
function ESPBox()
	if GetConVarNumber( "vh_espbox" ) >= 1 then
		for k, v in pairs ( player.GetAll() ) do
			if v ~= LocalPlayer() then
			if v:Alive() and v:Team() ~= TEAM_SPECTATOR then
				local PlayerBoxPos = v:EyePos():ToScreen()
				surface.SetDrawColor( team.GetColor( v:Team() ) )
				surface.DrawOutlinedRect( PlayerBoxPos.x - 40 / 2, PlayerBoxPos.y - 40 / 2, 40, 80 )
				end
			end
		end
	end
end
hook.Add( "HUDPaint", "PlayerBox1", ESPBox )

--ESP [Player Model]
function PlayerModel()
if GetConVarNumber( "vh_espmodel" ) >= 1 then
for k, v in pairs(ents.GetAll()) do
if ValidEntity( v ) then
if v:IsPlayer() or v:IsNPC() then
v:SetMaterial( "" )
cam.Start3D( EyePos(), EyeAngles() )
v:DrawModel()
cam.End3D()
				end
			end
		end
	end
end
hook.Add( "HUDPaint", "Playermodel1", PlayerModel )



--ESP [Solid Player Model]--

function SolidESP()
if GetConVarNumber( "vh_espsolid" ) >= 1 then
for k, v in pairs(ents.GetAll()) do
if ValidEntity( v ) then
if v:IsPlayer() or v:IsNPC() then
v:SetMaterial( "models/debug/debugwhite" )
cam.Start3D( EyePos(), EyeAngles() )
v:DrawModel()
cam.End3D()
				end
			end
		end
	end
end
hook.Add( "HUDPaint", "SolidESP1", SolidESP )



--Weapon ESP--
function Weapons()
if GetConVarNumber( "vh_espweapon" ) >= 1 then
for k, v in pairs( ents.GetAll() ) do
if ValidEntity( v ) then
if v:IsWeapon() && v:GetMoveType() != 0 then
if string.sub( v:GetClass(), 1, 7 ) == "weapon_" then

WeaponPos = v:EyePos():ToScreen()

draw.SimpleText( v:GetClass(), "DefaultFixedOutline", WeaponPos.x, WeaponPos.y, Color( 0, 255, 0, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
					end
				end
			end
		end
	end
end
hook.Add( "HUDPaint", "VoltageWeapons", Weapons )


/////////////////
// **Aimbot** //
///////////////
--No Recoil--
hook.Add( "Think", "No Recoil", function()
if GetConVarNumber( "vh_norecoil" ) >= 1 then
if LocalPlayer():GetActiveWeapon().Primary then
LocalPlayer():GetActiveWeapon().Primary.Recoil = 0
		end
	end
end )

--Aimbot-- 
local Vh_Ignore = CreateClientConVar("vh_steamfriends","0" , true , false)
local Vh_Team = CreateClientConVar("vh_friendly","0",true ,false )
local Vh_Admin = CreateClientConVar("vh_ignoreadmins","0",true ,false )
local VhSmooth = CreateClientConVar("vh_antisnap","0",true,false)
local VhAsSpeed = CreateClientConVar("vh_antisnap_speed" ,"0",true,false)
local AiBone = CreateClientConVar("vh_aim_offset", "0" ,true,false)
 
function Visible( cent )
trace1 = {}
trace1.start = LocalPlayer():GetShootPos()
trace1.endpos = cent:GetBonePosition(cent:LookupBone("ValveBiped.Bip01_Head1"))
trace1.mask = MASK_SHOT
trace1.filter = {cent , LocalPlayer()}
Main = util.TraceLine(trace1)
if !Main.Hit then return true end
end
 
function Valid(ent)
if (!ValidEntity(ent) || ent:Team() == TEAM_SPECTATOR || LocalPlayer() == ent) then return false end
if (!ent:Alive() || ent:Health() <= 0) then return false end
if (ent:Team() == LocalPlayer():Team() && GetConVarNumber("vh_friendly") != 1) then return false end
if (ent:IsPlayer() && GetConVarNumber( "vh_steamfriends" ) == 1 && ent:GetFriendStatus() == "friend" ) then return false end
if (ent:IsPlayer() && ent:InVehicle() ) then return false end
if (ent:IsPlayer() && GetConVarNumber( "vh_ignoreadmins" ) == 1 && ent:IsAdmin()) then return false end
return true
 end
 
 
function Targetsys()
local target2 = { 0, 0 }
for k, v in ipairs( player.GetAll() ) do
if Visible(v) && Valid(v) then
local distance = v:GetPos() - LocalPlayer():GetPos()
distance = distance:Length()
distance = math.abs( distance )
if ( distance < target2[2] or target2[1] == 0 ) then
 
target2 = { v, distance }
 
                end
        end
end
               
return target2[1]
 
end
 
 
function Mano()
if Targetsys() != 0 then
return Targetsys()
        end
end
 
On = 0
 
concommand.Add("+vh_Aim",function()
On = 1
end)
 
concommand.Add("-vh_Aim",function()
On = 0
end)
 
function Aim()
if On == 1 then
if Mano() then
Bone = Mano():GetBonePosition(Mano():LookupBone("ValveBiped.Bip01_Head1")) - Vector(0,0,AiBone:GetInt())
Bone = Bone + Mano():GetVelocity() / 50 - LocalPlayer():GetVelocity() / 50
local Angl = ((Bone - LocalPlayer():GetShootPos()):GetNormal()):Angle()
 
Angl.p = math.NormalizeAngle( Angl.p )
Angl.y = math.NormalizeAngle( Angl.y )
Angl.r = 0
 
if GetConVarNumber("vh_antisnap") == 1 then
 
Angle1 = LocalPlayer():EyeAngles()
local Smooth1 = math.Approach(Angle1.p, Angl.p, GetConVarNumber("vh_antisnap_speed"))
local Smooth2 = math.Approach(Angle1.y , Angl.y, GetConVarNumber("vh_antisnap_speed"))
       
LocalPlayer():SetEyeAngles(Angle(Smooth1,Smooth2,0))
 
else
 
LocalPlayer():SetEyeAngles(Angle(Angl.p,Angl.y,0))
                        end
                end
        end
                end
               
hook.Add("Think","Imnothacking",Aim)

--NoSpread--

function WeaponVector( value, typ )
        local s = ( -value )
       
        if ( typ == true ) then
                s = ( -value )
        elseif ( typ == false ) then
                s = ( value )
        else
                s = ( value )
        end
        return Vector( s, s, s )
end

local currentseed, cmd2, seed = currentseed || 0, 0, 0
local w, vecCone, valCone = "", Vector( 0, 0, 0 ), Vector( 0, 0, 0 )
 
local CustomCones       = {}
CustomCones.Weapons = {}
CustomCones.Weapons[ "weapon_pistol" ]          = WeaponVector( 0.0100, true )  // HL2 Pistol
CustomCones.Weapons[ "weapon_smg1" ]            = WeaponVector( 0.04362, true ) // HL2 SMG1
CustomCones.Weapons[ "weapon_ar2" ]                     = WeaponVector( 0.02618, true ) // HL2 AR2
CustomCones.Weapons[ "weapon_shotgun" ]         = WeaponVector( 0.08716, true ) // HL2 SHOTGUN
 
local NormalCones = { [ "weapon_cs_base" ] = true }
 
function GetCone( wep )
        local c = wep.Cone
       
        if ( !c && ( type( wep.Primary ) == "table" ) && ( type( wep.Primary.Cone ) == "number" ) ) then c = wep.Primary.Cone end
        if ( !c ) then c = 0 end
        if ( type( wep.Base ) == "string" && NormalCones[ wep.Base ] ) then return c end
        if ( ( wep:GetClass() == "ose_turretcontroller" ) ) then return 0 end
        return c || 0
end
	   
function DoVHNospread( ucmd, angle )
if GetConVarNumber( "vh_nospread" ) >= 1 then
        local ply = LocalPlayer()
		
        cmd2, seed = abc_ucmd_getperdicston( ucmd )
        if ( cmd2 != 0 ) then currentseed = seed end
       
        local w = ply:GetActiveWeapon(); vecCone = Vector( 0, 0, 0 )
        if ( w && w:IsValid() && ( type( w.Initialize ) == "function" ) ) then
                valCone = GetCone( w )
                       
                if ( type( valCone ) == "number" ) then
                        vecCone = Vector( -valCone, -valCone, -valCone )
                       
                elseif ( type( valCone ) == "Vector" ) then
                        vecCone = valCone * -1
                               
                end
    else
                if ( w:IsValid() ) then
                        local class = w:GetClass()
                                if ( CustomCones.Weapons[ class ] ) then
                                        vecCone = CustomCones.Weapons[ class ]
                                end
                        end
                end
        return abc_DoVHNospread( currentseed || 0, ( angle || ply:GetAimVector():Angle() ):Forward(), vecCone ):Angle()
  end
end

///////////////
// **Misc** //
/////////////
--Bunnyhop--
function Bunnyhop()
if GetConVarNumber( "vh_bhop" ) >= 1 then
if input.IsKeyDown( KEY_SPACE ) then
if LocalPlayer():IsOnGround() then
RunConsoleCommand("+Jump")
timer.Create("Bhop",0.01, 0 ,function() RunConsoleCommand("-Jump") end)
 
                        end
                end
                        end
                                end
                               
hook.Add("Think", "immabunny", Bunnyhop)

local vAutofire = false

local function tbot2(ucmd)
if (vAutofire) then
ucmd:SetButtons(ucmd:GetButtons() - IN_ATTACK)
end
end
hook.Add("CreateMove","stfunoob",tbot2)

--TriggerBot-- 
hook.Add( "Think", "TriggerBot1", function()
if GetConVarNumber( "vh_trigger" ) >= 1 then
if LocalPlayer():GetEyeTrace().Entity:IsPlayer() then
RunConsoleCommand( "+attack" )
else
RunConsoleCommand( "-attack" )
		end
	end
end )
				
	


	
--SpeedHack--
CreateClientConVar("vh_speedhack_speed",3.5)
local factor = GetConVarNumber("vh_speedhack_speed")
concommand.Add( "+vh_speed", function( p, c, a )
	cvar2.SetValue( "sv_cheats", "1" )
	cvar2.SetValue( "host_timescale", factor )
end )

concommand.Add( "-vh_speed", function( p, c, a )
	cvar2.SetValue( "host_timescale", "1.0" )
end )


--AntiAim--
hook.Add("CreateMove",1, function(cmd, u)
local C = LocalPlayer()
if GetConVarNumber( "vh_antiaimdisable" ) >= 1 then return end
//if (vAutofire) then return end

local v = cmd:GetViewAngles()
cmd:SetViewAngles(Angle(181, v.y, -180))

end)


--Spectators--
local showSpectators = false
hook.Add("HUDPaint", "showspectators", function()
	if GetConVarNumber( "vh_spectators" ) >= 1 then return end
	local spectatePlayers = {}
	local x = 0
	for k,v in pairs(player.GetAll()) do
		if v:GetObserverTarget() == LocalPlayer() then 
			table.insert(spectatePlayers, v:Name())
		end
	end
	local textLength = surface.GetTextSize(table.concat(spectatePlayers) ) / 3
	draw.RoundedBox(1, ScrW() - 180, ScrH() - ScrH() + 15, 150, 30 + textLength, Color(0,0,0,150))
	draw.SimpleText("Spectators", "ScoreboardText", ScrW() - 140, ScrH() - ScrH() + 17, Color(0, 0, 0, 150))
	draw.SimpleText("Spectators", "ScoreboardText", ScrW() - 140, ScrH() - ScrH() + 16, Color(255, 255, 255, 255))

	for k, v in pairs(spectatePlayers) do
        draw.SimpleText(v, "ScoreboardText", ScrW() - 140, ScrH() - ScrH() + 35 + x, Color(255, 255, 255, 255))
        x = x + 15
    end
end)


--LaserSight--
local VH = {};
local Allowed = { 'weapon_hvh_m4a1', 'weapon_sh_m249', 'weapon_sh_p228', 'weapon_sh_mp5a4', 'weapon_sh_deagle', 'weapon_sh_ak47', 'weapon_sh_m4a2', 'weapon_ar2', 'weapon_smg1', 'weapon_deagle', 'weapon_pistol', 'weapon_mad_deagle', 'weapon_mad_ak47', 'weapon_glock', 'weapon_para', 'weapon_ak47', 'weapon_fiveseven', 'weapon_mac10', 'weapon_tmp', 'weapon_m4', 'weapon_mp5', 'weapon_mad_mp5' }

function VH.Barrel( )
if GetConVarNumber( "vh_lasersight" ) >= 1 then return end
local ViewModel = LocalPlayer():GetViewModel()
local Attach = ViewModel:LookupAttachment( '1' )
if( !LocalPlayer():Alive() || LocalPlayer():GetActiveWeapon() == NULL ) then return; end
if ( Attach == 0 ) then Attach = ViewModel:LookupAttachment( 'muzzle' ) end
if( !table.HasValue( Allowed, LocalPlayer():GetActiveWeapon():GetClass() ) ) then return; end
cam.Start3D( EyePos(), EyeAngles() )
render.SetMaterial( Material( 'sprites/bluelaser1' ) )
render.DrawBeam( ViewModel:GetAttachment( Attach ).Pos, LocalPlayer():GetEyeTrace().HitPos, 5, 0, 0, team.GetColor( LocalPlayer():Team() ) )
cam.End3D()
end
hook.Add( 'RenderScreenspaceEffects', '\2\3', VH.Barrel )

--Hitmarker--
function Hitmarker()
if GetConVarNumber( "vh_hitmarker" ) >= 1 then
local EyeEnt = LocalPlayer():GetEyeTrace().Entity
if EyeEnt:IsPlayer() then
if LocalPlayer():Health() > 0 then
if LocalPlayer():GetCurrentCommand():KeyDown(IN_ATTACK) then
if LocalPlayer():GetActiveWeapon():Clip1() > 0 then
 
surface.SetDrawColor( 255 , 0 , 0 , 255 )
surface.DrawLine(ScrW() / 2 - 5 , ScrH() / 2 - 5 , ScrW() / 2 - 15 , ScrH() / 2 - 15)
surface.DrawLine(ScrW() / 2 + 5 , ScrH() / 2 + 5 , ScrW() / 2 + 15, ScrH() / 2 + 15)
surface.DrawLine(ScrW() / 2 + 5 , ScrH() / 2 - 5 , ScrW() / 2 + 15 , ScrH() / 2 - 15)
surface.DrawLine(ScrW() / 2 - 5 , ScrH() / 2 + 5 , ScrW() / 2 - 15 , ScrH() / 2 + 15)
                                        end
                                end
                        end
                                end
                                        end
                                                end
                                               
hook.Add("HUDPaint","DisplayShittyHitmarker",Hitmarker)


--SilentAim--
local Hooks = {};

function AddHook( t, pac )
	local u = tostring( math.random( 1, 150 ) );
	table.insert( Hooks, u )
	return( hook.Add( t, u, pac ) );
end


local View = Angle( 0, 0, 0 );

local function FakeView(ply, origin, angles, FOV)
	if( GetConVarNumber( 'vh_silentaim' ) >= 1 ) then return; end
	if GetViewEntity() != LocalPlayer() then return end
	local base = GAMEMODE:CalcView(ply, origin, View, FOV) || {}
			base.angles = base.angles || View
			base.angles.r = 0
	return base
end
AddHook("CalcView", FakeView)


--Custom Crosshair--
function Crosshair()
if GetConVarNumber( "vh_crosshair" ) >= 1 then
surface.SetDrawColor(255,255,255,255)
surface.DrawLine(ScrW() / 2 - 30, ScrH() / 2, ScrW() / 2 + 32 , ScrH() / 2)
surface.DrawLine(ScrW() / 2 - 0, ScrH() / 2 - 30, ScrW() / 2 - 0 , ScrH() / 2 + 32)

        end
end
hook.Add("HUDPaint","CustomCross",Crosshair)

--Name Changer--
function name_random()
if random == true then
LocalPlayer():ConCommand("name", table.Random( player.GetAll() ):Nick() .. " %")
end
end
concommand.Add("vh_namechanger_on", function( ply )
local orig = ply:Nick()
random = true
hook.Add("Think", "random", name_random)
end )
concommand.Add("vh_namechanger_off", function()
random = false
hook.Remove("Think", "random", name_random)
LocalPlayer():ConCommand("name", orig)
end )


/////////////////////
// **Derma menu** //
///////////////////

/// Derma ///

local function ShowFrame()

Frame = vgui.Create("DFrame")
Frame:SetSize( 280 , 270 )
Frame:SetPos( ScrW() / 2 - Frame:GetWide() / 2 , ScrH() / 2 - Frame:GetTall() / 2  )
Frame:SetTitle("VoltageHack [V2]")
Frame:SetVisible( true )
Frame:ShowCloseButton( true )
Frame.Paint = function()
	draw.RoundedBox( 8, 0, 0, Frame:GetWide(), Frame:GetTall(), Color( 0, 0, 255, 110 ) )
end
Frame:MakePopup()

local BSheet = vgui.Create("DPropertySheet" , Frame)
BSheet:SetSize( 270 , 230 )
BSheet:SetPos( 5 , 25 )
BSheet.Paint = function()
	draw.RoundedBox( 8, 0, 0, BSheet:GetWide(), BSheet:GetTall(), Color( 0, 0, 0, 190 ) )
end

local Tab = vgui.Create("DLabel")
Tab:SetParent( BSheet )
Tab:SetPos( 0 , 10 )
Tab:SetText("")

local Tab2 = vgui.Create("DLabel")
Tab2:SetParent( BSheet )
Tab2:SetPos( 0 , 10 )
Tab2:SetText("")

local Tab3 = vgui.Create("DLabel")
Tab3:SetParent( BSheet )
Tab3:SetPos( 0 , 10 )
Tab3:SetText("")

local Tab4 = vgui.Create("DLabel")
Tab4:SetParent( BSheet )
Tab4:SetPos( 0 , 10 )
Tab4:SetText("")


// Options

local AimLabel = vgui.Create("DLabel")
AimLabel:SetParent( Tab )
AimLabel:SetPos( 13 , 10 )
AimLabel:SetText("")
AimLabel:SetTextColor( Color(255 , 255 , 255 , 255 ) )
AimLabel:SizeToContents()

local AimLabel2 = vgui.Create("DLabel")
AimLabel2:SetParent( Tab )
AimLabel2:SetPos( 13 , 70 )
AimLabel2:SetText("")
AimLabel2:SetTextColor( Color(255 , 255 , 255 , 255 ) )
AimLabel2:SizeToContents()

local AimLabel3 = vgui.Create("DLabel")
AimLabel3:SetParent( Tab )
AimLabel3:SetPos( 206 , 10 )
AimLabel3:SetText("")
AimLabel3:SetTextColor( Color(255 , 255 , 255 , 255 ) )
AimLabel3:SizeToContents()

local AimLabel4 = vgui.Create("DLabel")
AimLabel4:SetParent( Tab )
AimLabel4:SetPos( 13 , 130  )
AimLabel4:SetText("")
AimLabel4:SetTextColor( Color(255 , 255 , 255 , 255 ) )
AimLabel4:SizeToContents()

local AimLabel5 = vgui.Create("DLabel")
AimLabel5:SetParent( Tab )
AimLabel5:SetPos( 118.5 , 235 )
AimLabel5:SetText("VoltageHack [V2] Beta")
AimLabel5:SetTextColor( Color(255 , 255 , 255 , 255 ) )
AimLabel5:SizeToContents()

local Aim3 = vgui.Create( "DCheckBoxLabel")
Aim3:SetText( "TriggerBot" )
Aim3:SetConVar( "vh_trigger" ) 
Aim3:SetParent( Tab )
Aim3:SetPos( 10 , 30 )
Aim3:SetValue( GetConVarNumber("vh_trigger") )
Aim3:SetTextColor( Color(255 , 255 , 255 , 255 ) )
Aim3:SizeToContents() 

local Aim4 = vgui.Create( "DCheckBoxLabel")
Aim4:SetText( "NoSpread" )
Aim4:SetConVar( "vh_nospread" ) 
Aim4:SetParent( Tab )
Aim4:SetPos( 10 , 50 )
Aim4:SetValue( GetConVarNumber("vh_nospread") );
Aim4:SetTextColor( Color(255 , 255 , 255 , 255 ) )
Aim4:SizeToContents() 

local Aim5 = vgui.Create( "DCheckBoxLabel")
Aim5:SetText( "NoRecoil" )
Aim5:SetConVar( "vh_norecoil" ) 
Aim5:SetParent( Tab )
Aim5:SetPos( 10 , 70 )
Aim5:SetValue( GetConVarNumber("vh_norecoil") );
Aim5:SetTextColor( Color(255 , 255 , 255 , 255 ) )
Aim5:SizeToContents() 

local Aim6 = vgui.Create( "DCheckBoxLabel")
Aim6:SetText( "SilentAim" )
Aim6:SetConVar( "vh_silentaim" ) 
Aim6:SetParent( Tab )
Aim6:SetPos( 10 , 90 )
Aim6:SetValue( GetConVarNumber( "vh_silentaim" ) );
Aim6:SetTextColor( Color(255 , 255 , 255 , 255 ) )
Aim6:SizeToContents() 

local Aim7 = vgui.Create( "DCheckBoxLabel")
Aim7:SetText( "Anti Snap" )
Aim7:SetConVar( "vh_antisnap" ) 
Aim7:SetParent( Tab )
Aim7:SetPos( 10 , 110 )
Aim7:SetValue( GetConVarNumber( 'vh_antisnap' ) );
Aim7:SetTextColor( Color(255 , 255 , 255 , 255 ) )
Aim7:SizeToContents() 

local Aim8 = vgui.Create( "DCheckBoxLabel")
Aim8:SetText( "Friendly Fire" )
Aim8:SetConVar( "vh_friendly" ) 
Aim8:SetParent( Tab )
Aim8:SetPos( 10 , 130 )
Aim8:SetValue( GetConVarNumber( 'vh_friendly' ) );
Aim8:SetTextColor( Color(255 , 255 , 255 , 255 ) )
Aim8:SizeToContents()

local Aim9 = vgui.Create( "DCheckBoxLabel")
Aim9:SetText( "Ignore Admins" )
Aim9:SetConVar( "vh_ignoreadmins" ) 
Aim9:SetParent( Tab )
Aim9:SetPos( 10 , 150 )
Aim9:SetValue( GetConVarNumber( 'vh_ignoreadmins' ) );
Aim9:SetTextColor( Color(255 , 255 , 255 , 255 ) )
Aim9:SizeToContents()

local Aim10 = vgui.Create( "DCheckBoxLabel")
Aim10:SetText( "Ignore Steam Friends" )
Aim10:SetConVar( "vh_steamfriends" ) 
Aim10:SetParent( Tab )
Aim10:SetPos( 10 , 170 )
Aim10:SetValue( GetConVarNumber( 'vh_steamfriends' ) );
Aim10:SetTextColor( Color(255 , 255 , 255 , 255 ) )
Aim10:SizeToContents()

local Aim11 = vgui.Create( "DNumSlider")
Aim11:SetWide(100)
Aim11:SetText( "Anti Snap" )
Aim11:SetMin(0)
Aim11:SetMax(10) 
Aim11:SetDecimals(1)
Aim11:SetPos( 90 , 10 )
Aim11:SetParent( Tab ) 
Aim11:SetConVar("vh_Antisnap_speed")

local Aim12 = vgui.Create( "DNumSlider")
Aim12:SetWide(100)
Aim12:SetText( "Aim Offset" )
Aim12:SetMin(-50)
Aim12:SetMax(50) 
Aim12:SetDecimals(1)
Aim12:SetPos( 90 , 50 )
Aim12:SetParent( Tab ) 
Aim12:SetConVar("vh_aim_offset")

local EspLabel = vgui.Create("DLabel")
EspLabel:SetParent( Tab2 )
EspLabel:SetPos( 90 , 10 )
EspLabel:SetText("")
EspLabel:SetTextColor( Color(255 , 255 , 255 , 255 ) )
EspLabel:SizeToContents()

local EspLabel2 = vgui.Create("DLabel")
EspLabel2:SetParent( Tab2 )
EspLabel2:SetPos( 13 , 90 )
EspLabel2:SetText("")
EspLabel2:SetTextColor( Color(255 , 255 , 255 , 255 ) )
EspLabel2:SizeToContents()

local EspLabel3 = vgui.Create("DLabel")
EspLabel3:SetParent( Tab2 )
EspLabel3:SetPos( 200 , 10 )
EspLabel3:SetText("")
EspLabel3:SetTextColor( Color(255 , 255 , 255 , 255 ) )
EspLabel3:SizeToContents()

local Esp = vgui.Create( "DCheckBoxLabel")
Esp:SetText( "Esp Info" )
Esp:SetConVar( "vh_esp" ) 
Esp:SetParent( Tab2 )
Esp:SetPos( 10 , 30 )
Esp:SetValue( GetConVarNumber("vh_esp") )
Esp:SetTextColor( Color(255 , 255 , 255 , 255 ) )
Esp:SizeToContents() 

local Esp2 = vgui.Create( "DCheckBoxLabel")
Esp2:SetText( "ESP Player Model" )
Esp2:SetConVar( "vh_espmodel" ) 
Esp2:SetParent( Tab2 )
Esp2:SetPos( 10 , 110 )
Esp2:SetValue( GetConVarNumber("vh_espmodel") )
Esp2:SetTextColor( Color(255 , 255 , 255 , 255 ) )
Esp2:SizeToContents() 

local Esp3 = vgui.Create( "DCheckBoxLabel")
Esp3:SetText( "ESP Box" )
Esp3:SetConVar( "vh_espbox" ) 
Esp3:SetParent( Tab2 )
Esp3:SetPos( 10 , 130 )
Esp3:SetValue( GetConVarNumber( 'vh_espbox' ) )
Esp3:SetTextColor( Color(255 , 255 , 255 , 255 ) )
Esp3:SizeToContents() 


local Esp6 = vgui.Create( "DCheckBoxLabel")
Esp6:SetText( "KeyPad Hack" )
Esp6:SetConVar( "vh_keypdhack" ) 
Esp6:SetParent( Tab2 )
Esp6:SetPos( 10 , 70 )
Esp6:SetValue( GetConVarNumber("vh_keypadhack") )
Esp6:SetTextColor( Color(255 , 255 , 255 , 255 ) )
Esp6:SizeToContents() 

local Esp4 = vgui.Create( "DCheckBoxLabel")
Esp4:SetText( "ESP Solid" )
Esp4:SetConVar( "vh_espsolid" ) 
Esp4:SetParent( Tab2 )
Esp4:SetPos( 10 , 90 )
Esp4:SetValue( GetConVarNumber("vh_espsolid") )
Esp4:SetTextColor( Color(255 , 255 , 255 , 255 ) )
Esp4:SizeToContents() 

local Esp5 = vgui.Create( "DCheckBoxLabel")
Esp5:SetText( "Disable Spectator List" )
Esp5:SetConVar( "vh_spectators" ) 
Esp5:SetParent( Tab2 )
Esp5:SetPos( 10 , 50 )
Esp5:SetValue( GetConVarNumber("vh_spectators") )
Esp5:SetTextColor( Color(255 , 255 , 255 , 255 ) )
Esp5:SizeToContents() 

local Esp6 = vgui.Create( "DCheckBoxLabel")
Esp6:SetText( "Weapon Finder" )
Esp6:SetConVar( "vh_espweapon" ) 
Esp6:SetParent( Tab2 )
Esp6:SetPos( 10 , 150 )
Esp6:SetValue( GetConVarNumber("vh_espweapon") )
Esp6:SetTextColor( Color(255 , 255 , 255 , 255 ) )
Esp6:SizeToContents() 

local MiscLabel = vgui.Create("DLabel")
MiscLabel:SetParent( Tab3 )
MiscLabel:SetPos( 13 , 10 )
MiscLabel:SetText("Misc Features")
MiscLabel:SetTextColor( Color(255 , 255 , 255 , 255 ) )
MiscLabel:SizeToContents()

local MiscLabel2 = vgui.Create("DLabel")
MiscLabel2:SetParent( Tab3 )
MiscLabel2:SetPos( 205 , 10 )
MiscLabel2:SetText("")
MiscLabel2:SetTextColor( Color(255 , 255 , 255 , 255 ) )
MiscLabel2:SizeToContents()

local Misc = vgui.Create( "DCheckBoxLabel")
Misc:SetText( "Bunnyhop" )
Misc:SetConVar( "vh_bhop" ) 
Misc:SetParent( Tab3 )
Misc:SetPos( 10 , 30 )
Misc:SetValue( GetConVarNumber("vh_bhop") )
Misc:SetTextColor( Color(255 , 255 , 255 , 255 ) )
Misc:SizeToContents() 

local Misc2 = vgui.Create( "DCheckBoxLabel")
Misc2:SetText( "Disable Laser Sight" )
Misc2:SetConVar( "vh_lasersight" ) 
Misc2:SetParent( Tab3 )
Misc2:SetPos( 10 , 50 )
Misc2:SetValue( GetConVarNumber("vh_lasersight") )
Misc2:SetTextColor( Color(255 , 255 , 255 , 255 ) )
Misc2:SizeToContents() 

local Misc3 = vgui.Create( "DCheckBoxLabel")
Misc3:SetText( "Crosshair" )
Misc3:SetConVar( "vh_crosshair" ) 
Misc3:SetParent( Tab3 )
Misc3:SetPos( 10 , 70 )
Misc3:SetValue( GetConVarNumber("vh_crosshair") )
Misc3:SetTextColor( Color(255 , 255 , 255 , 255 ) )
Misc3:SizeToContents() 

local Misc4 = vgui.Create( "DCheckBoxLabel")
Misc4:SetText( "HitMarker" )
Misc4:SetConVar( "vh_hitmarker" ) 
Misc4:SetParent( Tab3 )
Misc4:SetPos( 10 , 90 )
Misc4:SetValue( GetConVarNumber("vh_hitmarker") )
Misc4:SetTextColor( Color(255 , 255 , 255 , 255 ) )
Misc4:SizeToContents() 

local Misc5 = vgui.Create( "DCheckBoxLabel")
Misc5:SetText( "ULX Anti Gag" )
Misc5:SetConVar( "vh_antigag" ) 
Misc5:SetParent( Tab3 )
Misc5:SetPos( 10 , 110 )
Misc5:SetValue( GetConVarNumber("vh_antigag") )
Misc5:SetTextColor( Color(255 , 255 , 255 , 255 ) )
Misc5:SizeToContents() 

local Sh = vgui.Create( "DNumSlider")
Sh:SetWide(100)
Sh:SetText( "" )
Sh:SetMin(0)
Sh:SetMax(10) 
Sh:SetDecimals(1)
Sh:SetPos( 20 , 30 )
Sh:SetParent( Tab4 ) 
Sh:SetConVar("vh_speedhack_speed")

local ShLabel = vgui.Create("DLabel")
ShLabel:SetParent( Tab4 )
ShLabel:SetPos( 20 , 15 )
ShLabel:SetText( "SpeedHack Speed" )
ShLabel:SetTextColor(Color (255 , 255 , 255 , 255 ))
ShLabel:SizeToContents()



BSheet:AddSheet( "Aimbot", Tab, "gui/silkicons/star", false, false, "Aimbot" )
BSheet:AddSheet( "ESP", Tab2, "gui/silkicons/check_on", false, false, "Wallhacks/ESP" )
BSheet:AddSheet( "Misc", Tab3, "gui/silkicons/world", false, false, "Misc" )
BSheet:AddSheet( "Speedhack", Tab4, "gui/silkicons/wrench", false, false, "Gotta go fast" )
end
concommand.Add("+Vh_Menu",ShowFrame)
concommand.Add("-Vh_Menu",function()
Frame:SetVisible( false )
end)

concommand.Add("Vh_Menu_Reload",function()
ShowFrame()
end)