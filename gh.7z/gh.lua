--[[
	MOD/lua/yolo.lua [#6191 (#6507), 3799060475]
	TheRedShroom | STEAM_0:1:70260079 <217.131.115.56:27005> | [04.12.13 04:14:34PM]
	===BadFile===
]]


local GH = {}


function GH.Copy(orig)
local orig_type = type(orig)
local copy
if orig_type == 'table' then
copy = {}
for orig_key, orig_value in next, orig, nil do
copy[GH.Copy(orig_key)] = GH.Copy(orig_value)
end
setmetatable(copy, GH.Copy(getmetatable(orig)))
else
copy = orig
end
return copy
end


local _g, reg = table.Copy(_G), debug.getregistry()
local CreateClientConVar = _g.CreateClientConVar
local GetConVarNumber = _g.GetConVarNumber
local concommand = _g.concommand
local hook = _g.hook
local require = _g.require
local GetConVar = _g.GetConVar


GH.Ply = LocalPlayer()


function GH.CreateCConVar(var) return CreateClientConVar(var, "0", false, false) end
function GH.CreateChangeAble(var, am) return CreateClientConVar(var, am) end
function GH.GetCConVarNum(var) return GetConVarNumber(var) end
function GH.CreateConCommand(var, func) return concommand.Add(var, func) end
function GH.GetCConVar(var) return GetConVar(var) end


GH.Admins = {}
GH.Ents = { 
 "ent_coca",
 "ent_pot",
 "ent_item"
}


function GH.CalculateDistance( Ent ) 
local distance = Ent:GetPos():Distance( GH.Ply:GetPos() ) 


if distance <= GH.GetCConVarNum("gh_distance") then return true else return false end 
end


function GH.GetValidEnt( ent ) return table.HasValue( GH.Ents, ent:GetClass() ) end


function GH.GetAdmins()
for _, ply in pairs(player.GetAll()) do
if ( ply:IsAdmin() or ply:IsSuperAdmin() ) then
table.insert(GH.Admins, ply:Nick())
end
end


return PrintTable(GH.Admins)
end


function GH.Random()
return tostring(string.char(math.random(1, 52)) .. string.char(math.random(1, 52)) .. string.char(math.random(1, 52)) .. math.random(1, 600))
end


function GH.AddHook(name, func)
return hook.Add(name, GH.Random(), func)
end


function GH.Draw()
if ( GH.GetCConVarNum("gh_esp") == 1 ) then
for _, ply in pairs(player.GetAll()) do
if ( GH.CalculateDistance( ply ) and ply:Alive() and ply ~= GH.Ply ) then
local pos = ( ply:GetPos() + Vector(0, 0, 80) ):ToScreen()


local pos1 = ( ply:GetPos() + Vector(0, 0, 60) ):ToScreen()


if !IsValid(ply:GetActiveWeapon()) then return end


surface.SetTextColor(255, 255, 0, 200)
surface.SetFont("ChatFont")


local width, height = surface.GetTextSize(ply:Nick())


surface.SetTextPos(pos.x - height / 2, pos.y)


surface.DrawText( ply:Nick() .. " | Health: " .. tostring( ply:Health() ) )


surface.SetTextPos(pos1.x, pos1.y)
surface.DrawText(ply:GetActiveWeapon():GetClass())
end
end
end


if ( GH.GetCConVarNum("gh_espents") == 1 ) then
for _, ent in pairs(ents.GetAll()) do
if ( GH.CalculateDistance( ent ) and GH.GetValidEnt( ent ) ) then
local pos = ent:GetPos():ToScreen()


surface.SetTextPos(pos.x, pos.y)
surface.SetFont("ChatFont")
surface.SetDrawColor(255, 255, 0, 200)
surface.DrawText(ent:GetClass())
end
end
end


if ( GH.GetCConVarNum("gh_chams") == 1 ) then
for _, ply in pairs(player.GetAll()) do
if ( GH.CalculateDistance( ply ) and ply:Alive() ) then
cam.Start3D(GH.Ply:EyePos(), GH.Ply:EyeAngles())
render.SuppressEngineLighting(true)


ply:DrawModel()


if IsValid(ply:GetActiveWeapon()) then ply:GetActiveWeapon():DrawModel() end


render.SuppressEngineLighting(false)
cam.End3D()
end
end
end


if ( GH.GetCConVarNum("gh_entchams") == 1 ) then
for _, ent in pairs(ents.GetAll()) do
if ( GH.CalculateDistance( ent ) and GH.GetValidEnt( ent ) ) then
cam.Start3D(GH.Ply:EyePos(), GH.Ply:EyeAngles())
render.SuppressEngineLighting(true)


ent:DrawModel()


render.SuppressEngineLighting(false)
cam.End3D()
end
end
end
end


function GH.Escape()
RunConsoleCommand("say", "/sleep")


timer.Simple(0.5, function()
RunConsoleCommand("say", "/wakeup")
end)
end


function GH.Speed()
if ( GH.GetCConVarNum("gh_speed") == 1 ) then
require("cvar3")




GH.GetCConVar("sv_cheats"):SetValue(1)
GH.GetCConVar("host_timescale"):SetValue(10)
end
end




function GH.OffSpeed()
if ( GH.GetCConVarNum("gh_speed") == 1 ) then
require("cvar3")




GH.GetCConVar("sv_cheats"):SetValue(0)
GH.GetCConVar("host_timescale"):SetValue(1)
end
end


function GH.Menu()
local frame = vgui.Create("DPanel")
frame:SetSize(175, 115)
frame:Center()
frame:MakePopup()
frame.Paint = function()
surface.SetDrawColor(0, 0, 0, 190)
surface.DrawRect(0, 0, frame:GetWide(), frame:GetTall())




surface.SetDrawColor(0, 0, 0, 225)
surface.DrawRect(0, 0, frame:GetWide(), 25)




surface.SetTextColor(255, 255, 255, 255)
surface.SetTextPos(5, 2)
surface.SetFont("ChatFont")
surface.DrawText("[GH] Menu")
end


local close = vgui.Create("DImageButton", frame)
close:SetPos(frame:GetWide() - 18, 2)
close:SetSize(16, 16)
close:SetImage("icon16/cross.png")
close.DoClick = function()
frame:Remove()
end




local holder = vgui.Create("DPanelList", frame)
holder:SetPos(5, 30)
holder:SetSize(165, 80)
holder:EnableHorizontal(false)
holder:EnableVerticalScrollbar(true)


local esp = vgui.Create("DCheckBoxLabel")
esp:SetText("ESP")
esp:SetConVar("gh_esp")
holder:AddItem(esp)


local espents = vgui.Create("DCheckBoxLabel")
espents:SetText("Entity Finder")
espents:SetConVar("gh_espents")
holder:AddItem(espents)


local chams = vgui.Create("DCheckBoxLabel")
chams:SetText("Player Chams")
chams:SetConVar("gh_chams")
holder:AddItem(chams)


local espchams = vgui.Create("DCheckBoxLabel")
espchams:SetText("Entity Chams")
espchams:SetConVar("gh_entchams")
holder:AddItem(espchams)


local speed = vgui.Create("DCheckBoxLabel")
speed:SetText("SpeedHack")
speed:SetConVar("gh_speed")
holder:AddItem(speed)
end


function GH.RunHooks()
GH.AddHook("HUDPaint", GH.Draw)
end


function GH.Prepare()
GH.CreateCConVar("gh_esp")
GH.CreateCConVar("gh_espents")
GH.CreateCConVar("gh_chams")
GH.CreateCConVar("gh_entchams")
GH.CreateCConVar("gh_speed")


GH.CreateChangeAble("gh_distance", "1000")


GH.CreateConCommand("gh_getadmins", GH.GetAdmins)
GH.CreateConCommand("gh_escape", GH.Escape)
GH.CreateConCommand("+gh_speed", GH.Speed)
GH.CreateConCommand("-gh_speed", GH.OffSpeed)
GH.CreateConCommand("gh_menu", GH.Menu)
end


function GH.Init()
print("Initializing...")
print("Adding Hooks...")
GH.RunHooks()
print("Preparing...")
GH.Prepare()
print("Initialized.")


print("You're using version 1.0")
print("Make sure to check if admins are online (gh_getadmins).")
end


GH.Init()