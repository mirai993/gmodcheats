-- Note by paradox: This was a hack developed by Karson (or Karsonatorz) who was running the
-- only large propkill server in ~2019 - ~2023. It shutdown but the Discord server still exists
-- although it is also completely dead.

local function update() return end 
    
    surface.CreateFont( "karson", {
        size = "Trebuchet",
        weight = 44,
        blursize = 0,
        scanlines = 0,
        antialias = true,
        underline = false,
        italic = false,
        strikeout = false,
        symbol = false,
        rotary = false,
        shadow = true,
        additive = false,
        outline = false,
    } )
    
    surface.CreateFont( "karson2", {
        font = "Arial",
        size = 15,
        weight = 500,
        blursize = 0,
        scanlines = 0,
        antialias = true,
        underline = true,
        italic = false,
        strikeout = false,
        symbol = false,
        rotary = false,
        shadow = true,
        additive = false,
        outline = false,
    } )
    
    surface.CreateFont( "fucksake", {
        font = "Helvetica",
        size = 15,
        weight = 10,
        blursize = 0,
        scanlines = 0,
        antialias = false,
        underline = false,
        italic = false,
        strikeout = false,
        symbol = false,
        rotary = false,
        shadow = false,
        additive = false,
        outline = true,
    } )
    
    CreateClientConVar( "karson_friend", 1, true, false )
    CreateClientConVar( "karson_pkesp", 0, false, true )
    CreateClientConVar( "karson_simpleesp", 0, false, true )
    CreateClientConVar( "karson_esp", 1, true, false )
    CreateClientConVar( "karson_esp_money", 0, true, false )
    CreateClientConVar( "karson_codhack", 1, true, false )
    CreateClientConVar( "karson_aimbot", 2, true, false )
    CreateClientConVar( "karson_spectators", 1, true, false )
    CreateClientConVar( "karson_skybox", 1, true, false )
    CreateClientConVar( "karson_headtrace", 1, true, false )
    CreateClientConVar( "karson_groundtrace", 1, true, false )
    CreateClientConVar( "karson_crosshair", 1, true, false )
    CreateClientConVar( "karson_propsounds", 1, true, false )
    CreateClientConVar( "karson_spotwarning", 1, true, false )
    CreateClientConVar( "karson_proptrace", 1, true, false )
    CreateClientConVar("karson_bhop", 1, true, false )
    CreateClientConVar("karson_setfov_on", 0)
    CreateClientConVar("karson_setfov", 100)
    CreateClientConVar("karson_flightwarning", 1, true, false )
    CreateClientConVar("karson_viewmodels", 1, true, false )
    CreateClientConVar ("karson_xray", 1, true, false)
    CreateClientConVar("karson_ping", 1, true, false)
    CreateClientConVar("karson_ping_amount", 200)
    CreateClientConVar("karson_playerlines", 1)
    CreateClientConVar("karson_proplines", 1)
    
    
     function karson_menu()
     local buttoncolors = Color( 0, 0, 0, 255 )
     local buttonsize = 32
     frame1 = vgui.Create("DFrame")
     button1 = vgui.Create("DButton")
     frame1:SetPos(0, 0)
     frame1:SetSize(90,930)
     frame1:SetTitle("HAKES")
     frame1:SetVisible( true )
     frame1:MakePopup()
     frame1:ShowCloseButton( false ) 
     function frame1:Paint( w, h )
        draw.RoundedBox( 8, 0, 0, w, h, Color( 0, 0, 0, 0 ) )
    end
     button1:SetParent( frame1 )
     button1:SetText( "ESP" )
     button1:SetPos(0, 30)
     button1:SetSize(90,90)
      function button1:Paint( w, h )
        draw.RoundedBox( buttonsize, 0, 0, w, h, buttoncolors )
    end
     button1.DoClick = function()
     local menu = DermaMenu()
     menu:AddOption("on", function() RunConsoleCommand("karson_esp", "1") end )
     menu:AddOption("off", function() RunConsoleCommand("karson_esp", "0") end)
     menu:Open()
     end
     button2 = vgui.Create("DButton")
     button2:SetParent( frame1 )
     button2:SetText( "PK ESP" )
     button2:SetPos(0, 120)
     button2:SetSize(90,90)
      function button2:Paint( w, h )
        draw.RoundedBox( buttonsize, 0, 0, w, h, buttoncolors )
    end
     button2.DoClick = function()
     local menu = DermaMenu()
     menu:AddOption("on", function() RunConsoleCommand("karson_pkesp", "1") end )
     menu:AddOption("off", function() RunConsoleCommand("karson_pkesp", "0") end)
     menu:Open()
     end
      button3 = vgui.Create("DButton")
     button3:SetParent( frame1 )
     button3:SetText( "SIMPLE ESP" )
     button3:SetPos(0, 210)
     button3:SetSize(90,90)
     function button3:Paint( w, h )
        draw.RoundedBox( buttonsize, 0, 0, w, h, buttoncolors )
    end
     button3.DoClick = function()
     local menu = DermaMenu()
     menu:AddOption("on", function() RunConsoleCommand("karson_simpleesp", "1") end )
     menu:AddOption("off", function() RunConsoleCommand("karson_simpleesp", "0") end)
     menu:Open()
     end
      button4 = vgui.Create("DButton")
     button4:SetParent( frame1 )
     button4:SetText( "Aimbotz" )
     button4:SetPos(0, 300)
     button4:SetSize(90,90)
     function button4:Paint( w, h )
        draw.RoundedBox( buttonsize, 0, 0, w, h, buttoncolors )
    end
     button4.DoClick = function()
     local menu = DermaMenu()
     menu:AddOption("Player", function() RunConsoleCommand("karson_aimbot", "1") end )
     menu:AddOption("HeadSmash", function() RunConsoleCommand("karson_aimbot", "2") end)
     menu:AddOption("off", function() RunConsoleCommand("karson_aimbot", "0") end)
     menu:Open()
     end
      button5 = vgui.Create("DButton")
     button5:SetParent( frame1 )
     button5:SetText( "Show Spectators" )
     button5:SetPos(0, 390)
     button5:SetSize(90,90)
     function button5:Paint( w, h )
        draw.RoundedBox( buttonsize, 0, 0, w, h, buttoncolors )
    end
     button5.DoClick = function()
     local menu = DermaMenu()
     menu:AddOption("on", function() RunConsoleCommand("karson_spectators", "1") end )
     menu:AddOption("off", function() RunConsoleCommand("karson_spectators", "0") end)
     menu:Open()
     end
       button6 = vgui.Create("DButton")
     button6:SetParent( frame1 )
     button6:SetText( "Tracers" )
     button6:SetPos(0, 480)
     button6:SetSize(90,90)
     function button6:Paint( w, h )
        draw.RoundedBox( buttonsize, 0, 0, w, h, buttoncolors )
    end
     button6.DoClick = function()
     local menu = DermaMenu()
     menu:AddOption("Headtracers-on", function() RunConsoleCommand("karson_headtrace", "1") end )
     menu:AddOption("Headtracers-off", function() RunConsoleCommand("karson_headtrace", "0") end)
      menu:AddOption("Groundtracers-on", function() RunConsoleCommand("karson_groundtrace", "1") end)
       menu:AddOption("Groundtracers-off", function() RunConsoleCommand("karson_groundtrace", "0") end)
        menu:AddOption("Eyetracers-on", function() chat.AddText(Color(255, 0, 0), "not finished yet") end)
         menu:AddOption("Eyetracers-off", function() chat.AddText(Color(255, 0, 0), "not finished yet") end)
     menu:Open()
     end
       button7 = vgui.Create("DButton")
     button7:SetParent( frame1 )
     button7:SetText( "Black Skybox" )
     button7:SetPos(0, 570)
     button7:SetSize(90,90)
     function button7:Paint( w, h )
        draw.RoundedBox( buttonsize, 0, 0, w, h, buttoncolors )
    end
     button7.DoClick = function()
     local menu = DermaMenu()
     menu:AddOption("on", function() RunConsoleCommand("karson_skybox", "1") end )
     menu:AddOption("off", function() RunConsoleCommand("karson_skybox", "0") end)
     menu:Open()
     end
       button8 = vgui.Create("DButton")
     button8:SetParent( frame1 )
     button8:SetText( "Crosshair" )
     button8:SetPos(0, 660)
     button8:SetSize(90,90)
     function button8:Paint( w, h )
        draw.RoundedBox( buttonsize, 0, 0, w, h, buttoncolors )
    end
     button8.DoClick = function()
     local menu = DermaMenu()
     menu:AddOption("on", function() RunConsoleCommand("karson_crosshair", "1") end )
     menu:AddOption("off", function() RunConsoleCommand("karson_crosshair", "0") end)
     menu:Open()
     end
       button9 = vgui.Create("DButton")
     button9:SetParent( frame1 )
     button9:SetText( "Prop Sounds" )
     button9:SetPos(0, 750)
     button9:SetSize(90,90)
     function button9:Paint( w, h )
        draw.RoundedBox( buttonsize, 0, 0, w, h, buttoncolors )
    end
     button9.DoClick = function()
     local menu = DermaMenu()
     menu:AddOption("on", function() RunConsoleCommand("karson_propsounds", "1") end )
     menu:AddOption("off", function() RunConsoleCommand("karson_propsounds", "0") end)
     menu:Open()
     end
       button10 = vgui.Create("DButton")
     button10:SetParent( frame1 )
     button10:SetText( "Spot Warning" )
     button10:SetPos(0, 840)
     button10:SetSize(90,90)
     function button10:Paint( w, h )
        draw.RoundedBox( buttonsize, 0, 0, w, h, buttoncolors )
    end
     button10.DoClick = function()
     local menu = DermaMenu()
     menu:AddOption("on", function() RunConsoleCommand("karson_spotwarning", "1") end )
     menu:AddOption("off", function() RunConsoleCommand("karson_spotwarning", "0") end)
     menu:Open()
     end
     end
     concommand.Add("+karson_menu", karson_menu )
     
     concommand.Add("-karson_menu",function()
            frame1:SetVisible(false)
    end)
    
        local function karson_simpleesp()
         
         if GetConVarNumber( "karson_simpleesp" ) == 1 then
         
                for k,v in pairs ( player.GetAll() ) do
         
                        local Position = ( v:EyePos():ToScreen())
                        local Name = v:Name()
                        local health = v:Health()
                        local weapon = v:GetActiveWeapon()
                        local class = ""
                        if weapon and weapon:IsValid() then
                        class = weapon:GetClass()
                        end
                        local typing = v:IsTyping()
                        local showtype = ""
                        if typing then showtype = "Typing..." end
                        
                        if v == LocalPlayer() then continue end
                        draw.DrawText( showtype, "karson", Position.x, Position.y -30, Color( 0, 100, 100, 255 ), 1 )
                        draw.DrawText( Name, "karson", Position.x, Position.y, Color( 255, 200, 200, 255 ), 1 )
                        draw.DrawText("Health:" .. health, "karson", Position.x, Position.y +30, Color( 255, 0, 0, 255 ), 1 )
        end
        end
        end
                         
    hook.Add("HUDPaint", "karson_simpleesp", karson_simpleesp )
    
        local function karson_pkesp()
         
         if GetConVarNumber("karson_pkesp") == 1 then
         
                for k,v in pairs ( player.GetAll() ) do
         
                        local Position = ( v:EyePos():ToScreen())
                        local Name = v:Name()
                        local rank = v:GetUserGroup()
                        local teamcolor =  team.GetColor(v:Team())
                        local health = v:Health()
                        local typing = v:IsTyping()
                        local showtype = ""
                        if typing then showtype = "Typing..." end
                        
                        if v == LocalPlayer() then continue end
                        if v:Alive() then
                        draw.DrawText( showtype, "fucksake", Position.x, Position.y -30, Color( 0, 150, 150, 255 ), 1 )
                        draw.DrawText( Name, "fucksake", Position.x, Position.y, Color( 255, 120, 0, 255 ), 1 )
                        draw.DrawText( rank, "fucksake", Position.x, Position.y +15, Color( 255, 120, 0, 255 ), 1 ) 
                        if v:Alive() then 
                        draw.RoundedBox( 8, Position.x -4, Position.y -15, 10, 10, teamcolor )
                        end
                        if weapon and weapon.Primary then
                        draw.SimpleText( class, "karson", Position.x, Position.y +45, Color( 255, 200, 255, 255 ), 1 )
                        end
                    end
        end
        end
        end
                         
    hook.Add("HUDPaint", "karson_pkesp", karson_pkesp )
    
      
    local function karson_esp()
     if GetConVarNumber("karson_esp") == 1 then
     
             if LocalPlayer().spottargetlist and table.Count(LocalPlayer().spottargetlist) > 0 then
             draw.SimpleText( "People looking at you: " ..table.concat(LocalPlayer().spottargetlist,", "), "ChatFont", math.Round(ScrW()/2), math.Round(ScrH()/5), Color(255,50,0,255), TEXT_ALIGN_CENTER)
             end
    
                    for k,v in pairs ( player.GetAll() ) do
        
        
                        local min, max = v:GetRenderBounds()
                        local Position = ( v:EyePos():ToScreen())
                        local Name = v:Name()
                        local Health = v:Health()
                        local Ping = v:Ping()
                        local rank = v:GetUserGroup()
                        local teamcolor =  team.GetColor(v:Team())
                        local typing = v:IsTyping()
                        local showtype = ""
                        local lasereffect = Material("effects/laser1")
                        local lasereffectnoz = Material("effects/laser1_noz")
    
                        if typing then showtype = "Typing..." end
                         draw.DrawText( showtype, "karson", Position.x, Position.y -30, Color( 0, 100, 100, 255 ), 1 )
    
                                            local weapon = v:GetActiveWeapon()
                                            local class = ""
                                            local ammo = 0
                                            if weapon and weapon:IsValid() then
                                                    class = weapon:GetClass()
                                                    ammo =  weapon:Clip1()
                                            end
         
                        if v == LocalPlayer() then continue end		
                        draw.SimpleText( Name, "karson", Position.x, Position.y, Color( 255, 200, 200, 255 ), 1 )
                        draw.SimpleText("Health: [" .. Health .. "]", "karson", Position.x, Position.y +15, Color( 255, 255, 200, 255 ), 1 )
                        draw.SimpleText("Ping: " .. Ping .. "", "karson", Position.x, Position.y -15, Color( 200, 255, 200, 255 ), 1 )
                        draw.SimpleText( rank, "karson", Position.x, Position.y +30, Color( 255, 255, 255, 255 ), 1 )
                            
                                            if weapon and weapon.Primary then
                                                    draw.SimpleText( class, "karson", Position.x, Position.y +45, Color( 255, 200, 255, 255 ), 1 )
                                                    draw.SimpleText("Ammo: (" .. ammo .. ")" .. weapon.Primary.ClipSize, "karson", Position.x, Position.y +60, Color( 0, 255, 255, 255 ), 1 )
                                                    
                                          end
                                          
                                if v != LocalPlayer() then
                                if v:Alive() == true then
                                cam.Start3D(EyePos(), EyeAngles())
                                surface.SetDrawColor(teamcolor.r, teamcolor.g, teamcolor.b, 255)
                                render.SetMaterial( Material('sprites/physbeama') )
                                render.DrawBeam( v:GetShootPos(), v:GetEyeTrace().HitPos, 4, 0, 12, teamcolor)
                                
                                local Eyehit = util.QuickTrace( v:GetShootPos(), Vector(0,0,1000), v )
                                local Eyehit2 = util.QuickTrace( v:GetShootPos(), Vector(0,0,-1000), v )
                                render.SetMaterial( Material('sprites/physbeama') )
                                if v != LocalPlayer() then
                                    render.DrawBeam( v:GetShootPos(), Eyehit.HitPos, 4, 0, 12, teamcolor)
                                    render.DrawBeam( v:GetShootPos(), Eyehit2.HitPos, 4, 0, 12, teamcolor)
                                end
                                cam.End3D()
                            end
                        end
                        end
                   
                   
                           if LocalPlayer().picktarget then
                        draw.SimpleText( "Aimboating: " ..LocalPlayer().picktarget:Nick(), "karson2", math.Round(ScrW()/2)-25, math.Round(ScrH()/1.6), Color( 255, 150, 0, 255 ), TEXT_ALIGN_LEFT )
                        local aimdis = math.Round(LocalPlayer().picktarget:GetShootPos():Distance(LocalPlayer():GetEyeTrace().HitPos))
                        local pkdis = math.Round(Vector(LocalPlayer():GetEyeTrace().HitPos.x,LocalPlayer():GetEyeTrace().HitPos.y,LocalPlayer():GetEyeTrace().HitPos.z):Distance(Vector(LocalPlayer().picktarget:GetShootPos().x,LocalPlayer().picktarget:GetShootPos().y,LocalPlayer():GetEyeTrace().HitPos.z)))
                        local coldis
                        local colpk
                        if  math.abs(aimdis) < 250 then
                            // this whole bullshit is just for a pretty color effect you dont have to rack your brain over it
                            colsdis = HSVToColor(140-(math.abs(aimdis)^0.9), 1-((math.abs(aimdis)^0.9)/350), 1-((math.abs(aimdis)^0.9)/650))
                        else
                            colsdis = HSVToColor(0, 0, 0.5)
                        end
                        
                        if  math.abs(pkdis) < 250 then
                            // this whole bullshit is just for a pretty color effect you dont have to rack your brain over it
                            colpk = HSVToColor(140-(math.abs(pkdis)^0.9), 1-((math.abs(pkdis)^0.9)/350), 1-((math.abs(pkdis)^0.9)/650))
                        else
                            colpk = HSVToColor(0, 0, 0.5)
                        end
                        
                        draw.SimpleText( "Aim dist: " ..aimdis, "karson", math.Round(ScrW()/2)-25, math.Round(ScrH()/1.6)+15, colsdis, TEXT_ALIGN_LEFT)
                        draw.SimpleText( "PK dist: " ..pkdis, "karson", math.Round(ScrW()/2)-20, math.Round(ScrH()/1.6)+26, colpk, TEXT_ALIGN_LEFT)
                        end
        end
    end
    
    hook.Add( "HUDPaint", "karson_esp", karson_esp )
    
    
    local function karson_esp_money()
    for k,v in pairs ( player.GetAll() ) do
    local Position = ( v:GetPos() + Vector( 0,0,70 ) ):ToScreen()
    local money = (v.DarkRPVars and v.DarkRPVars.money)
    if GetConVarNumber( "karson_esp_money" ) == 0 then return end
    draw.DrawText("Money:" .. money, "DefaultSmall", Position.x, Position.y +75, Color( 255, 255, 255, 255 ), 1 )
    end
    end
    
    hook.Add( "HUDPaint", "karson_esp_money", karson_esp_money )
    
    
    local toggle = true
    function karson_fov()
    if toggle then
                    for k,v in pairs ( player.GetAll() ) do
                    if v != LocalPlayer() and v:Alive() then
                            local setdistfovtracer = v:GetShootPos():Distance(v:GetEyeTrace().HitPos)
                            local vangle = v:EyeAngles()
                            local vfov = v:GetFOV()
                            render.SetMaterial( Material('sprites/physbeama') )
                            local addupleft = Angle(vangle.p-(vfov/2.7),vangle.y-(vfov/2),vangle.r):Forward() * (setdistfovtracer^0.95)
                            local adddownleft = Angle(vangle.p+(vfov/2.7),vangle.y-(vfov/2),vangle.r):Forward() * (setdistfovtracer^0.95)
                            local addupright = Angle(vangle.p-(vfov/2.7),vangle.y+(vfov/2),vangle.r):Forward() * (setdistfovtracer^0.95)
                            local adddownright = Angle(vangle.p+(vfov/2.7),vangle.y+(vfov/2),vangle.r):Forward() * (setdistfovtracer^0.95)
                           
                            render.DrawBeam( v:GetShootPos(),v:GetShootPos() + addupleft,3,0,12,Color( 0, 255, 0, 255 ))
                            render.DrawBeam( v:GetShootPos(),v:GetShootPos() + adddownleft,3,0,12,Color( 0, 255, 0, 255 ))
                            render.DrawBeam( v:GetShootPos(),v:GetShootPos() + addupright,3,0,12,Color( 0, 255, 0, 255 ))
                            render.DrawBeam( v:GetShootPos(),v:GetShootPos() + adddownright,3,0,12,Color( 0, 255, 0, 255 ))
                           
                            render.DrawBeam( v:GetShootPos() + adddownleft,v:GetShootPos() + adddownright,3,0,12,Color( 0, 255, 0, 255 ))
                            render.DrawBeam( v:GetShootPos() + addupleft,v:GetShootPos() + adddownleft,3,0,12,Color( 0, 255, 0, 255 ))
                            render.DrawBeam( v:GetShootPos() + addupleft,v:GetShootPos() + addupright,3,0,12,Color( 0, 255, 0, 255 ))
                            render.DrawBeam( v:GetShootPos() + addupright,v:GetShootPos() + adddownright,3,0,12,Color( 0, 255, 0, 255 ))
    
                    end
                   
            end
        end
    end
    
     concommand.Add("karson_fov", function()
    
     if toggle then toggle = false
     elseif !toggle then toggle = true
     end
     if toggle or !toggle then 
     surface.PlaySound("buttons/combine_button3.wav");
     end
    
    end)
     
     hook.Add( "PostPlayerDraw", "karson_fov", karson_fov )
     
     local function karson_aimbot()
     if GetConVarNumber( "karson_aimbot" ) == 0 then return end
                    for k,v in pairs ( player.GetAll() ) do
                     if LocalPlayer():KeyDown(IN_WALK) then
                            if !LocalPlayer().picktarget then
                                if GetConVarNumber( "karson_aimbot" ) == 1 then
                                    local pos = v:GetShootPos() - LocalPlayer():GetShootPos()
                                    local unitPos = pos:GetNormalized()
                                    if unitPos:Dot(LocalPlayer():GetAimVector()) > 0.950 and v:Alive() then
                                            LocalPlayer().picktarget = v
                                    end
                                else
                                    for i=1, 80 do
                                        local pos = (v:GetShootPos() + Vector(0,0,i*15)) - LocalPlayer():GetShootPos()
                                        local unitPos = pos:GetNormalized()
                                        if unitPos:Dot(LocalPlayer():GetAimVector()) > 0.950 and v:Alive() then
                                                LocalPlayer().picktarget = v
                                        end
                                    end
                                end
                            else
                                 if GetConVarNumber( "karson_aimbot" ) == 1 then
                                    local eyeang = LocalPlayer():EyeAngles()
                                    local aimang = (LocalPlayer().picktarget:GetShootPos() - LocalPlayer():GetShootPos()):Angle()
                                    LocalPlayer():SetEyeAngles(aimang)
                                else
                                    local eyeang = LocalPlayer():EyeAngles()
                                    local aimang = (LocalPlayer().picktarget:GetShootPos() - LocalPlayer():GetShootPos()):Angle()
                                    LocalPlayer():SetEyeAngles(Angle(eyeang.p,aimang.y,aimang.r))
                                end
                            end
                    else
                            LocalPlayer().picktarget = nil
    
                end	
            end	
    end
    hook.Add( "Think", "karson_aimbot", karson_aimbot )	
    
     local function karson_propsounds()
            if GetConVarNumber( "karson_propsounds" ) == 0 then return end
                
                if !LocalPlayer().Resetsounds then LocalPlayer().Resetsounds = CurTime() end
                if LocalPlayer().Resetsounds < CurTime() then
                LocalPlayer().Resetsounds = CurTime() + 5
                RunConsoleCommand("stopsound")
                end
                
                for k,v in pairs ( ents.FindInSphere(LocalPlayer():GetShootPos(),2600) ) do
                    if v:GetClass() == "prop_physics" then
                        local vspeed = v:GetVelocity():Length()
    
                        if !v.propsound then
                            v.propsound = CreateSound(v, "ambient/machines/combine_shield_touch_loop1.wav")
                            v.propsound:Play()
                            v.propsound:SetSoundLevel(85)
                        else
                            v.propsound:ChangePitch(math.Clamp((vspeed/9)+25,0,255),0)
                            v.propsound:ChangeVolume(math.Clamp(vspeed/400,0,0.9)+0.1,0)
                        end
                        
                        if (v:GetPos():Distance(LocalPlayer():GetShootPos()) > 2400 or not v:IsValid()) and v.propsound then v.propsound:Stop(); v.propsound = nil end
                    end
                end	
    end
    hook.Add( "Think", "karson_propsounds", karson_propsounds )	
    
     local function karson_spotwarning()
            if GetConVarNumber( "karson_spotwarning" ) == 1 then
    
                LocalPlayer().spottargetlist = {}
                
                    for k,v in pairs ( player.GetAll() ) do
                        local midself = ((LocalPlayer():GetShootPos() + LocalPlayer():GetPos())/2)
                          local pos = midself - v:GetShootPos()
                          local unitPos = pos:GetNormalized()
                          local Eyehit = util.QuickTrace( v:GetShootPos(), v:GetAimVector(), v )
                          
                              local tr = {}
                            tr.start = v:GetShootPos()
                            tr.endpos = midself
                            tr.filter = v
                            local trace = util.TraceLine( tr )
        
                          if (unitPos:Dot(v:GetAimVector()) > 0.95 or v:GetEyeTrace().HitPos:Distance(midself) < 100) and not trace.HitWorld and v != LocalPlayer() and v:IsValid() then
                                table.insert(LocalPlayer().spottargetlist,v:Nick())
                          end
                    end	
                end
    end
    hook.Add( "Think", "karson_spotwarning", karson_spotwarning )	
    
    
     local toggle = true
     local function karson_eyetrace()
     if toggle then
                    for k,v in pairs ( player.GetAll() ) do
                    local teamcolor =  team.GetColor(v:Team())
                    render.SetMaterial( Material('sprites/physbeama') )
                    if v != LocalPlayer() then
                    if v:Alive() == true then
                            render.DrawBeam( v:GetShootPos(), v:GetEyeTrace().HitPos, 4, 0, 12, teamcolor)
    
                    end
            end
        end
    end
    end
    
     concommand.Add("karson_eyetrace", function()
    
     if toggle then toggle = false
     elseif !toggle then toggle = true
     end
      if toggle or !toggle then 
     surface.PlaySound("buttons/combine_button3.wav");
     end
    
    end)
     
     hook.Add( "PostPlayerDraw", "karson_eyetrace", karson_eyetrace )
     
     local function karson_friend()
     
     if GetConVarNumber("karson_friend") == 1 then
     for k,v in pairs ( player.GetAll() ) do
     local isfriend = v:GetFriendStatus( )
     local Position = ( v:GetPos() + Vector( 0,0,70 ) ):ToScreen()
     local teamcolor =  team.GetColor(v:Team())
     if isfriend == "friend"  then
                        surface.SetDrawColor(teamcolor)
                        surface.DrawLine( Position.x, Position.y -30, Position.x +10, Position.y -45 )
                        surface.DrawLine( Position.x, Position.y -30, Position.x -10, Position.y -45 )
                        surface.DrawLine( Position.x +0, Position.y -45, Position.x +5, Position.y -50 )
                        surface.DrawLine( Position.x -0, Position.y -45, Position.x -5, Position.y -50 )
                        ------------------------------------------------------------------------------------
                        surface.DrawLine( Position.x +10, Position.y -45, Position.x +5, Position.y -50 )
                        surface.DrawLine( Position.x -10, Position.y -45, Position.x -5, Position.y -50 )
     end
     if isfriend == "blocked" then
                                             surface.SetDrawColor(teamcolor)
                        surface.DrawLine( Position.x, Position.y -30, Position.x +10, Position.y -45 )
                        surface.DrawLine( Position.x, Position.y -30, Position.x -10, Position.y -45 )
                        surface.DrawLine( Position.x +0, Position.y -45, Position.x +5, Position.y -50 )
                        surface.DrawLine( Position.x -0, Position.y -45, Position.x -5, Position.y -50 )
                        ------------------------------------------------------------------------------------
                        surface.DrawLine( Position.x +10, Position.y -45, Position.x +5, Position.y -50 )
                        surface.DrawLine( Position.x -10, Position.y -45, Position.x -5, Position.y -50 )
                        ------------------------------------------------------------------------------------
                        surface.DrawLine( Position.x -20, Position.y -40, Position.x +20, Position.y -45 )
    end
    
    if isfriend == "none" then
    
                        draw.RoundedBox( 8, Position.x, Position.y -45, 10, 10, teamcolor ) 
    end
     end
     end
     end
     
     hook.Add("HUDPaint", "karson_friend", karson_friend )
     
     
     hook.Add("HUDPaint", "showspectators", function()
       if GetConVarNumber( "karson_spectators" ) <= 0 then return end
       local spectatePlayers = {}
       local x = 0
       for k,v in pairs(player.GetAll()) do
          if v:GetObserverTarget() == LocalPlayer() then
             table.insert(spectatePlayers, v:Name())
                            if not v.spectateNotified then
                                    chat.AddText(Color(255, 0, 0), "DANGER: " .. v:Nick() .. " is spectating you");
                                    surface.PlaySound("buttons/blip1.wav");
                                    v.spectateNotified = true
                            end
            else
                    v.spectateNotified = false
            end
       end
    
     
       for k, v in pairs(spectatePlayers) do
            draw.SimpleText(v, "default", ScrW() - 175, ScrH() - ScrH() + 35 + x, Color(255, 255, 255, 255))
            x = x + 15
     
     
     
                            end
       
       end)
    
     
    local function karson_skybox()
    if (GetConVarNumber( "karson_skybox" ) == 1)  then
    render.Clear(5, 5, 5, 255)
    return true
    else
    return false
    end
    end
    
    hook.Add("PreDrawSkyBox", "karson_skybox", karson_skybox)
    
    local function karson_crosshair()
    if GetConVarNumber( "karson_crosshair" ) == 0 then return end
    local x = ScrW() / 2
    local y = ScrH() / 2
     
    surface.SetDrawColor( 255, 255, 255, 255 )
     
    local gap = 0
    local length = gap + 10
     
    surface.DrawLine( x - length, y, x - gap, y )
    surface.DrawLine( x + length, y, x + gap, y )
    surface.DrawLine( x, y - length, x, y - gap )
    surface.DrawLine( x, y + length, x, y + gap )
    end
    hook.Add("HUDPaint", "karson_crosshair", karson_crosshair )
    
     local function karson_headtrace()
     if GetConVarNumber( "karson_headtrace" ) == 1 then
     
                    for k,v in pairs ( player.GetAll() ) do
                    local teamcolor =  team.GetColor(v:Team())
                    local Eyehit = util.QuickTrace( v:GetShootPos(), Vector(0,0,1000), v )
                    render.SetMaterial( Material('sprites/physbeama') )
                    if v != LocalPlayer() then
                    if v:Alive() then
                            render.DrawBeam( v:GetShootPos(), Eyehit.HitPos, 4, 0, 12, teamcolor)
                    end
                end
            end
        end
    end
    
    hook.Add("PostPlayerDraw", "karson_headtrace", karson_headtrace )
    
     local function karson_groundtrace()
     if GetConVarNumber( "karson_groundtrace" ) == 1 then
     
                    for k,v in pairs ( player.GetAll() ) do
                    local teamcolor =  team.GetColor(v:Team())
                    local Eyehit = util.QuickTrace( v:GetPos(), Vector(0,0,-1000), v )
                    render.SetMaterial( Material('sprites/physbeama') )
                    if v != LocalPlayer() then
                    if v:Alive() then
                            render.DrawBeam( v:GetPos(), Eyehit.HitPos, 4, 0, 12, teamcolor)
                    end
                end
            end
        end
    end
    
    hook.Add("PostPlayerDraw", "karson_groundtrace", karson_groundtrace )
    
     local function karson_proptrace()
     if GetConVarNumber( "karson_proptrace" ) == 1 then
     
                for k,v in pairs ( ents.FindInSphere(LocalPlayer():GetShootPos(),1700) ) do
                    if v:GetClass() == "prop_physics" then
                        local vspeed = v:GetVelocity():Length()
                        render.SetMaterial( Material('gui/arrow') )
                        render.DrawBeam( v:GetPos(), v:GetPos() + (v:GetVelocity()*0.7), 40, 12, 0, Color(255,0,0,255))
                    end
                end
     
        end
    end
    
    hook.Add("DrawPhysgunBeam", "karson_proptrace", karson_proptrace )
    
    function lazy180()
    
    local b = LocalPlayer():EyeAngles() LocalPlayer():SetEyeAngles(Angle(b.p,b.y-180,b.r))
        local function boost()
            local a = LocalPlayer():EyeAngles() LocalPlayer():SetEyeAngles(Angle(a.p-a.p-a.p, a.y-180, a.r))
            RunConsoleCommand("+jump")
            timer.Simple(0.2, function() RunConsoleCommand("-jump") end)
        end
        local function propSpawn()
            RunConsoleCommand("gm_spawn","models/props_combine/breenclock.mdl")
        end
    timer.Simple(0.03,propSpawn)
    timer.Simple(0.20,boost)
    end
    concommand.Add("lazy180",lazy180)
    
    
    local newfov =  GetConVarNumber("karson_setfov")
    
    local function fov(ply, ori, ang, fov, nz, fz)
        local view = {}
    
        view.origin = ori
        view.angles = ang
        view.fov = newfov
    
        return view
    end
    
    
    -- preperation
    hook.Remove("CalcView", "fov")
    timer.Simple(1, function()
    if GetConVarNumber("karson_setfov_on") == 1 then
        hook.Add("CalcView", "fov", fov)
    end
    end)
    -- end of prep
    
    cvars.AddChangeCallback("karson_setfov", function() 
        newfov = GetConVarNumber("karson_setfov")
    end)
    
    cvars.AddChangeCallback("karson_setfov_on", function() 
        if GetConVarNumber("karson_setfov_on") == 1 then
            hook.Add("CalcView", "fov", fov)
        else
            hook.Remove("CalcView", "fov")
        end
    end)
    
    function karson_bhop()
    if GetConVarNumber("karson_bhop") == 1 then
            if input.IsKeyDown(KEY_SPACE) then
                    if LocalPlayer():IsOnGround() then
                        if LocalPlayer():IsTyping() then return end
                            RunConsoleCommand("+jump")
                            timer.Create("JumpOFF",0.01,0,function()
                                    RunConsoleCommand("-jump")
                            end)
                    end
            end
        end
    end
    hook.Add("Think","karson_bhop",karson_bhop)
    
    function hello()
    for k , v in pairs ( player.GetAll()) do
    if v != LocalPlayer() then
                                if v:Alive() then
                                local teamcolor = team.GetColor(v:Team())
                                cam.Start3D(EyePos(), EyeAngles())
                                surface.SetDrawColor(teamcolor.r, teamcolor.g, teamcolor.b, 255)
                                render.SetMaterial( Material('sprites/physbeama') )
                                render.DrawBeam( v:GetShootPos(), v:GetEyeTrace().HitPos, 4, 0, 12, teamcolor)
                                
                                local Eyehit = util.QuickTrace( v:GetShootPos(), Vector(0,0,1000), v )
                                local Eyehit2 = util.QuickTrace( v:GetShootPos(), Vector(0,0,-1000), v )
                                render.SetMaterial( Material('sprites/physbeama') )
                                if v != LocalPlayer() then
                                if v:Alive() then
                                    render.DrawBeam( v:GetShootPos(), Eyehit.HitPos, 4, 0, 12, teamcolor)
                                    render.DrawBeam( v:GetShootPos(), Eyehit2.HitPos, 4, 0, 12, teamcolor)
                                end
                                end
                                cam.End3D()
                            end
                        end
                        end
                        end
                        
    hook.Add("HUDPaint", "hello", hello )
    
    local function karson_codhack()
        for k , v in pairs( player.GetAll() ) do
            if GetConVarNumber("karson_codhack") == 1 then
            local getpos = v:GetPos()
            local pos1 = (getpos + Vector( 15, 15, 72)):ToScreen()
            local pos2 = (getpos + Vector( 15, -15, 72)):ToScreen()
            local pos3 = (getpos + Vector( -15, -15, 72)):ToScreen()
            local pos4 = (getpos + Vector( -15, 15, 72)):ToScreen()
            local pos5 = (getpos + Vector( 15, 15, 0)):ToScreen()
            local pos6 = (getpos + Vector( 15, -15, 0)):ToScreen()
            local pos7 = (getpos + Vector( -15, -15, 0)):ToScreen()
            local pos8 = (getpos + Vector( -15, 15, 0)):ToScreen()
            local teamcolor = team.GetColor(v:Team())
            local function drawthelines() 
            surface.SetDrawColor(teamcolor)
            surface.DrawLine( pos1.x, pos1.y, pos2.x, pos2.y )
            surface.DrawLine( pos2.x, pos2.y, pos3.x, pos3.y )
            surface.DrawLine( pos3.x, pos3.y, pos4.x, pos4.y )
            surface.DrawLine( pos4.x, pos4.y, pos1.x, pos1.y )
            ---
            surface.DrawLine( pos1.x, pos1.y, pos5.x, pos5.y )
            surface.DrawLine( pos2.x, pos2.y, pos6.x, pos6.y )
            surface.DrawLine( pos3.x, pos3.y, pos7.x, pos7.y )
            surface.DrawLine( pos4.x, pos4.y, pos8.x, pos8.y )
            ---
            surface.SetDrawColor(255, 0, 0)
            surface.DrawLine( pos5.x, pos5.y, pos6.x, pos6.y )
            surface.DrawLine( pos6.x, pos6.y, pos7.x, pos7.y )
            surface.DrawLine( pos7.x, pos7.y, pos8.x, pos8.y )
            surface.DrawLine( pos8.x, pos8.y, pos5.x, pos5.y )
        end
        if v != LocalPlayer() and v:Alive() then
        drawthelines()
                end
        end
    end
    end
    
    hook.Add( "HUDPaint", "karson_codhack", karson_codhack )
    
    local function karson_flightwarning()
        for k, v in pairs ( player.GetAll() ) do
            if GetConVarNumber("karson_flightwarning") == 1 then 
                if LocalPlayer():IsOnGround() then
                    draw.SimpleText("ON GROUND", 'DermaLarge', ScrW() - 175, ScrH() - ScrH() + 80, Color(255, 0, 0, 255), 1, 1, 1)
                    else
                    draw.SimpleText("IN AIR", 'DermaLarge', ScrW() - 175, ScrH() - ScrH() + 80, Color(0, 255, 0, 255), 1, 1, 1)
                    end
                end
            end
        end
    
    hook.Add( "HUDPaint", "karson_flightwarning", karson_flightwarning )
    
    local function karson_viewmodels()
        for k , v in pairs ( player.GetAll() ) do
            if GetConVarNumber("karson_viewmodels") == 0 then
            v:DrawViewModel(false)
            else if
            GetConVarNumber("karson_viewmodels") == 1 then
            v:DrawViewModel(true)
            end
        end
    end
    end
    hook.Add("HUDPaint", "karson_viewmodels", karson_viewmodels )
    
    local function karson_xray()
        if GetConVarNumber( "karson_xray" ) == 1 then
            cam.Start3D(EyePos(), EyeAngles() )
                for k,v in pairs(ents.FindByClass("prop_physics")) do
                    local chamcol = Color(0, 255, 0, 20)
                    render.SetColorModulation(chamcol.r / 255, chamcol.g / 255, chamcol.b / 255, chamcol.a / 255)
                    render.SetBlend(chamcol.a / 2000 )
                    v:SetRenderMode(RENDERMODE_TRANSALPHA)
                    v:SetMaterial("mat4")//CWireframe
                    v:SetColor(chamcol)
                    v:DrawModel()
                end
            cam.End3D()
        else
            for k,v in pairs(ents.FindByClass("prop_physics")) do
                v:SetMaterial(self)
                hook.Remove("karson_xray")
            end
        end
    end
    hook.Add("PostDrawOpaqueRenderables", "karson_xray", karson_xray)
    
    local function karson_ping()
    if GetConVarNumber("karson_ping") == 1 then
    for k,v in pairs( player.GetAll() ) do
    local ping = v:Ping()
    local me = LocalPlayer()
    local meping = LocalPlayer():Ping()
    local meloss = LocalPlayer():PacketLoss()
    local toomuch = GetConVarNumber("karson_ping_amount")
    if v != me then end
    if me:IsTyping() then return end
    if ping >= toomuch then RunConsoleCommand("say", "lag spike my ping is " .. meping)
    end
    end
    end
    end
    hook.Add( "Think", "karson_ping", karson_ping )
    
     local function karson_playerlines()
        if GetConVarNumber( "karson_playerlines" ) == 1 then
            for k,v in pairs ( player.GetAll() ) do
                local playerdist = v:GetPos()
                local localdist = LocalPlayer():GetPos()
                render.SetMaterial( Material('sprites/physbeama') )
                if v != LocalPlayer() and v:Alive() then
                cam.Start3D(EyePos())
                if localdist:Distance(playerdist) < 4096 and localdist:Distance(playerdist) > 3700 then
                        render.DrawBeam( v:GetPos(), LocalPlayer():GetPos(), 20, 0, 122, Color(255,0,0,255))
                end
                if localdist:Distance(playerdist) < 3700 and localdist:Distance(playerdist) > 3000 then
                        render.DrawBeam( v:GetPos(), LocalPlayer():GetPos(), 20, 0, 122, Color(255,255,0,255))
                end
                if localdist:Distance(playerdist) < 3000 and localdist:Distance(playerdist) > 2000 then
                        render.DrawBeam( v:GetPos(), LocalPlayer():GetPos(), 20, 0, 122, Color(0,255,0,255))
                end
                if localdist:Distance(playerdist) < 2000 and localdist:Distance(playerdist) > 0 then
                        render.DrawBeam( v:GetPos(), LocalPlayer():GetPos(), 20, 0, 122, Color(0,0,255,255))
                end
                    cam.End3D()
                end
            end
        end
        end
    
    hook.Add("HUDPaint", "karson_playerlines", karson_playerlines )
    
    local function karson_proplines()
            if GetConVarNumber("karson_proplines") == 1 then
    local PlayerTable = player.GetAll()
    local EntityTable = ents.FindByClass( "prop_physics" )
                    for k,v in pairs(PlayerTable) do
                            for j,i in pairs(EntityTable) do
                           
                            local playerdist = v:GetPos()
                            local localdist = i:GetPos()
                            cam.Start3D()
                                    if i:GetClass() == "prop_physics" and v != LocalPlayer() and localdist:Distance(playerdist) < 750 and input.IsMouseDown(MOUSE_FIRST) and v:Alive() then
                                                    render.SetMaterial( Material('particle/bendibeam') )
                                                    render.DrawBeam( localdist, playerdist, 40, 12, 0, Color(255,0,255,255))
                                    end
                                    cam.End3D()
                            end
                    end
            end
    end
     
     
    hook.Add("HUDPaint", "karson_proplines", karson_proplines )
    
    update()