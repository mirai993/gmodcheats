/*
	
	snixzz3 Loader (Re-designed snixzzHook loader)
	coded by 0xymoron
	
	snixzz.net/snixzz3
	
	Purpose: Automatically loads the updated .lua source from the snixzz webserver.
	
	** You do not have permission to redistribute or modify this file. **
		
*/

local snixzz = { tCopy = table.Copy }
local g = snixzz.tCopy( _G )
local r = g.debug.getregistry()
local dlat = 1465361141

-- ** DO NOT FUCKING MODIFY **
snixzz.Src = {
	
	["stable"] = "MsgN('Please Try Again')",
	["dev"] = "MsgN('Please Try Again')",
	
}

snixzz.LoadMethods = { "RunString", "RunStringEx", "CompileString" }


/*
	
	Start of backend functions
	
*/

-- Check if a module is installed
function snixzz.IsInstallled( mod )
	
	return g.file.Exists( "lua/bin/" .. mod, "GAME" )
	
end

-- Check modules
snixzz.MissingModules = false
function snixzz.GetInstalled()
	
	for k, v in g.next, snixzz.Modules do
		
		if !snixzz.IsInstallled( v ) then
			
			snixzz.MissingModules = true
			
		end
	
	end
	
end

-- General color console printing
function snixzz.Msg( Type, Str )
	
	g.MsgC( g.Color( 255, 255, 255 ), "[snixzz3] " )
	
	if Type == "f" then -- fail
	
		g.MsgC( g.Color( 0, 255, 255 ), Str .. "\n" )
		
	elseif Type == "s" then -- success
		
		g.MsgC( g.Color( 0, 255, 0 ), Str .. "\n" )
		
	elseif Type == "e" then -- error
		
		g.MsgC( g.Color( 255, 0, 0 ), Str .. "\n" )
		
	else 
		
		g.MsgC( g.Color( 255, 255, 255 ), Str .. "\n" )
		
	end
	
end

local uuid = "2A8B771B-9C98-285D-9001-88CFE5C5041F"

-- Get the actual source code
function snixzz.GetSource( build, ret )

	g.http.Fetch( 
		
		"http://snixzz.net/cheats/snixzz3/" .. build .. ".lua",
		
		function( body, len, headers, code )
			
			snixzz.Src[build] = body
			
			snixzz.Msg( "s", "Got source code.." )
			
		end,
		
		function( error )
			
			snixzz.Src[build] = nil
			
			snixzz.Msg( "f", "Failed to get source code!" )
			
		end
		
	)
	
	if ret then	return snixzz.Src[build] end
end

-- Run the source using a chosen method
function snixzz.Exec( method, build )
	
	if method == "RunString" then
			
		g.RunString( snixzz.GetSource( build, true ) )
			
	elseif method == "RunStringEx" then
			
		g.RunStringEx( snixzz.GetSource( build, true ), "[C]" )
			
	elseif method == "CompileString" then
			
		snixzz.SourceFunc = g.CompileString( snixzz.GetSource( build, true ), "[C]", false )
			
		snixzz.SourceFunc()
		
	end
	
	return snixzz.Msg( "s", "Loaded using execution method '" .. method .. "'" )
end

-- The menu that is shown upon loading
function snixzz.UserInterface()
	
	-- Frame
	snixzz.Frame = g.vgui.Create( "DFrame" )
	snixzz.Frame:SetSize( 350, 230 )
	snixzz.Frame:Center()
	snixzz.Frame:SetTitle( "" )
	snixzz.Frame:SetDraggable( true )
	snixzz.Frame:ShowCloseButton( false )
	snixzz.Frame:MakePopup()
	snixzz.Frame.Paint = function( self )

		g.Derma_DrawBackgroundBlur( self, 0 )
		
		-- Inside Top
		g.draw.RoundedBox( 0, 0, 0, self:GetWide(), self:GetTall() - 190, g.Color( 0, 233, 255, 145 ) )
		
		-- Inside Bottom
		g.draw.RoundedBox( 0, 0, self:GetTall() - 190, self:GetWide(), self:GetTall(), g.Color( 70, 70, 70, 163 ) )
		
		-- Outline
		g.surface.SetDrawColor( g.Color( 0, 0, 0 ) )
		g.surface.DrawOutlinedRect( 0, 0, self:GetWide(), self:GetTall() )
		g.surface.DrawOutlinedRect( 0, 0, self:GetWide(), self:GetTall() - 190 )
	
	end
	
	local title = g.vgui.Create( "DLabel", snixzz.Frame )
	title:SetPos( 5, 5 ) 
	title:SetFont( "DermaLarge" )
	title:SetText( "snixzz3 by 0xymoron" )
	title:SetTextColor( g.color_white )
	title:SizeToContents()
	
	-- Close Button
	snixzz.CloseM = g.vgui.Create( "DButton", snixzz.Frame )
	snixzz.CloseM:SetText( "x" )
	snixzz.CloseM:SetSize( 20, 20 )
	snixzz.CloseM:SetPos( snixzz.Frame:GetWide() - snixzz.CloseM:GetWide(), 0 )
	snixzz.CloseM:SetTextColor( g.color_white )
	snixzz.CloseM.DoClick = function()
		
		snixzz.Frame:SetVisible( false )
		
	end
	snixzz.CloseM.Paint = function( self )
		
		-- Inside
		g.draw.RoundedBox( 0, 0, 0, self:GetWide(), self:GetTall(), g.Color( 255, 0, 0, 255 ) )
		
		-- Outline
		g.surface.SetDrawColor( g.Color( 0, 0, 0 ) )
		g.surface.DrawOutlinedRect( 0, 0, self:GetWide(), self:GetTall() )
		
	end
	
	-- Website Button
	Website = g.vgui.Create( "DButton", snixzz.Frame )
	Website:SetText( "snixzz.net" )
	Website:SetSize( 65, 20 )
	Website:SetPos( snixzz.Frame:GetWide() - snixzz.CloseM:GetWide() - Website:GetWide(), 0 )
	Website:SetTextColor( g.color_white )
	Website.DoClick = function()
		
		g.gui.OpenURL( "http://www.snixzz.net" )
		
	end
	Website.Paint = function( self )
		
		-- Inside
		g.draw.RoundedBox( 0, 0, 0, self:GetWide(), self:GetTall(), g.Color( 70, 70, 70, 255 ) )
		
		-- Outline
		g.surface.SetDrawColor( g.Color( 0, 0, 0 ) )
		g.surface.DrawOutlinedRect( 0, 0, self:GetWide(), self:GetTall() )
		
	end	

	-- Module Check
	Modules = g.vgui.Create( "DButton", snixzz.Frame )
	if snixzz.MissingModules then

		Modules:SetText( "MISSING MODULE(S) CLICK HERE" )
		
	else
		
		Modules:SetText( "Ready to Load!" )
		Modules:SetEnabled( false )
		
	end
	Modules:SetFont( "Trebuchet24" )
	Modules:SetTextColor( g.color_white )
	Modules:SetSize( snixzz.Frame:GetWide() - 10, 45 )
	Modules:SetPos( 5, 45 )
	Modules.DoClick = function()
			
		g.gui.OpenURL( "http://snixzz.net/cheats/snixzz3/modules/" )
			
	end
	Modules.Paint = function( self )
			
		-- Inside
		if snixzz.MissingModules then
		
			g.draw.RoundedBox( 0, 0, 0, self:GetWide(), self:GetTall(), g.Color( 255, 0, 0, 255 ) )
			
		else
			
			g.draw.RoundedBox( 0, 0, 0, self:GetWide(), self:GetTall(), g.Color( 0, 180, 0, 255 ) )
		
		end
		
		-- Outline
		g.surface.SetDrawColor( g.Color( 0, 0, 0 ) )
		g.surface.DrawOutlinedRect( 0, 0, self:GetWide(), self:GetTall() )
		
	end
		
	
	local buildText = g.vgui.Create( "DLabel", snixzz.Frame )
	buildText:SetPos( 5, snixzz.Frame:GetTall() - 135 )
	buildText:SetFont( "Trebuchet24" )
	buildText:SetText( "Select a build to load" )
	buildText:SetTextColor( g.color_white )
	buildText:SizeToContents()	
	
	-- Build Selection
	local Build = g.vgui.Create( "DComboBox", snixzz.Frame )
	Build:SetPos( 5, snixzz.Frame:GetTall() - 110 )
	Build:SetSize( snixzz.Frame:GetWide() - 10, 20 )
	Build:SetValue( "stable" )
	Build:AddChoice( "stable" )
	Build:AddChoice( "dev" )
	Build:SetTextColor( g.color_white )
	
	Build.Paint = function() 
		
		g.surface.SetDrawColor( Color( 0, 0, 0 ) )
		g.surface.DrawOutlinedRect( 0, 0, Build:GetWide(), Build:GetTall() )
		
	end
	
	local methodText = g.vgui.Create( "DLabel", snixzz.Frame )
	methodText:SetPos( 5, snixzz.Frame:GetTall() - 85 )
	methodText:SetFont( "Trebuchet24" )
	methodText:SetText( "Select an execution method" )
	methodText:SetTextColor( g.color_white )
	methodText:SizeToContents()	
	
	-- Load method selection
	local Method = g.vgui.Create( "DComboBox", snixzz.Frame )
	Method:SetPos( 5, snixzz.Frame:GetTall() - 60 )
	Method:SetSize( snixzz.Frame:GetWide() - 10, 20 )
	Method:SetValue( "CompileString" )
	Method:SetTextColor( g.color_white )
	for k, v in g.next, snixzz.LoadMethods do
		
		Method:AddChoice( v )
		
	end
	
	Method.Paint = function() 
		
		g.surface.SetDrawColor( Color( 0, 0, 0 ) )
		g.surface.DrawOutlinedRect( 0, 0, Method:GetWide(), Method:GetTall() )
		
	end
		
	-- Load with preconfigured settings!
	local Load = g.vgui.Create( "DButton", snixzz.Frame )
	Load:SetText( "Load Selected Build" )
	Load:SetPos( 5, snixzz.Frame:GetTall() - 35 )
	Load:SetSize( snixzz.Frame:GetWide() - 10, 30 )
	Load:SetFont( "Trebuchet24" )
	Load:SetTextColor( g.color_white )
	Load.Paint = function( self )
		
		-- Inside
		g.draw.RoundedBox( 0, 0, 0, self:GetWide(), self:GetTall(), g.Color( 0, 180, 0, 255 ) )
		
		-- Outline
		g.surface.SetDrawColor( g.Color( 0, 0, 0 ) )
		g.surface.DrawOutlinedRect( 0, 0, self:GetWide(), self:GetTall() )
		
	end
	Load.DoClick = function()
		
		if g.table.HasValue( snixzz.LoadMethods, Method:GetValue() ) then
			
			if Build:GetValue() == "dev" or Build:GetValue() == "stable" then
				
				snixzz.Exec( Method:GetValue(), Build:GetValue() )
				
				snixzz.Frame:SetVisible( false )
				
			else
				
				snixzz.Msg( "e", "Invalid build type!" )
				
			end
			
		else
			
			snixzz.Msg( "e", "Invalid load method!" )
			
		end
		
	end	
	
end

/*
	
	LOAD EVERYTHING
	
*/

g.http.Fetch( "http://snixzz.net/cheats/snixzz3/modules.txt",
		
	function( body, len, headers, code )
			
		snixzz.Modules = g.util.JSONToTable( body )
			
		snixzz.Msg( "s", "Got modules list" )
			
	end,
		
	function( error )
		
		snixzz.Modules = { "failed" }
			
		snixzz.Msg( "f", "Failed to get modules list!" )
			
	end
		
)

-- precache build sources
snixzz.GetSource( "stable", false )
snixzz.GetSource( "dev", false )

-- HTTP.FETCH IS TOO SLO
g.timer.Simple( 1, function()
	
	snixzz.GetInstalled()
		
	g.timer.Simple( 0.5, function()
	
		snixzz.UserInterface()

	end )
	
end )
	