--[[
Fait par 
Jelaag et 
corpseot ( mec qui suce la bite a exon ) 
je sais meme pas comment il on fait pour autant foir� le lua ]]--

local RhetoricMenu = {}
local hooks = {}
RhetoricMenu.IsAnimating = false
RhetoricMenu.AnimationStartTime = 0
RhetoricMenu.AnimationDuration = 0.6 --a changer c pas bo
RhetoricMenu.AnimationType = "fade"
RhetoricMenu.IsClosing = false
RhetoricMenu.Frame = nil
RhetoricMenu.CurrentTab = "visuals"
RhetoricMenu.ColorPicker = nil
RhetoricMenu.ActiveColorButton = nil
RhetoricMenu.CheckboxAnimations = {}
RhetoricMenu.LastInsertState = false
--sa c grave uhq je c je suis le goat <3
vietnamHatSettings = {
    inang = 25,
    length = 15,
    color = color(255, 255, 0, 75),
    size = 1.0,
    posZ = 2.0
}
RhetoricMenu.Settings = {
func = {
    me        = LocalPlayer(),
    sw, sh    = ScrW(), ScrH(),
    mdl       = LocalPlayer():GetModel(),
    eyePos    = LocalPlayer():EyePos(),
    eyeAng    = LocalPlayer():EyeAngles(),
    weapon    = LocalPlayer():GetActiveWeapon(),
    wClass    = IsValid(LocalPlayer():GetActiveWeapon()) and LocalPlayer():GetActiveWeapon():GetClass() or "",

    spread    = {},
    comps     = {},
    cones     = {},
    impacts   = {},

    CT        = CurTime,
    RFT       = RealFrameTime,
    latency   = LocalPlayer():Ping() / 1000,
    zeroVec   = Vector(),
    Vec       = Vector,

    hTabl     = hook.GetTable(),
    hAdd      = hook.Add,
    hRem      = hook.Remove,

    toStr     = tostring,
    valid     = IsValid,
    tSimple   = timer.Simple,

    deg       = math.deg,
    cos       = math.cos,
    abs       = math.abs,
    sin       = math.sin,
    tan       = math.tan,
    acos      = math.acos,
    sqrt      = math.sqrt,
    pi        = math.pi,
    floor     = math.floor,
    rad       = math.rad,
    round     = math.Round,
    normAng   = math.NormalizeAngle,
    rand      = math.random,
    rRand     = math.Rand,
    rSeed     = math.randomseed,
    atan      = math.atan,
    clamp     = math.Clamp,

    dText     = draw.SimpleText,
    dTextOut  = draw.SimpleTextOutlined,
    dBox      = draw.RoundedBox,
    dDrawText = draw.DrawText,

    sPlay     = surface.PlaySound,
    sSetCol   = surface.SetDrawColor,
    sRect     = surface.DrawRect,
    sLine     = surface.DrawLine,
    sText     = surface.DrawText,
    sCircle   = surface.DrawCircle,
    sSetFont  = surface.SetFont,
    sSetTxtCol= surface.SetTextColor,
    sSetTxtPos= surface.SetTextPos,
    sOutline  = surface.DrawOutlinedRect,
    sTxtSize  = surface.GetTextSize,

    rSupLight = render.SuppressEngineLighting,
    rMatOver  = render.MaterialOverride,
    rModelLit = render.SetModelLighting,
    rColMod   = render.SetColorModulation,
    rDepth    = render.DepthRange,
    rBlend    = render.SetBlend,
    rColMat   = render.SetColorMaterial,
    rDrawBox  = render.DrawBox,
},
    colors = {
        chams = color(255, 255, 255, 255),
        esp_name = color(255, 255, 255, 255),
        esp_weapon = color(255, 255, 255, 255),
        crosshair = color(255, 255, 255, 255),
        skeleton = color(255, 255, 255, 255),
        health_bar = color(255, 255, 255, 255),
        distance = color(255, 255, 255, 255),
        flags = color(255, 255, 255, 255),
        belt = color(255, 255, 255, 255),
        offscreen_arrow = color(255, 255, 255, 255),
        name = color(255, 255, 255, 255),
        health = color(0, 255, 0, 255),
        weapon = color(255, 255, 0, 255),
    },
    chams = {
        enabled = false,
        type = "flat",
        color = color(255, 255, 255, 255)
    },
    esp = {
        enabled = false,
        name = {
            enabled = false,
            color = color(255, 255, 255, 255)
        },
        health = {
            enabled = false,
            color = color(0, 255, 0, 255)
        },
        weapon = {
            enabled = false,
            color = color(255, 255, 0, 255)
        },
        distance = {
            enabled = false,
            color = color(255, 255, 255, 255)
        },
        skeleton = {
            enabled = false,
            color = color(255, 255, 255, 255)
        },
        belt = {
            enabled = false,
            color = color(255, 255, 0, 255),
            offset_x = 0,
            offset_y = -50
        },
        belt_on_screen = {
            enabled = false,
            color = color(255, 255, 0, 255),
            screen_x = 100,
            screen_y = 100
        }
    },
    selection = {
        players = false,
        prop = false,
        lootable = false,
        dropped_items = false,
        deployable = false,
        objectives = false,
        misc = false
    },
    filters = {
        max_distance = 500,
        enabled = false,
        teammates = false,
        sleepers = false,
        downed = false
    },
    HVH = {
        resolver = false,
        resolver_bruteforce = false,
        multipoint = false,
        movement_fix = false,
    },
    other = {
        safe_mode = false
    },
    exploits = {
        cusercmd_override = false,
        cusercmd_restoration = false,
        fakelag = false,
        desync = false,
        fake_duck = false,
        backtrack = false
    },
    indicator = {
        enabled = false,
        position_x = 100,
        position_y = 100,
        show_desync = false,
        show_choke = false,
        show_exploits = false
    },
    radar = {
        enabled = false,
        position_x = 200,
        position_y = 200,
        size = 150,
        range = 1000,
        show_enemies = false,
        show_allies = false,
        show_grid = false
    },
    radar_colors = {
        background_color = color(20, 20, 20, 200),
        grid_color = color(50, 100, 80, 100),
        local_color = color(100, 200, 150, 255),
        player_color = color(255, 100, 100, 255),
        ally_color = color(100, 200, 255, 255)
    },

    reload_bar = {
        enabled = false,
        color = color(255, 165, 0, 255),
        position_x = 850,
        position_y = 830,
        width = 200,
        height = 16,
        show_percentage = true,
        show_time = true,
        animation_speed = 1.0
    },

    additional_chams = {
        enabled = false,
        vietnam_hat = false,
        king_von = false
    },
    
    vietnam_hat_settings = {
        color = color(255, 255, 0, 75),
        size = 1.0,h
        posZ = 2.0
    },

    options = {
        skeleton = false,
        health_bar = false,
        name = false,
        weapon = false,
        distance = false,
        flags = false,
        belt = false,
        belt_on_screen = false,
        offscreen_arrow = false,
        model = "none",
        chams = false
    },
    esp_positions = {
        name = {x = 105, y = 20},
        health = {x = 5, y = 150},
        weapon = {x = 105, y = 310},
        distance = {x = 180, y = 150},
        belt = {x = 0, y = -50}
    }
    
}
local COLORS = {
    BG_LEFT = color(30, 76, 65, 255),
    BG_RIGHT = color(16, 48, 45, 255),
    TEXT = color(255, 255, 255, 255),
    TEXT_DIM = color(200, 200, 200, 255),
    BUTTON_NORMAL = color(30, 50, 60, 180),
    BUTTON_HOVER = color(40, 65, 75, 200),               
    BUTTON_ACTIVE = color(50, 80, 90, 220),
    CHECKBOX_BG = color(20, 40, 50, 150),
    CHECKBOX_CHECKED = color(30, 76, 65, 255),
    CHECKBOX_HOVER = color(35, 55, 65, 180),
    PANEL_BG = color(0, 0, 0, 100),
  BORDER = color(30, 76, 65, 255), 
    SLIDER_BG = color(15, 25, 35, 200),
    SLIDER_FILL = color(20, 45, 25, 255),
    SLIDER_KNOB = color(255, 255, 255, 255),
    SUBCATEGORY_BG = color(16, 48, 45, 150)
}

local function Rethoric_fuckdtchooks(event, func)
    local hID = util.CRC(RhetoricMenu.Settings.func.rand(10^4) + SysTime())

    RhetoricMenu.Settings.func.hAdd(event, hID, func)
    hooks[#hooks + 1] = { event = event, id = hID }

    logMessage = string.format("[HookCreated] > Hook ajouté : %s avec ID %s", event, hID)
end

--pr plus tard
function RhetoricMenu:savesettings()
    if vietnamHatSettings then
        self.Settings.vietnam_hat_settings = {
            color = vietnamHatSettings.color,
            size = vietnamHatSettings.size,
            posZ = vietnamHatSettings.posZ
        }
    end
end

function RhetoricMenu:loadvietnamhatsettings()
    if self.Settings.vietnam_hat_settings then
        vietnamHatSettings.color = self.Settings.vietnam_hat_settings.color or color(255, 255, 0, 75)
        vietnamHatSettings.size = self.Settings.vietnam_hat_settings.size or 1.0
        vietnamHatSettings.posZ = self.Settings.vietnam_hat_settings.posZ or 2.0
    end
end
local function Rethoric_painthorizontalgradientbackground(panel, w, h)
    --couleurs a pas toucher !!!
   local colors = {
        {10, 39, 64},  -- bleu
        {16, 48, 45},  -- vert fonce
        {16, 51, 43},  -- vert
        {11, 51, 42},  -- vert moyen
        {30, 76, 65}   -- vert clair
    }
    local steps = 100
    local segmentSize = steps / (#colors - 1)
    for i = 0, steps do
        local segmentIndex = math.floor(i / segmentSize) + 1
        local nextIndex = math.min(segmentIndex + 1, #colors)
        local localAlpha = (i % segmentSize) / segmentSize
        if segmentIndex >= #colors then
            segmentIndex = #colors
            nextIndex = #colors
            localAlpha = 0
        end
        local x = (w / steps) * i
        local width = math.ceil(w / steps) + 1
        local r = lerp(localAlpha, colors[segmentIndex][1], colors[nextIndex][1])
        local g = lerp(localAlpha, colors[segmentIndex][2], colors[nextIndex][2])
        local b = lerp(localAlpha, colors[segmentIndex][3], colors[nextIndex][3])
        surface.SetDrawColor(r, g, b, 255)
        surface.DrawRect(x, 0, width, h)
    end
end

local function Rethoric_paintsubcategorybackground(panel, w, h)
    local colors = {
        {8, 32, 52},   -- bleu fonce
        {10, 36, 44},  -- bleu vert
        {12, 38, 36},  -- vert fonce
        {15, 42, 38},  -- vert moyen
        {22, 58, 48}   -- vert clair
    }
    local steps = 50
    local segmentSize = steps / (#colors - 1)
    
    for i = 0, steps do
        local segmentIndex = math.floor(i / segmentSize) + 1
        local nextIndex = math.min(segmentIndex + 1, #colors)
        local localAlpha = (i % segmentSize) / segmentSize
        if segmentIndex >= #colors then
            segmentIndex = #colors
            nextIndex = #colors
            localAlpha = 0
        end
        local x = (w / steps) * i
        local width = math.ceil(w / steps) + 1
        local r = lerp(localAlpha, colors[segmentIndex][1], colors[nextIndex][1])
        local g = lerp(localAlpha, colors[segmentIndex][2], colors[nextIndex][2])
        local b = lerp(localAlpha, colors[segmentIndex][3], colors[nextIndex][3])
        surface.SetDrawColor(r, g, b, 200)
        surface.DrawRect(x, 0, width, h)
    end
end
local function Rethoric_getcheckboxanimation(id, checked)
    if not RhetoricMenu.CheckboxAnimations[id] then
        RhetoricMenu.CheckboxAnimations[id] = {
            progress = checked and 1 or 0,
            target = checked and 1 or 0,
            last_time = SysTime()
        }
    end
    local anim = RhetoricMenu.CheckboxAnimations[id]
    local current_time = SysTime()
    local dt = current_time - anim.last_time
    anim.last_time = current_time
    anim.target = checked and 1 or 0
    local speed = 8
    anim.progress = Lerp(dt * speed, anim.progress, anim.target)
    return anim.progress
end
local function Rethoric_paintanimatedcheckbox(panel, w, h, checked, id, hovered)
    local progress = Rethoric_getcheckboxanimation(id, checked)
    local bgColor = color(
        lerp(progress, COLORS.CHECKBOX_BG.r, COLORS.CHECKBOX_CHECKED.r),
        lerp(progress, COLORS.CHECKBOX_BG.g, COLORS.CHECKBOX_CHECKED.g),
        lerp(progress, COLORS.CHECKBOX_BG.b, COLORS.CHECKBOX_CHECKED.b),
        255
    )
    if hovered and not checked then bgColor = COLORS.CHECKBOX_HOVER end
    draw.RoundedBox(3, 0, 0, w, h, bgColor)
    surface.SetDrawColor(COLORS.BORDER.r, COLORS.BORDER.g, COLORS.BORDER.b, 200)
surface.DrawOutlinedRect(0, 0, w, h)
end
local function Rethoric_paintcustomslider(panel, w, h, value, min, max, hovered)
    draw.RoundedBox(h/2, 0, h/2 - 3, w, 6, COLORS.SLIDER_BG)
    local fillWidth = (value - min) / (max - min) * w
    if fillWidth > 0 then
        draw.RoundedBox(3, 0, h/2 - 3, fillWidth, 6, COLORS.SLIDER_FILL)
    end
    local knobX = fillWidth - 8
    knobX = math.max(0, math.min(w - 16, knobX))
    local knobColor = hovered and color(255, 255, 255, 255) or color(220, 220, 220, 255)
    draw.RoundedBox(8, knobX, h/2 - 8, 16, 16, knobColor)
    surface.SetDrawColor(COLORS.BORDER.r, COLORS.BORDER.g, COLORS.BORDER.b, 150)
    surface.DrawOutlinedRect(knobX, h/2 - 8, 16, 16)
end

local function Rethoric_paintcolorbutton(panel, w, h, color, hovered)
    local safeColor = color or color(255, 255, 255, 255)
    draw.RoundedBox(4, 0, 0, w, h, safeColor)
    local borderColor = hovered and color(255, 255, 255, 200) or COLORS.BORDER
    surface.SetDrawColor(borderColor.r, borderColor.g, borderColor.b, borderColor.a)
    surface.DrawOutlinedRect(0, 0, w, h)
    if hovered then
        surface.SetDrawColor(255, 255, 255, 30)
        surface.DrawRect(0, 0, w, h)
    end
end
local function Rethoric_paintpanelgradientbackground(panel, w, h, positionX)
    local leftColor = {10, 39, 64}   -- bleu
    local rightColor = {30, 76, 65}  -- vert
    
    local menuWidth = 680 
    local relativePosition = math.max(0, math.min(1, positionX / menuWidth))
    
    local baseR = lerp(relativePosition, leftColor[1], rightColor[1])
    local baseG = lerp(relativePosition, leftColor[2], rightColor[2])
    local baseB = lerp(relativePosition, leftColor[3], rightColor[3])
    
    local colors = {
        {math.max(0, baseR - 5), math.max(0, baseG - 5), math.max(0, baseB - 5)},
        {baseR, baseG, baseB},
        {math.min(255, baseR + 5), math.min(255, baseG + 5), math.min(255, baseB + 5)}
    }
    local steps = 30
    local segmentSize = steps / (#colors - 1)
    
    for i = 0, steps do
        local segmentIndex = math.floor(i / segmentSize) + 1
        local nextIndex = math.min(segmentIndex + 1, #colors)
        local localAlpha = (i % segmentSize) / segmentSize
        if segmentIndex >= #colors then
            segmentIndex = #colors
            nextIndex = #colors
            localAlpha = 0
        end
        local x = (w / steps) * i
        local width = math.ceil(w / steps) + 1
        local r = Lerp(localAlpha, colors[segmentIndex][1], colors[nextIndex][1])
        local g = Lerp(localAlpha, colors[segmentIndex][2], colors[nextIndex][2])
        local b = Lerp(localAlpha, colors[segmentIndex][3], colors[nextIndex][3])
        surface.SetDrawColor(r, g, b, 180)
        surface.DrawRect(x, 0, width, h)
    end
end
local function Rethoric_paintbutton(panel, w, h, text, active)
    local color = active and COLORS.BUTTON_ACTIVE or (panel:IsHovered() and COLORS.BUTTON_HOVER or COLORS.BUTTON_NORMAL)
    draw.RoundedBox(4, 0, 0, w, h, color)
    if active then
        surface.SetDrawColor(0, 255, 0, 150)
        surface.DrawOutlinedRect(0, 0, w, h)
    end
    surface.SetTextColor(COLORS.TEXT.r, COLORS.TEXT.g, COLORS.TEXT.b, COLORS.TEXT.a)
    surface.SetFont("Trebuchet18")
    local tw, th = surface.GetTextSize(text)
    surface.SetTextPos(w/2 - tw/2, h/2 - th/2)
    surface.DrawText(text)
end
local function Rethoric_easeoutcubic(t)
    return 1 - math.pow(1 - t, 3)
end

function RhetoricMenu:startopenanimation()
    self.IsAnimating = true
    self.IsClosing = false
    self.AnimationStartTime = SysTime()
end

function RhetoricMenu:startcloseanimation()
    self.IsAnimating = true
    self.IsClosing = true
    self.AnimationStartTime = SysTime()
end

function RhetoricMenu:getanimationprogress()
    if not self.IsAnimating then
        return self.IsClosing and 0 or 1
    end
    
    local elapsed = SysTime() - self.AnimationStartTime
    local progress = math.min(elapsed / self.AnimationDuration, 1)
    
    if progress >= 1 then
        self.IsAnimating = false
        if self.IsClosing and IsValid(self.Frame) then
            self.Frame:SetVisible(false)
        end
        return self.IsClosing and 0 or 1
    end
    
    progress = Rethoric_easeoutcubic(progress)
    return self.IsClosing and (1 - progress) or progress
end
function RhetoricMenu:create()
    if IsValid(self.Frame) then self.Frame:Remove() end
    
    self.Frame = vgui.Create("DFrame")
    self.Frame:SetSize(700, 480)
    self.Frame:Center()
    self.Frame:SetTitle("")
    self.Frame:SetDraggable(false) 
    self.Frame:ShowCloseButton(false)
    self.Frame:SetDeleteOnClose(false)
    self.Frame:MakePopup()
    
    self.TitleBar = vgui.Create("DPanel", self.Frame)
    self.TitleBar:SetPos(20, 4)
    self.TitleBar:SetSize(660, 26)
    self.TitleBar:SetCursor("sizeall")

    self.TitleBar.Paint = function(panel, w, h)
    end
    
    local dragging = false
    local dragOffsetX, dragOffsetY = 0, 0
    
    self.TitleBar.OnMousePressed = function(panel, mouse)
        if mouse == MOUSE_LEFT then
            dragging = true
            local x, y = self.Frame:GetPos()
            local mx, my = gui.MousePos()
            dragOffsetX = mx - x
            dragOffsetY = my - y
            panel:MouseCapture(true)
        end
    end
    
    self.TitleBar.OnMouseReleased = function(panel, mouse)
        if mouse == MOUSE_LEFT then
            dragging = false
            panel:MouseCapture(false)
        end
    end
    
    self.TitleBar.Think = function(panel)
        if dragging then
            local mx, my = gui.MousePos()
            self.Frame:SetPos(mx - dragOffsetX, my - dragOffsetY)
        end
    end
    
    self.AnimationType = "modern" --choix de lannimation
    self:startopenanimation()
    
    self.Frame.Paint = function(panel, w, h)
        local progress = self:getanimationprogress()
            if progress <= 0 and self.IsClosing then
            return
        end
        local matrix = Matrix()
        
        if self.AnimationType == "slide" then
            local offsetX = lerp(progress, -w, 0)
            matrix:Translate(Vector(offsetX, 0, 0))
            
        elseif self.AnimationType == "fade" then
            
            local alpha = progress * 255
            surface.SetAlphaMultiplier(progress)
            
        elseif self.AnimationType == "scale" then
            local scale = lerp(progress, 0.3, 1)
            matrix:Scale(Vector(scale, scale, 1))
            matrix:Translate(Vector(w * (1 - scale) / 2, h * (1 - scale) / 2, 0))
            
        elseif self.AnimationType == "slide_scale" then
            local offsetY = lerp(progress, -50, 0)
            local scale = lerp(progress, 0.8, 1)
            local alpha = progress
            
            matrix:Scale(Vector(scale, scale, 1))
            matrix:Translate(Vector(w * (1 - scale) / 2, h * (1 - scale) / 2 + offsetY, 0))
            surface.SetAlphaMultiplier(alpha)
            
        elseif self.AnimationType == "bounce" then
            local scale = Lerp(progress, 0.5, 1)
            matrix:Scale(Vector(scale, scale, 1))
            matrix:Translate(Vector(w * (1 - scale) / 2, h * (1 - scale) / 2, 0))
            
        elseif self.AnimationType == "modern" then
            local easeProgress = progress * progress * (3 - 2 * progress) -- smooth
            local scale = lerp(easeProgress, 0.7, 1)
            local offsetY = lerp(easeProgress, -80, 0)
            local rotation = lerp(easeProgress, 5, 0) -- rotation
            
            matrix:Scale(Vector(scale, scale, 1))
            matrix:Rotate(Angle(0, 0, rotation))
            matrix:Translate(Vector(w * (1 - scale) / 2, h * (1 - scale) / 2 + offsetY, 0))
            surface.SetAlphaMultiplier(easeProgress)
            
        elseif self.AnimationType == "elastic" then
            local elasticProgress = progress
            if progress > 0.5 then
                elasticProgress = 1 - math.pow(2, -10 * (progress - 0.5)) * math.sin((progress - 0.5) * 10 * math.pi) / 2
            else
                elasticProgress = math.pow(2, 10 * (progress - 1)) * math.sin((progress - 1) * 10 * math.pi) / 2 + 1
            end
            
            local scale = lerp(elasticProgress, 0.3, 1)
            local offsetY = lerp(elasticProgress, -100, 0)
            
            matrix:Scale(Vector(scale, scale, 1))
            matrix:Translate(Vector(w * (1 - scale) / 2, h * (1 - scale) / 2 + offsetY, 0))
            surface.SetAlphaMultiplier(progress)
        end

        cam.PushModelMatrix(matrix)
    
        PaintHorizontalGradientBackground(panel, w, h)
        draw.RoundedBox(8, 0, 0, w, h, color(0, 0, 0, 0))
 
        surface.SetTextColor(COLORS.TEXT.r, COLORS.TEXT.g, COLORS.TEXT.b, COLORS.TEXT.a)
        surface.SetFont("Trebuchet18")
        local titleText = "Rethoric9.uhq Roblox 〔sexternal〕"
        local tw, th = surface.GetTextSize(titleText)
        
        local rectWidth = 660
        local rectHeight = th + 8
        local rectX = 20
        local rectY = 4
        
        PaintSubcategoryBackground({GetWide = function() return rectWidth end, GetTall = function() return rectHeight end}, rectWidth, rectHeight)
 
        surface.SetDrawColor(COLORS.BORDER.r, COLORS.BORDER.g, COLORS.BORDER.b, 200)
        surface.DrawOutlinedRect(0, 0, w, h)
 
        surface.SetTextPos(w/2 - tw/2, 8)
        surface.DrawText(titleText)
  
        cam.PopModelMatrix()

        surface.SetAlphaMultiplier(1)
    end
    self.ContentPanel = vgui.Create("DPanel", self.Frame)
    self.ContentPanel:SetPos(10, 35)
    self.ContentPanel:SetSize(680, 400)
    self.ContentPanel.Paint = function() end
    
    -- pk tu regarde lache sa
    local easterEggBtn = vgui.Create("DButton", self.Frame)
    easterEggBtn:SetPos(660, 5)
    easterEggBtn:SetSize(30, 25)
    easterEggBtn:SetText("")
    easterEggBtn:SetCursor("hand")
    easterEggBtn.Paint = function(panel, w, h)
    end
    easterEggBtn.DoClick = function()
        sound.PlayURL("https://media.vocaroo.com/mp3/172PrdOwTgDK", "noplay", function(station)
            if isvalid(station) then
                station:SetVolume(1)
                station:Play()
            end
        end)
    end
    self:createtabbuttons()
    self:LoadTabContent("visuals")
    self:loadvietnamhatsettings() -- Charger les paramètres du chapeau vietnamien
    self.Frame.OnMousePressed = function(panel, mouse)
        self:closecolorpicker()
    end
end
function RhetoricMenu:toggle()
    if isvalid(self.Frame) and self.Frame:IsVisible() and not self.IsAnimating then
        self:startcloseanimation()
    else
        if not isvalid(self.Frame) then
            self:create()
        else
            self.Frame:SetVisible(true)
            self:startopenanimation()
        end
    end
end
function RhetoricMenu:setanimationtype(type)
    self.AnimationType = type
end

function RhetoricMenu:cycleanimationtype()
    local types = {"modern", "elastic", "bounce", "scale", "slide_scale", "fade", "slide"}
    local currentIndex = 1
    for i, animType in ipairs(types) do
        if self.AnimationType == animType then
            currentIndex = i
            break
        end
    end
    local nextIndex = (currentIndex % #types) + 1
    self.AnimationType = types[nextIndex]
    print("Animation changée vers: " .. self.AnimationType)
end
function RhetoricMenu:createtabbuttons()
    local tabs = {"aimbot", "visuals", "misc", "environment"}
    local totalWidth = 700 
    local buttonHeight = 30
    local startX = 0
    local startY = 450
    local tabContainer = vgui.Create("DPanel", self.Frame)
    tabContainer:SetPos(startX, startY)
    tabContainer:SetSize(totalWidth, buttonHeight)
    tabContainer.Paint = function(panel, w, h)
        PaintSubcategoryBackground(panel, w, h)
        surface.SetDrawColor(COLORS.BORDER.r, COLORS.BORDER.g, COLORS.BORDER.b, 200)
surface.DrawOutlinedRect(0, 0, w, h)
    end
    local buttonWidth = totalWidth / #tabs
    for i, tab in ipairs(tabs) do
        local btn = vgui.Create("DButton", tabContainer)
        btn:SetPos((i-1) * buttonWidth, 0)
        btn:SetSize(buttonWidth, buttonHeight)
        btn:SetText("")
        btn.Paint = function(panel, w, h)
            local textColor = self.CurrentTab == tab and color(255, 255, 255, 255) or color(200, 200, 200, 255)
            surface.SetTextColor(textColor.r, textColor.g, textColor.b, textColor.a)
           surface.SetFont("Trebuchet18")
            local text = tab:upper()
            local tw, th = surface.GetTextSize(text)
            surface.SetTextPos(w/2 - tw/2, h/2 - th/2)
            surface.DrawText(text)
        end
        btn.DoClick = function()
            self.CurrentTab = tab
            self:LoadTabContent(tab)
            self:closecolorpicker()
        end
    end
end
--tab environement
function RhetoricMenu:createenvironmenttab()
    local label = vgui.Create("DLabel", self.ContentPanel)
    label:SetPos(280, 180)
    label:SetSize(200, 50)
    label:SetText("ENVIRONMENT - Coming Soon")
    label:SetTextColor(COLORS.TEXT)
    label:SetFont("DebugOverlay")
end
function RhetoricMenu:loadtabcontent(tab)
    self.ContentPanel:Clear()
    self:closecolorpicker()
    if tab == "visuals" then
        self:createvisualstab()
    elseif tab == "aimbot" then
        self:rethoricbot()
    elseif tab == "misc" then
        self:createmisctab()
    elseif tab == "environment" then
        self:createenvironmenttab()
    end
end
function RhetoricMenu:createoptionwithcolor(parent, x, y, optionKey, colorKey, label)
    -- label gauche
    local optionLabel = vgui.Create("DLabel", parent)
    optionLabel:SetPos(x, y)
    optionLabel:SetSize(100, 20)
    optionLabel:SetText(label)
    optionLabel:SetTextColor(COLORS.TEXT)
    optionLabel:SetCursor("hand")
    if colorKey then
        local colorBtn = vgui.Create("DButton", parent)
        colorBtn:SetPos(x + 105, y - 1)
        colorBtn:SetSize(30, 20)
        colorBtn:SetText("")
        colorBtn.Paint = function(panel, w, h)
            Rethoric_paintcolorbutton(panel, w, h, self.Settings.colors[colorKey], panel:IsHovered())
        end
        colorBtn.DoClick = function()
            self:opencolorpicker(colorBtn, colorKey)
        end
    end
    local checkPanel = vgui.Create("DPanel", parent)
    checkPanel:SetPos(x + 175, y)
    checkPanel:SetSize(18, 18)
    checkPanel:SetCursor("hand")
    local checkId = "option_" .. optionKey
    local isChecked = self.Settings.options[optionKey]
    checkPanel.Paint = function(panel, w, h)
        Rethoric_paintanimatedcheckbox(panel, w, h, isChecked, checkId, panel:IsHovered())
    end
    checkPanel.OnMousePressed = function(panel, mouse)
        if mouse == MOUSE_LEFT then
            isChecked = not isChecked
            self.Settings.options[optionKey] = isChecked
        end
    end
    optionLabel.OnMousePressed = function(panel, mouse)
        if mouse == MOUSE_LEFT then checkPanel:OnMousePressed(mouse) end
    end
end
function RhetoricMenu:createcolorbutton(parent, x, y, colorKey, label)
    local colorBtn = vgui.Create("DButton", parent)
    colorBtn:SetPos(x, y)
    colorBtn:SetSize(30, 20)
    colorBtn:SetText("")
    colorBtn.Paint = function(panel, w, h)
        Rethoric_paintcolorbutton(panel, w, h, self.Settings.colors[colorKey], panel:IsHovered())
    end
    colorBtn.DoClick = function()
        self:opencolorpicker(colorBtn, colorKey)
    end
    local colorLabel = vgui.Create("DLabel", parent)
    colorLabel:SetPos(x + 35, y)
    colorLabel:SetSize(120, 20)
    colorLabel:SetText(label)
    colorLabel:SetTextColor(COLORS.TEXT)
    return colorBtn
end
function RhetoricMenu:createcoloroption(parent, x, y, w, label, colorKey)
    local optionLabel = vgui.Create("DLabel", parent)
    optionLabel:SetPos(x, y)
    optionLabel:SetSize(w - 40, 20)
    optionLabel:SetText(label)
    optionLabel:SetTextColor(COLORS.TEXT)

    local colorBtn = vgui.Create("DButton", parent)
    colorBtn:SetPos(x + w - 35, y)
    colorBtn:SetSize(30, 20)
    colorBtn:SetText("")
    colorBtn.Paint = function(panel, w, h)
        Rethoric_paintcolorbutton(panel, w, h, self.Settings.colors[colorKey], panel:IsHovered())
    end
    colorBtn.DoClick = function()
        self:opencolorpicker(colorBtn, colorKey)
    end
    
    return colorBtn
end
function RhetoricMenu:createtoggleoption(parent, x, y, w, label)
    local optionKey = label:gsub(" ", "_")
    
    --label option
    local optionLabel = vgui.Create("DLabel", parent)
    optionLabel:SetPos(x, y)
    optionLabel:SetSize(w - 25, 20)
    optionLabel:SetText(label)
    optionLabel:SetTextColor(COLORS.TEXT)
    
    -- checkbox toggle
    local checkPanel = vgui.Create("DPanel", parent)
    checkPanel:SetPos(x + w - 20, y)
    checkPanel:SetSize(18, 18)
    checkPanel:SetCursor("hand")
    
    local checkId = "option_" .. optionKey
    local isChecked = self.Settings.options[optionKey] or false
    
    checkPanel.Paint = function(panel, w, h)
        Rethoric_paintanimatedcheckbox(panel, w, h, isChecked, checkId, panel:IsHovered())
    end
    
    checkPanel.OnMousePressed = function(panel, mouse)
        if mouse == MOUSE_LEFT then
            isChecked = not isChecked
            self.Settings.options[optionKey] = isChecked
        end
    end
    
    optionLabel.OnMousePressed = function(panel, mouse)
        if mouse == MOUSE_LEFT then 
            checkPanel:OnMousePressed(mouse) 
        end
    end
    
    return checkPanel
end
function RhetoricMenu:createcustomslider(parent, x, y, w, label, min, max, value, callback)
    local sliderLabel = vgui.Create("DLabel", parent)
    sliderLabel:SetPos(x, y)
    sliderLabel:SetSize(w, 20)
    sliderLabel:SetText(label .. ": " .. math.floor(value))
    sliderLabel:SetTextColor(COLORS.TEXT)
    
    local sliderPanel = vgui.Create("DPanel", parent)
    sliderPanel:SetPos(x, y + 22)
    sliderPanel:SetSize(w, 20)
    sliderPanel:SetCursor("hand")
    local currentValue = value
    sliderPanel.Paint = function(panel, w, h)
        Rethoric_paintcustomslider(panel, w, h, currentValue, min, max, panel:IsHovered())
    end
    sliderPanel.OnMousePressed = function(panel, mouse)
        if mouse == MOUSE_LEFT then
            panel.Dragging = true
            panel:MouseCapture(true)
        end
    end
    sliderPanel.OnMouseReleased = function(panel, mouse)
        if mouse == MOUSE_LEFT then
            panel.Dragging = false
            panel:MouseCapture(false)
        end
    end
    sliderPanel.Think = function(panel)
        if panel.Dragging then
            local x, _ = panel:CursorPos()
            local percent = math.Clamp(x / panel:GetWide(), 0, 1)
            currentValue = min + (max - min) * percent
            sliderLabel:SetText(label .. ": " .. math.floor(currentValue))
            if callback then callback(currentValue) end
        end
    end
    return sliderPanel
end
function RhetoricMenu:opencolorpicker(button, colorKey, category)
    self:CloseColorPicker()
    self.ActiveColorButton = button
    local x, y = button:LocalToScreen(0, 0)
    self.ColorPicker = vgui.Create("DFrame")
    self.ColorPicker:SetSize(280, 220)
    self.ColorPicker:SetPos(x - 50, y - 230)
    self.ColorPicker:SetTitle("")
    self.ColorPicker:SetDraggable(true)
    self.ColorPicker:ShowCloseButton(true)
    self.ColorPicker:MakePopup()
    self.ColorPicker.Paint = function(panel, w, h)
        PaintHorizontalGradientBackground(panel, w, h)
        surface.SetDrawColor(0, 0, 0, 50)
        surface.DrawRect(0, 0, w, h)
        surface.SetDrawColor(COLORS.BORDER.r, COLORS.BORDER.g, COLORS.BORDER.b, 200)
        surface.DrawOutlinedRect(0, 0, w, h)
        surface.SetTextColor(COLORS.TEXT.r, COLORS.TEXT.g, COLORS.TEXT.b, COLORS.TEXT.a)
       surface.SetFont("Trebuchet18")
        local titleText = "Color Picker"
        local tw, th = surface.GetTextSize(titleText)
        surface.SetTextPos(w/2 - tw/2, 8)
        surface.DrawText(titleText)
    end
    local contentPanel = vgui.Create("DPanel", self.ColorPicker)
    contentPanel:SetPos(10, 30)
    contentPanel:SetSize(260, 180)
    contentPanel.Paint = function(panel, w, h)
        surface.SetDrawColor(0, 0, 0, 100)
        surface.DrawRect(0, 0, w, h)
        surface.SetDrawColor(COLORS.BORDER.r, COLORS.BORDER.g, COLORS.BORDER.b, 200)
surface.DrawOutlinedRect(0, 0, w, h)
    end
    local mixer = vgui.Create("DColorMixer", contentPanel)
    mixer:SetPos(5, 5)
    mixer:SetSize(250, 170)
    mixer:SetPalette(true)
    mixer:SetAlphaBar(true)
    mixer:SetWangs(true)
    
    --couleur actuelle
    local currentColor
    if category == "indicator" then
        if not self.Settings.indicator_colors then
            self.Settings.indicator_colors = {}
        end
        currentColor = self.Settings.indicator_colors[colorKey] or color(255, 255, 255)
    elseif category == "event_logger" then
        if not self.Settings.event_logger_colors then
            self.Settings.event_logger_colors = {}
        end
        currentColor = self.Settings.event_logger_colors[colorKey] or color(255, 255, 255)
    elseif category == "radar" then
        if not self.Settings.radar_colors then
            self.Settings.radar_colors = {}
        end
        currentColor = self.Settings.radar_colors[colorKey] or color(255, 255, 255)
    elseif category == "additional_halos" then
        if not self.Settings.additional_halos then
            self.Settings.additional_halos = {}
        end
        currentColor = self.Settings.additional_halos[colorKey] or color(255, 255, 255)
    elseif category == "vietnam_hat" then
        currentColor = vietnamHatSettings.color or color(255, 255, 0, 75)
    elseif category == "reload_bar" then
        if not self.Settings.reload_bar then
            self.Settings.reload_bar = {}
        end
        currentColor = self.Settings.reload_bar[colorKey] or color(255, 165, 0, 255)
    else
        currentColor = self.Settings.colors[colorKey]
    end
    
    mixer:SetColor(currentColor)
    mixer.ValueChanged = function(panel, color)
        if category == "indicator" then
            if not self.Settings.indicator_colors then
                self.Settings.indicator_colors = {}
            end
            self.Settings.indicator_colors[colorKey] = color
        elseif category == "event_logger" then
            if not self.Settings.event_logger_colors then
                self.Settings.event_logger_colors = {}
            end
            self.Settings.event_logger_colors[colorKey] = color
            self:savesettings()
        elseif category == "radar" then
            if not self.Settings.radar_colors then
                self.Settings.radar_colors = {}
            end
            self.Settings.radar_colors[colorKey] = color
            self:savesettings()
        elseif category == "additional_halos" then
            if not self.Settings.additional_halos then
                self.Settings.additional_halos = {}
            end
            self.Settings.additional_halos[colorKey] = color
            self:savesettings()
        elseif category == "vietnam_hat" then
            vietnamHatSettings.color = color
            self:savesettings()
        elseif category == "reload_bar" then
            if not self.Settings.reload_bar then
                self.Settings.reload_bar = {}
            end
            self.Settings.reload_bar[colorKey] = color
            self:savesettings()
        else
            self.Settings.colors[colorKey] = color
        end
    end
    self.ColorPicker.OnFocusChanged = function(panel, gained)
        if not gained then
            timer.Simple(0.1, function()
                if isvalid(self.ColorPicker) then
                    self:closecolorpicker()
                end
            end)
        end
    end
end
function RhetoricMenu:closecolorpicker()
    if isvalid(self.ColorPicker) then
        self.ColorPicker:Remove()
        self.ColorPicker = nil
        self.ActiveColorButton = nil
    end
end
function RhetoricMenu:LoadTabContent(tab)
    self.ContentPanel:Clear()
    self:CloseColorPicker()
    if tab == "visuals" then
        self:createvisualstab()
    elseif tab == "aimbot" then
        self:rethoricBot()

    elseif tab == "misc" then
        self:createmisctab()
    end
end
<<<<<<< HEAD
--fonctions cheats
local function Rethoric_drawreloadbar()
    if not RhetoricMenu.Settings.reload_bar or not RhetoricMenu.Settings.reload_bar.enabled then return end
    
    local ply = LocalPlayer()
    if not isvalid(ply) then return end
    
    local weapon = ply:GetActiveWeapon()
    if not isvalid(weapon) then return end
    
    local nextPrimaryFire = weapon:GetNextPrimaryFire()
    local currentTime = CurTime()
    
    if nextPrimaryFire <= currentTime then return end
    
    local reloadDuration = nextPrimaryFire - currentTime
    local maxReloadTime = 3.0
    
    if weapon.GetReloadTime then
        maxReloadTime = weapon:GetReloadTime() or maxReloadTime
    elseif weapon.Primary and weapon.Primary.Recoil then
        maxReloadTime = weapon.Primary.Recoil * 0.1 or maxReloadTime
    end
    
    local progress = math.max(0, math.min(1, 1 - (reloadDuration / maxReloadTime)))
    
    local settings = RhetoricMenu.Settings.reload_bar
    local barX = settings.position_x or 100
    local barY = settings.position_y or 100
    local barWidth = settings.width or 200
    local barHeight = settings.height or 16
    local barColor = settings.color or color(255, 165, 0, 255)
    
    local bgColor = color(15, 15, 15, 220)
    surface.SetDrawColor(bgColor.r, bgColor.g, bgColor.b, bgColor.a)
    surface.DrawRect(barX - 2, barY - 2, barWidth + 4, barHeight + 4)
    
    local gradientSteps = 30
    local fillWidth = barWidth * progress
    for i = 0, gradientSteps do
        local x = (fillWidth / gradientSteps) * i
        local width = math.ceil(fillWidth / gradientSteps) + 1
        local alpha = 0.3 + 0.7 * (i / gradientSteps)
        local r = lerp(alpha, math.max(30, barColor.r - 100), barColor.r)
        local g = lerp(alpha, math.max(30, barColor.g - 100), barColor.g)
        local b = lerp(alpha, math.max(30, barColor.b - 100), barColor.b)
        if x < fillWidth then
            surface.SetDrawColor(r, g, b, 255)
            surface.DrawRect(barX + x, barY, width, barHeight)
        end
    end
    
    surface.SetDrawColor(30, 76, 65, 200)
    surface.DrawOutlinedRect(barX, barY, barWidth, barHeight)
    
    if settings.show_percentage then
        surface.SetTextColor(255, 255, 255, 255)
        surface.SetFont("Trebuchet18")
        local progressText = math.floor(progress * 100) .. "%"
        local ptw, pth = surface.GetTextSize(progressText)
        surface.SetTextPos(barX + barWidth/2 - ptw/2, barY + barHeight + 5)
        surface.DrawText(progressText)
    end
end

hook.Add("HUDPaint", "Rethoric_reloadbar", Rethoric_drawreloadbar)

hook.Add("HUDPaint", "Rethoric_ese", function()
    --esp joueurs et joueuse j'aime les femmes
=======

local function Rethoric_rhetoricvis() 
>>>>>>> eb66d6ea2d38bd6a20267bf1321174d5668631bf
    for _, ply in ipairs(player.GetAll()) do
        if isvalid(ply) and ply:Alive() and ply != localplayer() then
            local posTop = ply:GetPos() + Vector(0, 0, 72)
            local posBottom = ply:GetPos()
            local screenTop = posTop:ToScreen()
            local screenBottom = posBottom:ToScreen()

            if screenTop.visible and screenBottom.visible then
                surface.SetFont("Trebuchet18")
                local color = RhetoricMenu.Settings.colors.name
                
                local boxWidth = 80 
                local boxHeight = math.abs(screenBottom.y - screenTop.y) --hauteur joueur
                boxHeight = math.max(boxHeight, 100) --hauteur min
                local centerX = (screenTop.x + screenBottom.x) / 2
                local centerY = (screenTop.y + screenBottom.y) / 2
                
                local espBox = {
                    left = centerX - boxWidth / 2,
                    right = centerX + boxWidth / 2,
                    top = screenTop.y,
                    bottom = screenBottom.y,
                    centerX = centerX,
                    centerY = centerY,
                    width = boxWidth,
                    height = boxHeight
                }

                if RhetoricMenu.Settings.esp.name and RhetoricMenu.Settings.esp.name.enabled then
                    local name = (ply.getDarkRPVar and ply:getDarkRPVar("rpname")) or ply:Nick()
                    local _, textHeight = surface.GetTextSize(name)
                    
                    local namePos = RhetoricMenu.Settings.esp_positions and RhetoricMenu.Settings.esp_positions.name
                    local finalX, finalY = espBox.centerX, espBox.top - textHeight - 5
                    
                    if namePos then
                        local modelWidth, modelHeight = 170, 250
                        local relativeX = (namePos.x / modelWidth) - 0.5 
                        local relativeY = namePos.y / modelHeight
                        
                        finalX = espBox.centerX + (relativeX * espBox.width)
                        finalY = espBox.top + (relativeY * espBox.height)
                    end
                    
                    
                    local color = RhetoricMenu.Settings.esp.name.color or color(255, 255, 255)
                    draw.SimpleTextOutlined(
                        name,
                        "Trebuchet18",
                        finalX,
                        finalY,
                        color(color.r, color.g, color.b, 255),
                        TEXT_ALIGN_CENTER,
                        TEXT_ALIGN_CENTER,
                        2,
                        color(0,0,0)
                    )
                    
                end

                if RhetoricMenu.Settings.esp.weapon and RhetoricMenu.Settings.esp.weapon.enabled then
                    local wep = ply:GetActiveWeapon()
                    if isvalid(wep) then
                        local weaponName = wep:GetPrintName() or wep:GetClass()
                        local _, textHeight = surface.GetTextSize(weaponName)
                        local color = RhetoricMenu.Settings.esp.weapon.color or color(255, 255, 0)
                        
                        local weaponPos = RhetoricMenu.Settings.esp_positions and RhetoricMenu.Settings.esp_positions.weapon
                        local finalX, finalY = espBox.centerX, espBox.bottom + 5
                        
                        if weaponPos then
                            local modelWidth, modelHeight = 170, 250
                            local relativeX = (weaponPos.x / modelWidth) - 0.5 -- -0.5 a 0.5
                            local relativeY = weaponPos.y / modelHeight -- 0 a 1
                            
                            finalX = espBox.centerX + (relativeX * espBox.width)
                            finalY = espBox.top + (relativeY * espBox.height)
                        end
                        
                        
                        draw.SimpleTextOutlined(
                            weaponName,
                            "Trebuchet18",
                            finalX,
                            finalY,
                            color(color.r, color.g, color.b, 255),
                            TEXT_ALIGN_CENTER,
                            TEXT_ALIGN_CENTER,
                            2,
                            color(0,0,0)
                        )
                    end
                end
                
                if RhetoricMenu.Settings.esp.health and RhetoricMenu.Settings.esp.health.enabled then
                    local health = ply:Health()
                    local maxHealth = ply:GetMaxHealth()
                    local healthPercent = math.Clamp(health / maxHealth, 0, 1)
                    
                    local healthPos = RhetoricMenu.Settings.esp_positions and RhetoricMenu.Settings.esp_positions.health
                    local finalX, finalY = espBox.left - 30, espBox.centerY
                    
                    if healthPos then
                        local modelWidth, modelHeight = 170, 250
                        local relativeX = (healthPos.x / modelWidth) - 0.5 -- -0.5 a 0.5
                        local relativeY = healthPos.y / modelHeight -- 0 a 1
                        
                        finalX = espBox.centerX + (relativeX * espBox.width)
                        finalY = espBox.top + (relativeY * espBox.height)
                    end
                                        
                    local color = RhetoricMenu.Settings.esp.health.color or color(0, 255, 0)
                    draw.SimpleTextOutlined(
                        health .. " HP",
                        "Trebuchet18",
                        finalX,
                        finalY,
                        color(color.r, color.g, color.b, 255),
                        TEXT_ALIGN_CENTER,
                        TEXT_ALIGN_CENTER,
                        2,
                        color(0,0,0)
                    )
                end
                
                if RhetoricMenu.Settings.esp.distance and RhetoricMenu.Settings.esp.distance.enabled then
                    local distance = math.round(localplayer():GetPos():Distance(ply:GetPos()))
                    --pos du darg n drop
                    local distancePos = RhetoricMenu.Settings.esp_positions and RhetoricMenu.Settings.esp_positions.distance
                    local finalX, finalY = espBox.right + 30, espBox.centerY
                    
                    if distancePos then
                        --marche pas jbandonne wallah
                        local modelWidth, modelHeight = 170, 250
                        local relativeX = (distancePos.x / modelWidth) - 0.5 -- -0.5 a 0.5
                        local relativeY = distancePos.y / modelHeight -- 0 a 1
                        
                        finalX = espBox.centerX + (relativeX * espBox.width)
                        finalY = espBox.top + (relativeY * espBox.height)
                    end
                                        
                    local color = RhetoricMenu.Settings.esp.distance.color or color(255, 255, 255)
                    draw.SimpleTextOutlined(
                        distance .. "m",
                        "Trebuchet18",
                        finalX,
                        finalY,
                        color(color.r, color.g, color.b, 255),
                        TEXT_ALIGN_CENTER,
                        TEXT_ALIGN_CENTER,
                        2,
                        color(0,0,0)
                    )
                end
            end
    end
end
    
    --esp npc 
    if RhetoricMenu.Settings.esp and RhetoricMenu.Settings.esp.enabled then
        for _, npc in ipairs(ents.GetAll()) do
            if isvalid(npc) and npc:IsNPC() and npc:Health() > 0 then
                local npcClass = npc:GetClass()
                local isMetropolice = (npcClass == "npc_metropolice" or npcClass == "npc_combine_s")
                
                -- taille boite esp
                local boxMultiplier = isMetropolice and 1.5 or 1.0
                local posTop = npc:GetPos() + Vector(0, 0, 72 * boxMultiplier)
                local posBottom = npc:GetPos()
                local screenTop = posTop:ToScreen()
                local screenBottom = posBottom:ToScreen()

                if screenTop.visible and screenBottom.visible then
                    surface.SetFont("Trebuchet18")
                    
                    local boxWidth = isMetropolice and 120 or 80
                    local boxHeight = math.abs(screenBottom.y - screenTop.y)
                    boxHeight = math.max(boxHeight, isMetropolice and 150 or 100)
                    local centerX = (screenTop.x + screenBottom.x) / 2
                    local centerY = (screenTop.y + screenBottom.y) / 2
                    
                    local espBox = {
                        left = centerX - boxWidth / 2,
                        right = centerX + boxWidth / 2,
                        top = screenTop.y,
                        bottom = screenBottom.y,
                        centerX = centerX,
                        centerY = centerY,
                        width = boxWidth,
                        height = boxHeight
                    }

                    if RhetoricMenu.Settings.esp.name and RhetoricMenu.Settings.esp.name.enabled then
                        local npcName = npcClass:gsub("npc_", ""):upper()
                        if isMetropolice then
                            npcName = "METROPOLICE"
                        end
                        local _, textHeight = surface.GetTextSize(npcName)
                        
                        local namePos = RhetoricMenu.Settings.esp_positions and RhetoricMenu.Settings.esp_positions.name
                        local finalX, finalY = espBox.centerX, espBox.top - textHeight - 5
                        
                        if namePos then
                            local modelWidth, modelHeight = 170, 250
                            local relativeX = (namePos.x / modelWidth) - 0.5
                            local relativeY = namePos.y / modelHeight
                            
                            finalX = espBox.centerX + (relativeX * espBox.width)
                            finalY = espBox.top + (relativeY * espBox.height)
                        end
                        
                        local color = isMetropolice and color(255, 100, 100) or (RhetoricMenu.Settings.esp.name.color or color(255, 255, 255))
                        draw.SimpleTextOutlined(
                            npcName,
                            isMetropolice and "Trebuchet24" or "Trebuchet18",
                            finalX,
                            finalY,
                            color(color.r, color.g, color.b, 255),
                            TEXT_ALIGN_CENTER,
                            TEXT_ALIGN_CENTER,
                            2,
                            color(0,0,0)
                        )
                        
                    end

                    if RhetoricMenu.Settings.esp.health and RhetoricMenu.Settings.esp.health.enabled then
                        local health = npc:Health()
                        local maxHealth = npc:GetMaxHealth()
                        
                        local healthPos = RhetoricMenu.Settings.esp_positions and RhetoricMenu.Settings.esp_positions.health
                        local finalX, finalY = espBox.left - 30, espBox.centerY
                        
                        if healthPos then
                            local modelWidth, modelHeight = 170, 250
                            local relativeX = (healthPos.x / modelWidth) - 0.5
                            local relativeY = healthPos.y / modelHeight
                            
                            finalX = espBox.centerX + (relativeX * espBox.width)
                            finalY = espBox.top + (relativeY * espBox.height)
                        end
                                                
                        local color = isMetropolice and color(255, 150, 150) or (RhetoricMenu.Settings.esp.health.color or color(0, 255, 0))
                        draw.SimpleTextOutlined(
                            health .. " HP",
                            isMetropolice and "Trebuchet24" or "Trebuchet18",
                            finalX,
                            finalY,
                            color(color.r, color.g, color.b, 255),
                            TEXT_ALIGN_CENTER,
                            TEXT_ALIGN_CENTER,
                            2,
                            color(0,0,0)
                        )
                        

                    end
                    
                    if RhetoricMenu.Settings.esp.distance and RhetoricMenu.Settings.esp.distance.enabled then
                        local distance = math.round(localplayer():GetPos():Distance(npc:GetPos()))
                        
                        local distancePos = RhetoricMenu.Settings.esp_positions and RhetoricMenu.Settings.esp_positions.distance
                        local finalX, finalY = espBox.right + 30, espBox.centerY
                        
                        if distancePos then
                            local modelWidth, modelHeight = 170, 250
                            local relativeX = (distancePos.x / modelWidth) - 0.5
                            local relativeY = distancePos.y / modelHeight
                            
                            finalX = espBox.centerX + (relativeX * espBox.width)
                            finalY = espBox.top + (relativeY * espBox.height)
                        end
                        --sa marche pas bien jbandone wallah
                        local color = isMetropolice and color(255, 200, 100) or (RhetoricMenu.Settings.esp.distance.color or color(255, 255, 255))
                        draw.SimpleTextOutlined(
                            distance .. "m",
                            isMetropolice and "Trebuchet24" or "Trebuchet18",
                            finalX,
                            finalY,
                            color(color.r, color.g, color.b, 255),
                            TEXT_ALIGN_CENTER,
                            TEXT_ALIGN_CENTER,
                            2,
                            color(0,0,0)
                        )
                        
                    end
                    
                    if isMetropolice and RhetoricMenu.Settings.esp.box and RhetoricMenu.Settings.esp.box.enabled then
                        surface.SetDrawColor(255, 100, 100, 200)
                        surface.DrawOutlinedRect(espBox.left, espBox.top, espBox.width, espBox.height)
                        surface.SetDrawColor(255, 100, 100, 50)
                        surface.DrawOutlinedRect(espBox.left - 1, espBox.top - 1, espBox.width + 2, espBox.height + 2)
                    end
                end
            end
        end
    end
    
    --belt on screen
    if RhetoricMenu.Settings.esp.belt_on_screen and RhetoricMenu.Settings.esp.belt_on_screen.enabled then
        local localPly = localplayer()
        if isvalid(localPly) then
            --que les joueurs viser
            local eyePos = localPly:EyePos()
            local eyeAngles = localPly:EyeAngles()
            local forward = eyeAngles:Forward()
            
            local targetPlayer = nil
            local minAngle = 30
            
            for _, v in ipairs(player.GetAll()) do
                if v == localPly or not v:Alive() then continue end
                
                local targetPos = v:GetPos() + Vector(0, 0, 40)
                local dirToTarget = (targetPos - eyePos):GetNormalized()
                local dotProduct = forward:Dot(dirToTarget)
                local angle = math.deg(math.acos(math.Clamp(dotProduct, -1, 1)))
                
                if angle < minAngle then
                    minAngle = angle
                    targetPlayer = v
                end
            end
            
            if isvalid(targetPlayer) then
                local weapons = targetPlayer:GetWeapons()
                local firearmWeapons = {}
                for _, weapon in ipairs(weapons) do
                    if isvalid(weapon) then
                        local weaponClass = weapon:GetClass()
                                --whitelist
                        if not string.find(weaponClass, "physgun") and 
                           not string.find(weaponClass, "crowbar") and 
                           not string.find(weaponClass, "keys") and 
                           not string.find(weaponClass, "hands") and 
                           not string.find(weaponClass, "pocket") and
                           not string.find(weaponClass, "gmod_tool") and
                           not string.find(weaponClass, "gmod_camera") and
                           not string.find(weaponClass, "weapon_fists") then
                            table.insert(firearmWeapons, weapon)
                        end
                    end
                end
                
                if #firearmWeapons > 0 then
                    local maxWeapons = math.min(#firearmWeapons, 12)
                    local beltColor = RhetoricMenu.Settings.esp.belt_on_screen.color or color(20, 55, 50)
                    
                    local screenW, screenH = ScrW(), ScrH()
                    local weaponsPerRow = 6
                    local squareSize = 60 -- taille fixe
                    local spacing = 10
                    local totalWidth = weaponsPerRow * squareSize + (weaponsPerRow - 1) * spacing
                    local screenX = RhetoricMenu.Settings.esp.belt_on_screen.screen_x or (screenW - totalWidth) / 2 --pr changer la pos
                    local screenY = RhetoricMenu.Settings.esp.belt_on_screen.screen_y or screenH - 140
                    
                    for i = 1, maxWeapons do
                        local weapon = firearmWeapons[i]
                        if isvalid(weapon) then
                            -- position 2 lignes
                            local row = math.floor((i - 1) / weaponsPerRow)
                            local col = (i - 1) % weaponsPerRow
                            local x = screenX + col * (squareSize + spacing)
                            local y = screenY + row * (squareSize + spacing + 15)
                            
                            local colors = {
                                {10, 39, 64},  -- bleu a gauche
                                {16, 48, 45},  -- vert turquoise fonce
                                {20, 55, 50},  -- vert turquoise moyen
                                {30, 76, 65}   -- vert turquoise clair a droite
                            }
                            local steps = 20
                            local segmentSize = steps / (#colors - 1)
                            for i = 0, steps do
                                local segmentIndex = math.floor(i / segmentSize) + 1
                                local nextIndex = math.min(segmentIndex + 1, #colors)
                                local localAlpha = (i % segmentSize) / segmentSize
                                if segmentIndex >= #colors then
                                    segmentIndex = #colors
                                    nextIndex = #colors
                                    localAlpha = 0
                                end
                                local rectX = x + (squareSize / steps) * i
                                local rectWidth = math.ceil(squareSize / steps) + 1
                                local r = lerp(localAlpha, colors[segmentIndex][1], colors[nextIndex][1])
                                local g = lerp(localAlpha, colors[segmentIndex][2], colors[nextIndex][2])
                                local b = lerp(localAlpha, colors[segmentIndex][3], colors[nextIndex][3])
                                surface.SetDrawColor(r, g, b, 255)
                                surface.DrawRect(rectX, y, rectWidth, squareSize)
                            end
                            
                            --modele 3d arme
                             local weaponModel = weapon:GetModel()
                             if weaponModel and weaponModel ~= "" then
                                 -- zone rendu 3d
                                 local modelSize = squareSize - 6
                                 local modelX = x + 3
                                 local modelY = y + 3
                                 
                                 -- camera opti
                                 local viewPos = Vector(15, 15, 8)
                                 local viewAng = Angle(-10, curtime() * 20 + i * 45, 0)
                                 
                                 local adjustedModelY = modelY - 8
                                 
                                 cam.Start3D(viewPos, viewAng, 70, modelX, adjustedModelY, modelSize, modelSize)
                                 
                                 --pas opti a modifier
                                 local tempEnt = clientsidemodel(weaponModel)
                                 if isvalid(tempEnt) then
                                     tempEnt:SetPos(Vector(0, 0, 0))
                                     tempEnt:SetAngles(Angle(0, curtime() * 30 + i * 30, 0))
                                     tempEnt:SetModelScale(1.5)  -- zoom plus important
                                     
                                     render.SetLightingOrigin(Vector(0, 0, 0))
                                     render.ResetModelLighting(0.4, 0.4, 0.4)
                                     render.SetModelLighting(BOX_FRONT, 1.0, 1.0, 1.0)
                                     render.SetModelLighting(BOX_BACK, 0.3, 0.3, 0.3)
                                     render.SetModelLighting(BOX_TOP, 0.9, 0.9, 0.9)
                                     
                                     render.SetColorModulation(beltColor.r/255, beltColor.g/255, beltColor.b/255)
                                     tempEnt:DrawModel()
                                     render.SetColorModulation(1, 1, 1)
                                     
                                     tempEnt:Remove()
                                 end
                                 
                                 cam.End3D()
                            else
                                local checkerSize = 6
                                for cx = 0, squareSize - 1, checkerSize do
                                    for cy = 0, squareSize - 1, checkerSize do
                                        local checkerX = math.floor(cx / checkerSize)
                                        local checkerY = math.floor(cy / checkerSize)
                                        local drawWidth = math.min(checkerSize, squareSize - cx)
                                        local drawHeight = math.min(checkerSize, squareSize - cy)
                                        local isBlack = (checkerX + checkerY) % 2 == 0
                                        local checkerColor = isBlack and color(15, 45, 70, 255) or color(35, 80, 75, 255)
                                        surface.SetDrawColor(checkerColor.r, checkerColor.g, checkerColor.b, 255)
                                        surface.DrawRect(x + cx, y + cy, drawWidth, drawHeight)
                                    end
                                end
                            end
                            
                            local weaponName = weapon:GetClass():gsub("weapon_", ""):upper()
                            surface.SetFont("DermaDefault")
                            surface.SetTextColor(255, 255, 255, 255)
                            local tw, th = surface.GetTextSize(weaponName)
                            
                            surface.SetDrawColor(16, 48, 45, 200)
                            surface.DrawRect(x + squareSize/2 - tw/2 - 3, y + squareSize + 2, tw + 6, th + 4)
                            
                            surface.SetTextPos(x + squareSize/2 - tw/2, y + squareSize + 4)
                            surface.DrawText(weaponName)
                        end
                    end
                end
            end
        end
    end
end

<<<<<<< HEAD
--fonctions menu
function RhetoricMenu:createvisualstab()
=======
FuckDTChooks("HUDPaint", _rhetoricVIS)
-- fonctions menu
function RhetoricMenu:CreateVisualsTab()
>>>>>>> eb66d6ea2d38bd6a20267bf1321174d5668631bf
    -- panneau scrollable
    local scrollPanel = vgui.Create("DScrollPanel", self.ContentPanel)
    scrollPanel:SetPos(0, 0)
    scrollPanel:SetSize(680, 400)
    
    --scrollbar uhq
    local sbar = scrollPanel:GetVBar()
    sbar:SetHideButtons(true)
    sbar:SetWide(8)
    sbar.Paint = function(panel, w, h)
        draw.RoundedBox(4, 0, 0, w, h, color(20, 20, 20, 100))
    end
    sbar.btnGrip.Paint = function(panel, w, h)
        draw.RoundedBox(4, 0, 0, w, h, color(COLORS.BORDER.r, COLORS.BORDER.g, COLORS.BORDER.b, 200))
    end
    
    -- scroll molette uhqqqqqqqqqqqqq
    scrollPanel.OnMouseWheeled = function(panel, delta)
        local vbar = panel:GetVBar()
        if isvalid(vbar) then
            vbar:AddScroll(delta * -3)
        end
    end
    
    -- panneau targets
    local targetsPanel = vgui.Create("DPanel", scrollPanel)
    targetsPanel:SetPos(10, 10)
    targetsPanel:SetSize(200, 180)
    targetsPanel.Paint = function(panel, w, h)
        draw.RoundedBox(6, 0, 0, w, h, COLORS.PANEL_BG)
        surface.SetDrawColor(COLORS.BORDER.r, COLORS.BORDER.g, COLORS.BORDER.b, 200)
        surface.DrawOutlinedRect(0, 0, w, h)
        draw.RoundedBox(4, 5, 5, w-10, 25, color(COLORS.SUBCATEGORY_BG.r, COLORS.SUBCATEGORY_BG.g, COLORS.SUBCATEGORY_BG.b, 180))
        surface.SetDrawColor(COLORS.BORDER.r, COLORS.BORDER.g, COLORS.BORDER.b, 150)
        surface.DrawOutlinedRect(5, 5, w-10, 25)
        surface.SetTextColor(COLORS.TEXT.r, COLORS.TEXT.g, COLORS.TEXT.b, COLORS.TEXT.a)
        surface.SetFont("Trebuchet18")
        local titleText = "TARGETS & FILTERS"
        local tw, th = surface.GetTextSize(titleText)
        surface.SetTextPos(w/2 - tw/2, 12)
        surface.DrawText(titleText)
    end
    
    --targets
    local yPos = 40
    local targetItems = {"players", "props", "dropped weapons"} -- items targets
    for i, item in ipairs(targetItems) do
        local itemPanel = vgui.Create("DPanel", targetsPanel)
        itemPanel:SetPos(10, yPos)
        itemPanel:SetSize(180, 22)
        itemPanel:SetCursor("hand")
        local isSelected = self.Settings.selection[item:gsub(" ", "_")] or false
        itemPanel.Paint = function(panel, w, h)
            local bgColor = isSelected and color(30, 76, 65, 150) or color(0, 0, 0, 0)
            if panel:IsHovered() then
                bgColor = isSelected and color(40, 86, 75, 180) or color(255, 255, 255, 20)
            end
            if isSelected or panel:IsHovered() then
                draw.RoundedBox(4, 0, 0, w, h, bgColor)
            end
            local textColor = isSelected and color(255, 255, 255, 255) or color(200, 200, 200, 255)
            if panel:IsHovered() then
                textColor = color(255, 255, 255, 255)
            end
            surface.SetTextColor(textColor.r, textColor.g, textColor.b, textColor.a)
            surface.SetFont("DermaDefault")
            local tw, th = surface.GetTextSize(item)
            surface.SetTextPos(w/2 - tw/2, h/2 - th/2)
            surface.DrawText(item)
        end
        itemPanel.OnMousePressed = function(panel, mouse)
            if mouse == MOUSE_LEFT then
                isSelected = not isSelected
                self.Settings.selection[item:gsub(" ", "_")] = isSelected
            end
        end
        yPos = yPos + 25
    end
    
    --filters
    yPos = yPos + 10
    local filterItems = {"teammates", "dormant", "admin"}
    for i, item in ipairs(filterItems) do
        local itemPanel = vgui.Create("DPanel", targetsPanel)
        itemPanel:SetPos(10, yPos)
        itemPanel:SetSize(180, 22)
        itemPanel:SetCursor("hand")
        local isSelected = self.Settings.filters[item]
        itemPanel.Paint = function(panel, w, h)
            local bgColor = isSelected and color(30, 76, 65, 150) or color(0, 0, 0, 0)
            if panel:IsHovered() then
                bgColor = isSelected and color(40, 86, 75, 180) or color(255, 255, 255, 20)
            end
            if isSelected or panel:IsHovered() then
                draw.RoundedBox(4, 0, 0, w, h, bgColor)
            end
            local textColor = isSelected and color(255, 255, 255, 255) or color(200, 200, 200, 255)
            if panel:IsHovered() then
                textColor = color(255, 255, 255, 255)
            end
            surface.SetTextColor(textColor.r, textColor.g, textColor.b, textColor.a)
            surface.SetFont("DermaDefault")
            local tw, th = surface.GetTextSize(item)
            surface.SetTextPos(w/2 - tw/2, h/2 - th/2)
            surface.DrawText(item)
        end
        itemPanel.OnMousePressed = function(panel, mouse)
            if mouse == MOUSE_LEFT then
                isSelected = not isSelected
                self.Settings.filters[item] = isSelected
            end
        end
        yPos = yPos + 25
    end
    
    -- panneau chams et materials
    local chamsPanel = vgui.Create("DPanel", scrollPanel)
    chamsPanel:SetPos(10, 200)
    chamsPanel:SetSize(200, 190)
    chamsPanel.Paint = function(panel, w, h)
        draw.RoundedBox(6, 0, 0, w, h, COLORS.PANEL_BG)
        surface.SetDrawColor(COLORS.BORDER.r, COLORS.BORDER.g, COLORS.BORDER.b, 200)
        surface.DrawOutlinedRect(0, 0, w, h)
        draw.RoundedBox(4, 5, 5, w-10, 25, color(COLORS.SUBCATEGORY_BG.r, COLORS.SUBCATEGORY_BG.g, COLORS.SUBCATEGORY_BG.b, 180))
        surface.SetDrawColor(COLORS.BORDER.r, COLORS.BORDER.g, COLORS.BORDER.b, 150)
        surface.DrawOutlinedRect(5, 5, w-10, 25)
        surface.SetTextColor(COLORS.TEXT.r, COLORS.TEXT.g, COLORS.TEXT.b, COLORS.TEXT.a)
        surface.SetFont("Trebuchet18")
        local titleText = "CHAMS & MATERIALS"
        local tw, th = surface.GetTextSize(titleText)
        surface.SetTextPos(w/2 - tw/2, 12)
        surface.DrawText(titleText)
    end
    
    -- checkbox pour activer les chams
    local chamsEnabled = vgui.Create("DPanel", chamsPanel)
    chamsEnabled:SetPos(10, 40)
    chamsEnabled:SetSize(18, 18)
    chamsEnabled:SetCursor("hand")
    local isChamsEnabled = self.Settings.chams.enabled
    chamsEnabled.Paint = function(panel, w, h)
        Rethoric_paintanimatedcheckbox(panel, w, h, isChamsEnabled, "chams_enabled", panel:IsHovered())
    end
    chamsEnabled.OnMousePressed = function(panel, mouse)
        if mouse == MOUSE_LEFT then
            isChamsEnabled = not isChamsEnabled
            self.Settings.chams.enabled = isChamsEnabled
        end
    end
    
    local chamsLabel = vgui.Create("DLabel", chamsPanel)
    chamsLabel:SetPos(35, 42)
    chamsLabel:SetSize(100, 20)
    chamsLabel:SetText("enable chams")
    chamsLabel:SetTextColor(COLORS.TEXT)
    chamsLabel:SetCursor("hand")
    chamsLabel.OnMousePressed = function(panel, mouse)
        if mouse == MOUSE_LEFT then chamsEnabled:OnMousePressed(mouse) end
    end
    
    -- menu deroulant pour les types de chams
    local chamsCombo = vgui.Create("DComboBox", chamsPanel)
    chamsCombo:SetPos(10, 75)
    chamsCombo:SetSize(180, 25)
    chamsCombo:SetValue(self.Settings.chams.type or "flat")
    chamsCombo:AddChoice("flat")
    chamsCombo:AddChoice("textured")
    chamsCombo:AddChoice("wireframe")
    chamsCombo:AddChoice("Mat_1")
    chamsCombo:AddChoice("orange")
    chamsCombo:AddChoice("orange_flame")
    chamsCombo.OnSelect = function(panel, index, value)
        self.Settings.chams.type = value
        if value == "orange" then
            self.Settings.chams.color = color(255, 165, 0, 255)
        elseif value == "orange_flame" then
            self.Settings.chams.color = color(255, 100, 0, 255)
        end
    end
    chamsCombo.Paint = function(panel, w, h)
        draw.RoundedBox(4, 0, 0, w, h, Color(30, 30, 30, 150))
        surface.SetDrawColor(COLORS.BORDER.r, COLORS.BORDER.g, COLORS.BORDER.b, 200)
        surface.DrawOutlinedRect(0, 0, w, h)
    end
    
    -- couleur des chams
    local chamsColorButton = vgui.Create("DButton", chamsPanel)
    chamsColorButton:SetPos(10, 110)
    chamsColorButton:SetSize(180, 25)
    chamsColorButton:SetText("")
    chamsColorButton.Paint = function(panel, w, h)
        local bgColor = Color(30, 30, 30, 150)
        if panel:IsHovered() then
            bgColor = Color(40, 40, 40, 180)
        end
        draw.RoundedBox(4, 0, 0, w, h, bgColor)
        surface.SetDrawColor(COLORS.BORDER.r, COLORS.BORDER.g, COLORS.BORDER.b, 200)
        surface.DrawOutlinedRect(0, 0, w, h)
        
        -- carre
        local colorSquareSize = 16
        local colorSquareX = 8
        local colorSquareY = (h - colorSquareSize) / 2
        draw.RoundedBox(2, colorSquareX, colorSquareY, colorSquareSize, colorSquareSize, self.Settings.chams.color)
        surface.SetDrawColor(255, 255, 255, 100)
        surface.DrawOutlinedRect(colorSquareX, colorSquareY, colorSquareSize, colorSquareSize)
        
        -- texte
        surface.SetTextColor(COLORS.TEXT.r, COLORS.TEXT.g, COLORS.TEXT.b, COLORS.TEXT.a)
        surface.SetFont("Trebuchet18")
        local tw, th = surface.GetTextSize("chams color")
        surface.SetTextPos(colorSquareX + colorSquareSize + 8, h/2 - th/2)
        surface.DrawText("chams color")
    end
    chamsColorButton.DoClick = function()
        for _, v in pairs(vgui.GetWorldPanel():GetChildren()) do
            if v:GetName() == "RhetoricColorPicker" then
                v:Remove()
            end
        end
        
        local colorFrame = vgui.Create("DFrame")
        colorFrame:SetName("RhetoricColorPicker")
        colorFrame:SetSize(320, 280)
        colorFrame:Center()
        colorFrame:SetTitle("")
        colorFrame:SetDraggable(true)
        colorFrame:SetSizable(false)
        colorFrame:SetDeleteOnClose(true)
        colorFrame:MakePopup()
        
        colorFrame.Paint = function(panel, w, h)
            draw.RoundedBox(8, 0, 0, w, h, Color(COLORS.PANEL_BG.r, COLORS.PANEL_BG.g, COLORS.PANEL_BG.b, 240))

            surface.SetDrawColor(COLORS.BORDER.r, COLORS.BORDER.g, COLORS.BORDER.b, 200)
            surface.DrawOutlinedRect(0, 0, w, h)
 
            draw.RoundedBoxEx(6, 2, 2, w-4, 30, Color(COLORS.SUBCATEGORY_BG.r, COLORS.SUBCATEGORY_BG.g, COLORS.SUBCATEGORY_BG.b, 200), true, true, false, false)
            surface.SetDrawColor(COLORS.BORDER.r, COLORS.BORDER.g, COLORS.BORDER.b, 150)
            surface.DrawOutlinedRect(2, 2, w-4, 30)

            surface.SetTextColor(COLORS.TEXT.r, COLORS.TEXT.g, COLORS.TEXT.b, 255)
            surface.SetFont("Trebuchet18")
            local titleText = "Chams Color Picker"
            local tw, th = surface.GetTextSize(titleText)
            surface.SetTextPos(w/2 - tw/2, 10)
            surface.DrawText(titleText)
        end
        --close bouton
        local closeButton = vgui.Create("DButton", colorFrame)
        closeButton:SetPos(colorFrame:GetWide() - 25, 5)
        closeButton:SetSize(20, 20)
        closeButton:SetText("")
        closeButton.Paint = function(panel, w, h)
            local bgColor = panel:IsHovered() and Color(200, 50, 50, 200) or Color(150, 150, 150, 100)
            draw.RoundedBox(3, 0, 0, w, h, bgColor)
            surface.SetDrawColor(255, 255, 255, 255)
            surface.DrawLine(5, 5, w-5, h-5)
            surface.DrawLine(w-5, 5, 5, h-5)
        end
        closeButton.DoClick = function()
            colorFrame:Remove()
        end
        
        local colorMixer = vgui.Create("DColorMixer", colorFrame)
        colorMixer:SetPos(10, 40)
        colorMixer:SetSize(300, 190)
        colorMixer:SetColor(self.Settings.chams.color)
        colorMixer.ValueChanged = function(panel, color)
            self.Settings.chams.color = color
            self:savesettings()
        end
        
        -- bouton ok
        local okButton = vgui.Create("DButton", colorFrame)
        okButton:SetPos(colorFrame:GetWide()/2 - 40, colorFrame:GetTall() - 35)
        okButton:SetSize(80, 25)
        okButton:SetText("")
        okButton.Paint = function(panel, w, h)
            local bgColor = panel:IsHovered() and Color(COLORS.SUBCATEGORY_BG.r + 20, COLORS.SUBCATEGORY_BG.g + 20, COLORS.SUBCATEGORY_BG.b + 20, 200) or Color(COLORS.SUBCATEGORY_BG.r, COLORS.SUBCATEGORY_BG.g, COLORS.SUBCATEGORY_BG.b, 180)
            draw.RoundedBox(4, 0, 0, w, h, bgColor)
            surface.SetDrawColor(COLORS.BORDER.r, COLORS.BORDER.g, COLORS.BORDER.b, 150)
            surface.DrawOutlinedRect(0, 0, w, h)
            
            surface.SetTextColor(COLORS.TEXT.r, COLORS.TEXT.g, COLORS.TEXT.b, 255)
            surface.SetFont("Trebuchet18")
            local tw, th = surface.GetTextSize("OK")
            surface.SetTextPos(w/2 - tw/2, h/2 - th/2)
            surface.DrawText("OK")
        end
        okButton.DoClick = function()
            colorFrame:Remove()
        end
        
        --auto close 
        colorFrame.OnFocusChanged = function(panel, gained)
            if not gained then
                timer.Simple(0.1, function()
                    if IsValid(panel) and not panel:HasFocus() then
                        panel:Remove()
                    end
                end)
            end
        end
    end
    
    -- distance slider
    self:createcustomslider(chamsPanel, 10, 145, 180, "max distance", 0, 10000, self.Settings.filters.max_distance, function(val)
        self.Settings.filters.max_distance = val
    end)
    
    -- ========== PANNEAU INDICATOR ========== --
    local indicatorPanel = vgui.Create("DPanel", scrollPanel)
    indicatorPanel:SetPos(10, 400)
    indicatorPanel:SetSize(330, 450) 
    indicatorPanel.Paint = function(panel, w, h)

        PaintSubcategoryBackground(panel, w, h)
        surface.SetDrawColor(COLORS.BORDER.r, COLORS.BORDER.g, COLORS.BORDER.b, 200)
        surface.DrawOutlinedRect(0, 0, w, h)
        surface.SetDrawColor(COLORS.BORDER.r + 20, COLORS.BORDER.g + 20, COLORS.BORDER.b + 20, 100)
        surface.DrawOutlinedRect(1, 1, w-2, h-2)

        draw.RoundedBox(6, 5, 5, w-10, 30, Color(COLORS.SUBCATEGORY_BG.r + 15, COLORS.SUBCATEGORY_BG.g + 15, COLORS.SUBCATEGORY_BG.b + 15, 200))
        draw.RoundedBox(6, 6, 6, w-12, 28, Color(COLORS.SUBCATEGORY_BG.r, COLORS.SUBCATEGORY_BG.g, COLORS.SUBCATEGORY_BG.b, 180))
        surface.SetDrawColor(COLORS.BORDER.r, COLORS.BORDER.g, COLORS.BORDER.b, 150)
        surface.DrawOutlinedRect(5, 5, w-10, 30)

        surface.SetTextColor(0, 0, 0, 100)
        surface.SetFont("Trebuchet18")
        local titleText = "INDICATOR"
        local tw, th = surface.GetTextSize(titleText)
        surface.SetTextPos(w/2 - tw/2 + 1, 15)
        surface.DrawText(titleText)
        
        surface.SetTextColor(COLORS.TEXT.r, COLORS.TEXT.g, COLORS.TEXT.b, COLORS.TEXT.a)
        surface.SetTextPos(w/2 - tw/2, 14)
        surface.DrawText(titleText)
        
        
    end
    -- checkbox pour activer l'indicator
    local indicatorEnabled = vgui.Create("DPanel", indicatorPanel)
    indicatorEnabled:SetPos(10, 40)
    indicatorEnabled:SetSize(18, 18)
    indicatorEnabled:SetCursor("hand")
    local isIndicatorEnabled = self.Settings.indicator.enabled
    indicatorEnabled.Paint = function(panel, w, h)
        Rethoric_paintanimatedcheckbox(panel, w, h, isIndicatorEnabled, "indicator_enabled", panel:IsHovered())
    end
    indicatorEnabled.OnMousePressed = function(panel, mouse)
        if mouse == MOUSE_LEFT then
            isIndicatorEnabled = not isIndicatorEnabled
            self.Settings.indicator.enabled = isIndicatorEnabled
        end
    end
    
    local indicatorLabel = vgui.Create("DLabel", indicatorPanel)
    indicatorLabel:SetPos(35, 42)
    indicatorLabel:SetSize(100, 20)
    indicatorLabel:SetText("enable")
    indicatorLabel:SetTextColor(COLORS.TEXT)
    indicatorLabel:SetCursor("hand")
    indicatorLabel.OnMousePressed = function(panel, mouse)
        if mouse == MOUSE_LEFT then indicatorEnabled:OnMousePressed(mouse) end
    end
    local indicatorOptions = {
        {key = "show_desync", label = "desynculator", colorKey = "desync_color", defaultColor = Color(180, 220, 200, 255)},
        {key = "show_choke", label = "choke", colorKey = "choke_color", defaultColor = Color(200, 200, 180, 255)},
        {key = "show_exploits", label = "exploits", colorKey = "exploits_color", defaultColor = Color(160, 200, 180, 255)},
        {key = "show_fps", label = "fps counter", colorKey = "fps_color", defaultColor = Color(180, 190, 210, 255)},
        {key = "show_ping", label = "ping display", colorKey = "ping_color", defaultColor = Color(190, 180, 200, 255)},
        {key = "show_velocity", label = "velocity", colorKey = "velocity_color", defaultColor = Color(200, 190, 170, 255)}
    }
    
    local optionY = 75
    for i, option in ipairs(indicatorOptions) do
        -- checkbox
        local checkbox = vgui.Create("DPanel", indicatorPanel)
        checkbox:SetPos(15, optionY)
        checkbox:SetSize(15, 15)
        checkbox:SetCursor("hand")
        local isChecked = self.Settings.indicator[option.key] or false
        checkbox.Paint = function(panel, w, h)
            Rethoric_paintanimatedcheckbox(panel, w, h, isChecked, "indicator_" .. option.key, panel:IsHovered())
        end
        checkbox.OnMousePressed = function(panel, mouse)
            if mouse == MOUSE_LEFT then
                isChecked = not isChecked
                self.Settings.indicator[option.key] = isChecked
            end
        end
        
        --  label
        local label = vgui.Create("DLabel", indicatorPanel)
        label:SetPos(35, optionY + 2)
        label:SetSize(100, 15)
        label:SetText(option.label)
        label:SetTextColor(COLORS.TEXT)
        label:SetFont("DermaDefault")
        label:SetCursor("hand")
        label.OnMousePressed = function(panel, mouse)
            if mouse == MOUSE_LEFT then checkbox:OnMousePressed(mouse) end
        end
        
        --bouton couleur avec style amélioré
        local colorBtn = vgui.Create("DButton", indicatorPanel)
        colorBtn:SetPos(280, optionY - 2)
        colorBtn:SetSize(22, 22)
        colorBtn:SetText("")
        colorBtn:SetCursor("hand")
        colorBtn.Paint = function(panel, w, h)
            local color = (self.Settings.indicator_colors and self.Settings.indicator_colors[option.colorKey]) or option.defaultColor
            
            --effet de profondeur
            draw.RoundedBox(5, 0, 0, w, h, Color(0, 0, 0, 100))
            draw.RoundedBox(5, 1, 1, w-2, h-2, color)
            
            -- Bordure
            local borderAlpha = panel:IsHovered() and 255 or 150
            surface.SetDrawColor(255, 255, 255, borderAlpha)
            surface.DrawOutlinedRect(0, 0, w, h)
            
            if panel:IsHovered() then
                surface.SetDrawColor(255, 255, 255, 50)
                surface.DrawOutlinedRect(1, 1, w-2, h-2)
            end
        end
        colorBtn.DoClick = function()
            self:opencolorpicker(colorBtn, option.colorKey, "indicator")
        end
        
        optionY = optionY + 25
    end
    
    --parametres 
    local settingsY = 220
    
    --sliders pour position
    local currentPosX = self.Settings.indicator.position_x or 100
    self:createcustomslider(indicatorPanel, 10, settingsY, 310, "Position X", 0, ScrW(), currentPosX, function(val)
        self.Settings.indicator.position_x = val
        self:savesettings()
    end)
    settingsY = settingsY + 35
    
    local currentPosY = self.Settings.indicator.position_y or 100
    self:createcustomslider(indicatorPanel, 10, settingsY, 310, "Position Y", 0, ScrH(), currentPosY, function(val)
        self.Settings.indicator.position_y = val
         self:savesettings()
    end)
    settingsY = settingsY + 35
    
    --slider pour la taille du texte
    local currentSize = self.Settings.indicator.text_size or 16
    self:createcustomslider(indicatorPanel, 10, settingsY, 310, "Text Size", 10, 30, currentSize, function(val)
        self.Settings.indicator.text_size = val
         self:savesettings()
    end)
    settingsY = settingsY + 35
    
    --bouton pour reset couleurs
    local resetBtn = vgui.Create("DButton", indicatorPanel)
    resetBtn:SetPos(10, settingsY + 20)
    resetBtn:SetSize(310, 25)
    resetBtn:SetText("")
    resetBtn.Paint = function(panel, w, h)
        -- fond avec degrade harmonise pour le bouton reset
        local baseColor = panel:IsHovered() and {45, 25, 25} or {35, 20, 20}
        local colors = {
            {baseColor[1] + 10, baseColor[2] + 15, baseColor[3] + 20, 180},
            {baseColor[1], baseColor[2] + 10, baseColor[3] + 15, 160},
            {baseColor[1] - 5, baseColor[2] + 5, baseColor[3] + 10, 140}
        }
        
        for i = 1, #colors - 1 do
            local startColor = colors[i]
            local endColor = colors[i + 1]
            local segmentHeight = h / (#colors - 1)
            local startY = (i - 1) * segmentHeight
            
            for y = 0, segmentHeight do
                local progress = y / segmentHeight
                local r = startColor[1] + (endColor[1] - startColor[1]) * progress
                local g = startColor[2] + (endColor[2] - startColor[2]) * progress
                local b = startColor[3] + (endColor[3] - startColor[3]) * progress
                local a = startColor[4] + (endColor[4] - startColor[4]) * progress
                
                surface.SetDrawColor(r, g, b, a)
                surface.DrawRect(0, startY + y, w, 1)
            end
        end
        
        surface.SetDrawColor(COLORS.BORDER.r, COLORS.BORDER.g, COLORS.BORDER.b, 200)
        surface.DrawOutlinedRect(0, 0, w, h)
        
        surface.SetTextColor(COLORS.TEXT.r, COLORS.TEXT.g, COLORS.TEXT.b, COLORS.TEXT.a)
        surface.SetFont("Trebuchet18")
        local tw, th = surface.GetTextSize("reset colors")
        surface.SetTextPos(w/2 - tw/2, h/2 - th/2)
        surface.DrawText("reset colors")
    end
    resetBtn.DoClick = function()
        -- Reset toutes les couleurs des indicateurs
        if not self.Settings.indicator_colors then
            self.Settings.indicator_colors = {}
        end
        for _, option in ipairs(indicatorOptions) do
            self.Settings.indicator_colors[option.colorKey] = option.defaultColor
        end
        self:savesettings()
    end
    -- ========== PANNEAU EVENT LOGGER ========== --
    local eventLoggerPanel = vgui.Create("DPanel", scrollPanel)
    eventLoggerPanel:SetPos(350, 400) 
    eventLoggerPanel:SetSize(330, 450) 
    eventLoggerPanel.Paint = function(panel, w, h)
        PaintSubcategoryBackground(panel, w, h)

        surface.SetDrawColor(COLORS.BORDER.r, COLORS.BORDER.g, COLORS.BORDER.b, 200)
        surface.DrawOutlinedRect(0, 0, w, h)
        surface.SetDrawColor(COLORS.BORDER.r + 20, COLORS.BORDER.g + 20, COLORS.BORDER.b + 20, 100)
        surface.DrawOutlinedRect(1, 1, w-2, h-2)

        draw.RoundedBox(6, 5, 5, w-10, 30, Color(COLORS.SUBCATEGORY_BG.r + 15, COLORS.SUBCATEGORY_BG.g + 15, COLORS.SUBCATEGORY_BG.b + 15, 200))
        draw.RoundedBox(6, 6, 6, w-12, 28, Color(COLORS.SUBCATEGORY_BG.r, COLORS.SUBCATEGORY_BG.g, COLORS.SUBCATEGORY_BG.b, 180))
        surface.SetDrawColor(COLORS.BORDER.r, COLORS.BORDER.g, COLORS.BORDER.b, 150)
        surface.DrawOutlinedRect(5, 5, w-10, 30)
        surface.SetTextColor(0, 0, 0, 100)
        surface.SetFont("Trebuchet18")
        local titleText = "EVENT LOGGER"
        local tw, th = surface.GetTextSize(titleText)
        surface.SetTextPos(w/2 - tw/2 + 1, 15)
        surface.DrawText(titleText)
        
        surface.SetTextColor(COLORS.TEXT.r, COLORS.TEXT.g, COLORS.TEXT.b, COLORS.TEXT.a)
        surface.SetTextPos(w/2 - tw/2, 14)
        surface.DrawText(titleText)
    end
    
    -- checkbox pour activer l'event logger
    local eventLoggerEnabled = vgui.Create("DPanel", eventLoggerPanel)
    eventLoggerEnabled:SetPos(10, 40)
    eventLoggerEnabled:SetSize(18, 18)
    eventLoggerEnabled:SetCursor("hand")
    local isEventLoggerEnabled = self.Settings.event_logger and self.Settings.event_logger.enabled or false
    eventLoggerEnabled.Paint = function(panel, w, h)
        Rethoric_paintanimatedcheckbox(panel, w, h, isEventLoggerEnabled, "event_logger_enabled", panel:IsHovered())
    end
    eventLoggerEnabled.OnMousePressed = function(panel, mouse)
        if mouse == MOUSE_LEFT then
            isEventLoggerEnabled = not isEventLoggerEnabled
            self.Settings.event_logger = self.Settings.event_logger or {}
            self.Settings.event_logger.enabled = isEventLoggerEnabled
            self:savesettings()
        end
    end
    
    local eventLoggerLabel = vgui.Create("DLabel", eventLoggerPanel)
    eventLoggerLabel:SetPos(35, 42)
    eventLoggerLabel:SetSize(100, 20)
    eventLoggerLabel:SetText("enable")
    eventLoggerLabel:SetTextColor(COLORS.TEXT)
    eventLoggerLabel:SetCursor("hand")
    eventLoggerLabel.OnMousePressed = function(panel, mouse)
        if mouse == MOUSE_LEFT then eventLoggerEnabled:OnMousePressed(mouse) end
    end
    --preview pour montrer les logs
    local logPreviewZone = vgui.Create("DPanel", eventLoggerPanel)
    logPreviewZone:SetPos(10, 75)
    logPreviewZone:SetSize(310, 100)
    logPreviewZone.Paint = function(panel, w, h)
        --fond cool
        draw.RoundedBox(8, 0, 0, w, h, Color(10, 15, 20, 240))
        draw.RoundedBox(8, 2, 2, w-4, h-4, Color(15, 20, 25, 220))
        
        local colors = {
            {20, 30, 40, 200},  -- bleu fonce en haut
            {25, 35, 45, 180},  -- transition
            {30, 40, 40, 160}   -- vert fonce en bas
        }
        for i = 1, #colors - 1 do
            local startColor = colors[i]
            local endColor = colors[i + 1]
            local segmentHeight = (h-4) / (#colors - 1)
            local startY = 2 + (i - 1) * segmentHeight
            for y = 0, segmentHeight do
                local progress = y / segmentHeight
                local r = startColor[1] + (endColor[1] - startColor[1]) * progress
                local g = startColor[2] + (endColor[2] - startColor[2]) * progress
                local b = startColor[3] + (endColor[3] - startColor[3]) * progress
                local a = startColor[4] + (endColor[4] - startColor[4]) * progress
                
                surface.SetDrawColor(r, g, b, a)
                surface.DrawRect(2, startY + y, w-4, 1)
            end
        end
        surface.SetDrawColor(COLORS.BORDER.r, COLORS.BORDER.g, COLORS.BORDER.b, 200)
        surface.DrawOutlinedRect(0, 0, w, h)
        surface.SetDrawColor(COLORS.BORDER.r + 30, COLORS.BORDER.g + 30, COLORS.BORDER.b + 30, 120)
        surface.DrawOutlinedRect(1, 1, w-2, h-2)
        local yPos = 10
        surface.SetFont("DermaDefault")
        
        --pr la preview
        local damageColor = (self.Settings.event_logger_colors and self.Settings.event_logger_colors.damage_color) or Color(255, 255, 180, 255)
        surface.SetTextColor(damageColor.r, damageColor.g, damageColor.b, 255)
        surface.SetTextPos(10, yPos)
        surface.DrawText("[Damage] > You hurt Player for 25")
        yPos = yPos + 15
        local killColor = (self.Settings.event_logger_colors and self.Settings.event_logger_colors.kill_color) or Color(255, 180, 180, 255)
        surface.SetTextColor(killColor.r, killColor.g, killColor.b, 255)
        surface.SetTextPos(10, yPos)
        surface.DrawText("[Kill] > Player beamed Enemy")
        yPos = yPos + 15
        local suicideColor = (self.Settings.event_logger_colors and self.Settings.event_logger_colors.suicide_color) or Color(255, 200, 200, 255)
        surface.SetTextColor(suicideColor.r, suicideColor.g, suicideColor.b, 255)
        surface.SetTextPos(10, yPos)
        surface.DrawText("[Suicide] > Player killed themselves")
        yPos = yPos + 15
    end
    
    --pour changer les couleurs
    local logColorOptions = {
        {key = "damage_color", label = "damage logs", defaultColor = Color(255, 255, 180, 255)},
        {key = "kill_color", label = "kill logs", defaultColor = Color(255, 180, 180, 255)},
        {key = "suicide_color", label = "suicide logs", defaultColor = Color(255, 200, 200, 255)}
    }
    
    local colorY = 190
    for i, option in ipairs(logColorOptions) do
        -- label
        local label = vgui.Create("DLabel", eventLoggerPanel)
        label:SetPos(15, colorY + 2)
        label:SetSize(120, 15)
        label:SetText(option.label)
        label:SetTextColor(COLORS.TEXT)
        label:SetFont("DermaDefault")
        local colorBtn = vgui.Create("DButton", eventLoggerPanel)
        colorBtn:SetPos(280, colorY - 2)
        colorBtn:SetSize(22, 22)
        colorBtn:SetText("")
        colorBtn:SetCursor("hand")
        colorBtn.Paint = function(panel, w, h)
            local color = (self.Settings.event_logger_colors and self.Settings.event_logger_colors[option.key]) or option.defaultColor
            draw.RoundedBox(5, 0, 0, w, h, Color(0, 0, 0, 100))
            draw.RoundedBox(5, 1, 1, w-2, h-2, color)
            local borderAlpha = panel:IsHovered() and 255 or 150
            surface.SetDrawColor(255, 255, 255, borderAlpha)
            surface.DrawOutlinedRect(0, 0, w, h)
            
            if panel:IsHovered() then
                surface.SetDrawColor(255, 255, 255, 50)
                surface.DrawOutlinedRect(1, 1, w-2, h-2)
            end
        end
        colorBtn.DoClick = function()
            self:opencolorpicker(colorBtn, option.key, "event_logger")
        end

        colorY = colorY + 25
    end
    
    --pos
    local logSettingsY = 270
    
    --sliders pour position
    local currentLogPosX = self.Settings.event_logger and self.Settings.event_logger.position_x or 20
    self:createcustomslider(eventLoggerPanel, 10, logSettingsY, 310, "Position X", 0, ScrW(), currentLogPosX, function(val)
        self.Settings.event_logger = self.Settings.event_logger or {}
        self.Settings.event_logger.position_x = val
         self:savesettings()
    end)
    logSettingsY = logSettingsY + 35
    
    local currentLogPosY = self.Settings.event_logger and self.Settings.event_logger.position_y or 320
    self:createcustomslider(eventLoggerPanel, 10, logSettingsY, 310, "Position Y", 0, ScrH(), currentLogPosY, function(val)
        self.Settings.event_logger = self.Settings.event_logger or {}
        self.Settings.event_logger.position_y = val
         self:savesettings()
    end)
    logSettingsY = logSettingsY + 35
    
    -- slider pour le nombre maximum de logs
    local currentMaxLogs = self.Settings.event_logger and self.Settings.event_logger.max_logs or 15
    self:createcustomslider(eventLoggerPanel, 10, logSettingsY, 280, "Max Logs", 5, 30, currentMaxLogs, function(val)
        self.Settings.event_logger = self.Settings.event_logger or {}
        self.Settings.event_logger.max_logs = val
         self:savesettings()
    end)
    logSettingsY = logSettingsY + 35
    
    -- reset colors
    local resetLogBtn = vgui.Create("DButton", eventLoggerPanel)
    resetLogBtn:SetPos(10, logSettingsY + 20)
    resetLogBtn:SetSize(310, 25)
    resetLogBtn:SetText("")
    resetLogBtn.Paint = function(panel, w, h)
        --fond uhq
        local baseColor = panel:IsHovered() and {45, 25, 25} or {35, 20, 20}
        local colors = {
            {baseColor[1] + 10, baseColor[2] + 15, baseColor[3] + 20, 180},
            {baseColor[1], baseColor[2] + 10, baseColor[3] + 15, 160},
            {baseColor[1] - 5, baseColor[2] + 5, baseColor[3] + 10, 140}
        }
        
        for i = 1, #colors - 1 do
            local startColor = colors[i]
            local endColor = colors[i + 1]
            local segmentHeight = h / (#colors - 1)
            local startY = (i - 1) * segmentHeight
            
            for y = 0, segmentHeight do
                local progress = y / segmentHeight
                local r = startColor[1] + (endColor[1] - startColor[1]) * progress
                local g = startColor[2] + (endColor[2] - startColor[2]) * progress
                local b = startColor[3] + (endColor[3] - startColor[3]) * progress
                local a = startColor[4] + (endColor[4] - startColor[4]) * progress
                
                surface.SetDrawColor(r, g, b, a)
                surface.DrawRect(0, startY + y, w, 1)
            end
        end
        
        surface.SetDrawColor(COLORS.BORDER.r, COLORS.BORDER.g, COLORS.BORDER.b, 200)
        surface.DrawOutlinedRect(0, 0, w, h)
        
        surface.SetTextColor(COLORS.TEXT.r, COLORS.TEXT.g, COLORS.TEXT.b, COLORS.TEXT.a)
        surface.SetFont("Trebuchet18")
        local tw, th = surface.GetTextSize("reset colors")
        surface.SetTextPos(w/2 - tw/2, h/2 - th/2)
        surface.DrawText("reset colors")
    end
    resetLogBtn.DoClick = function()
        --pr reset les couleurs
        if not self.Settings.event_logger_colors then
            self.Settings.event_logger_colors = {}
        end
        for _, option in ipairs(logColorOptions) do
            self.Settings.event_logger_colors[option.key] = option.defaultColor
        end
        self:savesettings()
    end
    
    -- ========== PANNEAU RADAR ========== --
    local radarPanel = vgui.Create("DPanel", scrollPanel)
    radarPanel:SetPos(10, 860) 
    radarPanel:SetSize(330, 600) 
    radarPanel.Paint = function(panel, w, h)
        PaintSubcategoryBackground(panel, w, h)
        
        surface.SetDrawColor(COLORS.BORDER.r, COLORS.BORDER.g, COLORS.BORDER.b, 200)
        surface.DrawOutlinedRect(0, 0, w, h)
        surface.SetDrawColor(COLORS.BORDER.r + 20, COLORS.BORDER.g + 20, COLORS.BORDER.b + 20, 100)
        surface.DrawOutlinedRect(1, 1, w-2, h-2)
        
        draw.RoundedBox(6, 5, 5, w-10, 30, Color(COLORS.SUBCATEGORY_BG.r + 15, COLORS.SUBCATEGORY_BG.g + 15, COLORS.SUBCATEGORY_BG.b + 15, 200))
        draw.RoundedBox(6, 6, 6, w-12, 28, Color(COLORS.SUBCATEGORY_BG.r, COLORS.SUBCATEGORY_BG.g, COLORS.SUBCATEGORY_BG.b, 180))
        surface.SetDrawColor(COLORS.BORDER.r, COLORS.BORDER.g, COLORS.BORDER.b, 150)
        surface.DrawOutlinedRect(5, 5, w-10, 30)
        
        surface.SetTextColor(0, 0, 0, 100)
        surface.SetFont("Trebuchet18")
        local titleText = "RADAR"
        local tw, th = surface.GetTextSize(titleText)
        surface.SetTextPos(w/2 - tw/2 + 1, 15)
        surface.DrawText(titleText)
        
        surface.SetTextColor(COLORS.TEXT.r, COLORS.TEXT.g, COLORS.TEXT.b, COLORS.TEXT.a)
        surface.SetTextPos(w/2 - tw/2, 14)
        surface.DrawText(titleText)
    end
    
    --checkbox pour activer le radar
    local radarEnabled = vgui.Create("DPanel", radarPanel)
    radarEnabled:SetPos(10, 40)
    radarEnabled:SetSize(18, 18)
    radarEnabled:SetCursor("hand")
    local isRadarEnabled = self.Settings.radar and self.Settings.radar.enabled or false
    radarEnabled.Paint = function(panel, w, h)
        Rethoric_paintanimatedcheckbox(panel, w, h, isRadarEnabled, "radar_enabled", panel:IsHovered())
    end
    radarEnabled.OnMousePressed = function(panel, mouse)
        if mouse == MOUSE_LEFT then
            isRadarEnabled = not isRadarEnabled
            self.Settings.radar = self.Settings.radar or {}
            self.Settings.radar.enabled = isRadarEnabled
            self:savesettings()
        end
    end
    
    local radarLabel = vgui.Create("DLabel", radarPanel)
    radarLabel:SetPos(35, 42)
    radarLabel:SetSize(100, 20)
    radarLabel:SetText("enable")
    radarLabel:SetTextColor(COLORS.TEXT)
    radarLabel:SetCursor("hand")
    radarLabel.OnMousePressed = function(panel, mouse)
        if mouse == MOUSE_LEFT then radarEnabled:OnMousePressed(mouse) end
    end
    
    -- preview zone pour montrer le radar
    local radarPreviewZone = vgui.Create("DPanel", radarPanel)
    radarPreviewZone:SetPos(10, 75)
    radarPreviewZone:SetSize(310, 100)
    radarPreviewZone.Paint = function(panel, w, h)
        draw.RoundedBox(8, 0, 0, w, h, Color(10, 15, 20, 240))
        draw.RoundedBox(8, 2, 2, w-4, h-4, Color(15, 20, 25, 220))
        
        local colors = {
            {20, 30, 40, 200},  -- bleu fonce en haut
            {25, 35, 45, 180},  -- transition
            {30, 40, 40, 160}   -- vert fonce en bas
        }
        
        for i = 1, #colors - 1 do
            local startColor = colors[i]
            local endColor = colors[i + 1]
            local segmentHeight = (h-4) / (#colors - 1)
            local startY = 2 + (i - 1) * segmentHeight
            
            for y = 0, segmentHeight do
                local progress = y / segmentHeight
                local r = startColor[1] + (endColor[1] - startColor[1]) * progress
                local g = startColor[2] + (endColor[2] - startColor[2]) * progress
                local b = startColor[3] + (endColor[3] - startColor[3]) * progress
                local a = startColor[4] + (endColor[4] - startColor[4]) * progress
                
                surface.SetDrawColor(r, g, b, a)
                surface.DrawRect(2, startY + y, w-4, 1)
            end
        end
        
        surface.SetDrawColor(COLORS.BORDER.r, COLORS.BORDER.g, COLORS.BORDER.b, 200)
        surface.DrawOutlinedRect(0, 0, w, h)
        surface.SetDrawColor(COLORS.BORDER.r + 30, COLORS.BORDER.g + 30, COLORS.BORDER.b + 30, 120)
        surface.DrawOutlinedRect(1, 1, w-2, h-2)
        
        local centerX, centerY = w/2, h/2
        local radius = 35
        
        surface.SetDrawColor(50, 150, 100, 150)
        draw.NoTexture()
        
        local segments = 32
        for i = 0, segments do
            local angle1 = (i / segments) * math.pi * 2
            local angle2 = ((i + 1) / segments) * math.pi * 2
            local x1 = centerX + math.cos(angle1) * radius
            local y1 = centerY + math.sin(angle1) * radius
            local x2 = centerX + math.cos(angle2) * radius
            local y2 = centerY + math.sin(angle2) * radius
            surface.DrawLine(x1, y1, x2, y2)
        end
        
        surface.SetDrawColor(40, 120, 80, 100)
        surface.DrawLine(centerX - radius, centerY, centerX + radius, centerY)
        surface.DrawLine(centerX, centerY - radius, centerX, centerY + radius)
        
        local playerColor = (self.Settings.radar_colors and self.Settings.radar_colors.player_color) or Color(255, 100, 100, 255)
        surface.SetDrawColor(playerColor.r, playerColor.g, playerColor.b, 255)
        surface.DrawRect(centerX + 15, centerY - 10, 3, 3)
        surface.DrawRect(centerX - 20, centerY + 8, 3, 3)
        
        local localColor = (self.Settings.radar_colors and self.Settings.radar_colors.local_color) or Color(100, 255, 100, 255)
        surface.SetDrawColor(localColor.r, localColor.g, localColor.b, 255)
        surface.DrawRect(centerX - 1, centerY - 1, 3, 3)
    end
    
    local radarColorOptions = {
        {key = "player_color", label = "les mechants", defaultColor = Color(255, 100, 100, 255)},
        {key = "ally_color", label = "ally bff", defaultColor = Color(100, 200, 255, 255)},
        {key = "local_color", label = "local player", defaultColor = Color(100, 255, 100, 255)},
        {key = "background_color", label = "radar background", defaultColor = Color(20, 20, 20, 200)},
        {key = "grid_color", label = "radar grid", defaultColor = Color(50, 100, 80, 100)},
        {key = "reach_color", label = "reach indicateur", defaultColor = Color(100, 255, 100, 220)}
    }
    
    local radarColorY = 190
    for i, option in ipairs(radarColorOptions) do
        local colorContainer = vgui.Create("DPanel", radarPanel)
        colorContainer:SetPos(10, radarColorY)
        colorContainer:SetSize(310, 30)
        colorContainer.Paint = function(panel, w, h)
            draw.RoundedBox(4, 0, 0, w, h, Color(0, 0, 0, 30))
            surface.SetDrawColor(COLORS.BORDER.r, COLORS.BORDER.g, COLORS.BORDER.b, 50)
            surface.DrawOutlinedRect(0, 0, w, h)
        end
        
        local label = vgui.Create("DLabel", colorContainer)
        label:SetPos(10, 7)
        label:SetSize(200, 16)
        label:SetText(option.label)
        label:SetTextColor(COLORS.TEXT)
        label:SetFont("Trebuchet18")
        
        local colorBtn = vgui.Create("DButton", colorContainer)
        colorBtn:SetPos(270, 4)
        colorBtn:SetSize(30, 22)
        colorBtn:SetText("")
        colorBtn:SetCursor("hand")
        colorBtn.Paint = function(panel, w, h)
            local color = (self.Settings.radar_colors and self.Settings.radar_colors[option.key]) or option.defaultColor
            
            draw.RoundedBox(6, 0, 0, w, h, Color(0, 0, 0, 120))
            draw.RoundedBox(6, 2, 2, w-4, h-4, color)
            
            local borderAlpha = panel:IsHovered() and 255 or 180
            surface.SetDrawColor(255, 255, 255, borderAlpha)
            surface.DrawOutlinedRect(0, 0, w, h)
            
            if panel:IsHovered() then
                surface.SetDrawColor(255, 255, 255, 80)
                surface.DrawOutlinedRect(1, 1, w-2, h-2)
                surface.SetDrawColor(color.r, color.g, color.b, 50)
                surface.DrawOutlinedRect(-1, -1, w+2, h+2)
            end
        end
        colorBtn.DoClick = function()
            self:opencolorpicker(colorBtn, option.key, "radar")
        end
        
        radarColorY = radarColorY + 35 
    end
    
    local radarSettingsY = 420 
    
    local settingsTitle = vgui.Create("DLabel", radarPanel)
    settingsTitle:SetPos(15, radarSettingsY - 25)
    settingsTitle:SetSize(280, 20)
    settingsTitle:SetText("RADAR SETTINGS")
    settingsTitle:SetTextColor(Color(COLORS.TEXT.r, COLORS.TEXT.g, COLORS.TEXT.b, 200))
    settingsTitle:SetFont("Trebuchet18")
    
    
    local currentRadarSize = self.Settings.radar and self.Settings.radar.size or 100
    self:createcustomslider(radarPanel, 10, radarSettingsY, 310, "Radar Size", 50, 200, currentRadarSize, function(val)
        self.Settings.radar = self.Settings.radar or {}
        self.Settings.radar.size = val
        self:savesettings()
    end)
    radarSettingsY = radarSettingsY + 40 
    
    local currentRadarRange = self.Settings.radar and self.Settings.radar.range or 1000
    self:createcustomslider(radarPanel, 10, radarSettingsY, 310, "Radar Range", 100, 5000, currentRadarRange, function(val)
        self.Settings.radar = self.Settings.radar or {}
        self.Settings.radar.range = val
        self:savesettings()
    end)
    radarSettingsY = radarSettingsY + 40
    
    local reachCheckbox = vgui.Create("DPanel", radarPanel)
    reachCheckbox:SetPos(10, radarSettingsY)
    reachCheckbox:SetSize(18, 18)
    reachCheckbox:SetCursor("hand")
    local isReachEnabled = self.Settings.radar and self.Settings.radar.show_reach or false
    reachCheckbox.Paint = function(panel, w, h)
        Rethoric_paintanimatedcheckbox(panel, w, h, isReachEnabled, "radar_reach_enabled", panel:IsHovered())
    end
    reachCheckbox.OnMousePressed = function(panel, mouse)
        if mouse == MOUSE_LEFT then
            isReachEnabled = not isReachEnabled
            self.Settings.radar = self.Settings.radar or {}
            self.Settings.radar.show_reach = isReachEnabled
            self:savesettings()
        end
    end
    
    local reachLabel = vgui.Create("DLabel", radarPanel)
    reachLabel:SetPos(35, radarSettingsY + 2)
    reachLabel:SetSize(150, 15)
    reachLabel:SetText("reach indicator")
    reachLabel:SetTextColor(COLORS.TEXT)
    reachLabel:SetFont("DermaDefault")
    reachLabel:SetCursor("hand")
    reachLabel.OnMousePressed = function(panel, mouse)
        if mouse == MOUSE_LEFT then reachCheckbox:OnMousePressed(mouse) end
    end
    
    --bouton couleur pour l'indicateur de reach
    local reachColorBtn = vgui.Create("DButton", radarPanel)
    reachColorBtn:SetPos(280, radarSettingsY - 2)
    reachColorBtn:SetSize(22, 22)
    reachColorBtn:SetText("")
    reachColorBtn:SetCursor("hand")
    reachColorBtn.Paint = function(panel, w, h)
        local color = (self.Settings.radar_colors and self.Settings.radar_colors.reach_color) or Color(100, 255, 100, 220)
        
        draw.RoundedBox(5, 0, 0, w, h, Color(0, 0, 0, 100))
        draw.RoundedBox(5, 1, 1, w-2, h-2, color)
        
        local borderAlpha = panel:IsHovered() and 255 or 150
        surface.SetDrawColor(255, 255, 255, borderAlpha)
        surface.DrawOutlinedRect(0, 0, w, h)
        
        if panel:IsHovered() then
            surface.SetDrawColor(255, 255, 255, 50)
            surface.DrawOutlinedRect(1, 1, w-2, h-2)
        end
    end
    reachColorBtn.DoClick = function()
        self:opencolorpicker(reachColorBtn, "reach_color", "radar")
    end
    
    radarSettingsY = radarSettingsY + 40
    
    local resetRadarBtn = vgui.Create("DButton", radarPanel)
    resetRadarBtn:SetPos(10, radarSettingsY + 20)
    resetRadarBtn:SetSize(310, 30)
    resetRadarBtn:SetText("")
    resetRadarBtn.Paint = function(panel, w, h)
        local baseColor = panel:IsHovered() and {45, 25, 25} or {35, 20, 20}
        local colors = {
            {baseColor[1] + 15, baseColor[2] + 20, baseColor[3] + 25, 200},
            {baseColor[1] + 5, baseColor[2] + 15, baseColor[3] + 20, 180},
            {baseColor[1], baseColor[2] + 10, baseColor[3] + 15, 160},
            {baseColor[1] - 5, baseColor[2] + 5, baseColor[3] + 10, 140}
        }
        
        for i = 1, #colors - 1 do
            local startColor = colors[i]
            local endColor = colors[i + 1]
            local segmentHeight = h / (#colors - 1)
            local startY = (i - 1) * segmentHeight
            
            for y = 0, segmentHeight do
                local progress = y / segmentHeight
                local r = startColor[1] + (endColor[1] - startColor[1]) * progress
                local g = startColor[2] + (endColor[2] - startColor[2]) * progress
                local b = startColor[3] + (endColor[3] - startColor[3]) * progress
                local a = startColor[4] + (endColor[4] - startColor[4]) * progress
                
                surface.SetDrawColor(r, g, b, a)
                surface.DrawRect(0, startY + y, w, 1)
            end
        end
        
        --bordure avec effet pas trop uhq
        local borderAlpha = panel:IsHovered() and 255 or 200
        surface.SetDrawColor(COLORS.BORDER.r, COLORS.BORDER.g, COLORS.BORDER.b, borderAlpha)
        surface.DrawOutlinedRect(0, 0, w, h)
        
        if panel:IsHovered() then
            surface.SetDrawColor(255, 100, 100, 100)
            surface.DrawOutlinedRect(1, 1, w-2, h-2)
        end
        
        --texte avec ombres
        surface.SetTextColor(0, 0, 0, 150)
        surface.SetFont("Trebuchet18")
        local tw, th = surface.GetTextSize("RESET COLORS")
        surface.SetTextPos(w/2 - tw/2 + 1, h/2 - th/2 + 1)
        surface.DrawText("RESET COLORS")
        
        surface.SetTextColor(COLORS.TEXT.r, COLORS.TEXT.g, COLORS.TEXT.b, COLORS.TEXT.a)
        surface.SetTextPos(w/2 - tw/2, h/2 - th/2)
        surface.DrawText("RESET COLORS")
    end
    resetRadarBtn.DoClick = function()
        if not self.Settings.radar_colors then
            self.Settings.radar_colors = {}
        end
        for _, option in ipairs(radarColorOptions) do
            self.Settings.radar_colors[option.key] = option.defaultColor
        end
        self:savesettings()
        
        resetRadarBtn:SetText("✓ RESET!")
        timer.Simple(1, function()
            if IsValid(resetRadarBtn) then
                resetRadarBtn:SetText("")
            end
        end)
    end
    
    -- ========== PANNEAU ENVIRONMENT========== --
    local environmentPanel = vgui.Create("DPanel", scrollPanel)
    environmentPanel:SetPos(350, 860)
    environmentPanel:SetSize(330, 600) -- grand panneau unifié
    environmentPanel.Paint = function(panel, w, h)
        PaintSubcategoryBackground(panel, w, h)
        
        -- bordure principale
        surface.SetDrawColor(COLORS.BORDER.r, COLORS.BORDER.g, COLORS.BORDER.b, 200)
        surface.DrawOutlinedRect(0, 0, w, h)
        surface.SetDrawColor(COLORS.BORDER.r + 20, COLORS.BORDER.g + 20, COLORS.BORDER.b + 20, 100)
        surface.DrawOutlinedRect(1, 1, w-2, h-2)
        
        -- titre principal
        draw.RoundedBox(6, 5, 5, w-10, 30, Color(COLORS.SUBCATEGORY_BG.r + 15, COLORS.SUBCATEGORY_BG.g + 15, COLORS.SUBCATEGORY_BG.b + 15, 200))
        draw.RoundedBox(6, 6, 6, w-12, 28, Color(COLORS.SUBCATEGORY_BG.r, COLORS.SUBCATEGORY_BG.g, COLORS.SUBCATEGORY_BG.b, 180))
        surface.SetDrawColor(COLORS.BORDER.r, COLORS.BORDER.g, COLORS.BORDER.b, 150)
        surface.DrawOutlinedRect(5, 5, w-10, 30)
        
        surface.SetTextColor(0, 0, 0, 100)
        surface.SetFont("Trebuchet18")
        local titleText = "ENVIRONMENT"
        local tw, th = surface.GetTextSize(titleText)
        surface.SetTextPos(w/2 - tw/2 + 1, 15)
        surface.DrawText(titleText)
        
        surface.SetTextColor(COLORS.TEXT.r, COLORS.TEXT.g, COLORS.TEXT.b, COLORS.TEXT.a)
        surface.SetTextPos(w/2 - tw/2, 14)
        surface.DrawText(titleText)
    end
    
    -- === SKYBOX ===
    local skyboxSubPanel = vgui.Create("DPanel", environmentPanel)
    skyboxSubPanel:SetPos(10, 40)
    skyboxSubPanel:SetSize(310, 120)
    skyboxSubPanel.Paint = function(panel, w, h)
        draw.RoundedBox(4, 0, 0, w, h, Color(0, 0, 0, 50))
        surface.SetDrawColor(COLORS.BORDER.r, COLORS.BORDER.g, COLORS.BORDER.b, 100)
        surface.DrawOutlinedRect(0, 0, w, h)
        
        surface.SetTextColor(COLORS.TEXT.r, COLORS.TEXT.g, COLORS.TEXT.b, COLORS.TEXT.a)
        surface.SetFont("Trebuchet18")
        local titleText = "SKYBOX"
        surface.SetTextPos(10, 5)
        surface.DrawText(titleText)
    end
    
    local skyboxEnabled = vgui.Create("DPanel", skyboxSubPanel)
    skyboxEnabled:SetPos(10, 30)
    skyboxEnabled:SetSize(18, 18)
    skyboxEnabled:SetCursor("hand")
    local isSkyboxEnabled = self.Settings.skybox and self.Settings.skybox.enabled or false
    skyboxEnabled.Paint = function(panel, w, h)
        Rethoric_paintanimatedcheckbox(panel, w, h, isSkyboxEnabled, "skybox_enabled", panel:IsHovered())
    end
    skyboxEnabled.OnMousePressed = function(panel, mouse)
        if mouse == MOUSE_LEFT then
            isSkyboxEnabled = not isSkyboxEnabled
            self.Settings.skybox = self.Settings.skybox or {}
            self.Settings.skybox.enabled = isSkyboxEnabled
            self:savesettings()
        end
    end
    
    local skyboxLabel = vgui.Create("DLabel", skyboxSubPanel)
    skyboxLabel:SetPos(35, 32)
    skyboxLabel:SetSize(60, 20)
    skyboxLabel:SetText("enable")
    skyboxLabel:SetTextColor(COLORS.TEXT)
    skyboxLabel:SetCursor("hand")
    skyboxLabel.OnMousePressed = function(panel, mouse)
        if mouse == MOUSE_LEFT then skyboxEnabled:OnMousePressed(mouse) end
    end
    
    local skyboxDropdown = vgui.Create("DComboBox", skyboxSubPanel)
    skyboxDropdown:SetPos(10, 60)
    skyboxDropdown:SetSize(290, 25)
    skyboxDropdown:SetValue("Default")
    skyboxDropdown:AddChoice("Default")
    skyboxDropdown:AddChoice("Day Clear")
    skyboxDropdown:AddChoice("Day Cloudy")
    skyboxDropdown:AddChoice("Sunset")
    skyboxDropdown:AddChoice("Night")
    skyboxDropdown:AddChoice("Stormy")
    skyboxDropdown:AddChoice("Desert")
    skyboxDropdown.Paint = function(panel, w, h)
        draw.RoundedBox(4, 0, 0, w, h, Color(COLORS.PANEL_BG.r, COLORS.PANEL_BG.g, COLORS.PANEL_BG.b, 200))
        surface.SetDrawColor(COLORS.BORDER.r, COLORS.BORDER.g, COLORS.BORDER.b, 200)
        surface.DrawOutlinedRect(0, 0, w, h)
        if panel:IsHovered() then
            surface.SetDrawColor(COLORS.BORDER.r + 30, COLORS.BORDER.g + 30, COLORS.BORDER.b + 30, 150)
            surface.DrawOutlinedRect(1, 1, w-2, h-2)
        end
    end
    skyboxDropdown.OnSelect = function(panel, index, value)
        self.Settings.skybox = self.Settings.skybox or {}
        self.Settings.skybox.selected = value
        self:savesettings()
    end
    -- === FOV CHANGER===
    local fovSubPanel = vgui.Create("DPanel", environmentPanel)
    fovSubPanel:SetPos(10, 170)
    fovSubPanel:SetSize(310, 120)
    fovSubPanel.Paint = function(panel, w, h)
        draw.RoundedBox(4, 0, 0, w, h, Color(0, 0, 0, 50))
        surface.SetDrawColor(COLORS.BORDER.r, COLORS.BORDER.g, COLORS.BORDER.b, 100)
        surface.DrawOutlinedRect(0, 0, w, h)
        
        surface.SetTextColor(COLORS.TEXT.r, COLORS.TEXT.g, COLORS.TEXT.b, COLORS.TEXT.a)
        surface.SetFont("Trebuchet18")
        local titleText = "FOV CHANGER"
        surface.SetTextPos(10, 5)
        surface.DrawText(titleText)
    end
    
    local fovEnabled = vgui.Create("DPanel", fovSubPanel)
    fovEnabled:SetPos(10, 30)
    fovEnabled:SetSize(18, 18)
    fovEnabled:SetCursor("hand")
    local isFovEnabled = self.Settings.fov_changer and self.Settings.fov_changer.enabled or false
    fovEnabled.Paint = function(panel, w, h)
        Rethoric_paintanimatedcheckbox(panel, w, h, isFovEnabled, "fov_enabled", panel:IsHovered())
    end
    fovEnabled.OnMousePressed = function(panel, mouse)
        if mouse == MOUSE_LEFT then
            isFovEnabled = not isFovEnabled
            self.Settings.fov_changer = self.Settings.fov_changer or {}
            self.Settings.fov_changer.enabled = isFovEnabled
            self:savesettings()
        end
    end
    
    local fovLabel = vgui.Create("DLabel", fovSubPanel)
    fovLabel:SetPos(35, 32)
    fovLabel:SetSize(60, 20)
    fovLabel:SetText("enable")
    fovLabel:SetTextColor(COLORS.TEXT)
    fovLabel:SetCursor("hand")
    fovLabel.OnMousePressed = function(panel, mouse)
        if mouse == MOUSE_LEFT then fovEnabled:OnMousePressed(mouse) end
    end
    
    local fovSlider = vgui.Create("DNumSlider", fovSubPanel)
    fovSlider:SetPos(10, 60)
    fovSlider:SetSize(290, 25)
    fovSlider:SetText("FOV Value")
    fovSlider:SetMin(60)
    fovSlider:SetMax(120)
    fovSlider:SetDecimals(0)
    fovSlider:SetValue(self.Settings.fov_changer and self.Settings.fov_changer.value or 90)
    fovSlider.OnValueChanged = function(panel, value)
        self.Settings.fov_changer = self.Settings.fov_changer or {}
        self.Settings.fov_changer.value = value
        self:savesettings()
    end
    
    -- === ADDITIONAL HALOS ===
    local halosSubPanel = vgui.Create("DPanel", environmentPanel)
    halosSubPanel:SetPos(10, 300)
    halosSubPanel:SetSize(310, 150)
    halosSubPanel.Paint = function(panel, w, h)
        draw.RoundedBox(4, 0, 0, w, h, Color(0, 0, 0, 50))
        surface.SetDrawColor(COLORS.BORDER.r, COLORS.BORDER.g, COLORS.BORDER.b, 100)
        surface.DrawOutlinedRect(0, 0, w, h)
        
        surface.SetTextColor(COLORS.TEXT.r, COLORS.TEXT.g, COLORS.TEXT.b, COLORS.TEXT.a)
        surface.SetFont("Trebuchet18")
        local titleText = "ADDITIONAL HALOS"
        surface.SetTextPos(10, 5)
        surface.DrawText(titleText)
    end
    
    local halosEnabled = vgui.Create("DPanel", halosSubPanel)
    halosEnabled:SetPos(10, 30)
    halosEnabled:SetSize(18, 18)
    halosEnabled:SetCursor("hand")
    local isHalosEnabled = self.Settings.additional_halos and self.Settings.additional_halos.enabled or false
    halosEnabled.Paint = function(panel, w, h)
        Rethoric_paintanimatedcheckbox(panel, w, h, isHalosEnabled, "halos_enabled", panel:IsHovered())
    end
    halosEnabled.OnMousePressed = function(panel, mouse)
        if mouse == MOUSE_LEFT then
            isHalosEnabled = not isHalosEnabled
            self.Settings.additional_halos = self.Settings.additional_halos or {}
            self.Settings.additional_halos.enabled = isHalosEnabled
            self:savesettings()
        end
    end
    
    local halosLabel = vgui.Create("DLabel", halosSubPanel)
    halosLabel:SetPos(35, 32)
    halosLabel:SetSize(60, 20)
    halosLabel:SetText("enable")
    halosLabel:SetTextColor(COLORS.TEXT)
    halosLabel:SetCursor("hand")
    halosLabel.OnMousePressed = function(panel, mouse)
        if mouse == MOUSE_LEFT then halosEnabled:OnMousePressed(mouse) end
    end
    
--options
    local halosOptions = {
        {key = "players", label = "Player", y = 60},
        {key = "props", label = "Props", y = 90}
    }
    
    for _, option in ipairs(halosOptions) do
        local optionEnabled = vgui.Create("DPanel", halosSubPanel)
        optionEnabled:SetPos(10, option.y)
        optionEnabled:SetSize(18, 18)
        optionEnabled:SetCursor("hand")
        local isOptionEnabled = self.Settings.additional_halos and self.Settings.additional_halos[option.key] or false
        optionEnabled.Paint = function(panel, w, h)
            Rethoric_paintanimatedcheckbox(panel, w, h, isOptionEnabled, "halos_" .. option.key, panel:IsHovered())
        end
        optionEnabled.OnMousePressed = function(panel, mouse)
            if mouse == MOUSE_LEFT then
                isOptionEnabled = not isOptionEnabled
                self.Settings.additional_halos = self.Settings.additional_halos or {}
                self.Settings.additional_halos[option.key] = isOptionEnabled
                self:savesettings()
            end
        end
        
        local optionLabel = vgui.Create("DLabel", halosSubPanel)
        optionLabel:SetPos(35, option.y + 2)
        optionLabel:SetSize(90, 20)
        optionLabel:SetText(option.label)
        optionLabel:SetTextColor(COLORS.TEXT)
        optionLabel:SetCursor("hand")
        optionLabel.OnMousePressed = function(panel, mouse)
            if mouse == MOUSE_LEFT then optionEnabled:OnMousePressed(mouse) end
        end
        
        local colorButton = vgui.Create("DPanel", halosSubPanel)
        colorButton:SetPos(130, option.y)
        colorButton:SetSize(25, 18)
        colorButton:SetCursor("hand")
        local currentColor = self.Settings.additional_halos and self.Settings.additional_halos[option.key .. "_color"] or Color(255, 255, 255, 255)
        colorButton.Paint = function(panel, w, h)
            Rethoric_paintcolorbutton(panel, w, h, currentColor, panel:IsHovered())
        end
        colorButton.OnMousePressed = function(panel, mouse)
            if mouse == MOUSE_LEFT then
                self:opencolorpicker(colorButton, option.key .. "_color", "additional_halos")
            end
        end
    end
    
    -- === ADITIONALS CHAMS ===
    local chamsSubPanel = vgui.Create("DPanel", environmentPanel)
    chamsSubPanel:SetPos(10, 460)
    chamsSubPanel:SetSize(310, 120)
    chamsSubPanel.Paint = function(panel, w, h)
        draw.RoundedBox(4, 0, 0, w, h, Color(0, 0, 0, 50))
        surface.SetDrawColor(COLORS.BORDER.r, COLORS.BORDER.g, COLORS.BORDER.b, 100)
        surface.DrawOutlinedRect(0, 0, w, h)
        
        surface.SetTextColor(COLORS.TEXT.r, COLORS.TEXT.g, COLORS.TEXT.b, COLORS.TEXT.a)
        surface.SetFont("Trebuchet18")
        local titleText = "ADITIONALS CHAMS"
        surface.SetTextPos(10, 5)
        surface.DrawText(titleText)
    end
    
    local chamsEnabled = vgui.Create("DPanel", chamsSubPanel)
    chamsEnabled:SetPos(10, 30)
    chamsEnabled:SetSize(18, 18)
    chamsEnabled:SetCursor("hand")
    local isChamsEnabled = self.Settings.additional_chams and self.Settings.additional_chams.enabled or false
    chamsEnabled.Paint = function(panel, w, h)
        Rethoric_paintanimatedcheckbox(panel, w, h, isChamsEnabled, "chams_enabled", panel:IsHovered())
    end
    chamsEnabled.OnMousePressed = function(panel, mouse)
        if mouse == MOUSE_LEFT then
            isChamsEnabled = not isChamsEnabled
            self.Settings.additional_chams = self.Settings.additional_chams or {}
            self.Settings.additional_chams.enabled = isChamsEnabled
            self:savesettings()
        end
    end
    
    local chamsLabel = vgui.Create("DLabel", chamsSubPanel)
    chamsLabel:SetPos(35, 32)
    chamsLabel:SetSize(60, 20)
    chamsLabel:SetText("enable")
    chamsLabel:SetTextColor(COLORS.TEXT)
    chamsLabel:SetCursor("hand")
    chamsLabel.OnMousePressed = function(panel, mouse)
        if mouse == MOUSE_LEFT then chamsEnabled:OnMousePressed(mouse) end
    end
    
    local chamsOptions = {
        {key = "vietnam_hat", label = "Vietnam hat", y = 60},
        {key = "king_von", label = "KING VON", y = 140}
    }
    for _, option in ipairs(chamsOptions) do
        local optionEnabled = vgui.Create("DPanel", chamsSubPanel)
        optionEnabled:SetPos(10, option.y)
        optionEnabled:SetSize(18, 18)
        optionEnabled:SetCursor("hand")
        local isOptionEnabled = self.Settings.additional_chams and self.Settings.additional_chams[option.key] or false
        optionEnabled.Paint = function(panel, w, h)
            Rethoric_paintanimatedcheckbox(panel, w, h, isOptionEnabled, "chams_" .. option.key, panel:IsHovered())
        end
        optionEnabled.OnMousePressed = function(panel, mouse)
            if mouse == MOUSE_LEFT then
                isOptionEnabled = not isOptionEnabled
                self.Settings.additional_chams = self.Settings.additional_chams or {}
                self.Settings.additional_chams[option.key] = isOptionEnabled
                self:savesettings()
            end
        end
        
        local optionLabel = vgui.Create("DLabel", chamsSubPanel)
        optionLabel:SetPos(35, option.y + 2)
        optionLabel:SetSize(90, 20)
        optionLabel:SetText(option.label)
        optionLabel:SetTextColor(COLORS.TEXT)
        optionLabel:SetCursor("hand")
        optionLabel.OnMousePressed = function(panel, mouse)
            if mouse == MOUSE_LEFT then optionEnabled:OnMousePressed(mouse) end
        end
        --c dla merde ptn aidez moi 
        if option.key == "vietnam_hat" then
            local sizeLabel = vgui.Create("DLabel", chamsSubPanel)
            sizeLabel:SetPos(120, option.y + 2)
            sizeLabel:SetSize(80, 15)
            sizeLabel:SetText("Taille: " .. string.format("%.1f", vietnamHatSettings.size or 1.0))
            sizeLabel:SetTextColor(COLORS.TEXT)
            sizeLabel:SetFont("DermaDefault")
            
            local sizeSlider = vgui.Create("DNumSlider", chamsSubPanel)
            sizeSlider:SetPos(210, option.y - 1)
            sizeSlider:SetSize(100, 20)
            sizeSlider:SetMin(0.1)
            sizeSlider:SetMax(3.0)
            sizeSlider:SetDecimals(1)
            sizeSlider:SetValue(vietnamHatSettings.size or 1.0)
            sizeSlider:SetText("")
            sizeSlider.OnValueChanged = function(panel, value)
                vietnamHatSettings.size = value
                sizeLabel:SetText("Taille: " .. string.format("%.1f", value))
                self:savesettings()
            end
            
            --slider z
            local posZLabel = vgui.Create("DLabel", chamsSubPanel)
            posZLabel:SetPos(120, option.y + 25)
            posZLabel:SetSize(80, 15)
            posZLabel:SetText("Pos Z: " .. string.format("%.1f", vietnamHatSettings.posZ or 2.0))
            posZLabel:SetTextColor(COLORS.TEXT)
            posZLabel:SetFont("DermaDefault")
            
            local posZSlider = vgui.Create("DNumSlider", chamsSubPanel)
            posZSlider:SetPos(210, option.y + 22)
            posZSlider:SetSize(100, 20)
            posZSlider:SetMin(-10.0)
            posZSlider:SetMax(20.0)
            posZSlider:SetDecimals(1)
            posZSlider:SetValue(vietnamHatSettings.posZ or 2.0)
            posZSlider:SetText("")
            posZSlider.OnValueChanged = function(panel, value)
                vietnamHatSettings.posZ = value
                posZLabel:SetText("Pos Z: " .. string.format("%.1f", value))
                self:savesettings()
            end
        end
    end
    
    local reloadBarPanel = vgui.Create("DPanel", scrollPanel)
    reloadBarPanel:SetPos(10, 1480)
    reloadBarPanel:SetSize(660, 200)
    reloadBarPanel.Paint = function(panel, w, h)
        PaintSubcategoryBackground(panel, w, h)
        
        surface.SetDrawColor(COLORS.BORDER.r, COLORS.BORDER.g, COLORS.BORDER.b, 200)
        surface.DrawOutlinedRect(0, 0, w, h)
        surface.SetDrawColor(COLORS.BORDER.r + 20, COLORS.BORDER.g + 20, COLORS.BORDER.b + 20, 100)
        surface.DrawOutlinedRect(1, 1, w-2, h-2)
        
        draw.RoundedBox(6, 5, 5, w-10, 30, Color(COLORS.SUBCATEGORY_BG.r + 15, COLORS.SUBCATEGORY_BG.g + 15, COLORS.SUBCATEGORY_BG.b + 15, 200))
        draw.RoundedBox(6, 6, 6, w-12, 28, Color(COLORS.SUBCATEGORY_BG.r, COLORS.SUBCATEGORY_BG.g, COLORS.SUBCATEGORY_BG.b, 180))
        surface.SetDrawColor(COLORS.BORDER.r, COLORS.BORDER.g, COLORS.BORDER.b, 150)
        surface.DrawOutlinedRect(5, 5, w-10, 30)
        
        surface.SetTextColor(0, 0, 0, 100)
        surface.SetFont("Trebuchet18")
        local titleText = "RELOAD BAR"
        local tw, th = surface.GetTextSize(titleText)
        surface.SetTextPos(w/2 - tw/2 + 1, 15)
        surface.DrawText(titleText)
        
        surface.SetTextColor(COLORS.TEXT.r, COLORS.TEXT.g, COLORS.TEXT.b, COLORS.TEXT.a)
        surface.SetTextPos(w/2 - tw/2, 14)
        surface.DrawText(titleText)
    end
    
    local reloadBarSubPanel = vgui.Create("DPanel", reloadBarPanel)
    reloadBarSubPanel:SetPos(10, 40)
    reloadBarSubPanel:SetSize(320, 150)
    reloadBarSubPanel.Paint = function(panel, w, h)
        draw.RoundedBox(4, 0, 0, w, h, Color(0, 0, 0, 50))
        surface.SetDrawColor(COLORS.BORDER.r, COLORS.BORDER.g, COLORS.BORDER.b, 100)
        surface.DrawOutlinedRect(0, 0, w, h)
        
        surface.SetTextColor(COLORS.TEXT.r, COLORS.TEXT.g, COLORS.TEXT.b, COLORS.TEXT.a)
        surface.SetFont("Trebuchet18")
        local titleText = "RELOAD BAR OPTIONS"
        local tw, th = surface.GetTextSize(titleText)
        surface.SetTextPos(w/2 - tw/2, 5)
        surface.DrawText(titleText)
    end
    
    local reloadBarEnabled = vgui.Create("DPanel", reloadBarSubPanel)
    reloadBarEnabled:SetPos(20, 40)
    reloadBarEnabled:SetSize(18, 18)
    reloadBarEnabled:SetCursor("hand")
    local isReloadBarEnabled = self.Settings.reload_bar and self.Settings.reload_bar.enabled or false
    reloadBarEnabled.Paint = function(panel, w, h)
        Rethoric_paintanimatedcheckbox(panel, w, h, isReloadBarEnabled, "reload_bar_enabled", panel:IsHovered())
    end
    reloadBarEnabled.OnMousePressed = function(panel, mouse)
        if mouse == MOUSE_LEFT then
            isReloadBarEnabled = not isReloadBarEnabled
            self.Settings.reload_bar = self.Settings.reload_bar or {}
            self.Settings.reload_bar.enabled = isReloadBarEnabled
            self:savesettings()
        end
    end
    
    local reloadBarLabel = vgui.Create("DLabel", reloadBarSubPanel)
    reloadBarLabel:SetPos(45, 42)
    reloadBarLabel:SetSize(60, 20)
    reloadBarLabel:SetText("enable")
    reloadBarLabel:SetTextColor(COLORS.TEXT)
    reloadBarLabel:SetCursor("hand")
    reloadBarLabel.OnMousePressed = function(panel, mouse)
        if mouse == MOUSE_LEFT then reloadBarEnabled:OnMousePressed(mouse) end
    end
    
    local reloadBarColorBtn = vgui.Create("DButton", reloadBarSubPanel)
    reloadBarColorBtn:SetPos(120, 40)
    reloadBarColorBtn:SetSize(30, 20)
    reloadBarColorBtn:SetText("")
    reloadBarColorBtn:SetCursor("hand")
    reloadBarColorBtn.Paint = function(panel, w, h)
        if not self.Settings.reload_bar then
            self.Settings.reload_bar = {}
        end
        local color = self.Settings.reload_bar.color or Color(255, 165, 0, 255)
        Rethoric_paintcolorbutton(panel, w, h, color, panel:IsHovered())
    end
    reloadBarColorBtn.DoClick = function()
        self:opencolorpicker(reloadBarColorBtn, "color", "reload_bar")
    end
    
    local reloadBarColorLabel = vgui.Create("DLabel", reloadBarSubPanel)
    reloadBarColorLabel:SetPos(155, 42)
    reloadBarColorLabel:SetSize(100, 20)
    reloadBarColorLabel:SetText("bar color")
    reloadBarColorLabel:SetTextColor(COLORS.TEXT)
    reloadBarColorLabel:SetCursor("hand")
    reloadBarColorLabel.OnMousePressed = function(panel, mouse)
        if mouse == MOUSE_LEFT then reloadBarColorBtn:DoClick() end
    end
    
    -- Position X Slider
    local currentPosX = self.Settings.reload_bar.position_x or 850
    self:createcustomslider(reloadBarSubPanel, 20, 70, 270, "Position X", 0, ScrW(), currentPosX, function(val)
        self.Settings.reload_bar.position_x = val
        self:savesettings()
    end)
    
    -- Position Y Slider
    local currentPosY = self.Settings.reload_bar.position_y or 830
    self:createcustomslider(reloadBarSubPanel, 20, 115, 270, "Position Y", 0, ScrH(), currentPosY, function(val)
        self.Settings.reload_bar.position_y = val
        self:savesettings()
    end)
    
    local reloadBarPreview = vgui.Create("DPanel", reloadBarPanel)
    reloadBarPreview:SetPos(340, 40)
    reloadBarPreview:SetSize(310, 150)
    reloadBarPreview.Paint = function(panel, w, h)
        -- Background rectangle (no rounded corners)
        surface.SetDrawColor(0, 0, 0, 50)
        surface.DrawRect(0, 0, w, h)
        surface.SetDrawColor(COLORS.BORDER.r, COLORS.BORDER.g, COLORS.BORDER.b, 100)
        surface.DrawOutlinedRect(0, 0, w, h)
        
        surface.SetTextColor(COLORS.TEXT.r, COLORS.TEXT.g, COLORS.TEXT.b, COLORS.TEXT.a)
        surface.SetFont("Trebuchet18")
        local titleText = "RELOAD BAR PREVIEW"
        local tw, th = surface.GetTextSize(titleText)
        surface.SetTextPos(w/2 - tw/2, 5)
        surface.DrawText(titleText)
        
        if isReloadBarEnabled then
            local time = SysTime()
            local reloadDuration = 2.5
            local progress = (time % reloadDuration) / reloadDuration
            
            local barX = 30
            local barY = 60
            local barWidth = 250
            local barHeight = 16
            
            -- Background rectangle (no rounded corners)
            local bgColor = Color(15, 15, 15, 220)
            surface.SetDrawColor(bgColor.r, bgColor.g, bgColor.b, bgColor.a)
            surface.DrawRect(barX - 2, barY - 2, barWidth + 4, barHeight + 4)
            
            -- Progress bar fill (no rounded corners)
            if not self.Settings.reload_bar then
                self.Settings.reload_bar = {}
            end
            local barColor = self.Settings.reload_bar.color or Color(255, 165, 0, 255)
             local gradientSteps = 50
             local fillWidth = barWidth * progress
             for i = 0, gradientSteps do
                 local x = (fillWidth / gradientSteps) * i
                 local width = math.ceil(fillWidth / gradientSteps) + 1
                 local alpha = 0.3 + 0.7 * (i / gradientSteps)
                 local r = Lerp(alpha, math.max(30, barColor.r - 100), barColor.r)
                 local g = Lerp(alpha, math.max(30, barColor.g - 100), barColor.g)
                 local b = Lerp(alpha, math.max(30, barColor.b - 100), barColor.b)
                 if x < fillWidth then
                     surface.SetDrawColor(r, g, b, 255)
                     surface.DrawRect(barX + x, barY, width, barHeight)
                 end
             end

            surface.SetDrawColor(COLORS.BORDER.r, COLORS.BORDER.g, COLORS.BORDER.b, 200)
            surface.DrawOutlinedRect(barX, barY, barWidth, barHeight)
            surface.SetTextColor(COLORS.TEXT.r, COLORS.TEXT.g, COLORS.TEXT.b, COLORS.TEXT.a)
            surface.SetFont("Trebuchet18")
            local progressText = math.floor(progress * 100) .. "%"
            local ptw, pth = surface.GetTextSize(progressText)
            surface.SetTextPos(w/2 - ptw/2, barY + barHeight + 20)
            surface.DrawText(progressText)
        else
            surface.SetTextColor(COLORS.TEXT_DIM.r, COLORS.TEXT_DIM.g, COLORS.TEXT_DIM.b, COLORS.TEXT_DIM.a)
            surface.SetFont("Trebuchet18")
            local disabledText = "enable la bar to see preview"
            local dtw, dth = surface.GetTextSize(disabledText)
            surface.SetTextPos(w/2 - dtw/2, h/2 - dth/2)
            surface.DrawText(disabledText)
        end
    end
    
    scrollPanel:GetCanvas():SetTall(2000) 
    local previewPanel = vgui.Create("DPanel", scrollPanel)
    previewPanel:SetPos(220, 10)
    previewPanel:SetSize(220, 380)
    previewPanel.Paint = function(panel, w, h)
        draw.RoundedBox(6, 0, 0, w, h, COLORS.PANEL_BG)
        surface.SetDrawColor(COLORS.BORDER.r, COLORS.BORDER.g, COLORS.BORDER.b, 200)
        surface.DrawOutlinedRect(0, 0, w, h)
        draw.RoundedBox(4, 5, 5, w-10, 25, Color(COLORS.SUBCATEGORY_BG.r, COLORS.SUBCATEGORY_BG.g, COLORS.SUBCATEGORY_BG.b, 180))
        surface.SetDrawColor(COLORS.BORDER.r, COLORS.BORDER.g, COLORS.BORDER.b, 150)
        surface.DrawOutlinedRect(5, 5, w-10, 25)
        surface.SetTextColor(COLORS.TEXT.r, COLORS.TEXT.g, COLORS.TEXT.b, COLORS.TEXT.a)
        surface.SetFont("Trebuchet18")
        local titleText = "ESP PREVIEW"
        local tw, th = surface.GetTextSize(titleText)
        surface.SetTextPos(w/2 - tw/2, 12)
        surface.DrawText(titleText)
    end
    
    local modelPanel = vgui.Create("DPanel", previewPanel)
    modelPanel:SetPos(5, 35)
    modelPanel:SetSize(210, 340)
    modelPanel.Paint = function(panel, w, h)
        draw.RoundedBox(4, 0, 0, w, h, Color(20, 40, 50, 150))
        surface.SetDrawColor(COLORS.BORDER.r, COLORS.BORDER.g, COLORS.BORDER.b, 200)
        surface.DrawOutlinedRect(0, 0, w, h)
        
        local gridSize = 10
        
        surface.SetDrawColor(35, 70, 80, 80)
        
        for x = 0, w, gridSize do
            surface.DrawLine(x, 0, x, h)
        end
        if w % gridSize ~= 0 then
            surface.DrawLine(w, 0, w, h)
        end
        
        for y = 0, h, gridSize do
            surface.DrawLine(0, y, w, y)
        end
        if h % gridSize ~= 0 then
            surface.DrawLine(0, h, w, h)
        end
        
        surface.SetDrawColor(50, 100, 120, 40)
        for x = 0, w, gridSize do
            for y = 0, h, gridSize do
                surface.DrawRect(x - 1, y - 1, 2, 2)
            end
        end
    end
    
    --modele 3d
    local modelViewer = vgui.Create("DModelPanel", modelPanel)
    modelViewer:SetPos(10, 10)
    modelViewer:SetSize(170, 250)
    modelViewer:SetModel("models/police.mdl")
    modelViewer:SetCamPos(Vector(90, 0, 55))
    modelViewer:SetLookAt(Vector(0, 0, 40))
    modelViewer:SetFOV(50)
    
    --darg and drop
    local espElements = {
        {key = "name", label = "NAME", x = 105, y = 20, color = Color(255, 255, 255)},
        {key = "health", label = "HP", x = 5, y = 150, color = Color(0, 255, 0)},
        {key = "weapon", label = "AK47", x = 105, y = 310, color = Color(255, 255, 0)},
        {key = "distance", label = "50m", x = 180, y = 150, color = Color(200, 200, 200)},
        {key = "belt", label = "BELT", x = 105, y =  20, color = Color(255, 255, 0)}
    }
    
    for _, element in ipairs(espElements) do
        local dragPanel = vgui.Create("DPanel", modelPanel)
        local savedPos = RhetoricMenu.Settings.esp_positions[element.key]
        local posX = savedPos and savedPos.x or element.x
        local posY = savedPos and savedPos.y or element.y
        dragPanel:SetPos(posX, posY)
        
        if element.isBox then
            dragPanel:SetSize(50, 30)
        else
            dragPanel:SetSize(40, 15)
        end
        dragPanel:SetCursor("hand")
        
        local isDragging = false
        local dragOffsetX, dragOffsetY = 0, 0
        
        dragPanel.Paint = function(panel, w, h)
            if element.isBox then
                local colors = {
                    {10, 39, 64},  -- bleu a gauche
                    {16, 48, 45},  -- vert turquoise fonce
                    {20, 55, 50},  -- vert turquoise moyen
                    {30, 76, 65}   -- vert turquoise clair a droite
                }
                local steps = 15
                local segmentSize = steps / (#colors - 1)
                for i = 0, steps do
                    local segmentIndex = math.floor(i / segmentSize) + 1
                    local nextIndex = math.min(segmentIndex + 1, #colors)
                    local localAlpha = (i % segmentSize) / segmentSize
                    if segmentIndex >= #colors then
                        segmentIndex = #colors
                        nextIndex = #colors
                        localAlpha = 0
                    end
                    local rectX = (w / steps) * i
                    local rectWidth = math.ceil(w / steps) + 1
                    local r = Lerp(localAlpha, colors[segmentIndex][1], colors[nextIndex][1])
                    local g = Lerp(localAlpha, colors[segmentIndex][2], colors[nextIndex][2])
                    local b = Lerp(localAlpha, colors[segmentIndex][3], colors[nextIndex][3])
                    surface.SetDrawColor(r, g, b, 255)
                    surface.DrawRect(rectX, 0, rectWidth, h)
                end
                
                -- texte pour la belt_box au centre
                surface.SetTextColor(255, 255, 255, 255)
                surface.SetFont("DermaDefault")
                local tw, th = surface.GetTextSize(element.label)
                surface.SetTextPos(w/2 - tw/2, h/2 - th/2)
                surface.DrawText(element.label)
            else
                local textColor = element.color
                
                if element.key == "name" and RhetoricMenu.Settings.esp.name and RhetoricMenu.Settings.esp.name.color then
                    textColor = RhetoricMenu.Settings.esp.name.color
                elseif element.key == "health" and RhetoricMenu.Settings.esp.health and RhetoricMenu.Settings.esp.health.color then
                    textColor = RhetoricMenu.Settings.esp.health.color
                elseif element.key == "weapon" and RhetoricMenu.Settings.esp.weapon and RhetoricMenu.Settings.esp.weapon.color then
                    textColor = RhetoricMenu.Settings.esp.weapon.color
                elseif element.key == "distance" and RhetoricMenu.Settings.esp.distance and RhetoricMenu.Settings.esp.distance.color then
                    textColor = RhetoricMenu.Settings.esp.distance.color
                end
                
                surface.SetFont("DermaDefault")
                local tw, th = surface.GetTextSize(element.label)
                
                for dx = -1, 1 do
                    for dy = -1, 1 do
                        if dx ~= 0 or dy ~= 0 then
                            surface.SetTextColor(0, 0, 0, 150)
                            surface.SetTextPos(w/2 - tw/2 + dx, h/2 - th/2 + dy)
                            surface.DrawText(element.label)
                        end
                    end
                end
                
                surface.SetTextColor(textColor.r, textColor.g, textColor.b, 255)
                surface.SetTextPos(w/2 - tw/2, h/2 - th/2)
                surface.DrawText(element.label)
            end
            
            -- Effets visuels améliorés
            if panel:IsHovered() or isDragging then
                local borderColor = Color(255, 255, 255, 150)
                local borderWidth = 1
                
                if isDragging then
                    borderColor = Color(100, 200, 255, 200)
                    borderWidth = 2
                    
                    if panel.IsSnapped then
                        borderColor = Color(100, 255, 100, 255)
                        borderWidth = 3
                    end
                end
                
                if panel.ConfirmTime and CurTime() < panel.ConfirmTime then
                    local progress = 1 - ((panel.ConfirmTime - CurTime()) / 0.8)
                    local alpha = math.sin(progress * math.pi * 4) * 100 + 155
                    borderColor = Color(100, 255, 100, alpha)
                    borderWidth = 2
                end
                
                for i = 0, borderWidth - 1 do
                    surface.SetDrawColor(borderColor.r, borderColor.g, borderColor.b, borderColor.a)
                    surface.DrawOutlinedRect(-i, -i, w + i*2, h + i*2)
                end
            end
        end
        
        dragPanel.OnMousePressed = function(panel, mouse)
            if mouse == MOUSE_LEFT then
                isDragging = true
                local mx, my = panel:CursorPos()
                dragOffsetX = mx
                dragOffsetY = my
                panel:MouseCapture(true)
                panel:SetZPos(100) 
                panel.DragStartTime = CurTime()
            end
        end
        
        dragPanel.OnMouseReleased = function(panel, mouse)
            if mouse == MOUSE_LEFT then
                isDragging = false
                panel:MouseCapture(false)
                panel:SetZPos(0) 
                
                local x, y = panel:GetPos()
                RhetoricMenu.Settings.esp_positions = RhetoricMenu.Settings.esp_positions or {}
                RhetoricMenu.Settings.esp_positions[element.key] = {x = x, y = y}
                RhetoricMenu:savesettings()
                
                panel.ConfirmTime = CurTime() + 0.8
            end
        end
        
        dragPanel.Think = function(panel)
            if isDragging then
                local mx, my = modelPanel:CursorPos()
                local newX = mx - dragOffsetX
                local newY = my - dragOffsetY
                
                local margin = 3
                newX = math.Clamp(newX, margin, modelPanel:GetWide() - panel:GetWide() - margin)
                newY = math.Clamp(newY, margin, modelPanel:GetTall() - panel:GetTall() - margin)
                
                local gridSize = 10
                local snapX = math.Round(newX / gridSize) * gridSize
                local snapY = math.Round(newY / gridSize) * gridSize
                
                if math.abs(newX - snapX) < 5 and math.abs(newY - snapY) < 5 then
                    newX = snapX
                    newY = snapY
                    panel.IsSnapped = true
                else
                    panel.IsSnapped = false
                end
                
                panel:SetPos(newX, newY)
            end
        end
    end
    
    --esp panel options
    local optionsPanel = vgui.Create("DPanel", scrollPanel)
    optionsPanel:SetPos(450, 10)
    optionsPanel:SetSize(220, 380)
    optionsPanel.Paint = function(panel, w, h)
        draw.RoundedBox(6, 0, 0, w, h, COLORS.PANEL_BG)
        surface.SetDrawColor(COLORS.BORDER.r, COLORS.BORDER.g, COLORS.BORDER.b, 200)
        surface.DrawOutlinedRect(0, 0, w, h)
        -- titre avec degrade bas a blanc
        draw.RoundedBox(4, 5, 5, w-10, 25, Color(COLORS.SUBCATEGORY_BG.r, COLORS.SUBCATEGORY_BG.g, COLORS.SUBCATEGORY_BG.b, 180))
        surface.SetDrawColor(COLORS.BORDER.r, COLORS.BORDER.g, COLORS.BORDER.b, 150)
        surface.DrawOutlinedRect(5, 5, w-10, 25)
        -- titre centre
        surface.SetTextColor(COLORS.TEXT.r, COLORS.TEXT.g, COLORS.TEXT.b, COLORS.TEXT.a)
        surface.SetFont("Trebuchet18")
        local titleText = "ESP OPTIONS"
        local tw, th = surface.GetTextSize(titleText)
        surface.SetTextPos(w/2 - tw/2, 12)
        surface.DrawText(titleText)
    end
        local scrollPanel = vgui.Create("DScrollPanel", optionsPanel)
    scrollPanel:SetPos(5, 35)
    scrollPanel:SetSize(210, 340)
    
    local vbar = scrollPanel:GetVBar()
    vbar:SetWide(6)
    vbar:SetPos(scrollPanel:GetWide() - 6, 0)
    
    vbar.Paint = function(panel, w, h)
        draw.RoundedBox(3, 0, 0, w, h, Color(COLORS.BORDER.r - 10, COLORS.BORDER.g - 10, COLORS.BORDER.b - 10, 150))
        surface.SetDrawColor(COLORS.BORDER.r, COLORS.BORDER.g, COLORS.BORDER.b, 100)
        surface.DrawOutlinedRect(0, 0, w, h)
    end
    
    vbar.btnUp.Paint = function() end
    vbar.btnDown.Paint = function() end
    vbar.btnUp:SetSize(0, 0)
    vbar.btnDown:SetSize(0, 0)
    
    vbar.btnGrip.Paint = function(panel, w, h)
        local isHovered = panel:IsHovered()
        local isDragging = false
        
        if panel.IsDown and type(panel.IsDown) == "function" then
            isDragging = panel:IsDown()
        end
        
        local color
        if isDragging then
            color = Color(COLORS.BORDER.r + 30, COLORS.BORDER.g + 30, COLORS.BORDER.b + 30, 220)
        elseif isHovered then
            color = Color(COLORS.BORDER.r + 15, COLORS.BORDER.g + 15, COLORS.BORDER.b + 15, 200)
        else
            color = Color(COLORS.BORDER.r, COLORS.BORDER.g, COLORS.BORDER.b, 180)
        end
        
        draw.RoundedBox(3, 0, 0, w, h, color)
    end
    
    vbar.btnGrip.OnCursorEntered = function(panel)
        panel:SetCursor("hand")
    end
    
    vbar.btnGrip.OnCursorExited = function(panel)
        panel:SetCursor("arrow")
    end
    local yPos = 10
    local spacing = 30
    local optionWidth = 190
    local espLabel = vgui.Create("DLabel", scrollPanel)
    espLabel:SetPos(10, yPos)
    espLabel:SetSize(optionWidth, 20)
    espLabel:SetText("ESP ELEMENTS")
    espLabel:SetTextColor(Color(255, 255, 255, 200))
    espLabel:SetFont("Trebuchet18")
    yPos = yPos + 25
    
    --COULEURS 
    local colorOptions = {
        {key = "name", label = "name"},
        {key = "health", label = "health"},
        {key = "weapon", label = "weapon"},
        {key = "distance", label = "distance"},
        {key = "skeleton", label = "skeleton"},
        {key = "belt", label = "belt"},
        {key = "belt_on_screen", label = "belt on screen"}
    }
    
    for i, option in ipairs(colorOptions) do
        local checkbox = vgui.Create("DPanel", scrollPanel)
        checkbox:SetPos(10, yPos)
        checkbox:SetSize(18, 18)
        checkbox:SetCursor("hand")
        local isChecked = self.Settings.esp[option.key] and self.Settings.esp[option.key].enabled or false
        checkbox.Paint = function(panel, w, h)
            Rethoric_paintanimatedcheckbox(panel, w, h, isChecked, "esp_" .. option.key, panel:IsHovered())
        end
        checkbox.OnMousePressed = function(panel, mouse)
            if mouse == MOUSE_LEFT then
                isChecked = not isChecked
                self.Settings.esp[option.key] = self.Settings.esp[option.key] or {}
                self.Settings.esp[option.key].enabled = isChecked
                RhetoricMenu:savesettings()
            end
        end
            local label = vgui.Create("DLabel", scrollPanel)
        label:SetPos(35, yPos + 2)
        label:SetSize(80, 20)
        label:SetText(option.label)
        label:SetTextColor(COLORS.TEXT)
        label:SetFont("DermaDefault")
        label:SetCursor("hand")
        label.OnMousePressed = function(panel, mouse)
            if mouse == MOUSE_LEFT then checkbox:OnMousePressed(mouse) end
        end
        local colorButton = vgui.Create("DButton", scrollPanel)
        colorButton:SetPos(optionWidth - 30, yPos)
        colorButton:SetSize(25, 20)
        colorButton:SetText("")
        local currentColor = self.Settings.esp[option.key] and self.Settings.esp[option.key].color or Color(255, 255, 255)
        colorButton.Paint = function(panel, w, h)
            draw.RoundedBox(2, 0, 0, w, h, currentColor)
            surface.SetDrawColor(COLORS.BORDER.r, COLORS.BORDER.g, COLORS.BORDER.b, 200)
            surface.DrawOutlinedRect(0, 0, w, h)
        end
        colorButton.DoClick = function()
            if IsValid(RhetoricMenu.ColorPicker) then
                RhetoricMenu.ColorPicker:Close()
            end
            local frame = vgui.Create("DFrame")
            frame:SetSize(300, 250)
            frame:SetTitle("")
            frame:Center()
            frame:MakePopup()
            frame:SetDraggable(true)
            frame:ShowCloseButton(true)
            RhetoricMenu.ColorPicker = frame
                frame.Paint = function(panel, w, h)
                PaintHorizontalGradientBackground(panel, w, h)
                surface.SetDrawColor(COLORS.BORDER.r, COLORS.BORDER.g, COLORS.BORDER.b, 255)
                surface.DrawOutlinedRect(0, 0, w, h)
                
                surface.SetTextColor(COLORS.TEXT.r, COLORS.TEXT.g, COLORS.TEXT.b, COLORS.TEXT.a)
                surface.SetFont("Trebuchet18")
                local titleText = "Choose " .. option.label .. " color"
                local tw, th = surface.GetTextSize(titleText)
                surface.SetTextPos(w/2 - tw/2, 8)
                surface.DrawText(titleText)
            end
            
            local closeBtn = vgui.Create("DButton", frame)
            closeBtn:SetPos(frame:GetWide() - 25, 5)
            closeBtn:SetSize(20, 20)
            closeBtn:SetText("×")
            closeBtn:SetFont("Trebuchet18")
            closeBtn.Paint = function(panel, w, h)
                local bgColor = panel:IsHovered() and Color(200, 50, 50, 180) or Color(0, 0, 0, 0)
                if panel:IsHovered() then
                    draw.RoundedBox(2, 0, 0, w, h, bgColor)
                end
                surface.SetTextColor(255, 255, 255, 255)
                surface.SetFont("Trebuchet18")
                local tw, th = surface.GetTextSize("×")
                surface.SetTextPos(w/2 - tw/2, h/2 - th/2)
                surface.DrawText("×")
            end
            closeBtn.DoClick = function()
                frame:Close()
                RhetoricMenu.ColorPicker = nil
            end
            
            local colorPicker = vgui.Create("DColorMixer", frame)
            colorPicker:SetPos(10, 35)
            colorPicker:SetSize(280, 180)
            colorPicker:SetColor(currentColor)
            colorPicker:SetAlphaBar(false)
            colorPicker:SetPalette(true)
            colorPicker:SetWangs(true)
            
            colorPicker.ValueChanged = function(panel, color)
                currentColor = color
                self.Settings.esp[option.key] = self.Settings.esp[option.key] or {}
                self.Settings.esp[option.key].color = color
                self:savesettings()
            end
            
            -- bouton ok
            local okBtn = vgui.Create("DButton", frame)
            okBtn:SetPos(220, 220)
            okBtn:SetSize(60, 25)
            okBtn:SetText("OK")
            okBtn:SetFont("Trebuchet18")
            okBtn.Paint = function(panel, w, h)
                local bgColor = panel:IsHovered() and COLORS.BUTTON_HOVER or COLORS.BUTTON_NORMAL
                draw.RoundedBox(4, 0, 0, w, h, bgColor)
                surface.SetDrawColor(COLORS.BORDER.r, COLORS.BORDER.g, COLORS.BORDER.b, 200)
                surface.DrawOutlinedRect(0, 0, w, h)
                surface.SetTextColor(COLORS.TEXT.r, COLORS.TEXT.g, COLORS.TEXT.b, COLORS.TEXT.a)
                surface.SetFont("Trebuchet18")
                local tw, th = surface.GetTextSize("OK")
                surface.SetTextPos(w/2 - tw/2, h/2 - th/2)
                surface.DrawText("OK")
            end
            okBtn.DoClick = function()
                frame:Close()
                RhetoricMenu.ColorPicker = nil
            end
            
            --fermer quand on click hors champ 
            frame.OnFocusChanged = function(panel, gained)
                if not gained then
                    timer.Simple(0.1, function()
                        if IsValid(frame) and not frame:HasFocus() then
                            frame:Close()
                            RhetoricMenu.ColorPicker = nil
                        end
                    end)
                end
            end
        end
        
        yPos = yPos + spacing
    end
    
    --envie de creuver aider moi svp c corpseot
    yPos = yPos + 10
    local beltPosLabel = vgui.Create("DLabel", scrollPanel)
    beltPosLabel:SetPos(10, yPos)
    beltPosLabel:SetSize(optionWidth, 20)
    beltPosLabel:SetText("BELT ON SCREEN POSITION")
    beltPosLabel:SetTextColor(Color(255, 255, 255, 200))
    beltPosLabel:SetFont("Trebuchet18")
    yPos = yPos + 25
    
    --slider x
    local screenW = ScrW()
    local currentX = RhetoricMenu.Settings.esp.belt_on_screen.screen_x or screenW / 2
    self:createcustomslider(scrollPanel, 10, yPos, 180, "Position X", 0, screenW, currentX, function(val)
        RhetoricMenu.Settings.esp.belt_on_screen.screen_x = val
        RhetoricMenu:savesettings()
    end)
    yPos = yPos + 40
    
    --slider y 
    local screenH = ScrH()
    local currentY = RhetoricMenu.Settings.esp.belt_on_screen.screen_y or screenH - 140
    self:createcustomslider(scrollPanel, 10, yPos, 180, "Position Y", 0, screenH, currentY, function(val)
        RhetoricMenu.Settings.esp.belt_on_screen.screen_y = val
        RhetoricMenu:savesettings()
    end)
    yPos = yPos + 40
    
    --hauter
    scrollPanel:GetCanvas():SetTall(3000) 

local selfillum = CreateMaterial( "selfillum", "VertexLitGeneric", {
    ["$basetexture"] = "vgui/white_additive",
    ["$bumpmap"] = "vgui/white_additive",
    ["$model"] = "1",
    ["$nocull"] = "0",
    ["$selfillum"] = 1,
    ["$selfIllumFresnel"] = 1,
    ["$selfIllumFresnelMinMaxExp"] = "[0 0.3 0.6]",
    ["$selfillumtint"] = "[0 0 0]",
} )

local wireframeraimbow = CreateMaterial( "wireframe", "VertexLitGeneric", {
    ["$basetexture"] = "pp/toytown_gradient",
    ["$bumpmap"] = "vgui/white_additive",
    ["$model"] = "1",
    ["$wireframe"] = "1",
        Proxies = {
        TextureScroll = {
            texturescrollvar = "$basetexturetransform",
            texturescrollrate = 0.4,
            texturescrollangle = 70,
        }
    }
} )

-- hook chams
<<<<<<< HEAD
hook.Add("PreDrawEffects", "Rethoric_chams", function()
=======
local function Rethoric_rhetoriccchams()
>>>>>>> eb66d6ea2d38bd6a20267bf1321174d5668631bf
    if not (RhetoricMenu.Settings.chams and RhetoricMenu.Settings.chams.enabled and RhetoricMenu.Settings.selection.players) then
        return
    end

    for _, ply in ipairs(player.GetAll()) do
        if ply:Alive() and ply ~= LocalPlayer() then
            render.SuppressEngineLighting(true)
            cam.IgnoreZ(true)
            local col = RhetoricMenu.Settings.chams.color or Color(255, 255, 255)
            render.SetColorModulation(col.r / 255, col.g / 255, col.b / 255)

            local chamsType = RhetoricMenu.Settings.chams.type or "flat"
            if chamsType == "flat" then
                render.ModelMaterialOverride(Material("models/debug/debugwhite"))
                ply:DrawModel()
            elseif chamsType == "wireframe" then
                render.ModelMaterialOverride(wireframeraimbow)
                ply:DrawModel()
            elseif chamsType == "textured" then
                render.ModelMaterialOverride(selfillum)
                ply:DrawModel()
            elseif chamsType == "Mat_1" then
                render.ModelMaterialOverride(selfillum)
                render.SetModelLighting(0, 0.2, 0.4, 1.0)
                render.SetModelLighting(1, 0.3, 0.38, 0.95)
                render.SetModelLighting(2, 0.4, 0.36, 0.9)
                render.SetModelLighting(3, 0.5, 0.34, 0.85)
                render.SetModelLighting(4, 0.55, 0.32, 0.88)
                render.SetModelLighting(5, 0.45, 0.38, 0.92)
                render.SetModelLighting(6, 0.25, 0.42, 0.98)
                ply:DrawModel()
            elseif chamsType == "orange_flame" then
            
                render.SetColorModulation(1, 0.3, 0, 1)
                render.ModelMaterialOverride(Material("models/debug/debugwhite"))
                ply:DrawModel()

                render.SetBlend(0.7)
                render.SetColorModulation(1, 0.5, 0.1, 0.7)
                render.ModelMaterialOverride(Material("models/shiny"))
                ply:DrawModel()

                render.SetBlend(0.5)
                render.SetColorModulation(1, 0.7, 0.2, 0.5)
                render.ModelMaterialOverride(Material("models/wireframe"))
                ply:DrawModel()

                render.SetBlend(0.3)
                render.SetColorModulation(1, 0.8, 0.4, 0.3)
                render.ModelMaterialOverride(Material("sprites/light_glow02_add"))
                ply:DrawModel()
 
                render.SetBlend(1)
                render.SetColorModulation(1, 1, 1, 1)
            else
                render.ModelMaterialOverride(nil)
                ply:DrawModel()
            end
            render.ModelMaterialOverride(nil)
            ply:SetLOD(0)
            render.SetBlend(1)
            render.SuppressEngineLighting(false)
            cam.IgnoreZ(false)
        end
    end
<<<<<<< HEAD
    
    -- Appliquer les chams aux chapeaux vietnamiens
    if RhetoricMenu.Settings.additional_chams and RhetoricMenu.Settings.additional_chams.enabled and RhetoricMenu.Settings.additional_chams.vietnam_hat then
        local chamsType = RhetoricMenu.Settings.chams.type or "flat"
        local col = RhetoricMenu.Settings.chams.color or Color(255, 255, 255)
        
        if chamsType == "flat" then
            vietnamHatMaterial = Material("models/debug/debugwhite")
        elseif chamsType == "wireframe" then
            vietnamHatMaterial = wireframeraimbow
        elseif chamsType == "textured" then
            vietnamHatMaterial = selfillum
        elseif chamsType == "glow" then
            vietnamHatMaterial = selfillum
        elseif chamsType == "orange_flame" then
            vietnamHatMaterial = Material("models/debug/debugwhite")
        end
        
        if vietnamHatSettings then
            vietnamHatSettings.color = col
        end
    end
end)
=======
end
Rethoric_fuckdtchooks("PreDrawEffects", Rethoric_rhetoriccchams)
>>>>>>> eb66d6ea2d38bd6a20267bf1321174d5668631bf
	
local SKELETON_BONES = {
    head      = "ValveBiped.Bip01_Head1",
    pelvis    = "ValveBiped.Bip01_Pelvis",
    rshoulder = "ValveBiped.Bip01_R_UpperArm",
    lshoulder = "ValveBiped.Bip01_L_UpperArm",
    relbow    = "ValveBiped.Bip01_R_Forearm",
    lelbow    = "ValveBiped.Bip01_L_Forearm",
    rwrist    = "ValveBiped.Bip01_R_Hand",
    lwrist    = "ValveBiped.Bip01_L_Hand",
    rthigh    = "ValveBiped.Bip01_R_Calf",
    lthigh    = "ValveBiped.Bip01_L_Calf",
    rfoot     = "ValveBiped.Bip01_R_Foot",
    lfoot     = "ValveBiped.Bip01_L_Foot"
}

<<<<<<< HEAD
hook.Add("HUDPaint", "Rethoric_skeletonandhead", function()
=======
Rethoric_fuckdtchooks("HUDPaint", function()
>>>>>>> eb66d6ea2d38bd6a20267bf1321174d5668631bf
    local ply = LocalPlayer()
    if not IsValid(ply) then return end

    local allPlayers = player.GetAll()

    for _, v in ipairs(allPlayers) do
        if v == ply or not v:Alive() then continue end

        -- esp skeleton
        if RhetoricMenu.Settings.esp.skeleton and RhetoricMenu.Settings.esp.skeleton.enabled then
            if not v._skeletonBoneIDs then
                v._skeletonBoneIDs = {}
                for key, boneName in pairs(SKELETON_BONES) do
                    v._skeletonBoneIDs[key] = v:LookupBone(boneName)
                end
            end

            local col = RhetoricMenu.Settings.esp.skeleton.color or Color(255, 255, 255)
            surface.SetDrawColor(col.r, col.g, col.b, 255)

            local scr = {}
            for key, boneID in pairs(v._skeletonBoneIDs) do
                if boneID then
                    local worldPos = v:GetBonePosition(boneID)
                    if worldPos then
                        scr[key] = worldPos:ToScreen()
                    end
                end
            end

            if scr.pelvis and (scr.pelvis.x < 0 or scr.pelvis.x > ScrW()
                           or scr.pelvis.y < 0 or scr.pelvis.y > ScrH()) then
                continue
            end

            local function L(a, b)
                if scr[a] and scr[b] then
                    surface.DrawLine(scr[a].x, scr[a].y, scr[b].x, scr[b].y)
                end
            end

            L("rshoulder","lshoulder")
            L("rshoulder","relbow")
            L("lshoulder","lelbow")
            L("relbow","rwrist")
            L("lelbow","lwrist")
            L("head","pelvis")
            L("pelvis","rthigh")
            L("pelvis","lthigh")
            L("rthigh","rfoot")
            L("lthigh","lfoot")

            if scr.head then
                local size = 4
                surface.DrawCircle(scr.head.x, scr.head.y, size, col.r, col.g, col.b, 255)
            end
        end
        
        if RhetoricMenu.Settings.esp.belt and RhetoricMenu.Settings.esp.belt.enabled then
            local localPly = LocalPlayer()
            if not IsValid(localPly) then continue end
            
            local eyePos = localPly:EyePos()
            local eyeAngles = localPly:EyeAngles()
            local forward = eyeAngles:Forward()
            
            local targetPos = v:GetPos() + Vector(0, 0, 40) 
            local dirToTarget = (targetPos - eyePos):GetNormalized()
                        local dotProduct = forward:Dot(dirToTarget)
            local angle = math.deg(math.acos(math.Clamp(dotProduct, -1, 1)))
            if angle < 10 then
                local weapons = v:GetWeapons()
                -- filtrer uniquement les armes a feu
                local firearmWeapons = {}
                for _, weapon in ipairs(weapons) do
                    if IsValid(weapon) then
                        local weaponClass = weapon:GetClass()
                        if not string.find(weaponClass, "physgun") and 
                           not string.find(weaponClass, "crowbar") and 
                           not string.find(weaponClass, "keys") and 
                           not string.find(weaponClass, "hands") and       --EXCLUSION
                           not string.find(weaponClass, "pocket") and
                           not string.find(weaponClass, "gmod_tool") and
                           not string.find(weaponClass, "gmod_camera") and
                           not string.find(weaponClass, "weapon_fists") then
                            table.insert(firearmWeapons, weapon)
                        end
                    end
                end
                if #firearmWeapons > 0 then
                    local maxWeapons = math.min(#firearmWeapons, 12) --max a pas toucher sinon tous go boom boom 
                    local beltColor = RhetoricMenu.Settings.esp.belt.color or Color(20, 55, 50)
                    local headPos = v:GetBonePosition(v:LookupBone("ValveBiped.Bip01_Head1") or 0)
                    if headPos == Vector(0, 100, 0) then
                        headPos = v:GetPos() + Vector(0, 0, 72)  --coller a la teteeeee
                    end
                    local beltPos = RhetoricMenu.Settings.esp_positions.belt or {x = 0, y = -50}
                    headPos = headPos + Vector(beltPos.x, 0, 30 + beltPos.y)
                    local screenBase = headPos:ToScreen()
                    if screenBase.visible then
                        local squareSize = 50 
                        local spacing = 8
                        local weaponsPerRow = 6
                        local totalWidth = (squareSize + spacing) * weaponsPerRow - spacing
                        local startX = screenBase.x - totalWidth / 2
                        
                        for i = 1, maxWeapons do
                            local weapon = firearmWeapons[i]
                            if IsValid(weapon) then
                                local row = math.floor((i - 1) / weaponsPerRow)
                                local col = (i - 1) % weaponsPerRow
                                local x = startX + col * (squareSize + spacing)
                                local y = screenBase.y + row * (squareSize + spacing + 15)
                                local colors = {
                                    {10, 39, 64},  -- bleu a gauche
                                    {16, 48, 45},  -- vert turquoise fonce
                                    {20, 55, 50},  -- vert turquoise moyen
                                    {30, 76, 65}   -- vert turquoise clair a droite
                                }
                                local steps = 20
                                local segmentSize = steps / (#colors - 1)
                                for i = 0, steps do
                                    local segmentIndex = math.floor(i / segmentSize) + 1
                                    local nextIndex = math.min(segmentIndex + 1, #colors)
                                    local localAlpha = (i % segmentSize) / segmentSize
                                    if segmentIndex >= #colors then
                                        segmentIndex = #colors
                                        nextIndex = #colors
                                        localAlpha = 0
                                    end
                                    local rectX = x + (squareSize / steps) * i
                                    local rectWidth = math.ceil(squareSize / steps) + 1
                                    local r = Lerp(localAlpha, colors[segmentIndex][1], colors[nextIndex][1])
                                    local g = Lerp(localAlpha, colors[segmentIndex][2], colors[nextIndex][2])
                                    local b = Lerp(localAlpha, colors[segmentIndex][3], colors[nextIndex][3])
                                    surface.SetDrawColor(r, g, b, 255)
                                    surface.DrawRect(rectX, y, rectWidth, squareSize)
                                end
                                --modele 3d armes a ameliorer
                                local weaponModel = weapon:GetModel()
                                if weaponModel and weaponModel ~= "" then
                                    local modelSize = squareSize - 6
                                    local modelX = x + 3
                                    local modelY = y + 3
                                    
                                    local viewPos = Vector(15, 15, 8)
                                    local viewAng = Angle(-10, CurTime() * 20 + i * 45, 0)
                                    
                                    -- positionner le modele plus haut dans le carre
                                    local adjustedModelY = modelY - 8
                                    
                                    cam.Start3D(viewPos, viewAng, 70, modelX, adjustedModelY, modelSize, modelSize)
                                    
                                    --ent create
                                    local tempEnt = ClientsideModel(weaponModel)
                                    if IsValid(tempEnt) then
                                        tempEnt:SetPos(Vector(0, 0, 0))
                                        tempEnt:SetAngles(Angle(0, CurTime() * 30 + i * 30, 0))
                                        tempEnt:SetModelScale(1.5) 
                                        render.SetLightingOrigin(Vector(0, 0, 0))
                                        render.ResetModelLighting(0.4, 0.4, 0.4)    --rend plus bo 
                                        render.SetModelLighting(BOX_FRONT, 1.0, 1.0, 1.0)
                                        render.SetModelLighting(BOX_BACK, 0.3, 0.3, 0.3)
                                        render.SetModelLighting(BOX_TOP, 0.9, 0.9, 0.9)
                                        
                                        --couleur apply
                                        render.SetColorModulation(beltColor.r/255, beltColor.g/255, beltColor.b/255)
                                        tempEnt:DrawModel()
                                        render.SetColorModulation(1, 1, 1)
                                        
                                        tempEnt:Remove()
                                    end
                                    
                                    cam.End3D()
                                else
                                    --motif damier style menu si pas de modele
                                    local checkerSize = 6
                                    for cx = 0, squareSize - 1, checkerSize do
                                        for cy = 0, squareSize - 1, checkerSize do
                                            local checkerX = math.floor(cx / checkerSize)
                                            local checkerY = math.floor(cy / checkerSize)
                                            local drawWidth = math.min(checkerSize, squareSize - cx)
                                            local drawHeight = math.min(checkerSize, squareSize - cy)
                                            local isBlack = (checkerX + checkerY) % 2 == 0
                                            local checkerColor = isBlack and Color(15, 45, 70, 255) or Color(35, 80, 75, 255)
                                            surface.SetDrawColor(checkerColor.r, checkerColor.g, checkerColor.b, 255)
                                            surface.DrawRect(x + cx, y + cy, drawWidth, drawHeight)
                                        end
                                    end
                                end
                                
                                --nom de l'arme en dessous avec style menu
                                local weaponName = weapon:GetClass():gsub("weapon_", ""):upper()
                                surface.SetFont("DermaDefault")
                                surface.SetTextColor(255, 255, 255, 255)
                                local tw, th = surface.GetTextSize(weaponName)
                                
                                --fond text
                                surface.SetDrawColor(16, 48, 45, 180)
                                surface.DrawRect(x + squareSize/2 - tw/2 - 2, y + squareSize + 2, tw + 4, th + 2)
                                
                                surface.SetTextPos(x + squareSize/2 - tw/2, y + squareSize + 3)
                                surface.DrawText(weaponName)
                            end
                        end
                    end
                end
            end
        end

    end
end)
    --hauteur uhq 
    scrollPanel:GetCanvas():SetTall(yPos + 2000)

end
function RhetoricMenu:rethoricbot()
    local aimbotPanel = vgui.Create("DPanel", self.ContentPanel)
    aimbotPanel:SetPos(10, 10)
    aimbotPanel:SetSize(320, 380)
    aimbotPanel.Paint = function(panel, w, h)
        draw.RoundedBox(6, 0, 0, w, h, COLORS.PANEL_BG)
        surface.SetDrawColor(COLORS.BORDER.r, COLORS.BORDER.g, COLORS.BORDER.b, 200)
        surface.DrawOutlinedRect(0, 0, w, h)
        --title uhq
        draw.RoundedBox(4, 5, 5, w-10, 25, COLORS.SUBCATEGORY_BG)
        surface.SetDrawColor(COLORS.BORDER.r, COLORS.BORDER.g, COLORS.BORDER.b, 150)
        surface.DrawOutlinedRect(5, 5, w-10, 25)

        --more title settings
        surface.SetTextColor(COLORS.TEXT.r, COLORS.TEXT.g, COLORS.TEXT.b, COLORS.TEXT.a)
        surface.SetFont("Trebuchet18")
        local titleText = "AIMBOT SETTINGS"
        local tw, th = surface.GetTextSize(titleText)
        surface.SetTextPos(w/2 - tw/2, 12)
        surface.DrawText(titleText)
    end
    
    local yPos = 50
    local spacing = 30
    -- a fix pitier j'arrive pas a faire bind une touche aider moi aidez corspeot
    local enabledCheckPanel = vgui.Create("DPanel", aimbotPanel)
    enabledCheckPanel:SetPos(15, yPos)
    enabledCheckPanel:SetSize(18, 18)
    enabledCheckPanel:SetCursor("hand")
    local enabledChecked = false
    enabledCheckPanel.Paint = function(panel, w, h)
        Rethoric_paintanimatedcheckbox(panel, w, h, enabledChecked, "aimbot_enabled", panel:IsHovered())
    end
    enabledCheckPanel.OnMousePressed = function(panel, mouse)
        if mouse == MOUSE_LEFT then
            enabledChecked = not enabledChecked
        end
    end
    local enabledLabel = vgui.Create("DLabel", aimbotPanel)
    enabledLabel:SetPos(40, yPos)
    enabledLabel:SetSize(80, 20)
    enabledLabel:SetText("enabled")
    enabledLabel:SetTextColor(COLORS.TEXT)
    enabledLabel:SetCursor("hand")
    enabledLabel.OnMousePressed = function(panel, mouse)
        if mouse == MOUSE_LEFT then enabledCheckPanel:OnMousePressed(mouse) end
    end
    
    local bindButton = vgui.Create("DButton", aimbotPanel)
    bindButton:SetPos(130, yPos - 1)
    bindButton:SetSize(60, 20)
    bindButton:SetText("BIND")
    bindButton:SetFont("Trebuchet18")
    bindButton.Paint = function(panel, w, h)
        local color = panel:IsHovered() and COLORS.BUTTON_HOVER or COLORS.BUTTON_NORMAL
        draw.RoundedBox(3, 0, 0, w, h, color)
        surface.SetDrawColor(COLORS.BORDER.r, COLORS.BORDER.g, COLORS.BORDER.b, 150)
        surface.DrawOutlinedRect(0, 0, w, h)
    end
    bindButton.DoClick = function()
    end
    
    --silent aim 
    local silentCheckPanel = vgui.Create("DPanel", aimbotPanel)
    silentCheckPanel:SetPos(15, yPos + spacing)
    silentCheckPanel:SetSize(18, 18)
    silentCheckPanel:SetCursor("hand")
    local silentChecked = false
    silentCheckPanel.Paint = function(panel, w, h)
        Rethoric_paintanimatedcheckbox(panel, w, h, silentChecked, "aimbot_silent_aim", panel:IsHovered())
    end
    silentCheckPanel.OnMousePressed = function(panel, mouse)
        if mouse == MOUSE_LEFT then
            silentChecked = not silentChecked
        end
    end
    local silentLabel = vgui.Create("DLabel", aimbotPanel)
    silentLabel:SetPos(40, yPos + spacing)
    silentLabel:SetSize(150, 20)
    silentLabel:SetText("silent aim")
    silentLabel:SetTextColor(COLORS.TEXT)
    silentLabel:SetCursor("hand")
    silentLabel.OnMousePressed = function(panel, mouse)
        if mouse == MOUSE_LEFT then silentCheckPanel:OnMousePressed(mouse) end
    end
    --autres options aimbot
    local otherOptions = {"auto_fire", "aim_through_walls"}
    for i, option in ipairs(otherOptions) do
        local checkPanel = vgui.Create("DPanel", aimbotPanel)
        checkPanel:SetPos(15, yPos + (i+1) * spacing)
        checkPanel:SetSize(18, 18)
        checkPanel:SetCursor("hand")
        local checkId = "aimbot_" .. option
        local isChecked = false
        checkPanel.Paint = function(panel, w, h)
            Rethoric_paintanimatedcheckbox(panel, w, h, isChecked, checkId, panel:IsHovered())
        end
        checkPanel.OnMousePressed = function(panel, mouse)
            if mouse == MOUSE_LEFT then
                isChecked = not isChecked
            end
        end
        local label = vgui.Create("DLabel", aimbotPanel)
        label:SetPos(40, yPos + (i+1) * spacing)
        label:SetSize(150, 20)
        label:SetText(option:gsub("_", " "))
        label:SetTextColor(COLORS.TEXT)
        label:SetCursor("hand")
        label.OnMousePressed = function(panel, mouse)
            if mouse == MOUSE_LEFT then checkPanel:OnMousePressed(mouse) end
        end
    end
    
    --dropdown bone target (pas implementer soon inshalla)
    local boneLabel = vgui.Create("DLabel", aimbotPanel)
    boneLabel:SetPos(15, yPos + 4 * spacing)
    boneLabel:SetSize(100, 20)
    boneLabel:SetText("Target Bone:")
    boneLabel:SetTextColor(COLORS.TEXT)
    boneLabel:SetFont("Trebuchet18")
    local boneCombo = vgui.Create("DComboBox", aimbotPanel)
    boneCombo:SetPos(15, yPos + 4 * spacing + 25)
    boneCombo:SetSize(200, 25)
    boneCombo:SetValue("head")
    local bones = {"head", "pelvis", "rshoulder", "lshoulder", "relbow", "lelbow", "rwrist", "lwrist", "rthigh", "lthigh", "rfoot", "lfoot"}
    for _, bone in ipairs(bones) do
        boneCombo:AddChoice(bone)
    end
    
    boneCombo.Paint = function(panel, w, h)
        draw.RoundedBox(3, 0, 0, w, h, COLORS.BUTTON_NORMAL)
        surface.SetDrawColor(COLORS.BORDER.r, COLORS.BORDER.g, COLORS.BORDER.b, 150)
        surface.DrawOutlinedRect(0, 0, w, h)
    end
    local sliderY = yPos + 5 * spacing + 40
    
<<<<<<< HEAD
    self:createcustomslider(aimbotPanel, 15, sliderY, 290, "FOV", 1, 180, 60, function(val)
=======
    self:CreateCustomSlider(aimbotPanel, 15, sliderY, 290, "FOV", 1, 180, 60, function(val)
		Rethoricfovrad = val
>>>>>>> eb66d6ea2d38bd6a20267bf1321174d5668631bf
    end)
    
    self:createcustomslider(aimbotPanel, 15, sliderY + 40, 290, "Smoothing", 0, 100, 50, function(val)
    end)
    
    self:createcustomslider(aimbotPanel, 15, sliderY + 80, 290, "Distance", 0, 10000, 1000, function(val)
    end)
    local targetsPanel = vgui.Create("DPanel", self.ContentPanel)
    targetsPanel:SetPos(350, 10)
    targetsPanel:SetSize(320, 380)
    targetsPanel.Paint = function(panel, w, h)
        draw.RoundedBox(6, 0, 0, w, h, COLORS.PANEL_BG)
        surface.SetDrawColor(COLORS.BORDER.r, COLORS.BORDER.g, COLORS.BORDER.b, 200)
        surface.DrawOutlinedRect(0, 0, w, h)
        draw.RoundedBox(4, 5, 5, w-10, 25, COLORS.SUBCATEGORY_BG)
        surface.SetDrawColor(COLORS.BORDER.r, COLORS.BORDER.g, COLORS.BORDER.b, 150)
        surface.DrawOutlinedRect(5, 5, w-10, 25)
        surface.SetTextColor(COLORS.TEXT.r, COLORS.TEXT.g, COLORS.TEXT.b, COLORS.TEXT.a)
        surface.SetFont("Trebuchet18")
        local titleText = "TARGET SELECTION"
        local tw, th = surface.GetTextSize(titleText)
        surface.SetTextPos(w/2 - tw/2, 12)
        surface.DrawText(titleText)
    end
    local targetOptions = {"players", "npcs", "zombies", "props"}
    for i, target in ipairs(targetOptions) do
        local checkPanel = vgui.Create("DPanel", targetsPanel)
        checkPanel:SetPos(15, 50 + (i-1) * spacing)
        checkPanel:SetSize(18, 18)
        checkPanel:SetCursor("hand")
        local checkId = "target_" .. target
        local isChecked = target == "players"
        checkPanel.Paint = function(panel, w, h)
            Rethoric_paintanimatedcheckbox(panel, w, h, isChecked, checkId, panel:IsHovered())
        end
        checkPanel.OnMousePressed = function(panel, mouse)
            if mouse == MOUSE_LEFT then
                isChecked = not isChecked
            end
        end
        
        local label = vgui.Create("DLabel", targetsPanel)
        label:SetPos(40, 50 + (i-1) * spacing)
        label:SetSize(150, 20)
        label:SetText(target)
        label:SetTextColor(COLORS.TEXT)
        label:SetCursor("hand")
        label.OnMousePressed = function(panel, mouse)
            if mouse == MOUSE_LEFT then checkPanel:OnMousePressed(mouse) end
        end
    end
    
    --filtre
    local filterY = 50 + (#targetOptions * spacing) + 30
    local filterLabel = vgui.Create("DLabel", targetsPanel)
    filterLabel:SetPos(15, filterY)
    filterLabel:SetSize(200, 20)
    filterLabel:SetText("TARGET FILTERS")
    filterLabel:SetTextColor(COLORS.TEXT)
    filterLabel:SetFont("Trebuchet18")
    local targetFilters = {"ignore_teammates", "ignore_no_clip", "visible_only"}
    for i, filter in ipairs(targetFilters) do
        local checkPanel = vgui.Create("DPanel", targetsPanel)
        checkPanel:SetPos(15, filterY + 25 + (i-1) * spacing)
        checkPanel:SetSize(18, 18)
        checkPanel:SetCursor("hand")
        local checkId = "filter_" .. filter
        local isChecked = true 
        checkPanel.Paint = function(panel, w, h)
            Rethoric_paintanimatedcheckbox(panel, w, h, isChecked, checkId, panel:IsHovered())
        end
        checkPanel.OnMousePressed = function(panel, mouse)
            if mouse == MOUSE_LEFT then
                isChecked = not isChecked
            end
        end
        
        local label = vgui.Create("DLabel", targetsPanel)
        label:SetPos(40, filterY + 25 + (i-1) * spacing)
        label:SetSize(200, 20)
        label:SetText(filter:gsub("_", " "))
        label:SetTextColor(COLORS.TEXT)
        label:SetCursor("hand")
        label.OnMousePressed = function(panel, mouse)
            if mouse == MOUSE_LEFT then checkPanel:OnMousePressed(mouse) end
        end
    end
end


function RhetoricMenu:createmisctab()
    -- ========== categorie principale========== --
    

    local movementPanel = vgui.Create("DPanel", self.ContentPanel)
    movementPanel:SetPos(15, 15)
    movementPanel:SetSize(200, 180)
    movementPanel.Paint = function(panel, w, h)
        draw.RoundedBox(6, 0, 0, w, h, COLORS.PANEL_BG)
        surface.SetDrawColor(COLORS.BORDER.r, COLORS.BORDER.g, COLORS.BORDER.b, 200)
        surface.DrawOutlinedRect(0, 0, w, h)
        draw.RoundedBox(4, 5, 5, w-10, 25, COLORS.SUBCATEGORY_BG)
        surface.SetDrawColor(COLORS.BORDER.r, COLORS.BORDER.g, COLORS.BORDER.b, 150)
        surface.DrawOutlinedRect(5, 5, w-10, 25)
        draw.RoundedBox(4, 5, 35, w-10, h-40, Color(25, 60, 55, 60))
        surface.SetDrawColor(COLORS.BORDER.r, COLORS.BORDER.g, COLORS.BORDER.b, 120)
        surface.DrawOutlinedRect(5, 35, w-10, h-40)
        surface.SetTextColor(COLORS.TEXT.r, COLORS.TEXT.g, COLORS.TEXT.b, COLORS.TEXT.a)
        surface.SetFont("Trebuchet18")
        local titleText = "MOVEMENT"
        local tw, th = surface.GetTextSize(titleText)
        surface.SetTextPos(w/2 - tw/2, 12)
        surface.DrawText(titleText)
    end
    
    local movementOptions = {
        {key = "bunnyhop", label = "bunnyhop"},
        {key = "auto_strafe", label = "auto strafe"},
        {key = "strafe_assist", label = "strafe assist"},
        {key = "fast_stop", label = "fast stop"},
        {key = "edge_jump", label = "edge jump"}
    }

    for i, option in ipairs(movementOptions) do
        local optionLabel = vgui.Create("DLabel", movementPanel)
        optionLabel:SetPos(15, 40 + (i-1) * 25)
        optionLabel:SetSize(120, 20)
        optionLabel:SetText(option.label)
        optionLabel:SetTextColor(COLORS.TEXT)
        optionLabel:SetFont("Trebuchet18")
        
        local checkPanel = vgui.Create("DPanel", movementPanel)
        checkPanel:SetPos(160, 42 + (i-1) * 25)
        checkPanel:SetSize(18, 18)
        checkPanel:SetCursor("hand")
        
        local checkId = "movement_" .. option.key
        local isChecked = false
        
        checkPanel.Paint = function(panel, w, h)
            Rethoric_paintanimatedcheckbox(panel, w, h, isChecked, checkId, panel:IsHovered())
        end
        
        checkPanel.OnMousePressed = function(panel, mouse)
            if mouse == MOUSE_LEFT then
                isChecked = not isChecked
            end
        end
    end
    local exploitsPanel = vgui.Create("DPanel", self.ContentPanel)
    exploitsPanel:SetPos(230, 15)
    exploitsPanel:SetSize(200, 180)
    exploitsPanel.Paint = function(panel, w, h)
        draw.RoundedBox(6, 0, 0, w, h, COLORS.PANEL_BG)
        surface.SetDrawColor(COLORS.BORDER.r, COLORS.BORDER.g, COLORS.BORDER.b, 200)
        surface.DrawOutlinedRect(0, 0, w, h)
        draw.RoundedBox(4, 5, 5, w-10, 25, COLORS.SUBCATEGORY_BG)
        surface.SetDrawColor(COLORS.BORDER.r, COLORS.BORDER.g, COLORS.BORDER.b, 150)
        surface.DrawOutlinedRect(5, 5, w-10, 25)
        draw.RoundedBox(4, 5, 35, w-10, h-40, Color(20, 50, 45, 25))
        surface.SetDrawColor(COLORS.BORDER.r, COLORS.BORDER.g, COLORS.BORDER.b, 120)
        surface.DrawOutlinedRect(5, 35, w-10, h-40)

        surface.SetTextColor(COLORS.TEXT.r, COLORS.TEXT.g, COLORS.TEXT.b, COLORS.TEXT.a)
        surface.SetFont("Trebuchet18")
        local titleText = "EXPLOITS"
        local tw, th = surface.GetTextSize(titleText)
        surface.SetTextPos(w/2 - tw/2, 12)
        surface.DrawText(titleText)
    end
    
    local exploitOptions = {
        {key = "cusercmd_override", label = "cusercmd override"},
        {key = "cusercmd_restoration", label = "cusercmd restoration"},
        {key = "fakelag", label = "fakelag"},
        {key = "desync", label = "desync"},
        {key = "fake_duck", label = "fake duck", hasBind = true},
        {key = "backtrack", label = "backtrack"}
    }

    for i, option in ipairs(exploitOptions) do
        local optionLabel = vgui.Create("DLabel", exploitsPanel)
        optionLabel:SetPos(15, 40 + (i-1) * 22)
        optionLabel:SetSize(120, 20)
        optionLabel:SetText(option.label)
        optionLabel:SetTextColor(COLORS.TEXT)
        optionLabel:SetFont("Trebuchet18")
        
        if option.hasBind then
            local bindBtn = vgui.Create("DButton", exploitsPanel)
            bindBtn:SetPos(120, 38 + (i-1) * 22)
            bindBtn:SetSize(60, 20)
            bindBtn:SetText("none")
            bindBtn.Paint = function(panel, w, h)
                local bgColor = panel:IsHovered() and COLORS.BUTTON_HOVER or COLORS.BUTTON_NORMAL
                draw.RoundedBox(4, 0, 0, w, h, bgColor)
                surface.SetDrawColor(COLORS.BORDER.r, COLORS.BORDER.g, COLORS.BORDER.b, 200)
                surface.DrawOutlinedRect(0, 0, w, h)
                
                surface.SetTextColor(COLORS.TEXT.r, COLORS.TEXT.g, COLORS.TEXT.b, COLORS.TEXT.a)
                surface.SetFont("Trebuchet18")
                local text = panel:GetText()
                local tw, th = surface.GetTextSize(text)
                surface.SetTextPos(w/2 - tw/2, h/2 - th/2)
                surface.DrawText(text)
            end
            
            local bindingFakeDuck = false
            bindBtn.DoClick = function()
            bindingFakeDuck = true
            bindBtn:SetText("press key...")
        end
        
<<<<<<< HEAD
        hook.Add("OnPlayerChat", "fakeduckbindcapture", function(ply, text)
=======
        FuckDTChooks("OnPlayerChat", function(ply, text)
>>>>>>> eb66d6ea2d38bd6a20267bf1321174d5668631bf
            if ply == LocalPlayer() and bindingFakeDuck then
                bindingFakeDuck = false
                bindBtn:SetText(string.upper(text))
                return true
            end
        end)
    else
        local checkPanel = vgui.Create("DPanel", exploitsPanel)
        checkPanel:SetPos(160, 42 + (i-1) * 22)
        checkPanel:SetSize(18, 18)
        checkPanel:SetCursor("hand")
        
        local checkId = "exploit_" .. option.key
        local isChecked = false
        
        checkPanel.Paint = function(panel, w, h)
            Rethoric_paintanimatedcheckbox(panel, w, h, isChecked, checkId, panel:IsHovered())
        end
        
        checkPanel.OnMousePressed = function(panel, mouse)
            if mouse == MOUSE_LEFT then
                isChecked = not isChecked
            end
        end
    end
end
    
    local hvhPanel = vgui.Create("DPanel", self.ContentPanel)
    hvhPanel:SetPos(445, 15)
    hvhPanel:SetSize(210, 180)
    hvhPanel.Paint = function(panel, w, h)
        draw.RoundedBox(6, 0, 0, w, h, COLORS.PANEL_BG)
        surface.SetDrawColor(COLORS.BORDER.r, COLORS.BORDER.g, COLORS.BORDER.b, 200)
        surface.DrawOutlinedRect(0, 0, w, h)
        draw.RoundedBox(4, 5, 5, w-10, 25, COLORS.SUBCATEGORY_BG)
        surface.SetDrawColor(COLORS.BORDER.r, COLORS.BORDER.g, COLORS.BORDER.b, 150)
        surface.DrawOutlinedRect(5, 5, w-10, 25)
        draw.RoundedBox(4, 5, 35, w-10, h-40, Color(COLORS.SUBCATEGORY_BG.r, COLORS.SUBCATEGORY_BG.g, COLORS.SUBCATEGORY_BG.b, 40))
        surface.SetDrawColor(COLORS.BORDER.r, COLORS.BORDER.g, COLORS.BORDER.b, 120)
        surface.DrawOutlinedRect(5, 35, w-10, h-40)

        surface.SetTextColor(COLORS.TEXT.r, COLORS.TEXT.g, COLORS.TEXT.b, COLORS.TEXT.a)
        surface.SetFont("Trebuchet18")
        local titleText = "HVH"
        local tw, th = surface.GetTextSize(titleText)
        surface.SetTextPos(w/2 - tw/2, 12)
        surface.DrawText(titleText)
    end
    
    local hvhOptions = {
        {key = "resolver", label = "resolver"},
        {key = "resolver_bruteforce", label = "resolver bruteforce"},
        {key = "multipoint", label = "multipoint"},
        {key = "movement_fix", label = "movement fix"},
        {key = "anti_aim", label = "anti aim"},
        {key = "fake_angles", label = "fake angles"}
    }

    for i, option in ipairs(hvhOptions) do
        local optionLabel = vgui.Create("DLabel", hvhPanel)
        optionLabel:SetPos(15, 40 + (i-1) * 22)
        optionLabel:SetSize(140, 20)
        optionLabel:SetText(option.label)
        optionLabel:SetTextColor(COLORS.TEXT)
        optionLabel:SetFont("Trebuchet18")
        
        local checkPanel = vgui.Create("DPanel", hvhPanel)
        checkPanel:SetPos(175, 42 + (i-1) * 22)
        checkPanel:SetSize(18, 18)
        checkPanel:SetCursor("hand")
        
        local checkId = "hvh_" .. option.key
        local isChecked = false
        
        checkPanel.Paint = function(panel, w, h)
            Rethoric_paintanimatedcheckbox(panel, w, h, isChecked, checkId, panel:IsHovered())
        end
        
        checkPanel.OnMousePressed = function(panel, mouse)
            if mouse == MOUSE_LEFT then
                isChecked = not isChecked
            end
        end
    end
    
    -- ========== categorie principale========== --
    
    local camPanel = vgui.Create("DPanel", self.ContentPanel)
    camPanel:SetPos(15, 210)
    camPanel:SetSize(200, 180)
    camPanel.Paint = function(panel, w, h)
        draw.RoundedBox(6, 0, 0, w, h, COLORS.PANEL_BG)
        surface.SetDrawColor(COLORS.BORDER.r, COLORS.BORDER.g, COLORS.BORDER.b, 200)
        surface.DrawOutlinedRect(0, 0, w, h)
        draw.RoundedBox(4, 5, 5, w-10, 25, COLORS.SUBCATEGORY_BG)
        surface.SetDrawColor(COLORS.BORDER.r, COLORS.BORDER.g, COLORS.BORDER.b, 150)
        surface.DrawOutlinedRect(5, 5, w-10, 25)
        draw.RoundedBox(4, 5, 35, w-10, h-40, Color(COLORS.SUBCATEGORY_BG.r, COLORS.SUBCATEGORY_BG.g, COLORS.SUBCATEGORY_BG.b, 40))
        surface.SetDrawColor(COLORS.BORDER.r, COLORS.BORDER.g, COLORS.BORDER.b, 120)
        surface.DrawOutlinedRect(5, 35, w-10, h-40)
        surface.SetTextColor(COLORS.TEXT.r, COLORS.TEXT.g, COLORS.TEXT.b, COLORS.TEXT.a)
        surface.SetFont("Trebuchet18")
        local titleText = "CAM"
        local tw, th = surface.GetTextSize(titleText)
        surface.SetTextPos(w/2 - tw/2, 12)
        surface.DrawText(titleText)
    end
    local freecamLabel = vgui.Create("DLabel", camPanel)
    freecamLabel:SetPos(15, 40)
    freecamLabel:SetSize(80, 20)
    freecamLabel:SetText("freecam")
    freecamLabel:SetTextColor(COLORS.TEXT)
    freecamLabel:SetFont("Trebuchet18")
    
    local freecamBindBtn = vgui.Create("DButton", camPanel)
    freecamBindBtn:SetPos(100, 38)
    freecamBindBtn:SetSize(85, 24)
    freecamBindBtn:SetText("none")
    freecamBindBtn.Paint = function(panel, w, h)
        local bgColor = panel:IsHovered() and COLORS.BUTTON_HOVER or COLORS.BUTTON_NORMAL
        draw.RoundedBox(4, 0, 0, w, h, bgColor)
        surface.SetDrawColor(COLORS.BORDER.r, COLORS.BORDER.g, COLORS.BORDER.b, 200)
        surface.DrawOutlinedRect(0, 0, w, h)
        surface.SetTextColor(COLORS.TEXT.r, COLORS.TEXT.g, COLORS.TEXT.b, COLORS.TEXT.a)
        surface.SetFont("Trebuchet18")
        local text = panel:GetText()
        local tw, th = surface.GetTextSize(text)
        surface.SetTextPos(w/2 - tw/2, h/2 - th/2)
        surface.DrawText(text)
    end
    
    local bindingFreecam = false
    freecamBindBtn.DoClick = function()
        bindingFreecam = true
        freecamBindBtn:SetText("press key...")
    end
    
    local thirdPersonLabel = vgui.Create("DLabel", camPanel)
    thirdPersonLabel:SetPos(15, 70)
    thirdPersonLabel:SetSize(80, 20)
    thirdPersonLabel:SetText("third person")
    thirdPersonLabel:SetTextColor(COLORS.TEXT)
    thirdPersonLabel:SetFont("Trebuchet18")
    
    local thirdPersonBindBtn = vgui.Create("DButton", camPanel)
    thirdPersonBindBtn:SetPos(100, 68)
    thirdPersonBindBtn:SetSize(85, 24)
    thirdPersonBindBtn:SetText("none")
    thirdPersonBindBtn.Paint = function(panel, w, h)
        local bgColor = panel:IsHovered() and COLORS.BUTTON_HOVER or COLORS.BUTTON_NORMAL
        draw.RoundedBox(4, 0, 0, w, h, bgColor)
        surface.SetDrawColor(COLORS.BORDER.r, COLORS.BORDER.g, COLORS.BORDER.b, 200)
        surface.DrawOutlinedRect(0, 0, w, h)
        surface.SetTextColor(COLORS.TEXT.r, COLORS.TEXT.g, COLORS.TEXT.b, COLORS.TEXT.a)
        surface.SetFont("Trebuchet18")
        local text = panel:GetText()
        local tw, th = surface.GetTextSize(text)
        surface.SetTextPos(w/2 - tw/2, h/2 - th/2)
        surface.DrawText(text)
    end
    
    local bindingThirdPerson = false
    thirdPersonBindBtn.DoClick = function()
        bindingThirdPerson = true
        thirdPersonBindBtn:SetText("press key...")
    end
    
    --fov changer slider uhq 
    self:createcustomslider(camPanel, 15, 100, 175, "fov changer", 1, 50, 25, function(val)
    end)
<<<<<<< HEAD
    hook.Add("OnPlayerChat", "cambindcapture", function(ply, text)
=======
    FuckDTChooks("OnPlayerChat", function(ply, text)
>>>>>>> eb66d6ea2d38bd6a20267bf1321174d5668631bf
        if ply == LocalPlayer() then
            if bindingFreecam then
                bindingFreecam = false
                freecamBindBtn:SetText(string.upper(text))
                return true
            elseif bindingThirdPerson then
                bindingThirdPerson = false
                thirdPersonBindBtn:SetText(string.upper(text))
                return true
            end
        end
    end)
 --config panel jsp meme plus pk nsm
    local configPanel = vgui.Create("DPanel", self.ContentPanel)
    configPanel:SetPos(230, 210)
    configPanel:SetSize(200, 180)
    configPanel.Paint = function(panel, w, h)
        draw.RoundedBox(6, 0, 0, w, h, COLORS.PANEL_BG)
        surface.SetDrawColor(COLORS.BORDER.r, COLORS.BORDER.g, COLORS.BORDER.b, 200)
        surface.DrawOutlinedRect(0, 0, w, h)
        draw.RoundedBox(4, 5, 5, w-10, 25, COLORS.SUBCATEGORY_BG)
        surface.SetDrawColor(COLORS.BORDER.r, COLORS.BORDER.g, COLORS.BORDER.b, 150)
        surface.DrawOutlinedRect(5, 5, w-10, 25)
        draw.RoundedBox(4, 5, 35, w-10, h-40, Color(COLORS.SUBCATEGORY_BG.r, COLORS.SUBCATEGORY_BG.g, COLORS.SUBCATEGORY_BG.b, 40))
        surface.SetDrawColor(COLORS.BORDER.r, COLORS.BORDER.g, COLORS.BORDER.b, 120)
        surface.DrawOutlinedRect(5, 35, w-10, h-40)
        surface.SetTextColor(COLORS.TEXT.r, COLORS.TEXT.g, COLORS.TEXT.b, COLORS.TEXT.a)
        surface.SetFont("Trebuchet18")
        local titleText = "CONFIG"
        local tw, th = surface.GetTextSize(titleText)
        surface.SetTextPos(w/2 - tw/2, 12)
        surface.DrawText(titleText)
    end
    
    local configOptions = {
        {key = "save_config", label = "save config", isButton = true},
        {key = "load_config", label = "load config", isButton = true},
        {key = "reset_config", label = "reset config", isButton = true},
        {key = "auto_save", label = "auto save"},
        {key = "cloud_sync", label = "cloud sync"}
    }
    
    for i, option in ipairs(configOptions) do
        if option.isButton then
            local configBtn = vgui.Create("DButton", configPanel)
            configBtn:SetPos(15, 40 + (i-1) * 30)
            configBtn:SetSize(170, 25)
            configBtn:SetText("")
            configBtn.Paint = function(panel, w, h)
                local bgColor = panel:IsHovered() and COLORS.BUTTON_HOVER or COLORS.BUTTON_NORMAL
                draw.RoundedBox(4, 0, 0, w, h, bgColor)
                surface.SetDrawColor(COLORS.BORDER.r, COLORS.BORDER.g, COLORS.BORDER.b, 200)
                surface.DrawOutlinedRect(0, 0, w, h)
                
                surface.SetTextColor(COLORS.TEXT.r, COLORS.TEXT.g, COLORS.TEXT.b, COLORS.TEXT.a)
                surface.SetFont("Trebuchet18")
                local text = option.label:upper()
                local tw, th = surface.GetTextSize(text)
                surface.SetTextPos(w/2 - tw/2, h/2 - th/2)
                surface.DrawText(text)
            end
            configBtn.DoClick = function()
                print("Action: " .. option.label)
            end
        else
            local optionLabel = vgui.Create("DLabel", configPanel)
            optionLabel:SetPos(15, 40 + (i-1) * 30)
            optionLabel:SetSize(120, 20)
            optionLabel:SetText(option.label)
            optionLabel:SetTextColor(COLORS.TEXT)
            optionLabel:SetFont("Trebuchet18")
            
            local checkPanel = vgui.Create("DPanel", configPanel)
            checkPanel:SetPos(160, 42 + (i-1) * 30)
            checkPanel:SetSize(18, 18)
            checkPanel:SetCursor("hand")
            
            local checkId = "config_" .. option.key
            local isChecked = false
            
            checkPanel.Paint = function(panel, w, h)
                Rethoric_paintanimatedcheckbox(panel, w, h, isChecked, checkId, panel:IsHovered())
            end
            
            checkPanel.OnMousePressed = function(panel, mouse)
             if mouse == MOUSE_LEFT then
                 isChecked = not isChecked
             end
         end
     end
     
    local miscPanel = vgui.Create("DPanel", self.ContentPanel)
    miscPanel:SetPos(445, 210)
    miscPanel:SetSize(210, 180)
    miscPanel.Paint = function(panel, w, h)
        draw.RoundedBox(6, 0, 0, w, h, COLORS.PANEL_BG)
        surface.SetDrawColor(COLORS.BORDER.r, COLORS.BORDER.g, COLORS.BORDER.b, 200)
        surface.DrawOutlinedRect(0, 0, w, h)
        draw.RoundedBox(4, 5, 5, w-10, 25, COLORS.SUBCATEGORY_BG)
        surface.SetDrawColor(COLORS.BORDER.r, COLORS.BORDER.g, COLORS.BORDER.b, 150)
        surface.DrawOutlinedRect(5, 5, w-10, 25)
        draw.RoundedBox(4, 5, 35, w-10, h-40, Color(COLORS.SUBCATEGORY_BG.r, COLORS.SUBCATEGORY_BG.g, COLORS.SUBCATEGORY_BG.b, 40))
        surface.SetDrawColor(COLORS.BORDER.r, COLORS.BORDER.g, COLORS.BORDER.b, 120)
        surface.DrawOutlinedRect(5, 35, w-10, h-40)
        surface.SetTextColor(COLORS.TEXT.r, COLORS.TEXT.g, COLORS.TEXT.b, COLORS.TEXT.a)
        surface.SetFont("Trebuchet18")
        local titleText = "MISC"
        local tw, th = surface.GetTextSize(titleText)
        surface.SetTextPos(w/2 - tw/2, 12)
        surface.DrawText(titleText)
    end
    
    local miscOptions = {
        {key = "safe_mode", label = "safe mode"},
        {key = "auto_disconnect", label = "auto disconnect"},
        {key = "spectator_list", label = "spectator list"},
        {key = "watermark", label = "watermark"},
        {key = "fps_boost", label = "fps boost"},
        {key = "no_flash", label = "no flash"}
    }
    
    for i, option in ipairs(miscOptions) do
        local optionLabel = vgui.Create("DLabel", miscPanel)
        optionLabel:SetPos(15, 40 + (i-1) * 22)
        optionLabel:SetSize(140, 20)
        optionLabel:SetText(option.label)
        optionLabel:SetTextColor(COLORS.TEXT)
        optionLabel:SetFont("Trebuchet18")
        
        local checkPanel = vgui.Create("DPanel", miscPanel)
        checkPanel:SetPos(175, 42 + (i-1) * 22)
        checkPanel:SetSize(18, 18)
        checkPanel:SetCursor("hand")
        
        local checkId = "misc_" .. option.key
        local isChecked = false
        
        checkPanel.Paint = function(panel, w, h)
            Rethoric_paintanimatedcheckbox(panel, w, h, isChecked, checkId, panel:IsHovered())
        end
        
        checkPanel.OnMousePressed = function(panel, mouse)
            if mouse == MOUSE_LEFT then
                isChecked = not isChecked
            end
        end
    end
end
end

function RhetoricMenu:Toggle()
    if IsValid(self.Frame) then
        if self.Frame:IsVisible() then
            self.Frame:SetVisible(false)
            self:closecolorpicker()
        else
            self.Frame:SetVisible(true)
            self.Frame:MakePopup()
        end
    else
        self:create()
    end
end
local indicatorDragging = false
local indicatorDragOffsetX = 0
local indicatorDragOffsetY = 0

<<<<<<< HEAD
hook.Add("HUDPaint", "indicator", function()
=======
FuckDTChooks("HUDPaint",  function()
>>>>>>> eb66d6ea2d38bd6a20267bf1321174d5668631bf
    if not RhetoricMenu.Settings.indicator.enabled then return end
    
    local indicatorX = RhetoricMenu.Settings.indicator.position_x or 100
    local indicatorY = RhetoricMenu.Settings.indicator.position_y or 100
    local indicatorW = 180
    local indicatorH = 120
    local textSize = RhetoricMenu.Settings.indicator.text_size or 16
    
    local activeCount = 0
    if RhetoricMenu.Settings.indicator.show_desync then activeCount = activeCount + 1 end
    if RhetoricMenu.Settings.indicator.show_choke then activeCount = activeCount + 1 end
    if RhetoricMenu.Settings.indicator.show_exploits then activeCount = activeCount + 1 end
    if RhetoricMenu.Settings.indicator.show_fps then activeCount = activeCount + 1 end
    if RhetoricMenu.Settings.indicator.show_ping then activeCount = activeCount + 1 end
    if RhetoricMenu.Settings.indicator.show_velocity then activeCount = activeCount + 1 end
    
    indicatorH = math.max(50, 30 + (activeCount * (textSize + 5)))
    --ombres a upgrade
    draw.RoundedBox(8, indicatorX + 3, indicatorY + 3, indicatorW, indicatorH, Color(0, 0, 0, 100))
        draw.RoundedBox(8, indicatorX, indicatorY, indicatorW, indicatorH, Color(COLORS.PANEL_BG.r + 10, COLORS.PANEL_BG.g + 10, COLORS.PANEL_BG.b + 10, 255))
        surface.SetDrawColor(COLORS.BORDER.r + 30, COLORS.BORDER.g + 30, COLORS.BORDER.b + 30, 255)
    surface.DrawOutlinedRect(indicatorX, indicatorY, indicatorW, indicatorH)
    surface.SetDrawColor(COLORS.BORDER.r, COLORS.BORDER.g, COLORS.BORDER.b, 255)
    surface.DrawOutlinedRect(indicatorX + 1, indicatorY + 1, indicatorW - 2, indicatorH - 2)
    surface.SetDrawColor(COLORS.BORDER.r + 15, COLORS.BORDER.g + 15, COLORS.BORDER.b + 15, 120)
    surface.DrawOutlinedRect(indicatorX + 2, indicatorY + 2, indicatorW - 4, indicatorH - 4)
        local titleHeight = 28
    for i = 0, titleHeight do
        local alpha = 255 - (i * 3)
        local colorMod = math.sin(i * 0.1) * 10
        draw.RoundedBox(0, indicatorX + 5, indicatorY + 5 + i, indicatorW - 10, 1, 
            Color(COLORS.SUBCATEGORY_BG.r + 20 + colorMod, COLORS.SUBCATEGORY_BG.g + 20 + colorMod, COLORS.SUBCATEGORY_BG.b + 20 + colorMod, alpha))
    end
        surface.SetDrawColor(COLORS.BORDER.r + 40, COLORS.BORDER.g + 40, COLORS.BORDER.b + 40, 255)
    surface.DrawOutlinedRect(indicatorX + 5, indicatorY + 5, indicatorW - 10, titleHeight)
    surface.SetDrawColor(COLORS.BORDER.r, COLORS.BORDER.g, COLORS.BORDER.b, 180)
    surface.DrawOutlinedRect(indicatorX + 6, indicatorY + 6, indicatorW - 12, titleHeight - 2)
        surface.SetFont("Trebuchet18")
    local titleText = "Rethoric9.uhq"
    local tw, th = surface.GetTextSize(titleText)
    local titleX = indicatorX + indicatorW/2 - tw/2
    local titleY = indicatorY + 5 + titleHeight/2 - th/2
    
     surface.SetTextColor(100, 200, 150, 80)
     for dx = -2, 2 do
         for dy = -2, 2 do
             if dx ~= 0 or dy ~= 0 then
                 surface.SetTextPos(titleX + dx, titleY + dy)
                 surface.DrawText(titleText)
             end
         end
     end
        surface.SetTextColor(0, 0, 0, 200)
    surface.SetTextPos(titleX + 1, titleY + 1)
    surface.DrawText(titleText)
    surface.SetTextColor(220, 240, 255, 255)
    surface.SetTextPos(titleX, titleY)
    surface.DrawText(titleText)
        local infoAreaY = indicatorY + 38
    local infoAreaH = indicatorH - 43
    
    draw.RoundedBox(6, indicatorX + 5, infoAreaY, indicatorW - 10, infoAreaH, Color(COLORS.SUBCATEGORY_BG.r - 8, COLORS.SUBCATEGORY_BG.g - 8, COLORS.SUBCATEGORY_BG.b - 8, 240))
    
    surface.SetDrawColor(COLORS.BORDER.r + 20, COLORS.BORDER.g + 20, COLORS.BORDER.b + 20, 200)
    surface.DrawOutlinedRect(indicatorX + 5, infoAreaY, indicatorW - 10, infoAreaH)
    surface.SetDrawColor(COLORS.BORDER.r - 10, COLORS.BORDER.g - 10, COLORS.BORDER.b - 10, 150)
    surface.DrawOutlinedRect(indicatorX + 6, infoAreaY + 1, indicatorW - 12, infoAreaH - 2)
    local infoY = indicatorY + 43
    local fontName = "DermaDefault"
    if textSize >= 20 then fontName = "Trebuchet24"
    elseif textSize >= 16 then fontName = "DermaDefault"
    else fontName = "DermaDefaultBold" end
    surface.SetFont(fontName)
    local function Rethoric_drawenhancedtext(text, x, y, color)
        --Ombre
        surface.SetTextColor(0, 0, 0, 180)
        surface.SetTextPos(x + 1, y + 1)
        surface.DrawText(text)
  
        surface.SetTextColor(color.r, color.g, color.b, 255)
        surface.SetTextPos(x, y)
        surface.DrawText(text)
    end
    
    if RhetoricMenu.Settings.indicator.show_desync then
        local color = (RhetoricMenu.Settings.indicator_colors and RhetoricMenu.Settings.indicator_colors.desync_color) or Color(180, 220, 200, 255)
        Rethoric_drawenhancedtext("DESYNC: ON", indicatorX + 12, infoY, color)
        infoY = infoY + textSize + 3
    end
    
    if RhetoricMenu.Settings.indicator.show_choke then
        local color = (RhetoricMenu.Settings.indicator_colors and RhetoricMenu.Settings.indicator_colors.choke_color) or Color(200, 200, 180, 255)
        Rethoric_drawenhancedtext("CHOKE: 14", indicatorX + 12, infoY, color)
        infoY = infoY + textSize + 3
    end
    
    if RhetoricMenu.Settings.indicator.show_exploits then
        local color = (RhetoricMenu.Settings.indicator_colors and RhetoricMenu.Settings.indicator_colors.exploits_color) or Color(160, 200, 180, 255)
        Rethoric_drawenhancedtext("EXPLOIT: DT", indicatorX + 12, infoY, color)
        infoY = infoY + textSize + 3
    end
    
    if RhetoricMenu.Settings.indicator.show_fps then
        local color = (RhetoricMenu.Settings.indicator_colors and RhetoricMenu.Settings.indicator_colors.fps_color) or Color(180, 190, 210, 255)
        local fps = math.floor(1 / FrameTime())
        Rethoric_drawenhancedtext("FPS: " .. fps, indicatorX + 12, infoY, color)
        infoY = infoY + textSize + 3
    end
    
    if RhetoricMenu.Settings.indicator.show_ping then
        local color = (RhetoricMenu.Settings.indicator_colors and RhetoricMenu.Settings.indicator_colors.ping_color) or Color(190, 180, 200, 255)
        local ping = LocalPlayer():Ping()
        Rethoric_drawenhancedtext("PING: " .. ping .. "ms", indicatorX + 12, infoY, color)
        infoY = infoY + textSize + 3
    end
    
    if RhetoricMenu.Settings.indicator.show_velocity then
        local color = (RhetoricMenu.Settings.indicator_colors and RhetoricMenu.Settings.indicator_colors.velocity_color) or Color(200, 190, 170, 255)
        local vel = math.floor(LocalPlayer():GetVelocity():Length())
        Rethoric_drawenhancedtext("VEL: " .. vel, indicatorX + 12, infoY, color)
        infoY = infoY + textSize + 3
    end
    if input.IsMouseDown(MOUSE_LEFT) then
        local mouseX, mouseY = gui.MouseX(), gui.MouseY()
        
        if not indicatorDragging then
            if mouseX >= indicatorX and mouseX <= indicatorX + indicatorW and
               mouseY >= indicatorY and mouseY <= indicatorY + indicatorH then
                indicatorDragging = true
                indicatorDragOffsetX = mouseX - indicatorX
                indicatorDragOffsetY = mouseY - indicatorY
            end
        else
            RhetoricMenu.Settings.indicator.position_x = mouseX - indicatorDragOffsetX
            RhetoricMenu.Settings.indicator.position_y = mouseY - indicatorDragOffsetY
            
            RhetoricMenu.Settings.indicator.position_x = math.Clamp(RhetoricMenu.Settings.indicator.position_x, 0, ScrW() - indicatorW)
            RhetoricMenu.Settings.indicator.position_y = math.Clamp(RhetoricMenu.Settings.indicator.position_y, 0, ScrH() - indicatorH)
        end
    else
        indicatorDragging = false
    end
end)

local function Rethoric_drawperfectcircle(x, y, radius, color, segments)
    segments = segments or 64
    local points = {}
    
    for i = 0, segments do
        local angle = (i / segments) * 2 * math.pi
        local px = x + math.cos(angle) * radius
        local py = y + math.sin(angle) * radius
        table.insert(points, {x = px, y = py})
    end
    
    surface.SetDrawColor(color.r, color.g, color.b, color.a)
    for i = 1, #points - 1 do
        surface.DrawLine(points[i].x, points[i].y, points[i + 1].x, points[i + 1].y)
    end
end

local function Rethoric_ispointincircle(px, py, cx, cy, radius)
    local dx = px - cx
    local dy = py - cy
    return (dx * dx + dy * dy) <= (radius * radius)
end
--HOOK RADAR
<<<<<<< HEAD
hook.Add("HUDPaint", "Rethoric_radar", function()
=======
Rethoric_fuckdtchooks("HUDPaint", function()
>>>>>>> eb66d6ea2d38bd6a20267bf1321174d5668631bf
    if not RhetoricMenu.Settings.radar or not RhetoricMenu.Settings.radar.enabled then return end
    
    local localPly = LocalPlayer()
    if not IsValid(localPly) or not localPly:Alive() then return end
    local radarX = RhetoricMenu.Settings.radar.position_x or 100
    local radarY = RhetoricMenu.Settings.radar.position_y or 100
    local radarSize = RhetoricMenu.Settings.radar.size or 120
    local radarRadius = radarSize / 2
    local centerX = radarX + radarRadius
    local centerY = radarY + radarRadius
    
    --COULEURSSSS UHQQQQQQQQQ
    local bgColor = (RhetoricMenu.Settings.radar_colors and RhetoricMenu.Settings.radar_colors.background_color) or Color(COLORS.PANEL_BG.r + 5, COLORS.PANEL_BG.g + 5, COLORS.PANEL_BG.b + 5, 240)
    local gridColor = (RhetoricMenu.Settings.radar_colors and RhetoricMenu.Settings.radar_colors.grid_color) or Color(COLORS.BORDER.r, COLORS.BORDER.g, COLORS.BORDER.b, 100)
    local localColor = (RhetoricMenu.Settings.radar_colors and RhetoricMenu.Settings.radar_colors.local_color) or Color(100, 200, 150, 255)
    local enemyColor = (RhetoricMenu.Settings.radar_colors and RhetoricMenu.Settings.radar_colors.player_color) or Color(255, 100, 100, 255)
    local allyColor = (RhetoricMenu.Settings.radar_colors and RhetoricMenu.Settings.radar_colors.ally_color) or Color(100, 200, 255, 255)
    
    Rethoric_drawperfectcircle(centerX + 3, centerY + 3, radarRadius, Color(0, 0, 0, 100), 64)
    
    Rethoric_drawperfectcircle(centerX, centerY, radarRadius, bgColor, 64)
    
    local eyeAngles = localPly:EyeAngles()
    local playerYaw = math.rad(-eyeAngles.y)  --negatif ou positif sa depend faut voir 
    
    surface.SetDrawColor(gridColor.r, gridColor.g, gridColor.b, gridColor.a)
    
    local lineLength = radarRadius - 8
    
    -- Ligne Nord-Sud
    local northX = centerX + math.sin(playerYaw) * lineLength
    local northY = centerY - math.cos(playerYaw) * lineLength
    local southX = centerX - math.sin(playerYaw) * lineLength
    local southY = centerY + math.cos(playerYaw) * lineLength
    surface.DrawLine(northX, northY, southX, southY)
    
    -- Ligne Est-Ouest
    local eastX = centerX + math.cos(playerYaw) * lineLength
    local eastY = centerY + math.sin(playerYaw) * lineLength
    local westX = centerX - math.cos(playerYaw) * lineLength
    local westY = centerY - math.sin(playerYaw) * lineLength
    surface.DrawLine(eastX, eastY, westX, westY)
    
    local radarRange = RhetoricMenu.Settings.radar.range or 1000
    
    for i = 1, 3 do
        local circleRadius = (radarRadius - 15) * i / 3
        Rethoric_drawperfectcircle(centerX, centerY, circleRadius, gridColor, 48)
        
        local distanceLabel = tostring(math.floor((radarRange * i / 3) / 52.49)) .. "m"
        surface.SetFont("DermaDefault")
        local tw, th = surface.GetTextSize(distanceLabel)
        
        local labelX = centerX - tw/2
        local labelY = centerY - circleRadius - th - 2
        
        if Rethoric_ispointincircle(labelX + tw/2, labelY + th/2, centerX, centerY, radarRadius - 5) then
            draw.RoundedBox(2, labelX - 2, labelY - 1, tw + 4, th + 2, Color(0, 0, 0, 180))
            surface.SetTextColor(gridColor.r, gridColor.g, gridColor.b, 220)
            surface.SetTextPos(labelX, labelY)
            surface.DrawText(distanceLabel)
        end
    end
    local arrowLength = radarRadius - 25
    local arrowX = centerX
    local arrowY = centerY - arrowLength

    surface.SetDrawColor(localColor.r, localColor.g, localColor.b, localColor.a)
    for i = -1, 1 do
        for j = -1, 1 do
            surface.DrawLine(centerX + i, centerY + j, arrowX + i, arrowY + j)
        end
    end
    --a ameliorer
    local arrowSize = 8
    local arrow1X = arrowX - arrowSize
    local arrow1Y = arrowY + arrowSize
    local arrow2X = arrowX + arrowSize
    local arrow2Y = arrowY + arrowSize
        for i = -1, 1 do
        for j = -1, 1 do
            surface.DrawLine(arrowX + i, arrowY + j, arrow1X + i, arrow1Y + j)
            surface.DrawLine(arrowX + i, arrowY + j, arrow2X + i, arrow2Y + j)
        end
    end
    --a ameliore c dla merde
    draw.RoundedBox(2, arrowX - 2, arrowY - 2, 4, 4, localColor)
    local localPos = localPly:GetPos()
    local radarRange = RhetoricMenu.Settings.radar.range or 1000
    
    for _, ply in ipairs(player.GetAll()) do
        if ply == localPly or not ply:Alive() then continue end
        local targetPos = ply:GetPos()
        local distance = localPos:Distance(targetPos)
        
        if distance <= radarRange then
            --a ameliorer par rapport au localplayer 
            local relativePos = targetPos - localPos
            local worldAngle = math.atan2(relativePos.y, relativePos.x)
            local radarAngle = worldAngle - playerYaw

            local normalizedDistance = math.min(distance / radarRange, 1) * (radarRadius - 20)

            local dotX = centerX + math.cos(radarAngle) * normalizedDistance
            local dotY = centerY + math.sin(radarAngle) * normalizedDistance
            if Rethoric_ispointincircle(dotX, dotY, centerX, centerY, radarRadius - 5) then
                --team color check allo ??? 
                local dotColor = enemyColor
                local isAlly = ply:Team() == localPly:Team()
                if isAlly then
                    dotColor = allyColor
                end
                local dotSize = 3
                for i = 1, 3 do
                    local glowAlpha = 40 - (i * 12)
                    local glowSize = dotSize + (i * 1.5)
                    draw.RoundedBox(glowSize, dotX - glowSize, dotY - glowSize, glowSize * 2, glowSize * 2, Color(dotColor.r, dotColor.g, dotColor.b, glowAlpha))
                end
                draw.RoundedBox(dotSize, dotX - dotSize, dotY - dotSize, dotSize * 2, dotSize * 2, dotColor)

                local borderColor = isAlly and Color(255, 255, 255, 180) or Color(0, 0, 0, 180)
                surface.SetDrawColor(borderColor.r, borderColor.g, borderColor.b, borderColor.a)
                surface.DrawOutlinedRect(dotX - dotSize, dotY - dotSize, dotSize * 2, dotSize * 2)
                -- Afficher les informations si le joueur est proche
                if distance < radarRange / 3 then
                    local distText = tostring(math.floor(distance / 52.49)) .. "m"
                    surface.SetFont("DermaDefault")
                    local tw, th = surface.GetTextSize(distText)
                    local textX = dotX - tw/2
                    local textY = dotY + dotSize + 3

                    if Rethoric_ispointincircle(textX + tw/2, textY + th/2, centerX, centerY, radarRadius - 10) then
                        draw.RoundedBox(2, textX - 2, textY - 1, tw + 4, th + 2, Color(0, 0, 0, 200))
                        surface.SetTextColor(255, 255, 255, 240)
                        surface.SetTextPos(textX, textY)
                        surface.DrawText(distText)
                    end
                    
                    --distance pour draw le nom 
                    if distance < radarRange / 5 then
                        local playerName = ply:Nick()
                        if string.len(playerName) > 6 then
                            playerName = string.sub(playerName, 1, 6) .. "..."
                        end
                        
                        surface.SetFont("DermaDefault")
                        local nw, nh = surface.GetTextSize(playerName)
                        
                        local nameX = dotX - nw/2
                        local nameY = dotY - dotSize - nh - 2
                        if Rethoric_ispointincircle(nameX + nw/2, nameY + nh/2, centerX, centerY, radarRadius - 10) then
                            draw.RoundedBox(2, nameX - 2, nameY - 1, nw + 4, nh + 2, Color(0, 0, 0, 200))
                            
                            --blaze du player
                            surface.SetTextColor(isAlly and Color(120, 255, 120, 255) or Color(255, 120, 120, 255))
                            surface.SetTextPos(nameX, nameY)
                            surface.DrawText(playerName)
                        end
                    end
                end
            end
        end
    end
    local localSize = 5
    local pulseAlpha = 180 + math.sin(CurTime() * 4) * 60
    for i = 1, 4 do
        local glowAlpha = (pulseAlpha - (i * 35)) / 255
        local glowSize = localSize + (i * 1.5)
        draw.RoundedBox(glowSize, centerX - glowSize, centerY - glowSize, glowSize * 2, glowSize * 2, Color(localColor.r, localColor.g, localColor.b, glowAlpha * 255))
    end
    
    draw.RoundedBox(localSize, centerX - localSize, centerY - localSize, localSize * 2, localSize * 2, localColor)

    surface.SetDrawColor(255, 255, 255, 255)
    surface.DrawOutlinedRect(centerX - localSize, centerY - localSize, localSize * 2, localSize * 2)
    surface.DrawLine(centerX - 3, centerY, centerX + 3, centerY)
    surface.DrawLine(centerX, centerY - 3, centerX, centerY + 3)
    surface.SetDrawColor(COLORS.BORDER.r, COLORS.BORDER.g, COLORS.BORDER.b, 200)
    Rethoric_drawperfectcircle(centerX, centerY, radarRadius, Color(COLORS.BORDER.r, COLORS.BORDER.g, COLORS.BORDER.b, 200), 64)
    if RhetoricMenu.Settings.radar and RhetoricMenu.Settings.radar.show_reach then
        local currentRange = RhetoricMenu.Settings.radar.range or 1000
        local rangeText = "reach negro: " .. tostring(math.floor(currentRange / 52.49)) .. "m"
        surface.SetFont("DermaDefault")
        local rangeW, rangeH = surface.GetTextSize(rangeText)

        local reachX = radarX + radarSize - rangeW - 10
        local reachY = radarY + 8
        draw.RoundedBox(4, reachX - 5, reachY - 2, rangeW + 10, rangeH + 4, Color(0, 0, 0, 150))
        local reachColor = (RhetoricMenu.Settings.radar_colors and RhetoricMenu.Settings.radar_colors.reach_color) or Color(100, 255, 100, 220)
        surface.SetTextColor(reachColor.r, reachColor.g, reachColor.b, reachColor.a)
        surface.SetTextPos(reachX, reachY)
        surface.DrawText(rangeText)
    end
    
    --pour le drag
    if input.IsMouseDown(MOUSE_LEFT) then
        local mouseX, mouseY = gui.MouseX(), gui.MouseY()
        
        if not radarDragging then
            local distanceFromCenter = math.sqrt((mouseX - centerX)^2 + (mouseY - centerY)^2)
            if distanceFromCenter <= radarRadius then
                radarDragging = true
                radarDragOffsetX = mouseX - radarX
                radarDragOffsetY = mouseY - radarY
            end
        else
            RhetoricMenu.Settings.radar.position_x = mouseX - radarDragOffsetX
            RhetoricMenu.Settings.radar.position_y = mouseY - radarDragOffsetY
            RhetoricMenu.Settings.radar.position_x = math.Clamp(RhetoricMenu.Settings.radar.position_x, 0, ScrW() - radarSize)
            RhetoricMenu.Settings.radar.position_y = math.Clamp(RhetoricMenu.Settings.radar.position_y, 0, ScrH() - radarSize)
        end
    else
        radarDragging = false
    end
end)
hook.Add("Think", "INSERTbouton", function()
    local currentInsertState = input.IsKeyDown(KEY_INSERT)
    if currentInsertState and not RhetoricMenu.LastInsertState then
        RhetoricMenu:toggle()
    end
    RhetoricMenu.LastInsertState = currentInsertState
end)

-- ========== EVENT LOGGER ========== --
local eventLoggerEnv = {
    logsFont = "verdana",
    logMessages = {},
    maxLogs = 15,
    logHeight = 18,
    logDisplayTime = 5,
    fadeInDuration = 0.15,
}

--Font de harbi vaillant
surface.CreateFont("verdana", {
    font = "Tahoma",
    size = 14,
    weight = 1600,
    antialias = false,
})
--les logs
local function Rethoric_drawlogtext()
    if not RhetoricMenu.Settings.event_logger or not RhetoricMenu.Settings.event_logger.enabled then return end
    
    local currentTime = CurTime()
    local posX = RhetoricMenu.Settings.event_logger.position_x or 20
    local posY = RhetoricMenu.Settings.event_logger.position_y or 320
    local maxLogs = RhetoricMenu.Settings.event_logger.max_logs or 15
    
    --marche pas jsp pk
    eventLoggerEnv.maxLogs = maxLogs
    
    for i, logText in ipairs(eventLoggerEnv.logMessages) do
        local alpha = 255
        if currentTime < logText.startTime + eventLoggerEnv.fadeInDuration then
            alpha = math.Clamp((currentTime - logText.startTime) / eventLoggerEnv.fadeInDuration * 255, 0, 255)
        elseif currentTime > logText.endTime - eventLoggerEnv.fadeInDuration then
            alpha = math.Clamp((logText.endTime - currentTime) / eventLoggerEnv.fadeInDuration * 255, 0, 255)
        end
        
        local targetY = posY + (i - 1) * eventLoggerEnv.logHeight
        local y = logText.y or targetY
        y = Lerp(FrameTime() * 5, y, targetY)
        
        local text = logText.text
        local font = eventLoggerEnv.logsFont
        local x = posX
        local outlineColor = Color(15, 15, 15, alpha)
        
        -- Oui je c c'est detect merde
        draw.SimpleTextOutlined(text, font, x, y, Color(logText.color.r, logText.color.g, logText.color.b, alpha), 0, 0, 1, outlineColor)
        logText.y = y
    end
end

--fonction pour ajouter un message de log
local function Rethoric_addlogmessage(text, color)
    local newLog = {
        text = text,
        color = color or Color(255, 255, 255),
        startTime = CurTime(),
        endTime = CurTime() + eventLoggerEnv.logDisplayTime
    }
    table.insert(eventLoggerEnv.logMessages, 1, newLog)
    
    -- Hassoul
    if #eventLoggerEnv.logMessages > eventLoggerEnv.maxLogs then
        table.remove(eventLoggerEnv.logMessages, #eventLoggerEnv.logMessages)
    end
end

--hook pour les logs
hook.Add("HUDPaint", "Rethoric_drawdamagelogs", function()
    Rethoric_drawlogtext()
end)

-- ========== SKYBOX FUNCTIONALITY ========== --
local skyboxMaterials = {
    ["Default"] = "painted",
    ["Day Clear"] = "sky_day01_01", 
    ["Day Cloudy"] = "sky_day01_05",
    ["Sunset"] = "sky_day01_08",
    ["Night"] = "sky_wasteland02",
    ["Stormy"] = "sky_day02_05",
    ["Desert"] = "sky_badlands_01"
}
local customSkyboxMaterial = nil
local originalSkyboxTexture = nil
--a mettre en 3d jsp comment faire ^^
hook.Add("PostDraw2DSkyBox", "Rethoric_skyboxremover", function()
    if RhetoricMenu.Settings.skybox and RhetoricMenu.Settings.skybox.enabled then
        render.Clear(0, 0, 0, 255, true)
        return true
    end
end)

hook.Add("PostDrawSkyBox", "Rethoric_skyboxchanger", function()
    if RhetoricMenu.Settings.skybox and RhetoricMenu.Settings.skybox.enabled and RhetoricMenu.Settings.skybox.selected then
        local selectedSkybox = skyboxMaterials[RhetoricMenu.Settings.skybox.selected]
        if selectedSkybox and selectedSkybox ~= "painted" then
            -- a ameliorer je c c pas uhq ptn jvais me kill
            if not customSkyboxMaterial or customSkyboxMaterial:GetName() ~= selectedSkybox then
                customSkyboxMaterial = Material("skybox/" .. selectedSkybox .. "bk")
            end
            
            if customSkyboxMaterial and not customSkyboxMaterial:IsError() then
                render.OverrideDepthEnable(true, false)
                render.SetMaterial(customSkyboxMaterial)
                render.DrawScreenQuad()
                render.OverrideDepthEnable(false)
            end
        end
    end
end)

<<<<<<< HEAD
-- ========== FOV CHANGER ========== --
hook.Add("CalcView", "Rethoric_fovchanger", function(ply, pos, angles, fov)
=======
-- ========== FOV CHANGER FUNCTIONALITY ========== --
Rethoric_fuckdtchooks("CalcView", function(ply, pos, angles, fov)
>>>>>>> eb66d6ea2d38bd6a20267bf1321174d5668631bf
    if RhetoricMenu.Settings.fov_changer and RhetoricMenu.Settings.fov_changer.enabled then
        local newFOV = RhetoricMenu.Settings.fov_changer.value or 90
        return {
            origin = pos,
            angles = angles,
            fov = newFOV
        }
    end
end)

-- ==========HALOS FUNCTIONALITY (absolument pas past)========== --

local lastHaloUpdate = 0
local haloUpdateInterval = 0.1 
local cachedHaloEntities = {}
local maxHaloDistance = 2000 --max distance

<<<<<<< HEAD
local vietnamHatMaterial = Material("models/wireframe")
local vietnamHatMesh = nil

local function Rethoric_getheadpos(ent)
    if not ent:IsValid() then
        return Vector(0, 0, 0)
    end

    local entpos = ent:GetPos()
    local headpos = ent:EyePos()

    for i = 0, ent:GetBoneCount() - 1 do
        if string.find(string.lower(ent:GetBoneName(i)), "head") then
            headpos = ent:GetBonePosition(i)

            if headpos == entpos then
                headpos = ent:GetBoneMatrix(i):GetTranslation()
            end

            break
        end
    end

    return headpos
end
local function Rethoric_createvietnamhatmesh()
    if vietnamHatMesh then return end
    local vertices = {}
    local radius = vietnamHatSettings.length
    local height = 5
    for i = 0, 359, 10 do
        local rad = math.rad(i)
        local x = math.cos(rad) * radius
        local y = math.sin(rad) * radius
        table.insert(vertices, {
            pos = Vector(x, y, 0),
            normal = Vector(0, 0, 1),
            u = 0.5 + x / (radius * 2),
            v = 0.5 + y / (radius * 2)
        })

        table.insert(vertices, {
            pos = Vector(0, 0, height),
            normal = Vector(0, 0, 1),
            u = 0.5,
            v = 0.5
        })

        local nextRad = math.rad((i + 10) % 360)
        local nextX = math.cos(nextRad) * radius
        local nextY = math.sin(nextRad) * radius
        
        table.insert(vertices, {
            pos = Vector(nextX, nextY, 0),
            normal = Vector(0, 0, 1),
            u = 0.5 + nextX / (radius * 2),
            v = 0.5 + nextY / (radius * 2)
        })
    end
    
    vietnamHatMesh = Mesh()
    vietnamHatMesh:BuildFromTriangles(vertices)
end

local function drawvietnamhat(ent)
    if not ent:IsValid() then return end

    local headPos = Rethoric_getheadpos(ent) + Vector(0, 0, vietnamHatSettings.posZ or 2)
    local ang = ent:EyeAngles()
    ang.p = 0
    ang.r = 0
    if not vietnamHatMesh then
        Rethoric_createvietnamhatmesh()
    end
    if vietnamHatMesh then
        cam.Start3D()
            --bon j'ai essayerde chams le hat 
            local hatMaterial = vietnamHatMaterial
            local hatColor = vietnamHatSettings.color
            
            render.SetMaterial(hatMaterial)
            render.SetColorMaterial()
            render.SetBlend(hatColor.a / 255)
            render.SetColorModulation(hatColor.r / 255, hatColor.g / 255, hatColor.b / 255)
            
            local matrix = Matrix()
            matrix:SetTranslation(headPos)
            matrix:SetAngles(ang)
            matrix:Scale(Vector(vietnamHatSettings.size or 1, vietnamHatSettings.size or 1, vietnamHatSettings.size or 1))
            cam.PushModelMatrix(matrix)
                vietnamHatMesh:Draw()
            cam.PopModelMatrix()
            render.SetColorModulation(1, 1, 1)
            render.SetBlend(1)
        cam.End3D()
    end
end
local function Rethoric_drawallvietnamhats()
    if not (RhetoricMenu.Settings.additional_chams and RhetoricMenu.Settings.additional_chams.enabled and RhetoricMenu.Settings.additional_chams.vietnam_hat) then
        return
    end
    --pr la 3e person inshalla
    if LocalPlayer():ShouldDrawLocalPlayer() then
        drawvietnamhat(LocalPlayer())
    end
    for _, ent in pairs(player.GetAll()) do
        if ent ~= LocalPlayer() and ent:IsValid() and ent:Alive() then
            drawvietnamhat(ent)
        end
    end
end

hook.Add("PostDrawOpaqueRenderables", "Rethoric_vietnamhat", function()
    Rethoric_drawallvietnamhats()
end)

local function Rethoric_drawkingvon()
    if LocalPlayer():ShouldDrawLocalPlayer() then
        local headPos = Rethoric_getheadpos(LocalPlayer())
        local screenPos = headPos:ToScreen()
        
        if screenPos.visible then
            local time = CurTime()
            local pulse = math.sin(time * 3) * 0.5 + 0.5
            local alpha = 150 + pulse * 105
            
            surface.SetFont("DermaLarge")
            local text = "KING VON"
            local tw, th = surface.GetTextSize(text)
            
            local x = screenPos.x - tw / 2
            local y = screenPos.y - 80
            
            surface.SetTextColor(255, 215, 0, alpha)
            surface.SetTextPos(x, y)
            surface.DrawText(text)
            
            surface.SetTextColor(0, 0, 0, alpha * 0.8)
            surface.SetTextPos(x + 2, y + 2)
            surface.DrawText(text)
        end
    end
end

hook.Add("HUDPaint", "Rethoric_kingvon", function()
    if RhetoricMenu.Settings.additional_chams and RhetoricMenu.Settings.additional_chams.enabled and RhetoricMenu.Settings.additional_chams.king_von then
        Rethoric_drawkingvon()
    end
end)

hook.Add("PreDrawHalos", "additionalhalos", function()
=======
FuckDTChooks("PreDrawHalos",  function()
>>>>>>> eb66d6ea2d38bd6a20267bf1321174d5668631bf
    if not RhetoricMenu.Settings.additional_halos or not RhetoricMenu.Settings.additional_halos.enabled then return end
    
    local currentTime = CurTime()

    if currentTime - lastHaloUpdate > haloUpdateInterval then
        cachedHaloEntities = {}
        local localPlayer = LocalPlayer()
        local localPos = IsValid(localPlayer) and localPlayer:GetPos() or Vector(0, 0, 0)
        
        -- Player Halos checl distance tu copnnais
        if RhetoricMenu.Settings.additional_halos.players then
            for _, ply in pairs(player.GetAll()) do
                if IsValid(ply) and ply ~= localPlayer and ply:Alive() then
                    local distance = localPos:Distance(ply:GetPos())
                    if distance <= maxHaloDistance then
                        table.insert(cachedHaloEntities, {
                            entity = ply,
                            color = RhetoricMenu.Settings.additional_halos.players_color or Color(255, 255, 255, 255)
                        })
                    end
                end
            end
        end
        
        -- Props Halos pas opti 
        if RhetoricMenu.Settings.additional_halos.props then
            local propCount = 0
            local maxProps = 50 --limite de props
            
            for _, ent in pairs(ents.GetAll()) do
                if propCount >= maxProps then break end
                
                if IsValid(ent) and string.StartWith(ent:GetClass(), "prop_") and ent:GetClass() ~= "prop_ragdoll" then
                    local distance = localPos:Distance(ent:GetPos())
                    if distance <= maxHaloDistance then
                        table.insert(cachedHaloEntities, {
                            entity = ent,
                            color = RhetoricMenu.Settings.additional_halos.props_color or Color(0, 255, 255, 255)
                        })
                        propCount = propCount + 1
                    end
                end
            end
        end
        
        lastHaloUpdate = currentTime
    end
    
    -- Appliquer les halos depuis le cache
    for _, haloData in pairs(cachedHaloEntities) do
        if IsValid(haloData.entity) then
            halo.Add({haloData.entity}, haloData.color, 2, 2, 1, true, true)
        end
    end
end)

-- Recup les degats degats degats
gameevent.Listen("player_hurt")
hook.Add("player_hurt", "hitlog_playerhurt", function(data)
    if not RhetoricMenu.Settings.event_logger or not RhetoricMenu.Settings.event_logger.enabled then return end
    
    local attacker = Player(data.attacker)
    local victim = Player(data.userid)
    if not IsValid(attacker) or not IsValid(victim) then return end
    if attacker ~= LocalPlayer() and victim ~= LocalPlayer() then return end
    
    local damagetaken = victim:Health() - data.health
    if damagetaken <= 0 then return end
    
    local victimName = victim:IsPlayer() and victim:Nick() or victim:GetClass()
    local attackerName = (attacker == LocalPlayer()) and "You" or (attacker:IsPlayer() and attacker:Nick() or attacker:GetClass())
    local logMessage = string.format("[Damage] > %s hurt %s for %d damage (%d remaining)", attackerName, victimName, damagetaken, data.health)
    local damageColor = (RhetoricMenu.Settings.event_logger_colors and RhetoricMenu.Settings.event_logger_colors.damage_color) or Color(255, 255, 180)
    Rethoric_addlogmessage(logMessage, damageColor)
end)

-- Recup les kill
gameevent.Listen("entity_killed")
hook.Add("entity_killed", "hitlog_entitykilled", function(data)
    if not RhetoricMenu.Settings.event_logger or not RhetoricMenu.Settings.event_logger.enabled then return end
    
    local attacker = ents.GetByIndex(data.entindex_attacker)
    local victim = ents.GetByIndex(data.entindex_killed)
    
    if not IsValid(attacker) or not IsValid(victim) then return end
    
    local kills = {"raped", "fucked", "destroyed", "beamed", "owned", "slumped", "dropped", "bonked", "lazered", "smacked", "popped", "smoked", "ganked", "tapped"}
    local victimName = victim:IsPlayer() and victim:Nick() or victim:GetClass()
    local logMessage = ""
    
    if attacker:IsPlayer() then
        if attacker == victim then
            logMessage = string.format("[Suicide] > %s killed themselves", victimName)
            local suicideColor = (RhetoricMenu.Settings.event_logger_colors and RhetoricMenu.Settings.event_logger_colors.suicide_color) or Color(255, 200, 200)
            timer.Simple(0.075, function()
                Rethoric_addlogmessage(logMessage, suicideColor)
            end)
        else
            logMessage = string.format("[Kill] > %s %s %s", attacker:Nick(), kills[math.random(#kills)], victimName)
            local killColor = (RhetoricMenu.Settings.event_logger_colors and RhetoricMenu.Settings.event_logger_colors.kill_color) or Color(255, 180, 180)
            timer.Simple(0.075, function()
                Rethoric_addlogmessage(logMessage, killColor)
            end)
        end
    else
        logMessage = string.format("[Kill] > %s was %s by %s", victimName, kills[math.random(#kills)], attacker:GetClass())
        local killColor = (RhetoricMenu.Settings.event_logger_colors and RhetoricMenu.Settings.event_logger_colors.kill_color) or Color(255, 180, 180)
        timer.Simple(0.075, function()
            Rethoric_addlogmessage(logMessage, killColor)
        end)
    end
end)