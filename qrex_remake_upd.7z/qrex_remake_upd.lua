
--[[------------------------------------------------------
    Variables
--------------------------------------------------------]]
local g = {}
g = table.Merge(g,_G) -- some servers break table.Copy _G, workaround
g.Menu = {}

local p = g.LocalPlayer()
local w, h = g.ScrW(), g.ScrH()
local gradient = g.Material("vgui/gradient-l")
local gradient_down = g.Material("gui/gradient_down")
local print = g.print
local Vector = g.Vector
--[[------------------------------------------------------
    Modules
--------------------------------------------------------]]
g.require( "big" )
g.require( "bsendpacket" )

--[[------------------------------------------------------
    Detours / Protections
--[[----------------------------------------------------]]

local function Print( msg )
    msg = tostring(msg or "")
    MsgC( Color(202,136,223), "[QREX] ", Color(149,230,255), msg .. "\n" )
end

--[[------------------------------------------------------
    Features / Options
--------------------------------------------------------]]
g.Options = {
    { "menu", "Aimbot"},
    { "section", "Aimbot", nil, "General" },
    { "section", "Aimbot", nil, "Accuracy" },
    { "section", "Aimbot", nil, "Target Selection" },
    { "section", "Aimbot", nil, "Hitbox Selection" },
    { "checkbox", "Aimbot", nil, "Accuracy", "Compensate Accuracy" },

    { "menu", "Miscellaneous" },
    { "section", "Miscellaneous", nil, "Movement" },
    { "section", "Miscellaneous", nil, "Fake Lag" },
    { "section", "Miscellaneous", nil, "Camera" },
    { "section", "Miscellaneous", nil, "Anti-Aim" },
    { "checkbox", "Miscellaneous", nil, "Movement", "Auto-BunnyHop" },
    { "checkbox", "Miscellaneous", nil, "Movement", "Auto-Strafe" },

    { "checkbox", "Miscellaneous", nil, "Fake Lag", "Enabled" },
    { "slider", "Miscellaneous", nil, "Fake Lag", "Max Choke", 1, 16 },

    { "menu", "Visuals", { "LocalPlayer", "Players" }, 800 },
    { "section", "Visuals", "Players", "ESP", 480, 960 },
    { "section", "Visuals", "Players", "Chams", 480, 960 },
    { "section", "Visuals", "Players", "Other", 480, 960 },
    { "colormixer", "Visuals", "Players", "ESP", "2D Boxes" },
    { "colormixer", "Visuals", "Players", "ESP", "Name ESP" },
    { "colormixer", "Visuals", "Players", "ESP", "Weapon" },
    { "checkbox", "Visuals", "Players", "ESP", "Box Filed" },
    { "checkbox", "Visuals", "Players", "ESP", "Health Bar" },
    { "checkbox", "Visuals", "Players", "ESP", "Skeletons" },
    { "checkbox", "Visuals", "Players", "ESP", "Team Colors" },

    { "menu", "Console", nil, 600, 350 },


    { "section", "Console", nil, "Output", 1090, 560 },

}
--[[------------------------------------------------------
    Functions
--------------------------------------------------------]]
function g.Scale(i)
    return math.max(i*(ScrH()/1440),1) -- scales UI based on resolution
end
function g.AddHook(txt,func)
    -- hook.Add( txt, "QREX|" .. util.CRC(math.random( 10^4 )+SysTime()), func )
    g.hook.Add( txt, "QREX|"..txt, func )
end
--[[------------------------------------------------------
    Fonts
--------------------------------------------------------]]
for i=12, 30 do
    g.surface.CreateFont("qrex."..i,{font="Roboto Bold",size=i,weight=550,})
end
--[[------------------------------------------------------
    Background
--------------------------------------------------------]]
local background = vgui.Create( "DFrame" )
background:DockPadding(0,0,0,0)
background:Dock(FILL)
background:DockMargin(0,0,0,0)
background:SetTitle("")
background:MakePopup()
background:SetDraggable(false)
background:SetKeyboardInputEnabled(false)
background:Center()
background.Paint = function(s,w,h)
    draw.RoundedBox(0,0,0,w,h,Color(0,0,0,66))
end

local MenuHandler = vgui.Create( "DIconLayout", background )
MenuHandler:Dock(FILL)
MenuHandler:DockMargin(16,16,16,16)
MenuHandler:SetSpaceX(8)
MenuHandler:SetSpaceY(4)

--[[--------------------------------------------------------------
    VGUI Elements
----------------------------------------------------------------]]
    local Element = {}
    function Element.FindIndex( ui, page, title )
        if !IsValid(g.Menu[ui or ""]) then return end
        if page then
            return g.Menu[ui] and IsValid(g.Menu[ui][page]) and ( title and IsValid(g.Menu[ui][page][title]) and g.Menu[ui][page][title] ) or g.Menu[ui][page]
        end
        return g.Menu[ui] and ( IsValid(g.Menu[ui][title]) and g.Menu[ui][title] ) or g.Menu[ui]
    end
    --[[------------------------------------------------------
        DFrame > Menu Design
    --------------------------------------------------------]]
        function Element.DScrollPanel( parent )
            if !IsValid(parent) then return end
            local DScrollPanel = vgui.Create( "DScrollPanel", parent )
            local VBar = DScrollPanel:GetVBar()
            VBar:SetWide(4)
            VBar:SetHideButtons(true)
            VBar.Paint = function(s,w,h)
                draw.RoundedBox(0,0,0,w,h,Color(26,26,26))
            end
            VBar.btnGrip.Paint = function(s,h,h)
                draw.RoundedBox(0,0,0,w,h,Color(42,42,42))
            end
            return DScrollPanel
        end

        function Element.CreateDFrame( title, tabs, W, H )
            W, H = W or 500, H or 600

            local DFrame = vgui.Create( "DFrame", MenuHandler )
            DFrame:DockPadding(0,0,0,0)
            DFrame:SetTitle("")
            DFrame:SetDraggable(false)
            DFrame:SetSize(W,H)
            DFrame.Paint = function( s, w, h )
                surface.SetDrawColor(0,0,0)
                surface.DrawOutlinedRect(0,0,w,h,1)
            end

            local DPanel = vgui.Create( "DPanel", DFrame )
            DPanel:Dock( TOP )
            DPanel:DockMargin(1,1,1,0)
            DPanel:SetTall( 25 )
            DPanel.Paint = function( s, w, h )
                draw.RoundedBox(0,0,0,w,h,Color(87,39,210,166))
                draw.SimpleText( title or "", "qrex.14", 4, h/2.1, Color(255,255,255), 0, 1 )
                surface.SetDrawColor(87,39,210)
                surface.DrawRect(0,h-2,w,2)
            end

            local panel = vgui.Create("DPanel",DFrame)
            g.Menu[title] = panel
            panel:Dock(FILL)
            panel:DockMargin(1,0,1,1)
            panel.Paint = function(s,w,h)
                draw.RoundedBox(0,0,0,w,h,Color(28,28,28))
            end

            if tabs then
                local nav = vgui.Create( "DPanel", panel )
                nav:Dock( TOP )
                nav:DockMargin(4,0,4,0)
                nav:SetTall( 30 )
                nav.Paint = function( s, w, h )
                    draw.RoundedBox(0,0,0,w,h,Color(36,36,36))
                    surface.SetDrawColor(42,42,42)
                    surface.DrawRect(0,h-2,w,2)
                end

                local Populate = vgui.Create( "DPanel", panel )
                Populate:Dock( FILL )
                Populate:DockMargin(8,8,8,8)
                Populate.Paint = nil

                local selected = ""
                for i, v in ipairs(tabs) do
                    if !IsValid(nav) then break end

                    local DIconLayout = vgui.Create( "DIconLayout", Populate )
                    g.Menu[title][v] = DIconLayout
                    DIconLayout:Dock( FILL )
                    DIconLayout:DockMargin(5,0,0,0)
                    DIconLayout:SetSpaceX(6)
                    DIconLayout:SetSpaceY(4)
                    DIconLayout.OnMousePressed = function()
                        Element.CloseMixer()
                    end

                    if i != 1 then DIconLayout:SetVisible(false) else selected = v end

                    local DButton = vgui.Create( "DButton", nav )
                    DButton:Dock( LEFT )
                    DButton:SetText( "" )
                    DButton.Think = function(s)
                        s:DockMargin(0,0,2,3)
                        s:SetWide( nav:GetWide()/#tabs )
                    end
                    DButton.Paint = function( s, w, h )
                        local hover = s:IsHovered()
                        local me = (selected == v)
                        draw.RoundedBox(0,0,0,w,h, hover and Color(55,55,55) or Color(44,44,44))
                        draw.SimpleText( v, "qrex.15", w/2, h/2, (me and Color(167,143,228)) or (hover and Color(255,255,255) or Color(255,255,255,155)), 1, 1 )
                    end
                    DButton.DoClick = function()
                        if selected == v then return end
                        g.Menu[title][selected]:SetVisible(false)
                        g.Menu[title][v]:SetVisible(true)
                        selected = v
                    end
                end
            else
                local Populate = vgui.Create( "DPanel", panel )
                Populate:Dock( FILL )
                Populate:DockMargin(8,8,8,8)
                Populate.Paint = nil

                local DIconLayout = vgui.Create( "DIconLayout", Populate )
                g.Menu[title] = DIconLayout
                DIconLayout:Dock( FILL )
                DIconLayout:DockMargin(5,0,0,0)
                DIconLayout:SetSpaceX(6)
                DIconLayout:SetSpaceY(4)
                DIconLayout.OnMousePressed = function()
                    Element.CloseMixer()
                end

            end
            DFrame:ShowCloseButton(false)
        end
    --[[------------------------------------------------------
        DPanel > Section
    --------------------------------------------------------]]
        function Element.CreateSection( ui, page, title, W, H )
            local parent = Element.FindIndex( ui, page, title )
            if !parent then return end
            local W, H = W or 445, H or 505
            local DPanelSection = vgui.Create( "DPanel", parent )
            DPanelSection:SetSize(W*.53,H*.55)
            DPanelSection.Paint = function( s, w, h )
                draw.RoundedBox(0,0,0,w,h,Color(32,32,32))
                surface.SetDrawColor(42,42,42)
                surface.DrawOutlinedRect(0,0,w,h,1)
                surface.SetDrawColor(0,0,0)
                surface.DrawOutlinedRect(1,1,w-2,h-2,1)
            end

            local DPanel = vgui.Create( "DPanel", DPanelSection )
            DPanel:Dock( TOP )
            DPanel:DockMargin(3,3,3,5)
            DPanel:SetTall( 18 )
            DPanel.Paint = function( s, w, h )
                surface.SetDrawColor(151,112,252,99)
                surface.SetMaterial(gradient)
                surface.DrawTexturedRect(0,0,w,h)
                surface.SetDrawColor(151,112,250)
                surface.DrawRect(0,h-2,w,2)
                draw.SimpleText( title, "qrex.13", 3, h/2, Color(255,255,255), 0, 1 )
            end

            local DScrollPanel = Element.DScrollPanel(DPanelSection)
            parent[title] = DScrollPanel
            DScrollPanel:Dock( FILL )
            DScrollPanel:DockMargin(10,8,2,2)
            DScrollPanel.OnMousePressed = function()
                Element.CloseMixer()
            end

            local VBar = DScrollPanel:GetVBar()
            VBar:SetWide(5)
            VBar:SetHideButtons(true)
            VBar.Paint = function(s,w,h)
                draw.RoundedBox(0,0,0,w,h,Color(26,26,26))
            end
            VBar.btnGrip.Paint = function( s, w, h )
                draw.RoundedBox(0,0,0,w,h,Color(42,42,42))
            end

            return DScrollPanel
        end
    --[[------------------------------------------------------
        DCheckBoxLabel > CreateCheckBox
    --------------------------------------------------------]]
        function Element.CreateCheckBox( ui, page, section, name, overwrite )
            local parent = Element.FindIndex( ui, page, section )
            if !parent then return end
            local DCheckBoxLabel = vgui.Create( "DCheckBoxLabel", (overwrite or parent) )
            DCheckBoxLabel:Dock(TOP)
            DCheckBoxLabel:DockMargin(0,0,0,8)
            DCheckBoxLabel:SetTextColor(Color(255,255,255))
            DCheckBoxLabel:SetFont( "qrex.12" )
            DCheckBoxLabel:SetText( name )
            DCheckBoxLabel:SizeToContents()
            DCheckBoxLabel.Button.Paint = function( s, w, h )
                parent[name] = s:GetChecked()
                draw.RoundedBox(0,0,0,w,h,Color(44,44,44))
                if parent[name] then
                    draw.RoundedBox(0,0,0,w,h,Color(151,112,250))
                    draw.SimpleText( "✔", "qrex.15", w/2, h/2, Color(255,255,255), 1, 1 )
                end
                surface.SetDrawColor(0,0,0)
                surface.DrawOutlinedRect(0,0,w,h,1)
            end
            DCheckBoxLabel.OnMousePressed = function()
                Element.CloseMixer()
            end
            return DCheckBoxLabel
        end
    --[[------------------------------------------------------
        DColorMixer > Color Changer
    --------------------------------------------------------]]
        function Element.CloseMixer()
            if !IsValid(Element.Mixer) then return end
            Element.Mixer:Remove()
        end
        Element.Mixer = nil
        function Element.DColorMixer( ui, page, section, name, color )
            local parent =  Element.FindIndex( ui, page, section )
            if !parent then return end
            Element.CloseMixer()
            local x, y = input.GetCursorPos()
            local DPanel = vgui.Create( "DPanel" )
            Element.Mixer = DPanel
            DPanel:SetPos(x,y)
            DPanel:SetSize( 150, 150 )
            DPanel:MoveToFront()
            DPanel:MakePopup()
            DPanel.Paint = function( s, w, h )
                draw.RoundedBox(0,0,0,w,h,Color(30,30,30))
                surface.SetDrawColor(42,42,42)
                surface.DrawOutlinedRect(0,0,w,h,1)
                surface.SetDrawColor(0,0,0)
                surface.DrawOutlinedRect(1,1,w-2,h-2,1)
            end
            local DColorMixer = vgui.Create( "DColorMixer", Element.Mixer )
            DColorMixer:Dock( FILL )
            DColorMixer:DockMargin(6,6,6,6)
            DColorMixer:SetPalette( false )
            DColorMixer:SetWangs( false )
            DColorMixer:SetAlphaBar( false )
            if color then DColorMixer:SetColor(color) end
            DColorMixer.Think = function(s)
                parent[name.."Color"] = s:GetColor()
            end
            return DPanel
        end
        function Element.CreateColorMixer( ui, page, section, name )
            local parent = Element.FindIndex( ui, page, section )
            if !parent then return end
            local DPanel = vgui.Create( "DPanel", parent )
            DPanel:Dock( TOP )
            DPanel:DockMargin(0,0,0,8)
            DPanel:SetTall( 15 )
            DPanel.Paint = nil
            local DButton = vgui.Create( "DButton", DPanel )
            DButton:Dock(RIGHT)
            DButton:DockMargin(0,0,10,0)
            DButton:SetWide( 45 )
            DButton:SetText( "" )
            DButton.col = nil
            DButton.Paint = function( s, w, h )
                surface.SetDrawColor(0,0,0)
                surface.DrawOutlinedRect(0,0,w,h,1)
                s.col = parent[name.."Color"] or Color(200,200,200)
                surface.SetDrawColor(s.col)
                surface.SetMaterial(gradient_down)
                surface.DrawTexturedRect(1,1,w-2,h-2)
            end
            DButton.DoClick = function(s)
                Element.DColorMixer( ui, page, section, name, s.col )
            end
            local checkbox = Element.CreateCheckBox(ui,page,section,name,DPanel)
            return DPanel
        end
    --[[------------------------------------------------------
        DComboBox > DropDown Boxes
    --------------------------------------------------------]]
        function Element.CreateDropDown( ui, page, section, name, dropdown, tbl )
            if !dropdown then return end
            local parent = Element.FindIndex( ui, page, section )
            if !parent then return end
            tbl = tbl or {}
            local DComboBox = vgui.Create( "DComboBox", parent )
            DComboBox:Dock( TOP )
            DComboBox:DockMargin(0,10,10,8)
            DComboBox:SetTextColor(Color(255,255,255))
            DComboBox:SetFont( "qrex.16" )
            DComboBox:SetValue( dropdown )
            for k, v in pairs( tbl ) do DComboBox:AddChoice( k ) end
            DComboBox:GetChildren()[1].Paint = function( s, w, h )
                draw.SimpleText( "▼", "qrex.16", w/2, h/2, Color(194,190,190,44), 1, 1 )
            end
            DComboBox.Paint = function( s, w, h )
                surface.SetDrawColor(0,0,0)
                surface.DrawOutlinedRect(0,0,w,h,1)
                draw.RoundedBox(0,1,1,w-2,h-2,Color(44,44,44))
                DisableClipping(true)
                draw.SimpleText(name,"qrex.17",2,-h*.32,Color(255,255,255,220),0,1)
                DisableClipping(false)
            end
            DComboBox.OnMenuOpened = function( panel )
                panel:GetChildren()[2].Paint = function( s, w, h )
                    surface.SetDrawColor(0,0,0)
                    surface.DrawOutlinedRect(0,0,w,h,1)
                    draw.RoundedBox(0,1,1,w-2,h-2,Color(44,44,44))
                end
            end
            DComboBox.OnSelect = function(_,_,d)
                parent[name] = d
            end
            return DComboBox
        end
    --[[------------------------------------------------------
        DNumSlider > Sliders
    --------------------------------------------------------]]
        function Element.CreateSlider( ui, page, section, name, min, max )
            local parent = Element.FindIndex( ui, page, section )
            if !parent then return end
            parent[name] = min
            local DNumSlider = vgui.Create( "DNumSlider", parent )
            DNumSlider:Dock( TOP )
            DNumSlider:DockMargin(-200,8,-40,8)
            DNumSlider:SetTall(6)
            DNumSlider:SetText("")
            DNumSlider:SetMin(min)
            DNumSlider:SetMax(max)
            DNumSlider:SetValue(min)
            DNumSlider.Slider.Paint = function( s, w, h )
                local value = tonumber( DNumSlider:GetValue() )
                surface.SetDrawColor(0,0,0)
                surface.DrawOutlinedRect(0,0,w,h,1)
                draw.RoundedBox(0,1,1,w-2,h-2,Color(55,55,55))
                surface.SetDrawColor(133,123,231)
                surface.DrawRect(1,1,w*math.Clamp(value/max,0,1)-2,h-2)
                DisableClipping( true )
                draw.SimpleText( name, "qrex.12", 8, -h*1.3, Color(255,255,255,155), 0, 1 )
                draw.SimpleTextOutlined(math.ceil(value), "qrex.12", w* math.Clamp(value/max,0,1)-2, h/2+5, Color(255,255,255,100), 1, 1, 1, Color(0,0,0) )
                DisableClipping( false )
            end
            DNumSlider.OnValueChanged = function(_,i)
                parent[name] = math.ceil(i)
            end

            DNumSlider.Slider:GetChildren()[1].Paint = nil
            DNumSlider:GetChildren()[1].Paint = nil

            return DNumSlider
        end

    function g.GenerateOptions()
        for _, t in ipairs( g.Options ) do
            local e = t[1]
            if e == "menu" then
                Element.CreateDFrame( t[2], t[3], t[4], t[5] )
            elseif e == "section" then
                Element.CreateSection( t[2], t[3], t[4], t[5], t[6] )
            elseif e == "checkbox" then
                Element.CreateCheckBox( t[2], t[3], t[4], t[5] )
            elseif e == "colormixer" then
                Element.CreateColorMixer( t[2], t[3], t[4], t[5], t[6] )
                elseif e == "dropdown" then
                    Element.CreateDropDown( t[2], t[3], t[4], t[5], t[6] )
            elseif e == "slider" then
                Element.CreateSlider( t[2], t[3], t[4], t[5], t[6], t[7] )
            end
        end
    end
    g.GenerateOptions()
--[[--------------------------------------------------------------
    VGUI Elements END
----------------------------------------------------------------]]

--[[--------------------------------------------------------------
    Lag Composition
----------------------------------------------------------------]]
    local LagComposition = {}

    --[[   todo
        improve this shit
    ]]

    function LagComposition:FakeLag( cmd )
        bSendPacket = true
        local fakelag = g.Menu["Miscellaneous"] and g.Menu["Miscellaneous"]["Fake Lag"]
        if !p:Alive() or !fakelag or !fakelag["Enabled"] then return end
        local ticks = math.Clamp( fakelag["Max Choke"] or 1, 1, 16 )
        local vel = p:GetVelocity()
        bSendPacket = big.GetChokedPackets() >= ticks
        if vel == Vector(0,0,0) then bSendPacket = true end
        Print( "[Fake-Lag] ticks: " .. ticks .. " Packets Missed: " .. big.GetChokedPackets() .. " bSendPacket: " .. tostring(bSendPacket) )
    end

--[[--------------------------------------------------------------
    Lag Composition END
----------------------------------------------------------------]]

--[[--------------------------------------------------------------
    Navigation Pathing
----------------------------------------------------------------]]
    local Navigation = {}

    function Navigation:PlayerPath( p )
        if !IsValid(p) then return end
        local pos = p:GetPos()
        local vel = Vector(p:GetVelocity())
        local tr = util.TraceHull({
            start = pos,
            endpos = pos+vel,
            mins = p:OBBMins(),
            maxs = p:OBBMaxs(),
            mask = MASK_PLAYERSOLID,
        })
        return tr
    end
--[[--------------------------------------------------------------
    Navigation Pathing END
----------------------------------------------------------------]]

--[[--------------------------------------------------------------
    Aimbot Targeting
----------------------------------------------------------------]]
    local Aimbot = {}
    g.EyeAngle = LocalPlayer():EyeAngles()

    g.AddHook( "InputMouseApply", function( cmd, x, y, ang )
        local m_pitch = GetConVar("m_pitch"):GetFloat()
        local m_yaw = GetConVar("m_yaw"):GetFloat()
        g.EyeAngle.pitch = g.EyeAngle.pitch + (y*m_pitch)
        g.EyeAngle.pitch = math.Clamp(math.NormalizeAngle(g.EyeAngle.pitch),-89,89)
        g.EyeAngle.yaw = g.EyeAngle.yaw - (x*m_yaw)
        g.EyeAngle.yaw = math.NormalizeAngle(g.EyeAngle.yaw)
    end )

    g.AddHook( "CalcView", function( p, _, angles )
        local aim = g.Menu["Aimbot"] and g.Menu["Aimbot"]["Accuracy"]
        if aim and aim["Compensate Accuracy"] then
            Print(g.EyeAngle)
            angles:Sub(p:GetViewPunchAngles())
        end
    end )
--[[--------------------------------------------------------------
    Aimbot Targeting END
----------------------------------------------------------------]]

--[[--------------------------------------------------------------
    Movement
----------------------------------------------------------------]]
    local Movement = {}
    function Movement:Bunnyhop( cmd )
        local bhop = Element.FindIndex( "Miscellaneous", nil, "Movement" )
        if !bhop or !bhop["Auto-BunnyHop"] then return end
        local p = LocalPlayer()
        if p:OnGround() then
            cmd:KeyDown( IN_JUMP )
        else
            cmd:RemoveKey( IN_JUMP )
        end
    end
    function Movement:AutoStrafe( cmd )
        local bhop = Element.FindIndex( "Miscellaneous", nil, "Movement" )
        if !bhop or !bhop["Auto-BunnyHop"] or !bhop["Auto-Strafe"] then return end
        local p = LocalPlayer()
        local vel = p:GetVelocity()
        if !p:IsOnGround() and p:GetMoveType() != MOVETYPE_NOCLIP and p:Alive() then
            cmd:SetForwardMove(5850/vel:Length2D())
            cmd:SetSideMove(cmd:CommandNumber() % 2 == 0 and -400 or 400)
        end
    end
    g.AddHook( "CreateMove", function( cmd )
        LagComposition:FakeLag( cmd )
        cmd:SetViewAngles(g.EyeAngle)
        Movement:Bunnyhop(cmd)
        Movement:AutoStrafe(cmd)
    end )
--[[--------------------------------------------------------------
    Movement END
----------------------------------------------------------------]]

local base_color = Color(200,200,200)

g.AddHook( "PostDrawOpaqueRenderables", function()
    -- local p = LocalPlayer()
    -- local path = Navigation:PlayerPath(p)
    -- local vel = p:GetVelocity()
    -- cam.Start3D()
    --     render.DrawWireframeBox( path.HitPos, p:GetAngles(), p:OBBMins(), p:OBBMaxs(), Color(255,255,255), true )
    -- cam.End3D()
end )

g.AddHook( "PostDrawHUD", function()
    local visual = g.Menu["Visuals"]
    if !visual then return end

    for _, pp in ipairs(player.GetAll()) do
        if !IsValid(pp) then continue end
        if p == pp then continue end
        local pos = pp:GetPos()
        local min, max = pp:GetCollisionBounds()
        local pos2 = pos+Vector(0,0,max.z)
        pos, pos2 = pos:ToScreen(), pos2:ToScreen()
        local h = pos.y-pos2.y
        local w = h/2
        if visual["Players"]["ESP"]["2D Boxes"] then
            local col = visual["Players"]["ESP"]["2D BoxesColor"] or base_color

            if visual["Players"]["ESP"][ "Team Colors" ] then col = team.GetColor(pp:Team()) end

            if visual["Players"]["ESP"]["Box Filed"] then
                draw.RoundedBox( 0, pos.x-w/2, pos.y-h, w, h, (col and Color(col.r,col.g,col.b,22) or Color(255,255,255,22) ) )
            end
            surface.SetDrawColor(0,0,0,255)
            surface.DrawOutlinedRect(pos.x-w/2+1,pos.y-h+1,w-2,h-2)
            surface.SetDrawColor(0,0,0,255)
            surface.DrawOutlinedRect(pos.x-w/2-1,pos.y-h-1,w+1,h+1)
            surface.SetDrawColor(col)
            surface.DrawOutlinedRect(pos.x-w/2,pos.y-h,w,h)
        end
        if visual["Players"]["ESP"]["Name ESP"] then
            local col = visual["Players"]["ESP"]["Name ESPColor"] or Color(255,255,255)
            draw.SimpleTextOutlined(pp:Name(),"qrex.14",pos.x,pos.y-h-(h*.03),(col and Color(col.r,col.g,col.b)),1,1,1,Color(0,0,0))
        end
        if visual["Players"]["ESP"]["Weapon"] then
            local wep = IsValid( pp:GetActiveWeapon() ) and pp:GetActiveWeapon() or nil
            local col = visual["Players"]["ESP"]["WeaponColor"] or Color(255,255,255)
            if wep then
                draw.SimpleTextOutlined(language.GetPhrase(wep:GetPrintName()),"qrex.14",pos.x,pos.y+(h*.03),(col and Color(col.r,col.g,col.b)),1,1,1,Color(0,0,0))
            end
        end
        if visual["Players"]["ESP"]["Health Bar"] then
            pp.oldhp = Lerp( FrameTime() * 5, pp.oldhp or pp:Health(), pp:Health() )
            local clamp = math.Clamp( pp.oldhp/pp:GetMaxHealth(), 0, 1 )
            local c = HSVToColor( clamp*110, 1, 1 )
            local hp = h * pp.oldhp / pp:GetMaxHealth()
            if(hp > h) then hp = h end
            local diff = h-hp
            local x = pos.x-w/2-7
            local ww = 4
            surface.SetDrawColor(0,0,0,220)
            surface.DrawRect(x,pos.y-h-1,ww,(h))
            surface.SetDrawColor(c)
            surface.DrawRect(x+1,pos.y-h+1+diff,ww-2,(h-1)*clamp)
        end
        if visual["Players"]["ESP"]["Skeletons"] then
            local pos = pp:GetPos() -- needed default pos
            for i=0, pp:GetBoneCount()-1 do
                local parent = pp:GetBoneParent(i)
                if(!parent) then continue end
                local bonepos = pp:GetBonePosition(i)
                if(bonepos == pos) then continue end
                local parentpos = pp:GetBonePosition(parent)
                if(!bonepos or !parentpos) then continue end
                local s1, s2 = bonepos:ToScreen(),parentpos:ToScreen()
                local col = visual["Players"]["ESP"]["SkeletonsColor"] or color_white
                if visual["Players"]["ESP"][ "Team Colors" ] then col = team.GetColor(pp:Team()) end
                surface.SetDrawColor(col)
                surface.DrawLine(s1.x,s1.y,s2.x,s2.y)
            end
        end
    end
end )

--[[------------------------------------------------------
    Open Menu
--------------------------------------------------------]]
local toggle = false
local openKey = KEY_F2 -- F2
hook.Add( "Think", "qrex.temp", function()
    if input.IsKeyDown(openKey) and !toggle then
        toggle = true
        Element.CloseMixer()
        background:SetVisible(!background:IsVisible())
        gui.EnableScreenClicker(background:IsVisible())
    elseif !input.IsKeyDown(openKey) then
        toggle = false
    end
end )
background:ShowCloseButton(false)


-- function ib.RemapClamped(val, A, B, C, D)
--     if A == B then return val >= B and D or C end
--     local cval = (val - A) / (B - A)
--     cval = math.Clamp(cval, 0.0, 1.0)
--     return C + (D - C) * cval
-- end

-- local function PredictSpread(cmd, ang) -- HUGE FUCKING THANKS TO S0LUM'S NCMD (and data for helping me figure shit out)
--     if (me:Team() == TEAM_SPECTATOR and not gBool("Main Menu", "General Utilities", "Spectator Mode")) or not me:Alive() or me:Health() < 1 then return end

--     local wep = me:GetActiveWeapon()

--     if gBool("Aim Assist", "Miscellaneous", "Remove Bullet Spread") and me:GetActiveWeapon():IsValid() and me:Alive() and me:Health() > 0 then
--         local class = wep:GetClass()
--         local cone = bi.spread.Spread[class]
--         if not cone then return ang end
--         if class == 'weapon_pistol' then
--             local ramp = ib.RemapClamped(wep:GetInternalVariable('m_flAccuracyPenalty'), 0, 1.5, 0, 1)
--             cone = LerpVector(ramp, Vector(0.00873, 0.00873, 0.00873), Vector(0.05234, 0.05234, 0.05234))
--         end

--         local seed = ib.spread.md5.PseudoRandom(cm.CommandNumber(cmd))
--         local x, y = ib.spread.enginespread[seed][1], ib.spread.enginespread[seed][2]
--         local forward, right, up = ang:Forward(), ang:Right(), ang:Up()
--         local retvec = forward + (x * cone[1] * right * -1) + (y * cone[2] * up * -1)
--         local spreadangles = retvec:Angle()
--         spreadangles:Normalize()
--         return spreadangles
--     end

-- end
