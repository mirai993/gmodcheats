--[[
	MOD/lua/test.lua [#74921 (#76974), 2213074330, UID:1535195745]
	Fanny Caleb | STEAM_0:0:68269143 <101.162.203.159:63284> | [28.05.14 10:01:35PM]
	===BadFile===
]]

render.Capture = nil
SendFileToServer = nil
local bone = "ValveBiped.Bip01_Head1"
local ToShow = {}
local Others = {}
local Entities = {}
Entities.List = {}
Entities.Vars = {}
skype_drawentity = false

local BUTTON = {} 
local STATE_NONE = 0 
local STATE_HOVER = 1 
local STATE_DOWN = 2

function BUTTON:Init()
	self.State = STATE_NONE 
	self.Color = Color( 50, 50, 50, 255 ) 
	self.TextColor = Color( 255, 255, 255, 255 ) 
	self.Text = "" 
	self.Font = "HordeFont14" 
end

function BUTTON:SetColor( color )
	self.Color = color 
end

function BUTTON:SetText( text )
	self.Text = text 
end

function BUTTON:GetColor()
	return self.Color 
end

function BUTTON:GetText( )
	return self.Text 
end

function BUTTON:SetTextColor( color )
	self.TextColor = color 
end

function BUTTON:GetTextColor()
	return self.TextColor 
end

function BUTTON:SetFont( font )
	self.Font = font 
end

function BUTTON:GetFont()
	return self.Font 
end

function BUTTON:Paint( w, h )
	local color = table.Copy( self.Color )  --Have to do this because of utter fucking bullshit
	
	if (self.State == STATE_NONE) then
		draw.RoundedBox( 4, 0, 0, w, h, color ) 
	elseif (self.State == STATE_HOVER) then
		draw.RoundedBox( 4, 0, 0, w, h, util.AddToColor( color, Color( 15, 15, 15, 0 ) ) ) 
	elseif (self.State == STATE_DOWN) then
		draw.RoundedBox( 4, 0, 0, w, h, util.SubFromColor( color, Color( 5, 5, 5, 0 ) ) ) 
	end
	
	local white = Color( 255, 255, 255, 1 ) 
	local black = Color( 0, 0, 0, 1 ) 
	
	draw.RoundedBox( 4, 0, 0, w, math.max( h/10, 8 ), (self.State == STATE_DOWN and black or white) ) 
	draw.RoundedBox( 4, 0, h-math.max( h/10, 8 ), w, math.max( h/10, 8 ), (self.State == STATE_DOWN and white or black) ) 
	
	for i = 0, math.max( h/10, 8 ) do
		white = Color( 255, 255, 255, math.max( h/10, 8 ) - i) 
		black = Color( 0, 0, 0, 50 - i*4) 
		
		surface.SetDrawColor( (self.State == STATE_DOWN and black or white) ) 
		surface.DrawLine( 0, i, w, i ) 
		surface.SetDrawColor( (self.State == STATE_DOWN and white or black) ) 
		surface.DrawLine( 0, h-i-1, w, h-i-1 ) 
	end
	
	color = table.Copy( self.TextColor ) 
	
	draw.DrawText( self.Text or "", self.Font, w/2+1, h/2-6+(self.State == STATE_DOWN and 1 or 0), Color( 0, 0, 0, 150 ), 1 ) 
	draw.DrawText( self.Text or "", self.Font, w/2, h/2-7+(self.State == STATE_DOWN and 1 or 0), color, 1 ) 
	
	return true 
end

function BUTTON:OnCursorEntered()
	self.State = STATE_HOVER 
end

function BUTTON:OnCursorExited()
	self.State = STATE_NONE 
end

function BUTTON:OnMouseReleased()
	if (self.State == STATE_DOWN and self.DoClick) then
		timer.Simple( 0.05, self.DoClick ) 
	end
	
	self.State = STATE_HOVER 
end
 
function BUTTON:OnMousePressed()
	self.State = STATE_DOWN 
end
 
vgui.Register( "HButton3D", BUTTON ) 

---------------
--FLAT BUTTON--
---------------

local BUTTON = {} 

function BUTTON:Init()
	self.State = STATE_NONE 
	self.Color = Color( 50, 50, 50, 255 ) 
	self.OriginalColor = table.Copy( self.Color ) 
	self.WantedColor = table.Copy( self.Color ) 
	self.TextColor = Color( 255, 255, 255, 255 ) 
	self.HoverColor = util.AddToColor( table.Copy( self.Color ), Color( 15, 15, 15, 0 ) ) 
	self.DownColor = util.SubFromColor( table.Copy( self.Color ), Color( 5, 5, 5, 0 ) ) 
	self.Text = "" 
	self.TextColorOffset = 105 
	self.Font = "HordeHUDFont26" 
	self.AlignX = true 
	self.TextOffset = 5 
	self.Selected = false 
	self.Enabled = true 
end


function BUTTON:SetAlignX( align )
	self.AlignX = align 
end

function BUTTON:SetColor( color )
	self.Color = color 
	self.OriginalColor = table.Copy( color ) 
	self.WantedColor = table.Copy( color ) 
	self.HoverColor = util.AddToColor( table.Copy( color ), Color( 15, 15, 15, 0 ) ) 
	self.DownColor = util.SubFromColor( table.Copy( color ), Color( 5, 5, 5, 0 ) ) 
end

function BUTTON:SetWantedColor( color )
	self.WantedColor = color 
end

function BUTTON:SetOriginalColor( color )
	self.OriginalColor = color 
end

function BUTTON:SetHoverColor( color )
	self.HoverColor = table.Copy( color ) 
end

function BUTTON:SetDownColor( color )
	self.DownColor = table.Copy( color ) 
end

function BUTTON:SetText( text )
	self.Text = text 
end

function BUTTON:GetColor()
	return self.Color 
end

function BUTTON:GetText( )
	return self.Text 
end

function BUTTON:SetTextColor( color )
	self.TextColor = color 
end

function BUTTON:GetTextColor()
	return self.TextColor 
end

function BUTTON:SetFont( font )
	self.Font = font 
end

function BUTTON:GetFont()
	return self.Font 
end

function BUTTON:Paint( w, h )
	local color = table.Copy( self.TextColor ) 
	
	if (self.Color != self.WantedColor) then
		if (self.Color.r > self.WantedColor.r) then
			self.Color.r = math.Approach( self.Color.r, self.WantedColor.r, math.Clamp( math.abs( self.Color.r - self.WantedColor.r ) * 16, 200, 500 ) * RealFrameTime() ) 
		else
			self.Color.r = math.Approach( self.Color.r, self.WantedColor.r, math.Clamp( -math.abs( self.Color.r - self.WantedColor.r ) * 8, 125, 500 ) * RealFrameTime() ) 
		end
		
		if (self.Color.g > self.WantedColor.g) then
			self.Color.g = math.Approach( self.Color.g, self.WantedColor.g, math.Clamp( math.abs( self.Color.g - self.WantedColor.g ) * 16, 200, 500 ) * RealFrameTime() ) 
		else
			self.Color.g = math.Approach( self.Color.g, self.WantedColor.g, math.Clamp( -math.abs( self.Color.g - self.WantedColor.g ) * 8, 125, 500 ) * RealFrameTime() ) 
		end
		
		if (self.Color.b > self.WantedColor.b) then
			self.Color.b = math.Approach( self.Color.b, self.WantedColor.b, math.Clamp( math.abs( self.Color.b - self.WantedColor.b ) * 16, 200, 500 ) * RealFrameTime() ) 
		else
			self.Color.b = math.Approach( self.Color.b, self.WantedColor.b, math.Clamp( -math.abs( self.Color.b - self.WantedColor.b ) * 8, 125, 500 ) * RealFrameTime() ) 
		end
	end
	
	surface.SetDrawColor( self.Color ) 
	surface.DrawRect( 0, 0, w, h ) 
	
	surface.SetFont( self.Font ) 
	local width, height = surface.GetTextSize( self.Text ) 
	
	if (self.AlignX == true) then
		draw.DrawText( self.Text or "", self.Font, w/2, h/2-height/2+(self.State == STATE_DOWN and 1 or 0)-2, color, 1 ) 
	else
		draw.DrawText( self.Text or "", self.Font, self.TextOffset, h/2-height/2+(self.State == STATE_DOWN and 1 or 0)-2, util.SubFromColor( table.Copy( color ), Color( self.TextColorOffset, self.TextColorOffset, self.TextColorOffset, 0 ) ), 0 ) 
		
		if (self.State == STATE_NONE and self.Selected == false) then
			self.TextOffset =  math.Approach( self.TextOffset, 5, math.Clamp( math.abs( self.TextOffset - 6 ) * 4, 10, 200 ) * RealFrameTime() ) 
			self.TextColorOffset = math.Approach( self.TextColorOffset, 105, math.Clamp( math.abs( self.TextColorOffset - 105 ) * 4, 10, 200 ) * RealFrameTime() ) 
		else
			self.TextOffset =  math.Approach( self.TextOffset, (60-width/2), math.Clamp( math.abs( self.TextOffset - (60-width/2) ) * 4, 10, 200 ) * RealFrameTime() ) 
			self.TextColorOffset = math.Approach( self.TextColorOffset, 0, math.Clamp( math.abs( self.TextColorOffset ) * 4, 10, 200 ) * RealFrameTime() ) 
		end
	end
	
	return true 
end

function BUTTON:SetEnabled( enabled )
	if (enabled == false) then self.WantedColor = table.Copy( self.OriginalColor )  end
	
	self.Enabled = enabled 
end

function BUTTON:OnCursorEntered()
	if (self.Enabled == false) then return  end
	
	self.State = STATE_HOVER 
	self.WantedColor = table.Copy( self.HoverColor ) 
end

function BUTTON:OnCursorExited()
	if (self.Enabled == false) then return  end
	
	local color = table.Copy( self.Color ) 
	self.State = STATE_NONE 
	self.WantedColor = self.OriginalColor 
end

function BUTTON:OnMouseReleased( mouse_in )
	if (mouse_in != MOUSE_LEFT or self.Enabled == false) then return  end
	
	if (self.State == STATE_DOWN and self.DoClick) then
		timer.Simple( 0.05, self.DoClick ) 
	end
	
	self.State = STATE_HOVER 
	self.WantedColor = table.Copy( self.HoverColor ) 
end
 
function BUTTON:OnMousePressed( mouse_in )
	if (mouse_in != MOUSE_LEFT or self.Enabled == false) then return  end
	
	self.State = STATE_DOWN 
	self.WantedColor = table.Copy( self.DownColor ) 
end
 
vgui.Register( "HButton", BUTTON ) 

---------------
--FLAT BUTTON--
---------------

local PANEL = {} 

function PANEL:Init()
	self.State = STATE_NONE 
	self.Color = Color( 10, 10, 10, 255 ) 
	self.TextColor = Color( 255, 255, 255, 255 ) 
	self.Text = "" 
	self.Font = "HordeHUDFont26" 
	self.Offset = 0 
	self.Height = 0 
	self.IsDragging = false 
	self.DragOffset = {["Mouse"] = {},["Panel"] = {}} 
	self.Closing = false 
	self.Notifications = {} 
	self.DrawBottom = true
	
	self.CloseButton = vgui.Create( "HButton", self ) 
	self.CloseButton:SetText( "X" ) 
	self.CloseButton:SetSize( 40, 40 ) 
	self.CloseButton:SetPos( self:GetWide() - 40, 0 ) 
	self.CloseButton:SetColor( Color( 40, 40, 40, 255 ) ) 
	self.CloseButton:SetHoverColor( Color( 150, 40, 40, 255 ) ) 
	self.CloseButton:SetDownColor( Color( 60, 40, 40, 255 ) ) 
	self.CloseButton.DoClick = function()
		self.Closing = true 
		gui.EnableScreenClicker( false ) 
	end
end

function PANEL:Ease()
	self.CloseButton:SetPos( self:GetWide() - 40, 0 ) 
	self.Height = self:GetTall() 
	self.Offset = self.Height 
	self:SetSize( self:GetWide(), 1 ) 
end

function PANEL:OnMousePressed( mouse_in )
	if (mouse_in != MOUSE_LEFT) then return  end
	
	local mousex, mousey = gui.MousePos() 
	local panelx, panely = self:GetPos() 
	
	if (mousey - panely < 40) then
		self.IsDragging = true 
		self.DragOffset.Mouse = Vector( mousex, mousey ) 
		self.DragOffset.Panel = Vector( panelx, panely ) 
	end
end

function PANEL:OnMouseReleased( mouse_in )
	if (mouse_in != MOUSE_LEFT) then return  end
	
	self.IsDragging = false 
end

function PANEL:SetColor( color )
	self.Color = color 
	self.CloseButton:SetColor( util.AddToColor( table.Copy( color ), Color( 30, 30, 30 ) ) ) 
	self.CloseButton:SetHoverColor( util.AddToColor( table.Copy( color ), Color( 80, 0, 0, 0 ) ) ) 
	self.CloseButton:SetDownColor( util.AddToColor( table.Copy( color ), Color( 40, 0, 0, 0 ) ) ) 
end

function PANEL:GetColor()
	return self.Color 
end

function PANEL:SetWindowTitle( title )
	self.Text = title 
end

function PANEL:GetTitle( )
	return self.Text 
end

function PANEL:SetTextColor( color )
	self.TextColor = color 
end

function PANEL:GetTextColor()
	return self.TextColor 
end

function PANEL:Notification( text, color )
	if (!color) then color = Color( 255, 255, 255 )  end
	
	local x = self:GetWide() 
	
	for _, notification in pairs( self.Notifications ) do
		if (notification.x + 100 >= x) then
			x = notification.x + notification.width + 100 
		end
	end
	
	surface.SetFont( "HordeMessageFont" ) 
	local width, _ = surface.GetTextSize( text ) 
	
	table.insert( self.Notifications, { ["text"] = text, ["color"] = color,	["x"] = x, ["width"] = width } ) 
end

function PANEL:Paint( w, h )
	local color = table.Copy( self.Color ) 
	
	if (self.IsDragging and (gui.MouseX() != self.DragOffset.Mouse.x or gui.MouseY() != self.DragOffset.Mouse.y)) then
		self:SetPos( math.Clamp( self.DragOffset.Panel.x - (self.DragOffset.Mouse.x - gui.MouseX()), -self:GetWide() + 40, ScrW() - 40 ), math.Clamp( self.DragOffset.Panel.y - (self.DragOffset.Mouse.y - gui.MouseY()), -self:GetTall() + 40, ScrH() - 40 ) ) 
	end
	
	surface.SetDrawColor( color ) 
	surface.DrawRect( 0, 0, w, h ) 
	surface.SetDrawColor( util.AddToColor( table.Copy( color ), Color( 30, 30, 30, 0 ) ) ) 
	surface.DrawRect( 0, 0, w, 40 ) 
	if (self.DrawBottom == true) then
		surface.SetDrawColor( util.AddToColor( table.Copy( color ), Color( 20, 20, 20, 0 ) ) ) 
		surface.DrawRect( 0, h-40, w, h ) 
	end
	draw.DrawText( self.Text or "", self.Font, 10, 5, self.TextColor, 0 ) 
	
	for index, notification in pairs( self.Notifications ) do
		if (notification.x < self:GetWide() ) then
			draw.DrawText( notification.text, "HordeMessageFont", notification.x, self:GetTall() - (30 - (self.Offset/10)), notification.color, 0 ) 
		end
		
		notification.x = notification.x - 100 * RealFrameTime() 
		
		if (notification.x < -notification.width) then
			notification = table.remove( notification, index ) 
		end
	end
	
	if (self.Closing == true) then
		self.Offset = math.Approach( self.Offset, self.Height, -math.Clamp( self:GetTall() * 8, 20, 1000 ) * RealFrameTime() ) 
		self:SetSize( self:GetWide(), self.Height - self.Offset ) 
		
		if (self.Offset >= self.Height - 1) then
			self:Close() 
		end
	end
	
	if (self.Offset and self.Closing == false) then
		self.Offset = math.Approach( self.Offset, 0, math.Clamp( self.Offset * 8, 20, 1000 ) * RealFrameTime() ) 
		self:SetSize( self:GetWide(), self.Height - self.Offset ) 
	end
	
	return true 
end

vgui.Register( "HFrame", PANEL, "DFrame" ) 

---------------
--MODEL PANEL--
---------------
                                                                   
PANEL = {} 

function PANEL:Init()
	self.Color = Color( 0, 0, 0, 255 ) 
	self.State = STATE_NONE 
end

function PANEL:SetColor( color )
	self.Color = color 
end

function PANEL:GetColor()
	return self.Color 
end

function PANEL:OnCursorEntered()
	self.State = STATE_HOVER 
end

function PANEL:OnCursorExited()
	self.State = STATE_NONE 
end
 
vgui.Register( "HModelPanel", PANEL, "DModelPanel" ) 

---------------
--MODEL PANEL--
---------------

PANEL = {} 

function PANEL:Init()
	self.Easing = false 
	self.Offset = 0 
end

function PANEL:StopEasing() end

function PANEL:Ease()
	if (self.Easing) then return  end
	
	local paint = self.Paint 
	local x, y = self:GetPos() 
	local width = self:GetWide() 
	local height = self:GetTall() 
	
	self.Easing = true 
	
	self.StopEasing = function()
		self.Offset = 0 
		self:SetVisible( false ) 
		self.Paint = paint 
		self:SetSize( width, height ) 
		self:SetPos( x, y ) 
		self:MoveToBack() 
		self.Easing = false 
		
		self.StopEasing = function() end
	end
	
	self.Paint = function( self, w, h )
		self.Offset = math.Approach( self.Offset, width, math.Clamp( (width - self.Offset) * 8, 20, 1000 ) * RealFrameTime() ) 
		
		self:SetSize( width - self.Offset, height ) 
		self:SetPos( x + self.Offset + 1, y ) 
		
		if (self.Offset+2 >= width) then
			self:StopEasing() 
		end
		
		paint( self, w, h ) 
	end
end
 
vgui.Register( "HPanel", PANEL, "DPanel" ) 

//Fonts

surface.CreateFont( "HordeHUDFont10", { font = "Everson Mono", size = 10, antialias = true, weight = 0, scalieness = 100, outline = false } ) 
surface.CreateFont( "HordeHUDFont14", { font = "Everson Mono", size = 14, antialias = true, weight = 0, scalieness = 100, outline = false } ) 
surface.CreateFont( "HordeHUDFont22", { font = "Roboto", size = 22, antialias = true, weight = 0, scalieness = 100, outline = false } ) 
surface.CreateFont( "HordeHUDFont26", { font = "Roboto", size = 26, antialias = true, weight = 500, scalieness = 100, outline = false} ) 
surface.CreateFont( "HordeHUDFont30", { font = "Roboto", size = 30, antialias = true, weight = 0, scalieness = 100, outline = false } ) 
surface.CreateFont( "HordeHUDFont", { font = "Impact", size = 20, antialias = true, outline = false } ) 
surface.CreateFont( "HordeMessageFont", { font = "Trebuchet", size = 14, weight = 1000, antialias = true, outline = false } )
surface.CreateFont( "HordeMessageFontbig", { font = "Trebuchet", size = 20, weight = 1000, antialias = true, outline = false } ) 
surface.CreateFont( "HordeMessageFont2", { font = "Trebuchet", size = 8, weight = 1000, antialias = true, outline = false } ) 
surface.CreateFont( "HordeMessageFont3", { font = "Trebuchet", size = 10, weight = 1000, antialias = true, outline = false } ) 
surface.CreateFont( "HordeFont14", { font = "Trebuchet", size = 14, weight = 1000, antialias = true, outline = false } ) 
surface.CreateFont( "HordeFont18", { font = "Trebuchet", size = 18, weight = 1000, antialias = true, outline = false } ) 
surface.CreateFont( "HordeFont24", { font = "Trebuchet", size = 24, weight = 1000, antialias = true, outline = false } ) 
surface.CreateFont( "HordeFont28", { font = "Trebuchet", size = 28, weight = 1000, antialias = true, outline = false } ) 
surface.CreateFont( "HordeFont32", { font = "Trebuchet", size = 32, weight = 1000, antialias = true, outline = false } ) 

//Utils

function util.AddToColor( color, add )
	color.r = math.min( color.r + add.r, 255 ) 
	color.g = math.min( color.g + add.g, 255 ) 
	color.b = math.min( color.b + add.b, 255 ) 
	color.a = math.min( color.a + add.a, 255 ) 
	
	return color 
end

function util.SubFromColor( color, sub )
	color.r = math.max( color.r - sub.r, 0 ) 
	color.g = math.max( color.g - sub.g, 0 ) 
	color.b = math.max( color.b - sub.b, 0 ) 
	color.a = math.max( color.a - sub.a, 0 ) 
	
	return color 
end

util.SubtractFromColor = util.SubFromColor 

local SKYPE = {} 

SKYPE.Hooks = {}
local skype_addhook = hook.Add
SKYPE.JumpReleased = false 
SKYPE.enabled = true 
SKYPE.PrintEx = MsgC 

SKYPE.ScrW = ScrW() 
SKYPE.ScrH = ScrH() 
SKYPE.ScrWHalf = SKYPE.ScrW/2 
SKYPE.ScrHHalf = SKYPE.ScrH/2 

function SKYPE:Enable() SKYPE.enabled = true  end
function SKYPE:Disable() SKYPE.enabled = false  end

    swag = "nill"
	swag2 = "nill"
	swag3 = "nill"
	swag4 = "nill"
	swag5 = "nill"
	swag6 = "nill"
	swag7 = "nill"
	swag8 = "nill"
	swag9 = "nill"
	swag10 = "nill"
	swag11 = "nill"
	swag12 = "nill"
	swag13 = "nill"
	swag14 = "nill"
	swaggggggg = "nill"
	
	if (swag == "nill") then
	swag = "AIMBOT OFF"
	end
	
	if (swag2 == "nill") then
	swag2 = "BOX ESP OFF"
	end
	
	if (swag3 == "nill") then
	swag3 = "RANK_ESP OFF"
	end
	
	if (swag4 == "nill") then
	swag4 = "NAME_ESP OFF"
	end
	
	if (swag5 == "nill") then
	swag5 = "HEALTH_ESP OFF"
	end

	if (swag6 == "nill") then
	swag6 = "NO-RECOIL OFF"
	end
	
	if (swag7 == "nill") then
	swag7 = "WEAPON_ESP OFF"
	end
	
	if (swag8 == "nill") then
	swag8 = "RADAR_SHOW OFF"
	end

	if (swag9 == "nill") then
	swag9 = "RADAR_NAME OFF"
	end	
	
	if (swag10 == "nill") then
	swag10 = "RADAR_HP OFF"
	end	
	
	if (swag11 == "nill") then
	swag11 = "RADAR_RANK OFF"
	end	

	if (swag12 == "nill") then
	swag12 = "PROP_XRAY OFF"
	end		

	if (swag13 == "nill") then
	swag13 = "SHOW_FPS OFF"
	end		
	
	if (swag14 == "nill") then
	swag14 = "SHOW_ADMIN OFF"
	end			
	
	fov = 30
		
function SKYPE_Menu()
	gui.EnableScreenClicker( true ) 
	
	local Panel = vgui.Create( "HFrame" ) 
	Panel:SetSize( 600, 400 ) 
	Panel:SetPos( ScrW()/2-Panel:GetWide()/2, ScrH()/2-Panel:GetTall()/2 ) 
	Panel:SetTitle( "" ) 
	Panel:SetWindowTitle( "FHaX Menu" ) 
	Panel:ShowCloseButton( false ) 
	Panel:SetDraggable( false ) 
	Panel:SetColor( Color( 0, 0, 0 ) ) 
	Panel:Ease() 
	
	ColumnSheet = vgui.Create("DColumnSheet", Panel)
	ColumnSheet:SetPos(55555, 5555)
	ColumnSheet:SetSize(700 ,700)
	   
    local FinderList = vgui.Create( "DPanelList" )
    FinderList:SetSize(379, 465)
    FinderList:SetSpacing(0)
    FinderList:EnableHorizontal(false)
    FinderList:EnableVerticalScrollbar(true)
    FinderList:AddItem(Finder)
       
    ColumnSheet:AddSheet("Finder", FinderList, "icon16/magnifier.png")
	
	local ScrollPanel = vgui.Create( "DScrollPanel", Panel ) 
	ScrollPanel:SetPos( 150, 60 ) 
	ScrollPanel:SetSize( 450, 270 ) 

	local Buttons, Panels = {}, {} 
	local soffset = 0 
	local createbutton = function( name, offset )
		local button =	vgui.Create( "HButton", Panel ) 
		
		button:SetText( name ) 
		button:SetSize( 130, 40 ) 
		button:SetPos( 10, 60+soffset+(offset or 0) ) 
		button:SetColor( Color( 30, 30, 30, 255 ) ) 
		button:SetHoverColor( Color( 30, 30, 80, 255 ) ) 
		button:SetDownColor( Color( 30, 30, 40, 255 ) ) 
		button:SetFont( "HordeMessageFont" ) 
		button:SetAlignX( false ) 
		
		button.DoClick = function()
		surface.PlaySound( "ambient/water/drip"..math.random(1, 4)..".wav" )
			for _, but in pairs( Buttons ) do
				if (but != button) then 
					but.Selected = false 
					but:SetOriginalColor(  Color( 30, 30, 30, 255 ) ) 
					but:SetWantedColor(  Color( 30, 30, 30, 255 ) ) 
					but:SetHoverColor( Color( 30, 30, 80, 255 ) ) 
					but:SetDownColor( Color( 30, 30, 40, 255 ) ) 
				end
			end
			
			
			for index, pan in pairs( Panels ) do
				if (index != name) then
					pan:Ease() 
				end
			end
			
			if (Panels[name].Easing) then
				Panels[name]:StopEasing() 
			end
			
			ScrollPanel.VBar:SetScroll( 0 ) 
			Panels[name]:SetVisible( true ) 
			Panels[name]:MoveToBack() 
			
			button.Selected = true 
			button:SetWantedColor( Color( 30, 60, 120, 255 ) ) 
			button:SetOriginalColor( Color( 30, 60, 100, 255 ) ) 
			button:SetHoverColor( Color( 30, 60, 120, 255 ) ) 
			button:SetDownColor( Color( 70, 60, 50, 255 ) ) 
		end
		
		soffset = soffset + 50 + (offset or 0) 
		
		return button 
	end
	
	local createpanel = function( color )
		local panel = vgui.Create( "HPanel", ScrollPanel ) 
		panel:SetPos( 0, 0 ) 
		panel:SetSize( 435, 270 ) 
		panel:MoveToBack() 
		panel.Paint = function( self, w, h )
			surface.SetDrawColor( color ) 
			surface.DrawRect( 0, 0, w, h ) 
		end
		
		return panel 
	end
	
	Panel:Notification( "FHaX Menu v1.0" ) 
	Panel:Notification( "Do u even lift???" )
	
	Panels = {["Main"]=createpanel( Color( 20, 20 , 20 ) ), ["Aimbot"]=createpanel( Color( 20, 20 , 20 ) ), ["ESP"]=createpanel( Color( 20, 20 , 20 ) ), ["Misc"]=createpanel( Color( 20, 20 , 20 ) ), ["Enity-Finder"]=createpanel( Color( 20, 20 , 20 ) ), ["File manager"]=createpanel( Color( 20, 20 , 20 ) ), ["Logs"]=createpanel( Color( 20, 20 , 20 ) )} 
	Buttons = {["Aimbot"]=createbutton( "Aimbot" ), ["ESP"]=createbutton( "ESP" ), ["Enity-Finder"]=createbutton( "Enity-Finder" ), ["Misc"]=createbutton( "Misc" )} 
	
	
	local DComboBox = vgui.Create( "DComboBox", Panels["Aimbot"] )
	DComboBox:SetPos( 20, 100 )
	DComboBox:SetSize( 100, 20 )
	DComboBox:SetValue( bone )
	DComboBox:AddChoice( "Head" )
	DComboBox:AddChoice( "Spine" )
	DComboBox.OnSelect = function( panel, index, value )
	if value == "Head" then
	bone = "ValveBiped.Bip01_Head1"
	chat.AddText(Color( 255, 0, 0 ), "Bone = ", Color( 255, 0, 0 ), bone)
	end
	if value == "Spine" then
	bone = "ValveBiped.Bip01_Spine"
	chat.AddText(Color( 255, 0, 0 ), "Bone = ", Color( 255, 0, 0 ), bone)
	end
	end
	
	
	if (swaggggggg == "nill") then
	swaggggggg = "Keypad Finder OFF"
	end
	
	local SKYPE_DERMABUTTON8 = vgui.Create( "HButton", Panels["Misc"] ) 
    SKYPE_DERMABUTTON8:SetText( swaggggggg ) 
	SKYPE_DERMABUTTON8:SetSize( 130, 40 ) 
	SKYPE_DERMABUTTON8:SetPos( 20, 10 ) 
	SKYPE_DERMABUTTON8:SetColor( Color( 30, 30, 30, 255 ) ) 
	SKYPE_DERMABUTTON8:SetHoverColor( Color( 30, 30, 80, 255 ) ) 
	SKYPE_DERMABUTTON8:SetDownColor( Color( 30, 30, 40, 255 ) ) 
	SKYPE_DERMABUTTON8:SetFont( "HordeMessageFont" ) 
	SKYPE_DERMABUTTON8:SetAlignX( false )  
	SKYPE_DERMABUTTON8.DoClick = function ()
    surface.PlaySound( "ambient/water/drip"..math.random(1, 4)..".wav" )	
	RunConsoleCommand( "skype_keypad_toggle" ) 
    keypadlog()	
	end

	local label = vgui.Create( "DLabel", Panels.Main ) 
	label:SetPos( 10, 10 ) 
	label:SetColor( Color( 205, 255, 255 ) ) 
	label:SetText( "Change Log \nAdded Aimbot\nCredits:BlueKirby For The Core Menu\nPlus Other Haxers" ) 
	label:SetFont( "HordeMessageFont" ) 
	label:SizeToContents() 
	
	local slider = vgui.Create("DNumSlider", Panels["Aimbot"] )
    slider:SetPos(0, 230)
    slider:SetText("             FOV")
    slider:SetMinMax(0, 180)
    slider:SetWide(200)
    slider:SetDecimals( 0 )
    slider:SetFGColor(255,255,255,255)
    slider:SetBGColor(255,255,255,255)
    slider:SetValue(fov)
    slider.OnValueChanged = function(panel, value)
    local c = tonumber(value)
    fov = math.Round(c)
    end
	
	local SKYPE_DERMABUTTON = vgui.Create( "HButton", Panels["Aimbot"] ) 
    SKYPE_DERMABUTTON:SetText( swag ) 
	SKYPE_DERMABUTTON:SetSize( 130, 40 ) 
	SKYPE_DERMABUTTON:SetPos( 20, 10 ) 
	SKYPE_DERMABUTTON:SetColor( Color( 30, 30, 30, 255 ) ) 
	SKYPE_DERMABUTTON:SetHoverColor( Color( 30, 30, 80, 255 ) ) 
	SKYPE_DERMABUTTON:SetDownColor( Color( 30, 30, 40, 255 ) ) 
	SKYPE_DERMABUTTON:SetFont( "HordeMessageFont" ) 
	SKYPE_DERMABUTTON:SetAlignX( false )  
	SKYPE_DERMABUTTON.DoClick = function () 
	surface.PlaySound( "ambient/water/drip"..math.random(1, 4)..".wav" )
    RunConsoleCommand( "skype_aimb0t" ) 
	end

	function skype_aimtoggle( player, command, arguments )
	if (swag == "AIMBOT OFF") then
	swag = "AIMBOT ON"
	else
	swag = "AIMBOT OFF"
	end
	if swag == "AIMBOT ON" then
	chat.AddText(Color( 79, 213, 214 ), "Aimbot", Color( 0, 255, 0 ), " [ON]")
	else
	chat.AddText(Color( 79, 213, 214 ), "Aimbot", Color( 255, 0, 0 ), " [OFF]")
	end
    local SKYPE_DERMABUTTON = vgui.Create( "HButton", Panels["Aimbot"] ) 
    SKYPE_DERMABUTTON:SetText( swag ) 
	SKYPE_DERMABUTTON:SetSize( 130, 40 ) 
	SKYPE_DERMABUTTON:SetPos( 20, 10 ) 
	SKYPE_DERMABUTTON:SetColor( Color( 30, 30, 30, 255 ) ) 
	SKYPE_DERMABUTTON:SetHoverColor( Color( 30, 30, 80, 255 ) ) 
	SKYPE_DERMABUTTON:SetDownColor( Color( 30, 30, 40, 255 ) ) 
	SKYPE_DERMABUTTON:SetFont( "HordeMessageFont" ) 
	SKYPE_DERMABUTTON:SetAlignX( false )  
	SKYPE_DERMABUTTON.DoClick = function () 
	surface.PlaySound( "ambient/water/drip"..math.random(1, 4)..".wav" )
    RunConsoleCommand( "skype_aimb0t" ) 
	end
    end
    concommand.Add( "skype_aimb0t", skype_aimtoggle ) 
	
	local SKYPE_DERMABUTTON2 = vgui.Create( "HButton", Panels["ESP"] ) 
    SKYPE_DERMABUTTON2:SetText( swag2 ) 
	SKYPE_DERMABUTTON2:SetSize( 130, 40 ) 
	SKYPE_DERMABUTTON2:SetPos( 20, 10 ) 
	SKYPE_DERMABUTTON2:SetColor( Color( 30, 30, 30, 255 ) ) 
	SKYPE_DERMABUTTON2:SetHoverColor( Color( 30, 30, 80, 255 ) ) 
	SKYPE_DERMABUTTON2:SetDownColor( Color( 30, 30, 40, 255 ) ) 
	SKYPE_DERMABUTTON2:SetFont( "HordeMessageFont" ) 
	SKYPE_DERMABUTTON2:SetAlignX( false )  
	SKYPE_DERMABUTTON2.DoClick = function () 
	surface.PlaySound( "ambient/water/drip"..math.random(1, 4)..".wav" )
    RunConsoleCommand( "skype_esp" ) 
	end
	
	local SKYPE_DERMABUTTON3 = vgui.Create( "HButton", Panels["ESP"] ) 
    SKYPE_DERMABUTTON3:SetText( swag3 ) 
	SKYPE_DERMABUTTON3:SetSize( 130, 40 ) 
	SKYPE_DERMABUTTON3:SetPos( 20, 60 ) 
	SKYPE_DERMABUTTON3:SetColor( Color( 30, 30, 30, 255 ) ) 
	SKYPE_DERMABUTTON3:SetHoverColor( Color( 30, 30, 80, 255 ) ) 
	SKYPE_DERMABUTTON3:SetDownColor( Color( 30, 30, 40, 255 ) ) 
	SKYPE_DERMABUTTON3:SetFont( "HordeMessageFont" ) 
	SKYPE_DERMABUTTON3:SetAlignX( false )  
	SKYPE_DERMABUTTON3.DoClick = function () 
	surface.PlaySound( "ambient/water/drip"..math.random(1, 4)..".wav" )
    RunConsoleCommand( "skype_esp_RANK_ESP" ) 
	end
	
	local SKYPE_DERMABUTTON4 = vgui.Create( "HButton", Panels["ESP"] ) 
    SKYPE_DERMABUTTON4:SetText( swag4 ) 
	SKYPE_DERMABUTTON4:SetSize( 130, 40 ) 
	SKYPE_DERMABUTTON4:SetPos( 20, 110 ) 
	SKYPE_DERMABUTTON4:SetColor( Color( 30, 30, 30, 255 ) ) 
	SKYPE_DERMABUTTON4:SetHoverColor( Color( 30, 30, 80, 255 ) ) 
	SKYPE_DERMABUTTON4:SetDownColor( Color( 30, 30, 40, 255 ) ) 
	SKYPE_DERMABUTTON4:SetFont( "HordeMessageFont" ) 
	SKYPE_DERMABUTTON4:SetAlignX( false )  
	SKYPE_DERMABUTTON4.DoClick = function () 
	surface.PlaySound( "ambient/water/drip"..math.random(1, 4)..".wav" )
    RunConsoleCommand( "skype_esp_NAME_ESP" ) 
	end
	
	local SKYPE_DERMABUTTON5 = vgui.Create( "HButton", Panels["ESP"] ) 
    SKYPE_DERMABUTTON5:SetText( swag5 ) 
	SKYPE_DERMABUTTON5:SetSize( 130, 40 ) 
	SKYPE_DERMABUTTON5:SetPos( 20, 160 ) 
	SKYPE_DERMABUTTON5:SetColor( Color( 30, 30, 30, 255 ) ) 
	SKYPE_DERMABUTTON5:SetHoverColor( Color( 30, 30, 80, 255 ) ) 
	SKYPE_DERMABUTTON5:SetDownColor( Color( 30, 30, 40, 255 ) ) 
	SKYPE_DERMABUTTON5:SetFont( "HordeMessageFont" ) 
	SKYPE_DERMABUTTON5:SetAlignX( false )  
	SKYPE_DERMABUTTON5.DoClick = function () 
	surface.PlaySound( "ambient/water/drip"..math.random(1, 4)..".wav" )
    RunConsoleCommand( "skype_esp_HEALTH_ESP" ) 
	end
	
	local SKYPE_DERMABUTTON6 = vgui.Create( "HButton", Panels["Aimbot"] ) 
    SKYPE_DERMABUTTON6:SetText( swag6 ) 
	SKYPE_DERMABUTTON6:SetSize( 130, 40 ) 
	SKYPE_DERMABUTTON6:SetPos( 20, 160 ) 
	SKYPE_DERMABUTTON6:SetColor( Color( 30, 30, 30, 255 ) ) 
	SKYPE_DERMABUTTON6:SetHoverColor( Color( 30, 30, 80, 255 ) ) 
	SKYPE_DERMABUTTON6:SetDownColor( Color( 30, 30, 40, 255 ) ) 
	SKYPE_DERMABUTTON6:SetFont( "HordeMessageFont" ) 
	SKYPE_DERMABUTTON6:SetAlignX( false )  
	SKYPE_DERMABUTTON6.DoClick = function () 
	surface.PlaySound( "ambient/water/drip"..math.random(1, 4)..".wav" )
    RunConsoleCommand( "skype_NO-REC0IL" ) 
	end
	
	local SKYPE_DERMABUTTON9 = vgui.Create( "HButton", Panels["Misc"] ) 
    SKYPE_DERMABUTTON9:SetText( swag8 ) 
	SKYPE_DERMABUTTON9:SetSize( 130, 40 ) 
	SKYPE_DERMABUTTON9:SetPos( 20, 60 ) 
	SKYPE_DERMABUTTON9:SetColor( Color( 30, 30, 30, 255 ) ) 
	SKYPE_DERMABUTTON9:SetHoverColor( Color( 30, 30, 80, 255 ) ) 
	SKYPE_DERMABUTTON9:SetDownColor( Color( 30, 30, 40, 255 ) ) 
	SKYPE_DERMABUTTON9:SetFont( "HordeMessageFont" ) 
	SKYPE_DERMABUTTON9:SetAlignX( false )  
	SKYPE_DERMABUTTON9.DoClick = function () 
	surface.PlaySound( "ambient/water/drip"..math.random(1, 4)..".wav" )
    RunConsoleCommand( "skype_radar_showz" ) 
	end
	
	local SKYPE_DERMABUTTON10 = vgui.Create( "HButton", Panels["Misc"] ) 
    SKYPE_DERMABUTTON10:SetText( swag9 ) 
	SKYPE_DERMABUTTON10:SetSize( 130, 40 ) 
	SKYPE_DERMABUTTON10:SetPos( 20, 110 ) 
	SKYPE_DERMABUTTON10:SetColor( Color( 30, 30, 30, 255 ) ) 
	SKYPE_DERMABUTTON10:SetHoverColor( Color( 30, 30, 80, 255 ) ) 
	SKYPE_DERMABUTTON10:SetDownColor( Color( 30, 30, 40, 255 ) ) 
	SKYPE_DERMABUTTON10:SetFont( "HordeMessageFont" ) 
	SKYPE_DERMABUTTON10:SetAlignX( false )  
	SKYPE_DERMABUTTON10.DoClick = function () 
	surface.PlaySound( "ambient/water/drip"..math.random(1, 4)..".wav" )
    RunConsoleCommand( "skype_radar_showz_name" ) 
	end
	
	local SKYPE_DERMABUTTON11 = vgui.Create( "HButton", Panels["Misc"] ) 
    SKYPE_DERMABUTTON11:SetText( swag10 ) 
	SKYPE_DERMABUTTON11:SetSize( 130, 40 ) 
	SKYPE_DERMABUTTON11:SetPos( 20, 160 ) 
	SKYPE_DERMABUTTON11:SetColor( Color( 30, 30, 30, 255 ) ) 
	SKYPE_DERMABUTTON11:SetHoverColor( Color( 30, 30, 80, 255 ) ) 
	SKYPE_DERMABUTTON11:SetDownColor( Color( 30, 30, 40, 255 ) ) 
	SKYPE_DERMABUTTON11:SetFont( "HordeMessageFont" ) 
	SKYPE_DERMABUTTON11:SetAlignX( false )  
	SKYPE_DERMABUTTON11.DoClick = function () 
	surface.PlaySound( "ambient/water/drip"..math.random(1, 4)..".wav" )
    RunConsoleCommand( "skype_radar_showz_health" ) 
	end
	
	local SKYPE_DERMABUTTON12 = vgui.Create( "HButton", Panels["Misc"] ) 
    SKYPE_DERMABUTTON12:SetText( swag11 ) 
	SKYPE_DERMABUTTON12:SetSize( 130, 40 ) 
	SKYPE_DERMABUTTON12:SetPos( 20, 210 ) 
	SKYPE_DERMABUTTON12:SetColor( Color( 30, 30, 30, 255 ) ) 
	SKYPE_DERMABUTTON12:SetHoverColor( Color( 30, 30, 80, 255 ) ) 
	SKYPE_DERMABUTTON12:SetDownColor( Color( 30, 30, 40, 255 ) ) 
	SKYPE_DERMABUTTON12:SetFont( "HordeMessageFont" ) 
	SKYPE_DERMABUTTON12:SetAlignX( false )  
	SKYPE_DERMABUTTON12.DoClick = function () 
	surface.PlaySound( "ambient/water/drip"..math.random(1, 4)..".wav" )
    RunConsoleCommand( "skype_radar_showz_rank" ) 
	end
	
	local SKYPE_DERMABUTTON13 = vgui.Create( "HButton", Panels["Misc"] ) 
    SKYPE_DERMABUTTON13:SetText( swag12 ) 
	SKYPE_DERMABUTTON13:SetSize( 130, 40 ) 
	SKYPE_DERMABUTTON13:SetPos( 170, 10 ) 
	SKYPE_DERMABUTTON13:SetColor( Color( 30, 30, 30, 255 ) ) 
	SKYPE_DERMABUTTON13:SetHoverColor( Color( 30, 30, 80, 255 ) ) 
	SKYPE_DERMABUTTON13:SetDownColor( Color( 30, 30, 40, 255 ) ) 
	SKYPE_DERMABUTTON13:SetFont( "HordeMessageFont" ) 
	SKYPE_DERMABUTTON13:SetAlignX( false )  
	SKYPE_DERMABUTTON13.DoClick = function () 
	surface.PlaySound( "ambient/water/drip"..math.random(1, 4)..".wav" )
    RunConsoleCommand( "skype_xray" ) 
	end
	
	local SKYPE_DERMABUTTON14 = vgui.Create( "HButton", Panels["Misc"] ) 
    SKYPE_DERMABUTTON14:SetText( swag13 ) 
	SKYPE_DERMABUTTON14:SetSize( 130, 40 ) 
	SKYPE_DERMABUTTON14:SetPos( 170, 60 ) 
	SKYPE_DERMABUTTON14:SetColor( Color( 30, 30, 30, 255 ) ) 
	SKYPE_DERMABUTTON14:SetHoverColor( Color( 30, 30, 80, 255 ) ) 
	SKYPE_DERMABUTTON14:SetDownColor( Color( 30, 30, 40, 255 ) ) 
	SKYPE_DERMABUTTON14:SetFont( "HordeMessageFont" ) 
	SKYPE_DERMABUTTON14:SetAlignX( false )  
	SKYPE_DERMABUTTON14.DoClick = function () 
	surface.PlaySound( "ambient/water/drip"..math.random(1, 4)..".wav" )
    RunConsoleCommand( "skype_sfps" ) 
	end
	
	local SKYPE_DERMABUTTON15 = vgui.Create( "HButton", Panels["Misc"] ) 
    SKYPE_DERMABUTTON15:SetText( swag14 ) 
	SKYPE_DERMABUTTON15:SetSize( 130, 40 ) 
	SKYPE_DERMABUTTON15:SetPos( 170, 110 ) 
	SKYPE_DERMABUTTON15:SetColor( Color( 30, 30, 30, 255 ) ) 
	SKYPE_DERMABUTTON15:SetHoverColor( Color( 30, 30, 80, 255 ) ) 
	SKYPE_DERMABUTTON15:SetDownColor( Color( 30, 30, 40, 255 ) ) 
	SKYPE_DERMABUTTON15:SetFont( "HordeMessageFont" ) 
	SKYPE_DERMABUTTON15:SetAlignX( false )  
	SKYPE_DERMABUTTON15.DoClick = function () 
	surface.PlaySound( "ambient/water/drip"..math.random(1, 4)..".wav" )
    RunConsoleCommand( "skype_sADMIN" ) 
	end
	
	local SKYPE_DERMABUTTON92 = vgui.Create( "HButton", Panels["Enity-Finder"] ) 
    SKYPE_DERMABUTTON92:SetText( " ESP" ) 
	SKYPE_DERMABUTTON92:SetSize( 40, 40 ) 
	SKYPE_DERMABUTTON92:SetPos( 200, 220 ) 
	SKYPE_DERMABUTTON92:SetColor( Color( 30, 30, 30, 255 ) ) 
	SKYPE_DERMABUTTON92:SetHoverColor( Color( 30, 30, 80, 255 ) ) 
	SKYPE_DERMABUTTON92:SetDownColor( Color( 30, 30, 40, 255 ) ) 
	SKYPE_DERMABUTTON92:SetFont( "HordeMessageFont" ) 
	SKYPE_DERMABUTTON92:SetAlignX( false )  
	SKYPE_DERMABUTTON92.DoClick = function () 
	skype_drawentity = !skype_drawentity
	end
	
	local SKYPE_DERMABUTTON7 = vgui.Create( "HButton", Panels["ESP"] ) 
    SKYPE_DERMABUTTON7:SetText( swag7 ) 
	SKYPE_DERMABUTTON7:SetSize( 130, 40 ) 
	SKYPE_DERMABUTTON7:SetPos( 20, 210 ) 
	SKYPE_DERMABUTTON7:SetColor( Color( 30, 30, 30, 255 ) ) 
	SKYPE_DERMABUTTON7:SetHoverColor( Color( 30, 30, 80, 255 ) ) 
	SKYPE_DERMABUTTON7:SetDownColor( Color( 30, 30, 40, 255 ) ) 
	SKYPE_DERMABUTTON7:SetFont( "HordeMessageFont" ) 
	SKYPE_DERMABUTTON7:SetAlignX( false )  
	SKYPE_DERMABUTTON7.DoClick = function () 
	surface.PlaySound( "ambient/water/drip"..math.random(1, 4)..".wav" )
    RunConsoleCommand( "skype_WEAPON_ESP" ) 
	end

	function skype_esptoggle( player, command, arguments )
	if (swag2 == "BOX ESP OFF") then
	swag2 = "BOX ESP ON"
	else
	swag2 = "BOX ESP OFF"
	end
	if swag2 == "BOX ESP ON" then
	chat.AddText(Color( 79, 213, 214 ), "BOX ESP", Color( 0, 255, 0 ), " [ON]")
	else
	chat.AddText(Color( 79, 213, 214 ), "BOX ESP", Color( 255, 0, 0 ), " [OFF]")
	end
	local SKYPE_DERMABUTTON2 = vgui.Create( "HButton", Panels["ESP"] ) 
    SKYPE_DERMABUTTON2:SetText( swag2 ) 
	SKYPE_DERMABUTTON2:SetSize( 130, 40 ) 
	SKYPE_DERMABUTTON2:SetPos( 20, 10 ) 
	SKYPE_DERMABUTTON2:SetColor( Color( 30, 30, 30, 255 ) ) 
	SKYPE_DERMABUTTON2:SetHoverColor( Color( 30, 30, 80, 255 ) ) 
	SKYPE_DERMABUTTON2:SetDownColor( Color( 30, 30, 40, 255 ) ) 
	SKYPE_DERMABUTTON2:SetFont( "HordeMessageFont" ) 
	SKYPE_DERMABUTTON2:SetAlignX( false )  
	SKYPE_DERMABUTTON2.DoClick = function () 
	surface.PlaySound( "ambient/water/drip"..math.random(1, 4)..".wav" )
    RunConsoleCommand( "skype_esp" ) 
	end
    end
    concommand.Add( "skype_esp", skype_esptoggle ) 
	
	function skype_esptoggle2( player, command, arguments )
	if (swag3 == "RANK_ESP OFF") then
	swag3 = "RANK_ESP ON"
	else
	swag3 = "RANK_ESP OFF"
	end
	if swag3 == "RANK_ESP ON" then
	chat.AddText(Color( 79, 213, 214 ), "RANK_ESP", Color( 0, 255, 0 ), " [ON]")
	else
	chat.AddText(Color( 79, 213, 214 ), "RANK_ESP", Color( 255, 0, 0 ), " [OFF]")
	end
	local SKYPE_DERMABUTTON3 = vgui.Create( "HButton", Panels["ESP"] ) 
    SKYPE_DERMABUTTON3:SetText( swag3 ) 
	SKYPE_DERMABUTTON3:SetSize( 130, 40 ) 
	SKYPE_DERMABUTTON3:SetPos( 20, 60 ) 
	SKYPE_DERMABUTTON3:SetColor( Color( 30, 30, 30, 255 ) ) 
	SKYPE_DERMABUTTON3:SetHoverColor( Color( 30, 30, 80, 255 ) ) 
	SKYPE_DERMABUTTON3:SetDownColor( Color( 30, 30, 40, 255 ) ) 
	SKYPE_DERMABUTTON3:SetFont( "HordeMessageFont" ) 
	SKYPE_DERMABUTTON3:SetAlignX( false )  
	SKYPE_DERMABUTTON3.DoClick = function () 
	surface.PlaySound( "ambient/water/drip"..math.random(1, 4)..".wav" )
    RunConsoleCommand( "skype_esp_RANK_ESP" ) 
	end
    end
    concommand.Add( "skype_esp_RANK_ESP", skype_esptoggle2 ) 
	
	function skype_esptoggle3( player, command, arguments )
	if (swag4 == "NAME_ESP OFF") then
	swag4 = "NAME_ESP ON"
	else
	swag4 = "NAME_ESP OFF"
	end
	if swag4 == "NAME_ESP ON" then
	chat.AddText(Color( 79, 213, 214 ), "NAME_ESP", Color( 0, 255, 0 ), " [ON]")
	else
	chat.AddText(Color( 79, 213, 214 ), "NAME_ESP", Color( 255, 0, 0 ), " [OFF]")
	end
	local SKYPE_DERMABUTTON4 = vgui.Create( "HButton", Panels["ESP"] ) 
    SKYPE_DERMABUTTON4:SetText( swag4 ) 
	SKYPE_DERMABUTTON4:SetSize( 130, 40 ) 
	SKYPE_DERMABUTTON4:SetPos( 20, 110 ) 
	SKYPE_DERMABUTTON4:SetColor( Color( 30, 30, 30, 255 ) ) 
	SKYPE_DERMABUTTON4:SetHoverColor( Color( 30, 30, 80, 255 ) ) 
	SKYPE_DERMABUTTON4:SetDownColor( Color( 30, 30, 40, 255 ) ) 
	SKYPE_DERMABUTTON4:SetFont( "HordeMessageFont" ) 
	SKYPE_DERMABUTTON4:SetAlignX( false )  
	SKYPE_DERMABUTTON4.DoClick = function () 
	surface.PlaySound( "ambient/water/drip"..math.random(1, 4)..".wav" )
    RunConsoleCommand( "skype_esp_NAME_ESP" ) 
	end
    end
    concommand.Add( "skype_esp_NAME_ESP", skype_esptoggle3 ) 
	
	function skype_esptoggle4( player, command, arguments )
	if (swag5 == "HEALTH_ESP OFF") then
	swag5 = "HEALTH_ESP ON"
	else
	swag5 = "HEALTH_ESP OFF"
	end
	if swag5 == "HEALTH_ESP ON" then
	chat.AddText(Color( 79, 213, 214 ), "HEALTH_ESP", Color( 0, 255, 0 ), " [ON]")
	else
	chat.AddText(Color( 79, 213, 214 ), "HEALTH_ESP", Color( 255, 0, 0 ), " [OFF]")
	end
	local SKYPE_DERMABUTTON5 = vgui.Create( "HButton", Panels["ESP"] ) 
    SKYPE_DERMABUTTON5:SetText( swag5 ) 
	SKYPE_DERMABUTTON5:SetSize( 130, 40 ) 
	SKYPE_DERMABUTTON5:SetPos( 20, 160 ) 
	SKYPE_DERMABUTTON5:SetColor( Color( 30, 30, 30, 255 ) ) 
	SKYPE_DERMABUTTON5:SetHoverColor( Color( 30, 30, 80, 255 ) ) 
	SKYPE_DERMABUTTON5:SetDownColor( Color( 30, 30, 40, 255 ) ) 
	SKYPE_DERMABUTTON5:SetFont( "HordeMessageFont" ) 
	SKYPE_DERMABUTTON5:SetAlignX( false )  
	SKYPE_DERMABUTTON5.DoClick = function () 
	surface.PlaySound( "ambient/water/drip"..math.random(1, 4)..".wav" )
    RunConsoleCommand( "skype_esp_HEALTH_ESP" ) 
	end
    end
    concommand.Add( "skype_esp_HEALTH_ESP", skype_esptoggle4 ) 
	
	function skype_radar_showz( player, command, arguments )
	if (swag8 == "RADAR_SHOW OFF") then
	swag8 = "RADAR_SHOW ON"
	else
	swag8 = "RADAR_SHOW OFF"
	end
	if swag8 == "RADAR_SHOW ON" then
	chat.AddText(Color( 79, 213, 214 ), "RADAR_SHOW", Color( 0, 255, 0 ), " [ON]")
	else
	chat.AddText(Color( 79, 213, 214 ), "RADAR_SHOW", Color( 255, 0, 0 ), " [OFF]")
	end
	local SKYPE_DERMABUTTON9 = vgui.Create( "HButton", Panels["Misc"] ) 
    SKYPE_DERMABUTTON9:SetText( swag8 ) 
	SKYPE_DERMABUTTON9:SetSize( 130, 40 ) 
	SKYPE_DERMABUTTON9:SetPos( 20, 60 ) 
	SKYPE_DERMABUTTON9:SetColor( Color( 30, 30, 30, 255 ) ) 
	SKYPE_DERMABUTTON9:SetHoverColor( Color( 30, 30, 80, 255 ) ) 
	SKYPE_DERMABUTTON9:SetDownColor( Color( 30, 30, 40, 255 ) ) 
	SKYPE_DERMABUTTON9:SetFont( "HordeMessageFont" ) 
	SKYPE_DERMABUTTON9:SetAlignX( false )  
	SKYPE_DERMABUTTON9.DoClick = function () 
	surface.PlaySound( "ambient/water/drip"..math.random(1, 4)..".wav" )
    RunConsoleCommand( "skype_radar_showz" ) 
	end
    end
    concommand.Add( "skype_radar_showz", skype_radar_showz ) 
	
	function skype_radar_showz_name( player, command, arguments )
	if (swag9 == "RADAR_NAME OFF") then
	swag9 = "RADAR_NAME ON"
	else
	swag9 = "RADAR_NAME OFF"
	end
	if swag9 == "RADAR_NAME ON" then
	chat.AddText(Color( 79, 213, 214 ), "RADAR_NAME", Color( 0, 255, 0 ), " [ON]")
	else
	chat.AddText(Color( 79, 213, 214 ), "RADAR_NAME", Color( 255, 0, 0 ), " [OFF]")
	end
	local SKYPE_DERMABUTTON10 = vgui.Create( "HButton", Panels["Misc"] ) 
    SKYPE_DERMABUTTON10:SetText( swag9 ) 
	SKYPE_DERMABUTTON10:SetSize( 130, 40 ) 
	SKYPE_DERMABUTTON10:SetPos( 20, 110 ) 
	SKYPE_DERMABUTTON10:SetColor( Color( 30, 30, 30, 255 ) ) 
	SKYPE_DERMABUTTON10:SetHoverColor( Color( 30, 30, 80, 255 ) ) 
	SKYPE_DERMABUTTON10:SetDownColor( Color( 30, 30, 40, 255 ) ) 
	SKYPE_DERMABUTTON10:SetFont( "HordeMessageFont" ) 
	SKYPE_DERMABUTTON10:SetAlignX( false )  
	SKYPE_DERMABUTTON10.DoClick = function () 
	surface.PlaySound( "ambient/water/drip"..math.random(1, 4)..".wav" )
    RunConsoleCommand( "skype_radar_showz_name" ) 
	end
    end
    concommand.Add( "skype_radar_showz_name", skype_radar_showz_name ) 
	
	function skype_radar_showz_health( player, command, arguments )
	if (swag10 == "RADAR_HP OFF") then
	swag10 = "RADAR_HP ON"
	else
	swag10 = "RADAR_HP OFF"
	end
	if swag10 == "RADAR_HP ON" then
	chat.AddText(Color( 79, 213, 214 ), "RADAR_HP", Color( 0, 255, 0 ), " [ON]")
	else
	chat.AddText(Color( 79, 213, 214 ), "RADAR_HP", Color( 255, 0, 0 ), " [OFF]")
	end
	local SKYPE_DERMABUTTON11 = vgui.Create( "HButton", Panels["Misc"] ) 
    SKYPE_DERMABUTTON11:SetText( swag10 ) 
	SKYPE_DERMABUTTON11:SetSize( 130, 40 ) 
	SKYPE_DERMABUTTON11:SetPos( 20, 160 ) 
	SKYPE_DERMABUTTON11:SetColor( Color( 30, 30, 30, 255 ) ) 
	SKYPE_DERMABUTTON11:SetHoverColor( Color( 30, 30, 80, 255 ) ) 
	SKYPE_DERMABUTTON11:SetDownColor( Color( 30, 30, 40, 255 ) ) 
	SKYPE_DERMABUTTON11:SetFont( "HordeMessageFont" ) 
	SKYPE_DERMABUTTON11:SetAlignX( false )  
	SKYPE_DERMABUTTON11.DoClick = function ()
	surface.PlaySound( "ambient/water/drip"..math.random(1, 4)..".wav" )
    RunConsoleCommand( "skype_radar_showz_health" ) 
	end
    end
    concommand.Add( "skype_radar_showz_health", skype_radar_showz_health ) 
	
	function skype_radar_showz_rank( player, command, arguments )
	if (swag11 == "RADAR_RANK OFF") then
	swag11 = "RADAR_RANK ON"
	else
	swag11 = "RADAR_RANK OFF"
	end
	if swag11 == "RADAR_RANK ON" then
	chat.AddText(Color( 79, 213, 214 ), "RADAR_RANK", Color( 0, 255, 0 ), " [ON]")
	else
	chat.AddText(Color( 79, 213, 214 ), "RADAR_RANK", Color( 255, 0, 0 ), " [OFF]")
	end
	local SKYPE_DERMABUTTON12 = vgui.Create( "HButton", Panels["Misc"] ) 
    SKYPE_DERMABUTTON12:SetText( swag11 ) 
	SKYPE_DERMABUTTON12:SetSize( 130, 40 ) 
	SKYPE_DERMABUTTON12:SetPos( 20, 210 ) 
	SKYPE_DERMABUTTON12:SetColor( Color( 30, 30, 30, 255 ) ) 
	SKYPE_DERMABUTTON12:SetHoverColor( Color( 30, 30, 80, 255 ) ) 
	SKYPE_DERMABUTTON12:SetDownColor( Color( 30, 30, 40, 255 ) ) 
	SKYPE_DERMABUTTON12:SetFont( "HordeMessageFont" ) 
	SKYPE_DERMABUTTON12:SetAlignX( false )  
	SKYPE_DERMABUTTON12.DoClick = function () 
	surface.PlaySound( "ambient/water/drip"..math.random(1, 4)..".wav" )
    RunConsoleCommand( "skype_radar_showz_rank" ) 
	end
    end
    concommand.Add( "skype_radar_showz_rank", skype_radar_showz_rank ) 
	
	function skype_xray( player, command, arguments )
	if (swag12 == "PROP_XRAY OFF") then
	swag12 = "PROP_XRAY ON"
	else
	swag12 = "PROP_XRAY OFF"
	end
	if swag12 == "PROP_XRAY ON" then
	chat.AddText(Color( 79, 213, 214 ), "PROP_XRAY", Color( 0, 255, 0 ), " [ON]")
	else
	chat.AddText(Color( 79, 213, 214 ), "PROP_XRAY", Color( 255, 0, 0 ), " [OFF]")
	end
	local SKYPE_DERMABUTTON13 = vgui.Create( "HButton", Panels["Misc"] ) 
    SKYPE_DERMABUTTON13:SetText( swag12 ) 
	SKYPE_DERMABUTTON13:SetSize( 130, 40 ) 
	SKYPE_DERMABUTTON13:SetPos( 170, 10 ) 
	SKYPE_DERMABUTTON13:SetColor( Color( 30, 30, 30, 255 ) ) 
	SKYPE_DERMABUTTON13:SetHoverColor( Color( 30, 30, 80, 255 ) ) 
	SKYPE_DERMABUTTON13:SetDownColor( Color( 30, 30, 40, 255 ) ) 
	SKYPE_DERMABUTTON13:SetFont( "HordeMessageFont" ) 
	SKYPE_DERMABUTTON13:SetAlignX( false )  
	SKYPE_DERMABUTTON13.DoClick = function ()
	surface.PlaySound( "ambient/water/drip"..math.random(1, 4)..".wav" )
    RunConsoleCommand( "skype_xray" ) 
	end
    end
    concommand.Add( "skype_xray", skype_xray ) 
	
	function skype_sfps( player, command, arguments )
	if (swag13 == "SHOW_FPS OFF") then
	swag13 = "SHOW_FPS ON"
	else
	swag13 = "SHOW_FPS OFF"
	end
	if swag13 == "SHOW_FPS ON" then
	chat.AddText(Color( 79, 213, 214 ), "SHOW_FPS", Color( 0, 255, 0 ), " [ON]")
	else
	chat.AddText(Color( 79, 213, 214 ), "SHOW_FPS", Color( 255, 0, 0 ), " [OFF]")
	end
	local SKYPE_DERMABUTTON14 = vgui.Create( "HButton", Panels["Misc"] ) 
    SKYPE_DERMABUTTON14:SetText( swag13 ) 
	SKYPE_DERMABUTTON14:SetSize( 130, 40 ) 
	SKYPE_DERMABUTTON14:SetPos( 170, 60 ) 
	SKYPE_DERMABUTTON14:SetColor( Color( 30, 30, 30, 255 ) ) 
	SKYPE_DERMABUTTON14:SetHoverColor( Color( 30, 30, 80, 255 ) ) 
	SKYPE_DERMABUTTON14:SetDownColor( Color( 30, 30, 40, 255 ) ) 
	SKYPE_DERMABUTTON14:SetFont( "HordeMessageFont" ) 
	SKYPE_DERMABUTTON14:SetAlignX( false )  
	SKYPE_DERMABUTTON14.DoClick = function ()
	surface.PlaySound( "ambient/water/drip"..math.random(1, 4)..".wav" )
    RunConsoleCommand( "skype_sfps" ) 
	end
    end
    concommand.Add( "skype_sfps", skype_sfps ) 
	
	function skype_sADMIN( player, command, arguments )
	if (swag14 == "SHOW_ADMIN OFF") then
	swag14 = "SHOW_ADMIN ON"
	else
	swag14 = "SHOW_ADMIN OFF"
	end
	if swag14 == "SHOW_ADMIN ON" then
	chat.AddText(Color( 79, 213, 214 ), "SHOW_ADMIN", Color( 0, 255, 0 ), " [ON]")
	else
	chat.AddText(Color( 79, 213, 214 ), "SHOW_ADMIN", Color( 255, 0, 0 ), " [OFF]")
	end
	local SKYPE_DERMABUTTON15 = vgui.Create( "HButton", Panels["Misc"] ) 
    SKYPE_DERMABUTTON15:SetText( swag14 ) 
	SKYPE_DERMABUTTON15:SetSize( 130, 40 ) 
	SKYPE_DERMABUTTON15:SetPos( 170, 110 ) 
	SKYPE_DERMABUTTON15:SetColor( Color( 30, 30, 30, 255 ) ) 
	SKYPE_DERMABUTTON15:SetHoverColor( Color( 30, 30, 80, 255 ) ) 
	SKYPE_DERMABUTTON15:SetDownColor( Color( 30, 30, 40, 255 ) ) 
	SKYPE_DERMABUTTON15:SetFont( "HordeMessageFont" ) 
	SKYPE_DERMABUTTON15:SetAlignX( false )  
	SKYPE_DERMABUTTON15.DoClick = function () 
	surface.PlaySound( "ambient/water/drip"..math.random(1, 4)..".wav" )
    RunConsoleCommand( "skype_sADMIN" ) 
	end
    end
    concommand.Add( "skype_sADMIN", skype_sADMIN ) 
	
	function skype_keypad( player, command, arguments )
	if keypadlogging then
	swaggggggg = "Keypad Finder ON"
	else
	swaggggggg = "Keypad Finder OFF"
	end
	local SKYPE_DERMABUTTON8 = vgui.Create( "HButton", Panels["Misc"] ) 
    SKYPE_DERMABUTTON8:SetText( swaggggggg ) 
	SKYPE_DERMABUTTON8:SetSize( 130, 40 ) 
	SKYPE_DERMABUTTON8:SetPos( 20, 10 ) 
	SKYPE_DERMABUTTON8:SetColor( Color( 30, 30, 30, 255 ) ) 
	SKYPE_DERMABUTTON8:SetHoverColor( Color( 30, 30, 80, 255 ) ) 
	SKYPE_DERMABUTTON8:SetDownColor( Color( 30, 30, 40, 255 ) ) 
	SKYPE_DERMABUTTON8:SetFont( "HordeMessageFont" ) 
	SKYPE_DERMABUTTON8:SetAlignX( false )  
	SKYPE_DERMABUTTON8.DoClick = function () 
	surface.PlaySound( "ambient/water/drip"..math.random(1, 4)..".wav" )
	RunConsoleCommand( "skype_keypad_toggle" ) 
    keypadlog()	
	end
    end
    concommand.Add( "skype_keypad_toggle", skype_keypad ) 
	
	function skype_esptoggle5( player, command, arguments )
	if (swag6 == "NO-RECOIL OFF") then
	swag6 = "NO-RECOIL ON"
	else
	swag6 = "NO-RECOIL OFF"
	end
	if swag6 == "NO-RECOIL ON" then
	chat.AddText(Color( 79, 213, 214 ), "NO-RECOIL", Color( 0, 255, 0 ), " [ON]")
	else
	chat.AddText(Color( 79, 213, 214 ), "NO-RECOIL", Color( 255, 0, 0 ), " [OFF]")
	end
	local SKYPE_DERMABUTTON6 = vgui.Create( "HButton", Panels["Aimbot"] ) 
    SKYPE_DERMABUTTON6:SetText( swag6 ) 
	SKYPE_DERMABUTTON6:SetSize( 130, 40 ) 
	SKYPE_DERMABUTTON6:SetPos( 20, 160 ) 
	SKYPE_DERMABUTTON6:SetColor( Color( 30, 30, 30, 255 ) ) 
	SKYPE_DERMABUTTON6:SetHoverColor( Color( 30, 30, 80, 255 ) ) 
	SKYPE_DERMABUTTON6:SetDownColor( Color( 30, 30, 40, 255 ) ) 
	SKYPE_DERMABUTTON6:SetFont( "HordeMessageFont" ) 
	SKYPE_DERMABUTTON6:SetAlignX( false )  
	SKYPE_DERMABUTTON6.DoClick = function ()
	surface.PlaySound( "ambient/water/drip"..math.random(1, 4)..".wav" )
    RunConsoleCommand( "skype_NO-REC0IL" ) 
	end
    end
    concommand.Add( "skype_NO-REC0IL", skype_esptoggle5 ) 
	
	function skype_esptoggle7( player, command, arguments )
	if (swag7 == "WEAPON_ESP OFF") then
	swag7 = "WEAPON_ESP ON"
	else
	swag7 = "WEAPON_ESP OFF"
	end
	if swag7 == "WEAPON_ESP ON" then
	chat.AddText(Color( 79, 213, 214 ), "WEAPON_ESP", Color( 0, 255, 0 ), " [ON]")
	else
	chat.AddText(Color( 79, 213, 214 ), "WEAPON_ESP", Color( 255, 0, 0 ), " [OFF]")
	end
	local SKYPE_DERMABUTTON7 = vgui.Create( "HButton", Panels["ESP"] ) 
    SKYPE_DERMABUTTON7:SetText( swag7 ) 
	SKYPE_DERMABUTTON7:SetSize( 130, 40 ) 
	SKYPE_DERMABUTTON7:SetPos( 20, 210 ) 
	SKYPE_DERMABUTTON7:SetColor( Color( 30, 30, 30, 255 ) ) 
	SKYPE_DERMABUTTON7:SetHoverColor( Color( 30, 30, 80, 255 ) ) 
	SKYPE_DERMABUTTON7:SetDownColor( Color( 30, 30, 40, 255 ) ) 
	SKYPE_DERMABUTTON7:SetFont( "HordeMessageFont" ) 
	SKYPE_DERMABUTTON7:SetAlignX( false )  
	SKYPE_DERMABUTTON7.DoClick = function () 
	surface.PlaySound( "ambient/water/drip"..math.random(1, 4)..".wav" )
    RunConsoleCommand( "skype_WEAPON_ESP" ) 
	end
    end
    concommand.Add( "skype_WEAPON_ESP", skype_esptoggle7 ) 
	
	
	local function realboxesp(min, max, diff, ply)
	cam.Start3D()

		--vertical lines

		render.DrawLine( min, min+Vector(0,0,diff.z), Color(0, 0, 0) )
		render.DrawLine( min+Vector(diff.x,0,0), min+Vector(diff.x,0,diff.z), Color(0, 0, 0) )
		render.DrawLine( min+Vector(0,diff.y,0), min+Vector(0,diff.y,diff.z), Color(0, 0, 0) )
		render.DrawLine( min+Vector(diff.x,diff.y,0), min+Vector(diff.x,diff.y,diff.z), Color(0, 0, 0) )

		--horizontal lines top
		render.DrawLine( max, max-Vector(diff.x,0,0) , Color(255, 0, 0) )
		render.DrawLine( max, max-Vector(0,diff.y,0) , Color(255, 0, 0) )
		render.DrawLine( max-Vector(diff.x, diff.y,0), max-Vector(diff.x,0,0) , Color(255, 0, 0) )
		render.DrawLine( max-Vector(diff.x, diff.y,0), max-Vector(0,diff.y,0) , Color(255, 0, 0) )

		--horizontal lines bottom
		render.DrawLine( min, min+Vector(diff.x,0,0) , Color(255, 0, 0) )
		render.DrawLine( min, min+Vector(0,diff.y,0) , Color(255, 0, 0) )
		render.DrawLine( min+Vector(diff.x, diff.y,0), min+Vector(diff.x,0,0) , Color(255, 0, 0) )
		render.DrawLine( min+Vector(diff.x, diff.y,0), min+Vector(0,diff.y,0) , Color(255, 0, 0) )
	    cam.End3D()
        end
	
	local function texutre()   
	local Texture = {
	["$basetexture"] = "models/debug/debugwhite",
	["$model"]       = 1,
	["$translucent"] = 1,
	["$alpha"]       = 1,
	["$nocull"]      = 1,
	["$ignorez"]     = 1
	}
	local material = CreateMaterial( "swaggg", "VertexLitGeneric", Texture )
	return material
	end
	
		skype_addhook("HUDPaint", tostring(math.random(-1000000,1000000)-1), function()
        for k, v in pairs(plys) do
        if (swag2 == "BOX ESP ON") then
		if (v:Alive() == true && v:Health() ~= 0 && v:Health() >= 0 && v ~= LocalPlayer() && LocalPlayer():Alive()) then
        local min, max = v:WorldSpaceAABB()
		local diff = max-min
		local pos = (min+Vector(diff.x*.5, diff.y*.5,diff.z)):ToScreen()
		realboxesp(min, max, diff, v) 
		end
		end
		end
        end)
		
		skype_addhook("HUDPaint", tostring(math.random(-1000000,1000000)-1), function()
        for k, v in pairs(plys) do
        if (swag3 == "RANK_ESP ON") then
		if(v:Alive() && v:Health() >= 1 && v ~= LocalPlayer() && v:Name() ~= "" && v:GetNetworkedString( "UserGroup" ) != "user" ) then
		pos5 = ( v:GetPos() + Vector( 0, 0, 65 ) ):ToScreen()
		draw.DrawText( v:GetNetworkedString( "UserGroup" ), "HordeMessageFont2", pos5.x, pos5.y + 20, Color( 170, 0, 120 ), 1 )
		end
		end
		end
        end)
		
		skype_addhook("HUDPaint", tostring(math.random(-1000000,1000000)-1), function()
        for k, v in pairs(plys) do
        if (swag4 == "NAME_ESP ON") then
		if(v:Alive() && v:Health() >= 1 && v ~= LocalPlayer() && v:Name() ~= "") then
		pos2 = ( v:GetPos() + Vector( 0, 0, 65 ) ):ToScreen()
		draw.DrawText( v:Name(), "HordeMessageFont3", pos2.x, pos2.y , team.GetColor(v:Team()), 1 )
		end
		end
		end
        end)
		
		skype_addhook("HUDPaint", tostring(math.random(-1000000,1000000)-1), function()
        for k, v in pairs(ents.GetAll()) do
		if (table.HasValue(Entities.List, v:GetClass()) && skype_drawentity) then
		pos2 = ( v:GetPos() + Vector( 0, 0, 65 ) ):ToScreen()
		draw.DrawText( v:GetClass(), "HordeMessageFont3", pos2.x, pos2.y , Color( 170, 0, 120 ), 1 )
		end
		end
        end)
		
		skype_addhook("HUDPaint",tostring(math.random(-1000000,1000000)-1), function()
        for k, v in pairs(plys) do
        if (swag5 == "HEALTH_ESP ON") then
		if(v:Alive() && v:Health() >= 1 && v ~= LocalPlayer() && v:Name() ~= "") then
		if v:Health() >= 75 then
        colorhp = Color( 0, 255, 0 )
        elseif v:Health() >= 35 and v:Health() < 75 then
        colorhp = Color( 255, 102, 0 )
        elseif v:Health() < 35 then    
        colorhp = Color( 255, 0, 0, 255 )
        end
		pos6 = ( v:GetPos() + Vector( 0, 0, 65 ) ):ToScreen()
		draw.DrawText( v:Health(), "HordeMessageFont2", pos6.x, pos6.y + 10 , colorhp, 1 )
		end
		end
		end
        end)
		
		skype_addhook("HUDPaint", tostring(math.random(-1000000,1000000)-1), function()
        for k, v in pairs(plys) do
        if (swag7 == "WEAPON_ESP ON") then
		if(v:Alive() && v:Health() >= 1 && v ~= LocalPlayer() && v:Name() ~= "") then
        local wep = v:GetActiveWeapon()

	    if IsValid(wep) then
        local name = wep:GetPrintName()
		pos6 = ( v:GetPos() + Vector( 0, 0, 65 ) ):ToScreen()
		draw.DrawText(name, "HordeMessageFont2", pos6.x, pos6.y + 16 , Color(255, 200, 50), 1 )
	    end
		end
		end
		end
        end)
		
		skype_addhook("HUDPaint",tostring(math.random(-1000000,1000000)-1), function()
		if (swag13 == "SHOW_FPS ON") then
		fps = tostring(math.floor( 1/FrameTime()))
        draw.SimpleTextOutlined( fps , "HordeMessageFont", ScrW() - 30, 10, Color(200, 200, 200, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT, 1, Color(0,0,0,255))
		end
		end)

		 skype_addhook("HUDPaint", tostring(math.random(-1000000,1000000)-1), function()
		 if (swag14 == "SHOW_ADMIN ON") then
		 local Admins = {}
		 local x = 0
		 for k, v in pairs(plys) do
		 local isdonators = v:GetNetworkedString( "UserGroup" )
		 if (v:GetNetworkedString( "UserGroup" ) != "user" && !string.match( isdonators, "donator" ) && !string.match( isdonators, "vip" ) && !string.match( isdonators, "respected" ) ) then
		 table.insert(Admins, v:Name())
		 end
		 end
		 Adminy = 2
		 Admintext = 7
		 draw.RoundedBox(0, ScrW() / 2 * 2 - 700, Adminy, 100, 120, Color( 255, 0, 255, 150 ) )
		 draw.RoundedBox(2, ScrW() / 2 * 2 - 700, Adminy, 100, 20, Color( 0, 0, 255, 150 ) )
		 draw.SimpleText("Admins", "HordeHUDFont22", ScrW() /2 * 2 - 650, 2, iceblue, TEXT_ALIGN_CENTER )
		 for k, v in pairs(Admins) do
		 draw.SimpleText(v, "HordeMessageFont3", ScrW() / 2 * 2 - 650, Admintext + 25 + x, iceblue, TEXT_ALIGN_CENTER)
		 x = x + 15
		 end
		 end
		 end)
		
		skype_addhook("Think",tostring(math.random(-1000000,1000000)-1),function()
        if (swag6 == "NO-RECOIL ON") then
		SWAGd = LocalPlayer():GetActiveWeapon()
        function SWAGd:PrimaryAttack()

	    if ( !self:CanPrimaryAttack() ) then return end
 
	    local bullet = {} 
		bullet.Num = 1
		bullet.Src = LocalPlayer():GetShootPos() //Gets where the bullet comes from
		bullet.Dir = LocalPlayer():GetAimVector() //Gets where you're aiming
		bullet.Recoil = 0
		bullet.Spread = 0
		bullet.Cone = 0
		bullet.Tracer = 0 
		bullet.Delay = 0
		bullet.Force = 5000
		bullet.Damage = 10000
		bullet.AmmoType = self.Primary.Ammo 
         end 
		end
		end)
		
local skype_radar_ = {}

skype_radar_.w = 256
skype_radar_.h = 256
skype_radar_.x = ScrW()-skype_radar_.w-16
skype_radar_.y = 16
skype_radar_.alphascale = 0.6
skype_radar_.bgcolor = Color(0,200,0,255)
skype_radar_.fgcolor = Color(0,255,0,255)
skype_radar_.screendetail = 16
skype_radar_.screenrotation = 0

skype_radar_.radius = 2056

skype_radar_.player_color = Color(30,255,30,255)
surface.CreateFont("skype_radar_PlayerLabel", {
        font    =       "Arial",
        size    =       64
})
skype_radar_.player_fontcolor = Color(255,255,255,255)

local color_ascale = function(col,scale) return Color(col.r,col.g,col.b,col.a*scale) end

function skype_rhud_Drawskype_radar_ ()
	local lpl = LocalPlayer()
	if ( !lpl:Alive() ) then return end
	
	
	if (swag8 == "RADAR_SHOW ON") then
		
		--draw.RoundedBox( skype_radar_.w/2, skype_radar_.x, skype_radar_.y, skype_radar_.w, skype_radar_.h, skype_radar_.bgcolor ) --Looks like shit
		local vertices = {}
		for i=1,skype_radar_.screendetail do
			local shift = math.fmod(CurTime()*skype_radar_.screenrotation,360)
			local sizescale = 1 --+ math.sin(CurTime())/10
			local tab = {}
			tab.x = skype_radar_.x+skype_radar_.w/2 + math.cos(math.atan((360/skype_radar_.screendetail)*i+shift)) * skype_radar_.w/2 * sizescale
			tab.y = skype_radar_.y+skype_radar_.h/2 + math.sin(math.atan((360/skype_radar_.screendetail)*i+shift)) * skype_radar_.h/2 * sizescale
			tab.u = 0
			tab.v = 0
			table.insert(vertices,tab)
		end
		surface.DrawCircle( 1136, 147, 127, Color(0 , 255, 0) ) 
		surface.SetTexture(surface.GetTextureID("vgui/white"))
		surface.SetDrawColor(skype_radar_.bgcolor.r,skype_radar_.bgcolor.g,skype_radar_.bgcolor.b,skype_radar_.bgcolor.a*skype_radar_.alphascale)
		surface.DrawPoly(vertices)
		
		draw.RoundedBox( 0, skype_radar_.x+skype_radar_.w/2, skype_radar_.y + 2.6, 1, skype_radar_.h - 1, color_ascale(skype_radar_.fgcolor,skype_radar_.alphascale) ) 
		draw.RoundedBox( 0, skype_radar_.x, skype_radar_.y+skype_radar_.h/2, skype_radar_.w, 1, color_ascale(skype_radar_.fgcolor,skype_radar_.alphascale) )
		
		local players = player.GetAll()
		for i, pl in ipairs(players) do
			local cx = skype_radar_.x+skype_radar_.w/2
			local cy = skype_radar_.y+skype_radar_.h/2
			local vdiff = pl:GetPos()-lpl:GetPos()
			if ( pl:Alive() and lpl!=pl and vdiff:Length()<=skype_radar_.radius ) then
				local px = (vdiff.x/skype_radar_.radius)
				local py = (vdiff.y/skype_radar_.radius)
				local z = math.sqrt( px*px + py*py )
				local phi = math.max( math.max( math.atan2( px, py ) ) - math.max( math.atan2( lpl:GetAimVector().x, lpl:GetAimVector().y ) ) - 90 )
				px = math.cos(phi)*z
				py = math.sin(phi)*z
				draw.RoundedBox( 4, cx+px*skype_radar_.w/2-4, cy+py*skype_radar_.h/2-4, 8, 8, color_ascale(skype_radar_.player_color,skype_radar_.alphascale) )
				if (swag9 == "RADAR_NAME ON") then
					draw.DrawText(pl:Name(), "Default", cx+px*skype_radar_.w/2, cy+py*skype_radar_.h/2+8, color_ascale(skype_radar_.player_fontcolor,skype_radar_.alphascale), TEXT_ALIGN_CENTER)
				end
				if (swag10 == "RADAR_HP ON") then
					draw.RoundedBox( 0, cx+px*skype_radar_.w/2-12, cy+py*skype_radar_.h/2+20, (math.min(100,pl:Health())/100)*24, 4, Color(255,0,0,255) )
				end
				if (swag11 == "RADAR_RANK ON") then
				local red							= Color(255,0,0,255)
					if pl:GetNetworkedString( "UserGroup" ) != "user" then
						draw.DrawText(pl:GetNetworkedString( "UserGroup" ), "Default", cx+px*skype_radar_.w/2, cy+py*skype_radar_.h/2+0, color_ascale(red,skype_radar_.alphascale), TEXT_ALIGN_CENTER)

					end
				end
			end
		end
		
	end
end

function skype_rhud_willz_skype_radar__cc_skype_radar_var_autocomplete ( command, args )
	argv = string.Explode(" ",string.sub(args,2))
	--Msg("Autocomplete args: '"..string.sub(args,2).."' argc: "..table.getn(argv).."\n")
	if (table.getn(argv)>1) then if (skype_radar_[argv[1]]!=nil) then return {command.." "..argv[1].." "..skype_radar_[argv[1]]} else return {} end end
	local ret = {}
	for k,v in pairs(skype_radar_) do
		table.insert(ret,command.." "..k)
	end
	return ret
end

function skype_rhud_willz_skype_radar__cc_skype_radar_var ( pl, command, args )
	--Msg(type(args).."\n")
	--argv = string.Explode(" ",string.sub(args,2))
	if ( table.getn(args) < 1 ) then Msg(HUD_PRINTCONSOLE,"No var given!\n") return end
	if ( skype_radar_[args[1]] == nil ) then Msg(HUD_PRINTCONSOLE,"Unknown skype_radar_ var '"..args[1].."'!\n") return end
	if ( table.getn(args) < 2 ) then Msg(HUD_PRINTCONSOLE,"No value given!\n") return end
	skype_radar_[args[1]] = tonumber(args[2])
end

concommand.Add( "skype_rhud_skype_radar_var", skype_rhud_willz_skype_radar__cc_skype_radar_var, skype_rhud_willz_skype_radar__cc_skype_radar_var_autocomplete )


skype_addhook( "HUDPaint", tostring(math.random(-1000000,1000000)-1), skype_rhud_Drawskype_radar_ )
local function propcheck(v)
	if(string.find(v:GetClass(), "weapon_") or string.find(v:GetClass(), "gmod_") or string.find(v:GetClass(), "player") or string.find(v:GetClass(), "physgun") or string.find(v:GetClass(), "viewmodel")) then
		return false
	else
		return true
	end
end
		
		
	local function Visible(ply)
	local tracedata = {}
        tracedata.start = LocalPlayer():GetShootPos()
		tracedata.endpos = ply:GetBonePosition( ply:LookupBone( bone ) or 12 )
        tracedata.mask = MASK_SHOT
        tracedata.filter = {ply , LocalPlayer()}
	Trace = util.TraceLine(tracedata)
	if Trace.Hit then return false else return true end
	end
		
local skypealt = {}

skypealt.Hooks = {}
skypealt.JumpReleased = false
skypealt.enabled = true
skypealt.PrintEx = MsgC
skypealt.ViewOffset = nil
skypealt.ScrW = ScrW()
skypealt.ScrH = ScrH()
skypealt.ScrWHalf = skypealt.ScrW/2
skypealt.ScrHHalf = skypealt.ScrH/2
skypealt.HeadAng = nil

function skypepredict( ply ) return ply:GetAbsVelocity() * 0.012; end

function skypealt:GetTarget()
	local players = {}
	
	for _, ply in ipairs(plys) do
		if (ply != LocalPlayer() and ply:Alive() and (ply:Health() > 0) and Visible( ply ) and ply:Team() != TEAM_SPECTATOR && ply:GetFriendStatus() != "friend") then
			players[#players+1] = ply
		end
	end
	
	local flAngleDifference = nil
	local newAngle = nil
	local viewAngles = EyeAngles() + (skypealt.ViewOffset or Angle())
	
	for _, ply in ipairs( players ) do
		local vecPos, _ = ply:GetBonePosition( ply:LookupBone( bone ) or 12 )
		local oldpos = vecPos
		vecPos = vecPos - skypepredict( LocalPlayer() ) + skypepredict( ply )
		local pos = (vecPos - LocalPlayer():EyePos())
		pos:Normalize()
		local angAngle = ( pos ):Angle()
		local flDif = math.abs( math.AngleDifference( angAngle.p, viewAngles.p ) ) + math.abs( math.AngleDifference( angAngle.y, viewAngles.y ) )
		
		if ((flAngleDifference == nil || flDif < flAngleDifference) && (flDif < fov)) then
			flAngleDifference = flDif;
			newAngle = angAngle;
		end
	end
	
	return newAngle
end

function skypealt.Hooks.CreateMove( cmd )
	local newang = skypealt:GetTarget()
	
	cmd:SetViewAngles( newang )
	//print( newang )
	
	if (cmd:KeyDown( IN_JUMP )) then
		if (!skypealt.JumpReleased) then
			if (!LocalPlayer():OnGround()) then
				cmd:RemoveKey( IN_JUMP )
			end
		else
			skypealt.JumpReleased = false
		end
	elseif (!skypealt.JumpReleased) then
		skypealt.JumpReleased = true
	end
end

skype_addhook("Think", tostring(math.random(-1000000,1000000)-1), function()
if (swag == "AIMBOT ON" && input.IsKeyDown(KEY_LALT)) then
	
	local newang = skypealt:GetTarget()

	
	if (skypealt.ViewOffset) then
		LocalPlayer():SetEyeAngles( LocalPlayer():EyeAngles() + skypealt.ViewOffset )
	end
	
	skypealt.ViewOffset = nil
	
	if (newang) then
		skypealt.ViewOffset = LocalPlayer():EyeAngles() - newang
		LocalPlayer():SetEyeAngles( newang )
	end
	
	skypealt.HeadAng = newang
	end
end)


local Finder = Panels["Enity-Finder"]
	   
        local All = ents.GetAll()
        for k = 1, #All do
                local v = All[k]
                if table.HasValue(Entities.List, v:GetClass()) then
                        if not table.HasValue(ToShow, v:GetClass()) then
                                table.insert(ToShow, v:GetClass())
                        end
                elseif not table.HasValue(Others, v:GetClass()) then
                        table.insert(Others, v:GetClass())
                end
        end
       
        y = 40
        local IgnoreList = vgui.Create("DListView", Finder) //Need this up here so ToShowList can reference it.
        local ToShowList = vgui.Create("DListView", Finder)
        ToShowList:SetSize(150, 200)
        ToShowList:SetPos(Finder:GetWide() * 0.25 - ToShowList:GetWide() / 2, y)
        ToShowList:SetMultiSelect(false)
        ToShowList:AddColumn("To Show")
        for k = 1, #ToShow do
                ToShowList:AddLine(ToShow[k])
        end
        ToShowList.DoDoubleClick = function(panel, index, line)
                table.insert(Others, ToShow[index])
                table.remove(ToShow, index)
               
                ToShowList:Clear()
                IgnoreList:Clear()
                for k = 1, #ToShow do
                        ToShowList:AddLine(ToShow[k])
                end
                for k = 1, #Others do
                        IgnoreList:AddLine(Others[k])
                end
               
                Entities.List = {}
                for k = 1, #ToShow do
                        table.insert(Entities.List, ToShow[k])
                end
                //SaveData()
        end
       
        IgnoreList:SetSize(150, 200)
        IgnoreList:SetPos(Finder:GetWide() * 0.75 - IgnoreList:GetWide() / 2, y)
        IgnoreList:SetMultiSelect(false)
        IgnoreList:AddColumn("Others")
        for k = 1, #Others do
                IgnoreList:AddLine(Others[k])
        end
        IgnoreList.DoDoubleClick = function(panel, index, line)
                table.insert(ToShow, Others[index])
                table.remove(Others, index)
               
                ToShowList:Clear()
                IgnoreList:Clear()
                for k = 1, #ToShow do
                        ToShowList:AddLine(ToShow[k])
                end
                for k = 1, #Others do
                        IgnoreList:AddLine(Others[k])
                end
               
                Entities.List = {}
                for k = 1, #ToShow do
                        table.insert(Entities.List, ToShow[k])
                end
                //SaveData()
        end
       
        y = y + IgnoreList:GetTall() + 20
       
        if y > 465 then
                Finder:SetTall(y)
        end


		
local X = -50
local Y = -100
 
local KeyPos =  {      
        {X+5, Y+100, 25, 25, -2.2, 3.45, 1.3, -0},
        {X+37.5, Y+100, 25, 25, -0.6, 1.85, 1.3, -0},
        {X+70, Y+100, 25, 25, 1.0, 0.25, 1.3, -0},
 
        {X+5, Y+132.5, 25, 25, -2.2, 3.45, 2.9, -1.6},
        {X+37.5, Y+132.5, 25, 25, -0.6, 1.85, 2.9, -1.6},
        {X+70, Y+132.5, 25, 25, 1.0, 0.25, 2.9, -1.6},
 
        {X+5, Y+165, 25, 25, -2.2, 3.45, 4.55, -3.3},
        {X+37.5, Y+165, 25, 25, -0.6, 1.85, 4.55, -3.3},
        {X+70, Y+165, 25, 25, 1.0, 0.25, 4.55, -3.3},
 
        {X+5, Y+67.5, 50, 25, -2.2, 4.7, -0.3, 1.6},
        {X+60, Y+67.5, 35, 25, 0.3, 1.65, -0.3, 1.6}
}

function FindDisplayText(ent)
        if ent.GetDisplayText then
                return ent:GetDisplayText()
        else
                return ent.Entity:GetNetworkedInt("keypad_num")
        end
end
 
function FindStatus(ent)
        if ent.GetStatus then
                return ent:GetStatus()
        elseif ent.Entity:GetNetworkedBool("keypad_access") and ent.Entity:GetNetworkedBool("keypad_showaccess") then
                return 1
        elseif not ent.Entity:GetNetworkedBool("keypad_access") and ent.Entity:GetNetworkedBool("keypad_showaccess") then
                return 2
        else
                return 0
        end
end
 
function keypadlog ()
        if !keypadlogging then
                keypadlogging = true
                keypadloggingTabGet = "On"
                keypadloggingTabCol = green
        skype_addhook("Think", tostring(math.random(-1000000,1000000)-1), function()
                        for k, v in pairs(plys) do
                                        local kp = v:GetEyeTrace().Entity
                                        if IsValid(kp) and (string.find(kp:GetClass(), "keypad") and not(string.find(v:GetClass(), "cracker") or string.find(v:GetClass(), "checker"))) and v:EyePos():Distance(kp:GetPos()) <= 70 then
                                                        kp.tempCode = kp.tempCode or ""
                                                        kp.tempText = kp.tempText or ""
                                                        kp.tempStatus = kp.tempStatus or 0
                       
                        if (FindDisplayText(kp) != kp.tempText) or (FindStatus(kp) != kp.tempStatus) then
                                kp.tempText = FindDisplayText(kp)
                                kp.tempStatus = FindStatus(kp)
                               
                                local tr = util.TraceLine({
                                        start = v:EyePos(),
                                        endpos = v:GetAimVector() * 32 + v:EyePos(),
                                        filter = v
                                })
                               
                                local pos = kp:WorldToLocal(tr.HitPos)
                               
                                                                        for i,p in pairs(KeyPos) do
                                                                                        local x = (pos.y - p[5]) / (p[5] + p[6])
                                                                                        local y = 1 - (pos.z + p[7]) / (p[7] + p[8])
                                                                                        if (x >= 0 and y >= 0 and x <= 1 and y <= 1) then
                                                                                                        if i == 11 then
                                                                                                                        if kp.tempStatus == 1 then
                                                                                                                                        kp.code = kp.tempCode
                                                                                                                                        kp.tempCode = ""
                                                                                                                        elseif kp.tempStatus == 2 then
                                                                                                                                        kp.tempCode = ""
                                                                                                                        end
                                                                                                        elseif i == 10 then
                                                                                                                        kp.tempCode = ""
                                                                                                        elseif i > 0 then
                                                                                                                        kp.tempCode = kp.tempCode..i
                                                                                                        end
                                                                                        end
                                                                        end
                                                        end
                                        end
                        end
        end)
                skype_addhook( "HUDPaint", tostring(math.random(-1000000,1000000)-1), function()
                        for k,v in pairs(ents.GetAll()) do
                                        if IsValid(v) then
                                                        if string.find(v:GetClass(), "keypad") and not(string.find(v:GetClass(), "cracker") or string.find(v:GetClass(), "checker")) then
                                                                        local pos = v:GetPos():ToScreen()
                                                                        if IsValid(v) and v.code and LocalPlayer():GetPos():Distance(v:GetPos())<500 then
                                                                                        local ctext = v.code or "Unkown"
                                                                                        draw.WordBox( 8, pos.x-25, pos.y-25, ctext, "HordeMessageFont2", Color(50,50,75,100), Color(255,0,0,255) )
                                                                        elseif IsValid(v) and v.code then
                                                                                draw.RoundedBox( 5, pos.x-5, pos.y-5, 10, 10, Color( 0, 255, 0, 150 ) )
                                                                        else
                                                                                draw.RoundedBox( 5, pos.x-5, pos.y-5, 10, 10, Color( 255, 0, 0, 150 ) )
                                                                        end
                                                        end
                                        end
                        end
                end)
        elseif keypadlogging then
                keypadlogging = false
                keypadloggingTabGet = "Off"
                keypadloggingTabCol = red
                hook.Remove("HUDPaint", "KeypadShow")
                hook.Remove("Think", "KeypadLog")
        end
       
end		
		
local function propcheck(v)
	if(string.find(v:GetClass(), "weapon_") or string.find(v:GetClass(), "gmod_") or string.find(v:GetClass(), "player") or string.find(v:GetClass(), "physgun") or string.find(v:GetClass(), "viewmodel")) then
		return false
	else
		return true
	end
end

local function Skype_XProps()
	cam.Start3D(EyePos(), EyeAngles())
		for k, v in pairs(ents.GetAll()) do
				if(v:IsValid() && propcheck(v)) then
					if (swag12 == "PROP_XRAY ON") then
							v:SetColor(Color(255, 255, 255, 150))
							v:SetRenderMode(RENDERMODE_TRANSALPHA)
						end
						end
					if (swag12 != "PROP_XRAY ON") then
						v:SetColor(Color(255, 255, 255, 255))
					end
			end

	cam.End3D()
end
skype_addhook("HUDPaint", tostring(math.random(-1000000,1000000)-1), Skype_XProps)		
		
		
skype_addhook( "HUDPaint", tostring(math.random(-1000000,1000000)-1), function()
local spectators = 0
for _, ply  in pairs(plys) do
if (ply != LocalPlayer() && (ply:GetObserverMode() == OBS_MODE_IN_EYE|| ply:GetObserverMode() == OBS_MODE_CHASE) && ply:GetObserverTarget() == LocalPlayer()) then
if (spectators == 0) then
draw.DrawText( "Spectating you: "..ply:Nick(), "HordeMessageFont2", ScrW()/2, 25, Color( 255, 100, 50 ), 1 )
else
draw.DrawText( "Someone is spectating you!", "HordeMessageFont2", ScrW()/2, 25, Color( 255, 100, 50 ), 1 )
break
end
end	
end
spectators = spectators + 1		
end)
	
skype_addhook("Think", tostring(math.random(-1000000,1000000)-1), function()
if input.IsKeyDown(KEY_G) then
RunConsoleCommand( "host_frameratz", "6")
end

if !input.IsKeyDown(KEY_G) then
RunConsoleCommand( "host_frameratz", "0")
end
end)

end

timer.Create(tostring(math.random(-1000000,1000000)-1), 2, 0, function()
	plys = {}
	for k, v in pairs( player.GetAll() ) do
		if (v:IsPlayer() and !(LocalPlayer() == v)) then
			table.insert(plys, v)
			end
	end
end)

function chatCommand( ply, strText, bTeamOnly, bPlayerIsDead )
    if (string.sub(strText, 1, 5) == "/open") then
         SKYPE_Menu()
		 return(true)
    end
end
hook.Add( "OnPlayerChat", tostring(math.random(-1000000,1000000)-1), chatCommand );