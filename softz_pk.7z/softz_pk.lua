-- Note by paradox:
-- Software's private propkill script!

local ply = LocalPlayer()
local chamscolor = Color(0, 255, 255) 
local boxcolor = Color(255, 255, 255) 
local tracecolor = Color(255, 255, 255) 
local namecolor = Color(255, 255, 255) 
local headlinecolor = Color(255, 0, 0) 
local eyetracecolor = Color(255, 0, 0)
local MaterialType = MaterialType or 1 



local matchams = CreateMaterial("chams", "UnlitGeneric", {
    ["$basetexture"] = "models/debug/debugwhite",
    ["$ignorez"] = 1,
    ["$color2"] = "[" .. chamscolor.r/255 .. " " .. chamscolor.g/255 .. " " .. chamscolor.b/255 .. "]",
    ["$model"] = 1
})



local function UpdateMaterials()
    matchams:SetVector("$color2", Vector(chamscolor.r/255, chamscolor.g/255, chamscolor.b/255))
   
end

local vars = {
 cham = true,
 propcham = true,
 headline = true,
 worldcoll = false,
 tracer = false,
 name = true,
 fov = true,
 thirdperson = false,
 bhop = true,
 box = true,
 asus = false,
 info = true,
 infovv = false,
 deathsay = false,
 killsay = false,
 eyetracer = false,
 customsky = GetConVar("sv_skyname"):GetString(),
 
 }



surface.CreateFont("Font", {
    font = "Arial",
    extended = true,
    size = 18
})

surface.CreateFont("bigg", {
    font = "Arial",
    extended = true,
    strikeout = true,
    size = 30
})

surface.CreateFont("ButFont", {
    font = "Arial",
    extended = true,
    size = 17
})

surface.CreateFont("MenuOptions", {
    	font = "Console",
    	size = 13,
    	weight = 900,
    	shadow = true,
    	antialias = false,
    });
    
    surface.CreateFont("Buttonfonto", {
    	font = "Console",
    	size = 14,
    	weight = 700,
    	shadow = true,
    	extended = true,
    	antialias = false,
    });
    
    local function DrawBox(x, y, w, h, text)
    	surface.SetDrawColor(40, 40, 255);
    	surface.DrawLine(x, y, x, y + h);
    	surface.DrawLine(x, y + h, x + w, y + h);
    	surface.DrawLine(x + w, y, x + w, y + h);
    	surface.DrawLine(x, y, x + 5, y);
    	surface.SetFont("MenuOptions");
    	local tw, th = surface.GetTextSize(text);
    	surface.SetTextColor(220, 220, 220);
    	surface.SetTextPos(x + 10, y - th / 2);
    	surface.DrawText(text);
    	surface.DrawLine(x + 10 + tw + 5, y, x + w, y);
    end
   local function checkbox(name, tooltip, val, x, y, parent)
    local checkbox = vgui.Create("DCheckBoxLabel", parent)
    checkbox:SetText(name)
    checkbox:SetPos(x, y)
    checkbox:SetTextColor(Color(50, 50, 50))
    checkbox:SetChecked(vars[val])

    if isstring(tooltip) then
        checkbox:SetTooltip(tooltip)
    end

    function checkbox:OnChange(bval)
        vars[val] = bval
    end

    function checkbox:PaintOver(width, height)
        -- Draw the background
        draw.RoundedBox(0, 0, 0, 15, 15, Color(200, 200, 200))

        -- Draw the blue checkmark if checked
        if self:GetChecked() then
            draw.RoundedBox(0, 1, 1, 13, 13, Color(40, 40, 200))
        end
    end
end

--- menu

local frame

local function ui()
 if IsValid(frame) then
        frame:Close()
        frame = nil
    else
	frame = vgui.Create("DFrame")
	frame:SetSize(500, 500) 
	frame:Center()
	frame:SetTitle("") 
	frame:SetDraggable(true) 
	frame:ShowCloseButton(false) 
	frame:MakePopup() 

	--- details
	frame.Paint = function(self, w, h)
	    draw.RoundedBox(2, 0, 0, w, h, Color(170,170,170))
	    draw.RoundedBox(0, 0, 30, w, 1, Color(40,40,255))
	    DrawBox(20, 40, 200, 190, "Players");
	    DrawBox(20, 240, 200, 100, "World");
	    DrawBox(20, 350, 200, 130, "Misc");
	    draw.SimpleText("SoftZ v0.7", "Font", 10, 6, Color(40,40,255))
	end
	
		
	
	
	--buttonz
	
	checkbox("Name","Enables Names", "name", 33, 50, frame)
	checkbox("Chams","Enables Player Chams", "cham", 33, 70, frame)
	checkbox("Head Line","Draws a line from players head up", "headline", 33, 90, frame)
	checkbox("Tracers","darws linees", "tracer", 33, 110, frame)
	checkbox("Eye Tracers","draws a line from eyes", "eyetracer", 33, 130, frame)
	checkbox("Box","draws a box", "box", 33, 150, frame)
	checkbox("In Fov Alert","Alerts you if your in a fov of someone", "infovv", 33, 170, frame)
	checkbox("Prop Chams","Enables Prop Chams", "propcham", 33, 250, frame)
	checkbox("World Color","Changes world color", "worldcoll", 33, 270, frame)
	checkbox("Asus Walls","Xray Vision OMG", "asus", 33, 290, frame)
	checkbox("Fov","Changes fov to 120 (the best amount)", "fov", 33, 380, frame)
	checkbox("Thirdperson","Thirdperson", "thirdperson", 33, 400, frame)
	checkbox("Bunny Hop","Jumpy", "bhop", 33, 360, frame)
	checkbox("KillSay","Chats when you kill haha", "killsay", 33, 420, frame)
	checkbox("DeathSay","Chats when you die", "deathsay", 33, 440, frame)
	checkbox("Info","Displays Info", "info", 33, 460, frame)
	
	--- colors 
	
	        local worldcol = vgui.Create("DImageButton", frame)
		worldcol:SetImage("icon16/color_wheel.png")
		worldcol:SetSize(16, 16)
		worldcol:SetPos(120, 270)
		function worldcol:DoClick()
		RunConsoleCommand("opencolor")
		end
		
		local chamcol = vgui.Create("DImageButton", frame)
		chamcol:SetImage("icon16/color_wheel.png")
		chamcol:SetSize(16, 16)
		chamcol:SetPos(95, 70)
		function chamcol:DoClick()
		RunConsoleCommand("opencolorcham")
		end
		
		
		local headcol = vgui.Create("DImageButton", frame)
		headcol:SetImage("icon16/color_wheel.png")
		headcol:SetSize(16, 16)
		headcol:SetPos(110, 90)
		function headcol:DoClick()
		RunConsoleCommand("opencolorhead")
		end
		
		local boxcol = vgui.Create("DImageButton", frame)
		boxcol:SetImage("icon16/color_wheel.png")
		boxcol:SetSize(16, 16)
		boxcol:SetPos(80, 150)
		function boxcol:DoClick()
		RunConsoleCommand("opencolorbox")
		end
		
		local tracecol = vgui.Create("DImageButton", frame)
		tracecol:SetImage("icon16/color_wheel.png")
		tracecol:SetSize(16, 16)
		tracecol:SetPos(100, 110)
		function tracecol:DoClick()
		RunConsoleCommand("opencolortrace")
		end
		
		local eyetracecol = vgui.Create("DImageButton", frame)
		eyetracecol:SetImage("icon16/color_wheel.png")
		eyetracecol:SetSize(16, 16)
		eyetracecol:SetPos(120, 130)
		function eyetracecol:DoClick()
		RunConsoleCommand("opencoloreyetrace")
		end
		
		local namecol = vgui.Create("DImageButton", frame)
		namecol:SetImage("icon16/color_wheel.png")
		namecol:SetSize(16, 16)
		namecol:SetPos(90, 50)
		function namecol:DoClick()
		RunConsoleCommand("opencolorname")
		end
		
	--- mats
	
	local propmat = vgui.Create( "DComboBox", frame)
	propmat:SetPos( 120, 249 )
	propmat:SetSize( 90, 20 )
	propmat:SetValue( "Prop Material" )
	propmat:AddChoice( "Galaxy" )
	propmat:AddChoice( "Water" )
	propmat:AddChoice( "Plasma" )
	propmat:AddChoice( "Chrome" )
	propmat:AddChoice( "Fire" )
	propmat:AddChoice( "Alien" )
	propmat:AddChoice( "Glass" )
	propmat.OnSelect = function( self, index, value )
		MaterialType = ( index )
	end
	propmat.Paint = function( self, w, h ) draw.RoundedBox( 0, 0, 0, w, h, Color( 200, 200, 200) ) end 
 
	
	--- cool stuff
	
	local textEntry = vgui.Create("DTextEntry", frame)
        textEntry:SetPos(33, 310)
        textEntry:SetSize(90, 20)
        textEntry:SetText("Custom Skybox")
       


       local function UpdateCustomSky()
         local customSky = textEntry:GetValue()
       if customSky ~= "" then
          vars = vars or {}  
          vars.customsky = customSky
          print("vars.customsky has been set to: " .. customSky)
      end
  end

  textEntry.OnEnter = UpdateCustomSky
  
   local listView = vgui.Create("DListView", frame)
   listView:SetPos(237, 40)
   listView:SetSize(250, 190)
   listView:AddColumn("Name")
   listView:AddColumn("SteamID")


  for _, column in ipairs(listView.Columns) do
      column.Header.Paint = function(self, w, h)
        draw.RoundedBox(0, 0, 0, w, h, Color(40, 40, 255)) 
        self:SetTextColor(Color(255, 255, 255)) 
        self:SetFont("DermaDefaultBold") 
    end
  end

   listView.Paint = function(self, w, h)
      draw.RoundedBox(0, 0, 0, w, h, Color(200, 200, 200))
   end

  for _, ply in ipairs(player.GetAll()) do
    local line = listView:AddLine(ply:Nick(), ply:SteamID())
    line.ply = ply
  end

  listView.OnRowSelected = function(_, index, row)
    local steamID = row:GetValue(2)
    SetClipboardText(steamID)
    print("Copied SteamID: " .. steamID)
  end
        
        
	
end
end

--- menu functions

hook.Add("Think", "insmenu", function()
    if input.IsKeyDown(KEY_INSERT) then
        if not okk then
            ui()
            okk = true
        end
    else
        okk = false
    end
end)

--- sub menus mostly colors

--- world 
concommand.Add( "opencolor", function()
local frame = vgui.Create("DFrame")
frame:SetTitle("World Color Changer")
frame:SetSize(300, 400)
frame:Center()
frame:MakePopup()


local colorMixer = vgui.Create("DColorMixer", frame)
colorMixer:SetPos(10, 30)
colorMixer:SetSize(280, 320)
colorMixer:SetPalette(true)
colorMixer:SetAlphaBar(true)
colorMixer:SetWangs(true)
colorMixer:SetColor(Color(255, 255, 255))


local function UpdateWorldColors()
    local color = colorMixer:GetColor()
    local colVector = Vector(color.r / 255, color.g / 255, color.b / 255)
if vars.worldcoll then
    for k, v in pairs(Entity(0):GetMaterials()) do
        local mat = Material(v)
        if mat then
            mat:SetVector("$color", colVector)
            mat:SetFloat("$alpha", color.a / 255)
        end
    end
    

    print("Changed world color to: " .. tostring(color))
    end
end

local applyButton = vgui.Create("DButton", frame)
applyButton:SetText("Apply Color")
applyButton:SetPos(10, 360)
applyButton:SetSize(280, 30)
applyButton.DoClick = UpdateWorldColors
end)

-- cham

concommand.Add( "opencolorcham", function()
local frame = vgui.Create("DFrame")
frame:SetTitle("Cham Color Changer")
frame:SetSize(300, 400)
frame:Center()
frame:MakePopup()


local colorMixer1 = vgui.Create("DColorMixer", frame)
colorMixer1:SetPos(10, 30)
colorMixer1:SetSize(280, 320)
colorMixer1:SetPalette(true)
colorMixer1:SetAlphaBar(true)
colorMixer1:SetWangs(true)
colorMixer1:SetColor(chamscolor)
 colorMixer1.ValueChanged = function(self, col)
        chamscolor = col
        UpdateMaterials()
    end
end)

-- prop


-- head

concommand.Add( "opencolorhead", function()
local frame = vgui.Create("DFrame")
frame:SetTitle("Prop Cham Color Changer")
frame:SetSize(300, 400)
frame:Center()
frame:MakePopup()


local colorMixer3 = vgui.Create("DColorMixer", frame)
colorMixer3:SetPos(10, 30)
colorMixer3:SetSize(280, 320)
colorMixer3:SetPalette(true)
colorMixer3:SetAlphaBar(true)
colorMixer3:SetWangs(true)
colorMixer3:SetColor(headlinecolor)
 colorMixer3.ValueChanged = function(self, col)
        headlinecolor = col
        UpdateMaterials()
    end
end)

--- box 

concommand.Add( "opencolorbox", function()
local frame = vgui.Create("DFrame")
frame:SetTitle("Box Color Changer")
frame:SetSize(300, 400)
frame:Center()
frame:MakePopup()


local colorMixer4 = vgui.Create("DColorMixer", frame)
colorMixer4:SetPos(10, 30)
colorMixer4:SetSize(280, 320)
colorMixer4:SetPalette(true)
colorMixer4:SetAlphaBar(true)
colorMixer4:SetWangs(true)
colorMixer4:SetColor(boxcolor)
 colorMixer4.ValueChanged = function(self, col)
        boxcolor = col
        UpdateMaterials()
    end
end)

-- trace

concommand.Add( "opencolortrace", function()
local frame = vgui.Create("DFrame")
frame:SetTitle("Box Color Changer")
frame:SetSize(300, 400)
frame:Center()
frame:MakePopup()


local colorMixer5 = vgui.Create("DColorMixer", frame)
colorMixer5:SetPos(10, 30)
colorMixer5:SetSize(280, 320)
colorMixer5:SetPalette(true)
colorMixer5:SetAlphaBar(true)
colorMixer5:SetWangs(true)
colorMixer5:SetColor(tracecolor)
 colorMixer5.ValueChanged = function(self, col)
        tracecolor = col
        UpdateMaterials()
    end
end)

--- eye tracer

concommand.Add( "opencoloreyetrace", function()
local frame = vgui.Create("DFrame")
frame:SetTitle("Box Color Changer")
frame:SetSize(300, 400)
frame:Center()
frame:MakePopup()


local colorMixer6 = vgui.Create("DColorMixer", frame)
colorMixer6:SetPos(10, 30)
colorMixer6:SetSize(280, 320)
colorMixer6:SetPalette(true)
colorMixer6:SetAlphaBar(true)
colorMixer6:SetWangs(true)
colorMixer6:SetColor(eyetracecolor)
 colorMixer6.ValueChanged = function(self, col)
        eyetracecolor = col
        UpdateMaterials()
    end
end)

--- name

concommand.Add( "opencolorname", function()
local frame = vgui.Create("DFrame")
frame:SetTitle("Box Color Changer")
frame:SetSize(300, 400)
frame:Center()
frame:MakePopup()


local colorMixer7 = vgui.Create("DColorMixer", frame)
colorMixer7:SetPos(10, 30)
colorMixer7:SetSize(280, 320)
colorMixer7:SetPalette(true)
colorMixer7:SetAlphaBar(true)
colorMixer7:SetWangs(true)
colorMixer7:SetColor(namecolor)
 colorMixer7.ValueChanged = function(self, col)
        namecolor = col
        UpdateMaterials()
    end
end)




--- scripts

--- chams head line etc



hook.Add("PrePlayerDraw", "chammer", function(ply)
    if IsValid(ply) and ply:IsPlayer() and vars.cham and ply:Team() == TEAM_SPECTATOR == false then
        render.MaterialOverride(matchams)
        render.SuppressEngineLighting(true)
    end
end)

hook.Add("PostPlayerDraw", "resetchammer", function(ply)
    if IsValid(ply) and ply:IsPlayer() and vars.cham and ply:Team() == TEAM_SPECTATOR == false then
        render.MaterialOverride(nil)
        render.SuppressEngineLighting(false)
    end
end)

-- prop


local function cham()

if MaterialType == 1 then
		material = ("Models/effects/comball_sphere")
end
if MaterialType == 2 then
		material = ("models/props_combine/stasisshield_sheet")
end
if MaterialType == 3 then
		material = ("models/props_combine/portalball001_sheet")
end
if MaterialType == 4 then
		material = ("debug/env_cubemap_model")
end
if MaterialType == 5 then
		material = ("models/shadertest/shader4")
end
if MaterialType == 6 then
		material = ("models/XQM/LightLinesRed_tool")
end

if MaterialType == 7 then
		material = ("models/props_combine/com_shield001a")
end
 
 
    for k,v in pairs(ents.FindByClass("prop_physics")) do
        if vars.propcham then
            xray = 1
            cam.Start3D()
            local distance = v:GetPos():Distance(ply:GetPos())
                cam.IgnoreZ(true)
                v:SetRenderMode(RENDERMODE_TRANSALPHA)
                v:SetColor(Color(0,255,255,255))
                 render.MaterialOverride(Material(material))
                v:DrawModel()  
                render.DrawWireframeBox(v:GetPos(), v:GetAngles(), v:OBBMins() + Vector(5, 5, 5), v:OBBMaxs() - Vector(5, 5, 5), Color(0,255,255,255))
                v:AddEffects(256)
            cam.End3D()
            else
                xray = 0
                v:SetColor(Color(50,50,50,255))
        end
    end
end
hook.Add("RenderScreenspaceEffects", "cham", cham)
 


hook.Add("PostDrawTranslucentRenderables", "headliner", function()
if vars.headline then
    for _, ply in ipairs(player.GetAll()) do
        if IsValid(ply) and ply:Team() == TEAM_SPECTATOR == false then
            local startPos = ply:GetPos() + Vector(0, 0, 60)
            local endPos = startPos + Vector(0, 0, 5000)
            render.DrawLine(startPos, endPos, headlinecolor, true)
        end
        end
    end
end)

hook.Add("HUDPaint", "TRacerr", function()
    local ply = LocalPlayer()
if vars.tracer then
    if not IsValid(ply) then return end


    local weapon = ply:GetActiveWeapon()
    if not IsValid(weapon) or weapon:GetClass() ~= "weapon_physgun" then return end

    local startPos = ply:GetEyeTrace().HitPos:ToScreen()

    surface.SetDrawColor(tracecolor.r, tracecolor.g, tracecolor.b) 

    for _, target in ipairs(player.GetAll()) do
        if IsValid(target) and target ~= ply and target:Team() == TEAM_SPECTATOR == false then
            local endPos = target:GetPos():ToScreen()
            surface.DrawLine(startPos.x, startPos.y, endPos.x, endPos.y)
        end
        end
    end
end)

hook.Add("HUDPaint", "Nameresper", function()
if vars.name then
    for _, ply in ipairs(player.GetAll()) do
        if IsValid(ply) and ply ~= LocalPlayer() and ply:Team() == TEAM_SPECTATOR == false then
            local pos = ply:GetPos()
            local posScreen  = ( ply:GetPos() + Vector( 0,0,80 ) ):ToScreen()

            if posScreen.visible then
              
                local distance = ply:GetPos():Distance(LocalPlayer():GetPos())

                if ply:Alive() then
                draw.SimpleText(ply:Nick(), "DermaDefault", posScreen.x, posScreen.y, Color(namecolor.r, namecolor.g, namecolor.b), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
                else 
                draw.SimpleText("DEAD", "bigg", posScreen.x, posScreen.y, Color(255, 0, 0), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
                end
            end
            end
        end
    end
end)

hook.Add("HUDPaint", "ESP", function()
if vars.box then
    for _, v in ipairs(player.GetAll()) do
        if v != LocalPlayer() and v:Alive() and v:Team() == TEAM_SPECTATOR == false then
            local min, max = v:OBBMins(), v:OBBMaxs()
            local pos = v:GetPos():ToScreen()

           
            local corners = {
                v:LocalToWorld(Vector(min.x, min.y, min.z)):ToScreen(),
                v:LocalToWorld(Vector(min.x, max.y, min.z)):ToScreen(),
                v:LocalToWorld(Vector(max.x, max.y, min.z)):ToScreen(),
                v:LocalToWorld(Vector(max.x, min.y, min.z)):ToScreen(),
                v:LocalToWorld(Vector(min.x, min.y, max.z)):ToScreen(),
                v:LocalToWorld(Vector(min.x, max.y, max.z)):ToScreen(),
                v:LocalToWorld(Vector(max.x, max.y, max.z)):ToScreen(),
                v:LocalToWorld(Vector(max.x, min.y, max.z)):ToScreen()
            }

           
            local minScreen = Vector(math.huge, math.huge)
            local maxScreen = Vector(-math.huge, -math.huge)
            for _, corner in ipairs(corners) do
                minScreen.x = math.min(minScreen.x, corner.x)
                minScreen.y = math.min(minScreen.y, corner.y)
                maxScreen.x = math.max(maxScreen.x, corner.x)
                maxScreen.y = math.max(maxScreen.y, corner.y)
            end

            
            local w = math.abs(maxScreen.x - minScreen.x)
            local h = math.abs(maxScreen.y - minScreen.y)
            local health = v:Health()
            local maxHealth = v:GetMaxHealth()

            
            surface.SetDrawColor(boxcolor.r, boxcolor.g, boxcolor.b)
            surface.DrawOutlinedRect(minScreen.x, minScreen.y, w, h)
            

            
         
            end
        end
    end
end)


--- in fov thing

local FOV = 90

local inFOV = false


local function IsInFOV(viewer, target)
    local viewerpos = viewer:GetPos()
    local targetpos = target:GetPos()
    local direction = (targetpos - viewerpos):GetNormalized()
    local viewerangle = viewer:EyeAngles()
    local angletotarget = direction:Angle()
    local angledifference = math.abs(math.AngleDifference(viewerangle.y, angletotarget.y))

    return angledifference <= (FOV / 2)
end


local function CheckFOV()
    local localPlayer = LocalPlayer()

    if not IsValid(localPlayer) then return end

    inFOV = false

    for _, player in ipairs(player.GetAll()) do
        if player ~= localPlayer and IsValid(player) then
            if IsInFOV(player, localPlayer) then
                inFOV = true
                break
            end
        end
    end
end


hook.Add("Think", "CheckFOVHook", CheckFOV)


local function DrawFOVAlert()
    if inFOV and vars.infovv then
        local text = "You are in the FOV of another player!"
        local textcolor = Color(255, 0, 0, 255)
        local screenwidth = ScrW()
        local screenheight = ScrH()
        local font = "Trebuchet24"

        draw.SimpleText(text, font, screenwidth / 2, screenheight * 0.1, textcolor, TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
        
    end
end

-- Hook the drawing function to the HUDPaint event
hook.Add("HUDPaint", "DrawFOVAlertHook", DrawFOVAlert)



--- eye

hook.Add("PostDrawOpaqueRenderables", "DrawPlayerEyeLines", function()
    local ply = LocalPlayer()
    
    if not IsValid(ply) or not ply:Alive() then return end

    for _, otherPly in ipairs(player.GetAll()) do
        if otherPly == ply then continue end

        if not IsValid(otherPly) or not otherPly:Alive() then continue end

        local eyepos = otherPly:EyePos()
        local eyeangles = otherPly:EyeAngles()
        local endpos = eyepos + eyeangles:Forward() * 2000 
if vars.eyetracer then
        render.SetColorMaterial()
        render.DrawLine(eyepos, endpos, Color(eyetracecolor.r, eyetracecolor.g, eyetracecolor.b), false) 
        end
    end
end)




--- custom sky etc

local mappings = {
    back = {pos = Vector(0,1,0),norm = Vector(0,-1,0)},
    front = {pos = Vector(0,-1,0),norm = Vector(0,1,0)},
    left = {pos = Vector(-1,0,0),norm = Vector(1,0,0)},
    right = {pos = Vector(1,0,0),norm = Vector(-1,0,0)},
    up = {pos = Vector(0,0,1),norm = Vector(0,0,-1)},
    down = {pos = Vector(0,0,-1),norm = Vector(0,0,1)},
}

local precache = {}

local function PrecacheSkybox(name)
    local skybox = {
        back = Material(string.format("skybox/%sbk", name)),
        front = Material(string.format("skybox/%sft", name)),
        left = Material(string.format("skybox/%slf", name)),
        right = Material(string.format("skybox/%srt", name)),
        up = Material(string.format("skybox/%sup", name)),
        down = Material(string.format("skybox/%sdn", name)),
    }
    precache[name] = skybox
end

hook.Add("PostDraw2DSkyBox", "Derama", function()
    local customSkyy = vars.customsky
    if not precache[customSkyy] then
        PrecacheSkybox(customSkyy)
    end

    local sky = precache[customSkyy]

    render.OverrideDepthEnable(true, false)

    cam.Start3D(Vector(0,0,0), EyeAngles())
    for side, mat in pairs(sky) do
        render.SetMaterial(mat)
        render.DrawQuadEasy(
            (mappings[side] and mappings[side].pos or Vector(0,0,1)) * 8146,
            mappings[side] and mappings[side].norm or Vector(0,0,-1),
            16292, 16292,
            Color(255, 255, 255),
            (side == "up" or side == "down") and 0 or 180
        )
    end
    cam.End3D()

    render.OverrideDepthEnable(false, false)
end)


local function asuss()
 for k,v in pairs(game.GetWorld():GetMaterials()) do
 if vars.asus then
    Material(v):SetFloat("$alpha", 0.8)
    else
    Material(v):SetFloat("$alpha", 1)   
 end
end
end

hook.Add("RenderScreenspaceEffects", "Asusss", asuss)


--- miscerinos

local function fov()
  if vars.fov then
    local ta = {}
    ta.fov = 120
    return ta
  end
end
hook.Add("CalcView", "fov", fov)

hook.Add( "CalcView", "ThirdPerson", function(ply, pos, angles, fov)
	local ThirdPerson = {}
	local CustomFOV = {}
	if vars.thirdperson then
		ThirdPerson.origin = pos-( angles:Forward()*100 )
		ThirdPerson.angles = angles
		ThirdPerson.fov = fov
		ThirdPerson.drawviewer = true
		return ThirdPerson
	else 
		ThirdPerson.origin = pos-( angles:Forward() )
		ThirdPerson.angles = angles
		ThirdPerson.fov = fov
	end
end)



local function Bhop() 

    if input.IsKeyDown( KEY_SPACE ) and ply:IsOnGround() and ply:IsTyping() == false and vars.bhop then
      RunConsoleCommand("+jump") 
      else
      RunConsoleCommand("-jump") 
    end
end

timer.Create( "Bhopper", 0, 0.01, Bhop)


local function Info()
if vars.info then
draw.RoundedBox(2, 10, 10, 230, 20, Color(170,170,170))
draw.RoundedBox(2, 65, 10, 1, 20, Color(20,20,255))
draw.RoundedBox(2, 140, 10, 1, 20, Color(20,20,255))
draw.SimpleText("SoftZ", "Font", 23, 12, Color(40,40,255))
draw.SimpleText( (os.date("%H:%M:%S")), "Font", 70, 12, Color(40,40,255))
draw.SimpleText("Tickrate: " .. math.Round(1 / engine.TickInterval()), "Font", 150, 12, Color(40,40,255))
end
end
hook.Add("HUDPaint", "name", Info)

--- says

deathmessages = {}
deathmessages[1] = "Godmode"
deathmessages[2] = "Cheater"
deathmessages[3] = "help im getting ddosed"
deathmessages[4] = "bro my ping"
deathmessages[5] = "i saw your aimbot buddy"
deathmessages[6] = "RDM"
deathmessages[7] = "my mouse is NOT working"



local wasalive = true

local function CheckPlayerDeath()
    local ply = LocalPlayer()
    
    if not IsValid(ply) or ply:InVehicle() then return end
    
    if wasalive and not ply:Alive() and vars.deathsay then
        ply:ConCommand("say " ..table.Random(deathmessages).." " )
        wasalive = false
    elseif not wasalive and ply:Alive() then
        wasalive = true
    end
end


hook.Add("Think", "playerdeathsayer", CheckPlayerDeath)


gameevent.Listen("entity_killed")
hook.Add("entity_killed", "", function(data)
 local att_index = data.entindex_attacker;
 local vic_index = data.entindex_killed;
 local memes = { "lol", "owned", "watch out for my props!", "i thought you were stronger", ":skull:"}
 if vars.killsay and (vic_index != att_index && att_index == ply:EntIndex()) then
 RunConsoleCommand("say", memes[ math.random( #memes ) ] )
end
end)


--- etc


RunConsoleCommand("cl_updaterate", 1000)
RunConsoleCommand("cl_cmdrate", 0)
RunConsoleCommand("cl_interp", 0)
RunConsoleCommand("rate", 51200)

hook.Remove("PostDraw2DSkyBox", "removeSkybox") hook.Remove("PreDrawSkyBox", "removeSkybox")



