--leaked by vex



/*
	bBot : redundant code, a fair bit is pasta
*/

surface.CreateFont("New Font", {font = "Impact", size = 45})
surface.CreateFont("Menu Font", {font = "Verdana", size = 15})
surface.CreateFont("wireless gamer", {font = "Open Sans MS", size = 45})
surface.CreateFont("Menu Font", {font = "Open Sans MS", size = 15, weight = 500, outline = false})
surface.CreateFont("crosshair", {font = "Roboto", size = 50, weight = 0, outline = 1})

-- locals

local util = util;
local player = player;
local input = input;
local bit = bit;
local hook = hook;
local me = LocalPlayer();
local aimtarget;
local KEY_LALT = KEY_LALT;
local MASK_SHOT = MASK_SHOT;
local Angle = Angle;
local pcall = pcall;
local require = require;
local print = print;
local Vector = Vector;
local math = math;
local fa;
local me = LocalPlayer();
local em = FindMetaTable"Entity";
local pm = FindMetaTable"Player";
local cm = FindMetaTable"CUserCmd";
local wm = FindMetaTable"Weapon";
local am = FindMetaTable"Angle";
local vm = FindMetaTable"Vector";
local fa = em.EyeAngles(me);

----------




-- Fix Movement

local function FixMovement(ucmd, aa)
        local side = Vector(cm.GetForwardMove(ucmd), cm.GetSideMove(ucmd), 0)        		
		local side = am.Forward((vm.Angle(vm.GetNormal(side)) + (cm.GetViewAngles(ucmd) - Angle(0, fa.y, 0)))) * vm.Length(side)
        
		if aa then  	   
			ucmd.SetForwardMove(ucmd, side.x)  	   
			ucmd.SetSideMove(ucmd, side.y * -1)  	   
			return  	   
		end   	   
		
		cm.SetForwardMove(ucmd, side.x)
        cm.SetSideMove(ucmd, side.y)
end

----------

local Switch = false




Antiaims = {  	   
	{"1", "Static Up"},  	   
	{"2", "Static Down"},  	   
	{"3", "Static Up/Down Change"},  	   
	{"4", "Sideway Follow Right Up"},  	   
	{"5", "Sideway Follow Right Down"},  	   
	{"6", "Sideway Follow Right Up/Down Change"},  	   
	{"7", "Sideway Follow Left Up"},  	   
	{"8", "Sideway Follow Left Down"},  	   
	{"9", "Sideway Follow Left Up/Down Change"},  	   
	{"10", "Jitter Up"},  	   
	{"11", "Jitter Down"},  	   
	{"12", "Jitter Up/Down Change"},  	   
	{"13", "Random Angles 1"},  	   
	{"14", "Random Angles 2"},  	   
	{"15", "Jitter Up Random Fake Angles"},  	   
	{"16", "Jitter Down Random Fake Angles"},  	   
}  	 

-----------

-- Spinbot


function pinbot(ucmd)  	   
	if GetConVarNumber("Ben_hvh_Spinbot") != 1 or VTE or input.IsMouseDown(107) or input.IsKeyDown(15) then   	   
		return   	   
	end  	   
	local amount = GetConVarNumber("Ben_hvh_Spinbot_Speed")  	   
	ucmd.SetViewAngles(ucmd, ucmd.GetViewAngles(ucmd) + Angle(0, amount, 0))  	   
	FixMovement(ucmd)  	   
end 

----------
VTE = false 
AA = false  	
local toggle     
local change  	   
  	   
function Antiaim(ucmd)     
	if GetConVarNumber("Ben_hvh_aa") != 1 or VTE or input.IsMouseDown(107) or input.IsKeyDown(15) or !LocalPlayer():Alive() then return end  	
		AA = true  	   
		local method = GetConVarNumber("Ben_hvh_aa_method")  	   
		if method == 1 then  	   
			ucmd.SetViewAngles(ucmd, Angle(181, fa.y, 0))  	   
			ucmd.SetForwardMove(ucmd, ucmd.GetForwardMove(ucmd) * -1)  	   
		elseif method == 2 then  	   
			ucmd.SetViewAngles(ucmd, Angle(-181, fa.y, 0))  	   
			ucmd.SetForwardMove(ucmd, ucmd.GetForwardMove(ucmd) * -1)  	   
		elseif method == 3 then  	   
			local ang = change and -181 or 181  	   
			change = not change  	   
			ucmd.SetViewAngles(ucmd, Angle(ang, fa.y, 0))  	   
			ucmd.SetForwardMove(ucmd, ucmd.GetForwardMove(ucmd) * -1)  	   
		elseif method == 4 then  	   
			ucmd.SetViewAngles(ucmd, Angle(181, fa.y - 90, 0))  	   
			FixMovement(ucmd, true)  	   
		elseif method == 5 then  	   
			ucmd.SetViewAngles(ucmd, Angle(-181, fa.y - 90, 0))  	   
			FixMovement(ucmd, true)  	   
		elseif method == 6 then  	   
			local ang = change and -181 or 181  	   
			change = not change  	   
			ucmd.SetViewAngles(ucmd, Angle(ang, fa.y - 90, 0))  	   
			FixMovement(ucmd, true)  	   
		elseif method == 7 then  	   
			ucmd.SetViewAngles(ucmd, Angle(181, fa.y + 90, 0))  	   
			FixMovement(ucmd, true)  	   
		elseif method == 8 then  	   
			ucmd.SetViewAngles(ucmd, Angle(-181, fa.y + 90, 0))  	   
			FixMovement(ucmd, true)  	   
		elseif method == 9 then  	   
			local ang = change and -181 or 181  	   
			change = not change  	   
			ucmd.SetViewAngles(ucmd, Angle(ang, fa.y + 90, 0))  	   
			FixMovement(ucmd, true)  	   
		elseif method == 10 then  	   
			ucmd.SetViewAngles(ucmd, Angle(181, math.random(-180,180), 0))  	   
			FixMovement(ucmd, true)  	   
		elseif method == 11 then  	   
			ucmd.SetViewAngles(ucmd, Angle(-181, math.random(-180,180), 0))  	   
			FixMovement(ucmd, true)  	   
		elseif method == 12 then  	   
			local ang = change and 181 or -181  	   
			change = not change  	   
			ucmd.SetViewAngles(ucmd, Angle(ang, math.random(-180,180), 0))  	   
			FixMovement(ucmd, true)  	   
		elseif method == 13 then  	   
			local rand1 = math.random(1,2)  	   
			local rand2 = math.random(1,2)  	   
			local ang = rand1 == 1 and 90 or 0  	   
			local ang2 = rand2 == 1 and 181 or -181  	   
			ucmd.SetViewAngles(ucmd, Angle(ang2, ang, 0))  	   
			FixMovement(ucmd, true)  	   
		elseif method == 14 then  	   
			local rand1 = math.random(1,5)  	   
			local rand2 = math.random(1,2)  	   
			local ang = rand1 == 1 and 90 or rand2 == 2 and 180 or rand3 == 3 and 270 or rand1 == 4 and 45 or 360  	   
			local ang2 = rand2 == 1 and 181 or -181  	   
			ucmd.SetViewAngles(ucmd, Angle(ang2, ang, 0))  	   
			FixMovement(ucmd, true)  	   
		elseif method == 15 then  	   
			ucmd.SetViewAngles(ucmd, Angle(math.random(181, 270), math.random(-180,180), 0))  	   
			FixMovement(ucmd, true)  	   
		elseif method == 16 then  	   
			ucmd.SetViewAngles(ucmd, Angle(math.random(-270, -181), math.random(-180,180), 0))  	   
			FixMovement(ucmd, true)  	  
		end
	end
  	   
  	   
----------

/* curtime */

local servertime = 0;

hook.Add("Move", "", function()
	if(!IsFirstTimePredicted()) then return; end
	servertime = CurTime() + engine.TickInterval();
end);

local badSequences = {
    [ACT_VM_DEPLOY] = true;
    [ACT_VM_DEPLOY_1] = true;
    [ACT_VM_DEPLOY_2] = true;
    [ACT_VM_DEPLOY_3] = true;
    [ACT_VM_DEPLOY_4] = true;
    [ACT_VM_DEPLOY_5] = true;
    [ACT_VM_DEPLOY_6] = true;
    [ACT_VM_DEPLOY_7] = true;
    [ACT_VM_DEPLOY_8] = true;
    [ACT_VM_DEPLOY_EMPTY] = true;
    [ACT_VM_ATTACH_SILENCER] = true;
    [ACT_VM_DETACH_SILENCER] = true;
    [ACT_VM_DRAW] = true;
    [ACT_VM_DRAW_DEPLOYED] = true;
    [ACT_VM_DRAW_EMPTY] = true;
    [ACT_VM_DRAW_SILENCED] = true;
    [ACT_VM_RELOAD] = true;
    [ACT_VM_RELOAD_DEPLOYED] = true;
    [ACT_VM_RELOAD_EMPTY] = true;
}

local function canFire()
    local wep = me:GetActiveWeapon();
    if(!wep || !wep:IsValid()) then
        return false;
    end
    local sequence = wep:GetSequence();
    if(badSequences[sequence]) then return false; end
    if(wep:GetNextPrimaryFire() <= servertime) then
        return true;
    end
    return false;
end


------------

-- Requires

hook.Add("PostDraw2DSkyBox", "", function()
if GetConVarNumber("Ben_Visuals_Nosky") == 1 then
	render.Clear(0, 0, 0, 0, true, true);
	end
end);


/* extra */

local Entity = Entity;
local spam_text = "memed"
gameevent.Listen("entity_killed");

hook.Add("entity_killed", "", function(data)
if GetConVarNumber("Ben_Misc_Chatspam") == 1 then
	local att_index = data.entindex_attacker;
	local vic_index = data.entindex_killed;

	if(vic_index != att_index && att_index == me:EntIndex()) then
		RunConsoleCommand("say", spam_text);
	end
	end
end);

require("cvar3")
require("enginepred");
require("dickwrap")



local mat = CreateMaterial("", "VertexLitGeneric", {
        ["$basetexture"] = "models/debug/debugwhite",
        ["$model"] = 1,
        ["$ignorez"] = 1,
});
 
local mat2 = CreateMaterial(" ", "VertexLitGeneric", {
        ["$basetexture"] = "models/debug/debugwhite",
        ["$model"] = 1,
        ["$ignorez"] = 0,
}); 

local mat3 = CreateMaterial("", "VertexLitGeneric", {
        ["$basetexture"] = "models/wireframe",
        ["$model"] = 1,
        ["$ignorez"] = 1,
});
 
local mat4 = CreateMaterial(" ", "VertexLitGeneric", {
        ["$basetexture"] = "models/wireframe",
        ["$model"] = 1,
        ["$ignorez"] = 0,
});
 
function GAMEMODE:RenderScreenspaceEffects()
        if GetConVarNumber("Ben_Visuals_Enabled") == 1 then
		if GetConVarNumber("Ben_Visuals_Chams") == 1 then
        local allplys = player.GetAll();
        for i = 1, #allplys do
                local v = allplys[i];
                if (!v || !em.IsValid(v) || v == me || em.Health(v) < 1 || pm.Team(v) == 1002) then continue; end
                local col = Color(0,255,0);
                cam.Start3D();
				if GetConVarNumber("Ben_Visuals_Chams_type") == 1 then
                        render.MaterialOverride(mat);
				end
				if GetConVarNumber("Ben_Visuals_Chams_type") == 2 then
                        render.MaterialOverride(mat3);
				end
                        render.SetColorModulation(col.b / 255, col.r / 255, col.g / 255);
                        em.DrawModel(v);
				if GetConVarNumber("Ben_Visuals_Chams_type") == 1 then		
                        render.MaterialOverride(mat2);
				end	
				if GetConVarNumber("Ben_Visuals_Chams_type") == 2 then
						render.MaterialOverride(mat4);
				end
                        render.SetColorModulation(col.r / 255, col.g / 255, col.b / 255);
                        em.DrawModel(v);
                        render.SetColorModulation(1, 1, 1);
                cam.End3D();
			end
		end
	end
end


local wireframeMat = Material("models/wireframe");

hook.Add("PreDrawViewModel", "", function()
    if GetConVarNumber("Ben_Visuals_Wireframe_Viewmodel") == 1 then  
	
    render.MaterialOverride(wireframeMat);
    render.SetColorModulation(1,1,1); 
	end
end);

function CalcViewModelView(_, _, opos, _, pos, a)  	   
	local pt, at  	   
	if GetConVarNumber("Ben_hvh_Spinbot") == 1 or GetConVarNumber("Ben_hvh_aa") == 1 then  	   
		pt = opos  	   
		at = oa  	   
	else  	   
		pt = pos  	   
		at = a  	   
	end  	   
	return pt, at  	   
end  	   
  	   
hook.Add("CalcViewModelView", "CalcViewModelView", CalcViewModelView)  	

function GAMEMODE:CalcView(p, o, a, f)  	   
	local view = {} 
	view.angles = toggle and Angle(fa.x, fa.y - 180, 0) or fa	
	view.fov = GetConVarNumber("Ben_Misc_Fov");
	view.origin = GetConVarNumber("Ben_Visuals_Thirdperson") == 1 && o + am.Forward(fa) * -150 || origin;
	vm_angles = fa  	   
	vm_origin = origin  
	return view;  	   
end  

function GAMEMODE:ShouldDrawLocalPlayer()  	   
	return(GetConVarNumber("Ben_Visuals_Thirdperson") == 1);  	   
end  

-- No Visual Recoil

hook.Add( "CalcView", "No Visual Recoil", function( ply, pos, angles, fov )

	if GetConVarNumber("Ben_Misc_Norecoil") == 1 then
		if (LocalPlayer():Health() > 0 && LocalPlayer():Team() != TEAM_SPECTATOR && LocalPlayer():Alive()) then
			return GAMEMODE:CalcView( ply, LocalPlayer():EyePos(), LocalPlayer():EyeAngles(), fov, 0.1 );
		end
	end
	
end )




-- Aimbot

CreateClientConVar("Ben_Aimbot_Enabled", 0, true, false)
CreateClientConVar("Ben_Aimbot_Silent", 0, true, false)
CreateClientConVar("Ben_Aimbot_AutoFire", 0, true, false)
CreateClientConVar("Ben_Aimbot_Ignoreteam", 0, true, false)
CreateClientConVar("Ben_Aimbot_IgnoreSpawnProtection", 0, true, false)
CreateClientConVar("Ben_Aimbot_Prediction", 0, true, false)

-- Visuals

CreateClientConVar("Ben_Visuals_Enabled", 0, true, false)
CreateClientConVar("Ben_Visuals_Name", 0, true, false)
CreateClientConVar("Ben_Visuals_Box", 0, true, false)
CreateClientConVar("Ben_Visuals_Box_Type", 0, true, false)
CreateClientConVar("Ben_Visuals_Weapon", 0, true, false)
CreateClientConVar("Ben_Visuals_Rank", 0, true, false)
CreateClientConVar("Ben_Visuals_Health", 0, true, false)
CreateClientConVar("Ben_Visuals_Health_Type", 0, true, false)
CreateClientConVar("Ben_Visuals_hands", 0, true, false)
CreateClientConVar("Ben_Visuals_Hands_Type", 0, true, false)
CreateClientConVar("Ben_Visuals_Wireframe_Viewmodel", 0, true, false)
CreateClientConVar("Ben_Visuals_Thirdperson", 0, true, false)
CreateClientConVar("Ben_Visuals_Chams", 0, true, false)
CreateClientConVar("Ben_Visuals_Chams_type", 0, true, false)
CreateClientConVar("Ben_Visuals_Nosky", 0, true, false)
CreateClientConVar("Ben_Visuals_Hitmarker", 0, true, false)

-- Misc

CreateClientConVar("Ben_Misc_Enabled", 0, true, false)
CreateClientConVar("Ben_Misc_Crosshair", 0, true, false)
CreateClientConVar("Ben_Misc_Crosshair_type", 0, true, false)
CreateClientConVar("Ben_Misc_Crosshair_Box", 0, true, false)
CreateClientConVar("Ben_Misc_Bunnyhop", 0, true, false)
CreateClientConVar("Ben_Misc_Autostrafe", 0, true, false)
CreateClientConVar("Ben_Misc_Chatspam", 0, true, false)
CreateClientConVar("Ben_Misc_Spamtext", 0, true, false)
CreateClientConVar("Ben_Misc_Norecoil", 0, true, false)
CreateClientConVar("Ben_Misc_Autopistol", 0, true, false)
CreateClientConVar("Ben_Misc_Fov", 0, true, false)

CreateClientConVar("Ben_Misc_menu_r", 0, true, false)
CreateClientConVar("Ben_Misc_menu_g", 0, true, false)
CreateClientConVar("Ben_Misc_menu_b", 0, true, false)


-- hvh

CreateClientConVar("Ben_hvh_enable", 0, true, false)
CreateClientConVar("Ben_hvh_aa", 0, true, false)
CreateClientConVar("Ben_hvh_fakelag", 0, true, false)
CreateClientConVar("Ben_hvh_fakelag_factor", 0, true, false)
CreateClientConVar("Ben_hvh_aa_method", 0, true, false)
CreateClientConVar("Ben_hvh_aaa", 0, true, false)
CreateClientConVar("Ben_hvh_aaa_method", 0, true, false)
CreateClientConVar("Ben_hvh_Spinbot", 0, true, false)
CreateClientConVar("Ben_hvh_Spinbot_Speed", 0, true, false)
----------------------------------------------------------------------------------------------

-- Fake Lag

local Queue = 0

function FakeLag(ucmd)
	if GetConVarNumber("Ben_hvh_enable") == 1 then
	if GetConVarNumber("Ben_hvh_fakelag") == 1 then
							
			Queue = Queue + 1

			if Queue >= 0 then
			if Queue < GetConVarNumber("Ben_hvh_fakelag_factor") then
				bSendPacket = false
			else
				bSendPacket = true
			end
			else
				bSendPacket = true
			end
		
			if Queue >= GetConVarNumber("Ben_hvh_fakelag_factor") then
				Queue = 0
			end
		end
	end
end



local vmchamsmat1 = CreateMaterial("ViewModel_1", "VertexLitGeneric", {
	["$basetexture"] = "models/debug/debugwhite",
	["$model"] = 1,
	["$ignorez"] = 0,
	["vertexcolor"] = 1,
	["$color2"] = "{46 234 236}"
});

local vmchamsmat2 = CreateMaterial("ViewModel_2", "VertexLitGeneric", {
	["$basetexture"] = "models/debug/debugwhite",
	["$model"] = 1,
	["$ignorez"] = 1,
	["vertexcolor"] = 1,
	["$color2"] = "{255 0 0}"
});

local chamsmat = CreateMaterial("chamsmat", "VertexLitGeneric", {
	["$ignorez"] = 0,
	["$model"] = 1,
	["$basetexture"] = "models/debug/debugwhite",
});


-- Rapid Fire

local me = LocalPlayer();

local function RapidFire(ucmd)
if GetConVarNumber("Ben_Misc_Autopistol") == 1 then   
    if (me:KeyDown(1)) then
        ucmd:RemoveKey(1);
		end
	end
end

-------------

local pitcharray = {};

/* AAA */
local function DoAAA()
if(GetConVarNumber("Ben_hvh_aaa") == 1)then
	for k,v in next, player.GetAll() do
			if(v == me) then continue; end
			local correctedpitch = v:EyeAngles().x;
			local correctedyaw = v:EyeAngles().y;

			if(GetConVarNumber("Ben_hvh_aaa_method") == 1) then //auto
				if(correctedpitch >= 89 && correctedpitch < 180) then
					correctedpitch = 89;
				elseif(correctedpitch >= 180 && correctedpitch < 290) then
					correctedpitch = -89;
				end
			elseif(GetConVarNumber("Ben_hvh_aaa_method") == 2) then //down
				correctedpitch = 89;
			elseif(GetConVarNumber("Ben_hvh_aaa_method") == 3) then // up
				correctedpitch = -89;
			end

			if(GetConVarNumber("Ben_hvh_aaa_method") == 1) then //auto
			elseif(GetConVarNumber("Ben_hvh_aaa_method") == 2)then
				correctedyaw = correctedyaw - 90;
			elseif(GetConVarNumber("Ben_hvh_aaa_method") == 3) then
				correctedyaw = correctedyaw + 90;
			else
				correctedyaw = correctedyaw - 180;
			end

			pitcharray[v:EntIndex()] = correctedpitch;

			--v:SetPoseParameter("aim_pitch", correctedpitch);
			--v:SetPoseParameter("body_yaw", 0);
			--v:SetPoseParameter("aim_yaw", 0);
			v:InvalidateBoneCache();
			v:SetRenderAngles(Angle(0, math.NormalizeAngle(correctedyaw), 0));
			end
		end
end



hook.Add("RenderScene", "", function()
	DoAAA();
end);

--------------

-- Aimbot

-- No Spread

local ofb = em.FireBullets;
 
local cones = {};
local nullvec = Vector() * -1;
 
function em.FireBullets(p, data)
        local spread = data.Spread * -1;
        local class = p:GetActiveWeapon():GetClass();
        if (spread != cones[class] && spread != nullvec) then
                cones[class] = spread;
        end
        return(ofb(p, data));
end
 
local function PredictSpread(ucmd, ang)
        local w = me:GetActiveWeapon();
        if (!w || !w:IsValid() || !cones[w:GetClass()]) then return ang; end
        local ang = (dickwrap.Predict(ucmd, ang:Forward(), cones[w:GetClass()])):Angle();
        ang.y, ang.x = math.NormalizeAngle(ang.y), math.NormalizeAngle(ang.x);
        return(ang);
end

local function Get_Pos(v)
        local eyes = v:LookupAttachment("eyes");
        return(eyes && v:GetAttachment(eyes).Pos || v:LocalToWorld(v:OBBCenter()));
end


local function _Valid(v)
        if(!v || !v:IsValid() || v:Health() < 1 || v:IsDormant() || v == me) then return false; end
        local trace = {
                mask = MASK_SHOT,
                endpos = GetPos(v),
                start = me:EyePos(),
                filter = {me, v},
        };
        return(util.TraceLine(trace).Fraction == 1);
end

local autowall = CreateClientConVar("autowall", 1);

local trace_walls = bit.bor(CONTENTS_TESTFOGVOLUME, CONTENTS_EMPTY, CONTENTS_MONSTER, CONTENTS_HITBOX);
local NoPenetration = {[MAT_SLOSH] = true};
local PenMod = {[MAT_SAND] = 0.5, [MAT_DIRT] = 0.8, [MAT_METAL] = 1.1, [MAT_TILE] = 0.9, [MAT_WOOD] = 1.2};
local trace_normal = bit.bor(CONTENTS_SOLID, CONTENTS_OPAQUE, CONTENTS_MOVEABLE, CONTENTS_DEBRIS, CONTENTS_MONSTER, CONTENTS_HITBOX, 402653442, CONTENTS_WATER);


local function fasAutowall(wep, startPos, aimPos, ply)
	if(!autowall:GetBool()) then return false; end
    local traces = {};
    local me = me;
    local traceResults = {};
    local dir = (aimPos - startPos):GetNormalized();
    traces[1] = { start = startPos, filter = me, mask = trace_normal, endpos = aimPos, };
    traceResults[1] = util.TraceLine(traces[1]);
    if(NoPenetration[traceResults[1].MatType]) then return false; end
    if((-dir):DotProduct(traceResults[1].HitNormal) <= .26) then return false; end
    traces[2] = { start = traceResults[1].HitPos, endpos = traceResults[1].HitPos + dir * wep.PenStr * (PenMod[traceResults[1].MatType] || 1) * wep.PenMod, filter = me, mask = trace_walls, };
    traceResults[2] = util.TraceLine(traces[2]);
    traces[3] = { start = traceResults[2].HitPos, endpos = traceResults[2].HitPos + dir * .1, filter = me, mask = trace_normal, };
    traceResults [3] = util.TraceLine(traces[3]);
    traces[4] = { start = traceResults[2].HitPos, endpos = aimPos, filter = me, mask = MASK_SHOT, };
    traceResults[4] = util.TraceLine(traces[4]);
    if(traceResults[4].Entity != ply) then return false; end
    return(!traceResults[3].Hit);
end

local function IsVisible(ply, pos)
	local trace = {
		start = me:EyePos(),
		endpos = pos,
		filter = {ply, me},
		mask = MASK_SHOT,
	};

	if (util.TraceLine(trace).Fraction == 1 ) then
		return true;
	else
		local wep = me:GetActiveWeapon();
		if(wep && wep:IsValid() && wep.PenStr) then
			return fasAutowall(wep, trace.start, trace.endpos, ply);
		end
	end

	return false;
end

local function _gethitbox(ent)
        if ent:LookupBone(hitbox) then
        local pos = ent:GetBonePosition(ent:GetHitBoxBone(0, 0))
                return pos
        end
        return ent:LocalToWorld(ent:OBBCenter())
end
 

local function Get_Target()
	local dists = {};
	for k,v in next, player.GetAll() do
		if(v == me || v:Health() < 1 || v:IsDormant()) then continue; end
		if((v:Team() == me:Team()) && GetConVarNumber("Ben_Aimbot_Ignoreteam") == 1) then continue; end
		
		if(IsVisible(v, GetPos(v))) then
			local d = v:GetPos():Distance(me:GetPos());
                table.insert(dists, {d, v});
		end
	end

table.sort(dists, function(a, b) return a[1] < b[1] end);
aimtarget = (dists[1] && dists[1][2] || nil);
end

local toggler = 0
local ang;

Penetrations = {  	   
	["pistol"] = 2,  	   
	["357"] = 5,  	   
	["smg1"] = 5,  	   
	["pistol"] = 4,  	   
	["ar2"] = 4,  	   
	["buckshot"] = 4,  	   
	["slam"] = 0,  	   
	["AirboatGun"] = 8,  	   
	["SniperPenetratedRound"] = 20,  	   
}  	   
  	   
function CanPenetrate(w, tr) -- Old Madcows autowall fixed up for m9k  	   
	if !w.Primary then return false end  	   
	local base = w.Base  	   
	if !base or !string.find(base, "bobs_") then return false end  	   
	local max = Penetrations[w.Primary.Ammo]  	   
	if !max then return false end  	   
	local dir = tr.Normal * max  	   
	local rico  	   
	if tr.MatType == 87 then  	   
		dir = tr.Normal * (max * 2)  	   
	end  	   
	if tr.MatType == 77 and w.Ricochet and w.Primary.Ammo != "SniperPenetratedRound" then  	   
		return false  	   
	end  	   
	local trace = {  	   
		endpos = tr.HitPos,  	   
		start = tr.HitPos + dir,  	   
		mask = 1174421507,  	   
		filter = {me},  	   
	}  	   
	local t = util.TraceLine( trace )  	   
	if( t.StartSolid || t.Fraction >= 1.0 || tr.Fraction <= 0.0) then return false end  	   
	return true  	   
end  	   

  	   
function Valid(v)  	   
	if !v then return false end  	   
	if !em.IsValid(v) then return false end  	   
	if v == me then return false end  	   
	if pm.Team(v) == 1002 then return false end  	   
	if em.GetMoveType(v) == 10 then return false end  	   
	if GetConVarNumber("Ben_Aimbot_IgnoreSpawnProtection") == 0 then if em.GetColor(v).a < 150 then return false end end  	   
	if em.Health(v) < 1 then return false end  	   
	if((v:Team() == me:Team()) && GetConVarNumber("Ben_Aimbot_Ignoreteam") == 1) then return false end
	--if GetConVarNumber("Ben_Aimbot_Ignoreteam") == 1 and pm.GetFriendStatus(v) == "friend" then return false end  	   
	if em.IsDormant(v) then return false end  	   
	local pos = em.GetAttachment(v, em.LookupAttachment(v, "eyes"))  	   
	local pos = pos and pos.Pos or em.LocalToWorld(v, em.OBBCenter(v))  	   
	local tr = {}  	   
	tr.endpos = pos  	   
	tr.start = em.EyePos(me)  	   
	tr.mask = 1174421507  	   
	tr.filter = {me, v}  	   
	local trace = util.TraceLine(tr)  	   
	if trace.Fraction != 1 and GetConVarNumber("autowall") == 1 then  	   
		local tr2 = {}  	   
		tr2.endpos = pos  	   
		tr2.start = em.EyePos(me)  	   
		tr2.mask = 1174421507  	   
		return CanPenetrate(pm.GetActiveWeapon(me), util.TraceLine(tr2))  	   
	end  	   
	return trace.Fraction == 1  	   
end  

function GetTarget()  	   
	local allplys = player.GetAll()  	   
	for i = 1, #allplys do  	   
		local v = allplys[i]  	   
		if !Valid(v) then continue end  	   
		Target = v   	   
		return   	   
	end  	   
end  

function GetPos()  	   
	local v = Target  	   
	local pos1 = em.GetAttachment(v, em.LookupAttachment(v, "eyes"))  	   
	local pos1 = pos1 and pos1.Pos or em.LocalToWorld(v, em.OBBCenter(v))  	   
	local pos2 = em.EyePos(me)  	   
	local prediction = GetConVarNumber("Ben_Aimbot_Prediction") == 1 and (em.GetVelocity(v) * .0067) or Vector()  	   
	local pos = pos1 - pos2 + prediction  	   
	return vm.Angle(pos)  	   
end  

local function Aimbot(ucmd)
	
	fa = fa + Angle(ucmd.GetMouseY(ucmd) * .023, ucmd.GetMouseX(ucmd) * -0.023, 0)  	   
	fa.y = math.NormalizeAngle(fa.y)  	   
	fa.p = math.Clamp(fa.p, -89, 89)  	   
	if GetConVarNumber("Ben_Aimbot_Enabled") and GetConVarNumber("Ben_Aimbot_Silent") and Valid(Target) then  	   
		
		VTE = true  	   
		
		local pos = GetPos()  	   
		local pos = PredictSpread(ucmd, pos)  	   
		pos.y = math.NormalizeAngle(pos.y)  	   
		ucmd.SetViewAngles(ucmd, pos)  	   
		if GetConVarNumber("Ben_Aimbot_AutoFire") == 1 then  	   
			ucmd.SetButtons(ucmd, bit.bor(ucmd.GetButtons(ucmd), 1))  	   
		end  	   
		
		FixMovement(ucmd)  	   
		return  	   
	end  	   
	VTE = false  
	if GetConVarNumber("Ben_Aimbot_Prediction") then
		if(!canFire()) then 
			return;
		end
	end
	if !Valid(Target) then  	   
		GetTarget()  	   
	end  	   
	if checkingang then  	   
		FixMovement(ucmd)  	   
		return  	   
	end  	   
	local keydown = input.IsMouseDown(107) or input.IsKeyDown(15)  	   
	local aa = GetConVarNumber("Ben_hvh_aa") == 1 or GetConVarNumber("Ben_hvh_Spinbot") == 1 or false  	   
	if aa and !keydown then return end  
			
end
	


     
-- No Hands

local pm = FindMetaTable("Player");


local ogethands = pm.GetHands; -- Note: Only for c_ viewmodels  	   
  	   

function pm.GetHands(...)
	if (GetConVarNumber("Ben_Visuals_hands") == 0 or GetConVarNumber("Ben_Visuals_hands") == 1) and GetConVarNumber("Ben_Visuals_Hands_Type") == 0 then
    
		return(ogethands(...));

	
	end
end 

hook.Add("PostDrawViewModel", "", function(vm)
	render.SetLightingMode(0);
	for k,v in next, vm:GetMaterials() do
		render.MaterialOverrideByIndex(k - 1, nil);
	end
end);

-- ESP

local function _IsValid(v)
	return (v != LocalPlayer() && IsValid(v) && v:Alive() && v:Health() > 0 && !v:IsDormant());
end

local function Get2DBounds(v)
	local min,max = v:OBBMins(),v:OBBMaxs()

	local corners = {
		Vector(min.x,min.y,min.z),
		Vector(min.x,min.y,max.z),
		Vector(min.x,max.y,min.z),
		Vector(min.x,max.y,max.z),
		Vector(max.x,min.y,min.z),
		Vector(max.x,min.y,max.z),
		Vector(max.x,max.y,min.z),
		Vector(max.x,max.y,max.z)
	}

	local minx,miny,maxx,maxy = math.huge, math.huge, -math.huge, -math.huge;

	for _, corner in next, corners do
		local screen = v:LocalToWorld(corner):ToScreen();
		minx,miny = math.min(minx,screen.x),math.min(miny,screen.y);
		maxx,maxy = math.max(maxx,screen.x),math.max(maxy,screen.y);
	end
	return minx,miny,maxx,maxy;
end

local function FamiHealthbar()
	for k,v in next, player.GetAll() do
		if (_IsValid(v)) then
		if GetConVarNumber("Ben_Visuals_Enabled") == 1 then
		
		
			local x1,y1,x2,y2 = Get2DBounds(v);
			local color = Color(255,255,255);
			local diff = math.abs(x2 - x1);
			local diff2 = math.abs(y2 - y1);
			
			/*
			BOX
			*/
			if GetConVarNumber("Ben_Visuals_Box") == 1 and GetConVarNumber("Ben_Visuals_Box_Type") == 2 then
				surface.SetDrawColor(100,100,100)
				surface.DrawOutlinedRect(x1-1,y1-1,diff+2,diff2+2)
				surface.DrawOutlinedRect(x1+1,y1+1,diff-2,diff2-2)
				surface.SetDrawColor(color)
				surface.DrawOutlinedRect(x1,y1,diff,diff2)
			end
			
			/*
			HEALTHBAR
			*/
			if GetConVarNumber("Ben_Visuals_Health_Type") == 1 then
				surface.SetDrawColor(color)
				surface.DrawRect(x1-5, y1,3,diff2-2)
				surface.SetDrawColor(5,5,5)
				surface.DrawLine(x1-4, y1+1,x1-4,y2-1)
				surface.SetDrawColor(255 - 2.55 * v:Health(), 2.55 * v:Health(),0)
				surface.DrawRect(x1-5, y2-(diff2/100 * v:Health()),3,diff2/100*(v:Health()))
				surface.SetDrawColor(5,5,5)
				surface.DrawOutlinedRect(x1-6, y1-1,5,diff2+2)
			end
		end
		end
	end
end

GAMEMODE["HUDPaint"] = function()
	FamiHealthbar()
	Crosshair()
	Hitmarker()
	Visuals()
	
end

local me = LocalPlayer()
function Visuals()

	er = math.sin(CurTime() * 4) * 127 + 128
	eg = math.sin(CurTime() * 4 + 2) * 127 + 128
	eb = math.sin(CurTime() * 4 + 4) * 127 + 128
	
	draw.SimpleText("[ bBot ]", "New Font", 4, 40, Color(255, 255, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_BOTTOM)
	if GetConVarNumber("Ben_Visuals_Enabled") == 1 then
	for k,v in next, player.GetAll() do
		if  !v:IsValid() or !v:IsPlayer() or !v:Alive() or 0 >= v:Health() then continue end
		if  v == me then continue end
		local min, max = v:GetCollisionBounds()
		local pos = v:GetPos()
		local top, bottom = (pos + Vector(0, 0, max.z)):ToScreen(), (pos - Vector(0, 0, 8)):ToScreen()
		local middle = bottom.y - top.y
		local width = middle / 2.425

		if GetConVarNumber("Ben_Visuals_Name") == 1 then
			draw.SimpleText(v:Nick(), "Menu Font", bottom.x, top.y, Color(255, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_BOTTOM)
		end

		if GetConVarNumber("Ben_Visuals_Box") == 1 and GetConVarNumber("Ben_Visuals_Box_Type") == 1 then
			
				surface.SetDrawColor(me:Team() == v:Team() and Color(0, 100, 255) or Color(200, 30, 30))
				surface.DrawOutlinedRect(bottom.x - width, top.y, width * 2, middle)
				surface.SetDrawColor(Color(0, 0, 0))
				surface.DrawOutlinedRect(bottom.x - width - 1, top.y - 1, width * 2 + 2, middle + 2)
				surface.DrawOutlinedRect(bottom.x - width + 1, top.y + 1, width * 2 - 2, middle - 2)
			
		end

		drawpos = 0

		if GetConVarNumber("Ben_Visuals_Weapon") == 1 then
			local wep = v:GetActiveWeapon()
			if wep and wep != NULL then
				draw.SimpleText(wep.GetPrintName and wep:GetPrintName() or wep:GetClass(), "Menu Font", bottom.x, bottom.y + drawpos, Color(255, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
				drawpos = drawpos + 10
			end
		end

		if GetConVarNumber("Ben_Visuals_Rank") == 1 then
			draw.SimpleText(v.GetUserGroup and v:GetUserGroup() or "__norank", "Menu Font", bottom.x, bottom.y + drawpos, Color(255, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
			drawpos = drawpos + 10
		end

		if GetConVarNumber("Ben_Visuals_Health") == 1 then
		if GetConVarNumber("Ben_Visuals_Health_Type") == 2 then
			local health = math.Clamp(v:Health(), 0, 100)
			local green = health * 2.55
			local red = 255 - green
			surface.SetDrawColor(Color(0, 0, 0))
			surface.DrawRect(bottom.x + width + 2, top.y - 1, 4, middle + 2)
			surface.SetDrawColor(Color(red, green, 0))
			local height = health * middle / 100
			surface.DrawRect(bottom.x + width + 3, top.y + (middle - height), 2, height)
		end
		
		end
	end
	end
end


function Hitmarker()
if GetConVarNumber("Ben_Visuals_Hitmarker") then
if LocalPlayer():Alive() then
	local MYEYES = LocalPlayer():GetEyeTrace().Entity
	local me = LocalPlayer()
	if MYEYES:IsPlayer() then
		if me:Health() > 0 then
			if me:KeyDown(IN_ATTACK) then
				

						surface.SetDrawColor( 255 , 255 , 255 , 255 )
						surface.DrawLine(ScrW() / 2 - 5 , ScrH() / 2 - 5 , ScrW() / 2 - 15 , ScrH() / 2 - 15)
						surface.DrawLine(ScrW() / 2 + 5 , ScrH() / 2 + 5 , ScrW() / 2 + 15, ScrH() / 2 + 15)
						surface.DrawLine(ScrW() / 2 + 5 , ScrH() / 2 - 5 , ScrW() / 2 + 15 , ScrH() / 2 - 15)
						surface.DrawLine(ScrW() / 2 - 5 , ScrH() / 2 + 5 , ScrW() / 2 - 15 , ScrH() / 2 + 15)
					
					
				end
			end
		end
	end
	end
end



-- Crosshair code -- 

	function Crosshair()

	if GetConVarNumber("Ben_Misc_Enabled") == 1 then
	if GetConVarNumber("Ben_Misc_Crosshair_type") == 1 then
	// Crosshair
	local x = ScrW() / 2
	local y = ScrH() / 2
	
	local crosscolor = Color( 0, 0, 0, 255 )
	local crosslength = 30
	local gap = 2
	
	local boxsize = 5
		
	-- Box
	if GetConVarNumber("Ben_Misc_Crosshair_Box") == 1 then
		surface.SetDrawColor( Color( 255, 0, 0 ) )
		surface.DrawOutlinedRect( x - boxsize - 2, y - boxsize - 2, ( boxsize + 2 ) * 2 + 1, ( boxsize + 2 ) * 2 + 1 )
	end
	
	-- Crosshair
	if GetConVarNumber("Ben_Misc_Crosshair") == 1 then
	
		surface.SetDrawColor( 0, 0, 0, 255 )
		surface.DrawLine( x - crosslength, y, x - gap, y )
		surface.DrawLine( x + crosslength, y, x + gap, y )
		
		surface.DrawLine( x, y - crosslength, x, y - gap )
		surface.DrawLine( x, y + crosslength, x, y + gap )
	end
	end
	end
	end
	
	
local function HideThings( name )
if GetConVarNumber("Ben_Misc_Enabled") == 1 then
	if GetConVarNumber("Ben_Misc_Crosshair") == 1 or GetConVarNumber("Ben_Misc_Crosshair_type") == 0 then
	if(name == "CHudCrosshair") then
             return false
        end
        -- We don't return anything here otherwise it will overwrite all other 
        -- HUDShouldDraw hooks.
		end
	end
end

hook.Add( "HUDShouldDraw", "HideThings", HideThings )	
	
hook.Add("HUDPaint", "Crosshair", function()
if GetConVarNumber("Ben_Misc_Enabled") == 1 then
	if GetConVarNumber("Ben_Misc_Crosshair") == 1 then
	if GetConVarNumber("Ben_Misc_Crosshair_type") == 2 then
		local col1 = Color(255,0,0)
		local col2 = Color(255,255,255)
		draw.SimpleTextOutlined("+", "crosshair", ScrW() / 2, ScrH() / 2, col1, 1, 1, 2, col2)
		end
	end
	end
end)

local function pBhoop(ucmd)
if GetConVarNumber("Ben_Misc_Enabled") == 1 then
if GetConVarNumber("Ben_Misc_Bunnyhop") == 1 then
	if (!LocalPlayer():IsTyping() && !LocalPlayer():IsOnGround() && LocalPlayer():Alive()) then
		ucmd:RemoveKey(2)
		if GetConVarNumber("Ben_Misc_Autostrafe") == 1 then
		if (ucmd:GetMouseX() < 0) then
			ucmd:SetSideMove(-31 ^ 2 + 39) // extra memey take that ari
		elseif(ucmd:GetMouseX() > 0) then
			ucmd:SetSideMove(31 ^ 2 + 39)
		end
		end
		end
		end
	end
end


hitbox = "ValveBiped.Bip01_Head1"

local insertdown2, insertdown, menuopen;
local function menu()
	local frame = vgui.Create( "DFrame" )
	frame:SetPos( 5, 5 )
	frame:SetSize( 1000, 500 )
	frame:SetTitle( "" )
	frame:SetVisible( true )
	frame:SetDraggable( true )
	frame:ShowCloseButton( false )
	frame:MakePopup()

	frame.Paint = function( self )
		
		draw.RoundedBox(0, 0, 0, self:GetWide(), self:GetTall(), Color(50, 50, 50))
		draw.RoundedBox(0, 0, 0, self:GetWide(), 25, Color(GetConVarNumber("Ben_Misc_menu_r"),GetConVarNumber("Ben_Misc_menu_g"),GetConVarNumber("Ben_Misc_menu_b")))
		draw.SimpleText("bBot.lua", "Menu Font", self:GetWide() / 2, 12.5, Color(255,255,255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)          
		surface.SetDrawColor(Color(75,75,75))
		
	end

	frame.Think = function()
			if (input.IsKeyDown(KEY_INSERT) && !insertdown2) then
				frame:Remove();
				menuopen = false;				
			end
	end
	
	-- Aimbot Enabled                
	
	local CheckBoxAimbot = vgui.Create( "DCheckBoxLabel", frame )
	CheckBoxAimbot:SetPos( 10,50 )
	CheckBoxAimbot:SetText( "Aimbot Enabled" )
	CheckBoxAimbot:SetConVar( "Ben_Aimbot_Enabled" ) 
	CheckBoxAimbot:SizeToContents()
	
	-- Aimbot Silent              
	
	local CheckBoxAimbot = vgui.Create( "DCheckBoxLabel", frame )
	CheckBoxAimbot:SetPos( 10,80 )
	CheckBoxAimbot:SetText( "Silent" )
	CheckBoxAimbot:SetConVar( "Ben_Aimbot_Silent" ) 
	CheckBoxAimbot:SizeToContents()
	
	-- Aimbot Auto Fire             
	
	local CheckBoxAimbot = vgui.Create( "DCheckBoxLabel", frame )
	CheckBoxAimbot:SetPos( 10,110 )
	CheckBoxAimbot:SetText( "Ignore Team" )
	CheckBoxAimbot:SetConVar( "Ben_Aimbot_Ignoreteam" ) 
	CheckBoxAimbot:SizeToContents()
	
	-- Aimbot Auto Fire             
	
	local CheckBoxAimbot = vgui.Create( "DCheckBoxLabel", frame )
	CheckBoxAimbot:SetPos( 10,140 )
	CheckBoxAimbot:SetText( "AutoFire" )
	CheckBoxAimbot:SetConVar( "Ben_Aimbot_AutoFire" ) 
	CheckBoxAimbot:SizeToContents()
	
	-- Aimbot Auto wall        
	
	local CheckBoxAimbot = vgui.Create( "DCheckBoxLabel", frame )
	CheckBoxAimbot:SetPos( 10,170 )
	CheckBoxAimbot:SetText( "AutoWall" )
	CheckBoxAimbot:SetConVar( "AutoWall" ) 
	CheckBoxAimbot:SizeToContents()
	
	-- Aimbot Auto wall        
	
	local CheckBoxAimbot = vgui.Create( "DCheckBoxLabel", frame )
	CheckBoxAimbot:SetPos( 10,200 )
	CheckBoxAimbot:SetText( "Prediction" )
	CheckBoxAimbot:SetConVar( "Ben_Aimbot_Prediction" ) 
	CheckBoxAimbot:SizeToContents()
	
	-- Aimbot Auto wall        
	
	local CheckBoxAimbot = vgui.Create( "DCheckBoxLabel", frame )
	CheckBoxAimbot:SetPos( 10,230 )
	CheckBoxAimbot:SetText( "Ignore Spawn Protection" )
	CheckBoxAimbot:SetConVar( "Ben_Aimbot_IgnoreSpawnProtection" ) 
	CheckBoxAimbot:SizeToContents()
	
	-- Aimbot Hitbox
	
	local DComboBox1 = vgui.Create( "DComboBox" , frame )
	DComboBox1:SetPos( 10,260 )
	DComboBox1:SetSize( 100, 20 )
	DComboBox1:SetValue( "Aimbot Hitbox" )
	DComboBox1:AddChoice( "ValveBiped.Bip01_Head1" )
	DComboBox1:AddChoice( "ValveBiped.Bip01_Neck1" )
	DComboBox1:AddChoice( "ValveBiped.Bip01_Spine4" )
	DComboBox1:AddChoice( "ValveBiped.Bip01_Spine2" )
	DComboBox1:AddChoice( "ValveBiped.Bip01_Spine1" )
	DComboBox1:AddChoice( "ValveBiped.Bip01_Spine" )
	DComboBox1:AddChoice( "ValveBiped.Bip01_R_UpperArm" )
	DComboBox1:AddChoice( "ValveBiped.Bip01_R_Forearm" )
	DComboBox1:AddChoice( "ValveBiped.Bip01_R_Hand" )
	DComboBox1:AddChoice( "ValveBiped.Bip01_L_UpperArm" )
	DComboBox1:AddChoice( "ValveBiped.Bip01_L_Forearm" )
	DComboBox1:AddChoice( "ValveBiped.Bip01_L_Hand" )
	DComboBox1:AddChoice( "ValveBiped.Bip01_R_Thigh" )
	DComboBox1:AddChoice( "ValveBiped.Bip01_R_Calf" )
	DComboBox1:AddChoice( "ValveBiped.Bip01_R_Foot" )
	DComboBox1:AddChoice( "ValveBiped.Bip01_R_Toe0" )
	DComboBox1:AddChoice( "ValveBiped.Bip01_L_Thigh" )
	DComboBox1:AddChoice( "ValveBiped.Bip01_L_Calf" )
	DComboBox1:AddChoice( "ValveBiped.Bip01_L_Foot" )
	DComboBox1:AddChoice( "ValveBiped.Bip01_L_Toe0" )
	DComboBox1.OnSelect = function( panel, index, value )
		--print( value .." was selected!" )
		if (value == "ValveBiped.Bip01_Head1") then
			hitbox = "ValveBiped.Bip01_Head1"
			print( "Hitbox : Head" )
		end
		if (value == "ValveBiped.Bip01_Neck1") then
			hitbox = "ValveBiped.Bip01_Neck1"
			print( "Hitbox : Neck" )
		end
		if (value == "ValveBiped.Bip01_Spine4") then
			hitbox = "ValveBiped.Bip01_Spine4"
			print( "Hitbox : Spine" )
		end
	end
	
	-- Visual Enabled                
	
	local CheckBoxAimbot = vgui.Create( "DCheckBoxLabel", frame )
	CheckBoxAimbot:SetPos( 160,50 )
	CheckBoxAimbot:SetText( "Visuals Enabled" )
	CheckBoxAimbot:SetConVar( "Ben_Visuals_Enabled" ) 
	CheckBoxAimbot:SizeToContents()
	
	-- Visual Name                
	
	local CheckBoxAimbot = vgui.Create( "DCheckBoxLabel", frame )
	CheckBoxAimbot:SetPos( 160,80 )
	CheckBoxAimbot:SetText( "Name" )
	CheckBoxAimbot:SetConVar( "Ben_Visuals_Name" ) 
	CheckBoxAimbot:SizeToContents()
	
    -- Visual Box                
	
	local CheckBoxAimbot = vgui.Create( "DCheckBoxLabel", frame )
	CheckBoxAimbot:SetPos( 160,110 )
	CheckBoxAimbot:SetText( "Box" )
	CheckBoxAimbot:SetConVar( "Ben_Visuals_Box" ) 
	CheckBoxAimbot:SizeToContents()
	
	-- Visual Box
	
	local DComboBox = vgui.Create( "DComboBox" , frame )
	DComboBox:SetPos( 160,140 )
	DComboBox:SetSize( 100, 20 )
	DComboBox:SetValue( "Box Type" )
	DComboBox:AddChoice( "Type One" )
	DComboBox:AddChoice( "Type Two" )
	DComboBox.OnSelect = function( panel, index, value )
		--print( value .." was selected!" )
		if (value == "Box Type") then
			RunConsoleCommand("Ben_Visuals_Box_Type", "0")
			print( "Box Type : 0" )
		end
		if (value == "Type One") then
			RunConsoleCommand("Ben_Visuals_Box_Type", "1")
			print( "Box Type : 1" )
		end
		if (value == "Type Two") then
			RunConsoleCommand("Ben_Visuals_Box_Type","2")
			print( "Box Type : 2" )
		end
	end
	
	-- Visual Health               
	
	local CheckBoxAimbot = vgui.Create( "DCheckBoxLabel", frame )
	CheckBoxAimbot:SetPos( 160,170 )
	CheckBoxAimbot:SetText( "Healthbar" )
	CheckBoxAimbot:SetConVar( "Ben_Visuals_Health" ) 
	CheckBoxAimbot:SizeToContents()
	
	local DComboBox1 = vgui.Create( "DComboBox" , frame )
	DComboBox1:SetPos( 160,200 )
	DComboBox1:SetSize( 100, 20 )
	DComboBox1:SetValue( "Healthbar Type" )
	DComboBox1:AddChoice( "Type One" )
	DComboBox1:AddChoice( "Type Two" )
	DComboBox1.OnSelect = function( panel, index, value )
		--print( value .." was selected!" )
		if (value == "Box Type") then
			RunConsoleCommand("Ben_Visuals_Health_Type", "0")
			print( "Health Type : 0" )
		end
		if (value == "Type One") then
			RunConsoleCommand("Ben_Visuals_Health_Type", "1")
			print( "Health Type : 1" )
		end
		if (value == "Type Two") then
			RunConsoleCommand("Ben_Visuals_Health_Type","2")
			print( "Health Type : 2" )
		end
	end
	
	-- Visual Weapon              
	
	local CheckBoxAimbot = vgui.Create( "DCheckBoxLabel", frame )
	CheckBoxAimbot:SetPos( 160,230 )
	CheckBoxAimbot:SetText( "Weapon" )
	CheckBoxAimbot:SetConVar( "Ben_Visuals_Weapon" ) 
	CheckBoxAimbot:SizeToContents()
	
	-- Visual rank           
	
	local CheckBoxAimbot = vgui.Create( "DCheckBoxLabel", frame )
	CheckBoxAimbot:SetPos( 160,260 )
	CheckBoxAimbot:SetText( "Rank" )
	CheckBoxAimbot:SetConVar( "Ben_Visuals_Rank" ) 
	CheckBoxAimbot:SizeToContents()
	
	-- Visual Nohands              
	
	local CheckBoxAimbot = vgui.Create( "DCheckBoxLabel", frame )
	CheckBoxAimbot:SetPos( 160,290 )
	CheckBoxAimbot:SetText( "Hands" )
	CheckBoxAimbot:SetConVar( "Ben_Visuals_hands" ) 
	CheckBoxAimbot:SizeToContents()
	
	local DComboBox2 = vgui.Create( "DComboBox" , frame )
	DComboBox2:SetPos( 160,320 )
	DComboBox2:SetSize( 100, 20 )
	DComboBox2:SetValue( "Hands Type" )
	DComboBox2:AddChoice( "Disabled" )
	DComboBox2:AddChoice( "Chams" )
	DComboBox2:AddChoice( "Normal" )
	DComboBox2.OnSelect = function( panel, index, value )
		--print( value .." was selected!" )
		if (value == "Disabled") then
			RunConsoleCommand("Ben_Visuals_Hands_Type","1")
			print( "Hands Type : 1" )
		end
		if (value == "Chams") then
			RunConsoleCommand("Ben_Visuals_Hands_Type","0")
			print( "Hands Type : 2" )
		end
		if (value == "Normal") then
			RunConsoleCommand("Ben_Visuals_Hands_Type","0")
			print( "Hands Type : 3" )
		end
	end
	
	
	-- Visual Wireframe viewmodel           
	
	local CheckBoxAimbot = vgui.Create( "DCheckBoxLabel", frame )
	CheckBoxAimbot:SetPos( 160,350 )
	CheckBoxAimbot:SetText( "Wireframe Viewmodel" )
	CheckBoxAimbot:SetConVar( "Ben_Visuals_Wireframe_Viewmodel" ) 
	CheckBoxAimbot:SizeToContents()
	
	-- Visual Third person          
	
	local CheckBoxAimbot = vgui.Create( "DCheckBoxLabel", frame )
	CheckBoxAimbot:SetPos( 160,380 )
	CheckBoxAimbot:SetText( "Thirdperson" )
	CheckBoxAimbot:SetConVar( "Ben_Visuals_Thirdperson" ) 
	CheckBoxAimbot:SizeToContents()
	
    -- Visual chams         
	
	local CheckBoxAimbot = vgui.Create( "DCheckBoxLabel", frame )
	CheckBoxAimbot:SetPos( 160,410 )
	CheckBoxAimbot:SetText( "Chams" )
	CheckBoxAimbot:SetConVar( "Ben_Visuals_Chams" ) 
	CheckBoxAimbot:SizeToContents()
	
	local DComboBox6 = vgui.Create( "DComboBox" , frame )
	DComboBox6:SetPos( 240,410 )
	DComboBox6:SetSize( 100, 20 )
	DComboBox6:SetValue( "Chams Type" )
	DComboBox6:AddChoice( "Textured" )
	DComboBox6:AddChoice( "Wireframe" )
	DComboBox6.OnSelect = function( panel, index, value )
		--print( value .." was selected!" )
		if (value == "Wireframe") then
			RunConsoleCommand("Ben_Visuals_Chams_type","2")
		end
		if (value == "Chams") then
			RunConsoleCommand("Ben_Visuals_Chams_type","1")
		end
	end
	
		
    -- Visual chams         
	
	local CheckBoxAimbot = vgui.Create( "DCheckBoxLabel", frame )
	CheckBoxAimbot:SetPos( 160,440 )
	CheckBoxAimbot:SetText( "No Sky" )
	CheckBoxAimbot:SetConVar( "Ben_Visuals_Nosky" ) 
	CheckBoxAimbot:SizeToContents()
	
	-- Visual chams         
	
	local CheckBoxAimbot = vgui.Create( "DCheckBoxLabel", frame )
	CheckBoxAimbot:SetPos( 160,470 )
	CheckBoxAimbot:SetText( "Hitmarker" )
	CheckBoxAimbot:SetConVar( "Ben_Visuals_Hitmarker" ) 
	CheckBoxAimbot:SizeToContents()
	
	-- Misc Enabled                
	
	local CheckBoxAimbot = vgui.Create( "DCheckBoxLabel", frame )
	CheckBoxAimbot:SetPos( 310,50 )
	CheckBoxAimbot:SetText( "Miscellaneous Enabled" )
	CheckBoxAimbot:SetConVar( "Ben_Misc_Enabled" ) 
	CheckBoxAimbot:SizeToContents()
	
	-- Misc Crosshair                 
	
	local CheckBoxAimbot = vgui.Create( "DCheckBoxLabel", frame )
	CheckBoxAimbot:SetPos( 310,80 )
	CheckBoxAimbot:SetText( "Crosshair" )
	CheckBoxAimbot:SetConVar( "Ben_Misc_Crosshair" ) 
	CheckBoxAimbot:SizeToContents()

	
	-- crosshair type
	
	local DComboBox3 = vgui.Create( "DComboBox" , frame )
	DComboBox3:SetPos( 310,110 )
	DComboBox3:SetSize( 100, 20 )
	DComboBox3:SetValue( "Crosshair Type" )
	DComboBox3:AddChoice( "Default" )
	DComboBox3:AddChoice( "Type One" )
	DComboBox3:AddChoice( "Type Two" )
	DComboBox3.OnSelect = function( panel, index, value )
		--print( value .." was selected!" )
		if (value == "Type One") then
			RunConsoleCommand("Ben_Misc_Crosshair_type","1")
			RunConsoleCommand("Ben_Misc_Crosshair_box","1")
			print( "Crosshair Type : 1" )
		end
		if (value == "Type Two") then
			RunConsoleCommand("Ben_Misc_Crosshair_type","2")
			print( "Crosshair Type : 2" )
		end
		if (value == "Default") then
			RunConsoleCommand("Ben_Misc_Crosshair_type","0")
			print( "Crosshair Type : 3" )
		end
	end
	
	-- Misc Bunnyhop           
	
	local CheckBoxAimbot = vgui.Create( "DCheckBoxLabel", frame )
	CheckBoxAimbot:SetPos( 310,140 )
	CheckBoxAimbot:SetText( "Bunnyhop" )
	CheckBoxAimbot:SetConVar( "Ben_Misc_Bunnyhop" ) 
	CheckBoxAimbot:SizeToContents()
	
    -- Misc Autostrafe           
	
	local CheckBoxAimbot = vgui.Create( "DCheckBoxLabel", frame )
	CheckBoxAimbot:SetPos( 310,170 )
	CheckBoxAimbot:SetText( "Autostrafe " )
	CheckBoxAimbot:SetConVar( "Ben_Misc_Autostrafe" ) 
	CheckBoxAimbot:SizeToContents()
	
	-- Misc chat spam        
	
	local CheckBoxAimbot = vgui.Create( "DCheckBoxLabel", frame )
	CheckBoxAimbot:SetPos( 310,200 )
	CheckBoxAimbot:SetText( "Kill Spam" )
	CheckBoxAimbot:SetConVar( "Ben_Misc_Chatspam" ) 
	CheckBoxAimbot:SizeToContents()
	
	local myText = vgui.Create("DTextEntry", frame)
	myText:SetSize (110,17)
	myText:SetText("Spam Text")
	myText:SetPos(400,199)
	myText.OnEnter = function() 
		spam_text = myText:GetValue()
	end
	-- Misc No recoil         
	
	local CheckBoxAimbot = vgui.Create( "DCheckBoxLabel", frame )
	CheckBoxAimbot:SetPos( 310,230 )
	CheckBoxAimbot:SetText( "No Recoil" )
	CheckBoxAimbot:SetConVar( "Ben_Misc_Norecoil" ) 
	CheckBoxAimbot:SizeToContents()
	
	-- Misc No recoil         
	
	local CheckBoxAimbot = vgui.Create( "DCheckBoxLabel", frame )
	CheckBoxAimbot:SetPos( 310,260 )
	CheckBoxAimbot:SetText( "Rapid Fire" )
	CheckBoxAimbot:SetConVar( "Ben_Misc_Autopistol" ) 
	CheckBoxAimbot:SizeToContents()
	
	-- Misc FOV changer
	
	local DermaNumSlider = vgui.Create( "DNumSlider", frame )
	DermaNumSlider:SetPos( 310,246 )			// Set the position
	DermaNumSlider:SetSize( 300, 100 )		// Set the size
	DermaNumSlider:SetText( "Field Of View" )	// Set the text above the slider
	DermaNumSlider:SetMin( 90 )				// Set the minimum number you can slide to
	DermaNumSlider:SetMax( 150 )				// Set the maximum number you can slide to
	DermaNumSlider:SetDecimals( 0 )			// Decimal places - zero for whole number
	DermaNumSlider:SetConVar( "Ben_Misc_Fov" ) // Changes the ConVar when you slide
	
	-- HVH enabled         
	
	local CheckBoxAimbot = vgui.Create( "DCheckBoxLabel", frame )
	CheckBoxAimbot:SetPos( 700,50 )
	CheckBoxAimbot:SetText( "Hack vs Hack Enabled" )
	CheckBoxAimbot:SetConVar( "Ben_hvh_enable" ) 
	CheckBoxAimbot:SizeToContents()
	
	-- HVH enabled         
	
	local CheckBoxAimbot = vgui.Create( "DCheckBoxLabel", frame )
	CheckBoxAimbot:SetPos( 700,80 )
	CheckBoxAimbot:SetText( "FakeLag" )
	CheckBoxAimbot:SetConVar( "Ben_hvh_fakelag" ) 
	CheckBoxAimbot:SizeToContents()
	
	-- hvh fake lag factor
	
	local DermaNumSlider = vgui.Create( "DNumSlider", frame )
	DermaNumSlider:SetPos( 700,90 )			// Set the position
	DermaNumSlider:SetSize( 300, 100 )		// Set the size
	DermaNumSlider:SetText( "Fakelag Rate" )	// Set the text above the slider
	DermaNumSlider:SetMin( 1 )				// Set the minimum number you can slide to
	DermaNumSlider:SetMax( 15 )				// Set the maximum number you can slide to
	DermaNumSlider:SetDecimals( 0 )			// Decimal places - zero for whole number
	DermaNumSlider:SetConVar( "Ben_hvh_fakelag_factor" ) // Changes the ConVar when you slide
	
	-- HVH enabled         
	
	local CheckBoxAimbot = vgui.Create( "DCheckBoxLabel", frame )
	CheckBoxAimbot:SetPos( 700,170 )
	CheckBoxAimbot:SetText( "AntiAim" )
	CheckBoxAimbot:SetConVar( "Ben_hvh_aa" ) 
	CheckBoxAimbot:SizeToContents()
	
	-- cAnti aim
	
	local DComboBox3 = vgui.Create( "DComboBox" , frame )
	DComboBox3:SetPos( 700,200 )
	DComboBox3:SetSize( 210, 20 )
	DComboBox3:SetValue( "AntiAim Type" )
	for k,v in pairs(Antiaims) do
		DComboBox3:AddChoice(v[2], function() RunConsoleCommand("Ben_hvh_aa_method", v[1]) end)
	end
	DComboBox3.OnSelect = function( panel, index, value )
		--print( value .." was selected!" )
		if (value == "Static Up") then
			RunConsoleCommand("Ben_hvh_aa_method","1")
		end
		if (value == "Static Down") then
			RunConsoleCommand("Ben_hvh_aa_method","2")
		end
		if (value == "Static Up/Down Change") then
			RunConsoleCommand("Ben_hvh_aa_method","3")
		end
		if (value == "Sideway Follow Right Up") then
			RunConsoleCommand("Ben_hvh_aa_method","4")
		end
		if (value == "Sideway Follow Right Down") then
			RunConsoleCommand("Ben_hvh_aa_method","5")
		end
		if (value == "Sideway Follow Right Up/Down Change") then
			RunConsoleCommand("Ben_hvh_aa_method","6")
		end
		if (value == "Sideway Follow Left Up") then
			RunConsoleCommand("Ben_hvh_aa_method","7")
		end
		if (value == "Sideway Follow Left Down") then
			RunConsoleCommand("Ben_hvh_aa_method","8")
		end
		if (value == "Sideway Follow Left Up/Down Change") then
			RunConsoleCommand("Ben_hvh_aa_method","9")
		end
		if (value == "Jitter Down") then
			RunConsoleCommand("Ben_hvh_aa_method","11")
		end
		if (value == "Jitter Up/Down Change") then
			RunConsoleCommand("Ben_hvh_aa_method","12")
		end
		if (value == "Random Angles 1") then
			RunConsoleCommand("Ben_hvh_aa_method","13")
		end
		if (value == "Random Angles 2") then
			RunConsoleCommand("Ben_hvh_aa_method","14")
		end
		if (value == "Jitter Up Random Fake Angles") then
			RunConsoleCommand("Ben_hvh_aa_method","15")
		end
		if (value == "Jitter Down Random Fake Angles") then
			RunConsoleCommand("Ben_hvh_aa_method","16")
		end
	end
	
	-- aaa        
	
	local CheckBoxAimbot = vgui.Create( "DCheckBoxLabel", frame )
	CheckBoxAimbot:SetPos( 700,230 )
	CheckBoxAimbot:SetText( "Anti-AntiAim" )
	CheckBoxAimbot:SetConVar( "Ben_hvh_aaa" ) 
	CheckBoxAimbot:SizeToContents()
	
	-- aaa type
	
	local DComboBox25 = vgui.Create( "DComboBox" , frame )
	DComboBox25:SetPos( 700,260 )
	DComboBox25:SetSize( 210, 20 )
	DComboBox25:SetValue( "Anti-AntiAim Type" )
	DComboBox25:AddChoice( "Auto" )
	DComboBox25:AddChoice( "Down" )
	DComboBox25:AddChoice( "Up" )
	DComboBox25.OnSelect = function( panel, index, value )
		--print( value .." was selected!" )
		if (value == "Auto") then
			RunConsoleCommand("Ben_hvh_aaa_method","1")
		end
		if (value == "Down") then
			RunConsoleCommand("Ben_hvh_aaa_method","2")
		end
		if (value == "Up") then
			RunConsoleCommand("Ben_hvh_aaa_method","3")
		end
	end
	
	-- spinbot       
	
	local CheckBoxAimbot = vgui.Create( "DCheckBoxLabel", frame )
	CheckBoxAimbot:SetPos( 700,290 )
	CheckBoxAimbot:SetText( "Spinbot" )
	CheckBoxAimbot:SetConVar( "Ben_hvh_Spinbot" ) 
	CheckBoxAimbot:SizeToContents()
	
		-- hvh fake lag factor
	
	local DermaNumSlider = vgui.Create( "DNumSlider", frame )
	DermaNumSlider:SetPos( 700,296 )			// Set the position
	DermaNumSlider:SetSize( 300, 100 )		// Set the size
	DermaNumSlider:SetText( "Spinbot Speed" )	// Set the text above the slider
	DermaNumSlider:SetMin( 1 )				// Set the minimum number you can slide to
	DermaNumSlider:SetMax( 50 )				// Set the maximum number you can slide to
	DermaNumSlider:SetDecimals( 0 )			// Decimal places - zero for whole number
	DermaNumSlider:SetConVar( "Ben_hvh_Spinbot_Speed" ) // Changes the ConVar when you slide
end	


function GAMEMODE:CreateMove(ucmd)

	if(ucmd:CommandNumber() == 0) then
		return;
	end

	RunConsoleCommand("cl_interp", 0);
	RunConsoleCommand("cl_updaterate", 100000);
	RunConsoleCommand("cl_interp_ratio", 1);
	
	pBhoop(ucmd);
	Aimbot(ucmd);
	RapidFire(ucmd);
	FakeLag(ucmd);
	Antiaim(ucmd);  
	pinbot(ucmd); 
	-- some bs --EnginePrediction(ucmd:CommandNumber());
	
	
end



local c_insertdown2, c_insertdown, c_menuopen;
local function RGB_Selection()
	local cframe = vgui.Create( "DFrame" )
	cframe:SetPos( 1010, 5 )
	cframe:SetSize( 300, 270)
	cframe:SetTitle( "" )
	cframe:SetVisible( true )
	cframe:SetDraggable( true )
	cframe:ShowCloseButton( false )
	cframe:MakePopup()

	
	
	-- Color label
	local color_label = Label( "Color( 255, 255, 255 )", cframe )
	color_label:SetPos( 95, 230 )
	color_label:SetSize( 150, 20 )
	color_label:SetHighlight( true )
	color_label:SetColor( Color( 255, 255, 255 ) )

	-- Color picker
	local color_picker = vgui.Create( "DRGBPicker", cframe )
	color_picker:SetPos( 50, 60 )
	color_picker:SetSize( 30, 190 )

	-- Color cube
	local color_cube = vgui.Create( "DColorCube", cframe )
	color_cube:SetPos( 85, 60 )
	color_cube:SetSize( 155, 155 )

	-- When the picked color is changed...
	function color_picker:OnChange( col )

		-- Get the hue of the RGB picker and the saturation and vibrance of the color cube
		local h = ColorToHSV( col )
		local _, s, v = ColorToHSV( color_cube:GetRGB() )

		-- Mix them together and update the color cube
		col = HSVToColor( h, s, v )
		color_cube:SetColor( col )

		-- Lastly, update the background color and label
		UpdateColors( col )

	end

	function color_cube:OnUserChanged( col )

		-- Update background color and label
		UpdateColors( col )

	end

	-- Updates display colors, label, and clipboard text
	function UpdateColors( col )
	
		color_label:SetText( "Color( "..col.r..", "..col.g..", "..col.b.." )" )
		color_label:SetColor( Color( ( col.r ), ( col.g ), ( col.b ) ) )
		RunConsoleCommand("Ben_Misc_menu_r",col.r)
		RunConsoleCommand("Ben_Misc_menu_g",col.g)
		RunConsoleCommand("Ben_Misc_menu_b",col.b)
		SetClipboardText( color_label:GetText() )

	end

	cframe.Paint = function( self )
		
		draw.RoundedBox(0, 0, 0, self:GetWide(), self:GetTall(), Color(50, 50, 50))
		draw.RoundedBox(0, 0, 0, self:GetWide(), 25, Color(GetConVarNumber("Ben_Misc_menu_r"),GetConVarNumber("Ben_Misc_menu_g"),GetConVarNumber("Ben_Misc_menu_b")))
		draw.SimpleText("Menu Color", "Menu Font", self:GetWide() / 2, 12.5, Color(255,255,255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)          
		surface.SetDrawColor(Color(75,75,75))
		
	end
	
	cframe.Think = function()
			if (input.IsKeyDown(KEY_INSERT) && !c_insertdown2) then
				cframe:Remove();
				c_menuopen = false;				
			end
	end
	
	
end	




local function Think()
        if (input.IsKeyDown(KEY_INSERT) && !menuopen && !insertdown && !c_menuopen && !c_insertdown) then
                menuopen = true;
                insertdown = true;
				c_menuopen = true;
				c_insertdown = true;
                menu();
				RGB_Selection();
				surface.PlaySound("Resource/warning.wav" )
        elseif (!input.IsKeyDown(KEY_INSERT) && !menuopen && !c_menuopen) then
                insertdown = false;
				c_insertdown = false
        end
        if (input.IsKeyDown(KEY_INSERT) && insertdown && menuopen) then
                insertdown2 = true;
				c_insertdown2 = true
        else
                insertdown2 = false;
				c_insertdown2 = false
        end
end
 
hook.Add("Think", "Menu", Think);

MsgC( Color( 23, 150, 50 ), ">> [ bBot Loaded! ]\n" );
MsgC( Color( 23, 150, 50 ), ">> Pasted By Ben.\n" );
MsgC( Color( 23, 150, 50 ), ">> Menu Toggle Key : Insert" );