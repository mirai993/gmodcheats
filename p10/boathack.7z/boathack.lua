--Boathack made by Muchamosboat--
--This is my first Lua Script ever, so any suggests or edits you would made please let me know on the form--
--In order to open the menu you will need to type "Bind [Key of your choice] open_boat"--
--For the aimbot there is no key you need to press, once your crosshair gets close enough to a players head it will snap on (Will likely change this in future undates)--
 
surface.CreateFont( "Arial", { -- This is your font, DO NOT DELETE
    font = "Arial", -- Use the font-name which is shown to you by your operating system Font Viewer, not the file name
    extended = false,
    size = 25,
    weight = 500,
    blursize = 0,
    scanlines = 0,
    antialias = true,
    underline = false,
    italic = false,
    strikeout = false,
    symbol = false,
    rotary = false,
    shadow = false,
    additive = false,
    outline = false,
} )
 
ply=LocalPlayer()
 
function BoatMenu()
 
CreateClientConVar( "esp", 0, true, false )
 
CreateClientConVar( "aimbot", 0, true, false )
 
CreateClientConVar( "Bhop", 0, true, false )
 
local DermaPanel = vgui.Create("DFrame") --This is the DermaPanel
DermaPanel:SetSize(250,200)
DermaPanel:Center()
DermaPanel:SetTitle("BoatHack V1 - Made By Muchamosboat")
DermaPanel:SetVisible(true)
DermaPanel:MakePopup()
DermaPanel:ShowCloseButton(true)
DermaPanel.Paint = function(s , w , h)
 
    draw.RoundedBox(5,0,0,w ,h ,Color(0,0,0,255))
 
    draw.RoundedBox(5,2,2,w-4 ,h-4 ,Color(45,45,45,255))
 
end
 
local DLabel = vgui.Create("DLabel", DermaPanel)
DLabel:SetPos(10,40)
DLabel:SetText("Aimbot")
 
local button = vgui.Create("DButton" , DermaPanel)
button:SetPos(50,40)
button:SetSize(50,20)
button:SetText("Enable")
function button.DoClick()
    ply:ConCommand("aimbot 1")
end
 
local button = vgui.Create("DButton" , DermaPanel)
button:SetPos(100,40)
button:SetSize(50,20)
button:SetText("Disable")
function button.DoClick()
    ply:ConCommand("aimbot 0")
end
 
local DLabel = vgui.Create("DLabel", DermaPanel)
DLabel:SetPos(10,60)
DLabel:SetText("Bhop")
 
local button = vgui.Create("DButton", DermaPanel)
button:SetPos(50,60)
button:SetSize(50,20)
button:SetText("Enable")
function button.DoClick()
    ply:ConCommand("Bhop 1")
end
 
local button = vgui.Create("DButton", DermaPanel)
button:SetPos(100,60)
button:SetSize(50,20)
button:SetText("Disable")
function button.DoClick()
    ply:ConCommand("Bhop 0")
end
 
local DLabel = vgui.Create("DLabel", DermaPanel)
DLabel:SetPos(10,80)
DLabel:SetText("ESP")
 
local button = vgui.Create("DButton", DermaPanel)
button:SetPos(50,80)
button:SetSize(50,20)
button:SetText("Enable")
function button.DoClick()
    ply:ConCommand("esp 1")
end
 
local button = vgui.Create("DButton", DermaPanel)
button:SetPos(100,80)
button:SetSize(50,20)
button:SetText("Disable")
function button.DoClick()
    ply:ConCommand("esp 0")
end
 
end
concommand.Add("open_boat", BoatMenu)
 
hook.Add( "HUDPaint", "ESP" ,function()
 
    if ConVarExists("esp") and GetConVar("esp"):GetInt() == 1 then
 
    for k,v in pairs ( player.GetAll() ) do
       
        local Position = ( v:GetPos() + Vector( 0,0,80 ) ):ToScreen()
        draw.DrawText( v:Name(), "Arial", Position.x, Position.y, Color(255,255,255), 1 )
    end
end
end)
 
hook.Add( "CreateMove", "BunnyHop:CreateMove", function( input )
 
    if ConVarExists("Bhop") and GetConVar("Bhop"):GetInt() == 1 then
 
    if ( !LocalPlayer( ):Alive( ) || !LocalPlayer( ).NextBunnyHop ) then return; end
    if ( LocalPlayer( ).NextBunnyHop < CurTime( ) ) then return; end
 
    if ( input:KeyDown( IN_JUMP ) ) then
        input:SetButtons( input:GetButtons( ) - IN_JUMP );
    end
end
end)
 
 if ConVarExists("Bhop") and GetConVar("Bhop"):GetInt() == 1 then
hook.Add( "OnPlayerHitGround", "BunnyHop:HotFeet", function( _p, _inWater, _onFloater, _speed )
    _p.NextBunnyHop = CurTime( );
end );
end
 
function aimbot()
    local ply = LocalPlayer()
    local trace = util.GetPlayerTrace( ply )
    local traceRes = util.TraceLine( trace )
 
    if ConVarExists("aimbot") and GetConVar("aimbot"):GetInt() == 1 then
 
    if traceRes.HitNonWorld then
        local target = traceRes.Entity
        if target:IsPlayer() then
            local targethead = target:LookupBone("ValveBiped.Bip01_Head1")
            local targetheadpos,targetheadang = target:GetBonePosition(targethead)
            ply:SetEyeAngles((targetheadpos - ply:GetShootPos()):Angle())
        end
    end
end
end
hook.Add("Think", "aimbot", aimbot)