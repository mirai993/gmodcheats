--[[
	MOD/lua/BoxBotInDev.lua
	Nautical | STEAM_0:1:25812285 <74.103.204.228:27005> | [19-10-13 10:45:13PM]
	===BadFile===
]]


-- Made by Boxedin123 with help from reference material from Nautical and math For the crosshair placement from snowizgr8 and the bones table from ReichBot v3(Couldent find author)
-- This is for LEARNING ONLY! IM NOT GOING TO RELEASE IT, only share it among friends.

-- Convars

local crossHair 		= CreateClientConVar( "BoxBot_Crosshair",		0,true,false )
local triggerBot 		= CreateClientConVar( "BoxBot_Trigger",			0,true,false ) 
local noRecoil 			= CreateClientConVar( "BoxBot_Norecoil",		0,true,false )
local esp 				= CreateClientConVar( "BoxBot_ESP",				0,true,false )
local entEsp			= CreateClientConVar( "BoxBot_EntESP",			0,true,false )
local boneEsp 			= CreateClientConVar( "BoxBot_BoneEsp",			0,true,false )
local noRecoilOffset 	= CreateClientConVar( "BoxBot_NorecoilOffset",	0,true,false )
local aimbot 			= CreateClientConVar( "BoxBot_Aimbot",			0,true,false )
local speedOffset		= CreateClientConVar( "BoxBot_SpeedOffset",		0,true,false )
local boundingBoxes 	= CreateClientConVar( "BoxBot_BoundingBoxes",	0,true,false )

-- Variables

local shouldAim 	= 0
local didShoot 		= false

local playerBones = {

        { S = "ValveBiped.Bip01_Head1", E = "ValveBiped.Bip01_Neck1" },
        { S = "ValveBiped.Bip01_Neck1", E = "ValveBiped.Bip01_Spine4" },
        { S = "ValveBiped.Bip01_Spine4", E = "ValveBiped.Bip01_Spine2" },
        { S = "ValveBiped.Bip01_Spine2", E = "ValveBiped.Bip01_Spine1" },
        { S = "ValveBiped.Bip01_Spine1", E = "ValveBiped.Bip01_Spine" },
        { S = "ValveBiped.Bip01_Spine", E = "ValveBiped.Bip01_Pelvis" },
 
        { S = "ValveBiped.Bip01_Spine2", E = "ValveBiped.Bip01_L_UpperArm" },
        { S = "ValveBiped.Bip01_L_UpperArm", E = "ValveBiped.Bip01_L_Forearm" },
        { S = "ValveBiped.Bip01_L_Forearm", E = "ValveBiped.Bip01_L_Hand" },
 
        { S = "ValveBiped.Bip01_Spine2", E = "ValveBiped.Bip01_R_UpperArm" },
        { S = "ValveBiped.Bip01_R_UpperArm", E = "ValveBiped.Bip01_R_Forearm" },
        { S = "ValveBiped.Bip01_R_Forearm", E = "ValveBiped.Bip01_R_Hand" },
 
        { S = "ValveBiped.Bip01_Pelvis", E = "ValveBiped.Bip01_L_Thigh" },
        { S = "ValveBiped.Bip01_L_Thigh", E = "ValveBiped.Bip01_L_Calf" },
        { S = "ValveBiped.Bip01_L_Calf", E = "ValveBiped.Bip01_L_Foot" },
        { S = "ValveBiped.Bip01_L_Foot", E = "ValveBiped.Bip01_L_Toe0" },
       
        { S = "ValveBiped.Bip01_Pelvis", E = "ValveBiped.Bip01_R_Thigh" },
        { S = "ValveBiped.Bip01_R_Thigh", E = "ValveBiped.Bip01_R_Calf" },
        { S = "ValveBiped.Bip01_R_Calf", E = "ValveBiped.Bip01_R_Foot" },
        { S = "ValveBiped.Bip01_R_Foot", E = "ValveBiped.Bip01_R_Toe0" },
}

local entClasses = { "spawned_shipment","money_printer" } // add classes here

-- TriggerBot

local function boxBotTriggerBot()
 
	if triggerBot:GetInt() >= 1 and shouldAim == 1 then
	
		local eyeTrace = LocalPlayer():GetEyeTrace().Entity
		
		if ( eyeTrace:IsPlayer() ) then 
		
			if ( didShoot ) then
			
				RunConsoleCommand( "-Attack" )
				didShoot = false

			else 
	
				RunConsoleCommand( "+Attack" )
				didShoot = true
			end
   
		elseif ( DidShoot ) then 
	
			RunConsoleCommand( "-Attack" )
			didShoot = false
		end
  
	elseif ( didShoot ) then 
	
		RunConsoleCommand( "-Attack" )
		didShoot = false
		
	end
end

-- Aimbot

local function distance( x1,y1,x2,y2 ) // function to return 2D distance, look up distance formula for graphs if you dont understand this
	
	local xsq = ( x2 - x1 )
	
	xsq = xsq * xsq
	
	local ysq = ( y2 - y1 )
	
	ysq = ysq * ysq

	return math.sqrt( xsq + ysq )
end

local function closestTarget()

	local best = { 0,nil }

	for k,v in ipairs( player.GetAll() ) do
		
		if ( v == LocalPlayer() ) then continue end
		if ( !v:Alive() ) then continue end
		
		local traceArray = {}
		traceArray.mask = MASK_SHOT
		traceArray.start = LocalPlayer():GetShootPos()
		traceArray.endpos = v:GetShootPos()
		traceArray.filter = { LocalPlayer(), v }

		local trace = util.TraceLine( traceArray )

		if ( trace.Hit ) then continue end
		
		local pos = v:GetPos():ToScreen()
		
		local targDistance = distance( ScrW() / 2,ScrH() / 2,pos.x,pos.y )
	
		if ( targDistance < best[ 1 ] or best[ 2 ] == nil ) then // if the distance from the center of the screen to the screen pos of the target is less than whats stored then, or if best[ 2 ] is nil, meaning this is our first loop then..
		
		
			best = { targDistance,v } 
		end
	end

	return best[ 2 ]
end

local function boxBotAim()

	if ( aimbot:GetInt() >= 1 or shouldAim == 1 ) then
	
		local target = closestTarget()
	
		if ( target == nil ) then return end

		local attachment = target:LookupAttachment( "eyes" ) 
				
		if ( attachment == nil ) then return end
				
		local getAttachment = target:GetAttachment( attachment )
		local myVector = ( getAttachment.Pos - LocalPlayer():GetShootPos() )
				
		LocalPlayer():SetEyeAngles( myVector:Angle() )
	end
end

-- No Recoil

local function noRecoilThink()
	
	if ( noRecoil:GetInt() >= 1 ) then
	
		if ( LocalPlayer():GetActiveWeapon().Primary ) then
		
			LocalPlayer():GetActiveWeapon().Primary.Recoil = noRecoilOffset:GetInt()
		end
	 end
end

-- Esp

local function boxBotEsp()

	if ( esp:GetInt() >= 1 ) then
	
		for _,v in ipairs( player.GetAll() ) do
		
			-- Information
			
			if ( v == LocalPlayer() ) then continue end
				
			local pos = v:GetPos()
			local offset01 = ( pos + Vector( 0,0,85 ) ):ToScreen()
			local offset02 = ( pos - Vector( 0,0,10 ) ):ToScreen()
			
			local colorOfEsp = team.GetColor( v:Team() )
			
			draw.SimpleText( v:Nick() , "BudgetLabel", offset01.x , offset01.y, colorOfEsp , TEXT_ALIGN_CENTER,TEXT_ALIGN_CENTER )
			
			local hp = "*DEAD*"
			
			if ( v:Alive() ) then
			
				hp = "Health: " .. v:Health()
			end
			
			local plyPos2 = ( v:GetPos() - Vector( 0,0,10 ) ):ToScreen()
		
			draw.SimpleText(  hp, "BudgetLabel", offset02.x , offset02.y, colorOfEsp , TEXT_ALIGN_CENTER,TEXT_ALIGN_CENTER )
			
			-- Boxes
			
			surface.SetDrawColor( colorOfEsp )
			
			if ( boundingBoxes:GetInt() >= 1 ) then
			
				local height = math.abs( offset01.y - offset02.y ) - 12
				
				surface.DrawOutlinedRect( offset01.x - ( height / 2 ),offset01.y + 6,height,height )
			end
			
			-- Skeleton
			
			if ( boneEsp:GetInt() >= 1 ) then
			
				for a,b in pairs( playerBones ) do
					
					local start = v:LookupBone( b.S )
					
					if ( start == nil ) then continue end
					
					local endPos = v:LookupBone( b.E )
					
					if ( endPos == nil ) then continue end
					
					local startScreenPos = v:GetBonePosition( start ):ToScreen()
					local endScreenPos = v:GetBonePosition( endPos ):ToScreen()
					
					surface.DrawLine( startScreenPos.x,startScreenPos.y,endScreenPos.x,endScreenPos.y )
				
				end
			
			end
			
		end
		
		-- Entity Esp
		
		if ( entEsp:GetInt() >= 1 ) then
		
			for _,v in ipairs( ents.GetAll() ) do
			
				local class = string.lower( v:GetClass() )
			
				if ( !table.HasValue( entClasses,class ) ) then continue end
				
				local entPos = v:LocalToWorld( v:OBBCenter() ):ToScreen() // get center of model and convert to screen coordinates
				
				draw.SimpleText( class,"BudgetLabel",entPos.x,entPos.y,Color( 120,120,200,255 ) ,TEXT_ALIGN_CENTER,TEXT_ALIGN_CENTER )
			end
		end
	end
	
	if ( crossHair:GetInt() >= 1 ) then
	
		local Strobe = math.random (0,255)
	
		surface.SetDrawColor( Strobe,0,Strobe )
		surface.DrawLine( ScrW() / 2 - 10, ScrH() / 2, ScrW() / 2 + 11 , ScrH() / 2 )
		surface.DrawLine( ScrW() / 2 - 0, ScrH() / 2 - 10, ScrW() / 2 - 0 , ScrH() / 2 + 11 )
	end
end

--BoxBotInDevMenu 100% boxedin
local function boxBotVgui()

	local Frame = vgui.Create( "DFrame" )
	Frame:SetPos( 50, 50 )
	Frame:SetSize( 500, 600 )
	Frame:SetTitle( "BoxBot Alpha: Coded By Boxedin123 / LOTS Of Help From Nautical.")
	Frame:SetVisible( true )
	Frame:SetDraggable( true )
	Frame:ShowCloseButton( true )
	Frame:MakePopup()
 
    local Crosshair = vgui.Create( "DCheckBoxLabel" )
    Crosshair:SetText( "Crosshair" )
    Crosshair:SetConVar( "BoxBot_Crosshair" )
	Crosshair:SetParent( Frame )
 	Crosshair:SetPos( 70,50 )
    Crosshair:SetValue( crossHair:GetInt() )
    Crosshair:SizeToContents()
	
    local TriggerBotBox = vgui.Create( "DCheckBoxLabel" )
    TriggerBotBox:SetText( "Trigger Bot" )
	TriggerBotBox:SetParent( Frame )
 	TriggerBotBox:SetPos( 70,70 )
    TriggerBotBox:SetConVar( "BoxBot_Trigger" )
    TriggerBotBox:SetValue( triggerBot:GetInt() )
    TriggerBotBox:SizeToContents()
 
    local NoRecoilBox = vgui.Create( "DCheckBoxLabel" )
    NoRecoilBox:SetText( "No Recoil" )
	NoRecoilBox:SetParent( Frame )
 	NoRecoilBox:SetPos( 70,90 )
    NoRecoilBox:SetConVar( "BoxBot_Norecoil" )
    NoRecoilBox:SetValue( noRecoil:GetInt() )
    NoRecoilBox:SizeToContents()
 
    local ESPBox = vgui.Create( "DCheckBoxLabel" )
    ESPBox:SetText( "ESP" )
	ESPBox:SetParent( Frame )
 	ESPBox:SetPos( 70,130 )
    ESPBox:SetConVar( "BoxBot_ESP" )
    ESPBox:SetValue( esp:GetInt() )
	ESPBox:SizeToContents()
	
    local ESPBoneBox = vgui.Create( "DCheckBoxLabel" )
    ESPBoneBox:SetText( "Bone Esp" )
	ESPBoneBox:SetParent( Frame )
 	ESPBoneBox:SetPos( 70,150 )
    ESPBoneBox:SetConVar( "BoxBot_BoneESP" )
    ESPBoneBox:SetValue( boneEsp:GetInt() )
	ESPBoneBox:SizeToContents()    
	
	local FullbrightBox = vgui.Create( "DCheckBoxLabel" )
    FullbrightBox:SetText( "Fullbright" )
	FullbrightBox:SetParent( Frame )
 	FullbrightBox:SetPos( 70,170 )
    FullbrightBox:SetConVar( "mat_fullbright" )
    FullbrightBox:SetValue( GetConVarNumber("mat_fullbright") )
	
	
	local WireframeBox = vgui.Create( "DCheckBoxLabel" )
    WireframeBox:SetText( "Wireframe(Buggy Something I Cant Control)" )
	WireframeBox:SetParent( Frame )
 	WireframeBox:SetPos( 70,190 )
    WireframeBox:SetConVar( "mat_wireframe")
    WireframeBox:SetValue( GetConVarNumber("mat_wireframe") )
	WireframeBox:SizeToContents()	
	
	
    local NoRecoilOffsetBox = vgui.Create( "DNumSlider" )
    NoRecoilOffsetBox:SetSize( 300, 50 ) 
	NoRecoilOffsetBox:SetParent( Frame )
 	NoRecoilOffsetBox:SetPos( 70,230 )
    NoRecoilOffsetBox:SetText( "No Recoil Offset" )
    NoRecoilOffsetBox:SetMin( -50 )
    NoRecoilOffsetBox:SetMax( 50 )
    NoRecoilOffsetBox:SetDecimals( 0 )
    NoRecoilOffsetBox:SetConVar( "BoxBot_NorecoilOffset" )


    local NoRecoilOffsetBox = vgui.Create( "DNumSlider" )
    NoRecoilOffsetBox:SetSize( 300, 100 ) 
	NoRecoilOffsetBox:SetParent( Frame )
 	NoRecoilOffsetBox:SetPos( 70,300 )
    NoRecoilOffsetBox:SetText( "Speedhack Speed" )
    NoRecoilOffsetBox:SetMin( -20 )
    NoRecoilOffsetBox:SetMax( 50 )
    NoRecoilOffsetBox:SetDecimals( 0 )
    NoRecoilOffsetBox:SetConVar( "BoxBot_SpeedOffset" )
end


--- Hooks + Cmds

hook.Add( "HUDPaint","BOXBOTESP",boxBotEsp )

hook.Add( "Think","BOXBOTTHINK",function() 

	boxBotTriggerBot()
	boxBotAim()
	noRecoilThink()
end )

--Box Bot Speed
concommand.Add("+BoxBot_Speed",function()

	RunConsoleCommand("host_framerate", GetConVarNumber("BoxBot_SpeedOffset"))
end)
 
concommand.Add("-BoxBot_Speed",function()

	RunConsoleCommand("host_framerate", "0")
end)

concommand.Add("+BoxBot_Aim",function()

	shouldAim = 1
end)
 
concommand.Add("-BoxBot_Aim",function()

	shouldAim = 0
end)

concommand.Add("BoxBot_Menu",boxBotVgui )