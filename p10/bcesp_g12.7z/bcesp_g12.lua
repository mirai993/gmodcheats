--[[
	autorun/client/BCESP.lua
	a naked 12 year old girl | (STEAM_0:1:30473979)
	===DStream===
]]

--[[
Name: BCESP.lua
Product: BloodyChef Client Scripts
Author: Eusion (STEAM_0:0:20450406)
]]--
--I've spent a long time creating this script over the years, please don't remove any of my credit. Thanks.

local BCESPToggle = CreateClientConVar("bc_esp", 1, true, false)
local BCESPPlayers = CreateClientConVar("bc_esp_players", 1, true, false)
local BCESPHCircle = CreateClientConVar("bc_esp_hcircle", 1, true, false)
local BCESPName = CreateClientConVar("bc_esp_name", 1, true, false)
local BCESPHealth = CreateClientConVar("bc_esp_health", 1, true, false)
local BCESPAdmin = CreateClientConVar("bc_esp_admin", 1, true, false)
local BCESPWeapon = CreateClientConVar("bc_esp_weapon", 1, true, false)
local BCESPDistance = CreateClientConVar("bc_esp_distance", 1, true, false)
local BCESPVelocity = CreateClientConVar("bc_esp_velocity", 0, true, false)
local BCESPImperial = CreateClientConVar("bc_esp_imperial", 0, true, false)
local BCESPLights = CreateClientConVar("bc_esp_lights", 0, true, false)
local BCESPMoney = CreateClientConVar("bc_esp_money", 0, true, false)
local BCESPLine = CreateClientConVar("bc_esp_line", 0, true, false)
local BCESPWH = CreateClientConVar("bc_esp_wh", 0, true, false)
local BCESPTTT = CreateClientConVar("bc_esp_ttt", 1, true, false)
local BCESPCS = CreateClientConVar("bc_esp_cs", 0, true, false)
local BCESPFriends = CreateClientConVar("bc_esp_friends", 1, true, false)
local BCESPIP = CreateClientConVar("bc_esp_ip", 0, true, false)
local BCESPCountry = CreateClientConVar("bc_esp_country", 0, true, false)
local BCESPTicker = CreateClientConVar("bc_esp_ticker", 1, true, false)
local BCESPEnts = CreateClientConVar("bc_esp_ents", 1, true, false)
local BCESPVehicle = CreateClientConVar("bc_esp_vehicle", 1, true, false)
local BCESPBone = CreateClientConVar("bc_esp_bone", "ValveBiped.Bip01_R_Foot", true, false)
--DefaultSmall
local BCESPFont = CreateClientConVar("bc_esp_font", "Default", true, false)
local BCESPEntities = CreateClientConVar("bc_esp_entities", "", true, false)

surface.SetFont(BCESPFont:GetString())
local Width, Height = surface.GetTextSize("a")

local TWeps = {
	"weapon_ttt_c4",
	"weapon_ttt_sipistol",
	"weapon_ttt_flaregun",
	"weapon_ttt_phammer",
	"weapon_ttt_knife"
}

local TData = {}

--Efficiency improvements.
local pairs = pairs
local sql = sql
local ValidEntity = ValidEntity
local LocalPlayer = LocalPlayer
local GetPos = GetPos
local GetBonePosition = GetBonePosition
local LookupBone = LookupBone
local IsPlayer = IsPlayer
local GetInt = GetInt
local GetString = GetString
local GetBonePosition = GetBonePosition
local draw = draw
local surface = surface
local render = render
local math = math
local GetClass = GetClass
local DynamicLight = DynamicLight

local ptable = {}
local etable = {}

hook.Remove("Think", "BCESP")
hook.Remove("HUDPaint", "BCESP")

local Tick = CurTime()

local function Ticker()
	if BCESPTicker:GetInt() == 1 then
		if (CurTime() - Tick) >= 30 then
			timer.Simple(1, function() --Every 30 seconds allow 1 second worth of scripts to run.
				Tick = CurTime()
			end)
			return true
		else
			return false
		end
	else
		return true
	end
end

local function SteamFriend(ply)
   return ply:GetFriendStatus() == "friend"
end

local function GetBone(ent, bone)
	return ent:GetBonePosition(ent:LookupBone(bone))
end

local function Visible(ent)
	if not ValidEntity(ent) then return end
	if not ent:IsPlayer() then return end
	local tracedata = {}
	tracedata.start = GetBone(LocalPlayer(), "ValveBiped.Bip01_Head1")
	tracedata.endpos = GetBone(ent, "ValveBiped.Bip01_Head1")
	tracedata.filter = LocalPlayer()
	local trace = util.TraceLine(tracedata)
	if trace.Entity:IsPlayer() then
		return true
	else
		return false
	end
end

local function GetAdmin(ply)
	if ASS_Initialized == nil and ply:GetNWString("UserGroup") == "" then
		if ply:IsAdmin() and not ply:IsSuperAdmin() then
			return "Admin"
		elseif ply:IsSuperAdmin() then
			return "Super Admin"
		elseif not ply:IsAdmin() and not ply:IsSuperAdmin() then
			return "Player"
		end
	end
	local usergroup = string.lower(ply:GetNWString("UserGroup"))
	if usergroup ~= "" then
		return string.gsub(usergroup, string.sub(usergroup, 1, 1), string.upper(string.sub(usergroup, 1, 1)))
	end
	if ASS_Initialized ~= nil and LevelToString ~= nil then
		return LevelToString(ply:GetNWInt("ASS_isAdmin"))
	end
end

hook.Add("Think", "BCESP", function()
	if BCESPToggle:GetInt() == 1 then
		ptable = {}
		etable = {}
		for k, v in pairs(ents.GetAll()) do
			if BCESPPlayers:GetInt() == 1 and ValidEntity(v) and v:IsPlayer() and v ~= LocalPlayer() and v:GetActiveWeapon():IsValid() then
				local ply = {}
				ply.data = {}
				--Start optimized variables
				if Ticker() then
					if BCESPName:GetInt() == 1 then
						v.name = v:Name()
					end
					if BCESPMoney:GetInt() == 1 then
						if v.DarkRPVars and v.DarkRPVars.money then
							v.Money = v.DarkRPVars.money
						else
							v.Money = v:GetNWInt("money")
						end
					end
					if BCESPAdmin:GetInt() == 1 then
						v.Rank = GetAdmin(v)
					end
					if BCESPIP:GetInt() == 1 then
						v.IP = sql.QueryValue("SELECT ip FROM bc_ips WHERE steam = " .. sql.SQLStr(v:SteamID()))
					end
					if BCESPCountry:GetInt() == 1 and v.IP then
						http.Get("http://api.hostip.info/country.php?ip=" .. v.IP, "", function(contents, size) 
							v.Country = contents
						end)
					end
					if BCESPFriends:GetInt() == 1 then
						v.Friend = SteamFriend(v)
					end
					ply.SubName = string.sub(v.name, 1, 7)
				end
				--End optimized variables
				if BCESPName:GetInt() == 1 then
					table.insert(ply.data, "\n" .. (v.name or ""))
				end
				if BCESPHealth:GetInt() == 1 then
					table.insert(ply.data, "\nHP: " .. v:Health())
				end
				if BCESPDistance:GetInt() == 1 then
					local distance = v:GetPos():Distance(LocalPlayer():GetPos())
					if BCESPImperial:GetInt() == 0 then
						distance = math.Round(distance*0.01905) .. "m"
					else
						distance = math.Round((distance*0.75)*0.0277777778) .. "yds"
					end
					table.insert(ply.data, "\n" .. distance)
				end
				if BCESPFriends:GetInt() == 1 then
					ply.Friend = (v.Friend or false)
				end
				if BCESPVelocity:GetInt() == 1 then
					local velocity = v:GetVelocity():Length()
					if BCESPImperial:GetInt() == 0 then
						velocity = math.Round((((velocity*0.01905)*3600)/1000)) .. " KM/H" --Hopefully convert to KM/H.
					else
						velocity = math.Round((((velocity*0.75)*3600)/63360)) .. " M/H" --Hopefully convert to M/H.
					end
					if (v:GetVelocity():Length() > 0) then
						table.insert(ply.data, "\n" .. velocity)
					end
				end
				if BCESPVehicle:GetInt() == 1 then
					ply.Vehicle = v:InVehicle()
					local driving = v:GetVehicle()
					if BCESPVelocity:GetInt() == 1 and driving and ValidEntity(driving) then
						local velocity = driving:GetVelocity():Length()
						if BCESPImperial:GetInt() == 0 then
							velocity = math.Round((((velocity*0.01905)*3600)/1000)) .. " KM/H" --Hopefully convert to KM/H.
						else
							velocity = math.Round((((velocity*0.75)*3600)/63360)) .. " M/H" --Hopefully convert to M/H.
						end
						if (driving:GetVelocity():Length() > 0) then
							table.insert(ply.data, "\n" .. velocity)
						end
					end
				end
				if BCESPMoney:GetInt() == 1 then
					table.insert(ply.data, "\n$" .. (v.Money or ""))
				end
				if BCESPWeapon:GetInt() == 1 then
					table.insert(ply.data, "\n" .. v:GetActiveWeapon():GetPrintName())
				end
				if BCESPAdmin:GetInt() == 1 then
					table.insert(ply.data, "\n" .. (v.Rank or ""))
				end
				ply.HitPos = v:GetEyeTrace().HitPos:ToScreen()
				ply.HitPosV = v:GetEyeTrace().HitPos
				ply.HPosV = GetBone(v, "ValveBiped.Bip01_Head1")
				if BCESPLine:GetInt() == 1 then
					local dlight = DynamicLight(v:EntIndex())
					if (dlight) then
						dlight.Pos = v:GetEyeTrace().HitPos
						dlight.r = 255
						dlight.g = 0
						dlight.b = 0
						dlight.Brightness = 7.5
						dlight.Size = 20
						dlight.Decay = 20 * 5
						dlight.DieTime = CurTime() + 1
					end
				end
				ply.Visible = Visible(v)
				if BCESPTTT:GetInt() == 1 then
					if table.HasValue(TWeps, v:GetActiveWeapon():GetClass()) then
						TData[v] = {["lastused"] = CurTime(), ["class"] = v:GetActiveWeapon():GetClass()}
					end
					if TData[v] then --Data exists for potential traitor.
						table.insert(ply.data, "\nPotential Traitor\nUsed: " .. TData[v].class .. " (" .. math.Round((CurTime()-TData[v].lastused)) .. ")")
						if GAMEMODE.round_state == ROUND_POST then
							TData = {}
						end
					end
				end
				if BCESPIP:GetInt() == 1 and v.IP then
					table.insert(ply.data, "\n" .. (v.IP or ""))
				end
				if BCESPCountry:GetInt() == 1 and v.Country then
					table.insert(ply.data, "\n" .. (v.Country or ""))
				end
				ply.HPos = GetBone(v, "ValveBiped.Bip01_Head1"):ToScreen()
				ply.Pos = GetBone(v, BCESPBone:GetString()):ToScreen()
				ply.PPos = v:GetPos()
				ply.Ent = v
				if BCESPCS:GetInt() == 1 then
					ply.Name = v:Name()
					ply.Rank = GetAdmin(v)
				end
				ply.Col = team.GetColor(v:Team())
				table.insert(ptable, ply)
			end
			if BCESPEnts:GetInt() == 1 and ValidEntity(v) and table.HasValue(string.Explode(" ", BCESPEntities:GetString()), v:GetClass()) then
				local EntTable = {}
				EntTable.Pos = v:GetPos():ToScreen()
				EntTable.Class = v:GetClass()
				local distance = v:GetPos():Distance(LocalPlayer():GetPos())
				if BCESPImperial:GetInt() == 0 then
					distance = math.Round(distance*0.01905) .. "m"
				else
					distance = math.Round((distance*0.75)*0.0277777778) .. "yds"
				end
				EntTable.Distance = distance
				table.insert(etable, EntTable)
				if BCESPLights:GetInt() == 1 then
					local dlight = DynamicLight(v:EntIndex())
					if (dlight) then
						dlight.Pos = v:GetPos()
						dlight.r = 255
						dlight.g = 255
						dlight.b = 255
						dlight.Brightness = 10
						dlight.Size = 40
						dlight.Decay = 40 * 5
						dlight.DieTime = CurTime() + 1
					end
				end
			end
		end
	end
end)

hook.Add("HUDPaint", "BCESP", function()
	if BCESPToggle:GetInt() == 1 then
		if BCESPPlayers:GetInt() == 1 then
			local Vis = 0
			for k, v in pairs(ptable) do
				draw.DrawText(string.Implode("", v.data), BCESPFont:GetString(), v.Pos.x+1, v.Pos.y+1, Color(0,0,0,255),0)
				draw.DrawText(string.Implode("", v.data), BCESPFont:GetString(), v.Pos.x, v.Pos.y, Color(255,255,255,255),0)
				if BCESPHCircle:GetInt() == 1 and (not v.Vehicle) and (not v.Friend) then
					draw.RoundedBox(1, v.HPos.x, v.HPos.y, 5, 5, Color(v.Col.r,v.Col.g,v.Col.b,255))
				end
				cam.Start3D(EyePos(), EyeAngles())
					if BCESPLine:GetInt() == 1 and v.Visible then
						render.SetMaterial(Material("cable/redlaser"))
						render.DrawBeam(v.HPosV, v.HitPosV, 2.5, 0, 0, Color(v.Col.r, v.Col.g, v.Col.b, 255))
					end
					if BCESPWH:GetInt() == 1 and (not v.Visible) and ValidEntity(v.Ent) then
						--[[render.SuppressEngineLighting(true)
						render.SetColorModulation(1, 1, 1)
						render.SetBlend(1)]]
						v.Ent:DrawModel()
					end
				cam.End3D()
				if BCESPLine:GetInt() == 1 and v.Visible then
					draw.DrawText((v.SubName or ""), BCESPFont:GetString(), v.HitPos.x, v.HitPos.y, Color(255,255,255,255),1)
				end
				if BCESPVehicle:GetInt() == 1 and v.Vehicle then
					local QuadTable = {}
					QuadTable.texture = surface.GetTextureID("gui/silkicons/car")
					QuadTable.color = Color(255, 255, 255, 255)
					QuadTable.x = v.HPos.x
					QuadTable.y = v.HPos.y
					QuadTable.w = 15
					QuadTable.h = 15
					draw.TexturedQuad(QuadTable)
				end
				if BCESPFriends:GetInt() == 1 and v.Friend and (not v.Vehicle) then
					local QuadTable = {}
					QuadTable.texture = surface.GetTextureID("gui/silkicons/emoticon_smile")
					QuadTable.color = Color(255, 255, 255, 255)
					QuadTable.x = v.HPos.x
					QuadTable.y = v.HPos.y
					QuadTable.w = 15
					QuadTable.h = 15
					draw.TexturedQuad(QuadTable)
				end
				if BCESPVehicle:GetInt() == 1 then
					if LocalPlayer():InVehicle() then
						local velocity = LocalPlayer():GetVehicle():GetVelocity():Length()
						if BCESPImperial:GetInt() == 0 then
							velocity = math.Round((((velocity*0.01905)*3600)/1000)) .. " KM/H" --Hopefully convert to KM/H.
						else
							velocity = math.Round((((velocity*0.75)*3600)/63360)) .. " M/H" --Hopefully convert to M/H.
						end
						draw.WordBox(8, 0, ScrH()/2, velocity, BCESPFont:GetString(), Color(50,50,75,100), Color(255,255,255,255))
					end
				end
				if BCESPCS:GetInt() == 1 then
					if v.Visible then
						Vis = Vis + 1
						draw.DrawText(v.Name .. " (" .. v.Rank .. ")", BCESPFont:GetString(), Width, Vis*Height, Color(v.Col.r, v.Col.g, v.Col.b, 255),0)
					end
				end
			end
			draw.RoundedBox(6, Width-Width/2, Height, Width*35, (Vis*Height), Color(0, 0, 0, 75))
			draw.RoundedBox(6, Width-Width/2, Height, Width*35, (Vis*Height)/2, Color(255, 255, 255, 20))
		end
		if BCESPEnts:GetInt() == 1 then
			for k, v in pairs(etable) do
				draw.RoundedBox(1, v.Pos.x - 2, v.Pos.y - 3, 5, 5, Color(255,255,255,255))
				draw.DrawText(v.Class .. "\n" .. v.Distance, BCESPFont:GetString(), v.Pos.x+1, v.Pos.y+1, Color(0,0,0,255),0)
				draw.DrawText(v.Class .. "\n" .. v.Distance, BCESPFont:GetString(), v.Pos.x, v.Pos.y, Color(255,255,255,255),0)
			end
		end
	end
end)

concommand.Add("bc_esp_remove", function()
	hook.Remove("HUDPaint", "BCESP")
	hook.Remove("Think", "BCESP")
end)

local function AddEntity(ply, cmd, args)
	local entity = tostring(args[1])
	
	local entities = string.Explode(" ", BCESPEntities:GetString())
	local previousdata = string.Implode(" ", entities)
	
	RunConsoleCommand("bc_esp_entities", previousdata .. " " .. entity)
end
concommand.Add("bc_esp_addentity", AddEntity)

local function RemoveEntity(ply, cmd, args)
	local entity = tostring(args[1])
	
	local entities = string.Explode(" ", BCESPEntities:GetString())
	local previousdata = string.Implode(" ", entities)
	local newdata = string.Replace(previousdata, " " .. entity, "")
	
	RunConsoleCommand("bc_esp_entities", newdata)
end
concommand.Add("bc_esp_removeentity", RemoveEntity)

local function BCESPOptions()
	local BCESPFrame = vgui.Create("DFrame")
	BCESPFrame:SetSize(200,600)
	BCESPFrame:Center()
	BCESPFrame:SetTitle("BCESP Options Menu")
	BCESPFrame:MakePopup()
	
	local DermaList = vgui.Create("DPanelList", BCESPFrame)
	DermaList:SetPos(15,30)
	DermaList:SetSize(170, 560)
	DermaList:SetSpacing(5)
	DermaList:EnableHorizontal(false)
	DermaList:EnableVerticalScrollbar(true)
	
	local BCESPActivate = vgui.Create("DCheckBoxLabel")
	BCESPActivate:SetText("ESP Activate")
	BCESPActivate:SetConVar("bc_esp")
	DermaList:AddItem(BCESPActivate)
	
	local BCESPPlayers = vgui.Create("DCheckBoxLabel")
	BCESPPlayers:SetText("Show players")
	BCESPPlayers:SetConVar("bc_esp_players")
	DermaList:AddItem(BCESPPlayers)
	
	local BCESPNames = vgui.Create("DCheckBoxLabel")
	BCESPNames:SetText("Show player names")
	BCESPNames:SetConVar("bc_esp_name")
	DermaList:AddItem(BCESPNames)
	
	local BCESPHealth = vgui.Create("DCheckBoxLabel")
	BCESPHealth:SetText("Show player health")
	BCESPHealth:SetConVar("bc_esp_health")
	DermaList:AddItem(BCESPHealth)
	
	local BCESPRank = vgui.Create("DCheckBoxLabel")
	BCESPRank:SetText("Show player rank")
	BCESPRank:SetConVar("bc_esp_admin")
	DermaList:AddItem(BCESPRank)
	
	local BCESPWeapon = vgui.Create("DCheckBoxLabel")
	BCESPWeapon:SetText("Show player weapon")
	BCESPWeapon:SetConVar("bc_esp_weapon")
	DermaList:AddItem(BCESPWeapon)
	
	local BCESPDistance = vgui.Create("DCheckBoxLabel")
	BCESPDistance:SetText("Show player distance")
	BCESPDistance:SetConVar("bc_esp_distance")
	DermaList:AddItem(BCESPDistance)
	
	local BCESPVelocity = vgui.Create("DCheckBoxLabel")
	BCESPVelocity:SetText("Show player velocity")
	BCESPVelocity:SetConVar("bc_esp_velocity")
	DermaList:AddItem(BCESPVelocity)
	
	local BCESPImp = vgui.Create("DCheckBoxLabel")
	BCESPImp:SetText("Use imperial units")
	BCESPImp:SetConVar("bc_esp_imperial")
	DermaList:AddItem(BCESPImp)
	
	local BCESPMoney = vgui.Create("DCheckBoxLabel")
	BCESPMoney:SetText("Show player money (DarkRP)")
	BCESPMoney:SetConVar("bc_esp_money")
	DermaList:AddItem(BCESPMoney)
	
	local BCESPHCircle = vgui.Create("DCheckBoxLabel")
	BCESPHCircle:SetText("Show player headpos circle")
	BCESPHCircle:SetConVar("bc_esp_hcircle")
	DermaList:AddItem(BCESPHCircle)
	
	local BCESPAim = vgui.Create("DCheckBoxLabel")
	BCESPAim:SetText("Show player aim line")
	BCESPAim:SetConVar("bc_esp_line")
	DermaList:AddItem(BCESPAim)
	
	local BCESPWall = vgui.Create("DCheckBoxLabel")
	BCESPWall:SetText("Enable player wallhack")
	BCESPWall:SetConVar("bc_esp_wh")
	DermaList:AddItem(BCESPWall)
	
	local BCESPTerror = vgui.Create("DCheckBoxLabel")
	BCESPTerror:SetText("Enable terrorist town hack")
	BCESPTerror:SetConVar("bc_esp_ttt")
	DermaList:AddItem(BCESPTerror)
	
	local BCESPCanSee = vgui.Create("DCheckBoxLabel")
	BCESPCanSee:SetText("Enable who can see me")
	BCESPCanSee:SetConVar("bc_esp_cs")
	DermaList:AddItem(BCESPCanSee)

	local BCESPFriend = vgui.Create("DCheckBoxLabel")
	BCESPFriend:SetText("Enable friends")
	BCESPFriend:SetConVar("bc_esp_friends")
	DermaList:AddItem(BCESPFriend)

	local BCESPIPS = vgui.Create("DCheckBoxLabel")
	BCESPIPS:SetText("Enable IPs")
	BCESPIPS:SetConVar("bc_esp_ip")
	DermaList:AddItem(BCESPIPS)

	local BCESPCoun = vgui.Create("DCheckBoxLabel")
	BCESPCoun:SetText("Show country")
	BCESPCoun:SetConVar("bc_esp_country")
	DermaList:AddItem(BCESPCoun)

	local BCESPTick = vgui.Create("DCheckBoxLabel")
	BCESPTick:SetText("Enable Ticker Optimization")
	BCESPTick:SetConVar("bc_esp_ticker")
	DermaList:AddItem(BCESPTick)
	
	local BCESPLights = vgui.Create("DCheckBoxLabel")
	BCESPLights:SetText("Enable lights")
	BCESPLights:SetConVar("bc_esp_lights")
	DermaList:AddItem(BCESPLights)
	
	local BCESPEnt = vgui.Create("DCheckBoxLabel")
	BCESPEnt:SetText("Show entities")
	BCESPEnt:SetConVar("bc_esp_ents")
	DermaList:AddItem(BCESPEnt)
	
	local BCESPVehicles = vgui.Create("DCheckBoxLabel")
	BCESPVehicles:SetText("Show vehicles")
	BCESPVehicles:SetConVar("bc_esp_vehicle")
	DermaList:AddItem(BCESPVehicles)
	
	local BCESPList1 = vgui.Create("DListView")
	BCESPList1:SetSize(170,100)
	BCESPList1:SetMultiSelect(false)
	BCESPList1:AddColumn("Show the following entities")
	for k,v in pairs(string.Explode(" ", BCESPEntities:GetString())) do
		BCESPList1:AddLine(v)
	end
	BCESPList1.OnClickLine = function(parent, line, isselected)
		LocalPlayer():ConCommand("bc_esp_removeentity " .. line:GetValue(1))
	end
	DermaList:AddItem(BCESPList1)
	
	local BCESPButton1 = vgui.Create("DButton")
	BCESPButton1:SetText("Add Entity")
	BCESPButton1.DoClick = function(button)
		Derma_StringRequest("Add an entity to BCESP", "Please use the entity class name.", "e.g. money_printer", function(text) LocalPlayer():ConCommand("bc_esp_addentity " .. text) end)
	end
	DermaList:AddItem(BCESPButton1)
	
	local BCESPButton2 = vgui.Create("DButton")
	BCESPButton2:SetText("Add Entity you are looking at")
	BCESPButton2.DoClick = function(button)
		LocalPlayer():ConCommand("bc_esp_addentity " .. LocalPlayer():GetEyeTraceNoCursor().Entity:GetClass())
	end
	DermaList:AddItem(BCESPButton2)
	
	local BCESPInfo = vgui.Create("DLabel")
	BCESPInfo:SetText("BCESP Version 3.1\nEusion (STEAM_0:0:20450406)")
	BCESPInfo:SizeToContents()
	DermaList:AddItem(BCESPInfo)
end
concommand.Add("bc_esp_options", BCESPOptions)