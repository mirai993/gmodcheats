--[[
	MOD/lua/rand0m.lua [#9612 (#9901), 2252894515, UID:2748654082]
	hrst | STEAM_0:1:89973919 <2.51.85.155:27005> | [12.06.14 04:40:09PM]
	===BadFile===
]]

----
 
--Todo: Finish menu, add more functions to the script.
 
local concommand = concommand
local cvars = cvars
local debug = debug
local ents = ents
local file = file
local hook = hook
local math = math
local spawnmenu = spawnmenu
local string = string
local surface = surface
local table = table
local timer = timer
local util = util
local vgui = vgui
 
local Angle = Angle
local CreateClientConVar = CreateClientConVar
local CurTime = CurTime
local ErrorNoHalt = ErrorNoHalt
local FrameTime = FrameTime
local GetConVarString = GetConVarString
local GetViewEntity = GetViewEntity
local include = include
local ipairs = ipairs
local LocalPlayer = LocalPlayer
local pairs = pairs
local pcall = pcall
local print = print
local RunConsoleCommand = RunConsoleCommand
local ScrH = ScrH
local ScrW = ScrW
local tonumber = tonumber
local type = type
local unpack = unpack
local ValidEntity = IsValid
local Vector = Vector
 
----
 
local function message()
chat.AddText( Color( 150, 255, 0, 255 ), "[C] Scripts loaded...")
print("[C] Coded by Crackerdown2HD")
surface.PlaySound("buttons/button4.wav")
end
message()
 
----
 
concommand.Add( "c_reloadscripts", function() include( "cscripts.lua" ) end )
 
----
 
function watermark()
        for k,v in pairs ( player.GetAll() ) do
                                draw.SimpleText("[C]", "DermaDefault", ScrW() / 8 - 225, ScrH() - 985, Color(150,255,0,255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
                                end
                        end
hook.Add( "HUDPaint", "watermark", watermark )
watermark()
               
----
 
local toggle = false
local function c_eyes()
if toggle then
        for k,v in pairs ( player.GetAll() ) do
                render.SetMaterial( Material('trails/smoke'))
                        if v != LocalPlayer() then
                                render.DrawBeam( v:GetShootPos(), v:GetEyeTrace().HitPos, 3, 0, 3, Color( 150, 255, 0, 150 ) )
                        end
                end
        end
end
concommand.Add("c_eyes", function()
        if toggle then toggle = false surface.PlaySound("items/nvg_off.wav") chat.AddText( Color( 150, 255, 0, 255 ), "[C] Eyes Toggled" )
        elseif !toggle then toggle = true surface.PlaySound("buttons/button9.wav") chat.AddText( Color( 150, 255, 0, 255 ), "[C] Eyes Toggled" )
        end
end)
hook.Add( "PostPlayerDraw", "c_eyes", c_eyes )
 
 
----
 
local toggle = false
local function c_heads()
if toggle then
        for k,v in pairs ( player.GetAll() ) do
                render.SetMaterial( Material('trails/smoke'))
                        if v != LocalPlayer() then
                                 render.DrawBeam( v:GetShootPos(), v:GetShootPos() + Vector(0,0,1000), 3, 0, 3, Color( 150, 255, 0, 150 ) )
                        end
                end
        end
end
concommand.Add("c_heads", function()
        if toggle then toggle = false surface.PlaySound("items/nvg_off.wav") chat.AddText( Color( 150, 255, 0, 255 ), "[C] Heads Toggled" )
        elseif !toggle then toggle = true surface.PlaySound("buttons/button9.wav") chat.AddText( Color( 150, 255, 0, 255 ), "[C] Heads Toggled" )
        end
end)
hook.Add( "PostPlayerDraw", "c_heads", c_heads )
 
 
----
 
local toggle = false
local function c_feet()
if toggle then
        for k,v in pairs ( player.GetAll() ) do
                render.SetMaterial( Material('trails/smoke'))
                        if v != LocalPlayer() then
                                 render.DrawBeam( v:GetShootPos(), v:GetShootPos() + Vector(0,0,-1000), 3, 0, 3, Color( 150, 255, 0, 150 ) )
                        end
                end
        end
end
concommand.Add("c_feet", function()
        if toggle then toggle = false surface.PlaySound("items/nvg_off.wav") chat.AddText( Color( 150, 255, 0, 255 ), "[C] Feet Toggled" )
        elseif !toggle then toggle = true surface.PlaySound("buttons/button9.wav") chat.AddText( Color( 150, 255, 0, 255 ), "[C] Feet Toggled" )
        end
end)
hook.Add( "PostPlayerDraw", "c_feet", c_feet )
 
----
 
local toggle = false
local function c_esp()
if toggle then
        for k,v in pairs ( player.GetAll() ) do
        if v != LocalPlayer() then
                local pos = (v:GetShootPos() + Vector( 0, 0, 20 ) ) :ToScreen()
                local name = v:Nick()
                local health = v:Health()              
                local rank = v:GetUserGroup()
                local maxhealth = 100
                 if health <= 100 then
                local healthratio = math.Round(health*10/maxhealth)/10
                        draw.DrawText( name, "DermaDefault", pos.x +10, pos.y -14, Color( 150, 255, 0, 255 ), TEXT_ALIGN_LEFT )
                        surface.SetDrawColor( 255, 108 , 186, 255 )
                        surface.DrawRect( pos.x +10, pos.y +3, 39, 2 )
                        surface.SetDrawColor( 0, 255, 0, 255 )
                        surface.DrawRect( pos.x +10, pos.y +3, 39*healthratio, 2 )
                        if v:GetUserGroup() == "user" then
                        draw.RoundedBox( 6, pos.x -3, pos.y -14, 5, 5, Color( 150, 255, 0, 255 ) )
                        elseif
                        draw.RoundedBox( 6, pos.x -3, pos.y -14, 5, 5, Color( 255, 108, 186, 255 ) ) then
                                                        end
                                                end
                                        end
                                end
                        end
                end
        concommand.Add("c_esp", function()
        if toggle then toggle = false surface.PlaySound("buttons/combine_button_locked.wav") chat.AddText( Color( 150, 255, 0, 255 ), "[C] ESP Toggled" )
        elseif !toggle then toggle = true surface.PlaySound("buttons/button9.wav") chat.AddText( Color( 150, 255, 0, 255 ), "[C] ESP Toggled" )
        end
end)
hook.Add( "HUDPaint", "c_esp", c_esp )
 
----
 
local toggle = false
function c_bhop()
        if toggle then
        if input.IsKeyDown( KEY_SPACE ) then
        if LocalPlayer():IsOnGround() then
        if LocalPlayer():WaterLevel() then
                RunConsoleCommand("+Jump")
                        timer.Create("bhop",0.01, 0 ,function() RunConsoleCommand("-Jump") end)
                                end
                        end
                end
        end
end
concommand.Add("c_bhop", function()
        if toggle then toggle = false surface.PlaySound("items/nvg_off.wav") chat.AddText( Color( 155, 255, 0, 255 ), "[C] BHop Toggled" )
        elseif !toggle then toggle = true surface.PlaySound("buttons/button9.wav") chat.AddText( Color( 150, 255, 0, 255 ), "[C] BHop Toggled" )
        end
end)
hook.Add("Think", "c_bhop", c_bhop)
 
----
 
----
 
local function c_lerp()
        RunConsoleCommand("cl_interp","0")
        RunConsoleCommand("cl_updaterate","500000")
        RunConsoleCommand("physgun_dampingfactor","0.1")
        RunConsoleCommand("physgun_timetoarrive","0")
end
concommand.Add( "c_lerp", c_lerp )
 
----
 
--
 local function c(s)
LocalPlayer():ConCommand(s)
end
 
concommand.Add("RDM_BUTTON1", function()
c("gmod_toolmode button;button_model models/props/de_train/utility_truck.mdl;use gmod_tool")
timer.Simple(0.350, function() c("+attack2") end)
timer.Simple(0.450, function() c("-attack2") end)
timer.Simple(0.500, function() c("use weapon_physgun") end)
end)
 local function c(s)
LocalPlayer():ConCommand(s)
end
--
 
concommand.Add("crack_menu", function()
local DermaFrame = vgui.Create( "DFrame" )
DermaFrame:SetPos( ScrW()/2 - 350, ScrH()/2 - 350 )
DermaFrame:SetSize( 600, 600 )
DermaFrame:SetTitle( "Crackers Utility Script" )
DermaFrame:SetVisible( true )
DermaFrame:MakePopup()
DermaFrame.Paint = function()
        draw.RoundedBox( 8, 0, 0, DermaFrame:GetWide(), DermaFrame:GetTall(), Color( 0, 0, 0, 100 ) )
end
 
local DermaButton = vgui.Create( "DButton" )
DermaButton:SetParent( DermaFrame )
DermaButton:SetText( "ESP" )
DermaButton:SetPos( 10, 20 )
DermaButton:SetSize( 100, 50 )
DermaButton:SetColor( Color( 255, 108, 186 ) )
DermaButton.DoClick = function()
        RunConsoleCommand( "c_esp" )
end
 
 
local DermaButton = vgui.Create( "DButton" )
DermaButton:SetParent( DermaFrame )
DermaButton:SetText( "Bhop" )
DermaButton:SetPos( 10, 120 )
DermaButton:SetSize( 100, 50 )
DermaButton:SetColor( Color( 255, 108, 186 ) )
DermaButton.DoClick = function()
        RunConsoleCommand( "c_bhop" )
end
 
local DermaButton = vgui.Create( "DButton" )
DermaButton:SetParent( DermaFrame )
DermaButton:SetText( "Reload" )
DermaButton:SetPos( 530, 570 )
DermaButton:SetSize( 60, 25 )
DermaButton:SetColor( Color( 0, 0, 0 ) )
DermaButton.DoClick = function()
        RunConsoleCommand( "c_reloadscripts" )
end
 
local DermaButton = vgui.Create( "DButton" )
DermaButton:SetParent( DermaFrame )
DermaButton:SetText( "Eyes" )
DermaButton:SetPos( 10, 220 )
DermaButton:SetSize( 100, 50 )
DermaButton:SetColor( Color( 255, 108, 186 ) )
DermaButton.DoClick = function()
        RunConsoleCommand( "c_eyes" )
end
 
 
local DermaButton = vgui.Create( "DButton" )
DermaButton:SetParent( DermaFrame )
DermaButton:SetText( "Heads" )
DermaButton:SetPos( 10, 320 )
DermaButton:SetSize( 100, 50 )
DermaButton:SetColor( Color( 255, 108, 186 ) )
DermaButton.DoClick = function()
        RunConsoleCommand( "c_heads" )
end
 
 
local DermaButton = vgui.Create( "DButton" )
DermaButton:SetParent( DermaFrame )
DermaButton:SetText( "Feet" )
DermaButton:SetPos( 10, 420 )
DermaButton:SetSize( 100, 50 )
DermaButton:SetColor( Color( 255, 108, 186 ) )
DermaButton.DoClick = function()
        RunConsoleCommand( "c_feet" )
end
 
 
end)