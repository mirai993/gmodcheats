local cathack = {};
cathack.Version = 0.02;

local aim_key = KEY_T
local trig_key = KEY_L

local esp = CreateClientConVar("cat_esp", 1, true, false)
local triggerbot = CreateClientConVar("cat_triggerbot", 1, true, false)
local watermark = CreateClientConVar("cat_watermark", 1, true, false)
local esp_ents = CreateClientConVar("cat_esp_ents", 1, true, false)
local esp_dist = CreateClientConVar("cat_esp_dist", 2500, true, false)
local aimbot = CreateClientConVar("cat_aimbot", 1, true, false)
local aimbone = CreateClientConVar("cat_aimbot_bone", 1, true, false)
local aimfov = CreateClientConVar("cat_aimbot_fov", 5, true, false)
local bhop = CreateClientConVar("cat_bunnyhop", 0, true, false)

cathack.Bones = {
	head = "ValveBiped.Bip01_Head1";
	spine = "ValveBiped.Bip01_Spine";
}

cathack.Bone = cathack.Bones[aimbone:GetString()]

function cathack.CloneTable( src ) --cbot
	local new = {}
	for k, v in pairs( src ) do
		local newf = rawget(src, k);
		if( type( newf ) == "table" and v ~= src ) then
			new[k] = cathack.CloneTable( v );
		else
			new[k] = newf;
		end
	end

	return new;
end

function cathack.Target(v)
	if v:IsPlayer() then
		if (cathack.cVisible(v) and v:Alive() and (v:Health() > 0)) then
			if (v ~= LocalPlayer()) and LocalPlayer():Team() ~= TEAM_SPECTATOR then
				return true
			end
		end
	end
end

cathack.table 			= cathack.CloneTable( table );
cathack.hook 			= cathack.CloneTable( hook );
cathack.math 			= cathack.CloneTable( math );
cathack.surface 		= cathack.CloneTable( surface );
cathack.draw			= cathack.CloneTable( draw );

local table 			= cathack.table;
local hook 				= cathack.hook;
local math 				= cathack.math;
local surface 			= cathack.surface;
local draw				= cathack.draw;

local entities = {
	"money_printer",
	"spawned_money"
}

surface.CreateFont("Trebuchet19", {font="TabLarge", size=13, weight=700})

hook.Add("HUDPaint", "catWATERMARK", function()
	if GetConVarNumber("cat_watermark") == 1 then
		draw.SimpleTextOutlined("Syntox Hack v"..cathack.Version, "Trebuchet19", 10, 10, Color(159, 0, 203, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT, 1, Color(0,0,0,255))
	end
end)

function cathack.ENTS()
	for k,v in pairs(ents.GetAll()) do print(v:GetClass()) end
end
concommand.Add("cat_print", cathack.ENTS)

function cathack.ESP(ent)
	if ent:IsPlayer() and ent:Alive() == true && ent:Health() ~= 0 && ent:Health() >= 0 && ent ~= LocalPlayer() && LocalPlayer():Alive() && LocalPlayer():Team() ~= TEAM_SPECTATOR then
		return true
	else
		return false
	end
end

function cathack.Shoot()
	RunConsoleCommand("+attack")
	timer.Simple(0.1, function() RunConsoleCommand("-attack") end)
end

function cathack.InFov(ent) --thx hypey
	for k,v in pairs(ents.FindInCone(LocalPlayer():GetShootPos(), LocalPlayer():GetAimVector(), 3000, GetConVarNumber("cat_aimbot_fov")))  do
		if(v:IsPlayer() && ent == v) then
			return true
		else
			return false
		end
	end
end

function cathack.cVisible(ent)
	local bone = ent:LookupBone(cathack.Bones[aimbone:GetString()])
	if bone ~= nil then
	local tracer = {}
	tracer.start = LocalPlayer():GetShootPos()
	tracer.endpos = ent:GetBonePosition(bone)
	tracer.filter = {LocalPlayer(), ent}
	tracer.mask = MASK_SHOT
	local trace = util.TraceLine(tracer)
	if trace.Fraction >= 1 then return true else return false end
	else return false end
end

local ESP = cathack.ESP;
local Shoot = cathack.Shoot;
local InFov = cathack.InFov;
local cVisible = cathack.cVisible;

hook.Add("HUDPaint", "catESP", function()
	for k,v in pairs(ents.GetAll()) do
		if GetConVarNumber("cat_esp") == 1 then
			if(v ~= LocalPlayer() and ESP(v) and v:GetPos():Distance(LocalPlayer():GetPos()) < (GetConVarNumber("cat_esp_dist"))) then
				local ESP = (v:EyePos()):ToScreen()
				draw.SimpleTextOutlined(v:Name(), "Trebuchet19", ESP.x, ESP.y -46, team.GetColor(v:Team()), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, Color(0,0,0,255))
				draw.SimpleTextOutlined(v:Health().."H - "..v:Armor().."A", "Trebuchet19", ESP.x, ESP.y -34, Color(255, 255, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, Color(0,0,0,255))
			end
		end
	
		if (IsValid(v) and (GetConVarNumber("cat_esp_ents") == 1) and (v:GetPos():Distance(LocalPlayer():GetPos()) < (GetConVarNumber("cat_esp_dist"))))then
			for k,e in pairs(entities) do
				if e == v:GetClass() then
					local ESP = (v:EyePos()):ToScreen()
					draw.SimpleTextOutlined(v:GetClass(), "Trebuchet19", ESP.x, ESP.y - 46, Color(255,0,0,255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, Color(0,0,0,255))
				end
			end
		end
	end
end)

hook.Add("Think", "catterbot", function()
	-- triggerbot
	if(GetConVarNumber("cat_triggerbot") == 1 && input.IsKeyDown(trig_key)) then
		local pos = LocalPlayer():GetShootPos()
		local ang = LocalPlayer():GetAimVector()
		local tracedata = {}
		tracedata.start = pos
		tracedata.endpos = pos+(ang*9999999999999)
		local trace = util.TraceLine(tracedata)
		if(trace.HitNonWorld) then
			target = trace.Entity
			if(target:IsPlayer()) then
				Shoot()
			end
		end
	end
	
	-- bhop
	if ((GetConVarNumber("cat_bunnyhop") == 1) and input.IsKeyDown(KEY_SPACE)) then 
		if(LocalPlayer():OnGround()) then
			LocalPlayer():ConCommand("+jump") 
			timer.Simple(.01, function()  
				LocalPlayer():ConCommand("-jump") 
			end) 
		end 
	end
	-- aimbot
	if GetConVarNumber("cat_aimbot") == 1 && input.IsKeyDown(aim_key) then
		for k,v in pairs(player.GetAll()) do
			local bone = cathack.Bones[aimbone:GetString()]
			if cVisible(v) and LocalPlayer():Alive() and v:Alive() and v ~= LocalPlayer() and v:Team() ~= TEAM_SPECTATOR and LocalPlayer():Team() ~= TEAM_SPECTATOR then
				local head = v:LookupBone(bone)
				local fov = GetConVarNumber("cat_aimbot_fov")
				if fov == 0 then
					local headpos,targetheadang = v:GetBonePosition(head)
					LocalPlayer():SetEyeAngles((headpos - LocalPlayer():GetShootPos()):Angle())
				else
					local lpang = LocalPlayer():GetAngles();
					local ang = (v:GetPos() - LocalPlayer():GetPos()):Angle();
					local ady = math.abs(math.NormalizeAngle(lpang.y - ang.y))
					local adp = math.abs(math.NormalizeAngle(lpang.p - ang.p ))
					if not(ady > fov or adp > fov) then
						local headpos,targetheadang = v:GetBonePosition(head)
						LocalPlayer():SetEyeAngles((headpos - LocalPlayer():GetShootPos()):Angle())
					end
				end
			end
		end
	end
end)