--[[
	autoaim.lua
	Jesse Jackson | (STEAM_0:1:43732934)
	===DStream===
]]

// AutoAim by Benboost
if SERVER then return end

local ClAimSteam = CreateClientConVar("AC_Aim_IgnoreSteam",0,true,false)
local CL = LocalPlayer()
local wep = LocalPlayer():GetActiveWeapon()
local NoSpreadHere=false
if #file.Find("lua/includes/modules/gmcl_dec0.dll",true)>=1 then
NoSpreadHere=true

local MoveSpeed = 1

mysetupmove = function(objPl, move)
    if move then
        MoveSpeed = (move:GetVelocity():Length())/move:GetMaxSpeed()
    end
end

local ID_GAMETYPE = ID_GAMETYPE or -1
local GameTypes = {
    {check=function ()
        return string.find(GAMEMODE.Name,"Garry Theft Auto") ~= nil
    end,getcone=function (wep,cone)
        if type(wep.Base) == "string" then
            if wep.Base == "civilian_base" then
                local scale = cone
                if CL:KeyDown(IN_DUCK) then
        scale = math.Clamp(cone/1.5,0,10)
                elseif CL:KeyDown(IN_WALK) then
        scale = cone
                elseif (CL:KeyDown(IN_SPEED) or CL:KeyDown(IN_JUMP)) then
        scale = cone + (cone*2)
                elseif (CL:KeyDown(IN_FORWARD) or CL:KeyDown(IN_BACK) or CL:KeyDown(IN_MOVELEFT) or CL:KeyDown(IN_MOVERIGHT)) then
        scale = cone + (cone*1.5)
                end
                scale = scale + (wep:GetNWFloat("Recoil",0)/3)
                return Vector(scale,0,0)
            end
        end
        return Vector(cone,cone,cone)
    end},
    {check=function ()
        return type(TEAM_ZOMBIE) == "number" and type(TEAM_SURVIVORS) == "number" and string.find(GAMEMODE.Name,"Zombie Survival") ~= nil and type(NUM_WAVES) == "number"
    end,getcone=function (wep,cone)
        if wep:GetNetworkedBool("Ironsights",false) then
            if CL:Crouching() then
                return wep.ConeIronCrouching or cone
            end
            return wep.ConeIron or cone
        elseif 25 < LocalPlayer():GetVelocity():Length() then
            return wep.ConeMoving or cone
        elseif CL:Crouching() then
            return wep.ConeCrouching or cone
        end
        return cone
    end},
    {check=function ()
        return type(TEAM_ZOMBIE) == "number" and type(TEAM_SURVIVORS) == "number" and string.find(GAMEMODE.Name,"Zombie Survival") ~= nil
    end,getcone=function (wep,cone)
        if CL:GetVelocity():Length() > 25 then
            return wep.ConeMoving or cone
        elseif CL:Crouching() then
            return wep.ConeCrouching or cone
        end
        return cone
    end},
    {check=function ()
        return type(gamemode.Get("ZombRP")) == "table" or type(gamemode.Get("DarkRP")) == "table"
    end,getcone=function (wep, cone)
        if type(wep.Base) == "string" and (wep.Base == "ls_snip_base" or wep.Base == "ls_snip_silencebase") then
            if CL:GetNWInt( "ScopeLevel", 0 ) > 0 then 
                print("using scopecone")
                return wep.Primary.Cone
            end
            print("using unscoped cone")
            return wep.Primary.UnscopedCone
        end
        if type(wep.GetIronsights) == "function" and wep:GetIronsights() then
            return cone
        end
        return cone + .05
    end},
    {check=function ()
        return (GAMEMODE.Data == "falloutmod" and type(Music) == "table")
    end,getcone=function(wep,cone)
        if wep.Primary then
            local LastShootTime = wep.Weapon:GetNetworkedFloat( "LastShootTime", 0 ) 
            local lastshootmod = math.Clamp(wep.LastFireMax + 1 - math.Clamp( (CurTime() - LastShootTime) * wep.LastFireModifier, 0.0, wep.LastFireMax ), 1.0,wep.LastFireMaxMod) 
            local accuracy = wep.Primary.Accuracy
            if CL:IsMoving() then accuracy = accuracy * wep.MoveModifier end
            if wep.Weapon:GetNetworkedBool( "Ironsights", false ) then accuracy = accuracy * 0.75 end
            accuracy = accuracy * ((16-(Skills.Marksman or 1))/11)
            if CL:KeyDown(IN_DUCK) then
                return accuracy*wep.CrouchModifier*lastshootmod
            else
                return accuracy*lastshootmod
            end
        end
    end}
}
Check = function()
    for k, v in pairs(GameTypes) do
        if v.check() then
            ID_GAMETYPE = k
            break
        end
    end
end



local tblNormalConeWepBases = {
    ["weapon_cs_base"] = true
}
local function GetCone(wep)
    local cone = wep.Cone
    if not cone and type(wep.Primary) == "table" and type(wep.Primary.Cone) == "number" then
        cone = wep.Primary.Cone
    end
    if wep:GetClass() == "ose_turretcontroller" then return 0 end
    return cone or 0
end

local currentseed, cmd2, seed = currentseed or 0, 0, 0
local wep, vecCone, valCone
PredictSpread = function(cmd,aimAngle)
    cmd2, seed = hl2_ucmd_getpr3diction(cmd)
    if cmd2 ~= 0 then
        currentseed = seed
    end
    wep = LocalPlayer():GetActiveWeapon()
    vecCone = Vector(0,0,0)
    if wep and wep:IsValid() and type(wep.Initialize) == "function" then
        valCone = GetCone(wep)
        if( tonumber( valCone ) ) then
        vecCone = Vector( -valCone, -valCone, -valCone )
        elseif( type( valCone ) == "Vector" ) then
        vecCone = -1 * valCone
        end
    end

	if wep:GetClass() == "weapon_smg1" then
	vecCone = Vector(-0.04362,-0.04362,-0.04362)
	elseif wep:GetClass() == "weapon_pistol" then
	vecCone = Vector( -0.0100, -0.0100, -0.0100 )
	elseif wep:GetClass() == "weapon_ar2" then
	vecCone = Vector( -0.02618, -0.02618, -0.02618 )
	elseif wep:GetClass() == "weapon_shotgun" then
	vecCone = Vector( -0.08716, -0.08716, -0.08716 )
	elseif wep:GetClass() == "weapon_iceaxe" then
	vecCone = Vector(-0.15,-0.15,-0.15)
	elseif wep:GetClass() == "weapon_sniper" then
	vecCone = Vector(-0.1,-0.1,0)
	elseif wep:GetClass() == "weapon_hmg1" then
	vecCone = Vector(-0.07,-0.07,-0.07)
	elseif wep:GetClass() == "weapon_smg2" then
	vecCone = Vector(-0.07,-0.07,-0.07)
	elseif wep:GetClass() == "weapon_ar1" then
	vecCone = Vector(-0.07,-0.07,0)
	elseif wep:GetClass() == "weapon_oicw" then
	if wep.Zoom == 0 then
	vecCone = Vector(-0.07,-0.07,-0.07)
	else
	vecCone = Vector(-0.01,-0.01,-0.01)
	end
	elseif wep:GetClass() == "weapon_bsmg1" then
	vecCone = Vector(-0.04362,-0.04362,-0.04362)
	elseif wep:GetClass() == "mill_deagle" then
	vecCone = Vector(-0.5,-0.5,-0.5)
	elseif wep:GetClass() == "weapon_para" then
	vecCone = Vector(-0.05,-0.05,0)
	end
	cne = -vecCone.x
    return hl2_manipshot(currentseed or 0, aimAngle:Forward(), vecCone):Angle()
end
end
local AC = {}

local concommand = concommand
local cvars = cvars
local debug = debug
local ents = ents
local file = file
local hook = hook
local math = math
local spawnmenu = spawnmenu
local string = string
local surface = surface
local table = table
local timer = timer
local util = util
local vgui = vgui

local Angle = Angle
local CreateClientConVar = CreateClientConVar
local CurTime = CurTime
local ErrorNoHalt = ErrorNoHalt
local FrameTime = FrameTime
local GetConVarString = GetConVarString
local GetViewEntity = GetViewEntity
local include = include
local ipairs = ipairs
local LocalPlayer = LocalPlayer
local pairs = pairs
local pcall = pcall
local print = print
local RunConsoleCommand = RunConsoleCommand
local ScrH = ScrH
local ScrW = ScrW
local tonumber = tonumber
local type = type
local unpack = unpack
local ValidEntity = ValidEntity
local Vector = Vector
local CCADD = concommand.Add

do
	local hooks = {}
	local created = {}
	local function CallHook(self, name, args)
		if !hooks[name] then return end
		for funcName, _ in pairs(hooks[name]) do
			local func = self[funcName]
			if func then
				local ok, err = pcall(func, self, unpack(args or {}))
				if !ok then
					ErrorNoHalt(err .. "\n")
				elseif err then
					return err
				end
			end
		end
	end
	local function RandomName()
		local random = ""
		for i = 1, math.random(4, 10) do
			local c = math.random(65, 116)
			if c >= 91 && c <= 96 then c = c + 6 end
			random = random .. string.char(c)
		end
		return random
	end
	local function AddHook(self, name, funcName)
		// If we haven't got a hook for this yet, make one with a random name and store it.
		// This is so anti-cheats can't detect by hook name, and so we can remove them later.
		if !created[name] then
			local random = RandomName()
			hook.Add(name, random, function(...) return CallHook(self, name, {...}) end)
			created[name] = random
		end
		
		hooks[name] = hooks[name] or {}
		hooks[name][funcName] = true
	end
	
	local cvarhooks = {}
	local function GetCallbackTable(convar)
		local callbacks = cvars.GetConVarCallbacks(convar)
		if !callbacks then
			cvars.AddChangeCallback(convar, function() end)
			callbacks = cvars.GetConVarCallbacks(convar)
		end
		return callbacks
	end
			
	local function AddCVarHook(self, convar, funcName, ...)
		local hookName = "CVar_" .. convar
		if !cvarhooks[convar] then
			local random = RandomName()
			
			local callbacks = GetCallbackTable(convar)
			callbacks[random] = function(...)
				CallHook(self, hookName, {...})
			end
			
			cvarhooks[convar] = random
		end
		AddHook(self, hookName, funcName)
	end
	
	// Don't let other scripts remove our hooks.
	local oldRemove = hook.Remove
	function hook.Remove(name, unique)
		if created[name] == unique then return end
		oldRemove(name, unique)
	end
	
	// Removes all hooks, useful if reloading the script.
	local function RemoveHooks()
		for hookName, unique in pairs(created) do
			oldRemove(hookName, unique)
		end
		for convar, unique in pairs(cvarhooks) do
			local callbacks = GetCallbackTable(convar)
			callbacks[unique] = nil
		end
	end
	
	// Add copies the script can access.
	AC.AddHook = AddHook
	AC.AddCVarHook = AddCVarHook
	AC.CallHook = CallHook
	AC.RemoveHooks = RemoveHooks
end

CCADD("AC_reload", function()
	AC:CallHook("Shutdown")
	print("Removing hooks...")
	AC:RemoveHooks()
	
	local info = debug.getinfo(1, "S")
	if info && info.short_src then
		print("Reloading (" .. info.short_src .. ")...")
		include(info.short_src)
	else
		print("Cannot find AutoAim file, reload manually.")
	end
end)
print("AutoAim loaded.")

// ##################################################
// MetaTables
// ##################################################

local function GetMeta(name)
	return table.Copy(_R[name] or {})
end

local AngM = GetMeta("Angle")
local CmdM = GetMeta("CUserCmd")
local EntM = GetMeta("Entity")
local PlyM = GetMeta("Player")
local VecM = GetMeta("Vector")

// ##################################################
// Settings
// ##################################################

do
	local settings = {}
	local function SettingVar(self, name)
		return (self.SettingPrefix or "") .. string.lower(name)
	end
	
	local function RandomName()
		local random = ""
		for i = 1, math.random(4, 10) do
			local c = math.random(65, 116)
			if c >= 91 && c <= 96 then c = c + 6 end
			random = random .. string.char(c)
		end
		return random
	end
	
	local function SetSetting(name, _, new)
		if !settings[name] then return end
		local info = settings[name]
		
		if info.Type == "number" then
			new = tonumber(new)
		elseif info.Type == "boolean" then
			new = (tonumber(new) or 0) > 0
		end
		
		info.Value = new
	end
	
	local function CreateSetting(self, name, desc, default, misc)
		local cvar = SettingVar(self, name)
		local info = {Name = name, Desc = desc, CVar = cvar, Type = type(default), Value = default}
		
		for k, v in pairs(misc or {}) do
			if !info[k] then info[k] = v end
		end
		
		// Convert default from boolean to number.
		if type(default) == "boolean" then
			default = default and 1 or 0
		end
		
		if !settings[cvar] then
			local tab = cvars.GetConVarCallbacks(cvar)
			if !tab then
				cvars.AddChangeCallback(cvar, function() end)
				tab = cvars.GetConVarCallbacks(cvar)
			end
			
			while true do
				local name = RandomName()
				if !tab[name] then
					tab[name] = SetSetting
					info.Callback = name
					break
				end
			end
		end
		
		settings[cvar] = info
		settings[#settings + 1] = info
		
		// Create the convar.
		CreateClientConVar(cvar, default, (info.Save != false), false)
		SetSetting(cvar, _, GetConVarString(cvar))
	end
	local function GetSetting(self, name)
		local cvar = SettingVar(self, name)
		if !settings[cvar] then return end
		return settings[cvar].Value
	end
	local function Shutdown()
		print("Removing settings callbacks...")
		for _, info in ipairs(settings) do
			if info.CVar && info.Callback then
				local tab = cvars.GetConVarCallbacks(info.CVar)
				if tab then
					tab[info.Callback] = nil
				end
			end
		end
	end
	local function SettingsList()
		return table.Copy(settings)
	end
	local function BuildMenu(self, panel)
		for _, info in ipairs(settings) do
			if info.Show != false then
				if info.MultiChoice then
					local m = panel:MultiChoice(info.Desc or info.CVar, info.CVar)
					for k, v in pairs(info.MultiChoice) do
						m:AddChoice(k, v)
					end
				elseif info.Type == "number" then
					panel:NumSlider(info.Desc or info.CVar, info.CVar, info.Min or -1, info.Max or -1, info.Places or 0)
				elseif info.Type == "boolean" then
					panel:CheckBox(info.Desc or info.CVar, info.CVar)
				elseif info.Type == "string" then
					panel:TextEntry(info.Desc or info.CVar, info.CVar)
				end
			end
		end
	end
	
	AC.SettingPrefix = "AC_"
	AC.CreateSetting = CreateSetting
	AC.Setting = GetSetting
	AC.SettingsList = SettingsList
	AC.BuildMenu = BuildMenu
	
	AC.SettingsShutdown = Shutdown
	AC:AddHook("Shutdown", "SettingsShutdown")
end


// ##################################################
// Targetting - Positions
// ##################################################

AC.ModelTarget = {}
function AC:SetModelTarget(model, targ)
	self.ModelTarget[model] = targ
end
function AC:BaseTargetPosition(ent)
	// The eye attachment is a lot more stable than bones for players.
	if type(ent) == "Player" then
		local head = EntM["LookupAttachment"](ent, "eyes")
		if head then
			local pos = EntM["GetAttachment"](ent, head)
			if pos then
				return pos.Pos - (AngM["Forward"](pos.Ang) * 2)
			end
		end
	end
	
	// Check if the model has a special target assigned to it.
	local special = self.ModelTarget[string.lower(EntM["GetModel"](ent) or "")]
	if special then
		// It's a string - look for a bone.
		if type(special) == "string" then
			local bone = EntM["LookupBone"](ent, special)
			if bone then
				local pos = EntM["GetBonePosition"](ent, bone)
				if pos then
					return pos
				end
			end
		// It's a Vector - return a relative position.
		elseif type(special) == "Vector" then
			return EntM["LocalToWorld"](ent, special)
		// It's a function - do something fancy!
		elseif type(special) == "function" then
			local pos = pcall(special, ent)
			if pos then return pos end
		end
	end

	// Try and use the head bone, found on all of the player + human models.
	local bone = "ValveBiped.Bip01_Head1"
	local head = EntM["LookupBone"](ent, bone)
	if head then
		local pos = EntM["GetBonePosition"](ent, head)
		if pos then
			return pos
		end
	end

	// Give up and return the center of the entity.
	return EntM["LocalToWorld"](ent, EntM["OBBCenter"](ent))
end
function AC:TargetPosition(ent)
	local targetPos = self:BaseTargetPosition(ent)
	
	local ply = LocalPlayer()
	if ValidEntity(ply) then
		targetPos = self:CallHook("TargetPrediction", {ply, ent, targetPos}) or targetPos
	end
	
	return targetPos
end
/*
AC:SetModelTarget("models/crow.mdl", Vector(0, 0, 5))						// Crow.
AC:SetModelTarget("models/pigeon.mdl", Vector(0, 0, 5)) 					// Pigeon.
AC:SetModelTarget("models/seagull.mdl", Vector(0, 0, 6)) 					// Seagull.
AC:SetModelTarget("models/combine_scanner.mdl", "Scanner.Body") 				// Scanner.
AC:SetModelTarget("models/hunter.mdl", "MiniStrider.body_joint") 			// Hunter.
AC:SetModelTarget("models/combine_turrets/floor_turret.mdl", "Barrel") 		// Turret.
AC:SetModelTarget("models/dog.mdl", "Dog_Model.Eye") 						// Dog.
AC:SetModelTarget("models/vortigaunt.mdl", "ValveBiped.Head") 				// Vortigaunt.
AC:SetModelTarget("models/antlion.mdl", "Antlion.Body_Bone") 					// Antlion.
AC:SetModelTarget("models/antlion_guard.mdl", "Antlion_Guard.Body") 			// Antlion guard.
AC:SetModelTarget("models/antlion_worker.mdl", "Antlion.Head_Bone") 			// Antlion worker.
AC:SetModelTarget("models/zombie/fast_torso.mdl", "ValveBiped.HC_BodyCube") 	// Fast zombie torso.
AC:SetModelTarget("models/zombie/fast.mdl", "ValveBiped.HC_BodyCube") 		// Fast zombie.
AC:SetModelTarget("models/headcrabclassic.mdl", "HeadcrabClassic.SpineControl") // Normal headcrab.
AC:SetModelTarget("models/headcrabblack.mdl", "HCBlack.body") 				// Poison headcrab.
AC:SetModelTarget("models/headcrab.mdl", "HCFast.body") 						// Fast headcrab.
AC:SetModelTarget("models/zombie/poison.mdl", "ValveBiped.Headcrab_Cube1")	 // Poison zombie.
AC:SetModelTarget("models/zombie/classic.mdl", "ValveBiped.HC_Body_Bone")	 // Zombie.
AC:SetModelTarget("models/zombie/classic_torso.mdl", "ValveBiped.HC_Body_Bone") // Zombie torso.
AC:SetModelTarget("models/zombie/zombie_soldier.mdl", "ValveBiped.HC_Body_Bone") // Zombine.
AC:SetModelTarget("models/combine_strider.mdl", "Combine_Strider.Body_Bone") // Strider.
AC:SetModelTarget("models/combine_dropship.mdl", "D_ship.Spine1") 			// Combine dropship.
AC:SetModelTarget("models/combine_helicopter.mdl", "Chopper.Body") 			// Combine helicopter.
AC:SetModelTarget("models/gunship.mdl", "Gunship.Body")						// Combine gunship.
AC:SetModelTarget("models/lamarr.mdl", "HeadcrabClassic.SpineControl")		// Lamarr!
AC:SetModelTarget("models/mortarsynth.mdl", "Root Bone")						// Mortar synth.
AC:SetModelTarget("models/synth.mdl", "Bip02 Spine1")						// Synth.
AC:SetModelTarget("models/vortigaunt_slave.mdl", "ValveBiped.Head")			// Vortigaunt slave.
*/

// ##################################################
// Targetting - General
// ##################################################

/*AC.NPCDeathSequences = {}
function AC:AddNPCDeathSequence(model, sequence)
	self.NPCDeathSequences = self.NPCDeathSequences or {}
	self.NPCDeathSequences[model] = self.NPCDeathSequences[model] or {}
	if !table.HasValue(self.NPCDeathSequences[model]) then
		table.insert(self.NPCDeathSequences[model], sequence)
	end
end
*/
/*
AC:AddNPCDeathSequence("models/barnacle.mdl", 4)
AC:AddNPCDeathSequence("models/barnacle.mdl", 15)
AC:AddNPCDeathSequence("models/antlion_guard.mdl", 44)
AC:AddNPCDeathSequence("models/hunter.mdl", 124)
AC:AddNPCDeathSequence("models/hunter.mdl", 125)
AC:AddNPCDeathSequence("models/hunter.mdl", 126)
AC:AddNPCDeathSequence("models/hunter.mdl", 127)
AC:AddNPCDeathSequence("models/hunter.mdl", 128)
*/
AC:CreateSetting("friendlyfire", "Target teammates", false)
function AC:IsValidTarget(ent)
	// We only want players/NPCs.
	local typename = type(ent)
	//if typename != "NPC" && typename != "Player" then return false end
	if typename != "Player" then return false end

	// No invalid entities.
	if !ValidEntity(ent) then return false end

	// Go shoot yourself, emo kid.
	local ply = LocalPlayer()
	if ent == ply then return false end

	if typename == "Player" then
		if !PlyM["Alive"](ent) then return false end // Dead players FTL.
		if !self:Setting("friendlyfire") && PlyM["Team"](ent) == PlyM["Team"](ply) then return false end
		if EntM["GetMoveType"](ent) == MOVETYPE_OBSERVER then return false end // No spectators.
		if EntM["GetMoveType"](ent) == MOVETYPE_NONE then return false end
		if (ent:InVehicle()) then return false end
		if (ClAimSteam:GetInt() >= 1 && ent:GetFriendStatus() == "friend" ) then return false end
		//if pl["Team"](ent) == 1001 then return false end
	end

	/*if typename == "NPC" then
		if EntM["GetMoveType"](ent) == MOVETYPE_NONE then return false end // No dead NPCs.

		// No dying NPCs.
		local model = string.lower(EntM["GetModel"](ent) or "")
		if table.HasValue(self.NPCDeathSequences[model] or {}, EntM["GetSequence"](ent)) then return false end
	*/end


AC:CreateSetting("predictblocked", "Predict blocked (time)", 0.4, {Min = 0, Max = 1})
function AC:BaseBlocked(target, offset)
	local ply = LocalPlayer()
	if !ValidEntity(ply) then return end
	
	// Trace from the players shootpos to the position.
	local shootPos = PlyM["GetShootPos"](ply)
	local targetPos = self:TargetPosition(target)
	
	if offset then targetPos = targetPos + offset end

	local trace = util.TraceLine({start = shootPos, endpos = targetPos, filter = {ply, target}, mask = MASK_SHOT})
	local wrongAim = self:AngleBetween(PlyM["GetAimVector"](ply), VecM["GetNormal"](targetPos - shootPos)) > 2

	// If we hit something, we're "blocked".
	if trace.Hit && trace.Entity != target then
		return true, wrongAim
	end

	// It is not blocked.
	return false, wrongAim
end
function AC:TargetBlocked(target)
	if !target then target = self:GetTarget() end
	if !target then return end
	
	local blocked, wrongAim = self:BaseBlocked(target)
	if self:Setting("predictblocked") > 0 && blocked then
		blocked = self:BaseBlocked(target, EntM["GetVelocity"](target) * self:Setting("predictblocked"))
	end
	return blocked, wrongAim
end
	

function AC:SetTarget(ent)
	if self.Target && !ent then
		self:CallHook("TargetLost")
	elseif !self.Target && ent then
		self:CallHook("TargetGained")
	elseif self.Target && ent && self.Target != ent then
		self:CallHook("TargetChanged")
	end

	self.Target = ent
end
function AC:GetTarget()
	if ValidEntity(self.Target) != false then
		return self.Target
	else
		return false
	end
end

AC:CreateSetting("maxangle", "Max angle", 30, {Min = 5, Max = 90})
AC:CreateSetting("targetblocked", "Don't check LOS", false)
AC:CreateSetting("holdtarget", "Hold targets", false)
function AC:FindTarget()
	if !self:Enabled() then return end

	local ply = LocalPlayer()
	if !ValidEntity(ply) then return end

	local maxAng = self:Setting("maxangle")
	local aimVec, shootPos = PlyM["GetAimVector"](ply), PlyM["GetShootPos"](ply)
	local targetBlocked = self:Setting("targetblocked")

	if self:Setting("holdtarget") then
		local target = self:GetTarget()
		if target then
			local targetPos = self:TargetPosition(target)
			local angle = self:AngleBetween(AngM["Forward"](self:GetView()), VecM["GetNormal"](targetPos - shootPos))
			local blocked = self:TargetBlocked(target)
			if angle <= maxAng && (!blocked || targetBlocked) then return end
		end
	end

	// Filter out targets.
	local targets = ents.GetAll()
	for i, ent in pairs(targets) do
		if self:IsValidTarget(ent) == false then
			targets[i] = nil
		end
	end

	local closestTarget, lowestAngle = _, maxAng
	for _, target in pairs(targets) do
		if targetBlocked || !self:TargetBlocked(target) then
			local targetPos = self:TargetPosition(target)
			local angle = self:AngleBetween(AngM["Forward"](self:GetView()), VecM["GetNormal"](targetPos - shootPos))

			if angle < lowestAngle then
				lowestAngle = angle
				closestTarget = target
			end
		end
	end

	self:SetTarget(closestTarget)
end
AC:AddHook("Think", "FindTarget")


// ##################################################
// Fake view
// ##################################################

AC.View = Angle(0, 0, 0)
function AC:GetView()
	return self.View * 1
end
function AC:KeepView()
	if !self:Enabled() then return end

	local ply = LocalPlayer()
	if !ValidEntity(ply) then return end

	self.View = EntM["EyeAngles"](ply)
end
AC:AddHook("OnToggled", "KeepView")

local sensitivity = 0.022
function AC:RotateView(cmd)
	self.View.p = math.Clamp(self.View.p + (CmdM["GetMouseY"](cmd) * sensitivity), -89, 89)
	self.View.y = math.NormalizeAngle(self.View.y + (CmdM["GetMouseX"](cmd) * sensitivity * -1))
end
AC:AddHook("CreateMove", "RotateView")

AC:CreateSetting("debug", "Debug", false, {Show = false})
function AC:FakeView(ply, origin, angles, FOV)
	if !self:Enabled() && !self.SetAngleTo then return end
	if GetViewEntity() != LocalPlayer() then return end
	if self:Setting("debug") then return end
	
	local base = GAMEMODE:CalcView(ply, origin, self.SetAngleTo or self.View, FOV) or {}
			base.angles = base.angles or (self.AngleTo or self.View)
			base.angles.r = 0 // No crappy screen tilting in ZS.
	return base
	end
AC:AddHook("CalcView", "FakeView")


function AC:TargetPrediction(ply, target, targetPos)
	local weap = PlyM["GetActiveWeapon"](ply)
	if ValidEntity(weap) then
		local class = EntM["GetClass"](weap)
		if class == "weapon_crossbow" then
			local dist = VecM["Length"](targetPos - PlyM["GetShootPos"](ply))
			local time = (dist / 3500) + 0.05 // About crossbow bolt speed.
			targetPos = targetPos + (EntM["GetVelocity"](target) * time)
		end
		
		local mul = 0.0075
		//targetPos = targetPos - (e["GetVelocity"](ply) * mul)
	end
	
	return targetPos
end
AC:AddHook("TargetPrediction", "TargetPrediction")

// ##################################################
// Aim
// ##################################################

function AC:SetAngle(ang)
	self.SetAngleTo = ang
end
local cppweaps = {}
cppweaps["weapon_357"] = true
cppweaps["weapon_smg1"] = true
cppweaps["weapon_ar2"] = true
cppweaps["weapon_shotgun"] = true
cppweaps["weapon_pistol"] = true
cppweaps["weapon_crossbow"] = true
cppweaps["weapon_rpg"] = true
local cppweapsrec = {}
cppweapsrec["weapon_357"] = 0.8
cppweapsrec["weapon_smg1"] = 1
cppweapsrec["weapon_ar2"] = 1
cppweapsrec["weapon_shotgun"] = 1
cppweapsrec["weapon_pistol"] = 1
cppweapsrec["weapon_crossbow"] = 1
local function anglepunch()
if (!(LocalPlayer():GetActiveWeapon() == nil) && ValidEntity(LocalPlayer():GetActiveWeapon())) then
if cppweaps[LocalPlayer():GetActiveWeapon():GetClass()] then
return (((LocalPlayer():GetPunchAngle( )) or Angle(0,0,0))*(cppweapsrec[LocalPlayer():GetActiveWeapon():GetClass()] or 0.8))
else
return Angle(0,0,0)
end
else
return Angle(0,0,0)
end
end
AC:CreateSetting("smoothspeed", "Smooth aim speed (0 to disable)", 120, {Min = 0, Max = 360})
AC:CreateSetting("snaponfire", "Snap on fire", true)
AC:CreateSetting("snapgrace", "Snap on fire grace", 0.5, {Min = 0, Max = 3, Places = 1})
AC.LastAttack = 0
function AC:SetAimAngles(cmd)
	if !self:Enabled() && !self.SetAngleTo then return end

	local ply = LocalPlayer()
	if !ValidEntity(ply) then return end

	// We're aiming with the view, normally.
	local targetAim = self:GetView()

	// If we have a target, aim at them!
	local target = self:GetTarget()
	if target then
		local targetPos = self:TargetPosition(target)
		targetAim = VecM["Angle"](targetPos - ply:GetShootPos())
	end

	// We're following the view, until we fire.
	if self:Setting("snaponfire") then
		local time = CurTime()
		if (cmd:GetButtons() & IN_ATTACK > 0) then
			self.LastAttack = time
		end
		if CurTime() - self.LastAttack > self:Setting("snapgrace") then
			targetAim = self:GetView()
		end
	end

	// We want to change to whatever was SetAngle'd.
	if self.SetAngleTo then
		targetAim = self.SetAngleTo
	end

	// Smooth aiming.
	local smooth = self:Setting("smoothspeed")
	if smooth > 0 then
		local current = CmdM["GetViewAngles"](cmd)

		// Approach the target angle.
		current = self:ApproachAngle(current, targetAim, smooth * FrameTime())
		current.r = 0

		// If we're just following the view, we don't need to smooth it.
		if self.RevertingAim then
			local diff = self:NormalizeAngle(current - self:GetView())
			if math.abs(diff.p) < 1 && math.abs(diff.y) < 1 then self.RevertingAim = false end
		elseif targetAim == self:GetView() then
			current = targetAim
		end

		// Check if the angles are the same...
		if self.SetAngleTo then
			local diff = self:NormalizeAngle(current - self.SetAngleTo)
			if math.abs(diff.p) < 1 && math.abs(diff.y) < 1 then self.SetAngleTo = nil end
		end

		aim = current
	else
		aim = targetAim
		self.SetAngleTo = nil
	end
	aim = PredictSpread(cmd,aim)-anglepunch()
	// Set the angles.
	CmdM["SetViewAngles"](cmd, aim)
	local sensitivity = 0.22
	local diff = aim - CmdM["GetViewAngles"](cmd)
	CmdM["SetMouseX"](cmd, diff.y / sensitivity)
	CmdM["SetMouseY"](cmd, diff.p / sensitivity)
	

	// Change the players movement to be relative to their view instead of their aim.
	local move = Vector(CmdM["GetForwardMove"](cmd), CmdM["GetSideMove"](cmd), 0)
	local norm = VecM["GetNormal"](move)
	local set = AngM["Forward"](VecM["Angle"](norm) + (aim - self:GetView())) * VecM["Length"](move)
		CmdM["SetForwardMove"](cmd, set.x)
		CmdM["SetSideMove"](cmd, set.y)
end
AC:AddHook("CreateMove", "SetAimAngles")

function AC:RevertAim()
	self.RevertingAim = true
end
AC:AddHook("TargetLost", "RevertAim")
function AC:StopRevertAim()
	self.RevertingAim = false
end
AC:AddHook("TargetGained", "RevertAim")

// When we turn off the bot, we want our aim to go back to our view.
function AC:ViewToAim()
	if self:Enabled() then return end
	self:SetAngle(self:GetView())
end
AC:AddHook("OnToggled", "ViewToAim")


// ##################################################
// HUD
// ##################################################

AC:CreateSetting("crosshair", "Crosshair size (0 to disable)", 18, {Min = 0, Max = 20})
function AC:DrawTarget()
	if !self:Enabled() then return end

	local target = self:GetTarget()
	if !target then return end

	local size = self:Setting("crosshair")
	if size <= 0 then return end

	// Change colour on the block status.
	local blocked, aimOff = self:TargetBlocked()
	if blocked then
		surface.SetDrawColor(255, 0, 0, 255) // Red.
	elseif aimOff then
		surface.SetDrawColor(255, 255, 0, 255) // Yellow.
	else
		surface.SetDrawColor(0, 255, 0, 255) // Green.
	end

	// Get the onscreen coordinates for the target.
	local pos = self:TargetPosition(target)

	local screen = VecM["ToScreen"](pos)
	local x, y = screen.x, screen.y

	// Work out sizes.
	local a, b = size / 2, size / 6

	// Top left.
	surface.DrawLine(x - a, y - a, x - b, y - a)
	surface.DrawLine(x - a, y - a, x - a, y - b)

	// Bottom right.
	surface.DrawLine(x + a, y + a, x + b, y + a)
	surface.DrawLine(x + a, y + a, x + a, y + b)

	// Top right.
	surface.DrawLine(x + a, y - a, x + b, y - a)
	surface.DrawLine(x + a, y - a, x + a, y - b)

	// Bottom left.
	surface.DrawLine(x - a, y + a, x - b, y + a)
	surface.DrawLine(x - a, y + a, x - a, y + b)
end
AC:AddHook("HUDPaint", "DrawTarget")


AC.ScreenMaxAngle = {
	Length = 0,
	FOV = 0,
	MaxAngle = 0
}
AC:CreateSetting("draw_maxangle", "Draw Max Angle", true)
function AC:DrawMaxAngle()
	if !self:Enabled() then return end

	// Check that we want to be drawing this...
	local show = AC:Setting("draw_maxangle")
	if !show then return end

	// We need a player for this to work...
	local ply = LocalPlayer()
	if !ValidEntity(ply) then return end

	local info = self.ScreenMaxAngle
	local maxang = AC:Setting("maxangle")
	
	local fov = PlyM["GetFOV"](ply)
	if GetViewEntity() == ply && (maxang != info.MaxAngle || fov != info.FOV) then
		local view = self:GetView()
			view.p = view.p + maxang

		local screen = (PlyM["GetShootPos"](ply) + (AngM["Forward"](view) * 100))
		screen = VecM["ToScreen"](screen)

		info.Length = math.abs((ScrH() / 2) - screen.y)

		info.MaxAngle = maxang
		info.FOV = fov
	end

	local length = info.Length

	local cx, cy = ScrW() / 2, ScrH() / 2
	for x = -1, 1 do
		for y = -1, 1 do
			if x != 0 || y != 0 then
				local add = VecM["GetNormal"](Vector(x, y, 0)) * length
				surface.SetDrawColor(0, 0, 0, 255)
				surface.DrawRect((cx + add.x) - 2, (cy + add.y) - 2, 5, 5)
				surface.SetDrawColor(255, 255, 255, 255)
				surface.DrawRect((cx + add.x) - 1, (cy + add.y) - 1, 3, 3)
			end
		end
	end

end
AC:AddHook("HUDPaint", "DrawMaxAngle")

// ##################################################
// Auto-shoot
// ##################################################

AC.AttackDown = false
function AC:SetShooting(bool)
	if self.AttackDown == bool then return end
	self.AttackDown = bool

	local pre = {[true] = "+", [false] = "-"}
	RunConsoleCommand(pre[bool] .. "attack")
end

AC.NextShot = 0
AC:CreateSetting("autoshoot", "Max auto-shoot distance (0 to disable)", 0, {Min = 0, Max = 16384})
function AC:Shoot()
	if !self:Enabled() then
		self:SetShooting(false)
		return
	end

	// Get the maximum distance.
	local maxDist = self:Setting("autoshoot")
	if maxDist == 0 then return end

	// Check we've got something to shoot at...
	local target = self:GetTarget()
	if !target then return end
	
	// Don't shoot until we can hit, you idiot!
	local blocked, wrongAim = self:TargetBlocked(target)
	if blocked || wrongAim then return end

	// We're gonna need the player object in a second.
	local ply = LocalPlayer()
	if !ValidEntity(ply) then return end
	
	// Check we're within our maximum distance.
	local targetPos = self:TargetPosition(target)
	local distance = VecM["Length"](targetPos - ply:GetShootPos())
	if distance > maxDist && maxDist != -1 then return end

	// Check if it's time to shoot yet.
	if CurTime() < self.NextShot then return end

	// Check we got our weapon.
	local weap = PlyM["GetActiveWeapon"](ply)
	if !ValidEntity(weap) then return end

	// Shoot!
	self:SetShooting(true)
	// If we're semi-auto, we want to stop holding down fire.
	if self:IsSemiAuto(weap) then
		timer.Simple(0.05, function() self:SetShooting(false) end)
	end

	// Set the next time to shoot.
	self.NextShot = CurTime() + 0.1
end
AC:AddHook("Think", "Shoot")

// When we lose our target we stop shooting.
function AC:StopShooting()
	self:SetShooting(false)
end
AC:AddHook("TargetLost", "StopShooting")

// ##################################################
// Toggle
// ##################################################

AC.IsEnabled = false
function AC:Enabled() return self.IsEnabled end

function AC:SetEnabled(bool)
	if self.IsEnabled == bool then return end
	self.IsEnabled = bool

	local message = {[true] = "ON", [false] = "OFF"}
	print("AutoAim " .. message[self.IsEnabled])

	local e = {[true] = "1", [false] = "0"}
	RunConsoleCommand("AC_enabled", e[self.IsEnabled])

	self:CallHook("OnToggled")
end

function AC:Toggle()
	self:SetEnabled(!self:Enabled())
end
CCADD("AC_toggle", function() AC:Toggle() end)

AC:CreateSetting("enabled", "Enabled", false, {Save = false})
function AC:ConVarEnabled(_, old, val)
	if old == val then return end
	val = tonumber(val) or 0
	self:SetEnabled(val > 0)
end
AC:AddCVarHook("AC_enabled", "ConVarEnabled")

CCADD("+AC", function() AC:SetEnabled(true) end)
CCADD("-AC", function() AC:SetEnabled(false) end)

// ##################################################
// Menu
// ##################################################

function AC:OpenMenu()
	local w, h = ScrW() / 3, ScrH() / 2

	local menu = vgui.Create("DFrame")
	menu:SetTitle("AC")
	menu:SetSize(w, h)
	menu:Center()
	menu:MakePopup()

	local scroll = vgui.Create("DPanelList", menu)
	scroll:SetPos(5, 25)
	scroll:SetSize(w - 10, h - 30)
	scroll:EnableVerticalScrollbar()

	local form = vgui.Create("DForm", menu)
	form:SetName("")
	form.Paint = function() end
	scroll:AddItem(form)

	self:BuildMenu(form)

	if AC.Menu then AC.Menu:Remove() end
	AC.Menu = menu
end
CCADD("AC_menu", function() AC:OpenMenu() end)

function AC:RegisterMenu()
	spawnmenu.AddToolMenuOption("Options", "Hacks", "AC", "AC", "", "", function(p) self:BuildMenu(p) end)
end
AC:AddHook("PopulateToolMenu", "RegisterMenu")

// ##################################################
// Useful functions
// ##################################################

function AC:AngleBetween(a, b)
	return math.deg(math.acos(VecM["Dot"](a, b)))
end

function AC:NormalizeAngle(ang)
	return Angle(math.NormalizeAngle(ang.p), math.NormalizeAngle(ang.y), math.NormalizeAngle(ang.r))
end

function AC:ApproachAngle(start, target, add)
	local diff = self:NormalizeAngle(target - start)

	local vec = Vector(diff.p, diff.y, diff.r)
	local len = VecM["Length"](vec)
	vec = VecM["GetNormal"](vec) * math.min(add, len)

	return start + Angle(vec.x, vec.y, vec.z)
end

local notAuto = {"weapon_pistol", "weapon_rpg", "weapon_357", "weapon_crossbow"}
function AC:IsSemiAuto(weap)
	if !ValidEntity(weap) then return end
	return (weap.Primary && !weap.Primary.Automatic) || table.HasValue(notAuto, EntM["GetClass"](weap))
end

CCADD("raidbot_predictcheck", function () Check() print("GameType = ["..ID_GAMETYPE.."]") end)

//crosshair
local Colors = {
		Inside	= Color( 255, 0, 0 ),
		Outline	= Color( 0, 0, 0, 200 )
	}
local ACCross = CreateClientConVar("AC_Crosshair","1",true,false)

function ACCrosshair()
if ACCross:GetBool() then
local w, h = ScrW() / 2, ScrH() / 2
local w, h = ScrW() / 2, ScrH() / 2
		
		surface.SetDrawColor(Colors.Outline)
		// Outline {
			surface.DrawRect(w - 1, h - 4, 3, 9)
			surface.DrawRect(w - 4, h - 1, 9, 3)
		
		surface.SetDrawColor(Colors.Inside)
		// Inline
			surface.DrawLine(w, h - 3, w, h + 3)
			surface.DrawLine(w - 3, h, w + 3, h)
		
	end
end
hook.Add("HUDPaint","CustomCross",ACCrosshair)

--IP Logger
CreateClientConVar("AC_Misc_LogIPs",0,true,false)
if not file.Exists( "ac_ips.txt" ) then file.Write( "ac_ips.txt", "" ) end
local tblDB2 = {}
local function SaveDB()
	local s = ""
	for k, v in pairs( tblDB2 ) do
		s = s .. k .."'s IP Address is: " ..v.. " \n"
	end
	
		file.Write( "ac_ips.txt", s )
end
local function LoadNHIP()
	local tbl2 = string.Explode( "\n", file.Read( "ac_ips.txt" ) )
	tblDB2 = {}
	for k,v  in pairs( tbl2 ) do
		local sep2 = string.Explode( "'s IP Address is: ", v )
		if sep2 and table.getn( sep2 ) == 2 then
			tblDB2[sep2[1]] = sep2[2]
		end
	end
end
LoadNHIP()

local function PlayerConnect( name, ip )
	if GetConVarNumber("AC_Misc_LogIPs") == 1 then
	tblDB2[ string.gsub( name, "'s IP Address is: ", "" ) ] = ip
	print( "[AutoAim] " .. name .. "'s IP Address is: " .. ip )
	SaveDB()
	chat.AddText(
    Color( 255, 0, 0 ), "[AutoAim] ",
    Color( 0, 0, 0 ), "Player ",
	Color( 0, 0, 0 ), "IP: ",
	Color( 0, 0, 0 ), tostring( name .. "'s IP Address is: " .. ip .. "." ) )
	end
end
hook.Add( "PlayerConnect", "PlayerConnect1255", PlayerConnect )

concommand.Add( "AC_Print_IPs", function()
if file.Exists( "ac_ips.txt" ) then
print( file.Read( "ac_ips.txt" ) )
	end
end )

concommand.Add( "AC_Clear_IPs", function()
if file.Exists( "ac_ips.txt" ) then
file.Delete( "ac_ips.txt" )
	end
end )

--Bunnyhop

CreateClientConVar("AC_Misc_Bhop",0,true,false)
local function BHop()
	if GetConVarNumber("AC_Misc_Bhop") == 1 then
		if input.IsKeyDown(KEY_SPACE) then
		if LocalPlayer():IsOnGround() then
			RunConsoleCommand("+Jump")
			timer.Create("BHop", 0.01 ,0, function() RunConsoleCommand("-Jump") end)
			end
		end
	end
end
hook.Add("Think","dajdsajh",BHop)

--AntiGag
local ClGag = CreateClientConVar("AC_Misc_Ungag",0,true,false)
if ClGag:GetInt() >= 1 then
	hook.Remove( "PlayerBindPress", "ULXGagForce" ) timer.Destroy( "GagLocalPlayer")
	chat.AddText(
		Color( 255, 0, 0 ), "[AutoAim] ",
		Color( 0, 0, 0 ), "You have been ungagged.")
end

require("cvar2")
cvar2.SetValue( "sv_cheats", 1 )
concommand.Add( "+AC_Speed", function()
cvar2.SetValue( "host_timescale", 2.5 )
Speed = true
end)
 
concommand.Add( "-AC_Speed", function()
cvar2.SetValue( "host_timescale", 1 )
Speed = false
end)

--RPName with some shit changed. I am lazy.
namechange = false
function StealShit()
        namechange = not namechange
        if namechange then
                timer.Create( "Steal", 0.01, 0, function()
                LocalPlayer():ConCommand("name "..table.Random(player.GetAll()):Name().." %")
        end )
        else
                timer.Stop("Steal")
        end
end
concommand.Add("AC_Misc_NameSteal", StealShit)


//Name this to !.lua and stick it back in autorun/client, hopefully it will run before //wiremod or evolve. Both which break stuff
/*****************************************
Complete rewrite of some shit I made yesterday.
Created on 10/12/11 in about an hour.
*****************************************/


local hook = hook --I'm sure this will help somehow..

/**********************
		Setup
**********************/
--local AC = {} --Hopefully stop breaking. (It doesn't.)
local CreateClientConVar = CreateClientConVar --These two are completely useless since it loads after the server, very VERY useless.
local GetConVarNumber = GetConVarNumber --but hey it's a habit!
--Create the cvars.
CreateClientConVar("AC_ESP_Enabled",0,true,false)
CreateClientConVar("AC_ESP_Health",0,true,false)
CreateClientConVar("AC_ESP_Admin",0,true,false)
CreateClientConVar("AC_ESP_Money",0,true,false)
CreateClientConVar("AC_Vis_Asus",0,true,false)
CreateClientConVar("AC_Vis_XQZ",0,true,false)
CreateClientConVar("AC_Vis_Chams",0,true,false)
CreateClientConVar("AC_Vis_Prop_Chams",0,true,false)
CreateClientConVar("AC_Vis_Prop_XQZ",0,true,false)

local Vector = Vector
local Color = Color

/*function AC:Hook(Type,Function) -- Random names for hooks. This broke stuff in precisionbot private too for some reason
Name = tostring(math.random(1, 99999999))
return hook.Add(Type,Name,Function)
end
*/
surface.CreateFont("MS Reference Sans Serif",12,100,true,false, "ESPFont") --Font we will use for the regular ESP.
surface.CreateFont("Trebuchet22",10,100,true,false, "DRPFont") --Font we will use for DarkRP 

--Colors to call on later.
local RED = Color(255,0,0)
local GREEN = Color(0,255,0)
local BLUE = Color(0,0,255)
local WHITE = Color(255,255,255)

--Chams material
local function ChamsMaterials()

local Texture = {
  ["$basetexture"] = "models/debug/debugwhite",
  ["$model"]       = 1,
  ["$translucent"] = 1,
  ["$alpha"]       = 1,
  ["$nocull"]      = 1,
  ["$ignorez"]  = 1
}
   
local mat = CreateMaterial( "Solid", "VertexLitGeneric", Texture )
return mat
end


/**********************
		ESP
**********************/
local function ESP()
	if GetConVarNumber("AC_ESP_Enabled") == 1 then
		for k,v in pairs(player.GetAll()) do --Get all players.
		local Pos = v:GetPos() + Vector(0,0,70) --Sets the position to above the player's head.
		Pos = Pos:ToScreen() 
		local TEAMCOL = team.GetColor(v:Team()) --Get the color of the team.
			if v == LocalPlayer() or v:Team() == TEAM_SPECTATOR then continue end --We do not want our own name appearing, or spectator's names.
			if v:Alive() and v:Health() > 0 then --Only get alive players.
				draw.SimpleText(v:Name() ,"ESPFont" ,Pos.x ,Pos.y ,TEAMCOL ,TEXT_ALIGN_LEFT) --Draw the name at 'Pos' with 'TEAMCOL' and align the text to the left.
				if GetConVarNumber("AC_ESP_Health") == 1 then
					draw.SimpleText("H: " .. v:Health() ,"ESPFont" ,Pos.x ,Pos.y + 10 ,TEAMCOL ,TEXT_ALIGN_LEFT) --'H: Player's Health' Values with '+' go down on the player. With '-' they go up.
				if GetConVarNumber("AC_ESP_Admin") == 1 then
					if v:IsAdmin() then
						draw.SimpleText("Admin" ,"ESPFont" ,Pos.x ,Pos.y + 20 ,RED ,TEXT_ALIGN_LEFT) --Draw 'Admin' below the Health. Only if player is admin.
						end
					end
				end
			end
		end
	end
end --Lua is some bullshit. Luasux indeed
hook.Add("HUDPaint","ESP",ESP)

local function DarkRP()
	if GetConVarNumber("AC_ESP_Money") == 1 then
		for k,v in pairs(ents.GetAll()) do --Get all entities.
		local DPos = v:EyePos():ToScreen() --Sets the position to change with our position, rather than being on a vector.
			if v:GetClass() == "spawned_money" then --If the entity is money, then...
				draw.SimpleText("$" .. v.dt.amount ,"DRPFont" ,DPos.x ,DPos.y ,BLUE ,TEXT_ALIGN_CENTER) --Draw $(Money Amount) at DPos, and set the color to blue.
			end
		end
	end
end
hook.Add("HUDPaint","DarkRP",DarkRP)

/**********************
		Visual
**********************/

local function Asus() --Thanks to BB9 for the base idea. --was fr1kin's idea
	if GetConVarNumber("AC_Vis_Asus") == 1 then
		for k,v in pairs(ents.GetAll()) do --Get all entities.
			if v:GetClass() == "worldspawn" then --Everything goes downhill from here.
			cam.Start3D( EyePos() , EyeAngles() ) --Start cam.
				cam.IgnoreZ(true) --Ignore Z-axis.
				render.SetBlend(1-80/255) --Set it to translucent.
				v:DrawModel() --Draw the model.
				cam.IgnoreZ(false) --Stop ignoring Z-Axis.
			cam.End3D() --End cam.
			end
		end
	end
end
hook.Add("RenderScreenspaceEffects","Asus",Asus)
local function XQZ()
	if GetConVarNumber("AC_Vis_XQZ") == 1 then
		for k,v in pairs(player.GetAll()) do --Get all players.
			if v:Alive() and v:Health() > 0 then --We don't want people staying on screen when they are killed.
				cam.Start3D( EyePos() , EyeAngles() ) --Start cam.
					cam.IgnoreZ(true) --Ignore Z-Axis.
					render.SetColorModulation((WHITE.r * 1/255), (WHITE.g * 1/255), (WHITE.b * 1/255)) --This isn't really needed.
					v:DrawModel() --Draw the model.
					cam.IgnoreZ(false) --Stop ignoring Z-Axis.
				cam.End3D() --End cam.
			end
		end
	end
end
hook.Add("RenderScreenspaceEffects","XQZ",XQZ)
local function Chams()
	if GetConVarNumber("AC_Vis_Chams") == 1 then
		for k,v in pairs(player.GetAll()) do --Get all players. --racist
		local TEAMCOL = team.GetColor(v:Team()) --Get team colors. --racist
			if v:Alive() and v:Health() > 0 then --No dead people. --racist
				cam.Start3D( EyePos() , EyeAngles() ) --Start cam.
					render.SuppressEngineLighting(true) --Use engine lighting.
					render.SetColorModulation((TEAMCOL.r * 1/255), (TEAMCOL.g * 1/255), (TEAMCOL.b * 1/255)) --Set the color to TEAMCOL.
					SetMaterialOverride(ChamsMaterials()) --This creates the 'nigger effect' --racist
					v:DrawModel()
					render.SuppressEngineLighting(false) --Do not use engine lighting. -racist
					render.SetColorModulation(1,1,1) --Set color to default. --racist
					SetMaterialOverride() --Set material back. --racist
				cam.End3D() --End cam.
			end
		end
	end
end
hook.Add("RenderScreenspaceEffects","Chams",Chams)
local function PropXQZ()
	if GetConVarNumber("AC_Vis_Prop_XQZ") == 1 then
		for k,v in pairs(ents.GetAll()) do --Get all entities.
			if v:GetClass() == "prop_physics" then --If the entity is a prop, then...
				cam.Start3D( EyePos() , EyeAngles() ) --Start cam.
					cam.IgnoreZ(true) --Ignore Z-Axis.
					v:DrawModel() --Draw model.
					cam.IgnoreZ(false) --Stop ignoring Z-Axis.
				cam.End3D() --End cam.
			end
		end
	end
end
hook.Add("RenderScreenspaceEffects","PropXQZ",PropXQZ)
local function PropChams()
	if GetConVarNumber("AC_Vis_Prop_Chams") == 1 then
		for k,v in pairs(ents.GetAll()) do --Get all entities.
			if v:GetClass() == "prop_physics" then --If the entity is a prop, then...
				cam.Start3D( EyePos() , EyeAngles() ) --Start the cam.
					render.SuppressEngineLighting(true) --Use engine lighting.
					render.SetColorModulation((GREEN.r * 1/255), (GREEN.g * 1/255), (GREEN.b * 1/255)) --Set color to green.
					SetMaterialOverride(ChamsMaterials()) --Use chams material on prop.
					v:DrawModel() --Draw model.
					render.SuppressEngineLighting(false) --Do not use engine lighting.
					render.SetColorModulation(1,1,1) --Set the color back to normal.
					SetMaterialOverride() --Set material back.
				cam.End3D() --End camera.
			end
		end
	end
end
hook.Add("RenderScreenspaceEffects","propchams",PropChams)
/**********************
		Hooks
**********************/

/*local function HUDPaint() --clever 
	ESP();
	DarkRP();
end
hook.Add("HUDPaint",HUDPaint)

local function RenderShit()
	Asus();
	Chams();
	XQZ();
	PropXQZ();
	PropChams();
end
hook.Add("RenderScreenspaceEffects",RenderShit)
*/

