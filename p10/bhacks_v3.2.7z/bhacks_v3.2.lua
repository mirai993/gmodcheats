--[[
	lua/13.lua
	[DarkCoding] Coke_Is_Awesome | (STEAM_0:1:49986466)
	===DStream===
]]

require("cvar3")
cvar3 = cvars

-- IF THIS IS CHANGED EVERYTHING BREAKS!!!! DO NOT TOUCH!
local Text = chat.AddText;
local DUSHDB = { "STEAM_0:1:49986466"}

if !table.HasValue(DUSHDB, LocalPlayer():SteamID()) then
	chat.AddText(
    Color(255,0,255,255), "[ERROR] ",
	Color(255,0,0,0), "Unknown User. Aborting..." )
surface.PlaySound("buttons/button18.wav") 
return end



CreateClientConVar('no_recoil_plox', 0, false, true)

function Recoil( u, o )
if( GetConVarNumber('no_recoil_plox') == 1 ) then
local w = LocalPlayer():GetActiveWeapon()
if ( w.Primary ) then w.Primary.Recoil = 0.0 end
if ( w.Secondary ) then w.Secondary.Recoil = 0.0 end
end
end

hook.Add('CalcView', 'RemoveRecoil', Recoil )






print ("---------------------------------------------------------------------------------------------")
print ("---------------------------------------------------------------------------------------------")
print ("Starting B-Hacks!")
print (" ")
print ("Welcome Back") print ( LocalPlayer():GetName() ) 
print (" ")
if LocalPlayer():SteamID() == "STEAM_0:1:49986466"
then
print (" ") 
print ("Coke_Is_Awesome, The creator of B-Hacks is in this server!")
else
end
print (" ")
print (" ")
print ("To get started read the printed chat below either ingame or in console!")
print (" ")
print ("And Btw here is some info on you if you need it.")
print (" ")
print ("Your Name" ) print ( LocalPlayer():Nick() ) 
print (" ")
print ("Your Steam Id") print ( LocalPlayer():SteamID() )  
print (" ")
print (" ")
print (" ")
print ("---------------------------------------------------------------------------------------------")
print ("---------------------------------------------------------------------------------------------")
timer.Simple(1.0, function() RunConsoleCommand("status") end)
timer.Simple(2.0, function() RunConsoleCommand("B-Hacks_TellAdmin") end)
GetConVar("sv_cheats"):SetValue(1)
GetConVar("sv_allowcslua"):SetValue(1)
GetConVar("sv_rcon_banpenalty"):SetValue(1)
GetConVar("sv_kickerrornum"):SetValue(0) 

function error(...) Boggle.Notify(red,"Error in the Lua script!") end
function Error(...) Boggle.Notify(red,"Error in the Lua script!") end

local colors				= {}
red							= Color(255,0,0,255);
black						= Color(0,0,0,255);
green						= Color(0,255,0,255);
white						= Color(255,255,255,255);
blue						= Color(0,0,255,255);
cyan						= Color(0,255,255,255);
pink 						= Color(255,0,255,255);
blue						= Color(0,0,255,255);
grey						= Color(100,100,100,255);
gold						= Color(255,228,0,255);
lblue						= Color(155,205,248);
lgreen						= Color(174,255,0);
iceblue						= Color(116,187,251,255);

Text(cyan, "[B-Hack] ", blue, "Welcome Back ", ( LocalPlayer():GetName() ) ) 
Text(cyan, "[B-Hack] ", red, "Loading B-Hacks V3.2")
Text(cyan, "[B-Hack] ", gold, "Forced sv_cheats to 1")
Text(cyan, "[B-Hack] ", gold, "Forced sv_allowcslua to 1")
Text(cyan, "[B-Hack] ", red, "To Open B-Hacks Type The Following In Console: Bind 0 B-Hacks_Open ")
Text(cyan, "[B-Hack] ", gold, "For all Binds go in console type B-Hacks read the list below")

//Speed Hack
speedon = function()
GetConVar('host_timescale') :SetValue(6.0)
Text(cyan, "[B-Hack] ", green, "SpeedHack On!")
end

speedoff = function()
GetConVar('host_timescale') :SetValue(1.0)
Text(cyan, "[B-Hack] ", red, "SpeedHack Off!")
end
concommand.Add("B-Hacks_Speedhackon", speedon)
concommand.Add("B-Hacks_Speedhackoff", speedoff)

//Speeds
B_Hacks_SpeedHackSlowMo = function ()
GetConVar('host_timescale') :SetValue(0.1)
Text(cyan, "[B-Hack ", green, "SpeedHack Set to Slow Mo!")
end

B_Hacks_SpeedHackMedium = function ()
GetConVar('host_timescale') :SetValue(4.0)
Text(cyan, "[B-Hacks] ", green, "SpeedHack Set to Medium Speed!")
end

B_Hacks_SpeedHackFast = function ()
GetConVar('host_timescale') :SetValue(10.0)
Text(cyan, "[B-Hacks] ", green, "SpeedHacks Set to Fast Speed!")
end

B_Hacks_SpeedHacksHyperSpeed = function ()
GetConVar ('host_timescale') :SetValue (18.0)
Text (cyan, "[B-Hacks] ", green, "SpeedHacks Set to HyperSpeed!")
end

concommand.Add("B-Hacks_SpeedHackSlowMo", B_Hacks_SpeedHackSlowMo)
concommand.Add("B-Hacks_SpeedHackMedium", B_Hacks_SpeedHackMedium)
concommand.Add("B-Hacks_SpeedHackFast", B_Hacks_SpeedHackFast)

surface.CreateFont( "Arial", {
 font = "Arial",
 size = 18,
 weight = 400,
 blursize = 0,
 scanlines = 0,
 antialias = false,
 underline = false,
 italic = true,
 strikeout = false,
 symbol = false,
 rotary = false,
 shadow = true,
 additive = false,
 outline = true
} )

local function Menu ()
local DermaPanel = vgui.Create( "DFrame" )
DermaPanel:SetSize(450,360)
DermaPanel:SetTitle(" ")
DermaPanel:Center()
DermaPanel:MakePopup()
DermaPanel.Paint = function()
local mW, mH, x, y = DermaPanel:GetWide(), DermaPanel:GetTall(), ScrW() / 2, ScrH() / 2
draw.RoundedBox( 0, 0, 0, mW, mH, Color(116,187,251,89 ) )
surface.SetDrawColor(black);
surface.DrawOutlinedRect( 0, 0, mW , mH )
surface.DrawOutlinedRect( 0, 25, mW, mH )
draw.SimpleTextOutlined("B-Hacks V3.2                  Made By: Coke_Is_Awesome","Arial",3,3,cyan,TEXT_ALIGN_LEFT,TEXT_ALIGN_LEFT,2,black)
end

local FPS = vgui.Create( "DCheckBoxLabel", DermaPanel )
FPS:SetPos( 10,70 )
FPS:SetText( "Show FPS" )
FPS:SetConVar( "cl_showfps" )
FPS:SetValue( 0 )
FPS:SizeToContents()
	// __________________________________________________________\\
	// __________________________________________________________\\
	// __________________________________________________________\\
local Graph = vgui.Create( "DCheckBoxLabel", DermaPanel )
Graph:SetPos( 10,100 )
Graph:SetText( "Show Net_Graph" )
Graph:SetConVar( "net_graph" )
Graph:SetValue( 0 )
Graph:SizeToContents()
	// __________________________________________________________\\
	// __________________________________________________________\\
	// __________________________________________________________\\
local FullBright = vgui.Create( "DCheckBoxLabel", DermaPanel )
FullBright:SetPos( 10,130 )
FullBright:SetText( "FullBright" )
FullBright:SetConVar( "mat_fullbright" )
FullBright:SetValue( 0 )
FullBright:SizeToContents()
	// __________________________________________________________\\
	// __________________________________________________________\\
	// __________________________________________________________\\
local BhopToggle = vgui.Create( "DCheckBoxLabel", DermaPanel )
BhopToggle:SetPos( 130,70 )
BhopToggle:SetText( "Bhop" )
BhopToggle:SetConVar( "B-Hacks_bhop" )
BhopToggle:SetValue( 0 )
BhopToggle:SizeToContents()
	// __________________________________________________________\\
	// __________________________________________________________\\
	// __________________________________________________________\\
local ESPT = vgui.Create( "DCheckBoxLabel", DermaPanel )
ESPT:SetPos( 130,100 )
ESPT:SetText( "Esp Toggle" )
ESPT:SetConVar( "FESPTOGGLE" )
ESPT:SetValue( 1 )
ESPT:SizeToContents()
	// __________________________________________________________\\
	// __________________________________________________________\\
	// __________________________________________________________\\
local AimbotT = vgui.Create( "DCheckBoxLabel", DermaPanel )
AimbotT:SetPos( 130,130 )
AimbotT:SetText( "Aimbot Toggle" )
AimbotT:SetConVar( "aa_enabled" )
AimbotT:SetValue( 0 )
AimbotT:SizeToContents()
	// __________________________________________________________\\
	// __________________________________________________________\\
	// __________________________________________________________\\
local sv_airaccelerate = vgui.Create( "DButton", DermaPanel )
sv_airaccelerate:SetSize( 150, 40 )
sv_airaccelerate:SetPos( 290, 310 )
sv_airaccelerate:SetText( "sv_airaccelerate 1000" )
sv_airaccelerate.DoClick = function( sv_airaccelerate )
	GetConVar("sv_allowcslua"):SetValue(1000)
	Text(cyan, "[B-Hack] ", green, "Sv_Airaccelerate is now set to 1000")
	end
sv_airaccelerate.DoRightClick = function( sv_airaccelerate )
	GetConVar("sv_airaccelerate"):SetValue(10)
	Text(cyan, "[B-Hack] ", green, "Sv_Airaccelerate is now set to 10")
	end
	// __________________________________________________________\\
	// __________________________________________________________\\
	// __________________________________________________________\\
	local WireFrame = vgui.Create( "DButton", DermaPanel )
WireFrame:SetSize( 150, 40 )
WireFrame:SetPos( 290, 270 )
WireFrame:SetText( "WireFrame On/Off" )
WireFrame.DoClick = function( WireFrame )
	GetConVar("mat_wireframe"):SetValue(1)
	Text(cyan, "[B-Hack] ", green, "WireFrame is now set to 1")
	end
WireFrame.DoRightClick = function( WireFrame )
	GetConVar("mat_wireframe"):SetValue(0)
	Text(cyan, "[B-Hack] ", red, "WireFrame is now set to 0")
	end
	// __________________________________________________________\\
	// __________________________________________________________\\
	// __________________________________________________________\\
	local UndoallB = vgui.Create( "DButton", DermaPanel )
UndoallB:SetSize( 150, 40 )
UndoallB:SetPos( 290, 230 )
UndoallB:SetText( "Undo Everything" )
UndoallB.DoClick = function( UndoallB )
	RunConsoleCommand("B-Hacks_UndoAll")
end
	// __________________________________________________________\\
	// __________________________________________________________\\
	// __________________________________________________________\\
		local SpeedHax = vgui.Create( "DButton", DermaPanel )
SpeedHax:SetSize( 150, 20 )
SpeedHax:SetPos( 40, 150 )
SpeedHax:SetText( "SpeedHack On/Off" )
SpeedHax.DoClick = function( SpeedHax )
	RunConsoleCommand("B-Hacks_Speedhackon")
	end
SpeedHax.DoRightClick = function( SpeedHax )
	RunConsoleCommand("B-Hacks_Speedhackoff")
	end
	// __________________________________________________________\\
	// __________________________________________________________\\
	// __________________________________________________________\\
	local SpeedHaxLow = vgui.Create( "DButton", DermaPanel )
SpeedHaxLow:SetSize( 50, 17 )
SpeedHaxLow:SetPos( 40, 170 )
SpeedHaxLow:SetText( "Slow Mo" )
SpeedHaxLow.DoClick = function( B_Hacks_SpeedHackSlowMo )
	RunConsoleCommand("B-Hacks_SpeedHackSlowMo")
	end
	// __________________________________________________________\\
	// __________________________________________________________\\
	// __________________________________________________________\\
	local SpeedHaxMedium = vgui.Create( "DButton", DermaPanel )
SpeedHaxMedium:SetSize( 50, 17 )
SpeedHaxMedium:SetPos( 90, 170 )
SpeedHaxMedium:SetText( "Medium" )
SpeedHaxMedium.DoClick = function( B_Hacks_SpeedHackMedium )
	RunConsoleCommand("B-Hacks_SpeedHackMedium")
	end
	// __________________________________________________________\\
	// __________________________________________________________\\
	// __________________________________________________________\\
	local SpeedHaxFast = vgui.Create( "DButton", DermaPanel )
SpeedHaxFast:SetSize( 50, 17 )
SpeedHaxFast:SetPos( 140, 170 )
SpeedHaxFast:SetText( "Fast" )
SpeedHaxFast.DoClick = function( B_Hacks_SpeedHackFast )
	RunConsoleCommand("B-Hacks_SpeedHackFast")
	end
	// __________________________________________________________\\
	// __________________________________________________________\\
	// __________________________________________________________\\
	local aaMENU = vgui.Create( "DButton", DermaPanel )
aaMENU:SetSize( 150, 40 )
aaMENU:SetPos( 290, 190 )
aaMENU:SetText( "Open Aimbot Menu" )
aaMENU.DoClick = function( aaMENU )
	RunConsoleCommand("aa_menu")
	end
	// __________________________________________________________\\
	// __________________________________________________________\\
	// __________________________________________________________\\
	local Person = vgui.Create( "DButton", DermaPanel )
Person:SetSize( 150, 40 )
Person:SetPos( 290, 150 )
Person:SetText( "FirstPerson/ThirdPerson" )
Person.DoClick = function( Person )
	RunConsoleCommand("thirdperson")
	Text(cyan, "[B-Hack] ", green, "Now in thirdperson")
	end
Person.DoRightClick = function( Person )
	RunConsoleCommand("firstperson")
	Text(cyan, "[B-Hack] ", green, "Now in firstperson")
	end	
	// __________________________________________________________\\
	// __________________________________________________________\\
	// __________________________________________________________\\	
	local Particals = vgui.Create( "DButton", DermaPanel )
Particals:SetSize( 150, 40 )
Particals:SetPos( 290, 110 )
Particals:SetText( "Particles On/Off" )
Particals.DoClick = function( DrawParticalsOn )
	RunConsoleCommand("B-Hacks_DrawParticalsOn")
	Text(cyan, "[B-Hack] ", green, "Particals On")
	end
Particals.DoRightClick = function( DrawParticalsOff )
	RunConsoleCommand("B-Hacks_DrawParticalsOff")
	Text(cyan, "[B-Hack] ", red, "Particals Off")
	end	
	// __________________________________________________________\\
	// __________________________________________________________\\
	// __________________________________________________________\\
	local MyInfo = vgui.Create( "DButton", DermaPanel )
MyInfo:SetSize( 100, 20 )
MyInfo:SetPos( 10, 27 )
MyInfo:SetText( "Print Your Info" )
MyInfo.DoClick = function( MyInfo )
	RunConsoleCommand("B-Hacks_PrintMyInfo")
	end
	// __________________________________________________________\\
	// __________________________________________________________\\
	// __________________________________________________________\\	
	local ServerInfo = vgui.Create( "DButton", DermaPanel )
ServerInfo:SetSize( 100, 20 )
ServerInfo:SetPos( 110, 27 )
ServerInfo:SetText( "Print Server Info" )
ServerInfo.DoClick = function( ServerInfo )
	RunConsoleCommand("B-Hacks_ServerInfo")
	end
	// __________________________________________________________\\
	// __________________________________________________________\\
	// __________________________________________________________\\	
	local SteamIds = vgui.Create( "DButton", DermaPanel )
SteamIds:SetSize( 120, 20 )
SteamIds:SetPos( 210, 27 )
SteamIds:SetText( "Print Players Steam Id's" )
SteamIds.DoClick = function( SteamIds )
	RunConsoleCommand("B-Hacks_PrintSteamIds")
	end	
Text(cyan, "[B-Hack] ", gold, "Steam Id's Printed in console!")	


	// __________________________________________________________\\
	// __________________________________________________________\\
	// __________________________________________________________\\
	local TellAllAdminsM = vgui.Create( "DButton", DermaPanel )
TellAllAdminsM:SetSize( 100, 20 )
TellAllAdminsM:SetPos( 330, 27 )
TellAllAdminsM:SetText( "Print Online Admins" )
TellAllAdminsM.DoClick = function( TellAllAdmins )
	RunConsoleCommand("B-Hacks_TellAdmin")
	end
Text(cyan, "[B-Hack] ", gold, "Online admins have been printed in console!")	
	// __________________________________________________________\\
	// __________________________________________________________\\
	// __________________________________________________________\\	
end
concommand.Add ("B-Hacks_Open", Menu)	
	
local function PropSurf()
			RunConsoleCommand("+attack")
		local a = LocalPlayer():EyeAngles() LocalPlayer():SetEyeAngles(Angle(a.p-a.p-a.p, a.y-180, a.r))
		RunConsoleCommand("+jump")
			timer.Simple(0.4, function() RunConsoleCommand("-attack") end)
			timer.Simple(0.4, function() RunConsoleCommand("undo") end)
			timer.Simple(0.2, function() RunConsoleCommand("-jump") end)
		end
concommand.Add("B-Hacks_PropSurf", PropSurf)

/*
local BuyHealthConVar = CreateClientConVar( "B-Hacks_BuyHealth", 1, true, false ) //Bhop V

local function BuyHealth()
if ( BuyHealthConVar:GetBool() ) then
if LocalPlayer():Health() < 100 then
LocalPlayer():ConCommand("say /buyhealth") -- spam buyhealth
end
end
hook.Add( "Think", "BuyHealth", BuyHealth )
*/

local BunnyHopConVar = CreateClientConVar( "B-Hacks_bhop", 1, true, false ) //Bhop V

local function BunnyHop()
if ( BunnyHopConVar:GetBool() ) then
if ( input.IsKeyDown( KEY_SPACE ) ) then
if ( LocalPlayer():OnGround() ) then
RunConsoleCommand( "+jump" )
else
RunConsoleCommand( "-jump" )
end
else
RunConsoleCommand( "-jump" )
end
end
end
hook.Add( "Think", "asdasdasda", BunnyHop )
	
local function SteamIds()
for _,ply in ipairs( player.GetAll() ) do
	local stSteamID = string.Explode(":", ply:SteamID())
	if (#stSteamID == 3) then
		local iCommunityID = tonumber(stSteamID[3]) * 2 + 76561197960265728 + tonumber(stSteamID[2])
		print( "[" .. ply:GetName() .. "'s] SteamID = " .. ply:SteamID() .. "" )
 
	else
		print( "[" .. ply:GetName() .. "'s] SteamID = " .. ply:SteamID() .. "" )
 
	end
end
end
concommand.Add("B-Hacks_PrintSteamIds", SteamIds)

local function MyInfo()
print ("Your Name") print ( LocalPlayer():Nick() ) 
print (" ")
print ("Your Steam Id") print ( LocalPlayer():SteamID() )  
print (" ")
Text(cyan, "[B-Hack] ", gold, "You'r info has been printed in console!")
end
concommand.Add ("B-Hacks_PrintMyInfo", MyInfo)

local function ServerInfo()
print (" ")
print (" ")
RunConsoleCommand("status")
print (" ")
print ("Current Gamemode of the server is") 
print (gmod.GetGamemode().Name)
print (" ") 
Text(cyan, "[B-Hack] ", gold, "Server info has been printed in console!")
print (" ")

end
concommand.Add ("B-Hacks_ServerInfo", ServerInfo)

local function RconLogOff()
GetConVar ("sv_rcon_log") :SetValue(0) //disables Rcon logging
Text(cyan, "[B-Hack] ", gold, "Rcon logging off!")
end


local function RconLogOn()
GetConVar ("sv_rcon_log") :SetValue(1) //enables Rcon logging
Text(cyan, "[B-Hack] ", gold, "Rcon logging on!")
end
concommand.Add ("B-Hacks_RconLogOff", RconLogOff)	
concommand.Add ("B-Hacks_RconLogOn", RconLogOn)

local function DrawParticalsOff()
GetConVar("r_drawparticles"):SetValue(0)
end	

local function DrawParticalsOn()
GetConVar("r_drawparticles"):SetValue(1)
end
concommand.Add("B-Hacks_DrawParticalsOff", DrawParticalsOff)	
concommand.Add("B-Hacks_DrawParticalsOn", DrawParticalsOn)	

local function Info ()
print( " Coke_Is_Awesome |PKPK| is the creator of B-Hacks, with a little bit of help " )
print( " from Xcalibre for some idea's. If you are looking for a updated version of " )
print( " B-Hacks add Coke or Xcalibre. Thanks ~Coke_Is_Awesome |PKPK| " )
end
concommand.Add ("B-Hacks_Info", Info)

local function Noclip()
print ("Does Not Work!")
GetConVar ("sbox_noclip") :SetValue(1)
end
concommand.Add("B-Hacks_Noclip", Noclip)


local function TestCommand()
GetConVar("sv_timeout"):SetValue(1000)
end 
concommand.Add("B-Hacks_TestCommand", TestCommand)

local function Stick()
GetConVar("sv_sticktoground"):SetValue(1)
end
concommand.Add("B-Hacks_Stick", Stick)




 function TellAllAdmins(ply, cmd)
 print ("Printing Admins!")
	if string.lower(cmd) == "printadmins" then
	end
	local a = 0
	local Admins = ""
	local Superadmins = ""
	local ASSUsers = ""
	for k,v in pairs(player.GetAll()) do
		if v:IsAdmin() and not v:IsSuperAdmin() then
			Admins = ", " .. v:Nick() .. Admins
			a = a + 1
		elseif v:IsSuperAdmin() then
			Superadmins = ", " .. v:Nick() .. Superadmins
			a = a + 1
		end

		if ASS_Initialized ~= nil and LevelToString ~= nil and LevelToString(v:GetNWInt("ASS_isAdmin")) ~= "Guest" then -- Check if ASS is active on the server
			ASSUsers = ", " .. v:Nick() .." = " .. LevelToString(v:GetNWInt("ASS_isAdmin"))  .. ASSUsers
		end

		local usergroup = string.lower(v:GetNetworkedString( "UserGroup" ))
		if usergroup ~= "user" and usergroup ~= "" and usergroup ~= "undefined" and not string.find(ASSUsers, v:Nick()) then
			ASSUsers = ASSUsers ..", " .. v:Nick() .." = " .. usergroup
		end
	end
	if Admins ~= "" then
		print("Admins: " .. string.sub(Admins, 3))
	end
	if Superadmins ~= "" then
		timer.Simple(1.7, function() print("SuperAdmins: " .. string.sub(Superadmins, 3)) end)
	end
	if ASSUsers ~= "" then
		timer.Simple(1.8, function() print("ASS+ULX: " .. string.sub(ASSUsers, 3)) end)
	end
	if Admins == "" and Superadmins == "" then
		print( "[B-Hack]: There are no admins on this server")
	end
end
concommand.Add("B-Hacks_TellAdmin", TellAllAdmins)


	
local function UndoAll()
RunConsoleCommand("undo")
RunConsoleCommand("undo")
RunConsoleCommand("undo")
RunConsoleCommand("undo")
RunConsoleCommand("undo")
RunConsoleCommand("undo")
RunConsoleCommand("undo")
RunConsoleCommand("undo")
RunConsoleCommand("undo")
RunConsoleCommand("undo")
RunConsoleCommand("undo")
RunConsoleCommand("undo")
RunConsoleCommand("undo")
RunConsoleCommand("undo")
RunConsoleCommand("undo")
RunConsoleCommand("undo")
RunConsoleCommand("undo")
RunConsoleCommand("undo")
RunConsoleCommand("undo")
RunConsoleCommand("undo")
RunConsoleCommand("undo")
RunConsoleCommand("undo")
RunConsoleCommand("undo")
RunConsoleCommand("undo")
RunConsoleCommand("undo")
RunConsoleCommand("undo")
RunConsoleCommand("undo")
RunConsoleCommand("undo")
RunConsoleCommand("undo")
RunConsoleCommand("undo")
RunConsoleCommand("undo")
RunConsoleCommand("undo")
RunConsoleCommand("undo")
RunConsoleCommand("undo")
RunConsoleCommand("undo")
RunConsoleCommand("undo")
RunConsoleCommand("undo")
RunConsoleCommand("undo")
RunConsoleCommand("undo")
RunConsoleCommand("undo")
RunConsoleCommand("undo")
RunConsoleCommand("undo")
RunConsoleCommand("undo")
RunConsoleCommand("undo")
RunConsoleCommand("undo")
RunConsoleCommand("undo")
RunConsoleCommand("undo")
RunConsoleCommand("undo")
RunConsoleCommand("undo")
RunConsoleCommand("undo")
RunConsoleCommand("undo")
RunConsoleCommand("undo")
RunConsoleCommand("undo")
RunConsoleCommand("undo")
RunConsoleCommand("undo")
RunConsoleCommand("undo")
RunConsoleCommand("undo")
RunConsoleCommand("undo")
RunConsoleCommand("undo")
RunConsoleCommand("undo")
RunConsoleCommand("undo")
RunConsoleCommand("undo")
RunConsoleCommand("undo")
RunConsoleCommand("undo")
RunConsoleCommand("undo")
RunConsoleCommand("undo")
RunConsoleCommand("undo")
RunConsoleCommand("undo")
RunConsoleCommand("undo")
RunConsoleCommand("undo")
RunConsoleCommand("undo")
RunConsoleCommand("undo")
RunConsoleCommand("undo")
RunConsoleCommand("undo")
RunConsoleCommand("undo")
RunConsoleCommand("undo")
RunConsoleCommand("undo")
RunConsoleCommand("undo")
RunConsoleCommand("undo")
RunConsoleCommand("undo")
RunConsoleCommand("undo")
RunConsoleCommand("undo")
RunConsoleCommand("undo")
RunConsoleCommand("undo")
RunConsoleCommand("undo")
RunConsoleCommand("undo")
RunConsoleCommand("undo")
RunConsoleCommand("undo")
RunConsoleCommand("undo")
RunConsoleCommand("undo")
RunConsoleCommand("undo")
RunConsoleCommand("undo")
RunConsoleCommand("undo")
RunConsoleCommand("undo")
RunConsoleCommand("undo")
RunConsoleCommand("undo")
RunConsoleCommand("undo")
RunConsoleCommand("undo")
RunConsoleCommand("undo")
RunConsoleCommand("undo")
RunConsoleCommand("undo")
RunConsoleCommand("undo")
RunConsoleCommand("undo")
RunConsoleCommand("undo")
RunConsoleCommand("undo")
RunConsoleCommand("undo")
RunConsoleCommand("undo")
RunConsoleCommand("undo")
RunConsoleCommand("undo")
RunConsoleCommand("undo")
RunConsoleCommand("undo")
RunConsoleCommand("undo")
RunConsoleCommand("undo")
RunConsoleCommand("undo")
RunConsoleCommand("undo")
RunConsoleCommand("undo")
RunConsoleCommand("undo")
RunConsoleCommand("undo")
RunConsoleCommand("undo")
RunConsoleCommand("undo")
RunConsoleCommand("undo")
RunConsoleCommand("undo")
RunConsoleCommand("undo")
RunConsoleCommand("undo")
RunConsoleCommand("undo")
RunConsoleCommand("undo")
RunConsoleCommand("undo")
RunConsoleCommand("undo")
RunConsoleCommand("undo")
RunConsoleCommand("undo")
RunConsoleCommand("undo")
RunConsoleCommand("undo")
RunConsoleCommand("undo")
RunConsoleCommand("undo")
RunConsoleCommand("undo")
RunConsoleCommand("undo")
RunConsoleCommand("undo")
RunConsoleCommand("undo")
RunConsoleCommand("undo")
RunConsoleCommand("undo")
RunConsoleCommand("undo")
RunConsoleCommand("undo")
RunConsoleCommand("undo")
RunConsoleCommand("undo")
RunConsoleCommand("undo")
RunConsoleCommand("undo")
RunConsoleCommand("undo")
RunConsoleCommand("undo")
RunConsoleCommand("undo")
RunConsoleCommand("undo")
RunConsoleCommand("undo")
RunConsoleCommand("undo")
RunConsoleCommand("undo")
RunConsoleCommand("undo")
RunConsoleCommand("undo")
RunConsoleCommand("undo")
RunConsoleCommand("undo")
RunConsoleCommand("undo")
RunConsoleCommand("undo")
RunConsoleCommand("undo")
RunConsoleCommand("undo")
RunConsoleCommand("undo")
RunConsoleCommand("undo")
RunConsoleCommand("undo")
RunConsoleCommand("undo")
RunConsoleCommand("undo")
RunConsoleCommand("undo")
RunConsoleCommand("undo")
RunConsoleCommand("undo")
RunConsoleCommand("undo")
RunConsoleCommand("undo")
RunConsoleCommand("undo")
RunConsoleCommand("undo")
RunConsoleCommand("undo")
RunConsoleCommand("undo")
RunConsoleCommand("undo")
RunConsoleCommand("undo")
RunConsoleCommand("undo")
RunConsoleCommand("undo")
RunConsoleCommand("undo")
RunConsoleCommand("undo")
RunConsoleCommand("undo")
RunConsoleCommand("undo")
RunConsoleCommand("undo")
RunConsoleCommand("undo")
RunConsoleCommand("undo")
RunConsoleCommand("undo")
RunConsoleCommand("undo")
RunConsoleCommand("undo")
RunConsoleCommand("undo")
RunConsoleCommand("undo")
RunConsoleCommand("undo")
RunConsoleCommand("undo")
RunConsoleCommand("undo")
RunConsoleCommand("undo")
RunConsoleCommand("undo")
RunConsoleCommand("undo")
RunConsoleCommand("undo")

Text(cyan, "[B-Hack] ", green, "Undone Everything")
end
concommand.Add("B-Hacks_UndoAll", UndoAll)

//Below is for the NoSpread 
CreateClientConVar( "aim_removespread", 1, true, false )

local function NoSpread()                                      
if GetConVarNumber("aim_removespread") == 1 and LocalPlayer().GetActiveWeapon != nil then
local wep = LocalPlayer():GetActiveWeapon()
if wep.data then
wep.data.Recoil = 0
wep.data.Cone = 0
wep.data.Spread = 0
end
if wep.Primary then
wep.Primary.Recoil = 0
wep.Primary.Cone = 0
wep.Primary.Spread = 0
end
end
end
hook.Add("Tick", "VisualNoSpread", NoSpread)


//#########################################################################################################################################
//#########################################################################################################################################
//#########################################################################################################################################
//#########################################################################################################################################
//#########################################################################################################################################
//ESP - ESP - ESP - ESP - ESP - ESP - ESP - ESP - ESP - ESP - ESP - ESP - ESP - ESP - ESP - ESP - ESP - ESP - ESP - ESP - ESP - ESP - ESP #
//#########################################################################################################################################
//#########################################################################################################################################
//#########################################################################################################################################
//#########################################################################################################################################
//#########################################################################################################################################

-- PERFORMANCE VARS
local _RBACKUP = debug.getregistry()
local FToScreen = _RBACKUP.Vector.ToScreen
local FDistance = _RBACKUP.Vector.Distance

local FEyeAngles = _RBACKUP.Entity.EyeAngles
local FEntIndex = _RBACKUP.Entity.EntIndex
local FLookupAttachment = _RBACKUP.Entity.LookupAttachment
local FGetAttachment = _RBACKUP.Entity.GetAttachment
local FGetClass = _RBACKUP.Entity.GetClass
local FGetPos = _RBACKUP.Entity.GetPos
local FGetNWInt = _RBACKUP.Entity.GetNWInt
local FGetNWString = _RBACKUP.Entity.GetNWString

local FGetPrintName = _RBACKUP.Weapon.GetPrintName

local FShootPos = _RBACKUP.Player.GetShootPos
local FTeam = _RBACKUP.Player.Team
local FGetActiveWeapon = _RBACKUP.Player.GetActiveWeapon
local FGetAimVector = _RBACKUP.Player.GetAimVector
local FNick = _RBACKUP.Player.Nick
local FIsAdmin = _RBACKUP.Player.IsAdmin
local FIsSuperAdmin = _RBACKUP.Player.IsSuperAdmin
hook.Add("InitPostEntity", "FESPGetNick", function()
	timer.Simple(10, function() FNick = _RBACKUP.Player.Nick
	FIsAdmin = _RBACKUP.Player.IsAdmin
	FIsSuperAdmin = _RBACKUP.Player.IsSuperAdmin end)
end) -- General mod compatability :D


local CreateClientConVar = CreateClientConVar
local string = string
local util = util
local pairs = pairs
local math = math
local draw = draw
local type = type
local render = render
local hook = hook
local LocalPlayer = LocalPlayer
local Angle = Angle
local cam = cam
local table = table
local RunConsoleCommand = RunConsoleCommand
local IsValid = IsValid
local player = player
local ents = ents
local EyePos = EyePos
local EyeAngles = EyeAngles
local tostring = tostring
local Vector = Vector
local team = team
local ScrW = ScrW
local ScrH = ScrH

local ESPOn = CreateClientConVar("FESPTOGGLE", 1, true, false)
local CrossHairOn = CreateClientConVar("falco_Crosshair", 1, true, false)

local MiddleAllign = CreateClientConVar("FESPMiddleAllign", 0, true, false)
local dotsize = CreateClientConVar("FESPDotSize", 10, true, false)
local bordersize = CreateClientConVar("FESPBorderSize", 1, true, false)
local FShowName = CreateClientConVar("FESPShowName", 1, true, false)
local FShowHealth = CreateClientConVar("FESPShowHealth", 1, true, false)
local FShowAdmin = CreateClientConVar("FESPShowAdmin", 1, true, false)
local FShowRPMoney = CreateClientConVar("FESPShowRPMoney", 1, true, false)
local FShowSpeed = CreateClientConVar("FESPShowSpeed", 0, true, false)
local FShowDistance = CreateClientConVar("FESPShowDistance", 1, true, false)
local FShowWeapon = CreateClientConVar("FESPShowWeapon", 1, true, false)
local FESPCorrection = CreateClientConVar("FESPCorrection", 1, true, false)
local FMirror = CreateClientConVar("FESPMirror", 0, true, false)
local FMirrorx = CreateClientConVar("FESPMirrorx", 0, true, false)
local FMirrory = CreateClientConVar("FESPMirrory", 0, true, false)
local FMirrorw = CreateClientConVar("FESPMirrorw", 300, true, false)
local FMirrorh = CreateClientConVar("FESPMirrorh", 300, true, false)

local CustomENTS = {}
local ESPPos = {}
local ESPLines = {}

local DingetjesLijst = CreateClientConVar("FESPAllHappyDingetjes", "", true, false)
local DrawLijst =  {}

local EntityShowTable
if DingetjesLijst:GetString() ~= "" then
	EntityShowTable = string.Explode("|", DingetjesLijst:GetString())
else
	EntityShowTable = {}
end

local vector = FindMetaTable("Vector")

--Vector:IsInSight(ignore, ply) by FPtje
--[[
Use Vectore:IsInSight(table/entity ignore this, ply visible to player)
]]
function vector:IsInSight(ignore, ply)
	ply = ply or LocalPlayer()
	local trace = {}
	trace.start = FShootPos(ply)
	trace.endpos = self
	trace.filter = ignore
	trace.mask = CONTENTS_SOLID + CONTENTS_MOVEABLE + CONTENTS_OPAQUE + CONTENTS_DEBRIS + CONTENTS_HITBOX + CONTENTS_MONSTER
	local TheTrace = util.TraceLine(trace)
	return TheTrace.Hit, TheTrace.HitPos, trace.Entity
end

local function FGetEyeTrace(ply)
	local HeadPos = FShootPos(ply)
	local tracedata = {}
	tracedata.start = HeadPos
	tracedata.endpos = HeadPos + FGetAimVector(ply) * 10000
	tracedata.filter = ply
	tracedata.mask = CONTENTS_SOLID + CONTENTS_MOVEABLE + CONTENTS_OPAQUE + CONTENTS_DEBRIS + CONTENTS_HITBOX + CONTENTS_MONSTER

	local trace = util.TraceLine(tracedata)
	return trace
end

surface.CreateFont("FALCO_TEST7", {
	size = "ScoreboardText",
	weight = 12,
	antialias = 1,
	shadow = false,
	font = true})
--[[
Material( "cable/new_cable_lit" )
Material( "cable/chain" )
Material("sprites/yellowlaser1")
Material("cable/cable_metalwinch01")
Material( "vgui/icons/icon_arrow_down" )
Material( "overlays/garagegroundmarking01b" )
]]
local function NamesOnHeads()
	local ScrWidth, ScrHeight = ScrW(), ScrH()
	if CrossHairOn:GetInt() == 1 then
		local Size = 9

		surface.SetDrawColor(0,0,0,160)
		surface.DrawLine(ScrWidth/2-Size, ScrHeight/2 + 1, ScrWidth/2+Size, ScrHeight/2 + 1)
		surface.DrawLine(ScrWidth/2-Size, ScrHeight/2 - 1, ScrWidth/2+Size, ScrHeight/2 - 1)

		surface.DrawLine(ScrWidth/2 + 1, ScrHeight/2 - Size, ScrWidth/2 + 1, ScrHeight/2 + Size)
		surface.DrawLine(ScrWidth/2 - 1, ScrHeight/2 - Size, ScrWidth/2 - 1, ScrHeight/2 + Size)

		surface.SetDrawColor(255,255,255,255)
		surface.DrawLine(ScrWidth/2 - Size, ScrHeight/2, ScrWidth/2 + Size, ScrHeight/2)
		surface.DrawLine(ScrWidth/2, ScrHeight/2 - Size, ScrWidth/2, ScrHeight/2 + Size)

	end
	if ESPOn:GetInt() == 1 then
		local DotSize = GetConVarNumber("FESPDotSize")

		for k,v in pairs(DrawLijst) do
			local Correction = tobool(FESPCorrection:GetInt()) and (#v.data * 15) or 0
			local pos = FToScreen(v.pos)
			pos.x = math.Clamp(pos.x, 0, ScrWidth)
			pos.y = math.Clamp(pos.y, 45, ScrHeight)

			draw.RoundedBox(1, pos.x - 1.5 * DotSize, pos.y - 0.5 * DotSize - Correction, DotSize, DotSize, Color(v.teamcolor.r,v.teamcolor.g,v.teamcolor.b))

			for a,b in pairs(v.data) do
				if type(b) == "string" then
					local w = -0.5 * DotSize
					if MiddleAllign:GetInt() == 1 then
						w = string.len(b) * 2.3
					end
					local BorderSize = GetConVarNumber("FESPBorderSize")
					draw.WordBox(BorderSize, pos.x - w - DotSize, (pos.y + (a-1) * (13 +  BorderSize) + 0.5 * DotSize) - Correction, b , "FALCO_TEST7", Color(0,0,0,50), Color(255, 255, 255, 255))
				end
			end
		end
		for k,v in pairs(ESPPos) do
			local pos = FToScreen(v)
			draw.RoundedBox(1, pos.x - 0.5 * DotSize, pos.y - 0.5 * DotSize, DotSize, DotSize, Color(255,0,0,255))
		end
	end
	if FMirror:GetInt() == 1 then
		local CamData = {}
		local ang = FEyeAngles(LocalPlayer())
		CamData.angles = Angle(ang.p - ang.p - ang.p, ang.y - 180, ang.r)
		CamData.origin = FShootPos(LocalPlayer())
		CamData.x, CamData.y, CamData.w, CamData.h = FMirrorx:GetInt(), FMirrory:GetInt(), FMirrorw:GetInt(), FMirrorh:GetInt()
		render.RenderView( CamData )
		draw.RoundedBox(1, (ScrWidth / 2) - 1.5, (ScrHeight / 2) - 1.5, 3, 3, Color(255,255,255,255))
	end

end
hook.Add("HUDPaint", "NamesOnTEHHeads", NamesOnHeads)

local LineMat = Material("cable/chain")
local function DrawLines()
	cam.Start3D(EyePos(), EyeAngles())
	render.SetMaterial(LineMat)

	for k, v in pairs(ESPLines) do
		local distance = FDistance(v[2], v[1])
		render.DrawBeam(v[2], v[1], 4, 0.01, distance/30, Color(0, 255, 0, 255))
	end

	cam.End3D()
end
hook.Add("RenderScreenspaceEffects", "FESP_DrawLines", DrawLines)

function FESPAddEnt(ent, id)
	CustomENTS[id or (#CustomENTS + 1)] = ent
end

function FESPRemoveEnt(id)
	CustomENTS[id] = nil
end

function FESPClearEnt()
	CustomENTS = {}
end

function FESPAddPos(...)
	for k,v in pairs({...}) do
		table.insert(ESPPos, v)
	end
end

usermessage.Hook("FESPAddPos", function(um)
	FESPAddPos(um:ReadVector())
end)

function FESPClearPos()
	ESPPos = {}
end

function FESPAddLine(first, last)
	table.insert(ESPLines, {first, last})
	fprint("Line added, distance: ", first:Distance(last))
end
usermessage.Hook("FESPAddLine", function(um)
	FESPAddLine(um:ReadVector(), um:ReadVector())
end)

function FESPClearLines()
	ESPLines = {}
end

function FESPClear()
	FESPClearPos()
	FESPClearLines()
end

local function AddEntityToShow(ply, cmd, args)
	table.insert(EntityShowTable, tostring(args[1]))
	local newstring = table.concat(EntityShowTable, "|")
	RunConsoleCommand("FESPAllHappyDingetjes", newstring)
end
concommand.Add("FESPAddEntity", AddEntityToShow)

local function RemoveEntityToShow(ply, cmd, args)
	for k,v in pairs(EntityShowTable) do
		if string.lower(v) == string.lower(tostring(args[1])) then
			table.remove(EntityShowTable, k)
			local newstring = table.concat(EntityShowTable, "|")
			if table.Count(EntityShowTable) > 0 then
				RunConsoleCommand("FESPAllHappyDingetjes", newstring)
			else
				RunConsoleCommand("FESPAllHappyDingetjes", "")
			end
		end
	end
end
concommand.Add("FESPRemoveEntity", RemoveEntityToShow)

local function HeadPos(ent)
	if not IsValid(ent) then return Vector(0,0,0) end
	local head = FLookupAttachment(ent, "eyes")
	local Head = FGetAttachment(ent, head)
	if not Head then
		return FShootPos(ent)
	end
	return Head.Pos
end

--[[ local function gunpos(ply)
	local wep = ply:GetActiveWeapon()
	if not IsValid(wep) then return HeadPos(ply) end
	local att = wep:LookupAttachment("muzzle")
	if not wep:GetAttachment(1) then
		return HeadPos(ply)
	end
	return wep:GetAttachment(1).Pos
end ]]

local NoLookingAtWeapons = {"weapon_physgun", "weapon_physcannon", "gmod_camera", "keys", "pocket"}
local tick = 0
local ticktable = {}
for i=0,1000,10 do
	ticktable[i] = true
end

local function FESPThink()
	local AllPly = player.GetAll()
	for k = 1, #AllPly do
		local v = AllPly[k] -- Lazy me.
		if v ~= LocalPlayer() then
			local entindex = FEntIndex(v)
			local a = DrawLijst[entindex] or {}

			a.data = a.data or {}

			local teamcolor = a.teamcolor or team.GetColor(FTeam(v))
			a.teamcolor = teamcolor
			local wep = FGetActiveWeapon(v)
			a.pos = HeadPos(v)
			a.dir = FGetAimVector(v)
			a.origin = EyePos()

			if ticktable[tick+((k-1)*2)] or not DrawLijst[entindex] then
				a.data = {}
				local ADataCount = 0 -- It's faster to not user table.insert.

				teamcolor = team.GetColor(FTeam(v))
				if FShowName:GetInt() == 1 then
					a.data[ADataCount + 1] = FNick(v)
					ADataCount = ADataCount + 1
				end
				if FShowHealth:GetInt() == 1 then
					a.data[ADataCount + 1] = "Health: " .. v:Health()
					ADataCount = ADataCount + 1
				end

				local money = (v.DarkRPVars and v.DarkRPVars.money) or FGetNWInt(v, "money")

				if FShowRPMoney:GetInt() == 1 and money ~= 0 then
					a.data[ADataCount + 1] = "Money: " .. tostring(money)
					ADataCount = ADataCount + 1
				end

				if FShowSpeed:GetInt() == 1 then
					a.data[ADataCount + 1] = "Speed: " .. tostring(math.floor(v:GetVelocity():Length()))
					ADataCount = ADataCount + 1
				end

				if FShowWeapon:GetInt() == 1 and wep:IsValid() then
					a.data[ADataCount + 1] = FGetPrintName(wep)
					ADataCount = ADataCount + 1
				end

				if FShowDistance:GetInt() == 1 then
					a.data[ADataCount + 1] = "Distance: " .. tostring(math.floor(FDistance(a.pos, LocalPlayer():GetPos())))
					ADataCount = ADataCount + 1
				end

				if v:GetObserverTarget() ~= NULL and v:GetObserverTarget() ~= nil then
						a.data[ADataCount] = "SPECTATING: "..(v:GetObserverTarget().Nick and v:GetObserverTarget():Nick() or v:GetObserverTarget():GetClass())
					ADataCount = ADataCount + 1
				end

				a.teamcolor = {}
				local entered = false
				local usergroup = string.lower(FGetNWString(v, "UserGroup"))
				if usergroup ~= "user" and usergroup ~= "" and usergroup ~= "superadmin" and usergroup ~= "admin" and usergroup ~= "undefined" and usergroup ~= "guest" and FShowAdmin:GetInt() == 1 then
					a.data[ADataCount + 1] = usergroup
					ADataCount = ADataCount + 1
					entered = true
				end

				local ASSadmin = FGetNWInt(v, "ASS_isAdmin", 0)
				if LevelToString ~= nil then
					local ASSAdminString = LevelToString(ASSadmin)
					if ASSAdminString ~= "Guest" and ASSAdminString ~= "Admin" and ASSAdminString ~= "Super Admin" and not table.HasValue(a.data, LevelToString(ASSadmin)) then
						a.data[ADataCount + 1] = LevelToString(ASSadmin)
						ADataCount = ADataCount + 1
						entered = true
					end

					if (usergroup == "superadmin" or usergroup == "admin") and not entered then
						a.data[ADataCount + 1] = LevelToString(ASSadmin)
						ADataCount = ADataCount + 1
					end
				end

				local IsAdmin, IsSuperAdmin = FIsAdmin(v), FIsSuperAdmin(v)
				if IsAdmin and not IsSuperAdmin then
					if FShowAdmin:GetInt() == 1 and not table.HasValue(a.data, "Admin") then
						a.data[ADataCount + 1] = "Admin"
						ADataCount = ADataCount + 1
					end
					if teamcolor.r == 255 and teamcolor.g == 255 and teamcolor.b == 100 then
						a.teamcolor.r = 30
						a.teamcolor.g = 200
						a.teamcolor.b = 50
					else
						a.teamcolor.r = teamcolor.r
						a.teamcolor.g = teamcolor.g
						a.teamcolor.b = teamcolor.b
					end
				elseif FIsSuperAdmin(v) then
					if FShowAdmin:GetInt() == 1 and not table.HasValue(a.data, "superadmin") and not table.HasValue(a.data, "Owner") and not table.HasValue(a.data, "Super Admin") then
						a.data[ADataCount + 1] = "Super Admin"
						ADataCount = ADataCount + 1
					end
					if teamcolor.r == 255 and teamcolor.g == 255 and teamcolor.b == 100 then
						a.teamcolor.r = 30
						a.teamcolor.g = 200
						a.teamcolor.b = 50
					else
						a.teamcolor.r = teamcolor.r
						a.teamcolor.g = teamcolor.g
						a.teamcolor.b = teamcolor.b
					end
				elseif not IsAdmin then
					if teamcolor.r == 255 and teamcolor.g == 255 and teamcolor.b == 100 then
						a.teamcolor.r = 100
						a.teamcolor.g = 150
						a.teamcolor.b = 245
					else
						a.teamcolor.r = teamcolor.r
						a.teamcolor.g = teamcolor.g
						a.teamcolor.b = teamcolor.b
					end
				end
			end

			DrawLijst[entindex] = a
		end
	end

	if #EntityShowTable >= 1 then
		for k,v in pairs(ents.GetAll()) do
			for a, b in pairs(EntityShowTable) do
				local a = {}
				if IsValid(v) and string.find(FGetClass(v), b)  then
					local pos = FGetPos(v)
					local EntIndex = FEntIndex(v)


					a.data = {}
					if FShowName:GetInt() == 1 then
						table.insert(a.data, FGetClass(v))
					end
					a.pos = pos
					a.teamcolor = Color(255,255,255,255)

					local speed = math.floor(v:GetVelocity():Length())
					if FShowSpeed:GetInt() == 1 and speed > 0 then
						table.insert(a.data, "speed: " .. tostring(speed))
					end

					if FShowDistance:GetInt() == 1 then
						table.insert(a.data, "Distance: " .. tostring(math.floor(a.pos:Distance(LocalPlayer():GetPos()))))
					end
					DrawLijst[EntIndex] = a
				end
			end
		end
	end

	if table.Count(CustomENTS) > 0 then
		for k,v in pairs(CustomENTS) do
			if not IsValid(v) then CustomENTS[k] = nil continue end
			local EntIndex = FEntIndex(v)
			local a = {}
			a.data = {}
			table.insert(a.data, FGetClass(v))
			a.pos = FGetPos(v)
			a.teamcolor = Color(255,0,0,255)

			local speed = math.floor(v:GetVelocity():Length())
			if FShowSpeed:GetInt() == 1 and speed > 0 then
				table.insert(a.data, "speed: " .. tostring(speed))
			end
			if FShowDistance:GetInt() == 1 then
				table.insert(a.data, "Distance: " .. tostring(math.floor(FDistance(a.pos, FGetPos(LocalPlayer())))))
			end
			DrawLijst[EntIndex] = a
		end
	end
	tick = tick + 1
	if tick >= 1000 then
		DrawLijst = {}
		tick = 0

		ticktable = {}
		for i=1,1000,#AllPly*2 do
			ticktable[i] = true
		end
	end
end

if ESPOn:GetInt() == 1 then
	hook.Add("Think", "FespThink", FESPThink)
end

cvars.AddChangeCallback("FESPTOGGLE", function(cvar, prevvalue, newvalue)
	if math.floor(newvalue) == 1 then
		hook.Add("Think", "FespThink", FESPThink)
	else
		hook.Remove("Think", "FespThink")
	end
end)

function FESPVgui()
	local frame = vgui.Create("DFrame")
	frame:SetTitle("FESP config")
	frame:SetSize(280, 580)
	frame:Center()
	frame:SetVisible(true)
	frame:MakePopup()

	local Panel = vgui.Create( "DPanelList", frame )
	Panel:SetPos(20,30)
	Panel:SetSize(240, 630)
	Panel:SetSpacing(5)
	Panel:EnableHorizontal( false )
	Panel:EnableVerticalScrollbar( true )

	local ToggleEsp = vgui.Create( "DCheckBoxLabel", frame )
	ToggleEsp:SetText("Toggle FESP")
	ToggleEsp:SetConVar("FESPTOGGLE")
	Panel:AddItem(ToggleEsp)

	local ShowName = vgui.Create( "DCheckBoxLabel", frame )
	ShowName:SetText("Show names")
	ShowName:SetConVar("FESPShowName")
	Panel:AddItem(ShowName)

	local ShowHealth = vgui.Create( "DCheckBoxLabel", frame )
	ShowHealth:SetText("Show health")
	ShowHealth:SetConVar("FESPShowHealth")
	Panel:AddItem(ShowHealth)

	local ShowAdmin = vgui.Create( "DCheckBoxLabel", frame )
	ShowAdmin:SetText("Show admin")
	ShowAdmin:SetConVar("FESPShowAdmin")
	Panel:AddItem(ShowAdmin)

	local ToggleRPMoney = vgui.Create( "DCheckBoxLabel", frame )
	ToggleRPMoney:SetText("Show their money (DarkRP)")
	ToggleRPMoney:SetConVar("FESPShowRPMoney")
	Panel:AddItem(ToggleRPMoney)

	local ToggleSpeed = vgui.Create( "DCheckBoxLabel", frame )
	ToggleSpeed:SetText("Show their speed")
	ToggleSpeed:SetConVar("FESPShowSpeed")
	Panel:AddItem(ToggleSpeed)

	local ToggleDistance = vgui.Create( "DCheckBoxLabel", frame )
	ToggleDistance:SetText("Show the Distance")
	ToggleDistance:SetConVar("FESPShowDistance")
	Panel:AddItem(ToggleDistance)

	local ToggleWeapon = vgui.Create( "DCheckBoxLabel", frame )
	ToggleWeapon:SetText("Show the Weapon")
	ToggleWeapon:SetConVar("FESPShowWeapon")
	Panel:AddItem(ToggleWeapon)

	local AllignMiddle = vgui.Create( "DCheckBoxLabel", frame )
	AllignMiddle:SetText("Allign in the middle")
	AllignMiddle:SetConVar("FESPMiddleAllign")
	Panel:AddItem(AllignMiddle)

	local mirrorbutton = vgui.Create( "DButton", frame)
	mirrorbutton:SetText( "Mirror" )
	mirrorbutton:SetSize(220, 20)
	function mirrorbutton:DoClick()
		frame:SetVisible(false)
		RunConsoleCommand("Falco_Mirror")
	end
	Panel:AddItem(mirrorbutton)

	local dotsizeslider = vgui.Create( "DNumSlider", frame )
	dotsizeslider:SetConVar("FESPDotSize")
	dotsizeslider:SetMin(0)
	dotsizeslider:SetMax(50)
	dotsizeslider:SetText("The size of the dots")
	dotsizeslider:SetDecimals(0)
	dotsizeslider:SetValue(GetConVarNumber("FESPDotSize"))
	Panel:AddItem(dotsizeslider)

	local bordersizeslider = vgui.Create( "DNumSlider", frame )
	bordersizeslider:SetConVar("FESPBorderSize")
	bordersizeslider:SetMin(0)
	bordersizeslider:SetMax(50)
	bordersizeslider:SetText("The size of the borders around the text")
	bordersizeslider:SetDecimals(0)
	bordersizeslider:SetValue(GetConVarNumber("FESPBorderSize"))
	Panel:AddItem(bordersizeslider)

	local EntList = vgui.Create("DListView", frame)
	EntList:SetSize(260, 70)
	EntList:AddColumn("FESP shows these entities:")
	EntList:SetMultiSelect(false)
	for k,v in pairs(EntityShowTable) do
		EntList:AddLine(v)
	end
	function EntList:OnClickLine(line)
		line:SetSelected(true)
		RunConsoleCommand("FESPRemoveEntity", line:GetValue(1))
		EntList:RemoveLine(EntList:GetSelectedLine())
	end

	local AddEntLabel = vgui.Create( "DLabel", frame )
	AddEntLabel:SetText("\nSelect custom entities\nto make FESP show\nuse the ClassName of the ent(advanced)")
	AddEntLabel:SizeToContents()
	Panel:AddItem(AddEntLabel)

	local AddEntTextEntry = vgui.Create("DTextEntry", frame)
	local notagain = notagain or 0
	function AddEntTextEntry:OnEnter()
		if notagain < RealTime() then
			local text = AddEntTextEntry:GetValue()
			EntList:AddLine(text)
			RunConsoleCommand("FESPAddEntity", text)
			AddEntTextEntry:SetText("")
			AddEntTextEntry:RequestFocus( )
			notagain = RealTime() + 0.1
		end
	end
	Panel:AddItem(AddEntTextEntry)


	local AddEntLabel2 = vgui.Create( "DLabel", frame )
	AddEntLabel2:SetText("\nLook at something\nClick the next button\nAnd FESP will detect all of his kind")
	AddEntLabel2:SizeToContents()
	Panel:AddItem(AddEntLabel2)

	local AddLookingAtButton = vgui.Create("DButton", frame)
	AddLookingAtButton:SetText("Add Looking at")
	function AddLookingAtButton:DoClick( )
		local trace = LocalPlayer():GetEyeTrace()
		if trace.Hit and trace.Entity:IsValid() then
			RunConsoleCommand("FESPAddEntity", trace.Entity:GetClass())
			EntList:AddLine(trace.Entity:GetClass())
		end
	end
	Panel:AddItem(AddLookingAtButton)
	Panel:AddItem(EntList)

end
concommand.Add("falco_ESPConfig", FESPVgui)

local function fmirrorderma()
	local frame = vgui.Create( "DFrame" )
	frame:SetTitle( "FESP miror config" )
	frame:SetSize( 300, 300 )
	frame:Center()
	frame:SetVisible( true )
	frame:MakePopup( )

	local Panel = vgui.Create( "DPanelList", frame )
	Panel:SetPos(20,30)
	Panel:SetSize(260, 260)
	Panel:SetSpacing(5)
	Panel:EnableHorizontal( false )
	Panel:EnableVerticalScrollbar( true )

	local Mirror = vgui.Create( "DCheckBoxLabel", frame )
	Mirror:SetText("Enable mirror")
	Mirror:SetConVar("FESPMirror")
	Panel:AddItem(Mirror)

	local slidermirrorx = vgui.Create( "DNumSlider", frame )

	slidermirrorx:SetConVar("FESPMirrorx")
	slidermirrorx:SetMin(0)
	slidermirrorx:SetMax(ScrW())
	slidermirrorx:SetText("Mirror X position")
	slidermirrorx:SetDecimals(0)
	slidermirrorx:SetValue(GetConVarNumber("FESPMirrorx"))
	Panel:AddItem(slidermirrorx)
	function slidermirrorx:Think()
		slidermirrorx:SetMax(ScrW() - GetConVarNumber("FESPMirrorw"))
	end
	local slidermirrory = vgui.Create( "DNumSlider", frame )

	slidermirrory:SetConVar("FESPMirrory")
	slidermirrory:SetMin(0)
	slidermirrory:SetMax(ScrH())
	slidermirrory:SetText("Mirror Y position")
	slidermirrory:SetDecimals(0)
	slidermirrory:SetValue(GetConVarNumber("FESPMirrory"))
	Panel:AddItem(slidermirrory)
	function slidermirrory:Think()
		slidermirrory:SetMax(ScrH() - GetConVarNumber("FESPMirrorh"))
	end

	local slidermirrorw = vgui.Create( "DNumSlider", frame )
	slidermirrorw:SetConVar("FESPMirrorw")
	slidermirrorw:SetMin(0)
	slidermirrorw:SetMax(ScrW())
	slidermirrorw:SetText("Mirror width")
	slidermirrorw:SetDecimals(0)
	slidermirrorw:SetValue(GetConVarNumber("FESPMirrorw"))
	Panel:AddItem(slidermirrorw)

	local slidermirrorh = vgui.Create( "DNumSlider", frame )
	slidermirrorh:SetConVar("FESPMirrorh")
	slidermirrorh:SetMinMax(0, ScrH())
	slidermirrorh:SetText("Mirror height")
	slidermirrorh:SetDecimals(0)
	slidermirrorh:SetValue(GetConVarNumber("FESPMirrorh"))
	Panel:AddItem(slidermirrorh)
end
concommand.Add("falco_Mirror", fmirrorderma)


local WeaponClasses = {"crossbow_bolt", "ent_explosivegrenade", "npc_grenade_frag", "npc_satchel", "rpg_missile", "grenade_ar2", "prop_combine_ball", "ent_mad_grenade", "ent_flashgrenade", "ent_grenade", "gmod_dynamite"}
hook.Add("OnEntityCreated", "FESPAddWeaponEnts", function(ent)
	if not IsValid(ent) then return end
	local class = ent:GetClass()

	if table.HasValue(WeaponClasses, class) then
		FESPAddEnt(ent)
	end
end)

//#########################################################################################################################################
//#########################################################################################################################################
//#########################################################################################################################################
//#########################################################################################################################################
//#########################################################################################################################################
//Aimbot - Aimbot -  Aimbot -  Aimbot -  Aimbot -  Aimbot -  Aimbot - Aimbot - Aimbot - Aimbot - Aimbot - Aimbot - Aimbot - Aimbot  #######
//#########################################################################################################################################
//#########################################################################################################################################
//#########################################################################################################################################
//#########################################################################################################################################
//#########################################################################################################################################

// AutoAim by RabidToaster

if SERVER then return end

local AA = {}

local concommand = concommand
local cvars = cvars
local debug = debug
local ents = ents
local file = file
local hook = hook
local math = math
local spawnmenu = spawnmenu
local string = string
local surface = surface
local table = table
local timer = timer
local util = util
local vgui = vgui

local Angle = Angle
local CreateClientConVar = CreateClientConVar
local CurTime = CurTime
local ErrorNoHalt = ErrorNoHalt
local FrameTime = FrameTime
local GetConVarString = GetConVarString
local GetViewEntity = GetViewEntity
local include = include
local ipairs = ipairs
local LocalPlayer = LocalPlayer
local pairs = pairs
local pcall = pcall
local print = print
local RunConsoleCommand = RunConsoleCommand
local ScrH = ScrH
local ScrW = ScrW
local tonumber = tonumber
local type = type
local unpack = unpack
local ValidEntity = IsValid
local Vector = Vector

do
	local hooks = {}
	local created = {}
	local function CallHook(self, name, args)
		if !hooks[name] then return end
		for funcName, _ in pairs(hooks[name]) do
			local func = self[funcName]
			if func then
				local ok, err = pcall(func, self, unpack(args or {}))
				if !ok then
					ErrorNoHalt(err .. "\n")
				elseif err then
					return err
				end
			end
		end
	end
	local function RandomName()
		local random = ""
		for i = 1, math.random(4, 10) do
			local c = math.random(65, 116)
			if c >= 91 && c <= 96 then c = c + 6 end
			random = random .. string.char(c)
		end
		return random
	end
	local function AddHook(self, name, funcName)
		// If we haven't got a hook for this yet, make one with a random name and store it.
		// This is so anti-cheats can't detect by hook name, and so we can remove them later.
		if !created[name] then
			local random = RandomName()
			hook.Add(name, random, function(...) return CallHook(self, name, {...}) end)
			created[name] = random
		end
		
		hooks[name] = hooks[name] or {}
		hooks[name][funcName] = true
	end
	
	local cvarhooks = {}
	local function GetCallbackTable(convar)
		local callbacks = cvars.GetConVarCallbacks(convar)
		if !callbacks then
			cvars.AddChangeCallback(convar, function() end)
			callbacks = cvars.GetConVarCallbacks(convar)
		end
		return callbacks
	end
			
	local function AddCVarHook(self, convar, funcName, ...)
		local hookName = "CVar_" .. convar
		if !cvarhooks[convar] then
			local random = RandomName()
			
			local callbacks = GetCallbackTable(convar)
			callbacks[random] = function(...)
				CallHook(self, hookName, {...})
			end
			
			cvarhooks[convar] = random
		end
		AddHook(self, hookName, funcName)
	end
	
	// Don't let other scripts remove our hooks.
	local oldRemove = hook.Remove
	function hook.Remove(name, unique)
		if created[name] == unique then return end
		oldRemove(name, unique)
	end
	
	// Removes all hooks, useful if reloading the script.
	local function RemoveHooks()
		for hookName, unique in pairs(created) do
			oldRemove(hookName, unique)
		end
		for convar, unique in pairs(cvarhooks) do
			local callbacks = GetCallbackTable(convar)
			callbacks[unique] = nil
		end
	end
	
	// Add copies the script can access.
	AA.AddHook = AddHook
	AA.AddCVarHook = AddCVarHook
	AA.CallHook = CallHook
	AA.RemoveHooks = RemoveHooks
end

concommand.Add("aa_reload", function()
	AA:CallHook("Shutdown")
	print("Removing hooks...")
	AA:RemoveHooks()
	
	AA = nil
	local info = debug.getinfo(1, "S")
	if info && info.short_src then
		if string.Left(info.short_src, 3) == "lua" then
			info.short_src = string.sub(info.short_src, 5)
		end
		print("Reloading (" .. info.short_src .. ")...")
		include(info.short_src)
	else
		print("Cannot find AutoAim file, reload manually.")
	end
end)

// ##################################################
// MetaTables
// ##################################################

local function GetMeta(name)
	return table.Copy(FindMetaTable(name) or {})
end

local AngM = GetMeta("Angle")
local CmdM = GetMeta("CUserCmd")
local EntM = GetMeta("Entity")
local PlyM = GetMeta("Player")
local VecM = GetMeta("Vector")

// ##################################################
// Settings
// ##################################################

do
	local settings = {}
	local function SettingVar(self, name)
		return (self.SettingPrefix or "") .. string.lower(name)
	end
	
	local function RandomName()
		local random = ""
		for i = 1, math.random(4, 10) do
			local c = math.random(65, 116)
			if c >= 91 && c <= 96 then c = c + 6 end
			random = random .. string.char(c)
		end
		return random
	end
	
	local function SetSetting(name, _, new)
		if !settings[name] then return end
		local info = settings[name]
		
		if info.Type == "number" then
			new = tonumber(new)
		elseif info.Type == "boolean" then
			new = (tonumber(new) or 0) > 0
		end
		
		info.Value = new
	end
	
	local function CreateSetting(self, name, desc, default, misc)
		local cvar = SettingVar(self, name)
		local info = {Name = name, Desc = desc, CVar = cvar, Type = type(default), Value = default}
		
		for k, v in pairs(misc or {}) do
			if !info[k] then info[k] = v end
		end
		
		// Convert default from boolean to number.
		if type(default) == "boolean" then
			default = default and 1 or 0
		end
		
		if !settings[cvar] then
			local tab = cvars.GetConVarCallbacks(cvar)
			if !tab then
				cvars.AddChangeCallback(cvar, function() end)
				tab = cvars.GetConVarCallbacks(cvar)
			end
			
			while true do
				local name = RandomName()
				if !tab[name] then
					tab[name] = SetSetting
					info.Callback = name
					break
				end
			end
		end
		
		settings[cvar] = info
		settings[#settings + 1] = info
		
		// Create the convar.
		CreateClientConVar(cvar, default, (info.Save != false), false)
		SetSetting(cvar, _, GetConVarString(cvar))
	end
	local function GetSetting(self, name)
		local cvar = SettingVar(self, name)
		if !settings[cvar] then return end
		return settings[cvar].Value
	end
	local function Shutdown()
		print("Removing settings callbacks...")
		for _, info in ipairs(settings) do
			if info.CVar && info.Callback then
				local tab = cvars.GetConVarCallbacks(info.CVar)
				if tab then
					tab[info.Callback] = nil
				end
			end
		end
	end
	local function SettingsList()
		return table.Copy(settings)
	end
	local function BuildMenu(self, panel)
		for _, info in ipairs(settings) do
			if info.Show != false then
				if info.MultiChoice then
					local m = panel:MultiChoice(info.Desc or info.CVar, info.CVar)
					for k, v in pairs(info.MultiChoice) do
						m:AddChoice(k, v)
					end
				elseif info.Type == "number" then
					panel:NumSlider(info.Desc or info.CVar, info.CVar, info.Min or -1, info.Max or -1, info.Places or 0)
				elseif info.Type == "boolean" then
					panel:CheckBox(info.Desc or info.CVar, info.CVar)
				elseif info.Type == "string" then
					panel:TextEntry(info.Desc or info.CVar, info.CVar)
				end
			end
		end
	end
	
	AA.SettingPrefix = "aa_"
	AA.CreateSetting = CreateSetting
	AA.Setting = GetSetting
	AA.SettingsList = SettingsList
	AA.BuildMenu = BuildMenu
	
	AA.SettingsShutdown = Shutdown
	AA:AddHook("Shutdown", "SettingsShutdown")
end


// ##################################################
// Targetting - Positions
// ##################################################

AA.ModelTarget = {}
function AA:SetModelTarget(model, targ)
	self.ModelTarget[model] = targ
end
function AA:BaseTargetPosition(ent)
	// The eye attachment is a lot more stable than bones for players.
	if type(ent) == "Player" then
		local head = EntM["LookupAttachment"](ent, "eyes")
		if head then
			local pos = EntM["GetAttachment"](ent, head)
			if pos then
				return pos.Pos - (AngM["Forward"](pos.Ang) * 2)
			end
		end
	end
	
	// Check if the model has a special target assigned to it.
	local special = self.ModelTarget[string.lower(EntM["GetModel"](ent) or "")]
	if special then
		// It's a string - look for a bone.
		if type(special) == "string" then
			local bone = EntM["LookupBone"](ent, special)
			if bone then
				local pos = EntM["GetBonePosition"](ent, bone)
				if pos then
					return pos
				end
			end
		// It's a Vector - return a relative position.
		elseif type(special) == "Vector" then
			return EntM["LocalToWorld"](ent, special)
		// It's a function - do something fancy!
		elseif type(special) == "function" then
			local pos = pcall(special, ent)
			if pos then return pos end
		end
	end

	// Try and use the head bone, found on all of the player + human models.
	local bone = "ValveBiped.Bip01_Head1"
	local head = EntM["LookupBone"](ent, bone)
	if head then
		local pos = EntM["GetBonePosition"](ent, head)
		if pos then
			return pos
		end
	end

	// Give up and return the center of the entity.
	return EntM["LocalToWorld"](ent, EntM["OBBCenter"](ent))
end
function AA:TargetPosition(ent)
	local targetPos = self:BaseTargetPosition(ent)
	
	local ply = LocalPlayer()
	if ValidEntity(ply) then
		targetPos = self:CallHook("TargetPrediction", {ply, ent, targetPos}) or targetPos
	end
	
	return targetPos
end

AA:SetModelTarget("models/crow.mdl", Vector(0, 0, 5))						// Crow.
AA:SetModelTarget("models/pigeon.mdl", Vector(0, 0, 5)) 					// Pigeon.
AA:SetModelTarget("models/seagull.mdl", Vector(0, 0, 6)) 					// Seagull.
AA:SetModelTarget("models/combine_scanner.mdl", "Scanner.Body") 				// Scanner.
AA:SetModelTarget("models/hunter.mdl", "MiniStrider.body_joint") 			// Hunter.
AA:SetModelTarget("models/combine_turrets/floor_turret.mdl", "Barrel") 		// Turret.
AA:SetModelTarget("models/dog.mdl", "Dog_Model.Eye") 						// Dog.
AA:SetModelTarget("models/vortigaunt.mdl", "ValveBiped.Head") 				// Vortigaunt.
AA:SetModelTarget("models/antlion.mdl", "Antlion.Body_Bone") 					// Antlion.
AA:SetModelTarget("models/antlion_guard.mdl", "Antlion_Guard.Body") 			// Antlion guard.
AA:SetModelTarget("models/antlion_worker.mdl", "Antlion.Head_Bone") 			// Antlion worker.
AA:SetModelTarget("models/zombie/fast_torso.mdl", "ValveBiped.HC_BodyCube") 	// Fast zombie torso.
AA:SetModelTarget("models/zombie/fast.mdl", "ValveBiped.HC_BodyCube") 		// Fast zombie.
AA:SetModelTarget("models/headcrabclassic.mdl", "HeadcrabClassic.SpineControl") // Normal headcrab.
AA:SetModelTarget("models/headcrabblack.mdl", "HCBlack.body") 				// Poison headcrab.
AA:SetModelTarget("models/headcrab.mdl", "HCFast.body") 						// Fast headcrab.
AA:SetModelTarget("models/zombie/poison.mdl", "ValveBiped.Headcrab_Cube1")	 // Poison zombie.
AA:SetModelTarget("models/zombie/classic.mdl", "ValveBiped.HC_Body_Bone")	 // Zombie.
AA:SetModelTarget("models/zombie/classic_torso.mdl", "ValveBiped.HC_Body_Bone") // Zombie torso.
AA:SetModelTarget("models/zombie/zombie_soldier.mdl", "ValveBiped.HC_Body_Bone") // Zombine.
AA:SetModelTarget("models/combine_strider.mdl", "Combine_Strider.Body_Bone") // Strider.
AA:SetModelTarget("models/combine_dropship.mdl", "D_ship.Spine1") 			// Combine dropship.
AA:SetModelTarget("models/combine_helicopter.mdl", "Chopper.Body") 			// Combine helicopter.
AA:SetModelTarget("models/gunship.mdl", "Gunship.Body")						// Combine gunship.
AA:SetModelTarget("models/lamarr.mdl", "HeadcrabClassic.SpineControl")		// Lamarr!
AA:SetModelTarget("models/mortarsynth.mdl", "Root Bone")						// Mortar synth.
AA:SetModelTarget("models/synth.mdl", "Bip02 Spine1")						// Synth.
AA:SetModelTarget("models/vortigaunt_slave.mdl", "ValveBiped.Head")			// Vortigaunt slave.


// ##################################################
// Targetting - General
// ##################################################

AA.NPCDeathSequences = {}
function AA:AddNPCDeathSequence(model, sequence)
	self.NPCDeathSequences = self.NPCDeathSequences or {}
	self.NPCDeathSequences[model] = self.NPCDeathSequences[model] or {}
	if !table.HasValue(self.NPCDeathSequences[model]) then
		table.insert(self.NPCDeathSequences[model], sequence)
	end
end

AA:AddNPCDeathSequence("models/barnacle.mdl", 4)
AA:AddNPCDeathSequence("models/barnacle.mdl", 15)
AA:AddNPCDeathSequence("models/antlion_guard.mdl", 44)
AA:AddNPCDeathSequence("models/hunter.mdl", 124)
AA:AddNPCDeathSequence("models/hunter.mdl", 125)
AA:AddNPCDeathSequence("models/hunter.mdl", 126)
AA:AddNPCDeathSequence("models/hunter.mdl", 127)
AA:AddNPCDeathSequence("models/hunter.mdl", 128)

AA:CreateSetting("friendlyfire", "Target teammates", false)
function AA:IsValidTarget(ent)
	// We only want players/NPCs.
	local typename = type(ent)
	if typename != "NPC" && typename != "Player" then return false end

	// No invalid entities.
	if !ValidEntity(ent) then return false end

	// Go shoot yourself, emo kid.
	local ply = LocalPlayer()
	if ent == ply then return false end

	if typename == "Player" then
		if !PlyM["Alive"](ent) then return false end // Dead players FTL.
		if !self:Setting("friendlyfire") && PlyM["Team"](ent) == PlyM["Team"](ply) then return false end
		if EntM["GetMoveType"](ent) == MOVETYPE_OBSERVER then return false end // No spectators.
		if EntM["GetMoveType"](ent) == MOVETYPE_NONE then return false end
		//if pl["Team"](ent) == 1001 then return false end
	end

	if typename == "NPC" then
		if EntM["GetMoveType"](ent) == MOVETYPE_NONE then return false end // No dead NPCs.

		// No dying NPCs.
		local model = string.lower(EntM["GetModel"](ent) or "")
		if table.HasValue(self.NPCDeathSequences[model] or {}, EntM["GetSequence"](ent)) then return false end
	end
end

AA:CreateSetting("predictblocked", "Predict blocked (time)", 0.4, {Min = 0, Max = 1})
function AA:BaseBlocked(target, offset)
	local ply = LocalPlayer()
	if !ValidEntity(ply) then return end
	
	// Trace from the players shootpos to the position.
	local shootPos = PlyM["GetShootPos"](ply)
	local targetPos = self:TargetPosition(target)
	
	if offset then targetPos = targetPos + offset end

	local trace = util.TraceLine({start = shootPos, endpos = targetPos, filter = {ply, target}, mask = MASK_SHOT})
	local wrongAim = self:AngleBetween(PlyM["GetAimVector"](ply), VecM["GetNormal"](targetPos - shootPos)) > 2

	// If we hit something, we're "blocked".
	if trace.Hit && trace.Entity != target then
		return true, wrongAim
	end

	// It is not blocked.
	return false, wrongAim
end
function AA:TargetBlocked(target)
	if !target then target = self:GetTarget() end
	if !target then return end
	
	local blocked, wrongAim = self:BaseBlocked(target)
	if self:Setting("predictblocked") > 0 && blocked then
		blocked = self:BaseBlocked(target, EntM["GetVelocity"](target) * self:Setting("predictblocked"))
	end
	return blocked, wrongAim
end
	

function AA:SetTarget(ent)
	if self.Target && !ent then
		self:CallHook("TargetLost")
	elseif !self.Target && ent then
		self:CallHook("TargetGained")
	elseif self.Target && ent && self.Target != ent then
		self:CallHook("TargetChanged")
	end

	self.Target = ent
end
function AA:GetTarget()
	if ValidEntity(self.Target) != false then
		return self.Target
	else
		return false
	end
end

AA:CreateSetting("maxangle", "Max angle", 30, {Min = 5, Max = 90})
AA:CreateSetting("targetblocked", "Don't check LOS", false)
AA:CreateSetting("holdtarget", "Hold targets", false)
function AA:FindTarget()
	if !self:Enabled() then return end

	local ply = LocalPlayer()
	if !ValidEntity(ply) then return end

	local maxAng = self:Setting("maxangle")
	local aimVec, shootPos = PlyM["GetAimVector"](ply), PlyM["GetShootPos"](ply)
	local targetBlocked = self:Setting("targetblocked")

	if self:Setting("holdtarget") then
		local target = self:GetTarget()
		if target then
			local targetPos = self:TargetPosition(target)
			local angle = self:AngleBetween(AngM["Forward"](self:GetView()), VecM["GetNormal"](targetPos - shootPos))
			local blocked = self:TargetBlocked(target)
			if angle <= maxAng && (!blocked || targetBlocked) then return end
		end
	end

	// Filter out targets.
	local targets = ents.GetAll()
	for i, ent in pairs(targets) do
		if self:IsValidTarget(ent) == false then
			targets[i] = nil
		end
	end

	local closestTarget, lowestAngle = _, maxAng
	for _, target in pairs(targets) do
		if targetBlocked || !self:TargetBlocked(target) then
			local targetPos = self:TargetPosition(target)
			local angle = self:AngleBetween(AngM["Forward"](self:GetView()), VecM["GetNormal"](targetPos - shootPos))

			if angle < lowestAngle then
				lowestAngle = angle
				closestTarget = target
			end
		end
	end

	self:SetTarget(closestTarget)
end
AA:AddHook("Think", "FindTarget")


// ##################################################
// Fake view
// ##################################################

AA.View = Angle(0, 0, 0)
function AA:GetView()
	return self.View * 1
end
function AA:KeepView()
	if !self:Enabled() then return end

	local ply = LocalPlayer()
	if !ValidEntity(ply) then return end

	self.View = EntM["EyeAngles"](ply)
end
AA:AddHook("OnToggled", "KeepView")

local sensitivity = 0.022
function AA:RotateView(cmd)
	self.View.p = math.Clamp(self.View.p + (CmdM["GetMouseY"](cmd) * sensitivity), -89, 89)
	self.View.y = math.NormalizeAngle(self.View.y + (CmdM["GetMouseX"](cmd) * sensitivity * -1))
end

AA:CreateSetting("debug", "Debug", false, {Show = false})
function AA:FakeView(ply, origin, angles, FOV)
	if !self:Enabled() && !self.SetAngleTo then return end
	if GetViewEntity() != LocalPlayer() then return end
	if self:Setting("debug") then return end
	
	local base = GAMEMODE:CalcView(ply, origin, self.SetAngleTo or self.View, FOV) or {}
			base.angles = base.angles or (self.AngleTo or self.View)
			base.angles.r = 0 // No crappy screen tilting in ZS.
	return base
end
AA:AddHook("CalcView", "FakeView")


function AA:TargetPrediction(ply, target, targetPos)
	local weap = PlyM["GetActiveWeapon"](ply)
	if ValidEntity(weap) then
		local class = EntM["GetClass"](weap)
		if class == "weapon_crossbow" then
			local dist = VecM["Length"](targetPos - PlyM["GetShootPos"](ply))
			local time = (dist / 3500) + 0.05 // About crossbow bolt speed.
			targetPos = targetPos + (EntM["GetVelocity"](target) * time)
		end
		
		local mul = 0.0075
		//targetPos = targetPos - (e["GetVelocity"](ply) * mul)
	end
	
	return targetPos
end
AA:AddHook("TargetPrediction", "TargetPrediction")

// ##################################################
// Aim
// ##################################################

function AA:SetAngle(ang)
	self.SetAngleTo = ang
end

AA:CreateSetting("smoothspeed", "Smooth aim speed (0 to disable)", 120, {Min = 0, Max = 360})
AA:CreateSetting("snaponfire", "Snap on fire", true)
AA:CreateSetting("snapgrace", "Snap on fire grace", 0.5, {Min = 0, Max = 3, Places = 1})
AA.LastAttack = 0
function AA:SetAimAngles(cmd)
	self:RotateView(cmd)

	if !self:Enabled() && !self.SetAngleTo then return end

	local ply = LocalPlayer()
	if !ValidEntity(ply) then return end

	// We're aiming with the view, normally.
	local targetAim = self:GetView()

	// If we have a target, aim at them!
	local target = self:GetTarget()
	if target then
		local targetPos = self:TargetPosition(target)
		targetAim = VecM["Angle"](targetPos - ply:GetShootPos())
	end

	// We're following the view, until we fire.
	if self:Setting("snaponfire") then
		local time = CurTime()
		if PlyM["KeyDown"](ply, IN_ATTACK) || PlyM["KeyDown"](ply, IN_ATTACK2) || self:Setting("autoshoot") != 0 then
			self.LastAttack = time
		end
		if CurTime() - self.LastAttack > self:Setting("snapgrace") then
			targetAim = self:GetView()
		end
	end

	// We want to change to whatever was SetAngle'd.
	if self.SetAngleTo then
		targetAim = self.SetAngleTo
	end

	// Smooth aiming.
	local smooth = self:Setting("smoothspeed")
	if smooth > 0 then
		local current = CmdM["GetViewAngles"](cmd)

		// Approach the target angle.
		current = self:ApproachAngle(current, targetAim, smooth * FrameTime())
		current.r = 0

		// If we're just following the view, we don't need to smooth it.
		if self.RevertingAim then
			local diff = self:NormalizeAngle(current - self:GetView())
			if math.abs(diff.p) < 1 && math.abs(diff.y) < 1 then self.RevertingAim = false end
		elseif targetAim == self:GetView() then
			current = targetAim
		end

		// Check if the angles are the same...
		if self.SetAngleTo then
			local diff = self:NormalizeAngle(current - self.SetAngleTo)
			if math.abs(diff.p) < 1 && math.abs(diff.y) < 1 then self.SetAngleTo = nil end
		end

		aim = current
	else
		aim = targetAim
		self.SetAngleTo = nil
	end

	// Set the angles.
	CmdM["SetViewAngles"](cmd, aim)
	local sensitivity = 0.22
	local diff = aim - CmdM["GetViewAngles"](cmd)
	CmdM["SetMouseX"](cmd, diff.y / sensitivity)
	CmdM["SetMouseY"](cmd, diff.p / sensitivity)
	

	// Change the players movement to be relative to their view instead of their aim.
	local move = Vector(CmdM["GetForwardMove"](cmd), CmdM["GetSideMove"](cmd), 0)
	local norm = VecM["GetNormal"](move)
	local set = AngM["Forward"](VecM["Angle"](norm) + (aim - self:GetView())) * VecM["Length"](move)
		CmdM["SetForwardMove"](cmd, set.x)
		CmdM["SetSideMove"](cmd, set.y)
end
AA:AddHook("CreateMove", "SetAimAngles")

function AA:RevertAim()
	self.RevertingAim = true
end
AA:AddHook("TargetLost", "RevertAim")
function AA:StopRevertAim()
	self.RevertingAim = false
end
AA:AddHook("TargetGained", "RevertAim")

// When we turn off the bot, we want our aim to go back to our view.
function AA:ViewToAim()
	if self:Enabled() then return end
	self:SetAngle(self:GetView())
end
AA:AddHook("OnToggled", "ViewToAim")


// ##################################################
// HUD
// ##################################################

AA:CreateSetting("crosshair", "Crosshair size (0 to disable)", 18, {Min = 0, Max = 20})
function AA:DrawTarget()
	if !self:Enabled() then return end

	local target = self:GetTarget()
	if !target then return end

	local size = self:Setting("crosshair")
	if size <= 0 then return end

	// Change colour on the block status.
	local blocked, aimOff = self:TargetBlocked()
	if blocked then
		surface.SetDrawColor(255, 0, 0, 255) // Red.
	elseif aimOff then
		surface.SetDrawColor(255, 255, 0, 255) // Yellow.
	else
		surface.SetDrawColor(0, 255, 0, 255) // Green.
	end

	// Get the onscreen coordinates for the target.
	local pos = self:TargetPosition(target)

	local screen = VecM["ToScreen"](pos)
	local x, y = screen.x, screen.y

	// Work out sizes.
	local a, b = size / 2, size / 6

	// Top left.
	surface.DrawLine(x - a, y - a, x - b, y - a)
	surface.DrawLine(x - a, y - a, x - a, y - b)

	// Bottom right.
	surface.DrawLine(x + a, y + a, x + b, y + a)
	surface.DrawLine(x + a, y + a, x + a, y + b)

	// Top right.
	surface.DrawLine(x + a, y - a, x + b, y - a)
	surface.DrawLine(x + a, y - a, x + a, y - b)

	// Bottom left.
	surface.DrawLine(x - a, y + a, x - b, y + a)
	surface.DrawLine(x - a, y + a, x - a, y + b)
end
AA:AddHook("HUDPaint", "DrawTarget")


AA.ScreenMaxAngle = {
	Length = 0,
	FOV = 0,
	MaxAngle = 0
}
AA:CreateSetting("draw_maxangle", "Draw Max Angle", true)
function AA:DrawMaxAngle()
	if !self:Enabled() then return end

	// Check that we want to be drawing this...
	local show = AA:Setting("draw_maxangle")
	if !show then return end

	// We need a player for this to work...
	local ply = LocalPlayer()
	if !ValidEntity(ply) then return end

	local info = self.ScreenMaxAngle
	local maxang = AA:Setting("maxangle")
	
	local fov = PlyM["GetFOV"](ply)
	if GetViewEntity() == ply && (maxang != info.MaxAngle || fov != info.FOV) then
		local view = self:GetView()
			view.p = view.p + maxang

		local screen = (PlyM["GetShootPos"](ply) + (AngM["Forward"](view) * 100))
		screen = VecM["ToScreen"](screen)

		info.Length = math.abs((ScrH() / 2) - screen.y)

		info.MaxAngle = maxang
		info.FOV = fov
	end

	local length = info.Length

	local cx, cy = ScrW() / 2, ScrH() / 2
	for x = -1, 1 do
		for y = -1, 1 do
			if x != 0 || y != 0 then
				local add = VecM["GetNormal"](Vector(x, y, 0)) * length
				surface.SetDrawColor(0, 0, 0, 255)
				surface.DrawRect((cx + add.x) - 2, (cy + add.y) - 2, 5, 5)
				surface.SetDrawColor(255, 255, 255, 255)
				surface.DrawRect((cx + add.x) - 1, (cy + add.y) - 1, 3, 3)
			end
		end
	end

end
AA:AddHook("HUDPaint", "DrawMaxAngle")

// ##################################################
// Auto-shoot
// ##################################################

AA.AttackDown = false
function AA:SetShooting(bool)
	if self.AttackDown == bool then return end
	self.AttackDown = bool

	local pre = {[true] = "+", [false] = "-"}
	RunConsoleCommand(pre[bool] .. "attack")
end

AA.NextShot = 0
AA:CreateSetting("autoshoot", "Max auto-shoot distance (0 to disable)", 0, {Min = 0, Max = 16384})
function AA:Shoot()
	if !self:Enabled() then
		self:SetShooting(false)
		return
	end

	// Get the maximum distance.
	local maxDist = self:Setting("autoshoot")
	if maxDist == 0 then return end

	// Check we've got something to shoot at...
	local target = self:GetTarget()
	if !target then return end
	
	// Don't shoot until we can hit, you idiot!
	local blocked, wrongAim = self:TargetBlocked(target)
	if blocked || wrongAim then return end

	// We're gonna need the player object in a second.
	local ply = LocalPlayer()
	if !ValidEntity(ply) then return end
	
	// Check we're within our maximum distance.
	local targetPos = self:TargetPosition(target)
	local distance = VecM["Length"](targetPos - ply:GetShootPos())
	if distance > maxDist && maxDist != -1 then return end

	// Check if it's time to shoot yet.
	if CurTime() < self.NextShot then return end

	// Check we got our weapon.
	local weap = PlyM["GetActiveWeapon"](ply)
	if !ValidEntity(weap) then return end

	// Shoot!
	self:SetShooting(true)
	// If we're semi-auto, we want to stop holding down fire.
	if self:IsSemiAuto(weap) then
		timer.Simple(0.05, function() self:SetShooting(false) end)
	end

	// Set the next time to shoot.
	self.NextShot = CurTime() + 0.1
end
AA:AddHook("Think", "Shoot")

// When we lose our target we stop shooting.
function AA:StopShooting()
	self:SetShooting(false)
end
AA:AddHook("TargetLost", "StopShooting")

// ##################################################
// Toggle
// ##################################################

AA.IsEnabled = false
function AA:Enabled() return self.IsEnabled end

function AA:SetEnabled(bool)
	if self.IsEnabled == bool then return end
	self.IsEnabled = bool

	local message = {[true] = "ON", [false] = "OFF"}
	print("AutoAim " .. message[self.IsEnabled])

	local e = {[true] = "1", [false] = "0"}
	RunConsoleCommand("aa_enabled", e[self.IsEnabled])

	self:CallHook("OnToggled")
end

function AA:Toggle()
	self:SetEnabled(!self:Enabled())
end
concommand.Add("aa_toggle", function() AA:Toggle() end)

AA:CreateSetting("enabled", "Enabled", false, {Save = false})
function AA:ConVarEnabled(_, old, val)
	if old == val then return end
	val = tonumber(val) or 0
	self:SetEnabled(val > 0)
end
AA:AddCVarHook("aa_enabled", "ConVarEnabled")

concommand.Add("+aa", function() AA:SetEnabled(true) end)
concommand.Add("-aa", function() AA:SetEnabled(false) end)

// ##################################################
// Menu
// ##################################################

function AA:OpenMenu()
	local w, h = ScrW() / 3, ScrH() / 2

	local menu = vgui.Create("DFrame")
	menu:SetTitle("AutoAim")
	menu:SetSize(w, h)
	menu:Center()
	menu:MakePopup()

	local scroll = vgui.Create("DPanelList", menu)
	scroll:SetPos(5, 25)
	scroll:SetSize(w - 10, h - 30)
	scroll:EnableVerticalScrollbar()

	local form = vgui.Create("DForm", menu)
	form:SetName("")
	form.Paint = function() end
	scroll:AddItem(form)

	self:BuildMenu(form)

	if AA.Menu then AA.Menu:Remove() end
	AA.Menu = menu
end
concommand.Add("aa_menu", function() AA:OpenMenu() end)

function AA:RegisterMenu()
	spawnmenu.AddToolMenuOption("Options", "Hacks", "AutoAim", "AutoAim", "", "", function(p) self:BuildMenu(p) end)
end
AA:AddHook("PopulateToolMenu", "RegisterMenu")

// ##################################################
// Useful functions
// ##################################################

function AA:AngleBetween(a, b)
	return math.deg(math.acos(VecM["Dot"](a, b)))
end

function AA:NormalizeAngle(ang)
	return Angle(math.NormalizeAngle(ang.p), math.NormalizeAngle(ang.y), math.NormalizeAngle(ang.r))
end

function AA:ApproachAngle(start, target, add)
	local diff = self:NormalizeAngle(target - start)

	local vec = Vector(diff.p, diff.y, diff.r)
	local len = VecM["Length"](vec)
	vec = VecM["GetNormal"](vec) * math.min(add, len)

	return start + Angle(vec.x, vec.y, vec.z)
end

local notAuto = {"weapon_pistol", "weapon_rpg", "weapon_357", "weapon_crossbow"}
function AA:IsSemiAuto(weap)
	if !ValidEntity(weap) then return end
	return (weap.Primary && !weap.Primary.Automatic) || table.HasValue(notAuto, EntM["GetClass"](weap))
end
