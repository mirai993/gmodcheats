--[[
	bobhack.lua
	Bob | (STEAM_0:0:34111703)
	===DStream===
]]

--Clientside Only--
if ( SERVER ) then return end




		LocalPlayer():PrintMessage( HUD_PRINTTALK, "[BobHack] Bob is best" )
		
	if GetConVarNumber("Sv_Cheats") == 1 then
	LocalPlayer():PrintMessage( HUD_PRINTTALK, "Sv_Cheats [On]" )
	else
	LocalPlayer():PrintMessage( HUD_PRINTTALK, "Sv_Cheats [Off]" )
	end
	if GetConVarNumber("Sv_ScriptEnforcer") == 1 || GetConVarNumber("Sv_ScriptEnforcer") == 2 then
	LocalPlayer():PrintMessage( HUD_PRINTTALK, "ScriptEnforcer [On]" )
	else
	LocalPlayer():PrintMessage( HUD_PRINTTALK, "ScriptEnforcer [Off]" )
	end


	
/* ConVars */ 

//ESP/
local EspCon = CreateClientConVar("bob_Esp","0", true , false)
local EspHealth = CreateClientConVar("bob_Esp_Health","0", true , false)
local EspDist = CreateClientConVar("bob_Esp_Distance","0", true , false)
local EspAdmin = CreateClientConVar("bob_Esp_Admin","0", true, false)
local Espwep = CreateClientConVar("bob_esp_wep", "0" ,true , false)

//Xray
local BobXRay = false
local BobXRayMat = CreateClientConVar( "Bob_xraymat", "xraysolid", true, false )
local BobXRayColors = {}
local BobXRayMats = {}
local repmat = CreateClientConVar("bob_xraymaterial", "mat2", true, false)
local FSetColor = _R.Entity.SetColor
local FSetMat = _R.Entity.SetMaterial




//Misc
CreateClientConVar( "bob_Crosshair", 0, true, false )
CreateClientConVar( "bob_barrelhack", 0, true, false )
CreateClientConVar( "bob_showip", 0, true, false )
CreateClientConVar( "bob_misc_admin", 0, true, false )
CreateClientConVar( "bob_misc_spectators", 0, true, false )
CreateClientConVar( "bob_keypadhack", 0, true, false )
CreateClientConVar( "bob_misc_Crosshair", 0, true, false )




//Balloonbot
CreateClientConVar( "", 0, true, false )
CreateClientConVar( "", 0, true, false )
CreateClientConVar( "", 0, true, false )





----------------------------------startofhack---------------------------------
	



---------------------------------esp------------------------------------------



Change = 0
function Changer()
if GetConVarNumber("bob_Esp_Health") == 0 then
 
Change = 0
 
else
 
Change = 10
 
        end
end
hook.Add("Think","Chak",Changer)
 
function Esp()
if EspCon:GetBool() then
	for _, v in pairs( player.GetAll() ) do
			if v:Alive() and v ~= LocalPlayer() then
local PlayerSpot = v:EyePos():ToScreen()
 
 
TeamColor = team.GetColor(v:Team())
 
surface.CreateFont("AR JULIAN",15,100,true,false, "HudSelectionText")
draw.SimpleText(v:Nick() , "HudSelectionText", PlayerSpot.x , PlayerSpot.y - 10 , surface.SetTextColor( Color(255 , 255 , 255 , 255 ) ) , TEXT_ALIGN_CENTER,TEXT_ALIGN_CENTER)

 
 	if Espwep:GetInt() > 0 and v:GetActiveWeapon():IsValid() then
					surface.SetTextColor( Color(255 , 255 , 255 , 255 ) )
					surface.SetFont( "HudSelectionText" )
					local add = 6
					if Espwep:GetInt() > 0 then add = 19 end
					surface.SetTextColor( Color(255 , 255 , 255 , 255 ) )
					surface.SetTextPos( PlayerSpot.x -20 , PlayerSpot.y - -15 )
					surface.DrawText( v:GetActiveWeapon():GetPrintName() )
				end
 
 
if  v:Alive() then
 
else
 
draw.SimpleText("-DEAD-","HudSelectionText",PlayerSpot.x, PlayerSpot.y - 20 , TeamColor , TEXT_ALIGN_CENTER,TEXT_ALIGN_CENTER)
       
        end
 
if EspHealth:GetBool() and v:Health() <= 100 then
 
local HealthBar = v:Health() / 2.5
 
surface.SetDrawColor(0,255,0,255)
surface.DrawOutlinedRect(PlayerSpot.x - 20,PlayerSpot.y - 3,40,4)
surface.DrawRect(PlayerSpot.x - 20,PlayerSpot.y - 3,HealthBar,4)
        end
 
if EspDist:GetBool() then
 
local distance = math.Round(v:GetPos():Distance(LocalPlayer():GetPos()))
draw.SimpleText(distance, "HudSelectionText", PlayerSpot.x , PlayerSpot.y + Change ,surface.SetTextColor( Color(255 , 255 , 255 , 255 ) ) , TEXT_ALIGN_CENTER,TEXT_ALIGN_CENTER)
 
 
                                end
                        end
                end
                        end
                                end
 
hook.Add("HUDPaint","ExtraSensoryPercept",Esp)
 
function Admindet()
if EspAdmin:GetBool() then
for k,v in pairs(player.GetAll()) do
if v!=LocalPlayer() then
if v:IsSuperAdmin() then
AdminS = v:EyePos():ToScreen()
 
draw.SimpleText("SuperAdmin","HudSelectionText", AdminS.x , AdminS.y - 30 , Color(255,0,0,255) , TEXT_ALIGN_CENTER,TEXT_ALIGN_CENTER)

elseif  v:IsAdmin() then
AdminS = v:EyePos():ToScreen()
 
draw.SimpleText("Admin","HudSelectionText", AdminS.x , AdminS.y - 30 , Color(255,0,0,255) , TEXT_ALIGN_CENTER,TEXT_ALIGN_CENTER)

elseif not v:IsAdmin() then
AdminS = v:EyePos():ToScreen()
 
draw.SimpleText("User","HudSelectionText", AdminS.x , AdminS.y - 30 , Color(255,0,0,255) , TEXT_ALIGN_CENTER,TEXT_ALIGN_CENTER)
 
                                end
                        end
                end
                        end
                                end
                               
hook.Add("HUDPaint","Superoctonopus",Admindet)


----------------------------------BOX-------------------------------------
--Credits to RabidToaster

local function PlyPos( ply )
local min, max = ply:OBBMins()
local max = ply:OBBMaxs()
 
local Spots = { Vector( min.x, min.y, min.z ), Vector( min.x, min.y, max.z ), Vector( min.x, max.y, min.z ), Vector( min.x, max.y, max.z ), Vector( max.x, min.y, min.z ), 
Vector( max.x, min.y, max.z ), Vector( max.x, max.y, min.z ), Vector( max.x, max.y, max.z ) }
 
local minX = ScrW() * 2
local minY = ScrH() * 2
local maxX = 0
local maxY = 0

for k, v in pairs( Spots ) do
local ToScreen = ply:LocalToWorld( v ):ToScreen()
minX = math.min( minX, ToScreen.x )
minY = math.min( minY, ToScreen.y )
maxX = math.max( maxX, ToScreen.x )
maxY = math.max( maxY, ToScreen.y )
end
return minX, minY, maxX, maxY
end

CreateClientConVar( "Bob_ESP_BoundingBox", 1, true, false )

hook.Add( "HUDPaint", "BoundingBoxTest", function()
if GetConVarNumber( "Bob_ESP_BoundingBox" ) >= 1 then
for k, v in pairs( player.GetAll() ) do
if v:Health() > 0 && v:Team() != TEAM_SPECTATOR then
if v != LocalPlayer() then

local x1, y1, x2, y2 = PlyPos(v)
local xy = { x1, y1, x2, y2 } 
  
local x1, y1, x2, y2 = unpack( xy )

surface.SetDrawColor( 255, 0, 0, 255 )

surface.DrawLine( x1, y1, math.min( x1 + 1510, x2 ), y1 )
surface.DrawLine( x1, y1, x1, math.min( y1 + 1510, y2 ) )
surface.DrawLine( x2, y1, math.max( x2 - 1510, x1 ), y1 ) 
surface.DrawLine( x2, y1, x2, math.min( y1 + 1510, y2 ) )
surface.DrawLine( x1, y2, math.min( x1 + 1510, x2 ), y2 ) 
surface.DrawLine( x1, y2, x1, math.max( y2 - 1510, y1 ) )
surface.DrawLine( x2, y2, math.max( x2 - 1510, x1 ), y2 ) 
surface.DrawLine( x2, y2, x2, math.max( y2 - 1510, y1 ) )
            end
         end
      end
   end
end )















------------------------------------------------Chams---------------------------------------------------------------------------------
 
local function BobMaterial()
 
local Texture = {
  ["$basetexture"] = "models/debug/debugwhite",
  ["$model"]       = 1,
  ["$translucent"] = 1,
  ["$alpha"]       = 1,
  ["$nocull"]      = 1,
  ["$ignorez"]  = 1
}
   
local material = CreateMaterial( "Bob_Solid", "VertexLitGeneric", Texture )
 
return material
 
end
 
CreateClientConVar( "Bob_ESP_Chams", 1, true, false )
 
local function BobChams()
local Div = ( 1 / 255 )
if GetConVarNumber( "Bob_ESP_Chams" ) >= 1 then
for k, v in pairs( player.GetAll() ) do
if ValidEntity( v ) and v:Health() > 0 || v:Alive() and v:Team() != TEAM_SPECTATOR then
cam.Start3D( EyePos(), EyeAngles() )
local TCol2 = team.GetColor( v:Team() )
local m = BobMaterial()
render.SuppressEngineLighting( true )
render.SetColorModulation( ( TCol2.r * Div ), ( TCol2.g * Div ), ( TCol2.b * Div ) )
SetMaterialOverride( m )
v:DrawModel()
render.SuppressEngineLighting( false )
render.SetColorModulation( 1, 1, 1 )
SetMaterialOverride()
v:DrawModel()
cam.End3D()
                        end
                end
        end
end
hook.Add( "RenderScreenspaceEffects", "BobChams", BobChams )
 
------------------------------------------------------------------------

--------------------L4DGlow---------------------------------------------

//Not Made By Me
//Credits to Jinto and blackops7799
 
local convar = CreateClientConVar( "Bob_ESP_L4DGlow", "1", true )
local teamcolors = CreateClientConVar( "Bob_ESP_L4D_TeamColors", "1", true )
local passes = CreateClientConVar( "Bob_ESP_L4D_Passes", "3", true )
 
local MaterialBlurX = Material( "pp/blurx" )
local MaterialBlurY = Material( "pp/blury" )
local MaterialWhite = CreateMaterial( "WhiteMaterial", "VertexLitGeneric", {
    ["$basetexture"] = "color/white",
    ["$vertexalpha"] = "1",
    ["$model"] = "1",
} )
local MaterialComposite = CreateMaterial( "CompositeMaterial", "UnlitGeneric", {
    ["$basetexture"] = "_rt_FullFrameFB",
    ["$additive"] = "1",
} )
 
// we need two render targets, if you don't want to create them yourself, you can
local RT1 = render.GetBloomTex0()
local RT2 = render.GetBloomTex1()
 
/*------------------------------------
    RenderGlow()
------------------------------------*/
local function RenderGlow( entity )
 
    // tell the stencil buffer we're going to write a value of one wherever the model
    // is rendered
    render.SetStencilEnable( true )
    render.SetStencilFailOperation( STENCILOPERATION_KEEP )
    render.SetStencilZFailOperation( STENCILOPERATION_REPLACE )
    render.SetStencilPassOperation( STENCILOPERATION_REPLACE )
    render.SetStencilCompareFunction( STENCILCOMPARISONFUNCTION_ALWAYS )
    render.SetStencilWriteMask( 1 )
    render.SetStencilReferenceValue( 1 )
     
    // this uses a small hack to render ignoring depth while not drawing color
    // i couldn't find a function in the engine to disable writing to the color channels
    // i did find one for shaders though, but I don't feel like writing a shader for this.
    cam.IgnoreZ( true )
        render.SetBlend( 0 )
            SetMaterialOverride( MaterialWhite )
                entity:DrawModel()
            SetMaterialOverride()
        render.SetBlend( 1 )
    cam.IgnoreZ( false )
     
    local w, h = ScrW(), ScrH()
     
    // draw into the white texture
    local oldRT = render.GetRenderTarget()
     
    render.SetRenderTarget( RT1 )
     
        render.SetViewPort( 0, 0, RT1:GetActualWidth(), RT1:GetActualHeight() )
         
        cam.IgnoreZ( true )
         
            render.SuppressEngineLighting( true )
             
            if teamcolors:GetBool() and entity:IsPlayer() then
             
                local color = team.GetColor( entity:Team() )
                render.SetColorModulation( color.r/255, color.g/255, color.b/255 )
                 
            elseif entity:IsPlayer() then
             
                local scale = math.Clamp( entity:Health() / 100, 0, 1 )
                local r,g,b = (255 - scale * 255), (55 + scale * 200), (50)
                render.SetColorModulation( r/255, g/255, b/255 )
                 
            else
             
                render.SetColorModulation( 1, 165/255, 0 )
                 
            end
             
                SetMaterialOverride( MaterialWhite )
                    entity:DrawModel()
                SetMaterialOverride()
                 
            render.SetColorModulation( 1, 1, 1 )
            render.SuppressEngineLighting( false )
             
        cam.IgnoreZ( false )
         
        render.SetViewPort( 0, 0, w, h )
    render.SetRenderTarget( oldRT )
     
    // don't need this for the next pass
    render.SetStencilEnable( false )
 
end
 
/*------------------------------------
    RenderScene()
------------------------------------*/
hook.Add( "RenderScene", "ResetGlow", function( Origin, Angles )
 
    local oldRT = render.GetRenderTarget()
    render.SetRenderTarget( RT1 )
        render.Clear( 0, 0, 0, 255, true )
    render.SetRenderTarget( oldRT )
     
end )
 
/*------------------------------------
    RenderScreenspaceEffects()
------------------------------------*/
hook.Add( "RenderScreenspaceEffects", "CompositeGlow", function()
 
    MaterialBlurX:SetMaterialTexture( "$basetexture", RT1 )
    MaterialBlurY:SetMaterialTexture( "$basetexture", RT2 )
    MaterialBlurX:SetMaterialFloat( "$size", 2 )
    MaterialBlurY:SetMaterialFloat( "$size", 2 )
         
    local oldRT = render.GetRenderTarget()
     
    for i = 1, passes:GetFloat() do
     
        // blur horizontally
        render.SetRenderTarget( RT2 )
        render.SetMaterial( MaterialBlurX )
        render.DrawScreenQuad()
 
        // blur vertically
        render.SetRenderTarget( RT1 )
        render.SetMaterial( MaterialBlurY )
        render.DrawScreenQuad()
         
    end
 
    render.SetRenderTarget( oldRT )
     
    // tell the stencil buffer we're only going to draw
    // where the player models are not.
    render.SetStencilEnable( true )
    render.SetStencilReferenceValue( 0 )
    render.SetStencilTestMask( 1 )
    render.SetStencilCompareFunction( STENCILCOMPARISONFUNCTION_EQUAL )
    render.SetStencilPassOperation( STENCILOPERATION_ZERO )
     
    // composite the scene
    MaterialComposite:SetMaterialTexture( "$basetexture", RT1 )
    render.SetMaterial( MaterialComposite )
    render.DrawScreenQuad()
 
    // don't need this anymore
    render.SetStencilEnable( false )
     
end )
 
local playerheldweap = nil
 
hook.Add( "PostPlayerDraw", "RenderEntityGlow", function( ply )
 
    if !convar:GetBool() then return end
 
    if( ScrW() == ScrH() ) then return end
 
    // prevent recursion
    if( OUTLINING_ENTITY ) then return end
    OUTLINING_ENTITY = true
     
    RenderGlow( ply )
     
    playerheldweap = ply:GetActiveWeapon()
     
    if IsValid( playerheldweap ) then
        RenderGlow( playerheldweap )
    end
     
    // prevents recursion time
    OUTLINING_ENTITY = false
         
end )

--------------------------------xray----------------------------------------
local BobXRay = false
local BobXRayMat = CreateClientConVar( "Bob_xraymat", "xraysolid", true, false )
local BobXRayColors = {}
local BobXRayMats = {}
local repmat = CreateClientConVar("bob_xraymaterial", "mat2", true, false)
local FSetColor = _R.Entity.SetColor
local FSetMat = _R.Entity.SetMaterial

-- XRAY

concommand.Add( "Bob_xray", function()
if !BobXRay then
surface.PlaySound("buttons/button19.wav") -- Alright, i'll show you where the sounds are.
for _, v in pairs( ents.GetAll() ) do
local r, g, b, a = v:GetColor()
BobXRayColors[ v:EntIndex() ] = Color( r, g, b, a )
BobXRayMats[ v:EntIndex() ] = v:GetMaterial()
if v:IsNPC() then
v:SetColor( 0, 0, 255, 255 )
elseif v:IsWeapon() then
v:SetColor( 150, 0, 255, 255 )
elseif string.find( v:GetClass(), "ghost" ) then
v:SetColor( 255, 255, 255, 100 )
elseif v:GetClass() == "drug_lab" or v:GetClass() == "money_printer" then
v:SetColor( 250, 50, 100, 50 )
elseif v:GetClass() == "viewmodel" then
v:SetColor( 50, 50, 250, 50 )
else
v:SetColor( 250, 250, 50, 100 )
end
v:SetMaterial( BobXRayMat:GetString() )
end
BobXRay = true
else
for _, v in pairs( ents.GetAll() ) do
local col = BobXRayColors[ v:EntIndex() ] or Color( 255, 255, 255, 255 )
v:SetMaterial( BobXRayMats[ v:EntIndex() ] )
v:SetColor( col.r, col.g, col.b, col.a )
BobXRay = false
end
end
if BobXRay then
surface.PlaySound("") -- When you turn it off, it will play this.
end
end )

local function BobRenderScene()
if BobXRay == false then return end
for _, v in pairs( ents.FindByClass( "prop_physics" ) ) do
if ValidEntity( v ) then
v:SetColor( 50, 255, 0, 255 )-- <------ Change that color if you like too.
v:SetMaterial( BobXRayMat:GetString() )
end

end
for _, v in pairs( player.GetAll() ) do
if ValidEntity( v ) then
v:SetColor( 255, 0, 0, 255 ) --
v:SetMaterial( BobXRayMat:GetString() )

		end
	end
end
hook.Add( "RenderScene", "Bob", BobRenderScene )
-- You didn't put the other player color ? Like, admin and all ? I'll do it




local PropPathOn = CreateClientConVar( "Bob_xray_proppath", "1", true, false )
local SpeedOn = CreateClientConVar( "Bob_xray_speedometer", "0", true, false )

local function PaintThings()
	if not BobXRay then return end
	for k,v in pairs( ents.GetAll() ) do
		if v:IsValid() and v:GetVelocity():Length() > 60 and v:GetClass() == "prop_physics" and PropPathOn:GetBool() then
			local PropCenter = v:OBBCenter()
			local propTrace = {}
			propTrace.start = v:LocalToWorld( v:OBBCenter() )
			propTrace.endpos = v:LocalToWorld( v:OBBCenter() ) + v:GetVelocity() * Vector( 10000, 10000, 10000 )
			propTrace.filter = v
			local DoPropLine = util.TraceLine( propTrace )
			cam.Start3D( EyePos() , EyeAngles() )
				render.SetMaterial( Material( "cable/redlaser" ) )
				render.DrawBeam( DoPropLine.StartPos, DoPropLine.HitPos, 50, 0, 0, Color( 255,255,255,255 ) )
			cam.End3D()
		end
		if v:IsValid() and v:GetClass() == "prop_physics" then
			local propradius = ents.FindInSphere( v:LocalToWorld( v:OBBCenter() ), 60 )
			for a,b in pairs( propradius ) do
				if b:IsPlayer() and b:Alive() then
					--draw.DrawText( "Prop near " .. b:Nick(), "Trebuchet24", ScrW()/2, 75, Color( 255, 255, 255, 255 ), 1 )
				end
			end
		end
	end
		if SpeedOn:GetBool() then
		local speedy = LocalPlayer():GetVelocity():Length()
		draw.SimpleTextOutlined( "Speed: " .. tostring( math.Round( speedy * 3600 / 63360 * 0.75 ) ) .. "mph", "Trebuchet24", ScrW()/2, 25, Color( 0, 0, 0, 255 ), 1, 1, 1, Color( 255, 255, 255, 150 ) )
	end
end
hook.Add( "HUDPaint", "paintthings", PaintThings )

---------------------------------------------







----------------------misc---------------------------------

--Adminlist--
local badmins = false
hook.Add("HUDPaint", "badmins", function()
	if GetConVarNumber( "bob_misc_admin" ) <= 0 then return end
	local badmins = {}
	local x = 0
	for k,v in pairs(player.GetAll()) do
		if v:IsAdmin() then 
			table.insert(badmins, v:Name())
		end
	end
	local textLength = surface.GetTextSize(table.concat(badmins) ) / 3
	draw.RoundedBox(1, ScrW() - 350, ScrH() - ScrH() + 15, 150, 30 + textLength, Color(0,0,0,150))
	draw.SimpleText("Admins", "ScoreboardText", ScrW() - 300, ScrH() - ScrH() + 16, Color(0, 0, 0, 150))
	draw.SimpleText("Admins", "ScoreboardText", ScrW() - 300, ScrH() - ScrH() + 17, Color(0, 255, 0))

	for k, v in pairs(badmins) do
        draw.SimpleText(v, "ScoreboardText", ScrW() - 300, ScrH() - ScrH() + 35 + x, Color(255, 255, 255, 255))
        x = x + 15
    end
end)



--Spectators--
local showSpectators = false
hook.Add("HUDPaint", "showspectators", function()
	if GetConVarNumber( "bob_misc_spectators" ) <= 0 then return end
	local spectatePlayers = {}
	local x = 0
	for k,v in pairs(player.GetAll()) do
		if v:GetObserverTarget() == LocalPlayer() then 
			table.insert(spectatePlayers, v:Name())
		end
	end
	local textLength = surface.GetTextSize(table.concat(spectatePlayers) ) / 3
	draw.RoundedBox(1, ScrW() - 180, ScrH() - ScrH() + 15, 150, 30 + textLength, Color(0,0,0,150))
	draw.SimpleText("Spectators", "ScoreboardText", ScrW() - 140, ScrH() - ScrH() + 17, Color(0, 0, 0, 150))
	draw.SimpleText("Spectators", "ScoreboardText", ScrW() - 140, ScrH() - ScrH() + 16, Color(0, 255, 0))

	for k, v in pairs(spectatePlayers) do
        draw.SimpleText(v, "ScoreboardText", ScrW() - 140, ScrH() - ScrH() + 35 + x, Color(255, 255, 255, 255))
        x = x + 15
    end
end)



---------------crashes----------------


function bc()

	RunConsoleCommand("adv_duplicator_angle", "9999999999999999999");
	RunConsoleCommand("adv_duplicator_height", "999999999999999999")

	chat.AddText(
Color(255,0,0,255), "Crash is activated ",
Color(255,0,0,255), "",
Color(255,0,0,255), "" )
end
concommand.Add("bobcrashon", bc)

function bc()

	RunConsoleCommand("adv_duplicator_angle", "0");
	RunConsoleCommand("adv_duplicator_height", "0")
	chat.AddText(
Color(255,0,0,255), "Crash is deactivated ",
Color(255,0,0,255), "",
Color(255,0,0,255), "" )
end
concommand.Add("bobcrashoff", bc)











--------------------------barrelhack-----------------------------------

function _R.Player:GetMuzzlePos()
	if self and self:IsValid() then
		if self:GetActiveWeapon() != nil then
			local wep = self:GetActiveWeapon()
			if wep and wep:IsValid() then
				local ViewModel = self:GetViewModel()
				if ViewModel != nil and ViewModel:IsValid() then
					local attach = ViewModel:LookupAttachment("muzzle")
					if attach > 0 then
						local pos = ViewModel:GetAttachment(attach).Pos
						return pos
					end
				end
			end
		end
	end
	return self:EyePos()
end






local BobBh = CreateClientConVar("bob_misc_barrel", "0" ,true , false)

function Barrelhax() 
if BobBh:GetBool() then
for k, v in pairs(player.GetAll()) do
			if v != nil then
				if v and v:IsValid() and v:Alive() then
					cam.Start3D(EyePos(), EyeAngles())
						render.SetMaterial( Material( "sprites/bluelaser1" ) )
						if v == LocalPlayer() then
							render.DrawBeam(v:GetMuzzlePos(), v:GetEyeTrace().HitPos, 10, 1, 1, Color(0, 255, 255, 255))
						else
							local pos = v:EyePos()
							if v:GetBonePosition(v:LookupBone("ValveBiped.Bip01_Head1")) != nil then
								pos = v:GetBonePosition(v:LookupBone("ValveBiped.Bip01_Head1"))
							end
							if v:GetMuzzlePos() != v:EyePos() then
								render.DrawBeam(v:GetMuzzlePos(), v:GetEyeTrace().HitPos, 25, 1, 1, Color(0, 255, 0, 255))
							else
								render.DrawBeam(pos, v:GetEyeTrace().HitPos, 25, 1, 1, Color(0, 255, 0, 255))
							end
						end
					cam.End3D()
				end
			end
		end
	end
 
 	for k,v in pairs( player.GetAll() ) do
		if v:IsValid() and v:IsPlayer() and v:Alive() and BobBh:GetBool() and v != LocalPlayer() then
			local skytrace = {}
			skytrace.start = v:GetShootPos()
			skytrace.endpos = v:GetShootPos() + Vector( 0, 0, 10000 )
			skytrace.filter = v
			local doskytrace = util.TraceLine( skytrace )
			cam.Start3D( EyePos() , EyeAngles() )
				render.SetMaterial( Material( "cable/redlaser" ) )
				render.DrawBeam( v:GetShootPos(), doskytrace.HitPos, 25, 0, 0, Color( 255,255,255,255 ) )
			cam.End3D()
		end
	end
	end

 
 hook.Add("HUDPaint","Specline", Barrelhax)
 
 
 
 -------------crosshair-----

function Crosshair()
if GetConVarNumber( "bob_misc_Crosshair" ) >= 1 then
surface.SetDrawColor(97,255,0,255)
surface.DrawLine(ScrW() / 2 - 5, ScrH() / 2, ScrW() / 2 + 5 , ScrH() / 2)
surface.DrawLine(ScrW() / 2 - 0, ScrH() / 2 - 5, ScrW() / 2 - 0 , ScrH() / 2 + 5)
        end
end
hook.Add("HUDPaint","CustomCross",Crosshair)
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 -----------------------------------------------------------------






















/////////////////////
// **Derma menu** //
///////////////////

/// Derma ///

local function ShowFrame()

Frame = vgui.Create("DFrame")
Frame:SetSize( 350 , 300 )
Frame:SetPos( ScrW() / 2 - Frame:GetWide() / 2 , ScrH() / 2 - Frame:GetTall() / 2  )
Frame:SetTitle("Bob Hack")
Frame:SetVisible( true )
Frame:ShowCloseButton( true )
Frame.Paint = function()
	draw.RoundedBox( 8, 0, 0, Frame:GetWide(), Frame:GetTall(), Color( 0, 0, 0, 190 ) )
end
Frame:MakePopup()

local BSheet = vgui.Create("DPropertySheet" , Frame)
BSheet:SetSize( 340 , 265 )
BSheet:SetPos( 5 , 25 )
BSheet.Paint = function()
	draw.RoundedBox( 8, 0, 0, BSheet:GetWide(), BSheet:GetTall(), Color( 0, 0, 0, 190 ) )
end

local Tab = vgui.Create("DLabel")
Tab:SetParent( BSheet )
Tab:SetPos( 0 , 10 )
Tab:SetText("")

local Tab2 = vgui.Create("DLabel")
Tab2:SetParent( BSheet )
Tab2:SetPos( 0 , 10 )
Tab2:SetText("")

local Tab3 = vgui.Create("DLabel")
Tab3:SetParent( BSheet )
Tab3:SetPos( 0 , 10 )
Tab3:SetText("")

local Tab4 = vgui.Create("DLabel")
Tab4:SetParent( BSheet )
Tab4:SetPos( 0 , 10 )
Tab4:SetText("")

local Tab5 = vgui.Create("DLabel")
Tab5:SetParent( BSheet )
Tab5:SetPos( 0 , 10 )
Tab5:SetText("")



// Options

local ESPLabel = vgui.Create("DLabel")
ESPLabel:SetParent( Tab )
ESPLabel:SetPos( 13 , 10 )
ESPLabel:SetText("")
ESPLabel:SetTextColor( Color(255 , 255 , 255 , 255 ) )
ESPLabel:SizeToContents()

local ESPLabel2 = vgui.Create("DLabel")
ESPLabel2:SetParent( Tab )
ESPLabel2:SetPos( 13 , 70 )
ESPLabel2:SetText("")
ESPLabel2:SetTextColor( Color(255 , 255 , 255 , 255 ) )
ESPLabel2:SizeToContents()

local ESPLabel3 = vgui.Create("DLabel")
ESPLabel3:SetParent( Tab )
ESPLabel3:SetPos( 206 , 10 )
ESPLabel3:SetText("")
ESPLabel3:SetTextColor( Color(255 , 255 , 255 , 255 ) )
ESPLabel3:SizeToContents()

local ESPLabel4 = vgui.Create("DLabel")
ESPLabel4:SetParent( Tab )
ESPLabel4:SetPos( 13 , 130  )
ESPLabel4:SetText("")
ESPLabel4:SetTextColor( Color(255 , 255 , 255 , 255 ) )
ESPLabel4:SizeToContents()

local ESPLabel5 = vgui.Create("DLabel")
ESPLabel5:SetParent( Tab )
ESPLabel5:SetPos( 118.5 , 235 )
ESPLabel5:SetText("")
ESPLabel5:SetTextColor( Color(255 , 255 , 255 , 255 ) )
ESPLabel5:SizeToContents()

local ESP3 = vgui.Create( "DCheckBoxLabel")
ESP3:SetText( "LESP ESP" )
ESP3:SetConVar( "lix_lesp_on" ) 
ESP3:SetParent( Tab )
ESP3:SetPos( 10 , 30 )
ESP3:SetValue( GetConVarNumber("lix_lesp_on") )
ESP3:SetTextColor( Color(255 , 255 , 255 , 255 ) )
ESP3:SizeToContents() 

local ESP4 = vgui.Create( "DCheckBoxLabel")
ESP4:SetText( "Bob ESP" )
ESP4:SetConVar( "Bob_esp" ) 
ESP4:SetParent( Tab )
ESP4:SetPos( 10 , 50 )
ESP4:SetValue( GetConVarNumber("bob_esp") )
ESP4:SetTextColor( Color(255 , 255 , 255 , 255 ) )
ESP4:SizeToContents() 

local ESP5 = vgui.Create( "DCheckBoxLabel")
ESP5:SetText( "ESP Box" )
ESP5:SetConVar( "Bob_ESP_BoundingBox" ) 
ESP5:SetParent( Tab )
ESP5:SetPos( 10 , 70 )
ESP5:SetValue( GetConVarNumber("Bob_ESP_BoundingBox") )
ESP5:SetTextColor( Color(255 , 255 , 255 , 255 ) )
ESP5:SizeToContents() 

local ESP6 = vgui.Create( "DCheckBoxLabel")
ESP6:SetText( "Show Rank" )
ESP6:SetConVar( "bob_Esp_Admin" ) 
ESP6:SetParent( Tab )
ESP6:SetPos( 10 , 90 )
ESP6:SetValue( GetConVarNumber( 'bob_Esp_Admin' ) );
ESP6:SetTextColor( Color(255 , 255 , 255 , 255 ) )
ESP6:SizeToContents() 

local ESP6 = vgui.Create( "DCheckBoxLabel")
ESP6:SetText( "HP bar" )
ESP6:SetConVar( "bob_Esp_Health" ) 
ESP6:SetParent( Tab )
ESP6:SetPos( 10 , 110 )
ESP6:SetValue( GetConVarNumber( 'bob_Esp_Health' ) );
ESP6:SetTextColor( Color(255 , 255 , 255 , 255 ) )
ESP6:SizeToContents() 

local ESP6 = vgui.Create( "DCheckBoxLabel")
ESP6:SetText( "Distance" )
ESP6:SetConVar( "bob_Esp_Distance" ) 
ESP6:SetParent( Tab )
ESP6:SetPos( 10 , 130 )
ESP6:SetValue( GetConVarNumber( 'bob_Esp_Distance' ) );
ESP6:SetTextColor( Color(255 , 255 , 255 , 255 ) )
ESP6:SizeToContents() 

local ESP6 = vgui.Create( "DCheckBoxLabel")
ESP6:SetText( "Show weapon" )
ESP6:SetConVar( "bob_esp_wep" ) 
ESP6:SetParent( Tab )
ESP6:SetPos( 10 , 150 )
ESP6:SetValue( GetConVarNumber( 'bob_esp_wep' ) );
ESP6:SetTextColor( Color(255 , 255 , 255 , 255 ) )
ESP6:SizeToContents() 




local EspLabel = vgui.Create("DLabel")
EspLabel:SetParent( Tab2 )
EspLabel:SetPos( 180 , 10 )
EspLabel:SetText("Additional FalcoXray options")
EspLabel:SetTextColor( Color(255 , 255 , 255 , 255 ) )
EspLabel:SizeToContents()

local EspLabel2 = vgui.Create("DLabel")
EspLabel2:SetParent( Tab2 )
EspLabel2:SetPos( 13 , 90 )
EspLabel2:SetText("")
EspLabel2:SetTextColor( Color(255 , 255 , 255 , 255 ) )
EspLabel2:SizeToContents()

local EspLabel3 = vgui.Create("DLabel")
EspLabel3:SetParent( Tab2 )
EspLabel3:SetPos( 200 , 10 )
EspLabel3:SetText("")
EspLabel3:SetTextColor( Color(255 , 255 , 255 , 255 ) )
EspLabel3:SizeToContents()



				local Esp6 = vgui.Create( "DButton", window )
		Esp6:SetSize( 100, 30 )
	Esp6:SetPos( 10, 10 )
	Esp6:SetParent( Tab2 )
	Esp6:SetText( "BobXray" )
	Esp6.DoClick = function( button )
		RunConsoleCommand("Bob_xray")
		end



		
				local Esp6 = vgui.Create( "DButton", window )
		Esp6:SetSize( 100, 30 )
	Esp6:SetPos( 10, 45 )
	Esp6:SetParent( Tab2 )
	Esp6:SetText( "FalcoXray" )
	Esp6.DoClick = function( button )
		RunConsoleCommand("Falco_xray")
		end

local Esp4 = vgui.Create( "DCheckBoxLabel")
Esp4:SetText( "Chams" )
Esp4:SetConVar( "Bob_ESP_Chams" ) 
Esp4:SetParent( Tab2 )
Esp4:SetPos( 10 , 80 )
Esp4:SetValue( GetConVarNumber("Bob_ESP_Chams") )
Esp4:SetTextColor( Color(255 , 255 , 255 , 255 ) )
Esp4:SizeToContents() 

local Esp5 = vgui.Create( "DCheckBoxLabel")
Esp5:SetText( "L4D Glow" )
Esp5:SetConVar( "Bob_ESP_L4DGlow" ) 
Esp5:SetParent( Tab2 )
Esp5:SetPos( 10 , 100 )
Esp5:SetValue( GetConVarNumber("Bob_ESP_L4DGlow") )
Esp5:SetTextColor( Color(255 , 255 , 255 , 255 ) )
Esp5:SizeToContents() 

local Esp5 = vgui.Create( "DCheckBoxLabel")
Esp5:SetText( "L4D TeamColours" )
Esp5:SetConVar( "Bob_ESP_L4D_TeamColors" ) 
Esp5:SetParent( Tab2 )
Esp5:SetPos( 10 , 120 )
Esp5:SetValue( GetConVarNumber("Bob_ESP_L4D_TeamColors") )
Esp5:SetTextColor( Color(255 , 255 , 255 , 255 ) )
Esp5:SizeToContents() 

local xray5 = vgui.Create( "DCheckBoxLabel")
xray5:SetText( "HidePhysgun" )
xray5:SetConVar( "xray_hidephysgun" ) 
xray5:SetParent( Tab2 )
xray5:SetPos( 180 , 30 )
xray5:SetValue( GetConVarNumber("xray_hidephysgun") )
xray5:SetTextColor( Color(255 , 255 , 255 , 255 ) )
xray5:SizeToContents()

local xray5 = vgui.Create( "DCheckBoxLabel")
xray5:SetText( "PropPath" )
xray5:SetConVar( "xray_proppath" ) 
xray5:SetParent( Tab2 )
xray5:SetPos( 180 , 50 )
xray5:SetValue( GetConVarNumber("xray_proppath") )
xray5:SetTextColor( Color(255 , 255 , 255 , 255 ) )
xray5:SizeToContents()

local xray5 = vgui.Create( "DCheckBoxLabel")
xray5:SetText( "PropSounds" )
xray5:SetConVar( "xray_propsounds" ) 
xray5:SetParent( Tab2 )
xray5:SetPos( 180 , 70 )
xray5:SetValue( GetConVarNumber("xray_propsounds") )
xray5:SetTextColor( Color(255 , 255 , 255 , 255 ) )
xray5:SizeToContents()

local xray5 = vgui.Create( "DCheckBoxLabel")
xray5:SetText( "PropSpawnSounds" )
xray5:SetConVar( "xray_propspawnsound" ) 
xray5:SetParent( Tab2 )
xray5:SetPos( 180 , 90 )
xray5:SetValue( GetConVarNumber("xray_propspawnsound") )
xray5:SetTextColor( Color(255 , 255 , 255 , 255 ) )
xray5:SizeToContents()

local xray5 = vgui.Create( "DCheckBoxLabel")
xray5:SetText( "HeadLaser" )
xray5:SetConVar( "xray_skyboxtrace" ) 
xray5:SetParent( Tab2 )
xray5:SetPos( 180 , 110 )
xray5:SetValue( GetConVarNumber("xray_skyboxtrace") )
xray5:SetTextColor( Color(255 , 255 , 255 , 255 ) )
xray5:SizeToContents()

local xray5 = vgui.Create( "DCheckBoxLabel")
xray5:SetText( "Speedometer" )
xray5:SetConVar( "xray_speedometer" ) 
xray5:SetParent( Tab2 )
xray5:SetPos( 180 , 130 )
xray5:SetValue( GetConVarNumber("xray_speedometer") )
xray5:SetTextColor( Color(255 , 255 , 255 , 255 ) )
xray5:SizeToContents()

local xray5 = vgui.Create( "DCheckBoxLabel")
xray5:SetText( "TeamColours" )
xray5:SetConVar( "xray_teamcolors" ) 
xray5:SetParent( Tab2 )
xray5:SetPos( 180 , 150 )
xray5:SetValue( GetConVarNumber("xray_teamcolors") )
xray5:SetTextColor( Color(255 , 255 , 255 , 255 ) )
xray5:SizeToContents()

local MiscLabel = vgui.Create("DLabel")
MiscLabel:SetParent( Tab3 )
MiscLabel:SetPos( 13 , 10 )
MiscLabel:SetText("Misc Features")
MiscLabel:SetTextColor( Color(255 , 255 , 255 , 255 ) )
MiscLabel:SizeToContents()

local MiscLabel2 = vgui.Create("DLabel")
MiscLabel2:SetParent( Tab3 )
MiscLabel2:SetPos( 205 , 10 )
MiscLabel2:SetText("Console Commands")
MiscLabel2:SetTextColor( Color(255 , 255 , 255 , 255 ) )
MiscLabel2:SizeToContents()

local Misc = vgui.Create( "DButton", window )
		Misc:SetSize( 100, 30 )
	Misc:SetPos( 205, 10 )
	Misc:SetParent( Tab3 )
	Misc:SetText( "CrashOn" )
	Misc.DoClick = function( button )
		RunConsoleCommand("bobcrashon")
		end


	local Misc = vgui.Create( "DButton", window )
		Misc:SetSize( 100, 30 )
	Misc:SetPos( 205, 50 )
	Misc:SetParent( Tab3 )
	Misc:SetText( "CrashOff" )
	Misc.DoClick = function( button )
		RunConsoleCommand("bobcrashoff")
		end

 

local Misc3 = vgui.Create( "DCheckBoxLabel")
Misc3:SetText( "Show Admin list" )
Misc3:SetConVar( "Bob_misc_admin" ) 
Misc3:SetParent( Tab3 )
Misc3:SetPos( 10 , 30 )
Misc3:SetValue( GetConVarNumber("Bob_misc_admin") )
Misc3:SetTextColor( Color(255 , 255 , 255 , 255 ) )
Misc3:SizeToContents() 

local Misc4 = vgui.Create( "DCheckBoxLabel")
Misc4:SetText( "Show Rope" )
Misc4:SetConVar( "rope_rendersolid") 
Misc4:SetParent( Tab3 )
Misc4:SetPos( 10 , 70 )
Misc4:SetValue( GetConVarNumber("rope_rendersolid") )
Misc4:SetTextColor( Color(255 , 255 , 255 , 255 ) )
Misc4:SizeToContents() 

local Misc5 = vgui.Create( "DCheckBoxLabel")
Misc5:SetText( "Show Spectator list" )
Misc5:SetConVar( "bob_misc_spectators" ) 
Misc5:SetParent( Tab3 )
Misc5:SetPos( 10 , 50 )
Misc5:SetValue( GetConVarNumber("bob_misc_spectators") )
Misc5:SetTextColor( Color(255 , 255 , 255 , 255 ) )
Misc5:SizeToContents() 

local Misc5 = vgui.Create( "DCheckBoxLabel")
Misc5:SetText( "Disable anti light crash" )
Misc5:SetConVar( "sec_showlights" ) 
Misc5:SetParent( Tab3 )
Misc5:SetPos( 10 , 90 )
Misc5:SetValue( GetConVarNumber("sec_showlights") )
Misc5:SetTextColor( Color(255 , 255 , 255 , 255 ) )
Misc5:SizeToContents() 

local Misc5 = vgui.Create( "DCheckBoxLabel")
Misc5:SetText( "Barrelhack" )
Misc5:SetConVar( "bob_misc_barrel" ) 
Misc5:SetParent( Tab3 )
Misc5:SetPos( 10 , 110 )
Misc5:SetValue( GetConVarNumber("bob_misc_barrel") )
Misc5:SetTextColor( Color(255 , 255 , 255 , 255 ) )
Misc5:SizeToContents() 

local ESPLabel = vgui.Create("DLabel")
ESPLabel:SetParent( Tab5 )
ESPLabel:SetPos( 13 , 10 )
ESPLabel:SetText("")
ESPLabel:SetTextColor( Color(255 , 255 , 255 , 255 ) )
ESPLabel:SizeToContents()

local ESPLabel2 = vgui.Create("DLabel")
ESPLabel2:SetParent( Tab5 )
ESPLabel2:SetPos( 13 , 70 )
ESPLabel2:SetText("")
ESPLabel2:SetTextColor( Color(255 , 255 , 255 , 255 ) )
ESPLabel2:SizeToContents()

local ESPLabel3 = vgui.Create("DLabel")
ESPLabel3:SetParent( Tab5 )
ESPLabel3:SetPos( 206 , 10 )
ESPLabel3:SetText("")
ESPLabel3:SetTextColor( Color(255 , 255 , 255 , 255 ) )
ESPLabel3:SizeToContents()

local ESPLabel4 = vgui.Create("DLabel")
ESPLabel4:SetParent( Tab5 )
ESPLabel4:SetPos( 13 , 130  )
ESPLabel4:SetText("")
ESPLabel4:SetTextColor( Color(255 , 255 , 255 , 255 ) )
ESPLabel4:SizeToContents()

local ESPLabel5 = vgui.Create("DLabel")
ESPLabel5:SetParent( Tab5 )
ESPLabel5:SetPos( 118.5 , 235 )
ESPLabel5:SetText("VoltageHack [V2] Beta")
ESPLabel5:SetTextColor( Color(255 , 255 , 255 , 255 ) )
ESPLabel5:SizeToContents()

local ESP3 = vgui.Create( "DCheckBoxLabel")
ESP3:SetText( "highfive_red" )
ESP3:SetConVar( "" ) 
ESP3:SetParent( Tab5 )
ESP3:SetPos( 10 , 30 )
ESP3:SetValue( GetConVarNumber( "" ) )
ESP3:SetTextColor( Color(255 , 255 , 255 , 255 ) )
ESP3:SizeToContents() 

local ESP4 = vgui.Create( "DCheckBoxLabel")
ESP4:SetText( "" )
ESP4:SetConVar( "" ) 
ESP4:SetParent( Tab5 )
ESP4:SetPos( 10 , 50 )
ESP4:SetValue( GetConVarNumber("") )
ESP4:SetTextColor( Color(255 , 255 , 255 , 255 ) )
ESP4:SizeToContents() 

local ESP5 = vgui.Create( "DCheckBoxLabel")
ESP5:SetText( "Neon ESP all" )
ESP5:SetConVar( "Neon_PlayerESP_ShowAll" ) 
ESP5:SetParent( Tab5 )
ESP5:SetPos( 10 , 70 )
ESP5:SetValue( GetConVarNumber("Neon_PlayerESP_ShowAll") )
ESP5:SetTextColor( Color(255 , 255 , 255 , 255 ) )
ESP5:SizeToContents() 

local ESP6 = vgui.Create( "DCheckBoxLabel")
ESP6:SetText( "Neon box" )
ESP6:SetConVar( "Neon_PlayerBox" ) 
ESP6:SetParent( Tab5 )
ESP6:SetPos( 10 , 90 )
ESP6:SetValue( GetConVarNumber( 'Neon_PlayerBox' ) );
ESP6:SetTextColor( Color(255 , 255 , 255 , 255 ) )
ESP6:SizeToContents() 

local ESP6 = vgui.Create( "DCheckBoxLabel")
ESP6:SetText( "Neon HP bar" )
ESP6:SetConVar( "Neon_PlayerESP_Health" ) 
ESP6:SetParent( Tab5 )
ESP6:SetPos( 10 , 110 )
ESP6:SetValue( GetConVarNumber( 'Neon_PlayerESP_Health' ) );
ESP6:SetTextColor( Color(255 , 255 , 255 , 255 ) )
ESP6:SizeToContents() 







BSheet:AddSheet( "ESP", Tab, "gui/silkicons/star", false, false, "ESP" )
BSheet:AddSheet( "Xray", Tab2, "gui/silkicons/check_on", false, false, "ESP" )
BSheet:AddSheet( "Misc", Tab3, "gui/silkicons/world", false, false, "Misc" )
BSheet:AddSheet( "Aimbot", Tab4, "gui/silkicons/wrench", false, false, "Gotta go fast" )
BSheet:AddSheet( "Rope/Elastics", Tab5, "gui/silkicons/wrench", false, false, "All your rope and elastics" )
end
concommand.Add("+Bob_menu",ShowFrame)
concommand.Add("-Bob_menu",function()
Frame:SetVisible( false )
end)

concommand.Add("Bob_MENU_RELOAD",function()
ShowFrame()
end)

