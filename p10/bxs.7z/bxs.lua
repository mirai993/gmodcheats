// updated, cheat got some more paste! epic

local me = LocalPlayer()

local config = {}
config.clrs = {}
config.binds = {}

config["Aimbot"] = false
config["AimHitbox"] = 1
config["Autofire"] = false
config.binds["AimKey"] = 0
config["AimFOV"] = 5
config["AimSmoothness"] = 0
config["RapidFire"] = false
config["NoSpread"] = false
config["FovCircle"] = false
config["IgnorePlayers"] = false
config["IgnoreNPCs"] = false
config["IgnoreBots"] = false
config["IgnoreTeam"] = false
config["IgnoreFriends"] = false
config["IgnoreNoclip"] = true
config["IgnoreGodmode"] = true

config["Visuals"] = false
config["Box"] = false
config["BoxFilled"] = false
config["3DBox"] = false
config["3DBoxFill"] = false
config["Health"] = false
config["Armor"] = false
config["Name"] = false
config["Weapon"] = false
config["Skeleton"] = false
config["Distance"] = false
config["Friend"] = false
config["Money"] = false
config["Rank"] = false
config["Chams"] = false
config["ChamsMaterial"] = 1
config["ShowPlayers"] = false
config["ShowNPCs"] = false
config["ShowOther"] = false
config["ESPRender"] = false
config["RenderDist"] = 250
config["EntRender"] = false
config["EntRenderDist"] = 400
config["ViewmodelChanger"] = false
config["removesway"] = false
config["removebob"] = false
config["ViewmodelFOV"] = 100
config["viewmodel_x"] = 0
config["viewmodel_y"] = 0
config["viewmodel_z"] = 0
config["viewmodel_p"] = 0
config["viewmodel_ya"] = 0
config["viewmodel_r"] = 0
config["RemoveSky"] = false
config["RGBSky"] = false
config["RGBSpeed"] = 5
config["Crosshair"] = false
config["WorldModulation"] = false
config["Traitor"] = false
config["EntBox"] = false
config["EntName"] = false
config["EntDist"] = false
config["EntChams"] = false
config["Freecam"] = false
config.binds["Freecam_key"] = 0

config["Misc"] = false
config["Bhop"] = false
config["Autostrafe"] = false
config["SpectatorsList"] = false
config["AdminsList"] = false
config["Thirdperson"] = false
config.binds["Thirdperson_key"] = 0
config["ChatSpam"] = false
config["TPDistance"] = 120
config["Hitsound"] = false
config["MenuColor"] = false
config["config_name"] = nil

config.binds["menu_key"] = 72

config.clrs["Box"] = "61 133 224 255"
config.clrs["3DBox"] = "61 133 224 255"
config.clrs["BoxFilled"] = "61 133 224 255"
config.clrs["ArmorText"] = "84 101 255 255"
config.clrs["Name"] = "255 255 255 255"
config.clrs["Weapon"] = "255 255 255 255"
config.clrs["Distance"] = "255 255 255 255"
config.clrs["Friend"] = "54 134 255 255"
config.clrs["Traitor"] = "155 0 0 255"
config.clrs["Rank"] = "255 255 255 255"
config.clrs["Chams"] = "61 133 224 255"
config.clrs["Skeleton"] = "200 200 200 255"
config.clrs["RemoveSky"] = "0 0 0 255"
config.clrs["WorldModulation"] = "255 255 255 255"
config.clrs["MenuColor"] = "61 133 224 255"
config.clrs["FovCircle"] = "61 133 224 255"
config.clrs["EntBox"] = "252 132 0 255"
config.clrs["EntName"] = "255 255 255 255"
config.clrs["EntDist"] = "255 255 255 255"
config.clrs["EntChams"] = "61 133 224 255"
config.clrs["Crosshair"] = "0 255 0 255"

config["FriendsList"] = {}
config["EntityList"] = {}

CreateMaterial("textured", "VertexLitGeneric")
CreateMaterial("flat", "UnLitGeneric")
CreateMaterial("wireframe", "VertexLitGeneric", { ["$wireframe"] = 1 })

local ChamMaterials = {
    ["Wireframe"] = "!wireframe",
    ["Flat"] = "!flat",
    ["Textured"] = "!textured"
}

surface.CreateFont("FT", { font = "Roboto Bold", weight = 1000, antialias = true, size = 32 })
surface.CreateFont("FT2", { font = "Bahnschrift Bold", weight = 500, antialias = true, size = 18 })
surface.CreateFont("FT3", { font = "Bahnschrift", weight = 300, antialias = true, size = 11 })
surface.CreateFont("FT4", { font = "Segoe UI", weight = 500, antialias = true, size = 14 })
surface.CreateFont("FT5", { font = "Tahoma", weight = 500, antialias = true, size = 13 })
surface.CreateFont("FT6", { font = "Tahoma", weight = 1000, antialias = true, size = 13 })
surface.CreateFont("FT7", { font = "Bahnschrift Bold", weight = 500, antialias = true, size = 15 })
surface.CreateFont("FT8", { font = "Bahnschrift", weight = 500, antialias = true, size = 12 })

local clr = {
    a = Color(10, 21, 32, 230),
    b = Color(16, 16, 22, 255),
    c = Color(24, 35, 48, 250),
    d = Color(12, 59, 84, 255),
    e = Color(16, 35, 47, 255),
    f = Color(50, 69, 82, 255),
    g = Color(18, 18, 18, 255),
    h = Color(20, 20, 20, 255),
    i = Color(107, 52, 235, 255),
    j = Color(10, 10, 10, 150),
    k = Color(61, 133, 224, 255),
    l = Color(250, 250, 250, 255),
    ll = Color(217, 217, 217, 255),
    lt = Color(153, 176, 189, 255),
    m = Color(10, 10, 10, 200)
}

local angc = {
    destroy = false,
    view = Angle(),
}

local LastFrameSS = false

local function DisableWorldModulation()
    for k, v in pairs( Entity( 0 ):GetMaterials() ) do
        Material( v ):SetVector( "$color", Vector(1, 1, 1) )
        Material( v ):SetFloat( "$alpha", 1 )
    end
end

local function UpdateWorldModulation()
    local col = string.ToColor(config.clrs["WorldModulation"])

    for k, v in pairs( Entity( 0 ):GetMaterials() ) do
        Material( v ):SetVector( "$color", Vector(col.r * (1 / 255), col.g * (1 / 255), col.b * (1 / 255)) )
        Material( v ):SetFloat( "$alpha", col.a * (1 / 255) )
    end
end

local hooks = {}

local staffRanks = {"tmod", "trialmod", "trialmoderator", "tmoderator", "mod", "moderator", "smod", "smoderator", "seniormod", "seniormoderator", "jadmin", "junioradmin", "leadadmin", "headadmin", "trialadmin", "admin", "superadmin", "sadmin", "senioradmin", "owner", "developer", "manager", "staff"}

local ss = false
local verifyconfig = config

local bxsmenu, MenuX, MenuY, colorWindow, cfgDropdown, entityFrame, entityFrameX, entityFrameY, entityFrameWasOpen
local loadedCfg = {}
local files, dir = file.Find( "BXS/*.json", "DATA" )

local intp, toggledelay3, toggledelayN = false, false, false

local function RandomString() return tostring(math.random(-9999999999, 9999999999)) end

local function AddHook(event, name, func)
    hooks[name] = event
    hook.Add(event, name, func)
end

local function VerifyConfig()
    for k, v in pairs(verifyconfig) do
        if config[k] == nil then
            config[k] = verifyconfig[k]
            MsgC(Color(61, 149, 217), "\n[BXS] ", Color(222, 222, 222), "The config value ", Color(255, 0, 0), k, Color(222, 222, 222), " was nil. To prevent errors in the cheat it has been set to the default value automatically. Please make sure to save your config with your desired settings to prevent this in the future.")
        end
    end
    for k, v in pairs(verifyconfig.clrs) do
        if config.clrs[k] == nil then
            if k == "config_name" then return end
            config.clrs[k] = verifyconfig.clrs[k]
            MsgC(Color(61, 149, 217), "\n[BXS] ", Color(222, 222, 222), "The color config value ", Color(255, 0, 0), k, Color(222, 222, 222), " was nil. To prevent errors in the cheat it has been set to the default value automatically. Please make sure to save your config with your desired settings to prevent this in the future.")
        end
    end
        for k, v in pairs(verifyconfig.binds) do
        if config.binds[k] == nil then
            config.binds[k] = verifyconfig.binds[k]
            MsgC(Color(61, 149, 217), "\n[BXS] ", Color(222, 222, 222), "The keybind config value ", Color(255, 0, 0), k, Color(222, 222, 222), " was nil. To prevent errors in the cheat it has been set to the default value automatically. Please make sure to save your config with your desired settings to prevent this in the future.")
        end
    end
end

local chatspammer = {
    "whats the max tabs you can have open on a vpn","how many vpns does it take to stop a ddos","whats better analog or garrys mod","whats the time","is it possible to make a clock in binary",
    "how many cars can you drive at once","did you know there's more planes on the ground than there is submarines in the air","how many busses can you fit on 1 bus",
    "how many tables does it take to support a chair","how many doors does it take to screw a screw","how long can you hold your eyes closed in bed",
    "how long can you hold your breath for under spagetti","whats the fastest time to deliver the mail as mail man","how many bees does it take to make a wasp make honey",
    "If I paint the sun blue will it turn blue","how many beavers does it take to build a dam","how much wood does it take to build a computer","can i have ur credit card number",
    "is it possible to blink and jump at the same time","did you know that dinosaurs were, on average, large","how many thursdays does it take to paint an elephant purple",
    "if cars could talk how fast would they go","did you know theres no oxygen in space","do toilets flush the other way in australia","if i finger paint will i get a splinter",
    "can you build me an ant farm","can you craft me a campfire","did you know australia hosts 4 out of 6 of the deadliest spiders in the world",
    "is it possible to ride a bike in space","can i make a movie based around your life","how many pants can you put on while wearing pants","if I paint a car red can it wear pants",
    "how come no matter what colour the liquid is the froth is always white","can a hearse driver drive a corpse in the car pool lane","how come the sun is cold at night",
    "why is it called a TV set when there is only one","if i blend strawberries can i have ur number","if I touch the moon will it be as hot as the sun","did u know ur dad is always older than u",
    "did u know the burger king logo spells burger king","did uknow if u chew on broken glass for a few mins, it starts to taste like blood","did u know running is faster than walking",
    "did u kno the colur blue is called blue because its blue","did you know a shooting star isnt a star","did u know shooting stars dont actually have guns",
    "did u kno the great wall of china is in china","statistictal fact: 100% of non smokers die","did you kmow if you eat you poop it out",
    "did u know rain clouds r called rain clouds cus they are clouds that rain","if cows drink milk is that cow a cannibal","did u know you cant win a staring contest with a stuffed animal",
    "did u know if a race car is at peak speed and hits someone they'll die","did u know the distance between the sun and earth is the same distance as the distance between the earth and the sun",
    "did u kno flat screen tvs arent flat","did u know aeroplane mode on ur phone doesnt make ur phone fly","did u kno too many birthdays can kill you","did u know rock music isnt for rocks",
    "did u know if you eat enough ice you can stop global warming","if ww2 happened before vietnam would that make vietnam world war 2","did you know 3.14 isn't a real pie",
    "did u know 100% of stair accidents happen on stairs","can vampires get AIDS","what type of bird was a dodo","did u know dog backwards is god",
    "did you know on average a dog barks more than a cat", "fuck you"
}

local fakeRT = GetRenderTarget( "fakeRT" .. os.time(), ScrW(), ScrH() )

AddHook("RenderScene", RandomString(), function( vOrigin, vAngle, vFOV )
if ( !gui.IsConsoleVisible() and !gui.IsGameUIVisible() ) or ss then
    local view = {
        x = 0,
        y = 0,
        w = ScrW(),
        h = ScrH(),
        dopostprocess = true,
        origin = vOrigin,
        angles = vAngle,
        fov = vFOV,
        drawhud = true,
        drawmonitors = true,
        drawviewmodel = true
    }
 
    render.RenderView( view )
    render.CopyTexture( nil, fakeRT )

    cam.Start2D()
        hook.Run( "HUDPaintZ" )
    cam.End2D()

    render.SetRenderTarget( fakeRT )

    return true
  end
end)

AddHook( "ShutDown", RandomString(), function()
    render.SetRenderTarget()
end)

local renderv = render.RenderView
local renderc = render.Clear
local rendercap = render.Capture
local rendercappix = render.CapturePixels
local vguiworldpanel = vgui.GetWorldPanel
render.CapturePixels = function() return end
 
local function screengrab()
    if ss then return end
    ss = true
 
    renderc( 0, 0, 0, 255, true, true )
    renderv( {
        origin = me:EyePos(),
        angles = me:EyeAngles(),
        x = 0,
        y = 0,
        w = ScrW(),
        h = ScrH(),
        dopostprocess = true,
        drawhud = true,
        drawmonitors = true,
        drawviewmodel = true
    } )
 
    local vguishits = vguiworldpanel()
 
    if IsValid( vguishits ) then
        vguishits:SetPaintedManually( true )
    end
 
    timer.Simple( 0.1, function()
        vguiworldpanel():SetPaintedManually( false )
        ss = false
    end)
end
 
render.Capture = function(data)
    screengrab()
    local cap = rendercap( data )
    return cap
end

function CloseFrame()
    MenuX, MenuY = bxsmenu:GetPos()
    RememberCursorPosition()
    bxsmenu:Remove()
    bxsmenu = false
end

local function SaveConfig()
    if cfgDropdown:GetSelected() == nil then return end
    
    local cfg = cfgDropdown:GetSelected()
    local JSONconfig = util.TableToJSON(config, true)
    file.Write("BXS/"..cfg, JSONconfig)

    MsgC(Color(61, 149, 217), "\n[BXS] ", Color(222, 222, 222), "Saved Config - ", Color(255, 0, 0), cfg, "\n")
end

local function LoadDefault()
    local JSONconfig = file.Read("BXS/default.json", "DATA")
    config = util.JSONToTable(JSONconfig)

    VerifyConfig()

    loadedCfg[0] = "default.json"
    for k, v in ipairs(files) do
        if v == "default.json" then
            loadedCfg[1] = k
        end
    end

    MsgC(Color(61, 149, 217), "\n[BXS] ", Color(222, 222, 222), "Loaded Default Config\n")
end

local function LoadConfig()
    if cfgDropdown:GetSelected() == nil then return end

    local cfg = cfgDropdown:GetSelected()
    local JSONconfig = file.Read("BXS/"..cfg, "DATA")
    config = util.JSONToTable(JSONconfig)

    VerifyConfig()

    loadedCfg[0] = cfg
    for k, v in ipairs(files) do
        if v == cfg then
            loadedCfg[1] = k
        end
    end

    MsgC(Color(61, 149, 217), "\n[BXS] ", Color(222, 222, 222), "Loaded Config - ", Color(255, 0, 0), cfg, "\n")

    CloseFrame()
    BXSGUI()
end


local function CreateConfig()
    if config["config_name"] == nil then return end
    
    if file.Exists("BXS/"..config["config_name"]..".json", "DATA") then return end

    local JSONconfig = util.TableToJSON(config, true)
    file.CreateDir("BXS")
    file.Write("BXS/"..config["config_name"]..".json", JSONconfig)

    MsgC(Color(61, 149, 217), "\n[BXS] ", Color(222, 222, 222), "Created Config - ", Color(255, 0, 0), config["config_name"], "\n")

    CloseFrame()
    BXSGUI()
end


local function DeleteConfig()
    if cfgDropdown:GetSelected() == nil then return end
    
    local cfg = cfgDropdown:GetSelected()
    file.Delete("BXS/"..cfg)

    loadedCfg = {}

    MsgC(Color(61, 149, 217), "\n[BXS] ", Color(222, 222, 222), "Deleted Config - ", Color(255, 0, 0), cfg, "\n")

    CloseFrame()
    BXSGUI()
end

function hookdel()
    for k, v in pairs(hooks) do
        hook.Remove(v, k)
    end
    if bxsmenu then
        bxsmenu:Remove()
    end
    if colorWindow then
        colorWindow:Remove()
    end
    if entityFrame then
        entityFrame:Remove()
    end
    for k, v in pairs(player.GetAll()) do
        v:SetRenderMode(0)
    end
    DisableWorldModulation()
end

local function CreateLabel(lbl, x, y, par)
    local label = vgui.Create("DLabel", par)
    label:SetTextColor(clr.lt)
    label:SetFont("FT4")
    label:SetText(lbl)
    local w, h = label:GetTextSize()
    label:SetSize(w, h)
    label:SetPos(x, y)
end

local function CheckBox(Parent, Text, PosX, PosY, Var, Col, Extra )
    local CheckBox = vgui.Create( "DCheckBoxLabel", Parent )
    CheckBox:SetFont("FT4")
    CheckBox:SetText( Text )
    CheckBox:SetSize( 16 + surface.GetTextSize(Text) + 10, 17 )
    CheckBox:SetPos( PosX, PosY )
    CheckBox:SetValue( config[Var] )
    function CheckBox:OnChange(bVal)
      config[Var] = bVal
    end
  function CheckBox.Button:Paint(w, h)
    local menucolor = string.ToColor(config.clrs["MenuColor"])
    if self:GetChecked() then
      CheckBox:SetTextColor( clr.l )
      draw.RoundedBox( 4, 1, 1, w - 1, h - 1, menucolor )
    else
      CheckBox:SetTextColor( clr.lt )
      draw.RoundedBox( 4, 1, 1, w - 1, h - 1, clr.b )
    end
  end
    if Col then
        local cx, cy = CheckBox:GetPos()
        local colorPicker = vgui.Create("DImageButton", Parent)
        colorPicker:SetImage("icon16/color_wheel.png")
        colorPicker:SetSize(16, 16)
        if Extra then
            colorPicker:SetPos(cx + CheckBox:GetWide() + 5, PosY + 1)
        else
            colorPicker:SetPos(cx + 205 + 4, PosY + 1)
        end
        function colorPicker:DoClick()
            if IsValid(colorWindow) then
                colorWindow:Remove()
            end
            colorWindow = vgui.Create("DFrame")
            colorWindow:SetSize(300, 225)
            colorWindow:SetTitle(Text .. " - Color Picker")
            function colorWindow:Paint(w, h)
                draw.RoundedBox(6, 1, 1, w - 2, h - 2, Color(10, 21, 32))
                draw.RoundedBox(0, 5, 24, w - 10, 2, clr.c)
            end
            local frameX, frameY = bxsmenu:GetPos()
            if frameX + 350 > ScrW() then
                colorWindow:Center()
            else
                colorWindow:SetPos(frameX + 350, frameY)
            end
            colorWindow:MakePopup()
            local colorSelector = vgui.Create("DColorMixer", colorWindow)
            colorSelector:Dock(FILL)
            colorSelector:DockPadding(5, 5, 5, 25)
            colorSelector:SetPalette(true)
            colorSelector:SetColor(string.ToColor(config.clrs[Var]))
            function colorSelector:ValueChanged(val)
                local r = tostring(val.r)
                local g = tostring(val.g)
                local b = tostring(val.b)
                local a = tostring(val.a)
                local col = r.." "..g.." "..b.." "..a
                config.clrs[Var] = col
            end
        end
    end
end

local function Slider(text, x, y, cfg, min, max, dec, par)
    local sliderLabel = vgui.Create("DLabel", par)
    sliderLabel:SetTextColor(clr.lt)
    sliderLabel:SetText(text)
    local w, h = sliderLabel:GetTextSize()
    sliderLabel:SetWide(w)
    sliderLabel:SetPos(x + 5, y - h / 8 - 1)

    local slider = vgui.Create("DNumSlider", par)
    slider:SetWide(250)
    slider:SetPos(x - 104, y + 3)
    slider:SetMin(min)
    slider:SetMax(max)
    slider:SetDark(false)
    slider:SetDefaultValue(config[cfg])
    slider:ResetToDefaultValue()
    slider:SetDecimals(dec)
    function slider:OnValueChanged()
        config[cfg] = slider:GetValue()
    end
    slider.Slider.Paint = function(self,w,h)
        local getwidth = slider.Slider.Knob:GetPos()
        draw.RoundedBox(0,2,16,w-4,2,clr.e)
        draw.RoundedBox(0,2,16,getwidth-2,2,string.ToColor(config.clrs["MenuColor"]))
    end
    
    slider.Slider.Knob:SetSize(10,10)
    slider.Slider.Knob.Paint = function(self,w,h)
        draw.RoundedBox(64,0,1,w,h,string.ToColor(config.clrs["MenuColor"]))
    end
    slider.Slider:SetNotches(0)
    slider.Slider:SetNotchColor(clr.l)
    slider.Scratch:SetVisible(false)
end

local function Binder( Parent, PosX, PosY, SizeX, SizeY, Var )
local Bind = vgui.Create( "DBinder", Parent )
Bind:SetTextColor(clr.lt)
Bind:SetValue( config.binds[Var] )
Bind:SetSize( SizeX, SizeY )
Bind:SetPos( PosX, PosY )
Bind.Paint = function(self, w, h)
    draw.RoundedBox(4, 0, 0, w, h, clr.e)
    draw.RoundedBox(4, 1, 1, w - 2, h - 2, clr.b)
end
Bind.OnChange = function()
    config.binds[Var] = Bind:GetValue()
  end
end

local function ComboBox(Parent, Text, PosX, PosY, Choices, Var, W1, H1)
    local dropdownLabel = vgui.Create("DLabel", Parent)
    dropdownLabel:SetTextColor(clr.ll)
    dropdownLabel:SetText(Text)
    local w, h = dropdownLabel:GetTextSize()
    dropdownLabel:SetWide(w)
    dropdownLabel:SetPos(PosX + 2, PosY - h / 8 + 4)

    local dropdown = vgui.Create("DComboBox", Parent)
    dropdown:SetSize(W1, H1)
    dropdown:SetPos(PosX, PosY + 20)
    for k, v in ipairs(Choices) do
        dropdown:AddChoice(v)
    end
    dropdown:SetSortItems(false)
    dropdown:ChooseOptionID(config[Var])
    function dropdown:OnSelect(index, value, data)
        config[Var] = index
    end
end

local function CreateButton(lbl, tooltip, fnc, x, y, par, w1, h1)
    local button = vgui.Create("DButton", par)
    button:SetSize(w1, h1)
    button:SetPos(x, y)
    button:SetTextColor(clr.lt)
    button:SetFont("FT7")
    button:SetText(lbl)
    --button:SetTooltip(tooltip)
    function button:Paint(w, h)
        draw.RoundedBox(4, 0, 0, w, h, clr.e)
        draw.RoundedBox(4, 1, 1, w - 2, h - 2, clr.b)
    end
    function button:DoClick()
        fnc()
    end
end

local function CreateTextInput(lbl, Var, x, y, chars, par, w1)
    local textInput = vgui.Create("DTextEntry", par)
    textInput:SetSize(w1, 20)
    textInput:SetPos(x, y)
    textInput:IsMultiline( false )
    textInput:SetMaximumCharCount(chars)
    textInput:SetPlaceholderText(lbl)
    textInput.Think = function()
        if textInput:IsEditing() then
            editingText = true
        else
            editingText = false
        end
        config[Var] = textInput:GetValue()
    end 
end

local function SubPanel(parent, text, x, y, w1, h1)
    local panel = vgui.Create("DPanel", parent)
    panel:SetPos( x, y )
    panel:SetSize( w1, h1 )
    panel.Paint = function(self, w, h)
    draw.RoundedBox(6, 1, 1, w - 2, h - 2, clr.a)
    draw.RoundedBox(0, 5, 28, w - 10, 2, clr.c)
    draw.SimpleText(text, "FT2", 8, 5, clr.ll, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP )
  end
end

local function CreateEntityList()
    if !entityFrame then
        local entityFrame = vgui.Create("DFrame")
        entityFrame:SetSize(425, 200)
        entityFrame:SetTitle("Entity ESP")
        if entityFrameX == nil or entityFrameY == nil then
            entityFrame:Center()
        else
            entityFrame:SetPos(entityFrameX, entityFrameY) 
        end
        entityFrame:MakePopup()
        function entityFrame:Paint(w, h)
            draw.RoundedBox(6, 1, 1, w - 2, h - 2, clr.b)
            draw.RoundedBox(0, 5, 24, w - 10, 2, clr.c)
            draw.RoundedBox(6, 299, 34, 120, 86, clr.e)
        end
        function entityFrame:OnClose()
            entityFrameX, entityFrameY = entityFrame:GetPos()
            entityFrame = false
        end

        local entList = vgui.Create("DListView", entityFrame)
        entList:DockMargin(0, 0, 125, 0)
        entList:Dock(FILL)
        entList:SetMultiSelect(false)
        entList:AddColumn("Entities")

        for k, v in ipairs(ents.GetAll()) do
            local good = true
            for k, line in ipairs( entList:GetLines() ) do
                if line:GetValue( 1 ) == v:GetClass() then good = false break end
            end
            if v:GetClass() != "worldspawn" and v:GetClass() != "player" and v:GetOwner() != me and good then
                entList:AddLine(v:GetClass())
            end
        end

        local enable = vgui.Create("DCheckBoxLabel", entityFrame)
        enable:SetFont("FT4")
        enable:SetText("Enable ESP")
        surface.SetFont("FT4")
        enable:SetSize( 16 + surface.GetTextSize("Enable ESP") + 10, 17 )
        enable:SetPos(304, 35)
        enable:SetValue( false )
        function enable.Button:Paint(w, h)
        local menucolor = string.ToColor(config.clrs["MenuColor"])
        if self:GetChecked() then
            enable:SetTextColor( clr.l )
            draw.RoundedBox( 4, 1, 1, w - 1, h - 1, menucolor )
        else
            enable:SetTextColor( clr.lt )
            draw.RoundedBox( 4, 1, 1, w - 1, h - 1, clr.b )
          end
        end
        function enable:OnChange( bVal )
            if entList:GetSelectedLine() != nil then
                local _, line = entList:GetSelectedLine()
                if bVal then
                    if table.HasValue(config["EntityList"], line:GetColumnText(1)) then return
                    else table.insert(config["EntityList"], line:GetColumnText(1)) end
                else
                    if table.HasValue(config["EntityList"], line:GetColumnText(1)) then
                        table.RemoveByValue(config["EntityList"], line:GetColumnText(1))
                    end
                end
            end
        end
        CheckBox(entityFrame, "Box ESP", 304, 51, "EntBox", true, true)
        CheckBox(entityFrame, "Name ESP", 304, 67, "EntName", true, true)
        CheckBox(entityFrame, "Distance ESP", 304, 83, "EntDist", true, true)
        CheckBox(entityFrame, "Chams", 304, 99, "EntChams", true, true)

        function entList:OnRowSelected(ind, line)
            if table.HasValue(config["EntityList"], line:GetColumnText(1)) then
                enable:SetValue(true)
            else
                enable:SetValue(false) 
            end
        end
    end
end

local function AddFriend( ply )
    if !ply:IsValid() then return end
    if table.HasValue( config["FriendsList"], ply ) then return end
    table.insert( config["FriendsList"], ply )
end

local function DelFriend( ply )
    if !ply:IsValid() then return end
    if !table.HasValue( config["FriendsList"], ply ) then return end
    table.RemoveByValue( config["FriendsList"], v )
end

local function IsFriend( ply )
    if !ply or !ply:IsValid() then return false end
    return table.HasValue( config["FriendsList"], ply )
end

hook.Add( "player_spawn", RandomString(), function( data )
    local id = data.userid
    local ply =  player.GetByID( id )
    if !ply:IsValid() then return end
    if ply:GetFriendStatus() == "friend" and !table.HasValue( config["FriendsList"], ply ) then
        AddFriend( ply )
    end
end)

local function RefreshFriends()
    for k, v in pairs(player.GetAll()) do
        if v:GetFriendStatus() == "friend" then AddFriend( v ) end
    end
end

local activetab = 'Aimbot'

for k, v in ipairs(files) do
    if string.lower(v) == "default.json" then
        LoadDefault()
    end
end

function BXSGUI()
files, dir = file.Find( "BXS/*.json", "DATA" )
bxsmenu = vgui.Create("DFrame")
bxsmenu:SetSize(700, 500)
if MenuX == nil or MenuY == nil then
    bxsmenu:Center()
else
    bxsmenu:SetPos(MenuX, MenuY)
end
bxsmenu:SetTitle("")
bxsmenu:SetDraggable(true)
bxsmenu:ShowCloseButton(false)
bxsmenu:MakePopup()
bxsmenu.Paint = function(self, w, h)
draw.RoundedBoxEx(4, 170, 0, w - 170, h, clr.b, false, true, false, true)
draw.RoundedBoxEx(4, 0, 0, 170, h, clr.c, true, false, true, false)
draw.RoundedBoxEx(0, 170, 55, w - 170, 2, clr.e)
draw.RoundedBoxEx(0, 168, 0, 2, h, Color(6, 25, 38))
surface.SetFont("FT")
draw.SimpleTextOutlined("BXS BETA", "FT", 24, 32, clr.l, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER, 1, Color(50, 91, 117, 180) )
draw.SimpleText("Aimbot", "FT4", 14, 60, clr.f, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER )
draw.SimpleText("Visuals", "FT4", 14, 120, clr.f, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER )
draw.SimpleText("Miscellaneous", "FT4", 14, 210, clr.f, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER )
end

local panel1 = vgui.Create('DPanel', bxsmenu)
panel1:SetSize( bxsmenu:GetWide() - 10, bxsmenu:GetTall() - 113 )
panel1:SetPos( 5, 65 )
panel1.Paint = function(self, w, h)
end
panel1:SetVisible(activetab == 'Aimbot')

local panel2 = vgui.Create('DPanel', bxsmenu)
panel2:SetSize( bxsmenu:GetWide() - 10, bxsmenu:GetTall() - 113 )
panel2:SetPos( 5, 65 )
panel2.Paint = function(self, w, h)
end
panel2:SetVisible(activetab == 'Players')

local panel5 = vgui.Create('DPanel', bxsmenu)
panel5:SetSize( bxsmenu:GetWide() - 10, bxsmenu:GetTall() - 113 )
panel5:SetPos( 5, 65 )
panel5.Paint = function(self, w, h)
end
panel5:SetVisible(activetab == 'Other')

local panel3 = vgui.Create('DPanel', bxsmenu)
panel3:SetSize( bxsmenu:GetWide() - 10, bxsmenu:GetTall() - 113 )
panel3:SetPos( 5, 65 )
panel3.Paint = function(self, w, h)
end
panel3:SetVisible(activetab == 'Main')

local panel4 = vgui.Create('DPanel', bxsmenu)
panel4:SetSize( bxsmenu:GetWide() - 10, bxsmenu:GetTall() - 113 )
panel4:SetPos( 5, 65 )
panel4.Paint = function(self, w, h)
end
panel4:SetVisible(activetab == 'Config')

local Tab1 = vgui.Create( "DButton", bxsmenu )
Tab1:SetText( "" )
Tab1:SetPos( 10, 72 )
Tab1:SetSize( 150, 30 )
Tab1.Paint = function(self, w, h)
if activetab == 'Aimbot' then
    local menucolor = string.ToColor(config.clrs["MenuColor"])
    draw.RoundedBox(6, 1, 1, w - 2, h - 2, Color(menucolor.r, menucolor.g, menucolor.b, 30))
end
    draw.SimpleText("Aimbot", "FT2", 15, 15, clr.ll, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
end
Tab1.DoClick = function()
    activetab = 'Aimbot'
    panel1:SetVisible(true)
    panel2:SetVisible(false)
    panel3:SetVisible(false)
    panel4:SetVisible(false)
    panel5:SetVisible(false)
end

local Tab2 = vgui.Create( "DButton", bxsmenu )
Tab2:SetText( "" )
Tab2:SetPos( 10, 132 )
Tab2:SetSize( 150, 30 )
Tab2.Paint = function(self, w, h)
if activetab == 'Players' then
    local menucolor = string.ToColor(config.clrs["MenuColor"])
    draw.RoundedBox(6, 1, 1, w - 2, h - 2, Color(menucolor.r, menucolor.g, menucolor.b, 30))
end
    draw.SimpleText("Players", "FT2", 15, 15, clr.ll, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
end
Tab2.DoClick = function()
    activetab = 'Players'
    panel1:SetVisible(false)
    panel2:SetVisible(true)
    panel3:SetVisible(false)
    panel4:SetVisible(false)
    panel5:SetVisible(false)
end

local Tab5 = vgui.Create( "DButton", bxsmenu )
Tab5:SetText( "" )
Tab5:SetPos( 10, 164 )
Tab5:SetSize( 150, 30 )
Tab5.Paint = function(self, w, h)
if activetab == 'Other' then
    local menucolor = string.ToColor(config.clrs["MenuColor"])
    draw.RoundedBox(6, 1, 1, w - 2, h - 2, Color(menucolor.r, menucolor.g, menucolor.b, 30))
end
    draw.SimpleText("Other", "FT2", 15, 15, clr.ll, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
end
Tab5.DoClick = function()
    activetab = 'Other'
    panel1:SetVisible(false)
    panel2:SetVisible(false)
    panel3:SetVisible(false)
    panel4:SetVisible(false)
    panel5:SetVisible(true)
end

local Tab3 = vgui.Create( "DButton", bxsmenu )
Tab3:SetText( "" )
Tab3:SetPos( 10, 222 )
Tab3:SetSize( 150, 30 )
Tab3.Paint = function(self, w, h)
if activetab == 'Main' then
    local menucolor = string.ToColor(config.clrs["MenuColor"])
    draw.RoundedBox(6, 1, 1, w - 2, h - 2, Color(menucolor.r, menucolor.g, menucolor.b, 30))
end
    draw.SimpleText("Main", "FT2", 15, 15, clr.ll, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
end
Tab3.DoClick = function()
    activetab = 'Main'
    panel1:SetVisible(false)
    panel2:SetVisible(false)
    panel3:SetVisible(true)
    panel4:SetVisible(false)
    panel5:SetVisible(false)
end

local Tab4 = vgui.Create( "DButton", bxsmenu )
Tab4:SetText( "" )
Tab4:SetPos( 10, 254 )
Tab4:SetSize( 150, 30 )
Tab4.Paint = function(self, w, h)
if activetab == 'Config' then
    local menucolor = string.ToColor(config.clrs["MenuColor"])
    draw.RoundedBox(6, 1, 1, w - 2, h - 2, Color(menucolor.r, menucolor.g, menucolor.b, 30))
end
    draw.SimpleText("Config", "FT2", 15, 15, clr.ll, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
end
Tab4.DoClick = function()
    activetab = 'Config'
    panel1:SetVisible(false)
    panel2:SetVisible(false)
    panel3:SetVisible(false)
    panel4:SetVisible(true)
    panel5:SetVisible(false)
end

CreateButton("Save", "Save Config.", SaveConfig, 180, 17, bxsmenu, 70, 24)
CreateButton("Load", "Load Config.", LoadConfig, 255, 17, bxsmenu, 70, 24)

    local usercfgs = {}
    cfgDropdown = vgui.Create("DComboBox", bxsmenu)
    cfgDropdown:SetSize(bxsmenu:GetWide() - 350, 20)
    cfgDropdown:SetPos(335, 19)
    if loadedCfg[0] != nil then
        cfgDropdown:ChooseOption(loadedCfg[0], loadedCfg[1])
    end
    for k, v in ipairs(files) do
        cfgDropdown:AddChoice(v)
    end
    cfgDropdown:SetSortItems(false)


SubPanel(panel1, "Main", 177, 5, 247, 172)
SubPanel(panel1, "Aim", 435, 5, 247, 92)
SubPanel(panel1, "Targets", 435, 104, 247, 153)
Slider("FOV", 445, 37, "AimFOV", 0, 180, 0, panel1)
Slider("Smooth", 445, 63, "AimSmoothness", 0, 15, 2, panel1)
CheckBox(panel1, "Enable Aimbot", 187, 37, "Aimbot" )
ComboBox(panel1, "Hitbox", 187, 49, {"Head", "Neck", "Upper Chest", "Chest", "Body", "Pelvis"}, "AimHitbox", 101, 16)
Binder(panel1, 187, 88, 101, 16, "AimKey" )
CheckBox(panel1, "Silent Aim", 187, 104, "Silent" )
CheckBox(panel1, "Autoshoot", 187, 120, "Autofire" )
CheckBox(panel1, "Draw FOV", 187, 136, "FovCircle", true )
CheckBox(panel1, "No Spread", 187, 152, "NoSpread" )
CheckBox(panel1, "Ignore Friends", 445, 136, "IgnoreFriends" )
CheckBox(panel1, "Ignore Teammates", 445, 152, "IgnoreTeam" )
CheckBox(panel1, "Ignore Bots", 445, 168, "IgnoreBots" )
CheckBox(panel1, "Ignore Noclip", 445, 184, "IgnoreNoClip" )
CheckBox(panel1, "Ignore Godmode", 445, 200, "IgnoreGodded" )
CheckBox(panel1, "Ignore Players", 445, 216, "IgnorePlayers" )
CheckBox(panel1, "Ignore NPCs", 445, 232, "IgnoreNPCs" )

    local function makeflist()
        flist = vgui.Create("DComboBox", panel1)
        flist:SetPos(178,185)
        flist:SetSize(120,20)
        for k,v in pairs(player.GetAll()) do
            if v ~= me then
                if not(table.HasValue(config["FriendsList"], v)) then
                    local i = flist:AddChoice(v:Nick())
                end
            end
        end
        flist.OnSelect = function(index,value,data)
            flist2 = data
        end
    end

    local function makeflistc()
        flistc = vgui.Create("DComboBox", panel1)
        flistc:SetPos(303, 185)
        flistc:SetSize(120,20)
        for k,v in pairs(config["FriendsList"]) do
            if v ~= me then
                local i = flistc:AddChoice(v:Nick())
        end
    end
        flistc.OnSelect = function(index,value,data)
            flistc2 = data
        end
    end

    makeflist()
    makeflistc()

    local function FriendAdd()
        if(flist2) then
            for k,v in pairs(player.GetAll()) do
                if (v:Nick() == flist2) then
                    table.insert( config["FriendsList"], v )
                end
            end
        end
        makeflist()
        makeflistc()
    end

    local function FriendRemove()
        if(flistc2) then
            for k,v in pairs(config["FriendsList"]) do
                if v:Nick() == flistc2 then
                    table.RemoveByValue( config["FriendsList"], v )
                end
            end
        end
    makeflist()
    makeflistc()
end

CreateButton("Add Friend", "", FriendAdd, 178, 210, panel1, 120, 20)
CreateButton("Remove Friend", "", FriendRemove, 303, 210, panel1, 120, 20)

SubPanel(panel2, "ESP", 177, 5, 247, 363)
SubPanel(panel2, "Render", 435, 5, 247, 84)
SubPanel(panel2, "Filter", 435, 96, 247, 89)
SubPanel(panel5, "Render", 435, 5, 247, 84)
SubPanel(panel5, "Screen", 435, 96, 247, 56)
SubPanel(panel5, "ESP", 177, 5, 247, 357)
Slider("Rainbow Speed", 187, 70, "RGBSpeed", 1, 50, 0, panel5)
Slider("Max Draw Distance", 445, 55, "RenderDist", 0, 2500, 1, panel2)
Slider("Max Draw Distance", 445, 55, "EntRenderDist", 0, 2500, 1, panel5)
CheckBox(panel2, "Enable Visuals", 187, 37, "Visuals" )
CheckBox(panel2, "2D Box ESP", 187, 53, "Box", true )
CheckBox(panel2, "2D Box Fill", 187, 69, "BoxFilled", true)
CheckBox(panel2, "3D Box ESP", 187, 85, "3DBox", true )
CheckBox(panel2, "3D Box Fill", 187, 101, "3DBoxFill", false )
CheckBox(panel2, "Name ESP", 187, 117, "Name", true )
CheckBox(panel2, "Health Bar", 187, 133, "HealthBar" )
CheckBox(panel2, "Health ESP", 187, 149, "HealthText" )
CheckBox(panel2, "Armor Bar", 187, 165, "ArmorBar", true )
CheckBox(panel2, "Armor ESP", 187, 181, "ArmorText", true )
CheckBox(panel2, "Money ESP", 187, 197, "Money" )
CheckBox(panel2, "Weapon ESP", 187, 213, "Weapon", true )
CheckBox(panel2, "Skeleton ESP", 187, 229, "Skeleton", true )
CheckBox(panel2, "Distance ESP", 187, 245, "Distance", true )
CheckBox(panel2, "Friend ESP", 187, 261, "Friend", true )
CheckBox(panel2, "Traitor ESP", 187, 277, "Traitor", true )
CheckBox(panel2, "Rank ESP", 187, 293, "Rank", true )
CheckBox(panel2, "Chams", 187, 309, "Chams", true )
ComboBox(panel2, "Chams Material", 187, 320, {"Flat", "Textured", "Wireframe"}, "ChamsMaterial", 160, 20)

CheckBox(panel5, "Skybox Color", 187, 37, "RemoveSky", true, false )
CheckBox(panel5, "Rainbow Skybox", 187, 53, "RGBSky", false, true )
CheckBox(panel5, "World Modulation", 187, 97, "WorldModulation", true )
CheckBox(panel5, "Viewmodel Changer", 187, 113, "ViewmodelChanger" )
Slider("Viewmodel FOV", 187, 130, "ViewmodelFOV", 60, 160, 0, panel5)
Slider("Viewmodel X", 187, 154, "viewmodel_x", -50, 50, 0, panel5)
Slider("Viewmodel Y", 187, 178, "viewmodel_y", -30, 30, 0, panel5)
Slider("Viewmodel Z", 187, 202, "viewmodel_z", -20, 20, 0, panel5)
Slider("Viewmodel Pitch", 187, 226, "viewmodel_p", -90, 90, 0, panel5)
Slider("Viewmodel Yaw", 187, 250, "viewmodel_ya", -90, 90, 0, panel5)
Slider("Viewmodel Roll", 187, 274, "viewmodel_r", -360, 360, 0, panel5)
CheckBox(panel5, "Remove Bob", 187, 299, "removebob" )
CheckBox(panel5, "Remove Sway", 187, 315, "removesway" )
CreateButton("Entity List", "", CreateEntityList, 187, 335, panel5, 120, 20)
CheckBox(panel2, "Limit ESP Distance", 445, 37, "ESPRender" )
CheckBox(panel5, "Limit Entity ESP Distance", 445, 37, "EntRender" )
CheckBox(panel2, "Show Players", 445, 128, "ShowPlayers" )
CheckBox(panel2, "Show NPCs", 445, 144, "ShowNPCs" )
CheckBox(panel2, "Show Other", 445, 160, "ShowOther" )
CheckBox(panel5, "Crosshair", 445, 128, "Crosshair", true )

if entityFrameWasOpen then
    CreateEntityList()
    entityFrameWasOpen = false
end

SubPanel(panel3, "Other", 177, 5, 247, 321)
CheckBox(panel3, "Enable Misc", 187, 37, "Misc" )
CheckBox(panel3, "Bhop", 187, 53, "Bhop" )
CheckBox(panel3, "Autostrafe", 187, 69, "Autostrafe" )
CheckBox(panel3, "Spectators List", 187, 85, "SpectatorsList" )
CheckBox(panel3, "Admins List", 187, 101, "AdminsList" )
CheckBox(panel3, "Freecam", 187, 117, "Freecam" )
Binder(panel3, 187, 135, 100, 16, "Freecam_key" )
CheckBox(panel3, "Thirdperson", 187, 151, "Thirdperson" )
Binder(panel3, 187, 170, 100, 16, "Thirdperson_key" )
Slider("Thirdperson Dist", 187, 187, "TPDistance", 20, 300, 0, panel3)
CheckBox(panel3, "Auto Pistol", 187, 214, "RapidFire" )
CheckBox(panel3, "Chat Spam", 187, 230, "ChatSpam" )
CheckBox(panel3, "Hitsound", 187, 246, "Hitsound" )
CheckBox(panel3, "Menu Color", 187, 262, "MenuColor", true)
CreateLabel("Menu Key:", 188, 281, panel3)
Binder(panel3, 247, 281, 55, 16, "menu_key" )
CreateButton("Unload Cheat", "", hookdel, 187, 299, panel3, 115, 20)
    CreateButton("Create Config", "Create Config.", CreateConfig, 175, 22, panel4, bxsmenu:GetWide() - 190, 20)
    CreateButton("Delete Config", "Delete Config.", DeleteConfig, 175, 44, panel4, bxsmenu:GetWide() - 190, 20)
    CreateTextInput("Config Name", "config_name", 175, 0, 16, panel4, bxsmenu:GetWide() - 190)
end
BXSGUI()

AddHook("Think", RandomString(), function()
if config["Misc"] and config["ChatSpam"] then
    RunConsoleCommand("say", chatspammer[math.random(0, table.Count( chatspammer ) - 1)] )
end
if(!ss) then 
    if config["WorldModulation"] and config["Visuals"] then
        DisableWorldModulation()
    end
    LastFrameSS = true
end
if LastFrameSS then
    if config["WorldModulation"] and config["Visuals"] then
        UpdateWorldModulation()
    end
    LastFrameSS = false
end
if(!config["WorldModulation"] or !config["Visuals"] )then
        DisableWorldModulation()
end
    if config.binds["menu_key"] != 0 and input.IsKeyDown(config.binds["menu_key"]) and !insertdown and !config["menu_key"] then
        if entityFrame then
            entityFrameX, entityFrameY = entityFrame:GetPos()
            entityFrame:Remove()
            entityFrameWasOpen = true
            entityFrame = false
        end
        if colorWindow then
            colorWindow:Remove()
            colorWindow = false
        end
        if bxsmenu then
            CloseFrame()
        else
            BXSGUI()
            RestoreCursorPosition()
            RefreshFriends()
        end
    end
    insertdown = input.IsKeyDown(config.binds["menu_key"])
end)

local NS = {}
 
NS.engineSpread = {
    [0] = {-0.492036, 0.286111},
    [1] = {-0.492036, 0.286111},
    [2] = {-0.255320, 0.128480},
    [3] = {0.456165, 0.356030},
    [4] = {-0.361731, 0.406344},
    [5] = {-0.146730, 0.834589},
    [6] = {-0.253288, -0.421936},
    [7] = {-0.448694, 0.111650},
    [8] = {-0.880700, 0.904610},
    [9] = {-0.379932, 0.138833},
    [10] = {0.502579, -0.494285},
    [11] = {-0.263847, -0.594805},
    [12] = {0.818612, 0.090368},
    [13] = {-0.063552, 0.044356},
    [14] = {0.490455, 0.304820},
    [15] = {-0.192024, 0.195162},
    [16] = {-0.139421, 0.857106},
    [17] = {0.715745, 0.336956},
    [18] = {-0.150103, -0.044842},
    [19] = {-0.176531, 0.275787},
    [20] = {0.155707, -0.152178},
    [21] = {-0.136486, -0.591896},
    [22] = {-0.021022, -0.761979},
    [23] = {-0.166004, -0.733964},
    [24] = {-0.102439, -0.132059},
    [25] = {-0.607531, -0.249979},
    [26] = {-0.500855, -0.185902},
    [27] = {-0.080884, 0.516556},
    [28] = {-0.003334, 0.138612},
    [29] = {-0.546388, -0.000115},
    [30] = {-0.228092, -0.018492},
    [31] = {0.542539, 0.543196},
    [32] = {-0.355162, 0.197473},
    [33] = {-0.041726, -0.015735},
    [34] = {-0.713230, -0.551701},
    [35] = {-0.045056, 0.090208},
    [36] = {0.061028, 0.417744},
    [37] = {-0.171149, -0.048811},
    [38] = {0.241499, 0.164562},
    [39] = {-0.129817, -0.111200},
    [40] = {0.007366, 0.091429},
    [41] = {-0.079268, -0.008285},
    [42] = {0.010982, -0.074707},
    [43] = {-0.517782, -0.682470},
    [44] = {-0.663822, -0.024972},
    [45] = {0.058213, -0.078307},
    [46] = {-0.302041, -0.132280},
    [47] = {0.217689, -0.209309},
    [48] = {-0.143615, 0.830349},
    [49] = {0.270912, 0.071245},
    [50] = {-0.258170, -0.598358},
    [51] = {0.099164, -0.257525},
    [52] = {-0.214676, -0.595918},
    [53] = {-0.427053, -0.523764},
    [54] = {-0.585472, 0.088522},
    [55] = {0.564305, -0.533822},
    [56] = {-0.387545, -0.422206},
    [57] = {0.690505, -0.299197},
    [58] = {0.475553, 0.169785},
    [59] = {0.347436, 0.575364},
    [60] = {-0.069555, -0.103340},
    [61] = {0.286197, -0.618916},
    [62] = {-0.505259, 0.106581},
    [63] = {-0.420214, -0.714843},
    [64] = {0.032596, -0.401891},
    [65] = {-0.238702, -0.087387},
    [66] = {0.714358, 0.197811},
    [67] = {0.208960, 0.319015},
    [68] = {-0.361140, 0.222130},
    [69] = {-0.133284, -0.492274},
    [70] = {0.022824, -0.133955},
    [71] = {-0.100850, 0.271962},
    [72] = {-0.050582, -0.319538},
    [73] = {0.577980, 0.095507},
    [74] = {0.224871, 0.242213},
    [75] = {-0.628274, 0.097248},
    [76] = {0.184266, 0.091959},
    [77] = {-0.036716, 0.474259},
    [78] = {-0.502566, -0.279520},
    [79] = {-0.073201, -0.036658},
    [80] = {0.339952, -0.293667},
    [81] = {0.042811, 0.130387},
    [82] = {0.125881, 0.007040},
    [83] = {0.138374, -0.418355},
    [84] = {0.261396, -0.392697},
    [85] = {-0.453318, -0.039618},
    [86] = {0.890159, -0.335165},
    [87] = {0.466437, -0.207762},
    [88] = {0.593253, 0.418018},
    [89] = {0.566934, -0.643837},
    [90] = {0.150918, 0.639588},
    [91] = {0.150112, 0.215963},
    [92] = {-0.130520, 0.324801},
    [93] = {-0.369819, -0.019127},
    [94] = {-0.038889, -0.650789},
    [95] = {0.490519, -0.065375},
    [96] = {-0.305940, 0.454759},
    [97] = {-0.521967, -0.550004},
    [98] = {-0.040366, 0.683259},
    [99] = {0.137676, -0.376445},
    [100] = {0.839301, 0.085979},
    [101] = {-0.319140, 0.481838},
    [102] = {0.201437, -0.033135},
    [103] = {0.384637, -0.036685},
    [104] = {0.598419, 0.144371},
    [105] = {-0.061424, -0.608645},
    [106] = {-0.065337, 0.308992},
    [107] = {-0.029356, -0.634337},
    [108] = {0.326532, 0.047639},
    [109] = {0.505681, -0.067187},
    [110] = {0.691612, 0.629364},
    [111] = {-0.038588, -0.635947},
    [112] = {0.637837, -0.011815},
    [113] = {0.765338, 0.563945},
    [114] = {0.213416, 0.068664},
    [115] = {-0.576581, 0.554824},
    [116] = {0.246580, 0.132726},
    [117] = {0.385548, -0.070054},
    [118] = {0.538735, -0.291010},
    [119] = {0.609944, 0.590973},
    [120] = {-0.463240, 0.010302},
    [121] = {-0.047718, 0.741086},
    [122] = {0.308590, -0.322179},
    [123] = {-0.291173, 0.256367},
    [124] = {0.287413, -0.510402},
    [125] = {0.864716, 0.158126},
    [126] = {0.572344, 0.561319},
    [127] = {-0.090544, 0.332633},
    [128] = {0.644714, 0.196736},
    [129] = {-0.204198, 0.603049},
    [130] = {-0.504277, -0.641931},
    [131] = {0.218554, 0.343778},
    [132] = {0.466971, 0.217517},
    [133] = {-0.400880, -0.299746},
    [134] = {-0.582451, 0.591832},
    [135] = {0.421843, 0.118453},
    [136] = {-0.215617, -0.037630},
    [137] = {0.341048, -0.283902},
    [138] = {-0.246495, -0.138214},
    [139] = {0.214287, -0.196102},
    [140] = {0.809797, -0.498168},
    [141] = {-0.115958, -0.260677},
    [142] = {-0.025448, 0.043173},
    [143] = {-0.416803, -0.180813},
    [144] = {-0.782066, 0.335273},
    [145] = {0.192178, -0.151171},
    [146] = {0.109733, 0.165085},
    [147] = {-0.617935, -0.274392},
    [148] = {0.283301, 0.171837},
    [149] = {-0.150202, 0.048709},
    [150] = {-0.179954, -0.288559},
    [151] = {-0.288267, -0.134894},
    [152] = {-0.049203, 0.231717},
    [153] = {-0.065761, 0.495457},
    [154] = {0.082018, -0.457869},
    [155] = {-0.159553, 0.032173},
    [156] = {0.508305, -0.090690},
    [157] = {0.232269, -0.338245},
    [158] = {-0.374490, -0.480945},
    [159] = {-0.541244, 0.194144},
    [160] = {-0.040063, -0.073532},
    [161] = {0.136516, -0.167617},
    [162] = {-0.237350, 0.456912},
    [163] = {-0.446604, -0.494381},
    [164] = {0.078626, -0.020068},
    [165] = {0.163208, 0.600330},
    [166] = {-0.886186, -0.345326},
    [167] = {-0.732948, -0.689349},
    [168] = {0.460564, -0.719006},
    [169] = {-0.033688, -0.333340},
    [170] = {-0.325414, -0.111704},
    [171] = {0.010928, 0.723791},
    [172] = {0.713581, -0.077733},
    [173] = {-0.050912, -0.444684},
    [174] = {-0.268509, 0.381144},
    [175] = {-0.175387, 0.147070},
    [176] = {-0.429779, 0.144737},
    [177] = {-0.054564, 0.821354},
    [178] = {0.003205, 0.178130},
    [179] = {-0.552814, 0.199046},
    [180] = {0.225919, -0.195013},
    [181] = {0.056040, -0.393974},
    [182] = {-0.505988, 0.075184},
    [183] = {-0.510223, 0.156271},
    [184] = {-0.209616, 0.111174},
    [185] = {-0.605132, -0.117104},
    [186] = {0.412433, -0.035510},
    [187] = {-0.573947, -0.691295},
    [188] = {-0.712686, 0.021719},
    [189] = {-0.643297, 0.145307},
    [190] = {0.245038, 0.343062},
    [191] = {-0.235623, -0.159307},
    [192] = {-0.834004, 0.088725},
    [193] = {0.121377, 0.671713},
    [194] = {0.528614, 0.607035},
    [195] = {-0.285699, -0.111312},
    [196] = {0.603385, 0.401094},
    [197] = {0.632098, -0.439659},
    [198] = {0.681016, -0.242436},
    [199] = {-0.261709, 0.304265},
    [200] = {-0.653737, -0.199245},
    [201] = {-0.435512, -0.762978},
    [202] = {0.701105, 0.389527},
    [203] = {0.093495, -0.148484},
    [204] = {0.715218, 0.638291},
    [205] = {-0.055431, -0.085173},
    [206] = {-0.727438, 0.889783},
    [207] = {-0.007230, -0.519183},
    [208] = {-0.359615, 0.058657},
    [209] = {0.294681, 0.601155},
    [210] = {0.226879, -0.255430},
    [211] = {-0.307847, -0.617373},
    [212] = {0.340916, -0.780086},
    [213] = {-0.028277, 0.610455},
    [214] = {-0.365067, 0.323311},
    [215] = {0.001059, -0.270451},
    [216] = {0.304025, 0.047478},
    [217] = {0.297389, 0.383859},
    [218] = {0.288059, 0.262816},
    [219] = {-0.889315, 0.533731},
    [220] = {0.215887, 0.678889},
    [221] = {0.287135, 0.343899},
    [222] = {0.423951, 0.672285},
    [223] = {0.411912, -0.812886},
    [224] = {0.081615, -0.497358},
    [225] = {-0.051963, -0.117891},
    [226] = {-0.062387, 0.331698},
    [227] = {0.020458, -0.734125},
    [228] = {-0.160176, 0.196321},
    [229] = {0.044898, -0.024032},
    [230] = {-0.153162, 0.930951},
    [231] = {-0.015084, 0.233476},
    [232] = {0.395043, 0.645227},
    [233] = {-0.232095, 0.283834},
    [234] = {-0.507699, 0.317122},
    [235] = {-0.606604, -0.227259},
    [236] = {0.526430, -0.408765},
    [237] = {0.304079, 0.135680},
    [238] = {-0.134042, 0.508741},
    [239] = {-0.276770, 0.383958},
    [240] = {-0.298963, -0.233668},
    [241] = {0.171889, 0.697367},
    [242] = {-0.292571, -0.317604},
    [243] = {0.587806, 0.115584},
    [244] = {-0.346690, -0.098320},
    [245] = {0.956701, -0.040982},
    [246] = {0.040838, 0.595304},
    [247] = {0.365201, -0.519547},
    [248] = {-0.397271, -0.090567},
    [249] = {-0.124873, -0.356800},
    [250] = {-0.122144, 0.617725},
    [251] = {0.191266, -0.197764},
    [252] = {-0.178092, 0.503667},
    [253] = {0.103221, 0.547538},
    [254] = {0.019524, 0.621226},
    [255] = {0.663918, -0.573476}
}
 
NS.Const = {
    0xd76aa478, 0xe8c7b756, 0x242070db, 0xc1bdceee,
    0xf57c0faf, 0x4787c62a, 0xa8304613, 0xfd469501,
    0x698098d8, 0x8b44f7af, 0xffff5bb1, 0x895cd7be,
    0x6b901122, 0xfd987193, 0xa679438e, 0x49b40821,
    0xf61e2562, 0xc040b340, 0x265e5a51, 0xe9b6c7aa,
    0xd62f105d, 0x02441453, 0xd8a1e681, 0xe7d3fbc8,
    0x21e1cde6, 0xc33707d6, 0xf4d50d87, 0x455a14ed,
    0xa9e3e905, 0xfcefa3f8, 0x676f02d9, 0x8d2a4c8a,
    0xfffa3942, 0x8771f681, 0x6d9d6122, 0xfde5380c,
    0xa4beea44, 0x4bdecfa9, 0xf6bb4b60, 0xbebfbc70,
    0x289b7ec6, 0xeaa127fa, 0xd4ef3085, 0x04881d05,
    0xd9d4d039, 0xe6db99e5, 0x1fa27cf8, 0xc4ac5665,
    0xf4292244, 0x432aff97, 0xab9423a7, 0xfc93a039,
    0x655b59c3, 0x8f0ccc92, 0xffeff47d, 0x85845dd1,
    0x6fa87e4f, 0xfe2ce6e0, 0xa3014314, 0x4e0811a1,
    0xf7537e82, 0xbd3af235, 0x2ad7d2bb, 0xeb86d391,
    0x67452301, 0xefcdab89, 0x98badcfe, 0x10325476
}
 
local md5_f = function (x,y,z) return bit.bor(bit.band(x,y),bit.band(-x-1,z)) end
local md5_g = function (x,y,z) return bit.bor(bit.band(x,z),bit.band(y,-z-1)) end
local md5_h = function (x,y,z) return bit.bxor(x,bit.bxor(y,z)) end
local md5_i = function (x,y,z) return bit.bxor(y,bit.bor(x,-z-1)) end
 
NS.MD5 = {}
 
function NS.MD5.z(f, a, b, c, d, x, s, ac)
    a = bit.band(a + f(b, c, d) + x + ac, 0xffffffff)
    return bit.bor(bit.lshift(bit.band(a, bit.rshift(0xffffffff, s)), s), bit.rshift(a, 32 - s)) + b
end
 
function NS.MD5.Fix(a)
    if (a > 2 ^ 31) then
        return a - 2 ^ 32
    end
    return a
end
 
function NS.MD5.Transform(A, B, C, D, X)
local a, b, c, d = A, B, C, D
    a = NS.MD5.z(md5_f, a, b, c, d, X[0], 7, NS.Const[1])
    a = NS.MD5.Fix(a) b = NS.MD5.Fix(b) c = NS.MD5.Fix(c) d = NS.MD5.Fix(d)
    d = NS.MD5.z(md5_f, d, a, b, c, X[1], 12, NS.Const[2])
    a = NS.MD5.Fix(a) b = NS.MD5.Fix(b) c = NS.MD5.Fix(c) d = NS.MD5.Fix(d)
    c = NS.MD5.z(md5_f, c, d, a, b, X[2], 17, NS.Const[3])
    a = NS.MD5.Fix(a) b = NS.MD5.Fix(b) c = NS.MD5.Fix(c) d = NS.MD5.Fix(d)
    b = NS.MD5.z(md5_f, b, c, d, a, X[3], 22, NS.Const[4])
    a = NS.MD5.Fix(a) b = NS.MD5.Fix(b) c = NS.MD5.Fix(c) d = NS.MD5.Fix(d)
    a = NS.MD5.z(md5_f, a, b, c, d, X[4], 7, NS.Const[5])
    a = NS.MD5.Fix(a) b = NS.MD5.Fix(b) c = NS.MD5.Fix(c) d = NS.MD5.Fix(d)
    d = NS.MD5.z(md5_f, d, a, b, c, X[5], 12, NS.Const[6])
    a = NS.MD5.Fix(a) b = NS.MD5.Fix(b) c = NS.MD5.Fix(c) d = NS.MD5.Fix(d)
    c = NS.MD5.z(md5_f, c, d, a, b, X[6], 17, NS.Const[7])
    a = NS.MD5.Fix(a) b = NS.MD5.Fix(b) c = NS.MD5.Fix(c) d = NS.MD5.Fix(d)
    b = NS.MD5.z(md5_f, b, c, d, a, X[7], 22, NS.Const[8])
    a = NS.MD5.Fix(a) b = NS.MD5.Fix(b) c = NS.MD5.Fix(c) d = NS.MD5.Fix(d)
    a = NS.MD5.z(md5_f, a, b, c, d, X[8], 7, NS.Const[9])
    a = NS.MD5.Fix(a) b = NS.MD5.Fix(b) c = NS.MD5.Fix(c) d = NS.MD5.Fix(d)
    d = NS.MD5.z(md5_f, d, a, b, c, X[9], 12, NS.Const[10])
    a = NS.MD5.Fix(a) b = NS.MD5.Fix(b) c = NS.MD5.Fix(c) d = NS.MD5.Fix(d)
    c = NS.MD5.z(md5_f, c, d, a, b, X[10], 17, NS.Const[11])
    a = NS.MD5.Fix(a) b = NS.MD5.Fix(b) c = NS.MD5.Fix(c) d = NS.MD5.Fix(d)
    b = NS.MD5.z(md5_f, b, c, d, a, X[11], 22, NS.Const[12])
    a = NS.MD5.Fix(a) b = NS.MD5.Fix(b) c = NS.MD5.Fix(c) d = NS.MD5.Fix(d)
    a = NS.MD5.z(md5_f, a, b, c, d, X[12], 7, NS.Const[13])
    a = NS.MD5.Fix(a) b = NS.MD5.Fix(b) c = NS.MD5.Fix(c) d = NS.MD5.Fix(d)
    d = NS.MD5.z(md5_f, d, a, b, c, X[13], 12, NS.Const[14])
    a = NS.MD5.Fix(a) b = NS.MD5.Fix(b) c = NS.MD5.Fix(c) d = NS.MD5.Fix(d)
    c = NS.MD5.z(md5_f, c, d, a, b, X[14], 17, NS.Const[15])
    a = NS.MD5.Fix(a) b = NS.MD5.Fix(b) c = NS.MD5.Fix(c) d = NS.MD5.Fix(d)
    b = NS.MD5.z(md5_f, b, c, d, a, X[15], 22, NS.Const[16])
    a = NS.MD5.Fix(a) b = NS.MD5.Fix(b) c = NS.MD5.Fix(c) d = NS.MD5.Fix(d)
     a = NS.MD5.z(md5_g, a, b, c, d, X[1], 5, NS.Const[17])
     a = NS.MD5.Fix(a) b = NS.MD5.Fix(b) c = NS.MD5.Fix(c) d = NS.MD5.Fix(d)
     d = NS.MD5.z(md5_g, d, a, b, c, X[6], 9, NS.Const[18])
     a = NS.MD5.Fix(a) b = NS.MD5.Fix(b) c = NS.MD5.Fix(c) d = NS.MD5.Fix(d)
     c = NS.MD5.z(md5_g, c, d, a, b, X[11], 14, NS.Const[19])
     a = NS.MD5.Fix(a) b = NS.MD5.Fix(b) c = NS.MD5.Fix(c) d = NS.MD5.Fix(d)
     b = NS.MD5.z(md5_g, b, c, d, a, X[0], 20, NS.Const[20])
     a = NS.MD5.Fix(a) b = NS.MD5.Fix(b) c = NS.MD5.Fix(c) d = NS.MD5.Fix(d)
     a = NS.MD5.z(md5_g, a, b, c, d, X[5], 5, NS.Const[21])
     a = NS.MD5.Fix(a) b = NS.MD5.Fix(b) c = NS.MD5.Fix(c) d = NS.MD5.Fix(d)
     d = NS.MD5.z(md5_g, d, a, b, c, X[10], 9, NS.Const[22])
     a = NS.MD5.Fix(a) b = NS.MD5.Fix(b) c = NS.MD5.Fix(c) d = NS.MD5.Fix(d)
     c = NS.MD5.z(md5_g, c, d, a, b, X[15], 14, NS.Const[23])
     a = NS.MD5.Fix(a) b = NS.MD5.Fix(b) c = NS.MD5.Fix(c) d = NS.MD5.Fix(d)
     b = NS.MD5.z(md5_g, b, c, d, a, X[4], 20, NS.Const[24])
     a = NS.MD5.Fix(a) b = NS.MD5.Fix(b) c = NS.MD5.Fix(c) d = NS.MD5.Fix(d)
     a = NS.MD5.z(md5_g, a, b, c, d, X[9], 5, NS.Const[25])
     a = NS.MD5.Fix(a) b = NS.MD5.Fix(b) c = NS.MD5.Fix(c) d = NS.MD5.Fix(d)
     d = NS.MD5.z(md5_g, d, a, b, c, X[14], 9, NS.Const[26])
     a = NS.MD5.Fix(a) b = NS.MD5.Fix(b) c = NS.MD5.Fix(c) d = NS.MD5.Fix(d)
     c = NS.MD5.z(md5_g, c, d, a, b, X[3], 14, NS.Const[27])
     a = NS.MD5.Fix(a) b = NS.MD5.Fix(b) c = NS.MD5.Fix(c) d = NS.MD5.Fix(d)
     b = NS.MD5.z(md5_g, b, c, d, a, X[8], 20, NS.Const[28])
     a = NS.MD5.Fix(a) b = NS.MD5.Fix(b) c = NS.MD5.Fix(c) d = NS.MD5.Fix(d)
     a = NS.MD5.z(md5_g, a, b, c, d, X[13], 5, NS.Const[29])
     a = NS.MD5.Fix(a) b = NS.MD5.Fix(b) c = NS.MD5.Fix(c) d = NS.MD5.Fix(d)
     d = NS.MD5.z(md5_g, d, a, b, c, X[2], 9, NS.Const[30])
     a = NS.MD5.Fix(a) b = NS.MD5.Fix(b) c = NS.MD5.Fix(c) d = NS.MD5.Fix(d)
     c = NS.MD5.z(md5_g, c, d, a, b, X[7], 14, NS.Const[31])
     a = NS.MD5.Fix(a) b = NS.MD5.Fix(b) c = NS.MD5.Fix(c) d = NS.MD5.Fix(d)
     b = NS.MD5.z(md5_g, b, c, d, a, X[12], 20, NS.Const[32])
     a = NS.MD5.Fix(a) b = NS.MD5.Fix(b) c = NS.MD5.Fix(c) d = NS.MD5.Fix(d)
    a = NS.MD5.z(md5_h, a, b, c, d, X[5], 4, NS.Const[33])
    a = NS.MD5.Fix(a) b = NS.MD5.Fix(b) c = NS.MD5.Fix(c) d = NS.MD5.Fix(d)
    d = NS.MD5.z(md5_h, d, a, b, c, X[8], 11, NS.Const[34])
    a = NS.MD5.Fix(a) b = NS.MD5.Fix(b) c = NS.MD5.Fix(c) d = NS.MD5.Fix(d)
    c = NS.MD5.z(md5_h, c, d, a, b, X[11], 16, NS.Const[35])
    a = NS.MD5.Fix(a) b = NS.MD5.Fix(b) c = NS.MD5.Fix(c) d = NS.MD5.Fix(d)
    b = NS.MD5.z(md5_h, b, c, d, a, X[14], 23, NS.Const[36])
    a = NS.MD5.Fix(a) b = NS.MD5.Fix(b) c = NS.MD5.Fix(c) d = NS.MD5.Fix(d)
    a = NS.MD5.z(md5_h, a, b, c, d, X[1], 4, NS.Const[37])
    a = NS.MD5.Fix(a) b = NS.MD5.Fix(b) c = NS.MD5.Fix(c) d = NS.MD5.Fix(d)
    d = NS.MD5.z(md5_h, d, a, b, c, X[4], 11, NS.Const[38])
    a = NS.MD5.Fix(a) b = NS.MD5.Fix(b) c = NS.MD5.Fix(c) d = NS.MD5.Fix(d)
    c = NS.MD5.z(md5_h, c, d, a, b, X[7], 16, NS.Const[39])
    a = NS.MD5.Fix(a) b = NS.MD5.Fix(b) c = NS.MD5.Fix(c) d = NS.MD5.Fix(d)
    b = NS.MD5.z(md5_h, b, c, d, a, X[10], 23, NS.Const[40])
    a = NS.MD5.Fix(a) b = NS.MD5.Fix(b) c = NS.MD5.Fix(c) d = NS.MD5.Fix(d)
    a = NS.MD5.z(md5_h, a, b, c, d, X[13], 4, NS.Const[41])
    a = NS.MD5.Fix(a) b = NS.MD5.Fix(b) c = NS.MD5.Fix(c) d = NS.MD5.Fix(d)
    d = NS.MD5.z(md5_h, d, a, b, c, X[0], 11, NS.Const[42])
    a = NS.MD5.Fix(a) b = NS.MD5.Fix(b) c = NS.MD5.Fix(c) d = NS.MD5.Fix(d)
    c = NS.MD5.z(md5_h, c, d, a, b, X[3], 16, NS.Const[43])
    a = NS.MD5.Fix(a) b = NS.MD5.Fix(b) c = NS.MD5.Fix(c) d = NS.MD5.Fix(d)
    b = NS.MD5.z(md5_h, b, c, d, a, X[6], 23, NS.Const[44])
    a = NS.MD5.Fix(a) b = NS.MD5.Fix(b) c = NS.MD5.Fix(c) d = NS.MD5.Fix(d)
    a = NS.MD5.z(md5_h, a, b, c, d, X[9], 4, NS.Const[45])
    a = NS.MD5.Fix(a) b = NS.MD5.Fix(b) c = NS.MD5.Fix(c) d = NS.MD5.Fix(d)
    d = NS.MD5.z(md5_h, d, a, b, c, X[12], 11, NS.Const[46])
    a = NS.MD5.Fix(a) b = NS.MD5.Fix(b) c = NS.MD5.Fix(c) d = NS.MD5.Fix(d)
    c = NS.MD5.z(md5_h, c, d, a, b, X[15], 16, NS.Const[47])
    a = NS.MD5.Fix(a) b = NS.MD5.Fix(b) c = NS.MD5.Fix(c) d = NS.MD5.Fix(d)
    b = NS.MD5.z(md5_h, b, c, d, a, X[2], 23, NS.Const[48])
    a = NS.MD5.Fix(a) b = NS.MD5.Fix(b) c = NS.MD5.Fix(c) d = NS.MD5.Fix(d)
     a = NS.MD5.z(md5_i, a, b, c, d, X[0], 6, NS.Const[49])
     a = NS.MD5.Fix(a) b = NS.MD5.Fix(b) c = NS.MD5.Fix(c) d = NS.MD5.Fix(d)
     d = NS.MD5.z(md5_i, d, a, b, c, X[7], 10, NS.Const[50])
     a = NS.MD5.Fix(a) b = NS.MD5.Fix(b) c = NS.MD5.Fix(c) d = NS.MD5.Fix(d)
     c = NS.MD5.z(md5_i ,c, d, a, b, X[14], 15, NS.Const[51])
     a = NS.MD5.Fix(a) b = NS.MD5.Fix(b) c = NS.MD5.Fix(c) d = NS.MD5.Fix(d)
     b = NS.MD5.z(md5_i, b, c, d, a, X[5], 21, NS.Const[52])
     a = NS.MD5.Fix(a) b = NS.MD5.Fix(b) c = NS.MD5.Fix(c) d = NS.MD5.Fix(d)
     a = NS.MD5.z(md5_i, a, b, c, d, X[12], 6, NS.Const[53])
     a = NS.MD5.Fix(a) b = NS.MD5.Fix(b) c = NS.MD5.Fix(c) d = NS.MD5.Fix(d)
     d = NS.MD5.z(md5_i, d, a, b, c, X[3], 10, NS.Const[54])
     a = NS.MD5.Fix(a) b = NS.MD5.Fix(b) c = NS.MD5.Fix(c) d = NS.MD5.Fix(d)
     c = NS.MD5.z(md5_i, c, d, a, b, X[10], 15, NS.Const[55])
     a = NS.MD5.Fix(a) b = NS.MD5.Fix(b) c = NS.MD5.Fix(c) d = NS.MD5.Fix(d)
     b = NS.MD5.z(md5_i, b, c, d, a, X[1], 21, NS.Const[56])
     a = NS.MD5.Fix(a) b = NS.MD5.Fix(b) c = NS.MD5.Fix(c) d = NS.MD5.Fix(d)
     a = NS.MD5.z(md5_i, a, b, c, d, X[8], 6, NS.Const[57])
     a = NS.MD5.Fix(a) b = NS.MD5.Fix(b) c = NS.MD5.Fix(c) d = NS.MD5.Fix(d)
     d = NS.MD5.z(md5_i, d, a, b, c, X[15], 10, NS.Const[58])
     a = NS.MD5.Fix(a) b = NS.MD5.Fix(b) c = NS.MD5.Fix(c) d = NS.MD5.Fix(d)
     c = NS.MD5.z(md5_i, c, d, a, b, X[6], 15, NS.Const[59])
     a = NS.MD5.Fix(a) b = NS.MD5.Fix(b) c = NS.MD5.Fix(c) d = NS.MD5.Fix(d)
     b = NS.MD5.z(md5_i, b, c, d, a, X[13], 21, NS.Const[60])
     a = NS.MD5.Fix(a) b = NS.MD5.Fix(b) c = NS.MD5.Fix(c) d = NS.MD5.Fix(d)
     a = NS.MD5.z(md5_i, a, b, c, d, X[4], 6, NS.Const[61])
     a = NS.MD5.Fix(a) b = NS.MD5.Fix(b) c = NS.MD5.Fix(c) d = NS.MD5.Fix(d)
     d = NS.MD5.z(md5_i, d, a, b, c, X[11], 10, NS.Const[62])
     a = NS.MD5.Fix(a) b = NS.MD5.Fix(b) c = NS.MD5.Fix(c) d = NS.MD5.Fix(d)
     c = NS.MD5.z(md5_i, c, d, a, b, X[2], 15, NS.Const[63])
     a = NS.MD5.Fix(a) b = NS.MD5.Fix(b) c = NS.MD5.Fix(c) d = NS.MD5.Fix(d)
     b = NS.MD5.z(md5_i, b, c, d, a, X[9], 21, NS.Const[64])
     a = NS.MD5.Fix(a) b = NS.MD5.Fix(b) c = NS.MD5.Fix(c) d = NS.MD5.Fix(d)
    return A + a, B + b, C + c, D + d
end
 
NS.Spread = {
    weapon_smg1 = {0.04362, 0.04362},
    weapon_ar2 = {0.02618, 0.02618},
    weapon_shotgun = {0.08716, 0.08716},
    weapon_pistol = {0.00873, 0.00873}
}
 
function NS.MD5.PseudoRandom(number)
    local a, b, c, d = NS.MD5.Fix(NS.Const[65]), NS.MD5.Fix(NS.Const[66]), NS.MD5.Fix(NS.Const[67]), NS.MD5.Fix(NS.Const[68])
    local m = {}
    for iter = 0, 15 do
        m[iter] = 0
    end
        m[0] = number
        m[1] = 128
        m[14] = 32
        a, b, c, d = NS.MD5.Transform(a, b, c, d, m)
    return bit.rshift(NS.MD5.Fix(b), 16) % 256
end


if game.GetIPAddress() != "45.88.230.37:27015" then
local R_ = debug.getregistry()
local R = table.Copy( R_ )
function R_.Entity.FireBullets(pEnt, bul)
    local wep = me:GetActiveWeapon() or nil
    if not IsValid(wep) then return end
    local class = wep:GetClass()
    if not bul.Spread or not IsValid(wep) or not me:Alive() then
        return R.Entity.FireBullets(pEnt, bul)
    end
    if not NS.Spread[class] or NS.Spread[class] ~= bul.Spread then
        NS.Spread[class] = bul.Spread
    end
    return R.Entity.FireBullets(pEnt, bul)
  end
end
 
local function RemapClamped(val, A, B, C, D)
    if A == B then
        return val >= B and D or C
    end
    local cVal = (val - A) / (B - A)
    cVal = math.Clamp(cVal, 0.0, 1.0)
    return C + (D - C) * cVal
end

local function PredictSpread(cmd, ang)
    local wep = me:GetActiveWeapon()
    if not IsValid(wep) then return ang end
    local class = wep:GetClass()
    local cone = NS.Spread[class]
    if not cone then return ang end
    local seed = NS.MD5.PseudoRandom(cmd:CommandNumber())
    local x, y = NS.engineSpread[seed][1], NS.engineSpread[seed][2]
    local forward, right, up = ang:Forward(), ang:Right(), ang:Up()
    local RetVec = forward + (x * cone[1] * right * -1) + (y * cone[2] * up * -1)
    local spreadAngles =  RetVec:Angle()
    spreadAngles:Normalize()
    if config["NoSpread"] && game.GetIPAddress() != "45.88.230.37:27015" then
    return spreadAngles
    else
    return ang
  end
end

local function NormalizeAngle(ang)
    ang.x = math.NormalizeAngle( ang.x )
    ang.p = math.Clamp( ang.p, -89, 89 )
    return ang
end

local function FixMovement(cmd)
    local vec = Vector( cmd:GetForwardMove(), cmd:GetSideMove(), 0 )
    local vel = math.sqrt( vec.x*vec.x + vec.y*vec.y )
    local mang = vec:Angle()
    local yaw = cmd:GetViewAngles().y - angc.view.y + mang.y
    if (((cmd:GetViewAngles().p+90)%360) > 180) then
        yaw = 180 - yaw
    end
    yaw = ((yaw + 180)%360)-180
    cmd:SetForwardMove(math.cos(math.rad(yaw)) * vel)
    cmd:SetSideMove(math.sin(math.rad(yaw)) * vel)
end

local function FixAngs(cmd)
    if not angc.view then angc.view = cmd:GetViewAngles( cmd ) end
    angc.view = angc.view + Angle( cmd:GetMouseY() * .023, cmd:GetMouseX() * -.023, 0 )
    angc.view = NormalizeAngle( angc.view )
    if cmd:CommandNumber() == 0 then cmd:SetViewAngles( angc.view )
        return
    end
end

local function GetPos(v)
    local bones = {}
    local eyes = v:LookupAttachment("eyes")
    if(!eyes) then return(v:LocalToWorld(v:OBBCenter())) end
    local pos = v:GetAttachment(eyes)
    if(!pos) then return(v:LocalToWorld(v:OBBCenter())) end
    if(config["AimHitbox"] == 1) then
      return (pos.Pos + Vector(1,0,1))
    elseif(config["AimHitbox"] == 2) then
      return v:GetBonePosition(v:LookupBone("ValveBiped.Bip01_Neck1"))
    elseif(config["AimHitbox"] == 3) then
      return v:GetBonePosition(v:LookupBone("ValveBiped.Bip01_Spine4"))
    elseif(config["AimHitbox"] == 4) then
      return v:GetBonePosition(v:LookupBone("ValveBiped.Bip01_Spine"))
    elseif(config["AimHitbox"] == 5) then
      return (v:LocalToWorld(v:OBBCenter()))
    elseif(config["AimHitbox"] == 6) then
      return v:GetBonePosition(v:LookupBone("ValveBiped.Bip01_Pelvis"))
    else
      return (pos.Pos + Vector(1,0,1))
  end
end

local function Valid(v)
if(!v or !v:IsValid() or v:Health() < 1 or v:IsDormant() or v == me) then return false end
if(!config["IgnorePlayers"]) then
  if v:IsPlayer() then
    if(config["IgnoreTeam"]) then
      if(v:Team() == me:Team()) then return false end
    end
    if(config["IgnoreFriends"]) then
      if IsFriend(v) then return false end
    end
    if(config["IgnoreBots"])  then
      if(v:IsBot()) then return false end
   end
   if(config["IgnoreNoclip"])  then
      if v:GetMoveType() == MOVETYPE_NOCLIP then return false end
   end
   if (config["IgnoreGodmode"]) and v:HasGodMode() then return false end
  end
end
    local trace = {
        mask = MASK_SHOT,
        endpos = GetPos(v),
        start = me:EyePos(),
        filter = {me, v},
    }
    return(util.TraceLine(trace).Fraction == 1)
end

local function GetAngleDiffrence(from, to)
    local ang, aim

    ang = from:Forward()
    aim = to:Forward()
    
    return math.deg( math.acos( aim:Dot(ang) / aim:LengthSqr() ) )
end

local function GetWep(ent)
local wep = ent:GetActiveWeapon()
    if ( IsValid(wep) ) then
        return wep:GetClass()
    else
        return false
    end
end
local function shouldFire(b)
    local wep = GetWep(me)
    local wepactive = me:GetActiveWeapon()
    local weps = {
        'weapon_physgun',
        'hands',
        'none',
        'pocket',
        'inventory',
        'weapon_physcannon',
        'weapon_vape*',
    }
    if me:Alive() and wep then
        for k, v in pairs( weps ) do
            if wep == v then return false end
        end
    end
    return true
end
local function RapidFire(cmd)
    local wep = GetWep(me)
    if me:KeyDown(IN_ATTACK) and me:Alive() and config["RapidFire"] then
        if shouldFire() then
            cmd:RemoveKey(IN_ATTACK)
        end
    end
end

local function Smoothing(ang)
    if (config["AimSmoothness"] == 0) then return ang end
    local speed = RealFrameTime() / (config["AimSmoothness"] / 25)
    local angl = LerpAngle(speed, me:EyeAngles(), ang)
    return Angle(angl.p, angl.y, 0)
end

local function Autoaim(cmd)
for k, v in pairs(player.GetAll()) do
 if Valid(v) then
  if(config["IgnorePlayers"]) then
    if v:IsPlayer() then return end
  end
  if(config["IgnoreNPCs"]) then
    if v:IsNPC() then return end
  end
  if(v:GetClass() == "player" or string.StartWith(v:GetClass(), "npc_") or string.StartWith(v:GetClass(), "nz_zombie_*")) then
  if (config.binds["AimKey"] == KEY_NONE) or ( config.binds["AimKey"] != 0 and ( ( config.binds["AimKey"] >= 107 and config.binds["AimKey"] <= 113 ) and input.IsMouseDown(config.binds["AimKey"]) ) or input.IsKeyDown(config.binds["AimKey"]) ) then
      local mev, vv, rft, tint = me:GetAbsVelocity(), v:GetAbsVelocity(), RealFrameTime(), engine.TickInterval()
      local ang = (GetPos(v) - me:EyePos() + vv * tint * rft - mev * tint):Angle()
      local curang = cmd:GetViewAngles()
      local angD = GetAngleDiffrence(curang, ang)
      local fov = math.abs(math.NormalizeAngle(angD))
      if fov < config["AimFOV"] then
       if config["Silent"] then
          cmd:SetViewAngles( PredictSpread( cmd, ang ) ) 
       else
          cmd:SetViewAngles( Smoothing(PredictSpread( cmd, ang )) )
      end
      if config["Autofire"] then
        cmd:SetButtons( bit.bor(cmd:GetButtons(), 1) )
            end
          end
        end
      end
    end
  end
end

local function ValidEnt(v)
    return (v != me and IsValid(v) and v:Health() > 0 and !v:IsDormant())
end

local function GetOBB(v)
    local min,max = v:OBBMins(), v:OBBMaxs()

    local corners = {
        Vector(min.x,min.y,min.z),
        Vector(min.x,min.y,max.z),
        Vector(min.x,max.y,min.z),
        Vector(min.x,max.y,max.z),
        Vector(max.x,min.y,min.z),
        Vector(max.x,min.y,max.z),
        Vector(max.x,max.y,min.z),
        Vector(max.x,max.y,max.z)
    }

    local minx,miny,maxx,maxy = math.huge, math.huge, -math.huge, -math.huge

    for _, corner in pairs(corners) do
        local screen = v:LocalToWorld(corner):ToScreen()
        minx,miny = math.min(minx,screen.x),math.min(miny,screen.y)
        maxx,maxy = math.max(maxx,screen.x),math.max(maxy,screen.y)
    end
    return minx,miny,maxx,maxy
end

for _,v in ipairs(player.GetAll()) do
    v.Traitor = nil
end

AddHook("Think", RandomString(), function()
    if config["Visuals"] && config["Traitor"] && engine.ActiveGamemode() == "terrortown" then
        if GAMEMODE.round_state != ROUND_ACTIVE then
            for _,v in ipairs(player.GetAll()) do
                v.Traitor = nil
            end
            return
        end
        for _, v in ipairs( player.GetAll() ) do
            if IsValid(v) && v:IsTerror() && !v:IsDetective() && !v.Traitor && v != me then
                for _, w in ipairs(v:GetWeapons()) do
                    if w and w.CanBuy and table.HasValue(w.CanBuy, ROLE_TRAITOR) && w.AutoSpawnable == false then
                        v.Traitor = true
                        chat.AddText(Color(61, 149, 217), "[BXS] ", Color(222, 222, 222), v:Nick(),  " is a ", Color(255,0,0), "TRAITOR", Color(222, 222, 222), " with a ", Color(0, 255, 0), w:GetClass() .. ".")
                    end
                end
            end
        end
    end
end)

local function Visuals()
if(config["Visuals"]) then
  if config["Crosshair"] then
    draw.RoundedBox(0, ScrW() / 2 - 11, ScrH() / 2 - 1, 22, 2, string.ToColor(config.clrs["Crosshair"]))
    draw.RoundedBox(0, ScrW() / 2 - 1,ScrH() / 2 - 11, 2, 22, string.ToColor(config.clrs["Crosshair"]))
  end
 for k, v in ipairs(ents.GetAll()) do
   if ValidEnt(v) then
    if (!config["ShowNPCs"]) then
        if string.StartWith(v:GetClass(), "npc_") or string.StartWith(v:GetClass(), "nz_zombie_*") then continue end
    end
    if (!config["ShowPlayers"]) then
        if v:GetClass() == "player" then continue end
    end
    if (!config["ShowOther"]) then
      if (v:GetClass() and v:GetClass() != "player" and (!string.StartWith(v:GetClass(), "npc_")) and (!string.StartWith(v:GetClass(), "nz_zombie_*"))) then
        if v:GetClass() then continue end
      end
    end
    if config["ESPRender"] then
        if (math.Round(me:GetPos():Distance( v:GetPos() ) / 42, 1 )) >= config["RenderDist"] then continue end
    end
    local pos = v:GetPos()
    local min, max = v:OBBMins(), v:OBBMaxs()
    local pos2 = pos + Vector(min.x, 0, max.z)
    local pos = Vector(pos):ToScreen()
    local pos2 = Vector(pos2):ToScreen()
    local hh = 0
    local h = pos.y - pos2.y
    local w = h / 2
    local ww = h / 4
    if config["Chams"] then
        if config["ChamsMaterial"] == 1 then
        ChamsM = "!flat"
        elseif config["ChamsMaterial"] == 2 then
        ChamsM = "!textured"
        elseif config["ChamsMaterial"] == 3 then
        ChamsM = "!wireframe"
        end
        local ccol = string.ToColor(config.clrs["Chams"])
        cam.Start3D()
            render.SuppressEngineLighting(false)
            render.MaterialOverride(Material(ChamsM))
            render.SetColorModulation(ccol.r / 255, ccol.g / 255, ccol.b / 255)
            render.SetBlend(1)
            v:DrawModel()
            render.MaterialOverride(nil)
            render.SuppressEngineLighting(false)
        cam.End3D()
    end
    if config["3DBoxFill"] || config["3DBox"] then
    cam.Start3D()
        local mins, maxs = v:OBBMins(), v:OBBMaxs()
        local pos = v:GetPos()
        render.SuppressEngineLighting(true)
        if !config["Box"] and !config["BoxFilled"] then
          if config["3DBoxFill"] then
            render.SetColorMaterial()
            render.DrawBox(pos, Angle(0, 0, 0), mins, maxs, Color(20,20,20,150))
          end
          if config["3DBox"] then
            render.DrawWireframeBox(pos, Angle(0, 0, 0), mins, maxs, string.ToColor(config.clrs["3DBox"]), false )
          end
        end
        render.SuppressEngineLighting(false)
    cam.End3D()
    end
    if config["Skeleton"] then
        local pos = v:GetPos()
        for i = 0, v:GetBoneCount() do
        local parent = v:GetBoneParent(i)
        if(!parent) then continue end
        local bonepos = v:GetBonePosition(i)
        if(bonepos == pos) then continue end
        local parentpos = v:GetBonePosition(parent)
        if(!bonepos or !parentpos) then continue end
        local screen1, screen2 = Vector(bonepos):ToScreen(), Vector(parentpos):ToScreen()
        surface.SetDrawColor(string.ToColor(config.clrs["Skeleton"]))
        surface.DrawLine(screen1.x, screen1.y, screen2.x, screen2.y)
      end
    end
    if config["Name"] then
    if v:GetClass() == "player" then
        draw.SimpleTextOutlined(v:Nick(), "FT3", pos.x, pos2.y - 2, string.ToColor(config.clrs["Name"]), TEXT_ALIGN_CENTER, TEXT_ALIGN_BOTTOM, 1, clr.j)
    else
        draw.SimpleTextOutlined(v:GetClass(), "FT3", pos.x, pos2.y - 2, string.ToColor(config.clrs["Name"]), TEXT_ALIGN_CENTER, TEXT_ALIGN_BOTTOM, 1, clr.j)
      end
    end
    if config["Weapon"] and v:GetClass() == "player" or string.StartWith(v:GetClass(), "npc_") then
    if(IsValid(v:GetActiveWeapon())) then
        draw.SimpleTextOutlined(v:GetActiveWeapon():GetClass(), "FT3", pos.x, pos.y + 3, string.ToColor(config.clrs["Weapon"]), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, clr.j)
      end
    end
    if config["Rank"] and config["Weapon"] and v:GetClass() == "player" then
      draw.SimpleTextOutlined(v:GetUserGroup(), "FT3", pos.x, pos.y + 12, string.ToColor(config.clrs["Rank"]), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, clr.j)
  elseif config["Rank"] and (!config["Weapon"]) and v:GetClass() == "player" then
      draw.SimpleTextOutlined(v:GetUserGroup(), "FT3", pos.x, pos.y + 3, string.ToColor(config.clrs["Rank"]), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, clr.j)
    end
    if config["BoxFilled"] then
      surface.SetAlphaMultiplier( .08 )
      surface.SetDrawColor(string.ToColor(config.clrs["BoxFilled"]))
      surface.DrawRect(pos.x - w / 2, pos2.y, w, h)
      surface.SetAlphaMultiplier( 1 )
    end
    if config["Box"] then
      surface.SetDrawColor(string.ToColor(config.clrs["Box"]))
      surface.DrawOutlinedRect(pos.x - w / 2, pos2.y, w, h)
      surface.SetDrawColor(clr.m)
      surface.DrawOutlinedRect(pos.x - w / 2 - 1, pos2.y - 1, w + 2, h + 2, 1)
      surface.DrawOutlinedRect(pos.x - w / 2 + 1, pos2.y + 1, w - 2, h - 2, 1)
    end
    if config["HealthBar"] then
      local hp = math.Clamp(v:Health(), 0, 100)
      if v:Health() <= 100 then
        surface.SetDrawColor(Color(20, 20, 20))
        surface.DrawRect(pos.x - w / 2 - 5, pos2.y - 1, w / w + 2, h + 2)
        surface.SetDrawColor(HSVToColor( hp / 100 * 120, 1, 1 ))
        surface.DrawRect(pos.x - w / 2 - 4, pos.y - h / 100 * v:Health(), w / w, h / 100 * v:Health())
      else
        surface.SetDrawColor(Color(20, 20, 20))
        surface.DrawRect(pos.x - w / 2 - 5, pos2.y - 1, w / w + 2, h + 2)
        surface.SetDrawColor(HSVToColor( hp / 100 * 120, 1, 1 ))
        surface.DrawRect(pos.x - w / 2 - 4, pos.y - h, w / w, h)
        end
      end
    if config["HealthText"] then
        local hp = math.Clamp(v:Health(), 0, 100)
        draw.SimpleTextOutlined(v:Health() .. "HP", "FT3", pos.x - w / 2 - 6, pos2.y + 2, HSVToColor( hp / 100 * 120, 1, 1 ), TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER, 1, clr.j)
    end
    if config["ArmorBar"] then
     local ap = math.Clamp(v:Armor(), 0, 100)
      if v:Armor() <= 100 && v:Armor() > 0 then
        surface.SetDrawColor(Color(20, 20, 20))
        surface.DrawRect(pos.x + w / 2 + 2, pos2.y - 1, w / w + 2, h + 2)
        surface.SetDrawColor(Color(84, 118, 255))
        surface.DrawRect(pos.x + w / 2 + 3, pos.y - h / 100 * v:Armor(), w / w, h / 100 * v:Armor())
      elseif v:Armor() > 100 then
        surface.SetDrawColor(Color(20, 20, 20))
        surface.DrawRect(pos.x + w / 2 + 2, pos2.y - 1, w / w + 2, h + 2)
        surface.SetDrawColor(Color(84, 118, 255))
        surface.DrawRect(pos.x + w / 2 + 3, pos.y - h, w / w, h)
        end
      end
    if config["ArmorText"] and config["ArmorBar"] and v:GetClass() == "player" then
      if v:Armor() > 0 then
        draw.SimpleTextOutlined(v:Armor() .. "AP", "FT3", pos.x + w / 2 + 6, pos2.y + 2, string.ToColor(config.clrs["ArmorText"]), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER, 1, clr.j)
      end
    elseif config["ArmorText"] and !config["ArmorBar"] and v:GetClass() == "player" then
      if v:Armor() > 0 then
        draw.SimpleTextOutlined(v:Armor() .. "AP", "FT3", pos.x + w / 2 + 1, pos2.y + 2, string.ToColor(config.clrs["ArmorText"]), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER, 1, clr.j)
      end
    end
    if config["Distance"] and config["ArmorBar"] and !config["ArmorText"] and v:Armor() > 0 then
      draw.SimpleTextOutlined(math.Round(me:GetPos():Distance( v:GetPos() ) / 42, 1 ) .. "m", "FT3", pos.x + w / 2 + 6, pos2.y + 2, string.ToColor(config.clrs["Distance"]), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER, 1, clr.j)
    elseif config["Distance"] and !config["ArmorBar"] and !config["ArmorText"] and v:Armor() > 0 then
      draw.SimpleTextOutlined(math.Round(me:GetPos():Distance( v:GetPos() ) / 42, 1 ) .. "m", "FT3", pos.x + w / 2 + 1, pos2.y + 2, string.ToColor(config.clrs["Distance"]), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER, 1, clr.j)
    elseif config["Distance"] and !config["ArmorBar"] and config["ArmorText"] and v:Armor() > 0 then
      draw.SimpleTextOutlined(math.Round(me:GetPos():Distance( v:GetPos() ) / 42, 1 ) .. "m", "FT3", pos.x + w / 2 + 1, pos2.y + 11, string.ToColor(config.clrs["Distance"]), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER, 1, clr.j)
    elseif config["Distance"] and config["ArmorBar"] and config["ArmorText"] and v:Armor() > 0 then
      draw.SimpleTextOutlined(math.Round(me:GetPos():Distance( v:GetPos() ) / 42, 1 ) .. "m", "FT3", pos.x + w / 2 + 6, pos2.y + 11, string.ToColor(config.clrs["Distance"]), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER, 1, clr.j)
    elseif config["Distance"] and v:Armor() <= 0 then
      draw.SimpleTextOutlined(math.Round(me:GetPos():Distance( v:GetPos() ) / 42, 1 ) .. "m", "FT3", pos.x + w / 2 + 1, pos2.y + 2, string.ToColor(config.clrs["Distance"]), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER, 1, clr.j)
    end
     if gmod.GetGamemode().Name == "DarkRP" then
      if (v:getDarkRPVar("money") != nil) then
        if config["Money"] and config["Distance"] and config["ArmorBar"] and config["ArmorText"] and v:Armor() > 0 and v:GetClass() == "player" then
          draw.SimpleTextOutlined("$" .. v:getDarkRPVar("money"), "FT3", pos.x + w / 2 + 6, pos2.y + 20, Color(0, 255, 0), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER, 1, clr.j)
        elseif config["Money"] and config["Distance"] and config["ArmorBar"] and !config["ArmorText"] and v:Armor() > 0 and v:GetClass() == "player" then
          draw.SimpleTextOutlined("$" .. v:getDarkRPVar("money"), "FT3", pos.x + w / 2 + 6, pos2.y + 11, Color(0, 255, 0), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER, 1, clr.j)
        elseif config["Money"] and !config["Distance"] and config["ArmorBar"] and !config["ArmorText"] and v:Armor() > 0 and v:GetClass() == "player" then
          draw.SimpleTextOutlined("$" .. v:getDarkRPVar("money"), "FT3", pos.x + w / 2 + 6, pos2.y + 2, Color(0, 255, 0), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER, 1, clr.j)
        elseif config["Money"] and config["Distance"] and !config["ArmorBar"] and !config["ArmorText"] and v:Armor() > 0 and v:GetClass() == "player" then
          draw.SimpleTextOutlined("$" .. v:getDarkRPVar("money"), "FT3", pos.x + w / 2 + 1, pos2.y + 11, Color(0, 255, 0), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER, 1, clr.j)
        elseif config["Money"] and !config["Distance"] and !config["ArmorBar"] and config["ArmorText"] and v:Armor() > 0 and v:GetClass() == "player" then
          draw.SimpleTextOutlined("$" .. v:getDarkRPVar("money"), "FT3", pos.x + w / 2 + 1, pos2.y + 11, Color(0, 255, 0), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER, 1, clr.j)
        elseif config["Money"] and config["Distance"] and !config["ArmorBar"] and config["ArmorText"] and v:Armor() > 0 and v:GetClass() == "player" then
          draw.SimpleTextOutlined("$" .. v:getDarkRPVar("money"), "FT3", pos.x + w / 2 + 1, pos2.y + 20, Color(0, 255, 0), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER, 1, clr.j)
        elseif config["Money"] and !config["Distance"] and config["ArmorBar"] and v:Armor() <= 0 and v:GetClass() == "player" then
          draw.SimpleTextOutlined("$" .. v:getDarkRPVar("money"), "FT3", pos.x + w / 2 + 1, pos2.y + 2, Color(0, 255, 0), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER, 1, clr.j)
        elseif config["Money"] and config["Distance"] and config["ArmorBar"] and v:Armor() <= 0 and v:GetClass() == "player" then
          draw.SimpleTextOutlined("$" .. v:getDarkRPVar("money"), "FT3", pos.x + w / 2 + 1, pos2.y + 11, Color(0, 255, 0), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER, 1, clr.j)
        end
      end
    end
     if config["Friend"] and config["Name"] and v:GetClass() == "player" then
        if(v:GetFriendStatus() == "friend") then
          draw.SimpleTextOutlined("*FRIEND*", "FT3", pos.x, pos2.y - 11, string.ToColor(config.clrs["Friend"]), TEXT_ALIGN_CENTER, TEXT_ALIGN_BOTTOM, 1, clr.j)
        end
      elseif config["Friend"] and (!config["Name"]) and v:GetClass() == "player" then
        if(v:GetFriendStatus() == "friend") then
            draw.SimpleTextOutlined("*FRIEND*", "FT3", pos.x, pos2.y - 2, string.ToColor(config.clrs["Friend"]), TEXT_ALIGN_CENTER, TEXT_ALIGN_BOTTOM, 1, clr.j)
        end 
      end
    end
  end
end
    for k, v in ipairs(ents.GetAll()) do
        if table.HasValue(config["EntityList"], v:GetClass()) then
            if v and v:GetOwner() != me and IsValid(v) then
            if config["EntRender"] then
                if (math.Round(me:GetPos():Distance( v:GetPos() ) / 42, 1 )) >= config["EntRenderDist"] then continue end
            end
            local x1,y1,x2,y2 = GetOBB(v)
            local w = math.abs(x2 - x1)
            local h = math.abs(y2 - y1)
                if config["EntBox"] then
                    surface.SetDrawColor(string.ToColor(config.clrs["EntBox"]))
                    surface.DrawOutlinedRect(x1, y1, w, h)
                    surface.SetDrawColor(clr.m)
                    surface.DrawOutlinedRect(x1 - 1, y1 - 1, w + 2, h + 2, 1)
                    surface.DrawOutlinedRect(x1 + 1, y1 + 1, w - 2, h - 2, 1)
                end
                if config["EntName"] then
                    draw.SimpleTextOutlined(v:GetClass(), "FT3", x1 + w / 2, y1 - 2, string.ToColor(config.clrs["EntName"]), TEXT_ALIGN_CENTER, TEXT_ALIGN_BOTTOM, 1, clr.j)
                end
                if config["EntDist"] then
                    draw.SimpleTextOutlined(math.Round(me:GetPos():Distance( v:GetPos() ) / 42, 1 ) .. "m", "FT3", x1 + w / 2, y2 - 2, string.ToColor(config.clrs["EntDist"]), TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP, 1, clr.j)
                end
                if config["EntChams"] then
                  if config["ChamsMaterial"] == 1 then
                    ChamsM = "!flat"
                  elseif config["ChamsMaterial"] == 2 then
                    ChamsM = "!textured"
                  elseif config["ChamsMaterial"] == 3 then
                    ChamsM = "!wireframe"
                end
                local ccol = string.ToColor(config.clrs["EntChams"])
                cam.Start3D()
                  render.SuppressEngineLighting(false)
                  render.MaterialOverride(Material(ChamsM))
                  render.SetColorModulation(ccol.r / 255, ccol.g / 255, ccol.b / 255)
                  render.SetBlend(1)
                  v:DrawModel()
                  render.MaterialOverride(nil)
                  render.SuppressEngineLighting(false)
                cam.End3D()
                end
            end
        end
    end
end

local function SpecList()
    local specw = 220
    local spech = 19
    local specamt = 0
    local specx = specw + (ScrW() / 12)
    local specy = 15
    draw.RoundedBoxEx(4, specx, specy, specw, spech, Color(10, 21, 32), true, true, false, false)
    draw.SimpleText("Spectator's List", "FT6", specx + specw / 2, specy + 1, clr.l, TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
    for k, v in pairs(player.GetAll()) do
        if (IsValid(v:GetObserverTarget()) and v != me and v:GetObserverTarget() == me) then
            draw.RoundedBox(0, specx, specy - 1 + spech + specamt, specw, spech, Color(20, 31, 42))
            draw.SimpleText(v:Nick(), "FT8", specx + specw / 2, specy + 1 + spech + specamt, clr.l, TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
            specamt = specamt + 14
        end
    end
    draw.RoundedBoxEx(4, specx, specy + spech + specamt, specw, 6, Color(10, 21, 32), false, false, true, true)
    draw.RoundedBox(0, specx, specy + spech - 2, specw, 2, string.ToColor(config.clrs["MenuColor"]))
    specw = specamt + 15
end

local function AdminList()
    local adminw = 220
    local adminh = 19
    local adminamt = 0
    local adminx = adminw + (ScrW() / 5) + 10
    local adminy = 15
    draw.RoundedBoxEx(4, adminx, adminy, adminw, adminh, Color(10, 21, 32), true, true, false, false)
    draw.SimpleText("Admin's List", "FT6", adminx + adminw / 2, adminy + 1, clr.l, TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
    for k, v in pairs(player.GetAll()) do
        if (v != me and table.HasValue(staffRanks, v:GetUserGroup())) then
            draw.RoundedBox(0, adminx, adminy - 1 + adminh + adminamt, adminw, adminh, Color(20, 31, 42))
            draw.SimpleText(v:Nick() .. " | " .. v:GetUserGroup(), "FT8", adminx + adminw / 2, adminy + 1 + adminh + adminamt, clr.l, TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
            adminamt = adminamt + 14
        end
    end
    draw.RoundedBoxEx(4, adminx, adminy + adminh + adminamt, adminw, 6, Color(10, 21, 32), false, false, true, true)
    draw.RoundedBox(0, adminx, adminy + adminh - 2, adminw, 2, string.ToColor(config.clrs["MenuColor"]))
    adminw = adminamt + 15
end

local freecamAngles = Angle()
local freecamAngles2 = Angle()
local freecamPos = Vector()
local freecamEnabled = false
local freecamSpeed = 3
local keyPressed = false

hook.Add("CreateMove", RandomString(), function(cmd)
    if(freecamEnabled && config["Freecam"] && config["Misc"]) then
        cmd:SetSideMove(0)
        cmd:SetForwardMove(0)
        cmd:SetViewAngles(freecamAngles2)
        cmd:RemoveKey(IN_JUMP)
        cmd:RemoveKey(IN_DUCK)
        
        freecamAngles = (freecamAngles + Angle(cmd:GetMouseY() * .023, cmd:GetMouseX() * -.023, 0));
        freecamAngles.p, freecamAngles.y, freecamAngles.x = math.Clamp(freecamAngles.p, -89, 89), math.NormalizeAngle(freecamAngles.y), math.NormalizeAngle(freecamAngles.x);
 
        local curFreecamSpeed = freecamSpeed
        if(input.IsKeyDown(KEY_LSHIFT)) then
            curFreecamSpeed = freecamSpeed * 2
        end
 
        if(input.IsKeyDown(KEY_W)) then
            freecamPos = freecamPos + (freecamAngles:Forward() * curFreecamSpeed)
        end
        if(input.IsKeyDown(KEY_S)) then
            freecamPos = freecamPos - (freecamAngles:Forward() * curFreecamSpeed)
        end
        if(input.IsKeyDown(KEY_A)) then
            freecamPos = freecamPos - (freecamAngles:Right() * curFreecamSpeed)
        end
        if(input.IsKeyDown(KEY_D)) then
            freecamPos = freecamPos + (freecamAngles:Right() * curFreecamSpeed)
        end
        if(input.IsKeyDown(KEY_SPACE)) then
            freecamPos = freecamPos + Vector(0,0,curFreecamSpeed)
        end
        if(input.IsKeyDown(KEY_LCONTROL)) then
          freecamPos = freecamPos - Vector(0,0,curFreecamSpeed)
        end
    end
end)

AddHook("Think", RandomString(), function()
if config["Freecam"] && config["Misc"] then
    if (config.binds["Freecam_key"] == KEY_NONE) or ( config.binds["Freecam_key"] != 0 and ( ( config.binds["Freecam_key"] >= 107 and config.binds["Freecam_key"] <= 113 ) and input.IsMouseDown(config.binds["Freecam_key"]) ) or input.IsKeyDown(config.binds["Freecam_key"]) ) then
        if(!keyPressed) then
            freecamEnabled = !freecamEnabled
            freecamAngles = me:EyeAngles()
            freecamAngles2 = me:EyeAngles()
            freecamPos = me:EyePos()
            keyPressed = true
        end
    else
        keyPressed = false
        end
    end
end)

local function Movement(cmd)
if me:GetMoveType() == MOVETYPE_LADDER or me:GetMoveType() == MOVETYPE_NOCLIP or me:GetMoveType() == MOVETYPE_OBSERVER then return end
 if config["Bhop"] then
  if me:OnGround() then
    cmd:KeyDown(IN_JUMP)
  else
    cmd:RemoveKey(IN_JUMP)
  end
end
if config["Autostrafe"] and config["Bhop"] then
  if(!me:OnGround()) then
     if cmd:GetMouseX() < 0 then
       cmd:SetSideMove(-5850)
    elseif cmd:GetMouseX() > 0 then
       cmd:SetSideMove(5850)
        end
      end
      if cmd:KeyDown(IN_JUMP) then
        cmd:SetForwardMove(10000)
    end
  end
end

gameevent.Listen("player_hurt")
local function HitSound(data)
  if config["Hitsound"] and config["Misc"] then
    if data.attacker == me:UserID() then
      surface.PlaySound("buttons/bell1.wav")
    end
  end
end
AddHook("player_hurt", RandomString(), HitSound)

AddHook("HUDPaintZ", RandomString(), function()
if(!ss) then
    Visuals()
  if(config["Misc"]) then
    if(config["SpectatorsList"]) then
        SpecList()
    end
    if config["AdminsList"] then
        AdminList()
    end
  end
  if config["FovCircle"] and config["Aimbot"] then
    if config["AimFOV"] < 70 then
    local sx = math.tan( math.rad( config["AimFOV"] ) / 1.3 )
    local wx = math.tan( math.rad( me:GetFOV() / 2 ) )
    local ffov = sx / wx
    local newfov = ffov * ( ScrW() / 2 )
    surface.DrawCircle( ScrW() / 2, ScrH() / 2, newfov, string.ToColor(config.clrs["FovCircle"]) )
      end
    end
  end
end)

AddHook("CalcView", RandomString(), function(ply, pos, angles, fov)
    local view = {}
    if(freecamEnabled && config["Freecam"] && config["Misc"]) then
        view = {
            origin = freecamPos,
            angles = freecamAngles,
            fov = fov,
            drawviewer = true
        }
    else
        view = {
            origin = pos,
            angles = angles,
            fov = fov,
            drawviewer = false
        }
    end
    return view
end)

AddHook("CalcViewModelView", RandomString(), function(Weapon, ViewModel, OldPos, OldAngle, EyePos, EyeAngle)
if ss then return end
  if intp && config.binds["Thirdperson_key"] != 0 or freecamEnabled then return end
    if config.binds["Thirdperson_key"] == 0 && config["Thirdperson"] then return end

    if config["removebob"] then
        EyeAngle = OldAngle
    end
    if config["removesway"] then
        EyePos = OldPos
    end

    if !config["ViewmodelChanger"] then return end
    
    local OverridePos = Vector(config["viewmodel_x"], config["viewmodel_y"], config["viewmodel_z"])
    local OverrideAngle = Angle(config["viewmodel_p"], config["viewmodel_ya"], config["viewmodel_r"])

    EyeAngle = EyeAngle * 1

    EyeAngle:RotateAroundAxis(EyeAngle:Right(), OverrideAngle.x * 1.0)
    EyeAngle:RotateAroundAxis(EyeAngle:Up(), OverrideAngle.y * 1.0)
    EyeAngle:RotateAroundAxis(EyeAngle:Forward(), OverrideAngle.z* 1.0)

    EyePos = EyePos + OverridePos.x * EyeAngle:Right() * 1.0
    EyePos = EyePos + OverridePos.y * EyeAngle:Forward() * 1.0
    EyePos = EyePos + OverridePos.z * EyeAngle:Up() * 1.0 

    return EyePos, EyeAngle
end)

AddHook( "CalcView", RandomString(), function(ply, pos, angles, fov)
if not me:InVehicle() then
  if not freecamEnabled then
    local view = {}
    view.angles = Either(config["Silent"], angc.view, angles)
    if (intp and config["Thirdperson"] and config["Misc"]) then
    view.origin = pos - ( (angles):Forward() * config["TPDistance"] ) or pos - ( (angc.view):Forward() * config["TPDistance"] ) or pos
    else
    end
    if config["ViewmodelChanger"] and config["Visuals"] and (!ss) then
      view.fov = config["ViewmodelFOV"]
    else
      view.fov = fov
    end
    view.drawviewer = (config["Thirdperson"] and config["Misc"] and intp)
    return view
    end
  end
end)

AddHook("CreateMove", RandomString(), function(cmd)
    if config["Aimbot"] then
      Autoaim(cmd)
    end
    if config["Misc"] then
      Movement(cmd)
      RapidFire(cmd)
  end
    if config["Silent"] then
      FixMovement(cmd)
      FixAngs(cmd)
  end
  if config["Thirdperson"] and config["Misc"] then
    if config.binds["Thirdperson_key"] == 0 then 
        intp = true
    elseif ( ( ( config.binds["Thirdperson_key"] >= 107 and config.binds["Thirdperson_key"] <= 113 ) and input.IsMouseDown(config.binds["Thirdperson_key"] ) and !toggledelay3 or input.IsKeyDown(config.binds["Thirdperson_key"]) and !toggledelay3 ) ) then
        intp = !intp
        toggledelay3 = true
        timer.Simple(0.3, function() toggledelay3 = false end)
    end
  end
end)

AddHook("PostDraw2DSkyBox", RandomString(), function()
    if config["RemoveSky"] and config["Visuals"] and (!ss) then
    local SkyCol = string.ToColor(config.clrs["RemoveSky"])
    local col = HSVToColor( ( CurTime() * (config["RGBSpeed"] * 3) ) % 360, 1, 1 )
    if config["RGBSky"] then
      render.Clear(col.r, col.g, col.b, SkyCol.a, true, true)
    else
      render.Clear(SkyCol.r, SkyCol.g, SkyCol.b, SkyCol.a, true, true)
    end
  end
end)