--[[
	cl_stats.lua
	Cal
	===DStream===
]]

concommand.Add("+cal_menu", function() frame:SetVisible( true ) end)
concommand.Add("-cal_menu", function() frame:SetVisible( false ) end)

frame = vgui.Create("DFrame")
frame:SetSize( 500, 300 )
frame:SetTitle( "Cal Bot V1" )
frame:Center()
frame:SetVisible( false )
frame:SetDraggable( false )
frame:ShowCloseButton( false )
frame:MakePopup()

local PropertySheet = vgui.Create( "DPropertySheet" )
PropertySheet:SetParent( frame )
PropertySheet:SetPos( 10, 30 )
PropertySheet:SetSize( 480, 260 )

local TestingPanel = vgui.Create( "DPanel", frame )
TestingPanel:SetPos( 10, 10 )
TestingPanel:SetSize( 480, 280 )
TestingPanel.Paint = function() -- Paint function
    surface.SetDrawColor( 50, 50, 50, 255 ) -- Set our rect color below us; we do this so you can see items added to this panel
    surface.DrawRect( 0, 0, TestingPanel:GetWide(), TestingPanel:GetTall() ) -- Draw the rect
end

PropertySheet:AddSheet( "ESP", TestingPanel, "gui/silkicons/user", false, false, "ESP/Console Commands" )

SheetItemOne = vgui.Create( "DCheckBoxLabel", TestingPanel )
SheetItemOne:SetPos( 10,10 )
SheetItemOne:SetText( "Enable ESP/AimBot" )
SheetItemOne:SizeToContents()

NumSliderThingy = vgui.Create( "DNumSlider",TestingPanel )
NumSliderThingy:SetPos( 310,10 )
NumSliderThingy:SetSize( 150, 100 ) -- Keep the second number at 100
NumSliderThingy:SetText( "View Model Alpha" )
NumSliderThingy:SetMin( 0 ) -- Minimum number of the slider
NumSliderThingy:SetMax( 255 ) -- Maximum number of the slider
NumSliderThingy:SetDecimals( 0 ) -- Sets a decimal. Zero means it's a whole number
NumSliderThingy:SetValue( 255 )

function getColor(ply)

	local Colour = team.GetColor( ply:Team() )
	
	if(ply:GetFriendStatus() == "friend") then
		Colour = Color(255,255,255,255)
	end
	
	return Colour
end

function getDistance(ent)

	local Distance = math.floor((LocalPlayer():GetPos() + LocalPlayer():OBBCenter()):Distance( ent:GetPos() + ent:OBBCenter()))
	
	return Distance

end

hook.Add("HUDPaint", "Draw", function()

	LocalPlayer():GetViewModel():SetColor(255,255,255,NumSliderThingy:GetValue())
	
	if(SheetItemOne:GetChecked())then
		Enabled = true
	else
		Enabled = false
	end
	
	if(Enabled) then
	
		surface.SetDrawColor(180,180,180,255)
		surface.DrawRect( ScrW()-210, 10, 200 , 200 )
		
		local m_ang = math.Deg2Rad(LocalPlayer():EyeAngles().y)
		local m_sin = math.sin(m_ang)
		local m_cos = math.cos(m_ang)
		local center_minimap =  Vector(ScrW()-105,105,0)
		surface.DrawCircle( center_minimap.x-1, center_minimap.y-1, 2, Color(255,255,255,255) )surface.DrawLine(center_minimap.x-1, center_minimap.y-1, center_minimap.x-1-m_sin*10, center_minimap.y-1-m_cos*10)
	
		for k,v in pairs(player.GetAll()) do
		
			if(v!=LocalPlayer()) then
			
				local m_ang2 = math.Deg2Rad((v:GetPos()-LocalPlayer():GetPos()):Angle().y - LocalPlayer():EyeAngles().y + 90)
				local m_sin2 = math.sin(m_ang2)
				local m_cos2 = math.cos(m_ang2)
			
				local Dis = ((v:GetPos().x-LocalPlayer():GetPos().x) + (v:GetPos().y-LocalPlayer():GetPos().y))/2
				local mm_pos_x = (m_cos2*Dis)/30
				local mm_pos_y = (m_sin2*Dis)/30
				//local mm_pos_y = (v:GetPos().x-LocalPlayer():GetPos().x)/30
				
				if(mm_pos_x>104) then
					mm_pos_x=104
				end
				
				if(mm_pos_x<-94) then
					mm_pos_x=-94
				end
				
				if(mm_pos_y>92) then
					mm_pos_y=92
				end
				
				if(mm_pos_y<-104) then
					mm_pos_y=-104
				end
				
				surface.DrawCircle( (center_minimap.x-1)+mm_pos_x, (center_minimap.y-1)-mm_pos_y, 2, getColor(v) )
			
				Colour = getColor(v)
			
				local bone = v:LookupBone("ValveBiped.Bip01_Head1")
				local pos = (v:GetBonePosition(bone) + Vector(0,0,2)):ToScreen()
				local aimPos = v:GetEyeTraceNoCursor( ).HitPos:ToScreen()
				
				local ang = math.Deg2Rad((LocalPlayer():GetPos()-v:GetPos()):Angle().y)
				local sin = math.sin(ang)
				local cos = math.cos(ang)
				
				if(v:InVehicle()) then
					topleft = (v:GetPos() - Vector(-sin*v:OBBMaxs().x,cos*v:OBBMaxs().y,-v:OBBMaxs().z/2)):ToScreen()
					bottomright = (v:GetPos() + Vector(-sin*v:OBBMaxs().x,cos*v:OBBMaxs().y,0)):ToScreen()
				else
					topleft = (v:GetPos() - Vector(-sin*v:OBBMaxs().x,cos*v:OBBMaxs().y,-v:OBBMaxs().z)):ToScreen()
					bottomright = (v:GetPos() + Vector(-sin*v:OBBMaxs().x,cos*v:OBBMaxs().y,0)):ToScreen()
				end
				
				surface.SetDrawColor(Colour)
				surface.DrawOutlinedRect( topleft.x, topleft.y, bottomright.x-topleft.x , bottomright.y-topleft.y )
				
				surface.SetDrawColor(Colour)
				surface.DrawLine(aimPos.x, aimPos.y, pos.x, pos.y)
				
				surface.CreateFont ("coolvetica", 20, 400, true, false, "CV20")
				
				surface.SetTextColor(Colour)
				surface.SetTextPos( (bottomright.x)+10, topleft.y ) 
				surface.SetFont("CV20")
				surface.DrawText( v:Nick() )

				surface.SetTextColor(Colour)
				surface.SetTextPos(  (bottomright.x)+10, topleft.y+14 )
				surface.SetFont("CV20")
				surface.DrawText( "Health: "..v:Health() )
				
				surface.SetTextColor(Colour)
				surface.SetTextPos(  (bottomright.x)+10, topleft.y+28 )
				surface.SetFont("CV20")
				surface.DrawText( "Distance: "..getDistance(v) )
				
			end
			
		end
		
		for k,v in pairs(ents.FindByClass("npc_*")) do
			
			if(v:GetClass()!="npc_grenade_frag") then
				
				local bone = v:LookupBone("ValveBiped.Bip01_Head1")
				local pos = (v:GetBonePosition(bone) + Vector(0,0,2)):ToScreen()
				local npc_class = string.sub(v:GetClass(), 6, string.len( v:GetClass() ))
				local npc_class_2 = string.upper(string.sub(v:GetClass(), 5, 5))
				
				surface.SetDrawColor(255,255,0,255)
				surface.DrawOutlinedRect( pos.x, pos.y, 10 , 10 )
				
				surface.SetTextColor( 255, 255, 0, 255 )
				surface.SetTextPos( pos.x + 15, pos.y-5 ) 
				surface.SetFont("CV20")
				surface.DrawText( npc_class_2..npc_class )
				
				surface.SetTextColor(255, 255, 0, 255 )
				surface.SetTextPos(  pos.x+15, pos.y+9 )
				surface.SetFont("CV20")
				surface.DrawText( "Distance: "..getDistance(v) )
				
			end
		
		end
		
		for k,v in pairs(ents.FindByClass("rpg_missile")) do
			
			local tracepos = v:GetPos() + v:OBBCenter()
			local traceang = v:GetForward()
			local tracedata = {}
			tracedata.start = tracepos
			tracedata.endpos = tracepos+(traceang*80000000000)
			tracedata.filter = v
			local trace = util.TraceLine(tracedata)
			
			local pos = (v:GetPos() + v:OBBCenter()):ToScreen()
			local tracehit = (trace.HitPos):ToScreen()
			
			surface.SetDrawColor(255,0,0,255)
			surface.DrawOutlinedRect( pos.x-5, pos.y-5, 10 , 10 )
			
			surface.SetDrawColor(255,0,0,255)
			surface.DrawLine(pos.x, pos.y, tracehit.x, tracehit.y)
			
			surface.SetTextColor(255,0,0,255)
			surface.SetTextPos( pos.x+10, pos.y-8 ) 
			surface.SetFont("CV20")
			surface.DrawText( "RPG Missile" )
			
			surface.SetTextColor(255,0,0,255)
			surface.SetTextPos( pos.x+10, pos.y+6 ) 
			surface.SetFont("CV20")
			surface.DrawText( "Distance: "..getDistance(v) )
			
		end
		
		for k,v in pairs(ents.FindByClass("prop_combine_ball")) do
			
			local tracepos = v:GetPos() + v:OBBCenter()
			local traceang = v:GetVelocity()
			local tracedata = {}
			tracedata.start = tracepos
			tracedata.endpos = tracepos+(traceang*800)
			tracedata.filter = v
			local trace = util.TraceLine(tracedata)
			
			local pos = (v:GetPos() + v:OBBCenter()):ToScreen()
			local tracehit = (trace.HitPos):ToScreen()
			
			surface.SetDrawColor(255,0,0,255)
			surface.DrawOutlinedRect( pos.x-5, pos.y-5, 10 , 10 )
			
			surface.SetDrawColor(255,0,0,255)
			surface.DrawLine(pos.x, pos.y, tracehit.x, tracehit.y)
			
			surface.SetTextColor(255,0,0,255)
			surface.SetTextPos( pos.x+10, pos.y-8 ) 
			surface.SetFont("CV20")
			surface.DrawText( "Combine Ball" )
			
			surface.SetTextColor(255,0,0,255)
			surface.SetTextPos( pos.x+10, pos.y+6 ) 
			surface.SetFont("CV20")
			surface.DrawText( "Distance: "..getDistance(v) )
			
		end
		
		for k,v in pairs(ents.FindByClass("npc_grenade_frag")) do
			
			local pos = (v:GetPos() + v:OBBCenter()):ToScreen()
			
			surface.SetDrawColor(255,0,0,255)
			surface.DrawOutlinedRect( pos.x-5, pos.y-5, 10 , 10 )
			
			surface.SetTextColor(255,0,0,255)
			surface.SetTextPos( pos.x+10, pos.y-8 ) 
			surface.SetFont("CV20")
			surface.DrawText( "Frag Grenade" )
			
			surface.SetTextColor(255,0,0,255)
			surface.SetTextPos( pos.x+10, pos.y+6 ) 
			surface.SetFont("CV20")
			surface.DrawText( "Distance: "..getDistance(v) )
			
		end
		
		for k,v in pairs(ents.FindByClass("crossbow_bolt")) do
			
			local pos = (v:GetPos() + v:OBBCenter()):ToScreen()
			
			surface.SetDrawColor(255,0,0,255)
			surface.DrawOutlinedRect( pos.x-5, pos.y-5, 10 , 10 )
			
			surface.SetTextColor(255,0,0,255)
			surface.SetTextPos( pos.x+10, pos.y-8 ) 
			surface.SetFont("CV20")
			surface.DrawText( "Crossbow Bolt" )
			
			surface.SetTextColor(255,0,0,255)
			surface.SetTextPos( pos.x+10, pos.y+6 ) 
			surface.SetFont("CV20")
			surface.DrawText( "Distance: "..getDistance(v) )
			
		end

	end
	
end)


concommand.Add("+cal_aim",function() Aimbot_On = true end)
concommand.Add("-cal_aim",function() Aimbot_On = false end)

hook.Add("Think","aimbot", function()
	
	if(Aimbot_On && Enabled) then
		
		for k,v in pairs(ents.GetAll()) do
			
			if(v:IsValid())then
			
				if(v:IsPlayer() || v:IsNPC()) then
						
						if (v:GetFriendStatus() != "friend") then
						
						local bone = v:LookupBone("ValveBiped.Bip01_Head1")
						local pos = (v:GetBonePosition(bone) + Vector(0,0,3))
							
						local tracedata = {}
						tracedata.start = LocalPlayer():GetShootPos()
						tracedata.endpos = pos
						tracedata.filter = LocalPlayer()
						local trace = util.TraceLine(tracedata)
							
						if(trace.Entity==v) then
						
							Ang = (pos-LocalPlayer():GetShootPos()):Angle()
							LocalPlayer():SetEyeAngles(Ang)
							
						end
					
					end
						
				end
					
			end
			
		end
		
	end
	
end)