//botBot, made by Muffin and Marvincmarvin

local util = util
local vgui = vgui
local table = table
local math = math
local string = string
local surface = surface
local draw = draw


local botBot = {}
local getall = player.GetAll()
local val1, val2, val3 = 0, 0, 0
local temp = 0
local autoshoot = 0
local aim = false
local plyers = {}
local bhop = false


local function GetMeta( name )
    return table.Copy(_R[name] or {})
end
local AngM = GetMeta("Angle")
local CmdM = GetMeta("CUserCmd")
local EntM = GetMeta("Entity")
local PlyM = GetMeta("Player")
local VecM = GetMeta("Vector")

botBot.targets = {}
botBot.ver = "a0.5"

botBot.espchecks = {}
botBot.esp_enabled = CreateClientConVar( 'botBot_esp_enabled', 1, true, false )
botBot.esp_tar_ply = CreateClientConVar( 'botBot_esp_targetplayers', 1, true, false )
botBot.esp_tar_npc = CreateClientConVar( 'botBot_esp_targetnpcs', 1, true, false )
botBot.esp_show_name = CreateClientConVar( 'botBot_esp_showname', 1, true, false )
botBot.esp_show_health = CreateClientConVar( 'botBot_esp_showhealth', 1, true, false )
botBot.esp_show_admin = CreateClientConVar( 'botBot_esp_showadmin', 1, true, false )
botBot.esp_show_steam = CreateClientConVar( 'botBot_esp_showsteam', 1, true, false )
botBot.esp_show_lines = CreateClientConVar( 'botBot_esp_showlines', 0, true, false )
botBot.esp_show_bones = CreateClientConVar( 'botBot_esp_showbones', 1, true, false )
botBot.esp_show_model = CreateClientConVar( 'botBot_esp_showmodel', 1, true, false )
botBot.esp_show_rpents = CreateClientConVar( 'botBot_esp_showrpents', 1, true, false )

botBot.aim_enabled = CreateClientConVar( 'botBot_aim_enabled', 1, true, false )
botBot.aim_npc = CreateClientConVar( 'botBot_aim_targetnpcs', 0, true, false )
botBot.aim_maxdist = CreateClientConVar( 'botBot_aim_maxdist', 16340, true, false )
botBot.aim_autoshoot = CreateClientConVar( 'botBot_aim_autoshoot', 0, true, false )
botBot.aim_targetsteamfriends = CreateClientConVar( 'botBot_aim_targetsteamfriends', 1, true, false )
botBot.aim_targetadmins = CreateClientConVar( 'botBot_aim_targetadmins', 1, true, false )

botBot.theme = CreateClientConVar( 'botBot_theme', 0, true, false )

botBot.colors = {}
botBot.colors.blue = Color( 0, 160, 255 )
botBot.colors.green = Color( 114, 255, 0 )
botBot.colors.red = Color( 250, 50, 50 )
botBot.colors.grey = Color( 150, 150, 150 )
botBot.colors.darkgrey = Color( 20, 20, 20 )

botBot.colors.theme = {}
botBot.colors.theme.norm = botBot.colors.blue
botBot.colors.theme.light = Color( 0, 200, 250, 70 )

botBot.titles = {}
botBot.titles[1] = "fuck your shit"
botBot.titles[2] = "better than sethhack"
botBot.titles[3] = "you suck at life"
botBot.titles[4] = "lemonparty endorsed"
botBot.titles[5] = "deal with it"
botBot.titles[6] = "since 2001"
botBot.titles[7] = "fights cancer"

for k, v in pairs( getall ) do
    if v == LocalPlayer() then
       table.remove( getall, k ) 
    end
end

local targs = {}


timer.Create( "npccheck", 1, 0, function()
    npctargs = {}

    for k,v in pairs( ents.GetAll() ) do 
        if v != LocalPlayer() and v:IsNPC() then
            table.insert( npctargs, v )
        end
    end
end )


local function FindPlayerByName( name )
    for k,v in pairs( player.GetAll() ) do
        if string.find( v:Name(), name, 1, true ) then
            return v
        end
    end
end

function _R.Entity.GetVisible( self )
    local trace = {}

    if self:IsPlayer() then 
        trace = {start = LocalPlayer():GetShootPos(),endpos = self:HeadPos(),filter = {LocalPlayer(), self}} 
    elseif self:IsNPC() then
        trace = {start = LocalPlayer():GetShootPos(),endpos = self:LocalToWorld(self:OBBCenter()),filter = {LocalPlayer(), self}} 
    end
    local tr = util.TraceLine(trace)

    if tr.Fraction == 1 then
        return true
    else
        return false
    end    
end



function _R.Entity.GetAlive( self )
    local ret = false

    if self:IsValid() then
        if self:IsPlayer() then
            if self:Alive() then ret = true end
        elseif self:IsNPC() then
            if self:GetMoveType()!=0 then ret = true end
        end
    end
    return ret
end




/*---------------------*\
--------#[Aimbot]#-------
\*---------------------*/

local function FindTarget( pos )
    if table.Count( table.Add( player.GetAll(), npctargs ) ) > 1 then 

        local distance = math.huge
        local plys = {}
        local alltargs = {}

        if botBot.aim_npc:GetInt() == 1 then
            alltargs = table.Add( targs, npctargs )
        else 
            alltargs = targs 
        end

        for k,v in pairs( alltargs ) do
            if v:GetAlive() and plys[k] != LocalPlayer() then
                local curdist = v:GetPos():Distance( pos )

                if curdist < distance  then
                    table.insert( plys, v )
                    distance = curdist
                end
            end
        end

        for i = #plys, 1, -1 do
            if plys[i]:GetVisible() then
                if botBot.aim_targetsteamfriends:GetInt() == 0 then
                    if plys[i]:GetFriendStatus() ~= "friend" then
                        return plys[i]
                    end
                elseif botBot.aim_targetadmins:GetInt() == 0 then
                    if not plys[i]:IsAdmin() and not plys[i]:IsSuperAdmin() then
                        return plys[i]
                    end
                else
                    return plys[i]
                end
            end
        end
    else
        return nil
    end
end


local function EntCheck( ent )
    if !ent:IsValid() then return false end
    if !ent:IsPlayer() and !ent:IsNPC() then return false end
    if util.PointContents( ent:EyePos() ) == CONTENTS_SOLID then return false end
    return true
end

local function RandString()
    return tostring( math.Round( math.random( 52, 148) / math.random( 5, 100), math.random( 3, 14) ) )
end

local function GetIndexInTable( var, tab )
    for k,v in pairs( tab ) do
        if var == v then
            return k
        end
    end
    return false
end


concommand.Add( "+botbot_aim", function() aim = true end )

hook.Add( "CreateMove", "cmove", function( UCMD )
    if aim == true and botBot.aim_enabled:GetInt() == 1 then 
        local val, targ = pcall( FindTarget, LocalPlayer():GetPos() ) 
        local val2, val3 = pcall( EntCheck, targ )

        if val == true and val2 == true and val3 == true and #targs > 0 then
            
            local targpos = ( ( targ:GetPos() + Vector( 0, 0, 40 ) ) - LocalPlayer():GetShootPos() ):Normalize():Angle()

            UCMD:SetViewAngles( targpos )

            if botBot.aim_autoshoot:GetInt() == 1 and autoshoot == 0 then        
                RunConsoleCommand( "+attack" )
                autoshoot = 1
            end

        elseif autoshoot == 1 then
            RunConsoleCommand( "-attack" )
            autoshoot = 0
        end
    end

    //Bunnyhop
    if bhop then
        if LocalPlayer():IsOnGround() then
            UCMD:SetButtons( UCMD:GetButtons() | IN_JUMP )
        end
    end
end )
concommand.Add( "-botbot_aim", function()
    aim = false

    if autoshoot == 1 then
        RunConsoleCommand( "-attack" )
        autoshoot = 0
    end
end )
concommand.Add( "+botbot_bh", function() bhop = true end )
concommand.Add( "-botbot_bh", function() bhop = false end )





  /*---------------------*\
  --------#[ ESP ]#--------
  \*---------------------*/

function botBot:CreateMaterial( pl )
    local BaseInfo = {
        ['$basetexture'] = 'models/debug/debugwhite',
        ['$model']       = 1,
        ['$translucent'] = 1,
        ['$alpha']       = 1,
        ['$nocull']      = 1,
        ['$ignorez'] = 1
    }
    local mat = CreateMaterial( 'pb_solid_mat', 'VertexLitGeneric', BaseInfo )
    return mat
end



function _R.Entity.HeadPos( self )
    if self:IsPlayer() then
        local hbone = self:LookupBone('ValveBiped.Bip01_Head1')
        return self:GetBonePosition(hbone)
    else 
        return self:GetPos() 
    end
end



function _R.Entity:GetBones()
    local ret = {}

    if self:IsPlayer() then
        ret = { 
            h = self:GetBonePosition( self:LookupBone('ValveBiped.Bip01_Head1') ):ToScreen(),
            p = self:GetBonePosition( self:LookupBone('ValveBiped.Bip01_Spine') ):ToScreen(),
            r_t = self:GetBonePosition( self:LookupBone('ValveBiped.Bip01_R_Thigh') ):ToScreen(), 
            r_c = self:GetBonePosition( self:LookupBone('ValveBiped.Bip01_R_Calf') ):ToScreen(), 
            r_f = self:GetBonePosition( self:LookupBone('ValveBiped.Bip01_R_Foot') ):ToScreen(),
            r_ua = self:GetBonePosition( self:LookupBone('ValveBiped.Bip01_R_UpperArm') ):ToScreen(), 
            r_fa = self:GetBonePosition( self:LookupBone('ValveBiped.Bip01_R_Forearm') ):ToScreen(),
            r_h = self:GetBonePosition( self:LookupBone('ValveBiped.Bip01_R_Hand') ):ToScreen(),                 
            l_t = self:GetBonePosition( self:LookupBone('ValveBiped.Bip01_L_Thigh') ):ToScreen(), 
            l_c = self:GetBonePosition( self:LookupBone('ValveBiped.Bip01_L_Calf') ):ToScreen(),
            l_f = self:GetBonePosition( self:LookupBone('ValveBiped.Bip01_L_Foot') ):ToScreen(),  
            l_ua = self:GetBonePosition( self:LookupBone('ValveBiped.Bip01_L_UpperArm') ):ToScreen(), 
            l_fa = self:GetBonePosition( self:LookupBone('ValveBiped.Bip01_L_Forearm') ):ToScreen(),
            l_h = self:GetBonePosition( self:LookupBone('ValveBiped.Bip01_L_Hand') ):ToScreen(),
            n = self:GetBonePosition( self:LookupBone('ValveBiped.Bip01_Neck1') ):ToScreen()
        }
    end
    return ret

end

local function GetTargets()
    botBot.targets = {}

    for _,ent in pairs( ents.GetAll() ) do
        if ( ent:IsPlayer() ) and ( ent != LocalPlayer() ) then
            if botBot.esp_tar_ply:GetInt() == 1 and ent:IsPlayer() then
                table.insert( botBot.targets, ent )
            elseif botBot.esp_tar_npc:GetInt() == 1 and ent:IsNPC() then
                table.insert( botBot.targets, ent )
            end
        end
    end
end



local function EnableAll()
    RunConsoleCommand( 'botBot_esp_enabled', "1" )
    RunConsoleCommand( 'botBot_esp_targetplayers', "1" )
    RunConsoleCommand( 'botBot_esp_targetnpcs', "1" )
    RunConsoleCommand( 'botBot_esp_showname', "1" )
    RunConsoleCommand( 'botBot_esp_showhealth', "1" )
    RunConsoleCommand( 'botBot_esp_showadmin', "1" )
    RunConsoleCommand( 'botBot_esp_showsteam', "1" )
    RunConsoleCommand( 'botBot_esp_showlines', "1" )
    RunConsoleCommand( 'botBot_esp_showbones', "1" )  
    RunConsoleCommand( 'botBot_esp_showmodel', "1" )
end

local function DisableAll()
    RunConsoleCommand( 'botBot_esp_enabled', "0" )
    RunConsoleCommand( 'botBot_esp_targetplayers', "0" )
    RunConsoleCommand( 'botBot_esp_targetnpcs', "0" )
    RunConsoleCommand( 'botBot_esp_showname', "0" )
    RunConsoleCommand( 'botBot_esp_showhealth', "0" )
    RunConsoleCommand( 'botBot_esp_showadmin', "0" )
    RunConsoleCommand( 'botBot_esp_showsteam', "0" )
    RunConsoleCommand( 'botBot_esp_showlines', "0" )
    RunConsoleCommand( 'botBot_esp_showbones', "0" )  
    RunConsoleCommand( 'botBot_esp_showmodel', "0" )
end

local function DrawEsp()
    if botBot.esp_enabled:GetInt() == 1 then
        for _,pl in pairs( botBot.targets ) do
            if pl:IsValid() then
                            
                local pos = ( pl:GetPos() ):ToScreen()

                b = pl:GetBones()
                local spos = b.h
                local lpos = ( pl:GetEyeTrace().HitPos ):ToScreen() or nil
                
                local drawcolor = Color(0,0,0)
                
                if pl:GetVisible() and pl:GetAlive() then 
                    drawcolor = team.GetColor( pl:Team() ) or botBot.colors.green
                elseif not pl:GetVisible() and pl:GetAlive() then
                    drawcolor = botBot.colors.red 
                elseif not pl:GetAlive() then
                    drawcolor = botBot.colors.grey
                end
                            
                if pl:IsPlayer() then
                    local hpos = ( pl:HeadPos() ):ToScreen()
                    local y = 7
                                       
                    surface.SetDrawColor( botBot.colors.grey )
                    surface.DrawOutlinedRect( hpos.x-2, hpos.y-2, 4, 4 )
                                                                                        
                    if botBot.esp_show_health:GetInt() == 1 then
                        draw.RoundedBox( 0, pos.x-17, pos.y+4, 42, 6, botBot.colors.darkgrey )
                        draw.RoundedBox( 0, pos.x-16, pos.y+5, 0.4 * math.Clamp( pl:Health(), 1, 100 ), 4, drawcolor )
                    end
                                        
                    if botBot.esp_show_name:GetInt() == 1 then
                        y = y + 10
                        draw.SimpleText( pl:Nick(), 'BudgetLabel', pos.x, pos.y+y, drawcolor, 1, 1 )
                    end
                                        
                    if botBot.esp_show_admin:GetInt() == 1 then
                        y = y + 10
                        local a_text = ''

                        if pl:IsAdmin() then 
                            if pl:IsSuperAdmin() then
                                a_text = 'Super Admin' 
                            else
                                a_text = 'Admin' 
                            end
                        else
                            a_text = 'Player'
                        end
                        draw.SimpleText( a_text, 'BudgetLabel', pos.x, pos.y+y, drawcolor, 1, 1 )
                    end
                                        
                    if botBot.esp_show_steam:GetInt() == 1 then
                        y = y + 10
                        draw.SimpleText( pl:SteamID(), 'BudgetLabel', pos.x, pos.y+y, drawcolor, 1, 1 )
                    end
                                        
                    if botBot.esp_show_bones:GetInt() == 1 then
                        local b = pl:GetBones()

                        surface.SetDrawColor( drawcolor )
                        surface.DrawLine(b.h.x, b.h.y, b.n.x, b.n.y)
                        surface.DrawLine(b.n.x, b.n.y, b.p.x, b.p.y)
                                                
                        surface.DrawLine(b.r_t.x, b.r_t.y, b.r_c.x, b.r_c.y)
                        surface.DrawLine(b.p.x, b.p.y, b.r_t.x, b.r_t.y)
                        surface.DrawLine(b.r_c.x, b.r_c.y, b.r_f.x, b.r_f.y)
                                                
                        surface.DrawLine(b.n.x, b.n.y, b.r_ua.x, b.r_ua.y)
                        surface.DrawLine(b.r_h.x, b.r_h.y, b.r_fa.x, b.r_fa.y)
                        surface.DrawLine(b.r_fa.x, b.r_fa.y, b.r_ua.x, b.r_ua.y)
                                                
                        surface.DrawLine(b.l_t.x, b.l_t.y, b.l_c.x, b.l_c.y)
                        surface.DrawLine(b.p.x, b.p.y, b.l_t.x, b.l_t.y)
                        surface.DrawLine(b.l_c.x, b.l_c.y, b.l_f.x, b.l_f.y)
                                                
                        surface.DrawLine(b.n.x, b.n.y, b.l_ua.x, b.l_ua.y)
                        surface.DrawLine(b.l_h.x, b.l_h.y, b.l_fa.x, b.l_fa.y)
                        surface.DrawLine(b.l_fa.x, b.l_fa.y, b.l_ua.x, b.l_ua.y)                  
                    end                          
                elseif pl:IsNPC() then

                    local pos = ( pl:GetPos() ):ToScreen()
                    local y = 0
                                        
                    if botBot.esp_show_health:GetInt() == 1 then
                        draw.RoundedBox( 0, pos.x-17, pos.y-4, 42, 6, botBot.colors.darkgrey)
                        draw.RoundedBox( 0, pos.x-16, pos.y-3, 0.4*(pl:Health()), 4, drawcolor)
                    end
                                        
                    if botBot.esp_show_name:GetInt() == 1 then
                        y = y + 10
                        draw.SimpleText(pl:GetClass(), 'BudgetLabel', pos.x, pos.y+y, drawcolor, 1, 1)
                    end
                    
                end
                                    
                if botBot.esp_show_lines:GetInt() == 1 and pl:GetAlive() then

                        surface.SetDrawColor( drawcolor )
                        surface.DrawLine( spos.x, spos.y, lpos.x, lpos.y )
                end
                
                if botBot.esp_show_model:GetInt() == 1 then
                    cam.Start3D( EyePos(), EyeAngles() )

                        local mat, col = botBot:CreateMaterial( v ), drawcolor

                        render.SuppressEngineLighting( true )
                        render.SetColorModulation( ( col.r ), ( col.g ), ( col.b ) )
                        SetMaterialOverride( mat )
                        pl:DrawModel()

                        render.SuppressEngineLighting( false )
                        render.SetColorModulation( 1, 1, 1 )
                        SetMaterialOverride()
                        pl:DrawModel()

                    cam.End3D()

                end                                 
            end
        end

        if botBot.esp_show_rpents:GetInt() == 1 then
            local tempents = { "microwave", "spawned_shipment", "gunlab", "food", "melon", "money_printer", "spawned_weapon", "drug_lab", "drug" }
            local rpents = {}

            for k,v in pairs( tempents ) do
                table.Add( rpents, ents.FindByClass( v ) )
            end

            for _,ent in pairs( rpents ) do
                local drawcolor = Color(0,0,0)
                if ent:GetVisible() then 
                    drawcolor = botBot.colors.green 
                else
                    drawcolor = botBot.colors.red 
                end

                cam.Start3D( EyePos(), EyeAngles() )

                    local mat, col = botBot:CreateMaterial( v ), drawcolor

                    render.SuppressEngineLighting( true )
                    render.SetColorModulation( ( col.r ), ( col.g ), ( col.b ) )
                    SetMaterialOverride( mat )
                    ent:DrawModel()

                    render.SuppressEngineLighting( false )
                    render.SetColorModulation( 1, 1, 1 )
                    SetMaterialOverride()
                    ent:DrawModel()

                cam.End3D()

            end
        end
    end
end

hook.Add( 'HUDPaint', 'botBot_esp', DrawEsp )
hook.Add( 'Think', 'botBot_esp_target', GetTargets )

concommand.Add( 'botBot_esp_enableall', EnableAll )
concommand.Add( 'botBot_esp_disableall', DisableAll )






/*---------------------*\
--------#[ GUI ]#--------
\*---------------------*/

concommand.Add( "botbot_menu", function()
    
    if ( table.Count( player.GetAll() ) ) > 1 then
        botBot.titles[8] = "players mad - " .. tostring( table.Count( player.GetAll() ) - 1 )
    else
        botBot.titles[8] = "just you? having fun?"
    end

    if botBot.theme:GetInt() == 0 then
        botBot.colors.theme.norm = Color( 0, 160, 255 )
        botBot.colors.theme.light = Color( 0, 200, 255, 50 )
    elseif botBot.theme:GetInt() == 1 then
        botBot.colors.theme.norm = Color( 160, 250, 0 )
        botBot.colors.theme.light = Color( 200, 250, 0, 50 )
    elseif botBot.theme:GetInt() == 2 then
        botBot.colors.theme.norm = Color( 255, 160, 0 )
        botBot.colors.theme.light = Color( 255, 200, 0, 50 )
    elseif botBot.theme:GetInt() == 3 then
        botBot.colors.theme.norm = Color( 255, 255, 255 )
        botBot.colors.theme.light = Color( 255, 255, 255, 50 )
    end

    local rand = math.random( #botBot.titles )

    frame1 = vgui.Create( 'DFrame' )
    frame1:SetPos( -256, 256 )
    frame1:SetSize( 224, 300 )
    frame1:ShowCloseButton( false )
    frame1:SetTitle( "" )
    frame1.Paint = function()
    
        surface.SetDrawColor( 50, 50, 50, 255 )
        surface.DrawRect( 1, 1, frame1:GetWide() - 2, frame1:GetTall() - 2)
       
        for i = 1, 174 do
            surface.SetDrawColor( i - 30, i - 30, i - 30, a )
            surface.DrawLine( 225 - ( i * 3), 0, 500, 275 + ( i * 3 ) ) 
        end
       
        surface.SetDrawColor( 0, 0, 0, 255 )
        surface.DrawOutlinedRect( 0, 0, frame1:GetWide(), frame1:GetTall())
       
        draw.SimpleText( "botBot: " .. botBot.titles[rand], "ChatFont", 10, 7, botBot.colors.theme.norm )
       
        surface.SetDrawColor( 30, 30, 30, 255 )
        surface.DrawRect( 204, 5, 16, 16 )
       
        surface.SetDrawColor( 15, 15, 15, 255 )
        surface.DrawOutlinedRect( 203, 5, 17, 16 )
       
        draw.SimpleText( "x", "Trebuchet22", 207, 0, botBot.colors.theme.norm )
       
    end
     
    button1 = vgui.Create( "DButton", frame1 )
    button1:SetSize( 17, 17 )
    button1:SetPos( 204, 5 )
    button1:SetText( "" )
    button1.DoClick = function()
        frame1:MoveTo( -256, 256, 0.5, 0, 2 )
        hook.Remove( "Think", "tehthink" )
        timer.Simple( 0.5, function()
            frame1:Close()
        end )
    end
    button1.Paint = function()
        return
    end
     
    frame1:MakePopup()
     
    sheet1 = vgui.Create( "DPropertySheet", frame1 )
    sheet1:SetPos( 5, 30 )
    sheet1:SetSize( 213, 282 )
    sheet1.Paint = function()
        return
    end
     



    ---------------- 
    -- Aimbot Tab -- 
    ----------------
    panel1 = vgui.Create( "DPanel", frame1 )
    panel1:SetPos( 7, 55 )
    panel1:SetSize( 211, 237 )
    panel1.Paint = function()
        draw.RoundedBoxEx( 4, 0, 0, panel1:GetWide(), panel1:GetTall(), Color( 0, 0, 0, 255 ), false, true, true, true )
        draw.RoundedBoxEx( 4, 1, 1, panel1:GetWide() - 2, panel1:GetTall() - 2, Color( 50, 50, 50, 255 ), false, true, true, true )
        draw.RoundedBox( 0, 1, 0, 51, 5, Color( 50, 50, 50, 255 ) )
    end
     
    local Table = sheet1:AddSheet( "           ", panel1, false, false, "Aimbot settings n'shit" )
    Table.Tab.Paint = function()
        draw.RoundedBoxEx( 4, 0, 0, Table.Tab:GetWide(), Table.Tab:GetTall(), Color( 0, 0, 0, 255 ), true, true, false, false )
        draw.RoundedBoxEx( 4, 1, 1, Table.Tab:GetWide() - 2, Table.Tab:GetTall() - 1, Color( 50, 50, 50, 255 ), true, true, false, false )
        draw.SimpleText( "Aimbot", "Default", 10, 5, botBot.colors.theme.norm )
    end


    local panel4 = vgui.Create( "DPanel", panel1 )
    panel4:SetPos( 11, 140 )
    panel4:SetSize( 162, 87 )
    panel4.Paint = function() 
        surface.SetDrawColor( Color( 40, 40, 40, 255 ) )
        surface.DrawOutlinedRect( 0, 0, panel4:GetWide(), panel4:GetTall() )
    end

    local list1 = vgui.Create( "DListView", panel1 )
    list1:SetPos( 12, 141 )
    list1:SetSize( 160, 85 )
    local test1 = list1:AddColumn( "Name" )
    test1.Header.PaintOver = function()
        surface.SetDrawColor( Color( 30, 30, 30, 255 ) )
        surface.DrawRect( 0, 0, test1.Header:GetWide(), test1.Header:GetTall() )

        surface.SetDrawColor( Color( 50, 50, 50, 255 ) )
        surface.DrawRect( 1, 1, test1.Header:GetWide() - 2, test1.Header:GetTall() - 2 )

        draw.SimpleText( "Name", "Default", test1.Header:GetWide() / 2 - 13, 1, botBot.colors.theme.norm )

    end 
    local test2 = list1:AddColumn( "Enemy" )
    test2.Header.PaintOver = function()
        surface.SetDrawColor( Color( 30, 30, 30, 255 ) )
        surface.DrawRect( 0, 0, test2.Header:GetWide(), test2.Header:GetTall() )

        surface.SetDrawColor( Color( 50, 50, 50, 255 ) )
        surface.DrawRect( 1, 1, test2.Header:GetWide() - 2, test2.Header:GetTall() - 2 )

        draw.SimpleText( "Enemy", "Default", test2.Header:GetWide() / 2 - 15, 1, botBot.colors.theme.norm )

    end 

    function UpdateList()
        list1:Clear()
        getall = {}

        for k,v in pairs( player.GetAll() ) do
            if v != LocalPlayer() then
                table.insert( getall, v )
            end
        end
        
        for k,v in pairs( getall ) do
            list1:AddLine( v:Nick(), tostring( table.HasValue( targs, v ) ) )
            print(v)
        end

    end


    local button2 = vgui.Create( "DButton", panel1 )
    button2:SetSize( 18, 18 )
    button2:SetPos( 178, 148 )
    button2:SetText( "" )
    button2.Paint = function() 
        surface.SetDrawColor( 0, 0, 0, 255 ) 
        surface.DrawOutlinedRect( 0, 0, button2:GetWide(), button2:GetTall() )

        surface.SetDrawColor( 30, 30, 30, 255 )
        surface.DrawRect( 1, 1, button2:GetWide() - 2, button2:GetTall() - 2 )

        draw.SimpleText( ">>", "Trebuchet19", 0, 0, botBot.colors.theme.norm )
    end
    button2.DoClick = function()
        targs = {}
        UpdateList()
    end

    local button3 = vgui.Create( "DButton", panel1 )
    button3:SetSize( 18, 18 )
    button3:SetPos( 178, 174 )
    button3:SetText( "" )
    button3.Paint = function() 
        surface.SetDrawColor( 0, 0, 0, 255 ) 
        surface.DrawOutlinedRect( 0, 0, button3:GetWide(), button3:GetTall() )

        surface.SetDrawColor( 30, 30, 30, 255 )
        surface.DrawRect( 1, 1, button3:GetWide() - 2, button3:GetTall() - 2 )

        draw.SimpleText( "<<", "Trebuchet19", 1, 0, botBot.colors.theme.norm )
    end
    button3.DoClick = function()
        targs = player.GetAll()

        for k,v in pairs( targs ) do
            if v == LocalPlayer() then
                table.remove( targs, k )
            end
        end
        UpdateList()
    end

    local button4 = vgui.Create( "DButton", panel1 )
    button4:SetSize( 18, 18 )
    button4:SetPos( 178, 200 )
    button4:SetText( "" )
    button4.Paint = function() 
        surface.SetDrawColor( 0, 0, 0, 255 ) 
        surface.DrawOutlinedRect( 0, 0, button4:GetWide(), button4:GetTall() )

        surface.SetDrawColor( 30, 30, 30, 255 )
        surface.DrawRect( 1, 1, button4:GetWide() - 2, button4:GetTall() - 2 )

        draw.SimpleText( "+-", "Trebuchet22", 2, -3, botBot.colors.theme.norm )
    end
    button4.DoClick = function()
        local selected = list1:GetLine( list1:GetSelectedLine() )
        local target = FindPlayerByName( selected:GetValue(1) )

        if selected:GetValue(2) == "true" then
            table.remove( targs, GetIndexInTable( target, targs ) )
        else
            table.insert( targs, target )
        end
        UpdateList()
    end 

    local num1 = vgui.Create( "DNumSlider", panel1 )
    num1:SetPos( 16, 100 )
    num1:SetWide( 150 )
    num1:SetMin( 0 )
    num1:SetMax( 100000 )
    num1:SetText( "Maximum Dist." )
    num1:SetConVar( "botBot_aim_maxdist" )
    num1.Label:SetTextColor( botBot.colors.theme.norm )
    num1.Slider.Paint = function()
        draw.RoundedBox( 4, 0, 0, num1.Slider:GetWide(), num1.Slider:GetTall(), botBot.colors.theme.light )

        surface.SetDrawColor( Color( 50, 50, 50, 255 ) )
        surface.DrawLine( 4, num1.Slider:GetTall() / 2, num1.Slider:GetWide() - 4, num1.Slider:GetTall() / 2 )
    end

    local check2 = vgui.Create( "DCheckBoxLabel", panel1 )
    check2:SetPos( 15, 10 )
    check2:SetText( "Enabled" )
    check2:SizeToContents()
    check2:SetConVar( "botBot_aim_enabled" )
    check2:SetTextColor( botBot.colors.theme.norm )

    local check3 = vgui.Create( "DCheckBoxLabel", panel1 )
    check3:SetPos( 15, 28 )
    check3:SetText( "Autoshoot" )
    check3:SizeToContents()
    check3:SetConVar( "botBot_aim_autoshoot" )
    check3:SetTextColor( botBot.colors.theme.norm )

    local check4 = vgui.Create( "DCheckBoxLabel", panel1 )
    check4:SetPos( 15, 46 )
    check4:SetText( "NPCs" )
    check4:SizeToContents()
    check4:SetConVar( "botBot_aim_targetnpcs" )
    check4:SetTextColor( botBot.colors.theme.norm )

    local check5 = vgui.Create( "DCheckBoxLabel", panel1 )
    check5:SetPos( 15, 64 )
    check5:SetText( "Steam Friends" )
    check5:SizeToContents()
    check5:SetConVar( "botBot_aim_targetsteamfriends" )
    check5:SetTextColor( botBot.colors.theme.norm )

    local check6 = vgui.Create( "DCheckBoxLabel", panel1 )
    check6:SetPos( 15, 82 )
    check6:SetText( "Admins" )
    check6:SizeToContents()
    check6:SetConVar( "botBot_aim_targetadmins" )
    check6:SetTextColor( botBot.colors.theme.norm )

    -------------
    -- ESP Tab --
    -------------
    panel2 = vgui.Create( "DPanel", frame1 )
    panel2:SetPos( 7, 55 )
    panel2:SetSize( 211, 237 )
    panel2.Paint = function()
        draw.RoundedBoxEx( 4, 0, 0, panel2:GetWide(), panel2:GetTall(), Color( 0, 0, 0, 255 ), false, true, true, true )
        draw.RoundedBoxEx( 4, 1, 1, panel2:GetWide() - 2, panel2:GetTall() - 2, Color( 50, 50, 50, 255 ), false, true, true, true )
        draw.RoundedBox( 0, 49, 0, 39, 5, Color( 50, 50, 50, 255 ) )
    end

     
    local Table2 = sheet1:AddSheet( "       ", panel2, false, false, "'dem ESP options" )
    Table2.Tab.Paint = function()
        draw.RoundedBoxEx( 4, 0, 0, Table2.Tab:GetWide(), Table2.Tab:GetTall(), Color( 0, 0, 0, 255 ), true, true, false, false )
        draw.RoundedBoxEx( 4, 1, 1, Table2.Tab:GetWide() - 2, Table2.Tab:GetTall() - 1, Color( 50, 50, 50, 255 ), true, true, false, false )
        draw.SimpleText( "ESP", "Default", 10, 5, botBot.colors.theme.norm )
    end
     
    Dlist = vgui.Create( "DPanelList", panel2 )
    Dlist:SetPos( 15, 10 )
    Dlist:SetSize( 115, 216 )
    Dlist:SetSpacing( 4 )
    Dlist:EnableHorizontal( false )
    Dlist:EnableVerticalScrollbar( true )
    Dlist.Paint = function() end
    
    for i = 1, 10 do
        botBot.espchecks[i] = vgui.Create( "DCheckBoxLabel" )
        botBot.espchecks[i]:SetText( "Label" )
        botBot.espchecks[i]:SetTextColor( botBot.colors.theme.norm )
        
        Dlist:AddItem( botBot.espchecks[i] )   
    end
     
    botBot.espchecks[1]:SetText( "Enabled" )
    botBot.espchecks[1]:SizeToContents()
    botBot.espchecks[1]:SetConVar( "botBot_esp_enabled" )

    botBot.espchecks[2]:SetText( "Show Players" )
    botBot.espchecks[2]:SizeToContents()
    botBot.espchecks[2]:SetConVar( "botBot_esp_targetplayers" )

    botBot.espchecks[3]:SetText( "Show NPCs" )
    botBot.espchecks[3]:SizeToContents()
    botBot.espchecks[3]:SetConVar( "botBot_esp_targetnpcs" )

    botBot.espchecks[4]:SetText( "Show Names" )
    botBot.espchecks[4]:SizeToContents()
    botBot.espchecks[4]:SetConVar( "botBot_esp_showname" )

    botBot.espchecks[5]:SetText( "Show Health" )
    botBot.espchecks[5]:SizeToContents()
    botBot.espchecks[5]:SetConVar( "botBot_esp_showhealth" )

    botBot.espchecks[6]:SetText( "Show Admin Status" )
    botBot.espchecks[6]:SizeToContents()
    botBot.espchecks[6]:SetConVar( "botBot_esp_showadmin" )

    botBot.espchecks[7]:SetText( "Show STEAMID" )
    botBot.espchecks[7]:SizeToContents()
    botBot.espchecks[7]:SetConVar( "botBot_esp_showsteam" )

    botBot.espchecks[8]:SetText( "Show Lines" )
    botBot.espchecks[8]:SizeToContents()
    botBot.espchecks[8]:SetConVar( "botBot_esp_showlines" )

    botBot.espchecks[9]:SetText( "Show Player Bones" )
    botBot.espchecks[9]:SizeToContents()
    botBot.espchecks[9]:SetConVar( "botBot_esp_showbones" )

    botBot.espchecks[10]:SetText( "Show Player Model" )
    botBot.espchecks[10]:SizeToContents()
    botBot.espchecks[10]:SetConVar( "botBot_esp_showmodel" )

    button5 = vgui.Create( "DButton", panel2 )
    button5:SetPos( 15, 195 )
    button5:SetSize( 60, 29 )
    button5:SetText( "" )
    button5.Paint = function()
        surface.SetDrawColor( 0, 0, 0, 255 ) 
        surface.DrawOutlinedRect( 0, 0, button5:GetWide(), button5:GetTall() )

        surface.SetDrawColor( 30, 30, 30, 255 )
        surface.DrawRect( 1, 1, button5:GetWide() - 2, button5:GetTall() - 2 )

        draw.SimpleText( "Enable All", "Default", 7, 8, botBot.colors.theme.norm )
    end
    button5.DoClick = function()
        RunConsoleCommand( "botBot_esp_enableall" )
    end

    button6 = vgui.Create( "DButton", panel2 )
    button6:SetPos( 85, 195 )
    button6:SetSize( 60, 29 )
    button6:SetText( "" )
    button6.Paint = function()
        surface.SetDrawColor( 0, 0, 0, 255 ) 
        surface.DrawOutlinedRect( 0, 0, button6:GetWide(), button6:GetTall() )

        surface.SetDrawColor( 30, 30, 30, 255 )
        surface.DrawRect( 1, 1, button6:GetWide() - 2, button6:GetTall() - 2 )

        draw.SimpleText( "Disable All", "Default", 7, 8, botBot.colors.theme.norm )
    end
    button6.DoClick = function()
        RunConsoleCommand( "botBot_esp_disableall" )
    end


    -------------- 
    -- Misc Tab --
    --------------
    panel3 = vgui.Create( "DPanel", frame1 )
    panel3:SetPos( 7, 55 )
    panel3:SetSize( 211, 237 )
    panel3.Paint = function()
        draw.RoundedBoxEx( 4, 0, 0, panel3:GetWide(), panel3:GetTall(), Color( 0, 0, 0, 255 ), false, true, true, true )
        draw.RoundedBoxEx( 4, 1, 1, panel3:GetWide() - 2, panel3:GetTall() - 2, Color( 50, 50, 50, 255 ), false, true, true, true )
        draw.RoundedBox( 0, 85, 0, 42, 5, Color( 50, 50, 50, 255 ) )
    end
     
    local Table3 = sheet1:AddSheet( "        ", panel3, false, false, "We're spoiling you by giving you this tab, you know." )
    Table3.Tab.Paint = function()
        draw.RoundedBoxEx( 4, 0, 0, Table3.Tab:GetWide(), Table3.Tab:GetTall(), Color( 0, 0, 0, 255 ), true, true, false, false )
        draw.RoundedBoxEx( 4, 1, 1, Table3.Tab:GetWide() - 2, Table3.Tab:GetTall() - 1, Color( 50, 50, 50, 255 ), true, true, false, false )
        draw.SimpleText( "Misc", "Default", 10, 5, botBot.colors.theme.norm )
    end

    local check1 = vgui.Create( "DCheckBox", panel3 )
    check1:SetPos( 20, 17 )
--    check1:SetText( "Click to toggle BunnyHop" )
--    check1:SizeToContents()

    check1:SetValue( bhop )

    check1.DoClick = function() 
        check1:Toggle()
        bhop = not bhop
    end

    local label1 = vgui.Create( "DLabel", panel3 )
    label1:SetPos( 40, 16 )
    label1:SetText( "BunnyHop toggle" )
    label1:SetFont( "Default" )
    label1:SetTextColor( botBot.colors.theme.norm )
    label1:SizeToContents()

    local label2 = vgui.Create( "DLabel", panel3 )
    label2:SetPos( 15, 32 )
    label2:SetText( "You can also bind a key to '+botbot_bh'" )
    label2:SetFont( "DefaultSmall" )
    label2:SetTextColor( botBot.colors.theme.light )
    label2:SizeToContents()

    local label3 = vgui.Create( "DLabel", panel3 )
    label3:SetPos( 33, 49 )
    label3:SetText( "Theme" )
    label3:SetFont( "Default" )
    label3:SetTextColor( botBot.colors.theme.norm )
    label3:SizeToContents()

    local multi1 = vgui.Create( "DMultiChoice", panel3 )
    multi1:SetPos( 20, 65 )
    multi1:AddChoice( "Blue" )
    multi1:AddChoice( "Green" )
    multi1:AddChoice( "Orange" )
    multi1:AddChoice( "White" )
    multi1.OnSelect = function( value, index, data )
        RunConsoleCommand( "botBot_theme", index - 1 )

        frame1:Close()
        RunConsoleCommand( "botBot_menu" )
        sheet1:SetActiveTab( nil )
    end




    hook.Add( "Think", "tehthink", function()
        if #plyers ~= table.Count( player.GetAll() ) then   
            getall = player.GetAll()

            for k,v in pairs( getall ) do
                if v == LocalPlayer() then
                    table.remove( getall, k )
                end
            end
            UpdateList()
        end
        plyers = player.GetAll()
    end )
    UpdateList()

    frame1:MoveTo( 156, 256, 0.5, 0, 2)
end )
