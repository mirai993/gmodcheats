--[[
	MOD/lua/lololololol/meh.lua
	☆☆ wuff you :3 | STEAM_0:0:67962271 <74.214.144.97:27005> | [23-10-13 04:41:37AM]
	===BadFile===
]]

// Copyright 2013 - Coke_Is_Awesome - B-Hacks V4 Menu

function MainMenu()

	// Frames \\
	
	MainFrame = vgui.Create( "DFrame" ) -- Main Frame
	MainFrame:SetPos( 50, 50 )
	MainFrame:SetSize( 1800, 820 ) -- <> || ^V
	MainFrame:SetTitle( "B-Hacks V4" )
	MainFrame:SetVisible( true )
	MainFrame:SetDraggable( false )
	MainFrame:ShowCloseButton( false )
	MainFrame:MakePopup()
	MainFrame.Paint = function()
		surface.SetDrawColor( 6, 6, 6, 250 )
		surface.DrawRect( 0, 0, MainFrame:GetWide(), MainFrame:GetTall() )
	end
	
	SecondFrame = vgui.Create( "DFrame" )
	SecondFrame:SetPos( 50, 50 )
	SecondFrame:SetSize( 1800, 820 ) -- <> || ^V
	SecondFrame:SetTitle( "B-Hacks V4" )
	SecondFrame:SetVisible( false )
	SecondFrame:SetDraggable( false )
	SecondFrame:ShowCloseButton( false )
	SecondFrame:MakePopup()
	SecondFrame.Paint = function()
    surface.SetDrawColor( 6, 6, 6, 250 )
    surface.DrawRect( 0, 0, SecondFrame:GetWide(), SecondFrame:GetTall() )
	end

	ThirdFrame = vgui.Create( "DFrame" )
	ThirdFrame:SetPos( 50, 50 )
	ThirdFrame:SetSize( 1800, 820 ) -- <> || ^V
	ThirdFrame:SetTitle( "B-Hacks V4" )
	ThirdFrame:SetVisible( false )
	ThirdFrame:SetDraggable( false )
	ThirdFrame:ShowCloseButton( false )
	ThirdFrame:MakePopup()
	ThirdFrame.Paint = function()
    surface.SetDrawColor( 6, 6, 6, 250 )
    surface.DrawRect( 0, 0, ThirdFrame:GetWide(), ThirdFrame:GetTall() )
	end
	
	FourthFrame = vgui.Create( "DFrame" )
	FourthFrame:SetPos( 50, 50 )
	FourthFrame:SetSize( 1800, 820 ) -- <> || ^V
	FourthFrame:SetTitle( "B-Hacks V4" )
	FourthFrame:SetVisible( false )
	FourthFrame:SetDraggable( false )
	FourthFrame:ShowCloseButton( false )
	FourthFrame:MakePopup()
	FourthFrame.Paint = function()
    surface.SetDrawColor( 6, 6, 6, 250 )
    surface.DrawRect( 0, 0, FourthFrame:GetWide(), FourthFrame:GetTall() )
	end
	
	FifthFrame = vgui.Create( "DFrame" )
	FifthFrame:SetPos( 50, 50 )
	FifthFrame:SetSize( 1800, 820 ) -- <> || ^V
	FifthFrame:SetTitle( "B-Hacks V4" )
	FifthFrame:SetVisible( false )
	FifthFrame:SetDraggable( false )
	FifthFrame:ShowCloseButton( false )
	FifthFrame:MakePopup()
	FifthFrame.Paint = function()
    surface.SetDrawColor( 6, 6, 6, 250 )
    surface.DrawRect( 0, 0, FifthFrame:GetWide(), FifthFrame:GetTall() )
	end
	
	SixthFrame = vgui.Create( "DFrame" )
	SixthFrame:SetPos( 50, 50 )
	SixthFrame:SetSize( 1800, 820 ) -- <> || ^V
	SixthFrame:SetTitle( "B-Hacks V4" )
	SixthFrame:SetVisible( false )
	SixthFrame:SetDraggable( false )
	SixthFrame:ShowCloseButton( false )
	SixthFrame:MakePopup()
	SixthFrame.Paint = function()
    surface.SetDrawColor( 6, 6, 6, 250 )
    surface.DrawRect( 0, 0, SixthFrame:GetWide(), SixthFrame:GetTall() )
	end
	
	// Buttons \\
	
	local CloseButtonMainFrame = vgui.Create( "Button", MainFrame )
        CloseButtonMainFrame:SetSize( 1700, 35 )
        CloseButtonMainFrame:SetPos( 70, 2 )
        CloseButtonMainFrame:SetVisible( true )
        CloseButtonMainFrame:SetText( "Close Menu" )
		CloseButtonMainFrame.Paint = function()
			surface.SetDrawColor( 10, 10, 240, 200 )
			surface.DrawRect( 0, 4, CloseButtonMainFrame:GetWide(), CloseButtonMainFrame:GetTall() )
		end
        function CloseButtonMainFrame:OnMousePressed()
			MainFrame:Close()
        end
		
	local CloseButtonSecondFrame = vgui.Create( "Button", SecondFrame )
        CloseButtonSecondFrame:SetSize( 1700, 35 )
        CloseButtonSecondFrame:SetPos( 70, 2 )
        CloseButtonSecondFrame:SetVisible( true )
        CloseButtonSecondFrame:SetText( "Close Menu" )
		CloseButtonSecondFrame.Paint = function()
			surface.SetDrawColor( 10, 10, 240, 200 )
			surface.DrawRect( 0, 4, CloseButtonSecondFrame:GetWide(), CloseButtonSecondFrame:GetTall() )
		end
        function CloseButtonSecondFrame:OnMousePressed()
			SecondFrame:Close()
        end
		
	local CloseButtonThirdFrame = vgui.Create( "Button", ThirdFrame )
        CloseButtonThirdFrame:SetSize( 1700, 35 )
        CloseButtonThirdFrame:SetPos( 70, 2 )
        CloseButtonThirdFrame:SetVisible( true )
        CloseButtonThirdFrame:SetText( "Close Menu" )
		CloseButtonThirdFrame.Paint = function()
			surface.SetDrawColor( 10, 10, 240, 200 )
			surface.DrawRect( 0, 4, CloseButtonThirdFrame:GetWide(), CloseButtonThirdFrame:GetTall() )
		end
        function CloseButtonThirdFrame:OnMousePressed()
			ThirdFrame:Close()
        end
		
	local CloseButtonFourthFrame = vgui.Create( "Button", FourthFrame )
        CloseButtonFourthFrame:SetSize( 1700, 35 )
        CloseButtonFourthFrame:SetPos( 70, 2 )
        CloseButtonFourthFrame:SetVisible( true )
        CloseButtonFourthFrame:SetText( "Close Menu" )
		CloseButtonFourthFrame.Paint = function()
			surface.SetDrawColor( 10, 10, 240, 200 )
			surface.DrawRect( 0, 4, CloseButtonFourthFrame:GetWide(), CloseButtonFourthFrame:GetTall() )
		end
        function CloseButtonFourthFrame:OnMousePressed()
			FourthFrame:Close()
        end
		
	local CloseButtonFifthFrame = vgui.Create( "Button", FifthFrame )
        CloseButtonFifthFrame:SetSize( 1700, 35 )
        CloseButtonFifthFrame:SetPos( 70, 2 )
        CloseButtonFifthFrame:SetVisible( true )
        CloseButtonFifthFrame:SetText( "Close Menu" )
		CloseButtonFifthFrame.Paint = function()
			surface.SetDrawColor( 10, 10, 240, 200 )
			surface.DrawRect( 0, 4, CloseButtonFifthFrame:GetWide(), CloseButtonFifthFrame:GetTall() )
		end
        function CloseButtonFifthFrame:OnMousePressed()
			FifthFrame:Close()
        end
		
	local CloseButtonSixthFrame = vgui.Create( "Button", SixthFrame )
        CloseButtonSixthFrame:SetSize( 1700, 35 )
        CloseButtonSixthFrame:SetPos( 70, 2 )
        CloseButtonSixthFrame:SetVisible( true )
        CloseButtonSixthFrame:SetText( "Close Menu" )
		CloseButtonSixthFrame.Paint = function()
			surface.SetDrawColor( 10, 10, 240, 200 )
			surface.DrawRect( 0, 4, CloseButtonSixthFrame:GetWide(), CloseButtonSixthFrame:GetTall() )
		end
        function CloseButtonSixthFrame:OnMousePressed()
			FifthFrame:Close()
        end
		
		// Tabs \\
		
	local NextTabButtonMainFrame = vgui.Create( "Button", MainFrame )
        NextTabButtonMainFrame:SetSize( 50, 710 )
        NextTabButtonMainFrame:SetPos( 1720, 40 )
        NextTabButtonMainFrame:SetVisible( true )
        NextTabButtonMainFrame:SetText( "Next Tab" )
		NextTabButtonMainFrame.Paint = function()
			surface.SetDrawColor( 10, 10, 240, 200 )
			surface.DrawRect( 0, 4, NextTabButtonMainFrame:GetWide(), NextTabButtonMainFrame:GetTall() )
		end
        function NextTabButtonMainFrame:OnMousePressed()
			MainFrame:SetVisible( false )
			SecondFrame:SetVisible( true )
        end

	local BackTabButtonSecondFrame = vgui.Create( "Button", SecondFrame )
        BackTabButtonSecondFrame:SetSize( 50, 700 )
        BackTabButtonSecondFrame:SetPos( 70, 40 )
        BackTabButtonSecondFrame:SetVisible( true )
        BackTabButtonSecondFrame:SetText( "Back Tab" )
		BackTabButtonSecondFrame.Paint = function()
			surface.SetDrawColor( 10, 10, 240, 200 )
			surface.DrawRect( 0, 4, BackTabButtonSecondFrame:GetWide(), BackTabButtonSecondFrame:GetTall() )
		end
        function BackTabButtonSecondFrame:OnMousePressed()
			SecondFrame:SetVisible( false )
			MainFrame:SetVisible( true )
        end
		
	local BackTabButtonThirdFrame = vgui.Create( "Button", ThirdFrame )
        BackTabButtonThirdFrame:SetSize( 50, 700 )
        BackTabButtonThirdFrame:SetPos( 70, 40 )
        BackTabButtonThirdFrame:SetVisible( true )
        BackTabButtonThirdFrame:SetText( "Back Tab" )
		BackTabButtonThirdFrame.Paint = function()
			surface.SetDrawColor( 10, 10, 240, 200 )
			surface.DrawRect( 0, 4, BackTabButtonThirdFrame:GetWide(), BackTabButtonThirdFrame:GetTall() )
		end
        function BackTabButtonThirdFrame:OnMousePressed()
			SecondFrame:SetVisible( false )
			ThirdFrame:SetVisible( false )
			MainFrame:SetVisible( true )
        end
		
	local BackTabButtonFourthFrame = vgui.Create( "Button", FourthFrame )
        BackTabButtonFourthFrame:SetSize( 50, 700 )
        BackTabButtonFourthFrame:SetPos( 70, 40 )
        BackTabButtonFourthFrame:SetVisible( true )
        BackTabButtonFourthFrame:SetText( "Back Tab" )
		BackTabButtonFourthFrame.Paint = function()
			surface.SetDrawColor( 10, 10, 240, 200 )
			surface.DrawRect( 0, 4, BackTabButtonFourthFrame:GetWide(), BackTabButtonFourthFrame:GetTall() )
		end
        function BackTabButtonFourthFrame:OnMousePressed()
			SecondFrame:SetVisible( false )
			ThirdFrame:SetVisible( false )
			FourthFrame:SetVisible( false )
			MainFrame:SetVisible( true )
        end
		
	local BackTabButtonFifthFrame = vgui.Create( "Button", FifthFrame )
        BackTabButtonFifthFrame:SetSize( 50, 700 )
        BackTabButtonFifthFrame:SetPos( 70, 40 )
        BackTabButtonFifthFrame:SetVisible( true )
        BackTabButtonFifthFrame:SetText( "Back Tab" )
		BackTabButtonFifthFrame.Paint = function()
			surface.SetDrawColor( 10, 10, 240, 200 )
			surface.DrawRect( 0, 4, BackTabButtonFifthFrame:GetWide(), BackTabButtonFifthFrame:GetTall() )
		end
        function BackTabButtonFifthFrame:OnMousePressed()
			SecondFrame:SetVisible( false )
			ThirdFrame:SetVisible( false )
			FourthFrame:SetVisible( false )
			FifthFrame:SetVisible( false )
			MainFrame:SetVisible( true )
        end
		
	local BackTabButtonSixthFrame = vgui.Create( "Button", SixthFrame )
        BackTabButtonSixthFrame:SetSize( 50, 700 )
        BackTabButtonSixthFrame:SetPos( 70, 40 )
        BackTabButtonSixthFrame:SetVisible( true )
        BackTabButtonSixthFrame:SetText( "Back Tab" )
		BackTabButtonSixthFrame.Paint = function()
			surface.SetDrawColor( 10, 10, 240, 200 )
			surface.DrawRect( 0, 4, BackTabButtonSixthFrame:GetWide(), BackTabButtonSixthFrame:GetTall() )
		end
        function BackTabButtonSixthFrame:OnMousePressed()
			SecondFrame:SetVisible( false )
			ThirdFrame:SetVisible( false )
			FourthFrame:SetVisible( false )
			FifthFrame:SetVisible( false )
			SixthFrame:SetVisible( false )
			MainFrame:SetVisible( true )
        end
		
		// Disconnect Buttons \\
		
	local DisconnectMainFrame = vgui.Create( "Button", MainFrame )
        DisconnectMainFrame:SetSize( 400, 55 )
        DisconnectMainFrame:SetPos( 1370, 755 )
        DisconnectMainFrame:SetVisible( true )
        DisconnectMainFrame:SetText( "Disconnect From Server" )
		DisconnectMainFrame.Paint = function()
			surface.SetDrawColor( 244, 10, 10, 200 )
			surface.DrawRect( 0, 4, DisconnectMainFrame:GetWide(), DisconnectMainFrame:GetTall() )
		end
        function DisconnectMainFrame:OnMousePressed()
			LocalPlayer():ConCommand("Disconnect")
        end
		
	local DisconnectSecondFrame = vgui.Create( "Button", SecondFrame )
        DisconnectSecondFrame:SetSize( 400, 55 )
        DisconnectSecondFrame:SetPos( 1370, 755 )
        DisconnectSecondFrame:SetVisible( true )
        DisconnectSecondFrame:SetText( "Disconnect From Server" )
		DisconnectSecondFrame.Paint = function()
			surface.SetDrawColor( 244, 10, 10, 200 )
			surface.DrawRect( 0, 4, DisconnectSecondFrame:GetWide(), DisconnectSecondFrame:GetTall() )
		end
        function DisconnectSecondFrame:OnMousePressed()
			LocalPlayer():ConCommand("Disconnect")
        end
		
	local DisconnectThirdFrame = vgui.Create( "Button", ThirdFrame )
        DisconnectThirdFrame:SetSize( 400, 55 )
        DisconnectThirdFrame:SetPos( 1370, 755 )
        DisconnectThirdFrame:SetVisible( true )
        DisconnectThirdFrame:SetText( "Disconnect From Server" )
		DisconnectThirdFrame.Paint = function()
			surface.SetDrawColor( 244, 10, 10, 200 )
			surface.DrawRect( 0, 4, DisconnectThirdFrame:GetWide(), DisconnectThirdFrame:GetTall() )
		end
        function DisconnectThirdFrame:OnMousePressed()
			LocalPlayer():ConCommand("Disconnect")
        end
		
	local DisconnectFourthFrame = vgui.Create( "Button", FourthFrame )
        DisconnectFourthFrame:SetSize( 400, 55 )
        DisconnectFourthFrame:SetPos( 1370, 755 )
        DisconnectFourthFrame:SetVisible( true )
        DisconnectFourthFrame:SetText( "Disconnect From Server" )
		DisconnectFourthFrame.Paint = function()
			surface.SetDrawColor( 244, 10, 10, 200 )
			surface.DrawRect( 0, 4, DisconnectFourthFrame:GetWide(), DisconnectFourthFrame:GetTall() )
		end
        function DisconnectFourthFrame:OnMousePressed()
			LocalPlayer():ConCommand("Disconnect")
        end
		
	local DisconnectFifthFrame = vgui.Create( "Button", FifthFrame )
        DisconnectFifthFrame:SetSize( 400, 55 )
        DisconnectFifthFrame:SetPos( 1370, 755 )
        DisconnectFifthFrame:SetVisible( true )
        DisconnectFifthFrame:SetText( "Disconnect From Server" )
		DisconnectFifthFrame.Paint = function()
			surface.SetDrawColor( 244, 10, 10, 200 )
			surface.DrawRect( 0, 4, DisconnectFifthFrame:GetWide(), DisconnectFifthFrame:GetTall() )
		end
        function DisconnectFifthFrame:OnMousePressed()
			LocalPlayer():ConCommand("Disconnect")
        end
		
	local DisconnectSixthFrame = vgui.Create( "Button", SixthFrame )
        DisconnectSixthFrame:SetSize( 400, 55 )
        DisconnectSixthFrame:SetPos( 1370, 755 )
        DisconnectSixthFrame:SetVisible( true )
        DisconnectSixthFrame:SetText( "Disconnect From Server" )
		DisconnectSixthFrame.Paint = function()
			surface.SetDrawColor( 244, 10, 10, 200 )
			surface.DrawRect( 0, 4, DisconnectSixthFrame:GetWide(), DisconnectSixthFrame:GetTall() )
		end
        function DisconnectSixthFrame:OnMousePressed()
			LocalPlayer():ConCommand("Disconnect")
        end
		
		// BuyHealth Buttons \\
		
	local BuyHealthMainFrame = vgui.Create( "Button", MainFrame )
        BuyHealthMainFrame:SetSize( 400, 55 )
        BuyHealthMainFrame:SetPos( 70, 755 )
        BuyHealthMainFrame:SetVisible( true )
        BuyHealthMainFrame:SetText( "BuyHealth" )
		BuyHealthMainFrame.Paint = function()
			surface.SetDrawColor( 10, 10, 244, 200 )
			surface.DrawRect( 0, 4, BuyHealthMainFrame:GetWide(), BuyHealthMainFrame:GetTall() )
		end
        function BuyHealthMainFrame:OnMousePressed()
			LocalPlayer():ConCommand("say /buyhealth")
        end

	local BuyHealthSecondFrame = vgui.Create( "Button", SecondFrame )
        BuyHealthSecondFrame:SetSize( 400, 55 )
        BuyHealthSecondFrame:SetPos( 70, 755 )
        BuyHealthSecondFrame:SetVisible( true )
        BuyHealthSecondFrame:SetText( "BuyHealth" )
		BuyHealthSecondFrame.Paint = function()
			surface.SetDrawColor( 10, 10, 244, 200 )
			surface.DrawRect( 0, 4, BuyHealthSecondFrame:GetWide(), BuyHealthSecondFrame:GetTall() )
		end
        function BuyHealthSecondFrame:OnMousePressed()
			LocalPlayer():ConCommand("say /buyhealth")
        end
		
	local BuyHealthThirdFrame = vgui.Create( "Button", ThirdFrame )
        BuyHealthThirdFrame:SetSize( 400, 55 )
        BuyHealthThirdFrame:SetPos( 70, 755 )
        BuyHealthThirdFrame:SetVisible( true )
        BuyHealthThirdFrame:SetText( "BuyHealth" )
		BuyHealthThirdFrame.Paint = function()
			surface.SetDrawColor( 10, 10, 244, 200 )
			surface.DrawRect( 0, 4, BuyHealthThirdFrame:GetWide(), BuyHealthThirdFrame:GetTall() )
		end
        function BuyHealthThirdFrame:OnMousePressed()
			LocalPlayer():ConCommand("say /buyhealth")
        end
		
	local BuyHealthFourthFrame = vgui.Create( "Button", FourthFrame )
        BuyHealthFourthFrame:SetSize( 400, 55 )
        BuyHealthFourthFrame:SetPos( 70, 755 )
        BuyHealthFourthFrame:SetVisible( true )
        BuyHealthFourthFrame:SetText( "BuyHealth" )
		BuyHealthFourthFrame.Paint = function()
			surface.SetDrawColor( 10, 10, 244, 200 )
			surface.DrawRect( 0, 4, BuyHealthFourthFrame:GetWide(), BuyHealthFourthFrame:GetTall() )
		end
        function BuyHealthFourthFrame:OnMousePressed()
			LocalPlayer():ConCommand("say /buyhealth")
        end
		
	local BuyHealthFifthFrame = vgui.Create( "Button", FifthFrame )
        BuyHealthFifthFrame:SetSize( 400, 55 )
        BuyHealthFifthFrame:SetPos( 70, 755 )
        BuyHealthFifthFrame:SetVisible( true )
        BuyHealthFifthFrame:SetText( "BuyHealth" )
		BuyHealthFifthFrame.Paint = function()
			surface.SetDrawColor( 10, 10, 244, 200 )
			surface.DrawRect( 0, 4, BuyHealthFifthFrame:GetWide(), BuyHealthFifthFrame:GetTall() )
		end
        function BuyHealthFifthFrame:OnMousePressed()
			LocalPlayer():ConCommand("say /buyhealth")
        end
		
	local BuyHealthSixthFrame = vgui.Create( "Button", SixthFrame )
        BuyHealthSixthFrame:SetSize( 400, 55 )
        BuyHealthSixthFrame:SetPos( 70, 755 )
        BuyHealthSixthFrame:SetVisible( true )
        BuyHealthSixthFrame:SetText( "BuyHealth" )
		BuyHealthSixthFrame.Paint = function()
			surface.SetDrawColor( 10, 10, 244, 200 )
			surface.DrawRect( 0, 4, BuyHealthSixthFrame:GetWide(), BuyHealthSixthFrame:GetTall() )
		end
        function BuyHealthSixthFrame:OnMousePressed()
			LocalPlayer():ConCommand("say /buyhealth")
        end

		// Admin To Me Buttons \\
		
	local AdminToMeMainFrame = vgui.Create( "Button", MainFrame )
        AdminToMeMainFrame:SetSize( 400, 55 )
        AdminToMeMainFrame:SetPos( 700, 755 )
        AdminToMeMainFrame:SetVisible( true )
        AdminToMeMainFrame:SetText( "Admin To Me" )
		AdminToMeMainFrame.Paint = function()
			surface.SetDrawColor( 10, 244, 10, 200 )
			surface.DrawRect( 0, 4, AdminToMeMainFrame:GetWide(), AdminToMeMainFrame:GetTall() )
		end
        function AdminToMeMainFrame:OnMousePressed()
			LocalPlayer():ConCommand("say @Admin To Me")
        end
		
	local AdminToMeSecondFrame = vgui.Create( "Button", SecondFrame )
        AdminToMeSecondFrame:SetSize( 400, 55 )
        AdminToMeSecondFrame:SetPos( 700, 755 )
        AdminToMeSecondFrame:SetVisible( true )
        AdminToMeSecondFrame:SetText( "Admin To Me" )
		AdminToMeSecondFrame.Paint = function()
			surface.SetDrawColor( 10, 244, 10, 200 )
			surface.DrawRect( 0, 4, AdminToMeSecondFrame:GetWide(), AdminToMeSecondFrame:GetTall() )
		end
        function AdminToMeSecondFrame:OnMousePressed()
			LocalPlayer():ConCommand("say @Admin To Me")
        end
		
	local AdminToMeThirdFrame = vgui.Create( "Button", ThirdFrame )
        AdminToMeThirdFrame:SetSize( 400, 55 )
        AdminToMeThirdFrame:SetPos( 700, 755 )
        AdminToMeThirdFrame:SetVisible( true )
        AdminToMeThirdFrame:SetText( "Admin To Me" )
		AdminToMeThirdFrame.Paint = function()
			surface.SetDrawColor( 10, 244, 10, 200 )
			surface.DrawRect( 0, 4, AdminToMeThirdFrame:GetWide(), AdminToMeThirdFrame:GetTall() )
		end
        function AdminToMeThirdFrame:OnMousePressed()
			LocalPlayer():ConCommand("say @Admin To Me")
        end
		
	local AdminToMeFourthFrame = vgui.Create( "Button", FourthFrame )
        AdminToMeFourthFrame:SetSize( 400, 55 )
        AdminToMeFourthFrame:SetPos( 700, 755 )
        AdminToMeFourthFrame:SetVisible( true )
        AdminToMeFourthFrame:SetText( "Admin To Me" )
		AdminToMeFourthFrame.Paint = function()
			surface.SetDrawColor( 10, 244, 10, 200 )
			surface.DrawRect( 0, 4, AdminToMeFourthFrame:GetWide(), AdminToMeFourthFrame:GetTall() )
		end
        function AdminToMeFourthFrame:OnMousePressed()
			LocalPlayer():ConCommand("say @Admin To Me")
        end
		
	local AdminToMeFifthFrame = vgui.Create( "Button", FifthFrame )
        AdminToMeFifthFrame:SetSize( 400, 55 )
        AdminToMeFifthFrame:SetPos( 700, 755 )
        AdminToMeFifthFrame:SetVisible( true )
        AdminToMeFifthFrame:SetText( "Admin To Me" )
		AdminToMeFifthFrame.Paint = function()
			surface.SetDrawColor( 10, 244, 10, 200 )
			surface.DrawRect( 0, 4, AdminToMeFifthFrame:GetWide(), AdminToMeFifthFrame:GetTall() )
		end
        function AdminToMeFifthFrame:OnMousePressed()
			LocalPlayer():ConCommand("say @Admin To Me")
        end
		
	local AdminToMeSixthFrame = vgui.Create( "Button", SixthFrame )
        AdminToMeSixthFrame:SetSize( 400, 55 )
        AdminToMeSixthFrame:SetPos( 700, 755 )
        AdminToMeSixthFrame:SetVisible( true )
        AdminToMeSixthFrame:SetText( "Admin To Me" )
		AdminToMeSixthFrame.Paint = function()
			surface.SetDrawColor( 10, 244, 10, 200 )
			surface.DrawRect( 0, 4, AdminToMeSixthFrame:GetWide(), AdminToMeSixthFrame:GetTall() )
		end
        function AdminToMeSixthFrame:OnMousePressed()
			LocalPlayer():ConCommand("say @Admin To Me")
        end
		
		// GmodWiki Buttons \\
		
	local GmodWikiOneMainFrame = vgui.Create( "Button", MainFrame )
        GmodWikiOneMainFrame:SetSize( 200, 25 )
        GmodWikiOneMainFrame:SetPos( 1130, 755 )
        GmodWikiOneMainFrame:SetVisible( true )
        GmodWikiOneMainFrame:SetText( "Gmod Wiki #1" )
		GmodWikiOneMainFrame.Paint = function()
			surface.SetDrawColor( 218, 229, 2, 200 )
			surface.DrawRect( 0, 4, GmodWikiOneMainFrame:GetWide(), GmodWikiOneMainFrame:GetTall() )
		end
        function GmodWikiOneMainFrame:OnMousePressed()
			MainFrame:SetVisible( false )
			SecondFrame:SetVisible( false )
			ThirdFrame:SetVisible( true )
        end
		
	local GmodWikiOneSecondFrame = vgui.Create( "Button", SecondFrame )
        GmodWikiOneSecondFrame:SetSize( 200, 25 )
        GmodWikiOneSecondFrame:SetPos( 1130, 755 )
        GmodWikiOneSecondFrame:SetVisible( true )
        GmodWikiOneSecondFrame:SetText( "Gmod Wiki #1" )
		GmodWikiOneSecondFrame.Paint = function()
			surface.SetDrawColor( 218, 229, 2, 200 )
			surface.DrawRect( 0, 4, GmodWikiOneSecondFrame:GetWide(), GmodWikiOneSecondFrame:GetTall() )
		end
        function GmodWikiOneSecondFrame:OnMousePressed()
			MainFrame:SetVisible( false )
			SecondFrame:SetVisible( false )
			ThirdFrame:SetVisible( true )
        end
		
	local GmodWikiOneThirdFrame = vgui.Create( "Button", ThirdFrame )
        GmodWikiOneThirdFrame:SetSize( 200, 25 )
        GmodWikiOneThirdFrame:SetPos( 1130, 755 )
        GmodWikiOneThirdFrame:SetVisible( true )
        GmodWikiOneThirdFrame:SetText( "Gmod Wiki #1" )
		GmodWikiOneThirdFrame.Paint = function()
			surface.SetDrawColor( 218, 229, 2, 200 )
			surface.DrawRect( 0, 4, GmodWikiOneThirdFrame:GetWide(), GmodWikiOneThirdFrame:GetTall() )
		end
        function GmodWikiOneThirdFrame:OnMousePressed()
			MainFrame:SetVisible( false )
			SecondFrame:SetVisible( false )
			FourthFrane:SetVisible( false )
			FifthFrame:SetVisible( false )
			ThirdFrame:SetVisible( true )
        end
		
	local GmodWikiOneFourthFrame = vgui.Create( "Button", FourthFrame )
        GmodWikiOneFourthFrame:SetSize( 200, 25 )
        GmodWikiOneFourthFrame:SetPos( 1130, 755 )
        GmodWikiOneFourthFrame:SetVisible( true )
        GmodWikiOneFourthFrame:SetText( "Gmod Wiki #1" )
		GmodWikiOneFourthFrame.Paint = function()
			surface.SetDrawColor( 218, 229, 2, 200 )
			surface.DrawRect( 0, 4, GmodWikiOneFourthFrame:GetWide(), GmodWikiOneFourthFrame:GetTall() )
		end
        function GmodWikiOneFourthFrame:OnMousePressed()
			MainFrame:SetVisible( false )
			SecondFrame:SetVisible( false )
			FifthFrame:SetVisible( false )
			FourthFrame:SetVisible( false )
			ThirdFrame:SetVisible( true )
        end

	local GmodWikiOneFifthFrame = vgui.Create( "Button", FifthFrame )
        GmodWikiOneFifthFrame:SetSize( 200, 25 )
        GmodWikiOneFifthFrame:SetPos( 1130, 755 )
        GmodWikiOneFifthFrame:SetVisible( true )
        GmodWikiOneFifthFrame:SetText( "Gmod Wiki #1" )
		GmodWikiOneFifthFrame.Paint = function()
			surface.SetDrawColor( 218, 229, 2, 200 )
			surface.DrawRect( 0, 4, GmodWikiOneFifthFrame:GetWide(), GmodWikiOneFifthFrame:GetTall() )
		end
        function GmodWikiOneFifthFrame:OnMousePressed()
			MainFrame:SetVisible( false )
			SecondFrame:SetVisible( false )
			FourthFrame:SetVisible( false )
			FifthFrame:SetVisible( false )
			ThirdFrame:SetVisible( true )
        end
		
	local GmodWikiOneSixthFrame = vgui.Create( "Button", SixthFrame )
        GmodWikiOneSixthFrame:SetSize( 200, 25 )
        GmodWikiOneSixthFrame:SetPos( 1130, 755 )
        GmodWikiOneSixthFrame:SetVisible( true )
        GmodWikiOneSixthFrame:SetText( "Gmod Wiki #1" )
		GmodWikiOneSixthFrame.Paint = function()
			surface.SetDrawColor( 218, 229, 2, 200 )
			surface.DrawRect( 0, 4, GmodWikiOneSixthFrame:GetWide(), GmodWikiOneSixthFrame:GetTall() )
		end
        function GmodWikiOneSixthFrame:OnMousePressed()
			MainFrame:SetVisible( false )
			SecondFrame:SetVisible( false )
			FourthFrame:SetVisible( false )
			FifthFrame:SetVisible( false )
			SixthFrame:SetVisible( false )
			ThirdFrame:SetVisible( true )
        end
		
		// Gmod Wiki 2 Buttons \\
		
	local GmodWikiTwoButtonMainFrame = vgui.Create( "Button", MainFrame )
        GmodWikiTwoButtonMainFrame:SetSize( 200, 25 )
        GmodWikiTwoButtonMainFrame:SetPos( 1130, 785 )
        GmodWikiTwoButtonMainFrame:SetVisible( true )
        GmodWikiTwoButtonMainFrame:SetText( "Gmod Wiki #2" )
		GmodWikiTwoButtonMainFrame.Paint = function()
			surface.SetDrawColor( 218, 229, 2, 200 )
			surface.DrawRect( 0, 4, GmodWikiTwoButtonMainFrame:GetWide(), GmodWikiTwoButtonMainFrame:GetTall() )
		end
        function GmodWikiTwoButtonMainFrame:OnMousePressed()
			MainFrame:SetVisible( false )
			SecondFrame:SetVisible( false )
			ThirdFrame:SetVisible( false )
			FifthFrame:SetVisible( false )
			FourthFrame:SetVisible( true )
        end
		
	local GmodWikiTwoButtonSecondFrame = vgui.Create( "Button", SecondFrame )
        GmodWikiTwoButtonSecondFrame:SetSize( 200, 25 )
        GmodWikiTwoButtonSecondFrame:SetPos( 1130, 785 )
        GmodWikiTwoButtonSecondFrame:SetVisible( true )
        GmodWikiTwoButtonSecondFrame:SetText( "Gmod Wiki #2" )
		GmodWikiTwoButtonSecondFrame.Paint = function()
			surface.SetDrawColor( 218, 229, 2, 200 )
			surface.DrawRect( 0, 4, GmodWikiTwoButtonSecondFrame:GetWide(), GmodWikiTwoButtonSecondFrame:GetTall() )
		end
        function GmodWikiTwoButtonSecondFrame:OnMousePressed()
			MainFrame:SetVisible( false )
			SecondFrame:SetVisible( false )
			ThirdFrame:SetVisible( false )
			FifthFrame:SetVisible( false )
			FourthFrame:SetVisible( true )
        end
		
	local GmodWikiTwoButtonThirdFrame = vgui.Create( "Button", ThirdFrame )
        GmodWikiTwoButtonThirdFrame:SetSize( 200, 25 )
        GmodWikiTwoButtonThirdFrame:SetPos( 1130, 785 )
        GmodWikiTwoButtonThirdFrame:SetVisible( true )
        GmodWikiTwoButtonThirdFrame:SetText( "Gmod Wiki #2" )
		GmodWikiTwoButtonThirdFrame.Paint = function()
			surface.SetDrawColor( 218, 229, 2, 200 )
			surface.DrawRect( 0, 4, GmodWikiTwoButtonThirdFrame:GetWide(), GmodWikiTwoButtonThirdFrame:GetTall() )
		end
        function GmodWikiTwoButtonThirdFrame:OnMousePressed()
			MainFrame:SetVisible( false )
			SecondFrame:SetVisible( false )
			ThirdFrame:SetVisible( false )
			FifthFrame:SetVisible( false )
			FourthFrame:SetVisible( true )
        end
		
	local GmodWikiTwoButtonFourthFrame = vgui.Create( "Button", FourthFrame )
        GmodWikiTwoButtonFourthFrame:SetSize( 200, 25 )
        GmodWikiTwoButtonFourthFrame:SetPos( 1130, 785 )
        GmodWikiTwoButtonFourthFrame:SetVisible( true )
        GmodWikiTwoButtonFourthFrame:SetText( "Gmod Wiki #2" )
		GmodWikiTwoButtonFourthFrame.Paint = function()
			surface.SetDrawColor( 218, 229, 2, 200 )
			surface.DrawRect( 0, 4, GmodWikiTwoButtonFourthFrame:GetWide(), GmodWikiTwoButtonFourthFrame:GetTall() )
		end
        function GmodWikiTwoButtonFourthFrame:OnMousePressed()
			MainFrame:SetVisible( false )
			SecondFrame:SetVisible( false )
			ThirdFrame:SetVisible( false )
			FifthFrame:SetVisible( false )
			FourthFrame:SetVisible( true )
        end
		
	local GmodWikiTwoButtonFifthFrame = vgui.Create( "Button", FifthFrame )
        GmodWikiTwoButtonFifthFrame:SetSize( 200, 25 )
        GmodWikiTwoButtonFifthFrame:SetPos( 1130, 785 )
        GmodWikiTwoButtonFifthFrame:SetVisible( true )
        GmodWikiTwoButtonFifthFrame:SetText( "Gmod Wiki #2" )
		GmodWikiTwoButtonFifthFrame.Paint = function()
			surface.SetDrawColor( 218, 229, 2, 200 )
			surface.DrawRect( 0, 4, GmodWikiTwoButtonFifthFrame:GetWide(), GmodWikiTwoButtonFifthFrame:GetTall() )
		end
        function GmodWikiTwoButtonFifthFrame:OnMousePressed()
			MainFrame:SetVisible( false )
			SecondFrame:SetVisible( false )
			ThirdFrame:SetVisible( false )
			FifthFrame:SetVisible( false )
			FourthFrame:SetVisible( true )
        end
		
	local GmodWikiTwoButtonSixthFrame = vgui.Create( "Button", SixthFrame )
        GmodWikiTwoButtonSixthFrame:SetSize( 200, 25 )
        GmodWikiTwoButtonSixthFrame:SetPos( 1130, 785 )
        GmodWikiTwoButtonSixthFrame:SetVisible( true )
        GmodWikiTwoButtonSixthFrame:SetText( "Gmod Wiki #2" )
		GmodWikiTwoButtonSixthFrame.Paint = function()
			surface.SetDrawColor( 218, 229, 2, 200 )
			surface.DrawRect( 0, 4, GmodWikiTwoButtonSixthFrame:GetWide(), GmodWikiTwoButtonSixthFrame:GetTall() )
		end
        function GmodWikiTwoButtonSixthFrame:OnMousePressed()
			MainFrame:SetVisible( false )
			SecondFrame:SetVisible( false )
			ThirdFrame:SetVisible( false )
			SixthFrame:SetVisible( false )
			FifthFrame:SetVisible( false )
			FourthFrame:SetVisible( true )
        end
		
		// Google Buttons \\
		
	local GoogleButtonMainFrame = vgui.Create( "Button", MainFrame )
        GoogleButtonMainFrame:SetSize( 200, 25 )
        GoogleButtonMainFrame:SetPos( 485, 755 )
        GoogleButtonMainFrame:SetVisible( true )
        GoogleButtonMainFrame:SetText( "Google" )
		GoogleButtonMainFrame.Paint = function()
			surface.SetDrawColor( 218, 229, 2, 200 )
			surface.DrawRect( 0, 4, GoogleButtonMainFrame:GetWide(), GoogleButtonMainFrame:GetTall() )
		end
        function GoogleButtonMainFrame:OnMousePressed()
			MainFrame:SetVisible( false )
			SecondFrame:SetVisible( false )
			ThirdFrame:SetVisible( false )
			FourthFrame:SetVisible( false )
			FifthFrame:SetVisible( true )
        end
		
	local GoogleButtonSecondFrame = vgui.Create( "Button", SecondFrame )
        GoogleButtonSecondFrame:SetSize( 200, 25 )
        GoogleButtonSecondFrame:SetPos( 485, 755 )
        GoogleButtonSecondFrame:SetVisible( true )
        GoogleButtonSecondFrame:SetText( "Google" )
		GoogleButtonSecondFrame.Paint = function()
			surface.SetDrawColor( 218, 229, 2, 200 )
			surface.DrawRect( 0, 4, GoogleButtonSecondFrame:GetWide(), GoogleButtonSecondFrame:GetTall() )
		end
        function GoogleButtonSecondFrame:OnMousePressed()
			MainFrame:SetVisible( false )
			SecondFrame:SetVisible( false )
			ThirdFrame:SetVisible( false )
			FourthFrame:SetVisible( false )
			FifthFrame:SetVisible( true )
        end
		
	local GoogleButtonThirdFrame = vgui.Create( "Button", ThirdFrame )
        GoogleButtonThirdFrame:SetSize( 200, 25 )
        GoogleButtonThirdFrame:SetPos( 485, 755 )
        GoogleButtonThirdFrame:SetVisible( true )
        GoogleButtonThirdFrame:SetText( "Google" )
		GoogleButtonThirdFrame.Paint = function()
			surface.SetDrawColor( 218, 229, 2, 200 )
			surface.DrawRect( 0, 4, GoogleButtonThirdFrame:GetWide(), GoogleButtonThirdFrame:GetTall() )
		end
        function GoogleButtonThirdFrame:OnMousePressed()
			MainFrame:SetVisible( false )
			SecondFrame:SetVisible( false )
			ThirdFrame:SetVisible( false )
			FourthFrame:SetVisible( false )
			FifthFrame:SetVisible( true )
        end
		
	local GoogleButtonFourthFrame = vgui.Create( "Button", FourthFrame )
        GoogleButtonFourthFrame:SetSize( 200, 25 )
        GoogleButtonFourthFrame:SetPos( 485, 755 )
        GoogleButtonFourthFrame:SetVisible( true )
        GoogleButtonFourthFrame:SetText( "Google" )
		GoogleButtonFourthFrame.Paint = function()
			surface.SetDrawColor( 218, 229, 2, 200 )
			surface.DrawRect( 0, 4, GoogleButtonFourthFrame:GetWide(), GoogleButtonFourthFrame:GetTall() )
		end
        function GoogleButtonFourthFrame:OnMousePressed()
			MainFrame:SetVisible( false )
			SecondFrame:SetVisible( false )
			ThirdFrame:SetVisible( false )
			FourthFrame:SetVisible( false )
			FifthFrame:SetVisible( true )
        end
		
	local GoogleButtonFifthFrame = vgui.Create( "Button", FifthFrame )
        GoogleButtonFifthFrame:SetSize( 200, 25 )
        GoogleButtonFifthFrame:SetPos( 485, 755 )
        GoogleButtonFifthFrame:SetVisible( true )
        GoogleButtonFifthFrame:SetText( "Google" )
		GoogleButtonFifthFrame.Paint = function()
			surface.SetDrawColor( 218, 229, 2, 200 )
			surface.DrawRect( 0, 4, GoogleButtonFifthFrame:GetWide(), GoogleButtonFifthFrame:GetTall() )
		end
        function GoogleButtonFifthFrame:OnMousePressed()
			MainFrame:SetVisible( false )
			SecondFrame:SetVisible( false )
			ThirdFrame:SetVisible( false )
			FourthFrame:SetVisible( false )
			FifthFrame:SetVisible( true )
        end
		
	local GoogleButtonSixthFrame = vgui.Create( "Button", SixthFrame )
        GoogleButtonSixthFrame:SetSize( 200, 25 )
        GoogleButtonSixthFrame:SetPos( 485, 755 )
        GoogleButtonSixthFrame:SetVisible( true )
        GoogleButtonSixthFrame:SetText( "Google" )
		GoogleButtonSixthFrame.Paint = function()
			surface.SetDrawColor( 218, 229, 2, 200 )
			surface.DrawRect( 0, 4, GoogleButtonSixthFrame:GetWide(), GoogleButtonSixthFrame:GetTall() )
		end
        function GoogleButtonSixthFrame:OnMousePressed()
			MainFrame:SetVisible( false )
			SecondFrame:SetVisible( false )
			ThirdFrame:SetVisible( false )
			FourthFrame:SetVisible( false )
			SixthFrame:SetVisible( false )
			FifthFrame:SetVisible( true )
        end
		
		// Youtube Buttons \\
		
	local YoutubeButtonMainFrame = vgui.Create( "Button", MainFrame )
        YoutubeButtonMainFrame:SetSize( 200, 25 )
        YoutubeButtonMainFrame:SetPos( 485, 785 )
        YoutubeButtonMainFrame:SetVisible( true )
        YoutubeButtonMainFrame:SetText( "Youtube" )
		YoutubeButtonMainFrame.Paint = function()
			surface.SetDrawColor( 218, 229, 2, 200 )
			surface.DrawRect( 0, 4, YoutubeButtonMainFrame:GetWide(), YoutubeButtonMainFrame:GetTall() )
		end
        function YoutubeButtonMainFrame:OnMousePressed()
			MainFrame:SetVisible( false )
			SecondFrame:SetVisible( false )
			ThirdFrame:SetVisible( false )
			FourthFrame:SetVisible( false )
			FifthFrame:SetVisible( false )
			SixthFrame:SetVisible( true )
        end

	local YoutubeButtonSecondFrame = vgui.Create( "Button", SecondFrame )
        YoutubeButtonSecondFrame:SetSize( 200, 25 )
        YoutubeButtonSecondFrame:SetPos( 485, 785 )
        YoutubeButtonSecondFrame:SetVisible( true )
        YoutubeButtonSecondFrame:SetText( "Youtube" )
		YoutubeButtonSecondFrame.Paint = function()
			surface.SetDrawColor( 218, 229, 2, 200 )
			surface.DrawRect( 0, 4, YoutubeButtonSecondFrame:GetWide(), YoutubeButtonSecondFrame:GetTall() )
		end
        function YoutubeButtonSecondFrame:OnMousePressed()
			MainFrame:SetVisible( false )
			SecondFrame:SetVisible( false )
			ThirdFrame:SetVisible( false )
			FourthFrame:SetVisible( false )
			FifthFrame:SetVisible( false )
			SixthFrame:SetVisible( true )
        end
				
	local YoutubeButtonThirdFrame = vgui.Create( "Button", ThirdFrame )
        YoutubeButtonThirdFrame:SetSize( 200, 25 )
        YoutubeButtonThirdFrame:SetPos( 485, 785 )
        YoutubeButtonThirdFrame:SetVisible( true )
        YoutubeButtonThirdFrame:SetText( "Youtube" )
		YoutubeButtonThirdFrame.Paint = function()
			surface.SetDrawColor( 218, 229, 2, 200 )
			surface.DrawRect( 0, 4, YoutubeButtonThirdFrame:GetWide(), YoutubeButtonThirdFrame:GetTall() )
		end
        function YoutubeButtonThirdFrame:OnMousePressed()
			MainFrame:SetVisible( false )
			SecondFrame:SetVisible( false )
			ThirdFrame:SetVisible( false )
			FourthFrame:SetVisible( false )
			FifthFrame:SetVisible( false )
			SixthFrame:SetVisible( true )
        end
		
	local YoutubeButtonFourthFrame = vgui.Create( "Button", FourthFrame )
        YoutubeButtonFourthFrame:SetSize( 200, 25 )
        YoutubeButtonFourthFrame:SetPos( 485, 785 )
        YoutubeButtonFourthFrame:SetVisible( true )
        YoutubeButtonFourthFrame:SetText( "Youtube" )
		YoutubeButtonFourthFrame.Paint = function()
			surface.SetDrawColor( 218, 229, 2, 200 )
			surface.DrawRect( 0, 4, YoutubeButtonFourthFrame:GetWide(), YoutubeButtonFourthFrame:GetTall() )
		end
        function YoutubeButtonFourthFrame:OnMousePressed()
			MainFrame:SetVisible( false )
			SecondFrame:SetVisible( false )
			ThirdFrame:SetVisible( false )
			FourthFrame:SetVisible( false )
			FifthFrame:SetVisible( false )
			SixthFrame:SetVisible( true )
        end
		
	local YoutubeButtonFifthFrame = vgui.Create( "Button", FifthFrame )
        YoutubeButtonFifthFrame:SetSize( 200, 25 )
        YoutubeButtonFifthFrame:SetPos( 485, 785 )
        YoutubeButtonFifthFrame:SetVisible( true )
        YoutubeButtonFifthFrame:SetText( "Youtube" )
		YoutubeButtonFifthFrame.Paint = function()
			surface.SetDrawColor( 218, 229, 2, 200 )
			surface.DrawRect( 0, 4, YoutubeButtonFifthFrame:GetWide(), YoutubeButtonFifthFrame:GetTall() )
		end
        function YoutubeButtonFifthFrame:OnMousePressed()
			MainFrame:SetVisible( false )
			SecondFrame:SetVisible( false )
			ThirdFrame:SetVisible( false )
			FourthFrame:SetVisible( false )
			FifthFrame:SetVisible( false )
			SixthFrame:SetVisible( true )
        end
				
	local YoutubeButtonSixthFrame = vgui.Create( "Button", SixthFrame )
        YoutubeButtonSixthFrame:SetSize( 200, 25 )
        YoutubeButtonSixthFrame:SetPos( 485, 785 )
        YoutubeButtonSixthFrame:SetVisible( true )
        YoutubeButtonSixthFrame:SetText( "Youtube" )
		YoutubeButtonSixthFrame.Paint = function()
			surface.SetDrawColor( 218, 229, 2, 200 )
			surface.DrawRect( 0, 4, YoutubeButtonSixthFrame:GetWide(), YoutubeButtonSixthFrame:GetTall() )
		end
        function YoutubeButtonSixthFrame:OnMousePressed()
			MainFrame:SetVisible( false )
			SecondFrame:SetVisible( false )
			ThirdFrame:SetVisible( false )
			FourthFrame:SetVisible( false )
			FifthFrame:SetVisible( false )
			SixthFrame:SetVisible( true )
        end
		
		// Main Menu Stuff \\
		
	local BhopCheckBoxMainFrame = vgui.Create( "DCheckBoxLabel", MainFrame )
		BhopCheckBoxMainFrame:SetPos( 70, 60 )
		BhopCheckBoxMainFrame:SetText( "Bhop Toggle" )
		BhopCheckBoxMainFrame:SetConVar( "B-Hacks_Bhop" )
		BhopCheckBoxMainFrame:SetValue( 1 )
		BhopCheckBoxMainFrame:SizeToContents()
		
	local PlayerStats = vgui.Create("DListView", SecondFrame)
		PlayerStats:SetSize(1640, 695)
		PlayerStats:SetPos(130, 45)
		PlayerStats:SetMultiSelect(false)
		PlayerStats:AddColumn("Name")
		PlayerStats:AddColumn("SteamID")
		PlayerStats:AddColumn("Money")
		PlayerStats:AddColumn("Health")
		PlayerStats:AddColumn("Friend")
		PlayerStats:AddColumn("Is Admin")
		PlayerStats:AddColumn("Is SuperAdmin")
		PlayerStats.Paint = function()
			surface.SetDrawColor( 120, 120, 120, 250 )
			surface.DrawRect( 0, 0, PlayerStats:GetWide(), PlayerStats:GetTall() )
		end

	for k,v in pairs(player.GetAll()) do
		PlayerStats:AddLine(v:Nick(), v:SteamID(), v:Health(), v:GetFriendStatus(), v:IsAdmin(), v:IsSuperAdmin()) -- Add lines
	end
	
	GmodWikiOne = vgui.Create( "HTML", ThirdFrame )
	GmodWikiOne:SetPos( 130,45 )
	GmodWikiOne:SetSize( 1640, 695 )
	GmodWikiOne:OpenURL( "http://wiki.garrysmod.com" )
	
	GmodWikiTwo = vgui.Create( "HTML", FourthFrame )
	GmodWikiTwo:SetPos( 130,45 )
	GmodWikiTwo:SetSize( 1640, 695 )
	GmodWikiTwo:OpenURL( "http://maurits.tv/data/garrysmod/wiki/wiki.garrysmod.com/index4875.html" )
	
	
	Google = vgui.Create( "HTML", FifthFrame )
	Google:SetPos( 130,45 )
	Google:SetSize( 1640, 695 )
	Google:OpenURL( "http://Google.com" )
	
	Youtube = vgui.Create( "HTML", SixthFrame )
	Youtube:SetPos( 130,45 )
	Youtube:SetSize( 1640, 695 )
	Youtube:OpenURL( "http://Youtube.com" )
	
end
concommand.Add("OpenMainMenu", MainMenu)

local xray = CreateClientConVar ("xray", 0, true, false)
local function test()
for k, v in pairs (ents.FindByClass("prop_physics") ) do
if (GetConVarNumber("xray") == 1) then
v:SetMaterial("mat1")
else v:SetMaterial(self)
end
end
end
hook.Add("Think", "meh", test)