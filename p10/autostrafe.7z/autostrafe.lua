 
 
                    local bhop = { };
                    bhop.MetaPlayer = FindMetaTable( "Player")
                    bhop.oldKeyDown = bhop.MetaPlayer['KeyDown']
                    local bhopOn = true;
                    local bhopSOn = true;
                    local bhopHooks = { hook = { }, name = { } };
                    bhop.left = false
                    bhop.right = false
                    bhop.jump = false
                    bhop.what = true
                    function bhop.AddHook(hookname, name, func)
                            table.insert( bhopHooks.hook, hookname );
                            table.insert( bhopHooks.name, name );
                            hook.Add( hookname, name, func );
                    end
                    bhop.MetaPlayer['KeyDown'] = function( self, key )
                    if self != LocalPlayer() then return end
                        if (key == IN_MOVELEFT) and bhop.left then
                            return true
                        elseif (key == IN_MOVERIGHT) and bhop.right then
                            return true
                        elseif (key == IN_JUMP) and bhop.jump then
                            return true
                        else
                            return bhop.oldKeyDown( self, key )
                        end
                    end
 
                    function bhop.spamjump()
                            bhop.what = false
                            bhop.jump = true
                            timer.Simple(.05, function()
                                bhop.jump = false
                                timer.Simple( .25, function()
                                    bhop.what = true
                                end)
                            end)
                    end
 
     
        local oldEyePos = LocalPlayer():EyeAngles()--This is to see where player is looking
        function bhop.CreateMove( cmd )
                        local JumpReleased = false;
                if (cmd:KeyDown( IN_JUMP )) then
 
                        if (!JumpReleased) then
                                if (bhopOn && !LocalPlayer():OnGround()) then --Bhop here
                                        cmd:RemoveKey( IN_JUMP );
                                        if bhop.what then
                                            bhop.spamjump()
                                        end
                                end
                        else
                                JumpReleased = false
                        end
                                       
                                if(bhopSOn ) then--auto strafer
                                        local traceRes = LocalPlayer():EyeAngles()
                               
                                        if( traceRes.y > oldEyePos.y ) then --If you move your mouse left, walk left, if you're jumping
                                                oldEyePos = traceRes;
                                                cmd:SetSideMove( -1000000 )
                                                bhop.left = true
                                                timer.Simple(1, function() bhop.left = false end)
                                        end
         
                                        if( oldEyePos.y > traceRes.y )  then --If you move your mouse right, move right,  while jumping
                                                oldEyePos = traceRes;
                                                cmd:SetSideMove( 1000000 )
                                                bhop.right = true
                                                timer.Simple(1, function() bhop.right = false end)
                                        end
                                end
                elseif (!JumpReleased) then
                        JumpReleased = true;
                end
         
        end
           
        bhop.AddHook( "CreateMove", tostring(math.random(0, 133712837)), bhop.CreateMove )--add the hook
            concommand.Add( "bhop", function () --Toggler
                    if bhopOn then
                            print("Bhop off")
                            bhopOn = false;
                    else
                            print("Bhop on")
                            bhopOn = true;
                    end
            end )
            concommand.Add( "bhop_strafe",  function ()
                    if bhopSOn then
                            print("Strafe off")
                            bhopSOn = false;
                    else
                            print("Strafe on")
                            bhopSOn = true;
                    end
            end)
            concommand.Add("bhop_unload", function()
                for i = 1, #bhopHooks.hook do
                hook.Remove( bhopHooks.hook[i], bhopHooks.name[i] );
                print( "Unhooked "..bhopHooks.hook[i].." using name "..bhopHooks.name[i] );
            end
                    concommand.Remove("bhop_strafe")
                    concommand.Remove("bhop")
                    bhopOn = false;
                    bhopSOn = false;
                    print("Bhop unloaded")
                    table.Empty( bhopHooks )
                    concommand.Remove( "bhop_unload" )
            end)
           
        print("Bhop loaded\nMade by LordOfGears, enjoy. \nLeave feedback, please\n\n\n")