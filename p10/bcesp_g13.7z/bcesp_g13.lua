--[[
Name: BCESP.lua
Product: BloodyChef Client Scripts
Author: Eusion (STEAM_0:0:20450406)
]]--

local BCESPToggle = CreateClientConVar("bc_esp", 1, true, false)
local BCESPPlayers = CreateClientConVar("bc_esp_players", 1, true, false)
local BCESPHCircle = CreateClientConVar("bc_esp_hcircle", 1, true, false)
local BCESPName = CreateClientConVar("bc_esp_name", 1, true, false)
local BCESPHealth = CreateClientConVar("bc_esp_health", 1, true, false)
local BCESPAdmin = CreateClientConVar("bc_esp_admin", 1, true, false)
local BCESPWeapon = CreateClientConVar("bc_esp_weapon", 1, true, false)
local BCESPDistance = CreateClientConVar("bc_esp_distance", 1, true, false)
local BCESPVelocity = CreateClientConVar("bc_esp_velocity", 0, true, false)
local BCESPMoney = CreateClientConVar("bc_esp_money", 0, true, false)
local BCESPLine = CreateClientConVar("bc_esp_line", 0, true, false)
local BCESPWH = CreateClientConVar("bc_esp_wh", 0, true, false)
local BCESPTTT = CreateClientConVar("bc_esp_ttt", 1, true, false)
local BCESPLook = CreateClientConVar("bc_esp_look", 0, true, false)
local BCESPEnts = CreateClientConVar("bc_esp_ents", 1, true, false)
local BCESPVehicle = CreateClientConVar("bc_esp_vehicle", 1, true, false)
local BCESPBone = CreateClientConVar("bc_esp_bone", "ValveBiped.Bip01_R_Foot", true, false)
local BCESPFont = CreateClientConVar("bc_esp_font", "DefaultSmall", true, false)
local BCESPEntities = CreateClientConVar("bc_esp_entities", "", true, false)

local TWeps = {
	"weapon_ttt_c4",
	"weapon_ttt_sipistol",
	"weapon_ttt_flaregun",
	"weapon_ttt_phammer",
	"weapon_ttt_knife"
}

local TData = {}

local LookingAt = ""

--Efficiency improvements.
local pairs = pairs
local ValidEntity = ValidEntity
local LocalPlayer = LocalPlayer
local GetPos = GetPos
local GetBonePosition = GetBonePosition
local LookupBone = LookupBone
local IsPlayer = IsPlayer
local GetInt = GetInt
local GetString = GetString
local GetBonePosition = GetBonePosition
local draw = draw
local surface = surface
local render = render
local math = math
local GetClass = GetClass
local DynamicLight = DynamicLight

local ptable = {}
local etable = {}

hook.Remove("Think", "BCESP")
hook.Remove("HUDPaint", "BCESP")

local function GetBone(ent, bone)
	return ent:GetBonePosition(ent:LookupBone(bone))
end

local function Visible(ent)
	if not ValidEntity(ent) then return end
	if not ent:IsPlayer() then return end
	local tracedata = {}
	tracedata.start = GetBone(LocalPlayer(), "ValveBiped.Bip01_Head1")
	tracedata.endpos = GetBone(ent, "ValveBiped.Bip01_Head1")
	tracedata.filter = LocalPlayer()
	local trace = util.TraceLine(tracedata)
	if trace.Entity:IsPlayer() then
		return true
	else
		return false
	end
end

local function GetAdmin(ply)
	if ASS_Initialized == nil and ply:GetNWString("UserGroup") == "" then
		if ply:IsAdmin() and not ply:IsSuperAdmin() then
			return "Admin"
		elseif ply:IsSuperAdmin() then
			return "Super Admin"
		elseif not ply:IsAdmin() and not ply:IsSuperAdmin() then
			return "Player"
		end
	end
	local usergroup = string.lower(ply:GetNWString("UserGroup"))
	if usergroup ~= "" then
		return string.gsub(usergroup, string.sub(usergroup, 1, 1), string.upper(string.sub(usergroup, 1, 1)))
	end
	if ASS_Initialized ~= nil and LevelToString ~= nil then
		return LevelToString(ply:GetNWInt("ASS_isAdmin"))
	end
end

hook.Add("Think", "BCESP", function()
	if BCESPToggle:GetInt() == 1 then
		ptable = {}
		etable = {}
		LookingAt = ""
		for k, v in pairs(ents.GetAll()) do
			if BCESPPlayers:GetInt() == 1 and ValidEntity(v) and v:IsPlayer() and v ~= LocalPlayer() and v:GetActiveWeapon():IsValid() then
				local ply = {}
				ply.data = {}
				if BCESPName:GetInt() == 1 then
					table.insert(ply.data, "\n" .. v:Name())
				end
				if BCESPHealth:GetInt() == 1 then
					table.insert(ply.data, "\nHP: " .. v:Health())
				end
				if BCESPDistance:GetInt() == 1 then
					table.insert(ply.data, "\nDistance: " .. math.Round(v:GetPos():Distance(LocalPlayer():GetPos()) / 25.4) .. "m")
				end
				local velocity = math.floor(v:GetVelocity():Length())
				if BCESPVelocity:GetInt() == 1 and velocity > 0 then
					table.insert(ply.data, "\nVelocity: " .. velocity)
				end
				if BCESPMoney:GetInt() == 1 then
					if v.DarkRPVars and v.DarkRPVars.money then
						--New DarkRP variable system.
						table.insert(ply.data, "\n$" .. v.DarkRPVars.money)
					else
						--Old DarkRP network variable system.
						table.insert(ply.data, "\n$" .. v:GetNWInt("money"))
					end
				end
				if BCESPWeapon:GetInt() == 1 then
					table.insert(ply.data, "\n" .. v:GetActiveWeapon():GetPrintName())
				end
				if BCESPAdmin:GetInt() == 1 then
					table.insert(ply.data, "\n" .. GetAdmin(v))
				end
				if BCESPLine:GetInt() == 1 then
					ply.SubName = string.sub(v:Name(), 1, 7)
					ply.HitPos = v:GetEyeTrace().HitPos:ToScreen()
					ply.HitPosV = v:GetEyeTrace().HitPos
					ply.HPosV = GetBone(v, "ValveBiped.Bip01_Head1")
					local dlight = DynamicLight(v:EntIndex())
					if (dlight) then
						dlight.Pos = v:GetEyeTrace().HitPos
						dlight.r = 255
						dlight.g = 0
						dlight.b = 0
						dlight.Brightness = 7.5
						dlight.Size = 20
						dlight.Decay = 20 * 5
						dlight.DieTime = CurTime() + 1
					end
				end
				if Visible(v) then
					ply.Visible = true
				else
					ply.Visible = false
				end
				if BCESPVehicle:GetInt() == 1 then
					if v:InVehicle() then
						ply.Vehicle = true
					else
						ply.Vehicle = false
					end
				end
				if BCESPTTT:GetInt() == 1 then
					if table.HasValue(TWeps, v:GetActiveWeapon():GetClass()) then
						TData[v] = {["lastused"] = CurTime(), ["class"] = v:GetActiveWeapon():GetClass()}
					end
					if TData[v] then --Data exists for potential traitor.
						table.insert(ply.data, "\nPotential Traitor\nUsed: " .. TData[v].class .. " (" .. math.Round((CurTime()-TData[v].lastused)) .. ")")
						if GAMEMODE.round_state == ROUND_POST then
							TData = {}
						end
					end
				end
				if BCESPLook:GetInt() == 1 then
					if v:GetEyeTrace().Entity == LocalPlayer() then
						LookingAt = LookingAt .. "\n" .. v:Name()
					end
				end
				ply.HPos = GetBone(v, "ValveBiped.Bip01_Head1"):ToScreen()
				ply.Pos = GetBone(v, BCESPBone:GetString()):ToScreen()
				ply.PPos = v:GetPos()
				ply.Ent = v
				ply.Col = team.GetColor(v:Team())
				table.insert(ptable, ply)
			end
			if BCESPEnts:GetInt() == 1 and ValidEntity(v) and table.HasValue(string.Explode(" ", BCESPEntities:GetString()), v:GetClass()) then
				local EntTable = {}
				EntTable.Pos = v:GetPos():ToScreen()
				EntTable.Class = v:GetClass()
				EntTable.Distance = math.Round(tostring(v:GetPos():Distance(LocalPlayer():GetShootPos())))
				table.insert(etable, EntTable)
				local dlight = DynamicLight(v:EntIndex())
				if (dlight) then
					dlight.Pos = v:GetPos()
					dlight.r = 255
					dlight.g = 255
					dlight.b = 255
					dlight.Brightness = 10
					dlight.Size = 40
					dlight.Decay = 40 * 5
					dlight.DieTime = CurTime() + 1
				end
			end
		end
	end
end)

hook.Add("HUDPaint", "BCESP", function()
	if BCESPToggle:GetInt() == 1 then
		if BCESPPlayers:GetInt() == 1 then
			for k, v in pairs(ptable) do
				draw.DrawText(string.Implode("", v.data), BCESPFont:GetString(), v.Pos.x, v.Pos.y, Color(255,255,255,255),1)
				if BCESPHCircle:GetInt() == 1 and not v.Vehicle then
					draw.RoundedBox(1, v.HPos.x, v.HPos.y, 5, 5, Color(v.Col.r,v.Col.g,v.Col.b,255))
				end
				cam.Start3D(EyePos(), EyeAngles())
					if BCESPLine:GetInt() == 1 and v.Visible then
						render.SetMaterial(Material("cable/redlaser"))
						render.DrawBeam(v.HPosV, v.HitPosV, 2.5, 0, 0, Color(v.Col.r, v.Col.g, v.Col.b, 255))
					end
					if BCESPWH:GetInt() == 1 and (not v.Visible) and ValidEntity(v.Ent) then
						v.Ent:DrawModel()
					end
				cam.End3D()
				if BCESPLine:GetInt() == 1 and v.Visible then
					draw.DrawText(v.SubName .. "\n" .. math.Round(v.PPos:Distance(LocalPlayer():GetPos())), BCESPFont:GetString(), v.HitPos.x, v.HitPos.y, Color(255,255,255,255),1)
				end
				if BCESPVehicle:GetInt() == 1 and v.Vehicle then
					local QuadTable = {}
					QuadTable.texture = surface.GetTextureID("gui/silkicons/car")
					QuadTable.color = Color(255, 255, 255, 255)
					QuadTable.x = v.HPos.x
					QuadTable.y = v.HPos.y
					QuadTable.w = 15
					QuadTable.h = 15
					draw.TexturedQuad(QuadTable)
				end
				if BCESPLook:GetInt() == 1 then
					draw.DrawText(LookingAt, BCESPFont:GetString(), 1, 1, Color(255,255,255,255),0)
				end
			end
		end
		if BCESPEnts:GetInt() == 1 then
			for k, v in pairs(etable) do
				draw.RoundedBox(1, v.Pos.x - 2, v.Pos.y - 3, 5, 5, Color(255,255,255,255))
				draw.DrawText(v.Class .. "\n" .. v.Distance, BCESPFont:GetString(), v.Pos.x, v.Pos.y, Color(255,255,255,255),1)
			end
		end
	end
end)

concommand.Add("bc_esp_remove", function()
	hook.Remove("HUDPaint", "BCESP")
	hook.Remove("Think", "BCESP")
end)

local function AddEntity(ply, cmd, args)
	local entity = tostring(args[1])
	
	local entities = string.Explode(" ", BCESPEntities:GetString())
	local previousdata = string.Implode(" ", entities)
	
	RunConsoleCommand("bc_esp_entities", previousdata .. " " .. entity)
end
concommand.Add("bc_esp_addentity", AddEntity)

local function RemoveEntity(ply, cmd, args)
	local entity = tostring(args[1])
	
	local entities = string.Explode(" ", BCESPEntities:GetString())
	local previousdata = string.Implode(" ", entities)
	local newdata = string.Replace(previousdata, " " .. entity, "")
	
	RunConsoleCommand("bc_esp_entities", newdata)
end
concommand.Add("bc_esp_removeentity", RemoveEntity)

local function BCESPOptions()
	local BCESPFrame = vgui.Create("DFrame")
	BCESPFrame:SetSize(200,600)
	BCESPFrame:Center()
	BCESPFrame:SetTitle("BCESP Options Menu")
	BCESPFrame:MakePopup()
	
	local DermaList = vgui.Create("DPanelList", BCESPFrame)
	DermaList:SetPos(15,30)
	DermaList:SetSize(170, 560)
	DermaList:SetSpacing(5)
	DermaList:EnableHorizontal(false)
	DermaList:EnableVerticalScrollbar(true)
	
	local BCESPActivate = vgui.Create("DCheckBoxLabel")
	BCESPActivate:SetText("ESP Activate")
	BCESPActivate:SetConVar("bc_esp")
	DermaList:AddItem(BCESPActivate)
	
	local BCESPPlayers = vgui.Create("DCheckBoxLabel")
	BCESPPlayers:SetText("Show players")
	BCESPPlayers:SetConVar("bc_esp_players")
	DermaList:AddItem(BCESPPlayers)
	
	local BCESPNames = vgui.Create("DCheckBoxLabel")
	BCESPNames:SetText("Show player names")
	BCESPNames:SetConVar("bc_esp_name")
	DermaList:AddItem(BCESPNames)
	
	local BCESPHealth = vgui.Create("DCheckBoxLabel")
	BCESPHealth:SetText("Show player health")
	BCESPHealth:SetConVar("bc_esp_health")
	DermaList:AddItem(BCESPHealth)
	
	local BCESPRank = vgui.Create("DCheckBoxLabel")
	BCESPRank:SetText("Show player rank")
	BCESPRank:SetConVar("bc_esp_admin")
	DermaList:AddItem(BCESPRank)
	
	local BCESPWeapon = vgui.Create("DCheckBoxLabel")
	BCESPWeapon:SetText("Show player weapon")
	BCESPWeapon:SetConVar("bc_esp_weapon")
	DermaList:AddItem(BCESPWeapon)
	
	local BCESPDistance = vgui.Create("DCheckBoxLabel")
	BCESPDistance:SetText("Show player distance")
	BCESPDistance:SetConVar("bc_esp_distance")
	DermaList:AddItem(BCESPDistance)
	
	local BCESPVelocity = vgui.Create("DCheckBoxLabel")
	BCESPVelocity:SetText("Show player velocity")
	BCESPVelocity:SetConVar("bc_esp_velocity")
	DermaList:AddItem(BCESPVelocity)
	
	local BCESPMoney = vgui.Create("DCheckBoxLabel")
	BCESPMoney:SetText("Show player money (DarkRP)")
	BCESPMoney:SetConVar("bc_esp_money")
	DermaList:AddItem(BCESPMoney)
	
	local BCESPHCircle = vgui.Create("DCheckBoxLabel")
	BCESPHCircle:SetText("Show player headpos circle")
	BCESPHCircle:SetConVar("bc_esp_hcircle")
	DermaList:AddItem(BCESPHCircle)
	
	local BCESPAim = vgui.Create("DCheckBoxLabel")
	BCESPAim:SetText("Show player aim line")
	BCESPAim:SetConVar("bc_esp_line")
	DermaList:AddItem(BCESPAim)
	
	local BCESPWall = vgui.Create("DCheckBoxLabel")
	BCESPWall:SetText("Enable player wallhack")
	BCESPWall:SetConVar("bc_esp_wh")
	DermaList:AddItem(BCESPWall)
	
	local BCESPEnt = vgui.Create("DCheckBoxLabel")
	BCESPEnt:SetText("Show entities")
	BCESPEnt:SetConVar("bc_esp_ents")
	DermaList:AddItem(BCESPEnt)
	
	local BCESPVehicles = vgui.Create("DCheckBoxLabel")
	BCESPVehicles:SetText("Show vehicles")
	BCESPVehicles:SetConVar("bc_esp_vehicle")
	DermaList:AddItem(BCESPVehicles)
	
	local BCESPList1 = vgui.Create("DListView")
	BCESPList1:SetSize(170,100)
	BCESPList1:SetMultiSelect(false)
	BCESPList1:AddColumn("Show the following entities")
	for k,v in pairs(string.Explode(" ", BCESPEntities:GetString())) do
		BCESPList1:AddLine(v)
	end
	BCESPList1.OnClickLine = function(parent, line, isselected)
		LocalPlayer():ConCommand("bc_esp_removeentity " .. line:GetValue(1))
	end
	DermaList:AddItem(BCESPList1)
	
	local BCESPButton1 = vgui.Create("DButton")
	BCESPButton1:SetText("Add Entity")
	BCESPButton1.DoClick = function(button)
		Derma_StringRequest("Add an entity to BCESP", "Please use the entity class name.", "e.g. money_printer", function(text) LocalPlayer():ConCommand("bc_esp_addentity " .. text) end)
	end
	DermaList:AddItem(BCESPButton1)
	
	local BCESPButton2 = vgui.Create("DButton")
	BCESPButton2:SetText("Add Entity you are looking at")
	BCESPButton2.DoClick = function(button)
		LocalPlayer():ConCommand("bc_esp_addentity " .. LocalPlayer():GetEyeTrace().Entity:GetClass())
	end
	DermaList:AddItem(BCESPButton2)
	
	local BCESPInfo = vgui.Create("DLabel")
	BCESPInfo:SetText("BCESP Version 2.4\nEusion (STEAM_0:0:20450406)")
	BCESPInfo:SizeToContents()
	DermaList:AddItem(BCESPInfo)
end
concommand.Add("bc_esp_options", BCESPOptions)