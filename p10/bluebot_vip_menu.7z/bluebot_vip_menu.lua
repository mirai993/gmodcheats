--[[
	lua/bvip_cl_init.lua
	VACUBANU | (STEAM_0:0:49821628)
	===DStream===
]]

if (!CLIENT) then return end

local time = os.time()
local expires = 0
local localBVIP
local OriginalLocalPlayer = LocalPlayer
local BVIPs = {[1]=1}
local BVIPExpire = {[1]=1}
local saved
//Globals
BVIP = -1

local function openVIPMenu()
	if (localBVIP == -1 or !localBVIP) then return end
	--Keep them from opening the menu in case they open it before the net message.
	local Frame = vgui.Create( "DFrame" )
	Frame:SetSize( 500, 300 )
	Frame:Center()
	Frame:SetTitle( "VIP menu" )
	Frame:SetVisible( true )
	Frame:SetDraggable( false )
	Frame:ShowCloseButton( true )
	Frame:MakePopup()
	
	if (localBVIP) then
		surface.SetFont( "Trebuchet36" )
		local textWidth = surface.GetTextSize( "This menu is under construction." )
		label = vgui.Create( "DLabel", Frame )
		label:SetPos( (Frame:GetWide()/2) - (textWidth/2), Frame:GetTall() / 2 - 18 )
		label:SetFont( "Trebuchet36" )
		label:SetText( "This menu is under construction." )
		label:SizeToContents()
		
		surface.SetFont( "Trebuchet18" )
		textWidth = surface.GetTextSize( "Your VIP expires on ".. os.date( "%c", expires ) )
		label = vgui.Create( "DLabel", Frame )
		label:SetPos( (Frame:GetWide()/2) - (textWidth/2), Frame:GetTall() - 20 )
		label:SetFont( "Trebuchet18" )
		label:SetText( "Your VIP expires on ".. os.date( "%c", expires ) )
		label:SizeToContents()
	end
end

local function openAdminMenu()
	if (!OriginalLocalPlayer():IsSuperAdmin()) then return end

	local Frame = vgui.Create( "DFrame" )
	Frame:SetSize( 500, 300 )
	Frame:Center()
	Frame:SetTitle( "Admin Menu" )
	Frame:SetVisible( true )
	Frame:SetDraggable( false )
	Frame:ShowCloseButton( true )
	Frame:MakePopup()
	
	local homePanel = vgui.Create( "DPanel", Frame )
	homePanel:SetSize( Frame:GetWide(), Frame:GetTall() - 25 )
	homePanel:SetPos(0, 25 )
	homePanel:SetVisible( true )
	homePanel.Paint = function() end
	
	local playerListPanel = vgui.Create( "DPanel", Frame )
	playerListPanel:SetSize( Frame:GetWide(), Frame:GetTall() - 25 )
	playerListPanel:SetPos(0, 25 )
	playerListPanel:SetVisible( false )
	playerListPanel.Paint = function() end
	
	local playerEditPanel = vgui.Create( "DPanel", Frame )
	playerEditPanel:SetSize( Frame:GetWide(), Frame:GetTall() - 25 )
	playerEditPanel:SetPos(0, 25 )
	playerEditPanel:SetVisible( false )
	playerEditPanel.Paint = function() end
	
	local fullVIPListPanel = vgui.Create( "DPanel", Frame )
	fullVIPListPanel:SetSize( Frame:GetWide(), Frame:GetTall() - 25 )
	fullVIPListPanel:SetPos(0, 25 )
	fullVIPListPanel:SetVisible( false )
	fullVIPListPanel.Paint = function() end
	
	local addVIPPanel = vgui.Create( "DPanel", Frame )
	addVIPPanel:SetSize( Frame:GetWide(), Frame:GetTall() - 25 )
	addVIPPanel:SetPos(0, 25 )
	addVIPPanel:SetVisible( false )
	addVIPPanel.Paint = function() end
	
	local List = vgui.Create( "DPanelList", playerListPanel )
	List:SetPos( 20, 55 )
	List:SetSize( 460, 200 )
	List:SetSpacing( 2 )
	List:EnableVerticalScrollbar( true )
	List.Paint = function()
		surface.SetDrawColor( 0, 0, 0, 50 )
		surface.DrawRect( 0,  0, List:GetWide(), List:GetTall() )
		surface.SetDrawColor( 0, 0, 0, 100 )
		surface.DrawOutlinedRect( 0,  0, List:GetWide(), List:GetTall() )
	end
	
	local labelName = vgui.Create( "DLabel", playerEditPanel )
	labelName:SetPos( 25, 25 )
	labelName:SetFont( "DermaDefaultBold" )
	
	local labelSteamID = vgui.Create( "DLabel", playerEditPanel )
	labelSteamID:SetPos( 25, 40 )
	
	local label = vgui.Create( "DLabel", playerEditPanel )
	label:SetPos( 25, 62 )
	label:SetText( "VIP Level" )
	label:SizeToContents()
	
	label = vgui.Create( "DLabel", playerEditPanel )
	label:SetPos( 26, 102 )
	label:SetText( "Expiration (Hours)" )
	label:SizeToContents()

	label = vgui.Create( "DLabel", playerEditPanel )
	label:SetPos( 27, 142 )
	label:SetText( "Never = -1" )
	label:SizeToContents()
	
	label = vgui.Create( "DLabel", playerEditPanel )
	label:SetPos( 27, 180 )
	label:SetText( "Saving..." )
	label:SizeToContents()
	label:SetVisible( false )
	
	local savingLabel = vgui.Create( "DLabel", playerEditPanel )
	savingLabel:SetPos( 27, 142 )
	savingLabel:SetText( "Never = -1" )
	savingLabel:SizeToContents()
	
	local vipTextBox = vgui.Create( "DTextEntry", playerEditPanel )
	vipTextBox:SetPos( 25, 80 )
	vipTextBox:SetSize( 82, 18 )
	
	local expireTextBox = vgui.Create( "DTextEntry", playerEditPanel )
	expireTextBox:SetPos( 25, 120 )
	expireTextBox:SetSize( 82, 18 )
	
	local button = vgui.Create("DButton", playerEditPanel)
	button:SetText( "Save" )
	button:SetSize( 82, 18 )
	button:SetPos( 25, 160 )
	button.DoClick = function ( btn )
		if (saved == "w") then return end
		
		saved = "w"
		label:SetText( "Saving..." )
		label:SizeToContents()
		label:SetVisible( true )
		
		net.Start( "BVIP.UpdateVIP" )
			net.WriteString( labelName:GetValue() )
			net.WriteString( labelSteamID:GetValue() )
			net.WriteString( vipTextBox:GetValue() )
			net.WriteString( expireTextBox:GetValue() )
		net.SendToServer()
		
		timer.Create( "BVIP.CheckSave", 0.25, 16,
			function() 
				if (saved != "w") then
					label:SetText( saved )
				label:SizeToContents()
				label:SetVisible( true )
					timer.Destroy( "BVIP.CheckSave" )
					return
				end
			end
		)
	end
	
	local backButton = vgui.Create("DButton", playerEditPanel)
	backButton:SetText( "Back" )
	backButton:SetSize( 50, 20 )
	backButton:SetPos( Frame:GetWide() - backButton:GetWide() - 20, 25 )
	backButton.DoClick = function ( btn )
		if (playerEditPanel:IsVisible()) then
			playerEditPanel:SetVisible( false )
			playerListPanel:SetVisible( true )
			backButton:SetParent( playerListPanel )
		else
			homePanel:SetVisible( true )
			playerListPanel:SetVisible( false )
			fullVIPListPanel:SetVisible( false )
			addVIPPanel:SetVisible( false )
		end
	end
	
	button = vgui.Create("DButton", homePanel)
	button:SetText( "Current Players" )
	button:SetSize( 420, 20 )
	button:SetPos( 40, 25 )
	button.DoClick = function ( btn )
		backButton:SetParent( playerListPanel )
		homePanel:SetVisible( false )
		playerListPanel:SetVisible( true )
	end
	
	button = vgui.Create("DButton", homePanel)
	button:SetText( "All VIPs" )
	button:SetSize( 420, 20 )
	button:SetPos( 40, 55 )
	button.DoClick = function ( btn )
		backButton:SetParent( fullVIPListPanel )
		homePanel:SetVisible( false )
		fullVIPListPanel:SetVisible( true )
	end
	
	button = vgui.Create("DButton", homePanel)
	button:SetText( "Add VIP" )
	button:SetSize( 420, 20 )
	button:SetPos( 40, 85 )
	button.DoClick = function ( btn )
		backButton:SetParent( addVIPPanel )
		homePanel:SetVisible( false )
		addVIPPanel:SetVisible( true )
	end
	
	for _, ply in pairs(player.GetAll()) do
		local vip = tostring( BVIPs[ply:EntIndex()] )
		local expire  = tostring ( BVIPExpire[ply:EntIndex()] )
		local name = ply:Nick()
		local steamID = ply:SteamID()
		
		button = vgui.Create("DButton", playerListPanel)
		button:SetText( ply:Nick() )
		button:SetPos(25, 50)
		button:SetSize( 150, 20 )
		button.DoClick = function ( btn )
		
			surface.SetFont( "DermaDefaultBold" )
			
			labelName:SetText( name )
			labelName:SizeToContents()
			
			labelSteamID:SetText( steamID )
			labelSteamID:SizeToContents()
			
			playerListPanel:SetVisible( false )
			
			playerEditPanel:SetVisible( true )
			
			backButton:SetParent( playerEditPanel )
			
			vipTextBox:SetText( vip )
			
			expireTextBox:SetText( expire == "1" and "Never" or expire )
		end
		List:AddItem(button)
	end
end

openAdminMenu()

local function showExpireMenu(timeLeft)
	if (localBVIP == -1) then return end
	--Yes I did copy directly from the wiki
	local Frame = vgui.Create( "DFrame" )
	Frame:SetSize( 500, 300 )
	Frame:Center()
	Frame:SetTitle( "VIP Notice" )
	Frame:SetVisible( true )
	Frame:SetDraggable( false )
	Frame:ShowCloseButton( true )
	Frame:SetBackgroundBlur(1)
	Frame:MakePopup()

	local day = 5184000
	local hour = 207360
	local minute = 3456
	local units;
	local floor = math.floor

	if (floor(timeLeft/day) >= 1) then units = "day"
	elseif (floor(timeLeft/hour) >= 1) then units = "hour"
	elseif (floor(timeLeft/minute) >= 1) then units = "minute"
	else units = "second" end
	--This is redundant, but IDGAF
	timeLeft = floor(timeLeft/day) >= 1 and floor(timeLeft/day) or floor(timeLeft/hour) and floor(timeLeft/hour) or floor(timeLeft/minute) and floor(timeLeft/minute) or timeLeft
	--It annoys the hell out of me when programmers are so lazy they can't add or remove the s if it's plural or singular
	local s = timeLeft > 1 and "s" or ""
	--Not a half bad font
	surface.SetFont( "DermaLarge" )
	local textSize = surface.GetTextSize( "Your VIP will expire in "..timeLeft.." "..units..s.."!" )
	
	local label = vgui.Create( "DLabel", Frame )
	label:SetPos( (Frame:GetWide()/2) - (textSize/2), 125 )
	label:SetFont( "DermaLarge" )
	label:SetText( "Your VIP will expire in "..timeLeft.." "..units..s.."!" )
	label:SetColor( Color(255, 200+(math.sin(CurTime()*2)*20), 200+(math.sin(CurTime()*2)*20)) )
	label:SizeToContents()
	
	timer.Create( "Text Modifier", 0.1, 0, 
		function() 
			if (IsValid(label)) then 
				label:SetColor( Color(255, 200+(math.sin(CurTime()*2)*50), 200+(math.sin(CurTime()*2)*50)) )
			else
				timer.Destroy( "Text Modifier" )
				return;
			end 
		end 
	)
end

net.Receive( "BVIP.Time", 
	function( len )
		localBVIP = net.ReadInt(8) --Took me a while to get this to work.
		BVIP = localBVIP --I have a local one so non-VIP's cant open it unless they overwrite this function.
		--In which case the menu would still not open.
		--The wiki's example is incorrect. GJ remaking it, garry.
		time = net.ReadUInt(32)
		expires = net.ReadUInt(32)
		if ((expires - time) < (5184000*7) and expires - time > 0 and expires != 1 and BVIP >= 1) then
			timer.Simple( 60, 
			function() 
				showExpiremenu(expires-time)
			end )
		end
		timer.Create( "BVIP.SyncTime", 1.0, function() time = time + 1 end ) -- I don't really care if it's not synced down to the second.
		-- It's not like it matters if it's 1 second off.
	end
)

net.Receive( "BVIP.VIPList", 
	function( len )
		BVIPs = net.ReadTable()
		BVIPExpire = net.ReadTable()
	end
)

net.Receive( "BVIP.SaveInfo", 
	function( len )
		local saveinfo = net.ReadInt(4)
		if (!saveinfo) then
			save = "Save failed..."
		else
			save = "Save success!"
		end
	end
)

concommand.Add( "vip_menu", function(ply, cmd, args) openVIPMenu() end)