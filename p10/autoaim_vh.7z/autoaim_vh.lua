--[[
	autoaim.lua
	lawl usa sux
	===DStream===
]]

-- AutoAim by RabidToaster
	local LoadTime          = CurTime()
print([[
vHAutoaim v0.2
a new update.

- fixed aimbot bugs
- added silent aim
]])

if SERVER then return end
local cppweaps = {}
cppweaps["weapon_357"] = true
cppweaps["weapon_smg1"] = true
cppweaps["weapon_ar2"] = true
cppweaps["weapon_shotgun"] = true
cppweaps["weapon_pistol"] = true
cppweaps["weapon_crossbow"] = true
cppweaps["weapon_rpg"] = true
local cppweapsrec = {}
cppweapsrec["weapon_357"] = 0.8
cppweapsrec["weapon_smg1"] = 1
cppweapsrec["weapon_ar2"] = 1.115
cppweapsrec["weapon_shotgun"] = 1
cppweapsrec["weapon_pistol"] = 1
cppweapsrec["weapon_crossbow"] = 1
local function anglepunch()
if !(LocalPlayer():GetActiveWeapon() == nil) then
if cppweaps[LocalPlayer():GetActiveWeapon():GetClass()] then
return (((LocalPlayer():GetPunchAngle( )) or Angle(0,0,0))*(cppweapsrec[LocalPlayer():GetActiveWeapon():GetClass()]or(0.8)))
else
return Angle(0,0,0)
end
else
return Angle(0,0,0)
end
end
local CL = LocalPlayer()
local wep = LocalPlayer():GetActiveWeapon()
local NoSpreadHere=false
if #file.Find("../lua/includes/modules/gmcl_dec0.dll")>=1 then
NoSpreadHere=true

local MoveSpeed = 1

mysetupmove = function(objPl, move)
    if move then
        MoveSpeed = (move:GetVelocity():Length())/move:GetMaxSpeed()
    end
end

local ID_GAMETYPE = ID_GAMETYPE or -1
local GameTypes = {
    {check=function ()
        return string.find(GAMEMODE.Name,"Garry Theft Auto") ~= nil
    end,getcone=function (wep,cone)
        if type(wep.Base) == "string" then
            if wep.Base == "civilian_base" then
                local scale = cone
                if CL:KeyDown(IN_DUCK) then
        scale = math.Clamp(cone/1.5,0,10)
                elseif CL:KeyDown(IN_WALK) then
        scale = cone
                elseif (CL:KeyDown(IN_SPEED) or CL:KeyDown(IN_JUMP)) then
        scale = cone + (cone*2)
                elseif (CL:KeyDown(IN_FORWARD) or CL:KeyDown(IN_BACK) or CL:KeyDown(IN_MOVELEFT) or CL:KeyDown(IN_MOVERIGHT)) then
        scale = cone + (cone*1.5)
                end
                scale = scale + (wep:GetNWFloat("Recoil",0)/3)
                return Vector(scale,0,0)
            end
        end
        return Vector(cone,cone,cone)
    end},
    {check=function ()
        return type(TEAM_ZOMBIE) == "number" and type(TEAM_SURVIVORS) == "number" and string.find(GAMEMODE.Name,"Zombie Survival") ~= nil and type(NUM_WAVES) == "number"
    end,getcone=function (wep,cone)
        if wep:GetNetworkedBool("Ironsights",false) then
            if CL:Crouching() then
                return wep.ConeIronCrouching or cone
            end
            return wep.ConeIron or cone
        elseif 25 < LocalPlayer():GetVelocity():Length() then
            return wep.ConeMoving or cone
        elseif CL:Crouching() then
            return wep.ConeCrouching or cone
        end
        return cone
    end},
    {check=function ()
        return type(TEAM_ZOMBIE) == "number" and type(TEAM_SURVIVORS) == "number" and string.find(GAMEMODE.Name,"Zombie Survival") ~= nil
    end,getcone=function (wep,cone)
        if CL:GetVelocity():Length() > 25 then
            return wep.ConeMoving or cone
        elseif CL:Crouching() then
            return wep.ConeCrouching or cone
        end
        return cone
    end},
    {check=function ()
        return type(gamemode.Get("ZombRP")) == "table" or type(gamemode.Get("DarkRP")) == "table"
    end,getcone=function (wep, cone)
        if type(wep.Base) == "string" and (wep.Base == "ls_snip_base" or wep.Base == "ls_snip_silencebase") then
            if CL:GetNWInt( "ScopeLevel", 0 ) > 0 then 
                print("using scopecone")
                return wep.Primary.Cone
            end
            print("using unscoped cone")
            return wep.Primary.UnscopedCone
        end
        if type(wep.GetIronsights) == "function" and wep:GetIronsights() then
            return cone
        end
        return cone + .05
    end},
    {check=function ()
        return (GAMEMODE.Data == "falloutmod" and type(Music) == "table")
    end,getcone=function(wep,cone)
        if wep.Primary then
            local LastShootTime = wep.Weapon:GetNetworkedFloat( "LastShootTime", 0 ) 
            local lastshootmod = math.Clamp(wep.LastFireMax + 1 - math.Clamp( (CurTime() - LastShootTime) * wep.LastFireModifier, 0.0, wep.LastFireMax ), 1.0,wep.LastFireMaxMod) 
            local accuracy = wep.Primary.Accuracy
            if CL:IsMoving() then accuracy = accuracy * wep.MoveModifier end
            if wep.Weapon:GetNetworkedBool( "Ironsights", false ) then accuracy = accuracy * 0.75 end
            accuracy = accuracy * ((16-(Skills.Marksman or 1))/11)
            if CL:KeyDown(IN_DUCK) then
                return accuracy*wep.CrouchModifier*lastshootmod
            else
                return accuracy*lastshootmod
            end
        end
    end}
}
Check = function()
    for k, v in pairs(GameTypes) do
        if v.check() then
            ID_GAMETYPE = k
            break
        end
    end
end

concommand.Add("raidbot_predictcheck", function () Check() print("GameType = ["..ID_GAMETYPE.."]") end)

local tblNormalConeWepBases = {
    ["weapon_cs_base"] = true
}
local function GetCone(wep)
    local cone = wep.Cone
    if not cone and type(wep.Primary) == "table" and type(wep.Primary.Cone) == "number" then
        cone = wep.Primary.Cone
    end
    if wep:GetClass() == "ose_turretcontroller" then return 0 end
    return cone or 0
end

require("dec0")
local currentseed, cmd2, seed = currentseed or 0, 0, 0
local wep, vecCone, valCone
PredictSpread = function(cmd,aimAngle)
    cmd2, seed = hl2_ucmd_getpr3diction(cmd)
    if cmd2 ~= 0 then
        currentseed = seed
    end
    wep = LocalPlayer():GetActiveWeapon()
    vecCone = Vector(0,0,0)
    if wep and wep:IsValid() and type(wep.Initialize) == "function" then
        valCone = GetCone(wep)
        if( tonumber( valCone ) ) then
        vecCone = Vector( -valCone, -valCone, -valCone )
        elseif( type( valCone ) == "Vector" ) then
        vecCone = -1 * valCone
        end
    end

	if wep:GetClass() == "weapon_smg1" then
	vecCone = Vector(-0.04362,-0.04362,-0.04362)
	elseif wep:GetClass() == "weapon_pistol" then
	vecCone = Vector( -0.0100, -0.0100, -0.0100 )
	elseif wep:GetClass() == "weapon_ar2" then
	vecCone = Vector( -0.02618, -0.02618, -0.02618 )
	elseif wep:GetClass() == "weapon_shotgun" then
	vecCone = Vector( -0.08716, -0.08716, -0.08716 )
	elseif wep:GetClass() == "weapon_iceaxe" then
	vecCone = Vector(-0.15,-0.15,-0.15)
	elseif wep:GetClass() == "weapon_sniper" then
	vecCone = Vector(-0.01,-0.01,-0.01)
	elseif wep:GetClass() == "weapon_hmg1" then
	vecCone = Vector(-0.07,-0.07,-0.07)
	elseif wep:GetClass() == "weapon_smg2" then
	vecCone = Vector(-0.07,-0.07,-0.07)
	elseif wep:GetClass() == "weapon_ar1" then
	vecCone = Vector(-0.07,-0.07,0)
	elseif wep:GetClass() == "weapon_oicw" then
	if wep.Zoom == 0 then
	vecCone = Vector(-0.07,-0.07,-0.07)
	else
	vecCone = Vector(-0.01,-0.01,-0.01)
	end
	elseif wep:GetClass() == "weapon_bsmg1" then
	vecCone = Vector(-0.04362,-0.04362,-0.04362)
	elseif wep:GetClass() == "mill_deagle" then
	vecCone = Vector(-0.5,-0.5,-0.5)
	elseif wep:GetClass() == "weapon_para" then
	vecCone = Vector(-0.05,-0.05,0)
	end
	cne = -vecCone.x
    return hl2_manipshot(currentseed or 0, aimAngle:Forward(), vecCone):Angle()
end
end

local AA = {}

local concommand = concommand
local cvars = cvars
local debug = debug
local ents = ents
local file = file
local hook = hook
local math = math
local spawnmenu = spawnmenu
local string = string
local surface = surface
local table = table
local timer = timer
local util = util
local vgui = vgui

local Angle = Angle
local CreateClientConVar = CreateClientConVar
local CurTime = CurTime
local ErrorNoHalt = ErrorNoHalt
local FrameTime = FrameTime
local GetConVarString = GetConVarString
local GetViewEntity = GetViewEntity
local include = include
local ipairs = ipairs
local LocalPlayer = LocalPlayer
local pairs = pairs
local pcall = pcall
local print = print
local RunConsoleCommand = RunConsoleCommand
local ScrH = ScrH
local ScrW = ScrW
local tonumber = tonumber
local type = type
local unpack = unpack
local ValidEntity = ValidEntity
local Vector = Vector

do
	local hooks = {}
	local created = {}
	local function CallHook(self, name, args)
		if !hooks[name] then return end
		for funcName, _ in pairs(hooks[name]) do
			local func = self[funcName]
			if func then
				local ok, err = pcall(func, self, unpack(args or {}))
				if !ok then
					ErrorNoHalt(err .. "\n")
				elseif err then
					return err
				end
			end
		end
	end
	local function RandomName()
		local random = ""
		for i = 1, math.random(4, 10) do
			local c = math.random(65, 116)
			if c >= 91 && c <= 96 then c = c + 6 end
			random = random .. string.char(c)
		end
		return random
	end
	local function AddHook(self, name, funcName)
		// If we haven't got a hook for this yet, make one with a random name and store it.
		// This is so anti-cheats can't detect by hook name, and so we can remove them later.
		if !created[name] then
			local random = RandomName()
			hook.Add(name, random, function(...) return CallHook(self, name, {...}) end)
			created[name] = random
		end
		
		hooks[name] = hooks[name] or {}
		hooks[name][funcName] = true
	end
	
	local cvarhooks = {}
	local function GetCallbackTable(convar)
		local callbacks = cvars.GetConVarCallbacks(convar)
		if !callbacks then
			cvars.AddChangeCallback(convar, function() end)
			callbacks = cvars.GetConVarCallbacks(convar)
		end
		return callbacks
	end
			
	local function AddCVarHook(self, convar, funcName, ...)
		local hookName = "CVar_" .. convar
		if !cvarhooks[convar] then
			local random = RandomName()
			
			local callbacks = GetCallbackTable(convar)
			callbacks[random] = function(...)
				CallHook(self, hookName, {...})
			end
			
			cvarhooks[convar] = random
		end
		AddHook(self, hookName, funcName)
	end
	
	// Don't let other scripts remove our hooks.
	local oldRemove = hook.Remove
	function hook.Remove(name, unique)
		if created[name] == unique then return end
		oldRemove(name, unique)
	end
	
	// Removes all hooks, useful if reloading the script.
	local function RemoveHooks()
		for hookName, unique in pairs(created) do
			oldRemove(hookName, unique)
		end
		for convar, unique in pairs(cvarhooks) do
			local callbacks = GetCallbackTable(convar)
			callbacks[unique] = nil
		end
	end
	
	// Add copies the script can access.
	AA.AddHook = AddHook
	AA.AddCVarHook = AddCVarHook
	AA.CallHook = CallHook
	AA.RemoveHooks = RemoveHooks
end

concommand.Add("aa_reload", function()
	AA:CallHook("Shutdown")
	print("Removing hooks...")
	AA:RemoveHooks()
	
	local info = debug.getinfo(1, "S")
	if info && info.short_src then
		print("Reloading (" .. info.short_src .. ")...")
		include(info.short_src)
	else
		print("Cannot find AutoAim file, reload manually.")
	end
end)
print("AutoAim loaded.")

// ##################################################
// MetaTables
// ##################################################

local function GetMeta(name)
	return table.Copy(_R[name] or {})
end

local AngM = GetMeta("Angle")
local CmdM = GetMeta("CUserCmd")
local EntM = GetMeta("Entity")
local PlyM = GetMeta("Player")
local VecM = GetMeta("Vector")

// ##################################################
// Settings
// ##################################################

do
	local settings = {}
	local function SettingVar(self, name)
		return (self.SettingPrefix or "") .. string.lower(name)
	end
	
	local function RandomName()
		local random = ""
		for i = 1, math.random(4, 10) do
			local c = math.random(65, 116)
			if c >= 91 && c <= 96 then c = c + 6 end
			random = random .. string.char(c)
		end
		return random
	end
	
	local function SetSetting(name, _, new)
		if !settings[name] then return end
		local info = settings[name]
		
		if info.Type == "number" then
			new = tonumber(new)
		elseif info.Type == "boolean" then
			new = (tonumber(new) or 0) > 0
		end
		
		info.Value = new
	end
	
	local function CreateSetting(self, name, desc, default, misc)
		local cvar = SettingVar(self, name)
		local info = {Name = name, Desc = desc, CVar = cvar, Type = type(default), Value = default}
		
		for k, v in pairs(misc or {}) do
			if !info[k] then info[k] = v end
		end
		
		// Convert default from boolean to number.
		if type(default) == "boolean" then
			default = default and 1 or 0
		end
		
		if !settings[cvar] then
			local tab = cvars.GetConVarCallbacks(cvar)
			if !tab then
				cvars.AddChangeCallback(cvar, function() end)
				tab = cvars.GetConVarCallbacks(cvar)
			end
			
			while true do
				local name = RandomName()
				if !tab[name] then
					tab[name] = SetSetting
					info.Callback = name
					break
				end
			end
		end
		
		settings[cvar] = info
		settings[#settings + 1] = info
		
		// Create the convar.
		CreateClientConVar(cvar, default, (info.Save != false), false)
		SetSetting(cvar, _, GetConVarString(cvar))
	end
	local function GetSetting(self, name)
		local cvar = SettingVar(self, name)
		if !settings[cvar] then return end
		return settings[cvar].Value
	end
	local function Shutdown()
		print("Removing settings callbacks...")
		for _, info in ipairs(settings) do
			if info.CVar && info.Callback then
				local tab = cvars.GetConVarCallbacks(info.CVar)
				if tab then
					tab[info.Callback] = nil
				end
			end
		end
	end
	local function SettingsList()
		return table.Copy(settings)
	end
	local function BuildMenu(self, panel)
		for _, info in ipairs(settings) do
			if info.Show != false then
				if info.MultiChoice then
					local m = panel:MultiChoice(info.Desc or info.CVar, info.CVar)
					for k, v in pairs(info.MultiChoice) do
						m:AddChoice(k, v)
					end
				elseif info.Type == "number" then
					panel:NumSlider(info.Desc or info.CVar, info.CVar, info.Min or -1, info.Max or -1, info.Places or 0)
				elseif info.Type == "boolean" then
					panel:CheckBox(info.Desc or info.CVar, info.CVar)
				elseif info.Type == "string" then
					panel:TextEntry(info.Desc or info.CVar, info.CVar)
				end
			end
		end
	end
	
	AA.SettingPrefix = "aa_"
	AA.CreateSetting = CreateSetting
	AA.Setting = GetSetting
	AA.SettingsList = SettingsList
	AA.BuildMenu = BuildMenu
	
	AA.SettingsShutdown = Shutdown
	AA:AddHook("Shutdown", "SettingsShutdown")
end


// ##################################################
// Targetting - Positions
// ##################################################

AA.ModelTarget = {}
function AA:SetModelTarget(model, targ)
	self.ModelTarget[model] = targ
end
function AA:BaseTargetPosition(ent)
	// The eye attachment is a lot more stable than bones for players.
	if type(ent) == "Player" then
		local head = EntM["LookupAttachment"](ent, "eyes")
		if head then
			local pos = EntM["GetAttachment"](ent, head)
			if pos then
				return pos.Pos - (AngM["Forward"](pos.Ang) * 2)
			end
		end
	end
	
	// Check if the model has a special target assigned to it.
	local special = self.ModelTarget[string.lower(EntM["GetModel"](ent) or "")]
	if special then
		// It's a string - look for a bone.
		if type(special) == "string" then
			local bone = EntM["LookupBone"](ent, special)
			if bone then
				local pos = EntM["GetBonePosition"](ent, bone)
				if pos then
					return pos
				end
			end
		// It's a Vector - return a relative position.
		elseif type(special) == "Vector" then
			return EntM["LocalToWorld"](ent, special)
		// It's a function - do something fancy!
		elseif type(special) == "function" then
			local pos = pcall(special, ent)
			if pos then return pos end
		end
	end

	// Try and use the head bone, found on all of the player + human models.
	local bone = "ValveBiped.Bip01_Head1"
	local head = EntM["LookupBone"](ent, bone)
	if head then
		local pos = EntM["GetBonePosition"](ent, head)
		if pos then
			return pos
		end
	end

	// Give up and return the center of the entity.
	return EntM["LocalToWorld"](ent, EntM["OBBCenter"](ent))
end
function AA:TargetPosition(ent)
	local targetPos = self:BaseTargetPosition(ent)
	
	local ply = LocalPlayer()
	if ValidEntity(ply) then
		targetPos = self:CallHook("TargetPrediction", {ply, ent, targetPos}) or targetPos
	end
	
	return targetPos
end

AA:SetModelTarget("models/crow.mdl", Vector(0, 0, 5))						// Crow.
AA:SetModelTarget("models/pigeon.mdl", Vector(0, 0, 5)) 					// Pigeon.
AA:SetModelTarget("models/seagull.mdl", Vector(0, 0, 6)) 					// Seagull.
AA:SetModelTarget("models/combine_scanner.mdl", "Scanner.Body") 				// Scanner.
AA:SetModelTarget("models/hunter.mdl", "MiniStrider.body_joint") 			// Hunter.
AA:SetModelTarget("models/combine_turrets/floor_turret.mdl", "Barrel") 		// Turret.
AA:SetModelTarget("models/dog.mdl", "Dog_Model.Eye") 						// Dog.
AA:SetModelTarget("models/vortigaunt.mdl", "ValveBiped.Head") 				// Vortigaunt.
AA:SetModelTarget("models/antlion.mdl", "Antlion.Body_Bone") 					// Antlion.
AA:SetModelTarget("models/antlion_guard.mdl", "Antlion_Guard.Body") 			// Antlion guard.
AA:SetModelTarget("models/antlion_worker.mdl", "Antlion.Head_Bone") 			// Antlion worker.
AA:SetModelTarget("models/zombie/fast_torso.mdl", "ValveBiped.HC_BodyCube") 	// Fast zombie torso.
AA:SetModelTarget("models/zombie/fast.mdl", "ValveBiped.HC_BodyCube") 		// Fast zombie.
AA:SetModelTarget("models/headcrabclassic.mdl", "HeadcrabClassic.SpineControl") // Normal headcrab.
AA:SetModelTarget("models/headcrabblack.mdl", "HCBlack.body") 				// Poison headcrab.
AA:SetModelTarget("models/headcrab.mdl", "HCFast.body") 						// Fast headcrab.
AA:SetModelTarget("models/zombie/poison.mdl", "ValveBiped.Headcrab_Cube1")	 // Poison zombie.
AA:SetModelTarget("models/zombie/classic.mdl", "ValveBiped.HC_Body_Bone")	 // Zombie.
AA:SetModelTarget("models/zombie/classic_torso.mdl", "ValveBiped.HC_Body_Bone") // Zombie torso.
AA:SetModelTarget("models/zombie/zombie_soldier.mdl", "ValveBiped.HC_Body_Bone") // Zombine.
AA:SetModelTarget("models/combine_strider.mdl", "Combine_Strider.Body_Bone") // Strider.
AA:SetModelTarget("models/combine_dropship.mdl", "D_ship.Spine1") 			// Combine dropship.
AA:SetModelTarget("models/combine_helicopter.mdl", "Chopper.Body") 			// Combine helicopter.
AA:SetModelTarget("models/gunship.mdl", "Gunship.Body")						// Combine gunship.
AA:SetModelTarget("models/lamarr.mdl", "HeadcrabClassic.SpineControl")		// Lamarr!
AA:SetModelTarget("models/mortarsynth.mdl", "Root Bone")						// Mortar synth.
AA:SetModelTarget("models/synth.mdl", "Bip02 Spine1")						// Synth.
AA:SetModelTarget("models/vortigaunt_slave.mdl", "ValveBiped.Head")			// Vortigaunt slave.


// ##################################################
// Targetting - General
// ##################################################

AA.NPCDeathSequences = {}
function AA:AddNPCDeathSequence(model, sequence)
	self.NPCDeathSequences = self.NPCDeathSequences or {}
	self.NPCDeathSequences[model] = self.NPCDeathSequences[model] or {}
	if !table.HasValue(self.NPCDeathSequences[model]) then
		table.insert(self.NPCDeathSequences[model], sequence)
	end
end

AA:AddNPCDeathSequence("models/barnacle.mdl", 4)
AA:AddNPCDeathSequence("models/barnacle.mdl", 15)
AA:AddNPCDeathSequence("models/antlion_guard.mdl", 44)
AA:AddNPCDeathSequence("models/hunter.mdl", 124)
AA:AddNPCDeathSequence("models/hunter.mdl", 125)
AA:AddNPCDeathSequence("models/hunter.mdl", 126)
AA:AddNPCDeathSequence("models/hunter.mdl", 127)
AA:AddNPCDeathSequence("models/hunter.mdl", 128)

AA:CreateSetting("friendlyfire", "Target teammates", false)
function AA:IsValidTarget(ent)
	// We only want players/NPCs.
	local typename = type(ent)
	if typename != "NPC" && typename != "Player" then return false end

	// No invalid entities.
	if !ValidEntity(ent) then return false end

	// Go shoot yourself, emo kid.
	local ply = LocalPlayer()
	if ent == ply then return false end

	if typename == "Player" then
		if !PlyM["Alive"](ent) then return false end // Dead players FTL.
		if !self:Setting("friendlyfire") && PlyM["Team"](ent) == PlyM["Team"](ply) then return false end
		if EntM["GetMoveType"](ent) == MOVETYPE_OBSERVER then return false end // No spectators.
		if EntM["GetMoveType"](ent) == MOVETYPE_NONE then return false end
		//if pl["Team"](ent) == 1001 then return false end
	end

	if typename == "NPC" then
		if EntM["GetMoveType"](ent) == MOVETYPE_NONE then return false end // No dead NPCs.

		// No dying NPCs.
		local model = string.lower(EntM["GetModel"](ent) or "")
		if table.HasValue(self.NPCDeathSequences[model] or {}, EntM["GetSequence"](ent)) then return false end
	end
end

AA:CreateSetting("predictblocked", "Predict blocked (time)", 0.4, {Min = 0, Max = 1})
function AA:BaseBlocked(target, offset)
	local ply = LocalPlayer()
	if !ValidEntity(ply) then return end
	
	// Trace from the players shootpos to the position.
	local shootPos = PlyM["GetShootPos"](ply)
	local targetPos = self:TargetPosition(target)
	
	if offset then targetPos = targetPos + offset end

	local trace = util.TraceLine({start = shootPos, endpos = targetPos, filter = {ply, target}, mask = MASK_SHOT})
	local wrongAim = self:AngleBetween(PlyM["GetAimVector"](ply), VecM["GetNormal"](targetPos - shootPos)) > 2

	// If we hit something, we're "blocked".
	if trace.Hit && trace.Entity != target then
		return true, wrongAim
	end

	// It is not blocked.
	return false, wrongAim
end
function AA:TargetBlocked(target)
	if !target then target = self:GetTarget() end
	if !target then return end
	
	local blocked, wrongAim = self:BaseBlocked(target)
	if self:Setting("predictblocked") > 0 && blocked then
		blocked = self:BaseBlocked(target, EntM["GetVelocity"](target) * self:Setting("predictblocked"))
	end
	return blocked, wrongAim
end
	

function AA:SetTarget(ent)
	if self.Target && !ent then
		self:CallHook("TargetLost")
	elseif !self.Target && ent then
		self:CallHook("TargetGained")
	elseif self.Target && ent && self.Target != ent then
		self:CallHook("TargetChanged")
	end

	self.Target = ent
end
function AA:GetTarget()
	if ValidEntity(self.Target) != false then
		return self.Target
	else
		return false
	end
end

AA:CreateSetting("maxangle", "Max angle", 30, {Min = 5, Max = 90})
AA:CreateSetting("targetblocked", "Don't check LOS", false)
AA:CreateSetting("holdtarget", "Hold targets", false)
function AA:FindTarget()
	if !self:Enabled() then return end

	local ply = LocalPlayer()
	if !ValidEntity(ply) then return end

	local maxAng = self:Setting("maxangle")
	local aimVec, shootPos = PlyM["GetAimVector"](ply), PlyM["GetShootPos"](ply)
	local targetBlocked = self:Setting("targetblocked")

	if self:Setting("holdtarget") then
		local target = self:GetTarget()
		if target then
			local targetPos = self:TargetPosition(target)
			local angle = self:AngleBetween(AngM["Forward"](self:GetView()), VecM["GetNormal"](targetPos - shootPos))
			local blocked = self:TargetBlocked(target)
			if angle <= maxAng && (!blocked || targetBlocked) then return end
		end
	end

	// Filter out targets.
	local targets = ents.GetAll()
	for i, ent in pairs(targets) do
		if self:IsValidTarget(ent) == false then
			targets[i] = nil
		end
	end

	local closestTarget, lowestAngle = _, maxAng
	for _, target in pairs(targets) do
		if targetBlocked || !self:TargetBlocked(target) then
			local targetPos = self:TargetPosition(target)
			local angle = self:AngleBetween(AngM["Forward"](self:GetView()), VecM["GetNormal"](targetPos - shootPos))

			if angle < lowestAngle then
				lowestAngle = angle
				closestTarget = target
			end
		end
	end

	self:SetTarget(closestTarget)
end
AA:AddHook("Think", "FindTarget")


// ##################################################
// Fake view
// ##################################################

AA.View = Angle(0, 0, 0)
function AA:GetView()
	return self.View * 1
end
function AA:KeepView()
	if !self:Enabled() then return end

	local ply = LocalPlayer()
	if !ValidEntity(ply) then return end

	self.View = EntM["EyeAngles"](ply)
end
AA:AddHook("OnToggled", "KeepView")

local sensitivity = 0.022
function AA:RotateView(cmd)
	self.View.p = math.Clamp(self.View.p + (CmdM["GetMouseY"](cmd) * sensitivity), -89, 89)
	self.View.y = math.NormalizeAngle(self.View.y + (CmdM["GetMouseX"](cmd) * sensitivity * -1))
end
AA:AddHook("CreateMove", "RotateView")

AA:CreateSetting("debug", "Debug", false, {Show = false})
function AA:FakeView(ply, origin, angles, FOV)
	if !self:Enabled() && !self.SetAngleTo then return end
	if GetViewEntity() != LocalPlayer() then return end
	if self:Setting("debug") then return end
	
	local base = GAMEMODE:CalcView(ply, origin, self.SetAngleTo or self.View, FOV) or {}
			base.angles = base.angles or (self.AngleTo or self.View)
			base.angles.r = 0 // No crappy screen tilting in ZS.
	return base
end
--AA:AddHook("CalcView", "FakeView")

function AA:TargetPrediction(ply, target, targetPos)
	local weap = PlyM["GetActiveWeapon"](ply)
	if ValidEntity(weap) then
		local class = EntM["GetClass"](weap)
		if class == "weapon_crossbow" then
			local dist = VecM["Length"](targetPos - PlyM["GetShootPos"](ply))
			local time = (dist / 3500) + 0.05 // About crossbow bolt speed.
			targetPos = targetPos + (EntM["GetVelocity"](target) * time)
		end
		
		local mul = 0.0075
		targetPos = targetPos - (EntM["GetVelocity"](ply) * mul)
	end
	
	return targetPos
end
AA:AddHook("TargetPrediction", "TargetPrediction")

// ##################################################
// Aim
// ##################################################

function AA:SetAngle(ang)
	self.SetAngleTo = ang
end

AA:CreateSetting("smoothspeed", "Smooth aim speed (0 to disable)", 120, {Min = 0, Max = 360})
AA:CreateSetting("snaponfire", "Snap on fire", true)
AA:CreateSetting("snapgrace", "Snap on fire grace", 0.5, {Min = 0, Max = 3, Places = 1})
AA.LastAttack = 0
function AA:SetAimAngles(cmd)
	if !self:Enabled() && !self.SetAngleTo then return end

	local ply = LocalPlayer()
	if !ValidEntity(ply) then return end

	// We're aiming with the view, normally.
	local targetAim = self:GetView()

	// If we have a target, aim at them!
	local target = self:GetTarget()
	if target then
		local targetPos = self:TargetPosition(target)
		targetAim = VecM["Angle"](targetPos - ply:GetShootPos())
	end

	// We're following the view, until we fire.
	if self:Setting("snaponfire") then
		local time = CurTime()
		if PlyM["KeyDown"](ply, IN_ATTACK) || PlyM["KeyDown"](ply, IN_ATTACK2) || self:Setting("autoshoot") != 0 then
			self.LastAttack = time
		end
		if CurTime() - self.LastAttack > self:Setting("snapgrace") then
			targetAim = self:GetView()
		end
	end

	// We want to change to whatever was SetAngle'd.
	if self.SetAngleTo then
		targetAim = self.SetAngleTo
	end

	// Smooth aiming.
	local smooth = self:Setting("smoothspeed")
	if smooth > 0 then
		local current = CmdM["GetViewAngles"](cmd)

		// Approach the target angle.
		current = self:ApproachAngle(current, targetAim, smooth * FrameTime())
		current.r = 0

		// If we're just following the view, we don't need to smooth it.
		if self.RevertingAim then
			local diff = self:NormalizeAngle(current - self:GetView())
			if math.abs(diff.p) < 1 && math.abs(diff.y) < 1 then self.RevertingAim = false end
		elseif targetAim == self:GetView() then
			current = targetAim
		end

		// Check if the angles are the same...
		if self.SetAngleTo then
			local diff = self:NormalizeAngle(current - self.SetAngleTo)
			if math.abs(diff.p) < 1 && math.abs(diff.y) < 1 then self.SetAngleTo = nil end
		end

		aim = current
	else
		aim = targetAim
		self.SetAngleTo = nil
	end
	--self.View = aim
		if (cmd:GetButtons() & IN_ATTACK > 0) then
			aim = PredictSpread(cmd,aim)-anglepunch()
		end
	// Set the angles.
	CmdM["SetViewAngles"](cmd, aim)
	local sensitivity = 0.22
	local diff = aim - CmdM["GetViewAngles"](cmd)
	CmdM["SetMouseX"](cmd, diff.y / sensitivity)
	CmdM["SetMouseY"](cmd, diff.p / sensitivity)
	

	// Change the players movement to be relative to their view instead of their aim.
	local move = Vector(CmdM["GetForwardMove"](cmd), CmdM["GetSideMove"](cmd), 0)
	local norm = VecM["GetNormal"](move)
	local set = AngM["Forward"](VecM["Angle"](norm) + (aim - self:GetView())) * VecM["Length"](move)
		CmdM["SetForwardMove"](cmd, set.x)
		CmdM["SetSideMove"](cmd, set.y)
end
AA:AddHook("CreateMove", "SetAimAngles")

function AA:RevertAim()
	self.RevertingAim = true
end
AA:AddHook("TargetLost", "RevertAim")
function AA:StopRevertAim()
	self.RevertingAim = false
end
AA:AddHook("TargetGained", "RevertAim")

// When we turn off the bot, we want our aim to go back to our view.
function AA:ViewToAim()
	if self:Enabled() then return end
	self:SetAngle(self:GetView())
end
AA:AddHook("OnToggled", "ViewToAim")


// ##################################################
// HUD
// ##################################################

AA:CreateSetting("crosshair", "Crosshair size (0 to disable)", 18, {Min = 0, Max = 20})
function AA:DrawTarget()
	if !self:Enabled() then return end

	local target = self:GetTarget()
	if !target then return end

	local size = self:Setting("crosshair")
	if size <= 0 then return end

	// Change colour on the block status.
	local blocked, aimOff = self:TargetBlocked()
	if blocked then
		surface.SetDrawColor(255, 0, 0, 255) // Red.
	elseif aimOff then
		surface.SetDrawColor(255, 255, 0, 255) // Yellow.
	else
		surface.SetDrawColor(0, 255, 0, 255) // Green.
	end

	// Get the onscreen coordinates for the target.
	local pos = self:TargetPosition(target)

	local screen = VecM["ToScreen"](pos)
	local x, y = screen.x, screen.y

	// Work out sizes.
	local a, b = size / 2, size / 6

	// Top left.
	surface.DrawLine(x - a, y - a, x - b, y - a)
	surface.DrawLine(x - a, y - a, x - a, y - b)

	// Bottom right.
	surface.DrawLine(x + a, y + a, x + b, y + a)
	surface.DrawLine(x + a, y + a, x + a, y + b)

	// Top right.
	surface.DrawLine(x + a, y - a, x + b, y - a)
	surface.DrawLine(x + a, y - a, x + a, y - b)

	// Bottom left.
	surface.DrawLine(x - a, y + a, x - b, y + a)
	surface.DrawLine(x - a, y + a, x - a, y + b)
end
AA:AddHook("HUDPaint", "DrawTarget")
local function box( e )
	local ply, pos = LocalPlayer(), nil
	local center = e:LocalToWorld( e:OBBCenter() )
	local min, max = e:OBBMins(), e:OBBMaxs()
	local dim = max - min
	local z = max + min
	
	local frt	= ( e:GetForward() ) * ( dim.y / 2 )
	local rgt	= ( e:GetRight() ) * ( dim.x / 2 )
	local top	= ( e:GetUp() ) * ( dim.z / 2 )
	local bak	= ( e:GetForward() * -1 ) * ( dim.y / 2 )
	local lft	= ( e:GetRight() * -1 ) * ( dim.x / 2 )
	local btm	= ( e:GetUp() * -1 ) * ( dim.z / 2 )
	
	local d, v = math.Round( e:GetPos():Distance( ply:GetShootPos() ) )
	v = d / 30
	
	pos = e:LocalToWorld( top + top ) + Vector( 0, 0, v + 10 )
	if ( e:IsWeapon() ) then pos = e:LocalToWorld( e:OBBCenter() ) end
	
	local FRT 	= center + frt + rgt + top; FRT = FRT:ToScreen()
	local BLB 	= center + bak + lft + btm; BLB = BLB:ToScreen()
	local FLT	= center + frt + lft + top; FLT = FLT:ToScreen()
	local BRT 	= center + bak + rgt + top; BRT = BRT:ToScreen()
	local BLT 	= center + bak + lft + top; BLT = BLT:ToScreen()
	local FRB 	= center + frt + rgt + btm; FRB = FRB:ToScreen()
	local FLB 	= center + frt + lft + btm; FLB = FLB:ToScreen()
	local BRB 	= center + bak + rgt + btm; BRB = BRB:ToScreen()
	
	pos = pos:ToScreen()
	
	local maxX = math.max( FRT.x,BLB.x,FLT.x,BRT.x,BLT.x,FRB.x,FLB.x,BRB.x )
	local minX = math.min( FRT.x,BLB.x,FLT.x,BRT.x,BLT.x,FRB.x,FLB.x,BRB.x )
	local maxY = math.max( FRT.y,BLB.y,FLT.y,BRT.y,BLT.y,FRB.y,FLB.y,BRB.y)
	local minY = math.min( FRT.y,BLB.y,FLT.y,BRT.y,BLT.y,FRB.y,FLB.y,BRB.y )
	
	return maxX, minX, maxY, minY
end

aimmodels = {
        ["models/combine_scanner.mdl"] = "Scanner.Body",
        ["models/hunter.mdl"] = "MiniStrider.body_joint",
        ["models/combine_turrets/floor_turret.mdl"] = "Barrel",
        ["models/dog.mdl"] = "Dog_Model.Eye",
        ["models/antlion.mdl"] = "Antlion.Body_Bone",
        ["models/antlion_guard.mdl"] = "Antlion_Guard.Body",
        ["models/antlion_worker.mdl"] = "Antlion.Head_Bone",
        ["models/zombie/fast_torso.mdl"] = "ValveBiped.HC_BodyCube",
        ["models/zombie/fast.mdl"] = "ValveBiped.HC_BodyCube",
        ["models/headcrabclassic.mdl"] = "HeadcrabClassic.SpineControl",
        ["models/headcrabblack.mdl"] = "HCBlack.body",
        ["models/headcrab.mdl"] = "HCFast.body",
        ["models/zombie/poison.mdl"] = "ValveBiped.Headcrab_Cube1",
        ["models/zombie/classic.mdl"] = "ValveBiped.HC_Body_Bone",
        ["models/zombie/classic_torso.mdl"] = "ValveBiped.HC_Body_Bone",
        ["models/zombie/zombie_soldier.mdl"] = "ValveBiped.HC_Body_Bone",
        ["models/combine_strider.mdl"] = "Combine_Strider.Body_Bone",
        ["models/lamarr.mdl"] = "HeadcrabClassic.SpineControl"
}

local function HeadPos(ply) 
    if ValidEntity(ply) then 
if (ply:GetClass()=="npc_tripmine") && (ply:GetClass()=="npc_satchel") && (ply:GetClass()=="npc_grenade_frag") then
return false
end
	local bone = (aimmodels[ ply:GetModel() ] or "ValveBiped.Bip01_Head1")
	local hbone = ply:LookupBone(bone) 
        return ply:GetBonePosition(hbone) 
    else return end 
end
local function Visible(ply) 
    local trace = {start = LocalPlayer():GetShootPos(),endpos = HeadPos(ply),filter = {LocalPlayer(), ply}} 
    local tr = util.TraceLine(trace) 
	local u = LocalPlayer():GetCurrentCommand( )
		--if (u:GetButtons() & IN_ATTACK > 0) then
		--if tr.MatType == 87 then
--[[		local trace2 = {start = (tr.HitPos*2),endpos = HeadPos(ply),filter = {LocalPlayer(), ply}} 
		local tr2 = util.TraceLine(trace) 
		if tr2.Fraction == 1 then 
        return true 
		else 
		local trace3 = {start = (tr.HitPos/2),endpos = HeadPos(ply),filter = {LocalPlayer(), ply}} 
		local tr3 = util.TraceLine(trace) 
		if tr3.Fraction == 1 then 
        return true 
		else 
        return false 
		end 
		end]]
	--	return true		
		--end
	--	end
	if tr.Fraction == 1 then 
        return true 
    else 
        return false 
    end    
	end
function AA:drawesp() 
        for k, v in pairs(ents.GetAll()) do 
            if( ValidEntity(v) and v ~= LocalPlayer() ) then
                if( v:IsNPC() ) then 
                    local drawColor = Color(255, 255, 255, 255); 
                    local drawPosit = v:GetPos():ToScreen(); 
                    local vis = ""
                    if( Visible(v) ) then 
						vis = "Visible"
                        drawColor = Color( 255, 0, 0, 255 ); 
                    else 
						vis = "Invisible"
                        drawColor = Color( 0, 255, 255, 255 ); 
                    end
					surface.SetDrawColor(drawColor)
					local head = HeadPos(v):ToScreen()
					local maxX, minX, maxY, minY = box(v)
					local lol = maxY-minY
					local minz, maxz = v:OBBMins(), v:OBBMaxs()
					minz = (v:GetPos()+minz):ToScreen()
					maxz = (v:GetPos()+maxz):ToScreen()
					surface.DrawLine( maxX, maxY, maxX, minY )
					surface.DrawLine( maxX, minY, minX, minY )
					
					surface.DrawLine( minX, minY, minX, maxY )
					surface.DrawLine( minX, maxY, maxX, maxY )

                    local textData = {} 
                     
                    textData.pos = {} 
                    textData.pos[1] = drawPosit.x; 
                    textData.pos[2] = maxY+10; 
                    textData.color = drawColor; 
                    textData.text = v:GetClass(); 
                    textData.font = "DefaultFixed"; 
                    textData.xalign = TEXT_ALIGN_CENTER; 
                    textData.yalign = TEXT_ALIGN_CENTER; 
                    draw.Text( textData ); 
                    textData.pos = {} 
                    textData.pos[1] = drawPosit.x; 
                    textData.pos[2] = maxY+25; 
                    textData.color = drawColor; 
                    textData.text = vis; 
                    textData.font = "DefaultFixed"; 
                    textData.xalign = TEXT_ALIGN_CENTER; 
                    textData.yalign = TEXT_ALIGN_CENTER; 
                    draw.Text( textData );
					elseif( v:IsPlayer() and v:Health() > 0 and v:Alive() ) then 
                    local drawColor = team.GetColor(v:Team()); 
                    local drawPosit = v:GetPos():ToScreen(); 
                     
                    if( Visible(v) ) then 
                        drawColor.a = 255; 
                    else 
                        drawColor.r = 255 - drawColor.r; 
                        drawColor.g = 255 - drawColor.g; 
                        drawColor.b = 255 - drawColor.b; 
                    end 
                    surface.SetDrawColor(drawColor)
                    local textData = {} 
                    local maxX, minX, maxY, minY = box(v)
					local lol = maxY-minY
					surface.SetDrawColor(drawColor)
					surface.DrawLine( maxX, maxY, maxX, minY )
					surface.DrawLine( maxX, minY, minX, minY )
					
					surface.DrawLine( minX, minY, minX, maxY )
					surface.DrawLine( minX, maxY, maxX, maxY )
                    textData.pos = {} 
                    textData.pos[1] = drawPosit.x; 
                    textData.pos[2] = maxY+10; 
                    textData.color = drawColor; 
                    textData.text = v:GetName(); 
                    textData.font = "DefaultFixed"; 
                    textData.xalign = TEXT_ALIGN_CENTER; 
                    textData.yalign = TEXT_ALIGN_CENTER; 
                     
                    draw.Text( textData ); 
					local max_armor = 100; 
                     
                    if( v:Armor() > max_armor ) then 
                       max_armor = v:Armor(); 
                    end 
                    if v:GetActiveWeapon() then if ValidEntity(v:GetActiveWeapon()) then
					if v:GetActiveWeapon():GetClass() == "weapon_ak47" then
					draw.SimpleText( "b" , "CSKillIcons", drawPosit.x, maxY+35, drawColor, TEXT_ALIGN_CENTER, TEXT_ALIGN_LEFT, 1)
					elseif v:GetActiveWeapon():GetClass() == "weapon_para" then
					draw.SimpleText( "z" , "CSKillIcons", drawPosit.x, maxY+35, drawColor, TEXT_ALIGN_CENTER, TEXT_ALIGN_LEFT, 1)
					elseif v:GetActiveWeapon():GetClass() == "weapon_mp5" then
					draw.SimpleText( "x" , "CSKillIcons", drawPosit.x, maxY+35, drawColor, TEXT_ALIGN_CENTER, TEXT_ALIGN_LEFT, 1)
					elseif v:GetActiveWeapon():GetClass() == "weapon_m4" then
					draw.SimpleText( "w" , "CSKillIcons", drawPosit.x, maxY+35, drawColor, TEXT_ALIGN_CENTER, TEXT_ALIGN_LEFT, 1)
					elseif v:GetActiveWeapon():GetClass() == "weapon_glock" then
					draw.SimpleText( "c" , "CSKillIcons", drawPosit.x, maxY+35, drawColor, TEXT_ALIGN_CENTER, TEXT_ALIGN_LEFT, 1)
					elseif v:GetActiveWeapon():GetClass() == "weapon_tmp" then
					draw.SimpleText( "d" , "CSKillIcons", drawPosit.x, maxY+35, drawColor, TEXT_ALIGN_CENTER, TEXT_ALIGN_LEFT, 1)
					elseif v:GetActiveWeapon():GetClass() == "weapon_deagle" then
					draw.SimpleText( "f" , "CSKillIcons", drawPosit.x, maxY+35, drawColor, TEXT_ALIGN_CENTER, TEXT_ALIGN_LEFT, 1)
					elseif v:GetActiveWeapon():GetClass() == "weapon_pumpshotgun" then
					draw.SimpleText( "k" , "CSKillIcons", drawPosit.x, maxY+35, drawColor, TEXT_ALIGN_CENTER, TEXT_ALIGN_LEFT, 1)
					end
					end
					end
                    local mx = max_armor; 
                    local mw = v:Armor(); 
                    local drw = mw / lol
                    local drawPosHealth = drawPosit; 
					surface.SetDrawColor(0,0,0,255)
					surface.DrawRect(maxX+2,minY-1,6,lol+2)
					surface.SetDrawColor(255-(mw*2+50),mw*2+50,0,255)
					surface.DrawRect(maxX+3,minY-(mw/drw)+(mx/drw),4,mw/drw)
					local max_health = 100; 
                     
                    if( v:Health() > max_health ) then 
						max_health = v:Health(); 
                    end 
                    
                    local mx = max_health; 
                    local mw = v:Health(); 
                    local drw = mx / lol
                    local drawPosHealth = drawPosit; 
					surface.SetDrawColor(0,0,0,255)
					surface.DrawRect(minX-8,minY-1,6,lol+2)
					surface.SetDrawColor(255-(mw*2+50),mw*2+50,0,255)
					surface.DrawRect(minX-7,minY-(mw/drw)+(mx/drw),4,mw/drw)
					end
					end
    end 
	end
	local function bMaterial()
local Texture = {
  ["$basetexture"] = "models/debug/debugwhite",
  ["$model"]       = 1,
  ["$translucent"] = 1,
  ["$alpha"]       = 1,
  ["$nocull"]      = 1,
  ["$ignorez"]  = 1
}
local Texture2 = {
  ["$basetexture"] = "models/debug/debugwhite",
  ["$model"]       = 1,
  ["$translucent"] = 1,
  ["$alpha"]       = 1,
  ["$nocull"]      = 1
}
   
local material = CreateMaterial( "b_solid", "VertexLitGeneric", Texture )
local material2 = CreateMaterial( "b_solid2", "VertexLitGeneric", Texture2 )

return material,material2

end

function AA:bChams()
for k, v in pairs( ents.FindByClass("npc_*") ) do
if ValidEntity( v ) then
cam.Start3D( EyePos(), EyeAngles() )
local m,m2 = bMaterial()
render.SuppressEngineLighting( true )
render.SetColorModulation( 0, 0, 255 )
SetMaterialOverride( m )
v:DrawModel()
render.SuppressEngineLighting( false )
render.SetColorModulation( 255, 0, 0 )
SetMaterialOverride(m2)
v:DrawModel()
SetMaterialOverride(0)
cam.End3D()
			end
			end
for k, v in pairs( ents.FindByClass("combine_mine") ) do
if ValidEntity( v ) then
cam.Start3D( EyePos(), EyeAngles() )
local m,m2 = bMaterial()
render.SuppressEngineLighting( true )
render.SetColorModulation( 0, 255, 0 )
SetMaterialOverride( m )
v:DrawModel()
render.SuppressEngineLighting( false )
render.SetColorModulation( 255, 0, 0 )
SetMaterialOverride(m2)
v:DrawModel()
SetMaterialOverride(0)
cam.End3D()
			end
		end
end
--AA:AddHook("HUDPaint", "drawesp")
AA:AddHook("RenderScreenspaceEffects", "bChams")
AA.ScreenMaxAngle = {
	Length = 0,
	FOV = 0,
	MaxAngle = 0
}
AA:CreateSetting("draw_maxangle", "Draw Max Angle", true)
function AA:DrawMaxAngle()
	if !self:Enabled() then return end

	// Check that we want to be drawing this...
	local show = AA:Setting("draw_maxangle")
	if !show then return end

	// We need a player for this to work...
	local ply = LocalPlayer()
	if !ValidEntity(ply) then return end

	local info = self.ScreenMaxAngle
	local maxang = AA:Setting("maxangle")
	
	local fov = PlyM["GetFOV"](ply)
	if GetViewEntity() == ply && (maxang != info.MaxAngle || fov != info.FOV) then
		local view = self:GetView()
			view.p = view.p + maxang

		local screen = (PlyM["GetShootPos"](ply) + (AngM["Forward"](view) * 100))
		screen = VecM["ToScreen"](screen)

		info.Length = math.abs((ScrH() / 2) - screen.y)

		info.MaxAngle = maxang
		info.FOV = fov
	end

	local length = info.Length

	local cx, cy = ScrW() / 2, ScrH() / 2
	for x = -1, 1 do
		for y = -1, 1 do
			if x != 0 || y != 0 then
				local add = VecM["GetNormal"](Vector(x, y, 0)) * length
				surface.SetDrawColor(0, 0, 0, 255)
				surface.DrawRect((cx + add.x) - 2, (cy + add.y) - 2, 5, 5)
				surface.SetDrawColor(255, 255, 255, 255)
				surface.DrawRect((cx + add.x) - 1, (cy + add.y) - 1, 3, 3)
			end
		end
	end

end
AA:AddHook("HUDPaint", "DrawMaxAngle")

// ##################################################
// Auto-shoot
// ##################################################

AA.AttackDown = false
function AA:SetShooting(bool)
	if self.AttackDown == bool then return end
	self.AttackDown = bool

	local pre = {[true] = "+", [false] = "-"}
	RunConsoleCommand(pre[bool] .. "attack")
end

AA.NextShot = 0
AA:CreateSetting("autoshoot", "Max auto-shoot distance (0 to disable)", 0, {Min = 0, Max = 16384})
function AA:Shoot()
	if !self:Enabled() then
		self:SetShooting(false)
		return
	end

	// Get the maximum distance.
	local maxDist = self:Setting("autoshoot")
	if maxDist == 0 then return end

	// Check we've got something to shoot at...
	local target = self:GetTarget()
	if !target then return end
	
	// Don't shoot until we can hit, you idiot!
	local blocked, wrongAim = self:TargetBlocked(target)
	if blocked || wrongAim then return end

	// We're gonna need the player object in a second.
	local ply = LocalPlayer()
	if !ValidEntity(ply) then return end
	
	// Check we're within our maximum distance.
	local targetPos = self:TargetPosition(target)
	local distance = VecM["Length"](targetPos - ply:GetShootPos())
	if distance > maxDist && maxDist != -1 then return end

	// Check if it's time to shoot yet.
	if CurTime() < self.NextShot then return end

	// Check we got our weapon.
	local weap = PlyM["GetActiveWeapon"](ply)
	if !ValidEntity(weap) then return end

	// Shoot!
	self:SetShooting(true)
	// If we're semi-auto, we want to stop holding down fire.
	if self:IsSemiAuto(weap) then
		timer.Simple(0.05, function() self:SetShooting(false) end)
	end

	// Set the next time to shoot.
	self.NextShot = CurTime() + 0.1
end
AA:AddHook("Think", "Shoot")

// When we lose our target we stop shooting.
function AA:StopShooting()
	self:SetShooting(false)
end
AA:AddHook("TargetLost", "StopShooting")

// ##################################################
// Toggle
// ##################################################

AA.IsEnabled = false
function AA:Enabled() return self.IsEnabled end

function AA:SetEnabled(bool)
	if self.IsEnabled == bool then return end
	self.IsEnabled = bool

	local message = {[true] = "ON", [false] = "OFF"}
	print("AutoAim " .. message[self.IsEnabled])

	local e = {[true] = "1", [false] = "0"}
	RunConsoleCommand("aa_enabled", e[self.IsEnabled])

	self:CallHook("OnToggled")
end

function AA:Toggle()
	self:SetEnabled(!self:Enabled())
end
concommand.Add("aa_toggle", function() AA:Toggle() end)

AA:CreateSetting("enabled", "Enabled", false, {Save = false})
function AA:ConVarEnabled(_, old, val)
	if old == val then return end
	val = tonumber(val) or 0
	self:SetEnabled(val > 0)
end
AA:AddCVarHook("aa_enabled", "ConVarEnabled")

concommand.Add("+aa", function() AA:SetEnabled(true) end)
concommand.Add("-aa", function() AA:SetEnabled(false) end)

// ##################################################
// Menu
// ##################################################

function AA:OpenMenu()
	local w, h = ScrW() / 3, ScrH() / 2

	local menu = vgui.Create("DFrame")
	menu:SetTitle("AA")
	menu:SetSize(w, h)
	menu:Center()
	menu:MakePopup()

	local scroll = vgui.Create("DPanelList", menu)
	scroll:SetPos(5, 25)
	scroll:SetSize(w - 10, h - 30)
	scroll:EnableVerticalScrollbar()

	local form = vgui.Create("DForm", menu)
	form:SetName("")
	form.Paint = function() end
	scroll:AddItem(form)

	self:BuildMenu(form)

	if AA.Menu then AA.Menu:Remove() end
	AA.Menu = menu
end
concommand.Add("aa_menu", function() AA:OpenMenu() end)

function AA:RegisterMenu()
	spawnmenu.AddToolMenuOption("Options", "Hacks", "AA", "AA", "", "", function(p) self:BuildMenu(p) end)
end
AA:AddHook("PopulateToolMenu", "RegisterMenu")

// ##################################################
// Useful functions
// ##################################################

function AA:AngleBetween(a, b)
	return math.deg(math.acos(VecM["Dot"](a, b)))
end

function AA:NormalizeAngle(ang)
	return Angle(math.NormalizeAngle(ang.p), math.NormalizeAngle(ang.y), math.NormalizeAngle(ang.r))
end

function AA:ApproachAngle(start, target, add)
	local diff = self:NormalizeAngle(target - start)

	local vec = Vector(diff.p, diff.y, diff.r)
	local len = VecM["Length"](vec)
	vec = VecM["GetNormal"](vec) * math.min(add, len)

	return start + Angle(vec.x, vec.y, vec.z)
end

local notAuto = {"weapon_pistol", "weapon_rpg", "weapon_357", "weapon_crossbow"}
function AA:IsSemiAuto(weap)
	if !ValidEntity(weap) then return end
	return (weap.Primary && !weap.Primary.Automatic) || table.HasValue(notAuto, EntM["GetClass"](weap))
end
if not (CLIENT) then return end
local function validtargetesp(entz)
if !(entz:IsPlayer() or entz:IsNPC()) then return false end
if entz == LocalPlayer() then return false end
if entz:IsNPC() then 
if entz.IsDead == true then
return false
end
if entz:GetMoveType() == MOVETYPE_NONE then return false end
if entz:IsPlayer() then if entz:Health() < 1 then return false end end
if entz:IsNPC() then if entz.IsDead == true then return false end end
if entz:GetMoveType() == MOVETYPE_NONE then return false end
return true
end
end
local radar = {}
function DrawFadingColorBoxradar(x,y,w,h,alpha,mode)
if mode== 2 then
	local calculate = h/200
	local calculate2 = h/200
		for i=0,h do
		surface.SetDrawColor( 200-i/calculate, 200-i/calculate, 200-i/calculate, alpha)
		surface.DrawLine( x, i+y, x+w, i+y )
		end
else
	local calculate = h/200
	local calculate2 = h/200
		for i=0,h do
		surface.SetDrawColor( i/calculate, i/calculate, i/calculate, alpha)
		surface.DrawLine( x, i+y, x+w, i+y )
		end
end
end
function AA:drawbradar()
local target = self:GetTarget()
local textaaz = ""
	if !(ValidEntity(target)) then
	textaaz = ( "[autoaim Ultimate edition] Searching for target.")
	else
	if target:IsNPC() then
	textaaz = ( "[autoaim Ultimate edition] Target: "..target:GetClass())
	else
	textaaz = ( "[autoaim Ultimate edition] Target: "..target:GetName())
	end
	end
surface.SetFont("Default")
local sizwidth = surface.GetTextSize(textaaz)
surface.SetDrawColor( 0, 0, 0, 255 ); -- 68,68,68,255
surface.DrawRect( ScrW()/2-(sizwidth/2), 0, sizwidth, 48 ); 
DrawFadingColorBoxradar(ScrW()/2-(sizwidth/2),0,sizwidth,16,255,2)
DrawFadingColorBoxradar(ScrW()/2-(sizwidth/2),48-16,sizwidth,16,255,1)
surface.SetDrawColor( 90, 106, 79, 255 ); 
surface.DrawOutlinedRect( ScrW()/2-(sizwidth/2)-1, 0, sizwidth+1, 49 ); 
draw.SimpleText( textaaz, "Default", ScrW()/2, 16/2+16,Color(0,255,0,255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1)
surface.SetDrawColor( 0, 0, 0, 255 ); -- 68,68,68,255
surface.DrawRect( 0, 0, 200, 200 ); 
DrawFadingColorBoxradar(0,0,200,30,255,2)
DrawFadingColorBoxradar(0,200-31,200,30,255,1)
surface.SetDrawColor( 90, 106, 79, 255 ); 
surface.DrawOutlinedRect( 0, 0, 200, 200 ); 
surface.DrawLine( 10, 100, 190, 100 ); 
surface.DrawLine( 100, 10, 100, 190 );

--Default values
radar.w = 200
radar.h = 200
radar.x = 0
radar.y = 0
radar.alphascale = 0.6
radar.bgcolor = Color(255,0,0,255)
radar.fgcolor = Color(0,0,255,255)
radar.dangercolour = Color(220,0,0,255)
radar.dangerblipcolour = Color(255,255,0,255)
radar.screendetail = 64
radar.screenrotation = 0
radar.hazardmode = false    --doesnt work

radar.radius = 5000

radar.player_show = true
radar.player_color = Color(0,150,255,255)
surface.CreateFont("Arial",64,400,false,false,"RadarPlayerLabel")
radar.player_fontcolor = Color(255,255,255,255)
radar.player_showname = true
radar.player_showhealth = true
radar.player_showarmor = false --TO DO
radar.player_showammo = true


radar.scanfor = {"player", "blastfungus", "rpg_missile", "crossbow_bolt", "npc_", "sent_", "prop_vehicle_"}		-- What should the radar look for?  Accepts partial names.
radar.dangerous = {"sent_nuke_missile", "sent_nuke_detpack"}    --doesnt work

radar.bgcolorbak = radar.bgcolor
radar.fgcolorbak = radar.fgcolor
radar.player_colorbak = radar.player_color


local color_ascale = function(col,scale) return Color(col.r,col.g,col.b,col.a*scale) end

	local ETable = {}
	local PulseRadar = false

	local lpl = LocalPlayer()
	
	
	if ( radar.player_show ) then
	local vertices = {}
	for i=1,radar.screendetail do
		local shift = math.fmod(CurTime()*radar.screenrotation,360)
		local sizescale = 1
		local tab = {}
		tab.x = radar.x+radar.w/2 + math.cos(math.Deg2Rad((360/radar.screendetail)*i+shift)) * radar.w/2 * sizescale
		tab.y = radar.y+radar.h/2 + math.sin(math.Deg2Rad((360/radar.screendetail)*i+shift)) * radar.h/2 * sizescale
		tab.u = 0
		tab.v = 0
		table.insert(vertices,tab)
	end
	local players = {}

	for k,ent in pairs(ents.GetAll()) do

			if ent:IsValid() then
				local type = ent:GetClass()

				for k, v in ipairs(radar.scanfor) do
					if string.find(type,v) then
						table.insert(players,ent)
					end
				end
			end
		end
		for i, pl in ipairs(players) do
			local cx = radar.x+radar.w/2
			local cy = radar.y+radar.h/2
			local vdiff = pl:GetPos()-lpl:GetPos()
			local dummy = nil
				if pl:IsPlayer() then
					if ( pl:Alive() and lpl~=pl ) then
						local px = (vdiff.x/radar.radius)
						local py = (vdiff.y/radar.radius)
						local z = math.sqrt( px*px + py*py )
						local phi = math.Deg2Rad( math.Rad2Deg( math.atan2( px, py ) ) - math.Rad2Deg( math.atan2( lpl:GetAimVector().x, lpl:GetAimVector().y ) ) - 90 )
						px = math.cos(phi)*z
						py = math.sin(phi)*z
						draw.RoundedBox( 0, math.Clamp(cx+px*radar.w/2-4,0,190), math.Clamp(cy+py*radar.h/2-4,0,190), 8, 8, Color(0,100,255,255) )
						surface.SetDrawColor( 0,0,0,255 )
						surface.DrawOutlinedRect( math.Clamp(cx+px*radar.w/2-4,0,190), math.Clamp(cy+py*radar.h/2-4,0,190), 8, 8)
					end
				end
				if ((not pl:IsPlayer()) and pl:IsValid() ) then

				    local isDangerous = false
					if ( radar.hazardmode ) then
						for k,v in ipairs(radar.dangerous) do
						    if (pl:GetClass() == v) then
						        table.insert(ETable,pl)
						        isDangerous = true
							end
						end
					end
					
					local px = (vdiff.x/radar.radius)
					local py = (vdiff.y/radar.radius)
					local z = math.sqrt( px*px + py*py )
					local phi = math.Deg2Rad( math.Rad2Deg( math.atan2( px, py ) ) - math.Rad2Deg( math.atan2( lpl:GetAimVector().x, lpl:GetAimVector().y ) ) - 90 )
					px = math.cos(phi)*z
					py = math.sin(phi)*z

					if (isDangerous == false) then
						draw.RoundedBox( 0, math.Clamp(cx+px*radar.w/2-4,0,190), math.Clamp(cy+py*radar.h/2-4,0,190), 8, 8, Color(255,255,255,255) )
						surface.SetDrawColor( 0,0,0,255 )
						surface.DrawOutlinedRect( math.Clamp(cx+px*radar.w/2-4,0,190), math.Clamp(cy+py*radar.h/2-4,0,190), 8, 8)
					if pl:IsNPC() then
                        drawColor = Color( 255, 0, 0, 255 )
						draw.RoundedBox( 0, math.Clamp(cx+px*radar.w/2-4,0,190), math.Clamp(cy+py*radar.h/2-4,0,190), 8, 8, drawColor)
						surface.SetDrawColor( 0,0,0,255 )
						surface.DrawOutlinedRect( math.Clamp(cx+px*radar.w/2-4,0,190), math.Clamp(cy+py*radar.h/2-4,0,190), 8, 8)
					end
					end


					if radar.player_showname then

						local nametag = ""
						if string.find(pl:GetClass(),"blastfungus") then nametag = ""
						elseif string.find(pl:GetClass(),"npc_") then nametag = string.sub(pl:GetClass(),5)
						elseif string.find(pl:GetClass(),"sent_") then nametag = string.sub(pl:GetClass(),6)
						elseif string.find(pl:GetClass(),"prop_vehicle_") then nametag = string.sub(pl:GetClass(),14)
						else nametag = pl:GetClass()
						end

						local nametable = string.Explode("_",nametag)
						nametag = table.concat(nametable," ")
						local nametag1 = string.sub(nametag,0,1)
						local nametag2 = string.sub(nametag,2)
						nametag1 = string.upper(nametag1)
						nametag = nametag1..nametag2


					end
				end
   			end
	 	end
   		local count = table.Count(ETable)
   		
   		if ( count > 0 ) then
   		for k,pl in ipairs(ETable) do
   			local cx = radar.x+radar.w/2
			local cy = radar.y+radar.h/2
			local vdiff = pl:GetPos()-lpl:GetPos()
			
   			local px = (vdiff.x/radar.radius)
			local py = (vdiff.y/radar.radius)
			local z = math.sqrt( px*px + py*py )
			local phi = math.Deg2Rad( math.Rad2Deg( math.atan2( px, py ) ) - math.Rad2Deg( math.atan2( lpl:GetAimVector().x, lpl:GetAimVector().y ) ) - 90 )
			px = math.cos(phi)*z
			py = math.sin(phi)*z
						draw.RoundedBox( 0, math.Clamp(cx+px*radar.w/2-4,0,190), math.Clamp(cy+py*radar.h/2-4,0,190), 8, 8, color_ascale(radar.player_color,255) )
						surface.SetDrawColor( 0,0,0,255 )
						surface.DrawOutlinedRect( math.Clamp(cx+px*radar.w/2-4,0,190), math.Clamp(cy+py*radar.h/2-4,0,190), 8, 8)
		end
			
			radar.bgcolor = Color(255,255,255,0)
			radar.fgcolor = Color(60,60,60,100)
			
			PulseRadar = true
		end
end
--AA:AddHook("HUDPaint", "drawbradar")
LoadTime = math.floor(LoadTime - CurTime())
if LoadTime < 0 then
	LoadTime = -LoadTime
end
print("[vHGmod v0.2] | Loaded in "..LoadTime.." seconds")
print("                                   By BB9")