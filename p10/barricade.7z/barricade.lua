local mat_shiny = Material( "models/shiny" )
 
hook.Add("HUDPaint","BarricadeWallHack",function()
	-- it might be prop_physics, prop_physics_multiplayer, func_physbox, func_physbox_multiplayer
	local props = ents.FindByClass("prop_physics*")
	table.Add(props,ents.FindByClass("func_physbox*")) 
 
	render.SuppressEngineLighting(true)
	render.MaterialOverride(mat_shiny)
 
	cam.Start3D()
	for _,ent in ipairs(props) do
		local health = math.Clamp(ent:GetBarricadeHealth() / ent:GetMaxBarricadeHealth(),0,1)
		local nailed = ent:IsNailed()
		local color = nailed and Vector(1 - health,health,0) or Vector(0,0.5,1)
 
		render.SetColorModulation(color.x,color.y,color.z)
		render.SetBlend( util.IsValidModel( ent:GetModel() ) and ( nailed and 0.3 - barricadeHealth * 0.1 or 0.2) or 1 )
		-- util.IsValidModel filtres map created models (idk how to fix its render)
 
		ent:DrawModel()
 
		render.SetBlend(1)
	end
	cam.End3D()
 
	render.SetColorModulation(1,1,1)
	render.MaterialOverride(nil)
	render.SuppressEngineLighting(false)
end)