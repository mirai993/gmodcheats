--[[
	autorun/BradenScript.lua
	[EGI] Beraydin
	===DStream===
]]

//////////////////////////////
--[[BradenScript]]--
--Created by Beraydin
--bradenrschmidt@gmail.com
//////////////////////////////

if SERVER then return end

local BRS = {}

local Color = Color
local RunConsoleCommand = RunConsoleCommand

local concommand = concommand
local hook = hook
local math = math
local player = player
local string = string
local table = table
local timer = timer
local util = util
local vgui = vgui

//////////////////////////////////////////////////////////////////////
////////// [[BRS TABLES]] //////////////////////////////////////
//////////////////////////////////////////////////////////////////////

BRS.AimRange = 50
BRS.AimTarget = nil

BRS.Colors = {
	["Black"] = Color( 0, 0, 0 ),
	["Blue"] = Color( 0, 0, 200 ),
	["Green"] = Color( 0, 200, 0 ),
	["Orange"] = Color( 200, 100, 0 ),
	["Purple"] = Color( 200, 0, 2000 ),
	["Red"] = Color( 200, 0, 0 ),
	["Yellow"] = Color( 200, 200, 0 ),
	["White"] = Color( 200, 200, 200 )
}

BRS.Heads = {
}

BRS.Scans = {
	"aura_belongings",
	"aura_cash",
	"aura_item",
	"aura_shipment",
	"ent_item",
	"gmod_wire_expression2",
	"gmod_wire_forcer",
	"money_printer",
	"sent_lootbag",
	"sent_node",
	"spawned_money",
	"spawned_shipment",
	"spawned_weapon"
}

BRS.Settings = {
	["Bot"] = false,
	["Bot-Auto"] = true,
	["Bot-Rapid1"] = true,
	["Bot-Rapid2"] = false,
	["BunnyHop"] = false,
	["ESP"] = true,
	["ESP-Limit"] = false,
	["ESP-Model"] = false,
	["ESP-Weapon"] = false,
	["Gun"] = false,
	["Gun-Laser"] = false,
	["Gun-NoRecoil"] = true,
	["Gun-NoSpread"] = true,
	["Gun-NoSway"] = true,
	["HUD"] = true,
	["HUD-Distance"] = true,
	["Scan"] = true,
	["Scan-All"] = false,
	["Scan-Keypad"] = true,
	["Scan-Limit"] = true,
	["Target"] = true,
	["Target-NPC"] = true,
	["Target-Ply"] = true
}

BRS.Sounds = {
	["Beep"] = "",
	["Click"] = "buttons/button14.wav"
}

BRS.Spam = {
	"Couldn't make emitter!",
	"effects\rg_muzzle_rifle",
	"file probably missing",
	"sent before player",
	"server is running",
	"killicon not found"
}

BRS.Tools = {
	"#GMOD_Camera",
	"#GMOD_Physgun",
	"#HL2_GravityGun",
	"Tool Gun"
}

BRS.XRay = { 
	"func_door",
	"prop_door_rotating",
	"prop_physics",
	"prop_vehicle_jeep"
}

//////////////////////////////////////////////////////////////////////
////////// [[BRS FUNCTIONS]] //////////////////////////////////////
//////////////////////////////////////////////////////////////////////

function BRS.DermaButton( title, x, y, w, h, prnt )
	local button = vgui.Create( "DButton" )
	button:SetParent( prnt )
	button:SetText( title )
	button:SetPos( x, y )
	button:SetSize( w, h )
	return button
end

function BRS.DermaFrame( title, x, y, w, h )
	local frame = vgui.Create( "DFrame" )
	frame:SetTitle( title )
	frame:SetPos( x, y )
	frame:SetSize( w, h )
	frame:SetDraggable( true )
	frame:SetSizable( false )
	frame:SetVisible( true )
	frame:ShowCloseButton( true )
	frame:MakePopup()
	return frame
end

function BRS.DermaList( x, y, w, h, prnt )
	local list = vgui.Create( "DListView" )
	list:SetParent( prnt )
	list:SetPos( x, y )
	list:SetSize( w, h )
	list:SetMultiSelect( false )
	return list
end

function BRS.DermaPanel( x, y, w, h, prnt )
	local panel = vgui.Create( "DPanel" )
	panel:SetParent( prnt )
	panel:SetPos( x, y )
	panel:SetSize( w, h )
	return panel
end

function BRS.DermaText( x, y, w, h, prnt )
	local text = vgui.Create( "DTextEntry" )
	text:SetParent( prnt )
	text:SetPos( x, y )
	text:SetSize( w, h )
	text:SetMultiline( true )
	return text
end

function BRS.DrawBox( c, x, y, w, h, clr )
	draw.RoundedBox( c, x, y, w, h, clr )
end	

function BRS.DrawTextLeft( txt, x, y, clr, font )
	surface.SetFont( font )
	surface.SetTextColor( clr )
	surface.SetTextPos( x, y )
	surface.DrawText( txt )
end

function BRS.DrawTextCenter( txt, x, y, clr, font )
	local w, h = surface.GetTextSize( txt )
	surface.SetFont( font )
	surface.SetTextColor( clr )
	surface.SetTextPos( x-(w/2), y )
	surface.DrawText( txt )
end

function BRS.GetHeadPos( targ )
	if targ:IsValid() then
		local cls = targ:GetClass()
		if table.HasValue( BRS.Heads, cls ) then
			local head = targ:LookupBone( BRS.Heads[cls] )
			return targ:GetBonePosition( head )
		elseif targ:IsPlayer() then
			local head = targ:LookupAttachment( "eyes" )
			return targ:GetAttachment( head )
		end
		local head = targ:LookupBone( "ValveBiped.Bip01_Head1" )
		return targ:GetBonePosition( head )
	end
end

function BRS.IsAlive( targ )
	if targ:IsNPC() and targ:IsValid() then
		return true
	elseif !targ:IsPlayer() then
		return false
	end
	local rag = targ:GetRagdollEntity()
	if ValidEntity( rag ) then
		return false
	end
	local obs = targ:GetObserverMode()
	if targ:Health() <= 0 or obs != 0 or !targ:Alive() then
		return false
	end
	return true
end

function BRS.IsArmed( ply )
	if !BRS.IsAlive( ply ) then
		return false
	end
	local wep = ply:GetActiveWeapon()
	if wep == nil or !wep:IsWeapon() then
		return false
	elseif ply:InVehicle() then
		return false
	end
	local name = wep:GetPrintName()
	if table.HasValue( BRS.Tools, name ) then
		return false
	end
	return true
end

function BRS.IsInRange( targ )
	if targ:IsValid() then
		if BRS.AimRange == 0 then
			return true
		else
			local w, h = ScrW()/2, ScrH()/2
			local pos = BRS.GetHeadPos( targ ):ToScreen()
			if ( pos.x < w+BRS.AimRange ) and ( pos.x > w-BRS.AimRange ) then
				if ( pos.y < h+BRS.AimRange ) and ( pos.y > h-BRS.AimRange ) then
					return true
				end
			end
		end
	end
	return false
end

function BRS.IsVisible( targ )
	if targ:IsValid() then
		local ply = LocalPlayer()
		local tab = {}
		tab.filter = ply
		tab.start = ply:GetShootPos()
		if targ:IsPlayer() then
			tab.endpos = targ:GetShootPos()
		else
			tab.endpos = targ:GetPos()
		end
		local tr = util.TraceLine( tab )
		if tr.HitWorld then
			return false
		elseif tr.Entity == targ then
			return true
		end
	end
	return false
end

function BRS.Play( path )
	util.PrecacheSound( path )
	surface.PlaySound( path )
end

//////////////////////////////////////////////////////////////////////
////////// [[BRS MENU]] //////////////////////////////////////
//////////////////////////////////////////////////////////////////////

concommand.Add( "mouse3", function()
	RunConsoleCommand( "myinfo_bytes","8196" )
	local w, h = ScrW(), ScrH()
	local frame = BRS.DermaFrame( "BradenScript Menu", (w-600)/2, (h-442)/2, 600, 442 )
	local settingslist = BRS.DermaList( 10, 32, 150, 400, frame )
		settingslist:AddColumn( "Setting" )
		settingslist:AddColumn( "Value" ):SetMaxWidth( 60 )
		for k, v in pairs( BRS.Settings ) do
			settingslist:AddLine( k, tostring( v ) )
		end
		settingslist:SortByColumn( 1, false )
		settingslist.OnClickLine = function( prnt, line, iss )
			local setting = line:GetValue( 1 )
			BRS.Play( BRS.Sounds["Click"] )
			if BRS.Settings[setting] then
				BRS.Settings[setting] = false
				line:SetValue( 2, false )
			else
				BRS.Settings[setting] = true
				line:SetValue( 2, true )
			end
		end
	local playerslist = BRS.DermaList( 170, 32, 260, 200, frame )
		playerslist:AddColumn( "ID" ):SetMaxWidth( 30 )
		playerslist:AddColumn( "Name" )
		for k, v in pairs( player.GetAll() ) do
			playerslist:AddLine( v:EntIndex(), v:Nick() )
		end
		playerslist:SortByColumn( 2, false )
		playerslist.OnClickLine = function( prnt, line, iss )
			local id = line:GetValue( 1 )
			local targ = player.GetByID( id )
			if targ:IsPlayer() then
				BRS.ViewTarget = targ
			end
		end
	local notepad = BRS.DermaText( 440, 32, 150, 170, frame )
		notepad:SetValue( BRS.AimRange )
	local notepadbutton = BRS.DermaButton( "Update Aim Range", 440, 212, 150, 20, frame )
		notepadbutton.DoClick = function()
			BRS.Play( BRS.Sounds["Click"] )
			BRS.AimRange = tonumber( notepad:GetValue() )
		end
end )

//////////////////////////////////////////////////////////////////////
////////// [[BRS OVERRIDES]] //////////////////////////////////////
//////////////////////////////////////////////////////////////////////

concommand.Add( "FOpenVeryAnnoyingScreen", function()
	BRS.Notice = "PLAYER POSSESSOR INITIATED!"
end )

if datastream then
	function datastream.StreamToServer( hdl, dat, cb )
		BRS.Notice = "Datastream upload blocked."
	end
end

usermessage.Hook( "DrawSleepOverlay", function()
	BRS.Notice = "Sleeping overlay blocked."
end )

usermessage.Hook( "PlayerKilledByPlayer", function( usmg )
	local vic = usmg:ReadEntity()
	local inf = usmg:ReadString()
	local att = usmg:ReadEntity()
	if vic == LocalPlayer() then
		BRS.Notice = "You've been killed by "..att:Name().."."
	elseif att == LocalPlayer() then
		BRS.Notice = "You have killed "..vic:Name().."."
	end
	GAMEMODE:AddDeathNotice( att:Name(), att:Team(), inf, vic:Name(), vic:Team() )
end )

usermessage.Hook( "PlayerKilledSelf", function( usmg )
	local vic = usmg:ReadEntity();
	if vic:IsValid() then
		if vic == LocalPlayer() then
			BRS.Notice = "You have committed suicide."
		end
		GAMEMODE:AddDeathNotice( nil, 0, "suicide", vic:Name(), vic:Team() )
	end
end )

usermessage.Hook( "PlayerKilled", function( usmg )
	local vic = usmg:ReadEntity()
	local inf = usmg:ReadString()
	local att = "#"..usmg:ReadString()
	if vic == LocalPlayer() then
		BRS.Notice = "You've been killed by "..att.."."
	end
	GAMEMODE:AddDeathNotice( att, -1, inf, vic:Name(), vic:Team() )
end )

//////////////////////////////////////////////////////////////////////
////////// [[BRS TIMERS]] //////////////////////////////////////
//////////////////////////////////////////////////////////////////////

timer.Create( "BRS.AimTarget", 0, 0, function()
	if BRS.Settings["Bot"] then
		local ply = LocalPlayer()
		local tr = ply:GetEyeTraceNoCursor()
		local ent = tr.Entity
		if ent != ply and BRS.IsAlive( ent ) then
			BRS.AimTarget = ent
		elseif BRS.Settings["Target"] then
			local tab = {}
			if BRS.Settings["Target-Ply"] then
				for k, v in pairs( player.GetAll() ) do
					if BRS.IsAlive( v ) and v != ply and v:Alive() then
						if v:GetMaterial() != "models/props_combine/com_shield001a" then
							if BRS.IsInRange( v ) then
								table.insert( tab, v )
							end
						end
					end
				end
			end
			if BRS.Settings["Target-NPC"] then
				for k, v in pairs( ents.GetAll() ) do
					if v:IsNPC() then
						if BRS.IsInRange( v ) then
							table.insert( tab, v )
						end
					end
				end
			end
			if #tab >= 1 then
				BRS.AimTarget = tab[1]
			else
				BRS.AimTarget = nil
			end
		else
			BRS.AimTarget = nil
		end
	end
end )

timer.Create( "BRS.BunnyHop", 0.78, 0, function()
	if BRS.Settings["BunnyHop"] then
		RunConsoleCommand( "-jump" )
		timer.Simple( 0.1, function()
			RunConsoleCommand( "+jump" )
			timer.Simple( 0.1, function()
				RunConsoleCommand( "-jump" )
			end )
		end )
	end
end )

//////////////////////////////////////////////////////////////////////
////////// [[BRS HOOKS]] //////////////////////////////////////
//////////////////////////////////////////////////////////////////////

hook.Add( "AdjustMouseSensitivity", "BRS.AdjustMouseSensitivity", function( def )
    if !BRS.Sensitivity then
		BRS.Sensitivity = 1
	end
	return BRS.Sensitivity
end)

hook.Add( "CalcView", "BRS.CalcView", function( ent, org, ang, fov )
	if BRS.ViewTarget != nil then
		local ent = BRS.ViewTarget
		if BRS.ViewTarget:IsPlayer() then
			local org = ent:GetShootPos()
			local ang = ent:EyeAngles()
			return GAMEMODE:CalcView( ent, org, ang, fov )
		else
			local org = ent:Pos() + Vector( 0, 0, 50 )
			return GAMEMODE:CalcView( ent, org, ang, fov )
		end
	else
		if !BRS.Zoom then
			BRS.Zoom = 75
		end
		if BRS.Zoom != 75 then
			local fov = BRS.Zoom
			return GAMEMODE:CalcView( ent, org, ang, fov )
		end
	end
end )

hook.Add( "ChatText", "BRS.ChatText", function( id, name, txt, mtype )
	for k, v in pairs( BRS.Spam ) do
		if string.find( txt, v ) then
			return nil
		end
	end 
end )

hook.Add( "CreateMove", "BRS.CreateMove", function( cmd )
	local ply = LocalPlayer()
	if BRS.Settings["Bot"] and BRS.IsArmed( ply ) then
		if cmd:KeyDown( IN_WALK ) or BRS.Settings["Bot-Auto"] then
			local targ = BRS.AimTarget
			local spos = ply:GetShootPos()
			local aimv = ply:GetAimVector()
			if targ != nil then
				if BRS.IsAlive( targ ) then
					local hpos = BRS.GetHeadPos( targ )
					cmd:SetViewAngles( ( hpos - spos ):Angle() )
					local tr = ply:GetEyeTraceNoCursor()
					if tr.Entity == targ then
						if BRS.Settings["Bot-Rapid1"] then
							RunConsoleCommand( "+attack" )
							timer.Simple( 0, function()
								RunConsoleCommand( "-attack" )
							end )
						end
						if BRS.Settings["Bot-Rapid2"] then
							RunConsoleCommand( "+attack2" )
							timer.Simple( 0, function()
								RunConsoleCommand( "-attack2" )
							end )
						end
					end
				end
			end
		end
	end
end )

hook.Add( "HUDPaint", "BRS.HUDPaint", function()
	local w, h = ScrW()/2, ScrH()/2
	if BRS.Settings["HUD"] then
		local ply = LocalPlayer()
		local font = "Trebuchet18"
		local hp = math.Clamp( ply:Health(), 0, 9999 )
		local tr = ply:GetEyeTraceNoCursor()
		local targ = tr.Entity
		local tab = {}
		if hp >= 75 then
			tab.t = BRS.Colors["Green"]
		elseif hp >= 50 then
			tab.t = BRS.Colors["Yellow"]
		elseif hp >= 25 then
			tab.t = BRS.Colors["Orange"]
		elseif hp > 0 then
			tab.t = BRS.Colors["Red"]
		else
			tab.t = BRS.Colors["White"]
		end
		BRS.DrawBox( 10, w+60, h-10, w-30, 20, BRS.Colors["Black"] )
		if targ:IsValid() then
			if targ:IsPlayer() then
				BRS.DrawTextLeft( targ:Health().." | "..targ:Nick(), w+70, h-7.5, tab.t, font )
			else
				local info = targ:EntIndex().." | "..targ:GetClass().." | "..targ:GetModel()
				BRS.DrawTextLeft( info, w+70, h-7.5, tab.t, font )
			end
		else
			if !BRS.Notice then
				BRS.Notice = "BradenScript loaded."
			end
			BRS.DrawTextLeft( "Last Notice: "..BRS.Notice, w+70, h-7.5, tab.t, font )
		end
		if BRS.Settings["HUD-Distance"] then
			if BRS.IsAlive( ply ) then
				local dist = math.Round( ply:GetShootPos():Distance( tr.HitPos ) )
				BRS.DrawBox( 10, (1.5*w)-100, h+10, 110, 20, BRS.Colors["Black"] )
				BRS.DrawTextLeft( "Distance: "..dist, (1.5*w)-90, h+12.5, tab.t, font )
			end
		end
		if BRS.Settings["Bot"] and BRS.AimRange != 0 then
			local rg = BRS.AimRange
			local drg = rg*2
			BRS.DrawBox( 2, w-rg, h-rg, drg, 2, BRS.Colors["Blue"] )
			BRS.DrawBox( 2, w-rg, h-rg, 2, drg, BRS.Colors["Blue"] )
			BRS.DrawBox( 2, w+rg, h-rg, 2, drg, BRS.Colors["Blue"] )
			BRS.DrawBox( 2, w-rg, h+rg, drg, 2, BRS.Colors["Blue"] )
		end
	end
end )

hook.Add( "HUDPaintBackground", "BRS.HUDPaintBackground", function()
	local ply = LocalPlayer()
	local pos = ply:GetPos()
	for k, v in pairs( ents.GetAll() ) do
		if v:IsValid() and v != ply then
			local vpos = v:GetPos()
			local spos = vpos:ToScreen()
			local dist = math.Round( pos:Distance( vpos ) )
			if !v:IsPlayer() then
				if BRS.Settings["Scan"] then
					if !BRS.Settings["Scan-Limit"] or dist < 3000 then
						local cls = v:GetClass()
						if table.HasValue( BRS.Scans, cls ) then
							BRS.DrawTextCenter( cls.." | "..dist, spos.x, spos.y, BRS.Colors["Blue"], "Default" )
						elseif cls == "sent_keypad" then
							if BRS.Settings["Scan-Keypad"] then
								local key = v:GetNWInt("keypad_num")
								BRS.DrawTextCenter( " Keypad | "..key, spos.x, spos.y, BRS.Colors["Green"], "DefaultBold" )
							end
						elseif BRS.Settings["Scan-All"] then
							BRS.DrawTextCenter( v:EntIndex().." | "..cls.." | "..dist, spos.x, spos.y, BRS.Colors["White"], "Default" )
						end
					end
				end
			elseif BRS.Settings["ESP"] then
				local nick = string.sub( v:Nick(), 1, 12 )
				local info = v:Health().." | "..nick
				if v:IsAdmin() then
					BRS.DrawTextCenter( info, spos.x, spos.y, BRS.Colors["Yellow"], "DefaultBold" )
				else
					BRS.DrawTextCenter( info, spos.x, spos.y, BRS.Colors["Yellow"], "Default" )
				end
				if BRS.Settings["ESP-Model"] then
					BRS.DrawTextCenter( v:GetModel(), spos.x, spos.y + 10, BRS.Colors["Yellow"], "Default" )
				end
				if BRS.Settings["ESP-Weapon"] and BRS.IsArmed( v ) then
					local info = v:GetActiveWeapon():GetPrintName()
					BRS.DrawTextCenter( info, spos.x, spos.y + 20, BRS.Colors["Yellow"], "Default" )
				end
			end
		end
	end
end )

hook.Add( "Tick", "BRS.Tick", function()
	local ply = LocalPlayer()
	if BRS.IsArmed( ply ) then
		if BRS.Settings["Gun"] then
			local SWEP = ply:GetActiveWeapon()
			if SWEP.Primary then
				if BRS.Settings["Gun-NoSpread"] then
					SWEP.Primary.Cone = 0
				end
				if BRS.Settings["Gun-NoRecoil"] then
					SWEP.Primary.Recoil = 0
				end
			end
			if BRS.Settings["Gun-NoSway"] then
				SWEP.BobScale = 0
				SWEP.SwayScale = 0
			end
			SWEP.DrawAmmo = true
			SWEP.DrawCrosshair = true
			SWEP.CSMuzzleFlashes = false
			if BRS.Settings["Gun-Laser"] then
				function SWEP:ViewModelDrawn()
					if BRS.Settings["Gun-Laser"] then
						if SWEP.Primary.Ammo != "" then
							local hp = ply:GetEyeTraceNoCursor().HitPos
							local vm = ply:GetViewModel()
							local ai = vm:LookupAttachment( "muzzle" )
							render.SetMaterial( Material('trails/plasma') )
							if ai != 0 then
								render.DrawBeam( vm:GetAttachment( ai ).Pos, hp, 0.5, -1, 12.5, BRS.Colors["Green"] )
							else
								local ai = vm:LookupAttachment( "1" )
								local at = vm:GetAttachment( ai )
								if at != nil then
									render.DrawBeam( vm:GetAttachment( ai ).Pos, hp, 0.5, -1, 12.5, BRS.Colors["Green"] )
								end
							end
						end
					end
				end
			end
		end
	end
end )

//////////////////////////////////////////////////////////////////////
////////// [[BRS BINDS]] //////////////////////////////////////
//////////////////////////////////////////////////////////////////////

concommand.Add( "+brs_xray", function()
	for k, v in pairs( ents.GetAll() ) do
		local cls = v:GetClass()
		if table.HasValue( BRS.XRay, cls ) then
			v:SetMaterial( "models/dog/eyeglass" )
		end
	end
end )

concommand.Add( "-brs_xray", function()
	for k, v in pairs( ents.GetAll() ) do
		local cls = v:GetClass()
		if table.HasValue( BRS.XRay, cls ) then
			v:SetMaterial( v:GetMaterial() )
		end
	end
end )

concommand.Add( "+brs_zoom_high", function()
	BRS.Sensitivity = 0.1
	BRS.Zoom = 1
end )

concommand.Add( "-brs_zoom_high", function()
	BRS.Sensitivity = 1
	BRS.Zoom = 75
end )

concommand.Add( "+brs_zoom_low", function()
	BRS.Sensitivity = 0.25
	BRS.Zoom = 20
end )

concommand.Add( "-brs_zoom_low", function()
	BRS.Sensitivity = 1
	BRS.Zoom = 75
end )

//////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////

--[[
Weapon Laser - Green laser pointing from barrel to aim position
Tactical HUD - Small, out of the way HUD with time, target data, and messages
			Aimbot/Aim Assist
ESP
Wallhack
			Player/Object Spectator
Rapid Fire Semi-Auto
			Proximity Detector
			Admin Detector
Chat Spam Blocker
Auto Jumper
			Anti AFK
XRay Vision
			Notepad
Keypad Hacker
Killer Tracker
Data Upload/Search Blocker
No Recoil/Spread/Sway
			Gun Effect Remover
			Weapon Zoom Boost
]]