--[[
	lua/Hacks/NumbHack.lua
	SimpleIsTheBest | (STEAM_0:1:60333045)
	===DStream===
]]

--[[
Copyright :: All Rights Reserved
Registered :: 2013-03-01 21:30:12
Title :: Numbbot.lua
Category :: Lua file 
Credits: Made by OverDone     
]]

/************************************
Name: Localizing
Purpose: Make the cheat run faster
************************************/

if ( SERVER ) then return end

local g 					= table.Copy(_G)
local Numb					= {} -- Nothing!
Numb.settings				= {} -- Not started yet.
Numb.hooks					= {} -- Store hooks in a table
Numb.concommands			= {} -- Store concommands in a table
Numb.convars				= {} -- Store the ConVars in a table
Numb.timers					= {} -- Store Timers in a table
Numb.files					= {"Numb.lua", "Log.txt"} -- Files to hide and protect
Numb.version				= "2.3" -- Version of the cheat.
Numb.ents					= { -- ents to be picked up by entity esp, add more if you want.
"ent_pot",
"npc_vendor",
"weapon_perp_glock",
"ent_item",
"ent_prop_item",
"sent_spawnpoint",
"spawned_weapon",
"spawned_shipment",
"weed_plant",
"gift",
"spawned_money",
"base_item",
"weapon_ak47_dayz",
"weapon_mp5_dayz",
"weapon_deagle_dayz",
"sapphire_money_printer",
"amethyst_money_printer",
"topaz_money_printer",
"emerald_money_printer",
"msc_scrapnug",
"food_rawant",
"ent_resource",
"food_rawhead",
"gmodz_item", -- TPS DayZ
"drug_plant",
}
Numb.badcmds				= { -- commands to be blocked
"__ac",
"__imacheater",
"gm_possess",
"achievementRefresh", -- fuck u lifepunch
"__uc_", -- RIOT
"_____b__c",
"___m",
"sc",
"bg",
"bm",
"kickme",
"gw_iamacheater",
"imafaggot",
"birdcage_browse",
"reportmod",
"_fuckme",
"st_openmenu",
"_NOPENOPE",
"__ping",
"ar_check",
"GForceRecoil",
"~__ac_auth",
"blade_client_check",
"blade_client_detected_message",
"disconnect",
"exit",
"retry",
"kill",
"-voicerecord",
"+voicerecord",
"dac_imcheating", -- fuck u bich
"dac_pleasebanme", -- fuck u bich
"excl_banme", -- fuck u bitch
}

-- Crosshair shit
local x = ScrW() / 2 			--Crosshair
local y = ScrH() / 2 			--Crosshair
local gap 			= 0 		--Crosshair Gap
local length 		= 5 		--Crosshair Length
-- To get one crosshair working. I know pain in the ass!


Numb.spectators				= {} -- Store spectators here.
Numb.admins					= {} -- store admins here
Numb.config					= {} -- user config
Numb.dev						= { -- for module shit
"STEAM_0:1:60333045",
}

local colors				= {}
red							= Color(255,0,0,255);
black						= Color(0,0,0,255);
green						= Color(0,255,0,255);
white						= Color(255,255,255,255);
blue						= Color(0,0,255,255);
cyan						= Color(0,255,255,255);
pink 						= Color(255,0,255,255);
blue						= Color(0,0,255,255);
grey						= Color(100,100,100,255);
gold						= Color(255,228,0,255);
lblue						= Color(155,205,248);
lgreen						= Color(174,255,0);
iceblue						= Color(116,187,251,255);

local _G					= table.Copy(_G)

local math 					= _G.math
local string 				= _G.string
local hook 					= _G.hook
local table 				= _G.table
local timer 				= _G.timer
local surface 				= _G.surface
local concommand 			= _G.concommand
local cvars 				= _G.cvars
local ents 					= _G.ents
local player 				= _G.player
local team 					= _G.team
local util 					= _G.util
local draw 					= _G.draw
local usermessage 			= _G.usermessage
local vgui 					= _G.vgui
local http 					= _G.http
local cam 					= _G.cam
local render 				= _G.render

local MsgN 					= _G.MsgN
local Msg 					= _G.Msg
local Vector 				= _G.Vector
local Angle 				= _G.Angle
local pairs 				= _G.pairs
local ipairs 				= _G.ipairs
local CreateSound 			= _G.CreateSound
local setmetatable 			= _G.setmetatable
local Sound 				= _G.Sound
local print 				= _G.print
local pcall 				= _G.pcall
local type 					= _G.type
local LocalPlayer 			= _G.LocalPlayer
local KeyValuesToTable 		= _G.KeyValuesToTable
local TableToKeyValues 		= _G.TableToKeyValues
local Color 				= _G.Color
local CreateClientConVar 	= _G.CreateClientConVar
local ErrorNoHalt 			= _G.ErrorNoHalt
local IsValid 				= _G.IsValid
local CreateMaterial 		= _G.CreateMaterial
local tonumber 				= _G.tonumber
local tostring 				= _G.tostring
local CurTime			 	= _G.CurTime
local FrameTime 			= _G.FrameTime
local ScrW 					= _G.ScrW
local ScrH 					= _G.ScrH
local SetClipboardText 		= _G.SetClipboardText
local GetHostName 			= _G.GetHostName
local unpack 				= _G.unpack
local AddConsoleCommand 	= _G.AddConsoleCommand 
local require				= _G.require
local include				= _G.include

local MOVETYPE_OBSERVER 	= _G.MOVETYPE_OBSERVER
local MOVETYPE_NONE 		= _G.MOVETYPE_NONE
local TEXT_ALIGN_LEFT 		= _G.TEXT_ALIGN_LEFT
local TEXT_ALIGN_TOP 		= _G.TEXT_ALIGN_TOP
local TEXT_ALIGN_RIGHT 		= _G.TEXT_ALIGN_RIGHT
local TEXT_ALIGN_BOTTOM		= _G.TEXT_ALIGN_BOTTOM
local IN_JUMP 				= _G.IN_JUMP
local IN_FORWARD 			= _G.IN_FORWARD
local IN_BACK 				= _G.IN_BACK
local IN_MOVERIGHT 			= _G.IN_MOVERIGHT
local IN_MOVELEFT 			= _G.IN_MOVELEFT
local IN_SPEED 				= _G.IN_SPEED
local IN_DUCK 				= _G.IN_DUCK
local TEAM_SPECTATOR 		= 1002

-- old [copy]
local old_filecdir 			= file.CreateDir;
local old_filedel 			= file.Delete;
local old_fileexist 		= file.Exists;
local old_fileexistex 		= file.ExistsEx;
local old_filefind 			= file.Find;
local old_filefinddir 		= file.FindDir;
local old_filefindil 		= file.FindInLua;
local old_fileisdir			= file.IsDir;
local old_fileread 			= file.Read;
local old_filerename 		= file.Rename;
local old_filesize 			= file.Size;
local old_filetfind			= file.TFind;
local old_filetime 			= file.Time;
local old_filewrite 		= file.Write;
local old_dbginfo 			= debug.getinfo;
local old_dbginfo 			= debug.getupvalue;
local old_cve 				= ConVarExists;
local old_gcv 				= GetConVar;
local old_gcvn 				= GetConVarNumber;
local old_gcvs 				= GetConVarString;
local old_rcc 				= RunConsoleCommand;
local old_hookadd			= hook.Add;
local old_hookrem 			= hook.Remove;
local old_ccadd				= concommand.Add;
local old_ccrem 			= concommand.Remove;
local old_cvaracc 			= cvars.AddChangeCallback;
local old_cvargcvc 			= cvars.GetConVarCallbacks;
local old_cvarchange 		= cvars.OnConVarChanged;
local old_require			= require;
local old_eccommand 		= engineConsoleCommand;

--Fonts--
surface.CreateFont("Trebuchet19gh", {font="TabLarge", size=13, weight=700})
surface.CreateFont("ESPFont",{font = "ScoreboardText", size = 17, weight = 400, antialias = 0})
surface.CreateFont("ESPFont_Small",{font = "Default", size = 12, weight = 200, antialias = 0})
surface.CreateFont("Logo",{font = "akbar", size = 21, weight = 400, antialias = 0})
surface.CreateFont("Numb_ScoreboardText",{font = "ScoreboardText", size = 15, weight = 700, antialias = 0})
surface.CreateFont("Numb_coolvetica",{font = "coolvetica", size = 16, weight = 500, antialias = 0})
surface.CreateFont("Numb_hvh",{font = "ScoreboardTextt", size = 15, weight = 1000, antialias = 1})

/*************************
Name: Require
Purpose: Modules
**************************/
require("cvar3")

/************************
Name: Bones
Purpose: Get Those bones
*************************/
Numb.bones						= { -- Thanks to sethhack, didn't want to redo this.
{"Head", "ValveBiped.Bip01_Head1"},
{"Neck", "ValveBiped.Bip01_Neck1"},
{"Spine", "ValveBiped.Bip01_Spine"},
{"Spine1", "ValveBiped.Bip01_Spine1"},
{"Spine2", "ValveBiped.Bip01_Spine2"},
{"Spine4", "ValveBiped.Bip01_Spine4"},
{"R Upperarm", "ValveBiped.Bip01_R_UpperArm"},
{"R Forearm", "ValveBiped.Bip01_R_Forearm"},
{"R Hand", "ValveBiped.Bip01_R_Hand"},
{"L Upperarm", "ValveBiped.Bip01_L_UpperArm"},
{"L Forearm", "ValveBiped.Bip01_L_Forearm"},
{"L Hand", "ValveBiped.Bip01_L_Hand"},
{"R Thigh", "ValveBiped.Bip01_R_Thigh"},
{"R Calf", "ValveBiped.Bip01_R_Calf"},
{"R Foot", "ValveBiped.Bip01_R_Foot"},
{"R Toes", "ValveBiped.Bip01_R_Toe0"},
{"L Thigh", "ValveBiped.Bip01_L_Thigh"},
{"L Calf", "ValveBiped.Bip01_L_Calf"},
{"L Foot", "ValveBiped.Bip01_L_Foot"},
{"L Toes", "ValveBiped.Bip01_L_Toe0"}
}


/*
Name: Custom ENT
*/
function IsCustomEnt( entclass )
	return table.HasValue( Numb.ents, entclass )
end


g.rawset(_G, "RunConsoleCommand", oRunConsoleCommand) 

--Materials--
function Numb:CreateMaterial()
local BaseInfo = {
["$basetexture"] = "models/debug/debugwhite",
["$model"]       = 1,
["$translucent"] = 1,
["$alpha"]       = 1,
["$nocull"]      = 1,
["$ignorez"]	 = 1
}	
local mat	
if GetConVarString("Numb_ESP_Chams_Material") == "Solid" then
	mat = CreateMaterial( "Numb_solid", "VertexLitGeneric", BaseInfo )
elseif GetConVarString("Numb_ESP_Chams_Material") == "Wireframe" then
	mat = CreateMaterial( "Numb_wire", "Wireframe", BaseInfo )
end
   return mat
end

/*****
IsDev
*****/
function IsDev()
	if table.HasValue(Numb.dev,LocalPlayer():SteamID()) then
		return true
	else
		return false
	end
end

/*******************************************
Name: Print/Chat functions
Purpose: Notify the user of what's going on
********************************************/
function Numb.Print(msg)
	print("[Numb] "..msg)
end

function Numb.Notify(dosound,col,msg)
	if col then
		col = col
	end
chat.AddText(
Red, "[Numb] ", 
col, msg)
	if dosound == sound then
		local beep = Sound( "/buttons/button17.wav" )
		local beepsound = CreateSound( LocalPlayer(), beep )
		beepsound:Play()
	end
end

/***********************************************
Name: Hook functions
Purpose: Add hooks and protect from anticheats
************************************************/

-- Addhook
local function AddHook(Type,Function)
	Name = Type.." | "..math.random(1,1000),math.random(1,2000),math.random(1,3000) -- Simple hook names
	Numb.Print("[ADDED] Hook: ["..Type.."] | Name: "..Name.."")
	return old_hookadd(Type,Name,Function)
end

-- RemoveHook
local function RemoveHook(Type,Function)
	Numb.Print("[REMOVED] Hook: ["..Type.."]")
	return old_hookrem(Type,Function)
end

/**************
Random String
**************/
function RandomString( len )
	local ret = ""
		for i = 1 , len do
			ret = ret .. string.char( math.random( 65 , 116 ) )
        end
	return ret
end

/**********************
Name: Timer shit
Purpose: Anything timer
***********************/
function AddTimer( sec, rep, func )
	local index = RandomString( 10 )	
	Numb.timers[ index ] = sec	
	timer.Create( index, sec, rep, func )
end

/******************************************
Name: ConCommand Shit
Purpose: Anything related to concommands
********************************************/

function AddCMD(Name,Function)
	table.insert(Numb.concommands,Name)
	Numb.Print("[ADDED] ConCommand: "..Name.."")
	return old_ccadd(Name,Function)
end

function RemoveCMD(Name)
	table.remove(Numb.concommands,Name)
	Numb.Print("[REMOVED] ConCommand: "..Name.."")
	return old_ccrem(Name)
end

/*******************************************
Name: ConVars
Purpose: Anything with ConVars
********************************************/

-- AddConVar
function AddConVar(convar,str,save,data)
	table.insert(Numb.convars,"Numb_"..convar)
	return CreateClientConVar("Numb_"..convar,str,true,false), Numb.Print("[ADDED] ConVar: Numb_"..convar.." ["..str.."]")
end

/**************************
Name: Derma shit
Purpose: Anything Derma
***************************/
function AddCheckBox( text, cvar, parent, x, y, tt )
local checkbox = vgui.Create( "DCheckBoxLabel", parent )
checkbox:SetPos( x, y )
checkbox:SetText( text )
checkbox:SetConVar( cvar )
checkbox:SetTextColor(white)
checkbox:SetTooltip( tt or "No Tool Tip" )
checkbox:SizeToContents()	
end

// AddSlider for the derma
function AddSlider( text, cvar, parent, min, max, decimals, x, y, wide, tt )
local slider = vgui.Create( "DNumSlider" )
slider:SetParent( parent )
slider:SetPos( x, y )
slider:SetWide( wide )
slider:SetText( text )
--slider:SetTextColor(BLACK)
slider:SetMin( min ) 
slider:SetMax( max ) 
slider:SetDecimals( decimals ) 
slider:SetConVar( cvar )
slider:SetTooltip( tt or "No Tool Tip" )
end

Gradient = surface.GetTextureID( "gui/gradient" )
function DrawBox( x, y, wide, tall, dropsize )
	draw.RoundedBoxEx( 4, x, y, wide, dropsize, iceblue, true, true, false, false )
	draw.RoundedBoxEx( 4, x, y + dropsize, wide, tall - dropsize, Color( 0, 0, 0, 100 ), false, false, true, true )
end

/********************************************************
Name: Hide the cheat from client
Purpose: Don't show the where the cheat loads from, etc
*********************************************************/
function error(...) Numb.Notify(red,"Error in the Lua script!") end
function Error(...) Numb.Notify(red,"Error in the Lua script!") end

/*************************
Name: CreatePos
Purpose: Create a position
Credits: BaconBot
***************************/
function CreatePos(v)
local ply = LocalPlayer()
local center = v:LocalToWorld( v:OBBCenter() )
local min, max = v:OBBMins(), v:OBBMaxs()
local dim = max - min	local z = max + min	
local frt	= ( v:GetForward() ) * ( dim.y / 2 )
local rgt	= ( v:GetRight() ) * ( dim.x / 2 )
local top	= ( v:GetUp() ) * ( dim.z / 2 )
local bak	= ( v:GetForward() * -1 ) * ( dim.y / 2 )
local lft	= ( v:GetRight() * -1 ) * ( dim.x / 2 )
local btm	= ( v:GetUp() * -1 ) * ( dim.z / 2 )
local s = 1
local FRT 	= center + frt / s + rgt / s + top / s; FRT = FRT:ToScreen()
local BLB 	= center + bak / s + lft / s + btm / s; BLB = BLB:ToScreen()
local FLT	= center + frt / s + lft / s + top / s; FLT = FLT:ToScreen()
local BRT 	= center + bak / s + rgt / s + top / s; BRT = BRT:ToScreen()
local BLT 	= center + bak / s + lft / s + top / s; BLT = BLT:ToScreen()
local FRB 	= center + frt / s + rgt / s + btm / s; FRB = FRB:ToScreen()
local FLB 	= center + frt / s + lft / s + btm / s; FLB = FLB:ToScreen()
local BRB 	= center + bak / s + rgt / s + btm / s; BRB = BRB:ToScreen()	
local z = 100
if ( v:Health() <= 50 ) then z = 100 end
local x, y = ( ( v:Health() / 100 ) ), 1
if ( v:Health() <= 0 ) then x = 1 end
local FRT3 	= center + frt + rgt + top / x; FRT3 = FRT3; FRT3 = FRT3:ToScreen()
local BLB3 	= center + bak + lft + btm / x; BLB3 = BLB3; BLB3 = BLB3:ToScreen()
local FLT3	= center + frt + lft + top / x; FLT3 = FLT3; FLT3 = FLT3:ToScreen()
local BRT3 	= center + bak + rgt + top / x; BRT3 = BRT3; BRT3 = BRT3:ToScreen()
local BLT3 	= center + bak + lft + top / x; BLT3 = BLT3; BLT3 = BLT3:ToScreen()
local FRB3 	= center + frt + rgt + btm / x; FRB3 = FRB3; FRB3 = FRB3:ToScreen()
local FLB3 	= center + frt + lft + btm / x; FLB3 = FLB3; FLB3 = FLB3:ToScreen()
local BRB3 	= center + bak + rgt + btm / x; BRB3 = BRB3; BRB3 = BRB3:ToScreen()	
local x, y, z = 1.1, 0.9, 1
local FRT2 	= center + frt / y + rgt / z + top / x; FRT2 = FRT2:ToScreen()
local BLB2 	= center + bak / y + lft / z + btm / x; BLB2 = BLB2:ToScreen()
local FLT2	= center + frt / y + lft / z + top / x; FLT2 = FLT2:ToScreen()
local BRT2 	= center + bak / y + rgt / z + top / x; BRT2 = BRT2:ToScreen()
local BLT2 	= center + bak / y + lft / z + top / x; BLT2 = BLT2:ToScreen()
local FRB2 	= center + frt / y + rgt / z + btm / x; FRB2 = FRB2:ToScreen()
local FLB2 	= center + frt / y + lft / z + btm / x; FLB2 = FLB2:ToScreen()
local BRB2 	= center + bak / y + rgt / z + btm / x; BRB2 = BRB2:ToScreen()	
local maxX = math.max( FRT.x,BLB.x,FLT.x,BRT.x,BLT.x,FRB.x,FLB.x,BRB.x )
local minX = math.min( FRT.x,BLB.x,FLT.x,BRT.x,BLT.x,FRB.x,FLB.x,BRB.x )
local maxY = math.max( FRT.y,BLB.y,FLT.y,BRT.y,BLT.y,FRB.y,FLB.y,BRB.y )
local minY = math.min( FRT.y,BLB.y,FLT.y,BRT.y,BLT.y,FRB.y,FLB.y,BRB.y )
local minYhp2 = math.min( FRT.y,BLB.y,FLT.y,BRT.y,BLT.y,FRB.y,FLB.y,BRB.y )
local maxXhp = math.max( FRT3.x,BLB3.x,FLT3.x,BRT3.x,BLT3.x,FRB3.x,FLB3.x,BRB3.x )
local minXhp = math.min( FRT3.x,BLB3.x,FLT3.x,BRT3.x,BLT3.x,FRB3.x,FLB3.x,BRB3.x )
local maxYhp = math.max( FRT3.y,BLB3.y,FLT3.y,BRT3.y,BLT3.y,FRB3.y,FLB3.y,BRB3.y )
local minYhp = math.min( FRT3.y,BLB3.y,FLT3.y,BRT3.y,BLT3.y,FRB3.y,FLB3.y,BRB3.y )	
local maxX2 = math.max( FRT2.x,BLB2.x,FLT2.x,BRT2.x,BLT2.x,FRB2.x,FLB2.x,BRB2.x )
local minX2 = math.min( FRT2.x,BLB2.x,FLT2.x,BRT2.x,BLT2.x,FRB2.x,FLB2.x,BRB2.x )
local maxY2 = math.max( FRT2.y,BLB2.y,FLT2.y,BRT2.y,BLT2.y,FRB2.y,FLB2.y,BRB2.y )
local minY2 = math.min( FRT2.y,BLB2.y,FLT2.y,BRT2.y,BLT2.y,FRB2.y,FLB2.y,BRB2.y )
return maxX, minX, maxY, minY, maxX2, minX2, maxY2, minY2, minYhp, maxYhp
end



/**************************
Name: GetServerGM
Purpose: Check server's GM
***************************/

function GetServerGM( notify,name )
	if notify == true then
		Numb.Print("This server is using the gamemode '"..GAMEMODE.Name.."'.")
	end
	if ( string.find( string.lower( GAMEMODE.Name ), name ) ) then
		return true
	end
	return false
end

/*************************************
Name: PlayerVisible
Purpose: Check if a player is visible
*************************************/
local function CanSee(ent)    
	local tr = {};	
	tr.start = LocalPlayer():GetShootPos();
	tr.endpos = ent:GetPos() + Vector(0, 0, 5)
	tr.filter = {LocalPlayer(), ent};
	tr.mask = MASK_SHOT;	
    local trace = util.TraceLine(tr) ;
    if (trace.Fraction == 1) then 
        return true;
    else 
        return false; 
    end     
end

/**********************************
Name: GetColors
Purpose: Make a cool color!
***********************************/
local function GetColorCrosshair()
	if LocalPlayer():GetEyeTrace().Entity:IsPlayer() then
		return 0,255,0,255
	end
	if LocalPlayer():GetEyeTrace().Entity:IsNPC() then
		return 0,0,255,255
	end
	return team.GetColor(Color(255,0,0,255))
end

local function GetColorVisible(e)
	if CanSee(e) then
		return 0,255,0,255
	end
	if !CanSee(e) then
		return 255,0,0,255
	end
end


/**************************************
Name: Number shit
Purpose: Format number, round number, etc
**************************************/
function CommaValue(amount)
	local formatted = amount
	while true do  
		formatted, k = string.gsub(formatted, "^(-?%d+)(%d%d%d)", '%1,%2')
		if (k==0) then
			break
		end
	end
	return formatted
end

function RoundNum(val, decimal)
	if (decimal) then
		return math.floor( (val * 10^decimal) + 0.5) / (10^decimal)
	else
		return math.floor(val+0.5)
	end
end

function FormatNum(amount, decimal, prefix, neg_prefix)
	local str_amount,  formatted, famount, remain
	decimal = decimal or 2
	neg_prefix = neg_prefix or "-"
	famount = math.abs(RoundNum(amount,decimal))
	famount = math.floor(famount)
	remain = RoundNum(math.abs(amount) - famount, decimal)
	formatted = CommaValue(famount)
	if (decimal > 0) then
		remain = string.sub(tostring(remain),3)
		formatted = formatted .. "." .. remain .. string.rep("0", decimal - string.len(remain))
	end
	formatted = (prefix or "") .. formatted 
	if (amount<0) then
		if (neg_prefix=="()") then
			formatted = "("..formatted ..")"
		else
			formatted = neg_prefix .. formatted 
		end
	end
	return formatted
end


/**********************
Name: DrawText
Purpose: Draws text...
**********************/
function Numb.DrawText( text, font, x, y, colour, xalign, yalign )
	if (font == nil) then font = "Default" end
	if (x == nil) then x = 0 end
	if (y == nil) then y = 0 end	
	local curX = x
	local curY = y
	local curString = ""	
	surface.SetFont(font)
	local sizeX, lineHeight = surface.GetTextSize("\n")	
	for i=1, string.len(text) do
		local ch = string.sub(text,i,i)
		if (ch == "\n") then
			if (string.len(curString) > 0) then
				draw.SimpleText(curString, font, curX, curY, colour, xalign, yalign)
			end			
			curY = curY + (lineHeight/2)
			curX = x
			curString = ""
		elseif (ch == "\t") then
			if (string.len(curString) > 0) then
				draw.SimpleText(curString, font, curX, curY, colour, xalign, yalign)
			end
			local tmpSizeX,tmpSizeY =  surface.GetTextSize(curString)
			curX = math.ceil( (curX + tmpSizeX) / 50 ) * 50
			curString = ""
		else
			curString = curString .. ch
		end
	end	
	if (string.len(curString) > 0) then
		draw.SimpleText(curString, font, curX, curY, colour, xalign, yalign)
	end
end

local function FillRGBA(x,y,w,h,col)
    surface.SetDrawColor( col.r, col.g, col.b, col.a );
    surface.DrawRect( x, y, w, h );
end

local function OutlineRGBA(x,y,w,h,col)
    surface.SetDrawColor( col.r, col.g, col.b, col.a );
    surface.DrawOutlinedRect( x, y, w, h );
end

/*********************
Name: IsVehicle
Purpose: Find vehicles
*********************/
function Numb.IsVehicle( e )	
	local ply = LocalPlayer()	
	if ( string.find( e:GetClass(), "prop_vehicle_" ) && ply:GetMoveType() ~= 0 ) then
		return true
	end
	return false
end

/***************************
Name: SetColors
Purpose: Set Colors
****************************/
function SetColors(e)
	local ply, class, model = LocalPlayer(), e:GetClass(), e:GetModel()
	local col	
	if ( e:IsPlayer() ) then
		col = Color(0,255,0,255)
	elseif ( e:IsNPC() ) then 
		col = Color( 255, 0, 0, 20 )		
	elseif IsCustomEnt( e:GetClass() ) then
		col = Color( 0, 200, 255, 50 )		
	else
		col = Color( 255, 255, 255, 255 )		
	end	
	return col
end

/******************************
Name: Get Admin Type
Purpose: Get Admin Type..
*******************************/
local function GetAdminType(e)
	if e:IsAdmin() && !e:IsSuperAdmin() then
		return " [A] "
	elseif( e:IsSuperAdmin() ) then
		return " [SA] "
	end
	return " "
end

function CheckUpdate()
Numb.Print("Checking cheat version...")
	http.Fetch("https://dl.dropbox.com/u/91139226/version.txt", function(body, len, headers, code) 
		if body == Numb.version then 
			Numb.Notify(sound, green,"Your version of NumbBot is up to date! You are currently running veresion "..Numb.version) 
		else
			Numb.Notify(sound, red,"Your version of NumbBot is outdated! Please update to version "..body)
		end 
	end)
end
CheckUpdate()

function DoUpdate()
	Numb.Notify(false,green, "Please visit https://dl.dropbox.com/u/150309237/Numb/Numb.lua for the latest update of the cheat.")
end

/****************************
Name: Create ConVars
Purpose: Create ConVars..
*****************************/
AddConVar("ESP_Info",								0)
AddConVar("ESP_Box",								0)
AddConVar("ESP_Skeleton",							0)
AddConVar("ESP_Tracer",								0)
AddConVar("ESP_Crosshair",							0)
AddConVar("ESP_Crosshair_Type",						"CSS")
AddConVar("ESP_Chams",								0)
AddConVar("ESP_Chams_Material",						"Solid")
AddConVar("ESP_Ents",								0)
AddConVar("ESP_Distance",							1000)
AddConVar("ESP_Info_Type",							"info")
AddConVar("ESP_Text",								"ESPFont")
AddConVar("ESP_lasersights",						0)

AddConVar("MISC_Bunnyhop",							0)
AddConVar("MISC_TTT",								0)
AddConVar("MISC_ChatSpam",							0)
AddConVar("MISC_ChatSpam_Msg",						"NumbBot v2 By OverDone!")
AddConVar("MISC_AntiAFK",							0) 
AddConVar("MISC_CSNoclip",							0)
AddConVar("MISC_CSNoclip_Speed",					10)
AddConVar("MISC_Thirdperson",						0)
AddConVar("MISC_RPGod",								0)
AddConVar("MISC_Namechanger",						0)
AddConVar("MISC_ShowNotifications",					0)
AddConVar("MISC_SpeedHack_Speed",					3.5)
AddConVar("MISC_ShowSpec",							0)
AddConVar("MISC_ShowAdmins",						0)
AddConVar("MISC_Thirdperson_dist",					200)
AddConVar("MISC_Flashlight",						0)
AddConVar("MISC_nosky",								0)
AddConVar("MISC_Fullbright",						0)
AddConVar("MISC_NoRecoil",							1)
AddConVar("MISC_nospread",							1)
AddConVar("MISC_cheats",							1)

AddConVar("SPEED_speed",							3.5)


/***********************************
concommands to find entities and shit
**************************************/

AddCMD("_ents",function()
	PrintTable(ents.GetAll())
end)

--[[
	CHAMS
]]--

-- OnScreen and IsCloseEnough check
function OnScreen(ent)
	local a, f = debug.getregistry().Player["GetAimVector"](LocalPlayer()):Angle() - (ent:GetPos() - LocalPlayer():GetShootPos()):Angle(), debug.getregistry().Player["GetFOV"](LocalPlayer())	
	return (math.NormalizeAngle(a.y) < f + 2 && math.NormalizeAngle(a.p) < f + 2)
end
function IsCloseEnough(ent)
	local dist = ent:GetPos():Distance( LocalPlayer():GetPos() )
	if( dist <= GetConVarNumber("Numb_ESP_Distance") and ent:GetPos() != Vector( 0, 0, 0 ) ) and OnScreen(ent) then
		return true
	end
	return false	
end

function Chams()			
local mat = Numb:CreateMaterial()
	if GetConVarNumber("Numb_ESP_Chams") == 1 then
		for k,v in pairs(ents.GetAll()) do
			local col;
			if IsValid(v) and (IsCloseEnough(v) and v:IsPlayer() and v:Alive() and v:Health() > 0)  or (IsCloseEnough(v) and v:IsWeapon()) or (IsCloseEnough(v) and v:IsNPC()) then
				if (v:IsPlayer()) then
					col = team.GetColor(v:Team())
				elseif (v:IsWeapon()) then
					col = Color(255,0,0,255)
				elseif (v:IsNPC()) then
					col = Color(0,255,0,255)
				else
					col = Color(255,255,255,255)
				end
				cam.Start3D(EyePos(),EyeAngles())
					render.SuppressEngineLighting( true )
					render.SetColorModulation(col.r / 255, col.g / 255, col.b / 255);
					render.SetBlend(col.a / 255);
					render.MaterialOverride( mat )
					v:DrawModel()		
					render.SuppressEngineLighting( false )
					render.SetColorModulation(1,1,1)
					render.MaterialOverride( )
					v:DrawModel()
				cam.End3D()
			end
		end
	end
end
hook.Add('PostDrawEffects', 'Chams', Chams)

local IsLock = false;

--[[ 
	ESP
]]--
local function GetBoxColor(e)
	if CanSee(e) then
		return Color(0,255,0)
	elseif !CanSee(e) then
		return Color(255,0,0)
	end
end

function ESP()
	for k, e in pairs( player.GetAll() ) do
local TeamColor = team.GetColor(e:Team())
local HPColor = Color(255,255,255,255)
local Dist = e:GetPos():Distance(LocalPlayer():GetPos());
local wep = "Unknown"
local SteamID = e:SteamID()
local Name = e:Nick()
local InfoCol = white
if GetConVarNumber("Numb_PERP_RPNames") == 1 then
	Name = e:GetRPName()
else
	Name = e:Nick()
end
local maxX, minX, maxY, minY, maxX2, minX2, maxY2, minY2, minYhp, maxYhp = CreatePos( e )
-- This is bad
if e:Health() >= 90 then HPColor = Color(0,255,0,255)
	elseif e:Health() >= 70 then HPColor = Color(255,255,0,255)
	elseif e:Health() >= 50 then HPColor = Color(255,165,0,255)
	elseif e:Health() >= 30 then HPColor = Color(255,140,0,255)
	elseif e:Health() >= 20 then HPCOlor = Color(255, 255, 255, 255)
	elseif e:Health() >= 10 then HPColor = Color(255,0,0,255)
	else HPColor = Color(255,0,0,255)
end
draw.SimpleTextOutlined("xInstantHook v2.0 for Garry's Mod","Logo",25,15,Color(255,255,255,255),5,1,1,black)
if ( e:IsPlayer() && e:Alive() && e != LocalPlayer() && IsCloseEnough(e) ) then
			if e:GetActiveWeapon() != nil then
				if type(e:GetActiveWeapon()) == "Weapon" then
					if e:GetActiveWeapon() and e:GetActiveWeapon():IsValid() then
						wep = e:GetActiveWeapon():GetPrintName()
						
							-- ESP INFO
							if GetConVarNumber("Numb_ESP_Info") == 1 then
								draw.SimpleTextOutlined( Name..GetAdminType(e), "Trebuchet19gh", maxX2, minY2, TeamColor,4,1,1,Color(255,0,0))
								draw.SimpleTextOutlined( "H: " .. e:Health(), "Trebuchet19gh", maxX2, minY2 + 10, HPColor, 4,1, 1, black )
								draw.SimpleTextOutlined( "D: " .. math.floor(Dist), "Trebuchet19gh", maxX2, minY2 + 20, InfoCol, 4, 1, 1, black )
								draw.SimpleTextOutlined( "W: " .. wep, "Trebuchet19gh", maxX2, minY2 + 30, InfoCol, 4, 1, 1, black)
							end								
								if e:GetFriendStatus() == "friend" then
									draw.SimpleTextOutlined( "[Friend]", "ESPFont", maxX2, minY2 - 10, iceblue, 4, 1,1,black)
								end
							end
							
							-- ESP BOX --
							if GetConVarNumber("Numb_ESP_Box") == 1 then
								surface.SetDrawColor(GetBoxColor(e))				
								surface.DrawLine( maxX, maxY, maxX, minY )
								surface.DrawLine( maxX, minY, minX, minY )					
								surface.DrawLine( minX, minY, minX, maxY )
								surface.DrawLine( minX, maxY, maxX, maxY )
							end
							-- ESP SKELETON --
							local bones = {
							{ S = "ValveBiped.Bip01_Head1", E = "ValveBiped.Bip01_Neck1" },
							{ S = "ValveBiped.Bip01_Neck1", E = "ValveBiped.Bip01_Spine4" },
							{ S = "ValveBiped.Bip01_Spine4", E = "ValveBiped.Bip01_Spine2" },
							{ S = "ValveBiped.Bip01_Spine2", E = "ValveBiped.Bip01_Spine1" },
							{ S = "ValveBiped.Bip01_Spine1", E = "ValveBiped.Bip01_Spine" },
							{ S = "ValveBiped.Bip01_Spine", E = "ValveBiped.Bip01_Pelvis" },
							
							{ S = "ValveBiped.Bip01_Spine4", E = "ValveBiped.Bip01_L_UpperArm" },
							{ S = "ValveBiped.Bip01_L_UpperArm", E = "ValveBiped.Bip01_L_Forearm" },
							{ S = "ValveBiped.Bip01_L_Forearm", E = "ValveBiped.Bip01_L_Hand" },

							{ S = "ValveBiped.Bip01_Spine4", E = "ValveBiped.Bip01_R_UpperArm" },
							{ S = "ValveBiped.Bip01_R_UpperArm", E = "ValveBiped.Bip01_R_Forearm" },
							{ S = "ValveBiped.Bip01_R_Forearm", E = "ValveBiped.Bip01_R_Hand" },

							{ S = "ValveBiped.Bip01_Pelvis", E = "ValveBiped.Bip01_L_Thigh" },
							{ S = "ValveBiped.Bip01_L_Thigh", E = "ValveBiped.Bip01_L_Calf" },
							{ S = "ValveBiped.Bip01_L_Calf", E = "ValveBiped.Bip01_L_Foot" },
							{ S = "ValveBiped.Bip01_L_Foot", E = "ValveBiped.Bip01_L_Toe0" },

							{ S = "ValveBiped.Bip01_Pelvis", E = "ValveBiped.Bip01_R_Thigh" },
							{ S = "ValveBiped.Bip01_R_Thigh", E = "ValveBiped.Bip01_R_Calf" },
							{ S = "ValveBiped.Bip01_R_Calf", E = "ValveBiped.Bip01_R_Foot" },
							{ S = "ValveBiped.Bip01_R_Foot", E = "ValveBiped.Bip01_R_Toe0" },
							}
							if GetConVarNumber("Numb_ESP_Skeleton") == 1 then
								for k, v in pairs( bones ) do
									local sPos, ePos = e:GetBonePosition( e:LookupBone( v.S ) ):ToScreen(), e:GetBonePosition( e:LookupBone( v.E ) ):ToScreen()
										if e:IsPlayer() and !e:IsNPC() then
											surface.SetDrawColor(team.GetColor(e:Team()))
										end
										surface.DrawLine(sPos.x,sPos.y,ePos.x,ePos.y)
								end
							end
							-- ESP TRACER --
							if GetConVarNumber("Numb_ESP_Tracer") == 1 then	
								cam.Start3D( EyePos() , EyeAngles())
								render.SetMaterial( Material( "trails/laser" ) )
								StartPos = LocalPlayer():GetActiveWeapon():GetPos()
								EndPos = e:GetBonePosition(e:LookupBone("ValveBiped.Bip01_Head1"))
								render.DrawBeam(StartPos, EndPos , 3, 0, 0, Color(0,255,0,255))
								cam.End3D()
							end
							
							-- ESP CROSSHAIR --
							if GetConVarNumber("Numb_ESP_Crosshair") == 1 then
								if GetConVarString("Numb_ESP_Crosshair_Type") == "Spinning" then
									local x, y = ScrW() / 2, ScrH() / 2	
									local Speed = 1
									surface.SetDrawColor( 255, 0, 0, 255 )
									CHPosx = math.Clamp(LocalPlayer():GetEyeTrace().HitPos:ToScreen().x,0,ScrW())
									CHPosy = math.Clamp(LocalPlayer():GetEyeTrace().HitPos:ToScreen().y,0,ScrH())
									mathsin = math.sin(CurTime()*Speed)*4
									mathcos = math.cos(CurTime()*Speed)*4
									mathsin2 = math.sin(CurTime()*Speed+0.1)*4
									mathcos2 = math.cos(CurTime()*Speed+0.1)*4
									mathsin3 = math.sin(CurTime()*Speed-0.1)*4
									mathcos3 = math.cos(CurTime()*Speed-0.1)*4
									surface.DrawLine( CHPosx+mathcos*2,CHPosy+mathsin*2,CHPosx+mathcos*5,CHPosy+mathsin*5 );
									surface.DrawLine( CHPosx-mathcos*2,CHPosy-mathsin*2,CHPosx-mathcos*5,CHPosy-mathsin*5 );
									surface.DrawLine( CHPosx+mathsin*2,CHPosy-mathcos*2,CHPosx+mathsin*5,CHPosy-mathcos*5 );
									surface.DrawLine( CHPosx-mathsin*2,CHPosy+mathcos*2,CHPosx-mathsin*5,CHPosy+mathcos*5 );
								elseif GetConVarString("Numb_ESP_Crosshair_Type") == "Jewish" then
									surface.SetDrawColor( 255, 0, 0, 255 )
									surface.DrawLine(ScrW()/2, ScrH()/2, ScrW()/2 + 20, ScrH()/2)
									surface.DrawLine(ScrW()/2 + 20, ScrH()/2, ScrW()/2 + 20, ScrH()/2 + 20)
									surface.DrawLine(ScrW()/2 , ScrH()/2, ScrW()/2 - 20, ScrH()/2)
									surface.DrawLine(ScrW()/2 - 20 , ScrH()/2, ScrW()/2 - 20, ScrH()/2 - 20)
									surface.DrawLine(ScrW()/2, ScrH()/2, ScrW()/2, ScrH()/2 - 20)
									surface.DrawLine(ScrW()/2, ScrH()/2 - 20, ScrW()/2 + 20, ScrH()/2 - 20)
									surface.DrawLine(ScrW()/2, ScrH()/2, ScrW()/2, ScrH()/2 + 20)
									surface.DrawLine(ScrW()/2, ScrH()/2 + 20, ScrW()/2 - 20, ScrH()/2 + 20)
								elseif GetConVarString("Numb_ESP_Crosshair_Type") == "Basic" then
									local x, y, s = ScrW() / 2, ScrH() / 2, 10
									surface.SetDrawColor( 255, 0, 0, 255 )
									surface.DrawLine( x, y - s, x, y + s )
									surface.DrawLine( x - s, y, x + s, y )
								elseif GetConVarString("Numb_ESP_Crosshair_Type") == "X-Cross" then
									local x, y, w = ScrW() / 2, ScrH() / 2, 7
									surface.SetDrawColor( 255, 0, 0, 255 )
									surface.DrawLine(x - w, y - w, x + w, y + w)
									surface.DrawLine(x - w, y + w, x + w, y - w)
								elseif GetConVarString("Numb_ESP_Crosshair_Type") == "Dot" then
								draw.RoundedBox( 4, ( ScrW() / 2 ) - 3, ( ScrH() / 2 ) - 3, 7, 7, Color( 255, 255, 255, 255 ) )
								elseif GetConVarString("numb_ESP_Crosshair_Type") == "CSS" then
								        local g = 5
										local s, x, y, l = 10, ScrW() / 2, ScrH() / 2, g + 15
										surface.SetDrawColor( 255, 0, 0, 255 )
										surface.DrawLine( x - l, y, x - g, y )
										surface.DrawLine( x + l, y, x + g, y )
										surface.DrawLine( x, y - l, x, y - g )
										surface.DrawLine( x, y + l, x, y + g )
								elseif GetConVarString("numb_ESP_Crosshair_Type") == "Cross Boxed" then
									surface.SetDrawColor( 255, 0, 0, 255 )
										surface.DrawLine( x - length, y, x - gap, y )
										surface.DrawLine( x + length, y, x + gap, y )
										surface.DrawLine( x, y - length, x, y - gap )
										surface.DrawLine( x, y + length, x, y + gap )
										surface.DrawOutlinedRect( x - length - 2, y - length - 2, ( length + 2 ) * 2 + 1, ( length + 2 ) * 2 + 1 )
										surface.DrawLine(ScrW() / 2 - 30, ScrH() / 2, ScrW() / 2 + 32 , ScrH() / 2)
										surface.DrawLine(ScrW() / 2 - 0, ScrH() / 2 - 30, ScrW() / 2 - 0 , ScrH() / 2 + 32)
										draw.RoundedBox( 4, ( ScrW() / 2 ) - 3, ( ScrH() / 2 ) - 3, 7, 7, Color( 0, 0, 0, 50 ) )
								end
							end
							if GetConVarNumber("Numb_MISC_CSNoclip") == 1 then
								me_pos = LocalPlayer():EyePos():ToScreen()
								draw.SimpleText("You are here!", "ESPFont_Small", me_pos.x,me_pos.y +10, red, 4, 1 )
							end
					end
				end
			end
		end
	for _, v in ipairs( ents.GetAll() ) do
		if( v:IsValid() and IsCustomEnt( v:GetClass() )) then
			if GetConVarNumber("Numb_ESP_Ents") == 1 then
				local wepn = v:GetClass()
				local wname = string.Replace(wepn,"weapon_","")
				wname = string.Replace(wname,"_"," ")
				wname = string.upper(wname)
				local entpos = v:GetPos():ToScreen()
				draw.SimpleTextOutlined(wname, "ESPFont_Small", entpos.x + 50, entpos.y - 15, red, TEXT_ALIGN_CENTER, TEXT_ALIGN_LEFT, .6, black )
			end
		end                    
	end
end
hook.Add('HUDPaint', 'ESP', ESP)

function Misc()
	if GetConVarNumber("Numb_MISC_BunnyHop") == 1 then
		if input.IsKeyDown(KEY_SPACE) then
			if LocalPlayer():IsOnGround() then
				old_rcc("+Jump")
				timer.Create("Bhop",0.01, 0 ,function() old_rcc("-Jump") end)
			end
		end
	end
	if GetConVarNumber("Numb_MISC_ChatSpam") == 1 then
		LocalPlayer():ConCommand("say "..GetConVarString("Numb_MISC_ChatSpam_Msg").."")
	end
	if GetConVarNumber("Numb_MISC_RPGod") == 1 then
		if LocalPlayer():Health() < 100 then
			LocalPlayer():ConCommand("say /buyhealth"); -- spam buyhealth
		end
	end
	if GetConVarNumber("numb_MISC_NoRecoil") == 1 then
	local wep = LocalPlayer():GetActiveWeapon() 
		if LocalPlayer():GetActiveWeapon().Primary then
			LocalPlayer():GetActiveWeapon().Primary.Recoil = 0
		else
		if LocalPlayer():GetActiveWeapon().Primary then
			LocalPlayer():GetActiveWeapon().Primary.Recoil = 0
		end
	end
end
	if GetConVarNumber("Numb_MISC_Flashlight") == 1 then
		old_rcc("impulse","100")
	end
	if GetConVarNumber("Numb_MISC_Fullbright") == 1 then
		GetConVar("mat_fullbright"):SetValue(1)
	else
		GetConVar("mat_fullbright"):SetValue(0)
	end
	if GetConVarNumber("Numb_MISC_CSNoclip") ~= 1 then
		CS_NC = LocalPlayer():EyePos();
	end
end
hook.Add("Think", "Misc", Misc)


-- Sv_Cheats
function sv_cheats()
	if GetConVarNumber("numb_MISC_cheats") >= 1 then
		GetConVar("sv_cheats"):SetValue(1)
	else
		GetConVar("sv_cheats"):SetValue(0)
	end
end
hook.Add( "Think", "sv_cheats", sv_cheats )

-- NoSky
function RemoveSky()
        if GetConVarNumber("numb_misc_nosky") >= 1 then
        GetConVar('gl_clear'):SetValue(1)
        GetConVar('r_drawskybox'):SetValue(0)
        GetConVar('r_3dsky'):SetValue(0)
        else
        GetConVar('gl_clear'):SetValue(0)
        GetConVar('r_drawskybox'):SetValue(1)
        GetConVar('r_3dsky'):SetValue(0)
        end
end    
hook.Add( 'HUDPaint', 'BlackSky', RemoveSky );

-- Speedhack
timer.Create("AddSpeed", 2, 1, function()
concommand.Add("+Numb_Speed" , function() GetConVar('sv_cheats'):SetValue(1) GetConVar('host_timescale'):SetValue(tostring(GetConVarNumber("numb_SPEED_Speed"))) end)
concommand.Add("-Numb_Speed", function() GetConVar('host_timescale'):SetValue(1) end)
end)

-- Laser Sights
local VH = {};
local Allowed = { 
'weapon_mad_deagle', 
'weapon_mad_m4', 
'weapon_mad_m249', 
'weapon_mad_ak47',
'weapon_mad_tmp', 
'weapon_mad_mp5', 
'weapon_mad_awp', 
'weapon_mad_p90', 
'weapon_mad_usp_match', 
'weapon_mad_357', 
'weapon_mad_mp7', 
'weapon_mad_galil', 
'weapon_mad_sg552', 
'weapon_mad_alyxgun', 
'weapon_mad_glock', 
'weapon_smg1', 
'weapon_deagle', 
'weapon_pistol', 
'weapon_mad_deagle', 
'weapon_mad_ak47', 
'weapon_glock', 
'weapon_para', 
'weapon_ak47', 
'weapon_fiveseven', 
'weapon_mac10', 
'weapon_tmp', 
'weapon_m4', 
'weapon_mp5', 
'weapon_mad_mp5' }
 
function Barrel()
if GetConVarNumber( "numb_ESP_lasersights" ) >= 1 then return end
local ViewModel = LocalPlayer():GetViewModel()
local Attach = ViewModel:LookupAttachment( '1' )
if( !LocalPlayer():Alive() || LocalPlayer():GetActiveWeapon() == NULL ) then return; end
if ( Attach == 0 ) then Attach = ViewModel:LookupAttachment( 'muzzle' ) end
if( !table.HasValue( Allowed, LocalPlayer():GetActiveWeapon():GetClass() ) ) then return; end
cam.Start3D( EyePos(), EyeAngles() )
render.SetMaterial( Material( 'sprites/bluelaser1' ) )
render.DrawBeam( ViewModel:GetAttachment( Attach ).Pos, LocalPlayer():GetEyeTrace().HitPos, 5, 0, 0, team.GetColor( LocalPlayer():Team() ) )
cam.End3D()
end
hook.Add( 'RenderScreenspaceEffects', '\2\3', Barrel )


AddHook("CalcView",function(ply, pos, angles, fov)
	if GetConVarNumber("Numb_MISC_Thirdperson") == 1 and LocalPlayer():Alive() then
		local view = {}
		view.origin = pos-(angles:Forward()*GetConVarNumber("Numb_MISC_Thirdperson_Dist"))
		view.angles = angles
		view.fov = fov
		return view
	elseif(GetConVarNumber("Numb_MISC_CSNoclip") == 1 and CS_NC) then
		local ang = angles:Forward()
		if LocalPlayer():KeyDown( IN_FORWARD ) and GetConVarNumber("Numb_MISC_CSNoclip") == 1 then
		CS_NC = CS_NC + LocalPlayer():GetAimVector() * speed
		end
		if LocalPlayer():KeyDown( IN_BACK ) and GetConVarNumber("Numb_MISC_CSNoclip") == 1 then
			CS_NC = CS_NC - LocalPlayer():GetAimVector() * speed
		end
		if LocalPlayer():KeyDown( IN_MOVERIGHT ) and GetConVarNumber("Numb_MISC_CSNoclip") == 1 then
			CS_NC = CS_NC + ang:Angle():Right() * speed
		end
		if LocalPlayer():KeyDown( IN_MOVELEFT ) and GetConVarNumber("Numb_MISC_CSNoclip") == 1 then
			CS_NC = CS_NC - ang:Angle():Right() * speed
		end
		if LocalPlayer():KeyDown( IN_JUMP ) and GetConVarNumber("Numb_MISC_CSNoclip") == 1 then
			CS_NC = CS_NC + Vector( 0, 0, speed )
		end
		if LocalPlayer():KeyDown( IN_SPEED ) and GetConVarNumber("Numb_MISC_CSNoclip") == 1 then
			speed = ( GetConVarNumber("Numb_MISC_CSNoclip_Speed") * 3 * ( FrameTime() / 2 ) ) * 100
		elseif LocalPlayer():KeyDown( IN_DUCK ) and GetConVarNumber("Numb_MISC_CSNoclip") == 1 then
			speed = ( GetConVarNumber("Numb_MISC_CSNoclip_Speed") / 3 * ( FrameTime() / 2 ) ) * 100
		else
			speed = ( GetConVarNumber("Numb_MISC_CSNoclip_Speed") * ( FrameTime() / 2 ) ) * 100
		end		
		local view = {}
		view.origin = CS_NC
		view.angles = angles
		view.fov = fov
		return view
	else
		CS_NC = LocalPlayer():EyePos()
	end
	return GAMEMODE:CalcView(ply, pos, angles, fov)
end)
AddHook("ShouldDrawLocalPlayer",function()
	if GetConVarNumber("Numb_MISC_Thirdperson") == 1 then
		return true
	end
end)
function CSNoclip(ucmd)
	if GetConVarNumber("Numb_MISC_CSNoclip") == 1 then
		ucmd:SetForwardMove(0);
		ucmd:SetSideMove(0);
		ucmd:SetUpMove(0);
	end
end

function ShowNotifi()
	-- now spectating
	for k, v in pairs(player.GetAll()) do
		if (IsValid(v:GetObserverTarget()) and v:GetObserverTarget():IsPlayer() and v:GetObserverTarget() == LocalPlayer()) then
			if(not table.HasValue(Numb.spectators, v)) then
				table.insert(Numb.spectators, v);
				if GetConVarNumber("Numb_MISC_ShowSpec") == 1 then
					Numb.Notify(true,red,""..v:Nick().." is now spectating you!")
					surface.PlaySound("buttons/blip1.wav")
				end
			end
		end
	end
	-- no longer spectating
	for k, v in pairs(Numb.spectators) do
		if (not IsValid(v) or not IsValid(v:GetObserverTarget()) or not v:GetObserverTarget():IsPlayer() or (v:GetObserverTarget() ~= LocalPlayer())) then
			table.remove(Numb.spectators, k);
			if GetConVarNumber("Numb_MISC_ShowSpec") == 1 then
				Numb.Notify(true,green,""..v:Nick().." is no longer spectating you!")
			end
		end
	end
	-- admin join
	if GetConVarNumber("Numb_MISC_ShowAdmins") == 1 then
		for k, v in pairs(player.GetAll()) do
			if (v:IsAdmin() and not table.HasValue(Numb.admins, v)) then
				table.insert(Numb.admins, v);
				Numb.Notify(true,white,"Admin " .. v:Nick() .. " has joined!")
				surface.PlaySound("buttons/blip1.wav");
			end
		end
	end
end
hook.Add('Think', 'ShowNotifi', ShowNotifi)

/************************************
Name: Menu
Purpose: Lets do something a bit faster ?
*************************************/
concommand.Add( "x22_cheats", function()
        Menu = vgui.Create( "DFrame")
        Menu:SetSize( 390, 450 )
        Menu:SetTitle("Cheat Menu")
        Menu:Center()
        Menu:MakePopup()
               
        local AdvTab = vgui.Create( "DPropertySheet", Menu)
        AdvTab:SetPos( 5, 25 )
        AdvTab:SetSize( 380, 415 )
 
        local Page1 = vgui.Create( "DImage" )
        AdvTab:AddSheet( "Aimbot", Page1, "gui/silkicons/bomb", false, false, "Aimbot Settings" )
       
		/* Aimbot Page Labels */
		local TextAim1 = vgui.Create("DLabel")
        TextAim1:SetText( "Auto Aim" )
        TextAim1:SetParent( Page1 )
        TextAim1:SetWide(100)
        TextAim1:SetPos(10,20)
        TextAim1:SetTextColor(Color(255, 255, 255, 255))
		
		local TextAim1 = vgui.Create("DLabel")
        TextAim1:SetText( "Aim Priority" )
        TextAim1:SetParent( Page1 )
        TextAim1:SetWide(100)
        TextAim1:SetPos(10,60)
        TextAim1:SetTextColor(Color(255, 255, 255, 255))
		
		local TextAim1 = vgui.Create("DLabel")
        TextAim1:SetText( "Bone Aim" )
        TextAim1:SetParent( Page1 )
        TextAim1:SetWide(100)
        TextAim1:SetPos(10,100)
        TextAim1:SetTextColor(Color(255, 255, 255, 255))
		
		local TextAim1 = vgui.Create("DLabel")
        TextAim1:SetText( "AimOnce" )
        TextAim1:SetParent( Page1 )
        TextAim1:SetWide(100)
        TextAim1:SetPos(10, 140)
        TextAim1:SetTextColor(Color(255, 255, 255, 255))
		
		local TextAim1 = vgui.Create("DLabel")
        TextAim1:SetText( "Auto SprayDown" )
        TextAim1:SetParent( Page1 )
        TextAim1:SetWide(100)
        TextAim1:SetPos(10,180)
        TextAim1:SetTextColor(Color(255, 255, 255, 255))
		
		local TextAim1 = vgui.Create("DLabel")
        TextAim1:SetText( "Auto Fire" )
        TextAim1:SetParent( Page1 )
        TextAim1:SetWide(100)
        TextAim1:SetPos(10,220)
        TextAim1:SetTextColor(Color(255, 255, 255, 255))
		
		local TextAim1 = vgui.Create("DLabel")
        TextAim1:SetText( "Aim Angle" )
        TextAim1:SetParent( Page1 )
        TextAim1:SetWide(100)
        TextAim1:SetPos(10,260)
        TextAim1:SetTextColor(Color(255, 255, 255, 255))
		
		local TextAim1 = vgui.Create("DLabel")
        TextAim1:SetText( "Smooth Aim" )
        TextAim1:SetParent( Page1 )
        TextAim1:SetWide(100)
        TextAim1:SetPos(10,300)
        TextAim1:SetTextColor(Color(255, 255, 255, 255))
		
		local TextAim1 = vgui.Create("DLabel")
        TextAim1:SetText( "Smooth Aim Speed" )
        TextAim1:SetParent( Page1 )
        TextAim1:SetWide(100)
        TextAim1:SetPos(10,340)
        TextAim1:SetTextColor(Color(255, 255, 255, 255))
		
		local TextAim1 = vgui.Create("DLabel")
        TextAim1:SetText( "Trigger Bot" )
        TextAim1:SetParent( Page1 )
        TextAim1:SetWide(100)
        TextAim1:SetPos(10,380)
        TextAim1:SetTextColor(Color(255, 255, 255, 255))
		
		local TextAim1 = vgui.Create("DLabel")
        TextAim1:SetText( "On Pressy Key ( Aimbot )" )
        TextAim1:SetParent( Page1 )
        TextAim1:SetWide(200)
        TextAim1:SetPos(10,420)
        TextAim1:SetTextColor(Color(255, 255, 255, 255)) 
		
		/* Aimbot Coding */
		
		 local Aim1 = vgui.Create( "DCheckBoxLabel", Page1 )
        Aim1:SetPos( 250, 20 )
        Aim1:SetText( "On/Off" )
        Aim1:SetConVar("")
        Aim1:SetValue(GetConVarNumber(""))
        Aim1:SizeToContents()
		
		 local Aim1 = vgui.Create( "DCheckBoxLabel", Page1 )
        Aim1:SetPos( 250, 60 )
        Aim1:SetText( "On/Off" )
        Aim1:SetConVar("")
        Aim1:SetValue(GetConVarNumber(""))
        Aim1:SizeToContents()
		
		local Aim1 = vgui.Create( "DCheckBoxLabel", Page1 )
        Aim1:SetPos( 250, 100 )
        Aim1:SetText( "On/Off" )
        Aim1:SetConVar("")
        Aim1:SetValue(GetConVarNumber(""))
        Aim1:SizeToContents()

		local AimList = vgui.Create( "DComboBox", Page1)
		AimList:SetPos(250,100)
		AimList:SetSize( 82, 20 )
		for k, v in pairs(Numb.bones) do
			AimList:AddChoice(v[1]);
		end
		AimList.OnSelect = function(self)
			Numb.Notify(false,lblue,"Set aimspot to bone "..self:GetValue()..".")
		old_rcc("Hera_AIM_AimSpot",self:GetValue())
	end
	
		local Aim1 = vgui.Create( "DCheckBoxLabel", Page1 )
        Aim1:SetPos( 250, 140 )
        Aim1:SetText( "On/Off" )
        Aim1:SetConVar("")
        Aim1:SetValue(GetConVarNumber(""))
        Aim1:SizeToContents()
		
		local Aim1 = vgui.Create( "DCheckBoxLabel", Page1 )
        Aim1:SetPos( 250, 180 )
        Aim1:SetText( "On/Off" )
        Aim1:SetConVar("")
        Aim1:SetValue(GetConVarNumber(""))
        Aim1:SizeToContents()
		
		local Aim1 = vgui.Create( "DCheckBoxLabel", Page1 )
        Aim1:SetPos( 250, 220 )
        Aim1:SetText( "On/Off" )
        Aim1:SetConVar("")
        Aim1:SetValue(GetConVarNumber(""))
        Aim1:SizeToContents()
		
		local FoVSlider = vgui.Create( "DNumSlider", Page1 )
		FoVSlider:SetPos( 250, 220 )
		FoVSlider:SetSize( 150, 100 ) -- Keep the second number at 100
		FoVSlider:SetText( "Aimbot Field of View" )
		FoVSlider:SetMin( 0 ) -- Minimum number of the slider
		FoVSlider:SetMax( 180 ) -- Maximum number of the slider
		FoVSlider:SetDecimals( 0 ) -- Sets a decimal. Zero means it's a whole number
		FoVSlider:SetConVar( "" ) -- Set the convar
		
		local Aim1 = vgui.Create( "DCheckBoxLabel", Page1 )
        Aim1:SetPos( 250, 300 )
        Aim1:SetText( "On/Off" )
        Aim1:SetConVar("")
        Aim1:SetValue(GetConVarNumber(""))
        Aim1:SizeToContents()
		
		local FoVSlider = vgui.Create( "DNumSlider", Page1 )
		FoVSlider:SetPos( 250, 300 )
		FoVSlider:SetSize( 150, 100 ) -- Keep the second number at 100
		FoVSlider:SetText( "Smooth Aim Speed" )
		FoVSlider:SetMin( 0 ) -- Minimum number of the slider
		FoVSlider:SetMax( 5 ) -- Maximum number of the slider
		FoVSlider:SetDecimals( 1 ) -- Sets a decimal. Zero means it's a whole number
		FoVSlider:SetConVar( "" ) -- Set the convar
	
		local Page2 = vgui.Create( "DImage" )
        AdvTab:AddSheet( "Render", Page2, "gui/silkicons/user", false, false, "Render Settings" )

		/* Render Labels */

				local TextAim1 = vgui.Create("DLabel")
        TextAim1:SetText( "WallHack" )
        TextAim1:SetParent( Page2 )
        TextAim1:SetWide(100)
        TextAim1:SetPos(10,20)
        TextAim1:SetTextColor(Color(255, 255, 255, 255))
		
		local TextAim1 = vgui.Create("DLabel")
        TextAim1:SetText( "Collision Box" )
        TextAim1:SetParent( Page2 )
        TextAim1:SetWide(100)
        TextAim1:SetPos(10,60)
        TextAim1:SetTextColor(Color(255, 255, 255, 255))
		
		local TextAim1 = vgui.Create("DLabel")
        TextAim1:SetText( "Colored Skin" )
        TextAim1:SetParent( Page2 )
        TextAim1:SetWide(100)
        TextAim1:SetPos(10,100)
        TextAim1:SetTextColor(Color(255, 255, 255, 255))
		
		local TextAim1 = vgui.Create("DLabel")
        TextAim1:SetText( "No Smoke" )
        TextAim1:SetParent( Page2 )
        TextAim1:SetWide(100)
        TextAim1:SetPos(10, 140)
        TextAim1:SetTextColor(Color(255, 255, 255, 255))
		
		local TextAim1 = vgui.Create("DLabel")
        TextAim1:SetText( "No Flash" )
        TextAim1:SetParent( Page2 )
        TextAim1:SetWide(100)
        TextAim1:SetPos(10,180)
        TextAim1:SetTextColor(Color(255, 255, 255, 255))
		
		local TextAim1 = vgui.Create("DLabel")
        TextAim1:SetText( "Visibility Check" )
        TextAim1:SetParent( Page2 )
        TextAim1:SetWide(100)
        TextAim1:SetPos(10,220)
        TextAim1:SetTextColor(Color(255, 255, 255, 255))
		
		/* Render CheckBox */
		
		local Aim1 = vgui.Create( "DCheckBoxLabel", Page2 )
        Aim1:SetPos( 250, 20 )
        Aim1:SetText( "On/Off" )
        Aim1:SetConVar("")
        Aim1:SetValue(GetConVarNumber(""))
        Aim1:SizeToContents()
		
		local Aim1 = vgui.Create( "DCheckBoxLabel", Page2 )
        Aim1:SetPos( 250, 60 )
        Aim1:SetText( "On/Off" )
        Aim1:SetConVar("")
        Aim1:SetValue(GetConVarNumber(""))
        Aim1:SizeToContents()
		
		local Aim1 = vgui.Create( "DCheckBoxLabel", Page2 )
        Aim1:SetPos( 250, 100 )
        Aim1:SetText( "On/Off" )
        Aim1:SetConVar("")
        Aim1:SetValue(GetConVarNumber(""))
        Aim1:SizeToContents()
		
		local Aim1 = vgui.Create( "DCheckBoxLabel", Page2 )
        Aim1:SetPos( 250, 140 )
        Aim1:SetText( "On/Off" )
        Aim1:SetConVar("")
        Aim1:SetValue(GetConVarNumber(""))
        Aim1:SizeToContents()
		
		local Aim1 = vgui.Create( "DCheckBoxLabel", Page2 )
        Aim1:SetPos( 250, 180 )
        Aim1:SetText( "On/Off" )
        Aim1:SetConVar("")
        Aim1:SetValue(GetConVarNumber(""))
        Aim1:SizeToContents()
		
		local Aim1 = vgui.Create( "DCheckBoxLabel", Page2 )
        Aim1:SetPos( 250, 220 )
        Aim1:SetText( "On/Off" )
        Aim1:SetConVar("")
        Aim1:SetValue(GetConVarNumber(""))
        Aim1:SizeToContents()

		local Page3 = vgui.Create( "DImage" )
        AdvTab:AddSheet( "ESP", Page3, "gui/silkicons/wrench", false, false, "Customize The Cheat" )
		
		/* ESP Labels */
		local TextAim1 = vgui.Create("DLabel")
        TextAim1:SetText( "3D Radar" )
        TextAim1:SetParent( Page3 )
        TextAim1:SetWide(100)
        TextAim1:SetPos(10,20)
        TextAim1:SetTextColor(Color(255, 255, 255, 255))
		
		/* ESP CheckBoxes */
		local Misc3 = vgui.Create( "DCheckBoxLabel")
		Misc3:SetText( "On/Off" )
		Misc3:SetConVar( "numb_ESP_Info" )
		Misc3:SetParent( Page3 )
		Misc3:SetPos( 250, 20 )
		Misc3:SetValue( GetConVarNumber("numb_ESP_Info") )
		Misc3:SetTextColor( Color(255 , 255 , 255 , 255 ) )
		Misc3:SizeToContents()
		
		local Page4 = vgui.Create( "DImage" )
        AdvTab:AddSheet( "Hack", Page3, "gui/silkicons/wrench", false, false, "Customize The Cheat" )
		
		local TextAim1 = vgui.Create("DLabel")
        TextAim1:SetText( "" )
        TextAim1:SetParent( Page3 )
        TextAim1:SetWide(100)
        TextAim1:SetPos(10,20)
        TextAim1:SetTextColor(Color(255, 255, 255, 255))
end )


