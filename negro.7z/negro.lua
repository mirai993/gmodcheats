local espOn      = CreateClientConVar("negro_ESP", "1", true, false)
local setspeed   = CreateClientConVar("negro_setspeed", "6.0", true, false)
local silentAim  = CreateClientConVar("negroSilentBot", "0", true, false)
local removerec  = CreateClientConVar("negro_no_recoil", "0", true, false)
local dBotOn     = CreateClientConVar("negro_aimbot", "1", true, false)
local boneaim    = CreateClientConVar("negro_aimbot_bone", "ValveBiped.Bip01_Head1", true, false)
local NEGROaim     = CreateClientConVar("negro_aimbot_onshoot", "0", true, false)
local infov1     = CreateClientConVar("negro_aimbot_infov", 0, true, false)
local infov2     = CreateClientConVar("negro_aimbot_fov", 90, true, false)

--ESP--

local function negro_ESP()
	if espOn:GetBool() then
		for k,v in pairs (player.GetAll() ) do
				local ESP = (v:EyePos()):ToScreen()
				if v == LocalPlayer() then Name = "" else Name = v:Nick()

				if v:IsAdmin() then
					draw.DrawText(v:Name(), "BudgetLabel", ESP.x, ESP.y -46, team.GetColor(v:Team()), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT)
					draw.DrawText("Admin", "BudgetLabel", ESP.x, ESP.y -23, Color(255, 255, 255, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT)
				elseif v:IsSuperAdmin() then
					draw.DrawText(v:Name(), "BudgetLabel", ESP.x, ESP.y -46, team.GetColor(v:Team()), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT)
					draw.DrawText("SuperAdmin", "BudgetLabel", ESP.x, ESP.y -23, Color(255, 255, 255, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT)
				else
					draw.DrawText(v:Name(), "BudgetLabel", ESP.x, ESP.y -46, team.GetColor(v:Team()), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT)
					draw.DrawText("User", "BudgetLabel", ESP.x, ESP.y -23, Color(255, 255, 255, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT)
				end
				draw.DrawText("Health: " .. v:Health(), "BudgetLabel", ESP.x, ESP.y -34, Color(255, 255, 255, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT)
				if(v:GetActiveWeapon():IsValid()) then
					draw.DrawText(v:GetActiveWeapon():GetClass(), "BudgetLabel", ESP.x, ESP.y -12, Color(255, 255, 255, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT)
				end
			end
		end
	end
end

hook.Add ("HUDPaint", "esp", negro_ESP)

--Speedhack--

require("cvar3")
 
TS = GetConVar('host_timescale')
CH = GetConVar('sv_cheats')

function speedon()
	speed = GetConVarNumber("negro_setspeed")
	CH:SetValue( 1.0 )
	TS:SetValue( speed )
end
 
function speedoff()
	CH:SetValue(0)
end
 
concommand.Add("+speedhack", speedon)
concommand.Add("-speedhack", speedoff)

--aimbot--

local function IsVisible( ent )
	local tracer = {}
	if(LocalPlayer():GetShootPos() != nil && ent:IsValid() && ent != nil && LocalPlayer():GetActiveWeapon():IsValid() && LocalPlayer():GetActiveWeapon() != nil && ent:LookupBone("ValveBiped.Bip01_Head1") != nil && ent:GetBonePosition(ent:LookupBone("ValveBiped.Bip01_Head1")) != nil) then
		tracer.start = LocalPlayer():GetShootPos()
		tracer.endpos = ent:GetBonePosition(ent:LookupBone("ValveBiped.Bip01_Head1"))
		tracer.filter = { LocalPlayer(), ent }
		tracer.mask = MASK_SHOT
		local trace = util.TraceLine( tracer )
		if trace.Fraction >= 1 then return true else return false end
	end
end

local function InFov(ent)
	for k,v in pairs(ents.FindInCone(LocalPlayer():GetShootPos(), LocalPlayer():GetAimVector(), 3000, GetConVarNumber("negro_aim_fov")))  do
		if(v:IsPlayer() && ent == v) then
			return true
		else
			return false
		end
	end
end

local function WHCheck(v)
	if v:Alive() == true && v:Health() ~= 0 && v:Health() >= 0 && v ~= LocalPlayer() && LocalPlayer():Alive() then
		return true
	else
		return false
	end
end

local function negro_aim()
        for k,v in pairs(player.GetAll()) do
                local bone = tostring(boneaim:GetString())
                if IsVisible( v ) and LocalPlayer():Alive() and v:Alive() and v ~= LocalPlayer() and v:Team() ~= TEAM_SPECTATOR and LocalPlayer():Team() ~= TEAM_SPECTATOR and GetConVarNumber("negro_aimbot") == 1 and LocalPlayer():GetActiveWeapon():GetClass() ~= "weapon_physgun" and LocalPlayer():GetActiveWeapon():GetClass() ~= "gmod_tool" and LocalPlayer():GetActiveWeapon():GetClass() ~= "gmod_camera" and LocalPlayer():GetActiveWeapon():GetClass() ~= "weapon_crowbar" then
                        if GetConVarNumber("FIA_aimbot_onshoot") >= 1 then
                                if LocalPlayer():KeyDown(IN_ATTACK) then
                                        if(GetConVarNumber("negro_aimbot_infov") == 1) then
                                                if(InFov(v)) then
                                                        local head = v:LookupBone(bone)
                                                        local headpos,targetheadang = v:GetBonePosition(head)
                                                        LocalPlayer():SetEyeAngles((headpos - LocalPlayer():GetShootPos()):Angle())
                                                end
                                        else
                                                local head = v:LookupBone(bone)
                                                local headpos,targetheadang = v:GetBonePosition(head)
                                                LocalPlayer():SetEyeAngles((headpos - LocalPlayer():GetShootPos()):Angle())
                                        end
                                end
                        else
                                if(GetConVarNumber("negro_aimbot_infov") == 1) then
                                        if(InFov(v)) then
                                                local head = v:LookupBone(bone)
                                                local headpos,targetheadang = v:GetBonePosition(head)
                                                LocalPlayer():SetEyeAngles((headpos - LocalPlayer():GetShootPos()):Angle())
                                        end
                                else
                                        local head = v:LookupBone(bone)
                                        local headpos,targetheadang = v:GetBonePosition(head)
                                        LocalPlayer():SetEyeAngles((headpos - LocalPlayer():GetShootPos()):Angle())
                                end
                        end
                end
        end
end
hook.Add("Think", "NEGROaim", negro_aim)
