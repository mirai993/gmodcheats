/* 

	Hacks N Shit
		BooM
		
*/

concommand.Add( "+boom_hacks", function()

	Hacks = true
	
end)

concommand.Add( "-boom_hacks", function()

	Hacks = false
	
end)


hook.Add( "Think", "Hacks", function()

local ply = LocalPlayer()
local w = ply:GetActiveWeapon()

if ( Hacks ) then

	if ( w.Primary ) then w.Primary.Recoil = 0 end
	if ( w.Secondary ) then w.Secondary.Recoil = 0 end
	
	local trace = util.GetPlayerTrace( ply )
	local traceRes = util.TraceLine( trace ) 
	
	if traceRes.HitNonWorld then
		local target = traceRes.Entity 
			if target:IsPlayer() then 
				local targethead = target:LookupBone("ValveBiped.Bip01_Head1")
				local targetheadpos,targetheadang = target:GetBonePosition(targethead) 
				ply:SetEyeAngles((targetheadpos - LocalPlayer():GetShootPos()):Angle())
			end
		end
	
	else
		
		if ( w.Primary ) then w.Primary.Recoil = 3 end
		if ( w.Secondary ) then w.Secondary.Recoil = 3 end
		
		target = nil
		
	end
end)
------------------------------------
local SpectatingPlayers = {}
hook.Add("HUDPaint", "GBOT_ShowSpectators", function()
	
	SpectatingPlayers = {}
	local x = 0

	for _,pl in ipairs( player.GetAll() ) do
	
		if( pl:GetObserverTarget() == LocalPlayer() ) then
		
			table.insert( SpectatingPlayers, pl )
			
		end
		
	end
	
	surface.SetFont( "ScoreboardText" )
	local w, text_h = surface.GetTextSize( "penis" )
	local textLength = #SpectatingPlayers*text_h + #SpectatingPlayers*2
	draw.RoundedBox( 1, ScrW() - 350, ScrH() - 45 - textLength, 280, 30 + textLength, Color( 180, 180, 180 ) )
	draw.TexturedQuad( {

		texture = surface.GetTextureID( "gui/center_gradient" ),
		color = Color( 255, 255, 255, 120 ),
		x = ScrW() - 350,
		y = ScrH() - 45 - textLength,
		w = 280,
		h = 30 + textLength
		
	} )
	
	
	draw.SimpleText( "Spectators", "ChatFont", ScrW() - 340, ScrH() - 55 - textLength, Color( 120, 120, 120, 255 ) )
	for _, v in ipairs( SpectatingPlayers ) do
		draw.SimpleText( v:Nick(), "ScoreboardText", ScrW() - 315, ScrH() - 45 - textLength + x + text_h + 3, color_black )
		x = x + text_h + 2
	end
	
end )
------------------------------------
concommand.Add("+bhop",function()
hook.Add("Think","BHOP",function()
RunConsoleCommand((LocalPlayer():IsOnGround() and "+" or "-").."jump")
end)
end)

concommand.Add("-bhop",function()
hook.Remove("Think","BHOP")
RunConsoleCommand("-jump")
end)
------------------------------------
local Walls = {}

Walls.MatVis = CreateMaterial( "GBotChams_Vis", "UnlitGeneric", {

	[ "$basetexture" ] = "color/white",
	["$ignorez"]	 = 0
	
} )

Walls.MatInvis = CreateMaterial( "GBotChams_Invis", "UnlitGeneric", {

	["$basetexture"] = "color/white",
	["$ignorez"]	 = 1
	
} )

Walls.On = CreateClientConVar( "walls_chamson", 1, true, false )

function Walls.Draw()
	
	if( !Walls.On:GetBool() ) then return end
	
	local fvis =	Color( 0, 255, 0 )
	local finvis =	Color( 100, 100, 255 )
	local einvis =	Color( 255, 255, 0 ) 
	local evis =	Color( 255, 0, 0 ) 
	local winvis =	Color( 128, 0, 128 ) 
	local wvis =	Color( 255, 165, 0 ) 
	
	for _,ent in ipairs( ents.GetAll() ) do
	
		if( ( ent:IsPlayer() and ent:Alive() and ent:Team() != TEAM_SPECTATOR and ent != LocalPlayer() and ent:GetMoveType() != MOVETYPE_OBSERVER ) or ent:IsWeapon() ) then
			
			local color_invis = finvis
			local color_vis = fvis
			
			if( ent:IsPlayer() ) then
			
				//if( ent:GBOT_IsEnemy() ) then
				
				//	color_invis = einvis
				//	color_vis = evis
					
				//end
				
			elseif( ent:IsWeapon() ) then
			
				color_invis = winvis
				color_vis = wvis
				
			end
			
			cam.Start3D( EyePos(), EyeAngles() )

				render.SuppressEngineLighting( true )
				
				SetMaterialOverride( Walls.MatInvis )
				render.SetColorModulation( color_invis.r/255, color_invis.g/255, color_invis.b/255 )

				ent:DrawModel() -- Model Only Visible Through The Walls
				
				SetMaterialOverride( Walls.MatVis )
				render.SetColorModulation( color_vis.r/255, color_vis.g/255, color_vis.b/255 )

				ent:DrawModel() -- Model Not Visible Through Walls

				render.SuppressEngineLighting( false )
				render.SetColorModulation( 1, 1, 1 )
				SetMaterialOverride( 0 )

			cam.End3D()
			
		end
		
	end
	
end
hook.Add( "RenderScreenspaceEffects", "Walls_Draw", Walls.Draw )

hook.Add( "HUDPaint", "Wallhack", function()
 
	for k,v in pairs ( player.GetAll() ) do
 
		local Position = ( v:GetPos() + Vector( 0,0,80 ) ):ToScreen()
		local Name = ""
 
		if ( v == LocalPlayer() or !v:Alive() or v:Team() == TEAM_SPECTATOR ) then
			Name = "" 
			else Name = v:Name()
		end
 
		draw.DrawText( Name, "MenuLarge", Position.x, Position.y, Color( 255, 255, 255, 255 ), 1 )
 
	end
 
end )