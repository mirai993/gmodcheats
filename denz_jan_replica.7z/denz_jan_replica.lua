-- Note by paradox: Replica added some stuff to this.

//DenzHack by Denz
//Solo Coded with a bit paste. how else.
LocalPlayer():ConCommand("cl_interp 0.066; cl_interp_ratio 2; cl_updaterate 128; cl_cmdrate 128; gmod_mcore_test 8;");

RunConsoleCommand("menuhook_file_show_1337")
timer.Simple(0, function()
if !bSendPacket or !enginepred then
	pcall(function()
		require("dickwrap")
		require("cvar3")
		require("enginepred3")
	end)
end

local DH = {}
DH.Ver = "01.31.18"

local Color = Color

local sizeX = 716
local sizeY = 460
surface.CreateFont("Comic Sans MS", {
	font = "Comic Sans MS",
	size = 14,
	weight = 800
})

local dFont = "BudgetLabel"

local allply = player.GetAll()

local me = LocalPlayer()

local faply = NULL
local faply1 = NULL
local fakelagchams = NULL
local nulVec = Vector()
local globalOrig = nulVec
local silentAngle = Angle()

local cm
local ip = true
local lMouse = false
local rMouse = false
local AAchoke = false
local wheelUp = false
local wheelDown = false
local aimenable = false
local insertDown = false
local menuVisible = false
local rapidtoggle = false
local cStrafeToggle = false
local ActivatedModebox = false

local bones = {}
local bttab = {}
local bvtab = {}
local rndYAW =   {-180,-135,90,-45,0,45,90,135,180}
local rndPITCH = {-89,-45, 0,45,89}
local fakeAngles = Angle(0, 0, 0)
local realAngles = Angle(0, 0, 0)
local menuFixed = {}
local spreadTables = {}
local badSequences = {
	[ACT_VM_RELOAD] = true,
	[ACT_VM_RELOAD_SILENCED] = true,
	[ACT_VM_RELOAD_DEPLOYED] = true,
	[ACT_VM_RELOAD_IDLE] = true,
	[ACT_VM_RELOAD_EMPTY] = true,
	[ACT_VM_RELOADEMPTY] = true,
	[ACT_VM_RELOAD_M203] = true,
	[ACT_VM_RELOAD_INSERT] = true,
	[ACT_VM_RELOAD_INSERT_PULL] = true,
	[ACT_VM_RELOAD_END] = true,
	[ACT_VM_RELOAD_END_EMPTY] = true,
	[ACT_VM_RELOAD_INSERT_EMPTY] = true,
	[ACT_VM_RELOAD2] = true
}

local DanceModes = {
	"random",
	"robot",
	"muscle",
	"laugh",
	"bow",
	"cheer",
	"wave",
	"becon",
	"disagree",
	"forward",
	"group",
	"halt",
	"zombie",
	"dance"
}

local tracers = {}

local sv_gravity = GetConVar('sv_gravity'):GetFloat()
local sv_friction = GetConVar('sv_friction'):GetFloat()
local sv_stopspeed = GetConVar('sv_stopspeed'):GetFloat()
local sv_accelerate = GetConVar('sv_accelerate'):GetFloat()

local GUser = 1
local cStrafeRad = 0
local fakeLagSendCount = 0

local chamsmat_1 = CreateMaterial('randomname3312','VertexLitGeneric',{['$ignorez']=1,['$model']=1,['$basetexture']='models/debug/debugwhite',})
local chamsmat_2 = CreateMaterial('randomname33s2','Vertexlitgeneric',{['$ignorez']=0,['$model']=1,['$basetexture']='models/debug/debugwhite',})
local chamsmat_3 = CreateMaterial('randomname33ss','Vertexlitgeneric',{['$ignorez']=0,['$model']=1,['$translucent']=1,['$basetexture']='models/debug/debugwhite',})

local ATab = 1
local ATabs = {'AIMBOT','VISUALS','HVH','MISC','SETTINGS','PLAYERS'}

DH.Menu = {}
DH.Menu['HvH'] = {}
DH.Menu['Misc'] = {}
DH.Menu['Aimbot'] = {}
DH.Menu['General'] = {}
DH.Menu['Filters'] = {}
DH.Menu['Visuals'] = {}
DH.Menu['EVisuals'] = {}
DH.Menu['Settings'] = {}
DH.Menu['WhiteList'] = {}

DH.Vars = {}
DH.Vars['FoV'] = 90
DH.Vars['RealYaw'] = 0
DH.Vars['Cone FOV'] = 20
DH.Vars['RealPitch'] = 0
DH.Vars['Aim Smooth'] = 0
DH.Vars['ASUS Alpha'] = 75
DH.Vars['OwnFakeYaw'] = 0
DH.Vars['Rapid Delay'] = 0
DH.Vars['PlayerAAYaw'] = 0
DH.Vars['FakeLag Int'] = 1
DH.Vars['OwnFakePitch'] = 0
DH.Vars['ESP Distance'] = 15000
DH.Vars['FakeLag Send'] = 1
DH.Vars['FakeLag Choke'] = 1
DH.Vars['EESP Distance'] = 15000
DH.Vars['PlayerAAPitch'] = 0
DH.Vars['CStrafe Radius'] = 5
DH.Vars['Thirdperson FoV'] = 120
DH.Vars['FakeDuck maxticks'] = 1
DH.Vars['FakePing'] = 0
DH.Vars['FakeJitter'] = 0
DH.Vars['FakeLoss'] = 0
DH.Vars['FakeEblan power'] = 0
DH.Vars['tracers dietime'] = 30
DH.Vars['tracers max'] = 20

local DefVars = table.Copy(DH.Vars)

DH.Modes =
{
	['Save'] = {main = 'Legit'},
	['Bone'] = {main = 'Head'},
	['Aimbot'] = {main = 'Disable'},
	['AAType'] = {main = 'None'},
	['Predict'] = {main = 'Engine'},
	['AATable'] = {main = allply[1]:Name()},
	['BoneMode'] = {main = 'Center'},
	['AA Method'] = {main = 'None'},
	['FindMethod'] = {main = 'My pos'},
	['Dance mode'] = {main = 'dance'},
	['FakeEblan Method'] = {main = 'Mega eblan'},
	['KillRow mode'] = {main = 'Russian'}
}

bones['Head'] = 'ValveBiped.Bip01_Head1'
bones['Spine2'] = 'ValveBiped.Bip01_Spine2'
bones['Pelvis'] = 'ValveBiped.Bip01_Pelvis'
bones['Thigh'] = 'ValveBiped.Bip01_L_Thigh'
bones['Spine'] = 'ValveBiped.Bip01_Spine'

RunConsoleCommand('cl_interp',0.066)
RunConsoleCommand('cl_interp_ratio',2)
RunConsoleCommand('cl_updaterate',120)

RunConsoleCommand('cl_interp',0)
RunConsoleCommand('cl_updaterate',100000)
RunConsoleCommand('cl_interp_ratio',1)


local color_0 = Color(0,0,0)
local color_32 = Color(32,32,32)
local color_64 = Color(64,64,64)
local color_128 = Color(128,128,128)
local color_240 = Color(240,240,240)
local color_red = HSVToColor(0,1,0.7)

-- Copy Funcs
local gcam = cam
local gbit = bit
local ggui = gui
local gmath = math
local gteam = team
local guitl = util
local gtable = table
local gpairs = pairs
local ginput = input
local gstring = string
local gengine = engine
local gtostring = tostring

local bor = gbit.bor
local band = gbit.band
local bnot = gbit.bnot

local mceil = gmath.ceil
local mRand = gmath.Rand
local mHuge = gmath.huge
local mRound = gmath.Round
local mClamp = gmath.Clamp
local mrandom = gmath.random

local mousePos = ggui.MousePos
local ScW, ScH = ScrW(), ScrH()
local MsX, MsY = mousePos()

local sfind = gstring.find
local sRight = gstring.Right
local sExplode = gstring.Explode

local surface = surface
local sDrawRect = surface.DrawRect
local sDrawLine = surface.DrawLine
local sCreateFont = surface.CreateFont
local sGetTextSize = surface.GetTextSize
local sSetDrawColor = surface.SetDrawColor
local sDrawOutlinedRect = surface.DrawOutlinedRect

local grender = render
local rSetColorModulation = grender.SetColorModulation
local rSuppressEngineLighting = grender.SuppressEngineLighting
local rSetLightingMode = render.SetLightingMode
local rMaterialOverride = render.MaterialOverride

local cStart3D = gcam.Start3D
local cEnd3D = gcam.End3D
local cStart3D2D = gcam.Start3D2D
local cEnd3D2D = gcam.End3D2D

if DarkRP and DarkRP.disabledDefaults and DarkRP.disabledDefaults["workarounds"] and !DarkRP.disabledDefaults["workarounds"]["Cam function descriptive errors"] then
	local _, orgCamEnd3D = debug.getupvalue(cam.End3D, 2)
	local _, orgCamStart3D2D = debug.getupvalue(cam.Start3D2D, 2)
	local _, orgCamEnd3D2D = debug.getupvalue(cam.End3D2D, 2)

	cEnd3D = orgCamEnd3D
	cStart3D2D = orgCamStart3D2D
	cEnd3D2D = orgCamEnd3D2D
end

local tSort = gtable.sort
local tRandom = gtable.Random
local isValid = IsValid
local realTime = RealTime
local frameTime = FrameTime
local isKeyDown = ginput.IsKeyDown
local traceLine = guitl.TraceLine
local setMousePos = ggui.SetMousePos
local isMouseDown = ginput.IsMouseDown
local teamGetColor = gteam.GetColor
local tickInterval = gengine.TickInterval
local realFrameTime = RealFrameTime
local WasMousePressed = ginput.WasMousePressed
local RunConsoleCommand = RunConsoleCommand
local EnableScreenClicker = gui.EnableScreenClicker
local GetConVar = GetConVar

_G.oldcreatemove = _G.oldcreatemove or GAMEMODE.CreateMove

local function unload()
	GAMEMODE.CreateMove = oldcreatemove

	for k,v in gpairs(hook.GetTable()) do
		for k1,v1 in gpairs(v) do if sfind(gtostring(k1),'DH|') then hook.Remove(k,k1) end end
	end
	
	for k,v in gpairs(player.GetAll()) do
		v.dz_bfaa_flip = nil
		v.dz_bfaa_tick = nil
		v.dz_shots = nil
		v.dz_hurts = nil
	end

	for k,v in gpairs(bvtab) do
		if IsValid(v) then v:Remove() end
	end

	if IsValid(faply) then
		faply:Remove()
	end

	if IsValid(faply1) then
		faply1:Remove()
	end
	
	if IsValid(fakelagchams) then
		fakelagchams:Remove()
	end

	timer.Remove('UpdatePlayer')
	timer.Remove('NavalnyTopchik')

	bSendPacket = true
	EnableScreenClicker(false)
	RunConsoleCommand('stopsound') // damn son
end

unload()

local function AddHek(txt,fnc)
	local sys,txsz = gtostring(SysTime())..'\n',#txt
	MsgC('DenzHook added! ['..txt..'] '..(' '):rep((#sys+2-txsz)+20)..sys)

	local name = 'DH|' .. util.CRC(mrandom(10^4) + SysTime()) .. txt
	hook.Add(txt,name,fnc)
end

for k,v in gpairs(DH.Menu) do menuFixed[k] = {} for s,z in gpairs(v) do menuFixed[k][z] = false end end
DH.Menu = menuFixed

local function GetTextSize(font,str)
	surface.SetFont(font)
	return sGetTextSize(str)
end

local function InBox(x,y,x1,y1)
	return MsX > x and MsX < x1 and MsY > y and MsY < y1
end

local function DrawBox(col,x,y,sx,sy)
	sSetDrawColor(col)
	sDrawRect(x, y, sx, sy)
end

local function DrawText(col,x,y,str,font)
	surface.SetTextColor(col)
	surface.SetTextPos(x, y)
	surface.SetFont(font)
	surface.DrawText(str)
end

local function DrawLine(col,x,y,x1,y1)
	sSetDrawColor(col)
	sDrawLine(x, y, x1, y1)
end

local Round = math.Round
local function DrawRect(col,X,Y,W,H,Rev)
	X, Y = Round(X), Round(Y)
	W, H = Round(W), Round(H)

	if Rev then
		X = W<0 and X+W or X
		W = W<0 and -W or W
		Y = H<0 and Y+H or Y
		H = H<0 and -H or H
	end

	sSetDrawColor(col)
	sDrawRect(X, Y, W, H)
end

local function DrawOutlinedRect(col,x,y,w,h,fill)
	sSetDrawColor(col)
	x, y = mceil(x), mceil(y)
	w, h = mceil(w), mceil(h)
	fill = mceil(fill)
	local fx, fy = mClamp(fill, 0, w / 2),mClamp(fill, 0, h / 2)
	sDrawRect(x, y, w, fy)
	sDrawRect(x + w - fx, y + fy, fx,h - fy * 2)
	sDrawRect(x, y + h - fy, w, fy)
	sDrawRect(x, y + fy, fx, h - fy *2 )
end

sCreateFont('Theme', {
	font='Arial',
	size=13,
	weight=500
})

local function ThemeBox(name,x,y,x1,y1)
	DrawText(color_white,x+30,y-7,name,'Theme')

	local w,h = GetTextSize('Theme',name)
	sSetDrawColor(color_red)
	sDrawLine(x,y,x+25,y)
	sDrawLine(x+w+35,y,x+x1,y)
	sDrawLine(x,y+y1,x+x1,y+y1)
	sDrawLine(x,y+y1,x,y)
	sDrawLine(x+x1,y+y1,x+x1,y)
end

local function CheckBox(indx,name,x,y,rname)
	local txt = rname or name
	DrawText(color_white,x+20,y,txt,dFont)
	if InBox(x+1,y+1,x+14,y+14) then
		if lMouse and !ActivatedModebox then DH.Menu[indx][name] = !DH.Menu[indx][name] end
	end

	DrawRect(color_red,x+2,y+2,12,12)
	if DH.Menu[indx][name] then DrawRect(color_0,x+4,y+4,8,8) end

	sSetDrawColor(0,0,0,122)
	sDrawOutlinedRect(x+1,y+1,14,14)
end

local function Button(name,x,y,w,h,func)
	local sw,sh = GetTextSize(dFont,name)
	local color = color_32
	if InBox(x,y,x+w,y+h) then
		color = color_red
		if lMouse and !ActivatedModebox then func() end
	end
	DrawRect(color,x,y,w,h)
	DrawText(color_white,x+w/2-sw/2,y,name,dFont)
end

local function WhitelistButton(pl,x,y,w,h)
	local sw,sh = GetTextSize(dFont,pl:Name())
	local color = color_32
	local id = pl:SteamID()
	if InBox(x,y,x+w,y+h) then
		color = color_red
		if lMouse then
			DH.Menu.WhiteList[id] = !DH.Menu.WhiteList[id]
		end
		if rMouse then
			pl:ShowProfile()
		end
	end
	if DH.Menu.WhiteList[id] == true then color = color_red end

	DrawRect(color,x,y,w,h)
	DrawText(color_white,x+w/2-sw/2,y,pl:Name(),dFont)
end

local function AddSlider(name,x,y,len,min,max,rname,buff)
	if !DH.Vars[name..'buff'] then DH.Vars[name..'buff'] = mClamp(x+((DH.Vars[name]-min)/(max-min))*len,x,x+len) end
	local txt = rname or name
	local w,h = GetTextSize(dFont,txt)

	DrawText(color_white,x+len/2-w/2,y+5,txt,dFont)

	w,h = GetTextSize(dFont,DH.Vars[name])
	DrawText(color_white,x+len/2-w/2,y-7,DH.Vars[name],dFont)

	w,h = GetTextSize(dFont,tostring(max))
	DrawText(color_white,x,y+5,tostring(min),dFont)
	DrawText(color_white,x+len-w,y+5,tostring(max),dFont)

	local xxx = mClamp(DH.Vars[name..'buff'],x,x+len)
	local slidcol = color_white

	if InBox(x-1,y,x+len+1,y+18) then
		if wheelUp then
			DH.Vars[name] = mClamp(DH.Vars[name]+1,min,max)
			DH.Vars[name..'buff'] = mClamp(DH.Vars[name..'buff']-(1/(min-max)*len),x,x+len)
		elseif wheelDown then
			DH.Vars[name] = mClamp(DH.Vars[name]-1,min,max)
			DH.Vars[name..'buff'] = mClamp(DH.Vars[name..'buff']+(1/(min-max)*len),x,x+len)
		elseif isMouseDown(MOUSE_LEFT) and !ActivatedModebox then
			slidcol = color_red
			DH.Vars[name..'buff'] = mClamp(MsX,x,x+len)
			DH.Vars[name] = mClamp(Round(min+(((xxx-x)/len)*(max-min))),min,max)
		end
	end

	DrawRect(color_red,x,y+5,len,3)
	DrawRect(slidcol,DH.Vars[name..'buff'],y+2,3,6)
end

local function ModeBox(indx,x,y,w,h,tab)
	if !DH.Modes then DH.Modes = {idnx={main=tab[1],tab=false}} end
	local name,bname = DH.Modes[indx].main,DH.Modes[indx].main
	local sw,sh = GetTextSize(dFont,name)
	local boxcol = color_64
	if InBox(x,y,x+w,y+h) and !ActivatedModebox then boxcol = color_red if lMouse then lMouse=false DH.Modes[indx].tab = !DH.Modes[indx].tab end end
	local cnt=1

	if DH.Modes[indx].tab then
		boxcol = color_red
		for k,z in gpairs(tab) do
			local choosecol = DH.Modes[indx].main == z and color_red or color_32
			local v='' for i=1,13 do v = v..z[i] end
			local sw,sh = GetTextSize(dFont,v)
			if InBox(x,y+cnt*h,x+w+w,y+cnt*h+h) then
				if lMouse then
					DH.Modes[indx].main = z
					DH.Modes[indx].tab  = false
					ActivatedModebox = false
				else
					ActivatedModebox = true
				end
				choosecol = color_red
			end
			DrawRect(choosecol,x,y+cnt*h,w,h)
			DrawText(color_white,x+w/2-sw/2,y+cnt*h,v,dFont)
			cnt = cnt + 1
		end
		cnt = 1
	end

	DrawRect(color_32,x,y,w,h)
	DrawRect(boxcol,x+w-10,y+3,8,8)
	local v = name:sub(1, 13)
	sw, sh = GetTextSize(dFont,v)
	DrawText(color_white,x+w/2-sw/2,y,v,dFont)
end

local function LoadConfig(name)
	if !file.IsDir('alloyavera','DATA') then file.CreateDir('alloyavera') end
	if !file.Exists('alloyavera/def.txt','DATA') then file.Write('alloyavera/def.txt','') return end
	local tbl = util.JSONToTable(
	file.Exists("alloyavera/"..name..'.txt','DATA') and
	file.Read("alloyavera/"..name..'.txt')
	or '')
	or nil

	if tbl then
		for k,v in pairs(tbl.Vars)  do DH.Vars[k] = v end
		for k,v in pairs(tbl.Menu)  do DH.Menu[k] = v end
		for k,v in pairs(tbl.Modes) do DH.Modes[k] = v end
	end

	allply = player.GetAll()
end

local buff = table.Copy(DH)
LoadConfig('Custom')
if !DH.Menu['Settings']['Autoload'] then DH = buff end

local function SaveConfig(name)
	local buff = table.Copy(DH)
	/*
	for k, v in pairs(DH.Vars) do
		if sRight(k,4) == 'buff' then
			buff.Vars[k] = nil
		end

		for z, s in pairs(DefVars) do
			if z == k then
				buff.Vars[k] = nil
			end
		end
	end

	for k,v in pairs(DH) do
		if type(v) =='table' and next(v) == nil then
			buff[k] = nil
		end
	end

	for k,v in pairs(DH.Menu) do
		if next(v) == nil then
			buff.Menu[k] = nil
		end
	end
	*/

	file.Write('alloyavera/' .. name .. '.txt', util.TableToJSON(buff or {['Corrupted file!'] = true}))
end

local function DeleteConfig(name) file.Delete('alloyavera/'..name..'.txt') end

//Menu Hook
local function ownerName()
	local Members =
	{
		['STEAM_0:0:34824919'] = 'Denz',
	}

	return Members[me:SteamID()] or me:Name()
end

local ATabAnim = {}
local SessionID = util.CRC(os.time())

sCreateFont('Tabs',{font='Impact',size=40,weight = 500})
AddHek('DrawOverlay',function()
	if DH.Menu['Visuals']['Watermark'] then DrawText(color_red,4,0,'Samoware.cc v.'..DH.Ver,dFont) end
	if DH.Menu['Misc']['Info Panel'] then
		if me:Alive() then
			local eye = me:EyeAngles()

			local selfInfo =
			{
				{'Welcome ' .. ownerName() .. '! Session ID:' .. SessionID, col=1},
				{'Your STATS:'                          , col=1},
				{'   Health:     ' .. me:Health()               },
				{'   Ping:       ' .. me:Ping()                 },
				{'   FPS:        ' .. mRound(1/FrameTime())     },
				{'   bSendPacket ' .. tostring(bSendPacket)},
				{'   FakeLag:    ' .. DH.Vars['FakeLag Choke'] .. ' ' .. DH.Vars['FakeLag Send']},
				{'   Speed:      ' .. mRound(me:GetVelocity():Length(),2)},
				{'   Yaw:        ' .. mRound(eye.y,3)            },
				{'   Pitch:      ' .. mRound(eye.p,3)            },
				{'   AntiAim:    ' .. DH.Modes['AA Method'].main },
				{'   real Y:     ' .. mRound(realAngles.y,3)%360 },
				{'   real P:     ' .. mRound(realAngles.p,3)     },
				{'   fake Y:     ' .. mRound(fakeAngles.y,3)%360 },
				{'   fake P:     ' .. mRound(fakeAngles.p,3)     },
			}

			for k,v in pairs(selfInfo) do
				col = v.col == 1 and Color(255,255,0) or Color(255,255,255)

				if DH.Modes['AA Method'].main == 'None' and (k == 10 or k == 11 or k == 12 or k == 13) then continue end
				if mRound(realAngles.y) == mRound(fakeAngles.y) and mRound(realAngles.p) == mRound(fakeAngles.p) and (k == 12 or k == 13) then continue end

				DrawText(col,4,12*k,v[1],dFont)
			end
		end

		if IsValid(aaply) and aaply:Alive() then
			local y,p = 0,0
			local real = aaply:EyeAngles()
			local Method = aaply.AAMethod and aaply.AAMethod or 'None'

			if aaply.AAESP then y,p = aaply.AAESP.y or 0,aaply.AAESP.p or 0 end

			local targetInfo =
			{
				{'Target STATS:'                ,col=1},
				{'   Nick:    '..aaply:Name()         },
				{'   Rank:    '..aaply:GetUserGroup() },
				{'   Health:  '..aaply:Health()       },
				{'   Ping:    '..aaply:Ping()         },
				{'   Yaw:     '..mRound(real.y,3)     },
				{'   Pitch:   '..mRound(real.p,3)     },
				{'   AAA:     '..Method               },
				{'   AAA Y:   '..y		              },
				{'   AAA P:   '..p                    },
			}

			for k,v in pairs(targetInfo) do
				col = v.col == 1 and Color(255,255,0) or Color(255,255,255)

				if Method == 'None' and (k == 9 or k == 10) then continue end
				DrawText(col,4,12*k+156,v[1],dFont)
			end
		end
	end

	if !menuVisible then return end

	MsX,MsY = mousePos()
	local sx,sy = sizeX,sizeY
	local offX,offY = ScW/2-sx/2,ScH/2-sy/2

	if InBox(offX,offY-10,offX+sizeX,offY+10) then
		if input.IsMouseDown(MOUSE_LEFT) then
			offX = MsX/1.2
			offY = MsY
		end
	end

	DrawBox(DH.Menu['HvH']['Real Angles'] and Color(18,18,18,120) or Color(18,18,18,255),offX,offY,sx,sy)//MainBox
	DrawBox(color_red,offX,offY,sx,2)//TopBox
	DrawRect(color_red,offX+160,offY,1,sizeY)

	local namen = 'Samoware.cc v.'..DH.Ver
	local namenlen = #namen
	for i=0, namenlen do
		DrawText(HSVToColor(CurTime()*15+i%360,1,1),sizeX-namenlen*9+offX+i*8,offY+3,namen[i],dFont)
	end

	for i=0,sizeX do
		DrawRect(HSVToColor(200+i/5,0.7,1),offX+i,offY+2,1,3)
	end

	//Tabs
	for k,v in gpairs(ATabs) do
		local w = sx/#ATabs
		local x,y = GetTextSize('Tabs',v)
		local tabcolor = color_128
		if InBox(offX+5,offY+y/2+k*30-25+4-7,offX+5+x,offY+y/2+k*30-25+32-7) then
			ATabAnim[k] = SysTime()
			tabcolor = color_240
			if lMouse then ATab = k end
		else
			local mem1 = mClamp(255-((SysTime()-(ATabAnim[k] or 0))*255),0,100)
			local mem2 = mClamp(255-((SysTime()-(ATabAnim[k] or 0))*255),60,90)

			tabcolor = HSVToColor(0,mem1/100,mem2/100)
		end

		DrawText(ATab == k and color_white or tabcolor,offX+5,offY+y/2+k*30-25-7,v,'Tabs')
	end

	//Auto Adjust Box
	if ATab == 6 then
		sizeY = (#allply>23 and #allply <64) and 460+((#allply-5)*20) or 460
	else
		sizeY = 460
	end

	local dx,dy = offX+180,offY+10

	Button('Save',offX+5,offY+340+20*3,72.5,15, function() SaveConfig(DH.Modes['Save'].main) end)
	Button('Load',offX+82,offY+340+20*3,72.5,15, function() LoadConfig(DH.Modes['Save'].main) end)
	Button('Unload',offX+5,offY+340+20*5,72.5,15,function() unload() timer.Simple(0.1,function() if DH then DH=nil end end) end)
	Button('Fast Quit',offX+82,offY+340+20*5,72.5,15, function() RunConsoleCommand('gamemenucommand','quitnoconfirm') end)

	ModeBox('Save',offX+5,offY+340+20*4,150,15,{'Rage','Legit','Custom'})

	//Aimbot Checkboxes
	if ATab == 1 then //Aimbot
		ThemeBox('Aimbot',dx-10,dy+10,155,315)

		CheckBox('Aimbot','Silent',dx,dy+20*6)
		CheckBox('Aimbot','Spread',dx,dy+20*7)
		CheckBox('Aimbot','Autoshoot',dx,dy+20*8)

		CheckBox('Aimbot','Auto Walls',dx,dy+20*9)
		CheckBox('Aimbot','Rapid Fire',dx,dy+20*10)
		AddSlider('Rapid Delay',dx,dy+20*11,140,0,500)

		CheckBox('Aimbot','Kill Once',dx,dy+20*12)

		CheckBox('Aimbot','Cone',dx,dy+20*13)
		AddSlider('Cone FOV',dx,dy+20*14,140,0,360)

		AddSlider('Aim Smooth',dx,dy+20*15,140,0,100)

		ModeBox('BoneMode',dx,dy+20*5,135,15,{'Borders','Hitscan','Center'})
		ModeBox('Predict',dx,dy+20*4,135,15,{'Engine','EngineC','VelBase','Ping','GTick','Classic','MTick','None'})
		ModeBox('Bone',dx,dy+20*3,135,15,{'Head','Pelvis','Spine', 'Spine2', 'Thigh'})
		ModeBox('FindMethod',dx,dy+20*2,135,15,{'Crosshair','My pos','Crosshair 2D','Random'})
		ModeBox('Aimbot',dx,dy+20*1,135,15,{'Disable','Auto','Key'})
	end

	//Visuals
	if ATab == 2 then
		ThemeBox('Players',dx-10,dy+10,155,420)

		CheckBox('Visuals','Enabled',dx,dy+20*1)
		CheckBox('Visuals','Box',dx,dy+20*2)
		CheckBox('Visuals','Name',dx,dy+20*3)
		CheckBox('Visuals','Rank',dx,dy+20*4)
		CheckBox('Visuals','Health',dx,dy+20*5)
		CheckBox('Visuals','Hit Boxes',dx,dy+20*6)
		CheckBox('Visuals','Skeletones',dx,dy+20*7)
		CheckBox('Visuals','AA Mode',dx,dy+20*8)
		CheckBox('Visuals','Chams',dx,dy+20*9)
		CheckBox('Visuals','Fakelag Chams',dx,dy+20*10)
		CheckBox('Visuals','Fullbright',dx,dy+20*11)
		CheckBox('Visuals','Tracers',dx,dy+20*12)
		CheckBox('Visuals','Aim Dot',dx,dy+20*13)
		CheckBox('Visuals','Halo',dx,dy+20*14)
		CheckBox('Visuals','Whitelist',dx,dy+20*15)

		AddSlider('ESP Distance',dx,dy+20*16,140,0,285000)

		CheckBox('Visuals','Bullet tracers',dx,dy+20*17)
		CheckBox('Visuals','Fake model',dx,dy+20*18)
		AddSlider('tracers dietime',dx,dy+20*19,140,0,60)
		AddSlider('tracers max',dx,dy+20*20,140,0,60)

		ThemeBox('Entities',dx+155,dy+10,155,115)
		CheckBox('EVisuals','Enabled',dx+165,dy+20*2)
		CheckBox('EVisuals','Props',dx+165,dy+20*3)
		CheckBox('EVisuals','Weapons',dx+165,dy+20*4)
		CheckBox('EVisuals','Money',dx+165,dy+20*5)

		AddSlider('EESP Distance',dx+165,dy+20*1,140,0,285000)

		ThemeBox('Misc',dx+155,dy+135,155,235)
		CheckBox('Visuals','Crosshair 2D',dx+165,dy+125+20*1)
		CheckBox('Visuals','Crosshair 3D',dx+165,dy+125+20*2)
		CheckBox('Visuals','ASUS',dx+165,dy+125+20*3)

		AddSlider('ASUS Alpha',dx+165,dy+125+20*4,140,0,100)
		CheckBox('Misc','Thirdperson',dx+165,dy+125+20*5)

		AddSlider('FoV',dx+165,dy+125+20*6,140,30,140)
		AddSlider('Thirdperson FoV',dx+165,dy+125+20*7,140,0,500)

		CheckBox('Visuals','Night Mode',dx+165,dy+125+20*8)
		CheckBox('Visuals','Watermark',dx+165,dy+125+20*9)
		CheckBox('Visuals','Spectators',dx+165,dy+125+20*10)
		CheckBox('Visuals','Angles',dx+165,dy+125+20*11)

	end

	//HVH
	if ATab == 3 then
		//Anti-Aim
		ThemeBox('Anti-Aim',dx-10,dy+10,155,195)

		CheckBox('HvH','Real Angles',dx,dy+20*2)

		AddSlider('OwnFakeYaw',dx,dy+20*3,140,-180,180,'Fake Yaw')
		AddSlider('RealYaw',dx,dy+20*4,140,-180,180,'Real Yaw')
		AddSlider('RealPitch',dx,dy+20*5,140,-89,89,'Real Pitch')

		CheckBox('HvH','Dancer',dx,dy+20*6)

		CheckBox('HvH','FakeDuck',dx,dy+20*8)
		CheckBox('HvH','Invert fakeduck', dx,dy+20*9)

		//Anti-Anti-Aim
		local NameTbl = {}
		for k,v in gpairs(allply) do
			if !isValid(v) then continue end
			NameTbl[v:SteamID()] = v:Name()
			if DH.Modes['AATable'].main == v:Name() and GUser != v:SteamID() then
				DH.Vars['PlayerAAYaw'] = v.AAYaw or 0
				DH.Vars['PlayerAAPitch'] = v.AAPitch or 0
				DH.Modes['AAType'].main   = v.AAMethod or 'None'

				DH.Vars['PlayerAAYawbuff'] = mClamp(dx+((DH.Vars['PlayerAAYaw']+180)/(180+180))*140,dx,dx+140/2)--kill me
				DH.Vars['PlayerAAPitchbuff'] = mClamp(dx+((DH.Vars['PlayerAAPitch']+89)/(89+89))*140,dx,dx+140/2)

				GUser = v:SteamID()
			end

			if DH.Modes['AATable'].main == v:Name() then
				v.AAYaw = v.AAYaw and DH.Vars['PlayerAAYaw'] or 0
				v.AAPitch = v.AAPitch and DH.Vars['PlayerAAPitch'] or 0
				v.AAMethod = v.AAMethod and DH.Modes['AAType'].main or 'None'
			end
		end

		ThemeBox('Anti-Anti-Aim',dx-10,dy+215,155,155)

		CheckBox('HvH','Backtrack',dx,dy+205+20*1)
		AddSlider('PlayerAAYaw',dx,dy+205+20*2,140,-180,180,'Player Yaw')
		AddSlider('PlayerAAPitch',dx,dy+205+20*3,140,-90,90,'Player Pitch')

		Button('Reset AA Table',dx,dy+205+20*6,135,15,function()
			DH.Modes['AATable'].main = 'None'
			for k,v in gpairs(allply) do
				DH.Vars['PlayerAAYaw'] = 0
				DH.Vars['PlayerAAPitch'] = 0
				DH.Modes['AAType'].main = 'None'
				v.AAYaw = 0
				v.AAPitch = 0
				v.AAMethod = 'None'
				v.ResolveTableP = nil
				v.ResolveTableY = nil
				v.KResolveTableP = nil
				v.KResolveTableY = nil
				DH.Vars['PlayerAAYawbuff'] = mClamp(dx+((DH.Vars['PlayerAAYaw']+180)/(180+180))*100,dx+140/2,dy)--kill me
				DH.Vars['PlayerAAPitchbuff'] = mClamp(dx+((DH.Vars['PlayerAAPitch']+89)/(89+89))*100,dx+140/2,dy)
			end
		end)

		Button('Reset Player',dx,dy+205+20*7,135,15,function()
			for k,v in gpairs(allply) do
				if DH.Modes['AATable'].main == v:Name() then
					DH.Vars['PlayerAAYaw'] = 0
					DH.Vars['PlayerAAPitch'] = 0
					DH.Modes['AAType'].main = 'None'
					v.AAYaw = 0
					v.AAPitch = 0
					v.AAMethod = 'None'
					v.ResolveTableP = nil
					v.ResolveTableY = nil
					v.KResolveTableP = nil
					v.KResolveTableY = nil
					DH.Vars['PlayerAAYawbuff'] = mClamp(dx+((DH.Vars['PlayerAAYaw']+180)/(180+180))*100,dx,dy+140)--kill me
					DH.Vars['PlayerAAPitchbuff'] = mClamp(dx+((DH.Vars['PlayerAAPitch']+89)/(89+89))*100,dx,dy+140)
				end
			end
		end)

		ModeBox('AAType',dx,dy+205+20*5,135,15,{'None','rok','Auto','Custom','Static','Random',
		'Resolver Flick','Resolver Kill','180 Gay','180 90 -90','Bruteforce'})
		ModeBox('AATable',dx,dy+205+20*4,135,15,NameTbl)

		ModeBox('Dance mode',dx,dy+20*7,135,15,DanceModes)

		ModeBox('AA Method',dx,dy+20*1,135,15,
		{
		'None','Edge','Fake Angle','Static','StaticJit','Invert','RealDown','Legit','FakeFakeUP',
		'FakeUP','HandBlock','RandomJit','Sideways','Spinbot','Spinbot 2x','FakeBW','FakeBW2'
		})


		ThemeBox('Fake Lag',dx+155,dy+10,155,195)

		CheckBox('HvH','Fake Lag',dx+165,dy+20*1)
		AddSlider('FakeLag Send', dx+165,dy+20*2,140,1,14)
		AddSlider('FakeLag Choke',dx+165,dy+20*3,140,1,14)
		CheckBox('HvH','Break lagcomp',dx+165,dy+20*4)
		CheckBox('HvH','Fakelag on peek',dx+165,dy+20*5)
		Button('bSendPacket ' .. tostring(bSendPacket),dx+165,dy+20*6,135,15,function() bSendPacket = !bSendPacket end)
		CheckBox('HvH','Fake eblan',dx+165,dy+20*7)
		AddSlider('FakeEblan power',dx+165,dy+20*8,140,0,30)

		ThemeBox('Fake Ping',dx+320,dy+10,155,95)
		CheckBox('HvH','Fake Ping',dx+330,dy+20*1)
		AddSlider('FakePing', dx+330,dy+20*2,140,0,1500)
		AddSlider('FakeJitter',dx+330,dy+20*3,140,0,100)
		AddSlider('FakeLoss', dx+330,dy+20*4,140,0,100)

		ThemeBox('Enable Modules',dx+155,dy+215,155,75)

		CheckBox('HvH','Engine Predict',dx+165,dy+215+20*1)
		CheckBox('HvH','Spread Dickwrap',dx+165,dy+215+20*2)
		CheckBox('HvH','cvar3',dx+165,dy+215+20*3)

		ModeBox('FakeEblan Method',dx+165,dy+20*9,135,15,{'Mega eblan', 'Slippery eblan'})
	end

	//Misc
	if ATab == 4 then
		ThemeBox('Misc',dx-10,dy+10,155,255)

		CheckBox('Misc','BunnyHop',dx,dy+20*1)
		CheckBox('Misc','Autostrafer',dx,dy+20*2)
		CheckBox('Misc','Edge Jump',dx,dy+20*3)
		CheckBox('Misc','Flashlight',dx,dy+20*4)
		CheckBox('Misc','Chat KillRow',dx,dy+20*5)
		CheckBox('Misc','Chat ShotLog',dx,dy+20*7)
		CheckBox('Misc','Info Panel',dx,dy+20*8)

		CheckBox('Misc','Navalny',dx,dy+20*9)

		CheckBox('Misc','CStrafe',dx,dy+20*10)
		AddSlider('CStrafe Radius',dx,dy+20*11,140,0,20)

		CheckBox('Misc','Fastwalk',dx,dy+20*12)
		
		ModeBox('KillRow mode',dx,dy+20*6,135,15,{'Russian','Eng','Opezdal','HvH rus','HvH eng'})
	end

	//Settings
	if ATab == 5 then
		ThemeBox('General',dx-10,dy+10,115,115)
		CheckBox('Settings','Music OFF',dx,dy+20*2)
		CheckBox('Settings','Sound OFF',dx,dy+20*3)
		CheckBox('Settings','Autoload',dx,dy+20*4)
	end

	if ATab == 6 then
		//WhiteList
		ThemeBox('White List',dx-10,dy+10,155,15+(#allply)*20)

		for k,v in gpairs(allply) do
			if !v:IsValid() then continue end
			local name = ''
			local id = v:SteamID()
			for i=1,15 do name = name..v:Nick()[i] end
			name = name..(#v:Nick() >= 15 and '..' or '')
			if v:IsBot() or !v:SteamID() then id = v:UserID() end
			WhitelistButton(v,dx,dy+20*k,135,15)
		end

		//Filters
		ThemeBox('Filters',dx+155,dy+10,155,95)

		CheckBox('Filters','No Friends',dx+165,dy+20*1)
		CheckBox('Filters','No Admins',dx+165,dy+20*2)
		CheckBox('Filters','No Teammates',dx+165,dy+20*3)
		CheckBox('Filters','No Bots',dx+165,dy+20*4)
	end
end)

//require'eng3'
//require'nspred'

AddHek('Think',function()
	if(not insertDown and isKeyDown(KEY_INSERT)) then
		menuVisible = !menuVisible
		EnableScreenClicker(menuVisible)
		setMousePos(MsX,MsY)
	end

	insertDown = isKeyDown(KEY_INSERT)
end)

----MENU END

--require('bspkt')
local rang = {}
local gay180 = {135,180,-135}
local function aaa()
	for k,v in gpairs(allply) do
		if v == me or !isValid(v) then continue end

		v.aaaTick = v.aaaTick or 0
		local ang = v:EyeAngles()
		local ang = v:GetAngles()
		local p,y = ang.p,ang.y
		rang[v] = ang

		v.AAESP = v.AAESP or {}
		v.AAESP.mode = 'off'

		if v.AAMethod == 'None' or v.AAMethod == nil then continue end

		if v.AAMethod == 'Resolver Flick' then
			/*v.ResolveTableP = v.ResolveTableP or {}
			v.ResolveTableY = v.ResolveTableY or {}
			local rp, ry = mRound(p/40)*40, mRound((y%180)/40)*40
			local kek = true
			for i = 1,#v.ResolveTableP do
				if v.ResolveTableP[i] == rp and v.ResolveTableY[i] == ry then
					kek = false
					break
				end
			end

			if kek then
				print(v:Name(),'Gocha!',p,y)
				v.ResolveTableP[#v.ResolveTableP+1] = rp
				v.ResolveTableY[#v.ResolveTableP+1] = ry
			end

			local rnd = mrandom(#v.ResolveTableP-5,#v.ResolveTableP) and #v.ResolveTableP-v.aaaTick%5
			p = v.ResolveTableP[rnd] or prndPITCH[v.aaaTick%#rndPITCH+1]
			y = v.ResolveTableY[rnd] or yrndYAW[v.aaaTick%#rndYAW+1] */

			v.AAESP.mode = 'Flick'
		end

		if v.AAMethod == 'Resolver Kill' then
			if v:Health()<1 and !v.KResolveTableY then
				v.KResolveTableP = mClamp(p,-49,49)
				v.KResolveTableY = y%180
			end
			p = v.KResolveTableP or rndPITCH[v.aaaTick%#rndPITCH+1]
			y = v.KResolveTableY or rndYAW[v.aaaTick%#rndYAW+1]
			v.AAESP.mode = 'Resolver Kill'
		end

		if v.AAMethod == 'Auto' then
			v.AAESP.mode = 'Auto'
			local rp = mRound(p)
			local r3 = mRound(p,3)
			if  mRound(p,3) == 72.246  then y = y - 180 v.AAESP.mode = '612 Backward' end

			if  r3 == 1.055    then p = (v.aaaTick%2 == 0 and -49) or 49 y = y + 180 v.AAESP.mode = 'Spinbot' end
			if  r3 == 178.945 then p = (v.aaaTick%2 == 0 and -49) or 49   v.AAESP.mode = '178.945' end
			if  r3 == 303.047 then p = (v.aaaTick%2 == 0 and -49) or 49   v.AAESP.mode = '303.047' end
			if  r3 >= 72.070 and r3 <= 72.246 then y = y - 180 v.AAESP.mode = '612 Backward' end

			if y == 5.0089 then y = y + 180  v.AAESP.mode = '5.00..' end

			if  r3 == 89.121   then y = y + 180    v.AAESP.mode = 'Backward 1' end
			if  r3 == 89.824   then y = y + 180    v.AAESP.mode = 'Backward 2' end
			if -mRound(p,6) == 0.000005 then
				print(mRound(p,6))
				p = (v.aaaTick%2 == 0 and -49) or 49
				y = (v.aaaTick%2 == 0 and y-90) or y+90
				y = y-180
				y = y - 180
				v.AAESP.mode = 'Huge fuck'
			end

			if  mRound(p,3) == 87.012 or mRound(p,3) == 1.934 or mRound(p,3) == 2.637 or mRound(p,3) == 5.449 or mRound(p,3) == 88.066 then
				p = (v.aaaTick%2 == 0 and -49) or 49
				y = (v.aaaTick%2 == 0 and 0) or 180
				y = y + mRand(-10,10)

				local pitches = { -181, 541, 262 }
				local yaws = { 262, -262, 181, -181, 541, -541 }

				p = pitches[v.aaaTick%#pitches+1]
				y = yaws[v.aaaTick%#yaws+1]

				v.AAESP.mode = 'Strange'
			end

			if  mRound(p,3) == 88.945 then
				y = y - 180
				y = y + ((v.aaaTick%4 == 0 and 0) or 180 )
				p = (v.aaaTick%2 == 0 and -49) or 49
				v.AAESP.mode = 'Sideways'
			end

			if rp == 180 then p = (v.aaaTick%2 == 0 and -49) or 49 v.AAESP.mode = '180 Pitch' end

			if (p == 271.0546875) then p = (v.aaaTick%2 == 0 and -49) or 49 v.AAESP.mode = '271. up/down' end
			if (p == 322.03125)   then p = (v.aaaTick%2 == 0 and -49) or 49 v.AAESP.mode = '322. up/down' end
		end

		--p = -180.000005,180
		--if v.AAMethod == 'Static' then p,y = v.AAPitch,  v.AAYaw v.AAESP.mode = 'Static' end
		if v.AAMethod == 'Static' then
			p, y = ((mRound(-180.000005) == -612) and 89) or -180.000005, 180
		end

		if v.AAMethod == 'Custom' then p,y = v.AAPitch,y+v.AAYaw v.AAESP.mode = 'Custom' end

		if v.AAMethod == 'Random' then
			p,y = rndPITCH[v.aaaTick%#rndPITCH+1],rndYAW[v.aaaTick%#rndYAW+1]
			v.AAESP.mode = 'Random'
		end

		if v.AAMethod == '180 90 -90' then
			y = (me:GetPos()-v:GetPos()):Angle().y-gay180[v.aaaTick%#gay180+1]
			p = (v.aaaTick%2 == 0 and -49) or 49
			p = 49
			v.AAESP.mode = '180 90 -90'
		end

		if v.AAMethod == '180 Gay' then
			y = (me:GetPos()-v:GetPos()):Angle().y-180+v.AAYaw
			p = 49
			v.AAESP.mode = 'Backward Mode'
		end
		
		if v.AAMethod == 'Bruteforce' then
			if v.dz_bfaa_flip == nil then v.dz_bfaa_flip = true end
			p = v.dz_bfaa_flip and 89 or -89
			y = (v.dz_bfaa_tick or 0) * 45
			if y > 360 then
				y = 0
				v.dz_bfaa_tick = 0
				v.dz_bfaa_flip = !v.dz_bfaa_flip
			end
		end

		v:SetPoseParameter("aim_pitch", p);
		v:SetPoseParameter("head_pitch",p);

		v:SetPoseParameter("body_yaw", y);
		v:SetPoseParameter("aim_yaw", y);
		v:InvalidateBoneCache()
		v:SetRenderAngles(Angle(0, math.NormalizeAngle(y), 0))
		--v:SetupBones()

		v:InvalidateBoneCache();
		v:SetRenderAngles(Angle(0,y,0));

		v.AAESP.p = p or 0
		v.AAESP.y = y or 0
	end
end

local function getBPred(ent)
	ent.drop     = ent.drop or 0
	ent.speed    = ent.speed or 0
	ent.control  = ent.control or 0
	ent.wishvel  = ent.wishvel or nulVec
	ent.newspeed = ent.newspeed or 0

	local vel,grnd = ent:GetVelocity(),ent:IsOnGround()
	local ent_gravity = ent:GetGravity() or 1
	if !grnd then vel.z=vel.z-(ent_gravity*sv_gravity*.5*frameTime()) end
	if ent:WaterLevel() < 2  then
		ent.speed = vel:Length()
		if ent.speed > 0.1 then
			if grnd then
				ent.control = ent.speed < sv_stopspeed and sv_stopspeed or ent.speed
				ent.drop = ent.control * sv_friction * frameTime()
			end
			ent.newspeed = ent.speed - ent.drop
			if ent.newspeed < 0 then ent.newspeed = 0 end
			if ent.newspeed != ent.speed then
				ent.newspeed = ent.newspeed / ent.speed
				vel.x = vel.x * ent.newspeed
				vel.y = vel.y * ent.newspeed
				vel.z = vel.z * ent.newspeed
			end
		end
		ent.wishvel=(1-ent.newspeed)*Vector(vel.x,vel.y,vel.z)
	end

	local wishdir,wishspeed = ent.wishvel,ent.wishvel:Length()

	if wishspeed != 0 then
		wishdir = wishdir / wishspeed
		if (wishspeed > ent:GetMaxSpeed()) then
			ent.wishvel = ent.wishvel * ( ent:GetMaxSpeed() / wishspeed )
			wishspeed = ent:GetMaxSpeed()
		end
	end

	local addspeed,accelspeed,currentspeed = 0,0,0
	currentspeed = vel:Dot(wishdir)
	addspeed = wishspeed-currentspeed
	if addspeed > 0 then
		accelspeed = sv_accelerate * frameTime() * wishspeed
		if accelspeed > addspeed then accelspeed = addspeed end
		vel.x = vel.x*accelspeed*wishdir.x
		vel.y = vel.y*accelspeed*wishdir.y
		vel.z = vel.z*accelspeed*wishdir.z
	end
	vel.z = grnd and 0 or vel.z-(ent_gravity*sv_gravity*0.5*frameTime())
	return Vector(vel.x,vel.y,vel.z)
end

local function veloPredict(vec,trg)
	if !vec then return nulVec end
	local lvel,tvel,frm,eng = me:GetVelocity(),trg:GetVelocity(),realFrameTime(),tickInterval()

	if DH.Modes['Predict'].main == 'None' then return vec end
	if DH.Modes['Predict'].main == 'EngineC' then return vec+(tvel/45-lvel/45) end
	if DH.Modes['Predict'].main == 'VelBase' then return vec+((lvel-tvel)*(frm/(1/eng))) end
	if DH.Modes['Predict'].main == 'Classic' then return vec-(lvel*eng) end--vec+((tvel*eng)-(lvel*eng)) end -- minus to plus ex
	if DH.Modes['Predict'].main == 'Engine'  then return tvel == nulVec and vec or vec+tvel*eng*frm-lvel*eng end
	if DH.Modes['Predict'].main == 'MTick' then return vec+((getBPred(trg)*eng)-(getBPred(me)*eng))end
	if DH.Modes['Predict'].main == 'Ping'  then return vec+(tvel-lvel)*(me:Ping()*.001)*2 end
	if DH.Modes['Predict'].main == 'GTick' then return vec+(((tvel*frm/25)-(tvel*frm/66))-((lvel*frm/25)+(lvel*frm/66))) end
end

local function EdgeJump(cmd)
	if me:IsOnGround() and me:WaterLevel() < 2 and me:GetMoveType() == MOVETYPE_WALK then
		local StartPos,EndPos=me:GetPos(),me:GetPos()-Vector(0,0,18)
		local DirVec=Vector(me:GetVelocity():Angle():Forward().x,me:GetVelocity():Angle():Forward().y,0)*8
		local DirVec2=Vector(me:GetVelocity():Angle():Forward().x,me:GetVelocity():Angle():Forward().y,0)*16
		local f={start=StartPos-DirVec,endpos=EndPos-DirVec,filter=me,mask=MASK_PLAYERSOLID}
		local s={start=StartPos-DirVec2,endpos=EndPos-DirVec2,filter=me,mask=MASK_PLAYERSOLID}
		if traceLine(f).Fraction==1 and traceLine(s).Fraction!=1 then cmd:SetButtons(bor(cmd:GetButtons(),IN_JUMP)) end
	end
end

local fakeMode = 0
local function fakelag(cmd)
	local choke = DH.Vars['FakeLag Choke']
	local send = DH.Vars['FakeLag Send']
	fakeLagTickCount = choke + send
	if DH.Menu['HvH']['Fake Lag'] then
		fakeLagSendCount = fakeLagSendCount + 1
		if fakeLagSendCount > fakeLagTickCount then fakeLagSendCount = 1 end
		bSendPacket = send >= fakeLagSendCount and true or false

		local speed = me:GetVelocity():Length()

		RunConsoleCommand('cl_interp',0)
		RunConsoleCommand('cl_updaterate',128000)
		RunConsoleCommand('cl_interp_ratio',1)

		if true then return end

		if choke > 5 and speed == 0 and fakeMode != 1 then
			fakeMode = 1
			RunConsoleCommand('cl_updaterate',1048576)
			RunConsoleCommand('cl_cmdrate',1048576)
			RunConsoleCommand('cl_interp',0.695)
		end

		if choke <= 5 and choke > 1 and speed == 0 and fakeMode != 2 then
			fakeMode = 2
			RunConsoleCommand('cl_updaterate',66)
			RunConsoleCommand('cl_cmdrate',66)
			RunConsoleCommand('cl_interp',0.7)
		end

		if choke == 1 and speed == 0 and fakeMode != 3 then
			fakeMode = 3
			RunConsoleCommand('cl_updaterate',67)
			RunConsoleCommand('cl_cmdrate',67)
			RunConsoleCommand('cl_interp',1)
		end
	end
end

local function breaklagcomp(cmd)
	local vel = me:GetVelocity()
	local speed = vel:Length2D()
	
	local dst_per_tick = speed * tickInterval()
	
	local chokes = gmath.ceil(64 / dst_per_tick)
	chokes = gmath.Clamp(chokes, 1, 14)
	
	DH.Vars['FakeLag Choke'] = chokes
	DH.Vars['FakeLag Send'] = 1
	
	fakelag(cmd)
end

local function isVisible(vec,v)
	if DH.Menu['Aimbot']['Auto Walls'] then
		local wep = me:GetActiveWeapon()
		if wep and IsValid(wep) and wep:GetClass():StartWith("m9k") then
			local tr = traceLine({
				start = EyePos(),
				endpos = vec,
				mask = MASK_SHOT,
				filter = me
			})

			if wep:BulletPenetrate(0, nil, tr, DamageInfo()) then return true end
		end
	end

	local tr = traceLine({
		start = me:EyePos(),
		endpos = vec,
		mask = MASK_SHOT,
		filter = me
	})

	if DH.Menu['Aimbot']['Cone'] and (gmath.abs(gmath.deg(gmath.cos(me:GetEyeTrace().Normal:Dot(tr.Normal)))) >= DH.Vars['Cone FOV']) then return false end
	return tr.Entity == v or tr.Fraction == 1 --tr.Fraction == 1 or (tr.Entity==v and (tr.HitGroup == HITGROUP_HEAD) or (tr.HitGroup == HITGROUP_CHEST)) --tr.HitBox == ent:LookupBone(bones[DH.Modes['Bone'].main])
end

local killrow_messages = {
	["Russian"] = {
		"%s lox)",
		"%s чет изи",
		"%s ого ты лох",
		"%s loshara",
		"%s гг изи",
		"%s слабый ты слабый)",
		"%s ого соснул",
		"%s ахах хдд соснул пздц",
		"лоол рили %s)",
		"%s да ты /\\()X",
		"%s страшна вырубай)",
		"ну че ты %s",
		"кто соснул? %s соснул",
		"КАК МАТЬ???? ЖИВА???? %s",
		"%s играть научись",
		"таких лохов как %s я в жизни не встречал....",
		"%s ты медленый",
		"%s слепошара",
		"%s ты говно",
		"%s пиздец лох",
		"%s ну что",
		"че по ебалу?)) %s"
	},
	["Eng"] = {
		"eat shit",
		"eat a fat steaming cock you unpriviledged homosexual",
		"suck my universe sized dick",
		"drink my piss fucking faggot",
		"hop off my dick fucking nigger",
		"%s is so shit",
		"can you stop dying,".."%s?",
		"hey,".."%s? it's okay,try again next time!",
		"what the fuck was that %s?",
		"plan your next try in the respawn room!",
		"rekt",
		"owned",
		"lol",
		"you're a retard, %s",
		"there you go,back to the respawn",
		"you're bad, %s",
		"noob down",
		"lmao",
		"%s has died more times than native americans did back in the 1800's",
		"i bet you're insecure about your aim",
		"ahahah",
		"excuse me, %s, you have won the world record of the worst KD in history!",
		"there he goes back to the respawn room",
		"don't let the door hit you on the way out, %s!",
		"noob",
		"%s is a noob",
		"nerd",
		"pff",
		"ha",
		"ez",
		"%s is a nerd",
		"good job!",
		"try not to die next time, %s!",
	},
	["Opezdal"] = {
	
	},
	["HvH rus"] = {
		"включи уже антиаим хуесос",
		"ебать ты лошара",
		"какой же ты тупой",
		"изи свинья ебаная",
		"%s хватит сосать мой хуй",
		"что у тебя за говночит? %s",
		"%s был выебан в очко",
		"аим включи уебище))",
		"%s а я смотрю ты любишь сосать",
		"удаляй игру тупорылый хуесос",
		"ебать ты нищий",
		"1 свинья тупая",
		"пиздец ты опездал",
		"только не плачь",
		"%s как можно быть настолько косым с читами?",
		"%s ты куда стреляешь уебище",
		"%s я был в другой стороне хуеглот",
		"%s куда стреляешь долбаеб ебаный",
		"%s у тебя ресолвера нету что ли еблан?",
		"%s включи уже компенсатор фейклагов ебаный даун",
		"%s блять куда ты стреляешь?",
		"%s какой же ты изи",
		"%s включи autofire во вкладке аим ебанат",
		"%s спорим ты щас включишь баим пидарас",
		"ору нищ",
		"%s подписчик урбанички",
		"%s фанат метха",
		"%s лошок ебаный"
	},
	["HvH eng"] = {
		"sick resolver",
		"sick fakelag",
		"sick antiaim",
		"sick aimbot",
		"sick bhop",
		"sick spinbot",
		"nice aimware paste",
		"nice memeware paste",
		"what the fuck are you using lol",
		"sick cfg",
		"it must be a cfg issue, right?",
		"it must be a brain issue",
		"fix your *DEAD* ok thx",
		"BRUH",
		"ez",
		"ezz",
		"*DEAD*",
		"what are you shooting at lmao",
		"ez retard",
		"ez nn",
		"lol why so ez",
		"lol ez",
		"bro imagine resolving in gmod",
		"nice fucking engine prediction",
		"sick enginepred, you sell???",
		"nice brain, you sell???",
		"nice cfg, you sell???",
		"nice keybinds, you sell???",
		"nice aimware paste, you sell???",
		"nice free the skids paste",
		"nice internet",
		"nice computer",
		"sick steeringwheel assistance",
		"nice steeringwheel assistance",
		"insane vip hack",
		"insane aimware paste",
		"crazy aimware paste",
		"i cant tell if you're joking",
		"too fucking easy",
		"nice playstyle",
		"nice chromosome count",
		"easiest kill of my life",
		"nice fucking antiaim",
		"consider suicide",
		"imagine the only thing you eat being bullets man",
		"ez idiot",
		"is this methamphetamine???",
		"is this idiotbox???",
		"is this aoshax???",
		"is this rijin???",
		"is this (random aimware paste cheat name)",
		"no spin no win",
		"no backtrack no win",
		"ez baim retard",
		"mind enabling your antiaim",
		"mind enabling your fakelag",
		"ming enabling your aimbot",
		"nice keybinds",
		"wtf you died when i was afk",
		"even smeghack will tap you LMAO",
		"green green what's your problem green me say alone ramp me say alone ramp",
		"so ez",
		"I'll disable my antiaim just for you"
	}
}

do
	local opezdal = file.Read("menuhook/loles.txt", "MOD"):Split("\n")
	for k, v in ipairs(opezdal) do
		if #v < 255 then
			table.insert(killrow_messages["Opezdal"], v)
		end
	end
	
	print(#killrow_messages["Opezdal"], "opezdals loaded")
end

local function KillRow()
	local strings = killrow_messages[DH.Modes['KillRow mode'].main]
	return strings[math.random(#strings)]
end

gameevent.Listen('entity_killed')
AddHek('entity_killed', function(data)
	local victim, attacker = Entity(data.entindex_killed), Entity(data.entindex_attacker)
	if !victim.aaaTick then victim.aaaTick = 0 end

	if attacker == me and attacker != victim then
		if victim:IsPlayer() then
			victim.aaaTick = victim.aaaTick - 1
			if DH.Menu['Misc']['Chat KillRow'] then
				local msg = KillRow()
				if msg:find("%s") then
					local nick = victim:Nick():Replace("\n", "\\n"):Replace("\t", "\\t")
					msg = msg:format(nick)
				end
				
				RunConsoleCommand('say', msg)
			end
		end
	end
end)

AddHek('Think', function()
	if DH.Menu['HvH']['Dancer'] then
		local dance = DH.Modes['Dance mode'].main
		if dance == 'random' then
			dance = DanceModes[math.random(1, #DanceModes)]
		end

		GAMEMODE.CreateMove = function()
			if !me:IsPlayingTaunt() then
				RunConsoleCommand("act", dance)
			end
		end
	else
		GAMEMODE.CreateMove = oldcreatemove
	end

	if DH.Menu['HvH']['cvar3'] then
		GetConVar("sv_cheats"):SetValue(1)

		if DH.Menu['HvH']['Fake Ping'] then
			GetConVar("net_fakelag"):SetValue(DH.Vars['FakePing'])
			GetConVar("net_fakejitter"):SetValue(DH.Vars['FakeJitter'])
			GetConVar("net_fakeloss"):SetValue(DH.Vars['FakeLoss'])
		else
			GetConVar("net_fakelag"):SetValue(0)
			GetConVar("net_fakejitter"):SetValue(0)
			GetConVar("net_fakeloss"):SetValue(0)
		end
	else
		-- FIX
		/*GetConVar("sv_cheats"):SetValue(0)
		GetConVar("net_fakelag"):SetValue(0)
		GetConVar("net_fakejitter"):SetValue(0)
		GetConVar("net_fakeloss"):SetValue(0)*/
	end
end)

local navalny = {
	"Навальный топчик",
	"Навальный топчик",
	"Навальный топчик",
	"Навальный топчик,за него Тверскую топчем",
	"Навальный топчик,за него Тверскую топчем",
	"Нью Бэланс кеды, прилипли к подошве гетры",
	"Но сегодня в центре в них устроим веселье",
	"Мы отсюда не свалим",
	"Все кто дома - не с нами",
	"Мы тут просто гуляем",
	"В нашем сердце весна В нашем сердце весна",
	"В нашем сердце весна",
	"Навальный топчик,за него Тверскую топчем",
	"Навальный топчик,скажем громче",
	"Навальный топчик,за него Тверскую топчем",
	"Навальный топчик,",
	"Навальный топчик,за него Тверскую топчем",
	"Тверскую топчем",
	"Вокруг так много космонавтов",
	"МКС полицейский пазик",
	"Лица скрывают каски,маски",
	"Становиться опасно,но",
	"Мы устроим пляски",
	"Дружно,под эти песни",
	"Вся Тверская в курсе",
	"Вся Тверская денсит",
	"Тверская денсит",
	"Тверская денсит",
	"Денсит",
	"Навальный топчик,за него Тверскую топчем",
	"Навальный топчик,скажем громче",
	"Навальный топчик,за него Тверскую топчем",
	"Навальный топчик,",
	"Навальный топчик,за него Тверскую топчем",
	"Тверскую топчем",
	"Навальный топчик",
	"15 суток, нам нет места от скуки",
	"Ждем когда вернешься, Навальный Леша",
	"Время летит быстро,скоро новая вписка",
	"Мы не пойдем на пары если,Навальный с нами",
	"Навальный с нами,давай с нами",
	"Навальный с нами, пойдем тусить с нами",
	"Навальный с нами, давай с нами",
	"Давай с нами, пойдем тусить с нами",
	"Этому городу нужен герой",
	"Леша Навальный, мы с тобой",
	"Этой стране нужен герой",
	"Леша Навальный, мы с тобой",
	"Этой планете нужен герой",
	"Леша Навальный, мы с тобой",
	"Этой Вселенной нужен герой",
	"Леша Навальный, мы с тобой",
	"Этой Вселенной нужен герой",
	"Леша Навальный, мы с тобой",
	"Леша Навальный, мы с тобой"
}
local navalnenok = 0

local function navalnytimer()
	if !DH.Menu['Misc']['Navalny'] then
		navalnenok = 0
		return
	end

	navalnenok = navalnenok + 1
	if navalnenok>#navalny then navalnenok = 1 end

	RunConsoleCommand("say", navalny[navalnenok])
	--timer.Create('NavalnyTopchik', navalny[navalnenok], 0, navalnytimer)
end

timer.Create('NavalnyTopchik', 1, 0, navalnytimer)


local function GetHitBox(ply,b)
	for group = 0, ply:GetHitBoxGroupCount()-1 do
		for hitbox = 0, ply:GetHitBoxCount(group)-1 do
			local bone = ply:GetHitBoxBone(hitbox,group)
			if bone and bone == b then
				return hitbox
			end
		end
	end
	return 0
end

local function aimbotGetBone(ent)
	if !isValid(ent) then return end

	local ep
	local min,max = ent:GetHitBoxBounds(0, 0)
	if !min or !max then return ent:GetBonePosition(ent:LookupBone(bones[DH.Modes['Bone'].main]) or 0) end
	local bone, ang = ent:GetBonePosition(ent:LookupBone(bones[DH.Modes['Bone'].main]) or 0)
	min:Rotate(ang)
	max:Rotate(ang)
	ep = bone + ((min + max) * 0.5)

	if DH.Modes['BoneMode'].main == 'Center' then
		local matx = ent:GetBoneMatrix(ent:LookupBone(bones[DH.Modes['Bone'].main]) or -1)
		if matx then
			local ep = veloPredict(matx:GetTranslation() + matx:GetForward() * 4, ent)
			if isVisible(ep,ent) then return ep end
		end
	end

	if DH.Modes['BoneMode'].main == 'Hitscan' then
		local group = 0
		for hitbox = 0, ent:GetHitBoxCount(group) - 1 do
			bone, ang = ent:GetBonePosition(ent:GetHitBoxBone(hitbox, group))
			min, max = ent:GetHitBoxBounds(hitbox, group)
			min:Rotate(ang)
			max:Rotate(ang)
			ep = bone + ((min + max) * 0.5)
			ep = veloPredict(ep,ent)
			if isVisible(ep,ent) then return ep end
		end
	end

	if DH.Modes['BoneMode'].main == 'Borders' then
		local off = .5
		local b = ent:LookupBone(bones[DH.Modes['Bone'].main])
		if !b then
			if isVisible(ep,ent) then
				return ep
			end
			return ep
		end
		local M = ent:GetBoneMatrix(b) or Matrix()
		if M then
			local ep = veloPredict(M:GetTranslation()+M:GetForward()*4,ent)
			if isVisible(ep,ent) then return ep end

			local hb = GetHitBox(ent,b)
			local IN = {ent:GetHitBoxBounds(hb,0)}
			for i = 1,2 do
				local x = M:GetRight()*(-IN[i].y+(-IN[i].y < 0 and off or -off))
				for j = 1,2 do
					local y = M:GetForward()*(IN[j].x+(IN[j].x < 0 and off or -off))
					for k = 1,2 do
						local z = M:GetUp()*(IN[k].z+(IN[k].z < 0 and off or -off))
						local ep = veloPredict(M:GetTranslation()+x+y+z,ent)
						if isVisible(ep,ent) then return ep end
					end
				end
			end
		end
	end

	return isVisible(ep,ent) and ep
end

local function canFire(cmd)
	local wep = me:GetActiveWeapon()
	if !wep || !wep:IsValid() then return false end
	local sequence = wep:GetSequence()
	if badSequences[sequence] then return false end
	if DH.Menu['Aimbot']['Rapid Fire'] then
		return wep:GetNextPrimaryFire() <= enginepred.GetServerTime() - DH.Vars['Rapid Delay'] / 100
	end

	if wep:GetNextPrimaryFire() <= enginepred.GetServerTime() then
		return true
	end

	return false
end

local function rapidfire(cmd)
	if isValid(me) and isValid(me:GetActiveWeapon()) then
		if !canFire() then cmd:SetButtons(band(cmd:GetButtons(),bnot(IN_ATTACK))) return end
		if me:KeyDown(IN_ATTACK) then
			if me:GetActiveWeapon():GetClass() == 'weapon_physgun' then return end
			if rapidtoggle then
				cmd:SetButtons(bor(cmd:GetButtons(),IN_ATTACK))
				rapidtoggle = false
			else
				cmd:SetButtons(band(cmd:GetButtons(),bnot(IN_ATTACK)))
				rapidtoggle = true
			end
		end
	end
end

local function LengthSqrAng(ang)
	return math.pow(ang.p, 2) + math.pow(ang.y, 2) + math.pow(ang.z, 2)
end

function TimeToTicks(time)
	return math.floor(0.5 + time / engine.TickInterval())
end

function TicksToTime(ticks)
	return ticks * engine.TickInterval()
end

function fakeLagPredict(cmd,ent)
	ent = ent or LocalPlayer()
	if !DH.Menu['HvH']['Engine Predict'] then return end
	local simtime = enginepred.GetSimulationTime()
	if 16 > math.abs(TimeToTicks(simtime) - cmd:TickCount()) then
		cmd:SetTick(TimeToTicks(simtime))
	end
end

local function Backtrack(ent, cmd)
	if !DH.Menu['HvH']['Engine Predict'] then return end
	if bttab[ent] then
		local last = gmath.huge
		local record
		local simtime
		for k,v in next, bttab[ent] do
			if last > k then
				last = k
				simtime = k
				record = v
			end
		end
		if !record or !simtime then return end
		local correct = enginepred.GetLatency()
		local targettick = TimeToTicks(simtime)
		local deltaticks = TimeToTicks(correct - TicksToTime(enginepred.TickCount() - targettick))
		if gmath.abs(deltaticks) > (1 / engine.TickInterval() / 4) then return end
		local angles = record["angles"]
		local pos = record["pos"]
		local angdiff = ent:EyeAngles() - angles
		local posdiff = ent:GetPos() - pos

		if LengthSqrAng(angdiff) > 0.01 then
			ent:SetEyeAngles(record["angles"])
		end
		ent:SetCollisionBounds(record["mins"], record["maxs"])
		if posdiff:LengthSqr() > 0.01 then ent:SetPos(record["pos"]) end
		for k,v in next, record["poseparams"] do ent:SetPoseParameter(k, v) end
		ent:InvalidateBoneCache()
		ent:SetupBones()

		enginepred.SetTickCount(cmd, TimeToTicks(simtime) - enginepred.GetLatency())
	end
end

function BacktrackRecord()
	if !DH.Menu['HvH']['Engine Predict'] then return end
	for k,ent in next, allply do
		if ent == me then continue end
		if !ent:Alive() or ent:Health()<=0 then continue end
		if !bttab[ent] then bttab[ent] = {} else
			for i,v in next, bttab[ent] do
				local correct = enginepred.GetLatency()
				local targettick = TimeToTicks(i)
				local deltaticks = TimeToTicks(correct - TicksToTime(enginepred.TickCount() - targettick))
				if gmath.abs(deltaticks) > (1 / engine.TickInterval() / 4) then
					bttab[ent][i] = nil
				end
			end
		end

		local simtime = enginepred.GetSimulationTime(ent)
		if bttab[ent][simtime] then continue end
		bttab[ent][simtime] = {
			poseparams = {
				["aim_pitch"]  = ent:GetPoseParameter("aim_pitch"),
				["head_pitch"] = ent:GetPoseParameter("head_pitch"),
				["body_yaw"]   = ent:GetPoseParameter("body_yaw"),
				["aim_yaw"]    = ent:GetPoseParameter("aim_yaw")
			},
			angles = ent:EyeAngles(),
			pos = ent:GetPos(),
			mins = ent:OBBMins(),
			maxs = ent:OBBMaxs(),
			seq = ent:GetSequence(),
			cycle = ent:GetCycle()
		}
	end
end


--[[AddHek('PostFrameStageNotify',function()
	aaa()
	if DH.Menu['HvH']['Backtrack'] then BacktrackRecord() end
end)--]]


local function getPlayer(mode,enbl,aapl,selfpos)
	if !enbl then return end
	
	local pos = selfpos or me:GetPos()
	
	local pltbl = {}
	
	for k,v in gpairs(allply) do
		if !isValid(v) then continue end

		if !v or !v:IsPlayer() or v:IsDormant() or v == me or 0 >= v:Health() then continue end
		if !v:Alive() then continue end
		if !aimbotGetBone(v) and !aapl then continue end
		-- if v:GetColor().a <= 16 then continue end

		if (v:GetMoveType() == MOVETYPE_NONE) or (v:GetMoveType() == MOVETYPE_OBSERVER) then continue end
		if DH.Menu['Filters']['No Teammates'] and (me:Team() == v:Team()) then continue end
		if DH.Menu['Filters']['No Friends'] and v:GetFriendStatus() == 'friend' then continue end
		if DH.Menu['Filters']['No Admins'] and v:IsAdmin() then continue end
		if DH.Menu['Filters']['No Bots'] and v:IsBot() then continue end
		if DH.Menu.WhiteList[v:SteamID()] then continue end
		if v:Team() == TEAM_SPECTATOR then continue end

		if DH.Menu['HvH']['Backtrack'] then Backtrack(v,cm) end
		pltbl[#pltbl + 1] = v
	end

	if mode == 'Crosshair' then
		local pos = me:GetEyeTrace().HitPos
		tSort(pltbl, function(a,b)
			return (a:GetPos()-pos):LengthSqr() < (b:GetPos()-pos):LengthSqr()
		end)
	end

	if mode == 'My pos' then
		tSort(pltbl, function(a,b)
			return(a:GetPos()-pos):LengthSqr() < (b:GetPos()-pos):LengthSqr()
		end)
		
		return pltbl[1]
	end

	if mode == 'Crosshair 2D' then
		tSort(pltbl, function(a, b)
			local ats,bts = a:GetPos():ToScreen(), b:GetPos():ToScreen()
			return Vector(ScW/2-ats.x,ScH/2-ats.y,0):LengthSqr() < Vector(ScW/2-bts.x,ScH/2-bts.y,0):LengthSqr()
		end)
		
		return pltbl[1]
	end

	if mode == 'Random' then tRandom(pltbl) return pltbl[1] end

	return pltbl[1]
end

local fakelagging = false
local peeking = false
local peektick = 0
local function fakelagonpeek(cmd)
	local pos = me:GetPos()
	local vel = me:GetVelocity()
	
	pos = pos + vel * (tickInterval() * 14)
	
	local ply = getPlayer("My pos", true, false, pos)
	
	if ply and !peeking then
		peeking = true
		fakelagging = true
		peektick = 0
	elseif !ply then
		peeking = false
		fakelagging = false
	end
	
	local max_ticks = 15 - fakeLagTickCount
	if peeking and fakelagging then
		bSendPacket = peektick == max_ticks and true or false
		peektick = peektick + 1
		
		if peektick > max_ticks then
			fakelagging = false
		end
	end
end


local function bhop(cmd)
	if !DH.Menu['Misc']['BunnyHop'] then return end
	if me:GetMoveType() == MOVETYPE_NOCLIP or me:GetMoveType() == MOVETYPE_LADDER then return end

	if cmd:KeyDown(IN_JUMP) then
		if DH.Menu['Misc']['Autostrafer'] then
			cmd:SetButtons(bor(cmd:GetButtons(), IN_SPEED))
		end

		if !me:IsOnGround() then
			cmd:SetButtons(gbit.band(cmd:GetButtons(), gbit.bnot(IN_JUMP)))
			if DH.Menu['Misc']['Autostrafer'] then
				cmd:SetSideMove(cmd:GetMouseX() * 12)
			end
		end
		
		if gmath.abs(cmd:GetForwardMove()) < 1 then
			local mx = gmath.abs(cmd:GetMouseX()) * 2
			if mx == 0 then
				mx = 1
			elseif mx > 80 then
				mx = 100000000
			end
			
			local spd = me:GetVelocity():Length2D()
			if spd == 0 then
				spd = 1
			end
			
			cmd:SetForwardMove(15000 / spd / mx)
		end
	end
end

--[==[
local function bhop(cmd)
	if !DH.Menu['Misc']['BunnyHop'] then return end

	if me:GetMoveType() != MOVETYPE_NOCLIP && me:GetMoveType() != MOVETYPE_LADDER then
		if !me:OnGround() && cmd:KeyDown( IN_JUMP )then
			cmd:SetButtons( band( cmd:GetButtons(), bnot( IN_JUMP ) ) )

			if DH.Menu['Misc']['Autostrafer'] then
				cmd:SetSideMove( cmd:GetMouseX() * 7 )

				cmd:SetForwardMove( 5850 / me:GetVelocity():Length2D() )
				cmd:SetSideMove( ( cmd:CommandNumber() % 2 == 0 ) && -400 or 400 )
			end

		elseif cmd:KeyDown( IN_JUMP ) && DH.Menu['Misc']['Autostrafer'] then

			cmd:SetForwardMove( 10000 )

		end

	end


	--[[ [OLD] if me:IsOnGround() and cmd:KeyDown(IN_JUMP) then
		cmd:SetButtons(bit.bor(cmd:GetButtons(), IN_JUMP))
		if DH.Menu['Misc']['Autostrafer'] then
			cmd:SetForwardMove(10^4)
		end
	else
		if DH.Menu['Misc']['Autostrafer'] and cmd:KeyDown(IN_JUMP) then
			cmd:SetForwardMove(5850 / me:GetVelocity():Length2D())
			cmd:SetSideMove((cmd:CommandNumber() % 2 == 0) and 400 or -400)
		end
		cmd:RemoveKey(IN_JUMP)
	end--]]
end
--]==]

gameevent.Listen("player_hurt")
AddHek('player_hurt', function(data)
	local attacker = Player(data.attacker)
	local victim = Player(data.userid)
	
	if attacker != me or attacker == victim then return end
	
	victim.dz_hurts = (victim.dz_hurts or 0) + 1
	victim.dz_lastdmg = victim:Health() - data.health
end)

local hitgroup2str = {
	[HITGROUP_GENERIC]  = "Generic",
	[HITGROUP_HEAD]     = "Head",
	[HITGROUP_CHEST]    = "Chest",
	[HITGROUP_STOMACH]  = "Stomach",
	[HITGROUP_LEFTARM]  = "Left arm",
	[HITGROUP_RIGHTARM] = "Right arm",
	[HITGROUP_LEFTLEG]  = "Left leg",
	[HITGROUP_RIGHTLEG] = "Right leg",
	[HITGROUP_GEAR]     = "Gear"
}

AddHek('EntityFireBullets', function(ply, data)
	local spread = data.Spread * -1
	local wep = ply:GetActiveWeapon():GetClass()
	if spread != nulVec then
		spreadTables[wep] = spread
	end

	local oldfn = data.Callback
	data.Callback = function(att, tr, dmg)
		if !IsFirstTimePredicted() then return end
		
		local ent = tr.Entity
		if ent and IsValid(ent) and ent:IsPlayer() and aimenable then
			ent.dz_shots = (ent.dz_shots or 0) + 1
			
			local ismiss = ent.dz_shots > (ent.dz_hurts or 0)
			
			local log_white, log_red, log_green = Color(245, 245, 245), Color(245, 0, 0), Color(0, 245, 0)
			
			if ismiss then
				if DH.Menu['Misc']['Chat ShotLog'] then
					chat.AddText(log_white, ">> ", log_red, "MISSED > ", log_white, ent:Nick())
				end
				
				ent.dz_shots = 0
				ent.dz_hurts = 0
				ent.dz_bfaa_tick = (ent.dz_bfaa_tick or 0) + 1
			elseif DH.Menu['Misc']['Chat ShotLog'] then
				local type = "HIT"
				if ent.dz_lastdmg >= ent:Health() then
					type = "KILLED"
				end
				
				chat.AddText(log_white, ">> ", log_green, type, " > ", log_white, ent:Nick(), log_green, " > ", log_red, tostring(ent.dz_lastdmg), log_white, " (" .. hitgroup2str[tr.HitGroup] .. ")")
			end
		end
		
		if #tracers > DH.Vars['tracers max'] then
			if tracers[1][4] then
				tracers[1][4]:Remove()
			end

			table.remove(tracers, 1)
		end

		-- 1 life start, 2 start, 3 end, 4 player, 5 fake model, 6 cycle
		local data = {SysTime(), tr.StartPos, tr.HitPos}
		if DH.Menu['Visuals']['Fake model'] and (tr.Entity and IsValid(tr.Entity) and tr.Entity:IsPlayer()) then
			local e = tr.Entity
			local model = ClientsideModel(e:GetModel(), 1)
			local fixangle = e:EyeAngles()
			fixangle.p = 0

			model:SetPos(e:GetPos())
			model:SetAngles(fixangle)
			model:SetPoseParameter("aim_pitch", e:GetPoseParameter("aim_pitch"))
			model:SetPoseParameter("head_pitch", e:GetPoseParameter("head_pitch"))
			model:SetPoseParameter("body_yaw", e:GetPoseParameter("body_yaw"))
			model:SetPoseParameter("aim_yaw", e:GetPoseParameter("aim_yaw"))
			model:InvalidateBoneCache()
			model:SetRenderAngles(fixangle)
			model:SetSequence(e:GetSequence())
			model:SetCycle(e:GetCycle())
			model:SetMaterial("models/debug/debugwhite")

			data[4] = e
			data[5] = model
			data[6] = e:GetCycle()
		end

		tracers[#tracers + 1] = data

		if oldfn then
			oldfn(att, tr, dmg)
		end
	end

	return true
end)

local function removeSpread(cmd, ang)
	if !DH.Menu['Aimbot']['Spread'] then return ang end
	local wep = me:GetActiveWeapon()
	if !wep or !isValid(wep) then return ang end
	local class = wep:GetClass()

	local cang
	if !class:StartWith("cw_") then
		local spread
		if class:StartWith("tfa_") then
			local cone, recoil = wep:CalculateConeRecoil()
			spread = -Vector(cone, cone, 0)
		else
			spread = spreadTables[class] or wep.Cone
		end

		if !spread then return ang end

		cang = DH.Menu['HvH']['Spread Dickwrap'] and (dickwrap.Predict(cmd, ang:Forward(), spread)):Angle() or ang
	else
		local cone = wep.CurCone
		if !cone then return ang end

		if me:Crouching() then
			cone = cone * 0.85
		end

		gmath.randomseed(cmd:CommandNumber())
		cang = ang - Angle(math.Rand(-cone, cone), math.Rand(-cone, cone), 0) * 25
	end

	if class:StartWith("tfa_") or class:StartWith("cw_") then
		cang = cang - me:GetViewPunchAngles()
	elseif !class:StartWith("m9k_") then
		cang = cang + me:GetViewPunchAngles()
	end

	return cang
end

local function AngleVectors(ang)
	return ang:Forward(), ang:Right(), ang:Up()
end

local function fixMove(cmd, ang1)
	local vec = Vector(cmd:GetForwardMove(), cmd:GetSideMove(), 0)
	local vel = gmath.sqrt(vec.x * vec.x + vec.y * vec.y)
	local mang = vec:Angle()
	local yaw = cmd:GetViewAngles().y - ang1.y + mang.y

	if (((cmd:GetViewAngles().p + 90) % 360) > 180) then yaw = 180 - yaw end
	yaw = gmath.rad((yaw + 180) % 360 - 180)

	local newF = gmath.cos(yaw) * vel
	local newS = gmath.sin(yaw) * vel

	if cmd:GetViewAngles().r == 180 then newS = -newS end

	cmd:SetForwardMove(newF)
	cmd:SetSideMove(newS)

	/*local aim = cmd:GetViewAngles()

	local aimForward, aimRight, aimUp = AngleVectors(aim)
	local viewForward, viewRight, viewUp = AngleVectors(ang1)

	aimForward:Normalize()
	aimRight:Normalize()
	aimUp:Normalize()

	local fwd = cmd:GetForwardMove()
	local side = cmd:GetSideMove()
	local up = cmd:GetUpMove()

	cmd:SetForwardMove(aimForward:Dot(viewForward * fwd) + aimForward:Dot(viewRight * side) + aimForward:Dot(viewUp * up))
	cmd:SetSideMove(aimRight:Dot(viewForward * fwd) + aimRight:Dot(viewRight * side) + aimRight:Dot(viewUp * up))*/
end

local function cStrafe(cmd)
	if !DH.Menu['Misc']['CStrafe'] then return end
	//if isKeyDown(KEY_V) then
	//	enginepred.SetTickCount(cmd,math.huge)
	//end

	if isKeyDown(KEY_T) and !cStrafeToggle then
		cStrafeToggle = true
		local len = 4096
		for i = 1, 30 do
			local initpos = me:GetPos()+me:OBBCenter()
			local xpos = math.cos(math.rad(i*12))*4096
			local ypos = math.sin(math.rad(i*12))*4096
			local trace = util.TraceLine({start=initpos,endpos=initpos+Vector(xpos,ypos,0),filter=me,mask=MASK_PLAYERSOLID})
			len = math.min(len,(trace.HitPos-initpos):Length2D())
		end
		cStrafeRad = math.Clamp(len-46,0,512)
	end
	if isKeyDown(KEY_T) then
		cmd:SetForwardMove(4000) cmd:SetSideMove(0) fixMove(cmd,Angle(0,CurTime()*(512-cStrafeRad)%360,0))
	else
		cStrafeToggle = false
	end
end

local function getEnemypos()
	return (isValid(aaply) and (veloPredict(aaply:GetPos() or Vector(), aaply) - me:EyePos()):Angle()) or silentAngle
end

local AATick = 0
local oldYaw = 0
local oldedge = 0

--wtf dude are u retard??
local edge =
{
	p=
	{
		Vector(15,25,20),Vector(15,-25,20),Vector(-15,25,20),Vector(-15,-25,20),
		Vector(25,15,20),Vector(-25,15,20),Vector(25,-15,20),Vector(-25,-15,20),
	},
	ps=
	{
		Vector(15,-25,20),Vector(15,25,20),Vector(-15,-25,20),Vector(-15,25,20),
		Vector(-25,15,20),Vector(25,15,20),Vector(-25,-15,20),Vector(25,-15,20)
	},
	a={180,180,0,0,-90,-90,90,90}
}

local handblockangles = {
	["revolver"] = Angle(-25.936697, -177.352600, 0.000000),
	["smg"] = Angle(-58.050278, 161.561966, 0.000000),
	["rpg"] = Angle(-79.911888, 179.639832, 0.000000),
	["pistol"] = Angle(-85.895302, -136.086594, 0.000000),
	["shotgun"] = Angle(89.000000, -16.557995, 0.000000),
	["ar2"] = Angle(-33.471878, -174.345062, 0.000000),
	["melee"] = Angle(89.000000, -66.523354, 0.000000),
	["physgun"] = Angle(89.000000, 3.557386, 0.000000),
	["slam"] = Angle(89.000000, 0.000000, 0.000000),
	["crossbow"] = Angle(81.140701, -12.224648, 0.000000),
	["knife"] = Angle(89.000000, -10.477988, 0.000000)
}

local aamethods = {
	["Edge"] = function(cmd, oldaim, y, p)
		for i = 1, #edge.p do
			local start  = me:EyePos() - edge.p[i]
			local endpos = me:EyePos() - edge.ps[i]

			local tr = traceLine({
				start = start,
				endpos = endpos,
				filter = me,
				mask = MASK_SOLID
			})

			if tr.Fraction != 1 then
				y = edge.a[i]
				oldedge = y
				break
			end

			y = oldedge
		end

		p = -612 + mRand(0, 0.9)

		/*if bSendPacket then
			y = y+mrandom(1,13)
			p = -612.2+mRand(0.02,0.09)
		else
			y = y
			p = 90.1+mRand(-0.01,0.01)
		end*/

		/*AAchoke = !AAchoke
		for i=1,8 do
			local start = me:EyePos()-Vector(0,0,20)
			local endpos = start+(me:GetAngles()+Angle(0,i*45,0)):Forward()*45 and me:EyeAngles():Forward()*35

			local tr = traceLine({start=start,endpos=endpos,filter=me,mask=MASK_SOLID})

			if tr.Fraction != 1 then
				y = i*45
				oldedge = y
				break
			end
			y = oldedge
		end*/

		return p, y
	end,
	["Static"] = function(cmd, oldaim, y, p)
		p, y = -180.000005, 180
		return p, y
	end,
	["StaticJit"] = function(cmd, oldaim, y, p)
		y = mRand(-53, 105)
		p = 180.000008
		return p, y
	end,
	["HandBlock"] = function(cmd, oldaim, y, p)
		local weap = me:GetActiveWeapon()
		if !weap or !IsValid(weap) then return p, y end

		local angles = handblockangles[weap:GetHoldType()]
		if !angles then return p, y end

		y, p = getEnemypos().yaw - 180 - angles.y, angles.p

		return p, y
	end,
	["Invert"] = function(cmd, oldaim, y, p)
		local ey = getEnemypos().yaw
		local xd = oldYaw > ey-90

		if bSendPacket then
			y = ey-180
			p = 89
			p = 180.00000762939
			p = AAchoke and -612.3+mRand(0.02,0.09) or -612.2+mRand(0.02,0.09)
		else
			y = (ey-90 and ey+190 or ey-90)
			p = 89
			p = 180.00000762939
			p = AAchoke and -612.3+mRand(0.02,0.09) or -612.2+mRand(0.02,0.09)
		end

		oldYaw = ey - 90

		return p, y
	end,
	["RealDown"] = function(cmd, oldaim, y, p)
		p = AAchoke and 89 or 180.000008
		y = getEnemypos().y - (bSendPacket and 90 or 270)
		return p, y
	end,
	["Legit"] = function(cmd, oldaim, y, p)
		if bSendPacket then
			p = silentAngle.p

			local yaw = getEnemypos().y
			
			local diff = math.AngleDifference(silentAngle.y, yaw)
			if diff > 0 and diff < 45 then
				yaw = yaw - 90
			elseif diff < 0 and diff > -45 then
				yaw = yaw + 90
			end

			y = yaw
		else
			p, y = silentAngle.p, silentAngle.y
		end

		return p, y
	end,
	["FakeUP"] = function(cmd, oldaim, y, p)
		p = 180.000008
		return p, y
	end,
	["FakeFakeUP"] = function(cmd, oldaim, y, p)
		p = 180.00000762939
		return p, y
	end,
	["Sideways"] = function(cmd, oldaim, y, p)
		y, p = getEnemypos().yaw - 180, 90.1 + mRand(-0.01, 0.01)
		return p, y
	end,
	["RandomJit"] = function(cmd, oldaim, y, p)
		y = tRandom({262, -262, 181, -181, 541, -541})
		p = tRandom({-181, 541, 262})
		y, p = mRand(-179,179), mRand(-89,89)
		return p, y
	end,
	["Spinbot"] = function(cmd, oldaim, y, p)
		y, p = realTime() * 360 % 360, -612.087923
		return p, y
	end,
	["Spinbot 2x"] = function(cmd, oldaim, y, p)
		local change = realTime() * 1337 % 360
		if bSendPacket then
			y = realTime() * 1337 % 360
			p = 89
		else
			y = (change > 90 and change < 250) and 0 or 180
			p = 89
		end

		return p, y
	end,
	["Fake Angle"] = function(cmd, oldaim, y, p)
		y, p = bSendPacket and DH.Vars['RealYaw'] or DH.Vars['OwnFakeYaw'], bSendPacket and DH.Vars['RealPitch'] or DH.Vars['RealPitch']
		return p, y
	end,
	["FakeBW"] = function(cmd, oldaim, y, p)
		local ey = getEnemypos().yaw
		if bSendPacket then
			y = AAchoke and ey - 180 + mrandom(1, 13) + mRand(0.03, 0.08) or ey - 180 + mrandom(1, 13) + mRand(0.03, 0.08)
			p = 180.000008
		else
			y = AAchoke and ey - 125 + mrandom(1, 13) + mRand(0.03, 0.08) or ey - 125 + mrandom(1, 13) + mRand(0.03, 0.08)
			p = 180.000008
		end

		return p, y
	end,
	["FakeBW2"] = function(cmd, oldaim, y, p)
		local ey = getEnemypos().yaw
		y = ey - 180 + mrandom(1, 13) + mRand(0.03, 0.08)
		p = bSendPacket and -612.3 + mRand(0.02, 0.09) or -612.2 + mRand(0.02, 0.09)

		y = ey - 180 + gmath.cos(RealTime() * 10) * 40

		return p, y
	end
}

local mouse4pressed = false
local function aAimbot(cmd, oldaim)
	if DH.Modes['AA Method'].main == 'None' then return end
	if me:GetMoveType() == MOVETYPE_LADDER then return end

	local p, y = aamethods[DH.Modes['AA Method'].main](cmd, oldaim, y, p)
	local r = AAchoke and 0 or 180

	local curang = Angle(p, y, r)

	if cmd:KeyDown(IN_ATTACK) and canFire() then
		curang = removeSpread(cmd, DH.Menu['Aimbot']['Silent'] and silentAngle or cmd:GetViewAngles())
		curang = Angle(-curang.p - 180, curang.y + 180, r)
	end

	cmd:SetViewAngles(curang)

	AAchoke = !AAchoke
	-- p = ((mRound(p) == -612) and 89) or p

	if bSendPacket then
		fakeAngles = curang
	else
		realAngles = curang
	end
end

local function silent(cmd)
	if !DH.Menu['Aimbot']['Silent'] then return end
	silentAngle = silentAngle or cmd:GetViewAngles()
	silentAngle = silentAngle + Angle(cmd:GetMouseY() * .023, cmd:GetMouseX() * -.023, 0)
	silentAngle.p = mClamp(silentAngle.p, -89, 89)
	silentAngle.y = silentAngle.y % 360

	if cmd:CommandNumber() == 0 then return end
	cmd:SetViewAngles(silentAngle)
end

local function aimbot(cmd, tps)
	if DH.Menu['HvH']['Backtrack'] and ip and DH.Menu['HvH']['Engine Predict'] then
		ip = false
		--enginepred.SetInterpolation(ip)
	end

	aimenable = DH.Modes['Aimbot'].main == 'Auto'
	if DH.Menu['Aimbot']['Kill Once'] and preventKill then aimenable = false end
	if DH.Modes['Aimbot'].main == 'Key' then
		if isMouseDown(MOUSE_MIDDLE) then aimenable = true else preventKill = false  aimenable = false end
	end

	if aimenable and canFire() then
		if aimply and isValid(aimply) then
			if DH.Menu['HvH']['Fake Lag'] then
				bSendPacket = true
			end
			
			if DH.Menu['HvH']['Fake eblan'] then
				enginepred.SetOutSeq(enginepred.GetOutSeq())
			end

			aimply.aaaTick = aimply.aaaTick + 1

			local posAim = ((aimbotGetBone(aimply) or Vector()) - me:GetShootPos()):Angle()

			angs = removeSpread(cmd, posAim)

			-- FLIP / INVERT ANGLES ANGS
			local weap = me:GetActiveWeapon():GetClass()
			if !weap:StartWith("cw_") then
				-- angs = Angle(-angs.p - 180, angs.y + 180, 180)
			end

			if DH.Menu['Aimbot']['Autoshoot'] then
				cmd:SetButtons(bor(cmd:GetButtons(), IN_ATTACK))
			end

			if DH.Vars['Aim Smooth'] > 0 then angs = LerpAngle(1 - DH.Vars['Aim Smooth'] / 100, cmd:GetViewAngles(),angs) end

			cmd:SetViewAngles(angs)
		end
	end
end

--[[
old govno
local ftick = 0
local function fakeduck(cmd)
	if !DH.Menu['HvH']['FakeDuck'] then
		ftick=0
		return
	end

	RunConsoleCommand('cl_interp',0)
	RunConsoleCommand('cl_updaterate',100000)
	RunConsoleCommand('cl_interp_ratio',1)

	local lockon = DH.Vars['FakeDuck maxticks']
	if ftick<lockon then
		ftick = ftick + 1
		cmd:SetButtons(bit.bor(cmd:GetButtons(), IN_DUCK))
		bSendPacket = true
	elseif ftick==lockon then
		bSendPacket = false
		ftick = ftick - 1
	else
		ftick = ftick - 1
		cmd:SetButtons(bit.band(cmd:GetButtons(), bit.bnot(IN_DUCK)))
		bSendPacket = true
	end
end
-]]

local duckflip = true
local function fakeduck(cmd)
	if !DH.Menu['HvH']['Fake Lag'] then
		duckflip = !duckflip
		bSendPacket = duckflip
	end
	
	local invertSend = bSendPacket
	if DH.Menu['HvH']['Invert fakeduck'] then invertSend = !bSendPacket end

	if invertSend and !cmd:KeyDown(IN_JUMP) then
		cmd:SetButtons(gbit.bor(cmd:GetButtons(), IN_DUCK))
	else
		cmd:SetButtons(gbit.band(cmd:GetButtons(), gbit.bnot(IN_DUCK)))
	end
end

local function fakeEblan()
	if !isKeyDown(KEY_H) then return end
	if DH.Modes["FakeEblan Method"].Main == "Mega eblan" then
		enginepred.SetOutSeq(enginepred.GetOutSeq() + gmath.random(0, DH.Vars['FakeEblan power']))
	else
		enginepred.SetOutSeq(enginepred.GetOutSeq() + 3 * DH.Vars['FakeEblan power'])
	end
end

local fastwalk = true
local function fastWalk(cmd)
	if LocalPlayer():IsOnGround() && ( cmd:KeyDown(IN_FORWARD) || cmd:KeyDown(IN_BACK) ) then
		if fastwalk == false then
			cmd:SetSideMove(cmd:GetSideMove() - 5000)
		else
			cmd:SetSideMove(cmd:GetSideMove() + 5000)
		end
		
		fastwalk = !fastwalk
	end
end

AddHek('Think', function()
	allply = player.GetAll()

	for k,v in ipairs(allply) do
		v.aaaTick = v.aaaTick or 0
	end
	
	table.RemoveByValue(allply,me)
	
	aimply = getPlayer(DH.Modes['FindMethod'].main, true) --aimandshoot)

	if DH.Menu['Visuals']['Aim Dot'] then aimdot = getPlayer(DH.Modes['FindMethod'].main,true) end
	if DH.Modes['AA Method'].main != 'None' then aaply  = getPlayer(DH.Modes['FindMethod'].main, true, true) end
end)

local nextheal = -1
local chokedcommands = 0
AddHek('CreateMove',function(cmd)
	lMouse = WasMousePressed(MOUSE_LEFT)
	rMouse = WasMousePressed(MOUSE_RIGHT)
	wheelUp   = WasMousePressed(MOUSE_WHEEL_UP)
	wheelDown = WasMousePressed(MOUSE_WHEEL_DOWN)
	cm = cmd

	local cmdnum = cmd:CommandNumber()

	silent(cmd)
	if cmdnum == 0 then return end

	if DH.Menu['Misc']['Flashlight']   then cmd:SetImpulse(100) end
	if DH.Menu['HvH']['Fake eblan']    then fakeEblan() end
	if DH.Menu['Misc']['BunnyHop']     then bhop(cmd) end
	if DH.Menu['Misc']['Fastwalk']     then fastWalk(cmd) end
	if DH.Menu['Aimbot']['Rapid Fire'] then rapidfire(cmd) end
	if DH.Menu['HvH']['FakeDuck']      then fakeduck(cmd) end

	if DH.Menu['HvH']['Engine Predict']then
		enginepred.Predict(cmd)
	end

	if DH.Menu['Misc']['Edge Jump']    then EdgeJump(cmd) end

	if me:GetVelocity():Length2D() > 0 and DH.Menu['HvH']['Break lagcomp'] then
		breaklagcomp(cmd)
	elseif DH.Menu['HvH']['Fake Lag'] then
		fakelag(cmd)
	end
	
	if DH.Menu['HvH']['Fakelag on peek'] then
		fakelagonpeek(cmd)
	end
	
	if band(cmd:GetButtons(), IN_USE) == 0 then
		aAimbot(cmd, cmd:GetViewAngles())
	end
	
	aimbot(cmd)

	local x = cmd:GetViewAngles().x

	-- AUTOHEAL
	/*
	if (!aimenable or !canFire() or !aimply or !isValid(aimply)) and me:Alive() then
		if me:Health() <= 75 then
			if CurTime() > nextheal then
				cmd:SetViewAngles(Angle(89, 0, 0))
				me:ConCommand("gm_spawnsent item_healthkit")

				nextheal = CurTime() + 0.5
			end
		elseif me:Armor() < 100 and CurTime() > nextheal then
			cmd:SetViewAngles(Angle(89, 0, 0))
			me:ConCommand("gm_spawnsent item_battery")

			nextheal = CurTime() + 0.5
		end
	else
		nextheal = CurTime() + 0.5
	end
	*/

	fixMove(cmd, Either(DH.Menu['Aimbot']['Silent'], silentAngle, cmd:GetViewAngles()))
	cStrafe(cmd)

	if DH.Menu['HvH']['Backtrack'] then BacktrackRecord() end
	
	if !bSendPacket then
		chokedcommands = chokedcommands + 1
	end
	
	if chokedcommands >= 15 then
		bSendPacket = true
		chokedcommands = 0
	end
end)

AddHek('PreDrawOpaqueRenderables', function()
	aaa()
end)

local function SetupFakeModel(faply, angles)
	faply:SetNoDraw(true)
	faply:SetSequence(me:GetSequence())
	faply:SetCycle(me:GetCycle())

	local poz = me:GetPos()
	if me:Alive() then
		faply:SetModel(me:GetModel())
		faply:SetPos(me:GetPos())
		faply:SetAngles(Angle(0, angles.y, 0))
		faply:SetPoseParameter("aim_pitch", angles.p)
		faply:SetPoseParameter("move_x", me:GetPoseParameter("move_x"))
		faply:SetPoseParameter("move_y", me:GetPoseParameter("move_y"))
		faply:SetPoseParameter("head_pitch", angles.p)
		faply:SetPoseParameter("body_yaw", angles.y)
		faply:SetPoseParameter("aim_yaw", 0);
		faply:InvalidateBoneCache()
		faply:SetRenderAngles(Angle(0, angles.y, 0))
	end
end

AddHek('PreRender',function()
	grender.SetLightingMode(DH.Menu['Visuals']['Fullbright'] and 1 or 0)

	for k,v in pairs(game.GetWorld():GetMaterials()) do
		Material(v):SetFloat("$alpha",(DH.Menu['Visuals']['ASUS'] and DH.Vars['ASUS Alpha']/100) or 1)
	end

	--useless
	if DH.Menu['Aimbot']['Backtrack'] then
		for k, v in pairs(allply) do
			if !bttab[v] then continue end
			if !bvtab[v] then bvtab[v] = {} end

			for i, b in pairs(bttab[v]) do
				if !b or !b.angle then continue end
				local model
				if !bvtab[v][i] then
					model = ClientsideModel(v:GetModel(),1)
					bvtab[v][i] = model
				else
					model = bvtab[v][i]
				end

				local fixangle = b.angle
				fixangle.p = 0

				model:SetPos(b.pos)
				model:SetAngles(fixangle)
				model:SetPoseParameter("aim_pitch", b.poseparams["aim_pitch"])
				model:SetPoseParameter("head_pitch", b.poseparams["head_pitch"])
				model:SetPoseParameter("body_yaw", b.poseparams["body_yaw"])
				model:SetPoseParameter("aim_yaw", b.poseparams["aim_yaw"])
				model:InvalidateBoneCache()
				model:SetRenderAngles(fixangle)
				model:SetSequence(b.seq)
				model:SetCycle(b.cycle)
			end
		end
	end

	if DH.Menu['HvH']['Real Angles'] then
		if faply == NULL then faply = ClientsideModel(me:GetModel(), RENDERGROUP_OPAQUE) end
		if faply1 == NULL then faply1 = ClientsideModel(me:GetModel(), RENDERGROUP_OPAQUE) end
		SetupFakeModel(faply, fakeAngles)
		SetupFakeModel(faply1, realAngles)
	end
	
	if DH.Menu['Visuals']['Fakelag Chams'] then
		if fakelagchams == NULL then fakelagchams = ClientsideModel(me:GetModel(), RENDERGROUP_TRANSLUCENT) end
		
		if bSendPacket then
			local angs =  DH.Modes['AA Method'].main == 'None' and silentAngle or fakeAngles
			SetupFakeModel(fakelagchams, angs)
		end
	end
end)

AddHek('PostRender',function()
	grender.SetLightingMode(0)
end)

AddHek('PreDrawHUD',function()
	grender.SetLightingMode(0)
end)

AddHek('PrePlayerDraw',function(ply)
	return ply == LocalPlayer() and DH.Menu['HvH']['Real Angles']
end)

AddHek('CalcView',function(me, origin, angles)
	if GetViewEntity() ~= me then return end
	local view = {}
	globalOrig = origin
	view.drawviewer = DH.Menu['Misc']['Thirdperson']
	view.angles = Either(DH.Menu['Aimbot']['Silent'], silentAngle, angles)
	if DH.Menu['Misc']['Thirdperson'] then view.origin = origin-((DH.Menu['Aimbot']['Silent'] and silentAngle or angles):Forward()*DH.Vars['Thirdperson FoV']) end

	/*
	if DH.Menu['HvH']['FakeDuck'] then
		view.origin = origin
		view.origin.z = LocalPlayer():GetPos().z + 70.8857421875
	end
	*/

	view.fov = DH.Vars['FoV'] or 90
	return view
end)

AddHek('CalcViewModelView',function(wep,vm,oldPos,oldAng,pos,ang)
	return globalOrig,DH.Menu['Aimbot']['Silent'] and silentAngle or ang
end)

local function sDrawCircle( x, y, radius, seg )
	local cir = {}

	cir[#cir + 1] =  { x = x, y = y, u = 0.5, v = 0.5 }
	for i = 0, seg do
		local a = gmath.rad( ( i / seg ) * -360 )
		cir[#cir + 1] = { x = x + gmath.sin( a ) * radius, y = y + gmath.cos( a ) * radius, u = gmath.sin( a ) / 2 + 0.5, v = gmath.cos( a ) / 2 + 0.5 }
	end

	local a = gmath.rad( 0 ) -- This is needed for non absolute segment counts
	cir[#cir + 1] = { x = x + gmath.sin( a ) * radius, y = y + gmath.cos( a ) * radius, u = gmath.sin( a ) / 2 + 0.5, v = gmath.cos( a ) / 2 + 0.5 }

	surface.DrawPoly( ir)
end


local function drawESP(v)
	local mpos = v:GetPos()
	local pos = mpos:ToScreen()

	if DH.Vars['ESP Distance']<(mpos-me:GetPos()):Length2DSqr()/5000 then return end

	local espind = 0

	local color = teamGetColor(v:Team())
	local bpos, bcent = mpos,  v:OBBCenter()
	local bmin, bmax  = v:OBBMins(), v:OBBMaxs()
	local postab = {
		(bpos+Vector(bmin.x,bmin.y,bmax.z)):ToScreen(),
		(bpos+Vector(bmin.x,bmax.y,bmax.z)):ToScreen(),
		(bpos+Vector(bmax.x,bmax.y,bmax.z)):ToScreen(),
		(bpos+Vector(bmax.x,bmin.y,bmax.z)):ToScreen(),
		(bpos+Vector(bmin.x,bmin.y,bmin.z)):ToScreen(),
		(bpos+Vector(bmin.x,bmax.y,bmin.z)):ToScreen(),
		(bpos+Vector(bmax.x,bmax.y,bmin.z)):ToScreen(),
		(bpos+Vector(bmax.x,bmin.y,bmin.z)):ToScreen()
	}
	local x1, x2, y1, y2 = MSW, -1, MSH, -1
	local x1, x2, y1, y2 = mHuge,-mHuge,mHuge,-mHuge
	for k,v in gpairs(postab) do
		if v.x < x1 then x1 = v.x end
		if v.x > x2 then x2 = v.x end
		if v.y < y1 then y1 = v.y end
		if v.y > y2 then y2 = v.y end
	end

	local Right,Up = x2,y1

	if DH.Menu['Visuals']['Box'] then

		DrawOutlinedRect(color,x1,y1,x2-x1,y2-y1,1)
	end

	if DH.Menu['Visuals']['Spectators'] then
		if v:GetObserverMode() ~= OBS_MODE_NONE and v:GetObserverTarget() == me then
			spe = spe + 1
			DrawText(color_white,500,10+spe*30,name,dFont)
		end
	end

	if DH.Menu['Visuals']['Name'] then
		espind = espind + 1
		local name = v:Name()
		DrawText(color_white,Right+5,Up+10*espind,name,dFont)
	end

	if DH.Menu['Visuals']['Rank'] then
		espind = espind + 1
		local rank = v:GetUserGroup()
		DrawText(color_white,Right+5,Up+10*espind,rank,dFont)
	end

	if DH.Menu['Visuals']['Health'] then
		espind = espind + 1
		local ap = v:Armor()
		local hp = '['..v:Health()..'] '..(ap > 1 and '['..ap..']' or '')
		DrawText(color_white,Right+5,Up+10*espind,hp,dFont)
	end

	if DH.Menu['Visuals']['AA Mode'] then
		if v.AAESP then
			espind = espind + 1
			DrawText(color_white,Right+5,Up+10*espind,v.AAESP.mode or 'OFF',dFont)

			if v.AAESP.p then espind = espind + 1 DrawText(Color(255,255,0),Right+5,Up+10*espind,'RPitch: '..mRound(v.AAESP.p,4),dFont) end
			if v.AAESP.y then espind = espind + 1 DrawText(Color(255,255,0),Right+5,Up+10*espind,'RYaw: '..mRound(v.AAESP.y,4),dFont) end

			local mem = v:EyeAngles()
			espind = espind + 1
			DrawText(Color(0,255,0),Right+5,Up+10*espind, 'Pitch: '..mRound(mem.p,4),dFont)
			espind = espind + 1
			DrawText(Color(0,255,0),Right+5,Up+10*espind,'Yaw: '..mRound(mem.y,4),dFont)
		end
	end

	if DH.Menu['Visuals']['Aim Dot'] then
		if isValid(aimdot) then
			local gg = aimbotGetBone(aimdot)
			if gg then
				local kek = gg:ToScreen() --Predict for dot?
				sSetDrawColor(0,0,0,255)
				sDrawRect(kek.x-3,kek.y-3,6,6)
				sSetDrawColor(0,192,0)
				sDrawRect(kek.x-2,kek.y-2,4,4)
			end
		end
	end

	if DH.Menu['Visuals']['Skeletones'] then
		local pos = v:GetPos()
		for i = 0, v:GetBoneCount()-1 do
			local parent = v:GetBoneParent(i)
			if(!parent) then continue end
			local bonepos = v:GetBonePosition(i)
			if(bonepos == pos) then continue end
			local parentpos = v:GetBonePosition(parent)
			if(!bonepos or !parentpos) then continue end
			local screen1, screen2 = bonepos:ToScreen(),parentpos:ToScreen()
			sSetDrawColor(255,255,255)
			sDrawLine(screen1.x,screen1.y,screen2.x,screen2.y)
		end
	end

	if DH.Menu['Visuals']['Hit Boxes'] then
		for group = 0,v:GetHitBoxGroupCount()-1 do
			local count = v:GetHitBoxCount(group) - 1
			for hitbox = 0,count do
				local bone = v:GetHitBoxBone(hitbox,group)
				if(!bone) then continue end
				local min,max = v:GetHitBoxBounds(hitbox,group)
				local bonepos,boneang = v:GetBonePosition(bone)
				cam.Start3D() grender.DrawWireframeBox(bonepos,boneang,min,max,color_red,true) cam.End3D()
			end
		end
	end

	if DH.Menu['Visuals']['Tracers'] then
		local col = teamGetColor(v:Team())
		if v:GetEyeTrace().Entity == me then col = color_red end
		local b = v:LookupBone("ValveBiped.Bip01_R_Hand")

		if b then
			local ShootBone = v:GetBonePosition(b)

			cam.Start3D()
			grender.DrawLine(ShootBone,v:GetEyeTrace().HitPos,col,false)
			cam.End3D()
		end
	end

	if DH.Menu['Visuals']['Halo'] then
		local color = teamGetColor(v:Team())
		halo.Add({v},color,1,1,5,true,true)
		if isValid(v:GetActiveWeapon()) then
			halo.Add({v:GetActiveWeapon()},color,1,1,5,true,true)
		end
	end
end

local function drawEntity(str)
	for k,v in gpairs(ents.FindByClass(str)) do
		if (isValid(v) and not v:IsDormant()) then
			local mpos = v:GetPos()
			local pos  = mpos:ToScreen()
			local str = sExplode('/',v:GetModel())
			local nn = str[#str]

			if DH.Vars['EESP Distance'] < (mpos-me:GetPos()):Length2DSqr() / 5000 then return end

			local w,h = GetTextSize(dFont,nn)
			DrawText(color_white,pos.x-w/2,pos.y-h/2+5,nn,dFont)
		end
	end
end

local function drawEESP()
	if DH.Menu['EVisuals']['Money'] then drawEntity'exp_book*' end
	if DH.Menu['EVisuals']['Props'] then drawEntity'prop_*' end
	if DH.Menu['EVisuals']['Weapons'] then drawEntity'weapon*' end
end

local function MiscVisuals()
	if DH.Menu['Visuals']['Crosshair 2D'] then
		local color = teamGetColor(me:Team())
		DrawRect(color,ScW/2-8,ScH/2-1,16,2)
		DrawRect(color,ScW/2-1,ScH/2-8,2,16)
	end
end


local edge =
{
	p=
	{
		Vector(15,25,20),
		Vector(15,-25,20),

		Vector(-15,25,20),
		Vector(-15,-25,20),

		Vector(25,15,20),
		Vector(-25,15,20),

		Vector(25,-15,20),
		Vector(-25,-15,20),
	},

	ps=
	{
		Vector(15,-25,20),
		Vector(15,25,20),

		Vector(-15,-25,20),
		Vector(-15,25,20),

		Vector(-25,15,20),
		Vector(25,15,20),

		Vector(-25,-15,20),
		Vector(25,-15,20),
	}
}

AddHek('PostDrawTranslucentRenderables',function(bDepth, bSkybox)
	if bSkybox then return end

	if DH.Menu['Visuals']['Crosshair 3D'] then
		local tr = traceLine({start=me:EyePos(),endpos=me:EyePos()+(DH.Menu['Aimbot']['Silent'] and silentAngle or me:EyeAngles()):Forward()*1000,filter=me,mask=MASK_SOLID})
		local dis = mClamp(((tr.HitPos-me:EyePos()):Length())/500,0,1.95)
		local ang = tr.HitNormal:Angle()
		local pos = tr.HitPos+tr.HitNormal*dis*6
		local color = teamGetColor(me:Team())

		cStart3D2D(pos,ang+Angle(90,0,0),dis)
			DrawRect(color,-8,-1,4,2)
			DrawRect(color,4,-1,4,2)
			DrawRect(color,-1,-8,2,4)
			DrawRect(color,-1,4,2,4)
		cEnd3D2D()
	end

	if DH.Menu['Visuals']['Angles'] then
		local pos = me:GetPos()

		cStart3D2D(pos,Angle(0,45+me:GetRenderAngles().y,0),1)
			DrawLine(Color(0,125,0),0,0,25,25)
		cEnd3D2D()

		cStart3D2D(pos,Angle(0,45+fakeAngles.y,0),1)
			DrawLine(color_red,0,0,25,25)
		cEnd3D2D()

		cStart3D2D(pos,Angle(0,45+realAngles.y,0),1)
			DrawLine(color_white,0,0,25,25)
		cEnd3D2D()
	end

	if DH.Menu['Visuals']['Bullet tracers'] then
		local dietime = DH.Vars['tracers dietime']
		local fakemodel = DH.Menu['Visuals']['Fake model']

		if fakemodel then
			grender.SetStencilWriteMask(0xFF)
			grender.SetStencilTestMask(0xFF)
			grender.SetStencilReferenceValue(1)
		end

		for i=1, #tracers do
			local tr = tracers[i]
			if SysTime() >= (tr[1]+DH.Vars['tracers dietime']) then continue end

			if fakemodel and tr[5] then
				tr[5]:SetCycle(tr[6])
				grender.SetStencilPassOperation(STENCIL_KEEP)
				grender.SetStencilZFailOperation(STENCIL_KEEP)
				grender.ClearStencil()

				grender.SetStencilEnable(true)

				grender.SetStencilCompareFunction(STENCIL_NEVER)
				grender.SetStencilFailOperation(STENCIL_REPLACE)

				tr[5]:DrawModel()

				grender.SetStencilCompareFunction(STENCIL_EQUAL)
				grender.SetStencilPassOperation(STENCIL_KEEP)


				grender.SetColorMaterial()
				grender.DrawSphere(tr[3], 4, 16, 16, Color(255, 0, 0))

				grender.SetStencilEnable(false)
			else
				grender.SetColorMaterial()
				grender.DrawSphere(tr[3], 4, 16, 16, Color(255, 0, 0))
			end

			grender.DrawLine(tr[2], tr[3], Color(255, 0, 0, (tr[1]-SysTime())/dietime*255))
		end
	end
end)

timer.Create("gctracers", 1, 0, function()
	if !DH then
		for k,v in ipairs(tracers) do
			if !v[5] then continue end
			v[5]:Remove()
		end

		tracers = {}
		timer.Remove("gctracers")
	end

	for k,v in ipairs(tracers) do
		if SysTime() >= (v[1]+DH.Vars['tracers dietime']) or (v[5] and (!v[4] or !IsValid(v[4]) or !v[4]:IsPlayer())) then
			if v[5] then
				v[5]:Remove()
			end

			table.remove(tracers, k)
		end
	end
end)

AddHek('HUDPaint',function()
	if DH.Menu['Visuals']['Enabled'] then
		for k,v in next,allply do
			if (isValid(v) and v ~= me and v:Alive() and not v:IsDormant()) and not (DH.Menu['Visuals']['Whitelist'] and DH.Menu.WhiteList[v:Name()]) then
				drawESP(v)
			end
		end

		--na kovo aim
		local b = aimbotGetBone(aimply)
		if b then
			local scr = b:ToScreen()

			sSetDrawColor(255,0,0,255)
			--sDrawCircle(scr.x, scr.y, 15, 16)
			sDrawLine(ScW*0.5, ScH*0.5, scr.x, scr.y)
		end

		local target
		if aimply then
			target = aimply:Nick()
		else
			target = "None"
		end

		local text = "Target: "..target
		DrawText(color_white, ScW*0.5 - sGetTextSize(text)*0.5, ScH*0.75, text, "DermaLarge")
	end

	if DH.Menu['EVisuals']['Enabled'] then drawEESP() end
	MiscVisuals()
end)

AddHek('RenderScreenspaceEffects',function()
	if DH.Menu['HvH']['Real Angles'] then
		cStart3D()
			if faply:IsValid() then
				rMaterialOverride(chamsmat_2)
				rSetColorModulation(.95,.61,.07)
				faply:DrawModel()
			end

			if faply1:IsValid() then
				rMaterialOverride(chamsmat_2)
				rSetColorModulation(.15,.61,.57)
				faply1:DrawModel()
			end

			/*
			rMaterialOverride(chamsmat_2)
			rSetColorModulation(.95,.01,.77)
			me:DrawModel()
			*/
		cEnd3D()
	end
	
	if DH.Menu['Visuals']['Fakelag Chams'] then
		cStart3D()
			if fakelagchams:IsValid() then
				rMaterialOverride(chamsmat_3)
				rSetColorModulation(.25, .25, .8)
				fakelagchams:DrawModel()
			end
		cEnd3D()
	end

	if DH.Menu['Visuals']['Chams'] and DH.Menu['Visuals']['Enabled'] then
		for k, v in ipairs(allply) do
			if !isValid(v) then continue end
			if !v:Alive() or v == me then continue end

			cStart3D()
				rSuppressEngineLighting(true)
				rMaterialOverride(chamsmat_1)
				rSetColorModulation(.63, .094, .082)
				-- rSetBlend(1)
				v:DrawModel()

				if isValid(v:GetActiveWeapon()) then
					rSetColorModulation(1, .078, 0.57)
					v:GetActiveWeapon():DrawModel()
				end

				rSuppressEngineLighting(true)
				rSetColorModulation(.95, .61, .07)
				rMaterialOverride(chamsmat_2)
				-- rSetBlend(1)
				v:DrawModel()

				if isValid(v:GetActiveWeapon()) then
					rSetColorModulation(1, 0.95, 0.57)
					v:GetActiveWeapon():DrawModel()
				end

				rSetColorModulation(1,1,1)
				rSuppressEngineLighting(false)
			cEnd3D()
		end
	end
end)

/*
-- paste comming
function pitchAAA(data)
	local ent = data:GetEntity()
	if ent.AAMethod == 'rok' then
		local pitch = data:GetFloat()
		rang[ent] = rang[ent] or Angle()
		rang[ent].p = pitch
		if pitch > 89.95 and 91 > pitch then
			pitch = pitch - 90
		elseif pitch >= 89 and 180.087936 >= pitch then
			pitch = 89
		elseif pitch > 180.087936 and 271 > pitch then
			pitch = 271
		end

		data:SetFloat(pitch)
	end
end

function yawAAA(data)
	local ent = data:GetEntity()
	if ent.AAMethod == 'rok' then
		local yaw = data:GetFloat()
		rang[ent] = rang[ent] or Angle()
		rang[ent].y = yaw
		yaw = math.NormalizeAngle(yaw)
		data:SetFloat(yaw)
	end
end
*/

/*
enginepred.HookProp("DT_GMOD_Player", "m_angEyeAngles[0]", pitchAAA)
enginepred.HookProp("DT_GMOD_Player", "m_angEyeAngles[1]", yawAAA)
*/

AddHek('GetMotionBlurValues',function() rSetLightingMode(0) end)

/*

/*
local me,wep,prim,valid=LocalPlayer(),0,0,IsValid
_G.cam.ApplyShake=function() end
_G.util.ScreenShake=function() end

GAMEMODE.Think=function()
    wep=me:GetActiveWeapon()
    if !valid(wep) then return end
    if !me:Alive() then return end
    if wep.autist then return end
    wep.Recoil=0
    wep.Cone=0
    wep.Spread=0
    if valid(wep.Primary) then
        wep.Primary.Recoil=0
        wep.Primary.KickUp=0
        wep.Primary.KickDown=0
        wep.Primary.KickHorizontal=0
        wep.Primary.IronAccuracy =0
        wep.Primary.Cone=0
    end
    wep.CreateMove=function() end
    print(wep)
    wep.autist=true
end*/

timer.Simple(0, function()
	RunConsoleCommand("menuhook_file_hide_1337")
end)
end) -- end timer
