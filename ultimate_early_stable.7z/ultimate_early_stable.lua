
require("zxcmodule")

local Bit   = bit 
local Band  = Bit.band 
local Bnot  = Bit.bnot 
local Bor   = Bit.bor 

local Cam           = cam 
local CamEnd2D      = gCam.End2D
local CamEnd3D      = gCam.End3D
local CamEnd3D2D    = gCam.End3D2D
local CamStart2D    = gCam.Start2D
local CamStart3D    = gCam.Start3D
local CamStart3D2D  = gCam.Start3D2D
local CamIgnoreZ    = gCam.IgnoreZ

local Engine            = engine 
local EngineTickCount   = gEngine.TickCount

local Ents          = ents 
local EntsGetAll    = gEnts.GetAll

local Util      = util
local UtilTraceLine = Util.TraceLine
local UtilTraceHull = Util.TraceHull

local Hook         = hook  
local HookAdd      = Hook.Add
local HookRemove   = Hook.Remove

local Input                = input
local InputIsKeyDown       = Input.IsKeyDown
local InputIsMouseDown     = Input.IsMouseDown
local InputWasKeyPressed   = Input.WasKeyPressed
local InputWasMousePressed = Input.WasMousePressed

local engine_ActiveGamemode = Engine.ActiveGamemode()
local engine_TickInterval   = Engine.TickInterval()
local entLocalPlayer        = LocalPlayer()
local entWorldSpawn         = Entity( 0 )

local TableEnts     = {}
local TablePlys     = {}
local TableHooks    = {}
local TraceStruct   = {}
local TraceResult   = {}

local function QuickBand( Bits, Mask ) 
    return Band( Bits, Mask ) == Mask  
end

local function TimeToTicks( time )
	return math_Floor( 0.5 + time / engine_TickInterval )
end

local function TicksToTime( ticks )
    return engine_TickInterval * ticks
end

local function RoundToTick( time )
    return TicksToTime( TimeToTicks( time ) )
end

local function AddHook( event, func )
    local UniqueIdentificator = Util.Base64Encode( event ) .. CurTime()

    TableHooks[ #TableHooks + 1 ] = { event, UniqueIdentificator }

    HookAdd( event, UniqueIdentificator, func )
end












/*
    Util library 
*/







/*
    Hook library 
*/





/*
    Input library
*/





/*
    Math library 
*/

local gMath     = math 

local PI    = 3.1415926535898
local RAD   = 57.295779513082
local INF   = math.huge()

local math_AngleDifference  = math.AngleDifference
local math_NormalizeAngle   = math.NormalizeAngle

local math_Approach = math.Approach

local math_Cos  = math.cos 
local math_Acos = math.acos 

local math_Sin  = math.sin
local math_Asin = math.asin

local math_Tan  = math.tan 
local math_Atan = math.atan

local math_Round = math.Round 
local math_Abs = math.abs 
local math_Ceil = math.ceil 
local math_Floor = math.floor


local gGui      = gui 

 

local gNet      = net 
local gPlayer   = player 
local gRender   = render 
local gString   = string 
local gSurface  = surface 
local gTable    = table 
local gTeam     = team 

/*
    Misc
*/

local gui_EnableScreenClicker   = gGui.EnableScreenClicker

local ultimate                  = {}

ultimate.cfg                    = {}
ultimate.cfg.vars               = {}
ultimate.cfg.binds              = {}
ultimate.cfg.colors             = {}


ultimate.cfg.vars.SortingMethod         = 1
ultimate.cfg.vars.MaxTargets            = 0

ultimate.cfg.vars.WallScan              = false

ultimate.cfg.vars.HitScan               = false
ultimate.cfg.vars.TargetHitbox          = 1
ultimate.cfg.vars.HitboxSorting         = 1

ultimate.cfg.vars.ScanHead              = false 
ultimate.cfg.vars.ScanChest             = false 
ultimate.cfg.vars.ScanStomach           = false 
ultimate.cfg.vars.ScanLegs              = false 
ultimate.cfg.vars.ScanArms              = false 

ultimate.cfg.vars.MultiPoint            = true
ultimate.cfg.vars.MultiPointScale       = 0.8

ultimate.cfg.vars.HeadshotOnly          = false

ultimate.cfg.vars.SilentAim             = true  

ultimate.cfg.vars.RapidFire             = true  

ultimate.cfg.vars.FastStop              = false
ultimate.cfg.vars.WaterWalk             = false

ultimate.cfg.vars.BunnyHop              = true
ultimate.cfg.vars.MaxHops               = 0

ultimate.cfg.vars.AutoStrafe            = true
ultimate.cfg.vars.GroundStrafe          = false
ultimate.cfg.vars.AutoStrafeMode        = 3

ultimate.cfg.vars.SlowWalk              = false 
ultimate.cfg.vars.SlowWalkSpeed         = 2 

ultimate.cfg.vars.SlowMotion            = true 
ultimate.cfg.vars.SlowMoTime            = 0.5

ultimate.cfg.vars.AutoClimbSwep         = true 

ultimate.cfg.vars.EdgeJump              = false

ultimate.cfg.vars.HandJob               = true
ultimate.cfg.vars.HandJobMode           = 1

ultimate.cfg.vars.FlashlightSpam        = false
ultimate.cfg.vars.UseSpam               = false
ultimate.cfg.vars.TauntSpam             = true
ultimate.cfg.vars.CameraSpam            = true
ultimate.cfg.vars.Taunt                 = 1
ultimate.cfg.vars.TauntTime             = 0

ultimate.cfg.vars.Thirdperson           = true 
ultimate.cfg.vars.ThirdpersonCollision  = false
ultimate.cfg.vars.ThirdpersonDistance   = 120 
ultimate.cfg.vars.ThirdpersonSmoothing  = 2

ultimate.cfg.vars.Freecamera            = false 
ultimate.cfg.vars.FreecameraGhetto      = false 
ultimate.cfg.vars.FreecameraSpeed       = 10 

ultimate.cfg.vars.FovChanger            = false
ultimate.cfg.vars.ViewmodelFov          = 95
ultimate.cfg.vars.CustomViewFov         = 100

ultimate.cfg.binds[ 1 ]         = { state = true, key = -1, mode = 1 } // Third person
ultimate.cfg.binds[ 2 ]         = { state = false, key = -1, mode = 1 } // Free camera
ultimate.cfg.binds[ 3 ]         = { state = false, key = -1, mode = 1 } // Flashlight spam
ultimate.cfg.binds[ 4 ]         = { state = false, key = -1, mode = 1 } // Edge jump
ultimate.cfg.binds[ 5 ]         = { state = false, key = -1, mode = 1 } // Slow walk
ultimate.cfg.binds[ 6 ]         = { state = false, key = 30, mode = 1 } // Slow motion
                                
ultimate.Entities               = {}
ultimate.Players                = {}
ultimate.LocalPlayer            = LocalPlayer()
ultimate.WorldSpawn             = gEnt( 0 )

ultimate.mInput                 = {}
ultimate.mInput.KeysPressed     = {}
ultimate.mInput.KeysDown        = {}

ultimate.mView                  = {}
ultimate.mView.traceHull        = {}
ultimate.mView.traceResult      = {}
ultimate.mView.FreeCamActive    = false
ultimate.mView.Origin           = gVec()
ultimate.mView.FakeOrigin       = gVec()
ultimate.mView.Angles           = gAng()
ultimate.mView.FakeAng          = ultimate.LocalPlayer:EyeAngles()
ultimate.mView.PreFreeCamAngs   = gAng()
ultimate.mView.traceHull.start  = gVec()
ultimate.mView.traceHull.endpos = gVec()
ultimate.mView.traceHull.mins   = gVec( -3, -3, -3 )
ultimate.mView.traceHull.maxs   = gVec( 3, 3, 3 )
ultimate.mView.traceHull.masc   = MASK_BLOCKLOS
ultimate.mView.traceHull.filter = ultimate.LocalPlayer
ultimate.mView.traceDistance    = 0
ultimate.mView.Fov              = 0
ultimate.mView.ZNear            = 0
ultimate.mView.ZFar             = 0

ultimate.FreecamDirs            = {}
ultimate.FreecamDirs[1]         = { key = KEY_W, fnc = function( ang ) return   ang:Forward()   end }
ultimate.FreecamDirs[2]         = { key = KEY_S, fnc = function( ang ) return   -ang:Forward()  end }
ultimate.FreecamDirs[3]         = { key = KEY_A, fnc = function( ang ) return   -ang:Right()    end }
ultimate.FreecamDirs[4]         = { key = KEY_D, fnc = function( ang ) return   ang:Right()     end }

ultimate.cVars                  = {}
ultimate.cVars.m_yaw            = gGetConVar("m_yaw"):GetFloat()
ultimate.cVars.m_pitch          = gGetConVar("m_pitch"):GetFloat()
ultimate.cVars.forwardspeed     = gGetConVar("cl_forwardspeed"):GetInt()
ultimate.cVars.sidespeed        = gGetConVar("cl_sidespeed"):GetInt()
ultimate.cVars.sv_airaccelerate = gGetConVar("sv_airaccelerate"):GetInt()
ultimate.cVars.sv_maxvelocity   = gGetConVar("sv_maxvelocity"):GetInt()
ultimate.cVars.maxjumps         = gGetConVar("climbswep2_maxjumps") and gGetConVar("climbswep2_maxjumps"):GetInt()

ultimate.CurTime                = 0
ultimate.TickInterval           = engine.TickInterval()
ultimate.CurrentGamemode        = engine.ActiveGamemode()
ultimate.TickRate               = math_Floor( 1 / ultimate.TickInterval )

ultimate.mCmd                   = {}
ultimate.mCmd.Object            = false
ultimate.mCmd.SideMove          = 0
ultimate.mCmd.ForwardMove       = 0
ultimate.mCmd.UpMove            = 0
ultimate.mCmd.Buttons           = 0
ultimate.mCmd.Impulse           = 0
ultimate.mCmd.MouseWheel        = 0
ultimate.mCmd.MouseX            = 0
ultimate.mCmd.MouseY            = 0
ultimate.mCmd.CommandNumber     = 0
ultimate.mCmd.TickCount         = 0
ultimate.mCmd.ViewAngles        = ultimate.LocalPlayer:EyeAngles()
ultimate.mCmd.WishYaw           = 0
ultimate.mCmd.InMove            = false
ultimate.mCmd.InBadMove         = false
ultimate.mCmd.OnGround          = false
ultimate.mCmd.OnGroundTicks     = 0
ultimate.mCmd.SendPacket        = true 
ultimate.mCmd.ChokedPackets     = 0
ultimate.mCmd.NumHops           = 0
ultimate.mCmd.Swap              = false

ultimate.MoveKeys               = { IN_BACK, IN_FORWARD, IN_JUMP, IN_MOVELEFT, IN_MOVERIGHT }
ultimate.BadMovetypes           = { MOVETYPE_NOCLIP, MOVETYPE_LADDER, MOVETYPE_OBSERVER }

ultimate.Taunts                 = { "robot", "muscle", "laugh", "bow", "cheer", "wave", "becon", "agree", "disagree", "forward", "group", "half", "zombie", "dance", "pers", "halt", "salute" }
ultimate.DarkRpTaunts           = { [4] = ACT_GMOD_GESTURE_BOW, [2] = ACT_GMOD_TAUNT_MUSCLE, [7] = ACT_GMOD_GESTURE_BECON, [3] = ACT_GMOD_TAUNT_LAUGH, [15] = ACT_GMOD_TAUNT_PERSISTENCE, [9] = ACT_GMOD_GESTURE_DISAGREE, [8] = ACT_GMOD_GESTURE_AGREE, [6] = ACT_GMOD_GESTURE_WAVE, [14] = ACT_GMOD_TAUNT_DANCE }

ultimate.MovementType           = 0
ultimate.LocalVelocity          = 0 
ultimate.OldStrafeYaw           = 0
ultimate.Radian                 = 57.295779513082
ultimate.ModifySequence         = 0
ultimate.LastTauntTime          = 0
ultimate.SlowmoTicks            = 0



function ultimate.UpdatePlayerData( ent )
    ultimate.Players[ #ultimate.Players + 1 ] = {}

    ultimate.Players[ #ultimate.Players ] = { 
        Ent         = ent,
        Alive       = ent:Alive(),
        Index       = ent:EntIndex(),
        Dormant     = ent:IsDormant(),

        Health      = ent:Health(),
        Armor       = ent:Armor(),
        MaxHealth   = ent:GetMaxHealth(),
        MaxArmor    = ent:GetMaxArmor(),

        SteamID     = ent:SteamID(),
        Team        = ent:Team(),
        Bot         = ent:IsBot(),

        FriendStatus = ent:GetFriendStatus(),
        Model       = ent:GetModel(),

        Flags       = ent:GetFlags(),
        EFlags      = ent:GetEFlags(),
        Effects     = ent:GetEffects(),

        UserGroup   = ent:GetNWString( "UserGroup", "user" ),

        Position    = ent:GetPos(),
        NetOrigin   = ent:GetNetworkOrigin(),

        Angles      = ent:GetAngles(),
        EyeAngs     = ent:EyeAngles(),
        NetAngs     = ent:GetNetworkAngles(),

        SimulationTime = ded.GetSimulationTime( ent:EntIndex() ),
        PacketReceived = false,
        BreakingLagComp = false,
    }

    ent.prevSimTime = ent.prevSimTime or 0 
    ent.prevOrigin = ent.prevOrigin or ultimate.Players[ #ultimate.Players ].NetOrigin

    if ent.prevSimTime != ultimate.Players[ #ultimate.Players ].SimulationTime then
        ent.prevSimTime = ultimate.Players[ #ultimate.Players ].SimulationTime

        ultimate.Players[ #ultimate.Players ].PacketReceived = true 
    end

    if ent.prevOrigin != ultimate.Players[ #ultimate.Players ].NetOrigin then
        ent.prevOrigin = ultimate.Players[ #ultimate.Players ].NetOrigin
        ultimate.Players[ #ultimate.Players ].BreakingLagComp = ent.prevOrigin:DistToSqr( ultimate.Players[ #ultimate.Players ].NetOrigin ) > 4096
    end

    local w = ent:GetActiveWeapon()

    ultimate.Players[ #ultimate.Players ].Weapon = IsValid( w ) and w or false 
    ultimate.Players[ #ultimate.Players ].WeaponClass = ultimate.Players[ #ultimate.Players ].Weapon and w:GetClass() or "Unarmed"
end



function ultimate.hook_CalcView( ply, origin, angles, fov, znear, zfar )
    local view = {}

    view.angles     = angles
    view.origin     = origin
    view.fov        = ultimate.cfg.vars.FovChanger and ultimate.cfg.vars.CustomViewFov  or fov

    ultimate.mView.Origin   = origin
    ultimate.mView.Angles   = angles
    ultimate.mView.Fov      = fov
    ultimate.mView.ZNear    = znear
    ultimate.mView.ZFar     = zfar

    if ultimate.cfg.vars.SilentAim then
        view.angles = ultimate.mView.FakeAng
    end

    local thirdPersonActive = ultimate.cfg.vars.Thirdperson and ultimate.cfg.binds[ 1 ].state
    ultimate.mView.FreeCamActive = ultimate.cfg.vars.Freecamera and ultimate.cfg.binds[ 2 ].state

    local thirdPersonDistance = thirdPersonActive and ultimate.cfg.vars.ThirdpersonDistance or 0

    if ultimate.cfg.vars.ThirdpersonSmoothing > 0 then
        ultimate.mView.traceDistance = math_Approach( ultimate.mView.traceDistance, thirdPersonDistance, ultimate.cfg.vars.ThirdpersonSmoothing )
    else
        ultimate.mView.traceDistance = thirdPersonDistance
    end

    if ultimate.mView.FreeCamActive then
        view.drawviewer = not ultimate.cfg.vars.FreecameraGhetto

        for i = 1, 4 do
            if not ultimate.input_IsKeyDown( ultimate.FreecamDirs[ i ].key ) then continue end 
            ultimate.mView.FakeOrigin = ultimate.mView.FakeOrigin + ultimate.FreecamDirs[ i ].fnc( ultimate.mView.FakeAng ) * ultimate.cfg.vars.FreecameraSpeed 
        end

        view.origin = ultimate.mView.FakeOrigin
    elseif math_Round( ultimate.mView.traceDistance ) > 10 then
        view.drawviewer = true

        if ultimate.cfg.vars.ThirdpersonCollision then
            ultimate.mView.traceHull.start  = origin
            ultimate.mView.traceHull.endpos = origin - view.angles:Forward() * ultimate.mView.traceDistance

            ultimate.mView.traceResult = util_TraceHull( ultimate.mView.traceHull )

            view.origin = ultimate.mView.traceResult.HitPos
        else
            view.origin = origin - view.angles:Forward() * ultimate.mView.traceDistance
        end
    end

    if not ultimate.mView.FreeCamActive then
        ultimate.mView.FakeOrigin = ultimate.mView.Origin
    end 

    return view
end

function ultimate.CollectCommandData( cmd )
    ultimate.mCmd.Object        = cmd 

    ultimate.mCmd.SendPacket    = true 

    ultimate.mCmd.SideMove      = cmd:GetSideMove()
    ultimate.mCmd.ForwardMove   = cmd:GetForwardMove()
    ultimate.mCmd.UpMove        = cmd:GetUpMove()
    
    ultimate.mCmd.Buttons       = cmd:GetButtons()
    ultimate.mCmd.Impulse       = cmd:GetImpulse()
    
    ultimate.mCmd.MouseWheel    = cmd:GetMouseWheel()
    ultimate.mCmd.MouseX        = cmd:GetMouseX()
    ultimate.mCmd.MouseY        = cmd:GetMouseY()
    
    ultimate.mCmd.CommandNumber = cmd:CommandNumber()
    ultimate.mCmd.TickCount     = cmd:TickCount()
    
    ultimate.mCmd.ViewAngles    = cmd:GetViewAngles()
end

function ultimate.ComputeAngleData( cmd )
    if not ultimate.Players[1] then return end 
    local w = ultimate.Players[1].Weapon

    if w then 
        if w.FreezeMovement and w:FreezeMovement() then return end
        if ultimate.Players[1].WeaponClass == "weapon_physgun" and IsValid( w:GetInternalVariable("m_hGrabbedEntity") ) and band( ultimate.mCmd.Buttons, IN_USE ) == IN_USE then return end
    end 
    
    ultimate.mView.FakeAng = ultimate.mView.FakeAng and ultimate.mView.FakeAng or cmd:GetViewAngles() 
    ultimate.mView.FakeAng = ultimate.mView.FakeAng + gAng( ultimate.mCmd.MouseY * ultimate.cVars.m_yaw, ultimate.mCmd.MouseX * -ultimate.cVars.m_yaw, 0 )
    ultimate.mView.FakeAng.x = math_Clamp( ultimate.mView.FakeAng.x, -89, 89 )

    ultimate.mView.FakeAng:Normalize()
end

function ultimate.FixMovement( cmd, wishYaw )
	local pitch = math_NormalizeAngle( ultimate.mCmd.ViewAngles.x )
	local inverted = ( pitch > 89 || pitch < -89 ) and 1 or -1
	local angleDiff = math_Rad( math_NormalizeAngle( ( ultimate.mCmd.ViewAngles.y - wishYaw ) * inverted ) )

	ultimate.mCmd.ForwardMove = ultimate.mCmd.ForwardMove * -math_Cos( angleDiff ) * inverted + ultimate.mCmd.SideMove * math_Sin( angleDiff )
	ultimate.mCmd.SideMove = ultimate.mCmd.ForwardMove * math_Sin( angleDiff ) * inverted + ultimate.mCmd.SideMove * math_Cos( angleDiff ) 
end

ultimate.HandJob = {
    [1] = function( cmd )
        if _G.EasyChat then
            net_Start("EASY_CHAT_START_CHAT") 
			    net_WriteBool(true)
			net_SendToServer()
        else
            ded.SetTyping( cmd, true )
        end
    end,
    [2] = function( cmd )
        if _G.EasyChat then
            net_Start("EASY_CHAT_START_CHAT") 
                net_WriteBool(( ultimate.mCmd.CommandNumber % 12 ) >= 6)
            net_SendToServer()
        else
            ded.SetTyping( cmd, ( ultimate.mCmd.CommandNumber % 12 ) >= 6 )
        end
    end, 
    [3] = function( cmd )
        if _G.EasyChat then
            net_Start("EASY_CHAT_START_CHAT") 
                net_WriteBool(math_Random( 0, 1 ) == 0)
            net_SendToServer()
        else
            ded.SetTyping( cmd, math_Random( 0, 1 ) == 0 )
        end
    end,
}

ultimate.Autosrafers = {
    [ 1 ] = function() 
        ultimate.mCmd.SideMove = ultimate.mCmd.Swap and -5250 or 5250
    end,
    [ 2 ] = function()
        if ultimate.mCmd.MouseY > 1 then
            ultimate.mCmd.SideMove = ultimate.cVars.sidespeed
        elseif ultimate.mCmd.MouseY < 1 then
            ultimate.mCmd.SideMove = -ultimate.cVars.sidespeed
        end
    end,
    [ 3 ] = function()  
        local velocityLength = ultimate.LocalVelocity:Length2D()
        local sideFlip = ( ultimate.mCmd.TickCount % 2 ) == 0 and 1 or -1

        local viewAngles = ultimate.mView.FakeAng.y
        local velocityAngles = ultimate.LocalVelocity:Angle().y

        if velocityLength <= 15 and ( ultimate.mCmd.ForwardMove == 0 or ultimate.mCmd.SideMove == 0 ) then
            return
        end

        local turnAtan = math_Atan2( -ultimate.mCmd.SideMove, ultimate.mCmd.ForwardMove )
        viewAngles = viewAngles + ( turnAtan * ultimate.Radian )

        local strafeAngle = math_Min( math_Deg( math_Atan( 15 / velocityLength ) ), ultimate.cVars.sv_airaccelerate / ultimate.TickRate )
        if strafeAngle > 90 then strafeAngle = 90 elseif strafeAngle < 0 then strafeAngle = 0 end

        local tempYaw = math_NormalizeAngle( viewAngles - ultimate.OldStrafeYaw )
        local yawDelta = tempYaw

        ultimate.OldStrafeYaw = viewAngles

        local absYawDelta = math_Abs( yawDelta )

        if absYawDelta <= strafeAngle or absYawDelta >= 30 then
            tempYaw = math_NormalizeAngle( viewAngles - velocityAngles )

            local velocityDegree = math_Deg( math_Atan( 30 / ( velocityLength * 128 ) ) )
            if velocityDegree > 90 then velocityDegree = 90 elseif velocityDegree < 0 then velocityDegree = 0 end
       
            if tempYaw <= velocityDegree or velocityLength <= 15 then
                if -velocityDegree <= tempYaw or velocityLength <= 15 then
                    viewAngles = viewAngles + ( strafeAngle * sideFlip )
                    ultimate.mCmd.SideMove = ( ultimate.cVars.sidespeed * sideFlip )
                else
                    viewAngles = velocityAngles - velocityDegree
                    ultimate.mCmd.SideMove = ultimate.cVars.sidespeed
                end
            else
                viewAngles = velocityAngles + velocityDegree
                ultimate.mCmd.SideMove = -ultimate.cVars.sidespeed
            end
        elseif yawDelta != 0 then
            ultimate.mCmd.SideMove = yawDelta > 0 and -ultimate.cVars.sidespeed or ultimate.cVars.sidespeed
        end

        local moveVec = gVec( ultimate.mCmd.ForwardMove, ultimate.mCmd.SideMove, 0 )
        local moveLen = moveVec:Length()
        local moveAng = moveVec:Angle().y

        local normX = math_ModF( ultimate.mView.FakeAng.x + 180, 360 ) - 180
        local normY = math_ModF( ultimate.mView.FakeAng.y + 180, 360 ) - 180

        local moveYaw = math_Rad( normY - viewAngles + moveAng )

        if normX >= 90 or normX <= -90 or ultimate.mView.FakeAng.x >= 90 and ultimate.mView.FakeAng.x <= 200 or ultimate.mView.FakeAng.x <= -90 and ultimate.mView.FakeAng.x <= 200 then
            ultimate.mCmd.ForwardMove = -math_Cos( moveYaw ) * moveLen
        else
            ultimate.mCmd.ForwardMove = math_Cos( moveYaw ) * moveLen
        end

        ultimate.mCmd.SideMove = math_Sin( moveYaw ) * moveLen
    end
}

/*
    Tracing 
*/

ultimate.TraceStruct = { filter = ultimate.LocalPlayer, mask = MASK_SHOT, start = 0, endpos = 0 }
ultimate.TraceResult = {}
ultimate.ShittySweps = { ["swb_knife"] = true, ["swb_knife_m"] = true }

function ultimate.WallScan( Ent, Dir )
    if ultimate.ShittySweps[ ultimate.Players[1].WeaponClass ] then return false end 


end

function ultimate.VisibleCheck( Ent, Vec, AWallDir )
    ultimate.TraceStruct.start = ultimate.EyePos
    ultimate.TraceStruct.endpos = Vec

    ultimate.TraceResult = util_TraceLine( ultimate.TraceStruct )

    local CanHit = ultimate.TraceResult.Entity == Ent or ultimate.TraceResult.Fraction == 1

    if not CanHit and AWallDir and ultimate.cfg.vars.WallScan then
        return ultimate.WallScan( Ent, AWallDir )
    end

    if ultimate.cfg.vars.HeadshotOnly then
        return ultimate.TraceResult.HitGroup == 1 
    end

    return CanHit
end

/*
    Hitbox Selection
*/

ultimate.ParsedBones = {}
ultimate.HitBoxData = {
    [ HITGROUP_HEAD ]       = { damage = 3, scale = 1, safety = 1 },
    [ HITGROUP_CHEST ]      = { damage = 2, scale = 3, safety = 2 },
    [ HITGROUP_STOMACH ]    = { damage = 2, scale = 2, safety = 3 },
    [ HITGROUP_LEFTARM ]    = { damage = 1, scale = 1, safety = 1 },
    [ HITGROUP_RIGHTARM ]   = { damage = 1, scale = 1, safety = 1 },
    [ HITGROUP_LEFTLEG ]    = { damage = 1, scale = 1, safety = 1 },
    [ HITGROUP_RIGHTLEG ]   = { damage = 1, scale = 1, safety = 1 },
}

function ultimate.ParsePlayerBones( EntTable )
    if ultimate.ParsedBones[ EntTable.Model ] then
        return ultimate.ParsedBones[ EntTable.Model ]
    end

    ultimate.ParsedBones[ EntTable.Model ] = {}

    local HitBoxSet = EntTable.Ent:GetHitboxSet()
    local BoneCount = EntTable.Ent:GetBoneCount()

    for i = 0, BoneCount - 1 do
        local HitBoxGroup = EntTable.Ent:GetHitBoxHitGroup( i, HitBoxSet )

        if HitBoxGroup == nil or not ultimate.HitBoxData[ HitBoxGroup ] then continue end

        ultimate.ParsedBones[ EntTable.Model ][ #ultimate.ParsedBones[ EntTable.Model ] + 1 ] = {
            Index = i,
            Group = HitBoxGroup,
            DamageRank = ultimate.HitBoxData[ HitBoxGroup ].damage,
            ScaleRank = ultimate.HitBoxData[ HitBoxGroup ].scale,
            SafetyRank = ultimate.HitBoxData[ HitBoxGroup ].safety,
        }
    end

    return ultimate.ParsedBones[ EntTable.Model ]
end 
                
function ultimate.GetHitBoxBounds( Mins, Maxs, Pos, Ang )
    local Points = {
        ( ( Mins + Maxs ) * 0.5 ),
        Vector( Mins.x, Mins.y, Mins.z ),
        Vector( Mins.x, Maxs.y, Mins.z ),
        Vector( Maxs.x, Maxs.y, Mins.z ),
        Vector( Maxs.x, Mins.y, Mins.z ),
        Vector( Maxs.x, Maxs.y, Maxs.z ),
        Vector( Mins.x, Maxs.y, Maxs.z ),
        Vector( Mins.x, Mins.y, Maxs.z ),
        Vector( Maxs.x, Mins.y, Maxs.z )
    }

    for i = 1, #Points do
        Points[ i ]:Rotate( Ang )
        Points[ i ] = Points[ i ] + Pos

        if i == 1 then continue end 

        Points[ i ] = ( ( Points[ i ] - Points[1] ) * ultimate.cfg.vars.MultiPointScale ) + Points[ 1 ]
    end

    return Points
end

function ultimate.GetAimPosition( EntTable )
    local BoneTable = ultimate.ParsePlayerBones( EntTable )
    local BackUpPos = EntTable.Ent:LocalToWorld( EntTable.Ent:OBBCenter() )
    local HitboxSet = EntTable.Ent:GetHitboxSet()

    if ultimate.cfg.vars.HitScan then
        local SortedBones = {}
        local BonePositions = {}

        for i = 1, #BoneTable do
            local Group = BoneTable[ i ].Group 
            
            if not ultimate.cfg.vars.ScanHead and Group == 1 then continue end           
            if not ultimate.cfg.vars.ScanChest and Group == 2 then continue end                
            if not ultimate.cfg.vars.ScanStomach and Group == 3 then continue end                 
            if not ultimate.cfg.vars.ScanLegs and Group == 6 or Group == 7 then continue end                   
            if not ultimate.cfg.vars.ScanArms and Group == 4 or Group == 5 then continue end 

            SortedBones[ #SortedBones + 1 ] = BoneTable[ i ]
        end

        if #SortedBones == 0 then return { BackUpPos } end 

        if ultimate.cfg.vars.HitboxSorting == 1 then
            table.sort( SortedBones, function( a, b )
                return a.DamageRank < b.DamageRank
            end )
        elseif ultimate.cfg.vars.HitboxSorting == 2 then
            table.sort( SortedBones, function( a, b )
                return a.ScaleRank < b.ScaleRank
            end)
        elseif ultimate.cfg.vars.HitboxSorting == 3 then
            table.sort( SortedBones, function( a, b )
                return a.SafetyRank < b.SafetyRank
            end )
        end

        for i = 1, #SortedBones do
            local Index = SortedBones[ i ].Index
            local HitBoxBone = EntTable.Ent:GetHitBoxBone( Index, HitboxSet )
            if HitBoxBone == nil then continue end

            local BoneMins, BoneMaxs = EntTable.Ent:GetHitBoxBounds( Index, HitboxSet )
            if not BoneMins or not BoneMaxs then return { BackUpPos } end
            
            local BonePos, BoneAng = EntTable.Ent:GetBonePosition( HitBoxBone ) 

            if ultimate.cfg.vars.MultiPoint then
                local Points = ultimate.GetHitBoxBounds( BoneMins, BoneMaxs, BonePos, BoneAng )

                for MPs = 1, #Points do
                    BonePositions[ #BonePositions + 1 ] = Points[ MPs ]
                end
            else
                BoneMins:Rotate( BoneAng )
                BoneMaxs:Rotate( BoneAng )
                BonePositions[ #BonePositions + 1 ] = BonePos + ( ( BoneMins + BoneMaxs ) * 0.5 )
            end
        end

        if #BonePositions == 0 then return { BackUpPos } end 

        return BonePositions
    else
        local PreferedBoneIndex = 1

        for i = 1, #BoneTable do
            if BoneTable[ i ].Group != ultimate.cfg.vars.TargetHitbox then continue end 
            PreferedBoneIndex = BoneTable[ i ].Index
            break
        end

        local HitBoxBone = EntTable.Ent:GetHitBoxBone( PreferedBoneIndex, HitboxSet )

        if HitBoxBone == nil then return { BackUpPos } end

        local BoneMins, BoneMaxs = EntTable.Ent:GetHitBoxBounds( PreferedBoneIndex, HitboxSet )

        if not BoneMins or not BoneMaxs then return { BackUpPos } end

        local BonePos, BoneAng = EntTable.Ent:GetBonePosition( HitBoxBone )  

        if ultimate.cfg.vars.MultiPoint then
            return ultimate.GetHitBoxBounds( BoneMins, BoneMaxs, BonePos, BoneAng )
        else
            BoneMins:Rotate( BoneAng )
            BoneMaxs:Rotate( BoneAng )
            return { BonePos + ( ( BoneMins + BoneMaxs ) * 0.5 ) }
        end
    end
                   
    return { BackUpPos }
end

/*
    Target Selection
*/

ultimate.FriendList = {}

function ultimate.SortedPlayers( sortingMode )
    local myTeam = ultimate.Players[ 1 ].Team
    local validTargets = {}

    for i = 2, #ultimate.Players do
        local entTable = ultimate.Players[ i ]

        if not IsValid( entTable.Ent ) then continue end
        if not entTable.Alive or entTable.Dormant then continue end
        
        if ultimate.cfg.vars.IgnoreFriends and ultimate.FriendList[ entTable.SteamID ] then continue end
        if ultimate.cfg.vars.IgnoreSteamFriends and entTable.FriendStatus == "friend" then continue end
        if ultimate.cfg.vars.IgnoreBots and entTable.Bot then continue end
        if ultimate.cfg.vars.IgnoreTeammates and entTable.Team == myTeam then continue end
        if ultimate.cfg.vars.IgnoreDriving and IsValid( entTable.Ent:GetVehicle() ) then continue end
        if ultimate.cfg.vars.IgnoreGodmode and bor( entTable.Flags, FL_GODMODE ) == FL_GODMODE then continue end
        if ultimate.cfg.vars.IgnoreNoclips and bor( entTable.EFlags , EFL_NOCLIP_ACTIVE ) == EFL_NOCLIP_ACTIVE then continue end
        if ultimate.cfg.vars.IgnoreNodraw and bor( entTable.Effects, EF_NODRAW ) == EF_NODRAW then continue end
        if ultimate.cfg.vars.IgnoreFrozen and bor( entTable.Flags, FL_FROZEN  ) == FL_FROZEN  then continue end
        if ultimate.cfg.vars.IgnoreAdmins and entTable.UserGroup == "admin" or entTable.UserGroup == "superadmin" then continue end
        if ultimate.cfg.vars.IgnoreBrokenLagComp and entTable.BreakingLagComp then continue end

        validTargets[ #validTargets + 1 ] = entTable
    end

    if #validTargets == 0 then return end 
    
    if sortingMode == 1 then
        table.sort( validTargets, function( a, b )
            return ( a.Position - ultimate.EyePos ):LengthSqr() < ( b.Position - ultimate.EyePos ):LengthSqr()       
        end )
    elseif sortingMode == 2 then
        table.sort( validTargets, function( a, b )
            local aScreenPos = a.Position:ToScreen()
            local bScreenPos = b.Position:ToScreen()
            
            local ax = ( ScreenWidthCenter - aScreenPos.x )
            local bx = ( ScreenWidthCenter - bScreenPos.x )

            local ay = ( ScreenHeightCenter - aScreenPos.y )
            local by = ( ScreenHeightCenter - bScreenPos.y )

            local aDist = ax * ax + ay * ay
            local bDist = bx * bx + by * by

            return aDist < bDist
        end)
    elseif sortingMode == 3 then
        table.sort( validTargets, function( a, b )
            return a.Health < b.Health 
        end )
    end

    return validTargets
end 

function ultimate.GetAimbotTarget( cmd )
    local Targets = ultimate.SortedPlayers( ultimate.cfg.vars.SortingMethod )
 
    if not Targets then return end

    local NumTargets = #Targets 

    if ultimate.cfg.vars.MaxTargets != 0 and NumTargets > ultimate.cfg.vars.MaxTargets then
        NumTargets = ultimate.cfg.vars.MaxTargets
    end

    for i = 1, NumTargets do
        local Target = Targets[ i ]
        local AvaliablePositions = ultimate.GetAimPosition( Target )

        for p = 1, #AvaliablePositions do
            local Bone = AvaliablePositions[ p ]

            if not ultimate.VisibleCheck( Target.Ent, Bone, AWallDir ) then continue end 

            return Target.Ent, Bone
        end
 
    end
end 
 














ultimate.EyePos = ultimate.LocalPlayer:EyePos()


function ultimate.hook_CreateMove( cmd )

    for i = 1, #ultimate.cfg.binds do
        if ultimate.cfg.binds[ i ].key < 0 then continue end 

        if ultimate.cfg.binds[ i ].mode == 1 then
            ultimate.cfg.binds[ i ].state = ultimate.input_IsKeyDown( ultimate.cfg.binds[ i ].key )
        elseif ultimate.cfg.binds[ i ].mode == 2 and ultimate.input_WasKeyPressed( ultimate.cfg.binds[ i ].key ) then
            ultimate.cfg.binds[ i ].state = not ultimate.cfg.binds[ i ].state
        end
    end

    for i = 1, 113 do
        ultimate.mInput.KeysDown[ i ] = ultimate.input_IsKeyDown( i )
        ultimate.mInput.KeysPressed[ i ] = ultimate.input_WasKeyPressed( i )
    end

    ultimate.CollectCommandData( cmd )
    ultimate.ComputeAngleData( cmd ) 

    if ultimate.mCmd.CommandNumber == 0 then return end 

    if ultimate.cfg.vars.SilentAim then
        ultimate.mCmd.ViewAngles = gAng( ultimate.mView.FakeAng.x, ultimate.mView.FakeAng.y, 0 )
    end

    ultimate.mCmd.InBadMove = false
    ultimate.mCmd.InMove = false
    ultimate.mCmd.Swap = ( ultimate.mCmd.CommandNumber % 2 ) == 0

    ultimate.mCmd.OnGround = ultimate.LocalPlayer:IsFlagSet( FL_ONGROUND )
    ultimate.EyePos = ultimate.LocalPlayer:EyePos()

    if ultimate.mCmd.OnGround then
        ultimate.mCmd.OnGroundTicks = ultimate.mCmd.OnGroundTicks + 1
    else 
        ultimate.mCmd.OnGroundTicks = 0 
    end

    ultimate.MovementType = ultimate.LocalPlayer:GetMoveType()
    ultimate.LocalVelocity = ultimate.LocalPlayer:GetVelocity()
    ultimate.ModifySequence = 0

    for i = 1, #ultimate.MoveKeys do
        if band( ultimate.mCmd.Buttons, ultimate.MoveKeys[ i ]  ) == ultimate.MoveKeys[ i ] then
            ultimate.mCmd.InMove = true
            break 
        end  
    end

    for i = 1, #ultimate.BadMovetypes do
        if ultimate.MovementType == ultimate.BadMovetypes[ i ] then 
            ultimate.mCmd.InBadMove = true
            break
        end 
    end

    if not ultimate.Players[1] then return end

    local shit, nigger = ultimate.GetAimbotTarget(  )
    print( shit )
    debugoverlay.Box( nigger, gVec( -2, -2, -2 ), gVec( 2, 2, 2 ), 0.2, Color(255,0,0) )
    // Misc 
    if ultimate.cfg.vars.HandJob then 
        ultimate.HandJob[ ultimate.cfg.vars.HandJobMode ]( cmd ) 
    end

    if ultimate.cfg.vars.FlashlightSpam and ultimate.cfg.binds[ 3 ].state then 
        ultimate.mCmd.Impulse = 100 
    end

    if ultimate.cfg.vars.UseSpam and bor( ultimate.mCmd.Buttons, IN_USE ) == IN_USE and ultimate.mCmd.Swap then 
        ultimate.mCmd.Buttons = band( ultimate.mCmd.Buttons, bnot( IN_USE ) ) 
    end 

    if ultimate.cfg.vars.TauntSpam then
        local shouldTaunt = ultimate.cfg.vars.TauntTime == 0 and not ultimate.LocalPlayer:IsPlayingTaunt( true ) == false or ultimate.LastTauntTime < ultimate.CurTime
        
        if shouldTaunt then
            if DarkRP then
                RunConsoleCommand( "_DarkRP_DoAnimation", ultimate.DarkRpTaunts[ ultimate.cfg.vars.Taunt ] )
            else
                RunConsoleCommand( "act", ultimate.Taunts[ ultimate.cfg.vars.Taunt ] )  
            end
            
            ultimate.LastTauntTime = ultimate.CurTime + ultimate.cfg.vars.TauntTime
        end
    end

    if ultimate.cfg.vars.CameraSpam and ultimate.Players[1].WeaponClass == "gmod_camera" and ultimate.mCmd.Swap and band( ultimate.mCmd.Buttons, IN_ATTACK ) == IN_ATTACK then
        ultimate.mCmd.Buttons = band( ultimate.mCmd.Buttons, bnot( IN_ATTACK ) ) 
    end

    // Movement 

    if not ultimate.mCmd.InBadMove then
        if ultimate.cfg.vars.EdgeJump and ultimate.cfg.binds[ 4 ].state and ultimate.mCmd.OnGroundTicks > 24 then
            ded.StartSimulation( ultimate.Players[1].Index )

            ded.SimulateTick()

            local data = ded.GetSimulationData()

            ded.FinishSimulation() 

            if data.m_vecAbsOrigin.z < ultimate.Players[1].Position.z then
                ultimate.mCmd.Buttons = bor( ultimate.mCmd.Buttons, IN_JUMP )
            end
        end

        if ultimate.cfg.vars.WaterWalk and ultimate.Players[1].Ent:WaterLevel() > 1 then
            ultimate.mCmd.Buttons = bor( ultimate.mCmd.Buttons, IN_JUMP )
        end

        if band( ultimate.mCmd.Buttons, IN_JUMP ) == IN_JUMP then
            local shouldHop = ultimate.cfg.vars.MaxHops < 1 and true or ( ultimate.mCmd.NumHops < ultimate.cfg.vars.MaxHops )

            if ultimate.cfg.vars.BunnyHop and shouldHop then
                if ultimate.mCmd.OnGround then 
                    ultimate.mCmd.NumHops = ultimate.mCmd.NumHops + 1
                else
                    ultimate.mCmd.Buttons = band( ultimate.mCmd.Buttons, bnot( IN_JUMP ) )
                end
            end

            if ultimate.cfg.vars.AutoStrafe then
                ultimate.mCmd.ForwardMove = ultimate.mCmd.OnGround and ultimate.cVars.forwardspeed or 5850 / ultimate.LocalVelocity:Length2D() 

                if not ultimate.mCmd.OnGround then
                    ultimate.Autosrafers[ ultimate.cfg.vars.AutoStrafeMode ]()
                else
                    ultimate.mCmd.Buttons = bor( ultimate.mCmd.Buttons, IN_SPEED )
                end
            end
        else
            ultimate.mCmd.NumHops = 0
        end

        if ultimate.mCmd.OnGround and ultimate.cfg.vars.GroundStrafe and ultimate.mCmd.SideMove == 0 and ultimate.mCmd.ForwardMove > 0 then
            ultimate.mCmd.SideMove = ultimate.mCmd.Swap and -5250 or 5250
        end  

        if ultimate.cfg.vars.FastStop and not ultimate.mCmd.InMove and ultimate.mCmd.OnGround then
            local dir = ultimate.LocalVelocity:Angle()
                        
            dir.y = ultimate.mView.FakeAng.y - dir.y
                        
            local newmove = dir:Forward() * ultimate.LocalVelocity:Length2D()
                
            ultimate.mCmd.ForwardMove = -newmove.x
            ultimate.mCmd.SideMove = -newmove.y
        end

        if ultimate.cfg.vars.SlowWalk and ultimate.cfg.binds[ 5 ].state then 
            local ratio = ultimate.Players[1].Ent:GetSlowWalkSpeed()

            ultimate.mCmd.ForwardMove = math_Floor( ultimate.mCmd.ForwardMove / ( ultimate.cfg.vars.SlowWalkSpeed * ratio ) )
            ultimate.mCmd.SideMove = math_Floor( ultimate.mCmd.SideMove / ( ultimate.cfg.vars.SlowWalkSpeed * ratio ) )
        end
    end

    if ultimate.cfg.vars.AutoClimbSwep and ultimate.Players[1].Weapon and ultimate.Players[1].Weapon.Jumps then
        local jumps = ultimate.Players[1].Ent:GetNWInt("ClimbJumps")
        
        if ultimate.cVars.maxjumps - jumps < ultimate.cVars.maxjumps then
            ultimate.mCmd.ForwardMove = ultimate.cVars.forwardspeed
            ultimate.mCmd.SideMove = 0
            
            ultimate.mCmd.ViewAngles.y = math_NormalizeAngle( ultimate.mCmd.ViewAngles.y - 180 )
        end
    end 

    if ultimate.cfg.vars.RapidFire and band( ultimate.mCmd.Buttons, IN_ATTACK ) == IN_ATTACK and ultimate.mCmd.Swap and ultimate.Players[1].WeaponClass != "weapon_physgun" then
        ultimate.mCmd.Buttons = band( ultimate.mCmd.Buttons, bnot( IN_ATTACK ) )
    end

    if not ultimate.cfg.vars.SilentAim then 
        ultimate.mView.FakeAng = ultimate.mCmd.ViewAngles 
    else
        ultimate.FixMovement( cmd, ultimate.mView.FakeAng.y )
    end



    if ultimate.mView.FreeCamActive then
        ultimate.mCmd.SideMove = 0
        ultimate.mCmd.ForwardMove = 0
        ultimate.mCmd.UpMove = 0

        ultimate.mCmd.Buttons = 0 
        ultimate.mCmd.ViewAngles = ultimate.mView.PreFreeCamAngs
    else
        ultimate.mView.PreFreeCamAngs = ultimate.mCmd.ViewAngles 
    end

    // Modify input 
    cmd:SetSideMove( ultimate.mCmd.SideMove )
    cmd:SetForwardMove( ultimate.mCmd.ForwardMove )
    cmd:SetUpMove( ultimate.mCmd.UpMove )

    cmd:SetButtons( ultimate.mCmd.Buttons )
    cmd:SetImpulse( ultimate.mCmd.Impulse )

    cmd:SetMouseWheel( ultimate.mCmd.MouseWheel )
    cmd:SetMouseX( ultimate.mCmd.MouseX )
    cmd:SetMouseY( ultimate.mCmd.MouseY )
 
    cmd:SetViewAngles( ultimate.mCmd.ViewAngles )

    ded.SetBSendPacket( ultimate.mCmd.SendPacket )
    ded.SetCommandTick( cmd, ultimate.mCmd.TickCount )
end

function ultimate.hook_SendNetMsg( msgName )
    if msgName == "clc_Move" then
        if ultimate.cfg.vars.SlowMotion and ultimate.cfg.binds[ 6 ].state then
            if ultimate.SlowmoTicks < ultimate.TimeToTicks( ultimate.cfg.vars.SlowMoTime ) then
                ded.EnableSlowmotion( true )
                ultimate.SlowmoTicks = ultimate.SlowmoTicks + 1
            else
                ded.EnableSlowmotion( false )
                ultimate.SlowmoTicks = 0
            end
        else
            ded.EnableSlowmotion( false )
            ultimate.SlowmoTicks = 0
        end
    end
end

ded.SetInterpolation( false )
ded.SetSequenceInterpolation( false )

// Think 

function ultimate.fVec( vec )
    return gVec( math_Floor( vec.x ), math_Floor( vec.y ), math_Floor( vec.z ) )
end

ultimate.PathFinder             = {}
ultimate.PathFinder.LastCalc    = 0

ultimate.PathFinder.Nodes       = {}

ultimate.TrHullTemp = {
    maxs = ultimate.LocalPlayer:OBBMaxs(),
    mins = ultimate.LocalPlayer:OBBMins(),
    filter = ultimate.LocalPlayer,
    mask = MASK_PLAYERSOLID,
}

ultimate.pathLen = math_Floor( ultimate.TrHullTemp.maxs.y * 2 )

local transparent = Color( 115, 205, 255, 24)
local transparent2 = Color( 255, 128, 205, 24)

local dirvecs = {
    gVec( ultimate.pathLen, 0, 0 ),
    gVec( -ultimate.pathLen, 0, 0 ),
    gVec( 0, ultimate.pathLen, 0 ),
    gVec( 0, -ultimate.pathLen, 0 ),
    gVec( ultimate.pathLen, ultimate.pathLen, 0 ),
    gVec( ultimate.pathLen, -ultimate.pathLen, 0 ),
    gVec( -ultimate.pathLen, ultimate.pathLen, 0 ),
    gVec( -ultimate.pathLen, -ultimate.pathLen, 0 ),
    gVec( -ultimate.pathLen, -ultimate.pathLen, 0 ),
}

ultimate.PathFinder.Nodes[ 1 ]  = {
    vec = ultimate.fVec( ultimate.LocalPlayer:GetPos() ) + gVec( 0, 0, 8 ),
    dirs = {},
    comp = false,
}

for d = 1, #dirvecs do
    ultimate.PathFinder.Nodes[ 1 ].dirs[ d ] = false
end

ultimate.foundNodeVecs = {}
ultimate.prevNode = 0

ultimate.bestDistance = 13333333333333333333333333333337
ultimate.bestNode = 0
 
ultimate.targetvec = gVec( -2228, 26, -11071 )

ultimate.path = {}
 
local needtopathfind = true 
function ultimate.hook_Think()
    ultimate.CurTime = gCurTime()

    


    if ultimate.PathFinder.LastCalc <  ultimate.CurTime then
        if ultimate.PathFinder.Nodes[ultimate.bestNode] then
            debugoverlay.Box( ultimate.PathFinder.Nodes[ultimate.bestNode].vec, ultimate.TrHullTemp.mins, ultimate.TrHullTemp.maxs, 0.1, transparent2 )
        
            for i = 2, #ultimate.path do
                debugoverlay.Line( ultimate.path[i-1],ultimate.path[i], 0.1, transparent2, true )
            end
        end 

        

        if not needtopathfind then return end

        for i = 1, #ultimate.PathFinder.Nodes do
            local node = ultimate.PathFinder.Nodes[i]

            if ultimate.targetvec:DistToSqr( node.vec ) < ultimate.bestDistance then
                ultimate.bestNode = i
                ultimate.bestDistance = ultimate.targetvec:DistToSqr( node.vec )
                ultimate.path[ #ultimate.path + 1 ] = node.vec
            end

            if ultimate.bestDistance <= 136 * 136 then
                needtopathfind = false
            end

            if node.comp then
                continue
            end

            if ultimate.targetvec:DistToSqr( node.vec ) > ultimate.bestDistance then
                ultimate.PathFinder.Nodes[ i ].comp = true
                ultimate.PathFinder.LastCalc = 0.0001

                ultimate.prevNode = i

                continue
            end

            


            if ultimate.targetvec:DistToSqr( node.vec ) > ultimate.bestDistance then
                ultimate.PathFinder.Nodes[ i ].comp = true
                ultimate.PathFinder.LastCalc = ultimate.CurTime + ( 1 / FrameTime() ) / 1000

                ultimate.prevNode = i
                continue 
            end
    
            for dir = 1, #dirvecs do
                if ultimate.PathFinder.Nodes[ i ].dirs[ dir ] then continue end 
                        
                ultimate.TrHullTemp.start = node.vec
                ultimate.TrHullTemp.endpos = ultimate.fVec( node.vec + dirvecs[ dir ] )
    
                local trResult = util_TraceHull( ultimate.TrHullTemp )
                trResult.HitPos = ultimate.fVec( trResult.HitPos )

                if trResult.HitPos:DistToSqr( node.vec ) < ultimate.pathLen * ultimate.pathLen then
                    ultimate.PathFinder.Nodes[ i ].dirs[ dir ] = true 
                    continue
                end

                local foundsame = false
                for add = 1, #ultimate.PathFinder.Nodes do
                    if ultimate.PathFinder.Nodes[add].vec == trResult.HitPos or trResult.HitPos:DistToSqr( ultimate.PathFinder.Nodes[add].vec ) < ultimate.pathLen * ultimate.pathLen then
                        ultimate.PathFinder.Nodes[ i ].dirs[ dir ] = true 
                        foundsame = true
                        break
                    end
                end
 
                if foundsame then continue end
    
                local n = #ultimate.PathFinder.Nodes + 1
                ultimate.PathFinder.Nodes[ n ] = {
                    vec = trResult.HitPos,
                    dirs = {},
                    comp = false,
                }
    
                for d = 1, #dirvecs do
                    ultimate.PathFinder.Nodes[ n ].dirs[ d ] = false
                end
    
                debugoverlay.Box( trResult.HitPos, ultimate.TrHullTemp.mins, ultimate.TrHullTemp.maxs, 0.1, transparent )
    
                ultimate.PathFinder.Nodes[ i ].dirs[ dir ] = true 
            end
    
            ultimate.PathFinder.Nodes[ i ].comp = true
            ultimate.PathFinder.LastCalc = ultimate.CurTime + ( 1 / FrameTime() ) / 1000

            ultimate.prevNode = i
        end
    end
end

// Frame stages 
ultimate.FrameStages = {}

ultimate.FrameStages[ 3 ] = function() 
    local entities = ents_GetAll()
    local ent 

    for i = 1, #ultimate.Entities do
        ultimate.Entities[ i ] = nil
    end 

    for i = 1, #ultimate.Players do
        ultimate.Players[ i ] = nil
    end

    ultimate.UpdatePlayerData( ultimate.LocalPlayer )

    for i = 1, #entities do
        ent = entities[ i ]
        ultimate.Entities[ #ultimate.Entities + 1 ] = ent

        if not ent:IsPlayer() or ent == ultimate.LocalPlayer then continue end

        ultimate.UpdatePlayerData( ent )
    end

    
end

function ultimate.hook_PostFrameStageNotify( stage )
    if ultimate.FrameStages[ stage ] then ultimate.FrameStages[ stage ]() end
end

// Override

if ultimate.CurrentGamemode == "sandbox" then
    ultimate.OldIsPlayingTaunt = metaPlayer.IsPlayingTaunt 

    function metaPlayer:IsPlayingTaunt( arg )
        if arg then return ultimate.OldIsPlayingTaunt( ultimate.LocalPlayer ) end
        if ultimate.cfg.vars.TauntSpam and self == ultimate.LocalPlayer then return false end 

        return ultimate.OldIsPlayingTaunt( ultimate.LocalPlayer )
    end
end

ultimate.oldConCommand = metaPlayer.ConCommand
function metaPlayer:ConCommand( cmd )
    if ultimate.cfg.vars.CameraSpam and cmd == "jpeg" then return end

    ultimate.oldConCommand( self, cmd )
end



/*




ultimate.TauntCamObj.CreateMove = function( a1, a2, a3 )
        

        return ultimate.oldTauntCamCreateMove( a1, a2, a3 )
    end

    ultimate.TauntCamObj.ShouldDrawLocal = function( a1, a2 )
        if ultimate.cfg.vars.TauntSpam then return false end 

        return ultimate.oldTauntCamShouldDrawLocalPlayer( a1, a2 )
    end

    ultimate.TauntCamObj.CalcView = function( a1, a2, a3 )
        if ultimate.cfg.vars.TauntSpam then return false end 

        return ultimate.oldTauntCamCalcView( a1, a2, a3 )
    end
end
*/
hook_Add( "CalcView",   "hook",     ultimate.hook_CalcView )
hook_Add( "CreateMove", "hook",     ultimate.hook_CreateMove )
hook_Add( "PostFrameStageNotify", "hook",     ultimate.hook_PostFrameStageNotify )
hook_Add( "Think",      "hook",     ultimate.hook_Think )
hook_Add( "SendNetMsg",      "hook",     ultimate.hook_SendNetMsg )