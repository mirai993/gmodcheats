--[[
	MOD/lua/ai.lua
	псевдоник | STEAM_0:0:19009910 <95.221.235.217:27005> | [24-11-13 10:03:12AM]
	===BadFile===
]]


local HaveTarget=false


function Shot(target)
	
	local ply = LocalPlayer()
	local targethead = target:LookupBone("ValveBiped.Bip01_Head1") 
	local targetheadpos,targetheadang = target:GetBonePosition(targethead)

	ply:SetEyeAngles((targetheadpos - ply:GetShootPos()):Angle()) 
	 HaveTarget=false
--RunConsoleCommand("+attack")
	
end
--/*********************************
hook.Add("CreateMove","lal",function(cmd)
 if (LocalPlayer():KeyDown(IN_ATTACK)) then return end
                local aa = cmd:GetViewAngles()
                cmd:SetViewAngles(Angle(-181, aa.y, 180))
end)
hook.Remove("CreateMove","lal")
--*********************************/

if LocalPlayer():GetActiveWeapon().Primary then LocalPlayer():GetActiveWeapon().Primary.Recoil = 0   end

CreateClientConVar("jonny21_aim", 1, false, false)


CreateClientConVar("only_team", 1, false, false)



function CanShot(target)
if !LocalPlayer():Alive() or (!input.IsMouseDown(MOUSE_RIGHT)  or string.find(LocalPlayer():GetActiveWeapon():GetClass(),"knife")) then return false end
if LocalPlayer():GetActiveWeapon() and LocalPlayer():GetActiveWeapon().Primary then LocalPlayer():GetActiveWeapon().Primary.Recoil =0  end
if GetConVarNumber("jonny21_aim")!=1 then return false end
 if GetConVarNumber("only_team") == 1 and LocalPlayer():Team()==target:Team() then return false end
local ply = LocalPlayer() 
local pos = ply:GetShootPos()
local target=target
local tracedata = {}
tracedata.start = pos
	local targethead = target:LookupBone("ValveBiped.Bip01_Head1") 
	local targetheadpos,targetheadang = target:GetBonePosition(targethead)
tracedata.endpos = targetheadpos
tracedata.filter = ply
local trace = util.TraceLine(tracedata)
if trace.HitNonWorld and trace.Entity:IsPlayer() then   return true
else
--RunConsoleCommand("-attack")
return false
end
end


function aim()
	local ply = LocalPlayer() 
	local trace = util.GetPlayerTrace( ply )
	local traceRes = util.TraceLine( trace ) 
	if traceRes.HitNonWorld then 
		local target = traceRes.Entity
		if target:IsPlayer() then
	local targethead = target:LookupBone("ValveBiped.Bip01_Head1") 

			local targetheadpos,targetheadang = target:GetBonePosition(targethead)
			ply:SetEyeAngles((targetheadpos - ply:GetShootPos()):Angle()) 
			

		end
	end
end
hook.Add("Think","aimbot",aim) 
hook.Remove("Think","aimbot") 

hook.Add("Think","auto",function()
  local ply
  for i,v in pairs(player.GetAll())  do  if v!=LocalPlayer() and CanShot(v) then ply=v  break end end
  if ply != nil then
Shot(ply)
  end
  end)


local tblFonts = { }
tblFonts["MenuLarge"] = {
    font = "Verdana",
    size = 17,
    weight = 600,
    antialias = true,
}
for k,v in SortedPairs( tblFonts ) do
    surface.CreateFont( k, tblFonts[k] )
end
CreateClientConVar("jonny21_person", "0", false, false)
hook.Add("CalcView","lalsa11",function( player, pos, angles, fov )
          if GetConVarNumber("jonny21_person") == 1 and LocalPlayer():Alive() then
        local STOOD = {}
        STOOD.origin = pos-(angles:Forward()*45 + angles:Right()*-15 + angles:Up()*-2)
        STOOD.angles = angles
        STOOD.fov = fov
         
        local CROUCH = {}
        CROUCH.origin = pos-(angles:Forward()*25 + angles:Right()*-15 + angles:Up()*-25)
        CROUCH.angles = angles
        CROUCH.fov = fov
         
         
 
    if ( LocalPlayer():OnGround() && LocalPlayer():KeyDown(IN_DUCK)) then
            return CROUCH
    else return STOOD 
 
    end
 end
end)
  
hook.Add("ShouldDrawLocalPlayer", "DrawLocalPlayer", function( player )
    if GetConVarNumber("jonny21_person") == 1 and LocalPlayer():Alive() then     return true end
end)



CreateClientConVar("BunnyHop", 1, false, false)
CreateClientConVar("wh_team", 1, false, false)
CreateClientConVar("paint_players", 1, false, false)

		function Bh()
        if GetConVarNumber("BunnyHop") == 1 then
                if input.IsKeyDown(KEY_SPACE) then
                        if LocalPlayer():IsOnGround() then
                                RunConsoleCommand("+Jump")
                                timer.Create("Bhop",0.01, 0 ,function() RunConsoleCommand("-Jump") end)
                        end
                end
        end
		end
		hook.Add("Think","bh",Bh)

hook.Add( "HUDPaint", "TeamSeen", function()   
Cross()
for k,v in pairs ( player.GetAll() ) do

if GetConVarNumber("paint_players") == 1 then v:SetMaterial('lalal') end
local Position = ( v:GetPos() + Vector( 0,0,80 ) ):ToScreen()
local Name = ""
local Col=Color(255,120,0)
local Team = ""
if v == LocalPlayer() or not v:Alive() then Name = ""  Team = "" else 
Name = v:Name() Team= tostring(v:Health())
end 
         if GetConVarNumber("wh_team") == 1 then Col=team.GetColor(v:Team())end
draw.DrawText( Name, "MenuLarge", Position.x, Position.y, Col, 1 )
draw.DrawText(Team, "MenuLarge", Position.x, Position.y+15, Col , 1 )
end

end )

local This
function This2()
 This=LocalPlayer():GetEyeTrace().Entity


end
concommand.Add("this",This2)
function Cross()

if IsValid(This) then

         cam.Start3D( EyePos() , EyeAngles())
         render.SetMaterial( Material( "trails/laser" ) )
	
        StartPos = This:GetPos()
        EndPos = This:GetPos()+This:GetRight()*999999999
         render.DrawBeam(StartPos, EndPos , 3, 0, 0, Color(0,255,0,255))
         cam.End3D()

		 end
																

																local x, y = ScrW() / 2, ScrH() / 2    
                                                                local Speed = 1
                                                                surface.SetDrawColor(Color(255,160,0))
                                                                CHPosx = math.Clamp(LocalPlayer():GetEyeTrace().HitPos:ToScreen().x,0,ScrW())
                                                                CHPosy = math.Clamp(LocalPlayer():GetEyeTrace().HitPos:ToScreen().y,0,ScrH())
                                                                mathsin = math.sin(CurTime()*Speed)*4
                                                                mathcos = math.cos(CurTime()*Speed)*4
                                                                mathsin2 = math.sin(CurTime()*Speed+0.1)*4
                                                                mathcos2 = math.cos(CurTime()*Speed+0.1)*4
                                                                mathsin3 = math.sin(CurTime()*Speed-0.1)*4
                                                                mathcos3 = math.cos(CurTime()*Speed-0.1)*4
                                                                surface.DrawLine( CHPosx+mathcos*2,CHPosy+mathsin*2,CHPosx+mathcos*5,CHPosy+mathsin*5 );
                                                                surface.DrawLine( CHPosx-mathcos*2,CHPosy-mathsin*2,CHPosx-mathcos*5,CHPosy-mathsin*5 );
                                                                surface.DrawLine( CHPosx+mathsin*2,CHPosy-mathcos*2,CHPosx+mathsin*5,CHPosy-mathcos*5 );
                                                                surface.DrawLine( CHPosx-mathsin*2,CHPosy+mathcos*2,CHPosx-mathsin*5,CHPosy+mathcos*5 );
																

end

/*
[[

if ng_aimbot then 
NH_TARGETS()

local fov
local found=false 
for i=1, #nh_targets do 
local pl = nh_targets[i]
local dst=NH_GETDIST(pl:GetPos())
if dst<(fov or dst+1) and pl:Health()>0 and NH_CANTARGET(pl, true) and NH_GETBONEPOS (pl) then 
nh_target=pl
fov=dst
found =true
end
end
if not found then
nh_target=nil
end end]]*/


function This3()
LocalPlayer():ChatPrint(LocalPlayer():GetEyeTrace().Entity:GetClass())

end
concommand.Add("thisis",This3)

/*[[[[[[]]]]]][[[[[]]]]]
chat
*/


/*
HTMLTest = vgui.Create("HTML")
HTMLTest:SetPos(0,0)
HTMLTest:SetSize(0,0)

local Mes='Loading Chat'
local Str
local Url="http://files.melorean.com/counter.txt"
Request = function(cont) 

if cont!=Mes then Mes=cont chat.AddText(Color(0,0,0), "[Hackers] ", Color(0,255,0),Mes)  end 
 http.Fetch(Url, Request)


 end
http.Fetch(Url, Request)

function OnChatTab( str )
str=LocalPlayer():Nick()..': '..str
 HTMLTest:OpenURL("http://files.melorean.com/test.php?info="..str)
 str=''
 return str;
end
hook.Add('OnChatTab','OnChatTab',OnChatTab)
*/


/*
function ChatM()
		http.Fetch('http://files.melorean.com/counter.txt', function(cont) if cont!=Mes then chat.AddText(Color(0,0,0), "[Hackers] ", Color(0,255,0),Mes)  end end)
	if Str!=Mes then
		Str=Mes
		chat.AddText(Color(0,0,0), "[Hackers] ", Color(0,255,0),Str)
	end
end
hook.Add("Think",'chat',ChatM)
*/