// note by paradox: Disabled the stupid fuckin death notice telling you to buy premium. If you wanna enable it uncomment line 2261.

--[[

	Coded by Crave 4. // steamcommunity.com/id/Crave4
	
	Free version, therefore public source. Congrats!

	Credits: Razor (memeware base), Krown (gay, kinda based off his version), CyÃ¤egha (addhook function)

	The free version has absolutely 0 new things to offer compared to other lua cheats.																																											So consider getting premium?

]]

local me = LocalPlayer()
local steam = me:SteamID64()
local realname = me:Nick()

local cheatname = "Pasteware (Free)" -- pasters unite :/
local version = "2.1"
local modules = "mega.nz/#!ZZZFEYJa!Nc3yuXj_FhOARg1TsiStEnM3YmWCMXXh211-qxJL7Uk"
local discord = "https://discord.gg/bTudcrW" -- Feel free to join, also has modules and offers a free bypass for premium users.

local supported_modes, all_hooks, visible, dists, spam_messages, tauntspam, added, drawn_ents, priority_list, ignore_list, titems, traitors, tweps = { "sandbox", "murder", "darkrp", "terrortown" }, {}, {}, {}, { "discord.gg/bTudcrW", "A free version is available on the workshop!", "TAP 'EM ALL!", "Current build is v"..version.."!", "Godlike Anti-Aims and pResolvers!", "Deadly precise cheat for gmod!", "One of the greatest cheats for Garry's Mod!", "Way to the top!", "Prevent getting owned today!", "Superiority at it's finest!", "Reduce your risk of getting owned!" }, { "funny", "help", "scream", "morose" }, {}, {}, {}, {"1729998063"}, {"weapon_ttt_turtlenade", "weapon_ttt_death_station", "weapon_ttt_tripmine", "weapon_ttt_silencedsniper", "(Disguise)", "spiderman's_swep", "weapon_ttt_trait_defilibrator", "weapon_ttt_xbow", "weapon_ttt_dhook", "weapon_awp", "weapon_ttt_ak47", "weapon_jihadbomb", "weapon_ttt_knife", "weapon_ttt_c4", "weapon_ttt_decoy", "weapon_ttt_flaregun", "weapon_ttt_phammer", "weapon_ttt_push", "weapon_ttt_radio", "weapon_ttt_sipistol", "weapon_ttt_teleport", "weapon_ttt_awp", "weapon_mad_awp", "weapon_real_cs_g3sg1", "weapon_ttt_cvg_g3sg1", "weapon_ttt_healthstation5", "weapon_ttt_sentry", "weapon_ttt_poison_dart", "weapon_ttt_trait_defibrillator", "weapon_ttt_tmp_s"}, {}, {}

local chamsmat = CreateMaterial("Invisible", "VertexLitGeneric", { ["$ignorez"] = 1, ["$model"] = 1, ["$basetexture"] = "models/debug/debugwhite" })
local chamsmat2 = CreateMaterial("Visible", "VertexLitGeneric", { ["$ignorez"] = 0, ["$model"] = 1, ["$basetexture"] = "models/debug/debugwhite" })

local tppressed, tptoggle = false
local insertdown, insertdown2, menuopen, closemenu, draw_fov = false
local loaded1 = false
local displayed, footprints, blackscreen, said, said_info, bullied, already_bullied, looped_props, rotate, pressed, rot_pressed, applied, yaw_auto, name_changed, removewindow = false

local ox, oy, faketick, crouched, strafe_val, yaw_timer, prop_val, prop_delay = 0, 0, 0, 0, 0, 0, 0, 0

local og_read, og_open, og_exists, og_Receive = file.Read, file.Open, file.Exists, net.Receive

local PrimaryCol, FriendCol, NpcCol, AdminCol, AimCol, MenuCol = Color(0,125,255), Color(140, 45, 255), Color(200,200,200), Color(255,0,0), Color(255,60,160), Color(255,125,0), Color(100,255,100), Color(255,255,255)

local mousedown, candoslider, drawlast, notyetselected, insertdown2, insertdown, menuopen, aimtarget, fa, aa, audio
local servertime = CurTime()
local wep = me:GetActiveWeapon()

surface.CreateFont("Verdana", { font = "Verdana", size = 12, antialias = false, outline = true })

--[[
	MISCELLANEOUS FUNCTIONS PT.1
]]

local function msg(time, text)
	if not windowopen then
		windowopen = true

		local window = vgui.Create("DFrame")
		window:SetPos(ScrW()/4, 0)
		window:SetSize(ScrW()/2,25)
		window:SlideDown(0.3)
		window:SetTitle("")
		window:ShowCloseButton(false)
		window:SetDraggable(false)
		window.Paint = function(s, w, h)
			surface.SetDrawColor(40,40,40,240)
			surface.DrawRect(0, 0, w, h)
			--draw.RoundedBox(8, 0, 0, w, h, Color(40, 40, 40, 240))

			draw.DrawText(text, "Verdana", w/2, 6, Color(255,255,255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end

		timer.Simple(time, function()
			if windowopen then
				window:SlideUp(0.3)
				timer.Simple(0.3, function()
					windowopen = false
					window:Remove()
				end)
			end
		end)
	end

	chat.PlaySound()
	print("\n"..text.."\n")
end

local function msg(useless, text)
	-- I recoded this into a chat msg instead of a on-screen popup for the free version.
	-- The first parameter is useless and only used in the premium version, 2lazy to remove. (It was a timer on how long the msg would stay on your screen.)

	chat.PlaySound()
	chat.AddText(MenuCol, cheatname, Color(255,255,255), " - "..text)
end

local function RandomString()
	local str = ""

	for i = 1, 15 do
		str = str .. string.char(math.random(32, 126))
	end

	return str
end

local function addhook(event_name, func) -- Thank you for making my life so much easier, CyÃ¤egha.
	local name = RandomString()

	hook.Add(event_name, name, func)

	if not all_hooks[event_name] then
		all_hooks[event_name] = {}
	end

	all_hooks[event_name][name] = func
end

local function command(cmd)
	me:ConCommand(cmd)
end

local function disconnect(reason)
  msg(4, "Disconnected from the server. (Reason: "..reason..")")
  command("disconnect")
end

--[[
	SETUP
]]

do
	if pwloaded then
		msg(5, "Cheat already loaded. Press Insert, F11 or Home to open the menu.")
		return
	else
		if SERVER then return end
		
		if gui.IsGameUIVisible() then
			gui.HideGameUI()
		end

		if not system.IsWindows() then
			msg(7, cheatname.." only works on Windows. Change your operating system in order to use it.")
			return
		end

		if ScrW() <= 900 or ScrH() <= 700 then
			msg(8, "The menu's size is 900x700. Please use a resolution higher than that.")
			return
		end

		-- Line below needs to get simplified.
		if not file.Exists("lua/bin/gmcl_hi_win32.dll", "MOD") or not file.Exists("lua/bin/gmcl_fhook_win32.dll", "MOD") or not file.Exists("lua/bin/gmcl_stringtables_win32.dll", "MOD") or not file.Exists("lua/bin/gmcl_chatclear_win32.dll", "MOD") then
			SetClipboardText(modules)
			msg(7, "Please download the modules first. The download link has been copied to your clipboard.")
			chat.AddText(PrimaryCol, modules)
			return
		else
			if _G.QAC or _G.qac then
				--msg(5, "Detected QAC. Applied experimental bypass.") nope
				disconnect("Detected QAC.")
			--[[elseif _G.TAC or _G.tac then
				msg(3, "Detected TAC. Blocking incoming checks.") nope]]
			elseif _G.CAC or _G.cac then
				--[[if not file.IsDir(cheatname, "DATA") then
					msg(5, "Welcome, "..me:Nick()..". Press Insert, F11 or Home to open the menu.")
					file.CreateDir(cheatname)
				else
					msg(5, "Detected CAC. If you're using the correct bypass, you shouldn't get banned.") nope
				end]]
				disconnect("Detected CAC.")
			else
				if not file.IsDir(cheatname, "DATA") then
					msg(5, "Welcome, "..me:Nick()..". Press Insert, F11 or Home to open the menu.")
					file.CreateDir(cheatname)
				else
					if table.HasValue(supported_modes, engine.ActiveGamemode()) then
						if not file.IsDir(cheatname, "DATA") then
							msg(5, "Welcome, "..me:Nick()..". Press Insert, F11 or Home to open the menu.")
						else
							msg(3, "loaded successfully!")
						end
					else
						msg(5, "loaded successfully, but this gamemode isn't supported.")
					end
				end
			end

			require("hi")
			require("fhook")
			require("stringtables")
			require("ChatClear")

			memesendpacket = true
		end
	end

	game.RemoveRagdolls()
	command("cl_lagcompensation 1; r_cleardecals; cl_interp 0; cl_interp_ratio 2; cl_updaterate 30; gmod_mcore_test 1; r_queued_ropes 1; cl_threaded_bone_setup 1; cl_threaded_client_leaf_system 1; mat_queue_mode -1; r_threaded_renderables 1; r_threaded_particles 1; M9KGasEffect 0; hud_draw_fixed_reticle 0")
end

local options = {
	["Aimbot"] = {
		{
			{"Aimbot", 85, 40, 350, 235, 175},
			{"Enabled", "Checkbox", false, 0},
			{"Silent Aimbot", "Checkbox", false, 0},
			{"Auto Fire", "Checkbox", false, 0},
			{"Auto Stop", "Checkbox", false, 0},
			{"Auto Crouch", "Checkbox", false, 0},
			{"Auto Zoom", "Checkbox", false, 0},
			{"Aim Key", "Selection", "None", {"None", "Mouse3", "Mouse4", "Mouse5", "L-ALT", "L-CTRL", "Shift", "Letter: E", "Letter: F", "Letter: Q"}, 125},
			{"Aimbot FOV", "Slider", 0, 90, 125},
		},
		{
			{"Other", 445, 40, 350, 300, 175},
			{"Priority", "Selection", "FOV", {"FOV", "Nearest", "Lowest Health"}, 125},
			{"Aim Position", "Selection", "Head only", {"Head only", "Body only"}, 125},
			{"Ignore Players", "Checkbox", false, 0},
			{"Ignore NPCs", "Checkbox", false, 0},
			{"Ignore Team", "Checkbox", false, 0},
			{"Ignore Friends", "Checkbox", false, 0},
			{"Ignore Bots", "Checkbox", false, 0},
			{"Ignore Admins", "Checkbox", false, 0},
			{"Ignore driving Players", "Checkbox", false, 0},
			{"Ignore noclipping Players", "Checkbox", false, 0},
			{"Ignore transparent Players", "Checkbox", false, 0},
		},
	},
	["Triggerbot"] = {
		{
			{"Triggerbot", 85, 40, 350, 155, 175},
			{"Enabled", "Checkbox", false, 0},
			{"Auto Stop", "Checkbox", false, 0},
			{"Auto Crouch", "Checkbox", false, 0},
			{"Auto Zoom", "Checkbox", false, 0},
			{"Trigger Key", "Selection", "None", {"None", "Mouse3", "Mouse4", "Mouse5", "L-ALT", "L-CTRL", "Shift", "Letter: E", "Letter: F", "Letter: Q"}, 125},
		},
		{
			{"Other", 445, 40, 350, 275, 175},
			{"Trigger Position", "Selection", "Auto", {"Head only", "Body only", "Auto"}, 125 },
			{"Ignore Players", "Checkbox", false, 0},
			{"Ignore NPCs", "Checkbox", false, 0},
			{"Ignore Team", "Checkbox", false, 0},
			{"Ignore Friends", "Checkbox", false, 0},
			{"Ignore Bots", "Checkbox", false, 0},
			{"Ignore Admins", "Checkbox", false, 0},
			{"Ignore driving Players", "Checkbox", false, 0},
			{"Ignore noclipping Players", "Checkbox", false, 0},
			{"Ignore transparent Players", "Checkbox", false, 0},
		},
	},
	["Hack vs Hack"] = {
		{
			{"Anti-Aim", 85, 40, 350, 165, 175},
			{"Enabled", "Checkbox", false, 0},
			{"Follow closest Target", "Checkbox", false, 0},
			{"Pitch", "Selection", "None", {"None", "Up", "Down", "Center", "Fake-Down", "Jitter"}, 125},
			{"Yaw", "Selection", "None", {"None", "Sideways", "Backwards", "Spin", "Jitter", "Fake-Forwards"}, 125},
			{"Spin Speed", "Slider", 30, 180, 125},
		},
		{
			{"Anti-Aim Resolver", 445, 40, 350, 45, 175},
			{"Enabled", "Checkbox", false, 0},
		},
	},
	["Visuals"] = {
		{
			{"ESP", 85, 40, 350, 275, 175},
			{"Enabled", "Checkbox", false, 0},
			{"Names", "Checkbox", false, 0},
			{"Bones", "Checkbox", false, 0},
			{"Highlight Friends", "Checkbox", false, 0},
			{"Highlight Admins", "Checkbox", false, 0},
			--{"Draw Weapons", "Checkbox", false, 0},
			{"Draw Mode", "Selection", "Players only", {"Players only", "NPCs only", "Both"}, 125},
			{"Box", "Selection", "Off", {"Off", "2D (Outlined)", "2D (Semi-Solid)", "2D (Solid)", "3D"}, 125},
			{"Health", "Selection", "Off", {"Off", "Value only", "Bar only", "Both"}, 125},
			{"Lines", "Selection", "Off", {"Off", "Top", "Bottom", "Center"}, 125},
			{"Draw Local Player", "Checkbox", true, 0},
		},
		{
			{"Other", 445, 40, 350, 160, 175},
			{"Team Colors", "Checkbox", false, 0},
			{"Crosshair", "Checkbox", false, 0},
			{"No Recoil", "Checkbox", false, 0},
			{"Third Person", "Selection", "Off", {"Off", "On", "Mouse3", "Mouse4", "Mouse5", "L-ALT", "L-CTRL", "Shift", "Letter: E", "Letter: R", "Letter: F", "Letter: Q", "Letter: G"}, 125},
			{"Third Person Distance", "Slider", 0, 40, 125},
		},
		{
			{"Radar", 445, 215, 350, 125, 175},
			{"Enabled", "Checkbox", false, 0},
			{"Size", "Slider", 100, ScrH()/5, 125},
			{"Distance", "Slider", 5, 10, 125},
		},
	},
	["Misc"] = {
		{
			{"Misc", 85, 40, 350, 275, 175},
			{"Bunny Hop", "Checkbox", false, 0},
			{"Auto Strafe", "Checkbox", false, 0},
			--{"Circle Strafe", "Selection", "Off", {"Off", "Mouse3", "Mouse4", "Mouse5", "L-ALT", "L-CTRL", "Shift", "Letter: E", "Letter: F", "Letter: Q", "Letter: G"}, 125},
			{"Auto Reload", "Checkbox", false, 0},
			{"Rapid Fire", "Checkbox", false, 0},
			{"Log Kills in Chat", "Checkbox", false, 0},
			{"Name Stealer", "Checkbox", false, 0},
			{"Chat Spam", "Selection", "Advertisements", {"Off", "Advertisements", "Clear Chat"}, 125},
			{"Spam after Kill", "Checkbox", false, 0},
			{"Hitsound", "Checkbox", false, 0},
			{"Mute Footsteps", "Checkbox", false, 0},
		},
		{
			{"Fake Lag", 445, 40, 350, 75, 175},
			{"Density", "Slider", 0, 14, 125},
			{"Disable on Attack", "Checkbox", false, 0},
		},
		--[[{
			{"Configuration", 445, 130, 350, 170, 175},
			{"Load Config", "Selection", "Config #1", {"Config #1", "Config #2", "Config #3", "Config #4", "Config #5"}, 125},
			{"Config Path: GarrysMod\\garrysmod\\data\\"..cheatname, "Checkbox", false, 9999},
			{"Save selected config", "Button", "", 125},
			{"Load selected config", "Button", "", 125},
			{"Delete selected config", "Button", "", 125},
			{"Automatically save", "Checkbox", false, 0},
		},]] -- considered to make this public but nope gay kids gonna have pcodes :/
		{
			{"Other", 445, 130, 350, 130, 175},
			{"List Staff", "Button", "", 125},
			{"Discord / Premium", "Button", "", 125},
			{"Unload "..cheatname, "Button", "", 125},
			{"Debug Information", "Checkbox", false, 0},
		},
	},
	--[[["Gamemode"] = {
		{
			{"Murder", 85, 40, 350, 380, 175},
			{"Draw Magnum", "Checkbox", false, 0},
			{"Draw Knife", "Checkbox", false, 0},
			{"Draw Loot", "Checkbox", false, 0},
			{"Draw Bystander Names", "Checkbox", false, 0},
			{"Highlight Murderer", "Checkbox", false, 0},
			{"Highlight armed Bystander", "Checkbox", false, 0},
			{"Hide End Round Board", "Checkbox", false, 0},
			{"Hide Footprints", "Checkbox", false, 0},
			{"Don't become Murderer", "Checkbox", false, 0},
			{"No Black Screens", "Checkbox", false, 0},
			{"Murderer Notification", "Checkbox", false, 0},
			{"Murderer Announcer", "Selection", "Off", {"Off", "Announce every round", "Spam"}, 125},
			{"Taunt Spam", "Selection", "Off", {"Off", "Funny", "Help", "Scream", "Morose", "Random"}, 125},
			{"Ignore Team", "Checkbox", false, 0},
		},
		{
			{"TTT", 445, 40, 350, 275, 175},
			{"Hide Round Report", "Checkbox", false, 0},
			{"Panel Remover", "Checkbox", false, 0},
			{"Prop Kill Key", "Selection", "Off", {"Off", "Mouse3", "Mouse4", "Mouse5", "L-ALT", "L-CTRL", "Shift", "Letter: E", "Letter: F", "Letter: Q", "Letter: G"}, 125},
			{"Highlight Detectives", "Checkbox", false, 0},
			{"Highlight Traitors", "Checkbox", false, 0},
			{"Draw Traitor Items", "Checkbox", false, 0},
			{"Traitor Finder", "Checkbox", false, 0},
			{"Traitor Announcer", "Checkbox", false, 0},
			{"Ignore Detectives as Innocent", "Checkbox", false, 0},
			{"Ignore fellow Traitors", "Checkbox", false, 0},
		},
		{
			{"DarkRP", 445, 330, 350, 90, 175},
			{"Suicide near Arrest Batons", "Checkbox", false, 0},
			{"Prop Transparency", "Slider", 0, 230, 125},
		},
	},]]
	["Settings"] = {
		{
			{"Primary Color", 50, 20, 250, 105, 130},
			{"Red", "Slider", 0, 255, 88},
			{"Green", "Slider", 125, 255, 88},
			{"Blue", "Slider", 255, 255, 88},
		},
		{
			{"Friend Color", 50, 145, 250, 105, 130},
			{"Red", "Slider", 140, 255, 88},
			{"Green", "Slider",45, 255, 88},
			{"Blue", "Slider", 255, 255, 88},
		},
		{
			{"NPC Color", 50, 270, 250, 105, 130},
			{"Red", "Slider", 200, 255, 88},
			{"Green", "Slider", 200, 255, 88},
			{"Blue", "Slider", 200, 255, 88},
		},
		{
			{"Admin Color", 320, 145, 250, 105, 130},
			{"Red", "Slider", 255, 255, 88},
			{"Green", "Slider", 0, 255, 88},
			{"Blue", "Slider", 0, 255, 88},
		},
		{
			{"Menu Color", 320, 20, 250, 105, 130},
			{"Red", "Slider", 0, 255, 88},
			{"Green", "Slider", 180, 255, 88},
			{"Blue", "Slider", 255, 255, 88},
		},
		{
			{"ESP Distance", 590, 20, 250, 105, 130},
			{"Enabled", "Checkbox", true, 0},
			{"Distance Limit", "Slider", 950, 1500, 88},
		},
		{
			{"Menu", 320, 270, 250, 105, 130},
			--{"Feature Information", "Checkbox", true, 0},
			--{"Sounds", "Checkbox", true, 0},
			{"Darkness", "Slider", 20, 25, 88},
			{"Death Popups", "Checkbox", true, 0},
		},
		--[[{
			{"Colors", 590, 395, 250, 105, 175},
			{"Primary Color", "Button", "", 80},
		},]]
	},
}

local order = {
	"Aimbot",
	"Triggerbot",
	"Hack vs Hack",
	"Visuals",
	"Misc",
	"Settings",
}

for k,v in next, order do
	visible[v] = false
end

--[[
	MISCELLANEOUS FUNCTIONS PT.2
]]

gameevent.Listen("entity_killed")
--gameevent.Listen("player_say")
--gameevent.Listen("player_connect")
--gameevent.Listen("player_disconnect")
gameevent.Listen("player_hurt")
--gameevent.Listen("player_spawn")

local function updatevar( men, sub, lookup, new )
	for aa,aaa in next, options[men] do
		for key, val in next, aaa do
			if aaa[1][1] ~= sub then
				continue
			end
			if val[1] == lookup then
				val[3] = new
			end
		end
	end
end

local function saveconfig1()
	file.Write(cheatname.."/free_config_1.txt", util.TableToJSON(options))
end

local function loadconfig1()
	if file.Exists(cheatname.."/free_config_1.txt", "DATA") then
		local tab = util.JSONToTable( file.Read(cheatname.."/free_config_1.txt", "DATA") )
		local cursub
		for k,v in next, tab do
			if not options[k] then continue end
			for men, subtab in next, v do
				for key, val in next, subtab do
					if key == 1 then
						cursub = val[1]
						continue
					end
					updatevar(k, cursub, val[1], val[3])
				end
			end
		end
	end
end

local function gBool(men, sub, lookup)
	if not options[men] then return end
	for aa,aaa in next, options[men] do
		for key, val in next, aaa do
			if aaa[1][1] ~= sub then
				continue
			end
			if val[1] == lookup then
				return val[3]
			end
		end
	end
end

local function gOption(men, sub, lookup)
	if not options[men] then return "" end
	for aa,aaa in next, options[men] do
		for key, val in next, aaa do
			if aaa[1][1] ~= sub then
				continue
			end
			if val[1] == lookup then
				return val[3]
			end
		end
	end
	return ""
end

local function gInt(men, sub, lookup)
	if not options[men] then return 0 end
	for aa,aaa in next, options[men] do
		for key, val in next, aaa do
			if aaa[1][1] ~= sub then
				continue
			end
			if val[1] == lookup then
				return val[3]
			end
		end
	end
	return 0
end

local function unload()
	if gui.IsGameUIVisible() then
		gui.HideGameUI()
	end

	for k, v in next, all_hooks do
		for _k, _v in next, v do
			hook.Remove(k, _k)
		end
	end

	saveconfig1()

	command("cl_interp 0; cl_interp_ratio 2; cl_updaterate 30")

	memesendpacket = true
	pwloaded = false

	msg(3, "Cheat unloaded successfully.")
end

local function MouseInArea(minx, miny, maxx, maxy)
	local mousex, mousey = gui.MousePos()
	return(mousex < maxx and mousex > minx and mousey < maxy and mousey > miny)
end

local function DrawOptions(self, w, h)
	local mx, my = self:GetPos()
	local sizeper = (w - 10) / #order
	local maxx = 0

	for k,v in next, order do
		local bMouse = MouseInArea(mx + 5 + maxx, my + 31, mx + 5 + maxx + sizeper, my + 31 + 30)
		if visible[v] then
			local curcol = Color(MenuCol.r, MenuCol.g, MenuCol.b, 25)
			for i = 0, 30 do
				surface.SetDrawColor(curcol)
				surface.DrawLine( 5 + maxx, 31 + i, 5 + maxx + sizeper, 31 + i)
			end
		elseif bMouse then
			local curcol = Color(255, 255, 255, 3)
			for i = 0, 30 do
				surface.SetDrawColor(curcol)
				curcol.r, curcol.g, curcol.b = curcol.r - 1.7, curcol.g - 1.7, curcol.b - 1.7
				surface.DrawLine( 5 + maxx, 31 + i, 5 + maxx + sizeper, 31 + i)
			end
		else
			local curcol = Color(0, 0, 0, 0)
			for i = 0, 30 do
				surface.SetDrawColor(curcol)
				curcol.r, curcol.g, curcol.b = curcol.r - 1.7, curcol.g - 1.7, curcol.b - 1.7
				surface.DrawLine( 5 + maxx, 31 + i, 5 + maxx + sizeper, 31 + i)
			end
		end
		if bMouse and input.IsMouseDown(MOUSE_LEFT) and not mousedown and not visible[v] then
			local nb = visible[v]
			for key,val in next, visible do
				visible[key] = false
			end
			visible[v] = not nb
		end

		surface.SetFont("Verdana")
		surface.SetTextColor(MenuCol.r, MenuCol.g, MenuCol.b, 215)
		local tw, th = surface.GetTextSize(v)
		surface.SetTextPos( 5 + maxx + sizeper / 2 - tw / 2, 31 + 15 - th / 2 )
		surface.DrawText(v)
		maxx = maxx + sizeper
	end
end

local function DrawCheckbox(self, w, h, var, maxy, posx, posy, dist)
	--[[local feat = var[1]
	local text = ""]]

	surface.SetFont("Verdana")
	surface.SetTextColor(MenuCol.r, MenuCol.g, MenuCol.b, 200)
	surface.SetTextPos( 5 + posx + 15 + 5, 61 + posy + maxy )
	local tw, th = surface.GetTextSize(var[1])
	surface.SetDrawColor(MenuCol.r, MenuCol.g, MenuCol.b, 200)
	local mx, my = self:GetPos()
	local bMouse = MouseInArea(mx + 5 + posx + 15 + 5, my + 61 + posy + maxy, mx + 5 + posx + 15 + 5 + dist + 14 + var[4], my + 61 + posy + maxy + 16)

	if bMouse then
		surface.SetTextColor(PrimaryCol.r, PrimaryCol.g, PrimaryCol.b, 200)
		surface.SetDrawColor(PrimaryCol.r, PrimaryCol.g, PrimaryCol.b, 200)

		if not input.IsMouseDown(MOUSE_LEFT) then
			surface.DrawRect( 5 + posx + 15 + 5 + dist + 2 + var[4], 61 + posy + maxy + 2, 10, 10)
		end
	end

	surface.DrawText(var[1])
	surface.DrawOutlinedRect( posx + 25 + dist + var[4], 61 + posy + maxy , 13, 13)

	if var[3] then
		surface.SetDrawColor(MenuCol.r-30,MenuCol.g-30,MenuCol.b-30, 100)
		surface.DrawRect( 5 + posx + 15 + 5 + dist + 2 + var[4], 61 + posy + maxy + 2, 10, 10)
		surface.SetDrawColor(MenuCol.r-10,MenuCol.g-10,MenuCol.b-10, 100)
		surface.DrawOutlinedRect( 5 + posx + 15 + 5 + dist + 2 + var[4], 61 + posy + maxy + 2, 10, 10)
	end

	if bMouse and input.IsMouseDown(MOUSE_LEFT) and not mousedown and not drawlast then
		var[3] = not var[3]
	end
end

local function DrawSlider(self, w, h, var, maxy, posx, posy, dist)
	local curnum = var[3]
	local max = var[4]
	local size = var[5]
	surface.SetFont("Verdana")
	surface.SetTextColor(MenuCol.r, MenuCol.g, MenuCol.b, 200)
	surface.SetTextPos( posx + 25, 61 + posy + maxy )
	surface.DrawText(var[1])
	local tw, th = surface.GetTextSize(var[1])
	surface.SetDrawColor(50, 50, 50, 255)
	surface.DrawRect( 5 + posx + 15 + 5 + dist, 61 + posy + maxy + 9, size, 2)
	surface.SetDrawColor(MenuCol.r, MenuCol.g, MenuCol.b, 150)
	surface.DrawRect( 5 + posx + 15 + 5 + dist, 61 + posy + maxy + 9, size, 2)
	local ww = math.ceil(curnum * size / max)
	surface.DrawRect( 3 + posx + 15 + 5 + dist + ww, 61 + posy + maxy + 9 - 5, 6, 12)
	surface.SetDrawColor(0,0,0)
	local tw, th = surface.GetTextSize(curnum)
	surface.DrawOutlinedRect( 3 + posx + 15 + 5 + dist + ww, 61 + posy + maxy + 4, 6, 12)
	surface.SetTextPos( posx + dist - (size/15), 48.7 + posy + maxy + 16)
	local mx, my = self:GetPos()
	local bMouse = MouseInArea(5 + posx + 15 + 5 + dist + mx, 61 + posy + maxy + 9 - 5 + my, 5 + posx + 15 + 5 + dist + mx + size, 61 + posy + maxy + 9 - 5 + my + 12)

	if bMouse and input.IsMouseDown(MOUSE_LEFT) and not drawlast and not candoslider then
		surface.SetTextColor(PrimaryCol.r, PrimaryCol.g, PrimaryCol.b, 200)

		local mw, mh = gui.MousePos()
		local new = math.ceil( ((mw - (mx + posx + 25 + dist - size)) - (size + 1)) / (size - 2) * max)
		var[3] = new

		if var[1] == "Aimbot FOV" then
			draw_fov = true
		end

		timer.Simple(5, function() draw_fov = false end)
	end

	surface.DrawText(curnum)
end

local function DrawSelect(self, w, h, var, maxy, posx, posy, dist)
	local size = var[5]
	local curopt = var[3]
	surface.SetFont("Verdana")
	surface.SetTextColor(MenuCol.r, MenuCol.g, MenuCol.b, 225)
	surface.SetTextPos( 5 + posx + 15 + 5, 61 + posy + maxy )
	local tw, th = surface.GetTextSize(var[1])
	surface.DrawText(var[1])
	surface.SetDrawColor(MenuCol.r, MenuCol.g, MenuCol.b, 125)
	surface.DrawOutlinedRect( 25 + posx + dist, 61 + posy + maxy, size, 16)
	local mx, my = self:GetPos()
	local bMouse = MouseInArea( mx + 25 + posx + dist, my + 61 + posy + maxy, mx + 25 + posx + dist + size, my + 61 + posy + maxy + 16)
	local check = dist..posy..posx..w..h..maxy

	if bMouse or notyetselected == check then
		surface.SetDrawColor(PrimaryCol.r, PrimaryCol.g, PrimaryCol.b, 125)
		surface.DrawRect(25 + posx + dist + 2, 61 + posy + maxy + 2, size - 4, 12)
	end

	local tw, th = surface.GetTextSize(curopt)
	surface.SetTextPos( 25 + posx + dist + 5, 61 + posy + maxy + 6 - th / 2 + 2)
	surface.DrawText(curopt)

	if bMouse and input.IsMouseDown(MOUSE_LEFT) and not drawlast and not mousedown or notyetselected == check then
		notyetselected = check

		drawlast = function()
			local maxy2 = 16
			for k,v in next, var[4] do
				surface.SetDrawColor(MenuCol.r-75, MenuCol.g-75, MenuCol.b-75, 225)
				surface.DrawRect( 25 + posx + dist, 61 + posy + maxy + maxy2, size, 16)
				local bMouse2 = MouseInArea( mx + 25 + posx + dist, my + 61 + posy + maxy + maxy2, mx + 25 + posx + dist + size, my + 61 + posy + maxy + 16 + maxy2)
				if bMouse2 then
					surface.SetDrawColor(MenuCol.r-50,MenuCol.g-50,MenuCol.b-50, 240)
					surface.DrawRect( 25 + posx + dist, 61 + posy + maxy + maxy2, size, 16)
				end
				if bMouse2 and input.IsMouseDown(MOUSE_LEFT) and not mousedown then
					var[3] = v
					notyetselected = nil
					drawlast = nil
					return
				end

				local tw, th = surface.GetTextSize(v)
				surface.SetTextPos( 25 + posx + dist + 5, 61 + posy + maxy + 6 - th / 2 + 2 + maxy2)
				surface.DrawText(v)
				maxy2 = maxy2 + 16
			end
			local bbMouse = MouseInArea( mx + 25 + posx + dist, my + 61 + posy + maxy, mx + 25 + posx + dist + size, my + 61 + posy + maxy + maxy2)
			if not bbMouse and input.IsMouseDown(MOUSE_LEFT) and not mousedown then
				notyetselected = nil
				drawlast = nil

				return
			end
		end
	end
end

local function DrawButton(self, w, h, var, maxy, posx, posy, dist)
	local text = var[1]
	local size = var[4]
	surface.SetFont("Verdana")
	surface.SetTextColor(MenuCol.r, MenuCol.g, MenuCol.b, 255)
	surface.SetDrawColor(MenuCol.r, MenuCol.g, MenuCol.b, 120)
	surface.DrawOutlinedRect(posx - 150 + dist, 61 + posy + maxy, size + 64, 16)
	local mx, my = self:GetPos()
	local bMouse = MouseInArea( mx - 150 + posx + dist, my + 61 + posy + maxy, mx - 150 + posx + dist + size + 64, my + 61 + posy + maxy + 16)
	local check = dist..posy..posx..w..h..maxy

	if bMouse or notyetselected == check then
		surface.SetDrawColor(PrimaryCol.r, PrimaryCol.g, PrimaryCol.b, 120)
		surface.DrawRect(posx - 150 + dist + 2, 61 + posy + maxy + 2, size + 60, 12)
	end

	local tw, th = surface.GetTextSize(text)
	surface.SetTextPos(posx - 150 + dist + 5, 61 + posy + maxy + 6 - th / 2 + 2)
	surface.DrawText(text)

	if bMouse and input.IsMouseDown(MOUSE_LEFT) and not drawlast and not mousedown or notyetselected == check then
		if text == "Unload "..cheatname then
			self:Remove()
			unload()
		elseif text == "List Staff" then
			for k,v in ipairs(player.GetAll()) do
				if not v:IsAdmin() then continue end

				chat.AddText(MenuCol, v:Nick(), Color(255,255,255), " - ", AdminCol, v:GetNWString("usergroup"))
			end
		elseif text == "Discord" then
			gui.OpenURL(discord)
		end
	end
end

local function DrawSubSub(self, w, h, k, var, info)
	local opt, posx, posy, sizex, sizey, dist = var[1][1], var[1][2], var[1][3], var[1][4], var[1][5], var[1][6]
	surface.SetDrawColor(MenuCol.r, MenuCol.g, MenuCol.b, 70)
	local startpos = 61 + posy
	surface.SetTextColor(MenuCol.r, MenuCol.g, MenuCol.b, 200)
	surface.SetFont("Verdana")
	local tw, th = surface.GetTextSize(opt)
	surface.DrawLine( 5 + posx, startpos, 5 + posx + 15, startpos)
	surface.SetTextPos( 5 + posx + 15 + 5, startpos - th / 2 )
	surface.DrawLine( 5 + posx + 15 + 5 + tw + 5, startpos, 5 + posx + sizex, startpos)
	surface.DrawLine( 5 + posx, startpos, 5 + posx, startpos + sizey)
	surface.DrawLine( 5 + posx, startpos + sizey, 5 + posx + sizex+1, startpos + sizey)
	surface.DrawLine( 5 + posx + sizex, startpos, 5 + posx + sizex, startpos + sizey)
	surface.DrawText(opt)
	local maxy = 15

	for k,v in next, var do
		if k == 1 then
			continue
		end
		if v[2] == "Checkbox" then
			DrawCheckbox(self, w, h, v, maxy, posx, posy, dist, info)
		elseif v[2] == "Slider" then
			DrawSlider(self, w, h, v, maxy, posx, posy, dist)
		elseif v[2] == "Selection" then
			DrawSelect(self, w, h, v, maxy, posx, posy, dist, info)
		elseif v[2] == "Button" then
			DrawButton(self, w, h, v, maxy, posx, posy, dist)
		end
		maxy = maxy + 25
	end
end

local function DrawSub(self, w, h, info)
	for k, v in next, visible do
		if not v then
			continue
		end
		for _, var in next, options[k] do
			DrawSubSub(self, w, h, k, var, info)
		end
	end
end

local function config_colors()
	if not loaded1 then
		loadconfig1()
		loaded1 = true
	end

	PrimaryCol = Color(gInt("Settings", "Primary Color", "Red"), gInt("Settings", "Primary Color", "Green"), gInt("Settings", "Primary Color", "Blue"))
	FriendCol = Color(gInt("Settings", "Friend Color", "Red"), gInt("Settings", "Friend Color", "Green"), gInt("Settings", "Friend Color", "Blue"))
	NpcCol = Color(gInt("Settings", "NPC Color", "Red"), gInt("Settings", "NPC Color", "Green"), gInt("Settings", "NPC Color", "Blue"))
	AdminCol = Color(gInt("Settings", "Admin Color", "Red"), gInt("Settings", "Admin Color", "Green"), gInt("Settings", "Admin Color", "Blue"))
	MenuCol = Color(gInt("Settings", "Menu Color", "Red"), gInt("Settings", "Menu Color", "Green"), gInt("Settings", "Menu Color", "Blue"))
end

local function menu()
	local frame = vgui.Create("DFrame")
	frame:SetSize(900, 700)
	--frame:SetPos(menu_posx, menu_posy)
	frame:Center()
	frame:SetTitle("")
	frame:MakePopup()
	frame:ShowCloseButton(false)
	
	frame.Paint = function(self, w, h)
		if candoslider and not mousedown and not drawlast and not input.IsMouseDown(MOUSE_LEFT) then
			candoslider = false
		end

		surface.SetDrawColor(40, 40, 40, 240)
		surface.DrawRect(0, 0, w, h)
		surface.SetDrawColor(MenuCol.r, MenuCol.g, MenuCol.b, 25)
		surface.DrawRect(5, 5, w-10, 20)

		draw.SimpleText(cheatname.." v"..version.." - Registered to: Trial", "Verdana", w/2, 15, MenuCol, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		draw.SimpleText("by Crave4", "Verdana", 20, h-20, Color(MenuCol.r,MenuCol.g,MenuCol.b,10), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)

		DrawOptions(self, w, h)
		DrawSub(self, w, h, info)

		if drawlast then
			drawlast()
			candoslider = true
		end

		mousedown = input.IsMouseDown(MOUSE_LEFT)
	end
	
	frame.Think = function()
		if ((input.IsKeyDown(KEY_INSERT) or input.IsKeyDown(KEY_F11) or input.IsKeyDown(KEY_HOME)) and not insertdown2) then
			frame:Remove()
			menuopen = false
			candoslider = false
			drawlast = nil

			saveconfig1()
		end

		config_colors()
	end
end

local function tpcheck()
	if gui.IsGameUIVisible() or me:IsTyping() then return false end
	
	if gBool("Visuals", "ESP", "Enabled") then
		if gOption("Visuals", "Other", "Third Person") == "Mouse3" then
			if input.IsMouseDown(109) and not tppressed then
				tppressed = true
				tptoggle = not tptoggle
			elseif not input.IsMouseDown(109) and tppressed then
				tppressed = false
			end
		elseif gOption("Visuals", "Other", "Third Person") == "Mouse4" then
			if input.IsMouseDown(110) and not tppressed then
				tppressed = true
				tptoggle = not tptoggle
			elseif not input.IsMouseDown(110) and tppressed then
				tppressed = false
			end
		elseif gOption("Visuals", "Other", "Third Person") == "Mouse5" then
			if input.IsMouseDown(111) and not tppressed then
				tppressed = true
				tptoggle = not tptoggle
			elseif not input.IsMouseDown(111) and tppressed then
				tppressed = false
			end
		elseif gOption("Visuals", "Other", "Third Person") == "L-ALT" then
			if input.IsKeyDown(81) and not tppressed then
				tppressed = true
				tptoggle = not tptoggle
			elseif not input.IsKeyDown(81) and tppressed then
				tppressed = false
			end
		elseif gOption("Visuals", "Other", "Third Person") == "L-CTRL" then
			if input.IsKeyDown(83) and not tppressed then
				tppressed = true
				tptoggle = not tptoggle
			elseif not input.IsKeyDown(83) and tppressed then
				tppressed = false
			end
		elseif gOption("Visuals", "Other", "Third Person") == "Shift" then
			if input.IsKeyDown(79) and not tppressed then
				tppressed = true
				tptoggle = not tptoggle
			elseif not input.IsKeyDown(79) and tppressed then
				tppressed = false
			end
		elseif gOption("Visuals", "Other", "Third Person") == "Letter: E" then
			if input.IsKeyDown(15) and not tppressed then
				tppressed = true
				tptoggle = not tptoggle
			elseif not input.IsKeyDown(15) and tppressed then
				tppressed = false
			end
		elseif gOption("Visuals", "Other", "Third Person") == "Letter: R" then
			if input.IsKeyDown(28) and not tppressed then
				tppressed = true
				tptoggle = not tptoggle
			elseif not input.IsKeyDown(28) and tppressed then
				tppressed = false
			end
		elseif gOption("Visuals", "Other", "Third Person") == "Letter: F" then
			if input.IsKeyDown(16) and not tppressed then
				tppressed = true
				tptoggle = not tptoggle
			elseif not input.IsKeyDown(16) and tppressed then
				tppressed = false
			end
		elseif gOption("Visuals", "Other", "Third Person") == "Letter: Q" then
			if input.IsKeyDown(27) and not tppressed then
				tppressed = true
				tptoggle = not tptoggle
			elseif not input.IsKeyDown(27) and tppressed then
				tppressed = false
			end
		elseif gOption("Visuals", "Other", "Third Person") == "Letter: G" then
			if input.IsKeyDown(17) and not tppressed then
				tppressed = true
				tptoggle = not tptoggle
			elseif not input.IsKeyDown(17) and tppressed then
				tppressed = false
			end
		elseif gOption("Visuals", "Other", "Third Person") == "On" then
			return true
		else
			return false
		end
	end

	if tptoggle then
		return true
	else
		return false
	end
end

local function drawlocalp(v)
	if not tpcheck() then return v == me end

	if not gBool("Visuals", "ESP", "Draw Local Player") then
		return v == me
	end
end

local function filter(v)
	if gOption("Visuals", "ESP", "Draw Mode") == "Players only" then
		return v:IsPlayer()
	elseif gOption("Visuals", "ESP", "Draw Mode") == "NPCs only" then
		return v:IsNPC()
	elseif gOption("Visuals", "ESP", "Draw Mode") == "Both" then
		return v:IsPlayer() or v:IsNPC()
	else
		return nil
	end
end

local function maxdist(v)
	if gBool("Settings", "ESP Distance", "Enabled") and gInt("Settings", "ESP Distance", "Distance Limit") ~= 0 then
		if v:GetPos():Distance(me:GetPos()) > gInt("Settings", "ESP Distance", "Distance Limit")*3.2 then
			if v:IsPlayer() and gBool("Visuals", "ESP", "Highlight Friends") and v:GetFriendStatus() ~= "friend" then
				return false
			else
				return false
			end
		end
	end

	if v:GetPos():Distance(me:GetPos()) < 30 and not (tpcheck() and gBool("Visuals", "ESP", "Draw Local Player")) then
		return false
	else
		return true
	end
end

local function onscreen(v)
	if math.abs(v:LocalToWorld(v:OBBCenter()):ToScreen().x) < ScrW()*5 and math.abs(v:LocalToWorld(v:OBBCenter()):ToScreen().y) < ScrH()*5 then
		return true
	else
		return false
	end
end

local function WeaponCanFire()
	local w = me:GetActiveWeapon()

	if not w or not w:IsValid() then
		return true
	else
		if w:IsValid() then
			if string.find(string.lower(w:GetPrintName()),"knife") or string.find(string.lower(w:GetPrintName()),"sword") or string.find(string.lower(w:GetPrintName()),"fist") or string.find(string.lower(w:GetPrintName()),"crowbar") then
				return true
			else
				return servertime >= w:GetNextPrimaryFire()
			end
		end
	end
end

local function WeaponShootable()
	if me:Alive() and wep:IsValid() then
		if string.find(string.lower(wep:GetPrintName()),"knife") or string.find(string.lower(wep:GetPrintName()),"sword") or string.find(string.lower(wep:GetPrintName()),"fist") or string.find(string.lower(wep:GetPrintName()),"crowbar") then
			return true
		else
			if wep:Clip1() <= 0 then
				return
			end
			if string.find(string.lower(wep:GetPrintName()),"knife") or string.find(string.lower(wep:GetPrintName()),"gas") or string.find(string.lower(wep:GetPrintName()),"grenade") or string.find(string.lower(wep:GetPrintName()),"sword") or string.find(string.lower(wep:GetPrintName()),"machete") or string.find(string.lower(wep:GetPrintName()),"bomb") or string.find(string.lower(wep:GetPrintName()),"ied") or string.find(string.lower(wep:GetPrintName()),"c4") or string.find(string.lower(wep:GetPrintName()),"slam") or string.find(string.lower(wep:GetPrintName()),"climb") or string.find(string.lower(wep:GetPrintName()),"fist") or string.find(string.lower(wep:GetPrintName()),"gravitygun") then
				return false
			end
		end
		return true
	end
end

local function GetPos(v)
	if not v:IsValid() then return end

	if gOption("Aimbot", "Other", "Aim Position") == "Body only" then
		return v:LocalToWorld(v:OBBCenter())
	end

	--local head = v:LookupBone("ValveBiped.Bip01_Spine")
	local head = v:LookupAttachment("eyes")
	local pos = v:GetAttachment(head)

	local trace = { start = me:GetPos(), endpos = v:GetPos(), mask = MASK_PLAYERSOLID }
	local trace = util.TraceLine(trace)
	local height = (me:GetPos() - trace.HitPos).z

	if gOption("Aimbot", "Other", "Aim Position") == "Head only" then
		if v:IsPlayer() then
			if not head then
				return v:LocalToWorld(v:OBBCenter())
			end

			if not pos then
				return v:LocalToWorld(v:OBBCenter())
			end
		else
			if not head then
				return v:LocalToWorld(v:OBBCenter() - Vector(0,0,1))
			end

			if not pos then
				return v:LocalToWorld(v:OBBCenter() - Vector(0,0,1))
			end
		end

		if not (height > -300) then
			return pos.Pos + Vector(0,0,6)
		else
			return pos.Pos
		end
	end
end

local function aimkeycheck()
	if gui.IsGameUIVisible() or me:IsTyping() or not me:GetActiveWeapon():IsValid() then return false end
	
	if gBool("Aimbot", "Aimbot", "Enabled") then
		if gOption("Aimbot", "Aimbot", "Aim Key") == "Mouse3" then
			if input.IsMouseDown(109) then return true end
		elseif gOption("Aimbot", "Aimbot", "Aim Key") == "Mouse4" then
			if input.IsMouseDown(110) then return true end
		elseif gOption("Aimbot", "Aimbot", "Aim Key") == "Mouse5" then
			if input.IsMouseDown(111) then return true end
		elseif gOption("Aimbot", "Aimbot", "Aim Key") == "L-ALT" then
			if input.IsKeyDown(81) then return true end
		elseif gOption("Aimbot", "Aimbot", "Aim Key") == "L-CTRL" then
			if input.IsKeyDown(83) then return true end
		elseif gOption("Aimbot", "Aimbot", "Aim Key") == "Shift" then
			if input.IsKeyDown(79) then return true end
		elseif gOption("Aimbot", "Aimbot", "Aim Key") == "Letter: E" then
			if input.IsKeyDown(15) then return true end
		elseif gOption("Aimbot", "Aimbot", "Aim Key") == "Letter: F" then
			if input.IsKeyDown(16) then return true end
		elseif gOption("Aimbot", "Aimbot", "Aim Key") == "Letter: Q" then
			if input.IsKeyDown(27) then return true end
		elseif gOption("Aimbot", "Aimbot", "Aim Key") == "None" then
			return true
		end
	end
end

local function triggerkeycheck()
	if gui.IsGameUIVisible() or me:IsTyping() or not me:GetActiveWeapon():IsValid() then return false end

	if gBool("Triggerbot", "Triggerbot", "Enabled") then
		if gOption("Triggerbot", "Triggerbot", "Trigger Key") == "Mouse3" then
			if input.IsMouseDown(109) then return true end
		elseif gOption("Triggerbot", "Triggerbot", "Trigger Key") == "Mouse4" then
			if input.IsMouseDown(110) then return true end
		elseif gOption("Triggerbot", "Triggerbot", "Trigger Key") == "Mouse5" then
			if input.IsMouseDown(111) then return true end
		elseif gOption("Triggerbot", "Triggerbot", "Trigger Key") == "L-ALT" then
			if input.IsKeyDown(81) then return true end
		elseif gOption("Triggerbot", "Triggerbot", "Trigger Key") == "L-CTRL" then
			if input.IsKeyDown(83) then return true end
		elseif gOption("Triggerbot", "Triggerbot", "Trigger Key") == "Shift" then
			if input.IsKeyDown(79) then return true end
		elseif gOption("Triggerbot", "Triggerbot", "Trigger Key") == "Letter: E" then
			if input.IsKeyDown(15) then return true end
		elseif gOption("Triggerbot", "Triggerbot", "Trigger Key") == "Letter: F" then
			if input.IsKeyDown(16) then return true end
		elseif gOption("Triggerbot", "Triggerbot", "Trigger Key") == "Letter: Q" then
			if input.IsKeyDown(27) then return true end
		elseif gOption("Triggerbot", "Triggerbot", "Trigger Key") == "None" then
			return true
		end
	end
end

local function esp_col(v)
	if v:IsPlayer() then
		if v == me then return MenuCol end

		if gBool("Visuals", "ESP", "Highlight Aim Target") and v == aimtarget and aimtarget:IsValid() and aimkeycheck() and WeaponShootable() then
			return AimCol
		--[[if v:SteamID64() == highlighted1 or v:SteamID64() == highlighted2 or v:SteamID64() == highlighted3 or v:SteamID64() == highlighted4 then
			return HighlightCol
		else]]elseif gBool("Visuals", "ESP", "Highlight Friends") and v:GetFriendStatus() == "friend" then
			return FriendCol
		elseif gBool("Visuals", "ESP", "Highlight Admins") and v:IsAdmin() and not (v:GetFriendStatus() == "friend" and gBool("Visuals", "ESP", "Highlight Friends")) then
			return AdminCol
		else
			if gBool("Visuals", "Other", "Team Colors") then
				return team.GetColor(v)
			else
				return PrimaryCol
			end
		end
	elseif v:IsNPC() then
		return NpcCol
	else
		return PrimaryCol
	end
end

local function esp()
	for k, v in next, ents.GetAll() do

		if v:IsDormant() or not v:IsValid() then continue end
		if v:IsPlayer() and (v:Team() == TEAM_SPECTATOR or v:Team() == TEAM_CONNECTING) then continue end

		-- some premium features used to be here

		if not maxdist(v) or not onscreen(v) or drawlocalp(v) then continue end

		-- some premium features used to be here

		if v:Health() < 1 or not filter(v) then continue end

		texty1 = 5

		x1, y1, x2, y2 = ScrW() * 2, ScrH() * 2, -ScrW(), -ScrH()
		min, max = v:GetCollisionBounds()
		corners = { v:LocalToWorld(Vector(min.x, min.y, min.z)):ToScreen(), v:LocalToWorld(Vector(min.x, max.y, min.z)):ToScreen(), v:LocalToWorld(Vector(max.x, max.y, min.z)):ToScreen(), v:LocalToWorld(Vector(max.x, min.y, min.z)):ToScreen(), v:LocalToWorld(Vector(min.x, min.y, max.z)):ToScreen(), v:LocalToWorld(Vector(min.x, max.y, max.z)):ToScreen(), v:LocalToWorld(Vector(max.x, max.y, max.z)):ToScreen(), v:LocalToWorld(Vector(max.x, min.y, max.z)):ToScreen() }
	
		for _k, _v in next, corners do
			x1, y1 = math.min(x1, _v.x), math.min(y1, _v.y)
			x2, y2 = math.max(x2, _v.x), math.max(y2, _v.y)
		end
		
		diff, diff2 = math.abs(x2 - x1), math.abs(y2 - y1)

		if gOption("Visuals", "ESP", "Box") ~= "Off" then
			if gOption("Visuals", "ESP", "Box") == "2D (Outlined)" then
				surface.SetDrawColor(0,0,0)
				surface.DrawOutlinedRect(x1 - 1, y1 - 1, diff + 2, diff2 + 2)
				surface.DrawOutlinedRect(x1 + 1, y1 + 1, diff - 2, diff2 - 2)
				surface.SetDrawColor(esp_col(v))
				surface.DrawOutlinedRect(x1, y1, diff, diff2)
			elseif gOption("Visuals", "ESP", "Box") == "2D (Semi-Solid)" then
				surface.SetDrawColor(0,0,0)
				surface.DrawOutlinedRect(x1 - 1, y1 - 1, diff + 2, diff2 + 2)
				--surface.DrawOutlinedRect(x1 + 1, y1 + 1, diff - 2, diff2 - 2)
				surface.SetDrawColor(esp_col(v))
				surface.DrawOutlinedRect(x1, y1, diff, diff2)
			elseif gOption("Visuals", "ESP", "Box") == "2D (Solid)" then
				surface.SetDrawColor(esp_col(v))
		
				--surface.DrawOutlinedRect(x1 - 1, y1 - 1, diff + 2, diff2 + 2)
				surface.DrawOutlinedRect(x1, y1, diff, diff2)
			elseif gOption("Visuals", "ESP", "Box") == "3D" then
				for i = 1, 4 do
					surface.SetDrawColor(esp_col(v))
					surface.DrawLine(corners[i].x, corners[i].y, corners[i + 4].x, corners[i + 4].y)
					surface.DrawLine(corners[i].x, corners[i].y, corners[i % 4 + 1].x, corners[i % 4 + 1].y)
					surface.DrawLine(corners[i + 4].x, corners[i + 4].y, corners[i % 4 + 5].x, corners[i % 4 + 5].y)
				end
			else
				surface.SetDrawColor(0,0,0)
				surface.DrawLine(x1,y1,x1+(diff*0.225),y1)
				surface.DrawLine(x1,y1,x1,y1+(diff2*0.225))
				surface.DrawLine(x1,y2,x1+(diff*0.225),y2)
				surface.DrawLine(x1,y2,x1,y2-(diff2*0.225))
				surface.DrawLine(x2,y1,x2-(diff*0.225),y1)
				surface.DrawLine(x2,y1,x2,y1+(diff2*0.225))
				surface.DrawLine(x2,y2,x2-(diff*0.225),y2)
				surface.DrawLine(x2,y2,x2,y2-(diff2*0.225))

				surface.SetDrawColor(esp_col(v))
				surface.DrawLine(x1+1,y1+1,x1+(diff*0.225),y1+1)
				surface.DrawLine(x1+1,y1+1,x1+1,y1+(diff2*0.225))
				surface.DrawLine(x1+1,y2-1,x1+(diff*0.225),y2-1)
				surface.DrawLine(x1+1,y2-1,x1+1,y2-(diff2*0.225))
				surface.DrawLine(x2-1,y1+1,x2-(diff*0.225),y1+1)
				surface.DrawLine(x2-1,y1+1,x2-1,y1+(diff2*0.225))
				surface.DrawLine(x2-1,y2-1,x2-(diff*0.225),y2-1)
				surface.DrawLine(x2-1,y2-1,x2-1,y2-(diff2*0.225))
			end
		end

		if gBool("Visuals", "ESP", "Bones") then
			for i = 0, v:GetBoneCount() do
				local parent = v:GetBoneParent(i)
				if not v:GetBoneParent(i) then continue end
				local bonepos = v:GetBonePosition(i)
				if v:GetBonePosition(i) == v:GetPos() then continue end
				local parentpos = v:GetBonePosition(v:GetBoneParent(i))
				if not v:GetBonePosition(i) or not v:GetBonePosition(v:GetBoneParent(i)) then continue end
				local screen1, screen2 = bonepos:ToScreen(), parentpos:ToScreen()

				surface.SetDrawColor(esp_col(v))
				surface.DrawLine(screen1.x, screen1.y, screen2.x, screen2.y)
			end
		end

		if gBool("Visuals", "ESP", "Names") then
			if v:IsPlayer() then
				draw.SimpleText(v:Nick(), "Verdana", x2 + 2, y1 + texty1, esp_col(v), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
			else
				draw.SimpleText(v:GetClass(), "Verdana", x2 + 2, y1 + texty1, esp_col(v), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
			end

			texty1 = texty1 + 12
		end

		if gOption("Visuals", "ESP", "Health") ~= "Off" then
			if gOption("Visuals", "ESP", "Health") == "Value only" then
				draw.SimpleText(v:Health().." HP", "Verdana", x2 + 2, y1 + texty1, Color(255 - 255 / v:GetMaxHealth() * v:Health(), 255 / v:GetMaxHealth() * v:Health(), 0), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
				texty1 = texty1 + 12
			elseif gOption("Visuals", "ESP", "Health") == "Bar only" then
				surface.SetDrawColor(0,0,0)
				surface.DrawRect(x1 - 6, y1, 3, diff2)
				surface.DrawRect(x1 - 7, y1 - 1, 5, diff2 + 2)

				surface.SetDrawColor(Color(255 - 255 / v:GetMaxHealth() * v:Health(), 255 / v:GetMaxHealth() * v:Health(), 0))
				surface.DrawRect(x1 - 6, y2 - math.Clamp(diff2 / v:GetMaxHealth() * v:Health(), 0, diff2), 3, math.Clamp(diff2 / v:GetMaxHealth() * v:Health(), 0, diff2))
			else
				draw.SimpleText(v:Health().." HP", "Verdana", x2 + 2, y1 + texty1, Color(255 - 255 / v:GetMaxHealth() * v:Health(), 255 / v:GetMaxHealth() * v:Health(), 0), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
				texty1 = texty1 + 12

				surface.SetDrawColor(0,0,0)
				surface.DrawRect(x1 - 6, y1, 3, diff2)
				surface.DrawRect(x1 - 7, y1 - 1, 5, diff2 + 2)

				surface.SetDrawColor(Color(255 - 255 / v:GetMaxHealth() * v:Health(), 255 / v:GetMaxHealth() * v:Health(), 0))
				surface.DrawRect(x1 - 6, y2 - math.Clamp(diff2 / v:GetMaxHealth() * v:Health(), 0, diff2), 3, math.Clamp(diff2 / v:GetMaxHealth() * v:Health(), 0, diff2))
			end
		end

		if gOption("Visuals", "ESP", "Lines") ~= "Off" then
			local pos = v:LocalToWorld(v:OBBCenter()):ToScreen()
			surface.SetDrawColor(esp_col(v))

			if gBool("Visuals", "ESP", "Lines") == "Bottom" then
				surface.DrawLine(ScrW() / 2, ScrH(), pos.x, pos.y)
			elseif gBool("Visuals", "ESP", "Lines") == "Top" then
				surface.DrawLine(ScrW() / 2, 0, pos.x, pos.y)
			else
				surface.DrawLine(ScrW() / 2, ScrH()/2, pos.x, pos.y)
			end
		end
	end
end

local function aimfov()
	local center = Vector(ScrW()/2, ScrH()/2, 0)
	local scale = Vector(gInt("Aimbot","Aimbot","Aimbot FOV")*11.8, gInt("Aimbot","Aimbot","Aimbot FOV")*11.8, 0)
	local segmentdist = 360 / (2 * math.pi * math.max(scale.x, scale.y)/2)

	surface.SetDrawColor(MenuCol)

	for a = 0, 360 - segmentdist, segmentdist do
		surface.DrawLine(center.x + math.cos( math.rad( a ) ) * scale.x, center.y - math.sin( math.rad( a ) ) * scale.y, center.x + math.cos( math.rad( a + segmentdist ) ) * scale.x, center.y - math.sin( math.rad( a + segmentdist ) ) * scale.y)
	end
end

local function radar()
	local radar_size, radar_scale = ScrH()/10 + gInt("Visuals", "Radar", "Size"), 10 + gInt("Visuals", "Radar", "Distance") + me:GetVelocity():Length()/35--, gInt("Visuals", "Radar", "X-Position"), gInt("Visuals", "Radar", "Y-Position")
	local radar_x, radar_y = ScrW()/20, ScrH()/20

	local ang

	if me:Alive() then
		ang = math.rad(fa.y - 90)
	else
		ang = math.rad(me:EyeAngles().y - 90)
	end

	local cpos = me:GetPos()
	local cos, sin = math.cos(ang), math.sin(ang)

	-- Old: local ang = math.rad(me:EyeAngles().y - 90)

	local radar_center_x = radar_x + radar_size * 0.5
	local radar_center_y = radar_y + radar_size * 0.5

	surface.SetDrawColor(40, 40, 40, 225)
	surface.DrawRect(radar_x-1, radar_y-1, radar_size+2, radar_size+2) -- Background

	--[[surface.SetDrawColor(0,0,0)
	surface.DrawOutlinedRect(radar_x-1, radar_y-1, radar_size+2, radar_size+2) -- Outline  ]]

	surface.SetDrawColor(MenuCol)
	surface.DrawOutlinedRect(radar_x, radar_y, radar_size, radar_size) -- Outline
	surface.DrawLine(radar_center_x, radar_y, radar_center_x, radar_y + radar_size - 1) -- Y Axis
	surface.DrawLine(radar_x, radar_center_y, radar_x + radar_size - 1, radar_center_y) -- X Axis

	--[[surface.DrawOutlinedRect(radar_x+radar_size/2.5+me:GetVelocity():Length()/35, radar_y+radar_size/2.5+me:GetVelocity():Length()/35, radar_size/5-me:GetVelocity():Length()/35*2, radar_size/5-me:GetVelocity():Length()/35*2)
	surface.DrawOutlinedRect(radar_x+radar_size/3+me:GetVelocity():Length()/35, radar_y+radar_size/3+me:GetVelocity():Length()/35, radar_size/3-me:GetVelocity():Length()/35*2, radar_size/3-me:GetVelocity():Length()/35*2)
	surface.DrawOutlinedRect(radar_x+radar_size/3.5+me:GetVelocity():Length()/35, radar_y+radar_size/3.5+me:GetVelocity():Length()/35, radar_size/2.3-me:GetVelocity():Length()/35*2, radar_size/2.3-me:GetVelocity():Length()/35*2)]]

	render.SetScissorRect(radar_x + 1, radar_y + 1, radar_x + radar_size - 1, radar_y + radar_size - 1, true)

	for k,v in next, ents.GetAll() do
		if v == me or v:IsDormant() or not v:IsValid() or not maxdist(v) or v:Health() < 1 or not filter(v) then continue end
		if v:IsPlayer() and (v:Team() == TEAM_SPECTATOR or v:Team() == TEAM_CONNECTING) then continue end

		local pos = cpos - v:GetPos()
		pos.x = pos.x / radar_scale
		pos.y = pos.y / radar_scale

		local transx, transy = radar_center_x - pos.x, radar_center_y + pos.y
		local dx, dy = transx - radar_center_x, transy - radar_center_y

		transx = radar_center_x + (dx * cos - dy * sin) - 2
		transy = radar_center_y + (dx * sin + dy * cos) - 2

		surface.SetDrawColor(esp_col(v))
		surface.DrawRect(transx - 3, transy - 3, 12, 12)
		surface.SetDrawColor(0,0,0)
		surface.DrawOutlinedRect(transx - 3, transy - 3, 12, 12)
	end

	render.SetScissorRect(0, 0, 0, 0, false)
end

local function nophys()
	if gBool("Hack vs Hack", "Anti-Aim", "Enabled") or not me:Alive() or me:Health() < 1 then
		return false
	end

	if me:GetActiveWeapon():IsValid() and me:GetActiveWeapon():GetClass() == "weapon_physgun" then
		return true
	else
		return false
	end
end

local function FixMovement(cmd)
	-- NOT NEEDED -- if me:GetActiveWeapon():GetClass() == "weapon_zm_carry" then return end
	
	local vec = Vector(cmd:GetForwardMove(), cmd:GetSideMove(), 0)
	local vel = math.sqrt(vec.x*vec.x + vec.y*vec.y)
	local mang = vec:Angle()
	local yaw = cmd:GetViewAngles().y - fa.y + mang.y

	if ((cmd:GetViewAngles().p+90)%360) > 180 then
		yaw = 180 - yaw
	end

	yaw = ((yaw + 180)%360)-180
	cmd:SetForwardMove(math.cos(math.rad(yaw)) * vel)
	cmd:SetSideMove(math.sin(math.rad(yaw)) * vel)
end

--[[local function Clamp(val, min, max)
	if val < min then
		return min
	elseif val > max then
		return max
	end
	return val
end]]

local function NormalizeAngle(ang)
	if not nophys() then
		ang.x = math.NormalizeAngle(ang.x)
		ang.p = math.Clamp(ang.p, -89, 89)
	end
end

local function aim_filter(v)
	if not gBool("Aimbot", "Other", "Ignore Players") and gBool("Aimbot", "Other", "Ignore NPCs") then
		return v:IsPlayer()
	elseif not gBool("Aimbot", "Other", "Ignore NPCs") and gBool("Aimbot", "Other", "Ignore Players") then
		return v:IsNPC()
	elseif not gBool("Aimbot", "Other", "Ignore Players") and not gBool("Aimbot", "Other", "Ignore NPCs") then
		return v:IsPlayer() or v:IsNPC()
	else
		return nil
	end
end

local function trigger_filter(v)
	if not gBool("Triggerbot", "Other", "Ignore Players") and gBool("Triggerbot", "Other", "Ignore NPCs") then
		return v:IsPlayer()
	elseif not gBool("Triggerbot", "Other", "Ignore NPCs") and gBool("Triggerbot", "Other", "Ignore Players") then
		return v:IsNPC()
	elseif not gBool("Triggerbot", "Other", "Ignore Players") and not gBool("Triggerbot", "Other", "Ignore NPCs") then
		return v:IsPlayer() or v:IsNPC()
	else
		return nil
	end
end

local function Valid(v, type)
	if not v or not v:IsValid() or v == me or v:Health() < 1 or v:IsDormant() then return false end

	if type == "aimbot" or type == "antiaim" then
		if not aim_filter(v) then return false end
	elseif type == "triggerbot" then
		if not trigger_filter(v) then return false end
	else
		print("\n Error validating target. Report to the developer.\n")
		return false
	end

	if v:IsPlayer() then
		if gBool("Aimbot", "Other", "Ignore Friends") then
			if v:GetFriendStatus() == "friend" or v:SteamID64() == "76561197972182214" then return false end
		end

		if gBool("Aimbot", "Other", "Ignore Bots") then
			if v:IsBot() then return false end
		end

		if gBool("Aimbot", "Other", "Ignore Admins") then
			if v:IsAdmin() then return false end
		end

		if gBool("Aimbot", "Other", "Ignore driving Players") then
			if v:InVehicle() then return false end
		end

		if gBool("Aimbot", "Other", "Ignore noclipping Players") then
			if v:GetMoveType(v) == MOVETYPE_NOCLIP then return false end
		end

		if gBool("Aimbot", "Other", "Ignore transparent Players") then
			if v:GetColor().a < 255 then return false end
		end

		if v:Team() == TEAM_SPECTATOR or v:Team() == TEAM_CONNECTING then
			return false
		end

		if gBool("Aimbot", "Other", "Ignore Team") or gBool("Gamemode", "Murder", "Ignore Team") then
			if gBool("Aimbot", "Other", "Ignore Team") then
				if v:Team() == me:Team() and engine.ActiveGamemode() ~= "sandbox" then
					return false
				elseif v:Team() == me:Team() and engine.ActiveGamemode() ~= "darkrp" then
					return false
				end
			end
		end
	end

	if type ~= "antiaim" then
		if wep:IsValid() then
			local wepname = wep:GetPrintName()
			
			if wep:Clip1() <= 0 then
				return
			end
		end

		local tr = { start = me:EyePos(), endpos = GetPos(v), mask = MASK_SHOT, filter = {me, v} }

		if util.TraceLine(tr).Fraction == 1 then
			return true
		--[[elseif wep and wep:IsValid() and wep.PenStr then
			return fasAutowall(wep, tr.start, tr.endpos, v)
		elseif wep and wep:IsValid() and wep.BulletPenetrate then
			return m9kAutowall(wep, tr.start, tr.endpos, v)]]
		end

		return false
	else
		return true
	end
end

local function check_alive(v)
	if v:IsValid() then
		if v:IsPlayer() then
			return v:Alive()
		else
			return v:Health() > 0
		end
	end
end

local function gettarget()
	if gOption("Aimbot", "Other", "Priority") == "Nearest" then
		dists = {}
		for k,v in next, ents.GetAll() do
			if not Valid(v, "aimbot") then continue end
			dists[#dists + 1] = { v:GetPos():Distance(me:GetPos()), v }
		end
		table.sort(dists, function(a, b)
			return(a[1] < b[1])
		end)
		aimtarget = dists[1] and dists[1][2] or nil
	elseif gOption("Aimbot", "Other", "Priority") == "Lowest Health" then
		dists = {}
		for k,v in next, ents.GetAll() do
			if not Valid(v, "aimbot") then continue end
			dists[#dists + 1] = { v:Health(), v }
		end
		table.sort(dists, function(a, b)
			return(a[1] < b[1])
		end)
		aimtarget = dists[1] and dists[1][2] or nil
	else
		dists = {}
		for k,v in next, ents.GetAll() do
			if not Valid(v, "aimbot") then continue end
			--dists[#dists + 1] = { v:GetPos():Distance(me:GetEyeTrace().HitPos), v }
			aimtarget = dists[1] and dists[1][2] or nil
			dists[#dists + 1] = { math.Dist(ScrW() / 2, ScrH() / 2, v:EyePos():ToScreen().x, v:EyePos():ToScreen().y), v }
		end
		table.sort(dists, function(a, b)
			return(a[1] < b[1])
		end)
		aimtarget = dists[1] and dists[1][2] or nil
	end
end

local function fakelag(cmd, choke, send)
	if gBool("Misc", "Fake Lag", "Disable on Attack") and me:KeyDown(IN_ATTACK) then
		return
	end

	if cmd:CommandNumber() == 0 then
		return true
	end

	if not Choke then
		choke = gInt("Misc", "Fake Lag", "Density") + 0.7
	end

	if not Send then
		send = 0
	end

	faketick = faketick + 1

	if faketick > (choke + send) then
		faketick = 0
	end

	if not (send >= faketick) then
		memesendpacket = false
	end

	flsend = send

	return true
end

local function PredictPos(pos)
	local pos = pos - (me:GetVelocity() * engine.TickInterval())
	return pos
end

local function aimbot(cmd)
	if gBool("Aimbot", "Aimbot", "Silent Aimbot") and not tpcheck() then
		if cmd:CommandNumber() == 0 then return end
	end

	gettarget()
	aa = false

	if gBool("Aimbot", "Aimbot", "Auto Stop") and aimtarget and check_alive(aimtarget) and aimtarget:IsValid() and aimkeycheck() and WeaponShootable() then
		cmd:SetForwardMove(0)
		cmd:SetSideMove(0)
	end

	if gBool("Aimbot", "Aimbot", "Auto Crouch") and aimtarget and check_alive(aimtarget) and aimtarget:IsValid() and aimkeycheck() and WeaponShootable() and not cmd:KeyDown(IN_DUCK) then
		cmd:SetButtons(cmd:GetButtons() + IN_DUCK)
	end

	if gBool("Aimbot", "Aimbot", "Auto Zoom") and aimtarget and check_alive(aimtarget) and aimtarget:IsValid() and aimkeycheck() and WeaponShootable() and not cmd:KeyDown(IN_ATTACK2) then
		cmd:SetButtons(cmd:GetButtons() + IN_ATTACK2)
	end

	if aimtarget and check_alive(aimtarget) and aimtarget:IsValid() and aimkeycheck() and WeaponShootable() and WeaponCanFire() then
		local pos = GetPos(aimtarget) - me:EyePos()
		PredictPos(pos)
		local ang = pos:Angle()

		if gInt("Aimbot", "Aimbot", "Aimbot FOV") ~= 0 and gOption("Aimbot", "Other", "Priority") == "FOV" then
			for k,v in next, ents.GetAll() do
				if not Valid(v, "aimbot") then continue end

				local CalcX = ang.x - fa.x
				local CalcY = ang.y - fa.y

				if CalcY < 0 then CalcY = CalcY * -1 end	
				if CalcX < 0 then CalcX = CalcX * -1 end
				if CalcY > 360 then CalcY = CalcY - 360 end
				if CalcX > 360 then CalcX = CalcX - 360 end
				if CalcY > 180 then CalcY = 360 - CalcY end
				if CalcX > 180 then CalcX = 360 - CalcX end

				if CalcX <= gInt("Aimbot","Aimbot","Aimbot FOV") and CalcY <= gInt("Aimbot","Aimbot","Aimbot FOV") then
					if gBool("Aimbot", "Aimbot", "Auto Fire") and not gBool("Hack vs Hack", "Anti-Aim", "Enabled") and not gBool("Hack vs Hack", "Anti-Aim Resolver", "Enabled") and not gBool("Misc", "Fake Lag", "Enabled") then
						if me:IsSprinting() then
							command("-speed")
						end
						if WeaponShootable() and not string.find(string.lower(wep:GetPrintName()),"knife") and not string.find(string.lower(wep:GetPrintName()),"sword") and not string.find(string.lower(wep:GetPrintName()),"fist") and not string.find(string.lower(wep:GetPrintName()),"crowbar") then
							memesendpacket = false
						end
					end

					if gBool("Aimbot", "Aimbot", "Auto Fire") then
						if cmd:KeyDown(IN_DUCK) then
							cmd:SetButtons(IN_DUCK + IN_ATTACK)
						else
							cmd:SetButtons(IN_ATTACK)
						end
				
						if me:KeyDown(IN_ATTACK) then
							cmd:RemoveKey(IN_ATTACK)
						end
					end

					if gBool("Aimbot", "Aimbot", "Silent Aimbot") then
						FixMovement(cmd)
					else
						fa = ang
					end

					NormalizeAngle(ang)
					cmd:SetViewAngles(ang)
				else
					return
				end
			end
		else
			NormalizeAngle(ang)
			cmd:SetViewAngles(ang)

			if gBool("Aimbot", "Aimbot", "Auto Fire") and not gBool("Hack vs Hack", "Anti-Aim", "Enabled") and not gBool("Hack vs Hack", "Anti-Aim Resolver", "Enabled") and not gBool("Misc", "Fake Lag", "Enabled") then
				if me:IsSprinting() then
					command("-speed")
				end
				if WeaponShootable() and not string.find(string.lower(wep:GetPrintName()),"knife") and not string.find(string.lower(wep:GetPrintName()),"sword") and not string.find(string.lower(wep:GetPrintName()),"fist") and not string.find(string.lower(wep:GetPrintName()),"crowbar") then
					memesendpacket = false
				end
			end

			if gBool("Aimbot", "Aimbot", "Auto Fire") then
				if cmd:KeyDown(IN_DUCK) then
					cmd:SetButtons(IN_DUCK + IN_ATTACK)
				else
					cmd:SetButtons(IN_ATTACK)
				end

				if me:KeyDown(IN_ATTACK) then
					cmd:RemoveKey(IN_ATTACK)
				end
			end

			if gBool("Aimbot", "Aimbot", "Silent Aimbot") then
				FixMovement(cmd)
			else
				fa = ang
			end
		end
	end
	aa = true
end

local function crosshair()
	local width, height = ScrW() / 2, ScrH() / 2
	
	if hitmarker then
		surface.SetDrawColor(255,255,255)
	else
		surface.SetDrawColor(0,0,0)
	end

	surface.DrawLine(width - 10, height - 10, width + 10, height + 10)
	surface.DrawLine(width + 10, height - 10, width - 10, height + 10)

	if aimkeycheck() and WeaponShootable() and not aimkilled then
		surface.SetDrawColor(AimCol)
	elseif triggerkeycheck() and WeaponShootable() then
		surface.SetDrawColor(MenuCol)
	else
		surface.SetDrawColor(PrimaryCol)

		--[[if wep:IsValid() and wep:Clip1() <= 0 and wep:GetMaxClip1() >= 0 then
			draw.SimpleText("No ammunition in "..wep:GetPrintName()..".", "Verdana", ScrW()/2, ScrH()/1.8, AimCol, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end]]
	end

	surface.DrawLine(width - 5, height - 5, width + 5, height + 5)
	surface.DrawLine(width + 5, height - 5, width - 5, height + 5)

end

local function triggerfilter(hitbox)
	if gOption("Triggerbot", "Other", "Trigger Position") == "Head only" then
		return hitbox == 0
	elseif gOption("Triggerbot", "Other", "Trigger Position") == "Body only" then
		return hitbox == 16
	else
		return hitbox ~= nil
	end
end

local function triggerbot(cmd)
	td = {start = me:GetShootPos(), endpos = me:GetShootPos() + me:EyeAngles():Forward() * 65535, filter = me, mask = MASK_SHOT, mask}
	tr = util.TraceLine(td)
	v = tr.Entity

	local trace = me:GetEyeTraceNoCursor()
	local hitbox = trace.HitBox

	if not Valid(v, "triggerbot") or not trigger_filter(v) or not triggerfilter(hitbox) or (aimkeycheck() and gBool("Aimbot", "Aimbot", "Auto Fire")) then return end

	if gBool("Triggerbot", "Triggerbot", "Auto Stop") and v and check_alive(v) and v:IsValid() and triggerkeycheck() and WeaponShootable() then
		cmd:SetForwardMove(0)
		cmd:SetSideMove(0)
	end

	if gBool("Triggerbot", "Triggerbot", "Auto Crouch") and v and check_alive(v) and v:IsValid() and triggerkeycheck() and WeaponShootable() and not cmd:KeyDown(IN_DUCK) then
		cmd:SetButtons(cmd:GetButtons() + IN_DUCK)
	end

	if gBool("Triggerbot", "Triggerbot", "Auto Zoom") and v and check_alive(v) and v:IsValid() and triggerkeycheck() and WeaponShootable() and not cmd:KeyDown(IN_ATTACK2) then
		cmd:SetButtons(cmd:GetButtons() + IN_ATTACK2)
	end

	if v and check_alive(v) and v:IsValid() and triggerkeycheck() and WeaponShootable() and WeaponCanFire() then
		triggerbot_active = true

		if toggler == 0 then
			cmd:SetButtons(cmd:GetButtons() + IN_ATTACK)
			toggler = 1
		else
			cmd:SetButtons(cmd:GetButtons() + IN_ATTACK)
			toggler = 0
		end
	else
		triggerbot_active = false
	end
end

local function GetClosest()
	local ddists = {}
	local closest

	for k,v in next, player.GetAll() do
		if not Valid(v, "antiaim") then continue end

		ddists[#ddists + 1] = { v:GetPos():Distance(me:GetPos()), v }
	end

	table.sort(ddists, function(a, b)
		return a[1] < b[1]
	end)

	closest = ddists[1] and ddists[1][2] or nil

	if not closest then
		return fa.y
	end

	local pos = closest:GetPos()
	local pos = (pos - me:EyePos()):Angle()

	return pos.y
end

local function pitch()
	local opt = gOption("Hack vs Hack", "Anti-Aim", "Pitch")

	if opt == "None" then
		ox = fa.x
	elseif opt == "Up" then
		if gOption("Hack vs Hack", "Anti-Aim", "Yaw") == "Fake-Sideways" or gOption("Hack vs Hack", "Anti-Aim", "Yaw") == "Fake-Forwards" or gOption("Hack vs Hack", "Anti-Aim", "Yaw") == "Fake-Backwards" or gOption("Hack vs Hack", "Anti-Aim", "Yaw") == "Spin" then
			--ox = 3856
			ox = -120 - math.sin(CurTime()*10)*5
		else
			ox = -89
		end
	elseif opt == "Down" then
		if gOption("Hack vs Hack", "Anti-Aim", "Yaw") == "Fake-Sideways" or gOption("Hack vs Hack", "Anti-Aim", "Yaw") == "Fake-Forwards" or gOption("Hack vs Hack", "Anti-Aim", "Yaw") == "Fake-Backwards" or gOption("Hack vs Hack", "Anti-Aim", "Yaw") == "Spin" then
			--ox = -3856
			ox = 120 + math.sin(CurTime()*10)*5
		else
			ox = 89
		end
	elseif opt == "Center" then
		if gOption("Hack vs Hack", "Anti-Aim", "Yaw") == "Fake-Sideways" or gOption("Hack vs Hack", "Anti-Aim", "Yaw") == "Fake-Forwards" or gOption("Hack vs Hack", "Anti-Aim", "Yaw") == "Fake-Backwards" or gOption("Hack vs Hack", "Anti-Aim", "Yaw") == "Spin" then
			ox = 169 + math.sin(CurTime()*3)*5
		else
			ox = 0
		end
	elseif opt == "Fake-Down" then
		ox = 180.001
	elseif opt == "Jitter" then
		ox = math.random(-90, 90)
	end
end

local function yaw()
	local opt = gOption("Hack vs Hack", "Anti-Aim", "Yaw")

	if gOption("Hack vs Hack", "Anti-Aim", "Pitch") == "Fake-Down" then return end

	if opt == "None" then
		oy = fa.y
	elseif opt == "Sideways" then
		if gOption("Hack vs Hack", "Anti-Aim", "Rotation") == "Left" then
			if gBool("Hack vs Hack", "Anti-Aim", "Follow closest Target") then
				oy = GetClosest() + 90
			else
				oy = fa.y + 90
			end
		elseif gOption("Hack vs Hack", "Anti-Aim", "Rotation") == "Right" then
			if gBool("Hack vs Hack", "Anti-Aim", "Follow closest Target") then
				oy = GetClosest() - 90
			else
				oy = fa.y - 90
			end
		elseif rotate then
			if gBool("Hack vs Hack", "Anti-Aim", "Follow closest Target") then
				oy = GetClosest() + 90
			else
				oy = fa.y + 90
			end
		else
			if gBool("Hack vs Hack", "Anti-Aim", "Follow closest Target") then
				oy = GetClosest() - 90
			else
				oy = fa.y - 90
			end
		end
	elseif opt == "Backwards" then
		if gBool("Hack vs Hack", "Anti-Aim", "Follow closest Target") then
			oy = GetClosest() + 180
		else
			oy = fa.y + 180
		end
	elseif opt == "Spin" then
		if gOption("Hack vs Hack", "Anti-Aim", "Rotation") == "Right" then
			oy = CurTime() * (-gInt("Hack vs Hack", "Anti-Aim", "Spin Speed")*23) % 350, 1
		elseif gOption("Hack vs Hack", "Anti-Aim", "Rotation") == "Left" then
			oy = CurTime() * (gInt("Hack vs Hack", "Anti-Aim", "Spin Speed")*23) % 350, 1
		elseif rotate then
			oy = CurTime() * (-gInt("Hack vs Hack", "Anti-Aim", "Spin Speed")*23) % 350, 1
		else
			oy = CurTime() * (gInt("Hack vs Hack", "Anti-Aim", "Spin Speed")*23) % 350, 1
		end
	elseif opt == "Jitter" then
		oy = fa.y + math.random(-180, 180)
	elseif opt == "Fake-Forwards" then
		if gBool("Hack vs Hack", "Anti-Aim", "Follow closest Target") then
			if gOption("Hack vs Hack", "Anti-Aim", "Rotation") == "Right" then
				oy = GetClosest() + 180 + math.sin(CurTime()*10)*5
			elseif gOption("Hack vs Hack", "Anti-Aim", "Rotation") == "Left" then
				oy = GetClosest() + 180 - math.sin(CurTime()*10)*5
			elseif rotate then
				oy = GetClosest() + 180 + math.sin(CurTime()*10)*5
			else
				oy = GetClosest() + 180 - math.sin(CurTime()*10)*5
			end
		else
			if gOption("Hack vs Hack", "Anti-Aim", "Rotation") == "Right" then
				oy = fa.y + 180 + math.sin(CurTime()*10)*5
			elseif gOption("Hack vs Hack", "Anti-Aim", "Rotation") == "Left" then
				oy = fa.y + 180 - math.sin(CurTime()*10)*5
			elseif rotate then
				oy = fa.y + 180 + math.sin(CurTime()*10)*5
			else
				oy = fa.y + 180 - math.sin(CurTime()*10)*5
			end
		end
	end
end

local function antiaim(cmd)
	if (cmd:KeyDown(IN_ATTACK) and wep:Clip1() ~= 0) or me:WaterLevel() > 1 or me:GetMoveType() == MOVETYPE_LADDER or me:GetMoveType() == MOVETYPE_NOCLIP or string.find(string.lower(wep:GetPrintName()),"grenade") or not me:Alive() then return end

	if not tpcheck() --[[and gOption("Misc", "Misc", "Circle Strafe") ~= "Off" and strafekeycheck()]] and cmd:CommandNumber() == 0 then
		return
	elseif not tpcheck() and cmd:CommandNumber() == 0 then
		return
	end

	pitch()
	yaw()

	local aaang = Angle(ox, oy, 0)
	cmd:SetViewAngles(aaang)
	FixMovement(cmd, true)
end

local function GetAngle(ang)
	if not nophys() then
		return ang + me:GetPunchAngle()
	end
end

local function bunnyhop(cmd)
	buttons = cmd:GetButtons()
	if cmd:KeyDown(IN_JUMP) and me:IsValid() and me:GetMoveType() ~= MOVETYPE_NOCLIP and me:Alive() then
		if not me:IsOnGround() then
			buttons = bit.band(buttons, bit.bnot(IN_JUMP))
		end
		cmd:SetButtons(buttons)
	end
end

local function autostrafe(cmd)
	if me:IsOnGround() or me:KeyDown(IN_MOVELEFT) or me:KeyDown(IN_MOVERIGHT) or me:KeyDown(IN_FORWARD) or me:KeyDown(IN_BACK) or me:GetMoveType() == MOVETYPE_NOCLIP or me:WaterLevel() > 1 or not me:Alive() then return end

	--[[if cmd:GetMouseX() < -5 then
		cmd:SetSideMove(-me:GetVelocity():Length()-400)
	elseif cmd:GetMouseX() > 5 then
		cmd:SetSideMove(me:GetVelocity():Length()+400)
	else
		cmd:SetForwardMove(400)
		cmd:SetSideMove(math.random(-10000,10000))
	end]]

	if cmd:GetMouseX(ucmd) < -5 then
		cmd:SetSideMove(-400)
	elseif cmd:GetMouseX() > 5 then
		cmd:SetSideMove(400)
	else
		cmd:SetForwardMove(5850 / me:GetVelocity():Length2D())
		cmd:SetSideMove(cmd:CommandNumber() % 2 == 0 and -400 or 400)
	end
end

local function rapid(cmd)
	if engine.ActiveGamemode() == "terrortown" then
		if GetRoundState() ~= ROUND_ACTIVE or GetRoundState() == ROUND_PREP then return end
	end

	if me:GetActiveWeapon():IsValid() and me:GetActiveWeapon():GetClass() ~= "weapon_physgun" and me:GetActiveWeapon():GetClass() ~= "weapon_physcannon" then
		if wep:IsValid() and wep:Clip1() ~= 0 then
			if me:KeyDown(IN_ATTACK) then
				if string.find(string.lower(wep:GetPrintName()),"dual") then
					cmd:RemoveKey(IN_ATTACK) cmd:SetButtons(cmd:GetButtons() + IN_ATTACK2)
				else
					cmd:RemoveKey(IN_ATTACK)
				end
			end
		end
	end
end

local function autoreload(cmd)
	if engine.ActiveGamemode() == "terrortown" then
		if GetRoundState() ~= ROUND_ACTIVE or GetRoundState() == ROUND_PREP then return end
	end

	if wep:Clip1() ~= 0 then
		if not cmd:KeyDown(IN_ATTACK) or not aimkeycheck() then
			if wep:IsValid() then
				if wep:Clip1() <= 0 and wep:GetMaxClip1() > 0 and CurTime() > wep:GetNextPrimaryFire() then
					cmd:SetButtons(cmd:GetButtons() + IN_RELOAD)
				end
			else
				return
			end
		end
	else
		if wep:GetMaxClip1() > 0 and CurTime() > wep:GetNextPrimaryFire() then
			cmd:SetButtons(cmd:GetButtons() + IN_RELOAD)
		end
	end
end

local function show_aa(cmd)
	if not fa then
		fa = cmd:GetViewAngles()
	end

	fa = fa + Angle(cmd:GetMouseY() * .023, cmd:GetMouseX() * -.023, 0)
	NormalizeAngle(fa)

	if cmd:CommandNumber() == 0 then
		if not nophys() then
			cmd:SetViewAngles(GetAngle(fa))
			return
		end
	end
end

local function death_log(data)
	local killer = Entity(data.entindex_attacker)
	local victim = Entity(data.entindex_killed)
	local v = killer or victim

	if v:IsDormant() or not v:IsValid() then return end
	if v:IsPlayer() and (v:Team() == TEAM_SPECTATOR or v:Team() == TEAM_CONNECTING) then return end

	if killer:IsValid() and victim:IsValid() and killer:IsPlayer() and victim:IsPlayer() and me:GetActiveWeapon():IsValid() then
		if killer == victim and victim ~= me then
			chat.AddText(MenuCol, " "..victim:Nick().." killed themself.")
		elseif killer == victim and victim == me then
			chat.AddText(MenuCol, " You killed yourself.")
		elseif killer == me then
			chat.AddText(MenuCol, " You killed "..victim:Nick()..".")
		elseif victim == me then
			chat.AddText(MenuCol, " You were killed by "..killer:Nick()..".")
		else
			chat.AddText(MenuCol, " "..killer:Nick().." killed "..victim:Nick()..".")
		end

		if gBool("Settings", "Menu", "Sounds") then
			chat.PlaySound()
		end
	end
end

function file.Read(name, path)
	if string.find(name, cheatname..".lua") or string.find(string.lower(name), string.lower(cheatname)) and not string.find(string.lower(name), string.lower(cheatname.."/*")) then
		print("\nAn attempt to perform file.Read on \""..name.."\" has been made.\n")
		return "You are not going to be able to view this lua file, thanks to "..cheatname.."."
	else
		return og_read(name, path)
	end
end

function file.Open(name, mode, path)
	if string.find(name, cheatname..".lua") or string.find(string.lower(name), string.lower(cheatname)) and not string.find(string.lower(name), string.lower(cheatname.."/*")) then
		print("\nAn attempt to perform file.Open on \""..name.."\" has been made.\n")
		return "You are not going to be able to view this lua file, thanks to "..cheatname.."."
	else
		return og_open(name, mode, path)
	end
end

function file.Exists(name, path)
	if string.find(name, cheatname..".lua") or string.find(string.lower(name), string.lower(cheatname)) and not string.find(string.lower(name), string.lower(cheatname.."/*")) then
		print("\nAn attempt to perform file.Exists on \""..name.."\" has been made.\n")
		return "You are not going to be able to view this lua file, thanks to "..cheatname.."."
	else
		return og_exists(name, path)
	end
end

local function chatspam()
	if gOption("Misc", "Misc", "Chat Spam") == "Advertisements" then
		if engine.ActiveGamemode() == "darkrp" then
			command("say // "..cheatname.." - "..spam_messages[math.random(#spam_messages)])
		else
			command("say "..cheatname.." - "..spam_messages[math.random(#spam_messages)])
		end
	else
		if engine.ActiveGamemode() == "darkrp" then
			ChatClear.OOC()
		else
			ChatClear.Run()
		end
	end
end

local purchase = { "Consider buying premium!", "Buy the premium version for 6â‚¬!", "Get the premium version for 6â‚¬!", "Buy premium for just 6â‚¬!", "Would you like to purchase the premium version?", "Annoying popup.", "Consider getting the premium version!", "Get premium! You can disable these under the \"Settings\" tab." }
local toopoor = { "No!", "Nope.", "Fuck off.", "Miss me with that gay shit.", "No thanks.", "Not interested.", "I'll think about it.", "I might consider it.", "Stop.", "No." }

local function cancer()
	local menu = vgui.Create("DFrame")
	menu:SetSize(400, 125)
	menu:Center()
	menu:SetTitle("")
	menu:ShowCloseButton(false)
	menu:MakePopup()

	surface.PlaySound("ambient/music/country_rock_am_radio_loop.wav")

	local plzbuy = purchase[math.random(#purchase)]

	menu.Paint = function(s, w, h)
		surface.SetDrawColor(40,40,40,250)
		surface.DrawRect(0, 0, w, h)

		draw.DrawText(plzbuy, "Verdana", w/2, 20, Color(255,255,255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		draw.DrawText("Or press F to close.", "Verdana", w/2, h-35, Color(255,255,255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end

	local yes = vgui.Create("DButton", menu)
	yes:SetSize(140, 25)
	yes:SetPos(50, 50)
	yes:SetText("Okay!")
	yes.DoClick = function()
		command("stopsound")
		menu:Remove()
		gui.OpenURL(discord)
		SetClipboardText(discord)
		msg(5, "Copied discord invite!")
	end

	local no = vgui.Create("DButton", menu)
	no:SetSize(140, 25)
	no:SetPos(205, 50)
	no:SetText(toopoor[math.random(#toopoor)])
	no.DoClick = function()
		command("stopsound")
		menu:Remove()
	end

	menu.Think = function()
		if gui.IsGameUIVisible() then
			gui.HideGameUI()
		end

		if input.IsKeyDown(16) then
			command("stopsound")
			menu:Remove()
		end
	end
end

local function entityname()
	if util.TraceLine(util.GetPlayerTrace(me)).Entity:IsValid() then
		return util.TraceLine(util.GetPlayerTrace(me)).Entity:GetClass()
	else
		return "None"
	end
end

local function spam_kill(data)
	local killer = Entity(data.entindex_attacker)
	local killed = Entity(data.entindex_killed)

	if not killer:IsValid() or not killed:IsValid() or killer ~= me or killer == killed or not killed:IsPlayer() then return end
	if gBool("Aimbot", "Other", "Ignore Friends") then if killed:GetFriendStatus() == "friend" then return end end

	local default = { killed:Nick()..", do you even lift?", "Sit down, "..killed:Nick()..".", "Faggot.", "Owned!", "Rekt!!!", "1tapped.", "Ez tbh.", "Ez!", "Later, "..killed:Nick()..".", "Noob.", "Right into your face, "..killed:Nick()..".", "Into your face, pal.", killed:Nick().." with that negative IQ!", "Gay kid." }
	--local hvh = { "ez resolve, "..killed:Nick(), "noob", "pCheat", "stop using bad paste!!!!!", "10/10 cheat", "where can I get that perfect cheat", "wow!", "ez", "1", "ezzzz", "tfw resolved", "wow! rekt!", "owned!!", "u got OWNED "..killed:Nick().."!!!!!" }

	if gOption("Misc", "Misc", "Spam after Kill") == "On" then
		command("say "..default[math.random(#default)])
	elseif gOption("Misc", "Misc", "Spam after Kill") == "Rage Targets Only" and table.HasValue(priority_list, killed:UniqueID()) then
		command("say "..default[math.random(#default)])
	--[[elseif gOption("Misc", "Misc", "Spam after Kill") == "HvH Resolved Angle" and gBool("Hack vs Hack", "Anti-Aim Resolver", "Enabled") and gBool("Aimbot", "Aimbot", "Auto Fire") then
		command("say Resolved: "..killed:Nick().." - Pitch: "..gOption("Hack vs Hack", "Anti-Aim Resolver", "Pitch").." ("..math["Round"](pitch)..") - Yaw: "..gOption("Hack vs Hack", "Anti-Aim Resolver", "Yaw").." ("..math["Round"](yaw)..")")]]
	end
end

local function namesteal()
	local random_player = player.GetAll()[math.random(#player.GetAll())]

	if random_player:IsValid() and random_player ~= me and random_player:GetFriendStatus() ~= "friend" then
		if engine.ActiveGamemode() == "darkrp" then
			changetime = changetime + 1

			if changetime > 500 then
				command("say /name "..random_player:Name().."â€‹")
				changetime = 0
			end
		elseif engine.ActiveGamemode() == "terrortown" then
			if GetRoundState() ~= ROUND_ACTIVE and GetRoundState() ~= ROUND_PREP then
				_fhook_changename(random_player:Name().."â€‹")
			end
		else
			_fhook_changename(random_player:Name().."â€‹")
		end

		if not name_changed then
			name_changed = true
		end

		stolenname = random_player:Name()
	end
end

addhook("Move", function()
	--if not IsFirstTimePredicted() then return end

	servertime = CurTime()

	-- pasters, you can add delay to each shot here, figure out how
end)

addhook("Think", function()
	if (input.IsKeyDown(KEY_INSERT) or input.IsKeyDown(KEY_F11) or input.IsKeyDown(KEY_HOME)) and not menuopen and not insertdown then
		menuopen = true
		insertdown = true
		menu()
	elseif not (input.IsKeyDown(KEY_INSERT) or input.IsKeyDown(KEY_F11) or input.IsKeyDown(KEY_HOME)) and not menuopen then
		insertdown = false
	end
	if (input.IsKeyDown(KEY_INSERT) or input.IsKeyDown(KEY_F11) or input.IsKeyDown(KEY_HOME)) and insertdown and menuopen then
		insertdown2 = true
	else
		insertdown2 = false
	end

	if gOption("Misc", "Misc", "Chat Spam") ~= "Off" then
		chatspam()
	end

	if gBool("Misc", "Misc", "Name Stealer") then
		namesteal()
	else
		if name_changed and me:Nick() ~= realname then
			if engine.ActiveGamemode() == "darkrp" then
				command("say /name "..realname)
			elseif engine.ActiveGamemode() == "terrortown" then
				if GetRoundState() ~= ROUND_ACTIVE and GetRoundState() ~= ROUND_PREP then
					_fhook_changename(realname)
				end
			else
				_fhook_changename(realname)
			end

			name_changed = false
		end
	end

	if gBool("Settings", "Menu", "Death Popups") then
		if not me:Alive() and not opened then
			opened = true
			//cancer()
		elseif me:Alive() and opened then
			opened = false
		end
	end
end)

addhook("CreateMove", function(cmd)
	memesendpacket = true
	wep = me:GetActiveWeapon()

	if me:Health() < 1 or not me:Alive() then return end

	show_aa(cmd)

	if gBool("Triggerbot", "Triggerbot", "Enabled") then
		triggerbot(cmd)
	end

	if gInt("Misc", "Fake Lag", "Density") ~= 0 and not gBool("Hack vs Hack", "Anti-Aim", "Enabled") then
		fakelag(cmd)
	end

	if gBool("Misc", "Misc", "Bunny Hop") then
		bunnyhop(cmd)
	end

	if gBool("Misc", "Misc", "Auto Strafe") --[[and not strafekeycheck()]] then
		autostrafe(cmd)
	end

	if gBool("Misc", "Misc", "Rapid Fire") then
		rapid(cmd)
	end

	if gBool("Misc", "Misc", "Auto Reload") and wep:IsValid() then
		autoreload(cmd)
	end

	if gBool("Aimbot", "Aimbot", "Enabled") and wep:IsValid() and not cmd:KeyDown(IN_ATTACK) then
		aimbot(cmd)
	end

	if gBool("Hack vs Hack", "Anti-Aim", "Enabled") and wep:IsValid() and wep:GetClass() ~= "weapon_zm_carry" then
		antiaim(cmd)
	end
end)

addhook("entity_killed", function(data)
	if gOption("Misc", "Misc", "Spam after Kill") ~= "Off" then
		spam_kill(data)
	end

	if gBool("Misc", "Misc", "Log Kills in Chat") then
		death_log(data)
	end
end)

addhook("player_hurt", function(data)
	if gBool("Misc", "Misc", "Hitsound") then
		if data.attacker == me:UserID() then
			surface.PlaySound("buttons/button10.wav")
		end
	end
end)

addhook("ShouldDrawLocalPlayer", function()
	return tpcheck()
end)

addhook("PlayerFootstep", function()
	return gBool("Misc", "Misc", "Mute Footsteps")
end)

addhook("HUDPaint", function()
	if gBool("Visuals", "ESP", "Enabled") then
		esp()
	end
	if gInt("Settings", "Menu", "Darkness") > 0 and menuopen then
		surface.SetDrawColor(0,0,0,gInt("Settings", "Menu", "Darkness")*10)
		surface.DrawRect(0,0,ScrW(),ScrH())
	end

	if gBool("Visuals", "Other", "Crosshair") then
		crosshair()
	end

	if gBool("Visuals", "Radar", "Enabled") then
		radar()
	end

	if gInt("Aimbot", "Aimbot", "Aimbot FOV") ~= 0 and draw_fov then
		aimfov()
	end

	if gBool("Misc", "Other", "Debug Information") then
		draw.SimpleText("Build: "..version.."\t\tHealth: "..me:Health().."/"..me:GetMaxHealth().."\t\tVelocity: "..math["Round"](me:GetVelocity():Length()).."\t\tServer: "..GetHostName().."\t\tGamemode: "..engine.ActiveGamemode().."\t\tPlayers: "..player.GetCount().."/"..game.MaxPlayers().."\t\tMap: "..game.GetMap().."\t\tEntity: "..entityname().."\t\tEntities: "..math["Round"](ents.GetCount()-player.GetCount()*12).."\t\tFPS: "..math["Round"](1/FrameTime()).."\t\tPing: "..me:Ping().."\t\tDate: "..os.date("%d %b %Y").."\t\tTime: "..os.date("%H:%M:%S"), "Verdana", 50, 15, Color(255,255,255), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
	end
end)

addhook("CalcView", function(me, pos, ang, fov)
	if me:Alive() then
		if not tpcheck() and me:Alive() and not (wep:IsValid() and wep:GetPrimaryAmmoType() == 14 and input.IsMouseDown(108) and WeaponCanFire()) then
			local view = {}
			view.origin = me:EyePos()
			view.angles = me:EyeAngles()

			return view
		else
			local view = {}
			view.angles = GetAngle(fa)
			view.origin = tpcheck() and pos + Angle(fa):Forward() * ((gInt("Visuals", "Other", "Third Person Distance") + 10) * -10) or pos

			return view
		end
	end
end)

addhook("PreDrawOpaqueRenderables", function() -- or "RenderScene"
	if gBool("Hack vs Hack", "Anti-Aim Resolver", "Enabled") and gBool("Aimbot", "Aimbot", "Auto Fire") then
		for k, v in next, player.GetAll() do
			if not Valid(v, "antiaim") then continue end

			local pitch = v:EyeAngles().x
			local yaw = v:EyeAngles().y

			pitch = 90
			yaw = math.random(-180, 180) -- premium resolver literally owns anything unlike this

			v:SetPoseParameter("aim_pitch", math.NormalizeAngle(pitch))
			v:SetPoseParameter("head_pitch", math.NormalizeAngle(pitch))

			v:SetPoseParameter("body_yaw", 0)
			v:SetPoseParameter("aim_yaw", 0)

			v:SetRenderAngles(Angle(0, math.NormalizeAngle(yaw), 0))
			v:InvalidateBoneCache()
		end
	end

	if gBool("Hack vs Hack", "Anti-Aim", "Enabled") then
		me:SetRenderAngles(Angle(0, me:EyeAngles().y, 0))
	end
end)

do
	config_colors()

	concommand.Add("x_unload", unload) -- emergency unload

	pwloaded = true

	--[[if 1/RealFrameTime() < 40 then
		lowfps()
	end]]
end