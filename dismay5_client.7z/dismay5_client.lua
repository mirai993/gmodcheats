local dismay = {};
dismay.private = {
	hiddenfiles = {};
	funcs	= {};
	oldfuncs= {};
	metas = {
		real = {};
	};
	waitfor = {};
	gm 		= {};
	fgm 	= {};
	ogm 	= {};
	egm 	= {};
	vars 	= {};
	dhook 	= {};
	realg	= _G;
	esp		= {};
	scrnsht	= {};
	scrnshtd= {};
	oldr	= {};
};
function dismay.ShouldDrawESP() 
	return dismay.private.ShouldDrawESP;
end
print("***[C] - Loading");

function dismay.HideThisFile(f)
	dismay.private.hiddenfiles[dismay.private.oldfuncs.debug_getinfo(f).short_src] = true;
end

dismay.private.hiddenfiles["\x01"] = true;

local function __indexnew(self, k)
	local mt = dismay.private.oldg.getmetatable(self);
	if(dismay.private.oldg.rawget(mt.spoofed, k) == nil) then
		if(mt.spoofedname == "_G" and k == "dismay") then return dismay; end
		dismay.private.oldg.MsgC(dismay.private.oldg.Color(200, 0, 0, 255), "***WARNING: indexed function "..mt.spoofedname.."."..k.." but didn't exist! Defaulting to real global table (could have anticheat code in it)\n"..dismay.private.oldg.debug.traceback().."\n\n");
	else
		if(mt.spoofedname == "_G.dismay.private" and k == "realg") then
			return dismay.private.oldg.rawget(mt.spoofed, k);
		end
		if(dismay.private.oldg.type(dismay.private.oldg.rawget(mt.spoofed, k)) == "table") then
			local nmt 	= dismay.CopyTable(dismay.private.spf);
			nmt.spoofed = dismay.private.oldg.rawget(mt.spoofed, k);
			nmt.real	= dismay.private.oldg.rawget(mt.real, k);
			nmt.spoofedname = (mt.spoofedname and mt.spoofedname.."." or "")..k; 
			return dismay.private.oldg.setmetatable(mt.spoofed[k], nmt);
		else
			return mt.spoofed[k];
		end
	end
	return mt.real[k];
end

local function __newindexnew(self, k, v)
	dismay.private.oldg.MsgC(dismay.private.oldg.Color(200,0,0,255), "***WARNING: created new global index "..k.." ("..tostring(v).."). If this was intended use dismay.private.realg["..k.."] = "..tostring(v).."\n");
end

dismay.private.spf = {
	__index 	= __indexnew;
	__newindex 	= __newindexnew;
}

function dismay.SetupGlobalTable()
	local mt 		= dismay.CopyTable(dismay.private.spf);
	mt.spoofedname 	= "_G";
	mt.real 		= dismay.private.realg;
	mt.spoofed 		= dismay.private.newg;
	dismay.private.oldg.setfenv(2, dismay.private.oldg.setmetatable({}, mt));
end


local function normalang(ang)
	ang.p = (ang.p + 180) % 360 - 180;
	ang.y = (ang.y + 180) % 360 - 180;
	ang.r = (ang.r + 180) % 360 - 180;
	return ang;
end

if (GetPred) then dismay.private.GetPred = GetPred; GetPred = nil; 
	function dismay.GetPred(ply)
		return dismay.private.GetPred(ply, Vector(0,0,0));
	end
end
if (PredSpread) then
	dismay.private.PredSpread = PredSpread; PredSpread = nil;
	function dismay.PredSpread(cmd, ang)
		local l = LocalPlayer();
		local w = l:GetActiveWeapon();
		if(LocalPlayer():GetActiveWeapon().Author == "Spy" and w.CurCone) then -- fas2
			local n = cmd:CommandNumber();
			math.randomseed(n)
			local a = Angle(math.Rand(-w.CurCone, w.CurCone), math.Rand(-w.CurCone, w.CurCone), 0);
			local nang = ang - l:GetPunchAngle() - a * 25
			local b = false; 
			if w.ClumpSpread and w.ClumpSpread > 0 then
				b = Vector(math.Rand(-1, 1), math.Rand(-1, 1), math.Rand(-1, 1)) * w.ClumpSpread
			end
			if(b) then
				nang = (nang:Forward() - b):Angle();
			end
			return nang
		end
		local b, _spread = dismay.private.PredSpread(cmd:CommandNumber(), ang, dismay.GetSpread(LocalPlayer():GetActiveWeapon()));
		local g = {b, _spread};
		local ret = _spread:Angle();
		ret.p = ret.p;
		return normalang(ret);
	end
end
dismay.version = 8;
local oG = _G;

local function ReplaceG(index)
	dismay[index] = oG[index];
	oG[index] = nil;
end
local function ReplaceUN(index)
	dismay.private[index] = oG[index];
	oG[index] = nil;
end

ReplaceG	("Repaint");
ReplaceUN	("SendFile");
ReplaceUN	("GetFile");
ReplaceG	("SetCommandNumber");
ReplaceG	("_tc");
ReplaceG	("RunClient");
ReplaceG	("OpenClient");
ReplaceG	("RunMenu");
ReplaceG	("OpenMenu");
ReplaceG	("rversion");
ReplaceG	("IsDormant");
ReplaceG	("GetCmdRepState");
ReplaceG	("SetCmdRepState");
ReplaceG	("GetCmdSendState");
ReplaceG	("SetTickRate");
ReplaceG	("SetCmdSendState");
ReplaceG	("SetSteamName");
ReplaceG	("GetSteamName");
ReplaceG	("SetIGN");
ReplaceG	("LoadWebScript");
ReplaceG	("RequestFile");
ReplaceG	("GetTickCount");

dismay.SetCmdSendState(true);
dismay.SetCmdRepState(false);
dismay.SetCommandNumber(-1);

function dismay.OverrideHook(name, redir)
	dismay.private.Hooks = dismay.private.Hooks or {};
	dismay.private.Hooks[name] = redir;
end

function dismay.CallHook(name, ...)
	if(not dismay.private.Hooks[name]) then return; end
	for k,v in dismay.private.oldfuncs.pairs(dismay.private.Hooks[name]) do
		v(...);
	end
end

function dismay.SpoofFunction(oldfunction, replacefunction)
	dismay.private.funcs[replacefunction] = oldfunction;
end

function dismay.runwhenindexcreated(k, func)
	if (oG[k]) then func(); return; end
	dismay.private.waitfor[k] = dismay.private.waitfor[k] or {};
	dismay.private.waitfor[k][#dismay.private.waitfor[k] + 1] = func;
end

function dismay.GetHooks(name)
	return dismay.private.fgm[name] or {};
end

function dismay.AddHook(_type, name, func)
	if(_type == "OnScreenshot") then
		dismay.private.scrnsht[name] = func;
	end
	if(_type == "OnScreenshotDone") then
		dismay.private.scrnshtd[name] = func;
	end
	dismay.private.fgm[_type] = dismay.private.fgm[_type] or {};
	dismay.private.fgm[_type][name] = func;
end

function dismay.RemoveHook(_type, name)
	local type = _type;
	local c = dismay.private.fgm[type] or {};
	c[name] = nil;
end

function dismay.CopyTable(t, lookup_table)
	if (t == nil) then return nil end
	local copy = {}
	for i,v in dismay.private.oldfuncs.pairs(t) do
		if ( !istable(v) ) then
			copy[i] = v
		else
			lookup_table = lookup_table or {}
			lookup_table[t] = copy
			if lookup_table[v] then
				copy[i] = lookup_table[v] -- we already copied this table. reuse the copy.
			else
				copy[i] = dismay.CopyTable(v,lookup_table) -- not yet copied. copy it.
			end
		end
	end
	return copy
end


function dismay.CopyTable_l(t, lookup_table)
	if (t == nil) then return nil end
	local copy = {}
	for i,v in dismay.private.oldfuncs.pairs(t) do
		copy[i] = v;
	end
	return copy
end
dismay.private.oldfuncs.jit_util_funcinfo	= jit.util.funcinfo;
dismay.private.oldfuncs.debug_setupvalue	= debug.setupvalue;
dismay.private.oldfuncs.debug_getupvalue	= debug.getupvalue;
dismay.private.oldfuncs.debug_getinfo	= debug.getinfo;
dismay.private.oldfuncs.tostring		= tostring;
dismay.private.oldfuncs.getmetatable	= getmetatable;
dismay.private.oldfuncs.setmetatable	= setmetatable;
dismay.private.oldfuncs.rawget		= rawget;
dismay.private.oldfuncs.rawset		= rawset;
dismay.private.oldfuncs.pairs		= pairs;
dismay.private.oldfuncs.next		= next;

local function Color(r, g, b, a)
	return {r = r; g = g; b = b; a = a;}
end

dismay.private.oldg = dismay.CopyTable(_G);
dismay.private.newg = dismay.CopyTable(_G);
dismay.private.oldr = dismay.CopyTable(debug.getregistry());

local _R 	= dismay.private.oldr;
local G 	= dismay.private.oldg;
local rG = dismay.private.realg;
function dismay.private.newg.math.Round(x)
	return G.math.floor(x + 0.5);
end
dismay.SetupGlobalTable();


dismay.private.oldg.Color = Color;
dismay.private.newg.Color = Color;

dismay.private.metas.real.GAMEMODE = {
	__index = function(self, k)
		return dismay.private.gm[k] or dismay.private.ogm[k];
	end;
	__newindex = function(self, k, func)
		dismay.private.gm[k] = func;
		dismay.private.ogm[k] = func;
		dismay.private.oldfuncs.rawset(self, k, nil);
		if (dismay.private.oldg.type(func) == "function") then
			local f = function(GM, ...)
				if (dismay.private.fgm[k]) then
					for _k, vfunc in dismay.private.oldg.pairs(dismay.private.fgm[k]) do
						local r = vfunc(...);
						if (r ~= nil) then return r; end
					end
				end
				return dismay.private.ogm[k](dismay.private.ogm, ...);
			end
			dismay.SpoofFunction(func, f);
			dismay.private.gm[k] = f;
		end
		return;
	end;
	__dtable = true;
};
local troo = false;

dismay.private.metas.real._G = {
	__index = function(self, k)
		--if(troo) then dismay._tc(dismay.private.oldg.tostring(k).."\n"..debug.traceback(), "__index - _G"); end
		if (k == "dismay") then
			return dismay;
		end
		if (dismay.private.metas._G and dismay.private.metas._G.__index) then
			local ret = dismay.private.metas._G.__index(self, k);
			if (dismay.private.oldg.type(ret) ~= "no value") then
				return ret;
			end
		end
	end;
	__newindex = function(self, k, v)
		if (k == "dismay") then 
			return;
		end
		if (dismay.private.metas["_G"] and dismay.private.metas["_G"].__newindex and not dismay.private.check1) then
			dismay.private.check1 = true;			
			local ret = dismay.private.metas["_G"].__newindex(self, k, v);
			dismay.private.check1 = false;
			if (dismay.private.oldg.type(ret) ~= "no value") then
				return ret;
			end
		end
		if (dismay.private.waitfor[k]) then
			local o = dismay.CopyTable_l(dismay.private.waitfor[k]);
			dismay.private.waitfor[k] = nil;
			for i, func in dismay.private.oldg.ipairs(o) do
				func(v);
			end
		end
		return dismay.private.oldfuncs.rawset(self, k, v);
	end;
	__dtable = true;
};

function rG.debug.getupvalue(func, ...)
	--dismay._tc(tostring(func), "debug.getupvalue");
	if(dismay.private.funcs[func]) then
		return dismay.private.oldfuncs.debug_getupvalue(dismay.private.funcs[func], ...);
	end
	return dismay.private.oldfuncs.debug_getupvalue(func, ...);
end

function rG.debug.setupvalue(func, ...)
	--dismay._tc(tostring(func), "debug.setupvalue");
	if(dismay.private.funcs[func]) then
		return dismay.private.oldfuncs.debug_setupvalue(dismay.private.funcs[func], ...);
	end
	return dismay.private.oldfuncs.debug_setupvalue(func, ...);
end

local debug_getinfo;

function debug_getinfo(func, value)
	local ret = nil;
	if (dismay.private.funcs[func]) then
		ret = dismay.private.oldfuncs.debug_getinfo(dismay.private.funcs[func], value or nil);
		if (ret.func) then ret.func = func; end
	else
		ret = dismay.private.oldfuncs.debug_getinfo(func, value or nil);
		if(dismay.private.oldg.type(func) == "number") then
			local need = func;
			local current = 0;
			while(need > 1) do
				--ret and ret.short_src and dismay.private.hiddenfiles[ret.short_src]
				local r = dismay.private.oldfuncs.debug_getinfo(current);
				if(not r or not r.short_src or not dismay.private.hiddenfiles[r.short_src]) then
					need = need - 1;
				end
				current = current + 1;
			end
			ret = dismay.private.oldfuncs.debug_getinfo(current, value or nil);
		end
	end
	return ret;
end

rG.debug.getinfo = debug_getinfo;

function rG.jit.util.funcinfo(func, ...)
	local ret = nil;
	if(dismay.private.funcs[func]) then
		ret = dismay.private.oldfuncs.jit_util_funcinfo(dismay.private.funcs[func], ...);
	else
		ret = dismay.private.oldfuncs.jit_util_funcinfo(func, ...);
	end
	return ret;
end

function rG.next(table, t)
	--dismay._tc(tostring(table).." "..tostring(t), "next");
	if (table == dismay.private.oldg.rawget(rG, "GAMEMODE")) then
		return dismay.private.oldfuncs.next, dismay.private.gm, t;
	end
	if (table == rG) then
		local f_G = dismay.CopyTable_l(rG);
		f_G.GAMEMODE = dismay.private.oldg.rawget(rG, "GAMEMODE");
		return dismay.private.oldfuncs.next, f_G, t;
	end
	return dismay.private.oldfuncs.next, table, t;
end

function rG.pairs(table)
	if (table == dismay.private.oldg.rawget(rG, "GAMEMODE")) then
		--dismay._tc(tostring(table), "pairs - gamemode");
		return dismay.private.oldfuncs.next, dismay.private.gm, nil;
	end
	if (table == rG) then
		--dismay._tc(tostring(table).."\n"..debug.traceback(), "pairs - _G");
		
		local f_G = dismay.CopyTable_l(rG);
		f_G.GAMEMODE = dismay.private.oldg.rawget(rG, "GAMEMODE");
		return dismay.private.oldfuncs.next, f_G, nil;
	end
	return dismay.private.oldfuncs.next, table, nil;
end

function rG.rawget(table, index)
	if (dismay.private.oldfuncs.getmetatable(table) and dismay.private.oldg.type(dismay.private.oldfuncs.getmetatable(table)) == "table" and dismay.private.oldfuncs.getmetatable(table).__dtable) then
		return dismay.private.oldfuncs.getmetatable(table).__index(table, index);
	end
	return dismay.private.oldfuncs.rawget(table, index);
end

function rG.rawset(table, index, value)
	if (dismay.private.oldfuncs.getmetatable(table) and dismay.private.oldg.type(dismay.private.oldfuncs.getmetatable(table)) == "table" and dismay.private.oldfuncs.getmetatable(table).__dtable) then
		return dismay.private.oldfuncs.getmetatable(table).__newindex(table, index, value);
	end
	return dismay.private.oldfuncs.rawset(table, index, value);
end

function rG.tostring(value)
	local ots = dismay.private.oldfuncs.tostring;
	if(dismay.private.funcs[value]) then 
		return ots(dismay.private.funcs[value]);
	end
	return ots(value);
end

function rG.getmetatable(tbl)
	troo = true;
	if (tbl == rG) then
		return dismay.private.metas._G or nil;
	end
	if (tbl == dismay.private.oldg.rawget(rG, "GAMEMODE")) then
		return dismay.private.metas.GAMEMODE or nil;
	end
	troo = false;
	return G.getmetatable(tbl);
end

function rG.setmetatable(tbl, mt)
	if (tbl == rG) then
		dismay.private.metas._G = mt;
		return tbl;
	end
	if (tbl == G.rawget(rG, "GAMEMODE")) then
		dismay.private.metas.GAMEMODE = mt;
		return tbl;
	end
	return G.setmetatable(tbl, mt);
end

dismay.SpoofFunction(dismay.private.oldfuncs.jit_util_funcinfo,	rG.jit.util.funcinfo);
dismay.SpoofFunction(dismay.private.oldfuncs.debug_getupvalue,	rG.debug.getupvalue);
dismay.SpoofFunction(dismay.private.oldfuncs.debug_setupvalue,	rG.debug.setupvalue);
dismay.SpoofFunction(dismay.private.oldfuncs.debug_getinfo,	rG.debug.getinfo);
dismay.SpoofFunction(dismay.private.oldfuncs.getmetatable,	rG.getmetatable);
dismay.SpoofFunction(dismay.private.oldfuncs.setmetatable,	rG.setmetatable);
dismay.SpoofFunction(dismay.private.oldfuncs.tostring,		rG.tostring);
dismay.SpoofFunction(dismay.private.oldfuncs.rawget,		rG.rawget);
dismay.SpoofFunction(dismay.private.oldfuncs.rawset,		rG.rawset);
dismay.SpoofFunction(dismay.private.oldfuncs.pairs,		rG.pairs);
dismay.SpoofFunction(dismay.private.oldfuncs.next,		rG.next);

dismay.private.oldfuncs.setmetatable(rG, dismay.private.metas.real._G);

dismay.runwhenindexcreated("GAMEMODE", function(GAMEMODE)
	for k, func in dismay.private.oldfuncs.pairs(dismay.CopyTable_l(GAMEMODE)) do
		dismay.private.gm[k] = func;
		dismay.private.ogm[k] = func;
		dismay.private.oldfuncs.rawset(GAMEMODE, k, nil);
		if (dismay.private.oldg.type(func) == "function") then
			local f = function(self, ...)
				if (dismay.private.fgm[k]) then
					for _k, vfunc in dismay.private.oldg.pairs(dismay.private.fgm[k]) do
						local r = vfunc(...);
						if (r ~= nil) then return r; end
					end
				end
				return dismay.private.ogm[k](dismay.private.ogm, ...);
			end
			dismay.SpoofFunction(func, f);
			dismay.private.gm[k] = f;
		end
	end
	dismay.private.oldfuncs.setmetatable(GAMEMODE, dismay.private.metas.real.GAMEMODE);
end);

dismay.runwhenindexcreated("vgui", function()
	timer.Simple(1, function() -- lz
		local w = 200;
		local h = 200;
		local texture = surface.GetTextureID("gui/corner8");

		local function DrawCircle(x, y, r, col)
			G.surface.SetTexture(texture);
			G.surface.SetDrawColor(col);
			local mx = x + r;
			local my = y + r
			G.surface.DrawTexturedRectRotated(mx - r / 2, my - r / 2 , r, r, 0);
			G.surface.DrawTexturedRectRotated(mx - r / 2, my + r / 2 , r, r, 90);
			G.surface.DrawTexturedRectRotated(mx + r / 2, my + r / 2 , r, r, 180);
			G.surface.DrawTexturedRectRotated(mx + r / 2, my - r / 2 , r, r, 270);
		end

		dismay.Panels = dismay.Panels or {};

		local sqsize = 4;

		local function DrawPlayers(w, h, pixelsperunit)
			local plys = player.GetAll();
			local lp = LocalPlayer();
			local lppos = _R.Entity.GetPos(lp);
			local lpy = _R.Entity.EyeAngles(lp).y;
			lppos.z = 0;
			for i = 1, #plys do
				local v = plys[i];
				if(not _R.Player.Alive(v) or _R.Entity.Health(v) <= 0) then continue; end
				if(v == lp) then continue; end
				local ppos = _R.Entity.GetPos(v);
				ppos.z = 0;
				local dist = _R.Vector.Distance(ppos, lppos);
				local angy = _R.Vector.Angle(ppos - lppos).y;
				local d = (angy - lpy - 90) / 57;
				local xdif = -math.cos(d) * dist * pixelsperunit;
				local ydif = math.sin(d) * dist * pixelsperunit;
				local x = w / 2 + xdif - sqsize / 2;
				local y = h / 2 + ydif - sqsize / 2;
				if(x > w or y > h) then continue; end
				G.surface.DrawRect(x, y, sqsize, sqsize);
				G.surface.SetFont("BudgetLabel");
				local text = v:Nick().."("..math.Round(dist).."u)";
				local w2, h2 = G.surface.GetTextSize(text);
				G.surface.SetTextPos(x - w2 / 2, y + 2);
				G.surface.DrawText(text);
			end
		end

		local function DrawBG(w, h)
			local r = 4;
			local max = 3; -- max - 1
			local maxfade = 10;
			local bgcol = Color(57,57,57,250);
			local col = Color(255,0,0,0);
			local times = 3;
			surface.SetDrawColor(bgcol);
			surface.DrawRect(0, 0, w, h);
			for i = -((times - 1) / 2), ((times - 1) / 2) do
				local mult = math.abs(i) / (times - 1) / 2;
				bgcol.a = 250 * mult;
				bgcol.r = 57 * mult;
				bgcol.g = 57 * mult;
				bgcol.b = 57 * mult;
				--print(bgcol.a);
				surface.SetDrawColor(bgcol);
				surface.DrawLine(w / 2 + i, 0, w / 2 + i, h);
				surface.DrawLine(0, h / 2 + i, w, h / 2+ i);
			end
			DrawCircle(w / 2 - r, h / 2 - r, r, Color(235,25,0,255));
			surface.SetDrawColor(Color(122,0,0,255));
			surface.SetTextColor(Color(235, 35, 0, 255));
			DrawPlayers(w, h, 0.025);
			for i = 0, max do
				col.a = 255 * (i + 1) / (max + 1);
				surface.SetDrawColor(col);
				surface.DrawOutlinedRect(i, i, w - i * 2, h - i * 2);
			end
			for i = max + 1, maxfade do
				bgcol.a = 255 * (1 - (i+1) / (maxfade + 1));
				surface.SetDrawColor(bgcol);
				surface.DrawOutlinedRect(i, i, w - i * 2, h - i * 2);
			end
			
		end


		dismay.AddHook("HUDPaint", "Radar", function()
			if(not dismay.ShouldDrawESP()) then print("SDE: "..CurTime()); return; end
			DrawBG(w, h);
		end);
	end);
end)
dismay.runwhenindexcreated("LocalPlayer", function()
	local player_meta = FindMetaTable("Entity");
	dismay.Spread = {}
	local Spread = dismay.Spread;
	Spread.weapon_pistol 	= Vector(-0.01000, -0.01000, -0.01000);
	Spread.weapon_smg1		= Vector(-0.04362, -0.04362, -0.04362);
	Spread.weapon_ar2		= Vector(-0.02618, -0.02618, -0.02618);
	Spread.weapon_shotgun	= Vector(-0.08716, -0.08716, -0.08716);

	local old_fb = player_meta.FireBullets
	function player_meta:FireBullets(tbl)
		if(self == LocalPlayer()) then
			local c = true;
			if(self:GetActiveWeapon() and self:GetActiveWeapon().Base) then
				local b = self:GetActiveWeapon().Base or "";
				if(b == "bobs_gun_base" or b == "bobs_scoped_base" or b == "bobs_shotty_base") then
					if(tbl.Spread == Vector(0,0,0)) then
						c = false;
					end
				end
			end
			if(c) then
				dismay.Spread[self:GetActiveWeapon():GetClass()] = -(tbl.Spread or Vector(0,0,0));
			end
		end
 	    old_fb(self, tbl);
		if(dismay.FireBullets) then dismay.FireBullets(self, tbl); end
	end
	dismay.SpoofFunction(old_fb, player_meta.FireBullets);
end);

function dismay.GetSpread(wep)
	return dismay.Spread[wep:GetClass()] or Vector(0, 0, 0);
end

dismay.private.o_RenderCapture = render.Capture;

function rG.render.Capture(...)
	dismay.private.ShouldDrawESP = false;
	dismay.Repaint();
	print("RC:"..CurTime());
	local ret = dismay.private.o_RenderCapture(...);
	dismay.private.ShouldDrawESP = true;
	dismay.Repaint();
	return ret;
end

dismay.CurSpeedNum = 0;
dismay.WasSpeeding = true;
dismay.SpeedKey = false;

local function _tc(a)
	dismay._tc(a, a);
end

dismay.RunMenu([[
	dismay.SKey = dismay.SKey or KEY_G;
	dismay.RunClient("dismay.SKey = "..tostring(dismay.SKey)..";");
	dismay.RunClient("dismay.SpeedNum = "..(dismay.SpeedNum or 0)..";");
	dismay.RunClient("dismay.SpeedKey = "..(dismay.SpeedKey and "true" or "false")..";");
]]);

dismay.AddHook("CreateMove", "Speed", function(cmd)
	dismay.IsSpeeding = dismay.private.oldg.input.IsKeyDown(dismay.SKey or KEY_G) and dismay.SpeedKey;
	if(dismay.IsSpeeding) then
		if(dismay.SpeedNum > dismay.CurSpeedNum) then
			dismay.SetCmdRepState(true);
		else
			dismay.SetCmdRepState(false);
			dismay.CurSpeedNum = -1;
		end
		dismay.CurSpeedNum = dismay.CurSpeedNum + 1;
	elseif(dismay.WasSpeeding) then
		dismay.SetCmdRepState(false);
	end
	dismay.WasSpeeding = dismay.IsSpeeding;
end);

dismay.SpoofFunction(dismay.private.o_RenderCapture, render.Capture);
print("***[C] - Loaded");
dismay.runwhenindexcreated("FindMetaTable", function()
	local o = FindMetaTable("Weapon").SetNextPrimaryFire;
	local w = FindMetaTable("Weapon");
	dismay.NextPrimaryFire = {};
	function w:SetNextPrimaryFire(time, ...)
		dismay.NextPrimaryFire[self] = SysTime() + (time - CurTime()) / 4;
		return o(self, time, ...);
	end
	dismay.SpoofFunction(o, FindMetaTable("Weapon").SetNextPrimaryFire);
	dismay.RemoveHook("Think", "f");
end);

function dismay.GetNextPFire(wep)
	return dismay.NextPrimaryFire[wep] or 0;
end
print("***[C] - LOADING AIMBOAT");
dismay.runwhenindexcreated("GAMEMODE", function()
	local GetPred = dismay.GetPred;
	local IsDormant = dismay.IsDormant;
	local lp = LocalPlayer();

	local _R = debug.getregistry();

	local TraceLine = util.TraceLine;
	local LagCompensation = _R.Player.LagCompensation;

	local function IsValidTrace(trace, targ)
		return not trace.Hit or trace.Entity == targ;
	end

	local hooks = dismay.AddHook;

	local pred = true;
	local function predict(ply, pos, time)
		return pred and ply ~= LocalPlayer() and pos + ply:GetVelocity() * engine.TickInterval() or pos;
	end

	local function GetSpread(cmd, ang)
		return dismay.PredSpread(cmd, ang);
	end

	local function clamp(ang)
		ang.p = (ang.p + 180) % 360 - 180
		ang.y = (ang.y + 180) % 360 - 180
		return ang;
	end
	local ptbl = {
		endpos 	= nil;
		filter 	= {LocalPlayer(), nil};
		mask	= MASK_SHOT;
	};
	local function inbox(pos, mins, maxs)
		return pos.x >= mins.x and pos.y >= mins.y and pos.z >= mins.z and pos.x <= maxs.x and pos.y <= maxs.y and pos.z <= maxs.z;
	end
	local t = {
		filter = Entity(0);
		mask = MASK_SHOT;
	};
	local function GetBoneHitGroup(pos) -- fag die
		t.start = pos;
		t.endpos = pos + Vector(0.1, 0.1, 0.1);
		return TraceLine(t).HitGroup
	end
	local function GetPos(ply, my_pos)
		local bestpos = false
		ptbl.filter[2] = ply;
		ptbl.start = my_pos;
		local p = _R.Entity.GetPos(ply);
		local mins = _R.Entity.OBBMins(ply) + p;
		local maxs = _R.Entity.OBBMaxs(ply) + p;
		local best = 12;
		for i = 0, _R.Entity.GetBoneCount(ply) and _R.Entity.GetBoneCount(ply) - 1 or -1 do
			if(not _R.Entity.BoneHasFlag(ply, i, BONE_USED_BY_HITBOX)) then continue; end
			local pos = _R.Entity.GetBonePosition(ply, i);
			ptbl.endpos = predict(ply, pos);
			_R.Player.LagCompensation(lp, true);
			local trace_r = TraceLine(ptbl);
			_R.Player.LagCompensation(lp, false);
			local hg = GetBoneHitGroup(pos);
			if(hg == 0) then hg = 11; end
			if(IsValidTrace(trace_r, ply) and inbox(pos, mins, maxs) and hg < best) then
				bestpos = pos;
				best = hg;
			end
		end
		local peye = _R.Entity.EyeAngles(ply);
		if(peye.p >= 90 or peye.p <= -90) then --player is antiaiming
			bestpos = p + ply:OBBCenter();
		end
		
		if(not bestpos) then
			bestpos = ply:EyePos();
		end
		
		return bestpos;
	end

	local frnds = true;
	function dismay.ToggleFriends(bOn)
		frnds = bOn;
	end

	local l = false;
	function dismay.ToggleAimbot(bOn)
		l = bOn;
	end
	local teams = false;
	function dismay.ToggleTeams(bOn)
		teams = bOn;
	end
	function dismay.ToggleAimbotPred(b)
		pred = b;
	end
	dismay.RunMenu([[
		--if(not dismay.PredAimbot) then
		--	local self;
		--	self = dismay.CreateMenuItem("Toggle Prediction", function(bOn)
		--		dismay.AimbotPred = bOn;
		--		dismay.RunClient("dismay.ToggleAimbotPred("..tostring(bOn)..")");
		--	end);
		--	dismay.PredAimbot = self;
		--end
		
		if(not dismay.Aimbot) then
			local self;
			self = dismay.CreateMenuItem("Toggle aimbot", function(bOn)
				dismay.AimbotToggle = bOn;
				dismay.RunClient("dismay.ToggleAimbot("..tostring(bOn)..")");
			end);
			dismay.Aimbot = self;
		end
		if(not dismay.TeamsAimbot) then
			local self;
			self = dismay.CreateMenuItem("Toggle Teams", function(bOn)
				dismay.AimbotTeams = bOn;
				dismay.RunClient("dismay.ToggleTeams("..tostring(bOn)..")");
			end);
			dismay.TeamsAimbot = self;
		end
		if(not dismay.FriendsAimbot) then
			local self;
			self = dismay.CreateMenuItem("Toggle Friends", function(bOn)
				dismay.AimbotFriends = bOn;
				dismay.RunClient("dismay.ToggleFriends("..tostring(bOn)..")");
			end);
			dismay.FriendsAimbot = self;
		end
		dismay.RunClient("dismay.ToggleTeams("..tostring(dismay.AimbotTeams)..");");
		dismay.RunClient("dismay.ToggleAimbot("..tostring(dismay.AimbotToggle)..");");
	]]);

	dismay.RemoveHook("CreateMove", "Aimbot");

	local a = true;
	local wasshooting = false
	dismay.SetCmdSendState(true);
	dismay.SetCmdRepState(false);
	local i = 0;
	local max = 23;
	local troo = true;
	local isCrouch = false;
	
	local time = CurTime;
	local ctime = time();
	hooks("CreateMove", "Aimbot", function(cmd)
		if(time() - ctime >= 1) then collectgarbage(); ctime = time(); end
		if(not l) then 
			if(not a) then
				dismay.SetCmdSendState(true);
				dismay.SetCmdRepState(false);
				a = true; 
			end 
			return; 
		end
		a = false;
		dismay.ThisAng = (dismay.ThisAng or _R.CUserCmd.GetViewAngles(cmd));
		dismay.ThisAng = dismay.ThisAng + (_R.CUserCmd.GetViewAngles(cmd) - (dismay.LastAng or _R.CUserCmd.GetViewAngles(cmd)));
		dismay.SetCmdSendState(not dismay.GetCmdSendState());
		if(not troo) then
			cmd:SetButtons(bit.bor(cmd:GetButtons(), IN_DUCK));
		end
		local smove = _R.CUserCmd.GetSideMove(cmd);
		local fmove = _R.CUserCmd.GetForwardMove(cmd);
		if(dismay.GetCmdSendState()) then
			_R.CUserCmd.RemoveKey(cmd, IN_ATTACK);
			_R.CUserCmd.SetViewAngles(cmd, dismay.ThisAng);
		elseif(not dismay.GetCmdRepState()) then
			LagCompensation(lp, true);
			if(not lp or not lp.IsValid or not lp:IsValid()) then lp = LocalPlayer(); return; end
			local w = lp:GetActiveWeapon();
			if(lp:GetMaterial() ~= "" or not w or not w.IsValid or not w:IsValid() or lp:GetColor().a ~= 255 or lp:Health() <= 0 or not lp:Alive()) then return; end
			local lp_pos = _R.Player.GetShootPos(lp)
			local lp_ppos = predict(lp, lp_pos);
			lp_pos = lp_ppos;
			local ply, ply_pos, rang, ang;
			local plys = player.GetAll();
			for i = 1, #plys do
				ply = plys[i];
				if (frnds and _R.Player.GetFriendStatus(ply) == "friend" or IsDormant(ply) or _R.Entity.GetMaterial(ply) ~= ""  or _R.Entity.GetColor(ply).a ~= 255 or teams 
					and _R.Player.Team(ply) == _R.Player.Team(lp) or _R.Entity.Health(ply) <= 0 or ply == lp or 
					_R.Player.GetObserverMode(ply) ~= OBS_MODE_NONE) then continue; end
				ply_pos = predict(ply, GetPos(ply, lp_pos));
				rang = _R.Vector.Angle(ply_pos - lp_pos);
				ang = GetSpread(cmd, rang);
				local trace_r = TraceLine{start = lp_ppos, endpos = ply_pos, filter = {Entity(0), lp, ply}, mask = MASK_SHOT,}
				if(IsValidTrace(trace_r)) then
					cmd:SetViewAngles(clamp(ang));
					if(not cmd:KeyDown(IN_ATTACK) and not wasshooting) then
						_R.CUserCmd.SetButtons(cmd, bit.bor(_R.CUserCmd.GetButtons(cmd), IN_ATTACK));
					end
					wasshooting = not wasshooting;
					local move = Vector(fmove, smove, 0);
					local norm = move / 10000;
					local set = _R.Angle.Forward(_R.Vector.Angle(norm) + (_R.CUserCmd.GetViewAngles(cmd) - dismay.ThisAng)) * _R.Vector.Length(move);
					_R.CUserCmd.SetForwardMove(cmd, set.x);
					_R.CUserCmd.SetSideMove(cmd, set.y);
					break;
				end
			end
		end
		dismay.LastAng = _R.CUserCmd.GetViewAngles(cmd);
		LagCompensation(lp, false);
	end)
	local p;
	hooks("CalcView", "Aimbot", function(ply, pos, _, fov, x, y, ...)
		if(not l) then return; end
		if(ply and ply.IsValid and ply:IsValid() and not p) then p = pos - ply:GetPos(); end
		if(not p) then return; end
		return dismay.private.ogm.CalcView(rG.GAMEMODE or rG.GM, ply, pos, dismay.ThisAng, fov, x, y, ...);
	end);
	print("***[C] - LOADED AIMBOAT");
	dismay.LocalPlayer = nil;
end);

local function IsValidESP(ply)
	return ply:Health() > 0 and ply:Alive() and ply:GetObserverMode() == OBS_MODE_NONE;
end
local _col 				= Color(255,0,0,255);
local col_black			= Color(0,0,0,255);
local SetFont 			= surface.SetFont;
local pairs 			= pairs;
local lp 				= LocalPlayer;
local r 				= debug.getregistry();
local gp 				= r.Entity.GetPos;
local obbmx 			= r.Entity.OBBMaxs;
local obbms 			= r.Entity.OBBMins;
local toscr 			= r.Vector.ToScreen;
local ScrW 				= ScrW();
local ScrH 				= ScrH();
local ghp 				= r.Entity.Health;
local SetDrawColor 		= surface.SetDrawColor;
local SetTextColor 		= surface.SetTextColor;
local SetTextPos 		= surface.SetTextPos;
local DrawText			= surface.DrawText;
local DrawOutlinedRect 	= surface.DrawOutlinedRect;
local GetTextSize		= surface.GetTextSize;
local DrawRect			= surface.DrawRect;
local min 				= math.min;
local max 				= math.max;
local retcol = Color(0,0,0,255);

local function HealthToColor(hp)
	local g = min(max(hp * 2.55, 0), 255);
	local r = 255 - min(max((hp - 12) * 2.55, 0), 255);
	retcol.g = g;
	retcol.r = r;
	return retcol;
end

SetFont("BudgetLabel");
local _, h = GetTextSize("|ABCDEF");

dismay.RunMenu([[
	dismay.RunClient("dismay.NoESP = "..(dismay.NoESP and "true" or "false")..";");
]]);
local hud = true;
local view = {
	x = 0;
	y = 0;
	w = ScrW;
	h = ScrH;
	dopostprocess = true;
	drawhud = false;
	drawviewmodel = true;
};
dismay.private.ShouldDrawESP = true;
dismay.AddHook("HUDPaint", "ESP", function()
	if(not hud) then return; end
	if(not dismay.private.ShouldDrawESP) then 
		view.origin = G.EyePos();
		view.angles = G.EyeAngles();
		hud = false;
		render.RenderView(view);
		render.RenderHUD(0, 0, ScrW, ScrH);
		hook.Call("HUDPaint");
		hud = true;
		return;
	end
	if(dismay.NoESP) then return; end
	SetFont("BudgetLabel");
	local col, p, mn, mx, t, mostx, leastx, mosty, leasty, hp, text;
	t = {};
	for k,v in pairs(player.GetAll()) do
		if(v == lp() or not IsValidESP(v)) then continue; end
		p = gp(v);
		mn = obbms(v)
		mx = obbmx(v);
		t[1] = toscr(p + mn);
		t[2] = toscr(p + Vector(mn.x, mx.y, mn.z));
		t[3] = toscr(p + Vector(mx.x, mx.y, mn.z));
		t[4] = toscr(p + Vector(mx.x, mn.y, mn.z));
		t[5] = toscr(p + mx);
		t[6] = toscr(p + Vector(mx.x, mn.y, mx.z));
		t[7] = toscr(p + Vector(mn.x, mn.y, mx.z));
		t[8] = toscr(p + Vector(mn.x, mx.y, mx.z));
		mostx, leastx, mosty, leasty = 0,ScrW,0,ScrH;
		for i, cur in ipairs(t) do
			if(cur.x < leastx) then leastx = cur.x; end
			if(cur.y < leasty) then leasty = cur.y; end
			if(cur.x >  mostx) then  mostx = cur.x; end
			if(cur.y >  mosty) then  mosty = cur.y; end
		end
		hp = ghp(v);
		col = rG.team.GetColor(_R.Player.Team(v));
		SetDrawColor(col);
		SetTextColor(col);
		text = v:Nick();
		local w = GetTextSize(text);
		SetTextPos(mostx + 2, leasty);
		DrawText(text);
		SetTextPos(mostx + 2, leasty + h + 2);
		DrawText("H: "..tostring(hp));
		for i = 1, 2 do
			DrawOutlinedRect(leastx + i, leasty + i, (mostx - i * 2) - leastx, (mosty - i * 2) - leasty);
		end
		SetDrawColor(col_black);
		DrawOutlinedRect(leastx, leasty, mostx - leastx, mosty - leasty);
		DrawOutlinedRect(leastx + 3, leasty + 3, (mostx - 3 * 2) - leastx, (mosty - 3 * 2) - leasty);
		DrawOutlinedRect(leastx - 3, leasty, 4, mosty - leasty);
		
		SetDrawColor(HealthToColor(hp));
		local h = min(100, max(0, hp)) / 100;
		local rh = mosty - leasty - 2;
		DrawRect(leastx - 2, leasty + 1 + rh * (1 - h), 2, rh * h);
	end
end);

dismay.RunMenu([[
	if(not dismay.FullBright) then
		local self;
		self = dismay.CreateMenuItem("Toggle Fullbright", function(bOn)
			dismay.FullBrightOn = bOn;
			dismay.RunClient("dismay.FullBright = "..tostring(bOn)..";");
		end);
		dismay.FullBright = self;
	end
	dismay.RunClient("dismay.FullBright = "..tostring(dismay.FullBrightOn)..";");
]]);
dismay.AddHook("RenderScene", "fullbright", function(origin, angles, fov)
	if(not dismay.FullBright) then return; end
	render.SetLightingMode(2);
	render.RenderView{
		origin 	= origin;
		angles 	= angles;
		fov		= fov;
		x		= 0;
		y		= 0;
		w 		= ScrW;
		h		= ScrH;
		drawhud	= false;
		dopostprocess = true;
		drawmonitors = true; 
		drawviewmodel = true;
	};
	render.SetLightingMode(0);
	render.RenderHUD(0, 0, ScrW, ScrH);
	return true;
end)


dismay.HideThisFile(function() end);
dismay.RunClient([[dismay.HideThisFile(function() end)]]);