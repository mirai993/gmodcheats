--Have you ever wondered how people shot webz? well now you know...
--TODO: add a real aimbot, this one sucks

fullalphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz_";
exstr = { bot_esp = true, esp_wep = true, esp_on = true, aimbot_target = true }
function rndstring() --generates a random string that is between 4 to 10 chars only checks for conflicts with other generated strings
	local num = 0;
	local str = "bot_esp";
	while(exstr[str]) do
		str = "";
		for n=1,math.random(4,10),1 do
			num = math.random(1,53);
			str = str..string.sub(fullalphabet,num,num);
		end
	end
	exstr[str] = true;
	return str;
end
--the random table, store rnd vars in a rnd table to minimize potential conflicts...
local RNDTBL = rndstring();
while(_G[RNDTBL]) do
	RNDTBL = rndstring();
end
_G[RNDTBL] = { };
//CONSTANTS//
--vars--
local bot_on = rndstring();
local hitbox = rndstring();
local team_target = rndstring();
local esp_range = rndstring();
local BOT_colors = rndstring();
local esp_wep = rndstring();
local esp_on = rndstring();
local BOT_esp = rndstring();
local viewon = rndstring();
local view_vector = rndstring();
local view_speed = rndstring();
local aimbot_target = rndstring();
--funcs--
////

_G[RNDTBL][bot_on] = true;
_G[RNDTBL][hitbox] = 2; -- 1 is head, 2 is body
_G[RNDTBL][team_target] = false;
_G[RNDTBL][esp_range] = 4000;

local BOT_G_SEP = "@";
local BOT_I_SEP = "|";

_G[RNDTBL][BOT_colors] = { };
_G[RNDTBL][BOT_colors]["orange"] = Color(255,128,64,255);
_G[RNDTBL][BOT_colors]["purple"] = Color(181,62,193,255);
_G[RNDTBL][BOT_colors]["green"] = Color(0,255,0,255);
_G[RNDTBL][BOT_colors]["red"] = Color(255,0,0,255);
_G[RNDTBL][BOT_colors]["blue"] = Color(0,0,255,255);
_G[RNDTBL][BOT_colors]["yellow"] = Color(255,255,0,255);
_G[RNDTBL][BOT_colors]["maroon"] = Color(128,0,64,255);
_G[RNDTBL][BOT_colors]["lightblue"] = Color(0,255,255,255);
_G[RNDTBL][BOT_colors]["lightred"] = Color(255,128,128,255);
_G[RNDTBL][BOT_colors]["lightgreen"] = Color(128,255,128,255);
_G[RNDTBL][BOT_colors]["darkblue"] = Color(0,0,128,255);
_G[RNDTBL][BOT_colors]["darkred"] = Color(128,0,0,255);
_G[RNDTBL][BOT_colors]["darkgreen"] = Color(0,128,0,255);

if (file.Exists( "tacobot_cfg.txt" )) then
	local readcfg = string.Explode(BOT_G_SEP,file.Read("tacobot_cfg.txt"));
	_G[RNDTBL][hitbox] = tonumber(readcfg[1]);
	readcfg[2] = string.Explode(BOT_I_SEP,readcfg[2]);
	if (readcfg[2] != "") then
		_G[RNDTBL][BOT_esp] = { };
		for n=1,#readcfg[2],2 do
			_G[RNDTBL][BOT_esp][readcfg[2][n]] = readcfg[2][n+1];
		end
	end
	_G[RNDTBL][esp_range] = tonumber(readcfg[3]);
end

local BOT_save = rndstring();
_G[RNDTBL][BOT_save] = function()
	local espfavs = "";
	if (_G[RNDTBL][BOT_esp]) then
		for k, v in pairs(_G[RNDTBL][BOT_esp]) do
			espfavs = espfavs..BOT_I_SEP..k..BOT_I_SEP..v;
		end
		espfavs = string.sub(espfavs,2);
	end
	file.Write( "tacobot_cfg.txt", tostring(_G[RNDTBL][hitbox])..BOT_G_SEP..espfavs..BOT_G_SEP..tostring(_G[RNDTBL][esp_range]) );
end

local function setaimbot( ply, cmd, args )
	_G[RNDTBL][bot_on] = true;
	if (args[1] == "0") then
		_G[RNDTBL][bot_on] = false;
	end
end
concommand.Add( "aimbot_on", setaimbot );

local function setesp( ply, cmd, args )
	_G[RNDTBL][esp_on] = true;
	if (args[1] == "0") then
		_G[RNDTBL][esp_on] = false;
	end
end
concommand.Add( "aimbot_esp", setesp );

local function setwepesp( ply, cmd, args )
	_G[RNDTBL][esp_wep] = true;
	if (args[1] == "0") then
		_G[RNDTBL][esp_wep] = false;
	end
end
concommand.Add( "aimbot_esp_weapon", setwepesp );

local function setentesp( ply, cmd, args )
	if (#args < 2) then
		Msg( "Usage: aimbot_esp_entities <entity classname> <1 or 0> <color (orange, purple, green, black, ect.)>, type aimbot_esp_entityhelp to show a list of common entities\n" );
		return;
	end
	if !(tonumber(args[2])) then
		Msg( "Usage: aimbot_esp_entities <entity classname> <1 or 0> <color (orange, purple, green, black, ect.)>, type aimbot_esp_entityhelp to show a list of common entities\n" );
		return;
	end
	if (args[2] == "1") then
		if !(args[3]) then
			Msg( "Specify a color\n" );
			return;
		end
		if !(_G[RNDTBL][BOT_colors][args[3]]) then
			Msg( "Invalid color, use one of these:\n" );
			for k, v in pairs(BOT_color) do
				Msg( k.."\n" );
			end
			return;
		end
		if !(_G[RNDTBL][BOT_esp]) then
			_G[RNDTBL][BOT_esp] = { };
		end
		_G[RNDTBL][BOT_esp][args[1]] = args[3];
		Msg( "Showing entities with classname: "..args[1].."\n\n" );
		Msg( ":::::::::::Currently showing:::::::::::::::::\n" );
		for k, v in pairs(_G[RNDTBL][BOT_esp]) do
			Msg( k.."\n" );
		end
	else
		if (_G[RNDTBL][BOT_esp][args[1]]) then
			_G[RNDTBL][BOT_esp][args[1]] = nil;
			Msg( "No longer showing entities with a classname of "..args[1].."\n" );
			local found = false;
			for k, v in pairs(_G[RNDTBL][BOT_esp]) do
				return;
			end
			_G[RNDTBL][BOT_esp] = nil;
		else
			Msg( "The classname "..args[1].." was not on the show list\n" );
		end
	end
	_G[RNDTBL][BOT_save]();
end
concommand.Add( "aimbot_esp_setent", setentesp );

local function showentesp( ply, cmd, args )
	if (_G[RNDTBL][BOT_esp]) then
		Msg( "Drawing the following classnames on the esp hook\n-------------------------------------------\n" );
		for k, v in pairs(_G[RNDTBL][BOT_esp]) do
			Msg( k.."\n" );
		end
	else
		Msg( "No classnames have been applyed to the esp hook\nUse aimbot_esp_setent <classname> <color>\n" );
	end
end
concommand.Add( "aimbot_esp_showents", showentesp );

local function BOT_showentityhelp( ply, cmd, args )
	Msg( "Here are some common classnames (not all classnames in the game are shown)\n" );
	Msg( "Description - classname\n\n" );
	Msg( "Garry's mod button - gmod_button\n" );
	Msg( "Normal button - func_button" );
	Msg( "Physics prop - prop_physics\n" );
	Msg( "Pistol - weapon_pistol\n" );
	Msg( "Smg - weapon_smg1\n" );
	Msg( "Ar2 - weapon_ar2\n" );
	Msg( "Combine Soldier NPC - npc_combine_s\n" );
	Msg( "Zombie - npc_zombie\n" );
	Msg( "Moving bursh entity - func_movelinear\n" );
	Msg( "Brush door - func_door\n" );
	Msg( "Garry's mod thruster - gmod_thruster\n" );
	Msg( "For more classnames create an entity in Hammer and browze all the classes\n" );
	Msg( "You can also find many gmod entities by browzing garrysmod.gcf in gamemodes/sandbox/entities\n" );
	Msg( "The folders are the names of the class if you cannot find what you want\n" );
end
concommand.Add( "aimbot_esp_entityhelp", BOT_showentityhelp );

local function setesprange( ply, cmd, args )
	_G[RNDTBL][esp_range] = tonumber(args[1]);
	_G[RNDTBL][BOT_save]();
	Msg( "range is set to "..args[1].." pixels\n" );
end
concommand.Add( "aimbot_esp_range", setesprange );

local function sethitbox( ply, cmd, args )
	_G[RNDTBL][hitbox] = 1;
	if (args[1] == "body") then
		_G[RNDTBL][hitbox] = 2;
	end
	_G[RNDTBL][BOT_save]();
end
concommand.Add( "aimbot_hitbox", sethitbox );

local function setteamtarget( ply, cmd, args )
	_G[RNDTBL][team_target] = true;
	if (args[1] == "0") then
		_G[RNDTBL][team_target] = false;
	end
end
concommand.Add( "aimbot_target_teamates", setteamtarget );

local OFFSET_VECTOR = Vector( 0, 0, 50 );


local function aim_atclosest( ply, cmd, args )
	local closest = 100000;
	local trace = { start = LocalPlayer():EyePos(), endpos = 0, filter = LocalPlayer() };
	for k, v in ipairs( player.GetAll() ) do
		trace.endpos = v:GetPos() + OFFSET_VECTOR;
		if (v:Alive() && v ~= LocalPlayer() && util.TraceLine(trace).Entity == v) then
			if (!_G[RNDTBL][team_target]) then
				if (v:Team() ~= LocalPlayer():Team()) then
					if (LocalPlayer():EyePos():Distance( v:EyePos() )<closest) then
						closest = LocalPlayer():EyePos():Distance( v:EyePos() );
						_G[RNDTBL][aimbot_target] = v;
					end
				end
			else
				if (LocalPlayer():EyePos():Distance( v:EyePos() )<closest) then
					closest = LocalPlayer():EyePos():Distance( v:EyePos() );
					_G[RNDTBL][aimbot_target] = v;
				end
			end
		end
	end
	if (closest == 100000) then
		Msg( "The aimbot did not find a suitable target" );
		_G[RNDTBL][aimbot_target] = nil;
		return;
	end
	Msg( "The aimbot is now targeting ".._G[RNDTBL][aimbot_target]:Nick().."\n" );
end
concommand.Add( "aimbot_target_closest", aim_atclosest );

local function aim_clear( ply, cmd, args )
	_G[RNDTBL][aimbot_target] = nil;
	Msg( "Aimbot is not targeting any players\n" );
end
concommand.Add( "aimbot_target_clear", aim_clear );

local botfont = rndstring();
surface.CreateFont( "Arial", 12, 400, true, false, botfont );

local trace_aim = rndstring();
_G[RNDTBL][trace_aim] = function( length )
	local trace = { };
	trace.start = LocalPlayer():EyePos();
	trace.endpos = trace.start + LocalPlayer():GetAimVector()*length;
	trace.filter = LocalPlayer();
	
	return util.TraceLine( trace );
end
local goodweps = rndstring();
_G[RNDTBL][goodweps] = { };
_G[RNDTBL][goodweps]["HonorStick"] = true;
_G[RNDTBL][goodweps]["ts_hands"] = true;
_G[RNDTBL][goodweps]["ts_keys"] = true;
_G[RNDTBL][goodweps]["ts_medic"] = true;
_G[RNDTBL][goodweps]["weapon_physgun"] = true;
_G[RNDTBL][goodweps]["weapon_physcannon"] = true;

local specweps = rndstring();
_G[RNDTBL][specweps] = { };
_G[RNDTBL][specweps]["gmod_tool"] = true;
_G[RNDTBL][specweps]["weapon_ts_zipties"] = true;

local bot_alpha_ticks = rndstring();
_G[RNDTBL][bot_alpha_ticks] = 0;
local bot_alpha_inc = rndstring();
_G[RNDTBL][bot_alpha_inc] = 1;

local hookdraw = rndstring();
_G[RNDTBL][hookdraw] = function()
	if (_G[RNDTBL][aimbot_target]) then
		if (_G[RNDTBL][bot_on]) then
			if (_G[RNDTBL][aimbot_target]:Alive()) then
				if (_G[RNDTBL][hitbox] == 1) then
					LocalPlayer():SetEyeAngles( ((_G[RNDTBL][aimbot_target]:GetAttachment(1).Pos + _G[RNDTBL][aimbot_target]:GetAngles():Forward() * -4)-LocalPlayer():GetShootPos()):Angle() );
				else
					LocalPlayer():SetEyeAngles( ((_G[RNDTBL][aimbot_target]:GetPos()+OFFSET_VECTOR)-LocalPlayer():GetShootPos()):Angle() );
				end
			end
		end
	end
	if (_G[RNDTBL][esp_on]) then
		surface.SetFont( botfont );
		local tr = _G[RNDTBL][trace_aim](2000);
		local base = 0;
		local noshow = { };
		if (tr.HitNonWorld) then
			if (tr.Entity:IsPlayer() && tr.Entity != esp_avoid) then
				base = tr.Entity:EyePos():ToScreen();
				local teamcol = team.GetColor(tr.Entity:Team());
				surface.SetTextColor( teamcol.r, teamcol.g, teamcol.b, teamcol.a );
				surface.SetTextPos( base.x+5, base.y-12 );
				surface.DrawText( tr.Entity:Nick() );
				surface.SetTextColor( 20, 163, 38, 255 );
				surface.SetTextPos( base.x+15, base.y );
				surface.DrawText( "Strength:"..tostring(math.floor(tr.Entity:GetNWFloat( "stat.Strength" ))) );
				surface.SetTextPos( base.x+15, base.y+14 );
				surface.DrawText( "Speed:"..tostring(math.floor(tr.Entity:GetNWFloat( "stat.Speed" ))) );
				surface.SetTextPos( base.x+15, base.y+28 );
				surface.DrawText( "Sprint:"..tostring(math.floor(tr.Entity:GetNWFloat( "stat.Sprint" ))) );
				surface.SetDrawColor( 255, 0, 0, 255 );
				surface.DrawRect( base.x+15, base.y-16, 50, 5 );
				surface.SetDrawColor( 0, 255, 0, 255 );
				surface.DrawRect( base.x+15, base.y-16, tr.Entity:Health()*.5, 5 );
				surface.SetTextPos( base.x+15, base.y-48 );
				surface.DrawText( "$"..tostring(tr.Entity:GetNWFloat("money")) );
				surface.SetTextPos( base.x+70, base.y-16 );
				surface.DrawText( "HP: "..tostring(tr.Entity:Health()) );
				for k, v in ipairs(tr.Entity:GetWeapons()) do
					noshow[v] = true;
					local wepc = v:GetClass();
					if (_G[RNDTBL][goodweps][wepc]) then
						surface.SetTextColor( 20, 163, 38, 255 );
					elseif (_G[RNDTBL][specweps][wepc]) then
						surface.SetTextColor( 0, 0, 255, 255 );
					else
						surface.SetTextColor( 255, 0, 0, 255 );
					end
					surface.SetTextPos( base.x+60, base.y+((k-1)*14) );
					surface.DrawText( v:GetClass() );
				end
				tr = tr.Entity;
			else
				tr = LocalPlayer();
			end
		else
			tr = LocalPlayer();
		end
		surface.SetDrawColor( 255, 0, 0, 255 );
		for k, v in ipairs( player.GetAll() ) do
			if (v == LocalPlayer()) then
				for kk, vv in ipairs(v:GetWeapons()) do
					noshow[vv] = true;
				end
			else
				if (v:Alive() && v ~= tr && v ~= esp_avoid) then
					if (v:EyePos():Distance(LocalPlayer():EyePos())<_G[RNDTBL][esp_range]) then
						base = v:EyePos():ToScreen();
						local teamcol = team.GetColor( v:Team() );
						surface.DrawRect( base.x-5, base.y-5, 10, 10 );
						surface.SetTextColor( teamcol.r, teamcol.g, teamcol.b, 255 );
						surface.SetTextPos( base.x, base.y+5 );
						surface.DrawText( v:Nick() );
						surface.SetTextPos( base.x, base.y-14 );
						surface.DrawText( tostring(math.Round(v:EyePos():Distance(LocalPlayer():EyePos()))) );
						for kk, vv in ipairs(v:GetWeapons()) do
							noshow[vv] = true;
						end
					end
				end
			end
		end
		if (_G[RNDTBL][BOT_esp] || _G[RNDTBL][esp_wep]) then
			_G[RNDTBL][bot_alpha_ticks] = _G[RNDTBL][bot_alpha_ticks] + _G[RNDTBL][bot_alpha_inc];
			if (_G[RNDTBL][bot_alpha_ticks] <= 0) then
				_G[RNDTBL][bot_alpha_inc] = 1;
			elseif (_G[RNDTBL][bot_alpha_ticks] >= 180) then
				_G[RNDTBL][bot_alpha_inc] = -1;
			end
			for k, v in ipairs( ents.GetAll() ) do
				if (v:GetPos():Distance(LocalPlayer():EyePos())<_G[RNDTBL][esp_range]) then
					if (_G[RNDTBL][BOT_esp]) then
						if (_G[RNDTBL][BOT_esp][v:GetClass()]) then
							if (!noshow[v]) then
								local col = _G[RNDTBL][BOT_colors][_G[RNDTBL][BOT_esp][v:GetClass()]];
								surface.SetDrawColor( col.r, col.g, col.b, col.a-_G[RNDTBL][bot_alpha_ticks] );
								local base = v:GetPos():ToScreen();
								surface.DrawRect(base.x-4, base.y-4, 8, 8);
								surface.SetTextColor( col.r, col.g, col.b, col.a );
								surface.SetTextPos( base.x, base.y+2 );
								surface.DrawText( v:GetClass() );
							end
						end
					end
					if (_G[RNDTBL][esp_wep]) then
						if (v:IsWeapon() && !noshow[v]) then
							surface.SetDrawColor( 0, 0, 255, 255 );
							local base = v:GetPos():ToScreen();
							surface.DrawRect(base.x-4, base.y-4, 8, 8);
							surface.SetTextColor( 80, 80, 80, 255 );
							surface.SetTextPos( base.x, base.y+2 );
							surface.DrawText( v:GetClass() );
						end
					end
				end
			end
		end
	end
end
hook.Add( "HUDPaint", rndstring(), _G[RNDTBL][hookdraw] );

-------------------------------------------
--view manipulation
-------------------------------------------

_G[RNDTBL][viewon] = false;
_G[RNDTBL][view_vector] = Vector(0,0,0);
_G[RNDTBL][view_speed] = 10;
local worldpanel = vgui.GetWorldPanel()

local refreshspeed = rndstring();
local function resetforwardspeed()
	LocalPlayer():ConCommand( "cl_forwardspeed 10000" );
	resetforwardspeed = nil;
	hook.Remove( "Think", refreshspeed );
end
hook.Add( "Think", refreshspeed, resetforwardspeed );

--function panel_exitroam()
--	LocalPlayer():ConCommand( "view_on 0" );
--end

local function view_set( ply, cmd, args )
	if (args[1] == "1") then
		if (_G[RNDTBL][viewon]) then return; end
		_G[RNDTBL][viewon] = vgui.Create("Frame");
		_G[RNDTBL][viewon]:SetParent( worldpanel );
		_G[RNDTBL][viewon]:SetPos( ScrW()-100, 20 );
		_G[RNDTBL][viewon]:SetSize( 80, 80 );
		_G[RNDTBL][viewon]:SetMouseInputEnabled( false );
		_G[RNDTBL][viewon]:SetKeyboardInputEnabled( false );
		_G[RNDTBL][viewon]:SetVisible( true );
		local bpanel = vgui.Create("Button");
		bpanel:SetParent(_G[RNDTBL][viewon]);
		bpanel:SetPos( 0, 0 );
		bpanel:SetSize( 80, 80 );
		bpanel:SetText( "Roaming..." );
		bpanel:SetCommand("!");
		--bpanel:SetActionFunction(panel_exitroam);
		bpanel:SetVisible( true );
		LocalPlayer():ConCommand( "cl_forwardspeed 0" );
		Msg( "View roaming activated\n" );
	else
		_G[RNDTBL][viewon]:Remove();
		_G[RNDTBL][viewon] = nil;
		_G[RNDTBL][view_vector] = Vector(0,0,0);
		LocalPlayer():ConCommand( "cl_forwardspeed 10000" );
		Msg( "View roaming deactivated\n" );
	end
end
concommand.Add( "view_on", view_set );

local function view_set_speed( ply, cmd, args )
	if (#args < 1 || !tonumber(args[1])) then
		Msg( "Usage: view_speed <number>\nrate in which the view moves\n" );
		return;
	end
	_G[RNDTBL][view_speed] = tonumber(args[1]);
end
concommand.Add( "view_speed", view_set_speed );

local BOT_findplayer = rndstring();
_G[RNDTBL][BOT_findplayer] = function( str )
	local foundply = false;
	for k, v in ipairs(player.GetAll()) do
		if (v:IsValid()) then
			if (string.find(v:Nick(),str)) then
				if (foundply) then
					Msg( "Multiple players with "..str.." in their name, cannot continue\n" );
					return false;
				end
				foundply = v;
			end
		end
	end
	if (foundply) then
		return foundply;
	end
	Msg( "Cannot find a player with "..str.." in their name\n" );
	return false;
end

local function view_goto_player(ply, cmd, args)
	if (#args < 1) then
		Msg( "Usage: view_goto <part or all of players name>\nsets the view to the player's position spaces are allowed CaSe SeNsItIvE" );
		return;
	end
	args = table.concat(args," ");
	local fply = _G[RNDTBL][BOT_findplayer](args);
	if (fply) then
		_G[RNDTBL][view_vector] = fply:EyePos()-LocalPlayer():EyePos();
		Msg( "Went to "..fply:Nick().."\n" );
	end
end
concommand.Add( "view_goto", view_goto_player );

local function hookview( ply, org, ang, fov )
	if (_G[RNDTBL][viewon]) then
		local view = { angles = ang };
		if (LocalPlayer():KeyDown(IN_FORWARD)) then
			_G[RNDTBL][view_vector] = _G[RNDTBL][view_vector]+(view.angles:Forward()*_G[RNDTBL][view_speed]);
		elseif (LocalPlayer():KeyDown(IN_BACK)) then
			_G[RNDTBL][view_vector] = _G[RNDTBL][view_vector]+(view.angles:Forward()*-1*_G[RNDTBL][view_speed]);
		end
		if (LocalPlayer():KeyDown(IN_MOVELEFT)) then
			_G[RNDTBL][view_vector] = _G[RNDTBL][view_vector]+(view.angles:Right()*-1*_G[RNDTBL][view_speed]);
		elseif (LocalPlayer():KeyDown(IN_MOVERIGHT)) then
			_G[RNDTBL][view_vector] = _G[RNDTBL][view_vector]+(view.angles:Right()*_G[RNDTBL][view_speed]);
		end
		view.origin = org+_G[RNDTBL][view_vector];
		return view;
	end
end
hook.Add( "CalcView", rndstring(), hookview );

--clear non random names--
fullalphabet = nil;
exstr = nil;
rndstring = nil;
----