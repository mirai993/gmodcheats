
if SERVER then return end

--[[
dHack(deaglerHack)
A hack created by Deagler. 
Chances are a lot of this will be ideas from other hacks.

Now that I've started making this 
I swear to not c+p any code at all
Began on 1/4/2014


I really love gInject and admire Yuuki, He's a pretty great Lua coder.
He made a great cheat and I'm basically going to be re-writing and improving it as dHack.

At the beginning some of this will be gInject, As I go on and get to the point 
I can create a better version of it I will replace the gInject code with my own though I don't intend to use much of his code.
At the moment none of the code is ripped from gInject
]]--
local function lolcopy(t, lookup_table)
        if (t == nil) then return nil end
        
        local copy = {}
        _G.setmetatable(copy, _G.getmetatable(t))
        for i,v in _G.pairs(t) do
                if ( !istable(v) ) then
                        copy[i] = v
                else
                        lookup_table = lookup_table or {}
                        lookup_table[t] = copy
                        if lookup_table[v] then
                                copy[i] = lookup_table[v] -- we already copied this table. reuse the copy.
                        else
                                copy[i] = lolcopy(v,lookup_table) -- not yet copied. copy it.
                        end
                end
        end
        return copy
end

local g = lolcopy(_G)

local d = {}
d.version = "1.1.7"
d.overview = {}
g.http.Fetch("http://dhack.hexhosting.com/dHack/enabled.txt", function(body) 
	if body == d.version then 
		g.MsgC(g.Color(0,255,0,255),"dHack is up to date!\nVersion: "..d.version.."\n")
		d:SetDef()
		
	else
		g.MsgC(g.Color(255,0,0,255),"dHack is outdated!\nYou are on version: "..d.version.."\nLatest version: "..body.."\n")
	end
end, function(code) 
g.MsgC(g.Color(255,128,0,255),"HTTP Fetch failed.\n Error Code: "..tostring(code).."\n")

end )


function d:SetDef()

g.surface.CreateFont( "dFONT1", {
font = "Bebas Neue",
size = 22,
weight = 50,
antialias = true
} )

g.surface.CreateFont( "dFONT2", {
font = "Bebas Neue",
size = 17,
weight = 50,
antialias = true
} )

d.target1=nil
d.reload1 = CurTime()
d.typing = false
d.aimbot = false
d.collide = false
d.addprop = false
d.removeprop = false
d.espents = {}
d.friends = {}
d.log = {}
d.console = false
d.menuopen = false
d.str = "[dHack "..d.version.."]"
d.trigger1 = false
d.esp1 = false
d.configs = {}
d.blockedcmds = {
"onion_cheat_check",
"_Sharkeys",
"__ac",
"__imacheater",
"gm_possess",
"__uc_",
"_____b__c",
"___m",
"sc",
"bg",
"bm",
"kickme",
"gw_iamacheater",
"imafaggot",
"birdcage_browse",
"reportmod",
"_fuckme",
"st_openmenu",
"_NOPENOPE",
"__ping",
"ar_check",
"GForceRecoil",
"~__ac_auth",
"blade_client_check",
"blade_client_detected_message",
"disconnect",
"exit",
"retry",
"kill",
"dac_imcheating", 
"dac_pleasebanme", 
"excl_banme"
}
d.noreload = {
"weapon_physgun",
"weapon_gravgun",
"toolgun",
"pocket",
"crowbar",
"keys"
}
d.chars = { 
[1] = {char = "a", val = KEY_A}, 
[2] = {char = "b", val = KEY_B}, 
[3] = {char = "c", val = KEY_C}, 
[4] = {char = "d", val = KEY_D}, 
[5] = {char = "e", val = KEY_E}, 
[6] = {char = "f", val = KEY_F}, 
[7] = {char = "g", val = KEY_G}, 
[8] = {char = "h", val = KEY_H}, 
[9] = {char = "i", val = KEY_I}, 
[10] = {char = "j", val = KEY_J}, 
[11] = {char = "k", val = KEY_K}, 
[12] = {char = "l", val = KEY_L}, 
[13] = {char = "m", val = KEY_M}, 
[14] = {char = "n", val = KEY_N}, 
[15] = {char = "o", val = KEY_O}, 
[16] = {char = "p", val = KEY_P}, 
[17] = {char = "q", val = KEY_Q}, 
[18] = {char = "r", val = KEY_R}, 
[19] = {char = "s", val = KEY_S}, 
[20] = {char = "t", val = KEY_T}, 
[21] = {char = "u", val = KEY_U}, 
[22] = {char = "v", val = KEY_V}, 
[23] = {char = "w", val = KEY_W}, 
[24] = {char = "x", val = KEY_X}, 
[25] = {char = "y", val = KEY_Y}, 
[26] = {char = "z", val = KEY_Z}, 
[27] = {char = "space", val = KEY_SPACE}, 
[28] = {char = "tab", val = KEY_TAB}, 
[29] = {char = "lshift", val = KEY_LSHIFT}, 
[30] = {char = "rshift", val = KEY_RSHIFT}, 
[31] = {char = "lalt", val = KEY_LALT}, 
[32] = {char = "ralt", val = KEY_RALT}, 
[33] = {char = ",", val = KEY_COMMA}, 
[34] = {char = ".", val = KEY_PERIOD}, 
[35] = {char = "/", val = KEY_SLASH}, 
[36] = {char = "[", val = KEY_LBRACKET}, 
[37] = {char = ";", val = KEY_SEMICOLON}, 
[38] = {char = "'", val = KEY_APOSTROPHE},
[39] = {char = "F1", val = KEY_F1},
[40] = {char = "F2", val = KEY_F2},
[41] = {char = "F3", val = KEY_F3},
[42] = {char = "F4", val = KEY_F4},
[43] = {char = "F5", val = KEY_F5},
[43] = {char = "F6", val = KEY_F6},
[44] = {char = "F7", val = KEY_F7},
[45] = {char = "F8", val = KEY_F8},
[46] = {char = "F9", val = KEY_F9},
[47] = {char = "F10", val = KEY_F10},
[48] = {char = "F11", val = KEY_F11},
[48] = {char = "F12", val = KEY_F12},
[49] = {char = "KEYPAD_0", val = KEY_PAD_0},
[50] = {char = "KEYPAD_.", val = KEY_PAD_DECIMAL},
[51] = {char = "KEYPAD_INSERT", val = KEY_PAD_0},
[52] = {char = "KEYPAD_DELETE", val = KEY_PAD_DECIMAL},
[53] = {char = "KEYPAD_1", val = KEY_PAD_1},
[54] = {char = "KEYPAD_END", val = KEY_PAD_1},
[55] = {char = "KEYPAD_2", val = KEY_PAD_2},
[56] = {char = "KEYPAD_DOWNARROW", val = KEY_PAD_2},
[57] = {char = "KEYPAD_3", val = KEY_PAD_3},
[58] = {char = "KEYPAD_PAGEDOWN", val = KEY_PAD_3},
[59] = {char = "KEYPAD_4", val = KEY_PAD_4},
[60] = {char = "KEYPAD_LEFTARROW", val = KEY_PAD_4},
[61] = {char = "KEYPAD_5", val = KEY_PAD_5},
[62] = {char = "KEYPAD_6", val = KEY_PAD_6},
[63] = {char = "KEYPAD_RIGHTARROW", val = KEY_PAD_6},
[64] = {char = "KEYPAD_7", val = KEY_PAD_7},
[65] = {char = "KEYPAD_HOME", val = KEY_PAD_7},
[66] = {char = "KEYPAD_9", val = KEY_PAD_9},
[67] = {char = "KEYPAD_PGUP", val = KEY_PAD_9},
[68] = {char = "NUMLOCK", val = KEY_NUMLOCKTOGGLE},
[69] = {char = "KEYPAD_/", val = KEY_PAD_DIVIDE},
[70] = {char = "KEYPAD_*", val = KEY_PAD_MULTIPLY},
[71] = {char = "KEYPAD_-", val = KEY_PAD_MINUS},
[72] = {char = "KEYPAD_+", val = KEY_PAD_PLUS},
[73] = {char = "KEYPAD_ENTER", val = KEY_PAD_ENTER},
[74] = {char = "Insert", val = KEY_INSERT},
[75] = {char = "PageUp", val = KEY_PAGEUP},
[76] = {char = "PageDown", val = KEY_PAGEDOWN},
[75] = {char = "End", val = KEY_END},
[76] = {char = "Delete", val = KEY_DELETE},
[77] = {char = "KEYPAD_8", val = KEY_PAD_8},
[78] = {char = "KEYPAD_UPARROW", val = KEY_PAD_8},
[79] = {char = "None", val = KEY_NONE},
}
d.cmds = {
["help"] = {type="(Command)",usage="help or help <command>",help="Get help or info on any command.",example="help bind"},
["bind"] = {type="(String+String)",usage="bind <key> <action>",help="Bind any action from the list of actions to a key.",example="bind j +menu"},
["unbind"] = {type="(String)",usage="unbind <action> or bind none <action>",help="Unbind a previous or default bind",example="unbind toggle_esp"},
["ra_hack"] = {type="(String+Number)",usage="ra_hack <account#> <amount>",help="Hack RealisticATMs by RocketMania",example="ra_hack 2335-9328 5000"},
["addentity"] = {type="(String)",usage="addentity <classname>",help="Manually add an entity to the ESP by classname",example="addentity spawned_money"},
["collideprop"] = {type="(Command)",usage="collideprop",help="Collides the prop you are looking at",example="collideprop"},
["unbindall"] = {type="(Command)",usage="unbindall",help="Unbinds everything.",example="unbindall"},
["runcl"] = {type="(String)",usage="runcl <luastring>",help="Allows you to run Lua Code(Only use this if you actually know how.)",example="runcl [[print(\'Hello World\')]]"},
["melon_addcount"] = {type="(Number)",usage="melon_addcount <amount>",help="Allows you to add Melon Clicks to your count(Server must have Melon Clicker addon)",example="melon_addcount 5000"},
["melon_addpoints"] = {type="(Number)",usage="melon_addpoints <amount>",help="Allows you to add Melon Pointshop points to your count(Server must have Melon Clicker addon)",example="melon_addpoints 5000"},
["mde_openeditor"] = {type="(Command)",usage="mde_openeditor",help="Opens the RX Map Editor(Delete/Respawn all PermaProps)(Server must have RocketMania Map Editor)",example="mde_openeditor"},
["mde_addprop"] = {type="(Command)",usage="mde_addprop",help="Makes the prop you are looking at a PermaProp.(Server must have RocketMania Map Editor)",example="mde_addprop"},
["mde_removeprop"] = {type="(Command)",usage="mde_removeprop",help="Removes the prop you are looking at from being a PermaProp.(Server must have RocketMania Map Editor)",example="mde_removeprop"},
["crashall"] = {type="(Command)",usage="crashall",help="Crashes everyone in your server but you(Server must have RocketMania Map Editor)",example="crashall"},
["crashply"] = {type="(String)",usage="crashply <name>",help="Crashes a player of your choice(Server must have RocketMania Map Editor)",example="crashply deag"},
["extended_lastdced"] = {type="(Command)",usage="extended_lastdced",help="Displays the IP addresses+SteamIDs of the last few people that disconnected(Server must have ULX Extended)",example="extended_lastdced"},
["custom_lastdced"] = {type="(Command)",usage="custom_lastdced",help="Displays the IP addresses+SteamIDs of the last few people that disconnected(Server must have ULX Custom Commands)",example="custom_lastdced"},
["netinfo"] = {type="(Command)",usage="netinfo",help="Displays the net.Receivers info(Check what addons the server has)",example="netinfo"},
["commandinfo"] = {type="(Command)",usage="commandinfo",help="Displays the commands on the server (Check what commands are created on you)",example="commandinfo"},
}


d.binds = {
	["menu"] = {key=KEY_J,what="Opens the dHack Menu"},
	["+bhop"] = {key=KEY_SPACE,what="Auto-Bunnyhop"},
	["collideprop"] = {key=KEY_G,what="Collides the prop you are looking at"},
	["+aim"] = {key=KEY_Z,what="Hold this down to aimbot through everyone"},
	["toggle_trigger"] = {key=KEY_X,what="Toggle the dHack Triggerbot"},
	["toggle_esp"] = {key=KEY_M,what="Toggle the dHack ESP/Wallhack"},
	["map_addprop"] = {key=KEY_COMMA,what="Make the entity you are looking at permanent(Server must have RocketMania Map Editor)"},
	["map_removeprop"] = {key=KEY_PERIOD,what="Stop the entity you are looking at from being permanent(Server must have RocketMania Map Editor)"}
}

d.bools = {
	["bhop"] = true,
	["norecoil"] = false,

	["aimbot"] = false,
	["aimatteam"] = false,
	["aimatfriends"] = false,
	["autoshoot"] = false,
	["aautoreload"] = false,
	["aimplayer"] = false,
	["aimnpc"] = false,
	["antisnap"] = false,

	


	["triggerbot"] = false,
	["triggerplayer"] = false,
	["triggernpc"] = false,
	["tautoreload"] = false,

	["esp"] = true, 
	["eplayers"] = true,
	["enpcs"] = false,
	["eents"] = false,
	["ename"] = true,
	["erank"] = false,
	["ewep"] = false,
	["ehealth"] = true,
	["earmour"] = false,
	["erpcash"] = false,
	["epoints"] = false,
	["ehealthb"] = false,
	
	["wallhack"] = false, 
	["wplayers"] = true,
	["wnpcs"] = false,
	["wents"] = false,
	["wprops"] = false,
	
	["crosshair"] = false,
	["chealth"] = false,
	["carmour"] = false,
	["crpcash"] = false,
	["cpoints"] = false,
	["cshots"] = false,
	
	["logrcc"] = true,
	["blockacs"] = true,
	["blockss"] = true,
	
	
	


}

d.vars = { 
	["aimx"] = 7, 
	["aimy"] = 1, 
	["aimz"] = 61, 
	["aimfov"] = 45, 
	["antisnap"] = 0.2, 
	["adistance"] = 5000,
	["aimdistance"] = 5000, 
	["aimantisnap"] = 0.2, 
	["aimbone"] = "Head",
	["triggertype"] = "Head",

	["esptextdist"] = 15000, 
	["espbox"] = "3D", 
	["esptype"] = "Body", 
	["esphlocation"] = "Bottom", 
	["esphdist"] = 500,
	
	["espwtype"] = "Solid",
	["espwdist"] = 2000,

}
--d:AddVarComboBox(aimbot, "aimbone", "Mode:", {"Head","Chest","Offsets"}, 250, 15, 100)
d.bones = {
["Head"] = "ValveBiped.Bip01_Head1",
["Neck"] = "ValveBiped.Bip01_Neck1",
["Spine"] = "ValveBiped.Bip01_Spine",
["Spine1"] = "ValveBiped.Bip01_Spine1",
["Spine2"] = "ValveBiped.Bip01_Spine2",
["Spine4"] = "ValveBiped.Bip01_Spine4",
["Pelvis"] ="ValveBiped.Bip01_Pelvis",
["R Upperarm"] = "ValveBiped.Bip01_R_UpperArm",
["R Forearm"] = "ValveBiped.Bip01_R_Forearm",
["R Hand"] = "ValveBiped.Bip01_R_Hand",
["L Upperarm"] = "ValveBiped.Bip01_L_UpperArm",
["L Forearm"] = "ValveBiped.Bip01_L_Forearm",
["L Hand"] = "ValveBiped.Bip01_L_Hand",
["R Thigh"] = "ValveBiped.Bip01_R_Thigh",
["R Calf"] = "ValveBiped.Bip01_R_Calf",
["R Foot"] = "ValveBiped.Bip01_R_Foot",
["R Toes"] = "ValveBiped.Bip01_R_Toe0",
["L Thigh"] = "ValveBiped.Bip01_L_Thigh",
["L Calf"] = "ValveBiped.Bip01_L_Calf",
["L Foot"] = "ValveBiped.Bip01_L_Foot",
["L Toes"] = "ValveBiped.Bip01_L_Toe0",
["Random"] = "N/A"
}

d.oRCC = RunConsoleCommand
d.oRenderCapture = render.Capture
d.secondantiss = net.Receive
d.thirdantiss = net.Start
d.pmeta = g.FindMetaTable("Player")
d.oinput = input.IsKeyDown

function d:con(str)
g.MsgC(g.Color(0,255,0,255),"[dHack "..d.version.."] "..str.."\n")
end

function d:fakeqacss()
g.net.Start("screengrab_start")
		g.net.WriteUInt( 4,32 )
g.net.SendToServer()
end

function d:fakeqacpart()
	g.net.Start( "screengrab_part")
		g.net.WriteUInt( 4, 32 )
		g.net.WriteData( "000000000000000000000000", 4 )
	g.net.SendToServer()
end

function input.IsKeyDown(key)
	if key == KEY_SPACE then
		return false
	end
	return d.oinput(key)
end

function net.Receive(str,func)
	if str == "screengrab_part" and d.bools["blockss"] then
		d:con("Blocked an admin from taking a screenshot of your screen!(QAC)")
		d:fakeqacpart()
		return
	end
	
	return d.secondantiss(str,func)
end

function net.Start(str)
	if str == "screengrab_start" and d.bools["blockss"] then
		d:con("Blocked an admin from taking a screenshot of your screen!(QAC)")
		d:fakeqacss()
		return
	end
	
	return d.thirdantiss(str)
end

function debug.getinfo(indexkid)
return
end
d:con("QAC should be bypassed at this point")


function render.Capture(data)
	if d.bools["blockss"] then
		d:con("Blocked an admin from taking a screenshot of your screen!")
		return "nonoononooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoononononnonooooooonononoononononononononoonononoononononoonononoonoonononon"
	end
	
	return d.ORenderCapture(data)
end

function RunConsoleCommand(cmd, ...)
	local str = cmd
	if ... then
		local tolog = {...}
		if d.bools["logrcc"] then
		d:con("RunConsoleCommand("..cmd..", "..g.table.concat(tolog, ", ")..")")
		end
	end
	
	if d.bools["logrcc"] and !... then
		d:con("RunConsoleCommand("..cmd..")")
	end
		
	if d.bools["blockacs"] and g.table.HasValue(d.blockedcmds,cmd) then 
		d:con("Blocked:"..cmd.." from running")
		return 
	else
		return d.oRCC(cmd, ...)
	end
	
end

local oConCommand = d.pmeta.ConCommand
function d.pmeta.ConCommand(ply, cmd)
	cmd = cmd or ""
	if d.bools["logrcc"] then
	d:con("ConsoleCommand("..cmd..")")
	end
	if d.bools["blockacs"] and g.table.HasValue(d.blockedcmds,cmd) then 
	d:con("Blocked:"..cmd.." from running")
		return 
	else
		return oConCommand(ply, cmd)
	end
end

function d:savecfg(cfg)
	local tosave = {}
	tosave.vars = d.vars
	tosave.bools = d.bools
	tosave.binds = d.binds
	tosave.espents = d.espents
	tosave.friends = d.friends
	
	g.file.Delete("deaglerh/"..cfg..".txt")
	g.file.Write("deaglerh/"..cfg..".txt",g.util.TableToJSON(tosave))
end
function d:loadcfg(cfg) 
cfg = g.string.lower(cfg) 
	if g.file.Exists("deaglerh/"..cfg..".txt", "DATA") then 
		local toload = g.util.JSONToTable(g.file.Read("deaglerh/"..cfg..".txt", "DATA"))
		g.table.Merge(d.vars,toload.vars)
		g.table.Merge(d.bools,toload.bools)
		g.table.Merge(d.binds,toload.binds )
		g.table.Merge(d.espents,toload.espents )
		g.table.Merge(d.friends,toload.friends)
	end 
end 
function d:delete(cfg) 
	cfg = g.string.lower(cfg) 
	if g.file.Exists("deaglerh/"..cfg..".txt", "DATA") then 
		g.file.Delete("deaglerh/"..cfg..".txt") 
	end 
end 
function d:get() 
	local files = g.file.Find("deaglerh/*.txt", "DATA") 
	
	for k,v in g.ipairs(files) do 
		files[k] = g.string.Replace(v,".txt","") 
	end 
	
	return files 
end 
if !g.file.Exists("deaglerh", "DATA") then 
	g.file.CreateDir("deaglerh") 
	d:savecfg("default")
	d:savecfg("defaultbackup(dHack default backup)")
else 
d:loadcfg("default") 
end 
d.configs = d:get()

function d:AddCheckBox(dpanel, bool, text, x, y) 
	local checkbox = g.vgui.Create("DCheckBoxLabel", dpanel) 
	checkbox:SetPos(x, y) 
	checkbox:SetText(text) 
	checkbox:SizeToContents() 
	checkbox:SetTextColor(g.Color(0,255,0)) 
	checkbox:SetChecked(d.bools[bool]) 
	checkbox.OnChange = function(chk) 
		g.surface.PlaySound("ui/buttonclick.wav")
		d.bools[bool] = checkbox:GetChecked()
		d:addView("\""..bool.."\" set to "..tostring(checkbox:GetChecked())) 
	end 
end



function d:AddVarText(dpanel, var, text, min, max, x, y, w) 
	local w1 = g.surface.GetTextSize(text)
	
	local label = g.vgui.Create("DLabel", dpanel)
	label:SetTextColor(g.Color(0,255,0,255))
	label:SetPos(x, y-13) 	
	label:SetText(text)
	label:SizeToContents()
	
	local textbox = g.vgui.Create("DTextEntry", dpanel)
	textbox:SetPos(x, y) 
	textbox:SetWide(w)
	textbox:SetValue(d.vars[var])
	textbox.OnEnter = function() 
	local val =tonumber(textbox:GetValue())
	if !val then d:addView("Could not recognise \""..val.."\" for variable \""..var.."\". Please enter a number between "..min.." and "..max) return end
	if val < min then d:addView("Could not recognise \""..val.."\" for variable \""..var.."\". Please enter a number between "..min.." and "..max) end
	if val > max then d:addView("Could not recognise \""..val.."\" for variable \""..var.."\". Please enter a number between "..min.." and "..max) end
		if val and val >= min and val <= max then
			g.surface.PlaySound("ui/buttonclick.wav")
			d:addView("\""..var.."\" set to "..val.." from "..d.vars[var]) 
			d.vars[var] = val
		end
	end
 local textcol = g.Color(192,192,192,255)
local textocol = g.Color(100,100,100,255)

textbox.Paint = function()
local w = textbox:GetWide()
local h = textbox:GetTall()
g.draw.RoundedBox(0, 1, 1, w-2, h-2, textcol)
g.surface.SetDrawColor( textocol )
g.surface.DrawOutlinedRect( 0, 0, w, h )
textbox:DrawTextEntryText(g.Color(0, 0, 0), g.Color(0, 255, 0), g.Color(255, 255, 255))
end


  textbox.OnTextChanged = function(PanelVar)
   textbox:SetTextColor(g.Color(0,255,0,255))
  end

end

function d:AddVarComboBox(dpanel, var, text, values, x, y, w) 
	local w1 = g.surface.GetTextSize(text)
	
	local label = g.vgui.Create("DLabel", dpanel)
	label:SetTextColor(g.Color(0,255,0,255))
	label:SetPos(x, y-13) 	
	label:SetText(text)
	label:SizeToContents()
	
	local combobox = g.vgui.Create("DComboBox", dpanel)
	combobox:SetPos(x, y) 
	combobox:SetWide(w)
	combobox:SetValue(d.vars[var])
	for k,v in g.pairs(values) do
		combobox:AddChoice(v)
	end
	combobox.OnSelect = function(p,i,val,data) 
	if val == d.vars[var] then
		d:addView("\""..var.."\" was already set to "..d.vars[var].." silly!") 
		return
	end
		g.surface.PlaySound("ui/buttonclick.wav")
		d:addView("\""..var.."\" set to "..val.." from "..d.vars[var]) 
		d.vars[var] = val
	end

	
end

d.StartChat1 = GAMEMODE.StartChat 
function GAMEMODE:StartChat() 
	d.StartChat1() 
	d.typing = true 
end 

d.FinishChat1 = GAMEMODE.FinishChat 
function GAMEMODE:FinishChat() 
	d.FinishChat1() 
	d.typing = false 
end

function d:KeyString(key)

for k,v in g.ipairs(d.chars) do
if v.val==key then
return v.char
end
end
return "N/A"
end

function d:Collide(prop)
	 properties.List[ 'collision_off' ]:Action( prop ) 
	 properties.List[ 'collision_on' ]:Action( prop )
end

function d:RAHack(account,amount)
if (!account or !amount) or (account=="" or amount=="") or (account==" " or amount==" ") then return "Incorrect syntax. Usage: "..d.cmds["ra_hack"].usage.."("..d.cmds["ra_hack"].example..")" end
if !net.Receivers.atm_cl_verify_r_s2c then return "Server does not have Realistic ATM Addon" end
local msgs = {}
local amount1 = "-"..g.tostring(amount)
        g.net.Start("ATM_DepositMoney_C2S")
                g.net.WriteTable({Memo = "Hacked by dHack"..d.version,Num=account,Amount=g.tonumber(amount1)})
        g.net.SendToServer()

        g.table.insert(msgs,"Hacked $"..amount)
        return msgs
end

function d:Unbind(bind) 
	if !bind then return "Incorrect syntax. Usage: "..d.cmds["unbind"].usage.."("..d.cmds["unbind"].example..")" end
	local bind = bind:lower()
d.binds[bind].key=KEY_NONE
return bind.." was unbounded"
end

function d:SetBind(key,bind) 
if (!bind or !key) or (bind=="" or key=="") or (bind==" " or key==" ") then return "Incorrect syntax. Usage: "..d.cmds["bind"].usage.."("..d.cmds["bind"].example..")" end
	local bind = bind:lower()
	local key = key:lower()
if !d.binds[bind] then return bind.." is not a valid bind, Go to the \"Bindable Actions\" tab for a list of the valid binds." end
if key=="none" then 
	return d:Unbind(bind)
end
for k,v in g.ipairs(d.chars) do
if v.char:lower() == key then
d.binds[bind].key = v.val
return bind.." bound to "..v.char
end
end
return key.." is not a valid key. Go to the \"Bindable Keys\" tab for a list of valid keys."
end


function d:addentity(ent)

if !g.table.HasValue(d.espents,ent) then 
g.table.insert(d.espents,ent)
return ent.." is now being tracked on the ESP!"
else
return ent.." is already being tracked on the ESP!"
end

end

function d:melonaddcount(amount)
if !amount or amount <=0 then 
	return "Incorrect syntax. Usage: "..d.cmds["melon_addcount"].usage.."("..d.cmds["melon_addcount"].example..")" 
end
if !LocalPlayer().Clicker_AddToCount then return "Server does not have Melon Clicker addon" end

g.LocalPlayer():Clicker_AddToCount(amount)


return "Adding "..amount.." clicks to your Melon Clicker score!"
end

function d:melonaddpoints(amount)
if !amount or amount <=0 then 
	return "Incorrect syntax. Usage: "..d.cmds["melon_addpoints"].usage.."("..d.cmds["melon_addpoints"].example..")" 
end
if !LocalPlayer().Clicker_AddToCount then return "Server does not have Melon Clicker addon" end

g.net.Start('ClickerAddToPoints')
	g.net.WriteInt(amount, 32)
g.net.SendToServer()


return "Adding "..amount.." points to your pointshop account"
end

function d:addmdeprop(prop)
if !prop then 
	return "You must be looking at an entity!" 
end

if !MDE_AddNewStuff then return "Server does not have RocketMania Map Decoration Editor" end

local TARGET=prop

local Data = {} 
Data.Model = TARGET.GetModel and TARGET:GetModel() or "N/A"
Data.Color = TARGET:GetColor() 
Data.Material = TARGET:GetMaterial() 
Data.Skin = TARGET:GetSkin() 
Data.Class = TARGET:GetClass() 
Data.Type = g.type(TARGET)
local PosK = TARGET:GetPos() 
local AngleK = TARGET:GetAngles() 
Data.Pos = TARGET:GetPos() 
Data.Ang = TARGET:GetAngles()

MDE_AddNewStuff(Data,TARGET)




return "Making "..Data.Model.." a permenant prop."
end

function d:removemdeprop(prop)
if !prop then 
	return "You must be looking at an entity!" 
end
if !MDE_AddNewStuff then return "Server does not have RocketMania Map Decoration Editor" end
local TARGET=prop

local Data = {} 
Data.Model = TARGET.GetModel and TARGET:GetModel() or "N/A"
Data.Color = TARGET:GetColor() 
Data.Material = TARGET:GetMaterial() 
Data.Skin = TARGET:GetSkin() 
Data.Class = TARGET:GetClass() 
Data.Type = g.type(TARGET)

local PosK = TARGET:GetPos() 
local AngleK = TARGET:GetAngles() 
Data.Pos = TARGET:GetPos() 
Data.Ang = TARGET:GetAngles()

MDE_RemoveStuff(Data,TARGET)




return "Removing "..Data.Model.." from being a permanent prop"
end

function d:crashall()
if !MDE_AddNewStuff then return "Server does not have RocketMania Map Decoration Editor" end
	for k,v in g.pairs(player.GetAll()) do
		g.timer.Simple(k*2,function()
			if g.IsValid(v) then
				if v != g.LocalPlayer() then 
					local TARGET=v
					local Data = {} 
					Data.Model = TARGET.GetModel and TARGET:GetModel() or "N/A"
					Data.Color = TARGET:GetColor() 
					Data.Material = TARGET:GetMaterial() 
					Data.Skin = TARGET:GetSkin() 
					Data.Class = TARGET:GetClass() 
					Data.Type = type(TARGET)
					
					local PosK = TARGET:GetPos() 
					local AngleK = TARGET:GetAngles() 
					
					Data.Pos = TARGET:GetPos() 
					Data.Ang = TARGET:GetAngles()


					MDE_RemoveStuff(Data,TARGET)

					d:con(v:Name().." was crashed")
				end
			end
		end)
	end
end

function d:findPlayerByName(name)
name = g.string.Trim(name)
if name == "" or name == " " then return "syntax" end

        for k,v in g.pairs(player.GetAll()) do
                if g.string.find(v:Name():lower(),name)  then
                        return v
                end
        end
       
        return "No"
end
 
function d:crashply(name)
	local ply = d:findPlayerByName(name)
	
	if ply == "syntax" then return "Incorrect syntax. Usage: "..d.cmds["crashply"].usage.."("..d.cmds["crashply"].example..")"  end
	if !MDE_AddNewStuff then return "Server does not have RocketMania Map Decoration Editor" end
	if ply == "No" then return "Could not find a player with the name "..name end
	
					local TARGET=ply
					local Data = {} 
					Data.Model = TARGET.GetModel and TARGET:GetModel() or "N/A"
					Data.Color = TARGET:GetColor() 
					Data.Material = TARGET:GetMaterial() 
					Data.Skin = TARGET:GetSkin() 
					Data.Class = TARGET:GetClass() 
					Data.Type = g.type(TARGET)
					
					local PosK = TARGET:GetPos() 
					local AngleK = TARGET:GetAngles() 
					
					Data.Pos = TARGET:GetPos() 
					Data.Ang = TARGET:GetAngles()


					MDE_RemoveStuff(Data,TARGET)
	return "Crashed "..ply:Name()
end

function d:extendeddces()
	if !net.Receivers.recentdcs then return "Server does not have ULX Extended" end
	
	d.pmeta:ConCommand("ulx recentdcs")
	g.timer.Simple(1,function()

	g.MsgC(Color(255,128,0),d.str.."ULX Extended DC List "..#RecentDCs.." records\n")
	for k,v in g.pairs(RecentDCs) do 
		g.MsgC(Color(0,255,0),v.nick.."("..v.id..")\n\t "..v.ip.."\n\n")
	end
	g.MsgC(Color(255,128,0),d.str.."ULX Extended DC List "..#RecentDCs.." records\n")
	
	end)
	return "Data printed to console"
end

function d:customdces()
	if !net.Receivers.hcl then return "Server does not have Custom Commands" end
	if !disconnectTable then return "ERROR: NoTable" end
	local i =0
	for k,v in g.pairs(disconnectTable) do 
	 i= i+1
	end
	g.MsgC(Color(255,128,0),d.str.."CustomCommands DC List:"..i.." records\n")
	for k,v in g.pairs(disconnectTable) do 
		g.MsgC(Color(0,255,0),v[1].."("..k..")\n\t "..v[2].."\n\n")
	end
	g.MsgC(Color(255,128,0),d.str.."CustomCommands DC List:"..i.." records\n")
	

	return "Data printed to console"
end
function d:netinfo()
	if !net.Receivers then return "ERROR: net.Receivers does not exist" end
	
	local i =0
	for k,v in g.pairs(net.Receivers) do 
	 i= i+1
	end
	
	g.MsgC(Color(255,128,0),d.str.."net.Receivers:"..i.." records.\n")
	for k,v in g.pairs(net.Receivers) do
		g.MsgC(Color(0,255,0),k.."\n\t")
		g.MsgC(Color(255,0,100),g.jit.util.funcinfo(v).source.."\n\n")
	end
	g.MsgC(Color(255,128,0),d.str.."net.Receivers:"..i.." records.\n")

	return "Data printed to console"
end

function d:commandinfo()
	local cmds = concommand.GetTable()
	if !cmds then return "ERROR: Console commands do not exist" end
	
	local i =0
	for k,v in g.pairs(cmds) do 
	 i= i+1
	end
	
	g.MsgC(Color(255,128,0),d.str.."ConsoleCommands:"..i.." records.\n")
	for k,v in g.pairs(cmds) do
		g.MsgC(Color(0,255,0),k.."\n\t")
		g.MsgC(Color(255,0,100),g.jit.util.funcinfo(v).source.."\n\n")
	end
	g.MsgC(Color(255,128,0),d.str.."ConsoleCommands:"..i.." records.\n")
	
	return "Data printed to console"
end

function d:Enter(string)
local cmd = g.string.Explode(" ",string:lower())
--[[Checking if the command is valid]]--



if cmd[1] == "" or cmd[1] == " " or !cmd[1]  then return "You didn't enter anything silly!" end

if !d.cmds[cmd[1]] then return cmd[1].." is not a valid command, Type help for a list of commands" end

--[[Moving onto actual commands]]--



if cmd[1]=="help" and !cmd[2] then
local help = {}
g.table.insert(help,"Available Commands:")

 for k,v in g.pairs(d.cmds) do
	g.table.insert(help,k.." "..v.type.." - Usage: "..v.usage)
 end
return help
elseif cmd[1]=="help" and cmd[2] then
	local help = {}
 if d.cmds[cmd[2]] then
 	g.table.insert(help,cmd[2].." "..d.cmds[cmd[2]].type)
 	g.table.insert(help,d.cmds[cmd[2]].help)
 	g.table.insert(help,"Usage:"..d.cmds[cmd[2]].usage)
 	g.table.insert(help,"Example:"..d.cmds[cmd[2]].example)
 	return help
 else
 	return cmd[2].." is not a valid command, Type help for a list of commands" 
 end
end

if cmd[1]=="bind" then
return d:SetBind(cmd[2],cmd[3]) 
end
if cmd[1]=="unbind" then
return d:Unbind(cmd[2]) 
end

if cmd[1]=="ra_hack" then
return d:RAHack(cmd[2],cmd[3]) 
end

if cmd[1]=="addentity" then
return d:addentity(cmd[2]) 
end

if cmd[1]=="collideprop" then
d:Collide(g.LocalPlayer():GetEyeTrace().Entity)
end

if cmd[1]=="unbindall" then
for _,v in g.pairs(d.binds) do
v.key=KEY_NONE
return "Unbound all actions."
end

end

if cmd[1]=="runcl" then
g.RunString(g.string.sub(string,6))
return "Ran Lua Code:"..g.string.sub(string,6)
end

if cmd[1]=="melon_addcount" then
return d:melonaddcount(g.tonumber(cmd[2]))
end

if cmd[1]=="melon_addpoints" then
return d:melonaddpoints(g.tonumber(cmd[2]))
end

if cmd[1]=="mde_openeditor" then
	if !MDE_AddNewStuff then return "Server does not have RocketMania Map Decoration Editor" end
	MDE_OpenCommander()
	return "Respawn/Remover Editor opened"
end

if cmd[1]=="mde_addprop" then
 return d:addmdeprop(g.LocalPlayer():GetEyeTrace().Entity)
end
if cmd[1]=="mde_removeprop" then
 return d:removemdeprop(g.LocalPlayer():GetEyeTrace().Entity)
end

if cmd[1]=="crashall" then
 d:crashall()
 local amt = #player.GetAll()-1
 return "Attempting to crash "..amt.." players!"
end

if cmd[1]=="crashply" then
 local name=g.string.sub(string,g.string.len(cmd[1])+1)
 return d:crashply(name)
end

if cmd[1] == "extended_lastdced" then
	return d:extendeddces()
end

if cmd[1] == "custom_lastdced" then
	return d:customdces()
end

if cmd[1] == "netinfo" then
	return d:netinfo()
end

if cmd[1] == "commandinfo" then
	return d:commandinfo()
end

end
--gInject went with a good idea when doing a console system, Thought I would re-create my own version off it.

function d:OpenConsole()
	local console = g.vgui.Create("DFrame")
	console:SetTitle("") 
	console:SetPos(50,50)
	console:SetSize(600,500)
	console:ShowCloseButton(false)   		
	console:MakePopup()
	console.Paint = function()
		local w = console:GetWide()
		local h = console:GetTall()
		g.draw.RoundedBox(0, 0, 0, w, h, g.Color(30,30,30,255))
		g.surface.SetDrawColor( g.Color(0,255,0,255) )
		g.surface.DrawOutlinedRect( 0, 0, w, 27 )
		g.surface.DrawOutlinedRect( 0, 0, w, h )
		g.draw.SimpleTextOutlined("dHack "..d.version.." Console (SHIFT+8) ", "dFONT1", w / 2, 27 / 2, g.Color(0,255,0,255), 1, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, g.Color(0,0,0,255) )
	end

	local closebcol = g.Color(150,0,0,255)
	local closebocol = g.Color(150,25,0,255)
	
	local closeb = g.vgui.Create( "DButton", console )
		closeb:SetText( "X" )
		closeb:SetTextColor(g.Color( 255, 255, 255 ,255) )
		closeb:SetSize( 40, 27 )
		closeb:SetPos(console:GetWide() - 40 , 0 )
		
	closeb.DoClick = function()
		console:Close() 
		d.console = false;
		g.surface.PlaySound("ui/buttonclick.wav")
	end
	
	closeb.OnCursorEntered = function()
		closebcol = g.Color(150,50,0,255)
		closebocol = g.Color(150,75,0,255)
	end

	closeb.OnCursorExited = function()
		closebcol = g.Color(150,0,0,255)
		closebocol = g.Color(150,25,0,255)
	end
		
	closeb.Paint = function()
		local w = closeb:GetWide()
		local h = closeb:GetTall()
		g.draw.RoundedBox(0, 2, 2, w-4, h-4, closebcol)
		g.surface.SetDrawColor( closebocol )
		g.surface.DrawOutlinedRect( 1, 1, w-2, h-2 )
		g.surface.SetDrawColor( 0, 255, 0, 255 )
		g.surface.DrawOutlinedRect( 0, 0, w, h )
	end

local consoletabs = g.vgui.Create("DPropertySheet",console)
consoletabs:SetPos(10,37)
consoletabs:SetSize(console:GetWide()-20,console:GetTall()-47)

local consolepanel = g.vgui.Create("DPanel",consoletabs)
consolepanel:SetSize(consoletabs:GetWide(),consoletabs:GetTall())

local consolelist = g.vgui.Create("DListView",consolepanel)
consolelist:SetSize(consolepanel:GetWide() - 17, consolepanel:GetTall() - 59)
consolelist:AddColumn("dHack Console")      
consolelist:SetMultiSelect(false)
consolelist.OnClickLine = function()
consolelist:ClearSelection()
end

local bindpanel = g.vgui.Create("DPanel",consoletabs)
bindpanel:SetSize(consoletabs:GetWide(),consoletabs:GetTall())

local bindlist = g.vgui.Create("DListView",bindpanel)
bindlist:SetSize(bindpanel:GetWide()-17,bindpanel:GetTall()-39)
bindlist:AddColumn("Action"):SetFixedWidth(100)
bindlist:AddColumn("Key"):SetFixedWidth(100)
bindlist:AddColumn("What it does?")
bindlist:SetMultiSelect(false)
bindlist.OnClickLine = function()
bindlist:ClearSelection()
end

for k,v in g.pairs(d.binds) do
bindlist:AddLine(k,d:KeyString(v.key),tostring(v.what))
end
bindlist:SortByColumn(1, false)


local command = g.vgui.Create("DTextEntry", consolepanel)
command:SetPos(2,consolepanel:GetTall() - 57)
command:SetWide(consolepanel:GetWide() - 20)
command.OnEnter = function()
local consoletxt = {}

for k,v in g.ipairs(consolelist:GetLines()) do
	g.table.insert(consoletxt,v:GetValue(1))
end

bindlist:SortByColumn(1, false)
local msg = d:Enter(command:GetValue())
consolelist:Clear()

		 if type(msg) == "table" then 

		 	for _,v in g.pairs(msg) do 
		 		consolelist:AddLine(v) 
		 	end 

		 else 
		 	consolelist:AddLine(msg) 
		 end 
		 
		 consolelist:AddLine(">"..command:GetValue()) 

		 for _,v in g.ipairs(consoletxt) do 
		 	consolelist:AddLine(v) 
		 end 

		 command:SetText("") 
		 command:RequestFocus() 

		
bindlist:Clear()
for k,v in g.pairs(d.binds) do
bindlist:AddLine(k,d:KeyString(v.key),tostring(v.what))
end

end


local keypanel = g.vgui.Create("DPanel",consoletabs)
keypanel:SetSize(consoletabs:GetWide(),consoletabs:GetTall())

local keylist = g.vgui.Create("DListView",keypanel)
keylist:SetSize(keypanel:GetWide()-17,keypanel:GetTall()-39)
keylist:AddColumn("dHack Key")
keylist:AddColumn("GMod Equivalent")
keylist:SetMultiSelect(false)
keylist.OnClickLine = function()
keylist:ClearSelection()
end

for k,v in g.ipairs(d.chars) do
keylist:AddLine(v.char,tostring(v.val))
end
keylist:SortByColumn(1, false)




consoletabs:AddSheet("Console",consolepanel,"gui/silkicons/application_xp_terminal",false,false,"The dHack console.")
consoletabs:AddSheet("Bindable Keys",keypanel,"gui/silkicons/keyboard",false,false,"The keys you can use with dHack(Total: "..#d.chars..")")
consoletabs:AddSheet("Bindable Actions",bindpanel,"gui/silkicons/keyboard_add",false,false,"The actions you can bind with dHack(Total: "..#d.binds..")")
end

function d:OpenMenu()
local menu = g.vgui.Create("DFrame")
menu:SetSize(550,500) 
menu:SetTitle("") 
menu:ShowCloseButton(false) 
menu:Center() 
menu:MakePopup() 
menu.btnMinim:SetVisible(false)
menu.btnMaxim:SetVisible(false)
menu.Paint = function()
local w = menu:GetWide()
local h = menu:GetTall()
g.draw.RoundedBox(0, 0, 0, w, h, g.Color(30,30,30,255))
g.surface.SetDrawColor( g.Color(0,255,0,255) )
g.surface.DrawOutlinedRect( 0, 0, w, 27 )
g.surface.DrawOutlinedRect( 0, 0, w, h )


g.draw.SimpleTextOutlined("dHACK "..d.version, "dFONT1",w / 2, 27 / 2, g.Color(0,255,0,255), 1, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, g.Color(0,0,0,255) )


end

 -- For fucks sake change the colors
local closebcol = g.Color(150,0,0,255)
local closebocol = g.Color(150,25,0,255)

local closeb = g.vgui.Create( "DButton", menu )
closeb:SetText( "X" )
closeb:SetTextColor(g.Color( 255, 255, 255 ,255) )
closeb:SetSize( 40, 27 )
closeb:SetPos( menu:GetWide() - 40 , 0 )
closeb.Paint = function()

local w = closeb:GetWide()
local h = closeb:GetTall()

g.draw.RoundedBox(0, 2, 2, w-4, h-4, closebcol)
g.surface.SetDrawColor( closebocol )
g.surface.DrawOutlinedRect( 1, 1, w-2, h-2 )
g.surface.SetDrawColor( 0, 255, 0, 255 )
g.surface.DrawOutlinedRect( 0, 0, w, h )

end

closeb.DoClick = function()
menu:Close() 
d.menuopen = false
g.surface.PlaySound("ui/buttonclick.wav")
end

closeb.OnCursorEntered = function()
closebcol = g.Color(150,50,0,255)
closebocol = g.Color(150,75,0,255)
end

closeb.OnCursorExited = function()
closebcol = g.Color(150,0,0,255)
closebocol = g.Color(150,25,0,255)
end

local viewlist = g.vgui.Create("DListView",menu)
viewlist:SetSize(menu:GetWide()-4,170)
viewlist:SetPos(2,menu:GetTall()-172)
viewlist:AddColumn("Overview")
--[[
viewlist.Paint = function()

		local w = viewlist:GetWide()
		local h = viewlist:GetTall()

		g.surface.SetDrawColor(0,255,0,255)
		g.surface.DrawOutlinedRect(0, 0, w, h)
end
]]--
viewlist.OnClickLine = function()
viewlist:ClearSelection()
end
viewlist.Think = function()
viewlist.VBar:SetScroll(10000)
end

	for _,v in g.pairs(d.overview) do
	viewlist:AddLine(">"..v) 
	end

function d:addView(string)
	viewlist:Clear()
	g.table.insert(d.overview,string)
	for _,v in g.pairs(d.overview) do
	viewlist:AddLine(">"..v) 
	end
	viewlist.VBar:SetScroll(10000)
end

local dhax = g.vgui.Create("DPropertySheet",menu)
dhax:SetSize(menu:GetWide()-2,menu:GetTall()-205)
dhax:SetPos(1,30)

local aimbot = g.vgui.Create("DPanelList",dhax)
aimbot:SetSize(30,40)
aimbot:SetPos(20,20)
aimbot:SetSpacing(3.5)
aimbot:EnableHorizontal(false)
aimbot:EnableVerticalScrollbar(false)

local triggerbot = g.vgui.Create("DPanelList",dhax)
triggerbot:SetSize(30,40)
triggerbot:SetPos(20,20)
triggerbot:SetSpacing(3.5)
triggerbot:EnableHorizontal(false)
triggerbot:EnableVerticalScrollbar(false)

local esp = g.vgui.Create("DPanelList",dhax)
esp:SetSize(30,40)
esp:SetPos(20,20)
esp:SetSpacing(3.5)
esp:EnableHorizontal(false)
esp:EnableVerticalScrollbar(false)

local friends = g.vgui.Create("DPanelList",dhax)
friends:SetSize(30,40)
friends:SetPos(20,20)
friends:SetSpacing(3.5)
friends:EnableHorizontal(false)
friends:EnableVerticalScrollbar(false)


local misc = g.vgui.Create("DPanelList",dhax)
misc:SetSize(30,40)
misc:SetPos(20,20)
misc:SetSpacing(3.5)
misc:EnableHorizontal(false)
misc:EnableVerticalScrollbar(false)

local crosshair = g.vgui.Create("DPanelList",dhax)
crosshair:SetSize(30,40)
crosshair:SetPos(20,20)
crosshair:SetSpacing(3.5)
crosshair:EnableHorizontal(false)
crosshair:EnableVerticalScrollbar(false)


local ents = g.vgui.Create("DPanel",dhax)
ents:SetSize(dhax:GetWide(),dhax:GetTall())
ents:SetPos(20,20)


--[[Entity Menu, Yes this is in Lennys but I created it and put it in Lennys.]]--
local noton = g.vgui.Create("DListView",ents)
noton:SetSize(200,ents:GetTall()-40)
noton:SetPos(10,1)
noton:AddColumn("Not Being Tracked")
noton:SetMultiSelect(false)

local on = g.vgui.Create("DListView",ents)
on:SetSize(200,ents:GetTall()-40)
on:SetPos(ents:GetWide()-220,1)
on:AddColumn("Being Tracked")
on:SetMultiSelect(false)

local addent = g.vgui.Create("DButton",ents)
addent:SetSize(50,25)
addent:SetPos(ents:GetWide()/2-25,ents:GetTall()/2-40)
addent:SetText("+")
addent.DoClick = function() 
        if noton:GetSelectedLine() != nil then 
                local ent = noton:GetLine(noton:GetSelectedLine()):GetValue(1)
                if !g.table.HasValue(d.espents,ent) then 
						g.surface.PlaySound("ui/buttonclick.wav")
						d:addView(ent.." is now being tracked on the ESP")
                        g.table.insert(d.espents,ent)
                        noton:RemoveLine(noton:GetSelectedLine())
                        on:AddLine(ent)
                end
        end
end



local rement = g.vgui.Create("DButton",ents)
rement:SetSize(50,25)
rement:SetPos(ents:GetWide()/2-25,ents:GetTall()/2)
rement:SetText("-")
rement.DoClick = function()
        if on:GetSelectedLine() != nil then
                local ent = on:GetLine(on:GetSelectedLine()):GetValue(1)
                if g.table.HasValue(d.espents,ent) then 
                        for k,v in g.pairs(d.espents) do 
                                if v == ent then 
                                table.remove(d.espents,k) 
                                end 
                        end
								g.surface.PlaySound("ui/buttonclick.wav")
								d:addView(ent.." is no longer being tracked on the ESP")
                                on:RemoveLine(on:GetSelectedLine())
                                noton:AddLine(ent)
                end
        end
end

d.added = {}
for _,v in g.pairs(g.ents.GetAll()) do

if !g.table.HasValue(d.added,v:GetClass()) and !g.table.HasValue(d.espents,v:GetClass()) and !g.string.find(v:GetClass(),"grav")  and !g.string.find(v:GetClass(),"phys") and v:GetClass() != "player" and v:GetClass() != "prop_physics" then
noton:AddLine(v:GetClass())
g.table.insert(d.added,v:GetClass())
end

end

for _,v in pairs(d.espents) do
on:AddLine(v)
end


local configs = g.vgui.Create("DPanel",dhax)
configs:SetSize(dhax:GetWide(),dhax:GetTall())
configs:SetPos(20,20)

local configlist = g.vgui.Create("DListView",configs)
configlist:SetPos(2,24)
configlist:SetSize(configs:GetWide()-10,configs:GetTall()-60)
configlist:AddColumn("Configs(Double click to load)")
for k,v in g.pairs(d.configs) do 
	configlist:AddLine(v)
end
configlist.DoDoubleClick = function() 
	local line = configlist:GetSelectedLine() 
	if line != nil then 
		local config = configlist:GetLine(line):GetValue(1)
		g.surface.PlaySound("ui/buttonclick.wav")
		d:addView(config.." loaded.") 		
		d:loadcfg(config) 
		menu:Close() 
		d.menuopen = false 
	end 
end

local create = g.vgui.Create("DButton", configs) 
create:SetText("Create Config") 
create:SetSize(100, 20) 
create:SetPos(2, 2) 
create.DoClick = function() 
	g.Derma_StringRequest( "Create a New Config!", "Name of your new config file", "", function(txt) 
		if !g.table.HasValue(d.configs, txt) then 
			d:savecfg(txt) 
			g.table.insert(d.configs, txt) 
		end 
	end ) 
	menu:Close() 
	d.menuopen = false 
end 
local delete = g.vgui.Create("DButton", configs) 
delete:SetText("Delete Config") 
delete:SetSize(100, 20) 
delete:SetPos(configs:GetWide()-120, 2) 
delete.DoClick = function() 
local line = configlist:GetSelectedLine() 
if line != nil then 
local config = configlist:GetLine(line):GetValue(1) 
for k,v in pairs(d.configs) do 
if v == config then 
g.table.remove(d.configs, k) 
end 
end 
d:delete(config) 
menu:Close() 
d.menuopen = false 
end 
end


dhax:AddSheet("Aimbot",aimbot,"gui/silkicons/medal_gold_1",false,false,"Aimbot Settings")
dhax:AddSheet("Triggerbot",triggerbot,"gui/silkicons/medal_silver_1",false,false,"Triggerbot Settings")
--dhax:AddSheet("Friends",friends,"gui/silkicons/user_add",false,false,"Friend List")
dhax:AddSheet("ESP/Wallhack",esp,"gui/silkicons/user_green",false,false,"ESP Settings")
dhax:AddSheet("Entities",ents,"gui/silkicons/coins",false,false,"Entities to be displayed on ESP")
dhax:AddSheet("Misc",misc,"gui/silkicons/cog",false,false,"Misc Settings")
dhax:AddSheet("Crosshair",crosshair,"gui/silkicons/bullet_wrench",false,false,"Crosshair Settings(Icon is a WIP Deal with it)")
dhax:AddSheet("Configs",configs,"gui/silkicons/folder_wrench",false,false,"Save your settings here!")
-- Theme created by Penguin http://steamcommunity.com/profiles/76561198074794075/


--d:AddVarText(dpanel, var, text, min, max, x, y, w) 
--d:AddCheckBox(dpanel, bool, text, x, y) 
d:AddCheckBox(aimbot,"aimbot","Aimbot",5,5)
d:AddCheckBox(aimbot,"aimatteam","Aim at Team",5,35)
--d:AddCheckBox(aimbot,"aimatfriends","Aim at Friends",5,65)
d:AddCheckBox(aimbot,"autoshoot","Auto Shoot",5,95)
d:AddCheckBox(aimbot,"aautoreload","Auto Reload",5,125)
d:AddCheckBox(aimbot,"aimplayer","Aim at Players",5,155)
d:AddCheckBox(aimbot,"aimnpc","Aim at NPC",5,185)
--d:AddCheckBox(aimbot,"antisnap","Antisnap",5,215)

d:AddVarText(aimbot, "aimx","X Offset", 0, 256, 370, 15, 100) 
d:AddVarText(aimbot, "aimy","Y Offset", 0, 256, 370, 50, 100) 
d:AddVarText(aimbot, "aimz","Z Offset", 0, 256, 370, 85, 100) 
d:AddVarText(aimbot, "antisnap","Antisnap", 0, 20, 370, 120, 100) 
d:AddVarText(aimbot, "adistance","Aim Distance", 0, 20, 370, 155, 100) 
d:AddVarText(aimbot, "aimfov","Aim FOV", 0, 360, 370, 190, 100)
--d:AddVarComboBox(aimbot, "aimbone", "Mode:", {"Head","Chest","Offsets"}, 250, 15, 100)
local bones = {};
for k,v in g.pairs(d.bones) do
g.table.insert(bones,k)
end
d:AddVarComboBox(aimbot, "aimbone", "Mode:", bones, 250, 15, 100)


d:AddCheckBox(triggerbot,"triggerbot","Triggerbot",5,5)
d:AddCheckBox(triggerbot,"triggerplayer","Aim at Players",5,35)
d:AddCheckBox(triggerbot,"triggernpc","Aim at NPC",5,65)
d:AddCheckBox(triggerbot,"tautoreload","Auto-Reload",5,95)

d:AddVarComboBox(triggerbot, "triggertype", "Mode:", {"Head","All"}, 250, 15, 100) 


d:AddCheckBox(esp,"esp","ESP",5,5)
d:AddCheckBox(esp,"eplayers","Show Players",5,30)
d:AddCheckBox(esp,"enpc","Show NPCs",5,55)
d:AddCheckBox(esp,"eents","Show Ents",5,80)
d:AddCheckBox(esp,"ename","Show Name",5,105)
d:AddCheckBox(esp,"ehealth","Show Health",5,130)
d:AddCheckBox(esp,"earmour","Show Armour",5,155)
d:AddCheckBox(esp,"ewep","Show Weapon",5,180)
d:AddCheckBox(esp,"erpcash","Show Money(DarkRP)",5,205)
d:AddCheckBox(esp,"erank","Show Rank",5,230)

d:AddCheckBox(esp,"epoints","Show Points",120, 5)
d:AddCheckBox(esp,"ehealthb","Show Healthbar",120, 30)
d:AddCheckBox(esp,"wallhack","Wallhack",120,55 )
d:AddCheckBox(esp,"wplayers","Show Players",120,80 )
d:AddCheckBox(esp,"wnpcs","Show NPCs",120,105 )
d:AddCheckBox(esp,"wents","Show Ents",120,130 )
d:AddCheckBox(esp,"wprops","Show Props",120,155 )




d:AddVarComboBox(esp, "espbox", "ESP Box:", {"None","2D","3D"}, 250, 15, 100)
d:AddVarComboBox(esp, "esptype", "ESP Type:", {"Body","Top/Bottom","Left/Right"}, 250, 50, 100)
d:AddVarComboBox(esp, "esphlocation", "Healthbar Location:", {"Top","Bottom"}, 250, 85, 100)

d:AddVarText(esp, "esptextdist","ESP Distance:", 0, 20000, 370, 15, 100) 
d:AddVarText(esp, "esphdist","Healthbar Distance:", 0, 20000, 370, 50, 100) 
d:AddVarText(esp, "espwdist","Wallhack Distance:", 0, 20000, 370, 85, 100) 

d:AddVarComboBox(esp, "espwtype", "Wallhack Type:", {"Solid","Wireframe","Chams"}, 250, 120, 100)


d:AddCheckBox(crosshair,"crosshair","Crosshair(More shit coming soon k)",5,5)
--[[
d:AddCheckBox(crosshair,"chealth","Show Health",5,35)
d:AddCheckBox(crosshair,"carmour","Show Armour",5,65)
d:AddCheckBox(crosshair,"crpcash","Show RPCash(DarkRP)",5,95)
d:AddCheckBox(crosshair,"cpoints","Show Points(Pointshop)",5,125)
d:AddCheckBox(crosshair,"cshots","Show Shots to Kill",5,155)
--]]
d:AddCheckBox(misc,"bhop","Auto-Bunnyhop",5,5)
d:AddCheckBox(misc,"norecoil","No-Recoil",5,35)
d:AddCheckBox(misc,"logrcc","Log RunConsoleCommand",5,65)
d:AddCheckBox(misc,"blockacs","Block Anti-Cheats(Recommended)",5,95)
d:AddCheckBox(misc,"blockss","Anti-Screenshot",5,125)

end

d.CThink = GAMEMODE.Think 
function GAMEMODE:Think() 
	
	if g.input.IsKeyDown(KEY_LSHIFT) and g.input.IsKeyDown(KEY_8) and !d.console and !g.gui.IsConsoleVisible() and !d.typing then 
		d.console = true 
		d:OpenConsole()
	end

	if !d.console and !g.gui.IsConsoleVisible() and !d.typing and !d.menuopen then

		if g.input.IsKeyDown(d.binds["collideprop"].key) and !d.collide then 
	 		d.collide = true 
	 		d:Collide(g.LocalPlayer():GetEyeTrace().Entity)

		end

		if !g.input.IsKeyDown(d.binds["collideprop"].key) and d.collide then 
			d.collide = false 
		end 
		
		if g.input.IsKeyDown(d.binds["map_addprop"].key) and !d.addprop then 
	 		d.addprop = true 
	 		d:addmdeprop(g.LocalPlayer():GetEyeTrace().Entity)

		end

		if !g.input.IsKeyDown(d.binds["map_addprop"].key) and d.addprop then 
			d.addprop = false 
		end 
		
		if g.input.IsKeyDown(d.binds["map_removeprop"].key) and !d.removeprop then 
	 		d.removeprop = true 
	 		d:removemdeprop(g.LocalPlayer():GetEyeTrace().Entity)
		end

		if !g.input.IsKeyDown(d.binds["map_removeprop"].key) and d.removeprop then 
			d.removeprop = false 
		end 

		if g.input.IsKeyDown(d.binds["toggle_trigger"].key) and !d.trigger1 then 
			d.trigger1=true
	 		d.bools["triggerbot"] =! d.bools["triggerbot"]
	 		g.chat.AddText(g.Color(0,255,0,255),"[dHack "..d.version.."]".." Triggerbot set to: "..tostring(d.bools["triggerbot"]))
	 	end
		if !g.input.IsKeyDown(d.binds["toggle_trigger"].key) and d.trigger1 then
			d.trigger1=false
		end
		
		if g.input.IsKeyDown(d.binds["toggle_esp"].key) and !d.esp1 then 
			d.esp1=true
	 		d.bools["esp"] =! d.bools["esp"]
			d.bools["wallhack"] =! d.bools["wallhack"]
	 		g.chat.AddText(g.Color(0,255,0,255),"[dHack "..d.version.."]".." ESP set to: "..tostring(d.bools["esp"]))
	 	end
		if !g.input.IsKeyDown(d.binds["toggle_esp"].key) and d.esp1 then
			d.esp1=false
		end

end

	if g.input.IsKeyDown(d.binds["menu"].key) and !d.console and !g.gui.IsConsoleVisible() and !d.typing and !d.menuopen then
		d.menuopen=true
		d:OpenMenu()
	end

return self.BaseClass:Think()

end
function d:bug(string)
g.MsgC(g.Color(0,255,0,255),"[DEBUG]"..string.."\n")
end
function d:fLos(ent,pos) 

--"ValveBiped.Bip01_Head1"
	local checklos = {}
	if d:fFireValid(ent,pos) then
	
		checklos.start = g.LocalPlayer():GetShootPos()
		checklos.endpos = pos
		checklos.filter = { g.LocalPlayer(), ent }
		checklos.mask = MASK_SHOT
		local trace = g.util.TraceLine( checklos )
		if trace.Fraction >= 1 then
		
			return true 
		else 
	
			return false 
		end
	end
end

function d:fFireValid(ent,bone)
	if (g.LocalPlayer():GetShootPos() != nil and ent:IsValid() and ent != nil and g.LocalPlayer():GetActiveWeapon():IsValid() and g.LocalPlayer():GetActiveWeapon() != nil and bone != nil and bone != nil) then
		return true
	else
		return false
	end
end

function d:aimbot(ucmd) 
	local buttons = ucmd:GetButtons()
	if !g.input.IsKeyDown(d.binds["+aim"].key) then 
		d.target1 = nil 
	end
	
	if g.LocalPlayer():Alive() then 
	
		local targ, aimpos = d:search() -- Find our victim
		
		if targ and g.input.IsKeyDown(d.binds["+aim"].key) then -- Check if we have a victim and if we are holding down the AimKey
		
			local ang = (aimpos-LocalPlayer():GetShootPos()):Angle()
			ang.p, ang.y, ang.r = g.math.NormalizeAngle(ang.p), g.math.NormalizeAngle(ang.y), g.math.NormalizeAngle(ang.r) 
			ucmd:SetViewAngles(ang) 

	
	 	if d.bools["autoshoot"] then
			buttons= g.bit.bor(buttons, IN_ATTACK)
		end

		end
	end
		ucmd:SetButtons(buttons)
end 
	
function d:search() 

local tolook = nil 
local tolookg = nil 
local bone = d.bones[d.vars["aimbone"]]

if d.vars["aimbone"] == "Random" then
	bone = table.Random(d.bones)
end

	if IsValid(d.target1) and g.input.IsKeyDown(d.binds["+aim"].key) and g.team.GetName(d.target1.Team and d.target1:Team() or "Spectators") != "Spectators" then 
		if (d.target1:LookupBone(bone)) then 
			tolook = (d.vars["aimbone"] != "Offsets" and d.target1:GetBonePosition(d.target1:LookupBone(bone)) or d.target1:GetPos() + g.Vector(d.vars["aimx"], d.vars["aimy"], d.vars["aimz"])) 
		else 
			tolook = d.target1:GetPos() + g.Vector(d.vars["aimx"], d.vars["aimy"], d.vars["aimz"]) 
		end 
		
		if d:fLos(d.target1, tolook) and not (d.target1:IsPlayer() and !d.target1:Alive()) then 
			return d.target1, tolook 
		else 
			d.target1 = nil 
			return false 
		end 
	else 
		d.target1 = nil 
	end 
	local eyes = g.LocalPlayer():EyePos() 
	local aimangle = g.LocalPlayer():GetAimVector() 
	local bestfov = 360 

	for _,v in g.ipairs(g.ents.GetAll()) do 
		if IsValid(v) and (d.bools["aimnpc"] and v:IsNPC()) or (d.bools["aimplayer"] and v:IsPlayer() and g.team.GetName(v:Team()) != "Spectators") then 
			if (v:LookupBone(bone)) then 
			tolook = (d.vars["aimbone"] != "Offsets" and v:GetBonePosition(v:LookupBone(bone)) or v:GetPos() + g.Vector(d.vars["aimx"], d.vars["aimy"], d.vars["aimz"]))
			else 
				tolook = v:GetPos() + g.Vector(d.vars["aimx"], d.vars["aimy"], d.vars["aimz"]) 
			end 
			local teamcheck = true 
			if v:IsPlayer() then 
				if !d.bools["aimatteam"] and v:Team() == g.LocalPlayer():Team() then 
					teamcheck = false 
				end 
			end 
			local readyshoot, cyaw = d:fov(v) 
			if d:fLos(v, tolook) and v != g.LocalPlayer() and readyshoot and (teamcheck) and (!v:IsPlayer() or !g.table.HasValue(d.friends, v:SteamID())) then 
				if cyaw < bestfov then 
					bestfov = cyaw 
					tolookg = tolook 
					d.target1 = v 
				end 
			end 
		end 
	end 

	return d.target1,tolookg 
end

function d:fov(ent) 
	if g.LocalPlayer() == ent then 
		return false 
	end 
	
	if !g.IsValid(ent) then 
		return false 
	end 
	
	if ent:IsPlayer() and (!ent:Alive() or ent:Health() <= 0) then 
		return false 
	end 
	
	if ent:GetPos():Distance(g.LocalPlayer():GetPos()) >= d.vars["aimdistance"] then 
	return false 
	end 
	local fov = d.vars["aimfov"] 
	local ady = 0 
	if fov != 180 then 
		local lpang = g.LocalPlayer():GetAngles() 
		local ang = (ent:GetPos() - g.LocalPlayer():GetPos()):Angle() ady = g.math.abs(g.math.NormalizeAngle(lpang.y - ang.y)) 
		local adp = g.math.abs(g.math.NormalizeAngle(lpang.p - ang.p)) 
		
		if(ady > fov or adp > fov) then 
			return false 
		end
	end 
	return true, ady 
end

d.CreateMove = GAMEMODE.CreateMove 
function GAMEMODE:CreateMove(ucmd) 
	
	if (d.bools["aautoreload"]) or (d.bools["tautoreload"]) then 
		d:reload(ucmd)
	end 

	if (d.bools["aimbot"]) then 
		d:aimbot(ucmd) 
	end 

	if (d.bools["triggerbot"]) and !d.console and !g.gui.IsConsoleVisible() and !d.typing and !d.menuopen then 
		d:trigger(ucmd)
	end 

	if (d.bools["norecoil"]) then 
		local wep = g.LocalPlayer():GetActiveWeapon() 
		if IsValid(wep) and wep.Primary then 
			wep.Primary.Recoil = 0 
		end 
	end 

	if (d.bools["bhop"]) and !d.console and !g.gui.IsConsoleVisible() and !d.typing and !d.menuopen then 
		d:bhop(ucmd) 

	end 
	return self.BaseClass:CreateMove(ucmd)
end 

function d:trigger(ucmd)
local buttons = ucmd:GetButtons()
	local ply = g.LocalPlayer()
	local trace = g.util.GetPlayerTrace(ply)
	local traceRes = g.util.TraceLine(trace)
	local aimgroup = traceRes.HitGroup

	 if (d.bools["triggerplayer"] and traceRes.Entity:IsPlayer()) or (d.bools["triggernpc"] and traceRes.Entity:IsNPC()) and (traceRes.Entity:Alive() and traceRes.Entity:Health() > 0) then
			buttons= g.bit.band(buttons, bit.bnot(IN_ATTACK))
	 	if d.vars["triggertype"] == "Head" and aimgroup == HITGROUP_HEAD then
			buttons= g.bit.bor(buttons, IN_ATTACK)
		elseif d.vars["triggertype"] == "All" then
			buttons= g.bit.bor(buttons, IN_ATTACK)
		end
	end
	ucmd:SetButtons(buttons)
end

function d:bhop(ucmd) 
local buttons = ucmd:GetButtons()
if  g.input.IsKeyDown(d.binds["+bhop"].key) and 
			g.LocalPlayer():GetMoveType() != MOVETYPE_NOCLIP and 
			g.LocalPlayer():GetMoveType() != MOVETYPE_OBSERVER then
			if !g.LocalPlayer():OnGround() then 
			buttons= g.bit.band(buttons, bit.bnot(IN_JUMP))
			
		end
		ucmd:SetButtons(buttons)
	end
end

function d:reload(ucmd)
local buttons = ucmd:GetButtons()
buttons= g.bit.band(buttons, bit.bnot(IN_RELOAD))
if g.LocalPlayer():Alive() 
	and IsValid(g.LocalPlayer():GetActiveWeapon()) 
	and !g.table.HasValue(d.noreload,g.LocalPlayer():GetActiveWeapon():GetClass()) then 
		if g.LocalPlayer():GetActiveWeapon():Clip1() <= 0 then 
			buttons= g.bit.bor(buttons, IN_RELOAD)
		end
		
	end
	ucmd:SetButtons(buttons)
end
function d:drawbox(v)
	local color = v:IsPlayer() and g.team.GetColor(v:Team()) or g.Color(239,0,255)
	if d.vars["espbox"] == "3D" then
	local min, max = v:WorldSpaceAABB()
	local diff = max-min
        g.cam.Start3D()
                --[[Box ESP Base Created by Lenny]]--
				--[[Vertical Lines]]--
                g.render.DrawLine( min, min+g.Vector(0,0,diff.z), color )
                g.render.DrawLine( min+g.Vector(diff.x,0,0), min+g.Vector(diff.x,0,diff.z), color )
                g.render.DrawLine( min+g.Vector(0,diff.y,0), min+g.Vector(0,diff.y,diff.z), color)
                g.render.DrawLine( min+g.Vector(diff.x,diff.y,0), min+g.Vector(diff.x,diff.y,diff.z), color )
                --[[Top Horizontal Lines]]--
                g.render.DrawLine( max, max-g.Vector(diff.x,0,0) , color )
                g.render.DrawLine( max, max-g.Vector(0,diff.y,0) , color )
                g.render.DrawLine( max-g.Vector(diff.x, diff.y,0), max-g.Vector(diff.x,0,0) , color )
                g.render.DrawLine( max-g.Vector(diff.x, diff.y,0), max-g.Vector(0,diff.y,0) , color )
                 --[[Bottom Horizontal Lines]]--
                g.render.DrawLine( min, min+g.Vector(diff.x,0,0) , color )
                g.render.DrawLine( min, min+g.Vector(0,diff.y,0) , color )
                g.render.DrawLine( min+g.Vector(diff.x, diff.y,0), min+g.Vector(diff.x,0,0) , color )
                g.render.DrawLine( min+g.Vector(diff.x, diff.y,0), min+g.Vector(0,diff.y,0) , color )
		g.cam.End3D()
	end
	
	if d.vars["espbox"] == "2D" then
	local min1,max1 = v:WorldSpaceAABB()
	local min1,max1 = min1:ToScreen(),max1:ToScreen()
    local h = ( min1.y - max1.y )
    local w = ( h / 2 )
	g.surface.SetDrawColor(color)
	g.surface.DrawOutlinedRect( max1.x -w/2 , max1.y, w, h )  
	
	g.surface.SetDrawColor( g.Color(255,255,255,255) )
    g.surface.DrawOutlinedRect( max1.x -w/2  - 1, max1.y - 1, w  + 2, h + 2 )
    g.surface.DrawOutlinedRect( max1.x -w/2  + 1, max1.y + 1, w  - 2, h - 2 )
	end

	if d.bools["ehealthb"] then
	if v:GetPos():Distance(g.LocalPlayer():GetPos()) <= d.vars["esphdist"] and (v:IsPlayer() or v:IsNPC()) then
	local Health = 0
	local min1,max1 = v:WorldSpaceAABB()
	local min1,max1 = min1:ToScreen(),max1:ToScreen()
	local h = ( min1.y - max1.y )
	Health = g.math.min(100, (Health == v:Health() and Health) or g.Lerp(0.1, Health, v:Health()))
	local DrawHealth = g.math.Min(Health / v:Health(), 1)
	
	if d.vars["esphlocation"] =="Bottom" then
	g.draw.RoundedBox( 0, min1.x-2 , min1.y, 40, 6, g.Color(255,0,0,255)) 
    g.draw.RoundedBox(0, min1.x-2, min1.y, 400 * DrawHealth, 6,g.Color(0,255,0,255))
	end
	if d.vars["esphlocation"] =="Top" then
	g.draw.RoundedBox( 0, max1.x-2 , max1.y, 40, 6, g.Color(255,0,0,255)) 
    g.draw.RoundedBox(0, max1.x-2, max1.y, 400 * DrawHealth, 6, g.Color(0,255,0,255))
	end
   end
   end
	
end

d.HUDPaint = GAMEMODE.HUDPaint 
function GAMEMODE:HUDPaint() 

 for k,v in g.pairs(g.ents.GetAll()) do 
 
if d.bools["wallhack"] and IsValid(v) and v:GetPos():Distance(g.LocalPlayer():GetPos()) <= d.vars["espwdist"] then

local color = v:IsPlayer() and g.team.GetColor(v:Team()) or g.Color(239,0,255)
g.cam.Start3D()
if (d.bools["wents"] and !v:IsNPC() and !v:IsPlayer()) and g.table.HasValue(d.espents,v:GetClass()) then
	local color = g.Color(255,0,0)
	if d.vars["espwtype"] == "Wireframe" then
	v:SetMaterial("models/wireframe")
	elseif d.vars["espwtype"] == "Solid" then
	v:SetMaterial("models/debug/debugwhite")
	end
	
	g.render.SetColorModulation(color.r / 255, color.g / 255, color.b / 255) 
	g.render.SetBlend(color.a / 255) 
	v:SetColor(color) 
	v:DrawModel() 
	v:SetColor(Color(255,255,255)) 
	v:SetMaterial("")  
	
end

if (d.bools["wprops"] and !v:IsNPC() and !v:IsPlayer()) and v:GetClass() == "prop_physics" then
	if d.vars["espwtype"] == "Wireframe" then
	v:SetMaterial("models/wireframe")
	elseif d.vars["espwtype"] == "Solid" then
	v:SetMaterial("models/debug/debugwhite")
	end
	
	g.render.SetColorModulation(color.r / 255, color.g / 255, color.b / 255) 
	g.render.SetBlend(0.8) 
	v:SetColor(color) 
	v:DrawModel() 
	v:SetColor(Color(255,255,255)) 
	v:SetMaterial("")  
	
end

if d.bools["wplayers"] and v:IsPlayer() and v:Alive() and v:Health() > 0 and g.team.GetName(v:Team()) != "Spectators" and v != g.LocalPlayer()  then
	
	if d.vars["espwtype"] == "Wireframe" then
	v:SetMaterial("models/wireframe")
	elseif d.vars["espwtype"] == "Solid" then
	v:SetMaterial("models/debug/debugwhite")
	end
	
	g.render.SetColorModulation(color.r / 255, color.g / 255, color.b / 255) 
	g.render.SetBlend(color.a / 255) 
	v:SetColor(color) 
	v:DrawModel() 
	v:SetColor(Color(255,255,255)) 
	v:SetMaterial("")  
	

end


if d.bools["wnpcs"] and v:IsNPC() and v:Health() > 0 then

	if d.vars["espwtype"] == "Wireframe" then
	v:SetMaterial("models/wireframe")
	elseif d.vars["espwtype"] == "Solid" then
	v:SetMaterial("models/debug/debugwhite")
	end
	
	g.render.SetColorModulation(color.r / 255, color.g / 255, color.b / 255) 
	g.render.SetBlend(color.a / 255) 
	v:SetColor(color) 
	v:DrawModel() 
	v:SetColor(g.Color(255,255,255)) 
	v:SetMaterial("")  
	
end






g.cam.End3D() 
end
if d.bools["esp"] and IsValid(v) then
 	if (d.bools["eplayers"] and v:IsPlayer() and v:Alive() and v:Health() > 0 and g.team.GetName(v:Team()) != "Spectators") 
 		and v != g.LocalPlayer() and v:GetPos():Distance(g.LocalPlayer():GetPos()) <= d.vars["esptextdist"] then 
	if d.vars["esptype"] == "Body" then
		local y = -10 
		local pos = (v:GetPos()+g.Vector(0,0,45)):ToScreen() 
 		local rank = v:GetNetworkedInt("UserGroup") 
 		local color = g.Color(255,255,255,255) 
		d:drawbox(v)
		if d.bools["erpcash"] and v.DarkRPVars then
 		 g.draw.SimpleText("$: "..tostring(v.DarkRPVars.money), "BudgetLabel", pos.x, pos.y + y, color, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER) 
 		 y = y -12 
 		end
		if d.bools["epoints"] and v.PS_Points then
 		 g.draw.SimpleText("$: "..tostring(v.PS_Points), "BudgetLabel", pos.x, pos.y + y, color, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER) 
 		 y = y -12 
 		end
		if d.bools["ewep"] and v:GetActiveWeapon() and v:GetActiveWeapon().GetPrintName then
 		 g.draw.SimpleText("W: "..v:GetActiveWeapon():GetPrintName(), "BudgetLabel", pos.x, pos.y + y, color, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER) 
 		 y = y -12 
 		end
 		if d.bools["earmour"] then
 		 g.draw.SimpleText("A: "..v:Armor(), "BudgetLabel", pos.x, pos.y + y, color, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER) 
 		 y = y -12 
 		end
		if d.bools["ehealth"] then
 		 g.draw.SimpleText("H: "..v:Health(), "BudgetLabel", pos.x, pos.y + y, color, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER) 
 		 y = y -12 
 		end
 		if d.bools["ename"] then 
 			g.draw.SimpleText(v:Nick(), "BudgetLabel", pos.x, pos.y + y, color, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER) 
 			y = y -12 
 		end
 		if d.bools["erank"] then 
 			g.draw.SimpleText(rank, "BudgetLabel", pos.x, pos.y + y, color, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER) 
 			y = y -12 
 		end
	end
	
	if d.vars["esptype"] == "Top/Bottom" then
		local pos = (v:GetPos()+g.Vector(0,0,73)):ToScreen() 
		local pos2 = (v:GetPos()):ToScreen()
 		local rank = v:GetNetworkedInt("UserGroup") 
 		local color = g.Color(255,255,255,255) 
		d:drawbox(v)
		if d.bools["ename"] then 
 			g.draw.SimpleText(v:Nick(), "BudgetLabel", pos.x, pos.y, color, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER) 
 		end
		if d.bools["ehealth"] then 
 			g.draw.SimpleText("[H:"..v:Health().."]", "BudgetLabel", pos.x, pos.y, color,TEXT_ALIGN_LEFT,TEXT_ALIGN_CENTER)
 		end
		if d.bools["earmour"] then 
		local w= g.surface.GetTextSize("[H:"..v:Health().."]")
 			g.draw.SimpleText("[A:"..v:Armor().."]", "BudgetLabel", pos.x+w, pos.y, color,TEXT_ALIGN_LEFT,TEXT_ALIGN_CENTER)
 		end
		if d.bools["erank"] then 
 			g.draw.SimpleText(rank, "BudgetLabel", pos.x, pos.y-2, color,TEXT_ALIGN_CENTER,TEXT_ALIGN_TOP)
 		end
		if d.bools["ewep"] and v:GetActiveWeapon()  then 
		if v:GetActiveWeapon().GetPrintName then
 			g.draw.SimpleText("W: "..v:GetActiveWeapon():GetPrintName(), "BudgetLabel", pos2.x, pos2.y, color,TEXT_ALIGN_RIGHT,TEXT_ALIGN_CENTER)
		end
		end
		if d.bools["erpcash"] and v.DarkRPVars then 
 			g.draw.SimpleText(" $: "..tostring(v.DarkRPVars.money), "BudgetLabel", pos2.x, pos2.y, color,TEXT_ALIGN_LEFT,TEXT_ALIGN_CENTER)
		end
	end
	
		if d.vars["esptype"] == "Left/Right" then
		local pos = (v:GetPos()+g.Vector(0,0,45)):ToScreen() 
 		local rank = v:GetNetworkedInt("UserGroup") 
 		local color = g.Color(255,255,255,255) 
		d:drawbox(v)
		if d.bools["ename"] then 
 			g.draw.SimpleText(v:Nick(), "BudgetLabel", pos.x, pos.y, color, TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP) 
 		end
		if d.bools["ehealth"] then 
 			g.draw.SimpleText("H:"..v:Health(), "BudgetLabel", pos.x, pos.y+10, color,TEXT_ALIGN_RIGHT,TEXT_ALIGN_CENTER)
 		end
		if d.bools["earmour"] then 
		local w = g.surface.GetTextSize("H:"..v:Health())
		local w1 = g.surface.GetTextSize("A:"..v:Armor())
 			g.draw.SimpleText("A:"..v:Armor(), "BudgetLabel", pos.x-w+w1, pos.y+21, color,TEXT_ALIGN_RIGHT,TEXT_ALIGN_CENTER)
 		end
		if d.bools["erank"] then 
 			g.draw.SimpleText(rank, "BudgetLabel", pos.x, pos.y+26, color,TEXT_ALIGN_CENTER,TEXT_ALIGN_BOTTOM)
 		end
		if d.bools["ewep"] and v:GetActiveWeapon()  then 
		if v:GetActiveWeapon().GetPrintName then
 			g.draw.SimpleText("W: "..v:GetActiveWeapon():GetPrintName(), "BudgetLabel", pos.x+10, pos.y+10, color,TEXT_ALIGN_LEFT,TEXT_ALIGN_CENTER)
		end
		end
		if d.bools["erpcash"] and v.DarkRPVars then 
		local w = v:GetActiveWeapon().GetPrintName and g.surface.GetTextSize("W: "..v:GetActiveWeapon():GetPrintName()) or 0
		local w1 = g.surface.GetTextSize("$: "..tostring(v.DarkRPVars.money))
 			g.draw.SimpleText("$: "..tostring(v.DarkRPVars.money), "BudgetLabel", pos.x+10, pos.y+20, color,TEXT_ALIGN_LEFT,TEXT_ALIGN_CENTER)
		end
	end
	
	
 end
 if (d.bools["enpc"] and v:IsNPC() and v:Health() > 0) then
	if d.vars["esptype"] == "Body" then
		local y = -10 
		local pos = (v:GetPos()+g.Vector(0,0,45)):ToScreen() 
 		local color = g.Color(255,255,255,255) 
		d:drawbox(v)
		if d.bools["ewep"] and v:GetActiveWeapon() and v:GetActiveWeapon().GetPrintName then
 		 g.draw.SimpleText("W: "..v:GetActiveWeapon():GetPrintName(), "BudgetLabel", pos.x, pos.y + y, color, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER) 
 		 y = y -12 
 		end
		if d.bools["ehealth"] then
 		 g.draw.SimpleText("H: "..v:Health(), "BudgetLabel", pos.x, pos.y + y, color, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER) 
 		 y = y -12 
 		end
 		if d.bools["ename"] then 
 			g.draw.SimpleText(v.GetClass and v:GetClass() or "[NPC]", "BudgetLabel", pos.x, pos.y + y, color, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER) 
 			y = y -12 
 		end
	end	
		if d.vars["esptype"] == "Top/Bottom" then
		
		local pos = (v:GetPos()+g.Vector(0,0,73)):ToScreen() 
		local pos2 = (v:GetPos()):ToScreen() 
 		local color = g.Color(255,255,255,255) 
		d:drawbox(v)
		if d.bools["ename"] then 
 			g.draw.SimpleText(v.GetClass and v:GetClass() or "[NPC]", "BudgetLabel", pos.x, pos.y, color, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER) 
 		end
		if d.bools["ehealth"] then 
 			g.draw.SimpleText("[H:"..v:Health().."]", "BudgetLabel", pos.x, pos.y, color,TEXT_ALIGN_LEFT,TEXT_ALIGN_CENTER)
 		end
		if d.bools["ewep"] and v:GetActiveWeapon()  then 
		if v:GetActiveWeapon().GetPrintName then
 			g.draw.SimpleText("W: "..v:GetActiveWeapon():GetPrintName(), "BudgetLabel", pos2.x, pos2.y, color,TEXT_ALIGN_CENTER,TEXT_ALIGN_CENTER)
		end
		end
		
	end
	if d.vars["esptype"] == "Left/Right" then
		local pos = (v:GetPos()+g.Vector(0,0,45)):ToScreen() 
 		local rank = v:GetNetworkedInt("UserGroup") 
 		local color = g.Color(255,255,255,255) 
		d:drawbox(v)
		if d.bools["ename"] then 
 			g.draw.SimpleText(v.GetClass and v:GetClass() or "[NPC]", "BudgetLabel", pos.x, pos.y-5, color, TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP) 
 		end
		if d.bools["ehealth"] then 
 			g.draw.SimpleText("H:"..v:Health(), "BudgetLabel", pos.x, pos.y, color,TEXT_ALIGN_RIGHT,TEXT_ALIGN_CENTER)
 		end
		if d.bools["ewep"] and v:GetActiveWeapon()  then 
		if v:GetActiveWeapon().GetPrintName then
 			g.draw.SimpleText("W: "..v:GetActiveWeapon():GetPrintName(), "BudgetLabel", pos.x+10, pos.y, color,TEXT_ALIGN_LEFT,TEXT_ALIGN_CENTER)
		end
		end
	end
 end
 
  if (d.bools["eents"] and !v:IsNPC() and !v:IsPlayer()) then
	if g.table.HasValue(d.espents,v:GetClass()) then
	local pos = (v:GetPos()):ToScreen() 
	d:drawbox(v)
	g.draw.SimpleText(v.GetClass and v:GetClass() or "[Ent]", "BudgetLabel", pos.x, pos.y-5, Color(239,0,255), TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
	if v:GetClass() == "spawned_money" then 
	g.draw.SimpleText("$"..v:Getamount(), "BudgetLabel", pos.x, pos.y+4, Color(0,255,0), TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
	end
	end
  end
end

end
	if d.bools["crosshair"] then
		local w,h = g.ScrW()/2,g.ScrH()/2
		g.surface.SetDrawColor(g.Color(255,0,0))
		--horizontal
		g.surface.DrawLine(w-8, h, w+8, h)
		--vertical
        g.surface.DrawLine(w, h-8, w, h+8)
	end
	
d.HUDPaint(self)
end


end

