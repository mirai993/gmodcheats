--[[
	MOD/lua/autorun/client/propmenu.txt
	☆☆ luff you :3 | STEAM_0:0:38292541 <68.2.215.125:27005> | [22-10-13 10:33:28PM]
	===BadFile===
]]

--[[ thanks to bob for a few props and the buttons
bind a key to +quinprop_menu
clicking buttons copies the prop to the clipboard, bind the prop yourself by doing "bind e ((clipboard))" for example (no quotes no brackets) ]]
 
local function ShowFrame()
 
Frame = vgui.Create("DFrame")
Frame:SetSize( 761 , 400 )
Frame:SetPos( ScrW() / 2 - Frame:GetWide() / 2 , ScrH() / 2 - Frame:GetTall() / 2  )
Frame:SetTitle("Button menu")
Frame:SetVisible( true )
Frame:ShowCloseButton( true )
Frame.Paint = function()
        draw.RoundedBox( 8, 0, 0, Frame:GetWide(), Frame:GetTall(), Color( 0, 0, 0, 190 ) )
end
Frame:MakePopup()
 
 local BSheet = vgui.Create("DPropertySheet" , Frame)
BSheet:SetSize( 751 , 365 )
BSheet:SetPos( 5 , 25 )
BSheet.Paint = function()
        draw.RoundedBox( 8, 0, 0, BSheet:GetWide(), BSheet:GetTall(), Color( 0, 0, 0, 190 ) )
end
 
local Tab = vgui.Create("DLabel")
Tab:SetParent( BSheet )
Tab:SetPos( 0 , 10 )
Tab:SetText("")
 
local Tab2 = vgui.Create("DLabel")
Tab2:SetParent( BSheet )
Tab2:SetPos( 0 , 10 )
Tab2:SetText("")
 
local Tab3 = vgui.Create("DLabel")
Tab3:SetParent( BSheet )
Tab3:SetPos( 0 , 10 )
Tab3:SetText("")
 
local Tab4 = vgui.Create("DLabel")
Tab4:SetParent( BSheet )
Tab4:SetPos( 0 , 10 )
Tab4:SetText("")
 
local Tab5 = vgui.Create("DLabel")
Tab5:SetParent( BSheet )
Tab5:SetPos( 0 , 10 )
Tab5:SetText("")
 
 
 
 
 
 
// Options
 
 
 
local PropsLabel = vgui.Create("DLabel")
PropsLabel:SetParent( Tab )
PropsLabel:SetPos( 13 , 10 )
PropsLabel:SetText("")
PropsLabel:SetTextColor( Color(255 , 255 , 255 , 255 ) )
PropsLabel:SizeToContents()
 
local ESPLabel2 = vgui.Create("DLabel")
ESPLabel2:SetParent( Tab )
ESPLabel2:SetPos( 113 , 10 )
ESPLabel2:SetText("")
ESPLabel2:SetTextColor( Color(255 , 255 , 255 , 255 ) )
ESPLabel2:SizeToContents()
 
local ESPLabel3 = vgui.Create("DLabel")
ESPLabel3:SetParent( Tab )
ESPLabel3:SetPos( 206 , 10 )
ESPLabel3:SetText("")
ESPLabel3:SetTextColor( Color(255 , 255 , 255 , 255 ) )
ESPLabel3:SizeToContents()
 
local ESPLabel4 = vgui.Create("DLabel")
ESPLabel4:SetParent( Tab )
ESPLabel4:SetPos( 13 , 130  )
ESPLabel4:SetText("")
ESPLabel4:SetTextColor( Color(255 , 255 , 255 , 255 ) )
ESPLabel4:SizeToContents()
 
local ESPLabel5 = vgui.Create("DLabel")
ESPLabel5:SetParent( Tab )
ESPLabel5:SetPos( 118.5 , 235 )
ESPLabel5:SetText("")
ESPLabel5:SetTextColor( Color(255 , 255 , 255 , 255 ) )
ESPLabel5:SizeToContents()
 
 
local Props = vgui.Create( "DButton")
        Props:SetSize( 100, 30 )
        Props:SetPos( 10, 30 )
        Props:SetParent( Tab )
        Props:SetText( "flowerbarrel" )
        Props.DoClick = function( button )
                SetClipboardText(string.char(34) .."gm_spawn models/props/de_inferno/flower_barrel_p11.mdl" .. string.char(34))
                end
               
                local Props = vgui.Create( "DButton")
        Props:SetSize( 100, 30 )
        Props:SetPos( 113, 30 )
        Props:SetParent( Tab )
        Props:SetText( "sawblade" )
        Props.DoClick = function( button )
                SetClipboardText(string.char(34) .."gm_spawn models/props_junk/sawblade001a.mdl" .. string.char(34))
                end
 
        local Props = vgui.Create( "DButton")
        Props:SetSize( 100, 30 )
        Props:SetPos( 216, 30 )
        Props:SetParent( Tab )
        Props:SetText( "blueman angle" )
        Props.DoClick = function( button )
                SetClipboardText(string.char(34) .."gm_spawn models/props_phx/construct/glass/glass_angle360.mdl" .. string.char(34))
                end
               
                local Props = vgui.Create( "DButton")
        Props:SetSize( 100, 30 )
        Props:SetPos ( 319, 30 )
        Props:SetParent ( Tab )
        Props:SetText( "basket" )
        Props.DoClick = function( button )
                SetClipboardText(string.char(34) .."gm_spawn models/props/de_dust/grainbasket01c.mdl" .. string.char(34))
               
                end
 
                        local Props = vgui.Create( "DButton")
        Props:SetSize( 100, 30 )
        Props:SetPos( 10, 30 )
        Props:SetParent( Tab2 )
        Props:SetText( "tides" )
        Props.DoClick = function( button )
                SetClipboardText(string.char(34) .."gm_spawn models/props/de_tides/gate_large.mdl" .. string.char(34))
                end
 
                                local Props = vgui.Create( "DButton")
        Props:SetSize( 100, 30 )
        Props:SetPos( 113, 30 )
        Props:SetParent( Tab2 )
        Props:SetText( "blast door" )
        Props.DoClick = function( button )
                SetClipboardText(string.char(34) .."gm_spawn models/props_lab/blastdoor001c.mdl" .. string.char(34))
                end
               
                                local Props = vgui.Create( "DButton")
        Props:SetSize( 100, 30 )
        Props:SetPos( 216, 30 )
        Props:SetParent( Tab2 )
        Props:SetText( "longlockers" )
        Props.DoClick = function( button )
                SetClipboardText(string.char(34) .."gm_spawn models/props/de_train/Lockers_Long.mdl" .. string.char(34))
                end
               
                                local Props = vgui.Create( "DButton")
        Props:SetSize( 100, 30 )
        Props:SetPos( 319, 30 )
        Props:SetParent( Tab2 )
        Props:SetText( "lockers A" )
        Props.DoClick = function( button )
                SetClipboardText(string.char(34) .."gm_spawn models/props_c17/Lockers001a.mdl" .. string.char(34))
                end
               
                                        local Props = vgui.Create( "DButton")
        Props:SetSize( 100, 30 )
        Props:SetPos( 422, 30 )
        Props:SetParent( Tab2 )
        Props:SetText( "lockers B" )
        Props.DoClick = function( button )
                SetClipboardText(string.char(34) .."gm_spawn models/props/de_train/Lockers001a.mdl" .. string.char(34))
                end
                                        local Props = vgui.Create( "DButton")
        Props:SetSize( 100, 30 )
        Props:SetPos( 525, 30 )
        Props:SetParent( Tab2 )
        Props:SetText( "fridge" )
        Props.DoClick = function( button )
                SetClipboardText(string.char(34) .."gm_spawn models/props/CS_militia/refrigerator01.mdl" .. string.char(34))
                end
               
                                                        local Props = vgui.Create( "DButton")
        Props:SetSize( 100, 30 )
        Props:SetPos( 628, 30 )
        Props:SetParent( Tab2 )
        Props:SetText( "tv console" )
        Props.DoClick = function( button )
                SetClipboardText(string.char(34) .. "gm_spawn models/props/CS_militia/television_console01.mdl" .. string.char(34))
                end
               
                                                        local Props = vgui.Create( "DButton")
        Props:SetSize( 100, 30 )
        Props:SetPos( 10, 65 )
        Props:SetParent( Tab2 )
        Props:SetText( "truck" )
        Props.DoClick = function( button )
                SetClipboardText(string.char(34) .."gm_spawn models/props/de_train/utility_truck.mdl" .. string.char(34))
                end
               
                                                        local Props = vgui.Create( "DButton")
        Props:SetSize( 100, 30 )
        Props:SetPos( 113, 65 )
        Props:SetParent( Tab2 )
        Props:SetText( "canal bars" )
        Props.DoClick = function( button )
                SetClipboardText(string.char(34) .."gm_spawn models/props_canal/canal_bars004.mdl" .. string.char(34))
                end
               
                                                        local Props = vgui.Create( "DButton")
        Props:SetSize( 100, 30 )
        Props:SetPos( 319, 65 )
        Props:SetParent( Tab2 )
        Props:SetText( "carousel" )
        Props.DoClick = function( button )
                SetClipboardText(string.char(34) .."gm_spawn models/props_c17/playground_carousel01.mdl" .. string.char(34))
                end
               
                                                        local Props = vgui.Create( "DButton")
        Props:SetSize( 100, 30 )
        Props:SetPos( 216, 65 )
        Props:SetParent( Tab2 )
        Props:SetText( "shitty canalbar" )
        Props.DoClick = function( button )
                SetClipboardText(string.char(34) .."gm_spawn models/props_canal/pipe_bracket001.mdl" .. string.char(34))
                end
 
               
                                                                local Props = vgui.Create( "DButton")
                Props:SetSize( 100, 30 )
        Props:SetPos( 525, 65 )
        Props:SetParent( Tab2 )
        Props:SetText( "gazebo/cage" )
        Props.DoClick = function( button )
                SetClipboardText(string.char(34) .."gm_spawn models/props/cs_havana/gazebo.mdl" .. string.char(34))
                end
 
                local Props = vgui.Create( "DButton")
                Props:SetSize( 100, 30 )
        Props:SetPos( 628, 65 )
        Props:SetParent( Tab2 )
        Props:SetText( "propsareawesome" )
        Props.DoClick = function( button )
                SetClipboardText(string.char(34) .."gm_spawn models/props/de_train/TunnelArch.mdl" .. string.char(34))
                end
               
                local Props = vgui.Create( "DButton")
                Props:SetSize( 100, 30 )
        Props:SetPos( 422, 65 )
        Props:SetParent( Tab2 )
        Props:SetText( "tire" )
        Props.DoClick = function( button )
                SetClipboardText(string.char(34) .."gm_spawn models/props_phx/wheels/moped_tire.mdl" .. string.char(34))
                end
 
                local Props = vgui.Create ( "DButton")
                Props:SetSize( 100, 30 )
                Props:SetPos( 525, 65 )
                Props:SetParent( Tab2 )
                Props:SetText( "loud truck" )
                Props.DoClick = function( button )
                SetClipboardText(string.char(34) .. "gm_spawn models/props_vehicles/car003a_physics.mdl" .. string.char(34))
        end
               
                local Props = vgui.Create( "DButton")
                Props:SetSize( 100, 30 )
        Props:SetPos( 10, 30 )
        Props:SetParent( Tab3 )
        Props:SetText( "Rollercoaster" )
        Props.DoClick = function( button )
                SetClipboardText(string.char(34) .."gm_spawn models/XQM/CoasterTrack/slope_225_4.mdl" .. string.char(34))
                end
               
                local Props = vgui.Create( "DButton")
                Props:SetSize( 100, 30 )
        Props:SetPos( 113, 30 )
        Props:SetParent( Tab3 )
        Props:SetText( "storage tank" )
        Props.DoClick = function( button )
                SetClipboardText(string.char(34) .."gm_spawn models/props/de_nuke/storagetank.mdl" .. string.char(34))
                end
               
                local Props = vgui.Create( "DButton")
                Props:SetSize( 100, 30 )
        Props:SetPos( 216, 30 )
        Props:SetParent( Tab3 )
        Props:SetText( "hulladoll" )
        Props.DoClick = function( button )
                SetClipboardText(string.char(34) .."gm_spawn models/props_lab/huladoll.mdl" .. string.char(34))
                end
               
                local Props = vgui.Create( "DButton")
                Props:SetSize( 100, 30 )
        Props:SetPos( 319, 30 )
        Props:SetParent( Tab3 )
        Props:SetText( "cluster" )
        Props.DoClick = function( button )
                SetClipboardText(string.char(34) .."gm_spawn models/props_docks/piling_cluster01a.mdl" .. string.char(34))
                end
               
                local Props = vgui.Create( "DButton")
                Props:SetSize( 100, 30 )
        Props:SetPos( 525, 30 )
        Props:SetParent( Tab3 )
        Props:SetText( "pole" )
        Props.DoClick = function( button )
                SetClipboardText(string.char(34) .."gm_spawn models/props_docks/dockpole01a.mdl" .. string.char(34))
                end
               
                        local Props = vgui.Create( "DButton")
                Props:SetSize( 100, 30 )
        Props:SetPos( 628, 30 )
        Props:SetParent( Tab3 )
        Props:SetText( "window 1" )
        Props.DoClick = function( button )
                SetClipboardText(string.char(34) .."gm_spawn models/props/CS_militia/skylight_glass.mdl" .. string.char(34))
                end
               
                                        local Props = vgui.Create( "DButton")
                Props:SetSize( 100, 30 )
        Props:SetPos( 10, 65 )
        Props:SetParent( Tab3 )
        Props:SetText( "breen tube" )
        Props.DoClick = function( button )
                SetClipboardText(string.char(34) .."gm_spawn models/props_combine/breen_tube.mdl" .. string.char(34))
                end
 
                local Props = vgui.Create( "DButton")
                Props:SetSize( 100, 30 )
        Props:SetPos( 113, 65 )
        Props:SetParent( Tab3 )
        Props:SetText( "propane tank" )
        Props.DoClick = function( button )
                SetClipboardText(string.char(34) .."gm_spawn models/props_junk/propane_tank001a.mdl" .. string.char(34))
                end
 
                local Props = vgui.Create( "DButton" )
                Props:SetSize( 100, 30 )
        Props:SetPos( 216, 65 )
        Props:SetParent ( Tab3 )
        Props:SetText ( "biohazardtank" )
        Props.DoClick = function( button )
                SetClipboardText(string.char(34) .. "gm_spawn models/props/de_train/biohazardtank.mdl" .. string.char(34))
        end
 
                local Props = vgui.Create( "DButton")
                Props:SetSize( 100, 30 )
        Props:SetPos( 319, 65 )
        Props:SetParent( Tab3 )
        Props:SetText( "portalskydome" )
        Props.DoClick = function( button )
                SetClipboardText(string.char(34) .."gm_spawn models/props_combine/portalskydome.mdl" .. string.char(34))
        end
 
 
                local Props = vgui.Create( "DButton")
                Props:SetSize( 100, 30 )
        Props:SetPos( 422, 30 )
        Props:SetParent( Tab3 )
        Props:SetText( "window 2" )
        Props.DoClick = function( button )
                SetClipboardText(string.char(34) .."gm_spawn models/props/CS_militia/wndw01.mdl" .. string.char(34))
                end
 
                local Props = vgui.Create( "DButton" )
                Props:SetSize( 100, 30 )
        Props:SetPos( 422, 65 )
        Props:SetParent( Tab3 )
        Props:SetText( "wheel" )
        Props.DoClick = function( button )
                SetClipboardText(string.char(34) .. "gm_spawn models/props_phx/wheels/metal_wheel2.mdl" .. string.char(34))
        end
 
                local Props = vgui.Create ( "DButton" )
                Props:SetSize( 100, 30 )
        Props:SetPos( 525, 65 )
        Props:SetParent( Tab3 )
        Props:SetText( "crowbar" )
        Props.DoClick = function( button )
                SetClipboardText(string.char(34) .. "gm_spawn models/weapons/w_crowbar.mdl" .. string.char(34))
        end
 
                        local Props = vgui.Create( "DButton")
                Props:SetSize( 100, 30 )
        Props:SetPos( 10, 30 )
        Props:SetParent( Tab4 )
        Props:SetText( "parliament" )
        Props.DoClick = function( button )
                SetClipboardText(string.char(34) .."gm_spawn models/props_rooftop/parliament_dome_destroyed_exterior.mdl" .. string.char(34))
                end
 
                                local Props = vgui.Create( "DButton")
                Props:SetSize( 100, 30 )
        Props:SetPos( 216, 30 )
        Props:SetParent( Tab4 )
        Props:SetText( "project build.3" )
        Props.DoClick = function( button )
                SetClipboardText(string.char(34) .."gm_spawn models/props_buildings/project_building03.mdl" .. string.char(34))
                end
               
                                local Props = vgui.Create( "DButton")
                Props:SetSize( 100, 30 )
        Props:SetPos( 319, 30 )
        Props:SetParent( Tab4 )
        Props:SetText( "prison" )
        Props.DoClick = function( button )
                SetClipboardText(string.char(34) .."gm_spawn models/props_combine/prison01c.mdl" .. string.char(34))
                end
               
                                local Props = vgui.Create( "DButton")
                Props:SetSize( 100, 30 )
        Props:SetPos( 422, 30 )
        Props:SetParent( Tab4 )
        Props:SetText( "building" )
        Props.DoClick = function( button )
                SetClipboardText(string.char(34) .."gm_spawn models/props_buildings/building_002a.mdl" .. string.char(34))
                end
               
 
 
 
                        local Props = vgui.Create( "DButton")
                Props:SetSize( 100, 30 )
        Props:SetPos( 113, 30 )
        Props:SetParent( Tab4 )
        Props:SetText( "project build.2" )
        Props.DoClick = function( button )
                SetClipboardText(string.char(34) .."gm_spawn models/props_buildings/project_building02.mdl" .. string.char(34))
                end
 
 
 
                local Props = vgui.Create( "DButton")
                Props:SetSize( 100, 30 )
        Props:SetPos( 525, 30 )
        Props:SetParent( Tab4 )
        Props:SetText( "church" )
        Props.DoClick = function( button )
                SetClipboardText(string.char(34) .."gm_spawn models/props_buildings/row_church_fullscale.mdl" .. string.char(34))
                end
 
               
                local Props = vgui.Create( "DButton")
                Props:SetSize( 100, 30 )
        Props:SetPos( 628, 30 )
        Props:SetParent( Tab4 )
        Props:SetText( "church 2" )
        Props.DoClick = function( button )
                SetClipboardText(string.char(34) .."gm_spawn models/props_buildings/row_res_2_fullscale.mdl" .. string.char(34))
                end
 
                        local Props = vgui.Create( "DButton")
                Props:SetSize( 100, 30 )
        Props:SetPos( 10, 30 )
        Props:SetParent( Tab5 )
        Props:SetText( "torpedo" )
        Props.DoClick = function( button )
                SetClipboardText(string.char(34) .."gm_spawn models/props_phx/torpedo.mdl" .. string.char(34))
                end
 
                local Props = vgui.Create( "DButton")
                Props:SetSize( 100, 30 )
        Props:SetPos( 113, 30 )
        Props:SetParent( Tab5 )
        Props:SetText( "amraam" )
        Props.DoClick = function( button )
                SetClipboardText(string.char(34) .."gm_spawn models/props_phx/amraam.mdl" .. string.char(34))
                end
 
 
        local Props = vgui.Create( "DButton")
                Props:SetSize( 100, 30 )
        Props:SetPos( 216, 30 )
        Props:SetParent( Tab5 )
        Props:SetText( "ww2 bomb" )
        Props.DoClick = function( button )
                SetClipboardText(string.char(34) .."gm_spawn models/props_phx/ww2bomb.mdl" .. string.char(34))
                end
               
                        local Props = vgui.Create( "DButton")
                Props:SetSize( 100, 30 )
        Props:SetPos( 319, 30 )
        Props:SetParent( Tab5 )
        Props:SetText( "mk 82 bomb" )
        Props.DoClick = function( button )
                SetClipboardText(string.char(34) .."gm_spawn models/props_phx/mk-82.mdl" .. string.char(34))
                end
 
 
 
 
               
BSheet:AddSheet( "Surfprops", Tab, "gui/silkicons/heart", false, false, "" )
BSheet:AddSheet( "Killprops", Tab2, "gui/silkicons/heart", false, false, "" )
BSheet:AddSheet( "Miscellaneous", Tab3, "gui/silkicons/heart", false, false, "" )
BSheet:AddSheet( "Buildings", Tab4, "gui/silkicons/heart", false, false, "" )
BSheet:AddSheet( "Explosives", Tab5, "gui/silkicons/heart", false, false, "" )
end
concommand.Add("+quinprop_menu",ShowFrame)
concommand.Add("-quinprop_menu",function()
Frame:SetVisible( false )
end)