if ( !CLIENT ) then return end

--[[
dddddd______________________hhhhhhh_______hhhhhhh_____________aaa_____________kkkkkkk__________kkkkkk_________________
dllllld_____________________hlllllh_______hlllllh____________allla____________klllllk_________kllllk__________________
dlllllld____________________hlllllh_______hlllllh____________allla____________klllllk________kllllk___________________
dllllllld___________________hlllllh_______hlllllh___________allllla___________klllllk_______kllllk____________________
dlllllllld__________________hlllllh_______hlllllh___________allllla___________klllllk______kllllk_____________________
dlllddlllld_________________hlllllh_______hlllllh__________allllllla__________klllllk_____kllllk______________________
dllld dlllld________________hlllllh_______hlllllh__________alllallla__________klllllk____kllllk_______________________
dllld  dlllld_______________hlllllh_______hlllllh_________allla_allla_________klllllk___kllllk________zzzzzzzzzzzzzzz_
dllld   dlllld______________hlllllhhhhhhhhhlllllh_________allla_allla_________klllllk__kllllk__________zlllllllllllz__
dllld    dlllld____ddddddd__hlllllllllllllllllllh________allla___allla________klllllkkkllllk____________zzzzzzzlllz___
dllld     dlllld___d     D__hlllllllllllllllllllh________allla___allla________klllllllllllk__________________zlllz____           */             ______________________
dllld     dllllld__ddddddd__hlllllllllllllllllllh_______allllaaaaalllla_______klllllllllllk_________________zlllz_____          T/              | All Aboard the Rape |
dllld    dllllld____________hlllllllllllllllllllh_______allllllllllllla_______klllllkkkllllk_______________zlllz______         o/               | Train! The Brakes   |
dllld   dllllld_____________hlllllllllllllllllllh______allllllllllllllla______klllllk__kllllk_____________zlllz_______        o/                | May Not Work But    |
dllld  dllllld______________hlllllhhhhhhhhhlllllh______allllaaaaaaalllla______klllllk___kllllk___________zlllzzzzzzz__       T/                 \ That Has Never      |
dllld dllllld_______________hlllllh_______hlllllh_____alllla_______alllla_____klllllk____kllllk_________zlllllllllllz_      */                   \ Stopped Us Before! |
dlllddllllld________________hlllllh_______hlllllh_____alllla_______alllla_____klllllk_____kllllk_______zzzzzzzzzzzzzzz                            \    _______________|
dllllllllld_________________hlllllh_______hlllllh____alllla_________alllla____klllllk______kllllk_____________________                 ()          |  /
dlllllllld__________________hlllllh_______hlllllh____alllla_________alllla____klllllk_______kllllk____________________                    ()       | /
dllllllld___________________hlllllh_______hlllllh___alllla___________alllla___klllllk________kllllk___________________                       0     |/     \*
dlllllld____________________hlllllh_______hlllllh___alllla___________alllla___klllllk_________kllllk__________________                       __            \T
ddddddd_ ___________________hhhhhhh_______hhhhhhh__aaaaaa_____________aaaaaa__kkkkkkk__________kkkkkk________________________________________||_            \o
_|"""""|_|"""""|_|"""""|_|"""""|_|"""""|_|"""""|_|"""""|_|"""""|_|"""""|_|"""""|_|"""""|_|"""""|_|"""""|_|"""""|_|"""""|_|"""""|_|"""""|_|"[]"--|_           \o
"`-0-0-'"`-0-0-'"`-0-0-'"`-0-0-'"`-0-0-'"`-0-0-'"`-0-0-'"`-0-0-'"`-0-0-'"`-0-0-'"`-0-0-'"`-0-0-'"'-0-0-'"`-0-0-'"`-0-0-'"`-0-0-'"`-0-0-'"`-0-00-\\\           \T
--]]          
--DHAK public release 

if ( DHAK ) then 
	_G.rawset(_G, "DHAK", nil) 
end

local DHAK = DHAK or { ["Funcs"] = {} }

//thanks dem 
DHAK["Funcs"] = {
["CreateMove"] = {},
["HUDPaint"] = {},
["Think"] = {},
["RenderScreenspaceEffects"] = {},
}

local me = LocalPlayer()

DHAK["Bools"] = {
["Ignore Team"] = true,
["Anti_SS"] = true,
["ESP"] = true,
["BHOP"] = false,
["IgnoreSteamFriends"] = false,
["AutoShoot"] = false,
["ignoreadmins"] = true,
["MonNet"] = false,
["MonRCC"] = false,
["TargetFriends"] = false,
["AttatchmentAIM"] = false,
["BoneAim"] = true,
["Chams"] = false,
["AimbotBench"] = false,
["Laser"] = false,
["rapidfire"] = false,
}

DHAK["Vars"] = {
["aim_fov"] = 32,
}

DHAK["Hooks"] = {}

DHAK["Detours"] = {}

DHAK["Friends"] = {}

DHAK["Spectators"] = {}

DHAK["Admins"] = {}

DHAK["DeadPlayers"] = {}

DHAK["Cones"] = {}

DHAK["Binds"] = {
["+menu"] = KEY_L,
["+speedhack"] = KEY_V,
["Aimbot"] = KEY_F,
}

DHAK["Target"] = nil

DHAK["Shooting"] = false

DHAK["Typing"] = false

DHAK["Locked"] = false

//thanks rhook
DHAK["ANG"] = FindMetaTable( "Angle" )

DHAK["VEC"] = FindMetaTable( "Vector" )

DHAK["ENT"] = FindMetaTable( "Entity" )

DHAK["Meta"] = FindMetaTable( "Player" )

DHAK["cmd"] = FindMetaTable( "CUserCmd" )

local _T = debug["getregistry"]()

DHAK["NS"] = _T["Entity"]["FireBullets"]

DHAK["Colors"] = {
["Red"] = Color( 255, 0, 0, 255 ),
["DarkRed"] = Color( 200, 50, 50, 255 ),
["Black"] = Color( 0, 0, 0 ),
["Blue"] = Color( 0, 0, 255 ),
["Red"] = Color( 255, 0, 0 ),
["White"] = Color( 255, 255, 255 ),
["Grey"] = Color( 64, 64, 64 ),
["Green"] = Color( 0, 255, 0 ),
["Cyan"] = Color( 0, 255, 255 ),
["SexyRed"] = Color( 255, 50, 63 ),
["FaggotGreen"] = Color( 100, 255, 100 ),
["FaggotRed"] = Color( 255, 100, 100 ),
["Purple"] = Color( 129, 0, 255 ),
["Teal"] = Color( 0, 102, 102 ),
["Pink"] = Color( 255, 0, 127 ),
["DarkBlue"] = Color( 0, 0, 207 ),
["SexyBlue"] = Color( 51, 51, 255 ),
["LightGreen"] = Color( 102, 255, 102 ),
["Brown"] = Color( 51, 25, 0 ),
["TransRed"] = Color( 150, 0, 0, 125 ),
["TransBlack"] = Color( 0, 0, 0, 225 ),
["Random"] = Color( math["random"]( 1, 255 ), math["random"]( 1, 255 ), math["random"]( 1, 255 ) ),
}

surface["CreateFont"]( "DHAK", {
 size = 17, weight = 400,
})

surface["CreateFont"]( "DHAKzESP", {
    size = 10
} )

function DHAK.Message( col, txt )
	chat["AddText"]( DHAK["Colors"]["DarkRed"],  "[ DHAK ]: " )
	chat["AddText"]( col, txt .. "\n" )
end

function DHAK.GetBool( Bool )
	return DHAK["Bools"][Bool]
end

function DHAK.GetVar( Var )
	return DHAK["Vars"][ Var ]
end

function DHAK.MenuOpen( Bind )
	if !DHAK["Typing"] then 
		return input["IsKeyDown"]( DHAK["Binds"][ Bind ] )
	else
		return false
	end
end

//thanks kokomika/ari
function DHAK.drawtext( txt, x, y, col )
	draw.SimpleTextOutlined( txt, "DHAKzESP", x, y, col, TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT, 1, DHAK["Colors"]["Red"] )
end

//thanks rhook
function DHAK.GetPlayer()
 	local ptr = {}
	local allplayer = player["GetAll"]()
for i = 1, #allplayer do
		local v = allplayer[i]
		if !IsValid( v ) or v == me or me:Health( v ) < 1 or team["GetName"]( v:Team( v )) == 1002 then continue end
for i = 1,1 do		  
	ptr[#ptr+1] = v;
	    end  
    end
	return ptr
end

function DHAK.ESPPlayerGet()
 	local Rtard = {}
	local LEL = player["GetAll"]()
for i = 1, #LEL do
		local v = LEL[i]
		if !IsValid( v ) or v == me or me:Health( v ) < 1 or team["GetName"]( v:Team( v )) == 1002 then continue end
for i = 1,1 do	   
        Rtard[#Rtard+1] = v;	   
	    end
    end
	return Rtard
end

function DHAK.Detour ( Old, New )
	DHAK["Detours"][New] = Old
	return New
end

//thanks rhook
function DHAK.load (sack)
	require (sack)
	DHAK["Message"]( DHAK["Colors"]["Green"], " Has Loaded Modules" )
end

DHAK["load"]( "datastream" ) // not a DHAK module....
DHAK["load"]( "dickwrap" ) // not a DHAK module....

local _DHAK = _G["NHTable"]// fuck is he ? .. is HE DHAKING!?!?!? 
_G["NHTable"] = nil // -.- yep its a DHAKer shit... houston.... we have a problem.

//thanks tyler if you made this .. pretty sure you didnt but its cool
function DHAK.RegisterHook ( Type, Function )
	DHAK["Message"]( DHAK["Colors"]["Green"], "Hooking function " .. Type .." into " .. string["Replace"]( tostring( Function ), "function: ", "" ) )
for i = 1,1 do	
	DHAK["Hooks"][#DHAK["Hooks"]+1] = string["Replace"]( tostring( Function ), "function: ", "" );
	end
	return hook["Add"]( Type, string["Replace"]( tostring( Function ), "function: ", "" ), Function )
end

function DHAK.AddFriend ( e )
for i = 1,1 do	
	DHAK["Friends"][#DHAK["Friends"]+1] = e:Nick();
	end
	DHAK["Message"]( DHAK["Colors"]["Green"], " Added friend " .. e:Nick() )
end

function DHAK.RemoveFriend ( e )
for i = 1,1 do
	DHAK["Friends"][#DHAK["Friends"]] = nil;
	end
	DHAK["Message"]( DHAK["Colors"]["Red"], " Removed friend " .. e:Nick() )
end

//thanks rhook
function DHAK.GetWeapon ()
	local w = me:GetActiveWeapon()
	if !IsValid( w ) then return nil end
	local class = me:GetClass( w )
	return class
end

_T["Entity"]["FireBullets"] = function ( p, data )
	local spread = data["Spread"]
	if !spread then 
		return DHAK["NS"]( p, data )
	end
	local wep = DHAK["GetWeapon"]()
	if !wep then 
		return DHAK["NS"]( p, data )
	end
	if DHAK["Cones"][wep] == spread * -1 then 
		return DHAK["NS"]( p, data )
	end
	DHAK["Cones"][wep] = spread * -1
	return DHAK["NS"]( p, data )
end

function DHAK.PredictSpread ( ucmd, ang, shit )
	local wep = DHAK["GetWeapon"]()
	if !wep then return ang end
	if !DHAK["Cones"][wep] then return ang end
	return DHAK.VEC.Angle( dickwrap.Predict( ucmd, DHAK.ANG.Forward( ang ), DHAK["Cones"][wep] ) )
end

//thanks d3m for this wonderful life saving function
function DHAK.Aimspotfunc( e )
local forward = Vector()
local eyes = Vector()
local head = Vector()
local center = Vector()
if DHAK["GetBool"]("AttatchmentAIM") then		
    if ( e:LookupAttachment( "forward" ) ~= 0 ) then
           forward = e:GetAttachment( e:LookupAttachment( "forward" ) )
		    if ( forward ) and ( forward["Pos"] ) then
				return forward["Pos"]
			end
        end
        if ( e:LookupAttachment( "eyes" ) ~= 0 ) then
            eyes = e:GetAttachment( e:LookupAttachment( "eyes" ) )
            
			if ( eyes ) and ( eyes["Pos"] ) then
				return eyes["Pos"]
			end
        end
	end
if DHAK["GetBool"]("BoneAim") then	
if e:LookupBone( "ValveBiped.Bip01_Head1" ) then
        head = e:GetBonePosition( e:LookupBone( "ValveBiped.Bip01_Head1" ) )
			
		if ( head ) then
				return head
			end
		end
		if ( e:OBBCenter() and e:GetPos() ) then
			center = ( e:GetPos() + e:OBBCenter() )
			
			if ( center ) then
				return center
			end
		end
	end
end
	
function DHAK.Aimspot( e )		
	local pos = DHAK["Aimspotfunc"]( e )
	return pos
end

function DHAK.IsVisible( v )
		local trace = util["TraceLine"]( {
		start = me:GetShootPos(),
		endpos = DHAK["Aimspot"]( v ),
		filter = { me, v },
		mask = MASK_SHOT + CONTENTS_WINDOW
	} )
	if (( trace["Fraction"] >= 0.99 )) then return true end
	return false
end

function DHAK.IsValid( e )

if ( !IsValid( e ) || e == me ) then
	return false
end

if ( !e:Alive() || !e:IsPlayer() ) then 
	return false 
end

if e:GetMaterial() == "models/props_combine/stasisshield_sheet" then
	return false
end

if me:GetColor()["a"] < 255 then
	return false
end

local col = e:GetColor()
if col["a"] < 255 then
	return false
end

if ( e:GetMoveType() == MOVETYPE_OBSERVER || e:Team() == TEAM_SPECTATOR ) then 
	return false 
end

return true
end

function DHAK.Aim( e )

if ( !IsValid( e ) || e == me ) then
	return false
end

if ( !e:Alive() || !e:IsPlayer() || e:InVehicle() ) then 
	return false 
end

if DHAK["GetBool"]("ignoreadmins") && e:IsAdmin() then return false end

if ( GetConVarNumber( "sbox_noclip" ) == 0 && e:GetMoveType() == MOVETYPE_NOCLIP ) then 
	return false 
end

if DHAK["GetBool"]("IgnoreSteamFriends") then
	if e:GetFriendStatus() == "friend" then 
		return false 
	end
end	
	
if ( e:Team() == me:Team() ) then
       if DHAK["GetBool"]("Ignore Team") then	
		return false
	end
end	

if ( !DHAK["GetBool"]( "aim_targetfriends" ) && table["HasValue"]( DHAK["Friends"], e:Nick() ) ) then return false end
	
if ( DHAK["GetBool"]( "aim_targetfriends" ) && !table["HasValue"]( DHAK["Friends"], e:Nick() ) ) then return false end

if ( !DHAK["InFov"]( e ) ) then return false end

if e:GetMaterial() == "models/props_combine/stasisshield_sheet" then
	return false
end

if ( e:GetMoveType() == MOVETYPE_OBSERVER || e:Team() == TEAM_SPECTATOR ) then 
	return false 
end

if string["find"]( GAMEMODE["Name"] , "Trouble in Terror" ) then
	if ( me:IsTraitor() && e:IsTraitor() ) then
		return false
	end
end

if me:GetColor()["a"] < 255 then
	return false
end

local col = e:GetColor()
if col["a"] < 255 then
	return false
end

if !DHAK["IsVisible"]( e ) then
	return false
end
	return true
end

function DHAK.GetTarget()
    distance = math["huge"]
	local AllNigs = DHAK["GetPlayer"]()
	for i = 1, #AllNigs do
	local v = AllNigs[i]
		if DHAK["Aim"]( v ) then
			local distance2 = v:GetPos():DistToSqr( me:GetPos() )
			if distance2 < distance then
				distance = distance2
				DHAK["Target"] = v
			end
		end
	end
	return DHAK["Target"]
end

function DHAK.NormalizeAngles( Angl )
	Angl["p"] = math["NormalizeAngle"]( Angl["p"] )
	Angl["y"] = math["NormalizeAngle"]( Angl["y"] )
	Angl["r"] = 0  
end

//thanks rhook
function DHAK.Prediction( Pos, e )
    local plySpeed = me:GetVelocity() / 0.0067 - DHAK["Target"]:GetVelocity() / 0.0067
	return Pos 
end

function DHAK.IsAdmin( v )
if v:IsAdmin() then
	return true
end
	
if v:IsSuperAdmin() then
	return true
end
	
if v:IsUserGroup( "admin" ) then
	return true
end
	
if v:IsUserGroup( "superadmin" ) then
	return true
end
		
if v:IsUserGroup( "moderator" ) or v:IsUserGroup( "mod" ) or v:IsUserGroup( "trialmod" ) then
	return true
end
	
if v:IsUserGroup( "owner" ) then
	return true
	end
end	

//thanks kokomika/ari
function DHAK.dormant( e )
if !_G["QAC"] then
	if #DHAK["ESPPlayerGet"]() >= 15 then 
		return _DHAK["IsDormant"]( e:EntIndex() )
	else
		return false
		end
	end
end

//thanks p0mf and kokomika/ari
function DHAK.Funcs.CreateMove( ucmd )
DHAK["Target"] = DHAK["GetTarget"]()
if ( DHAK["MenuOpen"]( "Aimbot" ) && !DHAK["Typing"] ) then
		if( !DHAK["Target"] ) then return end
		DHAK["Angles"] = ucmd:GetViewAngles()
		if DHAK["Aim"]( DHAK["Target"] ) then
			
			DHAK["Locked"] = true 
		
			DHAK["Angles"] = ( DHAK["Prediction"]( DHAK["Aimspot"]( DHAK["Target"] ) ) - Vector( 0, 0, 0 ) )
			
			DHAK["Angles"] = ( DHAK["Angles"] - me:GetShootPos() ):GetNormal():Angle()
			DHAK["SetAngle"] = DHAK["PredictSpread"]( ucmd, Angle( DHAK["Angles"]["p"], DHAK["Angles"]["y"], 0 ) )
			DHAK["ViewAngles"] = ucmd:GetViewAngles()
			
			DHAK["NormalizeAngles"]( DHAK["Angles"] )

			 _DHAK["SetViewAngles"]( ucmd, DHAK["SetAngle"] )
			
			
		if DHAK["GetBool"]("AutoShoot") then	
			ucmd:SetButtons( bit["bor"]( ucmd:GetButtons(), IN_ATTACK ) )
		    end	
		end
	end	
if DHAK["GetBool"]("BHOP") then
		if (!me:IsOnGround() && me:Alive() ) then
			ucmd:SetButtons( bit["band"]( ucmd:GetButtons(), bit["bnot"]( IN_JUMP ) ) )
		end
   end
   	if DHAK["GetBool"]("NoRecoil") then 
	local weapon = me:GetActiveWeapon()

	if !IsValid(weapon) then
		return
	end

	if weapon["Primary"] then
	
		if weapon["Primary"]["Recoil"] then
			weapon["Primary"]["Recoil"] = 0
		end

		if weapon["Primary"]["KickUp"]  or weapon["Primary"]["ViewKick"] then
			weapon["Primary"]["KickUp"] = 0
			weapon["Primary"]["KickDown"] = 0
			weapon["Primary"]["KickHorizontal"] = 0
			weapon["Primary"]["ViewKick"] = 0
	        weapon["Primary"]["VelocitySensitivity"] = 0
	        weapon["Primary"]["MaxSpreadInc"] = 0
	        weapon["Primary"]["HipCone"] = 0
	        weapon["Primary"]["SpreadPerShot"] = 0
	        weapon["Primary"]["AimCone"] = 0	
		    end
	    end
    end
	if me:GetActiveWeapon()["Primary"] then
		me:GetActiveWeapon()["Primary"]["Recoil"] = 0
	end
end 

//thanks kokomika/ari 
function DHAK.Funcs.HUDPaint()
local DHAKz = "DHAK v4.98 Beta"
draw["DrawText"]( DHAKz, "DHAK", 5, 5, DHAK["Colors"]["Green"] )
local ESPplys = DHAK["ESPPlayerGet"]()
for i = 1, #ESPplys do
	local v = ESPplys[i]
if !DHAK["GetBool"]("ESP") then
	return 
end
if v != me and !DHAK["dormant"]( v ) and v:Alive() then
    if DHAK["IsValid"]( v ) then
		 if DHAK["GetBool"]( "Chams" ) then
			cam["Start3D"]()

				cam["IgnoreZ"](true)
				render["MaterialOverride"](Material("models/debug/debugwhite"))
				render["SuppressEngineLighting"]( true )

				local col = team["GetColor"]( v:Team() )

				render["SetColorModulation"]( col["r"]/255, col["g"]/255, col["b"]/255 )
					v:DrawModel()
				render["SetColorModulation"]( 1, 1, 1 )
				
				render["SuppressEngineLighting"]( false )
				render["MaterialOverride"]( 0 )
				cam["IgnoreZ"](false)

			cam["End3D"]()
		end	
			local posy = v:LocalToWorld( v:OBBCenter() ):ToScreen()

			local name = v:Nick() or "N/A"
			local health = v:Health() or 0
			local weapon = v:GetActiveWeapon()
			local rank = v:GetUserGroup() or "N/A"

			if weapon and weapon["GetPrintName"] then
				weapon = weapon:GetPrintName() or "N/A"
			else
				weapon = "N/A"
			end

			surface["SetFont"]("DHAKzESP")

			local x,y = surface["GetTextSize"]("X")

			posy["y"] = posy["y"] - y*2

			DHAK["drawtext"]("N: " .. name, posy["x"],posy["y"])
			DHAK["drawtext"]("H: " .. health, posy["x"],posy["y"] + y)
			DHAK["drawtext"]("W: " .. weapon, posy["x"],posy["y"] + (y*2))
			DHAK["drawtext"]("R: " .. rank, posy["x"],posy["y"] + (y*3))

			if health > 100 then
				health = 100
			end

			if health < 0 then
				health = 0
			end

			local healthbar = y*4
			local width = 5

			draw["RoundedBox"](0, posy["x"] - width - 5 - 2, posy["y"] - 2, width + 4, healthbar + 4, Color(0, 0, 0, 255) )
			draw["RoundedBox"](0, posy["x"] - width - 5, posy["y"], width, healthbar * 0.01 * health, Color(0, 200, 0, 200) )		
			end
        end
if DHAK["GetBool"]("Crosshair") then 
		local x = ScrW() / 2
		local y = ScrH() / 2
		local i = 0
		
		surface["SetDrawColor"]( DHAK["Colors"]["Red"] )
		for i = 0, 1 do
			surface["DrawLine"]( x + 9 + i, y, x, y )
			surface["DrawLine"]( x - 9 - i, y, x, y )
			surface["DrawLine"]( x, y + 9 + i, x, y )
			surface["DrawLine"]( x, y - 9 - i, x, y )
			end
		end
    end	
end

//shitty but it works .. thanks kittix
local laser = Material( "sprites/bluelaser1" )
function DHAK.Funcs.RenderScreenspaceEffects()
if DHAK["GetBool"]("Laser") then

local startpos = me:GetPos()
local EndPos = me:GetEyeTrace()["HitPos"];
local model = me:GetViewModel()

if not IsValid(model) then
return
end

local attach = model:GetAttachment("1")
if ( Attach == 0 ) then Attach = ViewModel:LookupAttachment("muzzle") end
if not attach then return end


startpos = attach["Pos"]

cam["Start3D"]()
render["SetMaterial"]( laser )
render["DrawBeam"]( startpos, EndPos, 5, 0, 0, Color( 25, 25, 255, 255 ) ) 
render["SetMaterial"](Material("Sprites/light_glow02_add_noz"))
render["DrawQuadEasy"](me:GetEyeTrace()["HitPos"], (EyePos() -  me:GetEyeTrace()["HitPos"]):GetNormal(), 30, 30, Color(255,255,255,255))
cam["End3D"]()
    end
end

function DHAK.InFov( e )
	if( DHAK["GetVar"]( "aim_fov" ) != 360 ) then
		local lpang = me:GetAngles()
		local ang = ( e:GetPos() - me:EyePos() ):Angle()
		ady = math["abs"]( math["NormalizeAngle"]( lpang["y"] - ang["y"] ) )
		adp = math["abs"]( math["NormalizeAngle"]( lpang["p"] - ang["p"] ) )
		if( ady > DHAK["GetVar"]( "aim_fov" ) || adp > DHAK["GetVar"]( "aim_fov" ) ) then 
		return false 
	    end
	end
	return true
end

file["Exists"] = DHAK["Detour"]( file["Exists"], function( filename, dir )
	if string["find"]( filename, "DHAKz" ) then 
		return false
	else
		return DHAK["Detours"][ file["Exists"] ]( filename, dir )
	end
end )

function DHAK.CreateOption( dtype, parent, o1, o2, o3, o4, o5, o6, o7 )
	 local addx, addy = 3, 3.5
	if ( dtype == "Checkbox" ) then
		dtype = "DCheckBoxLabel"
		local text, bool, x, y = o1, o2, o3, o4
		local checkbox = vgui["Create"]( dtype, parent )
		checkbox:SetText( text )
		checkbox:SetPos( x + addx, y + addy )
		checkbox:SizeToContents()
		checkbox:SetTextColor( DHAK["Colors"]["Green"] )
		checkbox:SetChecked( DHAK["Bools"][bool] ) 
		checkbox["OnChange"] = function( check ) 
			DHAK["Bools"][bool] = checkbox:GetChecked() 
		end 	
	elseif ( dtype == "Slider" ) then
		dtype = "DNumSlider"
		local text, var, min, max, wide, x, y = o1, o2, o3, o4, o5, o6, o7
		local slider = vgui["Create"]( dtype, parent )
		slider:SetPos( x + addx, y + addy )
		slider:SetWide( wide )
		slider:SetText( text )
		slider:SetMin( min )
		slider:SetMax( max )
		slider:SetDecimals( 0 )
		slider:SetValue( DHAK["Vars"][var] ) 
		slider["OnValueChanged"] = function( p, v ) 
			DHAK["Vars"][var] = v 
		end
	elseif ( dtype == "Button" ) then
		dtype = "DButton"
		local text, command, x, y = o1, o2, o3, o4
		local button = vgui["Create"]( dtype, parent )
		button:SetParent( parent )
		button:SetSize( 125, 25 )
		button:SetPos( x + addx, y + addy )
		button:SetText( text )
		button["DoClick"] = function() DHAK:Command( command ) end
	elseif ( dtype == "Label" ) then
		dtype = "DLabel"
		local text, x, y = o1, o2, o3
		local label = vgui["Create"]( dtype, parent )
		label:SetPos( x, y )
		label:SetText( text )
		label:SizeToContents()
		label:SetTextColor( DHAK["Colors"]["Green"] )
	end
end

function DHAK.Menu( tabs, menuheight, menuwidth, w, h, c1, c2 )
	local tabs, menuheight, menuwidth, w, h = {}, 300, 400, ScrW() / 2, ScrH() / 2
	local c1, c2 = DHAK["Colors"]["TransBlack"], DHAK["Colors"]["TransBlack"]
		
    DHAK["Frame"] = vgui["Create"]( "DPropertySheet" )
	DHAK["Frame"]:SetParent( DHAK["Frame"] )
	DHAK["Frame"]:SetPos( w - ( menuwidth / 2 ), h - ( menuheight / 2 ) )
	DHAK["Frame"]:SetSize( menuwidth, menuheight )
	DHAK["Frame"]:SetVisible( true )
	DHAK["Frame"]:MakePopup()
	DHAK["Frame"]["Think"] = function()
if !DHAK["MenuOpen"]( "+menu" ) && !DHAK["Typing"] then
		DHAK["MO"] = false
		DHAK["Frame"]:SetVisible( false )
	end
end	

	DHAK["Frame"]["Paint"] = function() draw["RoundedBox"]( 1, 0, 0, DHAK["Frame"]:GetWide(), DHAK["Frame"]:GetTall(), c1 ) end 
	DHAK["CreateOption"]( "Label", DHAK["Frame"], "", 310, 6.5 )
	
    local aimbot = vgui["Create"]( "DLabel", DHAK["Frame"] )
	aimbot:SetPos( 0, 0 )
	aimbot:SetText( "" )
	aimbot["Paint"] = function() draw["RoundedBox"]( 1, 0, 0, DHAK["Frame"]:GetWide(), DHAK["Frame"]:GetTall(), c2 ) end
	DHAK["Frame"]:AddSheet( "Aimbot", aimbot, false, false )
	
    local esp = vgui["Create"]( "DLabel", DHAK["Frame"] )
	esp:SetPos( 0, 0 )
	esp:SetText( "" )
	esp["Paint"] = function() draw["RoundedBox"]( 1, 0, 0, DHAK["Frame"]:GetWide(), DHAK["Frame"]:GetTall(), c2 ) end
	DHAK["Frame"]:AddSheet( "ESP", esp, false, false )
	
	local friends = vgui["Create"]( "DLabel", DHAK["Frame"] )
	friends:SetPos( 0, 0 )
	friends:SetText( "" )
	friends["Paint"] = function() draw["RoundedBox"]( 1, 0, 0, DHAK["Frame"]:GetWide(), DHAK["Frame"]:GetTall(), c2 ) end
	DHAK["Frame"]:AddSheet( "Friends", friends, false, false )
	
    local misc = vgui["Create"]( "DLabel", DHAK["Frame"] )
	misc:SetPos( 0, 0 )
	misc:SetText( "" )
	misc["Paint"] = function() draw["RoundedBox"]( 1, 0, 0, DHAK["Frame"]:GetWide(), DHAK["Frame"]:GetTall(), c2 ) end
	DHAK["Frame"]:AddSheet( "Misc", misc, false, false )
	
	local Exploits = vgui["Create"]( "DLabel", DHAK["Frame"] )
	Exploits:SetPos( 0, 0 )
	Exploits:SetText( "" )
	Exploits["Paint"] = function() draw["RoundedBox"]( 1, 0, 0, DHAK["Frame"]:GetWide(), DHAK["Frame"]:GetTall(), c2 ) end
	DHAK["Frame"]:AddSheet( "Exploits", Exploits, false, false )                                                             
	
	local AllPlayers = vgui["Create"]( "DListView", friends )
	AllPlayers:SetPos( 10, 10 )
	AllPlayers:SetSize( 150, 215 )
	AllPlayers:AddColumn( "Players" )
local allplys = DHAK["GetPlayer"]()
for k = 1, #allplys do 
local v = allplys[k]	
	if ( v != me && !table["HasValue"]( DHAK["Friends"], v:Nick() ) ) then
		AllPlayers:AddLine( v:Nick() )
	end
end
	
    local Friends = vgui["Create"]( "DListView", friends )
	Friends:SetPos( 205, 10 )
	Friends:SetSize( 150, 215 )
	Friends:AddColumn( "Friends" )
		local Retard = DHAK["Friends"]
	for k = 1, #Retard do
		local v = Retard[k]
	Friends:AddLine( v )
end
    local FriendsAdd = vgui["Create"]( "DButton", friends ) 
	FriendsAdd:SetText( "==>" ) 
	FriendsAdd:SetSize( 30, 20 )
	FriendsAdd:SetPos( 165, 55 )
	FriendsAdd["DoClick"] = function() 
local line = AllPlayers:GetSelectedLine() 
	if line != nil then 
		local playername = AllPlayers:GetLine( line ):GetValue( 1 ) 
	   if !table["HasValue"]( DHAK["Friends"], playername ) then  
		for i = 1,1 do	
			DHAK["Friends"][#DHAK["Friends"]+1] = playername;
			end
			DHAK["Message"]( DHAK["Colors"]["Green"], " Added Friend " .. playername )
			Friends:AddLine( playername ) 
			AllPlayers:RemoveLine( line ) 
		end 
	end
end
	
    local FriendsRemove = vgui["Create"]( "DButton", friends ) 
	FriendsRemove:SetText("<==") 
	FriendsRemove:SetSize( 30, 20 ) 
	FriendsRemove:SetPos( 165, 110 )
	FriendsRemove["DoClick"] = function() 
local line = Friends:GetSelectedLine() 
	if line != nil then 
		local playername = Friends:GetLine( line ):GetValue(1) 
		if table["HasValue"]( DHAK["Friends"], playername ) then		
		local FUCK = DHAK["Friends"]
	for k = 1, #FUCK do
		local v = FUCK[k]
				if v == playername then 
				for i = 1,1 do
					DHAK["Friends"][#DHAK["Friends"]] = nil;
					end
					DHAK["Message"]( DHAK["Colors"]["Green"], "Removed Friend " .. playername )
				end 
			end 
			AllPlayers:AddLine( playername ) 
			Friends:RemoveLine( line ) 
		end
	end 
end	

	DHAK["CreateOption"]( "Checkbox", aimbot, "Autoshoot", "AutoShoot", 5, 25 )
	DHAK["CreateOption"]( "Checkbox", aimbot, "Ignore Team", "Ignore Team", 5, 45 )
	DHAK["CreateOption"]( "Checkbox", aimbot, "Ignore Admins", "ignoreadmins", 5, 65 )
	DHAK["CreateOption"]( "Checkbox", aimbot, "Ignore Steam Friends", "IgnoreSteamFriends", 5, 85 )
	DHAK["CreateOption"]( "Checkbox", aimbot, "Attatchment aim", "AttatchmentAIM", 5, 165 )
	DHAK["CreateOption"]( "Checkbox", aimbot, "Target only friends", "TargetFriends", 5, 185 )
	DHAK["CreateOption"]( "Checkbox", aimbot, "Aim at head bone", "BoneAim", 5, 205 )
		
	DHAK["CreateOption"]( "Checkbox", aimbot, "Aimbot Benchmark", "AimbotBench", 150, 5 )
	
	DHAK["CreateOption"]( "Slider", aimbot, "FOV", "aim_fov", 0, 360, 200, 150, 135 )

	DHAK["CreateOption"]( "Label", esp, "Player ESP", 30, 10 )
	DHAK["CreateOption"]( "Checkbox", esp, "Player ESP", "ESP", 5, 25 )
	DHAK["CreateOption"]( "Checkbox", esp, "Laser Sight", "Laser", 5, 65 )
	DHAK["CreateOption"]( "Checkbox", esp, "Chams", "Chams", 5, 85 )
	
	DHAK["CreateOption"]( "Label", esp, "Other", 300, 10 )
	DHAK["CreateOption"]( "Checkbox", esp, "Crosshair", "Crosshair", 270, 25 )
	DHAK["CreateOption"]( "Checkbox", misc, "Bunnyhop", "BHOP", 5, 5 )
	
	
end		

function DHAK.Funcs.Think()
if ( DHAK["MenuOpen"]( "+menu" ) && !DHAK["MO"] && !gui["IsConsoleVisible"]() && !DHAK["Typing"] ) then
		DHAK["MO"] = true
	DHAK["Menu"]()
     end
end

DHAK["StartChat"] = GAMEMODE["StartChat"] 
function GAMEMODE:StartChat() 
	DHAK["StartChat"]() 
	DHAK["Typing"] = true 
end 

DHAK["FinishChat"] = GAMEMODE["FinishChat"] 
function GAMEMODE:FinishChat() 
	DHAK["FinishChat"]() 
	DHAK["Typing"] = false 
end 

function DHAK.HUDPaint()		
return DHAK["Funcs"]["HUDPaint"]()
end

function DHAK.CreateMove ( ucmd )
if( ucmd == nil ) then
    return;
end		
return DHAK["Funcs"]["CreateMove"] ( ucmd ) 
end

function DHAK.RenderScreenspaceEffects ()
return DHAK["Funcs"]["RenderScreenspaceEffects"] ()
end	

function DHAK.Think()		
return DHAK["Funcs"]["Think"] ()
end

DHAK["RegisterHook"]( "RenderScreenspaceEffects", DHAK["RenderScreenspaceEffects"] )
DHAK["RegisterHook"]( "CreateMove", DHAK["CreateMove"] )
DHAK["RegisterHook"]( "HUDPaint", DHAK["HUDPaint"] )
DHAK["RegisterHook"]( "Think", DHAK["Think"] )