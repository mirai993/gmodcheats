--[[
	autorun/client/zbot.lua
	Gilgax
	===DStream===
]]

/*
	<--Created by ZpankR-->
	
	Version 2.13
	
	Changelog:
	
	Version 1.0 - Initial Version.
	Version 1.2 - Added information to player boxes.
	Version 1.3 - Bug Fixes.
				- Added DarkRP support.
	Version 1.4 - More DarkRP information.
	Version 1.5 - More DarkRP information.
	Version 1.6 - Added Overv's Keypad Cracker code.
	Version 1.7 - Added IgnoreZ for players.
	Version 1.8 - Added IgnoreZ for props.
	Version 2.0 - Not an ESP anymore, more like a bot.
				- Added Aimbot with awesome targetting system.
	Version 2.1 - Added BHop/Attack/Use/Flashlight functions.
	Version 2.2 - Bug Fix: Player Eye Angles now update..
	Version 2.3 - Bug Fix on aimbot. Would break loop when LocalPlayer shown.
	Version 2.4 - Implemented XoX's Head Position to aimbot.
				- Optimized a ton of code.
	Version 2.5 - Added Team Selection.
	Version 2.6 - TriggerBot.
	Version 2.7 - Client Noclip.
	Version 2.8 - Buddy System.
	Version 2.9 - Radar.
	Version 2.10 - Fixed Buddy System.
				- Changed some Icons.
				- Added Box Detection.
				- Fixed Show Props.
				- Added Weapon Detection.
	Version 2.11 - Added GUI to spawnmenu.
				- Fixed Some bugs.
				- Added more Radar Entities.
				- Fixes, Fixes and Fixes.
	Version 2.12 - Added Locator to Radar.
				- Added GUI related features.
				- Fixed GUI related bugs.
				- REALLY fixed buddy system.
				- Fixed (maybe) everything that was wrong.
	Version 2.13 - Fixed Some Triggerbot Issues.
				- Added Filters to Bot.
				
	Planned:
		- Comments
		- Optimize Code
		- Make Aimbot Smooth
*/

zesp_debug = 0

zbot_VERSION = "2.13"

local zesp_enabled = tonumber(CreateClientConVar("zesp_enable", "1", true, false)) or 1
local zesp_players = tonumber(CreateClientConVar("zesp_players", "1", true, false)) or 1
local zesp_players_size = tonumber(CreateClientConVar("zesp_players_size", "32", true, false)) or 32
local zesp_props = tonumber(CreateClientConVar("zesp_props", "0", true, false)) or 0
local zesp_props_obb = tonumber(CreateClientConVar("zesp_props_obb", "0", true, false)) or 0
local zesp_printers = tonumber(CreateClientConVar("zesp_rp_printers", "1", true, false)) or 1
local zesp_printers_vintage = tonumber(CreateClientConVar("zesp_rp_printers_vintage", "0", true, false)) or 0
local zesp_printers_size = tonumber(CreateClientConVar("zesp_rp_printers_size", "15", true, false)) or 15
local zesp_weapons = tonumber(CreateClientConVar("zesp_weapons", "1", true, false)) or 1
local zesp_rpmoney = tonumber(CreateClientConVar("zesp_rp_playermoney", "0", true, false)) or 0
local zesp_rpshowdrops = tonumber(CreateClientConVar("zesp_rp_drops", "0", true, false)) or 0
local zesp_rpshowboxes = tonumber(CreateClientConVar("zesp_rp_boxes", "1", true, false)) or 1
local zesp_rp_boxes_content = tonumber(CreateClientConVar("zesp_rp_boxes_content", "0", true, false)) or 0
local zesp_keypads = tonumber(CreateClientConVar("zesp_keypads", "1", true, false)) or 1
local zesp_ignorez = tonumber(CreateClientConVar("zesp_ignorez", "0", true, false)) or 0
local zesp_ignorez_props = tonumber(CreateClientConVar("zesp_ignorez_props", "0", true, false)) or 0
local zesp_showadmins = tonumber(CreateClientConVar("zesp_showadmins", "1", true, false)) or 1
local zesp_radar = tonumber(CreateClientConVar("zesp_radar", "1", true, false)) or 1
local zesp_players_radar = tonumber(CreateClientConVar("zesp_players_radar", "1", true, false)) or 1
local zesp_props_radar = tonumber(CreateClientConVar("zesp_props_radar", "0", true, false)) or 0
local zesp_printers_radar = tonumber(CreateClientConVar("zesp_rp_printers_radar", "0", true, false)) or 0
local zesp_boxes_radar = tonumber(CreateClientConVar("zesp_rp_boxes_radar", "0", true, false)) or 0

local zesp_locate = false
local zesp_locate_target
local zesp_noclip = false
local zesp_spazz = false

local fences = {
		"models/props_wasteland/interior_fence001g.mdl",
		"models/props_wasteland/interior_fence002d.mdl",
		"models/props_c17/gate_door02a.mdl",
		"models/props_c17/gate_door01a.mdl",
		"models/props_c17/fence01a.mdl",
		"models/props_c17/fence01b.mdl",
		"models/props_c17/fence02a.mdl",
		"models/props_c17/fence02b.mdl",
		"models/props_c17/fence03a.mdl",
		"models/props_c17/fence04a.mdl"
	}

//We put this here so it can reload even if it errors.
concommand.Add('zbot_reload',function(p,com,args)
	include('autorun/client/zbot.lua')
end)

concommand.Add("zesp_locate",
function(ply,com,args)
	if zesp_locate then zesp_locate = false zesp_locate_target = nil print("Stopped locating " .. tostring(zesp_locate_target)) return end
	local follow = tostring(args[1])
	for k, v in pairs(player.GetAll())do
		if string.find(string.lower(v:Name()),string.lower(follow)) and v!=LocalPlayer() then
			zesp_locate = true
			zesp_locate_target = v
			print("Locating " .. v:Name())
			return
		end
	end
	zesp_locate = false
	zesp_locate_target = nil
	print("Could not find player match.")
end)

/*-------------------------------------------------------------------------------------------------------------------------
	UUUUHHHHHH
-------------------------------------------------------------------------------------------------------------------------*/

hook.Remove( "RenderScreenspaceEffects", "LASERPOINTER.RenderScreenspaceEffects")
timer.Simple(2,function()hook.Remove( "RenderScreenspaceEffects", "LASERPOINTER.RenderScreenspaceEffects")end)
require('enginespew')
hook.Add( "EngineSpew", "FuckYouFPP", function( spewType, msg, group, level )
	if string.find(msg,"SetConVar")==1 then return false end
end)

/*-------------------------------------------------------------------------------------------------------------------------
	Random Functions
-------------------------------------------------------------------------------------------------------------------------*/

function InvertColor(Col)
	local r = 255-Col.r
	local g = 255-Col.g
	local b = 255-Col.b
	return Color(r,g,b,Col.a)
end

function zprint(...)
	if zesp_debug == 1 then
		print(...)
	end
end

/*-------------------------------------------------------------------------------------------------------------------------
	keypad cracker by Overv
-------------------------------------------------------------------------------------------------------------------------*/

local X = -50
local Y = -100
local W = 100
local H = 200

local keyPos =	{	{X+5, Y+100, 25, 25, -2.2, 3.45, 1.3, -0},
					{X+37.5, Y+100, 25, 25, -0.6, 1.85, 1.3, -0},
					{X+70, Y+100, 25, 25, 1.0, 0.25, 1.3, -0},

					{X+5, Y+132.5, 25, 25, -2.2, 3.45, 2.9, -1.6},
					{X+37.5, Y+132.5, 25, 25, -0.6, 1.85, 2.9, -1.6},
					{X+70, Y+132.5, 25, 25, 1.0, 0.25, 2.9, -1.6},

					{X+5, Y+165, 25, 25, -2.2, 3.45, 4.55, -3.3},
					{X+37.5, Y+165, 25, 25, -0.6, 1.85, 4.55, -3.3},
					{X+70, Y+165, 25, 25, 1.0, 0.25, 4.55, -3.3},

					{X+5, Y+67.5, 40, 25, -2.2, 4.25, -0.3, 1.6},
					{X+55, Y+67.5, 40, 25, 0.3, 1.65, -0.3, 1.6}
				}
				
hook.Add( "Think", "ZESPThink", function()
	local zesp_keypads = tonumber(LocalPlayer():GetInfo("zesp_keypads"))
	if(zesp_keypads==1)then
		for _, keypad in pairs( ents.FindByClass( "sent_keypad" ) ) do
			local curNum = keypad:GetNWInt( "keypad_num" )
			if keypad:GetNWBool( "keypad_secure" ) then
				// Secure
				if keypad.prevNum != curNum and curNum != 0 then
					if curNum == 1 or !keypad.candidateCode then keypad.candidateCode = "" end
					
					if curNum > 0 then
						// Retrieve player entering the digit
						local usingPlayer = NULL
						for _, pl in pairs( player.GetAll( ) ) do
							local ent = pl:GetEyeTrace( ).Entity
							if ValidEntity( ent ) and ent == keypad then
								usingPlayer = pl
								break
							end
						end
						
						if ValidEntity( usingPlayer ) then
							// Retrieve exact entered digit
							local pos = keypad:WorldToLocal( usingPlayer:GetEyeTrace( ).HitPos )
							local digit = 0
							for i, v in pairs( keyPos ) do
								local x = ( pos.y - v[5] ) / ( v[5] + v[6] )
								local y = 1 - ( pos.z + v[7] ) / ( v[7] + v[8] )
								
								if x >= 0 and y >= 0 and x <= 1 and y <= 1 then
									digit = i
									break
								end
							end
							
							keypad.candidateCode = keypad.candidateCode .. tostring( digit )
						end
					end
				end
				
				// Copy the collected digits to the definitive code variable since we now know it's correct!
				if keypad:GetNetworkedBool( "keypad_access" ) and keypad:GetNetworkedBool( "keypad_showaccess" ) and keypad.code != keypad.candidateCode then
					keypad.code = keypad.candidateCode
				end
			else
				// Non-secure
				
				// Read the correct code when the ACCESS GRANTED message is displayed
				if keypad:GetNetworkedBool( "keypad_access" ) and keypad:GetNetworkedBool( "keypad_showaccess" ) then
					keypad.code = curNum
				end
			end
			
			keypad.prevNum = curNum
		end
	end
	
	// end of overv's keypad thing
	
end )



local function DrawRadarPoly(x,y,radius,quality)
	quality = quality or 180
	local circle = {}
	local tmp = 0
	local s,c
	for i=1,quality do
		tmp = math.rad(i*360)/quality
		s = math.sin(tmp)
		c = math.cos(tmp)
		circle[i] = {x = x + c*radius,y = y + s*radius,u = (c+1)/2,v = (s+1)/2}
	end
	return circle
end

local AdminTex = surface.GetTextureID( "gui/silkicons/shield" )
local UserTex = surface.GetTextureID( "gui/silkicons/user" )
local BoxTex = surface.GetTextureID( "gui/silkicons/box" )
local PrintTex = surface.GetTextureID( "gui/silkicons/money_add" )

function DrawESP()
	zesp_enabled = tonumber(LocalPlayer():GetInfo("zesp_enable"))
	zesp_players = tonumber(LocalPlayer():GetInfo("zesp_players"))
	zesp_players_size = tonumber(LocalPlayer():GetInfo("zesp_players_size"))
	zesp_props = tonumber(LocalPlayer():GetInfo("zesp_props"))
	zesp_props_obb = tonumber(LocalPlayer():GetInfo("zesp_props_obb"))
	zesp_printers = tonumber(LocalPlayer():GetInfo("zesp_rp_printers"))
	zesp_printers_vintage = tonumber(LocalPlayer():GetInfo("zesp_rp_printers_vintage"))
	zesp_printers_size = tonumber(LocalPlayer():GetInfo("zesp_rp_printers_size"))
	zesp_weapons = tonumber(LocalPlayer():GetInfo("zesp_weapons"))
	zesp_rpmoney = tonumber(LocalPlayer():GetInfo("zesp_rp_playermoney"))
	zesp_rpshowdrops = tonumber(LocalPlayer():GetInfo("zesp_rp_drops"))
	zesp_rpshowboxes = tonumber(LocalPlayer():GetInfo("zesp_rp_boxes"))
	zesp_rp_boxes_content = tonumber(LocalPlayer():GetInfo("zesp_rp_boxes_content"))
	local zesp_keypads = tonumber(LocalPlayer():GetInfo("zesp_keypads"))
	zesp_showadmins = tonumber(LocalPlayer():GetInfo("zesp_showadmins"))
	zesp_radar = tonumber(LocalPlayer():GetInfo("zesp_radar"))
	zesp_players_radar = tonumber(LocalPlayer():GetInfo("zesp_players_radar"))
	zesp_props_radar = tonumber(LocalPlayer():GetInfo("zesp_props_radar"))
	zesp_printers_radar = tonumber(LocalPlayer():GetInfo("zesp_rp_printers_radar"))
	zesp_boxes_radar = tonumber(LocalPlayer():GetInfo("zesp_rp_boxes_radar"))
	
	if zesp_enabled == 1 then
		
		if zesp_radar == 1 then
			local RadarColor = Color(15,95,20,110)
			local radius = 120
			local radardistancex = 20
			local radardistancey = 20
			//Circle:
			local circle = DrawRadarPoly(ScrW() - radius - radardistancex, radius + radardistancey, radius)
			surface.SetDrawColor(RadarColor)
			surface.SetTexture()
			surface.DrawPoly( circle )
			surface.SetDrawColor(Color(10,50,10,190))
			
			surface.DrawLine(ScrW() - radius - radardistancex, radardistancey, ScrW() - radius - radardistancex, radius * 2 + radardistancey)
			surface.DrawLine(ScrW() - radardistancex, radius + radardistancey, ScrW() - (radius * 2 + radardistancex), radius + radardistancey)
		end
		
		if zesp_players == 1 then
			
			for k, ply in pairs(player.GetAll()) do
				if ply != LocalPlayer() then
					allplayersposition = ply:GetPos() + ply:OBBCenter()
					playerposition = allplayersposition:ToScreen()
					plyColor = team.GetColor(ply:Team())
					surface.SetDrawColor(plyColor)
					local boxHeightDividedBy2 = zesp_players_size / 2
					surface.DrawOutlinedRect( playerposition.x - boxHeightDividedBy2, playerposition.y - boxHeightDividedBy2, zesp_players_size, zesp_players_size)
					
					surface.SetTextColor( plyColor )
					surface.SetTextPos(playerposition.x-boxHeightDividedBy2,playerposition.y - boxHeightDividedBy2 - (boxHeightDividedBy2-1))
					surface.SetFont("Default")
					surface.DrawText(ply:GetName())
					local reverseCol = Color(255-plyColor.r,255-plyColor.g,255-plyColor.b,plyColor.a)
					surface.SetTextColor( reverseCol )
					surface.SetTextPos(playerposition.x + boxHeightDividedBy2 + 4,playerposition.y - boxHeightDividedBy2 -2)
					local distance = ply:GetPos():Distance(LocalPlayer():GetPos())
					surface.DrawText("Dist: "..math.floor(distance))
					surface.SetTextPos(playerposition.x + boxHeightDividedBy2 + 4,playerposition.y - boxHeightDividedBy2 + 10)
					if ply:Alive() then
						surface.DrawText("Health: "..ply:Health())
						if ply:Armor() > 0 then
							surface.SetTextPos(playerposition.x + boxHeightDividedBy2 + 4,playerposition.y - boxHeightDividedBy2 + 22)
							surface.DrawText("Armor: "..ply:Armor())
						end
					else
						surface.DrawText("Player Dead")
					end
					if zesp_rpmoney == 1 then
						if(ply.DarkRPVars)then
							local money = tostring(ply.DarkRPVars.money)
							surface.SetTextColor( reverseCol )
							surface.SetTextPos(playerposition.x-15,playerposition.y + 16)
							surface.SetFont("Default")
							surface.DrawText("Money: "..money)
						end
					end
					if zesp_showadmins == 1 then
						if ply:IsAdmin() then
							surface.SetDrawColor( 255, 255, 255, 255 )
							surface.SetTexture( AdminTex )
							surface.DrawTexturedRect( playerposition.x - 16, playerposition.y - 16, 10, 10 )
						end
					end
					if zesp_players_radar == 1 and zesp_radar == 1 then
						
						local lpos = LocalPlayer():GetPos()
						local tpos = ply:GetPos()
						local angle = -Angle(0,(tpos - lpos):Angle().y,0) + Angle(0,LocalPlayer():GetAimVector():Angle().y-90,0)
						
						local optdist = 7500
						local radius = 120
						local radardistancex = 20
						local radardistancey = 20
						
						local height = (tpos.z - lpos.z)
						
						local planedistance = math.sqrt(distance^2 - height^2)
						
						local dist = math.Clamp(planedistance,0,optdist)
						
						local distnormal = math.log(dist+1)/math.log(optdist)
						local normal = angle:Forward() * distnormal
						
						local x = (ScrW() - radius - radardistancex) + (normal.x * distnormal)*radius - 4
						local y = radius + radardistancey + (normal.y * distnormal)*radius - 4
						
						if zesp_locate and zesp_locate_target == ply then
							local plycirc = DrawRadarPoly(x+4, y+4, 16, 45)
							local locateCol = Color(255-plyColor.r,255-plyColor.g,255-plyColor.b,110)
							surface.SetDrawColor(locateCol)
							surface.SetTexture()
							surface.DrawPoly( plycirc )
							
							local centerx = ScrW() - 140
							local centery = 140
							
							local arrowx = (ScrW() - 140) + (normal.x / distnormal)*radius/3
							local arrowy = 140 + (normal.y / distnormal)*radius/3
							
							surface.SetDrawColor(Color(255,50,20,250))
							surface.DrawLine(centerx, centery, arrowx, arrowy)
						end
						surface.SetDrawColor( plyColor )
						if ply:IsAdmin() then
							surface.SetTexture( AdminTex )
						else
							surface.SetTexture( UserTex )
						end
						surface.DrawTexturedRect( x, y, 8, 8 )

						//if dist < 500 then zprint(dist,distnormal,normal,angle) end
					end
				end
			end //end of players loop
			
		end
		
		for k, v in pairs(ents.GetAll())do
			if v:IsValid() then
				if(zesp_props==1)then
					local class = v:GetClass()
					if ((string.find(class,"func_")==1) or (string.find(class,"prop_")==1)) then
						local cpos = v:GetPos() + v:OBBCenter()
						local scrpos = cpos:ToScreen()
						
						local pos = v:GetPos()
						
						if zesp_props_obb == 1 then
							if(scrpos.x>0 and scrpos.x<ScrW() and scrpos.y>0 and scrpos.y<ScrH())then
								local mins = v:OBBMins()
								local maxs = v:OBBMaxs()
								
								local zzz = ( pos + mins ):ToScreen() // 0,0,0
								local uuu = ( pos + maxs ):ToScreen() // 1,1,1
								local zzu = ( pos + Vector( mins.x, mins.y, maxs.z ) ):ToScreen() // 0,0,1
								local zuz = ( pos + Vector( mins.x, maxs.y, mins.z ) ):ToScreen() // 0,1,0
								local uzz = ( pos + Vector( maxs.x, mins.y, mins.z ) ):ToScreen() // 1,0,0
								local zuu = ( pos + Vector( mins.x, maxs.y, maxs.z ) ):ToScreen() // 0,1,1
								local uzu = ( pos + Vector( maxs.x, mins.y, maxs.z ) ):ToScreen() // 1,0,1
								local uuz = ( pos + Vector( maxs.x, maxs.y, mins.z ) ):ToScreen() // 1,1,0
								
								
								if(zesp_debug == 1) then
									surface.SetFont("Default")
									surface.SetTextColor( Color(30,190,20,200) )
									
									surface.SetTextPos(zzz.x,zzz.y)
									surface.DrawText("zzz "..zzz.x.." "..zzz.y) 
									
									surface.SetTextPos(uuu.x,uuu.y)
									surface.DrawText("uuu "..uuu.x.." "..uuu.y)
									
									surface.SetTextPos(zzu.x,zzu.y)
									surface.DrawText("zzu "..zzu.x.." "..zzu.y)
									
									surface.SetTextPos(zuz.x,zuz.y)
									surface.DrawText("zuz "..zuz.x.." "..zuz.y)
									
									surface.SetTextPos(uzz.x,uzz.y)
									surface.DrawText("uzz "..uzz.x.." "..uzz.y)
									
									surface.SetTextPos(zuu.x,zuu.y)
									surface.DrawText("zuu "..zuu.x.." "..zuu.y)
									
									surface.SetTextPos(uzu.x,uzu.y)
									surface.DrawText("uzu "..uzu.x.." "..uzu.y)
									
									surface.SetTextPos(uuz.x,uuz.y)
									surface.DrawText("uuz "..uuz.x.." "..uuz.y)
								end
								
								surface.SetDrawColor(Color(240,25,235,130))
							
							
								
								surface.DrawLine( zzz.x, zzz.y, uzz.x, uzz.y )
								surface.DrawLine( zzz.x, zzz.y, zuz.x, zuz.y )
								surface.DrawLine( zzz.x, zzz.y, zzu.x, zzu.y )
								
								surface.DrawLine( uuz.x, uuz.y, uzz.x, uzz.y )
								surface.DrawLine( uuz.x, uuz.y, zuz.x, zuz.y )
								surface.DrawLine( uuz.x, uuz.y, uuu.x, uuu.y )
								
								surface.DrawLine( zuu.x, zuu.y, zzu.x, zzu.y )
								surface.DrawLine( zuu.x, zuu.y, zuz.x, zuz.y )
								surface.DrawLine( zuu.x, zuu.y, uuu.x, uuu.y )
								
								surface.DrawLine( uzu.x, uzu.y, uzz.x, uzz.y )
								surface.DrawLine( uzu.x, uzu.y, zzu.x, zzu.y )
								surface.DrawLine( uzu.x, uzu.y, uuu.x, uuu.y )
							end
						else
							if(scrpos.x>0 and scrpos.x<ScrW() and scrpos.y>0 and scrpos.y<ScrH())then
								surface.SetDrawColor(Color(210,80,160,180))
								surface.DrawLine( scrpos.x - 10, scrpos.y, scrpos.x + 10,  scrpos.y )
								surface.DrawLine( scrpos.x, scrpos.y - 10, scrpos.x, scrpos.y + 10 )
							end
						end
						
						if zesp_props_radar == 1 and zesp_radar == 1 then
							surface.SetDrawColor( 190,60,210,200 )
							local lpos = LocalPlayer():GetPos()
							local tpos = v:GetPos()
							local angle = -Angle(0,(tpos - lpos):Angle().y,0) + Angle(0,LocalPlayer():GetAimVector():Angle().y-90,0)
							
							local optdist = 7500
							local radius = 120
							local radardistancex = 20
							local radardistancey = 20
							local dist = math.Clamp(distance,0,optdist)
							
							local distnormal = math.log(dist+1)/math.log(optdist)
							local normal = angle:Forward() * distnormal
							
							local x = (ScrW() - radius - radardistancex) + (normal.x * distnormal)*radius - 3
							local y = radius + radardistancey + (normal.y * distnormal)*radius - 3
							
							surface.DrawLine( x - 6, y, x + 6, y )
							surface.DrawLine( x, y - 6, x, y + 6 )
							
							//if dist < 500 then zprint(dist,distnormal,normal,angle) end
						end
					end
				end
				
				if(zesp_printers==1)then
					local class = v:GetClass()
					if ((string.find(class,"printer"))) then
						local pos = v:GetPos() + v:OBBCenter()
						local scrpos = pos:ToScreen()
						if(scrpos.x>0 and scrpos.x<ScrW() and scrpos.y>0 and scrpos.y<ScrH())then
							if zesp_printers_vintage == 1 then
								surface.SetDrawColor(Color(180,240,30,200))
								surface.DrawLine( scrpos.x - zesp_printers_size, scrpos.y, scrpos.x + zesp_printers_size,  scrpos.y )
								surface.DrawLine( scrpos.x, scrpos.y - zesp_printers_size, scrpos.x, scrpos.y + zesp_printers_size )
							else
								surface.SetDrawColor(Color(240,240,230,210))
								surface.SetTexture( PrintTex )
								local size2 = zesp_printers_size * 2
								surface.DrawTexturedRect(scrpos.x-zesp_printers_size,scrpos.y-zesp_printers_size,size2,size2)
							end
						end
						
						if zesp_printers_radar == 1 and zesp_radar == 1 then
							surface.SetDrawColor( 190,230,50,210 )
							local lpos = LocalPlayer():GetPos()
							local tpos = pos
							local angle = -Angle(0,(tpos - lpos):Angle().y,0) + Angle(0,LocalPlayer():GetAimVector():Angle().y-90,0)
							
							local optdist = 7500
							local radius = 120
							local radardistancex = 20
							local radardistancey = 20
							local dist = math.Clamp(pos:Distance(lpos),0,optdist)
							
							local distnormal = math.log(dist+1)/math.log(optdist)
							local normal = angle:Forward() * distnormal

							local x = (ScrW() - radius - radardistancex) + (normal.x * distnormal)*radius - 3
							local y = radius + radardistancey + (normal.y * distnormal)*radius - 3

							surface.DrawLine( x - 6, y, x + 6, y )
							surface.DrawLine( x, y - 6, x, y + 6 )
							//if dist < 500 then zprint(dist,distnormal,normal,angle) end
						end
					end
				end
				
				if(zesp_weapons==1)then
					local class = v:GetClass()
					if ((string.find(class,"weapon")) and v:GetMoveType()==6) then
						local pos = v:GetPos() + v:OBBCenter()
						local scrpos = pos:ToScreen()
						if(scrpos.x>0 and scrpos.x<ScrW() and scrpos.y>0 and scrpos.y<ScrH())then
							surface.SetFont("Default")
							local class = v:GetClass()
							local sizex,sizey = surface.GetTextSize(class)
							draw.RoundedBoxEx( 2, scrpos.x-10, scrpos.y-10, 8+sizex, 20, Color(30,0,30,230), false, true, true, false )
							surface.SetTextColor( Color(230,190,20,200) )
							surface.SetTextPos(scrpos.x-6,scrpos.y-8)
							surface.DrawText(class)
						end
					end
				end
				
				if(zesp_rpshowdrops==1)then
					local class = v:GetClass()
					if ((string.find(class,"spawned_money"))) then
						local pos = v:GetPos() + v:OBBCenter()
						local scrpos = pos:ToScreen()
						local money = "$"..tostring(v.dt.amount)
						if(scrpos.x>0 and scrpos.x<ScrW() and scrpos.y>0 and scrpos.y<ScrH())then
							surface.SetFont("Default")
							local sizex,sizey = surface.GetTextSize(money)
							draw.RoundedBoxEx( 2, scrpos.x-10, scrpos.y-10, 8+sizex, 20, Color(30,0,30,230), false, true, true, false )
							surface.SetTextColor( Color(30,190,20,200) )
							surface.SetTextPos(scrpos.x-6,scrpos.y-8)
							surface.DrawText(money)
						end
					end
				end
				
				if(zesp_rpshowboxes==1)then
					local class = v:GetClass()
					if ((string.find(class,"spawned_shipment"))) then
						local pos = v:GetPos() + v:OBBCenter()
						local scrpos = pos:ToScreen()
						if(scrpos.x>0 and scrpos.x<ScrW() and scrpos.y>0 and scrpos.y<ScrH())then
							local content = v.dt.contents or ""
							local contents = CustomShipments[content]
							if not contents then return end
							contents = contents.name
							local ammount = v.dt.count
							surface.SetFont("Default")
							
							local toshow = tostring(ammount) .. "x ".. tostring(contents)
							local sizex,sizey = surface.GetTextSize(toshow)
							
							surface.SetDrawColor(Color(240,240,230,210))
							surface.SetTexture( BoxTex )
							surface.DrawTexturedRect(scrpos.x-8,scrpos.y-8,16,16)
							
							if zesp_rp_boxes_content == 1 then
								draw.RoundedBoxEx( 2, scrpos.x+9, scrpos.y-8, 4+sizex, 16, Color(30,0,30,230), false, true, true, false )
								
								surface.SetTextColor( Color(30,190,20,200) )
								surface.SetTextPos(scrpos.x+12,scrpos.y-8)
								surface.DrawText(toshow)
							end
						end
						
						if zesp_boxes_radar == 1 and zesp_radar == 1 then
							surface.SetDrawColor( 25,70,230,220 )
							local lpos = LocalPlayer():GetPos()
							local tpos = pos
							local angle = -Angle(0,(tpos - lpos):Angle().y,0) + Angle(0,LocalPlayer():GetAimVector():Angle().y-90,0)
							
							local optdist = 7500
							local radius = 120
							local radardistancex = 20
							local radardistancey = 20
							local dist = math.Clamp(pos:Distance(lpos),0,optdist)
							
							local distnormal = math.log(dist+1)/math.log(optdist)
							local normal = angle:Forward() * distnormal
							
							local x = (ScrW() - radius - radardistancex) + (normal.x * distnormal)*radius - 3
							local y = radius + radardistancey + (normal.y * distnormal)*radius - 3
							
							surface.DrawLine( x - 6, y, x + 6, y )
							surface.DrawLine( x, y - 6, x, y + 6 )
							
							//if dist < 500 then zprint(dist,distnormal,normal,angle) end
						end
					end
				end
			end
		end

		
		if(zesp_locate==1)then
			if(!ValidEntity(zesp_locate_target))then zesp_locate_target = nil zesp_locate = false return end
			local pos = zesp_locate_target:GetPos()
			local scrpos = pos:ToScreen()
			plyColor = team.GetColor(zesp_locate_target:Team())
			surface.SetDrawColor(plyColor)
			if(scrpos.x>0 and scrpos.x<ScrW() and scrpos.y>0 and scrpos.y<ScrH())then
				surface.DrawCircle( scrpos.x, scrpos.y, 45, plyColor ) 
			else
				scrpos.x = math.Clamp(scrpos.x,30,ScrW()-30)
				scrpos.y = math.Clamp(scrpos.y,30,ScrH()-30)
			end
		end
		
		if(zesp_keypads==1)then
			local keypad = LocalPlayer( ):GetEyeTrace( ).Entity
			if ValidEntity( keypad ) and keypad:GetClass( ) == "sent_keypad" then
				local keypadTxt = ""
				local keypadColor = Color( 192, 255, 0, 255 )
				
				if !keypad.code then
					keypadTxt = "Code not retrieved yet!"
					keypadColor = Color( 255, 128, 0, 255 )
				else
					keypadTxt = "Keypad Code: " .. keypad.code
				end
				
				surface.SetFont( "Default" )
				local w, h = surface.GetTextSize( keypadTxt )
				draw.WordBox( 8, ScrW( ) / 2 - w / 2 - 8, ScrH( ) / 2 - h / 2 - 8, keypadTxt, "Default", Color( 0, 0, 0, 128 ), keypadColor )
			end
		end
		
	end
end

hook.Add("HUDPaint","ZESPDraw",DrawESP)

local function IgnoreZInit()
	local drawOutline

	hook.Add( "PostDrawOpaqueRenderables", "ZSPRenderables", function()
		zesp_ignorez = tonumber(LocalPlayer():GetInfo("zesp_ignorez"))
		zesp_ignorez_props = tonumber(LocalPlayer():GetInfo("zesp_ignorez_props"))
		if zesp_ignorez==1 and zesp_enabled == 1 then
			for k, v in pairs(player.GetAll()) do
				if ( v:IsValid() ) then
					if( v:Alive() and v:Team() != TEAM_SPECTATOR and v:Team() != TEAM_UNASSIGNED and v:Team() != TEAM_CONNECTING) then
						cam.IgnoreZ( true )
							v:DrawShadow( false )
							v:DrawModel()
						cam.IgnoreZ( false )
					end
				end
			end
		end
		
		if zesp_ignorez_props==1 and zesp_enabled == 1 then
			for k, v in pairs(ents.GetAll()) do
				if ( ValidEntity(v) ) then
					if( !v:IsPlayer()) then
						cam.IgnoreZ( true )
							v:DrawShadow( false )
							v:DrawModel()
						cam.IgnoreZ( false )
					end
				end
			end
		end
	end )
end

IgnoreZInit()

concommand.Add("zesp_fixignorez",
function(ply,com,args)
	hook.Remove( "PostDrawOpaqueRenderables", "ZSPRenderables")
	IgnoreZInit()
end)


//ZAIM

concommand.Add("+zaim",
function(ply,com,args)
	zesp_aim = 1
	if zesp_noclip then zesp_noclip = false end
	if zesp_spazz then zesp_spazz = false end
end)

concommand.Add("-zaim",
function(ply,com,args)
	zesp_aim = 0
end)

local noclipstart = true

concommand.Add("zesp_noclip",
function(ply,com,args)
	if not zesp_noclip then
		angles = nil
	end
	zesp_noclip = not zesp_noclip
	if zesp_spazz then zesp_spazz = false end
end)

concommand.Add("zesp_spazz",
function(ply,com,args)
	if zesp_spazz then
		LocalPlayer():SetEyeAngles(Angle(0,0,0))
	end
	zesp_spazz = not zesp_spazz
	if zesp_noclip then zesp_noclip = false end
end)

local zesp_buddies = {"4122797814"}
if file.Exists("zbot/buddylist.txt") then
	zesp_buddies = string.Explode(' ',file.Read("zbot/buddylist.txt"))
else
	file.Write("zbot/buddylist.txt",string.Implode(' ',zesp_buddies))
end

local function SaveBuddies()
	file.Write("zbot/buddylist.txt",string.Implode(' ',zesp_buddies))
end

local BUDDYPANEL

local function IsBuddy(ply)
	if not ply then return false end
	if ply:IsPlayer() then
		local id = ply:UniqueID()
		for k, v in pairs(zesp_buddies)do
			if v==id then
				return true
			end
		end
		return false
	else
		return false
	end
end

for k, v in pairs(player.GetAll())do
	if IsBuddy(v) then
		v.IsFriend = true
	end
end

timer.Create("SyncBuddies",1,0,function()
	for k, v in pairs(player.GetAll())do
		if IsBuddy(v) then
			v.IsFriend = true
		else
			v.IsFriend = false
		end
	end
end)

hook.Add("PlayerSpawn","ZAIMPlayerSpawn",function(p)
	if IsBuddy(p) then
		p.IsFriend = true
	end
end)

local function AddBuddy(str)
	local str = string.lower(str)
	for k, v in pairs(player.GetAll())do
		local name = string.lower(v:Name())
		if string.find(name,str) then
			if table.HasValue(zesp_buddies,v:UniqueID()) then
				print(v:Name() .. " is already your buddy.")
			else
				table.insert(zesp_buddies,v:UniqueID())
				v.IsFriend = true
				print("Adding "..v:Name()..". ID '"..v:UniqueID().."'.")
				SaveBuddies()
				return
			end
		end
	end
	print("Could not find player '"..str.."'.")
end

local function DelBuddy(str)
	local str = string.lower(str)
	for k, v in pairs(player.GetAll())do
		local name = string.lower(v:Name())
		if string.find(name,str) then
			for o, l in pairs(zesp_buddies)do
				if v:UniqueID() == l then
					v.IsFriend = false
					print("Removing "..v:Name()..". ID '"..v:UniqueID().."'.")
					zesp_buddies[o] = nil
					SaveBuddies()
					return
				end
			end
			print(v:Name() .. " was not on your buddy list.")
		end
	end
	print("Could not find player '"..str.."'.")
end

local function UpdateBuddyPanel( Panel )
	if Panel then
		Panel:ClearControls()
		Panel:AddHeader()
		Panel:Button("Add Steam Buddies on Server", "zesp_addsteambuddies")
		Panel:Help("")
		Panel:Help("Players on this server:")
		for k, v in pairs(player.GetAll())do
			if v:UniqueID() != "4122797814" then
				if IsBuddy(v) then
					Panel:Button("Remove " .. tostring(v:Name()) .. " from your buddies.","zesp_delbuddy",tostring(v:Name()))
				else
					Panel:Button("Add " .. tostring(v:Name()) .. " to your buddies.","zesp_addbuddy",tostring(v:Name()))
				end
			end
		end
		Panel:Help("")
		local ctrl = vgui.Create( "DListView" )
		ctrl:SetMultiSelect( false )
		Panel:AddPanel( ctrl )
		ctrl:AddColumn( "Buddies" )
		for k, v in pairs(zesp_buddies)do
			ctrl:AddLine( v )
		end
		local ammount = #zesp_buddies
		if ammount == 0 then
			ammount = 0.5
		end
		ctrl:SetTall( ammount*21 )
		ctrl:SortByColumn( 1, false )
		
		Panel:Button("Print List to Console", "zesp_printbuddies")
		
		BUDDYPANEL = Panel
	end
end


concommand.Add("zesp_addbuddy",
function(ply,com,args)
	AddBuddy(tostring(args[1]))
	UpdateBuddyPanel( BUDDYPANEL )
end)

concommand.Add("zesp_delbuddy",
function(ply,com,args)
	DelBuddy(tostring(args[1]))
	UpdateBuddyPanel( BUDDYPANEL )
end)

concommand.Add("zesp_addsteambuddies",
function(ply,com,args)
	for k, v in pairs(player.GetAll())do
		if v:GetFriendStatus() == "friend" then
			AddBuddy(v:Name())
		end
	end
	UpdateBuddyPanel( BUDDYPANEL )
end)

concommand.Add("zesp_printbuddies",
function(ply,com,args)
	PrintTable(zesp_buddies)
end)

hook.Add("PlayerSpawn","ZESPPlayerSpawn",function(ply)
	
	if ply == LocalPlayer() then return end
	ply.IsFriend = false
	for k, v in pairs(zesp_buddies) do
		if ply:UniqueID() == v then
			ply.IsFriend = true
			break
		end
	end
end)

local botThroughEnts = {LocalPlayer()}

hook.Add("OnEntityCreated","ZESPEntCreate",function(ent)
	if ValidEntity(ent) then
		local class = ent:GetClass()
		if (string.find(class,"func_break")==1)then
			table.insert(botThroughEnts, ent)
		end
		if class == "prop_physics" then
			local model = ent:GetModel()
			local shouldInsert = false
			for k, v in pairs(fences)do
				if model == v then
					shouldInsert = true
				end
			end
			if shouldInsert then
				table.insert(botThroughEnts, ent)
			end
		end
	end
end)

for k, ent in pairs(ents.GetAll())do
	if ValidEntity(ent) then
		local class = ent:GetClass()
		if (string.find(class,"func_break")==1)then
			table.insert(botThroughEnts, ent)
		end
		if class == "prop_physics" then
			local model = ent:GetModel()
			local shouldInsert = false
			for k, v in pairs(fences)do
				if model == v then
					shouldInsert = true
				end
			end
			if shouldInsert then
				table.insert(botThroughEnts, ent)
			end
		end
	end
end

local zaim_dotrace = tonumber(CreateClientConVar("zaim_dotrace", "1", true, false)) or 1
local zaim_bone = tonumber(CreateClientConVar("zaim_bone", "0", true, false)) or 0
//local zaim_notk = tonumber(CreateClientConVar("zesp_notk", "1", true, false)) or 1

function SelectBestTarget()
	zprint("[ZAim] Selecting best target")
	zaim_dotrace = tonumber(LocalPlayer():GetInfo("zaim_dotrace"))
	//zaim_notk = tonumber(LocalPlayer():GetInfo("zesp_notk"))
	local pos = LocalPlayer():GetPos()
	local best
	local bestdist
	for k, v in pairs(player.GetAll())do
		if v!=LocalPlayer() then
			zprint("[ZAim] Checking "..v:Name())
				
			if v:Alive() and not v.IsFriend then
				zprint("[ZAim] Player Seems Alive.")

					if zaim_dotrace == 1 then
						zprint("[ZAim] Tracing "..v:Name())
						local tracedata = {}
						tracedata.start = LocalPlayer():EyePos()
						local eyes = v:LookupAttachment("eyes")
						zprint("[ZAim] Eyes Attachment: " .. eyes)
						local realeyes = v:GetAttachment(eyes)
						if realeyes==nil then
							zprint("[ZAim] Could not get Attachment \"eyes\".")
						else
							tracedata.endpos = realeyes.Pos+(LocalPlayer():GetAimVector()*10)
							tracedata.filter = botThroughEnts
							local trace = util.TraceLine(tracedata)
							if trace.Entity != v then
								zprint("[ZAim] Has something between ("..tostring(trace.Entity)..").")
							else
								if !best then
									zprint("[ZAim] Selected best. ("..v:Name()..". None before)")
									best = v
									bestdist = v:GetPos():Distance(pos)
								else
									if v:GetPos():Distance(pos)<bestdist then
										zprint("[ZAim] Selected new best ("..v:Name()..". Previous: "..best:Name()..")")
										best = v
										bestdist = v:GetPos():Distance(pos)
									end
								end
							end
						end
					else // if zaim_dotrace == 0
						if !best then
							zprint("[ZAim] Selected best. ("..v:Name()..". None before)")
							best = v
							bestdist = v:GetPos():Distance(pos)
						else
							if v:GetPos():Distance(pos)<bestdist then
								zprint("[ZAim] Selected new best ("..v:Name()..". Previous: "..best:Name()..")")
								best = v
								bestdist = v:GetPos():Distance(pos)
							end
						end
					end // end of zaim_dotrace
			end // end of alive?
			zprint("[ZAim] Finished Checking: " .. v:Name())
		end // end of v!=LocalPlayer
	end // end of loop
	zprint("[ZAim] best: "..tostring(best))
	return best or false
end

local function Shoot()
	RunConsoleCommand('+attack')
	timer.Simple(FrameTime()+0.01,function()
		RunConsoleCommand('-attack')
	end)
end

local zaim_triggerbot = tonumber(CreateClientConVar("zesp_trigger", "1", true, false)) or 1
/*
local DERPOVERRIDE = false
hook.Add("PlayerBindPress","ZAIMPBP",function(ply,bind,pressed)
	zaim_triggerbot = tonumber(LocalPlayer():GetInfo("zesp_trigger"))
	if zaim_triggerbot == 1 and bind == "+attack" and pressed then
		local tracedata = {}
		tracedata.start = LocalPlayer():EyePos()
		if randomplayer then
			local realeyes = randomplayer:GetAttachment(eyes)
			if not realeyes==nil then
				tracedata.endpos = realeyes.Pos+(LocalPlayer():GetAimVector()*10)
				tracedata.filter = LocalPlayer()
				local trace = util.TraceLine(tracedata)
				if trace.Entity != v then
					return true
				end
			end
		end
	end
end)
*/

local ghostpos

hook.Add("CalcView", "ZESPCalcView",function(p, pos, angles, fov)
	
	if zesp_aim == 1 then
		if randomplayer then
			if !randomplayer:Alive() then
				randomplayer = SelectBestTarget()
				if !randomplayer then
					return
				end
			end
		else
			randomplayer = SelectBestTarget()
			if !randomplayer then
				return
			end
		end
		
		zaim_bone = tonumber(LocalPlayer():GetInfo("zaim_bone"))
		
		local angle
		
		if zaim_bone==1 then
			local pos1 = randomplayer:GetAttachment(randomplayer:LookupBone("ValveBiped.Bip01_Spine")).Pos
			local pos2 = randomplayer:GetAttachment(randomplayer:LookupBone("ValveBiped.Bip01_Spine4")).Pos
			angle = (((pos1+pos2)/ 2)-LocalPlayer():EyePos()):Angle()
		else
			angle = ((randomplayer:GetAttachment(randomplayer:LookupAttachment("eyes")).Pos-(randomplayer:GetAimVector()))-(LocalPlayer():EyePos())):Angle()
		end
		
		//p:SetButtons(p:GetButtons() & IN_ATTACK)
		
		
		local view = {}
		view.origin = pos
		view.angles = angle
		view.fov = fov
		
		if LocalPlayer().SetEyeAngles then
			LocalPlayer():SetEyeAngles(angle)
			zaim_triggerbot = tonumber(LocalPlayer():GetInfo("zesp_trigger"))
			if zaim_triggerbot == 1 then
				local tracedata = {}
				tracedata.start = LocalPlayer():EyePos()
				tracedata.endpos = LocalPlayer():EyePos()+(angle:Forward()*10000)
				tracedata.filter = botThroughEnts
				local trace = util.TraceLine(tracedata)
				local trent = trace.Entity
				if trent:IsPlayer() and not trent.IsFriend then
					Shoot()
				end
			end
		end
		
		//CMD:SetViewAngles(angle)
		
		return view
	end
	
	if zesp_aim == 0 and randomplayer then
		randomplayer = nil
	end
	
	if zesp_noclip then
		local view = {}
		view.origin = ghostpos
		return view
	end
	ghostpos = pos
end)



hook.Add("CreateMove", "ZESPCreateMove",function(CMD)
	if zesp_spazz then
		CMD:SetViewAngles(Angle(math.random(-179,180),math.random(-179,180),math.random(-179,180)))
	end
	
	if zesp_noclip then
		angles = (angles or CMD:GetViewAngles()) + Angle(CMD:GetMouseY() * GetConVarNumber("m_pitch"), CMD:GetMouseX() * -GetConVarNumber("m_yaw"))
		angles.r=0
		ucorrected = angles
		ucorrected.p = math.NormalizeAngle(ucorrected.p)
		ucorrected.y = math.NormalizeAngle(ucorrected.y)
		
		local add = Vector( 0, 0, 0 )
		local ang = ucorrected
		if ( CMD:KeyDown( IN_FORWARD ) ) then add = add + ang:Forward() end
		if ( CMD:KeyDown( IN_BACK ) ) then add = add - ang:Forward() end
		if ( CMD:KeyDown( IN_MOVERIGHT ) ) then add = add + ang:Right() end
		if ( CMD:KeyDown( IN_MOVELEFT ) ) then add = add - ang:Right() end
		if ( CMD:KeyDown( IN_JUMP ) ) then add = add + ang:Up() end
		
		add = add:GetNormal() * FrameTime() * 500
		if ( CMD:KeyDown( IN_SPEED ) ) then add = add * 2 end
		if ( CMD:KeyDown( IN_DUCK ) ) then add = add / 4 end

		ghostpos = ghostpos + add
		
		CMD:SetForwardMove( 0 )
		CMD:SetSideMove( 0 )
		CMD:SetUpMove( 0 )
		CMD:SetButtons( 0 )
	end
	
	
end )

/*-------------------------------------------------------------------------------------------------------------------------
	Attack / BHop Script / Use Script / Super Flashlight functions
-------------------------------------------------------------------------------------------------------------------------*/

local function SuperAttack()
	LocalPlayer():ConCommand("+attack")
	LocalPlayer().canAttack = false
	timer.Simple(0.1,
		function()
			LocalPlayer().canAttack = true
			LocalPlayer():ConCommand("-attack")
		end
	)
end

local function SuperUse()
	LocalPlayer():ConCommand("+use")
	LocalPlayer().canUse = false
	timer.Simple(0.1,
		function()
			LocalPlayer().canUse = true
			LocalPlayer():ConCommand("-use")
		end
	)
end

local function SuperFlash()
	LocalPlayer():ConCommand("impulse 100")
	LocalPlayer().canFlash = false
	timer.Simple(0.05,
		function()
			LocalPlayer().canFlash = true
			LocalPlayer():ConCommand("impulse 100")
		end
	)
end

local function ToggleAttack()
	if LocalPlayer().isAttaking then
		LocalPlayer().isAttaking = false
		LocalPlayer():ConCommand("-attack")
	else
		LocalPlayer().isAttaking = true
		LocalPlayer():ConCommand("+attack")
	end
end

local function ToggleUse()
	if LocalPlayer().isUsing then
		LocalPlayer().isUsing = false
		LocalPlayer():ConCommand("-use")
	else
		LocalPlayer().isUsing = true
		LocalPlayer():ConCommand("+use")
	end
end

concommand.Add("+superuse",function(pl,com,args)
	LocalPlayer().SUse = true
	LocalPlayer().canUse = true
end)

concommand.Add("-superuse",function(pl,com,args)
	LocalPlayer().SUse = false
end)

concommand.Add("+superflash",function(pl,com,args)
	LocalPlayer().SFlash = true
	LocalPlayer().canFlash = true
end)

concommand.Add("-superflash",function(pl,com,args)
	LocalPlayer().SFlash = false
end)

concommand.Add("+superattack",function(pl,com,args)
	LocalPlayer().SAtk = true
	LocalPlayer().canAttack = true
end)

concommand.Add("-superattack",function(pl,com,args)
	LocalPlayer().SAtk = false
end)

concommand.Add("toggleattack",function(pl,com,args)
	ToggleAttack()
end)

concommand.Add("toggleuse",function(pl,com,args)
	ToggleUse()
end)

concommand.Add("+superjump",function(pl,com,args)
	LocalPlayer().SJump = true
end)

concommand.Add("-superjump",function(pl,com,args)
	LocalPlayer().SJump = false
end)

local function Jump()
	LocalPlayer():ConCommand("+jump")
	timer.Simple(0.1,
		function()
			LocalPlayer():ConCommand("-jump")
		end
	)
end

hook.Add("Think","SuperCommands",function()
	if(LocalPlayer().SAtk and LocalPlayer().canAttack)then
		SuperAttack()
	end
	if(LocalPlayer().SUse and LocalPlayer().canUse)then
		SuperUse()
	end
	if(LocalPlayer().SFlash and LocalPlayer().canFlash)then
		SuperFlash()
	end
	if(LocalPlayer().SJump and LocalPlayer():IsOnGround())then
		Jump()
	end
end)

/*-------------------------------------------------------------------------------------------------------------------------
	ZBot GUI / Menu
-------------------------------------------------------------------------------------------------------------------------*/

local Categories = {
	"Global",
	"ZESP",
	"ZAIM"
}

local function ZBotTab()
	spawnmenu.AddToolTab( "ZBot", "ZBot" )
	for _,Category in ipairs(Categories) do
		spawnmenu.AddToolCategory("ZBot", Category, Category)
	end
end
hook.Add( "AddToolMenuTabs", "ZBotTab", ZBotTab)



timer.Create("BuddyUpdate",10,0,function()
	UpdateBuddyPanel( BUDDYPANEL )
end)

local function ZMenus()
	
	//global settings
	local function settingsmenu( Panel )
		Panel:ClearControls()
		Panel:AddHeader()
		Panel:AddControl("CheckBox", {
			Label = "Enable ESP",
			Command = "zesp_enable"
		})
		Panel:AddControl("CheckBox", {
			Label = "Keypad Cracker",
			Command = "zesp_keypads"
		})
		Panel:Button("Client Noclip", "zesp_noclip")
		Panel:Button("Spazz Bot", "zesp_spazz")
		Panel:Button("Reload ZBOT", "zbot_reload") 
	end
	spawnmenu.AddToolMenuOption( "ZBot",
			"Global",   
			"GSettings",  
			"Global ZBot Settings",    "",    "",    
			settingsmenu )
	
	local function settingsmenu( Panel )
		Panel:ClearControls()
		Panel:AddHeader()
		Panel:Button("Reload Spawnmenu", "spawnmenu_reload")
		Panel:Button("Toggle Console (Doesn't Work)", "toggleconsole")
		Panel:Button("Fix IgnoreZ (Experimental)", "zesp_fixignorez")
		Panel:TextEntry("Disconnect Message", "disconnect_message", "Disconnect by user.")
	end
	spawnmenu.AddToolMenuOption( "ZBot",
			"Global",   
			"GMisc",  
			"Misc Commands",    "",    "",    
			settingsmenu )
	
	//players
	local function playersmenu( Panel )
		Panel:ClearControls()
		Panel:AddHeader()
		Panel:AddControl("CheckBox", {
			Label = "Player ESP",
			Command = "zesp_players"
		})
		Panel:AddControl("CheckBox", {
			Label = "Show Admins",
			Command = "zesp_showadmins"
		})
		Panel:AddControl("CheckBox", {
			Label = "Player IgnoreZ",
			Command = "zesp_ignorez"
		})
		Panel:AddControl("CheckBox", {
			Label = "Player Radar",
			Command = "zesp_players_radar"
		})
		Panel:AddControl("Slider", {
			Label = "Player Box Size",
			Type = "Float",
			Min = "4",
			Max = "64",
			Command = "zesp_players_size"
		})
	end
	spawnmenu.AddToolMenuOption( "ZBot",
			"ZESP",   
			"Players",  
			"Player ESP Options",    "",    "",    
			playersmenu,
			{SwitchConVar="zesp_players"} )
	
	//props
	local function propsmenu( Panel )
		Panel:ClearControls()
		Panel:AddHeader()
		Panel:AddControl("CheckBox", {
			Label = "Entity ESP",
			Command = "zesp_props"
		})
		Panel:AddControl("CheckBox", {
			Label = "Entity OBB ESP (needs ESP active)",
			Command = "zesp_props_obb"
		})
		Panel:AddControl("CheckBox", {
			Label = "Entity IgnoreZ",
			Command = "zesp_ignorez_props"
		})
		Panel:AddControl("CheckBox", {
			Label = "Show Weapons",
			Command = "zesp_weapons"
		})
	end
	spawnmenu.AddToolMenuOption( "ZBot",
			"ZESP",   
			"Entities",  
			"Entity ESP Options",    "",    "",    
			propsmenu,
			{SwitchConVar="zesp_props"} )
			
	//radar
	local function radarmenu( Panel )
		Panel:ClearControls()
		Panel:AddHeader()
		Panel:AddControl("CheckBox", {
			Label = "Enable Radar",
			Command = "zesp_radar"
		})
		Panel:AddControl("CheckBox", {
			Label = "Show Players on Radar",
			Command = "zesp_players_radar"
		})
		Panel:AddControl("CheckBox", {
			Label = "Show Entities on Radar (SLOW)",
			Command = "zesp_props_radar"
		})
		Panel:Help("")
		Panel:TextEntry("Locate Player", "zesp_locate")
		Panel:Button("Stop Locating", "zesp_locate")
	end
	spawnmenu.AddToolMenuOption( "ZBot",
			"ZESP",   
			"Radar",  
			"Radar Options",    "",    "",    
			radarmenu,
			{SwitchConVar="zesp_radar"} )
			
	//RP
	local function rpmenu( Panel )
		Panel:ClearControls()
		Panel:AddHeader()
		Panel:Help("Printers") 
		Panel:AddControl("CheckBox", {
			Label = "Show Printers",
			Command = "zesp_rp_printers"
		})
		Panel:AddControl("CheckBox", {
			Label = "Vintage Printer ESP (Nivel 100 xD)",
			Command = "zesp_rp_printers_vintage"
		})
		Panel:AddControl("Slider", {
			Label = "Printer ESP Size",
			Type = "Float",
			Min = "2",
			Max = "64",
			Command = "zesp_rp_printers_size"
		})
		Panel:AddControl("CheckBox", {
			Label = "Show on Radar",
			Command = "zesp_rp_printers_radar"
		})
		
		Panel:Help("Shipments") 
		Panel:AddControl("CheckBox", {
			Label = "Show Shipments",
			Command = "zesp_rp_boxes"
		})
		Panel:AddControl("CheckBox", {
			Label = "Show Shipment Contents",
			Command = "zesp_rp_boxes_content"
		})
		Panel:AddControl("CheckBox", {
			Label = "Show on Radar",
			Command = "zesp_rp_boxes_radar"
		})
		
		Panel:Help("Other") 
		Panel:AddControl("CheckBox", {
			Label = "Show Player Money",
			Command = "zesp_rp_playermoney"
		})
		Panel:AddControl("CheckBox", {
			Label = "Show Money Drops",
			Command = "zesp_rp_drops"
		})
		
	end
	spawnmenu.AddToolMenuOption( "ZBot",
			"ZESP",   
			"RP",  
			"RolePlay Options",    "",    "",    
			rpmenu)
			
			
	//ZAIM
	
	//settings
	local function zaimsettingsmenu( Panel )
		Panel:ClearControls()
		Panel:AddHeader()
		Panel:Help("Bind <KEY> +zaim") 
		Panel:Help("") 
		Panel:AddControl("CheckBox", {
			Label = "Enable Triggerbot",
			Command = "zesp_trigger"
		})
		Panel:AddControl("CheckBox", {
			Label = "Bone Aim (BUGGED)",
			Command = "zaim_bone"
		})
		Panel:AddControl("CheckBox", {
			Label = "Do Trace",
			Command = "zaim_dotrace"
		})
		
	end
	spawnmenu.AddToolMenuOption( "ZBot",
			"ZAIM",   
			"AimSettings",  
			"ZAimBot Settings",    "",    "",    
			zaimsettingsmenu )
	
	//buddies
	local function buddiesmenu( Panel )
		UpdateBuddyPanel( Panel )
	end
	spawnmenu.AddToolMenuOption( "ZBot",
			"ZAIM",   
			"Buddies",  
			"ZAimBot Buddies",    "",    "",    
			buddiesmenu )
end
hook.Add( "PopulateToolMenu", "ZMenus", ZMenus )



print('ZBOT v'..zbot_VERSION..' loaded successfuly..')