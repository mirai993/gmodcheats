/* Version 0.0.1 */

require( "zxcmodule" )



//local bgmat = Material("surffff/bg.png", "noclamp smooth")
















// Constants 
local me        = LocalPlayer()
local scrw      = ScrW()
local scrh      = ScrH()  


local surffff = {}

/*
    Config
*/

surffff.cfg         = { vars = {}, colors = {}, binds = {} }

surffff.cfg.vars[ "Anti aim" ]      = false
surffff.cfg.vars[ "Yaw" ]           = 1


surffff.cfg.vars[ "Bunnyhop" ]      = false
surffff.cfg.vars[ "Legit bhop" ]    = false
surffff.cfg.vars[ "Air strafe" ]    = false
surffff.cfg.vars[ "Ground strafe" ] = false
surffff.cfg.vars[ "Strafe type" ]   = 1
/* 
    Surface menu
*/

surface.CreateFont( "RobotoLT", { font = "Roboto", extended = false, size = ScreenScale( 8 ), weight = 400, antialias = true } )










surffff.elementh    = ScreenScale( 10 )
surffff.menuToggled = false

local mx, my = input.GetCursorPos()
local mousedown = false
function surffff.InRect( x, y, w, h )
    return ( mx >= x and mx < w ) and ( my >= y and my < h )
end 

surffff.drawElements    = {}

surffff.drawElements[ "Choice" ] = {
    drawFunc = function( data, x, y )
        surface.SetDrawColor( 16, 16, 16, 128 )
        surface.DrawRect( x, y, surffff.tabWidth, surffff.elementh )

        if surffff.InRect( x, y, x + surffff.tabWidth, y + surffff.elementh ) then
            if input.IsMouseDown( MOUSE_LEFT ) and not mousedown then
                surffff.cfg.vars[ data.str ] = math.Clamp( ( surffff.cfg.vars[ data.str ] + 1 ) % ( #data.strchoices + 1 ), 1, #data.strchoices )
            end
 
            mousedown = input.IsMouseDown( MOUSE_LEFT )
        end 

        surface.SetTextPos( x + 8, y + surffff.elementh / 2 - 8 )
        surface.SetTextColor( 255, 255, 255 )
        surface.DrawText( data.strchoices[ surffff.cfg.vars[ data.str ] ] .. "[ " ..  surffff.cfg.vars[ data.str ] .. " - " .. #data.strchoices .. " ]" )
    end
} 

surffff.drawElements[ "Button" ] = {
    drawFunc = function( data, x, y )
        surface.SetDrawColor( 16, 16, 16, 128 )
        surface.DrawRect( x, y, surffff.tabWidth, surffff.elementh )

        if surffff.InRect( x, y, x + surffff.tabWidth, y + surffff.elementh ) then
            if input.IsMouseDown( MOUSE_LEFT ) and not mousedown then
                surffff.cfg.vars[ data.str ] = not surffff.cfg.vars[ data.str ]
            end
 
            mousedown = input.IsMouseDown( MOUSE_LEFT )
        end

        if surffff.cfg.vars[ data.str ] then
            //surface.SetDrawColor( 255, 255, 255, 255 )
            //surface.SetMaterial( bgmat )

            //render.SetScissorRect( x, y, x + 3, y + surffff.elementh, true)
            //     surface.DrawTexturedRect(0, 0, scrw, scrh)
            //render.SetScissorRect(0, 0, 0, 0, false)
        end

        local clr = surffff.cfg.vars[ data.str ] and 128 or 255

        surface.SetTextPos( x + 8, y + surffff.elementh / 2 - 8 )
        surface.SetTextColor( 255, clr, clr )
        surface.DrawText( data.str )
    end
}

surffff.drawElements[ "Tab" ] = {
    drawFunc = function( data, x, y )

        surface.SetDrawColor( 16, 16, 16, 128 )
        surface.DrawRect( x, y, surffff.tabWidth, data.height )

        if data.open then
            surface.SetDrawColor( 86, 16, 16, 128 )
            surface.DrawRect( x, y, surffff.tabWidth, data.height )
        end

        if surffff.InRect( x, y, x + surffff.tabWidth, y + data.height ) then

            if input.IsMouseDown( MOUSE_LEFT ) and not mousedown then
                data.open = not data.open
            end

            mousedown = input.IsMouseDown( MOUSE_LEFT )
        end

        local openchar = data.open and "˅ " or "> "

        surface.SetTextPos( x + 5, y + data.height / 2 - 8 )
        surface.SetTextColor( 255, 255, 255 )
        surface.DrawText( openchar .. data.str )
    end
}

function surffff.addElement( str, data )
    surffff.drawList[ #surffff.drawList + 1 ] = {
        toDraw      = str,
        
        data        = data,
    }
end

surffff.drawList = {}
 
surffff.tabList = {}

surffff.tabList[ 1 ] = { str = "Combat",
    tbl = {  
        { str = "Button", data = { str = "WIP", height = 30, toggled = false } },
    }
}
surffff.tabList[ 2 ] = { str = "Self",
    tbl = {  
        { str = "Button", data = { str = "Anti aim" } },
        { str = "Choice", data = { str = "Yaw", check = "Anti aim", strchoices = { "Backward", "Sideways", "Fake sideways", "Jitter" } } },
    }
}
surffff.tabList[ 3 ] = { str = "Players",
    tbl = {  
        { str = "Button", data = { str = "WIP", height = 30, toggled = false } },
    }
}
surffff.tabList[ 4 ] = { str = "Movement",
    tbl = {  
        { str = "Button", data = { str = "Bunnyhop" } },
        { str = "Button", data = { str = "Air strafe" } },
        { str = "Choice", data = { str = "Strafe type", check = "Air strafe", strchoices = { "Legit", "Rage", "Multi dir" } } },
        { str = "Button", data = { str = "Ground strafe" } },

    }
}
surffff.tabList[ 5 ] = { str = "World",
    tbl = {  
        { str = "Button", data = { str = "WIP", height = 30, toggled = false } },
    }
}
surffff.tabList[ 7 ] = { str = "Render",
    tbl = {  
        { str = "Button", data = { str = "WIP", height = 30, toggled = false } },
    }
}
surffff.tabList[ 6 ] = { str = "Misc",
    tbl = {  
        { str = "Button", data = { str = "WIP", height = 30, toggled = false } },
    }
}

surffff.tabWidth = scrw / #surffff.tabList - #surffff.tabList
surffff.tabPad   = #surffff.tabList
surffff.tabX     = surffff.tabPad / 2

for i = 1, #surffff.tabList do
    surffff.addElement( "Tab", {
        height = surffff.elementh + surffff.elementh / 4,
        str = surffff.tabList[ i ].str,
        open = false,
        padx = surffff.tabX,
        drawList = surffff.tabList[ i ].tbl
    } )

    surffff.tabX = surffff.tabX + surffff.tabWidth + surffff.tabPad
end

local function drawBackground( x, y, w, h )
    /*


    surface.SetDrawColor( 255, 255, 255, 255 )
    surface.SetMaterial( bgmat )

    render.SetScissorRect( x, y, w, h, true)
        surface.DrawTexturedRect(0, 0, scrw, scrh)

        surface.SetDrawColor( 0, 0, 0, 128 )
        surface.DrawRect( 0, 0, scrw, scrh )
    render.SetScissorRect(0, 0, 0, 0, false)
    */

    surface.SetDrawColor( 0, 0, 0, 128 )
    surface.DrawRect( x, y, w, h ) 
end

function surffff.DrawOverlay()
    if not surffff.menuToggled then return end

    cam.Start2D()
    local x, y = surffff.tabPad, surffff.tabPad 

    mx, my = input.GetCursorPos()
    
    surface.SetFont( "RobotoLT" )

    for i = 1, #surffff.drawList do
        local element = surffff.drawList[ i ]

        if element.toDraw == "Tab" then
            x = element.data.padx
            y = surffff.tabPad
        end

        if not surffff.drawElements[ element.toDraw ] then continue end
         
        surffff.drawElements[ element.toDraw ].drawFunc( element.data, x, y )

        if element.toDraw == "Tab" and element.data.open then
            local dy = y + element.data.height
 
            if #element.data.drawList < 1 then continue end

            for i = 1, #element.data.drawList do
                local subElement = element.data.drawList[ i ]

                if not surffff.drawElements[ subElement.str ] then continue end
                if subElement.data.check and not surffff.cfg.vars[ subElement.data.check ] then continue end

                surffff.drawElements[ subElement.str ].drawFunc( subElement.data, x, dy )
 
                dy = dy + surffff.elementh
            end
        end

        y = y + element.data.height
        x = surffff.tabPad
    end
    cam.End2D()
end

local keypressed = false
function surffff.Think()
    if input.IsKeyDown( KEY_DELETE ) and not keypressed then
        surffff.menuToggled = not surffff.menuToggled
        gui.EnableScreenClicker( surffff.menuToggled )
    end

    keypressed = input.IsKeyDown( KEY_DELETE )
end

/*
    CreateMove
*/

function surffff.Movement( cmd )
    if ( cmd:KeyDown( IN_JUMP ) ) then
        if surffff.cfg.vars[ "Bunnyhop" ] and not me:IsFlagSet( FL_ONGROUND ) then
            cmd:RemoveKey( IN_JUMP )
        end
    end
end

function surffff.PostCreateMoveHook( cmd )
    surffff.Movement( cmd )
end

function surffff.PreFrameStageNotifyHook( stage )
end


/*
    Hooks
*/

hook.Add( "Think",                  "Think",                    surffff.Think )
hook.Add( "PostRender",            "PostRender",              surffff.DrawOverlay )

hook.Add( "PostCreateMove",         "PostCreateMove",           surffff.PostCreateMoveHook )
hook.Add( "PreFrameStageNotify",    "PreFrameStageNotify",      surffff.PreFrameStageNotifyHook ) 