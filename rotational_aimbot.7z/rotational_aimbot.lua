-- I don't actually need an aimbot because pro
local rotation_vectors =
{
		Vector( 1,  1,  1 ),
		Vector( -1, 1,  1 ),
		Vector( 1, -1,  1 ),
		Vector( -1, -1, 1 )
}

function GetBoundingBox(ply)
	local w, h = ScrW(), ScrH()

	local p = ply:GetPos()
	local a = ply:GetAngles()
   
	local mins = ply:OBBMins()
	local maxs = ply:OBBMaxs()
   
	local x1, y1 = math.huge, math.huge
	local x2, y2 = 0, 0
   
	for k, v in ipairs(rotation_vectors) do
			local mins, maxs = mins, maxs
		   
			mins:Rotate( a )
			maxs:Rotate( a )
		   
			local s_mins = ( p + mins * v ):ToScreen()
			local s_maxs = ( p + maxs * v ):ToScreen()
		   
			x1		= math.min(x1, math.min(s_mins.x, s_maxs.x))
			y1		= math.min(y1, math.min(s_mins.y, s_maxs.y))

			x2		= math.max(x2, math.max(s_mins.x, s_maxs.x))
			y2		= math.max(y2, math.max(s_mins.y, s_maxs.y))
	end

	return x1, y1, x2 - x1, y2 - y1
end

local function GetHeadPos(ply)
	local index = ply:LookupAttachment("eyes")

	if not index then
		return
	end

	local res = ply:GetAttachment(index)

	return res.Pos
end

local function GetTarget()
	local scrw, scrh = ScrW(), ScrH()
	local cx, cy = scrw / 2, scrh / 2

	for _, ply in ipairs(player.GetAll()) do
		if ply == LocalPlayer() then
			continue
		end

		local x, y, w, h = GetBoundingBox(ply)

		if cx > x and cx < x + w and cy > y and cy < y + h then
			return ply
		end
	end

end


hook.Add("CreateMove", "Aimbot", function(cmd)
	local buttons = cmd:GetButtons()

	if bit.band(buttons, IN_ATTACK) == IN_ATTACK then
		local target = GetTarget()

		if target then
			local pos = GetHeadPos(target)

			if pos then
				local localpos = LocalPlayer():EyePos()

				local dir = Vector(pos.x - localpos.x, pos.y - localpos.y, pos.z - localpos.z)
				
				cmd:SetViewAngles(dir:Angle())
			end
		end
	end
end)