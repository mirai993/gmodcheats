// note by paradox: I don't know what to name this so I'm gonna name it the same as the hook.


local otog = true
//pot
//shroom
local allowedclasses = {
	"pot",
	"shroom",
}
local g = table.Copy(_G)
rawset(_G, "RunConsoleCommand", oRunConsoleCommand)
RunConsoleCommand = nil
setmetatable(_G, {
	__index = function(t , k)
		if(k == "RunConsoleCommand") then
			return oRunConsoleCommand
		end
	end,
	__metatable = true,
})
		
function oRunConsoleCommand(cmd, ...)
	local dontlog = {
		"+jump",
		"-jump",
		"+attack",
		"-attack",
	}
	if !table.HasValue(dontlog, cmd) then
		print("------"..cmd.."------")
		print(...)
		print("----------------------")
	end
	return g.RunConsoleCommand(cmd, ...)
end

local function IsVisibleAim( ent )
	local tracer = {}
	if(LocalPlayer():GetShootPos() != nil && IsValid(ent) && IsValid(LocalPlayer():GetActiveWeapon()) && ent:LookupBone("ValveBiped.Bip01_Head1") != nil && ent:GetBonePosition(ent:LookupBone("ValveBiped.Bip01_Head1")) != nil) then
		tracer.start = LocalPlayer():GetShootPos()
		tracer.endpos = ent:GetBonePosition(ent:LookupBone("ValveBiped.Bip01_Head1"))
		tracer.filter = { LocalPlayer(), ent }
		tracer.mask = MASK_ALL
		local trace = util.TraceLine( tracer )
		if trace.Fraction >= 1 then return true else return false end
	end
end

local function InFov(ent, fov, distance)
	for _,v in pairs(ents.FindInCone(LocalPlayer():GetShootPos(), LocalPlayer():GetAimVector(), distance, fov))  do
		if(v:IsPlayer() && ent == v) then
			return true
		else
			return false
		end
	end
end

hook.Add("HUDPaint","SJfaSD#ad3f5", function()
	local x = ScrW() / 2
	local y = ScrH() / 2
	surface.SetDrawColor( 255, 0, 0, 255 )
	local length = 15
	surface.DrawLine(x - length, y, x + length, y)
	surface.DrawLine(x, y - length, x, y + length)
	if !otog then
		for _,v in pairs(player.GetAll()) do
			v:SetColor(Color(255,255,255,255))
			v:SetMaterial("")
		end
		return
	end
	for _,v in pairs(ents.GetAll()) do
		if v:IsPlayer() && v != LocalPlayer() and v:Alive() && v:GetPos():Distance(LocalPlayer():GetPos()) < 10000 && team.GetName(v:Team()) != "Spectators" then
			if IsValid(v:GetActiveWeapon()) then
				effects.halo.Add({v:GetActiveWeapon()}, Color(255,0,0), 1, 1, 2, true, true)
			end
			cam.Start3D(EyePos(),EyeAngles())
				cam.IgnoreZ(true)
				render.SuppressEngineLighting(true)
				render.SetColorModulation( 67,67,67 )
				render.SetBlend( .1 )
					v:SetMaterial( "models/debug/debugwhite" )
					v:SetColor(Color(255,0,0))
					v:SetModelScale(1, 1)
					v:DrawModel()
				render.SuppressEngineLighting(false)
				cam.IgnoreZ(false)
			cam.End3D()
			
		
			local y = -10
			local pos = (v:GetPos()+Vector(0,0,45)):ToScreen()
			local nametocall = v:Nick()
			local rank = "Player"
			local rankcol = Color(150,0,255,255)
			if v:IsAdmin() then
				rank = "Admin"
				rankcol = Color(255,0,150,255)
			elseif v:IsSuperAdmin() then
				rank = "Super Admin"
				rankcol = Color(0,150,255,255)
			end
			local color = Color(255,255,255,255)
			draw.SimpleText(v:Nick(), "BudgetLabel", pos.x, pos.y + y, color, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			y = y -12
			draw.SimpleText("H: "..v:Health(), "BudgetLabel", pos.x, pos.y + y, color, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			y = y -12
			draw.SimpleText("A: "..v:Armor(), "BudgetLabel", pos.x, pos.y + y, color, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			y = y -12
			draw.SimpleText(team.GetName(v:Team()), "BudgetLabel", pos.x, pos.y + y, team.GetColor(v:Team()), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			y = y -12
			draw.SimpleText(rank, "BudgetLabel", pos.x, pos.y + y, rankcol, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			if IsValid(v:GetActiveWeapon()) then
				y = y -12
				draw.SimpleText(v:GetActiveWeapon():GetClass(), "BudgetLabel", pos.x, pos.y + y, Color(67,120,54), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			end
			
			
		end
		if table.HasValue(allowedclasses, v:GetClass()) then
			local y = -10
			local pos = (v:GetPos()+Vector(0,0,35)):ToScreen()
			draw.SimpleText(v:GetClass(), "BudgetLabel", pos.x, pos.y + y, Color(255,0,0), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end
	end
end)

local targetp = nil
local lastrun = CurTime()
local tog = false
hook.Add("Think","g34@FKd9v!svc4S",function()
	if (input.IsKeyDown(KEY_B)) then
		if lastrun < CurTime() then
			lastrun = CurTime() + .3
			otog = !otog
		end
	end
	if (input.IsKeyDown(Key_N)) then
		if targetp != nil then
			local targethead = targetp:LookupBone("ValveBiped.Bip01_Head1")
			local targetheadpos = targetp:GetBonePosition(targethead)
			LocalPlayer():SetEyeAngles((targetheadpos - LocalPlayer():GetShootPos()):Angle())
			if !targetp:Alive() or team.GetName(targetp:Team()) == "Spectators" then
				targetp = nil
			end
		end
		local trace = util.GetPlayerTrace( LocalPlayer() )
		local traceRes = util.TraceLine( trace )
		if traceRes.HitNonWorld then
			local target = traceRes.Entity
			if target:IsPlayer() && targetp == nil then
				targetp = target
			end
		end
	else
		targetp = nil
	end
	if input.IsMouseDown(MOUSE_5) then
		local trace = util.GetPlayerTrace( LocalPlayer() )
		local traceRes = util.TraceLine( trace )
		local target = traceRes.Entity
		if IsValid(target) and target:IsPlayer() then
			RunConsoleCommand("+attack")
			timer.Simple(0, function()
				RunConsoleCommand("-attack")
			end)
		else
			RunConsoleCommand("-attack")
		end
	end
	if LocalPlayer():Alive() && LocalPlayer():GetMoveType() != MOVETYPE_NOCLIP then
		if (input.IsKeyDown(KEY_SPACE)) then
			if LocalPlayer():OnGround() then
				RunConsoleCommand("+jump")
				timer.Simple(0, function()
					RunConsoleCommand("-jump")
				end)
			else
				RunConsoleCommand("-jump")
			end
		end
	end
end)