--[[
	TylerHack/lua/autorun/client/TylerHack.lua
	-SDB- Tyler :( | (STEAM_0:0:40143824)
	===DStream===
]]

// Made by tyleR
// Version 1.2.0

local Hack = "TylerHack "
local Mode = 1
local AutoShoot = false
local Aiming = false
local Distance = 999999999
local tracedata = {}

local BannedWeapons = {"weapon_physcannon", "weapon_physgun", "weapon_frag", "weapon_real_cs_smoke", "arrest_stick", "unarrest_stick", "stunstick",
"weapon_real_cs_flash", "weapon_real_cs_grenade", "spidermans_swep", "manhack_welder", "laserpointer", "remotecontroller", "med_kit",
"door_ram", "pocket", "weaponchecker", "lockpick", "keypad_cracker", "keys", "weapon_real_cs_knife", "gmod_tool", "gmod_camera", "weapon_crowbar",
"weapon_stunstick", "weapon_knife", "weapon_rpg"}

print( Hack .. "TylerHack Version 1.2.0 Loaded" )

// AutoShoot Function

local function TylerHack()

if LocalPlayer():Alive() and AutoShoot then

local pos = LocalPlayer():GetShootPos()
local ang = LocalPlayer():GetAimVector()


tracedata.start = pos
tracedata.endpos = pos+(ang * Distance)
tracedata.filter = LocalPlayer()

local trace = util.TraceLine(tracedata)

target = trace.Entity

if WeaponCheck() and ModeCheck() and AmmoCheck() then

Fire()

end
end

end

// Aimbot shit

function ModeCheck()

if Mode == 1 then
if !target:IsNPC() and !target:IsPlayer() then

return false

end

elseif Mode == 2 then
if !target:IsPlayer() then

return false

end

elseif Mode == 3 then
if !target:IsNPC() then

return false

end
end

return true

end

// No-recoil.

local function NoRecoil()

if !Recoil and WeaponCheck() and LocalPlayer():Alive() and LocalPlayer():GetActiveWeapon():IsValid() and LocalPlayer():GetActiveWeapon().Primary then

LocalPlayer():GetActiveWeapon().Primary.Recoil = 0

else return end

end

hook.Add("Think", "Norecoil", NoRecoil)

// Check our ammo, if ammo is 0, then reload and output false, else if ammo is not 0, outputs true.

function AmmoCheck()

if Ammo() == 0 then

LocalPlayer():ConCommand("+reload; wait 2; -reload")

return false

else

return true

end

end

// Output our current ammo.

function Ammo()

if LocalPlayer() and LocalPlayer():GetActiveWeapon() and LocalPlayer():GetActiveWeapon():IsValid() then
 
	actwep = LocalPlayer():GetActiveWeapon()
	
	if ( ! actwep ) then return -1 end
 
	return actwep:Clip1()
	
end
	
end

// Checks if the target is valid for targeting.

function TargetCheck( ent )

if !ent:IsValid() or !ent:IsNPC() and !ent:IsPlayer() or LocalPlayer() == ent then return false end

if ent:IsPlayer() and !ent:Alive() then return false end

if ent:IsNPC() and ent:GetMoveType() == 0 then return false end

	if Mode == 1 then

if ent:IsNPC() or ent:IsPlayer() then return true end
	
	elseif Mode == 2 then

if ent:IsPlayer() then return true end
if ent:IsNPC() then return false end

	elseif Mode == 3 then

if ent:IsNPC() then return true end
if ent:IsPlayer() then return false end

	end

end	

// Targethead

function HeadPosition( ent )
    
	local hbone = ent:LookupBone("ValveBiped.Bip01_Head1")
	return ent:GetBonePosition(hbone)
	
end	



function TargetVisible( ent )
	
	local trace = {start = LocalPlayer():GetShootPos(),endpos = HeadPosition(ent),filter = {LocalPlayer(), ent},mask = 1174421507}
	local tr = util.TraceLine(trace)
	
	if tr.Fraction == 1 then
		
		return true
	
	else
	    
		return false
		
	end	
	
end



function GetTarget()

	local position = LocalPlayer():EyePos()
	local angle = LocalPlayer():GetAimVector()
	local tar = {0,0}
	
for _, ent in pairs( ents.GetAll() ) do
		
		if LocalPlayer():Alive() and WeaponCheck() and TargetCheck( ent ) and TargetVisible( ent ) and AmmoCheck() then
			
			local targetpos = ent:EyePos()
			local editor = ( targetpos - position ):Normalize()
			
			editor = editor - angle
			editor = editor:Length()
			editor = math.abs( editor )
			
				if editor < tar[2] or tar[1] == 0 then
				tar = {ent, editor}
			
				end
		end
end
	
return tar[1]

end

local Aimed = _R["CUserCmd"].SetViewAngles



function AutoAim( UCMD )				
	
if Aiming and WeaponCheck() then
	
	local targ = GetTarget()
	if targ == 0 then return end
	
    local velocity = targ:GetVelocity() or Vector(0,0,0)
        
	Aimed(UCMD, ( ( HeadPosition( targ ) + velocity * 2 * FrameTime() ) - LocalPlayer():GetShootPos() ):Angle() )
		
	local trace = LocalPlayer():GetEyeTrace()

end

end
	
hook.Add("CreateMove", "Autoaim", AutoAim)					


concommand.Add("th_aimbot_on", function()
    
Aiming = true

LocalPlayer():ChatPrint(Hack .. "Aimbot Enabled!")
	
end )


concommand.Add("th_aimbot_off", function()
    
Aiming = false 

LocalPlayer():ChatPrint(Hack .. "Aimbot Disabled!")
	
end )	

// Checks if the weapon you are trying to shoot with is in the table 'BannedWeapons' if it is, then it doesn't shoot with the aimbot.

function WeaponCheck()

if !LocalPlayer():Alive() then return false end

if LocalPlayer():Alive() and LocalPlayer():GetActiveWeapon():IsValid() then

Weapon = LocalPlayer():GetActiveWeapon():GetClass()

else return false

end

if table.HasValue( BannedWeapons, Weapon ) then

return false

else

return true

end

end



function Fire()

LocalPlayer():ConCommand("+attack; wait 2; -attack; wait 2")

end

// Hack GUI

local function menu()

local panel = vgui.Create("DFrame")
panel:SetSize(570, 300)
panel:SetPos(ScrW() / 3, ScrH() / 3)
panel:SetTitle( "TylerHack Menu" )
panel:SetVisible( true )
panel:SetDraggable( true )
panel:ShowCloseButton( true )
panel:MakePopup()

enabled1 = vgui.Create( "DButton", panel )
enabled1:SetPos( 20, 50 )
enabled1:SetSize( 140, 40 )
enabled1:SetText( "Aimbot: ON" )
enabled1.DoClick = function()

RunConsoleCommand( "th_aimbot_on" )
 
end

disabled1 = vgui.Create( "DButton", panel )
disabled1:SetPos( 20, 100 )
disabled1:SetSize( 140, 40 )
disabled1:SetText( "Aimbot: OFF" )
disabled1.DoClick = function()

RunConsoleCommand( "th_aimbot_off" )
 
end

espon1 = vgui.Create( "DButton", panel )
espon1:SetPos( 200, 50 )
espon1:SetSize( 140, 40 )
espon1:SetText( "ESP: On" )
espon1.DoClick = function()

RunConsoleCommand( "th_esp_on" )
 
end

espoff1 = vgui.Create( "DButton", panel )
espoff1:SetPos( 200, 100 )
espoff1:SetSize( 140, 40 )
espoff1:SetText( "ESP: Off" )
espoff1.DoClick = function()

RunConsoleCommand( "th_esp_off" )
 
end

aimoff1 = vgui.Create( "DButton", panel )
aimoff1:SetPos( 20, 210 )
aimoff1:SetSize( 140, 40 )
aimoff1:SetText( "No Recoil: OFF" )
aimoff1.DoClick = function()

RunConsoleCommand( "th_norecoil_off" )
 
end

aimon1 = vgui.Create( "DButton", panel )
aimon1:SetPos( 20, 160 )
aimon1:SetSize( 140, 40 )
aimon1:SetText( "No Recoil: ON" )
aimon1.DoClick = function()

RunConsoleCommand( "th_norecoil_on" )
 
end

mode1 = vgui.Create( "DButton", panel )
mode1:SetPos( 380, 80 )
mode1:SetSize( 140, 40 )
mode1:SetText( "Target All" )
mode1.DoClick = function()

Mode = 1
LocalPlayer():ChatPrint(Hack .. "Targeting Players and NPCs")
 
end

mode2 = vgui.Create( "DButton", panel )
mode2:SetPos( 380, 130 )
mode2:SetSize( 140, 40 )
mode2:SetText( "Target: Player" )
mode2.DoClick = function()

Mode = 2
LocalPlayer():ChatPrint(Hack .. "Targeting Players only")
 
end

mode3 = vgui.Create( "DButton", panel )
mode3:SetPos( 380, 180 )
mode3:SetSize( 140, 40 )
mode3:SetText( "Target: NPC" )
mode3.DoClick = function()

Mode = 3
LocalPlayer():ChatPrint(Hack .. "Targeting NPCs only")
 
end

randon = vgui.Create( "DButton", panel )
randon:SetPos( 200, 160 )
randon:SetSize( 140, 40 )
randon:SetText( "Rejoin Current Server" )
randon.DoClick = function()

LocalPlayer():ConCommand("retry")
 
end

randoff = vgui.Create( "DButton", panel )
randoff:SetPos( 200, 210 )
randoff:SetSize( 140, 40 )
randoff:SetText( "Ban Yourself (Spam Button)" )
randoff.DoClick = function()

LocalPlayer():ConCommand("rcon TylerHackIsCool")
 
end

label1 = vgui.Create( "Label", panel )
label1:SetPos( 205, 250 )
label1:SetSize( 140, 40 )
label1:SetText( "Created By tyleR" )


end

concommand.Add("th_menu", menu)


concommand.Add("th_norecoil_on", function()

Recoil = false
LocalPlayer():ChatPrint( Hack .. "No Recoil Enabled." )

end )

concommand.Add("th_norecoil_off", function()

Recoil = true
LocalPlayer():ChatPrint( Hack .. "No Recoil Disabled." )

end )



//NameChange (broken)

function name_random()

if random == true then

RunConsoleCommand("setinfo", "name", table.Random( player.GetAll() ):Nick() .. " ")

end

end

concommand.Add("th_changer_on", function( ply )

local orig = ply:Nick()
random = true
hook.Add("Think", "random", name_random)

end )

concommand.Add("th_changer_off", function()

random = false
hook.Remove("Think", "random", name_random)
RunConsoleCommand("setinfo", "name", orig)

end )

//ESP Function

function esp()

if enabled == true then
    
	for _,v in ipairs (player.GetAll()) do
	
	local pos = v:GetPos() + Vector(0,0,90)
	pos = pos:ToScreen()
	
	if v:Nick() == LocalPlayer():Nick() then
	name = ""
	dead = ""
	else
	name = v:Nick()
	dead = "*Dead*"
	end
	
	if v:Health() > 0 then
	color = Color(255,255,255,255)
	elseif v:Health() < 1 then
	color = Color(0,0,0,255)
	
	
	draw.DrawText(dead, "ScoreboardText", pos.x, pos.y + 10, color,1)
	
	end
	
	draw.DrawText(name, "ScoreboardText", pos.x, pos.y - 10, color,1)
	
	end
	
end

end

concommand.Add("th_esp_on", function()

enabled = true
hook.Add("HUDPaint", "Paint", esp)
LocalPlayer():ChatPrint(Hack .. "ESP (WallHack) - Enabled")

end )

concommand.Add("th_esp_off", function()

enabled = false
LocalPlayer():ChatPrint(Hack .. "ESP (WallHack) - Disabled")


end )