// note by paradox: Using the name of the script developer here since I am not naming this "aimbot.lua".

--###########
--#BY MaXx0r#
--###########

if CLIENT then
	local t_aim = false
	local t_trigger = false
	local t_wallhack = false
	local target = nil
	local oldtarget = nil
	local target_type = "player"
	local attack = false
	local aim_text = ""
	local trigger_text = ""
	local aim_locked_text = ""
	
	local MainFrame = vgui.Create("DFrame")
	local AimLabel = vgui.Create("DLabel", MainFrame)
	local TriggerLabel = vgui.Create("DLabel", MainFrame)
	local TargetTypeLabel = vgui.Create("DLabel", MainFrame)
	local AimLockedLabel = vgui.Create("DLabel", MainFrame)
	local ModelIcon = vgui.Create("DModelPanel", MainFrame)
	
	local Language_English = {"Aimbot activated...", "Aimbot deactivated...", "Aimbot", "Trigger activated...", "Trigger deactivated...", "Trigger", "Searching for: ", "Target type", "Target changed...", "Target lost...", "Target locked", "Aimbot", "Trigger", "Target type", "Target locked", "Aimbot successfully loaded...", "Searching for: ", "Player added to whitelist: ", "Player removed from whitelist: "}
	local Language_German = {"Aimbot aktiviert...", "Aimbot deaktiviert...", "Aimbot", "Trigger aktiviert...", "Trigger deaktiviert...", "Trigger", "Suche nach: ", "Ziel Typ", "Ziel gewechselt", "Ziel verloren...", "Ziel gesperrt", "Aimbot", "Trigger", "Ziel Typ", "Ziel gesperrt", "Aimbot erfolgreich geladen...", "Suche nach: ", "Spieler zur Whitelist hinzugefuegt: ", "Spieler von Whitelist entfernt: "}
	
	--####SET LANGUAGE###
	local Language = Language_English --English
	--local Language = Language_German --German
	--###################
	
	local Player_Whitelist = {}
	
	function toggle_aimbot()
		t_aim =! t_aim
		
		if t_aim then
			LocalPlayer():ChatPrint(Language[1])
			aim_text="X"
		else
			LocalPlayer():ChatPrint(Language[2])
			aim_text=""
		end
		
		AimLabel:SetText("["..aim_text.."]"..Language[3])
		surface.PlaySound("/buttons/button16.wav")
	end
	
	function toggle_trigger()
		t_trigger =! t_trigger
		
		if t_trigger then
			LocalPlayer():ChatPrint(Language[4])
			trigger_text="X"
		else
			LocalPlayer():ChatPrint(Language[5])
			trigger_text=""
		end
		
		TriggerLabel:SetText("["..trigger_text.."]"..Language[6])
		surface.PlaySound("/buttons/button16.wav")
	end
	
	function toggle_wallhack()
		t_wallhack =! t_wallhack
	end
	
	function change_target_type()
		if target_type=="player" then
			target_type = "npc"
		else
			target_type = "player"
		end
		LocalPlayer():ChatPrint(Language[7]..target_type.."...")
		
		TargetTypeLabel:SetText("["..target_type.."]"..Language[8])
		surface.PlaySound("/buttons/button16.wav")
	end
	
	function check_npc(ent)
		if ent!=nil and ent:IsValid() and target_type=="npc" and ent:IsNPC() then
			return true
		else
			return false
		end
	end
	
	function check_player(ent)
		if ent!=nil and ent:IsValid() and target_type=="player" and ent:IsPlayer() and ent:Alive() then
			return true
		else
			return false
		end
	end
	
	function whitelist_handle_player()
		local ply = LocalPlayer()
		local trace = util.GetPlayerTrace(ply)
		local traceRes = util.TraceLine(trace)
		
		if traceRes.HitNonWorld and check_player(traceRes.Entity) and !table.HasValue(Player_Whitelist, traceRes.Entity:SteamID()) then
			file.Write("aimbot_whitelist.txt", file.Read("aimbot_whitelist.txt")..","..traceRes.Entity:SteamID())
			ply:ChatPrint(Language[18].."["..traceRes.Entity:GetName().." / "..traceRes.Entity:SteamID().."]")
			surface.PlaySound("/buttons/button16.wav")
		elseif traceRes.HitNonWorld and check_player(traceRes.Entity) and table.HasValue(Player_Whitelist, traceRes.Entity:SteamID()) then
			file.Write("aimbot_whitelist.txt", string.Replace(file.Read("aimbot_whitelist.txt"),","..traceRes.Entity:SteamID(), ""))
			ply:ChatPrint(Language[19].."["..traceRes.Entity:GetName().." / "..traceRes.Entity:SteamID().."]")
			surface.PlaySound("/buttons/button16.wav")
		end
	end
	
	function update()
		Player_Whitelist = string.Explode(",",file.Read("aimbot_whitelist.txt"))
		
		local ply = LocalPlayer()
		local trace = util.GetPlayerTrace(ply)
		local traceRes = util.TraceLine(trace)
		local aimbone = traceRes.PhysicsBone
		
		if target==nil and traceRes.HitNonWorld and t_aim then
			if t_aim and check_npc(traceRes.Entity) or (check_player(traceRes.Entity) and !table.HasValue(Player_Whitelist, traceRes.Entity:SteamID())) then
				target = traceRes.Entity
				if target != oldtarget then
					oldtarget = target
					LocalPlayer():ChatPrint(Language[9])
					surface.PlaySound("/buttons/button15.wav")
				end
			end
		end
		
		if MainFrame:IsVisible() then
			if target!=nil and (check_npc(target) or check_player(target)) then
				ModelIcon:SetModel(target:GetModel())
				ModelIcon:SetCamPos(Vector(65, 0, 40))
				ModelIcon:SetLookAt(Vector(0, 0, 40))
			elseif LocalPlayer():Alive() then
				if LocalPlayer():GetActiveWeapon()!=nil then
					ModelIcon:SetModel(LocalPlayer():GetActiveWeapon():GetModel())
					ModelIcon:SetCamPos(Vector(0, 65, 0))
					ModelIcon:SetLookAt(Vector(0, 0, 0))
				end
			end
		end
		
		if target!=nil and t_aim and (check_npc(target) or (check_player(target)) and !table.HasValue(Player_Whitelist, target:SteamID())) then
			local targethead = target:LookupBone("ValveBiped.Bip01_Head1")
			local targetheadpos,targetheadang = target:GetBonePosition(targethead)
			ply:SetEyeAngles((targetheadpos - ply:GetShootPos()):Angle())
			aim_locked_text = "X"
		else
			if oldtarget!=target then
				oldtarget = target
				LocalPlayer():ChatPrint(Language[10])
				aim_locked_text = ""
			end
			target = nil
		end
		
		if MainFrame:IsVisible() then
			AimLockedLabel:SetText("["..aim_locked_text.."]"..Language[11])
		end
		
		if !attack and (check_npc(traceRes.Entity) or (check_player(traceRes.Entity)) and !table.HasValue(Player_Whitelist, traceRes.Entity:SteamID())) and t_trigger and aimbone==10 then
			RunConsoleCommand("+attack")
			attack=true
		elseif attack and (t_trigger or t_aim) then
			RunConsoleCommand("-attack")
			attack=false
		end
		
		for k,v in pairs(player.GetAll()) do
			if table.HasValue(Player_Whitelist, v:SteamID()) then
				v:SetMaterial("models/wireframe")
				v:SetColor(Color(0, 255, 0, 255))
			else
				v:SetMaterial("")
				v:SetColor(Color(255, 255, 255, 255))
			end
		end
	end
	
	function HudPaint()
		if t_wallhack then
			for k,v in pairs(player.GetAll()) do
				draw.DrawText(v:Name().." ["..math.Round(LocalPlayer():GetPos():Distance(v:GetPos())).."]", "Default", v:GetPos():ToScreen().x, v:GetPos():ToScreen().y-100, Color(-math.sin(RealTime()*10)*255, 0, math.sin(RealTime()*10)*255, 255), 1)
			end
		end
	end
	
	function print_whitelist()
		for k,v in pairs(Player_Whitelist) do
			print(v)
		end
	end
	
	function draw_menu()
		MainFrame:SetSize(110, 276)
		MainFrame:SetPos(0, ScrH()/2-256)
		MainFrame:SetTitle("Hack Menu")
		MainFrame:SetVisible(true)
		MainFrame:SetDraggable(true)
		MainFrame:ShowCloseButton(true)
		
		AimLabel:SetSize(96, 32)
		AimLabel:SetPos(8, 30)
		AimLabel:SetText("["..aim_text.."]"..Language[12])

		TriggerLabel:SetSize(96, 32)
		TriggerLabel:SetPos(8, 64)
		TriggerLabel:SetText("["..trigger_text.."]"..Language[13])
		
		TargetTypeLabel:SetSize(96, 32)
		TargetTypeLabel:SetPos(8, 98)
		TargetTypeLabel:SetText("["..target_type.."]"..Language[14])
		
		AimLockedLabel:SetSize(96, 32)
		AimLockedLabel:SetPos(8, 130)
		AimLockedLabel:SetText("["..aim_locked_text.."]"..Language[15])
		
		ModelIcon:SetSize(96,128)
		ModelIcon:SetPos(4, 140)
		function ModelIcon:LayoutEntity(Entity) return end
		ModelIcon:SetFOV(50)
	end
	
	draw_menu()
	
	concommand.Add("toggle_aimbot", toggle_aimbot)
	concommand.Add("toggle_trigger", toggle_trigger)
	concommand.Add("toggle_wallhack", toggle_wallhack)
	concommand.Add("change_target_type", change_target_type)
	concommand.Add("whitelist_handle_player", whitelist_handle_player)
	concommand.Add("print_whitelist", print_whitelist)
	
	hook.Add("Think", "update", update)
	hook.Add("HUDPaint", "paint_hud", HudPaint)
	
	LocalPlayer():ChatPrint(Language[16])
	LocalPlayer():ChatPrint(Language[17]..target_type.."...")
end