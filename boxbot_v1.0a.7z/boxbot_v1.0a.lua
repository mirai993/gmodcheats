--[[
	MOD/lua/BoxBotInDevOG.lua
	[DS]Boxedin123 | STEAM_0:0:21500578 <68.227.30.11:27005> | [16-10-13 12:00:34AM]
	===BadFile===
]]

--Made by Boxedin123 with help from reference material from Wattled Wallnut and math For the crosshair placement from snowizgr8 and the bones table from ReichBot v3(Couldent find author)
-- This is for my PERSONAL LEARNING ONLY! IM NOT GOING TO RELICE IT ONLY SHARE IT AMONG FREINDS WHO ARE LEARNING.

local BoxBotCrosshair = CreateClientConVar("BoxBotCrosshair","0",true,false)
local BoxBotTrigger = CreateClientConVar("BoxBotTrigger","0",true,false)
local BoxBotNorecoil = CreateClientConVar("BoxBotNorecoil","0",true,false)
local BoxBotESP = CreateClientConVar("BoxBotESP","0",true,false)
local BoxBotESP = CreateClientConVar("BoxBotEntESP","0",true,false)
local BoxBotBoneEsp = CreateClientConVar("BoxBotBoneEsp","0",true,false)
local BoxBotNorecoilOffset = CreateClientConVar("BoxBotNorecoilOffset","0",true,false)
local BoxBotAimbot = CreateClientConVar("BoxBotAimbot","0",true,false)
local BoxBotSpeedOffset = CreateClientConVar("BoxBotSpeedOffset","0",true,false)




print("------------------------")
print("------------------------")
print("------------------------")
print("BoxBot V1.0(DEV VERSION)")
print("--------Loaded!---------")
print("------------------------")
print("------------------------")
print("------------------------")
--Crosshair
function BoxBotCross()
local Strobe = math.random (0,255)
if GetConVarNumber("BoxBotCrosshair") >=.9 then
surface.SetDrawColor(Strobe,0,Strobe)
surface.DrawLine(ScrW() / 2 - 10, ScrH() / 2, ScrW() / 2 + 11 , ScrH() / 2)
surface.DrawLine(ScrW() / 2 - 0, ScrH() / 2 - 10, ScrW() / 2 - 0 , ScrH() / 2 + 11)
end
end


--TriggerBot
hook.Add("HUDPaint","BoxBotCrosshair",BoxBotCross)

local DidShoot = false

local function BoxBotTriggerbot()
 
if GetConVarNumber("BoxBotTrigger") >=.9 and Aim == 1 then
	local WhereThePlayerIsLooking = LocalPlayer():GetEyeTrace().Entity 
	if ( WhereThePlayerIsLooking:IsPlayer() or WhereThePlayerIsLooking:IsNPC() ) then 
	
	if ( DidShoot ) then
	RunConsoleCommand( "-Attack" )
	DidShoot = false

	else 
	
	RunConsoleCommand( "+Attack" )
	DidShoot = true
	end
   
	elseif ( DidShoot ) then 
	
	RunConsoleCommand( "-Attack" )
	DidShoot = false
	end
  
	elseif ( DidShoot ) then 
	RunConsoleCommand( "-Attack" )
	DidShoot = false
	end
	end

hook.Add( "Think","boxbot",BoxBotTriggerbot )



--Box Bot Speed
concommand.Add("+BoxBot_Speed",function()
RunConsoleCommand("host_framerate", GetConVarNumber("BoxBotSpeedOffset"))
end)
 
concommand.Add("-BoxBot_Speed",function()
RunConsoleCommand("host_framerate", "0")
end)









--BoxBot Aimboat


concommand.Add("+BoxBot_Aim",function()
Aim = 1
end)
 
concommand.Add("-BoxBot_Aim",function()
Aim = 0
end)




function BoxBotAltAim()
			local HeadPos =  v:EyePos()
			local HeadBone =  v:LookupBone("ValveBiped.Bip01_Head1")
			local HeadPos =  v:GetBonePosition(HeadBone)
			local pos = LocalPlayer():GetShootPos()
				LocalPlayer():SetEyeAngles((HeadPos - pos):Angle())
				end

function BoxBotAim()
if GetConVarNumber("BoxBotAimbot") >= .9 and Aim == 1 then
for k,v in pairs (player.GetAll()) do

local traceArray = {}
traceArray.mask = MASK_SHOT
traceArray.start =  v:GetShootPos()
traceArray.endpos = LocalPlayer():GetShootPos()
traceArray.filter = { LocalPlayer(), v }

local trace = util.TraceLine( traceArray )

if ( !trace.Hit ) then 


local Attachment = v:LookupAttachment("eyes") 
local GetAttachment = v:GetAttachment( Attachment )
local Head = ( GetAttachment.Pos)
local AimVector = ( Head - LocalPlayer():GetShootPos() )
local AimAngle = AimVector:Angle()
if v:Alive() and !(v== LocalPlayer()) then
LocalPlayer():SetEyeAngles(AimAngle)	


				

end
end
end
end
end


hook.Add("Think","BoxBotAim", BoxBotAim)
--Closest check


--Box Bot Entity Esp
if GetConVarNumber("BoxBotEntEsp") >= .9 then
	for _, ent in ipairs(ents.GetAll()) do


	hook.Add("HUDPaint","BoxBotEntEsp", function()
		for k,Ent in pairs(ents.GetAll()) do 
		if string.find(Ent:GetClass(),"spawned_shipment")  or 
		string.find(Ent:GetClass(),"spawned_weapon") or 
		string.find(Ent:GetClass(),"money_printer" or 
		string.find(Ent:GetClass(),"spawned_money")) then
		local ShipmentPos = (Ent:GetPos()):ToScreen()
			draw.SimpleText("Spawned_Entity","Trebuchet18",ShipmentPos.x,ShipmentPos.y +100 ,Color(255,0,0))
end
end
end)
end
end
--NoRecoil 100% Boxedin
hook.Add("Think","BoxBotNorecoil",function()
local NoReOffset = BoxBotNorecoilOffset:GetString()
 if GetConVarNumber("BoxBotNorecoil") >= .9 then
 if LocalPlayer():GetActiveWeapon().Primary then
 LocalPlayer():GetActiveWeapon().Primary.Recoil = NoReOffset
 end
 end
 end)

 --BoxBotESP 100% Boxedin
 local function BoxBotEsp()
	if GetConVarNumber("BoxBotESP") >= .9 then
	for _,v in ipairs(player.GetAll()) do
		if ( v == LocalPlayer() ) then 
		continue end
		local PlayerLocation = v:GetPos():ToScreen()
		
ColorOfEsp = team.GetColor(v:Team())




draw.SimpleText(v:Nick() , "BudgetLabel", PlayerLocation.x , PlayerLocation.y -10, ColorOfEsp , TEXT_ALIGN_CENTER,TEXT_ALIGN_CENTER)
draw.SimpleText("Health:"..v:Health() , "BudgetLabel", PlayerLocation.x , PlayerLocation.y -25, ColorOfEsp , TEXT_ALIGN_CENTER,TEXT_ALIGN_CENTER)

	if v:Health() <=0 then
	draw.SimpleText("**Dead**" , "BudgetLabel", PlayerLocation.x , PlayerLocation.y +15 , ColorOfEsp , TEXT_ALIGN_CENTER,TEXT_ALIGN_CENTER)

end
end
end
end
hook.Add("HUDPaint","BoxBotESP",BoxBotEsp)	

--TTT ESP NOT MINE AT ALL
	





--BoxBot Bone Esp

local Bones = {
        { S = "ValveBiped.Bip01_Head1", E = "ValveBiped.Bip01_Neck1" },
        { S = "ValveBiped.Bip01_Neck1", E = "ValveBiped.Bip01_Spine4" },
        { S = "ValveBiped.Bip01_Spine4", E = "ValveBiped.Bip01_Spine2" },
        { S = "ValveBiped.Bip01_Spine2", E = "ValveBiped.Bip01_Spine1" },
        { S = "ValveBiped.Bip01_Spine1", E = "ValveBiped.Bip01_Spine" },
        { S = "ValveBiped.Bip01_Spine", E = "ValveBiped.Bip01_Pelvis" },
 
        { S = "ValveBiped.Bip01_Spine2", E = "ValveBiped.Bip01_L_UpperArm" },
        { S = "ValveBiped.Bip01_L_UpperArm", E = "ValveBiped.Bip01_L_Forearm" },
        { S = "ValveBiped.Bip01_L_Forearm", E = "ValveBiped.Bip01_L_Hand" },
 
        { S = "ValveBiped.Bip01_Spine2", E = "ValveBiped.Bip01_R_UpperArm" },
        { S = "ValveBiped.Bip01_R_UpperArm", E = "ValveBiped.Bip01_R_Forearm" },
        { S = "ValveBiped.Bip01_R_Forearm", E = "ValveBiped.Bip01_R_Hand" },
 
        { S = "ValveBiped.Bip01_Pelvis", E = "ValveBiped.Bip01_L_Thigh" },
        { S = "ValveBiped.Bip01_L_Thigh", E = "ValveBiped.Bip01_L_Calf" },
        { S = "ValveBiped.Bip01_L_Calf", E = "ValveBiped.Bip01_L_Foot" },
        { S = "ValveBiped.Bip01_L_Foot", E = "ValveBiped.Bip01_L_Toe0" },
       
        { S = "ValveBiped.Bip01_Pelvis", E = "ValveBiped.Bip01_R_Thigh" },
        { S = "ValveBiped.Bip01_R_Thigh", E = "ValveBiped.Bip01_R_Calf" },
        { S = "ValveBiped.Bip01_R_Calf", E = "ValveBiped.Bip01_R_Foot" },
        { S = "ValveBiped.Bip01_R_Foot", E = "ValveBiped.Bip01_R_Toe0" },
}
     
local function BoxBotBoneEsp(e)    
		if GetConVarNumber("BoxBotBoneEsp") >= .9 then
		if e:Team() ~= TEAM_SPECTATOR and e:Team() ~= "1001" and e:Team() ~= "1002" and e:Team() ~= "1003"  and e:Alive() then
        if !e:Alive() then return end
        for k, v in pairs( Bones ) do
		
		
		local BoneID = e:LookupBone(v.S)
		if BoneID == nil then continue end		
		
		local BoneID2 = e:LookupBone(v.E)
		if BoneID2 == nil then continue end
			local sPos, ePos = e:GetBonePosition( BoneID  ):ToScreen(), e:GetBonePosition( BoneID2 ):ToScreen()
	surface.SetDrawColor( team.GetColor( e:Team() ) )
	surface.DrawLine( sPos.x, sPos.y, ePos.x, ePos.y )
end
end
end
end
hook.Add("HUDPaint", "BoxBotBoneEsp", function()
	for k,v in pairs(player.GetAll()) do
		if v != LocalPlayer() then
			BoxBotBoneEsp(v)
end
end
end)

--BoxBotInDevMenu 100% boxedin
local function BoxBotVGUI()
local Frame = vgui.Create( "DFrame" )
	Frame:SetPos( 50, 50 )
	Frame:SetSize( 500, 600 )
	Frame:SetTitle( "BoxBot Alpha: Coded By Boxedin123/ LOTS Of Help From Wattled Wallnut.")
	Frame:SetVisible( true )
	Frame:SetDraggable( true )
	Frame:ShowCloseButton( true )
	Frame:MakePopup()
 
    local Crosshair = vgui.Create( "DCheckBoxLabel" )
    Crosshair:SetText( "Crosshair" )
    Crosshair:SetConVar( "BoxBotCrosshair" )
	Crosshair:SetParent( Frame )
 	Crosshair:SetPos( 70,50 )
    Crosshair:SetValue( GetConVarNumber("BoxBotCrosshair") )
    Crosshair:SizeToContents()
	
    local TriggerBotBox = vgui.Create( "DCheckBoxLabel" )
    TriggerBotBox:SetText( "Trigger Bot" )
	TriggerBotBox:SetParent( Frame )
 	TriggerBotBox:SetPos( 70,70 )
    TriggerBotBox:SetConVar( "BoxBotTrigger" )
    TriggerBotBox:SetValue( GetConVarNumber("BoxBotTrigger") )
    TriggerBotBox:SizeToContents()
 
    local NoRecoilBox = vgui.Create( "DCheckBoxLabel" )
    NoRecoilBox:SetText( "No Recoil" )
	NoRecoilBox:SetParent( Frame )
 	NoRecoilBox:SetPos( 70,90 )
    NoRecoilBox:SetConVar( "BoxBotNorecoil" )
    NoRecoilBox:SetValue( GetConVarNumber("BoxBotNorecoil") )
    NoRecoilBox:SizeToContents()
 
    local ESPBox = vgui.Create( "DCheckBoxLabel" )
    ESPBox:SetText( "ESP" )
	ESPBox:SetParent( Frame )
 	ESPBox:SetPos( 70,130 )
    ESPBox:SetConVar( "BoxBotESP" )
    ESPBox:SetValue( GetConVarNumber("BoxBotESP") )
	ESPBox:SizeToContents()
	
    local ESPBoneBox = vgui.Create( "DCheckBoxLabel" )
    ESPBoneBox:SetText( "Bone Esp" )
	ESPBoneBox:SetParent( Frame )
 	ESPBoneBox:SetPos( 70,150 )
    ESPBoneBox:SetConVar( "BoxBotBoneESP" )
    ESPBoneBox:SetValue( GetConVarNumber("BoxBotBoneESP") )
	ESPBoneBox:SizeToContents()    
	
	local FullbrightBox = vgui.Create( "DCheckBoxLabel" )
    FullbrightBox:SetText( "Fullbright" )
	FullbrightBox:SetParent( Frame )
 	FullbrightBox:SetPos( 70,170 )
    FullbrightBox:SetConVar( "mat_fullbright" )
    FullbrightBox:SetValue( GetConVarNumber("mat_fullbright") )
	
	
	local WireframeBox = vgui.Create( "DCheckBoxLabel" )
    WireframeBox:SetText( "Wireframe(Buggy Something I Cant Control)" )
	WireframeBox:SetParent( Frame )
 	WireframeBox:SetPos( 70,190 )
    WireframeBox:SetConVar( "mat_wireframe")
    WireframeBox:SetValue( GetConVarNumber("mat_wireframe") )
	WireframeBox:SizeToContents()	
	
	
    local NoRecoilOffsetBox = vgui.Create( "DNumSlider" )
    NoRecoilOffsetBox:SetSize( 300, 50 ) 
	NoRecoilOffsetBox:SetParent( Frame )
 	NoRecoilOffsetBox:SetPos( 70,230 )
    NoRecoilOffsetBox:SetText( "No Recoil Offset" )
    NoRecoilOffsetBox:SetMin( -50 )
    NoRecoilOffsetBox:SetMax( 50 )
    NoRecoilOffsetBox:SetDecimals( 0 )
    NoRecoilOffsetBox:SetConVar( "BoxBotNorecoilOffset" )


    local NoRecoilOffsetBox = vgui.Create( "DNumSlider" )
    NoRecoilOffsetBox:SetSize( 300, 100 ) 
	NoRecoilOffsetBox:SetParent( Frame )
 	NoRecoilOffsetBox:SetPos( 70,300 )
    NoRecoilOffsetBox:SetText( "Speedhack Speed" )
    NoRecoilOffsetBox:SetMin( -20 )
    NoRecoilOffsetBox:SetMax( 50 )
    NoRecoilOffsetBox:SetDecimals( 0 )
    NoRecoilOffsetBox:SetConVar( "BoxBotSpeedOffset" )
end
concommand.Add("BoxBot_Menu",BoxBotVGUI)