--[[
	MOD/lua/noobette.lua [#4489 (#4489), 3356652410, UID:1872075671]
	Calver | STEAM_0:0:36375256 <92.24.185.41:27005> | [07.04.14 04:29:32PM]
	===BadFile===
]]

// haha i removed ure credits
// ~ coded by seth ~


	surface.CreateFont( "DefaultSmallDropShadow", {
	font = "Tahoma",
	size = 16,
	weight = 500,
	shadow = true,
} )	

local tables 	= table
local utils 	= util
local hooks 	= hook
local cvar		= cvars
local ent		= ents


local ValidEntity = IsValid

local G = table.Copy(_G)
local R = debug.getregistry()

local shit_box = CreateClientConVar('shit_box',1,true,false)

local esp = {};

esp.teams = {};

function esp:GetColor( ent, info )
	if( info.IsFriend ) then
		return G.Color( 64, 0, 64, 255 );
	elseif( aim:GetTarget() == ent ) then	
		return G.Color( 255, 255, 255, 255 );
	elseif( info.IsAdmin == true ) then
		return G.Color( 255, 0, 0, 255 );
	end
	return G.Color( 0, 255, 0, 255 );
end

function HealthToString(health)
      if health > 90 then
         return Color(0,255,0,255)
      elseif health > 70 then
         return Color(170,230,10,255)
      elseif health > 45 then
         return  Color(230,215,10,255)
      elseif health > 20 then
         return Color(255,140,0,255)
      else
         return Color(255,0,0,255)
      end
   end

   

      

G.surface.CreateFont( "InfoFont", {
	font = "Verdana",
	--tall = 50,
	size = 10,
	weight = 5,
	--outline = true,
	--italic = true,
} );



function esp:GetTeamColor( ent )
	
	return G.team.GetColor( R.Player.Team( ent ) );
end

function esp:Draw()
	local x, y, color
	local mon, nom;
	local h, w;
	local bot, top;
	local sx, sy;
	local size = 5;
			
	local team_color;
	
	for entity, info in G.pairs(player.GetAll() ) do
	if shit_box:GetBool() then
		/*if( !entity || entity && G.ValidEntity( entity ) == false ) then
		--	ent:SetInfo( entity, nil, nil );
			continue;
		end*/
		if !IsValid(info) or !info:Alive() or info == LocalPlayer() then
			continue;
		end
		
		if info:Team() == TEAM_SPECTATOR or  info:GetMoveType() == MOVETYPE_OBSERVER then
			continue
		end
		
		nom = R.Entity.GetPos( info );
		mon = nom + G.Vector( 0, 0, R.Entity.OBBMaxs( info ).z );
		
		bot = R.Vector.ToScreen( nom );
		top = R.Vector.ToScreen( mon );
		
		--if( bot.visible && top.visible ) then
			h = ( bot.y - top.y );
			w = h;
			
			sx, sy = 0, 0;
			
			team_color = team.GetColor(info);
			
			// Top left
			sx = ( top.x - ( w / 2 ) );
			sy = top.y;
			
			G.surface.SetDrawColor( G.Color( 0, 0, 0, 255 ) );
			
			G.surface.DrawRect( sx - 1, sy - 1, size + 2, 3 );
			G.surface.DrawRect( sx - 1, sy - 1, 3, size + 2 );
			
			---G.surface.SetDrawColor( team_color );
				G.surface.SetDrawColor( esp:GetTeamColor( info ) );
			G.surface.DrawLine( sx, sy, sx + size, sy );
			G.surface.DrawLine( sx, sy, sx, sy + size );
			
			// Top right
			sx = ( top.x + ( w / 2 ) );
			sy = top.y;
			
			G.surface.SetDrawColor( G.Color( 0, 0, 0, 255 ) );
			
			G.surface.DrawRect( sx - size, sy - 1, size + 2, 3 );
			G.surface.DrawRect( sx - 1, sy - 1, 3, size + 2 );
			
			--G.surface.SetDrawColor( team_color );
				G.surface.SetDrawColor( esp:GetTeamColor( info ) );
			G.surface.DrawLine( sx, sy, sx - size, sy );
			G.surface.DrawLine( sx, sy, sx, sy + size );
			
			// Bottom left
			sx = ( bot.x - ( w / 2 ) );
			sy = bot.y;
			
			G.surface.SetDrawColor( G.Color( 0, 0, 0, 255 ) );
			
			G.surface.DrawRect( sx - 1, sy - 1, size + 2, 3 );
			G.surface.DrawRect( sx - 1, sy - size, 3, size + 2 );
			
			--G.surface.SetDrawColor( team_color );
				G.surface.SetDrawColor( esp:GetTeamColor( info ) );
			G.surface.DrawLine( sx, sy, sx + size, sy );
			G.surface.DrawLine( sx, sy, sx, sy - size );
			
			// Bottom right
			sx = ( bot.x + ( w / 2 ) );
			sy = bot.y;
			
			G.surface.SetDrawColor( G.Color( 0, 0, 0, 255 ) );
			
			G.surface.DrawRect( sx - size, sy - 1, size + 2, 3 );
			G.surface.DrawRect( sx - 1, sy - size, 3, size + 2 );
			
			G.surface.SetDrawColor( esp:GetTeamColor( info ) );
				--G.surface.SetDrawColor(255,0,0);
			G.surface.DrawLine( sx, sy, sx - size, sy );
			G.surface.DrawLine( sx, sy, sx, sy - size );
			
			local posX = top.x;
			local posY = top.y - 10;
			local esppos = ( info:GetPos() + Vector( 0, 0, info:OBBMaxs().z ) ):ToScreen()

			
		--	G.draw.SimpleText( info:Name().. ' (' .. info:Health() .. ')' , "Default" , posX, posY + 15, team.GetColor(info:Team()), 1 )
			G.draw.SimpleText( info:Nick().. ' (' .. info:Health() .. ')' , "DefaultSmallDropShadow" ,esppos.x, esppos.y , team.GetColor(info:Team()), 1 )
		end
	end
end

function esp.PostRenderVGUI()
	esp:Draw();
end

hook.Add( "PostRenderVGUI",'esp', esp.PostRenderVGUI );