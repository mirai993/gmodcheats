-- paradox note: Has strange stuff like timer.IsTimer which existed in the G13 beta? Odd.

--[[
	includes/modules/Lesp.lua.txt
	monstergirl1244*rawr* :333333 | (STEAM_0:0:50536798)
	===DStream===
]]

-- LESP v1.0
-- DON'T GIVE IT AWAY TO RANDOM PEOPLE, I SPENT A WHOLE FUCKING WEEKEND CODING THIS
-- SOME SHIT MAY BE HARD TO UNDERSTAND. NEVER FORGET; ASK ME HOW TO DO SOMETHING AND I WILL EAT YOU
-- I LIKE TYPING IN CAPS
-- IF IT LAGS, TURN SOME FEATURES OFF
-- ALL COMMANDS ARE IN lix_lesp_
-- BIND SOMETHING TO +lix_lesp_menu, IT'LL MAKE YOUR LIFE EASIER
-- THAT'S ALL FOR NOW, HAVE FUN
-- <3 LIXQUID
 
-- TODO
 
-- SPECTATE
-- VOTING - Select
-- ZOOM
--[[ OTHER SHIT:
--]]
 
-- VARIABLES
 
local LESPSayPrefix = CreateClientConVar( "lix_lesp_sayprefix", "", true, false )
local LESPSayDelay = 0
 
local LESPOn = CreateClientConVar( "lix_lesp_on", 1, true, false )
local LESPHealth = CreateClientConVar( "lix_lesp_health", 1, true, false )
local LESPWeapon = CreateClientConVar( "lix_lesp_weapon", 1, true, false )
local LESPMoney = CreateClientConVar( "lix_lesp_money", 1, true, false )
local LESPDistance = CreateClientConVar( "lix_lesp_distance", 1, true, false )
local LESPSpeed = CreateClientConVar( "lix_lesp_speed", 1, true, false )
 
local LESPMirror = CreateClientConVar( "lix_lesp_mirror", 0, true, false )
local LESPMirrorx = CreateClientConVar( "lix_lesp_mirrorx", 0, true, false )
local LESPMirrory = CreateClientConVar( "lix_lesp_mirrory", 0, true, false )
local LESPMirrorw = CreateClientConVar( "lix_lesp_mirrorw", 300, true, false )
local LESPMirrorh = CreateClientConVar( "lix_lesp_mirrorh", 300, true, false )
local LESPMirrorpitch = CreateClientConVar( "lix_lesp_mirrorpitch", -2, true, false )
local LESPMirroryaw = CreateClientConVar( "lix_lesp_mirroryaw", 180, true, false )
local LESPMirrorroll = CreateClientConVar( "lix_lesp_mirrorroll", 0, true, false )
 
local LESPRadar = CreateClientConVar( "lix_lesp_radar", 0, true, false )
local LESPRadarx = CreateClientConVar( "lix_lesp_radarx", 0, true, false )
local LESPRadary = CreateClientConVar( "lix_lesp_radary", 0, true, false )
local LESPRadarw = CreateClientConVar( "lix_lesp_radarw", 300, true, false )
local LESPRadarh = CreateClientConVar( "lix_lesp_radarh", 300, true, false )
local LESPRadarfov = CreateClientConVar( "lix_lesp_radarfov", 300, true, false )
local LESPRadarauto = CreateClientConVar( "lix_lesp_radarauto", 1, true, false )
 
local LESPAimdot = CreateClientConVar( "lix_lesp_aimdot", 0, true, false )
local LESPAimdotfilt = CreateClientConVar( "lix_lesp_aimdotfilter", 1, true, false )
 
local LESPLight = false
local LESPAura = false
local LESPToggleCommands = {}
 
local LESPVoteTime = CreateClientConVar( "lix_lesp_votetime", 120, true, false )
local LESPVoteVoted = {}
local LESPVoteVotes = {}
local LESPVoteType = 0
 
local LESPDetects = {}
local LESPDetected = {}
local LESPDetectShow = CreateClientConVar( "lix_lesp_detectshow", 1, true, false )
local LESPDetectShowRad = CreateClientConVar( "lix_lesp_detectshowrad", 0, true, false )
local LESPDetectThreshold = CreateClientConVar( "lix_lesp_detectthresh", 100, true, false )
local LESPDetectTrace = CreateClientConVar( "lix_lesp_detecttrace", 0, true, false )
 
local LESPXRay = false
local LESPXRayMat = CreateClientConVar( "lix_lesp_xraymat", "xraysolid", true, false )
local LESPXRayColors = {}
local LESPXRayMats = {}
 
local LESPReverseChat = CreateClientConVar( "lix_lesp_chatreverse", 0, true, false )
local LESPCambChat = CreateClientConVar( "lix_lesp_chatcambridge", 0, true, false )
local LESPByteChat = CreateClientConVar( "lix_lesp_chatbyte", 0, true, false )
 
 
-- ENTITY SAVING
 
local LESPObjectsConvar = CreateClientConVar( "lix_lesp_objects", "", true, false )
local LESPObjects = {}
if LESPObjectsConvar:GetString() ~= "" then
        LESPObjects = string.Explode( "|", LESPObjectsConvar:GetString() )
end
 
-- UTILITY
 
local function LESPGetOffset( ply )
        if !ValidEntity( ply ) then return Vector( 0, 0, 0 ) end
        if !ply:GetAttachment( ply:LookupAttachment( "eyes" ) ) then
                return ply:GetShootPos():ToScreen()
        else
                return ply:GetAttachment( ply:LookupAttachment( "eyes" ) ).Pos:ToScreen()
        end
end
 
local function LESPSay( text )
        if string.len( LESPSayPrefix:GetString() .. text ) > 125 then
                timer.Simple( 2 * ( LESPSayDelay + 1 ), LESPSay, string.sub( LESPSayPrefix:GetString() .. text, 127 ) )
        end
        timer.Simple( 2 * LESPSayDelay, function()
                LESPSayDelay = LESPSayDelay - 1
                RunConsoleCommand( "say", LESPSayPrefix:GetString() .. text )
        end )
        LESPSayDelay = LESPSayDelay + 1
end
 
-- MAIN DRAWING
 
local function LESPDraw()
        if LESPAimdot:GetInt() > 0 then
                for _, v in pairs( player.GetAll() ) do
                        if LESPAimdotfilt:GetInt() > 0 then
                                if !util.TraceLine( { start = LocalPlayer():GetShootPos(), endpos = v:GetEyeTrace().HitPos, filter = LocalPlayer() } ).Hit and v ~= LocalPlayer() then
                                        local o = v:GetEyeTrace().HitPos:ToScreen()
                                        surface.SetDrawColor( 0, 0, 0, 255 )
                                        surface.DrawRect( o.x - 2, o.y - 2, 4, 4 )
                                        local col = team.GetColor( v:Team() )
                                        surface.SetDrawColor( col.r, col.g, col.b, 255 )
                                        surface.DrawRect( o.x - 1, o.y - 1, 2, 2 )
                                       
                                        surface.SetDrawColor( 0, 0, 0, 50 )
                                        surface.SetFont( "Default" )
                                        surface.DrawRect( o.x - surface.GetTextSize( v:Nick() ) / 2, o.y + 7, surface.GetTextSize( v:Nick() ) + 2, 12 )
                                        surface.SetTextColor( 255, 255, 255, 255 )
                                        surface.SetTextPos( o.x - ( surface.GetTextSize( v:Nick() ) ) / 2 + 1, o.y + 6 )
                                        surface.DrawText( v:Nick() )
                                end
                        else
                                if v ~= LocalPlayer() then
                                        local o = v:GetEyeTrace().HitPos:ToScreen()
                                        surface.SetDrawColor( 0, 0, 0, 255 )
                                        surface.DrawRect( o.x - 2, o.y - 2, 4, 4 )
                                        local col = team.GetColor( v:Team() )
                                        surface.SetDrawColor( col.r, col.g, col.b, 255 )
                                        surface.DrawRect( o.x - 1, o.y - 1, 2, 2 )
                                       
                                        surface.SetDrawColor( 0, 0, 0, 50 )
                                        surface.SetFont( "Default" )
                                        surface.DrawRect( o.x - surface.GetTextSize( v:Nick() ) / 2, o.y + 7, surface.GetTextSize( v:Nick() ) + 2, 12 )
                                        surface.SetTextColor( 255, 255, 255, 255 )
                                        surface.SetTextPos( o.x - ( surface.GetTextSize( v:Nick() ) ) / 2 + 1, o.y + 6 )
                                        surface.DrawText( v:Nick() )
                                end
                        end
                end
        end
        if LESPOn:GetInt() > 0 then
                for _, v in pairs( LESPObjects ) do
                        if v ~= "" then
                                for k, b in pairs( ents.GetAll() ) do
                                        if string.find( string.lower( b:GetClass() ), string.lower( v ) ) then
                                                local o = b:GetPos():ToScreen()
                                                surface.SetDrawColor( 0, 0, 0, 255 )
                                                surface.DrawRect( o.x - 6, o.y - 6, 12, 12 )
                                                surface.SetDrawColor( 255, 255, 255, 255 )
                                                surface.DrawRect( o.x - 5, o.y - 5, 10, 10 )
                                               
                                                surface.SetFont( "Default" )
                                               
                                                surface.SetDrawColor( 0, 0, 0, 50 )
                                                surface.DrawRect( o.x + 12, o.y - 6, surface.GetTextSize( b:GetClass() ) + 2, 12 )
                                                surface.SetTextColor( 255, 255, 255, 255 )
                                                surface.SetTextPos( o.x + 13, o.y - 7 )
                                                surface.DrawText( b:GetClass() )
                                               
                                                surface.SetDrawColor( 0, 0, 0, 50 )
                                                surface.SetFont( "Default" )
                                                surface.DrawRect( o.x - 6, o.y - 19, surface.GetTextSize( "D: " .. math.floor( b:GetPos():Distance( LocalPlayer():GetPos() ) ) ) + 2, 12 )
                                                surface.SetTextColor( 255, 255, 255, 255 )
                                                surface.SetTextPos( o.x - 5, o.y - 20 )
                                                surface.DrawText( "D: " .. math.floor( b:GetPos():Distance( LocalPlayer():GetPos() ) ) )
                                        end
                                end
                        end
                end
                for _, v in pairs( player.GetAll() ) do
                        if v:Alive() and v ~= LocalPlayer() then
                                local o = LESPGetOffset( v )
                               
                                if v:GetPos():Distance( LocalPlayer():GetPos() ) < 500 then
                                        o.y = o.y - ( 100 - v:GetPos():Distance( LocalPlayer():GetPos() ) / 5 )
                                end
                               
                                local color = team.GetColor( v:Team() )
                                surface.SetDrawColor( 0, 0, 0, 255 )
                                surface.DrawRect( o.x - 6, o.y - 6, 12, 12 )
                                surface.SetDrawColor( 0, 0, 255, 255 )
                                if v:IsSuperAdmin() then
                                        surface.SetDrawColor( 255, 0, 0, 255 )
                                elseif v:IsAdmin() then
                                        surface.SetDrawColor( 0, 255, 0, 255 )
                                end
                                surface.DrawRect( o.x - 5, o.y - 5, 10, 10 )
                                surface.SetDrawColor( 0, 0, 0, 255 )
                                surface.DrawRect( o.x - 3, o.y - 3, 6, 6 )
                                surface.SetDrawColor( color.r, color.g, color.b, 255 )
                                surface.DrawRect( o.x - 2, o.y - 2, 4, 4 )
                               
                                surface.SetFont( "Default" )
                               
                                surface.SetDrawColor( 0, 0, 0, 50 )
                                surface.DrawRect( o.x + 12, o.y - 6, surface.GetTextSize( v:Nick() ) + 2, 12 )
                                surface.SetTextColor( 255, 255, 255, 255 )
                                surface.SetTextPos( o.x + 13, o.y - 7 )
                                surface.DrawText( v:Nick() )
                               
                                if LESPDistance:GetInt() > 0 then
                                        surface.SetDrawColor( 0, 0, 0, 50 )
                                        surface.SetFont( "Default" )
                                        surface.DrawRect( o.x - 6, o.y - 19, surface.GetTextSize( "D: " .. math.floor( v:GetPos():Distance( LocalPlayer():GetPos() ) ) ) + 2, 12 )
                                        surface.SetTextColor( 255, 255, 255, 255 )
                                        surface.SetTextPos( o.x - 5, o.y - 20 )
                                        surface.DrawText( "D: " .. math.floor( v:GetPos():Distance( LocalPlayer():GetPos() ) ) )
                                end
                               
                                if LESPHealth:GetInt() > 0 then
                                        surface.SetDrawColor( 0, 0, 0, 50 )
                                        surface.SetFont( "Default" )
                                        surface.DrawRect( o.x - 6, o.y + 7, surface.GetTextSize( "HP: " .. v:Health() ) + 2, 12 )
                                        surface.SetTextColor( 255, 255, 255, 255 )
                                        surface.SetTextPos( o.x - 5, o.y + 6 )
                                        surface.DrawText( "HP: " .. v:Health() )
                                end
                               
                                if LESPMoney:GetInt() > 0 and v:GetNetworkedInt( "Money" ) ~= 0 then
                                        surface.SetDrawColor( 0, 0, 0, 50 )
                                        surface.SetFont( "Default" )
                                        local add = 19
                                        if LESPDistance:GetInt() > 0 then add = 32 end
                                        surface.DrawRect( o.x - 6, o.y - add, surface.GetTextSize( "$: " .. v:GetNWInt( "Money" ) ) + 2, 12 )
                                        surface.SetTextColor( 255, 255, 255, 255 )
                                        surface.SetTextPos( o.x - 5, o.y - add - 1 )
                                        surface.DrawText( "$: " .. v:GetNWInt( "Money" ) )
                                end
                               
                                if LESPWeapon:GetInt() > 0 and v:GetActiveWeapon():IsValid() then
                                        surface.SetDrawColor( 0, 0, 0, 50 )
                                        surface.SetFont( "Default" )
                                        local add = 6
                                        if LESPHealth:GetInt() > 0 then add = 19 end
                                        surface.DrawRect( o.x - 6, o.y + add + 1, surface.GetTextSize( v:GetActiveWeapon():GetPrintName() ) + 2, 12 )
                                        surface.SetTextColor( 255, 255, 255, 255 )
                                        surface.SetTextPos( o.x - 5, o.y + add )
                                        surface.DrawText( v:GetActiveWeapon():GetPrintName() )
                                end
                               
                        end
                end
        end
        if LESPMirror:GetInt() > 0 then
                local pitch = LESPMirrorpitch:GetInt()
                if pitch < 0 then pitch = pitch * LocalPlayer():EyeAngles().p end
                local yaw = LESPMirroryaw:GetInt()
                if yaw < 0 then yaw = yaw * LocalPlayer():EyeAngles().y end
                local roll = LESPMirrorroll:GetInt()
                if roll < 0 then roll = roll * LocalPlayer():EyeAngles().r end
               
                local Cam = {}
                Cam.angles = Angle( LocalPlayer():EyeAngles().p + pitch, LocalPlayer():EyeAngles().y + yaw, LocalPlayer():EyeAngles().r + roll )
                Cam.origin = LocalPlayer():GetShootPos()
                Cam.x = LESPMirrorx:GetInt()
                Cam.y = LESPMirrory:GetInt()
                Cam.w = LESPMirrorw:GetInt()
                Cam.h = LESPMirrorh:GetInt()
                render.RenderView( Cam )
                surface.SetDrawColor( 0, 0, 0, 255 )
                surface.DrawOutlinedRect( LESPMirrorx:GetInt(), LESPMirrory:GetInt(), LESPMirrorw:GetInt(),LESPMirrorh:GetInt() )
                surface.SetDrawColor( 255, 255, 255, 255 )
                surface.DrawRect( ScrW() / 2 - 1, ScrH() / 2 - 1, 2, 2 )
        end
        if LESPRadar:GetInt() > 0 then
                local Cam = {}
                Cam.angles = Angle( 90, LocalPlayer():EyeAngles().y, 0 )
               
                local Zvar = LESPRadarfov:GetInt()
                if LESPRadarauto:GetInt() > 0 then
                        local trace = {}
                        trace.start = LocalPlayer():GetPos() + Vector( 0, 0, 5 )
                        trace.endpos = LocalPlayer():GetPos() + Vector( 0, 0, LESPRadarfov:GetInt() )
                        trace.filter = LocalPlayer()
                        if util.TraceLine( trace ).Hit then
                                Zvar = util.TraceLine( trace ).HitPos.z - 5 - LocalPlayer():GetPos().z
                        end
                end
               
                Cam.origin = LocalPlayer():GetPos() + Vector( 0, 0, Zvar )
                Cam.x = LESPRadarx:GetInt()
                Cam.y = LESPRadary:GetInt()
                Cam.w = LESPRadarw:GetInt()
                Cam.h = LESPRadarh:GetInt()
                render.RenderView( Cam )
                surface.SetDrawColor( 0, 0, 0, 255 )
                surface.DrawOutlinedRect( LESPRadarx:GetInt(), LESPRadary:GetInt(), LESPRadarw:GetInt(),LESPRadarh:GetInt() )
                surface.SetDrawColor( 255, 255, 255, 255 )
                surface.DrawRect( ScrW() / 2 - 1, ScrH() / 2 - 1, 2, 2 )
        end
        for k, v in pairs( LESPDetects ) do
                if LESPDetectShow:GetInt() > 0 then
                        local o = v:ToScreen()
                        surface.SetDrawColor( 0, 0, 0, 255 )
                        surface.DrawRect( o.x - 2, o.y - 2, 4, 4 )
                        surface.SetDrawColor( 200, 50, 50, 255 )
                        surface.DrawRect( o.x - 1, o.y - 1, 2, 2 )
                       
                        surface.SetDrawColor( 0, 0, 0, 50 )
                        surface.SetFont( "Default" )
                        surface.DrawRect( o.x - surface.GetTextSize( "DET " .. k ) / 2, o.y + 7, surface.GetTextSize( "DET " .. k ) + 2, 12 )
                        surface.SetTextColor( 255, 255, 255, 255 )
                        surface.SetTextPos( o.x - ( surface.GetTextSize( "DET " .. k ) ) / 2 + 1, o.y + 6 )
                        surface.DrawText( "DET " .. k )
                        if LESPDetectShowRad:GetInt() > 0 then
                                for i = 1, 6 do
                                        local o = ( v + Vector( math.sin( i * 1 ) * LESPDetectThreshold:GetInt(), math.cos( i * 1 ) * LESPDetectThreshold:GetInt(), 0 ) ):ToScreen()
                                        local o2 = ( v + Vector( math.sin( ( i + 1 ) * 1 ) * LESPDetectThreshold:GetInt(), math.cos( ( i + 1 ) * 1 ) * LESPDetectThreshold:GetInt(), 0 ) ):ToScreen()
                                       
                                        surface.SetDrawColor( 255, 0, 0, 255 )
                                        surface.DrawLine( o.x, o.y, o2.x, o2.y )
                                end
                        end
                end
        end
end
hook.Add( "HUDPaint", "LESP", LESPDraw )
 
local function LESPThink()
        if LESPLight then
                local light = DynamicLight( LocalPlayer():UserID() )
                if light then
                        light.Pos = LocalPlayer():GetEyeTrace().HitPos
                        light.r = 255
                        light.g = 255
                        light.b = 255
                        light.Brightness = 10
                        light.Size = 800
                        light.Decay = 0
                        light.DieTime = CurTime() + 0.2
                end
        end
        if LESPAura then
                local light = DynamicLight( LocalPlayer():UserID() )
                if light then
                        light.Pos = LocalPlayer():GetPos()
                        light.r = 255
                        light.g = 255
                        light.b = 255
                        light.Brightness = 10
                        light.Size = 800
                        light.Decay = 0
                        light.DieTime = CurTime() + 0.2
                end
        end
        for k, v in pairs( LESPDetects ) do
                for b, n in pairs( player.GetAll() ) do
                        if LESPDetectTrace:GetInt() > 0 then
                                if n:GetPos():Distance( v ) < LESPDetectThreshold:GetInt() and !util.TraceLine( { start = v + Vector( 0, 0, 5 ), endpos = n:GetPos() } ).Hit and LESPDetected[ n:UniqueID() ] ~= true then
                                        chat.AddText( "Detector " .. k .. " breached by " .. n:Nick() )
                                        LESPDetected[ n:UniqueID() ] = true
                                elseif n:GetPos():Distance( v ) > LESPDetectThreshold:GetInt() then
                                        LESPDetected[ n:UniqueID() ] = false
                                end
                        else
                                if n:GetPos():Distance( v ) < LESPDetectThreshold:GetInt() and LESPDetected[ n:UniqueID() ] ~= true then
                                        chat.AddText( "Detector " .. k .. " breached by " .. n:Nick() )
                                        LESPDetected[ n:UniqueID() ] = true
                                elseif n:GetPos():Distance( v ) > LESPDetectThreshold:GetInt() then
                                        LESPDetected[ n:UniqueID() ] = false
                                end
                        end
                end
        end
end
hook.Add( "Think", "LESP", LESPThink )
 
concommand.Add( "lix_lesp_light", function() LESPLight = !LESPLight end )
concommand.Add( "lix_lesp_aura", function() LESPAura = !LESPAura end )
 
local function LESPDetectAdd()
        table.insert( LESPDetects, LocalPlayer():GetPos() )
        chat.AddText( "Detector " .. #LESPDetects .. " placed" )
end
 
local function LESPDetectRemove()
        if #LESPDetects > 0 then
                local best = 99999
                local var = 0
                for k, v in pairs( LESPDetects ) do
                        if v:Distance( LocalPlayer():GetPos() ) < best then
                                best = v:Distance( LocalPlayer():GetPos() )
                                var = k
                        end
                end
                table.remove( LESPDetects, var )
                chat.AddText( "Detector " .. var .. " removed" )
        end
end
 
concommand.Add( "lix_lesp_detectadd", LESPDetectAdd )
concommand.Add( "lix_lesp_detectremove", LESPDetectRemove )
 
 
-- VOTE
 
local function LESPVoteChat( ply, text, tchat, dead )
        if ply ~= LocalPlayer() and ply:EntIndex() ~= 0 and LESPVoteType ~= 0 then
                if !table.HasValue( LESPVoteVoted, ply ) then
                        if LESPVoteType == 1 then
                                if string.find( string.lower( text ), "!yes" ) then
                                        table.insert( LESPVoteVoted, ply )
                                        LESPVoteVotes[ "yes" ] = LESPVoteVotes[ "yes" ] + 1
                                        LESPSay( "Player " .. ply:Nick() .. " voted for. (+" .. LESPVoteVotes[ "yes" ] .. "/-" .. LESPVoteVotes[ "no" ] .. ")" )
                                elseif string.find( string.lower( text ), "!no" ) then
                                        table.insert( LESPVoteVoted, ply )
                                        LESPVoteVotes[ "no" ] = LESPVoteVotes[ "no" ] + 1
                                        LESPSay( "Player " .. ply:Nick() .. " voted against. (+" .. LESPVoteVotes[ "yes" ] .. "/-" .. LESPVoteVotes[ "no" ] .. ")" )
                                end
                        end
                        if LESPVoteType == 2 then
                                if string.find( text, "!" ) then
                                        for k, v in pairs( LESPVoteVotes ) do
                                                if string.lower( string.sub( text, string.find( text, "!" ) + 1 ) ) == string.lower( k ) then
                                                        table.insert( LESPVoteVoted, ply )
                                                        LESPVoteVotes[ string.lower( string.sub( text, string.find( text, "!" ) + 1 ) ) ] = v + 1
                                                        LESPSay( "Player " .. ply:Nick() .. " voted for " .. k .. " with " .. v .. " other(s)." )
                                                        return
                                                end
                                        end
                                        table.insert( LESPVoteVoted, ply )
                                        LESPVoteVotes[ string.sub( text, string.find( text, "!" ) + 1 ) ] = 1
                                        LESPSay( "Player " .. ply:Nick() .. " voted for " .. string.sub( text, string.find( text, "!" ) + 1 ) .. "." )
                                end
                        end
                end
        end
        if ply == LocalPlayer() then
                LESPSayDelay = LESPSayDelay + 1
                timer.Simple( 2, function() LESPSayDelay = LESPSayDelay - 1 end )
        end
       
        -- CHAT NOMMERS
       
        if LESPReverseChat:GetInt() > 0 and ply ~= LocalPlayer() then
                LESPSay( string.reverse( text ) )
        end
       
        if LESPByteChat:GetInt() > 0 and ply~= LocalPlayer() then
                local said = {}
                for _, k in pairs( string.ToTable( text ) ) do
                        table.insert( said, string.byte( k ) )
                end
                LESPSay( table.concat( said, " " ) )
        end
       
        if LESPCambChat:GetInt() > 0 and ply ~= LocalPlayer() then
                local tosay = ""
                for k, v in pairs( string.Explode( " ", text ) ) do
                        if string.len( v ) > 1 then
                                local word = string.sub( v, 2, string.len( v ) - 1 )
                                word = string.ToTable( word )
                                table.sort( word, function( a, b ) return ( math.random( 0, 1 ) == 0 ) end )
                                word = table.concat( word, "" )
                                tosay = tosay .. string.Left( v, 1 ) .. word .. string.Right( v, 1 ) .. " "
                        else
                                tosay = tosay .. v .. " "
                        end
                end
                LESPSay( string.Left( tosay, string.len( tosay ) - 1 ) )
        end
end
hook.Add( "OnPlayerChat", "LESP", LESPVoteChat )
 
local function LESPVoteStartYN( ply, com, args )
        if LESPVoteType ~= 0 then
                LESPVoteStop()
        end
        LESPVoteType = 1
        LESPSay( "LESP: \"" .. ( args[1] or "VOTE" ) .. "\". Vote with !yes or !no" )
        LESPVoteVotes[ "yes" ] = 0
        LESPVoteVotes[ "no" ] = 0
        timer.Create( "LESPVote", LESPVoteTime:GetInt(), 1, RunConsoleCommand, "lix_lesp_votestop" )
end
 
local function LESPVoteStartOpen( ply, com, args )
        if LESPVoteType ~= 0 then
                LESPVoteStop()
        end
        LESPVoteType = 2
        LESPSay( "LESP: \"" .. ( args[1] or "VOTE" ) .. "\". Vote with ! then what you want to vote." )
        timer.Create( "LESPVote", LESPVoteTime:GetInt(), 1, RunConsoleCommand, "lix_lesp_votestop" )
end
 
local function LESPVoteStop()
        if timer.IsTimer( "LESPVote" ) then
                timer.Stop( "LESPVote" )
        end
       
        LESPSay( "Vote Over. Results:" )
       
        if LESPVoteType == 1 then
                local extra = ""
                if LESPVoteVotes[ "yes" ] > LESPVoteVotes[ "no" ] then
                        extra = "Vote Passed."
                elseif LESPVoteVotes[ "yes" ] < LESPVoteVotes[ "no" ] then
                        extra = "Vote Failed."
                elseif LESPVoteVotes[ "yes" ] + LESPVoteVotes[ "no" ] == 0 then
                        extra = "Nobody Voted."
                elseif LESPVoteVotes[ "yes" ] == LESPVoteVotes[ "no" ] then
                        extra = "Vote Undecided."
                else
                        extra = "LOLWAT GLITCH"
                end
               
                LESPSay( "+" .. LESPVoteVotes[ "yes" ] .. " -" .. LESPVoteVotes[ "no" ] .. " " .. extra )
        end
        if LESPVoteType == 2 then
                --if #LESPVoteVotes == 0 then
                --      LESPSay( "Nobody Voted." )
                --end
                        local bestnum = 0
                        for k, v in pairs( LESPVoteVotes ) do
                                if v > bestnum then
                                        bestnum = v
                                end
                        end
                        local best = {}
                        for k, v in pairs( LESPVoteVotes ) do
                                if v == bestnum then
                                        table.insert( best, k )
                                end
                        end
                       
                        LESPSay( table.concat( best, ", " ) .. " had the most votes with " .. bestnum )
                --end
        end
       
        LESPVoteType = 0
        LESPVoteVotes = {}
        LESPVoteVoted = {}
end
 
concommand.Add( "lix_lesp_votestartyn", LESPVoteStartYN )
concommand.Add( "lix_lesp_votestartopen", LESPVoteStartOpen )
 
concommand.Add( "lix_lesp_votestop", LESPVoteStop )
 
-- XRAY
 
concommand.Add( "lix_lesp_xraay", function()
        if !LESPXRay then
                surface.PlaySound("beep_synthtone01.wav") -- Alright, i'll show you where the sounds are.
                for _, v in pairs( ents.GetAll() ) do
                        local r, g, b, a = v:GetColor()
                        LESPXRayColors[ v:EntIndex() ] = Color( r, g, b, a )
                        LESPXRayMats[ v:EntIndex() ] = v:GetMaterial()
                        if v:IsNPC() then
                                v:SetColor( 0, 0, 255, 255 )
                        elseif v:IsWeapon() then
                                v:SetColor( 150, 0, 255, 255 )
                        elseif string.find( v:GetClass(), "ghost" ) then
                                v:SetColor( 255, 255, 255, 100 )
                        elseif v:GetClass() == "drug_lab" or v:GetClass() == "money_printer" then
                                v:SetColor( 250, 50, 100, 50 )
                        elseif v:GetClass() == "viewmodel" then
                                v:SetColor( 255, 255, 255, 50 )
                        else
                                v:SetColor( 250, 250, 50, 100 )
                        end
                        v:SetMaterial( LESPXRayMat:GetString() )
                end
                LESPXRay = true
        else
                for _, v in pairs( ents.GetAll() ) do
                        local col = LESPXRayColors[ v:EntIndex() ] or Color( 255, 255, 255, 255 )
                        v:SetMaterial( LESPXRayMats[ v:EntIndex() ] )
                        v:SetColor( col.r, col.g, col.b, col.a )
                        LESPXRay = false
                end
        end
        if LESPXRay then
                surface.PlaySound("beep_error01.wav") -- When you turn it off, it will play this.
        end
end )
 
local function LESPRenderScene()
        if LESPXRay == false then return end
        for _, v in pairs( ents.FindByClass( "prop_physics" ) ) do
                if ValidEntity( v ) then
                        v:SetColor( 75, 255, 10, 95 )-- <------ Change that color if you like too.
                        v:SetMaterial( LESPXRayMat:GetString() )
                end
               
        end
        for _, v in pairs( player.GetAll() ) do
                if ValidEntity( v ) then
                        v:SetColor( 185, 10, 255, 255 )
                        v:SetMaterial( LESPXRayMat:GetString() )
                end
        end
end
hook.Add( "RenderScene", "LESP", LESPRenderScene )
-- You didn't put the other player color ? Like, admin and all ? I'll do it
 
-- RANDOM COMMANDS
 
concommand.Add( "lix_lesp_rotate1", function()
        LocalPlayer():SetEyeAngles( LocalPlayer():EyeAngles() + Angle( 0, 180, 0 ) )
end )
 
concommand.Add( "lix_lesp_rotate2", function()
        LocalPlayer():SetEyeAngles( LocalPlayer():EyeAngles() + Angle( -2 * LocalPlayer():EyeAngles().p, 180, 0 ) )
        RunConsoleCommand( "+jump" )
        timer.Simple( 0.2, RunConsoleCommand, "-jump" )
end )
 
concommand.Add( "lix_lesp_rotate3", function()
        RunConsoleCommand( "gm_spawn", "models/props_lab/lockerdoorleft.mdl" )
        RunConsoleCommand( "+attack" )
        timer.Simple( 0.2, function()
                LocalPlayer():SetEyeAngles( LocalPlayer():EyeAngles() + Angle( -2 * LocalPlayer():EyeAngles().p, 180, 0 ) )
                RunConsoleCommand( "+jump" )
                timer.Simple( 0.2, RunConsoleCommand, "-jump" )
                timer.Simple( 0.2, function()
                        RunConsoleCommand( "gmod_undo" )
                        RunConsoleCommand( "-attack" )
                end )
        end )
end )
 
concommand.Add( "lix_lesp_togglecommand", function( ply, com, args )
        if !args[1] then print( "No argument specified. Use attack instead of +attack." ) end
        if !LESPToggleCommands[ args[1] ] then LESPToggleCommands[ args[1] ] = false end
        if !LESPToggleCommands[ args[1] ] then
                RunConsoleCommand( "+" .. args[1] )
        else
                RunConsoleCommand( "-" .. args[1] )
        end
        LESPToggleCommands[ args[1] ] = !LESPToggleCommands[ args[1] ]
end )
 
-- MENU
 
local LESPMenuFrame
local function LESPMenu()
        gui.EnableScreenClicker( true )
       
        if !LESPMenuFrame then
                LESPMenuFrame = vgui.Create( "DFrame" )
                LESPMenuFrame:SetSize( 300, 400 )
                LESPMenuFrame:Center()
                LESPMenuFrame:ShowCloseButton( false )
                LESPMenuFrame:SetDraggable( false )
                LESPMenuFrame:SetTitle( "" )
                LESPMenuFrame.Paint = function() end
               
                local Sheet = vgui.Create( "DPropertySheet", LESPMenuFrame )
                Sheet:SetPos( 0, 0 )
                Sheet:SetSize( 300, 400 )
               
                -- LESP Config
               
                local Tab = vgui.Create( "DPanelList" )
                Tab:SetSpacing( 5 )
                Tab:SetPadding( 5 )
               
                local Control = vgui.Create( "DCheckBoxLabel" )
                Control:SetText( "Enabled" )
                Control:SetConVar( "lix_lesp_on" )
                Tab:AddItem( Control )
               
                local Control = vgui.Create( "DCheckBoxLabel" )
                Control:SetText( "Show Health" )
                Control:SetConVar( "lix_lesp_health" )
                Tab:AddItem( Control )
               
                local Control = vgui.Create( "DCheckBoxLabel" )
                Control:SetText( "Show Weapon" )
                Control:SetConVar( "lix_lesp_weapon" )
                Tab:AddItem( Control )
               
                local Control = vgui.Create( "DCheckBoxLabel" )
                Control:SetText( "Show Distance" )
                Control:SetConVar( "lix_lesp_distance" )
                Tab:AddItem( Control )
               
                local Control = vgui.Create( "DCheckBoxLabel" )
                Control:SetText( "Show Money" )
                Control:SetConVar( "lix_lesp_money" )
                Tab:AddItem( Control )
               
                local Control = vgui.Create( "DCheckBoxLabel" )
                Control:SetText( "Show Health" )
                Control:SetConVar( "lix_lesp_health" )
                Tab:AddItem( Control )
               
                local Objects = vgui.Create( "DListView" )
                Objects:AddColumn( "Targets" )
                Objects:SetSize( 50, 100 )
                Objects:SetMultiSelect( false )
                function Objects:OnClickLine( line )
                        line:SetSelected( true )
                        for k, v in pairs( LESPObjects ) do
                                if v == line:GetValue( 1 ) then
                                        table.remove( LESPObjects, k )
                                end
                        end
                        RunConsoleCommand( "lix_lesp_objects", table.concat( LESPObjects, "|" ) )
                        print( Objects:GetSelectedLine() )
                        Objects:RemoveLine( Objects:GetSelectedLine() )
                end
                Tab:AddItem( Objects )
               
                for _, v in pairs( LESPObjects ) do
                        if v ~= "" then
                                Objects:AddLine( v )
                        end
                end
               
                local Control = vgui.Create( "DButton" )
                Control:SetText( "Add" )
                Control.DoClick = function()
                        Derma_StringRequest( "LESP", "Name of entity to add:", "", function( txt )
                                table.insert( LESPObjects, txt )
                                RunConsoleCommand( "lix_lesp_objects", table.concat( LESPObjects, "|" ) )
                                Objects:AddLine( txt )
                        end )
                end
                Tab:AddItem( Control )
               
                local Control = vgui.Create( "DButton" )
                Control:SetText( "Add Looking at" )
                Control.DoClick = function()
                        if LocalPlayer():GetEyeTrace().Hit and LocalPlayer():GetEyeTrace().Entity:IsValid() then
                                table.insert( LESPObjects, LocalPlayer():GetEyeTrace().Entity:GetClass() )
                                RunConsoleCommand( "lix_lesp_objects", table.concat( LESPObjects, "|" ) )
                                Objects:AddLine( LocalPlayer():GetEyeTrace().Entity:GetClass() )
                        end
                end
                Tab:AddItem( Control )
               
                local Control = vgui.Create( "DButton" )
                Control:SetText( "Remove All" )
                Control.DoClick = function()
                        Derma_Query( "Do you want to remove all Entites?", "LESP",
                                "Yes", function()
                                        for i, v in pairs( string.Explode( "|", LESPObjects:GetString() ) ) do
                                                Objects:RemoveLine( i )
                                        end
                                        LESPObjects = {}
                                        RunConsoleCommand( "lix_lesp_objects", "" )
                                end,
                                "No", function() end )
                end
                Tab:AddItem( Control )
               
                local Control = vgui.Create( "DCheckBoxLabel" )
                Control:SetText( "Aimdots" )
                Control:SetConVar( "lix_lesp_aimdot" )
                Tab:AddItem( Control )
               
                local Control = vgui.Create( "DCheckBoxLabel" )
                Control:SetText( "Aimdot Filtering" )
                Control:SetConVar( "lix_lesp_aimdotfilter" )
                Tab:AddItem( Control )
               
                Sheet:AddSheet( "LESP", Tab, "gui/silkicons/group", false, false, "LESP Configuration" )
               
                -- Mirror Config
               
                local Tab = vgui.Create( "DPanelList" )
                Tab:SetSpacing( 5 )
                Tab:SetPadding( 5 )
               
                local Control = vgui.Create( "DCheckBoxLabel" )
                Control:SetText( "Mirror Enabled" )
                Control:SetConVar( "lix_lesp_mirror" )
                Tab:AddItem( Control )
               
                local Control = vgui.Create( "DButton" )
                Control:SetText( "Enable Mirror Placement" )
                Control.DoClick = function()
                        local PlaceFrame = vgui.Create( "DFrame" )
                        RunConsoleCommand( "lix_lesp_mirror", 0 )
                        PlaceFrame:SetSize( LESPMirrorw:GetInt(), LESPMirrorh:GetInt() )
                        PlaceFrame:SetPos( LESPMirrorx:GetInt(), LESPMirrory:GetInt() )
                        PlaceFrame:ShowCloseButton( false )
                        PlaceFrame:SetSizable( true )
                        PlaceFrame:SetTitle( "Move Da Mirror" )
                       
                        local PlaceButton = vgui.Create( "DButton", PlaceFrame )
                        PlaceButton:SetSize( 100, 40 )
                        PlaceButton:SetPos( 5, 30 )
                        PlaceButton:SetText( "Bitch Muddafuckin Stay Here" )
                        PlaceButton.DoClick = function()
                                local x, y = PlaceFrame:GetPos()
                                local w, h = PlaceFrame:GetSize()
                                RunConsoleCommand( "lix_lesp_mirrorx", x )
                                RunConsoleCommand( "lix_lesp_mirrory", y )
                                RunConsoleCommand( "lix_lesp_mirrorw", w )
                                RunConsoleCommand( "lix_lesp_mirrorh", h )
                                RunConsoleCommand( "lix_lesp_mirror", 1 )
                                PlaceFrame:Close()
                        end
                        PlaceButton.Think = function()
                                local x, y = PlaceFrame:GetPos()
                                local w, h = PlaceFrame:GetSize()
                                PlaceButton:SetSize( w - 10, h - 32 )
                                PlaceButton:SetPos( 5, 27 )
                        end
                end
                Tab:AddItem( Control )
               
                local Control = vgui.Create( "DNumSlider" )
                Control:SetText( "Pitch" )
                Control:SetMin( -2 )
                Control:SetMax( 359 )
                Control:SetDecimals( 0 )
                Control:SetConVar( "lix_lesp_mirrorpitch" )
                Tab:AddItem( Control )
               
                local Control = vgui.Create( "DNumSlider" )
                Control:SetText( "Yaw" )
                Control:SetMin( -2 )
                Control:SetMax( 359 )
                Control:SetDecimals( 0 )
                Control:SetConVar( "lix_lesp_mirroryaw" )
                Tab:AddItem( Control )
               
                local Control = vgui.Create( "DNumSlider" )
                Control:SetText( "Roll" )
                Control:SetMin( -2 )
                Control:SetMax( 359 )
                Control:SetDecimals( 0 )
                Control:SetConVar( "lix_lesp_mirrorroll" )
                Tab:AddItem( Control )
               
                local Control = vgui.Create( "DLabel" )
                Control:SetText( " " )
                Tab:AddItem( Control )
               
                local Control = vgui.Create( "DCheckBoxLabel" )
                Control:SetText( "Radar Enabled" )
                Control:SetConVar( "lix_lesp_radar" )
                Tab:AddItem( Control )
               
                local Control = vgui.Create( "DButton" )
                Control:SetText( "Enable Radar Placement" )
                Control.DoClick = function()
                        local PlaceFrame = vgui.Create( "DFrame" )
                        RunConsoleCommand( "lix_lesp_radar", 0 )
                        PlaceFrame:SetSize( LESPRadarw:GetInt(), LESPRadarh:GetInt() )
                        PlaceFrame:SetPos( LESPRadarx:GetInt(), LESPRadary:GetInt() )
                        PlaceFrame:ShowCloseButton( false )
                        PlaceFrame:SetSizable( true )
                        PlaceFrame:SetTitle( "Radar Placement" )
                       
                        local PlaceButton = vgui.Create( "DButton", PlaceFrame )
                        PlaceButton:SetSize( 100, 40 )
                        PlaceButton:SetPos( 5, 30 )
                        PlaceButton:SetText( "CONFIRM" )
                        PlaceButton.DoClick = function()
                                local x, y = PlaceFrame:GetPos()
                                local w, h = PlaceFrame:GetSize()
                                RunConsoleCommand( "lix_lesp_radarx", x )
                                RunConsoleCommand( "lix_lesp_radary", y )
                                RunConsoleCommand( "lix_lesp_radarw", w )
                                RunConsoleCommand( "lix_lesp_radarh", h )
                                RunConsoleCommand( "lix_lesp_radar", 1 )
                                PlaceFrame:Close()
                        end
                        PlaceButton.Think = function()
                                local x, y = PlaceFrame:GetPos()
                                local w, h = PlaceFrame:GetSize()
                                PlaceButton:SetSize( w - 10, h - 32 )
                                PlaceButton:SetPos( 5, 27 )
                        end
                end
                Tab:AddItem( Control )
               
                local Control = vgui.Create( "DNumSlider" )
                Control:SetText( "FOV" )
                Control:SetMin( 0 )
                Control:SetMax( 3000 )
                Control:SetDecimals( 0 )
                Control:SetConVar( "lix_lesp_radarfov" )
                Tab:AddItem( Control )
               
                local Control = vgui.Create( "DCheckBoxLabel" )
                Control:SetText( "Auto Adjust" )
                Control:SetConVar( "lix_lesp_radarauto" )
                Tab:AddItem( Control )
               
                Sheet:AddSheet( "Mirror", Tab, "gui/silkicons/magnifier", false, false, "Mirror and Radar Configuration" )
               
                -- VOTE
               
                local Tab = vgui.Create( "DPanelList" )
                Tab:SetSpacing( 5 )
                Tab:SetPadding( 5 )
               
                local Control = vgui.Create( "DButton" )
                Control:SetText( "Start Yes / No Vote" )
                Control.DoClick = function()
                        Derma_StringRequest( "LESP - Yes / No Vote", "Text to dispaly as vote:", "", function( txt )
                                RunConsoleCommand( "lix_lesp_votestartyn", txt )
                        end )
                end
                Tab:AddItem( Control )
               
                local Control = vgui.Create( "DButton" )
                Control:SetText( "Start Open Vote" )
                Control.DoClick = function()
                        Derma_StringRequest( "LESP - Open Vote", "Text to dispaly as vote:", "", function( txt )
                                RunConsoleCommand( "lix_lesp_votestartopen", txt )
                        end )
                end
                Tab:AddItem( Control )
               
                local Control = vgui.Create( "DLabel" )
                Control:SetText( " " )
                Tab:AddItem( Control )
               
                local Control = vgui.Create( "DNumSlider" )
                Control:SetText( "Vote Time" )
                Control:SetMin( 0 )
                Control:SetMax( 300 )
                Control:SetDecimals( 0 )
                Control:SetConVar( "lix_lesp_votetime" )
                Tab:AddItem( Control )
               
                local Control = vgui.Create( "DButton" )
                Control:SetText( "Stop Vote" )
                Control.DoClick = function()
                        RunConsoleCommand( "lix_lesp_votestop" )
                end
                Tab:AddItem( Control )
               
                Sheet:AddSheet( "Vote", Tab, "gui/silkicons/sound", false, false, "Voting System" )
               
                -- HOOKS
               
                local Tab = vgui.Create( "DPanelList" )
                Tab:SetSpacing( 5 )
                Tab:SetPadding( 5 )
                Tab:EnableVerticalScrollbar( true )
               
                local HooksTable = {}
               
                local function CreateHooks()
               
                        local Var = hook.GetTable()
                        table.sort( Var, function( a, b ) return a < b end )
                       
                        for HookName, HookFunctions in pairs( Var ) do
                                HooksTable[ HookName ] = vgui.Create( "DCollapsibleCategory" )
                                HooksTable[ HookName ]:SetExpanded( 0 )
                                HooksTable[ HookName ]:SetLabel( HookName )
                               
                                HooksTable[ HookName ].Contents = vgui.Create( "DPanelList" )
                                HooksTable[ HookName ].Contents:SetAutoSize( true )
                                HooksTable[ HookName ].Contents:SetSpacing( 5 )
                                HooksTable[ HookName ].Contents:SetPadding( 5 )
                                HooksTable[ HookName ].Contents:EnableHorizontal( false )
                                HooksTable[ HookName ].Contents:EnableVerticalScrollbar( true )
                               
                                HooksTable[ HookName ]:SetContents( HooksTable[ HookName ].Contents )
                               
                                Tab:AddItem( HooksTable[ HookName ] )
                               
                                local Var2 = HookFunctions
                                table.sort( Var2, function( a, b ) return a < b end )
                               
                                for HookID, HookFunction in pairs( Var2 ) do
                                        HooksTable[ HookName ].Contents[ HookID ] = vgui.Create( "DButton" )
                                        HooksTable[ HookName ].Contents[ HookID ]:SetText( HookID )
                                        HooksTable[ HookName ].Contents[ HookID ].DoClick = function()
                                                local Menu = DermaMenu()
                                                Menu:AddOption( "Call Hook", function() hook.Call( HookName ) end )
                                                Menu:AddOption( "Remove Hook", function() hook.Remove( HookName, HookID ) HooksTable[ HookName ].Contents[ HookID ]:Remove() end )
                                                Menu:Open()
                                        end
                                        HooksTable[ HookName ].Contents:AddItem( HooksTable[ HookName ].Contents[ HookID ] )
                                end
                        end
                end
               
                local Control = vgui.Create( "DButton" )
                Control:SetText( "Refresh" )
                Control.DoClick = function()
                        for k, v in pairs( HooksTable ) do
                                v:Remove()
                        end
                        CreateHooks()
                end
                Tab:AddItem( Control )
               
                CreateHooks()
               
                Sheet:AddSheet( "Hooks", Tab, "gui/silkicons/anchor", false, false, "Manage active Lua Hooks" )
               
                -- OTHER
               
                local Tab = vgui.Create( "DPanelList" )
                Tab:SetSpacing( 5 )
                Tab:SetPadding( 5 )
                Tab:EnableVerticalScrollbar( true )
               
                local Control = vgui.Create( "DButton" )
                Control:SetText( "Light" )
                Control.DoClick = function()
                        RunConsoleCommand( "lix_lesp_light" )
                end
                Tab:AddItem( Control )
               
                local Control = vgui.Create( "DButton" )
                Control:SetText( "Aura Light" )
                Control.DoClick = function()
                        RunConsoleCommand( "lix_lesp_aura" )
                end
                Tab:AddItem( Control )
               
                local Control = vgui.Create( "DLabel" )
                Control:SetText( " " )
                Tab:AddItem( Control )
               
                local Control = vgui.Create( "DButton" )
                Control:SetText( "Add Detector" )
                Control.DoClick = function()
                        RunConsoleCommand( "lix_lesp_detectadd" )
                end
                Tab:AddItem( Control )
               
                local Control = vgui.Create( "DButton" )
                Control:SetText( "Remove Detector" )
                Control.DoClick = function()
                        RunConsoleCommand( "lix_lesp_detectremove" )
                end
                Tab:AddItem( Control )
               
                local Control = vgui.Create( "DNumSlider" )
                Control:SetText( "Detector Threshold" )
                Control:SetMin( 0 )
                Control:SetMax( 2000 )
                Control:SetDecimals( 0 )
                Control:SetConVar( "lix_lesp_detectthresh" )
                Tab:AddItem( Control )
               
                local Control = vgui.Create( "DCheckBoxLabel" )
                Control:SetText( "Show Detectors" )
                Control:SetConVar( "lix_lesp_detectshow" )
                Tab:AddItem( Control )
               
                local Control = vgui.Create( "DCheckBoxLabel" )
                Control:SetText( "Show Thresholds" )
                Control:SetConVar( "lix_lesp_detectshowrad" )
                Tab:AddItem( Control )
               
                local Control = vgui.Create( "DCheckBoxLabel" )
                Control:SetText( "Trace Detection" )
                Control:SetConVar( "lix_lesp_detecttrace" )
                Tab:AddItem( Control )
               
                local Control = vgui.Create( "DLabel" )
                Control:SetText( " " )
                Tab:AddItem( Control )
               
                local Control = vgui.Create( "DCheckBoxLabel" )
                Control:SetText( "Reverse Chat" )
                Control:SetConVar( "lix_lesp_chatreverse" )
                Tab:AddItem( Control )
               
                local Control = vgui.Create( "DCheckBoxLabel" )
                Control:SetText( "Cambridge Chat" )
                Control:SetConVar( "lix_lesp_chatcambridge" )
                Tab:AddItem( Control )
               
                local Control = vgui.Create( "DLabel" )
                Control:SetText( " " )
                Tab:AddItem( Control )
               
                local Control = vgui.Create( "DButton" )
                Control:SetText( "Reload Scripts" )
                Control.DoClick = function()
                        if LESPMenuFrame then
                                LESPMenuFrame:Close()
                                gui.EnableScreenClicker( false )
                        end
                        include( "autorun/client/LESP.lua" )
                end
                Tab:AddItem( Control )
               
                Sheet:AddSheet( "Misc", Tab, "gui/silkicons/plugin", false, false, "Other Settings" )
        else
                LESPMenuFrame:SetVisible( true )
        end
end
 
local function LESPMenuOff()
        if LESPMenuFrame then
                LESPMenuFrame:SetVisible( false )
                gui.EnableScreenClicker( false )
        end
end
 
concommand.Add( "+lix_lesp_menu", LESPMenu )
concommand.Add( "-lix_lesp_menu", LESPMenuOff )
 
concommand.Add( "lix_lesp_reload", function() include( "autorun/client/LESP.lua" ) end )