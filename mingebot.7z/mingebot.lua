--[[
	lua/Hacks/cl_mingebot.lua
	SimpleIsTheBest | (STEAM_0:1:60333045)
	===DStream===
]]

if ( SERVER ) then return end


require("cvar3")

print('[MingeBot]--------------------------------------		')
print('[MingeBot] Loaded Anti-Cheat							')
print('[MingeBot] Loaded Modules							')
print('[MingeBot] Loaded Anti-VAC							')
print('[MingeBot] Open Menu With Minge_Menu					')
print('[MingeBot] Use speedhack With +Minge_speed			')
print('[MingeBot]----------------------------------------	')

HT = GetConVar('host_timescale')
SC = GetConVar('sv_cheats')
WF = GetConVar('mat_wireframe')
GC = GetConVar('gl_clear')
DS = GetConVar('r_drawskybox')
TD = GetConVar('r_3dsky')

surface.CreateFont("ESPFont_Small",			{font = "Default", size = 12, weight = 200, antialias = 0})
surface.CreateFont("Logo",					{font = "ScoreboardText", size = 17, weight = 400, antialias = 0})
surface.CreateFont("Logo_Small",			{font = "Default", size = 12, weight = 200, antialias = 0})
surface.CreateFont("Logo",					{font = "akbar", size = 21, weight = 400, antialias = 0})

local Tb  = table.Copy( file )
local Tbs = table.Copy( string )
local _G                    = table.Copy(_G)
local CreateMaterial 		= _G.CreateMaterial
local print 				= _G.print
local old_filecdir 			= file.CreateDir;
local old_filedel 			= file.Delete;
local old_fileexist 		= file.Exists;
local old_fileexistex 		= file.ExistsEx;
local old_filefind 			= file.Find;
local old_filefinddir 		= file.FindDir;
local old_filefindil 		= file.FindInLua;
local old_fileisdir			= file.IsDir;
local old_fileread 			= file.Read;
local old_filerename 		= file.Rename;
local old_filesize 			= file.Size;
local old_filetfind			= file.TFind;
local old_filetime 			= file.Time;
local old_filewrite 		= file.Write;
local old_dbginfo 			= debug.getinfo;
local old_dbginfo 			= debug.getupvalue;
local old_cve 				= ConVarExists;
local old_gcv 				= GetConVar;
local old_gcvn 				= GetConVarNumber;
local old_gcvs 				= GetConVarString;
local old_rcc 				= RunConsoleCommand;
local old_hookadd			= hook.Add;
local old_hookrem 			= hook.Remove;
local old_ccadd				= concommand.Add;
local old_ccrem 			= concommand.Remove;
local old_cvaracc 			= cvars.AddChangeCallback;
local old_cvargcvc 			= cvars.GetConVarCallbacks;
local old_cvarchange 		= cvars.OnConVarChanged;
local old_require			= require;
local old_eccommand 		= engineConsoleCommand;

local concommand = concommand
local cvars = cvars
local debug = debug
local ents = ents
local file = file
local hook = hook
local math = math
local spawnmenu = spawnmenu
local string = string
local surface = surface
local table = table
local timer = timer
local util = util
local vgui = vgui

local Angle = Angle
local CreateClientConVar = CreateClientConVar
local CurTime = CurTime
local ErrorNoHalt = ErrorNoHalt
local FrameTime = FrameTime
local GetConVarString = GetConVarString
local GetViewEntity = GetViewEntity
local include = include
local ipairs = ipairs
local LocalPlayer = LocalPlayer
local pairs = pairs
local pcall = pcall
local print = print
local RunConsoleCommand = RunConsoleCommand
local ScrH = ScrH
local ScrW = ScrW
local tonumber = tonumber
local type = type
local unpack = unpack
local ValidEntity = ValidEntity
local Vector = Vector


local Minge 		= {}
local Uw 			= {}
local Mw 			= {}
local Colors 		= {}
Red					= Color( 255, 0, 0, 255 );
Green				= Color( 0, 255, 0, 255 );
Blue				= Color( 0, 0, 255, 255 );
Orange				= Color( 255, 100, 0, 255 );
White				= Color( 255, 255, 255, 255 );
Black				= Color( 0, 0, 0, 255 );

-- Aimbot
local CLTrigger 		= CreateClientConVar( "minge_aim_trigger", 							1, true, false )
local CLNoSpread		= CreateClientConVar( "minge_aim_nospread", 						1, true, false )
local CLNoRecoil		= CreateClientConVar( "minge_aim_norecoil", 						1, true, false )
local CLSilentAim		= CreateClientConVar( "minge_aim_silentaim", 						1, true, false )
local CLSilentAim		= CreateClientConVar( "minge_aim_removeaa", 						0, true, false )
		
-- ESP				
local CLESP				= CreateClientConVar( 'minge_esp_info', 							1, true, false)
local CLESP				= CreateClientConVar( 'minge_esp_destance', 						1000, true, false)
local CLESP				= CreateClientConVar( 'minge_esp_box', 								1, true, false)
local CLChams			= CreateClientConVar( 'minge_esp_chams', 							1, true, false)
local CLChams			= CreateClientConVar( 'minge_esp_chams_material', 					"Wireframe", true, false)
local CLChams			= CreateClientConVar( 'minge_esp_tracer', 							1, true, false)
local CLBox				= CreateClientConVar( 'minge_esp_playerbox', 						1, true, false)
local CLSkeleton		= CreateClientConVar( 'minge_esp_skeleton', 						1, true, false)
local CLSkeleton		= CreateClientConVar( 'minge_esp_printers', 						1, true, false)
local CLSkeleton		= CreateClientConVar( 'minge_esp_money', 							1, true, false)
local CLSkeleton		= CreateClientConVar( 'minge_esp_shipment', 						1, true, false)
local CLSkeleton		= CreateClientConVar( 'minge_esp_weapons', 							1, true, false)
local CLCrosshair       = CreateClientConVar( 'minge_esp_crosshair', 						1, true, false)

-- Misc
local CLHop		       	= CreateClientConVar( 'minge_misc_bhop', 							1, true, false)
local CLSpam       		= CreateClientConVar( 'minge_misc_spamchat', 						1, true, false)
local CLSpamMsg       	= CreateClientConVar( 'minge_misc_spamchat_msg', 					1, true, false)
local CLRpGod      		= CreateClientConVar( 'minge_misc_rpgod', 							1, true, false)
local CLFLash       	= CreateClientConVar( 'minge_misc_flashlightspam', 					1, true, false)
	








/////////////////
// **Aimbot** //
///////////////
--No Recoil--
hook.Add( "Think", "No Recoil", function()
if GetConVarNumber( "minge_aim_norecoil" ) >= 1 then
if LocalPlayer():GetActiveWeapon().Primary then
LocalPlayer():GetActiveWeapon().Primary.Recoil = 0
                end
        end
end )

-- Anti aim --
 
--Aimbot--
// ### TEMPORARY AIMBOT CODE ### //
// Yes I know this aimbot is shit,//
//I will replace it when I get the time//
 
do
	local hooks = {}
	local created = {}
	local function CallHook(self, name, args)
		if !hooks[name] then return end
		for funcName, _ in pairs(hooks[name]) do
			local func = self[funcName]
			if func then
				local ok, err = pcall(func, self, unpack(args or {}))
				if !ok then
					ErrorNoHalt(err .. "\n")
				elseif err then
					return err
				end
			end
		end
	end
	local function RandomName()
		local random = ""
		for i = 1, math.random(4, 10) do
			local c = math.random(65, 116)
			if c >= 91 && c <= 96 then c = c + 6 end
			random = random .. string.char(c)
		end
		return random
	end
	local function AddHook(self, name, funcName)
		// If we haven't got a hook for this yet, make one with a random name and store it.
		// This is so anti-cheats can't detect by hook name, and so we can remove them later.
		if !created[name] then
			local random = RandomName()
			hook.Add(name, random, function(...) return CallHook(self, name, {...}) end)
			created[name] = random
		end
		
		hooks[name] = hooks[name] or {}
		hooks[name][funcName] = true
	end
	
	local cvarhooks = {}
	local function GetCallbackTable(convar)
		local callbacks = cvars.GetConVarCallbacks(convar)
		if !callbacks then
			cvars.AddChangeCallback(convar, function() end)
			callbacks = cvars.GetConVarCallbacks(convar)
		end
		return callbacks
	end
			
	local function AddCVarHook(self, convar, funcName, ...)
		local hookName = "CVar_" .. convar
		if !cvarhooks[convar] then
			local random = RandomName()
			
			local callbacks = GetCallbackTable(convar)
			callbacks[random] = function(...)
				CallHook(self, hookName, {...})
			end
			
			cvarhooks[convar] = random
		end
		AddHook(self, hookName, funcName)
	end
	
	// Don't let other scripts remove our hooks.
	local oldRemove = hook.Remove
	function hook.Remove(name, unique)
		if created[name] == unique then return end
		oldRemove(name, unique)
	end
	
	// Removes all hooks, useful if reloading the script.
	local function RemoveHooks()
		for hookName, unique in pairs(created) do
			oldRemove(hookName, unique)
		end
		for convar, unique in pairs(cvarhooks) do
			local callbacks = GetCallbackTable(convar)
			callbacks[unique] = nil
		end
	end
	
	// Add copies the script can access.
	Minge.AddHook = AddHook
	Minge.AddCVarHook = AddCVarHook
	Minge.CallHook = CallHook
	Minge.RemoveHooks = RemoveHooks
end

concommand.Add("Minge_reload", function()
	Minge:CallHook("Shutdown")
	print("Removing hooks...")
	Minge:RemoveHooks()
	
	local info = debug.getinfo(1, "S")
	if info && info.short_src then
		print("Reloading (" .. info.short_src .. ")...")
		include(info.short_src)
	else
		print("Cannot find AutoAim file, reload manually.")
	end
end)
print("AutoAim loaded.")

// ##################################################
// MetaTables
// ##################################################

local function GetMeta(name)
	return table.Copy(_R[name] or {})
end

local AngM = GetMeta("Angle")
local CmdM = GetMeta("CUserCmd")
local EntM = GetMeta("Entity")
local PlyM = GetMeta("Player")
local VecM = GetMeta("Vector")

// ##################################################
// Settings
// ##################################################

do
	local settings = {}
	local function SettingVar(self, name)
		return (self.SettingPrefix or "") .. string.lower(name)
	end
	
	local function RandomName()
		local random = ""
		for i = 1, math.random(4, 10) do
			local c = math.random(65, 116)
			if c >= 91 && c <= 96 then c = c + 6 end
			random = random .. string.char(c)
		end
		return random
	end
	
	local function SetSetting(name, _, new)
		if !settings[name] then return end
		local info = settings[name]
		
		if info.Type == "number" then
			new = tonumber(new)
		elseif info.Type == "boolean" then
			new = (tonumber(new) or 0) > 0
		end
		
		info.Value = new
	end
	
	local function CreateSetting(self, name, desc, default, misc)
		local cvar = SettingVar(self, name)
		local info = {Name = name, Desc = desc, CVar = cvar, Type = type(default), Value = default}
		
		for k, v in pairs(misc or {}) do
			if !info[k] then info[k] = v end
		end
		
		// Convert default from boolean to number.
		if type(default) == "boolean" then
			default = default and 1 or 0
		end
		
		if !settings[cvar] then
			local tab = cvars.GetConVarCallbacks(cvar)
			if !tab then
				cvars.AddChangeCallback(cvar, function() end)
				tab = cvars.GetConVarCallbacks(cvar)
			end
			
			while true do
				local name = RandomName()
				if !tab[name] then
					tab[name] = SetSetting
					info.Callback = name
					break
				end
			end
		end
		
		settings[cvar] = info
		settings[#settings + 1] = info
		
		// Create the convar.
		CreateClientConVar(cvar, default, (info.Save != false), false)
		SetSetting(cvar, _, GetConVarString(cvar))
	end
	local function GetSetting(self, name)
		local cvar = SettingVar(self, name)
		if !settings[cvar] then return end
		return settings[cvar].Value
	end
	local function Shutdown()
		print("Removing settings callbacks...")
		for _, info in ipairs(settings) do
			if info.CVar && info.Callback then
				local tab = cvars.GetConVarCallbacks(info.CVar)
				if tab then
					tab[info.Callback] = nil
				end
			end
		end
	end
	local function SettingsList()
		return table.Copy(settings)
	end
	local function BuildMenu(self, panel)
		for _, info in ipairs(settings) do
			if info.Show != false then
				if info.MultiChoice then
					local m = panel:MultiChoice(info.Desc or info.CVar, info.CVar)
					for k, v in pairs(info.MultiChoice) do
						m:AddChoice(k, v)
					end
				elseif info.Type == "number" then
					panel:NumSlider(info.Desc or info.CVar, info.CVar, info.Min or -1, info.Max or -1, info.Places or 0)
				elseif info.Type == "boolean" then
					panel:CheckBox(info.Desc or info.CVar, info.CVar)
				elseif info.Type == "string" then
					panel:TextEntry(info.Desc or info.CVar, info.CVar)
				end
			end
		end
	end
	
	Minge.SettingPrefix = "Minge_"
	Minge.CreateSetting = CreateSetting
	Minge.Setting = GetSetting
	Minge.SettingsList = SettingsList
	Minge.BuildMenu = BuildMenu
	
	Minge.SettingsShutdown = Shutdown
	Minge:AddHook("Shutdown", "SettingsShutdown")
end


// ##################################################
// Targetting - Positions
// ##################################################

Minge.ModelTarget = {}
function Minge:SetModelTarget(model, targ)
	self.ModelTarget[model] = targ
end
function Minge:BaseTargetPosition(ent)
	// The eye attachment is a lot more stable than bones for players.
	if type(ent) == "Player" then
		local head = EntM["LookupAttachment"](ent, "eyes")
		if head then
			local pos = EntM["GetAttachment"](ent, head)
			if pos then
				return pos.Pos - (AngM["Forward"](pos.Ang) * 2)
			end
		end
	end
	
	// Check if the model has a special target assigned to it.
	local special = self.ModelTarget[string.lower(EntM["GetModel"](ent) or "")]
	if special then
		// It's a string - look for a bone.
		if type(special) == "string" then
			local bone = EntM["LookupBone"](ent, special)
			if bone then
				local pos = EntM["GetBonePosition"](ent, bone)
				if pos then
					return pos
				end
			end
		// It's a Vector - return a relative position.
		elseif type(special) == "Vector" then
			return EntM["LocalToWorld"](ent, special)
		// It's a function - do something fancy!
		elseif type(special) == "function" then
			local pos = pcall(special, ent)
			if pos then return pos end
		end
	end

	// Try and use the head bone, found on all of the player + human models.
	local bone = "ValveBiped.Bip01_Head1"
	local head = EntM["LookupBone"](ent, bone)
	if head then
		local pos = EntM["GetBonePosition"](ent, head)
		if pos then
			return pos
		end
	end

	// Give up and return the center of the entity.
	return EntM["LocalToWorld"](ent, EntM["OBBCenter"](ent))
end
function Minge:TargetPosition(ent)
	local targetPos = self:BaseTargetPosition(ent)
	
	local ply = LocalPlayer()
	if ValidEntity(ply) then
		targetPos = self:CallHook("TargetPrediction", {ply, ent, targetPos}) or targetPos
	end
	
	return targetPos
end

Minge:SetModelTarget("models/crow.mdl", Vector(0, 0, 5))						// Crow.
Minge:SetModelTarget("models/pigeon.mdl", Vector(0, 0, 5)) 					// Pigeon.
Minge:SetModelTarget("models/seagull.mdl", Vector(0, 0, 6)) 					// Seagull.
Minge:SetModelTarget("models/combine_scanner.mdl", "Scanner.Body") 				// Scanner.
Minge:SetModelTarget("models/hunter.mdl", "MiniStrider.body_joint") 			// Hunter.
Minge:SetModelTarget("models/combine_turrets/floor_turret.mdl", "Barrel") 		// Turret.
Minge:SetModelTarget("models/dog.mdl", "Dog_Model.Eye") 						// Dog.
Minge:SetModelTarget("models/vortigaunt.mdl", "ValveBiped.Head") 				// Vortigaunt.
Minge:SetModelTarget("models/antlion.mdl", "Antlion.Body_Bone") 					// Antlion.
Minge:SetModelTarget("models/antlion_guard.mdl", "Antlion_Guard.Body") 			// Antlion guard.
Minge:SetModelTarget("models/antlion_worker.mdl", "Antlion.Head_Bone") 			// Antlion worker.
Minge:SetModelTarget("models/zombie/fast_torso.mdl", "ValveBiped.HC_BodyCube") 	// Fast zombie torso.
Minge:SetModelTarget("models/zombie/fast.mdl", "ValveBiped.HC_BodyCube") 		// Fast zombie.
Minge:SetModelTarget("models/headcrabclassic.mdl", "HeadcrabClassic.SpineControl") // Normal headcrab.
Minge:SetModelTarget("models/headcrabblack.mdl", "HCBlack.body") 				// Poison headcrab.
Minge:SetModelTarget("models/headcrab.mdl", "HCFast.body") 						// Fast headcrab.
Minge:SetModelTarget("models/zombie/poison.mdl", "ValveBiped.Headcrab_Cube1")	 // Poison zombie.
Minge:SetModelTarget("models/zombie/classic.mdl", "ValveBiped.HC_Body_Bone")	 // Zombie.
Minge:SetModelTarget("models/zombie/classic_torso.mdl", "ValveBiped.HC_Body_Bone") // Zombie torso.
Minge:SetModelTarget("models/zombie/zombie_soldier.mdl", "ValveBiped.HC_Body_Bone") // Zombine.
Minge:SetModelTarget("models/combine_strider.mdl", "Combine_Strider.Body_Bone") // Strider.
Minge:SetModelTarget("models/combine_dropship.mdl", "D_ship.Spine1") 			// Combine dropship.
Minge:SetModelTarget("models/combine_helicopter.mdl", "Chopper.Body") 			// Combine helicopter.
Minge:SetModelTarget("models/gunship.mdl", "Gunship.Body")						// Combine gunship.
Minge:SetModelTarget("models/lamarr.mdl", "HeadcrabClassic.SpineControl")		// Lamarr!
Minge:SetModelTarget("models/mortarsynth.mdl", "Root Bone")						// Mortar synth.
Minge:SetModelTarget("models/synth.mdl", "Bip02 Spine1")						// Synth.
Minge:SetModelTarget("models/vortigaunt_slave.mdl", "ValveBiped.Head")			// Vortigaunt slave.


// ##################################################
// Targetting - General
// ##################################################

Minge.NPCDeathSequences = {}
function Minge:AddNPCDeathSequence(model, sequence)
	self.NPCDeathSequences = self.NPCDeathSequences or {}
	self.NPCDeathSequences[model] = self.NPCDeathSequences[model] or {}
	if !table.HasValue(self.NPCDeathSequences[model]) then
		table.insert(self.NPCDeathSequences[model], sequence)
	end
end

Minge:AddNPCDeathSequence("models/barnacle.mdl", 4)
Minge:AddNPCDeathSequence("models/barnacle.mdl", 15)
Minge:AddNPCDeathSequence("models/antlion_guard.mdl", 44)
Minge:AddNPCDeathSequence("models/hunter.mdl", 124)
Minge:AddNPCDeathSequence("models/hunter.mdl", 125)
Minge:AddNPCDeathSequence("models/hunter.mdl", 126)
Minge:AddNPCDeathSequence("models/hunter.mdl", 127)
Minge:AddNPCDeathSequence("models/hunter.mdl", 128)

Minge:CreateSetting("friendlyfire", "Target teammates", false)
function Minge:IsValidTarget(ent)
	// We only want players/NPCs.
	local typename = type(ent)
	if typename != "NPC" && typename != "Player" then return false end

	// No invalid entities.
	if !ValidEntity(ent) then return false end

	// Go shoot yourself, emo kid.
	local ply = LocalPlayer()
	if ent == ply then return false end

	if typename == "Player" then
		if !PlyM["Alive"](ent) then return false end // Dead players FTL.
		if !self:Setting("friendlyfire") && PlyM["Team"](ent) == PlyM["Team"](ply) then return false end
		if EntM["GetMoveType"](ent) == MOVETYPE_OBSERVER then return false end // No spectators.
		if EntM["GetMoveType"](ent) == MOVETYPE_NONE then return false end
		//if pl["Team"](ent) == 1001 then return false end
	end

	if typename == "NPC" then
		if EntM["GetMoveType"](ent) == MOVETYPE_NONE then return false end // No dead NPCs.

		// No dying NPCs.
		local model = string.lower(EntM["GetModel"](ent) or "")
		if table.HasValue(self.NPCDeathSequences[model] or {}, EntM["GetSequence"](ent)) then return false end
	end
end

Minge:CreateSetting("predictblocked", "Predict blocked (time)", 0.4, {Min = 0, Max = 1})
function Minge:BaseBlocked(target, offset)
	local ply = LocalPlayer()
	if !ValidEntity(ply) then return end
	
	// Trace from the players shootpos to the position.
	local shootPos = PlyM["GetShootPos"](ply)
	local targetPos = self:TargetPosition(target)
	
	if offset then targetPos = targetPos + offset end

	local trace = util.TraceLine({start = shootPos, endpos = targetPos, filter = {ply, target}, mask = MASK_SHOT})
	local wrongAim = self:AngleBetween(PlyM["GetAimVector"](ply), VecM["GetNormal"](targetPos - shootPos)) > 2

	// If we hit something, we're "blocked".
	if trace.Hit && trace.Entity != target then
		return true, wrongAim
	end

	// It is not blocked.
	return false, wrongAim
end
function Minge:TargetBlocked(target)
	if !target then target = self:GetTarget() end
	if !target then return end
	
	local blocked, wrongAim = self:BaseBlocked(target)
	if self:Setting("predictblocked") > 0 && blocked then
		blocked = self:BaseBlocked(target, EntM["GetVelocity"](target) * self:Setting("predictblocked"))
	end
	return blocked, wrongAim
end
	

function Minge:SetTarget(ent)
	if self.Target && !ent then
		self:CallHook("TargetLost")
	elseif !self.Target && ent then
		self:CallHook("TargetGained")
	elseif self.Target && ent && self.Target != ent then
		self:CallHook("TargetChanged")
	end

	self.Target = ent
end
function Minge:GetTarget()
	if ValidEntity(self.Target) != false then
		return self.Target
	else
		return false
	end
end

Minge:CreateSetting("maxangle", "Max angle", 30, {Min = 5, Max = 90})
Minge:CreateSetting("targetblocked", "Don't check LOS", false)
Minge:CreateSetting("holdtarget", "Hold targets", false)
function Minge:FindTarget()
	if !self:Enabled() then return end

	local ply = LocalPlayer()
	if !ValidEntity(ply) then return end

	local maxAng = self:Setting("maxangle")
	local aimVec, shootPos = PlyM["GetAimVector"](ply), PlyM["GetShootPos"](ply)
	local targetBlocked = self:Setting("targetblocked")

	if self:Setting("holdtarget") then
		local target = self:GetTarget()
		if target then
			local targetPos = self:TargetPosition(target)
			local angle = self:AngleBetween(AngM["Forward"](self:GetView()), VecM["GetNormal"](targetPos - shootPos))
			local blocked = self:TargetBlocked(target)
			if angle <= maxAng && (!blocked || targetBlocked) then return end
		end
	end

	// Filter out targets.
	local targets = ents.GetAll()
	for i, ent in pairs(targets) do
		if self:IsValidTarget(ent) == false then
			targets[i] = nil
		end
	end

	local closestTarget, lowestAngle = _, maxAng
	for _, target in pairs(targets) do
		if targetBlocked || !self:TargetBlocked(target) then
			local targetPos = self:TargetPosition(target)
			local angle = self:AngleBetween(AngM["Forward"](self:GetView()), VecM["GetNormal"](targetPos - shootPos))

			if angle < lowestAngle then
				lowestAngle = angle
				closestTarget = target
			end
		end
	end

	self:SetTarget(closestTarget)
end
Minge:AddHook("Think", "FindTarget")


// ##################################################
// Fake view
// ##################################################

Minge.View = Angle(0, 0, 0)
function Minge:GetView()
	return self.View * 1
end
function Minge:KeepView()
	if !self:Enabled() then return end

	local ply = LocalPlayer()
	if !ValidEntity(ply) then return end

	self.View = EntM["EyeAngles"](ply)
end
Minge:AddHook("OnToggled", "KeepView")

local sensitivity = 0.022
function Minge:RotateView(cmd)
	self.View.p = math.Clamp(self.View.p + (CmdM["GetMouseY"](cmd) * sensitivity), -89, 89)
	self.View.y = math.NormalizeAngle(self.View.y + (CmdM["GetMouseX"](cmd) * sensitivity * -1))
end
Minge:AddHook("CreateMove", "RotateView")

Minge:CreateSetting("debug", "Debug", false, {Show = false})
function Minge:FakeView(ply, origin, angles, FOV)
	if !self:Enabled() && !self.SetAngleTo then return end
	if GetViewEntity() != LocalPlayer() then return end
	if self:Setting("debug") then return end
	
	local base = GAMEMODE:CalcView(ply, origin, self.SetAngleTo or self.View, FOV) or {}
			base.angles = base.angles or (self.AngleTo or self.View)
			base.angles.r = 0 // No crappy screen tilting in ZS.
	return base
end
Minge:AddHook("CalcView", "FakeView")


function Minge:TargetPrediction(ply, target, targetPos)
	local weap = PlyM["GetActiveWeapon"](ply)
	if ValidEntity(weap) then
		local class = EntM["GetClass"](weap)
		if class == "weapon_crossbow" then
			local dist = VecM["Length"](targetPos - PlyM["GetShootPos"](ply))
			local time = (dist / 3500) + 0.05 // About crossbow bolt speed.
			targetPos = targetPos + (EntM["GetVelocity"](target) * time)
		end
		
		local mul = 0.0075
		//targetPos = targetPos - (e["GetVelocity"](ply) * mul)
	end
	
	return targetPos
end
Minge:AddHook("TargetPrediction", "TargetPrediction")

// ##################################################
// Aim
// ##################################################

function Minge:SetAngle(ang)
	self.SetAngleTo = ang
end

Minge:CreateSetting("smoothspeed", "Smooth aim speed (0 to disable)", 120, {Min = 0, Max = 360})
Minge:CreateSetting("snaponfire", "Snap on fire", true)
Minge:CreateSetting("snapgrace", "Snap on fire grace", 0.5, {Min = 0, Max = 3, Places = 1})
Minge.LastAttack = 0
function Minge:SetAimAngles(cmd)
	if !self:Enabled() && !self.SetAngleTo then return end

	local ply = LocalPlayer()
	if !ValidEntity(ply) then return end

	// We're aiming with the view, normally.
	local targetAim = self:GetView()

	// If we have a target, aim at them!
	local target = self:GetTarget()
	if target then
		local targetPos = self:TargetPosition(target)
		targetAim = VecM["Angle"](targetPos - ply:GetShootPos())
	end

	// We're following the view, until we fire.
	if self:Setting("snaponfire") then
		local time = CurTime()
		if PlyM["KeyDown"](ply, IN_ATTACK) || PlyM["KeyDown"](ply, IN_ATTACK2) || self:Setting("autoshoot") != 0 then
			self.LastAttack = time
		end
		if CurTime() - self.LastAttack > self:Setting("snapgrace") then
			targetAim = self:GetView()
		end
	end

	// We want to change to whatever was SetAngle'd.
	if self.SetAngleTo then
		targetAim = self.SetAngleTo
	end

	// Smooth aiming.
	local smooth = self:Setting("smoothspeed")
	if smooth > 0 then
		local current = CmdM["GetViewAngles"](cmd)

		// Approach the target angle.
		current = self:ApproachAngle(current, targetAim, smooth * FrameTime())
		current.r = 0

		// If we're just following the view, we don't need to smooth it.
		if self.RevertingAim then
			local diff = self:NormalizeAngle(current - self:GetView())
			if math.abs(diff.p) < 1 && math.abs(diff.y) < 1 then self.RevertingAim = false end
		elseif targetAim == self:GetView() then
			current = targetAim
		end

		// Check if the angles are the same...
		if self.SetAngleTo then
			local diff = self:NormalizeAngle(current - self.SetAngleTo)
			if math.abs(diff.p) < 1 && math.abs(diff.y) < 1 then self.SetAngleTo = nil end
		end

		aim = current
	else
		aim = targetAim
		self.SetAngleTo = nil
	end

	// Set the angles.
	CmdM["SetViewAngles"](cmd, aim)
	local sensitivity = 0.22
	local diff = aim - CmdM["GetViewAngles"](cmd)
	CmdM["SetMouseX"](cmd, diff.y / sensitivity)
	CmdM["SetMouseY"](cmd, diff.p / sensitivity)
	

	// Change the players movement to be relative to their view instead of their aim.
	local move = Vector(CmdM["GetForwardMove"](cmd), CmdM["GetSideMove"](cmd), 0)
	local norm = VecM["GetNormal"](move)
	local set = AngM["Forward"](VecM["Angle"](norm) + (aim - self:GetView())) * VecM["Length"](move)
		CmdM["SetForwardMove"](cmd, set.x)
		CmdM["SetSideMove"](cmd, set.y)
end
Minge:AddHook("CreateMove", "SetAimAngles")

function Minge:RevertAim()
	self.RevertingAim = true
end
Minge:AddHook("TargetLost", "RevertAim")
function Minge:StopRevertAim()
	self.RevertingAim = false
end
Minge:AddHook("TargetGained", "RevertAim")

// When we turn off the bot, we want our aim to go back to our view.
function Minge:ViewToAim()
	if self:Enabled() then return end
	self:SetAngle(self:GetView())
end
Minge:AddHook("OnToggled", "ViewToAim")


// ##################################################
// HUD
// ##################################################

Minge:CreateSetting("crosshair", "Crosshair size (0 to disable)", 18, {Min = 0, Max = 20})
function Minge:DrawTarget()
	if !self:Enabled() then return end

	local target = self:GetTarget()
	if !target then return end

	local size = self:Setting("crosshair")
	if size <= 0 then return end

	// Change colour on the block status.
	local blocked, aimOff = self:TargetBlocked()
	if blocked then
		surface.SetDrawColor(255, 0, 0, 255) // Red.
	elseif aimOff then
		surface.SetDrawColor(255, 255, 0, 255) // Yellow.
	else
		surface.SetDrawColor(0, 255, 0, 255) // Green.
	end

	// Get the onscreen coordinates for the target.
	local pos = self:TargetPosition(target)

	local screen = VecM["ToScreen"](pos)
	local x, y = screen.x, screen.y

	// Work out sizes.
	local a, b = size / 2, size / 6

	// Top left.
	surface.DrawLine(x - a, y - a, x - b, y - a)
	surface.DrawLine(x - a, y - a, x - a, y - b)

	// Bottom right.
	surface.DrawLine(x + a, y + a, x + b, y + a)
	surface.DrawLine(x + a, y + a, x + a, y + b)

	// Top right.
	surface.DrawLine(x + a, y - a, x + b, y - a)
	surface.DrawLine(x + a, y - a, x + a, y - b)

	// Bottom left.
	surface.DrawLine(x - a, y + a, x - b, y + a)
	surface.DrawLine(x - a, y + a, x - a, y + b)
end
Minge:AddHook("HUDPaint", "DrawTarget")


Minge.ScreenMaxAngle = {
	Length = 0,
	FOV = 0,
	MaxAngle = 0
}
Minge:CreateSetting("draw_maxangle", "Draw Max Angle", true)
function Minge:DrawMaxAngle()
	if !self:Enabled() then return end

	// Check that we want to be drawing this...
	local show = Minge:Setting("draw_maxangle")
	if !show then return end

	// We need a player for this to work...
	local ply = LocalPlayer()
	if !ValidEntity(ply) then return end

	local info = self.ScreenMaxAngle
	local maxang = Minge:Setting("maxangle")
	
	local fov = PlyM["GetFOV"](ply)
	if GetViewEntity() == ply && (maxang != info.MaxAngle || fov != info.FOV) then
		local view = self:GetView()
			view.p = view.p + maxang

		local screen = (PlyM["GetShootPos"](ply) + (AngM["Forward"](view) * 100))
		screen = VecM["ToScreen"](screen)

		info.Length = math.abs((ScrH() / 2) - screen.y)

		info.MaxAngle = maxang
		info.FOV = fov
	end

	local length = info.Length

	local cx, cy = ScrW() / 2, ScrH() / 2
	for x = -1, 1 do
		for y = -1, 1 do
			if x != 0 || y != 0 then
				local add = VecM["GetNormal"](Vector(x, y, 0)) * length
				surface.SetDrawColor(0, 0, 0, 255)
				surface.DrawRect((cx + add.x) - 2, (cy + add.y) - 2, 5, 5)
				surface.SetDrawColor(255, 255, 255, 255)
				surface.DrawRect((cx + add.x) - 1, (cy + add.y) - 1, 3, 3)
			end
		end
	end

end
Minge:AddHook("HUDPaint", "DrawMaxAngle")

// ##################################################
// Auto-shoot
// ##################################################

Minge.AttackDown = false
function Minge:SetShooting(bool)
	if self.AttackDown == bool then return end
	self.AttackDown = bool

	local pre = {[true] = "+", [false] = "-"}
	RunConsoleCommand(pre[bool] .. "attack")
end

Minge.NextShot = 0
Minge:CreateSetting("autoshoot", "Max auto-shoot distance (0 to disable)", 0, {Min = 0, Max = 16384})
function Minge:Shoot()
	if !self:Enabled() then
		self:SetShooting(false)
		return
	end

	// Get the maximum distance.
	local maxDist = self:Setting("autoshoot")
	if maxDist == 0 then return end

	// Check we've got something to shoot at...
	local target = self:GetTarget()
	if !target then return end
	
	// Don't shoot until we can hit, you idiot!
	local blocked, wrongAim = self:TargetBlocked(target)
	if blocked || wrongAim then return end

	// We're gonna need the player object in a second.
	local ply = LocalPlayer()
	if !ValidEntity(ply) then return end
	
	// Check we're within our maximum distance.
	local targetPos = self:TargetPosition(target)
	local distance = VecM["Length"](targetPos - ply:GetShootPos())
	if distance > maxDist && maxDist != -1 then return end

	// Check if it's time to shoot yet.
	if CurTime() < self.NextShot then return end

	// Check we got our weapon.
	local weap = PlyM["GetActiveWeapon"](ply)
	if !ValidEntity(weap) then return end

	// Shoot!
	self:SetShooting(true)
	// If we're semi-auto, we want to stop holding down fire.
	if self:IsSemiAuto(weap) then
		timer.Simple(0.05, function() self:SetShooting(false) end)
	end

	// Set the next time to shoot.
	self.NextShot = CurTime() + 0.1
end
Minge:AddHook("Think", "Shoot")

// When we lose our target we stop shooting.
function Minge:StopShooting()
	self:SetShooting(false)
end
Minge:AddHook("TargetLost", "StopShooting")

// ##################################################
// Toggle
// ##################################################

Minge.IsEnabled = false
function Minge:Enabled() return self.IsEnabled end

function Minge:SetEnabled(bool)
	if self.IsEnabled == bool then return end
	self.IsEnabled = bool

	local message = {[true] = "ON", [false] = "OFF"}
	print("AutoAim " .. message[self.IsEnabled])

	local e = {[true] = "1", [false] = "0"}
	RunConsoleCommand("Minge_enabled", e[self.IsEnabled])

	self:CallHook("OnToggled")
end

function Minge:Toggle()
	self:SetEnabled(!self:Enabled())
end
concommand.Add("Minge_toggle", function() Minge:Toggle() end)

Minge:CreateSetting("enabled", "Enabled", false, {Save = false})
function Minge:ConVarEnabled(_, old, val)
	if old == val then return end
	val = tonumber(val) or 0
	self:SetEnabled(val > 0)
end
Minge:AddCVarHook("Minge_enabled", "ConVarEnabled")

concommand.Add("+Minge", function() Minge:SetEnabled(true) end)
concommand.Add("-Minge", function() Minge:SetEnabled(false) end)

// ##################################################
// Menu
// ##################################################

function Minge:OpenMenu()
	local w, h = ScrW() / 3, ScrH() / 2

	local menu = vgui.Create("DFrame")
	menu:SetTitle("Minge")
	menu:SetSize(w, h)
	menu:Center()
	menu:MakePopup()

	local scroll = vgui.Create("DPanelList", menu)
	scroll:SetPos(5, 25)
	scroll:SetSize(w - 10, h - 30)
	scroll:EnableVerticalScrollbar()

	local form = vgui.Create("DForm", menu)
	form:SetName("")
	form.Paint = function() end
	scroll:AddItem(form)

	self:BuildMenu(form)

	if Minge.Menu then Minge.Menu:Remove() end
	Minge.Menu = menu
end
concommand.Add("Minge_menu", function() Minge:OpenMenu() end)

function Minge:RegisterMenu()
	spawnmenu.AddToolMenuOption("Options", "Hacks", "Minge", "Minge", "", "", function(p) self:BuildMenu(p) end)
end
Minge:AddHook("PopulateToolMenu", "RegisterMenu")

// ##################################################
// Useful functions
// ##################################################

function Minge:AngleBetween(a, b)
	return math.deg(math.acos(VecM["Dot"](a, b)))
end

function Minge:NormalizeAngle(ang)
	return Angle(math.NormalizeAngle(ang.p), math.NormalizeAngle(ang.y), math.NormalizeAngle(ang.r))
end

function Minge:ApproachAngle(start, target, add)
	local diff = self:NormalizeAngle(target - start)

	local vec = Vector(diff.p, diff.y, diff.r)
	local len = VecM["Length"](vec)
	vec = VecM["GetNormal"](vec) * math.min(add, len)

	return start + Angle(vec.x, vec.y, vec.z)
end

local notAuto = {"weapon_pistol", "weapon_rpg", "weapon_357", "weapon_crossbow"}
function Minge:IsSemiAuto(weap)
	if !ValidEntity(weap) then return end
	return (weap.Primary && !weap.Primary.Automatic) || table.HasValue(notAuto, EntM["GetClass"](weap))
end

-- TriggerBot
function TriggerBot()
local Eye = LocalPlayer():GetEyeTrace().Entity
if GetConVarNumber( "minge_aim_trigger" ) >= 1 then
if (Eye:IsNPC() or Eye:IsPlayer()) then
RunConsoleCommand("+attack")
else
timer.Simple(0.50, function()
RunConsoleCommand("-attack")
                        end)
                end
        end
                end
 
hook.Add("Think", "Test", TriggerBot)

-- ESP
function ESP()
if GetConVarNumber("minge_esp_info") == 1 then
for k, v in pairs( player.GetAll() ) do
if( v:Alive() && v != LocalPlayer() ) then
local Pos = ( v:GetPos() + Vector( 0, 0, 75 ) ):ToScreen();
local Dist = v:GetPos():Distance(LocalPlayer():GetPos());
local wep = "Unknown"
if v:GetActiveWeapon() != nil then
if type(v:GetActiveWeapon()) == "Weapon" then
if v:GetActiveWeapon() and v:GetActiveWeapon():IsValid() then
wep = v:GetActiveWeapon():GetClass()
local InfoColor = Green
draw.SimpleText(v:Name(), "ESPFont_Small", Pos.x, Pos.y, InfoColor, TEXT_ALIGN_CENTER )
draw.SimpleText("H: " .. v:Health(), "ESPFont_Small", Pos.x, Pos.y + 12, InfoColor, TEXT_ALIGN_CENTER )
draw.SimpleText("D: " .. math.floor(Dist), "ESPFont_Small", Pos.x, Pos.y + 22, InfoColor, TEXT_ALIGN_CENTER);
draw.SimpleText("W: " .. wep, "ESPFont_Small", Pos.x, Pos.y + 32, InfoColor, TEXT_ALIGN_CENTER );
if v:IsAdmin() then
draw.SimpleText("[ADMIN]", "TabLarge", Pos.x, Pos.y - 12, Red, TEXT_ALIGN_CENTER );
end
if v:GetFriendStatus() == "friend" then
draw.SimpleText("-Friend-", "TabLarge", Pos.x, Pos.y - 22, Blue, TEXT_ALIGN_CENTER );
end
end
end
end
end
end
end
end
hook.Add("HUDPaint", "ESP",ESP)

function Crosshair()
	if GetConVarNumber("minge_esp_crosshair") == 1 then
		local x, y = ScrW() / 2, ScrH() / 2	
		local Speed = 1
		surface.SetDrawColor(255, 0, 0, 255)
		CHPosx = math.Clamp(LocalPlayer():GetEyeTrace().HitPos:ToScreen().x,0,ScrW())
		CHPosy = math.Clamp(LocalPlayer():GetEyeTrace().HitPos:ToScreen().y,0,ScrH())
		mathsin = math.sin(CurTime()*Speed)*4
		mathcos = math.cos(CurTime()*Speed)*4
		mathsin2 = math.sin(CurTime()*Speed+0.1)*4
		mathcos2 = math.cos(CurTime()*Speed+0.1)*4
		mathsin3 = math.sin(CurTime()*Speed-0.1)*4
		mathcos3 = math.cos(CurTime()*Speed-0.1)*4
		surface.DrawLine( CHPosx+mathcos*2,CHPosy+mathsin*2,CHPosx+mathcos*5,CHPosy+mathsin*5 );
		surface.DrawLine( CHPosx-mathcos*2,CHPosy-mathsin*2,CHPosx-mathcos*5,CHPosy-mathsin*5 );
		surface.DrawLine( CHPosx+mathsin*2,CHPosy-mathcos*2,CHPosx+mathsin*5,CHPosy-mathcos*5 );
		surface.DrawLine( CHPosx-mathsin*2,CHPosy+mathcos*2,CHPosx-mathsin*5,CHPosy+mathcos*5 );
		draw.RoundedBox( 4, ( ScrW() / 2 ) - 3, ( ScrH() / 2 ) - 3, 7, 7, Color( 255, 255, 255, 255 ) );
	end
end
hook.Add( 'HUDPaint', 'crosshair', Crosshair )


local skeleton = {
        { S = "ValveBiped.Bip01_Head1", E = "ValveBiped.Bip01_Neck1" },
        { S = "ValveBiped.Bip01_Neck1", E = "ValveBiped.Bip01_Spine4" },
        { S = "ValveBiped.Bip01_Spine4", E = "ValveBiped.Bip01_Spine2" },
        { S = "ValveBiped.Bip01_Spine2", E = "ValveBiped.Bip01_Spine1" },
        { S = "ValveBiped.Bip01_Spine1", E = "ValveBiped.Bip01_Spine" },
        { S = "ValveBiped.Bip01_Spine", E = "ValveBiped.Bip01_Pelvis" },
 
        { S = "ValveBiped.Bip01_Spine2", E = "ValveBiped.Bip01_L_UpperArm" },
        { S = "ValveBiped.Bip01_L_UpperArm", E = "ValveBiped.Bip01_L_Forearm" },
        { S = "ValveBiped.Bip01_L_Forearm", E = "ValveBiped.Bip01_L_Hand" },
 
        { S = "ValveBiped.Bip01_Spine2", E = "ValveBiped.Bip01_R_UpperArm" },
        { S = "ValveBiped.Bip01_R_UpperArm", E = "ValveBiped.Bip01_R_Forearm" },
        { S = "ValveBiped.Bip01_R_Forearm", E = "ValveBiped.Bip01_R_Hand" },
 
        { S = "ValveBiped.Bip01_Pelvis", E = "ValveBiped.Bip01_L_Thigh" },
        { S = "ValveBiped.Bip01_L_Thigh", E = "ValveBiped.Bip01_L_Calf" },
        { S = "ValveBiped.Bip01_L_Calf", E = "ValveBiped.Bip01_L_Foot" },
        { S = "ValveBiped.Bip01_L_Foot", E = "ValveBiped.Bip01_L_Toe0" },
       
        { S = "ValveBiped.Bip01_Pelvis", E = "ValveBiped.Bip01_R_Thigh" },
        { S = "ValveBiped.Bip01_R_Thigh", E = "ValveBiped.Bip01_R_Calf" },
        { S = "ValveBiped.Bip01_R_Calf", E = "ValveBiped.Bip01_R_Foot" },
        { S = "ValveBiped.Bip01_R_Foot", E = "ValveBiped.Bip01_R_Toe0" },
}
     
local function Skeleton(e)    
        if(GetConVarNumber("minge_esp_skeleton") == 1 ) then
        if !e:Alive() then return end
        for k, v in pairs( skeleton ) do
                local sPos, ePos = e:GetBonePosition( e:LookupBone( v.S ) ):ToScreen(), e:GetBonePosition( e:LookupBone( v.E ) ):ToScreen()
               
                surface.SetDrawColor( Red )
                surface.DrawLine( sPos.x, sPos.y, ePos.x, ePos.y )
                end
    end
end
hook.Add("HUDPaint", "SkeletonESP", function()
        for k,v in pairs(player.GetAll()) do
                if v != LocalPlayer() then
                       Skeleton(v)
                end
        end
end) 

-- Chams
function IsCloseEnough(ent)
        local dist = ent:GetPos():Distance( LocalPlayer():GetPos() )
        if( dist <= GetConVarNumber("minge_esp_destance") and ent:GetPos() != Vector( 0, 0, 0 ) ) then
                return true
        end
        return false   
end

function Minge:CreateMaterial()
local BaseInfo = {
["$basetexture"] = "models/debug/debugwhite",
["$model"]  = 1,
["$translucent"] = 1,
["$alpha"]  = 1,
["$nocull"]  = 1,
["$ignorez"]  = 1
}  
local mat  
if GetConVarNumber( "minge_esp_chams" ) == 1 then
  mat = CreateMaterial( "minge_chams", "VertexLitGeneric", BaseInfo )
  end
end

function Chams()
local mat = Minge:CreateMaterial()
  if GetConVarNumber( "minge_esp_chams" ) == 1 then
    for k,v in pairs(player.GetAll()) do
    local TCol = team.GetColor(v:Team())
    if IsValid(v) and v:Health() > 0 and v:Team() != TEAM_SPECTATOR and IsCloseEnough(v) then
    //Players
    cam.Start3D(EyePos(),EyeAngles())
    render.SuppressEngineLighting( true )
    render.SetColorModulation( ( TCol.r * ( 1 / 255 ) ), ( TCol.g * ( 1 / 255 ) ), ( TCol.b * ( 1 / 255 ) ) )
    render.MaterialOverride( mat )
    v:DrawModel()
    render.SuppressEngineLighting( false )
    render.SetColorModulation(1,1,1)
    render.MaterialOverride( )
    v:DrawModel()
    cam.End3D()
    end
    end
  end
end
hook.Add("RenderScreenSpaceEffects","hookName",Chams)
hook.Add('HUDPaint', 'Chams', Chams)

--BoundBox
function BoundingBox()
if GetConVarNumber( "minge_esp_box" ) >= 1 then
for k, v in pairs ( player.GetAll() ) do
if v ~= LocalPlayer() then
if v:Alive() and v:Team() ~= TEAM_SPECTATOR then
local PlayerBoxPos = v:EyePos():ToScreen()
surface.SetDrawColor( team.GetColor( v:Team() ) )
surface.DrawOutlinedRect( PlayerBoxPos.x - 40 / 3, PlayerBoxPos.y - 40 / 2, 30, 60 )
end
end
end
end
end
hook.Add( "HUDPaint", "CronusBoundingBox", BoundingBox )

-- Tracer
function Tracer()
	for k, v in pairs( player.GetAll() ) do
		if GetConVarNumber("minge_esp_tracer") == 1 then		
					cam.Start3D( EyePos() , EyeAngles())
					render.SetMaterial( Material( "trails/laser" ) )
					StartPos = LocalPlayer():GetActiveWeapon():GetPos()
					EndPos = v:GetBonePosition(v:LookupBone("ValveBiped.Bip01_Head1"))
					render.DrawBeam(StartPos, EndPos , 3, 0, 0, Color(0,255,0,255))
				cam.End3D()
			end
		end
	end
hook.Add('HUDPaint', 'Tracer', Tracer)

-- RP Shit

function RPShit()
if GetConVarNumber( "minge_esp_printers" ) >= 1 then
for k, v in pairs( ents.GetAll() ) do
if IsValid( v ) then
if v:GetClass() == "money_printer" or v:GetClass() == "gold_money_printer" or v:GetClass() == "owner_money_printer" or v:GetClass() == "nuclear_money_printer" or v:GetClass() == "normal_money_printer" or v:GetClass() == "amethyst_money_printer" or v:GetClass() == "vip_money_printer" or v:GetClass() == "plus_money_printer" or v:GetClass() == "emerald_money_printer" or v:GetClass() == "ruby_money_printer" or v:GetClass() == "zz_money_printer" or v:GetClass() == "sapphire_money_printer" or v:GetClass() == "topaz_money_printer" then
MoneyPrinterPos = v:EyePos():ToScreen()
draw.SimpleText( v:GetClass(), "TabLarge", MoneyPrinterPos.x, MoneyPrinterPos.y, Color( 255, 150, 0, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
                                end
                        end
                end
        end

if GetConVarNumber( "minge_esp_money" ) >= 1 then
for k, v in pairs( ents.GetAll() ) do
if IsValid( v ) then
if v:GetClass() == "spawned_money" then
MoneyPos = v:EyePos():ToScreen()
v:DrawModel()
draw.SimpleText( "Money: $" .. v.dt.amount, "TabLarge", MoneyPos.x, MoneyPos.y, Color( 0, 255, 0, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
                                end
                        end
                end
        end
if GetConVarNumber( "minge_esp_shipments" ) >= 1 then
for k, v in pairs( ents.GetAll() ) do
if IsValid( v ) then
if v:GetClass() == "spawned_shipment" && v:GetMoveType() != 0 then
ShipmentPos = v:EyePos():ToScreen()
v:DrawModel()
        local content = v.dt.contents
        local contents = CustomShipments[content]
        contents = contents.name
draw.SimpleText( "Shipment: " .. contents, "TabLarge", ShipmentPos.x, ShipmentPos.y, Color( 255, 0, 0, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
draw.SimpleText( "Count: " .. v.dt.count, "TabLarge", ShipmentPos.x, ShipmentPos.y + 22, Color( 255, 0, 0, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
                                end
                        end
                end
        end
 
function WeaponsESP()
if GetConVarNumber( "minge_esp_weapons" ) >= 1 then
for k, v in pairs( ents.GetAll() ) do
if IsValid( v ) then
if v:IsWeapon() && v:GetMoveType() != 0 then
if string.sub( v:GetClass(), 1, 7 ) == "weapon_" then
WeaponPos = v:EyePos():ToScreen()
v:DrawModel()
draw.SimpleText( v:GetClass(), "TabLarge", WeaponPos.x, WeaponPos.y, Color( 255, 0, 0, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
                                        end
                                end
                        end
                end
        end
	end
end
hook.Add('HUDPaint', 'RPShit', RPShit)

-- Misc
CreateClientConVar("minge_speedhack_speed", 3.5, true, false)
speedon = function()
HT:SetValue(tostring(GetConVarNumber("minge_speedhack_speed")))
SC:SetValue(5.0)
end
 
speedoff = function()
HT:SetValue(1.0)
SC:SetValue(0)
end
 
concommand.Add("+speedhack", speedon)
concommand.Add("-speedhack", speedoff)

-- Misc
function Misc()
	if GetConVarNumber("minge_misc_bhop") == 1 then
		if input.IsKeyDown(KEY_SPACE) then
			if LocalPlayer():IsOnGround() then
				old_rcc("+Jump")
				timer.Create("Bhop",0.01, 0 ,function() old_rcc("-Jump") end)
			end
		end
	end
	if GetConVarNumber("minge_misc_spamchat") == 1 then
		LocalPlayer():ConCommand("say "..GetConVarString("minge_misc_spamchat_msg").."["..math.random(1,999).."]")
	end
	if GetConVarNumber("minge_misc_rpgod") == 1 then
		if LocalPlayer():Health() < 100 then
			LocalPlayer():ConCommand("say /buyhealth"); -- spam buyhealth
		end
	end
	if GetConVarNumber("minge_misc_flashlightspam") == 1 then
		old_rcc("impulse", "100")
	end
end
hook.Add('Think', 'Misc', Misc)

-- Notifications
local observers = {}
timer.Simple(.1, function()
    for _,v in ipairs(player.GetAll()) do
        if IsValid(v:GetObserverTarget()) and v:GetObserverTarget() == LocalPlayer() and !table.HasValue(observers, v:SteamID()) then
            table.insert(observers, v:SteamID())
            chat.AddText(Color(255,0,0), "Player ", Color(65,120,35), v:Nick(), Color(255,0,0), " is now spectating you.")
        end
        if !IsValid(v:GetObserverTarget()) and table.HasValue(observers, v:SteamID()) then
            for k,g in pairs(observers) do
                if v:SteamID() == g then
        table.remove(observers, k)
                end
            end
            chat.AddText(Color(0,255,0), "Player ", Color(65,120,35), v:Nick(), Color(0,255,0), " is no longer spectating you.")
        end
    end
end)

-- Derma --
local function ShowFrame()
 
Frame = vgui.Create("DFrame")
Frame:SetSize( 280 , 270 )
Frame:SetPos( ScrW() / 2 - Frame:GetWide() / 2 , ScrH() / 2 - Frame:GetTall() / 2  )
Frame:SetTitle("MingeBot [V2] Beta [V1.2]")
Frame:SetVisible( true )
Frame:ShowCloseButton( true )
Frame.Paint = function()
        draw.RoundedBox( 8, 0, 0, Frame:GetWide(), Frame:GetTall(), Color( 0, 0, 255, 110 ) )
end
Frame:MakePopup()
 
local BSheet = vgui.Create("DPropertySheet" , Frame)
BSheet:SetSize( 270 , 230 )
BSheet:SetPos( 5 , 25 )
BSheet.Paint = function()
        draw.RoundedBox( 8, 0, 0, BSheet:GetWide(), BSheet:GetTall(), Color( 0, 0, 0, 190 ) )
end
 
local Tab = vgui.Create("DLabel")
Tab:SetParent( BSheet )
Tab:SetPos( 0 , 10 )
Tab:SetText("")
 
local Tab2 = vgui.Create("DLabel")
Tab2:SetParent( BSheet )
Tab2:SetPos( 0 , 10 )
Tab2:SetText("")
 
local Tab3 = vgui.Create("DLabel")
Tab3:SetParent( BSheet )
Tab3:SetPos( 0 , 10 )
Tab3:SetText("")
 
local Tab4 = vgui.Create("DLabel")
Tab4:SetParent( BSheet )
Tab4:SetPos( 0 , 10 )
Tab4:SetText("")
 
local Tab5 = vgui.Create("DLabel")
Tab5:SetParent( BSheet )
Tab5:SetPos( 0 , 10 )
Tab5:SetText("")
 
// Options
 
local AimLabel = vgui.Create("DLabel")
AimLabel:SetParent( Tab )
AimLabel:SetPos( 13 , 10 )
AimLabel:SetText("")
AimLabel:SetTextColor( Color(255 , 255 , 255 , 255 ) )
AimLabel:SizeToContents()
 
local AimLabel2 = vgui.Create("DLabel")
AimLabel2:SetParent( Tab )
AimLabel2:SetPos( 13 , 70 )
AimLabel2:SetText("")
AimLabel2:SetTextColor( Color(255 , 255 , 255 , 255 ) )
AimLabel2:SizeToContents()
 
local AimLabel3 = vgui.Create("DLabel")
AimLabel3:SetParent( Tab )
AimLabel3:SetPos( 206 , 10 )
AimLabel3:SetText("")
AimLabel3:SetTextColor( Color(255 , 255 , 255 , 255 ) )
AimLabel3:SizeToContents()
 
local AimLabel4 = vgui.Create("DLabel")
AimLabel4:SetParent( Tab )
AimLabel4:SetPos( 13 , 130  )
AimLabel4:SetText("")
AimLabel4:SetTextColor( Color(255 , 255 , 255 , 255 ) )
AimLabel4:SizeToContents()
 
local AimLabel5 = vgui.Create("DLabel")
AimLabel5:SetParent( Tab )
AimLabel5:SetPos( 118.5 , 235 )
AimLabel5:SetText("MingeBot [V2] Beta [V1.2]")
AimLabel5:SetTextColor( Color(255 , 255 , 255 , 255 ) )
AimLabel5:SizeToContents()
 
local Aim3 = vgui.Create( "DCheckBoxLabel")
Aim3:SetText( "AutoFire/Triggerbot" )
Aim3:SetConVar( "minge_aim_trigger" )
Aim3:SetParent( Tab )
Aim3:SetPos( 10 , 20 )
Aim3:SetValue( GetConVarNumber("minge_aim_trigger") )
Aim3:SetTextColor( Color(255 , 255 , 255 , 255 ) )
Aim3:SizeToContents()
 
local Aim4 = vgui.Create( "DCheckBoxLabel")
Aim4:SetText( "NoSpread" )
Aim4:SetConVar( "minge_aim_nospread" )
Aim4:SetParent( Tab )
Aim4:SetPos( 10 , 40 )
Aim4:SetValue( GetConVarNumber("minge_aim_nospread") )
Aim4:SetTextColor( Color(255 , 255 , 255 , 255 ) )
Aim4:SizeToContents()
 
local Aim5 = vgui.Create( "DCheckBoxLabel")
Aim5:SetText( "NoRecoil" )
Aim5:SetConVar( "minge_aim_norecoil" )
Aim5:SetParent( Tab )
Aim5:SetPos( 10 , 60 )
Aim5:SetValue( GetConVarNumber("minge_aim_norecoil") )
Aim5:SetTextColor( Color(255 , 255 , 255 , 255 ) )
Aim5:SizeToContents()
 
local Aim6 = vgui.Create( "DCheckBoxLabel")
Aim6:SetText( "SilentAim" )
Aim6:SetConVar( "minge_aim_silentaim" )
Aim6:SetParent( Tab )
Aim6:SetPos( 10 , 90 )
Aim6:SetValue( GetConVarNumber( 'minge_aim_silentaim' ) );
Aim6:SetTextColor( Color(255 , 255 , 255 , 255 ) )
Aim6:SizeToContents()
 
local EspLabel = vgui.Create("DLabel")
EspLabel:SetParent( Tab2 )
EspLabel:SetPos( 13 , 10 )
EspLabel:SetText("")
EspLabel:SetTextColor( Color(255 , 255 , 255 , 255 ) )
EspLabel:SizeToContents()
 
local EspLabel2 = vgui.Create("DLabel")
EspLabel2:SetParent( Tab2 )
EspLabel2:SetPos( 13 , 90 )
EspLabel2:SetText("")
EspLabel2:SetTextColor( Color(255 , 255 , 255 , 255 ) )
EspLabel2:SizeToContents()
 
local EspLabel3 = vgui.Create("DLabel")
EspLabel3:SetParent( Tab2 )
EspLabel3:SetPos( 200 , 10 )
EspLabel3:SetText("")
EspLabel3:SetTextColor( Color(255 , 255 , 255 , 255 ) )
EspLabel3:SizeToContents()
 
local Esp = vgui.Create( "DCheckBoxLabel")
Esp:SetText( "[ESP] Info" )
Esp:SetConVar( "minge_esp_info" )
Esp:SetParent( Tab2 )
Esp:SetPos( 10 , 20 )
Esp:SetValue( GetConVarNumber("minge_esp_info") )
Esp:SetTextColor( Color(255 , 255 , 255 , 255 ) )
Esp:SizeToContents()
 
local Esp2 = vgui.Create( "DCheckBoxLabel")
Esp2:SetText( "[ESP] PlayerBox" )
Esp2:SetConVar( "minge_esp_box" )
Esp2:SetParent( Tab2 )
Esp2:SetPos( 10 , 40 )
Esp2:SetValue( GetConVarNumber("minge_esp_box") )
Esp2:SetTextColor( Color(255 , 255 , 255 , 255 ) )
Esp2:SizeToContents()
 
local Esp3 = vgui.Create( "DCheckBoxLabel")
Esp3:SetText( "[ESP] Chams" )
Esp3:SetConVar( "minge_esp_chams" )
Esp3:SetParent( Tab2 )
Esp3:SetPos( 10 , 60 )
Esp3:SetValue( GetConVarNumber( 'minge_esp_chams' ) )
Esp3:SetTextColor( Color(255 , 255 , 255 , 255 ) )
Esp3:SizeToContents()
 
 
local Esp6 = vgui.Create( "DCheckBoxLabel")
Esp6:SetText( "[ESP] Skeleton" )
Esp6:SetConVar( "minge_esp_skeleton" )
Esp6:SetParent( Tab2 )
Esp6:SetPos( 10 , 80 )
Esp6:SetValue( GetConVarNumber("minge_esp_skeleton") )
Esp6:SetTextColor( Color(255 , 255 , 255 , 255 ) )
Esp6:SizeToContents()
 
local Esp4 = vgui.Create( "DCheckBoxLabel")
Esp4:SetText( "[ESP] SnapLine" )
Esp4:SetConVar( "minge_esp_tracer" )
Esp4:SetParent( Tab2 )
Esp4:SetPos( 10 , 100 )
Esp4:SetValue( GetConVarNumber("minge_esp_tracer") )
Esp4:SetTextColor( Color(255 , 255 , 255 , 255 ) )
Esp4:SizeToContents()
 
local Esp5 = vgui.Create( "DCheckBoxLabel")
Esp5:SetText( "[ESP] Crosshair" )
Esp5:SetConVar( "minge_esp_crosshair" )
Esp5:SetParent( Tab2 )
Esp5:SetPos( 10 , 120 )
Esp5:SetValue( GetConVarNumber("minge_esp_crosshair") )
Esp5:SetTextColor( Color(255 , 255 , 255 , 255 ) )
Esp5:SizeToContents()
 
-- DarkRP
local Esp5 = vgui.Create( "DCheckBoxLabel")
Esp5:SetText( "Show Money Printers" )
Esp5:SetConVar( "minge_esp_printers" )
Esp5:SetParent( Tab3 )
Esp5:SetPos( 10 , 20 )
Esp5:SetValue( GetConVarNumber("minge_esp_printers") )
Esp5:SetTextColor( Color(255 , 255 , 255 , 255 ) )
Esp5:SizeToContents()

local Esp5 = vgui.Create( "DCheckBoxLabel")
Esp5:SetText( "Show Money" )
Esp5:SetConVar( "minge_esp_money" )
Esp5:SetParent( Tab3 )
Esp5:SetPos( 10 , 40 )
Esp5:SetValue( GetConVarNumber("minge_esp_money") )
Esp5:SetTextColor( Color(255 , 255 , 255 , 255 ) )
Esp5:SizeToContents()

local Esp5 = vgui.Create( "DCheckBoxLabel")
Esp5:SetText( "Show Shipments" )
Esp5:SetConVar( "minge_esp_shipments" )
Esp5:SetParent( Tab3 )
Esp5:SetPos( 10 , 60 )
Esp5:SetValue( GetConVarNumber("minge_esp_shipments") )
Esp5:SetTextColor( Color(255 , 255 , 255 , 255 ) )
Esp5:SizeToContents()

local Esp5 = vgui.Create( "DCheckBoxLabel")
Esp5:SetText( "Show Weapons" )
Esp5:SetConVar( "minge_esp_weapons" )
Esp5:SetParent( Tab3 )
Esp5:SetPos( 10 , 80 )
Esp5:SetValue( GetConVarNumber("minge_esp_weapons") )
Esp5:SetTextColor( Color(255 , 255 , 255 , 255 ) )
Esp5:SizeToContents()
 
 
-- Misc
local MiscLabel = vgui.Create("DLabel")
MiscLabel:SetParent( Tab3 )
MiscLabel:SetPos( 13 , 10 )
MiscLabel:SetText("Misc Features")
MiscLabel:SetTextColor( Color(255 , 255 , 255 , 255 ) )
MiscLabel:SizeToContents()
 
local MiscLabel2 = vgui.Create("DLabel")
MiscLabel2:SetParent( Tab3 )
MiscLabel2:SetPos( 205 , 10 )
MiscLabel2:SetText("")
MiscLabel2:SetTextColor( Color(255 , 255 , 255 , 255 ) )
MiscLabel2:SizeToContents()
 
local Misc = vgui.Create( "DCheckBoxLabel")
Misc:SetText( "Bunnyhop" )
Misc:SetConVar( "minge_misc_bhop" )
Misc:SetParent( Tab4 )
Misc:SetPos( 10 , 20 )
Misc:SetValue( GetConVarNumber("minge_misc_bhop") )
Misc:SetTextColor( Color(255 , 255 , 255 , 255 ) )
Misc:SizeToContents()
 
local Misc2 = vgui.Create( "DCheckBoxLabel")
Misc2:SetText( "Chat Spammer" )
Misc2:SetConVar( "minge_misc_spamchat" )
Misc2:SetParent( Tab4 )
Misc2:SetPos( 10 , 40 )
Misc2:SetValue( GetConVarNumber("minge_misc_spamchat") )
Misc2:SetTextColor( Color(255 , 255 , 255 , 255 ) )
Misc2:SizeToContents()
 
local Misc3 = vgui.Create( "DCheckBoxLabel")
Misc3:SetText( "RP God ( Cost Money )" )
Misc3:SetConVar( "minge_misc_rpgod" )
Misc3:SetParent( Tab4 )
Misc3:SetPos( 10 , 60 )
Misc3:SetValue( GetConVarNumber("minge_misc_rpgod") )
Misc3:SetTextColor( Color(255 , 255 , 255 , 255 ) )
Misc3:SizeToContents()
 
local Misc4 = vgui.Create( "DCheckBoxLabel")
Misc4:SetText( "FlashLight Spammer" )
Misc4:SetConVar( "minge_misc_flashlightspam" )
Misc4:SetParent( Tab4 )
Misc4:SetPos( 10 , 80 )
Misc4:SetValue( GetConVarNumber("minge_misc_flashlightspam") )
Misc4:SetTextColor( Color(255 , 255 , 255 , 255 ) )
Misc4:SizeToContents()
 
local Sh = vgui.Create( "DNumSlider")
Sh:SetWide(100)
Sh:SetText( "" )
Sh:SetMin(0)
Sh:SetMax(10)
Sh:SetDecimals(1)
Sh:SetPos( 20 , 30 )
Sh:SetParent( Tab5 )
Sh:SetConVar("minge_speedhack_speed")
 
local ShLabel = vgui.Create("DLabel")
ShLabel:SetParent( Tab5 )
ShLabel:SetPos( 20 , 15 )
ShLabel:SetText( "SpeedHack Speed" )
ShLabel:SetTextColor(Color (255 , 255 , 255 , 255 ))
ShLabel:SizeToContents()
       
local IsisB = vgui.Create( "DButton", Tab3 )
IsisB:SetSize( 70, 30 )
IsisB:SetPos( 15, 300 )
IsisB:SetText( "Website." )
IsisB.DoClick = function()
       
local HtmlWin = vgui.Create( "DFrame" )
HtmlWin:SetPos( 1,1 )
HtmlWin:SetSize( ScrW() - 25 , ScrH() - 50 )
HtmlWin:SetTitle( "Updates/Information" )
HtmlWin:SetVisible( true )  
HtmlWin:SetDraggable( true )
HtmlWin:ShowCloseButton( false )
HtmlWin:MakePopup()
       
local HTMLWeb = vgui.Create( "HTML", HtmlWin )
HTMLWeb:SetSize(ScrW(), ScrH())
HTMLWeb:SetPos( 0, 50 )
HTMLWeb:OpenURL( "http://www.VoltageHack.webs.com/" )
 
local IsisB2 = vgui.Create( "DButton", HtmlWin )
IsisB2:SetSize( 70, 30 )
IsisB2:SetPos( 3, 5 )
IsisB2:SetText( "Minimize" )
IsisB2.DoClick = function()
HtmlWin:SetVisible(false)
        end    
local IsisB3 = vgui.Create( "DButton")
IsisB3:SetSize( 80,30 )
IsisB3:SetPos( ScrW() - 85, 35 )
IsisB3:SetText( "Hack Main Page" )
IsisB3.DoClick = function()
HtmlWin:SetVisible(true)
        end    
       
       
end
 
 
BSheet:AddSheet( "Aimbot", Tab, "gui/silkicons/star", false, false, "Aimbot" )
BSheet:AddSheet( "ESP", Tab2, "gui/silkicons/check_on", false, false, "Wallhacks/ESP" )
BSheet:AddSheet( "DarkRP", Tab3, "gui/silkicons/check_on", false, false, "RolePlay Wallhacks" )
BSheet:AddSheet( "Misc", Tab4, "gui/silkicons/world", false, false, "Misc" )
BSheet:AddSheet( "Speedhack", Tab5, "gui/silkicons/wrench", false, false, "Gotta go fast" )
end
concommand.Add("+MB_Menu",ShowFrame)
concommand.Add("-MB_Menu",function()
Frame:SetVisible( false )
end)
 
concommand.Add("MB_Menu_Reload",function()
ShowFrame()
end)