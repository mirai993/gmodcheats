--[[
	lua/lel.lua
	sup dude | (STEAM_0:0:35901997)
	===DStream===
]]

require("helios");


local defcon = {
	hook      = {},
	ply       = LocalPlayer(),
	OrigHooks = false

}
function defcon.FireBullet()    RunConsoleCommand("+attack"); end
function defcon.EndFireBullet() RunConsoleCommand("-attack"); end

surface.CreateFont("ChatFont", {
    font = "Verdana",
    size = 15,
    weight = 600,
    antialias = true,
});

function defcon.NewConVar(Cvar, Default)
	if(Cvar != nil && Default != nil) then
		CreateClientConVar(Cvar, Default, true, false);
	end
end

function defcon.ChatAlert(text)
	chat.AddText(
			Color(255, 5, 48, 255),
			"[defcon] ",
			Color(69, 23, 255, 255),
			text
		);
end


        concommand.Add("+bhop",function()
                hook.Add("Think","hook",function()
                        RunConsoleCommand(((LocalPlayer():IsOnGround() or LocalPlayer():WaterLevel() > 0) and "+" or "-").."jump")
                end)
        end)

        concommand.Add("-bhop",function()
                RunConsoleCommand("-jump")
                hook.Remove("Think","hook")
        end)

function defcon.TriggerBot()
	defcon.Pos          = defcon.ply:GetShootPos();
	defcon.Ang          = defcon.ply:GetAimVector();
	defcon.Trace        = {};
	defcon.Trace.start  = defcon.Pos;
	defcon.Trace.endpos = defcon.Pos + (defcon.Ang * GetConVarNumber("def_triggerbot_distance"));
	defcon.Trace.filter = defcon.Ply;

	defcon.LTrace       = util.TraceLine(defcon.Trace);

	if(defcon.LTrace.HitNonWorld) then
		defcon.Target = defcon.LTrace.Entity;
		if(defcon.Target:IsPlayer()) then
			if(input.IsKeyDown(KEY_LALT) && GetConVarNumber("def_triggerbot") == 1 && defcon.Target != defcon.ply && defcon.Target:Alive() && defcon.Target:Health() > 0 && IsValid(defcon.Target)) then
				defcon.FireBullet();
				timer.Simple(0.001, function() defcon.EndFireBullet() end);
			end
		end
	end
end

function defcon.IsVisible(e)
	defcon.Tracer = {};
	if(LocalPlayer():GetShootPos() != nil && e != nil && IsValid(LocalPlayer():GetActiveWeapon()) && LocalPlayer():GetActiveWeapon() != nil && e:LookupBone("ValveBiped.Bip01_Head1") != nil && e:GetBonePosition(e:LookupBone("ValveBiped.Bip01_Head1")) != nil) then
		defcon.Tracer.start  = defcon.ply:GetShootPos();
		defcon.Tracer.endpos = e:GetBonePosition(e:LookupBone("ValveBiped.Bip01_Head1"));
		defcon.Tracer.filter = {defcon.ply, e};

		defcon.Tr = util.TraceLine(defcon.Tracer);
		if(defcon.Tr.Fraction >= 1) then
			return true;
		else
			return false;
		end
	end
end

function defcon.ESP()
	for k,v in pairs(player.GetAll()) do
		if(GetConVarNumber("def_esp") == 1 && v:Alive() && v:Health() > 0 && v != LocalPlayer()) then
			cam.Start3D();
				v:DrawModel();
			cam.End3D();

			defcon.PlyPos = v:EyePos():ToScreen();

			if(defcon.IsVisible(v)) then
				surface.SetDrawColor(Color(0, 255, 0, 255));
			else
				surface.SetDrawColor(Color(255, 0, 0, 255));
			end

			defcon.BoxMin, defcon.BoxMax = v:LocalToWorld(v:OBBMins()):ToScreen(), v:LocalToWorld(v:OBBMaxs()):ToScreen();

			surface.DrawLine(defcon.BoxMin.x, defcon.BoxMin.y, defcon.BoxMin.x, defcon.BoxMax.y);
			surface.DrawLine(defcon.BoxMax.x, defcon.BoxMin.y, defcon.BoxMax.x, defcon.BoxMax.y);
			surface.DrawLine(defcon.BoxMin.x, defcon.BoxMax.y, defcon.BoxMax.x, defcon.BoxMax.y);
			surface.DrawLine(defcon.BoxMin.x, defcon.BoxMin.y, defcon.BoxMax.x, defcon.BoxMin.y);

			draw.SimpleText("Name: " .. v:Nick(), "ChatFont", defcon.PlyPos.x, defcon.PlyPos.y - 30, team.GetColor(v:Team()), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT);
			draw.SimpleText("Health: " .. v:Health(), "ChatFont", defcon.PlyPos.x, defcon.PlyPos.y - 15, team.GetColor(v:Team()), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT);
		end
	end
end

function defcon.EntESP()
	for k,v in pairs(ents.GetAll()) do
		if(GetConVarNumber("def_entesp") == 1 && string.find(v:GetClass(), "weapon") or string.find(v:GetClass(), "printer") or string.find(v:GetClass(), "money")) then
			cam.Start3D();
				v:DrawModel();
			cam.End3D();
		end
	end
end

function defcon.TraitorFinder()
	for k,v in pairs(ents.GetAll()) do
		if(GetConVarNumber("def_traitoresp") == 1 && v && v.CanBuy && table.HasValue(v.CanBuy, ROLE_TRAITOR)) then
			defcon.Traitor = v:GetOwner()
			if(defcon.Traitor != LocalPlayer() && defcon.Traitor:IsValid() && defcon.Traitor != nil && !defcon.Traitor:IsDetective()) then
				defcon.TPos = defcon.Traitor:EyePos():ToScreen();
				draw.SimpleText("Traitor", "ChatFont", defcon.TPos.x, defcon.TPos.y, Color(255, 0, 0, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT);
				halo.Add({defcon.Traitor}, Color(255, 0, 0, 255), 1.5, 1.5, 2, true, true);
				if(bLeeb == false) then
					defcon.ChatAlert(defcon.Traitor:Nick() .. " Is a traitor");
				end
				bLeeb = true;
			end
		end
	end
end

function defcon.Aimbot()
	for k,v in pairs(player.GetAll()) do
		if(GetConVarNumber("def_aimbot") == 1 && v:Team() ~= LocalPlayer():Team() && v:Nick() ~= "λɖαɱ" && input.IsKeyDown(KEY_LALT) && v:Alive() && v:Health() > 0 && v ~= LocalPlayer() && defcon.IsVisible(v)) then
			local targethead = v:LookupBone("ValveBiped.Bip01_Head1") -- In this aimbot we only aim for the head.
			if(targethead != nil) then
				local targetheadpos,targetheadang = v:GetBonePosition(targethead) -- Get the position/angle of the head.
				LocalPlayer():SetEyeAngles((targetheadpos - LocalPlayer():GetShootPos()):Angle())
			end
		end
	end
end

hook.Add("Think", "lel", defcon.Aimbot)

defcon.Stealth = {
	RealFrameTime     = nil; -- Think
	DrawRecordingIcon = nil; -- HUDPaint
};


function defcon.Init()
	defcon.NewConVar("def_triggerbot", 1);
	defcon.NewConVar("def_namestealer", 0);
	defcon.NewConVar("def_triggerbot_distance", 3000);

	defcon.NewConVar("def_esp", 1);
	defcon.NewConVar("def_entesp", 1);
	defcon.NewConVar("def_traitoresp", 1);
	defcon.NewConVar("def_boundingbox", 1);
	defcon.NewConVar("def_aimbot", 1);

	defcon.NewConVar("def_boundingbox_mode", 1);
	defcon.NewConVar("def_esp_mode", 1);

	defcon.hook = table.Copy(hook);
	defcon.hook = nil;

	if(defcon.hook == nil) then
		defcon.ChatAlert("Unable to copy table: hook");
		defcon.ChatAlert("Using original hook table, Proceed with caution");

		defcon.OrigHooks = true;
		hook.Add("Think", "defcon.Aimbot", defcon.Aimbot)
		hook.Add("Think", "defcon.TriggerBot", defcon.TriggerBot);
		hook.Add("HUDPaint", "defcon.ESP", defcon.ESP);
		hook.Add("HUDPaint", "defcon.EntESP", defcon.EntESP);
		hook.Add("HUDPaint", "defcon.TraitorFinder", defcon.TraitorFinder);
	else
		defcon.OrigHooks = false;
		defcon.hook.Add("Think", "defcon.Aimbot", defcon.Aimbot);
		defcon.hook.Add("Think", "defcon.TriggerBot", defcon.TriggerBot);
		defcon.hook.Add("HUDPaint", "defcon.ESP", defcon.ESP);
		defcon.hook.Add("HUDPaint", "defcon.EntESP", defcon.EntESP);
		defcon.hook.Add("HUDPaint", "defcon.TraitorFinder", defcon.TraitorFinder);
	end

	//defcon.HideHooks("defcon");
end

--[[

	Usage:
		defcon.hook.Add("Think", "defcon.TriggerBot", defcon.TriggerBot);
		-- Add other hooks here
		defcon.HideHooks("defcon.");

]]--

function defcon.HideHooks(prefix)
	defcon.StealHookName = nil;
	defcon.EventName     = nil;
	defcon.Function      = nil;
	for Event, Table in pairs(hook.Hooks) do
		for Name, Function in pairs(Table) do
			if(string.find(Name, prefix)) then
				if(defcon.OrigHooks == nil) then
					hook.Remove(Event, Name);
				else
					hook.Remove(Event, Name);
				end
				defcon.EventName = Event;
				defcon.Function = Function;
			elseif(Event == defcon.EventName) then
				defcon.StealHookName = Name;
			end
		end
	end
	if(defcon.OrigHooks == nil) then
		hook.Add(defcon.EventName, defcon.StealHookName, defcon.Function);
	else
		defcon.hook.Add(defcon.EventName, defcon.StealHookName, defcon.Function);
	end
end

concommand.Add("+defcon_speedhack", function()
	RunConsoleCommand("host_framerate", "10");
end)

concommand.Add("-defcon_speedhack", function()
	RunConsoleCommand("host_framerate", "0");
end)

defcon.Init();

for k,v in pairs(player.GetAll()) do
	print(v:Nick() .. ": " .. v:SteamID())
end