--[[
	estrogen.lua

	created by flarose
	just for testing my module
]]

require("panchiko")

local g_pLocalPlayer = LocalPlayer()
local g_pActiveWeapon = g_pLocalPlayer:GetActiveWeapon()
local g_bSendPacket = true

local g_tWeaponSpreadSeeds = {}
local g_tWeaponSpreadCones = {}

local color_white = Color(255, 255, 255)
local color_black = Color(0, 0, 0)
local color_red = Color(255, 0, 0)
local color_blue = Color(0, 0, 255)
local color_green = Color(0, 255, 0)
local color_orange = Color(255, 150, 0)
local color_gray = Color(175, 175, 175)
local color_pink = Color(255, 0, 200)
local color_crimson = Color(175, 0, 42)
local color_lavender = Color(165, 125, 255)
local color_purple = Color(125, 0, 255)
local color_teal = Color(0, 180, 180)
local color_seafoam = Color(201, 255, 229)

local FLOW_INCOMING = panchiko.FLOW_INCOMING
local FLOW_OUTGOING = panchiko.FLOW_OUTGOING

local HITGROUP_FIRST = HITGROUP_GENERIC
local HITGROUP_COUNT = HITGROUP_RIGHTLEG

local Primary_Mode = 0
local Secondary_Mode = 1

local INT_MAX = math.huge
local M_HPI = math.pi

local swcs_weapon_sync_seed = GetConVar("swcs_weapon_sync_seed")
local weapon_debug_inaccuracy_only_up = GetConVar("weapon_debug_inaccuracy_only_up")
local weapon_debug_max_inaccuracy = GetConVar("weapon_debug_max_inaccuracy")

local function Log(String, ...)
	MsgC(color_gray, "[", color_lavender, "Estrogen", color_gray, "] ", color_gray, string.format(String, ...))
	MsgN()
end

local EVisuals = {}
local ECreateMove = {}
ECreateMove.m_flServerTime = 0
ECreateMove.m_bCanShoot = false

local EAccuracy = {}
local ERagebot = {}

local EHitboxManager = {}
EHitboxManager.m_tModelData = {}

local EModelData = {}
EModelData.__index = EModelData

setmetatable(EModelData, {
	__call = function(cls, ...)
		local this = setmetatable({}, cls)
		this:_EModelData(...)
		return this
	end,
})

function EModelData:_EModelData()
	self.m_bIsValid = false
	self.m_tHitboxSets = {}

	for iHitGroup = HITGROUP_FIRST, HITGROUP_COUNT do
		self.m_tHitboxSets[iHitGroup] = {}
	end
end

function EModelData:IsValid()
	return self.m_bIsValid
end

--[[
	Hitbox Manager
]]

function EHitboxManager:ParseModelData(pEntity, strModel)
	if not isstring(strModel) or strModel == "" then
		print(string.format("model for %s is invalid", pEntity))
		return
	end

	pEntity:InvalidateBoneCache()
	pEntity:SetupBones()

	local iBoneCount = pEntity:GetBoneCount()
	if not iBoneCount or iBoneCount < 0 then
		Log("model doesnt have enough bones for %s", pEntity)
		return
	end

	local iHitboxSetCount = pEntity:GetHitboxSetCount()
	if not iHitboxSetCount or iHitboxSetCount == 0 then
		Log("model doesnt have any hitboxes for %s", pEntity)
		return
	end

	local pModelData = self.m_tModelData[strModel]
	if not pModelData then
		pModelData = EModelData()
		self.m_tModelData[strModel] = pModelData
	end

	local pHitboxSets = pModelData.m_tHitboxSets

	for iHitboxSet = 0, iHitboxSetCount - 1 do
		for iHitbox = 0, pEntity:GetHitBoxCount(iHitboxSet) - 1 do
			local iBone = pEntity:GetHitBoxBone(iHitbox, iHitboxSet)

			if pEntity:BoneHasFlag(iBone, BONE_PHYSICALLY_SIMULATED) or pEntity:BoneHasFlag(iBone, BONE_PHYSICS_PROCEDURAL) or pEntity:BoneHasFlag(iBone, BONE_ALWAYS_PROCEDURAL) then
				Log("bone %s has fucked flags; ignoring bone from %s", iBone, pEntity)
				continue
			end

			local iHitGroup = pEntity:GetHitBoxHitGroup(iHitbox, iHitboxSet)
			if iHitGroup == HITGROUP_GEAR then
				continue
			end

			local vBoxMins, vBoxMaxs = pEntity:GetHitBoxBounds(iHitbox, iHitboxSet)
			local vSize = vBoxMins - vBoxMaxs

			table.insert(pHitboxSets[iHitGroup], {
				m_iBone = iBone,

				m_flVolume = math.abs(vSize.x * vSize.y * vSize.z),
				m_vCenter = (vBoxMins + vBoxMaxs) * 0.5,

				m_vMins = vBoxMins,
				m_vMaxs = vBoxMaxs,

				m_tCorners = { -- insert points so you dont miss and look STUPID
					Vector(vBoxMins.x + 1, vBoxMins.y + 1, vBoxMins.z + 1),
					Vector(vBoxMaxs.x - 1, vBoxMaxs.y - 1, vBoxMaxs.z - 1),
					Vector(vBoxMins.x + 1, vBoxMins.y + 1, vBoxMaxs.z - 1),
					Vector(vBoxMaxs.x - 1, vBoxMins.y + 1, vBoxMaxs.z - 1),
					Vector(vBoxMaxs.x - 1, vBoxMaxs.y - 1, vBoxMins.z + 1),
					Vector(vBoxMaxs.x - 1, vBoxMins.y + 1, vBoxMins.z + 1),
					Vector(vBoxMins.x + 1, vBoxMaxs.y - 1, vBoxMins.z + 1),
					Vector(vBoxMins.x + 1, vBoxMaxs.y - 1, vBoxMaxs.z - 1)
				}
			})
		end
	end

	for _, pHitboxes in pairs(pHitboxSets) do
		table.sort(pHitboxes, function(lhs, rhs)
			return lhs.m_flVolume > rhs.m_flVolume
		end)
	end

	pModelData.m_bIsValid = true
	Log("Parsed %s hitbox data sucessfully", strModel)
end

function EHitboxManager:GetModelData(pEntity)
	local strModel = pEntity:GetModel()

	if not self.m_tModelData[strModel] then
		self:ParseModelData(pEntity, strModel)
	end

	return self.m_tModelData[strModel]
end

timer.Simple(0, function() -- initalize
	for _, v in pairs(player.GetAll()) do
		local strModel = v:GetModel()

		EHitboxManager:ParseModelData(v, strModel)
	end
end)

--[[
	Math
]]

local function fsel(c, x, y)
	return c >= 0 and x or y
end

local function RemapValClamped(val,a,b,c,d)
	if a == b then
		return fsel(val - b, d, c)
	end

	local cVal = (val - a) / (b - a)
	cVal = math.Clamp(cVal, 0, 1)

	return c + (d - c) * cVal
end

--[[
	CUniformRandomStream
]]

local UniformRandomStream
do
	local META = {
		m_iv = {}, -- array, size == NTAB
	}

	META.__index = META
	META.__tostring = function(self)
		return "UniformRandomStream [" .. self.m_idum .. "]"
	end

	function UniformRandomStream(seed)
		local obj = setmetatable({}, META)
		obj:SetSeed(tonumber(seed) or 0)

		return obj
	end

	-- https://github.com/VSES/SourceEngine2007/blob/master/src_main/vstdlib/random.cpp#L16

	local IA = 16807
	local IM = 2147483647
	local IQ = 127773
	local IR = 2836
	local NTAB = 32
	local NDIV = (1 + (IM - 1) / NTAB)
	local MAX_RANDOM_RANGE = 0x7FFFFFFF

	-- fran1 -- return a random floating-point number on the interval [0,1])
	local AM = (1 / IM)
	local EPS = 1.2e-7
	local RNMX = (1 - EPS)

	function META:SetSeed(iSeed)
		self.m_idum = iSeed < 0 and iSeed or -iSeed
		self.m_iy = 0
	end

	local int = math.floor
	function META:GenerateRandomNumber()
		local j, k
		if (self.m_idum <= 0 or not self.m_iy) then
			if (-self.m_idum < 1) then
				self.m_idum = 1
			else
				self.m_idum = -self.m_idum
			end

			j = NTAB + 8
			while true do
				if j <= 0 then break end
				j = j - 1

				k = int(self.m_idum / IQ)
				self.m_idum = int(IA * (self.m_idum-k * IQ) - IR * k)
				if (self.m_idum < 0)  then
					self.m_idum = int(self.m_idum + IM)
				end
				if (j < NTAB) then
					self.m_iv[j] = int(self.m_idum)
				end
			end
			self.m_iy = self.m_iv[0]
		end

		k = int(self.m_idum / IQ)
		self.m_idum = int(IA * (self.m_idum-k * IQ) - IR * k)
		if (self.m_idum < 0) then
			self.m_idum = int(self.m_idum + IM)
		end
		j = int(self.m_iy / NDIV)

		if (j >= NTAB or j < 0) then
			ErrorNoHalt(string.format("CUniformRandomStream had an array overrun: tried to write to element %d of 0..31.", j))
			j = int(bit.band( j % NTAB, 0x7fffffff))
		end

		self.m_iy = int(self.m_iv[j])
		self.m_iv[j] = int(self.m_idum)

		return self.m_iy
	end

	function META:RandomFloat(flLow, flHigh)
		flLow = flLow or 0
		flHigh = flHigh or 1

		local fl = AM * self:GenerateRandomNumber()
		if fl > RNMX then
			fl = RNMX
		end

		return (fl * ( flHigh - flLow ) ) + flLow -- float in [low,high]
	end

	function META:RandomFloatExp(flMinVal, flMaxVal, flExponent)
		flMinVal = flMinVal or 0
		flMaxVal = flMaxVal or 1
		flExponent = flExponent or 1

		local fl = AM * self:GenerateRandomNumber()
		fl = math.min(fl, RNMX)

		if flExponent ~= 1 then
			fl = math.pow(fl, flExponent)
		end

		return (fl * ( flMaxVal - flMinVal ) ) + flMinVal
	end

	function META:RandomInt(iLow, iHigh)
		iLow = iLow or 0 iHigh = iHigh or 100
		iLow = math.floor(iLow) iHigh = math.floor(iHigh)
		local iMaxAcceptable, n
		local x = iHigh - iLow + 1

		if x <= 1 or MAX_RANDOM_RANGE < x-1 then
			return iLow
		end

		iMaxAcceptable = math.floor(MAX_RANDOM_RANGE - ((MAX_RANDOM_RANGE + 1) % x ))
		n = self:GenerateRandomNumber()
		while n > iMaxAcceptable do
			n = self:GenerateRandomNumber()
		end

		return iLow + (n % x)
	end
end

do
	local VECTOR_CONE_1DEGREES	= Vector( 0.00873, 0.00873, 0.00873 )
	local VECTOR_CONE_3DEGREES	= Vector( 0.02618, 0.02618, 0.02618 )
	local VECTOR_CONE_5DEGREES	= Vector( 0.04362, 0.04362, 0.04362 )
	local VECTOR_CONE_6DEGREES	= Vector( 0.05234, 0.05234, 0.05234 )
	local VECTOR_CONE_10DEGREES   = Vector( 0.08716, 0.08716, 0.08716 )

	local ai_shot_bias_min = GetConVar("ai_shot_bias_min")
	local ai_shot_bias_max = GetConVar("ai_shot_bias_max")

	local rand = UniformRandomStream()

	for iSeed = 0, 255 do
		rand:SetSeed(iSeed)

		local x,y,z = 0, 0, 0
		local bias = 1

		local shotBiasMin = ai_shot_bias_min:GetFloat()
		local shotBiasMax = ai_shot_bias_max:GetFloat()

		local shotBias = ((shotBiasMax - shotBiasMin) * bias) + shotBiasMin
		local flatness = math.abs(shotBias) * 0.5

		repeat
			x = rand:RandomFloat(-1, 1) * flatness + rand:RandomFloat(-1, 1) * (1 - flatness)
			y = rand:RandomFloat(-1, 1) * flatness + rand:RandomFloat(-1, 1) * (1 - flatness)

			if shotBias < 0 then
				x = (x >= 0) and 1.0 - x or -1.0 - x
				y = (y >= 0) and 1.0 - y or -1.0 - y
			end

			z = (x * x) + (y * y)
		until z <= 1

		g_tWeaponSpreadSeeds[iSeed] = {
			X = x,
			Y = y,
			Z = z
		}
	end

	g_tWeaponSpreadCones = {
		weapon_smg1 = VECTOR_CONE_5DEGREES,
		weapon_ar2 = VECTOR_CONE_3DEGREES,
		weapon_357 = vector_origin,
		weapon_pistol = function(wep)
			local nv = wep:GetInternalVariable("m_flAccuracyPenalty")
			local ramp = RemapValClamped(nv, 0, 1.5, 0, 1)
			local cone = LerpVector(ramp, VECTOR_CONE_1DEGREES, VECTOR_CONE_6DEGREES)

			return cone
		end,
		weapon_shotgun = VECTOR_CONE_10DEGREES,

		-- hl1 weapons
		weapon_357_hl1 = VECTOR_CONE_1DEGREES,
		weapon_mp5_hl1 = VECTOR_CONE_3DEGREES,
		weapon_gauss = vector_origin,
		weapon_glock_hl1 = function(wep)
			if g_pLocalPlayer:KeyDown(IN_ATTACK2) then
				return Vector(0.1, 0.1, 0.1)
			end

			return Vector(0.01, 0.01, 0.01)
		end,
		weapon_shotgun_hl1 = function(wep)
			if g_pLocalPlayer:KeyDown(IN_ATTACK2) then
				return Vector(VECTOR_CONE_10DEGREES.x * 2, VECTOR_CONE_10DEGREES.x / 2)
			end

			return Vector(VECTOR_CONE_10DEGREES.x, VECTOR_CONE_10DEGREES.x / 2)
		end
	}
end

--[[
	Accuracy
]]

function EAccuracy:GetHeuristicSpreadAngles(pUserCmd, qTargetAngles)
	local vSpread = g_tWeaponSpreadCones[g_pActiveWeapon:GetClass()]
	if not vSpread then return qTargetAngles end

	if isfunction(vSpread) then
		vSpread = vSpread(g_pActiveWeapon)
	end

	local Seed = panchiko.GetRandomSeed(pUserCmd)

	local X = g_tWeaponSpreadSeeds[Seed].X
	local Y = g_tWeaponSpreadSeeds[Seed].Y

	local vForward = qTargetAngles:Forward()
	local vRight = qTargetAngles:Right()
	local vUp = qTargetAngles:Up()

	local SpreadVector = vForward + (X * vSpread.x * vRight * -1) + (Y * vSpread.y * vUp * -1)

	local vSpreadAng = SpreadVector:Angle()
	vSpreadAng:Normalize()

	return vSpreadAng
end

function EAccuracy:GetCW20SpreadAngles(pUserCmd, qTargetAngles)
	local flCurCone = 0.09 + g_pActiveWeapon.MaxSpreadInc

	--local angFlip = pUserCmd:GetViewAngles()
	--if pUserCmd:TickCount() % 2 == 0 then
	--	angFlip:Mul(-1)
	--end
	--
	--pUserCmd:SetInWorldClicker(true)
	--pUserCmd:SetWorldClickerAngles(angFlip:Right())

	math.randomseed(g_pActiveWeapon.IsFAS2Weapon and CurTime() or pUserCmd:CommandNumber())
	local x = math.Rand(-flCurCone, flCurCone) * 25
	local y = math.Rand(-flCurCone, flCurCone) * 25

	return qTargetAngles - Angle(x, y)
end

local arccw_desync = GetConVar("arccw_desync")
function EAccuracy:GetArcCWSpreadAngles(pUserCmd, qTargetAngles, flMultiplier)
	local qDirection = qTargetAngles:Forward()

	local flSeed1 = g_pActiveWeapon:GetBurstCount()
	local flSeed2 = not game.SinglePlayer() and pUserCmd:CommandNumber() or CurTime()

	local flSpread = ArcCW.MOAToAcc * g_pActiveWeapon:GetBuff("AccuracyMOA")
	local flDispersion = g_pActiveWeapon:GetDispersion() * ArcCW.MOAToAcc / 10

	local flRandomSeed = util.SharedRandom(flSeed1, -1337, 1337, flSeed2) * (g_pActiveWeapon:EntIndex() % 30241)

	local desync = arccw_desync:GetBool()
	local desyncnum = (desync and math.random()) or 0
	math.randomseed(math.Round(flRandomSeed) + desyncnum)

	g_pActiveWeapon:ApplyRandomSpread(qDirection, flDispersion * flMultiplier)

	local flRandomSeed2 = util.SharedRandom(1, -1337, 1337, flSeed2) * (g_pActiveWeapon:EntIndex() % 30241)
	math.randomseed(math.Round(flRandomSeed2) + desyncnum)

	g_pActiveWeapon:ApplyRandomSpread(qDirection, flSpread * flMultiplier)

	local qSpreadAng = qDirection:Angle()
	qSpreadAng:Normalize()

	return qSpreadAng
end

function EAccuracy:GetSWCSSpreadAngles(qTargetAngles)
	if not swcs_weapon_sync_seed:GetBool() then
		Log("swcs nospread will not work")
		return qTargetAngles
	end

	local iSeed = g_pActiveWeapon:GetRandomSeed()
	iSeed = iSeed + 1

	local fInaccuracy = g_pActiveWeapon:GetInaccuracy(false)

	local rand = UniformRandomStream(iSeed) -- init random system with this seed

	local flRadiusCurveDensity = rand:RandomFloat()
	if g_pActiveWeapon.IsR8Revolver and g_pActiveWeapon:GetWeaponMode() == Secondary_Mode then -- R8 REVOLVER SECONDARY FIRE
		flRadiusCurveDensity = 1 - (flRadiusCurveDensity * flRadiusCurveDensity)
	elseif g_pActiveWeapon.IsNegev and g_pActiveWeapon:GetRecoilIndex() < 3 then -- NEGEV WILD BEAST
		for j = 3, g_pActiveWeapon:GetRecoilIndex(), -1 do
			flRadiusCurveDensity = flRadiusCurveDensity * flRadiusCurveDensity
		end

		flRadiusCurveDensity = 1 - flRadiusCurveDensity
	end

	if weapon_debug_max_inaccuracy:GetBool() then
		flRadiusCurveDensity = 1
	end

	-----------------------------------------------------------------

	-- Get accuracy displacement
	local fTheta0 = rand:RandomFloat(0, 2 * M_HPI)
	if weapon_debug_inaccuracy_only_up:GetBool() then
		fTheta0 = M_HPI * 0.5
	end

	local fRadius0 = flRadiusCurveDensity * fInaccuracy
	local x0 = fRadius0 * math.cos(fTheta0)
	local y0 = fRadius0 * math.sin(fTheta0)

	local fTheta1 = 0
	local flSpreadCurveDensity = rand:RandomFloat()

	if g_pActiveWeapon:GetIsRevolver() and g_pActiveWeapon:GetWeaponMode() == Secondary_Mode then
		flSpreadCurveDensity = 1 - (flSpreadCurveDensity * flSpreadCurveDensity)
	elseif g_pActiveWeapon.IsNegev and g_pActiveWeapon:GetRecoilIndex() < 3 then
		for j = 3, g_pActiveWeapon:GetRecoilIndex(), -1 do
			flSpreadCurveDensity = flSpreadCurveDensity * flSpreadCurveDensity
		end

		flSpreadCurveDensity = 1 - flSpreadCurveDensity
	end

	--if weapon_accuracy_shotgun_spread_patterns:GetBool() then
	--	fTheta1, flSpreadCurveDensity = g_pActiveWeapon:GetSpreadOffset(rand, math.floor(iBullet + (g_pActiveWeapon:GetBullets() * g_pActiveWeapon:GetRecoilIndex()) - 1))
	--else
		flSpreadCurveDensity = rand:RandomFloat()
		fTheta1 = rand:RandomFloat(0, 2 * M_HPI)
	--end

	local fRadius1 = flSpreadCurveDensity * g_pActiveWeapon:GetSpread()
	local x1 = x0 + fRadius1 * math.cos(fTheta1)
	local y1 = y0 + fRadius1 * math.sin(fTheta1)

	-- 
	local angShooting = g_pActiveWeapon:GetFinalAimAngle()
	local vecDirShooting, vecRight, vecUp = angShooting:Forward(), angShooting:Right(), angShooting:Up()

	-- do spread comp
	local xSpread, ySpread = x1, y1

	local vecDir = vecDirShooting + (xSpread * vecRight) + (ySpread * vecUp)
	vecDir:Normalize()

	local temp = vecDirShooting:Angle() - vecDir:Angle()
	temp:Normalize()

	return qTargetAngles + temp
end

function EAccuracy:GetSpreadAngles(pUserCmd, qTargetAngles)
	local qAngSpread = Angle(qTargetAngles)

	if g_pActiveWeapon.IsSWCSWeapon then
		qAngSpread:Set(self:GetSWCSSpreadAngles(qTargetAngles))
	elseif g_pActiveWeapon.CW20Weapon or g_pActiveWeapon.IsFAS2Weapon then
		qAngSpread:Set(self:GetCW20SpreadAngles(pUserCmd, qTargetAngles))
	elseif g_pActiveWeapon.ArcCW then
		qAngSpread:Set(self:GetArcCWSpreadAngles(pUserCmd, qTargetAngles, -1))
	else
		qAngSpread:Set(self:GetHeuristicSpreadAngles(pUserCmd, qTargetAngles))
	end

	return qAngSpread
end

function EAccuracy:GetRecoilAngles()
	local viewpunch = Angle(angle_zero)

	if not g_pActiveWeapon:IsScripted() then
		local angViewPunch = g_pLocalPlayer:GetViewPunchAngles()

		if self.m_bShouldDecay then
			angViewPunch:Set(g_qPunchAngle)
		end

		if hWeapon:GetClass() == "weapon_pistol" then
			angViewPunch:Set(angle_zero)
		end

		viewpunch:Set(angViewPunch)
	elseif g_pActiveWeapon.IsSWCSWeapon then
		if self.m_bShouldDecay then
			hWeapon:DecayAimPunchAngle()
			hWeapon:UpdateAccuracyPenalty()
		end

		local qPunchAngles = hWeapon:GetAimPunchAngle()
		qPunchAngles:Normalize()

		viewpunch:Set(qPunchAngles)
	elseif g_pActiveWeapon.CW20Weapon or g_pActiveWeapon.IsFAS2Weapon then
		local vp = g_pLocalPlayer:GetViewPunchAngles()
		if self.m_bShouldDecay then
			vp = Angle(g_qPunchAngle)
		else
			vp = g_pLocalPlayer:GetViewPunchAngles()
		end

		viewpunch:Set(vp)
	end

	return viewpunch
end

--[[
	Aimbot
]]

function ERagebot:IsValidTarget(pEntity)
	if not IsValid(pEntity) or pEntity == g_pLocalPlayer then return false end

	if pEntity:IsPlayer() then
		if not pEntity:Alive() then return false end
	elseif pEntity:IsNPC() then
		if pEntity:GetClass() == "npc_turret_floor" then return false end
		if pEntity:GetClass() == "npc_furniture" then return false end
		if pEntity:Health() <= 0 then return false end
	elseif pEntity:IsNextBot() then
		if pEntity:Health() <= 0 then return false end
	end

	return true
end

function ERagebot:Run(pUserCmd)
	if not input.IsButtonDown(KEY_F) or not ECreateMove.m_bCanShoot or panchiko.GetChockedPackets() > 1 then
		return
	end

	local vShootPos = g_pLocalPlayer:GetShootPos()
	local vAimVector = pUserCmd:GetViewAngles():Forward()

	local trResult = {}
	local trData = {
		start = Vector(),
		endpos = Vector(),
		mask = MASK_SHOT,
		filter = {g_pLocalPlayer},

		output = trResult
	}

	local pRayStart = trData.start
	local pRayEnd = trData.endpos

	pRayStart:Set(vShootPos)

	local flFovRadius = math.rad(189.9)
	local flMaxCosTheta = math.cos(flFovRadius)

	for idx, pEntity in pairs(ents.GetAll()) do
		if pEntity:IsDormant() or not self:IsValidTarget(pEntity) then
			continue
		end

		local pModelData = EHitboxManager:GetModelData(pEntity)
		if not pModelData:IsValid() then
			continue
		end

		pEntity:InvalidateBoneCache()
		pEntity:SetupBones()

		local pHitboxSets = pModelData.m_tHitboxSets
		for iHitGroup, pHitboxes in pairs(pHitboxSets) do
			if iHitGroup ~= HITGROUP_HEAD then
				continue
			end

			for iHitbox, pHitbox in pairs(pHitboxes) do
				local pBoneToWorld = pEntity:GetBoneMatrix(pHitbox.m_iBone)
				if not pBoneToWorld then
					continue
				end

				local vTranslation, qOrientation = pBoneToWorld:GetTranslation(), pBoneToWorld:GetAngles()

				local vHitboxCenter = Vector(pHitbox.m_vCenter)
				vHitboxCenter:Rotate(qOrientation)
				vHitboxCenter:Add(vTranslation)

				local vShooterToHitbox = vHitboxCenter - vShootPos
				vShooterToHitbox:Normalize()

				local flCosTheta = vAimVector:Dot(vShooterToHitbox)
				if flCosTheta < flMaxCosTheta then
					continue
				end

				pRayEnd:Set(pRayStart + vShooterToHitbox * 8192)

				util.TraceLine(trData)

				if not trResult.Hit or trResult.Entity ~= pEntity or trResult.HitGroup ~= iHitGroup then
					continue
				end

				local qAngShooting = vShooterToHitbox:Angle()
				qAngShooting:Sub(EAccuracy:GetSpreadAngles(pUserCmd, qAngShooting))
				qAngShooting:Sub(EAccuracy:GetRecoilAngles())
				pUserCmd:SetViewAngles(qAngShooting)

				pUserCmd:RemoveKey(IN_USE)
				pUserCmd:AddKey(IN_ATTACK)
			end
		end
	end
end

--[[
	CreateMove
]]

function ECreateMove:PreCreateMove(pUserCmd)
	self.m_bCanShoot = false
	self.m_flServerTime = panchiko.GetServerTime(pUserCmd)
	self.m_iCommandNumber = pUserCmd:CommandNumber()
	self.m_bIsPredicted = self.m_iCommandNumber == 0

	g_pLocalPlayer = LocalPlayer()
	g_pActiveWeapon = g_pLocalPlayer:GetActiveWeapon()

	g_bSendPacket = true

	if IsValid(g_pActiveWeapon) then
		local flClip1 = g_pActiveWeapon:Clip1()
		if flClip1 <= 0 and flClip1 ~= 1 then
			return
		end

		local flNextPrimaryAttack = g_pActiveWeapon:GetNextPrimaryFire()

		if g_pActiveWeapon.IsSWCSWeapon then
			if g_pActiveWeapon:GetHasBurstMode() and g_pActiveWeapon:GetBurstShotsRemaining() > 0 then
			flNextPrimaryAttack = g_pActiveWeapon:GetNextBurstShot()
		end

			local flCycleTime = g_pActiveWeapon:GetCycleTime()
			flNextPrimaryAttack = g_pActiveWeapon:GetNextPrimaryFire(flCycleTime)
		end

		self.m_bCanShoot = self.m_flServerTime >= flNextPrimaryAttack
	end
end

function ECreateMove:OnCreateMove(pUserCmd)
	if not self.m_bIsSimulated then
		--local qOriginalView = pUserCmd:GetViewAngles()

		panchiko.UpdatePrediction()

		panchiko.StartPrediction(pUserCmd)
			ERagebot:Run(pUserCmd)
		panchiko.EndPrediction()
	end
end

function ECreateMove:PostCreateMove(pUserCmd)
	if not self.m_bIsPredicted then
		--panchiko.SetSendPacket(g_bSendPacket)

		--RotateMovement(pUserCmd)
	end
end

--[[
	Visuals
]]

local SCREEN_WIDTH = ScrW()
local SCREEN_HEIGHT = ScrH()

local VERTEX_MATRIX = {
	Vector(-1, -1, -1),
	Vector(-1, -1, 1),
	Vector(-1, 1, -1),
	Vector(-1, 1, 1),
	Vector(1, -1, -1),
	Vector(1, -1, 1),
	Vector(1, 1, -1),
	Vector(1, 1, 1)
}
function EVisuals:GetScreenCorners(entity, box) -- black p screen corners
	local pos = entity:GetPos()
	local mins, maxs = entity:GetCollisionBounds()
	local size = (maxs - mins) * 0.5
	local box_center = pos + (mins + maxs) * 0.5

	local x, y = INT_MAX, INT_MAX
	local w, h = -x, -y

	for i = 1, 8 do
		local corner = (box_center + VERTEX_MATRIX[i] * size):ToScreen()

		if corner.x < x then x = corner.x end
		if corner.y < y then y = corner.y end
		if corner.x > w then w = corner.x end
		if corner.y > h then h = corner.y end
	end

	if w <= 0 or h <= 0 or x >= SCREEN_WIDTH or y >= SCREEN_HEIGHT then
		return false
	end

	w = w - x
	h = h - y

	if w < 1 or h < 1 then
		return false
	end

	box.x = x
	box.y = y
	box.w = w
	box.h = h

	return true
end

function EVisuals:Draw()
	--local color = Color(255, 255, 255, 255)

	local pCurrentView = render.GetViewSetup(true)

	local vCameraPos = pCurrentView.origin
	local vCameraDir = pCurrentView.angles:Forward()
	local flMinCosTheta = math.cos(math.rad(pCurrentView.fov * 0.5))

	for idx, pEntity in pairs(ents.GetAll()) do
		local bIsPlayer = pEntity:IsPlayer()

		if bIsPlayer and pEntity:GetObserverMode() ~= OBS_MODE_NONE and pEntity:GetObserverTarget() == g_pLocalPlayer then
			continue
		end

		if pEntity:IsDormant() or not (bIsPlayer or pEntity:IsNextBot() or pEntity:IsNPC()) or pEntity:Health() <= 0 then
			continue
		end

		local vCameraToEntity = (pEntity:GetPos() - vCameraPos):GetNormalized()
		if vCameraDir:Dot(vCameraToEntity) <= flMinCosTheta then
			continue
		end

		local szName = "Entity"
		local colRender = Color(255, 255, 255, 255)
		if bIsPlayer then
			szName = pEntity:GetName()
			colRender = Color(255, 0, 0, 255)
		elseif pEntity.bIsZombie then
			szName = "Zombie"
			colRender = Color(0, 0, 255, 255)
		end

		local box = {}
		local bSuscess = EVisuals:GetScreenCorners(pEntity, box)
		if not bSuscess then
			continue
		end

		surface.SetDrawColor(0, 0, 0, colRender.a)
		surface.DrawOutlinedRect(box.x + 1, box.y + 1, box.w, box.h)

		surface.SetDrawColor(colRender)
		surface.DrawOutlinedRect(box.x, box.y, box.w, box.h)

		draw.SimpleText(szName, "DebugOverlay", box.x + box.w, box.y, colRender, TEXT_ALIGN_CENTER, TEXT_ALIGN_BOTTOM)
	end
end

--[[
	Hooks
]]

hook.Add("EntityFireBullet", "estrogen", function(pEntity, Data)
	if pEntity ~= g_pLocalPlayer then return end
	if not IsFirstTimePredicted() then return end

	if not IsValid(g_pActiveWeapon) then return end

	local vCurrentSpread = Data.Spread
	if isvector(vCurrentSpread) and not vCurrentSpread:IsZero() then
		g_tWeaponSpreadCones[g_pActiveWeapon.strClass] = vCurrentSpread
	end
end)

hook.Add("Tick", "estrogen", function()

end)

hook.Add("HUDPaint", "estrogen", function()
	EVisuals:Draw()
end)

hook.Add("CreateMove", "estrogen", function(pUserCmd)
	--ECreateMove:PreCreateMove(pUserCmd)
	--ECreateMove:OnCreateMove(pUserCmd)
	--ECreateMove:PostCreateMove(pUserCmd)
end)

concommand.Add("unload", function()
	hook.Remove("HUDPaint", "estrogen")
	hook.Remove("CreateMove", "estrogen")
end)