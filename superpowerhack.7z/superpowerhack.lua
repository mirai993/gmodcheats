notification.AddLegacy("Successfully Loaded SuperPower Hack - Welcome " .. LocalPlayer():Nick() .. " | " .. os.date("%I:%M %p"), NOTIFY_HINT, 5)
local SuperPower = {}
--
--
--Config
--
--
-- Debug Messages
SuperPower.Debug = 1
-- Target people with low hp first
SuperPower.HasLowHp = true
SuperPower.AutoAttack = false
--
--
--Config
--
--
--Cant copy--
local _GTbl = table.Copy(_G)
local table = _GTbl.table.Copy(_GTbl.table)
local playerz = _GTbl.table.Copy(player.GetAll())
local pairs = _GTbl.pairs
local hook = _GTbl.hook
local util = _GTbl.util
local LocalPlayer = _GTbl.LocalPlayer
local debug = _GTbl.debug
local Vector = _GTbl.Vector
--TableCopy--
--
local t = debug.getregistry()
local Func = {}
function Func:Copy(tbl, func, copy)
	tbl[func] = copy
end
 
--
Func:Copy(Func, "print", _GTbl.print)
function Func:Read(tbl, copy)
	return tbl[copy]
end
 
--
function SuperPower:DebugLog(msg)
	if SuperPower.Debug == 1 then Func:Read(Func, "print")(msg) end
end
 
SuperPower:DebugLog("Welcome to SuperPower H4X")
SuperPower.Players = function() return playerz end
function SuperPower:ISValidTarg(ply)
	local targethead = ply:LookupBone("ValveBiped.Bip01_Head1")
	local targetheadpos = ply:GetBonePosition(targethead)
	local trace = {
		start = LocalPlayer():GetShootPos(),
		endpos = targetheadpos,
		filter = {LocalPlayer(), ply}
	}
 
	local tr = util.TraceLine(trace)
	if tr.Fraction == 1 then
		return true
	else
		return false
	end
end
 
function SuperPower:FindTarg()
	local dist = 10000000
	local targ = NULL
	local targHP = 100
	for k, v in pairs(player.GetAll()) do
		if SuperPower.HasLowHp == true then
			if v ~= LocalPlayer() and v:Health() > 0 and v:Health() <= targHP and SuperPower:ISValidTarg(v) and not v:HasGodMode() and v:GetObserverMode() == 0 then
				targ = v
				targHP = v:Health()
			end
		elseif SuperPower.HasLowHp == false then
			if v:GetPos():Distance(LocalPlayer():GetPos()) < dist and v ~= LocalPlayer() and v:Health() > 0 and SuperPower:ISValidTarg(v) and not v:HasGodMode() and v:GetObserverMode() == 0 then
				dist = v:GetPos():Distance(LocalPlayer():GetPos())
				targ = v
			end
		end
	end
	return {
		Target = targ,
		Distance = dist,
		Health = targHP
	}
end
 
local bones = {
	{
		S = "ValveBiped.Bip01_Head1",
		E = "ValveBiped.Bip01_Neck1"
	},
	{
		S = "ValveBiped.Bip01_Neck1",
		E = "ValveBiped.Bip01_Spine4"
	},
	{
		S = "ValveBiped.Bip01_Spine4",
		E = "ValveBiped.Bip01_Spine2"
	},
	{
		S = "ValveBiped.Bip01_Spine2",
		E = "ValveBiped.Bip01_Spine1"
	},
	{
		S = "ValveBiped.Bip01_Spine1",
		E = "ValveBiped.Bip01_Spine"
	},
	{
		S = "ValveBiped.Bip01_Spine",
		E = "ValveBiped.Bip01_Pelvis"
	},
	{
		S = "ValveBiped.Bip01_Spine2",
		E = "ValveBiped.Bip01_L_UpperArm"
	},
	{
		S = "ValveBiped.Bip01_L_UpperArm",
		E = "ValveBiped.Bip01_L_Forearm"
	},
	{
		S = "ValveBiped.Bip01_L_Forearm",
		E = "ValveBiped.Bip01_L_Hand"
	},
	{
		S = "ValveBiped.Bip01_Spine2",
		E = "ValveBiped.Bip01_R_UpperArm"
	},
	{
		S = "ValveBiped.Bip01_R_UpperArm",
		E = "ValveBiped.Bip01_R_Forearm"
	},
	{
		S = "ValveBiped.Bip01_R_Forearm",
		E = "ValveBiped.Bip01_R_Hand"
	},
	{
		S = "ValveBiped.Bip01_Pelvis",
		E = "ValveBiped.Bip01_L_Thigh"
	},
	{
		S = "ValveBiped.Bip01_L_Thigh",
		E = "ValveBiped.Bip01_L_Calf"
	},
	{
		S = "ValveBiped.Bip01_L_Calf",
		E = "ValveBiped.Bip01_L_Foot"
	},
	{
		S = "ValveBiped.Bip01_L_Foot",
		E = "ValveBiped.Bip01_L_Toe0"
	},
	{
		S = "ValveBiped.Bip01_Pelvis",
		E = "ValveBiped.Bip01_R_Thigh"
	},
	{
		S = "ValveBiped.Bip01_R_Thigh",
		E = "ValveBiped.Bip01_R_Calf"
	},
	{
		S = "ValveBiped.Bip01_R_Calf",
		E = "ValveBiped.Bip01_R_Foot"
	},
	{
		S = "ValveBiped.Bip01_R_Foot",
		E = "ValveBiped.Bip01_R_Toe0"
	},
}
 
local function GetPredictedAimTarget(targ)
	local function PredictTargetPosition(player, target, predictionTimes)
		local cool = "ValveBiped.Bip01_L_UpperArm"
		if math.random(0, 1) == 1 then
			cool = bones[math.random(1, #bones)].S
		else
			cool = bones[math.random(1, #bones)].E
		end
 
		local targethead = target:LookupBone(cool)
		local targetPos = target:GetBonePosition(targethead)
		local targetVel = target:GetVelocity()
		local predictedPos = targetPos -- + (targetPos / predictionTimes * targetVel)
		return predictedPos
	end
 
	local target = targ
	if target and target:IsValid() then
		local predictionTime = 0.1
		local predictedPos = PredictTargetPosition(player, target, predictionTime)
		return target, predictedPos
	end
	return nil, nil
end
 
local em = FindMetaTable("Entity")
local ofb = em.FireBullets
local cones = {}
function em.FireBullets(p, data)
	local spread = Vector(data.Spread, data.Spread, 0)
	local class = p:GetActiveWeapon():GetClass()
	if spread ~= cones[class] then cones[class] = spread end
	return ofb(p, data)
end
 
function SuperPower.PSilent(ucmd)
	local targ = SuperPower:FindTarg()
	if targ.Target == NULL then return end
	if not ucmd:KeyDown(IN_ATTACK) then return end
	local target, predictedPos = GetPredictedAimTarget(targ.Target)
	local newang = (predictedPos - LocalPlayer():GetShootPos()):Angle()
	ucmd:SetViewAngles(newang)
end
 
hook.Add("CalcView", "PSilent", function(ply, pos, angles, fov)
	local view = {
		origin = pos - (angles:Forward() * 100),
		angles = ply:EyeAngles(),
		fov = fov,
		drawviewer = true
	}
	return view
end)
 
hook.Add("CreateMove", "LocalHax", SuperPower.PSilent)
local function Calc(ent)
	local xx = ent:OBBMins()
	local yy = ent:OBBMaxs()
	return {
		x = xx.x + yy.x,
		y = xx.y + yy.y
	}
end
 
local function GetENTPos(Ent)
	if Ent:IsValid() then
		local Points = {Vector(Ent:OBBMaxs().x, Ent:OBBMaxs().y, Ent:OBBMaxs().z), Vector(Ent:OBBMaxs().x, Ent:OBBMaxs().y, Ent:OBBMins().z), Vector(Ent:OBBMaxs().x, Ent:OBBMins().y, Ent:OBBMins().z), Vector(Ent:OBBMaxs().x, Ent:OBBMins().y, Ent:OBBMaxs().z), Vector(Ent:OBBMins().x, Ent:OBBMins().y, Ent:OBBMins().z), Vector(Ent:OBBMins().x, Ent:OBBMins().y, Ent:OBBMaxs().z), Vector(Ent:OBBMins().x, Ent:OBBMaxs().y, Ent:OBBMins().z), Vector(Ent:OBBMins().x, Ent:OBBMaxs().y, Ent:OBBMaxs().z)}
		local MaxX, MaxY, MinX, MinY
		local V1, V2, V3, V4, V5, V6, V7, V8
		local isVis
		for k, v in pairs(Points) do
			local ScreenPos = Ent:LocalToWorld(v):ToScreen()
			isVis = ScreenPos.visible
			if MaxX ~= nil then
				MaxX, MaxY, MinX, MinY = math.max(MaxX, ScreenPos.x), math.max(MaxY, ScreenPos.y), math.min(MinX, ScreenPos.x), math.min(MinY, ScreenPos.y)
			else
				MaxX, MaxY, MinX, MinY = ScreenPos.x, ScreenPos.y, ScreenPos.x, ScreenPos.y
			end
 
			if V1 == nil then
				V1 = ScreenPos
			elseif V2 == nil then
				V2 = ScreenPos
			elseif V3 == nil then
				V3 = ScreenPos
			elseif V4 == nil then
				V4 = ScreenPos
			elseif V5 == nil then
				V5 = ScreenPos
			elseif V6 == nil then
				V6 = ScreenPos
			elseif V7 == nil then
				V7 = ScreenPos
			elseif V8 == nil then
				V8 = ScreenPos
			end
		end
		return MaxX, MaxY, MinX, MinY, V1, V2, V3, V4, V5, V6, V7, V8, isVis
	end
end
 
hook.Add("HUDPaint", "HudDododo", function()
	draw.RoundedBox(0, 0, 0, 400, 400, Color(0, 0, 0, 155))
	local width, height, text = 0, 0, {}
	for k, v in pairs(player.GetAll()) do
		local ply = LocalPlayer()
		local wep = ply:GetActiveWeapon()
		if IsValid(wep) and wep.Primary ~= nil then wep.Primary.Recoil = 0 end
		text[k] = tostring(v:Nick()) .. " - " .. tostring(v:GetUserGroup()) .. " - " .. tostring(v:GetObserverMode()) .. " - " .. tostring(v:GetObserverTarget()) .. " - Health: " .. tostring(v:Health())
		draw.DrawText(text[k], "Default", 0, height, Color(255, 255, 255, 255), TEXT_ALIGN_LEFT)
		height = height + 10
		if v == LocalPlayer() then continue end
		local ts = v:GetPos():ToScreen()
		local bound = Calc(v)
		local MaxX, MaxY, MinX, MinY, V1, V2, V3, V4, V5, V6, V7, V8, isVis = GetENTPos(v)
		local XLen, YLen = MaxX - MinX, MaxY - MinY
		surface.SetDrawColor(Color(255, 255, 255))
		surface.DrawLine(MaxX, MaxY, MinX + XLen * 0.7, MaxY)
		surface.DrawLine(MinX, MaxY, MinX + XLen * 0.3, MaxY)
		surface.DrawLine(MaxX, MaxY, MaxX, MinY + YLen * 0.75)
		surface.DrawLine(MaxX, MinY, MaxX, MinY + YLen * 0.25)
		surface.DrawLine(MinX, MinY, MaxX - XLen * 0.7, MinY)
		surface.DrawLine(MaxX, MinY, MaxX - XLen * 0.3, MinY)
		surface.DrawLine(MinX, MinY, MinX, MaxY - YLen * 0.75)
		surface.DrawLine(MinX, MaxY, MinX, MaxY - YLen * 0.25)
	end
end)