--[[
	MOD/lua/Flehsys.lua
	fLSHY | STEAM_0:0:41819729 <76.98.241.141:55001> | [25-10-13 12:16:51PM]
	===BadFile===
]]

-- Fleshys C+P
---3D ESP Boxes
-- Thanks to Bob
local rxm   =    CreateClientConVar( "lix_lesp_bsp3dbox_red", 0, true, false)
local gxm   =    CreateClientConVar( "lix_lesp_bsp3dbox_green", 0, true, false)
local bxm    =    CreateClientConVar( "lix_lesp_bsp3dbox_blue", 255, true, false)


CreateClientConVar( "lix_lesp_BSP_3dbox", 1, true, false )
local function DrawBoundingBox() -- thanks Anthr4x
if GetConVarNumber("lix_lesp_BSP_3dbox") == 1 then
cam.Start3D(EyePos(), EyeAngles());
for k, ply in pairs(player.GetAll()) do
if ( ply:Alive() && ( IsValid(ply) && ply != LocalPlayer() )) then
local ang = ply:EyeAngles();
ang.p = 0;
ang.r = 0;
local pos = ply:GetPos();
local width = 32;
local height = 74;
local scale = 2;
local BoxColor = Color(GetConVarNumber("lix_lesp_bsp3dbox_red"),GetConVarNumber("lix_lesp_bsp3dbox_green"),GetConVarNumber("lix_lesp_bsp3dbox_blue"),255)
 

cam.IgnoreZ( true )
local ang2 = Angle(ang.p, ang.y, ang.r);
local pos2 = pos;
pos2 = pos2 - (ang2:Forward() * (width / 2));
pos2 = pos2 - (ang2:Right() * (width / 2));
pos2 = pos2 + (ang2:Up() * (height));
cam.Start3D2D(pos2, ang2, (1 / scale));
surface.SetDrawColor(BoxColor);
surface.DrawOutlinedRect(0, 0, (width * scale), (width * scale));
surface.SetDrawColor(Color(0, 0, 0, 0));
surface.DrawRect(0, 0, (width * scale), (width * scale));
cam.End3D2D();
 
-- Front Face
local ang3 = Angle(ang.p + 90, ang.y, ang.r);
local pos3 = pos;
pos3 = pos3 - (ang3:Forward() * height);
pos3 = pos3 - (ang3:Right() * (width / 2));
pos3 = pos3 + (ang3:Up() * (width / 2));
cam.Start3D2D(pos3, ang3, (0 / scale));
surface.SetDrawColor(BoxColor)
surface.DrawOutlinedRect(0, 0, (height * scale), (width * scale));
surface.SetDrawColor(Color(0, 0, 0, 0));
surface.DrawRect(0, 0, (height * scale), (width * scale));
cam.End3D2D();
 
                                        -- Back Face
local ang4 = Angle(ang.p + 90, ang.y, ang.r);
local pos4 = pos;
pos4 = pos4 - (ang4:Forward() * height);
pos4 = pos4 - (ang4:Right() * (width / 2));
pos4 = pos4 - (ang4:Up() * (width / 2));
cam.Start3D2D(pos4, ang4, (1 / scale));
surface.SetDrawColor(BoxColor);
surface.DrawOutlinedRect(0, 0, (height * scale), (width * scale));
surface.SetDrawColor(Color(0, 0, 0, 0));
surface.DrawRect(0, 0, (height * scale), (width * scale));
cam.End3D2D();
 
-- Right Face
local ang5 = Angle(ang.p + 90, ang.y, ang.r + 90);
local pos5 = pos;
pos5 = pos5 - (ang5:Forward() * height);
pos5 = pos5 - (ang5:Right() * (width / 2));
pos5 = pos5 - (ang5:Up() * (width / 2));
cam.Start3D2D(pos5, ang5, (1 / scale));
surface.SetDrawColor(BoxColor);
surface.DrawOutlinedRect(0, 0, (height * scale), (width * scale));
surface.SetDrawColor(Color(0, 0, 0, 0));
surface.DrawRect(0, 0, (height * scale), (width * scale));
cam.End3D();
-- Left Face
local ang6 = Angle(ang.p + 90, ang.y, ang.r + 90);
local pos6 = pos;
pos6 = pos6 - (ang6:Forward() * height);
pos6 = pos6 - (ang6:Right() * (width / 2));
pos6 = pos6 + (ang6:Up() * (width / 2));
cam.Start3D2D(pos6, ang6, (1 / scale));
surface.SetDrawColor(BoxColor);
surface.DrawOutlinedRect(0, 0, (height * scale), (width * scale));
surface.SetDrawColor(Color(0, 0, 0, 0));
surface.DrawRect(0, 0, (height * scale), (width * scale));
cam.End3D2D();
end
end
cam.End3D();
end
end
hook.Add("RenderScreenspaceEffects",""..math.random().."", DrawBoundingBox)

---3D ESP Boxes
-- Thanks to Bob

