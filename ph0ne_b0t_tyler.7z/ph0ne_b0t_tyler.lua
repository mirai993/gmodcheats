--[[*********************************************************************
	ph0ne.lua
	Coded by ph0ne
	Credits:
		+ C0BRA: hook.Call detour.
		+ fr1kin: gmcl_hermes, generally useful tips/advice/snippets.
		+ noPE: Detouring, autowall.
		+ RabidToaster: Random string, strafe correction.
		+ stgn: FireBullets detour, Evolve gag bypass.
***********************************************************************]]

if not CLIENT then return end
if C then _G.C = nil end -- We don't want to be easily detected.
local _R = debug.getregistry();
--[[--------------------------------------------
	INITIALIZATION
--]]--------------------------------------------

local C    = {} -- C is for CHEAT.
C.Commands = {}
C.Cones    = { normal = {}, hl2 = {} }
C.ConVars  = {}
C.Detours  = {}
C.Hooks    = {}
C.MenuInfo = {}
C.Meta	   = { _G, hook, concommand, debug, file }
C.Settings = {}
C.World	   = { players = {} }
C.funclog	   = {}


local old_filecdir 			= file.CreateDir;
local old_filedel 			= file.Delete;
local old_fileexist 		= file.Exists;
local old_fileexistex 		= file.ExistsEx;
local old_filefind 			= file.Find;
local old_filefinddir 		= file.FindDir;
local old_filefindil 		= file.FindInLua;
local old_fileisdir			= file.IsDir;
local old_fileread 			= file.Read;
local old_filerename 		= file.Rename;
local old_filesize 			= file.Size;
local old_filetfind			= file.TFind;
local old_filetime 			= file.Time;
local old_filewrite 		= file.Write;
local old_dbginfo 			= debug.getinfo;
local old_dbginfo 			= debug.getupvalue;
local old_timerc			= timer.Create;
local old_cve 				= ConVarExists;
local old_gcv 				= GetConVar;
local old_gcvn 				= GetConVarNumber;
local old_gcvs 				= GetConVarString;
local old_rcc 				= RunConsoleCommand;
local old_hookadd			= hook.Add;
local old_hookrem 			= hook.Remove;
local old_ccadd				= concommand.Add;
local old_ccrem 			= concommand.Remove;
local old_cvaracc 			= cvars.AddChangeCallback;
local old_cvargcvc 			= cvars.GetConVarCallbacks;
local old_cvarchange 		= cvars.OnConVarChanged;
local old_require			= require;
local old_eccommand 		= engineConsoleCommand;
local old_rs				= RunString;
local old_ccmd				= _R.Player.ConCommand;
local old_include			= include;
local old_usermsginc		= usermessage.IncomingMessage;

--[ LOGGER (ADDED LATER) ]--
if !old_fileexist("ph0nebot","DATA") then
	old_filecdir("ph0nebot");
end
function C:Log(msg)
	if !old_fileexist("ph0nebot/log.txt","DATA") then
		old_filewrite("ph0nebot/log.txt","Log started "..os.date().." \n")
	end
	table.insert(C.funclog,"["..os.date("%H:%M:%S").."]: "..msg)
	file.Append("ph0nebot/log.txt","["..os.date().."]: "..msg.."\n")
end

--[ RESET METATABLES ]--

function C:UnlockMeta()
	for i = 1, table.Count( C.Meta ) do
		rawset( C.Meta[i], "__metatable", false )
	end
end
C:UnlockMeta()

--[ OPTIMIZATION ]--

local cam				  = cam
local chat				  = chat
local draw				  = draw
local package			  = package
local player			  = player
local math				  = math
local render			  = render
local string			  = string
local surface			  = surface
local table				  = table
local team		 		  = team
local timer				  = timer
local util				  = util
local vgui				  = vgui
local Angle 			  = Angle
local Color 			  = Color
local EyeAngles			  = EyeAngles
local EyePos 			  = EyePos
local ipairs			  = ipairs
local pairs			 	  = pairs
local tobool			  = tobool
local tonumber			  = tonumber
local tostring			  = tostring
local type 				  = type
local unpack			  = unpack
local Vector 			  = Vector
local MsgN				  = MsgN
local IsValid 		  = IsValid
local RealFrameTime       = RealFrameTime
local CreateClientConVar  = CreateClientConVar
local CreateMaterial      = CreateMaterial
local AddConsoleCommand   = AddConsoleCommand

--[ BACKUPS ]--

C.Copy = {
	hook		  = table.Copy( hook ),
	GetInt  	  = _R["ConVar"].GetInt,
	GetBool	 	  = _R["ConVar"].GetBool,
	SetViewAngles = _R["CUserCmd"].SetViewAngles
}

--[[--------------------------------------------
	VARS
--]]--------------------------------------------

C.Vars = {
	osv 		 = 0,
	target		 = nil,
	aimlocked    = false,
	pkfake 	     = false,
	pkthrow 	 = false,
	firing  	 = false,
	found 	     = false,
	aimingang    = Angle( 0, 0, 0 ),
	fakeang 	 = Angle( 0, 0, 0 ),
	pkfakeang    = Angle( 0, 0, 0 ),
	pkthrowang   = Angle( 0, 0, 0 ),
	path 	 	 = "lua\\autorun\\client\\ph0ne.lua",
	prefix	     = "ph0ne_"
}

C.Modules  = { -- Store file names for protection.
	"loader.lua",
	"loader",
	"ph0ne.lua",
	"ph0ne",
	"gmcl_hermes.dll",
	"gmcl_hermes",
	"hermes",
	"gmcl_hake.dll",
	"gmcl_hake",
	"hake",
	"gmcl_sys.dll",
	"gmcl_sys",
	"sys"
}

--[[--------------------------------------------
	DETOURS
--]]--------------------------------------------

--[[--------------------------------------------
	C++ MODULE
--]]--------------------------------------------

function C:LoadModule()
print("nope")
end
C:LoadModule()

--[[--------------------------------------------
	HOOKING + CONCOMMANDS
--]]--------------------------------------------

function C:AddHook( name, func )
str = "hook"..math.random(1,200000000)
return old_hookadd(name,str,func);
end

function C:AddCommand( name, func )
	return old_ccadd(name, func )
end

--[[--------------------------------------------
	CONVARS
--]]--------------------------------------------

--[ ADD CONVARS ]--

C.SetVars = {
	{ Name = "aim", Value = 0, Desc = "Aimbot Enabled", Type = "bool", Table = "aim", Menu = "aim" },
	{ Name = "aim_silent", Value = 1, Desc = "Silent Aim", Type = "bool", Table = "aimsilent", Menu = "aim" },
	{ Name = "aim_smooth", Value = 0, Desc = "Smooth Aim (NOTE: Disables nospread.)", Type = "bool", Table = "aimsmooth", Menu = "aim" },
	{ Name = "aim_friendlyfire", Value = 1, Desc = "Aim at Teammates", Type = "bool", Table = "aimteam", Menu = "aim" },
	{ Name = "aim_ignoreadmins", Value = 0, Desc = "Ignore Admins", Type = "bool", Table = "ignoreadmins", Menu = "aim" },
	{ Name = "aim_ignoretraitors", Value = 0, Desc = "Ignore Friendly Traitors", Type = "bool", Table = "ignoretraitors", Menu = "aim" },
	{ Name = "aim_ignorefriends", Value = 0, Desc = "Ignore Steam Friends", Type = "bool", Table = "ignorefriends", Menu = "aim" },
	{ Name = "aim_autoshoot", Value = 0, Desc = "Autoshoot", Type = "bool", Table = "autoshoot", Menu = "aim" },
	{ Name = "aim_snaponfire", Value = 0, Desc = "Aim When Firing", Type = "bool", Table = "snaponfire", Menu = "aim" },
	{ Name = "aim_obb", Value = 0, Desc = "Aim at OBBCenter", Type = "bool", Table = "obb", Menu = "aim" },
	//{ Name = "aim_antiaim", Value = 0, Desc = "Anti-Aim", Type = "bool", Table = "antiaim", Menu = "aim" },
	//{ Name = "aim_nospread", Value = 1, Desc = "Nospread", Type = "bool", Table = "nospread", Menu = "aim" },
	{ Name = "aim_autowall", Value = 0, Desc = "Autowall (NOTE: Buggy, works with Mad Cow's weapon base only.)", Type = "bool", Table = "autowall", Menu = "aim" },
	{ Name = "aim_ignorevisibility", Value = 0, Desc = "Ignore Visibility Checks", Type = "bool", Table = "ignorevisibility", Menu = "aim" },
	{ Name = "aim_prediction", Value = 1, Desc = "Prediction", Type = "bool", Table = "prediction", Menu = "aim" },
	{ Name = "aim_prediction_val_tar", Value = 66, Desc = "Target Prediction", Type = "number", Table = "predictiontar", Max = 66, Min = 25, Menu = "aim" },
	{ Name = "aim_prediction_val_ply", Value = 45, Desc = "Local Prediction", Type = "number", Table = "predictionply", Max = 66, Min = 25, Menu = "aim" },
	{ Name = "aim_prediction_type", Value = 1, Table = "predictiontype" },
	{ Name = "aim_offset", Value = 0, Desc = "Offset Y", Type = "number", Table = "aimoffset", Max = 10, Min = -10, Menu = "aim" },
	{ Name = "aim_fov", Value = 180, Desc = "Aimbot FOV", Type = "number", Table = "aimfov", Max = 180, Min = 1, Menu = "aim" },
	{ Name = "aim_smooth_val", Value = 6, Desc = "Smooth Aim Speed", Type = "number", Table = "smoothspeed", Max = 12, Min = 4, Menu = "aim" },
	{ Name = "esp", Value = 1, Desc = "ESP Enabled", Type = "bool", Table = "esp", Menu = "esp" },
	{ Name = "esp_info", Value = 1, Desc = "Player Info", Type = "bool", Table = "infoesp", Menu = "esp" },
	{ Name = "esp_target", Value = 1, Desc = "Target Indicator Line", Type = "bool", Table = "targetesp", Menu = "esp" },
	{ Name = "esp_admins", Value = 1, Desc = "Admin List", Type = "bool", Table = "adminlist", Menu = "esp" },
	{ Name = "esp_rpents", Value = 0, Desc = "RP Entities", Type = "bool", Table = "rpesp", Menu = "esp" },
	{ Name = "esp_tttweps", Value = 0, Desc = "TTT Traitor Weapons", Type = "bool", Table = "traitorwepesp", Menu = "esp" },
	{ Name = "esp_chams", Value = 1, Desc = "Chams", Type = "bool", Table = "chams", Menu = "esp" },
	//{ Name = "esp_chams_fullbright", Value = 1, Desc = "Render Fullbright", Type = "bool", Table = "renderfullbright", Menu = "esp" },
	{ Name = "misc_bunnyhop", Value = 0, Desc = "Bunnyhop", Type = "bool", Table = "bhop", Menu = "misc" },
	{ Name = "misc_ungag", Value = 0, Desc = "ULX/Evolve Ungag", Type = "bool", Table = "ungag", Menu = "misc" },
	//{ Name = "misc_namesteal", Value = 0, Desc = "Namestealer", Type = "bool", Table = "namestealer", Menu = "misc" },
	{ Name = "misc_crosshair", Value = 1, Desc = "Crosshair", Type = "bool", Table = "crosshair", Menu = "misc" },
	{ Name = "misc_novisrecoil", Value = 1, Desc = "No Visual Recoil", Type = "bool", Table = "novisrecoil", Menu = "misc" },
	{ Name = "misc_calcview", Value = 1, Desc = "Enable CalcView", Type = "bool", Table = "calcview", Menu = "misc" },
	//{ Name = "misc_fullbright", Value = 0, Desc = "Enable Fullbright", Type = "bool", Table = "fullbright", Menu = "misc" },
	//{ Name = "misc_speed", Value = 1, Desc = "Speedhack Value", Type = "number", Table = "speed", Max = 8, Min = 1, Menu = "misc" }
}

--[ CREATE CONVARS ]--

function C:CreateConVars()
	local tbl = C.SetVars
	for i = 1, table.Count( tbl ) do
		local v = tbl[i]
		local pvar = C.Vars.prefix .. v.Name
		local convar = CreateClientConVar( pvar, v.Value, true, false )
		local cvarinfo = {
			Name  = pvar,
			Value = v.Value,
			Desc  = v.Desc,
			Type  = v.Type,
			Max   = v.Max,
			Min   = v.Min,
			Menu  = v.Menu
		}
		C.Settings[v.Table] = convar:GetInt() -- Store a value for our callback table.
		C.MenuInfo[pvar] = cvarinfo
		C.MenuInfo[#C.MenuInfo + 1] = cvarinfo
		cvars.AddChangeCallback( pvar, function( cvar, old, new )
			C.Settings[v.Table] = new
		end )
	
		C.ConVars[pvar] = convar
	end
end
C:CreateConVars()

MsgC( Color( 255, 255, 255 ),":: " )
MsgC(  Color( 255, 0, 0 ),"Convars created.\n" )

--[ CVAR CHECK ]--

function C:G( name, val )
	if ( tonumber( name ) == val ) then return true end
	return false
end

--[ CVAR HIDING ]--

C.OriginalVars = {
	{ "sv_cheats", FCVAR_NOTIFY , FCVAR_REPLICATED , FCVAR_CHEAT, "0" },
	{ "host_timescale", FCVAR_NOTIFY , FCVAR_REPLICATED , FCVAR_CHEAT, "1.0" },
	{ "r_drawothermodels", FCVAR_CLIENTDLL , FCVAR_CHEAT, "1" },
	{ "mat_fullbright", FCVAR_CHEAT, "0" },
	{ "sv_consistency", FCVAR_REPLICATED, "1" },
	{ "sv_allow_voice_from_file", FCVAR_REPLICATED, "1" },
	{ "voice_inputfromfile", FCVAR_NONE, "0" },
	{ "fog_enable", FCVAR_CLIENTDLL , FCVAR_CHEAT, "1" },
	{ "fog_enable_water_fog", FCVAR_CHEAT, "1" }
}


--[ CVAR FORCING ]--

--[[--------------------------------------------
	UTIL FUNCTIONS
--]]--------------------------------------------

--[ CHECKS ]--

function C:IsAdmin( e )
	if e:IsAdmin() or e:IsSuperAdmin() then return true end
	return false
end

function C:IsFriend( e )
	if ( e:GetFriendStatus() == "friend" ) then return true end
	return false
end

function C:IsTTT()
	if string.find( string.lower( GAMEMODE.Name ), "trouble in terror" ) then return true end
	return false
end

function C:IsTraitor( e )
	local ply = LocalPlayer()
	if not C:IsTTT() then return end
	if ply:IsTraitor() and e:IsTraitor() then return true end
	return false
end

function C:IsOnScreen( e ) -- Thanks fr1kin.
	local x, y, positions = ScrW(), ScrH(), { "OBBCenter", "OBBMaxs", "OBBMins" }
	for i = 1, table.Count( positions ) do
		local v = positions[i]
		local pos = e:LocalToWorld( _R.Entity[v]( e ) ):ToScreen()
		if ( pos.x &gt; 0 ) and ( pos.y &gt; 0 ) and ( pos.x &lt; x ) and ( pos.y &lt; y ) then return true end
	end
	return false
end

--[ FILTER ]--

function C:IsTargetValid( e, typ )
	local ply, str, fov = LocalPlayer(), tostring( typ ), tonumber( C.Settings['aimfov'] )
	if ( str == "aim" ) then
		if not IsValid( e ) or ( ply == e ) then return false end
		if not e:Alive() then return false end
		if C:IsAdmin( e ) and C:G( C.Settings['ignoreadmins'], 1 ) then return false end
		if C:IsTraitor( e ) and C:G( C.Settings['ignoretraitors'], 1 ) then return false end
		if C:IsFriend( e ) and C:G( C.Settings['ignorefriends'], 1 ) then return false end
		if ( e:Team() == ply:Team() ) and C:G( C.Settings['aimteam'], 0 ) then return false end
		if string.find( string.lower( team.GetName( e:Team() ) ), "spec" ) then return false end	
		if ( e:GetMoveType() == MOVETYPE_NONE ) then return false end
		if ( e:GetMoveType() == MOVETYPE_OBSERVER ) then return false end
		if ( fov ~= 180 ) then
			local ang = ( e:GetPos() - ply:GetShootPos() ):Angle()
			local yaw = math.abs( math.NormalizeAngle( ply:GetAngles().y - ang.y ) )
			local pitch = math.abs( math.NormalizeAngle( ply:GetAngles().p - ang.p ) )
			if ( yaw &gt; fov ) or ( pitch &gt; fov ) then return false end
		end
		return true
	elseif ( str == "esp" ) then
		if not IsValid( e ) or ( ply == e ) then return false end
		if not e:Alive() then return false end
		if string.find( string.lower( team.GetName( e:Team() ) ), "spec" ) then return false end
		if ( e:GetMoveType() == MOVETYPE_NONE ) then return false end
		if ( e:GetMoveType() == MOVETYPE_OBSERVER ) then return false end
		if not C:IsOnScreen( e ) then return false end
		return true
	elseif ( str == "chams" ) then -- For coloring based on aimbot targets.
		if not IsValid( e ) or ( ply == e ) then return false end
		if not e:Alive() then return false end
		if C:IsAdmin( e ) and C:G( C.Settings['ignoreadmins'], 1 ) then return false end
		if C:IsTraitor( e ) and C:G( C.Settings['ignoretraitors'], 1 ) then return false end
		if C:IsFriend( e ) and C:G( C.Settings['ignorefriends'], 1 ) then return false end
		if ( e:Team() == ply:Team() ) and C:G( C.Settings['aimteam'], 0 ) then return false end
		if string.find( string.lower( team.GetName( e:Team() ) ), "spec" ) then return false end	
		if ( e:GetMoveType() == MOVETYPE_NONE ) then return false end
		if ( e:GetMoveType() == MOVETYPE_OBSERVER ) then return false end
		return true
	end
	return false
end

--[ COLOR ]--

function C:GetPlayerColor( e )
	local vis, invis
	if C:IsTargetValid( e, "chams" ) then
		vis = Color( 255, 0, 0, 255 )
		invis = Color( 255, 255, 0, 255 )
	else
		vis = Color( 0, 255, 0, 255 )
		invis = Color( 0, 0, 255, 255 )
	end
	return vis, invis
end

--[[--------------------------------------------
	NOSPREAD
--]]--------------------------------------------

--[ HL2 CONES ]--

C.Cones.hl2["weapon_smg1"]    = Vector( -0.04362, -0.04362, -0.04362 )
C.Cones.hl2["weapon_pistol"]  = Vector( -0.0100, -0.0100, -0.0100 )
C.Cones.hl2["weapon_ar2"]	  = Vector( -0.02618, -0.02618, -0.02618 )
C.Cones.hl2["weapon_shotgun"] = Vector( -0.08716, -0.08716, -0.08716 )

--[ MANUPULATE SHOT ]--

function C:PredictSpread( cmd, angle )
end

--[[--------------------------------------------
	AIMBOT
--]]--------------------------------------------

--[ TARGET LOCATION ]--

C.ZombieModels = {
	{ "models/zombie/fast_torso.mdl",	  "ValveBiped.HC_BodyCube" },
	{ "models/zombie/fast.mdl",			  "ValveBiped.HC_BodyCube" },
	{ "models/headcrabclassic.mdl",		  "HeadcrabClassic.SpineControl" },
	{ "models/headcrabblack.mdl",		  "HCBlack.body" },
	{ "models/headcrab.mdl",			  "HCFast.body" },
	{ "models/zombie/poison.mdl",		  "ValveBiped.Headcrab_Cube1" },
	{ "models/zombie/classic.mdl",		  "ValveBiped.HC_Body_Bone" },
	{ "models/zombie/classic_torso.mdl",  "ValveBiped.HC_Body_Bone" },
	{ "models/zombie/zombie_soldier.mdl", "ValveBiped.HC_Body_Bone" },
}

function C:GetPosition( e, pos, typ )
	if ( tostring( typ ) == "attachment" ) then
		return e:GetAttachment( e:LookupAttachment( pos ) )
	elseif ( tostring( typ ) == "bone" ) then
		return e:GetBonePosition( e:LookupBone( pos ) )
	end
end

function C:GetTargetLocation( e )
	if C:G( C.Settings['obb'], 1 ) then return e:LocalToWorld( e:OBBCenter() ) end
	for i = 1, table.Count( C.ZombieModels ) do
		if ( e:GetModel() == C.ZombieModels[i][1] ) then return C:GetPosition( e, C.ZombieModels[i][2], "bone" ) end
	end
	if ( e:LookupAttachment( "forward" ) ~= 0 ) then -- CSS models.
		local forward = C:GetPosition( e, "forward", "attachment" )
		if forward and forward.Pos then return forward.Pos end
	end
	if ( e:LookupAttachment( "eyes" ) ~= 0 ) then -- General humanoid models.
		eyes = C:GetPosition( e, "eyes", "attachment" )
		if eyes and eyes.Pos then return eyes.Pos end
	end
	if e:LookupBone( "ValveBiped.Bip01_Head1" ) then -- Backup head position.
		return C:GetPosition( e, "ValveBiped.Bip01_Head1", "bone" )
	end
	return e:LocalToWorld( e:OBBCenter() ) -- Anything else.
end

--[ PREDICTION ]--

function C:GetPredictionPos( e )
return Vector( 0, 0, 0 )
end

--[ AUTOWALL ]--

function C:IsPenetrable( tr ) -- Thanks noPE.
	local ply, maxpenetration = LocalPlayer(), 16
	local wep = ply:GetActiveWeapon()
	if ( wep.Base == "weapon_mad_base" ) then -- The only widely used weapon base with penetration capability.
		if ( wep.Primary.Ammo == "AirboatGun" ) then -- 5.56mm
			maxpenetration = 18
		elseif ( wep.Primary.Ammo == "Gravity" ) then -- 4.6mm
			maxpenetration = 8
		elseif ( wep.Primary.Ammo == "AlyxGun" ) then -- 5.7mm
			maxpenetration = 12
		elseif ( wep.Primary.Ammo == "Battery" ) then -- 9mm
			maxpenetration = 14
		elseif ( wep.Primary.Ammo == "StriderMinigun" ) or ( wep.Primary.Ammo == "CombineCannon" ) then -- 7.62mm and .50AE respectively.
			maxpenetration = 20
		elseif ( wep.Primary.Ammo == "SniperPenetratedRound" ) then -- .45ACP
			maxpenetration = 16
		else
			maxpenetration = 16
		end
		if not tr.Entity:IsPlayer() then -- Don't ignore what we want to aim at.
			if ( ( tr.MatType == MAT_METAL ) and wep.Ricochet ) or ( tr.MatType == MAT_SAND ) then return false end -- Not penetrable.
			local direction = tr.Normal * maxpenetration
			local surfaces = { MAT_GLASS, MAT_PLASTIC, MAT_WOOD, MAT_FLESH, MAT_ALIENFLESH }
			for i = 1, table.Count( surfaces ) do
				if ( tr.MatType == surfaces[i] ) then direction = tr.Normal * ( maxpenetration * 2 ) end
			end
			local trace = util.TraceLine( {
				start = tr.HitPos + direction,
				endpos = tr.HitPos,
				filter = { wep.Owner },
				mask = MASK_SHOT
			} )
			if trace.StartSolid or ( trace.Fraction &gt;= 1.0 ) or ( tr.Fraction &lt;= 0.0 ) then return false end -- Bullet didn't penetrate.
		end
	else
		return false
	end
	return true
end

--[ VISIBILITY CHECK ]--

function C:TargetVisible( e )
	local ply = LocalPlayer()
	if C:G( C.Settings['ignorevisibility'], 1 ) then return true end
	local trace = util.TraceLine( {
		start = ply:GetShootPos(),
		endpos = C:GetTargetLocation( e ) + C:GetPredictionPos( e ),
		filter = { ply, e },
		mask = MASK_SHOT + CONTENTS_WINDOW
	} )
	if ( trace.Fraction &gt;= 0.99 ) or ( C:G( C.Settings['autowall'], 1 ) and C:IsPenetrable( trace ) ) then return true end
	return false
end

--[ CLOSEST-TO-CROSSHAIR TARGETING ]--

function C:GetAimTarget()
	if C:IsTargetValid( C.Vars.target, "aim" ) and C:TargetVisible( C.Vars.target ) then return C.Vars.target else C.Vars.target = nil end
	local ply, tar = LocalPlayer(), { 0, 0 } -- SlobBot sorting.
	if C:G( C.Settings['aim'], 1 ) then
		for i = 1, table.Count( C.World.players ) do
			local e = C.World.players[i]
			if C:IsTargetValid( e, "aim" ) and C:TargetVisible( e ) then
				local pos = C:GetTargetLocation( e ) + C:GetPredictionPos( e )
				local vec = ( pos - ply:GetShootPos() ):GetNormal()
				local d = math.deg( math.acos( ply:GetAimVector():Dot( vec ) ) ) -- AA:AngleBetween.
				if ( d &lt; tar[2] ) or ( tar[1] == 0 ) then -- Check if our distance is shorter than prevously, or if we haven't acquired a target yet.
					tar = { e, d }
				end
			end
		end
	end
	return ( ( tar[1] ~= 0 ) and ( tar[1] ~= ply ) and tar[1] ) or nil
end

--[ SMOOTH AIM ]--

function C:GetSmoothAngle( ang )
	local ply = LocalPlayer()
	local smoothang = Angle( 0, 0, 0 )
	if C:G( C.Settings['aimsmooth'], 1 ) then
		local speed = RealFrameTime() / ( tonumber( C.Settings['smoothspeed'] ) / 100 )
		smoothang = LerpAngle( speed, ply:GetAimVector():Angle(), ang )
	else
		return Angle( ang.p, ang.y, 0 )
	end
	return Angle( smoothang.p, smoothang.y, 0 )
end

--[ KEEP ANGLES ]--

function C.OnToggled()
	local ply = LocalPlayer()
	if not IsValid( ply ) then return end
	C.Vars.aacorrectang = ply:GetAimVector():Angle()
	C.Vars.fakeang = ply:GetAimVector():Angle()
end
C:AddHook( "OnToggled", C.OnToggled )

--[ AIMBOT ]--

function C.Aimbot( cmd )
	local ply, tar = LocalPlayer(), C:GetAimTarget()
	local wep = ply:GetActiveWeapon()
	C.Vars.fakeang.p = math.Clamp( C.Vars.fakeang.p + ( cmd:GetMouseY() * 0.022 ), -89, 90 )
	C.Vars.fakeang.y = math.NormalizeAngle( C.Vars.fakeang.y + ( cmd:GetMouseX() * -0.022 ) )
	if C:G( C.Settings['aimsilent'], 1 ) and C:G( C.Settings['antiaim'], 0 ) then
		C.Copy.SetViewAngles( cmd, C.Vars.fakeang )
	end
	if C:G( C.Settings['aim'], 1 ) and ply:Alive() and tar then
		C.Vars.target = tar
		C.Vars.found = true
		local pos = C:GetTargetLocation( tar ) + C:GetPredictionPos( tar )
		pos = pos + Vector( 0, 0, tonumber( C.Settings['aimoffset'] ) )
		local ang = ( pos - ply:GetShootPos() ):Angle()
		C.Vars.aimingang = ang
		ang = C:GetSmoothAngle( ang )
		if C:G( C.Settings['nospread'], 1 ) and C:G( C.Settings['aimsmooth'], 0 ) then
			ang = C:PredictSpread( cmd, ang )
		end
		ang = Angle( math.NormalizeAngle( ang.p ), math.NormalizeAngle( ang.y ), 0 )
		if C:G( C.Settings['snaponfire'], 1 ) then
			if cmd:KeyDown( IN_ATTACK ) then
				C.Copy.SetViewAngles( cmd, ang )
				C.Vars.aimlocked = true
			else
				C.Vars.aimlocked = false
			end
		else
			C.Copy.SetViewAngles( cmd, ang )
			C.Vars.aimlocked = true
		end
		if C:G( C.Settings['autoshoot'], 1 ) and not C.Vars.firing then
			RunConsoleCommand( "+attack" )
			C.Vars.firing = true
			timer.Simple( ( wep.Primary and wep.Primary.Delay ) or 0.05, function()
				RunConsoleCommand( "-attack" )
				C.Vars.firing = false
			end )
		end
	else
		C.Vars.target = nil
		C.Vars.aimlocked = false
		C.Vars.found = false
	end
	if C:G( C.Settings['aimsilent'], 1 ) and C.Vars.aimlocked then
		local move = Vector( cmd:GetForwardMove(), cmd:GetSideMove(), 0 )
		local norm = move:GetNormal()
		local set = ( norm:Angle() + ( C.Vars.aimingang - C.Vars.fakeang ) ):Forward() * move:Length()
		cmd:SetForwardMove( set.x )
		cmd:SetSideMove( set.y )
	end
end

--[[--------------------------------------------
	PROPKILLING
--]]--------------------------------------------

--[ COMMANDS ]--


--[ TURN PLAYER 180 ]--

function C.TTTPropkill( cmd )
	local ply = LocalPlayer()
	if C:IsTTT() then
		if C.Vars.pkfake and not C.Vars.pkthrow then
			C.Vars.pkthrowang = cmd:GetViewAngles()
			C.Vars.pkfakeang = C.Vars.pkthrowang - Angle( 0, 180, 0 )
			local move = Vector( cmd:GetForwardMove(), cmd:GetSideMove(), 0 )
			local norm = move:GetNormal()
			local ang = ply:GetAimVector():Angle()
			if C:G( C.Settings['aimsilent'], 1 ) then ang = C.Vars.fakeang end
			local set = ( norm:Angle() + ( C.Vars.pkfakeang - ang ) ):Forward() * move:Length()
			cmd:SetForwardMove( set.x )
			cmd:SetSideMove( set.y )
		elseif not C.Vars.pkfake and C.Vars.pkthrow then
			C.Vars.pkthrow = false
			C.Copy.SetViewAngles( cmd, C.Vars.pkfakeang )
			if C:G( C.Settings['aimsilent'], 1 ) then
				C.Vars.fakeang = C.Vars.pkfakeang
				C.Copy.SetViewAngles( cmd, C.Vars.fakeang )
			end
		else
			C.Vars.pkthrowang = cmd:GetViewAngles()
			C.Vars.pkfakeang = C.Vars.pkthrowang
		end
	end
end

--[[--------------------------------------------
	BUNNYHOPPING
--]]--------------------------------------------
	
function C.Bunnyhop( cmd )	
	local ply = LocalPlayer()
	if C:G( C.Settings['bhop'], 1 ) then
		if ( ply:GetMoveType() ~= MOVETYPE_WALK ) then return end
		if ply and cmd:KeyDown( IN_JUMP ) then
			if ply:IsOnGround() then
				cmd:SetButtons( cmd:GetButtons() , IN_JUMP )
			else
				cmd:SetButtons( cmd:GetButtons() - IN_JUMP )
			end
		end
	end
end

--[[--------------------------------------------
	ANTI-AIM
--]]--------------------------------------------


--[[--------------------------------------------
	CALCVIEW
--]]--------------------------------------------

function C.CalcView( e, origin, angles )
	local ply = LocalPlayer()
	local wep = ply:GetActiveWeapon()
	if wep.Primary then wep.Primary.Recoil = 0 end
	if wep.Secondary then wep.Secondary.Recoil = 0 end
	local view = GAMEMODE:CalcView( e, origin, angles ) or {}
	if C:G( C.Settings['calcview'], 1 ) then
		if C.Vars.pkfake and C:IsTTT() then
			view.angles = C.Vars.pkfakeang
		elseif C.Vars.aimlocked and C:G( C.Settings['aimsmooth'], 1 ) and C:G( C.Settings['aimsilent'], 0 ) then
			view.angles = ply:GetAimVector():Angle()
		elseif C.Vars.aimlocked and C:G( C.Settings['aimsilent'], 0 ) then
			view.angles = C.Vars.aimingang
		elseif C:G( C.Settings['aimsilent'], 1 ) or C:G( C.Settings['antiaim'], 1 ) then
			view.angles = C.Vars.fakeang
		elseif C:G( C.Settings['aimsilent'], 1 ) and C:G( C.Settings['novisrecoil'], 1 ) then
			view.angles = C.Vars.fakeang
		elseif C:G( C.Settings['novisrecoil'], 1 ) and C:G( C.Settings['aimsilent'], 0 ) then
			view.angles = ply:GetAimVector():Angle()
		else
			view = GAMEMODE:CalcView( e, origin, angles )
		end
	else
		view = GAMEMODE:CalcView( e, origin, angles )
	end
	return view
end
C:AddHook( "CalcView", C.CalcView )

--[[--------------------------------------------
	ESP
--]]--------------------------------------------

--[ TARGET LINE ]--

function C.DrawTargetLine()
	local w, h = ScrW() / 2, ScrH() / 2
	if C:G( C.Settings['esp'], 1 ) and C:G( C.Settings['aim'], 1 ) and C:G( C.Settings['targetesp'], 1 ) then
		if ( C.Vars.target ~= nil ) then
			if C:IsTargetValid( C.Vars.target, "esp" ) then
				local pos = C:GetTargetLocation( C.Vars.target ):ToScreen()
				surface.SetDrawColor( team.GetColor( C.Vars.target:Team() ) )
				surface.DrawLine( w, h, pos.x, pos.y )
			end
		end
	end
end

--[ STATUS CHECK ]--

function C:GetStatusColor( e )
	local pos = C:GetTargetLocation( e ):ToScreen()
	local statuscol = Color( 255, 255, 255, 255 )
	if C:IsFriend( e ) then
		statuscol = Color( 0, 255, 0, 255 )
	elseif C:IsAdmin( e ) then
		statuscol = Color( 255, 255, 0, 255 )
	elseif C:IsTraitor( e ) and C:IsTTT() then
		statuscol = Color( 255, 0, 0, 255 )
	else
		statuscol = Color( 255, 255, 255, 255 )
	end
	return statuscol
end

--[ PLAYER ESP ]--

function C:DrawPlayerInfo( e, pos )
	draw.SimpleTextOutlined(
		string.Left( tostring( e:Nick() ), 14 ), "Default",
		pos.x, pos.y - 16,
		C:GetStatusColor( e ),
		TEXT_ALIGN_CENTER, TEXT_ALIGN_BOTTOM,
		1, Color( 0, 0, 0, 255 )
	)
	local col = Color( 255, 255, 255, 255 )
	if ( e:Health() &lt;= 100 ) &amp;&amp; ( e:Health() &gt; 0 ) then
		col = Color( 255, 2.55 * e:Health(), 2.55 * e:Health(), 255 )
	else
		col = Color( 255, 255, 255, 255 )
	end
	draw.SimpleTextOutlined(
		e:Health(), "Default",
		pos.x, pos.y - 5,
		col,
		TEXT_ALIGN_CENTER, TEXT_ALIGN_BOTTOM,
		1, Color( 0, 0, 0, 255 )
	)
end

function C.DrawPlayerESP()
	local ply = LocalPlayer()
	if C:G( C.Settings['esp'], 1 ) and C:G( C.Settings['infoesp'], 1 ) then
		for i = 1, table.Count( C.World.players ) do
			local e = C.World.players[i]
			if C:IsTargetValid( e, "esp" ) then
				local pos = ( C:GetTargetLocation( e ) + Vector( 0, 0, 8 ) ):ToScreen()
				C:DrawPlayerInfo( e, pos )
			end
		end
	end
end
	
--[ ADMIN DISPLAY ]--

function C.DrawAdminList()
	if C:G( C.Settings['esp'], 1 ) and C:G( C.Settings['adminlist'], 1 ) then
		local admins, w, h, y = {}, ScrW(), ScrH(), 0
		draw.SimpleTextOutlined(
			"ADMINS:", "Default",
			w - ( w - 20 ), ( h - h ) + 301,
			Color( 255, 105, 105, 255 ),
			TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER,
			1, Color( 0, 0, 0, 255 )
		)
		for i = 1, table.Count( C.World.players ) do
			local e = C.World.players[i]
			if IsValid( e ) and C:IsAdmin( e ) then
				table.insert( admins, e:Nick() )
			end
		end
		for i = 1, table.Count( admins ) do
			draw.SimpleTextOutlined(
				tostring( admins[i] ), "Default",
				w - ( w - 20 ), ( ( h - h ) + 315 ) + y,
				Color( 255, 255, 255, 255 ),
				TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER,
				1, Color( 0, 0, 0, 255 )
			)
			y = y + 15
		end
	end
end

--[ RP ENTITY ESP ]--

C.World.rpents = {
	"money_printer",
	
	"money_printer_silver", // [RPS]
	"money_printer_diamond",// [RPS]
	"money_printer_gold",	// [RPS]
	
	"drug_plant", // |FP|
	
	"spawned_shipment", 	// Base DarkRP
	"gunlab",
	"drug_lab",
	
	"spawned_money",
	"dispenser",
	"gunvault",
	"drugfactory",
	"gunfactory",
	"microwave",
	"powerplant"
}

function C:DrawRPEntities()
	if C:G( C.Settings['esp'], 1 ) and C:G( C.Settings['rpesp'], 1 ) then
		for i = 1, table.Count( C.World.rpents ) do
			local ent = ents.FindByClass( C.World.rpents[i] ) -- Lag problem fixed.
			for e = 1, table.Count( ent ) do
				local pos = ent[e]:GetPos():ToScreen()
				draw.SimpleTextOutlined(
					tostring( C.World.rpents[i] ), "DefaultSmall",
					pos.x, pos.y,
					Color( 255, 255, 55, 255 ),
					TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER,
					1, Color( 0, 0, 0, 255 )
				)
			end
		end
	end
end

--[ TRAITOR WEAPON ESP ]--

C.World.traitorweapons = {
	"weapon_ttt_c4",
	"weapon_ttt_decoy",
	"weapon_ttt_flaregun",
	"weapon_ttt_knife",
	"weapon_ttt_phammer",
	"weapon_ttt_push",
	"weapon_ttt_radio",
	"weapon_ttt_sipistol",
	"weapon_ttt_teleport"
}

function C.DrawTraitorWeapons() -- This is more efficient than using _R.Player.GetWeapon on a Think hook.
	if C:G( C.Settings['esp'], 1 ) then
		if C:G( C.Settings['traitorwepesp'], 1 ) and C:IsTTT() then
			for i = 1, table.Count( C.World.traitorweapons ) do
				local ent = ents.FindByClass( C.World.traitorweapons[i] )
				for e = 1, table.Count( ent ) do
					local pos = ent[e]:GetPos():ToScreen()
					local wep = string.gsub( C.World.traitorweapons[i], "weapon_ttt_", "" )
					draw.SimpleTextOutlined(
						tostring( wep ), "DefaultSmall",
						pos.x, pos.y,
						Color( 255, 55, 55, 255 ),
						TEXT_ALIGN_RIGHT, TEXT_ALIGN_TOP,
						1, Color( 0, 0, 0, 255 )
					)
				end
			end
		end
	end
end

--[[--------------------------------------------
	CROSSHAIR
--]]--------------------------------------------

function C.DrawCrosshair()
	if C:G( C.Settings['crosshair'], 1 ) then
		local w, h = ScrW() / 2, ScrH() / 2
		local e1, e2 = 5, 20
		if C:G( C.Settings['aim'], 1 ) then
			surface.SetDrawColor( 255, 0, 0, 255 )
		else
			surface.SetDrawColor( 0, 255, 0, 255 )
		end
		surface.DrawLine( w - e1, h, w, h )
   		surface.DrawLine( w + e1, h, w, h )
		surface.DrawLine( w, h - e1, w, h )
		surface.DrawLine( w, h + e1, w, h )
		if C.Vars.found and not C.Vars.aimlocked then
			surface.SetDrawColor( 255, 255, 255, 255 )
			surface.DrawOutlinedRect(
				( w - e1 ) - 2,
				( h - e1 ) - 2,
				( ( e1 + 2 ) * 2 ) + 1,
				( ( e1 + 2 ) * 2 ) + 1
			)
		elseif C.Vars.found and C.Vars.aimlocked then
			surface.SetDrawColor( 255, 255, 255, 255 )
			surface.DrawLine( w - e2, h, w - e1, h )
			surface.DrawLine( w + e2, h, w + e1, h )
			surface.DrawLine( w, h - e2, w, h - e1 )
			surface.DrawLine( w, h + e2, w, h + e1 )
		end
		if C.Vars.found and ( C.Vars.target ~= nil ) then
			draw.SimpleTextOutlined(
				"Target: " .. string.Left( tostring( C.Vars.target:Nick() ), 16 ), "Default",
				w, h + 40,
				Color( 255, 135, 135, 255 ),
				TEXT_ALIGN_CENTER, TEXT_ALIGN_BOTTOM,
				1, Color( 0, 0, 0, 255 )
			)
		end
	end
end

--[[--------------------------------------------
	CHAMS
--]]--------------------------------------------

--[ MATERIAL ]--

function C:GetChamsMaterial()
	local params = {
		["$basetexture"] = "models/debug/debugwhite",
		["$model"]       = 1,
		["$translucent"] = 1,
		["$alpha"]       = 1,
		["$nocull"]      = 1,
		["$ignorez"]	 = 1
	}
	return CreateMaterial( "\0\1", "VertexLitGeneric", params )
end

--[ RENDERING ]--

function C.RenderScreenspaceEffects()
	if C:G( C.Settings['esp'], 1 ) and C:G( C.Settings['chams'], 1 ) then
		cam.Start3D( EyePos(), EyeAngles() )
		render.SuppressEngineLighting( tobool( C.Settings['renderfullbright'] ) )
		render.MaterialOverride( C:GetChamsMaterial() )
		for i = 1, table.Count( C.World.players ) do
			local e = C.World.players[i]
			local vis, invis = C:GetPlayerColor( e )
			if C:IsTargetValid( e, "esp" ) then
				render.SetColorModulation( ( invis.r / 255 ), ( invis.g / 255 ), ( invis.b / 255 ) )
				e:DrawModel()
			end
		end
		render.MaterialOverride()
		for i = 1, table.Count( C.World.players ) do -- Two loops surprisingly saves FPS as opposed to using one.
			local e = C.World.players[i]
			local vis, invis = C:GetPlayerColor( e )
			if C:IsTargetValid( e, "esp" ) then
				render.SetColorModulation( ( vis.r / 255 ), ( vis.g / 255 ), ( vis.b / 255 ) )
				e:SetMaterial( "models/debug/debugwhite" )
				e:DrawModel()
				e:SetMaterial( "" ) -- Reset to default mat due to AIDS.
			end
		end
		render.SuppressEngineLighting( false )
		cam.End3D()
	end
end
C:AddHook( "RenderScreenspaceEffects", C.RenderScreenspaceEffects )

--[[--------------------------------------------
	NAME CHANGING
--]]--------------------------------------------

--[ CONSTANT NAMESTEAL ]--

--[ SINGLE RANDOM NAMESTEAL ]--


--[ BLANK CHARACTER ]--
--[ ULX/EVOLVE UNGAG ]--

function C.UnGag()
	local ply = LocalPlayer()
	if ply and C:G( C.Settings['ungag'], 1 ) then
		if ulx and ulx.gagUser then
			ulx.gagUser( false )
			C.Copy.hook.Remove( "PlayerBindPress", "ULXGagForce" )
			timer.Destroy( "GagLocalPlayer" )
		end
		if evolve then
			ply:SetNWBool( "Muted", false ) -- Thanks stgn.
		end
	end
end

--[[--------------------------------------------
	PLAYERS AND ENTITIES
--]]--------------------------------------------

function C.GetAllPlayers()
	C.World.players = {}
	for i = 1, table.Count( player.GetAll() ) do
		local e = player.GetAll()[i]
		if IsValid( e ) then table.insert( C.World.players, e ) end
	end
end

// I don't like changing my binds
C:AddCommand("+Hera_Speed",function()
	old_rcc("sp00f_bs_host_timescale",3);
end)

C:AddCommand("-Hera_Speed",function()
	old_rcc("sp00f_bs_host_timescale",1)
end)

--[[--------------------------------------------
	HOOKED FUNCTIONS
--]]--------------------------------------------

function C.CreateMove( cmd )
	C.Aimbot( cmd )
	C.Bunnyhop( cmd )
	C.TTTPropkill( cmd )
end
C:AddHook( "CreateMove", C.CreateMove )

function C.HUDPaintHook()
	C.DrawTargetLine()
	C.DrawPlayerESP()
	C.DrawAdminList()
	C.DrawRPEntities()
	C.DrawTraitorWeapons()
	C.DrawCrosshair()
end
C:AddHook( "HUDPaint", C.HUDPaintHook )

function C.ThinkHook()
	C.GetAllPlayers()
	C.UnGag()
end
C:AddHook( "Think", C.ThinkHook )

--[[--------------------------------------------
	MENU
--]]--------------------------------------------

function C.Menu()
	local w, h, s = ScrW() / 2, ScrH() / 2, 5
	local x, y = 400, 325
	local px, py = x - 10, y - 30
	local tx, ty = x - 20, y - 65
	C.panel = vgui.Create( "DFrame" )
	C.panel:SetPos( w - x / 2, h - y / 2 )
	C.panel:SetSize( x, y )
	C.panel:SetTitle( ":: ph0ne.lua" )
	C.panel:SetVisible( true )
	C.panel:SetDraggable( true )
	C.panel:ShowCloseButton( true )
	C.panel:MakePopup()
	C.panel.Paint = function()
		draw.RoundedBox( 0, 0, 0, x, y, Color( 25, 55, 105, 55 ) )
		surface.SetDrawColor( Color( 0, 0, 0, 255 ) )
		surface.DrawOutlinedRect( 0, 0, x, y )
	end
	local page = vgui.Create( "DPropertySheet" )
	page:SetParent( C.panel )
	page:SetPos( 5, 25 )
	page:SetSize( px, py )
	page.Paint = function ()
		draw.RoundedBox( 0, 0, 0, px, py, Color( 0, 0, 0, 0 ) )
	end
	local aim = vgui.Create( "DPanel", page )
	aim.Paint = function()
		draw.RoundedBox( 0, 0, 0, tx, ty, Color( 0, 0, 0, 155 ) )
		surface.SetDrawColor( Color( 0, 0, 0, 255 ) )
		surface.DrawOutlinedRect( 0, 0, tx, ty )
	end
	local aimlist = vgui.Create( "DPanelList" )
	aimlist:SetPos( 10, 10 )
	aimlist:SetParent( aim )
	aimlist:SetSize( tx - 15, ty - 20 )
	aimlist:EnableVerticalScrollbar( true )
	aimlist:SetSpacing( s )
	aimlist.Paint = function() draw.RoundedBox( 0, 0, 0, tx - 15, ty - 20, Color( 0, 0, 0, 0 ) ) end
	local esp = vgui.Create( "DPanel", page )
	esp.Paint = function()
		draw.RoundedBox( 0, 0, 0, tx, ty, Color( 0, 0, 0, 155 ) )
		surface.SetDrawColor( Color( 0, 0, 0, 255 ) )
		surface.DrawOutlinedRect( 0, 0, tx, ty )
	end
	local esplist = vgui.Create( "DPanelList" )
	esplist:SetPos( 10, 10 )
	esplist:SetParent( esp )
	esplist:SetSize( tx - 15, ty - 20 )
	esplist:EnableVerticalScrollbar( true )
	esplist:SetSpacing( s )
	esplist.Paint = function() draw.RoundedBox( 0, 0, 0, tx - 15, ty - 20, Color( 0, 0, 0, 0 ) ) end
	local misc = vgui.Create( "DPanel", page )
	misc.Paint = function()
		draw.RoundedBox( 0, 0, 0, tx, ty, Color( 0, 0, 0, 155 ) )
		surface.SetDrawColor( Color( 0, 0, 0, 255 ) )
		surface.DrawOutlinedRect( 0, 0, tx, ty )
	end
	local misclist = vgui.Create( "DPanelList" )
	misclist:SetPos( 10, 10 )
	misclist:SetParent( misc )
	misclist:SetSize( tx - 15, ty - 20 )
	misclist:EnableVerticalScrollbar( true )
	misclist:SetSpacing( s )
	misclist.Paint = function() draw.RoundedBox( 0, 0, 0, tx - 15, ty - 20, Color( 0, 0, 0, 0 ) ) end
	for _, v in ipairs( C.MenuInfo ) do
		if ( v.Type == "bool" ) then
			local checkbox = vgui.Create( "DCheckBoxLabel" )
			checkbox:SetText( v.Desc )
			checkbox:SetConVar( v.Name )
			checkbox:SetValue( GetConVarNumber( v.Name ) )
			checkbox:SetTextColor( Color( 255, 255, 255, 255 ) )
			if ( v.Menu == "aim" ) then
				aimlist:AddItem( checkbox )
			elseif ( v.Menu == "esp" ) then
				esplist:AddItem( checkbox )
			elseif ( v.Menu == "misc" ) then
				misclist:AddItem( checkbox )
			end
		elseif ( v.Type == "number" ) then
			local slider = vgui.Create( "DNumSlider" )
			slider:SetText( "" )
			slider:SetMax( v.Max or 1 )
			slider:SetMin( v.Min or 0 )
			slider:SetDecimals( 0 )
			slider:SetConVar( v.Name )
			slider:SetValue( GetConVarNumber( v.Name ) )
			local label = vgui.Create( "DLabel" )
			label:SetParent( slider )
			label:SetWide( 150 )
			label:SetText( v.Desc )
			label:SetTextColor( Color( 255, 255, 255, 255 ) )
			if ( v.Menu == "aim" ) then
				aimlist:AddItem( slider )
			elseif ( v.Menu == "esp" ) then
				esplist:AddItem( slider )
			elseif ( v.Menu == "misc" ) then
				misclist:AddItem( slider )
			end
		end
	end
	local label = vgui.Create( "DLabel" )
	label:SetText( "Prediction Type" )
	label:SetTextColor( Color( 255, 255, 255, 255 ) )
	aimlist:AddItem( label )
	aimlist:AddItem( multichoice )
	local button = vgui.Create( "DButton" )
	button:SetText( "No Name" )
	button.DoClick = function() end
	misclist:AddItem( button )
	local button = vgui.Create( "DButton" )
	button:SetText( "Steal Random Name" )
	button.DoClick = function() end
	misclist:AddItem( button )

	
	page:AddSheet( "Aimbot", aim, nil, false, false, nil )
	page:AddSheet( "ESP", esp, nil, false, false, nil )
	page:AddSheet( "Misc", misc, nil, false, false, nil )
	//page:AddSheet( "Log", log, nil, false, false, nil );
end
C:AddCommand("ph0ne_menu",C.Menu);
C:Log("Successfully loaded.")

--[[--------------------------------------------
	END MESSAGE
--]]--------------------------------------------</pre></body></html>