-- note by paradox: Given to me directly by Tyler (0xymoron).


-- ColdFire Round Two --

-- Started April 2011 by Flapadar
-- Finished September 2011.

-- This won't work now, which is why I'm releasing this. It's no work of art.
-- But, I felt it sitting on my hard drive wasn't suitable for something I found so fun developing
-- The HVH fights vs everyone in the lua section really was a better drive than the shittier aspects of cheating (I think we all know what I mean there)

--Legal shit

--Don't bother trying to sell this - or edits of it. You don't have and won't get my permission.

-- Enjoy - Flapadar; 03/10/12


/* 

	Repaired by 0xymoron
	
	This is a fairly lazy port, I've just made it function, it will not have the same functionality as it did in 2011
	Some features have been removed due to incompatability or due to me not wanting to fix them.
	
	Lua NoSpread ported from snixzz3
	
	
	Missing/Incomplete features include:
	-Detours
	-IP Logger (no shit)
	-Silent aim is fucked
	-Entity transparency
	-Bunnyhop is fucky
	-Lua loader node tree is incomplete
	-Fullbright
	-Lua Logger (cus no detours)
	
	
*/


--[[

ToDO:


]]

local coldfire = {}

local DEBUGMODE = false

if DEBUGMODE then
	print("debug.")
	CF_GetCommandNumber = function() return 1 end
	CF_ManipulateShot = function(seed,a) return a end
	CF_GetPing = function() return 0.0005 end
	CF_SetConvar = function(cmd,v) rcc(cmd,v) end
	CF_Spoof = function() end
	CF_IsDormant = function(p) return false end
	CF_SetIPSpoofCallBack = function() end
	CF_SetRunScriptCallBack = function() end
end

if render.GetDXLevel() < 90 then
	MsgN("[ColdFire] FATAL ERROR: DXLevel 8 can cause crashes. We recommend setting it to 9.8 with -dxlevel 98 in the advanced launch options of garry's mod.")
end

-- Set globals to nil --

local _R = debug.getregistry()

//require( "snixzz2" )

/*
coldfire.GetUCMDNumber = CF_GetCommandNumber
coldfire.ShotManip = CF_ManipulateShot
coldfire.GetLocalPing = CF_GetPing
coldfire.Force = CF_SetConvar
coldfire.Spoof = CF_SpoofConvar
coldfire.IsDormant = CF_IsDormant
*/

coldfire.GetUCMDNumber = function( ... ) end;
coldfire.ShotManip = function( ... ) end;
coldfire.GetLocalPing = function( ... ) end;
coldfire.Force = function( ... ) end;
coldfire.Spoof = function( ... ) end;
coldfire.IsDormant = function( ... ) end;


//coldfire.ShotManip(1234,Angle(0,0,0):Forward(), Vector(0,0,0))

CF_GetCommandNumber = nil;
CF_ManipulateShot = nil;
CF_Require = nil;
CF_GetPing = nil;
CF_SetConVar = nil;
CF_SpoofConvar = nil;
CF_IsDormant = nil;


coldfire.UCMD = _R.CUserCmd
coldfire.SVA = _R.CUserCmd.SetViewAngles //coldfire.UCMD.SetViewAngles
coldfire.GVA = _R.CUserCmd.GetViewAngles //coldfire.UCMD.GetViewAngles
coldfire.GetButtons = _R.CUserCmd.GetButtons //coldfire.UCMD.GetButtons
coldfire.SetButtons = _R.CUserCmd.SetButtons //coldfire.UCMD.SetButtons
coldfire.Read = file.Read
coldfire.Write = file.Write
coldfire.Exists = file.Exists


--

local cexists = ConVarExists

--


-- LUA NOSPREAD, IMPORTED BECAUSE MODULE IS LOST FOREVER --
local md5 = {
  _VERSION     = "md5.lua 0.5.0",
  _DESCRIPTION = "MD5 computation in Lua (5.1)",
  _URL         = "https://github.com/kikito/md5.lua",
  _LICENSE     = [[
    MIT LICENSE
 
    Copyright (c) 2013 Enrique Garc’a Cota + Adam Baldwin + hanzao + Equi 4 Software
 
    Permission is hereby granted, free of charge, to any person obtaining a
    copy of this software and associated documentation files (the
    "Software"), to deal in the Software without restriction, including
    without limitation the rights to use, copy, modify, merge, publish,
    distribute, sublicense, and/or sell copies of the Software, and to
    permit persons to whom the Software is furnished to do so, subject to
    the following conditions:
 
    The above copyright notice and this permission notice shall be included
    in all copies or substantial portions of the Software.
 
    THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
    OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
    MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
    IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
    CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
    TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
    SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
  ]]
}
 
md5.const = {
  0xd76aa478, 0xe8c7b756, 0x242070db, 0xc1bdceee,
  0xf57c0faf, 0x4787c62a, 0xa8304613, 0xfd469501,
  0x698098d8, 0x8b44f7af, 0xffff5bb1, 0x895cd7be,
  0x6b901122, 0xfd987193, 0xa679438e, 0x49b40821,
  0xf61e2562, 0xc040b340, 0x265e5a51, 0xe9b6c7aa,
  0xd62f105d, 0x02441453, 0xd8a1e681, 0xe7d3fbc8,
  0x21e1cde6, 0xc33707d6, 0xf4d50d87, 0x455a14ed,
  0xa9e3e905, 0xfcefa3f8, 0x676f02d9, 0x8d2a4c8a,
  0xfffa3942, 0x8771f681, 0x6d9d6122, 0xfde5380c,
  0xa4beea44, 0x4bdecfa9, 0xf6bb4b60, 0xbebfbc70,
  0x289b7ec6, 0xeaa127fa, 0xd4ef3085, 0x04881d05,
  0xd9d4d039, 0xe6db99e5, 0x1fa27cf8, 0xc4ac5665,
  0xf4292244, 0x432aff97, 0xab9423a7, 0xfc93a039,
  0x655b59c3, 0x8f0ccc92, 0xffeff47d, 0x85845dd1,
  0x6fa87e4f, 0xfe2ce6e0, 0xa3014314, 0x4e0811a1,
  0xf7537e82, 0xbd3af235, 0x2ad7d2bb, 0xeb86d391,
  0x67452301, 0xefcdab89, 0x98badcfe, 0x10325476
}
 
local f=function (x,y,z) return bit.bor(bit.band(x,y),bit.band(-x-1,z)) end
local g=function (x,y,z) return bit.bor(bit.band(x,z),bit.band(y,-z-1)) end
local h=function (x,y,z) return bit.bxor(x,bit.bxor(y,z)) end
local i=function (x,y,z) return bit.bxor(y,bit.bor(x,-z-1)) end
local z=function (f,a,b,c,d,x,s,ac)
  a=bit.band(a+f(b,c,d)+x+ac,0xffffffff)
  return bit.bor(bit.lshift(bit.band(a,bit.rshift(0xffffffff,s)),s),bit.rshift(a,32-s))+b
end
local MAX = 2^31
local SUB = 2^32
function md5.fix(a)
  if a > MAX then return a-SUB end
  return a
end
 
function md5.transform(A,B,C,D,X)
  local a,b,c,d=A,B,C,D
  a=z(f,a,b,c,d,X[ 0], 7,md5.const[ 1])
  a=md5.fix(a) b=md5.fix(b) c=md5.fix(c) d=md5.fix(d)
  d=z(f,d,a,b,c,X[ 1],12,md5.const[ 2])
  a=md5.fix(a) b=md5.fix(b) c=md5.fix(c) d=md5.fix(d)
  c=z(f,c,d,a,b,X[ 2],17,md5.const[ 3])
  a=md5.fix(a) b=md5.fix(b) c=md5.fix(c) d=md5.fix(d)
  b=z(f,b,c,d,a,X[ 3],22,md5.const[ 4])
  a=md5.fix(a) b=md5.fix(b) c=md5.fix(c) d=md5.fix(d)
  a=z(f,a,b,c,d,X[ 4], 7,md5.const[ 5])
  a=md5.fix(a) b=md5.fix(b) c=md5.fix(c) d=md5.fix(d)
  d=z(f,d,a,b,c,X[ 5],12,md5.const[ 6])
  a=md5.fix(a) b=md5.fix(b) c=md5.fix(c) d=md5.fix(d)
  c=z(f,c,d,a,b,X[ 6],17,md5.const[ 7])
  a=md5.fix(a) b=md5.fix(b) c=md5.fix(c) d=md5.fix(d)
  b=z(f,b,c,d,a,X[ 7],22,md5.const[ 8])
  a=md5.fix(a) b=md5.fix(b) c=md5.fix(c) d=md5.fix(d)
  a=z(f,a,b,c,d,X[ 8], 7,md5.const[ 9])
  a=md5.fix(a) b=md5.fix(b) c=md5.fix(c) d=md5.fix(d)
  d=z(f,d,a,b,c,X[ 9],12,md5.const[10])
  a=md5.fix(a) b=md5.fix(b) c=md5.fix(c) d=md5.fix(d)
  c=z(f,c,d,a,b,X[10],17,md5.const[11])
  a=md5.fix(a) b=md5.fix(b) c=md5.fix(c) d=md5.fix(d)
  b=z(f,b,c,d,a,X[11],22,md5.const[12])
  a=md5.fix(a) b=md5.fix(b) c=md5.fix(c) d=md5.fix(d)
  a=z(f,a,b,c,d,X[12], 7,md5.const[13])
  a=md5.fix(a) b=md5.fix(b) c=md5.fix(c) d=md5.fix(d)
  d=z(f,d,a,b,c,X[13],12,md5.const[14])
  a=md5.fix(a) b=md5.fix(b) c=md5.fix(c) d=md5.fix(d)
  c=z(f,c,d,a,b,X[14],17,md5.const[15])
  a=md5.fix(a) b=md5.fix(b) c=md5.fix(c) d=md5.fix(d)
  b=z(f,b,c,d,a,X[15],22,md5.const[16])
  a=md5.fix(a) b=md5.fix(b) c=md5.fix(c) d=md5.fix(d)
 
  a=z(g,a,b,c,d,X[ 1], 5,md5.const[17])
  a=md5.fix(a) b=md5.fix(b) c=md5.fix(c) d=md5.fix(d)
  d=z(g,d,a,b,c,X[ 6], 9,md5.const[18])
  a=md5.fix(a) b=md5.fix(b) c=md5.fix(c) d=md5.fix(d)
  c=z(g,c,d,a,b,X[11],14,md5.const[19])
  a=md5.fix(a) b=md5.fix(b) c=md5.fix(c) d=md5.fix(d)
  b=z(g,b,c,d,a,X[ 0],20,md5.const[20])
  a=md5.fix(a) b=md5.fix(b) c=md5.fix(c) d=md5.fix(d)
  a=z(g,a,b,c,d,X[ 5], 5,md5.const[21])
  a=md5.fix(a) b=md5.fix(b) c=md5.fix(c) d=md5.fix(d)
  d=z(g,d,a,b,c,X[10], 9,md5.const[22])
  a=md5.fix(a) b=md5.fix(b) c=md5.fix(c) d=md5.fix(d)
  c=z(g,c,d,a,b,X[15],14,md5.const[23])
  a=md5.fix(a) b=md5.fix(b) c=md5.fix(c) d=md5.fix(d)
  b=z(g,b,c,d,a,X[ 4],20,md5.const[24])
  a=md5.fix(a) b=md5.fix(b) c=md5.fix(c) d=md5.fix(d)
  a=z(g,a,b,c,d,X[ 9], 5,md5.const[25])
  a=md5.fix(a) b=md5.fix(b) c=md5.fix(c) d=md5.fix(d)
  d=z(g,d,a,b,c,X[14], 9,md5.const[26])
  a=md5.fix(a) b=md5.fix(b) c=md5.fix(c) d=md5.fix(d)
  c=z(g,c,d,a,b,X[ 3],14,md5.const[27])
  a=md5.fix(a) b=md5.fix(b) c=md5.fix(c) d=md5.fix(d)
  b=z(g,b,c,d,a,X[ 8],20,md5.const[28])
  a=md5.fix(a) b=md5.fix(b) c=md5.fix(c) d=md5.fix(d)
  a=z(g,a,b,c,d,X[13], 5,md5.const[29])
  a=md5.fix(a) b=md5.fix(b) c=md5.fix(c) d=md5.fix(d)
  d=z(g,d,a,b,c,X[ 2], 9,md5.const[30])
  a=md5.fix(a) b=md5.fix(b) c=md5.fix(c) d=md5.fix(d)
  c=z(g,c,d,a,b,X[ 7],14,md5.const[31])
  a=md5.fix(a) b=md5.fix(b) c=md5.fix(c) d=md5.fix(d)
  b=z(g,b,c,d,a,X[12],20,md5.const[32])
  a=md5.fix(a) b=md5.fix(b) c=md5.fix(c) d=md5.fix(d)
 
  a=z(h,a,b,c,d,X[ 5], 4,md5.const[33])
  a=md5.fix(a) b=md5.fix(b) c=md5.fix(c) d=md5.fix(d)
  d=z(h,d,a,b,c,X[ 8],11,md5.const[34])
  a=md5.fix(a) b=md5.fix(b) c=md5.fix(c) d=md5.fix(d)
  c=z(h,c,d,a,b,X[11],16,md5.const[35])
  a=md5.fix(a) b=md5.fix(b) c=md5.fix(c) d=md5.fix(d)
  b=z(h,b,c,d,a,X[14],23,md5.const[36])
  a=md5.fix(a) b=md5.fix(b) c=md5.fix(c) d=md5.fix(d)
  a=z(h,a,b,c,d,X[ 1], 4,md5.const[37])
  a=md5.fix(a) b=md5.fix(b) c=md5.fix(c) d=md5.fix(d)
  d=z(h,d,a,b,c,X[ 4],11,md5.const[38])
  a=md5.fix(a) b=md5.fix(b) c=md5.fix(c) d=md5.fix(d)
  c=z(h,c,d,a,b,X[ 7],16,md5.const[39])
  a=md5.fix(a) b=md5.fix(b) c=md5.fix(c) d=md5.fix(d)
  b=z(h,b,c,d,a,X[10],23,md5.const[40])
  a=md5.fix(a) b=md5.fix(b) c=md5.fix(c) d=md5.fix(d)
  a=z(h,a,b,c,d,X[13], 4,md5.const[41])
  a=md5.fix(a) b=md5.fix(b) c=md5.fix(c) d=md5.fix(d)
  d=z(h,d,a,b,c,X[ 0],11,md5.const[42])
  a=md5.fix(a) b=md5.fix(b) c=md5.fix(c) d=md5.fix(d)
  c=z(h,c,d,a,b,X[ 3],16,md5.const[43])
  a=md5.fix(a) b=md5.fix(b) c=md5.fix(c) d=md5.fix(d)
  b=z(h,b,c,d,a,X[ 6],23,md5.const[44])
  a=md5.fix(a) b=md5.fix(b) c=md5.fix(c) d=md5.fix(d)
  a=z(h,a,b,c,d,X[ 9], 4,md5.const[45])
  a=md5.fix(a) b=md5.fix(b) c=md5.fix(c) d=md5.fix(d)
  d=z(h,d,a,b,c,X[12],11,md5.const[46])
  a=md5.fix(a) b=md5.fix(b) c=md5.fix(c) d=md5.fix(d)
  c=z(h,c,d,a,b,X[15],16,md5.const[47])
  a=md5.fix(a) b=md5.fix(b) c=md5.fix(c) d=md5.fix(d)
  b=z(h,b,c,d,a,X[ 2],23,md5.const[48])
  a=md5.fix(a) b=md5.fix(b) c=md5.fix(c) d=md5.fix(d)
 
  a=z(i,a,b,c,d,X[ 0], 6,md5.const[49])
  a=md5.fix(a) b=md5.fix(b) c=md5.fix(c) d=md5.fix(d)
  d=z(i,d,a,b,c,X[ 7],10,md5.const[50])
  a=md5.fix(a) b=md5.fix(b) c=md5.fix(c) d=md5.fix(d)
  c=z(i,c,d,a,b,X[14],15,md5.const[51])
  a=md5.fix(a) b=md5.fix(b) c=md5.fix(c) d=md5.fix(d)
  b=z(i,b,c,d,a,X[ 5],21,md5.const[52])
  a=md5.fix(a) b=md5.fix(b) c=md5.fix(c) d=md5.fix(d)
  a=z(i,a,b,c,d,X[12], 6,md5.const[53])
  a=md5.fix(a) b=md5.fix(b) c=md5.fix(c) d=md5.fix(d)
  d=z(i,d,a,b,c,X[ 3],10,md5.const[54])
  a=md5.fix(a) b=md5.fix(b) c=md5.fix(c) d=md5.fix(d)
  c=z(i,c,d,a,b,X[10],15,md5.const[55])
  a=md5.fix(a) b=md5.fix(b) c=md5.fix(c) d=md5.fix(d)
  b=z(i,b,c,d,a,X[ 1],21,md5.const[56])
  a=md5.fix(a) b=md5.fix(b) c=md5.fix(c) d=md5.fix(d)
  a=z(i,a,b,c,d,X[ 8], 6,md5.const[57])
  a=md5.fix(a) b=md5.fix(b) c=md5.fix(c) d=md5.fix(d)
  d=z(i,d,a,b,c,X[15],10,md5.const[58])
  a=md5.fix(a) b=md5.fix(b) c=md5.fix(c) d=md5.fix(d)
  c=z(i,c,d,a,b,X[ 6],15,md5.const[59])
  a=md5.fix(a) b=md5.fix(b) c=md5.fix(c) d=md5.fix(d)
  b=z(i,b,c,d,a,X[13],21,md5.const[60])
  a=md5.fix(a) b=md5.fix(b) c=md5.fix(c) d=md5.fix(d)
  a=z(i,a,b,c,d,X[ 4], 6,md5.const[61])
  a=md5.fix(a) b=md5.fix(b) c=md5.fix(c) d=md5.fix(d)
  d=z(i,d,a,b,c,X[11],10,md5.const[62])
  a=md5.fix(a) b=md5.fix(b) c=md5.fix(c) d=md5.fix(d)
  c=z(i,c,d,a,b,X[ 2],15,md5.const[63])
  a=md5.fix(a) b=md5.fix(b) c=md5.fix(c) d=md5.fix(d)
  b=z(i,b,c,d,a,X[ 9],21,md5.const[64])
  a=md5.fix(a) b=md5.fix(b) c=md5.fix(c) d=md5.fix(d)
  return A+a,B+b,C+c,D+d
end
 
function md5.PseudoRandom(number)
	local a,b,c,d = md5.fix(md5.const[65]),md5.fix(md5.const[66]),md5.fix(md5.const[67]),md5.fix(md5.const[68])
	local m = { }
	for i=0,15 do m[i] = 0 end
	m[0] = number
	m[1] = 128
	m[14] = 32
	local a,b,c,d = md5.transform(a,b,c,d,m)
	return bit.rshift( md5.fix(b) , 16) % 256--& 0xff this is so mutch faster 
end
 
local engineSpread = {
    	[0] = { -0.492036, 0.286111 },
    	[1] = { -0.492036, 0.286111 },
    	[2] = { -0.255320, 0.128480 },
    	[3] = { 0.456165, 0.356030 },
    	[4] = { -0.361731, 0.406344 },
    	[5] = { -0.146730, 0.834589 },
    	[6] = { -0.253288, -0.421936 },
    	[7] = { -0.448694, 0.111650 },
    	[8] = { -0.880700, 0.904610 },
    	[9] = { -0.379932, 0.138833 },
    	[10] = { 0.502579, -0.494285 },
    	[11] = { -0.263847, -0.594805 },
    	[12] = { 0.818612, 0.090368 },
    	[13] = { -0.063552, 0.044356 },
    	[14] = { 0.490455, 0.304820 },
    	[15] = { -0.192024, 0.195162 },
    	[16] = { -0.139421, 0.857106 },
    	[17] = { 0.715745, 0.336956 },
    	[18] = { -0.150103, -0.044842 },
    	[19] = { -0.176531, 0.275787 },
    	[20] = { 0.155707, -0.152178 },
    	[21] = { -0.136486, -0.591896 },
    	[22] = { -0.021022, -0.761979 },
    	[23] = { -0.166004, -0.733964 },
    	[24] = { -0.102439, -0.132059 },
    	[25] = { -0.607531, -0.249979 },
    	[26] = { -0.500855, -0.185902 },
    	[27] = { -0.080884, 0.516556 },
    	[28] = { -0.003334, 0.138612 },
    	[29] = { -0.546388, -0.000115 },
    	[30] = { -0.228092, -0.018492 },
    	[31] = { 0.542539, 0.543196 },
    	[32] = { -0.355162, 0.197473 },
    	[33] = { -0.041726, -0.015735 },
    	[34] = { -0.713230, -0.551701 },
    	[35] = { -0.045056, 0.090208 },
    	[36] = { 0.061028, 0.417744 },
    	[37] = { -0.171149, -0.048811 },
    	[38] = { 0.241499, 0.164562 },
    	[39] = { -0.129817, -0.111200 },
    	[40] = { 0.007366, 0.091429 },
    	[41] = { -0.079268, -0.008285 },
    	[42] = { 0.010982, -0.074707 },
    	[43] = { -0.517782, -0.682470 },
    	[44] = { -0.663822, -0.024972 },
    	[45] = { 0.058213, -0.078307 },
    	[46] = { -0.302041, -0.132280 },
    	[47] = { 0.217689, -0.209309 },
    	[48] = { -0.143615, 0.830349 },
    	[49] = { 0.270912, 0.071245 },
    	[50] = { -0.258170, -0.598358 },
    	[51] = { 0.099164, -0.257525 },
    	[52] = { -0.214676, -0.595918 },
    	[53] = { -0.427053, -0.523764 },
    	[54] = { -0.585472, 0.088522 },
    	[55] = { 0.564305, -0.533822 },
    	[56] = { -0.387545, -0.422206 },
    	[57] = { 0.690505, -0.299197 },
    	[58] = { 0.475553, 0.169785 },
    	[59] = { 0.347436, 0.575364 },
    	[60] = { -0.069555, -0.103340 },
    	[61] = { 0.286197, -0.618916 },
    	[62] = { -0.505259, 0.106581 },
    	[63] = { -0.420214, -0.714843 },
    	[64] = { 0.032596, -0.401891 },
    	[65] = { -0.238702, -0.087387 },
    	[66] = { 0.714358, 0.197811 },
    	[67] = { 0.208960, 0.319015 },
    	[68] = { -0.361140, 0.222130 },
    	[69] = { -0.133284, -0.492274 },
    	[70] = { 0.022824, -0.133955 },
    	[71] = { -0.100850, 0.271962 },
    	[72] = { -0.050582, -0.319538 },
    	[73] = { 0.577980, 0.095507 },
    	[74] = { 0.224871, 0.242213 },
    	[75] = { -0.628274, 0.097248 },
    	[76] = { 0.184266, 0.091959 },
    	[77] = { -0.036716, 0.474259 },
    	[78] = { -0.502566, -0.279520 },
    	[79] = { -0.073201, -0.036658 },
    	[80] = { 0.339952, -0.293667 },
    	[81] = { 0.042811, 0.130387 },
    	[82] = { 0.125881, 0.007040 },
    	[83] = { 0.138374, -0.418355 },
    	[84] = { 0.261396, -0.392697 },
    	[85] = { -0.453318, -0.039618 },
    	[86] = { 0.890159, -0.335165 },
    	[87] = { 0.466437, -0.207762 },
    	[88] = { 0.593253, 0.418018 },
    	[89] = { 0.566934, -0.643837 },
    	[90] = { 0.150918, 0.639588 },
    	[91] = { 0.150112, 0.215963 },
    	[92] = { -0.130520, 0.324801 },
    	[93] = { -0.369819, -0.019127 },
    	[94] = { -0.038889, -0.650789 },
    	[95] = { 0.490519, -0.065375 },
    	[96] = { -0.305940, 0.454759 },
    	[97] = { -0.521967, -0.550004 },
    	[98] = { -0.040366, 0.683259 },
    	[99] = { 0.137676, -0.376445 },
    	[100] = { 0.839301, 0.085979 },
    	[101] = { -0.319140, 0.481838 },
    	[102] = { 0.201437, -0.033135 },
    	[103] = { 0.384637, -0.036685 },
    	[104] = { 0.598419, 0.144371 },
    	[105] = { -0.061424, -0.608645 },
    	[106] = { -0.065337, 0.308992 },
    	[107] = { -0.029356, -0.634337 },
    	[108] = { 0.326532, 0.047639 },
    	[109] = { 0.505681, -0.067187 },
    	[110] = { 0.691612, 0.629364 },
    	[111] = { -0.038588, -0.635947 },
    	[112] = { 0.637837, -0.011815 },
    	[113] = { 0.765338, 0.563945 },
    	[114] = { 0.213416, 0.068664 },
    	[115] = { -0.576581, 0.554824 },
    	[116] = { 0.246580, 0.132726 },
    	[117] = { 0.385548, -0.070054 },
    	[118] = { 0.538735, -0.291010 },
    	[119] = { 0.609944, 0.590973 },
    	[120] = { -0.463240, 0.010302 },
    	[121] = { -0.047718, 0.741086 },
    	[122] = { 0.308590, -0.322179 },
    	[123] = { -0.291173, 0.256367 },
    	[124] = { 0.287413, -0.510402 },
    	[125] = { 0.864716, 0.158126 },
    	[126] = { 0.572344, 0.561319 },
    	[127] = { -0.090544, 0.332633 },
    	[128] = { 0.644714, 0.196736 },
    	[129] = { -0.204198, 0.603049 },
    	[130] = { -0.504277, -0.641931 },
    	[131] = { 0.218554, 0.343778 },
    	[132] = { 0.466971, 0.217517 },
    	[133] = { -0.400880, -0.299746 },
    	[134] = { -0.582451, 0.591832 },
    	[135] = { 0.421843, 0.118453 },
    	[136] = { -0.215617, -0.037630 },
    	[137] = { 0.341048, -0.283902 },
    	[138] = { -0.246495, -0.138214 },
    	[139] = { 0.214287, -0.196102 },
    	[140] = { 0.809797, -0.498168 },
    	[141] = { -0.115958, -0.260677 },
    	[142] = { -0.025448, 0.043173 },
    	[143] = { -0.416803, -0.180813 },
    	[144] = { -0.782066, 0.335273 },
    	[145] = { 0.192178, -0.151171 },
    	[146] = { 0.109733, 0.165085 },
    	[147] = { -0.617935, -0.274392 },
    	[148] = { 0.283301, 0.171837 },
    	[149] = { -0.150202, 0.048709 },
    	[150] = { -0.179954, -0.288559 },
    	[151] = { -0.288267, -0.134894 },
    	[152] = { -0.049203, 0.231717 },
    	[153] = { -0.065761, 0.495457 },
    	[154] = { 0.082018, -0.457869 },
    	[155] = { -0.159553, 0.032173 },
    	[156] = { 0.508305, -0.090690 },
    	[157] = { 0.232269, -0.338245 },
    	[158] = { -0.374490, -0.480945 },
    	[159] = { -0.541244, 0.194144 },
    	[160] = { -0.040063, -0.073532 },
    	[161] = { 0.136516, -0.167617 },
    	[162] = { -0.237350, 0.456912 },
    	[163] = { -0.446604, -0.494381 },
    	[164] = { 0.078626, -0.020068 },
    	[165] = { 0.163208, 0.600330 },
    	[166] = { -0.886186, -0.345326 },
    	[167] = { -0.732948, -0.689349 },
    	[168] = { 0.460564, -0.719006 },
    	[169] = { -0.033688, -0.333340 },
    	[170] = { -0.325414, -0.111704 },
    	[171] = { 0.010928, 0.723791 },
    	[172] = { 0.713581, -0.077733 },
    	[173] = { -0.050912, -0.444684 },
    	[174] = { -0.268509, 0.381144 },
    	[175] = { -0.175387, 0.147070 },
    	[176] = { -0.429779, 0.144737 },
    	[177] = { -0.054564, 0.821354 },
    	[178] = { 0.003205, 0.178130 },
    	[179] = { -0.552814, 0.199046 },
    	[180] = { 0.225919, -0.195013 },
    	[181] = { 0.056040, -0.393974 },
    	[182] = { -0.505988, 0.075184 },
    	[183] = { -0.510223, 0.156271 },
    	[184] = { -0.209616, 0.111174 },
    	[185] = { -0.605132, -0.117104 },
    	[186] = { 0.412433, -0.035510 },
    	[187] = { -0.573947, -0.691295 },
    	[188] = { -0.712686, 0.021719 },
    	[189] = { -0.643297, 0.145307 },
    	[190] = { 0.245038, 0.343062 },
    	[191] = { -0.235623, -0.159307 },
    	[192] = { -0.834004, 0.088725 },
    	[193] = { 0.121377, 0.671713 },
    	[194] = { 0.528614, 0.607035 },
    	[195] = { -0.285699, -0.111312 },
    	[196] = { 0.603385, 0.401094 },
    	[197] = { 0.632098, -0.439659 },
    	[198] = { 0.681016, -0.242436 },
    	[199] = { -0.261709, 0.304265 },
    	[200] = { -0.653737, -0.199245 },
    	[201] = { -0.435512, -0.762978 },
    	[202] = { 0.701105, 0.389527 },
    	[203] = { 0.093495, -0.148484 },
    	[204] = { 0.715218, 0.638291 },
    	[205] = { -0.055431, -0.085173 },
    	[206] = { -0.727438, 0.889783 },
    	[207] = { -0.007230, -0.519183 },
    	[208] = { -0.359615, 0.058657 },
    	[209] = { 0.294681, 0.601155 },
    	[210] = { 0.226879, -0.255430 },
    	[211] = { -0.307847, -0.617373 },
    	[212] = { 0.340916, -0.780086 },
    	[213] = { -0.028277, 0.610455 },
    	[214] = { -0.365067, 0.323311 },
    	[215] = { 0.001059, -0.270451 },
    	[216] = { 0.304025, 0.047478 },
    	[217] = { 0.297389, 0.383859 },
    	[218] = { 0.288059, 0.262816 },
    	[219] = { -0.889315, 0.533731 },
    	[220] = { 0.215887, 0.678889 },
    	[221] = { 0.287135, 0.343899 },
    	[222] = { 0.423951, 0.672285 },
    	[223] = { 0.411912, -0.812886 },
    	[224] = { 0.081615, -0.497358 },
    	[225] = { -0.051963, -0.117891 },
    	[226] = { -0.062387, 0.331698 },
    	[227] = { 0.020458, -0.734125 },
    	[228] = { -0.160176, 0.196321 },
    	[229] = { 0.044898, -0.024032 },
    	[230] = { -0.153162, 0.930951 },
    	[231] = { -0.015084, 0.233476 },
    	[232] = { 0.395043, 0.645227 },
    	[233] = { -0.232095, 0.283834 },
    	[234] = { -0.507699, 0.317122 },
    	[235] = { -0.606604, -0.227259 },
    	[236] = { 0.526430, -0.408765 },
    	[237] = { 0.304079, 0.135680 },
    	[238] = { -0.134042, 0.508741 },
    	[239] = { -0.276770, 0.383958 },
    	[240] = { -0.298963, -0.233668 },
    	[241] = { 0.171889, 0.697367 },
    	[242] = { -0.292571, -0.317604 },
    	[243] = { 0.587806, 0.115584 },
    	[244] = { -0.346690, -0.098320 },
    	[245] = { 0.956701, -0.040982 },
    	[246] = { 0.040838, 0.595304 },
    	[247] = { 0.365201, -0.519547 },
    	[248] = { -0.397271, -0.090567 },
    	[249] = { -0.124873, -0.356800 },
    	[250] = { -0.122144, 0.617725 },
    	[251] = { 0.191266, -0.197764 },
    	[252] = { -0.178092, 0.503667 },
    	[253] = { 0.103221, 0.547538 },
    	[254] = { 0.019524, 0.621226 },
    	[255] = { 0.663918, -0.573476 },
}

-- Hook System --

local coldhooks = {}

function coldfire:Hook(type , func)
	//coldhooks[type] = coldhooks[type] or {}
	//table.insert(coldhooks[type] , func)
	hook.Add( type, tostring( func ), func )
end

function coldfire:RemoveHook(type)
	coldhooks[type] = nil
end

-- ConCommand system --

local cmdadd = _G.concommand.Add
local cmdremove = _G.concommand.Remove

local pausecommands = {}
function coldfire:RegisterCommand(cmd,func)
	cmdadd( cmd, func )
	/*if not cmdadd then
		pausecommands[cmd] = func
	else
		return cmdadd and cmdadd(cmd,func)
	end*/
end

function coldfire:UnRegisterCommand(cmd)
	return cmdremove and cmdremove(cmd)
end


-- Logging System --

local dbginfo = function( ... ) end//debug.getinfo

coldfire.Logs = {}

function coldfire:LogFunction(funcname , log , level , blocked)
	local info = dbginfo(3) or {short_src = "[NONE]" , currentline = "[NONE]"}
	
	if coldfire.Settings and coldfire.Settings.ShowLogs and tonumber(coldfire.Settings.LogLevel or 1) >= level then
		print("[ColdFire] "..funcname..": "..log.. "("..info.short_src..": "..info.currentline..")".. (blocked and  " BLOCKED " or ""))
		table.insert(coldfire.Logs, {funcname,log,"("..info.short_src..": "..info.currentline..")",blocked})
	elseif not coldfire.Settings then 
		print("[ColdFire] "..funcname..": "..log.. "("..info.short_src..": "..info.currentline..")".. (blocked and  " BLOCKED " or ""))
		table.insert(coldfire.Logs, {funcname,log,"("..info.short_src..": "..info.currentline..")",blocked})
	end
end

local IPLog = {}
function coldfire:AddNickIP(steam,ip,name,x)
	IPLog = IPLog or {}
	IPLog[steam] = {name,ip}
	coldfire.Write("coldfire/iplog.txt" , glon.encode(IPLog or {}))
	
	if coldfire.AddNickToPanel then
		coldfire:AddNickToPanel(name,steam,ip)
	end
end

function coldfire:GetIPByNick(nick)
	local r ={}
	for k , v in pairs(IPLog) do
		if string.find(v[1]:lower(),nick:lower()) then
			table.insert(r,v[2])
		end
	end
	return r
end

function coldfire:GetNickIPs()
	return glon.decode(coldfire.Read("coldfire/iplog.txt") or "") or {}
end

function coldfire.PlayerConnect(steam,address,x,y)
	coldfire:LogFunction("PlayerConnect" , steam.." , " .. address.." , " .. (x or "") , 2)
	coldfire:AddNickIP(steam,address,x)
end

if type(CF_SetIPSpoofCallBack) == "function" then
	CF_SetIPSpoofCallBack(coldfire.PlayerConnect)
else
	MsgN("[ColdFire:120] IP Callback is "..type(CF_SetIPSpoofCallBack))
end

CF_SetIPSpoofCallBack = nil

--[[	g_Luagame->SetGlobal("CF_GetCommandNumber",GetCmdNr); 
	g_Luagame->SetGlobal("CF_ManipulateShot", ManipShot);
	g_Luagame->SetGlobal("CF_IsDormant", IsDormant);
	g_Luagame->SetGlobal("CF_GetPing", GetPing);
	g_Luagame->SetGlobal("CF_SetConvar", SetConVar );
	g_Luagame->SetGlobal("CF_SpoofConvar", SpoofConVar );
	g_Luagame->SetGlobal("CF_SetIPSpoofCallBack", SetConnectCallBack);
	g_Luagame->SetGlobal("CF_SetRunScriptCallBack", SetonRunScriptCallBack);
	g_Luagame->SetGlobal("CF_SetDisconnectCallBack", SetDisconnectCallBack);]]

local blockedPaths = {}	

function coldfire.OnRunScript(path,bool)	
	coldfire:LogFunction("OnRunScript" , path.." , " .. (bool and "true" or (bool == false) and "false" or "nil") , 4)
	
	if blockedPaths[path] then
		return false
	end
end 

//CF_SetRunScriptCallBack(coldfire.OnRunScript)
CF_SetRunScriptCallBack = nil;


	
--------------------------
--[[

PREREQUIRE SCRIPT + OVERRIDE WITH DEBUG PATCH

]]
--------------------------

local req = require
local creq = req
local preloaded = {}

local hookcall = function() end
--print(hookcall)
local cfhookcall

local oldhook = {}

local function cfhookcall(type , gm , ...)
	--print(hook.Call,hookcall , cfhookcall)
	if coldhooks[type] then
		for k , v in pairs(coldhooks[type]) do
			local isok , ret = pcall(v,...)
			if isok and ret ~= nil then
				return ret
			elseif not isok then
				ErrorNoHalt("[ColdFire] ("..type..","..k..") "..ret.."\n")
			end
		end
	end
	
	if type == "PlayerBindPress" or type == "BindPress" then
		local args = {...}
		table.remove(args,1)
		table.remove(args,2)
		local concat = table.concat(args," ")
		if string.find(concat:lower(),"cf_") then
			return;
		end
	end
	return coldfire.OldCall(type, gm , ...)
end


local function preRequire(module)
	

	local retval = creq(module)
	
	for k , v in pairs(retval) do
		oldhook[k] = v
	end
	--[[
	if module == "hook" then
		hookcall = retval.Call
		
		setmetatable( retval, 
			{ __index = function( t, k )
				if( k == "Call" ) then 
					return cfhookcall
				end
				return oldhook[k] end,
				
				__newindex = function( t, k, v ) 
					if k == "Call" then 
						if v ~= cfhookcall then 
							hookcall = v 
						end 
						return
					end
					oldhook[k] = v 
				end,
				__metatable = true
			}
		)
	end]]
	
	preloaded[module] = retval
	
	package.loaded[module] = nil
	
	for k , v in pairs(_G) do
		if v == retval then
			_G[k] = nil
		end
	end
	
	return preloaded[module]
end

local funcoverrides = {}

local function searchAndReplace(a,b)
	local function scanTable(tbl , done)
		done = done or {}
		for k , v in pairs(tbl) do
			if v == a then
				tbl[k] = b
			end
			
			if type(v) == "table" and v ~= tbl and not done[v] then
				done[v] = true
				scanTable(v , done)
			end
		end
	end
	
	scanTable(_G)
end

--------------------------
--[[

Misc shit

]]
--------------------------

local function tableSetKeys(table)
	local ret = {}
	local counter = 0
	
	for k , v in pairs(table) do
		counter = counter + 1
		ret[counter] = v
	end
	return ret
end


local function normalise(angle)
	if type(angle) == "Angle" then
		return Angle(math.NormalizeAngle(angle.p) , math.NormalizeAngle(angle.y) , math.NormalizeAngle(angle.r))
	end
	return angle
end

local f = math.floor
 
local function band(x,y)
    local z = 0
    for i=0,31 do
        if f(x/2^i)%2 == 1 and f(y/2^i)%2 == 1 then
            z = z+2^i
        end
    end
    return z
end
 
local function bor(x,y)
    local z = 0
    for i=0,31 do
        if f(x/2^i)%2 == 1 or f(y/2^i)%2 == 1 then
            z = z+2^i
        end
    end
    return z
end


-- Antidetection shit --

local hookadd
local hookremove
local hookcall = function() end
local hookgettable
local oldhook = {} 

local pcall = pcall

local cmdrdo_not_want = {}

local function fakeconcommandRemove(cmd)
	if string.find(string.lower(cmd) , "cf") then
		coldfire:LogFunction("concommand.Remove" , cmd , 1 , true)
		return
	end
	
	for k , v in pairs(cmdrdo_not_want) do
		if string.find(string.lower(cmd) , v) then
			coldfire:LogFunction("concommand.Remove" , cmd , 2 , true)
			return;
		end
	end
	
	return coldfire.concommandremove(cmd)
end


local concommandadd
local concommandremove
local concommandrun
local concommandautocomplete

local rcc = RunConsoleCommand

local blockcmd = {
--"-voicerecord"
}

local blockargs = {
"coldfire" , "cf",
}

local function myRCC(cmd,...)
	if coldfire.Settings.LockdownLua then
		MsgN("[ColdFire] RunConsoleCommand blocked:  Lua is locked down")
		coldfire:LogFunction("RunConsoleCommand" , cmd.." "..table.concat({...} , ",") , 1 , true)
		return
	end
	
	if not cmd then
		local a,b = pcall(rcc,nil)
		local cp = dbginfo(2).short_src
		local line = dbginfo(2).currentline
		error("["..cp..":"..line.."] "..b,0)
		return;
	end
	
	for k , v in pairs(blockcmd) do
		if table.HasValue(blockcmd , cmd) then
			coldfire:LogFunction("RunConsoleCommand" , cmd.." "..table.concat({...} , ",") , 1 , true)
			return;
		end
	end
	
	for k , v in pairs({...}) do
		if table.HasValue(blockargs,v) then
			if k > 1 then
				if LocalPlayer and IsValid(LocalPlayer()) then
					LocalPlayer():ChatPrint("[ColdFire] Suspected anticheat attempt:  "..dbginfo(2).short_src.." - Please report this on our forums")
				end
			else
				coldfire:LogFunction("RunConsoleCommand" , (cmd.." ")..table.concat({...} , "," ) , 1 , true)
				return;
			end
		end
	end
	coldfire:LogFunction("RunConsoleCommand" , (cmd or "").." ".. table.concat({...} , ",") , 2)
	return rcc(cmd,...)
end

//debugOverride(RunConsoleCommand,myRCC)

local pcc = _R.Player.ConCommand
local function myPCC(pl , cmd)
	if coldfire.Settings.LockdownLua then
		MsgN("[ColdFire] _R.Player.ConCommand blocked:  Lua is locked down")
		coldfire:LogFunction("_R.Player.ConCommand" ,cmd, 1 , true)
		return
	end
	
	for k , v in pairs(blockcmd) do
		if string.find(string.lower(cmd),v) then
			coldfire:LogFunction("_R.Player.ConCommand" , cmd , 1 , true)
			return;
		end
	end
	
	for k , v in pairs(string.Explode(" " , cmd)) do
		for a , b in pairs(blockargs) do
			if string.find(string.lower(v) , b) then
				if k > 2 then
					if LocalPlayer and IsValid(LocalPlayer()) then
						LocalPlayer():ChatPrint("[ColdFire] Suspected anticheat attempt:  "..dbginfo(2).short_src.." - Please report this on our forums")
					end
				else
						coldfire:LogFunction("_R.Player.ConCommand" ,cmd, 1 , true)
					return;
				end
			end
		end
	end
	
	coldfire:LogFunction("_R.Player.ConCommand" , cmd , 2)
	return pcc(pl,cmd)
end

local convars = {}

local function AddChangeCallback(convar , callback)
	cvars.AddChangeCallback( convar, callback )
	//table.insert(convars , {c=convar , cb=callback,v=GetConVar(convar):GetString()})
end

--local cv = preRequire("cvars")

local function cfOCC(name,old,new)
	local found = false
	for k , v in pairs(convars) do
		if v.c:lower () == name:lower() then
			v.cb(name,old,new)
			found = true
		end
	end
	
	
	return found and nil or coldfire.OldConVarC(name,old,new)
end

-- Settings --

if !file.IsDir( "ColdFire", "DATA" ) then

	file.CreateDir( "ColdFire" )

end

coldfire.SaveSettings = {}

function coldfire:SaveData(key,val)
	coldfire.SaveSettings[key] = val
	coldfire.Write("coldfire/cf_settings.txt" , util.TableToJSON(coldfire.SaveSettings))
end

coldfire.SavedConVars = {}

/*
coldfire:Hook("InitPostEntity" , function()

	local c = util.JSONToTable( coldfire.Read("coldfire/cf_settings.txt", "DATA"))

	if c and c.convars then
		for k , v in pairs(c.convars) do
			if k and v and k ~= "" then
				//if cexists(k) then
					rcc(k,v)
					coldfire.Settings[k] = v
				//end
			end
		end
		MsgN("[ColdFire] Previous settings loaded.")
	end
end )
*/

/*coldfire:Hook("Initialize" , function()
	IPLog = glon.decode(coldfire.Read("coldfire/iplog.txt") or "")
end )*/
	
	--	return glon.decode(coldfire.Read("coldfire/iplog.txt") or "") or {}



-- ConVar stuff -- 

coldfire.Settings = {}
coldfire.ConVarSettings = {}
coldfire.ConVarSettings["Aim"] = {}
coldfire.ConVarSettings["ESP"] = {}
coldfire.ConVarSettings["Misc"] = {}
coldfire.ConVarNames = {}

local function tobool(int)
	return math.floor(int) == 1
end


function coldfire:CreateConVar(cvar,clean,var,desc,def,maxno,minno,isdec)
	local booltype = false
	if type(def) == "boolean" then
		def = def and 1 or 0
		booltype = true
	end
	
	local convar = CreateConVar(cvar , def , {SERVER_CANNOT_QUERY})
	if booltype then
		coldfire.Settings[var] = tobool(convar:GetInt())
	elseif type(def) == "number" then
		if not isdec then
			coldfire.Settings[var] = convar:GetInt()
		else
			coldfire.Settings[var] = tonumber(convar:GetString())
		end
	elseif type(def) == "string" then
		coldfire.Settings[var] = convar:GetString()
	end

	if string.find(cvar , "aim") then
		if booltype then
			coldfire.ConVarSettings["Aim"][var] = {var = cvar , type = "boolean" , name = var,clean=clean,desc=desc}
		elseif type(def) == "string" then
			coldfire.ConVarSettings["Aim"][var] = {var = cvar , type = "string" , name = var,clean=clean,desc=desc}
		elseif type(def) == "number" then
			coldfire.ConVarSettings["Aim"][var] = {var = cvar , type = "number" , max = maxno , min = minno , dec = isdec , name = var,clean=clean,desc=desc}
		end
	elseif string.find(cvar , "esp") then
		if booltype then
			coldfire.ConVarSettings["ESP"][var] = {var = cvar , type = "boolean" , name = var,clean=clean,desc=desc}
		elseif type(def) == "string" then
			coldfire.ConVarSettings["ESP"][var] = {var = cvar , type = "string" , name = var ,clean=clean,desc=desc}
		elseif type(def) == "number" then
			coldfire.ConVarSettings["ESP"][var] = {var = cvar , type = "number" , max = maxno , min = minno , dec = isdec , name = var,clean=clean,desc=desc}
		end
	else
		if booltype then
			coldfire.ConVarSettings["Misc"][var] = {var = cvar , type = "boolean" , name = var,clean=clean,desc=desc}
		elseif type(def) == "string" then
			coldfire.ConVarSettings["Misc"][var] = {var = cvar , type = "string" , name = var,clean=clean,desc=desc}
		elseif type(def) == "number" then
			coldfire.ConVarSettings["Misc"][var] = {var = cvar , type = "number" , max = maxno , min = minno , dec = isdec , name = var,clean=clean,desc=desc}
		end
	end
	
	table.insert(coldfire.ConVarNames , cvar)
	
	AddChangeCallback(cvar , function(cvar , old , new)
		if booltype then
			coldfire.Settings[var] = tobool(math.floor(new))
		else
			coldfire.Settings[var] = new
		end
		
		coldfire.SavedConVars[cvar] = new
		coldfire:SaveData("convars" , coldfire.SavedConVars)
	end )
	
	return convar
end

coldfire:CreateConVar("cf_aim_enabled" , "Aim Enabled?" ,"AimEnabled" , "Enables the aimbot. You should really do this through a bind." ,false )
coldfire:CreateConVar("cf_aim_maxdistance" , "Max Distance" , "MaxDistance" ,"Sets the maximum distance the aimbot will lock at.", 0 , 16384 , 0)
coldfire:CreateConVar("cf_aim_targetnpcs" , "Target NPCs?" , "TargetNPCs" ,"Should the aimbot target NPCs?", true)
coldfire:CreateConVar("cf_aim_friendlyfire" , "Friendly Fire" , "FriendlyFire" ,"Target people on the same team as yourself?", false)
coldfire:CreateConVar("cf_aim_targetfriends" , "Target Friends?" , "TargetFriends" ,"Target people on your ColdFire friend's list?", false)
coldfire:CreateConVar("cf_aim_targetadmins" , "Target Admins?" , "TargetAdmins" ,"Target server admins?", true)
coldfire:CreateConVar("cf_aim_targetsteamfriends" , "Target Steam Friends?" , "TargetSteamFriends" ,"Target people on your Steam friends list?", true)
coldfire:CreateConVar("cf_aim_onlytargettraitors" , "(TTT) Target Opponents only" , "OnlyTargetTraitors" , "Only target opponents in TTT.", true)
coldfire:CreateConVar("cf_aim_targetmode" , "Targetting Preferences" , "TargetMode" ,"Target selection sorting mode.", 1 , 4 , 1)
coldfire:CreateConVar("cf_aim_bonemode" , "Bone Preference" , "BoneMode", "Which bone the aimbot should lock onto. Do this in the dropdown above.", 1 , 3 , 1)
coldfire:CreateConVar("cf_aim_maxangledifference" , "Maximum Angle (FOV)" , "MaxAngleDiff" , "Maximum Field of View. The aimbot won't snap past this.", 180 , 180 , 0 , true)
coldfire:CreateConVar("cf_aim_ignorelos" , "Ignore Line of Sight" , "IgnoreLOS", "Ignores the line of sight - can you see the target" , false)
coldfire:CreateConVar("cf_aim_velocityprediction" , "Velocity Prediction" , "VelocityPrediction" ,"A little prediction based on velocity.", false)
coldfire:CreateConVar("cf_aim_antisnap" , "Anti Snap" , "AntiSnap" , "Legit/smooth aim enabled?", false)
coldfire:CreateConVar("cf_aim_antisnapspeed" , "Anti Snap Speed" , "AntiSnapSpeed", "Speed anti-snap should move at." , 1 , 10 , 0 , true)
coldfire:CreateConVar("cf_aim_fakeview" , "Fake View" , "FakeView" , "Enable Fake-View. Means that you can walk a different way than you shoot." , true)
coldfire:CreateConVar("cf_aim_checkpartialhits" , "Check Partial Hits" , "CheckPartialHits" , "Target other bones if the main target bone isn't available?" , false)
coldfire:CreateConVar("cf_aim_autofire" , "Auto Fire" , "AutoFire" , "Automatically shoot when locked on?" , true)
coldfire:CreateConVar("cf_aim_autoreload" , "Auto Reload" , "AutoReload" , "Automatically reload when current clip is empty?" , true)
coldfire:CreateConVar("cf_aim_enemymode" , "Enemy Mode" , "EnemyMode" , "Switch to enemy mode. Only enemies will be targetted." , false)
coldfire:CreateConVar("cf_aim_nospread" , "No Spread" , "NoSpread" , "Predicts bullet spread and compensates for it." , true)
coldfire:CreateConVar("cf_aim_predictionseed" , "Prediction Factor" , "PredictionFactor", "Prediction factor. Smaller = more prediction." , 40 , 120 , 20 , true)
coldfire:CreateConVar("cf_aim_offsetz" , "Aim Offset (Z Axis)" ,"AimOffsetZ" , "Aim offset on Z axis. Higher the number, the lower to aim." , 0.5 , 32 , -16 , true)
coldfire:CreateConVar("cf_aim_snaponfire" , "Snap On Fire" , "SnapOnFire" , "Only target when the fire button is held down." , false)
coldfire:CreateConVar("cf_aim_snaponfiretime" , "Snap On Fire Hold Time" , "SnapOnFireTime" , "Time to stay locked on after fire button is released." , 0.6 , 10 , 0.1, true)
coldfire:CreateConVar("cf_aim_ucmdfire" , "CUserCmd Fire" , "CUserCMDFire" , "Use more secure method of firing and reloading." , true)
coldfire:CreateConVar("cf_aim_nospreadonfire" , "Nospread on Fire" , "NoSpreadOnFire" , "Enable nospread when shooting but the aimbot isn't enabled." , false)
coldfire:CreateConVar("cf_aim_ignoreweaponless" , "Ignore Weaponless Players" , "IgnoreWeaponless" , "Ignores weaponless players (Useful for 'ghosts' in gangwarsrp)" , false)
--coldfire:CreateConVar("cf_aim_holdtarget" , "Hold Current Target?" , "HoldTarget" , true)

coldfire:CreateConVar("cf_esp_onlydrawtraitors" , "(TTT) Only Draw Enemies" , "OnlyDrawTraitors", "Only draw enemies in TTT in the ESP." , false)
coldfire:CreateConVar("cf_esp_enabled" , "ESP Enabled" , "ESPEnabled" , "Enable the ESP." , true)
coldfire:CreateConVar("cf_esp_entitytransparency" , "Entity Transparency" , "EntityTransparency","Draw entities with transparency as you get closer to them." , false)
coldfire:CreateConVar("cf_esp_entitytransparencydiameter" , "Entity Transparency Diameter" , "EntityTransparencyDiameter" , "Diameter of the entity transparency function." , 2048, 4096 , 0)
coldfire:CreateConVar("cf_esp_maxespdistance" , "Max ESP Distance" , "MaxESPDistance" , "Maximum distance at which the ESP draws." , 0 , 8192 , 0)
coldfire:CreateConVar("cf_esp_minespdistance" , "Min ESP Distance" , "MinESPDistance" , "Minimum distance at which the ESP draws." , 0 , 8192 , 0)
coldfire:CreateConVar("cf_esp_draweyeangles" , "Draw Eye Angles?" ,"DrawEyeAngles", "Draw local player's real eye angles when correcting view?" , true)
coldfire:CreateConVar("cf_esp_lasersight" , "Draw Laser Sight?" ,"LaserSight", "Always draw real eye angles. (Laser Sight). Useful for targetting manually." , false)
coldfire:CreateConVar("cf_esp_lasereyes" , "Draw Laser Eyes?" ,"LaserEyes", "Draw other player's eye angles." , false)
coldfire:CreateConVar("cf_esp_outlinemodels" , "Outline Models?" , "OutlineModels" , "Outline models (chams)" , false)
coldfire:CreateConVar("cf_esp_drawmodels" , "Draw Models?" , "DrawModels" , "Re-draw models ignoring their Z order (Through walls)" , true)
coldfire:CreateConVar("cf_esp_drawweapons" , "Draw Weapons?" , "DrawWeapons" , "Always show weapons on the ESP" , true)
coldfire:CreateConVar("cf_esp_drawtextinfo" , "Draw Text Info?" , "DrawTextInfo" , "Draw text info about ESP targets" , true)
coldfire:CreateConVar("cf_esp_usesmallerfont" , "Use Small Font?" , "UseSmallFont" , "Use a smaller (and nicer) font" , true)
coldfire:CreateConVar("cf_esp_drawcrosshair" , "Draw Crosshair?" , "DrawCrosshair" , "Draw a crosshair" , false)
coldfire:CreateConVar("cf_esp_showspectators" , "Show Spectators?" , "ShowSpectators" , "Shows people who are spectating you." , true)

coldfire:CreateConVar("cf_spinbot" , "Spin Bot Enabled?" , "SpinBot" , "Enable spinbot" , false)
coldfire:CreateConVar("cf_traitormode" , "(TTT) Traitor Mode" , "TraitorMode" , "Show traitors in TTT" , true)

coldfire:CreateConVar("cf_logs_enabled" , "Lua Log?" , "ShowLogs" , "Log events in the Lua Log" , true)
coldfire:CreateConVar("cf_logs_level" , "Logging Level" , "LogLevel" , "Level of logging for the lua log. 4 = highest" , 1, 4 , 0)
coldfire:CreateConVar("cf_updatemenucomponents" , "Auto Update Menu Ents" , "RefreshMenu" ,"Automatically refresh menu components.",false)
coldfire:CreateConVar("cf_latencyprediction" , "Ping Predict. Factor" , "LatencyPrediction" ,"Prediction factor based on ping. Deprecated.", 45 , 300,5)
coldfire:CreateConVar("cf_pingpredict" , "Ping Based Prediction?" , "PingPredict" , "Prediction based on ping. Deprecated." , false)
coldfire:CreateConVar("cf_collectgarbage" , "Force CollectGarbage" , "CollectGarbage" , "Collect lua garbage (Increases FPS and reduces memory usage)" , true)
coldfire:CreateConVar("cf_mat_fullbright" , "Fullbright?" , "Fullbright" , "Enable fullbright. No source engine lighting." , false) 
coldfire:CreateConVar("cf_bunnyhop" , "Bunny Hop?" , "BunnyHop" , "Enable bunnyhop" , false)
coldfire:CreateConVar("cf_bunnyhopspace" , "Bunny Hop (Space Held)?" , "BunnyHopSpace" ,"Bunnyhop when the space key is held (Overrides bunnyhopspeed)" ,  true)
--BunnyHopSpace
--coldfire:CreateConVar("cf_bypassulxgag" , "Bypass ULX gag?" , "BypassULXGag" , true)
coldfire:CreateConVar("cf_bunnyhop_minspeed" , "Bunny Hop Minimum Speed" , "BunnyHopSpeed","Minimum speed at which bunnyhopping should start." , 260 , 1000,0)
--coldfire:CreateConVar("cf_bunnyhop_minspeed" , "Bunny Hop Minimum Speed" , 260,700,0)
--coldfire:CreateConVar("cf_speedhack" , "Speedhack?" , "Speedhack" , false)

-- Above won't work. Instead let them use the slider. 
coldfire:CreateConVar("cf_host_timescale" , "Speedhack Speed" , "SpeedhackSpeed","Speed at which to speedhack. This is a multiplier of normal speed." , 1 , 10 , 1 , true)
coldfire:CreateConVar("cf_checkdormantplayers" , "Hide Dormant Players" , "CheckDormantPlayers" ,"Ignore targets that are not actually there. (Not yet functioning)" , true)

coldfire:CreateConVar("cf_lockdownlua" , "Lockdown Lua Functions" , "LockdownLua" ,"Prevent all lua file operations and communication with the server." , false) -- Locks RCC and file functions. Prevents datastream.
coldfire:CreateConVar("cf_disconnectmessage" , "Custom Disconnect Message" , "DisconnectMessage" ,"Set a custom disconnect message.", "")

local c = util.JSONToTable( coldfire.Read("coldfire/cf_settings.txt", "DATA"))

if c and c.convars then
	for k , v in pairs(c.convars) do
		if k and v and k ~= "" then
			//if cexists(k) then
				rcc(k,v)
				coldfire.Settings[k] = v
			//end
		end
	end
	MsgN("[ColdFire] Previous settings loaded.")
end

-- Misc more --

--g_Luagame->SetGlobal("CF_SetDisconnectCallBack", SetDisconnectCallBack)

function coldfire.GetDisconnectMessage()
	if coldfire.Settings.DisconnectMessage ~= "" then
		return coldfire.Settings.DisconnectMessage
	end
end

--CF_SetDisconnectCallBack(coldfire.GetDisconnectMessage)

CF_SetDisconnectCallBack = nil


--------------------------
--[[

Targetting enums and tables.

]]
--------------------------

local TARGET_SORT_DISTANCE 	= 1
local TARGET_SORT_ANGLE 	= 2
local TARGET_SORT_HEALTH	= 3
local TARGET_SORT_RISK 		= 4

coldfire.TargetTypes = {
	[TARGET_SORT_DISTANCE] 	= "Sort by Distance",
	[TARGET_SORT_ANGLE] 	= "Sort by Angle Difference",
	[TARGET_SORT_HEALTH] 	= "Sort by Health",
	[TARGET_SORT_RISK] 		= "Sort by Calculated Risk",
}

local TARGET_BONE_HEAD 		= 1
local TARGET_BONE_SPINE 	= 2
local TARGET_BONE_SHOULDER 	= 3

coldfire.BoneTypes = {
	[TARGET_BONE_HEAD] = "head",
	[TARGET_BONE_SPINE] = "spine",
	[TARGET_BONE_SHOULDER] = "leg",
}

coldfire.Traitors = {}

function coldfire:IsTraitor(pl)
	return table.HasValue((coldfire.Traitors and coldfire.Traitors or (MsgN("[ColdFire] Error:  No traitor table") and {} )),pl)
end

function coldfire:GetPlayerDanger(pl)
	return 1
end

local weps = _R.Player.GetWeapons
local foundweps = {}

local ttt = true
coldfire:Hook("Think" , function()
	--[[if( ulx and ulx.gagUser ) then
		if coldfire.Settings.BypassULXGag then
			ulx.gagUser(LocalPlayer(),false)
		end
	end
	]]
	if not ttt or not string.find(GAMEMODE.Name , "Terror") then ttt = false return end
	
	if not coldfire.Settings.TraitorMode then return end
	
	for k , v in pairs(player.GetAll()) do
		for a , b in pairs(weps(v)) do
			if IsValid(b) then
				if type(b.CanBuy) == "table" and not table.HasValue(coldfire.Traitors,v) and not table.HasValue(foundweps , b) and GetRoundState() == 3 then
					if table.HasValue(b.CanBuy,ROLE_TRAITOR) and not table.HasValue(b.CanBuy,ROLE_INNOCENT) then
						if not v:IsDetective() then
							table.insert(coldfire.Traitors,v)
							table.insert(foundweps,b)
							chat.AddText(Color(116, 187 , 251 , 255) , "[ColdFire]" , Color(255,255,255,255) , "Player " , Color(116, 187 , 251 , 255) , v:Nick() , Color(255,255,255,255) , " collected traitor weapon " , Color(116, 187 , 251 , 255) , b:GetPrintName() or b:GetClass())
						end
					end
				end
			end
		end
	end
	
	if GetRoundState() == 4 and #coldfire.Traitors > 0 then
		table.Empty(coldfire.Traitors)
		table.Empty(foundweps)
		MsgN("[ColdFire] Cleared traitors")
	end
end )


--------------------------
--[[

Friends + Enemies.

]]
--------------------------

coldfire.Friends = (file.Exists("coldfire/coldfire_friends.txt", "DATA") and util.JSONToTable(file.Read("coldfire/coldfire_friends.txt", "DATA")) or {} )


function coldfire:AddFriend(pl)
	if IsValid(pl) and pl ~= LocalPlayer() then
		table.insert(coldfire.Friends , pl:SteamID())
		coldfire.Write("coldfire/coldfire_friends.txt" , util.TableToJSON(coldfire.Friends))
	end
end

function coldfire:RemoveFriend(pl)
	if IsValid(pl) then
		for k , v in pairs(coldfire.Friends) do
			if string.Trim(v) == pl:SteamID() then
				coldfire.Friends[k] = nil
			end
		end
		PrintTable(coldfire.Friends)
		coldfire.Write("coldfire/coldfire_friends.txt" , util.TableToJSON(coldfire.Friends))
	end
end

function coldfire:AddFriendByName(nick)
	for k , v in ipairs(player.GetAll()) do
		if string.find(string.lower(v:Nick()) , string.lower(nick)) then
			coldfire:AddFriend(v)
			break
		end
	end
end

function coldfire:RemoveFriendByName(nick)
	for k , v in ipairs(player.GetAll()) do
		if string.find(string.lower(v:Nick()) , string.lower(nick)) then
			coldfire:RemoveFriend(v)
			break
		end
	end
end

function coldfire:GetFriends()
	local friends = {}
	local notfriends = {}
	
	for k , v in ipairs(player.GetAll()) do
		if self:IsPlayerFriend(v) then
			table.insert(friends , v)
		elseif v ~= LocalPlayer() then
			table.insert(notfriends , v)
		end
	end
	
	return friends, notfriends
end


function coldfire:IsPlayerFriend(pl)
	local steamid = (pl.SteamID and pl:SteamID() or "")
	return table.HasValue(coldfire.Friends , steamid)
end

coldfire.Enemies = (file.Exists("coldfire/coldfire_enemies.txt", "DATA") and util.JSONToTable(file.Read("coldfire/coldfire_enemies.txt", "DATA")) or {} )

function coldfire:AddEnemy(pl)
	if IsValid(pl) and pl ~= LocalPlayer() then
		table.insert(coldfire.Enemies , pl:SteamID())
		coldfire.Write("coldfire/coldfire_enemies.txt" , util.TableToJSON(coldfire.Enemies))
	end
end

function coldfire:RemoveEnemy(pl)
	if IsValid(pl) then
		for k , v in pairs(coldfire.Enemies) do
			if string.Trim(v) == pl:SteamID() then
				coldfire.Enemies[k] = nil
			end
		end
		PrintTable(coldfire.Enemies)
		coldfire.Write("coldfire/coldfire_enemies.txt" , util.TableToJSON(coldfire.Enemies))
	end
end

function coldfire:AddEnemyByName(nick)
	for k , v in ipairs(player.GetAll()) do
		if string.find(string.lower(v:Nick()) , string.lower(nick)) then
			coldfire:AddEnemy(v)
			break
		end
	end
end

function coldfire:RemoveEnemyByName(nick)
	for k , v in ipairs(player.GetAll()) do
		if string.find(string.lower(v:Nick()) , string.lower(nick)) then
			coldfire:RemoveEnemy(v)
			break
		end
	end
end

function coldfire:GetEnemies()
	local enemies = {}
	local notenemies = {}
	
	for k , v in ipairs(player.GetAll()) do
		if self:IsPlayerEnemy(v) then
			table.insert(enemies , v)
		elseif v ~= LocalPlayer() then
			table.insert(notenemies , v)
		end
	end
	
	return enemies, notenemies
end


function coldfire:IsPlayerEnemy(pl)
	local steamid = (pl.SteamID and pl:SteamID() or "")
	return table.HasValue(coldfire.Enemies , steamid)
end

---

-- CreateMove thingmabobbers --

----

--It would be a good idea to re-write the below code.

---


--[[
local targrettable -- Don't create a new local each call.
local lastreturn = {} -- Recycle return values. Significantly increases FPS.
function coldfire:GetAllTargets()
	if lastreturn.t and lastreturn.t == CurTime() then
		return lastreturn.r
	end
	
	targrettable = {}
	for k , v in ipairs(ents.GetAll()) do
		-- Fuck ugly nesting.
		if IsValid(v) then
			if (v:IsPlayer() and coldfire.Settings.EnemyMode and coldfire:IsPlayerEnemy(v)) or (not v:IsPlayer() or not coldfire.Settings.EnemyMode) then
				if LocalPlayer() ~= v and v:IsPlayer() or v:IsNPC() or string.find(v:GetClass() , "npc") then
					if not (v:IsPlayer() and v:Health() <= 0 and v:GetMoveType() ~= 0)  and not ( (v:IsNPC() or string.find(v:GetClass() , "npc")) and v:GetMoveType() == 0) then
						if ( (LocalPlayer():GetPos():Distance(v:GetPos()) < tonumber(coldfire.Settings.MaxDistance)) or tonumber(coldfire.Settings.MaxDistance) == 0 ) then
							if not(not(coldfire.Settings.FriendlyFire) and (v.Team and v:Team() == LocalPlayer():Team())) then
								if (coldfire.Settings.TargetNPCs or not v:IsNPC() or not string.find(v:GetClass() , "npc")) and not(coldfire.Settings.CheckNPCRelationship and (v:IsNPC() and notIsEnemyEntityName(v:GetClass()))) then--and (coldfire.Settings.CheckNPCRelationship or !(v:IsNPC() and IsEnemyEntityName(v:GetClass()))) then
									if coldfire.Settings.TargetSteamFriends or (not v.GetFriendStatus or v:GetFriendStatus() ~= "friend") then
										if not(coldfire.Settings.TargetAdmins and (v.IsAdmin and v:IsAdmin())) then
											if ( not coldfire:IsPlayerFriend(v) or coldfire.Settings.TargetFriends or coldfire.Settings.EnemyMode ) then
												if string.find(string.lower(GAMEMODE.Name) , "terror") then
													if LocalPlayer():IsTraitor() and not v:IsTraitor() then
														table.insert(targrettable , v)
													elseif not LocalPlayer():IsTraitor() and coldfire:IsTraitor(v) then
														table.insert(targrettable , v)
													elseif not coldfire.Settings.OnlyTargetTraitors then
														table.insert(targrettable , v)
													end
												else
													table.insert(targrettable , v)
												end
											end
										end
									end
								end
							end
						end
					end
				end
			end
		end
	end
	lastreturn = {t=CurTime(),r=targrettable}
	return targrettable
end
]]

function coldfire.TraceCheck(ent)
	local pos = coldfire:GetShootPos(ent)
	--[[ Not too bad. 3.814697265625e-005
	2.288818359375e-005
	0.0003204345703125
	]]
	
	local trace = {}
	trace.start = LocalPlayer():GetShootPos()
	trace.endpos = pos
	trace.mask = 1174421507
	trace.filter = {LocalPlayer() , ent}

	local tr = util.TraceLine(trace)
	--[[
	
	Traces seem very bloody quick.
	5.340576171875e-005
	5.340576171875e-005
	5.340576171875e-005
	4.57763671875e-005	]]
	
	if not tr.Hit then
		return ent , pos
	end
end


local targetrequirements = {}

function coldfire:AddTargetRequirement(func)
	table.insert(targetrequirements ,func)
end

coldfire:AddTargetRequirement(function(ent) if not IsValid(ent) or (ent == LocalPlayer()) or not ent:IsValid() then return false else return true end end )
//coldfire:AddTargetRequirement(function(ent) if coldfire.IsDormant(ent:EntIndex()) then return false else return true end end )
--coldfire:AddTargetRequirement(function(ent) if not coldfire.TraceCheck(ent) then return false else return true end end )
coldfire:AddTargetRequirement(function(ent) if (ent.Team and ent:Team() == TEAM_SPECTATOR) then return false else return true end end )
coldfire:AddTargetRequirement(function(ent) if ent.GetObserverTarget and IsValid(ent:GetObserverTarget()) and ent ~= ent:GetObserverTarget() then return false else return true end end )
coldfire:AddTargetRequirement(function(ent) if coldfire.Settings.IgnoreWeaponless and ent:IsPlayer() and not IsValid(ent:GetActiveWeapon()) then return false else return true end end ) 
coldfire:AddTargetRequirement(function(ent) if not IsValid(ent) then return false end if (ent:IsNPC() or ent:IsPlayer() or string.find(ent:GetClass():lower(),"npc")) then return true else return false end end )
coldfire:AddTargetRequirement(function(ent) if not ((ent:IsPlayer() and coldfire.Settings.EnemyMode and coldfire:IsPlayerEnemy(ent)) or (not ent:IsPlayer() or not coldfire.Settings.EnemyMode)) then return false else return true  end end )
coldfire:AddTargetRequirement(function(ent) if not ( tonumber(coldfire.Settings.MaxDistance) == 0 or ((LocalPlayer():GetPos()-ent:GetPos()):LengthSqr() < tonumber(coldfire.Settings.MaxDistance^2))  ) then return false else return true end end )
--coldfire:AddTargetRequirement(function(ent) if (not(coldfire.Settings.FriendlyFire) and (ent.Team and ent:Team() == LocalPlayer():Team())) then return false else return true end end )
coldfire:AddTargetRequirement(function(ent) if (not(coldfire.Settings.FriendlyFire or string.find(string.lower(GAMEMODE.Name),"terror")) and (ent.Team and ent:Team() == LocalPlayer():Team())) then return false else return true end end )
coldfire:AddTargetRequirement(function(ent) if not ((coldfire.Settings.TargetNPCs or not ent:IsNPC() or not string.find(ent:GetClass() , "npc")) and not(coldfire.Settings.CheckNPCRelationship and (ent:IsNPC() and not IsEnemyEntityName(ent:GetClass())))) then return false else return true end end )
coldfire:AddTargetRequirement(function(ent) if not (coldfire.Settings.TargetSteamFriends or (not ent.GetFriendStatus or ent:GetFriendStatus() ~= "friend")) then return false else return true end end )
coldfire:AddTargetRequirement(function(ent) if not (coldfire.Settings.TargetFriends or (not coldfire:IsPlayerFriend(ent)) or not ent:IsPlayer()) then return false else return true end end )
coldfire:AddTargetRequirement(function(ent) if not (coldfire.Settings.TargetAdmins and (ent.IsAdmin and ent:IsAdmin()) or (ent.IsAdmin and not ent:IsAdmin()) or not ent.IsAdmin ) then return false else return true end end )
coldfire:AddTargetRequirement(function(ent) if ((LocalPlayer() == ent) or not(ent:IsPlayer() or ent:IsNPC() or string.find(ent:GetClass():lower(),"npc"))) then return false else return true end end )
coldfire:AddTargetRequirement(function(ent) if not (string.find(string.lower(GAMEMODE.Name) , "terror") and (ent.Team and ent:Team() == LocalPlayer():Team()) and ( (LocalPlayer().IsTraitor and LocalPlayer():IsTraitor() and not (ent.IsTraitor and ent:IsTraitor())) or (not LocalPlayer():IsTraitor() and coldfire:IsTraitor(ent) ) or (not coldfire.Settings.OnlyTargetTraitors) ) or not string.find(string.lower(GAMEMODE.Name),"terror")) then return false else return true end end )
coldfire:AddTargetRequirement(function(ent) if not (not (ent:IsPlayer() and ent:Health() <= 0 and ent:GetMoveType() ~= 0)  and not ( (ent:IsNPC() or string.find(ent:GetClass() , "npc")) and ent:GetMoveType() == 0)) then return false else return true end end )

local lastpass = {}
local checking
local cind = 0
function coldfire:ValidTarget(ent)
	for k , v in pairs(targetrequirements) do
		if IsValid(ent) and checking == ent then
			local r = v(ent)
			lastpass[ent] = lastpass[ent] or {}
			lastpass[ent][k] = r
			if not r then
				return false
			end
		elseif IsValid(ent) and lastpass[ent] and lastpass[ent][k] and lastpass[ent][k] == false then
			if checking == ent then
				if not v(ent) then
					lastpass[ent][k] = false
					return false
				else
					lastpass[ent][k] = true
				end
			else
				return false
			end
		elseif IsValid(ent) and lastpass[ent] and lastpass[ent][k] and lastpass[ent][k] == true then
			if not v(ent) then
				lastpass[ent][k] = false
				return false
			end
		elseif IsValid(ent) and (not lastpass[ent] or lastpass[ent][k] == nil) then
			lastpass[ent] = lastpass[ent] or {}
			lastpass[ent][k] = v(ent)
			
			if lastpass[ent][k] == false then
				return false
			end
		elseif not IsValid(ent) then
			return false
		else
			return false
		end
				
		--[[if IsValid(ent) and lastpass[ent]  and lastpass[ent].t and (lastpass[ent].t == CurTime()) and (lastpass[ent][k] == false) then
			return false
		elseif not lastpass[ent] or  checking == ent and (lastpass[ent].t and (lastpass[ent].t < CurTime()) or lastpass[ent][k] ~= false or checking == ent) then
			lastpass[ent] = {}
			if not v(ent) then
				lastpass[ent][k] = false
				lastpass[ent].t = CurTime()
				return false
			else
				lastpass[ent][k] = true
				lastpass[ent].t = CurTime()
			end
		elseif lastpass[ent] and lastpass[ent][k] then

		else
			return false
		end]]
	end
	return true
end


function coldfire:GetAllTargets()
	local targets = {}
	
	cind = cind + 1
	
	local e = ents.GetAll()
	while not IsValid(e[cind]) or not (e[cind]:IsPlayer() or e[cind]:IsNPC() or e[cind]:GetClass():lower():find("npc")) do
		cind = cind + 1
		if IsValid(e[cind]) and (e[cind]:IsPlayer() or e[cind]:IsNPC() or e[cind]:GetClass():lower():find("npc")) then
			checking = Entity(cind)
			break
		end
		if cind > #ents.GetAll() then
			cind = 1
			break
		end
	end
	checking = e[cind]
	for k  , v in pairs(e) do 
		if self:ValidTarget(v) then
			table.insert(targets,v)
		end
	end
		
		
	local targsortret = {}
	
	local myang
	if coldfire.Settings.FakeView then
		myang = coldfire.View
	else
		myang = LocalPlayer():EyeAngles()
	end
	
	for k , v in ipairs(targets) do
		--[[
		local ang = (v:GetPos() - LocalPlayer():GetPos()):Angle()
		local angdiffy = math.abs(math.NormalizeAngle( myang.y - ang.y ) )
		local angdiffp = math.abs(math.NormalizeAngle( myang.p - ang.p ) )
		
		0.00011444091796875
		0.0001068115234375
		0.00011444091796875
		0.00011444091796875
		
		New method - 
		0.00012969970703125
		7.62939453125e-005
		8.392333984375e-005
		6.866455078125e-005
		0.00011444091796875
		6.866455078125e-005
		7.62939453125e-005
		0.0001068115234375
		6.866455078125e-005

		]]
		--[[
		local angdiff = math.deg(math.acos(v:GetPos():Dot(LocalPlayer():GetPos() / (v:GetPos():Length() * LocalPlayer():GetPos():Length()))))
		]]
		
		local ang = (v:GetPos() - LocalPlayer():GetPos()):Angle()
		local angdiff = math.abs(math.NormalizeAngle( myang.y - ang.y ) )
		
		
		if (angdiff < tonumber(coldfire.Settings.MaxAngleDiff)) or  tonumber(coldfire.Settings.MaxAngleDiff) == 0 then
			table.insert(targsortret , {ent = v , dist = LocalPlayer():GetPos():Distance(v:GetPos()) , health = v:Health() , ang = angdiff , danger = coldfire:GetPlayerDanger(v) })
		end
	end
	
	--[[
		2.6702880859375e-005
		3.0517578125e-005
		3.0517578125e-005
		Sorting was already fast.]]
		
	local targetmode = math.floor(coldfire.Settings.TargetMode)
	if targetmode == TARGET_SORT_DISTANCE then
		table.SortByMember(targsortret , "dist" , function(a , b) return a > b end )
	elseif targetmode == TARGET_SORT_HEALTH then
		table.SortByMember(targsortret , "health" , function(a , b) return a > b end )
	elseif targetmode == TARGET_SORT_ANGLE then
		table.SortByMember(targsortret , "ang" , function(a , b) return a > b end )
	elseif targetmode == TARGET_SORT_RISK then
		table.SortByMember(targsortret , "danger" , function(a , b) return a < b end )
	end
	return targsortret
end

local alternatechecks = {
[1] = "ValveBiped.Bip01_L_Forearm",
[2] = "ValveBiped.Bip01_R_Forearm",
[3] = "ValveBiped.Bip01_L_Calf",
[4] = "ValveBiped.Bip01_R_Calf",
}


function coldfire:GetBestTarget()
	for k , v in pairs(self:GetAllTargets()) do
		if IsValid(v.ent) then
			local pos = coldfire:GetShootPos(v.ent)
			--[[ Not too bad. 3.814697265625e-005
			2.288818359375e-005
			0.0003204345703125
			]]
			
			local trace = {}
			trace.start = LocalPlayer():GetShootPos()
			trace.endpos = pos
			trace.mask = 1174421507
			trace.filter = {LocalPlayer() , v.ent}

			local tr = util.TraceLine(trace)
			--[[
			
			Traces seem very bloody quick.
			5.340576171875e-005
			5.340576171875e-005
			5.340576171875e-005
			4.57763671875e-005	]]
			
			if not tr.Hit and (LocalPlayer() ~= v.ent) then 
				return v.ent , pos
			end
			
			if coldfire.Settings.CheckPartialHits then
				--[[0.00026702880859375
					0.00026702880859375
					0.00034332275390625
					]]
				
				for a , b in ipairs(alternatechecks) do
					local bone = v.ent:LookupBone(b)
					if bone then
						local pos , angle = v.ent:GetBonePosition(bone)
						
						if pos then
							local trace = {}
							trace.start = LocalPlayer():GetShootPos()
							trace.endpos = coldfire:GetWeaponPredictionPos(pos , v.ent)
							trace.mask = 1174421507
							trace.filter = {LocalPlayer() , v.ent}

							local tr = util.TraceLine(trace)
							if not tr.Hit and (LocalPlayer() ~= v.ent) then
								return v.ent , pos
							end
						end
					end
				end
			end
		end
	end
	return false
end

function coldfire.Trace(ent)
 
	local pos = coldfire:GetShootPos(ent)
	
	if coldfire.Settings.IgnoreLOS then
		return ent,pos
	end
	
	--[[ Not too bad. 3.814697265625e-005
	2.288818359375e-005
	0.0003204345703125
	]]
	
	local trace = {}
	trace.start = LocalPlayer():GetShootPos()
	trace.endpos = pos
	trace.mask = 1174421507
	trace.filter = {LocalPlayer() , ent}

	local tr = util.TraceLine(trace)
	--[[
	
	Traces seem very bloody quick.
	5.340576171875e-005
	5.340576171875e-005
	5.340576171875e-005
	4.57763671875e-005	]]
	
	if not tr.Hit and (LocalPlayer() ~= ent) then 
		return ent , pos
	end
	
	if coldfire.Settings.CheckPartialHits then
		--[[0.00026702880859375
			0.00026702880859375
			0.00034332275390625
			]]
		
		for a , b in ipairs(alternatechecks) do
			local bone = ent:LookupBone(b)
			if bone then
				local pos , angle = ent:GetBonePosition(bone)
				
				if pos then
					local trace = {}
					trace.start = LocalPlayer():GetShootPos()
					trace.endpos = coldfire:GetWeaponPredictionPos(pos , ent)
					trace.mask = 1174421507
					trace.filter = {LocalPlayer() , vnt}

					local tr = util.TraceLine(trace)
					if not tr.Hit and (LocalPlayer() ~= ent) then
						return ent , pos
					end
				end
			end
		end
	end
end
----

--It would be a good idea to re-write the above code.

---

local EntPreviousPos = {}

function coldfire:GetPingPrediction(pl,pos)
	if not coldfire.Settings.PingPredict then return pos end
	if true then return pos end
	
	local deltapos
	
	deltapos = EntPreviousPos[pl] and (pl:GetPos() - EntPreviousPos[pl]) or pl:GetPos()
	
	local ping = coldfire.GetLocalPing() / coldfire.Settings.LatencyPrediction -- PredictionConstant is defined as a convar.
	
	EntPreviousPos[pl] = pl:GetPos()
	return (deltapos * ping) + pos
end

local weapons = {
["weapon_crossbow"] = 3110,
}

local lastpos
function coldfire:GetPredictedPos(pos)
	if lastpos then
		local l = lastpos 
		lastpos = pos
		--print((pos - lastpos) + pos , pos == ((pos - lastpos) + pos))]
		pos = (LerpVector(0.5,l,pos))
	end
	if coldfire.Settings.VelocityPrediction and IsValid(coldfire.CurrentTarget) then
		local mv = LocalPlayer():GetVelocity()
		local tv = coldfire.CurrentTarget:GetVelocity()
		local pf = coldfire.Settings.PredictionFactor
		
		pos = ( pos - (coldfire.CurrentTarget:GetVelocity():GetNormal()/5.8) + (LocalPlayer():GetVelocity():GetNormal()/3)) - Vector( 0, -1, coldfire.Settings.AimOffsetZ )
	end
	
	pos = coldfire:GetPingPrediction(coldfire.CurrentTarget,pos)
	
	local pl = coldfire.CurrentTarget
	if IsValid(pl) and type(pl:GetVelocity()) == "Vector" and pl.GetPos and type(pl:GetPos()) == "Vector" then
		local distance = LocalPlayer():GetPos():Distance(pl:GetPos())
		local weapon = (LocalPlayer().GetActiveWeapon and (IsValid(LocalPlayer():GetActiveWeapon()) and LocalPlayer():GetActiveWeapon():GetClass()))
		
		if weapon and weapons[weapon] then
			local time = distance / weapons[weapon]
			pos = pos + pl:GetVelocity() * time
		end
	end
	return pos
end


coldfire.Cones = {

	["HL2"] = {
		["weapon_pistol"] = Vector( 0.01, 0.01, 0.01 ),
		["weapon_smg1"] = Vector( 0.04362, 0.04362, 0.04362 ),
		["weapon_ar2"] = Vector( 0.02618, 0.02618, 0.02618 ),
		["weapon_shotgun"] = Vector( 0.08716, 0.08716, 0.08716 ),
	},
	
	["Normal"] = {}
	
}

local eFireBullet = _R.Entity.FireBullets
_R.Entity.FireBullets = function( e, bullet )
	
	local wep = LocalPlayer():GetActiveWeapon()
	
	coldfire.Cones.Normal[wep:GetClass()] = bullet.Spread

	return eFireBullet( e, bullet )

end

local wepCone
function coldfire.GetCone( wep )

	if !IsValid( wep ) then
		
		return 0
	
	end
	
	if coldfire.Cones["HL2"][wep:GetClass()] != nil then
		
		return coldfire.Cones.HL2[wep:GetClass()]
		
	end
	
	if coldfire.Cones.Normal[wep:GetClass()] != nil then
		
		return coldfire.Cones.Normal[wep:GetClass()]
		
	end
	
	wepCone = wep.Cone
	
	if !wepCone then
		
		wepCone = wep.Primary && wep.Primary.Cone or 0
		
	end
	
	return wepCone or 0
	
end

local currentseed, cone, spreadwep
local valCone, vecCone
local spreadCone, getCone = Vector( 0, 0, 0 )

local CustomCones = {}

CustomCones["#HL2_SMG1"]        = Vector( 0.04362, 0.04362, 0.04362 )
CustomCones["#HL2_Pistol"]      = Vector( 0.0100, 0.0100, 0.0100 )
CustomCones["#HL2_Pulse_Rifle"] = Vector( 0.02618, 0.02618, 0.02618 )
CustomCones["#HL2_Shotgun"]     = Vector( 0.08716, 0.08716, 0.08716 )

function coldfire:GetSpreadPrediction(ucmd,ang)

	wep = LocalPlayer():GetActiveWeapon()
	
	getCone = coldfire.GetCone( wep )
			
	if type( getCone ) == "number" then
		
		spreadCone = Vector( -getCone, -getCone, -getCone )
	
	elseif type( getCone ) == "Vector" then
			
		spreadCone = getCone * -1
		
	end
	
	if coldfire.Cones["HL2"][wep:GetClass()] != nil then
	
		punch = LocalPlayer():GetViewPunchAngles()
		
		ang = ang - punch
	
	end	

	local cmd2 = ucmd:CommandNumber()
	
	if( cmd2 == 0 ) then 
	
		return ang  
	
	end 
	
	local seed = md5.PseudoRandom( cmd2 )

	local x = engineSpread[seed][1]
	local y = engineSpread[seed][2]
 
	local forward = ang:Forward()
	local right = ang:Right()
	local up = ang:Up()
 
	local cd = forward + ( x * -spreadCone.x * right * -1 ) + ( y * -spreadCone.y * up * -1 )
	
	local spreadAngles = cd:Angle()
	
	spreadAngles:Normalize()

	return spreadAngles	

end

function coldfire:GetAntisnapAngle(ang)
	local p , y , r = ang.p	, ang.y  , ang.r
	
	if not p or not y or not r then
		ErrorNoHalt("[ColdFire:1241] Attempt to use a nil angle")
		return ang
	end
	
	local curang = LocalPlayer():EyeAngles()
	local speed = tonumber(coldfire.Settings.AntiSnapSpeed)
	local retangle = Angle(0 , 0 , 0)
	
	retangle.p = math.Approach( math.NormalizeAngle(curang.p or 0) ,  math.NormalizeAngle(p or 0), speed)
	retangle.y = math.Approach( math.NormalizeAngle(curang.y or 0) ,  math.NormalizeAngle(y or 0), speed)
	retangle.r = 0
	
	return Angle(retangle.p , retangle.y , retangle.r)
end



coldfire.Attachments = {

["head"] = "eyes",
["spine"] = "chest",
}

coldfire.Bones = {
["head"] = {


["models/zombie/classic.mdl"] = "ValveBiped.HC_Body_Bone" ,
["models/zombie/fast.mdl"] = "ValveBiped.HC_BodyCube",
["models/zombie/poison.mdl"] = "ValveBiped.Bip01_Spine4" , 
["other"] = "ValveBiped.Bip01_Head1",
},

["spine"] = {

["other"] = "ValveBiped.Bip01_Spine",

} ,

["leg"] = {

["other"] = "ValveBiped.Bip01_R_Calf",

},
}

function coldfire:GetWeaponPredictionPos(pos,ent) return pos end
function coldfire:GetShootPos(ent)
	if not IsValid(ent) then return end
	local btype = coldfire.BoneTypes[math.floor(tonumber(coldfire.Settings.BoneMode))]
	local aimpos
	--[[
	if btyte == "head" then
		-- GetAttachment(eyes) is better.
		
		local eyes = ent:LookupAttachment("eyes")
		if( eyes ~= 0 ) then
			eyes = ent:GetAttachment( eyes )
			if( eyes and eyes.Pos ) then
				aimpos = eyes.Pos
			end
		end
	end]]

	if not aimpos then
		if self.Bones[btype] then
			local boneid = ent:LookupBone(self.Bones[btype][ent:GetModel()] or self.Bones[btype]["other"])
			local pos , ang = ent:GetBonePosition(boneid)
			pos , ang = coldfire:GetWeaponPredictionPos(pos , ent), ang
			
			aimpos = pos
		else
			for k , v in pairs(self.Bones) do	
				local boneid = ent:LookupBone(v[ent:GetModel()] or v["other"])
				if boneid then
					local pos , ang = ent:GetBonePosition(boneid)
					
					if pos then
						aimpos = pos
						break
					end
				end
			end
		end
	end
	return aimpos
end

coldfire.IsFireButtonDown = false
local lastfiretime = 0

function coldfire.GetFireButton(ucmd)
	if IsValid(LocalPlayer()) and coldfire.Settings.AimEnabled and coldfire.Settings.SnapOnFire then
		local keys = coldfire.GetButtons(ucmd)
		
		if band(IN_ATTACK,keys) == 1 then
			lastfiretime = CurTime()
			coldfire.IsFireButtonDown = true
		elseif lastfiretime + (IsValid(LocalPlayer():GetActiveWeapon()) and (LocalPlayer():GetActiveWeapon():GetTable() and LocalPlayer():GetActiveWeapon():GetTable().Primary and LocalPlayer():GetActiveWeapon():GetTable().Primary.Delay or math.max(0.05 , coldfire.Settings.SnapOnFireTime) ) or 0.2) < CurTime() then
			coldfire.IsFireButtonDown = false
		end
	end
end

coldfire:Hook("CreateMove" , coldfire.GetFireButton)

function coldfire.Bunnyhop(ucmd)
	local keys = coldfire.GetButtons(ucmd)
	
	if coldfire.Settings.BunnyHop and ((LocalPlayer and LocalPlayer():GetVelocity():Length() > tonumber(coldfire.Settings.BunnyHopSpeed) or tonumber(coldfire.Settings.BunnyHopSpeed) == 0 ) or (coldfire.Settings.BunnyHopSpace and (band(IN_JUMP,keys)==2)  ) ) then
		if LocalPlayer():OnGround() then
			coldfire.SetButtons(ucmd,( bor(coldfire.GetButtons(ucmd) , IN_JUMP) ))
		elseif band(IN_JUMP,keys)==2 and coldfire.Settings.BunnyHopSpace and LocalPlayer():GetMoveType() ~= MOVETYPE_NOCLIP then
			coldfire.SetButtons(ucmd,keys-IN_JUMP)
		end
	end
end

coldfire:Hook("CreateMove" , coldfire.Bunnyhop)

local caimp
local caima

coldfire:Hook("CreateMove" , function(ucmd)
	if IsValid(LocalPlayer()) and coldfire.View == Angle(0,0,0) then
		coldfire.View = LocalPlayer():EyeAngles()
	end
	
	if coldfire.CurrentTarget and (coldfire.Settings.SnapOnFire and coldfire.IsFireButtonDown or not coldfire.Settings.SnapOnFire) then
		local br = false
		if coldfire.TargetHeld then
			local t , p = coldfire.Trace(coldfire.CurrentTarget)
			if not p then
				coldfire.CurrentTarget = nil
				br = true
			else
				caimp = p
				br = false
			end
		else
		
			caimp = coldfire.CurrentPos or coldfire:GetShootPos(coldfire.CurrentTarget)
		end
		
		if not br then
			caimp = caimp and coldfire:GetPredictedPos(caimp) or coldfire.CurrentPos 
			
			caima = (caimp - LocalPlayer():GetShootPos()):Angle()
			
			if coldfire.Settings.NoSpread then
				caima = coldfire:GetSpreadPrediction(ucmd,caima)
			end
			
			if coldfire.Settings.AntiSnap then
				caima = coldfire:GetAntisnapAngle(caima)
			end
			
			coldfire.SVA(ucmd,normalise(caima))
			
			
			-- Fake view --
			
			if coldfire.Settings.FakeView then
				local move = Vector( ucmd:GetForwardMove(), ucmd:GetSideMove(), 0 )
				local norm = move:GetNormal()
				local set = ( norm:Angle() + ( caima - coldfire.View ) ):Forward() * move:Length()
				ucmd:SetForwardMove(set.x )
				ucmd:SetSideMove(set.y)
				
				fakeview = true
			elseif fakeview then
				ucmd:SetForwardMove(caima.p)
				ucmd:SetSideMove(caima.y)
				fakeview = false
			end
			reset = false
			coldfire.Locked = true
		end
	elseif not reset then
		if not coldfire.Settings.AntiSnap then
			reset = true
			coldfire.SVA(ucmd,coldfire.View)
			ucmd:SetForwardMove(coldfire.View.p)
			ucmd:SetSideMove(coldfire.View.y)
			coldfire.Locked = false
			coldfire.CurrentTarget = false
			coldfire.Spinning = false
		elseif coldfire.View ~= ucmd:GetViewAngles() and coldfire.Settings.FakeView then
			coldfire.ResettingAntisnap = true
			coldfire.SVA(ucmd,normalise(coldfire:GetAntisnapAngle(coldfire.View)))
			local move = Vector( ucmd:GetForwardMove(), ucmd:GetSideMove(), 0 )
			local norm = move:GetNormal()
			local set = ( norm:Angle() + ( ucmd:GetViewAngles() - coldfire.View ) ):Forward() * move:Length()
			ucmd:SetForwardMove(set.x )
			ucmd:SetSideMove(set.y)
		elseif coldfire.Settings.FakeView then
			coldfire.ResettingAntisnap = false
			reset = true
			coldfire.SVA(ucmd,coldfire.View)
			ucmd:SetForwardMove(coldfire.View.p)
			ucmd:SetSideMove(coldfire.View.y)
			coldfire.Locked = false
			coldfire.CurrentTarget = false
			coldfire.Spinning = false
		end
	elseif coldfire.Settings.SpinBot then
		caima = Angle(math.random(-89,89),math.random(-89,89),0)
		coldfire.SVA(ucmd,normalise(caima))
		
		if coldfire.Settings.FakeView then	
			local move = Vector( ucmd:GetForwardMove(), ucmd:GetSideMove(), 0 )
			local norm = move:GetNormal()
			local set = ( norm:Angle() + ( caima - coldfire.View ) ):Forward() * move:Length()
			ucmd:SetForwardMove(set.x )
			ucmd:SetSideMove(set.y)
		end
		coldfire.Spinning = true
		reset = false
	elseif (IsValid(LocalPlayer():GetActiveWeapon()) and (LocalPlayer():GetActiveWeapon():GetClass() ~= "weapon_physgun" and LocalPlayer():GetActiveWeapon():GetClass() ~= "gmod_tool") or not IsValid(LocalPlayer():GetActiveWeapon())) then
		//if coldfire.Settings.FakeView then
			local keys = coldfire.GetButtons(ucmd)
			if coldfire.Settings.NoSpreadOnFire and band(IN_ATTACK,keys)==1 then
				coldfire.NoSpread = true
				coldfire.SVA(ucmd,normalise(coldfire:GetSpreadPrediction(ucmd,coldfire.View)))
			else
				coldfire.NoSpread = false
				coldfire.SVA(ucmd,coldfire.View)
			end
		//else
			//coldfire.View = ucmd:GetViewAngles()
		//end
	elseif (IsValid(LocalPlayer():GetActiveWeapon()) and (LocalPlayer():GetActiveWeapon():GetClass() ~= "weapon_physgun" or LocalPlayer():GetActiveWeapon():GetClass() ~= "gmod_tool")) then
		if coldfire.Settings.FakeView then
			coldfire.View = ucmd:GetViewAngles()
			coldfire.NoSpread = false
		end
	end
end )

coldfire:Hook("CreateMove" , function(ucmd)
	if not IsValid(coldfire.CurrentTarget)  then
		coldfire.CurrentTarget = nil
		coldfire.CurrentPos = nil
		coldfire.TargetHeld = false
	end
	
	if not (coldfire.Settings.AimEnabled and coldfire.CurrentTarget and IsValid(coldfire.CurrentTarget) and coldfire:ValidTarget(coldfire.CurrentTarget)) then
		if coldfire.CurrentTarget and not coldfire:ValidTarget(coldfire.CurrentTarget) or not coldfire.Settings.AimEnabled or not IsValid(LocalPlayer():GetActiveWeapon()) then
			coldfire.CurrentTarget = nil
			coldfire.CurrentPos = nil
			coldfire.TargetHeld = false 
		elseif coldfire.Settings.AimEnabled and IsValid(LocalPlayer():GetActiveWeapon()) then
			coldfire.CurrentTarget,coldfire.CurrentPos = coldfire:GetBestTarget()
			coldfire.TargetHeld = false
		end
	else
		coldfire.CurrentPos = nil
		coldfire.TargetHeld = true
	end
end )

coldfire.View = Angle( 0, 0, 0 )

coldfire:Hook("CreateMove" , function(ucmd)
	local sensitivity = 0.022
	coldfire.View.p = math.Clamp( coldfire.View.p + ( ucmd:GetMouseY() * sensitivity ), -89, 89 )
	coldfire.View.y = math.NormalizeAngle( coldfire.View.y + ( ucmd:GetMouseX() * sensitivity * -1 ) )
end )

coldfire:Hook("CalcView" , function(pl , org , ang , fov)
	if (coldfire.CurrentTarget or coldfire.Spinning or coldfire.ResettingAntisnap or coldfire.NoSpread) and coldfire.Settings.FakeView then
		local base = GAMEMODE:CalcView( pl, org, ang, fov ) or {}
		coldfire.View.y = base.angles.y
		//coldfire.View = coldfire.View:Forward()
		base.angles = ( ( coldfire.Settings.FakeView or coldfire.Spinning ) && coldfire.View ) or ang
		base.angles.r = 0
		return base
	end
end )

coldfire.NextFire = 0
coldfire.CUserCMDNum = 0
coldfire.ResetReload = true
coldfire.NextReload = 0
coldfire.NextReloadFrame = 0
coldfire.SetReload = 0
coldfire:Hook("CreateMove" , function(ucmd)
	coldfire.CUserCMDNum = coldfire.CUserCMDNum + 1
	if coldfire.Settings.AutoFire and coldfire.Locked and coldfire.NextFire <= coldfire.CUserCMDNum and not coldfire.Settings.SnapOnFire then
		if coldfire.Settings.AntiSnap then
			local target = coldfire.CurrentTarget
			
			if target then
				local myang = LocalPlayer():EyeAngles()
				local ang = (target:GetPos() - LocalPlayer():GetPos()):Angle()
				local angdiffy = math.abs(math.NormalizeAngle( myang.y - ang.y ) )
				local angdiffp = math.abs(math.NormalizeAngle( myang.p - ang.p ) )
		
				if angdiffy < 4 and angdiffp < 4 then
					coldfire.Firing = true
					coldfire.SetButtons(ucmd,( bor(coldfire.GetButtons(ucmd) , IN_ATTACK) ))
					coldfire.NextFire = coldfire.CUserCMDNum + 2
				end
			end
		else
			coldfire.NextFire = coldfire.CUserCMDNum + 2
			
			if coldfire.Settings.CUserCMDFire and coldfire.CurrentTarget then
				coldfire.SetButtons(ucmd,( bor(coldfire.GetButtons(ucmd) , IN_ATTACK) ))
			elseif coldfire.CurrentTarget then
				rcc("+attack")
			else
				rcc("-attack")
			end
		end
	elseif  coldfire.NextFire > coldfire.CUserCMDNum and not coldfire.Settings.CUserCMDFire then
		rcc("-attack")
	end
	
	if coldfire.Settings.AutoReload then
		if IsValid(LocalPlayer():GetActiveWeapon()) and LocalPlayer():GetActiveWeapon():Clip1() == 0 then
			if coldfire.SetReload < coldfire.CUserCMDNum then

				if coldfire.Settings.CUserCMDFire then
					coldfire.SetButtons(ucmd,bor(coldfire.GetButtons(ucmd) , IN_RELOAD))
				else
					rcc("+reload")
					coldfire.ResetReload = false
				end
				coldfire.NextReload = CurTime() + 4
				coldfire.NextReloadFrame = coldfire.CUserCMDNum + 5
				coldfire.SetReload = coldfire.SetReload + 125
			elseif (coldfire.SetReload - 125) < coldfire.CUserCMDNum then
			
			else
				coldfire.SetReload = coldfire.CUserCMDNum + 125
			end
			
		elseif not coldfire.ResetReload then 
			rcc("-reload")
			coldfire.ResetReload = true
		end
	elseif not coldfire.ResetReload then
		rcc("-reload")
		coldfire.ResetReload = true
	end
end )

coldfire:Hook("HUDPaint" , function()
	if coldfire.Settings.LaserSight or (coldfire.CurrentTarget or coldfire.Spinning or coldfire.ResettingAntisnap or coldfire.NoSpread) and coldfire.Settings.DrawEyeAngles then
		local pos 
		if IsValid(LocalPlayer():GetActiveWeapon()) then
			local vm = LocalPlayer():GetActiveWeapon()
			
			if IsValid(LocalPlayer():GetViewModel()) then
				vm = LocalPlayer():GetViewModel()
				
				local attachmentIndex = vm:LookupAttachment("2")
				
				if attachmentIndex == 0 then attachmentIndex = vm:LookupAttachment("muzzle") end
				
				pos = LocalPlayer():GetViewModel():GetAttachment(attachmentIndex)
				pos = pos and pos.Pos or LocalPlayer():EyePos() + Vector(5,0,0)
			else
			
				local attachmentIndex = vm:LookupAttachment("1")
				if attachmentIndex == 0 then attachmentIndex = vm:LookupAttachment("muzzle") end
				
				
				pos = LocalPlayer():GetActiveWeapon():GetAttachment(attachmentIndex)
				pos = pos and pos.Pos or LocalPlayer():EyePos() + Vector(5,0,0)
			end
		elseif IsValid(LocalPlayer():GetActiveWeapon()) then
			pos = LocalPlayer():GetActiveWeapon():GetPos()
		else
			pos = LocalPlayer():EyePos() + Vector(5,0,0)
		end
		--local pos = LocalPlayer():GetActiveWeapon():GetAttachment(LocalPlayer():GetActiveWeapon():LookupAttachment("muzzle")).Pos
		local trace = LocalPlayer():GetEyeTrace().HitPos
		
		cam.Start3D(EyePos(), EyeAngles())
			cam.IgnoreZ(true)
				render.SetMaterial(Material( "trails/laser" ))
				render.DrawBeam(pos, trace, 8, 2, 0, Color(0,255,0,255))
			cam.IgnoreZ(false)
		cam.End3D()
	end
end )

surface.CreateFont( "Verdana3", {
	font = "Verdana", 
	size = 20,
	weight = 500,
	antialias = true,
	shadow = true
} )

surface.CreateFont( "SmallerFont", {
	font = "default", 
	size = 16,
	weight = 500,
	antialias = true,
	outline = true
} )

coldfire:Hook("HUDPaint" , function()
	if coldfire.Settings.AimEnabled and not coldfire.CurrentTarget then
		draw.SimpleText("Scanning" , "Verdana3" , ScrW() / 2 , ScrH() / 2 + 15 , Color(0 , 255 , 0 , 255) , TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		textstruct = {text = "Scanning" , pos = {ScrW()/2 , ScrH()/2 + 15} , font = "Verdana3" , xalign = TEXT_ALIGN_CENTER , yalign = TEXT_ALIGN_CENTER, color = Color(255 , 60 , 20 , 255)}
		//draw.TextShadow(textstruct , 3)
	elseif coldfire.Settings.AimEnabled then
		draw.SimpleText("Locked ("..(coldfire.CurrentTarget.Nick and coldfire.CurrentTarget:Nick() or coldfire.CurrentTarget:GetClass() )..")" , "Verdana3" , ScrW() / 2 , ScrH() / 2 + 15 , Color(255 , 0 , 0 , 255) , TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		textstruct = {text = "Locked ("..(coldfire.CurrentTarget.Nick and coldfire.CurrentTarget:Nick() or coldfire.CurrentTarget:GetClass() )..")" , pos = {ScrW()/2 , ScrH()/2 + 15} , font = "Verdana3" , xalign = TEXT_ALIGN_CENTER , yalign = TEXT_ALIGN_CENTER, color = Color(116, 187 , 251 , 255)}
		//draw.TextShadow(textstruct , 3)
	end
	if coldfire.Settings.DrawCrosshair then
		local x , y = ScrW() / 2 , ScrH()/2
		
		surface.SetDrawColor(Color( 0,255,0,255,255) )
		local gap = coldfire.Settings.NoSpreadOnFire and 3 or 10
		local length = gap + 7
		
		surface.DrawLine( x - length, y, x - gap, y )
		surface.DrawLine( x + length, y, x + gap, y )
		surface.DrawLine( x, y - length, x, y - gap )
		surface.DrawLine( x, y + length, x, y + gap )
	end
end )


--------------------------
--[[

ESP base functions - these need to be 
optimised as much as possible due to the fact they're called every frame.

]]
--------------------------

coldfire.ESPEntities = (file.Exists("coldfire/coldfire_entities.txt", "DATA") and util.JSONToTable(file.Read("coldfire/coldfire_entities.txt", "DATA")) or {} )

function coldfire:AddESPEntity(class)
	if not table.HasValue(coldfire.ESPEntities , class) then
		table.insert(coldfire.ESPEntities , class)
		coldfire.Write("coldfire/coldfire_entities.txt" , util.TableToJSON(coldfire.ESPEntities))
	end
end

function coldfire:RemoveESPEntity(class)
	for k , v in pairs(self.ESPEntities) do
		if class == v then
			coldfire.ESPEntities[k] = nil
		end
	end
	coldfire.Write("coldfire/coldfire_entities.txt" , util.TableToJSON(coldfire.ESPEntities))
end

function coldfire:IsESPEntity(ent)
	return table.HasValue(coldfire.ESPEntities , ent:GetClass())
end

local esplastents = {t=0,t1={},t2={}}
function coldfire:GetAllESPEntities()
	if esplastents.t == CurTime() then
		return esplastents.t1,esplastents.t2
	end
	
	local ret = {}
	local notesp = {}
	for k , v in ipairs(ents.GetAll()) do
		if IsValid(v) and v ~= LocalPlayer() then
			if v:IsPlayer() or v:IsNPC() or table.HasValue(coldfire.ESPEntities , v:GetClass()) and v ~= LocalPlayer() or (coldfire.Settings.DrawWeapons and (v:IsWeapon() or string.find(v:GetClass() , "weapon")))  then
				if not(v.Team and (v:Team() == LocalPlayer():Team()) and coldfire.Settings.OnlyDrawOtherTeams) then
					if ( (tonumber(coldfire.Settings.MaxESPDistance) == 0) or (tonumber(v:GetPos():Distance(LocalPlayer():GetPos())) < tonumber(coldfire.Settings.MaxESPDistance))) and ( (tonumber(coldfire.Settings.MinESPDistance) == 0) or (tonumber(v:GetPos():Distance(LocalPlayer():GetPos())) > tonumber(coldfire.Settings.MinESPDistance)))then
						if ((v:IsPlayer() and v:Health()>0 and v:GetModel() ~= "models/player.mdl") or v:IsNPC()) and v:GetMoveType() ~= 0 and v:GetMoveType() ~= 10 then
							if not string.find(GAMEMODE.Name, "Terror") or (not coldfire.Settings.OnlyDrawTraitors or ((not LocalPlayer():IsTraitor() and coldfire:IsTraitor(v)) or (v.IsTraitor and LocalPlayer():IsTraitor() and not v:IsTraitor()))) then
								table.insert(ret , v)
							end
						elseif not v:IsPlayer() and not v:IsNPC() then
							table.insert(ret , v)
						end
					end
				end
			end
		end
	end
	esplastents.t = CurTime()
	esplastents.t1 = ret
	esplastents.t2 = notesp
	return ret , notesp
end

local espents = {t = 0 , t1 = {} , t2 = {}}
function coldfire:GetESPEntityClasses()
	if (espents and espents.t) == CurTime() then
		return espents.t1 , espents.t2
	end
	
	local esp = {}
	local notesp = {}
	
	for k , v in ipairs(ents.GetAll()) do
		if IsValid(v) then
			if not table.HasValue(esp , v:GetClass()) and not table.HasValue(notesp , v:GetClass()) then
				if ((v:IsWeapon() or string.find(v:GetClass() , "weapon")) and coldfire.Settings.DrawWeapons) or coldfire:IsESPEntity(v) then
					table.insert(esp , v:GetClass())
				else
					table.insert(notesp , v:GetClass())
				end
			end
		end
	end
	
	espents.t = CurTime()
	espents.t1 = esp
	espents.t2 = notesp
	return esp , notesp
end

-- Maybe rewrite the above two functions? --

local reset

local mat = Material("hlmv/debugmrmwireframe")

coldfire:Hook("RenderScreenspaceEffects" , function()
	if coldfire.Settings.ESPEnabled then
		if coldfire.Settings.DrawModels then
			cam.Start3D(EyePos(),EyeAngles())
				cam.IgnoreZ(true)
				render.SuppressEngineLighting(true)
				for k , v in pairs(coldfire:GetAllESPEntities()) do
					if coldfire.Settings.OutlineModels then
						//v:SetModelScale(1.1)
						render.MaterialOverride(mat)
						v:DrawModel()
						render.MaterialOverride(0)
						//v:SetModelScale(1)
					end
					v:DrawModel()
				end
				render.SuppressEngineLighting(false)
				cam.IgnoreZ(false)
			cam.End3D()
		end
		
		if coldfire.Settings.LaserEyes then
			cam.Start3D(EyePos(),EyeAngles())
				local mat = Material( "trails/laser" )
				for k , v in pairs(player.GetAll()) do
					if v ~= LocalPlayer() and v.GetEyeTrace then
						local pos 
						if v.GetActiveWeapon and IsValid(v:GetActiveWeapon()) then
							local vm = v:GetActiveWeapon()				
							local attachmentIndex = vm:LookupAttachment("1")
							if attachmentIndex == 0 then attachmentIndex = vm:LookupAttachment("muzzle") end
							
							
							pos = v:GetActiveWeapon():GetAttachment(attachmentIndex)
							pos = pos and pos.Pos or v:EyePos() + Vector(5,0,0)
						else
							pos = v:EyePos() + Vector(5,0,0)
						end
						--local pos = LocalPlayer():GetActiveWeapon():GetAttachment(LocalPlayer():GetActiveWeapon():LookupAttachment("muzzle")).Pos
						local trace = v:GetEyeTrace().HitPos

						render.SetMaterial(mat)
						render.DrawBeam(pos, trace, 8, 2, 0, Color(0,255,0,255))
					end
				end
			cam.End3D()
		end
	end
end )



local transpentities = {}

local nextgc = 0
coldfire:Hook("Think" , function()
	if coldfire.Settings.EntityTransparency then
		for k , v in ipairs(ents.GetAll()) do
			local dist = v:GetPos():Distance(LocalPlayer():GetPos())
			if dist < (coldfire.Settings.EntityTransparencyDiameter/2) then
				local r,g,b,a = v:GetColor()
				//local alpha = math.max(30,math.min(255,Lerp(0.2 ,((dist/(coldfire.Settings.EntityTransparencyDiameter/2))*255) , a)))
				local alpha = coldfire.Settings.EntityTransparencyDiameter
				if alpha > 250 then alpha = 255 end
				--if v:GetClass() == "prop_physics" then print(alpha) end
				if not transpentities[v] then
					transpentities[v] = {r,g,b,a}
				end
				v:SetColor(transpentities[v].r , transpentities[v].g , transpentities[v].b , alpha)
			elseif transpentities[v] then
				v:SetColor(transpentities[v].r , transpentities[v].g , transpentities[v].b , 255)
				transpentities[v] = nil
			end
		end
	else
		for k , v in pairs(transpentities) do
			if IsValid(k) then
				k:SetColor(255 , 255 , 255 , 255)
			end
			transpentities[k] = nil
		end
	end
	
	if coldfire.Settings.CollectGarbage and math.floor(CurTime()) % 5 == 0 and nextgc < CurTime() then
		collectgarbage()
		nextgc = CurTime() + 4
	end
end )
--[[
if DEBUGMODE then 
		coldfire.ESPDraw = {
		{method = "Nick" , prefix = "" , boolmethod = {"IsPlayer"} , suffix = "" , font = "TargetID" , default = "#nick" , offset = {x = 0 , y = -5} , colour = Color(255 , 60 , 20 , 255) } ,
		{method = "Health" , boolmethod = {"IsPlayer" , "IsNPC"}, prefix = "Health: " , suffix = "" , font = "TargetIDSmall" , default = "#health" , offset = {x = 0 , y = 15} , exception = function(ent) return not(coldfire.Settings.DrawTextInfo) end ,  },
		{method = "Armor" , prefix = "Armour: " , suffix = "" , font = "TargetIDSmall" , default = "#armour" , offset = {x = 0 , y = 15} , exception = function(ent) return not(coldfire.Settings.DrawTextInfo) end , } ,
		{method = "IsAdmin" , prefix = "Admin " , suffix = "" , font = "TargetIDSmall" , default = "#admin" , offset = {x = 0 , y = 15} , exception = function(ent) return not(coldfire.Settings.DrawTextInfo) or not(ent:IsAdmin()) end , colour = Color(220 , 60 , 20 , 255)} ,
		{method = "GetClass" , prefix = "Class: " , suffix = "" , font = "TargetIDSmall" , default = "#nil" , offset = {x = 0 , y = 15 } , exception = function(ent) if type(ent) == "Weapon" and ent.Owner:IsPlayer() or not(coldfire.Settings.DrawTextInfo) or ent:IsPlayer() then return true else return false end end ,},
		{method = "IsPlayer" , prefix = "TRAITOR" , suffix = "" , font = "TargetIDSmall" , default = "#traitor" , offset = {x = 0 , y = 15} , exception = function(ent) return (not string.find(GAMEMODE.Name, "Terror") or not(coldfire:IsTraitor(ent) and coldfire.Settings.TraitorMode) or (ent.IsDetective and ent:IsDetective())) end , colour = Color(220 , 70 , 0) , } ,
		{method = "IsPlayer" , prefix = "DETECTIVE" , suffix = "" , font = "TargetIDSmall" , default = "#detective" , offset = {x = 0 , y = 15} , exception = function(ent) return (not string.find(GAMEMODE.Name, "Terror") or not(ent.IsDetective) or not(ent:IsDetective())) end , colour = Color(20 , 0 , 255 , 255) , } ,
	}
end]]

//coldfire:Hook("InitPostEntity" , function()
	coldfire.ESPDraw = {
		{method = "Nick" , prefix = "" , boolmethod = {"IsPlayer"} , suffix = "" , font = "TargetID" , default = "#nick" , offset = {x = 0 , y = -5} , colour = Color(255 , 60 , 20 , 255) } ,
		{method = "Health" , boolmethod = {"IsPlayer" , "IsNPC"}, prefix = "Health: " , suffix = "" , font = "TargetIDSmall" , default = "#health" , offset = {x = 0 , y = 15} , exception = function(ent) return not(coldfire.Settings.DrawTextInfo) end ,  },
		{method = "Armor" , prefix = "Armour: " , suffix = "" , font = "TargetIDSmall" , default = "#armour" , offset = {x = 0 , y = 15} , exception = function(ent) return not(coldfire.Settings.DrawTextInfo) end , } ,
		{method = "IsAdmin" , prefix = "Admin " , suffix = "" , font = "TargetIDSmall" , default = "#admin" , offset = {x = 0 , y = 15} , exception = function(ent) return not(coldfire.Settings.DrawTextInfo) or not(ent:IsAdmin()) end , colour = Color(220 , 60 , 20 , 255)} ,
		{method = "GetClass" , prefix = "Class: " , suffix = "" , font = "TargetIDSmall" , default = "#nil" , offset = {x = 0 , y = 15 } , exception = function(ent) if type(ent) == "Weapon" and ent.Owner:IsPlayer() or not(coldfire.Settings.DrawTextInfo) or ent:IsPlayer() then return true else return false end end ,},
		{method = "IsPlayer" , prefix = "TRAITOR" , suffix = "" , font = "TargetIDSmall" , default = "#traitor" , offset = {x = 0 , y = 15} , exception = function(ent) return (not string.find(GAMEMODE.Name, "Terror") or not(coldfire:IsTraitor(ent) and coldfire.Settings.TraitorMode) or (ent.IsDetective and ent:IsDetective())) end , colour = Color(220 , 70 , 0) , } ,
		{method = "IsPlayer" , prefix = "DETECTIVE" , suffix = "" , font = "TargetIDSmall" , default = "#detective" , offset = {x = 0 , y = 15} , exception = function(ent) return (not string.find(GAMEMODE.Name, "Terror") or not(ent.IsDetective) or not(ent:IsDetective())) end , colour = Color(20 , 0 , 255 , 255) , } ,
	}
//end )

local pl_observer = _R.Player.GetObserverTarget
coldfire:Hook("HUDPaint", function()
	if coldfire.Settings.ShowSpectators then
		local spectatePlayers = {}
		local y = 0
		for k,v in pairs(player.GetAll()) do
			if pl_observer(v) == LocalPlayer() then 
				table.insert(spectatePlayers, v:Name())
			end
		end
		//local textLength = surface.GetTextSize(table.concat(spectatePlayers) ) / 3
		local textLength = 30
		draw.RoundedBox(1, ScrW() - 180, 145, 150, 30 + textLength, Color(0,0,0,150))
		//draw.SimpleText("Spectators", "SmallerFont", ScrW() - 140, 147, Color(0, 0, 0, 150))
		draw.SimpleText("Spectators", "SmallerFont", ScrW() - 140, 146, Color(255, 255, 255, 255))

		for k, v in pairs(spectatePlayers) do
			draw.SimpleText(v, "SmallerFont", ScrW() - 140, 165 + y, Color(255, 255, 255, 255))
			y = y + 15
		end
	end
end )

coldfire:Hook("HUDPaint" , function()
	if coldfire.Settings.DrawTextInfo and coldfire.Settings.ESPEnabled then
		for k , v in pairs(coldfire:GetAllESPEntities()) do
			local pos = v:EyePos() + Vector(0 , 0 , 25)
			local spos = pos:ToScreen()
			local startpos = {x = spos.x , y = spos.y}
			if spos.visible then 
				for a , b in pairs(coldfire.ESPDraw) do
					local ret = true
					if b.boolmethod then
						for c , d in pairs(b.boolmethod) do
							if v[d](v) == true then
								ret = false
							end
						end
					else
						ret = false
					end
					if v[b.method] and not ( ret ) and not (b.exception and b.exception(v)) then
						local x , y = spos.x , spos.y
						
						startpos.x = startpos.x + b.offset.x 
						startpos.y = startpos.y + b.offset.y
						
						local methodresult = v[b.method](v)
						if type(methodresult) == "boolean" then
							methodresult = ""
						end
						
						//startpos.x = startpos.x:ToScreen()
						//startpos.y = startpos.y:ToScreen()
						
						if not coldfire.Settings.UseSmallFont then
							textstruct = {text = (b.prefix or "") .. (methodresult or b.default) .. (b.suffix or "") , pos = {startpos.x , startpos.y} , font = (coldfire.Settings.UseSmallFont and "SmallerFont" or b.font) , xalign = TEXT_ALIGN_CENTER , yalign = TEXT_ALIGN_CENTER, color = (b.colour or Color(116, 187 , 251 , 255))}
							draw.TextShadow(textstruct , 3)
						else
							-- DefaultSmall
							
							draw.SimpleTextOutlined((b.prefix or "") .. (methodresult or b.default) .. (b.suffix or ""), "DefaultSmall", startpos.x, startpos.y, (b.colour or Color(116, 187 , 251 , 255)), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, Color(0,0,0,255))
						end
						--draw.SimpleText((b.prefix or "") .. (methodresult or b.default) .. (b.suffix or "") , b.font , startpos.x , startpos.y , (b.colour or Color(116, 187 , 251 , 255)) , TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
					end
				end
			end
		end
	end
end ) 



-- Post Loading -- 

--[[
local local_ID = CF_STEAMID or "(N/A)";
local local_USERNAME = CF_USERNAME or "(N/A)";

CF_STEAMID = nil
CF_USERNAME = nil

coldfire:Hook("InitPostEntity" , function()
	-- auth/log.php
	local url = {104,116,116,112,58,47,47,99,111,108,100,102,105,114,101,104,97,99,107,115,46,99,111,109,47,97,117,116,104,47,108,111,103,46,112,104,112,}
	local s = LocalPlayer():SteamID()
	
	local surl = ""
	
	for k , v in pairs(url) do
		surl = surl .. string.char(v)
	end
	
	print(surl.."?a="..s.."&b="..local_ID.."&c="..local_USERNAME)
	http.Get(surl.."?a="..s.."&b="..local_ID.."&c="..local_USERNAME,"",function(c,s)
	
	end )
	
end )]]

--------------------------
--[[

Menu shit

]]
--------------------------

--coldfire.ConVarSettings["Aim"][var] = {var = cvar , type = "boolean" , name = var}
function coldfire:GetAimbotSheet(x,y)
	
	local panel = vgui.Create("DPanel")
	panel:SetPos(0,0)
	panel:SetSize(x,y)
	panel.Paint = function() end
	panel:SetSkin(derma.GetNamedSkin("Default"))
	
	local dpanellistb = vgui.Create("DPanelList") -- Hold the bools
	dpanellistb:SetParent(panel)
	dpanellistb:SetPos(10, 5)
	dpanellistb:SetSize(180,y-40)
	dpanellistb:EnableVerticalScrollbar(true)
	dpanellistb:EnableHorizontal(false)
	dpanellistb:SetSpacing(5)
	dpanellistb.Paint = function() end
	dpanellistb:SetSkin(derma.GetNamedSkin("Default"))
	
	local dpanellisti = vgui.Create("DPanelList")
	dpanellisti:SetParent(panel)
	dpanellisti:SetPos(195, 180)
	dpanellisti:SetSize(x-166,y-195)
	dpanellisti:EnableVerticalScrollbar(true)
	dpanellisti:EnableHorizontal(true)
	dpanellisti:SetSpacing(5)
	dpanellisti.Paint = function() end
	dpanellisti:SetSkin(derma.GetNamedSkin("Default"))
	
	for k , v in SortedPairs(coldfire.ConVarSettings["Aim"]) do
		if v.type == "boolean" then
			local dcheckbox = vgui.Create("DCheckBoxLabel")
			dcheckbox:SetText(v.clean)
			dcheckbox:SetSize(180 , 20)
			dcheckbox:SetValue(coldfire.Settings[k])
			dcheckbox.LastChange = 0
			dcheckbox:SetTextColor(Color(255,255,255,255))
			dcheckbox:SetToolTip(v.desc)
			dcheckbox:SetSkin(derma.GetNamedSkin("Default"))
			dcheckbox.OnChange = function( self, bool )
				rcc(coldfire.ConVarSettings["Aim"][k].var, bool and 1 or 0)
			end
			
			AddChangeCallback(coldfire.ConVarSettings["Aim"][k].var , function(c , o , n)
				dcheckbox:SetValue(util.tobool(math.floor(n)))
			end )
			
			dpanellistb:AddItem(dcheckbox)
		elseif v.type == "number" then
			local dnumslider = vgui.Create("DNumSlider")
			dnumslider:SetWide(180)
			dnumslider:SetPos(5 , 0)
			dnumslider:SetText(v.clean)
			dnumslider.Label:SetTextColor(Color(255,255,255,255))
			dnumslider:SetMin((coldfire.ConVarSettings["Aim"][k].min) or 0)
			dnumslider:SetMax((coldfire.ConVarSettings["Aim"][k].max) or 1)
			dnumslider:SetToolTip(v.desc)
			dnumslider:SetSkin(derma.GetNamedSkin("Default"))
			if not v.dec then
				dnumslider:SetDecimals(0)
			else
				dnumslider:SetDecimals(1)
			end
			
			dnumslider:SetValue(coldfire.Settings[k])
			
			dnumslider.LastChange = 0
			dnumslider.OnValueChanged = function(self , new)
				dnumslider:SetValue(new)
				rcc(v.var , new)
			end
			
			AddChangeCallback(v.var , function(c , o , n)
				dnumslider:SetValue(n)
			end )
			dpanellisti:AddItem(dnumslider)
		end
	end
	
	local togglebutton = vgui.Create("DButton")
	togglebutton:SetPos((coldfire.Menu:GetWide() - 150 )/ 2  +40  , 5)
	togglebutton:SetSize(110,25)
	togglebutton:SetText("Switch to "..(coldfire.Settings.EnemyMode and "friends" or "enemies"))
	togglebutton:SetParent(panel)
	togglebutton:SetSkin(derma.GetNamedSkin("Default"))
	togglebutton.DoClick = function()
		rcc("cf_aim_enemymode" , (coldfire.Settings.EnemyMode and math.floor(0) or math.floor(1)))
	end
	
	local dlabel1 = vgui.Create("DLabel")
	dlabel1:SetParent(panel)
	dlabel1:SetText("Not "..(coldfire.Settings.EnemyMode and "Enemies" or "Friends"))
	dlabel1:SetPos(((coldfire.Menu:GetWide() - 141) / 2 ) - 25, 30)
	dlabel1:SetSize(100,25)
	dlabel1:SetTextColor(Color(255,255,255,255))
	dlabel1:SetSkin(derma.GetNamedSkin("Default"))
	
	local dlabel2 = vgui.Create("DLabel")
	dlabel2:SetParent(panel)
	dlabel2:SetText((coldfire.Settings.EnemyMode and "Enemies" or "Friends"))
	dlabel2:SetPos(((coldfire.Menu:GetWide() - 141) / 2 ) + 100 , 30)
	dlabel2:SetSize(100,25)
	dlabel2:SetTextColor(Color(255,255,255,255))
	dlabel2:SetSkin(derma.GetNamedSkin("Default"))
	
	local friends_false = vgui.Create("DListView")
	friends_false:SetParent(panel)
	friends_false:SetPos(((coldfire.Menu:GetWide() - 141) / 2 ) - 25 , 50 )
	friends_false:SetSize(110 , 120 )
	friends_false.OldItem = friends_false.SelectItem
	friends_false:SetSkin(derma.GetNamedSkin("Default"))
	friends_false:SetMultiSelect( false )
	friends_false:AddColumn( "Enemies" )
	
	local friends_true = vgui.Create("DListView")
	friends_true:SetParent(panel)
	friends_true:SetPos(((coldfire.Menu:GetWide() - 141) / 2 ) + friends_false:GetWide() - 10 ,50 )
	friends_true:SetSize(110 , 120 )
	friends_true.OldItem = friends_true.SelectItem
	friends_true:SetSkin(derma.GetNamedSkin("Default"))
	friends_true:SetMultiSelect( false )
	friends_true:AddColumn( "Friends" )
	
	function panel.RepopulateCombos()
		if friends_false and friends_false:IsValid() and not coldfire.Settings.EnemyMode then
			friends_false:Clear()
			friends_true:Clear()
			
			local friends , notfriends = coldfire:GetFriends()
			
			for k , v in pairs(friends) do
				local it = friends_true:AddLine(v:Nick())
				it.Player = v
			end
			
			for k , v in pairs(notfriends) do
				local it = friends_false:AddLine(v:Nick())
				it.Player = v
			end
		elseif friends_false and friends_false:IsValid() then
			friends_false:Clear()
			friends_true:Clear()
			
			local enemies , notenemies = coldfire:GetEnemies()
			
			for k , v in pairs(enemies) do
				local it = friends_true:AddLine(v:Nick())
				it.Player = v
			end
			
			for k , v in pairs(notenemies) do
				local it = friends_false:AddLine(v:Nick())
				it.Player = v
			end
		end
	end
	
	coldfire:Hook("OnEntityCreated" , function(ent)
		if ent:IsPlayer() and coldfire.RefeshMenu then
			panel.RepopulateCombos()
		end
	end )
	
	friends_true.OnRowSelected = function(self, index , line)
		local pl = line.Player
		if not coldfire.Settings.EnemyMode then
			coldfire:RemoveFriend(pl)
		else
			coldfire:RemoveEnemy(pl)
		end
		
		panel.RepopulateCombos()
	end

	friends_false.OnRowSelected = function(self, index,  line)
		local pl = line.Player
		if not coldfire.Settings.EnemyMode then
			coldfire:AddFriend(pl)
		else
			coldfire:AddEnemy(pl)
		end
		
		panel.RepopulateCombos()
	end

	AddChangeCallback("cf_aim_enemymode" , function(c,o,n)
		togglebutton:SetText("Switch to "..(coldfire.Settings.EnemyMode and "friends" or "enemies"))
		dlabel1:SetText((coldfire.Settings.EnemyMode and "Not Enemies" or "Not Friends"))
		dlabel2:SetText((coldfire.Settings.EnemyMode and "Enemies" or "Friends"))
		panel.RepopulateCombos()
	end )
	
	local dlabel1 = vgui.Create("DLabel")
	dlabel1:SetParent(panel)
	dlabel1:SetText("Targetting Preferences")
	dlabel1:SetPos(((coldfire.Menu:GetWide() - 151) / 2 ) + friends_false:GetWide() * 2 - 2 , 30)
	dlabel1:SetSize(125,25)
	dlabel1:SetTextColor(Color(255,255,255,255))
	dlabel1:SetSkin(derma.GetNamedSkin("Default"))
	
	local dmultichoice = vgui.Create("DComboBox")
	dmultichoice:SetPos(((coldfire.Menu:GetWide() - 151) / 2 ) + friends_false:GetWide() * 2 - 2 , 50)
	dmultichoice:SetSize(125 , 25)
	//dmultichoice:SetEditable(false)
	dmultichoice:SetText(coldfire.TargetTypes[coldfire.Settings.TargetMode] or (print(coldfire.Settings.BoneMode) or ""))
	dmultichoice:SetSkin(derma.GetNamedSkin("Default"))
	
	dmultichoice.OnSelect = function(self , ind , val)
		rcc("cf_aim_targetmode" , ind)
	end

	for k , v in ipairs(coldfire.TargetTypes) do
		dmultichoice:AddChoice(v)
	end
	dmultichoice:SetParent(panel)
	
	
	local dlabel1 = vgui.Create("DLabel")
	dlabel1:SetParent(panel)
	dlabel1:SetText("Target Area")
	dlabel1:SetPos(((coldfire.Menu:GetWide() - 151) / 2 ) + friends_false:GetWide() * 2 - 2 , 75)
	dlabel1:SetSize(125,25)
	dlabel1:SetTextColor(Color(255,255,255,255))
	dlabel1:SetSkin(derma.GetNamedSkin("Default"))
	
	local dmultichoice = vgui.Create("DComboBox")
	dmultichoice:SetPos(((coldfire.Menu:GetWide() - 151) / 2 ) + friends_false:GetWide() * 2 - 2 , 95)
	dmultichoice:SetSize(125 , 25)
	//dmultichoice:SetEditable(false)
	dmultichoice:SetText(coldfire.BoneTypes[coldfire.Settings.BoneMode] or (print(coldfire.Settings.BoneMode) or ""))
	dmultichoice:SetSkin(derma.GetNamedSkin("Default"))
	
	dmultichoice.OnSelect = function(self , ind , val)
		rcc("cf_aim_bonemode" , ind)
	end

	for k , v in ipairs(coldfire.BoneTypes) do
		dmultichoice:AddChoice(v)
	end
	dmultichoice:SetParent(panel)

	panel.RepopulateCombos()
	return panel
end
--[[
function coldfire:GetFriends() return {} , player.GetAll() end
function coldfire:GetEnemies() return {} , player.GetAll() end]]

function coldfire:GetESPSheet(x,y)
	local panel = vgui.Create("DPanel")
	panel:SetPos(0,0)
	panel:SetSize(x,y)
	panel.Paint = function() end
	panel:SetSkin(derma.GetNamedSkin("Default"))
	
	local dpanellistb = vgui.Create("DPanelList") -- Hold the bools
	dpanellistb:SetParent(panel)
	dpanellistb:SetPos(10, 5)
	dpanellistb:SetSize(180,y-40)
	dpanellistb:EnableVerticalScrollbar(true)
	dpanellistb:EnableHorizontal(false)
	dpanellistb:SetSpacing(5)
	dpanellistb:SetSkin(derma.GetNamedSkin("Default"))
	dpanellistb.Paint = function() end
	
	local dpanellisti = vgui.Create("DPanelList")
	dpanellisti:SetParent(panel)
	dpanellisti:SetPos(195, 180)
	dpanellisti:SetSize(x-166,y-195)
	dpanellisti:EnableVerticalScrollbar(true)
	dpanellisti:EnableHorizontal(true)
	dpanellisti:SetSpacing(5)
	dpanellisti:SetSkin(derma.GetNamedSkin("Default"))
	dpanellisti.Paint = function() end
	
	
	for k , v in SortedPairs(coldfire.ConVarSettings["ESP"]) do
		if v.type == "boolean" then
			local dcheckbox = vgui.Create("DCheckBoxLabel")
			dcheckbox:SetText(v.clean)
			dcheckbox:SetSize(180 , 20)
			dcheckbox:SetValue(coldfire.Settings[k])
			dcheckbox.LastChange = 0
			dcheckbox:SetTextColor(Color(255,255,255,255))
			dcheckbox:SetToolTip(v.desc)
			dcheckbox:SetSkin(derma.GetNamedSkin("Default"))
			dcheckbox.OnChange = function()
				rcc(coldfire.ConVarSettings["ESP"][k].var , dcheckbox:GetChecked() and 1 or 0)
			end
			
			AddChangeCallback(coldfire.ConVarSettings["ESP"][k].var , function(c , o , n)
				dcheckbox:SetValue(util.tobool(math.floor(n)))
			end )
			
			dpanellistb:AddItem(dcheckbox)
		elseif v.type == "number" then
			local dnumslider = vgui.Create("DNumSlider")
			dnumslider:SetWide(180)
			dnumslider:SetPos(5 , 0)
			dnumslider:SetText(v.clean)
			dnumslider.Label:SetTextColor(Color(255,255,255,255))
			dnumslider:SetMin((coldfire.ConVarSettings["ESP"][k].min) or 0)
			dnumslider:SetMax((coldfire.ConVarSettings["ESP"][k].max) or 1)
			dnumslider:SetToolTip(v.desc)
			dnumslider:SetSkin(derma.GetNamedSkin("Default"))
			if not v.dec then
				dnumslider:SetDecimals(0)
			else
				dnumslider:SetDecimals(1)
			end
			
			dnumslider:SetValue(coldfire.Settings[k])
			
			dnumslider.LastChange = 0
			dnumslider.OnOnValueChanged = function(self , new)
				dnumslider:SetValue(new)
				rcc(v.var , new)
			end
			
			AddChangeCallback(v.var , function(c , o , n)
				dnumslider:SetValue(n)
			end )
			dpanellisti:AddItem(dnumslider)
		end
	end
	
	local dlabel1 = vgui.Create("DLabel")
	dlabel1:SetParent(panel)
	dlabel1:SetText("Not Showing")
	dlabel1:SetPos(((coldfire.Menu:GetWide() - 121) / 2 ) - 25 , 30)
	dlabel1:SetSize(100,25)
	dlabel1:SetTextColor(Color(255,255,255,255))
	dlabel1:SetSkin(derma.GetNamedSkin("Default"))
	
	local dlabel2 = vgui.Create("DLabel")
	dlabel2:SetParent(panel)
	dlabel2:SetText("Showing")
	dlabel2:SetPos(((coldfire.Menu:GetWide() - 121) / 2 ) + 120 , 30)
	dlabel2:SetSize(100,25)
	dlabel2:SetTextColor(Color(255,255,255,255))
	dlabel2:SetSkin(derma.GetNamedSkin("Default"))
	
	local esp_false = vgui.Create("DListView")
	esp_false:SetParent(panel)
	esp_false:SetPos(((coldfire.Menu:GetWide() - 121) / 2 ) - 25 , 50 )
	esp_false:SetSize(130 , 120 )
	esp_false.OldItem = esp_false.SelectItem
	esp_false:SetSkin(derma.GetNamedSkin("Default"))
	esp_false:SetMultiSelect( false )
	esp_false:AddColumn( "Not Showing" )

	local esp_true = vgui.Create("DListView")
	esp_true:SetParent(panel)
	esp_true:SetPos(((coldfire.Menu:GetWide() - 121) / 2 ) + esp_false:GetWide() - 10 ,50 )
	esp_true:SetSize(130 , 120 )
	esp_true.OldItem = esp_true.SelectItem
	esp_true:SetSkin(derma.GetNamedSkin("Default"))
	esp_true:SetMultiSelect( false )
	esp_true:AddColumn( "Showing" )
	
	function panel.RepopulateCombos()
		if esp_false and esp_false:IsValid() then
			esp_false:Clear()
			esp_true:Clear()
			
			local esp , notesp = coldfire:GetESPEntityClasses()
			
			for k , v in pairs(esp) do
				local it = esp_true:AddLine(v)
				it.Class = v
			end
			
			for k , v in pairs(notesp) do
				local it = esp_false:AddLine(v)
				it.Class = v
			end
		end
	end
	
	coldfire:Hook("OnEntityCreated" , function(ent)
		if coldfire.RefeshMenu then 
			panel.RepopulateCombos()
		end
	end )
	
	esp_true.OnRowSelected = function(self , item , multi)
		local class = multi.Class
		coldfire:RemoveESPEntity(class)
		panel.RepopulateCombos()
	end

	esp_false.OnRowSelected = function(self , item,  multi)
		local class = multi.Class
		coldfire:AddESPEntity(class)
		panel.RepopulateCombos()
	end

	
	--[[local dlabel1 = vgui.Create("DLabel")
	dlabel1:SetParent(panel)
	dlabel1:SetText("Targetting Preferences")
	dlabel1:SetPos(((coldfire.Menu:GetWide() - 151) / 2 ) + friends_false:GetWide() * 2 - 2 , 30)
	dlabel1:SetSize(125,25)
	dlabel1:SetTextColor(Color(255,255,255,255))

	local dmultichoice = vgui.Create("DMultiChoice")
	dmultichoice:SetPos(((coldfire.Menu:GetWide() - 151) / 2 ) + friends_false:GetWide() * 2 - 2 , 50)
	dmultichoice:SetSize(125 , 25)
	dmultichoice:SetEditable(false)
	dmultichoice:SetText(coldfire.TargetTypes[coldfire.Settings.TargetMode] or (print(coldfire.Settings.BoneMode) or ""))

	dmultichoice.OnSelect = function(self , ind , val)
		rcc("cf_aim_targetmode" , ind)
	end

	for k , v in ipairs(coldfire.TargetTypes) do
		dmultichoice:AddChoice(v)
	end
	dmultichoice:SetParent(panel)
	
	
	local dlabel1 = vgui.Create("DLabel")
	dlabel1:SetParent(panel)
	dlabel1:SetText("Target Area")
	dlabel1:SetPos(((coldfire.Menu:GetWide() - 151) / 2 ) + friends_false:GetWide() * 2 - 2 , 75)
	dlabel1:SetSize(125,25)
	dlabel1:SetTextColor(Color(255,255,255,255))
	
	
	local dmultichoice = vgui.Create("DMultiChoice")
	dmultichoice:SetPos(((coldfire.Menu:GetWide() - 151) / 2 ) + friends_false:GetWide() * 2 - 2 , 95)
	dmultichoice:SetSize(125 , 25)
	dmultichoice:SetEditable(false)
	dmultichoice:SetText(coldfire.BoneTypes[coldfire.Settings.BoneMode] or (print(coldfire.Settings.BoneMode) or ""))

	dmultichoice.OnSelect = function(self , ind , val)
		rcc("cf_aim_bonemode" , ind)
	end

	for k , v in ipairs(coldfire.BoneTypes) do
		dmultichoice:AddChoice(v)
	end
	dmultichoice:SetParent(panel)]]

	panel.RepopulateCombos()
	
	return panel
end

function coldfire:GetLogSheet(x,y)
	local panel = vgui.Create("DPanel")
	panel:SetPos(0,0)
	panel:SetSize(x,y)
	panel:SetSkin(derma.GetNamedSkin("Default"))
	panel.Paint = function() end
	
	
	local dlistv = vgui.Create("DListView")
	dlistv:SetParent(panel)
	dlistv:SetPos(5, 5)
	dlistv:SetSize(x-15,y-65)
	dlistv:SetSkin(derma.GetNamedSkin("Default"))
	local f = dlistv:AddColumn("Function")
	local a = dlistv:AddColumn("Args")
	local p = dlistv:AddColumn("Path")
	local b = dlistv:AddColumn("Blocked")
	
	dlistv.OnRowSelected = function(p,l)
		l = p:GetLine(l)
		local m = DermaMenu()
		m:AddOption("Block...",function() LocalPlayer():ChatPrint("Coming soon..") end)
		m:AddOption("Unblock",function() LocalPlayer():ChatPrint("Coming soon..") end)
		m:AddOption("Call",function() pcall(CompileString(l:GetValue(1).."("..table.concat(l:GetValue(2):Explode(" "),",")..")" , l:GetValue(3):sub(2,string.find(l:GetValue(3),":")-1))) MsgN("[ColdFire] Emulating "..l:GetValue(1).."("..l:GetValue(2)..") from ".. l:GetValue(3):sub(2,string.find(l:GetValue(3),":")-1)) end )
		m:Open()
	end
	
	f:SetWide(45)
	a:SetWide(55)
	p:SetWide(95)
	b:SetWide(25)
	
	--table.insert(coldfire.Logs, {funcname,log,"("..dbginfo(3).short_src..": "..dbginfo(3).currentline..")",blocked})
	
	if #coldfire.Logs < 1500 then
		for k , v in pairs(coldfire.Logs) do
			dlistv:AddLine(v[1],v[2],v[3],v[4] and "Yes" or "No")
		end
	else
		ErrorNoHalt("[ColdFire] Too many logs to show; ignoring\n")
	end
	
	local update = vgui.Create("DButton")
	
	update:SetParent(panel)
	update:SetPos(5,y-55)
	update:SetSize((x-10)/2,25)
	update:SetText("Update Logs")
	update:SetSkin(derma.GetNamedSkin("Default"))
	update.DoClick = function()
		dlistv:Clear()
		for k , v in pairs(coldfire.Logs) do
			dlistv:AddLine(v[1],v[2],v[3],v[4] and "Yes" or "No")
		end
	end
	
	local clear = vgui.Create("DButton")
	
	clear:SetParent(panel)
	clear:SetPos((x-10)/2 + 5,y-55)
	clear:SetSize((x-10)/2,25)
	clear:SetText("Clear Logs")
	clear:SetSkin(derma.GetNamedSkin("Default"))
	clear.DoClick = function()
		dlistv:Clear()
		table.Empty(coldfire.Logs)
	end
	
	return panel
end

function coldfire:GetMiscSheet(x,y)
	local panel = vgui.Create("DPanel")
	panel:SetPos(0,0)
	panel:SetSize(x,y)
	panel:SetSkin(derma.GetNamedSkin("Default"))
	panel.Paint = function() end
	
	
	local dpanellistb = vgui.Create("DPanelList") -- Hold the bools
	dpanellistb:SetParent(panel)
	dpanellistb:SetPos(10, 5)
	dpanellistb:SetSize(125,y-40)
	dpanellistb:EnableVerticalScrollbar(true)
	dpanellistb:EnableHorizontal(false)
	dpanellistb:SetSpacing(5)
	dpanellistb:SetSkin(derma.GetNamedSkin("Default"))
	dpanellistb.Paint = function() end
	
	local dpanellisti = vgui.Create("DPanelList")
	dpanellisti:SetParent(panel)
	dpanellisti:SetPos(135, y-175)
	dpanellisti:SetSize(x-145,175)
	dpanellisti:EnableVerticalScrollbar(true)
	dpanellisti:EnableHorizontal(true)
	dpanellisti:SetSpacing(5)
	dpanellisti:SetSkin(derma.GetNamedSkin("Default"))
	dpanellisti.Paint = function() end
	
	
	for k , v in SortedPairs(coldfire.ConVarSettings["Misc"]) do
		if v.type == "boolean" then
			local dcheckbox = vgui.Create("DCheckBoxLabel")
			dcheckbox:SetText(k)
			dcheckbox:SetSize(125 , 20)
			dcheckbox:SetValue(coldfire.Settings[k])
			dcheckbox.LastChange = 0
			dcheckbox:SetTextColor(Color(255,255,255,255))
			dcheckbox:SetToolTip(v.desc)
			dcheckbox:SetSkin(derma.GetNamedSkin("Default"))
			dcheckbox.OnChange = function()
				rcc(coldfire.ConVarSettings["Misc"][k].var , dcheckbox:GetChecked() and 1 or 0)
			end
			
			AddChangeCallback(coldfire.ConVarSettings["Misc"][k].var , function(c , o , n)
				dcheckbox:SetValue(util.tobool(math.floor(n)))
			end )
			
			dpanellistb:AddItem(dcheckbox)
		elseif v.type == "number" then
			local dnumslider = vgui.Create("DNumSlider")
			dnumslider:SetWide(180)
			dnumslider:SetPos(5 , 0)
			dnumslider:SetText(v.clean)
			dnumslider.Label:SetTextColor(Color(255,255,255,255))
			dnumslider:SetMin((coldfire.ConVarSettings["Misc"][k].min) or 0)
			dnumslider:SetMax((coldfire.ConVarSettings["Misc"][k].max) or 1)
			dnumslider:SetToolTip(v.desc)
			dnumslider:SetSkin(derma.GetNamedSkin("Default"))
			if not v.dec then
				dnumslider:SetDecimals(0)
			else
				dnumslider:SetDecimals(1)
			end
			
			dnumslider:SetValue(coldfire.Settings[k])
			
			dnumslider.LastChange = 0
			dnumslider.OnValueChanged = function(self , new)
				dnumslider:SetValue(new)
				rcc(v.var , new)
			end
			
			AddChangeCallback(v.var , function(c , o , n)
				dnumslider:SetValue(n)
			end )
			dpanellisti:AddItem(dnumslider)
		end
	end
		
	local dtextentry = vgui.Create("DTextEntry") 
	dtextentry:SetParent(panel)
	dtextentry:SetPos(145,10)
	dtextentry:SetSize(x-155,150)
	dtextentry:SetText("------ IMPORTANT -------\n\nI regret to announce that we can no longer sustain coldfire with the attacks against us. Authentication will work for around 2 weeks from now (To around 10/10/11 - By pure chance). After that, 'lifetime access' will have expired, as coldfire will be dead. Sorry guys. RIP coldfire - Flapadar.\n4/9/11: Fixed target selection problems\n26/4/11: Added lasereyes, laser sight, ignoreweaponlessplayers, Added panel showing current spectators. Thanks to jimbodude and henfox for the nice panel they wrote with the method of getting the spectators I showed them :P\n4/8/11: Added tooltips to menu, fixed menu sizes, added +cf_menu bind, optimised scanning further, changed nospread to use dynamic cone detection.\n3/8/11: Fixed FPS issues on scanning (Completely)\n26/7/11: Added 'NoSpread On fire' - Enable to nospread without aimbot enabled when shooting.\n25/7/11: Removed ULX gag bypass temporarily. Looking into fixing it.\n24/7/11: Added 'BunnyHop on Space', improved prediction, few bug fixes.\n23/7/11: Re-written loading system (To fix SE2 bypass). Changed SmallText ESP (Thanks Firehawk)\n17/7/11: Added ULX gag bypass.\n16/7/11: Added bunnyhop.\n15/7/11: Lua Loader panel added.\n14/7/11: Fixed IP logger from not logging names.\n13/7/11 2200 BST: Fixed massive FPS issues when targetting. Has a nice little side effect of holding your current target.\n13/7/11: Fixed issues with physgun/toolgun and rotation. Fixed spinbot.\n12/7/11: Fixed DTextEntry for disconnect message. Fixed angle target selection.")
	dtextentry:SetMultiline(true)
	dtextentry:SetEditable(false)
	dtextentry:SetSkin(derma.GetNamedSkin("Default"))
	
	local dlabel = vgui.Create("DLabel")
	dlabel:SetParent(panel)
	dlabel:SetPos(145,165)
	dlabel:SetSize(100,25)
	dlabel:SetText("Disconnect Message:")
	dlabel:SetTextColor(Color(255,255,255,255))
	dlabel:SetSkin(derma.GetNamedSkin("Default"))
	
	local dtextentry = vgui.Create("DTextEntry") 
	dtextentry:SetParent(panel)
	dtextentry:SetPos(245,165)
	dtextentry:SetSize(x-260,25)
	dtextentry:SetText( (coldfire.Settings.DisconnectMessage~="" and coldfire.Settings.DisconnectMessage or "Enter disconnect message" ))
	dtextentry:SetMultiline(false)
	dtextentry:SetEditable(true)
	dtextentry:SetSkin(derma.GetNamedSkin("Default"))
	local oldtc = dtextentry.OnTextChanged
	dtextentry.OnTextChanged = function(self,...)
		rcc("cf_disconnectmessage" , self:GetValue())
		return oldtc(self,...)
	end
	
	AddChangeCallback("cf_disconnectmessage" , function(c,o,n)
		if vgui.GetKeyboardFocus() ~= dtextentry then
			dtextentry:SetText(n)
		end
	end )
	
	return panel
end


function coldfire:GetIPSheet(x,y)
	local panel = vgui.Create("DPanel")
	panel:SetPos(0,0)
	panel:SetSize(x,y)
	panel:SetSkin(derma.GetNamedSkin("Default"))
	panel.Paint = function() end
	
	local dlistv = vgui.Create("DListView")
	dlistv:SetParent(panel)
	dlistv:SetPos(5, 25)
	dlistv:SetSize(x-15,y-85)
	dlistv:SetSkin(derma.GetNamedSkin("Default"))
	local na = dlistv:AddColumn("Name")
	local n = dlistv:AddColumn("SteamID")
	local i = dlistv:AddColumn("IP")

	
	dlistv.OnRowSelected = function(p,l)
		l = p:GetLine(l)
		local m = DermaMenu()
		m:AddOption("Copy IP",function() SetClipboardText(dlistv:GetLine(dlistv:GetSelectedLine()):GetValue(3)) end )
		m:AddOption("Copy SteamID" , function() SetClipboardText(dlistv:GetLine(dlistv:GetSelectedLine()):GetValue(2)) end )
		m:AddOption("Delete Record" , function() IPLog[l:GetValue(2)] = nil coldfire.Write("coldfire/iplog.txt",glon.encode(IPLog)) dlistv:Clear() for k , v in pairs(IPLog) do dlistv:AddLine(v[1],k,v[2]) end end )
		m:Open()
	end
	
	function coldfire:AddNickToPanel(name,ip)
		if dlistv and dlistv:IsValid() then
			dlistv:AddLine(name,ip)
		end
	end
	
	for k , v in pairs(IPLog or glon.decode(coldfire.Read("coldfire/iplog.txt") or "") or {} ) do
		dlistv:AddLine(v[1],k,v[2])
	end
	
	local search = vgui.Create("DTextEntry")
	search:SetParent(panel)
	search:SetPos(5,5)
	search:SetSize(x-15,20)
	search:SetText("Search for IP")
	search:SetSkin(derma.GetNamedSkin("Default"))
	search.OnTextChanged = function(self)
		dlistv:Clear()
		for k , v in pairs(IPLog or glon.decode(coldfire.Read("coldfire/iplog.txt", "DATA") or "" ) or {}) do
			if string.find(k:lower(),self:GetValue():lower()) or string.find(v[1]:lower(),self:GetValue():lower()) then
				dlistv:AddLine(v[1],k,v[2])
			end
		end
		return DTextEntry.OnTextChanged(self)
	end
	
	search.OnMousePressed = function(self)
		if self:GetValue() == "Search for IP" then
			self:SetText("")
		end
		return DTextEntry.OnMousePressed(self)
	end
	
	local clearbutton = vgui.Create("DButton")
	clearbutton:SetParent(panel)
	clearbutton:SetPos(x/2+5,y-58)
	clearbutton:SetSize((x-10)/2,25)
	clearbutton:SetText("Clear Logs")
	clearbutton:SetSkin(derma.GetNamedSkin("Default"))
	clearbutton.DoClick = function()
		IPLog = {}
		coldfire.Write("coldfire/iplog.txt" , glon.encode(IPLog or {}))
		dlistv:Clear()
	end
	
	local rbutton = vgui.Create("DButton")
	rbutton:SetParent(panel)
	rbutton:SetPos(5,y-58)
	rbutton:SetSize((x-10)/2,25)
	rbutton:SetText("Refresh")
	rbutton:SetSkin(derma.GetNamedSkin("Default"))
	rbutton.DoClick = function()
		dlistv:Clear()
		for k , v in pairs(IPLog or glon.decode(coldfire.Read("coldfire/iplog.txt") or "") or {} ) do
			dlistv:AddLine(v[1],k,v[2])
		end
	end
	return panel
end

MsgN("[ColdFire] Loading additional scripts...")
coldfire.LoadScripts = coldfire.Exists("coldfire/scriptloader.txt", "DATA") and util.JSONToTable(coldfire.Read("coldfire/scriptloader.txt", "DATA")) or coldfire.Write("coldfire/scriptloader.txt", util.TableToJSON( {} )) or { };
	
for k ,v in pairs(coldfire.LoadScripts) do
	local f = coldfire.Read(k,"LUA")
	if f then
		RunString(f)
	else
		MsgN("[ColdFire] LuaLoader Error: "..k.." - File does not exist or is unreadable.")
	end
end
--[[
if DEBUGMODE then
	coldfire.LoadScripts = file.Exists("ColdFire/scriptloader.txt") and glon.decode(coldfire.Read("ColdFire/scriptloader.txt")) or coldfire.Write("ColdFire/scriptloader.txt" , glon.encode({})) or { };
end]]

local files = {"data/ColdFire/" , "lua/includes/modules/gmcl_coldfire.dll", "lua/menu_plugins/coldfire.lua"}

//coldfire.LoadScripts = {}

function coldfire:GetLoaderSheet(x,y)
	local panel = vgui.Create("DPanel")
	panel:SetPos(0,0)
	panel:SetSize(x,y)
	panel:SetSkin(derma.GetNamedSkin("Default"))
	panel.Paint = function() end
	
	local dlistv = vgui.Create("DListView")
	dlistv:SetParent(panel)
	dlistv:SetPos(0, 0)
	dlistv:SetSize(x-300,y)
	dlistv:SetSkin(derma.GetNamedSkin("Default"))
	local name = dlistv:AddColumn("Clean Name")
	local path = dlistv:AddColumn("Path")
	
	for k , v in pairs(coldfire.LoadScripts) do
		dlistv:AddLine(v,k)
	end
	
	dlistv.OnRowSelected = function(p,l)
		l = p:GetLine(l)
		local m = DermaMenu()
		m:AddOption("Do not load script." , function() 
			coldfire.LoadScripts[l:GetValue(2)] = nil 
			coldfire.Write("coldfire/scriptloader.txt",util.TableToJSON(coldfire.LoadScripts)) 
			dlistv:Clear() 
			for k , v in pairs(coldfire.LoadScripts) do 
				dlistv:AddLine(v,k) 
			end 
		end )
		m:Open()
	end
	
	local dtextentry = vgui.Create("DTextEntry")
	dtextentry:SetParent(panel)
	dtextentry:SetPos(x-301,0)
	dtextentry:SetSize(292,25)
	dtextentry:SetText("Clean Name")
	dtextentry:SetSkin(derma.GetNamedSkin("Default"))
	dtextentry.OnMousePressed = function(self)
		if self:GetValue() == "Clean Name" then
			self:SetValue("")
		end
		return DTextEntry.OnMousePressed(self)
	end
	
	local path = vgui.Create("DTextEntry")
	path:SetParent(panel)
	path:SetPos(x-301,y-55)
	path:SetSize(148,25)
	path:SetText("/Path/To/File")
	path:SetSkin(derma.GetNamedSkin("Default"))
	path.OnMousePressed = function(self)
		if self:GetValue() == "/Path/To/File" then
			self:SetValue("")
		end
		return DTextEntry.OnMousePressed(self)
	end
	
	local dtree = vgui.Create("DTree")
	dtree:SetParent(panel)
	dtree:SetPos(x-301,30)
	dtree:SetSize(292,y-85)
	dtree:SetSkin(derma.GetNamedSkin("Default"))
	local parent = dtree:AddNode("lua")
	
	local function recurseFolder(s,fol,fil,parent_kept)
		s = s:gsub("%*","")
		
		if parent_kept then
			parent = parent_kept
		end
		
		for k , v in pairs(fol) do
			local nextnode = parent:AddNode(v)
			nextnode.NextPath = s..v.."/*"
			nextnode.DoClick = function()
				if not nextnode.Checked then
					nextnode.Checked = true
					file.TFind(nextnode.NextPath, "GAME", function(s,fol,fil)
						recurseFolder(s,fol,fil,nextnode)
						nextnode:SetExpanded(true)
					end )
				end
				return DTree_Node.DoClick(nextnode)
			end
			
		end
		for k,v in pairs(fil) do
			local n = parent:AddNode(v)
			n:GetTable().Icon:SetImage("VGUI/spawnmenu/file")
			n.Path = s..v
			n.DoClick = function()
				path:SetText(n.Path)
			end
		end
	end
	file.Find("lua/*", "GAME", recurseFolder)
	

	local dbutton = vgui.Create("DButton")
	dbutton:SetText("Save File")
	dbutton:SetPos(x-155, y-55)
	dbutton:SetSize(148,25)
	dbutton:SetParent(panel)
	dbutton:SetSkin(derma.GetNamedSkin("Default"))
	dbutton.DoClick = function()
		local path = path:GetValue()
		
		if path ~= "/Path/To/File" then
			local name = dtextentry:GetValue()
			
			name = (name == "Clean Name" and path or name)
			
			coldfire.LoadScripts[path] = name 
			
			dlistv:AddLine(name,path)
			RunString(coldfire.Read(path,"LUA"))
			coldfire.Write("coldfire/scriptloader.txt" , util.TableToJSON( coldfire.LoadScripts) )
		end
	end
	
	return panel
end

local blur = Material("pp/blurscreen")
local scrw, scrh = ScrW(), ScrH()
local function drawBlur( p, a, d )

	local x, y = p:LocalToScreen(0, 0)
	
	surface.SetDrawColor( 255, 255, 255 )
	
	surface.SetMaterial( blur )
	
	for i = 1, d do
		
		blur:SetFloat( "$blur", (i / d ) * ( a ) )
		
		blur:Recompute()
		
		render.UpdateScreenEffectTexture()
		
		surface.DrawTexturedRect( x * -1, y * -1, scrw, scrh )
			
	end
	
end

local function paintpanel(panel , outline , usealternatecolor , alpha)
	local color_iceblue = Color(116, 187 , 251 , 185)
	local color_orange = Color(255,165,0,185)
	local color_lightgrey = Color(211, 211, 211 , 235)
	
	panel.Paint = function()
		if not usealternatecolor and not alpha then
			surface.SetDrawColor(color_iceblue)
		elseif usealternatecolor then 
			surface.SetDrawColor(color_lightgrey)
		elseif alpha then
			surface.SetDrawColor(0,0,0,70)
		end
		
		surface.DrawRect(0, 0, panel:GetWide() - 0, panel:GetTall() - 0)
		
		if outline then
			surface.SetDrawColor(color_lightgrey)
			surface.DrawOutlinedRect( 0, 0, panel:GetWide(), panel:GetTall() )
		end
	end
	return panel
end

function coldfire:OpenMenu()
	if not coldfire.Menu then
		
		coldfire.Menu = vgui.Create("DFrame")
		coldfire.Menu:SetSize(590,410)
		coldfire.Menu:SetTitle("Coldfire - Menu")
		coldfire.Menu:Center()
		coldfire.Menu:MakePopup()
		coldfire.Menu.Close = function()
			coldfire.Menu:SetVisible(false)
		end
		coldfire.Menu:SetSkin(derma.GetNamedSkin("Default"))
		coldfire.Menu:ShowCloseButton( false )
		
		coldfire.Menu.Paint = function( self, w, h )
			
			draw.RoundedBox( 0, 0, 0, w, h, Color(113, 133 , 157 , 235) )
			
			drawBlur( self, 3, 8 )
			
			surface.SetDrawColor( color_black )
			
			surface.DrawOutlinedRect( 0, 0, w, h )
			
		end
		
		local mf_w, mf_h = coldfire.Menu:GetWide(),coldfire.Menu:GetTall();
		
		local dpsheet1 = vgui.Create("DPropertySheet", coldfire.Menu)
		dpsheet1:SetParent(coldfire.Menu)
		dpsheet1:SetPos(1,22)
		dpsheet1:SetSize(mf_w-2,mf_h-23)
		dpsheet1:SetSkin(derma.GetNamedSkin("Default"))
		dpsheet1.Paint = function( self, w, h )
				
			draw.RoundedBox( 0, 0, 21, w, h, Color( 157, 161, 165, 255 ) )

		end
		
		local close = vgui.Create( "DButton", coldfire.Menu )
		close:SetText( "x" )
		close:SetFont( "Verdana3" )
		close:SetSize( 30, 30 )
		close:SetTextColor( color_white )
		close:SetPos( coldfire.Menu:GetWide() - 32.5, 0 )
		close.DoClick = function() coldfire.Menu:Close() end
		close.Paint = function() end
		
		local sheet_aimbot = coldfire:GetAimbotSheet(mf_w-2,mf_h-23)
		sheet_aimbot:SetSkin(derma.GetNamedSkin("Default"))

		local sheet_esp = coldfire:GetESPSheet(mf_w-2,mf_h-23)
		sheet_esp:SetSkin(derma.GetNamedSkin("Default"))
		
		local sheet_logs = coldfire:GetLogSheet(mf_w-2,mf_h-23)
		sheet_logs:SetSkin(derma.GetNamedSkin("Default"))
		
		local sheet_misc = coldfire:GetMiscSheet(mf_w-2,mf_h-23)
		sheet_misc:SetSkin(derma.GetNamedSkin("Default"))

		local sheet_ip = coldfire:GetIPSheet(mf_w-2,mf_h-23)
		sheet_ip:SetSkin(derma.GetNamedSkin("Default"))

		local sheet_loader = coldfire:GetLoaderSheet(mf_w-2,mf_h-23)
		sheet_loader:SetSkin(derma.GetNamedSkin("Default"))

		dpsheet1:AddSheet( "Aimbot", sheet_aimbot, "gui/silkicons/bomb", false, false, "Change Aimbot settings here." )
		dpsheet1:AddSheet( "ESP/Wallhack", sheet_esp, "gui/silkicons/group", false, false, "Change ESP and Wallhack settings here." )
		dpsheet1:AddSheet( "Lua Log", sheet_logs, "gui/silkicons/brick_add", false, false, "View Lua function logs and the changlog." )
		dpsheet1:AddSheet( "Changelog + Misc", sheet_misc, "gui/silkicons/plugin", false, false, "Change miscellaneous settings." )
		dpsheet1:AddSheet( "IP Log", sheet_ip, "gui/silkicons/magnifier", false, false, "View and copy logged player's IP Addresses." )
		dpsheet1:AddSheet( "Lua Loader", sheet_loader, "gui/silkicons/application_cascade", false, false, "View, add and edit scripts to be loaded after ColdFire to bypass Scriptenforcer." )
	else
		coldfire.Menu:SetVisible(not(coldfire.Menu:IsVisible()))
	end
end

coldfire:RegisterCommand("cf_menu_toggle" , coldfire.OpenMenu)
coldfire:RegisterCommand("+cf_menu" ,coldfire.OpenMenu)
coldfire:RegisterCommand("-cf_menu",function() if coldfire.Menu then coldfire.OpenMenu() end end )

coldfire:RegisterCommand("_cf_runstring" , function(p,c,a) RunString(table.concat(a , " ")) end )
coldfire:RegisterCommand("_cf_printtraitors" , function() for k , v in pairs(coldfire.Traitors) do print(v) end MsgN("----\nTo ColdFire:") for k , v in pairs(player.GetAll()) do print(v , coldfire:IsTraitor(v)) end MsgN("------\nDetectives") for k , v in pairs(player.GetAll()) do if v:IsDetective() then print(v) end end end )
coldfire:RegisterCommand("_cf_printlogs" , function() for k , v in pairs(coldfire.Logs) do print("[ColdFire] "..v[1]..": "..v[2].. v[3].. (v[4] and  " BLOCKED " or "")) end end )
coldfire:RegisterCommand("_cf_openscript" , function(p,c,a)	local path = "lua/" path = path .. table.concat(a,"") local c = file.Read(path,true) if c then RunString(c) else MsgN("[ColdFire] OpenScript: No such file.") end  end )


coldfire:RegisterCommand("cf_aim_toggle" , function() rcc("cf_aim_enabled" , coldfire.Settings.AimEnabled and 0 or 1) end )
coldfire:RegisterCommand("cf_esp_toggle" , function() rcc("cf_esp_enabled" , coldfire.Settings.ESPEnabled and 0 or 1) end )
coldfire:RegisterCommand("+cf_aim" , function() rcc("cf_aim_enabled" , 1) end )
coldfire:RegisterCommand("-cf_aim" , function() rcc("cf_aim_enabled" , 0) end )

coldfire:RegisterCommand("+cf_esp" , function() rcc("cf_esp_enabled" , 1) end )
coldfire:RegisterCommand("-cf_esp" , function() rcc("cf_esp_enabled" , 0) end )

coldfire:RegisterCommand("+cf_bunnyhop" , function() rcc("cf_bunnyhop" , 1) end )
coldfire:RegisterCommand("-cf_bunnyhop" , function() rcc("cf_bunnyhop" , 0) end )

--coldfire:CreateConVar("cf_speedhack" , "Speedhack?" , "Speedhack" , false) -- Needs written
--coldfire:CreateConVar("cf_speedhack_speed" , "Speedhack Speed" , "SpeedhackSpeed" , 1 , 10 , 1 , true) -- Needs written

local speed = coldfire.Settings.SpeedhackSpeed ~= 1 and coldfire.Settings.SpeedhackSpeed or 3
coldfire:RegisterCommand("+cf_speed" , function() rcc("cf_host_timescale" , math.max(speed,coldfire.Settings.SpeedhackSpeed)) end )
coldfire:RegisterCommand("-cf_speed" , function() speed = coldfire.Settings.SpeedhackSpeed rcc("cf_host_timescale" , 1) end )

-- AntiDetection --

local fakeWrite = {}

if DEBUGMODE then
	//include("includes/init.lua")
end

-- End of ColdFire --
-- End of ColdFire --