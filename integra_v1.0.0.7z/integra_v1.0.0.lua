--[[
	integra/integra.lua
	-MLFR- Anthr4X (Swe) | (STEAM_0:1:33687954)
	===DStream===
]]

include('includes/compat.lua')
include('includes/util.lua')
include('includes/util/sql.lua')
require('concommand')
require('saverestore')
require('gamemode')
require('weapons')
require('hook')
require('timer')
require('schedule')
require('scripted_ents')
require('player_manager')
require('numpad')
require('team')
require('undo')
require('cleanup')
require('duplicator')
require('constraint')
require('construct')	
require('filex')
require('vehicles')
require('usermessage')
require('list')
require('cvars')
require('http')
require('datastream')
require('draw')
require('markup')
require('effects')
require('killicon')
require('spawnmenu')
require('controlpanel')
require('presets')
require('cookie')

include('includes/util/model_database.lua')
include('includes/util/vgui_showlayout.lua')
include('includes/util/tooltips.lua')
include('includes/util/client.lua')

local math = math
local string = string
local debug = debug
local table = table
local pcall = pcall
local error = error
local ErrorNoHalt = ErrorNoHalt
local MsgN = MsgN
local Msg = Msg
local print = print
local surface = surface
local util = util
local type = type
local RunConsoleCommand = RunConsoleCommand
local CreateClientConVar = CreateClientConVar
local _R = _R
local _G = _G

local aiming = false
local target = nil
local xrayents = {}
local integra = {}
	integra.modules = {}

// Derma used
local IDerma = {}
IDerma.CreateDFrame = function(parent)
	local Frame = vgui.Create("DFrame", parent)
		Frame:SetSize(100, 20)
		Frame:SetPos(10, 10)
		Frame.Paint = function(self)
			surface.SetDrawColor(Color(0, 0, 0, 192))
			surface.DrawRect(0, 0, self:GetWide(), self:GetTall())
			surface.SetDrawColor(Color(0, 0, 0, 96))
			surface.DrawRect(0, 0, self:GetWide(), 22)
		end
	return Frame
end
IDerma.CreateDPanel = function(parent)
	local Panel = vgui.Create("DPanel", parent)
		Panel.Paint = function(self)
			surface.SetDrawColor(Color(0, 0, 0, 192))
			surface.DrawRect(0, 0, self:GetWide(), self:GetTall())
			surface.SetDrawColor(Color(192, 192, 192, 16))
			surface.DrawOutlinedRect(0, 0, self:GetWide(), self:GetTall())
		end
	return Panel
end
// End of used derma

local function INT_AddModule(mod)
	if mod.ConVar != nil then
		if mod.ConVar != "" then
			CreateClientConVar("int_" .. mod.ConVar .. "_enabled", 1, true, false)
		end
	end
	local obj = {}
		obj.Title = mod.Title or "Unknown"
		obj.ConVar = mod.ConVar or ""
		obj.Init = mod.Init or function() end
		obj.Reload = mod.Reload or function() end
		obj.Paint = mod.Paint or function() end
		obj.UsePaint = mod.UsePaint or false
		obj.Think = mod.Think or function() end
		obj.UseThink = mod.UseThink or false
		obj.RenderScreenspaceEffects = mod.RenderScreenspaceEffects or function() end
		obj.UseRenderScreenspaceEffects = mod.UseRenderScreenspaceEffects or false
	table.insert(integra.modules, obj)
end

local function INT_IsModEnabled(mod)
	if mod.ConVar != nil then
		if mod.ConVar != "" then
			if GetConVar("int_" .. mod.ConVar .. "_enabled"):GetBool() then
				return true
			else
				return false
			end
		else
			return true
		end
	end
	return true
end

local function INT_AddModConfig(mod, config, default)
	if mod.ConVar != nil then
		if mod.ConVar != "" then
			CreateClientConVar("int_" .. mod.ConVar .. "_" .. config, default or 0, true, false)
		end
	end
end

local function INT_GetModConfig(mod, config)
	if mod.ConVar != nil then
		if mod.ConVar != "" then
			if GetConVar("int_" .. mod.ConVar .. "_" .. config) != nil then
				return GetConVar("int_" .. mod.ConVar .. "_" .. config)
			end
		end
	end
end

local function INT_ValidPlayer(ply)
	if ply != nil then
		if type(ply) == "Player" then
			if ply and ply:IsValid() then
				if ply:Nick() != nil then
					return true
				end
			end
		end
	end
	return false
end

local function INT_GetMuzzlePos(ply)
	if INT_ValidPlayer(ply) then
		if ply:GetActiveWeapon() != nil then
			local wep = ply:GetActiveWeapon()
			if wep and wep:IsValid() then
				local ViewModel = ply:GetViewModel()
				if ViewModel != nil and ViewModel:IsValid() then
					local attach = ViewModel:LookupAttachment("muzzle")
					if attach > 0 then
						local pos = ViewModel:GetAttachment(attach).Pos
						return pos
					end
				end
			end
		end
	end
	return ply:EyePos()
end

local function INT_Paint()
	if not GetConVar("int_enabled"):GetBool() then return end
	for k, v in pairs(integra.modules) do
		if INT_IsModEnabled(v) and v.UsePaint then
			v:Paint()
		end
	end
end
hook.Add("HUDPaint", "INT_Paint", INT_Paint)

local function INT_Think()
	if not GetConVar("int_enabled"):GetBool() then return end
	for k, v in pairs(integra.modules) do
		if INT_IsModEnabled(v) and v.UseThink then
			v:Think()
		end
	end
end
hook.Add("Think", "INT_Think", INT_Think)

local function INT_RenderScreenspaceEffects()
	if not GetConVar("int_enabled"):GetBool() then return end
	for k, v in pairs(integra.modules) do
		if INT_IsModEnabled(v) and v.UseRenderScreenspaceEffects then
			v:RenderScreenspaceEffects()
		end
	end
end
hook.Add("RenderScreenspaceEffects", "INT_RenderScreenspaceEffects", INT_RenderScreenspaceEffects)

local function INT_GetNearestAimingPlayer(eyepos, eyeang)
	if not INT_ValidPlayer(target) or not target:Alive() then
		local pos = {}
		local _eyepos = EyePos()
		local _eyeang = EyeAngles()
		if eyepos != nil then
			_eyepos = eyepos
		end
		if eyeang != nil then
			_eyeang = eyeang
		end
		cam.Start3D(_eyepos, _eyeang)
			for k, v in pairs(player.GetAll()) do
				if INT_ValidPlayer(v) then
					if v != LocalPlayer() and v:Alive() and v:GetBonePosition(6):Distance(EyePos()) < GetConVar("int_aimbot_maxdistance"):GetInt() then
						local headangles = (v:GetBonePosition(v:LookupBone("ValveBiped.Bip01_Head1")) - EyePos()):Angle()
						local aimangles = (LocalPlayer():GetEyeTrace().HitPos - EyePos()):Angle()
						headangles.r = 0
						aimangles.r = 0
						local angle = headangles:Forward():Distance(aimangles:Forward()) * 90
						table.insert(pos, {ent = v, dist = angle})
					end
				end
			end
		cam.End3D()
		table.SortByMember(pos, "dist")
		local ent = nil
		local min = 9999
		for i = 1, #pos do
			if INT_ValidPlayer(pos[#pos + 1  - i].ent) then
				if pos[#pos + 1- i].ent:Alive() and pos[#pos + 1- i].dist < (GetConVar("int_aimbot_angle"):GetInt()) and  pos[#pos + 1 - i].dist < min then
					min = pos[#pos + 1 - i].dist
					ent = pos[#pos + 1 - i].ent
				end
			end
		end
		return ent
	else
		return target
	end
end

// ESP Wallhack
local esp = {}
	esp.Title = "ESP Wallhack"
	esp.ConVar = "esp"
	esp.UsePaint = true
	esp.UseRenderScreenspaceEffects = true

function esp:Paint()
	if INT_GetModConfig(esp, "drawcrosshair"):GetBool() then
		if INT_ValidPlayer(LocalPlayer()) then
			local tr = LocalPlayer():GetEyeTrace()
			local pos = {}
				pos.x = ScrW() / 2
				pos.y = ScrH() / 2
			if not INT_GetModConfig(esp, "simple"):GetBool() then
				surface.SetDrawColor(Color(255, 0, 0, 255))
				local dist = (LocalPlayer():GetPos() + Vector(0, 0, 64)):Distance(tr.HitPos)
				surface.DrawOutlinedRect(pos.x - 7 - ((dist / 1000) / 2), pos.y - 7 - ((dist / 1000) / 2), 14 + (dist / 1000), 14 + (dist / 1000))
				surface.DrawOutlinedRect(pos.x - 10 - ((dist / 1000) / 2), pos.y - 10 - ((dist / 1000) / 2), 20 + (dist / 1000), 20 + (dist / 1000))
				surface.DrawLine(pos.x - 15 - (dist / 1000) - 5, pos.y, pos.x - 3, pos.y)
				surface.DrawLine(pos.x + 15 + (dist / 1000) + 5, pos.y, pos.x + 3, pos.y)
				surface.DrawLine(pos.x, pos.y - 15 - (dist / 1000) - 5, pos.x, pos.y - 3)
				surface.DrawLine(pos.x, pos.y + 15 + (dist / 1000) + 5, pos.x, pos.y + 3)
				surface.SetFont("TabLarge")
				local unit = "m"
				if dist < 320 then
					dist = (dist / 64) * 100
					unit = "cm"
				end
				if dist > 320 then
					dist = dist / 64
					unit = "m"
				end
				local text = "Distance: " .. math.Round(dist) .. unit
				local size = surface.GetTextSize(text)
				surface.SetTextPos(pos.x - (size / 2), pos.y + 15 + (dist / 1000) + 10)
				surface.SetTextColor(Color(255, 0, 0, 255))
				surface.DrawText(text)
				local velocity = math.Round(LocalPlayer():GetPos():Distance(LocalPlayer():GetPos() + LocalPlayer():GetVelocity()))
				text = "Speed: " .. math.Round((velocity / 64) * 3600 / 1000) .. "km/h" 
				size = surface.GetTextSize(text)
				surface.SetTextPos(pos.x - (size / 2), pos.y + 15 + (dist / 1000) + 22)
				surface.SetTextColor(Color(0, 255, 0, 255))
				surface.DrawText(text)
			else
				surface.SetDrawColor(Color(255, 0, 0, 255))
				local dist = (LocalPlayer():GetPos() + Vector(0, 0, 64)):Distance(tr.HitPos)
				surface.DrawOutlinedRect(pos.x - 7 - ((dist / 1000) / 2), pos.y - 7 - ((dist / 1000) / 2), 14 + (dist / 1000), 14 + (dist / 1000))
				surface.SetFont("TabLarge")
				local unit = "m"
				if dist < 320 then
					dist = (dist / 64) * 100
					unit = "cm"
				end
				if dist > 320 then
					dist = dist / 64
					unit = "m"
				end
				local text = "Distance: " .. math.Round(dist) .. unit
				local size = surface.GetTextSize(text)
				surface.SetTextPos(pos.x - (size / 2), pos.y + 15 + (dist / 1000) + 10)
				surface.SetTextColor(Color(255, 0, 0, 255))
				surface.DrawText(text)
			end
		end
	end
end

function esp:RenderScreenspaceEffects()
	if INT_GetModConfig(esp, "drawplayers"):GetBool() then
		for k, v in pairs(player.GetAll()) do
			if INT_ValidPlayer(v) and v != LocalPlayer() then
				if v:GetBonePosition(6):Distance(EyePos()) <= INT_GetModConfig(esp, "drawdistance"):GetInt() then
					local alpha = 255
					if v:GetBonePosition(6):Distance(EyePos()) > INT_GetModConfig(esp, "drawdistance"):GetInt() - (INT_GetModConfig(esp, "drawdistance"):GetInt() / 10) then
						local bound = INT_GetModConfig(esp, "drawdistance"):GetInt() - (INT_GetModConfig(esp, "drawdistance"):GetInt() - (INT_GetModConfig(esp, "drawdistance"):GetInt() / 10))
						local dist = INT_GetModConfig(esp, "drawdistance"):GetInt() - v:GetBonePosition(6):Distance(EyePos())
						alpha = (255 / bound) * dist
					end
					local pos = v:GetBonePosition(6)
						pos = pos:ToScreen()
					if aiming then
						if v == INT_GetNearestAimingPlayer(EyePos(), EyeAngles()) then
							surface.SetDrawColor(Color(0, 255, 0, 255))
							surface.DrawOutlinedRect(pos.x - 15, pos.y - 15, 30, 30)
							surface.SetDrawColor(Color(0, 255, 0, 128))
							surface.DrawOutlinedRect(pos.x - 13, pos.y - 13, 26, 26)
						end
					end
					if not INT_GetModConfig(esp, "simple"):GetBool() then
						surface.SetDrawColor(Color(255, 0, 0, 255))
						surface.DrawOutlinedRect(pos.x - 5, pos.y - 5, 10, 10)
						surface.SetDrawColor(Color(255, 0, 0, alpha / 2))
						surface.DrawRect(pos.x - 1, pos.y - 1, 2, 2)
						surface.SetFont("BudgetLabel")
						local col = Color(255, 255, 255, alpha)
						surface.SetTextColor(col)
						local text, size
						if v:Health() > 0 then
							text = "Health: "
							size = surface.GetTextSize(text .. v:Health() .. "%")
							surface.SetTextPos(pos.x - (size / 2), pos.y - 18)
							surface.DrawText(text)
							surface.SetTextColor(Color(0, 255, 0, alpha))
							surface.DrawText(v:Health() .. "%")
							surface.SetTextColor(col)
						else
							text = "Health: "
							size = surface.GetTextSize(text .. "DEAD")
							surface.SetTextPos(pos.x - (size / 2), pos.y - 18)
							surface.DrawText(text)
							surface.SetTextColor(Color(255, 0, 0, alpha))
							surface.DrawText("DEAD")
							surface.SetTextColor(col)
						end
						local wep = "Unknown"
						if v:GetActiveWeapon() != nil then
							if type(v:GetActiveWeapon()) == "Weapon" then
								if v:GetActiveWeapon() and v:GetActiveWeapon():IsValid() then
									wep = v:GetActiveWeapon():GetClass()
								end
							end
						end
						text = "Weapon: " .. wep
						size = surface.GetTextSize(text)
						surface.SetTextPos(pos.x - (size / 2), pos.y - 28)
						surface.DrawText(text)
						local distance = 0
							distance = math.Round(v:GetBonePosition(6):Distance(EyePos()))
						text = "Distance: " .. distance
						size = surface.GetTextSize(text)
						surface.SetTextPos(pos.x - (size / 2), pos.y - 38)
						surface.DrawText(text)
						surface.SetFont("ChatFont")
						if team.GetColor(v:Team()) != nil then
							col = team.GetColor(v:Team())
							col.a = alpha
						end
						local rank = ""
						if v:IsAdmin() and not v:IsSuperAdmin() then
							rank = " (Admin)"
						elseif v:IsSuperAdmin() then
							rank = " (Super Admin)"
						end
						surface.SetTextColor(col)
						text = v:Nick()
						size = surface.GetTextSize(text .. rank)
						surface.SetTextPos(pos.x - (size / 2), pos.y - 48)
						surface.DrawText(text)
						surface.SetTextColor(Color(255, 255, 255, 255))
						surface.DrawText(rank)
					else
						surface.SetFont("BudgetLabel")
						local col = Color(128, 128, 128, 255)
						if team.GetColor(v:Team()) != nil then
							col = team.GetColor(v:Team())
							col.a = alpha
						end
						local rank = ""
						if v:IsAdmin() and not v:IsSuperAdmin() then
							rank = " (Admin)"
						elseif v:IsSuperAdmin() then
							rank = " (Super Admin)"
						end
						local text = v:Nick() .. rank
						local size = surface.GetTextSize(text)
						surface.SetTextColor(col)
						surface.SetTextPos(pos.x - (size / 2), pos.y)
						surface.DrawText(v:Nick())
						surface.SetTextColor(Color(255, 255, 255, 255))
						surface.DrawText(rank)
					end
				end
			end
		end
	end
end

INT_AddModule(esp)
INT_AddModConfig(esp, "drawplayers", 1)
INT_AddModConfig(esp, "drawcrosshair", 1)
INT_AddModConfig(esp, "drawdistance", 16384)
INT_AddModConfig(esp, "simple", 0)
// End ESP Wallhack

// XRay
local types = {
	{"prop_physics", Color(255, 0, 0)},
	{"player", Color(0, 255, 0)},
	{"npc_", Color(0, 0, 255)},
	{"spawned_", Color(255, 255, 0)},
	{"printer", Color(255, 255, 0)}
}
local xray = {}
	xray.Title = "XRay"
	xray.ConVar = "xray"
	xray.UseRenderScreenspaceEffects = true
	xray.Init = function()
		xrayents = {}
		for k, v in pairs(ents.GetAll()) do
			if v != nil then
				if type(v) == "Entity" then
					if v and v:IsValid() then
						table.insert(xrayents, v)
					end
				end
			end
		end
	end
	xray.Reload = function()
		xrayents = {}
	end

local function AddXRayEntity(ent)
	if ent != nil then
		if type(ent) == "Entity" then
			if ent and ent:IsValid() then
				for _, index in pairs(types) do
					if string.match(index[1], ent:GetClass()) then
						table.insert(xrayents, ent)
						if #xrayents > INT_GetModConfig(xray, "maxents"):GetInt() then
							table.remove(xrayents, 1)
						end
					end
				end
			end
		end
	end
end

local function RemoveXRayEntity(ent)
	if ent != nil then
		if type(ent) == "Entity" then
			if ent and ent:IsValid() then
				for k, v in pairs(xrayents) do
					if v != nil then
						if v == ent then
							table.remove(xrayents, k)
						end
					else
						table.remove(xrayents, k)
					end
				end
			end
		end
	end
end

hook.Add("OnEntityCreated", "INT_AddXRayEntity", AddXRayEntity)
hook.Add("EntityRemoved", "INT_RemoveXRayEntity", function(ent)
	xrayents = {}
	for k, v in pairs(ents.GetAll()) do
		if v != nil then
			if type(v) == "Entity" then
				if v and v:IsValid() then
					AddXRayEntity(v)
				end
			end
		end
	end
end)

function xray:RenderScreenspaceEffects()
	for k, v in pairs(xrayents) do
		if v != nil then
			if type(v) == "Entity" then
				if v and v:IsValid() then
					for _, index in pairs(types) do
						if string.match(index[1], v:GetClass()) then
							local valid = true
							if v:IsPlayer() then
								if not v:Alive() then
									valid = false
								end
							end
							if valid then
								cam.Start3D(EyePos(), EyeAngles())
									cam.IgnoreZ(true)
										render.SuppressEngineLighting(true)
										if INT_GetModConfig(xray, "customcolor"):GetBool() then
											render.SetColorModulation(index[2].r / 255, index[2].g / 255, index[2].b / 255)
										end
										if INT_GetModConfig(xray, "custommaterial"):GetBool() then
											SetMaterialOverride(Material("models/shiny"))
											render.SetBlend(0.5)
										end
										v:DrawModel()
										if INT_GetModConfig(xray, "customcolor"):GetBool() then
											render.SetColorModulation(1, 1, 1)
										end
										if INT_GetModConfig(xray, "custommaterial"):GetBool() then
											SetMaterialOverride(nil)
											render.SetBlend(0)
										end
										render.SuppressEngineLighting(false)
									cam.IgnoreZ(false)
								cam.End3D()
							end
						end
					end
				else
					table.remove(xrayents, k)
				end
			else
				table.remove(xrayents, k)
			end
		else
			table.remove(xrayents, k)
		end
	end
	for k, v in pairs(player.GetAll()) do
		if v != nil then
			if INT_ValidPlayer(v) then
				if v:Alive() then
					cam.Start3D(EyePos(), EyeAngles())
						cam.IgnoreZ(true)
							render.SuppressEngineLighting(true)
							if INT_GetModConfig(xray, "customcolor"):GetBool() then
								render.SetColorModulation(0, 1, 0)
							end
							if INT_GetModConfig(xray, "custommaterial"):GetBool() then
								SetMaterialOverride(Material("models/shiny"))
								render.SetBlend(0.5)
							end
							v:DrawModel()
							if INT_GetModConfig(xray, "customcolor"):GetBool() then
								render.SetColorModulation(1, 1, 1)
							end
							if INT_GetModConfig(xray, "custommaterial"):GetBool() then
								SetMaterialOverride(nil)
								render.SetBlend(0)
							end
							render.SuppressEngineLighting(false)
						cam.IgnoreZ(false)
					cam.End3D()
				end
			end
		end
	end
end

INT_AddModule(xray)
INT_AddModConfig(xray, "customcolor", 1)
INT_AddModConfig(xray, "custommaterial", 1)
INT_AddModConfig(xray, "drawplayers", 1)
INT_AddModConfig(xray, "drawprops", 1)
INT_AddModConfig(xray, "drawnpcs", 1)
INT_AddModConfig(xray, "drawrpents", 1)
INT_AddModConfig(xray, "maxents", 50)
// End XRay

// Barrel Hack
local mat = Material("tripmine_laser")
local bh = {}
	bh.Title = "Barrel Hack"
	bh.ConVar = "barrelhack"
	bh.UseRenderScreenspaceEffects = true

function bh:RenderScreenspaceEffects()
	for k, v in pairs(player.GetAll()) do
		if INT_ValidPlayer(v) then
			if v:Alive() then
				cam.Start3D(EyePos(), EyeAngles())
					render.SetMaterial(mat)
					if v == LocalPlayer() then
						render.DrawBeam(INT_GetMuzzlePos(v), v:GetEyeTrace().HitPos, 15, 1, 1, Color(0, 255, 0, 255))
					else
						local pos = v:EyePos()
						if v:GetBonePosition(v:LookupBone("ValveBiped.Bip01_R_Hand")) != nil then
							pos = v:GetBonePosition(v:LookupBone("ValveBiped.Bip01_R_Hand"))
						end
						if INT_GetMuzzlePos(v) != v:EyePos() then
							render.DrawBeam(INT_GetMuzzlePos(v), v:GetEyeTrace().HitPos, 30, 1, 1, Color(0, 255, 0, 255))
						else
							render.DrawBeam(pos, v:GetEyeTrace().HitPos, 30, 1, 1, Color(0, 255, 0, 255))
						end
					end
				cam.End3D()
			end
		end
	end
end

INT_AddModule(bh)
// End Barrel Hack

// Aimbot
local aimbot = {}
	aimbot.Title = "Aimbot"
	aimbot.ConVar = "aimbot"
	aimbot.UseThink = true
	aimbot.UsePaint = true

function aimbot:HUDPaint()
	if INT_GetModConfig(aimbot, "drawradius"):GetBool() then
		for k, v in pairs(player.GetAll()) do
			if INT_ValidPlayer(v) then
				if v != LocalPlayer() then
					local pos = v:GetBonePosition(6):ToScreen()
					surface.SetDrawColor(Color(255, 255, 255, 128))
					surface.DrawCircle(pos.x, pos.y, GetConVar("int_aimbot_angle"):GetInt() * 2 * 3)
					surface.DrawCircle(pos.x - 1, pos.y, GetConVar("int_aimbot_angle"):GetInt() * 2 * 3)
					surface.DrawCircle(pos.x + 1, pos.y, GetConVar("int_aimbot_angle"):GetInt() * 2 * 3)
				end
			end
		end
	end
end

function aimbot:Think()
	if aiming then
		if target == nil then
			if INT_ValidPlayer(INT_GetNearestAimingPlayer(EyePos(), EyeAngles())) then
				local ply = INT_GetNearestAimingPlayer(EyePos(), EyeAngles())
				if ply:Alive() and ply != LocalPlayer() then
					target = ply
				end
			end
		else
			if INT_ValidPlayer(target) and target:Alive() then
				local angles = ((target:GetBonePosition(6) - EyePos()) + ((target:GetVelocity()) / (1000 / INT_GetModConfig(aimbot, "velocityamount"):GetInt()))):Angle()
				if mode == 1 then
					angles = (target:GetEyeTrace().HitPos() - EyePos()):Angle()
				end
				LocalPlayer():SetEyeAngles(angles)
				if INT_GetModConfig(aimbot, "autofire"):GetBool() then
					local rand = math.random(-10, 10)
					rand = rand / (EyePos():Distance(target:GetBonePosition(6)) / 10)
					LocalPlayer():SetEyeAngles(Angle(angles.p + (rand * 1), angles.y + rand, 0))
					local ent = LocalPlayer():GetEyeTrace().Entity
					if INT_ValidPlayer(ent) then
						RunConsoleCommand("+attack")
						timer.Simple(0.05, function()
							RunConsoleCommand("-attack")
						end)
					else
						RunConsoleCommand("-attack")
					end
				end
			else
				target = nil
				RunConsoleCommand("-attack")
			end
		end
	end
end

INT_AddModule(aimbot)
INT_AddModConfig(aimbot, "angle", 45)
INT_AddModConfig(aimbot, "drawradius", 0)
INT_AddModConfig(aimbot, "autofire", 1)
INT_AddModConfig(aimbot, "maxdistance", 4096)
INT_AddModConfig(aimbot, "velocityamount", 500)
concommand.Add("+int_aimbot", function()
	aiming = true
	mode = 0
end)
concommand.Add("-int_aimbot", function()
	target = nil
	aiming = false
end)
concommand.Add("+int_aimbot_barrelhack", function()
	aiming = true
	mode = 1
end)
concommand.Add("-int_aimbot_barrelhack", function()
	target = nil
	aiming = false
end)
// End Aimbot

hook.Add("PlayerConnect", "INT_ShowIP", function(name, ip)
	chat.AddText(Color(0, 255, 0), name, Color(255, 255, 255), " has connected with IP ", Color(0, 255, 0), ip, Color(255, 255, 255), "!")
end)
CreateClientConVar("int_showip", 1, true, false)

local utilEffect = util.Effect

function util.Effect(effect, data, override, recipient)
	if not GetConVar("int_noeffects"):GetBool() then
		utilEffect(effect, data, override, recipient)
	end
end

CreateClientConVar("int_noeffects", 1, true, false)

local function INT_Reload()
	for k, v in pairs(integra.modules) do
		v:Reload()
	end

	hook.Remove("RenderScreenspaceEffects", "INT_RenderScreenspaceEffects")
	hook.Remove("Think", "INT_Think")
	hook.Remove("HUDPaint", "INT_Paint")

	hook.Add("RenderScreenspaceEffects", "INT_RenderScreenspaceEffects", INT_RenderScreenspaceEffects)
	hook.Add("Think", "INT_Think", INT_Think)
	hook.Add("HUDPaint", "INT_Paint", INT_Paint)

	for k, v in pairs(integra.modules) do
		v:Init()
	end
end
concommand.Add("int_reload", INT_Reload)

local function INT_Rotate()
	local ang = EyeAngles()
	LocalPlayer():SetEyeAngles(Angle(ang.p, ang.y - 180, 0))
end
concommand.Add("int_rotate", INT_Rotate)

local usetype = 0
local function INT_UseSpam()
	if usetype == 0 then
		RunConsoleCommand("+use")
		usetype = 1
	else
		RunConsoleCommand("-use")
		usetype = 0
	end
end

local function INT_Menu()
	local Frame = IDerma.CreateDFrame()
		Frame:SetSize(600, 400)
		Frame:Center()
		Frame:SetTitle("Integra Main Menu")
		Frame:SetDraggable(false)
		Frame:SetSizable(false)
		Frame:MakePopup()
	local Sheet = vgui.Create("DPropertySheet", Frame)
		Sheet:SetSize(Frame:GetWide() - 20, Frame:GetTall() - 40)
		Sheet:SetPos(10, 30)
		Sheet:SetDrawBackground(false)
		Sheet.Paint = function(self)
			surface.SetDrawColor(Color(192, 192, 192, 128))
			surface.DrawOutlinedRect(0, 22, self:GetWide(), self:GetTall() - 22)
		end
	local ConfigPanel = IDerma.CreateDPanel(Sheet)
		Sheet:AddSheet("Configuration", ConfigPanel, "gui/silkicons/wrench", false, false, "Main Config")
end
concommand.Add("int_menu", INT_Menu)

concommand.Add("+int_usespam", function()
	timer.Create("UseSpam", 0.05, 0, INT_UseSpam)
end)

concommand.Add("-int_usespam", function()
	timer.Destroy("UseSpam")
	RunConsoleCommand("-use")
end)

CreateClientConVar("int_enabled", 1, true, false)