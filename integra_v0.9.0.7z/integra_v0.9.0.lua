--[[
	integra/integra.lua
	Cry | (STEAM_0:0:42087122)
	===DStream===
]]

/**********************
* Integra Version 0.9 *
***********************/

require('concommand')
require('hook')
require('usermessage')
require('cvar2')

local RunString = RunString
local concommand = concommand
local hook = hook
local cvar2 = cvar2 or {}
local file = file
local cam = cam
local render = render

local GConVar = GetConVar
local GConVarNum = GetConVarNumber

local blockedcvars = {
	{cvar = "host_timescale"},
	{cvar = "host_framerate"},
	{cvar = "sv_cheats"},
	{cvar = "mat_wireframe"},
	{cvar = "mat_fullbright"},
	{cvar = "int_"} // Come on anti cheats, you must have a better way then using GetConVar to detect these things.
}

/*function GetConVar(cvar)
	for k, v in pairs(blockedcvars) do
		if string.match(cvar, v.cvar) then
			return nil
		end
	end

	return GConVar(cvar)
end

function GetConVarNumber(cvar)
	for k, v in pairs(blockedcvars) do
		if string.match(cvar, v.cvar) then
			return nil
		end
	end

	return GConVarNum(cvar)
end*/

if cvar2 then
	if cvar2.SetValue then
		cvar2.SetValue("sv_cheats", "1")
	else
		MsgN("Integra Error: gm_cvar2 could not be found, bug?")
	end
end

hook.Add("InitPostEntity", "AntiCheats", function()
	if FACEnabled != nil then
		// Thought i'd just do it for fun, since that's what you made that global for flappy.
		chat.AddText(Color(255, 0, 0), "Flapadar's Anti-Cheat is active on the server. Expect a kick.")
		surface.PlaySound("buttons/button1.wav")
	end
end)

concommand.Add("int_speedamount", function(p, c, args)
	if args[1] == nil then MsgN("You need to specify a value, prefferably in range of 0.2 to 7") return end

	if cvar2 then
		if cvar2.SetValue then
			cvar2.SetValue("host_timescale", args[1])
		else
			MsgN("Integra Error: gm_cvar2 could not be found, bug?")
		end
	else
		MsgN("Integra Error: gm_cvar2 could not be found, bug?")
	end
end)

CreateClientConVar("int_enabled", 1, true, false)

concommand.Add("int_runlua", function(p, c, a)
	RunString(unpack(a))
end)

// Useful functions
hook.Add("Think", "INT_RollCorrection", function()
	// Corrects the roll angle so you don't tilt a direction with the eye
	if GConVar("int_rollcorrection"):GetBool() then
		if not LocalPlayer():InVehicle() then
			if EyeAngles().r != 0 then
				LocalPlayer():SetEyeAngles(Angle(EyeAngles().p, EyeAngles().y, 0))
			end
		end
	end
end)
CreateClientConVar("int_rollcorrection", 0, true, false)

local function ValidPlayer(ply)
	// Checks if an entity is a valid player.
	if ValidEntity(ply) then
		if type(ply) == "Player" then
			if ply:IsPlayer() then
				if ply.Nick and ply.SteamID and ply.Health then
					// Additionally, sometimes often in some spectator mode, these will get goofed and go nil for some reason.
					return true
				end
			end
		end
	end

	return false
end

local function GetHeadPos(ply)
	// Gets the head position of a player.
	local pos = Vector(0, 0, 0)

	if ValidEntity(ply) then
		pos = (ply:GetBonePosition(ply:LookupBone("ValveBiped.Bip01_Head1")) or ply:EyePos())
	end
	return pos
end

local function RotateVector(amount)
	// This will return a normalized x-y vector as to where it would be on this 2D angle, eg using angle 0 would return {x = 1, y = 0}, whereas using angle 90 would be {x = 0, y = 1}.
	local angle = amount / 180 * 3.14159
	local pos = {}
		pos.x = math.cos(angle) - math.sin(angle)
		pos.y = math.sin(angle) + math.cos(angle)
	return pos
end

local function GetMuzzlePos(ply)
	// Gets the muzzle position of the player's weapon (Returns eye position if nil).
	if not ValidPlayer(ply) then return Vector() end

	local vm = ply:GetViewModel()
	local pos = ply:EyePos()

	if ValidEntity(vm) then
		local attachId = vm:LookupAttachment("muzzle")
		if attachId == 0 then
			attachId = vm:LookupAttachment("1")
		end

		if vm:GetAttachment(attachId) != nil then
			pos = vm:GetAttachment(attachId).Pos
		end
	end

	return (pos or ply:EyePos())
end

local function ModuleEnabled(title)
	// Checks if a specific module has been int_*_enabled.
	if GConVar("int_" .. title .. "_enabled") != nil then
		if GConVar("int_" .. title .. "_enabled"):GetBool() then
			if GConVar("int_enabled"):GetBool() then
				return true
			else
				return false
			end
		else
			return false
		end
	end

	return true
end

local function InBounds(num, min, max)
	// Checks if a number is in bounds
	if num <= max and num >= min then
		return true
	else
		return false
	end
end

local function GetUserGroup(ply)
	// Checks what user group this player has, Example: admin, superadmin, guest.
	if ValidPlayer(ply) then
		if ply:IsAdmin() and not ply:IsSuperAdmin() then
			return "Admin"
		elseif ply:IsSuperAdmin() then
			return "Super Admin"
		else
			return "Player"
		end
	end
	return "Unknown"
end

local function GetModuleConfig(title, config)
	// Gets a config index for a module.
	return GConVar("int_" .. title .. "_" .. config)
end

local function AddModuleConfig(title, config, default)
	// Creates a config index for a module
	CreateClientConVar("int_" .. title .. "_" .. config, default, true, false)
end

local function AddModuleHook(title, config_enabled, default_enabled, func, htype)
	// Adds a hook to a module
	if config_enabled then
		// Optionally, if this is true, it will create the convar int_*_enabled unless it exists, and only run the hook when it's enabled.
		CreateClientConVar("int_" .. title .. "_enabled", default_enabled, true, false)
		hook.Add(htype, "INT_" .. title .. "_" .. htype, function()
			if ModuleEnabled(title) then
				func()
			end
		end)
	else
		hook.Add(htype, "INT_" .. title .. "_" .. htype, function()
			func()
		end)
	end
end

local function AddBindkeyCommand(title, func, htype, on_callback, off_callback)
	concommand.Add("+int_" .. title, function(ply, cmd, args)
		if htype == 1 then
			hook.Add("Think", "INT_BindFunc_" .. title, func)
		elseif htype == 2 then
			hook.Add("Tick", "INT_BindFunc_" .. title, func)
		end
		if on_callback then
			on_callback(args)
		end
	end)
	concommand.Add("-int_" .. title, function(ply, cmd, args)
		hook.Remove("Think", "INT_BindFunc_" .. title)
		hook.Remove("Tick", "INT_BindFunc_" .. title)
		if off_callback then
			off_callback(args)
		end
	end)
end

// Anti Motion Blur, mainly to stop the taser effect on DRP because really, it's useless.
local function AntiB_Tick()
	RunConsoleCommand("pp_motionblur", 0)
end
AddModuleHook("antiblur", true, 1, AntiB_Tick, "Tick")

// XRay Vision
local XRay_Material = Material("models/shiny")
local XRay_Entities = {}

local function XRay_EntityCreate(ent)
	if ValidEntity(ent) then
		if ent:GetClass() == "prop_physics" then
			if #XRay_Entities + 1 > GetModuleConfig("xray", "maxprops"):GetInt() then
				XRay_Entities[1] = ent
			else
				table.insert(XRay_Entities, ent)
			end
		end
	end
end

local function XRay_Render()
	if GetModuleConfig("xray", "drawprops"):GetBool() then
		cam.Start3D(EyePos(), EyeAngles())
			cam.IgnoreZ(true)
				SetMaterialOverride(XRay_Material)
					render.SetBlend(0.4)
					render.SetColorModulation(1, 0, 0)
					render.SuppressEngineLighting(true)
						for k, v in pairs(XRay_Entities) do
							if ValidEntity(v) then
								if v:GetClass() == "prop_physics" then
									v:DrawModel()
								end
							else
								table.remove(XRay_Entities, k)
							end
						end
						for k, v in pairs(ents.GetAll()) do
							if ValidEntity(v) then
								if v:GetClass() == "func_physbox" then
									render.SetBlend(1)
									render.SetColorModulation(1, 1, 1)
										v:DrawModel()
								end
							end
						end
					render.SuppressEngineLighting(false)
					render.SetBlend(1)
					render.SetColorModulation(1, 1, 1)
				SetMaterialOverride(nil)
			cam.IgnoreZ(false)
		cam.End3D()
	end

	if GetModuleConfig("xray", "drawdoors"):GetBool() then
		cam.Start3D(EyePos(), EyeAngles())
			cam.IgnoreZ(true)
				SetMaterialOverride(XRay_Material)
					render.SetBlend(0.4)
					render.SetColorModulation(1, 0, 0)
					render.SuppressEngineLighting(true)
						for k, v in pairs(ents.GetAll()) do
							if ValidEntity(v) then
								if v:GetClass() == "prop_door_rotating" or v:GetClass() == "func_door" or v:GetClass() == "func_door_rotating" then
								end
							end
						end
					render.SuppressEngineLighting(false)
					render.SetBlend(1)
					render.SetColorModulation(1, 1, 1)
				SetMaterialOverride(nil)
			cam.IgnoreZ(false)
		cam.End3D()
	end

	if GetModuleConfig("xray", "drawents"):GetBool() then
		cam.Start3D(EyePos(), EyeAngles())
			cam.IgnoreZ(true)
				SetMaterialOverride(XRay_Material)
					render.SetBlend(0.4)
					render.SetColorModulation(1, 0, 0)
					render.SuppressEngineLighting(true)
						for k, v in pairs(ents.GetAll()) do
							if ValidEntity(v) then
								if not string.match(v:GetClass(), "pcmod") then
									if string.match(v:GetClass(), "weapon") and not ValidEntity(v.Owner) then
										cam.Start2D()
											local pos = v:GetPos():ToScreen()
											draw.SimpleText("Weapon: " .. v:GetClass(), "UiBold", pos.x, pos.y, Color(255, 255, 255, 255))
										cam.End2D()
									end
									if string.match(v:GetClass(), "printer") or string.match(v:GetClass(), "spawned") then
										v:DrawModel()
									end
									if string.match(v:GetClass(), "printer") then
										cam.Start2D()
											local pos = v:GetPos()
												pos = pos:ToScreen()
											surface.SetFont("UiBold")
											local w, h = surface.GetTextSize("Money Printer (" .. v:GetClass() .. ")")
											draw.WordBox(6, pos.x - (w / 2), pos.y - (h / 2), "Money Printer (" .. v:GetClass() .. ")", "UiBold", Color(0, 0, 50, 150), Color(255, 255, 255, 255))
										cam.End2D()
									end
									if string.match(v:GetClass(), "ammo") or string.match(v:GetClass(), "crate") then
										v:DrawModel()
									end
									if string.match(v:GetClass(), "arsenalcrate") then
										v:DrawModel()
										cam.Start2D()
											local pos = v:GetPos()
												pos = pos:ToScreen()
											surface.SetFont("UiBold")
											local w, h = surface.GetTextSize("Zombie Survival Arsenal Crate")
											draw.WordBox(6, pos.x - (w / 2), pos.y - (h / 2), "Zombie Survival Arsenal Crate", "UiBold", Color(0, 50, 0, 150), Color(255, 255, 255, 255))
										cam.End2D()
									end
									if string.match(v:GetClass(), "resupplybox") then
										v:DrawModel()
										cam.Start2D()
											local pos = v:GetPos()
												pos = pos:ToScreen()
											surface.SetFont("UiBold")
											local w, h = surface.GetTextSize("Zombie Survival Resupply Box")
											draw.WordBox(6, pos.x - (w / 2), pos.y - (h / 2), "Zombie Survival Resupply Box", "UiBold", Color(0, 50, 0, 150), Color(255, 255, 255, 255))
										cam.End2D()
									end
									if string.match(v:GetClass(), "shipment") then
										if CustomShipments then
											cam.Start2D()
												local pos = v:GetPos()
													pos = pos:ToScreen()
												surface.SetFont("UiBold")
												
												local text = "Shipment"
												local w, h
												if CustomShipments != nil and v.dt != nil then
													text = "Shipment of " .. (CustomShipments[v.dt.contents].name or "Unknown") .. "x" .. v.dt.count
												end
												w, h = surface.GetTextSize(text)
												draw.WordBox(6, pos.x - (w / 2), pos.y - (h / 2), text, "UiBold", Color(50, 0, 0, 150), Color(255, 255, 255, 255))
											cam.End2D()
										end
									end
								end
							end
						end
					render.SuppressEngineLighting(false)
					render.SetBlend(1)
					render.SetColorModulation(1, 1, 1)
				SetMaterialOverride(nil)
			cam.IgnoreZ(false)
		cam.End3D()
	end

	if GetModuleConfig("xray", "drawplayers"):GetBool() then
		cam.Start3D(EyePos(), EyeAngles())
			cam.IgnoreZ(true)
				SetMaterialOverride(XRay_Material)
					render.SetBlend(0.4)
					render.SetColorModulation(0, 1, 0)
					render.SuppressEngineLighting(true)
						for k, v in pairs(player.GetAll()) do
							if ValidPlayer(v) and v != LocalPlayer() then
								if v:Alive() then
									v:DrawModel()
								end
							end
						end
					render.SuppressEngineLighting(false)
					render.SetBlend(1)
					render.SetColorModulation(1, 1, 1)
				SetMaterialOverride(nil)
			cam.IgnoreZ(false)
		cam.End3D()
	end
end

AddModuleHook("xray", true, 1, XRay_Render, "RenderScreenspaceEffects")
AddModuleConfig("xray", "drawplayers", 1)
AddModuleConfig("xray", "drawprops", 1)
AddModuleConfig("xray", "drawdoors", 1)
AddModuleConfig("xray", "drawents", 1)
AddModuleConfig("xray", "maxprops", 20)
hook.Add("OnEntityCreated", "INT_xray_OnEntityCreated", XRay_EntityCreate)

local AB_Target
local AB_PrevFiremode = 0

local function AB_GetNearestTarget()
	if ValidEntity(AB_Target) then
		return AB_Target
	end

	local aimangles = {}
	local targetents = {}
	if GetModuleConfig("aimbot", "targetplayers"):GetBool() then
		for k, v in pairs(player.GetAll()) do
			if ValidPlayer(v) then
				if not GetModuleConfig("aimbot", "targetsteamfriends"):GetBool() then
					if v:GetFriendStatus() != "friend" then
						table.insert(targetents, v)
					end
				else
					table.insert(targetents, v)
				end
			end
		end
	end

	if GetModuleConfig("aimbot", "targetnpcs"):GetBool() then
		for k, v in pairs(ents.GetAll()) do
			if ValidEntity(v) then
				if v:IsNPC() then
					table.insert(targetents, v)
				end
			end
		end
	end

	for k, v in pairs(targetents) do
		 if ValidEntity(v) and v != LocalPlayer() then
			if v:Health() > 0 or v:IsNPC() then
				if v:GetPos():Distance(EyePos()) <= GetModuleConfig("aimbot", "maxdistance"):GetInt() then
					local ang = (GetHeadPos(v) - EyePos()):Angle()
						ang.p = 0
					if not GetModuleConfig("aimbot", "targetteammates"):GetBool() then
						if not v:IsNPC() then
							if v:Team() != LocalPlayer():Team() then
								table.insert(aimangles, {ply = v, ang = ang})
							end
						else
							table.insert(aimangles, {ply = v, ang = ang})
						end
					else
						table.insert(aimangles, {ply = v, ang = ang})
					end
				end
			end
		 end
	end
	local nearest = {}
	for k, v in pairs(aimangles) do
		local ang = v.ang
		local eyeang = EyeAngles()
			eyeang.p = 0
		local dist = eyeang:Forward():Distance(ang:Forward()) * 90
		if dist <= GetModuleConfig("aimbot", "maxangle"):GetInt() then
			table.insert(nearest, {ply = v.ply, ang = dist})
		end
	end
	if #nearest <= 0 then return end
	table.SortByMember(nearest, "ang", function(a, b) return a > b end)

	local aimablenearest = {}
	for k, v in pairs(nearest) do
		local tr_data = {}
			tr_data.start = EyePos()
			tr_data.endpos = GetHeadPos(v.ply)
		local tr = util.TraceLine(tr_data)
			if ValidPlayer(tr.Entity) then
				table.insert(aimablenearest, {ply = v.ply, ang = v.ang})
			end
	end

	if #aimablenearest <= 0 then return end
	table.SortByMember(aimablenearest, "ang", function(a, b) return a > b end)
	return aimablenearest[1].ply
end

local function AB_FindNearestTarget()
	if ValidPlayer(AB_Target) then
		return
	end

	local aimangles = {}
	local targetents = {}
	if GetModuleConfig("aimbot", "targetplayers"):GetBool() then
		for k, v in pairs(player.GetAll()) do
			if ValidPlayer(v) then
				if not GetModuleConfig("aimbot", "targetsteamfriends"):GetBool() then
					if v:GetFriendStatus() != "friend" then
						table.insert(targetents, v)
					end
				else
					table.insert(targetents, v)
				end
			end
		end
	end

	if GetModuleConfig("aimbot", "targetnpcs"):GetBool() then
		for k, v in pairs(ents.GetAll()) do
			if ValidEntity(v) then
				if v:IsNPC() then
					table.insert(targetents, v)
				end
			end
		end
	end

	for k, v in pairs(targetents) do
		 if ValidEntity(v) and v != LocalPlayer() then
			if v:Health() > 0 or v:IsNPC() then
				if v:GetPos():Distance(EyePos()) <= GetModuleConfig("aimbot", "maxdistance"):GetInt() then
					local ang = (GetHeadPos(v) - EyePos()):Angle()
						ang.p = 0
					if not GetModuleConfig("aimbot", "targetteammates"):GetBool() then
						if not v:IsNPC() then
							if v:Team() != LocalPlayer():Team() then
								table.insert(aimangles, {ply = v, ang = ang})
							end
						else
							table.insert(aimangles, {ply = v, ang = ang})
						end
					else
						table.insert(aimangles, {ply = v, ang = ang})
					end
				end
			end
		 end
	end
	local nearest = {}
	for k, v in pairs(aimangles) do
		local ang = v.ang
		local eyeang = EyeAngles()
			eyeang.p = 0
		local dist = eyeang:Forward():Distance(ang:Forward()) * 90
		if dist <= GetModuleConfig("aimbot", "maxangle"):GetInt() then
			table.insert(nearest, {ply = v.ply, ang = dist})
		end
	end
	if #nearest <= 0 then return end
	table.SortByMember(nearest, "ang", function(a, b) return a > b end)

	local aimablenearest = {}
	for k, v in pairs(nearest) do
		local tr_data = {}
			tr_data.start = EyePos()
			tr_data.endpos = GetHeadPos(v.ply)
		local tr = util.TraceLine(tr_data)
			if ValidEntity(tr.Entity) then
				table.insert(aimablenearest, {ply = v.ply, ang = v.ang})
			end
	end

	if #aimablenearest <= 0 then return end
	table.SortByMember(aimablenearest, "ang", function(a, b) return a > b end)
	AB_Target = aimablenearest[1].ply
end

local function AB_Think()
	local ValidTarget = false
	if ValidEntity(AB_Target) then
		if AB_Target:Health() > 0 or AB_Target:IsNPC() then
			local tr_data = {}
				tr_data.start = EyePos()
				tr_data.endpos = GetHeadPos(AB_Target)
			local tr = util.TraceLine(tr_data)
				if ValidEntity(tr.Entity) then
					if tr.Entity:IsPlayer() or tr.Entity:IsNPC() then
						ValidTarget = true
					end
				end
		else
			AB_Target = nil
		end
	end
	if ValidTarget then
		local pos = GetHeadPos(AB_Target)
		if GetModuleConfig("aimbot", "velocitypredict"):GetBool() then
			local amt = GetModuleConfig("aimbot", "velocitypredict"):GetFloat() * 6
			if amt > 0 then
				local addamt = 1
				if GetModuleConfig("aimbot", "velocitypredict_speedhack"):GetBool() then
					addamt = GConVar("host_timescale"):GetInt()
				end
				pos = pos + ((AB_Target:GetVelocity() / 1000) * amt) - (((LocalPlayer():GetVelocity() * addamt) / 500) * amt)
			end
		end
		local ang = (pos - EyePos()):Angle()
		LocalPlayer():SetEyeAngles(ang)
		if GetModuleConfig("aimbot", "autofire"):GetBool() then
			if AB_PrevFiremode == 0 then
				RunConsoleCommand("+attack")
				AB_PrevFiremode = 1
			else
				RunConsoleCommand("-attack")
				AB_PrevFiremode = 0
			end
		end
	else
		RunConsoleCommand("-attack")
		AB_FindNearestTarget()
	end
end

AddBindkeyCommand("aimbot", AB_Think, 1, nil, function() RunConsoleCommand("-attack") AB_Target = nil AB_PrevFiremode = 0 end)
AddModuleConfig("aimbot", "autofire", 1)
AddModuleConfig("aimbot", "velocitypredict", 1)
AddModuleConfig("aimbot", "velocitypredict_speedhack", 1)
AddModuleConfig("aimbot", "targetnpcs", 1)
AddModuleConfig("aimbot", "targetplayers", 1)
AddModuleConfig("aimbot", "targetsteamfriends", 0)
AddModuleConfig("aimbot", "targetteammates", 1)
AddModuleConfig("aimbot", "maxangle", 360)
AddModuleConfig("aimbot", "maxdistance", 16384)

// ESP (Wallhack)
local ESP_PlayerData = {}
local ESP_Target

local function ESP_Draw()
	if GetModuleConfig("esp", "blockpostproccessing") then
		DrawColorModify = function() end
	end
	cam.Start3D(EyePos(), EyeAngles())
		cam.Start2D()
			for k, v in pairs(ESP_PlayerData) do
				local name = v.Name
				local rank = " (" .. v.Rank .. ")"
					if v.Rank == "Player" or v.Rank == "Unknown" then rank = "" end
				local pos = v.HeadPos
				local vars = v.Vars
					pos = pos:ToScreen()
				
				local ypos = pos.y - 18
				if GetModuleConfig("esp", "drawplayerinfo"):GetBool() then
					ypos = ypos - 10 - (#vars * 10)
				end

				surface.SetFont("Trebuchet18")
				if GetModuleConfig("esp", "outlinedtext"):GetBool() then
					draw.SimpleTextOutlined(name, "Trebuchet18", pos.x - (surface.GetTextSize(name .. rank) / 2), ypos, Color(205, 91, 69, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP, 1, Color(0, 0, 0, 255))
					draw.SimpleTextOutlined(rank, "Trebuchet18", pos.x - (surface.GetTextSize(name .. rank) / 2) + surface.GetTextSize(name), ypos, Color(198, 226, 255, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP, 1, Color(0, 0, 0, 255))
				else
					draw.SimpleText(name, "Trebuchet18", pos.x - (surface.GetTextSize(name .. rank) / 2), ypos, Color(205, 91, 69, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
					draw.SimpleText(rank, "Trebuchet18", pos.x - (surface.GetTextSize(name .. rank) / 2) + surface.GetTextSize(name), ypos, Color(198, 226, 255, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
				end
				if GetModuleConfig("esp", "drawplayerinfo"):GetBool() then
					surface.SetFont("UiBold")
					for k, v in pairs(vars) do
						local key = v[1]
						local value = v[2]
						if GetModuleConfig("esp", "outlinedtext"):GetBool() then
							draw.SimpleText(key .. ": ", "UiBold", pos.x - (surface.GetTextSize(key .. ": " .. value) / 2), ypos + 8 + (k * 10), Color(255, 255, 255, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
							draw.SimpleTextOutlined(value, "UiBold", pos.x - (surface.GetTextSize(key .. ": " .. value) / 2) + surface.GetTextSize(key .. ": "), ypos + 8 + (k * 10), Color(198, 226, 255, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP, 1, Color(0, 0, 0, 128))
						else
							draw.SimpleText(key .. ": ", "UiBold", pos.x - (surface.GetTextSize(key .. ": " .. value) / 2), ypos + 8 + (k * 10), Color(255, 255, 255, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
							draw.SimpleText(value, "UiBold", pos.x - (surface.GetTextSize(key .. ": " .. value) / 2) + surface.GetTextSize(key .. ": "), ypos + 8 + (k * 10), Color(198, 226, 255, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
						end
					end
				end
			end
			if GetModuleConfig("esp", "drawcrosshair"):GetBool() then
				local aimbot = false
				local pos = LocalPlayer():GetEyeTrace().HitPos
					if GetModuleConfig("esp", "drawaimbot"):GetBool() then
						if ValidEntity(ESP_Target) then
							pos = GetHeadPos(ESP_Target)
							aimbot = true
						else
							aimbot = false
						end
					else
						aimbot = false
					end

				local dist = math.Round(EyePos():Distance(pos))
					pos = pos:ToScreen()
				if aimbot then
					local angle = CurTime() * 200
					surface.SetDrawColor(Color(255, 0, 0, 192))
					surface.DrawLine(pos.x - (RotateVector(angle).x * 15), pos.y - (RotateVector(angle).y * 15), pos.x - (RotateVector(angle).x * 5), pos.y - (RotateVector(angle).y * 5))
					surface.DrawLine(pos.x - (RotateVector(angle + 90).x * 15), pos.y - (RotateVector(angle + 90).y * 15), pos.x - (RotateVector(angle + 90).x * 5), pos.y - (RotateVector(angle + 90).y * 5))
					surface.DrawLine(pos.x - (RotateVector(angle + 180).x * 15), pos.y - (RotateVector(angle + 180).y * 15), pos.x - (RotateVector(angle + 180).x * 5), pos.y - (RotateVector(angle + 180).y * 5))
					surface.DrawLine(pos.x - (RotateVector(angle + 270).x * 15), pos.y - (RotateVector(angle + 270).y * 15), pos.x - (RotateVector(angle + 270).x * 5), pos.y - (RotateVector(angle + 270).y * 5))
				end

				pos = LocalPlayer():GetEyeTrace().HitPos
					pos = pos:ToScreen()
				surface.SetDrawColor(Color(255, 0, 0, 192))
				surface.DrawLine(pos.x - 15 - (dist / 1000), pos.y, pos.x - 5 - (dist / 1000), pos.y)
				surface.DrawLine(pos.x + 15 + (dist / 1000), pos.y, pos.x + 5 + (dist / 1000), pos.y)
				surface.DrawLine(pos.x, pos.y - 15 - (dist / 1000), pos.x, pos.y - 5 - (dist / 1000))
				surface.DrawLine(pos.x, pos.y + 15 + (dist / 1000), pos.x, pos.y + 5 + (dist / 1000))
		end
		cam.End2D()
	cam.End3D()
end

local function ESP_Think()
	hook.Remove("RenderScreenspaceEffects", "DeathColours")
	hook.Remove("RenderScreenspaceEffects", "DrawNewTeamEffect")
	// Using "Think" instead of directly in the HUDPaint for this reduces the frames from pausing (Low FPS) due to the calculations slowing it.
	for k, v in pairs(player.GetAll()) do
		if ValidPlayer(v) and v != LocalPlayer() then
			local data = {}
				data.Entity = v
				data.Name = v:Nick()
				data.Rank = GetUserGroup(v)
				data.HeadPos = GetHeadPos(v)
				data.Vars = {}

					local health = v:Health() .. "%"
					if v:Health() <= 0 then health = "DEAD" end
					table.insert(data.Vars, {"Health", health})

					table.insert(data.Vars, {"Distance", math.Round(data.HeadPos:Distance(EyePos()))})

					local weapon = "Unknown"
					if ValidEntity(v:GetActiveWeapon()) then weapon = v:GetActiveWeapon():GetPrintName() or v:GetActiveWeapon():GetClass() end
					table.insert(data.Vars, {"Weapon", weapon})
				ESP_PlayerData[v:UserID()] = data
		end
	end
	for k, v in pairs(ESP_PlayerData) do
		if not ValidPlayer(v.Entity) or v.Entity == nil then
			table.remove(ESP_PlayerData, k)
			ESP_PlayerData[k] = nil
		end
	end
end

local function ESP_Tick()
	if GetModuleConfig("esp", "drawaimbot"):GetBool() then
		ESP_Target = AB_GetNearestTarget()
	end
end

AddModuleHook("esp", true, 1, ESP_Draw, "HUDPaint")
AddModuleHook("esp", true, 1, ESP_Think, "Think")
AddModuleHook("esp", true, 1, ESP_Tick, "Tick")
AddModuleConfig("esp", "blockpostproccessing", 1)
AddModuleConfig("esp", "drawaimbot", 1)
AddModuleConfig("esp", "drawcrosshair", 1)
AddModuleConfig("esp", "drawplayerinfo", 1)
AddModuleConfig("esp", "outlinedtext", 1)
AddModuleConfig("esp", "headbox", 1)

// Barrelhack
local BH_Material = Material("effects/laser1")
local BH_Material_NOZ = Material("effects/laser1_noz")
local BH_Target

local function BH_Render()
	cam.Start3D(EyePos(), EyeAngles())
		for k, v in pairs(player.GetAll()) do
			if ValidPlayer(v) then
				render.SetMaterial(BH_Material)
				if GetModuleConfig("barrelhack", "drawaimbot"):GetBool() and v == LocalPlayer() then
					local pos = LocalPlayer():GetEyeTrace().HitPos
						if ValidEntity(ESP_Target) then
							pos = GetHeadPos(ESP_Target)
							aimbot = true
						else
							aimbot = false
						end
					if ValidEntity(ESP_Target) then
						render.DrawBeam(GetMuzzlePos(v), pos, 20, 1, 1, Color(0, 255, 0, 255))
					end
				else
					if GetModuleConfig("barrelhack", "playeraim"):GetBool() and v != LocalPlayer() then
						render.DrawBeam(GetMuzzlePos(v), v:GetEyeTrace().HitPos, 20, 1, 1, Color(255, 0, 0, 255))
					end
				end

				if GetModuleConfig("barrelhack", "headlaser"):GetBool() and v != LocalPlayer() then
					render.SetMaterial(BH_Material_NOZ)

					local tr = util.TraceLine({start = v:EyePos(), endpos = v:EyePos() + Vector(0, 0, 100000), filter = v})
					render.DrawBeam(v:EyePos(), tr.HitPos, 10, 1, 1, Color(0, 255, 0, 255))

					tr = util.TraceLine({start = v:EyePos(), endpos = v:EyePos() - Vector(0, 0, 100000), filter = v})
					render.DrawBeam(v:EyePos(), tr.HitPos, 10, 1, 1, Color(0, 255, 0, 255))
				end
			end
		end
	cam.End3D()
end

AddModuleHook("barrelhack", true, 1, BH_Render, "RenderScreenspaceEffects")
AddModuleConfig("barrelhack", "headlaser", 1)
AddModuleConfig("barrelhack", "playeraim", 1)
AddModuleConfig("barrelhack", "drawaimbot", 1)

local umh = usermessage.Hook
function usermessage.Hook(name, func)
	if name != "ulx_blind" then
		umh(name, func)
	end
end

local function AG_Think()
	if LocalPlayer():GetNWBool("Muted") then
		LocalPlayer():SetNWBool("Muted", false)
	end

	hook.Remove("PlayerBindPress", "ULXGagForce")
	timer.Destroy("GagLocalPlayer")

	if LocalPlayer():GetNWBool("EV_Blinded") then
		LocalPlayer():SetNWBool("EV_Blinded", false)
	end
end
AddModuleHook("antigag", true, 1, AG_Think, "Think")

// Rotate
concommand.Add("int_rotate", function() LocalPlayer():SetEyeAngles(EyeAngles() - Angle(0, 180, 0)) end)

// Bunnyhop
local function BunnyHop()
	if LocalPlayer():IsOnGround() then
		RunConsoleCommand("+jump")
	else
		RunConsoleCommand("-jump")
	end
end
AddBindkeyCommand("bhop", BunnyHop, 1, nil, function() RunConsoleCommand("-jump") end)

// Bind-key command spammer
local CS_On = false
local CS_Commands = {"attack"}

local function CS_Tick()
	if CS_On then
		for k, v in pairs(CS_Commands) do
			if v != "109" then
				RunConsoleCommand("-" .. v)
			end
		end
		CS_On = false
	else
		for k, v in pairs(CS_Commands) do
			if v != "109" then
				RunConsoleCommand("+" .. v)
			end
		end
		CS_On = true
	end
end
AddBindkeyCommand("commandspam", CS_Tick, 2, function(args) if args != nil then table.Empty(CS_Commands) CS_Commands = args end end, function(args) for k, v in pairs(CS_Commands) do RunConsoleCommand("-" .. v) end CS_Commands = {"attack"} end)

local SA_Text = ""
local function SA_Tick()
	for k, v in pairs(player.GetAll()) do
		if ValidPlayer(v) then
			if GetModuleConfig("spamall", "telladmins"):GetBool() then
				RunConsoleCommand("Fadmin", "message", v:Nick(), math.Round(math.random(1, 5)), string.Replace(SA_Text, "109", ""))
			else
				if not v:IsAdmin() then
					RunConsoleCommand("Fadmin", "message", v:Nick(), math.Round(math.random(1, 5)), string.Replace(SA_Text, "109", ""))
				end
			end
		end
	end
end
AddBindkeyCommand("spamall", SA_Tick, 2, function(args) hook.Remove("HUDPaint", "FAdin_MessagePaint") SA_Text = table.concat(args, " ") end, nil)
AddModuleConfig("spamall", "telladmins", 1)


// Door Spam
local DS_On = false

local function DS_Tick()
	if DS_On then
		RunConsoleCommand("+attack")
		DS_On = false
	else
		RunConsoleCommand("-attack")
		RunConsoleCommand("undo")
		DS_On = true
	end
end
AddBindkeyCommand("doorspam", DS_Tick, 2, nil, function(args) RunConsoleCommand("-attack") end)

// Flashlight spammer
local active = false
local function LS_Tick()
	RunConsoleCommand("impulse", "100")
	active = not active
end

AddBindkeyCommand("lightspam", LS_Tick, 2, nil, function() if active then RunConsoleCommand("impulse", "100") end end)

// IP Displays
hook.Add("PlayerConnect", "INT_Common_IPDisplay", function(name, ip)
	if GConVar("int_showip"):GetBool() then
		chat.AddText(Color(0, 255, 0), name, Color(255, 255, 255), " has joined the game with IP ", Color(0, 255, 0), ip, Color(255, 255, 255), "!")
	end
end)
CreateClientConVar("int_showip", 1, true, false)

local targetply
local proppos

local function DrawPhysBeam()
	if ValidPlayer(targetply) then
		/* Copied from FPP, Umad Falco? :D */
			local w, h = surface.GetTextSize(targetply:Nick())
			local col = Color(255, 0, 0, 255)
			draw.RoundedBox(4, 0, ScrH()/2 - h, w + 28, 16, Color(50,50,50,100))
			draw.DrawText(targetply:Nick(), "Default", 24, ScrH() / 2 - h, col, 0) 
		/* End of stolen Lua */

		local EData = EffectData()
			EData:SetStart(proppos)
			EData:SetOrigin(proppos)
			EData:SetScale(1)
		util.Effect("WheelDust", EData)
	end
end
hook.Add("RenderScreenspaceEffects", "INT_FramePlayerRender", DrawPhysBeam)

local function FramePlayer(ply)
	local ang = ply:EyeAngles()
	proppos = ply:GetEyeTrace().HitPos - (ply:EyeAngles():Up() * 90) + Vector(0, 0, 30)

	local ent = ents.Create("prop_physics")
		ent:SetPos(proppos + Vector(0, 0, 64))
		ent:SetAngles(ang + Angle(10, 25, 0))
		ent:SetModel("models/props_lab/blastdoor001c.mdl")
		ent:Spawn()
		ent:Activate()
		targetply = ply

	timer.Simple(2, function()
		ent:Remove()
		targetply = nil
	end)
end

concommand.Add("int_frameplayer", function(p, c, args)
	for k, v in pairs(player.GetAll()) do
		if ValidPlayer(v) then
			local nick = v:Nick()
			local text = args[1]
			if string.match(string.lower(nick), string.lower(text)) then
				FramePlayer(v)
				break
			end
		end
	end
end)

local function NoSpread()
	if GConVar("int_nospread"):GetBool() and LocalPlayer().GetActiveWeapon != nil then
		local wep = LocalPlayer():GetActiveWeapon()
			if ValidEntity(wep) then
				if wep.data then
					wep.data.Recoil = 0
					wep.data.Cone = 0
					wep.data.Spread = 0
				end
				if wep.Primary then
					wep.Primary.Recoil = 0
					wep.Primary.Cone = 0
					wep.Primary.Spread = 0
				end
			end
	end
end
CreateClientConVar("int_nospread", 1, true, false)
hook.Add("Tick", "INT_NoSpread", NoSpread)

// Add Numpad bindkeys, this will bypass anti-numpad scripts mainly used to prevent Fading Door Abuse.
AddBindkeyCommand("gm_special", nil, 0, function(args) RunConsoleCommand("+gm_special", args[1]) end, function(args) RunConsoleCommand("-gm_special", args[1]) end)

local aims = {}
local aim_c = 0
local aim_active = false

local function TraceAim()
	if aim_active then
		aim_c = aim_c + 1
		if aim_c >= 2 then
			aim_c = 0
			table.insert(aims, {EyePos(), LocalPlayer():GetEyeTrace().HitPos, ValidEntity(LocalPlayer():GetEyeTrace().Entity)})
		end
	end
	cam.Start3D(EyePos(), EyeAngles())
		for k, v in pairs(aims) do
			render.SetMaterial(BH_Material)
			if v[3] then
				render.DrawBeam(v[1], v[2], 10, 1, 1, Color(0, 255, 0, 255))
			else
				render.DrawBeam(v[1], v[2], 10, 1, 1, Color(255, 204, 0, 255))
			end
		end
	cam.End3D()
end

AddBindkeyCommand("traceaim", nil, 0, function() hook.Add("RenderScreenspaceEffects", "AimTrace_RSE", TraceAim) aim_active = true aims = {} aim_c = 0 end, function() aim_active = false end)

local function INT_Reload()
	for k, v in pairs(integra.modules) do
		v:Reload()
	end

	hook.Remove("RenderScreenspaceEffects", "INT_RenderScreenspaceEffects")
	hook.Remove("Think", "INT_Think")
	hook.Remove("HUDPaint", "INT_Paint")

	hook.Add("RenderScreenspaceEffects", "INT_RenderScreenspaceEffects", INT_RenderScreenspaceEffects)
	hook.Add("Think", "INT_Think", INT_Think)
	hook.Add("HUDPaint", "INT_Paint", INT_Paint)

	for k, v in pairs(integra.modules) do
		v:Init()
	end
end
concommand.Add("int_reload", INT_Reload)











// Integra Initialization Messages
Msg("Integra initialized, Version 0.9\n")
Msg("Made by Anthr4X (Anthr4x292) 2011-2012\n")
Msg("Integra: Garry's Mod Wallhack, Scripts Pack\n")