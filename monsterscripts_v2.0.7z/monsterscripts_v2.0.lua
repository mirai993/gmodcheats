--[[
	monster.lua
	Jesse Jackson | (STEAM_0:1:43732934)
	===DStream===
]]

--[[
	autorun/client/MonsterHacks.lua
	KBz | Monster
	===Begin Stream===
]]

/*     Monster Wallhack     */
/*       By Monster         */
/*     Steam: amokov_sf     */
/*     Send me suggestions  */

local table = table
local concommand = concommand
local timer = timer
local hook = hook
local toggle = true

local M = {} -- So I can define shit and keep it clientside

M.ConcommandAdd = concommand.Add

local function distance(v)
   return LocalPlayer():GetPos():Distance(v:GetPos()) -- A few convienince locals
end




local advert = CreateClientConVar("M_Advert", 0, false, false)-------------------- ESP ConVars
local traitormode = CreateClientConVar("M_Traitor_Detect", 1, false, false)------- List: advert, traitormode, 
local showhealth = CreateClientConVar("MESP_Health", 1, false, false)------------- showhealth, showcorpse, showc4
local showcorpse = CreateClientConVar("MESP_Corpse", 1, false, false)------------- showdistance, tttents, drawdisitance
local showc4 = CreateClientConVar("MESP_C4", 1, false, false)--------------------- 
local showdistance = CreateClientConVar("MESP_Distance", 1, false, false)--------- The var names should make it easy to 
local tttents = CreateClientConVar("MESP_TTTEntities", 1, false, false)----------- see what var does what
local drawdistance = CreateClientConVar("MESP_DrawDistance", 1500, false, false)--


local gmod_GetWeapons = _R.Player.GetWeapons
traitors = {}
local foundweps = {}
local cleared = false
function M.CheckTraitors() -- Base code taken from faphack
   if not GAMEMODE or not GAMEMODE.Name or not string.find(GAMEMODE.Name , "Trouble in Terror") then return end
   if #traitors == (#player.GetAll()* 0.25) then return end -- No need to keep finding after all traitors are found.
   if traitormode:GetBool() == true then 
      for k, ply in pairs(player.GetAll()) do
         if ply != LocalPlayer() then
            for _, wep in pairs(gmod_GetWeapons(ply)) do
               if type(wep.CanBuy) == "table" and not table.HasValue(traitors, ply) and not table.HasValue(foundweps, wep) and GetRoundState() == 3 then
                  if !ply:IsDetective() then
                     chat.AddText(Color(50, 205, 50), "[MonsterScripts]: "..ply:Nick().." has collected a "..wep:GetClass(),  Color(235 , 235 , 235))
                     table.insert(traitors, k, ply)
                     table.insert(foundweps, wep)
                     cleared = false
                  if advert:GetBool() then
                    RunConsoleCommand("say", ply:Nick().." is a Traitor, Add me on steam for my hack.")
                  end
                  elseif ply:IsDetective() then -- Makes teleporters better protected
                     table.insert(foundweps, wep)
                     if table.HasValue(traitors, ply) then
                        table.remove(traitors, k) -- Fixes an odd bug where detectives register as traitors first round in server.
                     end
                  end
               end
            end
         end
         if table.HasValue(traitors, ply) and (ply:Health() == 0 or ply:Health() < 0 or ply:Team() == 1002) then
            chat.AddText(Color(50 , 205 , 50) , "[MonsterScripts]: A traitor has died.")
            for a , b in pairs(traitors) do
               if b == ply then
                  traitors[a] = nil
               end
            end
         end
      end
      if GetRoundState() == 4 then
         traitors = {}
         foundweps = {}
      end
   end
end

hook.Add("Think", "FindTraitors", M.CheckTraitors)



-- ESP
timer.Simple(3, function()
print("\nMonster Scripts loaded\nCredits to Flapadar, I use a few of his functions\n") 
if string.find(GAMEMODE.Name, "Trouble in") then
   M.ConcommandAdd("+trace", function()-- For the easy toggle

      hook.Add("HUDPaint", "TTTWall", function()
         Position = nil
         pos = nil
         posex = nil
         POS = nil

         for k, v in pairs ( ents.GetAll() ) do
            if v:IsValid() and distance(v) <= drawdistance:GetInt() then
               if v:IsPlayer() then
                  local Position = ( v:GetPos() + Vector(0,0,42)):ToScreen()
                  local Name = ""
                  local dis = math.Round(LocalPlayer():GetPos():Distance(v:GetPos()))

                  if traitormode:GetBool() == true then
                     if v:IsValid() and table.HasValue(traitors, v) then
                        v:SetColor(255,0,0,255)
                     elseif v:IsValid() and v:IsDetective() then
                        v:SetColor(0,0,255,255)
                     else
                        v:SetColor(0,255,0,255)
                     end
                  elseif traitormode:GetBool() == false then
                     v:SetColor(0,255,0,255)
                  end


                  v:SetMaterial("MonsterMats/player")

                  if v == LocalPlayer() or v:Team() == 1002 then Name = "" else Name = v:Name() end

                  if v:Team() != 1002 then
                     draw.DrawText( Name, "DefaultLarge", Position.x, Position.y, Color(255,255,255,255), 1 )
                  end

                  if v == LocalPlayer() or v:Team() == 1002 or v:Health() <= 0 then hp = nil else hp = v:Health() end

                  local POS = (v:GetPos() + Vector(0,0,100)):ToScreen()
                  if showhealth:GetBool() == true then
                     if hp != nil and v:IsDetective() != nil then
                        if v:IsValid() and table.HasValue(traitors, v) then
                           draw.DrawText( "HEALTH: "..hp, "DefaultLarge", POS.x, (POS.y), Color(255,0,0,255), 1 )
                        elseif v:IsValid() and v:IsDetective() then
                           draw.DrawText( "HEALTH: "..hp, "DefaultLarge", POS.x, (POS.y), Color(0,0,255,255), 1 )
                        else
                           draw.DrawText( "HEALTH: "..hp, "DefaultLarge", POS.x, (POS.y), Color(0,255,0,255), 1 )
                        end
                     end
                  end

                  if showdistance:GetBool() == true and dis != nil and v:Team() != 1002 and v != LocalPlayer() and v:IsDetective() != nil then
                     dispos = v:GetPos():ToScreen()
                     if table.HasValue(traitors, v) then
                        draw.DrawText( dis, "DefaultLarge", dispos.x, dispos.y, Color(255,0,0,255), 1 )
                     elseif v:IsDetective() then
                        draw.DrawText( dis, "DefaultLarge", dispos.x, dispos.y, Color(0,0,255,255), 1 )
                     else
                        draw.DrawText( dis, "DefaultLarge", dispos.x, dispos.y, Color(0,255,0,255), 1 )
                     end
                  end
               else
                  if showcorpse:GetBool() == true then
                     if v:GetClass() == "prop_ragdoll" then
                        pos = v:GetPos():ToScreen()
                     
                        CORPSE = CORPSE or {}
                        CORPSE.dti = {BOOL_FOUND = 0, ENT_PLAYER = 0, INT_CREDITS = 0}
                        local dti = CORPSE.dti

                        if (!v:GetDTBool(dti.BOOL_FOUND) or v:GetDTInt(dti.INT_CREDITS) != 0) and (v:GetDTEntity(ENT_PLAYER)):IsPlayer() then
                           ent = v:GetDTEntity(ENT_PLAYER)
                           draw.DrawText( ent:Nick(), "TargetID", pos.x, (pos.y+5), Color( 255, 255, 0, 255 ), 1 )
                           if v:GetDTInt(dti.INT_CREDITS) != 0 then
                              draw.DrawText(v:GetDTInt(dti.INT_CREDITS).." credits", "DefaultLarge", pos.x, (pos.y+25), Color( 255, 255, 0, 255 ), 1 )
                           end
                           v:SetMaterial("monstermats/player")
                        else
                           v:SetMaterial()
                        end
                     end
                  end

                     if tttents:GetBool() == true then
                        if string.find(v:GetClass(), "ttt") then
                           if !v:IsWeapon() then
                              v:SetMaterial("monstermats/player")
                              v:SetColor(255,255,0,255)
                           end
                        end
                        if v:IsWeapon() then
                           v:SetMaterial("monstermats/player")
                           v:SetColor(255,0,150,255)
                        end
                     end

                  if showc4:GetBool() == true then
                     if !v:IsWeapon() and string.find(v:GetClass(), "c4") then
                        v:SetMaterial("monstermats/player")
                        v:SetColor(0,255,255,255)
                        local pos = v:GetPos():ToScreen()
                        draw.DrawText( "C4", "TargetID", pos.x, (pos.y+5), Color( 0, 255, 255, 255 ), 1 )
                     end
                  end

               end
            end
         end
      end)
   end)


   M.ConcommandAdd("-trace", function()
   hook.Remove("HUDPaint", "TTTWall")
      for k, v in pairs(ents.GetAll()) do
         if v:IsValid() then
            v:SetMaterial()
            v:SetColor(255,255,255,255)
         end
      end
   end)

   M.ConcommandAdd("MESP_Toggle", function() --Toggle command
      if toggle then
         hook.Add("HUDPaint", "TTTWall", function()
            Position = nil
            pos = nil
            posex = nil
            POS = nil

            for k, v in pairs ( ents.GetAll() ) do
               if distance(v) <= drawdistance:GetInt() then
                  if v:IsPlayer() then
                     local Position = ( v:GetPos() + Vector(0,0,42)):ToScreen()
                     local Name = ""
                     local dis = math.Round(LocalPlayer():GetPos():Distance(v:GetPos()))

                     v:SetMaterial("MonsterMats/player")

                     if v == LocalPlayer() or v:Team() == 1002 then Name = "" else Name = v:Name() end

                     if v:Team() != 1002 then
                        draw.DrawText( Name, "DefaultLarge", Position.x, Position.y, Color(255,255,255,255), 1 )
                     end

                     if traitormode:GetBool() == true then
                        if v:IsValid() and table.HasValue(traitors, v) then
                           v:SetColor(255,0,0,255)
                        elseif v:IsValid() and v:IsDetective() then
                           v:SetColor(0,0,255,255)
                        else
                           v:SetColor(0,255,0,255)
                        end
                     elseif traitormode:GetBool() == false then
                        v:SetColor(0,255,0,255)
                     end

                     if v == LocalPlayer() or v:Team() == 1002 or v:Health() <= 0 then hp = nil else hp = v:Health() end

                     local POS = (v:GetPos() + Vector(0,0,100)):ToScreen()
                     if showhealth:GetBool() == true then
                        if hp != nil and v:IsDetective() != nil then
                           if v:IsValid() and table.HasValue(traitors, v) then
                              draw.DrawText( "HEALTH: "..hp, "DefaultLarge", POS.x, (POS.y), Color(255,0,0,255), 1 )
                           elseif v:IsValid() and v:IsDetective() then
                              draw.DrawText( "HEALTH: "..hp, "DefaultLarge", POS.x, (POS.y), Color(0,0,255,255), 1 )
                           else
                              draw.DrawText( "HEALTH: "..hp, "DefaultLarge", POS.x, (POS.y), Color(0,255,0,255), 1 )
                           end
                        end
                     end

                     if showdistance:GetBool() == true and dis != nil and v:Team() != 1002 and v != LocalPlayer() and v:IsDetective() != nil then
                        dispos = v:GetPos():ToScreen()
                        if table.HasValue(traitors, v) then
                           draw.DrawText( dis, "DefaultLarge", dispos.x, dispos.y, Color(255,0,0,255), 1 )
                        elseif v:IsDetective() then
                           draw.DrawText( dis, "DefaultLarge", dispos.x, dispos.y, Color(0,0,255,255), 1 )
                        else
                           draw.DrawText( dis, "DefaultLarge", dispos.x, dispos.y, Color(0,255,0,255), 1 )
                        end
                     end
                  else
                        if showcorpse:GetBool() == true then
                           if v:IsValid() and v:GetClass() == "prop_ragdoll" then
                              pos = v:GetPos():ToScreen()
                           
                              CORPSE = CORPSE or {}
                              CORPSE.dti = {BOOL_FOUND = 0, ENT_PLAYER = 0, INT_CREDITS = 0}
                              local dti = CORPSE.dti

                              if (!v:GetDTBool(dti.BOOL_FOUND) or v:GetDTInt(dti.INT_CREDITS) != 0) and (v:GetDTEntity(ENT_PLAYER)):IsPlayer() then
                                 ent = v:GetDTEntity(ENT_PLAYER)
                                 draw.DrawText( ent:Nick(), "TargetID", pos.x, (pos.y+5), Color( 255, 255, 0, 255 ), 1 )
                                 if v:GetDTInt(dti.INT_CREDITS) != 0 then
                                    draw.DrawText(v:GetDTInt(dti.INT_CREDITS).." credits", "DefaultLarge", pos.x, (pos.y+25), Color( 255, 255, 0, 255 ), 1 )
                                 end
                                 v:SetMaterial("monstermats/player")
                              else
                                 v:SetMaterial()
                              end
                           end
                        end

                     if tttents:GetBool() == true then
                        if v:IsValid() and string.find(v:GetClass(), "ttt") then
                           if !v:IsWeapon() then
                              v:SetMaterial("monstermats/player")
                              v:SetColor(255,255,0,255)
                           end
                        end
                        if v:IsWeapon() then
                           v:SetMaterial("monstermats/player")
                           v:SetColor(255,0,150,255)
                        end
                     end

                     if showc4:GetBool() == true then
                        if v:IsValid() and !v:IsWeapon() and string.find(v:GetClass(), "c4") then
                           v:SetMaterial("monstermats/player")
                           v:SetColor(0,255,255,255)
                           local pos = v:GetPos():ToScreen()
                           draw.DrawText( "C4", "TargetID", pos.x, (pos.y+5), Color( 0, 255, 255, 255 ), 1 )
                        end
                     end
                  end
               end
            end
         end)
         toggle = not toggle
      else
         hook.Remove("HUDPaint", "TTTWall")
         for k, v in pairs(ents.GetAll()) do
            if v:IsValid() then
               v:SetMaterial()
               v:SetColor(255,255,255,255)
            end
         end
         toggle = not toggle
      end
   end)
else
   M.ConcommandAdd("+trace", function()-- Easy swap command(s)

      hook.Add("HUDPaint", "OtherWall", function()
         Position = nil
         pos = nil
         posex = nil
         POS = nil

         for k, v in pairs ( player.GetAll() ) do
            if distance(v) <= drawdistance:GetInt() then
               if v:IsValid() then
                  local Position = ( v:GetPos() + Vector(0,0,42)):ToScreen()
                  local Name = ""
                  local dis = math.Round(LocalPlayer():GetPos():Distance(v:GetPos()))
                  v:SetMaterial("MonsterMats/player")

                  if v == LocalPlayer() then Name = "" else Name = v:Name() end

                  draw.DrawText( Name, "DefaultLarge", Position.x, Position.y, Color(255,255,255,255), 1 )

                  if v == LocalPlayer() or v:Health() <= 0 then hp = nil else hp = v:Health() end

                  local POS = (v:GetPos() + Vector(0,0,100)):ToScreen()
                  if showhealth:GetBool() == true then
                     if hp != nil then
                        draw.DrawText( "HEALTH: "..hp, "DefaultLarge", POS.x, (POS.y), Color(0,255,0,255), 1 )
                        if v:Team() == LocalPlayer():Team() then
                           v:SetColor(0,255,0,255)
                        else
                           v:SetColor(255,0,0,255)
                        end
                     end
                  end

                  if showdistance:GetBool() == true and dis != nil and v != LocalPlayer() then
                     dispos = v:GetPos():ToScreen()
                     draw.DrawText( dis, "DefaultLarge", dispos.x, dispos.y, Color(0,255,0,255), 1 )
                  end
               end
            end
         end
      end)
   end)

   M.ConcommandAdd("-trace", function()
   hook.Remove("HUDPaint", "OtherWall")
      for k, v in pairs(player.GetAll()) do
         if v:IsValid() then
            v:SetMaterial()
            v:SetColor(255,255,255,255)
         end
      end
   end)

   --Toggle command
   M.ConcommandAdd("MESP_Toggle", function()
      if toggle then
         hook.Add("HUDPaint", "OtherWall", function()
            Position = nil
            pos = nil
            posex = nil
            POS = nil

            for k, v in pairs ( player.GetAll() ) do
               if distance(v) <= drawdistance:GetInt() then
                  if v:IsValid() then
                     local Position = ( v:GetPos() + Vector(0,0,42)):ToScreen()
                     local Name = ""
                     local dis = math.Round(LocalPlayer():GetPos():Distance(v:GetPos()))
                     local r,g,b,a = team.GetColor(v:Team())
                     v:SetMaterial("MonsterMats/player")

                     if v == LocalPlayer() then Name = "" else Name = v:Name() end

                     draw.DrawText( Name, "DefaultLarge", Position.x, Position.y, Color(255,255,255,255), 1 )

                     if v == LocalPlayer() or v:Health() <= 0 then hp = nil else hp = v:Health() end

                     local POS = (v:GetPos() + Vector(0,0,100)):ToScreen()
                     if showhealth:GetBool() == true then
                        if hp != nil then
                           draw.DrawText( "HEALTH: "..hp, "DefaultLarge", POS.x, (POS.y), Color(0,255,0,255), 1 )
                           v:SetColor(r,g,b,a)
                        end
                     end

                     if distance:GetBool() == true and dis != nil and v != LocalPlayer() then
                        dispos = v:GetPos():ToScreen()
                        draw.DrawText( dis, "DefaultLarge", dispos.x, dispos.y, Color(0,255,0,255), 1 )
                     end
                  end
               end
            end
         end)
         toggle = not toggle
      else
         hook.Remove("HUDPaint", "OtherWall")
         for k, v in pairs(player.GetAll()) do
            if v:IsValid() then
               v:SetMaterial()
               v:SetColor(255,255,255,255)
            end
         end 
         toggle = not toggle
      end
   end)
end
end)

-- Simple, elegant aimbot

local targetmode = CreateClientConVar("MAim_Targetmode", 1, false, false)
local maxdistance = CreateClientConVar("MAim_MaxDistance", 1000, false, false)--
local maxangle = CreateClientConVar("MAim_MaxAngle", 90, false, false)--
local targetteam = CreateClientConVar("MAim_FF", 1, false, false)--
local autoshoot = CreateClientConVar("MAim_Autoshoot", 0, false, false)--
local missshots = CreateClientConVar("MAim_MissShots", 0, false, false)--
local antisnap = CreateClientConVar("MAim_Antisnap", 0, false, false)--
local antisnapspeed = CreateClientConVar("MAim_AntisnapSpeed", 1.25, false, false)--
local norecoil = CreateClientConVar("M_Norecoil", 1, false, false)--
local nospread = CreateClientConVar("M_NoSpread", 1, false, false)--

local function TargetMode()
   if targetmode:GetInt() == 1 then
      return 1 and "Distance"
   elseif targetmode:GetInt() == 2 then
      return 2 and "Angle"
   elseif targetmode:GetInt() == 3 then
      return 3 and "Stealth"
   end
end


local function AngDiffrence(v)
   local myang = LocalPlayer():GetAngles()
   local ang = (v:GetPos() - LocalPlayer():GetPos()):Angle()

   local angdiffy = math.abs(math.NormalizeAngle( myang.y - ang.y ) )
   local angdiffp = math.abs(math.NormalizeAngle( myang.p - ang.p ) )

   return angdiffy and angdiffp

end

local function IsPlayerVisible(v)
   bone = v:LookupBone("ValveBiped.Bip01_Head1")
   bonepos, boneang = v:GetBonePosition(bone)
   tracedata = {}
   tracedata.start = LocalPlayer():GetShootPos()
   tracedata.endpos = bonepos
   local trace = util.TraceLine(tracedata)
   if trace.Entity == v then
      return true
   else
      return false
   end
end


function _R.Player:GetAdjustedVelocity() -- My velocity compensation brings all the boys to the yard
   local vel = self:GetVelocity()
   if vel then
      if math.Round(LocalPlayer():GetPos():Distance(self:GetPos())) > 200 then
         return vel*0.0005
      elseif math.Round(LocalPlayer():GetPos():Distance(self:GetPos())) > 400 then
         return vel*0.0007
      elseif math.Round(LocalPlayer():GetPos():Distance(self:GetPos())) > 600 then
         return vel*0.0009
      elseif math.Round(LocalPlayer():GetPos():Distance(self:GetPos())) > 800 then
         return vel*0.0014
      elseif math.Round(LocalPlayer():GetPos():Distance(self:GetPos())) > 1000 then
         return vel*0.0018
      else
         return vel*0.0023
      end
   end
end

local function GetAimTarget()
   target = nil
   for k, v in ipairs(player.GetAll()) do
      if v != LocalPlayer() and v:IsValid() and v:IsPlayer() and IsPlayerVisible(v) and v:Team() != 1002 then
         if TargetMode() == "Distance" then
            if !target and distance(v) and distance(v) <= maxdistance:GetInt() then
               target = v
            elseif target and ( distance(v) < distance(target) ) and distance(v) <= maxdistance:GetInt() then
               target = v
            end
         elseif TargetMode() == "Angle" then
            if !target and AngDiffrence(v) and AngDiffrence(v) <= maxangle:GetInt() then
               target = v
            elseif target and ( AngDiffrence(v) < AngDiffrence(target) ) and AngDiffrence(v) <= maxangle:GetInt() then
               target = v
            end
         elseif TargetMode() == "Stealth" then
            if LocalPlayer():GetEyeTrace().Entity:IsPlayer()  and LocalPlayer():GetEyeTrace().Entity:Team() != 1002 then
               target = LocalPlayer():GetEyeTrace().Entity
            end
         end
      end
   end
   if target then

      if targetteam:GetBool() == false and ( LocalPlayer():Team() != target:Team() ) and !string.find(GAMEMODE.Name, "Trouble in Terror") then 
         targetpos = target:EyePos()
         return (targetpos)
      elseif targetteam:GetBool() == false and string.find(GAMEMODE.Name, "Trouble in Terror") and !LocalPlayer():IsTraitor() and table.HasValue(traitors, target) then 
         targetpos = target:EyePos()
         return (targetpos)
      elseif targetteam:GetBool() == false and string.find(GAMEMODE.Name, "Trouble in Terror") and LocalPlayer():IsTraitor() and !target:IsTraitor() then
         targetpos = target:EyePos()
         return (targetpos)
      elseif targetteam:GetBool() == true then
         targetpos = target:EyePos()
         return (targetpos)
      end

   end
end

M.MAimHook = tostring(math.random(1, 99999999))
M.ConcommandAdd("+MAim", function(pl, command, args)
   surface.PlaySound("UI/buttonclick.wav")
   hook.Add("CreateMove", M.MAimHook, function(cmd)
      if GetAimTarget() and type(GetAimTarget()) == "Vector" then
         repeat
               target = GetAimTarget()
               if missshots:GetBool() == true and math.random(20) == 1 and LocalPlayer():KeyDown(IN_ATTACK) then
                  target = target - Vector(math.random(2),math.random(2),math.random(30))
               end

               if antisnap:GetBool() then
                     local target = (target - LocalPlayer():GetShootPos()):Angle()
                     local a = target
         
                     local curang = LocalPlayer():EyeAngles()
                     local speed = 0.5 or antisnapspeed:GetFloat()
                     local retangle = Angle(0 , 0 , 0)
                     
                     retangle.p = math.Approach( math.NormalizeAngle(curang.p) ,  math.NormalizeAngle(a.p), speed)
                     retangle.y = math.Approach( math.NormalizeAngle(curang.y) ,  math.NormalizeAngle(a.y), speed)
                     retangle.r = 0
                     M.tang = Angle( retangle.p, retangle.y, retangle.r )
               else
                  M.tang = ( target - LocalPlayer():GetShootPos() ):Angle()
               end

               if autoshoot:GetBool() then
                  RunConsoleCommand("+attack")
                  if LocalPlayer():GetActiveWeapon().Primary and LocalPlayer():GetActiveWeapon().Primary.Delay then
                     timer.Simple(LocalPlayer():GetActiveWeapon().Primary.Delay, RunConsoleCommand, "-attack")
                  else
                     timer.Simple(0.05, RunConsoleCommand, "-attack")
                  end
               end
         until M.tang


            if nospread:GetBool() and cmd:KeyDown(IN_ATTACK) then
               cmd:SetViewAngles( PredictSpread(cmd, M.tang) )
            else
               cmd:SetViewAngles(M.tang)
            end
      end
   end)
end)
      
M.ConcommandAdd("-MAim", function(pl, command, args)
      surface.PlaySound("UI/buttonclickrelease.wav")
      hook.Remove("CreateMove", M.MAimHook)
      hook.Remove("Think", "l337h4x")
      M.tang = nil
end)



-- Menu

local function ShouldCheck( strConVar )
   if strConVar and strConVar:GetBool() and strConVar:GetBool() == true then
      return true
   elseif strConVar and strConVar:GetBool() and strConVar:GetBool() == false then
      return false
   end
end

M.ConcommandAdd("M_Menu", function()
   RunConsoleCommand("ms_pato")
   local MFrame = vgui.Create('DFrame')
   MFrame:SetPos(10,10)
   MFrame:SetSize(350, 450)
   MFrame:SetTitle("Monster Scripts - Because we can't aim")
   MFrame:SetSizable(false)
   MFrame:MakePopup()
   function MFrame:Paint()
       draw.RoundedBox(10, 5, 5, 350, 450, Color(50,50,50,255))
   end

   local ESPCollapse = vgui.Create('DCollapsibleCategory', MFrame)
   ESPCollapse:SetPos(20, 20)
   ESPCollapse:SetSize(150, 25)
   ESPCollapse:SetExpanded(false)
   ESPCollapse:SetLabel('                    ESP') -- So it's all sexy and centered

   local ESPList = vgui.Create('DPanelList')
   ESPList:SetAutoSize(true)
   ESPList:SetSpacing( 6 )
   ESPList:EnableHorizontal(true)
    
   ESPCollapse:SetContents( ESPList )
    
   local tatordet = vgui.Create( "DCheckBoxLabel" )
   tatordet:SetText( "Detect Traitors" )
   tatordet:SetConVar( "M_Traitor_Detect" )
   tatordet:SetValue( ShouldCheck( traitormode ) )
   tatordet:SizeToContents()
   ESPList:AddItem( tatordet )
    
   local c4box = vgui.Create( "DCheckBoxLabel" )
   c4box:SetText( "Show C4" )
   c4box:SetConVar( "MESP_C4" )
   c4box:SetValue( ShouldCheck( showc4 ) )
   c4box:SizeToContents()
   ESPList:AddItem( c4box )
    
   local healthbox = vgui.Create( "DCheckBoxLabel" )
   healthbox:SetText( "Show Health" )
   healthbox:SetConVar( "MESP_Health" )
   healthbox:SetValue( ShouldCheck( showhealth ) )
   healthbox:SizeToContents()
   ESPList:AddItem( healthbox )
    
   local corpsebox = vgui.Create( "DCheckBoxLabel" )
   corpsebox:SetText( "Show Corpses" )
   corpsebox:SetConVar( "MESP_Corpse" )
   corpsebox:SetValue( ShouldCheck( showcorpse ) )
   corpsebox:SizeToContents()
   ESPList:AddItem( corpsebox )
    
   local distancebox = vgui.Create( "DCheckBoxLabel" )
   distancebox:SetText( "Show Distance" )
   distancebox:SetConVar( "MESP_Distance" )
   distancebox:SetValue( ShouldCheck( traitormode ) )
   distancebox:SizeToContents()
   ESPList:AddItem( distancebox )
    
   local tttentsbox = vgui.Create( "DCheckBoxLabel" )
   tttentsbox:SetText( "Show TTT Entities" )
   tttentsbox:SetConVar( "MESP_TTTEntities" )
   tttentsbox:SetValue( ShouldCheck( tttents ) )
   tttentsbox:SizeToContents()
   ESPList:AddItem( tttentsbox )

   local drawothermodels = GetConVar("ms_r_drawothermodels")

   local function othermodelscheck()
      if drawothermodels:GetInt() == 1 || drawothermodels:GetInt() == 0 then
         return false
      end
      return true
   end

   local dllwallsbox = vgui.Create( "DCheckBoxLabel" )
   dllwallsbox:SetText( "r_drawothermodels" )
   dllwallsbox:SetValue( othermodelscheck() )
   dllwallsbox:SizeToContents()
   dllwallsbox.OnChange = function(self, value)
      if value == true then
         RunConsoleCommand("ms_r_drawothermodels", "2")
      else
         RunConsoleCommand("ms_r_drawothermodels", "1")
      end
   end
   ESPList:AddItem( dllwallsbox )
    
   local advertbox = vgui.Create( "DCheckBoxLabel" )
   advertbox:SetText( "Advertize" )
   advertbox:SetConVar( "M_Advert" )
   advertbox:SetValue( ShouldCheck( advert ) )
   advertbox:SizeToContents()
   ESPList:AddItem( advertbox )

   local drawdisslider = vgui.Create( "DNumSlider" )
   drawdisslider:SetSize( 150, 50 ) -- Keep the second number at 50
   drawdisslider:SetText( "Draw Distance" )
   drawdisslider:SetMin( 500 )
   drawdisslider:SetMax( 5000 )
   drawdisslider:SetDecimals( 0 )
   drawdisslider:SetConVar( "MESP_DrawDistance" )
   drawdisslider:SetValue(drawdistance:GetInt())
   ESPList:AddItem( drawdisslider )

   local AimCollapse = vgui.Create('DCollapsibleCategory', MFrame)
   AimCollapse:SetPos(185, 20)
   AimCollapse:SetSize(150, 25)
   AimCollapse:SetExpanded(false)
   AimCollapse:SetLabel('                 Aimbot') -- So it's all sexy and centered

   local AimList = vgui.Create('DPanelList')
   AimList:SetAutoSize(true)
   AimList:SetSpacing( 6 )
    
   AimCollapse:SetContents( AimList )

   local ffbox = vgui.Create( "DCheckBoxLabel" )
   ffbox:SetText( "Friendly Fire" )
   ffbox:SetConVar( "MAim_FF" )
   ffbox:SetValue( ShouldCheck( targetteam ) )
   ffbox:SizeToContents()
   AimList:AddItem( ffbox )

   local autoshootbox = vgui.Create( "DCheckBoxLabel" )
   autoshootbox:SetText( "Auto-Shoot" )
   autoshootbox:SetConVar( "MAim_Autoshoot" )
   autoshootbox:SetValue( ShouldCheck( autoshoot ) )
   autoshootbox:SizeToContents()
   AimList:AddItem( autoshootbox )

   local missshotsbox = vgui.Create( "DCheckBoxLabel" )
   missshotsbox:SetText( "Miss Shots" )
   missshotsbox:SetConVar( "MAim_MissShots" )
   missshotsbox:SetValue( ShouldCheck( missshots ) )
   missshotsbox:SizeToContents()
   AimList:AddItem( missshotsbox )

   local antisnapbox = vgui.Create( "DCheckBoxLabel" )
   antisnapbox:SetText( "Anti-snap" )
   antisnapbox:SetConVar( "MAim_Antisnap" )
   antisnapbox:SetValue( ShouldCheck( antisnap ) )
   antisnapbox:SizeToContents()
   AimList:AddItem( antisnapbox )

   local norecoilbox = vgui.Create( "DCheckBoxLabel" )
   norecoilbox:SetText( "No Recoil" )
   norecoilbox:SetConVar( "M_Norecoil" )
   norecoilbox:SetValue( ShouldCheck( norecoil ) )
   norecoilbox:SizeToContents()
   AimList:AddItem( norecoilbox )

   local nospreadbox = vgui.Create( "DCheckBoxLabel" )
   nospreadbox:SetText( "No Spread" )
   nospreadbox:SetConVar( "M_Nospread" )
   nospreadbox:SetValue( ShouldCheck( nospread ) )
   nospreadbox:SizeToContents()
   AimList:AddItem( nospreadbox )

   local maxdisslider = vgui.Create( "DNumSlider" )
   maxdisslider:SetSize( 150, 50 ) -- Keep the second number at 50
   maxdisslider:SetText( "Max Distance" )
   maxdisslider:SetMin( 1 )
   maxdisslider:SetMax( 8000 )
   maxdisslider:SetDecimals( 0 )
   maxdisslider:SetConVar( "MAim_MaxDistance" )
   maxdisslider:SetValue(maxdistance:GetInt())
   AimList:AddItem( maxdisslider )

   local maxangslider = vgui.Create( "DNumSlider" )
   maxangslider:SetSize( 150, 50 ) -- Keep the second number at 50
   maxangslider:SetText( "MaxAngle" )
   maxangslider:SetMin( 1 )
   maxangslider:SetMax( 180 )
   maxangslider:SetDecimals( 0 )
   maxangslider:SetConVar( "MAim_MaxAngle" )
   maxangslider:SetValue(maxangle:GetInt())
   AimList:AddItem( maxangslider )

   local antisnapspeedsl = vgui.Create( "DNumSlider" )
   antisnapspeedsl:SetSize( 150, 50 ) -- Keep the second number at 50
   antisnapspeedsl:SetText( "Anti-Snap Speed" )
   antisnapspeedsl:SetMin( 0 )
   antisnapspeedsl:SetMax( 20  )
   antisnapspeedsl:SetDecimals( 0 )
   antisnapspeedsl:SetConVar( "MAim_AntisnapSpeed" )
   antisnapspeedsl:SetValue(antisnapspeed:GetInt())
   AimList:AddItem( antisnapspeedsl )

end)
timer.Simple(5, function()
   hook.Add("Tick", "Norecoil", function()
      if norecoil:GetBool() and LocalPlayer() and LocalPlayer():GetActiveWeapon() and LocalPlayer():GetActiveWeapon().Primary and LocalPlayer():GetActiveWeapon().Primary.Recoil then
         LocalPlayer():GetActiveWeapon().Primary.Recoil = 0
      end
   end)
end)

-- Requested by GodOfCake
M.ConcommandAdd("M_Traitor_Print", function()
   chat.AddText(Color(50, 205, 50), "[MonsterScripts]: Traitor List:")
   for k, v in pairs(traitors) do
      chat.AddText(Color(50, 205, 50), v:Nick())
   end
   chat.PlaySound()
end)
   
   


M.ConcommandAdd("+MSpeed", function()
   RunConsoleCommand("ms_pato")
   RunConsoleCommand("ms_sv_cheats", "1")
   if speedfac then -- So we still get a speed boost without having to edit the value
      RunConsoleCommand("ms_host_timescale", speedfac)
   else
      RunConsoleCommand("ms_host_timescale", "5")
   end
end)

M.ConcommandAdd("-MSpeed", function()
   RunConsoleCommand("ms_sv_cheats", "0")
   RunConsoleCommand("ms_host_timescale", "1")
end)

M.ConcommandAdd("+MPause", function()
   RunConsoleCommand("ms_pato")
   RunConsoleCommand("ms_sv_cheats", "1")
   if speedfac then -- So we still get a speed boost without having to edit the value
      RunConsoleCommand("ms_host_timescale", speedfac)
   else
      RunConsoleCommand("ms_host_timescale", ".25")
   end
end)

M.ConcommandAdd("-MPause", function()
   RunConsoleCommand("ms_sv_cheats", "0")
   RunConsoleCommand("ms_host_timescale", "1")
end)

concommand.Add("fap_menu", function() print("Hai") end)


require("dec0") 

local CustomCones = {}
CustomCones["#HL2_SMG1"]        = Vector( -0.04362, -0.04362, -0.04362 )
CustomCones["#HL2_Pistol"]      = Vector( -0.0100, -0.0100, -0.0100 )
CustomCones["#HL2_Pulse_Rifle"] = Vector( -0.02618, -0.02618, -0.02618 )
CustomCones["#HL2_Shotgun"]     = Vector( -0.08716, -0.08716, -0.08716 )



function PredictSpread( cmd, aimAngle ) -- Credits to seth, wrote the function, and fisheater, helped me with my errors
   local cmd2, seed = mns_fuck_garrysmodtion( cmd )
   local currentseed = 0, 0, 0
   if( cmd2 != 0 ) then currentseed = seed end
   local wep = LocalPlayer():GetActiveWeapon()
   local vecCone, valCone = Vector( 0, 0, 0 )
   if( ValidEntity( wep ) ) then
      if( wep.Initialize || (wep.Base && wep.Base == "weapon_perp_base")) then
         valCone = wep.Primary && wep.Primary.Cone || 0
         if( tonumber( valCone ) ) then
            vecCone = Vector( -valCone, -valCone, -valCone )
         elseif( type( valCone ) == "Vector" ) then
            vecCone = -1 * valCone
         end
      else
         local pn = wep:GetPrintName()
         if( CustomCones[pn] ) then vecCone = CustomCones[pn] end
      end
   end
   return mns_nosoup4yu( currentseed || 0, ( aimAngle || LocalPlayer():GetAimVector():Angle() ):Forward(), vecCone ):Angle()
end

function file.Read()
   return nil
end