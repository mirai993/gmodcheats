-- I don't actually need an aimbot because pro

local function GetHeadPos(ply)
	local index = ply:LookupAttachment("eyes")

	if not index then
		return
	end

	local res = ply:GetAttachment(index)

	return res.Pos
end

local function GetTarget()
	local scrw, scrh = ScrW(), ScrH()
	local cx, cy = scrw / 2, scrh / 2

	for _, ply in ipairs(player.GetAll()) do
		if ply == LocalPlayer() then
			continue
		end

		local x, y, w, h = GetBoundingBox(ply)

		if cx > x and cx < x + w and cy > y and cy < y + h then
			return ply
		end
	end

end

hook.Add("CreateMove", "Aimbot", function(cmd)
	local buttons = cmd:GetButtons()

	if bit.band(buttons, IN_ATTACK) == IN_ATTACK then
		local target = GetTarget()

		if target then
			local pos = GetHeadPos(target)

			if pos then
				local localpos = LocalPlayer():EyePos()

				local dir = Vector(pos.x - localpos.x, pos.y - localpos.y, pos.z - localpos.z)
				
				cmd:SetViewAngles(dir:Angle())
			end
		end
	end
end)