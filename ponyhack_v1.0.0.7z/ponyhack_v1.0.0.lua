--[[
	MOD/lua/h/h.lua [#25406 (#25406), 1369807103, UID:3267398023]
	Kawaii Hafnium | STEAM_0:0:69773252 <142.167.63.80:60698> | [25.07.14 08:21:39PM]
	===BadFile===
]]

--[[
PonyHack v1 - By Hafnium
3rd rebuild of the hack

Started on 6/26/2014

This version is aimed at server exploits rather than cheats
Aren't you tired of seeing the same hack C+Ped 2147483647 times and renamed.

If you're reading this, you probably have a leaked copy, please don't redistribute this hack!
We ask that you immediately delete this file off your computer and contact Kawaii Hafnium (Hafnium)
explaining how you got this! (http://steamcommunity.com/id/MLP-FiM/)

Note:
I was drunk when I coded most of this hack, if it's shit, it's prolly cuz I'm so fucking drunk right
now, kk? don't come PMing me cuz it's shit bcuz I will fuck you up, kk? tyty, gg, well played.
FUCK YOU!!!1! kk?

Disclaimer:
No ponies were harmed in the making of this hack, enjoy!
]]--

require("net")
require("hook")
require("draw")

local math = math
local draw = draw
local pairs = pairs
local render = render
local vgui = vgui
local surface = surface
local RunConsoleCommand = RunConsoleCommand
local table = table

local h = {}
h.data = {} 
h.data.name = "PonyHack" 
h.data.author = "Hafnium" 
h.data.version = "1.0"
local me = LocalPlayer()
local include = include
function h.print(txt)
	chat.AddText(Color(255,0,0,255), "[" .. h.data.name .. "] ",Color(255,255,255), txt)
end

--[[
____________________▄▄▄███████████████▄▄
__________________▅▀█████▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓████▄
_______________________▄▄▄█████▒▒▒▒▒▒▓▓▓▓▓▓▓▓▓███▄▄
____________________▄██▓▓▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▓▓▓▓▓▓▓██▄_____▓▓
_________________▄█▒▒▓__▓▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▓▓▓▓▓██▓___▓▓
______________▄█▒▒▒▒▒▓__▓▓▓▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▓▓▓_______▓
____________▄█▒▒▒▒▒▒▒▓_▓___▓▓▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▓_________▓
__________▄█▒▒▒▒▒▒▒▒▒▓______▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▒▒▒▒▒▒▒▓___________▓
_________██▒▒▒████▓▓▓▓▓____▓____▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓________▓____▓
________███▀▀██▓▓▓▓▓▓▓▓▓_▓_______▓▓▀▀▀▀▀▀██▓▓▓▓▓▓▓__________▓____▓█
______█▀___▄█▓▓▓▓▓▓▓▓▓▓▓▓________▓_______██▓▓▓▓▓▓▓▓▓__________▓___▓██
_________▄█▓▓▓▓▓▓▓▓█████▓▓______________██▓▓▓▓██▀▀▀▓__________▓___▓▓▓█
_______▄█▓▓▓▓▓▓███▓███▓▓__▓____________█▓██▀▀▀_________________▓___▓▒▓▓█
_____▄█▓▓▓▓▓███▒▒▓██▓██▓______________█▀▀__▓▓▓▓▓▓▓___________▓___▓▒▒▓▓█
____██▓▓▓███▒▒▒▒▓██▓▓██▓_______________▓▓▓▓██████▓▓▀______▓_____▓▒▒▒▓▓█
___█▓▓████▒▒▒▒▒▓██▓▓▒██▓____________▓▓███▒▒▓▓▓▓██▓_____________▓▒▒▒▒▓▓█
__█▓█▀_██▒▒▒▒▒▒▓██▓▒▒██▓__________▓▓██▒▒▒▒▓▓▓▓▓██▓▄▀_________▓▓▓▒▒▒▓▓█
_██____██▒▒▒▒▒▒▓██▒▒▓▓█▓▓________▓▓██▓▒▒▒▓▓▓▓▓▓██▓__________▓█▓▓▒▒▒▒▓█
▀_____██▒▒▒▒▒▒▒▓██▒▒▓▓█▓▓_______▓▓██▓▓▓▒▒▒▓▓▓▓██▓▄▄▀______▓_█▓▓▒▒▒▒▓▓█
_____██▒▒▒▒▒▒▒▒▓██▒▒▓▓█▓▓▓____▓▓██▓▓▓▓▒▒▒▒▓▓▓██▓____________█▓▓▒▒▒▒▒▓█
_____██▒▒▒▒▒▒▒▒▓██▒▒▒▓██████▓▓▓██▓▓▓▒▒▒▒▒▓▓▓██▓___________█▓▓▓▒▒▒▒▒▓▓█
____██▒▒▒▒▒▒▒▒▒▓██▒▓▓██▓▓▓▓▓████▓▓▓▒▒▒▒▒▓▓▓██▓___________█▓▓▓▒▒▒▒▒▒▓▓█
____█▒▒▒▒▒▒▒▒▒▒▒▓█▓▓▓█▓▓______▓▓█▓▓▒▒▒▒▒▓▓▓▓██▓___________█▓▓▓▓▒▒▒▒▒▓▓█
___█▒▒▒▒▒▒▒▒▒▒▒▓▓█▓▓██▓_______▓▓█▓▓▒▒▒▒▓▓▓▓██▓___________█▓▓▓▓█▒▒▒▒▒▓▓█
___█▒▒▒▒▒▒█▒▒▒▒▓▓▓▓▓▓__________▓▓█▓▒▒▒▒▓▓▓▓██▓___________█▓▓▓▓█▒▒▒▒▒█▓▓█
__█▒▒▒▒▒▒█▒▒▒▒▓▓▓▓____▄▄___▄___▓▓██▒▒▒▒▓▓███▓____________█▓▓▓██▒▒▒▒▒██▓█
__█▒▒▒▒▒██▒▒▒▓▓▓▓▓▓________█▐___▓▓████████▓▓____________█▓▓▓█_█▒█▒▒▒█_█▓█
__█▒▒▒██_█▒▒▒▓▓▓▓▓▓▓▓▓▄▄▄▀_▐____▓▓▓▓███▓▓_________▓▓▓▓█▓▓█_█▒▒█▒▒▒█__██
_█▒▒▒█___█▒▒▒▓▓▓▓▓▓▓▓▓▓_____▐________▓▓▓▓________▓▓▓___████___█▒▒█▒▒█____█
_█▒▒█____█▒▒▒▓▓▓▓▓▓▓▓▓▓▓▓▓▄▀_______________▓▓▓▓▓_____██______█▒▒██▒▒█____█
_█▒█______█▒▒▒▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓___________________█▒▒███▒█
_██_______█▒▒▒▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓█____________________________█▒▒█_█▒█
_█_________█▒▒▓▓▓▓▓▓▓▓▓▓▓▓█▓▓▓▓█_____________________________█▒█___█▒█
____________█▒▓▓▓▓▓▓▓█▓▓▓▓▓██▓▓█____________________________█▒█_____██
____________█▒▓▓▓▓▓▓▓██▓▓▓█__███____________________________██_______█
_____________█▓▓▓▓▓▓▓█_█▓▓▓█___█____________________________█_________▀
______________█▓▓▓▓▓▓█__█▓▓▓█
______________█▓▓▓▓▓▓█___██▓█
_______________█▓▓▓▓▓█______██
________________█▓▓▓▓▓█_______█
_________________█▓▓▓▓█
__________________██▓▓▓█
____________________█▓▓▓█
_____________________██▓▓█
________________________██
__________________________█
--]]



--[[VARIABLES]]--
h.v={}

h.v.wallhack = {}
h.v.wallhack.ply = false
h.v.wallhack.ent = false
h.v.wallhack.ents = {"money_printer","spawned_money","spawned_weapon","spawned_shipment"}
h.v.wallhack.xhair = false
h.v.wallhack.stafflist = false

h.v.spam = {}
h.v.spam.light = false
h.v.spam.chat = false
h.v.spam.rope = false
h.v.spam.pointshop = false
h.v.spam.motd = false

h.v.aimbot = {}
h.v.aimbot.enabled = false
h.v.aimbot.steamfriends = false
h.v.aimbot.target = "ValveBiped.Bip01_Head1" -- I don't think I'm going to make this changeable for now.
h.v.aimbot.lines = false

h.v.misc = {}
h.v.misc.propkill = false
h.v.misc.derp = false
h.v.misc.norecoil = false

--[[HACKS START HERE]]--
local function DrawText(txt,font,x,y)
	draw.SimpleTextOutlined( txt, font, x, y, Color(255,255,255,255), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT, 1, Color(0,0,0,255) )
end

function h.wallhack_ply()
	
	if !h.v.wallhack.ply then return end
	
	for k,v in pairs(player.GetAll()) do
	
		if v != me then
			
			local posy = v:GetPos():ToScreen()
			DrawText( v:Nick() .. " (" .. v:Health() .. ")", "default", posy.x, posy.y)
			
			local wep = v:GetActiveWeapon()
			
			if IsValid(wep) and wep:GetPrintName() != nil then
				DrawText( wep:GetPrintName(), "default", posy.x,posy.y+10 )
			end
			
			local rank = v:GetUserGroup()
			
			if rank != nil and rank != "user" then
				DrawText( rank, "default", posy.x,posy.y+20 )
			end
			
		
		end
	
	end
	
end

function h.wallhack_ent()
	
	if !h.v.wallhack.ent then return end
	
	if h.v.wallhack.ents == nil then return end
	
	for k,v in pairs(ents.GetAll()) do
		if table.HasValue(h.v.wallhack.ents, v:GetClass()) then
			local posy = v:GetPos():ToScreen()
			DrawText(v:GetClass(), "default", posy.x,posy.y)
		end
	end

end

function h.wallhack_xhair()

	local mat = Material("vgui/crosshair.png","nocull")
	
	surface.SetMaterial( mat )
	surface.SetDrawColor(Color(0,150,255,255))
	
	if !h.v.wallhack.xhair then return end
	
	surface.DrawTexturedRect( ScrW()/2 - 32, ScrH()/2 - 32, 64, 64 )
	
end 

local staff
function h.wallhack_stafflist()

	if !h.v.wallhack.stafflist then return end

	staff = 0

	for k,v in pairs(player.GetAll()) do
		
		local rank = v:GetUserGroup()
		
		if rank != "user" then
			staff = staff+1
		end
		
		
	end
	
	if staff == 1 then -- dat OCD doe
		DrawText("There is currently " .. staff .. " possible staff member online!", "default", 5,5)
	else
		DrawText("There are currently " .. staff .. " possible staff members online!", "default", 5,5)
	end

end

hook.Add("HUDPaint", "h_wallhack", function()
	h.wallhack_ply()
	h.wallhack_ent()
	h.wallhack_xhair()
	h.wallhack_stafflist()
end)

local function distance(v1,v2)
	local args = {v1:LengthSqr(),v2:LengthSqr()}
	return math.max(unpack(args)) - math.min(unpack(args))
end

local target_ent
local target = {}
local target_distance = {}
local norecoil
function h.aimbot(cmd)

	-- Not sure if we should do it for blank commands or not
	--if cmd:CommandNumber() == 1 then return end

	target={}
	target_distance={}
	local closest

	if !h.v.aimbot.enabled then return end

	local plys = player.GetAll()
	
	if IsValid(target_ent) and !target_ent:Alive() then
		target_ent = nil -- If target is dead, find another one.
	end
	
	
	if !IsValid(target_ent) then
		
		for k,v in pairs(plys) do
			if v:Alive() and v != me then
	
				if (h.v.aimbot.friend and v:GetFriendStatus() == "friend") then
					-- Don't target friends!
				else
						local tr = {}
						tr.start = me:GetPos() + Vector(0,0,60) 
						tr.endpos = v:GetPos() + Vector(0,0,60) 
						tr.filter = me
 
						local trace = util.TraceLine( tr )
				
						local ent = trace.Entity
						
				
						if ent == v then -- TODO: Better wall detection Q.Q
							table.insert(target,v)
							table.insert(target_distance,distance(me:GetPos(),v:GetPos()))
						end
				
				end
			
			end
		end
			
			closest = math.min( unpack( target_distance ) )
			
			for k,v in pairs(target_distance) do
				if v == closest then
				
					target_ent = target[k]
				
				end
			end
		
	end
	
	if !IsValid(target_ent) then return end -- ???
	
	
	if !target_ent:Alive() then 
		target_ent = nil
		return 
	end
	
	local target_target = target_ent:LookupBone(h.v.aimbot.target)
	local targetpos,targetand = target_ent:GetBonePosition(target_target)
	local speed = target_ent:GetVelocity() * 0.013
	
	targetpos = targetpos + speed
	
	cmd:SetViewAngles( ( targetpos - me:GetShootPos() ):Angle() )
	
end
hook.Add("CreateMove", "h_ab", h.aimbot)

function h.aimbotlines()
	
	if !h.v.aimbot.lines then return end

	for k,v in pairs(player.GetAll()) do
		if v != me then
			cam.Start3D()
			
				local col = Color(255,255,255)
				if v == target_ent then
					col = Color(255,0,0)
				end
			
				render.DrawLine(me:GetPos() + Vector(0,0,60),v:GetPos() + Vector(0,0,60),col,false)
			cam.End3D()
		end
	end
	
end
hook.Add("HUDPaint", "h_al", h.aimbotlines)

h.misc = {}
function h.misc.propkill(cmd)
	if h.v.misc.propkill and me:KeyDown(IN_USE) then
		cmd:SetMouseWheel(1)
	end
end
hook.Add("CreateMove","h_pk", h.misc.propkill)

h.spam = {}
function h.spam.chat()
	if !h.v.spam.chat then return end
	RunConsoleCommand("say", h.data.name .. " v" .. h.data.version .. " is da bests hecks evar fux 2 herasethbaconfaphecks kk?")
end
timer.Create("h_chat", 1, 0, h.spam.chat)

function h.spam.rope()

	if !h.v.spam.rope then return end
	if me:GetActiveWeapon():GetClass() != "gmod_tool" then return end
	
	me:SetEyeAngles( Angle( math.random(360), math.random(360), 0 ) )
	RunConsoleCommand("+attack")
	
	timer.Simple(0.025, function()
		RunConsoleCommand("-attack")
	end)
	
	me:SetEyeAngles( Angle( math.random(360), math.random(360), 0) )
	RunConsoleCommand("+attack")
	
	timer.Simple(0.05, function()
		RunConsoleCommand("-attack")
	end)

end
timer.Create("h_rope", 0.055, 0, h.spam.rope)

function h.spam.light()
	if !h.v.spam.light then return end
	RunConsoleCommand("impulse", "100")
end
hook.Add("CreateMove", "h_light", h.spam.light) -- Way faster than a Think hook :3

function h.misc.derp(cmd)
	if !h.v.misc.derp then return end
	cmd:SetViewAngles( Angle( math.random(360), math.random(360), 0 ) )
end
hook.Add("CreateMove", "h_drp", h.misc.derp)

function h.misc.derp_view(ply, pos, angles, fov)
	if !h.v.misc.derp then return end
    local view = {}
    view.origin = ply:GetPos() + Vector(-70,0,50)
    view.angles = Angle(0,0,0)
    view.fov = fov
 
    return view
end
hook.Add("CalcView", "h_drp_vw", h.misc.derp_view)

hook.Add("ShouldDrawLocalPlayer", "h_derp_vw2", function(ply)
	if !h.v.misc.derp then return false end
       return true
end)

hook.Add("CalcView", "h_nrc", h.misc.norecoil)

function h.spam.motd()
	
	if h.v.spam.motd and (GetConVar("ulx_showmotd"):GetInt() == 0) then
		RunConsoleCommand("ulx", "motd") -- I love this one xD
	end

end

hook.Add("CreateMove", "h_motd", h.spam.motd)


--[[MENU SHIT, TYPICALLY THE MESSIEST PART OF THE HACK]]--
function h.menu()

	local x = 100
	local y = 25 + 30 + 5 + 30 + 5 + 30 + 5 + 30 + 5 + 35
	local frames = {}
	local BorderCol = Color(100,150,240,250)

	local frame = vgui.Create("DFrame")
	frame:SetSize(x,y)
	frame:SetPos(5,ScrH()/2-y/2)
	frame:MakePopup()
	frame:SetTitle(h.data.name .. " v" .. h.data.version)
	frame:SetDraggable(false)
	frame:ShowCloseButton(false)
	function frame.Paint()
		draw.RoundedBox(4,0,0,frame:GetWide(),frame:GetTall(),BorderCol)
		draw.RoundedBox(4,2,2,frame:GetWide()-4,frame:GetTall()-4,Color(250,250,250,250))
		draw.RoundedBox(4,0,0,frame:GetWide(),20,BorderCol) -- Little bar on the top xD
	end
	table.insert(frames,frame)
	
	local function RemoveFrames()
		for k,v in pairs(frames) do
			if k != 1 then
				v:Remove()
				frames[k] = nil
			end
		end
	end
	
	local function CreateMainFrame()
	local mainframe = vgui.Create("DFrame")
	mainframe:SetSize(200,300)
	mainframe:SetPos(115,ScrH()/2 - 150)
	mainframe:MakePopup()
	mainframe:ShowCloseButton(false)
	mainframe:SetDraggable(false)
	mainframe:SetTitle("")
	frames.main = mainframe
	function mainframe.Paint()
		if mainframe_enabled == false then return end
		draw.RoundedBox(4,0,0,mainframe:GetWide(),mainframe:GetTall(),BorderCol)
		draw.RoundedBox(4,2,2,mainframe:GetWide()-4,mainframe:GetTall()-4,Color(250,250,250,250))
		draw.RoundedBox(4,0,0,mainframe:GetWide(),20,BorderCol) -- Little bar on the top xD
	end
	end
	
	local cbut = vgui.Create("DButton", frame)
	cbut:SetSize(x - 10,30)
	cbut:SetPos(5,y-35)
	cbut:SetText("Close")
	function cbut.Paint()
		draw.RoundedBox(0,0,0,cbut:GetWide(),cbut:GetTall(),BorderCol)
		draw.RoundedBox(0,1,1,cbut:GetWide()-2,cbut:GetTall()-2,Color(255,255,255,255))
	end
	
	function cbut.DoClick()
		for k,v in pairs(frames) do
			v:Remove()
		end
	end
	
	local aimbot = vgui.Create("DButton", frame)
	aimbot:SetText("Aimbot ->")
	aimbot:SetSize(x-10,30)
	aimbot:SetPos(5,25)
	function aimbot.Paint()
		draw.RoundedBox(0,0,0,aimbot:GetWide(),aimbot:GetTall(),BorderCol)
		draw.RoundedBox(0,1,1,aimbot:GetWide()-2,aimbot:GetTall()-2,Color(255,255,255,255))
	end
	function aimbot.DoClick()
		
		if frames.main != nil then
			RemoveFrames()
		else
			RemoveFrames()
			CreateMainFrame() 
			
			frames.main:SetTitle("Aimbot settings")
			frames.main:SetTall(25 + 20 + 20 + 20)
			frames.main:SetPos(115, ScrH()/2 - frame:GetTall()/2)
		
			local but = vgui.Create("DCheckBoxLabel", frames.main)
			but:SetPos(5,25)
			but:SetText("Aimbot")
			but:SetValue( tobool( h.v.aimbot.enabled ) )
			but:SizeToContents()
			but:SetTextColor(Color(0,0,0,255))
			function but.Think()
				h.v.aimbot.enabled = tobool(but:GetChecked())
			end
			
			local but = vgui.Create("DCheckBoxLabel", frames.main)
			but:SetPos(5,25 + 20)
			but:SetText("Ignore steam friends")
			but:SetValue( tobool( h.v.aimbot.steamfriends ) )
			but:SizeToContents()
			but:SetTextColor(Color(0,0,0,255))
			function but.Think()
				h.v.aimbot.steamfriends = tobool(but:GetChecked())
			end
			
			local but = vgui.Create("DCheckBoxLabel", frames.main)
			but:SetPos(5,25 + 20 + 20)
			but:SetText("Debug lines")
			but:SetValue( tobool( h.v.aimbot.lines ) )
			but:SizeToContents()
			but:SetTextColor(Color(0,0,0,255))
			function but.Think()
				h.v.aimbot.lines = tobool(but:GetChecked())
			end
			
			
		end
		
	end

	
	local wallhack = vgui.Create("DButton", frame)
	wallhack:SetText("Wallhack ->")
	wallhack:SetSize(x-10,30)
	wallhack:SetPos(5,25 + 30 + 5)
	function wallhack.Paint()
		draw.RoundedBox(0,0,0,wallhack:GetWide(),wallhack:GetTall(),BorderCol)
		draw.RoundedBox(0,1,1,wallhack:GetWide()-2,wallhack:GetTall()-2,Color(255,255,255,255))
	end
	function wallhack.DoClick()
	
		if frames.main != nil then
			RemoveFrames()
		else
			RemoveFrames()
			CreateMainFrame() 
			
			frames.main:SetTitle("Wallhack settings")
			frames.main:SetTall(25 + 20 + 20 + 20 + 20)
			frames.main:SetPos(115, ScrH()/2 - frame:GetTall()/2 + 25 + 5)
		
			local but = vgui.Create("DCheckBoxLabel", frames.main)
			but:SetPos(5,25)
			but:SetText("Player ESP")
			but:SetValue( tobool( h.v.wallhack.ply ) )
			but:SizeToContents()
			but:SetTextColor(Color(0,0,0,255))
			function but.Think()
				h.v.wallhack.ply = tobool(but:GetChecked())
			end
			
			local but = vgui.Create("DCheckBoxLabel", frames.main)
			but:SetPos(5,25 + 20)
			but:SetText("Entity ESP")
			but:SetValue( tobool( h.v.wallhack.ent ) )
			but:SizeToContents()
			but:SetTextColor(Color(0,0,0,255))
			function but.Think()
				h.v.wallhack.ent = tobool(but:GetChecked())
			end
			
			local but = vgui.Create("DCheckBoxLabel", frames.main)
			but:SetPos(5,25 + 20 + 20)
			but:SetText("Staff counter")
			but:SetValue( tobool( h.v.wallhack.stafflist ) )
			but:SizeToContents()
			but:SetTextColor(Color(0,0,0,255))
			function but.Think()
				h.v.wallhack.stafflist = tobool(but:GetChecked())
			end
			
			local but = vgui.Create("DCheckBoxLabel", frames.main)
			but:SetPos(5,25 + 20 + 20 + 20)
			but:SetText("Crosshair")
			but:SetValue( tobool( h.v.wallhack.xhair ) )
			but:SizeToContents()
			but:SetTextColor(Color(0,0,0,255))
			function but.Think()
				h.v.wallhack.xhair = tobool(but:GetChecked())
			end
			
			local but = vgui.Create("DButton", frames.main)
			but:SetPos(frames.main:GetWide() - 100, 25)
			but:SetSize(95,frames.main:GetTall()-35)
			but:SetText( "Entity list ->" )
			function but.Paint()
				draw.RoundedBox(0,0,0,but:GetWide(),but:GetTall(),BorderCol)
				draw.RoundedBox(0,1,1,but:GetWide()-2,but:GetTall()-2,Color(255,255,255,255))
			end
			
			function but.DoClick()
				local frame = vgui.Create("DFrame")
				frame:SetSize(ScrW()/2,ScrH()/2)
				frame:Center()
				frame:MakePopup()
				frame:SetDraggable(false)
				frame:ShowCloseButton(false)
				frame:SetTitle("Entity list")
				function frame.Paint()
					draw.RoundedBox(4,0,0,frame:GetWide(),frame:GetTall(),BorderCol)
					draw.RoundedBox(4,2,2,frame:GetWide()-4,frame:GetTall()-4,Color(250,250,250,250))
					draw.RoundedBox(4,0,0,frame:GetWide(),20,BorderCol) -- Little bar on the top xD
				end
				
				local cbut = vgui.Create("DButton",frame)
				cbut:SetSize(frame:GetWide()-10, 30)
				cbut:SetPos(5,frame:GetTall()-35)
				cbut:SetText("Close")
				function cbut.DoClick()
					frame:Remove()
				end
				function cbut.Paint()
					draw.RoundedBox(0,0,0,cbut:GetWide(),cbut:GetTall(),BorderCol)
					draw.RoundedBox(0,1,1,cbut:GetWide()-2,cbut:GetTall()-2,Color(255,255,255,255))
				end
				
				
				local view = vgui.Create("DListView", frame)
				view:SetPos(5,25)
				view:SetSize(frame:GetWide()/2-5 - 50,frame:GetTall() - cbut:GetTall() - 35)
				view:AddColumn("On ESP")
				
				for k,v in pairs(h.v.wallhack.ents) do
					view:AddLine(v)
				end
				
				local view2 = vgui.Create("DListView", frame)
				view2:SetPos(5 + view:GetWide() + 100,25)
				view2:SetSize(frame:GetWide()/2-5 - 50,frame:GetTall() - cbut:GetTall() - 35)
				view2:AddColumn("Off ESP")
				
				local blacklist = {"player","worldspawn","env_sun","func_door","func_button","viewmodel"} -- We'll add more later on
				for k,v in pairs(ents.GetAll()) do
					if !table.HasValue(h.v.wallhack.ents, v:GetClass()) and !table.HasValue(blacklist,v:GetClass()) then
						view2:AddLine(v:GetClass())
					end
				end
				
				local function ReloadViews()
					view2:Clear()
					view:Clear()
					
					for k,v in pairs(h.v.wallhack.ents) do
						view:AddLine(v)
					end
					
					for k,v in pairs(ents.GetAll()) do
						if !table.HasValue(h.v.wallhack.ents) then
							view2:AddLine(v)
						end
					end
				end
				
				
				local but = vgui.Create("DButton", frame)
				but:SetPos(view:GetWide() + 10,frame:GetTall()/2 - 30 + 25/2)
				but:SetSize(90,30)
				but:SetText("<---")
				function but.DoClick()
					if view2:GetSelectedLine() != nil then
						local EntClass = view2:GetLine(view2:GetSelectedLine()):GetValue(1)
						table.insert(h.v.wallhack.ents, EntClass)
					end
				end
				
				local but = vgui.Create("DButton", frame)
				but:SetPos(view:GetWide() + 10,frame:GetTall()/2 - 30 - 35 + 25/2)
				but:SetSize(90,30)
				but:SetText("--->")
				function but.DoClick()
					if view:GetSelectedLine() != nil then
						local EntClass = view:GetLine(view:GetSelectedLine()):GetValue(1)
						local entz = table.KeysFromValue(h.v.wallhack.ents, EntClass)
						
							for k,v in pairs(entz) do
								table.remove(h.v.wallhack.ents,v)
							end
						
					end
				end
				
			end
			
		end
		
	end
	
	local spam = vgui.Create("DButton", frame)
	spam:SetText("Spam ->")
	spam:SetSize(x-10,30)
	spam:SetPos(5,25 + 30 + 5 + 30 + 5)
	function spam.Paint()
		draw.RoundedBox(0,0,0,spam:GetWide(),spam:GetTall(),BorderCol)
		draw.RoundedBox(0,1,1,spam:GetWide()-2,spam:GetTall()-2,Color(255,255,255,255))
	end
	function spam.DoClick()
	
		if frames.main != nil then
			RemoveFrames()
		else
			RemoveFrames()
			CreateMainFrame() 
			
			frames.main:SetTitle("Spam settings")
			frames.main:SetTall(25 + 20 + 20 + 20 + 20)
			frames.main:SetPos(115, ScrH()/2 - frame:GetTall()/2 + 25 + 5 + 25 + 5)
		
			local but = vgui.Create("DCheckBoxLabel", frames.main)
			but:SetPos(5,25)
			but:SetText("Chat spam")
			but:SetValue( tobool( h.v.spam.chat ) )
			but:SizeToContents()
			but:SetTextColor(Color(0,0,0,255))
			function but.Think()
				h.v.spam.chat = tobool(but:GetChecked())
			end
			
			local but = vgui.Create("DCheckBoxLabel", frames.main)
			but:SetPos(5,25 + 20)
			but:SetText("Flastlight spam")
			but:SetValue( tobool( h.v.spam.light ) )
			but:SizeToContents()
			but:SetTextColor(Color(0,0,0,255))
			function but.Think()
				h.v.spam.light = tobool(but:GetChecked())
			end
			
			local but = vgui.Create("DCheckBoxLabel", frames.main)
			but:SetPos(5,25 + 20 + 20)
			but:SetText("Rope spam")
			but:SetValue( tobool( h.v.spam.rope ) )
			but:SizeToContents()
			but:SetTextColor(Color(0,0,0,255))
			function but.Think()
				h.v.spam.rope = tobool(but:GetChecked())
			end
			
			local but = vgui.Create("DCheckBoxLabel", frames.main)
			but:SetPos(5,25 + 20 + 20 + 20)
			but:SetText("MOTD spam")
			but:SetValue( tobool( h.v.spam.motd ) )
			but:SizeToContents()
			but:SetTextColor(Color(0,0,0,255))
			function but.Think()
				h.v.spam.motd = tobool(but:GetChecked())
			end

			
		end
		
	end
	
	
	local misc = vgui.Create("DButton", frame)
	misc:SetText("Misc ->")
	misc:SetSize(x-10,30)
	misc:SetPos(5,25 + 30 + 5 + 30 + 5 + 30 + 5)
	function misc.Paint()
		draw.RoundedBox(0,0,0,misc:GetWide(),misc:GetTall(),BorderCol)
		draw.RoundedBox(0,1,1,misc:GetWide()-2,misc:GetTall()-2,Color(255,255,255,255))
	end
	
	function misc.DoClick()
	
		if frames.main != nil then
			RemoveFrames()
		else
			RemoveFrames()
			CreateMainFrame() 
			
			frames.main:SetTitle("Misc settings")
			frames.main:SetTall(25 + 20 + 20)
			frames.main:SetPos(115, ScrH()/2 - frame:GetTall()/2 + 25 + 5 + 25 + 5 + 25 + 25)
		
			local but = vgui.Create("DCheckBoxLabel", frames.main)
			but:SetPos(5,25)
			but:SetText("Easy propkill")
			but:SetValue( tobool( h.v.misc.propkill ) )
			but:SizeToContents()
			but:SetTextColor(Color(0,0,0,255))
			function but.Think()
				h.v.misc.propkill = tobool(but:GetChecked())
			end
			
			local but = vgui.Create("DCheckBoxLabel", frames.main)
			but:SetPos(5,25 + 20)
			but:SetText("D3RP M0D3")
			but:SetValue( tobool( h.v.misc.derp ) )
			but:SizeToContents()
			but:SetTextColor(Color(0,0,0,255))
			function but.Think()
				h.v.misc.derp = tobool(but:GetChecked())
			end


			
		end
		
	end

end
concommand.Add("hmenu",h.menu)