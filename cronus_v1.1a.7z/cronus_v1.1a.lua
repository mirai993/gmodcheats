--[[
	autorun/client/Cronus.lua
	Kinderknacht | (STEAM_0:0:50357078)
	===DStream===
]]

--[[
// Project Cronus // Thanks to anyone who helped me with this // This is just a HvH Cheat, Not some DarkRP Shit // I take no credit for most of this code // Enjoy Cronus! //
]]--

--[[ Start of the cheat, localizing, requires, and other useless bullshit ]]--

if ( SERVER ) then return end // We only want this to work clientside ;)

local Cronus = {}
local Version = 1.1 .. " Alpha "
local CreateClientConVar = CreateClientConVar;
local x = ScrW() / 2 --Crosshair
local y = ScrH() / 2 --Crosshair
local gap = 0 --Crosshair Gap
local length = 5 --Crosshair Length

if( _G["Cronus"] ) then _G["Cronus"] = nil; end

require("cronus_cvar")
require("cronus_se")

// ConVars
CreateClientConVar( "aim_removeaa", 1, true, false )
CreateClientConVar( "aim_removerecoil", 1, true, false )
CreateClientConVar( "misc_crosshair", 1, true, false )
CreateClientConVar( "esp_info", 1, true, false )


Cronus["Locked"] = false;
Cronus["Hooks"] = {};
Cronus["Copy"] = { //wtf !!
	["MsgN"] = MsgN,
	["tostring"] = tostring,
	["table"] = table,
	["hook"] = hook,
	["math"] = math,
	["surface"] = surface,
	["draw"] = draw,
	["ScrW"] = ScrW,
	["ScrH"] = ScrH,
	["pairs"] = pairs,
	["util"] = util,
	["http"] = http,
	["player"] = player,
	["input"] = input,
	["ValidEntity"] = ValidEntity,
	["LocalPlayer"] = LocalPlayer,
	["GetConVarNumber"] = GetConVarNumber,
	["SetMaterialOverride"] = SetMaterialOverride,
	["CreateMaterial"] = CreateMaterial,
	["Vector"] = Vector,
	["render"] = render,
	["Material"] = Material,
	["EyePos"] = EyePos,
	["EyeAngles"] = EyeAngles,
	["cam"] = cam,
	["team"] = team,
	["ents"] = ents,
	["Color"] = Color,
	["concommand"] = concommand,
	["vgui"] = vgui,
	["string"] = string,
	["RealFrameTime"] = RealFrameTime,
};


chat.AddText(
    Color(255,0,255,255), "[Cronus] ",
    Color(0,255,0,255), "Project ",
    Color(0,255,0,255), "Cronus ",
	Color(0,255,0,255), "Version " .. Version .. " Loaded" )

	

// Aimbot

hook.Add( "Think", "No Recoil", function()
if GetConVarNumber( "aim_removerecoil" ) >= 1 then
if LocalPlayer():GetActiveWeapon().Primary then
LocalPlayer():GetActiveWeapon().Primary.Recoil = 0
		end
	end
end )

function Cronus:Hook( type, func ) //Generic hooking system. Random hook names. If the hook breaks, you're shit out of luck.
	local Name = Cronus["Copy"]["tostring"]( Cronus["Copy"]["math"]["random"]( 1, 150 ) );
	Cronus["Copy"]["MsgN"]( "Adding Hook "..Name.." ["..type.."]" );
	Cronus["Copy"]["table"]["insert"]( Cronus["Hooks"], Name );
	return Cronus["Copy"]["hook"]["Add"]( type, Name, func );
end


local function HookCreateMove( u )
	Cronus:Aimbot( u );
	Cronus:Bhop( u );
end
Cronus:Hook( "CreateMove", HookCreateMove );

Cronus["ConVars"] = {
	["aim_admins"] = CreateClientConVar( "aim_admins", 0, true );
	["aim_auto"] = CreateClientConVar( "aim_auto", 1, true );
	["aim_friendly"] = CreateClientConVar( "aim_friendly", 1, true );
	["aim_offset"] = CreateClientConVar( "aim_offset", 0, true );
	["aim_prediction"] = CreateClientConVar( "aim_prediction", 1, true );
	["aim_steam"] = CreateClientConVar( "aim_steam", 0, true );
}



local Aimspots = {
"head",
"forward",
"eyes"
}

local function Aimspot( e )
	local Pos;
	for k, v in Cronus["Copy"]["pairs"]( Aimspots ) do
		if( e:GetAttachment( e:LookupAttachment( v ) ) ) then
			Pos = e:GetAttachment( e:LookupAttachment( v ) )["Pos"];
		end
	end
	return Pos;
end

local function bIsVisible( e )
	local Trace = {};
	Trace.start = Cronus["Copy"]["LocalPlayer"]():GetShootPos();
	Trace.endpos = Aimspot( e );
	Trace.mask = MASK_SHOT|CONTENTS_HITBOX;
	Trace.filter = e, Cronus["Copy"]["LocalPlayer"]();
	local tr = Cronus["Copy"]["util"]["TraceLine"]( Trace );
	if( tr.Fraction == 1.0 ) then
		return true;
	end
end

local function bIsValid( e )
	if( !Cronus["Copy"]["ValidEntity"]( e ) || e == Cronus["Copy"]["LocalPlayer"]() ) then return false; end
	if( !e:Alive() || !e:IsPlayer() || e:InVehicle() ) then return false; end
	if( Cronus["Copy"]["GetConVarNumber"]( "sbox_noclip" ) == 0 && e:GetMoveType() == MOVETYPE_NOCLIP ) then return false; end //Noclip glitchers are gay as penis, no?
	if( Cronus["ConVars"]["aim_friendly"]:GetInt() == 0 && e:Team() == Cronus["Copy"]["LocalPlayer"]():Team() ) then return false; end
	if( Cronus["ConVars"]["aim_steam"]:GetBool() && e:GetFriendStatus() == "friend" ) then return false; end
	if( Cronus["ConVars"]["aim_admins"]:GetInt() == 0 && e:IsAdmin() ) then return false; end
	if( e:GetMoveType() == MOVETYPE_OBSERVER || e:Team() == TEAM_SPECTATOR ) then return false; end
	return true;
end

local function GetTargets()
	local Targets = { 0, 0 };
	for k, v in Cronus["Copy"]["pairs"]( Cronus["Copy"]["player"]["GetAll"]() ) do
		if( bIsVisible( v ) && bIsValid( v ) ) then
			local Diff = ( v:EyePos() - Cronus["Copy"]["LocalPlayer"]():EyePos() ):Normalize();
			Diff = Diff - Cronus["Copy"]["LocalPlayer"]():GetAimVector();
			Diff = Diff:Length();
			Diff = Cronus["Copy"]["math"]["abs"]( Diff );
			if( Diff < Targets[2] || Targets[1] == 0 ) then
				Targets = { v, Diff };
			end
		end	
	end
	return( Targets[1] != 0 && Targets[1] != Cronus["Copy"]["LocalPlayer"]() ) && Targets[1] || nil;
end

local function NormalizeAngles( Angl )
	Angl.p = Cronus["Copy"]["math"]["NormalizeAngle"]( Angl.p );
	Angl.y = Cronus["Copy"]["math"]["NormalizeAngle"]( Angl.y );
	Angl.r = 0;
end

function Cronus:Prediction( e, Pos )
	if( Cronus["ConVars"]["aim_prediction"]:GetInt() == 1 ) then
		Pos = Pos + e:GetVelocity() / 50 + Cronus["Copy"]["LocalPlayer"]():GetVelocity() / 50; 
	end
	if( Cronus["ConVars"]["aim_prediction"]:GetInt() == 2 ) then
		Pos = Pos + e:GetVelocity() * ( 1 / 66 ) - Cronus["Copy"]["LocalPlayer"]():GetVelocity() * ( 1 / 66 ); 
	end
	if( Cronus["ConVars"]["aim_prediction"]:GetInt() == 3 ) then
		Pos = Pos + e:GetVelocity() * Cronus["Copy"]["RealFrameTime"]() / 45 + Cronus["Copy"]["LocalPlayer"]():GetVelocity() * Cronus["Copy"]["RealFrameTime"]() / 45;
	end
end

function Cronus:Aimbot( u )
	if( Cronus["Copy"]["input"]["IsKeyDown"]( KEY_F ) ) then //input.IsKeyDown is gay as hell.
		local Target = GetTargets();
		if( !Target ) then return; end
		Cronus["Locked"] = true;
		local Aimspot = Aimspot( Target );
		Cronus:Prediction( Target, Aimspot );
		Aimspot = Aimspot + Cronus["Copy"]["Vector"]( 0, 0, Cronus["ConVars"]["aim_offset"]:GetFloat() );
		local Angl = ( Aimspot - Cronus["Copy"]["LocalPlayer"]():GetShootPos() ):Angle();
		NormalizeAngles( Angl );
		u:SetViewAngles( Angl );
		Cronus["Copy"]["LocalPlayer"]():GetActiveWeapon()["Recoil"] = 0;
		if( Cronus["ConVars"]["aim_auto"]:GetBool() ) then
			u:SetButtons( u:GetButtons() | IN_ATTACK );
		end
	end
	if( !Cronus["Copy"]["input"]["IsKeyDown"]( KEY_F ) ) then //Should have used an else.
		Cronus["Locked"] = false;
	end
end

// Anti Aim
hook.Add("CreateMove",1, function(cmd, u)
local C = LocalPlayer()
local v = cmd:GetViewAngles()
if GetConVarNumber( "aim_removeaa" ) >= 1 then return end;
cmd:SetViewAngles(Angle(181, v.y, -181))
end)

// Speedhack
local factor = 3.5
concommand.Add( "+Cronus_Speed", function( p, c, a )
	cvar2.SetValue( "sv_cheats", "1" )
	cvar2.SetValue( "host_timescale", factor )
end )

concommand.Add( "-Cronus_Speed", function( p, c, a )
	cvar2.SetValue( "host_timescale", "1.0" )
end )

// Bhop
function Cronus:Bhop( u )
	if( u:KeyDown( IN_JUMP ) && Cronus["Copy"]["LocalPlayer"]():IsOnGround() == false && Cronus["Copy"]["LocalPlayer"]():GetMoveType() != MOVETYPE_OBSERVER && Cronus["Copy"]["LocalPlayer"]():Team() != TEAM_SPECTATOR ) then
		u:SetButtons( u:GetButtons() - IN_JUMP );
	end
end

// Crosshair
function Crosshair()
if GetConVarNumber( "misc_crosshair" ) >= 1 then
surface.SetDrawColor( 0, 255, 0, 200 )
surface.DrawLine( x - length, y, x - gap, y )
surface.DrawLine( x + length, y, x + gap, y )
surface.DrawLine( x, y - length, x, y - gap )
surface.DrawLine( x, y + length, x, y + gap )
surface.DrawLine(ScrW() / 2 - 5 , ScrH() / 2, ScrW() / 2 + 5 , ScrH() / 2)
surface.DrawLine(ScrW() / 2 , ScrH() / 2 + 5, ScrW() / 2 , ScrH() / 2 - 5)



        end
end
hook.Add("HUDPaint","CustomCross",Crosshair)

// ESP
local function ESP()
if( GetConVarNumber( 'esp_info' ) != 0 ) then
for k, v in pairs( player.GetAll() ) do
if( v:Alive() && v != LocalPlayer() ) then
local Pos = ( v:GetPos() + Vector( 0, 0, 75 ) ):ToScreen();
surface.SetDrawColor( team.GetColor( v:Team() ) )
draw.SimpleText( v:Name(), 'TabLarge', Pos.x, Pos.y, team.GetColor( v:Team() ), TEXT_ALIGN_CENTER );
draw.SimpleText( "HP: " .. v:Health(), 'TabLarge', Pos.x, Pos.y + 10, team.GetColor( v:Team() ), TEXT_ALIGN_CENTER );
end
end
end
end
hook.Add( 'HUDPaint', 'NIGGERSHITPENIS', ESP );

// Radar
function DoChecksRadar( e )

	local ply, val = LocalPlayer(), 0
	
	if ( e:IsPlayer() && e:GetMoveType() == MOVETYPE_OBSERVER ) then return false end
	
	if ( !e:IsValid() || !e:IsPlayer() && !e:IsNPC() || e == ply ) then return false end
	if ( e:IsPlayer() && !e:Alive() ) then return false end
	if ( e:IsNPC() && e:GetMoveType() == 0 ) then return false end
	if ( e:IsWeapon() && e:GetMoveType() == 0 ) then return false end
	
	return true
	
end

	local Radar = vgui.Create( "DFrame" )
	Radar:SetSize( 300, 300 )
	
	local rW, rH, x, y = Radar:GetWide(), Radar:GetTall(), ScrW() / 2, ScrH() / 2
	
	local sW, sH = ScrW(), ScrH()
	Radar:SetPos( sW - rW - 10, sH - rH - ( sH - rH ) + 10 )
	Radar:SetTitle("Cronus Radar")
	Radar:SetVisible( true )
	Radar:SetDraggable( true )
	Radar:ShowCloseButton( false )
	Radar:MakePopup()
	Radar.Paint = function()
		draw.RoundedBox( 0, 0, 0, rW, rH, Color( 0, 0, 0, 40 ) )
		surface.SetDrawColor( 255, 255, 255, 255 )
		surface.DrawOutlinedRect( 0, 0, rW, rH )
		
		local ply = LocalPlayer()
		
		local radar = {}
		radar.h		= 300
		radar.w		= 300
		radar.org	= 5000
		
		local x, y = ScrW() / 2, ScrH() / 2
		
		local half = rH / 2
		local xm = half
		local ym = half
		
		surface.DrawLine( xm, ym - 100, xm, ym + 100 )
		surface.DrawLine( xm - 100, ym, xm + 100, ym )
		
		for k, e in pairs( ents.GetAll() ) do
			if ( DoChecksRadar(e) ) then
				
				local s = 6
				local col = {}
				local color = Color( 255,255,255,200 )
				local plyfov = ply:GetFOV() / ( 70 / 1.13 )
				local zpos, npos = ply:GetPos().z - ( e:GetPos().z ), ( ply:GetPos() - e:GetPos() )
				
				npos:Rotate( Angle( 180, ( ply:EyeAngles().y ) * -1, -180 ) )
				local iY = npos.y * ( radar.h / ( ( radar.org * ( plyfov  * ( ScrW() / ScrH() ) ) ) + zpos * ( plyfov  * (ScrW() / ScrH() ) ) ) )
				local iX = npos.x * ( radar.w / ( ( radar.org * ( plyfov  * ( ScrW() / ScrH() ) ) ) + zpos * ( plyfov  * (ScrW() / ScrH() ) ) ) )
				
				
				local pX = ( radar.w / 2 )
				local pY = ( radar.h / 2 )
				
				local posX = pX - iY - ( s / 2 )
				local posY = pY - iX - ( s / 2 )
				
				local text = e:GetClass()
				
				if ( e:IsPlayer() ) then 
					text = e:Nick() .. " ["..e:Health().."]"
				end
				
				if iX < ( radar.h / 2 ) && iY < ( radar.w / 2 ) && iX > ( -radar.h / 2 ) && iY > ( -radar.w / 2 ) then
				
					draw.RoundedBox( s, posX, posY, s, s, color )

				end
			end
		end
	end
	
	Radar:SetVisible( true )
	Radar:SetMouseInputEnabled( false )
	Radar:SetKeyboardInputEnabled( false )
	concommand.Add( "+mouseenable", function() Radar:SetMouseInputEnabled( true ) end )
	concommand.Add( "-mouseenable", function() Radar:SetMouseInputEnabled( false ) end )
	
	RRadar = Radar

-- maybe i'll add more here.

