local w,h=ScrW(),ScrH()
local w2,h2=w/2,h/2
local LocalPlayer_=LocalPlayer()

-- wins&losses
if not file.Exists("geralds_wins_and_losses.txt","DATA") then
	local x={w=0,l=0} 
	file.Write("geralds_wins_and_losses.txt", util.TableToJSON(x,true)) 
end
local w_l=util.JSONToTable(file.Read("geralds_wins_and_losses.txt", "DATA"))
geralds_prop_wins=w_l.w or 0
geralds_prop_loses=w_l.l or 0

local function addwinloss(win_or_lose)
	if win_or_lose then
		geralds_prop_wins=geralds_prop_wins+1
	else
		geralds_prop_loses=geralds_prop_loses+1
	end
	local x={w=geralds_prop_wins,l=geralds_prop_loses}
	file.Write("geralds_wins_and_losses.txt", util.TableToJSON(x,true))
end

net.Receive( "props_FightResults", function()
	local battler1 = net.ReadTable()
	local battler2 = net.ReadTable()
	local winner = net.ReadString()
	local score = net.ReadString()
	local time = net.ReadString()
	if battler1.Steamid==LocalPlayer_:SteamID() or battler2.Steamid==LocalPlayer_:SteamID() then
		if winner==LocalPlayer_:Nick() then
			addwinloss(true)
		else
			addwinloss(false)
		end
	end
end)

-- propkill commands
LocalPlayer_:ConCommand("cl_interp 0;cl_interp_ratio 0;cl_updaterate 1000")

-- nodraw things
hook.Add("PostDrawSkyBox", "nosky", function()
	render.Clear(0,0,0,0,false,true)
end)

-- quake physgun
hook.Add("CalcViewModelView", "gayname", function(wep,vm,oldpos,oldang,pos,ang)
	local newpos=pos-(vm:GetRight()*8)
	local newpos=newpos-(vm:GetForward()*0)
	local newpos=newpos-(vm:GetUp()*6)
	return newpos,oldang
end)

-- transparent corner wall
local corner_wall=Material("realworldtextures/newer/0/bricks_0_16")
corner_wall:SetFloat("$alpha", 0.5)

-- 120 fov
hook.Add("CalcView", "high_fov", function(ply,pos,angles,fov)
	local v={
		origin=pos,
		angles=angles,
		fov=125
	}
	return v
end)

-- black&white xray
local blackwhite = {
	["$pp_colour_contrast"] = 0.5,
	["$pp_colour_colour"] = 0.2
}

CreateMaterial("xraymat", "UnlitGeneric",
{	["$basetexture"]="color/white",
	["$model"]=1,
	["$translucent"]=1,
	["$alpha"]=1,
	["$nocull"]=1,
	["$ignorez"]=1
})

local prop_color=Color(100,100,255,100)
local ply_color=Color(255,255,255,100)
local white=Color(0,0,0,255)



hook.Add("HUDPaint", "boxes", function()
	local props=ents.FindByClass("prop_physics")
	local plys=player.GetAll()
	cam.Start3D()
	render.OverrideDepthEnable(true,true)
	for i=1,#plys do
		local ply=plys[i]
		if ply==LocalPlayer_ or not ply:Alive() or ply:Team()==1 then continue end
		render.DrawWireframeBox(ply:GetPos(), ply:GetAngles(), ply:OBBMins(), ply:OBBMaxs(), white)
		render.SetColorMaterialIgnoreZ()
		render.DrawBox(ply:GetPos(),ply:GetAngles(),ply:OBBMins(),ply:OBBMaxs(),ply_color)
	end
	for i=1,#props do
		local prop=props[i]
		render.DrawWireframeBox(prop:GetPos(), prop:GetAngles(), prop:OBBMins(), prop:OBBMaxs(), white)
		render.SetColorMaterialIgnoreZ()
		render.DrawBox(prop:GetPos(),prop:GetAngles(),prop:OBBMins(),prop:OBBMaxs(),prop_color)
	end
	render.OverrideDepthEnable(false, false)
	cam.End3D()
end)

-- top velocity
geralds_top_velocity=geralds_top_velocity or 0
timer.Create("velocity_check", 0.3, 0, function()
	local vel=math.Round(LocalPlayer_:GetVelocity():Length())
end)

-- prop counter
local propz=file.Read("geralds_propkill.txt","DATA") or 0
geralds_prop_count=tonumber(propz)

local function logaprop()
	if not file.Exists("geralds_propkill.txt","DATA") then file.Write("geralds_propkill.txt", "0") end
	geralds_prop_count=geralds_prop_count+1
	file.Write("geralds_propkill.txt", tostring(geralds_prop_count))
end


-- esp
hook.Add("HUDPaint", "esp", function()
	draw.SimpleText("propkill | " .. (geralds_prop_count or "0") .. " props spawned | " .. geralds_top_velocity .. " top velocity | " .. geralds_prop_wins .. "-" .. geralds_prop_loses,"BudgetLabel",w*.005,h*.005,Color(255,255,100))
	local plys=player.GetAll()
	surface.DrawCircle(w2,h2,5,Color(255,255,255,255))
	for i=1,#plys do
		local ply=plys[i]
		if ply==LocalPlayer_ or ply:Team()==1 or not ply:Alive() then continue end
		local ps=(ply:LocalToWorld(ply:OBBCenter())):ToScreen()
		local headpos,feetpos=ply:GetShootPos():ToScreen(),ply:GetPos():ToScreen()
		local size=math.Clamp((feetpos.y-headpos.y)/4,4,12)
		local c=team.GetColor(ply:Team())
		draw.RoundedBox(12,ps.x-size/2, ps.y-size/2, size,size,Color(c.r,c.g,c.b))
	end
end)

-- bhop

hook.Add("Think", "dsgdfgxds", function()
    if LocalPlayer():GetMoveType() == MOVETYPE_NOCLIP then return end
		if (input.IsKeyDown(KEY_SPACE)) then
			if LocalPlayer():IsOnGround() then
				if LocalPlayer():IsTyping() then return end
					RunConsoleCommand("+jump")
					jumped = 1
				else
					RunConsoleCommand("-jump")
					jumped = 0
			end
			elseif LocalPlayer():IsOnGround() then
				if jumped == 1 then
					RunConsoleCommand("-jump")
					jumped = 0
		end
	end
end)

-- rotations
concommand.Add("props_180", function(ply)
	local eye=ply:EyeAngles()
	ply:SetEyeAngles(Angle(eye.p,eye.y-180,eye.r))
	surface.PlaySound("npc/zombie/claw_miss"..math.random(1,2)..".wav")
end)

concommand.Add("props_180up", function(ply)
	local eye=ply:EyeAngles()
	ply:SetEyeAngles(Angle(-eye.p,eye.y-180,eye.r))
	RunConsoleCommand("+jump")
	timer.Simple(0.2, function() RunConsoleCommand("-jump") end)
	surface.PlaySound("npc/zombie/claw_miss"..math.random(1,2)..".wav")
end)

concommand.Add("props_180shot", function(ply)
	local w=hook.GetTable().CalcView and hook.GetTable().CalcView["180shot"]
	local eye=ply:EyeAngles()

	if not ply:KeyDown(IN_ATTACK) then
		ply:SetEyeAngles(Angle(eye.p,eye.y-180,eye.r))
		return
	end

	if w then
		ply:SetEyeAngles(Angle(eye.p,eye.y-180,eye.r))
		hook.Remove("CalcView","180shot")
		timer.Remove("180shot")
		return
	end

	hook.Add("CalcView", "180shot", function(ply,pos,ang,fov)
		local v={
			origin=pos,
			angles=ang-Angle(0,180,0),
			fov=120
		}
		if not ply:KeyDown(IN_ATTACK) then
			hook.Remove("CalcView","180shot")
			local eye=ply:EyeAngles()
			ply:SetEyeAngles(Angle(eye.p,eye.y-180,eye.r))
			timer.Remove("180shot")
		end
		return v
	end)

	ply:SetEyeAngles(Angle(eye.p,eye.y-180,eye.r))
	timer.Create("180shot",5,1,function()
		hook.Remove("CalcView","180shot")
		ply:SetEyeAngles(Angle(eye.p,eye.y-180,eye.r))
	end)
	surface.PlaySound("npc/zombie/claw_miss"..math.random(1,2)..".wav")
end)

-- fps cmds
LocalPlayer_:ConCommand("gmod_mcore_test 1")
LocalPlayer_:ConCommand("r_cleardecals;r_decals 0")
LocalPlayer_:ConCommand("r_queued_ropes 1")
LocalPlayer_:ConCommand("cl_threaded_bone_setup 1")
LocalPlayer_:ConCommand("cl_threaded_client_leaf_system 1")
LocalPlayer_:ConCommand("mat_queue_mode -1")
LocalPlayer_:ConCommand("r_threaded_renderables 1")
LocalPlayer_:ConCommand("r_threaded_particles 1")
LocalPlayer_:ConCommand("rope_rendersolid 0")




surface.CreateFont("font", {
    font = "Verdana",
    size = 17.5,
    antialias = false,
    outline = true
})



--[[===============
        LOCALS
===================]]

local Visuals = {}

--[[===============
    FUNCTIONS
===================]]

local function GetSortedPlayers()
	local ret = {}
	
	for _, v in ipairs(player.GetAll()) do
		ret[#ret + 1] = v
	end
	
	local lpos = LocalPlayer():GetPos()
	
	table.sort(ret, function(a, b)
		return a:GetPos():DistToSqr(lpos) > b:GetPos():DistToSqr(lpos)
	end)
	
	return ret
end



function Visuals.tesp()
    for k, v in pairs( GetSortedPlayers() ) do 
		if v:IsValid() and not v:IsDormant() then
			if v:IsPlayer() and v ~= LocalPlayer() and v:Alive() and LocalPlayer():GetObserverMode() == 0 and v:Team() ~= TEAM_SPECTATOR then

                local teamcol = team.GetColor( v:Team() )
                local vposx = v:EyePos():ToScreen().x
                local vposy = v:EyePos():ToScreen().y

                draw.SimpleText( v:Name(), 'font', vposx, vposy - 0, Color( 255, 255, 255 ), 1, 1, 1 )

            end
        end
    end
end


hook.Add( 'HUDPaint', 'whatfuck', function()
    Visuals.tesp()
end)