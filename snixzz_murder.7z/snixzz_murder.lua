/*
	
	sMurder.lua
	snixzz.net OFFICIAL "Murder" script
	
	Author: 0xymoron
	Release: Public
	
*/

local SM = { tCopy = table.Copy, -- wtf!!!!!!
	
	Version = "0.1 Alpha",
	
	Weapons = { -- Suspect weapons
		
		"weapon_mu_knife",
		"weapon_mu_magnum",
	
	},
	
	Suspects = {},
		
}

local g = SM.tCopy( _G )
local r = g.debug.getregistry()

g.gameevent.Listen( "entity_killed" )

-- Get all suspected murders
function SM.GetSuspects()
	
	for k, v in g.next, g.player.GetAll() do
		
		for _, wep in g.next, v:GetWeapons() do
			
			if SM.Weapons[r.Entity.GetClass( wep )] then
				
				g.table.insert( SM.Suspects, v )
				
			end
		
		end
	
	end
	--return SM.Suspects or {}	
end

function SM.PlayerDeath( data )
	
	MsgN( g.Player( data.entindex_inflictor ):Nick() )
	
	--g.table.insert( SM.Suspects, data.entindex_attacker )
	
	/*g.chat.AddText(
		g.Color( 0, 255, 255 ), "[sMurder] ",
		g.Color( 255, 255, 255 ), "Player ",
		g.Color( 205, 68, 0 ), data.entindex_killed:Nick(),
		g.Color( 255, 255, 255 ), " was ",
		g.Color( 255, 0, 0 ), "killed by ",
		g.Color( 0, 255, 0 ), data.entindex_inflictor:Nick()
	)*/

end

function SM.NewRound()
	
	SM.Suspects = {}
	
	g.chat.AddText( 
		g.Color( 0, 255, 255 ), "[sMurder] ",
		g.Color( 255, 255, 255 ), "Round restarted, suspects reset."
	)
	
end

g.net.Receive( "DeclareWinner", function()
	
	SM.NewRound()
	
end )
	
local pos
function SM.HUDPaint()
	
	SM.GetSuspects()
	
	for k, v in g.next, SM.Suspects do
		
		if v != g.LocalPlayer() && v:Alive() && v:Team() != g.TEAM_SPECTATOR then
		
			pos = v:GetPos():ToScreen()
			
			g.draw.SimpleText( 
				v:Nick(), 
				"default",
				pos.x, pos.y, 
				g.team.GetColor( v:Team() ), 
				g.TEXT_ALIGN_CENTER, g.TEXT_ALIGN_CENTER 
			)
				
			g.draw.SimpleText( 
				"*SUSPECT*", 
				"default",
				pos.x, pos.y - 11, 
				g.Color( 255, 0, 0 ), 
				g.TEXT_ALIGN_CENTER, g.TEXT_ALIGN_CENTER 
			)	
			
		end
	
	end
	
end

g.hook.Add( "entity_killed", g.tostring( SM.PlayerDeath ), SM.PlayerDeath )
g.hook.Add( "HUDPaint", g.tostring( SM.HUDPaint ), SM.HUDPaint )
