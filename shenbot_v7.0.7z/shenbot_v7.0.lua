--[[
	MOD/lua/damage.lua [#22993 (#22993), 3366476473, UID:508514163]
	hrst | STEAM_0:1:89973919 <2.51.85.155:27005> | [12.06.14 04:39:16PM]
	===BadFile===
]]

	

    string = string
    math = math
    table = table
    hook = hook
    player = player
    surface = surface
    draw = draw
    team = team
    concommand = concommand
    util = util
     
    Angle = Angle
    Vector = Vector
    Color = Color
    Entity = Entity
    Player = Player
    LocalPlayer = LocalPlayer
    IsValid = IsValid
    pairs = pairs
    ipairs = ipairs
    ScrW = ScrW
    ScrH = ScrH
     
    surface.SetFont("Trebuchet18")
     
    local MySelf = LocalPlayer()
    local W, H = ScrW(), ScrH()
    local w, h = surface.GetTextSize("O.")
     
    if (SHENBOT) then -- Check if another instance is running.
            for k, v in pairs (SHENBOT.Hooks) do
                    for _, va in pairs (SHENBOT.Hooks[k]) do
                            hook.Remove(k, va)
                    end
            end
    end
     
    SHENBOT = SHENBOT or {}
    SHENBOT.Hooks = {}
    SHENBOT.HookLength = 8
    SHENBOT.Menu = SHENBOT.Menu or false
    SHENBOT.Target = NULL
    SHENBOT.View = Angle(0, 0, 0)
    SHENBOT.Props = {"money_printer", "special_printer"}
     
    SHENBOT.Bone = SHENBOT.Bone or "ValveBiped.Bip01_Spine2"
    SHENBOT.Aimbot = SHENBOT.Aimbot or false
    SHENBOT.AimbotHard = SHENBOT.AimbotHard or false
    SHENBOT.NoRecoil = SHENBOT.NoRecoil or false
    SHENBOT.Chams = SHENBOT.Chams or false
    SHENBOT.ESP = SHENBOT.ESP or false
    SHENBOT.ESPInfo = SHENBOT.ESPInfo or false
    SHENBOT.Crosshair = SHENBOT.Crosshair or false
    SHENBOT.Bhopping = SHENBOT.Bhopping or false
     
    SHENBOT.Commands = {}
    SHENBOT.Commands[1] = {
            Name = "Aimbot",
            Cmd = "slot1",
            Value = "Aimbot",
            Callback = function(cmd)
                    SHENBOT.Aimbot = !SHENBOT.Aimbot
                    SHENBOT[cmd.Value] = SHENBOT.Aimbot
            end
    }
    SHENBOT.Commands[2] = {
            Name = "Aimbot HARD",
            Cmd = "slot2",
            Value = "AimbotHard",
            Callback = function(cmd)
                    SHENBOT.AimbotHard = !SHENBOT.AimbotHard
                    SHENBOT[cmd.Value] = SHENBOT.AimbotHard
            end
    }
    SHENBOT.Commands[3] = {
            Name = "No Recoil",
            Cmd = "slot3",
            Value = "NoRecoil",
            Callback = function(cmd)
                    SHENBOT.NoRecoil = !SHENBOT.NoRecoil
                    SHENBOT[cmd.Value]= SHENBOT.NoRecoil
            end
    }
    SHENBOT.Commands[4] = {
            Name = "Bone",
            Cmd = "slot4",
            Value = "Bone",
            Callback = function(cmd)
                    SHENBOT:OpenBoneFrame()
                    SHENBOT[cmd.Value] = SHENBOT.Bone
            end
    }
    SHENBOT.Commands[5] = {
            Name = "Chams",
            Cmd = "slot5",
            Value = "Chams",
            Callback = function(cmd)
                    SHENBOT.Chams = !SHENBOT.Chams
                    SHENBOT[cmd.Value] = SHENBOT.Chams
            end
    }
    SHENBOT.Commands[6] = {
            Name = "ESP",
            Cmd = "slot6",
            Value = "ESP",
            Callback = function(cmd)
                    SHENBOT.ESP = !SHENBOT.ESP
                    SHENBOT[cmd.Value] = SHENBOT.ESP
            end
    }
    SHENBOT.Commands[7] = {
            Name = "ESP Info",
            Cmd = "slot7",
            Value = "ESPInfo",
            Callback = function(cmd)
                    SHENBOT.ESPInfo = !SHENBOT.ESPInfo
                    SHENBOT[cmd.Value] = SHENBOT.ESPInfo
            end
    }
    SHENBOT.Commands[8] = {
            Name = "Crosshair",
            Cmd = "slot8",
            Value = "Crosshair",
            Callback = function(cmd)
                    SHENBOT.Crosshair = !SHENBOT.Crosshair
                    SHENBOT[cmd.Value] = SHENBOT.Crosshair
            end
    }
    SHENBOT.Commands[9] = {
            Name = "Bhop",
            Cmd = "slot9",
            Value = "Bhopping",
            Callback = function(cmd)
                    SHENBOT.Bhopping = !SHENBOT.Bhopping
                    SHENBOT[cmd.Value] = SHENBOT.Bhopping
            end
    }
     
    local function GetMeta(name)
            return FindMetaTable(name)
    end
     
    local AngM = GetMeta("Angle")
    local CmdM = GetMeta("CUserCmd")
    local EntM = GetMeta("Entity")
    local PlyM = GetMeta("Player")
    local VecM = GetMeta("Vector")
     
    local function istrue(val, str1, str2)
            if (val == true) then
                    return str1
            end
           
            return str2
    end
     
    function SHENBOT:AngleBetween(a, b)
            return math.deg(math.acos(VecM["Dot"](a, b)))
    end
     
    function SHENBOT:BaseBlocked(target, offset)
            local ply = LocalPlayer()
            if (!IsValid(ply)) then return end
     
            local shootPos = PlyM["GetShootPos"](ply)
            local targetPos = self:TargetPosition(target)
           
            if (offset) then targetPos = targetPos + offset end
     
            local trace = util.TraceLine({start = shootPos, endpos = targetPos, filter = {ply, target}, mask = MASK_SHOT})
            local wrongAim = self:AngleBetween(PlyM["GetAimVector"](ply), VecM["GetNormal"](targetPos - shootPos)) > 2
     
            if (trace.Hit && trace.Entity != target) then
                    return true, wrongAim
            end
     
            return false, wrongAim
    end
     
    function SHENBOT:SetTarget(ent)
            self.Target = ent
    end
     
    function SHENBOT:GetTarget()
            if (IsValid(SHENBOT.Target) != false) then
                    return self.Target
            else
                    return false
            end
    end
     
    function SHENBOT:GetView()
            return self.View * 1
    end
     
    function SHENBOT:IsValidTarget(ent)
            local typename = type(ent)
            if (typename != "NPC" && typename != "Player") then return false end
     
            if (!IsValid(ent)) then return false end
     
            local ply = LocalPlayer()
            if (ent == ply) then return false end
     
            if (typename == "Player") then
                    if (!PlyM["Alive"](ent)) then return false end
                    if (EntM["GetMoveType"](ent) == MOVETYPE_OBSERVER) then return false end
                    if (EntM["GetMoveType"](ent) == MOVETYPE_NONE) then return false end
            end
     
            if (typename == "NPC") then
                    if (EntM["GetMoveType"](ent) == MOVETYPE_NONE) then return false end
     
                    local model = string.lower(EntM["GetModel"](ent) or "")
                    if (table.HasValue(self.NPCDeathSequences[model] or {}, EntM["GetSequence"](ent))) then return false end
            end
    end
     
    function SHENBOT:BaseTargetPosition(ent)
            if (type(ent) == "Player") then
                    if (ent.ph_prop) then
                            return EntM["GetPos"](ent.ph_prop)
                    end
           
            local bone = self.Bone
            local head = EntM["LookupBone"](ent, bone)
                    if (head) then
                            local pos = EntM["GetBonePosition"](ent, head)
                            if pos then
                                    return pos
                            end
                    end
            end
     
            local special = self.ModelTarget[string.lower(EntM["GetModel"](ent) or "")]
            if (special) then
                    if type(special) == "string" then
                            local bone = EntM["LookupBone"](ent, special)
                            if (bone) then
                                    local pos = EntM["GetBonePosition"](ent, bone)
                                    if (pos) then
                                            return pos
                                    end
                            end
                    elseif (type(special) == "Vector") then
                            return EntM["LocalToWorld"](ent, special)
                    elseif (type(special) == "function") then
                            local pos = pcall(special, ent)
                            if (pos) then return pos end
                    end
            end
     
            local bone = self.Bone
            local head = EntM["LookupBone"](ent, bone)
            if (head) then
                    local pos = EntM["GetBonePosition"](ent, head)
                    if pos then
                            return pos
                    end
            end
     
            return EntM["LocalToWorld"](ent, EntM["OBBCenter"](ent))
    end
     
    function SHENBOT:TargetPosition(ent)
            local targetPos = self:BaseTargetPosition(ent)
           
            local ply = LocalPlayer()
            if (IsValid(ply)) then
                    local weap = PlyM["GetActiveWeapon"](ply)
                    if (IsValid(weap)) then
                            local class = EntM["GetClass"](weap)
                            if (class == "weapon_crossbow") then
                                    local dist = VecM["Length"](targetPos - PlyM["GetShootPos"](ply))
                                    local time = (dist / 3500) + 0.05 // About crossbow bolt speed.
                                    targetPos = targetPos + (EntM["GetVelocity"](target) * time)
                            end
                           
                            local mul = 0.0075
                    end
            end
           
            return targetPos
    end
     
    function SHENBOT:CreateHook(type, func)
            local str = ""
           
            for i = 1, SHENBOT.HookLength do
                    if (math.random(1, 2) == 2) then
                            str = str .. string.char(math.random(97, 122))
                    else
                            str = str .. string.char(math.random(65, 90))
                    end
            end
           
            // Register the hook in a table.
            if not (SHENBOT.Hooks[type]) then
                    SHENBOT.Hooks[type] = {}
            end
            table.insert(SHENBOT.Hooks[type], str)
     
            hook.Add(type, str, func)
    end
     
    // Menu
    SHENBOT:CreateHook("HUDPaint", function()
            local x, y = 50, 50
            if (!SHENBOT.Menu) then return end
     
            surface.SetFont("Trebuchet18")
            surface.SetTextColor(255, 255, 255, 255)
     
            draw.RoundedBox(0, x, y, 200, 25 + #SHENBOT.Commands * 25, Color(0, 0, 0, 175))
           
            surface.SetTextPos(x + 5, y + 5)
            surface.DrawText("ShenBot")
           
            local i = 1
            for k, v in pairs (SHENBOT.Commands) do
                    local val = SHENBOT[v.Value]
                    if (type(val) == "boolean") then
                            val = istrue(val, "Enabled", "Disabled")
                    end
           
                    y = y + 25
                   
                    surface.SetTextPos(x + 5, y + 5)
                    surface.DrawText(i .. ". " .. v.Name .. ": " .. val)
                   
                    i = i + 1
            end
    end)
     
    SHENBOT:CreateHook("PlayerBindPress", function(ply, bind, press)
            if (!SHENBOT.Menu) then return end
     
            for k, v in pairs (SHENBOT.Commands) do
                    if (v.Cmd == bind) then
                            v.Callback(v)
                            return false
                    end
            end
    end)
     
    /**************************************************
            Menus
    **************************************************/
    function SHENBOT:OpenBoneFrame()
            local frame = vgui.Create("DFrame")
            frame:SetSize(150, 50)
            frame:Center()
            frame:SetTitle("Choose target bone")
            frame:MakePopup()
           
            local bones = vgui.Create("DComboBox", frame)
            bones:SetWide(130)
            bones:CenterHorizontal()
            bones:AlignTop(25)
            bones.OnSelect = function(me, index, value, data)
                    SHENBOT.Bone = value
            end
           
            local bns = {"ValveBiped.Bip01_Head1",
                                    "ValveBiped.Bip01_Neck1",
                                    "ValveBiped.Bip01_Spine4",
                                    "ValveBiped.Bip01_Spine2",
                                    "ValveBiped.Bip01_Spine1",
                                    "ValveBiped.Bip01_Spine",
                                    "ValveBiped.Bip01_R_UpperArm",
                                    "ValveBiped.Bip01_R_Forearm",
                                    "ValveBiped.Bip01_R_Hand",
                                    "ValveBiped.Bip01_L_UpperArm",
                                    "ValveBiped.Bip01_L_Forearm",
                                    "ValveBiped.Bip01_L_Hand",
                                    "ValveBiped.Bip01_R_Thigh",
                                    "ValveBiped.Bip01_R_Calf",
                                    "ValveBiped.Bip01_R_Foot",
                                    "ValveBiped.Bip01_R_Toe0",
                                    "ValveBiped.Bip01_L_Thigh",
                                    "ValveBiped.Bip01_L_Calf",
                                    "ValveBiped.Bip01_L_Foot",
                                    "ValveBiped.Bip01_L_Toe0"}
                                   
            for k, v in pairs (bns) do
                    bones:AddChoice(v)
            end
    end
     
    /**************************************************
            ESP
    **************************************************/
    SHENBOT:CreateHook("HUDPaint", function()
            if (SHENBOT.Crosshair) then
                    surface.SetDrawColor(255, 0, 0, 255)
                    surface.DrawLine(ScrW() / 2 - 10, ScrH() / 2, ScrW() / 2 + 11, ScrH() / 2)
                    surface.DrawLine(ScrW() / 2 - 0, ScrH() / 2 - 10, ScrW() / 2 - 0, ScrH() / 2 + 11)
            end
            if (SHENBOT.ESP) then
                    cam.Start3D(EyePos(), EyeAngles())
                            for k, ply in pairs (player.GetAll()) do
                                    if (ply:Alive() && (IsValid(ply) && ply != LocalPlayer())) then
                                            local pos = ply:GetPos()
                                            local width = 32
                                            local height = 70
                                            local scale = 1
                                            local ang = EyeAngles()
                                            ang.p = ang.p - 90
                                            pos = pos - (ang:Right() * (width / 2))
                                            cam.Start3D2D(pos, ang, (1 / scale))
                                                    surface.SetDrawColor(team.GetColor(ply:Team()))
                                                    surface.DrawOutlinedRect(0, 0, (height * scale), (width * scale))
                                            cam.End3D2D()
                                    end
                            end
                    cam.End3D()
            end
     
            if (SHENBOT.ESPInfo) then
                    for k, v in pairs (player.GetAll()) do
                            if (v:Alive() && v != LocalPlayer()) then
                                    local Pos = (v:GetPos() + Vector(0, 0, 100)):ToScreen()
                                    local dist = v:GetPos():Distance(LocalPlayer():GetPos())
                                    local InfoCol = team.GetColor(v:Team())
                                    draw.SimpleText("Name: " .. v:Name(), "Tohoma", Pos.x, Pos.y, InfoCol, TEXT_ALIGN_CENTER)
                                    draw.SimpleText("HP: " .. v:Health(), "Tohoma", Pos.x, Pos.y + 12, InfoCol, TEXT_ALIGN_CENTER)
                                    draw.SimpleText("Distance: " .. math.floor(dist), "Tohoma", Pos.x, Pos.y + 22, InfoCol, TEXT_ALIGN_CENTER)
                            end
                    end
            end
    end)
     
    /**************************************************
            Chams
    **************************************************/
    local function makemat()       
            local texture = {
                    ["$basetexture"] = "models/debug/debugwhite",
                    ["$model"]       = 1,
                    ["$translucent"] = 1,
                    ["$alpha"]       = 1,
                    ["$nocull"]      = 1,
                    ["$ignorez"]     = 1
            }
            local material = CreateMaterial("esp_solid", "VertexLitGeneric", texture)
            return material
    end
     
    SHENBOT:CreateHook("HUDPaint", function()
            local Div = (1 / 255)
            local m = makemat()
            if (SHENBOT.Chams) then
                    for k, v in pairs (ents.GetAll()) do
                            if (v:IsValid() and table.HasValue(SHENBOT.Props, v:GetClass())) then
                                    cam.Start3D(EyePos(), EyeAngles())
                                            local TCol = Color(255, 255, 255, 255)
                                            render.SuppressEngineLighting(true)
                                                    render.SetColorModulation((TCol.r * Div), (TCol.g * Div), (TCol.b * Div))
                                                            render.MaterialOverride(m)
                                                            v:DrawModel()
                                                    render.SuppressEngineLighting(false)
                                            render.SetColorModulation(1, 1, 1)
                                            render.MaterialOverride()
                                    cam.End3D()
                            end
                    end
                    for k, v in pairs (player.GetAll()) do
                            if (IsValid(v) and v:Health() > 0 and v:Team() != TEAM_SPECTATOR) then
                                    cam.Start3D(EyePos(), EyeAngles())
                                            local TCol = team.GetColor(v:Team())
                                            render.SuppressEngineLighting(true)
                                                    render.SetColorModulation((TCol.r * Div), (TCol.g * Div), (TCol.b * Div))
                                                            render.MaterialOverride(m)
                                                            v:DrawModel()
                                                    render.SuppressEngineLighting(false)
                                            render.SetColorModulation(1, 1, 1)
                                            render.MaterialOverride()
                                    cam.End3D()
                            end
                    end
            end
    end)
     
    /**************************************************
            No Recoil & Aimbot
    **************************************************/
    SHENBOT:CreateHook("Think", function()
            local ply = LocalPlayer()
            if (!IsValid(ply)) then return end
           
            if (SHENBOT.Target and SHENBOT.Target:IsValid()) then
                    local target = SHENBOT.Target
                    if (!SHENBOT.Aimbot or
                            !target:Alive()) then
                            SHENBOT.Target = NULL
                    end
            end
           
            if (SHENBOT.Target and SHENBOT.Target:IsValid()) then return end
           
            local tr = ply:GetEyeTrace()
            if (tr.HitNonWorld and tr.Entity and tr.Entity:IsValid()) then
                    if (tr.Entity:IsPlayer()) then
                            SHENBOT.Target = tr.Entity
                    end
            end
    end)
     
    SHENBOT:CreateHook("Think", function(cmd)
            local ply = LocalPlayer()
            if (SHENBOT.NoRecoil) then
                    -- ply:SetEyeAngles(EyeAngles())
            end
           
            if (SHENBOT.Aimbot) then
                    local view = SHENBOT:GetView()
                    local target = SHENBOT:GetTarget()
                    if (target) then
                            local targetPos = SHENBOT:TargetPosition(target)
                            ply:SetEyeAngles((targetPos - ply:GetShootPos()):Angle())
                    end
            end
    end)
     
    SHENBOT:CreateHook("CreateMove", function(cmd)
            local ply = LocalPlayer()
           
            if (SHENBOT.NoRecoil) then
                    cmd:SetViewAngles(EyeAngles())
            end
     
            if (SHENBOT.AimbotHard) then
                    local view = SHENBOT:GetView()
                    local target = SHENBOT:GetTarget()
                    if (target) then
                            local targetPos = SHENBOT:TargetPosition(target)
                            local aim = (targetPos - ply:GetShootPos()):Angle()
                           
                            CmdM["SetViewAngles"](cmd, aim)
                            local sensitivity = 0.22
                            local diff = aim - CmdM["GetViewAngles"](cmd)
                            CmdM["SetMouseX"](cmd, diff.y / sensitivity)
                            CmdM["SetMouseY"](cmd, diff.p / sensitivity)
                    end
            end
    end)
     
    SHENBOT:CreateHook("CalcView", function(ply, origin, angles, fov)
            if (SHENBOT.NoRecoil) then
                    return {angles = LocalPlayer():EyeAngles()}
            end
    end)
     
    /**************************************************
            Bhop
    **************************************************/
    local bhop = false
    SHENBOT:CreateHook("Think", function()
            local ply = LocalPlayer()
            if (SHENBOT.Bhopping) then
                    RunConsoleCommand((bhop and "+" or "-") .. "jump")
                    bhop = !bhop
            end
    end)
     
    /**************************************************
            Concommands
    **************************************************/
    concommand.Add("sb_menu", function()
            SHENBOT.Menu = !SHENBOT.Menu
    end)
     
    concommand.Add("bhop", function()
            SHENBOT.Bhopping = !SHENBOT.Bhopping
            RunConsoleCommand("-jump")
    end)
     
    concommand.Add("+aim", function()
            SHENBOT.Aimbot = true
    end)
     
    concommand.Add("-aim", function()
            SHENBOT.Aimbot = false
    end)
     
    concommand.Add("+aimhard", function()
            SHENBOT.AimbotHard = true
    end)
     
    concommand.Add("-aimhard", function()
            SHENBOT.AimbotHard = false
    end)

