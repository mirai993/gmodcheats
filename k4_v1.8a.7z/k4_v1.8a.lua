--[[
	MOD/lua/work/client/LK0N4T4.lua [#29202 (#29202), 3249395436, UID:888933180]
	ᴘ★ᴍғ | STEAM_0:1:83324734 <99.238.15.33:27005> | [04.05.14 03:28:23PM]
	===BadFile===
]]

if SERVER then return end

// Little piece of C+P from k4 because I'm lazy.
function AddCMD(Name,Function)
	K0N4T4Print("[ADDED] ConCommand: "..Name.."")
	return old_ccadd(Name,Function)
end

function AddConVar(convar,str,save,data)
	return CreateClientConVar("k4_"..convar,str,true,false), K0N4T4Print("[ADDED] ConVar: k4_"..convar.." ["..str.."]")
end

function K0N4T4Print(msg)
	print("[K0N4T4] "..msg)
end

local g = table.Copy(_G)

/*
Shortcuts, shortcuts everywhere
*/

local colors				= {}
red						= Color(255,0,0,255);
black						= Color(0,0,0,255);
green						= Color(0,255,0,255);
white						= Color(255,255,255,255);
blue						= Color(0,0,255,255);
cyan						= Color(0,255,255,255);
pink 						= Color(255,0,255,255);
blue						= Color(0,0,255,255);
grey						= Color(100,100,100,255);
gold						= Color(255,228,0,255);
lblue						= Color(155,205,248);
lgreen						= Color(174,255,0);
iceblue						= Color(116,187,251,255);
purple  					= Color(255,0,255,255);

function MakeCVar(convar, str, save, data)
	return CreateClientConVar(convar, str, true, false)
end


/***********************
ConVar's
***********************/
-- AIM BOT --
local dBotOn     = MakeCVar("k4_aimbot", "1", true, false)
local boneaim    = MakeCVar("k4_aimbot_bone", "ValveBiped.Bip01_Head1", true, false)
local K0N4T4     = MakeCVar("k4_aimbot_onshoot", "0", true, false)
local infov1     = MakeCVar("k4_aimbot_distance", 0, true, false)
local infov2     = MakeCVar("k4_aimbot_fov", 90, true, false)
local silentAim  = MakeCVar("k4_aimbot_silent", "0", true, false)

-- ESP / WALLHACK --
local espOn 	 = MakeCVar("k4_esp", "1", true, false)
local wallHackOn = MakeCVar("k4_wallhack", "0", true, false)
local wHackWire  = MakeCVar("k4_wallhack_wire", "0", true, false)
local EspDist    = MakeCVar("k4_ESP_Distance", "180", true, false)
local espBox  	 = MakeCVar("k4_ESP_Box", "1", true, false)
local espSkel    = MakeCVar("k4_ESP_Skeleton", "1", true, false)
local chamsMat   = MakeCVar("k4_ESP_Chams_Material","Solid", true, false)
local Glowing    = MakeCVar("k4_ESP_Glow", "0", true, false)
local Xray 		 = MakeCVar("k4_ESP_Xray", "0", true, false)
local XrayWires  = MakeCVar("k4_ESP_Xray_Wires", "1", true, false)
local XrayWSimp  = MakeCVar("k4_ESP_Xray_WSimple", "0", true, false)
local Ents 		 = MakeCVar("k4_ESP_Ents", "1", true, false)
local tracers    = MakeCVar("k4_ESP_Tracer", "1", true, false)
local lifeline    = MakeCVar("k4_ESP_LLine", "0", true, false)

concommand.Add( "k4_help", function() 
	print([[
		Hello, user if this is your first time using K0N4T4 please enter the following command in console "find k4_"
		this will list all the commands included in this hack. (WARNING: If you are using the light version some commands may not work.)
		
		Bellow you can find discriptions for the commands you will be using the most.
		
		k4_esp 1|0 :: Toggle ESP (Player Info, and Visuals)
		k4_wallhack 1|0 :: Toggle the wallhack
		k4_wallhack_wire 1|0 :: Toggle wireframe mode for the wallhack
		k4_xray :: Toggle xray
		k4_esp_tracer 2|1|0 :: Toggle tracers ( 2 = Use the old tracers, 1 = Use the new tracers, 0 = Disable )
		k4_esp_lline 1|0 :: Toggle HP oriented tracers.
		
		k4_aimbot 1|0 :: Toggle the aimbot, we recommend binding this to a key (ie. BindToggle r "k4_aimbot")
	]])
end )

-- HANDY HELPERS --
local killswitch       = MakeCVar("_k4NORUN_switch", "0", true, false) --Kill Switch Data Holder.
local bhop       = MakeCVar("k4_bhop", "0", true, false) --Bunny hop toggle.
local menu       = MakeCVar("k4_menu", "0", true, false) --Menu [WIP].
local removerec  = MakeCVar("k4_remove_recoil", "0", true, false) --No recoil.
local logIds     = MakeCVar("k4_log_steamids", "1", true, false) --SteamID logs.
local TalkLogs   = MakeCVar("k4_saylogs", "0", true, false) --Say logs in chat.

-- MISC --
local rpGod      = MakeCVar("k4_RPGOD", "0", true, false)
local tHack 	 = MakeCVar("k4_Misc_TTTHack", "0", true, false)
local chatspam   = MakeCVar("k4_Misc_CSpam", "0", true, false) --Chat Spam Toggle
local spamMsg 	 = MakeCVar("k4_Misc_CSpam_Msg", "-seffhakked-") --Chat Spam Message
local crosshair  = MakeCVar("k4_MISC_CROSSHAIR", "1", true, false) --Misc Crosshair
local propspamen = MakeCVar("k4_Misc_PSpam", "0", true, false) --Spam toggle
local propsmodel = MakeCVar("k4_Misc_PSpam_Model", "models/props_junk/watermelon01.mdl") --What model to spam
local Changer    = MakeCVar("k4_Misc_NameChanger", "0", true, false) --Name changer, most servers are protected from this.
local Changer2   = MakeCVar("k4_Misc_JobChanger", "0", true, false) --Job changer.
local ShowAdmins = MakeCVar("k4_Misc_PrintAdmins", "1", true, false) --Show the admins





-- Locals, do not edit. --
local POSSID 				= {"3661754147", "1217776124", "1833447947", "380449519", "3736849507", "3213074641", "4049813078", "1936458157", "1051044005", "1220357655", "831083134"} -- Not easily crackable, but still pretty insecure. :/
local x 					= ScrW() / 2 --Crosshair
local y 					= ScrH() / 2 --Crosshair
local gap 					= 0 --Crosshair Gap
local length 				= 10 --Crosshair Length
local tblDB      			= {}
local g	         			= table.Copy(_G)
local k4         			= {}
local k4_Admins 			= {}
local Menu       			= {}
local k4_version 			= "1.8a"
local k4_dev				= ""
local phase     			= "Alpha"
local old_ccadd	 			= concommand.Add;
local old_hookadd			= hook.Add;
local old_hookrem 			= hook.Remove;
local plr       			= LocalPlayer()
local TEAM_SPECTATOR 		= 1002
local NOSSID    			= { "STEAM_0:1:7099" }
local host       			= GetConVarString("ip")
k4laser					= {
"weapon_pocket",
"keys",
"pocket",
"weapon_toolgun",
"weapon_physgun",
"weapon_camera",
"camera",
"weapon_crowbar"
}


function k4:CreateMaterial()
local BaseInfo = {
["$basetexture"] = "models/debug/debugwhite",
["$model"]       = 1,
["$translucent"] = 1,
["$alpha"]       = 1,
["$nocull"]      = 1,
["$ignorez"]	 = 1
}	
local mat	
if GetConVarString("k4_ESP_Chams_Material") == "Solid" then
	mat = CreateMaterial( "k4_solid", "VertexLitGeneric", BaseInfo )
elseif GetConVarString("k4_ESP_Chams_Material") == "Wireframe" then
	mat = CreateMaterial( "k4_wire", "Wireframe", BaseInfo )
end
   return mat
end


--Addhook & Removehook
local function AddHook(Type,Function)
	Name = Type.." | "..math.random(1,1000),math.random(1,2000),math.random(1,3000) -- Simple hook names
	K0N4T4Print("[ADDED] Hook: ["..Type.."] | Name: "..Name.."")
	return old_hookadd(Type,Name,Function)
end

-- RemoveHook
local function RemoveHook(Type,Function)
	K0N4T4Print("[REMOVED] Hook: ["..Type.."]")
	return old_hookrem(Type,Function)
end

Gradient = surface.GetTextureID( "gui/gradient" )
function DrawBox( x, y, wide, tall, dropsize )
	draw.RoundedBoxEx( 4, x, y, wide, dropsize, iceblue, true, true, false, false )
	draw.RoundedBoxEx( 4, x, y + dropsize, wide, tall - dropsize, Color( 0, 0, 0, 100 ), false, false, true, true )
end


/******************************
Name: Get Admin Type
Purpose: Get Admin Type..
*******************************/
function GetAdminType(e,bool)
	local usergroup = e:GetNetworkedVar("UserGroup") or e:GetUserGroup() or "user"
	if ( (e:IsAdmin() or e:IsSuperAdmin()) or usergroup != "user" ) then
		local ugroup = string.Left(usergroup, 14)
		local ugroup = string.Replace(string.lower(ugroup), "owner", "OP")
		local ugroup = string.Replace(string.lower(ugroup), "superadmin", "SA")
		local ugroup = string.Replace(string.lower(ugroup), "super admin", "SA")
		local ugroup = string.Replace(string.lower(ugroup), "administrator", "A")
		local ugroup = string.Replace(string.lower(ugroup), "admin", "A")
		local ugroup = string.Replace(string.lower(ugroup), "moderator", "M")
		local ugroup = string.Replace(string.lower(ugroup), "mod", "M")
		local ugroup = string.Replace(string.lower(ugroup), "respected", "R")
		if(bool) then
			return usergroup:lower(), true
		else
			return "[ " .. string.upper(ugroup) .. " ] "
		end
	end
	if(bool) then
		return "", false
	else
		return ""
	end
end

/*************************
Name: Notify
Purpose: Chat functions
Credits: k4
*************************/

function k4.Notify(dosound,col,msg)
	if col then
		col = col
	end
chat.AddText(
purple, "[k4] ",
col, msg)
	if dosound then
		local beep = Sound( "/buttons/button17.wav" )
		local beepsound = CreateSound( LocalPlayer(), beep )
		beepsound:Play()
	end
end

k4.Notify(true,red,[[YOU ARE RUNNING THE LIGHT VERSION OF K0N4T4 | SOME THINGS MAY NOT WORK!]])

/*************************
Name: CreatePos
Purpose: Create a position
Credits: BaconBot
***************************/
function CreatePos(v)
local ply = LocalPlayer()
local center = v:LocalToWorld( v:OBBCenter() )
local min, max = v:OBBMins(), v:OBBMaxs()
local dim = max - min	local z = max + min	
local frt	= ( v:GetForward() ) * ( dim.y / 2 )
local rgt	= ( v:GetRight() ) * ( dim.x / 2 )
local top	= ( v:GetUp() ) * ( dim.z / 2 )
local bak	= ( v:GetForward() * -1 ) * ( dim.y / 2 )
local lft	= ( v:GetRight() * -1 ) * ( dim.x / 2 )
local btm	= ( v:GetUp() * -1 ) * ( dim.z / 2 )
local s = 1
local FRT 	= center + frt / s + rgt / s + top / s; FRT = FRT:ToScreen()
local BLB 	= center + bak / s + lft / s + btm / s; BLB = BLB:ToScreen()
local FLT	= center + frt / s + lft / s + top / s; FLT = FLT:ToScreen()
local BRT 	= center + bak / s + rgt / s + top / s; BRT = BRT:ToScreen()
local BLT 	= center + bak / s + lft / s + top / s; BLT = BLT:ToScreen()
local FRB 	= center + frt / s + rgt / s + btm / s; FRB = FRB:ToScreen()
local FLB 	= center + frt / s + lft / s + btm / s; FLB = FLB:ToScreen()
local BRB 	= center + bak / s + rgt / s + btm / s; BRB = BRB:ToScreen()	
local z = 100
if ( v:Health() <= 50 ) then z = 100 end
local x, y = ( ( v:Health() / 100 ) ), 1
if ( v:Health() <= 0 ) then x = 1 end
local FRT3 	= center + frt + rgt + top / x; FRT3 = FRT3; FRT3 = FRT3:ToScreen()
local BLB3 	= center + bak + lft + btm / x; BLB3 = BLB3; BLB3 = BLB3:ToScreen()
local FLT3	= center + frt + lft + top / x; FLT3 = FLT3; FLT3 = FLT3:ToScreen()
local BRT3 	= center + bak + rgt + top / x; BRT3 = BRT3; BRT3 = BRT3:ToScreen()
local BLT3 	= center + bak + lft + top / x; BLT3 = BLT3; BLT3 = BLT3:ToScreen()
local FRB3 	= center + frt + rgt + btm / x; FRB3 = FRB3; FRB3 = FRB3:ToScreen()
local FLB3 	= center + frt + lft + btm / x; FLB3 = FLB3; FLB3 = FLB3:ToScreen()
local BRB3 	= center + bak + rgt + btm / x; BRB3 = BRB3; BRB3 = BRB3:ToScreen()	
local x, y, z = 1.1, 0.9, 1
local FRT2 	= center + frt / y + rgt / z + top / x; FRT2 = FRT2:ToScreen()
local BLB2 	= center + bak / y + lft / z + btm / x; BLB2 = BLB2:ToScreen()
local FLT2	= center + frt / y + lft / z + top / x; FLT2 = FLT2:ToScreen()
local BRT2 	= center + bak / y + rgt / z + top / x; BRT2 = BRT2:ToScreen()
local BLT2 	= center + bak / y + lft / z + top / x; BLT2 = BLT2:ToScreen()
local FRB2 	= center + frt / y + rgt / z + btm / x; FRB2 = FRB2:ToScreen()
local FLB2 	= center + frt / y + lft / z + btm / x; FLB2 = FLB2:ToScreen()
local BRB2 	= center + bak / y + rgt / z + btm / x; BRB2 = BRB2:ToScreen()	
local maxX = math.max( FRT.x,BLB.x,FLT.x,BRT.x,BLT.x,FRB.x,FLB.x,BRB.x )
local minX = math.min( FRT.x,BLB.x,FLT.x,BRT.x,BLT.x,FRB.x,FLB.x,BRB.x )
local maxY = math.max( FRT.y,BLB.y,FLT.y,BRT.y,BLT.y,FRB.y,FLB.y,BRB.y )
local minY = math.min( FRT.y,BLB.y,FLT.y,BRT.y,BLT.y,FRB.y,FLB.y,BRB.y )
local minYhp2 = math.min( FRT.y,BLB.y,FLT.y,BRT.y,BLT.y,FRB.y,FLB.y,BRB.y )
local maxXhp = math.max( FRT3.x,BLB3.x,FLT3.x,BRT3.x,BLT3.x,FRB3.x,FLB3.x,BRB3.x )
local minXhp = math.min( FRT3.x,BLB3.x,FLT3.x,BRT3.x,BLT3.x,FRB3.x,FLB3.x,BRB3.x )
local maxYhp = math.max( FRT3.y,BLB3.y,FLT3.y,BRT3.y,BLT3.y,FRB3.y,FLB3.y,BRB3.y )
local minYhp = math.min( FRT3.y,BLB3.y,FLT3.y,BRT3.y,BLT3.y,FRB3.y,FLB3.y,BRB3.y )	
local maxX2 = math.max( FRT2.x,BLB2.x,FLT2.x,BRT2.x,BLT2.x,FRB2.x,FLB2.x,BRB2.x )
local minX2 = math.min( FRT2.x,BLB2.x,FLT2.x,BRT2.x,BLT2.x,FRB2.x,FLB2.x,BRB2.x )
local maxY2 = math.max( FRT2.y,BLB2.y,FLT2.y,BRT2.y,BLT2.y,FRB2.y,FLB2.y,BRB2.y )
local minY2 = math.min( FRT2.y,BLB2.y,FLT2.y,BRT2.y,BLT2.y,FRB2.y,FLB2.y,BRB2.y )
return maxX, minX, maxY, minY, maxX2, minX2, maxY2, minY2, minYhp, maxYhp
end

 ///////////////////////////////////////////////////

 chat.AddText(
    Color(255,0,255,255), "[k4] ",
	Color(0,255,0,255), "Version " ..k4_version.. " " ..phase.. " Loaded" )
surface.PlaySound("buttons/button14.wav")

////////////////////////////////////////////////////
function Changelog()
	http.Fetch("https://dl.dropbox.com/s/ok1ct6k36xx7z2y/changelog.txt", function(body, len, headers, code)
		file.Write("k4_changelog " ..k4_version.. ".txt", body)
	end)
end

///////////////////////////////////////////////////

surface.CreateFont( "Logo", { font = "Calibri", size = 100, weight = 700, } )
surface.CreateFont( "Misc", { font = "Calibri", size = 40, weight = 700, } )
surface.CreateFont( "esp", { font = "Arial Black", size = 16, weight = 70 } )
surface.CreateFont("ESPFont",{font = "ScoreboardText", size = 17, weight = 400, antialias = 0})
surface.CreateFont("ESPFont_Small",{font = "Default", size = 12, weight = 200, antialias = 0})
surface.CreateFont("Logo",{font = "akbar", size = 21, weight = 400, antialias = 0})
surface.CreateFont("k4_ScoreboardText",{font = "ScoreboardText", size = 15, weight = 700, antialias = 0})
surface.CreateFont("k4_coolvetica",{font = "ScoreboardText", size = 16, weight = 500, antialias = 0})
surface.CreateFont("k4_hvh",{font = "ScoreboardTextt", size = 15, weight = 1000, antialias = 1})
surface.CreateFont("ChLg", {font = "Calibri", size = 11, wieght = 500, })


//////////////////////////////////////////////////////////////////////////////
//Animation Changer, DARKRP ONLY
-- written by sokyru
-- edited by Kio-Foxx
-- original script written by Shinycow

local Enabled = CreateClientConVar("_k4_SwimAnimation", "0", true, false)
local Enabled2 = CreateClientConVar("_k4_Autistic", "0", true, false)
local Enabled3 = CreateClientConVar("_k4_DanceThing", "0", true, false)
local Enabled4 = CreateClientConVar("_k4_Swing", "0", true, false)

concommand.Add("k4_anim",function(ply,cmd,args,str)
	args[1] = string.lower(args[1])
	if(args[1] == "0") then
		RunConsoleCommand("_k4_SwimAnimation", "0")
		RunConsoleCommand("_k4_Autistic", "0")
		RunConsoleCommand("_k4_DanceThing", "0")
		RunConsoleCommand("_k4_Swing", "0")
    elseif(args[1] == "1" or args[1] == "swim" or args[1] == "ground") then
    	RunConsoleCommand("_k4_SwimAnimation", args[2])
    elseif(args[1] == "2" or args[1] == "zombie" or args[1] == "autisim") then
    	RunConsoleCommand("_k4_Autistic", args[2])
    elseif(args[1] == "3" or args[1] == "dance") then
    	RunConsoleCommand("_k4_DanceThing", args[2])
    elseif(args[1] == "4" or args[1] == "swing") then
    	RunConsoleCommand("_k4_Swing", args[2])
    elseif(args[1] == "help") then
    	print([[This is the shortcut command for animation forcing! || 1 = Swim in the ground | 2 = Zombie walk | 3 = Dance | 4 = Swing your arms when you attack. | 0 = Set all to 0]])
    end
end, function()
	return {"k4_anim 1 1","k4_anim 2 1","k4_anim 3 1","k4_anim 4 1", "k4_anim 1 0","k4_anim 2 0","k4_anim 3 0","k4_anim 4 0"}
end)

local function doAnim()
	if Enabled:GetBool() then
		RunConsoleCommand("_DarkRP_DoAnimation", "1627")
	end
end

timer.Create("anim", 1, 0, doAnim)

local function doAutism()
	if Enabled2:GetBool() then
		RunConsoleCommand("_DarkRP_DoAnimation", "1631")
	end
end

timer.Create("anim2", 1, 0, doAutism)

local function doDance()
	if Enabled3:GetBool() then
		RunConsoleCommand("_DarkRP_DoAnimation", "1635")
	end
end

timer.Create("anim3", 8, 0, doDance)

local function doSwing()
	if Enabled4:GetBool() and ( LocalPlayer():KeyPressed(IN_ATTACK) or LocalPlayer():KeyReleased(IN_ATTACK) ) and (!timer.Exists("_k4_timer_delay")) then
		RunConsoleCommand("_DarkRP_DoAnimation", "1633")
		timer.Create("_k4_timer_delay", 1, 1, function() timer.Destroy("_k4_timer_delay") end)
	end
end
hook.Add("Think", "_k4_swing_hook", doSwing())
////////////////////////////////////////////////////////////////////////////////////

local function IsVisible( ent ) /* Huge credits to whoever made this tracer function! */
	local tracer = {}
	if(LocalPlayer():GetShootPos() != nil && ent:IsValid() && ent != nil && LocalPlayer():GetActiveWeapon():IsValid() && LocalPlayer():GetActiveWeapon() != nil && ent:LookupBone("ValveBiped.Bip01_Head1") != nil && ent:GetBonePosition(ent:LookupBone("ValveBiped.Bip01_Head1")) != nil) then
		tracer.start = LocalPlayer():GetShootPos()
		tracer.endpos = ent:GetBonePosition(ent:LookupBone("ValveBiped.Bip01_Head1"))
		tracer.filter = { LocalPlayer(), ent }
		tracer.mask = MASK_SHOT
		local trace = util.TraceLine( tracer )
		if trace.Fraction >= 1 then return true else return false end
	end
end

local function InFov(ent)
	for k,v in pairs(ents.FindInCone(LocalPlayer():GetShootPos(), LocalPlayer():GetAimVector(), 3000, GetConVarNumber("k4_aimbot_fov")))  do
		if(v:IsPlayer() && ent == v) then
			return true
		else
			return false
		end
	end
end

local function WHCheck(v)
	if v:Alive() == true && v:Health() != 0 && v:Health() >= 0 && v ~= LocalPlayer() && LocalPlayer():Alive() then
		return true
	else
		return false
	end
end

function headlock(v, bone)
	if not(LocalPlayer() and LocalPlayer():Alive() and v and v:IsValid()) then return end
	local aimtrace = LocalPlayer():GetEyeTrace()
	if not(aimtrace and aimtrace.HitPos) then return end
	--local aimsphere = ents.FindInSphere(aimtrace.HitPos, 300)[1]
	--local mysphere = ents.FindInSphere(LocalPlayer():GetPos(), 200)[1]
	--if not(aimsphere or mysphere) then return end
	
	--if(mysphere and mysphere:IsPlayer() and IsVisible( v )) then v = mysphere end
	--if(aimsphere and aimsphere:IsPlayer() and IsVisible( v )) then v = aimsphere end
	if(aimtrace.Entity:IsPlayer() and IsVisible( v )) then v = aimtrace.Entity end
	
	
	local head = v:LookupBone(bone)
	local headpos,targetheadang = v:GetBonePosition(head)
	LocalPlayer():SetEyeAngles((headpos - LocalPlayer():GetShootPos()):Angle())
end


local function K0N4T4Aim()
	local searchtab = {}
	if(GetConVarNumber("k4_aimbot_distance") > 0) then
		searchtab = ents.FindInSphere(LocalPlayer():GetPos(), GetConVarNumber("k4_aimbot_distance"))
	else
		searchtab = player.GetAll()
	end
	
	for k,v in pairs(searchtab) do
		local bone = tostring(boneaim:GetString())
		if IsVisible( v ) and LocalPlayer():Alive() and v:IsPlayer() and v:Alive() and v:Health() > 0 and v ~= LocalPlayer() and v:Team() ~= TEAM_SPECTATOR and LocalPlayer():Team() ~= TEAM_SPECTATOR and GetConVarNumber("k4_aimbot") == 1 and LocalPlayer():GetActiveWeapon():GetClass() ~= "weapon_physgun" and LocalPlayer():GetActiveWeapon():GetClass() ~= "gmod_tool" and LocalPlayer():GetActiveWeapon():GetClass() ~= "gmod_camera" and LocalPlayer():GetActiveWeapon():GetClass() ~= "weapon_crowbar" then
			if GetConVarNumber("k4_aimbot_onshoot") >= 1 then
				if LocalPlayer():KeyDown(IN_ATTACK) then
					headlock(v, bone)
				end
			else
				headlock(v, bone)
			end
		end
	end
end
hook.Add("Think", "K0N4T4Aim", K0N4T4Aim)

--No Recoil
function NoRec()
	if GetConVarNumber("k4_remove_recoil") == 1 then
		if LocalPlayer():GetActiveWeapon().Primary then
			LocalPlayer():GetActiveWeapon().Primary.Recoil = 0
		end
	end
end

-- Wallhack

function IsCloseEnough(ent)
	local dist = ent:GetPos():Distance( LocalPlayer():GetPos() )
	if( dist <= GetConVarNumber("k4_ESP_Distance") and ent:GetPos() != Vector( 0, 0, 0 ) ) then
		return true
	end
	return false	
end

function wally( ccol, v, mat )
	if not( v and mat ) then return end
	if (v:GetPos():Distance(LocalPlayer():GetPos()) > 1500) then return end
	if not( ccol ) then ccol = Color(221, 221, 221, 190) end
	cam.Start3D(EyePos(), EyeAngles())
	g.render.SuppressEngineLighting(false)
	g.render.SetColorModulation(ccol.r / 255, ccol.g / 255, ccol.b / 255)
	g.render.SetBlend(ccol.a / 255)
	v:SetMaterial(tostring(mat))
	v:SetColor(255, 255, 220, 0)
	v:DrawModel()
	cam.End3D()
	v:SetColor(Color(255, 255, 255))
	v:SetMaterial("")
end

function Chams()
	if GetConVarNumber("k4_wallhack") == 1 then
		for k,v in pairs(player.GetAll()) do
			if WHCheck(v) then
			   local chamcol = g.team.GetColor(v:Team()) or Color(134,13,255,255)
			   wally( chamcol, v, "models/wireframe" )
		   end
		end
	end
end
hook.Add("HUDPaint", "Chams", Chams)

-- Esp --
-- include("K4/modules/k4_esp.lua")

concommand.Add("k4_esp_getinfo", function(ply)
	print("----------------------\n||[k4] ESP INFO [k4]||\n----------------------")
    PrintTable(ply:GetEyeTrace())
	local targ = ply:GetEyeTrace().Entity
	if(targ and targ:IsPlayer()) then
		if not (targ:Alive()) then return end
		print("\n----------------------\n||[k4] ESP SPEC [k4]||\n----------------------")
		print( "SteamID: " .. tostring(targ:SteamID()) )
		print( "Friend: " .. tostring(targ:GetFriendStatus()) )
		print( "Frags: " .. tostring(targ:Frags()) )
		print( "Deaths: " .. tostring(targ:Deaths()) )
		print("\n-----------------------------\n||[k4] ESP TARGET INFO [k4]||\n-----------------------------")
		local targeye = targ:GetEyeTrace()
		PrintTable(targeye)
		if(targeye.Entity and targeye.Entity:IsPlayer()) then
			print("\n-----------------------------\n||[k4] ESP TARGET SPEC [k4]||\n-----------------------------")
			print( "SteamID: " .. tostring(targeye.Entity:SteamID()) )
			print( "Friend: " .. tostring(targeye.Entity:GetFriendStatus()) )
			print( "Frags: " .. tostring(targeye.Entity:Frags()) )
			print( "Deaths: " .. tostring(targeye.Entity:Deaths()) )
		end
	end
end)

--Props
local function propcheck(v)
	if(string.find(v:GetClass():lower(), "gmod_") or string.find(v:GetClass():lower(), "player") or string.find(v:GetClass():lower(), "physgun") or string.find(v:GetClass():lower(), "viewmodel")) then
		return false
	else
		return true
	end
end

local chamcolo = Color(221, 0, 0, 190)

local darkrp = ( string.lower(engine.ActiveGamemode()) == "darkrp" )

local function propwall(n, v)
	if not (GetConVarNumber("k4_ESP_Xray_Wires") == 1) then return end
	if( n == 1 ) then
		LocalPlayer().propwall = "wall"
		local propy = string.find(v:GetClass():lower(), "prop" )
		if(GetConVarNumber("k4_ESP_Xray_WSimple") == 1) then propy = nil end
		local enty = ( string.find(v:GetClass():lower(), "money") or string.find(v:GetClass():lower(), "ship") or string.find(v:GetClass():lower(), "crate") )
		local weaponless = ( string.find(v:GetClass():lower(), "weapon") and not v:GetOwner():IsPlayer() )
		if( v and v:IsValid() and ( propy or enty or weaponless )) then
		if( v:GetPos():Distance(LocalPlayer():GetPos()) >= 800 and propy ) then return end
			if( v:GetPos():Distance(LocalPlayer():GetPos()) <= 300 ) then 
				chamcolo = Color(221, 0, 0, 190) 
			else
				chamcolo = Color(0, 0, 221, 190) 
			end
			local traced = ( LocalPlayer():GetEyeTrace().Entity == v )
			if( enty ) then 
				chamcolo = Color(0, 221, 221, 190)
				if(string.find(v:GetClass():lower(), "money") and darkrp) then
					if( traced) then AddWorldTip( v:EntIndex(), v:GetClass()..": $" .. tostring(v:GetNetworkedInt("PrintA")), 0, v:GetPos(), v  ) end
				elseif( (string.find(v:GetClass():lower(), "ship") or string.find(v:GetClass():lower(), "crate")) and darkrp ) then
					/*
					if( traced ) then
						local vmodel = string.Replace(tostring(v:GetgunModel():GetModel()), "model", "")
						vmodel = string.Replace(vmodel, "s/", "")
						vmodel = string.Replace(vmodel, "weapon", "")
						vmodel = string.Replace(vmodel, ".mdl", "")
						AddWorldTip( v:EntIndex(), v:GetClass()..": Weapon[" .. tostring(vmodel) .. "]", 0, v:GetPos(), v  )
					end
					*/
				else
					if( traced ) then AddWorldTip( v:EntIndex(), v:GetClass(), 0, v:GetPos(), v  ) end
				end
			end
			if( weaponless or v:IsWeapon() ) then
				chamcolo = Color(221, 0, 221, 190)
				local name = v:GetClass()
				if(v:GetClass():lower() == "spawned_weapon" and darkrp) then
					name = string.Replace(v:GetModel(), "model", "")
					name = string.Replace(string.Replace(string.Replace(name, "s/", ""), "weapon", "Weapon: "), ".mdl", "")
				end
				if( traced ) then AddWorldTip( v:EntIndex(), name, 0, v:GetPos(), v  ) end
			end
			wally( chamcolo, v, "models/wireframe" )
		end
	elseif( LocalPlayer().propwall == "wall" ) then
		hook.Remove("HUDPaint", "XRAYProps", XProps)
		LocalPlayer().propwall = nil
	end
end

local function XProps()
	cam.Start3D(EyePos(), EyeAngles())
		for k, v in pairs(ents.GetAll()) do
			if( v and v:IsValid() && propcheck(v)) then
				propwall(1, v)
				local islight = (string.find(v:GetClass():lower(), "env_sprite") or string.find(v:GetClass():lower(), "light_environment") or string.find(v:GetClass():lower(), "light_spot"))
				if(GetConVarNumber("k4_ESP_Xray") == 1) then
					if(islight) then
						v:SetColor(Color(255, 255, 255, 255))
						v:SetRenderMode(RENDERMODE_NONE)
					elseif(string.find(v:GetClass():lower(), "func_door")) then
						v:SetColor(Color(221, 0, 0, 100))
						v:SetRenderMode(RENDERMODE_TRANSALPHA)
					elseif(string.find(v:GetClass():lower(), "npc")) then
						v:SetColor(Color(221, 0, 221, 200))
						v:SetMaterial("models/debug/debugwhite")
						v:SetRenderMode(RENDERMODE_GLOW)
					else
						v:SetMaterial("models/debug/debugwhite")
						if(GetConVarNumber("k4_ESP_Xray_WSimple") == 1) then
							v:SetColor(Color(0, 0, 10, 150))
						else
							v:SetColor(Color(0, 0, 10, 100))
						end
						v:SetRenderMode(RENDERMODE_TRANSALPHA)
					end
				else
					v:SetMaterial("")
					v:SetColor(Color(255, 255, 255, 255))
					propwall(0, v)
				end
			end
		end
	cam.End3D()
end
hook.Add("HUDPaint", "XRAYProps", XProps)

-- SHORT CUTS --
concommand.Add( "k4_xray", function()
	hook.Add("HUDPaint", "XRAYProps", XProps)
	k4.Notify(false,green,[[XRAY TOGGLED]])
	local xrayval = 0
	if( GetConVarNumber("k4_ESP_Xray") == 1) then xrayval = 0 else xrayval = 1 end
	if(xrayval == 1) then 
		CreateSound( LocalPlayer(), Sound("npc/metropolice/vo/xray.wav") ):Play()
	else
		CreateSound( LocalPlayer(), Sound("weapons/sniper/sniper_zoomout.wav") ):Play()
	end
	RunConsoleCommand("k4_ESP_Xray", tostring(xrayval))
end )

concommand.Add( "k4_whois", function()
	print("--------------\n||[k4 WHOIS]||\n--------------\n")
	for _,v in pairs(player.GetAll()) do
		local usergroup = v:GetNetworkedVar("UserGroup") or v:GetUserGroup()
		local text = tostring(v) .. " | " .. usergroup .. " | " .. v:SteamID() .. " | " .. string.upper(tostring(v:GetFriendStatus()))
		if( darkrp ) then
			if( v.DarkRPVars.rpname ) then
				text = v.DarkRPVars.rpname .. " | " .. text
			else
				text = "nil" .. " | " .. text
			end
		end
		if( string.lower(usergroup) != "user" ) then
			if(GetAdminType(v,true) == ("admin" or "superadmin" or "owner") or (v:IsAdmin() or v:IsSuperAdmin())) then
				MsgC(Color(255,0,0), "RANKED> " .. text .. "\n\n")
			else
				MsgC(Color(255,200,200), "RANKED> " .. text .. "\n\n")
			end
		else
			
			if(v:GetFriendStatus() == "friend") then
				MsgC(iceblue, "NORANK> " .. text .. "\n\n")
			else
				MsgC(Color(255,255,255), "NORANK> " .. text .. "\n\n")
			end
		end
	end
end )

concommand.Add( "k4_lookat", function(ply,_,args)
	for _,v in pairs(player.GetAll()) do
		if( (string.find( string.lower(v:Nick()), string.lower(tostring(args[1]))) ~= nil and args[1] != "_") or tostring(v:SteamID()) == tostring(args[2]) ) then
			local head = v:LookupBone("ValveBiped.Bip01_Head1")
			local headpos,targetheadang = v:GetBonePosition(head)
			ply:SetEyeAngles((headpos - ply:GetShootPos()):Angle())
		end
	end
end)

-- Client Side Player Muting --
concommand.Add( "k4_mute", function(ply,_,args)
	for _,v in pairs(player.GetAll()) do
		if( (string.find( string.lower(v:Nick()), string.lower(tostring(args[1]))) ~= nil and args[1] != "_") or tostring(v:SteamID()) == tostring(args[2]) ) then
			v:SetMuted(true)
			k4.Notify(true,Color(168,168,168), v:Nick() .. " has been muted!")
		end
	end
end)
concommand.Add( "k4_unmute", function(ply,_,args)
	for _,v in pairs(player.GetAll()) do
		if( (string.find( string.lower(v:Nick()), string.lower(tostring(args[1]))) ~= nil and args[1] != "_") or tostring(v:SteamID()) == tostring(args[2]) ) then
			v:SetMuted(false)
			k4.Notify(true,Color(168,168,168), v:Nick() .. " has been unmuted!")
		end
	end
end)

/********************
-- THE KILL SWITCH --
********************/

-- Partial Kill --
concommand.Add( "k4_klag", function()
	k4.Notify(true,red,[[WARNING: Some hooks have been removed. (To Reactivate Reload The Script)]])
	hook.Remove("HUDPaint", "XRAYProps", XProps)
	hook.Remove("Think", "AimCheck", AimCheck)
	hook.Remove("HUDPaint", "Chams", Chams)
	hook.Remove("HUDPaint", "esp", K0N4T4Esp)
end )

-- Full Kill --
concommand.Add( "k4_kill", function()
	k4.Notify(true,red,[[WARNING: K0N4T4 IS NOW DEAD. (To Reactivate Reload The Script)]])
	hook.Remove("HUDPaint", "XRAYProps", XProps)
	hook.Remove("Think", "AimCheck", AimCheck)
	hook.Remove("HUDPaint", "Chams", Chams)
	hook.Remove("HUDPaint", "esp", K0N4T4Esp)
	hook.Remove("Think", "_k4_swing_hook", doSwing())
end )

/*********************
-- EXTRA UTIL STUFF --
*********************/
concommand.Add( "k4_load", function()
	local files, folders = file.Find("lua/K4/modules/*.lua", "GAME")
	for k, v in pairs(files) do
		include("K4/modules/" .. v)
	end
end )