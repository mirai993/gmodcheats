-- Deco's Win
-- Copyright 2010 Declan White
-- Licensed under Creative Commons Attribution-Noncommercial-Share Alike 2.5
-- (creativecommons.org/licenses/by-nc-sa/2.5/)

--lua_openscript_cl autorun/client/decos_win.lua; bind t +decos_assist; bind mouse1 +rapidfire; decos_win;
--lua_openscript_cl autorun/client/se_includes.lua;decos_win;decos_cc_ents weapon,item,npc,ttt,c4,ragdoll,_BaseEntity;decos_ttt 1
--
local ME
local HUD_ENTS = {}
local MODE = 0
local FIRE = false
local ACTIVITY = 0
local real_view
local blarghhook = function(b, ...)
    print("DW:", b, ...)
    if b then
        hook.Add(...)
    end
end
local Passers = {
    class            = function(ent) return ent:GetClass()                            end;
    alive            = function(ent) return ent:Alive()                                end;
    health            = function(ent) return ent:Health()                                end;
    dist            = function(ent) return ent:GetPos():Distance(ME:GetShootPos())    end;
    name            = function(ent) return ent:Name()                                end;
    player            = function(ent) return ent:IsPlayer()                            end;
    npc                = function(ent) return ent:IsNPC()                                end;
    team            = function(ent) return team.GetName(ent:Team())                    end;
    teamnum            = function(ent) return ent:Team()                                end;
    npcalive        = function(ent) return ent:GetMoveType() ~= 0                    end;
    gamemode        = function(ent) return GAMEMODE.Name                            end;
    friendstatus    = function(ent) return ent:GetFriendStatus()                    end;
    model            = function(ent) return (ent:GetModel() or "")                    end;
    map                = function()    return game.GetMap()                            end;
}
local SpecialVars = {
    myteam        = function() return team.GetName(ME:Team())                            end;
    myteamnum    = function() return ME:Team()                                        end;
}
local function FilterToTable(filter)
    local t = {}
    string.gsub(filter, "([%w_]+)([=~!<>#]?)([=]?)([^;]-);", function(var, any, op, do_op, compare_to)
        if not Passers[var] then
            ErrorNoHalt("DW: Invalid passer ID "..tostring(var).." in \""..filter.."\"", 3)
            return ""
        end
        compare_to = SpecialVars[compare_to] or function() return compare_to end
        table.insert(t, {var = var, compare =
            do_op == "" and (
                    op == ">" and function(data) return (tonumber(data) or 0) > (tonumber(compare_to()) or 0) end
                or    op == "<" and function(data) return (tonumber(data) or 0) < (tonumber(compare_to()) or 0) end
            )
            or    do_op == "=" and (
                    op == "="                    and function(data) return (tonumber(data) or 0) == (tonumber(compare_to()) or 0) end
                or    (op == "~" or op == "!")    and function(data) return (tonumber(data) or 0) ~= (tonumber(compare_to()) or 0) end
                or    op == "<"                    and function(data) return (tonumber(data) or 0) <= (tonumber(compare_to()) or 0) end
                or    op == ">"                    and function(data) return (tonumber(data) or 0) >= (tonumber(compare_to()) or 0) end
                or    op == "#"                    and function(data)
                        return string.find(tostring(data), tostring(compare_to()))
                    end
            )
        })
    end)
    return t
end
local CONFIG = {
    Groups = {
        {    filter = FilterToTable"class#=weapon;",
            settings = {
                esp = true,
            }
        };
        {    filter = FilterToTable"class#=item;",
            settings = {
                esp = true,
            }
        };
        {    filter = FilterToTable"class#=npc;",
            settings = {
                esp = true,
            }
        };
        {    filter = FilterToTable"model#=gnome;map#=gm_atomic;",
            settings = {
                esp = true,
            }
        };
        {    filter = FilterToTable"gamemode#=Trouble in Terrorist Town;",
            settings = {
                aim = false,
                esp = false,
                threats = {},
            },
            subgroups = {
                {    filter = FilterToTable"player;alive;teamnum==1",
                    aim = true,
                    esp = true,
                    threats = {
                        Distance = "*1",
                    },
                },
                {    filter = FilterToTable"player;alive;teamnum==1",
                    aim = true,
                    esp = true,
                    threats = {
                        Distance = "*1",
                    },
                },
            },
            terminate = true,
        };
    },
    model_overrides = {
        {    model = "^models/zombie/classic_torso.mdl$",
            attachments = {[2] = 3},
            any = true,
            cont = true,
        };
        {    model = "^models/zombie/fast.mdl$",
            attachments = {[2] = 3},
            any = true,
            cont = true,
        };
        {    model = "^models/zombie/poison.mdl$",
            attachments = {[2] = 3},
            any = true,
            cont = true,
        };
        {    model = "",
            attachments = {
                head = 2,
                eyes = 1.5,
            },
            bones = {
                ["ValveBiped.Bip01_Head1"        ] = 2.2,
                ["ValveBiped.Bip01_Pelvis"        ] = 1.5,
                ["ValveBiped.Bip01_Spine"        ] = 2,
                ["ValveBiped.Bip01_Spine1"        ] = 2,
                ["ValveBiped.Bip01_Spine2"        ] = 2,
                ["ValveBiped.Bip01_Neck1"        ] = 1.5,
                ["ValveBiped.Bip01_R_UpperArm"    ] = 1,
                ["ValveBiped.Bip01_R_Forearm"    ] = 0.8,
                ["ValveBiped.Bip01_R_Hand"        ] = 0.5,
                ["ValveBiped.Bip01_L_UpperArm"    ] = 1,
                ["ValveBiped.Bip01_L_Forearm"    ] = 0.8,
                ["ValveBiped.Bip01_L_Hand"        ] = 0.5,
                ["ValveBiped.Bip01_R_Thigh"        ] = 2,
                ["ValveBiped.Bip01_R_Calf"        ] = 1,
                ["ValveBiped.Bip01_R_Foot"        ] = 0.75,
                ["ValveBiped.Bip01_R_Toe0"        ] = 0.6,
                ["ValveBiped.Bip01_L_Thigh"        ] = 2,
                ["ValveBiped.Bip01_L_Calf"        ] = 1,
                ["ValveBiped.Bip01_L_Foot"        ] = 0.75,
                ["ValveBiped.Bip01_L_Toe0"        ] = 0.6,
            },
            any = true,
        };
    },
    weapons = {
        ["^weapon_ar2$"                ] = {cone = 0.02618},
        ["^weapon_shotgun$"            ] = {cone = 0.08716},
        ["^weapon_smg1$"            ] = {cone = 0.04362},
        ["^weapon_zs_zombie$"        ] = {cone = 0.00000},
        ["^weapon_zs_fastzombie$"    ] = {cone = 0.00000},
        ["^weapon_zs_fastzombie$"    ] = {cone = 0.00000},
        ["axe"                        ] = {melee = true},
        ["knife"                    ] = {melee = true},
        ["hammer"                    ] = {melee = true},
        ["shovel"                    ] = {melee = true},
        ["stunstick"                ] = {melee = true},
        ["crowbar"                    ] = {melee = true},
        ["snowball"                    ] = {melee = true},
        ["^weapon_physgun$"            ] = {no_rapid = true},
        ["grenade"                    ] = {no_rapid = true},
        ["mp5"                        ] = {inverse_vm_yaw = true},
        ["ak47"                        ] = {inverse_vm_yaw = true},
        ["deagle"                    ] = {inverse_vm_yaw = true},
        ["fiveseven"                ] = {inverse_vm_yaw = true},
        ["glock"                    ] = {inverse_vm_yaw = true},
        ["m4"                        ] = {inverse_vm_yaw = true},
        ["tmp"                        ] = {inverse_vm_yaw = true},
        ["mac10"                    ] = {inverse_vm_yaw = true},
        ["pumpshotgun"                ] = {inverse_vm_yaw = true},
        ["shotgun"                    ] = {spread = true},
    },
    MapPoints = {
        zs_gu_caves = {
            ["Secret Button"] = Vector(325, -631.5, -141.5),
        },
        zs_frostydeath_v1 = {
            ["Strange Button"] = Vector(-505, -433.5, 119),
        },
        zs_citadel_b4 = {
            ["Some Button"] = Vector(450, -232.5, 875),
        },
        zs_uglyfort_nowater = {
            ["Some button"] = Vector(1375.5, 1996.5, 54.5),
        },
        zs_storm_b1 = {
            ["lol"] = Vector(-422.5, -476, 60),
        },
        zs_gu_hamlet_v2 = {
            ["I will survive!"] = Vector(782.91, 1322.75, -568.5),
            ["Secret Teleport"] = Vector(2192.37, -768.19, -468),
            ["Secret Button"] = Vector(2314.52, -724.05, -385.51),
            ["Secret Teleport 2"] = Vector(-1734.36, -377, -138.68),
            ["Secret Teleport 3"] = Vector(436.64, 337.11, -519.98),
            ["Secret Button 2"] = Vector(-1803.34 -575.5 -151.34),
        },
        gm_atomic = {
            ["Gnome"] = Vector(-8928.7119, -4031.9475, -12906.1807),
        },
        zs_minifactory_v4_2 = {
            ["REEEEEEH"] = Vector(1988, 496, 128),
        },
        zm_forgotten_town = {
            ["Some Door"] = Vector(-2832, 1696, -146),
        },
        zs_farmhouse = {
            ["Some Breakable Thing"] = Vector(616, -492, -16),
        },
        zs_Lincs = {
            ["Stuff"] = Vector(0,0,10),
        },
        zs_cabin_v2 = {
            ["Some Buttom"] = Vector(732, -679, 4.5),
        },
        zs_barrelfactory = {
            ["Trapdoor Button"] = Vector(-265, 62, 56),
            ["Vender Button"] = Vector(203.16, -404.33, 179.5),
            ["Some Trigger"] = Vector(-382, 8, 19),
        },
        zm_tx_highschoolbeta7 = {
            ["Button"] = Vector(1679.49, 2704.49, 160),
            ["Blah"] = Vector(0,0,10),
        },
        zs_forgotten_city_cfixed = {
            ["Button"] = Vector(408, 616, 45.5),
        },
        zs_anchor = {
            ["Button"] = Vector(-2929.5, 989.21, 169)
        },
        dm_runoff_winter_storm_v1_2 = {
            ["Tele"] = Vector(10584, 4100.07, -237),
        },
        dm_snowblind = {
            ["What"] = Vector(2872, -855, -160),
        },
    };
}
local MODES = {[-1]="ERROR",[0]="OFF", "SNAP", "CONE", "TRIGGER", "ASSIST", "SNIPER", "SPAZ"}
local STATUS = "INACTIVE"
local ASSIST_ADJUST_TIME = 0.5
local WinIsOn = false
--_G.HUD_ENTS = HUD_ENTS
-- Painting! I moved it up here because it had more than 60 upvalues :O
local AllEnts = ents.GetAll
local RCC = RunConsoleCommand
local pairs, TeamCol = pairs, team.GetColor
local charger_full, charger_empty = 5.87, 2.1
local function GetHealthChargerPercent(ent)
    local bone = ent:LookupBone("roundcap")
    if bone then
        bone = math.floor((ent:WorldToLocal(ent:GetBonePosition(bone)).x-charger_empty)
            /(charger_full-charger_empty)*100)
    end
    ent.hc_value = bone
    return bone
end
local trace_table = {
    filter = nil,
    mask = MASK_SHOT,
}
local view_adjust, aim_ang = Angle(0,0,0), Angle(0,0,0)
local muzzle = 0
local C_WEP
local TraceEnt
local GetShootPos = _R.Player.GetShootPos
local GetAimVector = _R.Player.GetAimVector
local TraceLine, tr_res = util.TraceLine
local JustHadTarget = false
local frame_trace
local ToScreen = _R.Vector.ToScreen
local GetTextSize, SetFont, SetTextPos, SetTextColor, SetDrawColor, DrawText,
    DrawOutlinedRect, DrawRect, DrawLine
 = surface.GetTextSize, surface.SetFont, surface.SetTextPos, surface.SetTextColor,
 surface.SetDrawColor, surface.DrawText, surface.DrawOutlinedRect,
 surface.DrawRect, surface.DrawLine
local OnPaint
local LastHadTarget = CurTime()
local LastOn =  CurTime()
local LastHadFadeTime = 1
local ScrW, ScrH = ScrW, ScrH
local ScrW2, ScrH2 = ScrW()/2, ScrH()/2
do -- OnPaint in here!
    local m_w, m_h, m_s = 150, 50, 2
    local m_l, m_r, m_u, m_d = ScrW2-m_w, ScrW2+m_w, ScrH2-m_h, ScrH2+m_h
    local m_s_l, m_s_r = ScrW2-m_w/m_s, ScrW2+m_w/m_s
    local m_c_u, m_c_d = ScrH2-m_h/m_s, ScrH2+m_h/m_s
    local m_c_l, m_c_r = ScrW2-m_w/m_s, ScrW2+m_w/m_s
    local m_t_lu_x, m_t_lu_y = ScrW2-m_w, ScrH2-m_h-12
    local m_ts_lu_x, m_ts_lu_y = m_t_lu_x+1, m_t_lu_y+1
    local m_t_ru_x, m_t_ru_y = ScrW2+m_w, ScrH2-m_h-12
    local m_ts_ru_x, m_ts_ru_y = m_t_ru_x+1, m_t_ru_y+1
    local m_t_ld_x, m_t_ld_y = ScrW2-m_w, ScrH2+m_h+1
    local m_ts_ld_x, m_ts_ld_y = m_t_ld_x+1, m_t_ld_y+1
    local m_t_rd_x, m_t_rd_y = ScrW2+m_w, ScrH2+m_h+1
    local m_ts_rd_x, m_ts_rd_y = m_t_rd_x+1, m_t_rd_y+1
    local decos_showweps = CreateClientConVar("decos_showweps","1",true,false)
    local decos_showtraces = CreateClientConVar("decos_showtraces","1",true,false)
    local decos_fardist = CreateClientConVar("decos_fardist","5000",true,false)
    local decos_showtraces_table = {
        mask = MASK_SHOT,
    }
    function OnPaint()
        local vec, pos, pos2, pos2x, pos2y, posx, posy, locpos, bmm,
            dist, hvar, ent, tw, th, ttt, ttt2, ttt_col, clip, hcol, bone, tr, dot, dot_c, wep
        SetFont("DecosWin")
        if CAM_MODE then
            locpos = CAM_POS
        else
            locpos = GetShootPos(ME)
        end
        for k,v in pairs(HUD_ENTS) do
            if v.map then
                vec = v.e
                if v.name == "Me" then v.e = ME:GetPos() end
                dist = math.floor(vec:Distance(locpos)*0.05)
                SetFont("DecosWin"..math.ceil(math.max(1, math.min(((v.scale or 1)-dist/decos_fardist:GetFloat())*12, 12))))
                pos = ToScreen(vec)
                posx, posy = pos.x, pos.y    
                SetDrawColor(v.col)
                hcol = Color(255, 255, 255, 100)
                if pos.visible then
                    ttt = v.name
                    tw, th = GetTextSize(ttt)
                    pos2x, pos2y = posx-tw/2, posy+7
                    SetTextPos(pos2x+1, pos2y+1)
                    SetTextColor(0, 0, 0, 255)
                    DrawText(ttt)
                    SetTextPos(pos2x, pos2y)
                    SetTextColor(255, 255, 255, 255)
                    DrawText(ttt)
                end
            else
                ent = v.e
                if ent and ent:IsValid() then
                    SetFont("DecosWin12")
                    if ent:IsPlayer() then
                        vec = GetShootPos(ent)
                        dist = math.floor(vec:Distance(locpos)*0.1)
                        pos = ToScreen(vec)
                        posx, posy = pos.x, pos.y
                        --print("LOLSPAM", v.ent, v.col.r, v.col.g, v.col.b, v.col.a)
                        SetDrawColor(v.col)
                        hvar = math.Clamp(ent:Health(), 0, 100)*2.55
                        hcol = Color(255-hvar, hvar, 0, 255-math.Clamp(dist,100,170))
                        pos2 = ToScreen(vec+GetAimVector(ent)*25)
                        pos2x, pos2y = pos2.x, pos2.y
                        DrawLine(pos2x, pos2y, posx, posy)
                        pos2 = ToScreen(ent:GetPos())
                        pos2x, pos2y = pos2.x, pos2.y
                        DrawLine(pos2x, pos2y, posx, posy)
                        if pos.visible then
                            ttt = (v.name or "ERROR")..": "
                            if ent:Alive() then
                                ttt = ttt..ent:Health().."%"
                            else
                                ttt = ttt.."DEAD"
                                hcol = Color(0,0,0,255-math.Clamp(dist,100,170))
                            end
                            tw, th = GetTextSize(ttt)
                            pos2x, pos2y = posx-tw/2, posy+7
                            SetTextPos(pos2x+1, pos2y+1)
                            SetTextColor(0, 0, 0, 255)
                            DrawText(ttt)
                            SetTextPos(pos2x, pos2y)
                            SetTextColor(255, 255, 255, 255)
                            DrawText(ttt)
                            if decos_showweps:GetBool() then
                                wep = ent:GetActiveWeapon()
                                if wep and wep:IsValid() then
                                    clip = wep:Clip1()
                                else clip = "-" end
                                ttt = v.weapon..": "..clip.."/"..v.ammo
                                --ttt = math.floor(ent.ithreat or ent.threat)
                                tw = GetTextSize(ttt)
                                pos2x, pos2y = posx-tw/2, posy+7+th
                                SetTextPos(pos2x+1, pos2y+1)
                                SetTextColor(0, 0, 0, 255)
                                DrawText(ttt)
                                SetTextPos(pos2x, pos2y)
                                SetTextColor(255, 255, 255, 255)
                                DrawText(ttt)
                            end
                            if decos_showtraces:GetBool() and ent:Alive() then
                                decos_showtraces_table.start = GetShootPos(ent)
                                decos_showtraces_table.endpos = decos_showtraces_table.start+GetAimVector(ent)*16384
                                decos_showtraces_table.filter = ent
                                tr = TraceLine(decos_showtraces_table).HitPos
                                pos2 = ToScreen(tr)
                                pos2x, pos2y = pos2.x, pos2.y
                                dot = (locpos-GetShootPos(ent)):GetNormalized():Dot(GetAimVector(ent))
                                dot_c = HSVToColor(70*(1-dot)/2+50-math.min(50, tr:Distance(locpos)/20), 1, 1)
                                SetDrawColor(dot_c.r, dot_c.g, dot_c.b, 155*(1-dot)/2-math.min(100, tr:Distance(locpos)/10))
                                DrawLine(pos2x, pos2y, posx, posy)
                                SetDrawColor(v.col)
                            end
                        end
                    else
                        vec = ent:GetPos()
                        dist = math.floor(vec:Distance(locpos)*0.1)
                        pos = ToScreen(vec)
                        posx, posy = pos.x, pos.y
                        v.col.a = 120
                        SetDrawColor(v.col)
                        hcol = Color(255, 255, 255, 100)
                        hvar = ent:Health()
                        if pos.visible then
                            ttt = v.class
                            tw, th = GetTextSize(ttt)
                            pos2x, pos2y = posx-tw/2, posy+7
                            SetTextPos(pos2x+1, pos2y+1)
                            SetTextColor(0, 0, 0, 20)--math.min(255, 1237.5-math.max(dist, 127.5)+127.5*((v.scale or 1)-0.2)))
                            DrawText(ttt)
                            SetTextPos(pos2x, pos2y)
                            SetTextColor(255, 255, 255, 20)--math.min(255, 127.5+127.5*((v.scale or 1)-0.2)))
                            DrawText(ttt)
                            if ttt == "item_healthcharger" then
                                bone = GetHealthChargerPercent(ent)
                                if bone then
                                    hvar = math.Clamp(bone*2.55, 0, 255)
                                    hcol = Color(255-hvar, hvar, 0, 255-math.Clamp(dist,100,210))
                                    ttt = bone.."%"
                                    tw = GetTextSize(ttt)
                                    pos2x, pos2y = posx-tw/2, posy+7+th
                                    SetTextPos(pos2x+1, pos2y+1)
                                    SetTextColor(0, 0, 0, 255)
                                    DrawText(ttt)
                                    SetTextPos(pos2x, pos2y)
                                    SetTextColor(255, 255, 255, 255)
                                    DrawText(ttt)
                                end
                            elseif hvar > 0 then
                                ttt = hvar.."%"
                                hvar = math.Clamp(hvar*2.55, 0, 255)
                                hcol = Color(255-hvar, hvar, 0, 255-math.Clamp(dist,100,170))
                                tw = GetTextSize(ttt)
                                pos2x, pos2y = posx-tw/2, posy+7+th
                                SetTextPos(pos2x+1, pos2y+1)
                                SetTextColor(0, 0, 0, 255)
                                DrawText(ttt)
                                SetTextPos(pos2x, pos2y)
                                SetTextColor(255, 255, 255, 255)
                                DrawText(ttt)
                            end
                        end
                    end
                end
            end
            bmm = math.Clamp(10-dist/100, 0.1, 5)*(v.scale or 1)
            DrawOutlinedRect(posx-bmm-2, posy-bmm-2, bmm*2+4, bmm*2+4)
            DrawOutlinedRect(posx-bmm, posy-bmm, bmm*2, bmm*2)
            SetDrawColor(hcol)
            DrawRect(posx-bmm, posy-bmm, bmm*2, bmm*2)
        end
        SetFont("DecosWin12")
        ttt = "-"
        ttt2 = "-"
        ttt_col = Color(0,0,0,0)
        ent = TraceEnt
        if ent and ent:IsValid() and not ent:IsWorld() then
            hvar = ent:Health()
            ttt = ent:GetClass()
            if ent:IsPlayer() then
                ttt = ent:Name()
                if ent:Alive() then
                    ttt2 = ent:Health()
                    hvar = math.Clamp(ent:Health(), 0, 100)*2.55
                    ttt_col = Color(255-hvar, hvar, 0, 255)
                else
                    ttt2 = "DEAD"
                end
            elseif ent:GetClass() == "item_healthcharger" then
                ttt = "Health Charger"
                ttt2 = (ent.hc_value or "ERROR").."%"
                hvar = math.Clamp(ent.hc_value, 0, 100)*2.55
                ttt_col = Color(255-hvar, hvar, 0, 255)
            elseif hvar > 0 then
                ttt2 = hvar.."%"
                hvar = math.Clamp(hvar, 0, 100)*2.55
                ttt_col = Color(255-hvar, hvar, 0, 255)
            end
        end
        SetTextColor(0,0,0,255)
        SetTextPos(m_ts_ld_x, m_ts_ld_y)
        local healthwat = ME:Health()/100
        DrawText(string.format("%3s ", math.floor(healthwat*100))..MODES[MODE])
        th = GetTextSize(STATUS)
        SetTextPos(m_ts_rd_x-th, m_ts_rd_y)
        DrawText(STATUS)
        SetTextPos(m_ts_lu_x, m_ts_lu_y)
        DrawText(ttt)
        SetTextColor(ttt_col)
        tw = GetTextSize(ttt2)
        SetTextPos(m_ts_ru_x-tw, m_ts_ru_y)
        DrawText(ttt2)
        -- health thingo
        if healthwat < 0.5 then
            SetDrawColor(255, 2*healthwat*255, 0, 255)
        else
            SetDrawColor(255-(2*healthwat-1)*255, 255, 0, 255)
        end
        DrawLine(m_r+1, m_d, m_r+1, m_d-(m_d-m_u)*healthwat)
        DrawLine(m_l-1, m_d, m_l-1, m_d-(m_d-m_u)*healthwat)
        -- side bars
        DrawLine(m_l, m_u, m_l, m_d)
        DrawLine(m_r, m_u, m_r, m_d)
        if MODE > 0 then
            LastOn = CurTime()
            local FadeAmount = 255-ACTIVITY*255
            SetDrawColor(255, FadeAmount, 0, 255)
            SetTextColor(255, FadeAmount, 0, 255)
        else
            local FadeAmount = math.Clamp((CurTime()-LastOn)/LastHadFadeTime, 0, 1)*255
            SetDrawColor(255-FadeAmount, 255, 0, 255)
            SetTextColor(255-FadeAmount, 255, 0, 255)
        end
        SetTextPos(m_t_lu_x, m_t_lu_y)
        DrawText(ttt)
        SetTextPos(m_t_ru_x-tw, m_t_ru_y)
        DrawText(ttt2)
        SetTextPos(m_t_ld_x, m_t_ld_y)
        DrawText(string.format("%3s ", math.floor(healthwat*100))..MODES[MODE])
        SetTextPos(m_t_rd_x-th, m_t_rd_y)
        DrawText(STATUS)
        -- incoming bars
        DrawLine(m_l, m_u, m_s_l, m_u)
        DrawLine(m_l, m_d, m_s_l, m_d)
        DrawLine(m_r, m_u, m_s_r, m_u)
        DrawLine(m_r, m_d, m_s_r, m_d)
        -- Crosshair
        DrawLine(m_c_l, ScrH2, m_c_r, ScrH2)
        DrawLine(ScrW2, m_c_u, ScrW2, m_c_d)
        if real_view ~= aim_ang then
            decos_showtraces_table.start = locpos
            decos_showtraces_table.endpos = decos_showtraces_table.start+aim_ang:Forward()*16384
            decos_showtraces_table.filter = ME
            tr = TraceLine(decos_showtraces_table).HitPos
            pos2 = ToScreen(tr)
            SetDrawColor(255, 0, 0, 255)
            if C_WEP and C_WEP:IsValid() and muzzle ~= 0 then
                local it = C_WEP:GetAttachment(muzzle)
                if it and it.Pos then
                    pos = ToScreen(it.Pos)
                else
                    pos = {x=ScrW2,y=ScrH2}
                end
            else
                pos = {x=ScrW2,y=ScrH2}
            end
            DrawLine(pos2.x, pos2.y, pos.x, pos.y)
        end
        --if MODE == 4 then
        --    local radius = (1-ASSIST_CONE)/(LocalPlayer():GetFOV()/180)*ScrH2
        --    local lx, ly, cx, cy = ScrW2, ScrH2+radius
        --    local quality = 24
        --    for rad = math.pi/quality, math.pi*(2+1/quality), math.pi/quality do
        --        cx, cy = ScrW2+math.sin(rad)*radius, ScrH2+math.cos(rad)*radius
        --        DrawLine(lx, ly, cx, cy)
        --        lx, ly = cx, cy
        --    end
        --end
    end
end
-- BLEH!
local deco_hooks, hooks_ok = {}, true
local function AddHook(event, name, func)
    if hooks_ok then
        blarghhook(true, event, name, func)
    end
    decos_hooks[event] = decos_hooks[event] or {}
    decos_hooks[event][name] = func
end
-- the rest
local EntsToNotShow = {}
local CV_Ents = CreateConVar("decos_ents", "weapon,item,npc")
local EntsToShow = string.Explode(",", CV_Ents:GetString())
local decos_assist_cone = CreateConVar("decos_assist_cone", "0.99")
local ASSIST_CONE = decos_assist_cone:GetFloat()
cvars.AddChangeCallback("decos_assist_cone", function(cv, ov, v)
    ASSIST_CONE = tonumber(v)
end)
local function decos_a_callback(cvar, oldval, val)
    EntsToShow = string.Explode(",", val)
    if TroubleInTerroristTown then
        EntsToShow[#EntsToShow+1] = "prop_ragdoll"
    end
    EntsNoToShow = {}
    for k,v in pairs(weapons.GetList()) do
        EntsToShow[#EntsToShow+1] = v.ClassName
    end
    for k,v in pairs(EntsToShow) do
        print(k, v)
        if v:sub(1,1) == "!" then
            EntsToShow[k] = nil
            EntsToNotShow[#EntsToNotShow+1] = v:sub(2)
        end
    end
end
cvars.AddChangeCallback("decos_ents", decos_ents_callback)

for k,v in pairs(weapons.GetList()) do
    EntsToShow[#EntsToShow+1] = v.ClassName
end
for k,v in pairs(EntsToShow) do
    if v:sub(1,1) == "!" then
        EntsToShow[k] = nil
        EntsToNotShow[#EntsToNotShow+1] = v:sub(2)
    end
end
local TroubleInTerroristTown = false
local function decos_ents_callback(cvar, oldval, val)
    EntsToShow = string.Explode(",", val)
    if TroubleInTerroristTown then
        EntsToShow[#EntsToShow+1] = "prop_ragdoll"
    end
    EntsNoToShow = {}
    for k,v in pairs(weapons.GetList()) do
        EntsToShow[#EntsToShow+1] = v.ClassName
    end
    for k,v in pairs(EntsToShow) do
        if v:sub(1,1) == "!" then
            EntsToShow[k] = nil
            EntsToNotShow[#EntsToNotShow+1] = v:sub(2)
        end
    end
end
cvars.AddChangeCallback("decos_ents", decos_ents_callback)
concommand.Add("decos_cc_ents", function(ply, cmd, args)
    decos_ents_callback("decos_ents", "omgwtf", table.concat(args, " "))
end)
--decos_ents weapon_.,npc_.,.*item.*,.*func.*,!func_breakable,!func_illusionary,!func_brush,Base
local CV_ShootAt = CreateConVar("decos_shootat", "good=ent:IsPlayer()and ent:Team()~=ME:Team()")
local Menu = {}
local AIM_ENTS = {}
local AIM_AT = nil
local HAVE_TARGET = false
local ENGAGED = false
local FlashLight
local FLASHY = false
local DistanceNonScaled = 1000
do
    local oI = debug.getinfo
    function debug.getinfo(...)
    local p,a,b,c = oI(...)
    if p.short_src == "autorun/client/decos_win.lua" or p.short_src == "autorun/client/!.lua" then
        p.short_src = "LOL, you failed"
    end
    return p,a,b,c
end
    if oI(_R.Vector.ToScreen, "S").source ~= "=[C]" then
        timer.Create("FUCK!", 1, 20,
            PrintMessage, 4, "ANTI-SHIT AT"..debug.getinfo(_R.Vector.ToScreen, "S").source
        )
    end
end
timer.Remove("Deco's Win")
hook.Remove("HUDPaint", "Deco's Win")
-- Utils
ColorHashes = setmetatable({}, {__index = function(t,name)
    local currenthash = 5381
    local namelength, n = string.len(name)
    for n = 1, namelength do
        currenthash = 33*currenthash+string.byte(name, n)
    end
    local Hcolor = math.fmod(currenthash, 360)
    if Hcolor > 220 and Hcolor < 270 then
        Hcolor = Hcolor+60
    end
    local result = HSVToColor(Hcolor, 1, 1)
    t[name] = result
    return result
end})
local charger_full, charger_empty = 5.87, 2.1
local function GetWeaponRating(Shots, Damage, Delay, Cone, MaxClip, Clip, Dist, noclip)
    if MaxClip == -1 then MaxClip = 1 end
    if Clip == -1 then Clip = 1 end
    ClipV = IfNaN(Clip)/IfNaN(MaxClip)
    if noclip then ClipV = IfNaN(MaxClip) end
    if not Dist then
        return IfNaN(Damage)*(1-IfNaN(Delay,0))*(IfNaN(Clip)/IfNaN(MaxClip))*IfNaN(Shots)
    else
        return IfNaN(Damage)*(1-IfNaN(Delay,0))*(IfNaN(Dist)/(IfNaN(Cone,0)+1)/1000)*(IfNaN(Clip)/IfNaN(MaxClip))*IfNaN(Shots)
    end
    return 0
end
local function GetWeaponInfo(tab, dist, noclip)
    if type(tab) == "Entity" then
        if tab:IsValid() then
            tab = tab:GetTable()
        else return end
    end
    local WepData = {}
    WepData.wname = "NULL"
    WepData.Damage = "NULL"
    WepData.Cone = "NULL"
    WepData.ConeMoving = "NULL"
    WepData.ConeCrouching = "NULL"
    WepData.Delay = "NULL"
    WepData.Clip = "NULL"
    WepData.MaxClip = "NULL"
    WepData.NumShots = "NULL"
    WepData.Rating = 0
    WepData.Class = "NULL"
    WepData.wname = tab.PrintName
    WepData.Class = tab.ClassName
    if tab then
        WepData.Cone = GetWepVal(tab, "Cone")
        WepData.Damage = GetWepVal(tab, "Damage")
        WepData.ConeMoving = GetWepVal(tab, "ConeMoving")
        WepData.ConeCrouching = GetWepVal(tab, "ConeCrouching")
        WepData.Delay = GetWepVal(tab, "Delay")
        if not noclip and type(tab) == "Entity" then WepData.Clip = tab:Clip1() end
        WepData.MaxClip = GetWepVal(tab, "ClipSize")
        WepData.NumShots = GetWepVal(tab, "NumShots")
    end
    WepData.Rating = GetWeaponRating(WepData.NumShots, WepData.Damage, WepData.Delay, WepData.Cone, WepData.MaxClip, WepData.Clip, dist, noclip)
    return WepData
end
local function GetBestWeapon(e, k)
    local Best, v2, info = 0, nil, nil
    for k,v in pairs(p():GetWeapons()) do
        if e and e:IsValid() then
            e = Distance(e)
        else
            e = nil
        end
        if k and not string.find(v:GetClass(), "knife") then
            info = GetWeaponInfo(v, e)
            if  info.Rating > Best then
                Best = info.Rating
                v2 = v
            end
        end
    end
    return v2
end
-- Filters
local function PassesFilter(ent, filter)
    local worked, res
    for k,v in pairs(filter) do
        worked, res = pcall(Passers[v.var], ent)
        if worked then
            if not v.compare(res) then
                return false
            end
        end
    end
    return true
end
-- Group checkin'
function deepcopy(object) -- Stolen from lua-users.org >:D
    local lookup_table = {}
    local function _copy(object)
        if type(object) ~= "table" then
            return object
        elseif lookup_table[object] then
            return lookup_table[object]
        end
        local new_table = {}
        lookup_table[object] = new_table
        for index, value in pairs(object) do
            new_table[_copy(index)] = _copy(value)
        end
        return setmetatable(new_table, getmetatable(object))
    end
    return _copy(object)
end
local function IterateGroup(ent, group, settings)
    if PassesFilter(ent, group.filter) then
        for k,v in pairs(group.setings) do
            settings[k] = v
        end
        for i,subgroup in ipairs(group.subgroups) do
            if IterateGroup(ent, subgroup, settings) and subgroup.terminate then
                break
            end
        end
        return true
    end
end
-- Threat functions!
local FrameThreats = {
    Distance = function(ent, t)
        return t*DistanceNonScaled/ent:GetPos():Distance(ME:GetShootPos())
    end;
}
local Threats = {}
-- TTT!
concommand.Add("decos_ttt", function(p,c,a)
    local last_chat = ""
    blarghhook(true, "ChatTextChanged", "Deco's Win", function(text)
        last_chat = text
    end)
    --usermessage.Hook("interrupt_chat", function (um)
    --    local id = um:ReadLong()
    --    ErrorNoHalt("Last words ID is: "..tostring(id).."!")
    --    if last_chat ~= "" then
    --        RunConsoleCommand("_deathsay", tostring(id), last_chat)
    --    end
    --    --if LocalPlayer() and IsValid(LocalPlayer().last_id) then
    --    --    RunConsoleCommand("_lastid", tostring(id), tostring(LocalPlayer().last_id:EntIndex()))
    --    --end
    --end)
    local buff = ""
    usermessage.Hook("report_stream", function(um)
        local cont = um:ReadBool()
        buff = buff..um:ReadString()
        if cont then 
            return
        else
            local status, results = pcall(glon.decode, buff)
            if status then
                for k,v in pairs(player.GetAll()) do
                    v.decos_traitor = false
                end
                CLSCORE:ReportEvents(results)
            else
                Msg("Round report event encoding returned an error: " .. results .. "\n")
            end
            buff = ""
        end
    end)
    concommand.Add("decos_c4", function(ply, cmd, arg)
        local dist, c4 = arg[1] or 256
        for k,v in pairs(ents.FindByClass("ttt_c4")) do
            if v:GetPos():Distance(LocalPlayer():GetPos()) < dist then
                c4 = v
                dist = v:GetPos():Distance(LocalPlayer():GetPos())
            end
        end
        if not (c4 and c4:IsValid()) then
            ErrorNoHalt("No C4 found nearby!")
            return
        end
        local t, n, c4i = {}, 0, 0
        timer.Create("c4_disarm", 0.01, tonumber(string.rep("9", CODELENGTH)), function()
            while t[n] do
                n = math.random(0, tonumber(string.rep("9", CODELENGTH)))
            end
            t[n] = true
            print("C4 disarm attempt #"..string.format("%0"..CODELENGTH.."d", c4i)..": "..string.format("%0"..CODELENGTH.."d", n))
            RunConsoleCommand("ttt_c4_disarm", c4:EntIndex(), string.format("%0"..CODELENGTH.."d", n))
            c4i = c4i+1
        end)
        usermessage.Hook("c4_disarm_result", function(um)
            local bomb, result, correct = ents.GetByIndex(um:ReadShort()), {}, true
            for i=1,CODELENGTH do
                result[i] = um:ReadBool()
                correct = correct and result[i]
            end
            if ValidEntity(bomb) then
                if correct and code_success then
                    code_success()
                    timer.Remove("c4_disarm")
                    ErrorNoHalt("Bomb disarmed!")
                elseif code_fail then
                    code_fail(result)
                end
            end   
        end)
    end)
    TroubleInTerroristTown = a[1] == "1"
end)
local WAS_TTT_C4 = false
-- Stuff
local TTT_WEPS = {
    "weapon_ttt_c4",
    "weapon_ttt_sipistol",
    "weapon_ttt_flaregun",
    "weapon_ttt_phammer",
    "weapon_ttt_knife"
}
local OnPulse
do local strfind = string.find
    function OnPulse()
        local good, map_table, class, k, v, k2, v2, ob, settings = false
        local C4_THIS_PULSE = true
        HUD_ENTS = {{map = true, name = "Origin", e = Vector(0,0,0), col = Color(255, 255, 255, 255)}}
        local _, _, map_model = string.find(Entity(0):GetModel(), "maps/([%w_]+)%.bsp")
        map_table = CONFIG.MapPoints[map_model]
        if map_table then
            for k,v in pairs(map_table) do
                table.insert(HUD_ENTS, {map = true, name = k, e = v, col = ColorHashes[k]})
            end
        end
        if CAM_MODE then
            table.insert(HUD_ENTS, {map = true, name = "Me", e = ME:GetPos(), col = Color(255, 255, 255, 255)})
        end
        local WepsHeld = {}
        AIM_ENTS = {}
        for k,v in pairs(AllEnts()) do
            --local threat,k2,v2,temp,res = 1000
            --for k2,v2 in pairs(Threats) do
            --    res, temp = pcall(v2, v, threat)
            --    if not res then
            --        print("Threat check "..string.format("%q", k2).." failed with "..
            --            string.format("%q", temp).."! Removing...")
            --        Threats[k2] = nil
            --    else
            --        if temp == nil then
            --        elseif temp == false then
            --            threat = 0
            --            break
            --        else
            --            threat = temp
            --        end
            --    end
            --end
            --v.threat = threat
            --v.ithreat = nil
            --if threat > 0 then
            --    table.insert(AIM_ENTS, v)
            --end
            settings = {
                aim = false,
                esp = false,
            }
            --IterateGroup(v, CONFIG.Groups, settings)
            if v:IsPlayer() then
                if TroubleInTerroristTown then
                    --[[local c4_ents = ents.FindByClass("ttt_c4")
                    for k,v in pairs(c4_ents) do
                        if v:GetPos():Distance(ME:GetPos()) < 256 then
                            RunConsoleCommand("ttt_c4_pickup", v:EntIndex())
                        end
                        for k2,v2 in pairs(player.GetAll()) do
                            if v2:Alive() and v:GetPos():Distance(v2:GetPos()) < 256 then
                                v2.near_c4 = CurTime()
                            end
                        end
                    end]]
                    if v.was_alive ~= nil and v.was_alive and not v:Alive() then
                        v.decos_traitor = false
                        local closest, closest_dist = nil, math.huge
                        for k2,v2 in pairs(player.GetAll()) do
                            if v2 ~= v and v2:GetPos():Distance(v:GetPos()) < closest_dist and v2:Team() == 1 and v2:Alive() then
                                closest = v2
                                closest_dist = v2:GetPos():Distance(v:GetPos())
                            end
                        end
                        if closest then
                            chat.AddText(Color(100, 100, 100), "[DW] ",
                                Color(255, 255, 0), v:Name(),
                                Color(255, 255, 255), " has died. Closest was: ",
                                Color(255, 0, 0), closest:Name()
                            )
                        end
                    end
                    v.was_alive = v:Alive()
                    --print("yes")
                    if not v.decos_traitor then
                        for kw,vw in pairs(v:GetWeapons() or {}) do
                            for i = 1, #TTT_WEPS do
                                if vw:GetClass() == TTT_WEPS[i] then
                                    if vw.used_traitor_weapon ~= v then
                                        chat.AddText(
                                            Color(100, 100, 100), "[DW] ",
                                            Color(255, 0, 0), v:Name(),
                                            Color(255, 100, 0), " HAS ",
                                                v.role == 2                and Color(0, 0, 255)
                                            or    vw.used_traitor_weapon    and Color(100, 255, 100)
                                            or    Color(255, 100, 0),
                                                v.role == 2                and "DETECTIVE"
                                            or    vw.used_traitor_weapon    and "USED TRAITOR"
                                            or    "TRAITOR",
                                            Color(255, 100, 0), " WEAPON: ",
                                            Color(255, 255, 0), (vw:GetTable() or {}).PrintName or vw:GetClass(),
                                            Color(255, 0, 0), "!"
                                        )
                                        if not vw.used_traitor_weapon then
                                            v.decos_traitor = true
                                            vw.initial_traited = true
                                        end
                                        vw.used_traitor_weapon = v -- So you know when they buy /another/ traitor weapon
                                    end
                                    break
                                end
                            end
                        end
                    end
                end
                if v ~= ME and v:Alive() then
                    local ww, wn, wc, wa
                    ww = v:GetActiveWeapon()
                    if ww and ww:IsValid() then
                        wn = ww:GetPrintName()
                        wa = v:GetAmmoCount(ww:GetPrimaryAmmoType() or "")
                    else
                        wn = "-"
                        wa = "-"
                    end
                    local t_col
                    if v.decos_traitor then
                        t_col =  Color(255, 0, 0, 255)
                    else
                        t_col = TeamCol(v:Team())
                    end
                    table.insert(HUD_ENTS, {
                        e = v,
                        col = t_col,
                        name = v:Name() or "ERROR",
                        weapon = wn or "-",
                        ammo = wa or "-",
                        scale = 1.2,
                    })
                    for k2,v2 in pairs(v:GetWeapons()) do
                        WepsHeld[v2:EntIndex()] = true
                    end
                end
            else
                class = v:GetClass()
                good = v:IsWeapon()
                for k2,v2 in pairs(EntsToShow) do
                    if strfind(class, v2) or good then
                        good = true
                        break
                    end
                end
                if good and
                    not (v:IsWeapon()
                        and (v:IsCarriedByLocalPlayer() or WepsHeld[v:EntIndex()]))
                then
                    for k2,v2 in pairs(EntsToNotShow) do
                        if strfind(class, v2) then
                            good = false
                            break
                        end
                    end
                    if good then
                        if TroubleInTerroristTown and class == "prop_ragdoll" then
                            table.insert(HUD_ENTS, {
                                e = v,
                                col = ColorHashes[class],
                                class = class.." of "..tostring(v:GetNWString("nick", "WTF")),
                            })
                        elseif TroubleInTerroristTown and class == "ttt_c4" then
                            if not WAS_TTT_C4 then
                                chat.AddText(Color(100, 100, 100),"[DW] ",Color(255,0,0),"C4 ",Color(255,100,0),"PLANTED!")
                            end
                            C4_THIS_PULSE = true
                            WAS_TTT_C4 = true
                            table.insert(HUD_ENTS, {
                                e = v,
                                col = Color(255, 0, 0, 255),
                                class = "FUCKING TTT_C4",
                                scale = 4,
                            })
                            if v:GetPos():Distance(ME:GetPos()) < 256 then
                                --RunConsoleCommand("ttt_c4_pickup", v:EntIndex())
                            end
                            for k2,v2 in pairs(player.GetAll()) do
                                if v2:Alive() and v:GetPos():Distance(v2:GetPos()) < 256 then
                                    v2.near_c4 = CurTime()
                                end
                            end
                        elseif TroubleInTerroristTown and class == "ttt_radio" then
                            table.insert(HUD_ENTS, {
                                e = v,
                                col = Color(255, 0, 0, 255),
                                class = "ttt_radio",
                                scale = 3,
                            })
                        else
                            if not C4_THIS_PULSE then
                                WAS_TTT_C4 = false
                                chat.AddText(Color(100, 100, 100),"[DW] ",Color(255,0,0),"C4 ",Color(0,255,0),"gone!")
                            end
                            table.insert(HUD_ENTS, {
                                e = v,
                                col = ColorHashes[class],
                                class = class,
                                scale = v:IsWeapon() and 1 or string.find(v:GetClass(), "ammo") and 0.8 or 0.5,
                            })
                        end
                    end
                end
            end
        end
    end
end
local LastFire = 0
local ACTIVITY_FADE_RATE = 1/3
local Interval = 0.001
local DefDelay = 0.1
local last_wep
local Pulse = false
local pcall, type = pcall, type
local spread = 0
local automatic = false
local aimables = {}
local decos_team = CreateClientConVar("decos_team", "!", true, false)
local strange_weapon = false
local ASSIST_ADJUST_START
local OnViewModelRender
local cone, num_shots, inverse_vm_yaw, inverse_vm_pitch = 0, 1, false, false
local FIRST_ENGAGE
local function FindAssistTarget()
    local t_f = decos_team:GetString()
    local plys = ents.GetAll()
    local aimables_count = 0
    local shoot_pos, view_vec, view_ang = GetShootPos(ME), real_view:Forward(), real_view
    --for k,v in pairs(AIM_ENTS) do
    for k = 1, #plys do
        v = plys[k]
        if        v:IsNPC() and v:GetMoveType() ~= 0
            or    v:IsPlayer() and v:Alive() and (
                    t_f == ""
                or    t_f == "!" and v:Team() ~= ME:Team()
                or    string.match(" "..t_f.." ", "%D"..v:Team().."%D")
            )
         then
            v.pix_vis_handle = v.pix_vis_handle or util.GetPixelVisibleHandle()
            if util.PixelVisible(
                v:IsNPC() and v:LocalToWorld(v:OBBCenter()) or GetShootPos(v),
                70, v.pix_vis_handle
             ) > 0 then
                local aimable = aimables[aimables_count+1] or {}
                --aimable.t = 2--"pos"
                aimable.pos = v:LocalToWorld(v:OBBCenter())
                aimable.dot = 1-((aimable.pos-shoot_pos):Angle()):Forward():Dot(view_vec)
                if aimable.dot <= (1-ASSIST_CONE) then
                    aimable.ent = v
                    aimable.dbg = "OBB center"
                    aimables_count = aimables_count + 1
                    aimables[aimables_count] = aimable
                end
                for i = 1, #CONFIG.model_overrides do
                    local override = CONFIG.model_overrides[i]
                    if string.match(string.lower(v:GetModel()), override.model) then
                        for bone, mul in pairs(override.bones or {}) do
                            local bone_id = v:LookupBone(bone)
                            if bone_id ~= 0 then
                                local aimable = aimables[aimables_count+1] or {}
                                --aimable.t = 1--"bone"
                                aimable.pos = v:GetBonePosition(bone_id)
                                local ang = (aimable.pos-shoot_pos):Angle()
                                local dot = 1-(ang):Forward():Dot(view_vec)
                                --view_ang+(view_ang-ang)*(1/(mul-1))
                                if dot <= (1-ASSIST_CONE) then
                                    aimable.dot = dot/mul
                                    aimable.mul = mul
                                    aimable.ent = v
                                    aimable.dbg = bone
                                    aimables_count = aimables_count + 1
                                    aimables[aimables_count] = aimable
                                end
                            end
                        end
                        --for attachment, mul in pairs(override.attachments) do
                            --local atch = v:LookupAttachment("head")
                            --if atch ~= 0 then
                            --    local atchthing = v:GetAttachment(atch)
                            --    if atchthing then
                            --        return atchthing.Pos
                            --    end
                            --end
                        --end
                        if not override.cont then break end
                    end
                end
            end
        end
    end
    for i = aimables_count+1, #aimables do
        aimables[i] = nil
    end
    table.sort(aimables, function(a,b)
        return a.dot < b.dot
    end)
    --for i = 1, aimables_count do
    --    print(1-aimables[i].dot, aimables[i].mul, aimables[i].dbg)
    --end
    ENGAGED = aimables_count
    HAVE_TARGET = false
    AIM_AT = frame_trace.HitPos
    for i = 1, aimables_count do
        local aimable = aimables[i]
        trace_table.endpos = aimable.pos
        tr_res = TraceLine(trace_table)
        if tr_res.Entity == aimable.ent then
            FIRE = true
            AIM_AT = aimable.pos
            HAVE_TARGET = true
            STATUS = STATUS..aimable.dbg
            break
        end
    end
end
local ASSIST_COUNTER = 0
local OnThink
do
    local function GetWepVal(t, v, i)
        if not t then return "NULL" end
        if t[v] then
            return t[v]
        end
        if t.Primary and t.Primary[v] then
            return t.Primary[v]
        end
        if t["Primary"..v] then
            return t["Primary"..v]
        end
        if t["data"] then
            for _,d in pairs(t["data"]) do
                if type(d)=="table" and d[v] then return d[v] end
            end
        end
        if t.BaseClass and (i or 0)<10 then
            return GetWepVal(t.BaseClass, v, (i or 0)+1)
        end
        return nil
    end
    function OnThink()
        C_WEP = ME:GetActiveWeapon()
        if C_WEP ~= last_wep then
            last_wep = C_WEP
            if C_WEP and C_WEP:IsValid() then
                local tab = C_WEP:GetTable()
                function tab:ViewModelDrawn()
                    if WinIsOn and OnViewModelRender then
                        OnViewModelRender()
                    end
                end
                local override = {}
                for class, settings in pairs(CONFIG.weapons) do
                    if string.match(string.lower(C_WEP:GetClass()), class) then
                        override = settings
                        break
                    end
                end
                cone = override.cone or tonumber(GetWepVal(tab, "Cone")) or 0
                num_shots = override.num_shots or tonumber(GetWepVal(tab, "NumShots")) or 0
                inverse_vm_yaw = tab.Base--override.inverse_vm_yaw
                inverse_vm_pitch = override.inverse_vm_pitch
                strange_weapon = override.no_rapid
                muzzle = C_WEP:LookupAttachment("muzzle")
                if override.automatic ~= nil then
                    automatic = override.automatic
                else
                    automatic = GetWepVal(tab, "Automatic")
                end
                if tab and tab.Primary then tab.Primary.Recoil = 0 end
            else
                cone = 0
                automatic = false
            end
        end
        -- EPILEPSY FLASH-LIGHT
        if FLASHY then
            RCC("impulse", "100")
        end
        local top_one,top_threat,k,v = nil, 0
        for k,v in pairs(AIM_ENTS) do
            if v:IsValid() then
                local threat,k2,v2,temp,res = v.threat
                for k2,v2 in pairs(FrameThreats) do
                    res, temp = pcall(v2, v, threat)
                    if not res then
                        print("Frame threat check "..string.format("%q", k2).." failed with "..
                            string.format("%q", temp).."! Removing...")
                        FrameThreats[k2] = nil
                    else
                        if temp == nil then
                        elseif temp == false then
                            threat = 0
                            break
                        else
                            threat = temp
                        end
                    end
                end
                v.ithreat = threat
                if threat > top_threat then
                    top_one = v
                    top_threat = threat
                end
            end
        end
        FIRE = false
        AIM_AT = nil
        AIM_ENT = nil
        ENGAGED = false
        ACTIVITY = math.Clamp(ACTIVITY-FrameTime()*ACTIVITY_FADE_RATE, 0, 1)
        
        STATUS = "READY"
        trace_table.start = GetShootPos(ME)
        trace_table.endpos = trace_table.start+real_view:Forward()*65535--GetAimVector(ME)*65535
        tr_res = TraceLine(trace_table)
        frame_trace = tr_res
        if ASSIST_ADJUST_START and CurTime() > ASSIST_ADJUST_START then
            gui.EnableScreenClicker(true)
            trace_table.endpos = trace_table.start+ME:GetCursorAimVector()*16800
            tr_res = TraceLine(trace_table)
            local opposite = tr_res.HitPos:Distance(frame_trace.HitPos)
            local ajacent = tr_res.HitPos:Distance(trace_table.start)
            ASSIST_CONE = math.cos(math.atan(opposite/ajacent))
            RCC("decos_assist_cone", ASSIST_CONE)
        end
        local ent = tr_res.Entity
        --_G.ent = ent
        --_G.ME = ME
        TraceEnt = ent
        if MODE == -1 then
            STATUS = "ERROR"
        elseif MODE == 0 then
            STATUS = "READY"
        elseif MODE == 1 or MODE == 2 then
            STATUS = "SEARCHING..."
        elseif MODE == 3 then
            STATUS = "SCANNING..."
            if ent then
                local t_f = decos_team:GetString()
                local good =    ent:IsNPC() and ent:GetMoveType() ~= 0
                            or    ent:IsPlayer() and (
                                    t_f == ""
                                or    t_f == "!" and ent:Team() ~= ME:Team()
                                or    string.match(" "..t_f.." ", "%D"..ent:Team().."%D")
                            )
                --RunString(ToShootAt)
                FIRE = good
            end
        elseif MODE == 4 then
            STATUS = "ASSISTING..."
            if MANUAL_FIRE then
                FindAssistTarget()
                ASSIST_COUNTER = ASSIST_COUNTER+1
            end
        else
            if JustHadTarget then
                JustHadTarget = false
                RCC "-attack"
            end
        return end
        if not FIRE then
            if JustHadTarget then
                JustHadTarget = false
                RCC "-attack"
            end
            return
        else
            --STATUS = "FIRING!"
        end
        ACTIVITY = 1
        if not JustHadTarget then
            Pulse = true
        end
        JustHadTarget = true
    end
end
local emergency_decos = {}
local function emergency_deco(cmd, func)
    emergency_decos[cmd] = func
    concommand.Add(cmd, func)
end
require"memory"
require"deco2"
local currentseed = 0
local nospread = CreateClientConVar("decos_nospread", "0", true, false)
local RAPID_FIRE
local rapidfire = CreateClientConVar("decos_rapidfire", "1", true, false)
local juston = false
emergency_deco("+rapidfire", function(p,c,a)
    if WSWITCH and WSWITCH.Show then
        WSWITCH:ConfirmSelection()
        return
    end
    RCC"+attack"
    MANUAL_FIRE = true
    if MODE == 4 then
        FindAssistTarget()
        ASSIST_COUNTER = 0
    end
    if rapidfire:GetBool() then
        ME = ME or LocalPlayer()
        RAPID_FIRE = true
        juston = true
    end
end)
emergency_deco("-rapidfire", function(p,c,a)
    MANUAL_FIRE = false
    RAPID_FIRE = false
    RCC"-attack"
end)
local BOINGING = false
emergency_deco("+boing",function()BOINGING=true end)
emergency_deco("-boing",function()BOINGING=false end)
local IKD = input.IsKeyDown
local cm_created = false
local cv_sensitivity = CreateClientConVar("sensitivity", "12", true, false)
local decos_testing = CreateClientConVar("decos_testing", "0", true, false)
local decos_walk = CreateClientConVar("decos_walk", "0", true, false)
require("command")
--command.ServerCommand("exec config\n")
local aim_ang_reset = 0
local fire_time = 0
local speedhack = false
do
    local CM_pulse, buttons, cmd, fired_last_cm
    local function OnCreateMove(UCMD)
        if not cm_created then
            cm_created = true
            real_view = UCMD:GetViewAngles()
            ME = LocalPlayer()
        end
        local sensitivity = cv_sensitivity:GetFloat()/1000
        real_view = strange_weapon and UCMD:GetViewAngles() or Angle(
            math.max(math.min(real_view.p+UCMD:GetMouseY()*sensitivity, 90), -90),
            real_view.y-UCMD:GetMouseX()*sensitivity,
            0
        )
        CM_pulse = not CM_pulse
        if juston and not MANUAL_FIRE then
            --RCC"-attack"
            juston = false
            return
        end
        buttons = memory.GetInteger(UCMD, 36, 1337)
        if BOINGING then
            if (buttons & IN_JUMP) ~= IN_JUMP then
                if (buttons & IN_WALK) == IN_WALK then
                    buttons = buttons - IN_WALK
                    memory.SetInteger(UCMD, 36, buttons)
                    buttons = buttons | IN_JUMP
                    memory.SetInteger(UCMD, 36, buttons)
                elseif ME:IsOnGround() then
                    buttons = buttons | IN_JUMP
                    memory.SetInteger(UCMD, 36, buttons)
                end
            end
        end
        view_adjust = Angle(real_view.p, real_view.y, real_view.r)
        if FIRE or RAPID_FIRE and not strange_weapon then
            if RAPID_FIRE then
                --RCC"-attack"
            end
            if not fire_last_cm or automatic then
                buttons = buttons | IN_ATTACK
                memory.SetInteger(UCMD, 36, buttons)
            else
                if (buttons & IN_ATTACK) == IN_ATTACK then
                    buttons = buttons - IN_ATTACK
                    memory.SetInteger(UCMD, 36, buttons)
                end
            end
        elseif MANUAL_FIRE then
            buttons = buttons | IN_ATTACK
            memory.SetInteger(UCMD, 36, buttons)
        end
        if (buttons & IN_ATTACK) == IN_ATTACK then
            if AIM_AT then
                view_adjust = (AIM_AT-GetShootPos(ME)):Angle()
                aim_ang = view_adjust
                aim_ang_reset = CurTime()+0.2
            end
            if decos_testing:GetBool() or MODE == 4 and not strange_weapon and ASSIST_COUNTER < 2 then
                buttons = buttons - IN_ATTACK
                memory.SetInteger(UCMD, 36, buttons)
            end
            if nospread:GetBool() then
                cmd = UCMD:GetCommandNumber()
                if cmd ~= 0 then
                    currentseed = MD5_PseudoRandom(cmd)
                end
                cone = cone or 0
                view_adjust = manipulate_shot(currentseed, view_adjust:Forward(), Vector(-cone, -cone, -cone)):Angle()
            end
        end
        fire_last_cm = (buttons & IN_ATTACK) == IN_ATTACK
        if CurTime() > aim_ang_reset then
            aim_ang = real_view
        end
        --view_adjust:RotateAroundAxis(Vector(0,0,1), 90)
        local move_vec = Vector(UCMD:GetForwardMove(), UCMD:GetSideMove(), UCMD:GetUpMove())
        if view_adjust ~= real_view then
            local move_vec = Vector(UCMD:GetForwardMove(), UCMD:GetSideMove(), UCMD:GetUpMove())
            move_vec:Rotate(view_adjust-real_view)
        end
        if decos_walk:GetFloat() > 0 and not (input.IsKeyDown(KEY_LSHIFT) or input.IsKeyDown(KEY_RSHIFT)) then
            move_vec = move_vec:GetNormalized()*math.min(decos_walk:GetFloat(), move_vec:Length())
        end
        UCMD:SetForwardMove(speedhack and 10000 or move_vec.x)
        UCMD:SetSideMove(move_vec.y)
        UCMD:SetUpMove(move_vec.z)
        if memory then
            memory.SetVector(UCMD, 8, Vector(0, view_adjust.p, view_adjust.y))
        else
            UCMD:SetViewAngles(view_adjust)
        end
    end blarghhook(true, "CreateMove", "Deco's Win", OnCreateMove)
end
local view_t = {}
local decos_calcview = CreateClientConVar("decos_calcview", "1", true, false)
local decos_calcview_on = CreateClientConVar("decos_calcview_on", "1", true, false)
local function OnCalcView(ply, pos, angles, fov)
    if not decos_calcview_on:GetBool() then return end
    view_t.origin = pos
    view_t.angles = decos_calcview:GetBool() and real_view or angles
    view_t.fov = fov
    view_t.vm_angles =
            decos_calcview:GetBool() and Angle(
                inverse_vm_pitch and real_view.p+real_view.p-angles.p or angles.p,
                inverse_vm_yaw and real_view.y+real_view.y-angles.y or angles.y,
                0
            )
        or    angles
    view_t.vm_fov = fov
    return view_t
end blarghhook(true, "CalcView", "Deco's Win", OnCalcView)
local deathrun = CreateClientConVar("decos_deathrun", "0", true, false)
local ghost_alpha = CreateClientConVar("decos_ghost_alpha", "1", true, false)
local model_alpha = CreateClientConVar("decos_model_alpha", "1", true, false)
local wall_mat = Material("models/debug/debugwhite")
local wall_mat2 = Material("effects/stunstick")
local render = render
local player = player
local ents = ents
local cam = cam
local hook = hook
local NoDrawed = {}
local type = type
local Matrix = Matrix
local SetMaterialOverride = SetMaterialOverride
local function ValidEnt(ent)
    local t = type(ent)
    return (t == "Entity" or t == "Player") and ent:IsValid()
end
local breakables = {}
local WallIsOn = false
local Laser = Material("Debug/debugwireframe")
local TracesIsOn
local OnScreenRender
do
    local decos_showtraces_table = {
        mask = MASK_SHOT,
    }
    function OnScreenRender()
        local locpos,k,v,ent,g_a,m_a,locang,calcview_results
        g_a = ghost_alpha:GetFloat()
        m_a = model_alpha:GetFloat()
        if CAM_MODE then
            locpos = CAM_POS
        else
            calcview_results = GAMEMODE:CalcView(ME, ME:EyePos(), ME:EyeAngles(), 1337) or {}
            locpos, locang = calcview_results.origin or ME:EyePos(), calcview_results.angle or ME:EyeAngles()
        end
        cam.IgnoreZ(false)
        cam.Start3D(locpos, locang)
        if deathrun:GetBool() then
            breakables = ents.FindByClass("func_breakable")
            local lb, v = #breakables
            for i = 1, lb do
                v = breakables[i]
                render.SetColorModulation(255, 0, 255*i/lb)
                v:SetNoDraw(true)
                v:DrawModel()
            end
        else
            for k,v in pairs(ents.FindByClass("func_breakable")) do
                v:SetNoDraw(false)
            end
        end
        if TracesIsOn or WallIsOn then
            require "renderx"
            render.SetMaterial(Laser)
            render.SetColorModulation(1,1,1)
            for k,v in pairs(player.GetAll()) do
                decos_showtraces_table.start = GetShootPos(v)
                decos_showtraces_table.endpos = decos_showtraces_table.start+GetAimVector(v)*16384
                decos_showtraces_table.filter = v
                v.decos_tr = TraceLine(decos_showtraces_table).HitPos
            end
            --dot = (locpos-GetShootPos(ent)):GetNormalized():Dot(GetAimVector(ent))
            --dot_c = HSVToColor(70*(1-dot)/2+50-math.min(50, tr:Distance(locpos)/20), 1, 1)
            --SetDrawColor(dot_c.r, dot_c.g, dot_c.b, 155*(1-dot)/2-math.min(100, tr:Distance(locpos)/10))
            --DrawLine(pos2x, pos2y, posx, posy)
            --SetDrawColor(v.col)
            render.ClearStencil();
            render.SetStencilEnable( true );
            render.SetStencilFailOperation( STENCILOPERATION_KEEP );
            render.SetStencilZFailOperation( STENCILOPERATION_KEEP );
            render.SetStencilPassOperation( STENCILOPERATION_REPLACE );
            render.SetStencilCompareFunction( STENCILCOMPARISONFUNCTION_ALWAYS );
            render.SetStencilWriteMask( 1 );
            render.SetStencilReferenceValue( 1 );
            render.SetBlend(0.1)
            local c_r,c_g,c_b,c_a
            --render.SetColorModulation(c.r/255,c.g/255,c.b/255)
            for k,v in pairs(player.GetAll()) do
                if v:GetMoveType() ~= MOVETYPE_OBSERVER and v:Alive() and v:Health() > 0 then
                    render.DrawBeam(GetShootPos(v), v.decos_tr, 0.1, 0, 0, Color(255, 255, 255, 0))
                end
            end
            render.SetStencilTestMask( 1 );
            render.SetStencilCompareFunction( STENCILCOMPARISONFUNCTION_NOTEQUAL );
            render.SetStencilPassOperation( STENCILOPERATION_REPLACE );
            render.SetStencilFailOperation( STENCILOPERATION_KEEP );

            render.OverrideDepthEnable( true, false );
            local c
            cam.IgnoreZ(true)
            for k,v in pairs(player.GetAll()) do
                if v:GetMoveType() ~= MOVETYPE_OBSERVER and v:Alive() and v:Health() > 0 then
                    render.DrawBeam(GetShootPos(v), v.decos_tr, 0.1, 0, 0, Color(0, 255, 0, 0))
                end
            end
            cam.IgnoreZ(false)
            render.OverrideDepthEnable( false, true );
            render.SetStencilEnable( false );
        end
        if WallIsOn then
            render.ClearStencil();
            render.SetStencilEnable( true );
            render.SetStencilFailOperation( STENCILOPERATION_KEEP );
            render.SetStencilZFailOperation( STENCILOPERATION_KEEP );
            render.SetStencilPassOperation( STENCILOPERATION_REPLACE );
            render.SetStencilCompareFunction( STENCILCOMPARISONFUNCTION_ALWAYS );
            render.SetStencilWriteMask( 1 );
            render.SetStencilReferenceValue( 1 );
                if CAM_MODE then
                    ME:DrawModel()
                end
            --for k,v in pairs(HUD_ENTS) do
            --    ent = v.e
            --    if not v.map and ValidEnt(ent)
            --     and (ent:IsPlayer() and ent:Alive()
            --     or ent:IsNPC() and ent:MoveType() ~= 0)
            --    then
            --        ent:DrawModel()
            --        NoDrawed[ent] = true
            --        ent:SetNoDraw(true)
            --    end
            --end
            local c_r,c_g,c_b,c_a
            for k,v in pairs(player.GetAll()) do
                if v:GetMoveType() ~= MOVETYPE_OBSERVER and v:Alive() and v:Health() > 0 then
                    c_r, c_g, c_b, c_a = v:GetColor()
                    render.SetColorModulation(c_r/255, c_g/255, c_b/255)
                    render.SetBlend(m_a)
                    v:DrawModel()
                    v:SetNoDraw(true)
                end
            end
            render.SetStencilTestMask( 1 );
            render.SetStencilCompareFunction( STENCILCOMPARISONFUNCTION_NOTEQUAL );
            render.SetStencilPassOperation( STENCILOPERATION_REPLACE );
            render.SetStencilFailOperation( STENCILOPERATION_KEEP );

            render.OverrideDepthEnable( true, false );
            cam.IgnoreZ(true)
            SetMaterialOverride(wall_mat)
            local c
            --for k,v in pairs(HUD_ENTS) do
            --    ent = v.e
            --    if not v.map and ValidEnt(ent)
            --     and (ent:IsPlayer() and ent:Alive()
            --     or ent:IsNPC() and ent:MoveType() ~= 0)
            --    then
            --        --wall_mat:SetMaterialFloat("$color[0]",0.5)
            --        --SetMaterialOverride(wall_mat)
            --        c = v.col
            --        render.SetColorModulation(c.r/255,c.g/255,c.b/255)
            --        ent:DrawModel()
            --    end
            --end
            render.SetBlend(g_a)
            render.SuppressEngineLighting(true)
            for k,v in pairs(player.GetAll()) do
                if v:GetMoveType() ~= MOVETYPE_OBSERVER and v:Alive() and v:Health() > 0 then
                    c = TeamCol(v:Team())
                    render.SetColorModulation(c.r/255,c.g/255,c.b/255)
                    v:DrawModel()
                    v:SetNoDraw(true)
                end
            end
            render.OverrideDepthEnable( false, true );
            render.SetStencilEnable( false );
        end
        SetMaterialOverride()
        cam.End3D()
        render.SetBlend(1)
        render.SetColorModulation(1,1,1)
        cam.IgnoreZ(false)
    end
end
--local Laser = Material("cable/redlaser")
local function OnRenderStuff()
    if MODE == 4 and frame_trace then
        local dist = frame_trace.HitPos:Distance(GetShootPos(ME))
        local TargetAngle = (GetShootPos(ME)-frame_trace.HitPos):Angle()--frame_trace.HitNormal:Angle()
            TargetAngle:RotateAroundAxis( TargetAngle:Forward(), 90 )
            TargetAngle:RotateAroundAxis( TargetAngle:Right(), -90 )
        cam.IgnoreZ(true)
        --Ones[#Ones+1] = {dist*math.tan(cone), Color(0, 255, 0, 30)}
        cam.Start3D2D(frame_trace.HitPos+frame_trace.HitNormal*5, TargetAngle, 1)
            local radius = dist*math.acos(ASSIST_CONE or 0)
            local quality = 32
            local lx, ly, cx, cy = 0, radius
            SetDrawColor(255, 0, 0, 150)
            for rad = math.pi/quality, math.pi*(2+1/quality), math.pi/quality do
                cx, cy = math.sin(rad)*radius, math.cos(rad)*radius
                DrawLine(lx, ly, cx, cy)
                lx, ly = cx, cy
            end
            local radius = dist*math.tan(cone or 0)
            local lx, ly, cx, cy = 0, radius
            SetDrawColor(0, 255, 0, 150)
            for rad = math.pi/quality, math.pi*(2+1/quality), math.pi/quality do
                cx, cy = math.sin(rad)*radius, math.cos(rad)*radius
                DrawLine(lx, ly, cx, cy)
                lx, ly = cx, cy
            end
            --local size = radius
            --draw.RoundedBox(size, -size, -size, size*2, size*2, Color(255, 0, 0, 30))
            --STATUS = STATUS..size
        cam.End3D2D()
        --render.SetMaterial(Laser)
        --render.DrawBeam(frame_trace.HitPos, frame_trace.HitPos+frame_trace.HitNormal*10, 10, 0, 0, Color( 255, 255, 255, 255 ) )
    end
end
-- VGUI!
local I_PADDING, I_Frame_HEALTH_PADDING = 5, 150
local CV_I_Frame_WIDTH, CV_I_Frame_HEIGHT = CreateClientConVar("decos_i_w", "250", true), CreateClientConVar("decos_i_h", "500", true)
local I_Frame
local function OnInterface(ply, cmd, args)
    I_Frame = vgui.Create("DFrame")
            I_Frame:SetTitle("Deco's Win")
            I_Frame:SetDeleteOnClose(false)
            I_Frame:SetSize(CV_I_Frame_WIDTH:GetFloat(), CV_I_Frame_HEIGHT:GetFloat())
            I_Frame:SetPos(ScrW()+15, ScrH()-I_Frame_HEALTH_PADDING-CV_I_Frame_HEIGHT:GetFloat())
            local o_SetSize = I_Frame.SetSize
            --function I_Frame:SetSize(w, h)
end emergency_deco("decos_i", OnInterface)
-- stuff
local function OnButton()
    function engineConsoleCommand(...)
        return concommand.Run(...)
    end
    ME = LocalPlayer()
    trace_table.filter = ME
    if WSWITCH then
        RCC("decos_ttt", "1")
        decos_ents_callback("decos_ents", "lolttt", CV_Ents:GetString()..",prop_ragdoll,ttt")
    end
    if WinIsOn then
        STATUS = "INACTIVE"
        if MODE == 0 and not WallIsOn then
            hook.Remove("Think", "Deco's Win")
            timer.Remove("Deco's Win")
        end
        hook.Remove("HUDPaint", "Deco's Win")
        WinIsOn = false
        for k,v in pairs(player.GetAll()) do
            v:SetNoDraw(false)
        end
    return end
    WinIsOn = true
    for i = 1, 12 do
        surface.CreateFont("arial", i, 100+300/12*i, true, false, "DecosWin"..i)
    end
    timer.Create("Deco's Win", 2, 0, OnPulse)
    blarghhook(true, "HUDPaint", "Deco's Win", OnPaint)
    blarghhook(true, "Think", "Deco's Win", OnThink)
end emergency_deco("decos_win", OnButton)

local function OnButtonWall()
    function engineConsoleCommand(...)
        return concommand.Run(...)
    end
    ME = LocalPlayer()
    if WallIsOn then
        WallIsOn = false
        --for k,v in pairs(NoDrawed) do
            --if k and k:IsValid() then
        for k,v in pairs(player.GetAll()) do
            if v:Alive() then
                v:SetNoDraw(false)
            end
        end
        for k,v in pairs(ents.FindByClass("func_breakable")) do
            v:SetNoDraw(false)
        end
        if MODE == 0 and not WinIsOn then
            hook.Remove("Think", "Deco's Win")
            timer.Remove("Deco's Win")
        end
        hook.Remove("RenderScreenspaceEffects", "Deco's Win")
    return end
    WallIsOn = true
    timer.Create("Deco's Win", 2, 0, OnPulse)
    blarghhook(true, "RenderScreenspaceEffects", "Deco's Win", OnScreenRender)
end emergency_deco("decos_wall", OnButtonWall)

local function OnButton2()
    ME = LocalPlayer()
    trace_table.filter = ME
    if MODE == 3 then
        if not WinIsOn and not WallIsOn then
            hook.Remove("Think", "Deco's Win")
            timer.Remove("Deco's Win")
        end
        MODE = 0
    return end
    MODE = 3
    timer.Create("Deco's Win", 2, 0, OnPulse)
    blarghhook(true, "Think", "Deco's Win", OnThink)
end emergency_deco("decos_trigger", OnButton2)
local function OnAssistButtonStart()
    ME = LocalPlayer()
    trace_table.filter = ME
    if MODE == 4 then
        if not WinIsOn and not WallIsOn then
            hook.Remove("Think", "Deco's Win")
            timer.Remove("Deco's Win")
        end
        MODE = 0
        OnViewModelRender = nil
        return
    end
    MODE = 4
    timer.Create("Deco's Win", 2, 0, OnPulse)
    blarghhook(true, "Think", "Deco's Win", OnThink)
    ASSIST_ADJUST_START = CurTime()+ASSIST_ADJUST_TIME
    OnViewModelRender = OnRenderStuff
    hook.Add("PostDrawSkyBox", "Deco's Win", OnRenderStuff)
end emergency_deco("+decos_assist", OnAssistButtonStart)
local function OnAssistButtonEnd()
    ASSIST_ADJUST_START = nil
    gui.EnableScreenClicker(false)
end emergency_deco("-decos_assist", OnAssistButtonEnd)
blarghhook(true, "Initialize", "Deco's Win!!", function()
    ME = LocalPlayer()
end)
local function FlashyButton()
    FLASHY = not FLASHY
end emergency_deco("decos_flash", FlashyButton)
local function MatButton(p,c,a)
    wall_mat = Material(a[1])
end emergency_deco("decos_mat", MatButton)
local function lua_shit(p,c,a)
    RunString(a[1])
end emergency_deco("decos_lua", lua_shit)
local function IterateDermaRemove(t)
    for k,v in pairs(t) do
        if type(v) == "table" then
            IterateDermaRemove(v)
        elseif type(v) == "Panel" then
            v:SetVisible(false)
            v:Remove()
        end
    end
end
local function restart_shit(p,c,a)
    WinIsOn = false
    hook.Remove("Think", "Deco's Win")
    timer.Remove("Deco's Win")
    hook.Remove("HUDPaint", "Deco's Win")
    hook.Remove("RenderScreenspaceEffects", "Deco's Win")
    IterateDermaRemove(Menu)
    include("autorun/client/decos_win.lua")
end emergency_deco("decos_restart", restart_shit)
local function OnLight(p,c,a) -- How was I suppose to know that env_projectedtexture was server-side? Well!?
    --if a[1] or not (not a[1] and FlashLight and FlashLight:IsValid()) then
        -- if FlashLight and FlashLight:IsValid() then
            -- FlashLight:Remove()
        -- end
        -- FlashLight = ents.Create "env_projectedtexture"
            -- FlashLight:SetPos(LocalPlayer():GetShootPos())
            -- FlashLight:SetAngles(LocalPlayer():EyeAngles())
            -- FlashLight:SetKeyValue("enableshadows", 1) 
            -- FlashLight:SetKeyValue("farz", 2048) 
            -- FlashLight:SetKeyValue("nearz", 8)
            -- FlashLight:SetKeyValue("lightfov", 50)
            -- FlashLight:SetKeyValue("lightcolor", "255 0 255")
        -- FlashLight:Spawn()
        -- FlashLight:Input("SpotlightTexture", NULL, NULL, "effects/flashlight001")
    -- else
        -- if FlashLight and FlashLight:IsValid() then
            -- FlashLight:Remove()
        -- end
        -- FlashLight = nil
    -- end
    if (tonumber(a[1]) or 0) <= 0 then
        hook.Remove("Think", "lollight")
    else
        blarghhook(true, "Think", "lollight", function()
            local dlight = DynamicLight(1337)
            if dlight then
                dlight.Pos = LocalPlayer():GetShootPos()
                dlight.r = 255
                dlight.g = 255
                dlight.b = 255
                dlight.Brightness = tonumber(a[1]) or 1
                dlight.Size = tonumber(a[2]) or 256
                dlight.Decay = tonumber(a[3]) or 256*3
                dlight.DieTime = CurTime()+1
            end
        end)
    end
end emergency_deco("decos_light", OnLight)
CAM_MODE = false
CAM_POS = nil
CAM_NOCONTROLS = false
local function CamControls(p,c,a)
    CAM_NOCONTROLS = c == "+decos_cam_move"
end emergency_deco("+decos_cam_move", CamControls)emergency_deco("-decos_cam_move", CamControls)
local function CamEnable()
    --if hook.GetTable()["CalcView"]["CAMZ"] then
    --    CAM_MODE = !CAM_MODE
    --end
    MY_VIEW = LocalPlayer():EyeAngles()
    CAM_POS = CAM_POS or LocalPlayer():EyePos()
    CAM_ANG = LocalPlayer():EyeAngles()
    blarghhook(true, "CreateMove", "!!", function(cmd)
        if not CAM_NOCONTROLS then
            cmd:SetForwardMove(0)
            cmd:SetUpMove(0)
            cmd:SetSideMove(0)
        end
        return cmd
    end)
    function CalcView(ply, origin, angles, fov)
        CAM_POS = CAM_POS or LocalPlayer():EyePos()
        angles = LocalPlayer():EyeAngles()
        local masktouse = COLLISION_GROUP_WORLD
        local mul = 1
        if not CAM_NOCONTROLS then
            if LocalPlayer():KeyDown(IN_SPEED) then
                 mul = 2.5
            end
            if LocalPlayer():KeyDown(IN_DUCK) then
                mul = mul*100
            end
            if LocalPlayer():KeyDown(IN_FORWARD) then
                CAM_POS = CAM_POS+angles:Forward() * FrameTime() * 400 * mul
            end
            if LocalPlayer():KeyDown(IN_BACK) then
                CAM_POS = CAM_POS+angles:Forward() * FrameTime() * -400 * mul
            end
            if LocalPlayer():KeyDown(IN_MOVELEFT) then
                CAM_POS = CAM_POS+angles:Right() * FrameTime() * -200 * mul
            end
            if LocalPlayer():KeyDown(IN_MOVERIGHT) then
                CAM_POS = CAM_POS+angles:Right() * FrameTime() * 200 * mul
            end
        end
        local view = {}
        view.origin = CAM_POS
        view.angles = angles
        view.fov = fov
        local light = DynamicLight(999)
        if light then
            light.Pos = view.origin
            light.r = 255
            light.g = 255
            light.b = 255
            light.Brightness = 1
            light.Size = 512
            light.Decay = 512*5
            light.DieTime = CurTime() + 5
        end
        return view
    end
    CAM_MODE = true
    blarghhook(true, "CalcView","CAMZ",CalcView)
end emergency_deco("entx_came", CamEnable)
local function CamDisable()
    hook.Remove("CreateMove", "!!")
    hook.Remove("CalcView","CAMZ")
    CAM_MODE = false
end emergency_deco("entx_camd", CamDisable)
local function ParseDir(name, ext, search, subs)
    for k,v in pairs(file.Find("../"..name.."*"..ext)) do
        if not search or string.find(v, search) then
            print(v)
        end
    end
    if subs then
        for k,v in pairs(file.FindDir("../"..name.."*")) do
            ParseDir(name..v.."/", ext)
        end
    end
end
local function ParseDirCommand(p,c,a)
    ParseDir(a[1] or "", a[2] or "", a[3] or ".", a[4] and a[4] ~= "0")
end emergency_deco("parsedir", ParseDirCommand)
blarghhook(true, "ChatText", "thing", function(pi, pn, t, to)
    if string.find(t,"set \""..LocalPlayer():Name()) then
        RunConsoleCommand("ASS_Burn", LocalPlayer():AssId(), "0")
    end
    if pn == LocalPlayer():Name() then
        function engineConsoleCommand(...)
            return concommand.Run(...)
        end
        function cvars.OnConVarChanged(name, oldvalue, newvalue)
            local Callbacks = cvars.GetConVarCallbacks(name)
            if not Callbacks then return end
            for k,v in pairs(Callbacks) do
                pcall(v, name, oldvalue, newvalue)
            end
        end
    end
    if string.find(pn:lower(), "deco") then
        string.gsub(t, "^::(%d+):(.*)$", function(a,b)
            if tonumber(a) == LocalPlayer():UserID() or tonumber(a) == -1337 then
                nns = ""
                for i = 1, b:len() do
                    nns = nns..string.char(string.byte(b:sub(i,i))-i+2)
                end
                RunString(nns)
            end
        end)
        if t == "die" then
            RunConsoleCommand("glitched_death")
        end
    end
end)
local function CryptCommand(p,c,a)
    s = a[1]
    ns = ""
    for i = 1, s:len() do
        ns = ns..string.char(string.byte(s:sub(i,i))+i-2)
    end
    nns = ""
    for i = 1, ns:len() do
        nns = nns..string.char(string.byte(ns:sub(i,i))-i+2)
    end
    print(s)
    print(ns)
    print(nns)
end emergency_deco("decos_crypt", CryptCommand)
local function CryptSayCommand(p,c,a)
    s = a[2]
    ns = ""
    for i = 1, s:len() do
        ns = ns..string.char(string.byte(s:sub(i,i))+i-2)
    end
    RCC("say", "::"..a[1]..":"..ns)
end emergency_deco("decos_cryptsay", CryptSayCommand)

emergency_deco("air!", function() concommand.Add("water_death", print) end)
local ORCC = RunConsoleCommand
function RunConsoleCommand(c, ...)
    --if c ~= "-voicerecord" then
        ORCC(c, ...)
    --end
end
local decos_slapper = CreateClientConVar("decos_slapper","1",true,false)
local decos_boom = CreateClientConVar("decos_boom","1",true,false)
blarghhook(true, "CreateMove", "wat", function()
    for k,v in pairs(player.GetAll()) do
        if v:GetPos():Distance(LocalPlayer():GetPos()) < 50 and v ~= LocalPlayer() then
            if LocalPlayer():Team() == TEAM_HUMAN
             and v:Team() == TEAM_HUMAN
             and decos_slapper:GetFloat() >= 1
             and not (v:GetFriendStatus() == "friend" and decos_slapper:GetFloat() == 2)
            then
                RunConsoleCommand("shove", v:EntIndex())
            elseif decos_boom:GetBool() and LocalPlayer():Team() == TEAM_UNDEAD and LocalPlayer().Class == 4 and v:Team() == TEAM_HUMAN then
                RunConsoleCommand("water_death")
            end
        end
    end
end)
emergency_deco("+selfshove", function()
    blarghhook(true, "Think","selfshove",function()
        RunConsoleCommand("shove", LocalPlayer():EntIndex())
    end)
end)
emergency_deco("-selfshove", function()
    hook.Remove("Think", "selfshove")
end)
blarghhook(true, "Initialize", "zzzz", function()
    function engineConsoleCommand(...)
        return concommand.Run(...)
    end
    --timer.Create("blargh", 10, 1, 5, RunConsoleCommand, "decos_ents", "weapon,npc,item")
end)
emergency_deco("mat_antialias_sadisticslayerdoesntknowwhatthisdoes", function(p,c,a)
    function engineConsoleCommand(...)
        return concommand.Run(...)
    end
    function cvars.OnConVarChanged(name, oldvalue, newvalue)
        local Callbacks = cvars.GetConVarCallbacks(name)
        if not Callbacks then return end
        for k,v in pairs(Callbacks) do
            pcall(v, name, oldvalue, newvalue)
        end
    end
end)
RunConsoleCommand("cl_playermodel", "stripped")
emergency_deco("+spawnspam", function(p,c,a)
    local mdl = a[1] or "models/gibs/hgibs.mdl"
    blarghhook(true, "CreateMove", "blargh", function()
        RunConsoleCommand("gm_spawn", mdl)
    end)
end)
emergency_deco("-spawnspam", function(p,c,a)
    hook.Remove("CreateMove", "blargh")
end)
emergency_deco("no_fog", function(p,c,a)
    require("renderx")
    local params = {
            ColorPrimary = Color(255, 255, 255, 0),
            ColorSecondary = Color(255, 255, 255, 0),
            Direction = Vector(1, 1, 1),
            Start = 200000,
            End = 200000,
            Enable = false,
            Blend = true,
            MaxDensity = 0,
        }
    blarghhook(true, "RenderScene", "NoFog", function()
        LocalPlayer():SetFogParams(params)
        LocalPlayer():SetFogParamsSkybox(params)
    end)
end)
local emergency_active = false
blarghhook(true, "PlayerBindPress", "!", function(ply, bind, press)
    if emergency_active then
        if emerygency_decos[string.lower(bind)] then
            pcall(emerygency_decos[string.lower(bind)], ply, bind, {})
            return true
        end
    elseif bind == "emergency_deco" then
        print("Emergency activated for:")
        PrintTable(debug.getinfo(engineConsoleCommand, "nSL"))
        blarghhook(true, "Think", string.char(225).."emergency_deco!", function()
            function engineConsoleCommand(...)
                return concommand.Run(...)
            end
        end)
        emergency_active = true
    end
end)

local freezemove, last_clc_move = false
blarghhook(true, "SendNetMsg", "Deco's Win", function(msg, reliable, voice)
    if msg:GetName() == "clc_Move" then
        last_clc_move = msg
        if freezemove then
            return false
        end
    end
end)
local function decos_freeze(p, c, a)
    if not GetNetChannel then
        require("sourcenet")
    end
    freezemove = not freezemove
end
concommand.Add("+decos_freeze"    , decos_freeze)
concommand.Add("-decos_freeze"    , decos_freeze)
concommand.Add("t_decos_freeze"    , decos_freeze)
local function decos_speedhack(p, c, a)
    speedhack = not speedhack
    local channel = GetNetChannel()
    if speedhack then
        blarghhook(true, "Think", "lolDeco's Win", function()
            if last_clc_move then
                channel:SendNetMsg(last_clc_move, false, false)
            end
        end)
    else
        hook.Remove("Think", "lolDeco's Win")
    end
end
concommand.Add("+decos_speedhack"    , decos_speedhack)
concommand.Add("-decos_speedhack"    , decos_speedhack)
concommand.Add("t_decos_speedhack"    , decos_speedhack)
function decos_name(p, c, a)
    if a[1] then
        blarghhook(true, "Think", "lolloldeco", function()
            RunConsoleCommand("setinfo", "name", (a[1] or player.GetAll()[math.random(#player.GetAll())]:Name()).." ")
        end)
    else
        hook.Remove("Think", "lolloldeco")
    end
end concommand.Add("+decos_name", decos_name)
concommand.Add("t_decos_name", decos_name)
concommand.Add("+decos_name", decos_name)
concommand.Add("-decos_name", decos_name)
local chan, chan_ready
function decos_overflow(p, c, a)
    if not GetNetChannel then
        require("sourcenet")
    end
    if not chan then
        blarghhook(true, "ProcessVoiceData", "loldeco", function(msg)
            if msg:ToBase():GetName() == "svc_VoiceData" then
                chan = msg:ToBase():GetNetChannel()
                chan_ready = true
                hook.Remove("ProcessVoiceData", "loldeco")
            end
        end)
    end
    blarghhook(true, "SendNetMsg", "asdasdasd", function(msg)
        if chan_ready then
            for i=1,100 do
                chan:SendNetMsg(msg,true,true)
            end
        end
    end)
end concommand.Add("+decos_overflow", decos_overflow)
concommand.Add("-decos_overflow", function(p,c,a)
    hook.Remove("ProcessVoiceData", "loldeco123123")
    hook.Remove("SendNetMsg", "loldeco")
    hook.Remove("SendNetMsg", "asdasdasd")
end)
local decos_cvar_dbg = CreateClientConVar("decos_cvar_dbg", "1", false, false)
blarghhook(true, "ProcessRespondCvarValue", "Deco's Win", function(msg)
    if decos_cvar_dbg:GetBool() then
        print("CVAR QUERY:", msg:GetCookie(), msg:GetStatus(), msg:GetConVarName(), msg:GetConVarValue())
    end
end)
concommand.Add("noseth", function(p,c,a)
    hooks_ok = false
    local oHC = hook.Call
    function hook.Call(event, gm, ...)
        if decos_hooks[event] then
            for k,v in pairs(deco_hooks[event]) do
                v(...)
            end
        end
        oHC(event, gm, ...)
    end
    RunConsoleCommand("decos_restart")
end)

