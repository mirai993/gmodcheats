local NH_NORECOIL = false
local NH_WALLHACK = false
local NH_DRAWBOX = false
local NH_ESP = false
local NH_BARREL = false
local NH_TRACE = false
local NH_RADAR = false
local NH_RADAR_SIZE = 128
local NH_RADAR_SCALE = 2048
local NH_RADAR_POS = { ScrW() * 0.1, ScrH() / 2 }
local NH_CROSSHAIR = false
local NH_BONESCAN = false
local NH_AUTOSHOT = false
local NH_TRIGGER = false
local NH_IGNORE_TEAM = false
local NH_IGNORE_STEAM = false
local NH_NICK = false
local NH_INFO = false
local NH_AIM_ENABLED = false
local NH_BUTTON = 0
local NH_SHOOTCMD = 1
local NH_LOOKUPBONE = 'Head'
local NH_BUNNYHOP = false
local NH_TARGET_NPC = false
local NH_AUTOPISTOL = false

local nh_target
local nh_aimbot = false
local nh_keydown = false
local nh_radar_grab = false
local nh_bones = {
	Head = 'ValveBiped.Bip01_Head1',
    Neck = 'ValveBiped.Bip01_Neck1',
    Spine = 'ValveBiped.Bip01_Spine',
    Spine1 = 'ValveBiped.Bip01_Spine1',
    Spine2 = 'ValveBiped.Bip01_Spine2',
    Spine3 = 'ValveBiped.Bip01_Spine3',
    Spine4 = 'ValveBiped.Bip01_Spine4',
    [ 'R Upperarm' ] = 'ValveBiped.Bip01_R_UpperArm',
    [ 'R Forearm' ] = 'ValveBiped.Bip01_R_Forearm',
    [ 'R Hand' ] = 'ValveBiped.Bip01_R_Hand',
    [ 'L Upperarm' ] = 'ValveBiped.Bip01_L_UpperArm',
    [ 'L Forearm' ] = 'ValveBiped.Bip01_L_Forearm',
    [ 'L Hand' ] = 'ValveBiped.Bip01_L_Hand',
    [ 'R Thigh' ] = 'ValveBiped.Bip01_R_Thigh',
    [ 'R Calf' ] = 'ValveBiped.Bip01_R_Calf',
    [ 'R Foot' ] = 'ValveBiped.Bip01_R_Foot',
    [ 'R Toes' ] = 'ValveBiped.Bip01_R_Toe0',
    [ 'L Thigh' ] = 'ValveBiped.Bip01_L_Thigh',
    [ 'L Calf' ] = 'ValveBiped.Bip01_L_Calf',
    [ 'L Foot' ] = 'ValveBiped.Bip01_L_Foot',
    [ 'L Toes' ] = 'ValveBiped.Bip01_L_Toe0'
}

local nh_buttons = { MOUSE_LEFT, MOUSE_MIDDLE, MOUSE_RIGHT }
local nh_cmd = { 'attack', 'attack2' }
local nh_stencil = Material( 'models/debug/debugwhite' )

local function NH_TARGETS()
	local targets = {}
	for _, pl in pairs( player.GetAll() ) do
		if pl:Health() > 0 then
			table.insert( targets, pl )
		end
	end
	
	if NH_TARGET_NPC then
		table.Add( targets, ents.FindByClass( 'npc_*' ) )
	end
	
	return targets
end

local function NH_CANTARGET( ply )
	local self = LocalPlayer()
	
	if NH_TARGET_NPC and ply:IsNPC() then return true end
	if NH_IGNORE_TEAM and ply:IsPlayer() and ply:Team() == self:Team() then return false end
	if NH_IGNORE_STEAM and ply:IsPlayer() and ply:GetFriendStatus() == 'friend' then return false end
	
	return true
end

local function NH_GETPLAYERCOLOR( ply, alpha )
	local a, b = 0, 0
	if NH_CANTARGET( ply ) then
		a = 255
	else
		b = 255
	end
	
	return Color( a, b, 0, alpha or 255 )
end

local function NH_PREDICTPOS( pl, pos )
	return pos + pl:GetVelocity() * 0.02 - LocalPlayer():GetVelocity() * 0.05
end

local function NH_GETFOV( vec )
	local s = vec:ToScreen()
	return math.abs( ScrW() / 2 - s.x ) + math.abs( ScrH() / 2 - s.y )
end

local function NH_GETBONEPOS( pl )
	local self = LocalPlayer()
	
	local NH_BONE
	local bone = pl:LookupBone( nh_bones[ NH_LOOKUPBONE ] )
	if bone then
		NH_BONE = bone
	end
	
	if NH_BONE then
		local tr = util.TraceLine( {
			start = self:GetShootPos(),
			endpos = pl:GetBonePosition( NH_BONE ),
			filter = { self }
		} )
		
		if tr.Entity == pl then
			return pl:GetBonePosition( NH_BONE )
		end
	end
	
	if NH_BONESCAN then
		for bone = pl:GetBoneCount(), 0, -1 do
			local tr = util.TraceLine( {
				start = self:GetShootPos(),
				endpos = pl:GetBonePosition( bone ),
				filter = { self }
			} )
			
			if tr.Entity == pl then
				return pl:GetBonePosition( bone )
			end
		end
	end
end
	
local nh_menu
local nh_menu_pos = { 100, 100 }
local function NH_OPENMENU()
	nh_menu = vgui.Create( 'DFrame' )
	nh_menu:SetSize( 600, 400 )
	nh_menu:SetPos( unpack( nh_menu_pos ) )
	nh_menu:SetTitle( ' ' )
	nh_menu:ShowCloseButton( false )
	nh_menu:MakePopup()
	nh_menu.ctrls = {}
	nh_menu.Paint = function()
		nh_menu_pos[1], nh_menu_pos[2] = nh_menu:GetPos()
		
		surface.SetDrawColor( Color( 0, 0, 0, 128 ) )
		surface.DrawRect( 0, 0, nh_menu:GetWide(), nh_menu:GetTall() )
		
		surface.SetDrawColor( color_white )
		surface.DrawOutlinedRect( 0, 0, nh_menu:GetWide() - 1, nh_menu:GetTall() - 2 )
		
		surface.SetDrawColor( Color( 255, 100, 0, 255 ) )
		surface.DrawOutlinedRect( 1, 0, nh_menu:GetWide() - 1, nh_menu:GetTall() - 1 )
		
		surface.SetFont( 'Default' )
		surface.SetTextColor( Color( 255, 0, 0, 255 ) )
		surface.SetTextPos( nh_menu:GetWide() / 2 - surface.GetTextSize( 'NanoHack - Main menu' ) / 2, 2 )
		surface.DrawText( 'NanoHack - Main menu' )
		
		surface.SetDrawColor( Color( 150, 150, 150, 255 ) )
		surface.DrawRect( 5, 20, nh_menu:GetWide() - 10, 5 )
		surface.DrawRect( 5, 40, nh_menu:GetWide() - 10, 5 )
	end
	
	local tab1_1 = vgui.Create( 'DCheckBoxLabel', nh_menu )
		tab1_1:SetPos( 50, 60 )
		tab1_1:SetText( 'Enable aimbot' )
		tab1_1:SizeToContents()
		tab1_1:SetChecked( NH_AIM_ENABLED )
		tab1_1:SetVisible( false )
		tab1_1.OnChange = function()
			NH_AIM_ENABLED = tab1_1:GetChecked()
		end
		
	local tab1_2 = vgui.Create( 'DCheckBoxLabel', nh_menu )
		tab1_2:SetPos( 50, 80 )
		tab1_2:SetText( 'Automatic shooting (Shoot when aimbot is locked on target)' )
		tab1_2:SizeToContents()
		tab1_2:SetChecked( NH_AUTOSHOT )
		tab1_2:SetVisible( false )
		tab1_2.OnChange = function()
			NH_AUTOSHOT = tab1_2:GetChecked()
		end
		
	local tab1_3 = vgui.Create( 'DCheckBoxLabel', nh_menu )
		tab1_3:SetPos( 50, 100 )
		tab1_3:SetText( 'Trigger bot (Shoot when someone is under your crosshair)' )
		tab1_3:SizeToContents()
		tab1_3:SetChecked( NH_TRIGGER )
		tab1_3:SetVisible( false )
		tab1_3.OnChange = function()
			NH_TRIGGER = tab1_3:GetChecked()
		end
		
	local tab1_13 = vgui.Create( 'DCheckBoxLabel', nh_menu )
		tab1_13:SetPos( 50, 120 )
		tab1_13:SetText( 'AutoPistol (Shoot automatically with semi-automatic weapons)' )
		tab1_13:SizeToContents()
		tab1_13:SetChecked( NH_AUTOPISTOL )
		tab1_13:SetVisible( false )
		tab1_13.OnChange = function()
			NH_AUTOPISTOL = tab1_13:GetChecked()
		end
		
	local tab1_4 = vgui.Create( 'DCheckBoxLabel', nh_menu )
		tab1_4:SetPos( 50, 140 )
		tab1_4:SetText( 'BoneScan (Scan for avaliable bone, when target bone is unreachable)' )
		tab1_4:SizeToContents()
		tab1_4:SetChecked( NH_BONESCAN )
		tab1_4:SetVisible( false )
		tab1_4.OnChange = function()
			NH_BONESCAN = tab1_4:GetChecked()
		end
	
	local tab1_5 = vgui.Create( 'DCheckBoxLabel', nh_menu )
		tab1_5:SetPos( 50, 160 )
		tab1_5:SetText( 'Ignore teammates' )
		tab1_5:SizeToContents()
		tab1_5:SetChecked( NH_IGNORE_TEAM )
		tab1_5:SetVisible( false )
		tab1_5.OnChange = function()
			NH_IGNORE_TEAM = tab1_5:GetChecked()
		end
		
	local tab1_6 = vgui.Create( 'DCheckBoxLabel', nh_menu )
		tab1_6:SetPos( 50, 180 )
		tab1_6:SetText( 'Ignore steam friends' )
		tab1_6:SizeToContents()
		tab1_6:SetChecked( NH_IGNORE_STEAM )
		tab1_6:SetVisible( false )
		tab1_6.OnChange = function()
			NH_IGNORE_STEAM = tab1_6:GetChecked()
		end
		
	local tab1_7 = vgui.Create( 'DCheckBoxLabel', nh_menu )
		tab1_7:SetPos( 50, 200 )
		tab1_7:SetText( 'Target NPCs' )
		tab1_7:SizeToContents()
		tab1_7:SetChecked( NH_TARGET_NPC )
		tab1_7:SetVisible( false )
		tab1_7.OnChange = function()
			NH_TARGET_NPC = tab1_7:GetChecked()
		end
		
	local tab1_8 = vgui.Create( 'DCheckBoxLabel', nh_menu )
		tab1_8:SetPos( 50, 220 )
		tab1_8:SetText( 'Shoot key (Unchecked - Mouse Left; checked - Mouse Right)' )
		tab1_8:SizeToContents()
		tab1_8:SetChecked( NH_SHOOTCMD == 2 )
		tab1_8:SetVisible( false )
		tab1_8.OnChange = function()
			if tab1_8:GetChecked() then
				NH_SHOOTCMD = 2
			else
				NH_SHOOTCMD = 1
			end
		end
	
	local tab1_9 = vgui.Create( 'DComboBox', nh_menu )
		tab1_9:SetPos( 50, 260 )
		tab1_9:SetWide( 128 )
		tab1_9:AddChoice( 'Automatic' )
		tab1_9:AddChoice( 'Mouse Left' )
		tab1_9:AddChoice( 'Mouse Middle' )
		tab1_9:AddChoice( 'Mouse Right' )
		
		local text = {
			[0] = 'Automatic',
			'Mouse Left',
			'Mouse Middle',
			'Mouse Right'
		}
		
		tab1_9:SetText( text[ NH_BUTTON ] )
		tab1_9:SetVisible( false )
		tab1_9.OnSelect = function( _, _, str )
			local text = {
				Automatic = 0,
				[ 'Mouse Left' ] = 1,
				[ 'Mouse Middle' ] = 2,
				[ 'Mouse Right' ] = 3
			}
			
			NH_BUTTON = text[ str ]
		end
		
	local tab1_10 = vgui.Create( 'DComboBox', nh_menu )
		tab1_10:SetPos( 50, 290 )
		tab1_10:SetWide( 128 )
		for key in pairs( nh_bones ) do tab1_10:AddChoice( key ) end
		tab1_10:SetText( NH_LOOKUPBONE )
		tab1_10:SetVisible( false )
		tab1_10.OnSelect = function( _, _, str )
			NH_LOOKUPBONE = str
		end
		
	local tab1_11 = vgui.Create( 'DLabel', nh_menu )
		tab1_11:SetPos( 180, 265 )
		tab1_11:SetText( ' - aimkey' )
		tab1_11:SetVisible( false )
		tab1_11:SizeToContents()
		
	local tab1_12 = vgui.Create( 'DLabel', nh_menu )
		tab1_12:SetPos( 180, 295 )
		tab1_12:SetText( ' - target bone' )
		tab1_12:SetVisible( false )
		tab1_12:SizeToContents()
	
	local tab2_1 = vgui.Create( 'DCheckBoxLabel', nh_menu )
		tab2_1:SetPos( 50, 60 )
		tab2_1:SetText( 'Enable wallhack (See other players throught the walls)' )
		tab2_1:SizeToContents()
		tab2_1:SetChecked( NH_WALLHACK )
		tab2_1:SetVisible( false )
		tab2_1.OnChange = function()
			NH_WALLHACK = tab2_1:GetChecked()
		end
		
	local tab2_2 = vgui.Create( 'DCheckBoxLabel', nh_menu )
		tab2_2:SetPos( 50, 80 )
		tab2_2:SetText( 'Draw crosshair' )
		tab2_2:SizeToContents()
		tab2_2:SetChecked( NH_CROSSHAIR )
		tab2_2:SetVisible( false )
		tab2_2.OnChange = function()
			NH_CROSSHAIR = tab2_2:GetChecked()
		end
		
	local tab2_3 = vgui.Create( 'DCheckBoxLabel', nh_menu )
		tab2_3:SetPos( 50, 100 )
		tab2_3:SetText( 'Draw players\' nicks and NPCs\' classnames' )
		tab2_3:SizeToContents()
		tab2_3:SetChecked( NH_NICK )
		tab2_3:SetVisible( false )
		tab2_3.OnChange = function()
			NH_NICK = tab2_3:GetChecked()
		end
		
	local tab2_4 = vgui.Create( 'DCheckBoxLabel', nh_menu )
		tab2_4:SetPos( 50, 120 )
		tab2_4:SetText( 'Draw targets\' health and armor' )
		tab2_4:SizeToContents()
		tab2_4:SetChecked( NH_INFO )
		tab2_4:SetVisible( false )
		tab2_4.OnChange = function()
			NH_INFO = tab2_4:GetChecked()
		end
	
	local tab2_5 = vgui.Create( 'DCheckBoxLabel', nh_menu )
		tab2_5:SetPos( 50, 140 )
		tab2_5:SetText( 'Draw 2D boxes on targets' )
		tab2_5:SizeToContents()
		tab2_5:SetChecked( NH_ESP )
		tab2_5:SetVisible( false )
		tab2_5.OnChange = function()
			NH_ESP = tab2_5:GetChecked()
		end
		
	local tab2_6 = vgui.Create( 'DCheckBoxLabel', nh_menu )
		tab2_6:SetPos( 50, 160 )
		tab2_6:SetText( 'Draw 3D boxes on targets' )
		tab2_6:SizeToContents()
		tab2_6:SetChecked( NH_DRAWBOX )
		tab2_6:SetVisible( false )
		tab2_6.OnChange = function()
			NH_DRAWBOX = tab2_6:GetChecked()
		end
		
	local tab2_7 = vgui.Create( 'DCheckBoxLabel', nh_menu )
		tab2_7:SetPos( 50, 180 )
		tab2_7:SetText( 'Draw trace lines to players' )
		tab2_7:SizeToContents()
		tab2_7:SetChecked( NH_TRACE )
		tab2_7:SetVisible( false )
		tab2_7.OnChange = function()
			NH_TRACE = tab2_7:GetChecked()
		end
		
	local tab3_1 = vgui.Create( 'DCheckBoxLabel', nh_menu )
		tab3_1:SetPos( 50, 60 )
		tab3_1:SetText( 'Enabled' )
		tab3_1:SizeToContents()
		tab3_1:SetChecked( NH_RADAR )
		tab3_1:SetVisible( false )
		tab3_1.OnChange = function()
			NH_RADAR = tab3_1:GetChecked()
		end
		
	local tab3_2 = vgui.Create( 'DNumSlider', nh_menu )
		tab3_2:SetPos( 50, 80 )
		tab3_2:SetWide( 512 )
		tab3_2:SetMin( 45 )
		tab3_2:SetMax( math.min( ScrW(), ScrH() ) / 2 )
		tab3_2:SetDecimals( 0 )
		tab3_2:SetValue( NH_RADAR_SIZE )
		tab3_2:SetVisible( false )
		tab3_2:SetText( 'Size' )
		tab3_2.OnValueChanged = function()
			NH_RADAR_SIZE = tab3_2:GetValue()
		end
		
	local tab3_3 = vgui.Create( 'DNumSlider', nh_menu )
		tab3_3:SetPos( 50, 100 )
		tab3_3:SetWide( 512 )
		tab3_3:SetMin( 64 )
		tab3_3:SetMax( 16384 )
		tab3_3:SetDecimals( 0 )
		tab3_3:SetValue( NH_RADAR_SCALE )
		tab3_3:SetVisible( false )
		tab3_3:SetText( 'Radius' )
		tab3_3.OnValueChanged = function()
			NH_RADAR_SCALE = tab3_3:GetValue()
		end
		
	local tab4_1 = vgui.Create( 'DCheckBoxLabel', nh_menu )
		tab4_1:SetPos( 50, 60 )
		tab4_1:SetText( 'NoRecoil' )
		tab4_1:SizeToContents()
		tab4_1:SetChecked( NH_NORECOIL )
		tab4_1:SetVisible( false )
		tab4_1.OnChange = function()
			NH_NORECOIL = tab4_1:GetChecked()
		end
		
	local tab5_1 = vgui.Create( 'DCheckBoxLabel', nh_menu )
		tab5_1:SetPos( 50, 60 )
		tab5_1:SetText( 'BHOP' )
		tab5_1:SizeToContents()
		tab5_1:SetChecked( NH_BUNNYHOP )
		tab5_1:SetVisible( false )
		tab5_1.OnChange = function()
			NH_BUNNYHOP = tab5_1:GetChecked()
		end
	
	local tab5_3 = vgui.Create( 'DTextEntry', nh_menu )
		tab5_3:SetPos( 100, 80 )
		tab5_3:SetText( 'default' )
		tab5_3:SetWide( 128 )
		tab5_3:SetVisible( false )
		tab5_3.OnGetFocus = function()
			nh_menu.block = true
			nh_menu:ShowCloseButton( true )
		end
		
	local tab5_2 = vgui.Create( 'DButton', nh_menu )
		tab5_2:SetPos( 50, 80 )
		tab5_2:SetText( ' ' )
		tab5_2:SetWide( 40 )
		tab5_2:SetVisible( false )
		tab5_2.DoClick = function()
			if not file.Exists( tab5_3:GetValue() .. '.txt', 'DATA' ) then return end
			
			local f = file.Open( tab5_3:GetValue() .. '.txt', 'r', 'DATA' )
			local json = util.JSONToTable( f:Read( f:Size() ) or '' )
			f:Close()
			
			NH_NORECOIL = json.NH_NORECOIL
			NH_WALLHACK = json.NH_WALLHACK
			NH_DRAWBOX = json.NH_DRAWBOX
			NH_ESP = json.NH_ESP
			NH_BARREL = json.NH_BARREL
			NH_TRACE = json.NH_TRACE
			NH_RADAR = json.NH_RADAR
			NH_RADAR_SIZE = json.NH_RADAR_SIZE
			NH_RADAR_SCALE = json.NH_RADAR_SCALE
			NH_RADAR_POS = json.NH_RADAR_POS
			NH_CROSSHAIR = json.NH_CROSSHAIR
			NH_BONESCAN = json.NH_BONESCAN
			NH_AUTOSHOT = json.NH_AUTOSHOT
			NH_TRIGGER = json.NH_TRIGGER
			NH_IGNORE_TEAM = json.NH_IGNORE_TEAM
			NH_IGNORE_STEAM = json.NH_IGNORE_STEAM
			NH_NICK = json.NH_NICK
			NH_INFO = json.NH_INFO
			NH_AIM_ENABLED = json.NH_AIM_ENABLED
			NH_BUTTON = json.NH_BUTTON
			NH_SHOOTCMD = json.NH_SHOOTCMD
			NH_LOOKUPBONE = json.NH_LOOKUPBONE
			NH_BUNNYHOP = json.NH_BUNNYHOP
			NH_TARGET_NPC = json.NH_TARGET_NPC
			NH_AUTOPISTOL = json.NH_AUTOPISTOL
			
			if nh_menu.block then nh_menu:Remove() nh_menu = nil end
		end
		
		tab5_2.Paint = function()
			surface.SetDrawColor( Color( 255, 255, 0, 255 ) )
			surface.DrawOutlinedRect( 0, 0, tab5_2:GetWide(), tab5_2:GetTall() )
			
			surface.SetFont( 'Default' )
			surface.SetTextColor( color_white )
			surface.SetTextPos( tab5_2:GetWide() / 2 - surface.GetTextSize( 'Load' ) / 2, 5 )
			surface.DrawText( 'Load' )
		end
		
	local tab5_4 = vgui.Create( 'DButton', nh_menu )
		tab5_4:SetPos( 238, 80 )
		tab5_4:SetText( ' ' )
		tab5_4:SetWide( 40 )
		tab5_4:SetVisible( false )
		tab5_4.DoClick = function()
			local kv = {
				NH_NORECOIL = NH_NORECOIL,
				NH_WALLHACK = NH_WALLHACK,
				NH_DRAWBOX = NH_DRAWBOX,
				NH_ESP = NH_ESP,
				NH_BARREL = NH_BARREL,
				NH_TRACE = NH_TRACE,
				NH_RADAR = NH_RADAR,
				NH_RADAR_SIZE = NH_RADAR_SIZE,
				NH_RADAR_SCALE = NH_RADAR_SCALE,
				NH_RADAR_POS = NH_RADAR_POS,
				NH_CROSSHAIR = NH_CROSSHAIR,
				NH_BONESCAN = NH_BONESCAN,
				NH_AUTOSHOT = NH_AUTOSHOT,
				NH_TRIGGER = NH_TRIGGER,
				NH_IGNORE_TEAM = NH_IGNORE_TEAM,
				NH_IGNORE_STEAM = NH_IGNORE_STEAM,
				NH_NICK = NH_NICK,
				NH_INFO = NH_INFO,
				NH_AIM_ENABLED = NH_AIM_ENABLED,
				NH_BUTTON = NH_BUTTON,
				NH_SHOOTCMD = NH_SHOOTCMD,
				NH_LOOKUPBONE = NH_LOOKUPBONE,
				NH_BUNNYHOP = NH_BUNNYHOP,
				NH_TARGET_NPC = NH_TARGET_NPC,
				NH_AUTOPISTOL = NH_AUTOPISTOL
			}
			
			local f = file.Open( tab5_3:GetValue() .. '.txt', 'w', 'DATA' )
			f:Write( util.TableToJSON( kv ) )
			f:Close()
			
			if nh_menu.block then nh_menu:Remove() nh_menu = nil end
		end
		
		tab5_4.Paint = function()
			surface.SetDrawColor( Color( 255, 255, 0, 255 ) )
			surface.DrawOutlinedRect( 0, 0, tab5_4:GetWide(), tab5_4:GetTall() )
			
			surface.SetFont( 'Default' )
			surface.SetTextColor( color_white )
			surface.SetTextPos( tab5_4:GetWide() / 2 - surface.GetTextSize( 'Save' ) / 2, 5 )
			surface.DrawText( 'Save' )
		end
	
	local tab1 = vgui.Create( 'DButton', nh_menu )
		tab1:SetPos( 15, 20 )
		tab1:SetSize( 70, 25 )
		tab1:SetText( ' ' )
		tab1.color = Color( 255, 255, 0, 255 )
		tab1.DoClick = function()
			for _, el in pairs( nh_menu.ctrls ) do
				if el ~= tab1 then
					el.color = Color( 255, 255, 0, 255 )
				end
			end
			
			tab1_1:SetVisible( true )
			tab1_2:SetVisible( true )
			tab1_3:SetVisible( true )
			tab1_4:SetVisible( true )
			tab1_5:SetVisible( true )
			tab1_6:SetVisible( true )
			tab1_7:SetVisible( true )
			tab1_8:SetVisible( true )
			tab1_9:SetVisible( true )
			tab1_10:SetVisible( true )
			tab1_11:SetVisible( true )
			tab1_12:SetVisible( true )
			tab1_13:SetVisible( true )
			
			tab2_1:SetVisible( false )
			tab2_2:SetVisible( false )
			tab2_3:SetVisible( false )
			tab2_4:SetVisible( false )
			tab2_5:SetVisible( false )
			tab2_6:SetVisible( false )
			tab2_7:SetVisible( false )
			
			tab3_1:SetVisible( false )
			tab3_2:SetVisible( false )
			tab3_3:SetVisible( false )
			
			tab4_1:SetVisible( false )

			tab5_1:SetVisible( false )
			tab5_2:SetVisible( false )
			tab5_3:SetVisible( false )
			tab5_4:SetVisible( false )
			
			tab1.color = Color( 0, 255, 0, 255 )
		end
		
		tab1.Paint = function()
			surface.SetDrawColor( tab1.color )
			surface.DrawOutlinedRect( 0, 0, tab1:GetWide(), tab1:GetTall() )
			
			surface.SetFont( 'Default' )
			surface.SetTextColor( color_white )
			surface.SetTextPos( tab1:GetWide() / 2 - surface.GetTextSize( 'Aimbot' ) / 2, 5 )
			surface.DrawText( 'Aimbot' )
		end
	
	table.insert( nh_menu.ctrls, tab1 )
	
	local tab2 = vgui.Create( 'DButton', nh_menu )
		tab2:SetPos( 115, 20 )
		tab2:SetSize( 70, 25 )
		tab2:SetText( ' ' )
		tab2.color = Color( 255, 255, 0, 255 )
		tab2.DoClick = function()
			for _, el in pairs( nh_menu.ctrls ) do
				if el ~= tab2 then
					el.color = Color( 255, 255, 0, 255 )
				end
			end
			
			tab1_1:SetVisible( false )
			tab1_2:SetVisible( false )
			tab1_3:SetVisible( false )
			tab1_4:SetVisible( false )
			tab1_5:SetVisible( false )
			tab1_6:SetVisible( false )
			tab1_7:SetVisible( false )
			tab1_8:SetVisible( false )
			tab1_9:SetVisible( false )
			tab1_10:SetVisible( false )
			tab1_11:SetVisible( false )
			tab1_12:SetVisible( false )
			tab1_13:SetVisible( false )
			
			tab2_1:SetVisible( true )
			tab2_2:SetVisible( true )
			tab2_3:SetVisible( true )
			tab2_4:SetVisible( true )
			tab2_5:SetVisible( true )
			tab2_6:SetVisible( true )
			tab2_7:SetVisible( true )
			
			tab3_1:SetVisible( false )
			tab3_2:SetVisible( false )
			tab3_3:SetVisible( false )
			
			tab4_1:SetVisible( false )
			
			tab5_1:SetVisible( false )
			tab5_2:SetVisible( false )
			tab5_3:SetVisible( false )
			tab5_4:SetVisible( false )
			
			tab2.color = Color( 0, 255, 0, 255 )
		end
		
		tab2.Paint = function()
			surface.SetDrawColor( tab2.color )
			surface.DrawOutlinedRect( 0, 0, tab2:GetWide(), tab2:GetTall() )
			
			surface.SetFont( 'Default' )
			surface.SetTextColor( color_white )
			surface.SetTextPos( tab2:GetWide() / 2 - surface.GetTextSize( '3D Radar' ) / 2, 5 )
			surface.DrawText( '3D Radar' )
		end
	
	table.insert( nh_menu.ctrls, tab2 )
	
	local tab3 = vgui.Create( 'DButton', nh_menu )
		tab3:SetPos( 215, 20 )
		tab3:SetSize( 70, 25 )
		tab3:SetText( ' ' )
		tab3.color = Color( 255, 255, 0, 255 )
		tab3.DoClick = function()
			for _, el in pairs( nh_menu.ctrls ) do
				if el ~= tab3 then
					el.color = Color( 255, 255, 0, 255 )
				end
			end
			
			tab1_1:SetVisible( false )
			tab1_2:SetVisible( false )
			tab1_3:SetVisible( false )
			tab1_4:SetVisible( false )
			tab1_5:SetVisible( false )
			tab1_6:SetVisible( false )
			tab1_7:SetVisible( false )
			tab1_8:SetVisible( false )
			tab1_9:SetVisible( false )
			tab1_10:SetVisible( false )
			tab1_11:SetVisible( false )
			tab1_12:SetVisible( false )
			tab1_13:SetVisible( false )
			
			tab2_1:SetVisible( false )
			tab2_2:SetVisible( false )
			tab2_3:SetVisible( false )
			tab2_4:SetVisible( false )
			tab2_5:SetVisible( false )
			tab2_6:SetVisible( false )
			tab2_7:SetVisible( false )
			
			tab3_1:SetVisible( true )
			tab3_2:SetVisible( true )
			tab3_3:SetVisible( true )
			
			tab4_1:SetVisible( false )
			
			tab5_1:SetVisible( false )
			tab5_2:SetVisible( false )
			tab5_3:SetVisible( false )
			tab5_4:SetVisible( false )
			
			tab3.color = Color( 0, 255, 0, 255 )
		end
		
		tab3.Paint = function()
			surface.SetDrawColor( tab3.color )
			surface.DrawOutlinedRect( 0, 0, tab3:GetWide(), tab3:GetTall() )
			
			surface.SetFont( 'Default' )
			surface.SetTextColor( color_white )
			surface.SetTextPos( tab3:GetWide() / 2 - surface.GetTextSize( '2D Radar' ) / 2, 5 )
			surface.DrawText( '2D Radar' )
		end
	
	table.insert( nh_menu.ctrls, tab3 )
	
	local tab4 = vgui.Create( 'DButton', nh_menu )
		tab4:SetPos( 315, 20 )
		tab4:SetSize( 70, 25 )
		tab4:SetText( ' ' )
		tab4.color = Color( 255, 255, 0, 255 )
		tab4.DoClick = function()
			for _, el in pairs( nh_menu.ctrls ) do
				if el ~= tab4 then
					el.color = Color( 255, 255, 0, 255 )
				end
			end
			
			tab1_1:SetVisible( false )
			tab1_2:SetVisible( false )
			tab1_3:SetVisible( false )
			tab1_4:SetVisible( false )
			tab1_5:SetVisible( false )
			tab1_6:SetVisible( false )
			tab1_7:SetVisible( false )
			tab1_8:SetVisible( false )
			tab1_9:SetVisible( false )
			tab1_10:SetVisible( false )
			tab1_11:SetVisible( false )
			tab1_12:SetVisible( false )
			tab1_13:SetVisible( false )
			
			tab2_1:SetVisible( false )
			tab2_2:SetVisible( false )
			tab2_3:SetVisible( false )
			tab2_4:SetVisible( false )
			tab2_5:SetVisible( false )
			tab2_6:SetVisible( false )
			tab2_7:SetVisible( false )
			
			tab3_1:SetVisible( false )
			tab3_2:SetVisible( false )
			tab3_3:SetVisible( false )
			
			tab4_1:SetVisible( true )
			
			tab5_1:SetVisible( false )
			tab5_2:SetVisible( false )
			tab5_3:SetVisible( false )
			tab5_4:SetVisible( false )
			
			tab4.color = Color( 0, 255, 0, 255 )
		end
		
		tab4.Paint = function()
			surface.SetDrawColor( tab4.color )
			surface.DrawOutlinedRect( 0, 0, tab4:GetWide(), tab4:GetTall() )
			
			surface.SetFont( 'Default' )
			surface.SetTextColor( color_white )
			surface.SetTextPos( tab4:GetWide() / 2 - surface.GetTextSize( 'Removals' ) / 2, 5 )
			surface.DrawText( 'Removals' )
		end
	
	table.insert( nh_menu.ctrls, tab4 )
	
	local tab5 = vgui.Create( 'DButton', nh_menu )
		tab5:SetPos( 515, 20 )
		tab5:SetSize( 70, 25 )
		tab5:SetText( ' ' )
		tab5.color = Color( 255, 255, 0, 255 )
		tab5.DoClick = function()
			for _, el in pairs( nh_menu.ctrls ) do
				if el ~= tab5 then
					el.color = Color( 255, 255, 0, 255 )
				end
			end
			
			tab1_1:SetVisible( false )
			tab1_2:SetVisible( false )
			tab1_3:SetVisible( false )
			tab1_4:SetVisible( false )
			tab1_5:SetVisible( false )
			tab1_6:SetVisible( false )
			tab1_7:SetVisible( false )
			tab1_8:SetVisible( false )
			tab1_9:SetVisible( false )
			tab1_10:SetVisible( false )
			tab1_11:SetVisible( false )
			tab1_12:SetVisible( false )
			tab1_13:SetVisible( false )
			
			tab2_1:SetVisible( false )
			tab2_2:SetVisible( false )
			tab2_3:SetVisible( false )
			tab2_4:SetVisible( false )
			tab2_5:SetVisible( false )
			tab2_6:SetVisible( false )
			tab2_7:SetVisible( false )
			
			tab3_1:SetVisible( false )
			tab3_2:SetVisible( false )
			tab3_3:SetVisible( false )
			
			tab4_1:SetVisible( false )
			
			tab5_1:SetVisible( true )
			tab5_2:SetVisible( true )
			tab5_3:SetVisible( true )
			tab5_4:SetVisible( true )
			
			tab5.color = Color( 0, 255, 0, 255 )
		end
		
		tab5.Paint = function()
			surface.SetDrawColor( tab5.color )
			surface.DrawOutlinedRect( 0, 0, tab5:GetWide(), tab5:GetTall() )
			
			surface.SetFont( 'Default' )
			surface.SetTextColor( color_white )
			surface.SetTextPos( tab5:GetWide() / 2 - surface.GetTextSize( 'Misc' ) / 2, 5 )
			surface.DrawText( 'Misc' )
		end
	
	table.insert( nh_menu.ctrls, tab5 )
end

local function NH_CLOSEMENU()
	if nh_menu.block then return end

	nh_menu:Remove()
	nh_menu = nil
end

concommand.Add( '+nh_menu', NH_OPENMENU )
concommand.Add( '-nh_menu', NH_CLOSEMENU )

local _vk_jump
hook.Add( 'CreateMove', 'NH_CREATEMOVE', function( pCmd )
	local self = LocalPlayer()
	local tr = self:GetEyeTraceNoCursor()
	if ( NH_TRIGGER or NH_AUTOSHOT ) and nh_aimbot and nh_target and nh_target:IsValid() and nh_target:Health() > 0 and NH_CANTARGET( nh_target ) then
		local bp = NH_GETBONEPOS( nh_target )
		
		if bp then
			pCmd:SetViewAngles( ( NH_PREDICTPOS( nh_target, bp ) - self:GetShootPos() ):Angle() )
		end
	elseif NH_TRIGGER and ( tr.Entity:IsPlayer() or NH_TARGET_NPC and tr.Entity:IsNPC() ) and NH_CANTARGET( tr.Entity ) then 
		local bp = NH_GETBONEPOS( tr.Entity )
		
		if bp then
			pCmd:SetViewAngles( ( NH_PREDICTPOS( tr.Entity, bp ) - self:GetShootPos() ):Angle() )
		end
	end
	
	if nh_aimbot and nh_target and nh_target:IsValid() and nh_target:Health() > 0 and NH_CANTARGET( nh_target ) and NH_GETBONEPOS( nh_target ) or NH_TRIGGER and ( tr.Entity:IsPlayer() or NH_TARGET_NPC and tr.Entity:IsNPC() ) and NH_CANTARGET( tr.Entity )then
		if nh_keydown then
			RunConsoleCommand( '-' .. nh_cmd[ NH_SHOOTCMD ] )
			nh_keydown = false
		else
			RunConsoleCommand( '+' .. nh_cmd[ NH_SHOOTCMD ] )
			nh_keydown = true
		end
	elseif nh_keydown then
		RunConsoleCommand( '-' .. nh_cmd[ NH_SHOOTCMD ] )
		nh_keydown = false
	end
	
	if NH_BUNNYHOP and input.IsKeyDown( KEY_SPACE ) then
		if self:IsOnGround() then
			if _vk_jump then
				_vk_jump = false
			else
				_vk_jump = true
			end
		end
	elseif _vk_jump then
		_vk_jump = false
	end
	
	if _vk_jump then
		pCmd:SetButtons( IN_JUMP )
	end
end )

local dx, dy
hook.Add( 'Think', 'NH_THINK', function()
	local self = LocalPlayer()
	if NH_BUTTON == 0 then
		nh_aimbot = NH_AIM_ENABLED
	else
		nh_aimbot = input.IsMouseDown( nh_buttons[ NH_BUTTON ] ) and NH_AIM_ENABLED
	end
	
	if NH_AUTOPISTOL then
		if input.IsMouseDown( MOUSE_LEFT ) then
			RunConsoleCommand( '+attack' )
			timer.Simple( 0.01, function() RunConsoleCommand( '-attack' ) end )
		end
		
		if input.IsMouseDown( MOUSE_RIGHT ) then
			RunConsoleCommand( '+attack2' )
			timer.Simple( 0.01, function() RunConsoleCommand( '-attack2' ) end )
		end
	end
	
	local x, y = gui.MousePos()
	if input.IsMouseDown( MOUSE_LEFT ) then
		if not nh_radar_grab then
			dx = x - NH_RADAR_POS[1]
			dy = y - NH_RADAR_POS[2]
			
			nh_radar_grab = true
		end
	
		if ( NH_RADAR_POS[1] - NH_RADAR_SIZE ) < x and ( NH_RADAR_POS[1] + NH_RADAR_SIZE ) > x and ( NH_RADAR_POS[2] - NH_RADAR_SIZE ) < y and ( NH_RADAR_POS[2] + NH_RADAR_SIZE ) > y then		
			NH_RADAR_POS[1] = math.Clamp( x - dx, NH_RADAR_SIZE, ScrW() - NH_RADAR_SIZE )
			NH_RADAR_POS[2] = math.Clamp( y - dy, NH_RADAR_SIZE, ScrH() - NH_RADAR_SIZE )
		end
	else
		nh_radar_grab = false
	end
	
	if nh_aimbot then
		local fov
		for _, pl in pairs( NH_TARGETS() ) do
			if pl ~= self and pl:Health() > 0 then
				if NH_GETBONEPOS( pl ) and NH_CANTARGET( pl ) and --[[ pl:GetPos():Distance( self:GetPos() ) < ( dist or pl:GetPos():Distance( self:GetPos() ) + 1 ) and ]] NH_GETFOV( pl:GetPos() ) < ( fov or NH_GETFOV( pl:GetPos() ) + 1 ) then
					nh_target = pl
					dist = pl:GetPos():Distance( self:GetPos() )
					fov = NH_GETFOV( pl:GetPos() )
					found = true
				end
			end
		end
		
		if not found then
			nh_target = nil
		end
	end
end )

hook.Add( 'CalcView', 'NH_CAMERA', function( ply, pos, ang )
	if NH_NORECOIL and pos == ply:GetShootPos() then
		angles = ply:EyeAngles()
		
		return {
			angles = angles
		}
	end
end )

hook.Add( 'PreDrawOpaqueRenderables', 'NH_RENDER', function()
	if NH_WALLHACK then
		render.ClearStencil()
		render.SetStencilEnable( true )
		render.SetStencilFailOperation( STENCILOPERATION_KEEP )
		render.SetStencilPassOperation( STENCILOPERATION_KEEP )
		render.SetStencilZFailOperation( STENCILOPERATION_REPLACE )
		render.SetStencilCompareFunction( STENCILCOMPARISONFUNCTION_ALWAYS )
		
		render.SetStencilReferenceValue( 1 )
		render.SetBlend( 0.9 )
		render.MaterialOverride( nh_stencil )
			for _, pl in pairs( NH_TARGETS() ) do
				if pl:IsValid() then
					local col = table.Copy( NH_GETPLAYERCOLOR( pl ) )
						col.r = col.r / 255
						col.g = col.g / 255
					
					render.SetColorModulation( col.r, col.g, 0 )
					pl:DrawModel()
					
					if pl.GetActiveWeapon then
						local w = pl:GetActiveWeapon()
						if w and w:IsValid() then
							w:DrawModel()
						end
					end
					render.SetColorModulation( 1, 1, 1 )
				end
			end
		render.MaterialOverride()
		render.SetColorModulation( 1, 1, 1 )
		render.SetBlend( 1 )
		
		render.SetStencilCompareFunction( STENCILCOMPARISONFUNCTION_EQUAL )
		render.SuppressEngineLighting( true )
		render.MaterialOverride( nh_stencil )
			cam.IgnoreZ( true )
				for _, pl in pairs( NH_TARGETS() ) do
					if pl:IsValid() then
						local col = NH_GETPLAYERCOLOR( pl )
							col.r = col.r / 255
							col.g = col.g / 255
						
						render.SetColorModulation( col.r, col.g, 0 )
						pl:DrawModel()
						
						if pl.GetActiveWeapon then
							local w = pl:GetActiveWeapon()
							if w and w:IsValid() then
								w:DrawModel()
							end
						end
						render.SetColorModulation( 1, 1, 1 )
					end
				end
			cam.IgnoreZ( false )
		render.MaterialOverride()
		render.SuppressEngineLighting( false )
		render.SetStencilEnable( false )
	end
end )

hook.Add( 'HUDPaint', 'NH_RENDER', function()
	local self = LocalPlayer()
	
	surface.SetFont( 'ChatFont' )
	surface.SetTextColor( Color( 255, 50, 50, 255 ) )
	surface.SetTextPos( ScrW() / 2 - surface.GetTextSize( 'NanoHack' ) / 2, 10 )
	surface.DrawText( 'NanoHack' )
	
	if NH_TRACE then
		for _, pl in pairs( NH_TARGETS() ) do
			if pl ~= self then
				local scr = pl:GetPos():ToScreen()
				
				surface.SetDrawColor( NH_GETPLAYERCOLOR( pl ) )
				surface.DrawLine( ScrW() / 2, ScrH() / 2, math.Clamp( scr.x, 0, ScrW() ), math.Clamp( scr.y, 0, ScrH() ) )
			end
		end
	end
	
	if NH_CROSSHAIR then
		surface.SetDrawColor( color_white )
		surface.DrawLine( ScrW() / 2 - 52, ScrH() / 2, ScrW() / 2 + 52, ScrH() / 2 )
		surface.DrawLine( ScrW() / 2, ScrH() / 2 - 52, ScrW() / 2, ScrH() / 2 + 52 )
		
		surface.SetDrawColor( Color( 255, 0, 0, 255 ) )
		surface.DrawLine( ScrW() / 2 - 32, ScrH() / 2, ScrW() / 2 + 32, ScrH() / 2 )
		surface.DrawLine( ScrW() / 2, ScrH() / 2 - 32, ScrW() / 2, ScrH() / 2 + 32 )
	end
	
	if NH_RADAR then 
		surface.SetDrawColor( Color( 30, 30, 30, 75 ) )
		surface.DrawRect( NH_RADAR_POS[1] - NH_RADAR_SIZE, NH_RADAR_POS[2] - NH_RADAR_SIZE, 2 * NH_RADAR_SIZE + 2, 2 * NH_RADAR_SIZE + 2 )
		
		surface.SetDrawColor( Color( 255, 120, 0, 255 ) )
		surface.DrawLine( NH_RADAR_POS[1] - NH_RADAR_SIZE + 5, NH_RADAR_POS[2], NH_RADAR_POS[1] + NH_RADAR_SIZE - 5, NH_RADAR_POS[2] )
		surface.DrawLine( NH_RADAR_POS[1], NH_RADAR_POS[2] - NH_RADAR_SIZE + 5, NH_RADAR_POS[1], NH_RADAR_POS[2] + NH_RADAR_SIZE - 5 )
		
		for _, pl in pairs( NH_TARGETS() ) do
			local dst = pl:GetPos() - self:GetPos()
			if pl ~= self then
				dst:Rotate( Angle( 0, -self:EyeAngles().yaw + 90, 0 ) )
				dst[1] = math.Clamp( dst[1], -NH_RADAR_SCALE, NH_RADAR_SCALE )
				dst[2] = math.Clamp( dst[2], -NH_RADAR_SCALE, NH_RADAR_SCALE )
				
				dst = dst / NH_RADAR_SCALE * NH_RADAR_SIZE
				
				surface.SetDrawColor( NH_GETPLAYERCOLOR( pl ) )
				surface.DrawRect( NH_RADAR_POS[1] + dst[1] - 3, NH_RADAR_POS[2] - dst[2] - 3, 6, 6 )
			end
		end
	end
	
	if NH_ESP or NH_NICK or NH_INFO then
		for _, pl in pairs( NH_TARGETS() ) do
			if pl ~= self then
				local col = NH_GETPLAYERCOLOR( pl )
				local nom = pl:GetPos()
				local mon = nom + Vector( 0, 0, pl:OBBMaxs()[3] )
				
				local bot, top = nom:ToScreen(), mon:ToScreen()
				local h = ( bot.y - top.y )
				local w = h / 5
				
				if NH_ESP then
					surface.SetDrawColor( col )
					surface.DrawOutlinedRect( top.x - w, top.y, w * 2, bot.y - top.y )
				end
				
				if NH_NICK then
					local text = pl:GetClass()
					if pl:IsPlayer() then
						text = pl:Nick()
					end
					
					surface.SetFont( 'Default' )
					surface.SetTextColor( Color( 255, 255, 0, 255 ) )
					surface.SetTextPos( top.x - surface.GetTextSize( text ) / 2, top.y )
					surface.DrawText( text )
				end
				
				if NH_INFO then
					local wep = '<no weapon>'
					if pl.GetActiveWeapon and pl:GetActiveWeapon():IsValid() then
						wep = pl:GetActiveWeapon():GetClass()
					end
					
					if pl:IsPlayer() then
						str = 'Health: ' .. pl:Health() .. '%; Armor: ' .. pl:Armor() .. '%\nWeapon: ' .. wep
						str = str:Split( '\n' )
												
						surface.SetFont( 'Default' )
						surface.SetTextColor( Color( 0, 255, 0, 255 ) )
						
						for i, t in pairs( str ) do
							if bot.y - top.y < 32 then
								surface.SetTextPos( top.x - surface.GetTextSize( t ) / 2, top.y + i * 16 )
							else
								surface.SetTextPos( bot.x - surface.GetTextSize( t ) / 2, bot.y - 32 + i * 16  )
							end
							
							surface.DrawText( t )
						end
					end
				end
			end
		end
	end
	
	if NH_BARREL then
		for _, pl in pairs( NH_TARGETS() ) do
			if pl ~= self then
				local col = NH_GETPLAYERCOLOR( pl )
				local orig = pl:GetShootPos()
				local dest = orig + pl:GetAimVector() * 256
					orig, dest = orig:ToScreen(), dest:ToScreen()
				
				surface.SetDrawColor( col )
				surface.DrawLine( orig.x, orig.y, dest.x, dest.y )
			end
		end
	end
	
	if NH_DRAWBOX then
		for _, pl in pairs( NH_TARGETS() ) do
			if pl ~= self then
				surface.SetDrawColor( NH_GETPLAYERCOLOR( pl ) )
				
				local nom = pl:GetPos()
				local mon = nom + Vector( 0, 0, pl:OBBMaxs()[3] )
				
				local bnd1 = Vector( 16, 16, 0 )
					bnd1:Rotate( Angle( 0, pl:EyeAngles().yaw, 0 ) )
					bnd1 = ( nom + bnd1 ):ToScreen()
					
				local bnd2 = Vector( 16, -16, 0 )
					bnd2:Rotate( Angle( 0, pl:EyeAngles().yaw, 0 ) )
					bnd2 = ( nom + bnd2 ):ToScreen()
					
				local bnd3 = Vector( -16, -16, 0 )
					bnd3:Rotate( Angle( 0, pl:EyeAngles().yaw, 0 ) )
					bnd3 = ( nom + bnd3 ):ToScreen()
					
				local bnd4 = Vector( -16, 16, 0 )
					bnd4:Rotate( Angle( 0, pl:EyeAngles().yaw, 0 ) )
					bnd4 = ( nom + bnd4 ):ToScreen()
				
				local bnd5 = Vector( 16, 16, 0 )
					bnd5:Rotate( Angle( 0, pl:EyeAngles().yaw, 0 ) )
					bnd5 = ( mon + bnd5 ):ToScreen()
					
				local bnd6 = Vector( 16, -16, 0 )
					bnd6:Rotate( Angle( 0, pl:EyeAngles().yaw, 0 ) )
					bnd6 = ( mon + bnd6 ):ToScreen()
					
				local bnd7 = Vector( -16, -16, 0 )
					bnd7:Rotate( Angle( 0, pl:EyeAngles().yaw, 0 ) )
					bnd7 = ( mon + bnd7 ):ToScreen()
					
				local bnd8 = Vector( -16, 16, 0 )
					bnd8:Rotate( Angle( 0, pl:EyeAngles().yaw, 0 ) )
					bnd8 = ( mon + bnd8 ):ToScreen()
				
				surface.DrawLine( bnd1.x, bnd1.y, bnd2.x, bnd2.y )
				surface.DrawLine( bnd2.x, bnd2.y, bnd3.x, bnd3.y )
				surface.DrawLine( bnd3.x, bnd3.y, bnd4.x, bnd4.y )
				surface.DrawLine( bnd4.x, bnd4.y, bnd1.x, bnd1.y )
				
				surface.DrawLine( bnd5.x, bnd5.y, bnd6.x, bnd6.y )
				surface.DrawLine( bnd6.x, bnd6.y, bnd7.x, bnd7.y )
				surface.DrawLine( bnd7.x, bnd7.y, bnd8.x, bnd8.y )
				surface.DrawLine( bnd8.x, bnd8.y, bnd5.x, bnd5.y )
				
				surface.DrawLine( bnd1.x, bnd1.y, bnd5.x, bnd5.y )
				surface.DrawLine( bnd2.x, bnd2.y, bnd6.x, bnd6.y )
				surface.DrawLine( bnd3.x, bnd3.y, bnd7.x, bnd7.y )
				surface.DrawLine( bnd4.x, bnd4.y, bnd8.x, bnd8.y )
			end
		end
	end
end )

concommand.Add( 'lua', function( _, _, args )
	local lua = CompileString( table.concat( args, ' ' ), 'RunString', false )
	if type( lua ) == 'string' then
		MsgC( Color( 255, 0, 0 ), lua .. '\n' )
	else
		print( '> ' .. table.concat( args, ' ' ) )
		
		local ok, lua = pcall( lua )
		if not ok then
			MsgC( Color( 255, 0, 0 ), lua .. '\n' )
		end
	end
end )