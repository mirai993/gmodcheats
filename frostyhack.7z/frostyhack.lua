--[[
	!.lua
	lulululululul | (STEAM_0:0:18691624)
	===DStream===
]]

if SERVER then return end
--Speed optimising
local hook = require ( "hook" )
local concommand = require ( "concommand" )
local math = math
local pairs = pairs
local ipairs = ipairs
local RunConsoleCommand = RunConsoleCommand
local type = type
local Angle = Angle
local Vector = Vector
local ents = ents
local LocalPlayer = LocalPlayer
local draw = draw
local surface = surface
local vgui = vgui
local util = util or {}
util.tobool = util.tobool or tobool
local cam = cam

--settings
local FHack = {}
FHack.Settings = {}
FHack.Settings.ucmdcount = 0
FHack.Settings.ucmdcountnext = 0
FHack.Settings.PreAimOn = false
FHack.Settings.bonechecks = {
[1] = "ValveBiped.Bip01_Head1",
[2] = "ValveBiped.Bip01_L_Forearm",
[3] = "ValveBiped.Bip01_R_Forearm",
[4] = "ValveBiped.Bip01_L_Calf",
[5] = "ValveBiped.Bip01_R_Calf",
[6] = "ValveBiped.Bip01_L_Foot",
[7] = "ValveBiped.Bip01_R_Foot",
}
local target = CreateClientConVar("fhack",0,false,false)
local showesp = CreateClientConVar("fhackmodel",1,false,false)
local ragemode = CreateClientConVar("fhackrage",0,false,false)

function FHack:DrawStuff()
	if showesp:GetInt() == 0 then return end
	local gap = 10
	local length = 20
	local x, y = ScrW() / 2, ScrH() / 2
	surface.SetDrawColor( 100, 255, 0, 255 )
	surface.DrawLine( x - length, y, x - gap, y )
	surface.DrawLine( x + length, y, x + gap, y )
	surface.DrawLine( x, y - length, x, y - gap )
	surface.DrawLine( x, y + length, x, y + gap )
end
hook.Add("HUDPaint", "FHack.DrawStuff", FHack.DrawStuff)

function FHack:Models()
	if showesp:GetInt() == 0 then return end
	cam.Start3D(EyePos() , EyeAngles())
		for k , v in ipairs(ents.GetAll()) do
			if ValidEntity(v) and v != LocalPlayer() and type(v) == "Player" and !(v:Health() <= 0) then
				cam.IgnoreZ(true)
				v:DrawModel()
				cam.IgnoreZ(false)
			end
		end
	cam.End3D()
end
hook.Add("RenderScreenspaceEffects", "FHack.Models", FHack.Models)

local shootnow = false
local function shootnowenable()
	shootnow = true
end
concommand.Add( "+_aim", shootnowenable )
local function shootnowdisable()
	shootnow = false
	RunConsoleCommand("-attack")
end
concommand.Add( "-_aim", shootnowdisable )

function FHack:GetTarget()
	local sortedtargets = {} --Sorting targets
	for k , v in ipairs(ents.GetAll()) do
		if ValidEntity(v) and v != LocalPlayer() and type(v) == "Player" and !(v:Health() <= 0) and v:GetMoveType() == MOVETYPE_WALK then
			table.insert(sortedtargets , {ent = v , distance = LocalPlayer():GetPos():Distance(v:GetPos())})
		end
	end
	table.SortByMember(sortedtargets , "distance" , function(a , b) return a > b end )
	
	--finding best target
	for k , v in ipairs(sortedtargets) do
		for i=1,7 do
			local BoneIndx = v.ent:LookupBone(FHack.Settings.bonechecks[i])
			local BonePos , BoneAng = v.ent:GetBonePosition( BoneIndx )
			local trace = {}
			trace.start = LocalPlayer():GetShootPos()
			trace.endpos = BonePos
			trace.mask = 1174421507
			trace.filter = {LocalPlayer() , v.ent}

			local tr = util.TraceLine(trace)
			if not tr.Hit then
				return v.ent , BonePos
			end
			-- local tracedata = {}
			-- tracedata.start = LocalPlayer():GetShootPos()
			-- tracedata.endpos = BonePos
			-- tracedata.mask = 1174421507
			-- tracedata.filter = LocalPlayer()
			-- local trace = util.TraceLine(tracedata)
			-- if trace.Entity:IsPlayer() then
				-- return v.ent , BonePos
			-- end
		end
	end
end

function FHack.Aiming(ucmd)
	if target:GetInt() == 1 then
		local PTarget , PTargetPos = FHack:GetTarget()
		if PTargetPos then
			--Set the angles
			PTargetPos = FHack:Prediction( PTargetPos , PTarget )
			local playerviewangle = (PTargetPos - LocalPlayer():EyePos()):Angle()
			local targetaim = Angle( math.NormalizeAngle( playerviewangle.p ) , math.NormalizeAngle( playerviewangle.y ) , math.NormalizeAngle( playerviewangle.r ))
			ucmd:SetViewAngles(targetaim)
			--Setting Mouse to compenstate
			local diff = targetaim - ucmd:GetViewAngles()
			ucmd:SetMouseX( diff.y )
			ucmd:SetMouseY( diff.p )
			--Movement Adjustment
			local move = Vector( ucmd:GetForwardMove(), ucmd:GetSideMove(), 0)
			local norm = move:GetNormal()
			local set = Angle(Angle(norm) + (targetaim - LocalPlayer():EyePos())):Forward() * move:Length()
			ucmd:SetForwardMove(set.x)
			ucmd:SetSideMove(set.y)
			
			if ragemode:GetInt() == 1 then --Start Firing
				RunConsoleCommand("+attack")
			end
		end
		
		--Stop Firing
		if FHack.Settings.ucmdcountnext <= FHack.Settings.ucmdcount  then
			FHack.Settings.ucmdcountnext = FHack.Settings.ucmdcount + 3
			if ragemode:GetInt() == 1 then
				RunConsoleCommand("-attack")
			end
		end
		FHack.Settings.ucmdcount = FHack.Settings.ucmdcount + 1
	elseif shootnow == true then
		local PTarget , PTargetPos = FHack:GetTarget()
		if PTargetPos then
			--Set the angles
			PTargetPos = FHack:Prediction( PTargetPos , PTarget )
			local playerviewangle = (PTargetPos - LocalPlayer():EyePos()):Angle()
			local targetaim = Angle( math.NormalizeAngle( playerviewangle.p ) , math.NormalizeAngle( playerviewangle.y ) , math.NormalizeAngle( playerviewangle.r ))
			ucmd:SetViewAngles(targetaim)
			--Setting Mouse to compenstate
			local diff = targetaim - ucmd:GetViewAngles()
			ucmd:SetMouseX( diff.y )
			ucmd:SetMouseY( diff.p )
			--Movement Adjustment
			local move = Vector( ucmd:GetForwardMove(), ucmd:GetSideMove(), 0)
			local norm = move:GetNormal()
			local set = Angle(Angle(norm) + (targetaim - LocalPlayer():EyePos())):Forward() * move:Length()
			ucmd:SetForwardMove(set.x)
			ucmd:SetSideMove(set.y)
			
			RunConsoleCommand("+attack")
		end
		
		--Stop Firing
		if FHack.Settings.ucmdcountnext <= FHack.Settings.ucmdcount  then
			FHack.Settings.ucmdcountnext = FHack.Settings.ucmdcount + 3
			RunConsoleCommand("-attack")
		end
		FHack.Settings.ucmdcount = FHack.Settings.ucmdcount + 1
	end
end
hook.Add("CreateMove", "FHack.Aiming", FHack.Aiming)

-- function FHack:Prediction( pos, entity )
	-- local timesamount = 0.0085
	-- if LocalPlayer():GetVelocity():Length() > 100 then
		-- pos = pos - Vector(0 , 0 , LocalPlayer():GetVelocity():Length() / 250)
	-- end
	-- if LocalPlayer():GetPos():Distance(entity:GetPos()) > 1000 then
		-- pos = pos - Vector(0 , 0 , LocalPlayer():GetPos():Distance(entity:GetPos())/900)
		-- timesamount = 0.0083
	-- end
	-- return pos + entity:GetVelocity() * timesamount - LocalPlayer():GetVelocity() * timesamount
-- end

function FHack:Prediction( pos, entity )
	--local timesamount = 0.0085
	if LocalPlayer():GetVelocity():Length() > 100 then
		pos = pos - Vector(0 , 0 , LocalPlayer():GetVelocity():Length() / 250)
	end
	if LocalPlayer():GetPos():Distance(entity:GetPos()) > 1000 then
		pos = pos - Vector(0 , 0 , LocalPlayer():GetPos():Distance(entity:GetPos())/900)
	end
	return pos
end

function FHack:NoRecoilSpread()
	if ValidEntity(LocalPlayer()) and ValidEntity(LocalPlayer():GetActiveWeapon()) and (LocalPlayer():GetActiveWeapon().Primary and LocalPlayer():GetActiveWeapon().Primary.Recoil != 0) then
		LocalPlayer():GetActiveWeapon().Recoil = 0
		LocalPlayer():GetActiveWeapon().Primary.Recoil = 0
		LocalPlayer():GetActiveWeapon().Cone = 0
		LocalPlayer():GetActiveWeapon().Primary.Cone = 0
	end
end
hook.Add("Tick", "FHack.NoRecoilSpread", FHack.NoRecoilSpread)

print("\n-\n--\n----FROSTY HACK RUNNING----\n--\n-\n")

local PLAYER = FindMetaTable( "Player" )
function PLAYER:ViewPunch( angle )
	return false
end