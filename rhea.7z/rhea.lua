--[[
	MOD/lua/Rhea/client_load.lua
	gяєу нєℓℓισѕ | STEAM_0:0:53429341 <66.168.88.138:27006> | [27-10-13 11:39:29PM]
	===BadFile===
]]

/**************************************
__________.__                      ___ ___                __    
\______   \  |__   ____ _____     /   |   \_____    ____ |  | __
 |       _/  |  \_/ __ \\__  \   /    ~    \__  \ _/ ___\|  |/ /
 |    |   \   Y  \  ___/ / __ \_ \    Y    // __ \\  \___|    < 
 |____|_  /___|  /\___  >____  /  \___|_  /(____  /\___  >__|_ \
        \/     \/     \/     \/         \/      \/     \/     \/
**************************************/


local RH			= {};
local Admins		= {};
local SAdmins		= {};
local Name1			= tostring( math.random(1, 100) ) 
local Name2			= tostring( math.random(1, 1000) )
local Name3			= tostring( math.random(1, 10000) ) 
local rheaHooks		= { Hook = {}, Name = {}, Log = { "quit", "exit", "retry", "disconnect", "dac_pleasebanme" } }
local old_print 	= print
local old_msgn		= MsgN
local old_fileread 	= file.Read
local TS = GetConVar('host_timescale')
local CH = GetConVar('sv_cheats')
require("cvar3")

RH.Bools		= {
	[ "Rhea_ESP_Active" ] 		= true,
	[ "Rhea_ESP_Info" ]			= true,
	[ "Rhea_ESP_Box" ]			= false,
	[ "Rhea_ESP_XHair" ]		= false,
	[ "Rhea_ESP_Skeleton" ]		= false,
	[ "Rhea_ESP_Healthbar" ]	= false,
	[ "Rhea_ESP_Admin" ]		= true,
	[ "Rhea_ESP_AdminList" ]	= true,

	// Misc //
	[ "Rhea_MISC_BlockRCC" ]	= true,
	[ "Rhea_MISC_NoRecoil" ]	= true,
	[ "Rhea_MISC_Bhop" ]		= true,
};

RH.Binds = { [ "+Rhea_Speed" ] = KEY_N, };
RH.Keys	= { [1] = { char = "n", val = KEY_N}, };

/*----------------------------------------------------------
Usefull Functions: Functions that will make the hack run faster
-----------------------------------------------------------*/

function get_group(v)
	return v:GetNetworkedString("UserGroup")
end

function isvip(v)
local g = get_group(v)
	if g != "user" and g != "guest" and g != "" then
		return true
	end
	return false
end

function get_vips()
local r = {}
	for k, v in pairs(player.GetAll()) do
		if isvip(v) then
			table.insert(r, v)
			end
		end
	return
end

function viporwut(v)
	if isvip(v) then
		return Color(255, 170, 170)
	elseif v:GetFriendStatus() == "friend" then
		return Color(174, 232, 0)
	else
		return Color(255, 255, 255)
	end
end


function IsWorking( v )
	if ( v:Alive() && v:Health() ~= 0 && v != LocalPlayer() ) then
		return true
	else
		return false
	end
end;

function RankCol( color )
	local RankCol = Color(255, 255, 255, 255)
	if ( isvip(v) ) then
		RankCol = Color(0, 0, 255, 255)
	else
		RankCol = Color(0, 255, 0, 255)
	end
end

function AddHook( Type, Name, Func )
	table.insert( rheaHooks.Hook, Type )
	table.insert( rheaHooks.Name, Name )
	hook.Add( Type, Name, Func )
end;

/*----------------------------------------------------------
Main Coding: The core of the code
-----------------------------------------------------------*/

function SimpleESP()
	for k, v in pairs( player.GetAll() ) do
		if ( RH.Bools["Rhea_ESP_Active"] ) then
			if ( IsWorking(v) ) then

				local Pos		= v:GetPos():ToScreen()
				local Name 		= v:Name()
				local Health    = v:Health()
				local Dist 		= v:GetPos():Distance( LocalPlayer():GetPos() )
				local Dist2		= math.floor( Dist / 16 )
				local Counter	= 0
				local Text 		= Name
				if ( Dist ) then
					PInfo = Name..' | '..Dist2..'m | '..Health..''
				end

				if ( RH.Bools["Rhea_ESP_Info"] ) then
					draw.SimpleText( PInfo, "DefaultFixed", Pos.x, Pos.y + 20, Color(0, 255, 0, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
				end
				
				if ( RH.Bools["Rhea_ESP_AdminList"] ) then
					for k, v in pairs( player.GetAll() ) do
						if ( isvip(v) ) then
							draw.SimpleText( v:GetName().." [A]", "HudHintTextLarge", 20, ScrH() / 2 - Counter, Color(255, 0, 0, 255) )
							Counter = Counter + 12
						end
					end
				end
				
				if ( RH.Bools["Rhea_ESP_XHair"] ) then
					local g = 5
					local s, x, y, l = 10, ScrW() / 2, ScrH() / 2, g + 15
					local hply = LocalPlayer():Health()
					local nply = LocalPlayer():GetName()
					local xhp, yhp = ScrW()/(2) - 25, ScrH()/(2) - 15
					local xname, yname = ScrW() / (2), ScrH()/(2) + 35
					surface.SetDrawColor( 255, 0, 0, 255 )
					surface.DrawLine( x - l, y, x - g, y )
					surface.DrawLine( x + l, y, x + g, y )
					surface.DrawLine( x, y - l, x, y - g )
					surface.DrawLine( x, y + l, x, y + g )
					surface.DrawCircle( x, y, 20, Color(255,255,255,255) )
					surface.DrawCircle( x, y, 10, Color(255,0,0,255) ) 		
					surface.DrawLine( x - 20, y - 20, x + 20, y + 20 )
					surface.DrawLine( x - 20, y + 20, x + 20, y - 20)
					surface.DrawLine(ScrW() / 2 - 10, ScrH() / 2, ScrW() / 2 + 11 , ScrH() / 2)
					surface.DrawLine(ScrW() / 2 - 0, ScrH() / 2 - 10, ScrW() / 2 - 0 , ScrH() / 2 + 11)
					draw.SimpleTextOutlined( hply, "Default", xhp, yhp, Color(0,0,0,255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, Color(255,255,255,255) )
					draw.SimpleTextOutlined( nply, "Default", xname, yname, Color(255,255,255,255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, Color(0,0,0,255) )
				end
			end;
		end;
	end;
end;

function SimpleMISC()
	if ( RH.Bools["Rhea_ESP_Admin"] ) then
		for k, v in pairs( player.GetAll() ) do
			if ( v:IsAdmin() && not table.HasValue( Admins, v ) ) then
				table.insert(Admins, v);
				chat.AddText(Color(255, 0, 0, 255), "[RheaHack] ", Color(0, 255, 255), "Administrator, "..v:Nick() .. ", has joined!");
				surface.PlaySound("buttons/blip1.wav");
			end
			
			if ( v:IsSuperAdmin() and not v:IsAdmin() && not table.HasValue( SAdmins, v ) ) then
				table.insert(SAdmins, v);
				chat.AddText(Color(255, 0, 0, 255), "[RheaHack] ", Color(0, 255, 255), "SuperAdmin, "..v:Nick() .. ", has joined!");
				surface.PlaySound("buttons/blip1.wav");
			end
		end
			end
			
	if ( RH.Bools["Rhea_MISC_Bhop"] ) then
		if ( input.IsKeyDown( KEY_SPACE ) ) then
			if ( LocalPlayer():OnGround() ) then
				RunConsoleCommand("+jump")
				timer.Create("SandboxThink", 0.00001, 0, function()
					RunConsoleCommand("-jump")
				end )
			end
		end
	end
end

function NoRecoil()
	if ( RH.Bools["Rhea_MISC_NoRecoil"] ) then
		local ply = LocalPlayer()
		local wep = ply:GetActiveWeapon()
		if ( wep.Primary ) then wep.Primary.Recoil = 0 end
		if ( wep.Secondary ) then wep.Secondary.Recoil = 0 end
	end
end



speedon = function()
CH:SetValue(1.0)
TS:SetValue(9.0)
end
 
speedoff = function()
CH:SetValue(1.0)
CH:SetValue(0)
end
concommand.Add("+Rhea_Speedhack", speedon)
concommand.Add("-Rhea_Speedhack", speedoff)



/*----------------------------------------------------------
Detours: We must stay undetected
-----------------------------------------------------------*/

MsgN("Detouring file.Read")
// file.Read
function file.Read( f, base )
	if f != nil and type(f) == "string" then
		if string.match(f, "addons/") or string.match(f, "lua/") or string.match(f, ".lua") or string.match(f, "data/") then
			chat.AddText( Color(255, 100, 100, 255), "[RheaHack]", Color(100, 255, 100, 255), "Blocked attempt to view ".. f)
			surface.PlaySound("buttons/button6.wav")
			return "LOL NOPE"
		else
			return old_fileread(f, false)
		end
	end
end

MsgN("[RheaHack] - Detouring print")
// print
function print( Msg )
	MsgN(string.format("[RheaHack] - ", Msg ))
	return old_print( Msg )
end

function BlockRCC( cmd, ... )
	local old_rcc = RunConsoleCommand
	if ( FH.Bools["Rhea_MISC_BlockRCC"] ) then
		if ( table.HasValue(FH.Log, cmd) ) then
			print("Blocked RCC: "..cmd)
			return old_rcc(cmd, ...)
		end
	end
end

MsgN("[RheaHack] - Base64Encode Bypassed!")
function util.Base64Encode()
	local Picture	= file.Read("error.txt", "DATA" )
	chat.AddText("Someone is taking a screenshot of your screen! Sending a ERROR picture!")
	return( Picture )
end

MsgN("[RheaHack] - DAC Bypassed!")
// Bypass DAC
for i = 100, 10000 do
	hook.Remove( "Think", tostring( i ) );
end

for i = 1, 10 do
	hook.Remove( "Think", tostring( i ) );
end

MsgN("[RheaHack] - Other Timers Bypassed!")
timer.Destroy( "AntiCheatTimer" )
timer.Destroy( "testing123" )

hook.Remove( "Think", "PlayerInfoThing" )

hook.Add( "Think", "sh_menu", function()
	return true
end )
hook.Remove( "Think", "sh_menu" )

AddHook( "HUDPaint", Name1, SimpleESP)
AddHook( "Think",	 Name2, SimpleMISC)
AddHook( "CalcView", Name3, NoRecoil)
