/*                                                                                                                 
	
	snixzz3 - snixzz.net official Garry's Mod cheat
	by 0xymoron

	!!! You do not have permission to redistribute this. !!!
	!!! You do not have permission to modify this, use any of this, or manipulate it in any way. !!!
		
	----------------- 
	
		Credits
		
	-----------------
	
	fr1kin <3 - for teaching me Lua in the first place & tons of help along the way.
	ethos - TONS of help with optimization & finding my mistakes
	some guy - the pure lua nospread

*/

local md5 = {
  _VERSION     = "md5.lua 0.5.0",
  _DESCRIPTION = "MD5 computation in Lua (5.1)",
  _URL         = "https://github.com/kikito/md5.lua",
  _LICENSE     = [[
    MIT LICENSE
 
    Copyright (c) 2013 Enrique Garc’a Cota + Adam Baldwin + hanzao + Equi 4 Software
 
    Permission is hereby granted, free of charge, to any person obtaining a
    copy of this software and associated documentation files (the
    "Software"), to deal in the Software without restriction, including
    without limitation the rights to use, copy, modify, merge, publish,
    distribute, sublicense, and/or sell copies of the Software, and to
    permit persons to whom the Software is furnished to do so, subject to
    the following conditions:
 
    The above copyright notice and this permission notice shall be included
    in all copies or substantial portions of the Software.
 
    THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
    OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
    MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
    IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
    CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
    TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
    SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
  ]]
}
 
md5.const = {
  0xd76aa478, 0xe8c7b756, 0x242070db, 0xc1bdceee,
  0xf57c0faf, 0x4787c62a, 0xa8304613, 0xfd469501,
  0x698098d8, 0x8b44f7af, 0xffff5bb1, 0x895cd7be,
  0x6b901122, 0xfd987193, 0xa679438e, 0x49b40821,
  0xf61e2562, 0xc040b340, 0x265e5a51, 0xe9b6c7aa,
  0xd62f105d, 0x02441453, 0xd8a1e681, 0xe7d3fbc8,
  0x21e1cde6, 0xc33707d6, 0xf4d50d87, 0x455a14ed,
  0xa9e3e905, 0xfcefa3f8, 0x676f02d9, 0x8d2a4c8a,
  0xfffa3942, 0x8771f681, 0x6d9d6122, 0xfde5380c,
  0xa4beea44, 0x4bdecfa9, 0xf6bb4b60, 0xbebfbc70,
  0x289b7ec6, 0xeaa127fa, 0xd4ef3085, 0x04881d05,
  0xd9d4d039, 0xe6db99e5, 0x1fa27cf8, 0xc4ac5665,
  0xf4292244, 0x432aff97, 0xab9423a7, 0xfc93a039,
  0x655b59c3, 0x8f0ccc92, 0xffeff47d, 0x85845dd1,
  0x6fa87e4f, 0xfe2ce6e0, 0xa3014314, 0x4e0811a1,
  0xf7537e82, 0xbd3af235, 0x2ad7d2bb, 0xeb86d391,
  0x67452301, 0xefcdab89, 0x98badcfe, 0x10325476
}
 
local f=function (x,y,z) return bit.bor(bit.band(x,y),bit.band(-x-1,z)) end
local g=function (x,y,z) return bit.bor(bit.band(x,z),bit.band(y,-z-1)) end
local h=function (x,y,z) return bit.bxor(x,bit.bxor(y,z)) end
local i=function (x,y,z) return bit.bxor(y,bit.bor(x,-z-1)) end
local z=function (f,a,b,c,d,x,s,ac)
  a=bit.band(a+f(b,c,d)+x+ac,0xffffffff)
  return bit.bor(bit.lshift(bit.band(a,bit.rshift(0xffffffff,s)),s),bit.rshift(a,32-s))+b
end
local MAX = 2^31
local SUB = 2^32
function md5.fix(a)
  if a > MAX then return a-SUB end
  return a
end
 
function md5.transform(A,B,C,D,X)
  local a,b,c,d=A,B,C,D
  a=z(f,a,b,c,d,X[ 0], 7,md5.const[ 1])
  a=md5.fix(a) b=md5.fix(b) c=md5.fix(c) d=md5.fix(d)
  d=z(f,d,a,b,c,X[ 1],12,md5.const[ 2])
  a=md5.fix(a) b=md5.fix(b) c=md5.fix(c) d=md5.fix(d)
  c=z(f,c,d,a,b,X[ 2],17,md5.const[ 3])
  a=md5.fix(a) b=md5.fix(b) c=md5.fix(c) d=md5.fix(d)
  b=z(f,b,c,d,a,X[ 3],22,md5.const[ 4])
  a=md5.fix(a) b=md5.fix(b) c=md5.fix(c) d=md5.fix(d)
  a=z(f,a,b,c,d,X[ 4], 7,md5.const[ 5])
  a=md5.fix(a) b=md5.fix(b) c=md5.fix(c) d=md5.fix(d)
  d=z(f,d,a,b,c,X[ 5],12,md5.const[ 6])
  a=md5.fix(a) b=md5.fix(b) c=md5.fix(c) d=md5.fix(d)
  c=z(f,c,d,a,b,X[ 6],17,md5.const[ 7])
  a=md5.fix(a) b=md5.fix(b) c=md5.fix(c) d=md5.fix(d)
  b=z(f,b,c,d,a,X[ 7],22,md5.const[ 8])
  a=md5.fix(a) b=md5.fix(b) c=md5.fix(c) d=md5.fix(d)
  a=z(f,a,b,c,d,X[ 8], 7,md5.const[ 9])
  a=md5.fix(a) b=md5.fix(b) c=md5.fix(c) d=md5.fix(d)
  d=z(f,d,a,b,c,X[ 9],12,md5.const[10])
  a=md5.fix(a) b=md5.fix(b) c=md5.fix(c) d=md5.fix(d)
  c=z(f,c,d,a,b,X[10],17,md5.const[11])
  a=md5.fix(a) b=md5.fix(b) c=md5.fix(c) d=md5.fix(d)
  b=z(f,b,c,d,a,X[11],22,md5.const[12])
  a=md5.fix(a) b=md5.fix(b) c=md5.fix(c) d=md5.fix(d)
  a=z(f,a,b,c,d,X[12], 7,md5.const[13])
  a=md5.fix(a) b=md5.fix(b) c=md5.fix(c) d=md5.fix(d)
  d=z(f,d,a,b,c,X[13],12,md5.const[14])
  a=md5.fix(a) b=md5.fix(b) c=md5.fix(c) d=md5.fix(d)
  c=z(f,c,d,a,b,X[14],17,md5.const[15])
  a=md5.fix(a) b=md5.fix(b) c=md5.fix(c) d=md5.fix(d)
  b=z(f,b,c,d,a,X[15],22,md5.const[16])
  a=md5.fix(a) b=md5.fix(b) c=md5.fix(c) d=md5.fix(d)
 
  a=z(g,a,b,c,d,X[ 1], 5,md5.const[17])
  a=md5.fix(a) b=md5.fix(b) c=md5.fix(c) d=md5.fix(d)
  d=z(g,d,a,b,c,X[ 6], 9,md5.const[18])
  a=md5.fix(a) b=md5.fix(b) c=md5.fix(c) d=md5.fix(d)
  c=z(g,c,d,a,b,X[11],14,md5.const[19])
  a=md5.fix(a) b=md5.fix(b) c=md5.fix(c) d=md5.fix(d)
  b=z(g,b,c,d,a,X[ 0],20,md5.const[20])
  a=md5.fix(a) b=md5.fix(b) c=md5.fix(c) d=md5.fix(d)
  a=z(g,a,b,c,d,X[ 5], 5,md5.const[21])
  a=md5.fix(a) b=md5.fix(b) c=md5.fix(c) d=md5.fix(d)
  d=z(g,d,a,b,c,X[10], 9,md5.const[22])
  a=md5.fix(a) b=md5.fix(b) c=md5.fix(c) d=md5.fix(d)
  c=z(g,c,d,a,b,X[15],14,md5.const[23])
  a=md5.fix(a) b=md5.fix(b) c=md5.fix(c) d=md5.fix(d)
  b=z(g,b,c,d,a,X[ 4],20,md5.const[24])
  a=md5.fix(a) b=md5.fix(b) c=md5.fix(c) d=md5.fix(d)
  a=z(g,a,b,c,d,X[ 9], 5,md5.const[25])
  a=md5.fix(a) b=md5.fix(b) c=md5.fix(c) d=md5.fix(d)
  d=z(g,d,a,b,c,X[14], 9,md5.const[26])
  a=md5.fix(a) b=md5.fix(b) c=md5.fix(c) d=md5.fix(d)
  c=z(g,c,d,a,b,X[ 3],14,md5.const[27])
  a=md5.fix(a) b=md5.fix(b) c=md5.fix(c) d=md5.fix(d)
  b=z(g,b,c,d,a,X[ 8],20,md5.const[28])
  a=md5.fix(a) b=md5.fix(b) c=md5.fix(c) d=md5.fix(d)
  a=z(g,a,b,c,d,X[13], 5,md5.const[29])
  a=md5.fix(a) b=md5.fix(b) c=md5.fix(c) d=md5.fix(d)
  d=z(g,d,a,b,c,X[ 2], 9,md5.const[30])
  a=md5.fix(a) b=md5.fix(b) c=md5.fix(c) d=md5.fix(d)
  c=z(g,c,d,a,b,X[ 7],14,md5.const[31])
  a=md5.fix(a) b=md5.fix(b) c=md5.fix(c) d=md5.fix(d)
  b=z(g,b,c,d,a,X[12],20,md5.const[32])
  a=md5.fix(a) b=md5.fix(b) c=md5.fix(c) d=md5.fix(d)
 
  a=z(h,a,b,c,d,X[ 5], 4,md5.const[33])
  a=md5.fix(a) b=md5.fix(b) c=md5.fix(c) d=md5.fix(d)
  d=z(h,d,a,b,c,X[ 8],11,md5.const[34])
  a=md5.fix(a) b=md5.fix(b) c=md5.fix(c) d=md5.fix(d)
  c=z(h,c,d,a,b,X[11],16,md5.const[35])
  a=md5.fix(a) b=md5.fix(b) c=md5.fix(c) d=md5.fix(d)
  b=z(h,b,c,d,a,X[14],23,md5.const[36])
  a=md5.fix(a) b=md5.fix(b) c=md5.fix(c) d=md5.fix(d)
  a=z(h,a,b,c,d,X[ 1], 4,md5.const[37])
  a=md5.fix(a) b=md5.fix(b) c=md5.fix(c) d=md5.fix(d)
  d=z(h,d,a,b,c,X[ 4],11,md5.const[38])
  a=md5.fix(a) b=md5.fix(b) c=md5.fix(c) d=md5.fix(d)
  c=z(h,c,d,a,b,X[ 7],16,md5.const[39])
  a=md5.fix(a) b=md5.fix(b) c=md5.fix(c) d=md5.fix(d)
  b=z(h,b,c,d,a,X[10],23,md5.const[40])
  a=md5.fix(a) b=md5.fix(b) c=md5.fix(c) d=md5.fix(d)
  a=z(h,a,b,c,d,X[13], 4,md5.const[41])
  a=md5.fix(a) b=md5.fix(b) c=md5.fix(c) d=md5.fix(d)
  d=z(h,d,a,b,c,X[ 0],11,md5.const[42])
  a=md5.fix(a) b=md5.fix(b) c=md5.fix(c) d=md5.fix(d)
  c=z(h,c,d,a,b,X[ 3],16,md5.const[43])
  a=md5.fix(a) b=md5.fix(b) c=md5.fix(c) d=md5.fix(d)
  b=z(h,b,c,d,a,X[ 6],23,md5.const[44])
  a=md5.fix(a) b=md5.fix(b) c=md5.fix(c) d=md5.fix(d)
  a=z(h,a,b,c,d,X[ 9], 4,md5.const[45])
  a=md5.fix(a) b=md5.fix(b) c=md5.fix(c) d=md5.fix(d)
  d=z(h,d,a,b,c,X[12],11,md5.const[46])
  a=md5.fix(a) b=md5.fix(b) c=md5.fix(c) d=md5.fix(d)
  c=z(h,c,d,a,b,X[15],16,md5.const[47])
  a=md5.fix(a) b=md5.fix(b) c=md5.fix(c) d=md5.fix(d)
  b=z(h,b,c,d,a,X[ 2],23,md5.const[48])
  a=md5.fix(a) b=md5.fix(b) c=md5.fix(c) d=md5.fix(d)
 
  a=z(i,a,b,c,d,X[ 0], 6,md5.const[49])
  a=md5.fix(a) b=md5.fix(b) c=md5.fix(c) d=md5.fix(d)
  d=z(i,d,a,b,c,X[ 7],10,md5.const[50])
  a=md5.fix(a) b=md5.fix(b) c=md5.fix(c) d=md5.fix(d)
  c=z(i,c,d,a,b,X[14],15,md5.const[51])
  a=md5.fix(a) b=md5.fix(b) c=md5.fix(c) d=md5.fix(d)
  b=z(i,b,c,d,a,X[ 5],21,md5.const[52])
  a=md5.fix(a) b=md5.fix(b) c=md5.fix(c) d=md5.fix(d)
  a=z(i,a,b,c,d,X[12], 6,md5.const[53])
  a=md5.fix(a) b=md5.fix(b) c=md5.fix(c) d=md5.fix(d)
  d=z(i,d,a,b,c,X[ 3],10,md5.const[54])
  a=md5.fix(a) b=md5.fix(b) c=md5.fix(c) d=md5.fix(d)
  c=z(i,c,d,a,b,X[10],15,md5.const[55])
  a=md5.fix(a) b=md5.fix(b) c=md5.fix(c) d=md5.fix(d)
  b=z(i,b,c,d,a,X[ 1],21,md5.const[56])
  a=md5.fix(a) b=md5.fix(b) c=md5.fix(c) d=md5.fix(d)
  a=z(i,a,b,c,d,X[ 8], 6,md5.const[57])
  a=md5.fix(a) b=md5.fix(b) c=md5.fix(c) d=md5.fix(d)
  d=z(i,d,a,b,c,X[15],10,md5.const[58])
  a=md5.fix(a) b=md5.fix(b) c=md5.fix(c) d=md5.fix(d)
  c=z(i,c,d,a,b,X[ 6],15,md5.const[59])
  a=md5.fix(a) b=md5.fix(b) c=md5.fix(c) d=md5.fix(d)
  b=z(i,b,c,d,a,X[13],21,md5.const[60])
  a=md5.fix(a) b=md5.fix(b) c=md5.fix(c) d=md5.fix(d)
  a=z(i,a,b,c,d,X[ 4], 6,md5.const[61])
  a=md5.fix(a) b=md5.fix(b) c=md5.fix(c) d=md5.fix(d)
  d=z(i,d,a,b,c,X[11],10,md5.const[62])
  a=md5.fix(a) b=md5.fix(b) c=md5.fix(c) d=md5.fix(d)
  c=z(i,c,d,a,b,X[ 2],15,md5.const[63])
  a=md5.fix(a) b=md5.fix(b) c=md5.fix(c) d=md5.fix(d)
  b=z(i,b,c,d,a,X[ 9],21,md5.const[64])
  a=md5.fix(a) b=md5.fix(b) c=md5.fix(c) d=md5.fix(d)
  return A+a,B+b,C+c,D+d
end
 
function md5.PseudoRandom(number)
	local a,b,c,d = md5.fix(md5.const[65]),md5.fix(md5.const[66]),md5.fix(md5.const[67]),md5.fix(md5.const[68])
	local m = { }
	for i=0,15 do m[i] = 0 end
	m[0] = number
	m[1] = 128
	m[14] = 32
	local a,b,c,d = md5.transform(a,b,c,d,m)
	return bit.rshift( md5.fix(b) , 16) % 256--& 0xff this is so mutch faster 
end
 
local engineSpread = {
    	[0] = { -0.492036, 0.286111 },
    	[1] = { -0.492036, 0.286111 },
    	[2] = { -0.255320, 0.128480 },
    	[3] = { 0.456165, 0.356030 },
    	[4] = { -0.361731, 0.406344 },
    	[5] = { -0.146730, 0.834589 },
    	[6] = { -0.253288, -0.421936 },
    	[7] = { -0.448694, 0.111650 },
    	[8] = { -0.880700, 0.904610 },
    	[9] = { -0.379932, 0.138833 },
    	[10] = { 0.502579, -0.494285 },
    	[11] = { -0.263847, -0.594805 },
    	[12] = { 0.818612, 0.090368 },
    	[13] = { -0.063552, 0.044356 },
    	[14] = { 0.490455, 0.304820 },
    	[15] = { -0.192024, 0.195162 },
    	[16] = { -0.139421, 0.857106 },
    	[17] = { 0.715745, 0.336956 },
    	[18] = { -0.150103, -0.044842 },
    	[19] = { -0.176531, 0.275787 },
    	[20] = { 0.155707, -0.152178 },
    	[21] = { -0.136486, -0.591896 },
    	[22] = { -0.021022, -0.761979 },
    	[23] = { -0.166004, -0.733964 },
    	[24] = { -0.102439, -0.132059 },
    	[25] = { -0.607531, -0.249979 },
    	[26] = { -0.500855, -0.185902 },
    	[27] = { -0.080884, 0.516556 },
    	[28] = { -0.003334, 0.138612 },
    	[29] = { -0.546388, -0.000115 },
    	[30] = { -0.228092, -0.018492 },
    	[31] = { 0.542539, 0.543196 },
    	[32] = { -0.355162, 0.197473 },
    	[33] = { -0.041726, -0.015735 },
    	[34] = { -0.713230, -0.551701 },
    	[35] = { -0.045056, 0.090208 },
    	[36] = { 0.061028, 0.417744 },
    	[37] = { -0.171149, -0.048811 },
    	[38] = { 0.241499, 0.164562 },
    	[39] = { -0.129817, -0.111200 },
    	[40] = { 0.007366, 0.091429 },
    	[41] = { -0.079268, -0.008285 },
    	[42] = { 0.010982, -0.074707 },
    	[43] = { -0.517782, -0.682470 },
    	[44] = { -0.663822, -0.024972 },
    	[45] = { 0.058213, -0.078307 },
    	[46] = { -0.302041, -0.132280 },
    	[47] = { 0.217689, -0.209309 },
    	[48] = { -0.143615, 0.830349 },
    	[49] = { 0.270912, 0.071245 },
    	[50] = { -0.258170, -0.598358 },
    	[51] = { 0.099164, -0.257525 },
    	[52] = { -0.214676, -0.595918 },
    	[53] = { -0.427053, -0.523764 },
    	[54] = { -0.585472, 0.088522 },
    	[55] = { 0.564305, -0.533822 },
    	[56] = { -0.387545, -0.422206 },
    	[57] = { 0.690505, -0.299197 },
    	[58] = { 0.475553, 0.169785 },
    	[59] = { 0.347436, 0.575364 },
    	[60] = { -0.069555, -0.103340 },
    	[61] = { 0.286197, -0.618916 },
    	[62] = { -0.505259, 0.106581 },
    	[63] = { -0.420214, -0.714843 },
    	[64] = { 0.032596, -0.401891 },
    	[65] = { -0.238702, -0.087387 },
    	[66] = { 0.714358, 0.197811 },
    	[67] = { 0.208960, 0.319015 },
    	[68] = { -0.361140, 0.222130 },
    	[69] = { -0.133284, -0.492274 },
    	[70] = { 0.022824, -0.133955 },
    	[71] = { -0.100850, 0.271962 },
    	[72] = { -0.050582, -0.319538 },
    	[73] = { 0.577980, 0.095507 },
    	[74] = { 0.224871, 0.242213 },
    	[75] = { -0.628274, 0.097248 },
    	[76] = { 0.184266, 0.091959 },
    	[77] = { -0.036716, 0.474259 },
    	[78] = { -0.502566, -0.279520 },
    	[79] = { -0.073201, -0.036658 },
    	[80] = { 0.339952, -0.293667 },
    	[81] = { 0.042811, 0.130387 },
    	[82] = { 0.125881, 0.007040 },
    	[83] = { 0.138374, -0.418355 },
    	[84] = { 0.261396, -0.392697 },
    	[85] = { -0.453318, -0.039618 },
    	[86] = { 0.890159, -0.335165 },
    	[87] = { 0.466437, -0.207762 },
    	[88] = { 0.593253, 0.418018 },
    	[89] = { 0.566934, -0.643837 },
    	[90] = { 0.150918, 0.639588 },
    	[91] = { 0.150112, 0.215963 },
    	[92] = { -0.130520, 0.324801 },
    	[93] = { -0.369819, -0.019127 },
    	[94] = { -0.038889, -0.650789 },
    	[95] = { 0.490519, -0.065375 },
    	[96] = { -0.305940, 0.454759 },
    	[97] = { -0.521967, -0.550004 },
    	[98] = { -0.040366, 0.683259 },
    	[99] = { 0.137676, -0.376445 },
    	[100] = { 0.839301, 0.085979 },
    	[101] = { -0.319140, 0.481838 },
    	[102] = { 0.201437, -0.033135 },
    	[103] = { 0.384637, -0.036685 },
    	[104] = { 0.598419, 0.144371 },
    	[105] = { -0.061424, -0.608645 },
    	[106] = { -0.065337, 0.308992 },
    	[107] = { -0.029356, -0.634337 },
    	[108] = { 0.326532, 0.047639 },
    	[109] = { 0.505681, -0.067187 },
    	[110] = { 0.691612, 0.629364 },
    	[111] = { -0.038588, -0.635947 },
    	[112] = { 0.637837, -0.011815 },
    	[113] = { 0.765338, 0.563945 },
    	[114] = { 0.213416, 0.068664 },
    	[115] = { -0.576581, 0.554824 },
    	[116] = { 0.246580, 0.132726 },
    	[117] = { 0.385548, -0.070054 },
    	[118] = { 0.538735, -0.291010 },
    	[119] = { 0.609944, 0.590973 },
    	[120] = { -0.463240, 0.010302 },
    	[121] = { -0.047718, 0.741086 },
    	[122] = { 0.308590, -0.322179 },
    	[123] = { -0.291173, 0.256367 },
    	[124] = { 0.287413, -0.510402 },
    	[125] = { 0.864716, 0.158126 },
    	[126] = { 0.572344, 0.561319 },
    	[127] = { -0.090544, 0.332633 },
    	[128] = { 0.644714, 0.196736 },
    	[129] = { -0.204198, 0.603049 },
    	[130] = { -0.504277, -0.641931 },
    	[131] = { 0.218554, 0.343778 },
    	[132] = { 0.466971, 0.217517 },
    	[133] = { -0.400880, -0.299746 },
    	[134] = { -0.582451, 0.591832 },
    	[135] = { 0.421843, 0.118453 },
    	[136] = { -0.215617, -0.037630 },
    	[137] = { 0.341048, -0.283902 },
    	[138] = { -0.246495, -0.138214 },
    	[139] = { 0.214287, -0.196102 },
    	[140] = { 0.809797, -0.498168 },
    	[141] = { -0.115958, -0.260677 },
    	[142] = { -0.025448, 0.043173 },
    	[143] = { -0.416803, -0.180813 },
    	[144] = { -0.782066, 0.335273 },
    	[145] = { 0.192178, -0.151171 },
    	[146] = { 0.109733, 0.165085 },
    	[147] = { -0.617935, -0.274392 },
    	[148] = { 0.283301, 0.171837 },
    	[149] = { -0.150202, 0.048709 },
    	[150] = { -0.179954, -0.288559 },
    	[151] = { -0.288267, -0.134894 },
    	[152] = { -0.049203, 0.231717 },
    	[153] = { -0.065761, 0.495457 },
    	[154] = { 0.082018, -0.457869 },
    	[155] = { -0.159553, 0.032173 },
    	[156] = { 0.508305, -0.090690 },
    	[157] = { 0.232269, -0.338245 },
    	[158] = { -0.374490, -0.480945 },
    	[159] = { -0.541244, 0.194144 },
    	[160] = { -0.040063, -0.073532 },
    	[161] = { 0.136516, -0.167617 },
    	[162] = { -0.237350, 0.456912 },
    	[163] = { -0.446604, -0.494381 },
    	[164] = { 0.078626, -0.020068 },
    	[165] = { 0.163208, 0.600330 },
    	[166] = { -0.886186, -0.345326 },
    	[167] = { -0.732948, -0.689349 },
    	[168] = { 0.460564, -0.719006 },
    	[169] = { -0.033688, -0.333340 },
    	[170] = { -0.325414, -0.111704 },
    	[171] = { 0.010928, 0.723791 },
    	[172] = { 0.713581, -0.077733 },
    	[173] = { -0.050912, -0.444684 },
    	[174] = { -0.268509, 0.381144 },
    	[175] = { -0.175387, 0.147070 },
    	[176] = { -0.429779, 0.144737 },
    	[177] = { -0.054564, 0.821354 },
    	[178] = { 0.003205, 0.178130 },
    	[179] = { -0.552814, 0.199046 },
    	[180] = { 0.225919, -0.195013 },
    	[181] = { 0.056040, -0.393974 },
    	[182] = { -0.505988, 0.075184 },
    	[183] = { -0.510223, 0.156271 },
    	[184] = { -0.209616, 0.111174 },
    	[185] = { -0.605132, -0.117104 },
    	[186] = { 0.412433, -0.035510 },
    	[187] = { -0.573947, -0.691295 },
    	[188] = { -0.712686, 0.021719 },
    	[189] = { -0.643297, 0.145307 },
    	[190] = { 0.245038, 0.343062 },
    	[191] = { -0.235623, -0.159307 },
    	[192] = { -0.834004, 0.088725 },
    	[193] = { 0.121377, 0.671713 },
    	[194] = { 0.528614, 0.607035 },
    	[195] = { -0.285699, -0.111312 },
    	[196] = { 0.603385, 0.401094 },
    	[197] = { 0.632098, -0.439659 },
    	[198] = { 0.681016, -0.242436 },
    	[199] = { -0.261709, 0.304265 },
    	[200] = { -0.653737, -0.199245 },
    	[201] = { -0.435512, -0.762978 },
    	[202] = { 0.701105, 0.389527 },
    	[203] = { 0.093495, -0.148484 },
    	[204] = { 0.715218, 0.638291 },
    	[205] = { -0.055431, -0.085173 },
    	[206] = { -0.727438, 0.889783 },
    	[207] = { -0.007230, -0.519183 },
    	[208] = { -0.359615, 0.058657 },
    	[209] = { 0.294681, 0.601155 },
    	[210] = { 0.226879, -0.255430 },
    	[211] = { -0.307847, -0.617373 },
    	[212] = { 0.340916, -0.780086 },
    	[213] = { -0.028277, 0.610455 },
    	[214] = { -0.365067, 0.323311 },
    	[215] = { 0.001059, -0.270451 },
    	[216] = { 0.304025, 0.047478 },
    	[217] = { 0.297389, 0.383859 },
    	[218] = { 0.288059, 0.262816 },
    	[219] = { -0.889315, 0.533731 },
    	[220] = { 0.215887, 0.678889 },
    	[221] = { 0.287135, 0.343899 },
    	[222] = { 0.423951, 0.672285 },
    	[223] = { 0.411912, -0.812886 },
    	[224] = { 0.081615, -0.497358 },
    	[225] = { -0.051963, -0.117891 },
    	[226] = { -0.062387, 0.331698 },
    	[227] = { 0.020458, -0.734125 },
    	[228] = { -0.160176, 0.196321 },
    	[229] = { 0.044898, -0.024032 },
    	[230] = { -0.153162, 0.930951 },
    	[231] = { -0.015084, 0.233476 },
    	[232] = { 0.395043, 0.645227 },
    	[233] = { -0.232095, 0.283834 },
    	[234] = { -0.507699, 0.317122 },
    	[235] = { -0.606604, -0.227259 },
    	[236] = { 0.526430, -0.408765 },
    	[237] = { 0.304079, 0.135680 },
    	[238] = { -0.134042, 0.508741 },
    	[239] = { -0.276770, 0.383958 },
    	[240] = { -0.298963, -0.233668 },
    	[241] = { 0.171889, 0.697367 },
    	[242] = { -0.292571, -0.317604 },
    	[243] = { 0.587806, 0.115584 },
    	[244] = { -0.346690, -0.098320 },
    	[245] = { 0.956701, -0.040982 },
    	[246] = { 0.040838, 0.595304 },
    	[247] = { 0.365201, -0.519547 },
    	[248] = { -0.397271, -0.090567 },
    	[249] = { -0.124873, -0.356800 },
    	[250] = { -0.122144, 0.617725 },
    	[251] = { 0.191266, -0.197764 },
    	[252] = { -0.178092, 0.503667 },
    	[253] = { 0.103221, 0.547538 },
    	[254] = { 0.019524, 0.621226 },
    	[255] = { 0.663918, -0.573476 },
}

if _G.snixzz then chat.AddText( Color( 255, 0, 0 ), "\n\n\n\n\nsnixzz3 cannot be reloaded! Reconnect then re-load it." ) return end
if game.SinglePlayer() then chat.AddText( Color( 255, 0, 0 ), "\n\n\n\n\nsnixzz3 will not load in singleplayer!" ) return end

local snixzz = {}

snixzz.IsDev = function( ply ) return ply:SteamID64() == "76561198040553376" end -- I am not proud of myself.

snixzz.Panic = false

snixzz.DataFolder = "snixzz3_beta"

snixzz.Info = {
	["Version"] = "build 1.4.0b",
	["Updated"] = "8/23/18",
	["Size"] = "163kb",
	["Lines"] = "6,737",
}

// Data cache
snixzz.Cache = {}
snixzz.ConsoleHistory = {}
snixzz.ChatCache = {}
snixzz.ChatHistory = {}
snixzz.DisableDetours = false

local G
if _G.easylua then // for why
	G = _G // please no
	snixzz.DisableDetours = true // help me
else
	G = table.Copy( _G )
end
local _R = G.debug.getregistry()
local hookGetTableCopy = G.table.Copy( hook.GetTable() )

local EntM = G.FindMetaTable( "Entity" )
local PlyM = G.FindMetaTable( "Player" )
local WepM = G.FindMetaTable( "Weapon" )
local MatM = G.FindMetaTable( "IMaterial" )

-- Gamemode checks
snixzz.IsTTT = G.GAMEMODE.Name == "Trouble in Terrorist Town"
snixzz.IsDarkRP = ( -- Wow look at all these garbage DarkRP renames.
G.GAMEMODE.Name == "DarkRP" or G.GAMEMODE.Name == "MethRP" or 
G.GAMEMODE.Name == "The Purge" or G.GAMEMODE.Name == "starwarsrp" or 
G.GAMEMODE.Name == "KingdomRP" or G.GAMEMODE.Name == "MilitaryRP" or
G.GAMEMODE.Name == "SlaveRP" or G.GAMEMODE.Name == "1942RP" or
G.GAMEMODE.Name == "ZombieRP" or G.GAMEMODE.Name == "SchoolRP" or
G.GAMEMODE.Name == "PrisonRP" or G.GAMEMODE.Name == "HaloRP" or
G.GAMEMODE.Name == "PonyRP" or G.GAMEMODE.Name == "MexicanBorderRPP" or G.GAMEMODE.Name == "HogwartsRP" -- end my suffering. what the fuck is this shit.
)
snixzz.IsSandbox = G.GAMEMODE.Name == "Sandbox"
snixzz.IsMurder = G.GAMEMODE.Name == "Murder"
snixzz.IsProphunt = G.GAMEMODE.Name == "Prop Hunt" or G.GAMEMODE.Name == "Prophunt" or G.GAMEMODE.Name == "Enhanced Prop Hunt"
snixzz.IsBasewars = G.GAMEMODE.Name == "BaseWars"

snixzz.Detours = {
	["net.Start"] = {
		["checksaum"] = true,
		["checksum"] = true,
		["gcontrolled_vars"] = true,
		["controlled_vars"] = true,
		["quack"] = true,
		["leyac_cmd"] = true, -- old but blocks old versions
	},
	["Commands"] = {
		"GetTheTime",
	},
}

snixzz["Spoof"] = {
	["sv_allowcslua"] = 0,
	["sv_cheats"] = 0,
	["host_timescale"] = 1,
	["host_framerate"] = 0,
}	

// Aimbot vars nd shit
snixzz.Target = nil
snixzz.Typing = false
snixzz.Locked = false

snixzz.Bools = {
	
	-- Load settings
	["load_unhooked"] = false,
	
	-- Aimbot & view settings
	["aim_toggle"] = false,
	["aim_autoshoot"] = true,
	["aim_silent"] = true,
	["aim_psilent"] = false,
	["aim_anti"] = false,
	["aim_badshots"] = false,
	["aim_nospread"] = true,
	["aim_norecoil"] = true,
	["aim_prediction"] = true,	
	["aim_antiantiaim"] = false,
	["aim_checkfov"] = false,
	["aim_ignorelos"] = false,
	["aim_ignoresteam"] = true,
	["aim_ignoreadmins"] = false,
	["aim_ignorebots"] = false,
	["aim_ignoreteam"] = false,
	["aim_ignorefriends"] = true,
	["aim_ignoretraitors"] = false,
	["aim_onlytraitors"] = false,
	["aim_holdtarget"] = false,
	["aim_constant_nospread"] = false,
	["aim_smooth"] = false,
	["aim_canfire"] = false,
	["aim_targetonlyfriends"] = false,
	
	-- ESP settings
	["esp_enabled"] = true,
	["esp_name"] = true,
	["esp_health_text"] = true,
	["esp_health_bar"] = true,
	["esp_chams"] = true,
	["esp_chams_weapon"] = true,
	["esp_weapon"] = true,
	["esp_box"] = true,
	["esp_crosshair"] = false,
	["esp_crosshair_box"] = false,
	["esp_laser"] = true,
	["esp_nohands"] = true,
	["esp_status"] = true,
	["esp_list"] = true,
	["esp_snaplines"] = false,
	["esp_distance"] = false,
	["esp_dynamiclight"] = false,
	["esp_wireweapon"] = false,
	["esp_aimpos"] = false,
	["esp_bullet_trace"] = false,
	["esp_hitbox"] = false,
	["esp_rainbow"] = false,
	["esp_radar"] = false,

	["misc_bhop"] = true,
	["misc_triggerbot"] = false,
	["misc_thirdperson"] = false,
	["misc_traitor_finder"] = false,
	["misc_murder_finder"] = false,
	["misc_prophunt_finder"] = false,
	["misc_chat_spam"] = false,
	["misc_autostrafe"] = false,
	["misc_rapidfire"] = false,
	["misc_autoreload"] = false, -- todo
	["misc_csnoclip"] = false,
	["misc_exploits_prophunt"] = true,
	["misc_doorspam"] = false,
	["misc_votekickspam"] = false,
	["misc_namechanger"] = false,

}

snixzz.Vars = {
	
	-- Aimbot Vars
	["aim_distance"] = 2147483647,
	["aim_fov"] = 180,
	["aim_offset"] = 0,
	["aim_method"] = "Hitbox",
	["aim_anti_method"] = "Classic",
	["aim_hitbox"] = "Head",
	["aim_bone"] = "Head",
	["aim_target_method"] = "Distance",
	["aim_prediction_method"] = "Engine Velocity",
	["aim_anti_spin_speed"] = 10,
	["aim_target_type"] = "Players",
	["aim_smooth_speed"] = 8,
	
	-- ESP Vars
	["esp_render_distance"] = 3000,
	["esp_chams_material"] = "Solid",
	["esp_box_width"] = 1.5,
	["esp_fov"] = 90,
	["esp_laser_attachment"] = "Iron Sights",
	["esp_type"] = "Players",
	
	-- Misc Vars
	["speedhack_speed"] = 3.5,
	["speedhack_type"] = "pSpeed",
	
	["misc_triggerbot_method"] = "Hitbox",
	["misc_triggerbot_type"] = "Players",
	["misc_menucolor"] = Color( 99, 99, 99, 163 ),
	["misc_menucolor2"] = Color( 0, 221, 225, 145 ),
	["misc_lasercolor"] = Color( 255, 0, 0, 255 ),
	["misc_thirdperson_distance"] = 90,
	["misc_csnoclip_speed"] = 10,

	["misc_chat_spam_method"] = "Random Jokes",
	["misc_chat_spam_message"] = "0xymoron is the king of gmod", -- TODO: add menu for dis

}

snixzz.Binds = {
	["+aimbot"] = KEY_F,
	["+menu"] = KEY_INSERT,
	["+speedhack"] = KEY_B,
	["+triggerbot"] = KEY_G,
	["chat"] = KEY_T,
}

snixzz.Entities = {}
snixzz.Friends = {}

snixzz.BadEntities = {

	["env_sprite"] = true,
	["player"] = true,
	["prop_physics"] = true,
	["prop_door_rotating"] = true,
	["prop_dynamic"] = true,
	["viewmodel"] = true,
	["weapon_physgun"] = true,
	["weapon_physcannon"] = true,
	["keys"] = true,
	["pocket"] = true,
	["gmod_tool"] = true,
	["physgun_beam"] = true,
	["func_door_rotating"] = true,
	["func_breakable_surf"] = true,
	["worldspawn"] = true,
	["func_door"] = true,
	["class C_Sun"] = true,
	["func_useableladder"] = true,
	["class C_BaseEntity"] = true,
	["class C_PlayerResource"] = true,
	["class C_GMODGameRulesProxy"] = true,
	["class C_WaterLODControl"] = true,
	["class C_ShadowControl"] = true,
	["class C_EnvTonemapController"] = true,
	["class C_PhysPropClientside"] = true,
	["class C_HL2MPRagdoll"] = true,
	["class C_BaseFlex"] = true,
	["class C_ParticleSystem"] = true,
	["class C_RopeKeyframe"] = true,
	["env_skypaint"] = true,
	["manipulate_bone"] = true,
	
}

snixzz.Keys = {
	[1] = { Name = "A", Key = KEY_A },
	[2] = { Name = "B", Key = KEY_B },
	[3] = { Name = "C", Key = KEY_C },
	[4] = { Name = "D", Key = KEY_D },
	[5] = { Name = "E", Key = KEY_E },
	[6] = { Name = "F", Key = KEY_F },
	[7] = { Name = "G", Key = KEY_G },		
	[8] = { Name = "H", Key = KEY_H },
	[9] = { Name = "I", Key = KEY_I },
	[10] = { Name = "J", Key = KEY_J },
	[11] = { Name = "K", Key = KEY_K },
	[12] = { Name = "L", Key = KEY_L },
	[13] = { Name = "M", Key = KEY_M },
	[14] = { Name = "N", Key = KEY_N },
	[15] = { Name = "O", Key = KEY_O },
	[16] = { Name = "P", Key = KEY_P },
	[17] = { Name = "Q", Key = KEY_Q },
	[18] = { Name = "R", Key = KEY_R },
	[19] = { Name = "S", Key = KEY_S },
	[20] = { Name = "T", Key = KEY_T },
	[21] = { Name = "U", Key = KEY_U },
	[22] = { Name = "V", Key = KEY_V },
	[23] = { Name = "W", Key = KEY_W },
	[24] = { Name = "X", Key = KEY_X },
	[25] = { Name = "Y", Key = KEY_Y },
	[26] = { Name = "Z", Key = KEY_Z },
	[27] = { Name = "SPACE", Key = KEY_SPACE },
	[28] = { Name = "TAB", Key = KEY_TAB },
	[29] = { Name = "Left Shift", Key = KEY_LSHIFT },
	[30] = { Name = "Right Shift", Key = KEY_RSHIFT },
	[31] = { Name = "Left Alt", Key = KEY_LALT },
	[32] = { Name = "Right Alt", Key = KEY_RALT },
	[33] = { Name = "Delete", Key = KEY_DELETE },
	[34] = { Name = ".", Key = KEY_PERIOD },
	[35] = { Name = "/", Key = KEY_SLASH },
	[36] = { Name = "[", Key = KEY_LBRACKET },
	[37] = { Name = ";", Key = KEY_SEMICOLON },
	[38] = { Name = "'", Key = KEY_APOSTROPHE },
	[39] = { Name = ",", Key = KEY_COMMA },	
	[40] = { Name = "Insert", Key = KEY_INSERT },
	[41] = { Name = "Middle Mouse", Key = MOUSE_MIDDLE },
	[42] = { Name = "Left Mouse", Key = MOUSE_LEFT },
	[43] = { Name = "Right Mouse", Key = MOUSE_RIGHT },
	[44] = { Name = "Mouse 4", Key = MOUSE_4 },
	[45] = { Name = "Mouse 5", Key = MOUSE_5 },
	[46] = { Name = "Mouse First", Key = MOUSE_FIRST },
	[46] = { Name = "Mouse Last", Key = MOUSE_LAST },
	[46] = { Name = "Mouse Wheel Up", Key = MOUSE_WHEEL_UP },
	[46] = { Name = "Mouse Wheel Down", Key = MOUSE_WHEEL_DOWN },
}

snixzz.DefaultConfig = G.file.Read( snixzz.DataFolder .. "/defaultconfig.txt", "DATA" ) or "default"

// nospread shit
snixzz.RecoilBackup = {}
snixzz.Bullets = {}

snixzz.BadWeapons = {
	["gmod_tool"] = true,
	["gmod_camera"] = true,
	["weapon_physgun"] = true,
	["weapon_crowbar"] = true,
	["keys"] = true,
	["pocket"] = true,
}

snixzz["Colors"] = {
	["White"] = Color( 255, 255, 255, 255 ),
	["Black"] = Color( 0, 0, 0, 255 ),
	["Green"] = Color( 0, 255, 0, 255 ),
	["Red"] = Color( 255, 0, 0, 255 ),
	["DarkRed"] = Color( 200, 50, 50, 255 ),
	["Cyan"] = Color( 0, 255, 255, 255 ),
	["Purple"] = Color( 255, 0, 255 ),
}

snixzz.AdminGroups = {
	["trialmod"] = true,
	["tmod"] = true,
	["trial-mod"] = true,
	["trialmoderator"] = true,
	["t-mod"] = true,
	["mod"] = true,
	["moderator"] = true,
	["operator"] = true,
	["vipmod"] = true,
	["vipmoderator"] = true,
	["admin"] = true,
	["vipadmin"] = true,
	["head-admin"] = true,
	["headadmin"] = true,
	["manager"] = true,
	["developer"] = true,
	["dev"] = true,
	["superadmin"] = true,
	["sadmin"] = true,
	["super"] = true,
	["vipsuperadmin"] = true, -- i cry
	["owner"] = true,
	["root_user"] = true,
	["vipowner"] = true, -- wouldn't be surprised it
	["doubleadmin"] = true, -- what the fuck is this
}

G.surface.CreateFont( "snixzz_status", { font = "coolvetica", size = 20, antialias = true } ) -- HudHintTextLarge
G.surface.CreateFont( "snixzz_logo", { size = 25, weight = 0, antialias = true, shadow = false, font = "Tahoma" } )
G.surface.CreateFont( "snixzz_logo_small", { size = 13, weight = 0, antialias = true, shadow = false, font = "Tahoma" } )
G.surface.CreateFont( "ESPFont", { size = 14, weight = 200, antialias = false, shadow = true, font = "Arial" } )

/* General notification/display functions */

local sound
function snixzz.Sound( Error )

	if Error then
	
		sound = G.Sound( "/HL1/fvox/buzz.wav" )
		
	else
	
		sound = G.Sound( "/buttons/button17.wav" )
		
	end
	
	local createSound = G.CreateSound( G.LocalPlayer(), sound )
	createSound:Play()
	
end

function snixzz.AddToConsole( str )

	if snixzz.ConsoleOpen && snixzz.cHistory && str != nil then
		
		snixzz.cHistory:AddLine( str )
		
		snixzz.cHistory:PerformLayout()
		snixzz.cHistory.VBar:SetScroll( snixzz.cHistory.VBar.CanvasSize )
		
	end
	
	G.table.insert( snixzz.ConsoleHistory, str )
	
end

function snixzz.Message( col, text )

	G.MsgC( snixzz.Colors.Cyan, "[snixzz3]: " )
	G.MsgC( col, text .. "\n" )
	
	snixzz.AddToConsole( text )
	
end

function snixzz.Chat( col, text, bool )
	
	G.chat.AddText(
		
		col, "[snixzz3]: ",
		color_white, text
		
	)
	
	if !bool then
	
		snixzz.AddToConsole( text )
		
	end
	
end

function snixzz.ACNotify( text )

	snixzz.Chat( snixzz.Colors.Red, text )
	
	snixzz.logEvent( "anticheat", text )
	snixzz.Sound( Error )
	
end

function snixzz.Debug( text )

	snixzz.AddToConsole( text )
	
	snixzz.logEvent( "Debug", text )
	
end

function snixzz.LogDetour( text )
	
	snixzz.AddToConsole( text )
	
	snixzz.logEvent( "Detour", text )

end

/* Detour function */
function snixzz.Detour( Old, New )

	if snixzz.DisableDetours then
		
		snixzz.AddToConsole( "Easylua detected, ignoring detour '" .. G.tostring( Old ) .. "'" )
		
		return Old
		
	end

	snixzz.Detours[New] = Old
	snixzz.AddToConsole( "Detouring function " .. G.tostring( Old ) .. "." )

	return New
end

/* Module Loading */
snixzz.Functions = {}
snixzz.LoadedModules = {}

function snixzz.IsInstalled( mod )
	
	return G.file.Exists( "lua/bin/gmcl_" .. mod .. "_win32.dll", "GAME" )
	
end

-- ghetto module-less loading
function snixzz.LoadModules()

	-- Attempt to load modules
	if G.system.IsWindows() then
	
		--if snixzz.IsInstalled( "bsendpacket" ) then G.require( "bSendPacket" ) snixzz.LoadedModules["bSendPacket"] = true end
		//if snixzz.IsInstalled( "snixzz2" ) then G.require( "snixzz2" ) snixzz.LoadedModules["snixzz2"] = true end
		
		//if snixzz.IsInstalled( "dickwrap" ) then G.require( "dickwrap" ) snixzz.LoadedModules["dickwrap"] = true end
		
	end

	-- Check & notify if the module successfully loaded
	/*if bSendPacket != nil or !G.system.IsWindows() then

		bSendPacket = true
		
		snixzz.AddToConsole( "Successfully loaded module 'gmcl_bSendPacket_win32.dll'" )

	else
		
		bSendPacket = nil
		
		snixzz.Chat( snixzz.Colors.Red, "Unable to load module 'gmcl_bSendPacket_win32.dll', disabling module features." )
		
	end*/

	if _G.NHTable != nil or !G.system.IsWindows() then
		
		//snixzz.Functions.PredictSpread = _G.NHTable.ZeroSpread
		snixzz.Functions.PredictSpread = function( cmd, ang, vec ) return ang end
		snixzz.Functions.LocalPlayer = _G.NHTable.SetLPIndex
		snixzz.Functions.ConCommand = _G.NHTable.ClientCMD
		//snixzz.Functions.SetViewAngles = _G.NHTable.SetViewAngles
		snixzz.Functions.SetViewAngles = function( cmd, ang ) cmd:SetViewAngles( ang ) end
		snixzz.Functions.NoDraw = _G.NHTable.NoDraw
		snixzz.Functions.IsDormant = _G.NHTable.IsDormant
		snixzz.Functions.IsVisible = _G.NHTable.IsVisible
		snixzz.Functions.SetName = _G.NHTable.Changename
		
		-- C++ IsVisible func
		snixzz.IsVisible = function( v, pos )
	
			if snixzz.Bools["aim_antiantiaim"] then
		
				snixzz.FixAngle( v )
	
			end
	
			return snixzz.Functions.IsVisible( G.LocalPlayer():GetShootPos(), pos, v:EntIndex() )
		end
		
		snixzz.AddToConsole( "Successfully loaded module 'gmcl_snixzz2_win32.dll'" )
				
		_G.NHTable = nil		
				
	else

		snixzz.Functions.PredictSpread = function( cmd, ang, vec ) return ang end
		snixzz.Functions.LocalPlayer = G.LocalPlayer()
		snixzz.Functions.ConCommand = function( cmd ) G.LocalPlayer():ConCommand( cmd ) end
		snixzz.Functions.NoDraw = function( mat, bool ) end
		snixzz.Functions.SetViewAngles = function( cmd, ang ) cmd:SetViewAngles( ang ) end
		snixzz.Functions.IsDormant = function( index ) return false end
		
		-- Lua IsVisible func
		snixzz.Functions.IsVisible = function( shootpos, pos, v ) return false end
		
		snixzz.IsVisible = function( v, pos )
		
			if snixzz.Bools["aim_antiantiaim"] then
		
				snixzz.FixAngle( v )
	
			end
			
			local traceTab = { start = G.LocalPlayer():GetShootPos(), endpos = pos, mask = MASK_SHOT, filter = function( entity ) return !entity:IsPlayer() end }
			local trace = G.util.TraceLine( traceTab )
			return !trace.Hit
			
		end
		
		snixzz.Chat( snixzz.Colors.Red, "Unable to load module 'gmcl_snixzz2_win32.dll', disabling module features." )
		
	end

end

/*
	
	VIP/Advertisement System/Stats

	This system is constantly being worked on.
	I like tracking stats, there's really no reason for it I just enjoy seeing who's actually using my work.
	
*/

snixzz.Membership = "nil"
snixzz.Membership = "vip"

function snixzz.Login( ply )

	snixzz.LoadTime = CurTime()

	gui.EnableScreenClicker( true )
	
	snixzz.loadFrame = G.vgui.Create( "DFrame" )
	snixzz.loadFrame:SetTitle( "Logging in as '" .. ply:SteamID64() .. "'" )
	snixzz.loadFrame:SetSize( 250, 50 )
	snixzz.loadFrame:Center()
	snixzz.loadFrame:ShowCloseButton( false )
	snixzz.loadFrame:SetBackgroundBlur( true )
	snixzz.loadFrame:SetDraggable( false )
	
	snixzz.loadFrame.Paint = function( self )
		
		G.draw.RoundedBox( 0, 0, 0, self:GetWide(), self:GetTall(), Color( 0, 0, 0, 100 ) )
		G.surface.SetDrawColor( Color( 0, 0, 0 ) )
		G.surface.DrawOutlinedRect( 0, 0, self:GetWide(), self:GetTall() )
	end
	
	snixzz.loadProgress = G.vgui.Create( "DProgress", snixzz.loadFrame )
	snixzz.loadProgress:SetPos( 5, 22.5 )
	snixzz.loadProgress:SetSize( snixzz.loadFrame:GetWide() - 10, snixzz.loadFrame:GetTall() - 27.5 )
	snixzz.loadProgress:SetFraction( 0.1 )

	local oSystem = "Unknown"
	local oIP = "Unknown"
	
	if system.IsWindows() then oSystem = "Windows" elseif system.IsLinux() then oSystem = "Linux" elseif system.IsOSX() then oSystem = "OSX" else oSystem = "Unknon" end
	
	snixzz.loadProgress:SetFraction( 0.2 )
	
	snixzz.loadFrame:SetTitle( "Connecting to login server" )
	
	G.http.Fetch( "http://snixzz.net/cheats/snixzz3/register.php?steamid=" .. ply:SteamID64() .. "&os=" .. oSystem, -- stop spamming this faggots
		
		function( body )
				
			snixzz.loadFrame:SetTitle( "Connected, getting user info." )

			if body == "Error: Banned" then
				
				snixzz.Ban( ply, "ip" )
				
				return
				
			end
				
			local tab = util.JSONToTable( body )

			if istable( tab ) then
			
				if tab.group == "dev" then 
						
					snixzz.Membership = "dev"
					
				elseif tab.group == "vip" then
					
					snixzz.Membership = "vip"

				elseif tab.group == "user" then	
					
					snixzz.Membership = "user"
					
				elseif tab.group == "banned" then
						
					snixzz.Membership = "banned"
					snixzz.Banned = true
					
				elseif body == "Error: Invalid SteamID64" then
						
					snixzz.Chat( Color( 255, 0, 0 ), "There was a problem with your login ID, if you believe this is an error please join our Discord @ https://discord.gg/H25nZGU" )
						
					snixzz.Membership = "user" 
					
				else
						
					snixzz.Chat( Color( 255, 0, 0 ), "Failed to fetch user data from login server, running as guest." )
						
					snixzz.Membership = "guest" 

				end
					
				snixzz.loadProgress:SetFraction( 0.3 )	
					
				snixzz.LoadCheat()
				
			elseif string.find( body, "Error: " ) then
				
				snixzz.Chat( Color( 255, 255, 0 ), "Failed to load, please see below for reason." )
				snixzz.Chat( Color( 255, 0, 0 ), body )
				
				if snixzz.loadFrame then snixzz.loadFrame:Close() gui.EnableScreenClicker( false ) end
				
				return
					
			else
				
				snixzz.loadFrame:SetTitle( "Received bad login info." )
			
				snixzz.Membership = "guest"
			
				snixzz.Chat( Color( 255, 0, 0 ), "Received bad login response, running as guest." )
				
				snixzz.LoadCheat()
				
			end
					
		end,
		
		function( error )
		
			snixzz.loadFrame:SetTitle( "Failed to connect to login server." )
			
			snixzz.Membership = "guest"
			
			snixzz.LoadCheat( true )
				
		end
		
	)
	
end

function snixzz.IsVIP()

	return snixzz.Membership == "vip" or snixzz.Membership == "dev"

end

function snixzz.Stats( ply, loading, func )

	G.http.Fetch( "http://snixzz.net/cheats/snixzz3/stats.php?steamid=" .. ply:SteamID64() .. "&load=" .. tostring( loading ),
		
		function( body )
		
			if loading && snixzz.loadProgress then
			
				snixzz.loadProgress:SetFraction( 0.7 )
			
			end
		
			if !string.find( body, "Error:" ) then
		
				G.http.Fetch( "http://snixzz.net/cheats/snixzz3/stats/totalruns.txt", 
					
					function( statsbody )
						
						if loading && snixzz.loadProgress then
			
							snixzz.loadProgress:SetFraction( 0.8 )
							
							func()
							
						end
						
						snixzz.AddToConsole( "Successfully posted stats, snixzz3 has now been ran " .. string.Comma( statsbody ) .. " times." )
						
					end,
					
					function( error ) 
						
						snixzz.Chat( Color( 255, 0, 0 ), "Failed to receive stats." )
						
						if loading && snixzz.loadProgress then
			
							snixzz.loadProgress:SetFraction( 0.8 )
							
							func()
							
						end
						
					end
					
				)
				
			else
				
				snixzz.Chat( Color( 255, 0, 0 ), "Failed to post stats. (" .. body .. ")" )
				
			end
		
		end,
		
		function( error )
			
			snixzz.Chat( Color( 255, 0, 0 ), "Failed to post stats." )
			
		end
		
	)
		
end

/*
	Logging system
*/
snixzz.NoLog = { -- Types of logs to not save in data/
	["Setting"] = true,
	["Load"] = true,
	["Detours"] = true,
	["Config"] = true,
	["Info"] = true,
	["debug"] = true,
	["Timer"] = true,
	["Hook"] = true,
	["Main"] = true,
}

snixzz.Lines = {}
function snixzz.logEvent( Type, str )

	G.table.insert( snixzz.Lines, str )
	
	if snixzz.LogTab then
	
		snixzz.LogTab:AddLine( str )
		
		snixzz.LogTab.VBar:SetScroll( snixzz.LogTab.VBar.CanvasSize )
		
	end
	
	if !snixzz.NoLog[Type] then
	
		local logFile = "[" .. G.os.date() .. "] " .. str .. "\n"
		
		G.file.Append( snixzz.DataFolder .. "/logs/" .. Type .. ".txt", logFile )
		
	end

end

/* Anti-Cheat bypass functions */
-- This is all really outdated. TODO: Update thhis
snixzz.Backup = {}
function snixzz.AntiCheats()

	-- HERP-AC c+p shitty ac
	if _G.CheckVars then
	
		snixzz.ACNoitfy( "function CheckVars exists, detouring the scan." )
		
		_G.CheckVars = snixzz.Detour( _G.CheckVars, function()
		
			snixzz.Chat( Color( 50, 255, 50 ), "HERP-AC attempted to scan cvars, stopping that..." )
			
		end )
		
	end
	
	-- Tyler's Anti-Cheat v2 (shameless bypass of my own anti-cheat)
	if _G.RunCheck then
	
		snixzz.ACNoitfy( "function RunCheck exists, detouring." )
		
		_G.RunCheck = snixzz.Detour( _G.RunCheck, function()
		
			snixzz.Chat( Color( 50, 255, 50 ), "TAC attempted to run a check, returning no information." )
			
		end )
		
 	end
	
end

-- TODO: Add runstring section to menu
local compiledString
function snixzz.RunString( str )

	compiledString = G.CompileString( str, "[C]", false )
	
	if G.type( compiledString ) == "string" then
	
		snixzz.Chat( Color( 0, 255, 255 ), "Failed to run Lua. '" .. str .. "'" )
		
		return
	end

	compiledString()
	
end

local Name
snixzz.Hooks = {}
function snixzz.AddHook( Type, Func )

	Name = G.tostring( Func )
	snixzz.AddToConsole( "Adding unsecure hook '" .. Name .. "'" )
	snixzz.Hooks[Type] = Name
	
	return G.hook.Add( Type, Name, Func )
end

snixzz.TimerCache = {}
function snixzz.RegisterTimer( delay, rep, func )

	Name = G.tostring( func )
	snixzz.AddToConsole( "Adding timer " .. Name .. " with delay '" .. G.tostring( delay ) .. "'" )
	
	G.table.insert( snixzz.TimerCache, Name )
	
	return G.timer.Create( Name, delay, rep, func )
end

/*

	Settings & Menu backend.
	Config system recycled from hake v2
	Re-wrote a bit of it.
	
*/

function snixzz.CreateOption( dtype, parent, oText, oBool, xPos, yPos, oWide, xPos2, yPos2, oDec, func )

	local addx, addy = 3, 3.5
	
	if dtype == "Checkbox" then
		dtype = "DCheckBoxLabel"
		local text, bool, x, y = oText, oBool, xPos, yPos
		local checkbox = G.vgui.Create( dtype, parent )
		checkbox:SetText( text )
		checkbox:SetPos( x + addx, y + addy )
		checkbox:SizeToContents()
		checkbox:SetTextColor( G.color_white )
		checkbox:SetChecked( snixzz.Bools[bool] ) 
		checkbox.OnChange = function( check ) 
			snixzz.Bools[bool] = checkbox:GetChecked() 
		end 	
		
	elseif dtype == "Slider" then
		dtype = "DNumSlider"
		local text, var, min, max, wide, x, y, Dec = oText, oBool, xPos, yPos, oWide, xPos2, yPos2, oDec
		local slider = G.vgui.Create( dtype, parent )
		slider:SetPos( x + addx, y + addy )
		slider:SetWide( wide )
		slider:SetText( text )
		slider:SetMin( min )
		slider:SetMax( max )
		slider:SetDecimals( Dec )
		slider:SetValue( snixzz.Vars[var] ) 
		slider.OnValueChanged = function( p, v ) 
			snixzz.Vars[var] = v 
		end
		
	elseif dtype == "Label" then
		dtype = "DLabel"
		local text, x, y = oText, oBool, xPos
		local label = G.vgui.Create( dtype, parent )
		label:SetPos( x, y )
		label:SetText( text )
		label:SizeToContents()
		label:SetTextColor( G.color_white )
		
	end
	
end

function snixzz.ConfigExists( cfg )

	if G.file.Exists( snixzz.DataFolder .. "/configs/" .. cfg .. ".txt", "DATA" ) then
		
		return true
		
	else
	
		return false
		
	end
end

function snixzz.SaveConfig( cfg )

	local save = {}
	save.Vars = snixzz.Vars
	save.Bools = snixzz.Bools
	save.Binds = snixzz.Binds
	save.Entities = snixzz.Entities
	save.Friends = snixzz.Friends
	cfg = G.string.gsub( cfg, " ", "_" )
	
	if !snixzz.ConfigExists( cfg ) then
	
		G.table.insert( snixzz.Configs, cfg )
		G.file.Write( snixzz.DataFolder .. "/configs/" .. cfg .. ".txt", G.util.TableToJSON( save ) )
		snixzz.Chat( snixzz.Colors.Green, "Created config " .. cfg .. "!" )
		
		snixzz.LoadConfig( cfg )
		
	else
		
		snixzz.Chat( snixzz.Colors.Red, "Config " .. cfg .. " already exists!" )
		
	end
	
end

function snixzz.UpdateConfig()

	local cfg = snixzz.CurrentConfig

	if cfg != "default" then
	
		if snixzz.ConfigExists( cfg ) then
			
			local save = {}
			save.Vars = snixzz.Vars
			save.Bools = snixzz.Bools
			save.Binds = snixzz.Binds
			save.Entities = snixzz.Entities
			save.Friends = snixzz.Friends
			G.file.Write( snixzz.DataFolder .. "/configs/" .. cfg .. ".txt", G.util.TableToJSON( save ) )
			snixzz.Chat( snixzz.Colors.Green, "Updated '" .. cfg .. "' with current settings" )
			
		else
			
			snixzz.Chat( snixzz.Colors.Red, "Config " .. cfg .. " wasn't found!" )
			
		end
		
	else
	
		snixzz.Chat( snixzz.Colors.Red, "You can't modify 'default' config!" )
		
	end	
	
end
	
function snixzz.LoadConfig( cfg, bool )

	cfg = G.string.lower( cfg )
	
	if snixzz.CurrentConfig != cfg then
	
		if snixzz.ConfigExists( cfg ) then
		
			local ToRead = G.util.JSONToTable( G.file.Read( snixzz.DataFolder .. "/configs/" .. cfg .. ".txt", "DATA" ) )
			snixzz.Vars = ToRead.Vars
			snixzz.Bools = ToRead.Bools
			snixzz.Binds = ToRead.Binds
			snixzz.Entities = ToRead.Entities
			snixzz.Friends = ToRead.Friends
			snixzz.CurrentConfig = cfg
			
			if !bool then -- ignore chat on first load
				snixzz.Chat( snixzz.Colors.Green, "Loaded config '" .. cfg .. "'" )
			end
			
		else
		
			snixzz.LoadConfig( "default" )
			snixzz.CurrentConfig = "default"
			snixzz.Chat( Color( 255, 0, 0 ), "Invalid config file! '" .. cfg .. "' Loading default!" )
			
		end
		
	else
	
		snixzz.Chat( snixzz.Colors.Red, "Config " .. cfg .. " is already loaded!" )
		
	end
	
end

function snixzz.DeleteConfig( cfg )

	cfg = G.string.lower( cfg )
	
	if cfg != snixzz.DefaultConfig then
		
		if G.file.Exists( snixzz.DataFolder .. "/configs/" .. cfg .. ".txt", "DATA" ) then
			
			G.file.Delete( snixzz.DataFolder .. "/configs/" .. cfg .. ".txt" )
			snixzz.Chat( snixzz.Colors["DarkRed"], "Deleted config '" .. cfg .. "'" )
			
		else
		
			snixzz.Chat( Color( 255, 0, 0 ), "Unable to find config " .. cfg "!" )
			
		end
		
	else
	
		snixzz.Chat( snixzz.Colors["Red"], "You cannot delete the default config!" )
		
	end
end

function snixzz.RenameConfig( Old, New )

	New = G.string.gsub( New, " ", "_" )
	New = G.string.lower( New )
	
	if Old != snixzz.DefaultConfig then
	
		if !snixzz.ConfigExists( New ) then
		
			local OldConfig = G.file.Read( snixzz.DataFolder .. "/configs/" .. Old .. ".txt", "DATA" )
			
			if snixzz.ConfigExists( Old ) then
			
				G.file.Delete( snixzz.DataFolder .. "/configs/" .. Old .. ".txt", "DATA" )
				
			end
			
			G.file.Write( snixzz.DataFolder .. "/configs/" .. New .. ".txt", OldConfig )
			snixzz.Chat( snixzz.Colors["DarkRed"], "Renamed " .. Old .. " to " .. New .. "." )
			
		else
		
			snixzz.Chat( Color( 255, 0, 0 ), "Config " .. New .. " already exists! Pick a different name." )
			
		end
		
	else
	
		snixzz.Chat( snixzz.Colors["Red"], "You cannot rename the default config!" )
		
	end
	
end

function snixzz.SetDefaultConfig( cfg )

	if cfg != snixzz.DefaultConfig then
	
		if snixzz.ConfigExists( cfg ) then
		
			snixzz.DefaultConfig = cfg 
			G.file.Write( snixzz.DataFolder .. "/defaultconfig.txt", snixzz.DefaultConfig )
			snixzz.Chat( Color( 255, 255, 0 ), "Set '" .. cfg .. "' as the default config." )
			
		else
		
			snixzz.Chat( Color( 255, 0, 0 ), "'" .. cfg .. "' is not a valid config!" )
			
		end
		
	else
	
		snixzz.Chat( Color( 255, 0, 0 ), "'" .. cfg .. "' is already the default config!" )
		
	end
	
end

function snixzz.BindKey( Bind, Key, bool ) 

	-- Console binding, ignore checks.
	if bool then
	
		if G[Key] then
		
			if snixzz.Binds[Bind] then
	
				snixzz.Binds[Bind] = G[Key]
				snixzz.Chat( snixzz.Colors.Green, "Bound " .. Bind .. " to " .. Key .. "!" )
				
			else
				
				snixzz.Chat( snixzz.Colors.Red, "'" .. Bind .. "' is an unknown command!" )
				
			end
			
		else
			
			snixzz.Chat( snixzz.Colors.Red, "'" .. Key .. "' is an unknown key!" )
			
		end
		
		return
		
	end

	if snixzz.Binds[Bind] then 

		for _, v in G.pairs( snixzz.Keys ) do 
										
			if Key == v.Name then 

				snixzz.Binds[Bind] = v.Key
				snixzz.Chat( snixzz.Colors.Green, "Bound " .. Bind .. " to " .. Key .. "!" )
				
			end 
			
		end  
		
	end 
	
end

-- TODO: use this somewhere
function snixzz.Unbind( Bind )

	if snixzz.Binds[Bind] then
	
		snixzz.Binds[Bind] = KEY_NONE
		snixzz.Chat( snixzz.Colors.Green, "Unbound " .. Bind .. "!" )
		
	else	
	
		snixzz.Chat( snixzz.Colors.Red, "Failed to find command '" .. Bind .. "'" )
		
	end
	
end 

function snixzz.GetConfigs() 

	local files = G.file.Find( snixzz.DataFolder .. "/configs/*.txt", "DATA") 
	
	for k, v in G.pairs( files ) do 
		
		files[k] = G.string.Replace( v, ".txt", "" ) 
	
	end  
	
	return files 
end 

-- Update all configs to work with the newest version of the cheat.
snixzz.UpdatedCfgs = {}
function snixzz.UpdateAllConfigs() -- Update outdated configs to the new version.
	
	for _, cfg in G.next, snixzz.Configs do
		
		if snixzz.ConfigExists( cfg ) then
		
			local json = G.util.JSONToTable( G.file.Read( snixzz.DataFolder .. "/configs/" .. cfg .. ".txt", "DATA" ) )

			-- Check Binds
			for k, v in G.next, snixzz.Binds do
				
				if json.Binds[k] == nil then
					
					json.Binds[k] = v
				
					snixzz.Message( snixzz.Colors.White, "Added bind '" .. k .. "' to config '" .. cfg .. "'" )
					
					if !snixzz.UpdatedCfgs[cfg] then snixzz.UpdatedCfgs[cfg] = true end
					
				end
				
			end
			
			-- Check Bools
			for k, v in G.next, snixzz.Bools do
				
				if json.Bools[k] == nil then
					
					json.Bools[k] = v
				
					snixzz.Message( snixzz.Colors.White, "Added bool '" .. k .. "' to config '" .. cfg .. "'" )
					
					if !snixzz.UpdatedCfgs[cfg] then snixzz.UpdatedCfgs[cfg] = true end
					
				end
				
			end
			
			-- Check Vars
			for k, v in G.next, snixzz.Vars do
				
				if json.Vars[k] == nil then
									
					json.Vars[k] = v
					
					snixzz.Message( snixzz.Colors.White, "Added var '" .. k .. "' to config '" .. cfg .. "'" )
					
					if !snixzz.UpdatedCfgs[cfg] then snixzz.UpdatedCfgs[cfg] = true end

				end
				
			end
			
			if snixzz.UpdatedCfgs[cfg] then
			
				G.file.Write( snixzz.DataFolder .. "/configs/" .. cfg .. ".txt", G.util.TableToJSON( json ) )
				
				snixzz.Chat( snixzz.Colors.Green, "Successfully updated config '" .. cfg .. "' with the newest settings." )
				
			end
			
		end
		
	end
	
end

/*

	filesystem 

*/

snixzz.DataFiles = {
	"defaultconfig.txt",
	"logs/Main.txt",
	"logs/AntiCheat.txt",
	"logs/Detour.txt",
	"logs/Debug.txt",
}
snixzz.DataFolders = {
	"configs",
	"logs",
}

function snixzz.FileSystem()
	
	if !G.file.IsDir( snixzz.DataFolder, "DATA" ) then
		
		G.file.CreateDir( snixzz.DataFolder )
		snixzz.Message( Color( 0, 255, 0 ), "Creating '" .. snixzz.DataFolder .. "' main data folder." )
		
	end
	
	for k, v in G.next, snixzz.DataFolders do
		
		if !G.file.IsDir( snixzz.DataFolder .. "/" ..  v, "DATA" ) then
		
			G.file.CreateDir( snixzz.DataFolder .. "/" .. v )
			snixzz.Message( Color( 0, 255, 0 ), "Creating '" .. snixzz.DataFolder .. "/" .. v .. "' data folder." )
			
		end
		
	end

	for k, v in G.next, snixzz.DataFiles do
	
		if !G.file.Exists( snixzz.DataFolder .. "/" ..  v, "DATA" ) then
			
			G.file.Write( snixzz.DataFolder .. "/" .. v, G.Either( v == "defaultconfig.txt", snixzz.DefaultConfig, "=== snixzz3 by 0xymoron ===\n\n" ) ) -- This is a cool function.
			
			snixzz.Message( Color( 0, 255, 0 ), "Creating '" .. snixzz.DataFolder .. "/" .. v .. "' data file." )
		
		end
		
	end
	
end

/*
	ESP	functions
*/

-- borrowed from snipwnage2's cheat with permission
function snixzz.GetBounds( v )

	local eyePos = v:EyeAngles()
	local min = v:OBBMins()
	local max = v:OBBMaxs()
	
	local corners = {
		
		G.Vector( min.x, min.y, min.z ),
		G.Vector( min.x, min.y, max.z ),
		G.Vector( min.x, max.y, min.z ),
		G.Vector( min.x, max.y, max.z ),
		G.Vector( max.x, min.y, min.z ),
		G.Vector( max.x, min.y, max.z ),
		G.Vector( max.x, max.y, min.z ),
		G.Vector( max.x, max.y, max.z ),
		
	}
	
	local minx = G.math.huge 
	local miny = G.math.huge 
	local maxx = -G.math.huge
	local maxy = -G.math.huge
	
	for _, corner in G.next, corners do
		
		local screen = v:LocalToWorld( corner ):ToScreen()
		minx = G.math.min( minx, screen.x )
		miny = G.math.min( miny, screen.y )
		maxx = G.math.max( maxx, screen.x )
		maxy = G.math.max( maxy, screen.y )
		
	end
	
	return minx, miny, maxx, maxy
end

-- Thanks gmod wiki!
function snixzz.DrawOutlinedBox( x, y, w, h, thickness, color )
	
	G.surface.SetDrawColor( color )
	
	for i = 0, thickness - 1 do
		
		G.surface.DrawOutlinedRect( x + i, y + i, w - i * 2, h - i * 2 )
	
	end
	
end

function snixzz.IsAdmin( v )

	if v:IsAdmin() then
		
		return true
		
	end
	
	if snixzz.AdminGroups[v:GetUserGroup()] then
		
		return true
		
	end
	
end

function snixzz.ShouldDraw( v )

	// better fps maybe
	local distance = v:GetPos():Distance( G.LocalPlayer():GetPos() )
	
	if snixzz.Vars["esp_render_distance"] != 0 && distance >= snixzz.Vars["esp_render_distance"] then
		
		return false
	
	end

	if !v:IsPlayer() or !v:Alive() or v == G["LocalPlayer"]() then
		
		return false
	
	end
		
	if ( v:Team() == TEAM_SPECTATOR or G.string.find( G.team.GetName( v:Team() ), "spectator" ) ) then
		
		return false
	
	end	
	
	if snixzz.Functions.IsDormant( v:EntIndex() ) then
		
		return false
	
	end
	
	return true	
end

/********************/
/*					*/
/* Aimbot functions */
/*					*/
/********************/


-- sloppy ass isvalid function
function snixzz.IsValid( v, Type )
	
	if !G.IsValid( v ) or v == G.LocalPlayer() then
		
		return false
		
	end
	
	if Type then
		
		if Type == "Aimbot" then
		
			if snixzz.IsProphunt && snixzz.Bools["misc_prophunt_finder"] then
				
				if v:IsPlayer() then
					
					if v:Team() == TEAM_SPECTATOR or v:Team() == TEAM_UNASSIGNED then return false end
					
					if v == LocalPlayer() then return false end -- Duh
					
				elseif snixzz.IsProp( v ) then
					
					local owner = v:GetOwner()
					
					if owner == LocalPlayer() then return false end
					
				end
				
				if LocalPlayer():GetClass() == "ph_prop" then
					
					return false
					
				end
				
				if !snixzz.IsProp( v ) && !v:IsPlayer() then
					
					return false
					
				end
				
				if v:IsPlayer() && v:Team() == TEAM_HUNTERS then
					
					return false
					
				end
			
			elseif snixzz.Vars["aim_target_type"] == "NPC" && !v:IsNPC() then
				
				return false
				
			elseif snixzz.Vars["aim_target_type"] == "Players" && !v:IsPlayer() then
				
				return false
				
			elseif snixzz.Vars["aim_target_type"] == "Both" && !v:IsPlayer() && !v:IsNPC() then
				
				return false
				
			end
		
		elseif Type == "Triggerbot" then
		
			if snixzz.Vars["misc_triggerbot_type"] == "NPC" && !v:IsNPC() then
				
				return false
				
			elseif snixzz.Vars["misc_triggerbot_type"] == "Players" && !v:IsPlayer() then
				
				return false
				
			elseif snixzz.Vars["misc_triggerbot_type"] == "Both" && !v:IsPlayer() && !v:IsNPC() then
				
				return false
				
			end
			
		elseif Type == "ESP" then
			
			if snixzz.IsProphunt && snixzz.Bools["misc_prophunt_finder"] then
				
				if v:IsPlayer() then
					
					if v:Team() == TEAM_SPECTATOR or v:Team() == TEAM_UNASSIGNED then return false end
					
					if v == LocalPlayer() then return false end -- Duh
					
				elseif snixzz.IsProp( v ) then
					
					local owner = v:GetOwner()
					
					if owner == LocalPlayer() then return false end
					
				end

				if !snixzz.IsProp( v ) && !v:IsPlayer() then
					
					return false
					
				end
				
				if v:IsPlayer() && !snixzz.IsProp( v ) && v:Team() == TEAM_PROPS then
					
					return false
					
				end
				
			elseif snixzz.Vars["esp_type"] == "NPC" && !v:IsNPC() then
				
				return false
				
			elseif snixzz.Vars["esp_type"] == "Players" && !v:IsPlayer() then
				
				return false
				
			elseif snixzz.Vars["esp_type"] == "Entities" && !snixzz.Entities[v:GetClass()] then
				
				return false
				
			elseif snixzz.Vars["esp_type"] == "All" && !snixzz.Entities[v:GetClass()] && !v:IsPlayer() && !v:IsNPC() then
				
				return false
				
			end
			
			local distance = v:GetPos():Distance( G.LocalPlayer():GetPos() )
	
			if snixzz.Vars["esp_render_distance"] != 0 && distance >= snixzz.Vars["esp_render_distance"] then
				
				return false
			
			end
			
		end
		
	end
		
	-- IsDormant check
	if snixzz["IsDormant"]( v:EntIndex() ) && !snixzz.IsProp( v ) then 
			
		return false
		
	end
	
	if Type == nil or Type != "ESP" then
	
		if v:GetMoveType() == 0 && !snixzz.IsProp( v ) then
			
			return false
			
		end

		// visible check
		if !snixzz.Bools["aim_ignorelos"] then
			
			if !snixzz.IsVisible( v, snixzz.GetPos( v ) ) then
				
				return false
		
			end
		
		end
		
		-- field of view
		if !snixzz.InFov( v ) then
				
			return false
			
		end
		
	end
	
	if snixzz.IsProphunt && snixzz.Bools["misc_prophunt_finder"] then
	
		if snixzz.IsProp( v ) && v:Health() < 0 then
			
			return false
		
		elseif v:IsPlayer() && !v:Alive() then
				
			return false
				
		end
		
	elseif v:IsNPC() then
		
		if v:Health() < 1 then
			
			return false
			
		end
		
	elseif v:IsPlayer() then
		
		if Type == nil or Type != "ESP" then
		
			-- ignore admins
			if snixzz.Bools["aim_ignoreadmins"] then
				
				if snixzz.IsAdmin( v ) then
					
					return false
				
				end
			
			end
			
			-- ignore friends
			if snixzz.Bools["aim_ignorefriends"] then
				
				if snixzz.Friends[v:Nick()] then
					
					return false
				
				end
			
			end
			
			if snixzz.Bools["aim_targetonlyfriends"] then
			
				if !snixzz.Friends[v:Nick()] or snixzz.Friends[v:Nick()] == nil then
				
					return false
					
				end
			
			end
		
			-- Ignore bots
			if snixzz.Bools["aim_ignorebots"] && v:IsBot() then
				
				return false
			
			end
			
			if v:InVehicle() then 
			
				return false 
		
			end
			
			-- No noclip glitchers please
			if G.GetConVarNumber( "sbox_noclip" ) == 0 && v:GetMoveType() == MOVETYPE_NOCLIP then 
				
				return false 
			
			end
		
			-- Ignore Steam friends
			if snixzz.Bools["aim_ignoresteam"] then
				
				if v:GetFriendStatus() == "friend" then 
					
					return false 
				
				end
			
			end
			
			-- Friendly Fire
			if snixzz.Bools["aim_ignoreteam"] then
				
				if ( v:Team() == G.LocalPlayer():Team() ) then
					
					return false
			
				end
			
			end
			
			// ignore T buddies
			if snixzz.Bools["aim_ignoretraitors"] && snixzz.IsTTT then
				
				if ( G.LocalPlayer():IsTraitor() && v:IsTraitor() ) then
					
					return false
				
				end
			
			end
			
			// Target only traitors
			if snixzz.Bools["aim_onlytraitors"] && snixzz.IsTTT then
				
				if !snixzz.IsTraitor( v ) then
					
					return false
					
				end
				
			end
			
			
			// spawn protection
			local col = v:GetColor()
			
			if col.a < 255 then
			
				return false
			
			end
			
			if G.LocalPlayer():GetColor().a < 255 then
				
				return false
		
			end
			
		end
		
		if !v:Alive() then
				
			return false
				
		end
		
		-- Spectator check
		if v:GetMoveType() == MOVETYPE_OBSERVER or v:Team() == TEAM_SPECTATOR then 
			
			return false 
		
		end
		
	end

	return true
	
end


snixzz.Cones = {

	["HL2"] = {
		["weapon_pistol"] = G.Vector( 0.01, 0.01, 0.01 ),
		["weapon_smg1"] = G.Vector( 0.04362, 0.04362, 0.04362 ),
		["weapon_ar2"] = G.Vector( 0.02618, 0.02618, 0.02618 ),
		["weapon_shotgun"] = G.Vector( 0.08716, 0.08716, 0.08716 ),
	},
	
	["Normal"] = {}
	
}

local wepCone
snixzz.Predicting = false
function snixzz.GetCone( wep )

	if !G.IsValid( wep ) then
		
		return 0
	
	end
	
	snixzz.Predicting = true -- idea stolen from dismay, seeing if this does anything.

	if snixzz.Cones["HL2"][wep:GetClass()] != nil then
		
		snixzz.Predicting = false
		
		return snixzz.Cones.HL2[wep:GetClass()]
		
	end
	
	if snixzz.Cones.Normal[wep:GetClass()] != nil then
		
		snixzz.Predicting = false
		
		return snixzz.Cones.Normal[wep:GetClass()]
		
	end
	
	wepCone = wep.Cone
	
	if !wepCone then
		
		wepCone = wep.Primary && wep.Primary.Cone or 0
		
	end
	
	snixzz.Predicting = false
	
	return wepCone or 0
	
end
		
local spreadCone = G.Vector( 0, 0, 0 )
local getCone = G.Vector( 0, 0, 0 )
local punch
function snixzz.PredictSpread( cmd, ang )
	
	local wep = G.LocalPlayer():GetActiveWeapon() or NULL
	
	if !G.IsValid( wep ) then
		
		return ang
	
	end
	
	getCone = snixzz.GetCone( wep )
			
	if G.type( getCone ) == "number" then
		
		spreadCone = G.Vector( -getCone, -getCone, -getCone )
	
	elseif G.type( getCone ) == "Vector" then
			
		spreadCone = getCone * -1
		
	end
	
	if snixzz.Cones["HL2"][wep:GetClass()] != nil then
	
		punch = G.LocalPlayer():GetViewPunchAngles()
		
		ang = ang - punch
	
	end

	local iCmdNumber = cmd:CommandNumber()
	
	if( iCmdNumber == 0 ) then 
	
		return ang  
	
	end 
	
	local seed = md5.PseudoRandom( iCmdNumber )

	local x = engineSpread[seed][1]
	local y = engineSpread[seed][2]
 
	local forward = ang:Forward()
	local right = ang:Right()
	local up = ang:Up()
 
	local cd = forward + ( x * -spreadCone.x * right * -1 ) + ( y * -spreadCone.y * up * -1 )
	
	local spreadAngles = cd:Angle()
	
	spreadAngles:Normalize()

	return spreadAngles
	
	//return snixzz.Functions.PredictSpread( cmd, ang, spreadCone )
	
end



snixzz.NPCModels = {

	["models/combine_scanner.mdl"] = "Scanner.Body",
	["models/hunter.mdl"] = "MiniStrider.body_joint",
	["models/combine_turrets/floor_turret.mdl"] = "Barrel",
	["models/dog.mdl"] = "Dog_Model.Eye",
	["models/antlion.mdl"] = "Antlion.Body_Bone",
	["models/antlion_guard.mdl"] = "Antlion_Guard.Body",
	["models/antlion_worker.mdl"] = "Antlion.Head_Bone",
	["models/zombie/fast_torso.mdl"] = "ValveBiped.HC_BodyCube",
	["models/zombie/fast.mdl"] = "ValveBiped.HC_BodyCube",
	["models/headcrabclassic.mdl"] = "HeadcrabClassic.SpineControl",
	["models/headcrabblack.mdl"] = "HCBlack.body",
	["models/headcrab.mdl"] = "HCFast.body",
	["models/zombie/poison.mdl"] = "ValveBiped.Headcrab_Cube1",
	["models/zombie/classic.mdl"] = "ValveBiped.HC_Body_Bone",
	["models/zombie/classic_torso.mdl"] = "ValveBiped.HC_Body_Bone",
	["models/zombie/zombie_soldier.mdl"] = "ValveBiped.HC_Body_Bone",
	["models/combine_strider.mdl"] = "Combine_Strider.Body_Bone",
	["models/lamarr.mdl"] = "HeadcrabClassic.SpineControl",
	["models/crow.mdl"] = Vector( 0, 0, 5 ),
	["models/pigeon.mdl"] = Vector( 0, 0, 5 ),
	["models/seagull.mdl"] = Vector( 0, 0, 6 ),

}

snixzz.Bones = {
	
	["Head"] = "ValveBiped.Bip01_Head1",
	["Neck"] = "ValveBiped.Bip01_Neck1",
	["Spine"] = "ValveBiped.Bip01_Spine",
	["Spine2"] = "ValveBiped.Bip01_Spine2",
	["Spine4"] =  "ValveBiped.Bip01_Spine4",
	["Pelvis"] = "ValveBiped.Bip01_Pelvis",
	["R Upperarm"] = "ValveBiped.Bip01_R_UpperArm",
	["R Forearm"] = "ValveBiped.Bip01_R_Forearm",
	["R Hand"] = "ValveBiped.Bip01_R_Hand",
	["L Upperarm"] = "ValveBiped.Bip01_L_UpperArm",
	["L Forearm"] = "ValveBiped.Bip01_L_Forearm",
	["L Hand"] = "ValveBiped.Bip01_L_Hand",
	["R Thigh"] = "ValveBiped.Bip01_R_Thigh",
	["R Calf"] = "ValveBiped.Bip01_R_Calf",
	["R Foot"] = "ValveBiped.Bip01_R_Foot",
	["R Toes"] = "ValveBiped.Bip01_R_Toe0",
	["L Thigh"] = "ValveBiped.Bip01_L_Thigh",
	["L Calf"] = "ValveBiped.Bip01_L_Calf",
	["L Foot"] = "ValveBiped.Bip01_L_Foot",
	["L Toes"] = "ValveBiped.Bip01_L_Toe0",
	
}

snixzz.Hitboxes = {

	["Head"] = 0,	
	["L Upperarm"] = 1,
	["L Forearm"] = 2,
	["L Hand"] = 3,
	["R Upperarm"] = 4,
	["R Forearm"] = 5,
	["R Hand"] = 6,
	["L Thigh"] = 7,
	["L Calf"] = 8,
	["F Foot"] = 9,
	["L Toe"] = 10,
	["R Thigh"] = 11,
	["R Calf"] = 12,
	["R Foot"] = 13,
	["R Toe"] = 14,
	["Pelvis"] = 15,
	["Spine"] = 16,
	
}

snixzz.Hitscans = {
	0, -- head
	16, -- spine
	4, -- r upper arm
	1, -- l upper arm
	5, -- r forearm
	2, -- l forearm
	6, -- r hand
	3, -- l hand
	15, -- pelvis
	11, -- r thigh
	7, -- l thigh
	12, -- r calf
	8, -- l calf
	13, -- r foot
	9, -- l foot
}

snixzz.Hitgroups = {
	[HITGROUP_HEAD] = "Head",
	[HITGROUP_CHEST] = "Chest",
	[HITGROUP_STOMACH] = "Stomach",
	[HITGROUP_LEFTARM] = "Left Arm",
	[HITGROUP_RIGHTARM] = "Right Arm",
	[HITGROUP_LEFTLEG] = "Left Leg",
	[HITGROUP_RIGHTLEG] = "Right Leg",
}

local Hitbox
local HitboxPos
local Bone
local BonePos
local Hitscan
local HitscanPos
local HitMin, HitMax
function snixzz.GetPos( v )
	
	if snixzz.IsProphunt && snixzz.Bools["misc_prophunt_finder"] && snixzz.IsProp( v ) then
		
		return v:LocalToWorld( v:OBBCenter() )
	
	elseif snixzz.Vars["aim_target_type"] == "NPC" or snixzz.Vars["aim_target_type"] == "Both" && v:IsNPC() then
		
		local special = snixzz.NPCModels[v:GetModel()]	
		
		if !special then	
			
			for k, v in G.next, snixzz.Bones do
				
				if v[1] == snixzz.Vars["aim_bone"] then
					
					special = v[2]
					
				end
				
			end
			
			special = special or "ValveBiped.Bip01_Head1"
			
		elseif type( special ) == "Vector" then
		
			return v:LocalToWorld( special )
		
		end
		
		local bone = v:LookupBone( special )
		
		if bone then
			
			local pos, ang = v:GetBonePosition( bone )
			
			return pos, ang
			
		end
		
	elseif snixzz.Vars["aim_target_type"] == "Players" or snixzz.Vars["aim_target_type"] == "Both" && v:IsPlayer() then
	
		if snixzz.Vars["aim_method"] == "Hitbox" then
		
			Hitbox = v:GetHitBoxBone( snixzz.Hitboxes[snixzz.Vars["aim_hitbox"]], 0 )	
			HitboxPos = v:GetBonePosition( Hitbox )
		
			local min, max = v:GetHitBoxBounds( snixzz.Hitboxes[snixzz.Vars["aim_hitbox"]], 0 )
			
			return HitboxPos + ( min + max ) / 2
			
		elseif snixzz.Vars["aim_method"] == "Bone" then
			
			Bone = snixzz.Bones[snixzz.Vars["aim_bone"]]
			BonePos = v:LookupBone( Bone )
			
			if BonePos then
				
				local pos, ang = v:GetBonePosition( BonePos )
				return pos, ang
			
			end
		
		elseif snixzz.Vars["aim_method"] == "Hitscan" then
			
			for k, e in G.next, snixzz.Hitscans do
			
				Hitscan = v:GetHitBoxBone( snixzz.Hitscans[k], 0 )

				if Hitscan != nil then
					
					HitscanPos = v:GetBonePosition( Hitscan )
					HitMin, HitMax = v:GetHitBoxBounds( snixzz.Hitscans[k], 0 )
					
					if snixzz.IsVisible( v, HitscanPos + ( HitMin + HitMax ) / 2 ) then
						
						snixzz.TargetBone = Hitscan

						return HitscanPos + ( HitMin + HitMax ) / 2
						
					end
					
				end
				
			end
		
		end		
		
	end

	return v:LocalToWorld( v:OBBCenter() )
end

-- thanks asutorea
function snixzz.CanFire()
	
	local wep = G.LocalPlayer():GetActiveWeapon()
	
	if snixzz.properCurTime == nil then return false end
	
	return G.IsValid( wep ) && !snixzz.BadWeapons[wep:GetClass()] && wep:GetActivity() != ACT_RELOAD && wep:GetNextPrimaryFire() < snixzz.properCurTime && G.LocalPlayer():Alive()
end

-- pAntiAnti Aim
function snixzz.FixAngle( v )

	local eyeAngles = _R.Entity.EyeAngles( v )
	
	if eyeAngles.p < -89 then
		
		_R.Entity.SetPoseParameter( v, "aim_pitch", eyeAngles.p + 180 )
		_R.Entity.InvalidateBoneCache( v )
	
	elseif eyeAngles.p > 89 then
	
		_R.Entity.SetPoseParameter( v, "aim_pitch", eyeAngles.p - 180 )
		_R.Entity.InvalidateBoneCache( v )
	
	end
	
end

function snixzz.OnScreen( v )
	
	local a, f = _R.Player.GetAimVector( G.LocalPlayer() ):Angle() - ( v:GetPos() - G.LocalPlayer():GetShootPos() ):Angle(), _R.Player.GetFOV( G.LocalPlayer() )     
	
	return ( G.math.NormalizeAngle( a.y ) < f + 2 && G.math.NormalizeAngle( a.p ) < f + 2 )
end

function snixzz.IsDormant( index )
	
	return snixzz.Functions.IsDormant( index )

end

function snixzz.FixMove( ucmd, aa )
	
	local fixAngle = G.Vector( ucmd:GetForwardMove(), ucmd:GetSideMove(), 0 )
	fixAngle = (( fixAngle:GetNormal() ):Angle() + ( ucmd:GetViewAngles() - G.Angle( 0, snixzz.Silent.y, 0 ) ) ):Forward() * fixAngle:Length()
	
	if aa then
		
		ucmd:SetForwardMove( fixAngle.x )
		ucmd:SetSideMove( fixAngle.y * -1 )
		
		return	
	end
	
	ucmd:SetForwardMove( fixAngle.x )
	ucmd:SetSideMove( fixAngle.y )
	
end

function snixzz.NormalizeAngles( ang )
	
	ang.p = G.math.NormalizeAngle( ang.p )
	ang.y = G.math.NormalizeAngle( ang.y )
	ang.r = 0
	
	return ang
	
end

local fov, my_FovAngs, targAng // fovangs
local fovang = {}
function snixzz.InFov( ply )

	fov = snixzz.Vars["aim_fov"] 
	
	if fov == 180 then 
	
		return true
		
	end
	
	my_FovAngs = LocalPlayer():GetAngles()

	targAng = ( snixzz.GetPos( ply ) - LocalPlayer():GetShootPos() ):Angle()
	
	fovang.y = math.abs( math.NormalizeAngle( my_FovAngs.y - targAng.y ) )
	fovang.p = math.abs( math.NormalizeAngle( my_FovAngs.p - targAng.p ) )
	
	if fovang.y > fov or fovang.p > fov then 
	
		return false 
		
	end
	
	return true
	
end

local smooth_Speed
local my_Angles
function snixzz.SmoothAngle( ang ) // idk what im doing

	smooth_Speed = snixzz.Vars["aim_smooth_speed"] / 10

	my_Angles = LocalPlayer():EyeAngles()
	
	my_Angles.p = math.Approach( my_Angles.p, ang.p, smooth_Speed )
	
	my_Angles.y = math.Approach( my_Angles.y, ang.y, smooth_Speed )
	
	my_Angles.r = 0
	
	ang = my_Angles
	
	return ang

end

snixzz.PredPositions = {}
local tbl = snixzz.PredPositions[v] or {}

function snixzz.GetPredictionPos( v, pos )
	
	tbl.pos = tbl.pos or pos or _R.Entity.GetPos( v )
	
	local realTime = G.RealTime()
	
	if tbl.realTime != realTime then
		
		tbl.realTime = realTime
		tbl.pos = pos or _R.Entity.GetPos( v )
		
	end	
	
	tbl.velocity = v:GetVelocity()	
	snixzz.PredPositions = tbl	
	
	return tbl.pos
end

snixzz.PredictionMethods = { "Velocity 0.0075", "Engine Velocity", "Classic", "Herpes", "ColdFire", "FapHack", "fr1kin", "Dismay", "Ampris", "Turbobot", "Faphack Old" }
snixzz.PredWeapons = {

	["weapon_crossbow"] = 3110,
	["weapon_frag"] = 3110,
	
}

local sv_gravity = G.GetConVar( "sv_gravity" )
local interp_ratio = G.GetConVar( "cl_interp_ratio" )
local updaterate = G.GetConVar( "cl_updaterate" )
local interp = G.GetConVar( "cl_interp" )
local emptyVec = Vector( 0, 0, 0 )
local tPos, lVelocity, tVelocity, tDistance, predTime, predWep, shootPos, ply_Frames, targ_Frames, time, ping

function snixzz.Prediction( Pos, v )

	predWep = G.LocalPlayer():GetActiveWeapon()
	lVelocity = _R.Entity.GetVelocity( G.LocalPlayer() )
	tVelocity = _R.Entity.GetVelocity( v )
	tPos = _R.Entity.GetPos( v )
	lPos = _R.Entity.GetPos( G.LocalPlayer() )
	tDistance = lPos:Distance( tPos )
	
	if G.IsValid( v ) && G.type( tVelocity ) == "Vector" && G.type( tPos ) == "Vector" then		

		if predWep && G.IsValid( predWep ) && snixzz.PredWeapons[predWep:GetClass()] then		
		
			predTime = tDistance / snixzz.PredWeapons[predWep:GetClass()]
			Pos = Pos + tVelocity * predTime	
			
		else		
		
			if snixzz.Vars["aim_prediction_method"] == "Velocity 0.0075" then
				
				Pos = Pos + lVelocity * 0.0075 + tVelocity * 0.0075
					
			elseif snixzz.Vars["aim_prediction_method"] == "Engine Velocity" then
				
				Pos = Pos + tVelocity * G.engine.TickInterval() - lVelocity * G.engine.TickInterval()
				
			elseif snixzz.Vars["aim_prediction_method"] == "Classic" then
			
				Pos = Pos + tVelocity / 45 - lVelocity / 45
			
			elseif snixzz.Vars["aim_prediction_method"] == "Herpes" then
			
				tPos = snixzz.GetPredictionPos( v, Pos ) - Pos
				Pos = Pos + ( tPos * 2 ) - ( lVelocity / 50 )
			
			elseif snixzz.Vars["aim_prediction_method"] == "ColdFire" then
			
				Pos = Pos - tVelocity:GetNormal() / 5.8 + lVelocity:GetNormal() / 3
				
			elseif snixzz.Vars["aim_prediction_method"] == "FapHack" then
				
				Pos = Pos + tVelocity * 0.02 - lVelocity * 0.05
				
			elseif snixzz.Vars["aim_prediction_method"] == "fr1kin" then
			
				local targetFrames = RealFrameTime() / 25
				local plyFrames = RealFrameTime() / 66
				
				Pos = Pos + ( ( tVelocity * targetFrames ) - ( tVelocity * plyFrames ) ) - ( ( lVelocity * targetFrames ) + ( lVelocity * plyFrames ) )
				
			elseif snixzz.Vars["aim_prediction_method"] == "Dismay" then

				local vel = v:GetVelocity()
				
				local i = math.max( interp:GetFloat(), interp_ratio:GetFloat() / updaterate:GetFloat() )
				
				if v:IsOnGround() then
					
					vel.z = vel.z - sv_gravity:GetFloat() * 0.5 * FrameTime()
					
					vel.z = vel.z + v:GetVelocity().z * FrameTime()
					
				end
				
				Pos = Pos + vel * ( engine.TickInterval() * i )											
				
			elseif snixzz.Vars["aim_prediction_method"] == "Ampris" then

				shootPos = G.LocalPlayer():GetShootPos() + G.LocalPlayer():GetVelocity() * G.engine.TickInterval()
				ply_Frames = RealFrameTime() / 66
				targ_Frames = RealFrameTime() / 25
				
				Pos = Pos + ( tVelocity * ( targ_Frames ) - ( lVelocity * ( ply_Frames ) ) )
				
			elseif snixzz.Vars["aim_prediction_method"] == "Turbobot" then

				Pos = Pos + tVelocity * ( 1 / 66 ) - lVelocity * ( 1 / 66 )
					
			elseif snixzz.Vars["aim_prediction_method"] == "Faphack Old" then
			
				Pos = ( Pos - Vector( 0, 0, lVelocity:Length() / 250 ) ) + ( tVelocity * 0.0087 ) - ( lVelocity * 0.0087 )				
				
			end	
			
		end
		
	end
	
	return Pos
end

function snixzz.GetTarget()
	
	local x, y = G.ScrW(), G.ScrH()
	local vPos
	local oldPos = G.LocalPlayer():EyePos():ToScreen()
	local distance = G.math.huge
	local AngA
	local AngB
	//local target
	
	local Method
	
	if snixzz.IsProphunt && snixzz.Bools["misc_prophunt_finder"] then
		
		Method = G.ents.GetAll()
	
	elseif snixzz.Vars["aim_target_type"] == "NPC" then
		
		Method = G.ents.GetAll() 
		
	elseif snixzz.Vars["aim_target_type"] == "Players" then
	
		Method = G.player.GetAll()

	elseif snixzz.Vars["aim_target_type"] == "Both" then

		Method = G.ents.GetAll()
		
	end
	
	for k, v in G.next, Method do
		
		if snixzz.IsValid( v, "Aimbot" ) then
			
			distance2 = v:GetPos():DistToSqr( G.LocalPlayer():GetPos() )
			
			if snixzz.Vars["aim_target_method"] == "Distance" then
				
				if distance2 < distance then
				
					distance = distance2
					
					return v
				
				end
				
			elseif snixzz.Vars["aim_target_method"] == "Closest" then // i suck at math so this is totally ripped from every cheat ever
				
				local pos = LocalPlayer():EyePos()
				local ang = snixzz.Silent //LocalPlayer():GetAimVector()
				
				local plys = { 0, 0 }
				
				local plypos = v:EyePos()
				
				local diff = ( plypos - pos )
				
				diff = diff - ang
				diff = diff:Length()
				
				diff = math.abs( diff )
				
				if ( diff < plys[2] or plys[1] == 0 ) then
				
					plys = { v, diff }
					
				end
				
				return plys[1]
				
			elseif snixzz.Vars["aim_target_method"] == "Crosshair" then
			
				vPos = v:GetPos():ToScreen()
				AngA = G.math.Dist( x / 2, y / 2, oldPos.x, oldPos.y )
				AngB = G.math.Dist( x / 2, y / 2, vPos.x, vPos.y )
			
				if AngB <= AngA then
				
					return v
					
				end
				
			end	
			
		else
		
			continue
			
		end
		
	end
	
	return nil
end

snixzz.Firing = false
function snixzz.Fire( ucmd )

	if snixzz.Firing then
	
		ucmd:RemoveKey( G.IN_ATTACK )
		snixzz.Firing = false
		
	else
	
		ucmd:SetButtons( G.bit.bor( ucmd:GetButtons(), G.IN_ATTACK ) )
		snixzz.Firing = true
		
	end
	
end

snixzz.SpammingDoor = false
function snixzz.SpamDoor( ucmd )

	if snixzz.SpammingDoor then
	
		ucmd:RemoveKey( G.IN_USE )
		snixzz.SpammingDoor = false
		
	else
	
		ucmd:SetButtons( G.bit.bor( ucmd:GetButtons(), G.IN_USE ) )
		snixzz.SpammingDoor = true
		
	end
	
end


snixzz.FakeSwitch = false
snixzz.FakeAngle = G.Angle()
snixzz.AntiAimMethods = { "Classic", "Classic Inverted", "Static", "Jitter", "Random Pitch",/* "Fake Angles", "Fake Jitter", */"Spin", /*"Fake Spin"*/ }
function snixzz.AntiAim( ucmd )

	local pitches = { -181, 541, 262 }
	local yaws = { 262, -262, 181, -181, 541, -541 }
	
	-- OG anti-aim
	if snixzz.Vars["aim_anti_method"] == "Classic" then
		
		snixzz.Functions.SetViewAngles( ucmd, G.Angle( 181, ucmd:GetViewAngles().y, 180 ) )
		snixzz.FixMove( ucmd )
		
	-- Looking down instead of up
	elseif snixzz.Vars["aim_anti_method"] == "Classic Inverted" then
		
		snixzz.Functions.SetViewAngles( ucmd, G.Angle( -181, ucmd:GetViewAngles().y, 180 ) )
		snixzz.FixMove( ucmd )
		
	-- Static
	elseif snixzz.Vars["aim_anti_method"] == "Static" then
		
		snixzz.Functions.SetViewAngles( ucmd, G.Angle( -snixzz.Angles.p + 900, snixzz.Angles.y + 180, 0 ) )
		snixzz.FixMove( ucmd, true )
		
	-- Jitter - credits to cdriza
	elseif snixzz.Vars["aim_anti_method"] == "Jitter" then
		
		snixzz.Functions.SetViewAngles( ucmd, G.Angle( G.table.Random( pitches ), G.table.Random( yaws ), 0 ) )
		snixzz.FixMove( ucmd, true )
		
	-- Randomized pitch
	elseif snixzz.Vars["aim_anti_method"] == "Random Pitch" then
	
		snixzz.Functions.SetViewAngles( ucmd, G.Angle( G.math.random( -180, -186.49999 ), ucmd:GetViewAngles().y, 180 ) )
		snixzz.FixMove( ucmd )
		
	-- bSendPacket Fake Angles
	/*elseif snixzz.Vars["aim_anti_method"] == "Fake Angles" then
		
		snixzz.FakeAngle = ucmd:GetViewAngles()
		
		if snixzz.FakeSwitch then
			
			bSendPacket = true
			//snixzz.Functions.SendPacket( true )
			snixzz.Functions.SetViewAngles( ucmd, G.Angle( -192, snixzz.FakeAngle.y + 90, 0 ) )
		
		else
			
			bSendPacket = false			
			snixzz.Functions.SetViewAngles( ucmd, G.Angle( -192, snixzz.FakeAngle.y - 90, 0 ) )
		
		end
		
		snixzz.FixMove( ucmd, true )
		snixzz.FakeSwitch = !snixzz.FakeSwitch
	
	-- bSendPacket Fake Jitter
	elseif snixzz.Vars["aim_anti_method"] == "Fake Jitter" then
		
		snixzz.FakeAngle = ucmd:GetViewAngles()
		
		if snixzz.FakeSwitch then
			
			bSendPacket = true
			snixzz.Functions.SetViewAngles( ucmd, G.Angle( G.math.random( -180, -186.49999 ), snixzz.FakeAngle.y + 90, 0 ) )
		
		else
			
			bSendPacket = false			
			snixzz.Functions.SetViewAngles( ucmd, G.Angle( G.math.random( -180, -186.49999 ), snixzz.FakeAngle.y - 90, 0 ) )
		
		end
		
		snixzz.FixMove( ucmd, true )
		snixzz.FakeSwitch = !snixzz.FakeSwitch
		
	*/
		
	-- Simple spinbot with -192 pitch
	elseif snixzz.Vars["aim_anti_method"] == "Spin" then
		
		snixzz.Functions.SetViewAngles( ucmd, ucmd:GetViewAngles() + G.Angle( 0, G.math.fmod( G.CurTime() / .1 * 2 * snixzz.Vars["aim_anti_spin_speed"], 360 ), 0 ) )
		snixzz.FixMove( ucmd, false )
	
	-- bSendPacket Spinbot
	/*elseif snixzz.Vars["aim_anti_method"] == "Fake Spin" then
		
		snixzz.FakeAngle = ucmd:GetViewAngles()
		
		if FakeSwitch then
			
			bSendPacket = true			
			snixzz.Functions.SetViewAngles( ucmd, ucmd:GetViewAngles() + G.Angle( 0, G.math.fmod( G.CurTime() / .1 * 2 * snixzz.Vars["aim_anti_spin_speed"], 360 ), 0 ) )
		
		else
			
			bSendPacket = false
			snixzz.Functions.SetViewAngles( ucmd, ucmd:GetViewAngles() + G.Angle( 0, -G.math.fmod( G.CurTime() / .1 * 2 * snixzz.Vars["aim_anti_spin_speed"], 360 ), 0 ) )
		
		end
		
		snixzz.FixMove( ucmd, false )
	*/
	end
	
end

-- To shorten up my aimbot checks a bit.
function snixzz.ShouldAim( ucmd, isToggled )
	
	if snixzz.Bools["aim_canfire"] && !snixzz.CanFire() then
		
		return false
		
	end
	
	return snixzz.Target && snixzz.IsValid( snixzz.Target, "Aimbot" ) && ucmd:CommandNumber() != 0// && snixzz.CanFire()	
	
end

function snixzz.InMenu()

	return snixzz.Typing or snixzz.ChatboxOpen or G.gui.IsConsoleVisible() or G.gui.IsGameUIVisible()

end

local bind, key
function snixzz.DoBind( str )
	
	//if snixzz.ChatOpen or snixzz.Typing then return false end
	
	if snixzz.InMenu() then return false end
	
	if str == "+aimbot" && snixzz.Bools["aim_toggle"] then return true end
	
	if str == "+triggerbot" && snixzz.Bools["misc_triggerbot"] then return true end
	
	bind = snixzz.Binds[str]
	
	key = input.GetKeyName( bind )
	
	if string.find( key:lower(), "mouse" ) then
	
		if input.IsMouseDown( bind ) then
			
			return true
			
		end
		
	else
	
		if input.IsKeyDown( bind ) then 
			
			return true
			
		end
	
	end

	return false

end

/*=======================


Hooked functions below


=========================*/
snixzz.Status = "Waiting..."
snixzz.StatusColor = Color( 255, 255, 0, 150 )
snixzz.Silent = G.Angle()
snixzz.BulletTime = true
snixzz.StuckSwitch = false
snixzz.StuckTicks = 0
snixzz.pDelay = 0
snixzz.NoSpreadAngle = G.Angle()
//snixzz.SpreadPos = G.Vector( 0, 0, 0 )

local plsbeDoor
function snixzz.CreateMove( ucmd )

	-- cl noclip
	if snixzz.Bools["misc_csnoclip"] then
	
		ucmd:SetForwardMove( 0 )
		ucmd:SetUpMove( 0 )
		ucmd:SetSideMove( 0 )
		
	end
	
	-- Doorspam
	if snixzz.Bools["misc_doorspam"] then
	
		plsbeDoor = G.LocalPlayer():GetEyeTrace().Entity
		
		if IsValid( plsbeDoor ) && plsbeDoor:GetClass() == "func_door" or plsbeDoor:GetClass() == "prop_door_rotating" then
		
			snixzz.SpamDoor( ucmd )
		
		end
	
	end	

	// Silent aim
	snixzz.Silent = snixzz.Silent + G.Angle( ucmd:GetMouseY() * 0.022, -ucmd:GetMouseX() * 0.022, 0 )
	snixzz.Silent.p = G.math.Clamp( snixzz.Silent.p, -89, 89 )
	snixzz.Silent.y = G.math.NormalizeAngle( snixzz.Silent.y )
	
	ucmd:SetViewAngles( snixzz.Silent ) 

	if ucmd:CommandNumber() == 0 then

		return
		
	end		
	
	if !snixzz.Bools["aim_holdtarget"] then 
		
		snixzz.Target = snixzz.GetTarget()
		
	end
	
	snixzz.Offset = G.Vector( 0, 0, snixzz.Vars["aim_offset"] )
			
	snixzz.Angles = snixzz.Silent
	
	// Aimbot core
	//if ( snixzz.Binds["+aimbot"] != nil && G.input.IsKeyDown( snixzz.Binds["+aimbot"] ) && !snixzz.ChatboxOpen && !snixzz.Typing or snixzz.Bools["aim_toggle"] ) then
	if snixzz.DoBind( "+aimbot" ) then
		
		if snixzz.Bools["aim_holdtarget"] then
		
			if snixzz.Target == nil or snixzz.Target != nil && !snixzz.IsValid( snixzz.Target, "Aimbot" ) then
			
				snixzz.Target = snixzz.GetTarget()
			 
			end
			
		end
		
		if snixzz.ShouldAim( ucmd, snixzz.Bools["aim_toggle"] ) then
		
			snixzz.Angles = snixzz.GetPos( snixzz.Target ) + snixzz.Offset
			
			if snixzz.Bools["aim_prediction"] then
				
				snixzz.Angles = snixzz.Prediction( snixzz.Angles, snixzz.Target )
				
			end
				
			snixzz.Angles = ( snixzz.Angles - G.LocalPlayer():GetShootPos() ):Angle()	
			
			-- Spread Prediction
			if snixzz.Bools["aim_nospread"] then
			
				if snixzz.Bools["aim_badshots"] then
					
					if G.math.random( 1, 5 ) == 1 then
					
						snixzz.Angles = snixzz.Angles // eeeeeeeeeeeeeeeeeeeeee
						
					else
		
						snixzz.Angles = snixzz.PredictSpread( ucmd, G.Angle( snixzz.Angles.p, snixzz.Angles.y, 0 ) )
						
					end
					
				else
					
					snixzz.Angles = snixzz.PredictSpread( ucmd, G.Angle( snixzz.Angles.p, snixzz.Angles.y, 0 ) )
					
				end
				
			end	
			
			snixzz.Angles = snixzz.NormalizeAngles( snixzz.Angles )
			
			-- Set angles
			snixzz.Functions.SetViewAngles( ucmd, snixzz.Angles )	

			-- autofire
			if snixzz.Bools["aim_autoshoot"] then
				
				snixzz.Fire( ucmd )		
				
			end
			
			-- Silent aim view & move correction
			if snixzz.Bools["aim_silent"] then
				
				snixzz.FixMove( ucmd )
				
			else
				
				snixzz.Silent = snixzz.Angles
				
			end
				
			-- ghetto aimbot status
			if snixzz.Target:IsPlayer() then
			
				snixzz.Status = "Locked! (" .. snixzz.Target:Nick() .. ")"
				
				snixzz.StatusColor = Color( 255, 0, 0, 150 )
				snixzz.Locked = true
				
			elseif snixzz.Target:IsNPC() then
				
				snixzz.Status = "Locked! (" .. snixzz.Target:GetModel() .. ")"
				
				snixzz.StatusColor = Color( 255, 0, 0, 150 )
				snixzz.Locked = true
				
			elseif snixzz.IsProphunt && snixzz.IsProp( snixzz.Target ) && snixzz.IsProp( snixzz.Target ) then
				
				snixzz.Status = "Locked! (" .. snixzz.Target:GetOwner():Name() .. ")"
				
				snixzz.StatusColor = Color( 255, 0, 0, 150 )
				snixzz.Locked = true

			end
							
		else
			
			snixzz.Target = nil
			snixzz.Status = "Searching..."
			snixzz.StatusColor = Color( 0, 255, 0, 150 )
			snixzz.Locked = false	
		
		end
	
	else
		
		snixzz.Target = nil
		snixzz.Status = "Searching..."
		snixzz.StatusColor = Color( 0, 255, 0, 150 )
		snixzz.Locked = false	
	
	end
	
	-- Rapid-Fire
	if snixzz.Bools["misc_rapidfire"] && ucmd:KeyDown( IN_ATTACK ) && !snixzz.Locked then
		
		snixzz.Fire( ucmd )
		
	end
	
	-- Constant NoSpread
	if snixzz.Bools["aim_constant_nospread"] then
	
		snixzz.SpreadHitPos = G.LocalPlayer():GetEyeTrace().HitPos
		snixzz.NoSpreadAngle = ( snixzz.SpreadHitPos - G.LocalPlayer():GetShootPos() ):GetNormal():Angle()
		snixzz.NoSpreadAngle = snixzz.PredictSpread( ucmd, ucmd:GetViewAngles() )
		
		if !snixzz.Locked && ucmd:KeyDown( IN_ATTACK ) then
			
			snixzz.NoSpreadAngle.p = math.NormalizeAngle( snixzz.NoSpreadAngle.p )
			snixzz.NoSpreadAngle.y = math.NormalizeAngle( snixzz.NoSpreadAngle.y )
			
			snixzz.Functions.SetViewAngles( ucmd, snixzz.NoSpreadAngle )
			
		end
		
	end
	
	-- Triggerbot
	//if snixzz.Binds["+triggerbot"] != nil && snixzz.Bools["misc_triggerbot"] or G.input.IsKeyDown( snixzz.Binds["+triggerbot"] ) then
	if snixzz.DoBind( "+triggerbot" ) then
		
		snixzz.StatusColor = Color( 255, 255, 0, 150 )
		snixzz.Status = "Triggerbot Searching.."
		local hitgroup = G.LocalPlayer():GetEyeTrace().HitGroup
		local entity = G.LocalPlayer():GetEyeTrace().Entity
		snixzz.SpreadPos = G.LocalPlayer():GetEyeTrace().HitPos
		
		if snixzz.Vars["misc_triggerbot_type"] == "NPC" or snixzz.Vars["misc_triggerbot_type"] == "Both" && entity:IsNPC() then
			
			if snixzz.IsValid( entity, "Triggerbot" ) then
				
				if snixzz.Bools["aim_nospread"] or snixzz.Bools["aim_constant_nospread"] then
					
					snixzz.NoSpreadAng = snixzz.PredictSpread( ucmd, ( snixzz.SpreadPos - G.LocalPlayer():GetShootPos() ):GetNormal():Angle() )
					snixzz.Functions.SetViewAngles( ucmd, snixzz.NoSpreadAng )
					
				end
				
				snixzz.StatusColor = Color( 255, 0, 0, 150 )
				snixzz.Status = "Firing! (" .. entity:GetModel() .. ")"
			
				snixzz.Fire( ucmd )
				
			end
		
		elseif snixzz.Vars["misc_triggerbot_method"] == "Body" then
			
			if snixzz.IsValid( entity, "Triggerbot" ) then
								
				if snixzz.Bools["aim_nospread"] or snixzz.Bools["aim_constant_nospread"] then
					
					snixzz.NoSpreadAng = snixzz.PredictSpread( ucmd, ( snixzz.SpreadPos - G.LocalPlayer():GetShootPos() ):GetNormal():Angle() )
					snixzz.Functions.SetViewAngles( ucmd, snixzz.NoSpreadAng )
					
				end
				
				snixzz.StatusColor = Color( 255, 0, 0, 150 )
				snixzz.Status = "Firing! (" .. entity:Nick() .. ")"
			
				snixzz.Fire( ucmd )
				
			end
			
		elseif snixzz.Vars["misc_triggerbot_method"] == "Hitbox" then
			
			if snixzz.Hitgroups[hitgroup] != nil && snixzz.IsValid( entity, "Triggerbot" ) then
								
				if snixzz.Bools["aim_nospread"] or snixzz.Bools["aim_constant_nospread"] then
					
					snixzz.NoSpreadAng = snixzz.PredictSpread( ucmd, ( snixzz.SpreadPos - G.LocalPlayer():GetShootPos() ):GetNormal():Angle() )
					snixzz.Functions.SetViewAngles( ucmd, snixzz.NoSpreadAng )
					
				end
				
				snixzz.StatusColor = Color( 255, 0, 0, 150 )
				snixzz.Status = "Firing! (" .. entity:Nick() .. ")"
				
				snixzz.Fire( ucmd ) 
				
			end
			
		end
		
	end
	
	-- Anti-Aim
	if snixzz.Bools["aim_anti"] && !snixzz.Locked && !ucmd:KeyDown( IN_ATTACK ) && !ucmd:KeyDown( IN_USE ) && G.LocalPlayer():GetMoveType() != MOVETYPE_LADDER then
		
		snixzz.AntiAim( ucmd )
		
	end	
	
	// Bunnyhop & autostrafe
	if snixzz.Bools["misc_bhop"] then
		
		if !G.LocalPlayer():GetMoveType() != MOVETYPE_NOCLIP && G.LocalPlayer():GetMoveType() != MOVETYPE_LADDER && !snixzz.Typing then		
			
			if !G.LocalPlayer():OnGround() && ucmd:KeyDown( IN_JUMP )then				
				
				ucmd:SetButtons( G.bit.band( ucmd:GetButtons(), G.bit.bnot( IN_JUMP ) ) )
				
				-- Autostrafe shamelessly ripped from "public hvh v1".
				-- i don't understand this shit.
				if snixzz.Bools["misc_autostrafe"] then
					
					if ucmd:GetMouseX() > 1 or ucmd:GetMouseX() < - 1 then
						
						ucmd:SetSideMove( ucmd:GetMouseX() > 1 && 400 or -400 )
						
					else
						
						ucmd:SetForwardMove( 5850 / G.LocalPlayer():GetVelocity():Length2D() )
						ucmd:SetSideMove( ( ucmd:CommandNumber() % 2 == 0 ) && -400 or 400 ) -- what the fuck. who thought of this shit.
						
					end
					
				end
				
			elseif ucmd:KeyDown( IN_JUMP ) && snixzz.Bools["misc_autostrafe"] then
				
				ucmd:SetForwardMove( 10000 )
							
			end			
			
		end		
		
	end

end

snixzz.CSNoclipPos = {}
function snixzz.CalcView( ply, origin, angles, fov )

	local ply = G.LocalPlayer()
	local wep = ply:GetActiveWeapon()
	local noclipSpeed = snixzz.Vars["misc_csnoclip_speed"] * ( FrameTime() / 2 ) * 100
	local view = {}
		
	// Advanced NoRecoil. TODO: Recoil Control System
	if snixzz.Bools["aim_norecoil"] then
		
		if wep.Primary then
		
			wep.Primary.Recoil = 0
			
		elseif wep.Secondary then
			
			wep.Secondary.Recoil = 0
			
		end
		
	else
	
		if wep.Primary then

			wep.Primary.Recoil = snixzz.RecoilBackup[wep:GetClass()]
			
		else
		
			if wep.Secondary then
			
				wep.Secondary.Recoil = snixzz.RecoilBackup[wep:GetClass()]
				
			end
			
		end
		
	end
		
	if snixzz.Bools["misc_csnoclip"] && snixzz.CSNoclipPos then

		local ang = snixzz.Silent:Forward()
		
		if LocalPlayer():KeyDown( IN_FORWARD ) then
			
			snixzz.CSNoclipPos = snixzz.CSNoclipPos + LocalPlayer():GetAimVector() * noclipSpeed
			
		end
		
		if LocalPlayer():KeyDown( IN_BACK ) then
			
			snixzz.CSNoclipPos = snixzz.CSNoclipPos - LocalPlayer():GetAimVector() * noclipSpeed
			
		end
		
		if LocalPlayer():KeyDown( IN_MOVERIGHT ) then
			
			snixzz.CSNoclipPos = snixzz.CSNoclipPos + ang:Angle():Right() * noclipSpeed
			
		end
		
		if LocalPlayer():KeyDown( IN_MOVELEFT ) then
			
			snixzz.CSNoclipPos = snixzz.CSNoclipPos - ang:Angle():Right() * noclipSpeed
			
		end

	else 
		
		snixzz.CSNoclipPos = LocalPlayer():EyePos()
		
	end
	
	view.angles = ( snixzz.Bools["aim_silent"] or snixzz.Bools["aim_anti"] ) && snixzz.Silent or angles
		
	view.fov = snixzz.Vars["esp_fov"]
	
	//view.origin = snixzz.Bools["misc_thirdperson"] && ( origin - snixzz.Silent:Forward() * snixzz.Vars["misc_thirdperson_distance"] ) or origin
	
	if snixzz.Bools["misc_thirdperson"] then
		
		view.origin =  origin - snixzz.Silent:Forward() * snixzz.Vars["misc_thirdperson_distance"] or origin
		
	elseif snixzz.Bools["misc_csnoclip"] then
		
		view.origin = snixzz.CSNoclipPos
		
	else
		
		view.origin = origin
		
	end

	return view	
end

-- Autism as FUCK
function snixzz.Color( col )

	if snixzz.Bools["esp_rainbow"] then
		
		return G.HSVToColor( RealTime() * 120 % 360, 1, 1 )

	end
		
	return col

end

// GetColor func
function snixzz.GetESPColor( v )
	
	if snixzz.Bools["misc_murder_finder"] && snixzz.IsMurder then
		
		if snixzz.IsMurderer( v ) then
		
			return G.Color( 255, 0, 0 )
			
		elseif snixzz.HasMagnum( v ) then
			
			return G.Color( 0, 255, 255 )
			
		else 
			
			return G.Color( 0, 255, 0 )
			
		end
		
	elseif snixzz.Bools["misc_prophunt_finder"] && snixzz.IsProphunt then
		
		if snixzz.IsProp( v ) then
			
			return G.Color( 255, 0, 0 )
			
		else
		
			return G.Color( 0, 255, 0 )
			
		end
		
	end
	
	if v:IsNPC() then
		
		return G.Color( 0, 255, 0 )
		
	end
	
	if snixzz.Entities[v:GetClass()] then
		
		return G.Color( 255, 255, 255 )
		
	end
	
	if v:GetFriendStatus() == "friend" then
		
		return G.HSVToColor( RealTime() * 120 % 360, 1, 1 )
	
	end
	
	if snixzz.Bools["misc_traitor_finder"] && snixzz.IsTTT && snixzz.IsTraitor( v ) then
		
		return G.Color( 255, 0, 0 )
		
	else
		
		return snixzz.Color( G.team.GetColor( v:Team() ) )
	
	end
	
	return G.Color( 255, 255, 255 )
	
end

local laserMat = G.Material( "trails/laser" )
local hitposMat = G.Material( "Sprites/light_glow02_add_noz" )
function snixzz.HUDPaint()

	local textpos;
	local x1, y1, x2, y2;
	local diff;
	local diff2;
	local color;
	local startx;
	local starty;
	local endpos;
	local pos;
	local wep = G.LocalPlayer():GetActiveWeapon()
	local viewmodel = G.LocalPlayer():GetViewModel()		
	local weapon
	local dynLight
	local playerPos
	local targetPos
	
	if snixzz.Bools["esp_radar"] then
	
		
	
	end
	
	-- Menu header
	if snixzz.MenuOpen then
		
		G.surface.SetDrawColor( snixzz.Color( snixzz.Vars["misc_menucolor2"] ) )
		G.surface.DrawRect( 20, 50, 420, 60 )
		
		G.surface.SetDrawColor( Color( 0, 0, 0, 255 ) )
		G.surface.DrawOutlinedRect( 20, 50, 420, 60, 2 )		

		G.draw.SimpleTextOutlined( "snixzz3", "snixzz_logo", 25, 55, snixzz.Color( snixzz.Colors.White ), TEXT_ALIGN_LEFT,TEXT_ALIGN_LEFT, 1.5, Color( 0, 0, 0 ) )
		G.draw.SimpleTextOutlined( "by 0xymoron", "snixzz_logo_small", G.surface.GetTextSize( "snixzz3" ) + 30, 65, snixzz.Color( snixzz.Colors.White ), TEXT_ALIGN_LEFT,TEXT_ALIGN_LEFT, 1, Color( 0, 0, 0 ) )
		
		-- Is VIP?
		G.draw.SimpleTextOutlined( "VIP:", "snixzz_logo_small", 
			//190, 65, 
			snixzz.Frame:GetWide() / 2 - surface.GetTextSize( "VIP:" ) / 2, 65,
			snixzz.Colors.White, TEXT_ALIGN_LEFT,TEXT_ALIGN_LEFT, 1, Color( 0, 0, 0 ) 
		)		
		
		-- Texture
		G.surface.SetMaterial( Material( snixzz.IsVIP() == true && "icon16/accept.png" or snixzz.IsVIP() == false && "icon16/cancel.png" ) )
		G.surface.SetDrawColor( color_white )
		G.surface.DrawTexturedRect( snixzz.Frame:GetWide() / 2 - surface.GetTextSize( "VIP:" ) / 2 + 22, 65, 16, 16 )
		
		-- Big ass shit
		G.draw.SimpleTextOutlined( 
			snixzz.Info.Version .. "   Last Updated: " .. snixzz.Info.Updated, 
			"snixzz_logo_small", 
			snixzz.Frame:GetWide() + 15, snixzz.Frame:GetTall() - 352,
			snixzz.Colors.White, TEXT_ALIGN_RIGHT, TEXT_ALIGN_BOTTOM, 1, Color( 30, 30, 30, 255 ) 
		)
		
	end
	
	-- Menu opening
	if snixzz.DoBind( "+menu" ) && !snixzz.MenuOpen then
			
		snixzz.Menu()
		snixzz.MenuOpen = true
			
	end
	
	-- Console Opening
	if G.input.IsKeyDown( KEY_Q ) && G.input.IsKeyDown( KEY_TAB ) && !snixzz.ConsoleOpen && !snixzz.InMenu() then
		
		snixzz.Console()
		snixzz.ConsoleOpen = true
		
	end
	
	-- Chat opening
	if !snixzz.ChatboxOpen then

		if snixzz.DoBind( "chat" ) then
			
			//snixzz.OpenChat()
			//snixzz.ChatboxOpen = true
			
		end
		
	end	
	
	if snixzz.Panic then return end
	if !snixzz.Bools["esp_enabled"] then return end
	
	-- Watermark
	/*if !snixzz.IsVIP() then
	
		G.draw.SimpleTextOutlined( "snixzz3 " .. snixzz.Info.Version .. " - snixzz.net", "snixzz_logo", G.ScrW() - 10, 25, G.HSVToColor( G.RealTime() * 120 % 360, 1, 1 ), TEXT_ALIGN_RIGHT, TEXT_ALIGN_BOTTOM, 1, G.Color( 0, 0, 0 ) )
	
	end*/
	
	-- Laser Sight
	if snixzz.Bools["esp_laser"] then
					
		if viewmodel && G.IsValid( wep ) && G.IsValid( viewmodel ) then
			
			if wep:GetClass() != "weapon_physgun" then
						
				local muzzle = viewmodel:LookupAttachment( "muzzle" )
				
				if muzzle == 0 then
					
					muzzle = viewmodel:LookupAttachment( "1" )
			
				end
							
				local trace = G.LocalPlayer():GetEyeTrace().HitPos
							
				if viewmodel:GetAttachment( muzzle ) then						
					
					G.cam.Start3D( G.EyePos(), G.EyeAngles() )
									
						local startpos = viewmodel:GetAttachment( muzzle ).Pos						
						local endpos = trace	
									
						if snixzz.Bools["aim_silent"] && snixzz.Locked && G.IsValid( snixzz.Target ) then
							
							endpos = snixzz.GetPos( snixzz.Target )
							
						else
							
							endpos = trace
							
						end
									
						-- Laser
						G.render.SetMaterial( laserMat )													
						G.render.DrawBeam( startpos, endpos, 4, 0, 0, snixzz.Color( snixzz.Vars["misc_lasercolor"] ) )
								
						-- HitPos Dot
						G.render.SetMaterial( hitposMat )
						
							G.render.DrawQuadEasy( 
							endpos, -- trace
							( G.EyePos() - trace ):GetNormal(), 
							25, 25, 
							Color( 255, 255, 255, 255 ), 0 
							
						)
								
					G.cam.End3D()
					
				end
				
			end
			
		end
		
	end

	-- Dynamic Light around player
	if snixzz.Bools["esp_dynamiclight"] then
	
		dynLight = G.DynamicLight( G.LocalPlayer():EntIndex() )
		dynLight.pos = G.LocalPlayer():GetShootPos()
		dynLight.r = 255
		dynLight.g = 255
		dynLight.b = 255
		dynLight.brightness = 1.75
		dynLight.Decay = 850
		dynLight.Size = 250
		dynLight.DieTime = G.CurTime() + 1
		
	end
	
	if G.IsValid( viewmodel ) then
	
		if snixzz.Bools["esp_wireweapon"] then
			
			_R.Entity.SetMaterial( viewmodel, "models/wireframe" )
			_R.Entity.SetColor( viewmodel, snixzz.Color( snixzz.Vars["misc_lasercolor"] ) )
			
		else
		
			_R.Entity.SetMaterial( viewmodel, "" )
			_R.Entity.SetColor( viewmodel, Color( 255, 255, 255 ) )
			
		end
		
	end
	
	local Method
	
	if snixzz.IsProphunt && snixzz.Bools["misc_prophunt_finder"] then
		
		Method = G.ents.GetAll()
	
	elseif snixzz.Vars["esp_type"] == "NPC" or snixzz.Vars["esp_type"] == "All" or snixzz.Vars["esp_type"] == "Entities" then
		
		Method = G.ents.GetAll()
		
	elseif snixzz.Vars["esp_type"] == "Players" then
		
		Method = G.player.GetAll()
		
	end
			
	for k, v in G.next, Method do
		
		if snixzz.IsValid( v, "ESP" ) then	

			textpos = 0 -- -2
			
			x1, y1, x2, y2 = snixzz.GetBounds( v )
			diff = G.math.abs( x2 - x1 )
			diff2 = G.math.abs( y2 - y1 )
			
			playerPos = snixzz.GetPos( v )
			color = snixzz.GetESPColor( v )	

			if v:IsPlayer() or v:IsNPC() then
				
				if G.IsValid( v:GetActiveWeapon() ) then
					
					weapon = v:GetActiveWeapon():GetPrintName()
					
				else
					
					weapon = "Unknown"
					
				end		
				
			else
				
				weapon = "nil"
				
			end
				
			if v:IsPlayer() or snixzz.IsProphunt && snixzz.IsProp( v ) then
				
				if snixzz.IsMurder then
				
					if snixzz.Bools["esp_name"] then
						
						G.draw.SimpleText( v:GetBystanderName() .. " (" .. v:Nick() .. ")", "ESPFont", x2 + 2, y1 + textpos, color, TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT )
						textpos = textpos + 12
						
					end
				
				elseif snixzz.IsProphunt && snixzz.Bools["misc_prophunt_finder"] then
					
					if snixzz.IsProp( v ) then
					
						G.draw.SimpleText( v:GetOwner():Name(), "ESPFont", x2 + 2, y1 + textpos, color, TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT )
						textpos = textpos + 12
					
					elseif v:Team() != TEAM_PROPS && v:GetClass() != "ph_prop" then
					
						G.draw.SimpleText( v:Nick(), "ESPFont", x2 + 2, y1 + textpos, color, TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT )
						textpos = textpos + 12
					
					end
					
				else
				
					if snixzz.Bools["esp_name"] then
						
						G.draw.SimpleText( v:Nick(), "ESPFont", x2 + 2, y1 + textpos, color, TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT )
						textpos = textpos + 12
						
					end
					
				end
				
			elseif v:IsNPC() then
				
				G.draw.SimpleText( v:GetModel(), "ESPFont", x2 + 2, y1 + textpos, color, TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT )
				textpos = textpos + 12
				
			elseif snixzz.Entities[v:GetClass()] then
			
				G.draw.SimpleText( v:GetClass(), "ESPFont", x2 + 2, y1 + textpos, color, TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT )
				textpos = textpos + 12
				
			end	
			
			if snixzz.Bools["esp_health_text"] then
			
				if snixzz.IsProphunt && snixzz.Bools["misc_prophunt_finder"] && snixzz.IsProp( v ) then
				
					G.draw.SimpleText( "HP: " .. v:GetOwner():Health(), "ESPFont", x2 + 2, y1 + textpos, color, TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT )
					textpos = textpos + 12

				elseif !snixzz.Entities[v:GetClass()] then
						
					G.draw.SimpleText( "HP: " .. v:Health(), "ESPFont", x2 + 2, y1 + textpos, color, TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT )
					textpos = textpos + 12
						
				end
					
			end	
			
			-- Health Bar
			if snixzz.Bools["esp_health_bar"] && !snixzz.Entities[v:GetClass()] then
				
				local health = v:Health()
					
				if snixzz.IsProphunt && snixzz.Bools["misc_prophunt_finder"] && snixzz.IsProp( v ) then
						
					health = v:GetOwner():Health()
						
				end
					
				G.surface.SetDrawColor( Color( 0, 0, 0 ) )
				G.surface.DrawRect( x1 -6, y1, 3, diff2 )
				G.surface.SetDrawColor( Color( 0, 255, 0 ) )
				G.surface.DrawRect( x1 - 6, y2 - diff2 / 100 * health, 3, diff2 / 100 * health )

			end
			
			-- ESP weapon
			if v:IsPlayer() or v:IsNPC() then
			
				if snixzz.Bools["esp_weapon"] then
						
					G.draw.SimpleText( weapon, "ESPFont", x2 + 2, y1 + textpos, color, TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT )
					textpos = textpos + 12
						
				end
				
				-- Snaplines
				if snixzz.Bools["esp_snaplines"] then
						
					startx = G.ScrW() / 2
					starty = G.ScrH() / 2
					endpos = playerPos:ToScreen()
							
					G.surface.SetDrawColor( color )
					G.surface.DrawLine( startx, starty, endpos.x, endpos.y )
						
				end
		
			end	
				
			-- Distance ESP
			if snixzz.Bools["esp_distance"] then
				
				G.draw.SimpleText( "D: " .. G.math.Round( v:GetPos():Distance( G.LocalPlayer():GetPos() ) ), "ESPFont", x2 + 2, y1 + textpos, color, TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT )
				textpos = textpos + 12
					
			end
				
				
			// Box ESP
			if snixzz.Bools["esp_box"] then
				
				snixzz.DrawOutlinedBox( x1, y1, diff, diff2, snixzz.Vars["esp_box_width"], color )
				
			end
			
			-- taken from newsbot for debug purposes
			if snixzz.Bools["esp_hitbox"] then
				
				for group = 0, EntM.GetHitBoxGroupCount( v ) do
				
					local count = EntM.GetHitBoxCount( v, group ) - 1
					
					for hitbox = 0, count do
					
						local bone = EntM.GetHitBoxBone( v, hitbox, group )
						
						if !bone then continue end
						
						local min, max = EntM.GetHitBoxBounds( v, hitbox, group )
						
						local bonepos, boneang = EntM.GetBonePosition( v, bone )
						
						G.cam.Start3D()
							
							if snixzz.Vars["aim_method"] == "Hitscan" && snixzz.TargetBone != nil && bone == snixzz.TargetBone then
							
								G.render.DrawWireframeBox( bonepos, boneang, min, max, Color( 255, 0, 0 ), true )
							
							else
							
								G.render.DrawWireframeBox( bonepos, boneang, min, max, Color( 255, 255, 255 ), true )
								
							end
							
						G.cam.End3D()
						
					end
					
				end
				
			end
				
			-- Chams! Much faster than RenderScreenSpaceEffects
			if snixzz.Bools["esp_chams"] then
				
				G.cam.Start3D()
					
					if snixzz.Vars["esp_chams_material"] == "Solid" then
						
						v:SetMaterial( "models/debug/debugwhite" )
						
					elseif snixzz.Vars["esp_chams_material"] == "Wireframe" then
					
						v:SetMaterial( "models/wireframe" )
					
					elseif snixzz.Vars["esp_chams_material"] == "XQZ" then
						
						v:SetMaterial( "" )
						
					end
						
					-- Weapon Chams
					if v:IsPlayer() or v:IsNPC() then
					
						if G.IsValid( v:GetActiveWeapon() ) then
							
							v:GetActiveWeapon():DrawModel()
							
						end
						
					end
						
					-- Player chams
					if snixzz.Vars["esp_chams_material"] != "XQZ" then
						
						G.render.SetColorModulation( color.r / 255, color.g / 255, color.b / 255 )
						
					end
					
					v:DrawModel()	
					//v:SetColor( Color( 255, 255, 255 ) )	
					v:SetMaterial( "" )

				G.cam.End3D()
				
			end
									
			-- For prediction testing & shit
			if snixzz.Bools["esp_aimpos"] then
				
				local predictedPos = snixzz.Prediction( playerPos, v ):ToScreen()
			
				G.draw.RoundedBox( 4, predictedPos.x, predictedPos.y, 7, 7, Color( 255, 0, 0, 255 ) )
				
			end
			
		else
		
			continue
			
		end	
	
	end

	// Aim status & shit
	if snixzz.Bools["esp_status"] then
		
		G.draw.DrawText( snixzz.Status, "snixzz_status", G.ScrW() / 2, G.ScrH() * 0.5 + 50, snixzz.StatusColor, TEXT_ALIGN_CENTER )
		
	end
	
	// Crosshair
	local x = ScrW() / 2
	local y = ScrH() / 2
	
	local crosscolor = Color( 0, 0, 0, 255 )
	local crosslength = 50
	local gap = 2
	
	local boxsize = 5
		
	-- Box
	if snixzz.Bools["esp_crosshair_box"] then
		
		G.surface.SetDrawColor( snixzz.Color( Color( 255, 255, 255 ) ) )
		G.surface.DrawOutlinedRect( x - boxsize - 2, y - boxsize - 2, ( boxsize + 2 ) * 2 + 1, ( boxsize + 2 ) * 2 + 1 )
		
	end
	
	-- Crosshair
	if snixzz.Bools["esp_crosshair"] then
		
		G.surface.SetDrawColor( snixzz.Color( Color( 0, 0, 0, 255 ) ) )
		G.surface.DrawLine( x - crosslength, y, x - gap, y )
		G.surface.DrawLine( x + crosslength, y, x + gap, y )
		
		G.surface.DrawLine( x, y - crosslength, x, y - gap )
		G.surface.DrawLine( x, y + crosslength, x, y + gap )
		
	end
	
end

snixzz.properCurTime = 0
snixzz.LagVar = 12
snixzz.LagTicks = 0
local dynLight
function snixzz.Move()

	if G.IsFirstTimePredicted() then return end
	snixzz.properCurTime = G.CurTime() + G.engine.TickInterval()	
			
	// No hands
	if snixzz.Bools["esp_nohands"] then
		
		snixzz.Functions.NoDraw( G.Material( "models/weapons/v_models/hands/v_hands" ), true )
		
	else
	
		snixzz.Functions.NoDraw( G.Material( "models/weapons/v_models/hands/v_hands" ), false )
		
	end	
			
end

local alphabet = {"a","b","c","d","e","f","g","h","i","j","k","l","m","n","o","p","q","r","s","t","u","v","w","x","y","z"}

function snixzz.Namechanger()
	
	if snixzz.Bools["misc_namechanger"] then
		
		local players = G.table.Copy( G.player.GetAll() )
		table.RemoveByValue( players, LocalPlayer() )
		
		snixzz.NextName = G.table.Random( players ):Nick()
		G.chat.AddText( Color( 0, 255, 255 ), "[snixzz3] Changed your name to " .. snixzz.NextName ) 
		
		if snixzz.IsDarkRP then
			
			-- Overly comlpicated Steam name stealer & RP name stealer. Accuse 2 different people at once.
			//snixzz.NextName = G.table.Random( G.player.GetAll() ):Nick()
			//snixzz.Functions.ConCommand( "name " .. snixzz.NextName .. " %" )
			//snixzz.Functions.SetName( snixzz.NextName .. " %" )
	
			snixzz.Functions.ConCommand( "darkrp rpname " .. snixzz.NextName .. table.Random( alphabet ) ) -- ** TODO: CHANGE q TO SOMETHING ELSE.
			
		/*else
			
			//snixzz.NextName = G.table.Random( G.player.GetAll() ):Nick()
			snixzz.Functions.ConCommand( "name " .. snixzz.NextName .. " %" )
			snixzz.Functions.SetName( snixzz.NextName .. " %" )
			*/
		end
		
	end
	
end

function snixzz.ChatSpam()

	if snixzz.Bools["misc_chat_spam"] then
	
		if snixzz.Vars["misc_chat_spam_method"] == "Advertise" then
	
			G.RunConsoleCommand( "say", G.Either( snixzz.IsDarkRP, "/ooc " .. snixzz.Vars["misc_chat_spam_message"], snixzz.Vars["misc_chat_spam_message"] ) )
			
		elseif snixzz.Vars["misc_chat_spam_method"] == "Yo Momma Jokes" then	
			
			G.http.Fetch( "http://api.yomomma.info/", 
				
				function( body )
					
					if body && body != "" then
						
						G.RunConsoleCommand( "say", G.Either( snixzz.IsDarkRP,  "/ooc " .. util.JSONToTable( body )["joke"], util.JSONToTable( body )["joke"] ) )
						
					end
					
				end,
				
				function( error )
					
					snixzz.Chat( snixzz.Colors.Red, "Unable to grab joke from API! (" .. error .. ")" )
					
				end
			
			)
			
		elseif snixzz.Vars["misc_chat_spam_method"] == "Chuck Norris" then

			G.http.Fetch( "https://api.chucknorris.io/jokes/random", 
				
				function( body )
					
					if body && body != "" then
						
						G.RunConsoleCommand( "say", G.Either( snixzz.IsDarkRP,  "/ooc " .. util.JSONToTable( body )["value"], util.JSONToTable( body )["value"] ) )
						
					end
					
				end,
				
				function( error )
					
					snixzz.Chat( snixzz.Colors.Red, "Unable to grab joke from API! (" .. error .. ")" )
					
				end
			
			)
			
		elseif snixzz.Vars["misc_chat_spam_method"] == "Insults" then

			G.http.Fetch( "https://insult.mattbas.org/api/insult/", 
				
				function( body )
					
					if body && body != "" then
						
						G.RunConsoleCommand( "say", G.Either( snixzz.IsDarkRP,  "/ooc " .. body, body ) )
						
					end
					
				end,
				
				function( error )
					
					snixzz.Chat( snixzz.Colors.Red, "Unable to grab joke from API! (" .. error .. ")" )
					
				end
			
			)

		elseif snixzz.Vars["misc_chat_spam_method"] == "Random Jokes" then
			
			G.http.Fetch( "https://jokes.guyliangilsing.me/retrieveJokes.php?type=random", 
				
				function( body )
					
					if body && body != "" then
						
						G.RunConsoleCommand( "say", G.Either( snixzz.IsDarkRP,  "/ooc " .. util.JSONToTable( body )["joke"], util.JSONToTable( body )["joke"] ) )
						
					end
					
				end,
				
				function( error )
					
					snixzz.Chat( snixzz.Colors.Red, "Unable to grab joke from API! (" .. error .. ")" )
					
				end
			
			)
			
		end

	end	
	
end

snixzz.CorrectAngles = {}

// Idk where this came from but it's shit

/*
function snixzz.AAA()

	for k, v in G.next, G.player.GetAll() do
		
		if v == G.LocalPlayer() then continue end
		
		local pitch, yaw = v:EyeAngles().x, v:EyeAngles().y
		local sid = v:SteamID()
		
		if !snixzz.CorrectAngles[sid] then
			
			snixzz.CorrectAngles[sid] = { ["p"] = 0, ["y"] = 0 }
			
		end
		
		-- pitch
		if snixzz.CorrectAngles[sid]["p"] == 1 then
			
			pitch = 89
			
		elseif snixzz.CorrectAngles[sid]["p"] == 2 then
			
			pitch = -89
			
		end
		
		-- yaw
		if snixzz.CorrectAngles["y"] == 1 then
			
			yaw = yaw - 45
			
		elseif snixzz.CorrectAngles["y"] == 2 then
			
			yaw = yaw + 45
			
		else
			
			yaw = yaw - 180
			
		end
			
		_R.Entity.SetPoseParameter( v, "aim_pitch", pitch )
		_R.Entity.SetPoseParameter( v, "body_yaw", 0 )
		_R.Entity.SetPoseParameter( v, "aim_yaw", 0 )
		_R.Entity.InvalidateBoneCache( v )
		_R.Entity.SetRenderAngles( v, G.Angle( 0, G.math.NormalizeAngle( yaw ), 0 ) )
		
	end

end*/

/*
	
		
	Traitor, Prophunt, & Murder Finders.
	

*/
snixzz.Traitors = {}
snixzz.Murderers = {}
snixzz.ClearedMurderers = false
snixzz.ClearedTraitors = false
local t

function snixzz.IsMurderer( v )

	if v:HasWeapon( "weapon_mu_knife" ) then
	
		return true
		
	end
	
	if G.table.HasValue( snixzz.Murderers, v ) then 
	
		return true
		
	end
	
	return false

end

function snixzz.HasMagnum( v )

	if v:HasWeapon( "weapon_mu_magnum" ) then
	
		return true
		
	end
	
	return false

end

local testtab = {}
function snixzz.IsProp( v )
	
	if v:GetOwner() != nil then
		
		local owner = v:GetOwner()
		
	else
		
		return false
		
	end
	
	if v:GetClass() == "ph_prop" && owner != G.LocalPlayer() then
		
		return true
		
	end
	
	return false

end

function snixzz.IsTraitor( v )
	
	if G.table.HasValue( snixzz.Traitors, v ) or G.LocalPlayer():IsTraitor() && v:IsTraitor() then
		
		return true
		
	end
	
	return false
end

function snixzz.GetTraitors()
	
	if !snixzz.IsTTT then return end
	
	if !snixzz.Bools["misc_traitor_finder"] then return end
		
	for k, v in G.next, G.ents.GetAll() do
			
		if _G.GetRoundState() == 3 && v:IsWeapon() && v:GetOwner():IsPlayer() && v.Buyer == nil && v.CanBuy && G.table.HasValue( v.CanBuy, 1 ) && !G.table.HasValue( snixzz.Traitors, v:GetOwner() ) then
				
			local t = v:GetOwner()
				
			if t:GetRole() == 2 then
					
				v.Buyer = t
				
				snixzz.ClearedTraitors = false
					
			else
					
				G.table.insert( snixzz.Traitors, t )
				
				snixzz.ClearedTraitors = false
				
				snixzz.Chat( G.Color( 255, 0, 0 ), t:Nick() .. " bought traitor weapon '" .. v:GetClass() .. "'" )
					
			end
				
		elseif GetRoundState() != 3 then
				
			if !snixzz.ClearedTraitors then
		
				snixzz.Traitors = {}
				snixzz.Chat( color_white, "Cleared traitors table." )
				snixzz.ClearedTraitors = true
			
				
			end
			
		end
		
	end
	
end


/*
	DETOURS
*/

// thanks for old code daz, miss u buddy. <3
function snixzz.SpoofQACPing()

	local int = G.net.ReadInt( 10 )
	
	G.net.Start( "Debug1" )
	
		G.net.WriteInt( int, 16 )
		
	G.net.SendToServer()
	
	snixzz.AddToConsole( "Spoofed QAC ping" )

end

local function no()

	snixzz.ACNotify( "Blocked incoming QAC net message" )

	return
	
end

snixzz.AAC = {

	["FakeFiles"] = {
		"demo_recording.lua",
		"vgui/dbutton.lua",
		"vgui/dgrid.lua",
		"menu/menu.lua",
		"menu/mainmenu.lua",
		"menu/loading.lua",
		"menu/video.lua",
		"menu/errors.lua",
	},
	
	["Receivers"] = {
	
		["Debug2"] = snixzz.SpoofQACPing,
		["gcontrol_vars"] = function() 
			
			G.net.Start( "gcontrol_vars" )
			
				G.net.WriteBit()
				
			G.net.SendToServer()
			
		end,
		["control_vars"] = no,
		["checksaum"] = no,
	
	},
	
}

function snixzz.CreateDetours()
	
	debug.getinfo = snixzz.Detour( debug.getinfo, function()
	
		return { 
			what = "C",
			source = "[C]",
			source_src = "[C]",
			linedefined = -1,
			currentline = -1,
			lastlinedefined = -1,
			short_src = "[C]",
		}
		
	end )
	
	_R.Entity.FireBullets = snixzz.Detour( _R.Entity.FireBullets, function( e, bullet )
		
		local wep = G.LocalPlayer():GetActiveWeapon()
		
		snixzz.Cones.Normal[ wep:GetClass() ] = bullet["Spread"]
		
		if snixzz.RecoilBackup[ wep:GetClass() ] == nil then
		
			snixzz.AddToConsole( "Saving recoil backup for '" .. wep:GetClass() .. "' (" .. wep.Primary.Recoil .. ")" )
		
			snixzz.RecoilBackup[ wep:GetClass() ] = wep.Primary.Recoil or 0
		
		end
		
		if snixzz.Predicting then return end
		
		return snixzz.Detours[ _R.Entity.FireBullets ]( e, bullet )
	end )
	
	WepM.SendWeaponAnim = snixzz.Detour( WepM.SendWeaponAnim, function( ... )
	
		if snixzz.Predicting then return end
		
		return snixzz.Detours[WepM.SendWeaponAnim]( ... )
	
	end )

	render.Capture = snixzz.Detour( render.Capture, function( data )
		
		snixzz.AddToConsole( "An anti-cheat attempted to capture your screen, disabling visuals for 5 seconds." )
		
		snixzz.Panic = true
		
		if snixzz.MenuOpen == true then
			
			snixzz.Frame:SetVisible( false )
			snixzz.MenuOpen = false
			
		end
		
		G.timer.Simple( 5, function()
		
			snixzz.Panic = false

			//snixzz.ACNotify( "Your visuals were disabled due to a screen grab detection." )
			
		end )
		
		return data
	end )

	file.Exists = snixzz.Detour( file.Exists, function( filename, dir )
		
		snixzz.LogDetour( "file.Exists( '" .. filename .. "', '" .. dir .. "' )" )
		
		if G.string.find( filename, "snixzz" ) then
			
			snixzz.ACNotify( "An anti-cheat attempted to search for snixzz" )
			return false
			
		else
		
			return snixzz.Detours[ file.Exists ]( filename, dir )
			
		end
		
	end )

	file.Read = snixzz.Detour( file.Read, function( filename, dir )

		snixzz.LogDetour( "file.Read( '" .. filename .. "', '" .. dir or "nil" .. "' )" )
		
		if G.string.find( filename, ".lua" ) then
			
			snixzz.ACNotify( "An anti-cheat attempted to search for a .lua file '" .. filename .. "'" )
			return "print( 'Hello World' )"
			
		else
			
			return snixzz.Detours[ file.Read ]( filename, dir )
			
		end
		
	end )

	file.Find = snixzz.Detour( file.Find, function( filename, dir )
		
		snixzz.LogDetour( "file.Find( '" .. filename .. "', '" .. dir .. "' )" )
		
		if G.string.find( filename, "snixzz" ) then 
			
			return G.table.Random( snixzz.AAC.FakeFiles )
		
		else
		
			return snixzz.Detours[ file.Find ]( filename, dir )
			
		end
		
	end )	

	net.Receive = snixzz.Detour( net.Receive, function( name, func )
			
		snixzz.LogDetour( "net.Receive( '" .. name .. "' )" )
		
		if snixzz.AAC.Receivers[name] then
			
			return snixzz.Detours[net.Receive]( name, snixzz.AAC.Receivers[name] )
			
		end
		
		return snixzz.Detours[ net.Receive ]( name, func )
	end )

	net.Start = snixzz.Detour( net.Start, function( name )
		
		if snixzz.Detours["net.Start"][name] then
			
			snixzz.ACNotify( "Blocked net.Start ( '" .. name .. "' )" )
			return
			
		else
		
			snixzz.LogDetour( "net.Start( '" .. name .. "' )" )
			return snixzz.Detours[ net.Start ]( name )
			
		end
		
	end )

	net.SendToServer = snixzz.Detour( net.SendToServer, function()
		
		snixzz.LogDetour( "net.SendToServer()" )
		
		return snixzz.Detours[net.SendToServer]()
	end )

	net.WriteString = snixzz.Detour( net.WriteString, function( str )
		
		if G.string.find( str, "snixzz" ) then
			
			snixzz.ACNotify( "Blocked net.WriteString ( '" .. str .. "' )" )
			return "nil"
			
		else
		
			snixzz.LogDetour( "net.WriteString( '" .. str .. "' )" )
			return snixzz.Detours[ net.WriteString ]( str )
			
		end
		
	end )

	net.WriteTable = snixzz.Detour( net.WriteTable, function( tab )
		
		if istable( tab ) then
					
			local sorted = G.table.concat( tab, ", " )
		
			snixzz.LogDetour( "net.WriteTable( { " .. sorted .. " } )" )
		
		end
		
		return snixzz.Detours[net.WriteTable]( tab )
		
	end )
	
	net.WriteInt = snixzz.Detour( net.WriteInt, function( int, size )
		
		snixzz.LogDetour( "net.WriteInt( " .. int .. ", " .. size .. " )" )
		
		return snixzz.Detours[net.WriteInt]( int, size )
		
	end )
	
	net.WriteBool = snixzz.Detour( net.WriteBool, function( bool )
		
		snixzz.LogDetour( "net.WriteBool( " .. tostring( bool ) .. " )" )
		
		return snixzz.Detours[net.WriteBool]( bool )
		
	end )
	
	net.WriteEntity = snixzz.Detour( net.WriteEntity, function( ent )
		
		if G.IsValid( ent ) then
		
			snixzz.LogDetour( "net.WriteEntity( " .. tostring( ent ) .. " )" )
			
		end
		
		return snixzz.Detours[net.WriteEntity]( ent )
		
	end )	
	
	_R.Player.ConCommand = snixzz.Detour( _R.Player.ConCommand, function( ply, args )

		snixzz.LogDetour( ply:Nick() .. " - _R.Player.ConCommand( '" .. args .. "' ) " )
		
		if !snixzz.Detours["Commands"][args] then
		
			return snixzz.Detours[ _R.Player.ConCommand ]( ply, args )
		
		else
			
			snixzz.ACNotify( "Blocked _R.Player.ConCommand( '" .. args .. "' )" )
			return
		
		end
		
	end )

	GetConVarNumber = snixzz.Detour( GetConVarNumber, function( cvar )
		
		if snixzz.Spoof[cvar] != nil then
			
			return snixzz.Spoof[cvar]
			
		else
			
			return snixzz.Detours[GetConVarNumber]( cvar )
			
		end
		
	end )

	snixzz.IgnoreCMDs = {
		["hvh_playheadshotsound"] = true,
		["hvh_hitsound"] = true,
		["r_cleardecals"] = true,
		["ulx_showmotd"] = true,
	}

	RunConsoleCommand = snixzz.Detour( RunConsoleCommand, function( cmd, ... )
		
		local str = cmd
		
		if !snixzz.IgnoreCMDs[cmd] then	
			
			if ... then
			
				local args = { ... }
				str = str .. ", " .. ( ... )
				
				snixzz.LogDetour( "RunConsoleCommand( '" .. cmd .. ", '" .. G.table.concat( args, "', '" ) .. "' )" )
				
			else
			
				snixzz.LogDetour( "RunConsoleCommand( '" .. cmd .. "' )")
				
			end
			
		end
		
		if !snixzz.Detours["Commands"][cmd] then
		
			return snixzz.Detours[ RunConsoleCommand ]( cmd, ... )
			
		else
			
			snixzz.ACNotify( "Blocked RunConsoleCommand( '" .. cmd .. "' )" )
			return
			
		end
		
	end )
	
	/*hook.GetTable = snixzz.Detour( hook.GetTable, function()
		
		return hookGetTableCopy
	end )*/
	
	IsFirstTimePredicted = snixzz.Detour( IsFirstTimePredicted, function()
	
		if snixzz.Predicting then
		
			return true
			
		end
		
		return snixzz.Detours[IsFirstTimePredicted]()
	
	end )
	
	pairs = snixzz.Detour( pairs, function( ... )
	
		local tab = { ... }
		
		local info = G.debug.getinfo( 2 )
		
		if info then
			
			local src = info.short_src
			
			if src:find( "cl_qac" ) then
				
				return snixzz.Detours[pairs]( { } )
				
			end
			
		end
		
		return snixzz.Detours[pairs]( G.unpack( tab ) )		
	
	end )
	
end

/*
	
	Menu Core
	
*/


/***************
	
	Changelog
	
****************/
snixzz.UpdateLog = "Loading..."

function snixzz.UpdateChangelog()
	
	G.http.Fetch( "http://snixzz.net/cheats/snixzz3/changelog.txt",
	
		function( body, len, headers, code )
			
			snixzz.UpdateLog = body
			
			if !G.file.Exists( snixzz.DataFolder .. "/changelog.txt", "DATA" ) then
				
				G.file.Write( snixzz.DataFolder .. "/changelog.txt", body )
				
				snixzz.Chat( Color( 0, 255, 0 ), "The changelog has been updated!" )
				
				snixzz.CMenu()
				
			else
				
				local log = G.file.Read( snixzz.DataFolder .. "/changelog.txt", "DATA" )
				
				if log != body then

					G.file.Write( snixzz.DataFolder .. "/changelog.txt", body )
					
					snixzz.Chat( Color( 0, 255, 0 ), "The changelog has been updated!" )
				
					snixzz.CMenu()	
					
				end
				
			end
			
		end,
		
		function( error )
			
			snixzz.UpdateLog = error
			snixzz.Chat( snixzz.Colors.Red, "Failed to update changelog '" .. error .. "'" )
			
		end
		
	)
	
end

function snixzz.CMenu()

	snixzz.CFrame = G.vgui.Create( "DFrame" )
	snixzz.CFrame:SetPos( 20, 80 )
	snixzz.CFrame:SetSize( 430, 420 )
	snixzz.CFrame:SetTitle( "snixzz3 " .. snixzz.Info.Version .. " Changelog :: by 0xymoron" )
	snixzz.CFrame:SetVisible( true )
	snixzz.CFrame:SetDraggable( true )
	snixzz.CFrame:ShowCloseButton( false )
	snixzz.CFrame:MakePopup()
	snixzz.CFrame.Paint = function() 
	
		G.draw.RoundedBox( 0, 0, 0, snixzz.CFrame:GetWide(), snixzz.CFrame:GetTall(), snixzz.Vars["misc_menucolor2"] )
		G.surface.SetDrawColor( Color( 0, 0, 0 ) )
		G.surface.DrawOutlinedRect( 0, 0, snixzz.CFrame:GetWide(), snixzz.CFrame:GetTall() )
		
	end
	
	local close = G.vgui.Create( "DButton", snixzz.CFrame )
	close:SetSize( 50, 20 )
	close:SetPos( snixzz.CFrame:GetWide() - 51, 1 )
	close:SetText( "x" )
	close:SetTextColor( G.Color( 255, 255, 255 ) )
	close:SetFont( "Trebuchet18" )
	
	close.Paint = function()
	
		G.draw.RoundedBox( 0, 0, 0, close:GetWide(), close:GetTall(), Color( 168, 62, 62, 255 ) )
	
	end
	
	close.DoClick = function()
		
		snixzz.CFrame:Close()
		snixzz.Sound()
		snixzz.CFrame = nil
		
	end
	
	local ChangelogText = G.vgui.Create( "DTextEntry", snixzz.CFrame )
	ChangelogText:SetPos( 5, 35 )
	ChangelogText:SetSize( snixzz.CFrame:GetWide() - 10, snixzz.CFrame:GetTall() - 40 )
	ChangelogText:SetText( snixzz.UpdateLog )
	ChangelogText:SetEditable( false )
	ChangelogText:SetMultiline( true )
	
end

/*
	
	snixzz3 "IRC" (Chatbox)
	
*/

local function urlencode( str ) -- thanks random github guy
  
	if ( str ) then
      
		str = string.gsub (str, "\n", "\r\n")
		
		str = string.gsub (str, "([^%w ])", function( c )
			
			return string.format( "%%%02X", string.byte( c ) )
			
		end )
		
		str = string.gsub ( str, " ", "+" )
		
   end
   
   return str    
   
end

function snixzz.GetChatData( ply, func )

	G.http.Fetch( "http://snixzz.net/cheats/snixzz3/data/chat.json",
		
		function( body )
		
			local tab = util.JSONToTable( body )
			
			snixzz.ChatCache = tab
			
			if func then
			
				return func()
				
			end
			
		end,
		
		function( error )
		
			snixzz.Chat( Color( 255, 0, 0 ), "Failed to get chat data." )
		
		end
		
	)

end

function snixzz.SendChatMessage( ply, msg, func )
	
	local oldMsg = msg
	
	msg = urlencode( msg )

	G.http.Fetch( "http://snixzz.net/cheats/snixzz3/chat.php?steamid=" .. ply:SteamID64() .. "&msg=" .. msg,
	
		function( body )
		
			if body != "sent" then
				
				snixzz.Chat( Color( 255, 0, 0 ), "Failed to send chat message. '" .. body .. "'" )
				
			else
				
				if func then
			
					func()
				
				end
				
				snixzz.AddToConsole( "Sent chat message '" .. oldMsg .. "'" )
				
			end
			
		end,
		
		function( error )
		
			snixzz.Chat( Color( 255, 0, 0 ), "Failed to send message, try again. '" .. error .. "'" )
			
		end
		
	)
	
end

function snixzz.UpdateChatbox( bool, func )

	if !snixzz.ChatDisplay then return end
	
	for k, v in G.next, snixzz.ChatCache do
				
		local nick = v["nick"]		
		local sid = v["sid"]
		local message = v["message"]
		
		if !snixzz.ChatHistory[sid] then
		
			snixzz.ChatHistory[sid] = {}

		end
		
		if !G.table.HasValue( snixzz.ChatHistory[sid], message ) or bool == true then	
			
			if sid == "nil" then
					
				snixzz.ChatDisplay:InsertColorChange( 255, 0, 0, 255 )
					
			elseif sid == "76561198040553376" then
			
				snixzz.ChatDisplay:InsertColorChange( 0, 255, 255, 255 )
			
			else
			
				snixzz.ChatDisplay:InsertColorChange( 185, 185, 185, 255 )
				
			end 
			
			snixzz.ChatDisplay:AppendText( nick )
			
			snixzz.ChatDisplay:InsertColorChange( 255, 255, 255, 255 )
			snixzz.ChatDisplay:AppendText( ": " .. message .. "\n" )
			
			if bool == false then
				
				snixzz.Sound()
				
			end
		
			G.table.insert( snixzz.ChatHistory[sid], message )

		end
			
	end
		
	if func then
			
		func()
			
	end

end

function snixzz.UpdateWhosOnline( bool, func )

	if !snixzz.IsVIP() then return end
	
	G.http.Fetch( "http://snixzz.net/cheats/snixzz3/getonline.php", 
	
		function( body )
			
			snixzz.WhosOnline = G.util.JSONToTable( body )

			if func then
				
				func()
				
			end
			
		end,
		
		function( error )
			
			snixzz.WhosOnline = { ["fail"] = "Failed to update" }
		
		end
		
	)
	
end

snixzz.ChatboxOpen = false
snixzz.ChatUpdateData = 0
snixzz.WhosOnline = {}

function snixzz.OpenChat()
	
	if snixzz.Chatbox && snixzz.Chatbox:IsVisible() or snixzz.ChatboxOpen then return end
	
	snixzz.Chatbox = G.vgui.Create( "DFrame" )
	snixzz.Chatbox:SetTitle( "snixzz3 Chat (Experimental)" )
	snixzz.Chatbox:SetSize( 600, 240 )
	snixzz.Chatbox:SetPos( 20, ScrH() / 2 - snixzz.Chatbox:GetTall() )
	snixzz.Chatbox:ShowCloseButton( true )
	snixzz.Chatbox:SetDraggable( true )
	
	snixzz.Chatbox.Paint = function( self )
	
		G.draw.RoundedBox( 0, 0, 0, self:GetWide(), self:GetTall(), Color( 0, 0, 0, 150 ) )
		G.surface.SetDrawColor( Color( 0, 0, 0 ) )
		G.surface.DrawOutlinedRect( 0, 0, self:GetWide(), self:GetTall() )
	
	end
	
	snixzz.Chatbox.Think = function( self )
		
		snixzz.ChatUpdateData = snixzz.ChatUpdateData + 1
		
		if snixzz.ChatUpdateData == 3300 then
			
			snixzz.GetChatData( LocalPlayer(), function()
			
				snixzz.UpdateChatbox( false, function()
				
					snixzz.ChatUpdateData = 0
					
				end )
				
			end )
			
		end
		
		if G.input.IsKeyDown( KEY_ESCAPE ) then
			
			self:Close()
			
		end
		
	end
	
	snixzz.Chatbox.OnClose = function( self )

		snixzz.ChatHistory = {}
		snixzz.ChatCache = {}
		snixzz.ChatboxOpen = false
		
		if snixzz.OnlineFrame && snixzz.OnlineFrame:IsVisible() then
		
			snixzz.OnlineFrame:SetVisible( false )
			snixzz.OnlineFrame = nil
		
		end
		
	end
	
	snixzz.ChatEntry = vgui.Create( "DTextEntry", snixzz.Chatbox )
	snixzz.ChatEntry:SetPos( 5, snixzz.Chatbox:GetTall() - 25 )
	snixzz.ChatEntry:SetSize( snixzz.Chatbox:GetWide() - 35, 20 )
		
	snixzz.ChatEntry.OnEnter = function( self )
		
		local oldMsg = self:GetValue()
		
		if oldMsg == "" then snixzz.Chatbox:Close() return end
		
		self:SetEnabled( false )
		self:SetEditable( false )
		
		self:SetText( "Sending message..." )
		
		snixzz.SendChatMessage( LocalPlayer(), oldMsg, function() 
			
			self:SetText( "Updating chat..." )
			
			snixzz.GetChatData( LocalPlayer(), function()
			
				snixzz.UpdateChatbox( false, function()
					
					self:SetText( "Sent! Please wait 10 seconds before sending another message." )
					
					G.timer.Simple( 10, function() if IsValid( self ) then self:SetEnabled( true ) self:SetEditable( true ) self:SetText( "" ) end end )
					
				end )
			
			end )
			
		end )
		
	end	
	
	snixzz.ChatDisplay = vgui.Create( "RichText", snixzz.Chatbox )
	snixzz.ChatDisplay:SetPos( 5, 25 )
	snixzz.ChatDisplay:SetSize( snixzz.Chatbox:GetWide() - 10, snixzz.Chatbox:GetTall() - 45 )

	snixzz.ChatDisplay.PerformLayout = function( self )
	
		self:SetFontInternal( "ChatFont" )
	
	end

	snixzz.GetChatData( LocalPlayer(), function()
		
		snixzz.UpdateChatbox( true, function()
			
			snixzz.Chatbox:MakePopup()
			
			snixzz.ChatboxOpen = true
			
		end )
		
	end )
	
	if snixzz.IsVIP() then
	
		snixzz.UpdateWhosOnline( true, function()
			
			if !snixzz.Chatbox:IsVisible() then return end
			
			snixzz.OnlineFrame = G.vgui.Create( "DFrame" )
			snixzz.OnlineFrame:SetSize( 200, 120 )
			snixzz.OnlineFrame:SetTitle( "Online Users (" .. table.Count( snixzz.WhosOnline ) .. ")" )
			snixzz.OnlineFrame:SetPos( 20, ScrH() / 2 - snixzz.Chatbox:GetTall() - snixzz.OnlineFrame:GetTall() - 10 )
			snixzz.OnlineFrame:ShowCloseButton( false )
			snixzz.OnlineFrame:SetDraggable( false )
			
			snixzz.OnlineFrame.Paint = function( self )
			
				G.draw.RoundedBox( 0, 0, 0, self:GetWide(), self:GetTall(), Color( 0, 0, 0, 125 ) )
				G.surface.SetDrawColor( Color( 0, 0, 0 ) )
				G.surface.DrawOutlinedRect( 0, 0, self:GetWide(), self:GetTall() )
			
			end
			
			snixzz.OnlineList = G.vgui.Create( "DListLayout", snixzz.OnlineFrame )
			snixzz.OnlineList:SetPos( 5, 25 )
			snixzz.OnlineList:SetSize( snixzz.OnlineFrame:GetWide() - 10, snixzz.OnlineFrame:GetTall() - 35 )

			
			if table.Count( snixzz.WhosOnline ) >= 1 then
			
				for k, v in G.next, snixzz.WhosOnline do
					
					local pButton = snixzz.OnlineList:Add( "DButton" )
					pButton:SetText( v )
					pButton:SetSize( snixzz.OnlineList:GetWide() - 10, 15 )
					pButton:SetTextColor( color_white )
					pButton:SetFont( "ChatFont" )

					pButton.Paint = function( self )
						
						G.draw.RoundedBox( 0, 0, 0, self:GetWide(), self:GetTall(), Color( 0, 0, 0, 50 ) )
						G.surface.SetDrawColor( color_white )
						G.surface.DrawOutlinedRect( 0, 0, self:GetWide(), self:GetTall() )
						
					end
					
					pButton.DoClick = function( self )
					
						gui.OpenURL( "http://steamcommunity.com/profiles/" .. util.NiceFloat( k ) )
					
					end
					
				end
				
			else
				
				local pButton = snixzz.OnlineList:Add( "DButton" )
				pButton:SetText( "No one :(" )
				pButton:SetSize( snixzz.OnlineList:GetWide() - 10, 15 )
				pButton:SetTextColor( Color( 255, 0, 0 ) )
				pButton:SetFont( "ChatFont" )

				pButton.Paint = function( self )
						
					G.draw.RoundedBox( 0, 0, 0, self:GetWide(), self:GetTall(), Color( 0, 0, 0, 50 ) )
					G.surface.SetDrawColor( Color( 255, 0, 0 ) )
					G.surface.DrawOutlinedRect( 0, 0, self:GetWide(), self:GetTall() )
						
				end
				
			end
				
		
		end )
	
	end

end

/*
	
	
	Custom Console

	
*/

snixzz.Cmds = {}

snixzz.CmdDesc = {

	["bind"] = "bind: proper usage: bind <key> <command>",
	["unbind"] = "unbind: proper usage: unbind <command>",
	["binds"] = "binds: Displays a list of bindable commands",
	["convars"] = "convars: Displays a list of changable convars",
	["server"] = "server: Displays server information",
	["players"] = "players: Displays a list of players & SteamIDs",
	["lua_run"] = "lua_run: Run a Lua string",
	["connect"] = "connect: Connect to the provided IP",
	["clear"] = "clear: Clears the console",
	
}

function snixzz.ConsoleCommand( str )
	
	if !snixzz.ConFrame then return end
	
	local args = G.string.Explode( " ", str )
	local cmd = args[1]
	local cmdArgs = args[2]
	
	G.table.remove( args, 1 )
	
	snixzz.AddToConsole( "] " .. str )
	
	-- Console Commands
	if snixzz.Cmds[cmd] then
		
		snixzz.Cmds[cmd]( G.LocalPlayer(), cmd, args )
		
	-- ConVars
	elseif snixzz.Bools[cmd] != nil then
		
		cmdArgs = G.tobool( cmdArgs )
		
		if cmdArgs != nil then 
		
			snixzz.Bools[cmd] = cmdArgs
			snixzz.Chat( snixzz.Colors.Green, "Set ConVar '" .. cmd .. "' to '" .. G.tostring( cmdArgs ) .. "'" )
			
		else
		
			snixzz.Chat( snixzz.Colors.Red, "Failed to set ConVar '" .. cmd .. "' to '" .. G.tostring( cmdArgs ) or "nil" )
			
		end
			
	elseif snixzz.Vars[cmd] != nil then
		
		if cmdArgs != nil then
			
			snixzz.Vars[cmd] = cmdArgs
			snixzz.Chat( snixzz.Colors,Green, "Set ConVar '" .. cmd .. "' to '" .. G.tostring( cmdArgs ) .. "'" )
			
		else
			
			snixzz.Chat( snixzz.Colors.Red, "Failed to set ConVar '" .. cmd .. "' to '" .. G.tostring( cmdArgs ) or "nil" )
			
		end
		
	elseif cmd == "lua_run" then
		
		local lua_String = G.string.gsub( str, "lua_run ", "" )
		
		snixzz.AddToConsole( "Running Lua String '" .. lua_String .. "'" )
		
		snixzz.RunString( lua_String )
	
	elseif cmd == "name" then
	
		local name_str = G.string.gsub( str, "name ", "" )
		
		snixzz.AddToConsole( "Attempting to change name to '" .. name_str .. "'" )
		
		snixzz.Functions.SetName( string.len( name_str ), name_str )
	
	else
	
		snixzz.AddToConsole( "Unknown command '" .. cmd .. "'" )
		
	end
	
	snixzz.cEntry:SetText( "" )
	
end

function snixzz.AddConsoleCommand( cmd, func )

	snixzz.Cmds[cmd] = func
	
end

snixzz.AddConsoleCommand( "help", function( ply, cmd, args )

	for k, v in G.next, snixzz.Cmds do
		
		snixzz.AddToConsole( snixzz.CmdDesc[k] )
		
	end
	
end )

snixzz.AddConsoleCommand( "ping", function( ply, cmd, args )

	if snixzz.Membership == "dev" then
	
		snixzz.PingServer( ply )
		
	else
		
		snixzz.AddToConsole( "You must be a developer to use this command." )
		
	end

end )

snixzz.AddConsoleCommand( "chat", function( ply, cmd, args )

	/*if snixzz.ConFrame then
		
		snixzz.ConsoleOpen = false
		snixzz.ConFrame:Remove()
		
	end

	snixzz.OpenChat()*/
	snixzz.AddToConsole( "Chat has been temporarily disabled." )

end )


snixzz.AddConsoleCommand( "say", function( ply, cmd, args )

	if snixzz.Membership == "dev" then
	
		snixzz.SendChatMessage( ply, tostring( table.concat( args, " " ) ) )
		
	else
		
		snixzz.AddToConsole( "You must be a developer to use this command." )
		
	end

end )

snixzz.AddConsoleCommand( "bind", function( ply, cmd, args )

	if !args[1] or !args[2] then snixzz.AddToConsole( snixzz.CmdDesc["bind"] ) return end

	local key = "KEY_" .. G.string.upper( args[1] )
	local cmd = args[2]
	
	snixzz.BindKey( cmd, key, true )

end )

snixzz.AddConsoleCommand( "unbind", function( ply, cmd, args )
	
	if !args[1] then snixzz.AddToConsole( "Unbind proper usage: unbind <command>" ) return end
	
	local command = args[1]
	
	snixzz.Unbind( command )
	
end )

snixzz.AddConsoleCommand( "convars", function( ply, cmd, args )
	
	for k, v in G.next, snixzz.Bools do
		
		snixzz.AddToConsole( "ConVar: " .. k .. " | Enabled: " .. G.tostring( v ) )
		
	end
	
	for k, v in G.next, snixzz.Vars do
		
		snixzz.AddToConsole( "ConVar: " .. k .. " | Value: " .. G.tostring( v ) )
		
	end

end )

snixzz.AddConsoleCommand( "binds", function( ply, cmd, args )
	
	for k, v in G.next, snixzz.Binds do
		
		snixzz.AddToConsole( "Command: " .. k .. " | Bound to: " .. G.input.GetKeyName( v )	)
		
	end
	
end )

snixzz.AddConsoleCommand( "clear", function( ply, cmd, args )
	
	if snixzz.ConFrame && snixzz.cHistory then
		
		snixzz.cHistory:Clear()
		
	end
	
	snixzz.ConsoleHistory = {}
	
	snixzz.AddToConsole( "Cleared console history." )
	
end )

snixzz.AddConsoleCommand( "connect", function( ply, cmd, args )
	
	if args[1] != nil then
	
		snixzz.AddToConsole( "Connecting to '" .. args[1] .. "'" )
		
		G.RunConsoleCommand( "connect", args[1] )
		
	else
		
		snixzz.AddToConsole( "Unknown IP" )
		
	end
	
end )

snixzz.ConsoleOpen = false

function snixzz.Console()
	
	snixzz.ConFrame = G.vgui.Create( "DFrame" )
	snixzz.ConFrame:SetSize( 700, 450 )
	snixzz.ConFrame:SetPos( 30, 30 )
	snixzz.ConFrame:SetTitle( "snixzz3 Console :: by 0xymoron" )
	snixzz.ConFrame:ShowCloseButton( false )
	snixzz.ConFrame:MakePopup()
	snixzz.ConFrame.Paint = function( self ) 
	
		G.draw.RoundedBox( 0, 0, 0, self:GetWide(), self:GetTall(), snixzz.Vars["misc_menucolor2"] )
		G.surface.SetDrawColor( Color( 0, 0, 0 ) )
		G.surface.DrawOutlinedRect( 0, 0, self:GetWide(), self:GetTall() )
		
	end
	snixzz.ConFrame.Think = function( self )
		
		if G.input.IsKeyDown( KEY_ESCAPE ) then
		
			snixzz.ConsoleOpen = false
			self:Remove()
			
		end
		
	end	
	
	local close = G.vgui.Create( "DButton", snixzz.ConFrame )
	close:SetSize( 50, 20 )
	close:SetPos( snixzz.ConFrame:GetWide() - 51, 1 )
	close:SetText( "x" )
	close:SetTextColor( G.Color( 255, 255, 255 ) )
	close:SetFont( "Trebuchet18" )
	
	close.Paint = function( self )
	
		G.draw.RoundedBox( 0, 0, 0, self:GetWide(), self:GetTall(), G.Color( 168, 62, 62, 255 ) )
	
	end
	
	close.DoClick = function()
		
		snixzz.ConsoleOpen = false
		snixzz.ConFrame:Remove()
		snixzz.Sound()
		
	end
	
	snixzz.cHistory = G.vgui.Create( "DListView", snixzz.ConFrame )
	snixzz.cHistory:SetPos( 5, 27 )
	snixzz.cHistory:SetSize( 690, 397 )
	snixzz.cHistory:SetSortable( false )
	snixzz.cHistory:AddColumn( "" )
	snixzz.cHistory:SetMultiSelect( false )

	for k, v in pairs( snixzz.ConsoleHistory ) do
		
		snixzz.cHistory:AddLine( v )
		
	end
	
	snixzz.cHistory.OnClickLine = function( prnt, line, self )
	
		G.SetClipboardText( line:GetValue( 1 ) )
		
		snixzz.Chat( snixzz.Colors.Green, "Copied selected line to clipboard.", true )
		
	end
	
	snixzz.cHistory:PerformLayout()
	snixzz.cHistory.VBar:SetScroll( snixzz.cHistory.VBar.CanvasSize )
	
	-- command entry
	snixzz.cEntry = G.vgui.Create( "DTextEntry", snixzz.ConFrame )
	snixzz.cEntry:SetMultiline( false )
	snixzz.cEntry:SetSize( 690, 20 )
	snixzz.cEntry:SetPos( 5, 427 )
	
	snixzz.cEntry.OnEnter = function( self )
		
		snixzz.ConsoleCommand( self:GetValue() )
		
	end
	
	snixzz.cEntry.Think = function( self )
		
		self:RequestFocus()
		
	end
	
end

snixzz.MenuToggle = false

function snixzz.DoMenuToggle()
	
	snixzz.MenuOpen = true
	snixzz.Frame:SetVisible( true )
	
end

function snixzz.Menu()

	local tabs, menuheight, menuwidth, w, h = {}, 430, 420, ScrW() / 2, ScrH() / 2
	
	snixzz.Frame = G.vgui.Create( "DPropertySheet" )
	snixzz.Frame:SetParent( snixzz.Frame )
	snixzz.Frame:SetPos( 20, 80 )
	snixzz.Frame:SetSize( menuwidth, menuheight )
	snixzz.Frame:SetVisible( true )
	snixzz.Frame:MakePopup()
	snixzz.Frame.Think = function()
		
		if snixzz.Binds["+menu"] == nil then return end
		
		/*if !G.input.IsKeyDown( snixzz.Binds["+menu"] )*/if !snixzz.DoBind( "+menu" ) && !snixzz.MenuToggle then
		
			snixzz.MenuOpen = false
			//snixzz.Changelog:SetVisible( false )
			//snixzz.LinksButton:SetVisible( false )
			snixzz.Frame:SetVisible( false )
			
		end
		
	end	
	snixzz.Frame.Paint = function() 
		
		G.draw.RoundedBox( 0, 0, 30, snixzz.Frame:GetWide(), snixzz.Frame:GetTall(), snixzz.Vars["misc_menucolor"] )
		G.surface.SetDrawColor( Color( 0, 0, 0 ) )
		G.surface.DrawOutlinedRect( 0, 0, snixzz.Frame:GetWide(), snixzz.Frame:GetTall() )
		
	end
	
	-- Menu Toggle button
	local Toggle = G.vgui.Create( "DButton" )
	Toggle:SetParent( snixzz.Frame )
	Toggle:SetText( "Hold Open" )
	Toggle:SetTextColor( snixzz.Colors.Green )
	Toggle:SetPos( 0, 0 )
	Toggle:SetPos( snixzz.Frame:GetWide() - 60, 0 )
	Toggle:SetSize( 60, 30 )
	Toggle.DoClick = function()
		
		snixzz.MenuToggle = !snixzz.MenuToggle
		snixzz.DoMenuToggle()
		
		if snixzz.MenuToggle == true then
			
			Toggle:SetText( "Close" )
			Toggle:SetTextColor( Color( 255, 255, 0 ) )
			snixzz.Sound()
			
		else
			
			Toggle:SetText( "Hold Open" )
			Toggle:SetTextColor( snixzz.Colors.Green )
			snixzz.Sound()
			
		end
		
	end
	Toggle.Paint = function() 
		
		G.surface.SetDrawColor( Color( 0, 0, 0 ) )
		G.surface.DrawOutlinedRect( 0, 0, Toggle:GetWide(), Toggle:GetTall() )
		
	end

	/*snixzz.LinksButton = G.vgui.Create( "DButton" )
	snixzz.LinksButton:SetText( "Links" )
	snixzz.LinksButton:SetPos( snixzz.Frame:GetWide() - 205, 60 )
	snixzz.LinksButton:SetSize( 35, 18 )
	snixzz.LinksButton:SetFont( "snixzz_logo_small" )
	snixzz.LinksButton:SetTextColor( color_white )
	
	snixzz.LinksButton.DoClick = function()
		
		if !snixzz.linksMenu then
		
			snixzz.Sound()
			snixzz.OpenLinksMenu()
			
		end
		
	end
	snixzz.LinksButton.Paint = function() 
		
		G.surface.SetDrawColor( Color( 0, 0, 0 ) )
		G.surface.DrawOutlinedRect( 0, 0, snixzz.LinksButton:GetWide(), snixzz.LinksButton:GetTall() )
		
	end*/

	-- Parents for the tabs
	tabs.aimbot = G.vgui.Create( "DLabel", snixzz.Frame )
	tabs.aimbot:SetPos( 0, 0 )
	tabs.aimbot:SetText( "" )

	tabs.esp = G.vgui.Create( "DLabel", snixzz.Frame )
	tabs.esp:SetPos( 0, 0 )
	tabs.esp:SetText( "" )

	tabs.misc = G.vgui.Create( "DLabel", snixzz.Frame )
	tabs.misc:SetPos( 0, 0 )
	tabs.misc:SetText( "" )
	
	tabs.lists = G.vgui.Create( "DLabel", snixzz.Frame )
	tabs.lists:SetPos( 0, 0 )
	tabs.lists:SetText( "" )

	tabs.log = G.vgui.Create( "DLabel", snixzz.Frame )
	tabs.log:SetPos( 0, 0 )
	tabs.log:SetText( "" )

	tabs.config = G.vgui.Create( "DLabel", snixzz.Frame )
	tabs.config:SetPos( 0, 0 )
	tabs.config:SetText( "" )
	
	snixzz.Frame:AddSheet( "Aimbot", tabs.aimbot, "icon16/lightning.png", false, false )
	snixzz.Frame:AddSheet( "Visual", tabs.esp, "icon16/eye.png", false, false )
	snixzz.Frame:AddSheet( "Misc", tabs.misc, "icon16/plugin.png", false, false )
	snixzz.Frame:AddSheet( "Lists", tabs.lists, "icon16/user_add.png", false, false )
	snixzz.Frame:AddSheet( "Detours", tabs.log, "icon16/application_xp_terminal.png", false, false )
	snixzz.Frame:AddSheet( "Config", tabs.config, "icon16/wrench.png", false, false )

	-- Aimbot Settings
	snixzz.CreateOption( "Checkbox", tabs.aimbot, "Aimbot Toggle", "aim_toggle", 5, 5 )
	snixzz.CreateOption( "Checkbox", tabs.aimbot, "Autoshoot", "aim_autoshoot", 5, 25 )
	snixzz.CreateOption( "Checkbox", tabs.aimbot, "Silent Aim", "aim_silent", 5, 45 )
	snixzz.CreateOption( "Checkbox", tabs.aimbot, "Spread Prediction", "aim_nospread", 5, 65 )
	snixzz.CreateOption( "Checkbox", tabs.aimbot, "Aim Prediction", "aim_prediction", 5, 85 )
	snixzz.CreateOption( "Checkbox", tabs.aimbot, "Remove Recoil", "aim_norecoil", 5, 105 )
	snixzz.CreateOption( "Checkbox", tabs.aimbot, "Miss random shots", "aim_badshots", 5, 125 )	
	snixzz.CreateOption( "Checkbox", tabs.aimbot, "Hold Target", "aim_holdtarget", 5, 145 )	
	snixzz.CreateOption( "Checkbox", tabs.aimbot, "Constant NoSpread", "aim_constant_nospread", 5, 165 )
	//snixzz.CreateOption( "Checkbox", tabs.aimbot, "Smooth Aiming", "aim_smooth", 5, 165 )	
	
	snixzz.CreateOption( "Checkbox", tabs.aimbot, "Ignore Team", "aim_ignoreteam", 130, 5 )
	snixzz.CreateOption( "Checkbox", tabs.aimbot, "Ignore Admins", "aim_ignoreadmins", 130, 25 )
	snixzz.CreateOption( "Checkbox", tabs.aimbot, "Ignore Steam Friends", "aim_ignoresteam", 130, 45 )
	snixzz.CreateOption( "Checkbox", tabs.aimbot, "Ignore Bots", "aim_ignorebots", 130, 65 )
	snixzz.CreateOption( "Checkbox", tabs.aimbot, "Ignore LOS", "aim_ignorelos", 130, 85 )
	snixzz.CreateOption( "Checkbox", tabs.aimbot, "Ignore Friends", "aim_ignorefriends", 130, 105 )
	snixzz.CreateOption( "Checkbox", tabs.aimbot, "Target Only Friends", "aim_targetonlyfriends", 130, 125 )
	snixzz.CreateOption( "Checkbox", tabs.aimbot, "Ignore Friendly Traitors", "aim_ignoretraitors", 130, 145 )
	snixzz.CreateOption( "Checkbox", tabs.aimbot, "Target Only Traitors", "aim_onlytraitors", 130, 165 )
	
	snixzz.CreateOption( "Checkbox", tabs.aimbot, "Anti Anti-Aim", "aim_antiantiaim", 275, 5 )
	snixzz.CreateOption( "Checkbox", tabs.aimbot, "Anti-Aim", "aim_anti", 275, 25 )
	snixzz.CreateOption( "Checkbox", tabs.aimbot, "Check CanFire", "aim_canfire", 275, 45 )
	
	snixzz.CreateOption( "Slider", tabs.aimbot, "Spinbot Speed", "aim_anti_spin_speed", 10, 50, 420, 5, 325, 0 )
	snixzz.CreateOption( "Slider", tabs.aimbot, "Field of View", "aim_fov", 1, 180, 420, 5, 345, 0 )
	snixzz.CreateOption( "Slider", tabs.aimbot, "Aimspot Offset", "aim_offset", -20, 20, 425, 5, 365, 0 )
	
	
	snixzz.CreateOption( "Label", tabs.aimbot, "Prediction Method", 115, 250 )
	
	local PredictionMethod = G.vgui.Create( "DComboBox", tabs.aimbot )
	PredictionMethod:SetPos( 115, 265 )
	PredictionMethod:SetSize( 105, 20 )
	PredictionMethod:SetText( snixzz.Vars["aim_prediction_method"] )
	PredictionMethod:SetTextColor( color_white )
	
	for k, v in G.next, snixzz.PredictionMethods do
		
		PredictionMethod:AddChoice( v )
		
	end
	
	PredictionMethod.OnSelect = function( self )
		
		snixzz.Vars["aim_prediction_method"] = self:GetValue()
		snixzz.Chat( Color( 0, 255, 255 ), "Set prediction method to '" .. self:GetValue() .. "'" )
		snixzz.Sound()
		
	end	
	
	PredictionMethod.Paint = function() 
		
		G.surface.SetDrawColor( Color( 0, 0, 0 ) )
		G.surface.DrawOutlinedRect( 0, 0, PredictionMethod:GetWide(), PredictionMethod:GetTall() )
		
	end
	
	snixzz.CreateOption( "Label", tabs.aimbot, "Target Type", 225, 250 )
	
	local TargetType = G.vgui.Create( "DComboBox", tabs.aimbot )
	TargetType:SetPos( 225, 265 )
	TargetType:SetSize( 105, 20 )
	TargetType:SetText( snixzz.Vars["aim_target_type"] )
	TargetType:SetTextColor( color_white )
	
	for k, v in G.next, { "Players", "NPC", "Both" } do
		
		TargetType:AddChoice( v )
		
	end
	
	TargetType.OnSelect = function( self )
		
		snixzz.Vars["aim_target_type"] = self:GetValue()
		snixzz.Chat( Color( 0, 255, 255 ), "Set target type to '" .. self:GetValue() .. "'" )
		snixzz.Sound()
		
	end	
	
	TargetType.Paint = function() 
		
		G.surface.SetDrawColor( Color( 0, 0, 0 ) )
		G.surface.DrawOutlinedRect( 0, 0, TargetType:GetWide(), TargetType:GetTall() )
		
	end
	
	// AntiAim Method
	snixzz.CreateOption( "Label", tabs.aimbot, "Anti-Aim Method", 5, 250 )
	local AntiAimMethod = G.vgui.Create( "DComboBox", tabs.aimbot )
	AntiAimMethod:SetPos( 5, 265 )
	AntiAimMethod:SetSize( 105, 20 )
	AntiAimMethod:SetText( snixzz.Vars["aim_anti_method"] )
	AntiAimMethod:SetTextColor( color_white )
	
	for k, v in G.next, snixzz.AntiAimMethods do
		
		AntiAimMethod:AddChoice( v )
		
	end
	
	AntiAimMethod.OnSelect = function( self )
		
		snixzz.Vars["aim_anti_method"] = self:GetValue()
		snixzz.Chat( Color( 0, 255, 255 ), "Set anti-aim method to '" .. self:GetValue() .. "'" )
		snixzz.Sound()
		
	end
	
	AntiAimMethod.Paint = function() 
		
		G.surface.SetDrawColor( Color( 0, 0, 0 ) )
		G.surface.DrawOutlinedRect( 0, 0, AntiAimMethod:GetWide(), AntiAimMethod:GetTall() )
		
	end

	-- Aimbot hitbox/bone method & spot selection
	snixzz.CreateOption( "Label", tabs.aimbot, "Aimbot Method", 5, 290 )

	local AimbotMethod = G.vgui.Create( "DComboBox", tabs.aimbot )
	AimbotMethod:SetPos( 5, 305 )
	AimbotMethod:SetSize( 105, 20 )
	AimbotMethod:SetText( snixzz.Vars["aim_method"] )
	AimbotMethod:AddChoice( "Hitbox" )
	AimbotMethod:AddChoice( "Bone" )
	AimbotMethod:AddChoice( "Hitscan" )
	AimbotMethod:SetTextColor( color_white )
	AimbotMethod.OnSelect = function( self )
		
		snixzz.Vars["aim_method"] = self:GetValue()
		snixzz.Chat( Color( 0, 255, 255 ), "Set aimbot method to '" .. self:GetValue() .. "'" )
		snixzz.Sound()
		
		 -- Close to menu to avoid bugs.
		snixzz.Frame:SetVisible( false )
		//snixzz.Changelog:SetVisible( false )
		//snixzz.LinksButton:SetVisible( false )
		snixzz.MenuOpen = false
		snixzz.MenuToggle = false
		
	end
	
	AimbotMethod.Paint = function() 
		
		G.surface.SetDrawColor( Color( 0, 0, 0 ) )
		G.surface.DrawOutlinedRect( 0, 0, AimbotMethod:GetWide(), AimbotMethod:GetTall() )
		
	end
	
	-- Aimspot & aim method selection
	snixzz.CreateOption( "Label", tabs.aimbot, "Aim Spot", 115, 290 )
	
	local Aimspot = G.vgui.Create( "DComboBox", tabs.aimbot )
	Aimspot:SetPos( 115, 305 )
	Aimspot:SetSize( 105, 20 )
	Aimspot:SetTextColor( color_white )
	
	if snixzz.Vars["aim_method"] == "Hitbox" then
		
		Aimspot:SetText( snixzz.Vars["aim_hitbox"] )
		
		Aimspot:SetDisabled( false )
		
		for k, v in G.next, snixzz.Hitboxes do
			
			Aimspot:AddChoice( k )
			
		end
		
	elseif snixzz.Vars["aim_method"] == "Bone" then
	
		Aimspot:SetText( snixzz.Vars["aim_bone"] )
		
		Aimspot:SetDisabled( false )
		
		for k, v in G.next, snixzz.Bones do
			
			Aimspot:AddChoice( k )
			
		
		end
		
	elseif snixzz.Vars["aim_method"] == "Hitscan" then
	
		Aimspot:SetText( "Auto" )
		Aimspot:SetDisabled( true )
		
	end
	
	Aimspot.OnSelect = function( self )
		
		if snixzz.Vars["aim_method"] == "Hitbox" then
		
			snixzz.Vars["aim_hitbox"] = self:GetValue()
			snixzz.Chat( Color( 0, 255, 255 ), "Set aimbot hitbox to '" .. self:GetValue() .. "'" )
			
		elseif snixzz.Vars["aim_method"] == "Bone" then
		
			snixzz.Vars["aim_bone"] = self:GetValue()
			snixzz.Chat( Color( 0, 255, 255 ), "Set aimbot bone to '" .. self:GetValue() .. "'" )

		end
		
		snixzz.Sound()
	end
	
	Aimspot.Paint = function() 
		
		G.surface.SetDrawColor( Color( 0, 0, 0 ) )
		G.surface.DrawOutlinedRect( 0, 0, Aimspot:GetWide(), Aimspot:GetTall() )
		
	end
	
	// Target method
	snixzz.CreateOption( "Label", tabs.aimbot, "Target Method", 225, 290 )
	
	local TargetMethod = G.vgui.Create( "DComboBox", tabs.aimbot )
	TargetMethod:SetPos( 225, 305 )
	TargetMethod:SetSize( 105, 20 )
	TargetMethod:SetText( snixzz.Vars["aim_target_method"] )
	TargetMethod:SetTextColor( color_white )
	TargetMethod:AddChoice( "Distance" )
	TargetMethod:AddChoice( "Closest" )
	TargetMethod:AddChoice( "Crosshair" )
	TargetMethod.OnSelect = function( self )
	
		snixzz.Vars["aim_target_method"] = self:GetValue()
		snixzz.Chat( Color( 0, 255, 255 ), "Set target method to '" .. self:GetValue() .. "'" )
		snixzz.Sound()
		
	end	
	
	TargetMethod.Paint = function() 
	
		G.surface.SetDrawColor( Color( 0, 0, 0 ) )
		G.surface.DrawOutlinedRect( 0, 0, TargetMethod:GetWide(), TargetMethod:GetTall() )
		
	end

	-- Visual Settings
	snixzz.CreateOption( "Checkbox", tabs.esp, "Enable Visuals", "esp_enabled", 5, 5 )
	snixzz.CreateOption( "Checkbox", tabs.esp, "Name Text", "esp_name", 5, 45 )
	snixzz.CreateOption( "Checkbox", tabs.esp, "Health Text", "esp_health_text", 5, 65 )
	snixzz.CreateOption( "Checkbox", tabs.esp, "Weapon Text", "esp_weapon", 5, 85 )
	snixzz.CreateOption( "Checkbox", tabs.esp, "Distance Text", "esp_distance", 5, 105 )
	snixzz.CreateOption( "Checkbox", tabs.esp, "Bounding Box", "esp_box", 5, 125 )
	snixzz.CreateOption( "Checkbox", tabs.esp, "Chams", "esp_chams", 5, 145 )
	snixzz.CreateOption( "Checkbox", tabs.esp, "Health Bar", "esp_health_bar", 5, 165 )
	snixzz.CreateOption( "Checkbox", tabs.esp, "Hitbox ESP", "esp_hitbox", 5, 185 )

	snixzz.CreateOption( "Checkbox", tabs.esp, "Crosshair", "esp_crosshair", 130, 5 )
	snixzz.CreateOption( "Checkbox", tabs.esp, "Crosshair Box", "esp_crosshair_box", 130, 25 )
	snixzz.CreateOption( "Checkbox", tabs.esp, "Remove Hands", "esp_nohands", 130, 45 )
	snixzz.CreateOption( "Checkbox", tabs.esp, "Aimbot Status", "esp_status", 130, 65 )
	snixzz.CreateOption( "Checkbox", tabs.esp, "Laser Sights", "esp_laser", 130, 85 )
	snixzz.CreateOption( "Checkbox", tabs.esp, "Aim Snaplines", "esp_snaplines", 130, 105 )
	snixzz.CreateOption( "Checkbox", tabs.esp, "Dynamic Light", "esp_dynamiclight", 130, 125 )
	snixzz.CreateOption( "Checkbox", tabs.esp, "Wireframe Weapon", "esp_wireweapon", 130, 145 )
	snixzz.CreateOption( "Checkbox", tabs.esp, "Draw Aimbot Position", "esp_aimpos", 130, 165 )	
	snixzz.CreateOption( "Checkbox", tabs.esp, "RGB Mode", "esp_rainbow", 130, 185 )	

	snixzz.CreateOption( "Slider", tabs.esp, "Field of View", "esp_fov", 90, 140, 420, 5, 325, 1 )
	snixzz.CreateOption( "Slider", tabs.esp, "Box Width", "esp_box_width", 1, 2.5, 420, 5, 345, 1 )
	snixzz.CreateOption( "Slider", tabs.esp, "Render Distance", "esp_render_distance", 0, 7500, 415, 5, 365, 0 )

	
	snixzz.CreateOption( "Label", tabs.esp, "Chams Material", 5, 290 )
	
	local ChamsType = G.vgui.Create( "DComboBox", tabs.esp )
	ChamsType:SetPos( 5, 305 )
	ChamsType:SetSize( 105, 20 )
	ChamsType:SetText( snixzz.Vars["esp_chams_material"] )
	ChamsType:AddChoice( "Solid" )
	ChamsType:AddChoice( "Wireframe" )
	ChamsType:AddChoice( "XQZ" )
	ChamsType:SetTextColor( color_white )
	ChamsType.OnSelect = function( self )
	
		snixzz.Vars["esp_chams_material"] = self:GetValue()
		snixzz.Chat( Color( 0, 255, 255 ), "Set chams material to '" .. self:GetValue() .. "'" )
		snixzz.Sound()
		
	end
	
	ChamsType.Paint = function() 
	
		G.surface.SetDrawColor( Color( 0, 0, 0 ) )
		G.surface.DrawOutlinedRect( 0, 0, ChamsType:GetWide(), ChamsType:GetTall() )
		
	end
	
	snixzz.CreateOption( "Label", tabs.esp, "ESP Type", 115, 290 )
	
	local ESPType = G.vgui.Create( "DComboBox", tabs.esp )
	ESPType:SetPos( 115, 305 )
	ESPType:SetSize( 105, 20 )
	ESPType:SetText( snixzz.Vars["esp_type"] )
	ESPType:AddChoice( "Players" )
	ESPType:AddChoice( "NPC" )
	ESPType:AddChoice( "Entities" )
	ESPType:AddChoice( "All" )
	ESPType:SetTextColor( color_white )
	ESPType.OnSelect = function( self )
	
		snixzz.Vars["esp_type"] = self:GetValue()
		snixzz.Chat( Color( 0, 255, 255 ), "Set ESP type to '" .. self:GetValue() .. "'" )
		snixzz.Sound()
		
	end
	
	ESPType.Paint = function() 
	
		G.surface.SetDrawColor( Color( 0, 0, 0 ) )
		G.surface.DrawOutlinedRect( 0, 0, ESPType:GetWide(), ESPType:GetTall() )
		
	end
	
	--------------
	-- Misc tab --
	--------------
	snixzz.CreateOption( "Checkbox", tabs.misc, "Bunnyhop", "misc_bhop", 5, 5 )
	snixzz.CreateOption( "Checkbox", tabs.misc, "Autostrafe", "misc_autostrafe", 5, 25 )
	snixzz.CreateOption( "Checkbox", tabs.misc, "Triggerbot", "misc_triggerbot", 5, 45 )
	snixzz.CreateOption( "Checkbox", tabs.misc, "Thirdperson", "misc_thirdperson", 5, 65 )
	snixzz.CreateOption( "Checkbox", tabs.misc, "Chat Spam", "misc_chat_spam", 5, 85 )
	snixzz.CreateOption( "Checkbox", tabs.misc, "Rapid Fire", "misc_rapidfire", 5, 105 )
	snixzz.CreateOption( "Checkbox", tabs.misc, "Clientside Noclip", "misc_csnoclip", 5, 125 )
	snixzz.CreateOption( "Checkbox", tabs.misc, "Door Spam", "misc_doorspam", 5, 145 )

	snixzz.CreateOption( "Checkbox", tabs.misc, "Traitor Finder", "misc_traitor_finder", 130, 5 )
	snixzz.CreateOption( "Checkbox", tabs.misc, "Murder Finder", "misc_murder_finder", 130, 25 )
	snixzz.CreateOption( "Checkbox", tabs.misc, "Prophunt Finder", "misc_prophunt_finder", 130, 45 )
	snixzz.CreateOption( "Checkbox", tabs.misc, "Prophunt Exploits [Beta]", "misc_exploits_prophunt", 130, 65 )
	snixzz.CreateOption( "Checkbox", tabs.misc, "ULX Votekick Spam", "misc_votekickspam", 130, 85 )
	snixzz.CreateOption( "Checkbox", tabs.misc, "Namechanger", "misc_namechanger", 130, 105 )
	
	snixzz.CreateOption( "Slider", tabs.misc, "Thirdperson Distance", "misc_thirdperson_distance", 50, 180, 415, 5, 345, 1 )

	snixzz.CreateOption( "Label", tabs.misc, "Triggerbot Method", 5, 290 )
	
	local Trigmethod = G.vgui.Create( "DComboBox", tabs.misc )
	Trigmethod:SetPos( 5, 305 )
	Trigmethod:SetSize( 105, 20 )
	Trigmethod:SetText( snixzz.Vars["misc_triggerbot_method"] )
	Trigmethod:AddChoice( "Body" )
	Trigmethod:AddChoice( "Hitbox" )
	Trigmethod:SetTextColor( color_white )
	Trigmethod.OnSelect = function( self )
	
		snixzz.Vars["misc_triggerbot_method"] = self:GetValue()
		snixzz.Chat( Color( 0, 255, 255 ), "Set triggerbot method to '" .. self:GetValue() .. "'" )
		snixzz.Sound()
		
	end
	Trigmethod.Paint = function() 
		
		G.surface.SetDrawColor( Color( 0, 0, 0 ) )
		G.surface.DrawOutlinedRect( 0, 0, Trigmethod:GetWide(), Trigmethod:GetTall() )
		
	end	
	
	snixzz.CreateOption( "Label", tabs.misc, "Triggerbot Type", 115, 290 )
	
	local TrigType = G.vgui.Create( "DComboBox", tabs.misc )
	TrigType:SetPos( 115, 305 )
	TrigType:SetSize( 105, 20 )
	TrigType:SetText( snixzz.Vars["misc_triggerbot_type"] )
	TrigType:AddChoice( "Players" )
	TrigType:AddChoice( "NPC" )
	TrigType:AddChoice( "Both" )
	TrigType:SetTextColor( color_white )
	TrigType.OnSelect = function( self )
	
		snixzz.Vars["misc_triggerbot_type"] = self:GetValue()
		snixzz.Chat( Color( 0, 255, 255 ), "Set triggerbot type to '" .. self:GetValue() .. "'" )
		snixzz.Sound()
		
	end
	TrigType.Paint = function() 
		
		G.surface.SetDrawColor( Color( 0, 0, 0 ) )
		G.surface.DrawOutlinedRect( 0, 0, TrigType:GetWide(), TrigType:GetTall() )
		
	end		
	
	snixzz.CreateOption( "Label", tabs.misc, "Chat Spam Method", 225, 290 )

	local SpamMethod = G.vgui.Create( "DComboBox", tabs.misc )
	SpamMethod:SetPos( 225, 305 )
	SpamMethod:SetSize( 105, 20 )
	SpamMethod:SetText( snixzz.Vars["misc_chat_spam_method"] )
	SpamMethod:AddChoice( "Advertise" )
	SpamMethod:AddChoice( "Random Jokes" )
	SpamMethod:AddChoice( "Chuck Norris" )
	SpamMethod:AddChoice( "Yo Momma Jokes" )
	SpamMethod:AddChoice( "Insults" )
	SpamMethod:SetTextColor( color_white )
	SpamMethod.OnSelect = function( self )
	
		snixzz.Vars["misc_chat_spam_method"] = self:GetValue()
		snixzz.Chat( Color( 0, 255, 255 ), "Set chat spam method to '" .. self:GetValue() .. "'" )
		snixzz.Sound()
		
	end
	
	SpamMethod.Paint = function() 
		
		G.surface.SetDrawColor( Color( 0, 0, 0 ) )
		G.surface.DrawOutlinedRect( 0, 0, SpamMethod:GetWide(), SpamMethod:GetTall() )
		
	end	
	
	---------------
	-- Lists Tab --
	---------------
	
	-- Friends/enemies
	
	local Enemies = G.vgui.Create( "DListView", tabs.lists )
	Enemies:SetPos( 5, 5 )
	Enemies:SetSize( 170, 190 )
	Enemies:AddColumn( "Enemies" )
	
	for k, v in G.next, G.player.GetAll() do
		
		if !snixzz.Friends[v:Nick()] && v != G.LocalPlayer() then
			
			Enemies:AddLine( v:Nick() )
			
		end
		
	end
	
	local Friends = G.vgui.Create( "DListView", tabs.lists )
	Friends:SetPos( 230, 5 )
	Friends:SetSize( 170, 190 )
	Friends:AddColumn( "Friends" )
	
	for k, v in G.next, snixzz.Friends do
		
		Friends:AddLine( k )
		
	end
	
	local AddFriend = G.vgui.Create( "DButton", tabs.lists ) 
	AddFriend:SetText( "-->" ) 
	AddFriend:SetSize( 30, 20 )
	AddFriend:SetPos( 187.5, 140 )
	AddFriend:SetTextColor( color_white )
	AddFriend.DoClick = function() 
	
	local line = Enemies:GetSelectedLine()
		
		if line != nil then 
			
			local ply = Enemies:GetLine( line ):GetValue(1)  
			
			if !snixzz.Friends[ply] then
				
				snixzz.Friends[ply] = true
				snixzz.Chat( snixzz.Colors.Green, "Added '" .. ply .. "' to friends list." )
				Friends:AddLine( ply ) 
				Enemies:RemoveLine( line ) 
				snixzz.Sound()
				
			end 
			
		end
		
	end
	
	AddFriend.Paint = function() 
		
		G.surface.SetDrawColor( Color( 0, 0, 0 ) )
		G.surface.DrawOutlinedRect( 0, 0, AddFriend:GetWide(), AddFriend:GetTall() )
		
	end
	
	local RemoveFriend = G.vgui.Create( "DButton", tabs.lists ) 
	RemoveFriend:SetText("<--") 
	RemoveFriend:SetSize( 30, 20 ) 
	RemoveFriend:SetPos( 187.5, 165 )
	RemoveFriend:SetTextColor( color_white )
	RemoveFriend.DoClick = function() 
	
		local line = Friends:GetSelectedLine() 
		
		if line != nil then 
			
			local ply = Friends:GetLine( line ):GetValue( 1 ) 
			
			if snixzz.Friends[ply] then
			
				for k, v in G.next, snixzz.Friends do 
					
					if k == ply then 
						
						snixzz.Friends[k] = nil
						snixzz.Chat( snixzz.Colors.Red, "Removed '" .. ply .. "' from the friends list." )
						snixzz.Sound()
						
					end 
					
				end 
				
				Enemies:AddLine( ply ) 
				Friends:RemoveLine( line )
				
			end
			
		end 
		
	end 
	
	RemoveFriend.Paint = function() 
		
		G.surface.SetDrawColor( Color( 0, 0, 0 ) )
		G.surface.DrawOutlinedRect( 0, 0, RemoveFriend:GetWide(), RemoveFriend:GetTall() )
		
	end
	
	local AllEnts = G.vgui.Create( "DListView", tabs.lists )
	AllEnts:SetSize( 170, 190 )
	AllEnts:SetPos( 5, Enemies:GetTall() + 10 )
	AllEnts:AddColumn( "All Entities" )
	
	local addedEnts = {}
	
	for k, v in G.next, G.ents.GetAll() do
	
		if !addedEnts[v:GetClass()] && !v:IsPlayer() && !v:IsNPC() && !snixzz.Entities[v:GetClass()] && !snixzz.BadEntities[v:GetClass()] then
	
			AllEnts:AddLine( v:GetClass() )
			addedEnts[v:GetClass()] = true
			
		end
		
	end
	
	local DrawEnts = G.vgui.Create( "DListView", tabs.lists )
	DrawEnts:SetPos( 230, Friends:GetTall() + 10 )
	DrawEnts:SetSize( 170, 190 )
	DrawEnts:AddColumn( "Entities to Draw" )
	
	for k, v in G.next, snixzz.Entities do
		
		DrawEnts:AddLine( k )
		
	end
	
	local AddEntity = G.vgui.Create( "DButton", tabs.lists ) 
	AddEntity:SetText( "-->" ) 
	AddEntity:SetSize( 30, 20 )
	AddEntity:SetPos( 187.5, 315 )
	AddEntity:SetTextColor( color_white )
	AddEntity.DoClick = function() 
	
	local line = AllEnts:GetSelectedLine()
		
		if line != nil then 
			
			local ent = AllEnts:GetLine( line ):GetValue(1)  
			
			if !snixzz.Entities[ply] then
				
				snixzz.Entities[ent] = true
				snixzz.Chat( snixzz.Colors.Green, "Added '" .. ent .. "' to entities list." )
				DrawEnts:AddLine( ent ) 
				AllEnts:RemoveLine( line ) 
				snixzz.Sound()
				
			end 
			
		end
		
	end
	
	AddEntity.Paint = function() 
		
		G.surface.SetDrawColor( Color( 0, 0, 0 ) )
		G.surface.DrawOutlinedRect( 0, 0, AddEntity:GetWide(), AddEntity:GetTall() )
		
	end
	
	local RemoveEntity = G.vgui.Create( "DButton", tabs.lists ) 
	RemoveEntity:SetText("<--") 
	RemoveEntity:SetSize( 30, 20 ) 
	RemoveEntity:SetPos( 187.5, 350 )
	RemoveEntity:SetTextColor( color_white )
	RemoveEntity.DoClick = function() 
	
		local line = DrawEnts:GetSelectedLine() 
		
		if line != nil then 
			
			local ent = DrawEnts:GetLine( line ):GetValue( 1 ) 
			
			if snixzz.Entities[ent] then
			
				for k, v in G.next, snixzz.Entities do 
					
					if k == ent then 
						
						snixzz.Entities[k] = nil
						snixzz.Chat( snixzz.Colors.Red, "Removed '" .. ent .. "' from the entities list." )
						snixzz.Sound()
						
					end 
					
				end 
				
				AllEnts:AddLine( ent ) 
				DrawEnts:RemoveLine( line )
				
			end
			
		end 
		
	end 
	
	RemoveEntity.Paint = function() 
		
		G.surface.SetDrawColor( Color( 0, 0, 0 ) )
		G.surface.DrawOutlinedRect( 0, 0, RemoveEntity:GetWide(), RemoveEntity:GetTall() )
		
	end
	
	-----------------
	--  Log Tab    --
	-----------------
	
	snixzz.LogTab = G.vgui.Create( "DListView", tabs.log )
	snixzz.LogTab:SetPos( 5, 5 )
	snixzz.LogTab:SetSize( snixzz.Frame:GetWide() - 25, snixzz.Frame:GetTall() - 70 )
	snixzz.LogTab:AddColumn( "snixzz3 Logs" )
	snixzz.LogTab:SetSortable( false )
	snixzz.LogTab:SetMultiSelect( false )
	
	for k, v in G.next, snixzz.Lines do
		snixzz.LogTab:AddLine( v )
		
	end
	
	snixzz.LogTab.OnClickLine = function( parent, line, isselected )
		
		G.SetClipboardText( line:GetValue( 1 ) )
		
	end
	
	local ConsoleClear = G.vgui.Create( "DButton", tabs.log ) 
	ConsoleClear:SetText( "Clear Log" ) 
	ConsoleClear:SetSize( snixzz.Frame:GetWide() - 25, 23 )
	ConsoleClear:SetPos( 5, 370 )
	ConsoleClear:SetTextColor( color_white )
	
	ConsoleClear.DoClick = function() 
	
		snixzz.Lines = {}
		snixzz.LogTab:Clear()
		
	end 
	
	ConsoleClear.Paint = function() 
		
		G.surface.SetDrawColor( Color( 0, 0, 0 ) )
		G.surface.DrawOutlinedRect( 0, 0, ConsoleClear:GetWide(), ConsoleClear:GetTall() )
		
	end
	
	----------------
	-- Config Tab --
	----------------
	--Menu Settings
	snixzz.CreateOption( "Label", tabs.config, "Menu Color", 230, 5 )
	
	local MenuColor = G.vgui.Create( "DColorMixer", tabs.config )
	MenuColor:SetPos( 230, 20 ) 
	MenuColor:SetSize( 170, 100 )
	MenuColor:SetPalette( false )
	MenuColor:SetAlphaBar( true )
	MenuColor:SetWangs( false )
	MenuColor:SetColor( snixzz.Vars["misc_menucolor"] )
	
	MenuColor.ValueChanged = function()
		
		snixzz.Vars["misc_menucolor"] = MenuColor:GetColor()
		
	end
	
	snixzz.CreateOption( "Label", tabs.config, "Secondary Menu Color", 230, 125 )
	
	local MenuColor2 = G.vgui.Create( "DColorMixer", tabs.config )
	MenuColor2:SetPos( 230, 140 ) 
	MenuColor2:SetSize( 170, 100 )
	MenuColor2:SetPalette( false )
	MenuColor2:SetAlphaBar( true )
	MenuColor2:SetWangs( false )
	MenuColor2:SetColor( snixzz.Vars["misc_menucolor2"] )
	
	MenuColor2.ValueChanged = function()
		
		snixzz.Vars["misc_menucolor2"] = MenuColor2:GetColor()
		
	end
	
	snixzz.CreateOption( "Label", tabs.config, "Laser Color", 230, 245 )
	
	local LaserCol = G.vgui.Create( "DColorMixer", tabs.config )
	LaserCol:SetPos( 230, 260 ) 
	LaserCol:SetSize( 170, 100 )
	LaserCol:SetPalette( false )
	LaserCol:SetAlphaBar( false )
	LaserCol:SetWangs( false )
	LaserCol:SetColor( snixzz.Vars["misc_lasercolor"] )
	
	LaserCol.ValueChanged = function()
		
		snixzz.Vars["misc_lasercolor"] = LaserCol:GetColor()
		
	end
	
	local CfgList = G.vgui.Create( "DListView", tabs.config ) 
	CfgList:SetPos( 5, 5 ) 
	CfgList:SetMultiSelect( false ) 
	CfgList:SetSize( 220, 80 )
	CfgList:AddColumn( "Config" ) 
	
	for k, v in G.next, snixzz.Configs do 
		
		CfgList:AddLine( v ) 
		
	end 
	
	CfgList.DoDoubleClick = function() 
		
		local line = CfgList:GetSelectedLine() 
		
		if line != nil then 
		
			local config = CfgList:GetLine( line ):GetValue( 1 ) 
			snixzz.LoadConfig( config ) 
			snixzz.Sound()
			
		end 
		
	end 
		
	-- Right from gInject. Im lazy with menus. I'll re-write it later
	local CreateConfig = G.vgui.Create( "DButton", tabs.config ) 
	CreateConfig:SetText( "Create New" ) 
	CreateConfig:SetSize( 105, 30 )
	CreateConfig:SetPos( 5, 90 )
	CreateConfig:SetTextColor( color_white )
	CreateConfig.DoClick = function() 
	
		G.Derma_StringRequest( "New Config", "Name of the new config", "", function( txt ) 
		
			snixzz.SaveConfig( txt ) 
			snixzz.Sound()
			
		end )
		
	end 
	
	CreateConfig.Paint = function() 
	
		G.surface.SetDrawColor( Color( 0, 0, 0 ) )
		G.surface.DrawOutlinedRect( 0, 0, CreateConfig:GetWide(), CreateConfig:GetTall() )
		
	end
	
	local RenameConfig = G.vgui.Create( "DButton", tabs.config ) 
	RenameConfig:SetText( "Rename" ) 
	RenameConfig:SetSize( 105, 30 )
	RenameConfig:SetPos( 5, 125 )
	RenameConfig:SetTextColor( color_white )
	RenameConfig.DoClick = function()
		
		G.Derma_StringRequest( "Rename Config", "Name of the new config", "", function( NewConfig ) 
			
			local line = CfgList:GetSelectedLine() 
			
			if line != nil then 
				
				local OldConfig = CfgList:GetLine( line ):GetValue( 1 ) 
				
				if OldConfig != "default" then
				
					snixzz.RenameConfig( OldConfig, NewConfig )
					G.table.remove( snixzz.Configs, CfgList:GetSelectedLine() )
					G.table.insert( snixzz.Configs, NewConfig )
					snixzz.Sound()
					
				end
				
			end
			
		end )
		
	end
	
	RenameConfig.Paint = function() 
		
		G.surface.SetDrawColor( Color( 0, 0, 0 ) )
		G.surface.DrawOutlinedRect( 0, 0, RenameConfig:GetWide(), RenameConfig:GetTall() )
		
	end
	
	local DeleteConfig = G.vgui.Create( "DButton", tabs.config ) 
	DeleteConfig:SetText( "Delete" ) 
	DeleteConfig:SetSize( 105, 30 )
	DeleteConfig:SetPos( 118, 90 )
	DeleteConfig:SetTextColor( color_white )
	DeleteConfig.DoClick = function() 
	
		local line = CfgList:GetSelectedLine() 
		
		if line != nil then
			
			local config = CfgList:GetLine( line ):GetValue( 1 ) 
			if config != "default" then
			
				for k, v in G.next, snixzz.Configs do 
					
					if v == config then 
					
						snixzz.DeleteConfig( config )
						G.table.remove( snixzz.Configs, k ) 
						snixzz.Sound()
						
					end 
					
				end
				
			end
			
		end 
		
	end 
	
	DeleteConfig.Paint = function() 
	
		G.surface.SetDrawColor( Color( 0, 0, 0 ) )
		G.surface.DrawOutlinedRect( 0, 0, DeleteConfig:GetWide(), DeleteConfig:GetTall() )
		
	end
	
	
	local LoadConfig = G.vgui.Create( "DButton", tabs.config ) 
	LoadConfig:SetText( "Load" ) 
	LoadConfig:SetSize( 105, 30 )
	LoadConfig:SetPos( 118, 125 )
	LoadConfig:SetTextColor( color_white )
	LoadConfig.DoClick = function()
	
		local line = CfgList:GetSelectedLine() 
		
		if line != nil then 
			local config = CfgList:GetLine( line ):GetValue( 1 ) 
			snixzz.LoadConfig( config )
			snixzz.Frame:SetVisible( false )
			//snixzz.Changelog:SetVisible( false )
			//snixzz.LinksButton:SetVisible( false )
			snixzz.MenuOpen = false
			snixzz.MenuToggle = false
			snixzz.Sound()
			
		end
		
	end
	
	LoadConfig.Paint = function() 
		
		G.surface.SetDrawColor( Color( 0, 0, 0 ) )
		G.surface.DrawOutlinedRect( 0, 0, LoadConfig:GetWide(), LoadConfig:GetTall() )
		
	end
	
	local SetDefaultCfg = G.vgui.Create( "DButton", tabs.config ) 
	SetDefaultCfg:SetText( "Set Default" ) 
	SetDefaultCfg:SetSize( 105, 30 )
	SetDefaultCfg:SetPos( 118, 160 )
	SetDefaultCfg:SetTextColor( color_white )
	SetDefaultCfg.DoClick = function()
	
		local line = CfgList:GetSelectedLine() 
	
		if line != nil then 
		
			local config = CfgList:GetLine( line ):GetValue( 1 ) 
			
			snixzz.SetDefaultConfig( config )
			snixzz.LoadConfig( config )
			snixzz.Sound()
			
		end
		
	end	
	
	SetDefaultCfg.Paint = function() 
		
		G.surface.SetDrawColor( Color( 0, 0, 0 ) )
		G.surface.DrawOutlinedRect( 0, 0, SetDefaultCfg:GetWide(), SetDefaultCfg:GetTall() )
		
	end
		
	local UpdateConfig = G.vgui.Create( "DButton", tabs.config ) 
	UpdateConfig:SetText( "Save Changes" ) 
	UpdateConfig:SetSize( 105, 35 )
	UpdateConfig:SetPos( 118, 195 )
	UpdateConfig:SetTextColor( color_white )
	UpdateConfig.DoClick = function()
		
		snixzz.Sound()
		snixzz.UpdateConfig()
		
	end	
	
	UpdateConfig.Paint = function() 
		
		G.surface.SetDrawColor( Color( 0, 0, 0 ) )
		G.surface.DrawOutlinedRect( 0, 0, UpdateConfig:GetWide(), UpdateConfig:GetTall() )
		
	end
		
	// Binds
	local BindCommands = G.vgui.Create( "DComboBox", tabs.config )
	BindCommands:SetPos( 5, 160 )
	BindCommands:SetSize( 105, 20 )
	BindCommands:SetTextColor( color_white )
	
	for k, v in G.next, snixzz.Binds do
		
		BindCommands:AddChoice( k )
		
	end
	
	BindCommands.Paint = function() 
	
		G.surface.SetDrawColor( Color( 0, 0, 0 ) )
		G.surface.DrawOutlinedRect( 0, 0, BindCommands:GetWide(), BindCommands:GetTall() )
		
	end
	
	local BindKeys = G.vgui.Create( "DComboBox", tabs.config )
	BindKeys:SetPos( 5, 185 )
	BindKeys:SetSize( 105, 20 )
	BindKeys:SetTextColor( color_white )
	
	for k, v in G.next, snixzz.Keys do
		
		BindKeys:AddChoice( v.Name )
		
	end
	
	BindKeys.Paint = function() 
	
		G.surface.SetDrawColor( Color( 0, 0, 0 ) )
		G.surface.DrawOutlinedRect( 0, 0, BindKeys:GetWide(), BindKeys:GetTall() )
		
	end
	
	local RebindKey = G.vgui.Create( "DButton", tabs.config ) 
	RebindKey:SetText( "Bind" ) 
	RebindKey:SetSize( 105, 20 )
	RebindKey:SetPos( 5, 210 )
	RebindKey:SetTextColor( color_white )
	RebindKey.DoClick = function() 
		
		local Key = BindKeys:GetValue()
		local Command = BindCommands:GetValue()
		
		if ( BindKeys:GetValue() != "" && BindCommands:GetValue() != "" ) then
			
			snixzz.Frame:SetVisible( false )
			//snixzz.Changelog:SetVisible( false )
			//snixzz.LinksButton:SetVisible( false )
			snixzz.MenuOpen = false
			snixzz.MenuToggle = false
			snixzz.BindKey( Command, Key )
			snixzz.Sound()
			
		end
		
	end
	
	RebindKey.Paint = function() 
		
		G.surface.SetDrawColor( Color( 0, 0, 0 ) )
		G.surface.DrawOutlinedRect( 0, 0, RebindKey:GetWide(), RebindKey:GetTall() )
		
	end
	
	local JoinHvH = G.vgui.Create( "DButton", tabs.config ) 
	JoinHvH:SetText( "Join OFFICIAL Hack VS Hack Server" ) 
	JoinHvH:SetSize( 218, 30 )
	JoinHvH:SetPos( 5, 235 )
	JoinHvH:SetTextColor( color_white )
	JoinHvH:SetFont( "snixzz_logo_small" )
	JoinHvH.DoClick = function()
		
		Derma_Query( 
		
		"Would you like to join Hack VS Hack?", "Join Hack VS Hack", 
		
		"Yes", function() 
			
			snixzz.Chat( Color( 255, 0, 0 ), "Connecting in 15 seconds. If you're missing the map you can simply Google 'aim_ag_texture2' & download it anywhere." )
			
			timer.Simple( 15, function()
			
				G.LocalPlayer():ConCommand( "connect 66.150.164.192:27015" )
			
			end )
			
		end,
		
		"No", function()

			snixzz.Chat( Color( 0, 255, 255 ), "Hack VS Hack is a great place to test & configure your cheat or compete against other cheaters!" )
		
		end )
		
	end	
	
	JoinHvH.Paint = function() 
		
		G.surface.SetDrawColor( Color( 0, 0, 0 ) )
		G.surface.DrawOutlinedRect( 0, 0, JoinHvH:GetWide(), JoinHvH:GetTall() )
		
	end
	
	snixzz.Changelog = G.vgui.Create( "DButton", tabs.config )
	snixzz.Changelog:SetText( "Changelog and News" )
	snixzz.Changelog:SetPos( 5, 270 )
	snixzz.Changelog:SetSize( 218, 30 )
	snixzz.Changelog:SetFont( "snixzz_logo" )
	snixzz.Changelog:SetTextColor( color_white )
	
	snixzz.Changelog.DoClick = function()
		
		if !snixzz.CFrame then
		
			snixzz.Sound()
			snixzz.CMenu()
			
		end
		
	end
	snixzz.Changelog.Paint = function() 
		
		//G.draw.RoundedBox( 0, 0, 0, snixzz.Changelog:GetWide(), snixzz.Changelog:GetTall(), Color( 40, 40, 40, 145 ) )
		G.surface.SetDrawColor( Color( 0, 0, 0 ) )
		G.surface.DrawOutlinedRect( 0, 0, snixzz.Changelog:GetWide(), snixzz.Changelog:GetTall() )
		
	end
	
	snixzz.CreateOption( "Checkbox", tabs.config, "Load with GAMEMODE hooks (Buggy, may break parts of gamemode)", "load_unhooked", 5, 375 )
	
end

/*
	
	Open Steam Group & Forum once
	
*/

/*
function snixzz.RequestLinks()
	
	G.Derma_Query( "snixzz.net is expanding!\nWe've re-opened our forums and a Steam group, please take a look & consider joining!", "[snixzz.net] Join us!",
	"Okay!", function()
		
		snixzz.OpenLinksMenu()
		
	end )
	
end

function snixzz.OpenLinksMenu()
	
	snixzz.linksMenu = G.vgui.Create( "DFrame" )
	snixzz.linksMenu:SetSize( 260, 60 )
	snixzz.linksMenu:Center()
	snixzz.linksMenu:SetTitle( "Links" )
	snixzz.linksMenu:ShowCloseButton( false )
	snixzz.linksMenu:MakePopup()
	snixzz.linksMenu.Paint = function( self ) 
	
		G.draw.RoundedBox( 0, 0, 0, self:GetWide(), self:GetTall(), snixzz.Vars["misc_menucolor2"] )
		G.surface.SetDrawColor( Color( 0, 0, 0 ) )
		G.surface.DrawOutlinedRect( 0, 0, self:GetWide(), self:GetTall() )
		
	end
	
	local close = G.vgui.Create( "DButton", snixzz.linksMenu )
	close:SetSize( 50, 20 )
	close:SetPos( snixzz.linksMenu:GetWide() - 51, 1 )
	close:SetText( "x" )
	close:SetTextColor( G.Color( 255, 255, 255 ) )
	close:SetFont( "Trebuchet18" )
	
	close.Paint = function()
	
		G.draw.RoundedBox( 0, 0, 0, close:GetWide(), close:GetTall(), Color( 168, 62, 62, 255 ) )
	
	end
	
	close.DoClick = function()
		
		snixzz.linksMenu:Close()
		snixzz.Sound()
		snixzz.linksMenu = nil
		
	end
	
	local website = G.vgui.Create( "DButton", snixzz.linksMenu )
	website:SetSize( 120, 30 )
	website:SetPos( 5, 25 )
	website:SetText( "Forums" )
	website:SetTextColor( color_white )
	
	website.Paint = function() 
		
		G.surface.SetDrawColor( Color( 230, 30, 30 ) )
		G.surface.DrawOutlinedRect( 0, 0, website:GetWide(), website:GetTall() )
		
	end
	
	website.DoClick = function( self )
		
		G.gui.OpenURL( "https://bit.ly/1UiOwAC" )
		
	end
	
	local group = G.vgui.Create( "DButton", snixzz.linksMenu )
	group:SetSize( 120, 30 )
	group:SetPos( 130, 25 )
	group:SetText( "Steam Group" )
	group:SetTextColor( color_white )
	
	group.Paint = function() 
		
		G.surface.SetDrawColor( Color( 0, 255, 153 ) )
		G.surface.DrawOutlinedRect( 0, 0, group:GetWide(), group:GetTall() )
		
	end
	
	group.DoClick = function( self )
		
		G.gui.OpenURL( "https://bit.ly/1VzMroY" )
		
	end
	
end

if !G.file.Exists( snixzz.DataFolder .. "/asktojoin.txt", "DATA" ) then
	
	snixzz.RequestLinks()
	
	file.Write( snixzz.DataFolder .. "/asktojoin.txt", "Confirmed, asked to join website/steam group on " .. G.os.date() .. "\n" )
	
end
*/

/*

	Hooking & loading.
	
*/

function snixzz.LoadHooks()

	snixzz.GMHooks = { -- Return the server's original hooks for selected types
		
		["CreateMove"] = GAMEMODE.CreateMove,
		["HUDPaint"] = GAMEMODE.HUDPaint,
		["StartChat"] = GAMEMODE.StartChat,
		["FinishChat"] = GAMEMODE.FinishChat,
		["PlayerTraceAttack"] = GAMEMODE.PlayerTraceAttack,
		["RenderScene"] = GAMEMODE.RenderScene,

	}
	
	function GAMEMODE:RenderScene()
	
	end
	
	function GAMEMODE:PlayerTraceAttack( ent, dmg, dir, trace )
	
		local hit = trace.HitPos
		local start = trace.StartPos
		
		G.table.insert( snixzz.Bullets, { hit, start, 5, Color( 255, 0, 0, 255 ), snixzz.Angles } )
		
		return snixzz.GMHooks["PlayerTraceAttack"]( ent, dmg, dir, trace )
		
	end

	function GAMEMODE:StartChat() 
		
		snixzz.Typing = true
		
		return snixzz.GMHooks.StartChat() 
	end 

	function GAMEMODE:FinishChat() 
		
		snixzz.Typing = false 
		
		return snixzz.GMHooks.FinishChat()
	end 

	function GAMEMODE:ShouldDrawLocalPlayer( ply )
		
		return snixzz.Bools["misc_thirdperson"]
		
	end

	if snixzz.Bools["load_unhooked"] then

		function GAMEMODE:CreateMove( ucmd )
			
			snixzz.CreateMove( ucmd )
			
			return snixzz.GMHooks.CreateMove( ucmd )
		end

		function GAMEMODE:HUDPaint( self, ... )
			
			snixzz.HUDPaint()
			
			return snixzz.GMHooks.HUDPaint( self, ... )
		end

		function GAMEMODE:CalcView( ply, origin, angles, fov )
		
			return snixzz.CalcView( ply, origin, angles, fov )
			
		end

		function GAMEMODE:Move()
		
			return snixzz.Move()
			
		end
		
		snixzz.AddToConsole( "Hooking functions into the gamemode's hook system." )
		
	else

		snixzz.AddHook( "CreateMove", snixzz.CreateMove )
		snixzz.AddHook( "HUDPaint", snixzz.HUDPaint )
		snixzz.AddHook( "CalcView", snixzz.CalcView )
		snixzz.AddHook( "Move", snixzz.Move )
		
		snixzz.AddToConsole( "Loading unsecured hooks. More detectable but more reliable." )
		
	end
	
end

function snixzz.LoadExploits()

	if snixzz.Bools["misc_exploits_prophunt"] then
	
		local Team = 1
		
		if team.GetName( Team ) == "Hunters" then
		
			Team = 2
		
		end
	
		net.Receive( "PH_TeamWinning_Snd", function( len )
				
			snixzz.Chat( Color( 0, 255, 0 ), "Detected round end, attempting to exploit team swap system to become hunter" )
			
			G.RunConsoleCommand( "changeteam", Team )
				
		end )
		
		net.Receive( "PH_RoundDraw_Snd", function( len )
				
			snixzz.Chat( Color( 0, 255, 0 ), "Detected round draw, attempting to exploit team swap system to become hunter" )
			
			G.RunConsoleCommand( "changeteam", Team )
				
		end )	
		
	end

end

function snixzz.DisplayAd()

	local ad_frame = vgui.Create( "DFrame" )
	ad_frame:SetSize( 500, 125 )
	ad_frame:SetPos( ScrW() / 2 - ( ad_frame:GetWide() / 2 ), ScrH() - ad_frame:GetTall() )
	ad_frame:SetTitle( "" )
	ad_frame:ShowCloseButton( false )
	
	ad_frame.Paint = function()	
	end

	local ad_html = vgui.Create( "DHTML", ad_frame )
	ad_html:SetSize( 480, 115 )
	ad_html:SetPos( 5, 25 )
	ad_html:OpenURL( "http://snixzz.net/ad.html" )
	
	ad_html.OnFinishLoadingDocument = function()
		
		if ispanel( ad_frame ) then
		
			ad_frame.Paint = function()
			
				local str = "Advertisement"
			
				surface.SetFont( "Trebuchet18" )
			
				local w, h = surface.GetTextSize( str )
			
				draw.RoundedBox( 0, 12.5, 32.5, w + 5, 20, Color( 0, 0, 0, 200 ) )
			
				draw.SimpleText( str, "Trebuchet18", 15, 42.5, Color( 200, 200, 200, 200 ), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER )
			
			end	
			
			timer.Simple( 8, function() 
				
				if ispanel( ad_frame ) then
				
					ad_frame:Close() 
					
				end
				
			end )
			
		end
		
	end	

end

function snixzz.PingServer( ply ) -- This was overly complicated & I ended up having to do it a really dumb way for now.

	snixzz.AddToConsole( "Attempting to ping snixzz server" )

	G.http.Fetch( "http://snixzz.net/cheats/snixzz3/ping.php?steamid=" .. ply:SteamID64(), 
		
		function( body )
			
			snixzz.AddToConsole( "snixzz server responded to ping with '" .. body .. "'" )
			
			if body == "Error: Retry" then
				
				snixzz.PingServer( LocalPlayer() )
				
			end
			
		end,
			
		function( error )
			
			snixzz.AddToConsole( "ping received, pinging server again in 250 seconds." )
			
			G.timer.Simple( 250, function()
	
				snixzz.PingServer( LocalPlayer() )
				
			end )
			
			if snixzz.IsDev( LocalPlayer() ) or !snixzz.IsVIP() then
			
				if math.random( 1, 3 ) == 1 then // roll the dice boi
			
					//snixzz.DisplayAd()
					
				end
				
			end
			
		end
		
	)

end

local nerd
local reson = {

	"s n i x z z . n e t",
	"s n i x z z 3",
	"no votekick pls",

}
function snixzz.VotekickSpam()
	
	if snixzz.Bools["misc_votekickspam"] then
	
		local nerds = {}
	
		for k, v in next, player.GetAll() do
		
			if v == LocalPlayer() then continue end
		
			table.insert( nerds, v )
		
		end
		
		nerd = table.Random( nerds )
		
		RunConsoleCommand( "ulx", "votekick", nerd:Nick(), tostring( table.Random( reson ) ) )
	
	end

end

function snixzz.CreateTimers() 
	
	if snixzz.IsTTT then

		snixzz.RegisterTimer( 10, 0, snixzz.GetTraitors )
		
	end

	if snixzz.IsDarkRP then
		
		snixzz.RegisterTimer( 10, 0, snixzz.Namechanger )
		
	else
		
		snixzz.RegisterTimer( G.GetConVarNumber( "sv_namechange_cooldown_seconds" ) + 0.5, 0, snixzz.Namechanger )
		
	end

	snixzz.RegisterTimer( 20.5, 0, snixzz.VotekickSpam )
	snixzz.RegisterTimer( 1, 0, snixzz.ChatSpam )
	
end

function snixzz.LoadAllFunctions()
	
	snixzz.UpdateChangelog()
	
	snixzz.FileSystem()
	
	snixzz.Configs = snixzz.GetConfigs()
	
	if !snixzz.ConfigExists( "default" ) then
		
		snixzz.SaveConfig( "default" )
	
	end
	
	snixzz.UpdateAllConfigs()

	snixzz.LoadConfig( snixzz.DefaultConfig, true )	
	
	snixzz.AntiCheats()
	snixzz.CreateDetours()
	snixzz.LoadModules()
	snixzz.CreateTimers() 
	snixzz.LoadHooks()
	snixzz.LoadExploits()
	
	//snixzz.PingServer( LocalPlayer() )
	
	//snixzz.Chat( Color( 0, 255, 0 ), "Loaded in " .. string.NiceTime( math.Round( CurTime() - snixzz.LoadTime ) ) )

end

function snixzz.Ban( ply, bantype )

	if bantype == "ip" then
		
		snixzz.Chat( Color( 255, 0, 0 ), "You have been IP banned from the snixzz.net services." )
		
	elseif bantype == "id" then
		
		snixzz.Chat( Color( 255, 0, 0 ), "You have been banned from the snixzz.net services." )
		
	end
	
	if snixzz.loadFrame && snixzz.loadProgress then
	
		snixzz.loadProgress:SetFraction( 1 )
		
		snixzz.loadFrame:SetTitle( "Banned." )	
		
		snixzz.loadFrame:Close() 
		snixzz.loadProgress = nil 
		snixzz.loadFrame = nil
					
		gui.EnableScreenClicker( false )
		
	end

	if _G.snixzz then _G.snixzz = nil end
		
end

function snixzz.LoadCheat( bool )
	
	if snixzz.loadProgress then
	
		snixzz.loadProgress:SetFraction( 0.4 )
		snixzz.loadFrame:SetTitle( "Logged in, sending stats." )
		
	end
	
	if snixzz.Banned then
		
		snixzz.Ban( LocalPlayer(), "id" )
		
		return
		
	end
	
	snixzz.Stats( LocalPlayer(), true, function()
		
		G.chat.AddText( "\n\n\n\n" )
		
		if bool then
			
			snixzz.Chat( Color( 255, 0, 0 ), "Failed to connect to login server, running as guest." )

		end
		
		snixzz.logEvent( "Load", "Playing " .. GAMEMODE.Name .. " on " .. GetHostName() )
		
		snixzz.Chat( snixzz.Colors.Green, "Press '" .. G.input.GetKeyName( snixzz.Binds["+menu"] ) .. "' to open the menu & hold TAB+Q to open the console." )
		
		G.chat.AddText( 
		snixzz.Colors.DarkRed, "[snixzz3] ",
		snixzz.Colors.Cyan, "Loaded lua. ",
		snixzz.Colors.Purple, snixzz.Info.Version .. ", ",
		snixzz.Colors.White, "Last updated ",
		snixzz.Colors.Green, snixzz.Info.Updated .. ", ",
		Color( 255, 255, 0 ), snixzz.Info.Size .. ", ",
		Color( 0, 100, 240 ), snixzz.Info.Lines .. " ",
		snixzz.Colors.White, "lines long. ", 
		snixzz.Colors.Green, "Membership Status: ",
		color_white, snixzz.Membership )
		
		//snixzz.Chat( snixzz.Colors.Cyan, "Try out our new chat system by pressing '" .. G.input.GetKeyName( snixzz.Binds["chat"] ) .. "' or typing 'chat' in your snixzz3 console." )
		
		snixzz.Sound()
		
		snixzz.Users = {}
		
		// Some shit
		for k, v in G.next, G.player.GetAll() do
			
			if v != G.LocalPlayer() then
				
				if snixzz.IsDev( v ) then
						
					snixzz.Chat( Color( 0, 255, 255 ), "The developer of snixzz3 is on the server! Suck " .. v:Nick() .. "'s cock!" ) -- im a faggot
						
				end
				
			end
			
		end

		
		snixzz.loadProgress:SetFraction( 1 )
		
		snixzz.loadFrame:SetTitle( "Done!" )
		
		G.timer.Simple( 0.5, function() 
			
			snixzz.loadFrame:Close() 
			snixzz.loadProgress = nil 
			snixzz.loadFrame = nil

			gui.EnableScreenClicker( false )
				
			snixzz.LoadAllFunctions()
			
		end )
		
	end )
	
end

timer.Simple( 5, function()

snixzz.LoadAllFunctions()

end )
//snixzz.Login( LocalPlayer() )