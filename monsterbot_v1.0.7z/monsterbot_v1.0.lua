//-/~ Note By Paradox:
-- This is a paste of defcon with some extra features
-- see cheats/typical/defcon.lua

local MonsterBot = { Menu = { t = {}; b = {}; c = 0;}; Alive = {}; Spectators = {};}
 
Msg( "\n[MonsterBot] Loaded\n" )
Msg( "For a List of Binds look Below\n" )
Msg( "Bind Key Toggle Misc_removelaser  <Laser\n" )
Msg( "Bind Key Toggle Monster_aimassist  <AimAssist\n" )
Msg( "Bind Key ThrowMagneto  <PropKill\n" )
Msg( "MBN_toggle  <FreeCam\n\n" )
 
MonsterBot.Normal                   = {
        aimbot                                  = true;
        aimbot_fov                              = 15;
        aimbot_friendly_fire    = true;
        triggerbot                              = false;
        norecoil                                   = false;
 
        esp_player                              =  false;
        esp_player_dist                 = 16000;
        esp_player_showdist             =  false;
        esp_player_name                 = false;
        esp_player_rank                 = false;
        esp_player_health               = false;
        esp_player_armor                = false;
        esp_player_glow                 = false;
 
        esp_entity                              = false;
        esp_entity_dist                 = 16000;
        esp_entity_glow                 = false;
 
        flashlight_spam                 = false;
        thirdperson                             = false;
 
        darkrp_money                    = false;
        darkrp_god                              = false;
 
        ttt_deathnotifs                 = false;
        ttt_showalive                   = false;
 
        perp_fuel                        = false;
 
        developer                               = false;
 
}
MonsterBot.Settings                 = (file.Exists("d_settings.txt", "DATA") and util.JSONToTable(file.Read("d_settings.txt", "DATA"))) or MonsterBot.Normal
MonsterBot.Entities                 = (file.Exists("d_entities.txt", "DATA") and util.JSONToTable(file.Read("d_entities.txt", "DATA"))) or {}
MonsterBot.Whitelist                = (file.Exists("d_whitelist.txt", "DATA") and util.JSONToTable(file.Read("d_whitelist.txt", "DATA"))) or {}
MonsterBot.AimKey                   = (file.Exists("d_aimkey.txt", "DATA") and tonumber(file.Read("d_aimkey.txt", "DATA"))) or KEY_LALT
MonsterBot.Triggerkey               = (file.Exists("d_trigkey.txt", "DATA") and tonumber(file.Read("d_trigkey.txt", "DATA"))) or KEY_LALT
MonsterBot.Phrases                  = {
        " Monsterbot";
        " Monsterbot";
        " Monsterbot";
        " Monsterbot";
}
 
MonsterBot.Keys = {
"KEY_0", "KEY_1", "KEY_2", "KEY_3", "KEY_4", "KEY_5",
"KEY_6", "KEY_7", "KEY_8", "KEY_9", "KEY_A", "KEY_B", "KEY_C",
"KEY_D", "KEY_E", "KEY_F", "KEY_G", "KEY_H", "KEY_I", "KEY_J",
"KEY_K", "KEY_L", "KEY_M", "KEY_N", "KEY_O", "KEY_P", "KEY_Q",
"KEY_R", "KEY_S", "KEY_T", "KEY_U", "KEY_V", "KEY_W", "KEY_X",
"KEY_Y", "KEY_Z", "KEY_PAD_0", "KEY_PAD_1", "KEY_PAD_2", "KEY_PAD_3",
"KEY_PAD_4", "KEY_PAD_5", "KEY_PAD_6", "KEY_PAD_7", "KEY_PAD_8", "KEY_PAD_9",
"KEY_PAD_DIVIDE", "KEY_PAD_MULTIPLY", "KEY_PAD_MINUS", "KEY_PAD_PLUS", "KEY_PAD_ENTER",
"KEY_PAD_DECIMAL", "KEY_LBRACKET", "KEY_RBRACKET", "KEY_SEMICOLON", "KEY_APOSTROPHE",
"KEY_BACKQUOTE", "KEY_COMMA", "KEY_PERIOD", "KEY_SLASH", "KEY_BACKSLASH", "KEY_MINUS",
"KEY_EQUAL", "KEY_ENTER", "KEY_SPACE", "KEY_BACKSPACE", "KEY_TAB", "KEY_CAPSLOCK",
"KEY_NUMLOCK", "KEY_ESCAPE", "KEY_SCROLLLOCK", "KEY_INSERT", "KEY_DELETE", "KEY_HOME",
"KEY_END", "KEY_PAGEUP", "KEY_PAGEDOWN", "KEY_BREAK", "KEY_LSHIFT", "KEY_RSHIFT",
"KEY_LALT", "KEY_RALT", "KEY_LCONTROL", "KEY_RCONTROL", "KEY_LWIN", "KEY_RWIN",
"KEY_APP", "KEY_UP", "KEY_LEFT", "KEY_DOWN", "KEY_RIGHT", "KEY_F1", "KEY_F2",
"KEY_F3", "KEY_F4", "KEY_F5", "KEY_F6", "KEY_F7", "KEY_F8", "KEY_F9",
"KEY_F10", "KEY_F11", "KEY_F12", "KEY_CAPSLOCKTOGGLE", "KEY_NUMLOCKTOGGLE",
"KEY_SCROLLLOCKTOGGLE"
};
 
for k,v in pairs(MonsterBot.Normal) do
        if MonsterBot.Settings[k] == nil then
                MonsterBot.Settings = MonsterBot.Normal
                -- so that if a new key is added to the normal config, the Settings will reset
        end
end
 
-- functions
function MonsterBot.Alert(str)
        chat.AddText(Color(255,0,0,255), "[MonsterBot] ", Color(100,100,100,255), str)
        chat.PlaySound()
end
function MonsterBot.Update(x,y,z, ok)
        if x == "setting" then
                MonsterBot.Settings[y] = z
                if ok == true then
                        file.Write("d_settings.txt", util.TableToJSON(MonsterBot.Settings))
                end
        elseif x == "entity" then
                file.Write("d_entities.txt", util.TableToJSON(MonsterBot.Entities))
        elseif x == "friend" then
                file.Write("d_whitelist.txt", util.TableToJSON(MonsterBot.Whitelist))
        end
        if not(file.Exists("d_aimkey.txt", "DATA")) then file.Write("d_aimkey.txt", "") end
        if not(file.Exists("d_trigkey.txt", "DATA")) then file.Write("d_trigkey.txt", "") end
end
function MonsterBot.ESPCheck(typ, v)
        if typ == "player" then
                if v:Alive() && v:Health() >= 1 && v ~= LocalPlayer() /*&& /*LocalPlayer():Alive() &&*/ /*LocalPlayer():Team() ~= TEAM_SPECTATOR*/ then
                        return true
                end
        elseif typ == "entity" then
                if IsValid(v) then
                        return true
                end
        end
        return false
end
function MonsterBot.ESPDistance(typ, v)
        if typ == "player" then
                if MonsterBot.Settings["esp_player_dist"] >= 16000 then
                        return true
                elseif v:GetPos():Distance(LocalPlayer():GetPos()) < (MonsterBot.Settings["esp_player_dist"]) then
                        return true
                end
        elseif typ == "entity" then
                if MonsterBot.Settings["esp_entity_dist"] >= 16000 then
                        return true
                elseif v:GetPos():Distance(LocalPlayer():GetPos()) < (MonsterBot.Settings["esp_entity_dist"]) then
                        return true
                end
        end
        return false
end
function MonsterBot.GetShootPos(ent)
        local eyes = ent:LookupAttachment("eyes");
        if(eyes ~= 0) then
                eyes = ent:GetAttachment(eyes);
                if(eyes and eyes.Pos) then
                        return eyes.Pos, eyes.Ang;
                end
        end
end
function MonsterBot.Visible(ent)
        local pos = LocalPlayer():GetShootPos()
        local ang = LocalPlayer():GetAimVector()
        local trace = {start = LocalPlayer():GetShootPos(), endpos = MonsterBot.GetShootPos(ent), filter = {LocalPlayer(), ent}, mask = 1174421507};
        local tr = util.TraceLine(trace);
        return(tr.Fraction == 1);
end
function MonsterBot.Whitelisted(ent)
        if MonsterBot.Whitelist[ent:SteamID()] then return true
        else return false end
end
function MonsterBot.CanTarget(v)
        if v:IsPlayer() then
                if (MonsterBot.Visible(v) and (not MonsterBot.Whitelisted(v)) and v:Alive() and (v:Health() > 0) and v:Team() ~= TEAM_SPECTATOR) then
                        if (v ~= LocalPlayer() and LocalPlayer():Alive() and LocalPlayer():Team() ~= TEAM_SPECTATOR) then
                                if not(MonsterBot.Settings["aimbot_friendly_fire"]) then
                                        if (v:Team() ~= LocalPlayer():Team()) then
                                                return true
                                        end
                                else
                                        return true
                                end
                        end
                end
        end
        return false
end
 
function MonsterBot.Ents()
        local t = {}
        for k,v in pairs(ents.GetAll()) do
                if IsValid(v) and not(table.HasValue(t, v:GetClass())) then
                        table.insert(t, v:GetClass())
                end
        end
        table.sort(t, function(a,b) return a < b end)
 
        return t
end
-- intro
MonsterBot.Alert("MonsterBot loaded successfully! Hold TAB and Q to open the menu!")
-- fonts
surface.CreateFont("monsfont", {
        font    =       "impact",
        size    =       64
});
surface.CreateFont("monsfontesp1", {
        font="TabLarge",
        size=13,
        weight=700
});
surface.CreateFont("monsfontesp2", {
        font="TabLarge",
        size=10,
        weight=700
});
surface.CreateFont("monsfontesp3", {
        font="verdana",
        size=20,
        weight=700
});
-- short vars
local menu                              = MonsterBot.Menu
local current                   = MonsterBot.Current
local alive                             = MonsterBot.Alive
local normal                    = MonsterBot.Normal
local settings                  = MonsterBot.Settings
local entities                  = MonsterBot.Entities
local whitelist                 = MonsterBot.Whitelist
local phrases                   = MonsterBot.Phrases
local espcheck                  = MonsterBot.ESPCheck
local espdistance               = MonsterBot.ESPDistance
local G                                 = table.Copy(_G)
local R                                 = table.Copy(_R)
-- testing
/*G.rawset(_G, "__metatable", false)
G.rawset(_G, "RunConsoleCommand", MonsterBot.RCC)
G.setmetatable(_G, {
        __index = function(t , k)
                if(k == "hook") then
                        return G.hook;
                end
                if(k == "require") then
                        return G.require;
                end
                if(k == "concommand") then
                        return G.concommand;
                end
                if(k == "engineConsoleCommand") then
                        return G.engineConsoleCommand;
                end
                if(k == "RunConsoleCommand") then
                        return MonsterBot.RCC;
                end
                if(k == "RunString") then
                        return G.RunString;
                end
                if(k == "RunStringEx") then
                        return G.RunStringEx;
                end
        end,
        __metatable = true,
});
 
function MonsterBot.RCC(cmd, ...)
        MonsterBot.Alert("cmd = "..cmd.." ... = ")
        return G.RunConsoleCommand(cmd, ...);
end*/
-- menu
local function AddTab(txt, tab, func)
        menu.c = menu.c + 1 -- increase the counter for the amount of tabs
        local panel
        if tab and tab == true then
                panel = vgui.Create("DPanel", menu.frame);
                panel:SetPos(120,25);
                panel:SetSize(376,406);
                if menu.Current == txt then
                        panel:SetVisible(true)
                else
                        panel:SetVisible(false)
                end
                panel.Paint = function()
                        surface.SetDrawColor( 10, 10, 10, 255 )
                        surface.DrawOutlinedRect( 0, 0, panel:GetWide() - 1, panel:GetTall() - 1)
                        draw.SimpleText(string.upper(txt), "monsfont", 10, 5, Color(210, 210, 210, 255), TEXT_ALIGN_LEFT);
                end
        end
        local button = vgui.Create("DButton", menu.buttons);
        button:SetText(txt);
        button:SetSize(80, 20);
        button:SetPos(15, -15+(25*menu.c));
        button:SetTextColor(color_white)
        button.Paint = function(self)
                surface.SetDrawColor(100,100,100,220)
                surface.DrawRect(0, 0,self:GetSize())
                surface.SetDrawColor(0,0,0,255)
                surface.DrawOutlinedRect(0,0,self:GetSize())
        end
        button.DoClick = func or (tab and tab == true and function()
                for k,v in pairs(menu.t) do
                        if v ~= panel then
                                v:SetVisible(false)
                        end
                end
                panel:SetVisible(true)
                menu.Current = txt
                surface.PlaySound("ambient/levels/canals/drip4.wav");
        end)
        return panel, button;
end
 
local function AddFeature(id, parent, typ, name, setting, o1, o2)
        if not parent then return end
        if typ == "button" then
                local label = vgui.Create("DLabel", parent)
                label:SetText(name)
                label:SetPos(5,(55+(id*25)))
                label:SizeToContents(false)
                local button = vgui.Create("DButton", parent)
                if MonsterBot.Settings[setting] == true then
                        button:SetText("enabled")
                else
                        button:SetText("disabled")
                end
                button:SetSize(80,20)
                if not id then
                        button:SetPos(285,45)
                else
                        button:SetPos(285,(55+(id*25)))
                end
                button.DoClick = function()
                        if button:GetText() == "enabled" then
                                button:SetText("disabled"); MonsterBot.Update("setting", setting, false, true)
                        else
                                button:SetText("enabled"); MonsterBot.Update("setting", setting, true, true)
                        end
                end
                button:SetTextColor(color_white)
                button.Paint = function(self)
                        surface.SetDrawColor(100,100,100,220)
                        surface.DrawRect(0, 0,self:GetSize())
                        surface.SetDrawColor(0,0,0,255)
                        surface.DrawOutlinedRect(0,0,self:GetSize())
                end
                return button,label
        elseif typ == "slider" then
                local slider = vgui.Create("DNumSlider", parent)
                slider:SetPos(5, (45+(id*25)))
                slider:SetText(name)
                slider:SetMinMax(o1, o2)
                slider:SetWide(372.5)
                slider:SetDecimals( 0 )
                slider:SetFGColor(255,255,255,255)
                slider:SetBGColor(255,255,255,255)
                slider:SetValue(MonsterBot.Settings[setting])
                slider.OnValueChanged = function(panel, value)
                        local c = tonumber(value)
                        MonsterBot.Update("setting", setting, math.Round(c), true)
                end
                return slider;
        end
end
 
local function AddButton(parent, text, posx, posy, func)
        local button = vgui.Create("DButton", parent)
        button:SetText(text)
        button:SetSize(80,20)
        button:SetPos(posx,posy)
        button:SetTextColor(color_white)
        button.DoClick = func or function() end
        button.Paint = function(self)
                surface.SetDrawColor(100,100,100,220)
                surface.DrawRect(0, 0,self:GetSize())
                surface.SetDrawColor(0,0,0,255)
                surface.DrawOutlinedRect(0,0,self:GetSize())
        end
        return button
end
 
local function DrawMenu()
        if(menu.frame) then menu.frame:Remove(); menu.frame = nil; end
 
        menu.c = 0
 
        menu.frame = vgui.Create("DFrame");
        --menu.frame:SetPos(ScrW()/2-184, ScrH()/2-155);
        menu.frame:SetSize(500, 435);
        menu.frame:Center()
        menu.frame:SetTitle("MonsterBot"..MonsterBot.Phrases[math.random(1, table.Count(MonsterBot.Phrases))]);
        menu.frame.Paint = function()
                surface.SetDrawColor(138,132,132,150)
                surface.DrawRect(0, 0,menu.frame:GetWide(),menu.frame:GetTall())
                surface.SetDrawColor(0,0,0,255)
                surface.DrawOutlinedRect(0,0,menu.frame:GetWide(),menu.frame:GetTall())
        end
        menu.frame:SetVisible(true);
        menu.frame:SetDraggable(true);
        menu.frame:SetSizable(false);
        menu.frame:ShowCloseButton(false);
        menu.frame:SetBackgroundBlur(true)
        menu.frame:MakePopup();
 
        menu.close = vgui.Create("DButton", menu.frame)
        menu.close:SetFont('marlett')
        menu.close:SetText('r')
        menu.close:SetColor(Color(255, 255, 255))
        menu.close:SetSize(15, 15)
        menu.close:SetDrawBackground(false)
        menu.close:SetPos(menu.frame:GetWide() - 20, 5)
        menu.close.DoClick = function()
                menu.frame:Remove(); menu.frame = nil;
        end
 
        menu.buttons = vgui.Create("DPanel",menu.frame)
        menu.buttons:SetPos(5, 25)
        menu.buttons:SetSize(111,406)
        menu.buttons:SetVisible(true)
        menu.buttons.Paint = function()
                surface.SetDrawColor(10,10,10,255)
                surface.DrawOutlinedRect(0,0,110,405)
        end
 
        menu.t.mons = vgui.Create("DPanel", menu.frame);
        menu.t.mons:SetPos(120,25);
        menu.t.mons:SetSize(376,406);
        if menu.Current ~= nil then menu.t.mons:SetVisible(false) end
        menu.t.mons.Paint = function()
                surface.SetDrawColor( 10, 10, 10, 255 )
                surface.DrawOutlinedRect( 0, 0, menu.t.mons:GetWide() - 1, menu.t.mons:GetTall() - 1)
        end
 
        menu.t.a, menu.b.a              = AddTab("Aimbot",              true)
        menu.t.p, menu.b.p              = AddTab("Player ESP",  true)
        menu.t.e, menu.b.e              = AddTab("Entity ESP",  true)
        menu.t.m, menu.b.m              = AddTab("Misc.",               true)
        menu.t.g, menu.b.g              = AddTab("Game-mode",   true)
        --id, parent  , the type, the text , setting
        AddFeature(1, menu.t.a, "button", "Enabled", "aimbot")
        AddFeature(2, menu.t.a, "button", "Triggerbot", "triggerbot")
        AddFeature(3, menu.t.a, "button", "No-Recoil", "norecoil")
        AddFeature(4, menu.t.a, "button", "Friendly Fire", "aimbot_friendly_fire")
        AddFeature(5, menu.t.a, "slider", "FOV", "aimbot_fov", 0, 180)
 
        AddFeature(1, menu.t.p, "button", "Enabled", "esp_player")
        AddFeature(2, menu.t.p, "button", "Show Name", "esp_player_name")
        AddFeature(3, menu.t.p, "button", "Show Rank", "esp_player_rank")
        AddFeature(4, menu.t.p, "button", "Show Health", "esp_player_health")
        AddFeature(5, menu.t.p, "button", "Show Armor", "esp_player_armor")
        AddFeature(6, menu.t.p, "button", "Show Distance", "esp_player_showdist")
        AddFeature(7, menu.t.p, "slider", "Draw Distance", "esp_player_dist", 0, 16000)
        AddFeature(8, menu.t.p, "button", "Draw Glow Halo", "esp_player_glow")
 
        AddFeature(1, menu.t.e, "button", "Enabled", "esp_entity")
        AddFeature(2, menu.t.e, "slider", "Draw Distance", "esp_entity_dist", 0, 16000)
        AddFeature(3, menu.t.e, "button", "Draw Glow Halo", "esp_entity_glow")
 
        AddFeature(1, menu.t.m, "button", "Flashlight Spam [hold leftarrow]", "flashlight_spam")
        AddFeature(2, menu.t.m, "button", "[Third-Person]", "thirdperson")
        AddFeature(3, menu.t.m, "button", "Developer", "developer")
 
        if string.find(gmod.GetGamemode().Name, "DarkRP") then
                AddFeature(1, menu.t.g, "button", "God-mode Exploit (Costs in-game $$$)", "darkrp_god")
        elseif string.find(gmod.GetGamemode().Name, "Trouble in Terrorist Town") then
                AddFeature(1, menu.t.g, "button", "Display Death Notifications", "ttt_deathnotifs")
                AddFeature(2, menu.t.g, "button", "Show Alive Players (Scoreboard)", "ttt_showalive")
        elseif string.find(gmod.GetGamemode().Name, "PERP") then
                AddFeature(1, menu.t.g, "button", "Infinite Fuel","perp_Fuel")
        end
        local elist
        local elist2
        local elistc
        local elistc2
        local function makeelist()
                elist = vgui.Create("DComboBox", menu.t.e)
                elist:SetPos(10,menu.t.e:GetTall()-43)
                elist:SetSize(130,20)
                for k,v in pairs(MonsterBot.Ents()) do
                        if not(MonsterBot.Entities[v]) then
                                local i = elist:AddChoice(v)
                        end
                end
                elist.OnSelect = function(index,value,data)
                        print(data)
                        elist2 = data
                end
        end
        local function makeelistc()
                elistc = vgui.Create("DComboBox", menu.t.e)
                elistc:SetPos(235, menu.t.e:GetTall()-43)
                elistc:SetSize(130,20)
                for k,v in pairs(MonsterBot.Entities) do
                        local i = elistc:AddChoice(v)
                end
                elistc.OnSelect = function(index,value,data)
                        elistc2 = data
                end
        end
        makeelist()
        makeelistc()
        AddButton(menu.t.e, "Add Entity", 35, menu.t.e:GetTall()-23, function()
                if(elist2) then
                        for k,v in pairs(MonsterBot.Ents()) do
                                if (v == elist2) then
                                        print(v)
                                        table.insert(MonsterBot.Entities, v)
                                        MonsterBot.Update("entity")
                                end
                        end
                end
                makeelist()
                makeelistc()
        end)
        AddButton(menu.t.e, "Remove Entity", 260, menu.t.e:GetTall()-23, function()
                if(elistc2) then
                        for k,v in pairs(MonsterBot.Entities) do
                                if (v == elistc2) then
                                        MonsterBot.Entities[k] = nil;
                                        MonsterBot.Update("entity")
                                end
                        end
                end
                makeelist()
                makeelistc()
        end)
        /*local flist
        local flist2
        local flistc
        local flistc2
        local function makeflist()
                flist = vgui.Create("DComboBox", menu.t.a)
                flist:SetPos(10,menu.t.a:GetTall()-43)
                flist:SetSize(130,20)
                for k,v in pairs(player.GetAll()) do
                        if v ~= LocalPlayer() then
                                if not(MonsterBot.Whitelist[v:SteamID()]) then
                                        local i = flist:AddChoice(v:Nick())
                                end
                        end
                end
                flist.OnSelect = function(index,value,data)
                        print(data)
                        elist2 = data
                end
        end
        local function makeflistc()
                flistc = vgui.Create("DComboBox", menu.t.a)
                flistc:SetPos(235, menu.t.a:GetTall()-43)
                flistc:SetSize(130,20)
                for k,v in pairs(player.GetAll()) do
                        if v ~= LocalPlayer() then
                                if MonsterBot.Whitelist[v:SteamID()] then
                                        local i = flistc:AddChoice(v:Nick())
                                end
                        end
                end
                flistc.OnSelect = function(index,value,data)
                        flistc2 = data
                end
        end
        makeflist()
        makeflistc()
        AddButton(menu.t.a, "Add Friend", 35, menu.t.a:GetTall()-23, function()
                if(flist2) then
                        for k,v in pairs(player.GetAll()) do
                                if (v:Nick() == flist2) then
                                        print(v:Nick())
                                        table.insert(MonsterBot.Whitelist, v:SteamID())
                                        PrintTable(MonsterBot.Whitelist)
                                        MonsterBot.Update("friend")
                                end
                        end
                end
                makeflist()
                makeflistc()
        end)
        AddButton(menu.t.a, "Remove Friend", 260, menu.t.a:GetTall()-23, function()
                if(flistc2) then
                        for k,v in pairs(MonsterBot.Whitelist) do
                                if (v:SteamID() == flistc2) then
                                        MonsterBot.Whitelist[k] = nil;
                                       MonsterBot.Update("friend")
                                end
                        end
                end
                makeflist()
                makeflistc()
        end)*/
end
 
hook.Add("HUDPaint", "catHUD", function()
        if MonsterBot.Settings["esp_player"] or MonsterBot.Settings["esp_entity"] then
                for k,v in pairs(ents.GetAll()) do
                        if MonsterBot.Settings["esp_player"] && v:IsPlayer() then
                                if(espcheck("player", v) and espdistance("player", v))then
                                        local ESP = (v:EyePos()):ToScreen()
                                        local name,health,rank,col,distance = "","","","",""
                                        local outcol = Color(0,0,0,255)
                                        local white = Color(255,255,255,255)
                                        local outcol2 = outcol
                                        if MonsterBot.Settings["esp_player_name"] then
                                                if v.GetRPName then name = v:GetRPName()
                                                else name = v:Nick() end
                                        end
                                        if v:Nick() ~= name then rank = " "..v:Nick() end
                                        if v.SteamName and name ~= v:SteamName() then rank = " "..v:SteamName() end
                                        if MonsterBot.Settings["esp_player_rank"] then
                                                if v:IsSuperAdmin() then
                                                        rank = "[Super Admin]"..rank
                                                elseif v:IsAdmin() then
                                                        rank = "[Admin]"..rank
                                                elseif v:IsUserGroup("moderator") or v:IsUserGroup("mod") then
                                                        rank = "[Moderator]"..rank
                                                elseif v:IsUserGroup("vip") or v:IsUserGroup("donator") then
                                                        rank = "[Donator]"..rank
                                                end
                                        end
                                        if MonsterBot.Settings["esp_player_health"] and not(MonsterBot.Settings["esp_player_armor"]) then
                                                health = v:Health().."H"
                                        elseif MonsterBot.Settings["esp_player_armor"] and not(MonsterBot.Settings["esp_player_health"]) then
                                                health = v:Armor().."A"
                                        elseif MonsterBot.Settings["esp_player_armor"] and MonsterBot.Settings["esp_player_health"] then
                                                health = v:Health().. "H - "..v:Armor().."A"
                                        end
                                        if MonsterBot.Settings["esp_player_showdist"] then
                                                distance = v:GetPos():Distance(LocalPlayer():GetPos())
                                                distance = math.Round(distance).." m"
                                        end
                                        col = team.GetColor(v:Team())
                                        if (not col) or (col == nil) then
                                                col = Color(255,255,255,255)
                                        end
                                        if(col.r <= 50 and col.g <= 50 and col.b <= 50) then
                                                outcol2 = Color(200,200,200,255)
                                        end
                                        if col.a <= 50 then
                                                col = Color(col.r,col.g,col.b, 255)
                                        end
                                        draw.SimpleTextOutlined(rank, "monsfontesp2", ESP.x, ESP.y -46, col, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, outcol2)
                                        draw.SimpleTextOutlined(name, "monsfontesp1", ESP.x, ESP.y - 34, col, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, outcol2)
                                        if health ~= "" then
                                                draw.SimpleTextOutlined(health, "monsfontesp2", ESP.x, ESP.y -22, white, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, outcol)
                                                draw.SimpleTextOutlined(distance, "monsfontesp2", ESP.x, ESP.y - 10, white, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, outcol)
                                        else
                                                draw.SimpleTextOutlined(distance, "monsfontesp2", ESP.x, ESP.y - 22, white, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, outcol)
                                        end
                                        if MonsterBot.Settings["esp_player_glow"] then
                                                halo.Add({v}, col, 2, 2, 1, true, true)
                                        end
                                end
                        end
                        if (MonsterBot.Settings["esp_entity"] and espcheck("entity", v) and espdistance("entity", v))then
                                if table.HasValue(MonsterBot.Entities, v:GetClass()) then
                                        local ESP = (v:EyePos()):ToScreen()
                                        draw.SimpleTextOutlined(v:GetClass(), "monsfontesp1", ESP.x, ESP.y - 46, Color(255,0,0,255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, Color(0,0,0,255))
                                        if MonsterBot.Settings["esp_entity_glow"] then
                                                halo.Add({v}, Color(255,0,0,255), 2, 2, 1, true, true)
                                        end
                                end
                        end
                end
        end
end)
        if input.IsKeyDown(KEY_TAB) and string.find(gmod.GetGamemode().Name, "Trouble in Terrorist Town") and MonsterBot.Settings["ttt_showalive"] then
                local t = {}
                for k,v in pairs(player.GetAll()) do
                        if v:IsValid() and v:Team() ~= TEAM_SPECTATOR and MonsterBot.Alive[v:UniqueID()] == true and v ~= LocalPlayer() then
                                table.insert(t, v)
                        end
                end
 
                local height = 30
                local offs = 30
                for i = 1, #t do
                        height = height + 15;
                end
                surface.SetDrawColor(0,0,0,255)
                surface.DrawRect(ScrW()-185, ScrH()-ScrH()+5, 175, height);
 
                surface.SetTextColor(Color(255, 255, 255, 255));
                surface.SetTextPos(ScrW()-125, ScrH()-ScrH()+5);
                surface.SetFont("Trebuchet24");
                surface.DrawText("ALIVE");
 
                surface.SetFont("Trebuchet18");
                for k,v in pairs(t) do
                        local nick = string.sub(v:Nick(), 0, 22);
                        surface.SetTextPos(ScrW()-175, ScrH()-ScrH()+offs)
                        surface.DrawText(nick)
                        offs = offs + 15
                end
        end
hook.Add("CalcView", "catVIEW", function(ply, pos, angles, fov)
        if MonsterBot.Settings["thirdperson"] and LocalPlayer():Alive() then
                local view = {}
                view.origin = pos-(angles:Forward()*100)
                view.angles = angles
                view.fov = fov
 
                return view
        end
end)
hook.Add("ShouldDrawLocalPlayer", "catLOCAL", function()
        if MonsterBot.Settings["thirdperson"] then
                return true
        end
end)
hook.Add("Think", "catBOT", function()
        if(input.IsKeyDown(KEY_TAB) && input.IsKeyDown(KEY_Q) && !menu.frame)then
                DrawMenu()
        elseif(menu.frame && input.IsKeyDown(KEY_ESCAPE))then
                menu.frame:Remove();menu.frame = nil
        end
 
timer.Remove("DoFuel");
timer.Create("DoFuel",5,0,function()
        if string.find(gmod.GetGamemode().Name, "PERP") and MonsterBot.Settings["perp_fuel"] then
                DoFuel();
        end
end)
 
        if MonsterBot.Settings["flashlight_spam"] and input.IsKeyDown(KEY_LEFT) then
                RunConsoleCommand("impulse", "100")
                end
 
        if(MonsterBot.Settings["triggerbot"] && (not MonsterBot.Settings["developer"] and input.IsKeyDown(MonsterBot.Triggerkey)) or (MonsterBot.Settings["developer"] and input.IsMouseDown(MOUSE_4))) then
                local pos = LocalPlayer():GetShootPos()
                local ang = LocalPlayer():GetAimVector()
                local tracedata = {}
                tracedata.start = pos
                tracedata.endpos = pos+(ang*9999999999999)
                local trace = util.TraceLine(tracedata)
                if(trace.HitNonWorld) then
                        target = trace.Entity
                        if(target:IsPlayer() and MonsterBot.CanTarget(target)) then
                                RunConsoleCommand("+attack")
                                timer.Simple(0.000000000000000000001, function() RunConsoleCommand("-attack") end)
                        end
                end
        end
        if(MonsterBot.Settings["aimbot"] && (not MonsterBot.Settings["developer"] and input.IsKeyDown(MonsterBot.AimKey)) or (MonsterBot.Settings["developer"] and input.IsKeyDown(KEY_LALT))) then
                for k,v in pairs(player.GetAll()) do
                        if MonsterBot.CanTarget(v) then
                                local head = v:LookupBone("ValveBiped.Bip01_Head1")
                                if head ~= nil then
                                        local fov = MonsterBot.Settings["aimbot_fov"]
                                        if fov == 0 then
                                                local headpos,targetheadang = v:GetBonePosition(head)
                                                LocalPlayer():SetEyeAngles((headpos - LocalPlayer():GetShootPos()):Angle())
                                        else
                                                local lpang = LocalPlayer():GetAngles();
                                                local ang = (v:GetPos() - LocalPlayer():GetPos()):Angle();
                                                local ady = math.abs(math.NormalizeAngle(lpang.y - ang.y))
                                                local adp = math.abs(math.NormalizeAngle(lpang.p - ang.p ))
                                                if not(ady > fov or adp > fov) then
                                                        local headpos,targetheadang = v:GetBonePosition(head)
                                                        if headpos != nil and targetheadang != nil then
                                                                LocalPlayer():SetEyeAngles((headpos - LocalPlayer():GetShootPos()):Angle())
                                                        end
                                                end
                                        end
                                end
                        end
                end
        end
        if (string.find(gmod.GetGamemode().Name, "Trouble in Terrorist Town") or _G.KARMA) and MonsterBot.Settings["ttt_deathnotifs"] then
                for k,v in pairs(player.GetAll()) do
                        if v:Alive() and not (MonsterBot.Alive[v:UniqueID()] == true) then
                                MonsterBot.Alive[v:UniqueID()] = true
                        elseif not v:Alive() and (MonsterBot.Alive[v:UniqueID()] == true) then
                                MonsterBot.Alive[v:UniqueID()] = false
                                MonsterBot.Alert(v:Nick().. " has died!")
                        end
                end
        end
        for k,v in pairs(player.GetAll()) do
                if v and v:IsValid() and v:IsPlayer() and v.GetObserverTarget and v:GetObserverTarget() and v:GetObserverTarget():IsValid() and v:GetObserverTarget():IsPlayer() and v:GetObserverTarget() == LocalPlayer() then
                        if not(MonsterBot.Spectators[v:UniqueID()] == true) then
                                MonsterBot.Spectators[v:UniqueID()] = true
                                MonsterBot.Alert(v:Nick().." began spectating you!")
                                surface.PlaySound("buttons/blip1.wav")
                        end
                end
                if MonsterBot.Spectators[v:UniqueID()] == true then
                        if not (v.GetObserverTarget and v:GetObserverTarget() and v:GetObserverTarget():IsValid() and v:GetObserverTarget():IsPlayer() and v:GetObserverTarget() == LocalPlayer()) then
                                MonsterBot.Spectators[v:UniqueID()] = nil
                                MonsterBot.Alert(v:Nick().." stopped spectating you.")
                                surface.PlaySound("buttons/blip1.wav")
                        end
                end
        end
        for k,v in pairs(MonsterBot.Spectators) do
                local play = player.GetByUniqueID(k)
                if not play then
                        MonsterBot.Spectators[k] = nil
                        MonsterBot.Alert(v:Nick().." stopped spectating you.")
                        surface.PlaySound("buttons/blip1.wav")
                end
        end
end)
if MonsterBot.Settings["norecoil"] and LocalPlayer():GetActiveWeapon().Primary then
 LocalPlayer():GetActiveWeapon().Primary.Recoil = 0
                end
if MonsterBot.Settings["developer"] then
        concommand.Add("blowc4test", function()
                for k, v in pairs(ents.FindByClass("ttt_c4")) do
                        RunConsoleCommand("ttt_c4_disarm", v:EntIndex(), math.random(1000, 5000))
                end
        end)
        concommand.Add("debug", function()
                local pcash,gname = "", gmod.GetGamemode().Name
                print("Game-mode:\n    "..gname)
                if string.find(gname, "DarkRP") then
                        print("Player Cash Amounts")
                        for k,v in pairs(player.GetAll()) do
                                if not(v.DarkRPVars and v.DarkRPVars.money)and(darkrpvar == true) then
                                        darkrpvar = false
                                end
                                if v ~= LocalPlayer() then
                                        pcash = pcash.."    "..v:Nick().." - $"..v.DarkRPVars.money.."\n"
                                end
                        end
                        if pcash ~= "" then
                                print(pcash)
                        end
                elseif string.find(gname, "PERP") then
                        local b = GetGlobalInt("perp_druggy_buy", 0);
                        local s = GetGlobalInt("perp_druggy_sell", 0);
                        if b then print("Buying: "..b) end
                        if s then print("Selling: "..s) end
                end
                if LocalPlayer().PS_GetPoints then
                        print("Player Pointshop Points")
                        for k,v in pairs(player.GetAll()) do
                                if v ~= LocalPlayer() and v.PS_GetPoints then
                                        print("    "..v:Nick().." - "..v:PS_GetPoints().." points")
                                end
                        end
                end
                if LocalPlayer().GetActiveWeapon and LocalPlayer():GetActiveWeapon() ~= nil and IsValid(LocalPlayer():GetActiveWeapon()) then
                        print("Current Weapon")
                        print("    Class: "..LocalPlayer():GetActiveWeapon():GetClass())
                end
                local pos = LocalPlayer():GetShootPos()
                local ang = LocalPlayer():GetAimVector()
                local tracedata = {}
                tracedata.start = pos
                tracedata.endpos = pos+(ang*9999999999999)
                local trace = util.TraceLine(tracedata)
                if(trace.HitNonWorld) then
                        target = trace.Entity
                        print("Entity Info")
                        print("    Class: "..target:GetClass())
                        print("    Model: "..target:GetModel())
                end
        end)
end
 
// Aim Assist //
 
aimassist = {}
 
bot = {}
aimassist.Version = 1.0
aimassist.Owner = LocalPlayer()
aimassist.Enabled = false
aimassist.Target = NULL
 
function aimassist.Think() -- Starting the function
if ( aimassist.Enabled ) then
local ply = LocalPlayer() -- Getting ourselves
local trace = util.GetPlayerTrace( ply ) -- Player Trace part. 1
local traceRes = util.TraceLine( trace ) -- Player Trace part. 2
if traceRes.HitNonWorld then -- If the aimbot aims at something that isn't the map..
        local target = traceRes.Entity -- It's obviously an entity.
        if target:IsPlayer() then -- But it must be a player.
                local targethead = target:LookupBone("ValveBiped.Bip01_Head1") -- In this aimassist we only aim for the head.
                local targetheadpos,targetheadang = target:GetBonePosition(targethead) -- Get the position/angle of the head.
                ply:SetEyeAngles((targetheadpos - ply:GetShootPos()):Angle()) -- And finally, we snap our aim to the head of the target.
        end
end
end
 
 
                                                                        if ( aimassist.AttackState ) then
                                                                                        local targethead = target:LookupBone()
                                                                                        aimassist.AttackState = false
                                                                        end
                                                end
 
hook.Add( "Think", "aimassistThink", aimassist.Think )
hook.Add("Think","aimassist",aimassist)
 
function aimassist.Command( ply, command, args )
        if ( #args == 0 ) then
                        aimassist.Enabled = !aimassist.Enabled
                        if ( aimassist.Enabled ) then
                                        LocalPlayer():ChatPrint( "[AimAssist] Enabled.\n" )
                        else
                                       LocalPlayer():ChatPrint( "[AimAssist] Disabled.\n" )
                        end
                end
        end
 
concommand.Add( "Monster_aimassist",aimassist.Command )
 
// TTT Prop-Kill //
 
function MagnetoThrow()
-- Nice and easy, turn it slow 180
timer.Simple(.02,Turn)
timer.Simple(.04,Turn)
timer.Simple(.06,Turn)
timer.Simple(.08,Turn)
timer.Simple(.10,Turn)
timer.Simple(.12,Turn)
timer.Simple(.14,Turn)
timer.Simple(.16,Turn)
timer.Simple(.18,Turn)
timer.Simple(.20,Turn)
timer.Simple(.22,Turn)
timer.Simple(.24,Turn)
timer.Simple(.26,Turn)
timer.Simple(.28,Turn)
timer.Simple(.30,Turn)
timer.Simple(.32,Turn)
timer.Simple(.34,Turn)
timer.Simple(.36,Turn)
-- OH MY GOD WHIP AROUND 180
timer.Simple(.46,TurnBack)
-- And deliver the final blow by pressing right click
timer.Simple(.7,function() RunConsoleCommand("+attack") end)
timer.Simple(.72,function() RunConsoleCommand("-attack") end)
end
 
function Turn()
-- Turn function
LocalPlayer():SetEyeAngles(LocalPlayer():EyeAngles ()-Angle(0,10,0))
end
 
function TurnBack()
-- Turn 180 function
LocalPlayer():SetEyeAngles(LocalPlayer():EyeAngles ()-Angle(0,180,0))
end
-- Making it a console command
concommand.Add("ThrowMagneto",MagnetoThrow)
 
// Free Cam //
 
local MBN = {}
 
MBN.Enabled = false
MBN.ViewOrigin = Vector( 0, 0, 0 )
MBN.ViewAngle = Angle( 0, 0, 0 )
MBN.Velocity = Vector( 0, 0, 0 )
 
function MBN.CalcView( ply, origin, angles, fov )
        if ( !MBN.Enabled ) then return end
        if ( MBN.SetView ) then
                MBN.ViewOrigin = origin
                MBN.ViewAngle = angles
               
                MBN.SetView = false
        end
        return { origin = MBN.ViewOrigin, angles = MBN.ViewAngle }
end
hook.Add( "CalcView", "MonsterBot-Noclip", MBN.CalcView )
 
function MBN.CreateMove( cmd )
        if ( !MBN.Enabled ) then return end
       
        // Add and reduce the old velocity.
        local time = FrameTime()
        MBN.ViewOrigin = MBN.ViewOrigin + ( MBN.Velocity * time )
        MBN.Velocity = MBN.Velocity * 0.95
       
        // Rotate the view when the mouse is moved.
        local sensitivity = 0.022
        MBN.ViewAngle.p = math.Clamp( MBN.ViewAngle.p + ( cmd:GetMouseY() * sensitivity ), -89, 89 )
        MBN.ViewAngle.y = MBN.ViewAngle.y + ( cmd:GetMouseX() * -1 * sensitivity )
       
        // What direction we're going to move in.
        local add = Vector( 0, 0, 0 )
        local ang = MBN.ViewAngle
        if ( cmd:KeyDown( IN_FORWARD ) ) then add = add + ang:Forward() end
        if ( cmd:KeyDown( IN_BACK ) ) then add = add - ang:Forward() end
        if ( cmd:KeyDown( IN_MOVERIGHT ) ) then add = add + ang:Right() end
        if ( cmd:KeyDown( IN_MOVELEFT ) ) then add = add - ang:Right() end
        if ( cmd:KeyDown( IN_JUMP ) ) then add = add + ang:Up() end
        if ( cmd:KeyDown( IN_DUCK ) ) then add = add - ang:Up() end
       
        // Speed.
        add = add:GetNormal() * time * 100
        if ( cmd:KeyDown( IN_SPEED ) ) then add = add * 2 end
       
        MBN.Velocity = MBN.Velocity + add
       
        // This stops us looking around crazily while spiritwalking.
        if ( MBN.LockView == true ) then
                MBN.LockView = cmd:GetViewAngles()
        end
        if ( MBN.LockView ) then
                cmd:SetViewAngles( MBN.LockView )
        end
       
        // This stops us moving while spiritwalking.
        cmd:SetForwardMove( 0 )
        cmd:SetSideMove( 0 )
        cmd:SetUpMove( 0 )
end
hook.Add( "CreateMove", "MonsterBotNoclip", MBN.CreateMove )
 
function MBN.Toggle()
        MBN.Enabled = !MBN.Enabled
        MBN.LockView = MBN.Enabled
        MBN.SetView = true
       
        local status = { [ true ] = "ON", [ false ] = "OFF" }
        print( "MonsterBot-Noclip " .. status[ MBN.Enabled ] )
end
concommand.Add( "MBN_toggle", MBN.Toggle )
 
concommand.Add( "MBN_pos", function() print( MBN.ViewOrigin )
end )
 
// CrossHair //
 
local shouldDraw = true
 
local hzCross = CreateClientConVar("HZ_Crosshair","0",false)
 
function Crosshair1()
surface.SetDrawColor (235, 235, 235, 235)
surface.DrawLine(ScrW() / 2 - 10, ScrH() / 2, ScrW() / 2 + 11 , ScrH() / 2)
surface.DrawLine(ScrW() / 2 - 0, ScrH() / 2 - 10, ScrW() / 2 - 0 , ScrH() / 2 + 11)
end
hook.Add("HUDPaint","CustomCross",Crosshair1)
 
Color(0, 0, 255, 255)
 
// Laser Sight \\
 
function MonsterBot.Barrel( )
if GetConVarNumber( "misc_removelaser" ) >= 1 then return end
local ViewModel = LocalPlayer():GetViewModel()
local Attach = ViewModel:LookupAttachment( '1' )
if( !LocalPlayer():Alive() || LocalPlayer():GetActiveWeapon() == NULL ) then return; end
if ( Attach == 0 ) then Attach = ViewModel:LookupAttachment( 'muzzle' ) end
//if( !table.HasValue( LaserSightAllowed, LocalPlayer():GetActiveWeapon():GetClass() ) ) then return; end
cam.Start3D( EyePos(), EyeAngles() )
render.SetMaterial(Material("sprites/physbeam"))
render.DrawBeam( ViewModel:GetAttachment( Attach ).Pos, LocalPlayer():GetEyeTrace().HitPos, 5, 0, 0, Color(255, 255, 255, 255) )
local Size = math.random() * 1.35
render.SetMaterial(Material("sprites/redglow1"))
render.DrawQuadEasy(LocalPlayer():GetEyeTrace().HitPos, (EyePos() -  LocalPlayer():GetEyeTrace().HitPos):GetNormal(), 30, 30, Color(235,235,235,235) )
cam.End3D()
end
hook.Add( 'HUDPaint', '\2\3', MonsterBot.Barrel )
 
CreateClientConVar( "misc_removelaser", 0, true, false )
 
// BHOP \\
 
if CLIENT then
concommand.Add("+bhop",function()
hook.Add("Think","hook",function()
RunConsoleCommand(((LocalPlayer():IsOnGround() or LocalPlayer():WaterLevel() > 0) and "+" or "-").."jump")
end)
end)
 
concommand.Add("-bhop",function()
RunConsoleCommand("-jump")
hook.Remove("Think","hook")
end)
end
 
// PropKill \\
function Propkill()
local ply = LocalPlayer()
local Angles = LocalPlayer():EyeAngles()
LocalPlayer():SetEyeAngles(Angle(30, Angles.yaw + 180, Angles.roll))
timer.Create("spawn", 0.1, 1, function()
LocalPlayer():ConCommand("gm_spawn models/props_junk/sawblade001a.mdl")
LocalPlayer():ConCommand("+attack")
end)
timer.Create("jump", 0.15, 1, function()
LocalPlayer():ConCommand("+jump")
end)
timer.Create("turnback", 0.35, 1, function()    
LocalPlayer():SetEyeAngles(Angle(40, Angles.yaw, Angles.roll))
end)
timer.Create("release", 0.37, 1, function()
LocalPlayer():ConCommand("-attack")
end)
timer.Create("-jummp", 0.3, 1, function()
LocalPlayer():ConCommand("-jump")
end)
timer.Create("undo", 1.2, 1, function()        
LocalPlayer():ConCommand("undo")
end)
end
 
concommand.Add("propkill", Propkill)
 
// TDetector \\
 
if string.find(gmod.GetGamemode().Name, "Trouble in Terrorist Town") then
 
local matOverlay = Material( "sprites/glow08" )
local matTraitor = Material( "sprites/dot" )
local twep = {"spiderman's_swep", "weapon_ttt_trait_defilibrator", "weapon_ttt_xbow", "weapon_ttt_dhook", "weapon_awp", "weapon_ttt_ak47", "weapon_jihadbomb", "weapon_ttt_knife", "weapon_ttt_c4", "weapon_ttt_decoy", "weapon_ttt_flaregun", "weapon_ttt_phammer", "weapon_ttt_push", "weapon_ttt_radio", "weapon_ttt_sipistol", "weapon_ttt_teleport", "weapon_ttt_awp", "weapon_ttt_silencedsniper", "weapon_ttt_turtlenade", "weapon_ttt_death_station", "weapon_ttt_sg552", "weapon_ttt_tripmine"}
 
for _,v in pairs(player.GetAll()) do
       v.HatTraitor = nil
end
for _,v in pairs(ents.GetAll()) do
       v.HatESPTracked = nil
end
 
hook.Add("PostDrawOpaqueRenderables", "wire_animations_idle", function()
       if GAMEMODE.round_state != ROUND_ACTIVE then
               for _,v in pairs(player.GetAll()) do
                       v.HatTraitor = nil
               end
               for _,v in pairs(ents.GetAll()) do
                       v.HatESPTracked = nil
               end
               return
       end
       for _,v in pairs( ents.GetAll() ) do
               if v and IsValid(v) and (table.HasValue(twep, v:GetClass()) and !v.HatESPTracked) then
                       local pl = v.Owner
                       if pl and IsValid(pl) and pl:IsTerror() then
                               if pl:IsDetective() then
                                       v.HatESPTracked = true
                               else
                                       v.HatESPTracked = true
                                       pl.HatTraitor = true
                                       chat.AddText( pl, Color(255,125,0), " is a ",Color(255,0,0), "TRAITOR",Color(255,125,0), " with a ",Color(255,0,0),v:GetClass().."!")
                               end
                       end
               end
       end
         
 
               //Add a name for anyone we tracked
              // cam.Start2D()
                   //    local pos = (pl:GetPos()+Vector(0,0,100)):ToScreen()
                    //   draw.DrawText( pl:Nick(), "ScoreboardText", pos['x'], pos['y'], team.GetColor( pl:Team() ), TEXT_ALIGN_CENTER )
              // cam.End2D()
     //  end
end)
end