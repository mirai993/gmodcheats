--[[
	MOD/lua/HOSC Lite 1-0-0.lua [#31248 (#31248), 325535763, UID:287776704]
	*Ąx ΛΞ —(ArȼƮɨc | STEAM_0:0:92033036 <192.64.5.248:27005> | [26.07.14 05:50:48PM]
	===BadFile===
]]

-- HOSC 0.0 Hack
-- Coded by HOSC

if not CLIENT then return end
if C then _G.C = nil end 
local _R = debug.getregistry();

--[[--------------------------------------------
	Local Stuff that should optimise the cheat!
--]]--------------------------------------------
local cam				  = cam
local chat				  = chat
local draw				  = draw
local package			  = package
local player			  = player
local math				  = math
local render			  = render
local string			  = string
local surface			  = surface
local table				  = table
local team		 		  = team
local timer				  = timer
local util				  = util
local vgui				  = vgui
local Angle 			  = Angle
local Color 			  = Color
local EyeAngles			  = EyeAngles
local EyePos 			  = EyePos
local ipairs			  = ipairs
local pairs			 	  = pairs
local tobool			  = tobool
local tonumber			  = tonumber
local tostring			  = tostring
local type 				  = type
local unpack			  = unpack
local Vector 			  = Vector
local MsgN				  = MsgN
local IsValid 		  = IsValid
local RealFrameTime       = RealFrameTime
local CreateClientConVar  = CreateClientConVar
local CreateMaterial      = CreateMaterial
local AddConsoleCommand   = AddConsoleCommand
-------------Begin HOSCs Hacks Here------
local shouldbeam  = false
local HOSC = {}
local g = RVRM_g_RVRM
local status = HackStatus1
local HoSC = {}
local DH = {}
--[[--------------------------------------------
	Tables, bool list
--]]--------------------------------------------
red = Color(255,0,0)
blue = Color(0,0,255)
green = Color(0,255,0)
darkgreen = Color(0,128,0)
white = Color(255,255,255)
black = Color(0,0,0)
lightblue = Color(0,255,255)
darkblue = Color(0,0,128)
gold = Color(255,215,0)
-- HACK Status Tables
HackStatus1="Undetected"
HackStatus2="Detected"
HackStatus3="Unknown"
HOSCversion="0.0.1"


-- Bone Tables

HOSC.Bones = {
                "ValveBiped.Bip01_Head1",
                "ValveBiped.Bip01_Neck1",
                "ValveBiped.Bip01_Spine4",
                "ValveBiped.Bip01_Spine2",
                "ValveBiped.Bip01_Spine1",
                "ValveBiped.Bip01_Spine",
                "ValveBiped.Bip01_R_UpperArm",
                "ValveBiped.Bip01_R_Forearm",
                "ValveBiped.Bip01_R_Hand",
                "ValveBiped.Bip01_L_UpperArm",
                "ValveBiped.Bip01_L_Forearm",
                "ValveBiped.Bip01_L_Hand",
                "ValveBiped.Bip01_R_Thigh",
                "ValveBiped.Bip01_R_Calf",
                "ValveBiped.Bip01_R_Foot",
                "ValveBiped.Bip01_R_Toe0",
                "ValveBiped.Bip01_L_Thigh",
                "ValveBiped.Bip01_L_Calf",
                "ValveBiped.Bip01_L_Foot",
                "ValveBiped.Bip01_L_Toe0"
            }

DH.bools = {
                    ["aimactive"] = true,
                    ["aimteam"] = true,
                    ["aimmanuel"] = false,
                    ["aimautoshoot"] = false,
                    ["aimautoreload"] = false,
                    ["advert"] = false,
                    ["aimorg"] = false,
                    ["targetnpc"] = false,
                    ["targetplayer"] = true,
                    ["targetent"] = false,
                    ["checklos"] = true,
                    ["triggeractive"] = false,
                    ["aimantisnap"] = false,
                    ["espactive"] = true,
                    ["espchams"] = true,
                    ["espchams"] = true,
                    ["espplayers"] = true,
                    ["espnpcs"] = false,
                    ["espents"] = false,
                    ["espwireframe"] = false,
                    ["espsolid"] = true,
                    ["norecoil"] = true,
                    ["esphealth"] = true,
                    ["esparmor"] = true,
                    ["espteam"] = true,
                    ["espname"] = true,
                    ["esprpname"] = true,
                    ["esporg"] = true,
                    ["espadmin"] = true,
                    ["espweapon"] = true,
                    ["eyetracer"] = false,
                    ["miscbhop"] = true,
                    ["lognet"] = false,
                    ["logfile"] = false,
					["logbypass"] = false,
                    ["loghook"] = false,
                    ["logrcc"] = false,
                    ["logcc"] = false,
                    ["loggcv"] = false,
                    ["miscblockrcc"] = false,
                    ["miscblocknet"] = false,
                    ["printlog"] = false,
                    ["printconsole"] = false,
                    ["speedhack"] = false,
                    --["antiafk"] = false,
                    ["thirdperson"] = false,
                    ["autosave"] = true,
                    ["perp_infinite_fuel"] = true,
                    ["perp_drug_info"] = false,
                    ["player_info"] = false,
                    ["adminbox"] = true,
                    ["attackspam"] = false,
                    ["notifications"] = false,
                    ["show_spectators"] = true,
                    ["ttt_finder"] = true,
                    ["autosvcheat"] = true,
                    ["nosmoke"] = false,
                    ["fixscreen"] = false,
                    ["drawcrosshair"] = false,
                    ["fullbright"] = false,
                    ["map"] = false,
                    ["radar"] = false,
                    ["radar_outline"] = true,
                    ["radar_cross"] = true,
                    ["radar_names"] = false,
                }
     
                DH.vars = {
                    ["aimx"] = 7,
                    ["aimy"] = 1,
                    ["aimz"] = 61,
                    ["aimfov"] = 45,
                    ["aimdistance"] = 5000,
                    ["aimantisnap"] = 0.2,
                    ["espchamdist"] = 2000,
                    ["esptextdist"] = 15000,
                    ["thirdpersondist"] = 250,
                    ["leveloverview"] = 5,
                    ["radar_size"] = 200,
                    ["radar_pixrat"] = 15,
                }
				
                DH.binds = {
                    ["+aim"] = "KEY_F",
                    ["menu_toggle"] = "KEY_L",
                    ["+triggerbot"] = "KEY_T",
                    ["esp_toggle"] = "KEY_N",
                    ["+bhop"] = "KEY_SPACE",
                    ["+speed"] = "KEY_V",
                    ["thirdperson_toggle"] = "KEY_I",
                    ["map_toggle"] = "KEY_M",
                    ["zoom_in"] = "KEY_O",
                    ["zoom_out"] = "KEY_P",
                }
			
            
--[[--------------------------------------------
	Local Functions
--]]--------------------------------------------
        local function duplicateTable(tbl, lookup)
            local copy = {}
            
            for i, v in _G.pairs(tbl) do
                if _G.type(v) == "table" then
                    lookup = lookup or {}
                    lookup[tbl] = copy

                    if lookup[v] then
                        copy[i] = lookup[v]
                    else
                        copy[i] = duplicateTable(v, lookup)
                    end
                else
                    copy[i] = _G.rawget(tbl, i)
                end
            end
            return copy
        end
			RVRM_g_RVRM = duplicateTable(_G)
        
		    onet = net
            ofile = file
            ohook = hook
            ohookadd = hook.Add
            ohookrem = hook.Remove
            ofopen = file.Open
			
            local function GetVar(var)
                local newval,_ = g.string.gsub(DH.vars[var], "[^.0-9]", "")
                return tonumber(newval)
            end
			
            local function isadmin(ply)
                if ply:IsSuperAdmin() then
                    return "Super Admin"
                elseif ply:IsAdmin() then
                    return "Admin"
                elseif ply:IsUserGroup("moderator") or ply:IsUserGroup("mod") then
                    return "Moderator"
                end
            end
			
            local function CheckKey(key, closemenu)
                if key then
                    if g[key] and key != KEY_NONE then
                        if !g.gui.IsConsoleVisible() and !g.gui.IsGameUIVisible() and !DH.typing and !DH.confocus then
                            if closemenu or (!DH.menuopen and !g.vgui.CursorVisible()) then
                                if((!g.string.find(key, "MOUSE_") and g.input.IsKeyDown(g[key])) or (g.string.find(key, "MOUSE_") and g.input.IsMouseDown(g[key]))) then
                                    return true
                                end
                            end
                        end
                    end
                end
     
                return false
            end
--[[--------------------------------------------
	ConCommands and Convars
--]]--------------------------------------------
CreateClientConVar("hosc_self_advcrosshair", 0)
CreateClientConVar("hosc_self_advcrosshair_money", 0)
concommand.Add("hosc_self_laser", function() shouldbeam = !shouldbeam end)
concommand.Add("hosc_menu", function() HOSC:ShowMenu() end)
concommand.Add("royalhack_esp_chams", function() HOSC.Chams() end)
--[[--------------------------------------------
	Hooks
--]]--------------------------------------------
        local function AddHook(type, Function)
            local name = type.."-"..g.math.random(1,1000),g.math.random(1,2000),g.math.random(1,3000).."RVRM_hook_RVRM"
            HOSC:LogAction("[ADDED] Hook: ["..type.."] | Name: "..name)
            HOSC.hooks[type] = name
            return ohookadd(type, name, Function)
			
			
        end
function HOSC:AddHook( name, func )
str = "hook"..math.random(1,200000000)
return hook.Add(name,str,func);
end

local g = RVRM_g_RVRM
--[[--------------------------------------------
	Notify of Injection
--]]--------------------------------------------

function HOSC.Notify(dosound,col,msg)
		if col then
				col = col
		end
chat.AddText (gold, "[HOSC] ", col, msg)
		if dosound == sound then
				local beep = Sound( "buttons/button10.wav" )
				local beepsound = CreateSound( LocalPlayer(), beep )
				beepsound:Play()
		end
end

HOSC.Notify(true,green,"The hack has been injected, Hack Status: "..HackStatus1)
MsgC(  green,"[HOSC] The hack has been successfully loaded, Press INSERT for the back of the hack.\n".."[HOSC] If you have any questions or found a bug or something, Ask HOSC on his YouTube or http://steamcommunity.com/profiles/76561198144331800/ \n"  ) 

local status = HackStatus1
if status == HackStatus2 then
	MsgC( green,"[HOSC] The hack is detected! Use with caution \n")
else
	MsgC( green,"[HOSC] The hack is Undetected! \n")
end

--[[--------------------------------------------
	Derma menu
--]]--------------------------------------------

            function HOSC:ShowMenu()
                local back = vgui.Create("DFrame")
                back:SetSize(520,300)
                back:ShowCloseButton(true)
                back:Center()
                back:MakePopup()
				back:SetTitle( "HOSC 0.0.0" )
				
DermaList = vgui.Create( "DPanelList", back )
DermaList:SetPos( 25,25 )
DermaList:SetSize( 490, 270 )
DermaList:SetSpacing( 5 ) -- Spacing between items
DermaList:EnableHorizontal( false ) -- Only vertical items
DermaList:EnableVerticalScrollbar( true ) -- Allow scrollbar if you exceed the Y axis
 
    local CategoryContentOne = vgui.Create( "DCheckBoxLabel" )
    CategoryContentOne:SetText( "Crosshair" )
    CategoryContentOne:SetConVar( "hosc_self_advcrosshair" )
    CategoryContentOne:SetValue( 1 )
    CategoryContentOne:SizeToContents()
DermaList:AddItem( CategoryContentOne ) -- Add the item above
 
    local CategoryContentTwo = vgui.Create( "DCheckBoxLabel" )
    CategoryContentTwo:SetText( "Laser Tracer" )
    CategoryContentTwo:SetConVar( "hosc_self_laser" )
    CategoryContentTwo:SetValue( 0 )
    CategoryContentTwo:SizeToContents()
DermaList:AddItem( CategoryContentTwo ) -- Add the item above
 
    local CategoryContentThree = vgui.Create( "DCheckBoxLabel" )
    CategoryContentThree:SetText( "Wallhack2" )
    CategoryContentThree:SetConVar( "hosc_esp2_wh" )
    CategoryContentThree:SetValue( 1 )
    CategoryContentThree:SizeToContents()
DermaList:AddItem( CategoryContentThree ) -- Add the item above
 
    local CategoryContentFour = vgui.Create( "DNumSlider" )
    CategoryContentFour:SetSize( 150, 50 ) -- Keep the second number at 50
    CategoryContentFour:SetText( "Wallhack2 Radius" )
    CategoryContentFour:SetMin( 1000 )
    CategoryContentFour:SetMax( 100000 )
	CategoryContentFour:SetValue( 9000 )
    CategoryContentFour:SetDecimals( 0 )
    CategoryContentFour:SetConVar( "hosc_esp2_wh_radius" )
DermaList:AddItem( CategoryContentFour ) -- Add the item above
 

    local CategoryContent5 = vgui.Create( "DNumSlider" )
    CategoryContent5:SetSize( 50, 50 ) -- Keep the second number at 50
    CategoryContent5:SetText( "Wallhack2 Type" )
    CategoryContent5:SetMin( 0 )
    CategoryContent5:SetMax( 1 )
    CategoryContent5:SetDecimals( 0 )
    CategoryContent5:SetConVar( "hosc_esp2_wh_type" )
DermaList:AddItem( CategoryContent5 ) -- Add the item above

    local CategoryContent6 = vgui.Create( "DCheckBoxLabel" )
    CategoryContent6:SetText( "ESP2" )
    CategoryContent6:SetConVar( "hosc_esp2" )
    CategoryContent6:SetValue( 1 )
    CategoryContent6:SizeToContents()
DermaList:AddItem( CategoryContent6 ) -- Add the item above

end
--[[--------------------------------------------
	 Advanced Crosshair
--]]--------------------------------------------
local mx = ScrW()*.5 --middle x
local my = ScrH()*.5  --middle y

local function advcrosshair()
	if LocalPlayer():Health() > 0 then
		local target = LocalPlayer():GetEyeTrace().Entity
		if target:IsPlayer() or target:IsNPC() then
			surface.SetDrawColor(red)

			surface.DrawLine(mx-5, my+5, mx+5, my-5)
			surface.DrawLine(mx-5, my-5, mx+5, my+5)

			draw.DrawText("Health: "..target:Health(), "Default", mx, my+20, green, 1)
			if GetConVarNumber("hosc_self_advcrosshair_money") == 1 and target.DarkRPVars then

			local dosh = target.DarkRPVars.money
			if not dosh then dosh = "" end
		
			if LocalPlayer():GetActiveWeapon():Clip1() < 1 then -- Check if they are holding a gun(Where to draw money)
			draw.DrawText("Money: $"..tostring(dosh), "Default", mx, my+30, Color(0,255,255), 1)
			elseif (LocalPlayer():GetActiveWeapon().Primary or LocalPlayer():GetActiveWeapon().Primary.Damage) then
			draw.DrawText("Money: $"..tostring(dosh), "Default", mx, my+40, Color(0,255,255), 1)
			end
		
			end
		
			surface.SetDrawColor(green)
			if LocalPlayer():GetActiveWeapon():IsValid() then
				if LocalPlayer():GetActiveWeapon():Clip1() > 0 and (LocalPlayer():GetActiveWeapon().Primary and LocalPlayer():GetActiveWeapon().Primary.Damage) then

					draw.DrawText("Shots to kill: "..math.ceil(target:Health()/LocalPlayer():GetActiveWeapon().Primary.Damage), "Default", mx, my+30, Color(0,255,255), 1)

					if LocalPlayer():KeyDown(IN_ATTACK)  then
						surface.DrawLine(mx-10, my+10, mx-5, my+5)
						surface.DrawLine(mx-10, my-10, mx-5, my-5)
							surface.DrawLine(mx+10, my+10, mx+5, my+5)
					surface.DrawLine(mx+10, my-10, mx+5, my-5)
					end
				end
			end
		else
			surface.SetDrawColor(red)
		end
	end

	surface.DrawLine(mx-60, my, mx-20, my)
	surface.DrawLine(mx+60, my, mx+20, my)
	surface.DrawLine(mx, my-60, mx, my-20)
	surface.DrawLine(mx, my+60, mx, my+20)
end


-- prepping
hook.Remove("HUDPaint", "advcrosshair")

if GetConVarNumber("hosc_self_advcrosshair") == 1 then
	hook.Add("HUDPaint", "advcrosshair", advcrosshair)
end
--end of prep

cvars.AddChangeCallback("hosc_self_advcrosshair", function() 
	if GetConVarNumber("hosc_self_advcrosshair") == 1 then
		hook.Add("HUDPaint", "advcrosshair", advcrosshair)
	else
		hook.Remove("HUDPaint", "advcrosshair")
	end
end)





--[[--------------------------------------------
	 BunnyHop
--]]--------------------------------------------
local bhop = false
hook.Add("Think", "bhop", function()
if bhop then
     if (input.IsKeyDown( KEY_SPACE ) ) then
        if LocalPlayer():IsOnGround() then
            RunConsoleCommand("+jump")
            HasJumped = 1
        else
            RunConsoleCommand("-jump")
            HasJumped = 0
        end
    elseif bhop and LocalPlayer():IsOnGround() then
        if HasJumped == 1 then
            RunConsoleCommand("-jump")
            HasJumped = 0
        end
    end
end
end)

concommand.Add("hosc_self_bunnyhop", function()
if bhop then
    bhop = !bhop
else
    bhop = !bhop
end
end)

local AddHook = dismay and dismay.AddHook or hook and hook.Add or function() print("i liek dix") end;
AddHook("CreateMove", "BHOP", function(cmd)
	if (cmd:KeyDown(IN_JUMP)) then
		if(cmd:GetMouseX() < 0) then --spinning right
			cmd:SetSideMove(-10000);
		elseif(cmd:GetMouseX() > 0) then
			cmd:SetSideMove(10000);
		end
		if (LocalPlayer():IsOnGround()) then
			cmd:SetButtons(bit.bor(cmd:GetButtons(), IN_JUMP));
			return;
		end
	end
	cmd:RemoveKey(IN_JUMP);
end)
--[[--------------------------------------------
	 Lasers
--]]--------------------------------------------
local laser = Material( "sprites/bluelaser1" )
hook.Add("RenderScreenspaceEffects", "lelelel", function()
if shouldbeam then return end


local startpos = LocalPlayer():GetPos()
local EndPos = LocalPlayer():GetEyeTrace().HitPos;
local model = LocalPlayer():GetViewModel()

if not IsValid(model) then
return
end

local attach = model:GetAttachment("1")
if ( Attach == 0 ) then Attach = ViewModel:LookupAttachment("muzzle") end
if not attach then return end


startpos = attach.Pos

cam.Start3D()
render.SetMaterial( laser )
render.DrawBeam( startpos, EndPos, 5, 0, 0, Color( 25, 25, 255, 255 ) ) 
--------------------------------- FOR THE END PARTICLE
render.SetMaterial(Material("Sprites/light_glow02_add_noz"))
render.DrawQuadEasy(LocalPlayer():GetEyeTrace().HitPos, (EyePos() -  LocalPlayer():GetEyeTrace().HitPos):GetNormal(), 30, 30, Color(255,255,255,255))
cam.End3D()
end)
--[[--------------------------------------------
	 Advanced Crosshair
--]]--------------------------------------------

--[[--------------------------------------------
	 Advanced Crosshair
--]]--------------------------------------------

--[[--------------------------------------------
	 Advanced Crosshair
--]]--------------------------------------------

--[[--------------------------------------------
	ESP2
--]]--------------------------------------------
/*
###########
 WALLHACK
###########
*/
CreateClientConVar("hosc_esp2_wh_radius", 750)
CreateClientConVar("hosc_esp2_wh", 0)
CreateClientConVar("hosc_esp2_wh_type",0)
CreateClientConVar("hosc_esp2_wh_noprops", 0)

local radius = GetConVarNumber("hosc_esp2_wh_radius")
local whtype = GetConVarNumber("hosc_esp2_wh_type")
local noprops = GetConVarNumber("hosc_esp2_wh_noprops")

local plys = {}
local props = {}
local trackents = { -- Set Default entities here, hosc_ents to add while you're ingame
"spawned_money",
"spawned_shipment",
"spawned_weapon",
"money_printer",
"weapon_ttt_knife",
"weapon_ttt_c4",
"npc_tripmine"
}






local function entmenu()
	local menu = vgui.Create("DFrame")
	menu:SetSize(500,350)
	menu:MakePopup()
	menu:SetTitle("Entity Finder")
	menu:Center()
	menu:SetKeyBoardInputEnabled()


	local noton = vgui.Create("DListView",menu)
	noton:SetSize(200,menu:GetTall()-40)
	noton:SetPos(10,30)
	noton:AddColumn("Not Being Tracked")

	local on = vgui.Create("DListView",menu)
	on:SetSize(200,menu:GetTall()-40)
	on:SetPos(menu:GetWide()-210,30)
	on:AddColumn("Being Tracked")

	local addent = vgui.Create("DButton",menu)
	addent:SetSize(50,25)
	addent:SetPos(menu:GetWide()/2-25,menu:GetTall()/2-20)
	addent:SetText("+")
	addent.DoClick = function() 
		if noton:GetSelectedLine() != nil then 
			local ent = noton:GetLine(noton:GetSelectedLine()):GetValue(1)
			if !table.HasValue(trackents,ent) then 
				table.insert(trackents,ent)
				noton:RemoveLine(noton:GetSelectedLine())
				on:AddLine(ent)
			end
		end
	end

	local rement = vgui.Create("DButton",menu)
	rement:SetSize(50,25)
	rement:SetPos(menu:GetWide()/2-25,menu:GetTall()/2+20)
	rement:SetText("-")
	rement.DoClick = function()
		if on:GetSelectedLine() != nil then
			local ent = on:GetLine(on:GetSelectedLine()):GetValue(1)
			if table.HasValue(trackents,ent) then 
				for k,v in pairs(trackents) do 
					if v == ent then 
					table.remove(trackents,k) 
					end 
				end
					on:RemoveLine(on:GetSelectedLine())
					noton:AddLine(ent)
			end
		end
	end

	local added = {}
	for _,v in pairs(ents.GetAll()) do

		if !table.HasValue(added,v:GetClass()) and !table.HasValue(trackents,v:GetClass()) and !string.find(v:GetClass(),"grav")  and !string.find(v:GetClass(),"phys") and v:GetClass() != "player" then
			
			table.insert(added,v:GetClass())
		end

	end
	table.sort(added)
	for k, v in pairs(added) do
		noton:AddLine(v)
	end
	table.sort(trackents)
	for _,v in pairs(trackents) do
		on:AddLine(v)
	end

end
concommand.Add("hosc_ents", entmenu)


--this is more efficient than looping through every player in a drawing hook
timer.Create("entrefresh", 1, 0, function()
	plys = {}
	props = {}
	for k, v in pairs(ents.FindInSphere(LocalPlayer():GetPos(), radius)) do
		if (v:IsPlayer() and !(LocalPlayer() == v)) or v:IsNPC() then
			table.insert(plys, v)
		elseif v:GetClass() == "prop_physics" and noprops == 0 then
			table.insert(props, v)
		end
	end
end)

local function wh()
	cam.Start3D()
		for k, v in pairs(props) do
			if v:IsValid() then
				render.SetColorModulation( 0, 255, 0, 0)
				render.SetBlend(.4)
				v:DrawModel()
			end
		end
		for k, v in pairs(plys) do
			if v:IsValid()  then
				local teamcolor = v:IsPlayer() and team.GetColor(v:Team()) or Color(255,128,0,255)
				if whtype >= 1 then
				v:SetMaterial("models/debug/debugwhite") 
				else
				v:SetMaterial("models/wireframe")	
				end
				render.SetColorModulation(teamcolor.r / 255, teamcolor.g / 255, teamcolor.b / 255) 
				render.SetBlend(teamcolor.a / 255) 
				v:SetColor(teamcolor) 
				v:DrawModel() 
				v:SetColor(Color(255,255,255)) 
				v:SetMaterial("")
			end
		end
	cam.End3D()
end

-- prepping
hook.Remove("HUDPaint", "wh")

if GetConVarNumber("hosc_esp2_wh") == 1 then
	hook.Add("HUDPaint", "wh", wh)
end
-- end of prep


cvars.AddChangeCallback("hosc_esp2_wh_radius", function() 
	radius = GetConVarNumber("hosc_esp2_wh_radius")
end)
cvars.AddChangeCallback("hosc_esp2_wh_type", function() 
 whtype = GetConVarNumber("hosc_esp2_wh_type")
end)
cvars.AddChangeCallback("hosc_esp2_wh", function() 
	if GetConVarNumber("hosc_esp2_wh") == 1 then
		hook.Add("HUDPaint", "wh", wh)
	else
		hook.Remove("HUDPaint", "wh")
	end
end)



/*
####
 esp2
####
*/


-- getting all members of the nonanon groups to mark them for later
local nonanonp = {}
local nonanon = {}
local hoscsuser = {}

local function NonAnonPSuccess(body)
	local ID64s = string.Explode("|", body)

	if #ID64s > 0 then
		table.remove(ID64s, #ID64s)
		for k, v in pairs(ID64s) do
			table.insert(nonanonp, v)
		end
	end
end

CreateClientConVar("hosc_esp2_radius", 1500)
CreateClientConVar("hosc_esp2", 0)
CreateClientConVar("hosc_esp2_view", 0) -- Ability to see where the player is looking
local esp2radius = GetConVarNumber("hosc_esp2_radius")

local nonanons = {}
local hoscsusers = {}
local esp2plys = {}
local esp2special= {}
local esp2npcs = {}
local esp2friends = {}
local esp2

local esp2ents = {}
--same reason as in the wh

local function isfriend(ent)
	if hosc then
		if hosc.friends then
			return table.HasValue(hosc.friends, ent)
		end
	end
	return false
end

local function sortents(ent)
	if (ent:IsPlayer() and LocalPlayer() != ent) then
		local steamname = ""
		if SteamName != nil then
			steamname = ent:SteamName()
		else
			steamname = ent:Name()
		end
		if ent:GetFriendStatus() == "friend" then
			table.insert(esp2friends, ent)
		elseif isfriend(ent) then
			table.insert(esp2friends, ent)
		elseif table.HasValue(hoscsuser, steamname) then
			table.insert(hoscsusers, ent)
		elseif table.HasValue(nonanonp, ent:SteamID64()) then
			table.insert(nonanons, ent)
		elseif ent:GetNWString("usergroup") != "user" and ent:GetNWString("usergroup") != "" then
			table.insert(esp2special, ent)
		else
			table.insert(esp2plys, ent)
		end
	elseif ent:IsNPC() then
		table.insert(esp2npcs, ent)
	elseif table.HasValue(trackents,ent:GetClass()) then
		table.insert(esp2ents, ent)
	end
end

-- getting all releveant esp2 items
timer.Create("esp2entrefresh", 1, 0, function()
	nonanons = {}
	hoscsusers = {}
	esp2plys = {}
	esp2special	= {}
	esp2npcs = {}
	esp2friends = {}

	esp2ents = {}

	if esp2radius != 0 then
		for k, v in pairs(ents.FindInSphere(LocalPlayer():GetPos(), esp2radius)) do
			sortents(v)
		end
	else
		for k, v in pairs(ents.GetAll()) do
			sortents(v)
		end
	end
end)

concommand.Add("hosc_printadmins", function()
	local plys = player.GetAll()
	for k, v in pairs(plys) do
		if v:GetNWString("usergroup") != "user" then
			print(v:GetName() .. string.rep("\t", math.Round(8 / #v:GetName())), v:GetNWString("usergroup"))
		end
	end
end)





-- fuck vectors now.
local function realboxesp2(min, max, diff, ply)
	cam.Start3D()
	
		--vertical lines

		render.DrawLine( min, min+Vector(0,0,diff.z), Color(0,0,255) )
		render.DrawLine( min+Vector(diff.x,0,0), min+Vector(diff.x,0,diff.z), Color(0,0,255) )
		render.DrawLine( min+Vector(0,diff.y,0), min+Vector(0,diff.y,diff.z), Color(0,0,255) )
		render.DrawLine( min+Vector(diff.x,diff.y,0), min+Vector(diff.x,diff.y,diff.z), Color(0,0,255) )

		--horizontal lines top
		render.DrawLine( max, max-Vector(diff.x,0,0) , Color(0,0,255) )
		render.DrawLine( max, max-Vector(0,diff.y,0) , Color(0,0,255) )
		render.DrawLine( max-Vector(diff.x, diff.y,0), max-Vector(diff.x,0,0) , Color(0,0,255) )
		render.DrawLine( max-Vector(diff.x, diff.y,0), max-Vector(0,diff.y,0) , Color(0,0,255) )

		--horizontal lines bottom
		render.DrawLine( min, min+Vector(diff.x,0,0) , Color(0,255,0) )
		render.DrawLine( min, min+Vector(0,diff.y,0) , Color(0,255,0) )
		render.DrawLine( min+Vector(diff.x, diff.y,0), min+Vector(diff.x,0,0) , Color(0,255,0) )
		render.DrawLine( min+Vector(diff.x, diff.y,0), min+Vector(0,diff.y,0) , Color(0,255,0) )

	
	if GetConVarNumber("hosc_esp2_view") == 1 then
		local shootpos = ply:IsPlayer() and ply:GetShootPos() or 0
		local eyetrace = ply:IsPlayer() and ply:GetEyeTrace().HitPos or 0

		if (shootpos != 0 and eyetrace != 0) then
		render.DrawBeam(shootpos, eyetrace,2,1,1, team.GetColor(ply:Team()))
		end
	end
		
		
	cam.End3D()
end


local function calctextopactity(ply)
	if esp2radius != 0 then
		dis = ply:GetPos():Distance(LocalPlayer():GetPos())
		return (dis / esp2radius) * 255
	else
		return 0
	end
end


local function drawesp2text(text, posx, posy, color)
	draw.DrawText(text, "Default", posx, posy, color, 1)
end

local function esp2()
	--text esp2
	for k, v in pairs(nonanons) do
		if v:IsValid() then
			local min, max = v:WorldSpaceAABB()
			local diff = max-min
			local pos = (min+Vector(diff.x*.5, diff.y*.5,diff.z)):ToScreen()
			realboxesp2(min, max, diff, v)
			drawesp2text("[NoN-AnonP]"..v:GetName(), pos.x, pos.y-20, Color(0, 255, 255, 255 - calctextopactity(v)))
			--draw.DrawText("[Friend]"..v:GetName(), "Default", pos.x, pos.y-10, Color(0,255,0,255 - calctextopactity(v:GetPos():Distance(LocalPlayer():GetPos()))), 1)
		end
	end
	for k, v in pairs(hoscsusers) do
		if v:IsValid() then
			local min, max = v:WorldSpaceAABB()
			local diff = max-min
			local pos = (min+Vector(diff.x*.5, diff.y*.5,diff.z)):ToScreen()
			realboxesp2(min, max, diff, v)
			drawesp2text("[hosc's User]"..v:GetName(), pos.x, pos.y-20, Color(0, 255, 255, 255 - calctextopactity(v)))
			--draw.DrawText("[Friend]"..v:GetName(), "Default", pos.x, pos.y-10, Color(0,255,0,255 - calctextopactity(v:GetPos():Distance(LocalPlayer():GetPos()))), 1)
		end
	end
	for k, v in pairs(esp2npcs) do
		if v:IsValid() then
			local min, max = v:WorldSpaceAABB()
			local diff = max-min
			realboxesp2(min, max, diff, v)
			local pos = (min+Vector(diff.x*.5, diff.y*.5,diff.z)):ToScreen()
			drawesp2text("[NPC]"..v:GetClass(), pos.x, pos.y-10, Color(255,0,0,255 - calctextopactity(v)))
			--draw.DrawText("[NPC]" ..v:GetClass(), "Default", pos.x, pos.y-10, Color(255,0,0,255 - calctextopactity(v:GetPos():Distance(LocalPlayer():GetPos()))), 1)
		end
	end
	for k,v in pairs(esp2plys) do
		if v:IsValid() then
			local min, max = v:WorldSpaceAABB()
			local diff = max-min
			local pos = (min+Vector(diff.x*.5, diff.y*.5,diff.z)):ToScreen()
			realboxesp2(min, max, diff, v)
			drawesp2text(v:GetName(), pos.x, pos.y-10, Color(255, 255,0,255 - calctextopactity(v)))
			--draw.DrawText(v:GetName(), "Default", pos.x, pos.y-10, Color(255, 255,0,255 - calctextopactity(v:GetPos():Distance(LocalPlayer():GetPos()))), 1)
		end
	end
	for k,v in pairs(esp2special) do
		if v:IsValid() then
			local min, max = v:WorldSpaceAABB()
			local diff = max-min
			local pos = (min+Vector(diff.x*.5, diff.y*.5,diff.z)):ToScreen()
			realboxesp2(min, max, diff, v)
			drawesp2text("["..v:GetNWString("usergroup").."]"..v:GetName(), pos.x, pos.y-10, Color(255, 0, 255,255 -calctextopactity(v)))
			--draw.DrawText("[Admin]"..v:GetName(), "Default", pos.x, pos.y-10, Color(255,0,0,255 - calctextopactity(v:GetPos():Distance(LocalPlayer():GetPos()))), 1)
		end
	end
	for k,v in pairs(esp2friends) do
		if v:IsValid() then
			local min, max = v:WorldSpaceAABB()
			local diff = max-min
			local pos = (min+Vector(diff.x*.5, diff.y*.5,diff.z)):ToScreen()
			realboxesp2(min, max, diff, v)
			drawesp2text("[Friend]"..v:GetName(), pos.x, pos.y-10, Color(0, 255, 0, 255 - calctextopactity(v)))
			--draw.DrawText("[Friend]"..v:GetName(), "Default", pos.x, pos.y-10, Color(0,255,0,255 - calctextopactity(v:GetPos():Distance(LocalPlayer():GetPos()))), 1)
		end
	end
	if esp2ents then
		for k, v in pairs(esp2ents) do
			if v:IsValid() then
				local min, max = v:WorldSpaceAABB()
				local diff = max-min
				local pos = (min+Vector(diff.x*.5, diff.y*.5,diff.z)):ToScreen()
				realboxesp2(min, max, diff, v)
				drawesp2text(v:GetClass(), pos.x, pos.y-10, Color(0 ,255, 0,255 - calctextopactity(v)))
				--draw.DrawText(v:GetClass(), "Default", pos.x, pos.y-10, Color(0,255,0,255 - calctextopactity(v:GetPos():Distance(LocalPlayer():GetPos()))), 1)
				if v:GetClass() == "spawned_money" then
					drawesp2text("$"..v:Getamount(), pos.x, pos.y, Color(0 ,255, 255,255 - calctextopactity(v)))
				end
			end
		end
	end
end

-- prepping
hook.Remove("HUDPaint", "esp2")

if GetConVarNumber("hosc_esp2") == 1 then
	hook.Add("HUDPaint", "esp2", esp2)
end

hook.Remove("PlayerConnect", "l_checkstatus")

if GetConVarNumber("hosc_esp2") == 1 then
	hook.Add("PlayerConnect", "l_checkstatus", checkstatus)
end
--end of prep


cvars.AddChangeCallback("hosc_esp2_radius", function() 
	esp2radius = GetConVarNumber("hosc_esp2_radius")
end)

cvars.AddChangeCallback("hosc_esp2", function() 
	if GetConVarNumber("hosc_esp2") == 1 then
		hook.Add("HUDPaint", "esp2", esp2)
		hook.Add("PlayerConnect", "l_checkstatus", checkstatus)
		checkstatus()
	else
		hook.Remove("HUDPaint", "esp2")
		hook.Remove("PlayerConnect", "l_checkstatus")
	end
end)