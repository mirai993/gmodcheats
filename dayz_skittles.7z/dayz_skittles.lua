--[[
	MOD/lua/GModZ.lua
	[TSA] Skittles 2.0 | (STEAM_0:1:41711091) | [05-08-13 08:39:06PM]
	===BadFile===
]]

local food = { -- all food
"orange",
"milk",
"water",
"soda",
"melon",
"banana",
"literwater",
"beans",
"fastfood",
}
local health = {
"painkillers",
-- bloodpack and healthkit show up as weapons due to having weapon_ in their class name
-- who cares
}


function pia()
	for k, e in pairs(ents.FindByClass("gmodz_item")) do
		if IsValid( e ) then
			local pos = (e:GetPos():ToScreen())

			-- WEAPONS
			if string.find(e:GetModel(),'weapon') then
				draw.SimpleText(e.id, "default" ,pos.x, pos.y, Color(0,255,0,255), 1 )

			-- AMMO
			elseif string.find(e.id,'ammo') then
				draw.SimpleText(e.id, "default" ,pos.x, pos.y, Color(255,0,0,255), 1 )

			-- FOOD
			elseif table.HasValue(food,e.id) then
				draw.SimpleText(e.id, "default" ,pos.x, pos.y, Color(255,255,0,255), 1 )

			-- HEALTH
			elseif table.HasValue(health,e.id) then
				draw.SimpleText(e.id, "default" ,pos.x, pos.y, Color(0,255,255,255), 1 )

			-- OTHER
			else
				draw.SimpleText(e.id, "default" ,pos.x, pos.y, Color(150,150,150), 1 )

			end
		end
	end
end
hook.Add( "HUDPaint", "pia", pia )
