--[[
	blue_hack_private.lua
	[6kx3] Blue Kirby | (STEAM_0:0:25093119)
	===DStream===
]]

--Variables
local realAngles = Angle( 0, 0, 0 )
local savedAngle = Angle( 0, 0, 0 )
local Cam3DAngles = Angle( 0, 0, 0 )
local lastAimAngle = Angle( 0, 0, 0 )
local lastAimPos = Vector( 0, 0, 0 )
local DistVec = 0
local fuck = 0
local EntityList = {}
local AlreadyRanAttack = false
local RenderEntities = {}
local angleOffset = 0
local key_w = 0
local key_a = 0
local key_s = 0
local key_d = 0
local MOVE = { [0] = "+forward", [1] = "+moveleft", [2] = "+back", [3] = "+moveright" }
local STOPMOVE = { "-forward", "-moveleft", "-back", "-moveright" }
local CustomColor = Color( 255, 0, 0 );
local FriendColor = Color( 50, 120, 255 )
local _inAttack = false
local shake = {}
local ShouldSeeAngle = false;
shake.p = 0
shake.y = 0
--Convars
local bk_aimbot_autoshoot = CreateClientConVar( "bk_aimbot_autoshoot", 0, true, false )
local bk_aimbot_ignore_steam_friends = CreateClientConVar( "bk_aimbot_ignore_steam_friends", 0, true, false )
local bk_aimbot_ignore_teammates = CreateClientConVar( "bk_aimbot_ignore_teammates", 0, true, false )
local bk_aimbot_silent = CreateClientConVar( "bk_aimbot_silent", 0, true, false )
local bk_aimbot_silent_smooth = CreateClientConVar( "bk_aimbot_silent_smooth", 1, true, false )
local bk_aimbot_use_friend_and_enemy_list = CreateClientConVar( "bk_aimbot_use_friend_and_enemy_list", 0, true, false )
local bk_crosshair_actual_aim = CreateClientConVar( "bk_crosshair_actual_aim", 1, true, false )
local bk_crosshair = CreateClientConVar( "bk_crosshair", 1, true, false )
local bk_esp = CreateClientConVar( "bk_esp", 0, true, false )
local bk_esp_info = CreateClientConVar( "bk_esp_info", 0, true, false )
local bk_esp_use_friend_and_enemy_list = CreateClientConVar( "bk_esp_use_friend_and_enemy_list", 0, true, false )
local bk_esp_use_custom_color = CreateClientConVar( "bk_esp_use_custom_color", 0, true, false )
local bk_esp_use_friend_color = CreateClientConVar( "bk_esp_use_friend_color", 0, true, false )
local bk_norecoil = CreateClientConVar( "bk_norecoil", 1, true, false )
local bk_nospread = CreateClientConVar( "bk_nospread", 1, true, false )
local bk_smoothlook = CreateClientConVar( "bk_smoothlook", 0, true, false )
local bk_spinbot = CreateClientConVar( "bk_spinbot", 0, true, false )
local bk_spinbot_random = CreateClientConVar( "bk_spinbot_random", 0, true, false )
local bk_wallhack = CreateClientConVar( "bk_wallhack", 0, true, false )
local bk_wallhack_players = CreateClientConVar( "bk_wallhack_players", 0, true, false )
local bk_wallhack_entities = CreateClientConVar( "bk_wallhack_entities", 0, true, false )

local function CreateCheckBox( text, pos, parent, convar, value )
	
	local CheckBox = vgui.Create( "DCheckBoxLabel", parent )
	CheckBox:SetPos( pos.x, pos.y )
	CheckBox:SetText( text )
	CheckBox:SetValue( value )
	CheckBox:SizeToContents()
	if tostring( convar ) then
		CheckBox:SetConVar( convar )
	end
	
	return CheckBox
	
end

BKConVarList = { "bk_aimbot_autoshoot",
"bk_aimbot_ignore_steam_friends",
"bk_aimbot_ignore_teammates",
"bk_aimbot_silent",
"bk_aimbot_use_friend_and_enemy_list",
"bk_esp",
"bk_esp_info",
"bk_esp_use_friend_and_enemy_list",
"bk_esp_use_custom_color",
"bk_esp_use_friend_color",
}

BKConVarNames = { "Auto Shoot",
"Ignore Steam Friends",
"Ignore Team Mates",
"Enabled",
"Use Friends/Enemies",
"Enabled",
"Info",
"Disguard friends",
"Use color",
"Use friend color",
}

local BKAimbotWhitelist = {}
local BKAimbotBlacklist = {}

local function BKMenu()
	
	local MainPanel = vgui.Create( "DFrame" )
	MainPanel:SetSize( 430, 350 )
	MainPanel:SetPos( ScrW() / 2 - MainPanel:GetWide() / 2, ScrH() / 2 - MainPanel:GetTall() / 2 )
	MainPanel:SetVisible( true )
	MainPanel:SetTitle( "Blue Kirby - Private Hack" )
	MainPanel:SetVisible( true )
	MainPanel:SetDraggable( true )
	MainPanel:ShowCloseButton( false )
	MainPanel:MakePopup()
	MainPanel.Paint = function()
		draw.RoundedBox( 4, 336, 0, 100, 20, Color(0, 0, 0, 255)  )
		draw.RoundedBox( 4, 337, 1, 98, 18, Color(120, 120, 120, 255)  )
	end
	
	local Header = vgui.Create( "DLabel", MainPanel )
	Header:SetText( "Blue Hack" )
	Header:SetPos( 342, 3 )
	Header:SetColor( Color( 50, 155, 255 ) )
	Header:SetFont( "TabLarge" )
	Header:SizeToContents()
	
	local PropertySheet = vgui.Create( "DPropertySheet", MainPanel )
	PropertySheet:SetPos( 0, 0 )
	PropertySheet:SetSize( MainPanel:GetWide(), MainPanel:GetTall() )
	PropertySheet.Paint = function()
		draw.RoundedBox( 4, 0, 22, MainPanel:GetWide(), MainPanel:GetTall() - 22, Color(170, 170, 170, 255)  )
	end
	
	local AimbotPanel = vgui.Create( "DPanel", MainPanel )
	AimbotPanel:SetSize( MainPanel:GetWide(), MainPanel:GetTall() )
	AimbotPanel:SetPos( 0, 0 )
	AimbotPanel.Paint = function()
		draw.RoundedBox( 4, 0, 0, MainPanel:GetWide(), MainPanel:GetTall(), Color( 90, 90, 90, 255 )  )
	end
	
	local ESPPanel = vgui.Create( "DPanel", MainPanel )
	ESPPanel:SetSize( MainPanel:GetWide(), MainPanel:GetTall() )
	ESPPanel:SetPos( 0, 0 )
	ESPPanel.Paint = function()
		draw.RoundedBox( 4, 0, 0, MainPanel:GetWide(), MainPanel:GetTall(), Color( 90, 90, 90, 255 )  )
	end
	
	PropertySheet:AddSheet( "Aimbot", AimbotPanel, "gui/silkicons/user", false, false, "Aimbort settings" )
	PropertySheet:AddSheet( "ESP", ESPPanel, "gui/silkicons/group", false, false, "ESPN Channel" )
	
	local aimbotSettings = vgui.Create( "DLabel", AimbotPanel )
	aimbotSettings:SetText( "Aimbot Settings:" )
	aimbotSettings:SetPos( 6, 4 )
	aimbotSettings:SetColor( Color( 255, 255, 255 ) )
	aimbotSettings:SizeToContents()
	
	for i = 1, 4 do
		
		CreateCheckBox( BKConVarNames[i], Vector( 6, 10 + (20 * i) ), AimbotPanel, BKConVarList[i], 1 )
		
	end
	
	CreateCheckBox( BKConVarNames[5], Vector( 266, 90 ), AimbotPanel, BKConVarList[5], 1 )
	
	local WhiteList = vgui.Create( "DLabel", AimbotPanel )
	WhiteList:SetText( "Enemies:" )
	WhiteList:SetPos( 6, 120 )
	WhiteList:SetColor( Color( 255, 255, 255 ) )
	WhiteList:SizeToContents()
	
	local WhiteList = vgui.Create( "DComboBox", AimbotPanel )
	WhiteList:SetPos( 6, 135 )
	WhiteList:SetSize( 150, 178 )
	WhiteList:SetMultiple( false )
	BKAimbotWhitelist = {}
	for k, v in pairs( player.GetAll() ) do
		
		if v != LocalPlayer() and !table.HasValue( BKAimbotBlacklist, v ) then
			WhiteList:AddItem( v:Name() )
			table.insert( BKAimbotWhitelist, v )
		end
		
	end
	
	local BlackList = vgui.Create( "DLabel", AimbotPanel )
	BlackList:SetText( "Friends:" )
	BlackList:SetPos( 266, 120 )
	BlackList:SetColor( Color( 255, 255, 255 ) )
	BlackList:SizeToContents()
	
	local BlackList = vgui.Create( "DComboBox", AimbotPanel )
	BlackList:SetPos( 266, 135 )
	BlackList:SetSize( 150, 178 )
	BlackList:SetMultiple( false )
	for k, v in pairs( BKAimbotBlacklist ) do
		
		if v:IsValid() and v:IsPlayer() then
			BlackList:AddItem( v:Name() )
		end
		
	end
	
	local AddBlackList = vgui.Create( "DButton", AimbotPanel )
	AddBlackList:SetSize( 76, 20 )
	AddBlackList:SetPos( 175, 135 )
	AddBlackList:SetText( ">>" )
	
	local AddWhiteList = vgui.Create( "DButton", AimbotPanel )
	AddWhiteList:SetSize( 76, 20 )
	AddWhiteList:SetPos( 175, 165 )
	AddWhiteList:SetText( "<<" )
	
	AddBlackList.DoClick = function()
	
		if !WhiteList:GetSelectedItems()[1] then return end
		BlackList:AddItem( WhiteList:GetSelectedItems()[1]:GetValue() )
		local findPlayerByName = NULL;
		for k, v in pairs( player.GetAll() ) do
			
			if v:Name() == WhiteList:GetSelectedItems()[1]:GetValue() then
				
				findPlayerByName = v
				
			end
			
		end
		table.insert( BKAimbotBlacklist, findPlayerByName )
		WhiteList:Clear()
		BKAimbotWhitelist = {}
		for k, v in pairs( player.GetAll() ) do
		
			if v != LocalPlayer() and !table.HasValue( BKAimbotBlacklist, v ) then
				WhiteList:AddItem( v:Name() )
				table.insert( BKAimbotWhitelist, v )
			end
		
		end
		
	end
	
	AddWhiteList.DoClick = function()
		
		if !BlackList:GetSelectedItems()[1] then return end
		WhiteList:AddItem( BlackList:GetSelectedItems()[1]:GetValue() ) 
		
		for k, v in pairs( BKAimbotBlacklist ) do
		
			if v:Name() == BlackList:GetSelectedItems()[1]:GetValue() then
				
				table.remove( BKAimbotBlacklist, k )
				break;
				
			end
			
		end
		
		BlackList:Clear()
		
		for k, v in pairs( BKAimbotBlacklist ) do
	
			BlackList:AddItem( v:Name() )
		
		end
		
	end
	
	local CLOSE = vgui.Create( "DSysButton", MainPanel )
	CLOSE:SetSize( 20, 20 )
	CLOSE:SetPos( 410, 0 )
	CLOSE:SetType( "close" )
	CLOSE.DoClick = function()
		MainPanel:Close()
	end
	
	local espSettings = vgui.Create( "DLabel", ESPPanel )
	espSettings:SetText( "ESP Settings:" )
	espSettings:SetPos( 6, 4 )
	espSettings:SetColor( Color( 255, 255, 255 ) )
	espSettings:SizeToContents()
	
	local CustomColorCube = vgui.Create( "DColorMixer", ESPPanel )
	CustomColorCube:SetPos( 6, 170 )
	CustomColorCube:SetSize( 170, 120 )
	CustomColorCube:SetColor( CustomColor )
	CustomColorCube.Think = function()
		CustomColor = CustomColorCube:GetColor()
	end
	
	local FriendColorCube = vgui.Create( "DColorMixer", ESPPanel )
	FriendColorCube:SetPos( 265, 170 )
	FriendColorCube:SetSize( 170, 120 )
	FriendColorCube:SetColor( FriendColor )
	FriendColorCube.Think = function()
		FriendColor = FriendColorCube:GetColor()
	end
	
	for i = 6, 8 do
		
		CreateCheckBox( BKConVarNames[i], Vector( 6, 10 + (20 * (i - 5)) ), ESPPanel, BKConVarList[i], 1 )
		
	end
	
	CreateCheckBox( BKConVarNames[9], Vector( 6, 300 ), ESPPanel, BKConVarList[9], 1 )
	CreateCheckBox( BKConVarNames[10], Vector( 265, 300 ), ESPPanel, BKConVarList[10], 1 )
	
end
concommand.Add( "bk_menu", BKMenu )

local function BKUnload()
	
	hook.Remove( "CreateMove", "BK.hacks" )
	hook.Remove( "HUDPaint", "BK.ESP.Box" )
	hook.Remove( "Think", "BK.Aimbot.Silent" )
	hook.Remove( "Think", "BK.Aimbot" )
	hook.Remove( "HUDPaint", "Blue_Wall_.Hack" )
	hook.Remove( "CalcView", "SmoothLook" )
	
end
concommand.Add( "bk_unload", BKUnload )

hook.Add( "CreateMove", "BK.hacks", function() 
	
	local wep = LocalPlayer():GetActiveWeapon()
	
	if bk_nospread:GetBool() and LocalPlayer():Alive() and wep:IsValid() and wep.Primary then
	
		wep.Primary.Spread = 0
		wep.Primary.Cone = 0

	end
	
	if bk_norecoil:GetBool() and LocalPlayer():Alive() and wep:IsValid() and wep.Primary then
		
		wep.Primary.Recoil = 0
		
	end
	
end )

local function getAnglesDifference( angle1, angle2 )
	
	local pitch1 = angle1.p
	local yaw1 = angle1.y
	local pitch2 = angle2.p
	local yaw2 = angle2.y
	local TotalDistance = 0
	TotalDistance = math.abs(math.AngleDifference( pitch1, pitch2 ))
	TotalDistance = math.abs(math.AngleDifference( yaw1, yaw2 )) + TotalDistance
	
	return TotalDistance
	
end

local function GetBestTarget()
	
	local ply = LocalPlayer()
	
end

local function lerpA( angle1, angle2, ammount )
	
	ammount = ammount * 10
	
	angle1.p = math.ApproachAngle( angle1.p, angle2.p, 1 ) 
	angle1.y = math.ApproachAngle( angle1.y, angle2.y, 1 ) 
	angle1.r = 0
	
	return angle1
	
end

local function GetHead( ply )
	
	if !ply:IsPlayer() or !ply:IsValid() then return end
	
	local targethead = ply:LookupBone("ValveBiped.Bip01_Head1")
	local targetheadpos,targetheadang = ply:GetBonePosition(targethead)
	
	return targetheadpos
	
end

function IsSteamFriend( ply )
   return ply:GetFriendStatus() == "friend"
end

local function GetBestPlayer()
	
	if table.Count( player.GetAll() ) == 1 then return LocalPlayer() end
	
	local ply = LocalPlayer()
	local plys = {}
	
	for k, v in pairs( player.GetAll() ) do
		
		local issteamfriend = IsSteamFriend( v ) and bk_aimbot_ignore_steam_friends:GetBool()
		local isteammate = v:Team() == ply:Team() and bk_aimbot_ignore_teammates:GetBool()
		local isonblacklist = table.HasValue( BKAimbotBlacklist, v ) and bk_aimbot_use_friend_and_enemy_list:GetBool()
		local allchecks = issteamfriend or isteammate or isonblacklist
		
		if v != ply and v:Alive() and !allchecks then
			
			local pos = ply:GetShootPos()
			local ang = ply:GetAimVector()
			local tracedata = {}
			tracedata.start = pos
			tracedata.endpos = GetHead(v)
			tracedata.filter = ply
			local trace = util.TraceLine(tracedata)
			
			if trace.HitNonWorld then
			
				if trace.Entity == v then
					plys[table.Count(plys)] = v
				end
				
			end
			
		end
		
	end
	
	for k, v in pairs( plys ) do
		
		local lerpd = (GetHead(v) - ply:EyePos()):Angle()
		local dist = math.abs(math.AngleDifference( ply:EyeAngles().p, lerpd.p )) * 180 + math.abs(math.AngleDifference( ply:EyeAngles().y, lerpd.y )) * 180
		lerpd = (GetHead(plys[0]) - ply:EyePos()):Angle()
		local dist2 = math.abs(math.AngleDifference( ply:EyeAngles().p, lerpd.p )) * 180 + math.abs(math.AngleDifference( ply:EyeAngles().y, lerpd.y )) * 180
		if dist < dist2 then
			plys[0] = v
		end
		
	end
	
	if IsValid(plys[0]) then
		ply = plys[0]
	end
	
	return ply;
end

local function GetHand( ply )
	
	local pos = Vector( 0, 0, 0 )
	
	local targethead = ply:LookupBone("ValveBiped.Bip01_R_Hand")
	local pos,targetheadang = ply:GetBonePosition(targethead)
	
	return pos
	
end

local function GetBonePos( ply, bone )
	
	local pos = Vector( 0, 0, 0 )
	
	local bone = ply:LookupBone( bone )
	local pos, ang = ply:GetBonePosition( bone )
	
	return pos
	
end

local function GetLowestX( ply )
	
	local x = ScrW()
	
	local bones = { 
	"ValveBiped.Bip01_Head1", 
	"ValveBiped.Anim_Attachment_RH", 
	"ValveBiped.Bip01_Spine",
	"ValveBiped.Bip01_Spine2",
	"ValveBiped.Bip01_Spine4",
	"ValveBiped.Bip01_R_Hand", 
	"ValveBiped.Bip01_R_Forearm", 
	"ValveBiped.Bip01_R_Foot", 
	"ValveBiped.Bip01_R_Thigh", 
	"ValveBiped.Bip01_R_Calf", 
	"ValveBiped.Bip01_R_Shoulder", 
	"ValveBiped.Bip01_R_Elbow",
	"ValveBiped.Bip01_L_Hand", 
	"ValveBiped.Bip01_L_Forearm", 
	"ValveBiped.Bip01_L_Foot", 
	"ValveBiped.Bip01_L_Thigh", 
	"ValveBiped.Bip01_L_Calf", 
	"ValveBiped.Bip01_L_Shoulder", 
	"ValveBiped.Bip01_L_Elbow"
	}
	
	for k, v in pairs( bones ) do
		
		local cleanupcode = GetBonePos( ply, v ):ToScreen().x
		
		if cleanupcode < x then
			
			x = cleanupcode
			
		end
		
	end
	
	return x
	
end

local function GetHighestX( ply )
	
	local x = 0
	
	local bones = { 
	"ValveBiped.Bip01_Head1", 
	"ValveBiped.Anim_Attachment_RH", 
	"ValveBiped.Bip01_Spine",
	"ValveBiped.Bip01_Spine2",
	"ValveBiped.Bip01_Spine4",
	"ValveBiped.Bip01_R_Hand", 
	"ValveBiped.Bip01_R_Forearm", 
	"ValveBiped.Bip01_R_Foot", 
	"ValveBiped.Bip01_R_Thigh", 
	"ValveBiped.Bip01_R_Calf", 
	"ValveBiped.Bip01_R_Shoulder", 
	"ValveBiped.Bip01_R_Elbow",
	"ValveBiped.Bip01_L_Hand", 
	"ValveBiped.Bip01_L_Forearm", 
	"ValveBiped.Bip01_L_Foot", 
	"ValveBiped.Bip01_L_Thigh", 
	"ValveBiped.Bip01_L_Calf", 
	"ValveBiped.Bip01_L_Shoulder", 
	"ValveBiped.Bip01_L_Elbow"
	}
	
	for k, v in pairs( bones ) do
		
		local cleanupcode = GetBonePos( ply, v ):ToScreen().x
		
		if cleanupcode > x then
			
			x = cleanupcode
			
		end
		
	end
	
	return x
	
end

local function BKESPBox()
	
	local ply = LocalPlayer();
	
	if bk_esp:GetBool() == false then return end
	
	for k, v in pairs(player.GetAll()) do
	
		local isonblacklist = table.HasValue( BKAimbotBlacklist, v ) and bk_esp_use_friend_and_enemy_list:GetBool()
		local FriendColorEnabled = bk_esp_use_friend_color:GetBool() and table.HasValue( BKAimbotBlacklist, v )
		local allchecks = isonblacklist
		
		if v != ply and v:Alive() and !allchecks then
			
			local pos = Vector( 0, 0 )
			
			pos = ( GetHead( v ) + Vector( 0, 0, 7) ):ToScreen()
			pos.x = GetLowestX( v )
			local pos_end = Vector( GetHighestX( v ), v:GetPos():ToScreen().y )
			
			surface.SetDrawColor( FriendColorEnabled and FriendColor or bk_esp_use_custom_color:GetBool() and CustomColor or team.GetColor( v:Team() ) )
			surface.DrawOutlinedRect( pos.x, pos.y, pos_end.x - pos.x, pos_end.y - pos.y )
			
			if bk_esp_info:GetBool() == true and pos_end.x < ScrW() and pos_end.x > 0 then
			
				local finalx = pos_end.x + 5
				
				pos = (v:GetPos() + Vector( 0, 0, 70) ):ToScreen()
				
				draw.RoundedBox( 2, finalx, pos.y, 33, 5, Color( 255, 255, 255, 150 ) )
				draw.RoundedBox( 2, finalx + 1, pos.y + 1, v:Health() / 3 - 2, 3, Color( 255, 0, 0, 150 ) )
				
				pos.y = pos.y + 7
				
				draw.SimpleText( v:Name(), "DefaultSmall", finalx, pos.y + 1, Color( 0, 0, 0, 150 ) )
				draw.SimpleText( v:Name(), "DefaultSmall", finalx + 1, pos.y, FriendColorEnabled and FriendColor or bk_esp_use_custom_color:GetBool() and CustomColor or team.GetColor( v:Team() ) )
				
				pos.y = pos.y + 12
				
				local weapon = v:GetActiveWeapon()
				
				if IsValid( weapon ) then
				
					draw.SimpleText( weapon:GetClass(), "DefaultSmall", finalx, pos.y + 1, Color( 0, 0, 0, 255 ) )
					draw.SimpleText( weapon:GetClass(), "DefaultSmall", finalx + 1, pos.y, Color( 255, 255, 255, 255 ) )
				
				end
			
			end
			
		end
		
	end
	
end
 
hook.Add("HUDPaint", "BK.ESP.Box", BKESPBox)

local function GetVelocityPrediction( ply, target )
	
	local vel = ply:GetVelocity()
	local velpred = Vector( 0, 0, 0 )
	local dist = ply:GetPos():Distance( target:GetPos() ) and vel:Length()
	velpred.y = vel.y / 100
	
	return velpred
	
end

local function BKAimbotSilent()
	
	if !_inAttack and bk_aimbot_autoshoot:GetBool() == false or bk_aimbot_silent:GetBool() == false then return end
	
	local ply = LocalPlayer();
	
	local aiment = ply:GetEyeTrace().Entity
	
	local target = GetBestPlayer();
	
	if !target:Alive() or target == ply then if !AlreadyRanAttack then RunConsoleCommand( "-attack" ) AlreadyRanAttack = true end ShouldSeeAngle = false return end
	
	local nigger = GetHead( target )
	
	local VelPred = GetVelocityPrediction( ply, target )
	
	local lerpd = ( nigger - LocalPlayer():EyePos() - VelPred ):Angle()
	
	if bk_aimbot_silent_smooth:GetInt() > 0 then
		lerpd = lerpA( ply:EyeAngles(), ( nigger - LocalPlayer():EyePos()):Angle(), bk_aimbot_silent_smooth:GetInt() )
	end
	
	ShouldSeeAngle = lerpd;
	
	DistVec = math.abs(math.AngleDifference( ply:EyeAngles().p, lerpd.p )) * 180 + math.abs(math.AngleDifference( ply:EyeAngles().y, lerpd.y )) * 180
	
	ply:SetEyeAngles( lerpd )
	RunConsoleCommand( "+attack" )
	AlreadyRanAttack = false
	
end
hook.Add( "Think", "BK.Aimbot.Silent", BKAimbotSilent )

local function BKAimbot()

end
hook.Add( "Think", "BK.Aimbot", BKAimbot )
	
concommand.Add( "+bk_attack", function() 


	LastAimAngle = LocalPlayer():EyeAngles()
	LastAimPos = LocalPlayer():GetEyeTrace().HitPos
	_inAttack = true
	BKAimbotSilent()
	RunConsoleCommand( "+attack" )
	timer.Simple( 0.01, function() LocalPlayer():SetEyeAngles( LastAimAngle ) end )
	
end)
	
concommand.Add( "-bk_attack", function() 
		
	_inAttack = false
	plyRealAngle = LocalPlayer():EyeAngles().y
	ShouldSeeAngle = false;
	
	RunConsoleCommand( "-attack" )
		
end)

local function SmoothLook(ply, pos, angles, fov)
	
	local view = {}
	
	Cam3DAngles = angles
	
	if bk_norecoil:GetBool() and !bk_smoothlook:GetBool() then
		
		view.origin = pos
		view.angles = LocalPlayer():EyeAngles()
		
		if ShouldSeeAngle != false then
			view.angles = ShouldSeeAngle;
		end
		
		view.fov = fov
		view.znear = 0.1
		Cam3DAngles = view.angles
		
		view.angles.y = view.angles.y
		
		return view
		
	end
	
	if !bk_smoothlook:GetBool() then return end
	
	view.origin = LocalPlayer():EyePos()
	view.angles = LocalPlayer():EyeAngles()
	view.fov = fov
	view.znear = 0.1
	
	if getAnglesDifference( view.angles, realAngles ) > 5 then
		realAngles = LerpAngle( 0.9, view.angles, realAngles )
	end
	view.angles = realAngles
	
	view = GAMEMODE:CalcView(ply, view.origin, view.angles, view.fov, view.znear)
	local poop = ( LocalPlayer():GetEyeTrace().HitPos - view.origin ):Angle()
	view.vm_origin = nil
	savedAngle = LerpAngle( RealFrameTime() / 0.07, savedAngle, poop )
	view.vm_angles = savedAngle //( LocalPlayer():GetEyeTrace().HitPos - view.origin ):Angle()
	
	Cam3DAngles = view.angles
	return view
	
end
hook.Add( "CalcView", "SmoothLook", SmoothLook )

hook.Add( "HUDPaint", "Blue_Wall_.Hack", function()
	
	if bk_wallhack:GetBool() and bk_wallhack_players:GetBool() then
		
		local Pos = LocalPlayer():EyePos()
		local Ang = angles
		
		cam.Start3D( Pos, Cam3DAngles )
		
		for k, v in pairs ( player.GetAll() ) do
			
			if v:Health() > 0 and v != LocalPlayer() then
				
				render.SuppressEngineLighting( true )
				render.SetColorModulation( 0, 1, 0 )
				render.SetBlend( 1 )
				v:SetMaterial( "models/debug/debugwhite" )
				render.SetColorModulation( 1, 1, 1 )
				v:DrawModel()
					
				if v:GetActiveWeapon():IsValid() then
					v:GetActiveWeapon():DrawModel()
				end
				
				render.SuppressEngineLighting( false )
				
			end
			
		end
		
		cam.End3D()
	
	else
		
		for k, v in pairs ( player.GetAll() ) do
		
			v:SetMaterial( "" )
	
		end
		
	end
	
	if !bk_crosshair:GetBool() then return end
	
	local pos = LocalPlayer():GetEyeTrace().HitPos:ToScreen()
	pos.x = pos.x - 1
	
	if !bk_crosshair_actual_aim:GetBool() then pos = Vector( ScrW() / 2 - 1, ScrH() / 2 ) end
	
	surface.SetDrawColor(0, 0, 0, 255)
	surface.DrawLine( pos.x + 1, pos.y - 4, pos.x + 1, pos.y + 4 )
	surface.DrawLine( pos.x, pos.y - 4, pos.x, pos.y + 4 )
	surface.DrawLine( pos.x - 1, pos.y - 4, pos.x - 1, pos.y + 4 )
	
	surface.DrawLine( pos.x - 4, pos.y + 1, pos.x + 4, pos.y + 1 )
	surface.DrawLine( pos.x - 4, pos.y, pos.x + 4, pos.y )
	surface.DrawLine( pos.x - 4, pos.y - 1, pos.x + 4, pos.y - 1 )
	
	surface.SetDrawColor(255, 255, 255, 255)
	surface.DrawLine( pos.x, pos.y - 3, pos.x, pos.y + 3 )
	surface.DrawLine( pos.x - 3, pos.y, pos.x + 3, pos.y )
	
	draw.SimpleText( tostring(DistVec) )
	
end )