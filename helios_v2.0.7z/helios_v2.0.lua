/*
	gnu [STEAM_0:0:35901997 | 74.57.247.164:27005]
	helios.lua (16877 bytes)
*/
--require("helios"); ;__;
 
print(" _          _ _   ");        
print("| |        | (_)          ");
print("| |__   ___| |_  ___  ___ ");
print("| '_ \\ / _ \\ | |/ _ \\/ __|");
print("| | | |  __/ | | (_) \\__ \\");
print("|_| |_|\\___|_|_|\\___/|___/");
 
local helios = {
        hHook     = { sbList={}, list={}; };
        fHook     = { list={}; };
 
        visuals   = {};
        update    = {};
 
        lp        = LocalPlayer();
 
        derma     = {};
 
        convars   = {};
 
        targets   = {};
 
        trp       = {};
 
        _G        = table.Copy(_G);
} _G = table.Copy(helios["_G"]);
 
-- helios->hHook->sbHijackAdd (Sandbox Hooks): Find an already running hook and hijack it to point to our new function(s)
function helios.hHook.sbHijackAdd(hEvent, Function, NewFunction)
        for Event, FuncTbl in pairs(hook.Hooks) do
                if(Event == hEvent) then
                        for FuncName, Func in pairs(FuncTbl) do
                                if(FuncName == Function) then
                                        helios["hHook"]["sbList"][FuncName] = table.Copy(_G.hook.Hooks[Event])[FuncName];
                                        hook.Hooks[Event][FuncName] = function(m_vParam)
                                                helios["hHook"]["sbList"][FuncName](m_vParam);
                                                NewFunction(m_vParam);
                                        end
                                end
                        end
                end
        end
end
 
-- helios->hHook->hijackAdd (Non-Sandbox Hooks): Find an already running hook and hijack it to point to our new function(s)
function helios.hHook.hijackAdd(hEvent, Function, NewFunction)
        for Event, FuncTbl in pairs(hook.Hooks) do
                if(Event == hEvent) then
                        for FuncName, Func in pairs(FuncTbl) do
                                if(FuncName == Function) then
                                        if(helios["_G"] ~= nil) then
                                                helios["hHook"]["list"][FuncName] = table.Copy(_G.hook.Hooks[Event])[FuncName];
                                                hook.Hooks[Event][FuncName] = nil;
                                               
                                                helios["_G"]["hook"].Add(hEvent, Function, function(m_vParam)
                                                        helios["hHook"]["list"][FuncName](m_vParam);
                                                        NewFunction(m_vParam);
                                                end)
                                        end
                                end
                        end
                end
        end
end
 
function helios.determineHookType()
        helios.hHook.sbHijackAdd("Think", "RealFrameTime", function()
                helios["sbHook"] = true;
        end)
 
        if(helios["sbHook"] == true) then
                return "sandbox";
        else
                return "nonsandbox";
        end
end
 
print("[helios->Main] Hooking functions created");
 
function helios.genConVars()
        helios["convars"]["esp"] = helios["_G"].CreateClientConVar("helios_esp", 1, true, false);
        helios["convars"]["lights"] = helios["_G"].CreateClientConVar("helios_lights", 1, true, false);
        helios["convars"]["chams"] = helios["_G"].CreateClientConVar("helios_chams", 1, true, false);
        helios["convars"]["tracers"] = helios["_G"].CreateClientConVar("helios_tracers", 1, true, false);
        helios["convars"]["eyelasers"] = helios["_G"].CreateClientConVar("helios_eyelasers", 1, true, false);
        helios["convars"]["aimbot"] = helios["_G"].CreateClientConVar("helios_aimbot", 1, true, false);
        helios["convars"]["norecoil"] = helios["_G"].CreateClientConVar("helios_norecoil", 1, true, false);
        print("[helios->Main] Convars Created");
end
helios.genConVars();
 
function helios.visuals.isVisible(ply)
        helios["trp"].Trace = {};
 
        helios["trp"].Trace.start  = helios["lp"]:EyePos();
        helios["trp"].Trace.endpos = ply:EyePos();
        helios["trp"].Trace.filter = {helios["lp"], ply};
 
        helios["tr"] = util.TraceLine(helios["trp"].Trace);
 
        if(helios["tr"].Hit) then
                return true;
        end
end
 
 
 
function helios.antiAim(CUserCmd)
        local m_angOrig = CUserCmd:GetViewAngles();
        CUserCmd:SetViewAngles(Angle(math.random(-180,-186.49999), CUserCmd:GetViewAngles().y, 180));
        CUserCmd:SetViewAngles(m_angOrig);
end
 
function helios.visuals.Temporary()
        for _, v in pairs(player.GetAll()) do
                helios["pcolor"] = team.GetColor(v:Team());
                if(GetConVarNumber("helios_chams") == 1 && v:Alive() && v:Health() > 0 && v ~= helios["lp"]) then
                        cam.Start3D(EyePos(), EyeAngles());
                                render.SuppressEngineLighting(true);
                                render.SetBlend(0.2);
                                render.MaterialOverride(Material("models/debug/debugwhite"));
                                render.SetColorModulation(helios["pcolor"].r / 255, helios["pcolor"].g / 255, helios["pcolor"].b / 255);
                                v:DrawModel();
                                render.SuppressEngineLighting(false);
                                render.MaterialOverride();
                                render.SetColorModulation(1, 1, 1);
                        cam.End3D();
                end
 
                if(GetConVarNumber("helios_eyelasers") == 1 && v:Alive() && v:Health() > 0 && v ~= helios["lp"]) then
                        cam.Start3D(EyePos(), EyeAngles());
                        render.SetMaterial(Material("cable/redlaser"));
                        render.DrawBeam(v:EyePos(), v:GetEyeTrace().HitPos, 10, 1, 1, Color(0, 255, 0, 255));
                        cam.End3D();
                end
 
                if(GetConVarNumber("helios_tracers") == 1 && v:Alive() && v:Health() > 0 && v ~= helios["lp"] && !helios["visuals"].isVisible(v) && 1 == 2) then
                        cam.Start3D(EyePos(), EyeAngles());
                                if(LocalPlayer():GetViewModel():GetAttachment(LocalPlayer():GetViewModel():LookupAttachment("muzzle")) ~= nil) then
                                        render.SetMaterial(Material("cable/hydra"));
                                        render.DrawBeam(LocalPlayer():GetViewModel():GetAttachment(LocalPlayer():GetViewModel():LookupAttachment("muzzle")).Pos, v:EyePos(), 3, 1, 1, Color(0, 255, 0, 255));
                                end
                        cam.End3D();
                end
 
 
                if(GetConVarNumber("helios_lights") && v:Alive() && v:Health() > 0 && v ~= helios["lp"] && 1 == 2) then
                        helios["plight"] = DynamicLight(v:EntIndex());
                        if(helios["plight"]) then
                                helios["plight"].Pos = v:GetPos() + Vector(0, 0, 10);
                                helios["plight"].r = helios["pcolor"].r;
                                helios["plight"].g = helios["pcolor"].g;
                                helios["plight"].b = helios["pcolor"].b;
                                helios["plight"].Brightness = 5;
                                helios["plight"].Decay = 125 * 5;
                                helios["plight"].Size = 128;
                                helios["plight"].DieTime = CurTime() + 1;
                        else
                                helios["plight"].DieTime = CurTime();
                        end
                end
        end
end
 
function helios.Aimbot(CUserCmd)
        for _, v in pairs(player.GetAll()) do
                if(v ~= helios["lp"] && v:IsValid() && v:LookupBone("ValveBiped.Bip01_Head1") ~= nil && GetConVarNumber("helios_aimbot") == 1 && v:Team() ~= TEAM_SPECTATOR) then
                        helios.target = {};
                        helios["target"].Bone = 0;
                        if(v:GetAttachment(v:LookupAttachment("eyes")) ~= nil) then
                                helios["target"].Bone = v:GetAttachment(v:LookupAttachment("eyes")).Pos;
                        elseif(v:GetAttachment(v:LookupAttachment("forward")) ~= nil) then
                                helios["target"].Bone = v:GetAttachment(v:LookupAttachment("forward")).Pos;
                        elseif(v:GetAttachment(v:LookupAttachment("head")) ~= nil) then
                                helios["target"].Bone = v:GetAttachment(v:LookupAttachment("head")).Pos;
                        else
                                helios["target"].Bone = v:GetBonePosition(v:LookupBone("ValveBiped.Bip01_Head1")).Pos;
                        end
 
                        if(v:Health() > 0 && !helios["visuals"].isVisible(v) && (helios["target"].Bone:ToScreen().x - (ScrW() / 2)) <= 100 && (helios["target"].Bone:ToScreen().x - (ScrW() / 2)) >= -100 && (helios["target"].Bone:ToScreen().y - (ScrH() / 2)) <= 100 && (helios["target"].Bone:ToScreen().y - (ScrH() / 2)) >= -100) then
                                helios["target"].AimAngle = helios["target"].Bone;
                                if(v:GetColor().a ~= 200 && helios["lp"]:GetColor().a ~= 200) then
                                        helios["target"].AimAngle = helios["target"].AimAngle + (helios["lp"]:GetVelocity() / 45 - helios["lp"]:GetVelocity() / 45);
 
                                        helios["target"].AimAngle = (helios["target"].AimAngle - helios["lp"]:GetShootPos()):Angle();
 
                                        if(helios["lp"]:GetVelocity():Length() > 100) then
                                                helios["target"].AimAngle = helios["target"].AimAngle + Angle(0, 0, helios["lp"]:GetVelocity():Length() / 250);
                                        end
 
                                        helios["target"].AimAngle.p = math.NormalizeAngle(helios["target"].AimAngle.p);
                                        helios["target"].AimAngle.y = math.NormalizeAngle(helios["target"].AimAngle.y);
                                        helios["target"].r = 0;
 
                                        if(input.IsMouseDown(MOUSE_LEFT)) then
                                                CUserCmd:SetViewAngles(helios["target"].AimAngle);
                                        end
                                end
                        end
                end
        end
end
 
function helios.FireBullet()    RunConsoleCommand("+attack"); end
function helios.EndFireBullet() RunConsoleCommand("-attack"); end
 
function helios.TriggerBot()
        if(helios["lp"]:GetShootPos() ~= nil && 1 == 2) then
                helios.Pos          = helios["lp"]:GetShootPos();
                helios.Ang          = helios["lp"]:GetAimVector();
                helios.Trace        = {};
                helios.Trace.start  = helios.Pos;
                helios.Trace.endpos = helios.Pos + (helios.Ang * 99999999999);
                helios.Trace.filter = helios["lp"];
 
                helios.LTrace       = util.TraceLine(helios.Trace);
 
                if(input.IsKeyDown(KEY_LALT) && helios.LTrace.HitNonWorld) then
                        helios.Target = helios.LTrace.Entity;
                        if(helios.Target:IsPlayer()) then
                                if(helios.Target != helios["lp"] && helios.Target:Alive() && helios.Target:Health() > 0 && IsValid(helios.Target)) then
                                        helios.FireBullet();
                                        timer.Simple(0.001, function() helios.EndFireBullet() end);
                                end
                        end
                end
        end
end

hook.Add("HUDPaint", "a", helios.visuals.Temporary);

concommand.Add("+helios_speedhack", function()
        RunConsoleCommand("host_framerate", "10");
end)
concommand.Add("-helios_speedhack", function()
        RunConsoleCommand("host_framerate", "0");
end)
 
if(helios.determineHookType() == "sandbox") then
        helios.hHook.sbHijackAdd("Think", "RealFrameTime", function()
                helios.TriggerBot();
                if(LocalPlayer():GetActiveWeapon().Primary ~= nil && GetConVarNumber("helios_nospread")) then
                        LocalPlayer():GetActiveWeapon().Primary.Recoil = 0;
                end
        end);
 
        Msg("[helios->Hooking] Detoured Think hook [RealFrameTime] -> ");
        Msg(hook.Hooks["Think"].RealFrameTime);
        Msg("\n");
 
        helios.hHook.sbHijackAdd("HUDPaint", "DrawRecordingIcon", function()
                helios.visuals.Temporary();
        end);
 
        Msg("[helios->Hooking] Detoured HUDPaint hook [DrawRecordingIcon] -> ");
        Msg(hook.Hooks["HUDPaint"].DrawRecordingIcon);
        Msg("\n");
 
        if(hook.Hooks["CreateMove"] ~= nil && hook.Hooks["CreateMove"].propspawn_SetupMove ~= nil) then
                helios.hHook.sbHijackAdd("CreateMove", "propspawn_SetupMove", function(CUserCmd)
                        helios.Aimbot(CUserCmd);
                        helios.antiAim(CUserCmd);
                end);
        else
                print("[helios->Hooking] Warning: Unable to locate CreateMove hook. Creating hook.");
                helios["_G"].hook.Add("CreateMove", "propspawn_SetupMove", function(CUserCmd)
                        helios.Aimbot(CUserCmd);
                        helios.antiAim(CUserCmd);
                end)
        end
 
        Msg("[helios->Hooking] Detoured CreateMove hook [propspawn_SetupMove] -> ");
        //Msg(hook.Hooks["CreateMove"].propspawn_SetupMove);
        Msg("\n");
else
        helios.hHook.hijackAdd("Think", "RealFrameTime", function()
                helios.TriggerBot();
 
                if(LocalPlayer():GetActiveWeapon().Primary ~= nil && GetConVarNumber("helios_nospread")) then
                        LocalPlayer():GetActiveWeapon().Primary.Recoil = 0;
                end
        end);
 
        Msg("[helios->Hooking] Detoured Think hook [RealFrameTime] -> ");
        Msg(hook.Hooks["Think"].RealFrameTime);
        Msg("\n");
 
        helios.hHook.hijackAdd("HUDPaint", "DrawRecordingIcon", function()
                helios.visuals.Temporary();
        end);
 
        Msg("[helios->Hooking] Detoured HUDPaint hook [DrawRecordingIcon] -> ");
        Msg(hook.Hooks["HUDPaint"].DrawRecordingIcon);
        Msg("\n");
 
        if(hook.Hooks["CreateMove"] ~= nil && hook.Hooks["CreateMove"].propspawn_SetupMove ~= nil) then
                helios.hHook.hijackAdd("CreateMove", "propspawn_SetupMove", function(CUserCmd)
                        helios.Aimbot(CUserCmd);
                        helios.antiAim(CUserCmd);
                end);
        else
                print("[helios->Hooking] Warning: Unable to locate CreateMove hook. Creating hook.");
                helios["_G"].hook.Add("CreateMove", "propspawn_SetupMove", function(CUserCmd)
                        helios.Aimbot(CUserCmd);
                        helios.antiAim(CUserCmd);
                end)
        end
 
        Msg("[helios->Hooking] Detoured CreateMove hook [propspawn_SetupMove] -> ");
        //Msg(hook.Hooks["CreateMove"].propspawn_SetupMove);
        Msg("\n");
end
helios["origplayer"] = table.Copy(FindMetaTable("Player"));
helios["player"] = FindMetaTable("Player");
 
helios["player"].MetaBaseClass.FireBullets = function(m_entOrig, m_structBullet)
                print("FireBullets Called with spread [" .. m_structBullet.Spread.x .. ", " .. m_structBullet.Spread.y .. ", " .. m_structBullet.Spread.z  .. "] -> Vector(0, 0, 0)");
                m_structBullet.Tracer = 1;
                m_structBullet.Spread = Vector(0, 0, 0);
 
        helios["origplayer"]["MetaBaseClass"].FireBullets(m_entOrig, m_structBullet);
end
 
Msg("[helios->Hooking] Detoured FireBullets -> ");
Msg(helios["player"].MetaBaseClass.FireBullets);
Msg("\n");
 
--[[require("helios");
 
helios.OrigPlayer = table.Copy(FindMetaTable("Player")).MetaBaseClass;
helios.Player     = FindMetaTable("Player");
 
helios.handler_firebullets = function(m_ePlayer, m_eShot)
        print("FireBullets Called with spread [" .. m_eShot.Spread.x .. ", " .. m_eShot.Spread.y .. ", " .. m_eShot.Spread.z  .. "] -> Vector(0, 0, 0)");
        m_eShot["Spread"] = Vector(0, 0, 0);
 
        return helios.OrigPlayer.FireBullets(m_ePlayer, m_eShot);
end
 
helios.ApplyHook(FIRE_BULLETS);]]--
