--[[
	haha i removed your credits
	~ coded by seth ~
	Fixed again by HeX
]]


local Enabled = CreateClientConVar("shit_box", 1, true, false)


surface.CreateFont("DefaultSmallDropShadow", {
		font	= "Tahoma",
		size	= 16,
		weight	= 500,
		shadow	= true,
	}
)	


local TRANS = Color(0,0,0,255)

local function DrawESP()
	if not Enabled:GetBool() then return end
	
	local x,y,color
	local mon,nom
	local h,w
	local bot,top
	local sx,sy
	local size = 5
	
	for k,v in pairs( player.GetAll() ) do
		if not IsValid(v) or not v:Alive() or v == LocalPlayer() then
			continue
		end
		if v:Team() == TEAM_SPECTATOR or v:GetMoveType() == MOVETYPE_OBSERVER then
			continue
		end
		
		local tCol = team.GetColor( v:Team() )
		
		nom = v:GetPos()
		mon = nom + Vector( 0, 0, v:OBBMaxs().z )
		
		bot = nom:ToScreen()
		top = mon:ToScreen()
		
		h = ( bot.y - top.y )
		w = h;
		
		sx,sy = 0,0;
		
		
		// Top left
		sx = ( top.x - ( w / 2 ) )
		sy = top.y;
		
		surface.SetDrawColor(TRANS)
		
		surface.DrawRect( sx - 1, sy - 1, size + 2, 3 )
		surface.DrawRect( sx - 1, sy - 1, 3, size + 2 )
		
		surface.SetDrawColor(tCol)
		surface.DrawLine( sx, sy, sx + size, sy )
		surface.DrawLine( sx, sy, sx, sy + size )
		
		// Top right
		sx = ( top.x + ( w / 2 ) )
		sy = top.y;
		
		surface.SetDrawColor(TRANS)
		
		surface.DrawRect( sx - size, sy - 1, size + 2, 3 )
		surface.DrawRect( sx - 1, sy - 1, 3, size + 2 )
		
		surface.SetDrawColor(tCol)
		surface.DrawLine( sx, sy, sx - size, sy )
		surface.DrawLine( sx, sy, sx, sy + size )
		
		//Bottom left
		sx = ( bot.x - ( w / 2 ) )
		sy = bot.y;
		
		surface.SetDrawColor(TRANS)
		
		surface.DrawRect( sx - 1, sy - 1, size + 2, 3 )
		surface.DrawRect( sx - 1, sy - size, 3, size + 2 )
		
		surface.SetDrawColor(tCol)
		surface.DrawLine( sx, sy, sx + size, sy )
		surface.DrawLine( sx, sy, sx, sy - size )
		
		//Bottom right
		sx = ( bot.x + ( w / 2 ) )
		sy = bot.y;
		
		surface.SetDrawColor(TRANS)
		
		surface.DrawRect( sx - size, sy - 1, size + 2, 3)
		surface.DrawRect( sx - 1, sy - size, 3, size + 2)
		
		surface.SetDrawColor(tCol)
		surface.DrawLine( sx, sy, sx - size, sy )
		surface.DrawLine( sx, sy, sx, sy - size )
		
		local posX 		= top.x
		local posY 		= top.y - 10
		local esppos	= ( v:GetPos() + Vector( 0, 0, v:OBBMaxs().z ) ):ToScreen()
		
		draw.SimpleText(
			v:Nick()..' ('..v:Health()..')',
			"DefaultSmallDropShadow",
			esppos.x,
			esppos.y,
			tCol,
			1
		)
	end
end
hook.Add("PostRenderVGUI", "ESP", DrawESP)








