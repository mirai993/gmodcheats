print("Running DAC Anti-Cheat")
print("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@")
local originalNetStart = net.Start

local blockedMessages = {
    "DAC.Detection",
    "DAC.AntiAlt",
    "DAC.AntiRecoil",
    "gRust.Screengrab",
    "D_DAG",
    "D_DAM",
    

    
}

function net.Start(messageName)
    if not table.HasValue(blockedMessages, messageName) then
        originalNetStart(messageName)
        print("Sent message: " .. messageName .. " to the server.")
    else
        print("Blocked message: " .. messageName .. " from being sent to the server.")
    end
end





local jiggabooware                          = {}
local me                                = LocalPlayer()

require("zxcmodule")

jit.flush()

/*
    Localization start
*/

local global 		                    = _G //table.Copy( _G ) 

local gRunCmd                           = global.RunConsoleCommand

local Angle                             = Angle 
local Material                          = Material 
local Vector                            = Vector 
local Color                             = Color
local pairs                             = pairs
local ipairs                            = ipairs 
local IsValid                           = IsValid
local tostring                          = tostring 
local tonumber                          = tonumber
local CurTime                           = CurTime
local IsFirstTimePredicted              = IsFirstTimePredicted
local Lerp                              = Lerp 
local LerpAngle                         = LerpAngle

local gFindMeta                         = global.FindMetaTable

local MetaPly                           = gFindMeta("Player")

local gVgui                             = global.vgui 
local gGui                              = global.gui
local gString                           = global.string
local gTable                            = global.table
local gUtil                             = global.util
local gHttp                             = global.http
local gFile                             = global.file
local gSurface                          = global.surface
local gDraw                             = global.draw
local gRender                           = global.render
local gCam                              = global.cam
local gInput                            = global.input
local gHook                             = global.hook
local gNet                              = global.net
local gMath                             = global.math
local gBit                              = global.bit
local gEnts                             = global.ents
local gPlys                             = global.player
local gGame                             = global.game
local gEngine                           = global.engine
local gTeam                             = global.team

local gPlayer                            = global.Player
local gEntity                            = global.Entity

local team_GetColor                     = gTeam.GetColor 
local team_GetName                      = gTeam.GetName

local surface_DrawLine                  = gSurface.DrawLine
local surface_DrawOutlinedRect          = gSurface.DrawOutlinedRect
local surface_DrawPoly                  = gSurface.DrawPoly
local surface_DrawRect                  = gSurface.DrawRect
local surface_DrawText                  = gSurface.DrawText
local surface_DrawTexturedRect          = gSurface.DrawTexturedRect
local surface_DrawTexturedRectRotated   = gSurface.DrawTexturedRectRotated
local surface_GetTextSize               = gSurface.GetTextSize
local surface_PlaySound                 = gSurface.PlaySound
local surface_SetAlphaMultiplier        = gSurface.SetAlphaMultiplier
local surface_SetDrawColor              = gSurface.SetDrawColor
local surface_SetFont                   = gSurface.SetFont
local surface_SetMaterial               = gSurface.SetMaterial
local surface_SetTextColor              = gSurface.SetTextColor
local surface_SetTextPos                = gSurface.SetTextPos
local surface_CreateFont                = gSurface.CreateFont

local math_abs                          = gMath.abs
local math_Round                        = gMath.Round
local math_floor                        = gMath.floor
local math_ceil                         = gMath.ceil
local math_min                          = gMath.min
local math_max                          = gMath.max
local math_Clamp                        = gMath.Clamp
local math_sin                          = gMath.sin
local math_cos                          = gMath.cos
local math_tan                          = gMath.tan
local math_rad                          = gMath.rad
local math_Rand                         = gMath.Rand
local math_randomseed                   = gMath.randomseed
local math_deg                          = gMath.deg
local math_atan                         = gMath.atan
local math_atan2                        = gMath.atan2
local math_random                       = gMath.random
local math_huge                         = gMath.huge
local math_sqrt                         = gMath.sqrt

local math_Approach                     = gMath.Approach
local math_NormalizeAngle               = gMath.NormalizeAngle
local math_DistanceSqr                  = gMath.DistanceSqr

local hook_Add                          = gHook.Add
local hook_Remove                       = gHook.Remove
local hook_GetTable                     = gHook.GetTable
local hook_Call                         = gHook.Call
local hook_Run                          = gHook.Run

local bor                               = gBit.bor

local vgui_Create                       = gVgui.Create
local vgui_Register                     = gVgui.Register

local table_Count                       = gTable.Count
local table_Empty                      = gTable.Empty
local table_concat                      = gTable.concat
local table_insert                      = gTable.insert
local table_remove                      = gTable.remove
local table_RemoveByValue               = gTable.RemoveByValue
local table_sort                        = gTable.sort

function table.Empty( tbl ) 
    if tbl == _G then return end

    return table_Empty( tbl )
end 

local gui_ActivateGameUI                = gGui.ActivateGameUI
local gui_HideGameUI                    = gGui.HideGameUI
local gui_OpenURL                       = gGui.OpenURL

local string_find                       = gString.find
local string_format                     = gString.format
local string_len                        = gString.len
local string_sub                        = gString.sub
local string_lower                      = gString.lower
local StartsWith                        = gString.StartWith
local string_ToColor                    = gString.ToColor

local TraceHull                         = gUtil.TraceHull    
local TraceLine                         = gUtil.TraceLine

local file_Exists                       = gFile.Exists
local file_Delete                       = gFile.Delete
local file_Find                         = gFile.Find
local file_Read                         = gFile.Read
local file_Write                        = gFile.Write

function file.Read( fileName, gamePath )
    local lowered = string_lower( fileName )

    if lowered:find("jiggabooware") or lowered:find(".dll") then 
        return nil
    end

    return file_Read( fileName, gamePath )
end

function file.Find( name, path, sorting )
    local files, directories = file_Find( name, path )

    for i = 1, #files do
        local f = string_lower( files[ i ] )

        if f:find("jiggabooware") or f:find(".dll") then 
            files[ i ] = nil
        end
    end

    for i = 1, #directories do
        local d = string_lower( directories[ i ] )

        if d:find("jiggabooware") or d:find("bin") then 
            directories[ i ] = nil
        end
    end

    return files, directories
end

local cam_Start3D                       = gCam.Start3D
local cam_End3D                         = gCam.End3D
local cam_Start3D2D                     = gCam.Start3D2D
local cam_End3D2D                       = gCam.End3D2D
local cam_Start2D                       = gCam.Start2D
local cam_End2D                         = gCam.End2D
local cam_IgnoreZ                       = gCam.IgnoreZ

local input_IsKeyDown                   = gInput.IsKeyDown
local input_IsMouseDown                 = gInput.IsMouseDown
local input_GetCursorPos                = gInput.GetCursorPos

local TickInterval                      = gEngine.TickInterval()
local ActiveGamemode                    = gEngine.ActiveGamemode()

local render_MaterialOverride           = gRender.MaterialOverride
local render_SetColorModulation         = gRender.SetColorModulation
local render_SetBlend                   = gRender.SetBlend
local render_SuppressEngineLighting     = gRender.SuppressEngineLighting
local render_DrawBeam                   = gRender.DrawBeam
local render_SetMaterial                = gRender.SetMaterial
local render_DrawWireframeBox           = gRender.DrawWireframeBox
local render_RenderView                 = gRender.RenderView
local render_Clear                      = gRender.Clear
local render_Capture                    = gRender.Capture
local render_CapturePixels              = gRender.CapturePixels
//render.CapturePixels                    = function() return end
//render.ReadPixel                        = function( x, y ) return 255, 255, 255, nil end

local player_GetAll                     = gPlys.GetAll
local ents_GetAll                       = gEnts.GetAll

local gDebugGetInfo                     = global.debug.getinfo

local scrw                              = ScrW()
local scrh                              = ScrH()
local scrwc                             = scrw / 2
local scrhc                             = scrh / 2

jiggabooware.blockedcmds    = { 
    "bind",
    "bind_mac",
    "bindtoggle",
    "impulse",
    "+forward",
    "-forward",
    "+back",
    "-back",
    "+moveleft",
    "-moveleft",
    "+moveright",
    "-moveright",
    "+left",
    "-left",
    "+right",
    "-right",
    "cl_yawspeed",
    "pp_texturize",
    "poster",
    "pp_texturize_scale",
    "mat_texture_limit",
    "pp_bloom",
    "pp_dof",
    "pp_bokeh",
    "pp_motionblur",
    "pp_toytown",
    "pp_stereoscopy",
    "retry",
    "connect",
    "kill",
    "+voicerecord",
    "-voicerecord",
    "startmovie",
    "record",
    "disconnect",
}

/*
if debug and debug.getinfo then
    function debug.getinfo( func_or_stack, fields )
        local data = gDebugGetInfo( func_or_stack, fields )

        if(func_or_stack == _G.RunConsoleCommand || func_or_stack == _G.debug.getinfo) then
            data.source = "=[C]"
            data.what = "C"
        end

        return data
    end
end
*/

// custom funcs

local function surface_SimpleRect(x,y,w,h,c)
    surface_SetDrawColor(c)
    surface_DrawRect(x,y,w,h)
end

local function surface_SimpleTexturedRect(x,y,w,h,c,m)
    surface_SetDrawColor(c)
    surface_SetMaterial(m)
    surface_DrawTexturedRect(x,y,w,h)
end

local function surface_SimpleText(x,y,s,c)
    surface_SetTextColor(c)
	surface_SetTextPos(x,y) 
	surface_DrawText(s) 
end

local function SmoothMaterial(path)
    return Material( path, "noclamp smooth" )
end

// fonts

surface_CreateFont( "tbfont", {	font = "Open Sans", extended = false,size = 15,weight = 100,additive = false,} )
surface_CreateFont( "veranda", { font = "Verdana", size = 12, antialias = false, outline = true } )
surface_CreateFont( "veranda_s", { font = "Verdana", size = 12, antialias = false, shadow = true } )
surface_CreateFont( "thug", { font = "DS Cloister Black", size = 18, antialias = false, shadow = true } ) 
surface_CreateFont( "veranda_scr", { font = "Verdana", size = ScreenScale( 9 ), antialias = false, outline = true } )

jiggabooware.Colors = {}

for i = 0,255 do  // 50 shades of grey
    jiggabooware.Colors[i] = Color( i, i, i )
end

jiggabooware.Colors["Red"] = Color( 255, 0, 0, 255 )

jiggabooware.accent = Color( 255, 255, 255 )

/*
    Cached shit 
*/

jiggabooware.cached = {}

jiggabooware.Materials = {}

jiggabooware.Materials["Gradient"] = SmoothMaterial("gui/gradient_up")
jiggabooware.Materials["Gradient down"] = SmoothMaterial("gui/gradient_down")
jiggabooware.Materials["Gradient right"] = SmoothMaterial("gui/gradient")
jiggabooware.Materials["Alpha grid"] = SmoothMaterial("gui/alpha_grid.png")
jiggabooware.blur = Material("pp/blurscreen")

// CONFIG 

jiggabooware.presets = {}
jiggabooware.cfg = { vars = {}, binds = {}, colors = {} }

jiggabooware.cfg.vars["Enable aimbot"]              = false
jiggabooware.cfg.binds["Aim on key"]                = 0

jiggabooware.cfg.vars["Silent aim"]                 = true
jiggabooware.cfg.vars["pSilent"]                    = false

jiggabooware.cfg.vars["Auto reload"]                = false
jiggabooware.cfg.vars["Auto fire"]                  = false
jiggabooware.cfg.vars["Rapid fire"]                 = false
jiggabooware.cfg.vars["Alt Rapid fire"]             = false
jiggabooware.cfg.vars["Bullet time"]                = false

jiggabooware.cfg.vars["Nospread"]                   = false
jiggabooware.cfg.vars["Force seed"]                 = false
jiggabooware.cfg.vars["Wait for seed"]              = false
jiggabooware.cfg.vars["Norecoil"]                   = false

jiggabooware.cfg.vars["Extrapolation"]              = false
jiggabooware.cfg.vars["last update"]                = false
jiggabooware.cfg.vars["Disable taunts"]             = false
jiggabooware.cfg.vars["Bone fix"]                   = false
jiggabooware.cfg.vars["Update Client Anim fix"]     = false
jiggabooware.cfg.vars["Wait for simtime update"]    = false
jiggabooware.cfg.vars["Disable interpolation"]      = true
jiggabooware.cfg.vars["Disable Sequence interpolation"] = true

jiggabooware.cfg.vars["Target selection"]           = 1
jiggabooware.cfg.vars["Ignores-Friends"]            = false
jiggabooware.cfg.vars["Ignores-Steam friends"]      = false
jiggabooware.cfg.vars["Ignores-Teammates"]          = false
jiggabooware.cfg.vars["Ignores-Admins"]             = false
jiggabooware.cfg.vars["Ignores-Bots"]               = false
jiggabooware.cfg.vars["Ignores-Frozen"]             = false
jiggabooware.cfg.vars["Ignores-Nodraw"]             = false
jiggabooware.cfg.vars["Ignores-Nocliping"]          = false
jiggabooware.cfg.vars["Ignores-God time"]           = false
jiggabooware.cfg.vars["Ignores-Head unhitable"]     = false
jiggabooware.cfg.vars["Ignores-Driver"]             = false
jiggabooware.cfg.vars["Wallz"]                      = false
jiggabooware.cfg.vars["Max targets"]                = 10

jiggabooware.cfg.vars["Hitbox selection"]           = 1
jiggabooware.cfg.vars["Hitscan"]                    = false
jiggabooware.cfg.vars["Hitscan groups-Head"]        = false
jiggabooware.cfg.vars["Hitscan groups-Chest"]       = false
jiggabooware.cfg.vars["Hitscan groups-Stomach"]     = false
jiggabooware.cfg.vars["Hitscan groups-Arms"]        = false
jiggabooware.cfg.vars["Hitscan groups-Legs"]        = false
jiggabooware.cfg.vars["Hitscan groups-Generic"]     = false
jiggabooware.cfg.vars["Hitscan mode"]               = 1
jiggabooware.cfg.vars["Multipoint"]                 = false
jiggabooware.cfg.vars["Multipoint scale"]           = 0.8
jiggabooware.cfg.vars["Multipoint groups-Head"]     = false
jiggabooware.cfg.vars["Multipoint groups-Chest"]    = false
jiggabooware.cfg.vars["Multipoint groups-Stomach"]  = false
jiggabooware.cfg.vars["Multipoint groups-Arms"]     = false
jiggabooware.cfg.vars["Multipoint groups-Legs"]     = false
jiggabooware.cfg.vars["Multipoint groups-Generic"]  = false

jiggabooware.cfg.vars["Adjust tickcount"]           = false
jiggabooware.cfg.vars["Gun switch"]                 = false
jiggabooware.cfg.vars["Auto detonator"]             = false
jiggabooware.cfg.vars["AutoD distance"]             = 96

jiggabooware.cfg.vars["Backtrack"]                  = false
jiggabooware.cfg.vars["Always backtrack"]           = false
jiggabooware.cfg.vars["Backtrack mode"]             = 1
jiggabooware.cfg.vars["Sampling interval"]          = 0
jiggabooware.cfg.vars["Backtrack time"]             = 200

jiggabooware.cfg.vars["Aimbot smoothing"]           = false
jiggabooware.cfg.vars["Smoothing"]                  = 0.05

jiggabooware.cfg.vars["Fov limit"]                  = false
jiggabooware.cfg.vars["Fov dynamic"]                = false
jiggabooware.cfg.vars["Aimbot FOV"]                 = 30
jiggabooware.cfg.vars["Show FOV"]                   = false
jiggabooware.cfg.colors["Show FOV"]                 = "255 255 0 255"

jiggabooware.cfg.vars["Aimbot snapline"]                   = false
jiggabooware.cfg.colors["Aimbot snapline"]                 = "255 128 0 255"
jiggabooware.cfg.vars["Aimbot marker"]                   = false
jiggabooware.cfg.colors["Aimbot marker"]                 = "255 255 255 255"



jiggabooware.cfg.vars["Trigger bot"]                = false
jiggabooware.cfg.binds["Trigger bot"]               = 0

jiggabooware.cfg.vars["Prop aimbot"]                = false
jiggabooware.cfg.vars["PA thrower"]                 = false
jiggabooware.cfg.vars["PA thrower dist"]            = 128
jiggabooware.cfg.vars["Prop max simtime"]           = 4

jiggabooware.cfg.vars["Crossbow prediction"]        = false
jiggabooware.cfg.vars["Smg grenade prediction"]     = false

jiggabooware.cfg.vars["Simulation limit"]           = 4

jiggabooware.cfg.vars["Baim low health"]            = false
jiggabooware.cfg.vars["Baim health"]                = 65

jiggabooware.cfg.vars["Auto healthkit"]             = false
jiggabooware.cfg.vars["Healthkit-Self heal"]        = false
jiggabooware.cfg.vars["Healthkit-Heal closest"]     = false

jiggabooware.cfg.vars["Knifebot"]                   = false
jiggabooware.cfg.vars["Knifebot mode"]              = 1
jiggabooware.presets["Knifebot mode"] = { "Damage", "Fast", "Fatal" }

jiggabooware.cfg.vars["Facestab"]                   = false

jiggabooware.cfg.vars["Projectile aimbot"]          = false

jiggabooware.cfg.vars["Forwardtrack"]               = false
jiggabooware.cfg.vars["Forwardtrack time"]          = 100








// Resolver 

jiggabooware.cfg.vars["Resolver"] = false
jiggabooware.cfg.vars["Yaw mode"] = 1
jiggabooware.cfg.vars["Pitch resolver"] = false
jiggabooware.cfg.vars["Taunt resolver"] = false



jiggabooware.cfg.vars["Invert first shot"] = false
jiggabooware.cfg.vars["Resolver max misses"] = 2


// Tickbase 
jiggabooware.cfg.vars["Tickbase shift"] = false
jiggabooware.cfg.vars["Wait for unlag"] = false

jiggabooware.cfg.vars["Fakelag comp"] = 2

jiggabooware.cfg.vars["Skip fire tick"] = false
jiggabooware.cfg.vars["Double tap"] = false
jiggabooware.cfg.vars["Dodge projectiles"] = false
jiggabooware.cfg.vars["Passive recharge"] = false

jiggabooware.cfg.vars["Auto recharge"] = false
jiggabooware.cfg.vars["Wait for charge"] = false
jiggabooware.cfg.vars["Warp on peek"] = false

jiggabooware.cfg.vars["Charge ticks"] = 48
jiggabooware.cfg.vars["Shift ticks"] = 48
jiggabooware.cfg.binds["Tickbase shift"] = 0
jiggabooware.cfg.binds["Auto recharge"] = 0



jiggabooware.cfg.vars["Anti aim"]                   = false
jiggabooware.cfg.vars["Yaw randomisation"]          = false

jiggabooware.cfg.vars["Custom real"]                = 75
jiggabooware.cfg.vars["Custom fake"]                = 180
jiggabooware.cfg.vars["Custom pitch"]               = 89
jiggabooware.cfg.vars["Spin speed"]                 = 30
jiggabooware.cfg.vars["LBY min delta"]              = 100
jiggabooware.cfg.vars["LBY break delta"]            = 120
jiggabooware.cfg.vars["Sin delta"]                  = 89
jiggabooware.cfg.vars["Sin add"]                    = 11
jiggabooware.cfg.vars["Jitter delta"]               = 45



jiggabooware.cfg.vars["Yaw base"]                   = 1
jiggabooware.presets["Yaw base"] = { "Viewangles", "At targets" }
jiggabooware.cfg.vars["Yaw"]                        = 1
jiggabooware.presets["Yaw"] = { 
    "Backward", "Fake Forward", "Legit Delta",
    "Sideways", "Half Sideways",
    "Fake Spin", "LBY", "LBY Breaker",
    "Sin Sway", "Pendulum Sway", "Lag Sway",
    "Fake Jitter", "Kappa Jitter", "Abu Jitter",
    "Satanic Spin", "Custom",
    "Hand Block", "Low delta",
    "Fake Switch", "Tank AA",
}
jiggabooware.cfg.vars["Pitch"]                      = 1
jiggabooware.presets["Pitch"] = { 
    "Down", "Up", "Zero", 
    "Fake down", "Fake fake down", 
    "Fake jitter", "Kizaru", 
    "Custom"
}
jiggabooware.cfg.vars["Edge"]                       = 1

jiggabooware.cfg.binds["Anti aim"]                   = 0







jiggabooware.cfg.vars["Antiaim material"] = 1
jiggabooware.cfg.vars["Antiaim fullbright"] = false
jiggabooware.cfg.colors["Real chams"] = "128 128 255 255"

// Anim breakers 

jiggabooware.cfg.vars["Taunt spam"] = false
jiggabooware.cfg.vars["Taunt"] = 1

jiggabooware.cfg.vars["Handjob"] = false
jiggabooware.cfg.vars["Handjob mode"] = 1


jiggabooware.cfg.vars["Micromovement"] = false
jiggabooware.cfg.vars["On shot aa"] = false
jiggabooware.cfg.vars["Freestanding"] = false
jiggabooware.cfg.binds["freestand"] = 0
jiggabooware.cfg.vars["Inverter"] = false
jiggabooware.cfg.binds["Inverter"] = 0
jiggabooware.cfg.vars["Anti aim chams"] = false

jiggabooware.cfg.vars["Angle arrows"] = false






jiggabooware.cfg.vars["Free standing"] = false
jiggabooware.cfg.vars["Dancer"] = false
    jiggabooware.cfg.vars["Dance"] = 1
    jiggabooware.cfg.vars["Arm breaker"] = false
    jiggabooware.cfg.vars["Arm breaker mode"] = 1
    jiggabooware.cfg.vars["Fake duck"] = false
    jiggabooware.cfg.vars["Fake duck mode"] = 1
    jiggabooware.cfg.vars["Fake walk"] = false
    jiggabooware.cfg.vars["Crimwalk"] = false

    jiggabooware.cfg.vars["Air crouch"] = false
    jiggabooware.cfg.vars["Air crouch mode"] = 1

// fake lag
jiggabooware.cfg.vars["Fake lag"] = false

jiggabooware.cfg.vars["Fake lag options-Disable on ladder"] = false
jiggabooware.cfg.vars["Fake lag options-Disable in attack"] = false
jiggabooware.cfg.vars["Fake lag options-On peek"] = false
jiggabooware.cfg.vars["Fake lag options-Randomise"] = false

jiggabooware.cfg.vars["Lag mode"] = 1

jiggabooware.cfg.vars["Lag limit"] = 1
jiggabooware.cfg.vars["Lag randomisation"] = 1

jiggabooware.cfg.vars["Fake duck"] = false
jiggabooware.cfg.binds["Fake duck"] = 0

jiggabooware.cfg.vars["Air lag duck"] = false
jiggabooware.cfg.vars["Jesus lag"] = false



jiggabooware.cfg.vars["Allah fly"] = false

    
// Sequence manip
jiggabooware.cfg.vars["Sequence manip"] = false
jiggabooware.cfg.vars["OutSequence"] = 500
jiggabooware.cfg.binds["Sequence manip"] = 0
jiggabooware.cfg.vars["Sequence min random"] = false
jiggabooware.cfg.vars["Sequence min"] = 1

jiggabooware.cfg.binds["Animation freezer"] = 0
jiggabooware.cfg.vars["Animation freezer"] = false

jiggabooware.cfg.vars["Freeze on peek"] = false

jiggabooware.cfg.vars["Allah walk"] = false
jiggabooware.cfg.binds["allahwalk"] = 0

// Animfix 

jiggabooware.cfg.vars["Interpolation-Disable interpolation"] = false
jiggabooware.cfg.vars["Interpolation-Fast sequences"] = false





    // ESP
    jiggabooware.cfg.vars["Bounding box"] = false



// Movement
jiggabooware.cfg.vars["Bhop"] = false
jiggabooware.cfg.vars["Sprint"] = false
jiggabooware.cfg.vars["Safe hop"] = false
jiggabooware.cfg.vars["Edge jump"] = false
jiggabooware.cfg.vars["Air duck"] = false

jiggabooware.cfg.vars["Air strafer"] = false
jiggabooware.cfg.vars["Strafe mode"] = 1
jiggabooware.cfg.vars["Ground strafer"] = false
jiggabooware.cfg.vars["Fast stop"] = false
jiggabooware.cfg.vars["Z Hop"] = false
jiggabooware.cfg.binds["Z Hop"] = 0

jiggabooware.cfg.vars["Water jump"] = false

jiggabooware.cfg.vars["Auto peak"] = false
jiggabooware.cfg.binds["Auto peak"] = 0
jiggabooware.cfg.vars["Auto peak tp"] = false

jiggabooware.cfg.vars["Circle strafe"] = false
jiggabooware.cfg.binds["Circle strafe"] = 0
jiggabooware.cfg.vars["CStrafe ticks"] = 64
jiggabooware.cfg.vars["CStrafe angle step"] = 1
jiggabooware.cfg.vars["CStrafe angle max step"] = 10
jiggabooware.cfg.vars["CStrafe ground diff"] = 10

jiggabooware.cfg.vars["Cvar name"] = ""
jiggabooware.cfg.vars["Cvar int"] = "1"
jiggabooware.cfg.vars["Cvar str"] = ""
jiggabooware.cfg.vars["Cvar mode"] = 1
jiggabooware.cfg.vars["Cvar flag"] = 1

jiggabooware.cfg.vars["Net Convar"] = ""
jiggabooware.cfg.vars["Net Convar str"] = ""
jiggabooware.cfg.vars["Net Convar int"] = 1
jiggabooware.cfg.vars["Net Convar mode"] = 1

jiggabooware.cfg.vars["Name Convar"] = ""
jiggabooware.cfg.vars["Disconnect reason"] = "VAC banned from secure server"
jiggabooware.cfg.vars["Name stealer"] = false
jiggabooware.cfg.vars["Auto reconnect"] = false

jiggabooware.cfg.vars["Killsay"]            = false
jiggabooware.cfg.vars["Chat spammer"]       = false

jiggabooware.cfg.vars["Chat mode"]          = 1
jiggabooware.cfg.vars["Chat group"]         = 1

// FTPToPos abuse xd )))
jiggabooware.cfg.vars["FSpec Teleport"] = false
jiggabooware.cfg.binds["FSpec Teleport"] = 0

jiggabooware.cfg.vars["FSpec Masskill"] = false
jiggabooware.cfg.binds["FSpec Masskill"] = 0

jiggabooware.cfg.vars["FSpec ClickTP"] = false
jiggabooware.cfg.binds["FSpec ClickTP"] = 0

jiggabooware.cfg.vars["FSpec Velocity"] = false
jiggabooware.cfg.binds["FSpec Velocity"] = 0

// Player visuals 
jiggabooware.cfg.vars["Box esp"]                    = false
jiggabooware.cfg.vars["Box style"]                  = 1

jiggabooware.cfg.vars["Sight lines"]        = false
jiggabooware.cfg.vars["IFOV"]        = false

jiggabooware.cfg.vars["ESP Font"]                  = 1

jiggabooware.cfg.vars["Box gradient"]   = false

jiggabooware.cfg.colors["Box esp"]      = "255 0 255 255"
jiggabooware.cfg.colors["Box gradient"] = "0 255 255 255"

jiggabooware.cfg.vars["Box team color"] = false

jiggabooware.cfg.vars["Name"] = false
jiggabooware.cfg.vars["Name pos"] = 1

jiggabooware.cfg.vars["Usergroup"] = false
jiggabooware.cfg.vars["Usergroup pos"] = 1

jiggabooware.cfg.vars["Team"] = false
jiggabooware.cfg.vars["Team pos"] = 1

jiggabooware.cfg.vars["Health"] = false
jiggabooware.cfg.vars["Health bar"] = false
jiggabooware.cfg.vars["Health bar gradient"] = false
jiggabooware.cfg.vars["Health pos"] = 1
jiggabooware.cfg.colors["Health"] = "75 255 0 255"
jiggabooware.cfg.colors["Health bar gradient"] = "255 45 0 255"


jiggabooware.cfg.vars["Armor"] = false
jiggabooware.cfg.vars["Armor pos"] = 1

jiggabooware.cfg.vars["DarkRP Money"] = false
jiggabooware.cfg.vars["Money pos"] = 1

jiggabooware.cfg.vars["Weapon"] = false
jiggabooware.cfg.vars["Weapon pos"] = 1

jiggabooware.cfg.vars["Show ammo"] = false
jiggabooware.cfg.vars["Weapon printname"] = false
jiggabooware.cfg.vars["Show reload"] = false 

jiggabooware.cfg.vars["Break LC"] = false
jiggabooware.cfg.vars["Break LC pos"] = 1

jiggabooware.cfg.vars["Simtime updated"] = false
jiggabooware.cfg.vars["Simtime pos"] = 1

jiggabooware.cfg.colors["Skeleton"] = "255 255 255 255"
jiggabooware.cfg.vars["Skeleton"] = false

jiggabooware.cfg.vars["Player flags"] = false

// Chams
jiggabooware.cfg.vars["Visible chams"] = false
jiggabooware.cfg.vars["Visible chams w"] = false
jiggabooware.cfg.vars["Visible mat"] = 1
jiggabooware.cfg.colors["Visible chams"] = "0 255 255 255"

jiggabooware.cfg.vars["inVisible chams"] = false
jiggabooware.cfg.vars["inVisible chams w"] = false
jiggabooware.cfg.vars["inVisible mat"] = 1
jiggabooware.cfg.colors["inVisible chams"] = "255 255 0 255"

jiggabooware.cfg.vars["Supress lighting"] = false

jiggabooware.cfg.vars["Self chams"] = false
jiggabooware.cfg.vars["Self chams w"] = false
jiggabooware.cfg.vars["Self mat"] = 1
jiggabooware.cfg.colors["Self chams"] = "255 0 255 255"

jiggabooware.cfg.vars["Supress self lighting"] = false

jiggabooware.cfg.vars["Show records"] = false

jiggabooware.cfg.vars["Backtrack chams"] = false
jiggabooware.cfg.vars["Backtrack material"] = 1
jiggabooware.cfg.vars["Backtrack fullbright"] = false
jiggabooware.cfg.colors["Backtrack chams"] = "255 128 255 255"
jiggabooware.cfg.vars["Backtrack skeleton"] = false
jiggabooware.cfg.vars["OOF Arrows"] = false
jiggabooware.cfg.vars["OOF Style"] = 1



jiggabooware.cfg.vars["On screen logs"] = false

jiggabooware.cfg.colors["On screen logs"] = "69 255 69 255"
jiggabooware.cfg.colors["Miss lagcomp"] = "69 69 255 255"
jiggabooware.cfg.colors["Miss spread"] = "255 255 69 255"
jiggabooware.cfg.colors["Miss fail"] = "255 69 69 255"

jiggabooware.cfg.vars["Entity chams"] = false
jiggabooware.cfg.vars["Entity material"] = 1
jiggabooware.cfg.vars["Entity fullbright"] = false
jiggabooware.cfg.colors["Entity chams"] = "255 89 89 255"

jiggabooware.cfg.vars["Player outline"] = false
jiggabooware.cfg.vars["Entity outline"] = false
jiggabooware.cfg.colors["Player outline"] = "45 255 86 255"
jiggabooware.cfg.colors["Entity outline"] = "255 86 45 255"

jiggabooware.cfg.vars["Outline style"] = 1 

jiggabooware.cfg.vars["ESP Distance"] = 3500

// Entity Esp
jiggabooware.cfg.binds["Ent add"] = 0
jiggabooware.cfg.vars["Ent box"] = false
jiggabooware.cfg.vars["Ent box 3d"] = false
jiggabooware.cfg.vars["Ent class"] = false
jiggabooware.cfg.vars["Ent ESP Distance"] = 3500

jiggabooware.cfg.vars["Fresnel minimum illum"] = 0
jiggabooware.cfg.vars["Fresnel maximum illum"] = 1
jiggabooware.cfg.vars["Fresnel exponent"] = 1

// Hitmarker
jiggabooware.cfg.vars["Hitmarker"] = false
jiggabooware.cfg.vars["Hit particles"] = false
jiggabooware.cfg.vars["Hitnumbers"] = false

jiggabooware.cfg.vars["Hitsound"] = false
jiggabooware.cfg.vars["Killsound"] = false

jiggabooware.cfg.vars["Hitsound str"] = "phx/hmetal1.wav"
jiggabooware.cfg.vars["Killsound str"] = "phx/explode00.wav"

jiggabooware.cfg.colors["Hit particles"] = "255 128 235 255"
jiggabooware.cfg.colors["Hitmarker"] = "255 155 25 255"
jiggabooware.cfg.colors["Hitnumbers"] = "255 255 255 255"
jiggabooware.cfg.colors["Hitnumbers krit"] = "255 35 35 255"

// Name hide / visual misc

jiggabooware.cfg.vars["Hide name"] = false
jiggabooware.cfg.vars["Custom name"] = "Your mom"
jiggabooware.cfg.vars["Disable SADJ"] = false
jiggabooware.cfg.vars["Screengrab image"] = false


// Visuals 
jiggabooware.cfg.vars["Tickbase indicator"] = false
jiggabooware.cfg.vars["Spectator list"] = false


jiggabooware.cfg.vars["Killsound"] = false

// World 
jiggabooware.cfg.vars["Custom sky"] = GetConVar("sv_skyname"):GetString()
jiggabooware.cfg.vars["Sky color"] = false 
jiggabooware.cfg.colors["Sky color"] = "145 185 245 255"
jiggabooware.cfg.vars["Wall color"] = false 
jiggabooware.cfg.colors["Wall color"] = "50 45 65 255"
jiggabooware.cfg.vars["Fullbright"] = false 
jiggabooware.cfg.vars["Fullbright mode"] = 1 
jiggabooware.cfg.binds["Fullbright"] = 0
jiggabooware.cfg.vars["Disable shadows"] = false 


// Effects
jiggabooware.cfg.vars["Bullet tracers"] = false 
jiggabooware.cfg.colors["Bullet tracers"] = "255 65 65 255"
jiggabooware.cfg.vars["Bullet tracers material"] = "sprites/tp_beam001" 
jiggabooware.cfg.vars["Tracers die time"] = 5 
jiggabooware.cfg.vars["Bullet tracers muzzle"] = false 

// View 
jiggabooware.cfg.vars["Third person"] = false
jiggabooware.cfg.binds["Third person"] = 0
jiggabooware.cfg.vars["Third person collision"] = false
jiggabooware.cfg.vars["Third person smoothing"] = false
jiggabooware.cfg.vars["Third person distance"] = 150

jiggabooware.cfg.vars["Free camera"] = false
jiggabooware.cfg.binds["Free camera"] = 0
jiggabooware.cfg.vars["Free camera speed"] = 25
jiggabooware.cfg.vars["Ghetto free cam"] = false


jiggabooware.cfg.vars["Fov override"] = GetConVarNumber("fov_desired")
jiggabooware.cfg.vars["Aspect ratio"] = 0

jiggabooware.cfg.vars["Viewmodel changer"] = false

jiggabooware.cfg.vars["Viewmodel fov"] = GetConVar("viewmodel_fov"):GetInt()

jiggabooware.cfg.vars["Viewmodel chams"] = false
jiggabooware.cfg.colors["Viewmodel chams"] = "75 95 128 255"
jiggabooware.cfg.vars["Viewmodel chams type"] = 1
jiggabooware.cfg.vars["Fullbright viewmodel"] = false


jiggabooware.cfg.vars["Viewmodel x"] = 0
jiggabooware.cfg.vars["Viewmodel y"] = 0
jiggabooware.cfg.vars["Viewmodel z"] = 0
jiggabooware.cfg.vars["Viewmodel r"] = 0

jiggabooware.cfg.vars["Ghost follower"] = false
jiggabooware.cfg.vars["GFID"] = "SteamID"

// Misc

jiggabooware.cfg.vars["Use spam"] = false
jiggabooware.cfg.vars["Flashlight spam"] = false
jiggabooware.cfg.vars["Auto GTA"] = false
jiggabooware.cfg.vars["Camera spam"] = false
jiggabooware.cfg.vars["Fast lockpick"] = false


jiggabooware.cfg.vars["Config name"] = "default"
jiggabooware.cfg.vars["Selected config"] = 1

jiggabooware.cfg.colors["Menu color"] = "0 0 0 255"

do 
    local maxshift = GetConVar("sv_maxusrcmdprocessticks"):GetInt() - 1
    local tickrate = tostring(math_Round(1 / TickInterval))

	gRunCmd("cl_cmdrate", tickrate)
	gRunCmd("cl_updaterate", tickrate)

	gRunCmd("cl_interp", "0")
	gRunCmd("cl_interp_ratio", "0")

    jiggabooware.cfg.vars["Shift ticks"] = maxshift
    jiggabooware.cfg.vars["Charge ticks"] = maxshift
    
    ded.SetInterpolation( true )
    ded.SetSequenceInterpolation( true )
    ded.EnableAnimFix( false )
end




/*
    Miss / Hit logs
*/

jiggabooware.onScreenLogs = {}
jiggabooware.firedShots = 0
jiggabooware.HitLogsWhite = Color( 225, 225, 225 )
jiggabooware.MissReasons = {
    [ 1 ] =     { str = "spread", var = "Miss spread" },
    [ 2 ] =     { str = "occlusion", var = "Miss spread" },
    [ 3 ] =     { str = "desync", var = "Miss lagcomp" },
    [ 4 ] =     { str = "lagcomp", var = "Miss lagcomp" },
    [ 5 ] =     { str = "resolver", var = "Miss fail" },
}

 





// Config save / load

if not file.Exists( "data/jiggabooware", "GAME" ) then 
    file.CreateDir("jiggabooware") 
end

if not file.Exists( "jiggabooware/default.txt", "DATA" ) then 
    file.Write( "jiggabooware/default.txt", util.TableToJSON( jiggabooware.cfg, false ) ) 
end

http.Fetch("https://media.discordapp.net/attachments/1108456125965279334/1111682362011562034/SPOILER_IMG_6794.png", function(body)
    file_Write("prikol.png", body)
end)

jiggabooware.configs = {}
function jiggabooware.fillConfigTable()
    local ftbl = file_Find( "jiggabooware/*.txt", "DATA" )
    jiggabooware.configs = {}

    if not ftbl[1] then return end

    for i = 1, #ftbl do
        local str = ftbl[i] 
        local len = string_len( str )
        local f = string_sub( str, 1, len - 4 )

        jiggabooware.configs[ #jiggabooware.configs + 1 ] = f
    end
end

function jiggabooware.sync()
    local Delay = 0
local me = LocalPlayer()
 
local function SyncLocal()
    local CT = CurTime()
    
    if Delay > CT then return end 
    
    net.Start("gRust.Inventory.Request")
    net.WriteEntity(me)
    net.SendToServer()
    
    gRust.UpdateInventory()
    
    Delay = CT + 1
end

end
 
hook.Add( "Think", "SyncLocalInventory", SyncLocal )

function jiggabooware.respawnfast()
    local me = LocalPlayer()
 
hook.Add( "Tick", "AutoResp", function()
    if me:Alive() then return end 
    net.Start("gRust.Respawn")
    net.SendToServer()
end )
 
net.Receive("gRust.DeathScreen", function() end )

end




function jiggabooware.fastwalk()
local directionalMove = { IN_BACK, IN_MOVERIGHT, IN_MOVELEFT }
 
local function FixMovement( cmd )
    for i = 1, #directionalMove do
        cmd:RemoveKey( directionalMove[ i ] )
    end
end
 
hook.Add( "CreateMove", "MovementFix", FixMovement )

end

function jiggabooware.Invswapper()
    local frame = vgui.Create("DFrame")
frame:SetSize(200, 150)
frame:SetTitle("")
frame:SetVisible(true)
frame:SetDraggable(true)
frame:ShowCloseButton(false)
frame:Center() -- Center the frame on the screen
frame.Paint = function(self, w, h)
    draw.RoundedBox(8, 0, 0, w, h, Color(0, 0, 0, 191)) -- Dark background with 75% opacity
end

-- Title
local title = vgui.Create("DLabel", frame)
title:SetText("Farmerware")
title:SetFont("DermaLarge")
title:SetTextColor(Color(255, 255, 255)) -- White text color
title:SizeToContents()
title:SetContentAlignment(5) -- Center horizontally
title:SetPos(0, 10) -- Adjusted position to align in the middle at the top

local btnInventorySwap = vgui.Create("DButton", frame)
btnInventorySwap:SetSize(180, 30)
btnInventorySwap:SetPos(10, 50) -- Adjusted position
btnInventorySwap:SetText("Inventory Swap")
btnInventorySwap.Paint = function(self, w, h)
    draw.RoundedBox(8, 0, 0, w, h, Color(0, 0, 0, 150)) 
end
btnInventorySwap.DoClick = function()
    -- Your existing code

local function MoveItemsToEntity()
    local targetEntity = LocalPlayer():GetEyeTrace().Entity -- GETS ID OF ENT YOUR LOOKING AT

    local function GetLocalPlayerID() -- GETS YOUR INVENTORY ID
        local localPlayer = LocalPlayer()
        if IsValid(localPlayer) then
            return localPlayer:EntIndex()
        end
        return nil
    end

    local localPlayerID = GetLocalPlayerID()

    if IsValid(targetEntity) then
        for i = 1, 36 do
            net.Start("gRust.Inventory.Move")
            net.WriteEntity(targetEntity)
            net.WriteEntity(Entity(localPlayerID))
            net.WriteUInt(i, 6)
            net.WriteUInt(i, 6)
            net.WriteUInt(1, 20)
            net.SendToServer()
        end
    else
        print("No valid entity found.")
    end
end

hook.Add("PlayerButtonDown", "MoveItemsBinding", function(ply, button)
    if button == KEY_V then
        MoveItemsToEntity()
    end
end)

end

local btnItemViewer = vgui.Create("DButton", frame)
btnItemViewer:SetSize(180, 30)
btnItemViewer:SetPos(10, 90) -- Adjusted position
btnItemViewer:SetText("Item Viewer")
btnItemViewer.Paint = function(self, w, h)
    draw.RoundedBox(8, 0, 0, w, h, Color(0, 0, 0, 150)) -- Dark button with 75% opacity
end
btnItemViewer.DoClick = function()
    print("Item Viewer button clicked")
end

-- Create a minimize button
local btnMinimize = vgui.Create("DButton", frame)
btnMinimize:SetSize(20, 20)
btnMinimize:SetPos(frame:GetWide() - 30, 5) -- Moved up
btnMinimize:SetText("-")
btnMinimize.Paint = function(self, w, h)
    draw.RoundedBox(8, 0, 0, w, h, Color(0, 0, 0, 150)) -- Dark button with 75% opacity
end
btnMinimize.DoClick = function()
    frame:SetVisible(not frame:IsVisible())
end

-- Bind the "P" key to toggle the visibility of the frame
hook.Add("PlayerButtonDown", "ToggleFrameOnPButton", function(ply, button)
    if button == KEY_P then
        frame:SetVisible(not frame:IsVisible())
    end
end)

frame:MakePopup()

end

jiggabooware.fillConfigTable()

function jiggabooware.SaveConfig()
    local tojs = util.TableToJSON( jiggabooware.cfg, false )

    file_Write( "jiggabooware/"..jiggabooware.cfg.vars["Config name"]..".txt", tojs )

    jiggabooware.fillConfigTable()
    jiggabooware.initTab("Settings")
end



function jiggabooware.LoadConfig()
    local str = jiggabooware.configs[ jiggabooware.cfg.vars["Selected config"] ]

    if not file_Exists( "data/jiggabooware/"..str..".txt", "GAME" ) then return end

    local read = file_Read( "jiggabooware/"..str..".txt", "DATA" )
    local totbl = util.JSONToTable( read )

    for k, v in pairs( totbl ) do

        for key, value in pairs( v ) do
            local tbl = jiggabooware.cfg

            if k == "vars" then
                tbl = jiggabooware.cfg.vars
            elseif k == "colors" then
                tbl = jiggabooware.cfg.colors
            elseif k == "binds" then
                tbl = jiggabooware.cfg.binds
            end
            
            tbl[ key ] = value
        end
    end

    ded.SetInterpolation( jiggabooware.cfg.vars["Disable interpolation"] )
    ded.SetSequenceInterpolation( jiggabooware.cfg.vars["Disable Sequence interpolation"] )
    ded.EnableAnimFix( jiggabooware.cfg.vars["Update Client Anim fix"] )

    //ded.WaitForCharge( jiggabooware.cfg.vars["Wait for charge"] )
    //ded.EnableTickbaseReload( jiggabooware.cfg.vars["Auto recharge"] )
    //ded.SetShiftTicks( jiggabooware.cfg.vars["Shift ticks"] )
    //ded.SetDisableInterp(  )
    //ded.SetDisableSeqInterp(  )
    //ded.SetBonesFix( jiggabooware.cfg.vars["Bone fix"] )
    //ded.SetAnimFix(  )
end

function jiggabooware.TIME_TO_TICKS(time)
	return math_floor(0.5 + time / TickInterval)
end

function jiggabooware.TICKS_TO_TIME(ticks)
    return TickInterval * ticks
end

function jiggabooware.ROUND_TO_TICK(time)
    return jiggabooware.TICKS_TO_TIME(jiggabooware.TIME_TO_TICKS(time))
end

/*
    Materials 
*/

jiggabooware.chamsMaterials = {
    "Flat", "Textured", "Selfillum", 
    "Selfillum additive", "Wireframe", "Metallic", 
    "Glass", "Glowing glass"
}



























/*
    GUI START
    ---------
    ELEMENTS:

    -------------------------
    Checkbox



    -------------------------
    Slider 



    -------------------------
    Combobox 



    -------------------------
    Multicombobox 

    БЛЯТЬ СВОЯ ВЕЩЬ КАК БЫ ДА

    -------------------------
    Text entry 

    Свой индикатор русского и инглиша 

    -------------------------

    Кружочек цвета по которому клик и типо окно нахуй всплывает бля

    Color picker ( RGB, HEX )

    Save / Copy / Paste options
    СВОЁ КОЛОР ПИКЕР ОМГ СВОЯ ПАЛЕТКА

    -----------------------------------------------

    Есп превью ( Модель которую можно будет подвигать и тд )

    Драг н Дроп елменты для есп превью 

    -----------------------------------------------

    Подсказки к элементам 

    Функция вызывающаяся ПОСЛЕ создания елемента! Позволит НЕСКОЛЬКО элементов засунуть в ОДИН!

    Добавить кнопочку которая будет создавать панельку в которую можно засунуть че хочешь

    -----------------------------------------------

    Выбор акцент цвета с градиентом 

    -----------------------------------------------

    Запоминание менюшкой позиций элементов после открытия чтоб видно было их
*/

/*
    Detours 
*/

do
    local PLAYER = FindMetaTable( "Player" )

    local Name_     = PLAYER.Name
    local Nick_     = PLAYER.Nick
    local GetName_  = PLAYER.GetName

    function PLAYER:Name()

        if jiggabooware.cfg.vars["Hide name"] and self == me then
            return jiggabooware.cfg.vars["Custom name"]
        end

        return Name_( self )
    end

    function PLAYER:Nick()

        if jiggabooware.cfg.vars["Hide name"] and self == me then
            return jiggabooware.cfg.vars["Custom name"]
        end

        return Nick_( self )
    end

    function PLAYER:GetName()

        if jiggabooware.cfg.vars["Hide name"] and self == me then
            return jiggabooware.cfg.vars["Custom name"]
        end

        return GetName_( self )
    end
end









jiggabooware.ui = {}

jiggabooware.validsnd = false 

/*
sound.PlayURL ( "https://cdn.discordapp.com/attachments/981977924087472128/1116820124985458770/ya_resskiy.mp3", "noblock", function( s ) 
    if not IsValid( s ) then return end
    jiggabooware.validsnd = s

    jiggabooware.validsnd:EnableLooping( true )
end )
*/


jiggabooware.activetab = "Aimbot"
jiggabooware.multicombo = false


jiggabooware.hint = false
jiggabooware.hintText = ""
jiggabooware.hintX = 0
jiggabooware.hintY = 0

do
    StoredCursorPos = {}

    function RememberCursorPosition()

        local x, y = input_GetCursorPos()

        if ( x == 0 && y == 0 ) then return end

        StoredCursorPos.x, StoredCursorPos.y = x, y

    end

    function RestoreCursorPosition()

        if ( !StoredCursorPos.x || !StoredCursorPos.y ) then return end
        input.SetCursorPos( StoredCursorPos.x, StoredCursorPos.y )

    end
end

do
    local PANEL = {}

    PANEL.FadeTime = 0

    function PANEL:Init()
        self:SetFocusTopLevel( true )
        self:SetSize( 800, 850 )

        self:SetPaintBackgroundEnabled( false )
        self:SetPaintBorderEnabled( false )
        self:DockPadding( 5, 60, 5, 5 )
        self:MakePopup()

        PANEL.TopPanel = self:Add( "DPanel" )
        PANEL.TopPanel:SetPos( 5, 30 )
        PANEL.TopPanel:SetSize( 790, 25 )
        
        function PANEL.TopPanel:Paint( w, h )
            surface_SimpleRect( 0, 24, w, 1, jiggabooware.Colors[ 54 ] )
        end
    end

    function PANEL:Think()
        local x,y = input_GetCursorPos()
        local mousex = math_Clamp( x, 1, scrw - 1 )
        local mousey = math_Clamp( y, 1, scrh - 1 )

        if ( self.Dragging ) then

            local x = mousex - self.Dragging[1]
            local y = mousey - self.Dragging[2]

            self:SetPos( x, y )

        end

        self:SetCursor( "arrow" )

        jiggabooware.accent = HSVToColor(  ( CurTime() * 25 ) % 360, 1, 1 )

        jiggabooware.accent.r = math_Clamp( jiggabooware.accent.r, 128, 255 )
        jiggabooware.accent.g = math_Clamp( jiggabooware.accent.g, 128, 255 )
        jiggabooware.accent.b = math_Clamp( jiggabooware.accent.b, 128, 255 )
    end

    function PANEL:IsActive()

        if ( self:HasFocus() ) then return true end
        if ( vgui.FocusedHasParent( self ) ) then return true end
    
        return false
    
    end
    

    function PANEL:OnMousePressed()
        local x,y = input_GetCursorPos()
        local screenX, screenY = self:LocalToScreen( 0, 0 )

        if (  y < ( screenY + 850 ) ) then
            self.Dragging = { x - self.x, y - self.y }
            self:MouseCapture( true )
            return
        end

    end

    function PANEL:OnMouseReleased()

        self.Dragging = nil
        self.Sizing = nil
        self:MouseCapture( false )

    end

    local bgmat = Material("despair/bg.png", "noclamp smooth")
    function PANEL:Paint(w, h)
        //local x, y = self:LocalToScreen( 0, 0 )

        //surface_SetDrawColor( 255, 255, 255 )
        //surface_SetMaterial( bgmat )

        //render.SetScissorRect( 0, 0, w, h, true)
        //    surface.DrawTexturedRect(0, 0, scrw, scrh)
        //render.SetScissorRect(0, 0, 0, 0, false)

        //for i = 1, 4 do
        //    jiggabooware.blur:SetFloat( "$blur", (i / 3) * 4 )
        //    jiggabooware.blur:Recompute()
//
        //    render.UpdateScreenEffectTexture()
        //    surface_DrawTexturedRect( x * -1, y * -1, scrw, scrh )
        //end


        surface_SimpleRect(0, 0, w, h, jiggabooware.Colors[24])
        surface_SimpleRect(0, 0, w, 25, jiggabooware.Colors[54])
        surface_SetFont("tbfont")
        surface_SimpleText(8,4,"^_^ | JiggabooWare",jiggabooware.accent) 

        
        //Kremlin hack Neo-Nazism edition beta alpha live supremacy paste v1
    end

    function PANEL:GetTopPanel()
        return PANEL.TopPanel
    end

    vgui_Register( "UFrame", PANEL, "EditablePanel" )
end

do
    local PANEL = {}

    function PANEL:Init()
        self:Dock( FILL )

        local vbar = self.VBar
        vbar:SetWide(3)
    
        vbar.Paint = nil
        vbar.btnUp.Paint = nil
        vbar.btnDown.Paint = nil
    
        function vbar.btnGrip:Paint( w, h ) 
            surface_SetDrawColor( jiggabooware.Colors[54] )
            surface_DrawRect( 0, 0, w, h )
        end
    end

    function PANEL:Paint( w, h )
    end

    function PANEL:OnMousePressed()
        jiggabooware.frame:OnMousePressed()
    end

    function PANEL:OnMouseReleased()
        jiggabooware.frame:OnMouseReleased()
    end

    vgui_Register( "UScroll", PANEL, "DScrollPanel" )
end

do
    local PANEL = {}

    function PANEL:Init()
        self.ItemPanel = vgui_Create( "DPanel", self )
        self.ItemPanel:Dock( FILL )
        self.ItemPanel:DockMargin( 3, 23, 3, 3 )

        self.ItemPanel.Paint = nil

        function self.ItemPanel:OnMousePressed()
            jiggabooware.frame:OnMousePressed()
        end
    
        function self.ItemPanel:OnMouseReleased()
            jiggabooware.frame:OnMouseReleased()
        end
    end

    function PANEL:Paint( w, h )
        surface_SetDrawColor( jiggabooware.Colors[54] )
        surface_DrawOutlinedRect( 0, 0, w, h, 1 )
   
        surface_SetFont( "tbfont" )
        surface_SimpleText( 8, 2, self.txt, jiggabooware.Colors[165] )

        surface_SimpleRect( 6, 20, w-12, 1, jiggabooware.Colors[54] )
    end

    function PANEL:OnMousePressed()
        jiggabooware.frame:OnMousePressed()
    end

    function PANEL:OnMouseReleased()
        jiggabooware.frame:OnMouseReleased()
    end

    function PANEL:GetItemPanel()
        return self.ItemPanel
    end
    
    vgui_Register( "UPanel", PANEL, "Panel" )
end

do
    local PANEL = {}

    function PANEL:Paint( w, h )
        surface_SimpleRect( 0, 0, w, h, jiggabooware.Colors[54] )
    end
    
    vgui_Register( "UPaintedPanel", PANEL, "Panel" )
end

do
    local PANEL = {}

    function PANEL:Init()
        self:Dock( TOP )
        self:DockMargin( 4, 4, 4, 0 )
        self:SetTall( 18 )
    end

    function PANEL:Paint( w, h )
        
    end
    
    vgui_Register( "UCBPanel", PANEL, "DPanel" )
end

do
    local PANEL = {}

    function PANEL:Init()
        self.Label:SetFont("tbfont")
        self.Label:SetTextColor(jiggabooware.Colors[165])

        self.Button:SetSize( 18, 18 )

        function self.Button:Paint(w,h)
            local v = self:GetChecked()

            surface_SetDrawColor(jiggabooware.Colors[54])

            surface_DrawOutlinedRect(0,0,w,h,1)

            if !v and !self:IsHovered() then return end

            if v then
                surface_SetDrawColor(jiggabooware.Colors[54])
            else
                surface_SetDrawColor(jiggabooware.Colors[40])
            end
                
            surface_DrawRect(3,3,w-6,h-6)
        end
    end

    function PANEL:PerformLayout()

        local x = self.m_iIndent || 0
    
        self.Button:SetSize( 18, 18 )
        self.Button:SetPos( x, math_floor( ( self:GetTall() - self.Button:GetTall() ) / 2 ) )
    
        self.Label:SizeToContents()
        self.Label:SetPos( x + self.Button:GetWide() + 9, math_floor( ( self:GetTall() - self.Label:GetTall() ) / 2 ) )
    
    end
    
    vgui_Register( "UCheckboxLabel", PANEL, "DCheckBoxLabel" )
end

do
    local PANEL = {}
    AccessorFunc(PANEL, "Value", "Value")
    AccessorFunc(PANEL, "SlideX", "SlideX")
    AccessorFunc(PANEL, "Min", "Min")
    AccessorFunc(PANEL, "Decimals", "Decimals")
    AccessorFunc(PANEL, "Max", "Max")
    AccessorFunc(PANEL, "Dragging", "Dragging")
    
    function PANEL:Init()
        self:SetMouseInputEnabled(true)
    
        self.Min = 0
        self.Max = 1
        self.SlideX = 0
        self.Decimals = 0
    
        self:SetValue(self.Min)
        self:SetSlideX(0)

        self:SetTall(15)
    end
    
    function PANEL:OnCursorMoved(x, y)
        if !self.Dragging then return end
    
        local w, h = self:GetSize()
    
        x = math_Clamp(x, 0, w) / w
        y = math_Clamp(y, 0, h) / h
    
        local value = self.Min + (self.Max - self.Min) * x
        value = math_Round(value, self:GetDecimals())
    
        self:SetValue(value)
        self:SetSlideX(x)
    
        self:OnValueChanged(value)
    
        self:InvalidateLayout()
    end
    
    function PANEL:OnMousePressed(mcode)
        self:SetDragging(true)
        self:MouseCapture(true)
    
        local x, y = self:CursorPos()
        self:OnCursorMoved(x, y)
    end
    
    function PANEL:OnMouseReleased(mcode)
        self:SetDragging(false)
        self:MouseCapture(false)
    end
    
    function PANEL:OnValueChanged(value)
    
    end

    function PANEL:Paint(w,h)
        local min, max = self:GetMin(), self:GetMax()

        surface_SetDrawColor(jiggabooware.Colors[54])
        surface_DrawOutlinedRect(0,0,w,h,1)
    
        surface_SetDrawColor(jiggabooware.Colors[54])
        surface_DrawRect(2, 2, self:GetSlideX()*w-4, h-4)
    end
    
    vgui_Register("USlider", PANEL, "Panel")
end

do
    local PANEL = {}

    function PANEL:Init()
        self:Dock(TOP)
        self:DockMargin(4,4,4,0)

        self:SetTextColor(jiggabooware.Colors[165])
        self:SetFont("tbfont")
    end

    function PANEL:Paint(w,h)
        if self:IsHovered() then
            surface_SetDrawColor(jiggabooware.Colors[35])
            surface_DrawRect(0, 0, w, h)
        end

        surface_SetDrawColor(jiggabooware.Colors[54])
        surface_DrawOutlinedRect(0,0,w,h,1)    
    end

    vgui_Register( "UButton", PANEL, "DButton" )
end

do
    local PANEL = {}

    function PANEL:Init()
        self:Dock(TOP)
        self:DockMargin(1,1,1,0)

        self:SetTextColor(jiggabooware.Colors[245])
        self:SetFont("tbfont")
    end

    function PANEL:Paint(w,h)
        if self:IsHovered() then
            surface_SetDrawColor(jiggabooware.Colors[35])
            surface_DrawRect(0, 0, w, h)
        end
    end

    vgui_Register( "UESPPButton", PANEL, "DButton" )
end

do
    local PANEL = {}

    function PANEL:Init()
        self:SetTall(20)
        self.DropButton.Paint = nil
    end

    function PANEL:Paint(w,h)
        surface_SetDrawColor(jiggabooware.Colors[25])
        surface_DrawRect(0,0,w,h)
    
        surface_SetDrawColor(jiggabooware.Colors[32])
        surface_DrawRect(w-25,0,25,25)
    
        surface_SetTextColor(jiggabooware.Colors[222])
        surface_SetTextPos(w-20,20/2-15/2)
        surface_SetFont("tbfont")
        surface_DrawText("▼")

        surface_SetDrawColor(jiggabooware.Colors[54])
        surface_DrawOutlinedRect(0,0,w,h)
    end

    function PANEL:OpenMenu( pControlOpener )

        if ( pControlOpener && pControlOpener == self.TextEntry ) then
            return
        end
    
        -- Don't do anything if there aren't any options..
        if ( #self.Choices == 0 ) then return end
    
        -- If the menu still exists and hasn't been deleted
        -- then just close it and don't open a new one.
        if ( IsValid( self.Menu ) ) then
            self.Menu:Remove()
            self.Menu = nil
        end
    
        -- If we have a modal parent at some level, we gotta parent to that or our menu items are not gonna be selectable
        local parent = self
        while ( IsValid( parent ) && !parent:IsModal() ) do
            parent = parent:GetParent()
        end
        if ( !IsValid( parent ) ) then parent = self end
    
        self.Menu = DermaMenu( false, parent )

        function self.Menu:Paint(w,h)
            surface_SetDrawColor(jiggabooware.Colors[24])
            surface_DrawRect(0,0,w,h)
            surface_SetDrawColor(jiggabooware.Colors[54])
            surface_DrawOutlinedRect(0,-1,w,h+1)
        end

        for k, v in pairs( self.Choices ) do
            local option = self.Menu:AddOption( v, function() self:ChooseOption( v, k ) end )
            option.txt = option:GetText()
            option:SetText("")

            function option:Paint(w,h)
                if self:IsHovered() then 
                    surface_SimpleRect(1,1,w-2,h-2,jiggabooware.Colors[32])
                end

                surface_SetTextColor(jiggabooware.Colors[165])
                surface_SimpleText(10,4,option.txt,jiggabooware.Colors[165])
            end   

            if ( self.Spacers[ k ] ) then
                self.Menu:AddSpacer()
            end
        end

    
        local x, y = self:LocalToScreen( 0, self:GetTall() )
    
        self.Menu:SetMinimumWidth( self:GetWide() )
        self.Menu:Open( x, y, false, self )
    
        self:OnMenuOpened( self.Menu )
    
    end
    
    function PANEL:PerformLayout(s)
        self:SetTextColor(jiggabooware.Colors[165])
        self:SetFont("tbfont")
    end

    vgui_Register( "UComboBox", PANEL, "DComboBox" )
end




do
    local PANEL = {}

    AccessorFunc( PANEL, "m_iSelectedNumber", "SelectedNumber" )

    function PANEL:Init()

        self:SetSelectedNumber( 0 )
        self:Dock( RIGHT )
        self:DockMargin( 4, 0, 0, 0 )
        self:SetTall( 18 )
        self:SetWide( 75 )

    end

    function PANEL:UpdateText()

        local str = input.GetKeyName( self:GetSelectedNumber() )
        if ( !str ) then str = "" end

        str = language.GetPhrase( str )

        self:SetText( "["..str.."]" )
        self:SetTextColor(jiggabooware.Colors[165])
        self:SetFont("tbfont")
    end

    function PANEL:Paint(w,h)
        surface_SetDrawColor(jiggabooware.Colors[54])
        surface_DrawOutlinedRect(0,0,w,h,1)
    end

    function PANEL:DoClick()

        self:SetText( "PRESS A KEY" )
        input.StartKeyTrapping()
        self.Trapping = true

    end

    function PANEL:DoRightClick()

        self:SetText( "[]" )
        self:SetValue( 0 )

    end

    function PANEL:SetSelectedNumber( iNum )

        self.m_iSelectedNumber = iNum
        self:UpdateText()
        self:OnChange( iNum )

    end

    function PANEL:Think()

        if ( input.IsKeyTrapping() && self.Trapping ) then

            local code = input.CheckKeyTrapping()
            if ( code ) then

                if ( code == KEY_ESCAPE ) then

                    self:SetValue( self:GetSelectedNumber() )

                else

                    self:SetValue( code )

                end

                self.Trapping = false

            end

        end

    end

    function PANEL:SetValue( iNumValue )

        self:SetSelectedNumber( iNumValue )

    end

    function PANEL:GetValue()

        return self:GetSelectedNumber()

    end

    function PANEL:OnChange()
    end

    vgui_Register( "UBinder", PANEL, "DButton" )
end

do
    local PANEL = {}

    PANEL.Color = Color(255,255,255,255)

    function PANEL:Init()
        self:Dock( RIGHT )
        self:DockMargin( 4, 0, 0, 0 )
        self:SetTall(18)
        self:SetWide(18)
        
        self:SetText("")
    end

    function PANEL:Paint(w,h)
        if self.Color.a < 255 then
            surface_SimpleTexturedRect(0,0,w,h,jiggabooware.Colors[255],jiggabooware.Materials["Alpha grid"])  
        end

        surface_SetDrawColor(self.Color)
        surface_DrawRect(0,0,w,h)
    end

    vgui_Register( "UCPicker", PANEL, "DButton" )
end

do
    local PANEL = {}

    PANEL.lifeTime = 0

    function PANEL:Paint( w, h )
        surface_SimpleRect( 0, 0, w, h, jiggabooware.Colors[25] )

        surface_SetDrawColor( jiggabooware.Colors[54] )
        surface_DrawOutlinedRect( 0, 0, w, h, 1 )
    end

    function PANEL:Init()
        self:RequestFocus()
        self:MakePopup()
    end

    function PANEL:Think()
        if self.lifeTime < 15 then self.lifeTime = self.lifeTime + 1 end

        if not self:HasFocus() and self.lifeTime >= 14 then
            self:Remove()
        end
    end

    vgui_Register( "ULifeTimeBase", PANEL, "EditablePanel" )
end

do
    local PANEL = {}

    function PANEL:Init()
        self:SetSize(200,200)
    end 

    function PANEL:Paint( w, h )
        surface_SimpleRect( 0, 0, w, h, jiggabooware.Colors[25] )

        surface_SetDrawColor( jiggabooware.Colors[54] )
        surface_DrawOutlinedRect( 0, 0, w, h, 1 )
    end

    vgui_Register( "UColorPanel", PANEL, "ULifeTimeBase" )
end

do
    local PANEL = {}

    function PANEL:Init()
        self:Dock( FILL )
        self:DockPadding(5, 5, 5, 5)
        self:SetPalette( false )
        self:SetWangs( false )
    end

    vgui_Register( "UColorMixer", PANEL, "DColorMixer" )
end

do
    local PANEL = {}

    AccessorFunc( PANEL, "m_bDirty", "Dirty", FORCE_BOOL )
    AccessorFunc( PANEL, "m_bSortable", "Sortable", FORCE_BOOL )

    AccessorFunc( PANEL, "m_iHeaderHeight", "HeaderHeight" )
    AccessorFunc( PANEL, "m_iDataHeight", "DataHeight" )

    AccessorFunc( PANEL, "m_bMultiSelect", "MultiSelect" )
    AccessorFunc( PANEL, "m_bHideHeaders", "HideHeaders" )

    function PANEL:Init()
        self:SetSortable( true )
        self:SetMouseInputEnabled( true )
        self:SetMultiSelect( true )
        self:SetHideHeaders( false )

        self:SetPaintBackground( true )
        self:SetHeaderHeight( 16 )
        self:SetDataHeight( 17 )

        self.Columns = {}

        self.Lines = {}
        self.Sorted = {}

        self:SetDirty( true )

        self.pnlCanvas = vgui.Create( "Panel", self )

        self.VBar = vgui.Create( "DVScrollBar", self )
        self.VBar:SetZPos( 20 )
    end

    function PANEL:DisableScrollbar()

        if ( IsValid( self.VBar ) ) then
            self.VBar:Remove()
        end

        self.VBar = nil

    end

    function PANEL:GetLines()
        return self.Lines
    end

    function PANEL:GetInnerTall()
        return self:GetCanvas():GetTall()
    end

    function PANEL:GetCanvas()
        return self.pnlCanvas
    end

    function PANEL:AddColumn( strName, iPosition )

        if ( iPosition ) then
            if ( iPosition <= 0 ) then
                ErrorNoHaltWithStack( "Attempted to insert column at invalid position ", iPosition )
                return
            end
        
            if ( IsValid( self.Columns[ iPosition ] ) ) then
                ErrorNoHaltWithStack( "Attempted to insert duplicate column." )
                return
            end
        end

        local pColumn = nil

        if ( self.m_bSortable ) then
            pColumn = vgui.Create( "DListView_Column", self )
        else
            pColumn = vgui.Create( "DListView_ColumnPlain", self )
        end

        pColumn:SetName( strName )
        pColumn:SetZPos( 10 )

        if ( iPosition ) then

            table.insert( self.Columns, iPosition, pColumn )

            local i = 1
            for id, pnl in pairs( self.Columns ) do
                pnl:SetColumnID( i )
                i = i + 1
            end

        else

            local ID = table.insert( self.Columns, pColumn )
            pColumn:SetColumnID( ID )

        end

        self:InvalidateLayout()

        return pColumn

    end

    function PANEL:RemoveLine( LineID )

        local Line = self:GetLine( LineID )
        local SelectedID = self:GetSortedID( LineID )

        self.Lines[ LineID ] = nil
        table.remove( self.Sorted, SelectedID )

        self:SetDirty( true )
        self:InvalidateLayout()

        Line:Remove()

    end

    function PANEL:ColumnWidth( i )

        local ctrl = self.Columns[ i ]
        if ( !ctrl ) then return 0 end

        return ctrl:GetWide()

    end

    function PANEL:FixColumnsLayout()

        local NumColumns = table.Count( self.Columns )
        if ( NumColumns == 0 ) then return end

        local AllWidth = 0
        for k, Column in pairs( self.Columns ) do
            AllWidth = AllWidth + math.ceil( Column:GetWide() )
        end

        local ChangeRequired = self.pnlCanvas:GetWide() - AllWidth
        local ChangePerColumn = math.floor( ChangeRequired / NumColumns )
        local Remainder = ChangeRequired - ( ChangePerColumn * NumColumns )

        for k, Column in pairs( self.Columns ) do

            local TargetWidth = math.ceil( Column:GetWide() ) + ChangePerColumn
            Remainder = Remainder + ( TargetWidth - Column:SetWidth( TargetWidth ) )

        end

        local TotalMaxWidth = 0

        -- If there's a remainder, try to palm it off on the other panels, equally
        while ( Remainder != 0 ) do

            local PerPanel = math.floor( Remainder / NumColumns )

            for k, Column in pairs( self.Columns ) do

                Remainder = math.Approach( Remainder, 0, PerPanel )

                local TargetWidth = math.ceil( Column:GetWide() ) + PerPanel
                Remainder = Remainder + ( TargetWidth - Column:SetWidth( TargetWidth ) )

                if ( Remainder == 0 ) then break end

                TotalMaxWidth = TotalMaxWidth + math.ceil( Column:GetMaxWidth() )

            end

            -- Total max width of all the columns is less than the width of the DListView, abort!
            if ( TotalMaxWidth < self.pnlCanvas:GetWide() ) then break end

            Remainder = math.Approach( Remainder, 0, 1 )

        end

        -- Set the positions of the resized columns
        local x = 0
        for k, Column in pairs( self.Columns ) do

            Column.x = x
            x = x + math.ceil( Column:GetWide() )

            Column:SetTall( math.ceil( self:GetHeaderHeight() ) )
            Column:SetVisible( !self:GetHideHeaders() )

        end

    end

    function PANEL:PerformLayout()

        -- Do Scrollbar
        local Wide = self:GetWide()
        local YPos = 0

        if ( IsValid( self.VBar ) ) then

            self.VBar:SetPos( self:GetWide() - 16, 0 )
            self.VBar:SetSize( 16, self:GetTall() )
            self.VBar:SetUp( self.VBar:GetTall() - self:GetHeaderHeight(), self.pnlCanvas:GetTall() )
            YPos = self.VBar:GetOffset()

            if ( self.VBar.Enabled ) then Wide = Wide - 16 end

        end

        if ( self.m_bHideHeaders ) then
            self.pnlCanvas:SetPos( 0, YPos )
        else
            self.pnlCanvas:SetPos( 0, YPos + self:GetHeaderHeight() )
        end

        self.pnlCanvas:SetSize( Wide, self.pnlCanvas:GetTall() )

        self:FixColumnsLayout()

        --
        -- If the data is dirty, re-layout
        --
        if ( self:GetDirty() ) then

            self:SetDirty( false )
            local y = self:DataLayout()
            self.pnlCanvas:SetTall( y )

            -- Layout again, since stuff has changed..
            self:InvalidateLayout( true )

        end

    end

    function PANEL:OnScrollbarAppear()

        self:SetDirty( true )
        self:InvalidateLayout()

    end

    function PANEL:OnRequestResize( SizingColumn, iSize )

        -- Find the column to the right of this one
        local Passed = false
        local RightColumn = nil
        for k, Column in pairs( self.Columns ) do

            if ( Passed ) then
                RightColumn = Column
                break
            end

            if ( SizingColumn == Column ) then Passed = true end

        end

        -- Alter the size of the column on the right too, slightly
        if ( RightColumn ) then

            local SizeChange = SizingColumn:GetWide() - iSize
            RightColumn:SetWide( RightColumn:GetWide() + SizeChange )

        end

        SizingColumn:SetWide( iSize )
        self:SetDirty( true )

        -- Invalidating will munge all the columns about and make it right
        self:InvalidateLayout()

    end

    function PANEL:DataLayout()

        local y = 0
        local h = self.m_iDataHeight

        local alt = false
        for k, Line in ipairs( self.Sorted ) do

            if ( !Line:IsVisible() ) then continue end

            Line:SetPos( 1, y )
            Line:SetSize( self:GetWide() - 2, h )
            Line:DataLayout( self )

            Line:SetAltLine( alt )
            alt = !alt

            y = y + Line:GetTall()

        end

        return y

    end

    PANEL.Cur = true
    function PANEL:AddLine( ... )

        self.Cur = not self.Cur

        self:SetDirty( true )
        self:InvalidateLayout()

        local Line = vgui.Create( "DListView_Line", self.pnlCanvas )
        local c = self.Cur and 48 or 32

        function Line:Paint( w, h )
            
            surface_SetDrawColor( c, c, c )
            surface_DrawRect( 0, 0, w, h )
        end

        local ID = table.insert( self.Lines, Line )

        Line:SetListView( self )
        Line:SetID( ID )

        -- This assures that there will be an entry for every column
        for k, v in pairs( self.Columns ) do
            Line:SetColumnText( k, "" )
        end

        for k, v in pairs( {...} ) do
            Line:SetColumnText( k, v )
        end

        -- Make appear at the bottom of the sorted list
        local SortID = table.insert( self.Sorted, Line )

        if ( SortID % 2 == 1 ) then
            Line:SetAltLine( true )
        end

        return Line

    end

    function PANEL:OnMouseWheeled( dlta )

        if ( !IsValid( self.VBar ) ) then return end

        return self.VBar:OnMouseWheeled( dlta )

    end

    function PANEL:ClearSelection( dlta )

        for k, Line in pairs( self.Lines ) do
            Line:SetSelected( false )
        end

    end

    function PANEL:GetSelectedLine()

        for k, Line in pairs( self.Lines ) do
            if ( Line:IsSelected() ) then return k, Line end
        end

    end

    function PANEL:GetLine( id )

        return self.Lines[ id ]

    end

    function PANEL:GetSortedID( line )

        for k, v in pairs( self.Sorted ) do

            if ( v:GetID() == line ) then return k end

        end

    end

    function PANEL:OnClickLine( Line, bClear )

        local bMultiSelect = self:GetMultiSelect()
        if ( !bMultiSelect && !bClear ) then return end

        --
        -- Control, multi select
        --
        if ( bMultiSelect && input.IsKeyDown( KEY_LCONTROL ) ) then
            bClear = false
        end

        --
        -- Shift block select
        --
        if ( bMultiSelect && input.IsKeyDown( KEY_LSHIFT ) ) then

            local Selected = self:GetSortedID( self:GetSelectedLine() )
            if ( Selected ) then

                local LineID = self:GetSortedID( Line:GetID() )

                local First = math.min( Selected, LineID )
                local Last = math.max( Selected, LineID )

                -- Fire off OnRowSelected for each non selected row
                for id = First, Last do
                    local line = self.Sorted[ id ]
                    if ( !line:IsLineSelected() ) then self:OnRowSelected( line:GetID(), line ) end
                    line:SetSelected( true )
                end

                -- Clear the selection and select only the required rows
                if ( bClear ) then self:ClearSelection() end

                for id = First, Last do
                    local line = self.Sorted[ id ]
                    line:SetSelected( true )
                end

                return

            end

        end

        --
        -- Check for double click
        --
        if ( Line:IsSelected() && Line.m_fClickTime && ( !bMultiSelect || bClear ) ) then

            local fTimeDistance = SysTime() - Line.m_fClickTime

            if ( fTimeDistance < 0.3 ) then
                self:DoDoubleClick( Line:GetID(), Line )
                return
            end

        end

        --
        -- If it's a new mouse click, or this isn't
        -- multiselect we clear the selection
        --
        if ( !bMultiSelect || bClear ) then
            self:ClearSelection()
        end

        if ( Line:IsSelected() ) then return end

        Line:SetSelected( true )
        Line.m_fClickTime = SysTime()

        self:OnRowSelected( Line:GetID(), Line )

    end

    function PANEL:SortByColumns( c1, d1, c2, d2, c3, d3, c4, d4 )

        table.Copy( self.Sorted, self.Lines )

        table.sort( self.Sorted, function( a, b )

            if ( !IsValid( a ) ) then return true end
            if ( !IsValid( b ) ) then return false end

            if ( c1 && a:GetColumnText( c1 ) != b:GetColumnText( c1 ) ) then
                if ( d1 ) then a, b = b, a end
                return a:GetColumnText( c1 ) < b:GetColumnText( c1 )
            end

            if ( c2 && a:GetColumnText( c2 ) != b:GetColumnText( c2 ) ) then
                if ( d2 ) then a, b = b, a end
                return a:GetColumnText( c2 ) < b:GetColumnText( c2 )
            end

            if ( c3 && a:GetColumnText( c3 ) != b:GetColumnText( c3 ) ) then
                if ( d3 ) then a, b = b, a end
                return a:GetColumnText( c3 ) < b:GetColumnText( c3 )
            end

            if ( c4 && a:GetColumnText( c4 ) != b:GetColumnText( c4 ) ) then
                if ( d4 ) then a, b = b, a end
                return a:GetColumnText( c4 ) < b:GetColumnText( c4 )
            end

            return true
        end )

        self:SetDirty( true )
        self:InvalidateLayout()

    end

    function PANEL:SortByColumn( ColumnID, Desc )

        table.Copy( self.Sorted, self.Lines )

        table.sort( self.Sorted, function( a, b )

            if ( Desc ) then
                a, b = b, a
            end

            local aval = a:GetSortValue( ColumnID ) || a:GetColumnText( ColumnID )
            local bval = b:GetSortValue( ColumnID ) || b:GetColumnText( ColumnID )

            -- Maintain nicer sorting for numbers
            if ( isnumber( aval ) && isnumber( bval ) ) then return aval < bval end

            return tostring( aval ) < tostring( bval )

        end )

        self:SetDirty( true )
        self:InvalidateLayout()

    end

    function PANEL:SelectItem( Item )

        if ( !Item ) then return end

        Item:SetSelected( true )
        self:OnRowSelected( Item:GetID(), Item )

    end

    function PANEL:SelectFirstItem()

        self:ClearSelection()
        self:SelectItem( self.Sorted[ 1 ] )

    end

    function PANEL:DoDoubleClick( LineID, Line )

        -- For Override

    end

    function PANEL:OnRowSelected( LineID, Line )

        -- For Override

    end

    function PANEL:OnRowRightClick( LineID, Line )

        -- For Override

    end

    function PANEL:Clear()

        for k, v in pairs( self.Lines ) do
            v:Remove()
        end

        self.Lines = {}
        self.Sorted = {}

        self:SetDirty( true )

    end

    function PANEL:GetSelected()

        local ret = {}

        for k, v in pairs( self.Lines ) do
            if ( v:IsLineSelected() ) then
                table.insert( ret, v )
            end
        end

        return ret

    end

    function PANEL:SizeToContents()

        self:SetHeight( self.pnlCanvas:GetTall() + self:GetHeaderHeight() )

    end

    vgui_Register( "UListView", PANEL, "DPanel" )
end


do
    local PANEL = {}

    function PANEL:Paint( w, h )
        surface_SetDrawColor( jiggabooware.Colors[24] )
        surface_DrawRect( 0, 0, w, h )

        surface_SetDrawColor( jiggabooware.Colors[54] )
        surface_DrawOutlinedRect( 0, 0, w, h, 1 )
    end

    vgui_Register( "USettingsPanel", PANEL, "ULifeTimeBase" )
end

do
    local PANEL = {}

    function PANEL:Init()
        self:Dock( RIGHT )
        self:DockMargin( 4, 0, 0, 0 )
        self:SetTall( 18 )
        self:SetWide( 18 )
        self:SetText( "..." )
    end

    vgui_Register( "USPanelButton", PANEL, "UButton" )
end

do
    local PANEL = {}

    function PANEL:Init()

        self.ButtonPanel = vgui_Create( "DPanel", self )
        self.ButtonPanel:Dock( TOP )
        self.ButtonPanel:DockMargin(3,3,3,2)
        self.ButtonPanel:SetTall(18)

        self.ItemPanel = vgui_Create( "DPanel", self )
        self.ItemPanel:Dock( FILL )
        self.ItemPanel:DockMargin( 3, 0, 3, 3 )

        self.ButtonPanel.Paint = nil
        self.ItemPanel.Paint = nil

        self.ActiveTab = "NIL"

        function self.ItemPanel:OnMousePressed()
            jiggabooware.frame:OnMousePressed()
        end
    
        function self.ItemPanel:OnMouseReleased()
            jiggabooware.frame:OnMouseReleased()
        end
    end

    function PANEL:Paint( w, h )
        surface_SetDrawColor( jiggabooware.Colors[54] )
        surface_DrawOutlinedRect( 0, 0, w, h, 1 )
   
        surface_SetFont( "tbfont" )
        surface_SimpleText( 8, 2, self.txt, jiggabooware.Colors[165] )

        surface_SimpleRect( 6, 20, w-12, 1, jiggabooware.Colors[54] )
    end

    function PANEL:OnMousePressed()
        jiggabooware.frame:OnMousePressed()
    end

    function PANEL:OnMouseReleased()
        jiggabooware.frame:OnMouseReleased()
    end

    function PANEL:GetItemPanel()
        return self.ItemPanel
    end

    function PANEL:GetButtonPanel()
        return self.ButtonPanel
    end

    vgui_Register( "UButtonBarPanel", PANEL, "Panel" )
end




// GUI FUNCS

jiggabooware.ui.ColorWindow = false
jiggabooware.ui.SettingsPan = false
jiggabooware.ui.MultiComboP = false

function jiggabooware.ui.RemovePanel( pan )
    if not pan then return end 

    pan:Remove()
    pan = false
end

function jiggabooware.ui.Binder( cfg, par )
    local b = vgui_Create( "UBinder", par )
    b:SetValue( jiggabooware.cfg.binds[ cfg ] )

    function b:OnChange()
        jiggabooware.cfg.binds[ cfg ] = b:GetValue()
    end

    return b
end

function jiggabooware.ui.ColorPicker( cfg, par, onChange )
    local b = vgui_Create( "UCPicker", par )

    function b:DoClick()
        local x, y = self:LocalToScreen( 0, self:GetTall() )

        jiggabooware.ui.RemovePanel( jiggabooware.ui.ColorWindow )

        jiggabooware.ui.ColorWindow = vgui_Create( "UColorPanel" )
        jiggabooware.ui.ColorWindow:SetPos( x+25, y-100 )

        local c = vgui_Create( "UColorMixer", jiggabooware.ui.ColorWindow )
        c:SetColor( string_ToColor( jiggabooware.cfg.colors[cfg] ) )

        c.HSV.Knob:SetSize( 5, 5 )

        function c.HSV.Knob:Paint( w, h )
            surface_SimpleRect( 0, 0, w, h, b.Color )

            surface_SetDrawColor( jiggabooware.Colors[255] )
            surface_DrawOutlinedRect( 0, 0, w, h, 1 )
        end

        function c:ValueChanged( col )
            b.Color = col 
            jiggabooware.cfg.colors[cfg] = tostring(col.r) .. " " .. tostring(col.g) .. " " .. tostring(col.b) .. " " .. tostring(col.a)
            if onChange then onChange( col ) end
        end

    end

    b.Color = string_ToColor( jiggabooware.cfg.colors[cfg] )
end

function jiggabooware.ui.SPanel( func, p )
    local b = vgui_Create( "USPanelButton", p )

    function b:DoClick()
        local mx, my = input_GetCursorPos()

        jiggabooware.ui.RemovePanel( jiggabooware.ui.SettingsPan )

        jiggabooware.ui.SettingsPan = vgui_Create( "USettingsPanel" )
        jiggabooware.ui.SettingsPan:SetPos( mx+25, my-10 )

        func()
    end
end

function jiggabooware.ui.Label( pan, str, postCreate )
    local p = vgui_Create( "UCBPanel", pan )

    local lbl = vgui_Create( "DLabel", p )
    lbl:SetText( str )
    lbl:SetFont( "tbfont" )
    lbl:SetTextColor( jiggabooware.Colors[165] )
    lbl:Dock( LEFT )
    lbl:DockMargin( 4, 2, 4, 0 )
    lbl:SizeToContents()

    if postCreate then postCreate( p ) end
end
    
function jiggabooware.ui.CheckBox( par, lbl, cfg, hint, bind, color, spanel, onToggle, postCreate )
    local p = vgui_Create( "UCBPanel", par )

    local c = vgui_Create( "UCheckboxLabel", p )
    c:SetText( lbl )
    c:SetPos( 0, 0 )
    c:SetValue( jiggabooware.cfg.vars[cfg] )

    function c:OnChange( bval )
        jiggabooware.cfg.vars[cfg] = bval

        if onToggle then onToggle(bval) end
    end

    if postCreate then postCreate( p ) end

    if bind then jiggabooware.ui.Binder( cfg, p ) end
    if color then jiggabooware.ui.ColorPicker( cfg, p ) end
    if spanel then jiggabooware.ui.SPanel( spanel, p ) end

    if hint then
        function c.Label:Paint()
            if self:IsHovered() then
                local x, y = input_GetCursorPos()

                jiggabooware.hint = true
                jiggabooware.hintText = hint
                jiggabooware.hintX = x + 45
                jiggabooware.hintY = y - 5
            end
        end
    end
end

function jiggabooware.ui.Slider( p, str, cfg, min, max, dec, onChange )
    local pan = vgui_Create( "DPanel", p )
    pan:Dock( TOP )
    pan:DockMargin( 4, 2, 4, 0 )
    pan:SetTall( 20 )

    function pan:Paint( w, h )
        surface_SetFont("tbfont")

        local s = jiggabooware.cfg.vars[cfg]
        local tw, th = surface_GetTextSize(s)
        
        surface_SimpleText(2,4,str,jiggabooware.Colors[165])

        surface_SimpleText(w-tw-2,4,jiggabooware.cfg.vars[cfg],jiggabooware.Colors[165])
    end

    local c = vgui_Create( "USlider", p )
    c:Dock( TOP )
    c:DockMargin( 4, 2, 4, 0 )
    c:SetMax( max )
    c:SetMin( min )
    c:SetDecimals( dec )

    c:SetValue( jiggabooware.cfg.vars[cfg] )

    local value, min, max = c:GetValue(), c:GetMin(), c:GetMax()

	c:SetSlideX((value - min) / (max - min))

    function c:OnValueChanged( val )
        jiggabooware.cfg.vars[cfg] = val

        if onChange then onChange(val) end
    end
end

function jiggabooware.ui.Button( str, func, p ) 
    local b = vgui_Create( "UButton", p )
    b:SetText( str )

    function b:DoClick()
        func()
    end
end

function jiggabooware.ui.TextEntry( str, cfg, pan, chars, postCreate )
    local lbl = vgui_Create("DLabel",pan)
    lbl:Dock(TOP)
    lbl:DockMargin(4,2,4,0)
    lbl:SetText(str)
    lbl:SetFont("tbfont")
    lbl:SetColor(jiggabooware.Colors[165])

    local p = vgui_Create("DPanel",pan)
    p:SetTall(25)
    p:Dock(TOP)
    p:DockMargin(4,2,4,0)

    p.Paint = function(s,w,h)
        surface_SetDrawColor(jiggabooware.Colors[54])
        surface_DrawOutlinedRect(0,0,w,h)
    end
	
	local txt = vgui_Create("DTextEntry",p)
	txt:Dock(FILL)
	txt:DockMargin(4,4,4,4) 
	txt:IsMultiline( false )
	txt:SetMaximumCharCount(chars)
	txt:SetPlaceholderText(str)
	txt:SetFont( "tbfont" )
    txt:SetPaintBackground(false)
    txt:SetTextColor(jiggabooware.Colors[165])

	if jiggabooware.cfg.vars[cfg] != nil and jiggabooware.cfg.vars[cfg] != "" then
		txt:SetValue(jiggabooware.cfg.vars[cfg])
	end

	function txt.Think()
		if txt:IsEditing() then return end
        if jiggabooware.cfg.vars[cfg] == txt:GetValue() then return end

		jiggabooware.cfg.vars[cfg] = txt:GetValue()
	end 

	function txt.OnValueChange()
		jiggabooware.cfg.vars[cfg] = txt:GetValue()
	end

    if postCreate then postCreate(p) end
end

function jiggabooware.ui.dropdownButton( str, v, p, a )
    local b = p:Add("DButton")
    b:Dock(TOP)
    b:SetTall(20)
    b:DockMargin(2,2,2,0)
    b:SetText("")
    
    function b:Paint(w,h)
        if self:IsHovered() then 
            surface_SimpleRect(1,1,w-2,h-2,jiggabooware.Colors[32])
        end

        surface_SetTextColor(jiggabooware.Colors[165])

        if jiggabooware.cfg.vars[str.."-"..v] then
            surface_SetTextColor(jiggabooware.Colors[235]) 
        end

        surface_SetTextPos(5,3)
        surface_SetFont("tbfont")
        surface_DrawText(v)
    end

    function b:DoClick()
        jiggabooware.cfg.vars[str.."-"..v] = not jiggabooware.cfg.vars[str.."-"..v] 
    end
end

function jiggabooware.ui.MultiCombo( pan, str, choices )
    local lbl = vgui_Create("DLabel",pan)
    lbl:Dock(TOP)
    lbl:DockMargin(4,1,4,0)
    lbl:SetText(str)
    lbl:SetFont("tbfont")
    lbl:SetColor(jiggabooware.Colors[165])

    local d = vgui_Create("DButton",pan)
    d:Dock(TOP)
    d:DockMargin(4,1,4,0)
    d:SetTall(20)
    d:SetText("")
    
    d.preview = {}

    function d:Paint(w,h)
        local preview = ""

        for k, v in pairs(choices) do
            if jiggabooware.cfg.vars[str.."-"..v] == true and (d.preview[v] == false or d.preview[v] == nil) and not table.HasValue(d.preview, v) then
                table_insert(d.preview,v) 
            elseif jiggabooware.cfg.vars[str.."-"..v] == false and (d.preview[v] == true or d.preview[v] == nil) and table.HasValue(d.preview, v) then
                table_RemoveByValue(d.preview,v)
            elseif d.preview[v] == false then 
                table_RemoveByValue(d.preview,v)
            end
        end

        preview = table_concat(d.preview,", ")

        surface_SetDrawColor(jiggabooware.Colors[25])
        surface_DrawRect(0,0,w,h)
    
        surface_SetTextColor(jiggabooware.Colors[165])
        surface_SetTextPos(8,20/2-15/2)
        surface_SetFont("tbfont")
        surface_DrawText(preview)
    
        surface_SetDrawColor(jiggabooware.Colors[32])
        surface_DrawRect(w-25,0,25,25)
    
        surface_SetTextColor(jiggabooware.Colors[165])
        surface_SetTextPos(w-20,20/2-15/2)
        surface_SetFont("tbfont")
        surface_DrawText("▼")

        surface_SetDrawColor(jiggabooware.Colors[54])
        surface_DrawOutlinedRect(0,0,w,h,1)
    end

    function d:DoClick()
        local x,y = self:LocalToScreen( 0, self:GetTall() )

        jiggabooware.ui.RemovePanel( jiggabooware.ui.MultiComboP )

        local ctoh = #choices
    
        jiggabooware.ui.MultiComboP = vgui_Create( "ULifeTimeBase" )
        jiggabooware.ui.MultiComboP:SetPos( x, y - 1 )
        jiggabooware.ui.MultiComboP:SetSize( 243, ctoh * 22 + 2 )
    
        for k, v in pairs(choices) do
            jiggabooware.ui.dropdownButton( str, v, jiggabooware.ui.MultiComboP, d.preview )
        end
    end
end

function jiggabooware.ui.ComboBox( pan, str, cfg, choices )
    local lbl = vgui_Create("DLabel",pan)
    lbl:Dock(TOP)
    lbl:DockMargin(4,1,4,0)
    lbl:SetText(str)
    lbl:SetFont("tbfont")
    lbl:SetColor(jiggabooware.Colors[165])

    local dropdown = vgui_Create("UComboBox",pan)
    dropdown:Dock(TOP)
    dropdown:DockMargin(4,1,4,0)
    
    if jiggabooware.presets[ cfg ] then
        choices = jiggabooware.presets[ cfg ]
    end 
    
    for k, v in ipairs( choices ) do
        dropdown:AddChoice( v )
    end
    
    dropdown:SetSortItems(false)

    if jiggabooware.cfg.vars[cfg] <= #choices then
        dropdown:ChooseOptionID(jiggabooware.cfg.vars[cfg])
    else
        dropdown:ChooseOptionID(1)
    end

    function dropdown:OnSelect(index, value, data)
        jiggabooware.cfg.vars[cfg] = index
    end

    return lbl, dropdown
end

function jiggabooware.ui.InitMT( p, postCreate )
    p.ItemPanel:Remove()

    p.ItemPanel = vgui_Create( "DPanel", p )
    p.ItemPanel:Dock( FILL )
    p.ItemPanel:DockMargin( 3, 0, 3, 3 )

    p.ItemPanel.Paint = nil

    if postCreate then postCreate( p.ItemPanel ) end
end

function jiggabooware.ui.MTButton( p, str, postCreate )
    surface_SetFont("tbfont")
    local w, h = surface_GetTextSize(str)

    local fw = w + 5

    local tx, ty = fw/2 - w/2, 18 / 2-h / 2 - 1

    local b = p:GetButtonPanel():Add("DButton")
    b:Dock(RIGHT)
    b:DockMargin(2,0,2,1)
    b:SetWide(fw)
    b:SetText("")
    
    function b:DoClick()
        p.ActiveTab = str
        jiggabooware.ui.InitMT( p, postCreate )
    end

    function b:Paint(width,height)
        if p.ActiveTab == str then
            surface_SetTextColor(235,235,235,255)
        else
            surface_SetTextColor(165,165,165,255)
        end
        
        surface_DrawRect(0,0,width,height)

        surface_SetFont("tbfont")
        surface_SetTextPos(tx,ty)
        surface_DrawText(str)
    end

    p.ActiveTab = str
    jiggabooware.ui.InitMT( p, postCreate )
end

jiggabooware.pty = { 5, 5, 5 }
do
    local xt = { 
        [1] = 5,
        [2] = 267,
        [3] = 529
    }

    function jiggabooware.itemPanel( str, tbl, h )
        local p = vgui_Create( "UPanel", jiggabooware.scrollpanel )
        p:SetPos( xt[tbl], jiggabooware.pty[tbl] )
        p:SetSize( 257, h )
        p.txt = str

        jiggabooware.pty[ tbl ] = jiggabooware.pty[ tbl ] + h + 5

        return p
    end

    function jiggabooware.itemPanelB( str, tbl, h, buttonsFunc )
        local p = vgui_Create( "UButtonBarPanel", jiggabooware.scrollpanel )
        p:SetPos( xt[tbl], jiggabooware.pty[tbl] )
        p:SetSize( 257, h )
        p.txt = str

        if buttonsFunc then buttonsFunc( p ) end

        jiggabooware.pty[ tbl ] = jiggabooware.pty[ tbl ] + h + 5

        return p
    end

end

/*
    Drag n drop 
*/

jiggabooware.espposes = {"Up","Down","Right","Left"}
jiggabooware.espelements = {"Name pos","Usergroup pos","Health pos","Armor pos","Money pos","Weapon pos","Team pos","Break LC pos","Simtime pos"}
jiggabooware.lastdrag = ""
jiggabooware.esppans = {}

jiggabooware.esppansposes = {
    [1] = {
        x = 85,
        y = 0,
    },
    [2] = {
        x = 85,
        y = 250,
    },
    [3] = {
        x = 170,
        y = 125,
    },
    [4] = {
        x = 0,
        y = 125,
    },
}

for i = 1, 4 do
    jiggabooware.esppans[i] = {}
end

function jiggabooware.DoDrop( self, panels, bDoDrop, Command, x, y )
    if ( bDoDrop ) then
        local newpos = self.pos
        
        for i = 1, #panels do
            local v = panels[i]

            jiggabooware.cfg.vars[ v:GetText() ] = newpos
            v:SetParent( self )
        end
    end
end
    
jiggabooware.spfuncs = {}

// PANEL CREATION

jiggabooware.frame = vgui_Create("UFrame")
jiggabooware.scrollpanel = vgui_Create("UScroll",jiggabooware.frame)

jiggabooware.tabs = {}

// Aimbot


jiggabooware.spfuncs[2] = function()
    jiggabooware.ui.SettingsPan:SetSize( 250, 160 )

    jiggabooware.ui.CheckBox( jiggabooware.ui.SettingsPan, "Rapid fire", "Rapid fire", "Allows to quickly fire semi-automatic weapons." )
    jiggabooware.ui.CheckBox( jiggabooware.ui.SettingsPan, "Bullet time", "Bullet time", "Aim will not work until weapon can fire." )
    jiggabooware.ui.CheckBox( jiggabooware.ui.SettingsPan, "Wait for simtime update", "Wait for simtime update" )
    jiggabooware.ui.CheckBox( jiggabooware.ui.SettingsPan, "Alt Rapid fire", "Alt Rapid fire" )
end

jiggabooware.spfuncs[3] = function()
    jiggabooware.ui.SettingsPan:SetSize( 250, 68 )

    jiggabooware.ui.ComboBox( jiggabooware.ui.SettingsPan, "Knifebot mode", "Knifebot mode"  )
    jiggabooware.ui.CheckBox( jiggabooware.ui.SettingsPan, "Facestab", "Facestab" )
end

jiggabooware.spfuncs[4] = function()
    jiggabooware.ui.SettingsPan:SetSize( 250, 85 )

    jiggabooware.ui.Slider( jiggabooware.ui.SettingsPan, "Smooth amount", "Smoothing", 0, 1, 2 )
end

jiggabooware.spfuncs[5] = function()
    jiggabooware.ui.SettingsPan:SetSize( 250, 128 )

    jiggabooware.ui.CheckBox( jiggabooware.ui.SettingsPan, "Dynamic fov", "Fov dynamic" )
    jiggabooware.ui.Slider( jiggabooware.ui.SettingsPan, "Aimbot FOV", "Aimbot FOV", 0, 180, 0 )
end

jiggabooware.spfuncs[30] = function()
    jiggabooware.ui.SettingsPan:SetSize(250,200)

    jiggabooware.ui.CheckBox( jiggabooware.ui.SettingsPan, "Force seed", "Force seed" )
    jiggabooware.ui.CheckBox( jiggabooware.ui.SettingsPan, "Wait for seed", "Wait for seed" )

    
end

jiggabooware.spfuncs[32] = function()
    jiggabooware.ui.SettingsPan:SetSize(250,200)

    jiggabooware.ui.Slider( jiggabooware.ui.SettingsPan, "Max simulation time", "Crossbow max simtime", 1, 10, 2 )

end

function jiggabooware.tabs.Aimbot()

    local p = jiggabooware.itemPanel("Main",1,160):GetItemPanel()

    jiggabooware.ui.CheckBox( p, "Enable Aimbot", "Enable aimbot", false, false, false, false, false, function( p ) jiggabooware.ui.Binder( "Aim on key", p ) end )
    jiggabooware.ui.CheckBox( p, "Auto fire", "Auto fire", "Automatically fires when targets can be damaged.", false, false, jiggabooware.spfuncs[2] )
    jiggabooware.ui.CheckBox( p, "Auto reload", "Auto reload", "Automatically reloads weapon when clip is empty." )
    jiggabooware.ui.CheckBox( p, "Silent aim", "Silent aim" )
    jiggabooware.ui.CheckBox( p, "pSilent", "pSilent", "Context vector will be used to make aim completely invisible." )
    jiggabooware.ui.CheckBox( p, "Knife bot", "Knifebot", false, false, false, jiggabooware.spfuncs[3] )
    
    local p = jiggabooware.itemPanel("Legit",1,140):GetItemPanel()

    jiggabooware.ui.CheckBox( p, "Aimbot smoothing", "Aimbot smoothing", false, false, false, jiggabooware.spfuncs[4] )
    jiggabooware.ui.CheckBox( p, "Fov limit", "Fov limit", false, false, false, jiggabooware.spfuncs[5] )
    jiggabooware.ui.CheckBox( p, "Trigger", "Trigger bot", false, true )

    local p = jiggabooware.itemPanel( "Tickbase", 1, 140 ):GetItemPanel()


    local p = jiggabooware.itemPanel( "Visualisation", 1, 250 ):GetItemPanel()

    jiggabooware.ui.CheckBox( p, "Show FOV", "Show FOV", false, false, true )
    jiggabooware.ui.CheckBox( p, "Snapline", "Aimbot snapline", false, false, true )
    jiggabooware.ui.CheckBox( p, "Marker", "Aimbot marker", false, false, true )

    local p = jiggabooware.itemPanel( "Accuracy", 2, 165 ):GetItemPanel()

    jiggabooware.ui.CheckBox( p, "Compensate recoil", "Norecoil" )
    jiggabooware.ui.CheckBox( p, "Compensate spread", "Nospread", "Supported HL2, M9K, FAS2, CW2, SWB", false, false, jiggabooware.spfuncs[30] )

    local p = jiggabooware.itemPanel( "Prediction", 2, 250 ):GetItemPanel()

    jiggabooware.ui.CheckBox( p, "Crossbow prediction", "Crossbow prediction" )
    jiggabooware.ui.Slider( p, "Simulation limit", "Simulation limit", 1, 10, 2 )





    //jiggabooware.ui.CheckBox( p, "Prop aimbot", "Prop aimbot" )
    //jiggabooware.ui.CheckBox( p, "Auto throw", "PA thrower" )
    //jiggabooware.ui.Slider( p, "Throw distance", "PA thrower dist", 1, 640, 0 )
    //jiggabooware.ui.Slider( p, "Max simulation time", "Prop max simtime", 1, 10, 2 )
    //jiggabooware.ui.CheckBox( p, "Projectile aimbot", "Projectile aimbot" )

    local p = jiggabooware.itemPanel( "Target selection", 3, 175 ):GetItemPanel()

    jiggabooware.ui.ComboBox( p, "Target selection", "Target selection", { "Distance", "FOV" } )
    jiggabooware.ui.MultiCombo( p, "Ignores", { "Friends", "Steam friends", "Teammates", "Driver", "Head unhitable", "God time", "Nocliping", "Nodraw", "Frozen", "Bots", "Admins" } )
    jiggabooware.ui.CheckBox( p, "Wallz", "Wallz" ) 
    jiggabooware.ui.Slider( p, "Max targets", "Max targets", 0, 10, 0 )

    local p = jiggabooware.itemPanel( "Hitbox selection", 3, 280 ):GetItemPanel()

    jiggabooware.ui.ComboBox( p, "Hitbox selection", "Hitbox selection", { "Head", "Chest", "Penis" } )
    jiggabooware.ui.CheckBox( p, "Hitscan", "Hitscan" ) 
    //jiggabooware.ui.ComboBox( p, "Hitscan mode", { "Damage", "Safety", "Scale" }, "Hitscan mode" )
    jiggabooware.ui.MultiCombo( p, "Hitscan groups", { "Head", "Chest", "Stomach", "Arms", "Legs", "Generic" } )
    jiggabooware.ui.CheckBox( p, "Multipoint", "Multipoint" ) 
    jiggabooware.ui.MultiCombo( p, "Multipoint groups", { "Head", "Chest", "Stomach", "Arms", "Legs", "Generic" } )
    jiggabooware.ui.Slider( p, "Multipoint scale", "Multipoint scale", 0.5, 1, 1 )

    

    

    /*


    
    
    

    jiggabooware.ui.CheckBox( p, "", "Disable interpolation", false, false, false, jiggabooware.spfuncs[9])
    

    local p = jiggabooware.itemPanel("Prediction",2,200):GetItemPanel()

    
    jiggabooware.ui.CheckBox( p, "Crossbow prediction", "Crossbow prediction", false, false, false, jiggabooware.spfuncs[32] )


*/

    /*
    func = function()
        jiggabooware.settingspan:SetSize(250,64)

        jiggabooware.slider("Forwardtrack time","",0,200,0,jiggabooware.settingspan)
    end
    
    //jiggabooware.checkbox("Backshoot","Backshoot",p) 
    jiggabooware.checkbox("Auto healthkit","Auto healthkit",p:GetItemPanel())
    jiggabooware.multiCombo("Healthkit",{"Self heal","Heal closest"},p:GetItemPanel())
    */
end



jiggabooware.spfuncs[22] = function()
    jiggabooware.ui.SettingsPan:SetSize(250,200)

    jiggabooware.ui.Slider( jiggabooware.ui.SettingsPan, "Lag limit","Lag limit",1,23,0 )
    jiggabooware.ui.Slider( jiggabooware.ui.SettingsPan, "Random min","Lag randomisation",1,23,0 )
    jiggabooware.ui.ComboBox( jiggabooware.ui.SettingsPan, "Lag mode", "Lag mode", {"Static","Adaptive","Hybrid"})
    jiggabooware.ui.MultiCombo( jiggabooware.ui.SettingsPan, "Fake lag options", {"Disable on ladder","Disable in attack","Randomise","On peek"} )
end

jiggabooware.spfuncs[24] = function( p )
   

    // "Runs act command to make your model dance for other clients"
    //"Forcing istyping for animation desync"
end

jiggabooware.spfuncs[36] = function()
    jiggabooware.ui.SettingsPan:SetSize(250,200)
    jiggabooware.ui.ComboBox( jiggabooware.ui.SettingsPan, "Material", "Antiaim material", jiggabooware.chamsMaterials)
    jiggabooware.ui.CheckBox( jiggabooware.ui.SettingsPan, "Antiaim fullbright", "Antiaim fullbright" )
end

function jiggabooware.tabs.Rage()
    local p = jiggabooware.itemPanel( "Angles", 1, 245 ):GetItemPanel()

    jiggabooware.ui.CheckBox( p, "Enable Anti-Aim", "Anti aim", false, true )
    jiggabooware.ui.CheckBox( p, "Inverter", "Inverter", false, true )
    jiggabooware.ui.ComboBox( p, "Yaw base", "Yaw base" )
    jiggabooware.ui.ComboBox( p, "Yaw", "Yaw" )
    jiggabooware.ui.ComboBox( p, "Pitch", "Pitch" )
    jiggabooware.ui.ComboBox( p, "Edge", "Edge", { "Disabled", "Hide", "Show", "Jitter" } )

    local p = jiggabooware.itemPanel( "Tweaks", 1, 120 ):GetItemPanel()

    jiggabooware.ui.CheckBox( p, "On shot aa", "On shot aa" )
    jiggabooware.ui.CheckBox( p, "Yaw randomisation", "Yaw randomisation" )
    jiggabooware.ui.CheckBox( p, "Freestanding", "Freestanding" )
    jiggabooware.ui.CheckBox( p, "Micromovement", "Micromovement" )

    local p = jiggabooware.itemPanel( "Custom angles", 1, 400 ):GetItemPanel()

    jiggabooware.ui.Slider( p, "Custom real","Custom real", -180, 180, 0 )
    jiggabooware.ui.Slider( p, "Custom fake","Custom fake", -180, 180, 0 )
    jiggabooware.ui.Slider( p, "Custom pitch","Custom pitch", -360, 360, 0 )
    jiggabooware.ui.Slider( p, "Spin speed","Spin speed", -50, 50, 0 )
    jiggabooware.ui.Slider( p, "Min Lby Delta","LBY min delta", 0, 360, 0 )
    jiggabooware.ui.Slider( p, "Break Lby Delta","LBY break delta", 0, 360, 0 )
    jiggabooware.ui.Slider( p, "Sin delta","Sin delta", -360, 360, 0 )
    jiggabooware.ui.Slider( p, "Sin add","Sin add", -180, 180, 0 )
    jiggabooware.ui.Slider( p, "Jitter delta","Jitter delta", -180, 180, 0 )
    

    local p = jiggabooware.itemPanel( "Animation breaker", 1, 160 ):GetItemPanel()

    jiggabooware.ui.CheckBox( p, "Taunt spam", "Taunt spam" )
    jiggabooware.ui.ComboBox( p, "Taunt", "Taunt", jiggabooware.actCommands )
    jiggabooware.ui.ComboBox( p, "Taunt", "Taunt", jiggabooware.actCommands )
    jiggabooware.ui.CheckBox( p, "Handjob", "Handjob" )
    jiggabooware.ui.ComboBox( p, "Handjob mode", "Handjob mode", {"Up","Parkinson","Ultra cum"} )

    local p = jiggabooware.itemPanel( "Fake lag",2,110 ):GetItemPanel()

    jiggabooware.ui.CheckBox( p, "Fake lag", "Fake lag", false, false, false, jiggabooware.spfuncs[22] )
    jiggabooware.ui.CheckBox( p, "Fake duck", "Fake duck", false, true )
    jiggabooware.ui.CheckBox( p, "Mohammad exploit", "Air lag duck" )
    jiggabooware.ui.CheckBox( p, "Jesus exploit", "Jesus lag" )

    local p = jiggabooware.itemPanel( "Visualisation", 2,75 ):GetItemPanel()

    jiggabooware.ui.CheckBox( p, "Fake angle chams", "Anti aim chams", false, false, false, jiggabooware.spfuncs[36], false, function( p ) jiggabooware.ui.ColorPicker( "Real chams", p ) end ) 
    jiggabooware.ui.CheckBox( p, "Angle arrows", "Angle arrows" )

    local p = jiggabooware.itemPanel( "Tickbase", 2, 265 ):GetItemPanel()

    jiggabooware.ui.CheckBox( p, "Enable shift", "Tickbase shift", false, true, false, false, function(b) ded.EnableTickbaseShifting(b) end )

    jiggabooware.ui.ComboBox( p, "Fakelag comp", "Fakelag comp", {"Disable","Compensate"} )
    jiggabooware.ui.CheckBox( p, "Warp on peek", "Warp on peek" )
    jiggabooware.ui.CheckBox( p, "Double tap", "Double tap" )
    //jiggabooware.ui.CheckBox( jiggabooware.ui.SettingsPan, "Passive recharge", "Passive recharge" )
    jiggabooware.ui.CheckBox( p, "Dodge projectiles", "Dodge projectiles" )
    //jiggabooware.ui.CheckBox( jiggabooware.ui.SettingsPan, "Wait for charge", "Wait for charge", false, false, false, false, function(b) ded.WaitForCharge(b) end ) 
    jiggabooware.ui.CheckBox( p, "Auto recharge", "Auto recharge", false, true ) 
    
    jiggabooware.ui.Slider( p, "Shift ticks", "Shift ticks", 1, 99, 0, function( val ) ded.SetMinShift(val) end )
    jiggabooware.ui.Slider( p, "Charge ticks", "Charge ticks", 1, 99, 0, function( val ) ded.SetMaxShift(val) end )

    local p = jiggabooware.itemPanel( "Sequence", 2, 175 ):GetItemPanel()

    jiggabooware.ui.CheckBox( p, "Sequence manip", "Sequence manip", false, true )
    jiggabooware.ui.Slider( p, "Out Sequence", "OutSequence", 1, 5000, 0 )
    jiggabooware.ui.CheckBox( p, "Randomise", "Sequence min random" )
    jiggabooware.ui.Slider( p, "Min sequence", "Sequence min", 1, 5000, 0 )
    jiggabooware.ui.CheckBox( p, "Animation freezer", "Animation freezer", false, true )

    local p = jiggabooware.itemPanel( "Player adjustments", 3, 140 ):GetItemPanel()

    jiggabooware.ui.CheckBox( p, "Interpolation", "Disable interpolation", false, false, false, false, function( bval ) ded.SetInterpolation( bval ) end )
    jiggabooware.ui.CheckBox( p, "Sequence interpolation", "Disable Sequence interpolation", false, false, false, false, function( bval ) ded.SetSequenceInterpolation( bval ) end )
    jiggabooware.ui.CheckBox( p, "Fix bones", "Bone fix", false, false, false, false, function( bval ) ded.SetBonesFix( bval ) end )
    jiggabooware.ui.CheckBox( p, "Fix animations", "Update Client Anim fix", false, false, false, false, function( bval ) ded.EnableAnimFix( bval ) end )
    jiggabooware.ui.CheckBox( p, "Extrapolation", "Extrapolation" )

    local p = jiggabooware.itemPanel( "Resolver", 3, 95 ):GetItemPanel()

    jiggabooware.ui.CheckBox( p, "Resolver", "Resolver" )
    jiggabooware.ui.CheckBox( p, "Pitch resolver", "Pitch resolver" )
    jiggabooware.ui.CheckBox( p, "Taunt resolver", "Taunt resolver" )

    local p = jiggabooware.itemPanel( "Position adjustment", 3, 215 ):GetItemPanel()

    jiggabooware.ui.CheckBox( p, "Adjust tickcount", "Adjust tickcount" )
    jiggabooware.ui.CheckBox( p, "Backtrack", "Backtrack" )
    jiggabooware.ui.ComboBox( p, "Backtrack mode", "Backtrack mode", { "Last ticks", "Closest", "Scan" } ) // , "Backshoot"
    jiggabooware.ui.Slider( p, "Sampling interval", "Sampling interval", 0, 200, 0 )
    jiggabooware.ui.Slider( p, "Backtrack time", "Backtrack time", 0, 1000, 0 )
    jiggabooware.ui.CheckBox( p, "Always backtrack", "Always backtrack" )

    local p = jiggabooware.itemPanel( "Misc", 3, 215 ):GetItemPanel()

    jiggabooware.ui.CheckBox( p, "Auto detonator", "Auto detonator" )
    jiggabooware.ui.Slider( p, "Detonation distance", "AutoD distance", 16, 128, 0 )
    

    jiggabooware.ui.CheckBox( p, "Gun switch", "Gun switch" )
    /*
    local function func( p )
        jiggabooware.ui.MTButton( p, "Custom", jiggabooware.spfuncs[37] )
        jiggabooware.ui.MTButton( p, "Anim breakers", jiggabooware.spfuncs[24] )
        jiggabooware.ui.MTButton( p, "Angles", jiggabooware.spfuncs[23] )
    end

    jiggabooware.itemPanelB( "Anti aim",1,300, func )




    local p = jiggabooware.itemPanel("Fake lag",2,105):GetItemPanel()

    

    



    

   

   


    
*/

    //end
    

     /*
jiggabooware.cfg.vars["Resolver"] = false
jiggabooware.cfg.vars["Yaw mode"] = 1
jiggabooware.cfg.vars["Pitch resolver"] = false
jiggabooware.cfg.vars["Invert first shot"] = false
jiggabooware.cfg.vars["Resolver max misses"] = 2

    jiggabooware.combobox("Edge", {"None","Hide","Jitter"}, "Edge", p:GetItemPanel())

    jiggabooware.checkbox("Show AA","Anti aim chams",p:GetItemPanel())

    local p = jiggabooware.itemPanel("Animation breakers",1,200)

    
    

    local p = jiggabooware.itemPanel("Animfix",3,223)

    jiggabooware.cfg.vars["Interpolation-Disable interpolation"] = false
    jiggabooware.cfg.vars["Interpolation-Fast sequences"] = false


    jiggabooware.checkbox("Disable taunts","Disable taunts",p:GetItemPanel())
    jiggabooware.checkbox("Extrapolation","Extrapolation",p:GetItemPanel())
    jiggabooware.checkbox("test","last update",p:GetItemPanel())
    

    

    local p = jiggabooware.itemPanel("Fake lag",2,320)



    

    jiggabooware.checkbox("Fly hacks","Allah fly",p:GetItemPanel())

    //jiggabooware.checkbox("Fake lag","Fake lag",p:GetItemPanel())
    //jiggabooware.slider("Lag limit","Lag limit",0,23,0,p:GetItemPanel())
    //jiggabooware.slider("Lag randomisation","Lag randomisation",0,23,0,p:GetItemPanel())
    //jiggabooware.combobox("Lag mode", {"Static","Adaptive"}, "Lag mode", p:GetItemPanel())
   
    jiggabooware.checkbox("Michael Jackson exploit","Allah walk",p:GetItemPanel(),"allahwalk")
    jiggabooware.checkbox("","Fake duck",p:GetItemPanel(),"Fake duck")
   
    local p = jiggabooware.itemPanel("Tickbase",2,250)


    jiggabooware.multiCombo("Triggers",{"In Attack","On Peek","After peek"},p:GetItemPanel())

    // jiggabooware.checkbox("Skip fire tick","Skip fire tick",p:GetItemPanel())
    

    local p = jiggabooware.itemPanel( "Resolver", 3, 178 )

    jiggabooware.checkbox( "Enable resolver", "Resolver", p:GetItemPanel() )
    jiggabooware.combobox( "Yaw mode", { "Step", "Delta brute" }, "Yaw mode", p:GetItemPanel() )
    jiggabooware.slider( "Max misses", "Resolver max misses", 1, 6, 0, p:GetItemPanel() )
    jiggabooware.checkbox( "Pitch resolver", "Pitch resolver", p:GetItemPanel() )
    jiggabooware.checkbox( "Invert first shot", "Invert first shot", p:GetItemPanel() )
*/
end

/*local p = vgui_Create("UPanel",jiggabooware.scrollpanel)
    p:SetPos(5,y[1])
    p:SetSize(257,200)
    p.txt = "LBY Settings"

    jiggabooware.slider("LBY min delta","LBY min delta",0,360,0,p:GetItemPanel())
    jiggabooware.slider("LBY break delta","LBY break delta",0,360,0,p:GetItemPanel())
    */

jiggabooware.spfuncs[11] = function()
    jiggabooware.ui.SettingsPan:SetSize(250,200)
    
    jiggabooware.ui.CheckBox( jiggabooware.ui.SettingsPan, "Team color", "Box team color" )
    jiggabooware.ui.CheckBox( jiggabooware.ui.SettingsPan, "Gradient", "Box gradient" )
    jiggabooware.ui.ComboBox( jiggabooware.ui.SettingsPan, "Style", "Box style", { "Default", "Corner", "Hex", "Poly" })


end

jiggabooware.spfuncs[12] = function()
    jiggabooware.ui.SettingsPan:SetSize(250,48)
    
    jiggabooware.ui.CheckBox( jiggabooware.ui.SettingsPan, "Health bar", "Health bar" )
    jiggabooware.ui.CheckBox( jiggabooware.ui.SettingsPan, "Gradient", "Health bar gradient" )
end

jiggabooware.spfuncs[14] = function()
    jiggabooware.ui.SettingsPan:SetSize(250,256)
    
    jiggabooware.ui.ComboBox( jiggabooware.ui.SettingsPan, "Visible material", "Visible mat", jiggabooware.chamsMaterials)
    jiggabooware.ui.CheckBox( jiggabooware.ui.SettingsPan, "Weapon chams", "Visible chams w" )

    jiggabooware.ui.ComboBox( jiggabooware.ui.SettingsPan, "Invisible material", "inVisible mat", jiggabooware.chamsMaterials)
    jiggabooware.ui.CheckBox( jiggabooware.ui.SettingsPan, "inVisible chams", "inVisible chams" )
    jiggabooware.ui.CheckBox( jiggabooware.ui.SettingsPan, "Weapon chams", "inVisible chams w" )

    jiggabooware.ui.CheckBox( jiggabooware.ui.SettingsPan, "Fullbright", "Supress lighting" )
end

jiggabooware.spfuncs[15] = function()
    jiggabooware.ui.SettingsPan:SetSize(250,256)

    jiggabooware.ui.ComboBox( jiggabooware.ui.SettingsPan, "Material", "Self mat", jiggabooware.chamsMaterials)
    jiggabooware.ui.CheckBox( jiggabooware.ui.SettingsPan, "Weapon chams", "Self chams w" )

    jiggabooware.ui.CheckBox( jiggabooware.ui.SettingsPan, "Fullbright", "Supress self lighting" )
end

jiggabooware.spfuncs[16] = function()
    jiggabooware.ui.SettingsPan:SetSize(250,256)

    jiggabooware.ui.ComboBox( jiggabooware.ui.SettingsPan, "Material", "Backtrack material", jiggabooware.chamsMaterials)

    jiggabooware.ui.CheckBox( jiggabooware.ui.SettingsPan, "Fullbright", "Backtrack fullbright" )
end

jiggabooware.spfuncs[17] = function()
    jiggabooware.ui.SettingsPan:SetSize(250,256)

    jiggabooware.ui.ComboBox( jiggabooware.ui.SettingsPan, "Material", "Entity material", jiggabooware.chamsMaterials)

    jiggabooware.ui.CheckBox( jiggabooware.ui.SettingsPan, "Fullbright", "Entity fullbright" )
end

jiggabooware.spfuncs[18] = function()
    jiggabooware.ui.SettingsPan:SetSize(250,256)

    jiggabooware.ui.Slider( jiggabooware.ui.SettingsPan, "Die time","Tracers die time",1,10,0 )
    jiggabooware.ui.CheckBox( jiggabooware.ui.SettingsPan, "Bullet tracers muzzle", "Bullet tracers muzzle" )
    
end

jiggabooware.spfuncs[19] = function()
    jiggabooware.ui.SettingsPan:SetSize(250,256)

    jiggabooware.ui.ComboBox( jiggabooware.ui.SettingsPan, "Material", "Viewmodel chams type", jiggabooware.chamsMaterials)
    
    jiggabooware.ui.CheckBox( jiggabooware.ui.SettingsPan, "Fullbright", "Fullbright viewmodel" )
end

jiggabooware.spfuncs[20] = function()
    jiggabooware.ui.SettingsPan:SetSize(250,256)

    jiggabooware.ui.CheckBox( jiggabooware.ui.SettingsPan, "Smoothing", "Third person smoothing" )
    jiggabooware.ui.CheckBox( jiggabooware.ui.SettingsPan, "Collision", "Third person collision" )
    jiggabooware.ui.Slider( jiggabooware.ui.SettingsPan, "Distance","Third person distance",50,220,0 )
end

jiggabooware.spfuncs[21] = function()
    jiggabooware.ui.SettingsPan:SetSize(250,256)

    jiggabooware.ui.Slider( jiggabooware.ui.SettingsPan, "Freecam speed","Free camera speed",5,100,0 )
    jiggabooware.ui.CheckBox( jiggabooware.ui.SettingsPan, "Ghetto mode", "Ghetto free cam" )
end

jiggabooware.spfuncs[31] = function()
    jiggabooware.ui.SettingsPan:SetSize(250,256)

    jiggabooware.ui.CheckBox( jiggabooware.ui.SettingsPan, "3D", "Ent box 3d" )
end


jiggabooware.spfuncs[35] = function( p )
    local mdl = vgui.Create( "DModelPanel", p )
    mdl:SetPos(85,125)
    mdl:SetSize(85,125)
    mdl:SetModel( "models/props_vehicles/truck001a.mdl" ) 

    mdl:SetCamPos(Vector(0,0,148))

    function mdl:LayoutEntity( Entity ) return end 
    
    for i = 1,4 do
        local poses = jiggabooware.esppansposes

        jiggabooware.esppans[i].panel = vgui_Create( "UPaintedPanel", p )
        jiggabooware.esppans[i].panel:SetPos(poses[i].x,poses[i].y)
        jiggabooware.esppans[i].panel:SetSize(85,125)
        jiggabooware.esppans[i].panel:Receiver( "SwagCock$", jiggabooware.DoDrop )
        jiggabooware.esppans[i].panel.pos = i
    end

    for i = 1, #jiggabooware.espelements do
        local cfgstr = jiggabooware.espelements[i]
        local panel = jiggabooware.esppans[jiggabooware.cfg.vars[cfgstr]].panel

        local b = vgui_Create("UESPPButton")
        b:SetText( cfgstr )
		b:SetSize( 36, 24 )
		b:Dock( TOP )
        b:Droppable( "SwagCock$" ) 

        b:SetParent( panel )
    end
end

jiggabooware.spfuncs[33] = function()
    jiggabooware.ui.SettingsPan:SetSize(250,256)

    jiggabooware.ui.CheckBox( jiggabooware.ui.SettingsPan, "Show ammo", "Show ammo" )
    jiggabooware.ui.CheckBox( jiggabooware.ui.SettingsPan, "Print name", "Weapon printname" )
    jiggabooware.ui.CheckBox( jiggabooware.ui.SettingsPan, "Show reloading", "Show reloading" )
    
end

jiggabooware.spfuncs[34] = function()
    jiggabooware.ui.SettingsPan:SetSize(250,256)


end

function jiggabooware.tabs.Visuals()

    local p = jiggabooware.itemPanel("Player",1,500):GetItemPanel()

    jiggabooware.ui.CheckBox( p, "Box", "Box esp", false, false, true, jiggabooware.spfuncs[11] )

    jiggabooware.ui.CheckBox( p, "Name", "Name", false, false, false, false, false, function(p) local lbl, drop = jiggabooware.ui.ComboBox( p, "", "Name pos", {"Up","Down","Right","Left"} ) lbl:Remove() drop:Dock(RIGHT) drop:DockMargin(0,0,0,0) end )
    jiggabooware.ui.CheckBox( p, "Usergroup", "Usergroup", false, false, false, false, false, function(p) local lbl, drop = jiggabooware.ui.ComboBox( p, "", "Usergroup pos", {"Up","Down","Right","Left"} ) lbl:Remove() drop:Dock(RIGHT) drop:DockMargin(0,0,0,0) end )
    jiggabooware.ui.CheckBox( p, "Health", "Health", false, false, true, jiggabooware.spfuncs[12], false, function(p) local lbl, drop = jiggabooware.ui.ComboBox( p, "", "Health pos", {"Up","Down","Right","Left"} ) lbl:Remove() drop:Dock(RIGHT) drop:DockMargin(3,0,0,0) jiggabooware.ui.ColorPicker( "Health bar gradient", p ) end )
    jiggabooware.ui.CheckBox( p, "Armor", "Armor", false, false, false, false, false, function(p) local lbl, drop = jiggabooware.ui.ComboBox( p, "", "Armor pos", {"Up","Down","Right","Left"} ) lbl:Remove() drop:Dock(RIGHT) drop:DockMargin(0,0,0,0) end )
    jiggabooware.ui.CheckBox( p, "Weapon", "Weapon", false, false, false, jiggabooware.spfuncs[33], false, function(p) local lbl, drop = jiggabooware.ui.ComboBox( p, "", "Weapon pos", {"Up","Down","Right","Left"} ) lbl:Remove() drop:Dock(RIGHT) drop:DockMargin(3,0,0,0) end )
    jiggabooware.ui.CheckBox( p, "Team", "Team", false, false, false, false, false, function(p) local lbl, drop = jiggabooware.ui.ComboBox( p, "", "Team pos", {"Up","Down","Right","Left"} ) lbl:Remove() drop:Dock(RIGHT) drop:DockMargin(0,0,0,0) end )
    jiggabooware.ui.CheckBox( p, "Money", "DarkRP Money", false, false, false, false, false, function(p) local lbl, drop = jiggabooware.ui.ComboBox( p, "", "Money pos", {"Up","Down","Right","Left"} ) lbl:Remove() drop:Dock(RIGHT) drop:DockMargin(0,0,0,0) end )
    jiggabooware.ui.CheckBox( p, "Lag compensation", "Break LC", false, false, false, false, false, function(p) local lbl, drop = jiggabooware.ui.ComboBox( p, "", "Break LC pos", {"Up","Down","Right","Left"} ) lbl:Remove() drop:Dock(RIGHT) drop:DockMargin(0,0,0,0) end )
    jiggabooware.ui.CheckBox( p, "Packets ( Fake lag )", "Simtime updated", false, false, false, false, false, function(p) local lbl, drop = jiggabooware.ui.ComboBox( p, "", "Simtime pos", {"Up","Down","Right","Left"} ) lbl:Remove() drop:Dock(RIGHT) drop:DockMargin(0,0,0,0) end )
    
    
    jiggabooware.ui.Slider( p, "Max distance","ESP Distance",0,100000,0 )
    
    jiggabooware.ui.CheckBox( p, "Show records", "Show records" )
    jiggabooware.ui.CheckBox( p, "Skeleton", "Skeleton" )
    jiggabooware.ui.CheckBox( p, "OOF Arrows", "OOF Arrows", false, false, false, false, false, function(p)
        local lbl, drop = jiggabooware.ui.ComboBox( p, "", "OOF Style", {"Arrow","UkroSwastika"} ) 
        lbl:Remove() 
        drop:Dock(RIGHT) 
        drop:DockMargin(0,0,0,0) 
    end )
    // jiggabooware.ui.CheckBox( p, "OOF Arrows", "OOF Arrows", false, false, false, jiggabooware.spfuncs[34], false, function(p) local lbl, drop = jiggabooware.ui.ComboBox( p, "", "OOF Style", {"Arrow","UkroSwastika"} ) lbl:Remove() drop:Dock(RIGHT) drop:DockMargin(0,0,0,0) end )
    jiggabooware.ui.CheckBox( p, "Sight lines", "Sight lines" )
    jiggabooware.ui.CheckBox( p, "InFOV Indicator", "IFOV" )

    jiggabooware.ui.ComboBox( p, "Font", "ESP Font", { "Outlined", "Shadow", "Thug" } )

    







    


    local p = jiggabooware.itemPanel("Entity",1,135):GetItemPanel()

    jiggabooware.ui.CheckBox( p, "Box", "Ent box", false, false, false, jiggabooware.spfuncs[31] )
    jiggabooware.ui.CheckBox( p, "Class", "Ent class" )
    jiggabooware.ui.Slider( p, "Max distance","Ent ESP Distance",0,100000,0 )
    jiggabooware.ui.Label( p, "Add entity key", function( p ) jiggabooware.ui.Binder( "Ent add", p ) end )

    local p = jiggabooware.itemPanel( "Hitmarker", 1, 215 ):GetItemPanel()

    jiggabooware.ui.CheckBox( p, "Hitmarker", "Hitmarker", false, false, true )
    jiggabooware.ui.CheckBox( p, "Hitnumbers", "Hitnumbers", false, false, true, false, false, function(p) jiggabooware.ui.ColorPicker( "Hitnumbers krit", p ) end )
    //jiggabooware.ui.CheckBox( p, "Hit particles", "Hit particles", false, false, true, jiggabooware.spfuncs[31] )
    jiggabooware.ui.CheckBox( p, "Hitsound", "Hitsound" )
    jiggabooware.ui.TextEntry( "Sound path", "Hitsound str", p, 420 )
    jiggabooware.ui.CheckBox( p, "Killsound", "Killsound" )
    jiggabooware.ui.TextEntry( "Sound path", "Killsound str", p, 420 )
    
    local p = jiggabooware.itemPanel("Colored models",2,150):GetItemPanel()

    jiggabooware.ui.CheckBox( p, "Player chams", "Visible chams", false, false, true, jiggabooware.spfuncs[14], false, function(p) jiggabooware.ui.ColorPicker( "inVisible chams", p ) end )
    jiggabooware.ui.CheckBox( p, "Self chams", "Self chams", false, false, true, jiggabooware.spfuncs[15] )
    jiggabooware.ui.CheckBox( p, "Backtrack chams", "Backtrack chams", false, false, true, jiggabooware.spfuncs[16] )
    jiggabooware.ui.CheckBox( p, "Entity chams", "Entity chams", false, false, true, jiggabooware.spfuncs[17], false )
    jiggabooware.ui.CheckBox( p, "Viewmodel chams", "Viewmodel chams", false, false, true, jiggabooware.spfuncs[19], false )

    local p = jiggabooware.itemPanel("Material customisation",2,150):GetItemPanel()

    jiggabooware.ui.Slider( p, "Min illumination", "Fresnel minimum illum", 0, 1, 1, function( v )
        local v1, v2, v3, v4 = jiggabooware.chamMats.vis[3], jiggabooware.chamMats.vis[4], jiggabooware.chamMats.invis[3], jiggabooware.chamMats.invis[3]

        v1:SetVector( "$selfIllumFresnelMinMaxExp", Vector( v, jiggabooware.cfg.vars["Fresnel maximum illum"], jiggabooware.cfg.vars["Fresnel exponent"] ) )
        v2:SetVector( "$selfIllumFresnelMinMaxExp", Vector( v, jiggabooware.cfg.vars["Fresnel maximum illum"], jiggabooware.cfg.vars["Fresnel exponent"] ) )
        v3:SetVector( "$selfIllumFresnelMinMaxExp", Vector( v, jiggabooware.cfg.vars["Fresnel maximum illum"], jiggabooware.cfg.vars["Fresnel exponent"] ) )
        v4:SetVector( "$selfIllumFresnelMinMaxExp", Vector( v, jiggabooware.cfg.vars["Fresnel maximum illum"], jiggabooware.cfg.vars["Fresnel exponent"] ) )
    end )
    
    jiggabooware.ui.Slider( p, "Max illumination", "Fresnel maximum illum", 0, 1, 1, function( v )
        local v1, v2, v3, v4 = jiggabooware.chamMats.vis[3], jiggabooware.chamMats.vis[4], jiggabooware.chamMats.invis[3], jiggabooware.chamMats.invis[3]

        v1:SetVector( "$selfIllumFresnelMinMaxExp", Vector( jiggabooware.cfg.vars["Fresnel minimum illum"], v, jiggabooware.cfg.vars["Fresnel exponent"] ) )
        v2:SetVector( "$selfIllumFresnelMinMaxExp", Vector( jiggabooware.cfg.vars["Fresnel minimum illum"], v, jiggabooware.cfg.vars["Fresnel exponent"] ) )
        v3:SetVector( "$selfIllumFresnelMinMaxExp", Vector( jiggabooware.cfg.vars["Fresnel minimum illum"], v, jiggabooware.cfg.vars["Fresnel exponent"] ) )
        v4:SetVector( "$selfIllumFresnelMinMaxExp", Vector( jiggabooware.cfg.vars["Fresnel minimum illum"], v, jiggabooware.cfg.vars["Fresnel exponent"] ) )
    end )
 
    jiggabooware.ui.Slider( p, "Fresnel exponent", "Fresnel exponent", 0, 1, 1, function( v )
        local v1, v2, v3, v4 = jiggabooware.chamMats.vis[3], jiggabooware.chamMats.vis[4], jiggabooware.chamMats.invis[3], jiggabooware.chamMats.invis[3]

        v1:SetVector( "$selfIllumFresnelMinMaxExp", Vector( jiggabooware.cfg.vars["Fresnel minimum illum"], jiggabooware.cfg.vars["Fresnel maximum illum"], v ) )
        v2:SetVector( "$selfIllumFresnelMinMaxExp", Vector( jiggabooware.cfg.vars["Fresnel minimum illum"], jiggabooware.cfg.vars["Fresnel maximum illum"], v ) )
        v3:SetVector( "$selfIllumFresnelMinMaxExp", Vector( jiggabooware.cfg.vars["Fresnel minimum illum"], jiggabooware.cfg.vars["Fresnel maximum illum"], v ) )
        v4:SetVector( "$selfIllumFresnelMinMaxExp", Vector( jiggabooware.cfg.vars["Fresnel minimum illum"], jiggabooware.cfg.vars["Fresnel maximum illum"], v ) )
    end )

    local p = jiggabooware.itemPanel("Outlines",2,115):GetItemPanel()

    jiggabooware.ui.CheckBox( p, "Player outline", "Player outline", false, false, true )
    jiggabooware.ui.CheckBox( p, "Entity outline", "Entity outline", false, false, true )
    jiggabooware.ui.ComboBox( p, "Style", "Outline style", { "Default", "Subtractive", "Additive" } )

    local p = jiggabooware.itemPanel( "Indicators", 2, 115 ):GetItemPanel()

    jiggabooware.ui.CheckBox( p, "On screen logs", "On screen logs", false, false, true, false, false, function(p) jiggabooware.ui.ColorPicker( "Miss lagcomp", p ) jiggabooware.ui.ColorPicker( "Miss spread", p ) jiggabooware.ui.ColorPicker( "Miss fail", p ) end )
    jiggabooware.ui.CheckBox( p, "Spectator list", "Spectator list" )

    


    local p = jiggabooware.itemPanel("World",3,320):GetItemPanel()

    jiggabooware.ui.TextEntry( "Skybox texture", "Custom sky", p, 420 )
    jiggabooware.ui.CheckBox( p, "Sky color", "Sky color", false, false, true )
    jiggabooware.ui.CheckBox( p, "Wall color", "Wall color", false, false, true )
    jiggabooware.ui.CheckBox( p, "Bullet tracers", "Bullet tracers", false, false, true, jiggabooware.spfuncs[18] )
    jiggabooware.ui.TextEntry( "Material", "Bullet tracers material", p, 420 )
    jiggabooware.ui.CheckBox( p, "Fullbright", "Fullbright", false, true )
    jiggabooware.ui.ComboBox( p, "Mode", "Fullbright mode", { "Default", "Corvus extreme" } )
    jiggabooware.ui.CheckBox( p, "Disable shadows", "Disable shadows" )

    local p = jiggabooware.itemPanel("View",3,192):GetItemPanel()

    jiggabooware.ui.CheckBox( p, "Third person", "Third person", false, true, false, jiggabooware.spfuncs[20] )
    jiggabooware.ui.CheckBox( p, "Free camera", "Free camera", false, true, false, jiggabooware.spfuncs[21] )

    jiggabooware.ui.Slider( p, "Fov override","Fov override",75,160,0 )
    jiggabooware.ui.Slider( p, "Viewmodel fov","Viewmodel fov",50,180,0 )
    jiggabooware.ui.Slider( p, "Aspect ratio","Aspect ratio",0,2,3,function(val) gRunCmd("r_aspectratio",val) end )

    local p = jiggabooware.itemPanel( "Misc", 3, 220 ):GetItemPanel()

    jiggabooware.ui.CheckBox( p, "Hide name", "Hide name" )
    jiggabooware.ui.TextEntry( "Custom name", "Custom name", p, 999 )
    jiggabooware.ui.CheckBox( p, "Disable sensivity adjustment", "Disable SADJ" )
    jiggabooware.ui.CheckBox( p, "Screengrab image", "Screengrab image" )


    
    

   



    





    

    




    local p = jiggabooware.itemPanel("Indicators",1,185):GetItemPanel()

    jiggabooware.ui.CheckBox( p, "Tickbase indicator", "Tickbase indicator" )

    
    /*





    jiggabooware.checkbox("Kill sound","Killsound",p:GetItemPanel())
    

    local p = jiggabooware.itemPanel("World",2,123)

    

    local p = jiggabooware.itemPanel("Effects",2,142)


    
    

    local p = jiggabooware.itemPanel("View",3,275)




    // jiggabooware.ESPPP:Show()
*/
end

jiggabooware.spfuncs[25] = function()
    jiggabooware.ui.SettingsPan:SetSize(250,256)

    jiggabooware.ui.ComboBox( jiggabooware.ui.SettingsPan, "Strafe mode", "Strafe mode", {"Legit","Rage","Multidir"})
    jiggabooware.ui.CheckBox( jiggabooware.ui.SettingsPan, "Ground strafer", "Ground strafer" )
    jiggabooware.ui.CheckBox( jiggabooware.ui.SettingsPan, "Sin ( snake ) strafe", "Z Hop", false, true )
end

jiggabooware.spfuncs[26] = function()
    jiggabooware.ui.SettingsPan:SetSize(250,256)

    jiggabooware.ui.Slider( jiggabooware.ui.SettingsPan, "Predict ticks", "CStrafe ticks", 16, 128, 0 )
    jiggabooware.ui.Slider( jiggabooware.ui.SettingsPan, "Angle step", "CStrafe angle step", 1, 10, 0 )
    jiggabooware.ui.Slider( jiggabooware.ui.SettingsPan, "Angle max step", "CStrafe angle max step", 5, 50, 0 )
    jiggabooware.ui.Slider( jiggabooware.ui.SettingsPan, "Ground diff", "CStrafe ground diff", 1, 65, 0 )
end

jiggabooware.spfuncs[27] = function( p )
    jiggabooware.ui.TextEntry( "Name", "Name Convar", p, 250 )
    jiggabooware.ui.Button( "Change name", function() ded.NetSetConVar("name",jiggabooware.cfg.vars["Name Convar"]) end, p )
    jiggabooware.ui.CheckBox( p, "Name stealer", "Name stealer" )

    jiggabooware.ui.TextEntry( "Disconnect reason", "Disconnect reason", p, 250 )
    jiggabooware.ui.Button( "Disconnect", function() ded.NetDisconnect(jiggabooware.cfg.vars["Disconnect reason"]) end, p )
end 

function jiggabooware.CustomCvarVal( net )
    local m = net == 1 and "Net Convar mode" or "Cvar mode"
    local n = net == 1 and "Net Convar int" or "Cvar int"
    local s = net == 1 and "Net Convar str" or "Cvar str"

    local mode = jiggabooware.cfg.vars[m] 
    local num = jiggabooware.cfg.vars[n]
    local set = mode == 2 and math_Round( num ) or num

    if mode == 1 then set = jiggabooware.cfg.vars[s] end

    return set
end

jiggabooware.spfuncs[28] = function( p )
    jiggabooware.ui.TextEntry( "Cvar name", "Net Convar", p, 250 )
    jiggabooware.ui.Slider( p, "Cvar int", "Net Convar int", 1, 100, 2 )
    jiggabooware.ui.TextEntry( "Cvar str", "Net Convar str", p, 250 )

    jiggabooware.ui.ComboBox( p, "Set mode", "Net Convar mode", {"String","Int","Float"})

    jiggabooware.ui.Button( "Send new val", function() ded.NetSetConVar( jiggabooware.cfg.vars["Net Convar"] ,jiggabooware.CustomCvarVal( 1 ) ) end, p )
end 

jiggabooware.FCVAR = {
    str = {
        "Archive", "Archive XBOX", "Cheat", "Client can execute", "Client DLL", "Demo", "Dont record",
        "Game DLL", "Lua client", "Lua server", "Never as string", "None", "Notify", "Not connected",
        "Printable only", "Protected", "Replicated", "Server cannot query", "Server can execute",
        "Sponly", "Unlogged", "Unregistered", "Userinfo"
    },
    int = {
        128, 16777216, 16384, 1073741824, 8, 65536, 131072, 4, 262144, 524288, 4096, 0, 256, 4194304,
        1024, 32, 8192, 536870912, 268435456, 64, 2048, 1, 512
    }
}

jiggabooware.spfuncs[29] = function( p )
    jiggabooware.ui.TextEntry( "Enter cvar name", "Cvar name", p, 500 )
    jiggabooware.ui.Slider( p, "Custom number", "Cvar int", 1, 1000, 2 )
    jiggabooware.ui.TextEntry( "Custom string", "Cvar str", p, 500 )

    jiggabooware.ui.ComboBox( p, "Cvar mode", "Cvar mode", {"String","Int","Float"})
    
    jiggabooware.ui.Button( "Change cvar", function()
        local s = jiggabooware.CustomCvarVal( 0 )
        local n = jiggabooware.cfg.vars["Cvar name"]
        
        local flag = GetConVar(n):GetFlags()

        ded.CVarSetFlags( n, 0 )

        gRunCmd( n, s )

        ded.CVarSetFlags( n, flag )
    end, p )

    jiggabooware.ui.ComboBox( p, "Cvar flag", "Cvar flag", jiggabooware.FCVAR.str)

    jiggabooware.ui.Button( "Change flag", function()
        ded.CVarSetFlags( jiggabooware.cfg.vars["Cvar name"], jiggabooware.FCVAR.int[ jiggabooware.cfg.vars["Cvar flag"] ] )
        print( jiggabooware.cfg.vars["Cvar name"], jiggabooware.FCVAR.int[ jiggabooware.cfg.vars["Cvar flag"] ] )
    end, p )

end 

function jiggabooware.tabs.Misc()

    local function func( p )
        jiggabooware.ui.MTButton( p, "Cvar", jiggabooware.spfuncs[29] )
        jiggabooware.ui.MTButton( p, "Net cvar", jiggabooware.spfuncs[28] )
        jiggabooware.ui.MTButton( p, "Net", jiggabooware.spfuncs[27] )
    end

    local p = jiggabooware.itemPanel("Movement",1,200):GetItemPanel()

    jiggabooware.ui.CheckBox( p, "Bunny hop", "Bhop" )
    jiggabooware.ui.CheckBox( p, "Air strafer", "Air strafer", false, false, false, jiggabooware.spfuncs[25] )
    jiggabooware.ui.CheckBox( p, "Circle strafe", "Circle strafe", false, true, false, jiggabooware.spfuncs[26] )
    jiggabooware.ui.CheckBox( p, "Keep sprint", "Sprint" )
    jiggabooware.ui.CheckBox( p, "Fast stop", "Fast stop" )
    jiggabooware.ui.CheckBox( p, "Auto peak", "Auto peak", false, true )
    jiggabooware.ui.CheckBox( p, "Auto teleport back", "Auto peak tp" )
    jiggabooware.ui.CheckBox( p, "Water walk", "Water jump" )

    local p = jiggabooware.itemPanel("Key spam",1,185):GetItemPanel()

    jiggabooware.ui.CheckBox( p, "Use spam", "Use spam" )
    jiggabooware.ui.CheckBox( p, "Flashlight spam", "Flashlight spam" )
    jiggabooware.ui.CheckBox( p, "Auto GTA", "Auto GTA" )
    jiggabooware.ui.CheckBox( p, "Camera spam", "Camera spam" )
    jiggabooware.ui.CheckBox( p, "Vape spam", "Vape spam" )

    local p = jiggabooware.itemPanel("Chat spam",2,250):GetItemPanel()

    jiggabooware.ui.CheckBox( p, "Killsay", "Killsay" )
    jiggabooware.ui.CheckBox( p, "Chat spam", "Chat spammer" )

    jiggabooware.ui.ComboBox( p, "Mode", "Chat mode", { "Лучшее 22-23", "Унижалка", "Школа хвх", "AI унижалка", "Игра пилы", "В.В. Путин", "Arabic", "українська мова" })
    jiggabooware.ui.ComboBox( p, "Group", "Chat group", { "Normal", "/OOC", "Advert", "PM", "ULX" })
    
    

    //jiggabooware.ui.ComboBox( p, "Spam mode", {"Русский сборник сказок","Rage","Multidir"}, "Spam mode")

    jiggabooware.itemPanelB( "Net / Cvar", 3, 345, func )

    local p = jiggabooware.itemPanel("Memes",3,250):GetItemPanel()

    jiggabooware.ui.CheckBox( p, "Ghost follower", "Ghost follower" )
    jiggabooware.ui.TextEntry( "Targets ID", "GFID", p, 500 )
    jiggabooware.ui.CheckBox( p, "Auto Затяг ( Vape )", "Auto Vape" )
    jiggabooware.ui.CheckBox( p, "Fast lockpick", "Fast lockpick" )

   /*
        jiggabooware.checkbox("Safe hop","Safe hop",p:GetItemPanel())
        jiggabooware.checkbox("Edge jump","Edge jump",p:GetItemPanel())
        jiggabooware.checkbox("Air duck","Air duck",p:GetItemPanel())
    */
end

/*
function jiggabooware.updateMenuColor( col )
    local r, g, b = col.r, col.g, col.b 

    for i = 1,255 do 
        jiggabooware.Colors[i] = Color( i + r, i + g, i + b, 255 )
    end
end
*/


function jiggabooware.tabs.Settings()
    local p = jiggabooware.itemPanel("Config",1,200):GetItemPanel()

    jiggabooware.ui.TextEntry( "Config name", "Config name", p, 64 )

    jiggabooware.ui.ComboBox( p, "Config", "Selected config", jiggabooware.configs)

    jiggabooware.ui.Button( "Save config", function() jiggabooware.SaveConfig() end, p )
    jiggabooware.ui.Button( "Load config", function() jiggabooware.LoadConfig() end, p )

    //jiggabooware.ui.Label( p, "Menu color", function( p ) jiggabooware.ui.ColorPicker( "Menu color", p, jiggabooware.updateMenuColor ) end )
end

function jiggabooware.tabs.Players()
    local playerlist = vgui.Create( "UListView", jiggabooware.scrollpanel )
    playerlist:SetPos( 5, 5 )
    playerlist:SetSize( 500, 775 )
    playerlist:SetMultiSelect( false )
    playerlist:AddColumn( "Name" )
    playerlist:AddColumn( "SID" )
    playerlist:AddColumn( "SID64" )
    playerlist:AddColumn( "Team" )
    playerlist:AddColumn( "Group" )

    local plys = player_GetAll()

    for i = 1, #plys do
        playerlist:AddLine( plys[ i ]:Name(), plys[ i ]:SteamID(), plys[ i ]:SteamID64(), team_GetName( plys[ i ]:Team() ), plys[ i ]:GetUserGroup() )
    end
    


end

function jiggabooware.alphacredit()
    print("Modifications by Lordalpha c.is.sharp on discord")

end
function jiggabooware.jegacredit()
    print("Original by Serejega")

end

function jiggabooware.tabs.Credits()
    
    local p = jiggabooware.itemPanel("Credits",1,200):GetItemPanel()

    jiggabooware.ui.Button( "Modifications by Lordalpha", function() jiggabooware.alphacredit() end, p )
    jiggabooware.ui.Button( "Original Ultimate by Serajega", function() jiggabooware.jegacredit() end, p )


    //jiggabooware.ui.Label( p, "Menu color", function( p ) jiggabooware.ui.ColorPicker( "Menu color", p, jiggabooware.updateMenuColor ) end )
end

function jiggabooware.tabs.gRust()
    
    local p = jiggabooware.itemPanel("Exploits",1,200):GetItemPanel()

    jiggabooware.ui.Button( "Farmerware Exploit GUI", function() jiggabooware.Invswapper() end, p )
    jiggabooware.ui.Button( "Fast Walk", function() jiggabooware.fastwalk() end, p )
    jiggabooware.ui.Button( "Fast Respawn", function() jiggabooware.respawnfast() end, p )
    jiggabooware.ui.Button( "Inventory Sync", function() jiggabooware.sync() end, p )
    

    local p = jiggabooware.itemPanel("TC Auth Required Scripts",2,250):GetItemPanel()
    jiggabooware.ui.Button( "Demolisher", function() jiggabooware.niggademo() end, p)
    jiggabooware.ui.Button( "Key Pickup", function() jiggabooware.keynigga() end, p)


    //jiggabooware.ui.Label( p, "Menu color", function( p ) jiggabooware.ui.ColorPicker( "Menu color", p, jiggabooware.updateMenuColor ) end )
end

function jiggabooware.tabs.Scripts()
    local p = jiggabooware.itemPanel("Other Scripts",1,200):GetItemPanel()

    jiggabooware.ui.Button( "Catharsis ESP", function() jiggabooware.Catharsis() end, p )
    jiggabooware.ui.Button( "Animated Weapon Chams", function() jiggabooware.weaponchams() end, p )
    jiggabooware.ui.Button( "Net Logger", function() jiggabooware.netlogger() end, p )
    
    
    
end

function jiggabooware.keynigga()
    print("keyscarp")


    local function MoveItemsToEntity()
        local targetEntity = LocalPlayer():GetEyeTrace().Entity 
    
        local function GetLocalPlayerID()
            local localPlayer = LocalPlayer()
            if IsValid(localPlayer) then
                return localPlayer:EntIndex()
            end
            return nil
        end
    
        local localPlayerID = GetLocalPlayerID()
    
        if IsValid(targetEntity) then
            net.Start("gRust.PickupLock") 
                net.WriteEntity(targetEntity) 
            net.SendToServer() 
        else
            print("No valid entity found.")
        end
    end
    
    hook.Add("PlayerButtonDown", "MoveItemsBinding", function(ply, button)
        if button == KEY_H then
            MoveItemsToEntity()
        end
    end)
    

end



function jiggabooware.niggademo()
    local isMoving = false
local delay = 0.1  

local function MoveItemsToEntity()
    local targetEntity = LocalPlayer():GetEyeTrace().Entity 

    net.Start("gRust.Demolish")
    net.WriteEntity(targetEntity)
    net.SendToServer()
end

hook.Add("Think", "MoveItemsThink", function()
    if isMoving and input.IsKeyDown(KEY_L) then
        MoveItemsToEntity()
        timer.Simple(delay, function()  
            if isMoving then
                MoveItemsToEntity()
            end
        end)
    else
        isMoving = false
    end
end)

hook.Add("PlayerButtonDown", "MoveItemsBinding", function(ply, button)
    if button == KEY_L then
        isMoving = true
    end
end)

hook.Add("PlayerButtonUp", "StopMovingItemsBinding", function(ply, button)
    if button == KEY_L then
        isMoving = false
    end
end)

end

function jiggabooware.netlogger()
    

netCodes = netCodes or {
	["SendToServer"] = net.SendToServer,
	["Start"] = net.Start,
	["WriteAngle"] = net.WriteAngle,
	["WriteBit"] = net.WriteBit,
	["WriteBool"] = net.WriteBool,
	["WriteColor"] = net.WriteColor,
	["WriteData"] = net.WriteData,
	["WriteDouble"] = net.WriteDouble,
	["WriteEntity"] = net.WriteEntity,
	["WriteFloat"] = net.WriteFloat,
	["WriteInt"] = net.WriteInt,
	["WriteMatrix"] = net.WriteMatrix,
	["WriteNormal"] = net.WriteNormal,
	["WriteString"] = net.WriteString,
	["WriteTable"] = net.WriteTable,
	["WriteUInt"] = net.WriteUInt,
	["WriteVector"] = net.WriteVector
}

function tableToString(t)
   if type(o) == 'table' then
      local s = '{ '
      for k,v in pairs(o) do
         if type(k) ~= 'number' then k = '"'..k..'"' end
         s = s .. '['..k..'] = ' .. dump(v) .. ','
      end
      return s .. '} '
   else
      return tostring(o)
   end
end


local buffer = ""

local function construct_net_block(t, netName)
	makeString = "net." ..netName .. "("
	for i=1, #t do
		indexValue = t[i]
		if (type(indexValue) == "number") then
			if (i == #t) then makeString = makeString .. indexValue  else makeString = makeString .. indexValue .. ", " end
		elseif (type(indexValue) == "boolean") then
			makeString = makeString .. tostring(indexValue)
		elseif (type(indexValue) == "string") then
			if (i == #t) then makeString = makeString .. "\"" .. indexValue .. "\"" else makeString = makeString .. "\"" .. indexValue .. "\", " end
		elseif (type(indexValue) == "Player" || type(indexValue) == "Entity" || type(indexValue) == "NPC") then
			makeString = makeString .. "Entity(" .. tostring(indexValue:EntIndex()) .. ")"
		elseif (type(indexValue) == "Vector") then
			makeString = makeString .. "Vector(" .. string.gsub(tostring(indexValue), "%s+", ", ") .. ")"
		elseif (type(indexValue) == "table") then
			print("INDEXVALUE IS TABLE")
			print("indevalue", table.ToString(indexValue))
			makeString = makeString .. table.ToString(indexValue)
		else
			ErrorNoHalt("[netlogthing] !!! UNHANDLED !!! " .. "type(index): " .. "[" .. type(indexValue) .. "]" .. " index: " ..  "[" .. tostring(indexValue) .. "]")
		end
	end
	
	buffer = buffer .. makeString .. ")" .. "\n"
	if (string.match(buffer, "SendToServer")) then
		hook.Run( "RecvNetMsg", buffer )
		buffer = ""
	end
end



-- net request sent
	-- net requests go through our

	
	
function handle_net_message(netName)
	return function (...) -- just doing this so I can give access to netName in construct_net_block function
		construct_net_block({...}, netName)
		hook.Add( "RecvNetMsg", "netlogger", function(netmsg)
			detour_net_functions(false)
			RunString(netmsg)
			detour_net_functions(true)
		end)
			
		-- netCodes[netName](...)
	end
end


function detour_net_functions(bool) -- WriteTable calls a bunch of other net functions internally, so got to turn it off
	if (bool) then
		for k, v in pairs(netCodes) do
			net[k] = handle_net_message(k)
		end
	else
		for k, v in pairs(netCodes) do
			net[k] = v
		end
	end
		
end


if (!detoured_net_functions) then
	detoured_net_functions = true
	detour_net_functions(true)
else
	print("\n\n\nAlready detoured net functions\n\n\n")
end


function DrawRainbowRectOutline(self, frequency, x, y, w, h )
	for i = x, x + w - 1 do
		surface.SetDrawColor( HSVToColor( i * frequency % 360, 1, 1 ) )
		surface.DrawLine( i, y, i + 1, y )
		surface.DrawLine( i, y + h - 1, i + 1, y + h )
	end
	for i = y, y + h - 1 do
		surface.SetDrawColor( HSVToColor( i * frequency % 360, 1, 1 ) )
		surface.DrawLine( x, i, x, i + 1 )
		surface.DrawLine( x + w - 1, i, x + w, i + 1 )
	end
end

surface.CreateFont( "customFont2", {
	font = "Verdana", -- Use the font-name which is shown to you by your operating system Font Viewer, not the file name
	extended = false,
	size = 15,
	weight = 100,
	blursize = 0,
	scanlines = 0,
	antialias = true,
	underline = false,
	italic = false,
	strikeout = false,
	symbol = false,
	rotary = false,
	shadow = false,
	additive = false,
	outline = false,
} )

function mysplit(inputstr, sep)
        if sep == nil then
                sep = "%s"
        end
        local t={} ; i=1
        for str in string.gmatch(inputstr, "([^"..sep.."]+)") do
                t[i] = str
                i = i + 1
        end
        return t
end

local net_message_box = {
	setTextAndCount = function(self, text, count)
		newLineCount = #mysplit(text, "\n")
		self:SetTitle("      #" .. tostring(count))
		self.netmsgBox:SetText(text)
		W, H = self.netmsgBox:GetSize()
		W, H = self.netmsgBox:GetSize()
		self:SetSize(W, H + 200)
		self:SizeToContents()

	end,
	Init = function(self)
		outer_self = self
		self:ShowCloseButton( false )
		self:SetSize(150, 400)
		self.W, self.H = self:GetSize()
		self.netmsgBox = vgui.Create( "DTextEntry", self)
		self.netmsgBox:SetPos( 40, 50 )
		self.netmsgBox:Dock(FILL)
		self.netmsgBox:SetMultiline(true);
		self.netmsgBox.Paint = function(self,w,h) 
			draw.RoundedBox(0, 0, 0, w, h, Color(48,10,36, 255))
			self:DrawTextEntryText(Color(255, 255, 255), Color(30, 130, 255), Color(255, 255, 255))
		end

		local closeBtn = vgui.Create( "Button", self)
		closeBtn:SetSize( 14,14 )
		closeBtn:SetPos(5,6)
		closeBtn:SetVisible( true )
		closeBtn:SetText( "" )
		closeBtn.Paint = function(self,w,h)
			draw.RoundedBox(5, 0, 0, w, h, Color(225,81,32, 255))
  			-- surface.DrawCircle( 100, 100, 50, Color(255,255,255,255) ) 
			draw.DrawText( "x", "customFont2", w/2, -1, Color( 255,255,255, 255 ), TEXT_ALIGN_CENTER )
		end
		print("outer_self", outer_self)
		function closeBtn:OnMousePressed()
			outer_self:SetVisible(false)
			outer_self:Remove()
		end

	end,

	Paint = function(self, w, h)
		draw.RoundedBox(0, 0, 0, w, h, Color(48,10,36, 255))
		surface.SetDrawColor( Color( 200, 200, 200, 255 ) )
		surface.DrawOutlinedRect(0,0, w-1,h-1)
		surface.DrawOutlinedRect(0,0, w-1,25)
	end,
	Think = function(self, w, h)
		if (self:IsHovered()) then
			
		end
	end
}

vgui.Register("netmessagebox", net_message_box, "DFrame")
-- net_message_box = vgui.Create("netmessagebox")
-- net_message_box:setTextAndCount("net.Start('test')\nnet.SendToServer()")




browser = {
	Init = function(self)
		self.W, self.H = self:GetSize()
		self:SetSize(self.W * 15, 555)
		self:ShowCloseButton(false)
		self:SetDraggable(true)
		self.gmodwiki = vgui.Create("DHTML", self)
		self.gmodwiki:OpenURL("http://wiki.garrysmod.com/page/Main_Page")
		self.gmodwiki.zoom = 100
		self.gmodwiki:Dock(FILL)
		self:SetTitle("")
		-- self:MakePopup()
		
		local addressBar = vgui.Create( "DTextEntry", self ) -- create the form as a child of frame
		addressBar:SetPos( 60, 2 )
		addressBar:SetSize( 400, 25 )
		addressBar:SetText("http://wiki.garrysmod.com/page/Main_Page")
		addressBar.OnEnter = function( self1 )
			self.gmodwiki:OpenURL( self1:GetValue() )	-- print the form's text as server text
		end
		
		local backBtn = vgui.Create( "DButton", self ) -- create the form as a child of frame
		backBtn:SetPos( 5, 2 )
		backBtn:SetSize( 25, 25 )
		backBtn:SetText("<")
		backBtn:SetTextColor(Color(255,255,255))
		backBtn.DoClick = function()
			self.gmodwiki:RunJavascript([[window.history.go(-1)]])
		end
		
		backBtn.Paint = function(self, w, h)
			draw.RoundedBox(0, 0, 0, w, h, Color(57, 58, 49))
		end
		
		local forwardBtn = vgui.Create( "DButton", self ) -- create the form as a child of frame
		forwardBtn:SetPos( 35, 2 )
		forwardBtn:SetSize( 25, 25 )
		forwardBtn:SetText(">")
		forwardBtn:SetTextColor(Color(255,255,255))
		forwardBtn.DoClick = function()
			self.gmodwiki:RunJavascript([[window.history.go(1)]])
		end
		forwardBtn.Paint = function(self, w, h)
			draw.RoundedBox(0, 0, 0, w, h, Color(57, 58, 49))
		end
		
		
		self.gmodwiki:RunJavascript([[
			String.prototype.startsWith = function(char){
				return this[0] == char;
			}
		]]) -- pls update gmod's javascript engine
		
		
		
		local zoomInBtn = vgui.Create( "DButton", self ) -- create the form as a child of frame
		zoomInBtn:SetPos( 465, 2 )
		zoomInBtn:SetSize( 45, 25 )
		zoomInBtn:SetText("Zoom in")
		zoomInBtn:SetTextColor(Color(255,255,255))
		zoomInBtn.DoClick = function()
			self.gmodwiki.zoom = self.gmodwiki.zoom + 10
			self.gmodwiki:RunJavascript("document.body.style.zoom = \"" .. tostring(self.gmodwiki.zoom) .. "%\";")
		end
		zoomInBtn.Paint = function(self, w, h)
			draw.RoundedBox(0, 0, 0, w, h, Color(57, 58, 49))
		end
		
		local zoomOutBtn = vgui.Create( "DButton", self ) -- create the form as a child of frame
		zoomOutBtn:SetPos( 515, 2 )
		zoomOutBtn:SetSize( 45, 25 )
		zoomOutBtn:SetText("Zoom out")
		zoomOutBtn:SetTextColor(Color(255,255,255))
		zoomOutBtn.DoClick = function()
			self.gmodwiki.zoom = self.gmodwiki.zoom - 10
			self.gmodwiki:RunJavascript("document.body.style.zoom = \"" .. tostring(self.gmodwiki.zoom) .. "%\";")
		end
		zoomOutBtn.Paint = function(self, w, h)
			draw.RoundedBox(0, 0, 0, w, h, Color(57, 58, 49))
		end
		
		
		-- local closeBtn = vgui.Create( "DButton", self ) 
		-- closeBtn:SetText( "X" )					
		-- closeBtn:SetPos( 575, 5 )					
		-- closeBtn:SetSize( 20, 20 )			
		-- closeBtn:SetTextColor(Color(255,255,255))
		-- closeBtn.DoClick = function()
			-- self.gmodwiki:RunJavascript([[document.getElementsByTagName("body")[0].style.zoom = "200%"]])
			-- timer.Simple(5, function() 
				-- self:Close() 
			-- end)
		-- end
		-- closeBtn.Paint = function(self,w,h) draw.RoundedBox(0, 0, 0, w, h, Color(170, 37, 37)) end
		
		self.Paint = function(self, w,h)
			draw.RoundedBox(0, 0, 0, w, h, Color(47, 48, 42, 255))
		end
		self.Think = function(self)
			
		end
	end,
}
vgui.Register("browser", browser, "DFrame")

-- vgui.Create("browser")



local infoPopup = {
	
	setInfoText = function(self, tab_name)
		-- print(self.infopopupTexts[tab_name].header)
		self.header:SetText(self.infopopupTexts[tab_name].header)
		self.infoText:SetText(self.infopopupTexts[tab_name].infoText)
	end,

	Init = function(self)
		
		self.infopopupTexts = {
			-- Tab = {header = "", infoText = ""},
			ExploitTab = {header = "Exploit Tab", infoText = "You can upload your exploits locally or to the web here. This tab is also responsible for finding every single net message name on the server you load this menu on and saves it locally so we can tell if other servers have common exploits"},
			NetLoggerTab = {header = "Net logger Tab", infoText = "Logs all the net messages that come through. Useful for things that you can easily interact with that sends net messages i.e NPCs"},
			RepeaterTab = {header = "Repeater Tab", infoText = "Repeats the given net messages"},
			interceptorTab = {header = "Intercepter Tab", infoText = "Repeats the given net messages"},
			LuaViewerTab = {header = "Lua viewer Tab", infoText = "View all the server's client side files here"},
			LuaEditorTab = {header = "Lua editor Tab", infoText = "Simple lua editor with a \"browser\" built in"}
		},
	
		
		self:SetTitle("")
		self:SetSize(350, 350)
		self:Center()
		self:MakePopup()
		self:ShowCloseButton(false)

		
		local closeBtn = vgui.Create( "DButton", self ) 
		closeBtn:SetText( "X" )					
		closeBtn:SetPos( 325, 5 )					
		closeBtn:SetSize( 20, 20 )			
		closeBtn:SetTextColor(Color(255,255,255))
		closeBtn.DoClick = function() self:Close() end
		closeBtn.Paint = function(self,w,h) draw.RoundedBox(0, 0, 0, w, h, Color(170, 37, 37)) end
		
		self.header = vgui.Create("DLabel", self)
		self.header:SetFont("headerFont1")
		self.header:SetSize(150, 35)
		-- self.header:SetText("Exploits tab")
		self.header:Center()
		self.header.posX, self.header.posY = self.header:GetPos()
		self.header:SetPos(self.header.posX, 15)
		
		
		self.infoText = vgui.Create("DLabel", self)
		self.infoText:SetFont("infoFont")
		self.infoText:SetSize(320, 200)
		self.infoText:SetPos(30, 10)

		-- self.infoText:SetText("You can upload your exploits locally or to the web here. This tab is also responsible for finding every single net message name on the server you load this menu on and saves it locally so we can tell if other servers have common exploits")
		self.infoText:SetWrap(true)
		
	
		self.footerText = vgui.Create("DLabel", self)
		self.footerText:SetFont("infoFont")
		self.footerText:SetSize(100, 20)
		self.footerText:Center()
		self.footerText.posX, self.footerText.posY = self.footerText:GetPos()
		self.footerText:SetPos(self.footerText.posX, 320)

		self.footerText:SetText("Made by Riddle")
		self.footerText:SetWrap(true)
		
		self.Paint = function(self,w,h)
			draw.RoundedBox(0, 0, 0, w, h, Color(39, 40, 34))

			surface.SetDrawColor(Color(255,255,255))
			startX = 0
			endX = 350
			startY = 65
			endY = 65
			surface.DrawLine( startX, startY, endX, endY )
			DrawRainbowRectOutline(1, 0,0, w-1,h-1, 2)
		end

	end,
	
}

vgui.Register("infoPopup", infoPopup, "DFrame")


gmodWikiFrame = {
	Init = function(self)
		self:SetSize(700, 600)
		
		self.gmodwiki = vgui.Create("DHTML", self)
		self.gmodwiki:Dock(FILL)
		self.gmodwiki:OpenURL("http://wiki.garrysmod.com/page/Main_Page")

	end,
}


local CodeEditor = {
	setFill = function(self, b)
		if (b) then
			self:Dock(FILL)
		end
	end,
	
	setText = function(self, text)
		self.html:RunJavascript("SetContent(" .. "'" .. text .. "')")
	end,
	
	createButton = function(self)
	
		self.runLuaBtn = vgui.Create("DButton", self.right)
		self.runLuaBtn:Dock(BOTTOM)
		self.runLuaBtn:SetTall(self.runLuaBtn:GetTall() * 1.5)
		self.runLuaBtn:SetText("Run lua")
		self.runLuaBtn.DoClick = function()
			
			if (not self.currentCode) then
				print("[Warning] Nothing inside code editor")
				return 
			end
			RunString(self.currentCode)
		end
		self.runLuaBtn:SetTextColor(Color(255,255,255))
		self.runLuaBtn.Paint = function(self, w, h)
			draw.RoundedBox(0, 0, 0, w, h, Color(57, 58, 49))
		end
		
	end,
	
	showButton = function(self, b)
		self.shouldHaveButton = b
	end,
	
	Init = function(self)
		self.shouldHaveButton = true
		self:SetSize(250, 250)

		-- self:SetPos(20, 30)


		self.right = vgui.Create("PANEL", self)
		self.right:Dock(FILL)

		self.html = vgui.Create("DHTML", self.right)
		self.html:Dock(FILL)
		self.html:SetAllowLua(true)
		self.html:OpenURL("asset://garrysmod/lua/menu_plugins/luaviewer/index.html") --thx metastruct
		self.html:AddFunction("gmodinterface", "OnCode", function(code)
			self.currentCode = code
		end)
		
		-- self.html:RunJavascript("SetContent(" .. "'" .. content .. "')")
		
		
		
		self.html:AddFunction("gmodinterface", "DoLog", function(logstr) print("Log\t=\t", logstr) end)
		timer.Simple(0.1, function()
			if (self.shouldHaveButton) then
				self:createButton()
			else
				self.html:RunJavascript([[SetFontSize(10)]])
			end
		end)
	end
	
}
vgui.Register("CodeEditor", CodeEditor, "DPanel")


surface.CreateFont( "questionMarkFont", {
	font = "Arial", -- Use the font-name which is shown to you by your operating system Font Viewer, not the file name
	extended = false,
	size = 17,
	weight = 500,
	blursize = 0,
	scanlines = 0,
	antialias = true,
	underline = false,
	italic = false,
	strikeout = false,
	symbol = false,
	rotary = false,
	shadow = false,
	additive = false,
	outline = false,
} )


-- if (string.len(file.Read( "exploits.txt", "DATA" )) < 5) then
	-- default = {serversWithExploits = {}, exploits = {}, loggedServers = {}}
	-- file.Write( "exploits.txt", util.TableToJSON(default) )
-- end

local net_message_table = {}
local PANEL = {
	addToCatergory = function(self, netmsg, freq)
		local name = mysplit(netmsg, "\n")[1]
		if not net_message_table[name] then
			local Category = self.CategoryList:Add(name)
			Category:SetExpanded(false)

			local countLabel = vgui.Create( "DLabel", Category )
			countLabel:SetFont("customFont2")
			countLabel:SetColor(Color(255,255,255))
			countLabel:SetPos( 280, 0 )
			countLabel:SetSize(200,16)
			countLabel:SetText("COUNT: 1")

			net_message_box = vgui.Create("netmessagebox")
			net_message_box:Dock( TOP )
			net_message_box:setTextAndCount(netmsg, 1)

			
			DScrollPanel = vgui.Create( "DScrollPanel")
			Category:SetContents(DScrollPanel)

			DScrollPanel:Add(net_message_box)
			DScrollPanel:Dock( FILL )
-- 51.38.95.230:27015

			net_message_table[name] = {panel = Category, count = 1, countLabel = countLabel, DScrollPanel = DScrollPanel}
			Category.Paint = function (s,w,h)			
				draw.RoundedBox(0, 0, 0, w, h, Color(70,69,65))
			end
		else
			count = net_message_table[name].count + 1
			countLabel = net_message_table[name]["countLabel"]
			panel = net_message_table[name]["panel"]
			DScrollPanel = net_message_table[name]["DScrollPanel"]

			net_message_table[name] = { panel = panel, count = count, countLabel = countLabel, DScrollPanel = DScrollPanel}
		
			panel:SetLabel(name)
			
			countLabel:SetFont("customFont2")
			countLabel:SetColor(Color(255,255,255))
			countLabel:SetPos( 280, 0 )
			countLabel:SetText("COUNT: " .. count)

			net_message_box = vgui.Create("netmessagebox")
			net_message_box:setTextAndCount(netmsg, count)
			net_message_box:Dock( TOP )
			DScrollPanel:Add(net_message_box)
			DScrollPanel:Dock( FILL )
			
			self.i = 0

		end
	end,
	
	DrawRainbowRectOutline = function(self, frequency, x, y, w, h )
		for i = x, x + w - 1 do
			surface.SetDrawColor( HSVToColor( i * frequency % 360, 1, 1 ) )
			surface.DrawLine( i, y, i + 1, y )
			surface.DrawLine( i, y + h - 1, i + 1, y + h )
		end
		for i = y, y + h - 1 do
			surface.SetDrawColor( HSVToColor( i * frequency % 360, 1, 1 ) )
			surface.DrawLine( x, i, x, i + 1 )
			surface.DrawLine( x + w - 1, i, x + w, i + 1 )
		end
	end,
	
	Paint = function(self, w, h)
		draw.RoundedBox(0, 0, 0, w, h, Color(47, 48, 42, 255))
		self:DrawRainbowRectOutline(1,0,0, w-1,h-1, 2)
	end,

	Think = function(self, w, h)
		self.W, self.H = self:GetSize()
		if (self.isFrameOpen) then
			self.openGmodWiki:SetVisible(true)
		else
			self.openGmodWiki:SetVisible(false)
		end
		self.W, self.H = w, h
	end
}

function PANEL:IsOpen(b)
	self.isFrameOpen = b
end


function PANEL:Init()
		self.isFrameOpen = true
		
		self.W, self.H = self:GetSize()
		
		outside_self = self
		self:SetSize(400, 400)
		self:SetTitle("Riddle's menu")
		self:Center()
		self:SetVisible( true )
		self:SetDeleteOnClose(false)
		self.W, self.H = self:GetSize()
		self:ShowCloseButton(false)
		
		self.currentTab = "ExploitTab"
				
		local closeBtn = vgui.Create( "DButton", self ) 
		closeBtn:SetText( "X" )		
		closeBtn:SetPos( self.W * 0.93, 5 )					
		closeBtn:SetSize( 20, 20 )			
		closeBtn:SetTextColor(Color(255,255,255))
		closeBtn.DoClick = function() self:Close() end
		closeBtn.Paint = function(self,w,h) draw.RoundedBox(0, 0, 0, w, h, Color(170, 37, 37)) end
		
		local infoBtn = vgui.Create( "DButton", self ) 
		infoBtn:SetText( "?" )	
		infoBtn:SetFont("questionMarkFont")
		infoBtn:SetPos( self.W * 0.87, 5 )					
		infoBtn:SetSize( 20, 20 )			
		infoBtn:SetTextColor(Color(255,255,255))
		infoBtn.DoClick = function()
			infoPopup = vgui.Create("infoPopup")
			infoPopup:setInfoText(self.currentTab)
		end
		infoBtn.Paint = function(self,w,h) draw.RoundedBox(0, 0, 0, w, h, Color(37, 37, 170)) end
		
		

		sheet = vgui.Create( "DPropertySheet", self )
		sheet:SetPos(1, 20)
		sheet:SetSize(397, 376)

		local exploitsPanel = vgui.Create( "DPanel", sheet )
		exploitsPanel:Dock(FILL)
	
		
		self.NetLoggerPanel = vgui.Create( "DPanel", sheet )
		self.NetLoggerPanel:Dock(FILL)
		
		local repeaterPanel = vgui.Create( "DPanel", sheet )
		repeaterPanel:Dock(FILL)

	--	local luaViewerPanel = vgui.Create( "DPanel", sheet )
	--	luaViewerPanel:Dock(FILL)

		local luaEditorPanel = vgui.Create( "DPanel", sheet )
		luaEditorPanel:Dock(FILL)
		
		-- ExploitsTab = sheet:AddSheet( "Exploits", exploitsPanel, "icon16/world.png" )
		NetLoggerTab = sheet:AddSheet( "Net Logger", self.NetLoggerPanel, "icon16/page_white_edit.png" )
		repeaterTab = sheet:AddSheet( "Repeater", repeaterPanel, "icon16/arrow_rotate_anticlockwise.png" )
		interceptorTab = sheet:AddSheet( "Intcepter", repeaterPanel, "icon16/lock_go.png" )
		--luaViewerTab = sheet:AddSheet( "Lua Viewer", luaViewerPanel, "icon16/folder.png", false, false, "See server's clientside files" )
		luaEditorTab = sheet:AddSheet( "Lua Editor", luaEditorPanel, "icon16/application_xp_terminal.png", false, false, "See server's clientside files" )


		self.NetLoggerPanel.Paint = function(s,w,h)
			draw.RoundedBox(0, 0, 0, w, h, Color(39, 40, 34))
		end

		self.CategoryList = vgui.Create( "DCategoryList", self.NetLoggerPanel )
		self.CategoryList.Paint = function(self,w,h) draw.RoundedBox(0, 0, 0, w, h, Color(39, 40, 34)) end
		self.CategoryList:Dock( FILL )
		
		-- adding stuff to net_logger
		c = 0
		hook.Add( "RecvNetMsg", "netlogger2", function( netmsg )
			c = c + 1
			self:addToCatergory(netmsg, c)
		end )

		-- creating the panels
		-- luaViewer = vgui.Create("luaviewer", luaViewerPanel)
		luaEditor = vgui.Create("CodeEditor", luaEditorPanel)
		luaEditor:setFill(true)
		--main_menu = vgui.Create("main_menu", exploitsPanel)
		
		local browser = vgui.Create("browser", self)
		browser:SetPos(600,40)
		browser:SetVisible(false)
		
		-- Detouring and resizeing the panels when you click on them
		-- DoClickExploitsTab = ExploitsTab.Tab.DoClick
		DoClickNetLoggerTab = NetLoggerTab.Tab.DoClick
		--DoClickrepeaterTab = luaViewerTab.Tab.DoClick
		DoClickLuaViewerTab = repeaterTab.Tab.DoClick
		DoClickluaEditorTab = luaEditorTab.Tab.DoClick
		DoClickincepterTab = interceptorTab.Tab.DoClick

		
		-- ExploitsTab.Tab.DoClick = function (...) 
			-- -- outside_self:SizeTo(400, 600, 0.2, 0, 4)  
			-- -- sheet:SetSize(397, 574)
			-- browser:SetVisible(false)
			-- outside_self:SizeTo(700, 600, 0.2, 0, 4)  
			-- sheet:SetSize(697, 574)
			
			-- timer.Create( "Center2", 0.1, 5, function()  outside_self:Center() infoBtn:SetPos( self.W * 0.92, 5 ) closeBtn:SetPos(self.W * 0.96, 5) end )
			-- self.currentTab = "ExploitTab"
			-- DoClickExploitsTab(...) 
		-- end

		
		NetLoggerTab.Tab.DoClick = function (...) 
			outside_self:SizeTo(400, 400, 0.2, 0, 4)  
			sheet:SetSize(397, 376)
			
			-- closeBtn:SetPos(self.W * 0.95, 5)
			
			timer.Create( "Center3", 0.1, 5, function() outside_self:Center() infoBtn:SetPos( self.W * 0.87, 2 ) closeBtn:SetPos(self.W * 0.93, 2) end )
			self.currentTab = "NetLoggerTab"
			DoClickNetLoggerTab(...) 
		end
		
		repeaterTab.Tab.DoClick = function (...) 
			-- outside_self:SizeTo(400, 400, 0.2, 0, 4)  
			-- sheet:SetSize(400, 379)
			
			-- timer.Create( "Center2", 0.1, 5, function()  outside_self:Center() infoBtn:SetPos( self.W * 0.87, 2 ) closeBtn:SetPos(self.W * 0.93, 2) end )
			-- self.currentTab = "RepeaterTab"
			-- DoClickrepeaterTab(...) -- stops the click from going through i.e wont switch when clicked
		end


		interceptorTab.Tab.DoClick = function (...) 
			-- outside_self:SizeTo(400, 400, 0.2, 0, 4)  
			-- sheet:SetSize(400, 379)
			
			-- timer.Create( "Center2", 0.1, 5, function()  outside_self:Center() infoBtn:SetPos( self.W * 0.87, 2 ) closeBtn:SetPos(self.W * 0.93, 2) end )
			-- self.currentTab = "interceptorTab"
			-- DoClickincepterTab(...)  -- stops the click from going through i.e wont switch when clicked
		end
		
		-- luaViewerTab.Tab.DoClick = function(...)
			-- outside_self:SizeTo(ScrW() * .95, ScrH() * .95, 0.2, 0, 4)
			-- sheet:SetSize(ScrW() * .95, ScrH() * .95) 
			-- browser:SetVisible(false)
			-- timer.Create( "Center1", 0.1, 5, function()  outside_self:Center() infoBtn:SetPos( self.W * 0.94, 5 )  closeBtn:SetPos(self.W * 0.97, 5) end )
		
			-- self.currentTab = "LuaViewerTab"
			-- DoClickLuaViewerTab(...)
			
		-- end

		
		
		luaEditorTab.Tab.DoClick = function (...) 
			outside_self:SizeTo(595, 600, 0.2, 0, 4)  
			sheet:SetSize(592, 578)
			
			-- outside_self:SizeTo(1200, 600, 0.2, 0, 4)  
			-- sheet:SetSize(592, 578)
			browser:SetVisible(true)
			timer.Create( "Center4", 0.1, 5, function() outside_self:Center() infoBtn:SetPos( self.W * 0.90, 5 ) closeBtn:SetPos(self.W * 0.95, 5) end )
			
			self.currentTab = "LuaEditorTab"
			DoClickluaEditorTab(...) 
			
		end
		self.OnClose = function() self:IsOpen(false) self.openGmodWiki:SetVisible(false) print("closing")  gui.EnableScreenClicker(false) end
		
		
		
		
		self.openGmodWiki = vgui.Create("DButton", luaEditor)
		self.openGmodWiki:SetPos(575, 250)
		self.openGmodWiki:SetSize(15, 20)
		self.openGmodWiki:SetText(">")
		self.openGmodWiki:SetTextColor(Color(255,255,255))
		self.openGmodWiki.isOpen = false
		self.openGmodWiki.DoClick = function()
			self.openGmodWiki.isOpen = !self.openGmodWiki.isOpen
			if (self.openGmodWiki.isOpen) then
				outside_self:SizeTo(ScrW() * 0.99, 600, 0.2, 0, 4) 
				self.openGmodWiki:SetText("<")
			else
				outside_self:SizeTo(595, 600, 0.2, 0, 4) 
				self.openGmodWiki:SetText(">")
			end
			 
			sheet:SetSize(592, 578)
			
		
			
			timer.Create( "Center4", 0.1, 20, function() outside_self:Center() end )
		end
		
		self.openGmodWiki.Paint = function(self, w, h)
			-- 39 G: 40 B: 34
			draw.RoundedBox(0, 0, 0, w, h, Color(69, 70, 64))
		end
		
	
		self.Think = function()
			self.W, self.H = self:GetSize()
			-- print(self.W)
		end

end
 
vgui.Register("frame_handler", PANEL, "DFrame")

exploit_menu = vgui.Create("frame_handler")
exploit_menu:MakePopup()

concommand.Add("_dbg", function()
	net.Start("test_message")
	net.SendToServer()
end)

concommand.Add("_menu", function ()
	if (!exploit_menu) then
		exploit_menu = vgui.Create("frame_handler")
	end
	gui.EnableScreenClicker(true)
	exploit_menu:IsOpen(true)
	exploit_menu:MakePopup()
	exploit_menu:SetVisible( true )
end)

end


function jiggabooware.weaponchams()

local weaponparams = {
    ["$basetexture"] = "sprites/physbeam",
    ["$nodecal"] = 1,
    ["$model"] = 1,
    ["$additive"] = 1,
    ["$nocull"] = 1,
    Proxies = {
        TextureScroll = {
            texturescrollvar = "$basetexturetransform",
            texturescrollrate = 0.4,
            texturescrollangle = 70,
        }
    }
}
 
local armparams = {
    ["$basetexture"] = "models/inventory_items/dreamhack_trophies/dreamhack_star_blur",
    ["$nodecal"] = 1,
    ["$model"] = 1,
    ["$additive"] = 1,
    ["$nocull"] = 1,
    Proxies = {
        TextureScroll = {
            texturescrollvar = "$basetexturetransform",
            texturescrollrate = 0.2,
            texturescrollangle = 50,
        }
    }
}
 
 
local IsDrawingGlow = false
local Glow = CreateMaterial("edgeglow","UnlitGeneric",weaponparams)
local GlowTwo = CreateMaterial("edgeglow2","UnlitGeneric", armparams)
 
hook.Add("PreDrawViewModel", "PreViewModelChams", function()
    render.SuppressEngineLighting(true)
    if IsDrawingGlow then
        render.SetColorModulation(1, 5, 20)
        render.MaterialOverride(Glow)
    else
        render.SetColorModulation(1, 1, 1)
    end
    render.SetBlend(1)
end)
 
hook.Add("PostDrawViewModel", "PostViewModelChams", function()
    render.SetColorModulation(1, 1, 1)
    render.MaterialOverride(None)
    render.SetBlend(1)
    render.SuppressEngineLighting(false)
 
    if IsDrawingGlow then return end
 
    IsDrawingGlow = true
    LocalPlayer():GetViewModel():DrawModel()
    IsDrawingGlow = false
end)

end


function jiggabooware.Catharsis()
    require("zxcmodule")

local Cat                   = {}

local Ent                   = Entity 
local Vec                   = Vector 
local Ang                   = Angle 
local Col                   = Color 
local Ply                   = Player 
local Mat                   = Material 
local CreateMat             = CreateMaterial
local CurrentTime           = CurTime 
local RenderTime            = FrameTime
local GetConsoleVar         = GetConVar
local iPairs                = ipairs 
local Pairs                 = pairs 
local FirstTimePredicted    = IsFirstTimePredicted
local ValidCheck            = IsValid
local Interpolate           = Lerp 
local ToNumber              = tonumber 
local ToString              = tostring
local IsString              = isstring

local Bit                   = bit 
local Cam                   = cam 
local Engine                = engine 
local Ents                  = ents
local Util                  = util
local Hook                  = hook  
local InputLib              = input
local RenderLib             = render
local Math                  = math
local Steam                 = steamworks
local Surface               = surface 
local TeamLib               = team 

local Band                  = Bit.band 
local Bnot                  = Bit.bnot 
local Bor                   = Bit.bor 

local CamEnd2D              = Cam.End2D
local CamEnd3D              = Cam.End3D
local CamEnd3D2D            = Cam.End3D2D
local CamStart2D            = Cam.Start2D
local CamStart3D            = Cam.Start3D
local CamStart3D2D          = Cam.Start3D2D
local CamIgnoreZ            = Cam.IgnoreZ

local EngineTickCount       = Engine.TickCount

local EntsGetAll            = Ents.GetAll

local UtilTraceLine         = Util.TraceLine
local UtilTraceHull         = Util.TraceHull

local HookAdd               = Hook.Add
local HookRemove            = Hook.Remove

local InputIsKeyDown        = InputLib.IsKeyDown
local InputIsMouseDown      = InputLib.IsMouseDown
local InputWasKeyPressed    = InputLib.WasKeyPressed
local InputWasMousePressed  = InputLib.WasMousePressed

local MathAbs               = Math.abs 
local MathAcos              = Math.acos 
local MathApproach          = Math.Approach 
local MathAsin              = Math.asin
local MathAtan              = Math.atan
local MathAtan2             = Math.atan2 
local MathCeil              = Math.ceil
local MathClamp             = Math.Clamp 
local MathCos               = Math.cos 
local MathDeg               = Math.deg 
local MathFloor             = Math.floor  
local MathMax               = Math.max 
local MathMin               = Math.min 
local MathModF              = Math.modf 
local MathNormalizeAng      = Math.NormalizeAngle 
local MathRad               = Math.rad 
local MathRand              = Math.Rand 
local MathRandom            = Math.random 
local MathRandomSeed        = Math.randomseed 
local MathRound             = Math.Round 
local MathSin               = Math.sin 
local MathSqrt              = Math.sqrt 
local MathTan               = Math.tan

local SetAlphaMultiplier    = Surface.SetAlphaMultiplier
local SetTextDrawColor      = Surface.SetTextColor
local GetTextDrawSize       = Surface.GetTextSize
local DrawText              = Surface.DrawText
local SetTextPos            = Surface.SetTextPos
local SetTextFont           = Surface.SetFont
local DrawLine              = Surface.DrawLine
local SetDrawColor          = Surface.SetDrawColor
local DrawRect              = Surface.DrawRect
local SetDrawMaterial       = Surface.SetMaterial 
local TexturedRect          = Surface.DrawTexturedRect
local OutlinedRect          = Surface.DrawOutlinedRect

local MetaEntity            = FindMetaTable( "Entity" )
local MetaVector            = FindMetaTable( "Vector" )
local MetaPlayer            = FindMetaTable( "Player" )

local MetaOBBMins           = MetaEntity.OBBMins
local MetaOBBMaxs           = MetaEntity.OBBMaxs

local MetaToScreen          = MetaVector.ToScreen

local EngineActiveGamemode  = Engine.ActiveGamemode()
local EngineTickInterval    = Engine.TickInterval()
local EntLocalPlayer        = LocalPlayer()
local EntWorldSpawn         = Entity( 0 )
local ScreenWidth           = ScrW()
local ScreenHeight          = ScrH()
local ScreenCenterX         = MathFloor( ScreenWidth / 2 )
local ScreenCenterY         = MathFloor( ScreenHeight / 2 )

local TableEnts             = {}
local TablePlys             = {}
local TableHooks            = {}
local TraceStruct           = { filter = EntLocalPlayer, mask = MASK_SHOT }
local TraceResult           = {}

local function QuickBand( Bits, Mask ) 
    return Band( Bits, Mask ) == Mask  
end

local function TimeToTicks( Time )
	return MathFloor( 0.5 + Time / EngineTickInterval )
end

local function TicksToTime( Ticks )
    return EngineTickInterval * Ticks
end

local function RoundToTick( Time )
    return TicksToTime( TimeToTicks( Time ) )
end

local function AddHook( event, func )
    local UniqueIdentificator = Util.Base64Encode( event ) .. CurrentTime()

    TableHooks[ #TableHooks + 1 ] = { event, UniqueIdentificator }

    HookAdd( event, UniqueIdentificator, func )
end

local function IsKeyDown( Key )
    if Key >= 107 then
        return InputIsMouseDown( Key )
    end

    return InputIsKeyDown( Key )
end

local function WasKeyPressed( Key )
    if Key >= 107 then
        return InputWasMousePressed( Key )
    end

    return InputWasKeyPressed( Key )
end

// Cfg system 

Cat.Cfg = {}

Cat.Cfg.Vars                        = {}

Cat.Cfg.Vars.EnableAimbot           = false 
Cat.Cfg.Vars.DisableOnSpec          = false 

Cat.Cfg.Vars.AutoReload             = false 
Cat.Cfg.Vars.AutoSwitch             = 1

Cat.Cfg.Vars.SilentAim              = true 
Cat.Cfg.Vars.ContextAimbot          = false 

Cat.Cfg.Vars.AutoFire               = false 
Cat.Cfg.Vars.BulletTime             = false 
Cat.Cfg.Vars.WaitForSend            = false 

Cat.Cfg.Vars.RapidFire              = false 
Cat.Cfg.Vars.AltRapidFire           = false 

Cat.Cfg.Vars.Smoothing              = false 
Cat.Cfg.Vars.SmoothAmount           = 1
Cat.Cfg.Vars.SmoothRandomisation    = false 

Cat.Cfg.Vars.LimitFov               = false 
Cat.Cfg.Vars.DynamicFov             = false 
Cat.Cfg.Vars.FovLimit               = 15 

Cat.Cfg.Vars.AccelerativeAim        = false 
Cat.Cfg.Vars.ReleadCooldown         = 0 
Cat.Cfg.Vars.RelockCooldown         = 0

Cat.Cfg.Vars.TriggerBot             = false 
Cat.Cfg.Vars.TriggerDelay           = 0 
Cat.Cfg.Vars.TriggerIgnoreHighSpeed = false 
Cat.Cfg.Vars.TriggerIgnoreJumping   = false 

Cat.Cfg.Vars.PlayerInterpolation    = true 
Cat.Cfg.Vars.SequenceInterpolation  = true 

Cat.Cfg.Vars.ImprovedAnimations     = false 
Cat.Cfg.Vars.ImprovedBoneSetup      = false 

Cat.Cfg.Vars.RecoilCompensation     = false 
Cat.Cfg.Vars.SpreadCompensation     = false 
Cat.Cfg.Vars.AdjustedTickcount      = false 

Cat.Cfg.Vars.AutoStop               = 1

Cat.Cfg.Vars.TargetSelection        = 1 
Cat.Cfg.Vars.MaxTargets             = 10
Cat.Cfg.Vars.LimitAffectedByFPS     = false 

Cat.Cfg.Vars.IgnoreBots             = false 
Cat.Cfg.Vars.IgnoreFriends          = false 
Cat.Cfg.Vars.IgnoreSteamFriends     = false 
Cat.Cfg.Vars.IgnoreTeammates        = false
Cat.Cfg.Vars.IgnoreDriving          = false
Cat.Cfg.Vars.IgnoreGodmode          = false
Cat.Cfg.Vars.IgnoreNoclips          = false
Cat.Cfg.Vars.IgnoreNodraw           = false
Cat.Cfg.Vars.IgnoreFrozen           = false
Cat.Cfg.Vars.IgnoreAdmins           = false
Cat.Cfg.Vars.IgnoreInsaneHealthAmt  = false
Cat.Cfg.Vars.IgnoreBrokenLagComp    = false

Cat.Cfg.Vars.HeadShotOnly           = false

Cat.Cfg.Vars.Extrapolation          = 1 

Cat.Cfg.Vars.TargetBone             = 1 
Cat.Cfg.Vars.WallScan               = false 

Cat.Cfg.Vars.HitScan                = false 

Cat.Cfg.Vars.ScanHead               = false 
Cat.Cfg.Vars.ScanChest              = false 
Cat.Cfg.Vars.ScanStomach            = false 
Cat.Cfg.Vars.ScanLegs               = false 
Cat.Cfg.Vars.ScanArms               = false 

Cat.Cfg.Vars.HitScanSorting         = 1 
Cat.Cfg.Vars.AffectedSorting        = false 

Cat.Cfg.Vars.Multipoints            = false 
Cat.Cfg.Vars.MultipointScale        = 0.8

Cat.Cfg.Vars.HeadMultipoints        = false 
Cat.Cfg.Vars.ChestMultipoints       = false 
Cat.Cfg.Vars.StomachMultipoints     = false 
Cat.Cfg.Vars.LegsMultipoints        = false 
Cat.Cfg.Vars.ArmsMultipoints        = false 

Cat.Cfg.Vars.Prediction             = false 
Cat.Cfg.Vars.PredictionMethod       = 1 
Cat.Cfg.Vars.PredictionMode         = 1 
Cat.Cfg.Vars.SimulationLimit        = 1

Cat.Cfg.Vars.AutoDetonator          = false 

Cat.Cfg.Vars.MeleeBot               = false 
Cat.Cfg.Vars.MeleeMode              = 1 
Cat.Cfg.Vars.FaceStab               = false 
Cat.Cfg.Vars.FollowTarget           = false 

Cat.Cfg.Vars.Backtracking           = false 
Cat.Cfg.Vars.BacktrackMode          = 1

Cat.Cfg.Vars.SamplingInterval       = 1
Cat.Cfg.Vars.BacktrackTime          = 1

Cat.Cfg.Vars.BacktrackHitscan       = false 
Cat.Cfg.Vars.BacktrackMultipoints   = false 

Cat.Cfg.Vars.Backshoot              = false 

Cat.Cfg.Vars.EnableAntiAim          = false 

Cat.Cfg.Vars.YawBase                = 1
Cat.Cfg.Vars.AntiAimYaw             = 1
Cat.Cfg.Vars.AntiAimPitch           = 1
Cat.Cfg.Vars.AntiAimEdge            = 1
Cat.Cfg.Vars.Freestanding           = 1

Cat.Cfg.Vars.InAttackPitch          = false
Cat.Cfg.Vars.YawRandomisation       = false
Cat.Cfg.Vars.Micromovement          = false

Cat.Cfg.Vars.TauntSpam              = false 
Cat.Cfg.Vars.TauntAct               = 1
Cat.Cfg.Vars.HandJob                = false 
Cat.Cfg.Vars.HandJobMode            = 1

Cat.Cfg.Vars.FakeLag                = false
Cat.Cfg.Vars.ChokeLimit             = 1
Cat.Cfg.Vars.RandomMinChoke         = 0
Cat.Cfg.Vars.FakeLagMode            = 1
Cat.Cfg.Vars.ChokeOnPeek            = false 

Cat.Cfg.Vars.FakeWalk               = false 
Cat.Cfg.Vars.FakeFly                = false 
Cat.Cfg.Vars.FakeDuck               = false
Cat.Cfg.Vars.FakeJesus              = false 

Cat.Cfg.Vars.SequenceManipulation   = false 
Cat.Cfg.Vars.OutSequence            = 1000 
Cat.Cfg.Vars.SequenceOnPeek         = false 
Cat.Cfg.Vars.SavePackets            = false 

Cat.Cfg.Vars.TickbaseShift          = false 
Cat.Cfg.Vars.WarpOnPeek             = false 
Cat.Cfg.Vars.DoubleTap              = false 
Cat.Cfg.Vars.AutoRecharge           = false 
Cat.Cfg.Vars.PassiveCharge          = false
Cat.Cfg.Vars.ShiftTicks             = 21 
Cat.Cfg.Vars.FakeLagCompensation    = 1

Cat.Cfg.Vars.TauntResolver          = false 
Cat.Cfg.Vars.PitchResolver          = 1
Cat.Cfg.Vars.YawResolver            = 1

Cat.Cfg.Vars.BunnyHop               = false 
Cat.Cfg.Vars.MaxHops                = 0

Cat.Cfg.Vars.FastWalk               = false 
Cat.Cfg.Vars.WaterWalk              = false 

Cat.Cfg.Vars.AutoStrafe             = false 
Cat.Cfg.Vars.AutoStrafeMode         = 1

Cat.Cfg.Vars.SlowWalk               = false 
Cat.Cfg.Vars.SlowWalkSpeed          = 10 

Cat.Cfg.Vars.SlowMotion             = false 
Cat.Cfg.Vars.SlowMotionMult         = 5 

Cat.Cfg.Vars.AutoParkour            = false 
Cat.Cfg.Vars.EdgeJump               = false 

Cat.Cfg.Vars.FlashlightSpam         = false 
Cat.Cfg.Vars.UseSpam                = false 
Cat.Cfg.Vars.CameraSpam             = false 
Cat.Cfg.Vars.VapeSpam               = false 

Cat.Cfg.Vars.CircleStrafer          = false 
Cat.Cfg.Vars.CircleStraferMode      = 1

Cat.Cfg.Vars.PredictionTicks        = 32 
Cat.Cfg.Vars.MaxGroundDiff          = 16 
Cat.Cfg.Vars.MaxThreads             = 8 
Cat.Cfg.Vars.AngleStep              = 1
Cat.Cfg.Vars.MaxAngleStep           = 16

Cat.Cfg.Vars.SnakeStrafe            = false 
Cat.Cfg.Vars.KeepSprint             = false 

Cat.Cfg.Vars.AutoPeak               = false 
Cat.Cfg.Vars.AutoTeleportBack       = false 
Cat.Cfg.Vars.AiPeak                 = false 

Cat.Cfg.Vars.WalkBot                = false 
Cat.Cfg.Vars.WalkBotMode            = 1
Cat.Cfg.Vars.BlockBot               = false 

Cat.Cfg.Vars.AutoVape               = false 
Cat.Cfg.Vars.FastLockpick           = false 
Cat.Cfg.Vars.AutoGTA                = false 
Cat.Cfg.Vars.PropDriveAnnoyer       = false 

Cat.Cfg.Vars.ChatSpam               = false 
Cat.Cfg.Vars.KillSay                = false 
Cat.Cfg.Vars.DeathSay               = false 

Cat.Cfg.Vars.ChatSpamMode           = 1
Cat.Cfg.Vars.KillSayMode            = 1
Cat.Cfg.Vars.DeathSayMode           = 1 

Cat.Cfg.Vars.AutoResponder          = false 
Cat.Cfg.Vars.AutoRespondMode        = 1
Cat.Cfg.Vars.DelayedRespond         = false 
Cat.Cfg.Vars.SpoofTyping            = false 

Cat.Cfg.Vars.SteamFetcher           = false 
Cat.Cfg.Vars.AutoDox                = false 

Cat.Cfg.Vars.Lagger                 = false 
Cat.Cfg.Vars.LaggerMode             = 1
Cat.Cfg.Vars.LaggerForce            = 10

Cat.Cfg.Vars.CustomName             = ""
Cat.Cfg.Vars.CustomDisconnect       = ""

Cat.Cfg.Vars.NameStealer            = false 
Cat.Cfg.Vars.NameSwitchSpammer      = false 

Cat.Cfg.Vars.BoxEsp                 = true 
Cat.Cfg.Vars.BoxTeamColor           = true 
Cat.Cfg.Vars.BoxStyle               = 1
Cat.Cfg.Vars.BoxGradient            = false

Cat.Cfg.Vars.FilledBox              = false 
Cat.Cfg.Vars.FilledGradient         = false 

Cat.Cfg.Vars.NameEsp                = true 
Cat.Cfg.Vars.HighlightFriends       = true 
Cat.Cfg.Vars.SteamName              = false 
Cat.Cfg.Vars.NamePos                = 1

Cat.Cfg.Vars.AvatarImage            = true 

Cat.Cfg.Vars.UsergroupEsp           = true 
Cat.Cfg.Vars.HighlightAdmins        = false 
Cat.Cfg.Vars.UsergroupPos           = 1

Cat.Cfg.Vars.HealthEsp              = true 
Cat.Cfg.Vars.HealthBar              = true 
Cat.Cfg.Vars.HealthBarGradient      = true 
Cat.Cfg.Vars.HealthBarPos           = 4
Cat.Cfg.Vars.HealthPos              = 4 

Cat.Cfg.Vars.ArmorEsp               = true 
Cat.Cfg.Vars.ArmorBar               = true 
Cat.Cfg.Vars.ArmorBarGradient       = true 
Cat.Cfg.Vars.ArmorBarPos            = 4
Cat.Cfg.Vars.ArmorPos               = 4 

Cat.Cfg.Vars.WeaponEsp              = true 
Cat.Cfg.Vars.WeaponPrintName        = false 
Cat.Cfg.Vars.WeaponIcon             = false 
Cat.Cfg.Vars.WeaponReload           = true 
Cat.Cfg.Vars.ReloadingBar           = true 
Cat.Cfg.Vars.ReloadingGradient      = true 
Cat.Cfg.Vars.WeaponPos              = 2

Cat.Cfg.Vars.TeamEsp                = true 
Cat.Cfg.Vars.TeamPos                = 1

Cat.Cfg.Vars.MoneyEsp               = true 
Cat.Cfg.Vars.MoneyPos               = 1 

Cat.Cfg.Vars.LagcompIndicator       = true 
Cat.Cfg.Vars.PacketIndicator        = true 
Cat.Cfg.Vars.PacketPos              = 3

Cat.Cfg.Vars.TauntFlag              = false 
Cat.Cfg.Vars.NoclipFlag             = true 
Cat.Cfg.Vars.FrozenFlag             = true 
Cat.Cfg.Vars.WantedFlag             = true 
Cat.Cfg.Vars.FlagsPos               = 1

Cat.Cfg.Vars.BacktrackRecords       = false 
Cat.Cfg.Vars.RecordsStyle           = 1

Cat.Cfg.Vars.SkeletonEsp            = true 

Cat.Cfg.Vars.OOFArrows              = false 
Cat.Cfg.Vars.OOFArrowsSize          = 1
Cat.Cfg.Vars.OOFArrowsPadding       = 1
Cat.Cfg.Vars.OOFArrowsHideDormant   = false 
Cat.Cfg.Vars.OOFArrowsShowWeapon    = false 
Cat.Cfg.Vars.OOFArrowsHighlight     = false
Cat.Cfg.Vars.OOFArrowsAvatar        = false
Cat.Cfg.Vars.OOFArrowsStyle         = 1

Cat.Cfg.Vars.SightLines             = true 

Cat.Cfg.Vars.MaxDistance            = 14888888 
Cat.Cfg.Vars.MainFont               = 1

Cat.Cfg.Vars.EntityBox              = false 
Cat.Cfg.Vars.EntityBoxStyle         = false 

Cat.Cfg.Vars.EntityName             = false 
Cat.Cfg.Vars.EntityClass            = false 
Cat.Cfg.Vars.EntityAddInfo          = false 

Cat.Cfg.Vars.EntityMaxDistance      = 2046

Cat.Cfg.Vars.PlayerChams            = false 
Cat.Cfg.Vars.PlayerMaterial         = 1 
Cat.Cfg.Vars.PlayerChamsZ           = false 
Cat.Cfg.Vars.PlayerMaterialZ        = 1
Cat.Cfg.Vars.PlayerWeaponChams      = false 

Cat.Cfg.Vars.EntityChams            = false 
Cat.Cfg.Vars.EntityMaterial         = 1 
Cat.Cfg.Vars.EntityChamsZ           = false 
Cat.Cfg.Vars.EntityMaterialZ        = 1

Cat.Cfg.Vars.LocalPlayerChams       = false 
Cat.Cfg.Vars.LocalPlayerMaterial    = 1 

Cat.Cfg.Vars.HandChams              = false 
Cat.Cfg.Vars.HandMaterial           = 1 
Cat.Cfg.Vars.ViewmodelChams         = false 
Cat.Cfg.Vars.ViewmodelMaterial      = 1 

Cat.Cfg.Vars.FakeModelChams         = false 
Cat.Cfg.Vars.FakeModelMaterial      = 1 
Cat.Cfg.Vars.RealModelChams         = false 
Cat.Cfg.Vars.RealModelMaterial      = 1 

Cat.Cfg.Vars.BacktrackChams         = false 
Cat.Cfg.Vars.BacktrackMaterial      = 1 

Cat.Cfg.Vars.PlayerOutline          = false 
Cat.Cfg.Vars.PlayerOutlineStyle     = 1 

Cat.Cfg.Vars.EntityOutline          = false 
Cat.Cfg.Vars.EntityOutlineStyle     = 1 

Cat.Cfg.Vars.SkyboxMaterial         = "" 
Cat.Cfg.Vars.PaintedOverride        = false 

Cat.Cfg.Vars.SkyboxColored          = false 
Cat.Cfg.Vars.WallsColored           = false 
Cat.Cfg.Vars.PropsColored           = false 

Cat.Cfg.Vars.BulletTracers          = false 
Cat.Cfg.Vars.SpriteMaterial         = "" 
Cat.Cfg.Vars.MuzzleOrigin           = false 
Cat.Cfg.Vars.TracerDieTime          = 5 

Cat.Cfg.Vars.Fullbright             = false 
Cat.Cfg.Vars.FullbrightMode         = 1 

Cat.Cfg.Vars.ViewmodelChanger       = false
Cat.Cfg.Vars.ViewmodelFov           = 65

Cat.Cfg.Vars.FovChanger             = false
Cat.Cfg.Vars.VisualFov              = 65

Cat.Cfg.Vars.AspectRatio            = 1

Cat.Cfg.Vars.Thirdperson            = false
Cat.Cfg.Vars.ThirdpersonCollision   = false
Cat.Cfg.Vars.ThirdpersonSmoothing   = false
Cat.Cfg.Vars.ThirdpersonDistance    = 128
Cat.Cfg.Vars.ThirdpersonSmooth      = 25

Cat.Cfg.Vars.FreeCamera             = false
Cat.Cfg.Vars.FreeCamSpeed           = 10
Cat.Cfg.Vars.FreeCamGhetto          = false

Cat.Cfg.Vars.Indicators             = false
Cat.Cfg.Vars.TickbaseIndicator      = false
Cat.Cfg.Vars.OnScreenLogs           = false
Cat.Cfg.Vars.SpectatorList          = false
Cat.Cfg.Vars.AdminList              = false
Cat.Cfg.Vars.Watermark              = false
Cat.Cfg.Vars.TargetHud              = false

Cat.Cfg.Vars.HideName               = false
Cat.Cfg.Vars.NoSensivityAdj         = false
Cat.Cfg.Vars.ScreengrabImage        = false

Cat.Cfg.Binds   = {}

Cat.Cfg.Colors  = {}

Cat.Cfg.Colors.Box                  = Col( 0, 255, 255 )
Cat.Cfg.Colors.BoxBg                = Col( 0, 0, 0 )
Cat.Cfg.Colors.BoxGr                = Col( 255, 0, 255 )
Cat.Cfg.Colors.BoxFill              = Col( 0, 255, 255, 32 )
Cat.Cfg.Colors.PlayerName           = Col( 255, 255, 255 )
Cat.Cfg.Colors.FriendName           = Col( 0, 255, 0 )
Cat.Cfg.Colors.Usergroup            = Col( 128, 255, 0 )
Cat.Cfg.Colors.AdminHighlight       = Col( 255, 0, 0 )
Cat.Cfg.Colors.Health               = Col( 56, 255, 0 )
Cat.Cfg.Colors.Armor                = Col( 0, 56, 255 )
Cat.Cfg.Colors.Weapon               = Col( 255, 255, 128 )               
Cat.Cfg.Colors.BrokenLC             = Col( 255, 16, 16 )  
Cat.Cfg.Colors.PacketSent           = Col( 173, 255, 47 )  
Cat.Cfg.Colors.Skeleton             = Col( 255, 255, 255 )
Cat.Cfg.Colors.HealthBarBg          = Col( 0, 0, 0 )
Cat.Cfg.Colors.HealthBar            = Col( 72, 255, 72 )
Cat.Cfg.Colors.HealthBarGr          = Col( 255, 72, 72 )
Cat.Cfg.Colors.ArmorBarBg           = Col( 0, 0, 0 )
Cat.Cfg.Colors.ArmorBar             = Col( 72, 72, 255 )
Cat.Cfg.Colors.ArmorBarGr           = Col( 72, 255, 72 )
Cat.Cfg.Colors.ReloadingBarBg       = Col( 0, 0, 0 )
Cat.Cfg.Colors.ReloadingBar         = Col( 255, 128, 72 )
Cat.Cfg.Colors.ReloadingBarGr       = Col( 255, 72, 128 )

Cat.Cfg.Friends = {}
Cat.Cfg.EntList = {}

// Cache 

Cat.FrameTime       = 0
Cat.CurrentTime     = 0

Cat.Colors  = {}

Cat.Colors.White    = Col( 255, 255, 255 )
Cat.Colors.Money    = Col( 133, 187, 101 ) // https://rgbcolorcode.com/color/dollar-bill
Cat.Colors.Ice      = Col( 115, 155, 208 )
Cat.Colors.Arrest   = Col( 255, 0, 51 )

Cat.Materials   = {}

Cat.Materials.GradientV = Mat( "vgui/gradient-d" )
Cat.Materials.GradientH = Mat( "vgui/gradient-l" )

// Player data caching 

Cat.InitiallyCached = {}
Cat.Recachable      = {}

Cat.LastRecache     = CurrentTime()

function Cat.CachePlayerData( Ply )   
    Cat.InitiallyCached[ Ply ] = {} 

    Cat.InitiallyCached[ Ply ].SteamID      = Ply:SteamID()
    Cat.InitiallyCached[ Ply ].SteamID64    = Ply:SteamID64()
    Cat.InitiallyCached[ Ply ].EntIndex     = Ply:EntIndex()
    Cat.InitiallyCached[ Ply ].UserID       = Ply:UserID()
    Cat.InitiallyCached[ Ply ].IsBot        = Ply:IsBot()

    Cat.InitiallyCached[ Ply ].AvatarImage  = vgui.Create( "AvatarImage" )
    Cat.InitiallyCached[ Ply ].AvatarImage:SetSize( 12, 12 )
	Cat.InitiallyCached[ Ply ].AvatarImage:SetPlayer( Ply, 32 )
    Cat.InitiallyCached[ Ply ].AvatarImage:SetPaintedManually( true )

    if Ply:IsBot() then
        Cat.InitiallyCached[ Ply ].RealName = Ply:Name()
    else
        Steam.RequestPlayerInfo( Cat.InitiallyCached[ Ply ].SteamID64, function( steamName )
            Cat.InitiallyCached[ Ply ].RealName = steamName
        end )
    end
end

function Cat.UpdatePlayerVars( Ply )
    TablePlys[ #TablePlys ].Ent         = Ply 

    TablePlys[ #TablePlys ].Health      = Ply:Health()
    TablePlys[ #TablePlys ].Armor       = Ply:Armor()
    TablePlys[ #TablePlys ].MaxHealth   = Ply:GetMaxHealth()
    TablePlys[ #TablePlys ].MaxArmor    = Ply:GetMaxArmor()

    TablePlys[ #TablePlys ].Origin      = Ply:GetPos()
    TablePlys[ #TablePlys ].NetOrigin   = Ply:GetNetworkOrigin()

    TablePlys[ #TablePlys ].OBBCenter   = Ply:OBBCenter()
    TablePlys[ #TablePlys ].OBBMaxs     = Ply:OBBMaxs()
    TablePlys[ #TablePlys ].OBBMins     = Ply:OBBMins()

    TablePlys[ #TablePlys ].Angle       = Ply:GetAngles()
    TablePlys[ #TablePlys ].EyeAngles   = Ply:EyeAngles()
    TablePlys[ #TablePlys ].NetAngles   = Ply:GetNetworkAngles()

    TablePlys[ #TablePlys ].Flags       = Ply:GetFlags()
    TablePlys[ #TablePlys ].EngineFlags = Ply:GetEFlags()
    TablePlys[ #TablePlys ].Effects     = Ply:GetEffects()
    TablePlys[ #TablePlys ].MoveType    = Ply:GetMoveType()

    TablePlys[ #TablePlys ].Alive       = Ply:Alive()
    TablePlys[ #TablePlys ].IsDormant   = Ply:IsDormant()

    TablePlys[ #TablePlys ].SimTime     = ded.GetSimulationTime( Cat.InitiallyCached[ Ply ].EntIndex )
    
    Ply.StartedReloading = Ply.StartedReloading or 0
    Ply.PrevSimTime = Ply.PrevSimTime or 0
    Ply.Choked = Ply.Choked or 0
    Ply.BreakingLC = Ply.BreakingLC or false
    Ply.PrevOrigin  = Ply.PrevOrigin or TablePlys[ #TablePlys ].NetOrigin
    
    TablePlys[ #TablePlys ].PacketSent  = false 
    TablePlys[ #TablePlys ].BreakingLC  = false

    if Ply.PrevSimTime != TablePlys[ #TablePlys ].SimTime then
        Ply.BreakingLC = Ply.PrevOrigin:DistToSqr( TablePlys[ #TablePlys ].NetOrigin ) > 4096

        TablePlys[ #TablePlys ].PacketSent = true

        Ply.Choked = TimeToTicks( TablePlys[ #TablePlys ].SimTime - Ply.PrevSimTime )
        Ply.PrevOrigin  = TablePlys[ #TablePlys ].NetOrigin
        Ply.PrevSimTime = TablePlys[ #TablePlys ].SimTime
    end
    
    TablePlys[ #TablePlys ].BreakingLC = Ply.BreakingLC 
    TablePlys[ #TablePlys ].ChokedPackets = Ply.Choked

    local w = Ply:GetActiveWeapon()

    TablePlys[ #TablePlys ].Weapon      = ValidCheck( w ) and w or false 
    TablePlys[ #TablePlys ].WeaponClass = TablePlys[ #TablePlys ].Weapon and w:GetClass() or "Unarmed"
    TablePlys[ #TablePlys ].WeaponName  = TablePlys[ #TablePlys ].Weapon and language.GetPhrase( w:GetPrintName() ) or "Unarmed"
end

function Cat.RecachePlayerData( Ply )
    if not Cat.Recachable[ Ply ] then
        Cat.Recachable[ Ply ] = {} 
    end

    Cat.Recachable[ Ply ].Team        = Ply:Team()
    Cat.Recachable[ Ply ].TeamColor   = TeamLib.GetColor( Cat.Recachable[ Ply ].Team )
    Cat.Recachable[ Ply ].TeamName    = TeamLib.GetName( Cat.Recachable[ Ply ].Team )

    if MetaPlayer.getDarkRPVar then
        Cat.Recachable[ Ply ].Money   = DarkRP.formatMoney( Ply:getDarkRPVar("money") ) or "beggar"
        Cat.Recachable[ Ply ].Wanted  = Ply:getDarkRPVar("wanted")
    end

    Cat.Recachable[ Ply ].Name        = Ply:Name()
    Cat.Recachable[ Ply ].UserGroup   = Ply:GetNWString( "UserGroup", "user" )
    Cat.Recachable[ Ply ].SteamFriend = Ply:GetFriendStatus() == "friend" 
    Cat.Recachable[ Ply ].IsAdmin     = Ply:IsAdmin()

    Cat.Recachable[ Ply ].Model       = Ply:GetModel()

    Cat.Recachable[ Ply ].DormantFade = 0
end

// 2D Visuals
Surface.CreateFont( "Veranda", { font = "Verdana", size = 12, antialias = false, outline = true } )

Cat.DrawData        = {}

Cat.DrawData.Vis    = false

Cat.DrawData.MaxX   = 0 
Cat.DrawData.MaxY   = 0 
Cat.DrawData.MinX   = 0 
Cat.DrawData.MinY   = 0 
Cat.DrawData.Width  = 0 
Cat.DrawData.Height = 0
Cat.DrawData.TextX  = 0
Cat.DrawData.TextY  = 0

Cat.DrawData.DrawnText  = {}
Cat.DrawData.StartPoses = {}

Cat.DrawData.BarPoses   = {}
Cat.DrawData.BarPadding = {}

Cat.CachedTextSize  = {}

Cat.BarPadding = { { x = 0, y = -5 }, { x = 0, y = 5 }, { x = 5, y = 0 }, { x = -5, y = 0 } }

function Cat.GetEntityBounds( Ent )
    local Pos   = Ent:GetPos()

    local Maxs  = MetaOBBMaxs( Ent )
    local Mins  = MetaOBBMins( Ent )

    local Bounds = {
        MetaToScreen( Pos + Vec( Maxs.x, Maxs.y, Maxs.z ) ),
        MetaToScreen( Pos + Vec( Maxs.x, Maxs.y, Mins.z ) ),
        MetaToScreen( Pos + Vec( Maxs.x, Mins.y, Mins.z ) ),
        MetaToScreen( Pos + Vec( Maxs.x, Mins.y, Maxs.z ) ),
        MetaToScreen( Pos + Vec( Mins.x, Mins.y, Mins.z ) ),
        MetaToScreen( Pos + Vec( Mins.x, Mins.y, Maxs.z ) ),
        MetaToScreen( Pos + Vec( Mins.x, Maxs.y, Mins.z ) ),
        MetaToScreen( Pos + Vec( Mins.x, Maxs.y, Maxs.z ) ),
    }

    local MaxX, MaxY, MinX, MinY 
    local Vis = false 

    for i = 1, #Bounds do
        local ScreenPoint = Bounds[ i ]
        Vis = ScreenPoint.visible

        if MaxX == nil then
            MaxX = ScreenPoint.x 
            MaxY = ScreenPoint.y
            MinX = ScreenPoint.x
            MinY = ScreenPoint.y

            continue 
        end

        MaxX = MathMax( MaxX, ScreenPoint.x ) 
        MaxY = MathMax( MaxY, ScreenPoint.y ) 
        MinX = MathMin( MinX, ScreenPoint.x )
        MinY = MathMin( MinY, ScreenPoint.y )
    end

    return MathCeil( MaxX ), MathCeil( MaxY ), MathFloor( MinX ), MathFloor( MinY ), Vis
end

function Cat.GetTextX( TextWidth, Pos )
    if Pos < 3 then
        return TextWidth / 2 
    elseif Pos == 4 then 
        return TextWidth - Cat.DrawData.BarPadding[ Pos ].x 
    end

    return Cat.DrawData.BarPadding[ Pos ].x 
end

function Cat.GetTextY( TextHeight, Pos )
    if Pos == 1 then
        return Cat.DrawData.MinY + Cat.DrawData.BarPadding[ Pos ].y - TextHeight - 2 - TextHeight * Cat.DrawData.DrawnText[ Pos ]
    elseif Pos == 2 then
        return Cat.DrawData.MaxY + Cat.DrawData.BarPadding[ Pos ].y + TextHeight * Cat.DrawData.DrawnText[ Pos ] 
    end

    return Cat.DrawData.MinY + TextHeight * Cat.DrawData.DrawnText[ Pos ]
end

function Cat.GetTextSize( String )
    if Cat.CachedTextSize[ String ] then
        return Cat.CachedTextSize[ String ].x, Cat.CachedTextSize[ String ].y
    end

    local TextW, TextH = GetTextDrawSize( String )
    Cat.CachedTextSize[ String ] = {
        x = TextW,
        y = TextH - 2
    }

    return Cat.CachedTextSize[ String ].x, Cat.CachedTextSize[ String ].y
end

function Cat.DrawEspText( String, Pos )
    if not IsString( String ) then String = ToString( String ) end
    local TextWidth, TextHeight = Cat.GetTextSize( String )

    Cat.DrawData.TextX = Cat.DrawData.StartPoses[ Pos ] - Cat.GetTextX( TextWidth, Pos )
    Cat.DrawData.TextY = Cat.GetTextY( TextHeight, Pos )

    SetTextPos( Cat.DrawData.TextX, Cat.DrawData.TextY )
    DrawText( String )

    Cat.DrawData.DrawnText[ Pos ] = Cat.DrawData.DrawnText[ Pos ] + 1
end

function Cat.EspText( Conditions, Text, TextPos, TextColor )
    if not Conditions then return end 
        
    SetTextDrawColor( TextColor )  
    Cat.DrawEspText( Text, TextPos )
end

function Cat.DrawBar( Pos, Current, Max, BarColor, BackColor, Gradient, GradientColor )
    local BarX, BarY = Cat.DrawData.BarPoses[ Pos ].x + Cat.DrawData.BarPadding[ Pos ].x, Cat.DrawData.BarPoses[ Pos ].y + Cat.DrawData.BarPadding[ Pos ].y
    local BarW, BarH = Cat.DrawData.Width, 4
    local FillW, FillH = MathCeil( Current / Max * BarW ), BarH

    if Pos > 2 then
        BarW, BarH = 4, Cat.DrawData.Height 
        FillW, FillH = BarW, MathCeil( Current / Max * BarH )
    end

    SetDrawColor( BackColor )
    DrawRect( BarX, BarY, BarW, BarH )

    BarX, BarY = BarX + 1, BarY + 1

    if Pos > 2 then
        BarY = BarY + BarH - FillH
    end

    BarW, BarH = BarW - 2, BarH - 2
    FillW, FillH = FillW - 2, FillH - 2
    
    SetDrawColor( BarColor )
    DrawRect( BarX, BarY, FillW, FillH )

    if Gradient then
        SetDrawColor( GradientColor )
        SetDrawMaterial( Pos > 2 and Cat.Materials.GradientV or Cat.Materials.GradientH )
        TexturedRect( BarX, BarY, FillW, FillH )
    end

    Cat.DrawData.BarPadding[ Pos ].x = Cat.DrawData.BarPadding[ Pos ].x + Cat.BarPadding[ Pos ].x 
    Cat.DrawData.BarPadding[ Pos ].y = Cat.DrawData.BarPadding[ Pos ].y + Cat.BarPadding[ Pos ].y
end

function Cat.DrawPlayerVisuals()
    if #TablePlys == 0 then return end 

    local MaxPlayerDistance = Cat.Cfg.Vars.MaxDistance
    local MaxEntityDistance = Cat.Cfg.Vars.EntityMaxDistance

    MaxPlayerDistance = MaxPlayerDistance * MaxPlayerDistance
    MaxEntityDistance = MaxEntityDistance * MaxEntityDistance

    local LocalPlayerPos = TablePlys[ 1 ].Origin

    local CachedVars, UpdatedVars, Recaching 

    SetTextFont( "Veranda" )

    local BarPos 
    local BarX, BarY
    local BarW, BarH 
    local FillW, FillH 
    local SequenceID = 1
    local Reloading = false

    for i = 2, #TablePlys do
        UpdatedVars = TablePlys[ i ]
        CachedVars  = Cat.InitiallyCached[ UpdatedVars.Ent ]
        Recaching   = Cat.Recachable[ UpdatedVars.Ent ]

        SetAlphaMultiplier( UpdatedVars.IsDormant and 0.35 or 1 )

        if not UpdatedVars.Alive then continue end

        Cat.DrawData.MaxX, Cat.DrawData.MaxY, Cat.DrawData.MinX, Cat.DrawData.MinY, Cat.DrawData.Vis = Cat.GetEntityBounds( UpdatedVars.Ent )

        if not Cat.DrawData.Vis then continue end
        if LocalPlayerPos:DistToSqr( UpdatedVars.Origin ) > MaxPlayerDistance then continue end

        Cat.DrawData.Width  = MathFloor( Cat.DrawData.MaxX - Cat.DrawData.MinX )
        Cat.DrawData.Height = MathFloor( Cat.DrawData.MaxY - Cat.DrawData.MinY )
        
        Cat.DrawData.DrawnText  = { 0, 0, 0, 0 }
        Cat.DrawData.BarPadding = { { x = 0, y = 0 }, { x = 0, y = 0 }, { x = 0, y = 0 }, { x = 0, y = 0 } }

        Cat.DrawData.StartPoses = { 
            Cat.DrawData.MinX + Cat.DrawData.Width / 2, 
            Cat.DrawData.MinX + Cat.DrawData.Width / 2, 
            Cat.DrawData.MaxX + 5, 
            Cat.DrawData.MinX - 5 
        }

        Cat.DrawData.BarPoses = {
            { x = Cat.DrawData.MinX, y = Cat.DrawData.MinY - 6 },
            { x = Cat.DrawData.MinX, y = Cat.DrawData.MaxY + 1 }, 
            { x = Cat.DrawData.MaxX + 1, y = Cat.DrawData.MinY }, 
            { x = Cat.DrawData.MinX - 6, y = Cat.DrawData.MinY }
        }

        if Cat.Cfg.Vars.SightLines then 
            local EyeTrace = UpdatedVars.Ent:GetEyeTrace()
            local StartPos, HitPos = EyeTrace.StartPos:ToScreen(), EyeTrace.HitPos:ToScreen()

            SetDrawColor( Recaching.TeamColor )
            DrawLine( StartPos.x, StartPos.y, HitPos.x, HitPos.y )
        end
           
        if Cat.Cfg.Vars.SkeletonEsp then
            SetDrawColor( Cat.Cfg.Colors.Skeleton )

		    for BoneId = 0, UpdatedVars.Ent:GetBoneCount() - 1 do
			    local Parent = UpdatedVars.Ent:GetBoneParent( BoneId )
			    if not Parent then continue end

			    local ChildPos = UpdatedVars.Ent:GetBonePosition( BoneId )
			    if ChildPos == UpdatedVars.Ent:GetPos() then continue end

			    local ParentPos = UpdatedVars.Ent:GetBonePosition( Parent )
			    if not ChildPos or not ParentPos then continue end

			    local ChildScreenPos    = MetaToScreen( ChildPos )
                local ParentScreenPos   = MetaToScreen( ParentPos )

			    DrawLine( ChildScreenPos.x, ChildScreenPos.y, ParentScreenPos.x, ParentScreenPos.y )
		    end
        end

        SetDrawMaterial( Cat.Materials.GradientV )

        if Cat.Cfg.Vars.FilledBox then
            SetDrawColor( Cat.Cfg.Colors.BoxFill )  

            if Cat.Cfg.Vars.FilledGradient then
                TexturedRect( Cat.DrawData.MinX, Cat.DrawData.MinY, Cat.DrawData.Width, Cat.DrawData.Height )
            else
                DrawRect( Cat.DrawData.MinX, Cat.DrawData.MaxY, Cat.DrawData.Width, Cat.DrawData.Height )
            end
        end

        if Cat.Cfg.Vars.BoxEsp then 
            SetDrawColor( Cat.Cfg.Colors.BoxBg )
            OutlinedRect( Cat.DrawData.MinX, Cat.DrawData.MinY, Cat.DrawData.Width, Cat.DrawData.Height, 3 )
        
            SetDrawColor( Cat.Cfg.Vars.BoxTeamColor and Recaching.TeamColor or Cat.Cfg.Colors.Box )
            OutlinedRect( Cat.DrawData.MinX + 1, Cat.DrawData.MinY + 1, Cat.DrawData.Width - 2, Cat.DrawData.Height - 2 )
        
            if Cat.Cfg.Vars.BoxGradient then
                SetDrawColor( Cat.Cfg.Colors.BoxGr ) 

                TexturedRect( Cat.DrawData.MinX + 1, Cat.DrawData.MinY, 1, Cat.DrawData.Height - 1 )
                TexturedRect( Cat.DrawData.MaxX - 2, Cat.DrawData.MinY, 1, Cat.DrawData.Height - 1 )
                DrawRect( Cat.DrawData.MinX + 1, Cat.DrawData.MaxY - 2, Cat.DrawData.Width - 2, 1 )
            end
        end 

        if Cat.Cfg.Vars.HealthBar then
            Cat.DrawBar( Cat.Cfg.Vars.HealthBarPos, UpdatedVars.Health, UpdatedVars.MaxHealth, Cat.Cfg.Colors.HealthBar, Cat.Cfg.Colors.HealthBarBg, Cat.Cfg.Vars.HealthBarGradient, Cat.Cfg.Colors.HealthBarGr )
        end

        if Cat.Cfg.Vars.ArmorBar and UpdatedVars.Armor > 0 then
            Cat.DrawBar( Cat.Cfg.Vars.ArmorBarPos, UpdatedVars.Armor, UpdatedVars.MaxArmor, Cat.Cfg.Colors.ArmorBar, Cat.Cfg.Colors.ArmorBarBg, Cat.Cfg.Vars.ArmorBarGradient, Cat.Cfg.Colors.ArmorBarGr )
        end

        if Cat.Cfg.Vars.WeaponReload then
            for Layer = 0, 13 do
                if not UpdatedVars.Ent:IsValidLayer( Layer ) then continue end 
                SequenceID = UpdatedVars.Ent:GetLayerSequence( Layer ) 
                if not UpdatedVars.Ent:GetSequenceActivityName( SequenceID ):find( "RELOAD" ) then continue end 
                      
                if UpdatedVars.Ent.StartedReloading == 0 then
                    UpdatedVars.Ent.StartedReloading = Cat.CurrentTime
                end

                Reloading = true 
                break
            end

            if not Reloading and UpdatedVars.Ent.StartedReloading > 0 then
                UpdatedVars.Ent.StartedReloading = 0
            end
        end
        
        if UpdatedVars.Ent.StartedReloading > 0 and Cat.Cfg.Vars.ReloadingBar then
            Cat.DrawBar( 2, ( Cat.CurrentTime - UpdatedVars.Ent.StartedReloading ), UpdatedVars.Ent:SequenceDuration( SequenceID ), Cat.Cfg.Colors.ReloadingBar, Cat.Cfg.Colors.ReloadingBarBg, Cat.Cfg.Vars.ReloadingGradient, Cat.Cfg.Colors.ReloadingBarGr )
        end 

        SetTextDrawColor( Cat.Colors.White )
           
        Cat.EspText( Cat.Cfg.Vars.NameEsp, Cat.Cfg.Vars.SteamName and CachedVars.RealName or Recaching.Name, Cat.Cfg.Vars.NamePos, Recaching.SteamFriend and Cat.Cfg.Colors.FriendName or Cat.Cfg.Colors.PlayerName )

        if Cat.Cfg.Vars.AvatarImage then
            CachedVars.AvatarImage:SetPos( Cat.DrawData.TextX - 14, Cat.DrawData.TextY + 1 )
            CachedVars.AvatarImage:PaintManual()
        end
   
        Cat.EspText( Cat.Cfg.Vars.UsergroupEsp, Recaching.UserGroup, Cat.Cfg.Vars.UsergroupPos, ( Recaching.IsAdmin and Cat.Cfg.Vars.HighlightAdmins ) and Cat.Cfg.Colors.AdminHighlight or Cat.Cfg.Colors.Usergroup )
        Cat.EspText( Cat.Cfg.Vars.HealthEsp, UpdatedVars.Health, Cat.Cfg.Vars.HealthPos, Cat.Cfg.Colors.Health )
        Cat.EspText( Cat.Cfg.Vars.ArmorEsp, UpdatedVars.Armor, Cat.Cfg.Vars.ArmorPos, Cat.Cfg.Colors.Armor )
        Cat.EspText( Cat.Cfg.Vars.WeaponEsp, Cat.Cfg.Vars.WeaponPrintName and UpdatedVars.WeaponName or UpdatedVars.WeaponClass, Cat.Cfg.Vars.WeaponPos, Cat.Cfg.Colors.Weapon )
        Cat.EspText( Reloading, "RELOADING!", Cat.Cfg.Vars.WeaponPos, Cat.Cfg.Colors.Weapon )
        Cat.EspText( Cat.Cfg.Vars.TeamEsp, Recaching.TeamName, Cat.Cfg.Vars.TeamPos, Recaching.TeamColor )
        Cat.EspText( Cat.Cfg.Vars.MoneyEsp and Recaching.Money, Recaching.Money, Cat.Cfg.Vars.MoneyPos, Cat.Colors.Money )
        Cat.EspText( Cat.Cfg.Vars.LagcompIndicator, "LAGCOMP", Cat.Cfg.Vars.PacketPos, UpdatedVars.BreakingLC and Cat.Cfg.Colors.BrokenLC or Cat.Cfg.Colors.PacketSent )
        Cat.EspText( Cat.Cfg.Vars.PacketIndicator, UpdatedVars.PacketSent and "Packet sent" or "Laggin " .. UpdatedVars.ChokedPackets, Cat.Cfg.Vars.PacketPos, UpdatedVars.PacketSent and Cat.Cfg.Colors.PacketSent or Cat.Cfg.Colors.BrokenLC )
        Cat.EspText( Cat.Cfg.Vars.TauntFlag and UpdatedVars.Ent:IsPlayingTaunt(), "Taunting", Cat.Cfg.Vars.FlagsPos, Cat.Colors.White )
        Cat.EspText( Cat.Cfg.Vars.NoclipFlag and UpdatedVars.MoveType == MOVETYPE_NOCLIP, "NOCLIP", Cat.Cfg.Vars.FlagsPos, Cat.Colors.White )
        Cat.EspText( Cat.Cfg.Vars.FrozenFlag and QuickBand( UpdatedVars.Flags, FL_FROZEN ), "FROZEN", Cat.Cfg.Vars.FlagsPos, Cat.Colors.Ice )
        Cat.EspText( Cat.Cfg.Vars.WantedFlag and Recaching.Wanted, "WANTED", Cat.Cfg.Vars.FlagsPos, Cat.Colors.Arrest )
    end

    CachedVars, UpdatedVars, Recaching = nil, nil, nil 

    SetAlphaMultiplier( 1 )
end

// 






function Cat.CreateMoveHook( cmd )

end



// Think 

function Cat.ThinkHook()
    Cat.CurrentTime = CurrentTime()
    Cat.FrameTime = RenderTime()

end



// Frame stage hook 






ded.SetInterpolation( false )
ded.SetSequenceInterpolation( false )

Cat.FrameStages = {}

Cat.FrameStages[ 3 ] = function()
    local Entities = EntsGetAll()
    local CT = CurrentTime()
    local Ent 
    
    for i = 1, #TablePlys do TablePlys[ i ] = nil end
    for i = 1, #TableEnts do TableEnts[ i ] = nil end

    TablePlys[ 1 ] = {}

    if not Cat.InitiallyCached[ EntLocalPlayer ] then
        Cat.CachePlayerData( EntLocalPlayer )
        Cat.RecachePlayerData( EntLocalPlayer ) 
    end
    
    Cat.UpdatePlayerVars( EntLocalPlayer )

    if CT - Cat.LastRecache > 1 then 
        Cat.RecachePlayerData( EntLocalPlayer ) 
    end

    for i = 2, #Entities do
        Ent = Entities[ i ]
        TableEnts[ #TableEnts + 1 ] = Ent

        if not Ent:IsPlayer() or Ent == EntLocalPlayer then continue end 

        TablePlys[ #TablePlys + 1 ] = {}
        if not Cat.InitiallyCached[ Ent ] then 
            Cat.CachePlayerData( Ent ) 
            Cat.RecachePlayerData( Ent )
        end

        Cat.UpdatePlayerVars( Ent )

        if CT - Cat.LastRecache > 1 then
            Cat.RecachePlayerData( Ent )
        end
    end

    if CT - Cat.LastRecache > 1 then 
        Cat.LastRecache = CT + 1
    end

    Entities = nil 
end

function Cat.FrameStageHook( stage )
    if Cat.FrameStages[ stage ] then
        Cat.FrameStages[ stage ]()
    end
end

HookAdd( "PostFrameStageNotify", "Cat", Cat.FrameStageHook )
HookAdd( "HUDPaint", "Cat", Cat.DrawPlayerVisuals )
HookAdd( "Think", "Cat", Cat.ThinkHook )
HookAdd( "CreateMove", "Cat", Cat.CreateMoveHook )

end


jiggabooware.ttable = {}

jiggabooware.ttable["Aimbot"]   = jiggabooware.tabs.Aimbot
jiggabooware.ttable["Rage"]     = jiggabooware.tabs.Rage
jiggabooware.ttable["Visuals"]  = jiggabooware.tabs.Visuals
jiggabooware.ttable["Misc"]     = jiggabooware.tabs.Misc
jiggabooware.ttable["Settings"] = jiggabooware.tabs.Settings
jiggabooware.ttable["Players"]  = jiggabooware.tabs.Players
jiggabooware.ttable["gRust"]  = jiggabooware.tabs.gRust
jiggabooware.ttable["Credits"]  = jiggabooware.tabs.Credits
jiggabooware.ttable["Scripts"]  = jiggabooware.tabs.Scripts

function jiggabooware.initTab(tab)
    if jiggabooware.scrollpanel != nil then jiggabooware.scrollpanel:Remove() end

    jiggabooware.scrollpanel = vgui_Create("UScroll",jiggabooware.frame)

    jiggabooware.pty = { 5, 5, 5 }
    // jiggabooware.ESPPP:Hide()
    jiggabooware.ttable[tostring(tab)]()
end

function jiggabooware.tabButton(tab,par) 
    surface_SetFont("tbfont")
    local w, h = surface_GetTextSize(tab)

    local fw = w + 35

    local tx, ty = fw/2 - w/2, 25/2-h/2 - 1

    local b = par:Add("DButton")
    b:Dock(LEFT)
    b:DockMargin(2,0,2,1)
    b:SetWide(fw)
    b:SetText("")
    
    function b:DoClick()
        jiggabooware.activetab = tab
        jiggabooware.initTab(tab)
    end

    function b:Paint(width,height)
        if jiggabooware.activetab == tab or self:OnDepressed() then
            surface_SetDrawColor(jiggabooware.Colors[54])
            surface_SetTextColor(245,245,245,255)
        elseif self:IsHovered() then
            surface_SetDrawColor(jiggabooware.Colors[40])
            surface_SetTextColor(225,225,225,255)
        else
            surface_SetDrawColor(jiggabooware.Colors[30])
            surface_SetTextColor(200,200,200,255)
        end
        
        surface_DrawRect(0,0,width,height)

        surface_SetFont("tbfont")
        surface_SetTextPos(tx,ty)
        surface_DrawText(tab)
    end
end

jiggabooware.tabButton( "Aimbot",        jiggabooware.frame:GetTopPanel() ) 
jiggabooware.tabButton( "Rage",          jiggabooware.frame:GetTopPanel() ) 
jiggabooware.tabButton( "Visuals",       jiggabooware.frame:GetTopPanel() ) 
jiggabooware.tabButton( "Misc",          jiggabooware.frame:GetTopPanel() ) 
jiggabooware.tabButton( "Settings",      jiggabooware.frame:GetTopPanel() ) 
jiggabooware.tabButton( "Players",       jiggabooware.frame:GetTopPanel() ) 
jiggabooware.tabButton( "gRust",       jiggabooware.frame:GetTopPanel() ) 
jiggabooware.tabButton( "Credits",       jiggabooware.frame:GetTopPanel() ) 
jiggabooware.tabButton( "Scripts",       jiggabooware.frame:GetTopPanel() ) 

jiggabooware.ttable["Aimbot"]()

// Input 

function jiggabooware.IsKeyDown( key )
    if key >= 107 then
        return input_IsMouseDown( key )
    end

    return input_IsKeyDown( key )
end

/*
    Create Move start
*/

// cm stuff

jiggabooware.target             = false  
jiggabooware.aimingrn           = false 

jiggabooware.targetVector       = Vector()
jiggabooware.predictedVector    = Vector()
jiggabooware.backtrackVector    = Vector()
jiggabooware.nullVec            = Vector() * -1

jiggabooware.SilentAngle        = me:EyeAngles()

jiggabooware.SkipCommand        = false
jiggabooware.SendPacket         = true

jiggabooware.traceStruct        = { mask = MASK_SHOT, filter = me }
jiggabooware.badSweps           = { ["gmod_camera"] = true, ["manhack_welder"] = true, ["weapon_medkit"] = true, ["gmod_tool"] = true, ["weapon_physgun"] = true, ["weapon_physcannon"] = true, ["weapon_bugbait"] = true, }
jiggabooware.badSeqs            = { [ACT_VM_RELOAD] = true, [ACT_VM_RELOAD_SILENCED] = true, [ACT_VM_RELOAD_DEPLOYED] = true, [ACT_VM_RELOAD_IDLE] = true, [ACT_VM_RELOAD_EMPTY] = true, [ACT_VM_RELOADEMPTY] = true, [ACT_VM_RELOAD_M203] = true, [ACT_VM_RELOAD_INSERT] = true, [ACT_VM_RELOAD_INSERT_PULL] = true, [ACT_VM_RELOAD_END] = true, [ACT_VM_RELOAD_END_EMPTY] = true, [ACT_VM_RELOAD_INSERT_EMPTY] = true, [ACT_VM_RELOAD2] = true }
jiggabooware.cones              = {}
jiggabooware.parsedbones        = {}

jiggabooware.swbNormal          = bor(CONTENTS_SOLID, CONTENTS_OPAQUE, CONTENTS_MOVEABLE, CONTENTS_DEBRIS, CONTENTS_MONSTER, CONTENTS_HITBOX, 402653442, CONTENTS_WATER)
jiggabooware.swbWall            = bor(CONTENTS_TESTFOGVOLUME, CONTENTS_EMPTY, CONTENTS_MONSTER, CONTENTS_HITBOX)
jiggabooware.swbPen             = {[MAT_SAND] = 0.5, [MAT_DIRT] = 0.8, [MAT_METAL] = 1.1, [MAT_TILE] = 0.9, [MAT_WOOD] = 1.2}
jiggabooware.swbShit            = { ["swb_knife"] = true, ["swb_knife_m"] = true }

jiggabooware.m9kPenetration     = { ["SniperPenetratedRound"] = 20, ["pistol"] = 9, ["357"] = 12, ["smg1"] = 14, ["ar2"] = 16, ["buckshot"] = 5, ["slam"] = 5, ["AirboatGun"] = 17, }
jiggabooware.m9kMaxRicochet     = { ["SniperPenetratedRound"] = 10, ["pistol"] = 2, ["357"] = 5, ["smg1"] = 4, ["ar2"] = 5, ["buckshot"] = 0, ["slam"] = 0, ["AirboatGun"] = 9, }
jiggabooware.m9kCanRicochet     = { ["SniperPenetratedRound"] = true, ["pistol"] = true, ["buckshot"] = true, ["slam"] = true }
jiggabooware.m9kPenMaterial     = { [MAT_GLASS] = true, [MAT_PLASTIC] = true, [MAT_WOOD] = true, [MAT_FLESH] = true, [MAT_ALIENFLESH] = true }

jiggabooware.activeWeapon       = false 
jiggabooware.activeWeaponClass  = false 
jiggabooware.moveType           = me:GetMoveType() 

jiggabooware.myaw               = GetConVar("m_yaw"):GetFloat()

jiggabooware.backtracktick      = 0










function jiggabooware.AutoWall( dir, plyTarget )
	if not jiggabooware.activeWeapon or jiggabooware.swbShit[ jiggabooware.activeWeaponClass ] then return false end 

	local eyePos = me:EyePos()
	
	local function SWBAutowall()

        jiggabooware.traceStruct.start = eyePos
        jiggabooware.traceStruct.endpos = eyePos + dir * jiggabooware.activeWeapon.PenetrativeRange
        jiggabooware.traceStruct.filter = me
        jiggabooware.traceStruct.mask = jiggabooware.swbNormal

		local tr = TraceLine( jiggabooware.traceStruct )
		
		if tr.Hit and !tr.HitSky then
			local dot = -dir:Dot(tr.HitNormal)
			
			if jiggabooware.activeWeapon.CanPenetrate and dot > 0.26 then

                jiggabooware.traceStruct.start = tr.HitPos
                jiggabooware.traceStruct.endpos = tr.HitPos + dir * jiggabooware.activeWeapon.PenStr * ( jiggabooware.swbPen[tr.MatType] or 1 ) * jiggabooware.activeWeapon.PenMod
                jiggabooware.traceStruct.filter = me
                jiggabooware.traceStruct.mask = jiggabooware.swbWall

				tr = TraceLine( jiggabooware.traceStruct )

                jiggabooware.traceStruct.start = tr.HitPos
                jiggabooware.traceStruct.endpos = tr.HitPos + dir * 0.1
                jiggabooware.traceStruct.filter = me
                jiggabooware.traceStruct.mask = jiggabooware.swbNormal

				tr = TraceLine( jiggabooware.traceStruct) 
				
				if tr.Hit then return false end

                jiggabooware.traceStruct.start = tr.HitPos
                jiggabooware.traceStruct.endpos = tr.HitPos + dir * 32768
                jiggabooware.traceStruct.filter = me
                jiggabooware.traceStruct.mask = MASK_SHOT

				tr = TraceLine( jiggabooware.traceStruct )
				
                if jiggabooware.cfg.vars["Ignores-Head unhitable"] then
                    return tr.Entity == plyTarget and tr.HitGroup == 1
                else
                    return tr.Entity == plyTarget
                end
			end
		end
		
		return false
	end
	
	local function M9KAutowall()
		if !jiggabooware.activeWeapon.Penetration then
			return false
		end

		local function BulletPenetrate( tr, bounceNum, damage )
			if damage < 1 then
				return false
			end
			
			local maxPenetration    = 14
            local maxRicochet       = 0
            local isRicochet        = false

            if jiggabooware.m9kPenetration[ jiggabooware.activeWeapon.Primary.Ammo ] then
                maxPenetration = jiggabooware.m9kPenetration[ jiggabooware.activeWeapon.Primary.Ammo ]
            end
			
            if jiggabooware.m9kMaxRicochet[ jiggabooware.activeWeapon.Primary.Ammo ] then
                maxRicochet = jiggabooware.m9kMaxRicochet[ jiggabooware.activeWeapon.Primary.Ammo ]
            end

            if jiggabooware.m9kCanRicochet[ jiggabooware.activeWeapon.Primary.Ammo ] then
                isRicochet = jiggabooware.m9kMaxRicochet[ jiggabooware.activeWeapon.Primary.Ammo ]
            end

			if tr.MatType == MAT_METAL and isRicochet and jiggabooware.activeWeapon.Primary.Ammo != "SniperPenetratedRound" then
				return false
			end

			if bounceNum > maxRicochet then
				return false
			end

			local penetrationDir = tr.Normal * maxPenetration

			if jiggabooware.m9kPenMaterial[ tr.MatType ] then
				penetrationDir = tr.Normal * ( maxPenetration * 2 ) 
			end

			if tr.Fraction <= 0 then
				return false
			end

			jiggabooware.traceStruct.endpos    = tr.HitPos
			jiggabooware.traceStruct.start     = tr.HitPos + penetrationDir
			jiggabooware.traceStruct.mask      = MASK_SHOT
			jiggabooware.traceStruct.filter    = me

			local trace = TraceLine( jiggabooware.traceStruct )

			if trace.StartSolid or trace.Fraction >= 1 then
				return false
			end

			jiggabooware.traceStruct.endpos = trace.HitPos + tr.Normal * 32768
			jiggabooware.traceStruct.start  = trace.HitPos
			jiggabooware.traceStruct.mask   = MASK_SHOT
			jiggabooware.traceStruct.filter = me

			local penTrace = TraceLine( jiggabooware.traceStruct )

            if jiggabooware.cfg.vars["Ignores-Head unhitable"] then
                return penTrace.Entity == plyTarget and penTrace.HitGroup == 1
            else
                return penTrace.Entity == plyTarget
            end

			local damageMulti = 0.5
			if jiggabooware.activeWeapon.Primary.Ammo == "SniperPenetratedRound" then
				damageMulti = 1
			elseif tr.MatType == MAT_CONCRETE or tr.MatType == MAT_METAL then
				damageMulti = 0.3
			elseif tr.MatType == MAT_WOOD or tr.MatType == MAT_PLASTIC or tr.MatType == MAT_GLASS then
				damageMulti = 0.8
			elseif tr.MatType == MAT_FLESH or tr.MatType == MAT_ALIENFLESH then
				damageMulti = 0.9
			end
			
			if penTrace.MatType == MAT_GLASS then
				bounceNum = bounceNum - 1
			end

			return BulletPenetrate( penTrace, bounceNum + 1, damage * damageMulti )
		end

        jiggabooware.traceStruct.start = eyePos
        jiggabooware.traceStruct.endpos = eyePos + dir * 32768
        jiggabooware.traceStruct.filter = me
        jiggabooware.traceStruct.mask = MASK_SHOT

		local trace = TraceLine( jiggabooware.traceStruct )

		return BulletPenetrate( trace, 0, jiggabooware.activeWeapon.Primary.Damage )
	end
	
    if StartsWith( jiggabooware.activeWeaponClass, "m9k_" ) then
		return M9KAutowall()
	elseif StartsWith( jiggabooware.activeWeaponClass, "swb_" ) then
		return SWBAutowall()
	end
	
	return false
end

function jiggabooware.VisibleCheck( who, where, predticks, awalldir )
    local start = me:EyePos()

    if predticks then start = start + ( me:GetVelocity() * TickInterval ) * predticks end

    jiggabooware.traceStruct.start = start
	jiggabooware.traceStruct.endpos = where
	jiggabooware.traceStruct.mask = MASK_SHOT
    jiggabooware.traceStruct.filter = me

    local tr = TraceLine( jiggabooware.traceStruct )

    local canhit = tr.Entity == who or tr.Fraction == 1

    if !canhit and awalldir and jiggabooware.cfg.vars["Wallz"] then 
        return jiggabooware.AutoWall( awalldir, who )
    end

    if jiggabooware.cfg.vars["Ignores-Head unhitable"] and tr.HitGroup != 1 then return false end

    return canhit
end

function jiggabooware.CanShoot( cmd )
	if not jiggabooware.activeWeapon then return false end
	local seq = jiggabooware.activeWeapon:GetSequence()

    if jiggabooware.cfg.binds["Aim on key"] != 0 and not jiggabooware.IsKeyDown( jiggabooware.cfg.binds["Aim on key"] ) then
        return false
    end

	if jiggabooware.badSweps[ jiggabooware.activeWeaponClass ] then
		return false
	end

    if jiggabooware.moveType == MOVETYPE_NOCLIP then
        return false
    end

    if jiggabooware.cfg.vars["Auto fire"] and cmd:KeyDown(IN_ATTACK) then
        return false
    end

	if jiggabooware.cfg.vars["Bullet time"] and jiggabooware.activeWeapon:GetNextPrimaryFire() >= ded.GetServerTime(cmd) then
		return false
	end

    // print(ded.GetRandomSeed( cmd ))
    if jiggabooware.cfg.vars["Wait for seed"] and ded.GetRandomSeed( cmd ) != 134 then
        return false 
    end

	return jiggabooware.activeWeapon:Clip1() != 0 and !jiggabooware.badSeqs[ seq ] 
end 

function jiggabooware.Spread( cmd, ang, spread )
	if not jiggabooware.activeWeapon or not jiggabooware.cones[ jiggabooware.activeWeaponClass ] then return ang end

	local dir = ded.PredictSpread( cmd, ang, spread )

	local newangle = ang + dir:Angle()
	newangle:Normalize()

	return newangle
end

/*
    Nospread 
*/

jiggabooware.CustomSpread = {}

function jiggabooware.CustomSpread.swb( cmd, ang )
    /*
    local vel = me:GetVelocity():Length()
    local dir = ang:Forward()
    
    if !me.LastView then
        me.LastView = dir
        me.ViewAff = 0
    else
        me.ViewAff = Lerp( 0.25, me.ViewAff, ( dir - me.LastView ):Length() * 0.5 )
    end
    
    if jiggabooware.activeWeapon.dt and jiggabooware.activeWeapon.meSpread and jiggabooware.activeWeapon.dt.State == SWB_AIMING then
        jiggabooware.activeWeapon.BaseCone = jiggabooware.activeWeapon.meSpread
        
        if jiggabooware.activeWeapon.Owner.Expertise then
            jiggabooware.activeWeapon.BaseCone = jiggabooware.activeWeapon.BaseCone * ( 1 - jiggabooware.activeWeapon.Owner.Expertise["steadyme"].val * 0.0015 )
        end
    else
        jiggabooware.activeWeapon.BaseCone = jiggabooware.activeWeapon.HipSpread
        
        if jiggabooware.activeWeapon.Owner.Expertise then
            jiggabooware.activeWeapon.BaseCone = jiggabooware.activeWeapon.BaseCone * ( 1 - jiggabooware.activeWeapon.Owner.Expertise["wepprof"].val * 0.0015 )
        end
    end
    
    if me:Crouching() then
        jiggabooware.activeWeapon.BaseCone = jiggabooware.activeWeapon.BaseCone * ( jiggabooware.activeWeapon.dt.State == SWB_AIMING and 0.9 or 0.75 )
    end
    
    jiggabooware.activeWeapon.CurCone = math_Clamp( jiggabooware.activeWeapon.BaseCone + jiggabooware.activeWeapon.AddSpread + ( vel / 10000 * jiggabooware.activeWeapon.VelocitySensitivity ) * ( jiggabooware.activeWeapon.dt.State == SWB_AIMING and jiggabooware.activeWeapon.meMobilitySpreadMod or 1 ) + me.ViewAff, 0, 0.09 + jiggabooware.activeWeapon.MaxSpreadInc )
    
    if CurTime() > jiggabooware.activeWeapon.SpreadWait then
        jiggabooware.activeWeapon.AddSpread = math_Clamp( jiggabooware.activeWeapon.AddSpread - 0.005 * jiggabooware.activeWeapon.AddSpreadSpeed, 0, jiggabooware.activeWeapon.MaxSpreadInc )
        jiggabooware.activeWeapon.AddSpreadSpeed = math_Clamp( jiggabooware.activeWeapon.AddSpreadSpeed + 0.05, 0, 1 )
    end
    */

    local cone = jiggabooware.activeWeapon.CurCone
    if !cone then return ang end

    if me:Crouching() then
        cone = cone * 0.85
    end

    math_randomseed( cmd:CommandNumber() )
    return ang - Angle( math_Rand(-cone, cone), math_Rand(-cone, cone), 0 ) * 25
end

function jiggabooware.CustomSpread.cw( cmd, ang )
    local cone = jiggabooware.activeWeapon.CurCone
    if !cone then return ang end

    math_randomseed( cmd:CommandNumber() )
    return ang - Angle( math_Rand(-cone, cone), math_Rand(-cone, cone), 0 ) * 25
end

function jiggabooware.CustomSpread.fas2( cmd, ang )
    math_randomseed( CurTime() )

    local dir = Angle( math_Rand( -jiggabooware.activeWeapon.CurCone, jiggabooware.activeWeapon.CurCone ), math_Rand( -jiggabooware.activeWeapon.CurCone, jiggabooware.activeWeapon.CurCone ), 0 ) * 25
    local dir2 = dir 
            
    if jiggabooware.activeWeapon.ClumpSpread and jiggabooware.activeWeapon.ClumpSpread > 0 then
        dir2 = dir + Vector( math_Rand(-1, 1), math_Rand(-1, 1), math_Rand(-1, 1)) * jiggabooware.activeWeapon.ClumpSpread
    end

    return ang - dir2
end

function jiggabooware.CustomSpread.tfa( cmd, ang )

    
    return ang
end

jiggabooware.SpreadComps = {}

jiggabooware.SpreadComps["swb"]     = jiggabooware.CustomSpread.swb
jiggabooware.SpreadComps["cw"]      = jiggabooware.CustomSpread.cw
jiggabooware.SpreadComps["fas2"]    = jiggabooware.CustomSpread.fas2
jiggabooware.SpreadComps["tfa"]     = jiggabooware.CustomSpread.tfa










function jiggabooware.NoSpread(cmd, ang)
    if not jiggabooware.activeWeapon or jiggabooware.swbShit[ jiggabooware.activeWeaponClass ] then return ang end
    local base = string.Split( jiggabooware.activeWeaponClass, "_" )[ 1 ]

    if jiggabooware.SpreadComps[ base ] then
        ang = jiggabooware.SpreadComps[ base ]( cmd, ang )
    elseif jiggabooware.cones[ jiggabooware.activeWeaponClass ] then
        local spread = jiggabooware.cones[ jiggabooware.activeWeaponClass ]
        return jiggabooware.Spread( cmd, ang, spread ) 
    end

    return ang
end

function jiggabooware.NoRecoil( ang )  
	if StartsWith( jiggabooware.activeWeaponClass,"m9k_" ) or StartsWith( jiggabooware.activeWeaponClass,"bb_" ) or StartsWith( jiggabooware.activeWeaponClass,"unclen8_" ) then
		return ang
	else
	    ang = ang - me:GetViewPunchAngles()
    end

	return ang
end

/*
jiggabooware.ui.ComboBox( p, "Hitscan mode", { "Damage", "Safety", "Scale" }, "Hitscan mode" )

*/

function jiggabooware.ParseBones( ply, bone )
    local mdl = ply:GetModel()

    if jiggabooware.parsedbones[ mdl ] and jiggabooware.parsedbones[ mdl ][ bone ] then 
        return jiggabooware.parsedbones[ mdl ][ bone ]
    end

    if not jiggabooware.parsedbones[ mdl ] then
        jiggabooware.parsedbones[ mdl ] = {}
    end
        
    local set = ply:GetHitboxSet()
    local bonecount = ply:GetBoneCount()

    for i = 0, bonecount - 1 do 
		local group = ply:GetHitBoxHitGroup( i, set )

        if group == nil then continue end

		if bone == group then
			jiggabooware.parsedbones[ mdl ][ bone ] = i

            return i
        end
	end

    for i = 0, bonecount - 1 do 
        local group = ply:GetHitBoxHitGroup( i, set )

        if group == nil then continue end

        if bone > 1 and group == 0 then
            jiggabooware.parsedbones[ mdl ][ bone ] = i

            return i
        end
    end

    return 0
end

function jiggabooware.MultipointGroupCheck( group )
    if group == 1 and not jiggabooware.cfg.vars["Multipoint groups-Head"] then return false end
    if group == 2 and not jiggabooware.cfg.vars["Multipoint groups-Chest"] then return false end
    if group == 3 and not jiggabooware.cfg.vars["Multipoint groups-Stomach"] then return false end
    if group == 4 or group == 5 and not jiggabooware.cfg.vars["Multipoint groups-Arms"] then return false end
    if group == 6 or group == 7 and not jiggabooware.cfg.vars["Multipoint groups-Legs"] then return false end
    if group == 0 and not jiggabooware.cfg.vars["Multipoint groups-Generic"] then return false end

    return true 
end

function jiggabooware.GetBones( ply )
    local scale = jiggabooware.cfg.vars["Multipoint scale"]
    local pos = ply:LocalToWorld( ply:OBBCenter() )
    local set = ply:GetHitboxSet()

    if jiggabooware.cfg.vars["Hitscan"] then
        local set = ply:GetHitboxSet()
        local bonecount = ply:GetBoneCount()

        pos = {}

        for i = 0, bonecount - 1 do 
            local group = ply:GetHitBoxHitGroup( i, set )

            if group == nil then continue end

            if group == 1 and not jiggabooware.cfg.vars["Hitscan groups-Head"] then continue end
            if group == 2 and not jiggabooware.cfg.vars["Hitscan groups-Chest"] then continue end
            if group == 3 and not jiggabooware.cfg.vars["Hitscan groups-Stomach"] then continue end
            if group == 4 or group == 5 and not jiggabooware.cfg.vars["Hitscan groups-Arms"] then continue end
            if group == 6 or group == 7 and not jiggabooware.cfg.vars["Hitscan groups-Legs"] then continue end
            if group == 0 and not jiggabooware.cfg.vars["Hitscan groups-Generic"] then continue end

            pos[ #pos + 1 ] = { bone = i, hitgroup = group }
        end

        if not pos or not istable( pos ) then return end

        local valid = {}

        for i = 1, #pos do
            local bone = pos[ i ].bone
            local hitboxbone = ply:GetHitBoxBone( bone, set )

            if hitboxbone == nil then 
                continue 
            end 

            local mins, maxs = ply:GetHitBoxBounds( bone, set )

            if not mins or not maxs then 
                continue
            end 

            local bonepos, ang = ply:GetBonePosition( hitboxbone )
            
            if jiggabooware.cfg.vars["Multipoint"] and jiggabooware.MultipointGroupCheck( pos[ i ].hitgroup ) then
                local points = {
                    ( ( mins + maxs ) * 0.5 ),
                    Vector( mins.x, mins.y, mins.z ),
                    Vector( mins.x, maxs.y, mins.z ),
                    Vector( maxs.x, maxs.y, mins.z ),
                    Vector( maxs.x, mins.y, mins.z ),
                    Vector( maxs.x, maxs.y, maxs.z ),
                    Vector( mins.x, maxs.y, maxs.z ),
                    Vector( mins.x, mins.y, maxs.z ),
                    Vector( maxs.x, mins.y, maxs.z )
                }

                for i = 1, #points do
                    points[ i ]:Rotate( ang )
                    points[ i ] = points[ i ] + bonepos

                    if i == 1 then continue end 

                    points[ i ] = ( ( points[ i ] - points[1] ) * scale ) + points[ 1 ]
                    valid[ #valid + 1 ] = points[ i ]
                end
            end 

            mins:Rotate( ang )
            maxs:Rotate( ang )

            valid[ #valid + 1 ] = bonepos + ( ( mins + maxs ) * 0.5 )
        end

        return valid
    else
        local bone = jiggabooware.ParseBones( ply, jiggabooware.cfg.vars["Hitbox selection"] ) 

        local hitboxbone = ply:GetHitBoxBone( bone, set )

        if hitboxbone == nil then 
            return { pos }  
        end 

        local mins, maxs = ply:GetHitBoxBounds( bone, set )

        if not mins or not maxs then 
            return { pos } 
        end 

        local bonepos, ang = ply:GetBonePosition( hitboxbone )  

        if jiggabooware.cfg.vars["Multipoint"] then
            local points = {
                ( ( mins + maxs ) * 0.5 ),
                Vector( mins.x, mins.y, mins.z ),
                Vector( mins.x, maxs.y, mins.z ),
                Vector( maxs.x, maxs.y, mins.z ),
                Vector( maxs.x, mins.y, mins.z ),
                Vector( maxs.x, maxs.y, maxs.z ),
                Vector( mins.x, maxs.y, maxs.z ),
                Vector( mins.x, mins.y, maxs.z ),
                Vector( maxs.x, mins.y, maxs.z )
            }

            for i = 1, #points do
                points[ i ]:Rotate( ang )
                points[ i ] = points[ i ] + bonepos

                if i == 1 then continue end 

                points[ i ] = ( ( points[ i ] - points[1] ) * scale ) + points[ 1 ]
            end

            return points
        else 
            mins:Rotate( ang )
            maxs:Rotate( ang )

            pos = bonepos + ( ( mins + maxs ) * 0.5 )
        end
    end

    return { pos }
end

function jiggabooware.GetSortedPlayers( mode, selfpred, plypred, vischeck )
    local players   = player_GetAll()   
    local eyepos    = me:EyePos()       
    local valid     = {}                // sorted lady and gentleman goes here ( niggers and faggots goes to hell )

	if selfpred then
		eyepos = eyepos + (me:GetVelocity() * TickInterval) * selfpred
	end

    for i = 1, #players do
        local v = players[i] 

        if v == me then continue end 
        if not v:Alive() or v:IsDormant() then continue end 
        if jiggabooware.cfg.vars["Ignores-Bots"] and v:IsBot() then continue end 
        if jiggabooware.cfg.vars["Ignores-Friends"] and jiggabooware.cfg.friends[v:SteamID64()] then continue end 
        if jiggabooware.cfg.vars["Ignores-Steam friends"] and v:GetFriendStatus() == "friend" then continue end 
        if jiggabooware.cfg.vars["Ignores-Admins"] and v:IsAdmin() then continue end 
        if jiggabooware.cfg.vars["Ignores-Frozen"] and v:IsFlagSet( FL_FROZEN ) then continue end 
        if jiggabooware.cfg.vars["Ignores-Nodraw"] and v:IsEffectActive( EF_NODRAW ) then continue end 
        if jiggabooware.cfg.vars["Ignores-God time"] and v:GetColor().a < 255 then continue end 
        if jiggabooware.cfg.vars["Ignores-Driver"] and v:InVehicle() then continue end 

        local st = v:Team()

        if st == TEAM_SPECTATOR or jiggabooware.cfg.vars["Ignores-Teammates"] and st == v:Team() then continue end 
        if jiggabooware.cfg.vars["Ignores-Nocliping"] and v:IsEFlagSet(EFL_NOCLIP_ACTIVE) then continue end 

        if vischeck then
			local bone = jiggabooware.GetBones( v )[1]
			local dir = me:GetShootPos() - bone
			dir:Normalize()

			if !jiggabooware.VisibleCheck( v, bone, selfpred, dir ) then
				continue
			end
		end

        local pos = v:GetPos()
        if plypred then 
            pos = pos + (v:GetVelocity() * TickInterval) * plypred
        end

        valid[#valid+1] = { v, pos }
    end

    if mode == 1 then
        table_sort(valid, function( a, b )
            return ( a[2] - eyepos ):LengthSqr() < ( b[2] - eyepos ):LengthSqr()       
        end)
    elseif mode == 2 then
        table_sort(valid, function( a, b )
            local aScr, bScr = a[2]:ToScreen(), b[2]:ToScreen()

            local aDist
            do
                local dx = scrwc - aScr.x
                local dy = scrhc - aScr.y
                aDist = dx * dx + dy * dy
            end
    
            local bDist
            do
                local dx = scrwc - bScr.x
                local dy = scrhc - bScr.y
                bDist = dx * dx + dy * dy
            end
    
            return aDist < bDist
        end)
    end

    if #valid == 0 then return end

    return valid
end

function jiggabooware.IsTickHittable( ply, cmd, tick )
    if ded.GetLatency(0) > 1 then return false end

    local serverArriveTick = ded.GetServerTime(cmd) + ded.GetLatency(0) + ded.GetLatency(1)
    local diff = serverArriveTick - jiggabooware.btrecords[ ply ][ tick ].simulationtime

    if diff > jiggabooware.cfg.vars["Backtrack time"] / 1000 then return false end

    return true
end

function jiggabooware.FindBacktrack( cmd, ply )
    local ticks = #jiggabooware.btrecords[ ply ]
    local canhit = {}

    for i = 1, ticks do
        if jiggabooware.IsTickHittable( ply, cmd, i ) then
            canhit[ #canhit + 1 ] = i
        end
    end

    return canhit
end

function jiggabooware.FindFirstHittableTicks( ply, cmd )
    local tickcount = #jiggabooware.btrecords[ ply ]

    if !tickcount then return 1 end

    for i = 1, tickcount do
        if jiggabooware.IsTickHittable( ply, cmd, i ) then
            return i
        end
    end
end

do
    local lastdist, lasttick = 1337, 1

    function jiggabooware.FindClosestHittableTicks( ply, cmd )
        local mypos = me:EyePos()
        local records = jiggabooware.btrecords[ ply ]
        local firstticks = jiggabooware.FindFirstHittableTicks( ply, cmd )
        local tickcount = #records

        if !tickcount or !firstticks then return 1 end

        lastdist = math_huge
    
        for i = 1, tickcount - firstticks do
            local mt = i + firstticks

            if ( records[ mt ].aimpos ):DistToSqr( mypos ) < lastdist then
                lastdist = ( records[ mt ].aimpos ):DistToSqr( mypos )
                lasttick = mt
            end
        end

        return lasttick
    end
end

function jiggabooware.SelectTarget( cmd )
    local plys = jiggabooware.GetSortedPlayers( jiggabooware.cfg.vars["Target selection"] )
    jiggabooware.target     = false


    if !plys then return end 

    local maxplys       = jiggabooware.cfg.vars["Max targets"]
    local curplys       = #plys

    if maxplys != 0 and curplys > maxplys then
        curplys = maxplys
    end

    local aimAng
    for i = 1, curplys do
		local ply = plys[i][1]

        if not jiggabooware.cfg.vars["Always backtrack"] then
            local bones = jiggabooware.GetBones( ply )

            for o = 1, #bones do
                local bone = bones[o]
                aimAng = ( bone - me:EyePos() ):Angle()

                if jiggabooware.VisibleCheck( ply, bone, nil, aimAng:Forward() ) then 
                    jiggabooware.target = ply
                    return ply, bone, aimAng, false, 0
                end
            end
        /*elseif jiggabooware.cfg.vars["Extrapolation"] and jiggabooware.predicted[ ply ] then
            if not jiggabooware.predicted[ ply ].pos then return end

            aimAng = ( jiggabooware.predicted[ ply ].pos - me:EyePos() ):Angle()

            jiggabooware.traceStruct.start = me:EyePos()
            jiggabooware.traceStruct.endpos = jiggabooware.predicted[ ply ].pos
            jiggabooware.traceStruct.filter = me
            jiggabooware.traceStruct.mask = MASK_SHOT

            local tr = TraceLine( jiggabooware.traceStruct )

            if !tr.Hit or tr.Entity == ply then
                jiggabooware.target = ply
                return ply, jiggabooware.predicted[ ply ].pos, aimAng, false, 0
            end*/
        end

        if jiggabooware.cfg.vars["Backtrack"] then
            local ticks = jiggabooware.FindBacktrack( cmd, ply )

            if jiggabooware.btrecords[ ply ] and not ply.break_lc then 
                local ts = 0 
                
                if jiggabooware.cfg.vars["Backtrack mode"] == 3 then
                    for p = 1, #ticks do
                        if not jiggabooware.btrecords[ ply ][ p ] then continue end

                        aimAng = ( jiggabooware.btrecords[ ply ][ p ].aimpos - me:EyePos() ):Angle()

                        jiggabooware.traceStruct.start = me:EyePos()
                        jiggabooware.traceStruct.endpos = jiggabooware.btrecords[ ply ][ p ].aimpos
                        jiggabooware.traceStruct.filter = me
                        jiggabooware.traceStruct.mask = MASK_SHOT

                        local tr = TraceLine( jiggabooware.traceStruct )

                        if !tr.Hit or tr.Entity == ply then
                            jiggabooware.target = ply
                            jiggabooware.backtracktick = p

                            return ply, jiggabooware.btrecords[ ply ][ p ].aimpos, aimAng, true, p
                        end
                    end
                end

                if jiggabooware.cfg.vars["Backtrack mode"] == 3 then return end

                if jiggabooware.cfg.vars["Backtrack mode"] == 1 then
                    ts = jiggabooware.FindFirstHittableTicks( ply, cmd )
                elseif jiggabooware.cfg.vars["Backtrack mode"] == 2 then
                    ts = jiggabooware.FindClosestHittableTicks( ply, cmd )
                end

                if not jiggabooware.btrecords[ ply ][ ts ] then return end

                aimAng = ( jiggabooware.btrecords[ ply ][ ts ].aimpos - me:EyePos() ):Angle()

                jiggabooware.traceStruct.start = me:EyePos()
                jiggabooware.traceStruct.endpos = jiggabooware.btrecords[ ply ][ ts ].aimpos
                jiggabooware.traceStruct.filter = me
                jiggabooware.traceStruct.mask = MASK_SHOT

                local tr = TraceLine( jiggabooware.traceStruct )

                if !tr.Hit or tr.Entity == ply then
                    jiggabooware.target = ply
                    jiggabooware.backtracktick = ts

                    return ply, jiggabooware.btrecords[ ply ][ ts ].aimpos, aimAng, true, ts
                end
            end
        end
	end
end

function jiggabooware.IsMovementKeysDown( cmd )

    if cmd:KeyDown( IN_MOVERIGHT ) then
        return true 
    end 
    
    if cmd:KeyDown( IN_MOVELEFT ) then
        return true 
    end 

    if cmd:KeyDown( IN_FORWARD ) then
        return true 
    end 

    if cmd:KeyDown( IN_BACK ) then
        return true 
    end 

    return false
end

function jiggabooware.MovementFix( cmd, wish_yaw )

	local pitch = math_NormalizeAngle( cmd:GetViewAngles().x )
	local inverted = -1
	
	if ( pitch > 89 || pitch < -89 ) then
		inverted = 1
	end

	local ang_diff = math_rad( math_NormalizeAngle( ( cmd:GetViewAngles().y - wish_yaw ) * inverted ) )

	local forwardmove = cmd:GetForwardMove()
	local sidemove = cmd:GetSideMove()

	local new_forwardmove = forwardmove * -math_cos( ang_diff ) * inverted + sidemove * math_sin( ang_diff )
	local new_sidemove = forwardmove * math_sin( ang_diff ) * inverted + sidemove * math_cos( ang_diff )

	cmd:SetForwardMove( new_forwardmove )
	cmd:SetSideMove( new_sidemove )
end

function jiggabooware.SilentAngles(cmd)
	if !jiggabooware.SilentAngle then jiggabooware.SilentAngle = cmd:GetViewAngles() end

	jiggabooware.SilentAngle = jiggabooware.SilentAngle + Angle( cmd:GetMouseY() * jiggabooware.myaw, cmd:GetMouseX() * -jiggabooware.myaw, 0)
	jiggabooware.SilentAngle.p = math_Clamp( jiggabooware.SilentAngle.p, -89, 89 )
    jiggabooware.SilentAngle.r = 0
    
    jiggabooware.SilentAngle:Normalize()
end





















// Knife bot ( Etot zaichik knifer )

jiggabooware.knifes = {}

jiggabooware.knifes[1] = {
    str = "csgo_",

    canbackstab = true,

    leftdmg = 25,
    leftdmgb = 90,
    leftdist = 64*64,

    rightdmg = 65,
    rightdmgb = 180,
    rightdist = 48*48,
}

jiggabooware.knifes[2] = {
    str = "swb_",

    canbackstab = false,

    leftdmg = 10,
    leftdmgb = 10,
    leftdist = 50*50,

    rightdmg = 40,
    rightdmgb = 40,
    rightdist = 50*50,
}

jiggabooware.knifes[3] = {
    str = "weapon_crowba",

    canbackstab = false,

    leftdmg = 10,
    leftdmgb = 10,
    leftdist = 75*75,

    rightdmg = 10,
    rightdmgb = 10,
    rightdist = 75*75,
}

function jiggabooware:EntityFaceBack( ent )
    local angle = me:GetAngles().y - ent:GetAngles().y

    if angle < -180 then angle = 360 + angle end

    if angle <= 90 and angle >= -90 then return true end

    return false
end

function jiggabooware.CanStab( ent, pos, health )
    local mypos = me:GetShootPos()
    local tbl = jiggabooware.knifes[1]
    local wc = me:GetActiveWeapon():GetClass()
    local canuse = false 

    for i = 1, #jiggabooware.knifes do
        if StartsWith(wc,jiggabooware.knifes[i].str) then
            canuse = true 
            tbl = jiggabooware.knifes[i]
            break
        end
    end 

    if not canuse then return false, false end

    if jiggabooware.canBacktrack( ent ) and jiggabooware.btrecords[ent][jiggabooware.backtracktick] then
        pos = jiggabooware.btrecords[ ent ][ jiggabooware.backtracktick ].aimpos
    end

    local backstab = tbl.canbackstab and jiggabooware:EntityFaceBack( ent ) or false
    local dist = mypos:DistToSqr( pos )
    local mode = jiggabooware.cfg.vars["Knifebot mode"]
    
    if mode == 1 then // Damage mode - tries to inflict biggest possible damage
        if backstab and dist < tbl.rightdist then
            return true, true
        elseif dist < tbl.leftdist and ( ( backstab and health - tbl.leftdmgb <= 0 ) or ( health - tbl.leftdmg <= 0 ) ) then
            return true, false
        elseif dist < tbl.rightdist or  ( dist < tbl.rightdist and health - tbl.leftdmg > 0 )  then 
            return true, true
        end
    elseif mode == 2 then // Fast - tries to hit fast as possible
        if dist < tbl.rightdist then
            return true, true
        elseif dist < tbl.leftdist then
            return true, false
        end
    elseif mode == 3 then // Fatal - deals only fatal damage
        if dist < tbl.leftdist and ( ( backstab and health - tbl.leftdmgb <= 0 ) or ( health - tbl.leftdmg <= 0 ) ) then
            return true, false
        elseif dist < tbl.rightdist and ( ( backstab and health - tbl.rightdmgb <= 0 ) or ( health - tbl.rightdmg <= 0 ) ) then
            return true, true
        end
    end

    return false, false
end

function jiggabooware.simtimeCheck( v )
    if not jiggabooware.cfg.vars["Wait for simtime update"] then return true end

    return v.simtime_updated
end

// Crossbow prediction 

function jiggabooware.CrossbowPred( cmd )
    if not jiggabooware.CanShoot( cmd ) then return end

    local plys = jiggabooware.GetSortedPlayers( jiggabooware.cfg.vars["Target selection"] )

    if !plys then return end

    for i = 1, #plys do
        local ply = plys[i][1]

        local eyePos        = me:EyePos()

        local plyPos        = ply:GetPos()
        local plyCenter     = ply:OBBCenter()

        local aimPos        = plyPos + plyCenter
        local aimAngle      = ( aimPos - eyePos ):Angle()
        local aimVector     = aimAngle:Forward()

        local velStart      = aimVector * 3500

        local distance      = eyePos:Distance( aimPos )
        local travelTime    = distance / 3500

        // Movement simulation 
        local predTime      = ( ded.GetLatency( 0 ) + ded.GetLatency( 1 ) ) + travelTime

        if predTime > jiggabooware.cfg.vars["Simulation limit"] then continue end

        ded.StartSimulation( ply:EntIndex() )

        for i = 1, jiggabooware.TIME_TO_TICKS( predTime ) do
            ded.SimulateTick()
        end

        local data          = ded.GetSimulationData()

        aimPos              = data.m_vecAbsOrigin + plyCenter
        distance            = eyePos:Distance( aimPos )
        travelTime          = distance / 3500

        ded.FinishSimulation()

        // Gravity simulation
        local gravity       = GetConVar("sv_gravity"):GetFloat() * 0.05
        gravity             = ( gravity * TickInterval ) * jiggabooware.TIME_TO_TICKS( travelTime )

        aimPos.z            = aimPos.z + gravity

        // Aimbot 

        local finalVec = Vector( aimPos.x, aimPos.y, aimPos.z )
        local finalAng = ( finalVec - eyePos ):Angle()
        finalAng:Normalize()

        debugoverlay.Line( plyPos + plyCenter, finalVec, 0.1, color_white, true )

        cmd:SetViewAngles( finalAng )
    end
end

// Propkill aimbot

jiggabooware.grabbingEnt = false 

function jiggabooware.DrawPhysgunBeamFunc( ply, wep, e, tar, bone, hitpos )
    if ply != me then return end 

    jiggabooware.grabbingEnt = IsValid( tar ) and tar or false
end

jiggabooware.predictedPoint = {}
function jiggabooware.PropAim( cmd )
    if not jiggabooware.grabbingEnt or not IsValid( jiggabooware.grabbingEnt ) or not cmd:KeyDown( IN_ATTACK ) then return end

    local plys = jiggabooware.GetSortedPlayers( jiggabooware.cfg.vars["Target selection"] )
    jiggabooware.target = false
    jiggabooware.targetVector = false

    if !plys then return end

    for i = 1, #plys do
        local ply           = plys[i][1]

        local eyePos        = me:EyePos() 

        local plyPos        = ply:GetPos()
        local plyVel        = ply:GetVelocity()
        local plyCenter     = ply:OBBCenter()
        local plySpeed      = plyVel:Length()
        //local plyPred       = plyPos + plyVel * TickInterval

        local propPos       = jiggabooware.grabbingEnt:GetPos()
        local propVel       = jiggabooware.grabbingEnt:GetVelocity()
        local propSpeed     = propVel:Length()

        local distance      = plyPos:Distance( propPos )
        local plydist       = plyPos:Distance( eyePos )

        if plydist >= 4096 then continue end

        local travelTime    = distance / propSpeed
        //local predTime      = ( ded.GetLatency( 0 ) + ded.GetLatency( 1 ) ) + travelTime

        if travelTime > jiggabooware.cfg.vars["Simulation limit"] then continue end // predTime

        // Prediction

        ded.StartSimulation( ply:EntIndex() )

        for i = 1, jiggabooware.TIME_TO_TICKS( travelTime ) do // predTime
            ded.SimulateTick()
        end

        local data          = ded.GetSimulationData()
        local aimPos        = data.m_vecAbsOrigin + plyCenter

        distance            = aimPos:Distance( propPos )
        travelTime          = distance / propSpeed

        ded.FinishSimulation()

        // Mouse wheel shit

        local deltaDistance = plydist - distance
        local scrollDelta = -deltaDistance

        // Aim

        local aimAng        = ( aimPos - me:EyePos() ):Angle()
        aimAng:Normalize()

        cmd:SetMouseWheel( scrollDelta ) 
        cmd:SetViewAngles( aimAng )

        /* Method 1
        local scrollDelta = 0

        if distance == 0 then
            scrollDelta = 0
        elseif propSpeed > plySpeed then
            scrollDelta = - ( distance / propSpeed )
        else
            scrollDelta = distance / plySpeed
        end
        */


        /*



        
        local predticks = jiggabooware.TIME_TO_TICKS( ded.GetLatency(0) + ded.GetLatency(1) ) + 1

        ded.StartSimulation( ply:EntIndex() )

        for i = 1, predticks do
            ded.SimulateTick()
        end

        local data = ded.GetSimulationData()

        pos = data.m_vecAbsOrigin + ply:OBBCenter()

        ded.FinishSimulation()

        local dist = pos:DistToSqr( me:EyePos() )

        local clr = dist < 16777216 and Color( 0, 255, 0 ) or Color( 255, 0, 0 )

        debugoverlay.Line( pos, jiggabooware.grabbingEnt:GetPos(), 0.1, clr, true )
        debugoverlay.Box( pos - ply:OBBCenter(), ply:OBBMins(), ply:OBBMaxs(), 0.1, Color( 255, 15, 15, 32 ) )

        if dist >= 16777216 then continue end

        local aimAng = ( pos - me:EyePos() ):Angle()
        local ppd = jiggabooware.grabbingEnt:GetPos():DistToSqr( pos )

        local cd = jiggabooware.cfg.vars["PA thrower dist"]
        if ppd < ( cd * cd ) and jiggabooware.cfg.vars["PA thrower"] then
            cmd:RemoveKey( IN_ATTACK )
        end

        local bmd = math_sqrt( dist - ppd )

        if ( dist - ppd ) < 0 then bmd = 0 end 

        local scrollDelta = math_ceil( bmd > 0 and -ppd or ppd )

        if scrollDelta > 5000 then
            scrollDelta = 5000
        elseif scrollDelta < -5000 then
            scrollDelta = -5000
        end

        print( "SDelta", scrollDelta, "BMD", bmd, "PPD", ppd )

        cmd:SetMouseWheel( scrollDelta )
        cmd:SetViewAngles( aimAng )
        */
    end
end

function jiggabooware.Aim(cmd)
    jiggabooware.AntiAim(cmd)

    if jiggabooware.SendPacket then
        jiggabooware.fakeAngles.angle = cmd:GetViewAngles()
        jiggabooware.fakeAngles.movex = me:GetPoseParameter("move_x")
        jiggabooware.fakeAngles.movey = me:GetPoseParameter("move_y")

        local layers = {}

        for i = 0, 13 do
            if me:IsValidLayer(i) then
                layers[i] = {
                    cycle = me:GetLayerCycle(i),
                    sequence = me:GetLayerSequence(i),
                    weight = me:GetLayerWeight(i)
                }
            end
        end

        jiggabooware.fakeAngles.origin = me:GetNetworkOrigin()
        jiggabooware.fakeAngles.seq = me:GetSequence()
        jiggabooware.fakeAngles.cycle = me:GetCycle()
    else
        jiggabooware.realAngle = cmd:GetViewAngles()
    end

    local ply, bone, aimang, backtracking, bttick = jiggabooware.SelectTarget(cmd)

    jiggabooware.targetVector = bone 

    if not aimang then return end

    aimang:Normalize()  

    if not jiggabooware.cfg.vars["Enable aimbot"] or not ply then return end

    /*local targetTime = ded.GetSimulationTime( ply:EntIndex() )
    local timeOffset = ded.GetServerTime(cmd) - targetTime

    local serverArriveTick = ded.GetServerTime(cmd) + ded.GetLatency(0) + ded.GetLatency(1)
    local diff = serverArriveTick - targetTime

    if diff > 1 and jiggabooware.cfg.vars["Adjust tickcount"] then return end*/

    local oldangs = Angle(aimang)

    if jiggabooware.cfg.vars["Always backtrack"] and not backtracking then return end

    if jiggabooware.cfg.vars["Fov limit"] then
        local fov = jiggabooware.cfg.vars["Aimbot FOV"]

		local view = jiggabooware.cfg.vars["Silent aim"] and jiggabooware.SilentAngle or cmd:GetViewAngles()
		local ang = aimang - view

		ang:Normalize()

		ang = math_sqrt(ang.x * ang.x + ang.y * ang.y)

        if ang > fov then
            jiggabooware.targetVector = false
		    return 
        end
    end

    if not jiggabooware.CanShoot(cmd) or not jiggabooware.simtimeCheck( ply ) then return end
    if not jiggabooware.cfg.vars["Aimbot smoothing"] and jiggabooware.SkipCommand then return end

    jiggabooware.aimingrn = true

    // Knife bot 
    local altfire = false
    local canstab, rightstab = jiggabooware.CanStab( ply, bone, ply:Health() )

    if jiggabooware.cfg.vars["Knifebot"] and canstab then
        altfire = rightstab
    elseif jiggabooware.cfg.vars["Knifebot"] and not canstab then
        return 
    end

    local oldAimAng = aimang
    local finalAngle = aimang

    if jiggabooware.cfg.vars["Norecoil"] then
        finalAngle = jiggabooware.NoRecoil(finalAngle)
    end

    if jiggabooware.cfg.vars["Force seed"] then
        //ded.ForceSeed( cmd )
    end

    if jiggabooware.cfg.vars["Nospread"] then
        finalAngle = jiggabooware.NoSpread(cmd,finalAngle)
    end

    if jiggabooware.cfg.vars["On shot aa"] then
        finalAngle.p = -finalAngle.p - 180
        finalAngle.y = finalAngle.y + 180
    end
    
    if jiggabooware.cfg.vars["Facestab"] then
        local angles = ply:EyeAngles()

        finalAngle.y = angles.y
        finalAngle.p = angles.p

        altfire = true
    end

    if jiggabooware.cfg.vars["Aimbot smoothing"] then
        local va = cmd:GetViewAngles()
        va.r = 0

        local rat = jiggabooware.cfg.vars["Smoothing"] * 100
        local ret = LerpAngle( FrameTime()*rat, va, finalAngle )
        
        finalAngle = ret
    end

    if jiggabooware.cfg.vars["Projectile aimbot"] then
        local predTime = math.ceil( ( me:EyePos() ):DistToSqr( ply:GetPos() ) / 3600 )

        print( predTime )

        //if predTime > 15 then return end

        ded.StartSimulation( ply:EntIndex() )

        for tick = 1, predTime do
            ded.SimulateTick()
        end

        local data = ded.GetSimulationData()
        local vec = data.m_vecAbsOrigin

        ded.FinishSimulation()

        local g = predTime * 0.111

        print( vec.z, g )

        vec.z = vec.z + g 

        finalAngle = ( vec - me:EyePos() ):Angle()
        finalAngle:Normalize()  
    end

    //ded.SetContextMenu( cmd, jiggabooware.cfg.vars["pSilent"] or jiggabooware.cfg.vars["Facestab"] )
    if jiggabooware.cfg.vars["Facestab"] then
        cmd:SetViewAngles( finalAngle )
        ded.SetContextVector( cmd, oldAimAng:Forward(), true )
    elseif jiggabooware.cfg.vars["pSilent"] then
        ded.SetContextVector( cmd, oldAimAng:Forward(), true )
    else
        cmd:SetViewAngles( finalAngle )
    end

    if backtracking then
        targetTime = jiggabooware.btrecords[ply][bttick].simulationtime
        timeOffset = ded.GetServerTime(cmd) - targetTime

        serverArriveTick = ded.GetServerTime(cmd) + ded.GetLatency(0) + ded.GetLatency(1)
        diff = serverArriveTick - jiggabooware.btrecords[ply][bttick].simulationtime

        if diff < 0.2 then
            ded.NetSetConVar("cl_interpolate","0")
            ded.NetSetConVar("cl_interp","0")
            local tick = jiggabooware.TIME_TO_TICKS(targetTime)
            ded.SetCommandTick(cmd, tick)
        else
            ded.NetSetConVar("cl_interpolate","1")
            ded.NetSetConVar("cl_interp",tostring(ded.GetServerTime(cmd) - targetTime))
            local tick = jiggabooware.TIME_TO_TICKS(ded.GetServerTime(cmd))
            ded.SetCommandTick(cmd, tick - 1)
        end
    elseif jiggabooware.cfg.vars["Adjust tickcount"] then
        //if diff < 0.2 then
            ded.NetSetConVar("cl_interpolate","0")
            ded.NetSetConVar("cl_interp","0")

            ded.SetCommandTick(cmd, jiggabooware.TIME_TO_TICKS( ded.GetSimulationTime( ply:EntIndex() ) ) )
        //else
        //    ded.NetSetConVar("cl_interpolate","1")
        //    ded.NetSetConVar("cl_interp",tostring(ded.GetServerTime(cmd) - targetTime))

        //    local tick = jiggabooware.TIME_TO_TICKS(ded.GetServerTime(cmd))
        //    ded.SetCommandTick(cmd, tick - 1)
        //end
    end

    if jiggabooware.cfg.vars["Auto fire"] then

        local w = me:GetActiveWeapon():GetClass()

        if StartsWith( w, "m9k_" ) then
            cmd:RemoveKey( IN_SPEED )
        end

        jiggabooware.SendPacket = true
        me.simtime_updated = true
        ded.UpdateClientAnimation( me:EntIndex() )

        if jiggabooware.cfg.vars["Resolver"] then 
            ply.aimshots = (ply.aimshots or 0) + 1
        end

        cmd:AddKey( altfire and IN_ATTACK2 or IN_ATTACK ) 

        jiggabooware.SkipCommand = true 
    end
end

function jiggabooware.autoReload(cmd)
    if !jiggabooware.cfg.vars["Auto reload"] then return end

	local wep = me:GetActiveWeapon()

	if IsValid(wep) then
		if wep.Primary then
			if wep:Clip1() == 0 and wep:GetMaxClip1() > 0 and me:GetAmmoCount(wep:GetPrimaryAmmoType()) > 0 then
				cmd:AddKey(IN_RELOAD)
			end
		end
	end
end

// adaptive Cstrafe

jiggabooware.last_ground_pos = 0
jiggabooware.cstrafe_dir = 0

function jiggabooware.PredictVelocity( velocity, viewangles, dir, maxspeed, accel )

	local forward = viewangles:Forward()
	local right = viewangles:Right()
	
	local fmove = 0
	local smove = ( dir == 1 ) && -10000 || 10000
	
	forward.z = 0
	right.z = 0
	
	forward:Normalize()
	right:Normalize()

	local wishdir = Vector( forward.x*fmove + right.x*smove, forward.y*fmove + right.y*smove, 0 )
	local wishspeed = wishdir:Length()
	
	wishdir:Normalize()
	
	if ( wishspeed != 0 && wishspeed > maxspeed ) then
		wishspeed = maxspeed
	end
	
	local wishspd = wishspeed
	
	if ( wishspd > 30 ) then
		wishspd = 30
	end
	
	local currentspeed = velocity:Dot( wishdir )
	local addspeed = wishspd - currentspeed
	
	if ( addspeed <= 0 ) then
		return velocity
	end
	
	local accelspeed = accel * wishspeed * TickInterval
	
	if ( accelspeed > addspeed ) then
		accelspeed = addspeed
	end
	
	return velocity + ( wishdir * accelspeed )

end
    
function jiggabooware.PredictMovement( viewangles, dir, angle )

	local pm

	local sv_airaccelerate = GetConVarNumber( "sv_airaccelerate" )
	local sv_gravity = GetConVarNumber( "sv_gravity" )
	local maxspeed = me:GetMaxSpeed()
	local jump_power = me:GetJumpPower()

	local origin = me:GetNetworkOrigin()
	local velocity = me:GetAbsVelocity()
	
	local mins = me:OBBMins()
	local maxs = me:OBBMaxs()

    local pticks = math_Round(jiggabooware.cfg.vars["CStrafe ticks"])
	
	local on_ground = me:IsFlagSet( FL_ONGROUND )
	
	for i = 1, pticks do

		viewangles.y = math_NormalizeAngle( math_deg( math_atan2( velocity.y, velocity.x ) ) + angle )

		velocity.z = velocity.z - ( sv_gravity * TickInterval * 0.5 )

		if ( on_ground ) then
		
			velocity.z = jump_power
			velocity.z = velocity.z - ( sv_gravity * TickInterval * 0.5 )
			
		end

		velocity = jiggabooware.PredictVelocity( velocity, viewangles, dir, maxspeed, sv_airaccelerate )
		
		local endpos = origin + ( velocity * TickInterval )

		pm = TraceHull( {
			start = origin,
			endpos = endpos,
			filter = me,
			maxs = maxs,
			mins = mins,
			mask = MASK_PLAYERSOLID
		} )
		
		if ( ( pm.Fraction != 1 && pm.HitNormal.z <= 0.9 ) || pm.AllSolid || pm.StartSolid ) then
			return false
		end
		
		if ( pm.Fraction != 1 ) then
		
			local time_left = TickInterval

			for j = 1, 2 do
			
				time_left = time_left - ( time_left * pm.Fraction )

				local dot = velocity:Dot( pm.HitNormal )
				
				velocity = velocity - ( pm.HitNormal * dot )

				dot = velocity:Dot( pm.HitNormal )

				if ( dot < 0 ) then
					velocity = velocity - ( pm.HitNormal * dot )
				end

				endpos = pm.HitPos + ( velocity * time_left )

				pm = TraceHull( {
					start = pm.HitPos,
					endpos = endpos,
					filter = me,
					maxs = maxs,
					mins = mins,
					mask = MASK_PLAYERSOLID
				} )

				if ( pm.Fraction == 1 || pm.AllSolid || pm.StartSolid ) then
					break
				end
			
			end
			
		end
		
		origin = pm.HitPos
		
		if ( ( jiggabooware.last_ground_pos - origin.z ) > math_Round(jiggabooware.cfg.vars["CStrafe ground diff"]) ) then
			return false
		end
		
		pm = TraceHull( {
			start =  Vector( origin.x, origin.y, origin.z + 2 ),
			endpos = Vector( origin.x, origin.y, origin.z - 1 ),
			filter = me,
			maxs = Vector( maxs.x, maxs.y, maxs.z * 0.5 ),
			mins = mins,
			mask = MASK_PLAYERSOLID
		} )
		
		on_ground = ( ( pm.Fraction < 1 || pm.AllSolid || pm.StartSolid ) && pm.HitNormal.z >= 0.7 )
		
		velocity.z = velocity.z - ( sv_gravity * TickInterval * 0.5 )
		
		if ( on_ground ) then
			velocity.z = 0
		end


	end

	return true

end

function jiggabooware.CircleStrafe( cmd )

	local angle = 0
	
	while ( jiggabooware.cstrafe_dir < 2 ) do
	
		angle = 0
		local path_found = false
		local step = ( jiggabooware.cstrafe_dir == 1 ) && math_Round(jiggabooware.cfg.vars["CStrafe angle step"]) || -math_Round(jiggabooware.cfg.vars["CStrafe angle step"])
		
		while ( true ) do
		
			if ( jiggabooware.cstrafe_dir == 1 ) then
			
				if ( angle > math_Round(jiggabooware.cfg.vars["CStrafe angle max step"]) ) then
					break
				end
			
			else
			
				if ( angle < -math_Round(jiggabooware.cfg.vars["CStrafe angle max step"]) ) then
					break
				end
			
			end

			if ( jiggabooware.PredictMovement( cmd:GetViewAngles(), jiggabooware.cstrafe_dir, angle ) ) then
			
				path_found = true
				break
			
			end

			angle = angle + step
		
		end
		
		if ( path_found ) then
			break
		end
		
		jiggabooware.cstrafe_dir = jiggabooware.cstrafe_dir + 1
	
	end
	
	if ( jiggabooware.cstrafe_dir < 2 ) then
	
		local velocity = me:GetAbsVelocity()
		local viewangles = cmd:GetViewAngles()
		
		viewangles.y = math_NormalizeAngle( math_deg( math_atan2( velocity.y, velocity.x ) ) + angle )
		
		cmd:SetViewAngles( viewangles )
		cmd:SetSideMove( ( jiggabooware.cstrafe_dir == 1 ) && -10000 || 10000 )
	
	else
	
		jiggabooware.cstrafe_dir = 0
	
	end

end

do
    local ztick = 0
    local prev_yaw = 0
    local old_yaw = 0.0

    function jiggabooware.AutoStrafe( cmd )
        ztick = ztick + 1

        if ( jiggabooware.IsKeyDown(jiggabooware.cfg.binds["Circle strafe"]) and jiggabooware.cfg.vars["Circle strafe"] ) then
        
            jiggabooware.CircleStrafe( cmd )
    
        elseif ( jiggabooware.IsKeyDown(jiggabooware.cfg.binds["Z Hop"]) and jiggabooware.cfg.vars["Z Hop"] ) then
            local handler = ztick / 3.14
            
            cmd:SetSideMove( 5000 * math_sin(handler) )
        elseif jiggabooware.cfg.vars["Air strafer"] and jiggabooware.cfg.vars["Strafe mode"] == 3 then
    
            local get_velocity_degree = function(velocity)
                local tmp = math_deg(math_atan(30.0 / velocity))
                    
                if (tmp > 90.0) then
                    return 90.0
                elseif (tmp < 0.0) then
                    return 0.0
                else
                    return tmp
                end
            end
    
            local M_RADPI = 57.295779513082
            local side_speed = 10000
            local velocity = me:GetVelocity()
            velocity.z = 0.0
    
            local forwardmove = cmd:GetForwardMove()
            local sidemove = cmd:GetSideMove()
    
            if (!forwardmove || !sidemove) then
                return
            end
    
            if(velocity:Length2D() <= 15.0 && !(forwardmove != 0 || sidemove != 0)) then
                return
            end
    
            local flip = cmd:TickCount() % 2 == 0
    
            local turn_direction_modifier = flip && 1.0 || -1.0
            local viewangles = Angle(jiggabooware.SilentAngle.x, jiggabooware.SilentAngle.y, jiggabooware.SilentAngle.z)
    
            if (forwardmove || sidemove) then
                cmd:SetForwardMove(0)
                cmd:SetSideMove(0)
    
                local turn_angle = math_atan2(-sidemove, forwardmove)
                viewangles.y = viewangles.y + (turn_angle * M_RADPI)
            elseif (forwardmove) then
                cmd:SetForwardMove(0)
            end
    
            local strafe_angle = math_deg(math_atan(15 / velocity:Length2D()))
    
            if (strafe_angle > 90) then
                strafe_angle = 90
            elseif (strafe_angle < 0) then
                strafe_angle = 0
            end
    
            local temp = Vector(0, viewangles.y - old_yaw, 0)
            temp.y = math_NormalizeAngle(temp.y)
    
            local yaw_delta = temp.y
            old_yaw = viewangles.y
    
            local abs_yaw_delta = math_abs(yaw_delta)
    
            if (abs_yaw_delta <= strafe_angle || abs_yaw_delta >= 30) then
                local velocity_angles = velocity:Angle()
    
                temp = Vector(0, viewangles.y - velocity_angles.y, 0)
                temp.y = math_NormalizeAngle(temp.y)
    
                local velocityangle_yawdelta = temp.y
                local velocity_degree = get_velocity_degree(velocity:Length2D() * 128)
    
                if (velocityangle_yawdelta <= velocity_degree || velocity:Length2D() <= 15) then
                    if (-velocity_degree <= velocityangle_yawdelta || velocity:Length2D() <= 15) then
                        viewangles.y = viewangles.y + (strafe_angle * turn_direction_modifier)
                        cmd:SetSideMove(side_speed * turn_direction_modifier)
                    else
                        viewangles.y = velocity_angles.y - velocity_degree
                        cmd:SetSideMove(side_speed)
                    end
                else
                    viewangles.y = velocity_angles.y + velocity_degree
                    cmd:SetSideMove(-side_speed)
                end
            elseif (yaw_delta > 0) then
                cmd:SetSideMove(-side_speed)
            elseif (yaw_delta < 0) then
                cmd:SetSideMove(side_speed)
            end
    
            local move = Vector(cmd:GetForwardMove(), cmd:GetSideMove(), 0)
            local speed = move:Length()
    
            local angles_move = move:Angle()
    
            local normalized_x = math.modf(jiggabooware.SilentAngle.x + 180, 360) - 180
            local normalized_y = math.modf(jiggabooware.SilentAngle.y + 180, 360) - 180
    
            local yaw = math_rad(normalized_y - viewangles.y + angles_move.y)
    
            if (normalized_x >= 90 || normalized_x <= -90 || jiggabooware.SilentAngle.x >= 90 && jiggabooware.SilentAngle.x <= 200 || jiggabooware.SilentAngle.x <= -90 && jiggabooware.SilentAngle.x <= 200) then
                cmd:SetForwardMove(-math_cos(yaw) * speed)
            else
                cmd:SetForwardMove(math_cos(yaw) * speed)
            end
    
            cmd:SetSideMove(math_sin(yaw) * speed)

        elseif jiggabooware.cfg.vars["Air strafer"] and jiggabooware.cfg.vars["Strafe mode"] == 2 then
            cmd:SetForwardMove(0)

            if me:IsFlagSet( FL_ONGROUND ) then
                cmd:SetForwardMove(10000)
            else
                cmd:SetForwardMove(5850 / me:GetVelocity():Length2D())
                cmd:SetSideMove((cmd:CommandNumber() % 2 == 0) && -400 || 400)
            end

            /*

local ang_diff = math_NormalizeAngle( jiggabooware.SilentAngle.y - prev_yaw )
            
            if ( math_abs( ang_diff ) > 0 ) then
            
                if ( ang_diff > 0 ) then
                    cmd:SetSideMove( -10000 )
                else
                    cmd:SetSideMove( 10000 )
                end
            
            else
            
                local vel = me:GetAbsVelocity()
                local vel_yaw = math_NormalizeAngle( math_deg( math_atan2( vel.y, vel.x ) ) )
                local vel_yaw_diff = math_NormalizeAngle( jiggabooware.SilentAngle.y - vel_yaw )
                
                if ( vel_yaw_diff > 0 ) then
                    cmd:SetSideMove( -10000 )
                else
                    cmd:SetSideMove( 10000 )
                end
    
                local viewangles = cmd:GetViewAngles() //jiggabooware.SilentAngle //Angle( jiggabooware.SilentAngle.x, jiggabooware.SilentAngle.y, 0 )
                viewangles.y = vel_yaw
                cmd:SetViewAngles( viewangles )
                
            end
    
            prev_yaw = jiggabooware.SilentAngle.y
            */
            
            
        end
    end
end

/*
    Anti aim

*/

jiggabooware.aatarget = nil

function jiggabooware.PredictedPos(ply)
    return ply:GetPos() + ply:GetVelocity() * TickInterval
end

function jiggabooware.PredictedEyePos()
    return me:EyePos() + me:GetVelocity() * TickInterval
end

function jiggabooware.GetBaseYaw()
    if not IsValid( jiggabooware.aatarget ) or jiggabooware.cfg.vars["Yaw base"] != 2 then
        return jiggabooware.SilentAngle.y
    end

    return math_NormalizeAngle( (jiggabooware.PredictedPos(jiggabooware.aatarget) - jiggabooware.PredictedEyePos()):Angle().y )
end

function jiggabooware.Freestand(cmd)
	if !IsValid(jiggabooware.aatarget) then return false end

	local headpos = me:GetBonePosition(me:LookupBone("ValveBiped.Bip01_Head1"))
	if !headpos then return end

	local selfpos = me:GetPos()
	local headoffset = Vector(selfpos.x, selfpos.y, headpos.z):Distance(headpos) + 5

	local found = true

	local pos = jiggabooware.aatarget:WorldToLocal(selfpos)
	local bearing = math_deg(-math_atan2(pos.y, pos.x)) + 180 + 90
	local left, right = bearing - 180 - 90, bearing - 180 + 90

	local function CheckYaw(yaw)
		yaw = math_rad(yaw)
		local x, y = math_sin(yaw), math_cos(yaw)

		local headoffsetvec = Vector(x, y, 0) * headoffset
		headoffsetvec.z = headpos.z - selfpos.z

		local tr = TraceLine({
			start = jiggabooware.aatarget:EyePos() + jiggabooware.aatarget:GetVelocity() * TickInterval * 4,
			endpos = selfpos + headoffsetvec,
			filter = jiggabooware.aatarget
		})

		return tr.Fraction < 1 and tr.Entity != me
	end

	local function Normalize(ang) return 360 - ang + 90 end

	local leftcheck, rightcheck = CheckYaw(left), CheckYaw(right)

	left, right = Normalize(left), Normalize(right)

	do
		local headlocal = me:WorldToLocal(headpos)
		if headlocal.x > 0 then
			left, right = right, left
		end
	end

	if leftcheck and rightcheck then
		return false
	elseif leftcheck then
		return true, left , right
	elseif rightcheck then
		return true, right, left
	end

	return false
end

jiggabooware.realAngle = me:EyeAngles()
jiggabooware.inverted = false
jiggabooware.oldYaw = 0
jiggabooware.SwaySide = 1

local baseyaw = 0

jiggabooware.CalcYaw = {
    // Backward
    [1] = function( cmd ) 
        return baseyaw - 178 
    end, 
    // Fake forward
    [2] = function( cmd )
        return jiggabooware.SendPacket and baseyaw or baseyaw + 178 
    end, 
    // Legit Delta
    [3] = function( cmd )     
        return jiggabooware.SendPacket and baseyaw or baseyaw + ( jiggabooware.inverted and 43 or - 43 )
    end,
    // Sideways 
    [4] = function( cmd )     
        local delta = jiggabooware.inverted and 89 or -89
        return baseyaw - ( jiggabooware.SendPacket and delta or -delta ) 
    end,
    // Half Sideways
    [5] = function( cmd )     
        local delta = jiggabooware.inverted and 89 or -89
        return baseyaw - ( jiggabooware.SendPacket and delta or 178 ) 
    end,
    // Fake Spin
    [6] = function( cmd )     
        local add = math_NormalizeAngle( CurTime() * jiggabooware.cfg.vars["Spin speed"] * 10 )
        return jiggabooware.SendPacket and ( jiggabooware.inverted and ( baseyaw - 178 ) or add ) or ( jiggabooware.inverted and add or ( baseyaw - 178 ) )
    end,
    // LBY Spin
    [7] = function( cmd )     
        return ded.GetCurrentLowerBodyYaw( me:EntIndex() ) + ( jiggabooware.SendPacket and 180 or 0)
    end,
    // LBY Breaker
    [8] = function( cmd )   
        local yaw = baseyaw - 178

        if me:GetVelocity():Length2D() > 1 then
            yaw = ded.GetCurrentLowerBodyYaw( me:EntIndex() ) + ( jiggabooware.SendPacket and 180 or 0)
        elseif not jiggabooware.SendPacket then
            local side = jiggabooware.inverted and -1 or 1
            local lbyTarget = ded.GetTargetLowerBodyYaw( me:EntIndex() )

            if math_abs( math_NormalizeAngle( lbyTarget - jiggabooware.oldYaw ) ) < jiggabooware.cfg.vars["LBY min delta"] then
                yaw = math_NormalizeAngle( jiggabooware.oldYaw + jiggabooware.cfg.vars["LBY break delta"] * side)
            else
                yaw = math_NormalizeAngle( ded.GetCurrentLowerBodyYaw( me:EntIndex() ) - 44 * side )
            end
        end
        
        return yaw
    end,
    // Sin Sway
    [9] = function( cmd )     
        local add = jiggabooware.cfg.vars["Sin add"]
        local sin = math_sin( CurTime() ) * jiggabooware.cfg.vars["Sin delta"]
        return jiggabooware.SendPacket and baseyaw + sin + add or baseyaw - sin - add
    end,
    // Pendulum Sway
    [10] = function( cmd )
        local ct = CurTime()
        local delta = jiggabooware.cfg.vars["Sin delta"]
        local ct1 = ( ct % 0.9 )
        local ct2 = ( ct % 2 )

        local x1 = ct2 * math_sin(ct1)
        local y1 = ct2 * -1 * math_cos(ct1)
    
        local x2 = x1 + ct1 * math_sin(ct2)
        local y2 = y1 - ct1 * math_cos(ct2)

        local sin = jiggabooware.SendPacket and x2 * delta or y2 * delta
        return baseyaw + sin
    end,
    // Lag Sway
    [11] = function( cmd )     
        local swaySpeed = (jiggabooware.fakeLagTicks + 1) / 12 * math.pi
        local swayAmount = math_sin(CurTime() * swaySpeed) * 45
    
        return ( baseyaw - 180 ) + 55 * jiggabooware.SwaySide + swayAmount * jiggabooware.SwaySide * -1
    end,
    // Fake Jitter
    [12] = function( cmd )     
        local delta = jiggabooware.cfg.vars["Jitter delta"]
        
        local a = jiggabooware.SendPacket and baseyaw - 178 or baseyaw - 178 + math_random( -delta, delta )
        local b = jiggabooware.SendPacket and baseyaw - 178 + math_random( -delta, delta ) or baseyaw - 178

        return jiggabooware.inverted and a or b
    end,
    // Kappa Jitter 
    [13] = function( cmd )    
        local delta = jiggabooware.cfg.vars["Jitter delta"]

        local a = jiggabooware.SendPacket and baseyaw - 178 or baseyaw + ( delta * jiggabooware.SwaySide )
        local b = jiggabooware.SendPacket and baseyaw + ( delta * jiggabooware.SwaySide ) or baseyaw - 178

        return jiggabooware.inverted and a or b
    end,
    // Abu Jitter 
    [14] = function( cmd )   
        local ctjit = math_sin( CurTime() * 30 ) * 25

        return ctjit + ( jiggabooware.SendPacket and baseyaw - 160 * jiggabooware.SwaySide or baseyaw - 160 * -jiggabooware.SwaySide )
    end,
    // Satanic spinner 
    [15] = function( cmd ) 
        local side = jiggabooware.inverted and 1 or -1
        local satanicvalue = math_sin( CurTime() * 666 ) * 666

        return math_NormalizeAngle( jiggabooware.SendPacket and satanicvalue * side or satanicvalue * -side )
    end,
    // Custom aa
    [16] = function( cmd )   
        return jiggabooware.SendPacket and baseyaw + jiggabooware.cfg.vars["Custom real"] or baseyaw + jiggabooware.cfg.vars["Custom fake"]
    end,
    // Hand block 
    [17] = function( cmd )  








    end,
} 







do
    local pitch, yaw = 0, 0 

    local pitches = { 
        [1] = 89,
        [2] = -89,
        [3] = 0,
        [4] = -180,
        [5] = 180,
    }







 






    local mm_side = false
    local side = false
    local pitchflip = false

    local side = 1

    local function CalcPitch()
        local cfg = jiggabooware.cfg.vars["Pitch"]
        local x = 0

        if cfg <= 5 then return pitches[cfg] end

        if jiggabooware.SendPacket then
            pitchflip = not pitchflip
        end
        
        if cfg == 6 then
            x = pitchflip and 180 or -180
        elseif cfg == 7 then
            x = jiggabooware.SendPacket and 89 or -180
        elseif cfg == 8 then
            x = jiggabooware.cfg.vars["Custom pitch"] 
        end

        return x
    end

    /*




        elseif cfg == 7 then
            
        elseif cfg == 8 then
            
        elseif cfg == 9 then
            local sin = math_sin( CurTime() ) * 89
            y = jiggabooware.SendPacket and baseyaw + sin or baseyaw - sin
        elseif cfg == 10 then
            local side = ded.GetPreviousTick() % 2 == 1

            y = jiggabooware.SendPacket and baseyaw - 180 or baseyaw + ( side and -89 or 89 )    
        elseif cfg == 11 then

        elseif cfg == 12 then
            y = baseyaw + ( jiggabooware.SendPacket && jiggabooware.cfg.vars["Custom fake"] || jiggabooware.cfg.vars["Custom real"] )
        end

"Backward", 
        "Fake forward", 
        "Sideways", 
        "Half sideways", 
        "Fake spin", 
        "LBY", 
        "Kappa", 
        "Sway",
        "VDiff",
        "القضيب الطويل",
        "Lisp",
        "Custom",

if jiggabooware.cfg.vars["Jitter"] == 2 and jiggabooware.SendPacket then
            local r = math_random(-45,45)
            local lbydiff = ded.GetTargetLBY(me:EntIndex()) - ded.GetCurrentLBY(me:EntIndex())

            if y + r > ded.GetTargetLBY(me:EntIndex()) then
                y = y + math_random(-lbydiff,lbydiff)
            else
                y = y + r
            end
             
        elseif jiggabooware.cfg.vars["Jitter"] == 3 and jiggabooware.SendPacket then
            y = y + math_random(ded.GetCurrentLBY(me:EntIndex()),ded.GetTargetLBY(me:EntIndex()))
        end

        */
        
    local function micromovement(cmd)
        if !jiggabooware.cfg.vars["Micromovement"] then return end
        if !me:Alive() then return end
        if !me:IsFlagSet( FL_ONGROUND ) then return end
        if cmd:KeyDown(IN_BACK) or cmd:KeyDown(IN_FORWARD) or cmd:KeyDown(IN_MOVELEFT) or cmd:KeyDown(IN_MOVERIGHT) then return end

        cmd:SetSideMove(mm_side and -15.0 or 15.0)
        mm_side = !mm_side
    end

    local function aacheck(cmd)
        if !jiggabooware.cfg.vars["Anti aim"] then return false end
        if cmd:KeyDown(IN_ATTACK) then return false end
        if cmd:KeyDown(IN_USE) then return false end
        if jiggabooware.moveType == MOVETYPE_LADDER then return false end
        if jiggabooware.moveType == MOVETYPE_NOCLIP then return false end

        if jiggabooware.cfg.binds["Anti aim"] != 0 and not jiggabooware.IsKeyDown(jiggabooware.cfg.binds["Anti aim"]) then
            return false
        end

        return true 
    end

    function jiggabooware.AntiAim(cmd)
        local freestandsucc, freestandsafe, freestandunsafe 

        if jiggabooware.cfg.vars["Freestanding"] then
            freestandsucc, freestandsafe, freestandunsafe = jiggabooware.Freestand(cmd)
        end

        if jiggabooware.SendPacket then
            jiggabooware.SwaySide = jiggabooware.SwaySide * -1 
        end

        baseyaw = jiggabooware.GetBaseYaw()
        pitch = CalcPitch()
        yaw = jiggabooware.CalcYaw[jiggabooware.cfg.vars["Yaw"] ](cmd)

        if jiggabooware.cfg.vars["Yaw randomisation"] then
            yaw = yaw + math_random( -0.9, 0.9 ) 
        end 

        if freestandsucc then
            yaw = jiggabooware.SendPacket and freestandunsafe or freestandsafe
        end

        if aacheck(cmd) then
            local pyAngle = Angle(pitch,yaw,0)

            micromovement(cmd)

            cmd:SetViewAngles(pyAngle)
            jiggabooware.oldYaw = pyAngle.y
        end
    end
end

/*
    Fake lag  
*/
jiggabooware.fakeLagTicks = 0
jiggabooware.fakeLagfactor = 0
jiggabooware.chokedTicks = 0

jiggabooware.peeked = false 
jiggabooware.peeking = false 

function jiggabooware.FakeLagOnPeek()
    jiggabooware.fakeLagTicks = 21 - jiggabooware.chokedTicks - 1 

    if jiggabooware.chokedTicks >= 20 then
        jiggabooware.peeked = true
		jiggabooware.peeking = false
		jiggabooware.SendPacket = true
        me.simtime_updated = true
        ded.UpdateClientAnimation( me:EntIndex() )
		return
    end
end

function jiggabooware.WarpOnPeek()
	ded.StartShifting( true )

	jiggabooware.peeked = true
	jiggabooware.peeking = false
end

function jiggabooware.CheckPeeking()
	local plys

	for extr = 1, 8 do
        plys = jiggabooware.GetSortedPlayers( 1, extr, 1, true ) 
		if plys then break end
	end

	if plys and !jiggabooware.peeking and !jiggabooware.peeked then
		jiggabooware.peeking = true
		jiggabooware.peeked = false
	elseif !plys then
		jiggabooware.peeking = false
		jiggabooware.peeked = false
	end

	if jiggabooware.peeking and !jiggabooware.peeked then
		if !ded.GetIsShifting() and ded.GetCurrentCharge() >= jiggabooware.cfg.vars["Shift ticks"] and jiggabooware.cfg.vars["Warp on peek"] then
			jiggabooware.WarpOnPeek()
        elseif jiggabooware.cfg.vars["Freeze on peek"] then
            ded.SetOutSequenceNr( ded.GetOutSequenceNr() + jiggabooware.maxFreezeTicks - 1 ) 
		//elseif jiggabooware.cfg.vars["Fake lag options-On peek"] then
		//	jiggabooware.FakeLagOnPeek()
		end
	end
end




do
    
    local function shouldlag(cmd)
        if not jiggabooware.cfg.vars["Fake lag"] then return false end
        if not me:Alive() then return false end
        if jiggabooware.cfg.vars["Fakelag comp"] == 1 and ded.GetCurrentCharge() > 0 then return false end
        if jiggabooware.cfg.vars["Fake lag options-Disable on ladder"] and jiggabooware.moveType == MOVETYPE_LADDER then return false end
        if jiggabooware.cfg.vars["Fake lag options-Disable in attack"] and cmd:KeyDown(IN_ATTACK) then return false end

        if jiggabooware.cfg.vars["Allah fly"] and not me:IsFlagSet( FL_ONGROUND ) then
            return false
        end

        return true
    end

    function jiggabooware.FakeLag(cmd)
        local factor = math_Round(jiggabooware.cfg.vars["Lag limit"])

        if jiggabooware.cfg.vars["Fake lag options-Randomise"] then 
            factor =  math_random(jiggabooware.cfg.vars["Lag randomisation"],factor) 
        end

        local velocity = me:GetVelocity():Length2D()
        local pertick = velocity * TickInterval
        local adaptive_factor = math_Clamp(math_ceil(64 / pertick),1,factor)

        if jiggabooware.cfg.vars["Lag mode"] == 1 or jiggabooware.cfg.vars["Lag mode"] == 3 then
            jiggabooware.fakeLagfactor = factor
        elseif jiggabooware.cfg.vars["Lag mode"] == 2 then
            jiggabooware.fakeLagfactor = adaptive_factor
        end

        if jiggabooware.cfg.vars["Allah walk"] and me:IsFlagSet( FL_ONGROUND ) and jiggabooware.IsKeyDown(jiggabooware.cfg.binds["allahwalk"]) then
            jiggabooware.fakeLagfactor = 21
        end

        //if jiggabooware.cfg.vars["Fakelag comp"] == 2 and ded.GetCurrentCharge() > 0 then 
        //    local nfactor = jiggabooware.fakeLagfactor - ded.GetMaxShiftTicks() - 1
        //    jiggabooware.fakeLagfactor = math_Clamp( nfactor, 0, 21 )
        //end

        if shouldlag(cmd) then
            jiggabooware.SendPacket = false

            if jiggabooware.fakeLagTicks <= 0 then
                jiggabooware.fakeLagTicks = jiggabooware.fakeLagfactor
                jiggabooware.SendPacket = true
                me.simtime_updated = true
                ded.UpdateClientAnimation( me:EntIndex() )
            else
                jiggabooware.fakeLagTicks = jiggabooware.fakeLagTicks - 1
            end

        else
            if jiggabooware.fakeLagfactor > 0 then jiggabooware.fakeLagfactor = 0 end
            jiggabooware.SendPacket = true
            me.simtime_updated = true
            ded.UpdateClientAnimation( me:EntIndex() )
        end
    end
end

function jiggabooware.ClampMovementSpeed(cmd, speed)
	local final_speed = speed;

	local squirt = math_sqrt((cmd:GetForwardMove() * cmd:GetForwardMove()) + (cmd:GetSideMove() * cmd:GetSideMove()));

	if (squirt > speed) then
		local squirt2 = math_sqrt((cmd:GetForwardMove() * cmd:GetForwardMove()) + (cmd:GetSideMove() * cmd:GetSideMove()));

		local cock1 = cmd:GetForwardMove() / squirt2;
		local cock2 = cmd:GetSideMove() / squirt2;

		local Velocity = me:GetVelocity():Length2D();

		if (final_speed + 1.0 <= Velocity) then
			cmd:SetForwardMove(0)
			cmd:SetSideMove(0)
		else
			cmd:SetForwardMove(cock1 * final_speed)
			cmd:SetSideMove(cock2 * final_speed)
        end
    end
end

function jiggabooware.FastWalk( cmd )
    if not jiggabooware.cfg.vars["Ground strafer"] then return end 
    if math_abs(cmd:GetSideMove()) > 1 or math_abs(cmd:GetForwardMove()) < 1 then return end 
    if not me:IsFlagSet( FL_ONGROUND ) then return end

    if jiggabooware.moveType == MOVETYPE_NOCLIP or jiggabooware.moveType == MOVETYPE_LADDER then return end

    local waterLevel = me:WaterLevel()

    if waterLevel >= 2 then return end
    
	cmd:SetSideMove(cmd:CommandNumber() % 2 == 0 and -5250 or 5250)
end

function jiggabooware.validMoveType()
    return jiggabooware.moveType != MOVETYPE_LADDER and jiggabooware.moveType != MOVETYPE_NOCLIP and jiggabooware.moveType != MOVETYPE_OBSERVER 
end

function jiggabooware.isMoving(cmd)
    if not cmd then
        return false
    end

    return jiggabooware.hoppin or cmd:KeyDown(IN_MOVELEFT) or cmd:KeyDown(IN_MOVERIGHT) or cmd:KeyDown(IN_FORWARD) or cmd:KeyDown(IN_BACK) and not cmd:KeyDown(IN_JUMP)
end

function jiggabooware.Stop(cmd)
    if jiggabooware.validMoveType() and me:IsFlagSet( FL_ONGROUND ) then

        local moving = jiggabooware.isMoving(cmd)

        if not moving then

            local vel = me:GetVelocity()
            local dir = vel:Angle()
                
            dir.yaw = jiggabooware.SilentAngle.y - dir.yaw
                
            local newmove = dir:Forward() * vel:Length2D()
        
            cmd:SetForwardMove(0 - newmove.x)
            cmd:SetSideMove(0 - newmove.y)

        end

    end
end

// Slidewalk 

function jiggabooware.SlideWalk( cmd )
    local ticksToStop = jiggabooware.fakeLagfactor





end








// Auto peak 

jiggabooware.startedPeeking = false 
jiggabooware.needToMoveBack = false
jiggabooware.startPeekPosition = Vector(0,0,0)

function jiggabooware.MoveTo( cmd, pos )
    local ang = ( pos - me:GetPos() ):Angle().y

    cmd:SetForwardMove(1000)
    cmd:SetSideMove(0)

    cmd:AddKey(IN_SPEED)

    jiggabooware.MovementFix( cmd, ang )
end

function jiggabooware.checkAutopeak( cmd )
    if jiggabooware.startedPeeking and cmd:KeyDown(IN_ATTACK) then 
        jiggabooware.needToMoveBack = true
    elseif !jiggabooware.startedPeeking and !cmd:KeyDown(IN_ATTACK) then
        jiggabooware.needToMoveBack = false
    end  
end

do
    local colorA = Color( 235, 75, 75 )
    local colorB = Color( 75, 235, 75 )

    local apmat = Material( "gui/npc.png" )

    local nullangle = Angle(0,0,0)

    function jiggabooware.drawAutopeak()
        local col = jiggabooware.needToMoveBack and colorA or colorB
    
        cam_Start3D2D( jiggabooware.startPeekPosition, nullangle, 0.5 )
            cam_IgnoreZ( true )

            surface_SetDrawColor( col )
            surface_SetMaterial( apmat )
            surface_DrawTexturedRect( -32, -32, 64, 64 )

            cam_IgnoreZ( false )
        cam_End3D2D()
    end
end

function jiggabooware.autopeakThink()
    if jiggabooware.IsKeyDown(jiggabooware.cfg.binds["Auto peak"]) then
        if not jiggabooware.startedPeeking then
            jiggabooware.startPeekPosition = me:GetPos()     
        end

        jiggabooware.startedPeeking = true
    else
        jiggabooware.startedPeeking = false
    end
end







/*// Movement 
jiggabooware.holdingOnGround = false 
jiggabooware.badMoveTypes = { 
    ["MOVETYPE_NOCLIP"] = true, ["MOVETYPE_LADDER"] = true, ["MOVETYPE_OBSERVER"] = true 
}

function jiggabooware.BunnyHop(cmd)
    local moveType = me:GetMoveType()
    local waterLevel = me:WaterLevel()

    if jiggabooware.badMoveTypes[moveType] then return end 

    if me:IsFlagSet( FL_ONGROUND ) then

        --[[if jiggabooware.holdingOnGround then 
            jiggabooware.holdingOnGround = false

            cmd:RemoveKey(IN_JUMP)
        end

        if cmd:KeyDown(IN_JUMP) then
            jiggabooware.holdingOnGround = true 
        end

        return ]]
    else 
        cmd:RemoveKey(IN_JUMP)
        return
    end

    //if waterLevel >= 2 then return end 
end
*/

// Sequence Manipulation 

jiggabooware.freezedTicks = 0
jiggabooware.maxFreezeTicks = math_Round( 1 / TickInterval ) 
function jiggabooware.AnimationFreezer()
    if not jiggabooware.IsKeyDown( jiggabooware.cfg.binds["Animation freezer"] ) then return end

    if jiggabooware.freezedTicks < jiggabooware.maxFreezeTicks then
        ded.SetOutSequenceNr( ded.GetOutSequenceNr() + jiggabooware.maxFreezeTicks - 1 ) 

        jiggabooware.freezedTicks = jiggabooware.freezedTicks + 1
    else
        jiggabooware.freezedTicks = 0
    end
end

jiggabooware.seqshit = false
function jiggabooware.SequenceShit(cmd)
    if not jiggabooware.cfg.vars["Sequence manip"] or not jiggabooware.IsKeyDown(jiggabooware.cfg.binds["Sequence manip"]) then
        
        if jiggabooware.seqshit then
            jiggabooware.seqshit = false 
        end

        return 
    end

    local amt = jiggabooware.cfg.vars["Sequence min random"] and math_random(jiggabooware.cfg.vars["Sequence min"],jiggabooware.cfg.vars["OutSequence"]) or jiggabooware.cfg.vars["OutSequence"] 

    jiggabooware.seqshit = true
    jiggabooware.SendPacket = true
    ded.SetOutSequenceNr(ded.GetOutSequenceNr() + amt)
end

// Handjob ( arm breaker )
 
function jiggabooware.PerformHandjob( cmd )
    local mode = jiggabooware.cfg.vars["Handjob mode"]
    local shouldjerk = true

    if mode == 2 then
        shouldjerk = (cmd:CommandNumber() % 12) >= 6
    elseif mode == 3 then
        shouldjerk = math_random(0, 1) == 0 
    end

    ded.SetTyping(cmd, shouldjerk)
end 

// create move hook 

jiggabooware.norf = {
    ["laserjetpack"] = true,
    ["weapon_physgun"] = true,
}

jiggabooware.vapecd = false
jiggabooware.tyaga = 0
jiggabooware.maxvape = jiggabooware.TIME_TO_TICKS(5)
jiggabooware.hoppin = false
local ic = false

jiggabooware.slams = {}

hook.Add( "OnEntityCreated", "Aawwawawawawawawaawawa", function( ent )
    if ent:GetClass() == "npc_satchel" and ent:GetOwner() == me then 
        jiggabooware.slams[ #jiggabooware.slams + 1 ] = ent
    end
end )






function jiggabooware.CreateMove(cmd)
    jiggabooware.SilentAngles(cmd)

    jiggabooware.aimingrn = false

    //if ( ded.GetChokedPackets() > 14 ) then ded.SetChokedPackets( 14 ) end

    if cmd:CommandNumber() == 0 then return end

    //if ded.GetIsShifting() then jiggabooware.shiftedTicks = jiggabooware.shiftedTicks + 1 end

    local w = me:GetActiveWeapon()
    jiggabooware.activeWeapon       = IsValid( w ) and w or false
    jiggabooware.activeWeaponClass  = IsValid( w ) and w:GetClass() or false 
    jiggabooware.moveType           = me:GetMoveType() 

    //if jiggabooware.cfg.vars["Passive recharge"] and ded.GetCurrentCharge() < ded.GetMaxShiftTicks() and not me:Alive() then
    //    ded.SetReloadKeyPressed( true )
    //end


    if jiggabooware.cfg.vars["Silent aim"] then cmd:SetViewAngles(jiggabooware.SilentAngle) end

    //if ded.GetIsShifting() then
        //  ded.AdjustTickbase()
    //    print("shifting")
    //end

    if jiggabooware.cfg.vars["Flashlight spam"] and input_IsKeyDown( KEY_F ) then
        cmd:SetImpulse(100)
    end

    if jiggabooware.cfg.vars["Auto Vape"] then
        if cmd:KeyDown( IN_ATTACK ) then
            if jiggabooware.tyaga >= jiggabooware.maxvape then
                cmd:RemoveKey( IN_ATTACK )
                jiggabooware.tyaga = 0
            elseif jiggabooware.tyaga < jiggabooware.maxvape then
                jiggabooware.tyaga = jiggabooware.tyaga + 1 
            end
        else
            jiggabooware.tyaga = 0
        end
    end 


    if jiggabooware.vapecd then 
        jiggabooware.vapecd = false 
        cmd:RemoveKey( IN_ATTACK2 ) 
    elseif jiggabooware.cfg.vars["Vape spam"] and jiggabooware.activeWeapon and not jiggabooware.vapecd and StartsWith( jiggabooware.activeWeaponClass, "weapon_vape" ) then
        cmd:AddKey( IN_ATTACK2 )
        jiggabooware.vapecd = true
    end   

    if jiggabooware.cfg.vars["Handjob"] then
        jiggabooware.PerformHandjob( cmd )
    end 

    //if jiggabooware.cfg.vars["Fake latency"] then
    //    local amt = jiggabooware.cfg.vars["Max latency"]
    //    ded.SetInSequenceNr(ded.GetInSequenceNr() - amt)
    //end

    if jiggabooware.SkipCommand then 
        cmd:RemoveKey( IN_ATTACK ) 
    
        jiggabooware.SkipCommand = !jiggabooware.SkipCommand 
    end

    if ( me:IsFlagSet( FL_ONGROUND ) ) then
		jiggabooware.last_ground_pos = me:GetNetworkOrigin().z
	end

    if jiggabooware.cfg.vars["Animation freezer"] then jiggabooware.AnimationFreezer() end
    
	jiggabooware.SequenceShit(cmd)

    if not jiggabooware.seqshit then
        jiggabooware.FakeLag(cmd)

        if jiggabooware.cfg.vars["Allah walk"] and me:IsFlagSet( FL_ONGROUND ) and jiggabooware.IsKeyDown(jiggabooware.cfg.binds["allahwalk"]) then
            
            if jiggabooware.fakeLagTicks != 20 then
                jiggabooware.ClampMovementSpeed(cmd, 0)
            else
                jiggabooware.ClampMovementSpeed(cmd, me:GetWalkSpeed())
            end

            //if(jiggabooware.fakeLagTicks <= 20) then
            //    jiggabooware.ClampMovementSpeed(cmd, 0)
            //    jiggabooware.Stop(cmd)
                //me:SetPoseParameter("move_x", 0)
	            //me:SetPoseParameter("move_y", 0)
            //else
             //   jiggabooware.ClampMovementSpeed(cmd, me:GetWalkSpeed())
            //end

            --print(jiggabooware.fakeLagTicks,me:GetVelocity():Length2D())
        end
    end

    if jiggabooware.cfg.vars["Fake lag options-On peek"] or jiggabooware.cfg.vars["Warp on peek"] or jiggabooware.cfg.vars["Freeze on peek"] then
        jiggabooware.CheckPeeking()
    end
    
    // Movement
    
    jiggabooware.FastWalk( cmd )

    if jiggabooware.cfg.vars["Sprint"] then cmd:AddKey(IN_SPEED) end

    jiggabooware.hoppin = false
    if ( cmd:KeyDown( IN_JUMP ) ) then

		if ( !me:IsFlagSet( FL_ONGROUND ) ) and jiggabooware.cfg.vars["Bhop"] then
			cmd:RemoveKey( IN_JUMP )
            jiggabooware.hoppin = true
		end

		jiggabooware.AutoStrafe( cmd )
	end
    
	if jiggabooware.cfg.vars["Fast stop"] then
        jiggabooware.Stop(cmd)
    end

    if jiggabooware.cfg.vars["Water jump"] and me:WaterLevel() > 1 then
        cmd:AddKey( IN_JUMP )

    elseif jiggabooware.cfg.vars["Jesus lag"] and jiggabooware.SendPacket and me:WaterLevel() == 1 then
        cmd:AddKey( IN_DUCK )
    end

    if jiggabooware.cfg.vars["Fake duck"] and jiggabooware.IsKeyDown(jiggabooware.cfg.binds["Fake duck"]) then
        if jiggabooware.fakeLagTicks > (jiggabooware.fakeLagfactor / 2) then
            cmd:AddKey(IN_DUCK)
        else
            cmd:RemoveKey(IN_DUCK)
        end
    end

    jiggabooware.targetVector = false

	ded.StartPrediction(cmd)

        local wish_yaw = jiggabooware.SilentAngle.y 

        if ( jiggabooware.IsKeyDown(jiggabooware.cfg.binds["Circle strafe"]) and jiggabooware.cfg.vars["Circle strafe"] ) then
            wish_yaw = cmd:GetViewAngles().y
        end

        if jiggabooware.cfg.vars["Crossbow prediction"] and jiggabooware.activeWeaponClass == "weapon_crossbow" then
            jiggabooware.CrossbowPred( cmd )
        elseif jiggabooware.cfg.vars["Prop aimbot"] then
            jiggabooware.PropAim(cmd)
        else
            jiggabooware.Aim(cmd)
        end 
        
        if jiggabooware.cfg.vars["Silent aim"] then
            jiggabooware.MovementFix( cmd, wish_yaw )
        end

    ded.FinishPrediction() 

    if jiggabooware.cfg.vars["Trigger bot"] and jiggabooware.IsKeyDown( jiggabooware.cfg.binds["Trigger bot"] ) then
        local tr = me:GetEyeTrace().Entity 
        
        if tr and tr:IsPlayer() then
            cmd:AddKey( IN_ATTACK )
        end
    end

    if jiggabooware.cfg.vars["Double tap"] and jiggabooware.cfg.vars["Tickbase shift"] and cmd:KeyDown( IN_ATTACK ) then
        //jiggabooware.shiftedTicks = 0
        print( cmd:KeyDown( IN_ATTACK ) )
        ded.StartShifting( true )
    end

    if jiggabooware.cfg.vars["Rapid fire"] and me:Alive() then
        local w = me:GetActiveWeapon()

        if IsValid(w) and not jiggabooware.norf[ w:GetClass() ] and me:KeyDown( IN_ATTACK ) then
            cmd:RemoveKey(IN_ATTACK)
        end
    end

    if jiggabooware.cfg.vars["Alt Rapid fire"] and me:Alive() then
        local w = me:GetActiveWeapon()

        if IsValid(w) and me:KeyDown( IN_ATTACK2 ) then
            cmd:RemoveKey(IN_ATTACK2)
        end
    end

    if jiggabooware.cfg.vars["Auto detonator"] and #jiggabooware.slams > 0 then
        local d = jiggabooware.cfg.vars["AutoD distance"]
        d = d * d 

        local plys = player_GetAll()

        for jjj = 1, #plys do
            if plys[ jjj ] == me then continue end
            
            for k, v in pairs(jiggabooware.slams) do
                if not IsValid(v) then jiggabooware.slams[k] = nil continue end
    
                local pos = v:GetPos()
    
                if pos:DistToSqr( plys[ jjj ]:GetPos() + plys[ jjj ]:GetVelocity() * ( TickInterval * 4 ) ) < d then
                    cmd:AddKey( IN_ATTACK2 )
                    break
                end
            end
        end
    end

    if jiggabooware.cfg.vars["Auto peak"] then
        local ppos = jiggabooware.startPeekPosition
        local pposd = me:GetPos():DistToSqr(ppos)

        if jiggabooware.needToMoveBack and pposd < 1024 then //or jiggabooware.IsMovementKeysDown( cmd )
            jiggabooware.needToMoveBack = false
        end

        if jiggabooware.startedPeeking then
            //if not jiggabooware.IsMovementKeysDown( cmd ) then
            //    jiggabooware.needToMoveBack = true
            //end

            if jiggabooware.needToMoveBack then
                jiggabooware.MoveTo( cmd, ppos )

                if jiggabooware.cfg.vars["Auto peak tp"] and jiggabooware.cfg.vars["Tickbase shift"] then
                    //jiggabooware.shiftedTicks = 0
                    print("NIGGER")
                    ded.StartShifting( true )
                end
            end
        end

        jiggabooware.checkAutopeak( cmd )
    end

    jiggabooware.autoReload(cmd)

    if jiggabooware.cfg.vars["Use spam"] then
        if cmd:KeyDown(IN_USE) then
            cmd:RemoveKey(IN_USE)
        else
            cmd:AddKey(IN_USE)
        end
    end

    if jiggabooware.cfg.vars["Auto GTA"] then
        local tr = me:GetEyeTrace().Entity

        if IsValid( tr ) and tr:IsVehicle() then
            cmd:AddKey(IN_USE)
        end
    end

    if jiggabooware.cfg.vars["Ghost follower"] then
        local tar = player.GetBySteamID( jiggabooware.cfg.vars["GFID"] )

        if IsValid( tar ) then 
            local tang = ( tar:GetPos() - me:EyePos() ):Angle()

            cmd:ClearMovement()
            cmd:ClearButtons()

            cmd:SetForwardMove( 10000 )
            cmd:SetSideMove(0)

            cmd:AddKey(IN_SPEED)

            cmd:SetViewAngles( tang )
            jiggabooware.MovementFix( cmd, tang.y )
        end
    end

    if jiggabooware.cfg.vars["Air lag duck"] and jiggabooware.SendPacket then
        local startPosUnducked = me:GetPos()
        local isDucking = bit.band(me:GetFlags(), FL_DUCKING) != 0
        if isDucking then
            startPosUnducked.z = startPosUnducked.z - (72 - 36)
        end

        ded.StartSimulation( me:EntIndex() )

        local shouldduck = true 

        for i = 1, 4 do
            ded.SimulateTick()

            local simData = ded.GetSimulationData()

            local maxs = me:OBBMaxs()
            maxs.z = 72 

            if isDucking then
                simData.m_vecAbsOrigin.z = simData.m_vecAbsOrigin.z - (72 - 36)
            end

            local trace = TraceHull({
                start = startPosUnducked,
                endpos = simData.m_vecAbsOrigin,
                mins = me:OBBMins(),
                maxs = maxs,
                filter = me,
                mask = MASK_PLAYERSOLID
            })

            if me:IsOnGround() and trace.Hit then
                shouldduck = false 
                break
            end
        end

        ded.FinishSimulation()

        if shouldduck and !me:IsFlagSet( FL_ONGROUND ) then 
            cmd:AddKey( IN_DUCK )   
        end
    end

    if jiggabooware.fcenabled then
        cmd:ClearMovement()
        cmd:ClearButtons()

        cmd:SetViewAngles(jiggabooware.fcangles)
    end

    /*if jiggabooware.cfg.vars["Dodge projectiles"] and ded.GetCurrentCharge() >= ded.GetMaxShiftTicks() and not ded.GetIsShifting() then
        local entitys = ents_GetAll()

        for i = 1, #entitys do
            local v = entitys[ i ]

            if v:GetClass() != "crossbow_bolt" then continue end 

            local mypos = me:GetPos() + me:GetVelocity() * TickInterval 
            local entpos = v:GetPos() + ( v:GetAngles():Forward() * 3500 ) * TickInterval

            if mypos:DistToSqr( entpos ) > 320 then
                cmd:ClearMovement()
                cmd:ClearButtons()

                cmd:AddKey( IN_SPEED )
                cmd:SetSideMove( 10000 )
                ded.StartShifting( true )
            end
        end
    end*/

    if jiggabooware.SendPacket then
        jiggabooware.chokedTicks = 0 
    else
        jiggabooware.chokedTicks = jiggabooware.chokedTicks + 1
    end

    if not jiggabooware.cfg.vars["Silent aim"] then jiggabooware.SilentAngle = cmd:GetViewAngles() end

    ded.SetBSendPacket( jiggabooware.SendPacket )

    if jiggabooware.cfg.vars["Lag mode"] == 3 and jiggabooware.SendPacket then
        ded.SetOutSequenceNr(ded.GetOutSequenceNr() + 8)
    end
end 


 
   
hook_Add( "CreateMove", "jiggabooware.CreateMove", jiggabooware.CreateMove ) // Post
 
/* 
    Render Scene / Anti screengrab 
*/
jiggabooware.UnSafeFrame = false
jiggabooware.renderTarget = GetRenderTarget( "YaPidoras" .. os.time(), scrw, scrh )

do
    local oldsky, oldskycolor, oldwallcolor = jiggabooware.cfg.vars["Custom sky"], jiggabooware.cfg.vars["Sky color"], jiggabooware.cfg.vars["Wall color"]
    local oldskyclr, oldwallclr = jiggabooware.cfg.colors["Sky color"], jiggabooware.cfg.colors["Wall color"]

    local worldcollerp = string_ToColor( jiggabooware.cfg.colors["Wall color"] )
    local worldmats = Entity( 0 ):GetMaterials()

    local origsky = GetConVar("sv_skyname"):GetString()
    local tsides = {"lf", "ft", "rt", "bk", "dn", "up"}
    local skymat = {}

    for i = 1, 6 do 
        skymat[i] = Material("skybox/" .. origsky .. tsides[i]) 
    end

    local function setSkyboxTexture( skyname )
        for i = 1, 6 do
            local t = Material("skybox/" .. skyname .. tsides[i]):GetTexture("$basetexture")
            skymat[i]:SetTexture("$basetexture", t)
        end
    end

    local function setSkyColor( setcolor )
        local cfg = string_ToColor( jiggabooware.cfg.colors["Sky color"] )
        local vector = setcolor and Vector( cfg.r/255, cfg.g/255, cfg.b/255 ) or Vector( 1, 1, 1 )

        for i = 1, 6 do
            skymat[i]:SetVector( "$color", vector )
        end
    end

    local function setWallColor( setcolor )
        local cfg = string_ToColor( jiggabooware.cfg.colors["Wall color"] )
        worldcollerp = jiggabooware.ColorLerp( worldcollerp, cfg )
        local vector = setcolor and Vector( worldcollerp.r/255, worldcollerp.g/255, worldcollerp.b/255 ) or Vector( 1, 1, 1 )

        for i = 1, #worldmats do
            local value = worldmats[i]

            Material( value ):SetVector( "$color", vector )
            Material( value ):SetFloat( "$alpha", setcolor and (cfg.a / 255) or 255 )
        end
    end

    function jiggabooware.hRenderScene()

        local newname, newcolor, newcolor2 = jiggabooware.cfg.vars["Custom sky"], jiggabooware.cfg.vars["Sky color"], jiggabooware.cfg.vars["Wall color"]
        local newskyclr, newwallclr = jiggabooware.cfg.colors["Sky color"],jiggabooware.cfg.colors["Wall color"]
        
        if newskyclr != oldskyclr or newcolor != oldskycolor then
            setSkyColor( newcolor )

            oldskyclr = newskyclr
            oldskycolor = newcolor
        end

        if newwallclr != tostring( worldcollerp ) or newcolor2 != oldwallcolor then
            setWallColor( newcolor2 )

            oldwallcolor = newcolor2
        end

        if newname != oldsky then
            setSkyboxTexture( newname )
            oldsky = newname
        end

        // Esp shit

        if ( !gui.IsConsoleVisible() && !gui.IsGameUIVisible() ) || jiggabooware.UnSafeFrame then
            local view = {
                x = 0,
                y = 0,
                w = scrw,
                h = scrh,
                dopostprocess = true,
                origin = vOrigin,
                angles = vAngle,
                fov = vFOV,
                drawhud = true,
                drawmonitors = true,
                drawviewmodel = true
            }
         
            render_RenderView( view )
            render.CopyTexture( nil, jiggabooware.renderTarget )
         
            cam_Start2D()
                hook_Run( "Ungrabbable2D" )
            cam_End2D()

            cam_Start3D()
                hook_Run( "Ungrabbable3D" )
            cam_End3D()
    
            render.SetRenderTarget( jiggabooware.renderTarget )
         
            return true
        end
    end

end

function jiggabooware.PreScreenGrab()
    if jiggabooware.UnSafeFrame then return end
	jiggabooware.UnSafeFrame = true
 
	render_Clear( 0, 0, 0, 255, true, true )
	render_RenderView( {
		origin = me:EyePos(),
		angles = me:EyeAngles(),
		x = 0,
		y = 0,
		w = scrw,
		h = scrh,
		dopostprocess = true,
		drawhud = true,
		drawmonitors = true,
		drawviewmodel = true
	} )
 
	jiggabooware.UnSafeFrame = false
end

jiggabooware.prikol = Material( "a/prikol" ):GetTexture( "$basetexture" ) //  Material( file_Read( "prikol.png", "DATA" ) )

function render.Capture( data )
    jiggabooware.PreScreenGrab()

    if jiggabooware.cfg.vars["Screengrab image"] then 
        cam.Start2D()
            render.DrawTextureToScreen( jiggabooware.prikol )
        cam.End2D()
    end

	return render_Capture( data )
end

function _G.render.Capture( data )
    jiggabooware.PreScreenGrab()

    if jiggabooware.cfg.vars["Screengrab image"] then 
        cam.Start2D()
            render.DrawTextureToScreen( jiggabooware.prikol )
        cam.End2D()
    end

	return render_Capture( data )
end

function jiggabooware.Shutdown()
    render.SetRenderTarget()
end

/*
    ESP, Chams
*/

function jiggabooware.IsValidPlayer(pl)
    if pl == me then return false end
    if not IsValid(pl) then return false end
    if not pl:Alive() then return false end


    return true
end

function jiggabooware.GetEntPos(ent)
    local min, max = ent:OBBMins(), ent:OBBMaxs()

    local points = {
        Vector( max.x, max.y, max.z ),
        Vector( max.x, max.y, min.z ),
        Vector( max.x, min.y, min.z ),
        Vector( max.x, min.y, max.z ),
        Vector( min.x, min.y, min.z ),
        Vector( min.x, min.y, max.z ),
        Vector( min.x, max.y, min.z ),
        Vector( min.x, max.y, max.z )
    }

    local MaxX, MinX, MaxY, MinY
    local isVisible = false

    for i = 1, #points do
        local v = points[i]
        local p = ent:LocalToWorld( v ):ToScreen()
        isVisible = p.visible 
        
		if MaxX != nil then
            MaxX, MaxY, MinX, MinY = math_max( MaxX, p.x ), math_max( MaxY, p.y), math_min( MinX, p.x ), math_min( MinY, p.y)
        else
            MaxX, MaxY, MinX, MinY = p.x, p.y, p.x, p.y
        end

    end

    return MaxX, MaxY, MinX, MinY, isVisible
end

function jiggabooware.getTextX(tw,pos)
    if pos == 1 or pos == 2 then
        return tw/2
    elseif pos == 3 then
        return 0
    elseif pos == 4 then 
        return tw
    end
end

function jiggabooware.getTextY(max,min,th,pos,tbpos)
    if pos == 1 then
        return min-th-th*tbpos
    elseif pos == 2 then
        return max+th*tbpos
    elseif pos == 3 then
        return min+th*tbpos
    elseif pos == 4 then
        return min+th*tbpos
    end
end

function jiggabooware.SortByDistance( f, s )
    return f[1]:GetPos():DistToSqr( EyePos() ) > s[1]:GetPos():DistToSqr( EyePos() )
end

function jiggabooware.GenerateArrowPoss(x, y, scale, ang)
    local ang1 = Angle(0, ang, 0):Forward() * scale
    local ang2 = Angle(0, ang + 120, 0):Forward() * (scale - 1)
    local ang3 = Angle(0, ang - 120, 0):Forward() * (scale - 1)

    local p0 = {x = x, y = y}
    local poly = {
        {x = p0.x + ang1.x, y = p0.y + ang1.y},
        {x = p0.x + ang2.x, y = p0.y + ang2.y},
        {x = p0.x + ang3.x, y = p0.y + ang3.y},
    }
    return poly
end

function jiggabooware.DrawOutlinedPoly( poly )
    local last = nil
    for i = 1, #poly do
        local v = poly[ i ]
        if last then
            surface_DrawLine(last.x, last.y, v.x, v.y)
            last = v
        else
            last = v
        end
    end
    surface_DrawLine(last.x, last.y, poly[1].x, poly[1].y)
end

jiggabooware.Fonts = {
    [1] = "veranda",
    [2] = "veranda_s",
    [3] = "thug",
}

function jiggabooware.DrawESP()
    local d = jiggabooware.cfg.vars["ESP Distance"]
    local ed = jiggabooware.cfg.vars["Ent ESP Distance"]
    local pos = me:GetPos()
    d = d * d
    ed = ed * ed

    surface_SetFont( jiggabooware.Fonts[ jiggabooware.cfg.vars["ESP Font"] ] )

    if jiggabooware.cfg.vars["Ent box 3d"] then
        cam_Start3D()
            for i = 1, #jiggabooware.entityCache do
                local v = jiggabooware.entityCache[ i ]

                if not IsValid( v.entity ) then return end 

                if v.position:DistToSqr( pos ) > ed then continue end

                render_DrawWireframeBox( v.position, v.entity:GetAngles(), v.entity:OBBMins(), v.entity:OBBMaxs(), jiggabooware.Colors[255], true )
            end
        cam_End3D()
    end

    for i = 1, #jiggabooware.entityCache do
        local v = jiggabooware.entityCache[ i ]

        if not IsValid( v.entity ) then return end 

        if v.position:DistToSqr( pos ) > ed then continue end

        local MaxX, MaxY, MinX, MinY, isVisible = jiggabooware.GetEntPos( v.entity )
        local XLen, YLen = MaxX - MinX, MaxY - MinY

        if not isVisible then continue end

        surface_SetAlphaMultiplier( v.entity:IsDormant() and 0.35 or 1 )

        surface_SetTextColor( jiggabooware.Colors[255] )

        if jiggabooware.cfg.vars["Ent box"] and not jiggabooware.cfg.vars["Ent box 3d"] then
            surface_SetDrawColor( 0, 0, 0 )
            surface_DrawOutlinedRect(MinX-1,MinY-1,XLen+2,YLen+2,3)

            surface_SetDrawColor( 255, 255, 255 ) 
            surface_DrawOutlinedRect(MinX,MinY,XLen,YLen,1)
        end

        if jiggabooware.cfg.vars["Ent class"] then
            local tw, th = surface_GetTextSize( v.class )

            surface_SetTextPos( ( MaxX + (MinX - MaxX) / 2 ) - tw / 2 , MinY - th )
            surface_DrawText( v.class )
        end
    end

    local plys = player_GetAll()

    local color_box     = string_ToColor( jiggabooware.cfg.colors["Box esp"] )
    local color_box_g   = string_ToColor( jiggabooware.cfg.colors["Box gradient"] )

    local myEyePos = me:EyePos()

    for i = 1, #plys do
        local v = plys[i]

        if not jiggabooware.IsValidPlayer(v) or not jiggabooware.playerCache[ v ] then continue end
        
        local vp = jiggabooware.playerCache[ v ].GetPos
        local distance = vp:DistToSqr(pos)
		if distance > d then continue end

        surface_SetAlphaMultiplier( v:IsDormant() and 0.35 or 1 )

        local MaxX, MaxY, MinX, MinY, isVisible = jiggabooware.GetEntPos( v )
        local XLen, YLen = MaxX - MinX, MaxY - MinY

        local teamcolor = jiggabooware.playerCache[ v ].TeamColor

        if jiggabooware.cfg.vars["OOF Arrows"] then 
            local xScale, yScale = scrw / 250, scrh / 250
            local xScale, yScale = xScale * 50, yScale * 50
 
            local angle = ( v:EyePos() - myEyePos ):Angle() 
            local addPos = Angle(0, (jiggabooware.SilentAngle.y - angle.y) - 90, 0):Forward()
            local pos = Vector(scrw / 2, scrh / 2, 0) + Vector(addPos.x * xScale, addPos.y * yScale, 0)

            if math.abs( math.NormalizeAngle(angle.y - jiggabooware.SilentAngle.y) ) >= 60 then
                local poly = jiggabooware.GenerateArrowPoss(pos.x, pos.y, 16, (jiggabooware.SilentAngle.y - angle.y) - 90)
                local poly1 = jiggabooware.GenerateArrowPoss(pos.x, pos.y, 17, (jiggabooware.SilentAngle.y - angle.y) - 90)
                local poly2 = jiggabooware.GenerateArrowPoss(pos.x, pos.y, 15, (jiggabooware.SilentAngle.y - angle.y) - 90)
                
                if jiggabooware.cfg.vars["OOF Style"] == 1 then
                    surface_SetDrawColor( jiggabooware.Colors[0] )
                    jiggabooware.DrawOutlinedPoly( poly1 )
                    jiggabooware.DrawOutlinedPoly( poly2 )

                    surface_SetDrawColor( teamcolor ) 
                    jiggabooware.DrawOutlinedPoly( poly )
                else
                    local ang2 = Angle(0, (jiggabooware.SilentAngle.y - angle.y) - 90 + 120, 0):Forward() * (scale - 1)
                    surface_SetDrawColor( teamcolor ) 
                    
                    surface_DrawLine( pos.x, pos.y, pos.x, pos.y + ang2.y )
                    //surface_DrawLine(last.x, last.y, v.x, v.y)
                    //surface_DrawLine(last.x, last.y, v.x, v.y)
                    //surface_DrawLine(last.x, last.y, v.x, v.y)
                end
                
            end
        end

        if not isVisible then continue end

        if jiggabooware.cfg.vars["Box esp"] then
            if jiggabooware.cfg.vars["Box style"] == 1 then
                surface_SetDrawColor(jiggabooware.Colors[0])
                surface_DrawOutlinedRect(MinX-1,MinY-1,XLen+2,YLen+2,3)
        
                surface_SetDrawColor( jiggabooware.cfg.vars["Box team color"] and teamcolor or color_box )
                surface_DrawOutlinedRect(MinX,MinY,XLen,YLen,1)
            elseif jiggabooware.cfg.vars["Box style"] == 2 then
                local wlen, hlen = math_floor( XLen / 3 ), math_floor( YLen / 3 )

                surface_SetDrawColor(jiggabooware.Colors[0])

                // Left up
                surface_DrawRect( MinX - 1, MinY - 1, wlen, 3 )
                surface_DrawRect( MinX - 1, MinY - 1, 3, hlen )

                // Right up
                surface_DrawRect( MaxX - wlen + 2, MinY - 1, wlen, 3 )
                surface_DrawRect( MaxX - 1, MinY - 1, 3, hlen )

                // Left down
                surface_DrawRect( MinX - 1, MaxY - 2, wlen, 3 )
                surface_DrawRect( MinX - 1, MaxY - hlen, 3, hlen )

                // Right down
                surface_DrawRect( MaxX - wlen + 2, MaxY - 2, wlen, 3 )
                surface_DrawRect( MaxX - 1, MaxY - hlen, 3, hlen )

                surface_SetDrawColor( jiggabooware.cfg.vars["Box team color"] and teamcolor or color_box )

                wlen = wlen - 2
                hlen = hlen - 2 

                // Left up
                surface_DrawRect( MinX, MinY, wlen, 1 )
                surface_DrawRect( MinX, MinY, 1, hlen )
 
                // Right up
                surface_DrawRect( MaxX - wlen + 1, MinY, wlen, 1 )
                surface_DrawRect( MaxX, MinY, 1, hlen )
 
                // Left down
                surface_DrawRect( MinX, MaxY - 1, wlen, 1 )
                surface_DrawRect( MinX, MaxY - hlen - 1, 1, hlen )
 
                // Right down
                surface_DrawRect( MaxX - wlen + 1, MaxY - 1, wlen, 1 )
                surface_DrawRect( MaxX, MaxY - hlen - 1, 1, hlen )
            elseif jiggabooware.cfg.vars["Box style"] == 3 then
                local wlen, hlen = math_floor( XLen / 3 ), math_floor( YLen / 3 )
                local xc = math_floor( XLen / 2 )

                surface_SetDrawColor(jiggabooware.Colors[0])

                // Left
                surface_DrawRect( MinX - 1, MinY - 1 + hlen, 3, hlen )

                surface_DrawLine( MinX - 1, MinY - 1 + hlen, MinX + xc, MinY - 1 )
                surface_DrawLine( MinX + 1, MinY - 1 + hlen, MinX + xc, MinY + 1 )

                surface_DrawLine( MinX - 1, MinY - 2 + hlen * 2, MinX + xc, MinY + 1 + YLen )
                surface_DrawLine( MinX + 1, MinY - 2 + hlen * 2, MinX + xc, MinY - 1 + YLen )

                // Right
                surface_DrawRect( MaxX - 1, MinY - 1 + hlen, 3, hlen )

                surface_DrawLine( MaxX - 1, MinY - 1 + hlen, MinX + xc, MinY + 1 )
                surface_DrawLine( MaxX + 1, MinY - 1 + hlen, MinX + xc, MinY - 1 )

                surface_DrawLine( MaxX - 1, MinY - 2 + hlen * 2, MinX + xc, MinY - 1 + YLen )
                surface_DrawLine( MaxX + 1, MinY - 2 + hlen * 2, MinX + xc, MinY + 1 + YLen )

                surface_SetDrawColor( jiggabooware.cfg.vars["Box team color"] and teamcolor or color_box )

                // Left
                surface_DrawRect( MinX, MinY + hlen - 1, 1, hlen )
                surface_DrawLine( MinX, MinY - 1 + hlen, MinX + xc, MinY )
                surface_DrawLine( MinX, MinY - 2 + hlen * 2, MinX + xc, MinY + YLen )

                // Right
                surface_DrawRect( MaxX, MinY + hlen - 1, 1, hlen )
                surface_DrawLine( MaxX, MinY - 1 + hlen, MinX + xc, MinY )
                surface_DrawLine( MaxX, MinY - 2 + hlen * 2, MinX + xc, MinY + YLen )
            elseif jiggabooware.cfg.vars["Box style"] == 4 then
                local wlen, hlen = math_floor( XLen / 3 ) + 3, math_floor( YLen / 3 ) + 3
                local x, y, xw, xh = MinX - 3, MinY - 3, MaxX + 3, MaxY + 3
                local polys = {}

                for i = 1, 3 do
                    polys = {
                        { x = x + wlen, y = y },
                        { x = xw - wlen, y = y },
                        { x = xw, y = y + hlen },
                        { x = xw, y = xh - hlen },
                        { x = xw - wlen, y = xh },
                        { x = x + wlen, y = xh },
                        { x = x, y = xh - hlen },
                        { x = x, y = y + hlen },
                    }
    
                    surface_SetDrawColor( i == 2 and teamcolor or jiggabooware.Colors[0] ) 
                    jiggabooware.DrawOutlinedPoly( polys )
                    
                    wlen, hlen = wlen - i, hlen - i

                    y, x = y + i, x + i
                    xw, xh = xw - i, xh - i
                end
                
            end
        end

        // Sight lines 

        if jiggabooware.cfg.vars["Sight lines"] then 
            local tr = v:GetEyeTrace()
            local startpos, hitpos = tr.StartPos:ToScreen(), tr.HitPos:ToScreen()

            surface_SetDrawColor( teamcolor )
            surface_DrawLine( startpos.x, startpos.y, hitpos.x, hitpos.y )
        end

        // text 

        local ttbl = { [1] = 0, [2] = 0, [3] = 0, [4] = 0 }
        local poses = { [1] = MaxX + (MinX - MaxX) / 2, [3] = MaxX+5, [4] = MinX-5 }
        poses[2] = poses[1]

        surface_SetTextColor( jiggabooware.Colors[255] )

        if jiggabooware.cfg.vars["Name"] then 
            local name = jiggabooware.playerCache[ v ].Name
            local pos = jiggabooware.cfg.vars["Name pos"]
            local tw, th = surface_GetTextSize(name)

            surface_SetTextPos(poses[pos]-jiggabooware.getTextX(tw,pos),jiggabooware.getTextY(MaxY,MinY,th,pos,ttbl[pos]))
            surface_DrawText(name)

            ttbl[pos] = ttbl[pos] + 0.8
        end

        if jiggabooware.cfg.vars["Usergroup"] then 
            local name = jiggabooware.playerCache[ v ].GetUserGroup
            local pos = jiggabooware.cfg.vars["Usergroup pos"]
            local tw, th = surface_GetTextSize(name)

            surface_SetTextPos(poses[pos]-jiggabooware.getTextX(tw,pos),jiggabooware.getTextY(MaxY,MinY,th,pos,ttbl[pos]))
            surface_DrawText(name)

            ttbl[pos] = ttbl[pos] + 0.8
        end

        if jiggabooware.cfg.vars["Weapon"] then 
            local name = jiggabooware.cfg.vars["Show ammo"] and jiggabooware.playerCache[ v ].WeaponClass .. " (" .. jiggabooware.playerCache[ v ].WeaponAmmo .. ")" or jiggabooware.playerCache[ v ].WeaponClass
           
            if jiggabooware.cfg.vars["Show reloading"] then
                for i = 0, 13 do
                    if v:IsValidLayer(i) then
                        if v:GetSequenceActivityName(v:GetLayerSequence(i)):find("RELOAD") then
                            name = "RELOADING"
                            break
                        end
                    end
                end
            end

            local pos = jiggabooware.cfg.vars["Weapon pos"]
            local tw, th = surface_GetTextSize(name)

            surface_SetTextPos(poses[pos]-jiggabooware.getTextX(tw,pos),jiggabooware.getTextY(MaxY,MinY,th,pos,ttbl[pos]))
            surface_DrawText(name)

            ttbl[pos] = ttbl[pos] + 0.8
        end

        if jiggabooware.cfg.vars["Armor"] then 
            local name = jiggabooware.playerCache[ v ].Armor
            local pos = jiggabooware.cfg.vars["Armor pos"]
            local tw, th = surface_GetTextSize(name)

            surface_SetTextPos(poses[pos]-jiggabooware.getTextX(tw,pos),jiggabooware.getTextY(MaxY,MinY,th,pos,ttbl[pos]))
            surface_DrawText(name)

            ttbl[pos] = ttbl[pos] + 0.8
        end

        if jiggabooware.cfg.vars["Team"] then 
            local name = jiggabooware.playerCache[ v ].TeamName
            local pos = jiggabooware.cfg.vars["Team pos"]
            local tw, th = surface_GetTextSize(name)

            surface_SetTextPos(poses[pos]-jiggabooware.getTextX(tw,pos),jiggabooware.getTextY(MaxY,MinY,th,pos,ttbl[pos]))
            surface_DrawText(name)

            ttbl[pos] = ttbl[pos] + 0.8
        end

        if jiggabooware.cfg.vars["DarkRP Money"] then 
            local name = jiggabooware.playerCache[ v ].MoneyVar
            local pos = jiggabooware.cfg.vars["Money pos"]
            local tw, th = surface_GetTextSize(name)

            surface_SetTextPos(poses[pos]-jiggabooware.getTextX(tw,pos),jiggabooware.getTextY(MaxY,MinY,th,pos,ttbl[pos]))
            surface_DrawText(name)

            ttbl[pos] = ttbl[pos] + 0.8
        end
        
        local health = jiggabooware.playerCache[ v ].Health

        if jiggabooware.cfg.vars["Health bar"] then 
            local maxhealth = jiggabooware.playerCache[ v ].GetMaxHealth

			local healthfrac = math_min( health / maxhealth, 1 )
		    local height = math_floor( healthfrac * YLen )

            surface_SetDrawColor( 0, 0, 0 )
            surface_DrawRect( MinX-6, MinY-1, 4, YLen+2 )

			surface_SetDrawColor( string_ToColor( jiggabooware.cfg.colors["Health"] ) )
			surface_DrawRect(MinX - 5, MinY+YLen-height, 2, height)

            if jiggabooware.cfg.vars["Health bar gradient"] then 
                surface_SimpleTexturedRect( MinX - 5, MinY+YLen-height, 2, height, string_ToColor( jiggabooware.cfg.colors["Health bar gradient"] ) , jiggabooware.Materials["Gradient"] )
            end
        end

        if jiggabooware.cfg.vars["Health"] then 
            local pos = jiggabooware.cfg.vars["Health pos"]
            local tw, th = surface_GetTextSize(health)

            surface_SetTextPos(poses[pos]-jiggabooware.getTextX(tw,pos),jiggabooware.getTextY(MaxY,MinY,th,pos,ttbl[pos]))
            surface_DrawText(health)

            ttbl[pos] = ttbl[pos] + 0.8
        end

        if jiggabooware.cfg.vars["Break LC"] and v.break_lc then
            local name = "Breaking LC"
            local pos = jiggabooware.cfg.vars["Break LC pos"]
            local tw, th = surface_GetTextSize(name)

            surface_SetTextPos(poses[pos]-jiggabooware.getTextX(tw,pos),jiggabooware.getTextY(MaxY,MinY,th,pos,ttbl[pos]))
            surface_DrawText(name)

            ttbl[pos] = ttbl[pos] + 0.8
        end

        if jiggabooware.cfg.vars["Simtime updated"] then
            local name = v.simtime_updated and "Updated" or "Same"
            local pos = jiggabooware.cfg.vars["Simtime pos"]
            local tw, th = surface_GetTextSize(name)

            surface_SetTextPos(poses[pos]-jiggabooware.getTextX(tw,pos),jiggabooware.getTextY(MaxY,MinY,th,pos,ttbl[pos]))
            surface_DrawText(name)

            ttbl[pos] = ttbl[pos] + 0.8
        end

        if jiggabooware.cfg.vars["IFOV"] then
            local angle = ( v:EyePos() - myEyePos ):Angle() 
            local infov = math_abs( math_NormalizeAngle( angle.y ) ) > 75
            local name = infov and "in FOV!" or "out of FOV!"
            local pos = jiggabooware.cfg.vars["Simtime pos"]
            local tw, th = surface_GetTextSize(name)

            surface_SetTextPos(poses[pos]-jiggabooware.getTextX(tw,pos),jiggabooware.getTextY(MaxY,MinY,th,pos,ttbl[pos]))
            surface_DrawText(name)

            ttbl[pos] = ttbl[pos] + 0.8
        end
 
        if jiggabooware.cfg.vars["Skeleton"] then
            surface_SetDrawColor( string_ToColor( jiggabooware.cfg.colors["Skeleton"] ) )

		    for i = 0, v:GetBoneCount() - 1 do

			    local parent = v:GetBoneParent(i)

			    if(!parent) then continue end

			    local bonepos = v:GetBonePosition(i)

			    if(bonepos == v:GetPos() ) then continue end

			    local parentpos = v:GetBonePosition(parent)

			    if(!bonepos or !parentpos) then continue end

			    local screen1, screen2 = bonepos:ToScreen(),parentpos:ToScreen()

			    surface_DrawLine(screen1.x,screen1.y,screen2.x,screen2.y)
		    end
        end

        if jiggabooware.cfg.vars["Show records"] and jiggabooware.canBacktrack(v) then
            local len = #jiggabooware.btrecords[ v ]

            for i = 1, len do
                local pos = ( jiggabooware.btrecords[v][i].aimpos ):ToScreen()
                surface_SetDrawColor( jiggabooware.backtracktick == i and jiggabooware.Colors["Red"] or jiggabooware.Colors[255] )
                surface_DrawRect(pos.x,pos.y,2,2)
            end
        end

        if jiggabooware.cfg.vars["Backtrack skeleton"] and jiggabooware.canBacktrack(v) then
            local len = #jiggabooware.btrecords[ v ]

            surface_SetDrawColor( jiggabooware.Colors[255] )

            for i = 1, len do
                local data = jiggabooware.btrecords[ v ][ i ].skeleton

                for nbone = 1, #data do
                    local screen1, screen2 = data[nbone][1]:ToScreen(), data[nbone][2]:ToScreen()
        
                    surface_DrawLine(screen1.x,screen1.y,screen2.x,screen2.y)
                end
            end
        end
    end

    surface_SetAlphaMultiplier(1)
end


surface.CreateFont("DTFont", { font = "Verdana", size = 15, antialias = false, outline = true } )
surface.CreateFont("XVIDEOS FONT", { font = "Verdana", size = 45, antialias = false, shadow = true } )

jiggabooware.fovColor = Color( 255, 255, 255 )
jiggabooware.gradFov = false






//jiggabooware.bgmaterial = Material( "a/paws.png", "noclamp smooth" )



do
    local lc, blc = Color(125,255,64), Color(255,64,125)

    local indx, indy = scrw / 2 - 100, scrh/2 + 250
    local charge = 0

    local gradcolor, chargedcolor, unchargedcolor = Color(200,200,200,128), Color(0,255,128), Color(255,155,0)

    local chargestate, ccharge, chargecolor = "NOT CHARGED", 0, chargedcolor

    //local watermarkx = scrw + 245
    //local watermarkc = Color( 232, 232, 232, 235)

    function jiggabooware.DrawSomeShit()

        //if jiggabooware.frame:IsVisible() then
        //    surface_SetDrawColor( jiggabooware.accent )
        //    surface_SetMaterial( jiggabooware.bgmaterial )
        //    surface_DrawTexturedRect( 0, 0, scrw, scrh )
        //end

        surface_SetFont("DTFont")
        
        local latency = math_Round( ( ded.GetLatency(0) + ded.GetLatency(1) ) * 1000 ) 
        local currentlby = math_Round( ded.GetCurrentLowerBodyYaw( me:EntIndex() ) ) 
        local targetlby = math_Round( ded.GetTargetLowerBodyYaw( me:EntIndex() ) ) 


        surface_SimpleText(38,scrh-120,"LC",me.break_lc and blc or lc)
        surface_SimpleText(38,scrh-140,"FT: "..jiggabooware.fakeLagTicks,jiggabooware.SendPacket and blc or lc)
        surface_SimpleText(38,scrh-160,math_Round(me:GetVelocity():Length2D()),lc)
        surface_SimpleText(38,scrh-180,"AT: "..latency.." ms",latency > 50 and blc or lc)
        surface_SimpleText(38,scrh-200,"LBY: "..currentlby.." ("..targetlby..")",currentlby != targetlby and blc or lc)
        
        if jiggabooware.cfg.vars["Auto Vape"] then
            surface_SimpleText(38,scrh-220,"Vape: ", jiggabooware.tyaga == 0 and blc or lc)
            
            surface_SetDrawColor( 0, 0, 0 )
            surface_DrawRect( 78, scrh-219, 60, 14 )

            surface_SetDrawColor( lc )
            surface_DrawRect( 79, scrh-218, jiggabooware.tyaga / jiggabooware.maxvape * 58, 12 )
        end
        

        if jiggabooware.cfg.vars["Tickbase indicator"] then
            local max, cur = jiggabooware.cfg.vars["Charge ticks"], ded.GetCurrentCharge()
            local dtw = cur / max * 30

            local x, y = scrwc - 7, scrhc + 10

            surface_SimpleText( x, y, "DT", blc ) // 

            render.SetScissorRect( x, y, x + dtw, y + 30, true )
                surface_SimpleText( x, y, "DT", lc )
            render.SetScissorRect( 0, 0, 0, 0, false )
        end

        

        /*
        
        watermarkx = watermarkx - 1

        if watermarkx < -925 then
            watermarkx = scrw + 100
        end

        surface_SetFont("XVIDEOS FONT")
        surface_SimpleText(watermarkx,10,"This video was uploaded to WWW.XVIDEOS.COM",watermarkc)
        */
        local CT = CurTime()
        local FT = FrameTime() * 128

        if jiggabooware.cfg.vars["Hitmarker"] and #jiggabooware.hitmarkers > 0 then
            local hm = string_ToColor( jiggabooware.cfg.colors["Hitmarker"] ) 
    
            surface_SetDrawColor( hm )

            for i = #jiggabooware.hitmarkers, 1, -1  do
                local v = jiggabooware.hitmarkers[ i ]
    
                if v.time < CT - 1 then table_remove( jiggabooware.hitmarkers, i ) continue end 
    
                v.add = math_Approach( v.add, v.add - (CT - 1) * 5, FT )

                surface_DrawLine( scrwc - v.add, scrhc - v.add, scrwc - 10 - v.add, scrhc - 10 - v.add )
                surface_DrawLine( scrwc + v.add, scrhc - v.add, scrwc + 10 + v.add, scrhc - 10 - v.add )
                surface_DrawLine( scrwc - v.add, scrhc + v.add, scrwc - 10 - v.add, scrhc + 10 + v.add )
                surface_DrawLine( scrwc + v.add, scrhc + v.add, scrwc + 10 + v.add, scrhc + 10 + v.add )
            end
        end

        if jiggabooware.cfg.vars["Hitnumbers"] and #jiggabooware.hitnums > 0 then 
            local n, c = string_ToColor( jiggabooware.cfg.colors["Hitnumbers"] ), string_ToColor( jiggabooware.cfg.colors["Hitnumbers krit"] )
        
            surface_SetFont( "veranda_scr" )

            for i = #jiggabooware.hitnums, 1, -1 do
                local v = jiggabooware.hitnums[ i ]

                if v.time < CT - 1 then table_remove( jiggabooware.hitnums, i ) continue end 

                surface_SetTextColor( v.crit and c or n )

                v.add = math_Approach( v.add, v.add - (CT - 1) * 5, FT / 2 )

                surface_SetTextPos( scrwc - v.add * v.xdir, scrhc - v.add * v.ydir )
                surface_DrawText( v.dmg )
            end
        end

        if jiggabooware.cfg.vars["Show FOV"] then 
            local col = string_ToColor( jiggabooware.cfg.colors["Show FOV"] )
            
            local radius = jiggabooware.GetFovRadius()
        
            surface_SetDrawColor( 0, 0, 0, 128 )
            surface.DrawCircle( scrwc, scrhc, radius + 1 )

            surface_SetDrawColor( col.r, col.g, col.b )
            surface.DrawCircle( scrwc, scrhc, radius )

            surface_SetDrawColor( 0, 0, 0, 128 )
            surface.DrawCircle( scrwc, scrhc, radius - 1 )
        end

        if jiggabooware.target and jiggabooware.targetVector then
            if jiggabooware.cfg.vars["Aimbot snapline"] then 
                local pos = jiggabooware.targetVector:ToScreen()
                surface_SetDrawColor( string_ToColor( jiggabooware.cfg.colors["Aimbot snapline"] ) )
                surface_DrawLine( pos.x, pos.y, scrwc, scrhc )
            end
    
            if jiggabooware.cfg.vars["Aimbot marker"] then 
                local pos = jiggabooware.targetVector:ToScreen()

                surface_SetDrawColor( 0, 0, 0 )
                surface_DrawRect( pos.x - 6, pos.y - 6, 5, 3 )
                surface_DrawRect( pos.x + 2, pos.y - 6, 5, 3 )

                surface_DrawRect( pos.x - 6, pos.y + 4, 5, 3 )
                surface_DrawRect( pos.x + 2, pos.y + 4, 5, 3 )

                surface_DrawRect( pos.x - 6, pos.y - 6, 3, 5 )
                surface_DrawRect( pos.x + 4, pos.y - 6, 3, 5 )

                surface_DrawRect( pos.x - 6, pos.y + 2, 3, 5 )
                surface_DrawRect( pos.x + 4, pos.y + 2, 3, 5 )

                surface_SetDrawColor( string_ToColor( jiggabooware.cfg.colors["Aimbot marker"] ) )
                
                surface_DrawRect( pos.x - 5, pos.y - 5, 3, 1 )
                surface_DrawRect( pos.x + 3, pos.y - 5, 3, 1 )

                surface_DrawRect( pos.x - 5, pos.y + 5, 3, 1 )
                surface_DrawRect( pos.x + 3, pos.y + 5, 3, 1 )

                surface_DrawRect( pos.x - 5, pos.y - 5, 1, 3 )
                surface_DrawRect( pos.x + 5, pos.y - 5, 1, 3 )

                surface_DrawRect( pos.x - 5, pos.y + 3, 1, 3 )
                surface_DrawRect( pos.x + 5, pos.y + 3, 1, 3 )

            end
        end
        
        surface_SetFont( "veranda" )

        if jiggabooware.cfg.vars[ "On screen logs" ] and table.Count( jiggabooware.onScreenLogs ) > 0 then
            local tick = engine.TickCount()
            local x, y = scrw / 2, scrh / 2 + 45 
    
            for k, v in pairs( jiggabooware.onScreenLogs ) do

                if jiggabooware.TICKS_TO_TIME( tick - jiggabooware.onScreenLogs[ k ].tick ) > 8 then
                    jiggabooware.onScreenLogs[ k ] = nil
                    continue 
                end

                local data = jiggabooware.onScreenLogs[ k ]
                local fstr = ""
    
                for o = 1, #data[ 1 ] do
                    fstr = fstr .. data[ 1 ][ o ]
                end
    
                local tw, th = surface.GetTextSize( fstr )
    
                x = x - tw / 2
                
                for p = 1, #data[ 1 ] do
                    local str = data[ 1 ][ p ]
                    tw, th = surface.GetTextSize( str )
    
                    surface.SetTextPos( x, y )
                    surface.SetTextColor( data[ 2 ][ p ] )
                    surface.DrawText( str )
    
                    x = x + tw
                end
    
                x, y = scrw / 2, y + th
            end
        end

        local plys = player_GetAll()

        if jiggabooware.cfg.vars[ "Spectator list" ] then
            local y = scrh / 2 

            for i = 1, #plys do
                local v = plys[ i ]

                if not jiggabooware.playerCache[ v ] then continue end
                if jiggabooware.playerCache[ v ].ObserverMode == 0 then continue end 

                surface.SetTextPos( 15, y )
                surface.SetTextColor( jiggabooware.Colors[255] )
                surface.DrawText( v:Name() .. " spectating " .. tostring( jiggabooware.playerCache[ v ].ObserverTarget ) )
            
                y = y + 15
            end
        end 

        



        
    end
    
   
    
end



/*
hook.Add( "PostDrawTranslucentRenderables", "test", function()
    if jiggabooware.targetVector then
        render.DrawWireframeSphere( jiggabooware.targetVector, 0.5, 10, 10, Color( 255, 0, 64 ) )
    end
end)
*/


jiggabooware.kd = false
function jiggabooware.togglevisible()
    if jiggabooware.frame:IsVisible() then
        jiggabooware.frame:SetVisible(false)

        if jiggabooware.ui.MultiComboP then jiggabooware.ui.RemovePanel( jiggabooware.ui.MultiComboP ) end
        if jiggabooware.ui.ColorWindow then jiggabooware.ui.RemovePanel( jiggabooware.ui.ColorWindow ) end
        if jiggabooware.ui.SettingsPan then jiggabooware.ui.RemovePanel( jiggabooware.ui.SettingsPan ) end

        RememberCursorPosition()

        if jiggabooware.validsnd then jiggabooware.validsnd:Pause() end
    else
        jiggabooware.frame:SetVisible(true)

        RestoreCursorPosition()
        if jiggabooware.validsnd then jiggabooware.validsnd:Play() end
    end
end

// dormant esp 
--[[]

function jiggabooware.SetEntPos(ent,pos)
    if not IsValid(ent) or ent == me or not ent:IsDormant() then return end

    ent:SetNetworkOrigin(pos)
    ent:SetRenderOrigin(pos)
end

hook.Add( "EntityEmitSound", "EntSounds", function( data )
    local ent = data.Entity 
    local pos = data.Pos

    if ent:IsPlayer() and ent:Alive() and ent:IsDormant() then
        jiggabooware.SetEntPos(ent,pos)
        print(ent,pos)
    elseif ent:IsWeapon() then
        print(ent)
    end
end)

hook.Add( "PlayerStepSoundTime", "StepSounds", function( ent, type, walking )
    local pos = ent:GetPos()

    if ent:Alive() and ent:IsDormant() then
        jiggabooware.SetEntPos(ent,pos)
        print("steps ",ent,pos)
    end
end)
]]




hook.Add("PrePlayerDraw", "serj.preplayerdraw", function(ply, falgs)
	if ply != me then
        ply.ChatGestureWeight = 0
		for i = 0, 13 do
			if ply:IsValidLayer(i) then
				local seqname = ply:GetSequenceName(ply:GetLayerSequence(i))
				if seqname:StartWith("taunt_") or seqname:StartWith("act_") or seqname:StartWith("gesture_") then
                    ply:SetLayerDuration(i, 0.001)
					break
				end
			end
		end
        
    /*
	elseif ply == me then
        local ndata = jiggabooware.GetLocalNetworkData()
        //local ntang = Angle( 0, ndata.angles_y, 0 )

        //ply:SetPoseParameter("aim_yaw", ndata.angles_y)
        //ply:SetPoseParameter("head_yaw", ndata.angles_y)

        //ply:SetPoseParameter("aim_pitch", ndata.angles_x)
        //ply:SetPoseParameter("head_pitch", ndata.angles_x)

        //ply:InvalidateBoneCache()
        //ply:SetupBones()

        ply:SetNetworkOrigin( ndata.origin )
        ply:SetRenderOrigin( ndata.origin )


  

*/
    

    

    
    end

    if jiggabooware.cfg.vars["Visible chams"] then
        //ply:SetNoDraw( true )
    end
end)


// Chams

CreateMaterial("textured", "VertexLitGeneric") 
CreateMaterial("flat", "UnLitGeneric")
CreateMaterial("flat_z", "UnLitGeneric",{["$ignorez"] = 1})
CreateMaterial("textured_z", "VertexLitGeneric",{["$ignorez"] = 1})

CreateMaterial( "selfillum", "VertexLitGeneric", {
    ["$basetexture"] = "vgui/white_additive",
    ["$bumpmap"] = "vgui/white_additive",
    ["$model"] = "1",
    ["$nocull"] = "0",
    ["$selfillum"] = 1,
    ["$selfIllumFresnel"] = 1,
    ["$selfIllumFresnelMinMaxExp"] = "[0.0 0.3 0.6]",
    ["$selfillumtint"] = "[0 0 0]",
} )

CreateMaterial( "selfillum_z", "VertexLitGeneric", {
    ["$basetexture"] = "vgui/white_additive",
    ["$bumpmap"] = "vgui/white_additive",
    ["$model"] = "1",
    ["$nocull"] = "0",
    ["$selfillum"] = 1,
    ["$selfIllumFresnel"] = 1,
    ["$selfIllumFresnelMinMaxExp"] = "[0.0 0.3 0.6]",
    ["$selfillumtint"] = "[0 0 0]",
    ["$ignorez"] = 1,
} )

CreateMaterial( "selfillum_a", "VertexLitGeneric", {
    ["$basetexture"] = "vgui/white_additive",
    ["$bumpmap"] = "vgui/white_additive",
    ["$model"] = "1",
    ["$nocull"] = "1",
    ["$nodecal"] = "1",
    ["$additive"] = "1",
    ["$selfillum"] = 1,
    ["$selfIllumFresnel"] = 1,
    ["$selfIllumFresnelMinMaxExp"] = "[0.0 0.3 0.6]",
    ["$selfillumtint"] = "[0 0 0]",
} )

CreateMaterial( "selfillum_a_z", "VertexLitGeneric", {
    ["$basetexture"] = "vgui/white_additive",
    ["$bumpmap"] = "vgui/white_additive",
    ["$model"] = "1",
    ["$nocull"] = "1",
    ["$nodecal"] = "1",
    ["$additive"] = "1",
    ["$selfillum"] = 1,
    ["$selfIllumFresnel"] = 1,
    ["$selfIllumFresnelMinMaxExp"] = "[0.0 0.3 0.6]",
    ["$selfillumtint"] = "[0 0 0]",
    ["$ignorez"] = 1,
} )

CreateMaterial("wireframe", "VertexLitGeneric", {
	["$wireframe"] = 1,
})
CreateMaterial("wireframe_z", "VertexLitGeneric", {
	["$wireframe"] = 1,
    ["$ignorez"] = 1,
})

CreateMaterial("metallic", "VertexLitGeneric", {
	["$envmap"] = "env_cubemap",
    ["$envmaptint"] = "[ 0 1 1 ]",
    ["$envmapfresnel"] = "1",
    ["$alpha"] = "0.5",
})

CreateMaterial("metallic_z", "VertexLitGeneric", {
    ["$envmap"] = "env_cubemap",
    ["$envmaptint"] = "[ 0 1 1 ]",
    ["$envmapfresnel"] = "1",
    ["$alpha"] = "0.5",
    ["$ignorez"] = 1,
})

jiggabooware.chamMats = {
    vis = {
        Material("!flat"), -- flat
        Material("!textured"), -- textured
        Material("!selfillum"), -- glow
        Material("!selfillum_a"), -- glow outline
        Material("!wireframe"), -- wireframe
        Material("!metallic"), -- metallic
        Material("effects/nightvision"), -- _rt_fullframefb
        Material("effects/flashbang"), -- _rt_fullframefb
    },
    invis = {
        Material("!flat_z"), -- flat
        Material("!textured_z"), -- textured
        Material("!selfillum_z"), -- glow
        Material("!selfillum_a_z"), -- glow outline
        Material("!wireframe_z"), -- wireframe
        Material("!metallic_z"), -- metallic
        Material("effects/nightvision"), -- _rt_fullframefb
        Material("effects/flashbang"), -- _rt_fullframefb
    }
}
 
do
    local f = (1/255)

    function jiggabooware.drawChams()
        if jiggabooware.UnSafeFrame then return end

        local vm, invm = jiggabooware.cfg.vars["Visible mat"], jiggabooware.cfg.vars["inVisible mat"]
        local sin = math_floor( math_sin( CurTime() * 4 ) * 45 )

        local vc = string_ToColor(jiggabooware.cfg.colors["Visible chams"])
        local invc = string_ToColor(jiggabooware.cfg.colors["inVisible chams"])
        local sc = string_ToColor(jiggabooware.cfg.colors["Self chams"])
        
        cam_Start3D()
            for k, v in pairs(player_GetAll()) do
                if not IsValid(v) or v == me or not v:Alive() or v:IsDormant() then continue end 

                if jiggabooware.cfg.vars["Supress lighting"] then
                    render_SuppressEngineLighting(true)
                end

                if jiggabooware.cfg.vars["inVisible chams"] then
                    jiggabooware.chamMats.invis[6]:SetVector( "$envmaptint", Vector( invc.r / 255, invc.g / 255, invc.b / 255 ) )
                    render_MaterialOverride(jiggabooware.chamMats.invis[invm])
                    render_SetColorModulation(invc.r/255,invc.g/255,invc.b/255) 

                    if invm == 7 then
                        render_SetBlend( (sin + 100) / 255 )
                    end

                    v:SetRenderMode(1)
                    v:DrawModel()

                    if jiggabooware.cfg.vars["inVisible chams w"] then 
                        local w = v:GetActiveWeapon()
                        if IsValid(w) then w:DrawModel() end
                    end
                end

                if jiggabooware.cfg.vars["Visible chams"] then
                    jiggabooware.chamMats.vis[6]:SetVector( "$envmaptint", Vector( vc.r / 255, vc.g / 255, vc.b / 255 ) )
                    render_MaterialOverride(jiggabooware.chamMats.vis[vm])
                    render_SetColorModulation(vc.r/255,vc.g/255,vc.b/255)

                    if vm == 7 then
                        render_SetBlend( (sin + 100) / 255 )
                    end

                    v:DrawModel()

                    if jiggabooware.cfg.vars["Visible chams w"] then 
                        local w = v:GetActiveWeapon()
                        if IsValid(w) then w:DrawModel() end
                    end
                end

                if jiggabooware.cfg.vars["Supress lighting"] then
                    render_SuppressEngineLighting(false)
                end

            end

            if jiggabooware.cfg.vars["Self chams"] and IsValid(me) and me:Alive() then

                if jiggabooware.cfg.vars["Supress self lighting"] then
                    render_SuppressEngineLighting(true)
                end

                jiggabooware.chamMats.invis[6]:SetVector( "$envmaptint", Vector( sc.r / 255, sc.g / 255, sc.b / 255 ) )
                render_MaterialOverride(jiggabooware.chamMats.vis[jiggabooware.cfg.vars["Self mat"]])
                render_SetColorModulation(sc.r/255,sc.g/255,sc.b/255)

                if jiggabooware.cfg.vars["Self mat"] == 7 then
                    render_SetBlend( (sin + 100) / 255 )
                end

                me:SetRenderMode(1)
                me:DrawModel()

                if jiggabooware.cfg.vars["Self chams w"] then 
                    local w = me:GetActiveWeapon()
                    if IsValid(w) then w:DrawModel() end
                end
              
                if jiggabooware.cfg.vars["Supress self lighting"] then
                    render_SuppressEngineLighting(false)
                end

            end

            


        cam_End3D()

        render_SetColorModulation(1, 1, 1)
        render_SetBlend(1)
        render_MaterialOverride()
    end
end


// Client side models 

function jiggabooware.CS_Model(mdl)
    local model = ClientsideModel(mdl)
	model:SetNoDraw(true)

    return model
end

function jiggabooware.CS_Model_update(ply,model,tbl)
    if !tbl then return end

    local mdl = model
    local playerModel = ply:GetModel()
    local layers = tbl.layers 

    for i = 0, 13 do
        if mdl:IsValidLayer(i) then
            local l = layers[i]
            mdl:SetLayerCycle(l.cycle)
            mdl:SetLayerSequence(l.sequence)
            mdl:SetLayerWeight(l.weight)
        end
    end

    mdl:SetSequence(tbl.sequence)
    mdl:SetCycle(tbl.cycle)

    mdl:SetPoseParameter("aim_pitch", tbl.angles.p)
	mdl:SetPoseParameter("head_pitch", 0)
	mdl:SetPoseParameter("body_yaw", tbl.angles.y)
	mdl:SetPoseParameter("aim_yaw", 0)
		
	mdl:SetPoseParameter("move_x", tbl.movex)
	mdl:SetPoseParameter("move_y", tbl.movey)

    mdl:SetAngles( Angle( 0, tbl.angles.y, 0 ) )
    mdl:SetModel( playerModel )
	mdl:SetPos( tbl.origin )
end

function jiggabooware.PostDrawTranslucentRenderables()
    if jiggabooware.UnSafeFrame then return end

    jiggabooware.drawCSModels_backtrack()
    jiggabooware.drawCSModels_real()

    render_SetBlend(1)
    render_MaterialOverride()
end


// Backtracking 

jiggabooware.btrecords = {}
jiggabooware.predicted = {}

















function jiggabooware.canBacktrack(ply)
    if not jiggabooware.cfg.vars["Backtrack"] then return false end 
    if not IsValid(ply) then return false end
    if not jiggabooware.btrecords[ply] then return false end 
    if ply.break_lc then return false end 

    return true 
end

function jiggabooware.recordBacktrack(ply)
	local deadtime = CurTime() - jiggabooware.cfg.vars["Backtrack time"] / 1000
	
	local records = jiggabooware.btrecords[ply]

	if !records then
        records = {}
		jiggabooware.btrecords[ply] = records
	end
	
	local i = 1
	while i < #records do
		local record = records[i]
		
		if record.simulationtime < deadtime then
			table_remove(records, i)
			i = i - 1
		end
		
		i = i + 1
	end
	
	if !ply:Alive() then return end
    if ply.break_lc then return end
	
	local simulationtime = ded.GetSimulationTime(ply:EntIndex())
	local len = #records
	local simtimechanged = true

	if len > 0 then
		simtimechanged = records[len].simulationtime < simulationtime
	end
	
	if !simtimechanged then return end

	local layers = {}
	for i = 0, 13 do
		if ply:IsValidLayer(i) then
			layers[i] = {
				cycle = ply:GetLayerCycle(i),
				sequence = ply:GetLayerSequence(i),
				weight = ply:GetLayerWeight(i)
			}
		end
	end

    local eyeAngles = ply:EyeAngles()
    local x,y = eyeAngles.x, eyeAngles.y

    local bdata = {}
    for i = 0, ply:GetBoneCount() - 1 do
        local v, a = ply:GetBonePosition( i )
        bdata[i] = { vec = v, ang = a }
    end

    local hdata = {}
    local hset = ply:GetHitboxSet()
    local hnum = ply:GetHitBoxCount( hset )
    
    for hitbox = 0, hnum - 1 do
        local bone = ply:GetHitBoxBone( hitbox, hset )
  
        if bone == nil then continue end

        local mins, maxs = ply:GetHitBoxBounds( bone, hset )

        if not mins or not maxs then continue end 

        local bonepos, ang = ply:GetBonePosition( bone )  
        mins:Rotate( ang )
        maxs:Rotate( ang )

        hdata[ #hdata + 1 ] = { pos = bonepos, mins = mins, maxs = maxs }
    end

    local skeletondata = {}

    /*
    for i = 0, ply:GetBoneCount() - 1 do

        local parent = ply:GetBoneParent(i)

        if(!parent) then continue end

        local bonepos = ply:GetBonePosition(i)

        if(bonepos == ply:GetPos() ) then continue end

        local parentpos = ply:GetBonePosition(parent)

        if(!bonepos or !parentpos) then continue end

        skeletondata[ 1 ] = bonepos:ToScreen()
        skeletondata[ 2 ] = parentpos:ToScreen()
    end
    */

	records[len + 1] = {
		simulationtime =    ded.GetSimulationTime(ply:EntIndex()),
		angles =            Angle(x,y,0),
		origin =            ply:GetNetworkOrigin(),
		aimpos =            jiggabooware.GetBones( ply )[1],
		sequence =          ply:GetSequence(),
		cycle =             ply:GetCycle(),
		layers =            layers,
        movex =             ply:GetPoseParameter("move_x"),
        movey =             ply:GetPoseParameter("move_y"),
        bonedata =          bdata,
        //hitboxdata =        hdata,
        //skeleton =          skeletondata
    }
end

jiggabooware.btmodel = jiggabooware.CS_Model("models/player/kleiner.mdl")

function jiggabooware.drawCSModels_backtrack()
    if not jiggabooware.cfg.vars["Backtrack chams"] then return end 
    if not jiggabooware.canBacktrack(jiggabooware.target) then return end

    local len = #jiggabooware.btrecords[jiggabooware.target]
    local tbl = jiggabooware.btrecords[jiggabooware.target][jiggabooware.backtracktick]
    local m = jiggabooware.btmodel

    jiggabooware.CS_Model_update(jiggabooware.target,m,tbl)

    if jiggabooware.cfg.vars["Backtrack fullbright"] then
        render_SuppressEngineLighting(true)
    end

    local col = string_ToColor(jiggabooware.cfg.colors["Backtrack chams"])
    jiggabooware.chamMats.invis[6]:SetVector( "$envmaptint", Vector( col.r / 255, col.g / 255, col.b / 255 ) )
    render_MaterialOverride(jiggabooware.chamMats.invis[jiggabooware.cfg.vars["Backtrack material"]]) 
    render_SetColorModulation(col.r/255,col.g/255,col.b/255)
    m:SetRenderMode(1)
    m:DrawModel()

    if jiggabooware.cfg.vars["Backtrack fullbright"] then
        render_SuppressEngineLighting(false)
    end
end

jiggabooware.hitmarkers = {}
jiggabooware.hitnums = {}

gameevent.Listen( "player_hurt" )
hook_Add("player_hurt", "penissss1337", function(data)
    local health = data.health
	local priority = SERVER and data.Priority or 5
	local hurted = Player( data.userid )
	local attackerid = data.attacker

	if attackerid == me:UserID() then
        
        if jiggabooware.cfg.vars[ "On screen logs" ] then
            local hlcolor = string_ToColor( jiggabooware.cfg.colors[ "On screen logs" ] )
            local data = {
                tick = engine.TickCount(),
                {
                    "Hit ",
                    hurted:Name(),
                    " for ",
                    hurted:Health() - health,
                    " damage"
                },
                {
                    jiggabooware.HitLogsWhite,
                    hlcolor,
                    jiggabooware.HitLogsWhite,
                    hlcolor,
                    jiggabooware.HitLogsWhite,
                }
            }
            
            jiggabooware.onScreenLogs[ engine.TickCount() ] = data
            print( "hurt", engine.TickCount() )
        end

        if jiggabooware.cfg.vars["Hitmarker"] then
            jiggabooware.hitmarkers[ #jiggabooware.hitmarkers + 1 ] = { time = CurTime(), add = 0 }
        end

        if jiggabooware.cfg.vars["Hitnumbers"] then
            local hp = hurted:Health() - health
            jiggabooware.hitnums[ #jiggabooware.hitnums + 1 ] = { time = CurTime(), add = 0, xdir = math_random(-1,1), ydir = math_random(-1,1), dmg = hp, crit = health <= 0 }
        end

        if jiggabooware.cfg.vars["Hitsound"] then
            surface_PlaySound( jiggabooware.cfg.vars["Hitsound str"] )
        end

        if jiggabooware.cfg.vars["Resolver"] then 
            hurted.aimshots = (hurted.aimshots or 0) - 1
        end

    end
end)

/*
    Player vars 
*/

function jiggabooware.initPlayerVars( v )
    v.ult_prev_pos = Vector()

    v.ult_prev_simtime = 0 
    v.flticks = 0 
    v.aimshots = 0
    v.missedanimticks = 0

    v.break_lc = false 
    v.simtime_updated = false 
    v.fakepitch = false

    jiggabooware.btrecords[ v ] = {}
    jiggabooware.predicted[ v ] = {}
end

for k, v in ipairs(player_GetAll()) do
	jiggabooware.initPlayerVars( v )
end

/*
    Killsay / chatspam

    jiggabooware.ui.CheckBox( p, "Killsay", "Killsay" )
jiggabooware.ui.CheckBox( p, "Chat spam", "Chat spammer" )

jiggabooware.ui.ComboBox( p, "Mode", { "Лучшее 22-23", "Унижалка", "Школа хвх", "AI унижалка", "Игра пилы", "В.В. Путин", "Arabic", "українська мова" }, "Chat mode")
jiggabooware.ui.ComboBox( p, "Group", { "Normal", "/OOC", "Advert", "PM", "ULX" }, "Chat group")

*/


jiggabooware.chatmsg = {
    killsay = {
        { // Лучшие 22-23
            "1 нищий упал",
            "$$$ кешбек по зубам $$$",
            "╭∩╮( ⚆ ʖ ⚆)╭∩╮ ДоПрыГался(ت)ДрУжоЧеК",
            "ты куда жертва козьего аборта",
            "iq?",
            "·٠●•۩۞۩ОтДыХаЙ (ٿ) НуБяРа۩۞۩•●٠·",
            "але , а противники то где???",
            "ты по легиту играешь ?",
            "ебать ты красиво на бутылку присел , тебе дать альт ?",
            "свежий кабанчик",
            "АХАХА ЕБАТЬ У ТЕБЯ ЧЕРЕПНАЯ КОРОБКА ПРЯМ КАК [XML-RPC] No-Spread 24/7 | aim_ag_texture_2 ONLY!",
            "на мыло и веревку то деньги есть????",
            "откисай сочняра",
            "Вот тебе паяльник , запаяй себе ебальник",
            "сразу видно кфг иссуе мб конфиг у меня прикупишь ?",
            "Я твою маму дуже сильно поважаю , нехай береже її Степан Бендера",
            "упал хуета ебаная , но в боди забрал да похуй все равно упал",
            "не противник",
            "Loading… ██████████ Lifehack.cfg Activated",
            "Tapt by Anti-Hack",
            "чето умер...",
            "Найс софт чел без читов ты 0",
            "Чел ты без читов 0",
            "Держи зонтик тебя абасали",
            "Го 1 на 1 или зассал?Точно ты же до 1 считать не умееш...",
            "упавший на медию никогда не встанет с колен.",
            "Черные глаза Вспоминаю — умираю Черные глаза Я только о тебе мечтаю",
            "меня админ заставляет это заинжектить",
            "через процесс хакер инжектить?",
            "лол ору ты прямо как 𓀐𓂸𓀐𓂸𓀐𓂸𓀐𓂸𓀐𓂸",
            "обе чернокожие головы превратились в кубики льда… Бере.",
            "99 имен Аллаhа для детей",
            "Rindfleischetikettierungsüberwachungsaufgaben- übertragungsgesetz",
            "Лето 2015",
            "у тебя член не конский не по масти эпик фейл",
            "rnj ghjxbnfk njn utq",
            "гелим гелим гелим на валике",
            "Приходи один работёнка есть!, координаты: 55.8653382,49.304329",
        },
        { // Унижение
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
        },
    },




 

  




}



// Init player vars 
gameevent.Listen("player_spawn")
gameevent.Listen( "player_activate" )
gameevent.Listen( "entity_killed" )

hook.Add( "entity_killed", "entity_killed_example", function( data ) 
	local aid = data.entindex_attacker 		
	local vid = data.entindex_killed 	

    if aid != vid and Player( vid ):IsPlayer() and aid == me:EntIndex() then
        if jiggabooware.cfg.vars["Killsay"] then
            local tbl = jiggabooware.chatmsg.killsay[ jiggabooware.cfg.vars["Killsay mode"] ]
            local str = tbl[ math_random( 1, #tbl ) ]
            gRunCmd( "say", str )
        end
        
        if jiggabooware.cfg.vars["Killsound"] then
            surface_PlaySound( jiggabooware.cfg.vars["Killsound str"] )
        end

     
    end
end )



function jiggabooware.updatePlayerVars( data )
    local id = data.userid  

    local ply = Player( id )

    ply.ult_prev_pos = Vector()
    // ply.ult_prev_hitbox_pos = Vector()
    
    ply.ult_prev_simtime = 0
    ply.flticks = 0
        
    ply.simtime_updated = false
    ply.break_lc = false
    ply.fakepitch = false

    jiggabooware.btrecords[ ply ] = {}
    jiggabooware.predicted[ ply ] = {}
end



















// Menu hints 

function jiggabooware.drawOverlay()
    if jiggabooware.UnSafeFrame then return end
    if not jiggabooware.frame:IsVisible() then return end

    if not jiggabooware.hint then
        jiggabooware.hintText = ""
        return
    end

    surface_SetTextColor(jiggabooware.Colors[165])
    surface_SetFont("tbfont")

    local tw, th = surface_GetTextSize(jiggabooware.hintText)

    surface_SetDrawColor(jiggabooware.Colors[35])
    surface_DrawRect(jiggabooware.hintX,jiggabooware.hintY,tw+20,th+10)
    surface_SetDrawColor(jiggabooware.Colors[54])
    surface_DrawOutlinedRect(jiggabooware.hintX,jiggabooware.hintY,tw+20,th+10,1)    

    surface_SetTextPos(jiggabooware.hintX+10,jiggabooware.hintY+5)
    surface_DrawText(jiggabooware.hintText)

    jiggabooware.hint = false
end


// Gamemode UpdateClientsideAnimation
--[[]
local function RunSandboxAnims(ply, velocity, maxseqgroundspeed)
    local len = velocity:Length()
	local movement = 1.0

	if ( len > 0.2 ) then
		movement = ( len / maxseqgroundspeed )
	end

	local rate = math.min( movement, 2 )

	-- if we're under water we want to constantly be swimming..
	if ( ply:WaterLevel() >= 2 ) then
		rate = math.max( rate, 0.5 )
	elseif ( !ply:IsOnGround() && len >= 1000 ) then
		rate = 0.1
	end

	ply:SetPlaybackRate( rate )

	-- We only need to do this clientside..
	if ( CLIENT ) then
		if ( ply:InVehicle() ) then
			--
			-- This is used for the 'rollercoaster' arms
			--
			local Vehicle = ply:GetVehicle()
			local Velocity = Vehicle:GetVelocity()
			local fwd = Vehicle:GetUp()
			local dp = fwd:Dot( Vector( 0, 0, 1 ) )

			ply:SetPoseParameter( "vertical_velocity", ( dp < 0 && dp || 0 ) + fwd:Dot( Velocity ) * 0.005 )

			-- Pass the vehicles steer param down to the player
			local steer = Vehicle:GetPoseParameter( "vehicle_steer" )
			steer = steer * 2 - 1 -- convert from 0..1 to -1..1
			if ( Vehicle:GetClass() == "prop_vehicle_prisoner_pod" ) then steer = 0 ply:SetPoseParameter( "aim_yaw", math.NormalizeAngle( ply:GetAimVector():Angle().y - Vehicle:GetAngles().y - 90 ) ) end
			ply:SetPoseParameter( "vehicle_steer", steer )

		end
	end
end

function GAMEMODE:UpdateAnimation(plr, velocity, maxSeqGroundSpeed)
    local hResult = self.BaseClass.UpdateAnimation(self, plr, velocity, maxSeqGroundSpeed)

    RunSandboxAnims(plr, velocity, maxSeqGroundSpeed)
    return hResult;
end
]]



/*
    Libs -> Color
*/



//function jiggabooware.


function jiggabooware.ColorLerp( first, second )
    local FT = FrameTime() * 350

    first.r = math_Approach( first.r, second.r, FT )
    first.g = math_Approach( first.g, second.g, FT )
    first.b = math_Approach( first.b, second.b, FT )
    first.a = math_Approach( first.a, second.a, FT )

    math_Round( first.r, 0 )
    math_Round( first.g, 0 )
    math_Round( first.b, 0 )
    math_Round( first.a, 0 )

    return first
end

function jiggabooware.ColorEqual( first, second )
    if first.r != second.r or first.g != second.g or first.b != second.b or first.a != second.a then
        return false
    end

    return true 
end





/* 
    hooks -> Think 
*/

jiggabooware.ekd = false
jiggabooware.fbkd = false

// Dancer ( act / taunt spam )

jiggabooware.nextact = 0
jiggabooware.actCommands = {"robot","muscle","laugh","bow","cheer","wave","becon","agree","disagree","forward","group","half","zombie","dance","pers","halt","salute"}

// Name changer 

do
    local cooldown = GetConVarNumber("sv_namechange_cooldown_seconds")
    local curtime = CurTime()
    local lastname = me:Name()
    local changed = 0

    local function check(pl,mn,ptbl)
        if pl == me then return false end 

        if pl:Name() == mn then return false end

        if #ptbl > 5 then
            if lastname == pl:Name() then return  false end
        end

        return true
    end

    local function changename(name)
        ded.NetSetConVar("name",name.." ")

        if changed >= 2 then
            changed = 0
            lastname = name
        else
            changed = changed + 1
        end

        curtime = CurTime() + cooldown
    end

    function jiggabooware.nameChanger() 
        if curtime > CurTime() then return end

        local pltbl = player_GetAll()

        local len = me:Name():len()

        local mname = string.sub(me:Name(),1,len-1)

        local i = math_random(1,#pltbl)

        if not check(pltbl[i],mname,pltbl) then return end

        changename(pltbl[i]:Name())
    end
end

do
    local tply
    local chatdelay = CurTime()
    local inverterdown = false
        
    function jiggabooware.hThink()
        if input_IsKeyDown(KEY_DELETE) and not jiggabooware.kd then 
            jiggabooware.togglevisible()
    
            CloseDermaMenus()
        end

        jiggabooware.kd = input_IsKeyDown(KEY_DELETE)

        if jiggabooware.IsKeyDown( jiggabooware.cfg.binds["Ent add"] ) and not jiggabooware.ekd then
            local tr = me:GetEyeTrace().Entity

            if IsValid( tr ) then 
                local class = tr:GetClass()

                //print( jiggabooware.allowedClasses[ class ] )

                if not jiggabooware.allowedClasses[ class ] then
                    jiggabooware.allowedClasses[ class ] = true
                else
                    jiggabooware.allowedClasses[ class ] = not jiggabooware.allowedClasses[ class ]
                end
            end
        end

        if jiggabooware.cfg.vars["Inverter"] and jiggabooware.IsKeyDown( jiggabooware.cfg.binds["Inverter"] ) and not inverterdown then
            jiggabooware.inverted = !jiggabooware.inverted 
        end

        inverterdown = jiggabooware.IsKeyDown( jiggabooware.cfg.binds["Inverter"] )

        jiggabooware.ekd = jiggabooware.IsKeyDown( jiggabooware.cfg.binds["Ent add"] )

        if jiggabooware.IsKeyDown( jiggabooware.cfg.binds["Fullbright"] ) and not jiggabooware.fbkd then
            jiggabooware.fbe = not jiggabooware.fbe
        end

        jiggabooware.fbkd = jiggabooware.IsKeyDown( jiggabooware.cfg.binds["Fullbright"] )

        if jiggabooware.cfg.vars["FSpec ClickTP"] and jiggabooware.IsKeyDown( jiggabooware.cfg.binds["FSpec ClickTP"] ) then
            local pos = me:GetEyeTrace().HitPos
            
            //print(pos)

            //gRunCmd( "ba", "spec" )

            gRunCmd( "FTPToPos", string_format("%d, %d, %d", pos.x, pos.y, pos.z), string_format("%d, %d, %d", 0, 0, 0) )
        end

        
        
        // jiggabooware.cfg.vars["FSpec Teleport"] = false
        // jiggabooware.cfg.binds["FSpec Teleport"] = 0
        
        // jiggabooware.cfg.vars["FSpec Masskill"] = false
        // jiggabooware.cfg.binds["FSpec Masskill"] = 0
        
        // jiggabooware.cfg.vars["FSpec Velocity"] = false
        // jiggabooware.cfg.binds["FSpec Velocity"] = 0

        if jiggabooware.cfg.vars["Chat spammer"] and CurTime() > chatdelay then
            local s = jiggabooware.cfg.vars["Chat OOC"] and "// " or ""

            gRunCmd("say",s.."1")

            chatdelay = CurTime() + 0.5
        end
    
        if jiggabooware.cfg.vars["Name stealer"] then jiggabooware.nameChanger() end
    
        if ded.GetCurrentCharge() < jiggabooware.cfg.vars["Shift ticks"] then ded.StartShifting( false ) end

        if jiggabooware.cfg.vars["Tickbase shift"] then 
            if jiggabooware.IsKeyDown( jiggabooware.cfg.binds["Tickbase shift"] ) then
                ded.StartShifting( true )
            end
            
            local shouldcharge =  ded.GetCurrentCharge() < jiggabooware.cfg.vars["Charge ticks"] and jiggabooware.IsKeyDown( jiggabooware.cfg.binds["Auto recharge"] )
            
            ded.StartRecharging( shouldcharge )
        
            if shouldcharge then
                ded.StartShifting( false )
            end
        end
    
        if jiggabooware.cfg.vars["Taunt spam"] and jiggabooware.nextact < CurTime() and me:Alive() and !me:IsPlayingTaunt() then 
            local act = jiggabooware.actCommands[jiggabooware.cfg.vars["Taunt"]]
    
            gRunCmd("act", act)
            jiggabooware.nextact = CurTime() + 0.3
        end
    
        if jiggabooware.cfg.vars["Yaw base"] == 2 then
            tply = jiggabooware.GetSortedPlayers( 1, 0, 1, false ) 
    
            if tply then
                jiggabooware.aatarget = tply[1][1]
            end
        end

        if jiggabooware.cfg.vars["Auto peak"] then
            jiggabooware.autopeakThink()
        end
    end
end


/*
    hooks -> CalcView
*/

jiggabooware.vieworigin = me:EyePos()
jiggabooware.viewfov    = 0
jiggabooware.znear      = 0

jiggabooware.tpenabled = false
jiggabooware.tptoggled = false

jiggabooware.fcvector = me:EyePos()
jiggabooware.fcangles = me:EyeAngles()
jiggabooware.fcenabled = false
jiggabooware.fctoggled = false


/* // TODO
jiggabooware.checkbox("Collision","Third person collision",p:GetItemPanel())
jiggabooware.checkbox("Smoothing","Third person smoothing",p:GetItemPanel())

jiggabooware.slider("X","Viewmodel x",1,180,0,p:GetItemPanel())
jiggabooware.slider("Y","Viewmodel y",1,180,0,p:GetItemPanel())
jiggabooware.slider("Z","Viewmodel z",1,180,0,p:GetItemPanel())
jiggabooware.slider("Roll","Viewmodel r",1,360,0,p:GetItemPanel())
*/

jiggabooware.cameraHullMax = Vector( 3, 3, 3 )
jiggabooware.cameraHullMin = Vector( -3, -3, -3 )
function jiggabooware.hCalcView( ply, origin, angles, fov, znear, zfar )

    if jiggabooware.UnSafeFrame then 
        return { origin = origin, angles = angles, fov = fov } 
    end

    local view = {}

    local tppressed = jiggabooware.IsKeyDown(jiggabooware.cfg.binds["Third person"])
    local fcpressed = jiggabooware.IsKeyDown(jiggabooware.cfg.binds["Free camera"])

    if jiggabooware.cfg.vars["Third person"] and tppressed and not jiggabooware.tptoggled then
        jiggabooware.tpenabled = not jiggabooware.tpenabled
    end

    if jiggabooware.cfg.vars["Free camera"] and fcpressed and not jiggabooware.fctoggled then
        jiggabooware.fcenabled = not jiggabooware.fcenabled
        jiggabooware.fcangles = me:EyeAngles()
    elseif jiggabooware.fcenabled and not jiggabooware.cfg.vars["Free camera"] then
        jiggabooware.fcenabled = false
    end

    jiggabooware.tptoggled = tppressed
    jiggabooware.fctoggled = fcpressed


    if jiggabooware.cfg.vars["Fake duck"] and jiggabooware.IsKeyDown(jiggabooware.cfg.binds["Fake duck"]) then
        origin.z = me:GetPos().z + 64
    end

    local fangs = jiggabooware.cfg.vars["Silent aim"] and jiggabooware.SilentAngle or angles

    //angles = fangs
    //if not jiggabooware.cfg.vars[ "Norecoil" ] then
    //    angles:Add( ply:GetViewPunchAngles() )
    //end

    if jiggabooware.fcenabled then
        local speed = jiggabooware.cfg.vars["Free camera speed"]
        
        if input_IsKeyDown(KEY_W) then
            jiggabooware.fcvector = jiggabooware.fcvector + jiggabooware.SilentAngle:Forward() * speed
        end

        if input_IsKeyDown(KEY_S) then
            jiggabooware.fcvector = jiggabooware.fcvector - jiggabooware.SilentAngle:Forward() * speed
        end

        if input_IsKeyDown(KEY_A) then
            jiggabooware.fcvector = jiggabooware.fcvector - jiggabooware.SilentAngle:Right() * speed
        end

        if input_IsKeyDown(KEY_D) then
            jiggabooware.fcvector = jiggabooware.fcvector + jiggabooware.SilentAngle:Right() * speed
        end

        if input_IsKeyDown(KEY_SPACE) then
            jiggabooware.fcvector.z = jiggabooware.fcvector.z + speed
        end

        if input_IsKeyDown(KEY_LSHIFT) then
            jiggabooware.fcvector.z = jiggabooware.fcvector.z - speed
        end

        view.origin = jiggabooware.fcvector
        view.angles = fangs
        view.fov = jiggabooware.cfg.vars["Fov override"]
        view.drawviewer = !jiggabooware.cfg.vars["Ghetto free cam"]
    else
        jiggabooware.fcvector = origin
        view.origin = jiggabooware.tpenabled and origin - ( (fangs):Forward() * jiggabooware.cfg.vars["Third person distance"] ) or origin

        if jiggabooware.tpenabled and jiggabooware.cfg.vars["Third person collision"] then
            local tr = {}

            tr.start = origin
            tr.endpos = origin - ( (fangs):Forward() * jiggabooware.cfg.vars["Third person distance"] )
            tr.mins = jiggabooware.cameraHullMin
            tr.maxs = jiggabooware.cameraHullMax
            tr.filter = ply
            tr.mask = MASK_BLOCKLOS

            local res = TraceHull( tr )

            view.origin = res.HitPos
        end

        view.angles = fangs
        view.fov = jiggabooware.cfg.vars["Fov override"]
        view.drawviewer = jiggabooware.tpenabled
    end

    jiggabooware.vieworigin = ( jiggabooware.cfg.vars["Ghetto free cam"] and jiggabooware.fcenabled ) and jiggabooware.fcvector or origin
    jiggabooware.viewfov    = view.fov
    jiggabooware.znear      = znear

	return view
end

function jiggabooware.GetFovRadius()
    local Radius = jiggabooware.cfg.vars["Aimbot FOV"]

    local Ratio = scrw / scrh
    local AimFOV = Radius * (math.pi / 180)
    local GameFOV = jiggabooware.viewfov * (math.pi / 180)
    local ViewFOV = 2 * math.atan(Ratio * (jiggabooware.znear / 2) * math.tan(GameFOV / 2))



    return (math.tan(AimFOV) / math.tan(ViewFOV / 2)) * scrw
end

/*
    hooks -> CalcViewModelView
*/

function jiggabooware.hCalcViewModelView(wep, vm, oldPos, oldAng, pos, ang)
    if wep.CalcViewModelView then wep.CalcViewModelView = nil end

    pos = jiggabooware.vieworigin 
	ang = jiggabooware.cfg.vars["Silent aim"] and jiggabooware.SilentAngle or ang

	return pos, ang
end

/*
    hooks -> Pre / Post DrawViewModel
*/

do
    local drawing = false

    function jiggabooware.hPreDrawViewModel( vm, ply, w )
        if jiggabooware.UnSafeFrame then return end
        if ply != me then return end

        if jiggabooware.cfg.vars["Viewmodel chams"] then
            local col = string_ToColor( jiggabooware.cfg.colors["Viewmodel chams"] )
            jiggabooware.chamMats.vis[6]:SetVector( "$envmaptint", Vector( col.r / 255, col.g / 255, col.b / 255 ) )
            local mat = jiggabooware.chamMats.vis[jiggabooware.cfg.vars["Viewmodel chams type"]] 

            render_SetBlend(col.a/255)
            render_SetColorModulation(col.r/255,col.g/255,col.b/255)
            render_MaterialOverride(mat)
        end

        if jiggabooware.cfg.vars["Fullbright viewmodel"] then
            render_SuppressEngineLighting( true )
        end

        if jiggabooware.cfg.vars["Viewmodel fov"] != GetConVar("viewmodel_fov"):GetInt() and not drawing then 
            cam.IgnoreZ(true)
                cam.Start3D(nil, nil, jiggabooware.cfg.vars["Viewmodel fov"])
                drawing = true

                vm:DrawModel()

                drawing = false
                cam.End3D()
            cam.IgnoreZ(false)
        else
            return 
        end
        
        return true
    end

end

function jiggabooware.hPostDrawViewModel( vm, ply, w )
    render_SetColorModulation(1, 1, 1)
    render_MaterialOverride()
    render_SetBlend(1)
    render_SuppressEngineLighting(false)
end

/*
    hooks -> OnImpact ( c++ module )
*/
jiggabooware.bulletImpacts = {}

function jiggabooware.hOnImpact( data )
    local startpos = data.m_vStart 

    if jiggabooware.cfg.vars[ "Bullet tracers muzzle" ] and data.m_vStart == me:EyePos() then
        local vm = me:GetViewModel()
	    local wep = me:GetActiveWeapon()

        if vm && IsValid( wep ) && IsValid( vm ) then
            local muzzle = vm:LookupAttachment( "muzzle" )
			
		    if muzzle == 0 then
			    muzzle = vm:LookupAttachment( "1" )
		    end

            if vm:GetAttachment( muzzle ) then
                startpos = vm:GetAttachment( muzzle ).Pos
            end
        end
    end

    jiggabooware.bulletImpacts[#jiggabooware.bulletImpacts + 1] = {
        shootTime = CurTime(),
        startPos = startpos,
        endPos = data.m_vOrigin,
        hitbox = data.m_nHitbox,
        alpha = 255
    }
end


/*
    hooks -> PostDrawOpaqueRenderables
*/

do
    local oldtrmat = jiggabooware.cfg.vars["Bullet tracers material"]
    local tracemat = Material("sprites/tp_beam001")

    local realcolor, fakecolor, lbycolor = Color( 0, 255, 0 ), Color( 255, 0, 0 ), Color( 0, 0, 255 )

    function jiggabooware.hPostDrawOpaqueRenderables()
        if jiggabooware.UnSafeFrame then return end

        if jiggabooware.cfg.vars["Angle arrows"] then
            local pos = me:GetPos()

            cam_IgnoreZ(true)

            cam_Start3D2D( pos, Angle(0, jiggabooware.realAngle.y + 45, 0), 1 )
                surface_SetDrawColor( realcolor )
                surface_DrawLine( 0, 0, 25, 25 )
            cam_End3D2D()
    
            cam_Start3D2D( pos, Angle(0, jiggabooware.fakeAngles.angle.y + 45, 0), 1 )
                surface_SetDrawColor( fakecolor )
                surface_DrawLine( 0, 0, 25, 25 )
            cam_End3D2D()
    
            local lby = ded.GetCurrentLowerBodyYaw( me:EntIndex() )
            cam_Start3D2D( pos, Angle(0, lby + 45, 0), 1 )
                surface_SetDrawColor( lbycolor )
                surface_DrawLine( 0, 0, 25, 25 )
            cam_End3D2D()
    
            cam_IgnoreZ( false )
        end

        if jiggabooware.cfg.vars["Bullet tracers"] then
            local trmat = jiggabooware.cfg.vars["Bullet tracers material"] 
    

            //print( trmat, oldtrmat )
            if trmat != oldtrmat then
                tracemat = Material( trmat )
                oldtrmat = trmat
            end
    
            local tracercolor = string_ToColor(jiggabooware.cfg.colors["Bullet tracers"])
    
            local curTime = CurTime()
            local dieTime = jiggabooware.cfg.vars["Tracers die time"]
    
            for i = #jiggabooware.bulletImpacts, 1, -1 do
                local impact = jiggabooware.bulletImpacts[i]

                // impact.alpha = impact.alpha - 0.15

                if (curTime - impact.shootTime) > dieTime then
                    table_remove(jiggabooware.bulletImpacts, i)
                    continue
                end

                tracercolor.a = impact.alpha
    
                render_SetMaterial( tracemat ) 
                render_DrawBeam( impact.startPos, impact.endPos, 4, 1, 1, tracercolor )
            end
        end

        

        if jiggabooware.cfg.vars["Auto peak"] and jiggabooware.startedPeeking then
            jiggabooware.drawAutopeak()
        end


    end 
end

/*
    hooks -> FrameStageNotify ( c++ module )
*/

// Player data tables 

jiggabooware.playerTbl = FindMetaTable("Player")

jiggabooware.playerCache = {}
function jiggabooware.playerTableUpdate( ply )
    jiggabooware.playerCache[ ply ].Name = ply:Name()

    local t = ply:Team()

    jiggabooware.playerCache[ ply ].Team = t
    jiggabooware.playerCache[ ply ].TeamColor = team_GetColor( t ) 
    jiggabooware.playerCache[ ply ].TeamName = team_GetName( t )

    jiggabooware.playerCache[ ply ].GetUserGroup = ply:GetUserGroup()

    jiggabooware.playerCache[ ply ].Health = ply:Health()
    jiggabooware.playerCache[ ply ].GetMaxHealth = ply:GetMaxHealth()


    jiggabooware.playerCache[ ply ].Armor = ply:Armor()
    jiggabooware.playerCache[ ply ].GetMaxArmor = ply:GetMaxArmor()

    jiggabooware.playerCache[ ply ].GetPos = ply:GetPos()

    jiggabooware.playerCache[ ply ].ObserverMode = ply:GetObserverMode()
    jiggabooware.playerCache[ ply ].ObserverTarget = ply:GetObserverTarget()

    local w = ply:GetActiveWeapon()

    jiggabooware.playerCache[ ply ].WeaponClass = IsValid(w) and ( jiggabooware.cfg.vars["Weapon printname"] and language.GetPhrase( w:GetPrintName() ) or w:GetClass() ) or "Unarmed"
    jiggabooware.playerCache[ ply ].WeaponAmmo = IsValid(w) and w:Clip1() or "-"
 
    jiggabooware.playerCache[ ply ].MoneyVar = jiggabooware.playerTbl.getDarkRPVar and DarkRP.formatMoney(ply:getDarkRPVar("money")) or "beggar"
end  
 
function jiggabooware.playerDataUpdate( ply )
    if not jiggabooware.playerCache[ ply ] then
        jiggabooware.playerCache[ ply ] = {}

        jiggabooware.playerTableUpdate( ply )
        return
    end

    jiggabooware.playerTableUpdate( ply )
end

// Entity data

jiggabooware.entityCache = {}
jiggabooware.allowedClasses = {}

function jiggabooware.entTableUpdate()
    local entitys = ents_GetAll()

    jiggabooware.entityCache = {}

    for i = 1, #entitys do
        local ent = entitys[ i ]

        if not IsValid( ent ) then continue end 
        if not jiggabooware.allowedClasses[ ent:GetClass() ] then continue end

        jiggabooware.entityCache[ #jiggabooware.entityCache + 1 ] = {
            entity = ent,
            class = ent:GetClass(),
            position = ent:GetPos(),
        }
    end
end



// Resolver 

jiggabooware.bruteYaw = { -90, 0, 90, 180, -180, 180, 90, 0, -90 }

















do
    local localData = {}

    localData.origin = Vector()

    function jiggabooware.FillLocalNetworkData( netdata )
        localData.origin     =   netdata[1]
    end
    
    function jiggabooware.GetLocalNetworkData()
        return localData
    end
end


do
    local missedTicks = 0
    local lastSimTime = 0

    local FRAME_START = 0
    local FRAME_NET_UPDATE_START = 1
    local FRAME_NET_UPDATE_POSTDATAUPDATE_START = 2
    local FRAME_NET_UPDATE_POSTDATAUPDATE_END = 3
    local FRAME_NET_UPDATE_END = 4
    local FRAME_RENDER_START = 5
    local FRAME_RENDER_END = 6

    function jiggabooware.hFrameStageNotify( stage )
        local plys = player.GetAll()

        if stage == FRAME_NET_UPDATE_POSTDATAUPDATE_END then

            jiggabooware.entTableUpdate()

            plys = player.GetAll()

            local orig = me:GetNetworkOrigin()

            local data = {}

            data[1] = orig      // last networked origin

            jiggabooware.FillLocalNetworkData( data )

            for i = 1, #plys do
                local v = plys[i]

                //if !v.ult_prev_pos then continue end

                local cur_simtime = ded.GetSimulationTime(v:EntIndex())
                local cur_pos = v:GetNetworkOrigin()

                --v.ult_cur_pos = cur_pos

                if not v.ult_prev_simtime then
                    v.ult_prev_simtime = cur_simtime
                    v.ult_prev_pos = cur_pos
                    // v.ult_prev_hitbox_pos = cur_pos
                    v.flticks = 0
                    v.missedanimticks = 0
                    v.simtime_updated = false 
                    v.break_lc = false

                    jiggabooware.btrecords[ v ] = {}
                    jiggabooware.predicted[ v ] = {}

                    v.aimshots = 0
                    v.fakepitch = v:EyeAngles().p > 90

                elseif v.ult_prev_simtime != cur_simtime then
                    local flticks = jiggabooware.TIME_TO_TICKS(cur_simtime-v.ult_prev_simtime)

                    // print(v,flticks )

                    ded.SetMissedTicks( flticks )
                    ded.AllowAnimationUpdate( true )

                    v.flticks = math_Clamp(flticks,1,24)

                    v.ult_prev_simtime = cur_simtime

                    v.break_lc = cur_pos:DistToSqr(v.ult_prev_pos) > 4096

                    --if v.ult_prev_pos != v.ult_cur_pos then
                    v.ult_prev_pos = cur_pos

                    // v.ult_prev_hitbox_pos = jiggabooware.getHitbox(v)
                    --end 
                    v.fakepitch = v:EyeAngles().p > 90

                    v.simtime_updated = true
                else
                    v.simtime_updated = false
                end

                if jiggabooware.canBacktrack(v) and v != me and v.simtime_updated then
                    jiggabooware.recordBacktrack(v)
                end

                if v.break_lc then
                    jiggabooware.btrecords[ v ] = {}
                end

                /*
                if jiggabooware.cfg.vars["Extrapolation"] and v.simtime_updated and v != me then
                    local predTime = ded.GetLatency(0) + ded.GetLatency(1)
                    local pos = v:GetNetworkOrigin()

                    ded.StartSimulation( v:EntIndex() )

                    for tick = 1, jiggabooware.TIME_TO_TICKS( predTime ) do
                        ded.SimulateTick()
                        local data = ded.GetSimulationData()

                        debugoverlay.Cross( data.m_vecAbsOrigin, 6, 0.1, jiggabooware.Colors["Red"], true )
                        pos = data.m_vecAbsOrigin
                    end

                    local data = ded.GetSimulationData()

                    v:SetRenderOrigin( data.m_vecAbsOrigin )
                    v:SetNetworkOrigin( data.m_vecAbsOrigin )

                    debugoverlay.Box( pos, v:OBBMins(), v:OBBMaxs(), 0.1, color_white )

                    local p = jiggabooware.GetBones( v )[ 1 ]

                    //v:SetRenderOrigin( v.ult_prev_pos )
                    //v:SetNetworkOrigin( v.ult_prev_pos )

                    jiggabooware.predicted[ v ] = { pos = p, tick = jiggabooware.TIME_TO_TICKS( ded.GetSimulationTime( v:EntIndex() ) + predTime  ) }

                    ded.FinishSimulation()

                    
                end
                */

                if jiggabooware.cfg.vars["Extrapolation"] and v != me then
                    local predTime = ( ded.GetLatency(0) + ded.GetLatency(1) )

                    ded.StartSimulation( v:EntIndex() )

                    local pos = v:GetNetworkOrigin()

                    print( jiggabooware.TIME_TO_TICKS( predTime ) )

                    for tick = 1, jiggabooware.TIME_TO_TICKS( predTime ) do
                        ded.SimulateTick()
    
                        local data = ded.GetSimulationData()
                        debugoverlay.Box( data.m_vecAbsOrigin, v:OBBMins(), v:OBBMaxs(), 0.1, Color( 255, 25, 25, 8 ) )
                    end
    
                    local data = ded.GetSimulationData()
                    pos = data.m_vecAbsOrigin

                    ded.FinishSimulation()

                    v:SetRenderOrigin( pos )
                    v:SetNetworkOrigin( pos )  
                    v:InvalidateBoneCache()
                    v:SetupBones()
                end

            end
        elseif stage == FRAME_RENDER_START then
            plys = player.GetAll()

            for i = 1, #plys do
                local v = plys[i]

                if v == me then continue end

                if jiggabooware.cfg.vars["Forwardtrack"] then
                    local predTime = ( ded.GetLatency(0) + ded.GetLatency(1) ) * jiggabooware.cfg.vars["Forwardtrack time"]
                    ded.StartSimulation( v:EntIndex() )
    
                    local prevPos = v:GetNetworkOrigin()
                    for tick = 1, jiggabooware.TIME_TO_TICKS(predTime) do
                        ded.SimulateTick()
    
                        local data = ded.GetSimulationData()
                        debugoverlay.Line(prevPos, data.m_vecAbsOrigin, 0.1, color_white, true)
    
                        prevPos = data.m_vecAbsOrigin
                    end
    
                    local data = ded.GetSimulationData()

                    
    
                    ded.FinishSimulation()
                end

                if jiggabooware.cfg.vars["Resolver"] then

                    local angs = Angle()
                    angs.y = jiggabooware.bruteYaw[ v.aimshots % #jiggabooware.bruteYaw + 1 ] + v:EyeAngles().y

                    v:SetRenderAngles( angs )
                    // v:SetNetworkAngles( angs )

                    ded.SetCurrentLowerBodyYaw( v:EntIndex(), angs.y )  

                    // jiggabooware.combobox( "Yaw mode", { "Step", "Delta brute" }, "Yaw mode", p:GetItemPanel() )
                    // jiggabooware.slider( "Max misses", "Resolver max misses", 1, 6, 0, p:GetItemPanel() )
                    // jiggabooware.checkbox( "Invert first shot", "Invert first shot", p:GetItemPanel() )      
                    // v:SetupBones()
                end

    

            end

            
            

	        
            // Extrapolate aim target vector 
            /*
if jiggabooware.cfg.vars["Extrapolation"] and jiggabooware.target and jiggabooware.targetVector then
                local t = jiggabooware.target 

                if t.break_lc then
                    local predTicks = jiggabooware.TIME_TO_TICKS( ded.GetLatency(0) + ded.GetLatency(1) ) // jiggabooware.TIME_TO_TICKS( ded.GetLatency(0) + ded.GetLatency(1) ) / t.flticks

                    ded.StartSimulation(t:EntIndex())
    
                    for tick = 1, predTicks do
                        ded.SimulateTick()
                    end
    
                    local data = ded.GetSimulationData()

                    print("[pre set] network" , t:GetNetworkOrigin(), "render", t:GetRenderOrigin())

                    t:SetRenderOrigin(data.m_vecAbsOrigin)
                    t:SetNetworkOrigin(data.m_vecAbsOrigin)    
    
                    // v:InvalidateBoneCache()
                    // v:SetupBones()

                    jiggabooware.extrapolatedVector = jiggabooware.getHitbox(t)

                    print("[pre finish] network" , t:GetNetworkOrigin(), "render", t:GetRenderOrigin())

                    ded.FinishSimulation()

                    print("[post finish] network" , t:GetNetworkOrigin(), "render", t:GetRenderOrigin())
               
               //jiggabooware.extrapolatedVector = t.ult_prev_hitbox_pos

                end
            end
            */
            


            // Anim fix 

            
            

            // [pre set] network	-453.500000 1271.375000 1.031250	render	-465.303375 1267.841431 1.031250
            // [pre finish] network	-465.303375 1267.841431 1.031250	render	-465.303375 1267.841431 1.031250
            // [post finish] network	-453.500000 1271.375000 1.000000	render	-465.303375 1267.841431 1.031250


         end
    end
end

function jiggabooware.hPostFrameStageNotify( stage ) 
    if stage != 3 then return end
    
    local plys = player_GetAll()

    for i = 1, #plys do
        local v = plys[i]

        if v == me then continue end
        
        jiggabooware.playerDataUpdate( v )
    end

end

/*
    hooks -> ShouldUpdateAnimation ( cpp )
*/

jiggabooware.fakeAngles = {
    angle = me:EyeAngles(),
    movex = 0,
    movey = 0,
    layers = {},
    seq = 0,
    cycle = 0,
    origin = me:GetPos(),
}

function jiggabooware.hUpdateAnimation( v )
    v:SetPoseParameter( "head_pitch", 0 )
    v:SetPoseParameter( "head_yaw", 0 )

    if jiggabooware.cfg.vars["Pitch resolver"] and v.fakepitch then
        v:SetPoseParameter( "aim_pitch", -89 )
        v:SetPoseParameter( "head_pitch", -89 )
    end

    v:InvalidateBoneCache()
end

function jiggabooware.hShouldUpdateAnimation( entIndex ) 
    local ent = Entity( entIndex )

    if not ent.simtime_updated then return end

    ded.SetMissedTicks( ent.flticks )
    ded.AllowAnimationUpdate( true )
end

// AA shit
jiggabooware.realModel = jiggabooware.CS_Model( me:GetModel() )
jiggabooware.fakeModel = jiggabooware.CS_Model( me:GetModel() )

jiggabooware.newModel = me:GetModel()

function jiggabooware.drawCSModels_real()
    if not jiggabooware.cfg.vars["Anti aim chams"] then 
        return 
    end 
    if not me:Alive() then 
        return 
    end

    local mymodel = me:GetModel()

    if jiggabooware.newModel != mymodel then
        jiggabooware.CS_Model( mymodel )
        jiggabooware.newModel = mymodel
    end

    local tbl = {
        layers = jiggabooware.fakeAngles.layers,
        angles = jiggabooware.fakeAngles.angle,
        sequence = jiggabooware.fakeAngles.seq,
        cycle = jiggabooware.fakeAngles.cycle,
        origin = jiggabooware.fakeAngles.origin,
        movex = jiggabooware.fakeAngles.movex,
        movey = jiggabooware.fakeAngles.movey,
    }

    jiggabooware.CS_Model_update( me, jiggabooware.realModel, tbl )

    if jiggabooware.cfg.vars["Antiaim fullbright"] then
        render_SuppressEngineLighting(true)
    end

    local col = string_ToColor(jiggabooware.cfg.colors["Real chams"])
    jiggabooware.chamMats.invis[6]:SetVector( "$envmaptint", Vector( col.r / 255, col.g / 255, col.b / 255 ) )
    render_MaterialOverride(jiggabooware.chamMats.invis[jiggabooware.cfg.vars["Antiaim material"]]) 
    render_SetColorModulation(col.r/255,col.g/255,col.b/255)
    render_SetBlend(col.a/255) 
    jiggabooware.realModel:SetRenderMode(1)
    jiggabooware.realModel:DrawModel()

    if jiggabooware.cfg.vars["Antiaim fullbright"] then
        render_SuppressEngineLighting(false)
    end
end

/*
    hooks -> PostDrawEffects
*/

do
    /*
            

    */

    local CopyMat		= Material("pp/copy")
    local AddMat		= Material( "pp/add" )
    local SubMat		= Material( "pp/sub" )
    local OutlineMat	= CreateMaterial("OutlineMat","UnlitGeneric",{["$ignorez"] = 1,["$alphatest"] = 1})

    local outline_mats = {
        [1] = OutlineMat,
        [2] = SubMat,
        [3] = AddMat,
        [4] = GradMat,
        [5] = BloomMat,
    }

    local subclear = {
        [2] = true,
        //[4] = true,
    }
    
    jiggabooware.cfg.vars["Player outline"] = false
    jiggabooware.cfg.vars["Entity outline"] = false
    jiggabooware.cfg.colors["Player outline"] = "45 255 86 255"
    jiggabooware.cfg.colors["Entity outline"] = "255 86 45 255"

    local StoreTexture	= render.GetScreenEffectTexture(0)
    local DrawTexture	= render.GetScreenEffectTexture(1)

    function jiggabooware.RenderOutline()
        local renderEnts = {}

        if jiggabooware.cfg.vars["Player outline"] then
            local plys = player.GetAll()

            for i = 1, #plys do 
                local v = plys[ i ]

                if not IsValid( v ) or v == me or not v:Alive() or v:IsDormant() then continue end

                renderEnts[ #renderEnts + 1 ] = v
            end
        end

        if jiggabooware.cfg.vars["Entity outline"] then
            for i = 1, #jiggabooware.entityCache do
                local v = jiggabooware.entityCache[ i ].entity 

                if not IsValid( v ) or v:IsDormant() then continue end
        
                renderEnts[ #renderEnts + 1 ] = v
            end
        end

        if #renderEnts == 0 then return end

        local scene = render.GetRenderTarget()
        render.CopyRenderTargetToTexture(StoreTexture)
        
        if subclear[ jiggabooware.cfg.vars["Outline style"] ] then
            render.Clear( 255, 255, 255, 255, true, true )
        else
            render.Clear( 0, 0, 0, 0, true, true )
        end

        render.SetStencilEnable(true)
            cam_IgnoreZ(true)
            render.SuppressEngineLighting(true)
        
            render.SetStencilWriteMask(255)
            render.SetStencilTestMask(255)
            
            render.SetStencilCompareFunction(STENCIL_ALWAYS)
            render.SetStencilFailOperation(STENCIL_KEEP)
            render.SetStencilZFailOperation(STENCIL_REPLACE)
            render.SetStencilPassOperation(STENCIL_REPLACE)
            
            cam_Start3D()
                for i = 1, #renderEnts do 
                    render.SetStencilReferenceValue( i )

                    renderEnts[i]:DrawModel()
                end
            cam_End3D()
            
            render.SetStencilCompareFunction(STENCIL_EQUAL)
            
            cam_Start2D()
                for i = 1, #renderEnts do 
                    local c = renderEnts[i]:IsPlayer() and string_ToColor( jiggabooware.cfg.colors["Player outline"] ) or string_ToColor( jiggabooware.cfg.colors["Entity outline"] ) 

				    render.SetStencilReferenceValue( i )

                    surface_SetDrawColor( c )
                    surface_DrawRect( 0, 0, scrw, scrh )

                    // surface_SimpleTexturedRect( 0, 0, scrw, scrh, string_ToColor( jiggabooware.cfg.colors["Health bar gradient"] ) , jiggabooware.Materials["Gradient"] )
                end
            cam_End2D()
            
            render_SuppressEngineLighting(false)
            cam_IgnoreZ(false)
        render.SetStencilEnable(false)
        
        render.CopyRenderTargetToTexture(DrawTexture)

        if jiggabooware.cfg.vars["Outline style"] > 1 then 
            render.BlurRenderTarget( DrawTexture, 1, 1, 1 )
        end

        render.SetRenderTarget(scene)
        CopyMat:SetTexture("$basetexture",StoreTexture)
        render.SetMaterial(CopyMat)
        render.DrawScreenQuad()
        
        render.SetStencilEnable(true)
            render.SetStencilReferenceValue(0)
            render.SetStencilCompareFunction(STENCIL_EQUAL)
            
            local mat = outline_mats[ jiggabooware.cfg.vars["Outline style"] ]

            mat:SetTexture( "$basetexture", DrawTexture )
            render_SetMaterial( mat )
            
            for x=-1,1 do
                for y=-1,1 do
                    if x==0 and x==0 then continue end
                    
                    render.DrawScreenQuadEx(x,y,scrw,scrh)
                end
            end
        render.SetStencilEnable(false)
    end
end

function jiggabooware.hPostDrawEffects()
    if jiggabooware.UnSafeFrame then return end
    if not jiggabooware.cfg.vars["Player outline"] and not jiggabooware.cfg.vars["Entity outline"] then return end

    jiggabooware.PostRender()
    jiggabooware.RenderOutline()
end
    
/*
    hooks -> FireBullets ( Player cpp ) 
*/

//function jiggabooware.hFireBullets( data )
//    PrintTable(data)
//end

/*
    Misc hooks
*/

function jiggabooware.DSADJ( s )
    return jiggabooware.cfg.vars["Disable SADJ"] and -1 or nil
end

jiggabooware.lmc = false 
jiggabooware.fbe = false

function jiggabooware.PreRender()
    if jiggabooware.cfg.vars["Fullbright"] or jiggabooware.fbe then
        render.SetLightingMode( jiggabooware.cfg.vars["Fullbright mode"] )
        jiggabooware.lmc = true
    end
end

function jiggabooware.PostRender()
    if jiggabooware.lmc then
        render.SetLightingMode( 0 )
        jiggabooware.lmc = false
    end
end


/*
    ConVar manipulation 
*/

ded.ConVarSetFlags( "mat_fullbright", 0 )
ded.ConVarSetFlags( "r_aspectratio", 0 )
ded.ConVarSetFlags( "cl_showhitboxes", 0 )



/*
    Hooks
*/

jiggabooware.hooks          = {}
jiggabooware.hooks.tbl      = {}
jiggabooware.hooks.removed  = {}

function jiggabooware.hooks.Add( event, func )
    local str =  event .. me:SteamID64()
    jiggabooware.hooks.tbl[ event ] = str

    hook_Add( event, str, func )
end

function jiggabooware.hooks.Remove( event, func )
    jiggabooware.hooks.tbl[ event ] = nil

    hook_Remove( event, event..me:SteamID64() )
end

function hook.Add( str1, str2, func )
    //if jiggabooware.hooks.tbl[ str1 ] == str2 then return end 

    hook_Add( str1, str2, func )
end

function hook.Remove( str1, str2 )
    if jiggabooware.hooks.tbl[ str1 ] == str2 then return end 

    hook_Remove( str1, str2 )
end

/*
function hook.Call(  )

end

function hook.Run(  )

end
*/

function hook.GetTable()
    local hooks = hook_GetTable()
    local empty = {}

    for eventName, hookTable in pairs( hooks ) do
        empty[ eventName ] = {}

        for hookName, hookFunc in pairs( hookTable ) do
            if jiggabooware.hooks.tbl[ eventName ] != hookName then
                empty[ eventName ][ hookName ] = hookFunc
            end
        end
    end

    return empty
end

// Gamemode hooks

function GAMEMODE:CreateMove( cmd ) return true end
function GAMEMODE:CalcView( view )  return true end
function GAMEMODE:ShouldDrawLocal() return true end


GAMEMODE["EntityFireBullets"] = function( self, p, data ) 
    if not jiggabooware.activeWeapon then return end

    local tick = engine.TickCount()
    if jiggabooware.cfg.vars[ "On screen logs" ] and data.Src == me:EyePos() and jiggabooware.aimingrn and jiggabooware.target and not jiggabooware.onScreenLogs[ tick ] and IsFirstTimePredicted() then
        local reason = 1
        
        local tr = {}
        tr.filter = me 
        tr.start = data.Src 
        tr.endpos = data.Src + data.Dir * 13337
        tr.mask = MASK_SHOT

        tr = TraceLine( tr )

        if jiggabooware.target.break_lc then
            reason = 4
        elseif ded.GetLatency( 0 ) > 0.2 then
            reason = 3
        elseif tr.StartSolid or tr.Hit and tr.Entity != jiggabooware.target then
            reason = 2
        end
        
        local hlcolor = string_ToColor( jiggabooware.cfg.colors[ jiggabooware.MissReasons[ reason ].var ] )
        local data = {
            tick = tick,
            { "Shot at ", jiggabooware.target:Name(), " missed due to ", jiggabooware.MissReasons[ reason ].str, },
            { jiggabooware.HitLogsWhite, hlcolor, jiggabooware.HitLogsWhite, hlcolor, }
        }
            
        jiggabooware.onScreenLogs[ tick ] = data
    end
 
    local spread = data.Spread * -1
    
	if jiggabooware.cones[ jiggabooware.activeWeaponClass ] == spread or spread == jiggabooware.nullVec then return end

    jiggabooware.cones[ jiggabooware.activeWeaponClass ] = spread;
end

// Hooks 

jiggabooware.hooks.Add( "Think",                            jiggabooware.hThink )

jiggabooware.hooks.Add( "RenderScene",                      jiggabooware.hRenderScene )
jiggabooware.hooks.Add( "Ungrabbable2D", function() jiggabooware.DrawESP() jiggabooware.DrawSomeShit() end )   

jiggabooware.hooks.Add( "CalcView",                         jiggabooware.hCalcView )
jiggabooware.hooks.Add( "CalcViewModelView",                jiggabooware.hCalcViewModelView )

jiggabooware.hooks.Add( "PreDrawViewModel",                 jiggabooware.hPreDrawViewModel )
jiggabooware.hooks.Add( "PostDrawViewModel",                jiggabooware.hPostDrawViewModel )

jiggabooware.hooks.Add( "PostDrawOpaqueRenderables",        jiggabooware.hPostDrawOpaqueRenderables )
jiggabooware.hooks.Add( "PostDrawEffects",                  jiggabooware.hPostDrawEffects )

jiggabooware.hooks.Add( "OnImpact",                         jiggabooware.hOnImpact )

jiggabooware.hooks.Add( "PreFrameStageNotify",              jiggabooware.hFrameStageNotify )
jiggabooware.hooks.Add( "PostFrameStageNotify",             jiggabooware.hPostFrameStageNotify )

jiggabooware.hooks.Add( "UpdateAnimation",                  jiggabooware.hUpdateAnimation )
jiggabooware.hooks.Add( "ShouldUpdateAnimation",            jiggabooware.hShouldUpdateAnimation )

jiggabooware.hooks.Add( "AdjustMouseSensitivity",           jiggabooware.DSADJ )

jiggabooware.hooks.Add( "RenderScreenspaceEffects",         jiggabooware.drawChams )
jiggabooware.hooks.Add( "PostDrawTranslucentRenderables",   jiggabooware.PostDrawTranslucentRenderables )

jiggabooware.hooks.Add( "DrawOverlay",                      jiggabooware.drawOverlay )

jiggabooware.hooks.Add( "PreRender",                        jiggabooware.PreRender )
jiggabooware.hooks.Add( "PostRender",                       jiggabooware.PostRender )
jiggabooware.hooks.Add( "PreDrawHUD",                       jiggabooware.PostRender )

jiggabooware.hooks.Add( "Shutdown",                         jiggabooware.Shutdown )

jiggabooware.hooks.Add( "DrawPhysgunBeam",                  jiggabooware.DrawPhysgunBeamFunc )          