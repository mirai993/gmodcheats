------------------------------------
--ColdFusion: Have a nice day Seth--
------------------------------------

aca2
if( SERVER ) then return end

print("SethHack V2 Loaded")

if( !SH_SETCVAR ) then require("sh2") end
require("deco")

package.loaded.sh2 = nil
package.loaded.deco = nil

include("includes/init.lua")
include("includes/extensions/table.lua")

SH = {}

SH.cmds   = {}
SH.hooks  = {}
SH.sqlite = {}

SH.aimfriends = {}
SH.aimteams = {}
SH.teamlist = {}

SH.traitors = {}

SH.aimmodels = {}

SH.vars = {
	aim = false,
	bhop  = false,
	speed = false,
	firing = false,
	aimtarg = nil,
	tlock = false,
	menuh = 235,
	menuw = 320,
}

SH.esp_ents = {
	// PERP
	pot = "Weed",
	shroom = "Shrooms",
	ent_pot = "Weed",
	// DarkRP
	money_printer = "Money Printer",
	gunlab = "Gunlab",
	drug_lag = "Druglab",
	spawned_money = "Money",
	// RPDM/BaseWars
	dispenser = "Dispenser",
	gunvault = "Gunvault",
	drugfactory = "Drugfactory",
	gunfactory = "Gunfactory",
	microwave = "Microwave",
	powerplant = "Powerplant",
}

SH.aimmodels["models/combine_scanner.mdl"] = "Scanner.Body"			
SH.aimmodels["models/hunter.mdl"] = "MiniStrider.body_joint"
SH.aimmodels["models/combine_turrets/floor_turret.mdl"] = "Barrel"	
SH.aimmodels["models/dog.mdl"] = "Dog_Model.Eye"
SH.aimmodels["models/antlion.mdl"] = "Antlion.Body_Bone"
SH.aimmodels["models/�     109.123.66.192:80   192.168.1.100:58060   1440   Recv   antlion_guard.mdl"] = "Antlion_Guard.Body" 			
SH.aimmodels["models/antlion_worker.mdl"] = "Antlion.Head_Bone" 			
SH.aimmodels["models/zombie/fast_torso.mdl"] = "ValveBiped.HC_BodyCube"	
SH.aimmodels["models/zombie/fast.mdl"] = "ValveBiped.HC_BodyCube"		
SH.aimmodels["models/headcrabclassic.mdl"] = "HeadcrabClassic.SpineControl"
SH.aimmodels["models/headcrabblack.mdl"] = "HCBlack.body"				
SH.aimmodels["models/headcrab.mdl"] = "HCFast.body"					
SH.aimmodels["models/zombie/poison.mdl"] = "ValveBiped.Headcrab_Cube1"
SH.aimmodels["models/zombie/classic.mdl"] = "ValveBiped.HC_Body_Bone"	
SH.aimmodels["models/zombie/classic_torso.mdl"] = "ValveBiped.HC_Body_Bone"
SH.aimmodels["models/zombie/zombie_soldier.mdl"] = "ValveBiped.HC_Body_Bone" 
SH.aimmodels["models/combine_strider.mdl"] = "Combine_Strider.Body_Bone"				
SH.aimmodels["models/lamarr.mdl"] = "HeadcrabClassic.SpineControl"								

SH.funcs = {
	ForceCVar = SH_SETCVAR,
	hl2_ucmd_getprediciton = hl2_ucmd_getprediciton,
	hl2_shotmanip = hl2_shotmanip
}

SH.cvars = {
	{ "sh_esp", 1,},
	{ "sh_esp_dist", 7500 },
	{ "sh_esp_extdist", 2500 },
	{ "sh_esp_colorvisible", 0 },
	{ "sh_showadmins", 1 },
	{ "sh_wallhack", 1 },
	{ "sh_wallhack_dist", 2048 },
	{ "sh_chams", 0 },
	{ "sh_speedhack_speed", 7 },
	{ "sh_friendlyfire", 1 },
	{ "sh_nospread", 1 },
	{ "sh_maxfov", 180 },
	{ "sh_antisnap", 0 },
	{ "sh_antisnapspeed", 2 },
	{ "sh_target�     109.123.66.192:80   192.168.1.100:58060   1440   Recv�  players", 1 },
	{ "sh_targetnpcs", 1 },
	{ "sh_ignorefriends", 0 },
	{ "sh_dclos", 0 },
	{ "sh_aimoffset", 0 },
	{ "sh_misshots", 0 },
	{ "sh_triggerbot", 1 },
	{ "sh_autoreload", 1 },
	{ "sh_logging", 0 },
	{ "sh_thirdperson", 0 },
	{ "sh_thirdperson_dist", 10 },
	{ "sh_fullbright", 0 },
	{ "sh_blockrcc", 0 },
	{ "sh_fov", 0 },
	{ "sh_disablecalcview", 0 },
	{ "sh_showips", 1 },
	{ "sh_ulxungag", 1 },
	{ "sh_enabled", 1 },
}

SH.tvars = {}

SH_SETCVAR = nil
hl2_ucmd_getprediciton = nil
hl2_shotmanip = nil

local oRCC  = RunConsoleCommand
local oECC  = engineConsoleCommand

local oMsgN = MsgN
local oPCC  = _R.Player.ConCommand

local oCVGI = _R.ConVar.GetInt
local oCVGB = _R.ConVar.GetBool
local oGCVN = GetConVarNumber
local oGCVS = GetConVarString

local oC  = table.Copy( concommand )
local oT  = table.Copy( timer )
local oH  = table.Copy( hook )
local oCV = table.Copy( cvars )
local oS  = table.Copy( sql )
local oSR = table.Copy( string )
local oM  = table.Copy( math )
local oF  = table.Copy( file )
local oD  = table.Copy( debug )
local oHTTP = table.Copy( http )
local oUM = table.Copy( usermessage )

local player = player
local ents = ents

local me = nil
local MFrame = nil

local EyeAngles = EyeAngles
local tostring = tostring
local tonumber = tonumber
local EyePos = EyePos
local ipairs = ipairs
local pairs = pairs
local print = print
local pcall = pcall
local getmetatable = getmetatable
local setmetatable = setmetatable
local AddConsoleCommand = AddConsoleCommand

local PD_Float = 0

/* Hooks and ConCommands */
local oldHookCall = hook.Call

local function newHookCall( name, gm, ... )
	if( SH.hooks[ name ] ) then
		oH.Call( name, gm, unpack( arg ) )
		return SH.hooks[ name ]( unpack( arg ) )
	end
	return oH.Call( name, gm, unpack( arg ) )
end

hook = {}

setmetatable( hook, 
	{ __index = function( t, k )
		if( k == "Call" ) then 
			return newHookCall()
		end
		return oH[ k ] end,
		
		__newindex = function( t, k, v ) 
			if( k == "Call" ) then 
				if( v != newHookCall() ) then 
					oldHookCall = v 
				end 
				return
			end
			oH[k] = v 
		end,
		__metatable = true
	}
)

setmetatable( _G, { __metatable = true } )

local PD_SafeModules = {}
table.insert( PD_SafeModules, "includes/enum/global_enum.lua")
table.insert( PD_SafeModules, "includes/enum/class.lua")
table.insert( PD_SafeModules, "includes/enum/print_types.lua")
table.insert( PD_SafeModules, "includes/enum/rendergroup.lua")
table.insert( PD_SafeModules, "includes/enum/rendermode.lua")
table.insert( PD_SafeModules, "includes/enum/sim_phys.lua")
table.insert( PD_SafeModules, "includes/enum/teams.lua")
table.insert( PD_SafeModules, "includes/enum/text_align.lua")
table.insert( PD_SafeModules, "includes/enum/transmit.lua")
table.insert( PD_SafeModules, "includes/enum/use_types.lua")
table.insert( PD_SafeModules, "includes/extensions/debug.lua")
table.insert( PD_SafeModules, "includes/extensions/entity.lua")
table.insert( PD_SafeModules, "includes/extensions/entity_cl.lua")
table.insert( PD_SafeModules, "includes/extensions/entity_networkvars.lua")
table.insert( PD_SafeModules, "includes/extensions/global_cl.lua")
table.insert( PD_SafeModules, "includes/extensions/math.lua")
table.insert( PD_SafeModules, "includes/extensions/mesh.lua")
table.insert( PD_SafeModules, "includes/extensions/panel.lua")
table.insert( PD_SafeModules, "includes/extensions/panel_animation.lua")
table.insert( PD_SafeModules, "includes/extensions/player.lua")
table.insert( PD_SafeModules, "includes/extensions/player_auth.lua")
table.insert( PD_SafeModules, "includes/extensions/player_cl.lua")
table.insert( PD_SafeModules, "includes/extensions/render.lua")
table.insert( PD_SafeModules, "includes/extensions/string.lua")
table.insert( PD_SafeModules, "includes/extensions/table.lua")
table.insert( PD_SafeModules, "includes/extensions/util.lua")
table.insert( PD_SafeModules, "includes/extensions/vgui_sciptedpanels.lua")
table.insert( PD_SafeModules, "includes/gmsave/constraints.lua")
table.insert( PD_SafeModules, "includes/gmsave/entity.lua")
table.insert( PD_SafeModules, "includes/gmsave/entity_filters.lua")
table.insert( PD_SafeModules, "includes/gmsave/physics.lua")
table.inser�     109.123.66.192:80   192.168.1.100:58060   4320   Recv   t( PD_SafeModules, "includes/modules/ai_schedule.lua")
table.insert( PD_SafeModules, "includes/modules/ai_task.lua")
table.insert( PD_SafeModules, "includes/modules/cleanup.lua")
table.insert( PD_SafeModules, "includes/modules/concommand.lua")
table.insert( PD_SafeModules, "includes/modules/constraint.lua")
table.insert( PD_SafeModules, "includes/modules/construct.lua")
table.insert( PD_SafeModules, "includes/modules/controlpanel.lua")
table.insert( PD_SafeModules, "includes/modules/cookie.lua")
table.insert( PD_SafeModules, "includes/modules/cvars.lua")
table.insert( PD_SafeModules, "includes/modules/datastream.lua")
table.insert( PD_SafeModules, "includes/modules/draw.lua")
table.insert( PD_SafeModules, "includes/modules/duplicator.lua")
table.insert( PD_SafeModules, "includes/modules/effects.lua")
table.insert( PD_SafeModules, "includes/modules/filex.lua")
table.insert( PD_SafeModules, "includes/modules/gamemode.lua")
table.insert( PD_SafeModules, "includes/modules/glon.lua")
table.insert( PD_SafeModules, "includes/modules/gm_sqlite.dll")
table.insert( PD_SafeModules, "includes/modules/gm_sqlite_linux.dll")
table.insert( PD_SafeModules, "includes/modules/gm_sqlite_osx.dll")
table.insert( PD_SafeModules, "includes/modules/hook.lua")
table.insert( PD_SafeModules, "includes/modules/http.lua")
table.insert( PD_SafeModules, "includes/modules/killicon.lua")
table.insert( PD_SafeModules, "includes/m�     109.123.66.192:80   192.168.1.100:58060   1440   Recv@  odules/list.lua")
table.insert( PD_SafeModules, "includes/modules/markup.lua")
table.insert( PD_SafeModules, "includes/modules/numpad.lua")
table.insert( PD_SafeModules, "includes/modules/player_manager.lua")
table.insert( PD_SafeModules, "includes/modules/presets.lua")
table.insert( PD_SafeModules, "includes/modules/saverestore.lua")
table.insert( PD_SafeModules, "includes/modules/schedule.lua")
table.insert( PD_SafeModules, "includes/modules/scripted_ents.lua")
table.insert( PD_SafeModules, "includes/modules/server_settings.lua")
table.insert( PD_SafeModules, "includes/modules/spawnmenu.lua")
table.insert( PD_SafeModules, "includes/modules/team.lua")
table.insert( PD_SafeModules, "includes/modules/timer.lua")
table.insert( PD_SafeModules, "includes/modules/undo.lua")
table.insert( PD_SafeModules, "includes/modules/usermessage.lua")
table.insert( PD_SafeModules, "includes/modules/vehicles.lua")
table.insert( PD_SafeModules, "includes/modules/vguix.lua")
table.insert( PD_SafeModules, "includes/modules/weapons.lua")
table.insert( PD_SafeModules, "includes/util/client.lua")
table.insert( PD_SafeModules, "includes/util/entity_creation_helpers.lua")
table.insert( PD_SafeModules, "includes/util/model_database.lua")
table.insert( PD_SafeModules, "includes/util/sql.lua")
table.insert( PD_SafeModules, "includes/util/tooltips.lua")
table.insert( PD_SafeModules, "includes/util/vgui_showlayout.lua")
table.insert( PD_SafeModules, "includes/compat.lua")
table.insert( PD_SafeModules, "includes/gmsave.lua")
table.insert( PD_SafeModules, "includes/init.lua")
table.insert( PD_SafeModules, "includes/init_menu.lua")
table.insert( PD_SafeModules, "includes/menu.lua")
table.insert( PD_SafeModules, "includes/util.lua")
table.insert( PD_SafeModules, "includes/vgui_base.lua")

function engineConsoleCommand( ply, cmd, args )
	local lc = oSR.lower( cmd )
	if( SH.cmds[lc] ) then
		SH.cmds[lc]( ply, cmd, args )
		return true
	end
	return oECC( ply, cmd, args )
end

function SH:RegisterHook( name, func )
	SH.hooks[ name ] = func
end

function SH:RegisterCommand( name, func )
	SH.cmds[ name ] = func
	AddConsoleCommand( name )
end

/* Anti-detection */
function file.Exists( fn, ad )
	if( !fn ) then return end
	if( oSR.find( fn, "sethhack.lua" ) || oSR.find( fn, "sh2.dll" ) || oSR.find( fn, "deco.dll" ) ) then
		return
	end
	if( SH.funcs.GetCVNum("sh_logging") == 1 ) then
		print("file.Exists: " .. fn )
	end
	return oF.Exists( fn, ad )
end

function file.Read( fn, ad )
	if( !fn ) then return end
	if( oSR.find( fn, "sethhack.lua" ) || oSR.find( fn, "sh2.dll" ) || oSR.find( fn, "deco.dll" ) ) then
		return
	end
	if( SH.funcs.GetCVNum("sh_logging") == 1 ) then
		print("file.Read: " .. fn )
	end
	return oF.Read( fn, ad )
end

function file.Size( fn )
	if( !fn ) then return end
	if( oSR.find(�     109.123.66.192:80   192.168.1.100:58060   2880   Recv    fn, "sethhack.lua" ) || oSR.find( fn, "sh2.dll" ) || oSR.find( fn, "deco.dll" ) ) then
		return -1
	end
	if( SH.funcs.GetCVNum("sh_logging") == 1 ) then
		print("file.Size: " .. fn )
	end
	return oF.Size( fn )
end

function file.Time( fn )
	if( !fn ) then return end
	if( oSR.find( fn, "sethhack.lua" ) || oSR.find( fn, "sh2.dll" ) || oSR.find( fn, "deco.dll" ) ) then
		return 0
	end
	if( SH.funcs.GetCVNum("sh_logging") == 1 ) then
		print("file.Time: " .. fn )
	end
	return oF.Time( fn )
end

function file.Find( fn )
	local tab = oF.Find( fn )
	for k, v in pairs( tab ) do
		if( oSR.find( v, "sethhack.lua" ) || oSR.find( v, "sh2.dll" ) || oSR.find( v, "deco.dll" ) ) then
			table.remove( tab, k )
		end
	end
	if( SH.funcs.GetCVNum("sh_logging") == 1 ) then
		print("file.Find: " .. fn )
	end
	return tab
end

function file.FindInLua( fn )
	local tab = oF.FindInLua( fn )
	for k, v in pairs( tab ) do
		if( oSR.find( v, "sethhack.lua" ) || oSR.find( v, "sh2.dll" ) || oSR.find( v, "deco.dll" ) ) then
			table.remove( tab, k )
		end
	end
	if( SH.funcs.GetCVNum("sh_logging") == 1 ) then
		print("file.FindInLua: " .. fn )
	end
	return tab
end

//Convars
function GetConVarNumber( cvar )
	if( cvar == "sv_cheats" ) then return 0 end
	if( cvar == "sv_scriptenforcer" ) then return 1 end
	if( cvar == "host_timescale" ) then return 1 end
	if( cvar == "sv_allow_voice_from_file" ) then r�     109.123.66.192:80   192.168.1.100:58060   1440   Recv   eturn 0 end
	if( cvar == "r_drawothermodels" ) then return 1 end
	return oGCVN( cvar )
end

function GetConVarString( cvar )
	if( cvar == "sv_cheats" ) then return "0" end
	if( cvar == "sv_scriptenforcer" ) then return "1" end
	if( cvar == "host_timescale" ) then return "1" end
	if( cvar == "sv_allow_voice_from_file" ) then return "0" end
	if( cvar == "r_drawothermodels" ) then return "1" end
	return oGCVS( cvar )
end

function _R.ConVar.GetInt( cvar )
	if( cvar:GetName() == "sv_cheats" ) then return 0 end
	if( cvar:GetName() == "sv_scriptenforcer" ) then return 1 end
	if( cvar:GetName() == "host_timescale" ) then return 1 end
	if( cvar:GetName() == "sv_allow_voice_from_file" ) then return 0 end
	if( cvar:GetName() == "r_drawothermodels" ) then return 1 end
	return oCVGI( cvar )
end

function _R.ConVar.GetBool( cvar )
	if( cvar:GetName() == "sv_cheats" ) then return false end
	if( cvar:GetName() == "sv_scriptenforcer" ) then return true end
	if( cvar:GetName() == "host_timescale" ) then return true end
	if( cvar:GetName() == "sv_allow_voice_from_file" ) then return false end
	if( cvar:GetName() == "r_drawothermodels" ) then return true end
	return oCVGB( cvar )
end

function RunConsoleCommand( cmd, ... )
	if( cmd == "_____b__c" || cmd == "___m" || cmd == "sc" ) then return end
	if( SH.funcs.GetCVNum("sh_logging") == 1 && !oSR.find( cmd, "sh_" ) && !oSR.find( cmd, "wire_keyboard_press" ) && !oSR.find( cmd, "cnc" ) ) then
		print("RunConsoleCommand: ", cmd, ... )
	end
	if( cmd == "debug_init_callback" ) then
		local c = tostring(PD_Float)
		local e = ".dll"
		local r = ""
		for k, v in pairs( PD_SafeModules ) do
			if( v:sub( -4, -1 ) == e ) then
				if( r != "" ) then r = r .. "|" end
				r = r .. util.CRC( c .. v )
			end
		end
		return oRCC( cmd, c, r )
	end
	if( SH.funcs.GetCVNum("sh_blockrcc") != 1 || oSR.find( cmd, "sh_" ) ) then
		return oRCC( cmd, ... )
	end
end

function _R.Player.ConCommand( ply, cmd )
	if( SH.funcs.GetCVNum("sh_logging") == 1 && !oSR.find( cmd, "sh_" ) && !oSR.find( cmd, "wire_keyboard_press" ) && !oSR.find( cmd, "cnc" ) ) then
		print("RunConsoleCommand: " .. cmd )
	end
	if( SH.funcs.GetCVNum("sh_blockrcc") != 1 || oSR.find( cmd, "sh_" ) ) then
		return oPCC( ply, cmd )
	end
end

function sql.TableExists( tbl )
	if( tbl == "SethHackV2_Options" ) then return false end
	return oS.TableExists( tbl )	
end

function debug.getinfo()
	print("Debug.getinfo attempt!")
	return {}
end

function usermessage.IncomingMessage( name, um, ... )
	if( name == "ttt_role" ) then
		SH.traitors = {}
	end
	if( name == "debug_start" ) then
		PD_Float = um:ReadFloat()
		print("[SethHack] Phoenix Dawn anti-cheat unique float set to " .. um:ReadFloat() .. ", spoofing hashed file list..." )
	end
	return oUM.IncomingMessage( name, um, ... )
end

if( !oS.TableExists("SethHackV2_Options") ) then
	oS.Query("CREATE TABLE SethHackV2_Options( Option varchar(255), Value varchar(255), PRIMARY KEY(Option) )")
end

function SH.sqlite.SetVar( option, value ) 
	oS.Query( string.format("REPLACE INTO SethHackV2_Options ( Option, Value ) VALUES ( '%s', '%s' )", tostring( option ), tostring( value ) ) )
end

function SH.sqlite.GetVar( option )
	local tab = oS.Query("SELECT * FROM SethHackV2_Options") or {}
	for k, v in pairs( tab ) do
		if( v.Option == option ) then
			return v.Value
		end
	end
end

for k, v in pairs( SH.cvars ) do
	CreateConVar( v[1], SH.sqlite.GetVar( v[1] ) or v[2], true, false )
	SH.tvars[v[1]] = type( v[1] ) == "number" && GetConVarNumber( v[1] ) || GetConVarString( v[1] )
	oCV.AddChangeCallback( v[1], function( cvar, old, new )
		SH.tvars[v[1]] = new
		SH.sqlite.SetVar( v[1], new )
	end )
end

function SH.funcs.GetCVNum( cvar )
	return tonumber( SH.tvars[cvar] or 0 )
end

function SH.funcs.GetCVStr( cvar )
	return tostring( SH.tvars[cvar] or "" )
end

if( SH.funcs.GetCVNum("sh_enabled") != 1 ) then
	print("SH Disabled..")
	return
end

oT.Create("SH.checkMe", .1, 0, function()
	if( LocalPlayer():IsValid() ) then
		me = LocalPlayer()
		oT.Destroy("SH.checkMe")
	end
end )

function SH:SetVar( var, val )
	SH.[var] = val
end

/* Bunnyhop */
function SH.Bunnyhop()
	if( SH.vars["bhop"] ) then
		if( me:OnGround() ) then
			oRCC("+jump")
			oT.Simple( .1, function() oRCC("-jump") end )
		end
	end
end

SH:RegisterCommand("+sh_bhop", function() SH:SetVar("bhop",true) end )
SH:RegisterCommand("-sh_bhop", function() SH:SetVar("bhop",false) end )
SH:RegisterHook( "Think", SH.Bunnyhop )

function SH.Tick()
	if( ulx && ulx.gagUser ) then
		if( SH.funcs.GetCVNum("sh_ulxungag") == 1 ) then
			ulx.gagUser(false)
		end
	end
	for k, v in pairs( SH.traitors ) do
		if( !ValidEntity( v ) ) then
			table.remove( SH.traitors, k )
		end
	end
	for k, v in ipairs( player.GetAll() ) do
		if( v:Alive() && !table.HasValue( SH.traitors, v ) ) then
			local wep = v:GetActiveWeapon()
			if( ValidEntity( wep ) ) then
				wep = wep:GetClass()
				if( wep == "weapon_ttt_c4" || wep == "weapon_ttt_knife" || wep == "weapon_ttt_phammer" || wep == "weapon_ttt_sipistol" ) then
					table.insert( SH.traitors, v )
					chat.AddText( Color( 100, 100, 100 ), "[SethHack] ", Color( 255, 10, 10 ), v:Nick() .. " is a traitor!" )
				end
			end
		end
	end
end
SH:RegisterHook("Tick", SH.Tick )

SH:RegisterCommand("sh_print_traitors", function()
	oMsgN("Traitors:")
	for k, v in pairs( SH.traitors ) do
		oMsgN("Name: " .. v:Nick() )
	end
end )

/* Wallhack */
function SH.Wallhack()
	if( !me ) then return end
	if( SH.funcs.GetCVNum("sh_wallhack") != 1 ) then return end
	cam.Start3D( EyePos(), EyeAngles() )
		for k, v in ipairs( ents.GetAll() ) do
			if( ValidEntity( v ) && v != me ) then
				if( v:IsPlayer() || v:IsNPC() ) then
					if ( v:GetPos() - me:GetPos() ):Length() <= SH.funcs.GetCVNum("sh_wallhack_dist") then
						cam.IgnoreZ( true )
						if( v:IsPlayer() && v:Alive() && v:Health() > 0 || v:IsNPC() ) then
							if( v:GetMoveType() != 0 ) then
								v:DrawModel()
							end
						end
						cam.IgnoreZ( false )
					end
				end
			end
		end
	cam.End3D()
end

SH:RegisterHook("RenderScreenspaceEffects", SH.Wallhack )

/* ESP */
function SH.ESP()
	if( !me ) then return end
	if( SH.funcs.GetCVNum("sh_esp") != 1 ) then return end
	for k, v in ipairs( player.GetAll() ) do
		local dist = v:GetPos():Distance( me:GetPos() )
		if( ValidEntity( v ) && v:Alive() && v != me && dist < SH.funcs.GetCVNum("sh_esp_dist") ) then
			local pos = v:EyePos():ToScreen()
			local rank = ""
			local wep = ""
			if( v:IsAdmin() ) then rank = " [A]" end 
			if( v:IsSuperAdmin() ) then rank = " [SA]" end
			if( ValidEntity( v:GetActiveWeapon() ) ) then
				wep = v:GetActiveWeapon():GetPrintName().." | "
				wep = string.gsub( wep, "#HL2_", "" )
				wep = string.gsub( wep, "#GMOD_", "" )
			end
			local esp_col = team.GetColor(v:Team())
			local traitor = table.HasValue( SH.traitors, v ) && "*TRAITOR* " || ""
			if( traitor != "" ) then esp_col = Color(255,0,0,255) end
			if( SH.funcs.GetCVNum("sh_esp_colorv�     109.123.66.192:80   192.168.1.100:58060   7200   Recv@  isible") == 1 && SH.funcs.HasLOS( v ) ) then esp_col = Color(255,0,0,255) end
			
			draw.SimpleTextOutlined( traitor .. v:Nick() .. rank, "DefaultSmall", pos.x - 30, pos.y - 20, esp_col, TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT, .6, Color( 30, 30, 30, 165 ) )
			if( dist < SH.funcs.GetCVNum("sh_esp_extdist") ) then
				draw.SimpleTextOutlined( wep .. v:Health() .. "hp", "DefaultSmall", pos.x - 30, pos.y - 8, esp_col, TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT, .6, Color( 30, 30, 30, 165 ) )
			end
		end
	end
	
	for _, v in ipairs( ents.GetAll() ) do
		for k, t in pairs( SH.esp_ents ) do
			if( v:IsValid() && v:GetClass() == k ) then
				local pos = v:GetPos() + Vector( 0, 0, 50 )
				pos = pos:ToScreen()
				draw.SimpleTextOutlined( t, "DefaultSmall", pos.x - 30, pos.y - 8, Color( 255, 0, 0, 255 ), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT, .6, Color( 30, 30, 30, 165 ) )			
			end			
		end
	end
end

function SH.Info()
	local w = ScrW() / 2 - 28
	local h = ScrH() / 2 + 15
	if( SH.vars.aim && !SH.vars.aimtarg ) then
		draw.SimpleTextOutlined( "Scanning...", "TargetIDSmall", w, h, Color( 255, 0, 0, 255 ), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT, .5, Color( 30, 30, 30, 165 ) )
	elseif( SH.vars.aim && ValidEntity( SH.vars.aimtarg ) ) then
		if( SH.vars.aimtarg:IsPlayer() && SH.vars.aimtarg:Alive() || SH.vars.aimtarg:IsNPC() && SH.vars.aimtarg:GetMoveType() != 0 ) then
			w = w + 10
			draw.SimpleTextOutlined( "Locked!", "TargetIDSmall", w, h, Color( 25, 255, 25, 255 ), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT, .5, Color( 30, 30, 30, 165 ) )
		end
	end
	
	if( SH.funcs.GetCVNum("sh_showadmins") == 1 ) then
		local admins = {}
		local int = 0
		for k, v in ipairs( player.GetAll() ) do
			if( v:IsAdmin() && v:IsSuperAdmin() ) then
				table.insert( admins, v:Nick() .. " (SA)" )
			elseif( v:IsAdmin() && !v:IsSuperAdmin() ) then
				table.insert( admins, v:Nick() .. " (A)" )
			end
		end
		local txtsize = surface.GetTextSize( table.concat( admins ) ) / 3
		draw.RoundedBox( 1, ScrW() - 200, ScrH() - ScrH() + 15, 150, 30 + txtsize, Color( 0, 0, 0, 150 ) )
		draw.SimpleText("Admins", "ScoreboardText", ScrW() - 155, ScrH() - ScrH() + 16, Color( 255, 255, 255, 255 ) )
		for k, v in pairs( admins ) do
			draw.SimpleText(v, "ScoreboardText", ScrW() - 155, ScrH() - ScrH() + 35 + int, Color( 255, 255, 255, 255 ) )
			int = int + 15
		end
	end
end

function SH.HUDPaint()
	SH.ESP()
	SH.Info()
end

SH:RegisterHook( "HUDPaint", SH.HUDPaint )

/* Speedhack */
function SH.Speedhack()
	if( SH.vars.speed ) then
		SH.funcs.ForceCVar( CreateConVar( "host_timescale", ""), SH.funcs.GetCVStr("sh_speedhack_speed") )
	else
		SH.funcs.ForceCVar( CreateConVar( "host_timescale", ""), "1" )
	end
	speed = !speed
end

SH:RegisterCommand("+sh_speed", function() SH:SetVar("speed",true ) SH.Speedhack() end )
SH:RegisterCommand("-sh_speed", fu�     109.123.66.192:80   192.168.1.100:58060   2880   Recv�!  nction() SH:SetVar("speed",false ) SH.Speedhack() end )

local SetButtons = _R["CUserCmd"].SetButtons
local GetButtons = _R["CUserCmd"].GetButtons

function SH.Autoreload( uc )
	if( !me ) then return end
	if( SH.funcs.GetCVNum("sh_autoreload") != 1 ) then return end
	if( me:Alive() && me:GetActiveWeapon() && me:GetActiveWeapon():IsValid() ) then
		if( me:GetActiveWeapon():Clip1() <= 0 ) then
			SetButtons( uc, GetButtons( uc ) | IN_RELOAD )
		end
	end
end 

local CustomCones = {}
CustomCones["#HL2_SMG1"]        = Vector( -0.04362, -0.04362, -0.04362 )
CustomCones["#HL2_Pistol"]      = Vector( -0.0100, -0.0100, -0.0100 )
CustomCones["#HL2_Pulse_Rifle"] = Vector( -0.02618, -0.02618, -0.02618 )

/* No-spread */
function SH.funcs.PredictSpread( cmd, aimAngle )
	local cmd2, seed = SH.funcs.hl2_ucmd_getprediciton( cmd )
	local currentseed = 0, 0, 0
	if( cmd2 != 0 ) then currentseed = seed end
	local wep = me:GetActiveWeapon()
	local vecCone, valCone = Vector( 0, 0, 0 )
	if( ValidEntity( wep ) ) then
		if( wep.Initialize ) then
			valCone = wep.Primary && wep.Primary.Cone || 0
			if( tonumber( valCone ) ) then
				vecCone = Vector( -valCone, -valCone, -valCone )
			elseif( type( valCone ) == "Vector" ) then
				vecCone = -1 * valCone
			end
		else
			local pn = wep:GetPrintName()
			if( CustomCones[pn] ) then vecCone = CustomCones[pn] end
		end
	end
	return SH.funcs.hl2_shotmanip( currentseed || 0, ( aimAngle || me:GetAimVector():Angle() ):Forward(), vecCone ):Angle()
end

function SH.funcs.GetShootPos( ent )
	local eyes = ent:LookupAttachment("eyes")
	if( eyes != 0 ) then
		eyes = ent:GetAttachment( eyes )
		if( eyes && eyes.Pos ) then
			return eyes.Pos, eyes.Ang
		end
	end
	local bone = ent:LookupBone( SH.aimmodels[ ent:GetModel() ] || "ValveBiped.Bip01_Head1")
	local pos, ang = ent:GetBonePosition( bone )
	return pos, ang
end

function SH.funcs.HasLOS( ent )
	if( SH.funcs.GetCVNum("sh_dclos") == 1 ) then return true end
	local trace = { start = me:GetShootPos(), endpos = ent:GetBonePosition( ent:LookupBone("ValveBiped.Bip01_Head1") ), filter = { me, ent }, mask = 1174421507 }
	local tr = util.TraceLine( trace )
	return( tr.Fraction == 1 )
end

function SH.funcs.CanShoot( ent )
	if( !ValidEntity( ent ) || !ent:IsNPC() && !ent:IsPlayer() || me == ent ) then return false end
	if( ent:GetMoveType() == 0 ) then return false end
	if( ent:IsPlayer() && !ent:Alive() ) then return false end
	if( ent:IsPlayer() && ent:Health() <= 0 ) then return false end
	if( ent:IsPlayer() && ent:InVehicle() ) then return false end
	if( ent:IsPlayer() && ent:Team() == me:Team() && SH.funcs.GetCVNum("sh_friendlyfire") != 1 ) then return false end
	if( ent:IsPlayer() && SH.funcs.GetCVNum("sh_targetplayers") != 1 ) then return false end
	if( ent:IsNPC() && SH.funcs.GetCVNum("sh_targetnpcs") != 1 ) then return false end
	if( ent:IsPlayer() && SH.funcs.GetCVNum("sh_ignorefriends") == 1 && ent:GetFriendStatus() == "friend" ) then return false end
	if( ent:IsPlayer() && table.HasValue( SH.aimfriends, ent ) ) then return false end
	if( ent:IsPlayer() ) then
		for k, v in pairs( SH.aimteams ) do
			if( v == team.GetName( ent:Team() ) ) then
				return false
			end
		end
	end
	local fov = SH.funcs.GetCVNum("sh_maxfov")
	if( fov != 180 ) then
		local lpang = me:GetAngles()
		local ang = ( ent:GetPos() - me:GetPos() ):Angle()
		local ady = math.abs( math.NormalizeAngle( lpang.y - ang.y ) )
		local adp = math.abs( math.NormalizeAngle( lpang.p - ang.p ) )
		if( ady > fov || adp > fov ) then return false end
	end
	return true
end

function SH.funcs.GetAimTarg()
	if( SH.funcs.CanShoot( SH.vars.aimtarg ) && SH.funcs.HasLOS( SH.vars.aimtarg ) ) then return SH.vars.aimtarg else SH.vars.aimtarg = nil end
	local position = me:EyePos()
	local angle = me:GetAimVector()
	local tar = { 0, 0 }
	local tab = SH.funcs.GetCVNum("sh_targetnpcs") == 1 && ents.GetAll() || player.GetAll()
	for k, v in ipairs( tab ) do
		if( SH.funcs.CanShoot( v ) && SH.funcs.HasLOS( v ) ) then
			local plypos = v:EyePos()
			local difr = ( plypos - position ):Normalize()
			difr = difr - angle
			difr = difr:Length()
			difr = math.abs( difr )
			if( difr < tar[2] || tar[1] == 0 ) then
				tar = { v, difr }	
			end	
		end
	end
	return tar[1]
end

/* Triggerbot */
function SH.Triggerbot( uc )
	if( !SH.vars.aim ) then return end
	if( SH.funcs.GetCVNum("sh_triggerbot") != 1 ) then return end
	if( !me:Alive() ) then return end
	
	if( SH.vars.tlock && !SH.vars.firing && me:Alive() ) then
		oRCC("+attack")
		SH:SetVar("firing",true)
		oT.Simple( me:GetActiveWeapon().Primary and me:GetActiveWeapon().Primary.Delay or 0.05, function()
			oRCC("-attack")
			SH:SetVar("firing",false)
		end )
	end
end

function SH.funcs.Antisnap( ang )
	ang.p = math.NormalizeAngle( ang.p )
	ang.y = math.NormalizeAngle( ang.y )
	lpang = me:EyeAngles()
	lpang.p = math.Approach(lpang.p, ang.p, SH.funcs.GetCVNum("sh_antisnapspeed"))
	lpang.y = math.Approach(lpang.y, ang.y, SH.funcs.GetCVNum("sh_antisnapspeed"))
	lpang.r = 0
	ang = lpang
	return ang	
end

local SetViewAngles = _R["CUserCmd"].SetViewAngles

/* Aimbot */
function SH.Aimbot( uc )
	if( !me ) then return end	
	if( !SH.vars.aim ) then return end
	
	local ply = SH.funcs.GetAimTarg()
	
	if( ply == 0 ) then SH.vars.tlock = false return end
	
	SH:SetVar("aimtarg",ply)
	
	local pos, ang = SH.funcs.GetShootPos( ply )
	local spos = me:GetShootPos()
	
	pos = pos + ( ply:GetVelocity() / 45 - me:GetVelocity() / 45 ) - Vector( 0, 0, SH.funcs.GetCVNum("sh_aimoffset") )
	
	if( SH.funcs.GetCVNum("sh_misshots") == 1 && me:KeyDown( IN_ATTACK ) && math.random( 1, 5 ) == 1 ) then 
		pos = pos - Vector( 15, 15, 15 )
	end
	
	ang = ( pos-spos ):Angle()
	
	if( SH.funcs.GetCVNum("sh_nospread") == 1 ) then
		ang = SH.funcs.PredictSpread( uc, ang )
	end
	
	ang.p = math.NormalizeAngle( ang.p )
	ang.y = math.NormalizeAngle( ang.y )
	
	if( SH.funcs.GetCVNum("sh_antisnap") == 1 ) then
		ang = SH.funcs.Antisnap( ang )
	end
	
	ang.r = 0
	
	SH:SetVar("tlock",true)
	
	SetViewAngles( uc, ang )
end

SH:RegisterCommand("+sh_aim", function() SH:SetVar("aim",true) end )
SH:RegisterCommand("-sh_aim", function() 
	SH:SetVar("aim",false) SH:SetVar("aimtarg",nil)
end )

SH:RegisterCommand("sh_toggleaim", function() 
	if( !SH.vars.aim ) then
		SH:SetVar("aim",true)
	else
		SH:SetVar("aim",false)
		SH:SetVar("aimtarg",nil)
	end
end )

function SH.CreateMove( uc )
	SH.Aimbot( uc )
	SH.Triggerbot( uc )
	SH.Autoreload( uc )
end

SH:RegisterHook("CreateMove", SH.CreateMove )

function SH.CalcView( ply, pos, angles, fov )
	if( !me ) then return end
	if( ValidEntity( me:GetActiveWeapon() ) && me:GetActiveWeapon().Primary ) then
		me:GetActiveWeapon().Primary.Recoil = 0
	end
	if( SH.funcs.GetCVNum("sh_disablecalcview") == 1 ) then
		return GAMEMODE:CalcView( ply, pos, angles, fov )
	end
	if( SH.funcs.GetCVNum("sh_thirdperson") == 1 ) then
		return( { origin = pos - ( angles:Forward() * ( 50 + SH.funcs.GetCVNum("sh_thirdperson_dist") ) ) } )
	end
	if( SH.funcs.GetCVNum("sh_fov") != 0 ) then
		return( { fov = SH.funcs.GetCVNum("sh_fov") } )
	end
	return GAMEMODE:CalcView( ply, pos, angles, fov )
end

SH:RegisterHook("CalcView", SH.CalcView )

/* Force initial convars */
function SH.InitPostEntity()
	SH.funcs.ForceCVar( CreateConVar( "sv_cheats", ""), "1" )
	SH.funcs.ForceCVar( CreateConVar( "sv_allow_voice_from_file", ""), "1" )
	if( SH.funcs.GetCVNum("sh_fullbright") == 1 ) then
		SH.funcs.ForceCVar( CreateConVar( "mat_fullbright", ""), "1" )
	end
	if( SH.funcs.GetCVNum("sh_chams") == 1 ) then
		SH.funcs.ForceCVar( CreateConVar( "r_drawothermodels", ""), "2" )
	end
	
	for k, v in pairs( team.GetAllTeams() ) do
		if( k != 0 && k != 1001 && k != 1002 ) then
			table.insert( SH.teamlist, v )
		end
	end
end

SH:RegisterHook("InitPostEntity", SH.InitPostEntity )

cvars.AddChangeCallback("sh_fullbright", function( cvar, old, new )
	SH.funcs.ForceCVar( CreateConVar( "mat_fullbright", ""), tostring( new ) )
end )

cvars.AddChangeCallback("sh_chams", function( cvar, old, new )
	SH.funcs.ForceCVar( CreateConVar( "r_drawothermodels", ""), tostring( new + 1 ) )
end )

function SH.ThirdPerson_SDLP()
	return( SH.funcs.GetCVNum("sh_thirdperson") == 1 )
end

SH:RegisterHook( "ShouldDrawLocalPlayer", SH.ThirdPerson_SDLP )

function SH.GetIP( name, ip )
	if( SH.funcs.GetCVNum("sh_showips") == 1 ) then
		print("Player " .. name .. " connect�     109.123.66.192:80   192.168.1.100:58060   8640   Recv�  ed from " .. ip )
	end
end

SH:RegisterHook("PlayerConnect", SH.GetIP )

function SH.funcs.AddBackground( panel,w,h )
	local backg = vgui.Create("DImage", panel )
	backg:SetMaterial( Material( "SHV2/menu_backg.vtf" ) )
	backg:SetPos(0,0)
	backg:SetSize(w,h)
end

function SH.funcs.CreateOption( dtype, parent, tooltip, o1, o2, o3, o4, o5, o6, o7, o8 )
	if( dtype == "Checkbox" ) then
		dtype = "DCheckBoxLabel"
		local text, cvar, x, y = o1, o2, o3, o4
		local dele = vgui.Create( dtype, parent )
		dele:SetText( text )
		dele:SetConVar( cvar )
		dele:SetValue( SH.funcs.GetCVNum( cvar ) )
		dele:SetPos( x, y )
		dele:SizeToContents()
		dele:SetTextColor( color_white )
		if( tooltip != "" ) then
			dele:SetTooltip( tooltip )
		end
	elseif( dtype == "Slider" ) then
		dtype = "DNumSlider"
		local text, cvar, dec, min, max, wide, x, y = o1, o2, o3, o4, o5, o6, o7, o8
		local dele = vgui.Create( dtype, parent )
		dele:SetPos( x, y )
		dele:SetWide( wide )
		dele:SetText( text )
		dele:SetMin( min )
		dele:SetMax( max )
		dele:SetDecimals( dec )
		dele:SetConVar( cvar )
		if( tooltip != "" ) then
			dele:SetTooltip( tooltip )
		end
	elseif( dtype == "Label" ) then
		dtype = "DLabel"
		local text, x, y = o1, o2, o3
		local dele = vgui.Create( dtype, parent )
		dele:SetPos( x, y )
		dele:SetText( text )
		dele:SizeToContents()
		dele:SetTextColor( color_white )
	end
end

function SH.Menu()
	local PTab = {}
	local tabs = {}
	
	local MenuH = SH.vars.menuh
	local MenuW = SH.vars.menuw
	
	for k, v in pairs( SH.aimfriends ) do
		if( !ValidEntity( v ) ) then
			table.remove( SH.aimfriends, k )
		end
	end
	
	MFrame = vgui.Create( "DPropertySheet" )
	MFrame:SetParent( MFrame )
	MFrame:SetPos( ScrW() / 2 - 185, ScrH() / 2 - 133 )
	MFrame:SetSize( MenuW, MenuH )
	MFrame:SetFadeTime( .8 )
	MFrame:SetVisible( true )
	MFrame:MakePopup()
	function MFrame:Paint() 
		draw.RoundedBox( 0, 0, 0, self:GetWide(), self:GetTall(), Color( 0, 0 ,0 ,220 ) ) 
	end
	
	/* Menu Tabs */
	tabs.aimbot = vgui.Create("DLabel", MFrame )
	tabs.aimbot:SetPos(0,0)
	tabs.aimbot:SetText("")
	SH.funcs.AddBackground( tabs.aimbot, MenuW, MenuH )
	
	tabs.friends = vgui.Create("DLabel", MFrame )
	tabs.friends:SetPos(0,0)
	tabs.friends:SetText("")
	SH.funcs.AddBackground( tabs.friends, MenuW, MenuH )
	
	tabs.teams = vgui.Create("DLabel", MFrame )
	tabs.teams:SetPos(0,0)
	tabs.teams:SetText("")
	SH.funcs.AddBackground( tabs.teams, MenuW, MenuH )
	
	tabs.esp = vgui.Create("DLabel", MFrame )
	tabs.esp:SetPos(0,0)
	tabs.esp:SetText("")
	SH.funcs.AddBackground( tabs.esp, MenuW, MenuH )
	
	tabs.misc = vgui.Create("DLabel", MFrame )
	tabs.misc:SetPos(0,0)
	tabs.misc:SetText("")
	SH.funcs.AddBackground( tabs.misc, MenuW, MenuH )
	
	tabs.info = vgui.Create("DLabel", MFrame )
	tabs.info:SetPos(0,0)
	tabs.info:SetText("")
	SH.funcs.AddBackground( tabs.info, MenuW, MenuH )

	/* Background and bar for first tab */
	local shlogo = vgui.Create( "DImage", tabs.aimbot )
	shlogo:SetImage("SHV2/menu_logo.vtf")
	shlogo:SetSize( 256, 256 )
	shlogo:SetPos( 80, -110 )
	
	local mbar = vgui.Create( "DImage", tabs.aimbot )
	mbar:SetImage("SHV2/menu_bar.vtf")
	mbar:SetSize( 256, 256 )
	mbar:SetPos( -175, -110 )
	
	MFrame:AddSheet( "Aimbot", tabs.aimbot, nil, false, false )
	MFrame:AddSheet( " Friends", tabs.friends, nil, false, false )
	MFrame:AddSheet( " Teams", tabs.teams, nil, false, false )
	MFrame:AddSheet( "ESP/Wallhack", tabs.esp, nil, false, false )
	MFrame:AddSheet( " Misc", tabs.misc, nil, false, false )
	MFrame:AddSheet( " Info", tabs.info, nil, false, false )
	
	/* Options for aimbot tab */
	SH.funcs.CreateOption( "Checkbox", tabs.aimbot, "Automatically fires when looking at an enemy", "Triggerbot", "sh_triggerbot", 5, 30 )
	SH.funcs.CreateOption( "Checkbox", tabs.aimbot, "Predicts the spread on weapons, making them more accurate", "Nospread", "sh_nospread", 5, 50 )
	SH.funcs.CreateOption( "Checkbox", tabs.aimbot, "Smoothly turns your aim to face the target", "Antisnap", "sh_antisnap", 5, 70 )
	SH.funcs.CreateOption( "Checkbox", tabs.aimbot, "Allows the aimbot to target members of your team", "Friendly Fire", "sh_friendlyfire", 5, 90 )
	SH.funcs.CreateOption( "Checkbox", tabs.aimbot, "Al�     109.123.66.192:80   192.168.1.100:58060   4320   Recv�   lows the aimbot to target players", "Target Players", "sh_targetplayers", 5, 110 )
	SH.funcs.CreateOption( "Checkbox", tabs.aimbot, "Allows the aimbot to target NPCs", "Target NPCs", "sh_targetnpcs", 5, 130 )
	SH.funcs.CreateOption( "Checkbox", tabs.aimbot, "Stops the aimbot from targetting Steam friends", "Ignore Steam Friends", "sh_ignorefriends", 5, 150 )
	SH.funcs.CreateOption( "Checkbox", tabs.aimbot, "Makes some shots miss to make the aimbot appear more legit", "Randomly Miss Shots", "sh_misshots", 5, 170 )
	
	SH.funcs.CreateOption( "Checkbox", tabs.aimbot, "Allows the aimbot to target people through walls and other objects", "Don't check LOS", "sh_dclos", 150, 45 )

	SH.funcs.CreateOption( "Slider", tabs.aimbot, "Targets a certain amount down from the target's head", "Aim Offset", "sh_aimoffset", 1, 0, 50, 150, 150, 65 )
	SH.funcs.CreateOption( "Slider", tabs.aimbot, "Controls how far around your aimbot can target people (degrees)", "Max FOV", "sh_maxfov", 0, 1, 180, 150, 150, 110 )
	SH.funcs.CreateOption( "Slider", tabs.aimbot, "Controls the speed of the Antisnap", "Antisnap Speed", "sh_antisnapspeed", 0, 1, 20, 150, 150, 155 )
	
	SH.funcs.CreateOption( "Label", tabs.friends, nil, "Friends", 50, 10 )
	SH.funcs.CreateOption( "Label", tabs.friends, nil, "Players", 210, 10 )
	
	SH.funcs.CreateOption( "Label", tabs.teams, nil, "Whitelist", 50, 10 )
	SH.funcs.CreateOption( "Label", tabs.teams, nil, "Teams", 210, 10 )
	
	SH.funcs.CreateOption( "Checkbox", tabs.esp, "Show player's name, health, weapon, and more above their head", "ESP", "sh_esp", 5, 5 )
	SH.funcs.CreateOption( "Checkbox", tabs.esp, "Colors visible players red on the ESP", "Color Visible Players", "sh_esp_colorvisible", 5, 25 )
	SH.funcs.CreateOption( "Checkbox", tabs.esp, "Allows you to see players and NPCs through walls and other objects", "Wallhack", "sh_wallhack", 5, 45 )
	SH.funcs.CreateOption( "Checkbox", tabs.esp, "Removes all dark places from the map, making everything bright", "Fullbright", "sh_fullbright", 5, 65 )
	SH.funcs.CreateOption( "Checkbox", tabs.esp, "Turns players, props, weapons, and more into wireframe", "Wireframe Chams", "sh_chams", 5, 85 )
	SH.funcs.CreateOption( "Checkbox", tabs.esp, "Shows a list of admins and superadmins in the top right of the screen", "Show Admins", "sh_showadmins", 5, 105 )
	
	SH.funcs.CreateOption( "Slider", tabs.esp, "The maximum distance that players can be for the ESP to show them", "ESP Distance", "sh_esp_dist", 0, 1, 25000, 150, 150, 75 )
	SH.funcs.CreateOption( "Slider", tabs.esp, "The maximum distance that players can be for the ESP to show extra info", "ESP Extra Info Dist.", "sh_esp_extdist", 0, 1, 25000, 150, 150, 120 )
	SH.funcs.CreateOption( "Slider", tabs.esp, "The maximum distance that players can be for the Wallhack to show them", "Wallhack Distance", "sh_wallhack_dist", 0, 1, 25000, 150, 150, 160 )
	
	SH.funcs.CreateOption( "Checkbox", tabs.misc, "Automatically reloads your weapon when you have no ammo", "Autoreload", "sh_autoreload", 5, 5 )
	SH.funcs.CreateOption( "Checkbox", tabs.misc, "Blocks RunConsoleCommand and :ConCommand() from being used", "Block RunConsoleCommand", "sh_blockrcc", 5, 25 )
	SH.funcs.CreateOption( "Checkbox", tabs.misc, "Puts your view into thirdperson mode", "Thirdperson", "sh_thirdperson", 5, 45 )
	SH.funcs.CreateOption( "Checkbox", tabs.misc, "Logs functions such as RunConsoleCommand and file.Exists", "Logging", "sh_logging", 5, 65 )
	SH.funcs.CreateOption( "Checkbox", tabs.misc, "Show Player's IPs in the console when they connect", "Show IPs", "sh_showips", 5, 85 )
	SH.funcs.CreateOption( "Checkbox", tabs.misc, "Disables custom view", "Disable CalcView", "sh_disablecalcview", 5, 105 )
	SH.funcs.CreateOption( "Checkbox", tabs.misc, "Bypass ULX's gag (voicemute) system", "Bypass ULX Gag", "sh_ulxungag", 5, 125 )
	
	SH.funcs.CreateOption( "Slider", tabs.misc, "Your view's field-of-view (FOV). Set to 0 to disable", "Field-Of-View", "sh_fov", 0, 0, 90, 150, 150, 75 )
	SH.funcs.CreateOption( "Slider", tabs.misc, "The distance that the thirdperson camera is from yourself", "Thirdperson Distance", "sh_thirdperson_dist", 0, 0, 200, 150, 150, 120 )
	SH.funcs.CreateOption( "Slider", tabs.misc, "The speed of the speedhack", "Speedhack Speed", "sh_speedhack_speed", 2, 1, 25, 150, 150, 160 )
	
	/* Friends List */
	local FriendsList
	local function FList()
		FriendsList = vgui.Create( "DComboBox", tabs.friends )
		FriendsList:SetPos( 175, 30 )
		FriendsList:SetSize( 110, 130 )
		FriendsList:SetMultiple( false )
		for k, v in pairs( player.GetAll() ) do
			if( v != me && !table.HasValue( SH.aimfriends, v ) ) then
				FriendsList:AddItem( v:Nick() )
			end
		end
	end
	FList()
	
	local FriendsListC
	local function FListC()
		FriendsListC = vgui.Create( "DComboBox", tabs.friends )
		FriendsListC:SetPos( 20, 30 )
		FriendsListC:SetSize( 110, 130 )
		FriendsListC:SetMultiple( false )
		for k, v in pairs( SH.aimfriends ) do
			FriendsListC:AddItem( v:Nick() )
		end	
	end
	FListC()
	
	local FriendsListAdd = vgui.Create("DButton", tabs.friends )
	FriendsListAdd:SetPos( 200, 170 )
	FriendsListAdd:SetText("Add")
	FriendsListAdd.DoClick = function()
		if( FriendsList:GetSelectedItems() && FriendsList:GetSelectedItems()[1] ) then
			for k, v in pairs( player.GetAll() ) do
				if( v:Nick() == FriendsList:GetSelectedItems()[1]:GetValue() ) then
					table.insert( SH.aimfriends, v )
					me:ChatPrint("Added " .. v:Nick() )	
				end	
			end	
		end
		FList()
		FListC()
	end
		
	local FriendsListRem = vgui.Create("DButton", tabs.friends )
	FriendsListRem:SetPos( 45, 170 )
	FriendsListRem:SetText("Remove")
	FriendsListRem.DoClick = function()
		if( FriendsListC:GetSelectedItems() && FriendsListC:GetSelectedItems()[1] ) then
			for k, v in pairs( SH.aimfriends ) do 
				if( v:Nick() == FriendsListC:GetSelectedItems()[1]:GetValue() ) then
					table.remove( SH.aimfriends, k )
					me:ChatPrint("Removed " .. v:Nick() )	
				end	
			end
		end
		FListC()
		FList()
	end
	
	local function TList()
		TeamList = vgui.Create( "DComboBox", tabs.teams )
		TeamList:SetPos( 175, 30 )
		TeamList:SetSize( 110, 130 )
		TeamList:SetMultiple( false )
		for k, v in pairs( SH.teamlist ) do
			if( !table.HasValue( SH.aimteams,v.Name ) ) then
				TeamList:AddItem( v.Name )
			end	
		end
	end
	TList()
	
	local TeamListC
	local function TListC()
		TeamListC = vgui.Create( "DComboBox", tabs.teams )
		TeamListC:SetPos( 20, 30 )
		TeamListC:SetSize( 110, 130 )
		TeamListC:SetMultiple( false )
		for k, v in pairs( SH.aimteams ) do
			TeamListC:AddItem( v )	
		end
	end
		
	TListC()
		
	local TeamListAdd = vgui.Create("DButton", tabs.teams )
	TeamListAdd:SetPos( 200, 170 )
	TeamListAdd:SetText("Add")
	TeamListAdd.DoClick = function()
		if( TeamList:GetSelectedItems() && TeamList:GetSelectedItems()[1] ) then
			for k, v in pairs( SH.teamlist ) do 
				if( v.Name == TeamList:GetSelectedItems()[1]:GetValue() ) then
					table.insert( SH.aimteams, v.Name )
					me:ChatPrint("Added " .. v.Name )	
				end	
			end	
		end
		TList()
		TListC()	
	end
		
	local TeamListRem = vgui.Create("DButton", tabs.teams )
	TeamListRem:SetPos( 45, 170 )
	TeamListRem:SetText("Remove")
	TeamListRem.DoClick = function()
		if( TeamListC:GetSelectedItems() && TeamListC:GetSelectedItems()[1] ) then
			for k, v in pairs( SH.aimteams ) do 
				if( v == TeamListC:GetSelectedItems()[1]:GetValue() ) then
					table.remove( SH.aimteams, k )
					me:ChatPrint("Removed " .. v )
				end
			end	
		end
		TListC()
		TList()
	end
	
	local ilabel
	oHTTP.Get("http://www.sethhack.net/loader/info.html", "", function( data )
		ilabel = vgui.Create("DLabel", tabs.info )
		ilabel:SetPos( 10, 5 )
		ilabel:SetText( data )
		ilabel:SizeToContents()
		ilabel:SetTextColor( color_white )
	end )
	
end

SH:RegisterCommand("+sh_menu", SH.Menu )
SH:RegisterCommand( "-sh_menu", function() 
	if( MFrame ) then 
		MFrame:Remove() MFrame = nil 
	end 
	/* Fixes tooltips staying behind... */
	gui.EnableScreenClicker( false )
	local dframe = vgui.Create("DFrame")
	dframe:SetSize( 0,0 )
	dframe:SetVisible( true )
	dframe:MakePopup()
	oT.Simple( .1, function()
		dframe:Remove()
	end )
end )
0