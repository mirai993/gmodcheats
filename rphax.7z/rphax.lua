--[[
	rphax.lua
	Teh UDS :3 | (STEAM_0:1:25849684)
	===DStream===
]]

if !( CLIENT ) then return end

local RPH = {}
do
	local hooks = {}
	local created = {}
	local function CallHook(self, name, args)
		if !hooks[name] then return end
		for funcName, _ in pairs(hooks[name]) do
			local func = self[funcName]
			if func then
				local ok, err = pcall(func, self, unpack(args or {}))
				if !ok then
					ErrorNoHalt(err .. "\n")
				elseif err then
					return err

				end
			end
		end
	end
	local function RandomName()
		local random = ""
		for i = 1, math.random(4, 10) do
			local c = math.random(65, 116)
			if c >= 91 && c <= 96 then c = c + 6 end
			random = random .. string.char(c)
		end
		return random
	end
	local function AddHook(self, name, funcName)
		-- If we haven't got a hook for this yet, make one with a random name and store it.
		-- This is so anti-cheats can't detect by hook name, and so we can remove them later.
		if !created[name] then
			local random = RandomName()
			hook.Add(name, random, function(...) return CallHook(self, name, {...}) end)
			created[name] = random
		end
		
		hooks[name] = hooks[name] or {}
		hooks[name][funcName] = true
	end
	
	local cvarhooks = {}
	local function GetCallbackTable(convar)
		local callbacks = cvars.GetConVarCallbacks(convar)
		if !callbacks then
			cvars.AddChangeCallback(convar, function() end)
			callbacks = cvars.GetConVarCallbacks(convar)
		end
		return callbacks
	end
			
	local function AddCVarHook(self, convar, funcName, ...)
		local hookName = "CVar_" .. convar
		if !cvarhooks[convar] then
			local random = RandomName()
			
			local callbacks = GetCallbackTable(convar)
			callbacks[random] = function(...)
				CallHook(self, hookName, {...})
			end
			
			cvarhooks[convar] = random
		end
		AddHook(self, hookName, funcName)
	end
	
	-- Don't let other scripts remove our hooks.
	local oldRemove = hook.Remove
	function hook.Remove(name, unique)
		if created[name] == unique then return end
		oldRemove(name, unique)
	end
	
	-- Removes all hooks, useful if reloading the script.
	local function RemoveHooks()
		for hookName, unique in pairs(created) do
			oldRemove(hookName, unique)
		end
		for convar, unique in pairs(cvarhooks) do
			local callbacks = GetCallbackTable(convar)
			callbacks[unique] = nil
		end
	end

	-- Add copies the script can access.
	RPH.AddHook = AddHook
	RPH.AddCVarHook = AddCVarHook
	RPH.CallHook = CallHook
	RPH.RemoveHooks = RemoveHooks
end
do
	local settings = {}
	local function SettingVar(self, name)
		return (self.SettingPrefix or "") .. string.lower(name)
	end
	
	local function RandomName()
		local random = ""
		for i = 1, math.random(4, 10) do
			local c = math.random(65, 116)
			if c >= 91 && c <= 96 then c = c + 6 end
			random = random .. string.char(c)
		end
		return random
	end
	
	local function SetSetting(name, _, new)
		if !settings[name] then return end
		local info = settings[name]
		
		if info.Type == "number" then
			new = tonumber(new)
		elseif info.Type == "boolean" then
			new = (tonumber(new) or 0) > 0
		end
		
		info.Value = new
	end
	
	local function CreateSetting(self, name, desc, default, misc)
		local cvar = SettingVar(self, name)
		local info = {Name = name, Desc = desc, CVar = cvar, Type = type(default), Value = default}
		
		for k, v in pairs(misc or {}) do
			if !info[k] then info[k] = v end
		end
		
		// Convert default from boolean to number.
		if type(default) == "boolean" then
			default = default and 1 or 0
		end
		
		if !settings[cvar] then
			local tab = cvars.GetConVarCallbacks(cvar)
			if !tab then
				cvars.AddChangeCallback(cvar, function() end)
				tab = cvars.GetConVarCallbacks(cvar)
			end
			
			while true do
				local name = RandomName()
				if !tab[name] then
					tab[name] = SetSetting
					info.Callback = name
					break
				end
			end
		end
		
		settings[cvar] = info
		settings[#settings + 1] = info
		
		// Create the convar.
		CreateClientConVar(cvar, default, (info.Save != false), false)
		SetSetting(cvar, _, GetConVarString(cvar))
	end
	local function GetSetting(self, name)
		local cvar = SettingVar(self, name)
		if !settings[cvar] then return end
		return settings[cvar].Value
	end
	local function Shutdown()
		print("Removing settings callbacks...")
		for _, info in ipairs(settings) do
			if info.CVar && info.Callback then
				local tab = cvars.GetConVarCallbacks(info.CVar)
				if tab then
					tab[info.Callback] = nil
				end
			end
		end
	end
	local function SettingsList()
		return table.Copy(settings)
	end
	local function BuildMenu(self, panel)
		for _, info in ipairs(settings) do
			if info.Show != false then
				if info.MultiChoice then
					local m = panel:MultiChoice(info.Desc or info.CVar, info.CVar)
					for k, v in pairs(info.MultiChoice) do
						m:AddChoice(k, v)
					end
				elseif info.Type == "number" then
					panel:NumSlider(info.Desc or info.CVar, info.CVar, info.Min or -1, info.Max or -1, info.Places or 0)
				elseif info.Type == "boolean" then
					panel:CheckBox(info.Desc or info.CVar, info.CVar)
				elseif info.Type == "string" then
					panel:TextEntry(info.Desc or info.CVar, info.CVar)
				end
			end
		end
	end
	
	RPH.SettingPrefix = "rph_"
	RPH.CreateSetting = CreateSetting
	RPH.Setting = GetSetting
	RPH.SettingsList = SettingsList
	RPH.NoRecoilEnabled = false
	RPH.BuildMenu = BuildMenu
	RPH.SettingsShutdown = Shutdown
	RPH:AddHook("Shutdown", "SettingsShutdown")
end

local function DrawText(text,font,x,y,color,centeralign) 
	surface.SetFont( font );
	if centeralign then 
		surface.SetTextPos( x-(surface.GetTextSize(text)/2), y );
	else
		surface.SetTextPos( x, y );
	end
	surface.SetTextColor( color );
	surface.DrawText( text );
end
local function Jump(bool) 
	RunConsoleCommand((bool and "+" or "-").."jump")
end
local function FillRGBA(x,y,w,h,col)
	surface.SetDrawColor( col.r, col.g, col.b, col.a );
	surface.DrawRect( x, y, w, h );
end
local function OutlineRGBA(x,y,w,h,col)
	surface.SetDrawColor( col.r, col.g, col.b, col.a );
	surface.DrawOutlinedRect( x, y, w, h );
end
local function GetMeta(name)
	return table.Copy(_R[name] or {})
end

local UCmdM = GetMeta("CUserCmd"); 
local AngM = GetMeta("Angle")
local EntM = GetMeta("Entity")
local PlyM = GetMeta("Player")
local VecM = GetMeta("Vector")

function RPH:HeadPos(ply)
	if ValidEntity(ply) then
		local hbone = EntM["LookupBone"](ply,"ValveBiped.Bip01_Head1")
		return EntM["GetBonePosition"](ply,hbone)
	else return end
end
function RPH:Visible(ply)
	local trace = {start = PlyM["GetShootPos"](LocalPlayer()),endpos = self:HeadPos(ply),filter = {LocalPlayer(), ply}}
	local tr = util.TraceLine(trace)
	if tr.Fraction == 1 then
		return true
	else
		return false
	end    
end

concommand.Add(RPH.SettingPrefix.."unload", function()
	RPH:CallHook("Shutdown")
	print("Removing hooks...")
	RPH:RemoveHooks()
	concommand.Remove(RPH.SettingPrefix.."unload")
	concommand.Remove(RPH.SettingPrefix.."menu")
end)

--------------------------------
--No Recoil Part
RPH.View = EntM["EyeAngles"](LocalPlayer())

RPH:CreateSetting("norecoil_enable", "Enable NoRecoil", true)
function RPH:rphCreateMove(u)
	local ply = LocalPlayer();
	local wpn = PlyM["GetActiveWeapon"](ply);
	if (self.NoRecoilEnabled) then
		self.View.p = math.Clamp(self.View.p + (UCmdM["GetMouseY"](u) * GetConVarNumber("m_pitch")), -89, 89)
		self.View.y = math.NormalizeAngle(self.View.y + (UCmdM["GetMouseX"](u) * GetConVarNumber("m_yaw") * -1))
		UCmdM["SetViewAngles"]( u, self.View );
	end
end
RPH:AddHook("CreateMove","rphCreateMove");

function RPH:rphCalcView(u, pos, ang, fov)
	local ply = LocalPlayer();
    if (self.NoRecoilEnabled) then
        return { origin = pos, angles = self.View };
    else
        self.View = EntM["EyeAngles"](ply);
    end
end 
RPH:AddHook("CalcView","rphCalcView");

--------------------------------
--WH Part
RPH:CreateSetting("crosshair_enable", "Enable Crosshair", true)
RPH:CreateSetting("crosshair_scale", "Crosshair Scale", 5, { Min = 2, Max = 100 })

RPH:CreateSetting("esp_enable", "Enable ESP", true)
RPH:CreateSetting("esp_showents", "Show Entities in ESP", true)
RPH:CreateSetting("esp_ents", "Entities", "printer,spawned_money,shipment")
RPH:CreateSetting("esp_showplayers", "Show Players in ESP", true)
function RPH:rphHUDPaint()
	local ply = LocalPlayer();
    if (self:Setting("crosshair_enable")) then
		local w = (ScrW() / 2);
		local h = (ScrH() / 2);
		local csc = self:Setting("crosshair_scale")

		local gap = csc
		local length = gap + 10
		 
		--draw the crosshair
		surface.SetDrawColor(Color(255,0,0,255))
		surface.DrawLine( w - length, h, w - gap, h )
		surface.DrawLine( w + length, h, w + gap, h )
		surface.DrawLine( w, h - length, w, h - gap )
		surface.DrawLine( w, h + length, w, h + gap )
        local trace = util.GetPlayerTrace( ply );
        local traceRes = util.TraceLine( trace );
        if traceRes.HitNonWorld then
            local target = traceRes.Entity;
            if target:IsPlayer() then
				local color = team.GetColor(target:Team())
                DrawText( target:GetName(), 'TargetID', w, h-25, color, true );
                DrawText( target:Health()..'%', 'TargetID', w, h+10, color, true );
            end
		end
    end
    if (self:Setting("esp_enable")) then
	
		for k,v in pairs(ents.GetAll()) do
			if (v and ValidEntity(v)) then

				if (self:Setting("esp_showents")) then
					for num,ent in pairs(string.Explode(",",self:Setting("esp_ents"))) do
						if (EntM["GetClass"](v):find(ent)) then
							local printerPos = VecM["ToScreen"](EntM["LocalToWorld"](v, EntM["OBBCenter"](v)));
							local Cross = 10;
							surface.SetDrawColor(Color(255,0,0,255));
							surface.DrawLine( printerPos.x-Cross, printerPos.y, printerPos.x+Cross, printerPos.y );
							surface.DrawLine( printerPos.x, printerPos.y-Cross, printerPos.x, printerPos.y+Cross );
							draw.DrawText( EntM["GetClass"](v), "DefaultFixedOutline", printerPos.x, printerPos.y, Color(255,50,0,255),1);
						end
					end
				end
				
				if (self:Setting("esp_showplayers")) then
					if (PlyM["IsPlayer"](v) and v~=ply and EntM["Health"](v)>0 and PlyM["Alive"](v)) then
						local headPos, headAng = self:HeadPos(v);
						local drawColor = team.GetColor(PlyM["Team"](v));
						local drawPosit = VecM["ToScreen"](headPos);
						drawColor.a = 255;
						
						local textData = {}
						
						textData.pos = {}
						textData.pos[1] = drawPosit.x;
						textData.pos[2] = drawPosit.y;
						textData.color = drawColor;
						textData.text = PlyM["GetName"](v);
						textData.font = "DefaultFixedDropShadow";
						textData.xalign = TEXT_ALIGN_CENTER;
						textData.yalign = TEXT_ALIGN_CENTER;
						draw.Text( textData );
						
						local max_health = 100;
						
						if( EntM["Health"](v) > max_health )then
							max_health = EntM["Health"](v);
						end
						
						local mx = max_health / 4;
						local mw = EntM["Health"](v) / 4;
						
						local drawPosHealth = drawPosit;
						
						drawPosHealth.x = drawPosHealth.x - ( mx / 2 );
						drawPosHealth.y = drawPosHealth.y + 10;
						
						FillRGBA( drawPosHealth.x - 1, drawPosHealth.y - 1, mx + 2, 4 + 2, Color( 0, 0, 0, 255 ) );
						FillRGBA( drawPosHealth.x, drawPosHealth.y, mw, 4, drawColor );
					end
				end
				
			end
        end
		
    end
end 
RPH:AddHook("HUDPaint", "rphHUDPaint");

--------------------------------
-- BunnyHop Part
RPH:CreateSetting("bunnyhop_enable", "Enable Bunny Hopping", true)
function RPH:rphThink()
	local ply = LocalPlayer();
	local wpn = PlyM["GetActiveWeapon"](ply)
	if (self:Setting("norecoil_enable")) and PlyM["Alive"](ply) and wpn and ValidEntity(wpn)
		and not (wpn:GetClass()=="weapon_physgun" and PlyM["KeyDown"](ply,IN_ATTACK) and PlyM["KeyDown"](ply,IN_USE))
		and not (ConVarExists("snap_enabled") and GetConVarNumber("snap_enabled")==1 and GetConVarNumber("snap_alltools")==1 and PlyM["KeyDown"](ply,IN_USE))
		and not (wpn:GetClass()=="gmod_tool") then
        self.NoRecoilEnabled = true
    else
        self.NoRecoilEnabled = false
    end
    if (self:Setting("bunnyhop_enable") and input.IsKeyDown(KEY_SPACE)) then
        Jump(EntM["OnGround"](ply))
    else
        Jump(false)
    end
end
RPH:AddHook("Think", "rphThink" );

function RPH:OpenMenu()
	local w, h = ScrW() / 3, ScrH() / 2

	local menu = vgui.Create("DFrame")
	menu:SetTitle("ESP by UDS();")
	menu:SetSize(w, h)
	menu:Center()
	menu:MakePopup()

	local scroll = vgui.Create("DPanelList", menu)
	scroll:SetPos(5, 25)
	scroll:SetSize(w - 10, h - 30)
	scroll:EnableVerticalScrollbar()

	local form = vgui.Create("DForm", menu)
	form:SetName("")
	form.Paint = function() end
	scroll:AddItem(form)

	self:BuildMenu(form)

	if RPH.Menu then RPH.Menu:Remove() end
	RPH.Menu = menu
end
concommand.Add("rph_menu", function() RPH:OpenMenu() end)

Msg([[
=================
Hack enabled! :D
Type 'rph_unload' to unload the script
=================
]]);
