--[[
	newbot1337.lua
	Erfie - New Phone :D | (STEAM_0:0:11602053)
	===DStream===
]]

//cache\\ /<<--- tekmas fag
local pairs = pairs
local hook = hook
local LocalPlayer = LocalPlayer
local CreateClientConVar = CreateClientConVar
local RunConsoleCommand = RunConsoleCommand
local table = table
local surface = surface
local cam = cam
local render = render 
local util = util   
local math = math
local Entity = Entity
local team = team
local string = string
local ents = ents
local vgui = vgui
local concommand = concommand


//##ConsoleCommands##\\
//Aimboat
local aimbotcmd = CreateClientConVar("Bot_Aimbot",0,true,false)
local ignoreteamcmd = CreateClientConVar("Bot_IgnoreTeam",0,true,false)
local ignoresteamcmd = CreateClientConVar("Bot_IgnoreSteam",0,true,false)
local ignoreadminscmd = CreateClientConVar("Bot_IgnoreAdmins",0,true,false)
local triggerbotcmd = CreateClientConVar("Bot_TriggerBot",0,true,false)
local autoreloadcmd = CreateClientConVar("Bot_AutoReload",1,true,false)
local aimbotfovvalcmd = CreateClientConVar("Bot_FOVValue",1,true,false)

//ESP
local ESP = CreateClientConVar("Bot_ESP",1,true,false)
local Boxie = CreateClientConVar("Bot_Box",1,true,false)
local ESPSkeleton = CreateClientConVar("Bot_Skeleton",0,true,false)
local ESPInfo = CreateClientConVar("Bot_ESPInfo",1,true,false)
local ESPExtra = CreateClientConVar("Bot_ESPExtra",0,true,false)
local NPCESP = CreateClientConVar("Bot_ESPNPC",1,true,false)
local ESPDist = CreateClientConVar("Bot_ESPDist",5000,true,false)

//Misc
local Bhop = CreateClientConVar("Bot_Bhop",0,true,false)
local Tracer = CreateClientConVar("Bot_Tracer",1,true,false)
local Wallhack = CreateClientConVar("Bot_Wallhack",1,true,false)
local WallhackDist = CreateClientConVar("Bot_WallhackDist",5000,true,false)
local ViewModel = CreateClientConVar("Bot_View",255,true,false)
local TraceDist = CreateClientConVar("Bot_TraceDist",1000,true,false)
local DrawFovcmd = CreateClientConVar("Bot_DrawFOV",1,true,false)
local NoHandsOrWeapons = CreateClientConVar("Bot_NoWeapons",1,true,false)
local Barrelhack = CreateClientConVar("Bot_Barrel",1,true,false)
local Chamscmd = CreateClientConVar("Bot_Chams",0,true,false)
local Glow = CreateClientConVar("Bot_OutGlow",0,true,false)
local WireFrame = CreateClientConVar("Bot_Wire",0,true,false)
local DynamicLightR = CreateClientConVar("Bot_DR",255,true,false)
local DynamicLightG = CreateClientConVar("Bot_DG",255,true,false)
local DynamicLightB = CreateClientConVar("Bot_DB",255,true,false)
local DynamicLightSize = CreateClientConVar("Bot_DSize",255,true,false)
local DynamicLightBrightness = CreateClientConVar("Bot_DBrightness",1,true,false)
local DynamicLightEnable = CreateClientConVar("Bot_DE",0,true,false)

Friends = {}
EntTable = {}


table.insert(EntTable,"models/props_c17/fence01b.mdl")
table.insert(EntTable,"models/props_c17/fence01a.mdl")
table.insert(EntTable,"models/props_c17/fence02a.mdl")
table.insert(EntTable,"models/props_c17/fence02b.mdl")
table.insert(EntTable,"models/props_c17/fence03a.mdl")
table.insert(EntTable,"models/props_c17/fence04a.mdl")
table.insert(EntTable,"models/props_c17/gate_door02a.mdl")
table.insert(EntTable,"models/props_c17/gate_door01a.mdl")
table.insert(EntTable,"models/props_c17/metalladder001.mdl")
table.insert(EntTable,"models/props_wasteland/barricade002a.mdl")
table.insert(EntTable,"models/props_wasteland/barricade001a.mdl")

local ply = LocalPlayer()

function OuterGlow()
if Glow:GetBool() then
local I = (1/255)
for k, v in pairs(player.GetAll()) do
if ValidEntity(v) and v:Alive() then
cam.Start3D( EyePos(), EyeAngles())
local TeamColor = team.GetColor(v:Team())
render.SuppressEngineLighting(true)
render.SetColorModulation((TeamColor.r*I),(TeamColor.g*I),(TeamColor.b*I))
v:SetMaterial("hlmv/debugmrmwireframe")
v:DrawModel()
render.SuppressEngineLighting(false)
render.SetColorModulation(1,1,1)
v:SetMaterial("")
v:DrawModel()
cam.End3D()
end
end
end
end
hook.Add("HUDPaint","Glowing",OuterGlow)

function WireF()
if WireFrame:GetBool() then
local I = (1/255)
for k, v in pairs(player.GetAll()) do
if ValidEntity(v) and v:Alive() then
cam.Start3D( EyePos(), EyeAngles())
local TeamColor = team.GetColor(v:Team())
render.SuppressEngineLighting(true)
render.SetColorModulation((TeamColor.r*I),(TeamColor.g*I),(TeamColor.b*I))
v:SetMaterial("hlmv/debugmrmwireframe")
v:DrawModel()
render.SuppressEngineLighting(false)
render.SetColorModulation(1,1,1)
v:SetMaterial("")
v:DrawModel()
cam.End3D()
end
end
end
end
hook.Add("RenderScreenspaceEffects","WireFrames",WireF)

local function LuaMaterial()

local Texture = {
  ["$basetexture"] = "models/debug/debugwhite",
  ["$model"]       = 1,
  ["$translucent"] = 1,
  ["$alpha"]       = 1,
  ["$nocull"]      = 1,
  ["$ignorez"]  = 1
}
   
local material = CreateMaterial("Bot_Solid","VertexLitGenerc",Texture)

return material

end

function Chams()
if Chamscmd:GetBool() then
local I = (1/255)
for k, v in pairs( player.GetAll() ) do
if v!= ply then
if ValidEntity(v) and v:Health() > 0 || v:Alive() and v:Team() != TEAM_SPECTATOR then
cam.Start3D( EyePos(), EyeAngles() )
local TeamColor = team.GetColor(v:Team())
local mat = LuaMaterial()
render.SuppressEngineLighting(true)
render.SetColorModulation((TeamColor.r*I),(TeamColor.g*I),(TeamColor.b*I))
SetMaterialOverride(mat)
v:DrawModel()
render.SuppressEngineLighting(false)
render.SetColorModulation(1,1,1)
SetMaterialOverride()
v:DrawModel()
cam.End3D()
end
end
end
end
end
hook.Add("RenderScreenspaceEffects","PlayerChams",Chams)



local skeleton = {

// Main body
{ S = "ValveBiped.Bip01_Head1", E = "ValveBiped.Bip01_Neck1" },
{ S = "ValveBiped.Bip01_Neck1", E = "ValveBiped.Bip01_Spine4" },
{ S = "ValveBiped.Bip01_Spine4", E = "ValveBiped.Bip01_Spine2" },
{ S = "ValveBiped.Bip01_Spine2", E = "ValveBiped.Bip01_Spine1" },
{ S = "ValveBiped.Bip01_Spine1", E = "ValveBiped.Bip01_Spine" },
{ S = "ValveBiped.Bip01_Spine", E = "ValveBiped.Bip01_Pelvis" },

// Left Arm
{ S = "ValveBiped.Bip01_Spine4", E = "ValveBiped.Bip01_L_UpperArm" },
{ S = "ValveBiped.Bip01_L_UpperArm", E = "ValveBiped.Bip01_L_Forearm" },
{ S = "ValveBiped.Bip01_L_Forearm", E = "ValveBiped.Bip01_L_Hand" },

// Right Arm
{ S = "ValveBiped.Bip01_Spine4", E = "ValveBiped.Bip01_R_UpperArm" },
{ S = "ValveBiped.Bip01_R_UpperArm", E = "ValveBiped.Bip01_R_Forearm" },
{ S = "ValveBiped.Bip01_R_Forearm", E = "ValveBiped.Bip01_R_Hand" },

// Left leg
{ S = "ValveBiped.Bip01_Pelvis", E = "ValveBiped.Bip01_L_Thigh" },
{ S = "ValveBiped.Bip01_L_Thigh", E = "ValveBiped.Bip01_L_Calf" },
{ S = "ValveBiped.Bip01_L_Calf", E = "ValveBiped.Bip01_L_Foot" },
{ S = "ValveBiped.Bip01_L_Foot", E = "ValveBiped.Bip01_L_Toe0" },

// Right leg
{ S = "ValveBiped.Bip01_Pelvis", E = "ValveBiped.Bip01_R_Thigh" },
{ S = "ValveBiped.Bip01_R_Thigh", E = "ValveBiped.Bip01_R_Calf" },
{ S = "ValveBiped.Bip01_R_Calf", E = "ValveBiped.Bip01_R_Foot" },
{ S = "ValveBiped.Bip01_R_Foot", E = "ValveBiped.Bip01_R_Toe0" },
}
local function Skeleton(e)
if ESPSkeleton:GetBool() then
if e:IsPlayer() and e:Alive() then
for k, v in pairs( skeleton ) do

local sPos, ePos = e:GetBonePosition( e:LookupBone( v.S ) ):ToScreen(), e:GetBonePosition( e:LookupBone( v.E ) ):ToScreen()


if e:IsNPC() then
surface.SetDrawColor(Color(255,255,255))
end

if e:IsPlayer() and !e:IsNPC() then
surface.SetDrawColor(team.GetColor(e:Team()))
end

surface.DrawLine(sPos.x,sPos.y,ePos.x,ePos.y)
end
end
end
end

hook.Add("HUDPaint", "SkeletonESP", function()
for k,v in pairs(ents.GetAll()) do
if(v!=LocalPlayer()) then
Skeleton(v)
end
end
end)

function DerpNoRecoil()
if LocalPlayer():GetActiveWeapon().Primary then
LocalPlayer():GetActiveWeapon().Primary.Recoil = 0
end
end
hook.Add("Think","No Recoilz",DerpNoRecoil) 

function findsmallest(Table) 
    if Table == nil then return end
        local TBL = table.Copy(Table)
    table.sort(TBL)
    return TBL[1]
end

function findcorrect(Array,number)
    if Array == nil then return end
        if number == nil then return end
        for k,v in pairs(Array) do
        if number == v then
        return k
        end
    end
end

function findclosest(Array)
    local smallest = findsmallest(Array)
    local nummer = findcorrect(Array,smallest)
    return nummer
end

function DrawTracer() 
if Tracer:GetBool() then 
for k,v in pairs(player.GetAll()) do
if (v:GetPos() - ply:GetPos()):Length() <= GetConVarNumber("Bot_TraceDist") then ///niggers everywher mcd bro	
if (v!=LocalPlayer() and v:Alive() and v:IsPlayer()) then

cam.Start3D( EyePos() , EyeAngles())
render.SetMaterial( Material( "cable/physbeam" ) )

pos2 = v:GetPos()

render.DrawBeam(LocalPlayer():GetPos(), pos2 , 5, 0, 0, Color(255,255,255, 255 ))
cam.End3D()
end
end
end
end
end
hook.Add("HUDPaint","Tracer",DrawTracer)

function BarrelHack()
if Barrelhack:GetBool() then
for k,v in pairs(player.GetAll()) do
if v != LocalPlayer() and v:Alive() and v:IsPlayer() then

cam.Start3D(EyePos(),EyeAngles())
render.SetMaterial(Material("cable/physbeam"))
render.DrawBeam(v:GetBonePosition(v:LookupBone("ValveBiped.Bip01_Head1")),v:GetEyeTrace().HitPos , 5, 0, 0, Color(255,255,255,255))
cam.End3D()

end
end
end
end
hook.Add("HUDPaint","Barrelz",BarrelHack)

function BHOP()
if Bhop:GetBool() then
if input.IsKeyDown(KEY_SPACE) then
if LocalPlayer():IsOnGround() then
RunConsoleCommand("+Jump")
timer.Create("Bhopie",0.01,0,function() RunConsoleCommand("-Jump") end)
end
end
end
end
hook.Add("Think","bhops",BHOP)

function AutoReload()
if autoreloadcmd:GetBool() then
if ply:Alive() and ply:GetActiveWeapon() != NULL then
if ply:GetActiveWeapon():Clip1() == 0 then

RunConsoleCommand("+reload")
timer.Simple(1,function()
RunConsoleCommand("-reload")
end) 

end
end
end
end
hook.Add("Think","Reload",AutoReload)

function wallhakes()
if Wallhack:GetBool() then
for k,v in pairs(ents.GetAll()) do
if v != ply then
if ValidEntity(v) and v:Health() > 0 then
if(v:GetPos() - ply:GetPos()):Length() <= GetConVarNumber("Bot_WallhackDist") then
if v:IsPlayer() or v:IsNPC() then
v:SetMaterial("")
cam.Start3D(EyePos(),EyeAngles())
v:DrawModel()
cam.End3D()
end
end
end
end
end
end
end
hook.Add("HUDPaint","allah",wallhakes)
 

function TriggerBot()

local aimbotignoreteam = ignoreteamcmd:GetBool()
local aimbotignoresteam = ignoresteamcmd:GetBool()
local aimbotignoreadmins = ignoreadminscmd:GetBool()



local Target = LocalPlayer():GetEyeTrace().Entity

if triggerbotcmd:GetBool() then

if Target and Target:IsValid() and Target:IsPlayer() then

if Target:IsAdmin() and aimbotignoreadmins then 

elseif Target:Team() == ply:Team() and aimbotignoreteam then

elseif Target:GetFriendStatus() == "friend" and aimbotignoresteam then

else

if(ply:GetActiveWeapon() == NULL or ply:GetActiveWeapon() == "Camera") then return end
local weaponname = ply:GetActiveWeapon():GetClass()

if weaponname == "weapon_crossbow" then
else
RunConsoleCommand("+attack")

timer.Simple(0.15,function()
RunConsoleCommand("-attack")

end)
end
end
end
end
end
hook.Add("Think","OllieIsl33tAtLau",TriggerBot)

function FovCheck(entity,fov)

if entity == nil then return end
if fov == nil then return end

local toscreenpos = entity:GetPos():ToScreen()

local scalar = ScrW()/360
local fovvalue = GetConVarNumber("Bot_FOVValue")

if fovvalue == 180 then

return false

else

x = ScrW()/2 - fovvalue*scalar
x2 = ScrW()/2 + fovvalue*scalar

if toscreenpos.x > x and toscreenpos.x <  x2 and toscreenpos.y > 1 and toscreenpos.y < ScrH()-1 then return false end

return true

end

end


function DrawFOV()
if DrawFovcmd:GetBool() then

surface.SetDrawColor(Color(255,255,255,255))
surface.DrawCircle(ScrW()/2,ScrH()/2,GetConVarNumber("Bot_FOVValue")*10,Color(255,255,255,155)) 

end
end
hook.Add("HUDPaint","DrawMaFov",DrawFOV)

function SeeTru()
if NoHandsOrWeapons:GetBool() then
LocalPlayer():GetViewModel():SetColor(255,255,255,100)
else
LocalPlayer():GetViewModel():SetColor(255,255,255,255)

end
end
hook.Add("HUDPaint","NoHandsNoWeapon",SeeTru)

function dynamicpaint()

	if DynamicLightEnable:GetBool() == true then

	local dlight = DynamicLight( ply:EntIndex() )
	if ( dlight ) then
		local r = GetConVarNumber("Bot_DR")
		local g = GetConVarNumber("Bot_DG")
		local b = GetConVarNumber("Bot_DB")
		dlight.Pos = ply:GetPos()
		dlight.r = r
		dlight.g = g
		dlight.b = b
		dlight.Brightness = GetConVarNumber("Bot_DBrightness")
		dlight.Size = GetConVarNumber("Bot_DSize")
		dlight.Decay = GetConVarNumber("Bot_DSize") * 5
		dlight.DieTime = CurTime() + 1
                dlight.Style = 0
	end

	end
	
end

hook.Add("Think","dynamiclight",dynamicpaint)


function LightOnPlayers()
if LightOnPly:GetBool() then

for k,v in pairs(player.GetAll()) do

if v:IsPlayer and v:Alive() then

local Light = DynamicLight(v:EntIndex())
local r = GetConVarNumber("Bot_DR")
local g = GetConVarNumber("Bot_DG")
local b = GetConVarNumber("Bot_DB")
Light.pos = v:GetPos()
Light.r = r
Light.g = g
Light.b = b
Light.Brightness = GetConVarNumber("Bot_DBrightness")
Light.Size = GetConVarNumber("Bot_DSize")
Light.Decay = GetConVarNumber("Bot_DSize")*5
Light.DieTime = CurTime() + 1
Light.Style = 0


end
end
end
end
hook.Add("Think","Lights",LightOnPlayers)




function AimBot()

    ----------------------------------

    Distances = BN
    Distances = {}
    Players = BN
    Players = {}
    
    local aimbotenabled = aimbotcmd:GetBool()
    local aimbotignoreteam = ignoreteamcmd:GetBool()
    local aimbotignoresteam = ignoresteamcmd:GetBool()
    local aimbotignoreadmins = ignoreadminscmd:GetBool()  
    local aimbotfovvalue = GetConVarNumber("Bot_FOVVal")   	
    -------------------------------------
    
    if aimbotenabled then

        for k,v in pairs( player.GetAll() ) do
    
    
            if(v!=ply) then
            
                local BoneIndx = v:LookupBone("ValveBiped.Bip01_Head1")
                local BonePos , BoneAng = v:GetBonePosition( BoneIndx )
            
                local pos = ply:GetPos()
                local tracedata = {}
                tracedata.start = pos
                tracedata.endpos = BonePos
                tracedata.filter = ply
                local trace = util.TraceLine(tracedata)
                
                local name = v:GetName()
                
                if trace.Entity==v then
					if !table.HasValue(Friends,name) then

                    if v:IsAdmin() and aimbotignoreadmins then 
                    
                    elseif v:Team() == ply:Team() and aimbotignoreteam then
                    
                    elseif v:GetFriendStatus() == "friend" and aimbotignoresteam then
                    
					elseif FovCheck(v,aimbotfovvalue) then
                    
					
                    else
                                                            
                    table.insert(Distances,ply:GetPos():Distance(v:GetPos()))
                    table.insert(Players,v)
                    end
					
					end
                
				end
            
            end
        
        end
        
        
        Closestnum = findclosest(Distances)
        plyfound = Players[Closestnum]
        
        if plyfound != nil then
        
        local BoneIndx = plyfound:LookupBone("ValveBiped.Bip01_Head1")    
        local BonePos , BoneAng = plyfound:GetBonePosition( BoneIndx )
        local pos = ply:GetShootPos()
        
        if(ply:GetActiveWeapon() == NULL or ply:GetActiveWeapon() == "Camera") then return end
        local weaponname = ply:GetActiveWeapon():GetClass()
        
            if weaponname == "weapon_crossbow" and weaponname != nil then
            
            local Vel = plyfound:GetVelocity()*-1
            local dis = ply:GetPos():Distance(plyfound:GetPos())
            
            local mul = dis/3110
            
            prepos = (pos - Vector(0,0,dis/150)) + Vel*mul
            
            ply:SetEyeAngles((BonePos-prepos):Angle())
            
            else
			
			BonePos2 = BonePos-- +  plyfound:GetAimVector()*5

            ply:SetEyeAngles((BonePos2-pos):Angle())
            
            end
        
        end
    
    end

end
hook.Add("Think", "AimBot", AimBot)






function ESPCORRS()
for k,v in pairs(ents.GetAll()) do
local dist = v:GetPos():Distance(ply:GetPos())  


if ESP:GetBool() and dist < GetConVarNumber("Bot_ESPDist") then   //Note To tek hmm
if Boxie:GetBool() then
if v!=LocalPlayer() then
if v:IsPlayer() and v:Alive() then

local center = v:LocalToWorld( v:OBBCenter() )
local min,max = v:WorldSpaceAABB()
local dim = max - min

local front = v:GetForward()*(dim.y/2)
local right = v:GetRight()*(dim.x/2)
local top = v:GetUp()*(dim.z/2)
local back = (v:GetForward()*-1)*(dim.y/2)
local left = (v:GetRight()*-1)*(dim.x/2)
local bottom = (v:GetUp()*-1)*(dim.z/2)

local FRT = center+front+right+top
local BLB = center+back+left+bottom
local FLT = center+front+left+top
local BRT = center+back+right+top
local BLT = center+back+left+top
local FRB = center+front+right+bottom
local FLB = center+front+left+bottom
local BRB = center+back+right+bottom


FRT = FRT:ToScreen()
BLB = BLB:ToScreen()
FLT = FLT:ToScreen()
BRT = BRT:ToScreen()
BLT = BLT:ToScreen()
FRB = FRB:ToScreen()
FLB = FLB:ToScreen()
BRB = BRB:ToScreen()

local xmax = math.max(FRT.x,BLB.x,FLT.x,BRT.x,BLT.x,FRB.x,FLB.x,BRB.x)
local xmin = math.min(FRT.x,BLB.x,FLT.x,BRT.x,BLT.x,FRB.x,FLB.x,BRB.x)
local ymax = math.max(FRT.y,BLB.y,FLT.y,BRT.y,BLT.y,FRB.y,FLB.y,BRB.y)
local ymin = math.min(FRT.y,BLB.y,FLT.y,BRT.y,BLT.y,FRB.y,FLB.y,BRB.y)

surface.SetDrawColor(team.GetColor(v:Team()))

surface.DrawLine( xmax, ymax, xmax, ymin )
surface.DrawLine( xmax, ymin, xmin, ymin )
surface.DrawLine( xmin, ymin, xmin, ymax )
surface.DrawLine( xmin, ymax, xmax, ymax )

end
end
end

if NPCESP:GetBool() then
if v!=LocalPlayer() then
if v:IsNPC() then

local center = v:LocalToWorld( v:OBBCenter() )
local min,max = v:WorldSpaceAABB()
local dim = max - min

local front = v:GetForward()*(dim.y/2)
local right = v:GetRight()*(dim.x/2)
local top = v:GetUp()*(dim.z/2)
local back = (v:GetForward()*-1)*(dim.y/2)
local left = (v:GetRight()*-1)*(dim.x/2)
local bottom = (v:GetUp()*-1)*(dim.z/2)

local FRT = center+front+right+top
local BLB = center+back+left+bottom
local FLT = center+front+left+top
local BRT = center+back+right+top
local BLT = center+back+left+top
local FRB = center+front+right+bottom
local FLB = center+front+left+bottom
local BRB = center+back+right+bottom


FRT = FRT:ToScreen()
BLB = BLB:ToScreen()
FLT = FLT:ToScreen()
BRT = BRT:ToScreen()
BLT = BLT:ToScreen()
FRB = FRB:ToScreen()
FLB = FLB:ToScreen()
BRB = BRB:ToScreen()

local xmax = math.max(FRT.x,BLB.x,FLT.x,BRT.x,BLT.x,FRB.x,FLB.x,BRB.x)
local xmin = math.min(FRT.x,BLB.x,FLT.x,BRT.x,BLT.x,FRB.x,FLB.x,BRB.x)
local ymax = math.max(FRT.y,BLB.y,FLT.y,BRT.y,BLT.y,FRB.y,FLB.y,BRB.y)
local ymin = math.min(FRT.y,BLB.y,FLT.y,BRT.y,BLT.y,FRB.y,FLB.y,BRB.y)

surface.SetDrawColor(Color(255,255,255,255))

surface.DrawLine( xmax, ymax, xmax, ymin )
surface.DrawLine( xmax, ymin, xmin, ymin )
surface.DrawLine( xmin, ymin, xmin, ymax )
surface.DrawLine( xmin, ymax, xmax, ymax )

end
end
end

if v!=LocalPlayer() then

if v:IsPlayer() and v:Alive() and !v:IsNPC() then

local Pos = v:EyePos():ToScreen()
local Col = team.GetColor(v:Team())
local Dist = v:GetPos():Distance(LocalPlayer():GetPos())
local Rank = ""
local Wep = ""
if v:IsAdmin() then 
Rank = " (A)" 
end
if v:IsSuperAdmin() then 
Rank = " (SA)" 
end

if ValidEntity(v:GetActiveWeapon()) then
Wep = v:GetActiveWeapon():GetPrintName()
Wep = string.gsub(Wep,"#HL2_","")
Wep = string.gsub(Wep,"#GMOD_","")
end

if ESPInfo:GetBool() then
draw.SimpleTextOutlined(v:Nick() .." - "..v:Health().."H"..Rank,"DefaultSmall",Pos.x - 30,Pos.y - 20,Col,TEXT_ALIGN_LEFT,TEXT_ALIGN_LEFT,.6,Color(30,30,30,165))
end

if ESPExtra:GetBool() then
draw.SimpleTextOutlined(Wep.." - "..math.Round(Dist).."D","DefaultSmall",Pos.x - 30, Pos.y - 8, Col, TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT, .6, Color( 30, 30, 30, 165 ) )
end

elseif v:IsNPC() then
if NPCESP:GetBool() then
local NPC = v:GetClass()
NPC = string.Replace(NPC,"npc_","")
NPC = string.Replace(NPC,"_","")
NPC = string.upper(NPC)
local Pos = v:EyePos():ToScreen()
draw.SimpleTextOutlined(NPC,"DefaultSmall",Pos.x ,Pos.y - 20,Col,TEXT_ALIGN_CENTER,TEXT_ALIGN_CENTER,.6,Color(30,30,30,165))
end

end
end
end
end
end
hook.Add("HUDPaint","ESPCore",ESPCORRS)

//##Menu##\\
local MenuFrame
local function Menu()
gui.EnableScreenClicker(true)

if !MenuFrame then
MenuFrame = vgui.Create("DFrame")
MenuFrame:SetSize(300,400)
MenuFrame:Center()
MenuFrame:ShowCloseButton(false)
MenuFrame:SetDraggable(false)
MenuFrame:SetTitle("")
MenuFrame.Paint = function() end

local Sheet = vgui.Create("DPropertySheet",MenuFrame)
Sheet:SetPos(0,0)
Sheet:SetSize(300,400)

local Tab = vgui.Create("DPanelList")
Tab:SetSpacing(5)
Tab:SetPadding(5)

local Controll = vgui.Create("DCheckBoxLabel")
Controll:SetText("Aimbot Enabled")
Controll:SetConVar("Bot_AimBot")
Tab:AddItem(Controll)

local Controll = vgui.Create("DCheckBoxLabel")
Controll:SetText("Enable TriggerBot")
Controll:SetConVar("Bot_TriggerBot")
Tab:AddItem(Controll)

local Controll = vgui.Create("DCheckBoxLabel")
Controll:SetText("Enable Auto Reload")
Controll:SetConVar("Bot_AutoReload")
Tab:AddItem(Controll)

local Controll = vgui.Create("DCheckBoxLabel")
Controll:SetText("Ignore Steam Friends")
Controll:SetConVar("Bot_IgnoreSteam")
Tab:AddItem(Controll)

local Controll = vgui.Create("DCheckBoxLabel")
Controll:SetText("Ignore Admins")
Controll:SetConVar("Bot_IgnoreAdmins")
Tab:AddItem(Controll)

local Controll = vgui.Create("DCheckBoxLabel")
Controll:SetText("Ignore Team")
Controll:SetConVar("Bot_IgnoreTeam")
Tab:AddItem(Controll)

local FovSlider = vgui.Create("DNumSlider",Tab)
FovSlider:SetPos(165,5)
FovSlider:SetWide(120)
FovSlider:SetText("Aimbot FOV")
FovSlider:SetMin(1)
FovSlider:SetMax(180)
FovSlider:SetDecimals(0)
FovSlider:SetValue(90)
FovSlider:SetConVar("Bot_FOVValue")

Sheet:AddSheet("Aimbot",Tab,"gui/silkicons/shield",false,false,"Aimbot Config")

local Tab = vgui.Create("DPanelList")
Tab:SetSpacing(5)
Tab:SetPadding(5)

local Controll = vgui.Create("DCheckBoxLabel")
Controll:SetText("Enable Bhop") 
Controll:SetConVar("Bot_Bhop")
Tab:AddItem(Controll)

local Controll = vgui.Create("DCheckBoxLabel")
Controll:SetText("Enable Traces")
Controll:SetConVar("Bot_Tracer")
Tab:AddItem(Controll)

local Controll = vgui.Create("DCheckBoxLabel")
Controll:SetText("Enable Barrel")
Controll:SetConVar("Bot_Barrel")
Tab:AddItem(Controll)


local Controll = vgui.Create("DCheckBoxLabel")
Controll:SetText("Enable Wallhack")
Controll:SetConVar("Bot_Wallhack")
Tab:AddItem(Controll)

local Controll = vgui.Create("DCheckBoxLabel")
Controll:SetText("Draw FOV")
Controll:SetConVar("Bot_DrawFOV")
Tab:AddItem(Controll) 

Controll = vgui.Create("DCheckBoxLabel")
Controll:SetText("See Through Hands&Weapons")
Controll:SetConVar("Bot_NoWeapons")
Tab:AddItem(Controll)

local WallDistSlider = vgui.Create("DNumSlider",Tab)
WallDistSlider:SetPos(165,5)
WallDistSlider:SetWide(120)
WallDistSlider:SetText("Wallhack Dist")
WallDistSlider:SetMin(1000)
WallDistSlider:SetMax(25000)
WallDistSlider:SetDecimals(0)
WallDistSlider:SetValue(3000)
WallDistSlider:SetConVar("Bot_WallhackDist")

local TraceDistSlider = vgui.Create("DNumSlider",Tab)
TraceDistSlider:SetPos(165,50)
TraceDistSlider:SetWide(120)
TraceDistSlider:SetText("Trace Dist")
TraceDistSlider:SetMin(1000)
TraceDistSlider:SetMax(25000)
TraceDistSlider:SetDecimals(0)
TraceDistSlider:SetValue(3000)
TraceDistSlider:SetConVar("Bot_TraceDist") 

Controll = vgui.Create("DCheckBoxLabel")
Controll:SetText("Enable Chams")
Controll:SetConVar("Bot_Chams")
Tab:AddItem(Controll)

Controll = vgui.Create("DCheckBoxLabel")
Controll:SetText("Enable Wireframe")
Controll:SetConVar("Bot_Wire")
Tab:AddItem(Controll)

Controll = vgui.Create("DCheckBoxLabel")
Controll:SetText("Enable OutGlow")
Controll:SetConVar("Bot_OutGlow")
Tab:AddItem(Controll)

Sheet:AddSheet("Misc",Tab,"gui/silkicons/star",false,false,"Misc settings")

local Tab = vgui.Create("DPanelList")
Tab:SetSpacing(5)
Tab:SetPadding(5)

Controll = vgui.Create("DCheckBoxLabel")
Controll:SetText("Enable Dynamic Light")
Controll:SetPos(150,50)
Controll:SetConVar("Bot_DE")
Tab:AddItem(Controll)

local TraceDistSlider = vgui.Create("DNumSlider",Tab)
TraceDistSlider:SetPos(5,30)
TraceDistSlider:SetWide(120)
TraceDistSlider:SetText("Brightness")
TraceDistSlider:SetMin(1)
TraceDistSlider:SetMax(10)
TraceDistSlider:SetDecimals(1)
TraceDistSlider:SetValue(1)
TraceDistSlider:SetConVar("Bot_DBrightness") 

local TraceDistSlider = vgui.Create("DNumSlider",Tab)
TraceDistSlider:SetPos(5,70)
TraceDistSlider:SetWide(120)
TraceDistSlider:SetText("Size")
TraceDistSlider:SetMin(1)
TraceDistSlider:SetMax(2000)
TraceDistSlider:SetDecimals(0)
TraceDistSlider:SetValue(250)
TraceDistSlider:SetConVar("Bot_DSize") 

local colorCircle = vgui.Create( "DColorCircle", Tab )
colorCircle:SetPos( 5,120 )
colorCircle:SetSize( 100, 100 )
colorCircle.PaintOver = function() 

if colorCircle:GetRGB() == nil then else
local RGB = colorCircle:GetRGB()
RunConsoleCommand("Bot_DR",RGB.r)
RunConsoleCommand("Bot_DG",RGB.g)
RunConsoleCommand("Bot_DB",RGB.b)
end

end

Sheet:AddSheet("Dynamic Light",Tab,"gui/silkicons/palette",false,false,"Dynamic Light Settings")

local Tab = vgui.Create("DPanelList")
Tab:SetSpacing(5)
Tab:SetPadding(5)

local Controll = vgui.Create("DCheckBoxLabel")
Controll:SetText("Enable ESP")
Controll:SetConVar("Bot_ESP")
Tab:AddItem(Controll)

local Controll = vgui.Create("DCheckBoxLabel")
Controll:SetText("Enable ESP Info")
Controll:SetConVar("Bot_ESPInfo")
Tab:AddItem(Controll)

local Controll = vgui.Create("DCheckBoxLabel")
Controll:SetText("Enable ESP Boxes")
Controll:SetConVar("Bot_Box")
Tab:AddItem(Controll)

local Controll = vgui.Create("DCheckBoxLabel")
Controll:SetText("Enable ESP Extras")
Controll:SetConVar("Bot_ESPExtra")
Tab:AddItem(Controll)

local Controll = vgui.Create("DCheckBoxLabel")
Controll:SetText("Enable NPC ESP")
Controll:SetConVar("Bot_ESPNPC")
Tab:AddItem(Controll)

local Controll = vgui.Create("DCheckBoxLabel")
Controll:SetText("Enable Skeleton")
Controll:SetConVar("Bot_Skeleton")
Tab:AddItem(Controll)

local ESPDistSlider = vgui.Create("DNumSlider",Tab)
ESPDistSlider:SetPos(185,5)
ESPDistSlider:SetWide(100)
ESPDistSlider:SetText("ESP Dist")
ESPDistSlider:SetMin(1000)
ESPDistSlider:SetMax(25000)
ESPDistSlider:SetDecimals(0)
ESPDistSlider:SetValue(3000)
ESPDistSlider:SetConVar("Bot_ESPDist")


Sheet:AddSheet("ESP",Tab,"gui/silkicons/palette",false,false,"Config The ESP")

local Tab = vgui.Create("DPanelList")
Tab:SetSpacing(5)
Tab:SetPadding(5)

local Combobox
function AllPlayers()
Combobox = vgui.Create("DComboBox")
Combobox:SetParent(Tab)
Combobox:SetPos(10,10)
Combobox:SetSize(120,180)
Combobox:SetMultiple(false)

for k,v in pairs(player.GetAll()) do
if (v != LocalPlayer() && !table.HasValue(Friends,v:Nick())) then
Combobox:AddItem(v:Nick())
end
end
end
AllPlayers()


local Combobox2
function OnlyFriends()
Combobox2 = vgui.Create("DComboBox")
Combobox2:SetParent(Tab)
Combobox2:SetPos(160,10)
Combobox2:SetSize(120,180)
Combobox2:SetMultiple(false)

for k,v in pairs(player.GetAll()) do
if (table.HasValue(Friends,v:Nick())) then
Combobox2:AddItem(v:Nick())
end
end
end
OnlyFriends()

local ButtonAdd = vgui.Create("DButton")
ButtonAdd:SetParent(Tab)
ButtonAdd:SetSize(20,20)
ButtonAdd:SetPos(135,50)
ButtonAdd:SetText(">")
ButtonAdd.DoClick = function()

if #Combobox:GetSelectedItems()==0 then ply:ChatPrint("You Need To Select A Player") return end
if(Combobox:GetSelectedItems() && Combobox:GetSelectedItems()[1]) then
for k,v in pairs(player.GetAll()) do
if (v:Nick() == Combobox:GetSelectedItems()[1]:GetValue()) then
table.insert(Friends,v:Nick())
--ply:ChatPrint("Added "..v:GetName().." To Aimbot Friends")
end
end
end 
AllPlayers()
OnlyFriends()
end

local ButtonUpdate = vgui.Create("DButton") 
ButtonUpdate:SetParent(Tab)
ButtonUpdate:SetSize(60,30)
ButtonUpdate:SetPos(210,210)
ButtonUpdate:SetText("Update")
ButtonUpdate.DoClick = function()
AllPlayers()
end

local ButtonRemove = vgui.Create("DButton") 
ButtonRemove:SetParent(Tab)
ButtonRemove:SetSize(20,20)
ButtonRemove:SetPos(135,100)
ButtonRemove:SetText("<")
ButtonRemove.DoClick = function()

if #Combobox2:GetSelectedItems()==0 then ply:ChatPrint("You Need To Select A Player") return end
if (Combobox2:GetSelectedItems() && Combobox2:GetSelectedItems()[1] ) then
for k,v in pairs(Friends) do
if(v == Combobox2:GetSelectedItems()[1]:GetValue() ) then
table.remove(Friends,k)
end
end
end
OnlyFriends()
AllPlayers()
end

Sheet:AddSheet("Friends", Tab, "gui/silkicons/group", false, false, "Aimbot Friendlist" )

else 
MenuFrame:SetVisible(true)
end
end

local function MenuOff()
if MenuFrame then
MenuFrame:SetVisible(false)
gui.EnableScreenClicker(false)
end
end

concommand.Add("+Hack_Menu",Menu)
concommand.Add("-Hack_Menu",MenuOff)


//##For niggas##\\