--[[
	EXECUTABLE_PATH/scripts/AEDev3.lua
	-=TRR- is Up=Dayzlayer | STEAM_0:1:65860748 <86.169.139.24:27005> | [19-10-13 04:18:23PM]
	===BadFile===
]]

surface.PlaySound("ambient/fire/ignite.wav")

   --Fonts--
    surface.CreateFont("Logo",{font = "akbar", size = 21, weight = 400, antialias = 0})
draw.SimpleTextOutlined("AE","Logo",1285,15,Color(255,255,255,255),4,1,1,black)


LocalPlayer():PrintMessage( HUD_PRINTTALK, "[AE]Owner of AE: Cokeman" )
LocalPlayer():PrintMessage( HUD_PRINTTALK, "[AE]Credits:" )
LocalPlayer():PrintMessage( HUD_PRINTTALK, "[AE]BarmyAaron" )
LocalPlayer():PrintMessage( HUD_PRINTTALK, "[AE]Snow Boi" )
LocalPlayer():PrintMessage( HUD_PRINTTALK, "[AE]Commands:" )
LocalPlayer():PrintMessage( HUD_PRINTTALK, "[AE]Tab and Q to open Menu" )
LocalPlayer():PrintMessage( HUD_PRINTTALK, "[AE]Esc to quit Menu" )
LocalPlayer():PrintMessage( HUD_PRINTTALK, "[AE]Hold o to flashlight spam" )
LocalPlayer():PrintMessage( HUD_PRINTTALK, "[AE]Hold B for TriggerBot" )
LocalPlayer():PrintMessage( HUD_PRINTTALK, "[AE]Hold Space for bhop" )
LocalPlayer():PrintMessage( HUD_PRINTTALK, "--------------------------" )
LocalPlayer():PrintMessage( HUD_PRINTTALK, "[AE] Loaded version: Alpha 3" )
LocalPlayer():PrintMessage( HUD_PRINTTALK,  "[AE] stabilizing FPS")
LocalPlayer():PrintMessage( HUD_PRINTTALK, "[AE] stabilized FPS" )
LocalPlayer():PrintMessage( HUD_PRINTTALK, "[AE] dude wtf anticheat cant touch me" )
LocalPlayer():PrintMessage( HUD_PRINTTALK, "[AE] Client UpTo date :D Have fun" )

local Cokehack = {Menu = {tabs = {}, b = {}}}
local menu = Cokehack.Menu
 
Cokehack.Settings = {
        aimbot                  = true;
        aimbot_fov              = 5;
        aimbot_bone             = "ValveBiped.Bip01_Head1";
       
        triggerbot              = true;
       
        esp                             = true;
        esp_ply                 = true;
        esp_ply_name    = true;
        esp_ply_rank    = true;
        esp_ply_health  = true;
        esp_ply_dist    = true;
        esp_player_dist = 2000;
        esp_ent                 = true;
        esp_ent_dist    = 2000;
       
        darkrp_god              = false;
        flashlight_spam = true;
        bunnyhop                = false;
		spam               = false;
		ae               = false;
	    afk              = false;
		propspam         = false;
		animation        = false;
		auto        = false;
	    spamadminchat  = false;
		crash  = false;
		nolag  = false;
		reset  = false;
		WeedGrowTime  = false;
		Weed  = false;
		Fule  = false;
		playerinfo  = false;
	   {['Screenshot/Demo Protection'] = true},
}
 
 
 
Cokehack.Whitelist = {
}
Cokehack.Entities = {
        "money_printer";
        "spawned_money";
        "ent_pot_leaf";
        "ent_coca_leaf";
        "topaz_money_printer";
        "sapphire_money_printer";
        "ruby_money_printer";
        "emerald_money_printer";
        "amethyst_money_printer";
        "drug_pot_seeds";
        "perp_di";
}
Cokehack.Phrases = {
        "Cokeman is a gangsta";
        "Chicken Nuggets";
        "Black Man";
        "dude wtf anticheat cant touch me";
        "AE is the best";
        "So is AX";
}
 
Cokehack.Bones = {
        head = "ValveBiped.Bip01_Head1";
        spine = "ValveBiped.Bip01_Spine";
}
 
surface.CreateFont("Trebuchet19cat", {font="TabLarge", size=13, weight=700})
surface.CreateFont("Trebuchetcat", {font="TabLarge", size=10, weight=700})
 
function Cokehack.CloneTable( src ) --cbot
        local new = {}
        for k, v in pairs( src ) do
                local newf = rawget(src, k);
                if( type( newf ) == "table" and v ~= src ) then
                        new[k] = Cokehack.CloneTable( v );
                else
                        new[k] = newf;
                end
        end
 
        return new;
end
 
Cokehack.table                   = Cokehack.CloneTable( table );
Cokehack.hook                    = Cokehack.CloneTable( hook );
Cokehack.math                    = Cokehack.CloneTable( math );
Cokehack.surface                 = Cokehack.CloneTable( surface );
Cokehack.draw                    = Cokehack.CloneTable( draw );
 
local table                     = Cokehack.table;
local hook                              = Cokehack.hook;
local math                              = Cokehack.math;
local surface                   = Cokehack.surface;
local draw                              = Cokehack.draw;
 
function Cokehack.GetShootPos(ent)
        local eyes = ent:LookupAttachment("eyes");
        if(eyes ~= 0) then
                eyes = ent:GetAttachment(eyes);
                if(eyes and eyes.Pos) then
                        return eyes.Pos, eyes.Ang;
                end
        end
end
 
function Cokehack.GetVisible(ent)
        local pos = LocalPlayer():GetShootPos()
        local ang = LocalPlayer():GetAimVector()
        local trace = {start = LocalPlayer():GetShootPos(), endpos = Cokehack.GetShootPos(ent), filter = {LocalPlayer(), ent}, mask = 1174421507};
        local tr = util.TraceLine(trace);
        return(tr.Fraction == 1);
end
 
function Cokehack.Whitelisted(ent)
        if table.HasValue(Cokehack.Whitelist, ent:SteamID())     then return true
        else return false end
end
 
function Cokehack.Target(v)
        if v:IsPlayer() then
                if (Cokehack.GetVisible(v) and (not Cokehack.Whitelisted(v)) and v:Alive() and (v:Health() > 0) and v:Team() ~= TEAM_SPECTATOR) then
                        if (v ~= LocalPlayer() and LocalPlayer():Alive() and LocalPlayer():Team() ~= TEAM_SPECTATOR) then
                                if string.find(gmod.GetGamemode().Name, "Stronghold") then
                                        if (v:Team() ~= LocalPlayer():Team()) then
                                                return true
                                        end
                                else
                                        return true
                                end
                        end
                end
        end
        return false
end
 
function Cokehack.ESP(typ, v)
        if typ == "player" then
                if v:Alive() && v:Health() >= 1 && v ~= LocalPlayer() && /*LocalPlayer():Alive() &&*/ LocalPlayer():Team() ~= TEAM_SPECTATOR then
                        return true
                else
                        return false
                end
        elseif typ == "entity" then
                if IsValid(v) then
                        return true
                end
        end
end
 
function Cokehack.Rank(v)
        if v:IsAdmin() or v:IsSuperAdmin() then
                return "[A] "
        else return "" end
end
 
function Cokehack.Get(value)
        if not(Cokehack.Settings[value]) then return end
       
        if Cokehack.Settings[value] == true then
                return "enabled"
        elseif Cokehack.Settings[value] == false then
                return "disabled"
        elseif Cokehack.Settings[value] == "ValveBiped.Bip01_Head1" then
                return "head"
        elseif Cokehack.Settings[value] == "ValveBiped.Bip01_Spine4" then
                return "spine"
        else
                return Cokehack.Settings[value]
        end
end
 
function Cokehack.Set(value, value2)
        if value2 == "enabled" then
                Cokehack.Settings[value] = true
        elseif value2 == "disabled" then
                Cokehack.Settings[value] = false
        elseif value2 == "head" then
                Cokehack.Settings[value] = "ValveBiped.Bip01_Head1"
        elseif value2 == "spine" then
                Cokehack.Settings[value] = "ValveBiped.Bip01_Spine4"
        else
                Cokehack.Settings[value] = value2
        end
end
 
function Cokehack.GetBone()
        local b = Cokehack.Settings["aimbot_bone"]
        if b == "head" then
                return Cokehack.Bones["head"]
        elseif b == "spine" then
                return Cokehack.Bones["spine"]
        end
        return nil
end
 
function Cokehack.CreateTab(txt, szw, szh, psw, psh, parent, func)
        if(not parent) then return; end
        local panel = vgui.Create("DPanel", menu.frame);
        panel:SetPos(120,25);
        panel:SetSize(375,405);
        if menu.curwin == txt then panel:SetVisible(true) else panel:SetVisible(false) end
        panel.Paint = function()
                local line = "__________________________________________________________________________"
                surface.SetDrawColor( 00, 00, 00, 255 )
                surface.DrawRect( 0, 0, panel:GetWide(), panel:GetTall() )
                surface.CreateFont("shmenufont", {font="coolvetica", size=64, weight=500});
                surface.CreateFont("shmenufont2", {font="coolvetica", size=24, weight=500});
                draw.SimpleText(txt, "shmenufont", 10, 10, Color(255, 00, 00, 235), TEXT_ALIGN_LEFT);
                --draw.SimpleText(line, "MenuLarge", 50, 60, Color(0,0,0,255), TEXT_ALIGN_CENTER)
                if txt == "ESP" then
                        draw.SimpleText("Player ESP", "shmenufont2", 5, 100, Color(255,00,00,235), TEXT_ALIGN_LEFT);
                        draw.SimpleText("Entity ESP", "shmenufont2", 5, 250, Color(255,00,00,235), TEXT_ALIGN_LEFT);
                end
        end
        local button = vgui.Create("DButton", parent);
        button:SetText(txt);
        button:SetSize(szw, szh);
        button:SetPos(psw, psh);
        button.Paint = function(self) derma.SkinHook("PaintOver", "Button", self) end
        button:SetVisible(true);
        button.DoClick = func or function()
                for k,v in pairs(menu.tabs) do
                        if v ~= panel then
                                v:SetVisible(false)
                        end
                end
                panel:SetVisible(true)
                menu.curwin = txt
                surface.PlaySound("ambient/levels/canals/drip4.wav");
        end
        return panel, button;
end
 
function Cokehack.AddFeature(parent, id, typ, text, val, option1, option2, option3, option4, option5)
        if not(parent) or not(typ) then return; end
        local posy = (55+(id*25))
        if typ == "button" then
                if Cokehack.Settings[val] == nil then return end
                if text ~= nil then
                        local label = vgui.Create("DLabel", parent)
                        label:SetText(text)
                        label:SetPos(5,posy)
                        label:SizeToContents(false)
                end
 
                local button = vgui.Create("DButton", parent)
                if Cokehack.Get(val) == option1 then
                        button:SetText(option1)
                else
                        button:SetText(option2)
                end
                button:SetSize(80,20)
                if id == 0 then
                        button:SetPos(285,45)
                else
                        button:SetPos(285,posy)
                end
                button.DoClick = function()
                        if button:GetText() == option1 then
                                button:SetText(option2); Cokehack.Set(val, option2)
                        else
                                button:SetText(option1); Cokehack.Set(val, option1)
                        end
                end
                return button, label
        elseif typ == "dbutton" then
                local button = vgui.Create("DButton", parent)
                button:SetPos(option1,option2)
                button:SetSize(option3,option4)
                button:SetText(text)
                button.DoClick = option5
                return button
        elseif typ == "slider" then
                local slider = vgui.Create("DNumSlider", parent)
                slider:SetPos(5, posy-10)
                slider:SetText(text)
                slider:SetMinMax(option1, option2)
                slider:SetWide(372.5)
                slider:SetDecimals( 0 )
                slider:SetValue(Cokehack.Get(val))
                slider.OnValueChanged = function(panel, value)
                        local c = tonumber(value)
                        Cokehack.Set(val, math.Round(c))
                end
                return slider;
        elseif typ == "label" then
                local label = vgui.Create("DLabel", parent)
                label:SetText(text)
                label:SetPos(5,posy)
                label:SizeToContents(false)
        end
end
 
function Cokehack.DrMenu()
        if(menu.frame) then menu.frame:Remove(); end
       
        menu.frame = vgui.Create("DFrame");
        menu.frame:SetPos(ScrW()/2-184, ScrH()/2-155);
        menu.frame:SetSize(500, 435);
        menu.frame:SetTitle("AE Hack V2"..Cokehack.Phrases[math.random(1, table.Count(Cokehack.Phrases))]);
        menu.frame:SetVisible(true);
        menu.frame:SetDraggable(true);
        menu.frame:SetSizable(false);
        menu.frame:ShowCloseButton(false);
        menu.frame:SetBackgroundBlur(true)
        menu.frame:MakePopup();
 
        menu.buttons = vgui.Create("DPanel", menu.frame)
        menu.buttons:SetPos(5, 25)
        menu.buttons:SetSize(110,405)
        menu.buttons.Paint = function()
                surface.SetDrawColor(50,50,255,255)
                surface.DrawRect(0, 0, menu.buttons:GetWide(), menu.buttons:GetTall())
        end
 
        menu.tabs.aimbot, menu.b.aimbot =       Cokehack.CreateTab("Aimbot", 80, 20, 15, 10, menu.buttons)
        menu.tabs.pesp, menu.b.pesp             =       Cokehack.CreateTab("ESP", 80, 20, 15, 35, menu.buttons)
        menu.tabs.wh, menu.b.wh                 =       Cokehack.CreateTab("Wallhack", 80, 20, 15, 60, menu.buttons)
        menu.tabs.misc, menu.b.misc             =       Cokehack.CreateTab("Misc", 80, 20, 15, 85, menu.buttons)
		menu.tabs.an, menu.b.an                 =       Cokehack.CreateTab("Animation SOON", 80, 20, 22, 100, menu.buttons)
		menu.tabs.perp, menu.b.perp                 =       Cokehack.CreateTab("Animation SOON", 80, 20, 32, 150, menu.buttons)
       
        local mta = menu.tabs.aimbot
        local mtp = menu.tabs.pesp
        local mtw = menu.tabs.wh
        local mtm = menu.tabs.misc
		local an = menu.tabs.an
		local perp = menu.tabs.perp
		
        -- aimbot tab
        Cokehack.AddFeature(mta, 1, "button", "Aimbot", "aimbot", "enabled", "disabled")
        Cokehack.AddFeature(mta, 2, "button", "Aim-bone", "aimbot_bone", "head", "spine")
        Cokehack.AddFeature(mta, 3, "slider", "Aim FOV", "aimbot_fov", 1, 180)
        Cokehack.AddFeature(mta, 4, "button", "Triggerbot", "triggerbot", "enabled", "disabled")
       
        -- esp tab
        Cokehack.AddFeature(mtp, 0, "button", nil, "esp", "enabled", "disabled")
       
        Cokehack.AddFeature(mtp, 2, "button", "Enabled", "esp_player", "enabled", "disabled")
        Cokehack.AddFeature(mtp, 3, "button", "Show Name", "esp_ply_name", "enabled", "disabled")
        Cokehack.AddFeature(mtp, 4, "button", "Show Rank", "esp_ply_rank", "enabled", "disabled")
        Cokehack.AddFeature(mtp, 5, "button", "Show Health", "esp_ply_health", "enabled", "disabled")
        Cokehack.AddFeature(mtp, 6, "button", "Show Distance", "esp_ply_dist", "enabled", "disabled")
        Cokehack.AddFeature(mtp, 7, "slider", "Distance", "esp_player_dist", 0, 16000)
        Cokehack.AddFeature(mtp, 9, "button", "Enabled", "esp_ent", "enabled", "disabled")
        Cokehack.AddFeature(mtp, 10, "slider", "Distance", "esp_ent_dist", 0, 16000)
      
        -- misc tab
        Cokehack.AddFeature(mtm, 1, "button", "Flashlight Spam", "flashlight_spam", "enabled", "disabled")
        Cokehack.AddFeature(mtm, 2, "button", "DarkRP God Exploit", "darkrp_god", "enabled", "disabled")
        Cokehack.AddFeature(mtm, 3, "button", "Bunnyhop", "bunnyhop", "enabled", "disabled")
		Cokehack.AddFeature(mtm, 4, "button", "Spam", "spam", "enabled", "disabled")
		Cokehack.AddFeature(mtm, 5, "button", "AE was here", "ae", "enabled", "disabled")
		Cokehack.AddFeature(mtm, 6, "button", "AFK Fxing", "afk", "enabled", "disabled")
		Cokehack.AddFeature(mtm, 7, "button", "Propspam", "propspam", "enabled", "disabled")
		Cokehack.AddFeature(mtm, 8, "button", "Auto pistol", "auto", "enabled", "disabled")
		Cokehack.AddFeature(mtm, 9, "button", "Spam AdminChat", "spamadminchat", "enabled", "disabled")
		Cokehack.AddFeature(mtm, 10, "button", "Crash", "crash", "enabled", "disabled")
		Cokehack.AddFeature(mtm, 11, "button", "Nolag", "nolag", "enabled", "disabled")
		Cokehack.AddFeature(mtm, 12, "button", "Resetlag", "reset", "enabled", "disabled")
		
		
		--Perp Hacks tab
		Cokehack.AddFeature(perp, 1, "button", "WeedGrowTime", "WeedGrowTime", "enabled", "disabled")
		Cokehack.AddFeature(perp, 2, "button", "Weed", "Weed", "enabled", "disabled")
		Cokehack.AddFeature(perp, 3, "button", "Fule", "Fuel", "enabled", "disabled")
		Cokehack.AddFeature(perp, 4, "button", "playerinfo", "playerinfo", "enabled", "disabled")
		--An
		 Cokehack.AddFeature(an, 1, "button", "Animation", "animation", "enabled", "disabled")
end
 
hook.Add("Think", "CokeMENU", function()
        if(input.IsKeyDown(KEY_TAB) && input.IsKeyDown(KEY_Q) && !menu.frame)then
                Cokehack.DrMenu()
        elseif(menu.frame && input.IsKeyDown(KEY_ESCAPE))then
                menu.frame:Remove(); menu.frame = nil
                Cokehack.Menu = {}
        end
end)
 
hook.Add("Think", "CokeBOT", function()
        -- triggerbot
        if(Cokehack.Settings["triggerbot"] && input.IsKeyDown(KEY_B)) then
                local pos = LocalPlayer():GetShootPos()
                local ang = LocalPlayer():GetAimVector()
                local tracedata = {}
                tracedata.start = pos
                tracedata.endpos = pos+(ang*9999999999999)
                local trace = util.TraceLine(tracedata)
                if(trace.HitNonWorld) then
                        target = trace.Entity
                        if(target:IsPlayer() and (not Cokehack.Whitelisted(target))) then
                                RunConsoleCommand("+attack")
                                timer.Simple(0.000000000000000000001, function() RunConsoleCommand("-attack") end)
                        end
                end
        end
        -- aimbot [ need bone changing support ]
        if(Cokehack.Settings["aimbot"] && input.IsKeyDown(KEY_B)) /*or Cokehack.Settings["alert"]*/ then
                for k,v in pairs(player.GetAll()) do
                        /*if Cokehack.Settings["aimbot"] && input.IsKeyDown(KEY_B) then*/
                        local bone = Cokehack.Settings["aimbot_bone"];
                                if Cokehack.Target(v) then
                                        local head = v:LookupBone(bone)
                                        local fov = Cokehack.Settings["aimbot_fov"]
                                        if fov == 0 then
                                                local headpos,targetheadang = v:GetBonePosition(head)
                                                LocalPlayer():SetEyeAngles((headpos - LocalPlayer():GetShootPos()):Angle())
                                        else
                                                local lpang = LocalPlayer():GetAngles();
                                                local ang = (v:GetPos() - LocalPlayer():GetPos()):Angle();
                                                local ady = math.abs(math.NormalizeAngle(lpang.y - ang.y))
                                                local adp = math.abs(math.NormalizeAngle(lpang.p - ang.p ))
                                                if not(ady > fov or adp > fov) then
                                                        local headpos,targetheadang = v:GetBonePosition(head)
                                                        if headpos != nil and targetheadang != nil then
                                                        LocalPlayer():SetEyeAngles((headpos - LocalPlayer():GetShootPos()):Angle())
                                                        end
                                                end
                                        end
                                end
                               
                        --end
                        /*if Cokehack.Settings["alert"] then
                                local d = Cokehack.Settings["alert_dist"]
                                if v ~= LocalPlayer() and (v:GetPos():Distance(LocalPlayer():GetPos()) < d) then
                                       
                                end
                        end*/
                end
        end
        if Cokehack.Settings["flashlight_spam"] and input.IsKeyDown(KEY_O) then
                RunConsoleCommand("impulse", "100")
        end
       
        if Cokehack.Settings["darkrp_god"] and LocalPlayer():Health() < 100 and LocalPlayer():Alive() then
                RunConsoleCommand("say", "/buyhealth")
        end
		
		if Cokehack.Settings["ae"] then
                RunConsoleCommand("say", "/ooc AE was  HERE")
				end
	   if Cokehack.Settings["crash"] then
       local CRASHALL = CreateClientConVar("CrashAllClients", "0", true, false)
	   local function doCRSHALL()
        if CRASHALL:GetBool() then
 
                RunConsoleCommand("_DarkRP_DoAnimation", "-1921")
        end
end
timer.Create("allgo", 0, 0, doCRSHALL)
				end
	  
	   if Cokehack.Settings["Weed"]  then
        function PERP_Weed()
        if GetConVarNumber("ae_PERP_Weed") == 1 then
                local plants = {}
                for k, ent in pairs( ents.FindByClass("ent_pot") ) do
                        table.insert( plants, ent )
                end
                for k, ent in pairs( ents.FindByClass("ent_coca") ) do
                        table.insert( plants, ent )
                end
                local col = nil
                for k, ent in pairs( plants ) do
                        local pos = ent:GetPos() + Vector(0, 0, 10)
                        local ang = ent:GetAngles()
                        local drawpos = pos:ToScreen()
                        local timeleft = 85564
                        if( ent:GetClass() == "ent_coca" ) then col = Color( 0, 0, 255 ) else col = Color( 255, 0, 0 ) end
                        if( ent.dt != nil ) then
                                timeleft = ent:GetTable().GrowthTime - ( CurTime() - ent.dt.SpawnTime )
                        elseif( ent:GetTable().SpawnTime != nil ) then
                                timeleft = ent:GetTable().GrowthTime - (CurTime() - ent:GetTable().SpawnTime)
                        end
                        if( LocalPlayer():GetShootPos():Distance( pos ) <= 4000 ) then
                                if( timeleft > 1 and timeleft != 85564 ) then
                                        draw.SimpleText( ConvertTime( timeleft ) , "ESPFont_Small", drawpos.x, drawpos.y, col, 1, 1 )
                                elseif( timeleft != 85564 ) then
                                        draw.SimpleText( "DONE!", "ESPFont", drawpos.x, drawpos.y, green, 1, 1 )
                                end
                        end
                end
        end
end	 
end  
	  
	  
		if Cokehack.Settings["auto"]  then
	    
		end
					
						


         if Cokehack.Settings["propspam"] then
				RunConsoleCommand("gm_spawn", "models/hunter/misc/shell2x2.mdl")
				
				
			
			
        end
		

		 if Cokehack.Settings["reset"] then
				local function Reset()
	nolag = false
	RunConsoleCommand("r_3dsky", 1)
	RunConsoleCommand("r_WaterDrawReflection", 1)
	RunConsoleCommand("r_waterforcereflectentities", 1)
	RunConsoleCommand("r_teeth", 1)
	RunConsoleCommand("r_shadows", 1)
	RunConsoleCommand("r_ropetranslucent", 1)
	RunConsoleCommand("r_maxmodeldecal", 50) --50
	RunConsoleCommand("r_maxdlights", 32)--32
	RunConsoleCommand("r_decals", 2048)--2048
	RunConsoleCommand("r_drawmodeldecals", 1)
	RunConsoleCommand("r_drawdetailprops", 1)
	RunConsoleCommand("r_decal_cullsize", 1000)
	RunConsoleCommand("r_worldlights", 1)
	RunConsoleCommand("r_flashlightrender", 1)
	RunConsoleCommand("cl_forcepreload", 0)
	RunConsoleCommand("cl_ejectbrass", 1)
	RunConsoleCommand("cl_show_splashes", 1)
	RunConsoleCommand("cl_detaildist", 1200)
	--RunConsoleCommand("mat_fastnobump", 0)
	RunConsoleCommand("mat_filterlightmaps", 1)
	RunConsoleCommand("r_threaded_renderables", 0)
	RunConsoleCommand("r_threaded_client_shadow_manager", 0)
	--RunConsoleCommand("mat_filtertextures", 1)
	RunConsoleCommand("r_drawflecks", 1)
	RunConsoleCommand("r_WaterDrawRefraction", 0)
	--RunConsoleCommand("mat_showlowresimage", 0)
	RunConsoleCommand("r_dynamic", 1)
	for k,v in pairs(removes) do
		for a,b in pairs(ents.FindByClass(v)) do
			b:SetNoDraw(false)
		end
	end
	concommand.Add("coke_resetlag", Reset)
end

			
			
        end
		
		if Cokehack.Settings["spamadminchat"] then
				RunConsoleCommand("say", "@ Admin Help me Have a Wank")

			
			
        end
		
		if Cokehack.Settings["nolag"] then
	    local nolag = false
        local function StopLag()
	nolag = true
	RunConsoleCommand("r_3dsky", 0)
	RunConsoleCommand("r_WaterDrawReflection", 0)
	RunConsoleCommand("r_waterforcereflectentities", 0)
	RunConsoleCommand("r_teeth", 0)
	RunConsoleCommand("r_shadows", 0)
	RunConsoleCommand("r_ropetranslucent", 0)
	RunConsoleCommand("r_maxmodeldecal", 0) --50
	RunConsoleCommand("r_maxdlights", 0)--32
	RunConsoleCommand("r_decals", 0)--2048
	RunConsoleCommand("r_drawmodeldecals", 0)
	RunConsoleCommand("r_drawdetailprops", 0)
	RunConsoleCommand("r_worldlights", 0)
	RunConsoleCommand("r_flashlightrender", 0)
	RunConsoleCommand("cl_forcepreload", 1)
	RunConsoleCommand("r_threaded_renderables", 1)
	RunConsoleCommand("r_threaded_client_shadow_manager", 1)
	RunConsoleCommand("snd_mix_async", 1)
	RunConsoleCommand("cl_ejectbrass", 0)
	RunConsoleCommand("cl_detaildist", 0)
	RunConsoleCommand("cl_show_splashes", 0)
	--RunConsoleCommand("mat_fastnobump", 1)
	RunConsoleCommand("mat_filterlightmaps", 0)
	--RunConsoleCommand("mat_filtertextures", 0)
	RunConsoleCommand("r_drawflecks", 0)
	RunConsoleCommand("r_dynamic", 0)
	RunConsoleCommand("r_WaterDrawRefraction", 0)
	--RunConsoleCommand("mat_showlowresimage", 1)

	for k,v in pairs(removes) do
		for a,b in pairs(ents.FindByClass(v)) do
			b:SetNoDraw(true)
		end
	end
concommand.Add("ae_stoplag", StopLag)
end


			
			
        end
		
		 if Cokehack.Settings["spam"] then
				RunConsoleCommand("say", "hax")
				RunConsoleCommand("say", "hi")
				RunConsoleCommand("say", "run")
				RunConsoleCommand("say", "help")
			
			
        end
       
        if Cokehack.Settings["bunnyhop"] and input.IsKeyDown(KEY_SPACE) then
                if(LocalPlayer():OnGround())then
                        LocalPlayer():ConCommand("+jump")
                        timer.Simple(0.01, function()
                                LocalPlayer():ConCommand("-jump")
                        end)
                end
        end
end)
 
 
 
 
hook.Add("HUDPaint", "CokeHUD", function()
        if Cokehack.Settings["esp"] then
                for k,v in pairs(ents.GetAll()) do
                        if Cokehack.Settings["esp_ply"] && v:IsPlayer() then
                                if(Cokehack.ESP("player", v) and v:GetPos():Distance(LocalPlayer():GetPos()) < (Cokehack.Settings["esp_player_dist"]))then
                                        local ESP = (v:EyePos()):ToScreen()
                                        local name,health,rank,col,distance = "","","","",""
                                        local outcol = Color(0,0,0,255)
                                        local white = Color(255,255,255,255)
                                        local outcol2 = outcol
                                        if Cokehack.Settings["esp_ply_name"] then
                                                if v.GetRPName then name = v:GetRPName()
                                                else name = v:Nick() end
                                        end
                                        if v:Nick() ~= name then rank = " "..v:Nick() end
                                        if Cokehack.Settings["esp_ply_rank"] then
                                                if v:IsSuperAdmin() then
                                                        rank = "[Super Admin]"..rank
                                                elseif v:IsAdmin() then
                                                        rank = "[Admin]"..rank
                                                elseif v:IsUserGroup("moderator") or v:IsUserGroup("mod") then
                                                        rank = "[Moderator]"..rank
                                                elseif v:IsUserGroup("vip") or v:IsUserGroup("donator") then
                                                        rank = "[Donator]"..rank
                                                end
                                        end
                                        if Cokehack.Settings["esp_ply_health"] then
                                                health = v:Health().."H - "..v:Armor().."A"
                                        end
                                        if Cokehack.Settings["esp_ply_dist"] then
                                                distance = v:GetPos():Distance(LocalPlayer():GetPos())
                                                distance = math.Round(distance).." m"
                                        end
                                        col = team.GetColor(v:Team())
                                        if(col.r <= 50 and col.g <= 50 and col.b <= 50) then
                                                outcol2 = Color(200,200,200,255)
                                        end
                                        if col.a <= 50 then
                                                col = Color(col.r,col.g,col.b, 255)
                                        end
                                        draw.SimpleTextOutlined(rank, "Trebuchetcat", ESP.x, ESP.y -46, col, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, outcol2)
                                        draw.SimpleTextOutlined(name, "Trebuchet19cat", ESP.x, ESP.y - 34, col, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, outcol2)
                                        draw.SimpleTextOutlined(health, "Trebuchetcat", ESP.x, ESP.y -22, white, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, outcol)
                                        draw.SimpleTextOutlined(distance, "Trebuchetcat", ESP.x, ESP.y - 10, white, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, outcol)
                                end
                        end
                        if (Cokehack.Settings["esp_ent"] and Cokehack.ESP("entity", v) and (v:GetPos():Distance(LocalPlayer():GetPos()) < Cokehack.Settings["esp_ent_dist"]))then
                                for k,e in pairs(Cokehack.Entities) do
                                        if e == v:GetClass() then
                                                local ESP = (v:EyePos()):ToScreen()
                                                draw.SimpleTextOutlined(v:GetClass(), "Trebuchet19cat", ESP.x, ESP.y - 46, Color(255,0,0,255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, Color(0,0,0,255))
                                        end
                                end
                        end
                end
        end
end)
 
 
 
concommand.Add("defcon", function()
        local z = {"player"}
        local t = {}
        for k,v in pairs(ents.GetAll()) do
                if not table.HasValue(t, v:GetClass()) then
                        table.insert(t, v:GetClass())
                end
        end
        for e,x in pairs(t) do
                if !table.HasValue(z, x) then
                        print(x)
                end
        end
end)
 
concommand.Add("Cokehack", function()
        local darkrpvar = true
        print("Player Cash Amounts")
        for k,v in pairs(player.GetAll()) do
                if not(v.DarkRPVars and v.DarkRPVars.money)and(darkrpvar == true) then
                        darkrpvar = false
                end
                if v ~= LocalPlayer() then
                        print("    "..v:Nick().." : "..tostring(v.DarkRPVars.money))
                end
        end
        if darkrpvar == false then
                print("    Unable to get player cash amounts.")
        end
end)
 
concommand.Add("Cokeapult", function()
        PrintTable(player.GetAll()[3]:GetTable())
end)
/**************************************
Name: SHIT SNOW HAS ADDED
Purpose: HACKS AND SHIT
**************************************/



/**************************************
Name: Rotater DONT ADD TO MENU
Purpose: Does 180 and shit
**************************************/

local function Rotate180()
	snow_NOAUTOPICKUP = true
	timer.Simple(0.5, function() snow_NOAUTOPICKUP = false end)

	if hook.GetTable().CreateMove and hook.GetTable().CreateMove.PickupEnt then
		hook.Remove("CreateMove", "PickupEnt")
		hook.Remove("CalcView", "Ididntseeit")
		timer.Simple(0.05, function()
			local a = LocalPlayer():EyeAngles() LocalPlayer():SetEyeAngles(Angle(a.p, a.y-180, a.r))
		end)
		return
	end
	local a = LocalPlayer():EyeAngles() LocalPlayer():SetEyeAngles(Angle(a.p, a.y-180, a.r))
end
concommand.Add("ae_180", Rotate180)



/**************************************
Name: De Lagger
Purpose: Removes useless shit that garrys added to raise FPS
**************************************/

local removes = {"env_steam",
"func_illusionary",
"beam",
"class C_BaseEntity",
"env_sprite",
"class C_ShadowControl",
"class C_ClientRagdoll",
"func_illusionary",
"class C_PhysPropClientside",
}

local nolag = false

local function StopLag()
	nolag = true
	RunConsoleCommand("r_3dsky", 0)
	RunConsoleCommand("r_WaterDrawReflection", 0)
	RunConsoleCommand("r_waterforcereflectentities", 0)
	RunConsoleCommand("r_teeth", 0)
	RunConsoleCommand("r_shadows", 0)
	RunConsoleCommand("r_ropetranslucent", 0)
	RunConsoleCommand("r_maxmodeldecal", 0) --50
	RunConsoleCommand("r_maxdlights", 0)--32
	RunConsoleCommand("r_decals", 0)--2048
	RunConsoleCommand("r_drawmodeldecals", 0)
	RunConsoleCommand("r_drawdetailprops", 0)
	RunConsoleCommand("r_worldlights", 0)
	RunConsoleCommand("r_flashlightrender", 0)
	RunConsoleCommand("cl_forcepreload", 1)
	RunConsoleCommand("r_threaded_renderables", 1)
	RunConsoleCommand("r_threaded_client_shadow_manager", 1)
	RunConsoleCommand("snd_mix_async", 1)
	RunConsoleCommand("cl_ejectbrass", 0)
	RunConsoleCommand("cl_detaildist", 0)
	RunConsoleCommand("cl_show_splashes", 0)
	--RunConsoleCommand("mat_fastnobump", 1)
	RunConsoleCommand("mat_filterlightmaps", 0)
	--RunConsoleCommand("mat_filtertextures", 0)
	RunConsoleCommand("r_drawflecks", 0)
	RunConsoleCommand("r_dynamic", 0)
	RunConsoleCommand("r_WaterDrawRefraction", 0)
	--RunConsoleCommand("mat_showlowresimage", 1)

	for k,v in pairs(removes) do
		for a,b in pairs(ents.FindByClass(v)) do
			b:SetNoDraw(true)
		end
	end

end
concommand.Add("ae_stoplag", StopLag)

local function Reset()
	nolag = false
	RunConsoleCommand("r_3dsky", 1)
	RunConsoleCommand("r_WaterDrawReflection", 1)
	RunConsoleCommand("r_waterforcereflectentities", 1)
	RunConsoleCommand("r_teeth", 1)
	RunConsoleCommand("r_shadows", 1)
	RunConsoleCommand("r_ropetranslucent", 1)
	RunConsoleCommand("r_maxmodeldecal", 50) --50
	RunConsoleCommand("r_maxdlights", 32)--32
	RunConsoleCommand("r_decals", 2048)--2048
	RunConsoleCommand("r_drawmodeldecals", 1)
	RunConsoleCommand("r_drawdetailprops", 1)
	RunConsoleCommand("r_decal_cullsize", 1000)
	RunConsoleCommand("r_worldlights", 1)
	RunConsoleCommand("r_flashlightrender", 1)
	RunConsoleCommand("cl_forcepreload", 0)
	RunConsoleCommand("cl_ejectbrass", 1)
	RunConsoleCommand("cl_show_splashes", 1)
	RunConsoleCommand("cl_detaildist", 1200)
	--RunConsoleCommand("mat_fastnobump", 0)
	RunConsoleCommand("mat_filterlightmaps", 1)
	RunConsoleCommand("r_threaded_renderables", 0)
	RunConsoleCommand("r_threaded_client_shadow_manager", 0)
	--RunConsoleCommand("mat_filtertextures", 1)
	RunConsoleCommand("r_drawflecks", 1)
	RunConsoleCommand("r_WaterDrawRefraction", 0)
	--RunConsoleCommand("mat_showlowresimage", 0)
	RunConsoleCommand("r_dynamic", 1)
	for k,v in pairs(removes) do
		for a,b in pairs(ents.FindByClass(v)) do
			b:SetNoDraw(false)
		end
	end
end
concommand.Add("coke_resetlag", Reset)

/**************************************
Name: Hot key script
Purpose: Allows you to make Hotkeys and shit...
**************************************/

sql.Query("CREATE TABLE IF NOT EXISTS MultiKeyBinds('firstkey' INTEGER NOT NULL, 'secondkey' TEXT NOT NULL, 'commandname' TEXT NOT NULL, PRIMARY KEY('firstkey', 'secondkey'));")

local FirstButtons = {ctrl = KEY_LCONTROL, alt = KEY_LALT, shift = KEY_LSHIFT, space = KEY_SPACE}
local Binds = {}

local SQLBinds = sql.Query("SELECT * FROM MultiKeyBinds;")
if SQLBinds then
	for k,v in pairs(SQLBinds) do
		Binds[k] = {}
		Binds[k].firstkey = tonumber(v.firstkey)
		Binds[k].secondkey = string.lower(v.secondkey)
		Binds[k].commandname = v.commandname
	end
end

local AddGUI

local function Add(ply, cmd, args)
	if not args[1] then AddGUI() return end
	if not args[3] then print("Not enough arguments") return "Not enough arguments" end
	if not FirstButtons[string.lower(args[1])] then print("First key has to be shift, ctrl, alt or space") return "First key has to be shift, ctrl, alt or space" end

	local bind = {firstkey = FirstButtons[string.lower(args[1])], secondkey = string.lower(args[2]), commandname = args[3]}
	for k,v in pairs(Binds) do
		if v.firstkey == bind.firstkey and v.secondkey == bind.secondkey then
			Binds[k].commandname = bind.commandname

			sql.Query("UPDATE MultiKeyBinds SET commandname = "..sql.SQLStr(bind.commandname).." WHERE firstkey = "..bind.firstkey .." AND secondkey = "..sql.SQLStr(bind.secondkey)..";")
			print("Keybind updated!")
			return "Keybind updated!"
		end
	end
	table.insert(Binds, bind)

	sql.Query("INSERT INTO MultiKeyBinds VALUES(".. bind.firstkey ..", "..sql.SQLStr(bind.secondkey)..", "..sql.SQLStr(bind.commandname)..");")
	print("Keybind made!")
	return "Keybind made!"
end
concommand.Add("snow_hotkey", Add, function() return "snow_hotkey <Ctrl/alt/shift/space> \"<bind other key>\" \"<command>\"" end)

AddGUI = function()
	local firstkey, secondkey, commandname

	local function _3()
		Derma_StringRequest("Command name",
		[[ What will be the command that will be executed when you press the hotkey?
		NOTE: Some commands are blocked! Examples of blocked commands: quit, ent_*,
		lua_run_cl etc.]], "",
		function(text) commandname = text

			local text = Add(LocalPlayer(), "fuck you", {firstkey, secondkey, commandname})
			chat.AddText(Color(0, 255, 0, 255), text)
		end)
	end

	local function _2()
		hook.Add("HUDPaint", "TEMPHotKey", function()
			draw.DrawText([[Press the second key for the hotkey
			Note: The key must already be bound to something!
			If it's not it won't work!

			Well who would use a hotkey with an unbound key anyway]], "HUDNumber5", ScrW()/2, ScrH()/2, Color(0,0,255,255), TEXT_ALIGN_CENTER)
		end)

		hook.Add("PlayerBindPress", "TEMPHotKey", function(ply, bind, pressed)
			hook.Remove("HUDPaint", "TEMPHotKey")
			hook.Remove("PlayerBindPress", "TEMPHotKey")
			secondkey = string.lower(bind)
			_3()
			return true
		end)
	end

	Derma_Query([[What will be the first key for the hotkey?]], "First key",
		"ctrl", function() firstkey = "ctrl" _2() end,
		"alt", function() firstkey = "alt" _2() end,
		"shift", function() firstkey = "shift" _2() end,
		"space", function() firstkey = "space" _2() end)

end

local RemoveGUI
local function Remove(ply, cmd, args)
	if not args[1] then RemoveGUI() return end
	if not args[2] then print("Not enough arguments") return "Not enough arguments" end
	if not FirstButtons[string.lower(args[1])] then print("First key has to be shift, ctrl, alt or space") return "First key has to be shift, ctrl, alt or space" end

	for k,v in pairs(Binds) do
		if v.firstkey == FirstButtons[string.lower(args[1])] and v.secondkey == string.lower(args[2]) then
			sql.Query("DELETE FROM MultiKeyBinds WHERE firstkey = "..v.firstkey.." AND secondkey = "..sql.SQLStr(v.secondkey)..";")
			table.remove(Binds, k)
			print("Keybind removed!")
			return "Keybind Removed!"
		end
	end
	print("Keybind not found!")
	return "Keybind not found!"
end
concommand.Add("ae_Unhotkey", Remove, function() return "snow_Unhotkey <ctrl/alt/shift/space> \"bind other key\"" end)

RemoveGUI = function()
	local frame = vgui.Create("DFrame")
	frame:SetTitle( "Remove hotkeys" )
	frame:SetSize( 480, 200 )
	frame:Center()
	frame:SetVisible( true )
	frame:MakePopup( )

	local HotKeyList = vgui.Create("DListView", frame)
	HotKeyList:SetSize(470, 170)
	HotKeyList:SetPos(5, 25)
	HotKeyList:AddColumn("First key")
	HotKeyList:AddColumn("Second key")
	HotKeyList:AddColumn("command")
	HotKeyList:SetMultiSelect(false)

	local NumToKey = {[KEY_LCONTROL] = "ctrl", [KEY_LALT] = "alt", [KEY_LSHIFT] = "shift", [KEY_SPACE] = "space"}

	for k,v in pairs(Binds) do
		HotKeyList:AddLine(NumToKey[v.firstkey], v.secondkey, v.commandname)
	end

	function HotKeyList:OnClickLine(line)
		line:SetSelected(true)
		local text = Remove(LocalPlayer(), "get out", {line:GetValue(1), line:GetValue(2)})
		chat.AddText(Color(0, 255, 0, 255), text)

		HotKeyList:RemoveLine(HotKeyList:GetSelectedLine())
	end
end

concommand.Add("ae_hotkeyList", function() PrintTable(Binds) end)

hook.Add("PlayerBindPress", "snow_hotkey", function(ply, bind, pressed)

	for k,v in pairs(Binds) do
		if input.IsKeyDown(v.firstkey) and string.lower(bind) == string.lower(v.secondkey) and pressed then
			RunConsoleCommand(unpack(string.Explode(" ", v.commandname)))-- Using RunConsoleCommand instead of LocalPlayer():ConCommand to prevent unnecessary blocking
			return true
		end
	end
end)


/**************************************
Name: Error Replacer
Purpose: Replaces Errors With stacks of bricks
**************************************/

CreateClientConVar("ae_replaceErrors", 1, true, false)
/*hook.Add("Think", "ReplaceErrors", function()
	if not tobool(GetConVarNumber("ae_replaceErrors")) then return end
	for k,ent in pairs(ents.GetAll()) do -- FindByModel doesn't work
		if IsValid(ent) and string.lower(ent:GetModel() or "") == "models/error.mdl" and ent:GetClass() ~= "trace1" and ent:GetClass() ~= "ent_checkpoint" and ent:GetClass() ~= "ent_start" and ent:GetClass() ~= "ent_finish" and not ent:IsWeapon() then
			if ent.ErrorModel then
				ent:SetNoDraw(true)
			else

				local mins, maxs = ent:OBBMins(), ent:OBBMaxs()
				local difference = maxs - mins
				ent.ErrorModel = ClientsideModel("models/props_debris/concrete_cynderblock001.mdl", RENDER_GROUP_OPAQUE_ENTITY)
				if not ent.ErrorModel then return end
				ent.ErrorModel:SetMaterial("effects/security_noise2")
				ent.ErrorModel:SetPos(ent:GetPos())
				ent.ErrorModel:SetAngles(ent:GetAngles())
				ent.ErrorModel:SetParent(ent)
				ent.ErrorModel:SetColor(ent:GetColor())

				ent.ErrorModel:SetModelScale(Vector(difference.x/16,difference.y/8,difference.z/8))
				ent.ErrorModel:Spawn()
				ent.ErrorModel:Activate()

				ent:CallOnRemove("RemoveErrorModel", function(ent) SafeRemoveEntity(ent.ErrorModel) end)
			end
		end
	end
end)*/


/**************************************
Name: Snow Logger
Purpose: Logs functions and shit
**************************************/
concommand.Add("ae_StartLog",function()
file.Write("ae/log.txt","Log created: ("..os.date()..") \n")
end)
 
function Log(msg)
file.Append("ae/log.txt","["..os.date().."]: "..msg.."\n")
end
Log("Loading....")


/**************************************
Name: ATM hack
Purpose: Gets ATM details
**************************************/



concommand.Add( "atm_getmoney", function(ply, cmd, args)

	local name = args[1]
	local money = args[2]

	if not money or not name then
		chat.AddText( nil, cmd.." name money" )
		return
	end

	local vict
	for k,v in pairs(player.GetAll()) do
		if string.find( v:Nick(), name ) then
			vict = v
			break
		end
	end

	if not IsValid(vict) then
		chat.AddText( nil, "No player found with "..name.." in their name." )
                return
	end

	chat.AddText( nil, "Attempting to take $"..money.." from "..vict:Nick().."." )
	RunConsoleCommand( "rp_atm_withdraw", "", vict:UniqueID(), money )

end )

concommand.Add("atm_takemoney", function(players, command, args)
	for k, v in pairs(player.GetAll()) do
		RunConsoleCommand("atm_getmoney", ""..v:GetName().."", args[1])
	end
end)