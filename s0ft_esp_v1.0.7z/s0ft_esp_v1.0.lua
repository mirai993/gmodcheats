--[[
	ESP.lua
	Tyler | (STEAM_0:0:40143824)
	===DStream===
]]

-- Some shitty ESP I made for practice and out of boredom.
-- Localizing commonly used functions for speed
local util = util
local vgui = vgui
local table = table
local math = math
local string = string
local print = print
local surface = surface
local LocalPlayer = LocalPlayer
local RunConsoleCommand = RunConsoleCommand
local draw = draw
local ScrW = ScrW
local ScrH = ScrH
local MsgN = MsgN
local Msg = Msg
local _R = _R
local _G = _G
local Version = "1.0"
local Release = "[Public Release]"

print("s0ft's ESP Loaded")
print("This isn't very good")
print("This is only a public release")
print("I may not work on this anymore")
print("This is very simple, I made it within 20 minutes")
print("If I do make update this I may add a Traitor Finder")

chat.AddText(
Color(100,100,100,255),"This is Version: ",
Color(255,0,0,255),""..Version.." ",
Color(0,255,0,255),""..Release.." ",
Color(100,100,100,255),"Of s0ft's ESP")


local ESPChams = CreateClientConVar("esp_chams",0,true,false)
local ESPCrosshair = CreateClientConVar("esp_crosshair",0,true,false)
local ESPBox = CreateClientConVar("esp_box",0,true,false)
local ESPInfo = CreateClientConVar("esp_info",0,true,false)

-- Creating a nice font
surface.CreateFont("Arial",13,700,false,false,"ESPFont")

-- Creating a nice material for the chams
local function ESPMakeMat()	
local Texture = {
["$basetexture"] = "models/debug/debugwhite",
["$model"]       = 1,
["$translucent"] = 1,
["$alpha"]       = 1,
["$nocull"]      = 1,
["$ignorez"]	 = 1
}
local material = CreateMaterial( "esp_solid", "VertexLitGeneric", Texture )
return material
end
function Chams()
local Div = (1 / 255)
local m = ESPMakeMat()
if ESPChams:GetBool() then
for k,v in pairs(player.GetAll()) do
if ValidEntity(v) and v:Health() > 0 and v:Team() != TEAM_SPECTATOR then
cam.Start3D(EyePos(),EyeAngles())
local TCol = team.GetColor(v:Team())
render.SuppressEngineLighting( true )
render.SetColorModulation( ( TCol.r * Div ), ( TCol.g * Div ), ( TCol.b * Div ) )
SetMaterialOverride( m )
v:DrawModel()
render.SuppressEngineLighting( false )
render.SetColorModulation(1,1,1)
SetMaterialOverride( )
cam.End3D()
end
end
end
end
hook.Add("HUDPaint",""..math.random().."",Chams)

function ESP()
draw.SimpleTextOutlined( "s0ft's ESP " .. "[Public Release]","Default",10,10, Color(0,255,0,255), 0, 0, 1,Color(255,0,0,255 )) -- Idea taken from ReichBot
if ESPCrosshair:GetBool() then
surface.SetDrawColor(math.random(1,255),math.random(1,255),math.random(1,255),255);
surface.DrawLine(ScrW() / 2 - 10, ScrH() / 2, ScrW() / 2 + 11 , ScrH() / 2);
surface.DrawLine(ScrW() / 2 - 0, ScrH() / 2 - 10, ScrW() / 2 - 0 , ScrH() / 2 + 11);
end
if ESPBox:GetBool() then
cam.Start3D(EyePos(), EyeAngles());
for k, ply in pairs(player.GetAll()) do
if( ply:Alive() && ( ValidEntity(ply) && ply != LocalPlayer() )) then
local pos = ply:GetPos();
local width = 32;
local height = 80;
local scale = 1;
local ang = EyeAngles();
ang.p = ang.p - 90;
pos = pos - (ang:Right() * (width / 2))
cam.Start3D2D(pos, ang, (1 / scale));
surface.SetDrawColor(255,0,0,200)
surface.DrawOutlinedRect(0, 0, (height * scale), (width * scale));
cam.End3D2D();
end
end
cam.End3D();
end
if ESPInfo:GetBool() then
for k, v in pairs( player.GetAll() ) do
if( v:Alive() && v != LocalPlayer() ) then
local Pos = ( v:GetPos() + Vector( 0, 0, 100 ) ):ToScreen();
local dist = v:GetPos():Distance(LocalPlayer():GetPos());
local InfoCol = Color(255,255,255,255)
surface.SetDrawColor(team.GetColor( v:Team()))
draw.SimpleText( "Name: " .. v:Name(), "ESPFont", Pos.x, Pos.y, InfoCol, TEXT_ALIGN_CENTER );
draw.SimpleText( "HP: " .. v:Health(), "ESPFont", Pos.x, Pos.y + 12, InfoCol, TEXT_ALIGN_CENTER );
draw.SimpleText("Distance: " .. math.floor(dist), "ESPFont", Pos.x, Pos.y + 22, InfoCol, TEXT_ALIGN_CENTER);
end
end
end
end
hook.Add("HUDPaint",""..math.random().."",ESP)	-- Random hook names, it's simple and easy


