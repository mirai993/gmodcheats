
--- credits to leme for Aimbot and bhop

--- update added rate spam and more precise sliders and debloated some junk that didnt work and added mods
--- minor changes



pcall(require, "frozen2")
pcall(require, "zxcmodule")

local isValid = IsValid
surface.CreateFont("wireless gamer", {font = "Open Sans MS", size = 45})
surface.CreateFont("visual gamer", {font = "Courier New", size = 15, weight = 5000, outline = true})
local _R = debug.getregistry()
_R["__rbackup"] = _R["__rbackup"] and _R["__rbackup"] or table.Copy(_R)
local r = _R["__rbackup"]
local me = LocalPlayer()
uwu = {}
uwu.rang = {}
uwu.cvars = {}
uwu.ys = GetConVarNumber("m_yaw")
uwu.aat = nil
uwu.aas = false
uwu.atk = false
uwu.ld = false
uwu.gd = false
uwu.hm = 0
uwu.dc = 0
uwu.ct = 0
uwu.flt = 0
uwu.fltm = 0
uwu.er = 0
uwu.eg = 0
uwu.eb = 0
uwu.fa = nil
uwu.sp = nil
uwu.ep = nil
uwu.atl = 0
local friends = {}

local function RainbowColor(speed)
    local time = CurTime() * speed
    local r = math.sin(time) * 127 + 128
    local g = math.sin(time + 2) * 127 + 128
    local b = math.sin(time + 4) * 127 + 128
    return Color(r, g, b)
end


local soft = {}

local global = _G //table.Copy( _G )
local gRunCmd = global.RunConsoleCommand
local gmath = math
local gMath = global.math
local math_floor = gMath.floor
local math_Round = gMath.Round
local matan = gmath.atan
local mabs = gmath.abs 
local mcos = gmath.cos
local macos = gmath.acos
local msin = gmath.sin
local mrad = gmath.rad
local mdeg = gmath.deg
local mRound = gmath.Round
local mRand = gmath.Rand
local mClamp = gmath.Clamp
local mfloor = gmath.floor
local mrandom = gmath.random
local mSqrt = gmath.sqrt
local mMin = gmath.Min
local mRandSeed = gmath.randomseed
local nAngle = gmath.NormalizeAngle
local realFrameTime = RealFrameTime
local frameTime = FrameTime
local gsurface = surface
local sPlaySound = gsurface.PlaySound
local sDrawRect = gsurface.DrawRect
local sDrawLine = gsurface.DrawLine
local sDrawText = gsurface.DrawText
local sCreateFont = gsurface.CreateFont
local sGetTextSize = gsurface.GetTextSize
local sSetTextColor = gsurface.SetTextColor
local sSetTextPos = gsurface.SetTextPos
local sSetDrawColor = gsurface.SetDrawColor
local sSetFont = gsurface.SetFont
local sDrawOutlinedRect = gsurface.DrawOutlinedRect
local sDrawCircle = gsurface.DrawCircle
local nbpkt = false

local screenW, screenH = ScrW(), ScrH()

local function paintListView(list)
    function list:Paint()
        sSetDrawColor(Color(60, 60, 60))
        sDrawRect(0, 0, self:GetWide(), self:GetTall())
    end
    function list.VBar:Paint()
        sSetDrawColor(Color(60, 60, 60))
        sDrawRect(0, 0, self:GetWide(), self:GetTall())
    end
    function list.VBar.btnGrip:Paint()
        sSetDrawColor(Color(100, 50, 50))
        sDrawRect(0, 0, self:GetWide(), self:GetTall())
        sSetDrawColor(Color(200, 0, 0))
        sDrawOutlinedRect(0, 0, self:GetWide(), self:GetTall())
    end
    function list.VBar.btnUp:Paint()
        sSetDrawColor(Color(100, 100, 100))
        sDrawRect(0, 0, self:GetWide(), self:GetTall())
    end
    function list.VBar.btnDown:Paint()
        sSetDrawColor(Color(100, 100, 100))
        sDrawRect(0, 0, self:GetWide(), self:GetTall())
    end
    for _, v in pairs(list.Columns) do
        function v.Header:Paint()
            sSetDrawColor(Color(255, 50, 50))
            sDrawRect(2.5, 0, self:GetWide() - 5, self:GetTall())
            self:SetTextColor(Color(255, 255, 255))
        end
    end
end




--- yea

local vdbg = {
    destroy = false,
    view = Angle(),
}


local TickInterval = engine.TickInterval()
local TickRate = mfloor( 1 / TickInterval ) 
local ToolList = { [ "weapon_physgun" ] = true, [ "weapon_physcannon" ] = true, [ "gmod_tool" ] = true }

function soft.TIME_TO_TICKS(time)
	return math_floor(0.5 + time / TickInterval)
end



local function GetLerpTime()
	if GetConVar("cl_interpolate"):GetInt() == 0 then return 0 end

	local lerpRatio = GetConVar("cl_interp_ratio"):GetFloat()
	if lerpRatio == 0 then
		lerpRatio = 1
	end

	local lerpAmount = GetConVar("cl_interp"):GetFloat()
	local updateRate = GetConVar("cl_updaterate"):GetFloat()

	return math.max(lerpAmount, lerpRatio / updateRate)
end

local function normalizeAngle( ang )
    ang.x = nAngle( ang.x )
    ang.p = mClamp( ang.p, -89, 89 )
    return ang
end


--- md5
local bit_band = bit.band
local bit_bor = bit.bor
local bit_bxor = bit.bxor
local bit_lshift = bit.lshift
local bit_rshift = bit.rshift

module("md5", package.seeall)

Const = {
	0xd76aa478, 0xe8c7b756, 0x242070db, 0xc1bdceee,
	0xf57c0faf, 0x4787c62a, 0xa8304613, 0xfd469501,
	0x698098d8, 0x8b44f7af, 0xffff5bb1, 0x895cd7be,
	0x6b901122, 0xfd987193, 0xa679438e, 0x49b40821,
	0xf61e2562, 0xc040b340, 0x265e5a51, 0xe9b6c7aa,
	0xd62f105d, 0x02441453, 0xd8a1e681, 0xe7d3fbc8,
	0x21e1cde6, 0xc33707d6, 0xf4d50d87, 0x455a14ed,
	0xa9e3e905, 0xfcefa3f8, 0x676f02d9, 0x8d2a4c8a,
	0xfffa3942, 0x8771f681, 0x6d9d6122, 0xfde5380c,
	0xa4beea44, 0x4bdecfa9, 0xf6bb4b60, 0xbebfbc70,
	0x289b7ec6, 0xeaa127fa, 0xd4ef3085, 0x04881d05,
	0xd9d4d039, 0xe6db99e5, 0x1fa27cf8, 0xc4ac5665,
	0xf4292244, 0x432aff97, 0xab9423a7, 0xfc93a039,
	0x655b59c3, 0x8f0ccc92, 0xffeff47d, 0x85845dd1,
	0x6fa87e4f, 0xfe2ce6e0, 0xa3014314, 0x4e0811a1,
	0xf7537e82, 0xbd3af235, 0x2ad7d2bb, 0xeb86d391,
	0x67452301, 0xefcdab89, 0x98badcfe, 0x10325476
}

local f = function(x, y, z)
	return bit_bor(bit_band(x, y), bit_band(-x - 1, z))
end

local g = function(x, y, z)
	return bit_bor(bit_band(x, z), bit_band(y, -z - 1))
end

local h = function(x, y, z)
	return bit_bxor(x, bit_bxor(y, z))
end

local i = function(x, y, z)
	return bit_bxor(y, bit_bor(x, -z - 1))
end

local z = function(f, a, b, c, d, x, s, ac)
	a = bit_band(a + f(b, c, d) + x + ac, 0xffffffff)
	return bit_bor(bit_lshift(bit_band(a, bit_rshift(0xffffffff, s)), s), bit_rshift(a, 32 - s)) + b
end

local MAX = 2 ^ 31
local SUB = 2 ^ 32

function Fix(a)
	if a > MAX then
		return a - SUB
	end

	return a
end

function Transform(A, B, C, D, X)
	local a, b, c, d = A, B, C, D

	a=z(f,a,b,c,d,X[ 0], 7,Const[ 1]) -- I'm not even gonna try with this cluster fuck
	a=Fix(a) b=Fix(b) c=Fix(c) d=Fix(d)
	d=z(f,d,a,b,c,X[ 1],12,Const[ 2])
	a=Fix(a) b=Fix(b) c=Fix(c) d=Fix(d)
	c=z(f,c,d,a,b,X[ 2],17,Const[ 3])
	a=Fix(a) b=Fix(b) c=Fix(c) d=Fix(d)
	b=z(f,b,c,d,a,X[ 3],22,Const[ 4])
	a=Fix(a) b=Fix(b) c=Fix(c) d=Fix(d)
	a=z(f,a,b,c,d,X[ 4], 7,Const[ 5])
	a=Fix(a) b=Fix(b) c=Fix(c) d=Fix(d)
	d=z(f,d,a,b,c,X[ 5],12,Const[ 6])
	a=Fix(a) b=Fix(b) c=Fix(c) d=Fix(d)
	c=z(f,c,d,a,b,X[ 6],17,Const[ 7])
	a=Fix(a) b=Fix(b) c=Fix(c) d=Fix(d)
	b=z(f,b,c,d,a,X[ 7],22,Const[ 8])
	a=Fix(a) b=Fix(b) c=Fix(c) d=Fix(d)
	a=z(f,a,b,c,d,X[ 8], 7,Const[ 9])
	a=Fix(a) b=Fix(b) c=Fix(c) d=Fix(d)
	d=z(f,d,a,b,c,X[ 9],12,Const[10])
	a=Fix(a) b=Fix(b) c=Fix(c) d=Fix(d)
	c=z(f,c,d,a,b,X[10],17,Const[11])
	a=Fix(a) b=Fix(b) c=Fix(c) d=Fix(d)
	b=z(f,b,c,d,a,X[11],22,Const[12])
	a=Fix(a) b=Fix(b) c=Fix(c) d=Fix(d)
	a=z(f,a,b,c,d,X[12], 7,Const[13])
	a=Fix(a) b=Fix(b) c=Fix(c) d=Fix(d)
	d=z(f,d,a,b,c,X[13],12,Const[14])
	a=Fix(a) b=Fix(b) c=Fix(c) d=Fix(d)
	c=z(f,c,d,a,b,X[14],17,Const[15])
	a=Fix(a) b=Fix(b) c=Fix(c) d=Fix(d)
	b=z(f,b,c,d,a,X[15],22,Const[16])
	a=Fix(a) b=Fix(b) c=Fix(c) d=Fix(d)

	a=z(g,a,b,c,d,X[ 1], 5,Const[17])
	a=Fix(a) b=Fix(b) c=Fix(c) d=Fix(d)
	d=z(g,d,a,b,c,X[ 6], 9,Const[18])
	a=Fix(a) b=Fix(b) c=Fix(c) d=Fix(d)
	c=z(g,c,d,a,b,X[11],14,Const[19])
	a=Fix(a) b=Fix(b) c=Fix(c) d=Fix(d)
	b=z(g,b,c,d,a,X[ 0],20,Const[20])
	a=Fix(a) b=Fix(b) c=Fix(c) d=Fix(d)
	a=z(g,a,b,c,d,X[ 5], 5,Const[21])
	a=Fix(a) b=Fix(b) c=Fix(c) d=Fix(d)
	d=z(g,d,a,b,c,X[10], 9,Const[22])
	a=Fix(a) b=Fix(b) c=Fix(c) d=Fix(d)
	c=z(g,c,d,a,b,X[15],14,Const[23])
	a=Fix(a) b=Fix(b) c=Fix(c) d=Fix(d)
	b=z(g,b,c,d,a,X[ 4],20,Const[24])
	a=Fix(a) b=Fix(b) c=Fix(c) d=Fix(d)
	a=z(g,a,b,c,d,X[ 9], 5,Const[25])
	a=Fix(a) b=Fix(b) c=Fix(c) d=Fix(d)
	d=z(g,d,a,b,c,X[14], 9,Const[26])
	a=Fix(a) b=Fix(b) c=Fix(c) d=Fix(d)
	c=z(g,c,d,a,b,X[ 3],14,Const[27])
	a=Fix(a) b=Fix(b) c=Fix(c) d=Fix(d)
	b=z(g,b,c,d,a,X[ 8],20,Const[28])
	a=Fix(a) b=Fix(b) c=Fix(c) d=Fix(d)
	a=z(g,a,b,c,d,X[13], 5,Const[29])
	a=Fix(a) b=Fix(b) c=Fix(c) d=Fix(d)
	d=z(g,d,a,b,c,X[ 2], 9,Const[30])
	a=Fix(a) b=Fix(b) c=Fix(c) d=Fix(d)
	c=z(g,c,d,a,b,X[ 7],14,Const[31])
	a=Fix(a) b=Fix(b) c=Fix(c) d=Fix(d)
	b=z(g,b,c,d,a,X[12],20,Const[32])
	a=Fix(a) b=Fix(b) c=Fix(c) d=Fix(d)

	a=z(h,a,b,c,d,X[ 5], 4,Const[33])
	a=Fix(a) b=Fix(b) c=Fix(c) d=Fix(d)
	d=z(h,d,a,b,c,X[ 8],11,Const[34])
	a=Fix(a) b=Fix(b) c=Fix(c) d=Fix(d)
	c=z(h,c,d,a,b,X[11],16,Const[35])
	a=Fix(a) b=Fix(b) c=Fix(c) d=Fix(d)
	b=z(h,b,c,d,a,X[14],23,Const[36])
	a=Fix(a) b=Fix(b) c=Fix(c) d=Fix(d)
	a=z(h,a,b,c,d,X[ 1], 4,Const[37])
	a=Fix(a) b=Fix(b) c=Fix(c) d=Fix(d)
	d=z(h,d,a,b,c,X[ 4],11,Const[38])
	a=Fix(a) b=Fix(b) c=Fix(c) d=Fix(d)
	c=z(h,c,d,a,b,X[ 7],16,Const[39])
	a=Fix(a) b=Fix(b) c=Fix(c) d=Fix(d)
	b=z(h,b,c,d,a,X[10],23,Const[40])
	a=Fix(a) b=Fix(b) c=Fix(c) d=Fix(d)
	a=z(h,a,b,c,d,X[13], 4,Const[41])
	a=Fix(a) b=Fix(b) c=Fix(c) d=Fix(d)
	d=z(h,d,a,b,c,X[ 0],11,Const[42])
	a=Fix(a) b=Fix(b) c=Fix(c) d=Fix(d)
	c=z(h,c,d,a,b,X[ 3],16,Const[43])
	a=Fix(a) b=Fix(b) c=Fix(c) d=Fix(d)
	b=z(h,b,c,d,a,X[ 6],23,Const[44])
	a=Fix(a) b=Fix(b) c=Fix(c) d=Fix(d)
	a=z(h,a,b,c,d,X[ 9], 4,Const[45])
	a=Fix(a) b=Fix(b) c=Fix(c) d=Fix(d)
	d=z(h,d,a,b,c,X[12],11,Const[46])
	a=Fix(a) b=Fix(b) c=Fix(c) d=Fix(d)
	c=z(h,c,d,a,b,X[15],16,Const[47])
	a=Fix(a) b=Fix(b) c=Fix(c) d=Fix(d)
	b=z(h,b,c,d,a,X[ 2],23,Const[48])
	a=Fix(a) b=Fix(b) c=Fix(c) d=Fix(d)

	a=z(i,a,b,c,d,X[ 0], 6,Const[49])
	a=Fix(a) b=Fix(b) c=Fix(c) d=Fix(d)
	d=z(i,d,a,b,c,X[ 7],10,Const[50])
	a=Fix(a) b=Fix(b) c=Fix(c) d=Fix(d)
	c=z(i,c,d,a,b,X[14],15,Const[51])
	a=Fix(a) b=Fix(b) c=Fix(c) d=Fix(d)
	b=z(i,b,c,d,a,X[ 5],21,Const[52])
	a=Fix(a) b=Fix(b) c=Fix(c) d=Fix(d)
	a=z(i,a,b,c,d,X[12], 6,Const[53])
	a=Fix(a) b=Fix(b) c=Fix(c) d=Fix(d)
	d=z(i,d,a,b,c,X[ 3],10,Const[54])
	a=Fix(a) b=Fix(b) c=Fix(c) d=Fix(d)
	c=z(i,c,d,a,b,X[10],15,Const[55])
	a=Fix(a) b=Fix(b) c=Fix(c) d=Fix(d)
	b=z(i,b,c,d,a,X[ 1],21,Const[56])
	a=Fix(a) b=Fix(b) c=Fix(c) d=Fix(d)
	a=z(i,a,b,c,d,X[ 8], 6,Const[57])
	a=Fix(a) b=Fix(b) c=Fix(c) d=Fix(d)
	d=z(i,d,a,b,c,X[15],10,Const[58])
	a=Fix(a) b=Fix(b) c=Fix(c) d=Fix(d)
	c=z(i,c,d,a,b,X[ 6],15,Const[59])
	a=Fix(a) b=Fix(b) c=Fix(c) d=Fix(d)
	b=z(i,b,c,d,a,X[13],21,Const[60])
	a=Fix(a) b=Fix(b) c=Fix(c) d=Fix(d)
	a=z(i,a,b,c,d,X[ 4], 6,Const[61])
	a=Fix(a) b=Fix(b) c=Fix(c) d=Fix(d)
	d=z(i,d,a,b,c,X[11],10,Const[62])
	a=Fix(a) b=Fix(b) c=Fix(c) d=Fix(d)
	c=z(i,c,d,a,b,X[ 2],15,Const[63])
	a=Fix(a) b=Fix(b) c=Fix(c) d=Fix(d)
	b=z(i,b,c,d,a,X[ 9],21,Const[64])
	a=Fix(a) b=Fix(b) c=Fix(c) d=Fix(d)

	return A + a, B + b, C + c, D + d
end

function PseudoRandom(number)
    local a, b, c, d = Fix(Const[65]), Fix(Const[66]), Fix(Const[67]), Fix(Const[68])

    local m = {}

    for i= 0, 15 do
		m[i] = 0
	end

    m[0] = number
    m[1] = 128
    m[14] = 32

    local a,b,c,d = Transform(a,b,c,d,m)

    return bit_rshift( Fix(b) , 16) % 256
end

EngineSpread = {
    [0] = {-0.492036, 0.286111},
    [1] = {-0.492036, 0.286111},
    [2] = {-0.255320, 0.128480},
    [3] = {0.456165, 0.356030},
    [4] = {-0.361731, 0.406344},
    [5] = {-0.146730, 0.834589},
    [6] = {-0.253288, -0.421936},
    [7] = {-0.448694, 0.111650},
    [8] = {-0.880700, 0.904610},
    [9] = {-0.379932, 0.138833},
    [10] = {0.502579, -0.494285},
    [11] = {-0.263847, -0.594805},
    [12] = {0.818612, 0.090368},
    [13] = {-0.063552, 0.044356},
    [14] = {0.490455, 0.304820},
    [15] = {-0.192024, 0.195162},
    [16] = {-0.139421, 0.857106},
    [17] = {0.715745, 0.336956},
    [18] = {-0.150103, -0.044842},
    [19] = {-0.176531, 0.275787},
    [20] = {0.155707, -0.152178},
    [21] = {-0.136486, -0.591896},
    [22] = {-0.021022, -0.761979},
    [23] = {-0.166004, -0.733964},
    [24] = {-0.102439, -0.132059},
    [25] = {-0.607531, -0.249979},
    [26] = {-0.500855, -0.185902},
    [27] = {-0.080884, 0.516556},
    [28] = {-0.003334, 0.138612},
    [29] = {-0.546388, -0.000115},
    [30] = {-0.228092, -0.018492},
    [31] = {0.542539, 0.543196},
    [32] = {-0.355162, 0.197473},
    [33] = {-0.041726, -0.015735},
    [34] = {-0.713230, -0.551701},
    [35] = {-0.045056, 0.090208},
    [36] = {0.061028, 0.417744},
    [37] = {-0.171149, -0.048811},
    [38] = {0.241499, 0.164562},
    [39] = {-0.129817, -0.111200},
    [40] = {0.007366, 0.091429},
    [41] = {-0.079268, -0.008285},
    [42] = {0.010982, -0.074707},
    [43] = {-0.517782, -0.682470},
    [44] = {-0.663822, -0.024972},
    [45] = {0.058213, -0.078307},
    [46] = {-0.302041, -0.132280},
    [47] = {0.217689, -0.209309},
    [48] = {-0.143615, 0.830349},
    [49] = {0.270912, 0.071245},
    [50] = {-0.258170, -0.598358},
    [51] = {0.099164, -0.257525},
    [52] = {-0.214676, -0.595918},
    [53] = {-0.427053, -0.523764},
    [54] = {-0.585472, 0.088522},
    [55] = {0.564305, -0.533822},
    [56] = {-0.387545, -0.422206},
    [57] = {0.690505, -0.299197},
    [58] = {0.475553, 0.169785},
    [59] = {0.347436, 0.575364},
    [60] = {-0.069555, -0.103340},
    [61] = {0.286197, -0.618916},
    [62] = {-0.505259, 0.106581},
    [63] = {-0.420214, -0.714843},
    [64] = {0.032596, -0.401891},
    [65] = {-0.238702, -0.087387},
    [66] = {0.714358, 0.197811},
    [67] = {0.208960, 0.319015},
    [68] = {-0.361140, 0.222130},
    [69] = {-0.133284, -0.492274},
    [70] = {0.022824, -0.133955},
    [71] = {-0.100850, 0.271962},
    [72] = {-0.050582, -0.319538},
    [73] = {0.577980, 0.095507},
    [74] = {0.224871, 0.242213},
    [75] = {-0.628274, 0.097248},
    [76] = {0.184266, 0.091959},
    [77] = {-0.036716, 0.474259},
    [78] = {-0.502566, -0.279520},
    [79] = {-0.073201, -0.036658},
    [80] = {0.339952, -0.293667},
    [81] = {0.042811, 0.130387},
    [82] = {0.125881, 0.007040},
    [83] = {0.138374, -0.418355},
    [84] = {0.261396, -0.392697},
    [85] = {-0.453318, -0.039618},
    [86] = {0.890159, -0.335165},
    [87] = {0.466437, -0.207762},
    [88] = {0.593253, 0.418018},
    [89] = {0.566934, -0.643837},
    [90] = {0.150918, 0.639588},
    [91] = {0.150112, 0.215963},
    [92] = {-0.130520, 0.324801},
    [93] = {-0.369819, -0.019127},
    [94] = {-0.038889, -0.650789},
    [95] = {0.490519, -0.065375},
    [96] = {-0.305940, 0.454759},
    [97] = {-0.521967, -0.550004},
    [98] = {-0.040366, 0.683259},
    [99] = {0.137676, -0.376445},
    [100] = {0.839301, 0.085979},
    [101] = {-0.319140, 0.481838},
    [102] = {0.201437, -0.033135},
    [103] = {0.384637, -0.036685},
    [104] = {0.598419, 0.144371},
    [105] = {-0.061424, -0.608645},
    [106] = {-0.065337, 0.308992},
    [107] = {-0.029356, -0.634337},
    [108] = {0.326532, 0.047639},
    [109] = {0.505681, -0.067187},
    [110] = {0.691612, 0.629364},
    [111] = {-0.038588, -0.635947},
    [112] = {0.637837, -0.011815},
    [113] = {0.765338, 0.563945},
    [114] = {0.213416, 0.068664},
    [115] = {-0.576581, 0.554824},
    [116] = {0.246580, 0.132726},
    [117] = {0.385548, -0.070054},
    [118] = {0.538735, -0.291010},
    [119] = {0.609944, 0.590973},
    [120] = {-0.463240, 0.010302},
    [121] = {-0.047718, 0.741086},
    [122] = {0.308590, -0.322179},
    [123] = {-0.291173, 0.256367},
    [124] = {0.287413, -0.510402},
    [125] = {0.864716, 0.158126},
    [126] = {0.572344, 0.561319},
    [127] = {-0.090544, 0.332633},
    [128] = {0.644714, 0.196736},
    [129] = {-0.204198, 0.603049},
    [130] = {-0.504277, -0.641931},
    [131] = {0.218554, 0.343778},
    [132] = {0.466971, 0.217517},
    [133] = {-0.400880, -0.299746},
    [134] = {-0.582451, 0.591832},
    [135] = {0.421843, 0.118453},
    [136] = {-0.215617, -0.037630},
    [137] = {0.341048, -0.283902},
    [138] = {-0.246495, -0.138214},
    [139] = {0.214287, -0.196102},
    [140] = {0.809797, -0.498168},
    [141] = {-0.115958, -0.260677},
    [142] = {-0.025448, 0.043173},
    [143] = {-0.416803, -0.180813},
    [144] = {-0.782066, 0.335273},
    [145] = {0.192178, -0.151171},
    [146] = {0.109733, 0.165085},
    [147] = {-0.617935, -0.274392},
    [148] = {0.283301, 0.171837},
    [149] = {-0.150202, 0.048709},
    [150] = {-0.179954, -0.288559},
    [151] = {-0.288267, -0.134894},
    [152] = {-0.049203, 0.231717},
    [153] = {-0.065761, 0.495457},
    [154] = {0.082018, -0.457869},
    [155] = {-0.159553, 0.032173},
    [156] = {0.508305, -0.090690},
    [157] = {0.232269, -0.338245},
    [158] = {-0.374490, -0.480945},
    [159] = {-0.541244, 0.194144},
    [160] = {-0.040063, -0.073532},
    [161] = {0.136516, -0.167617},
    [162] = {-0.237350, 0.456912},
    [163] = {-0.446604, -0.494381},
    [164] = {0.078626, -0.020068},
    [165] = {0.163208, 0.600330},
    [166] = {-0.886186, -0.345326},
    [167] = {-0.732948, -0.689349},
    [168] = {0.460564, -0.719006},
    [169] = {-0.033688, -0.333340},
    [170] = {-0.325414, -0.111704},
    [171] = {0.010928, 0.723791},
    [172] = {0.713581, -0.077733},
    [173] = {-0.050912, -0.444684},
    [174] = {-0.268509, 0.381144},
    [175] = {-0.175387, 0.147070},
    [176] = {-0.429779, 0.144737},
    [177] = {-0.054564, 0.821354},
    [178] = {0.003205, 0.178130},
    [179] = {-0.552814, 0.199046},
    [180] = {0.225919, -0.195013},
    [181] = {0.056040, -0.393974},
    [182] = {-0.505988, 0.075184},
    [183] = {-0.510223, 0.156271},
    [184] = {-0.209616, 0.111174},
    [185] = {-0.605132, -0.117104},
    [186] = {0.412433, -0.035510},
    [187] = {-0.573947, -0.691295},
    [188] = {-0.712686, 0.021719},
    [189] = {-0.643297, 0.145307},
    [190] = {0.245038, 0.343062},
    [191] = {-0.235623, -0.159307},
    [192] = {-0.834004, 0.088725},
    [193] = {0.121377, 0.671713},
    [194] = {0.528614, 0.607035},
    [195] = {-0.285699, -0.111312},
    [196] = {0.603385, 0.401094},
    [197] = {0.632098, -0.439659},
    [198] = {0.681016, -0.242436},
    [199] = {-0.261709, 0.304265},
    [200] = {-0.653737, -0.199245},
    [201] = {-0.435512, -0.762978},
    [202] = {0.701105, 0.389527},
    [203] = {0.093495, -0.148484},
    [204] = {0.715218, 0.638291},
    [205] = {-0.055431, -0.085173},
    [206] = {-0.727438, 0.889783},
    [207] = {-0.007230, -0.519183},
    [208] = {-0.359615, 0.058657},
    [209] = {0.294681, 0.601155},
    [210] = {0.226879, -0.255430},
    [211] = {-0.307847, -0.617373},
    [212] = {0.340916, -0.780086},
    [213] = {-0.028277, 0.610455},
    [214] = {-0.365067, 0.323311},
    [215] = {0.001059, -0.270451},
    [216] = {0.304025, 0.047478},
    [217] = {0.297389, 0.383859},
    [218] = {0.288059, 0.262816},
    [219] = {-0.889315, 0.533731},
    [220] = {0.215887, 0.678889},
    [221] = {0.287135, 0.343899},
    [222] = {0.423951, 0.672285},
    [223] = {0.411912, -0.812886},
    [224] = {0.081615, -0.497358},
    [225] = {-0.051963, -0.117891},
    [226] = {-0.062387, 0.331698},
    [227] = {0.020458, -0.734125},
    [228] = {-0.160176, 0.196321},
    [229] = {0.044898, -0.024032},
    [230] = {-0.153162, 0.930951},
    [231] = {-0.015084, 0.233476},
    [232] = {0.395043, 0.645227},
    [233] = {-0.232095, 0.283834},
    [234] = {-0.507699, 0.317122},
    [235] = {-0.606604, -0.227259},
    [236] = {0.526430, -0.408765},
    [237] = {0.304079, 0.135680},
    [238] = {-0.134042, 0.508741},
    [239] = {-0.276770, 0.383958},
    [240] = {-0.298963, -0.233668},
    [241] = {0.171889, 0.697367},
    [242] = {-0.292571, -0.317604},
    [243] = {0.587806, 0.115584},
    [244] = {-0.346690, -0.098320},
    [245] = {0.956701, -0.040982},
    [246] = {0.040838, 0.595304},
    [247] = {0.365201, -0.519547},
    [248] = {-0.397271, -0.090567},
    [249] = {-0.124873, -0.356800},
    [250] = {-0.122144, 0.617725},
    [251] = {0.191266, -0.197764},
    [252] = {-0.178092, 0.503667},
    [253] = {0.103221, 0.547538},
    [254] = {0.019524, 0.621226},
    [255] = {0.663918, -0.573476}
}


-- rest

StartPrediction = StartPrediction or function() end
EndPrediction = EndPrediction or function() end

local stuff = {
	Order = { -- Scan in this order
		HITGROUP_HEAD,
		HITGROUP_CHEST,
		HITGROUP_STOMACH
	},

	CalcView = {
		EyePos = EyePos(),
		EyeAngles = EyeAngles(),
		FOV = LocalPlayer():GetFOV(),
		ZNear = 2.6
	},

	NotGuns = { -- Funny classes
		"bomb",
		"c4",
		"climb",
		"fist",
		"gravity gun",
		"grenade",
		"hand",
		"ied",
		"knife",
		"physics gun",
		"slam",
		"sword",
		"tool gun"
	},

	ActuallyGuns = { -- Even funnier classes
		"handgun"
	},

	FOVTri = {
		{x = 0, y = 0},
		{x = 0, y = 0},
		{x = 0, y = 0},
	},

	ConVars = {
		cl_interp = GetConVar("cl_interp"),

		sv_gravity = GetConVar("sv_gravity"),

		m_pitch = GetConVar("m_pitch"),
		m_yaw = GetConVar("m_yaw")
	},

	ExtraChecks = {
		-- These are taken directly from the weapon's base code with minor changes
		-- I couldn't be bothered to clean any of it up

		bobs = function(weapon) -- M9K
			if not IsValid(weapon) then return false end

			if not weapon.Owner:IsPlayer() then return false end
			if weapon.Owner:KeyDown(IN_SPEED) or weapon.Owner:KeyDown(IN_RELOAD) then return false end
			if weapon:GetNWBool("Reloading", false) then return false end
			if weapon:Clip1() < 1 then return false end

			return true
		end,

		cw = function(weapon)
			if not IsValid(weapon) then return false end

			if not weapon:canFireWeapon(1) or not weapon:canFireWeapon(2) or not weapon:canFireWeapon(3) then return false end
			if weapon.Owner:KeyDown(IN_USE) and CustomizableWeaponry.quickGrenade.canThrow(weapon) then return false end
			if weapon.dt.State == CW_AIMING and weapon.dt.M203Active and weapon.M203Chamber then return false end
			if weapon.dt.Safe then return false end
			if weapon:Clip1() == 0 then return false end
			if weapon.BurstAmount and weapon.BurstAmount > 0 then return false end

			return true
		end,

		fas2 = function(weapon)
			if not IsValid(weapon) then return false end

			if weapon.FireMode == "safe" then return false end
			if weapon.BurstAmount > 0 and weapon.dt.Shots >= weapon.BurstAmount then return false end
			if weapon.ReloadState ~= 0 then return false end
			if weapon.dt.Status == FAS_STAT_CUSTOMIZE then return false end
			if weapon.Cooking or weapon.FuseTime then return false end
			if weapon.Owner:KeyDown(IN_USE) and weapon:CanThrowGrenade() then return false end
			if weapon.dt.Status == FAS_STAT_SPRINT or weapon.dt.Status == FAS_STAT_QUICKGRENADE then return false end
			if weapon:Clip1() <= 0 or weapon.Owner:WaterLevel() >= 3 then return false end
			if weapon.CockAfterShot and not weapon.Cocked then return false end

			return true
		end,

		tfa = function(weapon)
			if not IsValid(weapon) then return false end

			local weapon2 = weapon:GetTable()

			local v = hook.Run("TFA_PreCanPrimaryAttack", weapon)
			if v ~= nil then return v end

			local stat = weapon:GetStatus()
			if stat == TFA.Enum.STATUS_RELOADING_WAIT or stat == TFA.Enum.STATUS_RELOADING then return false end

			if weapon:IsSafety() then return false end
			if weapon:GetSprintProgress() >= 0.1 and not weapon:GetStatL("AllowSprintAttack", false) then return false end
			if weapon:GetStatL("Primary.ClipSize") <= 0 and weapon:Ammo1() < weapon:GetStatL("Primary.AmmoConsumption") then return false end
			if weapon:GetPrimaryClipSize(true) > 0 and weapon:Clip1() < weapon:GetStatL("Primary.AmmoConsumption") then return false end
			if weapon2.GetStatL(weapon, "Primary.FiresUnderwater") == false and weapon:GetOwner():WaterLevel() >= 3 then return false end

			v = hook.Run("TFA_CanPrimaryAttack", self)
			if v ~= nil then return v end

			if weapon:CheckJammed() then return false end

			return true
		end,

		arccw = function(weapon)
			if not IsValid(weapon) then return false end

			if IsValid(weapon:GetHolster_Entity()) then return false end
			if weapon:GetHolster_Time() > 0 then return false end
			if weapon:GetReloading() then return false end
			if weapon:GetWeaponOpDelay() > CurTime() then return false end
			if weapon:GetHeatLocked() then return false end
			if weapon:GetState() == ArcCW.STATE_CUSTOMIZE then return false end
			if weapon:BarrelHitWall() > 0 then return false end
			if weapon:GetNWState() == ArcCW.STATE_SPRINT and not (weapon:GetBuff_Override("Override_ShootWhileSprint", weapon.ShootWhileSprint)) then return false end
			if (weapon:GetBurstCount() or 0) >= weapon:GetBurstLength() then return false end
			if weapon:GetNeedCycle() then return false end
			if weapon:GetCurrentFiremode().Mode == 0 then return false end
			if weapon:GetBuff_Override("Override_TriggerDelay", weapon.TriggerDelay) and weapon:GetTriggerDelta() < 1 then return false end
			if weapon:GetBuff_Hook("Hook_ShouldNotFire") then return false end
			if weapon:GetBuff_Hook("Hook_ShouldNotFireFirst") then return false end

			return true
		end
	},

	WeaponCones = {},

	BuildModeNetVars = {
		"BuildMode", -- Libby's
		"buildmode", -- Fun Server
		"_Kyle_Buildmode", -- Workshop addon
                "LibbyProtectedSpawn",
		"BuildMode"
	},

	GodModeNetVars = {
		"has_god" -- Fun Server + LBG
	},

	HvHModeNetVars = {
		"HVHER" -- Fun Server + LBG
	},

	og = LocalPlayer():EyeAngles(),

	ServerTime = CurTime(),
	TickInterval = engine.TickInterval(),

	FOV = 16,
        AimKey = MOUSE_5
   
}


local function GetEyePos() -- Quickerish ways of getting CalcView information from the CalcView hook
	return stuff.CalcView.EyePos
end

local function GetEyeAngles()
	return stuff.CalcView.EyeAngles
end

local function GetFOV()
	return stuff.CalcView.FOV
end

local function GetZNear()
	return stuff.CalcView.ZNear
end

local function FixAngle(ang)
	ang = ang or angle_zero
	
	return Angle(math.Clamp(math.NormalizeAngle(ang.pitch), -89, 89), math.NormalizeAngle(ang.yaw), math.NormalizeAngle(ang.roll)) -- Fixes an angle to (-89, 89), (-180, 180), (-180, 180)
end

local function GetBase(weapon)
	if not IsValid(weapon) or not weapon.Base then
		return nil
	end

	return weapon.Base:lower():Split("_")[1]
end


local function UtilityCheck(v)
    if v != ply and v:Alive() and v:IsValid() then
        return true
    else
        return false
    end
end

function uwu.AddHook(htype, name, func)
hook.Add(htype, name, func)
end

SizeW = 0.6 * ScrW()
SizeH = 0.6 * ScrH()
CenterX = (ScrW()/2) - SizeW/2
CenterY = (ScrH()/2) - SizeH/2


surface.CreateFont( "butf", {
	font = "Arial", 
	extended = true,
	size = 21,
	weight = 10000,
	blursize = 0,
	scanlines = 0,
       antialias = false,
	underline = false,
	italic = false,
	strikeout = false,
	symbol = false,
	rotary = false,
	shadow = false,
	additive = true,
	outline = false,
} )

local blue = Color(86, 159, 206, 255)

local vars = {
   name = true,
   rank = false,
   health = false,
   weapon = false,
   thirdperson = false,
   esp = true,
   box = true,
   chams = false,
   hud = true,
   radar = false,
   crosshair = false,

   aa = false,
   aa_mode = 'none',
   aa_realy = 0,
   aa_realp = 0,
   aa_fakey = 180,
   aa_fakep = 90,
   resolver = false,
   teamig = false,


   fl_choke = 0,
   fl = false,
   bhop = true,
   strafe = false,
   aura = false,
   crash = false,
   killsay = false,

   aim = true,
   silent = true,
   psilent = false,
   autofire = true,
   pred = true,
   norecoil = true,
   nospread = true,
   scaling_factor = 0.00,
   mouseaim = false,
   nointerp = true,
   synctick = false
}

CreateClientConVar("customdisconnect", "Disconnect Reason: too many fake niggas", true, false)

local function CreateDarkSlider(parent, posX, posY, Min, Max, val, sliderName)
    local slider = vgui.Create("DNumSlider", parent)
    slider:SetPos(posX, posY)
    slider:SetSize(370, 50)
    slider:SetText("")
    slider:SetMin(Min)
    slider:SetMax(Max)
    slider:SetValue(vars[val])
    slider:SetDecimals(2) -- No decimal places
    slider:SetDark(true) -- Use dark theme

    slider.Slider.Paint = function(self, w, h)
        draw.RoundedBox(4, 0, h/2 - 2, 300, 4, Color(255, 255, 255, 50)) -- Slider track
    end

    slider.Slider.Knob.Paint = function(self, w, h)
        draw.RoundedBox(8, 0, 0, w, h, Color(90, 90, 90, 255)) -- Slider knob
    end

    function slider:OnValueChanged(num)
        vars[val] = num
    end

    local label = vgui.Create("DLabel", parent)
    label:SetText(sliderName)
    label:SetPos(posX + 120, posY)
    label:SetFont("DermaDefault")
    label:SizeToContents()

    return slider
end

local function slider( name, val, min, max, x, y, w, h, parent)
    local slider = vgui.Create( "DNumSlider", parent)
        slider:SetMin( min )
        slider:SetMax( max )
        slider:SetText("")
        slider:SetSize(w, h)
        slider:SetPos(x, y)
        slider:SetValue( vars[val] )
        slider:SetDecimals(2)
    function slider:OnValueChanged( num )
        vars[val] = num
    end
    slider.Slider.Paint = function(self, w, h)
        draw.RoundedBox(4, 0, h/2 - 2, w, 4, Color(50,50,50, 255)) -- Slider track
    end

    slider.Slider.Knob.Paint = function(self, w, h)
        draw.RoundedBox(8, 0, 0, w, h, Color(40, 40, 255, 255)) -- Slider knob
    end

    local label = vgui.Create("DLabel", parent)
    label:SetText(name)
    label:SetPos(x + 190, y - 18)
    label:SetFont("tabf")
    label:SizeToContents()



end



local function checkbox(name, tooltip, val, x, y, parent)
    local checkbox = vgui.Create("DCheckBox", parent)
    checkbox:SetPos(x, y)
    checkbox:SetSize(25, 25)
    checkbox:SetTextColor(Color(255, 255, 255))
    checkbox:SetChecked(vars[val])
    if isstring(tooltip) then
        checkbox:SetTooltip(tooltip)
    end

    function checkbox:OnChange(bval)
        vars[val] = bval
    end

    function checkbox:PaintOver(w, h)
        draw.RoundedBox(0, 0, 0, w, h, Color(90,90,90))
        draw.RoundedBox(0, 0, 24, 25, 1, Color(0, 0, 0))
        draw.RoundedBox(0, 0, 0, 1, 25, Color(0, 0, 0))
        draw.RoundedBox(0, 24, 0, 1, 25, Color(0, 0, 0))
        draw.RoundedBox(0, 0, 0, 24, 1, Color(0, 0, 0))
        if checkbox:GetChecked() then
            surface.SetDrawColor(255, 255, 255, 255)
            surface.DrawLine(5, 11, 11, 18)
            surface.DrawLine(11, 18, 19, 5)
        end
    end

    local label = vgui.Create("DLabel", parent)
    label:SetText(name)
    label:SetPos(x + 35, y+4) -- Position the label next to the checkbox
    label:SetFont("tabf")
    label:SizeToContents()
end


surface.CreateFont("Font", {
    font = "Arial",
    extended = true,
    weight = 10000,
    antialias = false,
    additive = true,
    size = 24
})

surface.CreateFont( "tabf", {
	font = "Arial", 
	extended = true,
	size = 20,
	weight = 10000,
	blursize = 0,
	scanlines = 0,
       antialias = false,
	underline = false,
	italic = false,
	strikeout = false,
	symbol = false,
	rotary = false,
	shadow = false,
	additive = true,
	outline = false,
} )


local green = Color(50, 50, 50, 255)
local lgreen = Color(60, 60, 60, 255)
local llgreen = Color(49, 48, 43, 255)
local blue = Color(86, 159, 206, 255)




local frame

local function ui()
 if IsValid(frame) then
        frame:Close()
        frame = nil
    else
	frame = vgui.Create("DFrame") 
	frame:SetSize(600, 450) 
	frame:Center()
	frame:SetTitle("") 
	frame:SetDraggable(true)
        frame:ShowCloseButton(false) 
	frame:MakePopup() 

	frame.Paint = function(self, w, h)
	    draw.RoundedBox(0, 0, 0, w, h, Color(200,50,50,200))
            draw.RoundedBox(0, 0, 0, w, 49, Color(200,50,50))
            draw.RoundedBox(0, 0, 50, w, 1, Color(255,255,255))
      	    draw.SimpleText("Snowy", "Font", 10, 12, Color(255,255,255))
	end

        local panel1 = vgui.Create('DPanel', frame)
        panel1:SetSize( 600, 480 )
        panel1:SetPos( 0, 51 )
        panel1.Paint = function(self, w, h)
         draw.RoundedBox(0, 0, 0, w, h, Color(30,30,30,250))
         draw.RoundedBox(4, 10, 10, 280, 380, Color(100,100,100,20))
         draw.RoundedBox(4, 310, 10, 280, 380, Color(100,100,100,20))
        end
        panel1:SetVisible(activetab == 'Aimbot')

      
        local panel3 = vgui.Create('DPanel', frame)
        panel3:SetSize( 600, 480 )
        panel3:SetPos( 0, 51 )
        panel3.Paint = function(self, w, h)
          draw.RoundedBox(0, 0, 0, w, h, Color(30,30,30))
         draw.RoundedBox(4, 10, 10, 280, 380, Color(100,100,100,20))
         draw.RoundedBox(4, 310, 10, 280, 380, Color(100,100,100,20))

        end
        panel3:SetVisible(activetab == 'Visuals')

        local panel4 = vgui.Create('DPanel', frame)
        panel4:SetSize( 600, 480 )
        panel4:SetPos( 0, 51 )
        panel4.Paint = function(self, w, h)
          draw.RoundedBox(0, 0, 0, w, h, Color(30,30,30))
         draw.RoundedBox(4, 10, 10, 280, 380, Color(100,100,100,20))
         draw.RoundedBox(4, 310, 10, 280, 380, Color(100,100,100,20))

         end
        panel4:SetVisible(activetab == 'Misc')

        local panell = vgui.Create('DPanel', frame)
        panell:SetSize( 600, 480 )
        panell:SetPos( 0, 51 )
        panell.Paint = function(self, w, h)
          draw.RoundedBox(0, 0, 0, w, h, Color(30,30,30))
         draw.RoundedBox(4, 10, 10, 280, 380, Color(100,100,100,20))
         draw.RoundedBox(4, 310, 10, 280, 380, Color(100,100,100,20))

         end
        panell:SetVisible(activetab == 'legitbot')


             



       --- tabs

       local but = vgui.Create( "DButton", frame ) 
       but:SetText( "" )	
       but:SetPos( 200, 20 )
       but:SetSize( 92, 30 )	
       but.Paint = function(self, w, h)
         if activetab == 'Aimbot' then
          draw.RoundedBox(0, 0, 0, w, h, Color(80,80,80))
          draw.RoundedBox(0, 0, 28, w, 2, Color(255,255,255))
         else 
         draw.RoundedBox(0, 0, 0, w, h, llgreen)
         draw.RoundedBox(0, 0, 0, w, 1, Color(0,0,0))
         draw.RoundedBox(0, 0, 29, w, 1, Color(0,0,0))
         draw.RoundedBox(0, 0, 0, 1, h, Color(0,0,0))
         draw.RoundedBox(0, 91, 0, 1, h, Color(0,0,0))
         draw.RoundedBox(0, 96, 0, 1, h, Color(0,0,0))
         end
        draw.SimpleText("Ragebot", "tabf", 46, 5, color_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
       end
       but.DoClick = function()
    activetab = 'Aimbot'
    panel1:SetVisible(true)
    panell:SetVisible(false)
    panel3:SetVisible(false)
    panel4:SetVisible(false)
end

local butl = vgui.Create( "DButton", frame ) 
       butl:SetText( "" )	
       butl:SetPos( 100, 20 )
       butl:SetSize( 92, 30 )	
       butl.Paint = function(self, w, h)
         if activetab == 'legit' then
          draw.RoundedBox(0, 0, 0, w, h, Color(80,80,80))
          draw.RoundedBox(0, 0, 28, w, 2, Color(255,255,255))
         else 
         draw.RoundedBox(0, 0, 0, w, h, llgreen)
         draw.RoundedBox(0, 0, 0, w, 1, Color(0,0,0))
         draw.RoundedBox(0, 0, 29, w, 1, Color(0,0,0))
         draw.RoundedBox(0, 0, 0, 1, h, Color(0,0,0))
         draw.RoundedBox(0, 91, 0, 1, h, Color(0,0,0))
         draw.RoundedBox(0, 96, 0, 1, h, Color(0,0,0))
         end
        draw.SimpleText("Legitbot", "tabf", 46, 5, color_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
       end
       butl.DoClick = function()
    activetab = 'legit'
    panel1:SetVisible(false)
    panell:SetVisible(true)
    panel3:SetVisible(false)
    panel4:SetVisible(false)
end



      


       local but2 = vgui.Create( "DButton", frame ) 
       but2:SetText( "" )	
       but2:SetPos( 300, 20 )
       but2:SetSize( 92, 30 )	
       but2.Paint = function(self, w, h)
        if activetab == 'Visuals' then
          draw.RoundedBox(0, 0, 0, w, h, Color(80,80,80))
          draw.RoundedBox(0, 0, 28, w, 2, Color(255,255,255))
         else 
         draw.RoundedBox(0, 0, 0, w, h, llgreen)
         draw.RoundedBox(0, 0, 0, w, 1, Color(0,0,0))
         draw.RoundedBox(0, 0, 29, w, 1, Color(0,0,0))
         draw.RoundedBox(0, 0, 0, 1, h, Color(0,0,0))
         draw.RoundedBox(0, 91, 0, 1, h, Color(0,0,0))
         draw.RoundedBox(0, 96, 0, 1, h, Color(0,0,0))

         end
        draw.SimpleText("Visuals", "tabf", 46, 5, color_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
       end
       but2.DoClick = function()
    activetab = 'Visuals'
    panel1:SetVisible(false)
    panell:SetVisible(false)
    panel3:SetVisible(true)
    panel4:SetVisible(false)
end



       local but3 = vgui.Create( "DButton", frame ) 
       but3:SetText( "" )	
       but3:SetPos(400, 20)
       but3:SetSize( 92, 30 )	
       but3.Paint = function(self, w, h)
        if activetab == 'Misc' then
          draw.RoundedBox(0, 0, 0, w, h, Color(80,80,80))
          draw.RoundedBox(0, 0, 28, w, 2, Color(255,255,255))
         else 
         draw.RoundedBox(0, 0, 0, w, h, llgreen)
         draw.RoundedBox(0, 0, 0, w, 1, Color(0,0,0))
         draw.RoundedBox(0, 0, 29, w, 1, Color(0,0,0))
         draw.RoundedBox(0, 0, 0, 1, h, Color(0,0,0))
         draw.RoundedBox(0, 91, 0, 1, h, Color(0,0,0))
         draw.RoundedBox(0, 96, 0, 1, h, Color(0,0,0))

         end
        draw.SimpleText("Misc", "tabf", 46, 5, color_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
       end
       but3.DoClick = function()
    activetab = 'Misc'
    panel1:SetVisible(false)
    panell:SetVisible(false)
    panel3:SetVisible(false)
    panel4:SetVisible(true)
end


local but4 = vgui.Create( "DButton", frame ) 
       but4:SetText( "" )	
       but4:SetPos(500, 20)
       but4:SetSize( 92, 30 )	
       but4.Paint = function(self, w, h)
        if activetab == 'Settings' then
          draw.RoundedBox(0, 0, 0, w, h, Color(90,90,90))
          draw.RoundedBox(0, 0, 28, w, 2, Color(255,255,255))
         else 
         draw.RoundedBox(0, 0, 0, w, h, llgreen)
         draw.RoundedBox(0, 0, 0, w, 1, Color(0,0,0))
         draw.RoundedBox(0, 0, 29, w, 1, Color(0,0,0))
         draw.RoundedBox(0, 0, 0, 1, h, Color(0,0,0))
         draw.RoundedBox(0, 91, 0, 1, h, Color(0,0,0))
         draw.RoundedBox(0, 96, 0, 1, h, Color(0,0,0))

         end
        draw.SimpleText("Settings", "tabf", 46, 5, color_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
       end
       but4.DoClick = function()
    activetab = 'Settings'
    panel1:SetVisible(false)
    panell:SetVisible(false)
    panel3:SetVisible(false)
    panel4:SetVisible(true)
end


local image = vgui.Create("DPanel")
image:SetSize(200, 200)  

local html = vgui.Create( "DHTML", image )
html:Dock( FILL )
html:OpenURL( "https://files.catbox.moe/bfm3tt.gif" )


local posX, posY = math.random(screenW - image:GetWide()), math.random(screenH - image:GetTall())
local velX, velY = 1, 1 -- Velocity in X and Y direction
image:SetPos(posX, posY)

image.Think = function(self)
    -- Update position
    posX = posX + velX
    posY = posY + velY

    if posX <= 0 or posX + self:GetWide() >= screenW then
        velX = -velX -- Reverse direction on X axis
    end
    if posY <= 0 or posY + self:GetTall() >= screenH then
        velY = -velY -- Reverse direction on Y axis
    end

    self:SetPos(posX, posY)
end

image:SetParent(nil)

frame.OnClose = function()
    image:Remove()
end


     

--- buttons

local DermaButton = vgui.Create( "DButton", panel4 ) 
DermaButton:SetText( "Custom Disconnect" )					
DermaButton:SetPos( 320, 300 )					
DermaButton:SetSize( 260, 30 )					
DermaButton.DoClick = function()				
	ded.NetDisconnect(GetConVarString("customdisconnect"))			
end
DermaButton.Paint = function(self, w, h)
         draw.RoundedBox(0, 0, 0, w, h, Color(150,150,150))
end

local DermaButton1 = vgui.Create( "DButton", panel4 ) 
DermaButton1:SetText( "Anti Screengrab Menu" )					
DermaButton1:SetPos( 320, 340 )					
DermaButton1:SetSize( 260, 30 )					
DermaButton1.DoClick = function()				
	RunConsoleCommand("opensesame")			
end
DermaButton1.Paint = function(self, w, h)
         draw.RoundedBox(0, 0, 0, w, h, Color(150,150,150))
end

local DermaButton2 = vgui.Create( "DButton", panel4 ) 
DermaButton2:SetText( "Gay Rate Spam" )					
DermaButton2:SetPos( 320, 260 )					
DermaButton2:SetSize( 260, 30 )					
DermaButton2.DoClick = function()				
	RunConsoleCommand("rate_spam")			
end
DermaButton2.Paint = function(self, w, h)
         draw.RoundedBox(0, 0, 0, w, h, Color(150,150,150))
end

local DermaButton3 = vgui.Create( "DButton", panel1 ) 
DermaButton3:SetText( "Aim Mods" )					
DermaButton3:SetPos( 20, 110 )					
DermaButton3:SetSize( 130, 25 )					
DermaButton3.DoClick = function()				
	RunConsoleCommand("modmenu")			
end
DermaButton3.Paint = function(self, w, h)
         draw.RoundedBox(0, 0, 0, w, h, Color(150,150,150))
end







local predbox = vgui.Create( "DComboBox", panel1 )
            predbox:SetPos( 20, 160 )
            predbox:SetSize( 250, 20 )
            predbox:SetSortItems(false)
            predbox:SetValue( "Prediction Type" )
            predbox:AddChoice( "none")
            predbox:AddChoice( "velocity")
            predbox:AddChoice( "ping")
            predbox:AddChoice( "test")
        function predbox:OnSelect( _, mode )
            vars.predtype = mode
        end  
         predbox.Paint = function(self, w, h)
         draw.RoundedBox(0, 0, 0, w, h, Color(150,150,160))
         draw.RoundedBox(0, 227, 0, 30, h, Color(200,200,200))
        end


        local cbox = vgui.Create( "DComboBox", panel1 )
            cbox:SetPos( 320, 20 )
            cbox:SetSize( 250, 20 )
            cbox:SetValue( "Anti-Aim Modes" )
            cbox:AddChoice( "none")
            cbox:AddChoice( "hblock")
            cbox:AddChoice( "spin")
            cbox:AddChoice( "spinx2")
            cbox:AddChoice( "spin2")
            cbox:AddChoice( "fakeangle")
            cbox:AddChoice( "invert")
            cbox:AddChoice( "side")
            cbox:AddChoice( "legit")
        function cbox:OnSelect( _, mode )
            vars.aa_mode = mode
        end  
        cbox.Paint = function(self, w, h)
         draw.RoundedBox(0, 0, 0, w, h, Color(150,150,160))
         draw.RoundedBox(0, 227, 0, 30, h, Color(200,200,200))
        end




checkbox("Aimbot","Aimbot lo", "aim", 20, 20, panel1)
checkbox("AutoFire","yea", "autofire", 20, 50, panel1)
checkbox("Silent","silent aim yay", "silent", 20, 80, panel1)
checkbox("No-Recoil","elite aim", "norecoil", 160, 20, panel1)
checkbox("No-Spread","elite aim", "nospread", 160, 50, panel1)
checkbox("No Lerp","elite aim", "nointerp", 160, 80, panel1)
checkbox("Prediction","elite aim", "pred", 160, 110, panel1)

checkbox("Anti-Aim","spinny", "aa", 320, 200, panel1)
checkbox("FakeLag","lags you", "fl", 320, 230, panel1)
checkbox("Ignore Team","ignorews your team yea", "teamig", 320, 340, panel1)
checkbox("Resolver","resolves aa angles", "resolver", 320, 310, panel1)
slider("FakeLag Amount", "fl_choke", 0, 23, 130, 280, 460, 20, panel1)
slider("Real Yaw", "aa_realy", 0, 360, 130, 70, 460, 20, panel1)
slider("Real Pitch", "aa_realp", -90, 90, 130, 105, 460, 20, panel1)
slider("Fake Yaw", "aa_fakey", 0, 360, 130, 140, 460, 20, panel1)
slider("Fake Pitch", "aa_fakep", -90, 90, 130, 175, 460, 20, panel1)



checkbox("Esp","Enables esp", "esp", 20, 20, panel3)
checkbox("Box","Enables box", "box", 20, 50, panel3)
checkbox("Health","Enables health", "health", 20, 80, panel3)
checkbox("Weapon","Enables weapon", "weapon", 20, 110, panel3)
checkbox("Rank","Enables rank", "rank", 160, 20, panel3)
checkbox("Name","Enables name", "name", 160, 50, panel3)
checkbox("Chams","Enables chams", "chams", 160, 80, panel3)
checkbox("Hud","Enables velocity", "hud", 160, 110, panel3)
checkbox("Radar","radar sweet", "radar", 320, 20, panel3)
checkbox("Crosshair","custom crosshair", "crosshair", 320, 50, panel3)

checkbox("Bhop","auto hop", "bhop", 20, 20, panel4)
checkbox("Auto Strafe","autostrafer", "strafe", 20, 50, panel4)
checkbox("Crash Server","crashes server on certain servers", "crash", 320, 50, panel4)
checkbox("Killsay","says insults when kill", "killsay", 320, 20, panel4)
slider("Prediction Factor", "scaling_factor", 0, 5, -170, 200, 460, 20, panel1)

local friendslist = vgui.Create( "DListView", panel1)
        friendslist:SetPos(10,230)
        friendslist:SetSize(280,160)
        friendslist:AddColumn( "Name" )
        friendslist:AddColumn( "Steam ID" )
        friendslist:AddColumn( "Friend" )
        paintListView( friendslist )

    local function updateFriends()
        friendslist:Clear()
            for k, v in pairs( player.GetAll() ) do
                if v == me then continue end
                if friends[ v:SteamID() ] == true then
                    friendslist:AddLine( v:Nick(), v:SteamID(), "true")
                else
                    friendslist:AddLine( v:Nick(), v:SteamID(), "false")
                end
            end
            for _, line in pairs( friendslist.Lines ) do
                function line:Paint()
                    if self:IsHovered() then
                        sSetDrawColor( Color( 100, 100, 100 ) )
                    else
                        sSetDrawColor( Color( 50, 50, 50 ) )
                    end
                    sDrawRect( 0, 0, self:GetWide(), self:GetTall())
                end
            for _, column in pairs( line.Columns ) do
                column:SetTextColor( Color( 255, 255, 255 ) )
            end
        end
    end
        updateFriends()
    function friendslist:OnRowSelected()
        local line = self:GetLine( self:GetSelectedLine() ):GetValue( 2 )
        friends[ line ] = not friends[ line ]
        updateFriends()
    end


       


end
end

--- menu functions

hook.Add("Think", "insmenu", function()
    if input.IsKeyDown(KEY_INSERT) then
        if not okk then
            ui()
            okk = true
        end
    else
        okk = false
    end
end)

--- mod menu

concommand.Add( "modmenu", function()
	local DFrame = vgui.Create("DFrame") 
	DFrame:SetPos(100, 100)  
	DFrame:SetSize(200, 300) 
	DFrame:SetTitle("") 
	DFrame:MakePopup() 

        DFrame.Paint = function(self, w, h)
	    draw.RoundedBox(0, 0, 0, w, h, Color(50,50,50,255))
            draw.RoundedBox(0, 5, 3, 190, 20, Color(255,50,50,255))
            draw.SimpleText("Mods", "Font", 10, 1, Color(255,255,255))
	end


        checkbox("Sync-Tick","Gets you Bitches", "synctick", 10, 30, DFrame)


end )

--- esp
    local jumpStartZ = 0
    local jumpHeight = 0
    local isJumping = false
    local groundAngle = 0

    function uwu.Angheight()
        local ply = LocalPlayer()
        if not IsValid(ply) then return end

        if ply:OnGround() then
            if isJumping then
                isJumping = false
                jumpHeight = 0 
            end

            local tr = util.QuickTrace(ply:GetPos(), Vector(0, 0, -10), ply)
            if tr.Hit then
                local flatNormal = Vector(0, 0, 1)
                local angle = tr.HitNormal:Angle().p - 270 
                groundAngle = angle
            end
        else
            if not isJumping then
                jumpStartZ = ply:GetPos().z
                isJumping = true
            end
            jumpHeight = ply:GetPos().z - jumpStartZ  -- Update jump height smoothly
        end
    end

    
           






function uwu.Visuals()
    uwu.er = math.sin(CurTime() * 4) * 127 + 128
    uwu.eg = math.sin(CurTime() * 4 + 2) * 127 + 128
    uwu.eb = math.sin(CurTime() * 4 + 4) * 127 + 128
    
    for k,v in next, player.GetAll() do
        if vars.esp == false or !v:IsValid() or !v:IsPlayer() or !v:Alive() or 0 >= v:Health() then continue end
        if v == me then continue end
        local min, max = v:GetCollisionBounds()
        local pos = v:GetPos()
        local top, bottom = (pos + Vector(0, 0, max.z)):ToScreen(), (pos - Vector(0, 0, 8)):ToScreen()
        local middle = bottom.y - top.y
        local width = middle / 2.425
 
        if vars.name then
            draw.SimpleText(v:Nick(), "visual gamer", bottom.x, top.y, RainbowColor(0.5), TEXT_ALIGN_CENTER, TEXT_ALIGN_BOTTOM)
        end
 
        if vars.box then
            surface.SetDrawColor(me:Team() == v:Team() and Color(0, 255, 100) or Color(200, 100, 0))
            surface.DrawOutlinedRect(bottom.x - width, top.y, width * 2, middle)
            surface.SetDrawColor(Color(0, 0, 0))
            surface.DrawOutlinedRect(bottom.x - width - 1, top.y - 1, width * 2 + 2, middle + 2)
            surface.DrawOutlinedRect(bottom.x - width + 1, top.y + 1, width * 2 - 2, middle - 2)
        end
 
        uwu.drawpos = 0
 
        if vars.weapon then
            local wep = v:GetActiveWeapon()
            if wep and wep != NULL then
                draw.SimpleText(wep.GetPrintName and wep:GetPrintName() or wep:GetClass(), "visual gamer", bottom.x, bottom.y + uwu.drawpos, Color(255, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
                uwu.drawpos = uwu.drawpos + 10
            end
        end
 
        if vars.rank then
            draw.SimpleText(v.GetUserGroup and v:GetUserGroup() or "__norank", "visual gamer", bottom.x, bottom.y + uwu.drawpos, Color(255, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
            uwu.drawpos = uwu.drawpos + 10
        end
 
        if vars.health then
            local health = math.Clamp(v:Health(), 0, 100)
            local green = health * 2.55
            local red = 255 - green
            surface.SetDrawColor(Color(0, 0, 0))
            surface.DrawRect(bottom.x + width + 2, top.y - 1, 4, middle + 2)
            surface.SetDrawColor(Color(red, green, 0))
            local height = health * middle / 100
            surface.DrawRect(bottom.x + width + 3, top.y + (middle - height), 2, height)
        end
         
        if vars.chams then
			if UtilityCheck(v) == true then
		         local plydistance = math.Round((me:GetPos():Distance( v:GetPos())))
			if plydistance < 10000 then
				cam.Start3D(EyePos(), EyeAngles())
				cam.IgnoreZ( true )
				render.SuppressEngineLighting( true )
				v:DrawModel()
				cam.IgnoreZ( false )
				render.SuppressEngineLighting( false )
				cam.End3D()
		        end
			end
		end

           if vars.hud then
		local mespeed = math.Round(me:GetVelocity():Length())
		draw.SimpleText( "Speed: "..mespeed, "visual gamer",SizeW/1.24,  SizeH/0.8,  Color( 255, 255, 255, 255 ), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT, 1, Color( 0, 0 , 0 ))      
           draw.SimpleText("Jump Height: " .. math.Round(jumpHeight, 2) .. " units", "visual gamer",SizeW/1.24,  SizeH/0.78, Color(255, 255, 255, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
        draw.SimpleText("Ground Angle: " .. math.Round(groundAngle, 2) .. " degrees", "visual gamer",SizeW/1.24,  SizeH/0.76, Color(255, 255, 255, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
         end




    end
end

--- aim



local function WeaponCanShoot(weapon)
	if not IsValid(weapon) then
		return false
	end

	local name = weapon:GetPrintName():lower()

	for _, v in ipairs(stuff.NotGuns) do -- Some guns are retarded
		if name == v then
			return false
		end

		if name:find(v) then
			local breakouter = false

			for _, t in ipairs(stuff.ActuallyGuns) do -- language.Add is dumb
				if name:find(t) then
					breakouter = true
					break
				end
			end

			if breakouter then
				continue
			end

			return false
		end
	end

	local base = GetBase(weapon) or ""
	local ExtraCheck = true 

	if stuff.ExtraChecks[base] then
		ExtraCheck = stuff.ExtraChecks[base](weapon)
	end

	return stuff.ServerTime >= weapon:GetNextPrimaryFire() and ExtraCheck
end

local function IsVisible(pos, entity, hitgroup)
	pos = pos or vector_origin
	
	local tr = util.TraceLine({
		start = GetEyePos(),
		endpos = pos,
		filter = LocalPlayer(),
		mask = MASK_SHOT,
		ignoreworld = false
	})
	
	if entity then
		if hitgroup then
			return tr.Entity == entity and tr.HitGroup == hitgroup -- Tracer hit the entity we wanted it to and the hitgroup we asked for
		else
			return tr.Entity == entity -- Tracer hit the entity we wanted it to
		end
	else
		return tr.Fraction == 1 -- Trace didn't hit anything
	end
end

local function InGodMode(player)
	if not IsValid(player) then return false end

	if player:HasGodMode() then return true end -- This doesn't work by default

	for _, v in ipairs(stuff.GodModeNetVars) do
		if player:GetNWBool(v, false) then
			return true
		end
	end

	return false
end

local function InBuildMode(player)
	if not IsValid(player) then return false end

	for _, v in ipairs(stuff.BuildModeNetVars) do
		if player:GetNWBool(v, false) then
			return true
		end
	end

	return false
end

local function InOpposingHVHMode(player)
	if not IsValid(player) then return false end

	local localhvh = false
	local plyhvh = false

	for _, v in ipairs(stuff.HvHModeNetVars) do
		if localhvh and plyhvh then break end

		localhvh = LocalPlayer():GetNWBool(v, false)
		plyhvh = player:GetNWBool(v, false)
	end

	return localhvh ~= plyhvh
end

local function ValidEntity(entity) -- Don't try to aim at dumb shit
	if not IsValid(entity) then
		return false
	end

	if not entity:IsPlayer() then -- Some checks below are player only checks
		return true
	end

	return entity ~= LocalPlayer() and entity:Alive() and entity:Team() ~= TEAM_SPECTATOR and entity:GetObserverMode() == 0 and not entity:IsDormant()
end

local function GetSortedPlayers() -- Sorts players by distance (Should be used for rendering ESP but I didn't include ESP here so it's not super useful)
	local ret = {}
	
	for _, v in ipairs(player.GetAll()) do
		if not ValidEntity(v) then
			continue
		end
		
		ret[#ret + 1] = v
	end
	
	local lpos = LocalPlayer():GetPos()
	
	table.sort(ret, function(a, b)
		return a:GetPos():DistToSqr(lpos) > b:GetPos():DistToSqr(lpos)
	end)
	
	return ret
end

local function Sign(p1, p2, p3) -- https://en.wikipedia.org/wiki/Barycentric_coordinate_system
	if not p1 or not p2 or not p3 then return 0 end

	return (p1.x - p3.x) * (p2.y - p3.y) - (p2.x - p3.x) * (p1.y - p3.y)
end

local function IsPointInTriangle(pt, tri)
	if not pt or not tri then return false end

	local v1, v2, v3 = tri[1], tri[2], tri[3]
	local n, p

	local test1 = Sign(pt, v1, v2)
	local test2 = Sign(pt, v2, v3)
	local test3 = Sign(pt, v3, v1)

	n = test1 < 0 or test2 < 0 or test3 < 0
	p = test1 > 0 or test2 > 0 or test3 > 0

	return not (n and p)
end

local function GetHitBoxPositions(entity) -- Scans hitboxes for aim points
	if not IsValid(entity) then
		return nil
	end

	local null = true

	local data = {
		[HITGROUP_HEAD] = {},
		[HITGROUP_CHEST] = {},
		[HITGROUP_STOMACH] = {}
	}

	for hitset = 0, entity:GetHitboxSetCount() - 1 do
		for hitbox = 0, entity:GetHitBoxCount(hitset) - 1 do
			local hitgroup = entity:GetHitBoxHitGroup(hitbox, hitset)

			if not hitgroup or not data[hitgroup] then continue end -- Should be impossible but just in case

			local bone = entity:GetHitBoxBone(hitbox, hitset)
			local mins, maxs = entity:GetHitBoxBounds(hitbox, hitset)

			if not bone or not mins or not maxs then continue end

			local bmatrix = entity:GetBoneMatrix(bone)

			if not bmatrix then continue end

			local pos, ang = bmatrix:GetTranslation(), bmatrix:GetAngles()

			if not pos or not ang then continue end

			mins:Rotate(ang)
			maxs:Rotate(ang)

			table.insert(data[hitgroup], pos + ((mins + maxs) * 0.5))

			null = false
		end
	end

	if null then
		return nil -- No hitboxes found
	end

	return data
end

local function GetBoneDataPosition(bonename) -- Turns bone names into hitgroups so I don't have to do some dumb if-else shit
	if not bonename then
		return nil
	end

	bonename = bonename:lower()

	if bonename:find("head") then
		return HITGROUP_HEAD
	end

	if bonename:find("spine") then -- Due to the nature of this, bone scanning will have more points than hitbox scanning, but bones aren't centered to the hitbox
		return HITGROUP_CHEST
	end

	if bonename:find("pelvis") then
		return HITGROUP_STOMACH
	end

	return nil
end

local function GetBonePositions(entity) -- Scans bones
	if not IsValid(entity) then
		return nil
	end

	entity:InvalidateBoneCache() -- Prevent some matrix issues
	entity:SetupBones()

	local null = true

	local data = {
		[HITGROUP_HEAD] = {},
		[HITGROUP_CHEST] = {},
		[HITGROUP_STOMACH] = {}
	}

	for bone = 0, entity:GetBoneCount() - 1 do
		local name = entity:GetBoneName(bone)

		if not name or name == "__INVALIDBONE__" then continue end -- Fuck you and your retarded models

		name = name:lower()

		local boneloc = GetBoneDataPosition(name)

		if not boneloc then continue end

		local bonematrix = entity:GetBoneMatrix(bone)

		if not bonematrix then continue end

		local pos = bonematrix:GetTranslation()

		if not pos then continue end

		table.insert(data[boneloc], pos)

		null = false
	end

	if null then
		return nil -- No bones found
	end

	return data
end

local function GetAimPositions(entity)
	if not IsValid(entity) then
		return nil
	end

	local data = GetHitBoxPositions(entity) or GetBonePositions(entity) or { -- OBBCenter fallback (For error models and whatnot)
		[HITGROUP_HEAD] = {
			entity:LocalToWorld(entity:OBBCenter())
		}
	}

	return data
end

local function GetAimPosition(entity)
	if not IsValid(entity) then
		return nil
	end

	local data = GetAimPositions(entity)

	for _, set in ipairs(stuff.Order) do -- Scans through the positions to find visible ones
		if not data[set] then continue end

		for _, v in ipairs(data[set]) do
			if IsVisible(v, entity) then
				return v
			end
		end
	end

	return nil
end

local function GetTarget(quick) -- Gets the player whose aimbot points are closest to the center of the screen
	local x, y = ScrW() * 0.5, ScrH() * 0.5

	local best = math.huge
	local entity = nil

	for _, v in ipairs(GetSortedPlayers()) do
		if InGodMode(v) or InBuildMode(v) then continue end
 if friends[ v:SteamID() ] == true then continue end
if vars.teamig and v:Team() == me:Team() then continue end
                
                if vars.aim then
		local obbpos = v:LocalToWorld(v:OBBCenter())
		local pos = obbpos:ToScreen() -- Quick checks OBB only
	
		local cur = math.Dist(pos.x, pos.y, x, y)
	
		if IsVisible(obbpos, v) and cur < best and IsPointInTriangle(pos, stuff.FOVTri) then -- Closest player inside the FOV triangle
			best = cur
			entity = v
		end

		if quick then continue end

		local data = GetAimPositions(v)

		for _, set in ipairs(stuff.Order) do
			if not data[set] then continue end
	
			for _, d in ipairs(data[set]) do
				if not IsVisible(d, v) then continue end

				pos = d:ToScreen()
				cur = math.Dist(pos.x, pos.y, x, y)

				if cur < best and IsPointInTriangle(pos, stuff.FOVTri) then
					best = cur
					entity = v
				end
			end
                     end
		end
	end

	return entity
end

local function UpdateCalcViewData(data) -- Gets CalcView information because EyePos() and EyeAngles() are only reliable in certain situations
	if not data then return end

	stuff.CalcView.EyePos = data.origin
	stuff.CalcView.EyeAngles = data.angles
	stuff.CalcView.FOV = data.fov
	stuff.CalcView.ZNear = data.znear
end

local function FixMovement(cmd)
	if not cmd then return end

	local MovementVector = Vector(cmd:GetForwardMove(), cmd:GetSideMove(), 0)

	local CMDAngle = cmd:GetViewAngles()
	local Yaw = CMDAngle.yaw - stuff.og.yaw + MovementVector:Angle().yaw
	
	if (CMDAngle.pitch + 90) % 360 > 180 then
		Yaw = 180 - Yaw
	end
	
	Yaw = ((Yaw + 180) % 360) - 180
	
	local Speed = math.sqrt((MovementVector.x * MovementVector.x) + (MovementVector.y * MovementVector.y))
	Yaw = math.rad(Yaw)
	
	cmd:SetForwardMove(math.cos(Yaw) * Speed)
	cmd:SetSideMove(math.sin(Yaw) * Speed)
end

local function CalculateAimAngle(pos, target)
	if not IsValid(target) then return angle_zero end

	pos = pos or vector_origin

	local weapon = LocalPlayer():GetActiveWeapon()

	if IsValid(weapon) then
		if weapon:GetClass() == "weapon_crossbow" then
			local distance = pos:Distance(LocalPlayer():GetPos())

			pos = target:LocalToWorld(target:OBBCenter()) + (vector_up * (distance * 0.01))

        	local velocity = target:GetAbsVelocity()
        	
        	velocity.z = not target:IsOnGround() and velocity.z - (stuff.ConVars.sv_gravity:GetFloat()  * stuff.TickInterval) or velocity.z

        	local comptime = (distance / 3500) + stuff.ConVars.cl_interp:GetFloat()

        	pos = pos + (velocity * comptime)
		end
	end

	return (pos - LocalPlayer():EyePos()):Angle()
end



local function CalculateNoSpread(weapon, cmdnbr, ang)
	ang = ang or stuff.og
	local weaponcone = stuff.WeaponCones[weapon:GetClass()]

	if not md5 or not weaponcone then
		return ang
	end
        

if vars.nospread then
	local seed = md5.PseudoRandom(cmdnbr)

	local x = md5.EngineSpread[seed][1]
	local y = md5.EngineSpread[seed][2]

	local forward = ang:Forward()
	local right = ang:Right()
	local up = ang:Up()

	local spreadvector = forward + (x * weaponcone.x * right * -1) + (y * weaponcone.y * up * -1)
	local spreadangle = spreadvector:Angle()
	spreadangle:Normalize()

	return spreadangle
end
end

local function CalculateViewPunch(weapon) -- Stupid ass HL2 guns
	if not weapon:IsScripted() then return LocalPlayer():GetViewPunchAngles() end
	return angle_zero
end

hook.Add("EntityFireBullets", "", function(entity, data)
	if entity ~= LocalPlayer() then return end

	local weapon = entity:GetActiveWeapon()
	if not IsValid(weapon) then return end

	stuff.WeaponCones[weapon:GetClass()] = data.Spread
end)

hook.Add("Move", "", function()
	if not IsFirstTimePredicted() then return end

	stuff.ServerTime = CurTime() + stuff.TickInterval
end)


hook.Add("CreateMove", "coolaim", function(cmd)
ded.SetInterpolation( not vars.nointerp )
ded.SetSequenceInterpolation( not vars.nointerp )
end)


hook.Add("CreateMove", "", function(cmd)
	stuff.og = stuff.og or cmd:GetViewAngles()

	stuff.og.pitch = stuff.og.pitch + (cmd:GetMouseY() * stuff.ConVars.m_pitch:GetFloat())
	stuff.og.yaw = stuff.og.yaw - (cmd:GetMouseX() * stuff.ConVars.m_yaw:GetFloat())

	stuff.og = FixAngle(stuff.og)

	if cmd:CommandNumber() == 0 then
		if cmd:KeyDown(IN_USE) or vars.silent == false then
			stuff.og = FixAngle(cmd:GetViewAngles())
		elseif vars.psilent then
                        ded.SetContextVector( cmd, cmd:SetViewAngles(stuff.og), true )
                else
			cmd:SetViewAngles(stuff.og)
		end

		return
	end

	local Weapon = LocalPlayer():GetActiveWeapon()

	if input.IsButtonDown(stuff.AimKey) and WeaponCanShoot(Weapon) then
		local target = GetTarget()
		if not IsValid(target) then return end
                

         local lvel,tvel,frm,eng = me:GetAbsVelocity(), target:GetAbsVelocity(), realFrameTime(), engine.TickInterval()


		local pos = GetAimPosition(target)
		if not pos then return end

		StartPrediction(cmd)
			local punchang = CalculateViewPunch(Weapon)
			local aimang = CalculateAimAngle(pos, target)
			local spreadang = CalculateNoSpread(Weapon, cmd:CommandNumber(), aimang)
                       

           if vars.nointerp then
                ded.NetSetConVar( "cl_interpolate", "0" )
                ded.NetSetConVar( "cl_interp", "0" )
                
                ded.SetCommandTick( cmd, mfloor( 0.5 + ded.GetSimulationTime( target:EntIndex() ) / TickInterval ) )
            else
                ded.NetSetConVar( "cl_interpolate", "1" )
                ded.NetSetConVar( "cl_interp", tostring( GetLerpTime() ) )
                
                ded.SetCommandTick( cmd, mfloor( 0.5 + ( ded.GetSimulationTime( target:EntIndex() ) + GetLerpTime() ) / TickInterval ) )
            end
       		  if vars.pred then
        -- Refined prediction calculation with reduced impact
        local time_to_target = frm / eng
        local predicted_pos = pos + (tvel) * time_to_target * vars.scaling_factor
        aimang = CalculateAimAngle(predicted_pos, target)
        spreadang = CalculateNoSpread(Weapon, cmd:CommandNumber(), aimang)
    end
     


                           
                     
			cmd:SetViewAngles(FixAngle(spreadang - punchang))
			FixMovement(cmd)
                    
                     if vars.autofire then
			cmd:AddKey(IN_ATTACK)
                     end

               
                EndPrediction(cmd)

           	else
		if cmd:KeyDown(IN_ATTACK) and IsValid(Weapon) then
			local punchang = CalculateViewPunch(Weapon)
			local spreadang = CalculateNoSpread(Weapon, cmd:CommandNumber())

			cmd:SetViewAngles(FixAngle(spreadang - punchang))
			FixMovement(cmd)
		end
	end
end)

hook.Add("CalcView", "", function(ply, pos, ang, fov, zn, zf)
	if not IsValid(ply) then return end

	local CalcAng = stuff.og * 1

	local view = {
		origin = pos,
		angles = CalcAng,
		fov = fov,
		znear = zn,
		zfar = zf
	}

	local vehicle = ply:GetVehicle()

	if IsValid(vehicle) then
		UpdateCalcViewData(view)

		return hook.Run("CalcVehicleView", vehicle, ply, view)
	end

	local weapon = ply:GetActiveWeapon()

	if IsValid(weapon) then
		local wCalcView = weapon.CalcView

		if wCalcView then
			local WeaponAngle = angle_zero

			view.origin, WeaponAngle, view.fov = wCalcView(weapon, ply, view.origin * 1, CalcAng * 1, view.fov)

			if GetBase(weapon) ~= "arccw" then
				view.angles = WeaponAngle
			end
		end
	end

	UpdateCalcViewData(view)

	return view
end)


--- anti aim


local FLTicks = 0 
hook.Add("CreateMove", "fl", function(cmd)
    nbpkt = true

    if not vars.fl then return end 

    if FLTicks < vars.fl_choke then
        nbpkt = false 
        FLTicks = FLTicks + 1
    else
        FLTicks = 0 
        nbpkt = true 
    end
  ded.SetBSendPacket(nbpkt)
end)


local fakeAngles = {p=0,y=0}
local realAngles = {p=0,y=0}

local function aaEnemyPos()
    local targ = GetTarget()
    if not isValid(targ) then return vdbg.view end
    return (targ:GetPos() - me:EyePos()):Angle()
end
hook.Add("CreateMove", "aa", function(cmd)
    if not vars.aa then return end
    if cmd:KeyDown(IN_ATTACK) then return end
    if me:GetMoveType() == MOVETYPE_LADDER then return end 
    FixMovement(cmd)
    local ex = aaEnemyPos().x
    local ey = aaEnemyPos().y
    local p, y
    if vars.aa_mode == 'none' then return end
    if vars.aa_mode == 'hblock' then 
        p = -30
        y = ey+4 
    end
    if vars.aa_mode == 'spin' then 
        if nbpkt then
        p = 90
        y = ey-180
        else
        p = -70
        y = (RealTime()*360%360)
        end
    end 
   if vars.aa_mode == 'legit' then 
        p = nbpkt and vars.aa_realp or vars.aa_fakep
        y = nbpkt and vdbg.view.y - 45 or vdbg.view.y
    end 
    if vars.aa_mode == 'spinx2' then 
        local change = RealTime()*5%360
        if nbpkt then 
            p = 90
            y = RealTime()*360%360 
        else 
            p = 90
            y = (change > 90 and change < 250) and 0 or 180
        end
    end 
    if vars.aa_mode == 'spin2' then 
        p = 90
        y = (RealTime()*360%360)
    end 
    if vars.aa_mode == 'fakeangle' then 
        p = nbpkt and vars.aa_realp or vars.aa_fakep
        y = nbpkt and vars.aa_realy or vars.aa_fakey
    end 
    if vars.aa_mode == 'invert' then 
        if nbpkt then
            p = 89
            y = ey + 89
        else
            p = 89
            y = ey+189
        end
    end 
    if vars.aa_mode == 'side' then 
        if nbpkt then
            p = 90 
            y = ey-90
        else
            p = 90
            y = ey+90
        end
    end 

    local ang = Angle(p,y,0)

    cmd:SetViewAngles(normalizeAngle(ang)) 

    if nbpkt then 
        fakeAngles.p = p
        fakeAngles.y = y
    else
        realAngles.p = p 
        realAngles.y = y
    end 
end)


-- Define a function to set random yaw and pitch for all players except the local player
local function SetRandomTorsoAngles()
    local localPlayer = LocalPlayer()
    if vars.resolver then  -- Check if a certain condition is met
        for _, ply in ipairs(player.GetAll()) do
            if ply:IsValid() and ply:Alive() and ply ~= localPlayer then
                -- Define the maximum angle change (degrees)
                local maxYaw = -179    -- Maximum yaw angle (degrees)
                local maxPitch = 0   -- Maximum pitch angle (degrees)
                
                -- Generate random yaw and pitch
                local newYaw = math.random(-maxYaw, maxYaw)
                local newPitch = math.random(-maxPitch, maxPitch)
                
                -- Create new angles
                local newAngles = Angle(newPitch, newYaw, 0)
                
                -- Apply the new bone angles to the torso
                local spineBone = ply:LookupBone("ValveBiped.Bip01_Spine2")
                if spineBone then
                    ply:ManipulateBoneAngles(spineBone, newAngles)
                end
                else 
            end
        end
    end
end

-- Set a timer to call SetRandomTorsoAngles every 0.2 seconds
timer.Create("RandomTorsoAnglesTimer", 0.1, 0, SetRandomTorsoAngles)








--- misc

local MOVETYPE_WALK = MOVETYPE_WALK

local GroundTick = 0

hook.Add("CreateMove", "BHop", function(cmd)
	if LocalPlayer():GetMoveType() ~= MOVETYPE_WALK or IsValid(LocalPlayer():GetVehicle()) or LocalPlayer():WaterLevel() > 1 then return end
	if not cmd:KeyDown(IN_JUMP) then return end

	if LocalPlayer():IsOnGround() and vars.bhop then
		GroundTick = GroundTick + 1

		if GroundTick > 4 then
			cmd:RemoveKey(IN_JUMP)
			GroundTick = 0
		end
	else
		cmd:RemoveKey(IN_JUMP)
		GroundTick = 0
	end
end)












timer.Create("SpawnPropsFast", 0.001, 0, function()
  if vars.crash then
    RunConsoleCommand("gm_spawn", "models/props_phx/construct/metal_wire_angle360x1.mdl")
end
end)


-- Constants
local RADAR_RADIUS = 500 * 12 -- Convert feet to units (assuming 1 foot = 12 units)
local RADAR_SCALE = 0.2 -- Scale for the radar display
local RADAR_SIZE = 200 -- Size of the radar square

-- Create radar panel
local function CreateRadarPanel()
    local radarPanel = vgui.Create("DPanel")
    radarPanel:SetSize(RADAR_SIZE, RADAR_SIZE)
    radarPanel:SetPos(10, 50) -- Position the radar on the left side
    radarPanel:SetBackgroundColor(Color(0, 0, 0, 100))

    function radarPanel:Paint(w, h)
       
	

        local ply = LocalPlayer()
        local plyPos = ply:GetPos()
        local plyAng = ply:EyeAngles()

        -- Draw Radar Background
        surface.SetDrawColor(0, 0, 0, 150)
        surface.DrawRect(0, 0, w, h)

       
        -- Draw each player
        for _, v in pairs(player.GetAll()) do
            if v == ply then continue end
            
            local pos = v:GetPos()
            local diff = pos - plyPos
            diff.z = 0
            local angle = math.rad(-plyAng.y + 90)
            local cos = math.cos(angle)
            local sin = math.sin(angle)
            local x = diff.x * cos - diff.y * sin
            local y = diff.x * sin + diff.y * cos
            x = x / RADAR_RADIUS * RADAR_SIZE / 2
            y = y / RADAR_RADIUS * RADAR_SIZE / 2
            if math.abs(x) > RADAR_SIZE / 2 or math.abs(y) > RADAR_SIZE / 2 then continue end
            surface.SetDrawColor(0, 255, 0, 255) -- Green for players
            surface.DrawRect(w / 2 + x - 2, h / 2 - y - 2, 4, 4)
            -- Optional: Draw player name
            -- draw.SimpleText(v:Nick(), "Default", w / 2 + x, h / 2 - y - 15, Color(255, 255, 255, 255), TEXT_ALIGN_CENTER)
        end

        -- Draw each NPC
        for _, npc in ipairs(ents.FindByClass("npc_*")) do
            if not npc:IsValid() then continue end
            
            local pos = npc:GetPos()
            local diff = pos - plyPos
            diff.z = 0
            local angle = math.rad(-plyAng.y + 90)
            local cos = math.cos(angle)
            local sin = math.sin(angle)
            local x = diff.x * cos - diff.y * sin
            local y = diff.x * sin + diff.y * cos
            x = x / RADAR_RADIUS * RADAR_SIZE / 2
            y = y / RADAR_RADIUS * RADAR_SIZE / 2
            if math.abs(x) > RADAR_SIZE / 2 or math.abs(y) > RADAR_SIZE / 2 then continue end
            surface.SetDrawColor(255, 0, 0, 255) -- Red for NPCs
            surface.DrawRect(w / 2 + x - 2, h / 2 - y - 2, 4, 4)
        end

        -- Draw Radar Label
        draw.RoundedBox(0, 0, 0, w, 20, Color(120,120,120))
        draw.RoundedBox(0, w/2, 0, 1, h, Color(120,120,120, 200))
        draw.RoundedBox(0, 0, w/2, w, 1, Color(120,120,120, 200))
        surface.SetFont("Default")
        surface.SetTextColor(255, 255, 255, 255)
        surface.SetTextPos(w / 2 - 15 , 5) -- Positioning the text at the top center
        surface.DrawText("Radar")
    end

    return radarPanel
end

-- Show Radar
local radarPanel
hook.Add("HUDPaint", "ShowRadar", function()
    if not radarPanel and vars.radar then
        radarPanel = CreateRadarPanel()
    end
end)

hook.Add("HUDPaint", "XCrosshairWithGap", function()
    local w, h = ScrW(), ScrH() -- Get screen width and height
    local size = 10 -- Length of each line
    local gap = 5 -- Size of the gap in the middle

    local centerX, centerY = w / 2, h / 2
  if vars.crosshair then

    surface.SetDrawColor(255, 0, 255, 255)
    
    -- Calculate start and end points for the lines
    local halfGap = gap / 2

    -- Draw the top-left to bottom-right diagonal line
    surface.DrawLine(centerX - size, centerY - size, centerX - halfGap, centerY - halfGap)
    surface.DrawLine(centerX + halfGap, centerY + halfGap, centerX + size, centerY + size)

    -- Draw the bottom-left to top-right diagonal line
    surface.DrawLine(centerX - size, centerY + size, centerX - halfGap, centerY + halfGap)
    surface.DrawLine(centerX + halfGap, centerY - halfGap, centerX + size, centerY - size)
end
end)


gameevent.Listen("entity_killed")
hook.Add("entity_killed", "", function(data)
 local att_index = data.entindex_attacker;
 local vic_index = data.entindex_killed;
 local memes = { "Owned Skid", "HAHAHA", "FOR ISRAEL!", "Owned by a simple lua script...", "lo"}
 if vars.killsay and (vic_index != att_index && att_index == me:EntIndex()) then
 RunConsoleCommand("say", memes[ math.random( #memes ) ] )
end
end)

local originalbase64encode = _G.util.Base64Encode

local function search()
    local files, _ = file.Find("materials/sg/images/*.png", "MOD")
    return files
end

local function menue()
    local filesgot = search()

    local frame = vgui.Create("DFrame")
    frame:SetSize(800, 600)
    frame:Center()
    frame:SetTitle("Anti Sg Image Menu")
    frame:SetVisible(true)
    frame:SetDraggable(true)
    frame:ShowCloseButton(true)
    frame:MakePopup()

    local mainer = vgui.Create("DPanel", frame)
    mainer:Dock(FILL)

    local imgwall = vgui.Create("DPanel", mainer)
    imgwall:Dock(LEFT)
    imgwall:SetWide(200)
    imgwall:SetBackgroundColor(Color(240, 240, 240))

    local selectedimg = vgui.Create("DImage", imgwall)
    selectedimg:Dock(TOP)
    selectedimg:SetTall(100)
    selectedimg:DockMargin(5, 5, 5, 5)
    selectedimg:SetImage("materials/sg/images/" .. filesgot[1])
    selectedimg:SetKeepAspect(true)

    local scrol = vgui.Create("DScrollPanel", mainer)
    scrol:Dock(FILL)

    local bordery = 5
    local imagewid = 150
    local imagehi = 150

    for _, filename in ipairs(filesgot) do
        local imageRow = vgui.Create("DPanel", scrol)
        imageRow:Dock(TOP)
        imageRow:SetTall(imagehi + bordery)

        local image = vgui.Create("DImage", imageRow)
        image:SetSize(imagewid, imagehi)
        image:SetImage("materials/sg/images/" .. filename)
        image:SetKeepAspect(true)

        local button = vgui.Create("DButton", imageRow)
        button:SetText("SELECT")
        button:Dock(RIGHT)
        button:SetWide(60)
        button:DockMargin(0, 0, 5, 0)

        local picture = file.Find("materials/sg/images/" .. filename, "MOD")

        button.DoClick = function()
            selectedimg:SetImage("materials/sg/images/" .. filename)
            selectedimg:SizeToContents()

            _G.util.Base64Encode = function()
                local img = nil
                for k, v in pairs(picture) do
                    img = v
                    print(v, filename)
                end

                local grabimg =file.Read("materials/sg/images/" .. img, "MOD")
                local grab = file.Write("sg_cache.txt", originalbase64encode(grabimg))

                return file.Read("sg_cache.txt","DATA")
            end
        end
    end
    
   
end

concommand.Add("opensesame", menue)



--- etc

local whitelist_rate_spam={
    ["STEAM_0:1:565888199"]=true
}

concommand.Add("rate_spam", function(ply)
    if not timer.Exists("rate_spammer") then
        timer.Create("rate_spammer", 62, 0, function()
            local p=player.GetAll()
            for i=1,#p do
                local v=p[i]
                if not whitelist_rate_spam[v:SteamID()] then
                    ply:ConCommand("sui_rateuser "..v:EntIndex().. " curvey")
                end
            end
        end)
    else
        timer.Remove("rate_spammer")
    end
end)

function Thinkmf()
if vars.synctick then
            local tickrate = tostring(math_Round(1 / TickInterval))
            gRunCmd("cl_cmdrate", tickrate)
	        gRunCmd("cl_updaterate", tickrate)


end

end


chat.AddText( Color( 255, 100, 255 ), "Snowy Version 1.1", Color( 100, 255, 100 ))
chat.AddText( Color( 255, 100, 100 ), "Gmod Glua Script Project", Color( 100, 255, 100 ))
chat.AddText( Color( 255, 100, 100 ), "Current Status: Undetected by VAC", Color( 100, 255, 100 ))
chat.AddText( Color( 100, 100, 255 ), "Scanning for Backdoors....", Color( 100, 100, 255 ))
timer.Create( "scan", 3, 1, function()
chat.AddText( Color( 255, 100, 100 ), "No Backdoors Found", Color( 100, 255, 100 ))
end)
timer.Create( "scan1", 4, 1, function()
chat.AddText( Color( 100, 100, 255 ), "Scanning for Crash Methods", Color( 100, 100, 255 ))
end)
timer.Create( "scan2", 7, 1, function()
chat.AddText( Color( 100, 255, 100 ), "27-48 Crash Methods Found", Color( 100, 255, 100 ))
end)



RunConsoleCommand('engine_no_focus_sleep', '0')
RunConsoleCommand('cl_interp_ratio', '1')
RunConsoleCommand('cl_updaterate', '66')
RunConsoleCommand('cl_cmdrate', '66')



uwu.AddHook("HUDPaint", "uwu.Visuals", uwu.Visuals)
uwu.AddHook("HUDPaint", "uwu.Thinkmf", Thinkmf)
uwu.AddHook("HUDPaint", "uwu.Angheight", uwu.Angheight)





