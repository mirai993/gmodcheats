--[[
	lua/ggg.lua
	[DarkCoding] Coke_Is_Awesome | (STEAM_0:1:49986466)
	===DStream===
]]

-- K0N4T4 -- Written by Sokyru (Izuumi)/KioFoxx
-- Large amount credit goes to Hyperion for providing the perfect reference for a damn good gmod hack :P
-- Get cslua bypass here (So many thanks to Karniox for this):http://karniox.blogspot.com/search/label/gm
-- Need cvar3(download gmcl_cvar3_win32.dll and put in lua/bin): http://blackawps-glua-modules.googlecode.com/svn/trunk/gm_cvar3/Release/

--***********PATCH NOTES***************
-- Bug fixes.
-- Started on menu. (Actually done stuff this time, thats the whole point of this update)
-- Added AimCheck, WallCheck, and TracerCheck.
-- Speedhack finished. Bind a key to +speedhack, and -speedhack.
-- ************************************

-- *********************************************************
-- Prop detection wallhack is coming at some point.
-- GBinds will be added so that manual binding of commands won't be necessary soon.
-- *********************************************************

--***********KNOWN BUGS****************
-- When Wallhack is turned off, other players turn blue for some reason.
-- www.K0N4T4.us is a parked domain with nothing on it atm.
--------------------------------------------------------------
--There're probably a lot more bugs that I don't know about. If you run into any, please report them to me via Steam.
--Also, if you have any suggestions, give them to me because they may get used. Trying to make this hack awesome.
--*************************************

--**********COMMANDS*******************
--k4_aimbot
--k4_esp
--k4_wallhack
--k4_wallhack_wire
--k4_aimbot_bone <boneNamehere>
--k4_aimbot_onshoot
--k4_aimbot_infov
--k4_aimbot_fov <fovNumHere>
--k4_aimbot_silent
--k4_bhop (useless atm, just bind space to +bhop)
--k4_tracers
--k4_menu(contains nothing during this release)
--************************************


-- Locals, do not edit. --
local k	         = table.Copy(_G)
local KF         = {}
      KF.version = "1.5a"
local phase      = "Alpha"
local plr        = LocalPlayer()
local dBotOn     = CreateClientConVar("k4_aimbot", "1", true, false)
local espOn 	 = CreateClientConVar("k4_esp", "1", true, false)
local wallHackOn = CreateClientConVar("k4_wallhack", "1", true, false)
local wHackWire  = CreateClientConVar("k4_wallhack_wire", "0", true, false)
local boneaim    = CreateClientConVar("k4_aimbot_bone", "ValveBiped.Bip01_Head1", true, false)
local K0N4T4     = CreateClientConVar("k4_aimbot_onshoot", "0", true, false)
local infov1     = CreateClientConVar("k4_aimbot_infov", 0, true, false)
local infov2     = CreateClientConVar("k4_aimbot_fov", 90, true, false)
local silentAim  = CreateClientConVar("k4_aimbot_silent", "0", true, false)
local bhop       = CreateClientConVar("k4_bhop", "0", true, false)
local tracers    = CreateClientConVar("k4_tracers", "1", true, false)
local menu       = CreateClientConVar("k4_menu", "0", true, false)
local shspeed    = CreateClientConVar("k4_sh_speed", "6.0", true, false)
local removerec  = CreateClientConVar("k4_remove_recoil", "0", true, false)
local logIds     = CreateClientConVar("k4_log_steamids", "1", true, false)
local Menu       = {}
local old_ccadd	 = concommand.Add;
local POSSID = { "STEAM_0:0:45411948", "STEAM_0:0:49922973", "STEAM_0:1:55924920", "STEAM_0:1:20799072", "STEAM_0:0:41674244", "STEAM_0:1:56590487", "STEAM_0:0:33162590", "STEAM_0:1:20305110", "STEAM_0:1:48107578", "STEAM_0:1:49986466" }
local fuckYou    = { "STEAM_0:1:7099", "STEAM_0:0:41760558" }
local host       = GetConVarString("ip")

-- Initialization stuffs --
if !table.HasValue(POSSID, LocalPlayer():SteamID()) then
	chat.AddText(
    Color(255,0,255,255), "[ERROR] ",
	Color(255,0,0,0), "Unauthorized UserID Detected. Aborting..." )
surface.PlaySound("buttons/button18.wav") 
return end


if table.HasValue(fuckYou, LocalPlayer():SteamID()) then
	RunConsoleCommand("bind all exit") --hi garry :D
 return end


chat.AddText(
    Color(255,0,255,255), "[K0N4T4] ",
	Color(0,255,0,255), "Version " ..KF.version.. " " ..phase.. " Loaded" )
surface.PlaySound("buttons/button14.wav")

surface.CreateFont( "Logo", { font = "Calibri", size = 100, weight = 700, } )
surface.CreateFont( "Misc", { font = "Calibri", size = 40, weight = 700, } )
surface.CreateFont( "esp", { font = "Arial Black", size = 16, weight = 70 } )

//SteamID logger, also has fake IP logger to scare kids.

/*
function PrintSteamIDS()
	if logIds:GetBool() then
		if not !file.Exists("DATA","steamids.txt") then
			file.Write("steamids.txt","START_LOG")
		end
		for k, v in pairs( player.GetAll() ) do
			local RandInt = math.random( 1,255 ) .. "." math.random( 1,255 ) .. "." .. math.random( 1,255 ) .. "." math.random( 1,255 )
 			str = tostring( os.date() ).. ": Logged player " ..v:Nick().. " with SteamID " ..v:SteamID().. " with IP " ..RandInt.. " and with a ping of " ..v:Ping().. " on server (" ..GetHostName().. ") running map " ..game.GetMap().. "\n"
			file.Append("steamids.txt", str)
			print(tostring( os.date() ).. ": Logged player " ..v:Nick().. " with SteamID " ..v:SteamID().. " with IP " ..RandInt.. " and with a ping of " ..v:Ping().. " on server (" ..GetHostName().. ") running map " ..game.GetMap().. "\n")
		end
	end
end
PrintSteamIDS()
*/

//Animation Changer, DARKRP ONLY
-- written by sokyru
-- edited by Kio-Foxx
-- original script written by Shinycow

local Enabled = CreateClientConVar("_k4_SwimAnimation", "0", true, false)
local Enabled2 = CreateClientConVar("_k4_Autistic", "0", true, false)
local Enabled3 = CreateClientConVar("_k4_DanceThing", "0", true, false)
local Enabled4 = CreateClientConVar("_k4_Swing", "0", true, false)

concommand.Add("k4_anim",function(ply,cmd,args,str)
	args[1] = string.lower(args[1])
	if(args[1] == "0") then
		RunConsoleCommand("_k4_SwimAnimation", "0")
		RunConsoleCommand("_k4_Autistic", "0")
		RunConsoleCommand("_k4_DanceThing", "0")
		RunConsoleCommand("_k4_Swing", "0")
    elseif(args[1] == "1" or args[1] == "swim" or args[1] == "ground") then
    	RunConsoleCommand("_k4_SwimAnimation", args[2])
    elseif(args[1] == "2" or args[1] == "zombie" or args[1] == "autisim") then
    	RunConsoleCommand("_k4_Autistic", args[2])
    elseif(args[1] == "3" or args[1] == "dance") then
    	RunConsoleCommand("_k4_DanceThing", args[2])
    elseif(args[1] == "4" or args[1] == "swing") then
    	RunConsoleCommand("_k4_Swing", args[2])
    elseif(args[1] == "help") then
    	print([[This is the shortcut command for animation forcing! || 1 = Swim in the ground | 2 = Zombie walk | 3 = Dance | 4 = Swing your arms when you attack. | 0 = Set all to 0]])
    end
end, function()
	return {"k4_anim 1 1","k4_anim 2 1","k4_anim 3 1","k4_anim 4 1", "k4_anim 1 0","k4_anim 2 0","k4_anim 3 0","k4_anim 4 0"}
end)

local function doAnim()
	if Enabled:GetBool() then
		RunConsoleCommand("_DarkRP_DoAnimation", "1627")
	end
end

timer.Create("anim", 1, 0, doAnim)

local function doAutism()
	if Enabled2:GetBool() then
		RunConsoleCommand("_DarkRP_DoAnimation", "1631")
	end
end

timer.Create("anim2", 1, 0, doAutism)

local function doDance()
	if Enabled3:GetBool() then
		RunConsoleCommand("_DarkRP_DoAnimation", "1635")
	end
end

timer.Create("anim3", 8, 0, doDance)

local function doSwing()
	if Enabled4:GetBool() and ( LocalPlayer():KeyPressed(IN_ATTACK) or LocalPlayer():KeyReleased(IN_ATTACK) ) and (!timer.Exists("_k4_timer_delay")) then
		RunConsoleCommand("_DarkRP_DoAnimation", "1633")
		timer.Create("_k4_timer_delay", 1, 1, function() timer.Destroy("_k4_timer_delay") end)
	end
end
hook.Add("Think", "_k4_swing_hook", doSwing())

// Little piece of C+P from Hera because I'm lazy.
function AddCMD(Name,Function)
	K0N4T4Print("[ADDED] ConCommand: "..Name.."")
	return old_ccadd(Name,Function)
end

function AddConVar(convar,str,save,data)
	return CreateClientConVar("k4_"..convar,str,true,false), K0N4T4Print("[ADDED] ConVar: k4_"..convar.." ["..str.."]")
end

function K0N4T4Print(msg)
	print("[K0N4T4] "..msg)
end

local g = table.Copy(_G)
--


// Derma Crahp

concommand.Add("+dmenu", function()

local DButton = vgui.Create( "DNumSlider" )
     DButton:SetMin(0)
	 DButton:SetMax(25)
	 DButton:SetPos( 700, 350 )
     DButton:SetText( "Player Speed" )
     DButton:SetSize( 120, 10 )
	 DButton:SetConVar("k4_sh_speed")
	 DButton:MakePopup()

local hud = function()	 
		draw.RoundedBox(10, 635, ScrH() - 565 - 300, 650, 650, Color(25,25,25,200))
		draw.DrawText("K0N4T4", "Logo", 700, 220, Color(255, 255, 255, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT)
		draw.DrawText("V1", "Logo", 1120, 220, Color(255, 0, 0, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT)
	end
end)

function DRemove()
	concommand.Remove("+dmenu")
end

concommand.Add("-dmenu", DRemove)

--Speedhack, now works! :D

require("cvar3")
 
TS = GetConVar('host_timescale')
CH = GetConVar('sv_cheats')

function speedon()
	speed = GetConVarNumber("k4_sh_speed")
	CH:SetValue( speed )
	TS:SetValue( speed )
end
 
function speedoff()
	CH:SetValue(1.5)
	CH:SetValue(0)
end
 
concommand.Add("+speedhack", speedon)
concommand.Add("-speedhack", speedoff)

--[[
 INIT MSG
]]--


hook.Add("HUDPaint", "K0N4T4Watermark", function()
	draw.DrawText("K0N4T4 V1", "Misc", 10, 10, Color(255, 255, 255, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT)
end)

local function IsVisible( ent ) /* Huge credits to whoever made this tracer function! */
	local tracer = {}
	if(LocalPlayer():GetShootPos() != nil && ent:IsValid() && ent != nil && LocalPlayer():GetActiveWeapon():IsValid() && LocalPlayer():GetActiveWeapon() != nil && ent:LookupBone("ValveBiped.Bip01_Head1") != nil && ent:GetBonePosition(ent:LookupBone("ValveBiped.Bip01_Head1")) != nil) then
		tracer.start = LocalPlayer():GetShootPos()
		tracer.endpos = ent:GetBonePosition(ent:LookupBone("ValveBiped.Bip01_Head1"))
		tracer.filter = { LocalPlayer(), ent }
		tracer.mask = MASK_SHOT
		local trace = util.TraceLine( tracer )
		if trace.Fraction >= 1 then return true else return false end
	end
end

local function InFov(ent)
	for k,v in pairs(ents.FindInCone(LocalPlayer():GetShootPos(), LocalPlayer():GetAimVector(), 3000, GetConVarNumber("k4_aim_fov")))  do
		if(v:IsPlayer() && ent == v) then
			return true
		else
			return false
		end
	end
end

local function WHCheck(v)
	if v:Alive() == true && v:Health() ~= 0 && v:Health() >= 0 && v ~= LocalPlayer() && LocalPlayer():Alive() then
		return true
	else
		return false
	end
end

--[[
 CRAPAIM: Crap aimbot I based off of dead's. It's complete crap to say the least.
]]--

local function K0N4T4Aim()
        for k,v in pairs(player.GetAll()) do
                local bone = tostring(boneaim:GetString())
                if IsVisible( v ) and LocalPlayer():Alive() and v:Alive() and v ~= LocalPlayer() and v:Team() ~= TEAM_SPECTATOR and LocalPlayer():Team() ~= TEAM_SPECTATOR and GetConVarNumber("k4_aimbot") == 1 and LocalPlayer():GetActiveWeapon():GetClass() ~= "weapon_physgun" and LocalPlayer():GetActiveWeapon():GetClass() ~= "gmod_tool" and LocalPlayer():GetActiveWeapon():GetClass() ~= "gmod_camera" and LocalPlayer():GetActiveWeapon():GetClass() ~= "weapon_crowbar" then
                        if GetConVarNumber("k4_aimbot_onshoot") >= 1 then
                                if LocalPlayer():KeyDown(IN_ATTACK) then
                                        if(GetConVarNumber("k4_aimbot_infov") == 1) then
                                                if(InFov(v)) then
                                                        local head = v:LookupBone(bone)
                                                        local headpos,targetheadang = v:GetBonePosition(head)
                                                        LocalPlayer():SetEyeAngles((headpos - LocalPlayer():GetShootPos()):Angle())
                                                end
                                        else
                                                local head = v:LookupBone(bone)
                                                local headpos,targetheadang = v:GetBonePosition(head)
                                                LocalPlayer():SetEyeAngles((headpos - LocalPlayer():GetShootPos()):Angle())
                                        end
                                end
                        else
                                if(GetConVarNumber("k4_aimbot_infov") == 1) then
                                        if(InFov(v)) then
                                                local head = v:LookupBone(bone)
                                                local headpos,targetheadang = v:GetBonePosition(head)
                                                LocalPlayer():SetEyeAngles((headpos - LocalPlayer():GetShootPos()):Angle())
                                        end
                                else
                                        local head = v:LookupBone(bone)
                                        local headpos,targetheadang = v:GetBonePosition(head)
                                        LocalPlayer():SetEyeAngles((headpos - LocalPlayer():GetShootPos()):Angle())
                                end
                        end
                end
        end
end
hook.Add("Think", "K0N4T4Aim", K0N4T4Aim)

--[[ AIMBOT: C+P from Hera V4 until I feel like writing an undetected one like this huehueuhue. 
	Doesn't even work yet, need to rewrite and fix.


local Tb  = table.Copy( file )
local Tbs = table.Copy( string )
local Uw = {}
local Mw = {}
local function PlyPos( ply )
local min = ply:OBBMins()
local max = ply:OBBMaxs()
	
local Spots = {
	Vector( min.x, min.y, min.z ),
	Vector( min.x, min.y, max.z ),
	Vector( min.x, max.y, min.z ),
	Vector( min.x, max.y, max.z ),
	Vector( max.x, min.y, min.z ),
	Vector( max.x, min.y, max.z ),
	Vector( max.x, max.y, min.z ),
	Vector( max.x, max.y, max.z )
}	
local minX = ScrW() * 2
local minY = ScrH() * 2
local maxX = 0
local maxY = 0

	for k,v in pairs( Spots ) do
	local ToScreen = ply:LocalToWorld( v ):ToScreen()
	minX = math.min( minX, ToScreen.x )
	minY = math.min( minY, ToScreen.y )
	maxX = math.max( maxX, ToScreen.x )
	maxY = math.max( maxY, ToScreen.y )
	end
	return minX, minY, maxX, maxY
end
AddCMD("+k4_Aim",function()
Aimon = 1
end)

AddCMD("-k4_Aim",function()
Aimon = 0
IsLock = false
end)

local function AimSpot(targ)
	if GetConVarString("k4_AIM_AimSpot") == "Eye" then 
	local eye = targ:LookupAttachment("eyes")
		if eye then
		local pos = targ:GetAttachment(eye)
			if pos then return pos.Pos end
		end
	end	
	if GetConVarString("k4_AIM_AimSpot") == "Bone" then
	local bone = targ:LookupBone("ValveBiped.Bip01_Head1")
		if bone then
		local pos = targ:GetBonePosition(bone)
			if pos then return pos end
		end
	end	
	if GetConVarString("k4_AIM_AimSpot") == "Center" then
	local center = targ:OBBCenter()
		if center then
		local pos = targ:LocalToWorld(center)
			if pos then return pos end
		end
	end
	
return targ:LocalToWorld(targ:OBBCenter())

end

local function Exception(ent)
	if (ent == LocalPlayer()) then return false end
	if (ent:Team() == TEAM_SPECTATOR) then return false end
	if (ent:GetMoveType() == MOVETYPE_OBSERVER) then return false end
	if (!ent:Alive() ) then return false end
	if (ent:InVehicle()) then return false end 
	if (GetConVarNumber("k4_AIM_Friendly") == 0 && ent:Team() == LocalPlayer():Team()) then return false end  
	if (GetConVarNumber("k4_AIM_Steam") == 0 && ent:GetFriendStatus() == "friend" ) then return false end
return true
end

local function Visible(ply)
local tracedata = {}
	tracedata.start = LocalPlayer():GetShootPos()
	tracedata.endpos = AimSpot(ply) - Vector(0,0,GetConVarNumber("k4_AIM_Offset"))
	tracedata.mask = MASK_SHOT
	tracedata.filter = {ply , LocalPlayer()}
	Trace = util.TraceLine(tracedata)
	if Trace.Hit then return false else return true end
end

function InFov( ent )
	local fov = GetConVarNumber("k4_AIM_Fov")
	if( fov != 180 ) then
		local lpang = LocalPlayer():GetAngles()
		local ang = ( ent:GetBonePosition( ent:LookupBone("ValveBiped.Bip01_Head1") ) - LocalPlayer():EyePos() ):Angle()
		local ady = math.abs( math.NormalizeAngle( lpang.y - ang.y ) )
		local adp = math.abs( math.NormalizeAngle( lpang.p - ang.p ) )
		if( ady > fov || adp > fov ) then return false end
	end
	return true
end

local LastReload = 0
local dontreload = {"weapon_physgun" , "gmod_tool" , "weapon_gravgun"}
function AutoReload()
    if (GetConVarNumber("k4_AIM_Reload") == 1 and LocalPlayer():Alive() and IsValid( LocalPlayer():GetActiveWeapon() ) and !table.HasValue( dontreload, LocalPlayer():GetActiveWeapon():GetClass() ) ) then
		if( LocalPlayer():GetActiveWeapon():Clip1() <= 0 and CurTime() > ( LastReload + 5 ) ) then
			old_rcc( "+reload" )
			LastReload = CurTime()
			AddTimer( .2, 1, function()
				old_rcc( "-reload" )
			end )
		end
    end
end

local function Aimbot(ucmd)
local asspeed = GetConVarNumber("k4_AIM_AntiSnap_Speed") / 10
	if Aimon == 1 then		
		local ArchAngel = Angle(0,0,0)
		local target;
		local distance = math.huge;
		for _, ply in pairs(player.GetAll()) do
			if (ply != LocalPlayer() and ply:Alive() and Visible(ply) and Exception(ply)) and InFov(ply) then
				local thedist = ply:GetPos():DistToSqr(LocalPlayer():GetPos());
				if (thedist < distance) then
					distance = thedist;
					target = ply;
				end
			end
		end
		if target != nil then
		local Aimspot = AimSpot(target) - Vector(0,0,GetConVarNumber("k4_AIM_Offset"))
		Aimspot = Aimspot + target:GetVelocity() / 45 - LocalPlayer():GetVelocity() / 45
		Angel = (Aimspot - LocalPlayer():GetShootPos()):GetNormal():Angle()
		Angel.p = math.NormalizeAngle( Angel.p )
		Angel.y = math.NormalizeAngle( Angel.y )
		
		if GetConVarNumber("k4_AIM_AntiSnap") == 1 then 
			Angle1 = LocalPlayer():EyeAngles()
			local Smooth1 = math.Approach(Angle1.p, Angel.p, asspeed)
			local Smooth2 = math.Approach(Angle1.y , Angel.y, asspeed)       
			ArchAngel = Angle (Smooth1, Smooth2, 0)
		else			
			ArchAngel = Angle( Angel.p, Angel.y, 0 )
		end
				debug.getregistry()["CUserCmd"].SetViewAngles(ucmd, ArchAngel)
				IsLock = 1
			if GetConVarNumber("k4_AIM_Auto") == 1 then
                ucmd:SetButtons(bit.bor(ucmd:GetButtons(),IN_ATTACK)) 
			end
			if GetConVarNumber("k4_AIM_SH") == 1 then
				ucmd:SetButtons(bit.bor(ucmd:GetButtons(),IN_ATTACK2))  
			end
		end
	end
end

]]--


--Silent Aimbot
function aimbot()
	if silentAim:GetBool() then
		local ply = LocalPlayer() 
		local trace = util.GetPlayerTrace( ply )
		local traceRes = util.TraceLine( trace )
		if traceRes.HitNonWorld then 
			local target = traceRes.Entity
			if target:IsPlayer() then 
				local targethead = target:LookupBone("ValveBiped.Bip01_Head1") 
				local targetheadpos,targetheadang = target:GetBonePosition(targethead) 
				ply:SetEyeAngles((targetheadpos - ply:GetShootPos()):Angle()) 
			end
		end
	end
end
hook.Add("Think","aimbot",aimbot) 

--No Recoil
function NoRec()
	if GetConVarNumber("k4_remove_recoil") == 1 then
		if LocalPlayer():GetActiveWeapon().Primary then
			LocalPlayer():GetActiveWeapon().Primary.Recoil = 0
		end
	end
end

hook.Add("Think", "recoil", NoRec)

-- Esp --
local function K0N4T4Esp()
	if espOn:GetBool() then
		for k,v in pairs (player.GetAll() ) do
				local ESP = (v:EyePos()):ToScreen()
				if v == LocalPlayer() then Name = "" else Name = v:Nick()

				if v:IsAdmin() then
					draw.DrawText(v:Name(), "esp", ESP.x, ESP.y -46, team.GetColor(v:Team()), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT)
					draw.DrawText("Admin", "esp", ESP.x, ESP.y -23, Color(255, 255, 255, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT)
				elseif v:IsSuperAdmin() then
					draw.DrawText(v:Name(), "esp", ESP.x, ESP.y -46, team.GetColor(v:Team()), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT)
					draw.DrawText("SuperAdmin", "esp", ESP.x, ESP.y -23, Color(255, 255, 255, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT)
				else
					draw.DrawText(v:Name(), "esp", ESP.x, ESP.y -46, team.GetColor(v:Team()), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT)
					draw.DrawText("User", "esp", ESP.x, ESP.y -23, Color(255, 255, 255, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT)
				end
				draw.DrawText("Health: " .. v:Health(), "esp", ESP.x, ESP.y -34, Color(255, 255, 255, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT)
				if(v:GetActiveWeapon():IsValid()) then
					draw.DrawText(v:GetActiveWeapon():GetClass(), "esp", ESP.x, ESP.y -12, Color(255, 255, 255, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT)
				end
			end
		end
	end
end

hook.Add ("HUDPaint", "esp", K0N4T4Esp)

-- Wallhack -- WARNING: NOT SHIT <:
hook.Add("HUDPaint", "K0N4T4Wallhack", function()
		for k,v in pairs(player.GetAll()) do
		if wallHackOn:GetBool() then
			if WHCheck(v) then
				cam.Start3D(EyePos(), EyeAngles())
					v:SetMaterial("models/wireframe")
					v:SetColor(Color(0, 64, 255, 225))
					render.MaterialOverride("models/wireframe")
					render.SuppressEngineLighting( false )
					render.SetBlend( 0.8 )
					render.SetColorModulation( 0, 1, 0 )
					v:DrawModel()
					if GetConVarNumber("k4_wallhack_reg") >= 1 then -- Advise not using this trolo
						render.MaterialOverride("pp/copy")
						render.SuppressEngineLighting( false )
						render.SetBlend( 0.8 )
						render.SetColorModulation( 0, 1, 0 )
						v:SetMaterial("pp/copy")
						render.MaterialOverride("pp/copy")
						v:DrawModel()
					end
				cam.End3D()
			end
		end
	end
end)

-- Bhop --
	if CLIENT then
		concommand.Add("+bhop",function()
			hook.Add("Think","hook",function()
				RunConsoleCommand(((LocalPlayer():IsOnGround() or LocalPlayer():WaterLevel() > 0) and "+" or "-").."jump")
			end)
		end)

		concommand.Add("-bhop",function()
			RunConsoleCommand("-jump")
			hook.Remove("Think","hook")
		end)
	end

-- Tracers
hook.Add("HUDPaint", "K0N4T4Trace", function()
        if GetConVarNumber("k4_tracers") >= 1 then
                for k,v in pairs(player.GetAll()) do
                        local ETrace = v:EyePos():ToScreen()
                        local x = ScrW() / 2
                        local y = ScrH() / 2
                        if GetConVarNumber("k4_tracers_traceteam") >= 1 then
                                surface.SetDrawColor(team.GetColor(v:Team()))
                        else
                                surface.SetDrawColor(0, 64, 255, 225)
                        end
                        if WHCheck(v) then
                                if GetConVarNumber("k4_tracers_highlight") >= 1 then
                                local trace = LocalPlayer():GetEyeTrace().Entity
                                        if trace:IsPlayer() && trace:IsValid() && LocalPlayer():GetActiveWeapon():IsValid() then
                                                surface.SetDrawColor(19, 22, 22, 255)
                                                surface.DrawLine(ETrace.x, ETrace.y, x, y)
                                                surface.SetDrawColor(255, 255, 255, 255)
                                        end
                                end
                                surface.DrawLine(ETrace.x, ETrace.y, x, y)
                        end

                end
        end
end)

--[[
HUD SHIT
]]--

--Below is aimbot status check

hook.Add("HUDPaint", "AimStatus", function()
	draw.DrawText("Aimbot: ", "Misc", 1700, 10, Color(255, 255, 255, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT)
end)

function AimCheck()
	if GetConVarNumber("k4_aimbot") >= 1 then
		hook.Remove("HUDPaint", "DAimStatus2")
		hook.Add("HUDPaint", "DAimStatus1", function()
			draw.DrawText("On", "Misc", 1815, 10, Color(79, 225, 38, 107), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT)
		end)
	elseif GetConVarNumber("k4_aimbot") < 1 then
		hook.Remove("HUDPaint", "DAimStatus1")
		hook.Add("HUDPaint", "DAimStatus2", function()
			draw.DrawText("Off", "Misc", 1815, 10, Color(255, 0, 0, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT)
		end)
	end
end

hook.Add("Think", "AimCheck", AimCheck)


-- Below is Wallhack status check

hook.Add("HUDPaint", "WHStatus", function()
	draw.DrawText("Wallhack: ", "Misc", 1700, 50, Color(255, 255, 255, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT)
end)

function WallCheck()
	if GetConVarNumber("k4_wallhack") >= 1 then
		hook.Remove("HUDPaint", "WHStatus2")
		hook.Add("HUDPaint", "WHStatus1", function()
			draw.DrawText("On", "Misc", 1840, 50, Color(79, 225, 38, 107), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT)
		end)
	elseif GetConVarNumber("k4_wallhack") < 1 then
		hook.Remove("HUDPaint", "WHStatus1")
		hook.Add("HUDPaint", "WHStatus2", function()
			draw.DrawText("Off", "Misc", 1840, 50, Color(255, 0, 0, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT)
		end)
	end
end

hook.Add("Think", "WallCheck", WallCheck)

-- Below is Tracers Check

hook.Add("HUDPaint", "TracerStatus", function()
	draw.DrawText("Tracers: ", "Misc", 1700, 90, Color(255, 255, 255, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT)
end)

function TracerCheck()
	if GetConVarNumber("k4_tracers") >= 1 then
		hook.Remove("HUDPaint", "TStatus2")
		hook.Add("HUDPaint", "TStatus1", function()
			draw.DrawText("On", "Misc", 1815, 90, Color(79, 225, 38, 107), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT)
		end)
	elseif GetConVarNumber("k4_tracers") < 1 then
		hook.Remove("HUDPaint", "TStatus1")
		hook.Add("HUDPaint", "TStatus2", function()
			draw.DrawText("Off", "Misc", 1815, 90, Color(255, 0, 0, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT)
		end)
	end
end

hook.Add("Think", "TracerCheck", TracerCheck)

--Spawnprotection timer, for F2S:Stronghold, does not work.

function SPTimer()
	hook.Add("HUDPaint", "SpProtect4", function()
		draw.DrawText("4", "Misc", 1815, 90, Color(255, 0, 0, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT)
	end)
	sleep(1000)
	hook.Remove("HUDPaint", "SpProtect4")
	hook.Add("HUDPaint", "SpProtect3", function()
		draw.DrawText("3", "Misc", 1815, 90, Color(255, 0, 0, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT)
	end)
	sleep(1000)
	hook.Remove("HUDPaint", "SpProtect3")
	hook.Add("HUDPaint", "SpProtect2", function()
		draw.DrawText("2", "Misc", 1815, 90, Color(255, 0, 0, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT)
	end)
	sleep(1000)
	hook.Remove("HUDPaint", "SpProtect2")
	hook.Add("HUDPaint", "SpProtect1", function()
		draw.DrawText("2", "Misc", 1815, 90, Color(255, 0, 0, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT)
	end)
	sleep(1000)
	hook.Remove("HUDPaint", "SpProtect1")
end

hook.Add("PlayerSpawn", "SpawnProtectTime", SPTimer)