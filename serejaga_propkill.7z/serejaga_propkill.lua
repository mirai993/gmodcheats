// Simple pk shit by holy man Serejaga
local hk = {}

local localplayer = LocalPlayer()

local render_color = Color( 0, 0, 255 )
local cham_material = CreateMaterial( "flat", "UnLitGeneric" )

-- Override player render 
function hk.PrePlayerDraw( ply, flags )
    cam.IgnoreZ( true )

    -- Fill model with colored material  
    render.SetColorModulation( 1, 1, 0 )
    render.MaterialOverride( cham_material )
end

local mins, maxs = localplayer:OBBMins(), localplayer:OBBMaxs()
function hk.PostPlayerDraw( ply, flags )
    -- Render box 
    render.DrawWireframeBox( ply:GetPos(), ply:GetAngles(), mins, maxs, render_color, true )

    -- Reset render
    render.MaterialOverride()
    render.SetColorModulation( 1, 1, 1 )

    cam.IgnoreZ( false )
end

-- Override physgun beam 
function hk.DrawPhysgunBeam( ply, physgun, enabled, target, physbone, hitpos )
    if not enabled or ply == localplayer then
        return
    end

    local start, hit = ply:EyePos(), ply:GetEyeTrace().HitPos

    cam.IgnoreZ( true )

    -- Setup render
    render.SetColorModulation( 1, 1, 0 )
    render.SetMaterial( cham_material )

    render.DrawBeam( start, hit, 6, 0, 1 )
    
    -- Reset render
    render.MaterialOverride()
    render.SetColorModulation( 1, 1, 1 )

    cam.IgnoreZ( false )

    return false 
end

-- Entity render 
function hk.PreDrawEffects()
    local entities = ents.FindByClass( "prop_*" )

    cam.IgnoreZ( true )

    render.SetColorModulation( 0, 1, 0.3 )
    render.MaterialOverride( cham_material )

    for i = 1, #entities do
        local ent = entities[ i ]

        if ent:IsDormant() then
            continue 
        end

        -- Fill model with colored material  
        ent:DrawModel()

        -- Draw box
        render.DrawWireframeBox( ent:GetPos(), ent:GetAngles(), ent:OBBMins(), ent:OBBMaxs(), color_enemy, true )
    end

    -- Reset render
    render.MaterialOverride()
    render.SetColorModulation( 1, 1, 1 )

    cam.IgnoreZ( false )
end

-- Craaaaazyyy assist 
local forward = GetConVarNumber("cl_forwardspeed")
local side = GetConVarNumber("cl_sidespeed")

local prevYaw = 0 
function hk.CreateMove( cmd )
    if cmd:CommandNumber() == 0 then
        return 
    end

    local speed = localplayer:GetAbsVelocity():Length2D()
    local curYaw = math.NormalizeAngle( cmd:GetViewAngles().y )

    if cmd:KeyDown( IN_JUMP ) then
        if localplayer:IsFlagSet( FL_ONGROUND ) then
            cmd:SetForwardMove( 10000 )
        else
            cmd:SetForwardMove( 5850 / speed )
            cmd:SetSideMove( (cmd:CommandNumber() % 2 == 0) and -400 or 400 )

            cmd:RemoveKey( IN_JUMP )
        end
    end

    prevYaw = curYaw
end

-- Setup hooks 
for key, value in pairs( hk ) do
    local name = string.format( "serejaga.%s", key )  
    hook.Add( key, name, value )
end

-- Setup convars 
require("zxcmodule")

ded.SetInterpolation( false )
ded.SetSequenceInterpolation( false )

RunConsoleCommand( "cl_interp", 0 )
RunConsoleCommand( "cl_interp_ration", 0 )
RunConsoleCommand( "physgun_wheelspeed", 10000  )