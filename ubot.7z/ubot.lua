--[[
	lua/superhack.lua
	[Asm]Schwarz_C# | (STEAM_0:1:44629398)
	===DStream===
]]

﻿

if (_G['Color'] == nil) then 
	_G['Color'] = function(r, g, b, a)
		a = a or 255
		return {r = tonumber(r), g = tonumber(g), b = tonumber(b), a = tonumber(a)}
	end
end


local ubot = {}

	ubot.IncludeAimCmd = false
								
	ubot.ToggleAimKey = KEY_B
	ubot.ShowGUIKey = KEY_LBRACKET

ubot.lp = LocalPlayer()
ubot.scr = {['w'] = ScrW(), ['h'] = ScrH(), ['hw'] = ScrW() / 2, ['hh'] = ScrH() / 2}
local timer = timer
local hook = hook
local team = team
local surface = surface
local render = render
local string = string
local vgui = vgui
local math = math
local util = util
local cam = cam
local SetMaterialOverride = SetMaterialOverride
local RunConsoleCommand = RunConsoleCommand --fon.ec_ClientCmd_Unrestricted
local ValidEntity = ValidEntity
local HSVToColor = HSVToColor
local tostring = tostring
local IsValid = IsValid
local Vector = Vector
local Color = Color
local pairs = pairs
local type = type


string.random = function(minl, maxl)
	local tempstr = ""
	for i=0,math.random(minl,maxl) do
		local c = math.random(65,116)
		if (c >= 91) && (c <= 96) then c = c + 6 end
		tempstr = tempstr .. string.char(c)
	end
	return tempstr
end

ubot.nums2vec = function(x,y,z) return Vector(x,y,z) end
ubot.nums2ang = function(p,y,r) return Angle(p,y,r) end
ubot.IsFriend = function(ent) return (ent:GetFriendStatus() == 'friend') end
ubot.GetBonePos = function(ent, bone) return ent:GetBonePosition(ent:LookupBone(bone)) end
ubot.Distance = function(ent) return ubot.lp:GetShootPos():Distance(ent:GetPos()) end
ubot.num2vec = function(num) return Vector(num, num, num) end

ubot.NormalizeAngle = function(a)
	a = a % 360
	return (a > 180) and a - 360 or a
end

ubot.InFOV = function(ent, fov)
	local lpos = ubot.lp:WorldToLocal(ubot.lp:OBBCenter())
	local epos = ent:WorldToLocal(ent:OBBCenter())
	local ang = (epos - lpos):Angle()
	local currang = ubot.lp:EyeAngles()
	ang.p = math.NormalizeAngle(ang.p)
	ang.y = math.NormalizeAngle(ang.y)
	currang.p = math.NormalizeAngle(currang.p)
	currang.y = math.NormalizeAngle(currang.y)
	local diffP = math.abs(math.abs(currang.p) - math.abs(ang.p))
	local diffY = math.abs(math.abs(currang.y) - math.abs(ang.y))
	if (diffP > fov) or (diffY > fov) then return false end
	return true
end

ubot.IsBehindWall = function(ent)
	local tr = util.GetPlayerTrace(ubot.lp, ubot.lp:EyePos() - ent:LocalToWorld(ent:OBBCenter()))
	return not (tr.Entity == ent)
end

ubot.IsValid = function(ent)
	if (not IsValid(ent)) then return false end
	if (ent == ubot.lp) then return false end
	if ent:IsWorld() then return false end
	if ent:IsWeapon() then return false end
	if (ent:GetMoveType() == MOVETYPE_NONE) then return false end
	if (ent:GetMoveType() == MOVETYPE_OBSERVER) then return false end
	if ent:IsPlayer() then
		if ubot.config.get('misc', 'Target Steam Friends') then
			return ent:Alive()
		else return (ent:Alive() and (not ubot.IsFriend(ent))) end
	end
	return true
end

ubot.ClientIsCrouching = function()
	if ubot.lp:KeyDown(IN_DUCK) and ubot.ClientOnGround() then
		return true
	end
	return false
end

ubot.ClientOnGround = function()
	local ground = ubot.lp:GetGroundEntity()
	if IsValid(ground) or ground:IsWorld() or ubot.lp:IsOnGround() then
		return true
	end
	return false
end


ubot.hooks = {}

ubot.AddHook = function(event_name, name, func)
	if (ubot.hooks[event_name] == nil) then ubot.hooks[event_name] = {} end
	ubot.hooks[event_name][name] = string.random(4,10)
	hook.Add(event_name, ubot.hooks[event_name][name], func)
	print("ADDED HOOK ["..event_name.."]["..name.."] = "..tostring(func))
end

ubot.RemoveHook = function(event_name, name, func)
	hook.Remove(event_name, ubot.hooks[event_name][name])
	print("REMOVED HOOK ["..event_name.."]["..name.."]")
	ubot.hooks[event_name][name] = nil
end


ubot.config = {}

ubot.config.get = function(cfg, key)
	return ubot.config[cfg][key] or false
end

ubot.config.save = function()

end

ubot.config.load = function()

end

ubot.config.aimbot = {
{['Enabled'] = false},
{['Method'] = {'None', 'All', 'Sphere', 'InFOV', 'LockOn', 'AllNoWall', 'SphereNoWall'}},
{['Method Var'] = 512},
{['Trigger Bot'] = false},
{['Predict Spread'] = false},
{['Friendly Fire'] = false},
{['Include Players'] = true},
{['Include NPCs'] = false},
{['Include Props'] = false},
{['Bone'] = {'head','neck','chest','crotch'}},
{['No Shake'] = false},
}





ubot.config.bones = {
	["head"] = {
		['default'] = "ValveBiped.Bip01_Head1",
		['folder:zombie'] = "ValveBiped.HC_Body_Bone",
		['mdl:fast.mdl'] = "ValveBiped.HC_BodyCube",
		['mdl:poison.mdl'] = "ValveBiped.Headcrab_Cube1",
		['mdl:manhack.mdl'] = "Manhack.MH_Control",
		['mdl:combine_scanner.mdl'] = "Scanner.Body",
		['mdl:barnacle.mdl'] = "Barnacle.innards",
		['mdl:combine_helicopter.mdl'] = "Chopper.Body",
		['mdl:combine_strider.mdl'] = "Combine_Strider.Body_Bone",
		['mdl:combine_dropship.mdl'] = "D_ship.Pelvis",
		['mdl:gunship.mdl'] = "Gunship.Body",
		['mdl:pigeon.mdl'] = "Crow.Head"
	},
	["neck"] = {
		['default'] = "ValveBiped.Bip01_Neck1",
		['folder:zombie'] = "ValveBiped.HC_Body_Bone",
		['mdl:fast.mdl'] = "ValveBiped.Bip01_Spine4",
		['mdl:poison.mdl'] = "ValveBiped.Headcrab_Cube1",
		['mdl:headcrabblack.mdl'] = "HCblack.body",
		['mdl:headcrabclassic.mdl'] = "HeadcrabClassic.BodyControl",
		['mdl:headcrab.mdl'] = "HCfast.body",
		['mdl:manhack.mdl'] = "Manhack.MH_Control",
		['mdl:combine_scanner.mdl'] = "Scanner.Body",
		['mdl:barnacle.mdl'] = "Barnacle.body",
		['mdl:combine_helicopter'] = "Chopper.Body",
		['mdl:combine_strider'] = "Combine_Strider.Body_Bone",
		['mdl:combine_dropship'] = "D_ship.Pelvis",
		['mdl:gunship.mdl'] = "Gunship.Body",
		['mdl:pigeon.mdl'] = "Crow.Head"
	},
	["chest"] = {
		['default'] = "ValveBiped.Bip01_Spine2",
		['mdl:headcrabblack.mdl'] = "HCblack.body",
		['mdl:headcrabclassic.mdl'] = "HeadcrabClassic.BodyControl",
		['mdl:headcrab.mdl'] = "HCfast.body",
		['mdl:manhack.mdl'] = "Manhack.MH_Control",
		['mdl:combine_scanner.mdl'] = "Scanner.Body",
		['mdl:barnacle.mdl'] = "Barnacle.body",
		['mdl:combine_helicopter'] = "Chopper.Body",
		['mdl:combine_strider'] = "Combine_Strider.Body_Bone",
		['mdl:combine_dropship'] = "D_ship.Pelvis",
		['mdl:gunship.mdl'] = "Gunship.Body",
		['mdl:pigeon.mdl'] = "Crow.Body"
	},
	["crotch"] = {
		['default'] = "ValveBiped.Bip01_Pelvis",
		['folder:zombie'] = "ValveBiped.Bip01_Spine",
		['mdl:headcrabblack.mdl'] = "HCblack.body",
		['mdl:headcrabclassic.mdl'] = "HeadcrabClassic.BodyControl",
		['mdl:headcrab.mdl'] = "HCfast.body",
		['mdl:manhack.mdl'] = "Manhack.MH_Control",
		['mdl:combine_scanner.mdl'] = "Scanner.Body",
		['mdl:barnacle.mdl'] = "Barnacle.body",
		['mdl:combine_helicopter'] = "Chopper.Body",
		['mdl:combine_strider'] = "Combine_Strider.Body_Bone",
		['mdl:combine_dropship'] = "D_ship.Pelvis",
		['mdl:gunship.mdl'] = "Gunship.Body",
		['mdl:pigeon.mdl'] = "Crow.Body"
	}
}

--[[AIMBOT]]--
ubot.aimbot = {}
ubot.aimbot.shooting = false
ubot.aimbot.nextshot = 0
ubot.aimbot.starget = nil
ubot.aimbot.currSeed = 0

ubot.aimbot.AimCmdOn = false
ubot.aimbot.PlusAimCmd = function(ply, cmd, args)
	ubot.aimbot.AimCmdOn = true
end
ubot.aimbot.MinusAimCmd = function(ply, cmd, args)
	ubot.aimbot.AimCmdOn = false
	ubot.aimbot.shooting = false
	ubot.aimbot.starget = nil
end
if (ubot.IncludeAimCmd) then
	concommand.Remove("+ubot_viser")
	concommand.Remove("-ubot_viser")
	concommand.Add("+ubot_viser", ubot.aimbot.PlusAimCmd)
	concommand.Add("-ubot_viser", ubot.aimbot.MinusAimCmd)
end

ubot.aimbot.IsValid = function(ent)
	if (not ubot.IsValid(ent)) then return false end
	if ent:IsPlayer() and ubot.config.get('aimbot', 'Include Players') then
		if (ent:Team() == ubot.lp:Team()) then
			return ubot.config.get('aimbot', 'Friendly Fire')
		else return true end
	elseif ent:IsNPC() then
		return IsFriendEntityName(ent:GetClass()) and
			(ubot.config.get('aimbot', 'Include NPCs') and
			ubot.config.get('aimbot', 'Friendly Fire')) or
			ubot.config.get('aimbot', 'Include NPCs')
	elseif (not ent:IsPlayer()) and (not ent:IsNPC()) then
		return ubot.config.get('aimbot', 'Include Props')
	end
	return false
end

ubot.aimbot.methods = {
['None'] = function(x) return {} end,
['All'] = function(x) return ents.GetAll() end,
['Sphere'] = function(x) return ents.FindInSphere(ubot.lp:GetShootPos(), x or 512) end,
['InFOV'] = function(x)
	local prechk = ents.GetAll()
	local result = {}
	for k,v in pairs(prechk) do
		if (ubot.aimbot.IsValid(v)) then
			if ubot.InFOV(v, x) then table.insert(result, v) end
		end
	end
	return result
end,
['_LockOn'] = nil, ['LockOn'] = function(x)
	if (not ubot.IsValid(ubot.aimbot.methods["_LockOn"])) then
		ubot.aimbot.methods["_LockOn"] = ubot.lp:GetEyeTrace().Entity
	end
	if ubot.IsValid(ubot.aimbot.methods["_LockOn"]) and ubot.lp:Alive() then
		return {ubot.aimbot.methods["_LockOn"]}
	end
	return {}
end,
['AllNoWall'] = function(x)
	local prechk = ents.GetAll()
	local result = {}
	for k,v in pairs(prechk) do
		if (ubot.aimbot.IsValid(v)) then
			if not ubot.IsBehindWall(v) then table.insert(result, v) end
		end
	end
	return result
end,
['SphereNoWall'] = function(x)
	local prechk = ents.FindInSphere(ubot.lp:GetShootPos(), x or 512)
	local result = {}
	for k,v in pairs(prechk) do
		if (ubot.aimbot.IsValid(v)) then
			if not ubot.IsBehindWall(v) then table.insert(result, v) end
		end
	end
	return result
end
}

ubot.aimbot.GetAimPos = function(ent)
	if (ent == nil) or (not ubot.aimbot.IsValid(ent)) then return Vector(0,0,0) end
	local bones = ubot.config.bones[ubot.config.get('aimbot', 'Bone') or 'head']
	local exp = string.Explode('/', string.lower(ent:GetModel()))
	if (#exp ~= 3) then
		if ent:IsPlayer() or ent:IsNPC() then
			return ubot.GetBonePos(ent, bones['default'])
		else
			return ent:LocalToWorld(ent:OBBCenter())
		end
	end
	if (bones['mdl:'..exp[3]] ~= nil) then
		return ubot.GetBonePos(ent, bones['mdl:'..exp[3]])
	elseif (bones['folder:'..exp[2]] ~= nil) then
		return ubot.GetBonePos(ent, bones['folder:'..exp[2]])
	else
		return ubot.GetBonePos(ent, bones['default'])
	end
end

GetBoneName = function(lookup, section, ent)
	local bones = bones[section or 'head'] --default to head
	local expmdl = string.Explode('/', string.lower(ent:GetModel()))
	if (#expmdl ~= 3) then
		if ent:IsPlayer() or ent:IsNPC() then
			return ubot.GetBonePos(ent, bones['default'])
		else
			return ent:LocalToWorld(ent:OBBCenter())
		end
	end
	if (bones['mdl:'..expmdl[3]] ~= nil) then
		return bones['mdl:'..expmdl[3]]
	elseif (bones['folder:'..expmdl[2]] ~= nil) then
		return bones['folder:'..exp[2]]
	else
		return bones['default']
	end
end

ubot.aimbot.CrossbowFix = function(aimpos, target)
	if (ubot.lp:GetActiveWeapon().GetPrintName ~= nil) then
		if (ubot.lp:GetActiveWeapon():GetPrintName() == "#HL2_Crossbow") then
			local angp = math.sin((aimpos - ubot.lp:GetShootPos()):Angle().p)
			aimpos = aimpos + Vector(0,0, (ubot.Distance(target) / 244.286) + angp)
			return aimpos
		end
	end
	return aimpos
end

ubot.aimbot.GetCone = function(wep)
	local cone = wep.Cone
	if (wep.Primary ~= nil) then
		if (wep.Primary.Cone ~= nil) then cone = wep.Primary.Cone end
	end
	if (cone == nil) then cone = 0 end
	

	if (string.find(GAMEMODE.Name, "Zombie Survival") ~= nil) then
		cone = wep.Cone
		local ironsights = wep:GetNWBool("Ironsights", false)
		if (ironsights) and (wep.ConeIron) then cone = wep.ConeIron end
		if ubot.clientCrouching() and (wep.ConeIronCrouching and wep.ConeCrouching) then
			cone = (ironsights and wep.ConeIronCrouching or wep.ConeCrouching)
		end
		if (not ironsights) and ubot.IsMoving(tbl.lp) and (wep.ConeMoving) then
			cone = wep.ConeMoving
		end
	end
	
	return cone
end

ubot.aimbot.PredictSpread = function(ucmd, ang)
	local cnum = fon.CUserCmd_GetCommandNumber(ucmd)
	if (cnum ~= 0) then
		ubot.aimbot.currSeed = fon.fon_MD5_PseudoRandom(cnum)
	end
	local wep = ubot.lp:GetActiveWeapon()
	local vecCone = ubot.num2vec(ubot.aimbot.GetCone(wep) * -1)
	return fon.fon_ManipulateShot(ubot.aimbot.currSeed or 0,
		(ang or ubot.lp:GetAimVector():Angle()):Forward(), vecCone):Angle()
end

ubot.aimbot.tempAng = nil
ubot.aimbot.nextGUIkey = 0
ubot.aimbot.preAimAng = nil
ubot.aimbot.toggleaim = true
ubot.aimbot.nexttogglekey = 0
ubot.aimbot.CreateMove = function(ucmd)
	if (input.IsKeyDown(ubot.ShowGUIKey) and (CurTime() > ubot.aimbot.nextGUIkey)) then
		if input.IsKeyDown(KEY_DELETE) then
			for k,v in pairs(ubot.hooks) do
				for rk,rv in pairs(v) do
					ubot.RemoveHook(k,rk)
				end
			end
			ubot.gui.frame:SetVisible(false)
			ubot.gui = {}
		else
			if (not ubot.gui.frame:IsVisible()) then
				ubot.gui.frame:SetVisible(true)
				local x, y = ubot.gui.frame:GetPos()
				gui.SetMousePos(x + 25, y + 35)
			else
				ubot.config.save()
				ubot.gui.frame:SetVisible(false)
			end
		end
		ubot.aimbot.nextGUIkey = CurTime() + 0.5
	end
	
	if (not ubot.aimbot.IsValid(ubot.aimbot.starget)) then
		ubot.aimbot.preAimAng = nil
		ubot.aimbot.starget = nil
		ubot.aimbot.methods["_LockOn"] = nil
	end
	
	
	if ubot.config.get('aimbot', 'Trigger Bot') and ubot.aimbot.IsValid(ubot.lp:GetEyeTrace().Entity) then
		if (ubot.aimbot.nextshot < CurTime()) and IsValid(ubot.lp:GetActiveWeapon()) then
			ubot.aimbot.nextshot = (ubot.lp:GetActiveWeapon().Primary
				and ubot.lp:GetActiveWeapon().Primary.Delay or 0.1)
			ucmd:SetButtons(bit.bor(ucmd:GetButtons(), IN_ATTACK))
		else
			ucmd:SetButtons(bit.band(ucmd:GetButtons(), bit.bnot(IN_ATTACK)))
		end
	end
	
	if ubot.config.get('aimbot', 'Enabled') then
		if (not ubot.lp:Alive()) then ubot.aimbot.methods['_LockOn'] = nil end
		local aimang = nil
		
		if (input.IsKeyDown(ubot.ToggleAimKey) and (CurTime() > ubot.aimbot.nexttogglekey)) then
			ubot.aimbot.toggleaim = not ubot.aimbot.toggleaim
			ubot.aimbot.nexttogglekey = CurTime() + 0.2
		end
		
		local AimDisabled = false
		if (ubot.IncludeAimCmd) then
			AimDisabled = not ubot.aimbot.AimCmdOn
		elseif (not ubot.aimbot.toggleaim) then
			AimDisabled = true
		end
	
		
		if (not AimDisabled) then
			local xvar = ubot.config.get('aimbot', 'Method Var') or 0
			local _targets = ubot.aimbot.methods[ubot.config.get('aimbot', 'Method') or 'None'](xvar) or {}
			local targets = {}
			for k,v in pairs(_targets) do if ubot.aimbot.IsValid(v) then table.insert(targets, v) end end
			table.sort(targets, function(a,b) return ubot.Distance(a) < ubot.Distance(b) end)
			if (#targets ~= 0) and (targets ~= nil) then
				ubot.aimbot.starget = targets[1]
				if (ubot.aimbot.starget ~= nil) and ubot.aimbot.IsValid(ubot.aimbot.starget) then
					local aimpos = ubot.aimbot.GetAimPos(ubot.aimbot.starget)
					aimpos = ubot.aimbot.CrossbowFix(aimpos, ubot.aimbot.starget)
					aimang = (aimpos - ubot.lp:GetShootPos()):Angle()
				end
			end
		else
			ucmd:SetViewAngles(ubot.lp:EyeAngles())
			ubot.aimbot.methods["_LockOn"] = nil
		end
		
		--[[if ubot.lp:GetActiveWeapon().Base == "weapon_cs_base" then
			if ubot.config.get('aimbot', 'Predict Spread') and ucmd:KeyDown(IN_ATTACK) then
				if (aimang == nil) then
					aimang = ubot.lp:EyeAngles()
					if (ubot.aimbot.tempAng == nil) then
						ubot.aimbot.tempAng = ubot.lp:EyeAngles()
					end
					aimang = ubot.aimbot.tempAng
				end
				aimang = ubot.aimbot.PredictSpread(ucmd, aimang)
			else
				if (ubot.aimbot.tempAng ~= nil) then ubot.aimbot.tempAng = nil end
			end
		end]]--
		
		if (aimang ~= nil) then
			ubot.aimbot.preAimAng = ubot.lp:EyeAngles()
			aimang.p = ubot.NormalizeAngle(aimang.p)
			aimang.y = ubot.NormalizeAngle(aimang.y)
			aimang.r = ubot.NormalizeAngle(aimang.r)
			ucmd:SetViewAngles(aimang)
		end
	end
end
ubot.AddHook("CreateMove", "ubot.aimbot.CreateMove", ubot.aimbot.CreateMove)

ubot.aimbot.CalcView = function(ply, pos, ang, fov, nearZ, farZ)
	if (not ubot.config.get('aimbot', 'No Shake')) then return end
	if (ubot.aimbot.preAimAng == nil) then return end
	return {origin = pos, angles = ubot.aimbot.preAimAng, fov = fov, nearZ = nearZ, farZ = farZ}
end
ubot.AddHook("CalcView", "ubot.aimbot.CalcView", ubot.aimbot.CalcView)



--[[GUI]]--
ubot.gui = {}
ubot.gui.cfg2gui = function(parent, cfgtbl)
	parent.TextColor = Color(90,90,90,255)
	parent.items = {}
	parent.index = 0
	for k,v in pairs(cfgtbl) do
		for ck,cv in pairs(v) do k, v = ck, cv end
		if (type(v) == "boolean") then
			parent.items[k] = vgui.Create("DCheckBoxLabel")
			parent.items[k]:SetParent(parent)
			parent.items[k]:SetPos(0, parent.index * 20)
			parent.items[k]:SetText(k)
			parent.items[k]:SizeToContents()
			parent.items[k]:SetTextColor(parent.TextColor)
			parent.items[k]:SetValue(v)
			parent.items[k].OnChange = function()
				cfgtbl[k] = parent.items[k]:GetChecked()
			end
		elseif (type(v) == "table") then
			parent.items['_'..k] = vgui.Create("DLabel")
			parent.items['_'..k]:SetParent(parent)
			parent.items['_'..k]:SetPos(1, (parent.index * 20) + 4)
			parent.items['_'..k]:SetText(k..':')
			parent.items['_'..k]:SizeToContents()
			parent.items['_'..k]:SetTextColor(parent.TextColor)
			
			if (v.r ~= nil) and (v.g ~= nil) and (v.b ~= nil) then
				--[[
				parent.items[k] = vgui.Create("DRGBBar")
				parent.items[k]:SetParent(parent)
				parent.items[k]:SetPos(parent.items['_'..k]:GetWide() + 10, (parent.index * 20))
				parent.items[k]:SetSize(80, 21)
				parent.items[k]:SetColor(v)
				parent.items[k].OnColorChange = function()
					cfgtbl[k] = HSVToColor(parent.items[k]:GetHue(), 1, 1)
				end
				--]]
			else
				parent.items[k] = vgui.Create("DComboBox")
				parent.items[k]:SetParent(parent)
				parent.items[k]:SetPos(parent.items['_'..k]:GetWide() + 10, (parent.index * 20))
				parent.items[k]:SetSize(80, 21)
				for rk,rv in pairs(v) do parent.items[k]:AddChoice(rv) end
				parent.items[k]:ChooseOptionID(1)
				parent.items[k].OnSelect = function(Index, Value, Data)
					cfgtbl[k] = Data
				end
			end
			parent.index = parent.index + 0.5
		elseif (type(v) == "string") then
			parent.items['_'..k] = vgui.Create("DLabel")
			parent.items['_'..k]:SetParent(parent)
			parent.items['_'..k]:SetPos(1, (parent.index * 20) + 4)
			parent.items['_'..k]:SetText(k..':')
			parent.items['_'..k]:SizeToContents()
			parent.items['_'..k]:SetTextColor(parent.TextColor)
			
			parent.items[k] = vgui.Create("DTextEntry")
			parent.items[k]:SetParent(parent)
			parent.items[k]:SetPos(parent.items['_'..k]:GetWide() + 10, (parent.index * 20))
			parent.items[k]:SetSize(80, 21)
			parent.items[k]:SetEditable(true)
			parent.items[k]:SetValue(v)
			parent.items[k].OnEnter = function()
				cfgtbl[k] = parent.items[k]:GetValue()
			end
		elseif (type(v) == "number") then
			parent.items[k] = vgui.Create("DNumSlider")
			parent.items[k]:SetParent(parent)
			parent.items[k]:SetPos(0, (parent.index * 20))
			parent.items[k]:SetWide(130)
			parent.items[k]:SetText(k)
			parent.items[k]:SetMinMax(0, v * 2)
			parent.items[k]:SetDecimals(0)
			parent.items[k]:SetValue(v)
			parent.items[k].ValueChanged = function(self, val)
				cfgtbl[k] = tonumber(val) or 0
			end
			parent.index = parent.index + 1.3
		end
		parent.index = parent.index + 1
	end
end

ubot.gui.MakeMenuDone = false
ubot.gui.MakeMenu = function()
	if (not ubot.gui.MakeMenuDone) then
		ubot.gui.frame = vgui.Create("DFrame")
		ubot.gui.frame:SetSize(200, 350)
		ubot.gui.frame:Center() --22px title bar
		ubot.gui.frame:SetTitle("Аимботик - гопик")
		ubot.gui.frame:SetDeleteOnClose(false)
		ubot.gui.frame:MakePopup()
		ubot.gui.frame:SetVisible(true)

		ubot.gui.sheet = vgui.Create("DPropertySheet")
		ubot.gui.sheet:SetParent(ubot.gui.frame)
		ubot.gui.sheet:SetPos(5, 24)
		ubot.gui.sheet:SetSize(190, 321)

		ubot.gui.aimbot = vgui.Create("DPanel")
		ubot.gui.aimbot.Paint = nil
		ubot.gui.cfg2gui(ubot.gui.aimbot, ubot.config.aimbot)
		ubot.gui.sheet:AddSheet("АИМ АЗАЗА", ubot.gui.aimbot, "gui/info", false, false, "НастроЙКи АИМА ")

		
		ubot.config.load()
		ubot.gui.MakeMenuDone = true
	end
end

ubot.gui.MakeMenu()