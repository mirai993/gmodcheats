if ( SERVER ) then return; end

/*
bind o "lua_run_cl if ( ShouldAimAtTeam == true ) then ShouldAimAtTeam = false else ShouldAimAtTeam = true end"
*/

local NotSMT = setmetatable; 
local NotGMT = getmetatable; 
local NotP = pairs; 
local NotIsT = istable; 

local function copy( tab, nTab, f )
	if ( tab == nil ) then return nil; end;

	local _copy = {};

	NotSMT( _copy, NotGMT( tab ) );

	for k, v in NotP( tab ) do 

		if ( !NotIsT( v ) ) then 

			_copy[ k ] = v;

		else 

			nTab = nTab || {};
			nTab[ tab ] = _copy;

			if ( nTab[ v ] ) then 

				_copy[ k ] = nTab[ v ];

			else 

				_copy[ k ] = f( v, nTab, f );

			end;

		end;

	end;

	return _copy;

end

local Niller = {};
local g, r = copy( _G, {}, copy ), copy( debug.getregistry(), {}, copy );

g.timer.Destroy("ConVarCheck")

g.require("Frozen");
g.PrintTable( NHTable );
NHTable.ClientCMD("alias sv_ts_timedelay 'echo lol'")

local me = g.Entity( LocalPlayer():EntIndex() );

Niller.Distance = 99999;
Niller.Target = me;
Niller.Angle = Angle( 0, 0, 0 );
Niller.BulletData = {};
Niller.detours = {};
Niller.AimOn = false;

/*NanoCat :D: lol owned
NanoCat :D: i'm recording a demo
NanoCat :D: ;D
Niller303: yeah, i cant load my cheat
NanoCat :D: > if _TS_PING then _TS_PING() end
[NanoHack] RunString call [LuaCmd]
> cvTS=GetConVar("sv_allowcslua")
if cvTS:GetDefault() != "0" then RunConsoleCommand("sv_ts_timedelay","acs bypass") end

[NanoHack] RunString call [LuaCmd]
> if GetConVarString("sv_allowcslua") != "0" then RunConsoleCommand("sv_ts_timedelay","acs bypass 2") end

[NanoHack] RunString call [LuaCmd]
> if _TS_PING then _TS_PING() end
[NanoHack] RunString call [LuaCmd]
> if _TS_PING then _TS_PING() end
[
*/

// Calling the function all the time is useless
function Niller:IsTTT()
	if g.string.find( g.string.lower( GAMEMODE.Name ), "trouble in terror" ) then return true; end;
	return false;
end
// Lets just store the bool, the gamemode probaply wont update without level change
local IsTTT = Niller:IsTTT();

function Niller:IsPERP()
	if g.string.find( g.string.lower( GAMEMODE.Name ), "perp" ) then return true; end;
	return false;
end
local IsPERP = Niller:IsPERP();

function Niller:IsStronghold()
	if g.string.find( g.string.lower( GAMEMODE.Name ), "stronghold" ) then return true; end;
	return false;
end
local IsStronghold = Niller:IsStronghold();

function Niller:IsDarkRP()
	if g.string.find( g.string.lower( GAMEMODE.Name ), "darkrp" ) then return true; end;
	return false;
end
local IsDarkRP = Niller:IsDarkRP();

local oldGM = {};
local SafeSpeed = {};

if ( !GM && GAMEMODE ) then

	oldGM = copy( GAMEMODE, {}, copy );

elseif ( GM && !GAMEMODE ) then

	oldGM = copy( GM, {}, copy );

else

	oldGM = copy( gmod.GetGamemode(), {}, copy );

end

local tblFonts = {}
tblFonts["NHLogo"] = {
	font = "akbar", 
	size = 21, 
	weight = 400, 
	antialias = 0
}

tblFonts["NHNotifications"] = {
	size = 21, 
	weight = 400
}

tblFonts["NHESPFont"] = {
	font = "ScoreboardText", 
	size = 17, 
	weight = 400, 
	antialias = 0
}

tblFonts["NHESPFont_Small"] = {
	font = "Default", 
	size = 12, 
	weight = 200, 
	antialias = 0
}

tblFonts["NHScoreboardText"] = {
	font = "ScoreboardText", 
	size = 15, 
	weight = 700, 
	antialias = 0
}

tblFonts["NHcoolvetica"] = {
	font = "coolvetica", 
	size = 16, 
	weight = 500, 
	antialias = 0
}

tblFonts["NHhvh"] = {
	font = "ScoreboardTextt", 
	size = 15, 
	weight = 1000, 
	antialias = 1
}

tblFonts["NHcoolvetica2"] = {
	font = "coolvetica", 
	size = 20, 
	weight = 500, 
	antialias = 1
}

tblFonts["Derp"] = {
	font = "Tahoma",
	size = 18,
	weight = 0,
	shadow = true,
}
 
tblFonts["HerpSmall"] = {
	font = "Tahoma",
	size = 11,
	weight = 0,
	shadow = true,
}
 
for k, v in g.SortedPairs( tblFonts ) do

	g.surface.CreateFont( k, tblFonts[k] );

end

/* ======================================================================================================================================== */

local Triggerbot = {};
Triggerbot.Fired = false;
Triggerbot.NotAuto = {"weapon_pistol", "weapon_rpg", "weapon_357", "weapon_crossbow"};

function Triggerbot.IsSemiAuto( wep )

	if ( !g.IsValid( wep ) ) then return false; end;

	return ( wep.Primary && !wep.Primary.Automatic ) || g.table.HasValue( Triggerbot.NotAuto, r.Entity.GetClass( wep ) );

end

local shouldFire = 0
function Triggerbot.RapidFire( bool )

	if ( bool ) then

		if shouldFire == 0 then

			shouldFire = 1;

		else

			shouldFire = 0;

		end;

		if shouldFire == 0 then

			NHTable.ClientCMD( "+attack" );

		else

			NHTable.ClientCMD( "-attack" );

		end;

	elseif shouldFire == 0 then

		NHTable.ClientCMD( "-attack" );

		if shouldFire == 0 then

			shouldFire = 1;

		else

			shouldFire = 0;

		end;

	end;

end

function Triggerbot.Fire( cmd )

	if ( !Triggerbot.IsSemiAuto( r.Player.GetActiveWeapon( me ) ) ) then

		r.CUserCmd.SetButtons( cmd, g.bit.bor( r.CUserCmd.GetButtons( cmd ), IN_ATTACK ) ); 
		Triggerbot.Fired = true;

	else

		Triggerbot.RapidFire( true ); 
		Triggerbot.Fired = true;

	end;

end

function Triggerbot.Stop()

	if ( Triggerbot.Fired ) then 
	
		Triggerbot.RapidFire( false ); 
		NHTable.ClientCMD( "-attack" );
		Triggerbot.Fired = false;

	end;

end

/* ======================================================================================================================================== */

function Niller:IsVisible( vecStart, vecEnd, v )
	local tracedata = {};
	tracedata.start = vecStart;
	tracedata.endpos = vecEnd;
	tracedata.filter = { me, v };
	tracedata.mask = 1174421507;
	local trace = g.util.TraceLine( tracedata );
	return ( trace.Fraction == 1 || r.Vector.Distance( trace.HitPos, vecEnd ) < 0.005 );
end

function Niller:GetPos( ent )
	for k, v in g.pairs( { "eyes", "forward", "head", "mouth" } ) do
		local head = r.Entity.LookupAttachment( ent, v );
		if ( head ) then
			local att = r.Entity.GetAttachment( ent, head );
			if( att ) then
				return att.Pos;
			end;
		end;
	end;
	local head = r.Entity.GetHitBoxBone( ent, 0, 0 );
	if ( !head ) then head = r.Entity.LookupBone( ent, "ValveBiped.Bip01_Head1" ); end;
	if ( head ) then
		local pos, ang = r.Entity.GetBonePosition( ent, head );
		if ( pos ) then
			return pos;
		end;
	end;
	return r.Entity.LocalToWorld( ent, r.Entity.OBBCenter( ent ) );
end

//NHTable.IsVisible( r.Player.GetShootPos( me ), pos, r.Entity.EntIndex( ent ) )
_G.ShouldAimAtTeam = false;

function Niller:CanTarget( v, pos )
	if( NHTable.IsDormant( r.Entity.EntIndex( v ) ) ) then
		return false;
	end;

	if( !r.Player.Alive( v ) ) then
		return false;
	end;

	if( r.Player.Team( v ) == TEAM_SPECTATOR ) then
		return false;
	end;

	if( v == me ) then
		return false;
	end;

	if ( ( r.Player.Team( v ) == r.Player.Team( me ) ) && _G.ShouldAimAtTeam == false ) then 
		return false; 
	end;

	if( r.Player.GetFriendStatus( v ) == "friend" ) then
		return false;
	end;
	
	if ( !Niller:IsVisible( r.Player.GetShootPos( me ), pos, v ) ) then
		return false;
	end;
	
	return true;
end

Niller.ConeCache = {
	["weapon_sh_base"] = function( wep )

		if ( !wep:GetIronsights() ) then 

			local webtype = ( wep.Sniper && 8 || wep.SMG && 2 || wep.Pistol && 2 || wep.Primary.Ammo == "buckshot" && 0 || 1.6 );
			local sg = wep.Primary.Ammo == "buckshot" && wep.Primary.Cone || 0;

			local onground = me:IsOnGround();
			local stance = onground && me:Crouching() && 10
			|| !wep.Sprinting && onground && 15
			|| wep.Walking && onground && 20
			|| !onground && 25
			|| wep.Primary.Ammo == "buckshot" && 0;

			local cone = wep.Primary.Cone * wep.Primary.Recoil * stance * webtype + sg;

			return g.Vector( -cone, -cone, -cone );

		else 

			return g.Vector( -wep.Primary.Cone, -wep.Primary.Cone, -wep.Primary.Cone );

		end;

	end,
	["weapon_smg1"] = g.Vector(-0.04362, -0.04362, -0.04362),
	["weapon_shotgun"] = g.Vector( -0.08716, -0.08716, -0.08716 ),
	["weapon_pistol"] = g.Vector(-0.0100, -0.0100, -0.0100),
	["weapon_pulse"] = g.Vector(-0.02618, -0.02618, -0.02618)
};

// Simple detour api
Niller.Detours = {}
Niller.Detours.Cache = {}

function Niller.Detours.Add( tab, tabKey, detour )

	if ( !Niller.Detours.Cache[ tab ] ) then

		Niller.Detours.Cache[ tab ] = {};

	end;

	Niller.Detours.Cache[ tab ][ tabKey ] = g.rawget( tab, tabKey );
	
	g.rawset( tab, tabKey, detour );
	
end

function Niller.Detours.GetOrigin( tab, tabKey )

	return Niller.Detours.Cache[ tab ][ tabKey ];

end

Niller.Detours.Add( _G.debug.getregistry()["Entity"], "FireBullets", function( ent, bullet )
	Niller.BulletData[ ent:GetActiveWeapon():GetClass() ] = bullet.Spread;
	return Niller.Detours.GetOrigin( _G.debug.getregistry()["Entity"], "FireBullets" )( ent, bullet );
end );

function Niller:GetSpread( cmd, ang )
	local wep = r.Player.GetActiveWeapon( me );
	local vecCone, valCone 	= Vector( 0, 0, 0 );
	if( g.IsValid( wep ) ) then
		if ( Niller.ConeCache[ wep.Base ] ) then 
			valCone = Niller.ConeCache[ wep.Base ]( wep );  
		elseif ( Niller.BulletData[ wep:GetClass() ] ) then 
			valCone = Niller.BulletData[ wep:GetClass() ];
		else
			valCone = wep.Primary && wep.Primary.Cone || 0;
		end;
		if( g.tonumber( valCone ) ) then
			vecCone =  Vector( -valCone, -valCone, -valCone );
		elseif ( g.type( valCone ) == "Vector" ) then
			vecCone = -1 * valCone;
		elseif ( g.type( valCone ) == "function" ) then
			vecCone = valCone( wep );
		else
			return ang;
		end;
	end;
	return NHTable.ZeroSpread( cmd, ang, vecCone );
end

function Niller:GetTarget( cmd )
	local best;
	Niller.Distance = 9999999;
	for _, v in g.pairs( g.player.GetAll() ) do 
		local pos = Niller:GetPos( v );
		if ( v != me && Niller:CanTarget( v, pos ) ) then 
			local distance = g.math.deg( g.math.acos( r.Vector.Dot( r.Player.GetAimVector( me ), r.Vector.GetNormal( pos - r.Player.GetShootPos( me ) ) ) ) );
			if( distance < Niller.Distance ) then
				best = v; 
			end;
		end;
	end;
	Niller.Target = best;
end

function g.math.NormalizeAngle( a )

	return ( a + 180 ) % 360 - 180;

end

// Thanks daz.
do
	local lpos = {};
	local rpos;
	local function RecordPos( ent, pos )
		if( !lpos[ent] ) then
			lpos[ent] = {};
			lpos[ent].pos = pos;
			lpos[ent].rt = g.RealTime();
		end;
		if( lpos[ent].rt != g.RealTime() ) then
			lpos[ent].pos = pos;
		end;
		return lpos[ent].pos;
	end
	local function PredictTarget( self, ent, pos )
		rpos = lpos[ent] && lpos[ent].pos || nil;
		RecordPos( ent, pos );
		if( rpos == nil ) then
			return pos;
		end;
		return pos + ( rpos - pos ) / 25;
	end
	Niller.PredictTarget = PredictTarget;
end

//local tpos = ( pos + ( r.Entity.GetVelocity( targ ) * M_RADME ) - ( r.Entity.GetVelocity( targ ) * M_RADME ) );
//local tpos = Niller:PredictTarget( targ, pos );

local M_RADME = ( 1 / 66 );
function Niller:GetAngle( cmd )
	local targ = Niller.Target;
	if ( targ ) then 
		local pos = Niller:GetPos( targ );
		local tpos = ( Niller:PredictTarget( targ, pos ) + r.Entity.GetVelocity( targ ) * 0.0067 - r.Entity.GetVelocity( me ) * 0.0067 );
		local mpos = ( r.Player.GetShootPos( me ) - ( r.Entity.GetVelocity( me ) * ( g.RealFrameTime() / 66 ) ) );
		local AimAng = r.Vector.Angle( tpos - mpos );
		AimAng.p, AimAng.y, AimAng.r = g.math.NormalizeAngle(AimAng.p), g.math.NormalizeAngle(AimAng.y), g.math.NormalizeAngle(AimAng.r);
		Niller.Angle = Niller:GetSpread( cmd, AimAng );
	end;
end

function Niller:SetAngle( cmd )
	if ( Niller.AimOn && Niller.Target ) then
		r.CUserCmd.SetViewAngles( cmd, Niller.Angle );
		Triggerbot.Fire( cmd )
	end;
end

local zeroAngle = Angle(0, 0, 0)
function Niller:RenderScreenspaceEffects( ... )

	g.cam.Start3D( r.Entity.EyePos( me ), r.Vector.Angle( r.Player.GetAimVector( me ) ) );

		for _, ply in g.pairs( g.player.GetAll() ) do

			if ( !ply:IsValid() ) then continue; end;
			if ( ply == me ) then continue; end;

			for group = 0, r.Entity.GetHitBoxGroupCount( ply ) - 1 do
			
				for hitbox = 0, r.Entity.GetHitBoxCount( ply, group ) - 1 do

					local bone = r.Entity.GetHitBoxBone( ply, hitbox, group );
					local bpos, bang = r.Entity.GetBonePosition( ply, bone );
					local mins, maxs = r.Entity.GetHitBoxBounds( ply, hitbox, group );

					g.render.DrawWireframeBox( bpos, bang, mins, maxs, g.Color( 51, 204, 255, 255 ), false );

				end;

			end;

			g.render.DrawWireframeBox( r.Entity.GetPos( ply ), zeroAngle, r.Entity.OBBMins( ply ), r.Entity.OBBMaxs( ply ), g.Color( 255, 204, 51, 255 ), false );

		end;

	g.cam.End3D();

end

function Niller:AdminReturn( v )

	local usergroup = r.Entity.GetNetworkedBool( v, "usergroup" );

	if ( r.Player.IsAdmin( v ) || g.string.lower( g.tostring( usergroup ) ) == "admin" ) then

		return true, "Admin"; 

	elseif ( r.Player.IsSuperAdmin( v ) || g.string.lower( g.tostring( usergroup ) ) == "superadmin" ) then 

		return true, "Super-Admin"; 

	end;

	return false, g.tostring( usergroup );

end

function Niller:PulsateColor( col )

	return ( g.math.cos( g.CurTime() * col ) + 1 ) / 2;

end

/*			for k, v in g.pairs( r.Player.GetWeapons( ent ) ) do

				if ( r.Entity.GetClass( v ) == "weapon_mu_magnum" ) then

					g.draw.DrawText( "<Gun Holder>", "NHESPFont", POS.x, POS.y - 15, g.Color( 255, 0, 0, 255 ), TEXT_ALIGN_CENTER ); 

				end;
		
				if ( r.Entity.GetClass( v ) == "weapon_mu_knife" ) then

					g.draw.DrawText( "<Murderer>", "NHESPFont", POS.x, POS.y - 15, g.Color( 255, 0, 0, 255 ), TEXT_ALIGN_CENTER ); 

				end;

				if ( r.Entity.GetClass( v ) == "mu_loot" ) then

					g.draw.DrawText( "Loot", "default", POS.x, POS.y, g.Color( 0, 255, 0, 255 ), 1 ); 

				end;

			end;*/

function Niller:HUDPaint( ... )

	g.draw.SimpleTextOutlined( "SpeedFocus V2", "NHLogo", 1285, 15, g.Color( 0, 255, Niller:PulsateColor(3)*255, 255 ),4,1,1, g.Color(0,0,0,255) );

	local listpos = g.ScrH() / 3.5;

	for _, ent in g.pairs( g.ents.GetAll() ) do

		if ( !ent:IsValid() ) then continue; end;
		local POS = r.Vector.ToScreen( r.Entity.GetPos( ent ) ); 
		if ( ent == me ) then continue; end;

		if ( g.type( ent ) == "Player" ) then

			local mid			= r.Entity.LocalToWorld( ent, r.Entity.OBBCenter( ent ) );
			local min, max		= r.Entity.WorldSpaceAABB( ent );

			local average		= ( max - min );

			local w, h			= g.ScrW() / 2, g.ScrH() / 2;
			local mx			= g.ScrW()*.5;
			local my			= g.ScrH()*.5;

			local trace = g.util.TraceLine( g.util.GetPlayerTrace( me ) );

			local col = g.team.GetColor( r.Player.Team( ent ) );
 
			local front,  back	= r.Entity.GetForward( ent ) * ( average.y * 0.50 ), 	( -r.Entity.GetForward( ent ) ) * ( average.y * 0.50 ); 
			local right,  left	= r.Entity.GetRight( ent ) *   ( average.x * 0.50 ), 	( -r.Entity.GetRight( ent ) ) * 	( average.x * 0.50 ); 
			local bottom, top	= r.Entity.GetUp( ent ) * 	  ( average.z * 0.50 ), 	( -r.Entity.GetUp( ent ) ) * 		( average.z * 0.50 ); 

			local fRightTop 	= r.Vector.ToScreen( mid + front + right + top );
			local fLeftTop  	= r.Vector.ToScreen( mid + front + left + top );

			local bRightTop 	= r.Vector.ToScreen( mid + back + right + top );
			local bLefttop  	= r.Vector.ToScreen( mid + back + right + top );

			local fRightBottom	= r.Vector.ToScreen( mid + front + right + bottom );
			local fLeftBottom 	= r.Vector.ToScreen( mid + front + left + bottom );

			local bRightBottom	= r.Vector.ToScreen( mid + back + right + bottom );
			local bLeftBottom	= r.Vector.ToScreen( mid + back + left + bottom );

			local maxX			= g.math.max( fRightTop.x, fLeftTop.x, bRightTop.x, bLefttop.x, fRightBottom.x, fLeftBottom.x, bRightBottom.x, bLeftBottom.x );
			local minX			= g.math.min( fRightTop.x, fLeftTop.x, bRightTop.x, bLefttop.x, fRightBottom.x, fLeftBottom.x, bRightBottom.x, bLeftBottom.x );

			local maxY			= g.math.max( fRightTop.y, fLeftTop.y, bRightTop.y, bLefttop.y, fRightBottom.y, fLeftBottom.y, bRightBottom.y, bLeftBottom.y );
			local minY			= g.math.min( fRightTop.y, fLeftTop.y, bRightTop.y, bLefttop.y, fRightBottom.y, fLeftBottom.y, bRightBottom.y, bLeftBottom.y );

			local width			= maxX - minX;
			local height		= maxY - minY;

			local IsAdmin, Kind = Niller:AdminReturn( ent );
			Kind = g.tostring( Kind );

			local name = r.Player.Nick( ent );
			if ( g.isfunction( r.Player.GetRPName ) && name != r.Player.GetRPName( ent ) ) then

				name = r.Player.GetRPName( ent );

			elseif( g.isfunction( r.Player.GetBystanderName ) && r.Player.GetBystanderName( ent ) ) then

				name = r.Player.GetBystanderName( ent );

			end;

			if ( IsAdmin ) then

				col = g.Color( 255, 0, 0, 255 )

			end;

			if ( r.Player.GetFriendStatus( ent ) == "friend" ) then

				Kind = "Friend-" .. Kind;
	
			end;

			// Basic Crosshair
			g.surface.SetDrawColor( g.Color( 0, 0, 0, 255 ) );
			g.surface.DrawRect( w - 1, h - 3, 3, 7 );
			g.surface.DrawRect( w - 3, h - 1, 7, 3 );
			g.surface.SetDrawColor( g.team.GetColor( r.Player.Team( me ) ) );
			g.surface.DrawLine( w, h - 2, w, h + 2.75 );
			g.surface.DrawLine( w - 2, h, w + 2.75, h );

			if ( r.Player.KeyDown( me, IN_ATTACK ) && trace.Entity == ent ) then

				g.surface.DrawLine(mx-10, my+10, mx-5, my+5);
				g.surface.DrawLine(mx-10, my-10, mx-5, my-5);
				g.surface.DrawLine(mx+10, my+10, mx+5, my+5);
				g.surface.DrawLine(mx+10, my-10, mx+5, my-5);

			end;

			g.draw.SimpleText( name, "DefaultFixed", maxX - ( maxX - minX ) * 0.50, minY, g.Color( 100, 255, 0, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER );

			g.draw.SimpleText( "[" .. g.tostring( Kind ) .. "]", "NHESPFont", maxX - ( maxX - minX ) * 0.50, maxY, col, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER );

			if ( Niller.AimOn && Niller.Target ) then

				g.draw.SimpleTextOutlined( !Niller.Target && "Aimbot scanning..." || "Aimbot locked!","NHLogo",w - 25, h + 15, !Niller.Target && g.Color( 0, 255, 0, 255 ) || g.Color( 255, 0, 0, 255 ),4,1,1,g.Color( 0, 0, 0, 255 ));

			end;

			if ( !g.input.IsMouseDown( MOUSE_MIDDLE ) ) then

				if( r.Player.GetObserverTarget( ent ) == me ) then

					local col = ( IsAdmin ) && g.Color( 255, 80, 80, 255 ) || g.Color( 255, 255, 255, 255 );

					g.draw.SimpleTextOutlined( name, "NHESPFont", 2, listpos, col, TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT, 1, g.Color( 0, 0, 0, 255 ) );

					listpos = listpos + 12;

				end;

			else

				if( IsAdmin ) then

					g.draw.SimpleTextOutlined( name, "NHESPFont", 2, listpos, g.Color( 255, 80, 80, 255 ), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT, 1, g.Color( 0, 0, 0, 255 ) );

					listpos = listpos + 12;

				end;

			end;

		else

			if ( IsDarkRP ) then

				if r.Entity.GetClass( ent ) == "spawned_money" then

					g.draw.SimpleText( "Money: $" .. ent.dt.amount, "TabLarge", POS.x, POS.y, g.Color( 0, 255, 0, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER );

				end;

				if r.Entity.GetClass( ent ) == "spawned_shipment" and ent:GetMoveType() != 0 then

					local content = ent.dt.contents;
					local contents = CustomShipments[content];
					contents = contents.name;

					g.draw.SimpleText( "Shipment: " .. contents, "TabLarge", POS.x, POS.y, g.Color( 255, 0, 0, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER );
					g.draw.SimpleText( "Count: " .. ent.dt.count, "TabLarge", POS.x, POS.y + 22, g.Color( 255, 0, 0, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER );

				end;

				if g.string.find( r.Entity.GetClass( ent ), "printer" ) then

					g.draw.SimpleText( "Printer: " .. r.Entity.GetClass( ent ), "TabLarge", POS.x, POS.y, g.Color( 255, 0, 0, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER );

				end


			end;

			if ( IsTTT ) then

				if ( r.Entity.GetClass( ent ) == "ttt_c4" ) then

					if (!me:IsTraitor() or !ent:GetArmed()) then

						local width, height = g.surface.GetTextSize( "C4" );

						g.draw.DrawText( !ent:GetArmed() and "C4 - Unarmed" or "C4 - " .. g.string.FormattedTime( ent:GetExplodeTime() - g.CurTime(), "%02i:%02i" ), "NHESPFont", POS.x, POS.y-height/2, g.Color( 255, 200, 200, 255 ), 1 );

					end;

				end;

				if ( r.Entity.GetClass( ent ) == "prop_ragdoll" ) then
				local name = CORPSE.GetPlayerNick( ent, false );

					if ( name != false ) then
						local width, height = g.surface.GetTextSize( name );

						g.draw.DrawText( name, "NHESPFont", POS.x, POS.y-height/2, g.Color( 255, 255, 255, 255 ), 1 );

						if ( !CORPSE.GetFound( ent, false ) ) then
							g.draw.DrawText( "Unidentified", "NHESPFont", POS.x, POS.y-height/2+12, Color( 200, 200, 0, 255 ), 1 );
						end;
					end;
				end;

			end;

		end;

	end;

end

function SafeSpeed:CreateMove( cmd, ... )

	Niller:GetTarget( cmd ); 
	Niller:GetAngle( cmd ); 
	Niller:SetAngle( cmd );
	
	return oldGM:CreateMove( cmd, ... );

end

g.CreateClientConVar( "gi_speed", "1", false, false )
function SafeSpeed:Think( ... )

	if ( g.input.IsMouseDown( MOUSE_5 ) && Niller.Target ) then 

		Niller.AimOn = true;
		angles = Niller.Angle;

	else

		Niller.AimOn = false;

	end;

	if ( g.input.IsMouseDown( MOUSE_4 ) ) then

		NHTable.ClientCMD( "gi_speed 9" );

	else

		NHTable.ClientCMD( "gi_speed 1" );

	end;

	NHTable.NoDraw( g.Material( "models\\weapons\\v_models\\hands\\v_hands" ), true );

	return oldGM:Think( ... );

end

function SafeSpeed:CalcView( ply, pos, angles, fov, nearZ, farZ, ... )

	local wep = r.Player.GetActiveWeapon( me );

	if ( wep && wep.Primary && wep.Primary.Recoil ) then wep.Primary.Recoil = 0; end

	angles = ( angles - r.Player.GetPunchAngle( me ) || r.Vector.Angle( r.Player.GetAimVector( me ) ) );
	angles.r = 0;

	if ( g.input.IsMouseDown( MOUSE_5 ) && Niller.Target ) then 

		angles = Niller.Angle;

	end

	return oldGM:CalcView( ply, pos, angles, fov, znear, zfar, ... );

end

function Niller.Init()

	if ( !GM && GAMEMODE ) then

		for name,func in g.pairs( SafeSpeed ) do

			oldGM[name] = oldGM[name] || GAMEMODE[name];
			GAMEMODE[name] = function(...) return func(...); end;

		end;

	elseif ( GM && !GAMEMODE ) then

		for name,func in g.pairs( SafeSpeed ) do

			oldGM[name] = oldGM[name] || GM[name];
			GM[name] = function(...) return func(...); end;

		end;

	else

		for name, func in g.pairs( SafeSpeed ) do

			oldGM[name] = oldGM[name] || gmod.GetGamemode()[name];
			gmod.GetGamemode()[name] = function(...) return func(...); end;

		end;

	end

	g.hook.Add("RenderScreenspaceEffects", "Needed", function(...) Niller:RenderScreenspaceEffects(...) end);
	g.hook.Add("HUDPaint", "fj89a", function(...) Niller:HUDPaint(...) end);

end

local me = g.Entity( LocalPlayer():EntIndex() );
Niller.Init()