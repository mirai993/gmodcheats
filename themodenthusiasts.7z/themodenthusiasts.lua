// ttt hack pack made by TheModEnthusiast
LocalPlayer():ChatPrint("Welcome To TheModEnthusiasts First TTT MultiHack V0.1")
LocalPlayer():ChatPrint("Names Loaded")
hook.Add( "HUDPaint", "Wallhack", function()
 
	for k,v in pairs (player.GetAll()) do
	if GetConVarNumber("Wallhack") >= 1 then
                        if v ~= LocalPlayer() then
		if LocalPlayer():Alive() then
		local Position = ( v:GetPos() + Vector( 0,0,80 ) ):ToScreen()
		draw.DrawText( v:Name(), "ChatFont", Position.x, Position.y, Color( 10, 255, 0, 255 ), 1 )
		else
		
end
end
end
end
end)
CreateClientConVar("Wallhack", 1, true, false)


print("ESP Loaded")
LocalPlayer():ChatPrint("BoxESP Loaded")
LocalPlayer():ChatPrint("Wireframe Loaded")
LocalPlayer():ChatPrint("Please Enjoy")
local function MESPCheck(v)
	if v:Alive() == true && v:Health() ~= 0 && v:Health() >= 0 && v ~= LocalPlayer() && LocalPlayer():Alive() then
		return true
	else
		return false
	end
end


hook.Add( "HUDPaint", "aimbot.Wallhack", function()
for k,v in pairs ( player.GetAll() ) do
 
        local Position = ( v:GetPos() + Vector( 0,0,80 ) ):ToScreen()
        local Name = ""
 
        if v == LocalPlayer() then Name = "" else Name = v:Name() end
 
end
 
end )
 
local shouldDraw = true
 
local hzCross = CreateClientConVar("HZ_Crosshair","0",false)
 
function Crosshair1()
surface.SetDrawColor(team.GetColor(LocalPlayer():Team()))
surface.DrawLine(ScrW() / 2 - 10, ScrH() / 2, ScrW() / 2 + 11 , ScrH() / 2)
surface.DrawLine(ScrW() / 2 - 0, ScrH() / 2 - 10, ScrW() / 2 - 0 , ScrH() / 2 + 11)
end
hook.Add("HUDPaint","CustomCross",Crosshair1)

local function coordinates( ent )
local min, max = ent:OBBMins(), ent:OBBMaxs()
local corners = {
        Vector( min.x, min.y, min.z ),
        Vector( min.x, min.y, max.z ),
        Vector( min.x, max.y, min.z ),
        Vector( min.x, max.y, max.z ),
        Vector( max.x, min.y, min.z ),
        Vector( max.x, min.y, max.z ),
        Vector( max.x, max.y, min.z ),
        Vector( max.x, max.y, max.z )
}
 
local minX, minY, maxX, maxY = ScrW() * 2, ScrH() * 2, 0, 0
for _, corner in pairs( corners ) do
        local onScreen = ent:LocalToWorld( corner ):ToScreen()
        minX, minY = math.min( minX, onScreen.x ), math.min( minY, onScreen.y )
        maxX, maxY = math.max( maxX, onScreen.x ), math.max( maxY, onScreen.y )
end
 
return minX, minY, maxX, maxY
end
hook.Add("HUDPaint", "Example", function()
for k,v in pairs(player.GetAll()) do
        local x1,y1,x2,y2 = coordinates(v)
         print(tostring(team.GetColor(v:Team())))
         surface.SetDrawColor(color_white)
 
 
        surface.DrawLine( x1, y1, math.min( x1 + 5, x2 ), y1 )
        surface.DrawLine( x1, y1, x1, math.min( y1 + 5, y2 ) )
 
 
        surface.DrawLine( x2, y1, math.max( x2 - 5, x1 ), y1 )
        surface.DrawLine( x2, y1, x2, math.min( y1 + 5, y2 ) )
 
 
        surface.DrawLine( x1, y2, math.min( x1 + 5, x2 ), y2 )
        surface.DrawLine( x1, y2, x1, math.max( y2 - 5, y1 ) )
 
 
        surface.DrawLine( x2, y2, math.max( x2 - 5, x1 ), y2 )
        surface.DrawLine( x2, y2, x2, math.max( y2 - 5, y1 ) )
end
end)

local struc = {}
struc.pos = {}
struc.pos[1] = 100 -- x pos
struc.pos[2] = 200 -- y pos
struc.color = Color(255,0,0,255) -- Red
struc.text = "Hello World" -- Text
struc.font = "DefaultFixed" -- Font
struc.xalign = TEXT_ALIGN_CENTER -- Horizontal Alignment
struc.yalign = TEXT_ALIGN_CENTER -- Vertical Alignment
draw.Text( struc )

LocalPlayer():ChatPrint("Norecoil Loaded")
hook.Add("Think", "NoRecoil", function()
    if LocalPlayer() and LocalPlayer():GetActiveWeapon() and LocalPlayer():GetActiveWeapon().Primary then
        LocalPlayer():GetActiveWeapon().Primary.Recoil = 0
    end
end )



LocalPlayer():ChatPrint("Aimbot Loaded")
function aimbot()
CreateClientConVar( "aa_enabled", 0, true, false )
if ConVarExists( "aa_enabled" ) and GetConVar("aa_enabled"):GetInt() == 1 then
local ply = LocalPlayer()
local trace = util.GetPlayerTrace( ply )
local traceRes = util.TraceLine( trace )
if traceRes.HitNonWorld then
local target = traceRes.Entity
if target:IsPlayer() then
local targethead = target:LookupBone("ValveBiped.Bip01_Head1")
local targetheadpos,targetheadang = target:GetBonePosition(targethead)
ply:SetEyeAngles((targetheadpos - ply:GetShootPos()):Angle())
end
end
end
end
hook.Add("Think","aimbot",aimbot)


LocalPlayer():ChatPrint("Bunnyhop Loaded")
LocalPlayer():ChatPrint("Fullbright Loaded")
local ihop = true
hook.Add("Think", "ihop", function()
if ihop then
     if (input.IsKeyDown( KEY_SPACE ) ) then
        if LocalPlayer():IsOnGround() then
            RunConsoleCommand("+jump")
            HasJumped = 1
        else
            RunConsoleCommand("-jump")
            HasJumped = 0
        end
    elseif ihop and LocalPlayer():IsOnGround() then
        if HasJumped == 1 then
            RunConsoleCommand("-jump")
            HasJumped = 0
        end
    end
end
end)

concommand.Add("ihop_toggle", function()
if ihop then
    ihop = !ihop
    LocalPlayer():ChatPrint("iHop turned OFF")
else
    ihop = !ihop
    LocalPlayer():ChatPrint("iHop turned ON")
end
end)


LocalPlayer():ChatPrint("Traitor Finder Loaded")
local matOverlay = Material( "sprites/glow08" )
local matTraitor = Material( "sprites/dot" )
local twep = { "weapon_ttt_c4", "weapon_ttt_knife", "weapon_ttt_phammer", "weapon_ttt_sipistol", "weapon_ttt_flaregun", "weapon_ttt_push", "weapon_ttt_radio", "weapon_ttt_teleport", "(Disguise)" ,"spiderman's_swep", "weapon_ttt_trait_defilibrator", "weapon_ttt_xbow", "weapon_ttt_dhook", "weapon_awp", "weapon_jihadbomb", "weapon_ttt_knife", "weapon_ttt_c4", "weapon_ttt_decoy", "weapon_ttt_flaregun", "weapon_ttt_phammer", "weapon_ttt_push", "weapon_ttt_radio", "weapon_ttt_sipistol", "weapon_ttt_teleport", "weapon_ttt_awp", "weapon_ttt_silencedsniper", "weapon_ttt_turtlenade", "weapon_ttt_death_station", "weapon_ttt_sg552", "weapon_ttt_tripmine"}

for _,v in pairs(player.GetAll()) do
        v.HatTraitor = nil
end
for _,v in pairs(ents.GetAll()) do
        v.HatESPTracked = nil
end

hook.Add("PostDrawOpaqueRenderables", "wire_animations_idle", function()
        if GAMEMODE.round_state != ROUND_ACTIVE then
                for _,v in pairs(player.GetAll()) do
                        v.HatTraitor = nil
                end
                for _,v in pairs(ents.GetAll()) do
                        v.HatESPTracked = nil
                end
                return
        end
        for _,v in pairs( ents.GetAll() ) do
                if v and IsValid(v) and (table.HasValue(twep, v:GetClass()) and !v.HatESPTracked) then
                        local pl = v.Owner
                        if pl and IsValid(pl) and pl:IsTerror() then
                                if pl:IsDetective() then
                                        v.HatESPTracked = true
                                else
                                        v.HatESPTracked = true
                                        pl.HatTraitor = true
                                        chat.AddText( pl, Color(255,125,0), " is a ",Color(255,0,0), "TRAITOR",Color(255,125,0), " with a ",Color(255,0,0),v:GetClass().."!")
                                end
                        end
                end
        end
          
  

end)