

/*Hemi Hacks by: Hemirox*/

local version = "3.00"
local lastupdated = "2/9/13"


/*---------Variables---------*/

local oH = table.Copy( hook )

/*Localize ERRYTHING*/
local G = table.Copy( _G )

local math = G.math
local string = G.string
local hook = G.hook
local table = G.table
local timer = G.timer
local surface = G.surface
local concommand = G.concommand
local cvars = G.cvars
local ents = G.ents
local player = G.player
local team = G.team
local util = G.util
local draw = G.draw
local usermessage = G.usermessage
local vgui = G.vgui
local http = G.http
local cam = G.cam
local render = G.render
local MsgN = G.MsgN
local Msg = G.Msg
local Vector = G.Vector
local Angle = G.Angle
local pairs = G.pairs
local ipairs = G.ipairs
local CreateSound = G.CreateSound
local setmetatable = G.setmetatable
local Sound = G.Sound
local print = G.print
local pcall = G.pcall
local type = G.type
local LocalPlayer = G.LocalPlayer
util.KeyValuesToTable = G.util.KeyValuesToTable
util.TableToKeyValues = G.util.TableToKeyValues
local Color = G.Color
local CreateClientConVar = G.CreateClientConVar
local ErrorNoHalt = G.ErrorNoHalt
local IsValid = G.IsValid
local MOVETYPE_OBSERVER = G.MOVETYPE_OBSERVER
local MOVETYPE_NONE = G.MOVETYPE_NONE
local CreateMaterial = G.CreateMaterial
local tonumber = G.tonumber
local tostring = G.tostring
local CurTime = G.CurTime
local TEXT_ALIGN_LEFT = G.TEXT_ALIGN_LEFT
local TEXT_ALIGN_TOP = G.TEXT_ALIGN_TOP
local TEXT_ALIGN_RIGHT = G.TEXT_ALIGN_RIGHT
local TEXT_ALIGN_BOTTOM = G.TEXT_ALIGN_BOTTOM
local IN_JUMP = G.IN_JUMP
local IN_FORWARD = G.IN_FORWARD
local IN_BACK = G.IN_BACK
local IN_MOVERIGHT = G.IN_MOVERIGHT
local IN_MOVELEFT = G.IN_MOVELEFT
local IN_SPEED = G.IN_SPEED
local IN_DUCK = G.IN_DUCK
local FrameTime = G.FrameTime
local ScrW = G.ScrW
local ScrH = G.ScrH
local TEAM_SPECTATOR = 1002
local SetClipboardText = G.SetClipboardText
local render = G.render
render.MaterialOverride = G.render.MaterialOverride
local GetHostName = G.GetHostName
local unpack = G.unpack
local AddConsoleCommand = G.AddConsoleCommand
local RunConsoleCommand = G.RunConsoleCommand
local debug = G.debug

local R = debug.getregistry()

require('hemihackv3')

local HH = {}
HH.BH = {}

/*Module Functions*/
HH.ForceCvar = HH_ForceCvar
HH.SetSteamName = HH_SetName
HH.Print = HH_Print
HH.SetMyAngles = R.CUserCmd.SetViewAngles
HH.PredictSeed = HH_PredictSeed
HH.ManipulateShot = HH_ManipulateShot
HH.ReadFile = HH_ReadFile
HH.WriteFile = HH_WriteFile
HH.SetSpeed = HH_Speed

HH_ForceCvar = nil
HH_SetName = nil
HH_Print = nil
HH_PredictSeed = nil
HH_ManipulateShot = nil
HH_ReadFile = nil
HH_WriteFile = nil
HH_Speed = nil

/*Static Variables*/
HH.AimbotIsOn = false
HH.IsLocked = false
HH.LockedPlayer = nil
HH.BHop = false
HH.Me = nil
HH.LastReload = 0
HH.Friends = util.KeyValuesToTable( HH.ReadFile( "hemihack/hh_friends.txt" ) )
HH.Teams = util.KeyValuesToTable( HH.ReadFile( "hemihack/hh_teams.txt" ) )
HH.CustomEnts = util.KeyValuesToTable( HH.ReadFile( "hemihack/hh_ents.txt" ) )
HH.TargetBone = HH.ReadFile( "hemihack/hh_bone.txt" ) != "" and HH.ReadFile( "hemihack/hh_bone.txt" ) or "ValveBiped.Bip01_Head1"
HH.BH.Hops = 0
HH.BH.MaxSpeed = 0
HH.MenuCreated = false
HH.Loaded = true
HH.BaseColor = Color( 200, 100, 10, 255 )
HH.CvarSaves = util.KeyValuesToTable( HH.ReadFile( "hemihack/hh_config.txt" ) )

function HH.RandomString( internal )
	local len = math.random( 10, 20 )
	local ret = ""       
	for i = 1 , len do
		ret = ret .. string.char( math.random( 97, 122 ) )
	end		
	if( !internal ) then
		ret = HH.InternalCmd .. ret
	end
   
	return ret
end
HH.InternalCmd = HH.RandomString( true )

 /*Hooks*/
HH.Hooks = {}
function HH.AddHook( name , func )
	local index = HH.RandomString()
	HH.Hooks[ index ] = {}
	HH.Hooks[ index ].func = func
	HH.Hooks[ index ].type = name

	hook.Add( name, index, function( ... )
		if( !HH or !IsValid( HH.Me ) or HH.Me != LocalPlayer() ) then return end
		local isok, ret = pcall( HH.Hooks[ index ].func , ... )
	   
		if ret != nil then
			//print(tostring(ret))
			return ret
		end
	end )
end

/*Timers*/
HH.Timers = {}
function HH.AddTimer( sec, rep, func )
	local index = HH.RandomString()
	
	HH.Timers[ index ] = sec
	
	timer.Create( index, sec, rep, func )
end

/*Convars*/
HH.Vars = {}
function HH.AddConvar( name, default, save )
	local index = HH.RandomString()
	HH.Vars[ name ] = {}	
	HH.Vars[ name ].Index = index
	HH.Vars[ name ].CanSave = save
	
	if( HH.CvarSaves[ name ] ) then 
		default = HH.CvarSaves[ name ]
	end
	HH.Vars[ name ].Val = default
	
	local cvar = CreateClientConVar( index, default, false, false )
	cvars.AddChangeCallback( index, function( CVar, PreviousValue, NewValue )
		for k, v in pairs( HH.Vars ) do
			if( v.Index and v.Index == CVar ) then
				HH.Vars[ k ].Val = NewValue
				HH.SaveVars()
			end
		end
	end )
	return cvar
end

function HH.SaveVars()
	local vars = {}
	for k, v in pairs( HH.Vars ) do
		if( v.CanSave ) then
			vars[ k ] = v.Val
		end
	end
	HH.WriteFile( "hemihack/hh_config.txt", util.TableToKeyValues( vars ) )
end

function HH.GetRawConvar( name )
	if( HH.Vars[ name ] ) then
		return HH.Vars[ name ].Index
	end
end

/*Con Commands*/
function HH.AddCMD( name, func )
	concommand.Add( name, func )
end

/*Client Changeable Vars*/
HH.AutoShoot = 				HH.AddConvar( "hh_autoshoot", "1", true )
HH.MaxAimAngle = 			HH.AddConvar( "hh_maxangle", "90", true )
HH.CheckLos = 					HH.AddConvar( "hh_checklos", "1", true )
HH.IgnoreSteamFriends = 	HH.AddConvar( "hh_ignoresteamfriends", "1", true )
HH.ESPEnabled = 				HH.AddConvar( "hh_espenabled", "1", true )
HH.ShowPlayers =				HH.AddConvar( "hh_showplayers", "1", true )
HH.ShowEnts = 				HH.AddConvar( "hh_showents", "1", true )
HH.ESPDist = 					HH.AddConvar( "hh_espdist", "2500", true )
HH.CustomBone = 			HH.AddConvar( "hh_custombone", "0", true )
HH.DrawCrosshair = 			HH.AddConvar( "hh_crosshair", "1", true )
HH.ShowAdmins = 			HH.AddConvar( "hh_showadmins", "1", true )
HH.AutoReload = 				HH.AddConvar( "hh_autoreload", "1", true )
HH.ShowLaserEyes = 		HH.AddConvar( "hh_lasereyes", "1", true )
HH.FriendsBlackList = 		HH.AddConvar( "hh_friendsblacklist", "0", true )
HH.TeamsBlackList = 			HH.AddConvar( "hh_teamsblacklist", "0", true )
HH.IgnoreFriends = 			HH.AddConvar( "hh_ignorefriends", "0", true )
HH.IgnoreTeams = 			HH.AddConvar( "hh_ignoreteams", "0", true )
HH.IgnoreOwnTeam = 		HH.AddConvar( "hh_ignoreownteam", "0", true )
HH.NoRecoil = 					HH.AddConvar( "hh_norecoil", "1", true )
HH.WallHackEnabled = 		HH.AddConvar( "hh_wallhack", "0", true )
HH.WallHackSolid = 			HH.AddConvar( "hh_solidwallhack", "1", true )
HH.Chams = 					HH.AddConvar( "hh_chams", "1", true )
HH.IgnoreAdmins = 			HH.AddConvar( "hh_ignoreadmins", "0", true )
HH.ClientNoclip = 				HH.AddConvar( "hh_clientnoclip", "0", true )
HH.CNSpeed = 				HH.AddConvar( "hh_clientnoclipspeed", "10", true )
HH.ThirdPerson = 				HH.AddConvar( "hh_thirdperson", "0", true )
HH.ThirdDist = 					HH.AddConvar( "hh_thirdpersondist", "10", true )
HH.SpeedHackSpeed = 		HH.AddConvar( "hh_speedhackspeed", "5.0", true )
HH.AntiAfkEnabled = 		HH.AddConvar( "hh_antiafkkicker", "0", false )
HH.NoSpreadEnabled = 	HH.AddConvar( "hh_nospread", "1", true )
HH.NameChanger = 			HH.AddConvar( "hh_namechanger", "0", false )
HH.ShowTraitors = 			HH.AddConvar( "hh_showtraitors", "1", true )
HH.OnlyTargetTraitors = 	HH.AddConvar( "hh_targettraitors", "0", true )
HH.LeftShoulder = 			HH.AddConvar( "hh_tpleftshoulder", "0", true )
HH.TargetNPCs = 				HH.AddConvar( "hh_targetnpcs", "0", true )
HH.AntiSnap = 					HH.AddConvar( "hh_antisnap", "0", true )
HH.AntiSnapSpeed =	 		HH.AddConvar( "hh_antisnapspeed", "10", true )
HH.ShowConCommands = HH.AddConvar( "hh_showccs", "1", true )
HH.BlockRunCC = 				HH.AddConvar( "hh_blockccs", "0", true )
HH.DrawBonesESP = 			HH.AddConvar( "hh_drawbones", "0", true )
HH.BoxESP = 					HH.AddConvar( "hh_boxesp", "0", true )

/*Valid Bones*/
HH.ValidBones = {
"ValveBiped.Bip01_Head1",
"ValveBiped.Bip01_Spine",
"ValveBiped.Bip01_Spine2",
"ValveBiped.Bip01_Pelvis",
"ValveBiped.Bip01_L_Hand",
"ValveBiped.Bip01_R_Hand",
"ValveBiped.Bip01_L_Thigh",
"ValveBiped.Bip01_R_Thigh",
"ValveBiped.Bip01_L_Calf",
"ValveBiped.Bip01_R_Calf",
"ValveBiped.Bip01_L_Foot",
"ValveBiped.Bip01_R_Foot",
}

HH.InvalidEnts = {
"player",
"prop_physics",
"viewmodel",
}

//surface.CreateFont ( "ScoreboardText", 15, 700, true, false, "HHScoreboardText" )
//surface.CreateFont( "ScoreboardText" , 15 , 1000, true , false, "HHFont" )
//surface.CreateFont( "ScoreboardText" , 13 , 500, true , false, "HHFontSmall" )
//surface.CreateFont ( "akbar", 25, 600, true, false, "HHLogo" )

surface.CreateFont( "HHScoreboardText", { size = 18,	weight = 100, antialias = true,	shadow = false,	font = "coolvetica" } )
surface.CreateFont( "HHFont", { size = 15, weight = 200, antialias = true, shadow = false, font = "coolvetica" } )
surface.CreateFont( "HHFontSmall", { size = 13, weight = 10, antialias = true, shadow = false, font = "coolvetica" } )
surface.CreateFont( "HHLogo", { size = 25, weight = 600, antialias = true, shadow = false, font = "akbar" } )
surface.CreateFont( "ScoreboardText", { size = 13, weight = 300, antialias = true, shadow = false, font = "coolvetica" } )


/*---------Security---------*/
/*Block RunConsoleCommand/Player:ConCommand()*/
HH.blacklist = {

}

HH.hidden = {
	"_ping",
	"cnc",
	"wire_keyboard_press",
	HH.InternalCmd,
}
/*
local RunCC  = RunConsoleCommand
local PlayerCC  = _R.Player.ConCommand
	
function RunConsoleCommand( cmd, ... )
	if( !HH ) then return RunCC( cmd, ... ) end
	local args = { ... }
	local vars = ""
	if( #args > 0 ) then
		vars = tostring( unpack( args ) )
	end
   
   if( string.find( cmd, HH.InternalCmd ) ) then
		return RunCC( cmd, ... )
	end
		
	if( table.HasValue( HH.blacklist, cmd ) or HH.BlockRunCC:GetBool() ) then
		HH.Print( "[HH] RunConsoleCommand Blocked: " .. cmd .. " " .. vars .. "\n" )
		return
	end

	if( HH.ShowConCommands:GetBool() and ( string.Left( cmd, 1 ) != "+" and string.Left( cmd, 1 ) != "-" ) ) then
		if( !table.HasValue( HH.hidden, cmd ) ) then
			HH.Print( "[HH] RunConsoleCommand: " .. cmd .. " " .. vars .. "\n"  )
		end
	end
	
	return RunCC( cmd, ... )
end

function _R.Player.ConCommand( ply, cmd )
	if( !HH ) then return PlayerCC( ply, cmd ) end
	
	if( string.find( cmd, HH.InternalCmd ) ) then
		return PlayerCC( ply, cmd )
	end
   
	if( table.HasValue( HH.blacklist, cmd ) or HH.BlockRunCC:GetBool() ) then
		HH.Print( "[HH] PlayerConCommand Blocked: " .. cmd .. "\n" )
		return
	end
	
	if( HH.ShowConCommands:GetBool() and ( string.Left( cmd, 1 ) != "+" and string.Left( cmd, 1 ) != "-" ) ) then
		if( !table.HasValue( HH.hidden, cmd ) ) then
			HH.Print( "[HH] Player:ConCommand: " .. cmd .. "\n" )
		end
	end
	
	return PlayerCC( ply, cmd )
end*/


/*---------Functions---------*/

/*Rounded Box With Styling*/
HH.Gradient = surface.GetTextureID( "gui/gradient" )
function HH.DrawNiceBox( x, y, wide, tall, dropsize )
	draw.RoundedBoxEx( 4, x, y, wide, dropsize, HH.BaseColor, true, true, false, false )
	draw.RoundedBoxEx( 4, x, y + dropsize, wide, tall - dropsize, Color( 0, 0, 0, 220 ), false, false, true, true )
	surface.SetDrawColor( 255, 255, 255, 255 )
	surface.DrawLine( x, y + dropsize, x + wide, y + dropsize )
end

/*Notify*/
function HH.Notify( msg, sound )
	HH.Me:ChatPrint( "[HH] " .. msg )
	if( sound ) then
		local beep = Sound( "/buttons/button17.wav" )
		local mysound = CreateSound( HH.Me, beep )
		mysound:Play()
	end
end

/*Fov Check*/
function HH.InFov( ent )
	local fov = HH.MaxAimAngle:GetInt() /*Convar*/
	if( fov != 180 ) then
		local lpang = HH.Me:GetAngles()
		local ang = ( ent:GetBonePosition( ent:LookupBone( HH.GetBone() ) ) - HH.Me:EyePos() ):Angle()
		local ady = math.abs( math.NormalizeAngle( lpang.y - ang.y ) )
		local adp = math.abs( math.NormalizeAngle( lpang.p - ang.p ) )
		if( ady > fov or adp > fov ) then return false end
	end
	return true
end

/*Los Check*/
function HH.HasLos( ply )
	local td = {} 
	td.start = HH.Me:GetShootPos()
	td.endpos = ply:GetBonePosition( ply:LookupBone( HH.GetBone() ) )
	td.mask = 1174421507
	td.filter = { HH.Me, ply }
	
	local trace = util.TraceLine( td )
	if( trace.Fraction == 1 ) then
		return true
	end
	return false
end

/*Get Closest Target*/
function HH.GetClosest( pls )
	local pos = HH.Me:EyePos()
	local ang = HH.Me:GetAimVector()
	local returnply = { 0, 0 }
	for k, v in ipairs( pls ) do
		if( HH.IsValidPlayer( v ) ) then
			local plypos = v:GetBonePosition( v:LookupBone( HH.GetBone() ) )
			local difr = ( plypos - pos ):GetNormal()
			difr = difr - ang
			difr = difr:Length()
			difr = math.abs( difr )
			if( difr < returnply[2] || returnply[1] == 0 ) then
				returnply = { v, difr }
			end
		end
	end
	return returnply[1]
end


/*Get Target*/
function HH.GetNextTarget()
	if( HH.IsLocked and HH.IsValidPlayer( HH.LockedPlayer ) ) then return end
	local pls = {}
    for k, v in pairs( ents.GetAll() ) do
		if( HH.IsValidPlayer( v ) and HH.InFov( v )) then
			table.insert( pls, v )
		end
	end
	
	if( #pls > 1 ) then
		HH.LockedPlayer = HH.GetClosest( pls )
		HH.IsLocked = true
	elseif( #pls == 1 ) then
		HH.LockedPlayer = pls[1]
		HH.IsLocked = true
	else
		HH.IsLocked = false
	end
	return HH.IsLocked
end

/*Check Valid Players*/
function HH.IsValidPlayer( ply )
	if( !IsValid( ply ) or !( ply:IsPlayer() or ply:IsNPC() ) ) then return false end /*Check if player is valid*/
	if( ply == HH.Me ) then return false end /*Don't target self*/
	if( HH.CheckLos:GetBool() and !HH.HasLos( ply ) ) then return false end /*Check for Line of Sight*/
	if( ply:GetMoveType() == MOVETYPE_OBSERVER ) then return false end
	if( ply:GetMoveType() == 0 ) then return false end 
	if( HH.TargetNPCs:GetBool() and ply:IsNPC() ) then 
		return true 
	elseif( ply:IsNPC() ) then 
		return false 
	end
	if( ply:GetFriendStatus() == "friend" and HH.IgnoreSteamFriends:GetBool() ) then return false end /*Ignore Steam friends*/
	if( !ply:Alive() or ply:InVehicle() or HH.Me:InVehicle() or !HH.Me:Alive() ) then return false end
	if( HH.IgnoreOwnTeam:GetBool() and ply:Team() == HH.Me:Team() ) then return false end
	if( HH.IgnoreAdmins:GetBool() and ply:IsAdmin() ) then return false end
	if( HH.OnlyTargetTraitors:GetBool() and !HH.IsTraitor( ply ) ) then return false end
		
	if( HH.FriendsBlackList:GetBool() ) then
		if( !table.HasValue( HH.Friends, ply:SteamID() )  and !HH.IgnoreFriends:GetBool() ) then
			return false
		end
	else
		if( table.HasValue( HH.Friends, ply:SteamID() ) and !HH.IgnoreFriends:GetBool() ) then
			return false
		end
	end
	
	if( HH.TeamsBlackList:GetBool() ) then
		if( !HH.IsGoodTeam( team.GetName( ply:Team() ) ) and !HH.IgnoreTeams:GetBool() ) then
			return false
		end
	else
		if( HH.IsGoodTeam( team.GetName( ply:Team() ) ) and !HH.IgnoreTeams:GetBool() ) then
			return false
		end
	end
	
	return true
end

/*Prediction*/
local weapons = {
	[ "weapon_crossbow" ] = 3110,
}

function HH.Prediction( pos , pl )
	if IsValid( pl ) and type( pl:GetVelocity() ) == "Vector" and pl.GetPos and type( pl:GetPos() ) == "Vector" then
		local distance = HH.Me:GetPos():Distance( pl:GetPos() )
		local weapon = ( HH.Me.GetActiveWeapon and ( IsValid( HH.Me:GetActiveWeapon() ) and HH.Me:GetActiveWeapon():GetClass() ) )
		
		if weapon and weapons[ weapon ] then
			local time = distance / weapons[ weapon ]
			return pos + pl:GetVelocity() * time
		end
	end
	return pos
end

/*Add Friend*/
function HH.AddFriend( ply )
	if( ply:IsPlayer() and ply:IsValid() and ply != HH.Me and !table.HasValue (HH.Friends, ply:SteamID() ) ) then
		table.insert( HH.Friends, ply:SteamID() )
		HH.WriteFile( "hemihack/hh_friends.txt", util.TableToKeyValues( HH.Friends ) )
	end
end

/*Remove Friend*/
function HH.RemoveFriend( ply )
	if( ply:IsPlayer() and ply:IsValid() and ply != HH.Me ) then
		for k, v in pairs( HH.Friends ) do
			if( string.Trim( v ) == ply:SteamID() ) then
				HH.Friends[k] = nil
			end
		end
		HH.WriteFile( "hemihack/hh_friends.txt", util.TableToKeyValues( HH.Friends ) )
	end
end

/*Clear Friends*/
function HH.ClearFriendsList()
	HH.Friends = {}
	HH.WriteFile( "hemihack/hh_friends.txt", util.TableToKeyValues( HH.Friends ) )
end

function HH.IsFriend( ply )
	return table.HasValue( HH.Friends, ply:SteamID() )
end

/*Add Ent*/
function HH.AddEnt( entclass )
	if( !table.HasValue( HH.CustomEnts, entclass ) ) then
		table.insert( HH.CustomEnts, entclass )
		HH.WriteFile( "hemihack/hh_ents.txt", util.TableToKeyValues( HH.CustomEnts ) )
	end
end

/*Remove Ent*/
function HH.RemoveEnt( entclass )
	for k, v in pairs( HH.CustomEnts ) do
		if( string.Trim( v ) == entclass ) then
			HH.CustomEnts[k] = nil
		end
	end
	HH.WriteFile( "hemihack/hh_ents.txt", util.TableToKeyValues( HH.CustomEnts ) )
end

/*Clear Ents*/
function HH.ClearEnts()
	HH.CustomEnts = {}
	HH.WriteFile( "hemihack/hh_ents.txt", util.TableToKeyValues( HH.CustomEnts ) )
end

function HH.IsCustomEnt( entclass )
	return table.HasValue( HH.CustomEnts, entclass )
end

/*Add Team*/
function HH.AddTeam( teamname )
	table.insert( HH.Teams, teamname )
	HH.WriteFile( "hemihack/hh_teams.txt", util.TableToKeyValues( HH.Teams ) )
end

/*Remove Team*/
function HH.RemoveTeam( teamname )
	for k, v in pairs( HH.Teams ) do
		if( string.Trim( v ) == teamname ) then
			HH.Teams[k] = nil
		end
	end
	HH.WriteFile( "hemihack/hh_teams.txt", util.TableToKeyValues( HH.Teams ) )
end

function HH.IsGoodTeam( teamname )
	return table.HasValue( HH.Teams, teamname )
end

/*Clear Teams*/
function HH.ClearTeams()
	HH.Teams = {}
	HH.WriteFile( "hemihack/hh_teams.txt", util.TableToKeyValues( HH.Teams ) )
end

/*Get Target Bone*/
function HH.GetBone()
	if HH.CustomBone:GetBool() then 
		return HH.TargetBone
	else
		return "ValveBiped.Bip01_Head1"
	end
end

/*Set Target Bone*/
function HH.SetBone( bone )
	if table.HasValue( HH.ValidBones, bone ) then
		HH.TargetBone = bone
		HH.WriteFile( "hemihack/hh_bone.txt", HH.TargetBone )
	end
end

/*Get Wallhack material*/
function HH:CreateMaterial()
	local BaseInfo = {
		["$basetexture"] = "models/debug/debugwhite",
		["$model"]       = 1,
		["$translucent"] = 1,
		["$alpha"]       = 1,
		["$nocull"]      = 1,
		["$ignorez"]	 = 1
	}
	
	local mat
	if( HH.WallHackSolid:GetBool() ) then
		mat = CreateMaterial( "hh_solid", "VertexLitGeneric", BaseInfo )
	else
		mat = CreateMaterial( "hh_wireframe", "Wireframe", BaseInfo )
	end   
   return mat
end

/*Esp Distance Check*/
function HH.IsCloseEnough( ent )
	local dist = ent:GetPos():Distance( HH.Me:GetPos() )
	if( dist <= HH.ESPDist:GetInt() and ent:GetPos() != Vector( 0, 0, 0 ) ) then
		return true
	end
	return false	
end

/*No Spread*/
HH.CustomCones = {}
HH.CustomCones["#HL2_SMG1"]        = Vector( -0.04362, -0.04362, -0.04362 )
HH.CustomCones["#HL2_Pistol"]      = Vector( -0.0100, -0.0100, -0.0100 )
HH.CustomCones["#HL2_Pulse_Rifle"] = Vector( -0.02618, -0.02618, -0.02618 )

function HH.PredictSpread( cmd, aimAngle )
	local cmd2, seed = HH.PredictSeed( cmd:CommandNumber() )
   	local currentseed = 0, 0, 0
    if( cmd2 != 0 ) then currentseed = seed end
    local wep = HH.Me:GetActiveWeapon()
    local vecCone, valCone = Vector( 0, 0, 0 )
    if( IsValid( wep ) ) then
        if( wep.Initialize ) then
            valCone = wep.Primary and wep.Primary.Cone or 0
            if( tonumber( valCone ) ) then
                vecCone = Vector( -valCone, -valCone, -valCone )
            elseif( type( valCone ) == "Vector" ) then
                vecCone = -1 * valCone
            end
        else
            local pn = wep:GetPrintName()
            if( HH.CustomCones[pn] ) then vecCone = HH.CustomCones[pn] end
        end
    end

    local aimang = ( aimAngle or HH.Me:GetAimVector():Angle() ):Forward()
	local x, y, z = HH.ManipulateShot( currentseed or 0, aimang.x, aimang.y, aimang.z, vecCone.x, vecCone.y, vecCone.z )
	return Vector( x, y, z ):Angle()
end

HH.TGuns = { "weapon_ttt_c4", "weapon_ttt_knife", "weapon_ttt_phammer", "weapon_ttt_sipistol", "weapon_ttt_flaregun", "weapon_ttt_push", "weapon_ttt_radio", "weapon_ttt_teleport" }
HH.Traitors = {}
local allocatedweapons = {}
local cleared = false

function HH.PrintTraitors()
	if( !HH or !HH.Loaded ) then return end
	MsgN( "----------------Traitors----------------------")
	for k , v in pairs( HH.Traitors ) do
		HH.Print( v:Nick() .. "\n" )
	end
	HH.Print( #HH.Traitors.." of total ".. math.floor( #player.GetAll() / 4 ).." traitors detected.\n" )
	MsgN("-----------------------------------------------")
end
HH.AddCMD( "hh_printtraitors" , HH.PrintTraitors )

function HH.IsTraitor(pl)
	return table.HasValue( HH.Traitors , pl )
end

local umsg = usermessage.IncomingMessage

function usermessage.IncomingMessage( name , um , ... )
	if name == "ttt_role" and HH.ShowTraitors:GetBool() then
		HH.Print( "[HH] Clearing traitors - round end.\n" )
		for k , v in pairs( HH.Traitors ) do
			if IsValid( v ) then
				Msg( string.format( "Removing traitor %s - the round has ended." , v:Nick() ), false )
			end
			HH.Traitors[k] = nil
		end
	end
	
	return umsg( name , um , ... )
end

function HH.CheckTraitors()
	if not GAMEMODE or not GAMEMODE.Name or not string.find( GAMEMODE.Name , "Trouble in Terror" ) or !HH.ShowTraitors then return end
	for _, pl in pairs( player.GetAll() ) do
		for k, wep in pairs( ents.GetAll() ) do
			if( IsValid( wep ) and wep:IsWeapon() and table.HasValue( HH.TGuns , wep:GetClass() ) ) then	
				if pl:GetPos():Distance( wep:GetPos() ) <= 36 and not table.HasValue( HH.Traitors , pl ) and !table.HasValue( allocatedweapons , wep ) and not pl:IsDetective() and pl:Alive() then
					HH.Notify( string.format( "Player %s has traitor weapon %s" , pl:Nick() , wep:GetClass() ), true )
					table.insert( HH.Traitors,  pl )
					table.insert( allocatedweapons , wep )
					cleared = false
				end
			end
		end
		if table.HasValue( HH.Traitors , pl ) and (!pl:Alive() or pl:GetMoveType() == MOVETYPE_OBSERVER ) then
			HH.Notify( string.format( "Traitor %s has died!" , pl:Nick()  ), true )
			for a , b in pairs( HH.Traitors ) do
				if b == pl then
					HH.Traitors[a] = nil
				end
			end
		end
	end
end


/*---------Hooks---------*/
  
  
 /*Player Connect*/
 function HH.PConnect( name, ip )
	if ip != "none" and string.Left( ip, 2 ) != "0." then HH.IPS[ string.gsub( name,"=", "" ) ] = ip end
	HH.SaveIPs()
	if HH.MenuCreated then
		HH.RefreshIpMenu()
	end
	
	if !HH.LogIps:GetBool() then return end
	HH.Print( "\n\n[HH] " .. name .. " Connected from ip: " .. ip .. "\n\n" )
end
HH.AddHook( "PlayerConnect", HH.PConnect )
 
 /*TriggerBot*/
local Firing = false
function HH.TriggerBot()
	if( Firing ) then 
		RunConsoleCommand( "-attack" ) 
		Firing = false
		return
	end
	if( !HH.AutoShoot:GetBool() ) then return end
	if( !HH.Me:Alive() ) then return end
	if( !HH.AimbotIsOn or !HH.IsLocked or !HH.IsValidPlayer( HH.LockedPlayer ) ) then return end
	if( !HH.Me:GetActiveWeapon():IsValid() ) then return end
	
	RunConsoleCommand( "+attack" ) 
	//HH.Me():GetActiveWeapon():SetNextPrimaryFire( HH.Me():GetActiveWeapon() )
	Firing = true
end

/*Anti Snap*/
function HH.DoAntiSnap( ang )
        ang.p = math.NormalizeAngle( ang.p )
        ang.y = math.NormalizeAngle( ang.y )
		local speed = HH.AntiSnapSpeed:GetInt() / 10
        meang = HH.Me:EyeAngles()
        meang.p = math.Approach( meang.p, ang.p, speed )
        meang.y = math.Approach( meang.y, ang.y, speed )
        meang.r = 0
        ang = meang
        return ang    
end

/*AimBot*/
function HH.AimBot( cmd )
	if( !HH.AimbotIsOn ) then return end
	if( cmd:CommandNumber() == 0 ) then return end
	
	if( !HH.IsLocked or !HH.IsValidPlayer( HH.LockedPlayer ) ) then
		if( !HH.GetNextTarget() ) then return end
	end
	
	local ply = HH.LockedPlayer
	local targethead = ply:LookupBone( HH.GetBone() )
	local hepos = HH.Prediction( ply:GetBonePosition( targethead ), ply )
	
	local hepos = hepos + ply:GetVelocity() / 50 - HH.Me:GetVelocity() / 50 - Vector( 0, 0, 0 )
	
	shootang = ( hepos - HH.Me:EyePos() ):Angle()
			
	if( HH.AntiSnap:GetBool() ) then
		shootang = HH.DoAntiSnap( shootang )
	end
	
	if( HH.NoSpreadEnabled:GetBool() ) then
		shootang = HH.PredictSpread( cmd, shootang )
	end
	
	shootang.p, shootang.y, shootang.r = math.NormalizeAngle( shootang.p ), math.NormalizeAngle( shootang.y ), math.NormalizeAngle( shootang.r )

	HH.SetMyAngles( cmd, shootang )
end

HH.AddHook( "InputMouseApply", function( cmd, x, y, angle )
	if( HH.IsLocked and HH.AimbotIsOn ) then return true end
end )

/*Name Changer*/
HH.AddTimer( 0.2, 0, function()
	if( !HH.NameChanger:GetBool() ) then return end

	HH.SetSteamName( player.GetAll()[ math.random( 1, #player.GetAll() ) ]:Nick() .. " ~" )
end )

/*SpeedHack*/
function HH.SpeedHack()
	if( HH.Speed ) then
		HH.SetSpeed( HH.SpeedHackSpeed:GetFloat() )
	else
		HH.SetSpeed( 1 )
	end
end

local nonreloaders = { "weapon_physgun" , "gmod_tool" , "weapon_gravgun", "keys" }
/*Auto Reload*/
function HH.DoAutoReload()
    if( HH.AutoReload:GetBool() and HH.Me:Alive() and IsValid( HH.Me:GetActiveWeapon() ) and !table.HasValue( nonreloaders, HH.Me:GetActiveWeapon():GetClass() ) ) then
		if( HH.Me:GetActiveWeapon():Clip1() <= 0 and CurTime() > ( HH.LastReload + 5 ) ) then
			G.RunConsoleCommand( "+reload" )
			HH.LastReload = CurTime()
			HH.AddTimer( .2, 1, function()
				G.RunConsoleCommand( "-reload" )
			end )
		end
    end
end

/*BHop*/
HH.BH.LastHop = 0
function HH.DoBhop( cmd )
	if( HH.BHop ) then
		if( HH.Me:OnGround() and HH.Me:Alive() ) then
			cmd:SetButtons( bit.bor( cmd:GetButtons(), IN_JUMP ) )
			
			if( CurTime() > HH.BH.LastHop + 0.3 ) then
				HH.BH.LastHop = CurTime()
				HH.BH.Hops = HH.BH.Hops + 1
			end
		end
	end
end
   	
/*No Recoil*/
function HH.DoNoRecoil()
	if HH.NoRecoil:GetBool() and HH.Me:GetActiveWeapon():IsValid() and HH.Me:GetActiveWeapon().Primary then
		HH.Me:GetActiveWeapon().Primary.Recoil = 0
	end
end
	
/*Client Noclip*/
function HH.DoClientNoclip( cmd )
	if( HH.ClientNoclip:GetBool() ) then
		cmd:SetForwardMove( 0 )
		cmd:SetUpMove( 0 )
		cmd:SetSideMove( 0 )
	end
end

/*Aimbot Hud*/
function HH.PaintAimbot()
	if( !HH.IsLocked and HH.AimbotIsOn ) then
		draw.SimpleText( "Looking for Target...", "HHScoreboardText", ScrW()/2, ScrH()/2 + 100, Color(255, 0, 0), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
	elseif( HH.IsLocked and HH.AimbotIsOn ) then
		if( HH.LockedPlayer:IsPlayer() ) then
			draw.SimpleText( "Locked On: " .. HH.LockedPlayer:Nick() .. " (" .. HH.LockedPlayer:Health() .. " HP)", "HHScoreboardText", ScrW()/2, ScrH()/2 + 100, Color(0, 255, 0), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
		elseif( HH.LockedPlayer:IsValid() ) then
			draw.SimpleText( "Locked On: " .. HH.LockedPlayer:GetClass(), "HHScoreboardText", ScrW()/2, ScrH()/2 + 100, Color(0, 255, 0), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
		end
	end
end

/*ESP*/
function HH.ESP()
	for k, v in ipairs( player.GetAll() ) do
		if( v:Alive() and v != HH.Me and HH.IsCloseEnough( v ) and v:Team() != TEAM_SPECTATOR ) then
			local pos = v:EyePos():ToScreen()
			pos.y = pos.y - 32
			local astatus = ""
			local weaponp = ""
			local rank = ""
			local wep = ""
			if( v:IsAdmin() ) then rank = " [A]" end
			if( v:IsSuperAdmin() ) then rank = " [SA]" end
			local name = v:Nick() .. rank
			
			if( IsValid( v:GetActiveWeapon() ) ) then
				wep = v:GetActiveWeapon():GetPrintName().." | "
				wep = string.gsub( wep, "#HL2_", "" )
				wep = string.gsub( wep, "#GMOD_", "" )
			end
			
			local color = team.GetColor(v:Team())
			local dist = math.floor( v:GetPos():Distance( HH.Me:GetPos() ) )
			if( HH.ShowPlayers:GetBool() and HH.IsCloseEnough( v ) ) then
				draw.SimpleTextOutlined( team.GetName( v:Team() ), "HHFont", pos.x, pos.y + 14, color, TEXT_ALIGN_CENTER, TEXT_ALIGN_LEFT, 2, Color( 30, 30, 30, 165 ) )
				draw.SimpleTextOutlined( wep .. " Dist: " .. dist , "HHFont", pos.x, pos.y, Color( 255, 120, 20 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_LEFT, 2, Color( 30, 30, 30, 165 ) )
				draw.SimpleTextOutlined( name .. " | HP: " .. v:Health() .. " A: " .. v:Armor(), "HHFont", pos.x, pos.y - 14, Color( 120, 255, 20 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_LEFT, 2, Color( 30, 30, 30, 165 ) )
				if( HH.ShowTraitors:GetBool() and HH.IsTraitor( v ) ) then
					draw.SimpleTextOutlined( "TRAITOR!", "HHFont", pos.x, pos.y - 28, Color( 255, 0, 0 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_LEFT, 2, Color( 255, 120, 30, 165 ) )
				end
			end
		end
	end
	
	for _, v in ipairs( ents.GetAll() ) do
		if( v:IsValid() and HH.IsCustomEnt( v:GetClass() ) ) then
			if( HH.IsCloseEnough( v ) and HH.ShowEnts:GetBool() ) then
				local entpos = ( v:GetPos() + Vector( 0, 0, 50 ) ):ToScreen()
				draw.SimpleTextOutlined( v:GetClass(), "HHFontSmall", entpos.x, entpos.y - 8, Color( 255, 0, 0, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_LEFT, 1, Color( 30, 30, 30, 165 ) )
			end
		end                    
	end
end

/*Admins and Spectators*/
HH.Admins = {}
HH.Specs = {}
function HH.Info()
	if !HH.ShowAdmins:GetBool() then return end
	HH.AdminsTemp = HH.Admins 
	HH.Admins = {}
	
	local int = 0
	for k, v in ipairs( player.GetAll() ) do
		if( v:IsAdmin() ) then
			table.insert( HH.Admins, v )
		end
	end
	
	if( #HH.Admins > #HH.AdminsTemp ) then
		local pl = {}
		for k, v in ipairs( HH.Admins ) do
			if( !table.HasValue( HH.AdminsTemp, v ) ) then
				table.insert( pl, v )
			end
		end
		
		for k, v in pairs( pl ) do
			if( v and v:IsValid() and v != HH.Me ) then
				HH.AddTimer( 0.5, 1, function()
					HH.Notify( "Admin " .. v:Nick() .. " Joined!", true )
				end )
			end
		end
	end
	
	local txtsize = #HH.Admins * 16
	local posx = ScrW() - 200
	local posy = ScrH() - ScrH() + 15
	
	if ( #HH.Admins != 0 ) then
		HH.DrawNiceBox( posx, posy, 180, (txtsize + 1) + 24, 20 )
		draw.SimpleText( "Admins", "HHScoreboardText", posx + 90, posy + 2, Color( 255, 255, 255, 255 ), TEXT_ALIGN_CENTER )
		for k, v in pairs( HH.Admins ) do
			if( v:IsAdmin() and !v:IsSuperAdmin() ) then
				draw.SimpleText(v:Nick() .. " (A)", "HHFontSmall", posx + 10, posy + 25 + int, Color( 255, 255, 255, 255 ), TEXT_ALIGN_LEFT )
			elseif( v:IsSuperAdmin() ) then
				draw.SimpleText(v:Nick() .. " (SA)", "HHFontSmall", posx + 10, posy + 25 + int, Color( 255, 255, 255, 255 ), TEXT_ALIGN_LEFT )
			end
			int = int + 15
		end
	end
	
	HH.TempSpecs =  HH.Specs
	HH.Specs = {}
	for k, v in ipairs( player.GetAll() ) do
		if( v:GetObserverTarget() == HH.Me ) then
			table.insert( HH.Specs, v )
		end        
	end
	
	if( #HH.Specs > #HH.TempSpecs ) then
		local spl = {}
		for k, v in ipairs( HH.Specs ) do
			if( !table.HasValue( HH.TempSpecs, v ) ) then
				table.insert( spl, v )
			end
		end
		
		for k, v in pairs( spl ) do
			if( v and v:IsValid() ) then
				HH.Notify( v:Nick() .. " Started Spectating you!", true )
			end
		end
	end
	
	if( #HH.Specs < #HH.TempSpecs ) then
		local saf = {}
		for k, v in ipairs( HH.TempSpecs ) do
			if( !table.HasValue( HH.Specs, v ) ) then
				table.insert( saf, v )
			end
		end
		
		for k, v in pairs( saf ) do
			if( v and v:IsValid() ) then
				HH.Notify( v:Nick() .. " Stopped Spectating you!", false )
			end
		end
	end
	
	local add = 0
    if( #HH.Specs != 0 ) then
		surface.SetFont( "HHFontSmall" )
		local size = #HH.Specs * 16
		local poy = posy + txtsize + 35
		HH.DrawNiceBox( posx, poy, 180, ( size + 1 ) + 24, 20 )
		draw.SimpleText( "Spectators", "HHScoreboardText", posx + 90, poy + 2, Color( 255, 255, 255, 255 ), TEXT_ALIGN_CENTER )
        for k, v in pairs( HH.Specs ) do
			draw.SimpleText(v:Nick(), "HHFontSmall", posx + 10, poy + 25 + add, Color( 255, 255, 255, 255 ), TEXT_ALIGN_LEFT )
			add = add + 15
		end
	end
	
	/*Bhop Info*/
	if( HH.BHop ) then
		local posx = ScrW() - 200
		local posy = ScrH() - ScrH()/2
		local curspeed = math.Round( HH.Me:GetVelocity():Length() )
		if( curspeed > HH.BH.MaxSpeed and HH.Me:Alive() ) then HH.BH.MaxSpeed = curspeed end
		HH.DrawNiceBox( posx, posy, 150, 90, 20 )
		draw.SimpleText( "Bunny Hop", "HHScoreboardText", posx + 75, posy + 2, Color( 255, 255, 255, 255 ), TEXT_ALIGN_CENTER )
		draw.SimpleText( "Speed: " .. curspeed, "HHScoreboardText", posx + 75, posy + 27, Color( 255, 255, 255, 255 ), TEXT_ALIGN_CENTER )
		draw.SimpleText( "Max Speed: " .. HH.BH.MaxSpeed, "HHScoreboardText", posx + 75, posy + 47, Color( 255, 255, 255, 255 ), TEXT_ALIGN_CENTER )
		draw.SimpleText( "Hops: " .. math.Round( HH.BH.Hops ), "HHScoreboardText", posx + 75, posy + 67, Color( 255, 255, 255, 255 ), TEXT_ALIGN_CENTER )
	end
	
	/*Show where we are in Client Noclip*/
	if ( HH.ClientNoclip:GetBool() ) then
		local ppos = LocalPlayer():EyePos():ToScreen()
		draw.SimpleTextOutlined( "YOU ARE HERE", "HHScoreboardText", ppos.x, ppos.y, Color( 255, 0, 0, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, .6, Color( 30, 30, 30, 255 ) )
	end
end

/*Crosshair*/
function HH.ChairCross( x, y )
	local length = 15
	surface.DrawLine( x - length, y, x , y )
	surface.DrawLine( x + length, y, x, y )
	surface.DrawLine( x, y - length, x, y )
	surface.DrawLine( x, y + length, x, y )
end

function HH.CrossHair()
	if !HH.DrawCrosshair:GetBool() then return end
	local x = ScrW() / 2
	local y = ScrH() / 2
	if( HH.ThirdPerson:GetBool() and !HH.ClientNoclip:GetBool() ) then
		local pos = HH.Me:GetEyeTrace().HitPos:ToScreen()
		x = pos.x
		y = pos.y
	end
	
	if( !HH.Me:InVehicle() and HH.Me:Alive() ) then
		surface.SetDrawColor( 255, 0, 0, 255 )
		HH.ChairCross( x, y )
	end
end

/*Laser Eyes*/
function HH.LaserEyes()
	if( !HH.ShowLaserEyes:GetBool() ) then return end
	for k, v in pairs( player.GetAll() ) do
		if( v:IsValid() ) then
			if( v:Alive() ) then
				cam.Start3D( EyePos(), EyeAngles() )
					render.SetMaterial( Material( "cable/redlaser" ) )
					if( v != HH.Me ) then
						local pos = v:EyePos()
						local hit = util.TraceLine( util.GetPlayerTrace( v ) )
						if( HH.IsCloseEnough( v ) ) then
							render.DrawBeam( pos, hit.HitPos, 2, 1, 1, Color( 255, 0, 0, 255 ) )
						end
					end
				cam.End3D()
			end
		end
	end
end
HH.AddHook( "RenderScreenspaceEffects", HH.LaserEyes )

/*Wallhack*/
function HH.Wallhack()
	if( !HH.ESPEnabled:GetBool() ) then return end
	if HH.WallHackEnabled:GetBool() then
		cam.Start3D( EyePos(), EyeAngles() )
			for k, v in pairs ( player.GetAll() ) do				
				if( v:IsPlayer() and v != HH.Me and v:Alive() and v:Team() != TEAM_SPECTATOR and HH.IsCloseEnough( v ) ) then
					if( HH.Chams:GetBool() ) then
						local col = Color( 255, 10, 10 )
						local mat = HH.CreateMaterial()
						col = team.GetColor( v:Team() )
						if( HH.ShowTraitors:GetBool() and table.HasValue( HH.Traitors , v ) ) then
							col = Color( 255, 120, 0 )
						end
						
						if( v:GetActiveWeapon() and v:GetActiveWeapon():IsValid() ) then
							local wep = v:GetActiveWeapon()
							local wcol = Color( 255, 0, 0 )
							render.SetColorModulation( ( wcol.r * ( 1 / 255 ) ), ( wcol.g * ( 1 / 255 ) ), ( wcol.b * ( 1 / 255 ) ) )
							render.MaterialOverride( mat )
							render.SuppressEngineLighting( true )
							wep:DrawModel()
							render.SetColorModulation( 1, 1, 1 )
							render.MaterialOverride()
							render.SuppressEngineLighting( false )
							wep:DrawModel()
						end
						
						render.SetColorModulation( ( col.r * ( 1 / 255 ) ), ( col.g * ( 1 / 255 ) ), ( col.b * ( 1 / 255 ) ) )
						render.MaterialOverride( mat )
						render.SuppressEngineLighting( true )
						v:DrawModel()
						render.SetColorModulation( 1, 1, 1 )
						render.MaterialOverride()
						render.SuppressEngineLighting( false )
						v:DrawModel()
					else
						cam.IgnoreZ( true )
							render.SuppressEngineLighting( true )
								v:DrawModel()
								if( v:GetActiveWeapon() and v:GetActiveWeapon():IsValid() ) then
									local wep = v:GetActiveWeapon()
									wep:DrawModel()
								end
							render.SuppressEngineLighting( false )
						cam.IgnoreZ( false )
					end
				end
			end
		cam.End3D()
	end
end
HH.AddHook( "PostDrawEffects", HH.Wallhack )

local bones = {
	{ "ValveBiped.Bip01_L_Hand", "ValveBiped.Bip01_L_Forearm" },
	{ "ValveBiped.Bip01_L_Forearm", "ValveBiped.Bip01_L_UpperArm" },	
	{ "ValveBiped.Bip01_R_Hand", "ValveBiped.Bip01_R_Forearm" },
	{ "ValveBiped.Bip01_R_Forearm", "ValveBiped.Bip01_R_UpperArm" },
	{ "ValveBiped.Bip01_L_Toe0", "ValveBiped.Bip01_L_Foot" },
	{ "ValveBiped.Bip01_L_Foot", "ValveBiped.Bip01_L_Calf" },
	{ "ValveBiped.Bip01_L_Calf", "ValveBiped.Bip01_L_Thigh" },
	{ "ValveBiped.Bip01_R_Toe0", "ValveBiped.Bip01_R_Foot" },
	{ "ValveBiped.Bip01_R_Foot", "ValveBiped.Bip01_R_Calf" },
	{ "ValveBiped.Bip01_R_Calf", "ValveBiped.Bip01_R_Thigh" },
	{ "ValveBiped.Bip01_L_Thigh", "ValveBiped.Bip01_Pelvis" },
	{ "ValveBiped.Bip01_R_Thigh", "ValveBiped.Bip01_Pelvis" },
	{ "ValveBiped.Bip01_Pelvis", "ValveBiped.Bip01_Spine" },
	{ "ValveBiped.Bip01_Spine", "ValveBiped.Bip01_Spine2" },
	{ "ValveBiped.Bip01_Spine2", "ValveBiped.Bip01_Neck1" },
	{ "ValveBiped.Bip01_Neck1", "ValveBiped.Bip01_Head1" },
	{ "ValveBiped.Bip01_L_UpperArm", "ValveBiped.Bip01_Neck1" },
	{ "ValveBiped.Bip01_R_UpperArm", "ValveBiped.Bip01_Neck1" }
}

function HH.DrawBones()
	if( !HH.DrawBonesESP:GetBool() ) then return end
	for k, ply in pairs( player.GetAll() ) do
		if( ply == HH.Me ) then continue end
		if( !HH.IsCloseEnough( ply ) ) then continue end
		if( !ply:Alive() or ply:GetMoveType() == MOVETYPE_OBSERVER or ply:GetMoveType() == MOVETYPE_NONE ) then continue end
		
		if( HH.WallHackEnabled:GetBool() ) then
			local tcol = team.GetColor( ply:Team() )
			surface.SetDrawColor( 255 - tcol.r, 255 - tcol.g, 255 - tcol.b )
		else
			surface.SetDrawColor( 0, 255, 0 )
		end
		
		for _, v in pairs( bones ) do
			local pos1 = ply:GetBonePosition( ply:LookupBone( v[ 1 ] ) ):ToScreen()
			local pos2 = ply:GetBonePosition( ply:LookupBone( v[ 2 ] ) ):ToScreen()
			surface.DrawLine( pos1.x, pos1.y, pos2.x, pos2.y )
		end
	end
end

local function GetCoordinates( ent )
	local min, max = ent:OBBMins(), ent:OBBMaxs()
	local corners = {
		Vector( min.x, min.y, min.z ),
		Vector( min.x, min.y, max.z ),
		Vector( min.x, max.y, min.z ),
		Vector( min.x, max.y, max.z ),
		Vector( max.x, min.y, min.z ),
		Vector( max.x, min.y, max.z ),
		Vector( max.x, max.y, min.z ),
		Vector( max.x, max.y, max.z )
	}
	
	local minX, minY, maxX, maxY = ScrW() * 2, ScrH() * 2, 0, 0
	for _, corner in pairs( corners ) do
		local onScreen = ent:LocalToWorld( corner ):ToScreen()
		minX, minY = math.min( minX, onScreen.x ), math.min( minY, onScreen.y )
		maxX, maxY = math.max( maxX, onScreen.x ), math.max( maxY, onScreen.y )
	end
	
	return minX, minY, maxX, maxY
end

function HH.DrawBoxESP()
	if( !HH.BoxESP:GetBool() ) then return end
	for _, ply in pairs( player.GetAll() ) do
		if( ply == HH.Me ) then continue end
		if( !HH.IsCloseEnough( ply ) ) then continue end
		if( !ply:Alive() or ply:InVehicle() or ply:GetMoveType() == MOVETYPE_OBSERVER or ply:GetMoveType() == MOVETYPE_NONE ) then continue end
		
		local x1, y1, x2, y2 = GetCoordinates( ply )
		
		surface.SetDrawColor( 0, 255, 0 )
		
		surface.DrawLine( x1, y1, x2, y1 ) /*Top*/
		surface.DrawLine( x2, y1, x2, y2 ) /*Right*/
		surface.DrawLine( x1, y2, x2, y2 ) /*Bottom*/
		surface.DrawLine( x1, y1, x1, y2 ) /*Left*/
	end
end

local speed = HH.CNSpeed:GetInt() * ( FrameTime() / 2 ) * 100
/*Client Noclip / Thirdperson*/
function HH.CustomView( ply, pos, angles, fov )
	if( HH.ClientNoclip:GetBool() and HH.CNPos ) then
		local ang = angles:Forward()
		if HH.Me:KeyDown( IN_FORWARD ) and HH.ClientNoclip:GetBool() then
		HH.CNPos = HH.CNPos + HH.Me:GetAimVector() * speed
		end
		if HH.Me:KeyDown( IN_BACK ) and HH.ClientNoclip:GetBool() then
			HH.CNPos = HH.CNPos - HH.Me:GetAimVector() * speed
		end
		if HH.Me:KeyDown( IN_MOVERIGHT ) and HH.ClientNoclip:GetBool() then
			HH.CNPos = HH.CNPos + ang:Angle():Right() * speed
		end
		if HH.Me:KeyDown( IN_MOVELEFT ) and HH.ClientNoclip:GetBool() then
			HH.CNPos = HH.CNPos - ang:Angle():Right() * speed
		end
		if HH.Me:KeyDown( IN_JUMP ) and HH.ClientNoclip:GetBool() then
			HH.CNPos = HH.CNPos + Vector( 0, 0, speed )
		end
		if HH.Me:KeyDown( IN_SPEED ) and HH.ClientNoclip:GetBool() then
			speed = ( HH.CNSpeed:GetInt() * 3 * ( FrameTime() / 2 ) ) * 100
		elseif HH.Me:KeyDown( IN_DUCK ) and HH.ClientNoclip:GetBool() then
			speed = ( HH.CNSpeed:GetInt() / 3 * ( FrameTime() / 2 ) ) * 100
		else
			speed = ( HH.CNSpeed:GetInt() * ( FrameTime() / 2 ) ) * 100
		end
		
		local view = {}
		view.origin = HH.CNPos
		view.angles = angles
		view.fov = fov
		return view
	elseif( HH.ThirdPerson:GetBool() ) then
		HH.CNPos = HH.Me:EyePos()
		local view = {}
		if( HH.LeftShoulder:GetBool() ) then
			view.origin = pos - ( angles:Forward() * ( 30 + HH.ThirdDist:GetInt() ) + ( angles:Right() * 30  ) )
		else
			view.origin = pos - ( angles:Forward() * ( 30 + HH.ThirdDist:GetInt() ) - ( angles:Right() * 30  ) )
		end
		return view
	else
		HH.CNPos = HH.Me:EyePos()
	end
end
HH.AddHook( "CalcView", HH.CustomView )

/*Show Yourself*/
function HH.ShowYourSelf()
	if ( HH.ThirdPerson:GetBool() and !HH.ClientNoclip:GetBool() ) then
		return true
	end
end
HH.AddHook( "ShouldDrawLocalPlayer", HH.ShowYourSelf )

/*Anti Afk*/
local commands = { "forward" , "back" , "jump" , "moveleft" , "moveright", "right", "left", "duck" }
function HH.AntiAfk()
	if( HH.AntiAfkEnabled:GetBool() and #HH.Specs == 0 ) then
		local command1 = table.Random( commands )
		local command2 = table.Random( commands )
		HH.AddTimer( 1, 1, function() 
			G.RunConsoleCommand( "+"..command1 ) 
			G.RunConsoleCommand( "+"..command2 ) 
		end )
		HH.AddTimer( 2, 1, function() 
			G.RunConsoleCommand("-"..command1 ) 
			G.RunConsoleCommand("-"..command2 ) 
		end )
	end
end
HH.AddTimer( 10 , 0 , function() HH.AntiAfk() end )

function HH.CreateMove( uc )
	HH.AimBot( uc )
	HH.DoBhop( uc )
	HH.DoNoRecoil()
	HH.DoClientNoclip( uc )
end
HH.AddHook( "CreateMove", HH.CreateMove )

function HH.MenuThink()
	if( HH.MainMenu and HH.MenuClosed and HH.CanCloseMenu and HH.MainMenu:IsVisible() ) then
		HH.MainMenu:SetVisible( false )
	elseif( HH.MainMenu and !HH.MainMenu:IsVisible() and !HH.MenuClosed ) then
		HH.MainMenu:SetVisible( true )
	end
end

HH.AddHook( "Think", HH.MenuThink )
HH.AddHook( "Think", HH.TriggerBot )
HH.AddHook( "Think", HH.DoAutoReload )
HH.AddHook( "Think", HH.CheckTraitors )

function HH.HudPaint()
	if( !HH.ESPEnabled:GetBool() ) then return end
	HH.ESP()
	HH.Info()
	HH.CrossHair()
	HH.PaintAimbot()
	HH.DrawBones()
	HH.DrawBoxESP()
	
	HH.NumericHealth() /*PERP*/
	HH.RPNames()
	HH.WeedPaint()
	HH.DrawDruggy()	
end
HH.AddHook( "HUDPaint", HH.HudPaint )


/*---------Console Commands---------*/


/*Aimbot*/
HH.AddCMD( "+hh_aim", function()
	if !HH or !HH.Loaded then return end
	HH.AimbotIsOn =  true
end )

HH.AddCMD( "-hh_aim", function()
	if !HH or !HH.Loaded then return end
	HH.AimbotIsOn =  false
	HH.IsLocked = false	
	G.RunConsoleCommand("-attack")
end )

/*Bhop*/
HH.AddCMD( "+hh_bhop", function()
	if !HH or !HH.Loaded then return end
	HH.BHop = true
end )

HH.AddCMD( "-hh_bhop", function()
	if !HH or !HH.Loaded then return end
	HH.BHop = false
end )

HH.AddCMD( "hh_resetbhop", function()
	if !HH or !HH.Loaded then return end
	HH.BH.MaxSpeed = 0
	HH.BH.Hops = 0
	HH.Notify( "BHop Info Reset!", false )
end )

/*Speed Hack*/
HH.AddCMD( "+hh_speed", function()
	if !HH or !HH.Loaded then return end
	HH.Speed = true
	HH.SpeedHack()
end )

HH.AddCMD( "-hh_speed", function()
	if !HH or !HH.Loaded then return end
	HH.Speed = false
	HH.SpeedHack()
end )

function HH.Unload()
	if !HH or !HH.Loaded then return end
	for k, v in pairs( HH.Hooks ) do
		hook.Remove( v.type, k )
	end
	
	for k, v in pairs( HH.Timers ) do
		timer.Remove( k )
	end
	timer.Remove( "DoFuel" )
	HH = nil
	Msg( "Hemi Hack was succesfully unloaded.\n" )
end

HH.AddCMD( "hh_unload", function()
	if !HH or !HH.Loaded then return end
	
	HH.Unload()
end )


/*---------Utilities---------*/


function HH.CommaValue( amount )
	local formatted = amount
	while true do  
		formatted, k = string.gsub( formatted, "^(-?%d+)(%d%d%d)", '%1,%2' )
		if ( k==0 ) then
			break
		end
	end
	return formatted
end

function HH.RoundNum(val, decimal)
	if (decimal) then
		return math.floor( ( val * 10 ^ decimal ) + 0.5 ) / ( 10 ^ decimal )
	else
		return math.floor( val + 0.5 )
	end
end

function HH.FormatNum( amount, decimal, prefix, neg_prefix )
	local str_amount,  formatted, famount, remain

	decimal = decimal or 2
	neg_prefix = neg_prefix or "-"

	famount = math.abs( HH.RoundNum( amount, decimal ) )
	famount = math.floor( famount )

	remain = HH.RoundNum( math.abs( amount ) - famount, decimal )

	formatted = HH.CommaValue( famount )

	if ( decimal > 0 ) then
		remain = string.sub( tostring( remain ), 3 )
		formatted = formatted .. "." .. remain .. string.rep( "0", decimal - string.len( remain ) )
	end

	formatted = ( prefix or "" ) .. formatted 

	if ( amount < 0 ) then
		if ( neg_prefix=="()" ) then
			formatted = "(" .. formatted .. ")"
		else
			formatted = neg_prefix .. formatted 
		end
	end

	return formatted
end


/*-----------------------------------------------------------------------------------------------------------Menu-----------------------------------------------------------------------------------------------------------*/

/*SKIN*/
local SKIN = table.Copy( derma.GetDefaultSkin() )

local TEX_GRADIENT = surface.GetTextureID( "gui/gradient_down" )
local TEX_GRADIENT_UP = surface.GetTextureID( "gui/gradient_up" )

SKIN.colPropertySheet 			= Color( 200, 200, 200, 200 )
SKIN.colTab			 			= SKIN.colPropertySheet
SKIN.colTabInactive				= Color( 80, 80, 80, 255 )
SKIN.colTabShadow				= Color( 255, 0, 0, 255 )
SKIN.colTabText		 			= Color( 255, 255, 255, 255 )
SKIN.colTabTextInactive			= Color( 200, 200, 200, 255 )

/*Property Sheet*/
function SKIN:PaintPropertySheet( panel )
	local ActiveTab = panel:GetActiveTab()
	local Offset = 10
	if ActiveTab then
		local w, h, padding = panel:GetWide(), panel:GetTall(), panel:GetPadding()
		Offset = ActiveTab:GetTall()
		surface.SetDrawColor( self.colPropertySheet )
		surface.SetTexture( TEX_GRADIENT )
		surface.DrawTexturedRect( 2, Offset, w-4, h*0.75 )
		
		local tab = ActiveTab:GetWide()
		local x, _ = ActiveTab:GetPos()
		local tab_offset = -panel.tabScroller.pnlCanvas.x
		local x1, x2 = math.Round( x+padding+1-tab_offset ), math.Round( x+padding+tab-2-tab_offset )
		surface.SetDrawColor( 255, 255, 255, 200 )
		local left, right = (x1 >= 0 and x1 <= w), (x2 >= 0 and x2 <= w)
		if left then
			surface.DrawRect( 2, Offset, x1-1, 1 )
			surface.DrawRect( x1, Offset, 1, 2 )
		end
		if right then
			surface.DrawRect( x2, Offset, w-x2-2, 1 )
			surface.DrawRect( x2, Offset, 1, 2 )
		end
		if !left and !right then
			surface.DrawRect( 2, Offset, w-4, 1 )
		end
	end
end


function SKIN:PaintTab( panel )
	local w, h = panel:GetWide(), panel:GetTall()
	if panel:GetPropertySheet():GetActiveTab() == panel then
		/*Active*/
		surface.SetTexture( TEX_GRADIENT_UP )
		surface.SetDrawColor( SKIN.colTab )
		surface.DrawTexturedRect( 0, h * 0.05, w, h * 0.95 )
		surface.SetDrawColor( 255, 0, 0, 200 )
		surface.DrawTexturedRect( 1, 0, 1, h )
		surface.DrawTexturedRect( w - 2, 0, 1, h )
	else
		/*Inactive*/
		surface.SetDrawColor( SKIN.colTabInactive )
		surface.SetTexture( TEX_GRADIENT_UP )
		surface.DrawTexturedRect( 0, h * 0.30, w, h * 0.70 )
		surface.SetDrawColor( 10, 0, 0, 255 )
		surface.DrawTexturedRect( 1, h * 0.25, 1, h * 0.75 )
		surface.DrawTexturedRect( w - 2, h * 0.25, 1, h * 0.75 )
	end
end

/*Buttons*/
function SKIN:PaintButton( panel )
	local w, h = panel:GetSize()
	local col = Color( 40, 40, 40, 255 )
	local col2 = Color( 25, 25, 25, 255 )
	if panel.m_bBackground then
		if panel:GetDisabled() then
			col = Color( 25, 25, 25, 150 )
			col2 = Color( 25, 25, 25, 255 )
		elseif panel.Depressed /*or panel:GetSelected() */then
			col = Color( HH.BaseColor.r + 50, HH.BaseColor.g, HH.BaseColor.b, 255 )
			col2 = Color( HH.BaseColor.r + 40, HH.BaseColor.g, HH.BaseColor.b, 255 )
		elseif panel.Hovered then
			col = Color( HH.BaseColor.r + 60, HH.BaseColor.g, HH.BaseColor.b, 255 )
			col2 = Color( HH.BaseColor.r + 20, HH.BaseColor.g, HH.BaseColor.b, 255 )
		end
	end
	draw.RoundedBox( 4, 0, 0, w, h, Color( 50, 50, 50, 255) )
	draw.RoundedBoxEx( 4, 2, 2, w - 4, h / 2, col, true, true, false, false )
	draw.RoundedBoxEx( 4, 2, h / 2, w - 4, h / 2 - 2, col2, false, false, true, true )
end

/*Check box*/
function SKIN:PaintCheckBox( panel )
	local w, h = panel:GetSize()
		
	draw.RoundedBox( 4, 0, 0, w, h, Color( 120, 120, 120, 255 ) )
	if( panel:GetChecked() ) then
		draw.RoundedBox( 2, 1, 1, w - 2, h - 2, HH.BaseColor )
	end
end
 
function SKIN:SchemeCheckBox( panel )
	panel:SetTextColor( Color( 0, 0, 0, 0 ) )
	//DSysButton.ApplySchemeSettings( panel )
end

/*Scroll Bar*/
function SKIN:PaintScrollBarGrip( panel )
	draw.RoundedBox( 4, 0, 0, panel:GetWide(), panel:GetTall(), Color( 10, 10, 10 ) )
	draw.RoundedBoxEx( 4, 2, 2, panel:GetWide() - 4, panel:GetTall() / 2, Color( HH.BaseColor.r, HH.BaseColor.g, HH.BaseColor.b, HH.BaseColor.a + 20 ), true, true, false, false )
	draw.RoundedBoxEx( 4, 2, panel:GetTall() / 2, panel:GetWide() - 4, panel:GetTall() / 2 - 2, Color( HH.BaseColor.r, HH.BaseColor.g, HH.BaseColor.b, HH.BaseColor.a - 50 ), false, false, true, true )
end

function SKIN:LayoutVScrollBar( panel )
	local Wide = panel:GetWide()
	local Scroll = panel:GetScroll() / panel.CanvasSize
	local BarSize = math.max( panel:BarScale() * (panel:GetTall() - (Wide * 2)), 10 )
	local Track = panel:GetTall() - (Wide * 2) - BarSize
	Track = Track + 1
   
	Scroll = Scroll * Track
   
	panel.btnGrip:SetPos( 0, Wide + Scroll )
	panel.btnGrip:SetSize( Wide, BarSize )
   
	panel.btnUp:SetPos( 0, 0, Wide, Wide )
	panel.btnUp:SetSize( Wide, Wide )
	panel.btnUp.Paint = function( button ) SKIN:PaintButton( button ) end
   
	panel.btnDown:SetPos( 0, panel:GetTall() - Wide, Wide, Wide )
	panel.btnDown:SetSize( Wide, Wide )
	panel.btnDown.Paint = function( button ) SKIN:PaintButton( button ) end
end

/*Menu*/
HH.MenuInited = false
HH.CanCloseMenu = true
HH.MenuClosed = true

function HH.DrawFrame( panel )
	draw.RoundedBox( 0, 0, 0, panel:GetWide(), panel:GetTall(), Color( 0, 0, 0, 240 ) )
end

/*Main*/
function HH.InitMenu()
	HH.MainMenu = vgui.Create( "DFrame" )
	HH.MainMenu:SetPos( ScrW()/2-250, ScrH()/2-200 )
	HH.MainMenu:SetSize( 500, 400 )
	HH.MainMenu:ShowCloseButton( false )
	HH.MainMenu:SetDraggable( false )
	HH.MainMenu:SetTitle( "" )
	HH.MainMenu:SetVisible( false )
	HH.MainMenu:MakePopup()
	HH.MainMenu.Paint = function()
		HH.DrawNiceBox( 0, 0, HH.MainMenu:GetWide(), HH.MainMenu:GetTall(), 52 )
		draw.SimpleTextOutlined( "Hemi Hack V3", "HHLogo", 10, 3, Color( 255, 255, 255, 255 ), TEXT_ALIGN_LEFT,TEXT_ALIGN_LEFT, 2, Color( 10, 120, 155 ) )
		draw.SimpleTextOutlined( "By: Hemirox   Version: " .. version .. "   Last Updated: " .. lastupdated, "HHFontSmall", HH.MainMenu:GetWide() - 15, HH.MainMenu:GetTall() - 17, Color( 255, 255, 255, 255 ), TEXT_ALIGN_RIGHT, TEXT_ALIGN_BOTTOM, .6, Color( 30, 30, 30, 255 ) )
	end
	function HH.MainMenu:GetSkin()
        return SKIN;
    end    
	
	/*Lock Menu*/
	local Lock = vgui.Create( "DButton", HH.MainMenu )
	Lock:SetPos( HH.MainMenu:GetWide() - 80, 10 )
	Lock:SetSize( 70, 30 )
	Lock:SetText( "Lock Menu" )
	Lock.DoClick = function()
		if HH.CanCloseMenu then
			Lock:SetText( "Unlock Menu" )
			HH.CanCloseMenu = false
		else
			Lock:SetText( "Lock Menu" )
			HH.CanCloseMenu = true
		end
	end	
	
	/*AimBot Menu*/
	local  AimbotMenu = vgui.Create( "DFrame", HH.MainMenu )
	AimbotMenu:SetVisible( true )
	AimbotMenu:ShowCloseButton( false )
	AimbotMenu:SetTitle( "" )
	AimbotMenu.Paint = function()
		HH.DrawFrame( AimbotMenu )
	end
	
	HH.AddCheckBox( "Auto Shoot", "hh_autoshoot", AimbotMenu, 20, 20, "Automatically Shoot when locked on." )
	HH.AddCheckBox( "Auto Reload", "hh_autoreload", AimbotMenu, 20, 45, "Automatically Reload when your ammo is depleated." )
	HH.AddCheckBox( "No Recoil", "hh_norecoil", AimbotMenu, 20, 70, "Disable Weapon recoil. (Requires respawn when you disable it)" )
	HH.AddCheckBox( "No Spread", "hh_nospread", AimbotMenu, 20, 95, "Predicts Weapon Spread, bullets always hit the same spot." )
	HH.AddCheckBox( "Check for LOS", "hh_checklos", AimbotMenu, 20, 120, "Check to see if you can actually see the target." )
	HH.AddCheckBox( "Anti-Snap", "hh_antisnap", AimbotMenu, 20, 145, "Aimbot slowly moves to target, looks more natural." )
	
	HH.AddCheckBox( "Use Custom Bone", "hh_custombone", AimbotMenu, 20, 270, "Aimbot targets the custom bone that is set. (Otherwise targets head)" )
	
	HH.AddCheckBox( "Target NPCs", "hh_targetnpcs", AimbotMenu, 155, 20, "Aimbot will target NPCs." )
	HH.AddCheckBox( "Target Traitors (TTT)", "hh_targettraitors", AimbotMenu, 155, 45, "Aimbot will only target Detected Traitors. (TTT)" )
	HH.AddCheckBox( "Ignore Steam Friends", "hh_ignoresteamfriends", AimbotMenu, 155, 70, "Aimbot ignores your Steam Friends." )
	HH.AddCheckBox( "Ignore Admins", "hh_ignoreadmins", AimbotMenu, 155, 95, "Aimbot ignores Admins." )
	HH.AddCheckBox( "Ignore Own Team", "hh_ignoreownteam", AimbotMenu, 155, 120, "Aimbot ignores the team you are currently on." )
			
	local BoneList= vgui.Create( "DComboBox", AimbotMenu )
	BoneList:SetPos( 20, 290 )
	BoneList:SetSize( 150, 20 )
	//BoneList:SetEditable( false )
	BoneList:SetText( string.gsub( HH.TargetBone, "ValveBiped.Bip01_", "" )  )
	for k, v in pairs( HH.ValidBones ) do
		BoneList:AddChoice( string.gsub( v, "ValveBiped.Bip01_", "" ) )
	end
	BoneList.OnSelect = function( panel, index, value, data )
		HH.SetBone( "ValveBiped.Bip01_" .. value )
	end

	HH.AddSlider( "Anti-Snap Speed", "hh_antisnapspeed", AimbotMenu, 1, 20, 0, 250, 230, 200, "How fast does the anti-snap go?"  )
	HH.AddSlider( "Max Aimbot Snap Angle", "hh_maxangle", AimbotMenu, 5, 180, 0, 250, 270, 200, "How far can you turn to snap to Players?"  )
	
	local OpenFriends= vgui.Create( "DButton", AimbotMenu )
	OpenFriends:SetPos( 320, 20 )
	OpenFriends:SetSize( 100, 50 )
	OpenFriends:SetText( "Edit Friends" )
	OpenFriends.DoClick = function()
		HH.FriendsMenu()
	end
	
	local OpenTeams= vgui.Create( "DButton", AimbotMenu )
	OpenTeams:SetPos( 320, 80 )
	OpenTeams:SetSize( 100, 50 )
	OpenTeams:SetText( "Edit Teams" )
	OpenTeams.DoClick = function()
		HH.TeamsMenu()
	end
	
	HH.AddCheckBox( "Ignore Friends List", "hh_ignorefriends", AimbotMenu, 320, 160, "Aimbot ignores the custom Friends List" )
	HH.AddCheckBox( "Ignore Teams List", "hh_ignoreteams", AimbotMenu, 320, 190, "Aimbot ignores the custom Teams List." )
	
	/*ESP Menu*/
	local  ESPMenu = vgui.Create( "DFrame", HH.MainMenu)
	ESPMenu:SetVisible( true )
	ESPMenu:ShowCloseButton( false )
	ESPMenu:SetTitle( "" )
	ESPMenu.Paint = function()
		HH.DrawFrame( ESPMenu )
	end
	
	local OpenEnts= vgui.Create( "DButton", ESPMenu )
	OpenEnts:SetPos( 320, 100 )
	OpenEnts:SetSize( 100, 50 )
	OpenEnts:SetText( "Edit Ents" )
	OpenEnts.DoClick = function()
		HH.EntsMenu()
	end
	
	HH.AddCheckBox( "Master Switch", "hh_espenabled", ESPMenu, 20, 20, "Uncheck to disable all ESP functions." )
	HH.AddCheckBox( "Player ESP", "hh_showplayers", ESPMenu, 20, 50, "Show info about players above their heads." )
	HH.AddCheckBox( "Entity ESP", "hh_showents", ESPMenu, 20, 80, "Show Entities from the Custom Ents List." )
	HH.AddCheckBox( "Crosshair", "hh_crosshair", ESPMenu, 20, 110, "Show crosshair." )
	HH.AddCheckBox( "Admins/Spectators", "hh_showadmins", ESPMenu, 20, 140, "Show Admins/Spectators on your HUD." )
	HH.AddCheckBox( "Laser Eyes", "hh_lasereyes", ESPMenu, 20, 170, "See where people are looking." )
	HH.AddCheckBox( "Wallhack", "hh_wallhack", ESPMenu, 20, 200, "See people through walls." )
	HH.AddCheckBox( "Chams", "hh_chams", ESPMenu, 20, 230, "Dynamic coloring. (Requires Wallhack)" )
	HH.AddCheckBox( "Solid Chams", "hh_solidwallhack", ESPMenu, 20, 260, "Should Chams be solid? Otherwise Wireframe. (Requires Wallhack)" )
	
	HH.AddCheckBox( "Bone ESP", "hh_drawbones", ESPMenu, 155, 20, "Draw Bones on Players." )
	HH.AddCheckBox( "Box ESP", "hh_boxesp", ESPMenu, 155, 50, "Draw Boxes Around Players." )
	
	HH.AddSlider( "ESP Distance", "hh_espdist", ESPMenu, 5, 15000, 0, 250, 270, 200, "How far can people be to see them with ESP?" )
	
	/*Misc Menu*/
	local  MiscMenu = vgui.Create( "DFrame", HH.MainMenu )
	MiscMenu:SetVisible( true )
	MiscMenu:ShowCloseButton( false )
	MiscMenu:SetTitle( "" )
	MiscMenu.Paint = function()
		HH.DrawFrame( MiscMenu )
	end
	
/*	local RunStringTBox = vgui.Create( "DTextEntry", MiscMenu )
	RunStringTBox:SetWide( 200 )
	RunStringTBox:SetTall( 70 )
	RunStringTBox:SetPos( 250, 10 )
	RunStringTBox:SetMultiline( true )
	RunStringTBox:SetText( 'LocalPlayer():ChatPrint("Hello World")' )
	
	local RunStringButton = vgui.Create( "DButton", MiscMenu )
	RunStringButton:SetText( "Run Lua String" )
	RunStringButton:SetPos( 250, 80 )
	RunStringButton:SetWide( 100 )
	RunStringButton:SetTall( 30 )
	RunStringButton:SetToolTip( "This will allow you to run lua with Script Enforcer on." )
	RunStringButton.DoClick = function()
		//HH.RunLuaString( RunStringTBox:GetValue() )
	end*/
	
	local SetNameTBox = vgui.Create( "DTextEntry", MiscMenu )
	SetNameTBox:SetWide( 110 )
	SetNameTBox:SetPos( 250, 15 )
	HH.AddTimer( 3, 1, function()
		SetNameTBox:SetText( HH.Me:Nick() )
	end )
	
	local SetNameButton = vgui.Create( "DButton", MiscMenu )
	SetNameButton:SetText( "Change Name" )
	SetNameButton:SetPos( 370, 15 )
	SetNameButton:SetWide( 90 )
	SetNameButton:SetTall( SetNameTBox:GetTall() )
	SetNameButton:SetToolTip( "This will change your steam name." )
	SetNameButton.DoClick = function()
		HH.SetSteamName( SetNameTBox:GetValue() )
		HH.Notify( "Steam Name set to: " .. SetNameTBox:GetValue() )
	end
	
	HH.AddCheckBox( "Client Noclip", "hh_clientnoclip", MiscMenu, 20, 20, "Clientside Noclip. No one else can see you No-Clipping, you just appear to be standing still." )
	HH.AddCheckBox( "Third Person", "hh_thirdperson", MiscMenu, 20, 50, "Enable Third Person mode." )
	HH.AddCheckBox( "TP Left Shoulder", "hh_tpleftshoulder", MiscMenu, 20, 80, "Third Person mode over your left shoulder. (Otherwise Right shoulder)" )
	HH.AddCheckBox( "Name Changer", "hh_namechanger", MiscMenu, 20, 110, "Enable Name Changer. (Changing Steam status to 'Offline' is Recommended)" )
	HH.AddCheckBox( "Anti AFK Kicker", "hh_antiafkkicker", MiscMenu, 20, 140, "Makes you move randomly every 10 seconds to spoof AFK checkers." )
	HH.AddCheckBox( "Check for Traitors (TTT)", "hh_showtraitors", MiscMenu, 20, 170, "Check for Traitors in the TTT Gamemode." )
	/*HH.AddCheckBox( "Show ConCommands", "hh_showccs", MiscMenu, 20, 200, "Show when Console Commands are run through LUA." )
	HH.AddCheckBox( "Block ConCommands", "hh_blockccs", MiscMenu, 20, 230, "Block Console commands from being run through LUA." )*/
	
	HH.AddSlider( "Third Person Distance", "hh_thirdpersondist", MiscMenu, 0, 800, 0, 250, 190, 200, "How far away is the Third Person Mode?" )
	HH.AddSlider( "Client Noclip Speed", "hh_clientnoclipspeed", MiscMenu, 0, 15, 0, 250, 230, 200, "How fast does the Client Noclip go?" )
	HH.AddSlider( "Speed Hack Speed", "hh_speedhackspeed", MiscMenu, 1, 10, 0, 250, 270, 200, "How fast is the Speed Hack?" )
		
	/*Add Tabs*/
	HH.Tabs = vgui.Create( "DPropertySheet", HH.MainMenu )
	HH.Tabs:SetPos( 10, 30 )
	HH.Tabs:SetSize( HH.MainMenu:GetWide()-20, HH.MainMenu:GetTall()-45 )
	
	local aimbottab = HH.Tabs:AddSheet( "Aimbot", AimbotMenu, "icon16/controller.png", false, false )
	local esptab = HH.Tabs:AddSheet( "ESP", ESPMenu, "icon16/camera.png", false, false )
	local misctab = HH.Tabs:AddSheet( "Misc", MiscMenu, "icon16/box.png", false, false )
	HH.MenuInited = true
	HH.MenuCreated = true
end

/*Friends List*/
function HH.FriendsMenu()
	local FriendPanel = vgui.Create( "DFrame" )
	FriendPanel:SetPos( ScrW()/2 - 250, ScrH()/2 - 200 )
	FriendPanel:SetSize( 500, 400 )
	FriendPanel:SetTitle( "Friends List" )
	FriendPanel:SetVisible( true )
	FriendPanel:SetDraggable( false )
	FriendPanel:ShowCloseButton( true )
	FriendPanel.Paint = function()
		HH.DrawFrame( FriendPanel )
	end
	function FriendPanel:GetSkin()
         return SKIN;
    end
	FriendPanel:MakePopup()

	
	local NonFriends = vgui.Create( "DListView", FriendPanel )
	NonFriends:SetPos( 20, 45 )
	//NonFriends:EnableVerticalScrollbar( true )
	NonFriends:SetSize( 150, FriendPanel:GetTall() - 70 )
	NonFriends:SetMultiSelect( false )
	NonFriends:AddColumn( "Non-Friends" )
	NonFriends:SetHideHeaders( true )
	
	local Nonlabel = vgui.Create("DLabel", FriendPanel )
	Nonlabel:SetPos( 22, 30 ) 
	Nonlabel:SetColor( Color( 255, 255, 255, 255) )
	Nonlabel:SetFont("HHFontSmall")
	Nonlabel:SetText( "Non-Friends" )
	Nonlabel:SizeToContents()
	
	local AddFriend = vgui.Create( "DButton", FriendPanel )
	AddFriend:SetPos( FriendPanel:GetWide()/2 - 50, FriendPanel:GetTall()/2 - 65 )
	AddFriend:SetSize( 100, 30 )
	AddFriend:SetText( "Add Friend ->" )
	
	local Friends = vgui.Create( "DListView", FriendPanel )
	Friends:SetPos( FriendPanel:GetWide() - 170, 45 )
	Friends:SetSize( 150, FriendPanel:GetTall() - 70 )
	//Friends:EnableVerticalScrollbar( true )
	Friends:SetMultiSelect( false )
	Friends:AddColumn( "Friends" )
	Friends:SetHideHeaders( true )
	
	local flabel = vgui.Create("DLabel", FriendPanel )
	flabel:SetPos( FriendPanel:GetWide() - 168, 30 ) 
	flabel:SetColor( Color( 255, 255, 255, 255) )
	flabel:SetFont("HHFontSmall")
	flabel:SetText( "Friends" )
	flabel:SizeToContents()
	
	local RemoveFriend = vgui.Create( "DButton", FriendPanel )
	RemoveFriend:SetPos( FriendPanel:GetWide()/2 - 50, FriendPanel:GetTall()/2 + 25 )
	RemoveFriend:SetSize( 100, 30 )
	RemoveFriend:SetText( "<- Remove Friend" )
	
	HH.AddCheckBox( "Blacklist->", "hh_friendsblacklist", FriendPanel, FriendPanel:GetWide()/2 - 40, FriendPanel:GetTall()/2 - 125 )
	
	local function RefreshCombo()
		Friends:Clear()
		NonFriends:Clear()
		for k, v in pairs( player.GetAll() ) do
			if( !HH.IsFriend( v ) and v != HH.Me ) then
				local item = NonFriends:AddLine( v:Nick() )
				NonFriends:SortByColumn( 1 )
				item.pl = v
			end
		end
		
		for k, v in pairs( player.GetAll() ) do
			if( HH.IsFriend( v ) and v != HH.Me ) then
				local item = Friends:AddLine( v:Nick() )	
				item.pl = v
			end
		end
	end
	RefreshCombo()
	
	local Clear = vgui.Create( "DButton", FriendPanel )
	Clear:SetPos( FriendPanel:GetWide()/2 - 45, FriendPanel:GetTall() - 85 )
	Clear:SetSize( 90, 30 )
	Clear:SetText( "Clear" )
	Clear.DoClick = function()
		HH.ClearFriendsList()
		RefreshCombo()
	end
	
	AddFriend.DoClick = function()
		if( #NonFriends:GetSelected() != 0 ) then
			HH.Notify( "Added: " .. NonFriends:GetSelected()[1].pl:Nick(), false )
			HH.AddFriend( NonFriends:GetSelected()[1].pl )
			RefreshCombo()
		end
	end
	
	RemoveFriend.DoClick = function()
		if ( #Friends:GetSelected() != 0 ) then
			HH.Notify( "Removed: " .. Friends:GetSelected()[1].pl:Nick(), false )
			HH.RemoveFriend( Friends:GetSelected()[1].pl )
			RefreshCombo()
		end
	end
end

/*Ents List*/
function HH.EntsMenu()
	local EntPanel = vgui.Create( "DFrame" )
	EntPanel:SetPos( ScrW()/2 - 250, ScrH()/2 - 200 )
	EntPanel:SetSize( 500, 400 )
	EntPanel:SetTitle( "Custom Entities" )
	EntPanel:SetVisible( true )
	EntPanel:SetDraggable( false )
	EntPanel:ShowCloseButton( true )
	EntPanel.Paint = function()
		HH.DrawFrame( EntPanel )
	end
	function EntPanel:GetSkin()
         return SKIN;
    end
	EntPanel:MakePopup()
	
	local NonEnts = vgui.Create( "DListView", EntPanel )
	NonEnts:SetPos( 20, 45 )
	NonEnts:SetSize( 150, EntPanel:GetTall() - 70 )
	NonEnts:SetMultiSelect( false )
	NonEnts:AddColumn( "Added" )
	NonEnts:SetHideHeaders( true )
	
	local AddEnt = vgui.Create( "DButton", EntPanel )
	AddEnt:SetPos( EntPanel:GetWide()/2 - 50, EntPanel:GetTall()/2 - 65 )
	AddEnt:SetSize( 100, 30 )
	AddEnt:SetText( "Add Ent ->" )
	
	local Added = vgui.Create( "DListView", EntPanel )
	Added:SetPos( EntPanel:GetWide() - 170, 45 )
	Added:SetSize( 150, EntPanel:GetTall() - 70 )
	Added:SetMultiSelect( false )
	Added:AddColumn( "Added" )
	Added:SetHideHeaders( true )
		
	local RemoveEnt = vgui.Create( "DButton", EntPanel )
	RemoveEnt:SetPos( EntPanel:GetWide()/2 - 50, EntPanel:GetTall()/2 + 25 )
	RemoveEnt:SetSize( 100, 30 )
	RemoveEnt:SetText( "<- Remove Ent" )
	
	local function RefreshCombo()
		NonEnts:Clear()
		Added:Clear()
		local listedn = {}
		for k, v in pairs( ents.GetAll() ) do
			if( IsValid( v ) and !HH.IsCustomEnt( v:GetClass() ) and !table.HasValue( listedn, v:GetClass() ) and !table.HasValue( HH.InvalidEnts, v:GetClass() ) and string.Left( v:GetClass(), 8 ) != "class C_" and string.Left( v:GetClass(), 5 ) != "func_" and string.Left( v:GetClass(), 4 ) != "env_") then
				local item = NonEnts:AddLine( v:GetClass() )
				item.ent = v
				table.insert( listedn, v:GetClass() )
			end
		end
		
		local listeda= {}
		for k, v in pairs( HH.CustomEnts ) do
			local item = Added:AddLine( v )
			item.ent = v
			table.insert( listeda, v )
		end
	end
	RefreshCombo()
	
	local Clear = vgui.Create( "DButton", EntPanel )
	Clear:SetPos( EntPanel:GetWide()/2 - 45, EntPanel:GetTall() - 85 )
	Clear:SetSize( 90, 30 )
	Clear:SetText( "Clear" )
	Clear.DoClick = function()
		HH.ClearEnts( )
		RefreshCombo()
	end
	
	AddEnt.DoClick = function()
		if( #NonEnts:GetSelected() != 0 ) then
			HH.Notify( "Added: " .. NonEnts:GetSelected()[1].ent:GetClass(), false )
			HH.AddEnt( NonEnts:GetSelected()[1].ent:GetClass() )
			RefreshCombo()
		end
	end
	
	RemoveEnt.DoClick = function()
		if( #Added:GetSelected() != 0 ) then
			HH.Notify( "Removed: " .. Added