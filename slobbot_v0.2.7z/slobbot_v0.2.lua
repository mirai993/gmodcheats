---------------------------------------------
--Name: SlobBot
--Version: 0.2
--Author: Slob187 (obviously)
--Email: slob187.pb@gmail.com
--Revisor: lilEzek (lilezek@gmail.com)
---------------------------------------------

WOTS = {}
local minge = LocalPlayer()
local spining = false
local aiming = false
local SlobESPEnabled = false
local wireframeenabled = false
local canban = true
local DarkRPWallhackEnabled = false
local FakeView = Vector(0, 0, 0)


hook.Add("Think", "LocalFix", function()
	minge = LocalPlayer()
	if minge:IsValid() then
		hook.Remove("Think", "LocalFix")
		Msg("----SLOB BOT LOADED----\n")
	end
end)

CreateClientConVar("wots_aimbot_autoattack", "1", true, false) -- Auto atack at autoaim?
CreateClientConVar("wots_aimbot_autoattack_delay", "0", true, false) -- How much in seconds wait the weapon to shoot.
CreateClientConVar("wots_aimbot_teammode", "0", true, false) -- This turn off teammates xD.
CreateClientConVar("wots_aimbot_mouselock", "0", true, false) -- Use it for long range weapons
CreateClientConVar("wots_aimbot_add", "0", true, false) -- This add high to autoaim. With -40 you aim at feet.
CreateClientConVar("wots_buddy_1", "", true, false) -- Buddy 1 
CreateClientConVar("wots_buddy_2", "", true, false) -- Buddy 2
CreateClientConVar("wots_buddy_3", "", true, false) -- Buddy 3
CreateClientConVar("wots_buddy_4", "", true, false) -- Buddy 4
CreateClientConVar("wots_buddy_5", "", true, false) -- Buddy 5
CreateClientConVar("wots_buddy_attack", "0", true, false) -- Attack buddy too?
CreateClientConVar("wots_IsMegaspam", "0", true, false)
CreateClientConVar("wots_attackto", "1", true, false) -- 1 = players, 2 = npc, 3 = all
CreateClientConVar("wots_cm_x", "0", true, false)
CreateClientConVar("wots_cm_y", "0", true, false)
CreateClientConVar("wots_cm_z", "0", true, false)
CreateClientConVar("wots_cm_h", "0", true, false)
CreateClientConVar("wots_cm_w", "0", true, false)
CreateClientConVar("wots_followingto", "", true, false)
---------------------------- Aimbot code ---------------------------------
function SlobTeamAllowed(ent)
	if GetConVarNumber("wots_aimbot_teammode") >= 1 then
		if ent:Team() != minge:Team() then
			return true
		else
			return false
		end
	end
	return true
end

function EzekBuddyAllowed(ent)
	if ent:IsNPC() then 
		return true
	end
	if GetConVarNumber("wots_buddy_attack") >= 1 then 
		return true
	end
	if GetConVarString("wots_buddy_1") == ent:Nick() or
	GetConVarString("wots_buddy_2") == ent:Nick() or
	GetConVarString("wots_buddy_3") == ent:Nick() or
	GetConVarString("wots_buddy_4") == ent:Nick() or 
	GetConVarString("wots_buddy_5") == ent:Nick() then
		return false
	end
	return true
end

function SlobBotAllowed(ent)
	if !ent:IsValid() or !ent:IsNPC() and !ent:IsPlayer() or minge == ent then return false end
	if ent:IsPlayer() and !ent:Alive() then return false end
	if ent:IsPlayer() and string.find(string.lower(team.GetName(ent:Team())), "spectator") then return false end
	if ent:IsPlayer() and !SlobTeamAllowed(ent) then return false end
	if ent:IsNPC() and ent:GetMoveType() == 0 then return false end
	return true
end

function HeadPosition(ent)
	local hbone = ent:LookupBone("ValveBiped.Bip01_Head1")
	return ent:GetBonePosition(hbone) + Vector(0, 0, GetConVarNumber("wots_aimbot_add")) + EzekPerfectOffset(ent)
end

function GetSlobBotTarget()
	local position = minge:EyePos()
	local angle = minge:GetAimVector()
	local tar = {0,0}
	if GetConVarNumber("wots_attackto") == 1 then
		for _, ent in pairs(player.GetAll()) do
			if SlobBotAllowed(ent) and BotVisible(ent) and EzekBuddyAllowed(ent) then
				local targetpos = ent:EyePos()
				local difr = (targetpos-position):Normalize()
				difr = difr - angle
				difr = difr:Length()
				difr = math.abs(difr)
				if difr < tar[2] or tar[1] == 0 then
					tar = {ent, difr}
				end
			end
		end
	elseif GetConVarNumber("wots_attackto") == 2 then
		for _, ent in pairs(ents.GetAll()) do
			if ent:IsNPC() and ent:GetMoveType() != 0 and BotVisible(ent) then
				local targetpos = ent:EyePos()
				local difr = (targetpos-position):Normalize()
				difr = difr - angle
				difr = difr:Length()
				difr = math.abs(difr)
				if difr < tar[2] or tar[1] == 0 then
					tar = {ent, difr}
				end
			end
		end
	elseif GetConVarNumber("wots_attackto") == 3 then
		for _, ent in pairs(ents.GetAll()) do
			if SlobBotAllowed(ent) and BotVisible(ent) and EzekBuddyAllowed(ent) then
				local targetpos = ent:EyePos()
				local difr = (targetpos-position):Normalize()
				difr = difr - angle
				difr = difr:Length()
				difr = math.abs(difr)
				if difr < tar[2] or tar[1] == 0 then
					tar = {ent, difr}
				end
			end
		end
	end
	return tar[1]
end

_G.SafeAIM = _R["CUserCmd"].SetViewAngles

function SlobMegaAIM(UCMD)
	if aiming then
		local pwned = GetSlobBotTarget()
		if pwned != 0 then
			local targetaim = (HeadPosition(pwned) - minge:GetShootPos()):Angle()
			SafeAIM(UCMD, targetaim)
		end
		local tr = minge:GetEyeTrace()
		if SlobBotAllowed(tr.Entity) then
			if GetConVarNumber("wots_aimbot_mouselock") >= 1 then
				RunConsoleCommand("cl_mouseenable", "0")
			end
			if GetConVarNumber("wots_aimbot_autoattack") >= 1 then
				local aad = GetConVarNumber("wots_aimbot_autoattack_delay")
				if !timer.IsTimer("autoattack") then
					timer.Create("autoattack", aad, 0, function()
						RunConsoleCommand("wots_attack") -- Autoattack
					end)
				end
			end
		else
	        if GetConVarNumber("cl_mouseenable") == 0 then
		        RunConsoleCommand("cl_mouseenable", "1")
            end
			if timer.IsTimer("autoattack") then
				timer.Destroy("autoattack")
			end
		end
	end
end

hook.Add("CreateMove", "MingeBagAIMBot", SlobMegaAIM)

concommand.Add("wots_attack", function()
    LocalPlayer():ConCommand("+attack; wait 2; +attack; wait 2; -attack")
end)

concommand.Add("+slobpos", function()
    FakeView = minge:EyeAngles()
    aiming = true
end)

concommand.Add("-slobpos", function()
    aiming = false

	if GetConVarNumber("wots_aimbot_mouselock") >= 1 then
		RunConsoleCommand("cl_mouseenable", "1")
    end
    if timer.IsTimer("autoattack") then
	    timer.Destroy("autoattack")
	end
end)
-------------------------------------------------------------
--------------------------------- DarkRp Hack ---------------------------------
function RPSlobBotAllowed(ent)
	-- HAD TO USE THIS BECAUSE TABLES ONLY TRIGGER FIRST 2 ITEMS FOR SOME REASON
	if !(ent:IsValid()) then return false end 
	if (ent:GetClass() == nil) or (ent:GetClass() == "") or (string.find(ent:GetClass(), "physgun")) or (ent:GetOwner() == minge) then 
		return false 
	end
	if string.find(ent:GetClass(), "drug") or string.find(ent:GetClass(), "food") or
	string.find(ent:GetClass(), "drug") or string.find(ent:GetClass(), "gun") or
	string.find(ent:GetClass(), "melon") or string.find(ent:GetClass(), "money") or
	string.find(ent:GetClass(), "spawned") or string.find(ent:GetClass(), "microwave") or
	ent:GetModel() == "models/props/cs_assault/money.mdl" then
		return true
	else
		return false
	end
end

function SlobDarkRPHack()
	DarkRPWallhackEnabled = true
	hook.Add("HUDPaint", "DarkRPESP", function()
		for _, ent in pairs(ents.GetAll()) do
			if RPSlobBotAllowed(ent) then
				local rpepos = ent:GetPos()
				if rpepos:ToScreen().x > 0 and
				rpepos:ToScreen().y > 0 and
				rpepos:ToScreen().x < ScrW() and
				rpepos:ToScreen().y < ScrH() then
	                local rppos1 = (ent:LocalToWorld( Vector(0,0,0)) ):ToScreen()
                    if ent:GetModel() != "models/props/cs_assault/money.mdl" then
						draw.SimpleTextOutlined("Class: "..ent:GetClass(), "ScoreboardText", rppos1.x, rppos1.y, Color(0, 0, 255, 255), 2, 1, 1, Color(255, 255, 255, 255))
					else
						draw.SimpleTextOutlined("MONEY", "ScoreboardText", rppos1.x, rppos1.y, Color(0, 0, 255, 255), 2, 1, 1, Color(255, 255, 255, 255))
					end
				end
			end
		end
	end)
end

concommand.Add("wots_togglerphack", function()
    if DarkRPWallhackEnabled then
	    hook.Remove("HUDPaint", "DarkRPESP")
        SlobNotify("DarkRP mode: OFF")
		DarkRPWallhackEnabled = false
	elseif !DarkRPWallhackEnabled then
        SlobDarkRPHack()
        SlobNotify("DarkRP Mode: ON")
		DarkRPWallhackEnabled = true
    end
end)
------------------------------------------------------------------------------
--------------------------------- Wireframe Wallhack --------------------------------
function SlobWireFrameOn()
	wireframeenabled = true
	hook.Add("RenderScene", "SlobWireFrameHax", function()
		for _, ent in pairs(ents.GetAll()) do
				if wireframeenabled then
					if RPSlobBotAllowed(ent) then
						ent:SetMaterial("hlmv/debugmrmwireframe")
						ent:SetColor(255, 255, 255, 255)
					end
				end
			if SlobBotAllowed(ent) then
				if !BotVisible(ent) then
					local tc
					if ent:IsPlayer() then
						tc = team.GetColor(ent:Team())
					elseif ent:IsNPC() then
						tc = Color(0, 0, 255, 255)
					end
					ent:SetMaterial("hlmv/debugmrmwireframe")
					ent:SetColor(tc.r, tc.g, tc.b, 255)
				else
					ent:SetMaterial("")
					ent:SetColor(255, 255, 255, 255)
				end
		    end
	    end
    end)
end

concommand.Add("wots_togglewireframe", function()
    if wireframeenabled then
	    hook.Remove("RenderScene", "SlobWireFrameHax")
		for _, ent in pairs(ents.GetAll()) do
	        if RPSlobBotAllowed(ent) then
		    	ent:SetMaterial("")
		    elseif SlobBotAllowed(ent) then
		        ent:SetMaterial("")
                ent:SetColor(255, 255, 255, 255)
		    end
		end
        SlobNotify("WireFrame: OFF")
		wireframeenabled = false
	elseif !wireframeenabled then
        SlobWireFrameOn()
        SlobNotify("WireFrame: ON")
		wireframeenabled = true
    end
end)
------------------------------------------------------------------------------
--------------------------------  Espy Hack  --------------------------------
function SlobESPOn()
	SlobESPEnabled = true
	hook.Add("HUDPaint", "SlobESPOmg", function()
		draw.SimpleTextOutlined("Slob Bot", "ScoreboardText", 50, 10, Color(0, 0, 255, 255), 1, 1, 1, Color(255, 255, 255, 255))
		draw.SimpleTextOutlined("Wire Frame: "..tostring(wireframeenabled), "ScoreboardText", ScrW()/2, 10, Color(0, 0, 255, 255), 0, 1, 1, Color(255, 255, 255, 255))
		draw.SimpleTextOutlined("Banable: "..tostring(canban), "ScoreboardText", ScrW()/2, 25, Color(0, 0, 255, 255), 0, 1, 1, Color(255, 255, 255, 255))
		draw.SimpleTextOutlined("RP Wallhack: "..tostring(DarkRPWallhackEnabled), "ScoreboardText", ScrW()/2, 40, Color(0, 0, 255, 255), 0, 1, 1, Color(255, 255, 255, 255))
		for _, ent in pairs(ents.GetAll()) do
			if SlobBotAllowed(ent) then
				local epos = ent:GetPos()
				if epos:ToScreen().x > 0 and
				epos:ToScreen().y > 0 and
				epos:ToScreen().x < ScrW() and
				epos:ToScreen().y < ScrH() then
					local pos1 = (ent:LocalToWorld(Vector(0,0,70))):ToScreen()
					if ent:IsPlayer() then
						draw.SimpleTextOutlined("Name: "..ent:Nick(), "ScoreboardText", pos1.x, pos1.y+30, team.GetColor(ent:Team()), 2, 1, 1, Color(255, 255, 255, 255))
						draw.SimpleTextOutlined("Health: "..ent:Health(), "ScoreboardText", pos1.x, pos1.y+50, team.GetColor(ent:Team()), 2, 1, 1, Color(255, 255, 255, 255))
						if DarkRPWallhackEnabled then
							draw.SimpleTextOutlined("Money: $"..tonumber(ent:GetNWInt("money")), "ScoreboardText", pos1.x, pos1.y+70, team.GetColor(ent:Team()), 2, 1, 1, Color(255, 255, 255, 255))
						end

                        --local obbmax = ent:OBBMaxs()
		                --local obbsize = (ent:LocalToWorld(Vector(obbmax.x, obbmax.y, obbmax.z)):ToScreen())

						--surface.SetDrawColor(team.GetColor(ent:Team()))
						--surface.DrawOutlinedRect(1, 1, obbsize.y, obbsize.z)

					elseif ent:IsNPC() then
						draw.SimpleTextOutlined("Class: "..ent:GetClass(), "ScoreboardText", pos1.x, pos1.y+30, Color(0, 0, 255, 255), 2, 1, 1, Color(255, 255, 255, 255))
						--draw.SimpleTextOutlined("Health: "..ent:Health(), "ScoreboardText", pos1.x, pos1.y+50, Color(0, 0, 255), 2, 1, 1, Color(255, 255, 255, 255))
                    end

					if GetSlobBotTarget() == ent then
						draw.SimpleTextOutlined("TARGET", "ScoreboardText", pos1.x, pos1.y+10, Color(255, 0, 0, 255), 2, 1, 1, Color(255, 255, 255, 255))
						local tpos = HeadPosition(ent):ToScreen()
						local tcol
						if ent:IsPlayer() then
							tcol = team.GetColor(ent:Team())
						elseif ent:IsNPC() then
						    tcol = Color(0, 0, 255, 255)
						end
						surface.SetDrawColor(tcol.r, tcol.g, tcol.b, 255)
						surface.DrawLine(ScrW()/2, ScrH()/2, tpos.x, tpos.y)
					end
				end
		    end
	    end
    end)
end


concommand.Add("wots_toggleesp", function()
    if SlobESPEnabled then
	    hook.Remove("HUDPaint", "SlobESPOmg")
        SlobNotify("ESP: OFF")
		SlobESPEnabled = false
	elseif !SlobESPEnabled then
        SlobESPOn()
        SlobNotify("ESP: ON")
		SlobESPEnabled = true
    end
end)
-------------------------------------------------------------
---------------------------------  Menu ---------------------------------
local SlobPanel
local SlobList

function CreateSlobBotButton(a, b)
    SLOBBUTTON = vgui.Create("DButton")
    SLOBBUTTON:SetSize(0, 20)
    SLOBBUTTON:SetText(a)
    SLOBBUTTON.DoClick = function()
		RunConsoleCommand(b)
    end
    SlobList:AddItem(SLOBBUTTON)
end


concommand.Add("+wots_menu", function()
    SlobPanel = vgui.Create("DFrame")
	SlobPanel:Center()
    SlobPanel:SetSize(350, 350)
    SlobPanel:SetTitle("SlobBot v0.2")
    SlobPanel:SetVisible(true)
    SlobPanel:SetDraggable(true)
    SlobPanel:ShowCloseButton(false)
	SlobPanel.Paint = function()
		draw.RoundedBox(6, 0, 0, SlobPanel:GetWide(), SlobPanel:GetTall(), Color(176, 226, 255, 225))
		surface.SetDrawColor(color_white)
  		surface.DrawOutlinedRect(0, 0, SlobPanel:GetWide(), SlobPanel:GetTall())
	end
    SlobPanel:MakePopup()


    SlobList = vgui.Create("DPanelList", SlobPanel)
    SlobList:SetPos(30, 30)
    SlobList:SetSize(290, 290)
    SlobList:SetSpacing(5)
    SlobList:SetPadding(5)
    SlobList:EnableHorizontal(false)
    SlobList:EnableVerticalScrollbar(true)


    local AutoAttackCat = vgui.Create("DCheckBoxLabel")
    AutoAttackCat:SetText("Auto attack")
    AutoAttackCat:SetConVar("wots_aimbot_autoattack")
    AutoAttackCat:SetValue(GetConVarNumber("wots_aimbot_autoattack"))
    AutoAttackCat:SizeToContents()
    SlobList:AddItem(AutoAttackCat)


    local MouseLockCat = vgui.Create("DCheckBoxLabel")
    MouseLockCat:SetText("Mouse lock")
    MouseLockCat:SetConVar("wots_aimbot_mouselock")
    MouseLockCat:SetValue(GetConVarNumber("wots_aimbot_mouselock"))
    MouseLockCat:SizeToContents()
    SlobList:AddItem(MouseLockCat)


    local TeamModeCat = vgui.Create("DCheckBoxLabel")
    TeamModeCat:SetText("Team mode")
    TeamModeCat:SetConVar("wots_aimbot_teammode")
    TeamModeCat:SetValue(GetConVarNumber("wots_aimbot_teammode"))
    TeamModeCat:SizeToContents()
    SlobList:AddItem(TeamModeCat)

    local AADelay = vgui.Create("DNumSlider")
    AADelay:SetSize(150, 50)
    AADelay:SetText("Auto attack delay")
    AADelay:SetMin(0)
    AADelay:SetMax(10)
    AADelay:SetDecimals(1)
    AADelay:SetConVar("wots_aimbot_autoattack_delay")
    SlobList:AddItem(AADelay)

    local OFFSET = vgui.Create("DNumSlider")
    OFFSET:SetSize(150, 50)
    OFFSET:SetText("Offset")
    OFFSET:SetMin(-100)
    OFFSET:SetMax(100)
    OFFSET:SetDecimals(1)
    OFFSET:SetConVar("wots_aimbot_add")
    SlobList:AddItem(OFFSET)
	
	local attackto = vgui.Create("DNumSlider")
    attackto:SetSize(150, 50)
    attackto:SetText("1 = players, 2 = npc, 3 = both")
    attackto:SetMin(1)
    attackto:SetMax(3)
    attackto:SetDecimals(0)
    attackto:SetConVar("wots_attackto")
    SlobList:AddItem(attackto)
	
	local protectBuddys = vgui.Create("DCheckBoxLabel")
	protectBuddys:SetText("Protect players with this nickname:")
	protectBuddys:SetConVar("wots_buddy_attack")
	protectBuddys:SetValue(GetConVarNumber("wots_buddy_attack"))
	protectBuddys:SizeToContents()
	SlobList:AddItem(protectBuddys)
	
	local buddy1 = vgui.Create("DTextEntry")
	buddy1:SetSize(0,20)
	buddy1:SetText("Friend nickname here.")
	buddy1:SetConVar("wots_buddy_1")
	SlobList:AddItem(buddy1)
	
	local buddy2 = vgui.Create("DTextEntry")
	buddy2:SetSize(0,20)
	buddy2:SetText("Friend nickname here.")
	buddy2:SetConVar("wots_buddy_2")
	SlobList:AddItem(buddy2)
	
	local buddy3 = vgui.Create("DTextEntry")
	buddy3:SetSize(0,20)
	buddy3:SetText("Friend nickname here.")
	buddy3:SetConVar("wots_buddy_3")
	SlobList:AddItem(buddy3)
	
	local buddy4 = vgui.Create("DTextEntry")
	buddy4:SetSize(0,20)
	buddy4:SetText("Friend nickname here.")
	buddy4:SetConVar("wots_buddy_4")
	SlobList:AddItem(buddy4)
	
	local buddy5 = vgui.Create("DTextEntry")
	buddy5:SetSize(0,20)
	buddy5:SetText("Friend nickname here.")
	buddy5:SetConVar("wots_buddy_5")
	SlobList:AddItem(buddy5)

    CreateSlobBotButton("ESP", "wots_toggleesp")
	

	CreateSlobBotButton("SpyCamera", "wots_camera")

	local cameraposx = vgui.Create("DNumSlider")
    cameraposx:SetSize(150, 50)
    cameraposx:SetText("X pos of camera")
    cameraposx:SetMin(-10000)
    cameraposx:SetMax(10000)
    cameraposx:SetDecimals(2)
    cameraposx:SetConVar("wots_cm_x")
    SlobList:AddItem(cameraposx)
	
	local cameraposy = vgui.Create("DNumSlider")
    cameraposy:SetSize(150, 50)
    cameraposy:SetText("Y pos of camera")
    cameraposy:SetMin(-10000)
    cameraposy:SetMax(10000)
    cameraposy:SetDecimals(2)
    cameraposy:SetConVar("wots_cm_y")
    SlobList:AddItem(cameraposy)
	
	local cameraposz = vgui.Create("DNumSlider")
    cameraposz:SetSize(150, 50)
    cameraposz:SetText("Z pos of camera")
    cameraposz:SetMin(-10000)
    cameraposz:SetMax(10000)
    cameraposz:SetDecimals(2)
    cameraposz:SetConVar("wots_cm_z")
    SlobList:AddItem(cameraposz)
	
	local cameraposwidth = vgui.Create("DNumSlider")
    cameraposwidth:SetSize(150, 50)
    cameraposwidth:SetText("Width of camera")
    cameraposwidth:SetMin(1)
    cameraposwidth:SetMax(100)
    cameraposwidth:SetDecimals(0)
    cameraposwidth:SetConVar("wots_cm_w")
    SlobList:AddItem(cameraposwidth)
	
	local cameraposheight = vgui.Create("DNumSlider")
    cameraposheight:SetSize(150, 50)
    cameraposheight:SetText("Height of camera")
    cameraposheight:SetMin(1)
    cameraposheight:SetMax(100)
    cameraposheight:SetDecimals(0)
    cameraposheight:SetConVar("wots_cm_h")
    SlobList:AddItem(cameraposheight)

	CreateSlobBotButton("Follow this player","wots_camera_follow","wots_followingto")
	
	local followto = vgui.Create("DTextEntry")
	followto:SetSize(0,20)
	followto:SetText("Who to follow?")
	followto:SetConVar("wots_followingto")
	SlobList:AddItem(followto)
	
	local copy = vgui.Create("DLabel")
	copy:SetText("Click for copy a name")
	copy:SizeToContents()
	SlobList:AddItem(copy)
	
	local PlayersList = vgui.Create("DListView")
	PlayersList:SetParent(DermaPanel)
	PlayersList:SetPos(25, 50)
	PlayersList:SetSize(150, 150)
	PlayersList:SetMultiSelect(false)
	PlayersList:AddColumn("Name") // Add column
	PlayersList:AddColumn("Is admin?")	
	SlobList:AddItem(PlayersList)
	function PlayersList:OnRowSelected(Row)
		SlobNotify("Name copied to clipboard")
		SetClipboardText(listofplayers[Row])
	end
	listofplayers = {}
	for k,v in pairs(player.GetAll()) do
		PlayersList:AddLine(v:Nick(),tostring(v:IsAdmin()))
		table.insert(listofplayers, v:Nick())
	end 
			
	CreateSlobBotButton("Place cam here","wots_camerainmypos")
	
		
    CreateSlobBotButton("WireFrame", "wots_togglewireframe")


    CreateSlobBotButton("DarkRP mode", "wots_togglerphack")
	
	
	CreateSlobBotButton("Zombiefied World mode", "wots_togglezwhack")

	
    CreateSlobBotButton("Name changer", "wots_toggleimmunity")

	
	CreateSlobBotButton("Megaspam","wots_megaspam")

end)


concommand.Add("-wots_menu", function()
    SlobPanel:Close()
end)

------------------------------------------------------------------------------
--------------------------------  AntiBan System --------------------------------

local nicks = {}

local function EzekAntiBan()
	for i = 1, table.Count(nicks) do
		table.remove(nicks, i)
	end
	for _, faggot in pairs(player.GetAll()) do
		if faggot:Nick() != minge:Nick() then --just to be safer
			table.insert(nicks, faggot:Nick()..string.char(03)) --no space after the name yay
		end
	end
    if table.Count(nicks) > 0 then
		RunConsoleCommand("setinfo", "name", nicks[math.random(1, table.Count(nicks))])
	end
end

concommand.Add("wots_toggleimmunity", function()
    if canban then
	    canban = false
		hook.Add("Think","ChangeName",EzekAntiBan)
        SlobNotify("Toggle immunity: ON")
	elseif !canban then
	    canban = true
		hook.Remove("Think","ChangeName")
		SlobNotify("Toggle immunity: OFF")
	end
end)
------------------------------------------------------------------------------
---------------------------------  Varius ---------------------------------

-- Send notify.
function SlobNotify(str)
	if GAMEMODE.IsSandboxDerived then
		GAMEMODE:AddNotify(str, NOTIFY_CLEANUP, 5 )
	else
		LocalPlayer():ChatPrint(str)
	end
	print(str)
end

-- Returns if ent is visible.
function BotVisible(ent)
	local trace = {start = minge:GetShootPos(),endpos = HeadPosition(ent),filter = {minge, ent},mask = 1174421507}
	local tr = util.TraceLine(trace)
	if tr.Fraction == 1 then
		return true
	else
	    return false
	end
end

-- Spam the server

concommand.Add("wots_megaspam", function()
	if GetConVarNumber("wots_IsMegaspam") == 0 then
		SlobNotify("Toggle Mega spam: ON")
		hook.Add("Think", "Megaspam", function()
			RunConsoleCommand("say", "MINGE INVASION IS COMING "..math.random(1, 1337).." MINGES WILL DOMINATE GMOD")
		end)
		RunConsoleCommand("wots_IsMegaspam","1")
	else
		SlobNotify("Toggle Mega spam: OFF")
		hook.Remove("Think", "Megaspam")
		RunConsoleCommand("wots_IsMegaspam","0")
	end
end)
------------------------------------------------------------------------------
--------------------------------  Perfect offset --------------------------------
--List of perfect offset
EzekListEnt = {}
EzekListEnt["bsft.mdl"] = 40
EzekListEnt["stalker_snork_fast.mdl"] = 40
EzekListEnt["z0mbie/classic.mdl"] = 55 
EzekListEnt["hellknight_anim.mdl"] = 100

function EzekPerfectOffset(ent)
	for model,offset in pairs(EzekListEnt) do
		if string.find(ent:GetModel(), model) then
			return Vector(0,0,offset)
		end
	end
	return Vector(0,0,0)
end
------------------------------------------------------------------------------
--------------------------------  Camera system --------------------------------
local IsCameraPlaced = false
CameraEntity = ents.Create("prop_physics")

function EzekRemoveCameraEntity()
	CameraEntity:Remove()
end

function EzekShowCameraEntity()
	if !CameraEntity:IsValid( ) then
		CameraEntity = ents.Create("prop_physics")
	end
	CameraEntity:SetModel( "models/dav0r/camera.mdl" )
	CameraEntity:SetPos( Vector(GetConVarNumber("wots_cm_x"),GetConVarNumber("wots_cm_y"),GetConVarNumber("wots_cm_z")) )
	CameraEntity:SetAngles( LocalPlayer():EyeAngles() )
	CameraEntity:SetOwner( minge )
	CameraEntity:DrawModel()
	CameraEntity:Spawn()
	CameraEntity:SetColor(0, 255, 255, 255)
	CameraEntity:SetMaterial("hlmv/debugmrmwireframe")
end

function EzekRenderSpyCamera()
	local CamData = {}
	CamData.angles = LocalPlayer():EyeAngles()
	CamData.origin = Vector(GetConVarNumber("wots_cm_x"),GetConVarNumber("wots_cm_y"),GetConVarNumber("wots_cm_z"))
	CamData.x = 0
	CamData.y = 0
	CamData.w = ScrW() * GetConVarNumber("wots_cm_w")/100
	CamData.h = ScrH() * GetConVarNumber("wots_cm_h")/100
	render.RenderView( CamData )
	EzekShowCameraEntity()
end

concommand.Add("wots_camerainmypos", function()
	RunConsoleCommand("wots_cm_x", minge:GetPos().x)
	RunConsoleCommand("wots_cm_y", minge:GetPos().y)
	RunConsoleCommand("wots_cm_z", minge:GetPos().z + 60)
end)


concommand.Add("wots_camera", function()
	if IsCameraPlaced then
		EzekRemoveCameraEntity()
		SlobNotify("Toggle camera: OFF")
		IsCameraPlaced = false
		hook.Remove("HUDPaint", "OriginCam")
	else
		SlobNotify("Toggle camera: ON")
		IsCameraPlaced = true
		hook.Add("HUDPaint", "OriginCam", EzekRenderSpyCamera) 
	end
end)

concommand.Add("+wots_movecamera", function(ply, com, args )
	if !CameraEntity:IsValid( ) then
		return false
	else
		timer.Create("cameramove", 0, 9999999999999999, RunConsoleCommand, "+wots_movecamera",args[1])  
		CameraEntity:SetPos( CameraEntity:GetForward()*args[1] + CameraEntity:GetPos() )
		RunConsoleCommand("wots_cm_x", CameraEntity:GetPos().x)
		RunConsoleCommand("wots_cm_y", CameraEntity:GetPos().y)
		RunConsoleCommand("wots_cm_z", CameraEntity:GetPos().z)
	end
end)

concommand.Add("-wots_movecamera", function(ply, com, args )
	timer.Destroy("cameramove")
end)

concommand.Add("wots_camera_follow", function(ply, com, args)
	if CamIsFollowing then
		timer.Destroy("following")
		SlobNotify("Stop following")
		CamIsFollowing = false
		return false
	end		
	local PlayerExist = false
	for _,v in pairs(player.GetAll()) do
		if GetConVarString("wots_followingto") == v:Nick() then
			PlayerExist = true
		end
	end
	if !PlayerExist then 
		SlobNotify("Player doesn't exist")
		return false 
	end
	SlobNotify("Start following")
	CamIsFollowing = true
	timer.Create("following",0,9999999999999999, function()
		for _,v in pairs(player.GetAll()) do
			if v:Nick() == GetConVarString("wots_followingto") then
				RunConsoleCommand("wots_cm_x", v:GetPos().x)
				RunConsoleCommand("wots_cm_y", v:GetPos().y)
				RunConsoleCommand("wots_cm_z", v:GetPos().z+55)
			end
		end
	end)
end)
------------------------------------------------------------------------------
--------------------------------- Zombified World hack --------------------------------

function ZWEzekAllowed(ent)
	if !(ent:IsValid()) then return false end 
	if (ent:GetClass() == nil) or (ent:GetClass() == "") or (string.find(ent:GetClass(), "physgun")) or (ent:GetOwner() == minge) then 
		return false 
	end
	if string.find(ent:GetClass(), "fists") or string.find(ent:GetClass(), "faction") or string.find(ent:GetClass(), "zw_bed") then
		return true
	else
		return false
	end
end

function EzekZWHack()
	ZWhackEnabled = true
	hook.Add("HUDPaint", "ZWhack", function()
		for _, ent in pairs(ents.GetAll()) do
			if ZWEzekAllowed(ent) then
				local rpepos = ent:GetPos()
				if rpepos:ToScreen().x > 0 and
				rpepos:ToScreen().y > 0 and
				rpepos:ToScreen().x < ScrW() and
				rpepos:ToScreen().y < ScrH() then
                local rppos1 = (ent:LocalToWorld( Vector(0,0,0)) ):ToScreen()
                   	draw.SimpleTextOutlined("Class: "..ent:GetClass(), "ScoreboardText", rppos1.x, rppos1.y, Color(0, 0, 255, 255), 2, 1, 1, Color(255, 255, 255, 255))
				end
			end
		end
	end)
end

concommand.Add("wots_togglezwhack", function()
    if ZWhackEnabled then
	    hook.Remove("HUDPaint", "ZWhack")
        SlobNotify("Zombified world mode: OFF")
		ZWhackEnabled = false
	elseif !ZWhackEnabled then
        EzekZWHack()
        SlobNotify("Zombified world Mode: ON")
		ZWhackEnabled = true
    end
end)

------------------------------------------------------------------------------