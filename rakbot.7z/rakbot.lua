--[[
	MOD/lua/scripts/RakBot.lua [#37833 (#37833), 3241991234, UID:964580249]
	★ StatTrak™ Raklatif | STEAM_0:0:28961696 <92.98.143.220:27005> | [20.07.14 05:04:55PM]
	===BadFile===
]]

-- VARIABLES

local RakBotSayPrefix = CreateClientConVar( "rak_bot_sayprefix", "", true, false )
local RakBotSayDelay = 0

local RakBotOn = CreateClientConVar( "rak_bot_on", 1, true, false )
local RakBotHealth = CreateClientConVar( "rak_bot_health", 1, true, false )
local RakBotWeapon = CreateClientConVar( "rak_bot_weapon", 1, true, false )
local RakBotMoney = CreateClientConVar( "rak_bot_money", 1, true, false )
local RakBotDistance = CreateClientConVar( "rak_bot_distance", 1, true, false )
local RakBotSpeed = CreateClientConVar( "rak_bot_speed", 1, true, false )

local RakBotMirror = CreateClientConVar( "rak_bot_mirror", 0, true, false )
local RakBotMirrorx = CreateClientConVar( "rak_bot_mirrorx", 0, true, false )
local RakBotMirrory = CreateClientConVar( "rak_bot_mirrory", 0, true, false )
local RakBotMirrorw = CreateClientConVar( "rak_bot_mirrorw", 300, true, false )
local RakBotMirrorh = CreateClientConVar( "rak_bot_mirrorh", 300, true, false )
local RakBotMirrorpitch = CreateClientConVar( "rak_bot_mirrorpitch", -2, true, false )
local RakBotMirroryaw = CreateClientConVar( "rak_bot_mirroryaw", 180, true, false )
local RakBotMirrorroll = CreateClientConVar( "rak_bot_mirrorroll", 0, true, false )

local RakBotRadar = CreateClientConVar( "rak_bot_radar", 0, true, false )
local RakBotRadarx = CreateClientConVar( "rak_bot_radarx", 0, true, false )
local RakBotRadary = CreateClientConVar( "rak_bot_radary", 0, true, false )
local RakBotRadarw = CreateClientConVar( "rak_bot_radarw", 300, true, false )
local RakBotRadarh = CreateClientConVar( "rak_bot_radarh", 300, true, false )
local RakBotRadarfov = CreateClientConVar( "rak_bot_radarfov", 300, true, false )
local RakBotRadarauto = CreateClientConVar( "rak_bot_radarauto", 1, true, false )

local RakBotAimdot = CreateClientConVar( "rak_bot_aimdot", 0, true, false )
local RakBotAimdotfilt = CreateClientConVar( "rak_bot_aimdotfilter", 1, true, false )

local RakBotLight = false
local RakBotAura = false
local RakBotToggleCommands = {}

local RakBotVoteTime = CreateClientConVar( "rak_bot_votetime", 120, true, false )
local RakBotVoteVoted = {}
local RakBotVoteVotes = {}
local RakBotVoteType = 0

local RakBotDetects = {}
local RakBotDetected = {}
local RakBotDetectShow = CreateClientConVar( "rak_bot_detectshow", 1, true, false )
local RakBotDetectShowRad = CreateClientConVar( "rak_bot_detectshowrad", 0, true, false )
local RakBotDetectThreshold = CreateClientConVar( "rak_bot_detectthresh", 100, true, false )
local RakBotDetectTrace = CreateClientConVar( "rak_bot_detecttrace", 0, true, false )

local RakBotXRay = false
local RakBotXRayMat = CreateClientConVar( "rak_bot_xraymat", "xraysolid", true, false )
local RakBotXRayColors = {}
local RakBotXRayMats = {}

local RakBotReverseChat = CreateClientConVar( "rak_bot_chatreverse", 0, true, false )
local RakBotCambChat = CreateClientConVar( "rak_bot_chatcambridge", 0, true, false )
local RakBotByteChat = CreateClientConVar( "rak_bot_chatbyte", 0, true, false )


-- ENTITY SAVING

local RakBotObjectsConvar = CreateClientConVar( "rak_bot_objects", "", true, false )
local RakBotObjects = {}
if RakBotObjectsConvar:GetString() ~= "" then
	RakBotObjects = string.Explode( "|", RakBotObjectsConvar:GetString() )
end

-- UTILITY

local function RakBotGetOffset( ply )
	if !IsValid( ply ) then return Vector( 0, 0, 0 ) end
	if !ply:GetAttachment( ply:LookupAttachment( "eyes" ) ) then
		return ply:GetShootPos():ToScreen()
	else
		return ply:GetAttachment( ply:LookupAttachment( "eyes" ) ).Pos:ToScreen()
	end
end

local function RakBotSay( text )
	if string.len( RakBotSayPrefix:GetString() .. text ) > 125 then
		timer.Simple( 2 * ( RakBotSayDelay + 1 ), RakBotSay, string.sub( RakBotSayPrefix:GetString() .. text, 127 ) )
	end
	timer.Simple( 2 * RakBotSayDelay, function()
		RakBotSayDelay = RakBotSayDelay - 1
		RunConsoleCommand( "say", RakBotSayPrefix:GetString() .. text )
	end )
	RakBotSayDelay = RakBotSayDelay + 1
end

-- MAIN DRAWING

local function RakBotDraw()
	if RakBotAimdot:GetInt() > 0 then
		for _, v in pairs( player.GetAll() ) do
			if RakBotAimdotfilt:GetInt() > 0 then
				if !util.TraceLine( { start = LocalPlayer():GetShootPos(), endpos = v:GetEyeTrace().HitPos, filter = LocalPlayer() } ).Hit and v ~= LocalPlayer() then
					local o = v:GetEyeTrace().HitPos:ToScreen()
					surface.SetDrawColor( 0, 0, 0, 255 )
					surface.DrawRect( o.x - 2, o.y - 2, 4, 4 )
					local col = team.GetColor( v:Team() )
					surface.SetDrawColor( col.r, col.g, col.b, 255 )
					surface.DrawRect( o.x - 1, o.y - 1, 2, 2 )
					
					surface.SetDrawColor( 0, 0, 0, 50 )
					surface.SetFont( "Default" )
					surface.DrawRect( o.x - surface.GetTextSize( v:Nick() ) / 2, o.y + 7, surface.GetTextSize( v:Nick() ) + 2, 12 )
					surface.SetTextColor( 255, 255, 255, 255 )
					surface.SetTextPos( o.x - ( surface.GetTextSize( v:Nick() ) ) / 2 + 1, o.y + 6 )
					surface.DrawText( v:Nick() )
				end
			else
				if v ~= LocalPlayer() then
					local o = v:GetEyeTrace().HitPos:ToScreen()
					surface.SetDrawColor( 0, 0, 0, 255 )
					surface.DrawRect( o.x - 2, o.y - 2, 4, 4 )
					local col = team.GetColor( v:Team() )
					surface.SetDrawColor( col.r, col.g, col.b, 255 )
					surface.DrawRect( o.x - 1, o.y - 1, 2, 2 )
					
					surface.SetDrawColor( 0, 0, 0, 50 )
					surface.SetFont( "Default" )
					surface.DrawRect( o.x - surface.GetTextSize( v:Nick() ) / 2, o.y + 7, surface.GetTextSize( v:Nick() ) + 2, 12 )
					surface.SetTextColor( 255, 255, 255, 255 )
					surface.SetTextPos( o.x - ( surface.GetTextSize( v:Nick() ) ) / 2 + 1, o.y + 6 )
					surface.DrawText( v:Nick() )
				end
			end
		end
	end
	if RakBotOn:GetInt() > 0 then
		for _, v in pairs( RakBotObjects ) do
			if v ~= "" then
				for k, b in pairs( ents.GetAll() ) do
					if string.find( string.lower( b:GetClass() ), string.lower( v ) ) then
						local o = b:GetPos():ToScreen()
						surface.SetDrawColor( 0, 0, 0, 255 )
						surface.DrawRect( o.x - 6, o.y - 6, 12, 12 )
						surface.SetDrawColor( 255, 255, 255, 255 )
						surface.DrawRect( o.x - 5, o.y - 5, 10, 10 )
						
						surface.SetFont( "Default" )
						
						surface.SetDrawColor( 0, 0, 0, 50 )
						surface.DrawRect( o.x + 12, o.y - 6, surface.GetTextSize( b:GetClass() ) + 2, 12 )
						surface.SetTextColor( 255, 255, 255, 255 )
						surface.SetTextPos( o.x + 13, o.y - 7 )
						surface.DrawText( b:GetClass() )
						
						surface.SetDrawColor( 0, 0, 0, 50 )
						surface.SetFont( "Default" )
						surface.DrawRect( o.x - 6, o.y - 19, surface.GetTextSize( "D: " .. math.floor( b:GetPos():Distance( LocalPlayer():GetPos() ) ) ) + 2, 12 )
						surface.SetTextColor( 255, 255, 255, 255 )
						surface.SetTextPos( o.x - 5, o.y - 20 )
						surface.DrawText( "D: " .. math.floor( b:GetPos():Distance( LocalPlayer():GetPos() ) ) )
					end
				end
			end
		end
		for _, v in pairs( player.GetAll() ) do
			if v:Alive() and v ~= LocalPlayer() then
				local o = RakBotGetOffset( v )
				
				if v:GetPos():Distance( LocalPlayer():GetPos() ) < 500 then
					o.y = o.y - ( 100 - v:GetPos():Distance( LocalPlayer():GetPos() ) / 5 )
				end
				
				local color = team.GetColor( v:Team() )
				surface.SetDrawColor( 0, 0, 0, 255 )
				surface.DrawRect( o.x - 6, o.y - 6, 12, 12 )
				surface.SetDrawColor( 0, 0, 255, 255 )
				if v:IsSuperAdmin() then
					surface.SetDrawColor( 255, 0, 0, 255 )
				elseif v:IsAdmin() then
					surface.SetDrawColor( 0, 255, 0, 255 )
				end
				surface.DrawRect( o.x - 5, o.y - 5, 10, 10 )
				surface.SetDrawColor( 0, 0, 0, 255 )
				surface.DrawRect( o.x - 3, o.y - 3, 6, 6 )
				surface.SetDrawColor( color.r, color.g, color.b, 255 )
				surface.DrawRect( o.x - 2, o.y - 2, 4, 4 )
				
				surface.SetFont( "Default" )
				
				surface.SetDrawColor( 0, 0, 0, 50 )
				surface.DrawRect( o.x + 12, o.y - 6, surface.GetTextSize( v:Nick() ) + 2, 12 )
				surface.SetTextColor( 255, 255, 255, 255 )
				surface.SetTextPos( o.x + 13, o.y - 7 )
				surface.DrawText( v:Nick() )
				
				if RakBotDistance:GetInt() > 0 then
					surface.SetDrawColor( 0, 0, 0, 50 )
					surface.SetFont( "Default" )
					surface.DrawRect( o.x - 6, o.y - 19, surface.GetTextSize( "D: " .. math.floor( v:GetPos():Distance( LocalPlayer():GetPos() ) ) ) + 2, 12 )
					surface.SetTextColor( 255, 255, 255, 255 )
					surface.SetTextPos( o.x - 5, o.y - 20 )
					surface.DrawText( "D: " .. math.floor( v:GetPos():Distance( LocalPlayer():GetPos() ) ) )
				end
				
				if RakBotHealth:GetInt() > 0 then
					surface.SetDrawColor( 0, 0, 0, 50 )
					surface.SetFont( "Default" )
					surface.DrawRect( o.x - 6, o.y + 7, surface.GetTextSize( "HP: " .. v:Health() ) + 2, 12 )
					surface.SetTextColor( 255, 255, 255, 255 )
					surface.SetTextPos( o.x - 5, o.y + 6 )
					surface.DrawText( "HP: " .. v:Health() )
				end
				
				if RakBotMoney:GetInt() > 0 and v:GetNetworkedInt( "Money" ) ~= 0 then
					surface.SetDrawColor( 0, 0, 0, 50 )
					surface.SetFont( "Default" )
					local add = 19
					if RakBotDistance:GetInt() > 0 then add = 32 end
					surface.DrawRect( o.x - 6, o.y - add, surface.GetTextSize( "$: " .. v:GetNWInt( "Money" ) ) + 2, 12 )
					surface.SetTextColor( 255, 255, 255, 255 )
					surface.SetTextPos( o.x - 5, o.y - add - 1 )
					surface.DrawText( "$: " .. v:GetNWInt( "Money" ) )
				end
				
				if RakBotWeapon:GetInt() > 0 and v:GetActiveWeapon():IsValid() then
					surface.SetDrawColor( 0, 0, 0, 50 )
					surface.SetFont( "Default" )
					local add = 6
					if RakBotHealth:GetInt() > 0 then add = 19 end
					surface.DrawRect( o.x - 6, o.y + add + 1, surface.GetTextSize( v:GetActiveWeapon():GetPrintName() ) + 2, 12 )
					surface.SetTextColor( 255, 255, 255, 255 )
					surface.SetTextPos( o.x - 5, o.y + add )
					surface.DrawText( v:GetActiveWeapon():GetPrintName() )
				end
				
			end
		end
	end
	if RakBotMirror:GetInt() > 0 then
		local pitch = RakBotMirrorpitch:GetInt()
		if pitch < 0 then pitch = pitch * LocalPlayer():EyeAngles().p end
		local yaw = RakBotMirroryaw:GetInt()
		if yaw < 0 then yaw = yaw * LocalPlayer():EyeAngles().y end
		local roll = RakBotMirrorroll:GetInt()
		if roll < 0 then roll = roll * LocalPlayer():EyeAngles().r end
		
		local Cam = {}
		Cam.angles = Angle( LocalPlayer():EyeAngles().p + pitch, LocalPlayer():EyeAngles().y + yaw, LocalPlayer():EyeAngles().r + roll )
		Cam.origin = LocalPlayer():GetShootPos()
		Cam.x = RakBotMirrorx:GetInt()
		Cam.y = RakBotMirrory:GetInt()
		Cam.w = RakBotMirrorw:GetInt()
		Cam.h = RakBotMirrorh:GetInt()
		render.RenderView( Cam )
		surface.SetDrawColor( 0, 0, 0, 255 )
		surface.DrawOutlinedRect( RakBotMirrorx:GetInt(), RakBotMirrory:GetInt(), RakBotMirrorw:GetInt(),RakBotMirrorh:GetInt() )
		surface.SetDrawColor( 255, 255, 255, 255 )
		surface.DrawRect( ScrW() / 2 - 1, ScrH() / 2 - 1, 2, 2 )
	end
	if RakBotRadar:GetInt() > 0 then
		local Cam = {}
		Cam.angles = Angle( 90, LocalPlayer():EyeAngles().y, 0 )
		
		local Zvar = RakBotRadarfov:GetInt()
		if RakBotRadarauto:GetInt() > 0 then
			local trace = {}
			trace.start = LocalPlayer():GetPos() + Vector( 0, 0, 5 )
			trace.endpos = LocalPlayer():GetPos() + Vector( 0, 0, RakBotRadarfov:GetInt() )
			trace.filter = LocalPlayer()
			if util.TraceLine( trace ).Hit then
				Zvar = util.TraceLine( trace ).HitPos.z - 5 - LocalPlayer():GetPos().z
			end
		end
		
		Cam.origin = LocalPlayer():GetPos() + Vector( 0, 0, Zvar )
		Cam.x = RakBotRadarx:GetInt()
		Cam.y = RakBotRadary:GetInt()
		Cam.w = RakBotRadarw:GetInt()
		Cam.h = RakBotRadarh:GetInt()
		render.RenderView( Cam )
		surface.SetDrawColor( 0, 0, 0, 255 )
		surface.DrawOutlinedRect( RakBotRadarx:GetInt(), RakBotRadary:GetInt(), RakBotRadarw:GetInt(),RakBotRadarh:GetInt() )
		surface.SetDrawColor( 255, 255, 255, 255 )
		surface.DrawRect( ScrW() / 2 - 1, ScrH() / 2 - 1, 2, 2 )
	end
	for k, v in pairs( RakBotDetects ) do
		if RakBotDetectShow:GetInt() > 0 then
			local o = v:ToScreen()
			surface.SetDrawColor( 0, 0, 0, 255 )
			surface.DrawRect( o.x - 2, o.y - 2, 4, 4 )
			surface.SetDrawColor( 200, 50, 50, 255 )
			surface.DrawRect( o.x - 1, o.y - 1, 2, 2 )
			
			surface.SetDrawColor( 0, 0, 0, 50 )
			surface.SetFont( "Default" )
			surface.DrawRect( o.x - surface.GetTextSize( "DET " .. k ) / 2, o.y + 7, surface.GetTextSize( "DET " .. k ) + 2, 12 )
			surface.SetTextColor( 255, 255, 255, 255 )
			surface.SetTextPos( o.x - ( surface.GetTextSize( "DET " .. k ) ) / 2 + 1, o.y + 6 )
			surface.DrawText( "DET " .. k )
			if RakBotDetectShowRad:GetInt() > 0 then
				for i = 1, 6 do
					local o = ( v + Vector( math.sin( i * 1 ) * RakBotDetectThreshold:GetInt(), math.cos( i * 1 ) * RakBotDetectThreshold:GetInt(), 0 ) ):ToScreen()
					local o2 = ( v + Vector( math.sin( ( i + 1 ) * 1 ) * RakBotDetectThreshold:GetInt(), math.cos( ( i + 1 ) * 1 ) * RakBotDetectThreshold:GetInt(), 0 ) ):ToScreen()
					
					surface.SetDrawColor( 255, 0, 0, 255 )
					surface.DrawLine( o.x, o.y, o2.x, o2.y )
				end
			end
		end
	end
end
hook.Add( "HUDPaint", "RakBot", RakBotDraw )

local function RakBotThink()
	if RakBotLight then
		local light = DynamicLight( LocalPlayer():UserID() )
		if light then
			light.Pos = LocalPlayer():GetEyeTrace().HitPos
			light.r = 255
			light.g = 255
			light.b = 255
			light.Brightness = 10
			light.Size = 800
			light.Decay = 0
			light.DieTime = CurTime() + 0.2
		end
	end
	if RakBotAura then
		local light = DynamicLight( LocalPlayer():UserID() )
		if light then
			light.Pos = LocalPlayer():GetPos()
			light.r = 255
			light.g = 255
			light.b = 255
			light.Brightness = 10
			light.Size = 800
			light.Decay = 0
			light.DieTime = CurTime() + 0.2
		end
	end
	for k, v in pairs( RakBotDetects ) do
		for b, n in pairs( player.GetAll() ) do
			if RakBotDetectTrace:GetInt() > 0 then
				if n:GetPos():Distance( v ) < RakBotDetectThreshold:GetInt() and !util.TraceLine( { start = v + Vector( 0, 0, 5 ), endpos = n:GetPos() } ).Hit and RakBotDetected[ n:UniqueID() ] ~= true then
					chat.AddText( "Detector " .. k .. " breached by " .. n:Nick() )
					RakBotDetected[ n:UniqueID() ] = true
				elseif n:GetPos():Distance( v ) > RakBotDetectThreshold:GetInt() then
					RakBotDetected[ n:UniqueID() ] = false
				end
			else
				if n:GetPos():Distance( v ) < RakBotDetectThreshold:GetInt() and RakBotDetected[ n:UniqueID() ] ~= true then
					chat.AddText( "Detector " .. k .. " breached by " .. n:Nick() )
					RakBotDetected[ n:UniqueID() ] = true
				elseif n:GetPos():Distance( v ) > RakBotDetectThreshold:GetInt() then
					RakBotDetected[ n:UniqueID() ] = false
				end
			end
		end
	end
end
hook.Add( "Think", "RakBot", RakBotThink )

concommand.Add( "rak_bot_light", function() RakBotLight = !RakBotLight end )
concommand.Add( "rak_bot_aura", function() RakBotAura = !RakBotAura end )

local function RakBotDetectAdd()
	table.insert( RakBotDetects, LocalPlayer():GetPos() )
	chat.AddText( "Detector " .. #RakBotDetects .. " placed" )
end

local function RakBotDetectRemove()
	if #RakBotDetects > 0 then
		local best = 99999
		local var = 0
		for k, v in pairs( RakBotDetects ) do
			if v:Distance( LocalPlayer():GetPos() ) < best then
				best = v:Distance( LocalPlayer():GetPos() )
				var = k
			end
		end
		table.remove( RakBotDetects, var )
		chat.AddText( "Detector " .. var .. " removed" )
	end
end

concommand.Add( "rak_bot_detectadd", RakBotDetectAdd )
concommand.Add( "rak_bot_detectremove", RakBotDetectRemove )


-- VOTE

local function RakBotVoteChat( ply, text, tchat, dead )
	if ply ~= LocalPlayer() and ply:EntIndex() ~= 0 and RakBotVoteType ~= 0 then
		if !table.HasValue( RakBotVoteVoted, ply ) then
			if RakBotVoteType == 1 then
				if string.find( string.lower( text ), "!yes" ) then
					table.insert( RakBotVoteVoted, ply )
					RakBotVoteVotes[ "yes" ] = RakBotVoteVotes[ "yes" ] + 1
					RakBotSay( "Player " .. ply:Nick() .. " voted for. (+" .. RakBotVoteVotes[ "yes" ] .. "/-" .. RakBotVoteVotes[ "no" ] .. ")" )
				elseif string.find( string.lower( text ), "!no" ) then
					table.insert( RakBotVoteVoted, ply )
					RakBotVoteVotes[ "no" ] = RakBotVoteVotes[ "no" ] + 1
					RakBotSay( "Player " .. ply:Nick() .. " voted against. (+" .. RakBotVoteVotes[ "yes" ] .. "/-" .. RakBotVoteVotes[ "no" ] .. ")" )
				end
			end
			if RakBotVoteType == 2 then
				if string.find( text, "!" ) then
					for k, v in pairs( RakBotVoteVotes ) do
						if string.lower( string.sub( text, string.find( text, "!" ) + 1 ) ) == string.lower( k ) then
							table.insert( RakBotVoteVoted, ply )
							RakBotVoteVotes[ string.lower( string.sub( text, string.find( text, "!" ) + 1 ) ) ] = v + 1
							RakBotSay( "Player " .. ply:Nick() .. " voted for " .. k .. " with " .. v .. " other(s)." )
							return
						end
					end
					table.insert( RakBotVoteVoted, ply )
					RakBotVoteVotes[ string.sub( text, string.find( text, "!" ) + 1 ) ] = 1
					RakBotSay( "Player " .. ply:Nick() .. " voted for " .. string.sub( text, string.find( text, "!" ) + 1 ) .. "." )
				end
			end
		end
	end
	if ply == LocalPlayer() then
		RakBotSayDelay = RakBotSayDelay + 1
		timer.Simple( 2, function() RakBotSayDelay = RakBotSayDelay - 1 end )
	end
	
	-- CHAT NOMMERS
	
	if RakBotReverseChat:GetInt() > 0 and ply ~= LocalPlayer() then
		RakBotSay( string.reverse( text ) )
	end
	
	if RakBotByteChat:GetInt() > 0 and ply~= LocalPlayer() then
		local said = {}
		for _, k in pairs( string.ToTable( text ) ) do
			table.insert( said, string.byte( k ) )
		end
		RakBotSay( table.concat( said, " " ) )
	end
	
	if RakBotCambChat:GetInt() > 0 and ply ~= LocalPlayer() then
		local tosay = ""
		for k, v in pairs( string.Explode( " ", text ) ) do
			if string.len( v ) > 1 then
				local word = string.sub( v, 2, string.len( v ) - 1 )
				word = string.ToTable( word )
				table.sort( word, function( a, b ) return ( math.random( 0, 1 ) == 0 ) end )
				word = table.concat( word, "" )
				tosay = tosay .. string.Left( v, 1 ) .. word .. string.Right( v, 1 ) .. " "
			else
				tosay = tosay .. v .. " "
			end
		end
		RakBotSay( string.Left( tosay, string.len( tosay ) - 1 ) )
	end
end
hook.Add( "OnPlayerChat", "RakBot", RakBotVoteChat )

local function RakBotVoteStartYN( ply, com, args )
	if RakBotVoteType ~= 0 then
		RakBotVoteStop()
	end
	RakBotVoteType = 1
	RakBotSay( "RakBot: \"" .. ( args[1] or "VOTE" ) .. "\". Vote with !yes or !no" )
	RakBotVoteVotes[ "yes" ] = 0
	RakBotVoteVotes[ "no" ] = 0
	timer.Create( "RakBotVote", RakBotVoteTime:GetInt(), 1, RunConsoleCommand, "rak_bot_votestop" )
end

local function RakBotVoteStartOpen( ply, com, args )
	if RakBotVoteType ~= 0 then
		RakBotVoteStop()
	end
	RakBotVoteType = 2
	RakBotSay( "RakBot: \"" .. ( args[1] or "VOTE" ) .. "\". Vote with ! then what you want to vote." )
	timer.Create( "RakBotVote", RakBotVoteTime:GetInt(), 1, RunConsoleCommand, "rak_bot_votestop" )
end

local function RakBotVoteStop()
	if timer.Exists( "RakBotVote" ) then
		timer.Stop( "RakBotVote" )
	end
	
	RakBotSay( "Vote Over. Results:" )
	
	if RakBotVoteType == 1 then
		local extra = ""
		if RakBotVoteVotes[ "yes" ] > RakBotVoteVotes[ "no" ] then
			extra = "Vote Passed."
		elseif RakBotVoteVotes[ "yes" ] < RakBotVoteVotes[ "no" ] then
			extra = "Vote Failed."
		elseif RakBotVoteVotes[ "yes" ] + RakBotVoteVotes[ "no" ] == 0 then
			extra = "Nobody Voted."
		elseif RakBotVoteVotes[ "yes" ] == RakBotVoteVotes[ "no" ] then
			extra = "Vote Undecided."
		else
			extra = "LOLWAT GLITCH"
		end
		
		RakBotSay( "+" .. RakBotVoteVotes[ "yes" ] .. " -" .. RakBotVoteVotes[ "no" ] .. " " .. extra )
	end
	if RakBotVoteType == 2 then
		--if #RakBotVoteVotes == 0 then
		--	RakBotSay( "Nobody Voted." )
		--end
			local bestnum = 0
			for k, v in pairs( RakBotVoteVotes ) do
				if v > bestnum then
					bestnum = v
				end
			end
			local best = {}
			for k, v in pairs( RakBotVoteVotes ) do
				if v == bestnum then
					table.insert( best, k )
				end
			end
			
			RakBotSay( table.concat( best, ", " ) .. " had the most votes with " .. bestnum )
		--end
	end
	
	RakBotVoteType = 0
	RakBotVoteVotes = {}
	RakBotVoteVoted = {}
end

concommand.Add( "rak_bot_votestartyn", RakBotVoteStartYN )
concommand.Add( "rak_bot_votestartopen", RakBotVoteStartOpen )

concommand.Add( "rak_bot_votestop", RakBotVoteStop )

-- XRAY

concommand.Add( "rak_bot_xraay", function()
	if !RakBotXRay then
		surface.PlaySound("beep_synthtone01.wav") -- Alright, i'll show you where the sounds are.
		for _, v in pairs( ents.GetAll() ) do
			local r, g, b, a = v:GetColor()
			RakBotXRayColors[ v:EntIndex() ] = Color( r, g, b, a )
			RakBotXRayMats[ v:EntIndex() ] = v:GetMaterial()
			if v:IsNPC() then
				v:SetColor( 0, 0, 255, 255 )
			elseif v:IsWeapon() then
				v:SetColor( 150, 0, 255, 255 )
			elseif string.find( v:GetClass(), "ghost" ) then
				v:SetColor( 255, 255, 255, 100 )
			elseif v:GetClass() == "drug_lab" or v:GetClass() == "money_printer" then
				v:SetColor( 250, 50, 100, 50 )
			elseif v:GetClass() == "viewmodel" then
				v:SetColor( 50, 50, 250, 50 )
			else
				v:SetColor( 250, 250, 50, 100 )
			end
			v:SetMaterial( RakBotXRayMat:GetString() )
		end
		RakBotXRay = true
	else
		for _, v in pairs( ents.GetAll() ) do
			local col = RakBotXRayColors[ v:EntIndex() ] or Color( 255, 255, 255, 255 )
			v:SetMaterial( RakBotXRayMats[ v:EntIndex() ] )
			v:SetColor( col.r, col.g, col.b, col.a )
			RakBotXRay = false
		end
	end
	if RakBotXRay then
		surface.PlaySound("beep_error01.wav") -- When you turn it off, it will play this.
	end
end )

local function RakBotRenderScene()
	if RakBotXRay == false then return end
	for _, v in pairs( ents.FindByClass( "prop_physics" ) ) do
		if IsValid( v ) then
			v:SetColor( 255, 61, 190, 155 )-- <------ Change that color if you like too.
			v:SetMaterial( RakBotXRayMat:GetString() )
		end
		
	end
	for _, v in pairs( player.GetAll() ) do
		if IsValid( v ) then
			v:SetColor( 0, 255, 76, 255 )
			v:SetMaterial( RakBotXRayMat:GetString() )
		end
	end
end
hook.Add( "RenderScene", "RakBot", RakBotRenderScene )
-- You didn't put the other player color ? Like, admin and all ? I'll do it

-- RANDOM COMMANDS

concommand.Add( "rak_bot_rotate1", function()
	LocalPlayer():SetEyeAngles( LocalPlayer():EyeAngles() + Angle( 0, 180, 0 ) )
end )

concommand.Add( "rak_bot_rotate2", function()
	LocalPlayer():SetEyeAngles( LocalPlayer():EyeAngles() + Angle( -2 * LocalPlayer():EyeAngles().p, 180, 0 ) )
	RunConsoleCommand( "+jump" )
	
	local jump =     function() 
            RunConsoleCommand("-jump")
        end

	timer.Simple( 0.2, jump )
end )

concommand.Add( "rak_bot_rotate3", function()
	RunConsoleCommand( "gm_spawn", "models/props_junk/sawblade001a.mdl" ) 
	RunConsoleCommand( "+attack" )
	timer.Simple( 0.1, function()
		LocalPlayer():SetEyeAngles( LocalPlayer():EyeAngles() + Angle( -2 * LocalPlayer():EyeAngles().p, 180, 0 ) )
		RunConsoleCommand( "+jump" )
		local jump =     function() 
            RunConsoleCommand("-jump")
        end

	timer.Simple( 0.1, jump )
		timer.Simple( 0.1, function()
			RunConsoleCommand( "gmod_undo" )
			RunConsoleCommand( "-attack" )
		end )
	end )
end )

concommand.Add( "rak_bot_togglecommand", function( ply, com, args )
	if !args[1] then print( "No argument specified. Use attack instead of +attack." ) end
	if !RakBotToggleCommands[ args[1] ] then RakBotToggleCommands[ args[1] ] = false end
	if !RakBotToggleCommands[ args[1] ] then
		RunConsoleCommand( "+" .. args[1] )
	else
		RunConsoleCommand( "-" .. args[1] )
	end
	RakBotToggleCommands[ args[1] ] = !RakBotToggleCommands[ args[1] ]
end )

-- MENU

local RakBotMenuFrame
local function RakBotMenu()
	gui.EnableScreenClicker( true )
	
	if !RakBotMenuFrame then
		RakBotMenuFrame = vgui.Create( "DFrame" )
		RakBotMenuFrame:SetSize( 300, 400 )
		RakBotMenuFrame:Center()
		RakBotMenuFrame:ShowCloseButton( false )
		RakBotMenuFrame:SetDraggable( false )
		RakBotMenuFrame:SetTitle( "" )
		RakBotMenuFrame.Paint = function() end
		
		local Sheet = vgui.Create( "DPropertySheet", RakBotMenuFrame )
		Sheet:SetPos( 0, 0 )
		Sheet:SetSize( 300, 400 )
		
		-- RakBot Config
		
		local Tab = vgui.Create( "DPanelList" )
		Tab:SetSpacing( 5 )
		Tab:SetPadding( 5 )
		
		local Control = vgui.Create( "DCheckBoxLabel" )
		Control:SetText( "Enabled" )
		Control:SetConVar( "rak_bot_on" )
		Tab:AddItem( Control )
		
		local Control = vgui.Create( "DCheckBoxLabel" )
		Control:SetText( "Show Health" )
		Control:SetConVar( "rak_bot_health" )
		Tab:AddItem( Control )
		
		local Control = vgui.Create( "DCheckBoxLabel" )
		Control:SetText( "Show Weapon" )
		Control:SetConVar( "rak_bot_weapon" )
		Tab:AddItem( Control )
		
		local Control = vgui.Create( "DCheckBoxLabel" )
		Control:SetText( "Show Distance" )
		Control:SetConVar( "rak_bot_distance" )
		Tab:AddItem( Control )
		
		local Control = vgui.Create( "DCheckBoxLabel" )
		Control:SetText( "Show Money" )
		Control:SetConVar( "rak_bot_money" )
		Tab:AddItem( Control )
		
		local Control = vgui.Create( "DCheckBoxLabel" )
		Control:SetText( "Show Health" )
		Control:SetConVar( "rak_bot_health" )
		Tab:AddItem( Control )
		
		local Objects = vgui.Create( "DListView" )
		Objects:AddColumn( "Targets" )
		Objects:SetSize( 50, 100 )
		Objects:SetMultiSelect( false )
		function Objects:OnClickLine( line )
			line:SetSelected( true )
			for k, v in pairs( RakBotObjects ) do
				if v == line:GetValue( 1 ) then
					table.remove( RakBotObjects, k )
				end
			end
			RunConsoleCommand( "rak_bot_objects", table.concat( RakBotObjects, "|" ) )
			print( Objects:GetSelectedLine() )
			Objects:RemoveLine( Objects:GetSelectedLine() )
		end
		Tab:AddItem( Objects )
		
		for _, v in pairs( RakBotObjects ) do
			if v ~= "" then
				Objects:AddLine( v )
			end
		end
		
		local Control = vgui.Create( "DButton" )
		Control:SetText( "Add" )
		Control.DoClick = function()
			Derma_StringRequest( "RakBot", "Name of entity to add:", "", function( txt )
				table.insert( RakBotObjects, txt )
				RunConsoleCommand( "rak_bot_objects", table.concat( RakBotObjects, "|" ) )
				Objects:AddLine( txt )
			end )
		end
		Tab:AddItem( Control )
		
		local Control = vgui.Create( "DButton" )
		Control:SetText( "Add Looking at" )
		Control.DoClick = function()
			if LocalPlayer():GetEyeTrace().Hit and LocalPlayer():GetEyeTrace().Entity:IsValid() then
				table.insert( RakBotObjects, LocalPlayer():GetEyeTrace().Entity:GetClass() )
				RunConsoleCommand( "rak_bot_objects", table.concat( RakBotObjects, "|" ) )
				Objects:AddLine( LocalPlayer():GetEyeTrace().Entity:GetClass() )
			end
		end
		Tab:AddItem( Control )
		
		local Control = vgui.Create( "DButton" )
		Control:SetText( "Remove All" )
		Control.DoClick = function()
			Derma_Query( "Do you want to remove all Entites?", "RakBot",
				"Yes", function()
					for i, v in pairs( string.Explode( "|", RakBotObjects:GetString() ) ) do
						Objects:RemoveLine( i )
					end
					RakBotObjects = {}
					RunConsoleCommand( "rak_bot_objects", "" )
				end,
				"No", function() end )
		end
		Tab:AddItem( Control )
		
		local Control = vgui.Create( "DCheckBoxLabel" )
		Control:SetText( "Aimdots" )
		Control:SetConVar( "rak_bot_aimdot" )
		Tab:AddItem( Control )
		
		local Control = vgui.Create( "DCheckBoxLabel" )
		Control:SetText( "Aimdot Filtering" )
		Control:SetConVar( "rak_bot_aimdotfilter" )
		Tab:AddItem( Control )
		
		Sheet:AddSheet( "RakBot", Tab, "icon16/group.png", false, false, "RakBot Configuration" )
		
		-- Mirror Config
		
		local Tab = vgui.Create( "DPanelList" )
		Tab:SetSpacing( 5 )
		Tab:SetPadding( 5 )
		
		local Control = vgui.Create( "DCheckBoxLabel" )
		Control:SetText( "Mirror Enabled" )
		Control:SetConVar( "rak_bot_mirror" )
		Tab:AddItem( Control )
		
		local Control = vgui.Create( "DButton" )
		Control:SetText( "Enable Mirror Placement" )
		Control.DoClick = function()
			local PlaceFrame = vgui.Create( "DFrame" )
			RunConsoleCommand( "rak_bot_mirror", 0 )
			PlaceFrame:SetSize( RakBotMirrorw:GetInt(), RakBotMirrorh:GetInt() )
			PlaceFrame:SetPos( RakBotMirrorx:GetInt(), RakBotMirrory:GetInt() )
			PlaceFrame:ShowCloseButton( false )
			PlaceFrame:SetSizable( true )
			PlaceFrame:SetTitle( "Move Da Mirror" )
			
			local PlaceButton = vgui.Create( "DButton", PlaceFrame )
			PlaceButton:SetSize( 100, 40 )
			PlaceButton:SetPos( 5, 30 )
			PlaceButton:SetText( "Bitch Muddafuckin Stay Here" )
			PlaceButton.DoClick = function()
				local x, y = PlaceFrame:GetPos()
				local w, h = PlaceFrame:GetSize()
				RunConsoleCommand( "rak_bot_mirrorx", x )
				RunConsoleCommand( "rak_bot_mirrory", y )
				RunConsoleCommand( "rak_bot_mirrorw", w )
				RunConsoleCommand( "rak_bot_mirrorh", h )
				RunConsoleCommand( "rak_bot_mirror", 1 )
				PlaceFrame:Close()
			end
			PlaceButton.Think = function()
				local x, y = PlaceFrame:GetPos()
				local w, h = PlaceFrame:GetSize()
				PlaceButton:SetSize( w - 10, h - 32 )
				PlaceButton:SetPos( 5, 27 )
			end
		end
		Tab:AddItem( Control )
		
		local Control = vgui.Create( "DNumSlider" )
		Control:SetText( "Pitch" )
		Control:SetMin( -2 )
		Control:SetMax( 359 )
		Control:SetDecimals( 0 )
		Control:SetConVar( "rak_bot_mirrorpitch" )
		Tab:AddItem( Control )
		
		local Control = vgui.Create( "DNumSlider" )
		Control:SetText( "Yaw" )
		Control:SetMin( -2 )
		Control:SetMax( 359 )
		Control:SetDecimals( 0 )
		Control:SetConVar( "rak_bot_mirroryaw" )
		Tab:AddItem( Control )
		
		local Control = vgui.Create( "DNumSlider" )
		Control:SetText( "Roll" )
		Control:SetMin( -2 )
		Control:SetMax( 359 )
		Control:SetDecimals( 0 )
		Control:SetConVar( "rak_bot_mirrorroll" )
		Tab:AddItem( Control )
		
		local Control = vgui.Create( "DLabel" )
		Control:SetText( " " )
		Tab:AddItem( Control )
		
		local Control = vgui.Create( "DCheckBoxLabel" )
		Control:SetText( "Radar Enabled" )
		Control:SetConVar( "rak_bot_radar" )
		Tab:AddItem( Control )
		
		local Control = vgui.Create( "DButton" )
		Control:SetText( "Enable Radar Placement" )
		Control.DoClick = function()
			local PlaceFrame = vgui.Create( "DFrame" )
			RunConsoleCommand( "rak_bot_radar", 0 )
			PlaceFrame:SetSize( RakBotRadarw:GetInt(), RakBotRadarh:GetInt() )
			PlaceFrame:SetPos( RakBotRadarx:GetInt(), RakBotRadary:GetInt() )
			PlaceFrame:ShowCloseButton( false )
			PlaceFrame:SetSizable( true )
			PlaceFrame:SetTitle( "Radar Placement" )
			
			local PlaceButton = vgui.Create( "DButton", PlaceFrame )
			PlaceButton:SetSize( 100, 40 )
			PlaceButton:SetPos( 5, 30 )
			PlaceButton:SetText( "CONFIRM" )
			PlaceButton.DoClick = function()
				local x, y = PlaceFrame:GetPos()
				local w, h = PlaceFrame:GetSize()
				RunConsoleCommand( "rak_bot_radarx", x )
				RunConsoleCommand( "rak_bot_radary", y )
				RunConsoleCommand( "rak_bot_radarw", w )
				RunConsoleCommand( "rak_bot_radarh", h )
				RunConsoleCommand( "rak_bot_radar", 1 )
				PlaceFrame:Close()
			end
			PlaceButton.Think = function()
				local x, y = PlaceFrame:GetPos()
				local w, h = PlaceFrame:GetSize()
				PlaceButton:SetSize( w - 10, h - 32 )
				PlaceButton:SetPos( 5, 27 )
			end
		end
		Tab:AddItem( Control )
		
		local Control = vgui.Create( "DNumSlider" )
		Control:SetText( "FOV" )
		Control:SetMin( 0 )
		Control:SetMax( 3000 )
		Control:SetDecimals( 0 )
		Control:SetConVar( "rak_bot_radarfov" )
		Tab:AddItem( Control )
		
		local Control = vgui.Create( "DCheckBoxLabel" )
		Control:SetText( "Auto Adjust" )
		Control:SetConVar( "rak_bot_radarauto" )
		Tab:AddItem( Control )
		
		Sheet:AddSheet( "Mirror", Tab, "icon16/magnifier.png", false, false, "Mirror and Radar Configuration" )
		
		-- VOTE
		
		local Tab = vgui.Create( "DPanelList" )
		Tab:SetSpacing( 5 )
		Tab:SetPadding( 5 )
		
		local Control = vgui.Create( "DButton" )
		Control:SetText( "Start Yes / No Vote" )
		Control.DoClick = function()
			Derma_StringRequest( "RakBot - Yes / No Vote", "Text to dispaly as vote:", "", function( txt )
				RunConsoleCommand( "rak_bot_votestartyn", txt )
			end )
		end
		Tab:AddItem( Control )
		
		local Control = vgui.Create( "DButton" )
		Control:SetText( "Start Open Vote" )
		Control.DoClick = function()
			Derma_StringRequest( "RakBot - Open Vote", "Text to dispaly as vote:", "", function( txt )
				RunConsoleCommand( "rak_bot_votestartopen", txt )
			end )
		end
		Tab:AddItem( Control )
		
		local Control = vgui.Create( "DLabel" )
		Control:SetText( " " )
		Tab:AddItem( Control )
		
		local Control = vgui.Create( "DNumSlider" )
		Control:SetText( "Vote Time" )
		Control:SetMin( 0 )
		Control:SetMax( 300 )
		Control:SetDecimals( 0 )
		Control:SetConVar( "rak_bot_votetime" )
		Tab:AddItem( Control )
		
		local Control = vgui.Create( "DButton" )
		Control:SetText( "Stop Vote" )
		Control.DoClick = function()
			RunConsoleCommand( "rak_bot_votestop" )
		end
		Tab:AddItem( Control )
		
		Sheet:AddSheet( "Vote", Tab, "icon16/sound.png", false, false, "Voting System" )
		
		-- HOOKS
		
		local Tab = vgui.Create( "DPanelList" )
		Tab:SetSpacing( 5 )
		Tab:SetPadding( 5 )
		Tab:EnableVerticalScrollbar( true )
		
		local HooksTable = {}
		
		local function CreateHooks()
		
			local Var = hook.GetTable()
			table.sort( Var, function( a, b ) return a < b end )
			
			for HookName, HookFunctions in pairs( Var ) do
				HooksTable[ HookName ] = vgui.Create( "DCollapsibleCategory" )
				HooksTable[ HookName ]:SetExpanded( 0 )
				HooksTable[ HookName ]:SetLabel( HookName )
				
				HooksTable[ HookName ].Contents = vgui.Create( "DPanelList" )
				HooksTable[ HookName ].Contents:SetAutoSize( true )
				HooksTable[ HookName ].Contents:SetSpacing( 5 )
				HooksTable[ HookName ].Contents:SetPadding( 5 )
				HooksTable[ HookName ].Contents:EnableHorizontal( false )
				HooksTable[ HookName ].Contents:EnableVerticalScrollbar( true )
				
				HooksTable[ HookName ]:SetContents( HooksTable[ HookName ].Contents )
				
				Tab:AddItem( HooksTable[ HookName ] )
				
				local Var2 = HookFunctions
				table.sort( Var2, function( a, b ) return a < b end )
				
				/*
				for HookID, HookFunction in pairs( Var2 ) do
					HooksTable[ HookName ].Contents[ HookID ] = vgui.Create( "DButton" )
					HooksTable[ HookName ].Contents[ HookID ]:SetText( HookID )
					HooksTable[ HookName ].Contents[ HookID ].DoClick = function()
						local Menu = DermaMenu()
						Menu:AddOption( "Call Hook", function() hook.Call( HookName ) end )
						Menu:AddOption( "Remove Hook", function() hook.Remove( HookName, HookID ) HooksTable[ HookName ].Contents[ HookID ]:Remove() end )
						Menu:Open()
					end
					HooksTable[ HookName ].Contents:AddItem( HooksTable[ HookName ].Contents[ HookID ] )
				end
				*/
			end
		end
		
		local Control = vgui.Create( "DButton" )
		Control:SetText( "Refresh" )
		Control.DoClick = function()
			for k, v in pairs( HooksTable ) do
				v:Remove()
			end
			CreateHooks()
		end
		Tab:AddItem( Control )
		
		CreateHooks()
		
		Sheet:AddSheet( "Hooks", Tab, "icon16/anchor.png", false, false, "Manage active Lua Hooks" )
		
		-- OTHER
		
		local Tab = vgui.Create( "DPanelList" )
		Tab:SetSpacing( 5 )
		Tab:SetPadding( 5 )
		Tab:EnableVerticalScrollbar( true )
		
		local Control = vgui.Create( "DButton" )
		Control:SetText( "Light" )
		Control.DoClick = function()
			RunConsoleCommand( "rak_bot_light" )
		end
		Tab:AddItem( Control )
		
		local Control = vgui.Create( "DButton" )
		Control:SetText( "Aura Light" )
		Control.DoClick = function()
			RunConsoleCommand( "rak_bot_aura" )
		end
		Tab:AddItem( Control )
		
		local Control = vgui.Create( "DLabel" )
		Control:SetText( " " )
		Tab:AddItem( Control )
		
		local Control = vgui.Create( "DButton" )
		Control:SetText( "Add Detector" )
		Control.DoClick = function()
			RunConsoleCommand( "rak_bot_detectadd" )
		end
		Tab:AddItem( Control )
		
		local Control = vgui.Create( "DButton" )
		Control:SetText( "Remove Detector" )
		Control.DoClick = function()
			RunConsoleCommand( "rak_bot_detectremove" )
		end
		Tab:AddItem( Control )
		
		local Control = vgui.Create( "DNumSlider" )
		Control:SetText( "Detector Threshold" )
		Control:SetMin( 0 )
		Control:SetMax( 2000 )
		Control:SetDecimals( 0 )
		Control:SetConVar( "rak_bot_detectthresh" )
		Tab:AddItem( Control )
		
		local Control = vgui.Create( "DCheckBoxLabel" )
		Control:SetText( "Show Detectors" )
		Control:SetConVar( "rak_bot_detectshow" )
		Tab:AddItem( Control )
		
		local Control = vgui.Create( "DCheckBoxLabel" )
		Control:SetText( "Show Thresholds" )
		Control:SetConVar( "rak_bot_detectshowrad" )
		Tab:AddItem( Control )
		
		local Control = vgui.Create( "DCheckBoxLabel" )
		Control:SetText( "Trace Detection" )
		Control:SetConVar( "rak_bot_detecttrace" )
		Tab:AddItem( Control )
		
		local Control = vgui.Create( "DLabel" )
		Control:SetText( " " )
		Tab:AddItem( Control )
		
		local Control = vgui.Create( "DCheckBoxLabel" )
		Control:SetText( "Reverse Chat" )
		Control:SetConVar( "rak_bot_chatreverse" )
		Tab:AddItem( Control )
		
		local Control = vgui.Create( "DCheckBoxLabel" )
		Control:SetText( "Cambridge Chat" )
		Control:SetConVar( "rak_bot_chatcambridge" )
		Tab:AddItem( Control )
		
		local Control = vgui.Create( "DLabel" )
		Control:SetText( " " )
		Tab:AddItem( Control )
		
		local Control = vgui.Create( "DButton" )
		Control:SetText( "Reload Scripts" )
		Control.DoClick = function()
			if RakBotMenuFrame then
				RakBotMenuFrame:Close()
				gui.EnableScreenClicker( false )
			end
			include( "autorun/client/RakBot.lua" )
		end
		Tab:AddItem( Control )
		
		Sheet:AddSheet( "Misc", Tab, "icon16/plugin.png", false, false, "Other Settings" )
	else
		RakBotMenuFrame:SetVisible( true )
	end
end

local function RakBotMenuOff()
	if RakBotMenuFrame then
		RakBotMenuFrame:SetVisible( false )
		gui.EnableScreenClicker( false )
	end
end

concommand.Add( "+rak_bot_menu", RakBotMenu )
concommand.Add( "-rak_bot_menu", RakBotMenuOff )

concommand.Add( "rak_bot_reload", function() include( "scripts/RakBot.lua" ) end )