--[[
	disabled/menu_plugins/custom_menu/ghack.lua
	G-Force Connections | (STEAM_0:1:19084184)
	===DStream===
]]

-- Welcome to GHack v1
-- Coded by G-Force Connections

if SERVER then return end

require( "ghack" )
package.loaded.ghack = nil

concommand.Add( "runghacktxt", function() GH.RunString( file.Read( "ghack.txt" ) ) end )
concommand.Add( "runstringmenu", function( ply, cmd, args ) RunString( unpack( args ) ) end )
concommand.Add( "runstring", function( ply, cmd, args ) GH.RunString( unpack( args ) ) end )

GH.Vars = {}
GH.Hooks = {}
GH.Msg( "Loading..." )

include( "sourcenet3/sn3_base_gameevents.lua" )
package.loaded.sourcenet3 = nil

GH.Vars[ "Settings" ] = {}

require( "usermessage" )
require( "datastream" )

/*----------------------------------------------
   Commands / Convars and Anti-Cheat protector
----------------------------------------------*/

local OldFuncs = {}
OldFuncs[ "GetConVarNumber" ] = _G.GetConVarNumber
OldFuncs[ "GetConVarString" ] = _G.GetConVarString
OldFuncs[ "_R.ConVar.GetInt" ] = _R.ConVar.GetInt
OldFuncs[ "_R.ConVar.GetBool" ] = _R.ConVar.GetBool

local SpoofedCommands = {}
SpoofedCommands[ "sv_cheats" ] = 0
SpoofedCommands[ "sv_scriptenforcer" ] = 1
SpoofedCommands[ "host_timescale" ] = 1
SpoofedCommands[ "sv_allow_voice_from_file" ] = 0
SpoofedCommands[ "r_drawothermodels" ] = 0
SpoofedCommands[ "mat_fullbright" ] = 0

function GetConVarNumber( cvar )
	if table.HasValue( SpoofedCommands, cvar ) then
		GH.MsgWarn( Format( "GetConVarNumber tried to retrieve %s", cvar ) )
		return SpoofedCommands[ cvar ]
	end

	return OldFuncs[ "GetConVarNumber" ]( cvar )
end

function GetConVarString( cvar )
	if table.HasValue( SpoofedCommands, cvar ) then
		GH.MsgWarn( Format( "GetConVarString tried to retrieve %s", cvar ) )
		return tostring( SpoofedCommands[ cvar ] )
	end

	return OldFuncs[ "GetConVarString" ]( cvar )
end

function _R.ConVar.GetInt( cvar )
	if table.HasValue( SpoofedCommands, cvar ) then
		GH.MsgWarn( Format( "_R.ConVar.GetInt tried to retrieve %s", cvar ) )
		return SpoofedCommands[ cvar ]
	end

	return OldFuncs[ "_R.ConVar.GetInt" ]( cvar )
end

function _R.ConVar.GetBool( cvar )
	if table.HasValue( SpoofedCommands, cvar ) then
		GH.MsgWarn( Format( "_R.ConVar.GetBool tried to retrieve %s", cvar ) )
		return tobool( SpoofedCommands[ cvar ] )
	end

	return OldFuncs[ "_R.ConVar.GetBool" ]( cvar )
end

function debug.getinfo()
	GH.Msg( "debug.getinfo() attempt blocked." )

	return {}
end

-- Protect ourselves from Sourcenet3 :D
FilterOutgoingMessage( clc_RespondCvarValue, function( netchan, read, write )
	write:WriteUBitLong( clc_RespondCvarValue, NET_MESSAGE_BITS )
	
	local cookie = read:ReadSBitLong( 32 )
	write:WriteSBitLong( cookie, 32 )
	
	local status = read:ReadSBitLong( 4 )
	write:WriteSBitLong( status, 4 )
	
	local cvarname = read:ReadString()
	write:WriteString( cvarname )

	local cvarvalue = read:ReadString()

	if SpoofedCommands[ cvarname ] ~= nil then
		write:WriteString( tostring( SpoofedCommands[ cvarname ] ) )
		GH.MsgWarn( Format( "Sourcenet3 attempted to get the value of %s", cvarname ) )
	else
		write:WriteString( read:ReadString() )
	end
end )

OldFuncs[ "file.Exists" ] = file.Exists
OldFuncs[ "file.Read" ] = file.Read
OldFuncs[ "file.Size" ] = file.Size
OldFuncs[ "file.Time" ] = file.Time
OldFuncs[ "file.Find" ] = file.Find
OldFuncs[ "file.FindInLua" ] = file.FindInLua

local RestrictedFiles = {}
table.insert( RestrictedFiles, "ghack.lua" )
table.insert( RestrictedFiles, "gmcl_ghack.dll" )
table.insert( RestrictedFiles, "gmcl_extras.dll" )
table.insert( RestrictedFiles, "gm_sourcenet3.dll" )

local RestrictedNames = {}
table.insert( RestrictedNames, "hack" )
table.insert( RestrictedNames, "extras" )
table.insert( RestrictedNames, "sourcenet" )
table.insert( RestrictedNames, "anticheat" )
table.insert( RestrictedNames, "cheat" )
table.insert( RestrictedNames, "anti" )
table.insert( RestrictedNames, "_ac_fuck" )
table.insert( RestrictedNames, "shindig" )

function file.Exists( filename, basefolder )
	if not filename then return end

	for k, v in pairs( RestrictedNames ) do
		if string.find( string.lower( filename ), v ) then
			GH.MsgWarn( Format( "file.Exists attempted to find %s", filename ) )
			return
		end
	end

	return OldFuncs[ "file.Exists" ]( filename, basefolder )
end
 
function file.Read( filename, basefolder )
	if not filename then return end

	for k, v in pairs( RestrictedNames ) do
		if string.find( string.lower( filename ), v ) then
			GH.MsgWarn( Format( "file.Read attempted to find %s", filename ) )
			--return
		end
	end

	return OldFuncs[ "file.Read" ]( filename, basefolder )
end
 
function file.Size( filename )
	if not filename then return end

	for k, v in pairs( RestrictedNames ) do
		if string.find( string.lower( filename ), v ) then
			GH.MsgWarn( Format( "file.Size attempted to find %s", filename ) )
			return -1
		end
	end

	return OldFuncs[ "file.Size" ]( filename )
end
 
function file.Time( filename )
	if not filename then return end

	GH.Msg( "file.Time searched for file " .. filename )

	for k, v in pairs( RestrictedNames ) do
		if string.find( string.lower( filename ), v ) then
			GH.MsgWarn( Format( "file.Time attempted to find %s", filename ) )
			return 0
		end
	end

	return OldFuncs[ "file.Time" ]( filename )
end
 
function file.Find( filename )
	local tab = OldFuncs[ "file.Find" ]( filename )

	for k, v in pairs( tab ) do
		for _k, v in pairs( RestrictedNames ) do
			if string.find( string.lower( filename ), v ) then
				GH.MsgWarn( Format( "file.Find attempted to find %s", filename ) )
				table.remove( tab, k )
			end
		end
	end

	return tab
end
 
function file.FindInLua( filename )
	local tab = OldFuncs[ "file.FindInLua" ]( filename )

	for k, v in pairs( tab ) do
		for _k, v in pairs( RestrictedNames ) do
			if string.find( string.lower( filename ), v ) then
				GH.MsgWarn( Format( "file.FindInLua attempted to find %s", filename ) )
				table.remove( tab, k )
			end
		end
	end

	return tab
end

OldFuncs[ "datastream.StreamToServer" ] = datastream.StreamToServer

function datastream.StreamToServer( name, ... )
	if table.HasValue( RestrictedNames, name ) then
		GH.MsgWarn( Format( "datastream.StreamToServer tried to send messages under the alias %s", name ) )
		return
	end

	return OldFuncs[ "datastream.StreamToServer" ]( name, ... )
end

/*----------------------------------------------
		   RunConsoleCommand
----------------------------------------------*/

OldFuncs[ "RunConsoleCommand" ] = _G.RunConsoleCommand
OldFuncs[ "usermessage.IncomingMessage" ] = usermessage.IncomingMessage

local BlockedCommands = { "_____b__c", "___m", "sc", "+left", "+right", "+jump", "-left", "-right", "-jump", "kickme", "gw_iamacheater", "imafaggot", "birdcage_browse" }

function usermessage.IncomingMessage( name, um, ... )
	if name == "ac_cmd" then
		local command = um:ReadString()
		table.insert( BlockedCommands, command ) -- "Unique" command, block it.
		GH.MsgWarn( Format( "Blocked command: %s", command ) )

		return
	end

	return OldFuncs[ "usermessage.IncomingMessage" ]( name, um, ... )
end


function RunConsoleCommand( cmd, ... )
	if SpoofedCommands[ cmd ] ~= nil or table.HasValue( BlockedCommands ) then
		GH.Msg( "RunConsoleCommand: " .. cmd .. " was blocked." )

		return
	end

	return OldFuncs[ "RunConsoleCommand" ]( cmd, ... )
end

/*----------------------------------------------
		   Speed Hacks
----------------------------------------------*/

GH.Vars[ "Settings" ][ "SpeedHack" ] = false
GH.Vars[ "Settings" ][ "SpeedHackSpeed" ] = 5

function GH.SpeedHack()
	if GH.Vars[ "Settings" ][ "SpeedHack" ] then
		GH.ForceCVar( CreateConVar( "host_timescale", "" ), tostring( GH.Vars[ "Settings" ][ "SpeedHackSpeed" ] ) )
	else
		GH.ForceCVar( CreateConVar( "host_timescale", "" ), "1" )
	end
end

concommand.Add( "+gh_speed", function() GH.Vars[ "Settings" ][ "SpeedHack" ] = true GH.SpeedHack() end )
concommand.Add( "-gh_speed", function() GH.Vars[ "Settings" ][ "SpeedHack" ] = false GH.SpeedHack() end )

concommand.Add( "gh_speed", function( ply, cmd, args ) GH.Vars[ "Settings" ][ "SpeedHackSpeed" ] = args[ 1 ] end )

/*----------------------------------------------
	   Name Hack ( Thank you Sourcenet3 )
----------------------------------------------*/

GH.Vars[ "Settings" ][ "NameSpam" ] = false

function GH.SpamName()
	if GH.Vars[ "Settings" ][ "NameSpam" ] then
		hook.Add( "Think", "GH.SpamName", GH.SpamName )
	else
		hook.Remove( "Think", "GH.SpamName" )
		return
	end

	local newname = math.random( 0, 100000000 )

	local netchan = CNetChan()

	if not netchan then return end

	local buffer = netchan:GetReliableBuffer()
	
	if not buffer then return end
	
	buffer:WriteUBitLong( net_SetConVar, NET_MESSAGE_BITS )
	buffer:WriteByte( 1 )
	buffer:WriteString( "name" )
	buffer:WriteString( tostring( newname ) )
end
concommand.Add( "gh_namespam", function() GH.Vars[ "Settings" ][ "NameSpam" ] = !GH.Vars[ "Settings" ][ "NameSpam" ] GH.SpamName() end )

concommand.Add( "gh_setname", function( ply, cmd, args )
	if not args[ 1 ] then
		GH.Msg( "Syntax: setname <name>" )
		return
	end
	
	local netchan = CNetChan()
	
	if not netchan then return end

	local buffer = netchan:GetReliableBuffer()
	
	if not buffer then return end
	
	buffer:WriteUBitLong( net_SetConVar, NET_MESSAGE_BITS )
	buffer:WriteByte( 1 )
	buffer:WriteString( "name" )
	buffer:WriteString( args[ 1 ] )

	GH.Msg( "Your name has been set to: " .. args[ 1 ] )
end )

/*----------------------------------------------
		   Simple SV Bypasser
----------------------------------------------*/

hook.Add( "Think", "GH.SVCheats", function() GH.ForceCVar( GetConVar( "sv_cheats" ), "1" ) end )

/*----------------------------------------------
	 IP Grabber ( Thanks again to Sourcenet3 )
----------------------------------------------*/

GH.Vars[ "IPs" ] = {}

hook.Add( "ProcessGameEvent", "GH.IPGrabber", function( netchan, event )
	if event:GetName() ~= "player_connect" then return end

	local name = event:GetString( "name" )
	local steamid = event:GetString( "networkid" )
	local ipaddress = event:GetString( "address" )

	if ipaddress == "none" then
		GH.Msg( name .. " is a bot and has no IP!" )
		return event
	end

	GH.Vars[ "IPs" ][ steamid ] = {} -- steamid
	GH.Vars[ "IPs" ][ steamid ][ "Name" ] = name
	GH.Vars[ "IPs" ][ steamid ][ "IPAddress" ] = ipaddress

	GH.Msg( name .. " joined with IP " .. ipaddress )

	return event
end )

/*----------------------------------------------
Custom leave messages ( Thanks again to Sourcenet3 )
----------------------------------------------*/

local LeaveMessages = {}

table.insert( LeaveMessages, "I'm leaving you." )
table.insert( LeaveMessages, "Night night time." )
table.insert( LeaveMessages, "Because I love mudkipz." )
table.insert( LeaveMessages, "Banned for being too awesome." )
table.insert( LeaveMessages, "Ragequit." )

require( "disconnect" )

hook.Add( "DisconnectMsg", "GH.LeaveMessage", function( msg )
	local reason = LeaveMessages[ math.random( #LeaveMessages ) ]

	GH.Msg( Format( "Your disconnect reason was: %s", reason ) )
	return reason
end )

/*----------------------------------------------
			Prop Spawn Effect Delete
----------------------------------------------*/

hook.Add( "PostGamemodeLoaded", "GH.OverridePropEffect", function()
	_G.DoPropSpawnedEffect = function( ent ) end
	effects.Register( { Init = function() end, Think = function() end, Render = function() end }, "propspawn" )
end )

/*----------------------------------------------
			Annoying server spammer :3
----------------------------------------------*/

GH.Vars[ "Settings" ][ "SpamDataStream" ] = false

function GH.SpamDataStream()
	datastream.StreamToServer( "\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\n", {} )
	GM.Msg( "Spam message sent to the server." )
end

function GH.SpamServer()
	if GH.Vars[ "Settings" ][ "SpamDataStream" ] then
		timer.Create( "GH.SpamDataStream", 1, 0, GH.SpamDataStream )
	else
		timer.Destroy( "GH.SpamDataStream" )
	end
end

concommand.Add( "+gh_spamds", function() GH.Vars[ "Settings" ][ "SpamDataStream" ] = true GH.SpamServer() end )
concommand.Add( "-gh_spamds", function() GH.Vars[ "Settings" ][ "SpamDataStream" ] = false GH.SpamServer() end )