--------------Localized Variables--------------
require("cvar2")
require("deco")
include ( "includes/compat.lua" )
include ( "includes/util.lua" )
include ( "includes/util/sql.lua" )
require ( "concommand" )
require ( "saverestore" )
require ( "gamemode" )
require ( "weapons" )
require ( "hook" )
require ( "timer" )
require ( "schedule" )
require ( "scripted_ents" )
require ( "player_manager" )
require ( "numpad" )
require ( "team" )
require ( "undo" )
require ( "cleanup" )
require ( "datastream" )
require ( "spawnmenu" )
require ( "controlpanel" )
require ( "presets" )
require ( "cookie" )
include( "includes/util/model_database.lua" )
include( "includes/util/vgui_showlayout.lua" )
include( "includes/util/tooltips.lua" )	   
include( "includes/util/client.lua" )
include("includes/extensions/table.lua")
require ( "duplicator" )
require ( "constraint" )
require ( "construct" )	   
require ( "filex" )
require ( "vehicles" )
require ( "usermessage" )
require ( "list" )
require ( "cvars" )
require ( "http" )
require ( "draw" )
require ( "markup" )
require ( "effects" )
require ( "killicon" )
-----------------------------------------------
local math = math
local CreateClientConVar = CreateClientConVar
local Entity = Entity
local Angle = Angle
local LocalPlayer = LocalPlayer
local GetConVarNumber = GetConVarNumber
local ValidEntity = ValidEntity
local Player = Player
local Vector = Vector
local CurTime = CurTime
local RunConsoleCommand = RunConsoleCommand
local print = print
local Msg = Msg
local EyeAngles = EyeAngles
local EyePos = EyePos
local type = type
local tonumber = tonumber
local ipairs = ipairs
local pairs = pairs
local ScrW = ScrW
local ScrH = ScrH
local Error = function() end
local error = function() end
local ErrorNoHalt = function() end


local math = math
local spawnmenu = spawnmenu
local string = string
local surface = surface
local table = table
local timer = timer
local ents = ents
local file = file
local hook = hook
local team = team
local timer = timer
local cam = cam
local gui = gui
local render = render
local util = util
local vgui = vgui
local concommand = concommand
local cvars = cvars
local debug = debug

local IsPlayer = IsPlayer
local IsNPC = IsNPC
local ConVar = ConVar
local GetAimVector = GetAimVector
local CUserCmd = CUserCmd
local SetViewAngles = SetViewAngles
-----------------------------------------------
local Tags = 0
local AimToggle = 0
local StoreAngles = Angle(0,0,0)
local StoreView = 1
local WallToggle = 0
local WallHackStyle = 1
local XHairAlpha = 255
local prtcl = 1
local RPhax = 0
local TBVal = "No"
local Friends = {}
-----------------------------------------------
cvar2.SetValue("sv_cheats",1)
--[[---------------Name Tags---------------------]]--
local NTVar = CreateClientConVar("Hax_NameTags", 0, false, false)
local NTVar2 = CreateClientConVar("Hax_SaveView", 1, false, false)
local NTVar3 = CreateClientConVar("Hax_ShowCrosshair", 1, false, false)
local NTVar4 = CreateClientConVar("Hax_ShowCrosshair2", 1, false, false)
local NTVar5 = CreateClientConVar("Hax_WallHackStyle", 1, false, false)
local NTVar6 = CreateClientConVar("Hax_SmoothAim", 0, false, false)
local NTVar7 = CreateClientConVar("Hax_SmoothAimSpeed", 5, false, false)
local NTVar8 = CreateClientConVar("Hax_DrawParticles", 1, false, false)
local NTVar9 = CreateClientConVar("Hax_TriggerBot", 0, false, false)
local NTVar9b = CreateClientConVar("Hax_TriggerBot2", 0, false, false)
local NTVar10 = CreateClientConVar("Hax_IgnoreSteamFriends", 0, false, false)
local NTVar11 = CreateClientConVar("Hax_MaxWallHackDist", 360, false, false)
local NTVar12 = CreateClientConVar("Hax_IgnoreTeam", 0, false, false)
local NTVar13 = CreateClientConVar("Hax_AimFov", 0, false, false)
--------------FOV Function--------------
function FovCheck(ent)
if (GetConVarNumber("Hax_AimFov") == 0) or (GetConVarNumber("Hax_AimFov") == 180) then return true end
if math.NormalizeAngle((ent:GetPos()-LocalPlayer():GetPos()):Angle().y-LocalPlayer():EyeAngles().y) > GetConVarNumber("Hax_AimFov") then return false end
if math.NormalizeAngle((ent:GetPos()-LocalPlayer():GetPos()):Angle().y-LocalPlayer():EyeAngles().y) < -GetConVarNumber("Hax_AimFov") then return false end
if math.NormalizeAngle((ent:GetPos()-LocalPlayer():GetPos()):Angle().p-LocalPlayer():EyeAngles().p) > GetConVarNumber("Hax_AimFov") then return false end
if math.NormalizeAngle((ent:GetPos()-LocalPlayer():GetPos()):Angle().p-LocalPlayer():EyeAngles().p) < -GetConVarNumber("Hax_AimFov") then return false end
return true
end

-----------------------------------------------
function DrawNameTags()
if GetConVarNumber("Hax_NameTags") == 1 then
for k,v in pairs(player.GetAll()) do
if v != LocalPlayer() then
local pos = v:GetShootPos():ToScreen()
local w = surface.GetTextSize( v:Name() ) /2
if team.GetColor(v:Team()).r == 255 and team.GetColor(v:Team()).g == 255 and team.GetColor(v:Team()).b == 100 then
draw.WordBox( 2,pos.x-w, pos.y-40, v:Name(), "Default", Color(50,50,50,200), Color(255,255,255,255) )
else
draw.WordBox( 2,pos.x-w, pos.y-40, v:Name(), "Default", Color(team.GetColor(v:Team()).r,team.GetColor(v:Team()).g,team.GetColor(v:Team()).b,100), Color(255,255,255,255) )
end
local w2 = surface.GetTextSize( "Health: "..v:Health() ) / 2
draw.WordBox( 2,pos.x-w2, pos.y-23, "Health: "..v:Health(), "Default", Color(50,50,50,200), Color(255,255,255,255) )
if v:IsAdmin() and not v:IsSuperAdmin() then
local w3 = surface.GetTextSize( "Admin" ) / 2
draw.WordBox( 2,pos.x-w3, pos.y-57, "Admin", "Default", Color(250,50,50,200), Color(255,255,255,255) )
end
if v:IsSuperAdmin() then
local w3 = surface.GetTextSize( "Super Admin" ) / 2
draw.WordBox( 2,pos.x-w3, pos.y-57, "Super Admin", "Default", Color(250,50,50,200), Color(255,255,255,255) )
end
end
end
end
end
hook.Add("HUDPaint","NameTags",DrawNameTags)
--[[-------------------------------------------]]--
-------------------Visibility--------------------
function IsVisible( ent )
local tracedata = {}
tracedata.start = LocalPlayer():GetShootPos()
tracedata.endpos = ent:GetBonePosition( ent:LookupBone("ValveBiped.Bip01_Head1") ) 
tracedata.filter = {LocalPlayer(),ent}
tracedata.mask = MASK_SHOT
local trace = util.TraceLine(tracedata)
if trace.Fraction >=0.99 then return true else return false end
end
-------------------------------------------------
local Flagsadd
local Flags
function IsValidTarget( e )
if GetConVarNumber("Hax_IgnoreTeam") == 1 then
if e != LocalPlayer() then
Flagsadd = e:Team() != LocalPlayer():Team()
end
else
Flagsadd = NULL
end
if GetConVarNumber("Hax_IgnoreSteamFriends") == 1 then
Flags = e:Alive() && e:Health() > 1 and IsVisible(e) and not table.HasValue(Friends,e) and e:GetFriendStatus() != "friend" and FovCheck(e) and Flagsadd
else
Flags = e:Alive() && e:Health() > 1 and IsVisible(e) and not table.HasValue(Friends,e) and FovCheck(e) and Flagsadd
end
if Flags then return true end
return false
end
-------------------------------------------------
-------------Find Closest Player/NPC-------------
local function ClosestTarget()
local pos = LocalPlayer():GetPos()
local ang = LocalPlayer():GetAimVector()
local tmp = {}
local d
local en = {NULL,0}
for k, e in ipairs( player.GetAll() ) do
if ValidEntity(e) then
if e != LocalPlayer() then
local ntt = (e:GetPos()-pos):Normalize()
ntt = ntt - ang
ntt = ntt:Length()
ntt = math.abs(ntt)
if (ntt < en[2] and IsValidTarget(e)) or (en[1] == NULL and IsValidTarget(e)) then
en = {e,ntt}
end
end
end
end
if ValidEntity(en[1]) then
return en[1]
else
return LocalPlayer()
end
end
-------------------------------------------------
concommand.Add("-Hax_aimbot",function()
RunConsoleCommand("-attack")
RunConsoleCommand("-hax_rapidfire")
AimToggle = 0
end)
concommand.Add("+Hax_aimbot",function()
AimToggle = 1
end)
------------------Bug Fix------------------------
-------------------------------------------------
-------------------------------------------------
local CustomCones = {}
CustomCones["#HL2_SMG1"]        = Vector( -0.04362, -0.04362, -0.04362 )
CustomCones["#HL2_Pistol"]      = Vector( -0.0100, -0.0100, -0.0100 )
CustomCones["#HL2_Pulse_Rifle"] = Vector( -0.02618, -0.02618, -0.02618 )
function PredictSpread( cmd, aimAngle )
        local cmd2, seed = hl2_ucmd_getprediciton( cmd )
        local currentseed = 0, 0, 0
        if( cmd2 != 0 ) then currentseed = seed end
        local wep = LocalPlayer():GetActiveWeapon()
        local vecCone, valCone = Vector( 0, 0, 0 )
        if( ValidEntity( wep ) ) then
                if( wep.Initialize ) then
                        valCone = wep.Primary && wep.Primary.Cone || 0
                        if( tonumber( valCone ) ) then
                                vecCone = Vector( -valCone, -valCone, -valCone )
                        elseif( type( valCone ) == "Vector" ) then
                                vecCone = -1 * valCone
                        end
                else
                        local pn = wep:GetPrintName()
                        if( CustomCones[pn] ) then vecCone = CustomCones[pn] end
                end
        end
        return hl2_shotmanip( currentseed || 0, ( aimAngle || LocalPlayer():GetAimVector():Angle() ):Forward(), vecCone ):Angle()
end
-------------------------------------------------
---------------------AimBot----------------------
function Target()
return ClosestTarget()
end
function HaxBot(UCMD)
local HeadBone, TargAng
HeadBone = Target():GetAttachment(Target():LookupAttachment("eyes")).Pos
TargAng = ( HeadBone - LocalPlayer():GetShootPos() ):Angle()
TargAng = PredictSpread(UCMD,TargAng)
if AimToggle == 1 and Target() != LocalPlayer() then
UCMD:SetViewAngles( Angle( TargAng.p, TargAng.y, 0 ) )
RunConsoleCommand("+attack")
elseif AimToggle == 1 and Target() == LocalPlayer() then
RunConsoleCommand("-attack")
end
end
hook.Add("CreateMove","HaxBot",HaxBot)
-------------------------------------------------
-------------------------------------------------
--Ok now that we're done with the nametags and aimbot--
--Lets do the menu then the wallhack!--
--------------------Wall Hack--------------------
function WallHack()
if GetConVarNumber("Hax_WallHackStyle") == 1 then
for k,v in pairs(ents.GetAll()) do
if v:IsPlayer() or v:IsNPC() then
v:SetMaterial("")
cam.Start3D(EyePos(),EyeAngles())
if v:GetPos():Distance(LocalPlayer():GetPos())<GetConVarNumber("Hax_MaxWallHackDist")*1000 then
v:DrawModel()
end
cam.End3D()
end
end
end
end
concommand.Add("Hax_WallHack",function()
if RPhax != 1 then
RPhax = 1
elseif RPhax == 1 then
RPhax = 0
end
if WallToggle != 1 then
for k,v in pairs(player.GetAll()) do
v.PlyMat = v:GetMaterial()
end
WallToggle = 1
if GetConVarNumber("Hax_WallHackStyle") == 2 then
local MaterialBlurX = Material( "pp/blurx" );  
local MaterialBlurY = Material( "pp/blury" );  
local TexTine = render.GetBloomTex0()
local MaterialWhite = CreateMaterial( "WhiteMaterial", "VertexLitGeneric", {  
    ["$basetexture"] = "color/white",  
    ["$vertexalpha"] = "1",  
    ["$model"] = "1",  
} );  
local MaterialComposite = CreateMaterial( "CompositeMaterial", "UnlitGeneric", {  
    ["$basetexture"] = "_rt_FullFrameFB",  
    ["$additive"] = "1",  
} );  
local function RenderToStencil( entity )  
    render.SetStencilEnable( true );  
    render.SetStencilFailOperation( STENCILOPERATION_KEEP );  
    render.SetStencilZFailOperation( STENCILOPERATION_KEEP );  
    render.SetStencilPassOperation( STENCILOPERATION_REPLACE );  
    render.SetStencilCompareFunction( STENCILCOMPARISONFUNCTION_ALWAYS );  
    render.SetStencilWriteMask( 1 );  
    render.SetStencilReferenceValue( 1 );  
    cam.IgnoreZ( true );  
        render.SetBlend( 0 );  
            SetMaterialOverride( MaterialWhite );  
                entity:DrawModel();  
            SetMaterialOverride();  
        render.SetBlend( 1 );  
    cam.IgnoreZ( false );  
    render.SetStencilEnable( false );  
end
local function RenderToGlowTexture( entity )  
    local w, h = ScrW(), ScrH();  
    local oldRT = render.GetRenderTarget();  
    render.SetRenderTarget( TexTine );  
        render.SetViewPort( 0, 0, w, h );  
        cam.IgnoreZ( true );    
            render.SuppressEngineLighting( true );  
            render.SetColorModulation( 1, 0.2, 0.2 );
                SetMaterialOverride( MaterialWhite );  
                    entity:DrawModel();  
                SetMaterialOverride();  
            render.SetColorModulation( 1, 1, 1 );  
            render.SuppressEngineLighting( false );  
        cam.IgnoreZ( false );  
        render.SetViewPort( 0, 0, w, h );  
    render.SetRenderTarget( oldRT );  
 end
local function RenderScene( Origin, Angles )  
    render.ClearRenderTarget( TexTine, Color( 0, 0, 0, 255 ) );  
end  
hook.Add( "RenderScene", "ResetGlow", RenderScene );  
local function RenderScreenspaceEffects( )  
    MaterialBlurX:SetMaterialTexture( "$basetexture", TexTine );  
    MaterialBlurY:SetMaterialTexture( "$basetexture", TexTine );  
    MaterialBlurX:SetMaterialFloat( "$size", 2 );  
    MaterialBlurY:SetMaterialFloat( "$size", 2 );   
    local oldRT = render.GetRenderTarget();  
    render.SetRenderTarget( TexTine );  
    render.SetMaterial( MaterialBlurX );  
    render.DrawScreenQuad();  
    render.SetRenderTarget( TexTine );  
    render.SetMaterial( MaterialBlurY );  
    render.DrawScreenQuad();  
    render.SetRenderTarget( oldRT );   
    render.SetStencilEnable( true );  
    render.SetStencilReferenceValue( 0 );  
    render.SetStencilTestMask( 1 );  
    render.SetStencilCompareFunction( STENCILCOMPARISONFUNCTION_EQUAL );  
    render.SetStencilPassOperation( STENCILOPERATION_ZERO );  
    MaterialComposite:SetMaterialTexture( "$basetexture", TexTine );  
    render.SetMaterial( MaterialComposite );  
    render.DrawScreenQuad();  
    render.SetStencilEnable( false );  
end  
hook.Add( "RenderScreenspaceEffects", "CompositeGlow", RenderScreenspaceEffects );  
local function PostPlayerDraw( pl )   
    if( OUTLINING_PLAYER ) then return; end  
    OUTLINING_PLAYER = true;  
    RenderToStencil( pl );  
    RenderToGlowTexture( pl );  
    OUTLINING_PLAYER = false;  
  end  
hook.Add( "PostPlayerDraw", "RenderGlow", PostPlayerDraw );
end 
hook.Add("HUDPaint","WallHax",WallHack)
elseif WallToggle == 1 then
WallToggle = 0
hook.Remove("HUDPaint","WallHax")

hook.Remove( "PostPlayerDraw", "RenderGlow"); 
hook.Remove( "RenderScreenspaceEffects", "CompositeGlow");  
hook.Remove( "RenderScene", "ResetGlow" );  

for k,v in pairs(player.GetAll()) do
v:SetMaterial(v.PlyMat)
end
end
end)
-------------------------------------------------
-----------------Rapid Fire----------------------
local nti = 0
concommand.Add("+hax_rapidfire",function()
function rapidfire()
if nti < 2 then
nti = nti + 1
else
nti = 1
end

if nti ~= 1 then
RunConsoleCommand("+attack")
elseif nti ~= 2 then
RunConsoleCommand("-attack")
end

end
hook.Add("Think","rapidfire",rapidfire)
end)
concommand.Add("-hax_rapidfire",function()
hook.Remove("Think","rapidfire")
RunConsoleCommand("-attack")
end)
-------------------------------------------------
-------------------Trigger Bot-------------------
function TBSet()
if GetConVarNumber("Hax_TriggerBot") == 1 and AimToggle == 1 then
if ValidEntity(ClosestTarget()) then
RunConsoleCommand("+hax_rapidfire")
end
end
end
hook.Add("Think","TBGet",TBSet)
-------------------------------------------------
--------------------No Recoil--------------------
function NoRecoilWeapons()
if LocalPlayer():GetActiveWeapon().Primary then
LocalPlayer():GetActiveWeapon().Primary.Recoil = 0
end
end
hook.Add("Think","NoRecoilWeps",NoRecoilWeapons)
------------------------------------------------
-------------------Cross Hairs------------------
local Speed = 5
function DrawCrossHairs()
CHPosx = math.Clamp(LocalPlayer():GetEyeTrace().HitPos:ToScreen().x,0,ScrW())
CHPosy = math.Clamp(LocalPlayer():GetEyeTrace().HitPos:ToScreen().y,0,ScrH())

mathsin = math.sin(CurTime()*Speed)*4
mathcos = math.cos(CurTime()*Speed)*4
mathsin2 = math.sin(CurTime()*Speed+0.1)*4
mathcos2 = math.cos(CurTime()*Speed+0.1)*4
mathsin3 = math.sin(CurTime()*Speed-0.1)*4
mathcos3 = math.cos(CurTime()*Speed-0.1)*4
surface.SetDrawColor(0,255,0,XHairAlpha*GetConVarNumber("Hax_ShowCrosshair"))
surface.DrawLine( CHPosx+mathcos*2,CHPosy+mathsin*2,CHPosx+mathcos*5,CHPosy+mathsin*5 );
surface.DrawLine( CHPosx-mathcos*2,CHPosy-mathsin*2,CHPosx-mathcos*5,CHPosy-mathsin*5 );
surface.DrawLine( CHPosx+mathsin*2,CHPosy-mathcos*2,CHPosx+mathsin*5,CHPosy-mathcos*5 );
surface.DrawLine( CHPosx-mathsin*2,CHPosy+mathcos*2,CHPosx-mathsin*5,CHPosy+mathcos*5 );
surface.SetDrawColor(0,0,0,XHairAlpha*GetConVarNumber("Hax_ShowCrosshair"))
surface.DrawLine( CHPosx+mathcos2*2,CHPosy+mathsin2*2,CHPosx+mathcos2*5,CHPosy+mathsin2*5 );
surface.DrawLine( CHPosx-mathcos2*2,CHPosy-mathsin2*2,CHPosx-mathcos2*5,CHPosy-mathsin2*5 );
surface.DrawLine( CHPosx+mathsin2*2,CHPosy-mathcos2*2,CHPosx+mathsin2*5,CHPosy-mathcos2*5 );
surface.DrawLine( CHPosx-mathsin2*2,CHPosy+mathcos2*2,CHPosx-mathsin2*5,CHPosy+mathcos2*5 );

surface.DrawLine( CHPosx+mathcos3*2,CHPosy+mathsin3*2,CHPosx+mathcos3*5,CHPosy+mathsin3*5 );
surface.DrawLine( CHPosx-mathcos3*2,CHPosy-mathsin3*2,CHPosx-mathcos3*5,CHPosy-mathsin3*5 );
surface.DrawLine( CHPosx+mathsin3*2,CHPosy-mathcos3*2,CHPosx+mathsin3*5,CHPosy-mathcos3*5 );
surface.DrawLine( CHPosx-mathsin3*2,CHPosy+mathcos3*2,CHPosx-mathsin3*5,CHPosy+mathcos3*5 );

surface.DrawLine( CHPosx+mathcos3*5,CHPosy+mathsin3*5,CHPosx+mathcos2*5,CHPosy+mathsin2*5 );
surface.DrawLine( CHPosx-mathcos3*5,CHPosy-mathsin3*5,CHPosx-mathcos2*5,CHPosy-mathsin2*5 );
surface.DrawLine( CHPosx+mathsin3*5,CHPosy-mathcos3*5,CHPosx+mathsin2*5,CHPosy-mathcos2*5 );
surface.DrawLine( CHPosx-mathsin3*5,CHPosy+mathcos3*5,CHPosx-mathsin2*5,CHPosy+mathcos2*5 );


end
hook.Add("HUDPaint","CrossHair",DrawCrossHairs)
------------------------------------------------
------------------------------------------------
--Bit late but oh well! Now to see who your----- 
--aiming at!------------------------------------
------------------------------------------------
local tmpa = {}
local tmp = {}
local plyd = LocalPlayer()
function GetAimedAt()
local pname,pname2,pname3,pname4,pname5,pname6,pname7,pname8,normalpname
if ValidEntity(ClosestTarget()) then
plyd = ClosestTarget()
surface.SetTextColor( 255,255,255, 255 )
surface.SetTextPos( 700, 20 ) 
surface.SetFont("BudgetLabel")
pname = plyd:Name() 
pname2 = string.Replace(pname,"^1","")
pname3 = string.Replace(pname2,"^2","")
pname4 = string.Replace(pname3,"^3","")
pname5 = string.Replace(pname4,"^4","")
pname6 = string.Replace(pname5,"^5","")
pname7 = string.Replace(pname6,"^6","")
pname8 = string.Replace(pname7,"^7","")
normalpname = string.Replace(pname8,"?","")
if ClosestTarget() == LocalPlayer() then
surface.DrawText( "Aimbot target: None")
else
surface.DrawText( "Aimbot target: "..normalpname )
end
else
plyd = LocalPlayer()
surface.SetFont("BudgetLabel")
surface.SetTextPos( 700, 20 ) 
surface.SetTextColor( 255,255,255, 255 )
surface.DrawText( "Aimbot target: None")
end
surface.SetFont("BudgetLabel")
surface.SetTextColor( 255,255,255, 255 )
surface.SetTextPos( 700, 30 )
surface.DrawText( "Trigger Bot: "..TBVal )
surface.SetTextPos( 700, 40 )
surface.DrawText( "Aim Bot:")
if AimToggle == 1 then
surface.SetTextPos( 760, 40 )
surface.SetTextColor( 0,255,0, 255 )
surface.DrawText( "On" )
else
surface.SetTextPos( 760, 40 )
surface.SetTextColor( 255,0,0, 255 )
surface.DrawText( "Off" )
end
surface.SetTextColor( 255,255,255, 255 )
surface.SetTextPos( 700, 50 )
surface.DrawText( "Admins Online:")
for k,v in pairs(player.GetAll()) do
if v:IsAdmin() then
table.insert(tmpa,v)
end
end
for k,v in pairs(tmpa) do
if ValidEntity(v) then
surface.SetTextColor(255,255,255,255)
surface.SetTextPos( 800, 50+(k-1)*10 )
surface.DrawText( v:Name() )
end
table.remove(tmpa,k)
surface.SetTextColor( 255,255,255, 255 )
surface.SetTextPos( 950, 20 )
if #Friends == 0 then
surface.DrawText( "Aimbot Friends:None")
else
surface.DrawText( "Aimbot Friends:")
end
for k,v in pairs(Friends) do
if ValidEntity(v) then
surface.SetTextColor(255,255,255,255)
surface.SetTextPos( 1057, 20+(k-1)*10 )
surface.DrawText( v:Name() )
end
end
end
end
hook.Add("HUDPaint","GetAimbotPly",GetAimedAt)
------------------------------------------------
--------------------Draw ESP--------------------
local xx,yy = 0,0
local Flags2
function DrawCross()
if ValidEntity(ClosestTarget()) then 



if ClosestTarget():GetClass() == "player" then
if ClosestTarget() == LocalPlayer() then
 xx = ScrW()/2
 yy = ScrH()/2
 else
 xx = math.Clamp((ClosestTarget():GetBonePosition(ClosestTarget():LookupBone("ValveBiped.Bip01_Head1"))):ToScreen().x,0,ScrW())
 yy = math.Clamp((ClosestTarget():GetBonePosition(ClosestTarget():LookupBone("ValveBiped.Bip01_Head1"))+Vector(0,0,2)):ToScreen().y,0,ScrH())
end
 surface.SetDrawColor(255,255,255,XHairAlpha*GetConVarNumber("Hax_ShowCrosshair2"))
mathsin = math.sin(CurTime()*Speed)*4
mathcos = math.cos(CurTime()*Speed)*4
surface.DrawLine( xx+mathcos*2,yy+mathsin*2,xx+mathcos*5,yy+mathsin*5 );
surface.DrawLine( xx-mathcos*2,yy-mathsin*2,xx-mathcos*5,yy-mathsin*5 );
surface.DrawLine( xx+mathsin*2,yy-mathcos*2,xx+mathsin*5,yy-mathcos*5 );
surface.DrawLine( xx-mathsin*2,yy+mathcos*2,xx-mathsin*5,yy+mathcos*5 );
end
end
end

hook.Add( "HUDPaint", "DrawName", DrawCross )
-----------------------------------------------
---------------------BHOP----------------------
function StartBhop()
if LocalPlayer():IsOnGround() then
RunConsoleCommand("+jump")
elseif not LocalPlayer():IsOnGround() and LocalPlayer():GetMoveType() == MOVETYPE_WALK then
RunConsoleCommand("-jump")
end
end
concommand.Add("+bhop",function()
hook.Add("Think","Bhop",StartBhop)
RunConsoleCommand("+jump")
end)
concommand.Add("-bhop",function()
hook.Remove("Think","Bhop")
RunConsoleCommand("-jump")
end)
-----------------------------------------------
---------------------SPEED---------------------
concommand.Add("+Hax_speed",function()
cvar2.SetValue("host_timescale",5)
end)
concommand.Add("-Hax_speed",function()
cvar2.SetValue("host_timescale",1)
end)
-----------------------------------------------
-----------------------------------------------
local DarkRPClasses = {"spawned_money","spawned_shipment","spawned_weapon","money_printer","golden_money_printer","prop_physics"}
-----------------------------------------------
function DrawRPHax()
for k,v in pairs(ents.GetAll()) do
if not ValidEntity(v) then return end
if table.HasValue(DarkRPClasses,v:GetClass()) then
if RPhax == 1 then
v:SetMaterial("solid")
if v:GetClass() == DarkRPClasses[1] then
v:SetColor(255,0,0,255)
end
if v:GetClass() == DarkRPClasses[2] then
v:SetColor(255,50,200,255)
end
if v:GetClass() == DarkRPClasses[3] then
v:SetColor(0,255,0,255)
end
if v:GetClass() == DarkRPClasses[4] then
v:SetColor(0,0,255,255)
end
if v:GetClass() == DarkRPClasses[5] then
v:SetColor(255,204,51,255)
end
if v:GetClass() == DarkRPClasses[6] then
v:SetColor(255,255,255,255)
end
end
if RPhax == 0 then
v:SetMaterial("")
if v:GetClass() == DarkRPClasses[1] then
v:SetColor(255,255,255,255)
end
if v:GetClass() == DarkRPClasses[2] then
v:SetColor(255,255,255,255)
end
if v:GetClass() == DarkRPClasses[3] then
v:SetColor(255,255,255,255)
end
if v:GetClass() == DarkRPClasses[4] then
v:SetColor(255,255,255,255)
end
if v:GetClass() == DarkRPClasses[5] then
v:SetColor(255,255,255,255)
end
if v:GetClass() == DarkRPClasses[6] then
v:SetColor(255,255,255,255)
end
end
end
end
end
hook.Add("HUDPaint","RPHax",DrawRPHax)


local GetToggle = WallToggle
local pllist = {}

local function PlayerGetByName( stringent )
for k,v in pairs(ents.GetAll()) do
if v:IsPlayer() then
if v:Name() == stringent then
return v
end
end
end
end
local ipt = {}
function PlayerConnected(name, ip)
table.insert(ipt,"Name: "..name.."    IP: "..ip)
LocalPlayer():ChatPrint(name.."'s IP is "..ip)
end
hook.Add("PlayerConnect","GetIP",PlayerConnected)
local ComboBox2
local ATab
concommand.Add("+Hax_Menu",function()
GetToggle = WallToggle
local DermaPanel = vgui.Create( "DFrame" )
DermaPanel:SetPos( ScrW()/2-185,ScrH()/2-133 )
DermaPanel:SetSize( 0, 0 )
DermaPanel:SetTitle( "" )
DermaPanel:SetVisible( true )
DermaPanel:SetDraggable( false )
DermaPanel:ShowCloseButton( true )
DermaPanel:MakePopup()

concommand.Add("-Hax_Menu",function()
ATab = Pan:GetActiveTab()
DermaPanel:SetVisible(false)
end)

Pan = vgui.Create( "DPropertySheet" )
Pan:SetParent(DermaPanel)
Pan:SetPos( ScrW()/2-185,ScrH()/2-133 )
Pan:SetSize( 370, 270 )
Pan:SetFadeTime(0.01)
Pan:MakePopup()
Pan.Paint = function( Pan )
	   surface.SetDrawColor( 0, 0, 0, 255 );
	   	   surface.SetMaterial( Material("SHV2/menu_backg.vtf") )
	   	   surface.DrawTexturedRect( 5, 2, Pan:GetWide()-42, Pan:GetTall()-30 )
end
local DermaParent = vgui.Create( "DLabel", Pan )
DermaParent:SetPos(4,0)
DermaParent:SetText("")
local DermaParent2 = vgui.Create( "DLabel", Pan )
DermaParent2:SetPos(4,0)
DermaParent2:SetText("")
local DermaParent3 = vgui.Create( "DLabel", Pan )
DermaParent3:SetPos(4,0)
DermaParent3:SetText("")
local DermaParent4 = vgui.Create( "DLabel", Pan )
DermaParent4:SetPos(4,0)
DermaParent4:SetText("")

Pan:AddSheet( "General", DermaParent, "gui/silkicons/box", false, false, "General Settings" )
Pan:AddSheet( "Aimbot", DermaParent2, "gui/silkicons/group", false, false, "Aimbot Settings" )
Pan:AddSheet( "Aimbot Friends", DermaParent3, "gui/silkicons/heart", false, false, "Aimbot Friend List" )
Pan:AddSheet( "Players Info", DermaParent4, "gui/silkicons/user", false, false, "Information Of Each Player" )

local CheckBox = vgui.Create( "DCheckBoxLabel", DermaParent )
     CheckBox:SetPos(10,0)
     CheckBox:SetText("Name Tags")
	    CheckBox:SetConVar("Hax_NameTags")
     CheckBox:SizeToContents()
	    
	    local CheckBoxb = vgui.Create( "DCheckBoxLabel", DermaParent )
     CheckBoxb:SetPos(10,150)
     CheckBoxb:SetText("Full Bright")
	    CheckBoxb:SetConVar("mat_fullbright")
     CheckBoxb:SizeToContents()
 
 	    local CheckBoxc = vgui.Create( "DCheckBoxLabel", DermaParent )
     CheckBoxc:SetPos(10,20)
     CheckBoxc:SetText("Show Particles")
	    CheckBoxc:SetConVar("r_drawparticles")
     CheckBoxc:SizeToContents()
 
	    local CheckBox2 = vgui.Create( "DCheckBoxLabel", DermaParent )
     CheckBox2:SetPos(10,40)
     CheckBox2:SetText("Show CrossHair")
	    CheckBox2:SetConVar("Hax_Showcrosshair")
     CheckBox2:SizeToContents()
	    
	    	    local CheckBox2b = vgui.Create( "DCheckBoxLabel", DermaParent )
     CheckBox2b:SetPos(10,60)
     CheckBox2b:SetText("Show Aimbot CrossHair")
	    CheckBox2b:SetConVar("Hax_Showcrosshair2")
     CheckBox2b:SizeToContents()
	    
	    Label1 = vgui.Create("DLabel", DermaParent)
     Label1:SetText("Choose Wall Hack Mode. 1:Normal 2:L4D Style")
     Label1:SizeToContents() 
	    Label1:SetPos(10,80)
	    
	    local Wang = vgui.Create( "DNumberWang", DermaParent )
	    Wang:SetPos( 10, 100 )
	    Wang:SetMinMax( 1 , 2 )
	    Wang:SetWide(100)
	    Wang:SetDecimals(0)
	    Wang:SetConVar("Hax_WallHackStyle")
	    
	    Label2 = vgui.Create("DLabel", DermaParent)
     Label2:SetText("Max wall hack distance (in thousands)")
     Label2:SizeToContents() 
	    Label2:SetPos(10,170)
	    
	    local Wang2 = vgui.Create( "DNumberWang", DermaParent )
	    Wang2:SetPos( 10, 185 )
	    Wang2:SetMinMax( 1 , 1000 )
	    Wang2:SetWide(100)
	    Wang2:SetDecimals(0)
	    Wang2:SetConVar("Hax_MaxWallHackDist")
	    
	    Label3 = vgui.Create("DLabel", DermaParent2)
     Label3:SetText("Max Aim FOV")
     Label3:SizeToContents() 
	    Label3:SetPos(10,80)
	    
	    local Wang3 = vgui.Create( "DNumberWang", DermaParent2 )
	    Wang3:SetPos( 10, 95 )
	    Wang3:SetMinMax( 0 , 180 )
	    Wang3:SetWide(100)
	    Wang3:SetDecimals(0)
	    Wang3:SetConVar("Hax_AimFov")
	    
	    	    local buttont = vgui.Create( "DButton", DermaParent )
	    buttont:SetSize( 100, 20 )
	    buttont:SetPos( 10, 125 )
	    buttont:SetText( "Toggle WallHack" )
	    buttont.DoClick = function( buttont )
	    RunConsoleCommand("Hax_WallHack")
	    end
	    
	    local CheckBox3b = vgui.Create( "DCheckBoxLabel", DermaParent2 )
     CheckBox3b:SetPos(10,0)
     CheckBox3b:SetText("Ignore Steam Friends")
	    CheckBox3b:SetConVar("Hax_IgnoreSteamFriends")
     CheckBox3b:SizeToContents()
	    
	    local CheckBox4b = vgui.Create( "DCheckBoxLabel", DermaParent2 )
     CheckBox4b:SetPos(10,20)
     CheckBox4b:SetText("Trigger Bot")
	    CheckBox4b:SetConVar("Hax_TriggerBot")
     CheckBox4b:SizeToContents()
	    
	    local CheckBox4c = vgui.Create( "DCheckBoxLabel", DermaParent2 )
     CheckBox4c:SetPos(10,40)
     CheckBox4c:SetText("Ignore Team Mates")
	    CheckBox4c:SetConVar("Hax_IgnoreTeam")
     CheckBox4c:SizeToContents()
	    
local Icon = vgui.Create("DModelPanel", DermaParent)
Icon:SetModel(LocalPlayer():GetModel())
Icon:SetAnimated(true)
Icon:SetPos(150,10)
Icon:SetSize(175,175)
Icon.Entity:SetPos(Icon.Entity:GetPos()+Vector(-20,0,0))

local Icon2 = vgui.Create("DModelPanel", DermaParent2)
Icon2:SetModel(LocalPlayer():GetModel())
Icon2:SetAnimated(true)
Icon2:SetPos(150,10)
Icon2:SetSize(175,175)
Icon2.Entity:SetPos(Icon2.Entity:GetPos()+Vector(-20,0,0))
for k,v in pairs(player.GetAll()) do
if not table.HasValue(Friends,v) and not table.HasValue(pllist,v) then
table.insert(pllist,v)
end
end
local ComboBox
ComboBox = vgui.Create( "DComboBox", DermaParent3 )
ComboBox:SetPos( 10, 0 )
ComboBox:SetSize( 170, 210 )
ComboBox:SetMultiple( false )
ComboBox:EnableVerticalScrollbar( true )
for k,v in pairs(pllist) do
if ValidEntity(v) then
ComboBox:AddItem( v:Name() ) 
end
end

local buttona = vgui.Create( "DButton", DermaParent3 )
	   buttona:SetSize( 141, 30 )
	   buttona:SetPos( 183, 0 )
	   buttona:SetText( "Add Friend" )
	   buttona.DoClick = function( buttona )
if #ComboBox:GetSelectedItems()==0 then LocalPlayer():ChatPrint("Select a player then retry") return end
for k,v in pairs(ComboBox:GetSelectedItems()) do
if not table.HasValue(Friends,PlayerGetByName(v:GetValue())) and ValidEntity(PlayerGetByName(v:GetValue())) then
table.insert(Friends,PlayerGetByName(v:GetValue()))
LocalPlayer():ChatPrint("Added "..v:GetValue().." to aimbot friends!")
end
end
end
local tmpt = {}
local buttonb = vgui.Create( "DButton", DermaParent3 )
	   buttonb:SetSize( 141, 30 )
	   buttonb:SetPos( 183, 33 )
	   buttonb:SetText( "Remove Friend" )
	   buttonb.DoClick = function( buttonb )
if #ComboBox:GetSelectedItems()==0 then LocalPlayer():ChatPrint("Select a player then retry") return end
for a,b in pairs(ComboBox:GetSelectedItems()) do
for c,d in pairs(Friends) do
if b:GetValue() == d:Name() then
table.remove(Friends,c)
end
end
end
end

	   for k,v in pairs(ipt) do
	    Label3 = vgui.Create("DLabel", DermaParent4)
     Label3:SetText(v)
     Label3:SizeToContents() 
	    Label3:SetPos(10,k*15+10)
	   end

end)

local ZoomIn = 0
local TTrace
concommand.Add("+Hax_Zoom",function()
TTrace= LocalPlayer():GetEyeTrace()
hook.Add("CalcView", "ZCalcView", CalcView)
hook.Add("Think","ZoomIn",function()
if ZoomIn < 1 then
ZoomIn=ZoomIn+0.01
end
end)
end)
concommand.Add("-Hax_Zoom",function()
hook.Remove("CalcView", "ZCalcView")
hook.Add("Think","ZoomIn",function()
ZoomIn=0
end)
end)
function CalcView(ply, pos, angles, fov)
    local view = {}
    view.origin = LerpVector(ZoomIn,pos,TTrace.HitPos+TTrace.HitNormal*20)
    view.angles = angles
    view.fov = fov
 
    return view
end