--[[
	MOD/lua/speedy.lua
	ice cube | STEAM_0:1:36452221 <86.180.113.76:65403> | [07-01-14 11:54:45PM]
	===BadFile===
]]

surface.CreateFont("deffont", {
        font    =       "impact",
        size    =       64
});
surface.CreateFont("deffontesp1", {
        font="TabLarge",
        size=13,
        weight=700
});
surface.CreateFont("deffontesp2", {
        font="TabLarge",
        size=10,
        weight=700
});
surface.CreateFont("deffontesp3", {
        font="verdana",
        size=20,
        weight=700
});
-- short vars
local menu                              = defcon.Menu
local current                   = defcon.Current
local alive                             = defcon.Alive
local normal                    = defcon.Normal
local settings                  = defcon.Settings
local entities                  = defcon.Entities
local whitelist                 = defcon.Whitelist
local phrases                   = defcon.Phrases
local espcheck                  = defcon.ESPCheck
local espdistance               = defcon.ESPDistance
local G                                 = table.Copy(_G)
local R                                 = table.Copy(_R)

hook.Add("HUDPaint", "catHUD", function()
end
        if defcon.Settings["esp_player"] or defcon.Settings["esp_entity"] then
                for k,v in pairs(ents.GetAll()) do
                        if defcon.Settings["esp_player"] && v:IsPlayer() then
                                if(espcheck("player", v) and espdistance("player", v))then
                                        local ESP = (v:EyePos()):ToScreen()
                                        local name,health,rank,col,distance = "","","","",""
                                        local outcol = Color(0,0,0,255)
                                        local white = Color(255,255,255,255)
                                        local outcol2 = outcol
                                        if defcon.Settings["esp_player_name"] then
                                                if v.GetRPName then name = v:GetRPName()
                                                else name = v:Nick() end
                                        end
                                        if v:Nick() ~= name then rank = " "..v:Nick() end
                                        if v.SteamName and name ~= v:SteamName() then rank = " "..v:SteamName() end
                                        if defcon.Settings["esp_player_rank"] then
                                                if v:IsSuperAdmin() then
                                                        rank = "[Super Admin]"..rank
                                                elseif v:IsAdmin() then
                                                        rank = "[Admin]"..rank
                                                elseif v:IsUserGroup("moderator") or v:IsUserGroup("mod") then
                                                        rank = "[Moderator]"..rank
                                                elseif v:IsUserGroup("vip") or v:IsUserGroup("donator") then
                                                        rank = "[Donator]"..rank
                                                end
                                        end
                                        if defcon.Settings["esp_player_health"] and not(defcon.Settings["esp_player_armor"]) then
                                                health = v:Health().."H"
                                        elseif defcon.Settings["esp_player_armor"] and not(defcon.Settings["esp_player_health"]) then
                                                health = v:Armor().."A"
                                        elseif defcon.Settings["esp_player_armor"] and defcon.Settings["esp_player_health"] then
                                                health = v:Health().. "H - "..v:Armor().."A"
                                        end
                                        if defcon.Settings["esp_player_showdist"] then
                                                distance = v:GetPos():Distance(LocalPlayer():GetPos())
                                                distance = math.Round(distance).." m"
                                        end
                                        col = team.GetColor(v:Team())
                                        if (not col) or (col == nil) then
                                                col = Color(255,255,255,255)
                                        end
                                        if(col.r <= 50 and col.g <= 50 and col.b <= 50) then
                                                outcol2 = Color(200,200,200,255)
                                        end
                                        if col.a <= 50 then
                                                col = Color(col.r,col.g,col.b, 255)
                                        end
                                        draw.SimpleTextOutlined(rank, "deffontesp2", ESP.x, ESP.y -46, col, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, outcol2)
                                        draw.SimpleTextOutlined(name, "deffontesp1", ESP.x, ESP.y - 34, col, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, outcol2)
                                        if health ~= "" then
                                                draw.SimpleTextOutlined(health, "deffontesp2", ESP.x, ESP.y -22, white, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, outcol)
                                                draw.SimpleTextOutlined(distance, "deffontesp2", ESP.x, ESP.y - 10, white, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, outcol)
                                        else
                                                draw.SimpleTextOutlined(distance, "deffontesp2", ESP.x, ESP.y - 22, white, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, outcol)
                                        end
                                        if defcon.Settings["esp_player_glow"] then
                                                halo.Add({v}, col, 2, 2, 1, true, true)
                                        end
                                end
                        end
                        if (defcon.Settings["esp_entity"] and espcheck("entity", v) and espdistance("entity", v))then
                                if table.HasValue(defcon.Entities, v:GetClass()) then
                                        local ESP = (v:EyePos()):ToScreen()
                                        draw.SimpleTextOutlined(v:GetClass(), "deffontesp1", ESP.x, ESP.y - 46, Color(255,0,0,255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, Color(0,0,0,255))
                                        if defcon.Settings["esp_entity_glow"] then
                                                halo.Add({v}, Color(255,0,0,255), 2, 2, 1, true, true)
                                        end
                                end
                        end
                end
        end
        if input.IsKeyDown(KEY_TAB) and string.find(gmod.GetGamemode().Name, "Trouble in Terrorist Town") and defcon.Settings["ttt_showalive"] then
                local t = {}
                for k,v in pairs(player.GetAll()) do
                        if v:IsValid() and v:Team() ~= TEAM_SPECTATOR and defcon.Alive[v:UniqueID()] == true and v ~= LocalPlayer() then
                                table.insert(t, v)
                        end
                end
 
                local height = 30
                local offs = 30
                for i = 1, #t do
                        height = height + 15;
                end
                surface.SetDrawColor(0,0,0,255)
                surface.DrawRect(ScrW()-185, ScrH()-ScrH()+5, 175, height);
 
                surface.SetTextColor(Color(255, 255, 255, 255));
                surface.SetTextPos(ScrW()-125, ScrH()-ScrH()+5);
                surface.SetFont("Trebuchet24");
                surface.DrawText("ALIVE");
 
                surface.SetFont("Trebuchet18");
                for k,v in pairs(t) do
                        local nick = string.sub(v:Nick(), 0, 22);
                        surface.SetTextPos(ScrW()-175, ScrH()-ScrH()+offs)
                        surface.DrawText(nick)
                        offs = offs + 15
                end
        end
		
local CrossHairOn = CreateClientConVar("skid_crosshair", 1, true, false)

local function NamesOnHeads()
	local ScrWidth, ScrHeight = ScrW(), ScrH()
	local aimVec = LocalPlayer():GetAimVector()
	local localPos = EyePos()
	if CrossHairOn:GetInt() == 1 then
		local Size = 9

		surface.SetDrawColor(0,0,0,160)
		surface.DrawLine(ScrWidth/2-Size, ScrHeight/2 + 1, ScrWidth/2+Size, ScrHeight/2 + 1)
		surface.DrawLine(ScrWidth/2-Size, ScrHeight/2 - 1, ScrWidth/2+Size, ScrHeight/2 - 1)

		surface.DrawLine(ScrWidth/2 + 1, ScrHeight/2 - Size, ScrWidth/2 + 1, ScrHeight/2 + Size)
		surface.DrawLine(ScrWidth/2 - 1, ScrHeight/2 - Size, ScrWidth/2 - 1, ScrHeight/2 + Size)

		surface.SetDrawColor(0,255,0,255)
		surface.DrawLine(ScrWidth/2 - Size, ScrHeight/2, ScrWidth/2 + Size, ScrHeight/2)
		surface.DrawLine(ScrWidth/2, ScrHeight/2 - Size, ScrWidth/2, ScrHeight/2 + Size)

	end
end

			hook.Add("PreDrawSkyBox", "removeSkybox", function()
			render.Clear(0, 160, 255, 255)

			return true
		end)
	
local Disable = CreateClientConVar( "cl_disable_spawn_effects", "1", true, false )
if not tobool(Disable:GetInt()) then return end
local function Override()
	effects.Register( { Init = function() end, Think = function() end, Render = function() end }, "propspawn" )

	DoPropSpawnedEffect = function( ent )
	end
end

timer.Create("OverrideProp", 30, 0, Override)

hook.Add( "InitPostEntity", "PostGamemodeLoaded.OverridePropEffect", Override )
timer.Simple(3, Override)

    if CLIENT then
            concommand.Add("+bhop",function()
                    hook.Add("Think","hook",function()
                            RunConsoleCommand(((LocalPlayer():IsOnGround() or LocalPlayer():WaterLevel() > 0) and "+" or "-").."jump")
                    end)
            end)
     
            concommand.Add("-bhop",function()
                    RunConsoleCommand("-jump")
                    hook.Remove("Think","hook")
            end)
    end

	ocal function Rotate180Up()
	FALCO_NOAUTOPICKUP = true
	timer.Simple(0.5, function() FALCO_NOAUTOPICKUP = false end)

	if hook.GetTable().CreateMove and hook.GetTable().CreateMove.PickupEnt then
		hook.Remove("CreateMove", "PickupEnt")
		hook.Remove("CalcView", "Ididntseeit")
		timer.Simple(0.05, function()
			local a = LocalPlayer():EyeAngles() LocalPlayer():SetEyeAngles(Angle(a.p-a.p-a.p, a.y-180, a.r))
			RunConsoleCommand("+jump")
			timer.Simple(0.2, function() RunConsoleCommand("-jump") end)
		end)
		return
	end
	local a = LocalPlayer():EyeAngles() LocalPlayer():SetEyeAngles(Angle(a.p-a.p-a.p, a.y-180, a.r))
	RunConsoleCommand("+jump")
	timer.Simple(0.2, function() RunConsoleCommand("-jump") end)
end
concommand.Add("skid_180up", Rotate180Up)

concommand.Add("skid_180shot", function()
	local IsHook = hook.GetTable().CalcView and hook.GetTable().CalcView["180shot"]
	if IsHook then
		Rotate180()
		hook.Remove("CalcView", "180shot")
		timer.Destroy("180shot")
		return
	end

	hook.Add("CalcView", "180shot", function(ply, origin, angle, fov)
		local view = {}
		view.origin = origin
		view.angles = angle - Angle(0,180,0)
		view.fov = fov

		if not LocalPlayer():KeyDown(IN_ATTACK) then
			hook.Remove("CalcView", "180shot")
			Rotate180()
			timer.Destroy("180shot")
		end

		return view
	end)
	Rotate180()
	timer.Create("180shot", 5, 1, function()
		hook.Remove("CalcView", "180shot")
		Rotate180()
	end)
end)