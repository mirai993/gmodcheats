--[[
	MOD/lua/shack.lua [#15401 (#15401), 115878292, UID:3163339645]
	Shocky | STEAM_0:1:68217077 <75.81.60.148:27005> | [18.07.14 04:56:36AM]
	===BadFile===
]]

--Shack 1.3
--patchnotes
--[[
##1.3
- added aimbot
- added keybinds
- add bhop
- bounding boxes around keyitems
*fixed buddies

##1.2
- added tracers

##1.1
- added color coding
]]--
keywords={}
admins={}
Tracking={}
misc={}
oldcolor={}
bindnames={}
on={}
tracers={}
DownDist=0
NearestBad=nil --the nearest player who isn't a buddy because aimbots
function say(S)
	LocalPlayer():ChatPrint("[SH] "..S)
end
--BINDS--------------------------------------------------------------------------------------------------------------------------------------------------------------------------
function addBind(Name,Con)
	on[Name]=false
	local function DoToggle()
		on[Name]=not on[Name]
		local out=""
		if on[Name] then out="has been turned on." else out="has been turned off." end
		say(""..Name.." "..out)
	end
	concommand.Add(Con, DoToggle)
end
function addTBind(Name,Con)
	on[Name]=false
	local function DoOn()
		on[Name]=true
		say(Name.." enabled.")
	end
	local function DoOff()
		on[Name]=false
		say(Name.." disabled.")
	end
	concommand.Add("+"..Con,DoOn)
	concommand.Add("-"..Con,DoOff)

end
addBind("Tracers","sh_tracers")
addBind("PlayerInfo","sh_info")
addBind("Materials","sh_mats")
addBind("Radar","sh_radar")
addTBind("Aimbot","sh_aim")
addBind("Ragebot","sh_rage")
addBind("Burn","sh_burn")

blacklist={"physgun_beam"} --never displayed by text
showname={"player"} --entities whose name will be shown
docenter={"player","spawned_shipment","drug_lab"} --entities whose circles will be moved up by half the entitiy's size
buddies={"STEAM_0:1:24971849","STEAM_0:0:59610185"} --green tracers, do not hit via aimbot
tracers={"player"} --entities for tracers
buddyplayers={} --entity container for buddies

--Color Coding
misc["Buddies"]=Color(0,255,250,255)
misc["Admins"]=Color(255,0,0,255)
misc["Player"]=Color(0,0,255,64)
misc["Track"]=Color(255,255,0,255)
keywords["printer"]=Color(255,255,255,255)
keywords["weapon"]=Color(0,255,0,255)
keywords["drug"]=Color(255,0,0,128)
keywords["gun"]=Color(255,0,255,255)
keywords["microwave"]=Color(255,0,255,255)
keywords["shipment"]=Color(255,255,0,255)
keywords["player"]=Color(0,0,255,255)


function getUp(ent)
				local Min,Max=ent:WorldSpaceAABB()
				local AddZ=math.abs(Min.z-Max.z)/2
				for i,v in pairs(docenter) do
					if string.match(ent:GetClass(),v,0) then
						return AddZ
					end
				end
				return 0
end
function isBad(ent)
	for i,v in pairs(admins) do
		if ent==v then return true end
	end
	return false
end
function canShoot(pos,ent)
	local tracedata = {}
	tracedata.start=LocalPlayer():GetShootPos()
	tracedata.endpos=pos
	tracedata.filter=LocalPlayer()
	tracedata.mask=33570819 --shoot through fences, etc
	local trace = util.TraceLine(tracedata)
	if trace.HitNonWorld then
		if trace.Entity==ent then return true end
	end
	return false

end
function isBuddy(ent)
	for i,v in pairs(buddies) do
		if ent:SteamID()==v then
			if not buddyplayers[ent:SteamID()] then
				buddyplayers[ent:SteamID()]=ent --blacklist buddies from getting aimbot'd
			end
			return true
		end
	end
return false
end

function isKeyed(S)
	for i,v in pairs(keywords) do
		if string.match(S,i,0) then return true, v end
	end
	return false, Color(0,0,0,0)
end
function isBlack(S)
if (S==LocalPlayer()) then return true end
str=S:GetClass()
	for i,v in pairs(blacklist) do
		if string.match(str,v,0) then return true end
	end
	return false
end
function isGood(S)
	for i,v in pairs(showname) do
		if string.match(S,v,0) then return true end
	end
	return false
end

function getRealName(E)
	if isGood(E:GetClass()) then
		return E:GetName()
	else
		return E:GetClass()
	end
end

function doTrace(E)
	for i,v in pairs(tracers) do
		if string.match(string.lower(E),string.lower(v),0) then return true end
	end
	return false
end

function isTracked(ent)
	for i,v in pairs(Tracking) do
		if ent==v then return true end
	end
	return false
end

function getTracer(ent,color)
	if ent:GetClass()~="player" then 
		return color
	end
	if isBad(ent) then return misc["Admins"] end
	if isBuddy(ent) then return misc["Buddies"] end
	if isTracked(ent) then return misc["Track"] end
	return misc["Player"]
end

function FindDarkRPEnts()
	SystemOnline = true
	
hook.Add("HUDPaint", "FindDarkRPEnts", function()
	local players={}
	for _, ent in pairs(ents.GetAll()) do
		Ready, color=isKeyed(ent:GetClass())
		if ent:GetClass()=="player" then table.insert(players,ent) end
		if IsValid(ent) and (Ready) then
			ent:SetMaterial("JamsMaterials/hai")
			color=getTracer(ent,color)
			ent:SetColor(ColorAlpha(color,255))
			--surface.DrawText( v:Health().."hp" )
			if not ent:IsWeapon() and not isBlack(ent) then
				local pos1 = (ent:LocalToWorld(Vector(0,0,getUp(ent))))
				local pos=pos1:ToScreen()
				surface.DrawCircle( pos.x, pos.y, 5, color )
				draw.DrawText(getRealName(ent),"TargetID",pos.x,pos.y+5, ColorAlpha(color,255), TEXT_ALIGN_CENTER)
				if (doTrace(ent:GetClass())) then
					draw.DrawText("HP: "..(ent:Health()),"TargetID",pos.x,pos.y+15, ColorAlpha(color,255), TEXT_ALIGN_CENTER)
					--tracers
					local StartPos=Vector(ScrW()/2, ScrH()/2, 0)
					local EndPos=pos
					surface.SetDrawColor(color)
					surface.DrawLine(StartPos.x,StartPos.y,EndPos.x,EndPos.y)
				end
			end
			end
		end
		--halo.Add( AddHalo, Color(128,128,128,255), 2, 2, 1, true, true )
		--radar
		local distance={}
		local distanceowner={}
		for i,v in pairs(players) do
			local distancer=math.floor(v:GetPos():Distance(LocalPlayer():GetPos()))
			distance[#distance+1]=distancer
			distanceowner[distancer]=v
		end
		table.sort(distance)
		--distance=table.Reverse(distance)
		local playerbydist={}
		local datdistance={}
		for i,v in pairs(distance) do
			playerbydist[#playerbydist+1]=distanceowner[v]
			datdistance[#playerbydist]=distance[i]
		end
		surface.SetTextPos(0,0)
		NearestBad=nil
		local CurMax=0
		for i,v in pairs(playerbydist) do
			CurMax=CurMax+1
			DoDraw=CurMax<20
			surface.SetTextPos(0,DownDist+(15*(i-1)))
			surface.SetTextColor(ColorAlpha(getTracer(v,misc["Player"]),255))
			-- get their heads
			local CanShootHim=false
			if v and v:IsValid() and v:IsPlayer() and v:Alive() then
				targethead = v:LookupBone("ValveBiped.Bip01_Head1")
				if targethead then
					targetheadpos,targetheadang = v:GetBonePosition(targethead) 
					CanShootHim=true
				end
			end
			if CanShootHim and not NearestBad and not isBuddy(v) and v:Alive() and canShoot(targetheadpos,v) then 
				NearestBad=v 
				if DoDraw then
					surface.DrawText("-->"..v:GetName().."<--".." ["..math.floor(datdistance[i]/10).."]")
				end
			else
			if DoDraw then
				surface.DrawText(v:GetName().." ["..math.floor(datdistance[i]/10).."]")
			end
			end
		end
	end)
end

FindDarkRPEnts()

concommand.Add("jam_materials", function()

		if SystemOnline then
			hook.Remove("HUDPaint", "FindDarkRPEnts")
			
	for _, ent in pairs(ents.GetAll()) do 
		if IsValid(ent) and (isKeyed(ent:GetClass())) then
			ent:SetMaterial("")
			ent:SetColor(Color(255,255,255,255))
	end
end

	say("Disabled DarkRPEnts.")
		SystemOnline = false

			elseif !SystemOnline then
				FindDarkRPEnts()
				say("Enabled DarkRPEnts.")
		SystemOnline = true
	end
end)
local function Noclipr( ply )
	table.insert(admins,ply)
end
hook.Add( "PlayerNoClip", "DisableNoclipr", DisableNoclipr )

--bhops----------------------------------------------------------------------------------------------------------------------------------------------------------------------------
if CLIENT then
        concommand.Add("+bhop",function()
                hook.Add("Think","hook",function()
                        RunConsoleCommand(((LocalPlayer():IsOnGround() or LocalPlayer():WaterLevel() > 0) and "+" or "-").."jump")
                end)
        end)
 
        concommand.Add("-bhop",function()
                RunConsoleCommand("-jump")
                hook.Remove("Think","hook")
        end)
end

--flashlights-------------------------------------------------------------------------------------------------------------------------------------------------------------------
if false then
		flashon=false
        concommand.Add("+flash",function()
                hook.Add("Think","flash",function()
                        RunConsoleCommand("impulse","100")
						--print("flashing")
						flashon=not flashon
                end)
        end)
 
        concommand.Add("-flash",function()
				if flashon then
					RunConsoleCommand("impulse","100")
					flashon=false
				end
                hook.Remove("Think","flash")
        end)
end

--autoreload, aimbot--------------------------------------------------------------------------------------------------------------------------------------------------------------------
Reloading=false
Attacking=false
function autoReload()
	if LocalPlayer():Alive() and LocalPlayer():GetActiveWeapon():IsValid() and  LocalPlayer():GetActiveWeapon():GetPrimaryAmmoType() and LocalPlayer():GetActiveWeapon():Clip1()==0 and not Reloading then
		RunConsoleCommand("+reload")
		Reloading=true
	elseif Reloading then RunConsoleCommand("-reload") Reloading=false end
end
hook.Add("Think","autoreload",autoReload)
AimTarget=nil
function aim() -- Starting the function
	local ply = LocalPlayer() -- Getting ourselves
	local trace = util.GetPlayerTrace( ply ) -- Player Trace part. 1
	local traceRes = util.TraceLine( trace ) -- Player Trace part. 2
	if NearestBad then Target=NearestBad end
	if Target and Target:IsValid() and Target:IsPlayer() and Target:Alive() then -- But it must be a player.
			local target=Target
			local targethead = target:LookupBone("ValveBiped.Bip01_Head1") -- In this aimbot we only aim for the head.
			local targetheadpos,targetheadang = target:GetBonePosition(targethead) -- Get the position/angle of the head.
			local oldangs=ply:EyeAngles() --fake 'keep-looking-forward' thing
			ply:SetEyeAngles((targetheadpos - ply:GetShootPos()):Angle()) -- And finally, we snap our aim to the head of the target.
			if on["Ragebot"] and canShoot(targetheadpos,target) and not Attacking then RunConsoleCommand("+attack") Attacking=true else RunConsoleCommand("-attack") Attacking=false end
			--ply:SetEyeAngles(oldangs)
		else Target=nil end
end
--fake view--



concommand.Add("+aim",function()
	hook.Add("Think","aimbot",aim)
end)
concommand.Add("-aim",function()
	hook.Remove("Think","aimbot")
	Target=nil
end)

--concmds-----------------------------------------------------------------------------------------------------------------------------------------------------------------------
--concommand.Add(Name, Function)
cmd={}

cmd.AddTracer=function(player, cmd, args, str)
	if doTrace(args[1]) then say("Already tracing that.") return end
	table.insert(tracers,args[1])
	say("Added "..args[1].." to tracer list.")
	if not keywords[args[1]] then
		say("Adding "..args[1].." to keywords list.")
		local MyColor=Color(math.random(1,255),math.random(1,255),math.random(1,255))
		keywords[args[1]]=MyColor
	end
end
cmd.NoTracer=function(player, cmd, args, str)
	for i,v in pairs(tracers) do
		if string.match(v,args[1],0) then
			say("Removing "..v.." from tracers list.")
			table.remove(tracers,i)
		end
	end
end
cmd.Draw=function(player, cmd, args, str)
	if isKeyed(args[1]) then say("Already drawing that.") return end
	say("Added "..args[1].." to keywords list.")
	if not args[4] then
		MyColor=Color(math.random(1,255),math.random(1,255),math.random(1,255))
	elseif not args[5] then
		MyColor=Color(tonumber(args[2]),tonumber(args[3]),tonumber(args[4]),255)
	else
		MyColor=Color(tonumber(args[2]),tonumber(args[3]),tonumber(args[4]),tonumber(args[5]))
	end
	keywords[args[1]]=MyColor
end

cmd.NoDraw=function(player, cmd, args, str)
for i,v in pairs(keywords) do
		if string.match(i,args[1],0) then
			if SystemOnline then
				for _, ent in pairs(ents.GetAll()) do 
					if IsValid(ent) and (isKeyed(ent:GetClass())) then
						ent:SetMaterial("")
						ent:SetColor(Color(255,255,255,255))
					end
				end
			end
			say("Removing "..i.." from draw list.")
			keywords[i]=nil
		end
	end
end
cmd.List=function(player, cmd, args, str)
	local mywords={}
	for i,v in pairs(keywords) do table.insert(mywords,i) end
	print("Keywords: "..table.concat(mywords,", "))
	print("Tracers: "..table.concat(tracers,", "))
	local Tracknames={}
	local Adminnames={}
	for i,v in pairs(admins) do
		table.insert(Adminnames,v:GetName())
	end
	for i,v in pairs(Tracking) do
		table.insert(Tracknames,v:GetName())
	end
	print("Admins: "..table.concat(Adminnames,", "))
	print("Tracking: "..table.concat(Tracknames,", "))
end
cmd.Bad=function(player, cmd, args, str)
	local Players={}
	for _,v in pairs(ents.GetAll()) do
		if v:GetClass()=="player" then
			table.insert(Players,v)
		end
	end
	for i, v in pairs(Players) do
		if string.match(string.lower(v:GetName()),string.lower(args[1])) then
			say("Added "..v:GetName().." to baddy list.")
			table.insert(admins,v)
		end
	end
end
cmd.Nobad=function(player, cmd, args, str)
	for i,v in pairs(admins) do
		if string.match(string.lower(v:GetName()),string.lower(args[1]),0) then
			say("Removed "..v:GetName().." from baddy list.")
			table.remove(admins,i)
		end
	end
end

cmd.Track=function(player, cmd, args, str)
	local Players={}
	for _,v in pairs(ents.GetAll()) do
		if v:GetClass()=="player" then
			table.insert(Players,v)
		end
	end
	for i, v in pairs(Players) do
		if string.match(string.lower(v:GetName()),string.lower(args[1])) then
			say("Added "..v:GetName().." to tracking list.")
			table.insert(Tracking,v)
		end
	end
end
cmd.Notrack=function(player, cmd, args, str)
	for i,v in pairs(Tracking) do
		if string.match(string.lower(v:GetName()),string.lower(args[1]),0) then
			say("Removed "..v:GetName().." from tracking list.")
			table.remove(Tracking,i)
		end
	end
end
cmd.DownDist=function(player, cmd, args, str)
	DownDist=tonumber(args[1])
end
concommand.Add("dotrace",cmd.AddTracer)
concommand.Add("notrace",cmd.NoTracer)
concommand.Add("draw",cmd.Draw)
concommand.Add("nodraw",cmd.NoDraw)
concommand.Add("list",cmd.List)
concommand.Add("bad",cmd.Bad)
concommand.Add("nobad",cmd.Nobad)
concommand.Add("track",cmd.Track)
concommand.Add("notrack",cmd.Notrack)
concommand.Add("downdist",cmd.DownDist)
RunConsoleCommand("cl_showpos",1)

--Chat McSpammening-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
cmd.Dicks={"You motherfucking piece of shit!","You're retarded!","How do I scope as australian long-range?","R U A WIZARD?","BAN ME NIGGERS!","BAN ME BAN ME BAN ME!","YOU DICKS!","WHORE!","BITCH!","SLUT!","TRAIN WRECK!","KEEP CRYING!","SUCK A PIXIE DICK BITCHES!","8==D",
"YOU SUCK!","FUCK YOU!","DIE IN A FIRE!","DOIN' YOUR MOM!","NOT A HACK AT ALL!","SORCERERERY!","DICKS!","ERECTION!","PENIS!","THE HOLE IS CUMMING!","BURN IN HELL!","I HATE ALL OF YOU!","HACKERS!","NIGGER!","NIGGER NIGGER NIGGER!","NIGGERTASTIC!",
"OMG GARRYSMOD IS SO KOOL GUISE!11!1!","I WIN EVERYTIME!"}
CurrentErect=1
cmd.erect=function()
	local erection=""
	CurrentErect=CurrentErect+1
	for I=1, math.random(1,5) do
		erection=erection..cmd.Dicks[math.random(#cmd.Dicks)].." "
	end
	return string.upper(erection)
end
cmd.DICKS=function()
	if not on["Burn"] then return end
	RunConsoleCommand("say","/ooc "..cmd.erect())
	timer.Simple(0.5,cmd.DICKS)
end
concommand.Add("sh_burnthejews",cmd.DICKS)