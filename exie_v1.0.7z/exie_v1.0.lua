if( SERVER ) then return end

local EX = {}
EX.commands	= {}

EX.gcv = GetConVar
EX.gcvn = GetConVarNumber
EX.cccv	= CreateClientConVar
EX.ecc = engineConsoleCommand
EX.rcc = RunConsoleCommand
EX.acc = concommand.Add
EX.print = print
EX.hook = hook.Add
EX.CV = table.Copy( cvars )
EX.S  = table.Copy( sql )
EX.MsgN = MsgN




EX.cvars = {
        { "EXIE_esp", 1,},
		{ "EXIE_espslider", 3000,},
	    { "EXIE_Bhop", 0,},
        { "EXIE_xhair", 0,},
        { "EXIE_norecoil", 1,},
        { "EXIE_trigger", 0,},
        { "EXIE_HitMarker", 1,},
        { "EXIE_TTT", 0,},
		{ "EXIE_Esp_Admin", 1,},
		{ "EXIE_Rp_Esp", 0,},
		{ "EXIE_Line", 0,},
		{ "EXIE_AntiGag", 1,},
		{ "EXIE_traitor", 1,},
		{ "EXIE_wireframe", 0,},
		{ "EXIE_chams", 0,},
		{ "EXIE_showspec", 1,},
		{ "EXIE_thirdslider", 70,},
		{ "EXIE_Iplog", 1,}
	}
EX.tvars = {}
EX.sqlite = {}
EX.funcs = {}

function sql.TableExists( tbl )
        if( tbl == "EXIE_Options" ) then return false end
        return EX.S.TableExists( tbl )   
end

if( !EX.S.TableExists("EXIE_Options") ) then
        EX.S.Query("CREATE TABLE EXIE_Options( Option varchar(255), Value varchar(255), PRIMARY KEY(Option) )")
end
 
function EX.sqlite.SetVar( option, value )
        EX.S.Query( string.format("REPLACE INTO EXIE_Options ( Option, Value ) VALUES ( '%s', '%s' )", tostring( option ), tostring( value ) ) )
end

 
function EX.sqlite.GetVar( option )
        local tab = EX.S.Query("SELECT * FROM EXIE_Options") or {}
        for k, v in pairs( tab ) do
                if( v.Option == option ) then
                        return v.Value
                end
        end
end

for k, v in pairs( EX.cvars ) do
        CreateConVar( v[1], EX.sqlite.GetVar( v[1] ) or v[2], true, false )
        EX.tvars[v[1]] = type( v[1] ) == "number" && GetConVarNumber( v[1] ) || GetConVarString( v[1] )
        EX.CV.AddChangeCallback( v[1], function( cvar, old, new )
        EX.tvars[v[1]] = new
		EX.sqlite.SetVar( v[1], new )

		end )
end
 
function EX.funcs.GetCVNum( cvar )
        return tonumber( EX.tvars[cvar] or 0 )
end

local AllESPEntities = {"pot","shroom","weapon_rp_ak47","weapon_rp_uzi" }
local draw = draw
local team = team
local player = player
local convar = EX.cccv( "EXIE_glow", "0", true )
local teamcolors = EX.cccv( "EXIE_teamcolors", "1", true )
local passes = EX.cccv( "EXIE_passes", "2", true )
local EXIEThirdPerson = EX.cccv("EXIE_thirdperson", "1", true)

function QuickESP()
if ( EX.funcs.GetCVNum("EXIE_esp") != 1 ) then return end
 for k,v in pairs(player.GetAll()) do
      if v!=LocalPlayer() and v:IsValid() and v:GetPos():Distance(LocalPlayer():GetPos()) < EX.gcvn( "EXIE_espslider" ) then
         local pos = v:GetPos() + Vector(0,0,70)
         pos = pos:ToScreen()
         local cwep = "None"
         if v:GetActiveWeapon() and v:GetActiveWeapon():IsValid() then cwep = v:GetActiveWeapon():GetClass() end
         draw.SimpleTextOutlined( tostring(v:GetName()), "Default", pos.x, pos.y, team.GetColor(v:Team()), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, Color(0,0,0) )
         draw.SimpleTextOutlined( "W: " .. cwep .. " | Health: " .. v:Health(), "DefaultSmall", pos.x, pos.y+15,team.GetColor(v:Team()) , TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, Color(0,0,0) )
              
	 end
   end
   for k,v in pairs(ents.GetAll()) do
      if v:IsValid() and table.HasValue(AllESPEntities, string.lower(v:GetClass())) then
         local pos = v:GetPos() + Vector(0,0,5)
         pos = pos:ToScreen()
         draw.SimpleTextOutlined( tostring(v:GetClass()), "Uibold", pos.x, pos.y, Color(255,0,0), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, Color(0,0,0) )
      end
   end
 end

EX.hook("HUDPaint","Quick ESP" ,QuickESP)


------------------------------------------------------------------------
------------------------------------------------------------------------
------------------------------------------------------------------------

local MaterialBlurX = Material( "pp/blurx" )
local MaterialBlurY = Material( "pp/blury" )
local MaterialWhite = CreateMaterial( "WhiteMaterial", "VertexLitGeneric", {
    ["$basetexture"] = "color/white",
    ["$vertexalpha"] = "1",
    ["$model"] = "1",
} )
local MaterialComposite = CreateMaterial( "CompositeMaterial", "UnlitGeneric", {
    ["$basetexture"] = "_rt_FullFrameFB",
    ["$additive"] = "1",
} )
 
local RT1 = render.GetBloomTex0()
local RT2 = render.GetBloomTex1()
 
/*------------------------------------
    RenderGlow()
------------------------------------*/
local function RenderGlow( entity )
 
    render.SetStencilEnable( true )
    render.SetStencilFailOperation( STENCILOPERATION_KEEP )
    render.SetStencilZFailOperation( STENCILOPERATION_REPLACE )
    render.SetStencilPassOperation( STENCILOPERATION_REPLACE )
    render.SetStencilCompareFunction( STENCILCOMPARISONFUNCTION_ALWAYS )
    render.SetStencilWriteMask( 1 )
    render.SetStencilReferenceValue( 1 )
     
   
    cam.IgnoreZ( true )
        render.SetBlend( 0 )
            SetMaterialOverride( MaterialWhite )
                entity:DrawModel()
            SetMaterialOverride()
        render.SetBlend( 1 )
    cam.IgnoreZ( false )
     
    local w, h = ScrW(), ScrH()
     
    
    local oldRT = render.GetRenderTarget()
     
    render.SetRenderTarget( RT1 )
     
        render.SetViewPort( 0, 0, RT1:GetActualWidth(), RT1:GetActualHeight() )
         
        cam.IgnoreZ( true )
         
            render.SuppressEngineLighting( true )
             
            if entity:IsPlayer() then
             
                if teamcolors:GetBool() then
                    local color = team.GetColor( entity:Team() )
                    render.SetColorModulation( color.r/255, color.g/255, color.b/255 )
                else
                    local scale = math.Clamp( entity:Health() / 100, 0, 1 )
                    local r,g,b = (255 - scale * 255), (55 + scale * 200), (50)
                    render.SetColorModulation( r/255, g/255, b/255 )
                end
                 
            else
             
                render.SetColorModulation( 1, 165/255, 0 )
                 
            end
             
                SetMaterialOverride( MaterialWhite )
                    entity:DrawModel()
                SetMaterialOverride()
                 
            render.SetColorModulation( 1, 1, 1 )
            render.SuppressEngineLighting( false )
             
        cam.IgnoreZ( false )
         
        render.SetViewPort( 0, 0, w, h )
    render.SetRenderTarget( oldRT )
     
   
    render.SetStencilEnable( false )
 
end
 
/*------------------------------------
    RenderScene()
------------------------------------*/
EX.hook( "RenderScene", "ResetGlow", function( Origin, Angles )
 
    local oldRT = render.GetRenderTarget()
    render.SetRenderTarget( RT1 )
        render.Clear( 0, 0, 0, 255, true )
    render.SetRenderTarget( oldRT )
     
end )
 
/*------------------------------------
    RenderScreenspaceEffects()
------------------------------------*/
EX.hook( "RenderScreenspaceEffects", "CompositeGlow", function()
 
    MaterialBlurX:SetMaterialTexture( "$basetexture", RT1 )
    MaterialBlurY:SetMaterialTexture( "$basetexture", RT2 )
    MaterialBlurX:SetMaterialFloat( "$size", 2 )
    MaterialBlurY:SetMaterialFloat( "$size", 2 )
         
    local oldRT = render.GetRenderTarget()
     
    for i = 1, passes:GetFloat() do
     
    
        render.SetRenderTarget( RT2 )
        render.SetMaterial( MaterialBlurX )
        render.DrawScreenQuad()
 
        render.SetRenderTarget( RT1 )
        render.SetMaterial( MaterialBlurY )
        render.DrawScreenQuad()
         
    end
 
    render.SetRenderTarget( oldRT )
     
   
    render.SetStencilEnable( true )
    render.SetStencilReferenceValue( 0 )
    render.SetStencilTestMask( 1 )
    render.SetStencilCompareFunction( STENCILCOMPARISONFUNCTION_EQUAL )
    render.SetStencilPassOperation( STENCILOPERATION_ZERO )
     
   
    MaterialComposite:SetMaterialTexture( "$basetexture", RT1 )
    render.SetMaterial( MaterialComposite )
    render.DrawScreenQuad()
 
    render.SetStencilEnable( false )
     
end )
 
local playerheldweap = nil
 
EX.hook( "PostPlayerDraw", "RenderEntityGlow", function( ply )
 
    if !convar:GetBool() then return end
 
    if( ScrW() == ScrH() ) then return end
 
 
    if( OUTLINING_ENTITY ) then return end
    OUTLINING_ENTITY = true
     
    RenderGlow( ply )
     
    playerheldweap = ply:GetActiveWeapon()
     
    if IsValid( playerheldweap ) and playerheldweap:IsWeapon() then
        RenderGlow( playerheldweap )
    end
     
 
    OUTLINING_ENTITY = false
         
end )

--------------------------------------------------------------------------------
----------------------------------------------------------------------------------
-------------------------------------------------------------------------

local function FillRGBA(x,y,w,h,col)
    surface.SetDrawColor( col.r, col.g, col.b, col.a );
    surface.DrawRect( x, y, w, h );
end

local function DrawCrosshair()
    local w = ScrW() / 2;
    local h = ScrH() / 2;
    
    FillRGBA( w - 5, h, 11, 1, Color( 255, 0, 0, 255 ) );
    FillRGBA( w, h - 5, 1, 11, Color( 255, 0, 0, 255 ) );
end
function DrawXHair()
    if ( EX.funcs.GetCVNum("EXIE_xhair") != 1 ) then return end 
        DrawCrosshair();
    end

EX.hook( "HUDPaint", "DrawXHair", DrawXHair ); 



function Bunnyhop() 
if ( EX.funcs.GetCVNum("EXIE_Bhop") != 1 ) then return end
if input.IsKeyDown( KEY_SPACE ) then
if LocalPlayer():IsOnGround() then
EX.rcc("+Jump") 
timer.Create("Bhop",0.01, 0 ,function() EX.rcc("-Jump") end)

			end
		end
			end
				
EX.hook("Think", "Funkybunny", Bunnyhop)	



EX.hook("CalcView", "NoRecoil", function()
if ( EX.funcs.GetCVNum("EXIE_norecoil") != 1 ) then return end                
			local Wep = LocalPlayer():GetActiveWeapon()
                if (Wep.Primary) then Wep.Primary.Recoil = 0.0 end
                if (Wep.Secondary) then Wep.Secondary.Recoil = 0.0 end
       end)

WeaponTable = {"weapon_zm_pistol","weapon_ttt_wtester","weapon_zm_revolver","weapon_zm_molotov","weapon_zm_shotgun","weapon_ttt_m16","weapon_ttt_glock","weapon_zm_sledge","weapon_zm_rifle","weapon_zm_mac10"}

function TTTWeaponEsp() 
if ( EX.funcs.GetCVNum("EXIE_TTT") != 1 ) then return end
for k,v in pairs(ents.GetAll()) do
if ValidEntity(v) then
if table.HasValue(WeaponTable,v:GetClass()) and v:GetMoveType() != 0 then
Weaponscreenpot = v:GetPos():ToScreen()

draw.SimpleText(v:GetClass(),"DefaultSmall", Weaponscreenpot.x , Weaponscreenpot.y , Color(255,0,0,255) , TEXT_ALIGN_CENTER,TEXT_ALIGN_CENTER)
						end
					end
				end
					end
						

EX.hook("HUDPaint","TTTWeaponShow",TTTWeaponEsp)


PrinterTable = {"reg_money_printer","money_printer","platinum_printer","golden_printer","zz_money_printer","money_printer_commercial","money_printer_industrial"}

function MpExtraSp()
if ( EX.funcs.GetCVNum("EXIE_Rp_Esp") != 1 ) then return end
for k,v in pairs(ents.GetAll()) do
if ValidEntity(v) then
if table.HasValue(PrinterTable,v:GetClass()) then
local Pl = v:GetPos():ToScreen()
draw.SimpleText("Printer", "UiBold", Pl.x , Pl.y,Color(20,255,100,255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
					end
				end
			end
		end
	

	EX.hook("HUDPaint","MoneyMoney",MpExtraSp)


	
	function Trigger()
local Eye = LocalPlayer():GetEyeTrace().Entity
if ( EX.funcs.GetCVNum("EXIE_trigger") != 1 ) then return end
if On == 1 then
if (Eye:IsNPC() or Eye:IsPlayer()) then
EX.rcc("+Attack")
else
timer.Simple(0.50, function()
EX.rcc("-Attack")
			end)
		end
	end
		end


EX.hook("Think", "Test", Trigger)


function Hitmarker() 
if ( EX.funcs.GetCVNum("EXIE_HitMarker") != 1 ) then return end
local EyeEnt = LocalPlayer():GetEyeTrace().Entity
if EyeEnt:IsPlayer() then
if LocalPlayer():Health() > 0 then
if LocalPlayer():GetCurrentCommand():KeyDown(IN_ATTACK) then
if LocalPlayer():GetActiveWeapon():Clip1() > 0 then

surface.SetDrawColor( 50, 205, 50 )
surface.DrawLine(ScrW() / 2 - 5 , ScrH() / 2 - 5 , ScrW() / 2 - 15 , ScrH() / 2 - 15)
surface.DrawLine(ScrW() / 2 + 5 , ScrH() / 2 + 5 , ScrW() / 2 + 15, ScrH() / 2 + 15)
surface.DrawLine(ScrW() / 2 + 5 , ScrH() / 2 - 5 , ScrW() / 2 + 15 , ScrH() / 2 - 15)
surface.DrawLine(ScrW() / 2 - 5 , ScrH() / 2 + 5 , ScrW() / 2 - 15 , ScrH() / 2 + 15)
					end
				end
			end
				end
					end
						
						
EX.hook("HUDPaint","DisplayShittyHitmarker",Hitmarker)

function Barrelhax() 
if ( EX.funcs.GetCVNum("EXIE_Line") != 1 ) then return end
for k,v in pairs(player.GetAll()) do
if (v!=LocalPlayer() and v:Alive() and v:IsPlayer()) then
cam.Start3D( EyePos() , EyeAngles())
render.SetMaterial( Material( "cable/physbeam" ) )
render.DrawBeam(v:GetBonePosition(v:LookupBone("ValveBiped.Bip01_Head1")) , v:GetEyeTrace().HitPos , 5, 0, 0, Color(0, 100, 0 ))
cam.End3D()
			end
		end
	end
		
 
 EX.hook("HUDPaint","Specline", Barrelhax)

function Antigag()
if EXIEAnti:GetBool() then
hook.Remove( "PlayerBindPress", "ULXGagForce" ) timer.Destroy( "GagLocalPlayer")
	end
end

TraitorTable = {"weapon_ttt_c4", "weapon_ttt_knife", "weapon_ttt_phammer", "weapon_ttt_sipistol", "weapon_ttt_flaregun", "weapon_ttt_push", "weapon_ttt_radio"}

function Traitorfind()
if ( EX.funcs.GetCVNum("EXIE_traitor") != 1 ) then return end
for k,v in pairs(ents.GetAll()) do
if ValidEntity(v) then
if table.HasValue(TraitorTable,v:GetClass()) then
local Pl = v:GetPos():ToScreen()
draw.SimpleText("Traitor", "UiBold", Pl.x , Pl.y,Color(255,0,0), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
					end
				end
			end
		end
	

	EX.hook("HUDPaint","TraitorTTT",Traitorfind)

local mat = Material( "XE/EXIEwireframe")

function wire() 
if ( EX.funcs.GetCVNum("EXIE_wireframe") != 1 ) then return end
for k,v in pairs(player.GetAll()) do
if (v!=LocalPlayer and v:Alive() and v:IsPlayer() and v:Team() != TEAM_SPECTATOR ) then
if v:IsValid() and v:GetPos():Distance(LocalPlayer():GetPos()) < EX.gcvn( "EXIE_espslider" ) then
local drawc = Color(0, 0, 0)
	drawc = team.GetColor(v:Team())
render.SetColorModulation( (drawc.r/255), (drawc.g/255), (drawc.b/255) )
cam.Start3D( EyePos() , EyeAngles() ) 
cam.IgnoreZ(true)
cam.StartMaterialOverride( mat )
v:DrawModel()
cam.IgnoreZ(false)
cam.StartMaterialOverride( 0 )
cam.End3D()
				end
			end
		end
	end

		
EX.hook("HUDPaint","wireframe",wire)

function Chams() 
if ( EX.funcs.GetCVNum("EXIE_chams") != 1 ) then return end
for k,v in pairs(player.GetAll()) do
if (v!=LocalPlayer and v:Alive() and v:IsPlayer() and v:Team() != TEAM_SPECTATOR ) then
if v:IsValid() and v:GetPos():Distance(LocalPlayer():GetPos()) < EX.gcvn( "EXIE_espslider" ) then
local drawc = Color(0, 0, 0)
	drawc = team.GetColor(v:Team())
render.SetColorModulation( (drawc.r/255), (drawc.g/255), (drawc.b/255) )
cam.Start3D( EyePos() , EyeAngles() ) 
cam.IgnoreZ(true)
cam.StartMaterialOverride( mat )
v:DrawModel()
cam.IgnoreZ(false)
cam.StartMaterialOverride( 0 )
cam.End3D()
					end
				end
			end
		end
	
	
EX.hook("HUDPaint","Chamers",Chams)


---------------------------------------
---------------------------------------




    EX.hook("HUDPaint", "shit", function()
if ( EX.funcs.GetCVNum("EXIE_showspec") != 1 ) then return end
			local spectatePlayers = {}
            local x = 0
            for k,v in pairs(player.GetAll()) do
                    if v:GetObserverTarget() == LocalPlayer() then
                            table.insert(spectatePlayers, v:Name())
                    end
            end
            local textLength = surface.GetTextSize(table.concat(spectatePlayers) ) / 3
            draw.RoundedBox(1, ScrW() - 350, ScrH() - ScrH() + 35, 150, 30 + textLength, Color(255, 165, 0))
            draw.SimpleText("Spectators", "ScoreboardText", ScrW() - 310, ScrH() - ScrH() + 37, Color(255, 165, 0))
            draw.SimpleText("Spectators", "ScoreboardText", ScrW() - 310, ScrH() - ScrH() + 36, Color(0,0,0,150))
     
            for k, v in pairs(spectatePlayers) do
            draw.SimpleText(v, "ScoreboardText", ScrW() - 315, ScrH() - ScrH() + 35 + x, Color(0,0,0,150))
            x = x + 15
        end
    
end)

EX.hook("HUDPaint", "Adminss", function()
			if ( EX.funcs.GetCVNum("EXIE_Esp_Admin") != 1 ) then return end
				local admins = {}
                local int = 0
                for k, v in ipairs( player.GetAll() ) do
                        if( v:IsAdmin() && v:IsSuperAdmin() ) then
                                table.insert( admins, v:Nick() .. " (SA)" )
                        elseif( v:IsAdmin() && !v:IsSuperAdmin() ) then
                                table.insert( admins, v:Nick() .. " (A)" )
                        end
                end
                local txtsize = surface.GetTextSize( table.concat( admins ) ) / 3
                draw.RoundedBox( 1, ScrW() - 180, ScrH() - ScrH() + 35, 150, 30 + txtsize, Color( 255, 165, 0 ) )
                draw.SimpleText("Admins", "ScoreboardText", ScrW() - 140, ScrH() - ScrH() + 36, Color( 0, 0, 0, 150 ) )
                for k, v in pairs( admins ) do
                        draw.SimpleText(v, "ScoreboardText", ScrW() - 140, ScrH() - ScrH() + 55 + int, Color( 0, 0, 0, 150 ) )
                        int = int + 15
	          
				
			   
        end
end)

EX.rcc("EXIE_thirdperson_toggle")

function Toggle_View()
if EXIEThirdPerson:GetBool() then
		
		EX.hook( "CalcView", "ShoulderView", ShoulderView )
		EX.hook( "ShouldDrawLocalPlayer", "ShouldDrawLocalPlayer", DrawLocalPlayer )
		
	else
	
		hook.Remove( "CalcView", "ShoulderView" )
		hook.Remove( "ShouldDrawLocalPlayer", "ShouldDrawLocalPlayer" )
	
	end
end

function ShoulderView( ply, pos, angles, fov )

if EXIEThirdPerson:GetBool() then

		local view = {}
		view.origin = pos - ( angles:Forward() * EX.funcs.GetCVNum("EXIE_thirdslider") ) + ( angles:Right() * 0 ) + (angles:Up() * 5 )
		view.angles = angles
		view.fov = fov

		return view
	
	end
end



function DrawLocalPlayer( ply )

	if EXIEThirdPerson:GetBool() then

		return true

	else

		return false

	end

end

EX.acc( "EXIE_thirdperson_toggle", Toggle_View )

if not file.Exists( "EXIE_logged_ips.txt" ) then file.Write( "EXIE_logged_ips.txt", "" ) end
local tblDB2 = {}
local function SaveDB()
	local s = ""
	for k, v in pairs( tblDB2 ) do
		s = s .. k .."'s IP Address is: " ..v.. " \n"
	end
	
		file.Write( "EXIE_logged_ips.txt", s )
end
local function LoadNHIP()
	local tbl2 = string.Explode( "\n", file.Read( "EXIE_logged_ips.txt" ) )
	tblDB2 = {}
	for k,v  in pairs( tbl2 ) do
		local sep2 = string.Explode( "'s IP Address is: ", v )
		if sep2 and table.getn( sep2 ) == 2 then
			tblDB2[sep2[1]] = sep2[2]
		end
	end
end
LoadNHIP()			
			
local function PlayerConnect( name, ip )
	
	tblDB2[ string.gsub( name, "'s IP Address is: ", "" ) ] = ip
	EX.print( "[EX] Displayed Player IP: " .. name .. "'s IP Address is " .. ip )
	SaveDB()
if ( EX.funcs.GetCVNum("EXIE_Iplog") != 1 ) then return end
	chat.AddText(
    Color(0,0,0), "[EX] ",
    Color(255, 165, 0), "Displayed ",
    Color(255, 165, 0), "Player ",
	Color(255, 165, 0), "IP: ",
	Color(255, 165, 0), tostring( name .. "'s IP Address = " .. ip .. "." ) )
	end


EX.hook( "PlayerConnect", "PlayerConnect12", PlayerConnect )



 
local IsSpectating = false
local holding = {}
local SpectatePosition = Vector(0,0,0)
local CanMove = true 
local SaveAngles = Angle(0,0,0) // Only used when spectating an object
local SpecEnt = LocalPlayer()
local speed = 15
local SpecEntSaveAngle = Angle(0,0,0)
local camsdata = {}
local camsize = EX.cccv("Exie_SpecScreenSize", 5, true, false)
local LockMouse = EX.cccv("Exie_SpecLockMouse", 0, true, false)
local SpecSpeed = EX.cccv("Exie_NoclipSpeed", 50, true, false)
local ThPDist = 100
local SpecAng = Angle(0,0,0)
local IsPlayer = true



local function BindPresses(ply, bind, pressed)
	local use = LocalPlayer():KeyDown(IN_USE)
	if (string.find(bind, "forward") or string.find(bind, "moveleft") or string.find(bind, "moveright") or string.find(bind, "back") or string.find(bind, "jump") or string.find(bind, "duck")) and not use then
		holding[string.sub(bind, 2)] = pressed
		return true 
	elseif string.find(bind, "speed") and pressed and not use then
		if speed <= 15 then speed = 50
		elseif speed == 50 then speed = 15
		end
		return true
	elseif string.find(bind, "walk") and pressed and not use then
		if speed ~= 2 then speed = 2
		elseif speed == 2 then speed = 15
		end
		return true
	elseif string.find(bind, "invprev") and pressed and not use then
		ThPDist = ThPDist - 10
		return true
	elseif string.find(bind, "invnext") and pressed and not use then
		ThPDist = ThPDist + 10
		return true
	elseif string.find(bind, "menu") and not string.find(bind, "context") and pressed then
		if not use then
			OptionsDerma()
			fnotify("Hold use + Q to open the spawnmenu while spectating")
			return true
		end
	elseif string.find(bind, "attack2") and pressed and not use then
		if SpecEnt and SpecEnt:IsPlayer() then
			IsPlayer = not IsPlayer
			return true
		end
	elseif string.find(bind, "reload") and pressed and not use then
		if CanMove then
			local Tracey = {}
			Tracey.start = SpectatePosition
			Tracey.endpos = SpectatePosition + SpecAng:Forward() * 100000000
			Tracey.filter = LocalPlayer() // in case you're aiming at yourself... IF that's even possible but I can't be arsed to test that
			local trace = util.TraceLine(Tracey)
			
			
		elseif not CanMove then
			CanMove = true
			SpecEnt:SetNoDraw(false)
			if IsPlayer then
				if SpecEnt:IsPlayer() then
					SpectatePosition = SpecEnt:GetShootPos()
					SpecAng = SpecEnt:EyeAngles()
				else
					SpectatePosition = SpecEnt:GetPos()
					SpecAng = SpecEnt:EyeAngles()
				end
			end
			fnotify("Stopped spectating object")
		end
		return true
	end
end

local function DoMove(what)
	if CanMove then
		if string.find(what, "forward") then 
			SpectatePosition = SpectatePosition + SpecAng:Forward() * speed * RealFrameTime() * SpecSpeed:GetInt()
		elseif string.find(what, "back") then
			SpectatePosition = SpectatePosition - SpecAng:Forward() * speed * RealFrameTime() * SpecSpeed:GetInt()
		elseif string.find(what, "moveleft") then
			SpectatePosition = SpectatePosition - SpecAng:Right() * speed * RealFrameTime() * SpecSpeed:GetInt()
		elseif string.find(what, "moveright") then
			SpectatePosition = SpectatePosition + SpecAng:Right() * speed * RealFrameTime() * SpecSpeed:GetInt()
		elseif string.find(what, "jump") then
			SpectatePosition = SpectatePosition + Vector(0,0,speed * RealFrameTime() * SpecSpeed:GetInt())
		elseif string.find(what, "duck") then
			SpectatePosition = SpectatePosition - Vector(0,0,speed * RealFrameTime() * SpecSpeed:GetInt())
		end
	elseif not CanMove then
		if string.find(what, "forward") then // todo
			SaveAngles = SaveAngles + Angle(0.1 * speed * RealFrameTime() * SpecSpeed:GetInt(), 0, 0)
		elseif string.find(what, "back") then
			SaveAngles = SaveAngles - Angle(0.1 * speed * RealFrameTime() * SpecSpeed:GetInt(), 0, 0)
		elseif string.find(what, "moveleft") then
			SaveAngles = SaveAngles - Angle(0, 0.1 * speed * RealFrameTime() * SpecSpeed:GetInt(), 0)
		elseif string.find(what, "moveright") then
			SaveAngles = SaveAngles + Angle(0, 0.1 * speed * RealFrameTime() * SpecSpeed:GetInt(), 0)
		elseif string.find(what, "jump") then
			ThPDist = ThPDist + 0.5 * speed * RealFrameTime() * SpecSpeed:GetInt()
			if ThPDist > 10 then
				SpecEnt:SetNoDraw(false)
			end
		elseif string.find(what, "duck") and ThPDist > 3 then
			ThPDist = ThPDist - 0.5 * speed * RealFrameTime() * SpecSpeed:GetInt()
			if ThPDist <= 10 then
				SpecEnt:SetNoDraw(true)
			end
		end
	end
end

local function Thinks()
	for k,v in pairs(holding) do
		if v then
			DoMove(k)
		end
	end
end

local PLAYER = FindMetaTable("Player")
PLAYER.FalcooldEyeAngles = PLAYER.FalcooldEyeAngles or PLAYER.GetEyeTrace
function PLAYER:GetEyeTrace()
	if IsSpectating and CanMove and self == LocalPlayer() then
		local trace = {}
		trace.start = SpectatePosition
		trace.endpos = SpectatePosition + SpecAng:Forward() * 1000000
		trace.filter = LocalPlayer()
		traceline = util.TraceLine(trace)
		return traceline
	end
	return self:FalcooldEyeAngles()
end

local OldUtilPlayerTrace = util.GetPlayerTrace
function util.GetPlayerTrace(ply)
	if IsSpectating and ply == LocalPlayer() then
		local trace = {}
		trace.start = SpectatePosition
		trace.endpos = SpectatePosition + SpecAng:Forward() * 1000000
		trace.filter = LocalPlayer()
		return trace
	end
	return OldUtilPlayerTrace(ply)
end

local function CalcViews(ply, origin, angles, fov)
	local view = {}
	if not CanMove and not ValidEntity(SpecEnt) then
		CanMove = true
	end
	view.vm_origin = Vector(0,0,-13000)
	if not CanMove and not IsPlayer then
		local ang1 = SpecEnt:EyeAngles()
		local ang
		if SpecEnt:IsPlayer() then
			ang = Angle(ang1.p - ang1.p - ang1.p, ang1.y, ang1.r) - SpecEntSaveAngle
		else
			ang = SpecEntSaveAngle
		end
		SpectatePosition = SpecEnt:GetPos() - (SaveAngles + ang ):Forward() * ThPDist
		SpecAng = (SpecEnt:GetPos() - SpectatePosition):Angle()
		view.angles = SpecAng
		view.origin = SpectatePosition
		view.vm_origin = SpectatePosition
	elseif not CanMove and IsPlayer then
		view.angles = SpecEnt:EyeAngles()
		if SpecEnt:IsPlayer() then
			view.origin = SpecEnt:GetShootPos()
		else
			view.origin = SpecEnt:GetPos()
		end
		view.vm_origin = LocalPlayer():GetShootPos()
		SpecEnt:SetNoDraw(true)
	elseif CanMove then
		view.angles = SpecAng
		view.origin = SpectatePosition
		view.vm_origin = SpectatePosition
	end
	return view
end



local safeview = _R.CUserCmd.SetViewAngles
local function MouseStuff(u)
	if not CanMove and SpecEnt:IsValid() and SpecEnt:IsPlayer() and SpecEnt ~= LocalPlayer() then
		local trace = SpecEnt:GetEyeTrace().HitPos
		safeview(u, (trace - LocalPlayer():GetShootPos()):Angle())
	elseif not CanMove and SpecEnt:IsValid() and not SpecEnt:IsPlayer() and LockMouse:GetInt() ~= 1 then
		SaveAngles.p = SaveAngles.p + u:GetMouseY() * 0.025
		SaveAngles.y = SaveAngles.y - u:GetMouseX() * 0.025
		local trace = {}
		trace.start = SpectatePosition
		trace.endpos = SpectatePosition + SpecAng:Forward() * 100000 
		trace.filter = LocalPlayer()
		local traceline = util.TraceLine(trace)
		local pos = traceline.HitPos
		safeview(u, (pos - LocalPlayer():GetShootPos()):Angle())
	elseif CanMove then
		local trace = {}
		trace.start = SpectatePosition
		trace.endpos = SpectatePosition + SpecAng:Forward() * 100000 
		trace.filter = LocalPlayer()
		local traceline = util.TraceLine(trace)
		local pos = traceline.HitPos
		SpecAng.p = math.Clamp(SpecAng.p + u:GetMouseY() * 0.025, -90, 90)
		SpecAng.y = SpecAng.y + u:GetMouseX() * -0.025
		safeview(u, (pos - LocalPlayer():GetShootPos()):Angle())
	end
end

local function Toggle()
	if IsSpectating then
		IsSpectating = false
		CanMove = true
		if ValidEntity(SpecEnt) then
			SpecEnt:SetNoDraw(false)
			SpecEnt = LocalPlayer()
		end
		speed = 15
		holding = {}
		hook.Remove("CreateMove", "EXSpecate")
		hook.Remove("CalcView", "EXSpecate")
		hook.Remove("Think", "EXSpecate")
		hook.Remove("PlayerBindPress", "EXSpecate")
		hook.Remove("ShouldDrawLocalPlayer", "EXSpecate")
	else
		IsSpectating = true
		SpectatePosition = LocalPlayer():GetShootPos()
		SpecAng = LocalPlayer():EyeAngles()
		-- HOOKS:
		EX.hook("CreateMove", "EXSpecate", MouseStuff)
		EX.hook("CalcView", "EXSpecate", CalcViews)
		EX.hook("Think", "EXSpecate", Thinks)
		EX.hook("PlayerBindPress", "EXSpecate", BindPresses)
		EX.hook("ShouldDrawLocalPlayer", "EXSpecate", function() return true end)
	end
end
EX.acc("exie_spectate", Toggle)



--------------------------------------------------------------------------------
--------------------------------------------------------------------------------
--------------------------------------------------------------------------------

local oHTTP = table.Copy( http )

BaseFrame = vgui.Create("DFrame")
BaseFrame:SetSize( 330 , 200 )
BaseFrame:SetPos( ScrW() / 2 - 200 , ScrH() / 2 - 175 )
BaseFrame:SetTitle("EXIEBot")
BaseFrame:ShowCloseButton( false )
BaseFrame:SetVisible ( false )
BaseFrame:MakePopup()
 function BaseFrame:Paint()
                draw.RoundedBox( 0, 0, 0, self:GetWide(), self:GetTall(), Color( 0, 0 ,0 ,220 ) )
        end
 


local Sheet = vgui.Create("DPropertySheet" , BaseFrame)
Sheet:SetSize( 320 , 170 )
Sheet:SetPos( 5 , 25 )
function Sheet:Paint()
                draw.RoundedBox( 0, 0, 0, self:GetWide(), self:GetTall(), Color( 255, 165, 0 ) )
        end
local ThTab = vgui.Create("DLabel")
ThTab:SetParent( Sheet )
ThTab:SetPos( 0 , 10 )
ThTab:SetText("")
	
local FirstTab = vgui.Create("DLabel")
FirstTab:SetParent( Sheet )
FirstTab:SetPos( 0 , 10 )
FirstTab:SetText("")

local SecTab = vgui.Create("DLabel")
SecTab:SetParent( Sheet )
SecTab:SetPos( 0 , 10 )
SecTab:SetText("") 

local InfoTab = vgui.Create("DLabel")
InfoTab:SetParent( Sheet )
InfoTab:SetPos( 0 , 10 )
InfoTab:SetText("")

local CHL = vgui.Create("DLabel")
CHL:SetParent( Sheet )
CHL:SetPos( 0 , 10 )
CHL:SetText("")




---- Time ----

local Time = vgui.Create("DLabel")
Time:SetParent( InfoTab )
Time:SetPos( 250 , 10 )
Time:SetTextColor( Color(0 , 0 , 0 , 255 ) )
Time:SetText(tostring( os.date("%I") ) )

local Time2 = vgui.Create("DLabel")
Time2:SetParent( InfoTab )
Time2:SetPos( 267 , 10 )
Time2:SetTextColor( Color(0 , 0 , 0 , 255 ) )
Time2:SetText(tostring( os.date("%M") ) )

local Time3 = vgui.Create("DLabel")
Time3:SetParent( InfoTab )
Time3:SetPos( 263.5 , 10 )
Time3:SetTextColor( Color(0 , 0 , 0 , 255 ) )
Time3:SetText(":")

local Time4 = vgui.Create("DLabel")
Time4:SetParent( InfoTab )
Time4:SetPos( 280 , 10 )
Time4:SetTextColor( Color(0 , 0 , 0 , 255 ) )
Time4:SetText( tostring( os.date( "%p" ) ) )


// DLabels

local Label1 = vgui.Create("DLabel")
Label1:SetParent( FirstTab )
Label1:SetPos ( 30 , 10 ) 
Label1:SetTextColor( Color ( 0 , 0 , 0 , 255) )
Label1:SetText( "Esp" )
Label1:SizeToContents()

local Label2 = vgui.Create("DLabel")
Label2:SetParent( SecTab )
Label2:SetPos ( 30 , 10 ) 
Label2:SetTextColor( Color ( 0 , 0 , 0 , 255) )
Label2:SetText( "Other / Misc" )
Label2:SizeToContents()

local Label3 = vgui.Create("DLabel")
Label3:SetParent( InfoTab )
Label3:SetPos ( 30 , 10 ) 
Label3:SetTextColor( Color ( 0 , 0 , 0 , 255) )
Label3:SetText( "InfoTab" )
Label3:SizeToContents()

local Label4 = vgui.Create("DLabel")
Label4:SetParent( ThTab )
Label4:SetPos ( 30 , 10 ) 
Label4:SetTextColor( Color ( 0 , 0 , 0 , 255) )
Label4:SetText( "AimBot" )
Label4:SizeToContents()

// Regular Check Boxes

local Box1 = vgui.Create( "DCheckBoxLabel")
Box1:SetText( "ESP" )
Box1:SetConVar( "EXIE_esp" ) 
Box1:SetParent( FirstTab )
Box1:SetPos( 20 , 30 )
Box1:SetValue( 1 )
Box1:SetTextColor( Color(0 , 0 , 0 , 255 ) )
Box1:SizeToContents() 

local Box2 = vgui.Create( "DCheckBoxLabel")
Box2:SetText( "Glow" )
Box2:SetPos( 20 , 50 )
Box2:SetParent( FirstTab )
Box2:SetConVar( "EXIE_glow" ) 
Box2:SetValue( 0 )
Box2:SetTextColor( Color(0 , 0 , 0 , 255 ) )
Box2:SizeToContents() 

local Box4 = vgui.Create( "DCheckBoxLabel")
Box4:SetText( "Show Admins" )
Box4:SetConVar( "EXIE_esp_admin" ) 
Box4:SetValue( 1 )
Box4:SetPos( 20 , 70 )
Box4:SetParent( FirstTab )
Box4:SetTextColor( Color(0 , 0 , 0 , 255 ) )
Box4:SizeToContents() 

local Box5 = vgui.Create( "DCheckBoxLabel")
Box5:SetText( "Xhair" )
Box5:SetConVar( "EXIE_xhair" ) 
Box5:SetValue( 0 )
Box5:SetPos( 20 , 90 )
Box5:SetParent( FirstTab )
Box5:SetTextColor( Color(0 , 0 , 0 , 255 ) )
Box5:SizeToContents() 

local Box5 = vgui.Create( "DCheckBoxLabel")
Box5:SetText( "TTT Weapons" )
Box5:SetConVar( "EXIE_ttt" ) 
Box5:SetValue( 0 )
Box5:SetPos( 20 , 110 )
Box5:SetParent( FirstTab )
Box5:SetTextColor( Color(0 , 0 , 0 , 255 ) )
Box5:SizeToContents() 

local Box12 = vgui.Create( "DCheckBoxLabel")
Box12:SetText( "MoneyPrinter ESP" )
Box12:SetConVar( "EXIE_Rp_Esp" ) 
Box12:SetParent( FirstTab )
Box12:SetPos( 150 , 30 )
Box12:SetValue( 0 )
Box12:SetTextColor( Color(0 , 0 , 0 , 255 ) )
Box12:SizeToContents() 

local Box8 = vgui.Create( "DCheckBoxLabel")
Box8:SetText( "Trigger Bot" )
Box8:SetConVar( "EXIE_trigger" ) 
Box8:SetValue( 0 )
Box8:SetPos( 20 , 110 )
Box8:SetParent( ThTab )
Box8:SetTextColor( Color(0 , 0 , 0 , 255 ) )
Box8:SizeToContents() 

local Box9 = vgui.Create( "DCheckBoxLabel")
Box9:SetText( "Bhop" )
Box9:SetConVar( "EXIE_Bhop" ) 
Box9:SetValue( 0 )
Box9:SetPos( 20 , 30 )
Box9:SetParent( SecTab )
Box9:SetTextColor( Color(0 , 0 , 0 , 255 ) )
Box9:SizeToContents() 

local Box10 = vgui.Create( "DCheckBoxLabel")
Box10:SetText( "No Recoil" )
Box10:SetConVar( "EXIE_norecoil" )
Box10:SetPos( 150 , 30 )
Box10:SetParent( ThTab ) 
Box10:SetValue( 1 )
Box10:SetTextColor( Color(0 , 0 , 0 , 255 ) )
Box10:SizeToContents() 

local Box11 = vgui.Create( "DCheckBoxLabel")
Box11:SetText( "Hit Marker" )
Box11:SetConVar( "EXIE_hitmarker" ) 
Box11:SetPos( 20 , 50 )
Box11:SetParent( SecTab )
Box11:SetValue( 1 )
Box11:SetTextColor( Color(0 , 0 , 0 , 255 ) )
Box11:SizeToContents() 

local Box13 = vgui.Create( "DCheckBoxLabel")
Box13:SetText( "Laser Eyes" )
Box13:SetConVar( "EXIE_line" ) 
Box13:SetPos( 20 , 70 )
Box13:SetParent( SecTab )
Box13:SetValue( 0 )
Box13:SetTextColor( Color(0 , 0 , 0 , 255 ) )
Box13:SizeToContents() 

local Box14 = vgui.Create( "DCheckBoxLabel")
Box14:SetText( "ULXGag Bypass" )
Box14:SetConVar( "EXIE_AntiGag" ) 
Box14:SetPos( 150 , 30 )
Box14:SetParent( SecTab )
Box14:SetValue( 1 )
Box14:SetTextColor( Color(0 , 0 , 0 , 255 ) )
Box14:SizeToContents() 

local Box15 = vgui.Create( "DCheckBoxLabel")
Box15:SetText( "Traitor Finder" )
Box15:SetConVar( "EXIE_traitor" ) 
Box15:SetParent( FirstTab )
Box15:SetPos( 150 , 50 )
Box15:SetValue( 1 )
Box15:SetTextColor( Color(0 , 0 , 0 , 255 ) )
Box15:SizeToContents() 

local Box16 = vgui.Create( "DCheckBoxLabel")
Box16:SetText( "Wireframe" )
Box16:SetConVar( "EXIE_wireframe" ) 
Box16:SetParent( FirstTab )
Box16:SetPos( 150 , 70 )
Box16:SetValue( 0 )
Box16:SetTextColor( Color(0 , 0 , 0 , 255 ) )
Box16:SizeToContents() 

local Box17 = vgui.Create( "DCheckBoxLabel")
Box17:SetText( "Chams" )
Box17:SetConVar( "EXIE_chams" ) 
Box17:SetParent( FirstTab )
Box17:SetPos( 150 , 90 )
Box17:SetValue( 0 )
Box17:SetTextColor( Color(0 , 0 , 0 , 255 ) )
Box17:SizeToContents() 

local Box18 = vgui.Create( "DCheckBoxLabel")
Box18:SetText( "Show Spec" )
Box18:SetConVar( "EXIE_showspec" ) 
Box18:SetParent( SecTab )
Box18:SetPos( 150 , 50 )
Box18:SetValue( 1 )
Box18:SetTextColor( Color(0 , 0 , 0 , 255 ) )
Box18:SizeToContents()

local Box19 = vgui.Create( "DCheckBoxLabel")
Box19:SetText( "Third Person" )
Box19:SetConVar( "EXIE_thirdperson" ) 
Box19:SetParent( SecTab )
Box19:SetPos( 150 , 70 )
Box19:SetValue( 1 )
Box19:SetTextColor( Color(0 , 0 , 0 , 255 ) )
Box19:SizeToContents()

local NumSlider1 = vgui.Create( "DNumSlider" )
NumSlider1:SetPos( 150,105 )
NumSlider1:SetText( "" )
NumSlider1:SetParent( FirstTab )
NumSlider1:SetSize( 140, 90 ) 
NumSlider1:SetMin( 0 ) 
NumSlider1:SetMax( 50000 ) 
NumSlider1:SetDecimals( 0 ) 
NumSlider1:SetConVar( "EXIE_espslider" ) 

local Info3 = vgui.Create("DLabel")
Info3:SetParent( FirstTab )
Info3:SetPos( 160 , 105 )
Info3:SetTextColor( Color ( 0 , 0 , 0 , 255 ) )
Info3:SetSize( 200 , 20 )
Info3:SetText("Esp Distance")


local Box20 = vgui.Create( "DCheckBoxLabel")
Box20:SetText( "Chams" )
Box20:SetConVar( "EXIE_chams" ) 
Box20:SetParent( FirstTab )
Box20:SetPos( 150 , 90 )
Box20:SetValue( 0 )
Box20:SetTextColor( Color(0 , 0 , 0 , 255 ) )
Box20:SizeToContents() 

local Box21 = vgui.Create( "DCheckBoxLabel")
Box21:SetText( "Ignore SteamFriends" )
Box21:SetConVar( "EXIE_Aimbot_IgnoreSteam" ) 
Box21:SetParent( ThTab )
Box21:SetPos( 20 , 30 )
Box21:SetValue( 1 )
Box21:SetTextColor( Color(0 , 0 , 0 , 255 ) )
Box21:SizeToContents() 

local Box22 = vgui.Create( "DCheckBoxLabel")
Box22:SetText( "Friendly Fire" )
Box22:SetConVar( "EXIE_Aimbot_Friendlyfire" ) 
Box22:SetParent( ThTab )
Box22:SetPos( 20 , 50 )
Box22:SetValue( 1 )
Box22:SetTextColor( Color(0 , 0 , 0 , 255 ) )
Box22:SizeToContents() 

local Box23 = vgui.Create( "DCheckBoxLabel")
Box23:SetText( "Ignore Admins" )
Box23:SetConVar( "EXIE_Aimbot_IgnoreAdmins" ) 
Box23:SetParent( ThTab )
Box23:SetPos( 20 , 70 )
Box23:SetValue( 0 )
Box23:SetTextColor( Color(0 , 0 , 0 , 255 ) )
Box23:SizeToContents() 

local Box24 = vgui.Create( "DCheckBoxLabel")
Box24:SetText( "SmoothAim Enabled" )
Box24:SetConVar( "EXIE_SmoothAim_Enabled" ) 
Box24:SetParent( ThTab )
Box24:SetPos( 20 , 90 )
Box24:SetValue( 1 )
Box24:SetTextColor( Color(0 , 0 , 0 , 255 ) )
Box24:SizeToContents() 

local Box25 = vgui.Create( "DCheckBoxLabel")
Box25:SetText( "Ip Logs" )
Box25:SetConVar( "EXIE_Iplog" ) 
Box25:SetPos( 20 , 90 )
Box25:SetParent( SecTab )
Box25:SetValue( 1 )
Box25:SetTextColor( Color(0 , 0 , 0 , 255 ) )
Box25:SizeToContents() 

local NumSlider2 = vgui.Create( "DNumSlider" )
NumSlider2:SetPos( 150,105 )
NumSlider2:SetText( "" )
NumSlider2:SetParent( ThTab )
NumSlider2:SetSize( 140, 90 ) 
NumSlider2:SetMin( 0 ) 
NumSlider2:SetMax( 10 ) 
NumSlider2:SetDecimals( 0 )                   
NumSlider2:SetConVar( "EXIE_Smooth_Speed" ) 

local Info4 = vgui.Create("DLabel")
Info4:SetParent( ThTab )
Info4:SetPos( 160 , 105 )
Info4:SetTextColor( Color ( 0 , 0 , 0 , 255 ) )
Info4:SetSize( 200 , 20 )
Info4:SetText("Smooth Speed")

local NumSlider3 = vgui.Create( "DNumSlider" )
NumSlider3:SetPos( 150,65 )
NumSlider3:SetText( "" )
NumSlider3:SetParent( ThTab )
NumSlider3:SetSize( 140, 30 ) 
NumSlider3:SetMin( -100 ) 
NumSlider3:SetMax( 100 ) 
NumSlider3:SetDecimals( 0 )                  
NumSlider3:SetConVar( "EXIE_Aimbot_Offset")

local Info5 = vgui.Create("DLabel")
Info5:SetParent( ThTab )
Info5:SetPos( 160 , 65 )
Info5:SetTextColor( Color ( 0 , 0 , 0 , 255 ) )
Info5:SetSize( 200 , 20 )
Info5:SetText("Aim Offest")

local NumSlider5 = vgui.Create( "DNumSlider" )
NumSlider5:SetPos( 150,105 )
NumSlider5:SetText( "" )
NumSlider5:SetParent( SecTab )
NumSlider5:SetSize( 140, 90 )  
NumSlider5:SetMin( 50 ) 
NumSlider5:SetMax( 200 ) 
NumSlider5:SetDecimals( 0 )                  
NumSlider5:SetConVar( "EXIE_thirdslider")

local Info6 = vgui.Create("DLabel")
Info6:SetParent( SecTab )
Info6:SetPos( 160 , 105 )
Info6:SetTextColor( Color ( 0 , 0 , 0 , 255 ) )
Info6:SetSize( 200 , 20 )
Info6:SetText("Thirdperson Slider")



/// Info /// 

local DImageAvatar1 = vgui.Create("AvatarImage")
DImageAvatar1:SetParent( InfoTab )
DImageAvatar1:SetPos( 30, 30 )
DImageAvatar1:SetSize( 32 , 32 )
DImageAvatar1:SetPlayer( LocalPlayer() )

local Info6 = vgui.Create("DLabel")
Info6:SetParent( InfoTab )
Info6:SetPos( 30 , 60 )
Info6:SetTextColor( Color ( 0 , 0 , 0 , 255 ) )
Info6:SetSize( 200 , 20 )
Info6:SetText(tostring(  LocalPlayer():Nick()))


local ilabel
        oHTTP.Get("http://dl.dropbox.com/u/11288952/Exieinfo1.htm", "", function( data )
                ilabel = vgui.Create("DLabel")
                ilabel:SetPos( 90, 10 )
                ilabel:SetText( data )
                ilabel:SetParent( InfoTab )
				ilabel:SizeToContents()
                ilabel:SetTextColor( Color ( 0 , 0 , 0 , 255 ))
        end )

/// Changelog///
		
local ilabel2
        oHTTP.Get("http://dl.dropbox.com/u/11288952/ExieCHL.htm", "", function( data )
                ilabel2 = vgui.Create("DLabel")
                ilabel2:SetPos( 30, 10 )
                ilabel2:SetText( data )
                ilabel2:SetParent( CHL )
				ilabel2:SizeToContents()
                ilabel2:SetTextColor( Color ( 0 , 0 , 0 , 255 ))
        end )		

local Info6 = vgui.Create("DLabel")
Info6:SetParent( CHL )
Info6:SetPos( 180 , 10 )
Info6:SetTextColor( Color ( 0 , 0 , 0 , 255 ) )
Info6:SetSize( 200 , 20 )
Info6:SetText("Coded by: Mr.Jrt & Yuurei")

Sheet:AddSheet( "Home", InfoTab, "gui/silkicons/world", false, false, "About EXIEBot" )
Sheet:AddSheet( "Aimbot", ThTab, "gui/silkicons/star", false, false, "Aimbot" )
Sheet:AddSheet( "ESP", FirstTab, "gui/silkicons/check_on", false, false, "ESP" )
Sheet:AddSheet( "Misc", SecTab, "gui/silkicons/wrench", false, false, "Miscellaneous" )
Sheet:AddSheet( "Changelog", CHL, "gui/silkicons/table_edit", false, false, "Change log" )


 
 function frame_open()
	BaseFrame:SetVisible(true)
end
 
 function frame_close()
	BaseFrame:SetVisible(false)
end

EX.acc("-EXIE_menu",frame_close)
EX.acc("+EXIE_menu",frame_open)


function MagnetoThrow()
-- Nice and easy, turn it slow 180 
	timer.Simple(.02,Turn)
	timer.Simple(.04,Turn)
	timer.Simple(.06,Turn)
	timer.Simple(.08,Turn)
	timer.Simple(.10,Turn)
	timer.Simple(.12,Turn)
	timer.Simple(.14,Turn)
	timer.Simple(.16,Turn)
	timer.Simple(.18,Turn)
	timer.Simple(.20,Turn)
	timer.Simple(.22,Turn)
	timer.Simple(.24,Turn)
	timer.Simple(.26,Turn)
	timer.Simple(.28,Turn)
	timer.Simple(.30,Turn)
	timer.Simple(.32,Turn)
	timer.Simple(.34,Turn)
	timer.Simple(.36,Turn)
-- OH MY GOD WHIP AROUND 180
	timer.Simple(.46,TurnBack)
-- And deliver the final blow by pressing right click
	timer.Simple(.7,function() EX.rcc("+attack2") end)
	timer.Simple(.72,function() EX.rcc("-attack2") end)
end

function Turn()
-- Turn function
	LocalPlayer():SetEyeAngles(LocalPlayer():EyeAngles()-Angle(0,10,0))
end

function TurnBack()
-- Turn 180 function
	LocalPlayer():SetEyeAngles(LocalPlayer():EyeAngles()-Angle(0,180,0))

-- Making it a console command
EX.acc("ThrowMagneto",MagnetoThrow)
end