--[[
	MOD/lua/msh.lua
	ye | STEAM_0:1:65308065 <50.71.133.29:27005> | [21-11-13 06:53:28PM]
	===BadFile===
]]

﻿ply = LocalPlayer()
DATBONETHO = "ValveBiped.Bip01_Head1"
local IGNOREZ = true;
local color = Color( 255, 255, 0, 50 );
local that_other_color = Color( color.r, color.g, color.b, 255 );

CreateClientConVar("ma_darkrpgodmode", "0")
CreateClientConVar("ma_chams", "0")
CreateClientConVar("ma_glow", "0")
CreateClientConVar("ma_shitaimbot", "0")
CreateClientConVar("ma_keypadcracker", "0")
CreateClientConVar("ma_boxesp", "0")
CreateClientConVar("ma_spectator","0")
CreateClientConVar("ma_admindetector","0")
CreateClientConVar("ma_antiaim","0")
CreateClientConVar("ma_antifall_prop", "models/props_c17/oildrum001.mdl")

local printerclasses = {"ruby_money_printer", "sapphire_money_printer", "emerald_money_printer", "topaz_money_printer", "amethyst_money_printer", "nuclear_printer", "diamond_printer", "silver_printer", "gold_printer", "nuclear_money_printer", "diamond_money_printer", "silver_money_printer", "gold_money_printer", "normal_money_printer", "money_printer_bronze", "money_printer_silver", "money_printer_gold", "money_printer_ruby", "money_printer_diamond", "maxperform_money_printer", "advanced_money_printer", "upgrade_money_printer", "mini_moneyprinter", "money_printer", "shit_moneyprinter", "random_moneyprinter", "money_press", "precision_money_press", "generator_basic", "upgrade_coolingplate", "spawned_money", "money", "spawned_shipment", "microwave", "drug_lab", "drug"}
local printers = {}

MASpectators = {}
MAAdmins = {}

local TopFrame
local AimbotButton
local NoSpreadButton
local SpeedhackButton
local BypasserButton
local NoclipButton
local Chams
local SAimbot
local Glow
local BoxESP
local ESP
local KeypadCracker
local Head
local Spine
local Shoulder
local AimBone
local Detector
local MoreHacksLabel
local AntiAim

function Reset()
if (GetConVarNumber("ma_chams") == 1) then
RunConsoleCommand("ma_chams","0")
end
if (GetConVarNumber("ma_boxesp") == 1) then
RunConsoleCommand("ma_boxesp","0")
end
if (GetConVarNumber("ma_glow") == 1) then
RunConsoleCommand("ma_glow","0")
end
if (GetConVarNumber("ma_darkrpgodmode") == 1) then
RunConsoleCommand("ma_darkrpgodmode","0")
end
if (GetConVarNumber("ma_shitaimbot") == 1) then
RunConsoleCommand("ma_shitaimbot","0")
end
if (GetConVarNumber("ma_keypadcracker") == 1) then
RunConsoleCommand("ma_keypadcracker","0")
end
if (GetConVarNumber("ma_boxesp") == 1) then
RunConsoleCommand("ma_boxesp","0")
end
if (GetConVarNumber("ma_spectator") == 1) then
RunConsoleCommand("ma_spectator","0")
end
if (GetConVarNumber("ma_admindetector") == 1) then
RunConsoleCommand("ma_admindetector","0")
end
if (GetConVarNumber("ma_antiaim") == 1) then
RunConsoleCommand("ma_antiaim","0")
end
end
concommand.Add("ma_reset",Reset)

local toggle = 0
local ang
local view = {}
local function falldamage()
        hook.Add("CreateMove", "anti-fall", function(cmd)

                ang = cmd:GetViewAngles()
                if toggle == 0 then
                        oriang = ang
                        toggle = 1
                        hook.Add("CalcView", "FC", function(ply, ori, ang, fov, nz, fz)
                                view.origin = ori
                                view.angles = Angle(30, ang.yaw,0)
                                view.fov = fov

                                 return view        
                        end)
                end
                cmd:SetViewAngles(Angle(90, ang.yaw, 0))

                local trace = LocalPlayer():GetEyeTrace()
                if trace.HitWorld then
                        if LocalPlayer():GetPos():Distance(trace.HitPos) < 25 then
                                hook.Remove("CreateMove", "anti-fall")
                                RunConsoleCommand("gm_spawn", GetConVarString("ma_antifall_prop"))
                                cmd:SetViewAngles(view.angles)
                                hook.Remove("CalcView", "FC")
                                toggle = 0
                                timer.Simple(.1, function()
                                        RunConsoleCommand("undo")
                                end)
                        end
                end
        end)
end
concommand.Add("ma_antifall", falldamage)

function MAAntiAim(cmd, u)
    if GetConVarNumber("ma_antiaim") == 1 then
    if (LocalPlayer():KeyDown(IN_ATTACK)) then return end
    local aa = cmd:GetViewAngles()
    cmd:SetViewAngles(Angle(-181, aa.y, 180))
end
end
hook.Add("CreateMove","MAAntiAim",MAAntiAim)

function MADetector()
        for k, v in pairs(player.GetAll()) do
                if (IsValid(v:GetObserverTarget()) and v:GetObserverTarget():IsPlayer() and v:GetObserverTarget() == LocalPlayer()) then
                        if(not table.HasValue(MASpectators, v)) then
                                table.insert(MASpectators, v);
                                if GetConVarNumber("ma_spectator") == 1 then
								        chat.AddText(Color( 0, 255, 0 ),"[MH] "..v:Nick().." Started spectating you!")
                                        surface.PlaySound("buttons/blip1.wav")
                                end
                        end
                end
        end
        for k, v in pairs(MASpectators) do
                if (not IsValid(v) or not IsValid(v:GetObserverTarget()) or not v:GetObserverTarget():IsPlayer() or (v:GetObserverTarget() ~= LocalPlayer())) then
                        table.remove(MASpectators, k);
                        if GetConVarNumber("ma_spectator") == 1 then
                                chat.AddText(Color( 0, 255, 0 ),"[MH] "..v:Nick().." Stopped spectating you!")
								surface.PlaySound("buttons/blip1.wav")
                        end
                end
        end
        if GetConVarNumber("ma_admindetector") == 1 then
                for k, v in pairs(player.GetAll()) do
                        if (v:IsAdmin() and not table.HasValue(MAAdmins, v)) then
                                table.insert(MAAdmins, v);
								chat.AddText(Color( 0, 255, 0 ),"[MH] Admin "..v:Nick().." Has joined the game!")
                                surface.PlaySound("buttons/blip1.wav");
                        end
                end
        end
end
hook.Add("Think","MADetector",MADetector)

local function DrawHitbox()
if GetConVarNumber("ma_boxesp") == 1 then
cam.Start3D( EyePos(), EyeAngles() );
for i, ent in pairs( ents.GetAll() ) do
if( !ent ) then continue; end
if( !IsValid( ent ) ) then continue; end
if( ent == LocalPlayer() ) then continue; end
if( !ent:IsPlayer() && !ent:IsNPC() ) then continue; end
if( ( ent:IsPlayer() && !ent:Alive() ) || ( ent:IsNPC() && ent:GetMoveType() == 0 ) ) then continue; end
for hitbox = 0, ent:GetHitBoxCount(0) do
local bone = ent:GetHitBoxBone( hitbox, 0 );
local bpos, bang = ent:GetBonePosition( bone );
local min, max = ent:GetHitBoxBounds( hitbox, 0 );
if( min == nil || max == nil ) then
continue;
end
if( !IGNOREZ ) then
render.SetColorMaterial();
else
render.SetColorMaterialIgnoreZ();
end
render.SetBlend( color.a / 255 );
render.DrawBox( bpos, bang, min, max, color, !IGNOREZ );
render.DrawWireframeBox( bpos, bang, min, max, that_other_color, !IGNOREZ );
end
end
cam.End3D();
end
end
hook.Add( "RenderScreenspaceEffects", "Render", DrawHitbox );

local doFOV = false
local newfov = 90
local sens

concommand.Add("+ma_zoom", function( pl, cmd, args )
doFOV = true

sens = CreateClientConVar( "sensitivity", "10", false, false ):GetFloat()

pl:ConCommand( "sensitivity 1\n" )
end)

concommand.Add("-ma_zoom", function( pl, cmd, args )
doFOV = false

newfov = 90
pl:ConCommand( "sensitivity "..sens.."\n" )
end)



hook.Add("CalcView", "CalculateMaView", function( pl, origin, angles, oldfov )
if (!doFOV) then return end

local view = {}

newfov = newfov + (10 - newfov)*0.5
view.fov = newfov

return view

end)

local function coordinates( ent )

local min, max = ent:OBBMins(), ent:OBBMaxs()
local corners = {
Vector( min.x, min.y, min.z ),
Vector( min.x, min.y, max.z ),
Vector( min.x, max.y, min.z ),
Vector( min.x, max.y, max.z ),
Vector( max.x, min.y, min.z ),
Vector( max.x, min.y, max.z ),
Vector( max.x, max.y, min.z ),
Vector( max.x, max.y, max.z )
}

local minX, minY, maxX, maxY = ScrW() * 2, ScrH() * 2, 0, 0
for _, corner in pairs( corners ) do
local onScreen = ent:LocalToWorld( corner ):ToScreen()
minX, minY = math.min( minX, onScreen.x ), math.min( minY, onScreen.y )
maxX, maxY = math.max( maxX, onScreen.x ), math.max( maxY, onScreen.y )
end

return minX, minY, maxX, maxY
end
hook.Add("HUDPaint", "BoxPESP", function()
if GetConVarNumber("ma_boxesp") == 1 then
for k,v in pairs(player.GetAll()) do
local x1,y1,x2,y2 = coordinates(v)
surface.SetDrawColor(Color( 0, 255, 0 ))


surface.DrawLine( x1, y1, math.min( x1 + 5, x2 ), y1 )
surface.DrawLine( x1, y1, x1, math.min( y1 + 5, y2 ) )


surface.DrawLine( x2, y1, math.max( x2 - 5, x1 ), y1 )
surface.DrawLine( x2, y1, x2, math.min( y1 + 5, y2 ) )


surface.DrawLine( x1, y2, math.min( x1 + 5, x2 ), y2 )
surface.DrawLine( x1, y2, x1, math.max( y2 - 5, y1 ) )


surface.DrawLine( x2, y2, math.max( x2 - 5, x1 ), y2 )
surface.DrawLine( x2, y2, x2, math.max( y2 - 5, y1 ) )
end
end
end)

function maaimbot( cmd )
if GetConVarNumber("ma_shitaimbot") == 1 then
local trace = util.GetPlayerTrace( ply )
local traceRes = util.TraceLine( trace )
if traceRes.HitNonWorld then
local target = traceRes.Entity
if target:IsPlayer() then
local targethead = target:LookupBone(DATBONETHO)
local targetheadpos,targetheadang = target:GetBonePosition(targethead)
ply:SetEyeAngles((targetheadpos - ply:GetShootPos()):Angle())
function mase( cmd )
cmd:SetViewAngles((targetheadpos - ply:GetShootPos()):Angle())
end
end
end
end
end
hook.Add("CreateMove", "mase", mase)
hook.Add("Think","maaimbot",maaimbot)

surface.CreateFont( "COBFontSmall", {
font = "Bebas Neue",
size = 25,
weight = 500,
blursize = 0,
scanlines = 0,
antialias = true
})

function URACKDISAPRIN()
surface.SetFont("COBFontSmall")
surface.SetTextColor( 255,255,255 )
surface.SetTextPos(5, ScrH() / 2)
surface.DrawText("MH")
end
hook.Add( "HUDPaint", "WordBoxPaint", URACKDISAPRIN )

local function CHECKCHECKCHECK(v)
if v:Alive() == true && v:Health() ~= 0 && v:Health() >= 0 && v ~= LocalPlayer() && LocalPlayer():Alive() then
return true
else
return false
end
end

hook.Add("HUDPaint", "machams", function()
for k,v in pairs(player.GetAll()) do
if GetConVarNumber("ma_chams") == 1 then
if CHECKCHECKCHECK(v) then
cam.Start3D(EyePos(), EyeAngles())
v:SetMaterial("models/wireframe")
v:SetColor(ChamsColor)
render.MaterialOverride("models/wireframe")
render.SuppressEngineLighting( false )
render.SetBlend( 0.3 )
render.SetColorModulation( 0, 1, 0 )
v:DrawModel()
cam.End3D()
end
end
end
end)

hook.Add("HUDPaint", "L4DGlow", function()
for k,v in pairs(player.GetAll()) do
if(CHECKCHECKCHECK(v) && GetConVarNumber("ma_glow") == 1) then
effects.halo.Add({v}, team.GetColor(v:Team()), 1, 1, 5, true, true)

end
end
end)

local function madrp()
if GetConVarNumber("ma_darkrpgodmode") == 1 then
if LocalPlayer():Alive() and LocalPlayer():Health() < 75 then
RunConsoleCommand("say", "/buyhealth")
end
end
end

hook.Add("Think", "madarkrp", madrp)

concommand.Add("ma_esptoggle", function()
if esptoggle then
esptoggle = !esptoggle
else
esptoggle = !esptoggle
end
end)

esptoggle = false
function esp()
if esptoggle then
for _,v in ipairs (player.GetAll()) do
local pos = v:GetPos() + Vector(0,0,90)
local size = ScrW() * 0.02
local dis = math.floor(v:GetPos():Distance(LocalPlayer():GetPos()))
pos = pos:ToScreen()
name = v:Nick()
health = v:Health()
steamid = v:SteamID()
rank = v:GetNetworkedString("UserGroup")
if v:Nick() != LocalPlayer():Nick() then
if v:Health() > 0 then
if v:GetFriendStatus() == "friend" then
color = Color(0,255,0,255)
else
color = Color(255,255,255,255)
end
draw.DrawText(name, "Default", pos.x, pos.y - 45, color,1)
draw.DrawText("HP: "..health, "Default", pos.x, pos.y - 30, Color(255,0,0,255),1)
draw.DrawText("Dist: "..dis, "Default", pos.x, pos.y - 15, Color(255,255,0,255),1)
draw.DrawText("Rank: "..rank, "Default", pos.x, pos.y - -15, Color(255,255,0,255),1)
surface.SetDrawColor(Color(0,0,255,255))
surface.DrawLine(pos.x - size , pos.y - 30, pos.x + size, pos.y - 30)
if v:GetActiveWeapon():IsValid() and v:GetActiveWeapon():GetPrintName() then
draw.DrawText((v:GetActiveWeapon( ):GetPrintName()), "Default", pos.x, pos.y, Color(255,255,0,255),1)
else
draw.DrawText("None", "Default", pos.x, pos.y, Color(255,255,0,255),1)
end
elseif v:Health() < 1 then
color = Color(0,0,0,255)
draw.DrawText(name.." is dead.", "Default", pos.x, pos.y - 45, color,1)
draw.DrawText("Dist: "..dis, "Default", pos.x, pos.y - 30, color,1)
end
end
end
end
end
hook.Add("HUDPaint", "Paint", esp)

local X = -50
local Y = -100

local KeyPos =  {
{X+5, Y+100, 25, 25, -2.2, 3.45, 1.3, -0},
{X+37.5, Y+100, 25, 25, -0.6, 1.85, 1.3, -0},
{X+70, Y+100, 25, 25, 1.0, 0.25, 1.3, -0},

{X+5, Y+132.5, 25, 25, -2.2, 3.45, 2.9, -1.6},
{X+37.5, Y+132.5, 25, 25, -0.6, 1.85, 2.9, -1.6},
{X+70, Y+132.5, 25, 25, 1.0, 0.25, 2.9, -1.6},

{X+5, Y+165, 25, 25, -2.2, 3.45, 4.55, -3.3},
{X+37.5, Y+165, 25, 25, -0.6, 1.85, 4.55, -3.3},
{X+70, Y+165, 25, 25, 1.0, 0.25, 4.55, -3.3},

{X+5, Y+67.5, 50, 25, -2.2, 4.7, -0.3, 1.6},
{X+60, Y+67.5, 35, 25, 0.3, 1.65, -0.3, 1.6}
}

local function FindDisplayText(ent)
if ent.GetDisplayText then
return ent:GetDisplayText()
else
return ent.Entity:GetNetworkedInt("keypad_num")
end
end

local function FindStatus(ent)
if ent.GetStatus then
return ent:GetStatus()
elseif ent.Entity:GetNetworkedBool("keypad_access") and ent.Entity:GetNetworkedBool("keypad_showaccess") then
return 1
elseif not ent.Entity:GetNetworkedBool("keypad_access") and ent.Entity:GetNetworkedBool("keypad_showaccess") then
return 2
else
return 0
end
end

hook.Add("Think", "Somethingoranotherthatissomething", function()
for k,v in pairs(player.GetAll()) do
local kp = v:GetEyeTrace().Entity
if IsValid(kp) and (string.find(kp:GetClass(), "keypad") and not(string.find(v:GetClass(), "cracker") or string.find(v:GetClass(), "checker"))) and v:EyePos():Distance(kp:GetPos()) <= 70 then
kp.tempCode = kp.tempCode or ""
kp.tempText = kp.tempText or ""
kp.tempStatus = kp.tempStatus or 0

if (FindDisplayText(kp) != kp.tempText) or (FindStatus(kp) != kp.tempStatus) then
kp.tempText = FindDisplayText(kp)
kp.tempStatus = FindStatus(kp)

local tr = util.TraceLine({
start = v:EyePos(),
endpos = v:GetAimVector() * 32 + v:EyePos(),
filter = v
})

local pos = kp:WorldToLocal(tr.HitPos)

for i,p in pairs(KeyPos) do
local x = (pos.y - p[5]) / (p[5] + p[6])
local y = 1 - (pos.z + p[7]) / (p[7] + p[8])

if (x >= 0 and y >= 0 and x <= 1 and y <= 1) then
if i == 11 then
if kp.tempStatus == 1 then
kp.code = kp.tempCode
kp.tempCode = ""
elseif kp.tempStatus == 2 then
kp.tempCode = ""
end
elseif i == 10 then
kp.tempCode = ""
elseif i > 0 then
kp.tempCode = kp.tempCode..i
end
end
end
end
end
end
end)

hook.Add( "HUDPaint", "keypadcracker", function()
local e = LocalPlayer():GetEyeTrace().Entity
if IsValid(e) and string.find(e:GetClass(), "keypad") then
local text = e.code or "Not Found"
draw.WordBox( 8, ScrW() / 2, ScrH() / 2, text, "Default", Color(50,50,75,100), Color(255,255,255,255) )
end

for k,v in pairs(ents.GetAll()) do
if IsValid(v) then
if string.find(v:GetClass(), "keypad") and not(string.find(v:GetClass(), "cracker") or string.find(v:GetClass(), "checker")) then
if v != e then
local pos = v:GetPos():ToScreen()
if IsValid(v) and v.code then
draw.RoundedBox( 4, pos.x-5, pos.y-5, 20, 20, Color( 0, 255, 0, 150 ) )
else
draw.RoundedBox( 4, pos.x-5, pos.y-5, 20, 20, Color( 255, 0, 0, 150 ) )
end
end
end
end
end
end)

function muudeahack()
TopFrame = vgui.Create('DFrame')
TopFrame:SetSize(170, 540)
TopFrame:SetTitle('Muudea Hack v13.37')
TopFrame:SetDeleteOnClose(false)
TopFrame:MakePopup()
TopFrame.Paint = function()
surface.SetDrawColor(0, 0, 0, 190)
surface.DrawRect(0, 0, TopFrame:GetWide(), TopFrame:GetTall())

surface.SetDrawColor(0, 0, 0, 225)
surface.DrawRect(0, 0, TopFrame:GetWide(), 25)

surface.SetTextColor(255, 255, 255, 255)
surface.SetTextPos(5, 2)
end

AimbotButton = vgui.Create('DButton')
AimbotButton:SetSize(160, 25)
AimbotButton:SetPos(5, 90)
AimbotButton:SetText('Aimbot')
AimbotButton:SetVisible('true')
AimbotButton:SetParent( TopFrame )
AimbotButton.DoClick = function()
local aim, tar, target = false, nil, nil

function Visible(ply)
local trace = {start = LocalPlayer():GetShootPos(),endpos = ply:GetBonePosition( ply:LookupBone( "ValveBiped.Bip01_Spine" ) ),filter = {LocalPlayer(), ply}}
local tr = util.TraceLine(trace)
if tr.Fraction == 1 then
return true
else
return false
end
end

function FindAllTargets()
tar = LocalPlayer()
for k, v in pairs( ents.GetAll() ) do
if ( v:IsValid() && ( v:IsPlayer() && v:Alive() || v:IsNPC() && v:GetMoveType() != 0 ) && Visible( v ) /*&& v:Team() != LocalPlayer():Team() */ ) then
local oP, tP = v:EyePos():ToScreen(), tar:EyePos():ToScreen()
local a = math.Dist( ScrW() / 2, ScrH() / 2, oP.x, oP.y )
local b = math.Dist( ScrW() / 2, ScrH() / 2, tP.x, tP.y )
if ( b <= a ) then
tar = v
elseif ( target == LocalPlayer() ) then
tar = v
end
end
end
return tar
end

function Aimbot( ucmd )
target = FindAllTargets()

if ( !aim ) then return end
if ( target == nil || target == LocalPlayer() ) then return end

local view = target:GetBonePosition( target:LookupBone( DATBONETHO ) )
view = view + ( target:GetVelocity() / 45 + LocalPlayer():GetVelocity() / 45 )

local angle = ( view - LocalPlayer():GetShootPos() ):Angle()

angle.p = math.NormalizeAngle( angle.p )
angle.y = math.NormalizeAngle( angle.y )

angle.r = 0

ucmd:SetViewAngles( angle )

if ( aiming && target != nil || target != LocalPlayer() ) then
RunConsoleCommand( "+attack" )
timer.Simple( 0.1, function() RunConsoleCommand( "-attack" ) end )
end
end
hook.Add( "CreateMove", "AINGNJD", Aimbot )

concommand.Add( "+ma_aimbot", function() aim = true target = nil end )
concommand.Add( "-ma_aimbot", function() aim = false target = nil end )

function ESP()
for k, v in pairs( ents.GetAll() ) do
if ( v:IsPlayer() && v:Alive() && v != LocalPlayer() ) then
local pos = ( v:LocalToWorld( v:OBBCenter() ) - Vector( 0, 0, 0 ) ):ToScreen()
print("")

local pos = v:LocalToWorld( v:OBBCenter() ):ToScreen()
draw.RoundedBox( 0, pos.x, pos.y, 0, 0, Color( 0, 255, 255, 255 ) )
elseif ( v:IsPlayer() && !v:Alive() && v != LocalPlayer() ) then
local pos = ( v:LocalToWorld( v:OBBCenter() ) - Vector( 0, 0, 0 ) ):ToScreen()
print("")

local pos = v:LocalToWorld( v:OBBCenter() ):ToScreen()
draw.RoundedBox( 0, pos.x, pos.y, 0, 0, Color( 0, 255, 255, 255 ) )
elseif ( v:IsNPC() && v:GetMoveType() != 0 ) then
local pos = v:LocalToWorld( v:OBBCenter() ):ToScreen()
draw.RoundedBox( 0, pos.x, pos.y, 0, 0, Color( 0, 255, 255, 255 ) )
elseif ( v:IsValid() && v:GetMoveType() != 0 ) then
local pos = v:LocalToWorld( v:OBBCenter() ):ToScreen()
print("")
end
end
end
end
hook.Add( "HUDPaint", "SFDFDGGDG", ESP )

NoSpreadButton = vgui.Create('DButton')
NoSpreadButton:SetSize(160, 25)
NoSpreadButton:SetPos(5, 180)
NoSpreadButton:SetText('No Spread-No Recoil')
NoSpreadButton:SetVisible('true')
NoSpreadButton:SetParent( TopFrame );
NoSpreadButton.DoClick = function()
function NSNR()
local wep = LocalPlayer():GetActiveWeapon()
if wep.data then
wep.data.Recoil = 0
wep.data.Cone = 0
wep.data.Spread = 0
if wep.Primary then
wep.Primary.Recoil = 0
wep.Primary.Cone = 0
wep.Primary.Spread = 0
if wep.Secondary then
wep.Secondary.Recoil = 0
wep.Secondary.Cone = 0
wep.Secondary.Spread = 0
if wep.OldRecoil then
wep.OldRecoil = 0
end
end
end
end
end
end
hook.Add("Think", "NSNR", NSNR)

SpeedhackButton = vgui.Create('DButton')
SpeedhackButton:SetSize(160, 25)
SpeedhackButton:SetPos(5, 150)
SpeedhackButton:SetText('Speedhack')
SpeedhackButton:SetVisible('true')
SpeedhackButton:SetParent( TopFrame );
SpeedhackButton.DoClick = function()
require("c3")
CreateClientConVar("ma_setspeed", 2)

concommand.Add("muudeaspeed+", function()
RunConsoleCommand("ma_setspeed", ""..GetConVarNumber("ma_setspeed") + 0.5)
timer.Simple(0.25, function()
end)
end)
concommand.Add("muudeaspeed-", function()
RunConsoleCommand("ma_setspeed", ""..GetConVarNumber("ma_setspeed") - 0.5)
timer.Simple(0.25, function()
end)
end)


concommand.Add("+muudeaspeed", function()
GetConVar("sv_cheats"):SetValue(1)
GetConVar("host_timescale"):SetValue(GetConVarNumber("ma_setspeed"))
end)

concommand.Add("-muudeaspeed", function()
GetConVar("host_timescale"):SetValue(1)
end)
end

BypasserButton = vgui.Create('DButton')
BypasserButton:SetSize(160, 25)
BypasserButton:SetPos(5, 120)
BypasserButton:SetText('Bypasser')
BypasserButton:SetVisible('true')
BypasserButton:SetParent( TopFrame );
BypasserButton.DoClick = function()
require("c3")
GetConVar("sv_allowcslua"):SetFlags(0)
GetConVar("sv_cheats"):SetFlags(0)
GetConVar("sv_allowcslua"):SetValue(1)
GetConVar("sv_cheats"):SetValue(1)
end

InfoLabel = vgui.Create('DLabel')
InfoLabel:SetPos(40, 30)
InfoLabel:SetText('Muudea Hack v13.37\n  muudea@live.ca')
InfoLabel:SizeToContents()
InfoLabel:SetParent( TopFrame );

ESP = vgui.Create('DButton')
ESP:SetSize(160, 25)
ESP:SetPos(5, 360)
ESP:SetText('ESP')
ESP:SetParent( TopFrame );
ESP.DoClick = function()
RunConsoleCommand("ma_esptoggle")
end

BoxESP = vgui.Create('DButton')
BoxESP:SetSize(160, 25)
BoxESP:SetPos(5, 330)
BoxESP:SetText('Box ESP')
BoxESP:SetParent( TopFrame );
BoxESP.DoClick = function()
if GetConVarNumber("ma_boxesp") == 1 then
RunConsoleCommand("ma_boxesp","0")
else
RunConsoleCommand("ma_boxesp","1")
end
end

SAimbot = vgui.Create('DButton')
SAimbot:SetSize(160, 25)
SAimbot:SetPos(5, 300)
SAimbot:SetText('Legit Aimbot')
SAimbot:SetParent( TopFrame );
SAimbot.DoClick = function()
if GetConVarNumber("ma_shitaimbot") == 1 then
RunConsoleCommand("ma_shitaimbot","0")
else
RunConsoleCommand("ma_shitaimbot","1")
end
end

Glow = vgui.Create('DButton')
Glow:SetSize(160, 25)
Glow:SetPos(5, 270)
Glow:SetText('L4D Glow')
Glow:SetParent( TopFrame );
Glow.DoClick = function()
if GetConVarNumber("ma_glow") == 1 then
RunConsoleCommand("ma_glow","0")
else
RunConsoleCommand("ma_glow","1")
end
end

Chams = vgui.Create('DButton')
Chams:SetSize(160, 25)
Chams:SetPos(5, 240)
Chams:SetText('Chams')
Chams:SetParent( TopFrame );
Chams.DoClick = function()
if GetConVarNumber("ma_chams") == 1 then
RunConsoleCommand("ma_chams","0")
else
RunConsoleCommand("ma_chams","1")
end
end

NoRecoilButton = vgui.Create('DButton')
NoRecoilButton:SetSize(160, 25)
NoRecoilButton:SetPos(5, 210)
NoRecoilButton:SetText('DarkRP Godmode')
NoRecoilButton:SetParent( TopFrame );
NoRecoilButton.DoClick = function()
if GetConVarNumber("ma_darkrpgodmode") == 1 then
RunConsoleCommand("ma_darkrpgodmode","0")
else
RunConsoleCommand("ma_darkrpgodmode","1")
end
end

BoneLabel = vgui.Create('DLabel')
BoneLabel:SetPos(50, 390)
BoneLabel:SetText('Aimbot Bones')
BoneLabel:SizeToContents()
BoneLabel:SetParent( TopFrame );

MoreHacksLabel = vgui.Create('DLabel')
MoreHacksLabel:SetPos(50, 465)
MoreHacksLabel:SetText('More Hacks')
MoreHacksLabel:SizeToContents()
MoreHacksLabel:SetParent( TopFrame );

Spine = vgui.Create('DButton')
Spine:SetSize(160, 25)
Spine:SetPos(5, 435)
Spine:SetText('Spine')
Spine:SetVisible('true')
Spine:SetParent( TopFrame )
Spine.DoClick = function()
DATBONETHO = "ValveBiped.Bip01_Spine"
end

Head = vgui.Create('DButton')
Head:SetSize(160, 25)
Head:SetPos(5, 405)
Head:SetText('Head')
Head:SetVisible('true')
Head:SetParent( TopFrame )
Head.DoClick = function()
DATBONETHO = "ValveBiped.Bip01_Head1"
end

Detector = vgui.Create('DButton')
Detector:SetSize(160, 25)
Detector:SetPos(5, 480)
Detector:SetText('Detector')
Detector:SetVisible('true')
Detector:SetParent( TopFrame );
Detector.DoClick = function()
if GetConVarNumber("ma_admindetector") and GetConVarNumber("ma_spectator") == 1 then
RunConsoleCommand("ma_admindetector","0")
RunConsoleCommand("ma_spectator","0")
else
RunConsoleCommand("ma_admindetector","1")
RunConsoleCommand("ma_spectator","1")
end
end

AntiAim = vgui.Create('DButton')
AntiAim:SetSize(160, 25)
AntiAim:SetPos(5, 510)
AntiAim:SetText('Anti-Aim')
AntiAim:SetVisible('true')
AntiAim:SetParent( TopFrame );
AntiAim.DoClick = function()
if GetConVarNumber("ma_antiaim") == 1 then
RunConsoleCommand("ma_antiaim","0")
else
RunConsoleCommand("ma_antiaim","1")
end
end

NoclipButton = vgui.Create('DButton')
NoclipButton:SetSize(160, 25)
NoclipButton:SetPos(5, 60)
NoclipButton:SetText('Client Noclip')
NoclipButton:SetVisible('true')
NoclipButton:SetParent( TopFrame );
NoclipButton.DoClick = function()
local SW = {}

SW.Enabled = false
SW.ViewOrigin = Vector( 0, 0, 0 )
SW.ViewAngle = Angle( 0, 0, 0 )
SW.Velocity = Vector( 0, 0, 0 )

function SW.CalcView( ply, origin, angles, fov )
if ( !SW.Enabled ) then return end
if ( SW.SetView ) then
SW.ViewOrigin = origin
SW.ViewAngle = angles

SW.SetView = false
end
return { origin = SW.ViewOrigin, angles = SW.ViewAngle }
end
hook.Add( "CalcView", "SpiritWalk", SW.CalcView )

function SW.CreateMove( cmd )
if ( !SW.Enabled ) then return end

local time = FrameTime()
SW.ViewOrigin = SW.ViewOrigin + ( SW.Velocity * time )
SW.Velocity = SW.Velocity * 0.99

local sensitivity = 0.022
SW.ViewAngle.p = math.Clamp( SW.ViewAngle.p + ( cmd:GetMouseY() * sensitivity ), -89, 89 )
SW.ViewAngle.y = SW.ViewAngle.y + ( cmd:GetMouseX() * -1 * sensitivity )

local add = Vector( 0, 0, 0 )
local ang = SW.ViewAngle
if ( cmd:KeyDown( IN_FORWARD ) ) then add = add + ang:Forward() end
if ( cmd:KeyDown( IN_BACK ) ) then add = add - ang:Forward() end
if ( cmd:KeyDown( IN_MOVERIGHT ) ) then add = add + ang:Right() end
if ( cmd:KeyDown( IN_MOVELEFT ) ) then add = add - ang:Right() end
if ( cmd:KeyDown( IN_JUMP ) ) then add = add + ang:Up() end
if ( cmd:KeyDown( IN_DUCK ) ) then add = add - ang:Up() end

add = add:GetNormal() * time * 500
if ( cmd:KeyDown( IN_SPEED ) ) then add = add * 2 end

SW.Velocity = SW.Velocity + add

if ( SW.LockView == true ) then
SW.LockView = cmd:GetViewAngles()
end
if ( SW.LockView ) then
cmd:SetViewAngles( SW.LockView )
end

cmd:SetForwardMove( 0 )
cmd:SetSideMove( 0 )
cmd:SetUpMove( 0 )
end
hook.Add( "CreateMove", "SpiritWalk", SW.CreateMove )

function SW.Toggle()
SW.Enabled = !SW.Enabled
SW.LockView = SW.Enabled
SW.SetView = true

local status = { [ true ] = "ON", [ false ] = "OFF" }
print("")
end
concommand.Add( "ma_nocliptoggle", SW.Toggle )
end
end
concommand.Add("openmuudeahack", muudeahack )
print("|V|       _| _  _    |_| _  _  | ")
print("| ||_||_|(_|(/_(_|   | |(_|(_  |<")
chat.AddText(Color(0,255,0), "[MH] All Scripts Loaded Successfully!")
chat.AddText(Color( 255, 50, 63 ), "[MH] Muudea Hack Loaded! - muudea@live.ca")
chat.PlaySound()