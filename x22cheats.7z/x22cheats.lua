--[[
	lua/x22_cheats.lua
	SimpleIsTheBest | (STEAM_0:1:60333045)
	===DStream===
]]

--[[
Copyright :: All Rights Reserved
Registered :: 2013-03-01 21:30:12
Title :: x22 Cheats
Category :: Lua file 
Credits: Made by OverDone     
]]

if ( SERVER ) then return end

local g						= table.Copy(_G)
local x22					= {} -- Nothing
x22.hooks					= {}
x22.concommands				= {}
x22.convars					= {}
x22.timers					= {}
x22.spectators				= {} -- Store spectators here.
x22.admins					= {} -- store admins here
x22.config					= {} -- user config
x22.dev						= { -- for module shit
"STEAM_0:1:60333045",
}
x22.version					= "2.3"
x22.ents					= {
"lockpick",
"money_printer",
"spawned_food",
"spawned_money",
"spawned_shipment",
"spawned_weapon",
"drug",
"drug_lab",
"sapphire_money_printer",
"amethyst_money_printer",
"topaz_money_printer",
"emerald_money_printer",
"weed_plant",
}

local Colors				= {}
Red							= Color(255,0,0,255);
Black						= Color(0,0,0,255);
Green						= Color(0,255,0,255);
White						= Color(255,255,255,255);
Blue						= Color(0,0,255,255);
Cyan						= Color(0,255,255,255);
Pink 						= Color(255,0,255,255);
Blue						= Color(0,0,255,255);
Grey						= Color(100,100,100,255);
Gold						= Color(255,228,0,255);
Lblue						= Color(155,205,248);
Lgreen						= Color(174,255,0);
Iceblue						= Color(116,187,251,255);

local _G					= table.Copy(_G)

local math 					= _G.math
local string 				= _G.string
local hook 					= _G.hook
local table 				= _G.table
local timer 				= _G.timer
local surface 				= _G.surface
local concommand 			= _G.concommand
local cvars 				= _G.cvars
local ents 					= _G.ents
local player 				= _G.player
local team 					= _G.team
local util 					= _G.util
local draw 					= _G.draw
local usermessage 			= _G.usermessage
local vgui 					= _G.vgui
local http 					= _G.http
local cam 					= _G.cam
local render 				= _G.render

local MsgN 					= _G.MsgN
local Msg 					= _G.Msg
local Vector 				= _G.Vector
local Angle 				= _G.Angle
local pairs 				= _G.pairs
local ipairs 				= _G.ipairs
local CreateSound 			= _G.CreateSound
local setmetatable 			= _G.setmetatable
local Sound 				= _G.Sound
local print 				= _G.print
local pcall 				= _G.pcall
local type 					= _G.type
local LocalPlayer 			= _G.LocalPlayer
local KeyValuesToTable 		= _G.KeyValuesToTable
local TableToKeyValues 		= _G.TableToKeyValues
local Color 				= _G.Color
local CreateClientConVar 	= _G.CreateClientConVar
local ErrorNoHalt 			= _G.ErrorNoHalt
local IsValid 				= _G.IsValid
local CreateMaterial 		= _G.CreateMaterial
local tox22er 				= _G.tox22er
local tostring 				= _G.tostring
local CurTime			 	= _G.CurTime
local FrameTime 			= _G.FrameTime
local ScrW 					= _G.ScrW
local ScrH 					= _G.ScrH
local SetClipboardText 		= _G.SetClipboardText
local GetHostName 			= _G.GetHostName
local unpack 				= _G.unpack
local AddConsoleCommand 	= _G.AddConsoleCommand 
local require				= _G.require
local include				= _G.include

local MOVETYPE_OBSERVER 	= _G.MOVETYPE_OBSERVER
local MOVETYPE_NONE 		= _G.MOVETYPE_NONE
local TEXT_ALIGN_LEFT 		= _G.TEXT_ALIGN_LEFT
local TEXT_ALIGN_TOP 		= _G.TEXT_ALIGN_TOP
local TEXT_ALIGN_RIGHT 		= _G.TEXT_ALIGN_RIGHT
local TEXT_ALIGN_BOTTOM		= _G.TEXT_ALIGN_BOTTOM
local IN_JUMP 				= _G.IN_JUMP
local IN_FORWARD 			= _G.IN_FORWARD
local IN_BACK 				= _G.IN_BACK
local IN_MOVERIGHT 			= _G.IN_MOVERIGHT
local IN_MOVELEFT 			= _G.IN_MOVELEFT
local IN_SPEED 				= _G.IN_SPEED
local IN_DUCK 				= _G.IN_DUCK
local TEAM_SPECTATOR 		= 1002

-- old [copy]
local old_filecdir 			= file.CreateDir;
local old_filedel 			= file.Delete;
local old_fileexist 		= file.Exists;
local old_fileexistex 		= file.ExistsEx;
local old_filefind 			= file.Find;
local old_filefinddir 		= file.FindDir;
local old_filefindil 		= file.FindInLua;
local old_fileisdir			= file.IsDir;
local old_fileread 			= file.Read;
local old_filerename 		= file.Rename;
local old_filesize 			= file.Size;
local old_filetfind			= file.TFind;
local old_filetime 			= file.Time;
local old_filewrite 		= file.Write;
local old_dbginfo 			= debug.getinfo;
local old_dbginfo 			= debug.getupvalue;
local old_cve 				= ConVarExists;
local old_gcv 				= GetConVar;
local old_gcvn 				= GetConVarx22er;
local old_gcvs 				= GetConVarString;
local old_rcc 				= RunConsoleCommand;
local old_hookadd			= hook.Add;
local old_hookrem 			= hook.Remove;
local old_ccadd				= concommand.Add;
local old_ccrem 			= concommand.Remove;
local old_cvaracc 			= cvars.AddChangeCallback;
local old_cvargcvc 			= cvars.GetConVarCallbacks;
local old_cvarchange 		= cvars.OnConVarChanged;
local old_require			= require;
local old_eccommand 		= engineConsoleCommand;

function IsCustomEnt( entclass )
	return table.HasValue( x22.ents, entclass )
end
g.rawset(_G, "RunConsoleCommand", oRunConsoleCommand) 

--Materials--
function x22:CreateMaterial()
local BaseInfo = {
["$basetexture"] = "models/debug/debugwhite",
["$model"]       = 1,
["$translucent"] = 1,
["$alpha"]       = 1,
["$nocull"]      = 1,
["$ignorez"]	 = 1
}	
local mat	
if GetConVarString("x22_ESP_Chams_Material") == "Solid" then
	mat = CreateMaterial( "x22_solid", "VertexLitGeneric", BaseInfo )
elseif GetConVarString("x22_ESP_Chams_Material") == "Wireframe" then
	mat = CreateMaterial( "x22_wire", "Wireframe", BaseInfo )
end
   return mat
end

/*****
IsDev
*****/
function IsDev()
	if table.HasValue(x22.dev,LocalPlayer():SteamID()) then
		return true
	else
		return false
	end
end

/*******************************************
Name: Print/Chat functions
Purpose: Notify the user of what's going on
********************************************/
function x22.Print(msg)
	print("[x22] "..msg)
end

function x22.Notify(dosound,col,msg)
	if col then
		col = col
	end
chat.AddText(
Red, "[x22] ", 
col, msg)
	if dosound == sound then
		local beep = Sound( "/buttons/button17.wav" )
		local beepsound = CreateSound( LocalPlayer(), beep )
		beepsound:Play()
	end
end

/***********************************************
Name: Hook functions
Purpose: Add hooks and protect from anticheats
************************************************/

-- Addhook
local function AddHook(Type,Function)
	Name = Type.." | "..math.random(1,1000),math.random(1,2000),math.random(1,3000) -- Simple hook names
	x22.Print("[ADDED] Hook: ["..Type.."] | Name: "..Name.."")
	return old_hookadd(Type,Name,Function)
end

-- RemoveHook
local function RemoveHook(Type,Function)
	x22.Print("[REMOVED] Hook: ["..Type.."]")
	return old_hookrem(Type,Function)
end

/**************
Random String
**************/
function RandomString( len )
	local ret = ""
		for i = 1 , len do
			ret = ret .. string.char( math.random( 65 , 116 ) )
        end
	return ret
end

/**********************
Name: Timer shit
Purpose: Anything timer
***********************/
function AddTimer( sec, rep, func )
	local index = RandomString( 10 )	
	x22.timers[ index ] = sec	
	timer.Create( index, sec, rep, func )
end

/******************************************
Name: ConCommand Shit
Purpose: Anything related to concommands
********************************************/

function AddCMD(Name,Function)
	table.insert(x22.concommands,Name)
	x22.Print("[ADDED] ConCommand: "..Name.."")
	return old_ccadd(Name,Function)
end

function RemoveCMD(Name)
	table.remove(x22.concommands,Name)
	x22.Print("[REMOVED] ConCommand: "..Name.."")
	return old_ccrem(Name)
end

/*******************************************
Name: ConVars
Purpose: Anything with ConVars
********************************************/

-- AddConVar
function AddConVar(convar,str,save,data)
	table.insert(x22.convars,"x22_"..convar)
	return CreateClientConVar("x22_"..convar,str,true,false), x22.Print("[ADDED] ConVar: x22_"..convar.." ["..str.."]")
end

/**************************
Name: Derma shit
Purpose: Anything Derma
***************************/
function AddCheckBox( text, cvar, parent, x, y, tt )
local checkbox = vgui.Create( "DCheckBoxLabel", parent )
checkbox:SetPos( x, y )
checkbox:SetText( text )
checkbox:SetConVar( cvar )
checkbox:SetTextColor(white)
checkbox:SetTooltip( tt or "No Tool Tip" )
checkbox:SizeToContents()	
end

// AddSlider for the derma
function AddSlider( text, cvar, parent, min, max, decimals, x, y, wide, tt )
local slider = vgui.Create( "DNumSlider" )
slider:SetParent( parent )
slider:SetPos( x, y )
slider:SetWide( wide )
slider:SetText( text )
--slider:SetTextColor(BLACK)
slider:SetMin( min ) 
slider:SetMax( max ) 
slider:SetDecimals( decimals ) 
slider:SetConVar( cvar )
slider:SetTooltip( tt or "No Tool Tip" )
end

Gradient = surface.GetTextureID( "gui/gradient" )
function DrawBox( x, y, wide, tall, dropsize )
	draw.RoundedBoxEx( 4, x, y, wide, dropsize, iceblue, true, true, false, false )
	draw.RoundedBoxEx( 4, x, y + dropsize, wide, tall - dropsize, Color( 0, 0, 0, 100 ), false, false, true, true )
end

/********************************************************
Name: Hide the cheat from client
Purpose: Don't show the where the cheat loads from, etc
*********************************************************/
function error(...) x22.Notify(red,"Error in the Lua script!") end
function Error(...) x22.Notify(red,"Error in the Lua script!") end

/*************************
Name: CreatePos
Purpose: Create a position
Credits: BaconBot
***************************/
function CreatePos(v)
local ply = LocalPlayer()
local center = v:LocalToWorld( v:OBBCenter() )
local min, max = v:OBBMins(), v:OBBMaxs()
local dim = max - min	local z = max + min	
local frt	= ( v:GetForward() ) * ( dim.y / 2 )
local rgt	= ( v:GetRight() ) * ( dim.x / 2 )
local top	= ( v:GetUp() ) * ( dim.z / 2 )
local bak	= ( v:GetForward() * -1 ) * ( dim.y / 2 )
local lft	= ( v:GetRight() * -1 ) * ( dim.x / 2 )
local btm	= ( v:GetUp() * -1 ) * ( dim.z / 2 )
local s = 1
local FRT 	= center + frt / s + rgt / s + top / s; FRT = FRT:ToScreen()
local BLB 	= center + bak / s + lft / s + btm / s; BLB = BLB:ToScreen()
local FLT	= center + frt / s + lft / s + top / s; FLT = FLT:ToScreen()
local BRT 	= center + bak / s + rgt / s + top / s; BRT = BRT:ToScreen()
local BLT 	= center + bak / s + lft / s + top / s; BLT = BLT:ToScreen()
local FRB 	= center + frt / s + rgt / s + btm / s; FRB = FRB:ToScreen()
local FLB 	= center + frt / s + lft / s + btm / s; FLB = FLB:ToScreen()
local BRB 	= center + bak / s + rgt / s + btm / s; BRB = BRB:ToScreen()	
local z = 100
if ( v:Health() <= 50 ) then z = 100 end
local x, y = ( ( v:Health() / 100 ) ), 1
if ( v:Health() <= 0 ) then x = 1 end
local FRT3 	= center + frt + rgt + top / x; FRT3 = FRT3; FRT3 = FRT3:ToScreen()
local BLB3 	= center + bak + lft + btm / x; BLB3 = BLB3; BLB3 = BLB3:ToScreen()
local FLT3	= center + frt + lft + top / x; FLT3 = FLT3; FLT3 = FLT3:ToScreen()
local BRT3 	= center + bak + rgt + top / x; BRT3 = BRT3; BRT3 = BRT3:ToScreen()
local BLT3 	= center + bak + lft + top / x; BLT3 = BLT3; BLT3 = BLT3:ToScreen()
local FRB3 	= center + frt + rgt + btm / x; FRB3 = FRB3; FRB3 = FRB3:ToScreen()
local FLB3 	= center + frt + lft + btm / x; FLB3 = FLB3; FLB3 = FLB3:ToScreen()
local BRB3 	= center + bak + rgt + btm / x; BRB3 = BRB3; BRB3 = BRB3:ToScreen()	
local x, y, z = 1.1, 0.9, 1
local FRT2 	= center + frt / y + rgt / z + top / x; FRT2 = FRT2:ToScreen()
local BLB2 	= center + bak / y + lft / z + btm / x; BLB2 = BLB2:ToScreen()
local FLT2	= center + frt / y + lft / z + top / x; FLT2 = FLT2:ToScreen()
local BRT2 	= center + bak / y + rgt / z + top / x; BRT2 = BRT2:ToScreen()
local BLT2 	= center + bak / y + lft / z + top / x; BLT2 = BLT2:ToScreen()
local FRB2 	= center + frt / y + rgt / z + btm / x; FRB2 = FRB2:ToScreen()
local FLB2 	= center + frt / y + lft / z + btm / x; FLB2 = FLB2:ToScreen()
local BRB2 	= center + bak / y + rgt / z + btm / x; BRB2 = BRB2:ToScreen()	
local maxX = math.max( FRT.x,BLB.x,FLT.x,BRT.x,BLT.x,FRB.x,FLB.x,BRB.x )
local minX = math.min( FRT.x,BLB.x,FLT.x,BRT.x,BLT.x,FRB.x,FLB.x,BRB.x )
local maxY = math.max( FRT.y,BLB.y,FLT.y,BRT.y,BLT.y,FRB.y,FLB.y,BRB.y )
local minY = math.min( FRT.y,BLB.y,FLT.y,BRT.y,BLT.y,FRB.y,FLB.y,BRB.y )
local minYhp2 = math.min( FRT.y,BLB.y,FLT.y,BRT.y,BLT.y,FRB.y,FLB.y,BRB.y )
local maxXhp = math.max( FRT3.x,BLB3.x,FLT3.x,BRT3.x,BLT3.x,FRB3.x,FLB3.x,BRB3.x )
local minXhp = math.min( FRT3.x,BLB3.x,FLT3.x,BRT3.x,BLT3.x,FRB3.x,FLB3.x,BRB3.x )
local maxYhp = math.max( FRT3.y,BLB3.y,FLT3.y,BRT3.y,BLT3.y,FRB3.y,FLB3.y,BRB3.y )
local minYhp = math.min( FRT3.y,BLB3.y,FLT3.y,BRT3.y,BLT3.y,FRB3.y,FLB3.y,BRB3.y )	
local maxX2 = math.max( FRT2.x,BLB2.x,FLT2.x,BRT2.x,BLT2.x,FRB2.x,FLB2.x,BRB2.x )
local minX2 = math.min( FRT2.x,BLB2.x,FLT2.x,BRT2.x,BLT2.x,FRB2.x,FLB2.x,BRB2.x )
local maxY2 = math.max( FRT2.y,BLB2.y,FLT2.y,BRT2.y,BLT2.y,FRB2.y,FLB2.y,BRB2.y )
local minY2 = math.min( FRT2.y,BLB2.y,FLT2.y,BRT2.y,BLT2.y,FRB2.y,FLB2.y,BRB2.y )
return maxX, minX, maxY, minY, maxX2, minX2, maxY2, minY2, minYhp, maxYhp
end



/**************************
Name: GetServerGM
Purpose: Check server's GM
***************************/

function GetServerGM( notify,name )
	if notify == true then
		x22.Print("This server is using the gamemode '"..GAMEMODE.Name.."'.")
	end
	if ( string.find( string.lower( GAMEMODE.Name ), name ) ) then
		return true
	end
	return false
end

/*************************************
Name: PlayerVisible
Purpose: Check if a player is visible
*************************************/
local function CanSee(ent)    
	local tr = {};	
	tr.start = LocalPlayer():GetShootPos();
	tr.endpos = ent:GetPos() + Vector(0, 0, 5)
	tr.filter = {LocalPlayer(), ent};
	tr.mask = MASK_SHOT;	
    local trace = util.TraceLine(tr) ;
    if (trace.Fraction == 1) then 
        return true;
    else 
        return false; 
    end     
end

/**********************************
Name: GetColors
Purpose: Make a cool color!
***********************************/
local function GetColorCrosshair()
	if LocalPlayer():GetEyeTrace().Entity:IsPlayer() then
		return 0,255,0,255
	end
	if LocalPlayer():GetEyeTrace().Entity:IsNPC() then
		return 0,0,255,255
	end
	return team.GetColor(Color(255,0,0,255))
end

local function GetColorVisible(e)
	if CanSee(e) then
		return 0,255,0,255
	end
	if !CanSee(e) then
		return 255,0,0,255
	end
end


/**************************************
Name: x22er shit
Purpose: Format x22er, round x22er, etc
**************************************/
function CommaValue(amount)
	local formatted = amount
	while true do  
		formatted, k = string.gsub(formatted, "^(-?%d+)(%d%d%d)", '%1,%2')
		if (k==0) then
			break
		end
	end
	return formatted
end

function RoundNum(val, decimal)
	if (decimal) then
		return math.floor( (val * 10^decimal) + 0.5) / (10^decimal)
	else
		return math.floor(val+0.5)
	end
end

function FormatNum(amount, decimal, prefix, neg_prefix)
	local str_amount,  formatted, famount, remain
	decimal = decimal or 2
	neg_prefix = neg_prefix or "-"
	famount = math.abs(RoundNum(amount,decimal))
	famount = math.floor(famount)
	remain = RoundNum(math.abs(amount) - famount, decimal)
	formatted = CommaValue(famount)
	if (decimal > 0) then
		remain = string.sub(tostring(remain),3)
		formatted = formatted .. "." .. remain .. string.rep("0", decimal - string.len(remain))
	end
	formatted = (prefix or "") .. formatted 
	if (amount<0) then
		if (neg_prefix=="()") then
			formatted = "("..formatted ..")"
		else
			formatted = neg_prefix .. formatted 
		end
	end
	return formatted
end


/**********************
Name: DrawText
Purpose: Draws text...
**********************/
function x22.DrawText( text, font, x, y, colour, xalign, yalign )
	if (font == nil) then font = "Default" end
	if (x == nil) then x = 0 end
	if (y == nil) then y = 0 end	
	local curX = x
	local curY = y
	local curString = ""	
	surface.SetFont(font)
	local sizeX, lineHeight = surface.GetTextSize("\n")	
	for i=1, string.len(text) do
		local ch = string.sub(text,i,i)
		if (ch == "\n") then
			if (string.len(curString) > 0) then
				draw.SimpleText(curString, font, curX, curY, colour, xalign, yalign)
			end			
			curY = curY + (lineHeight/2)
			curX = x
			curString = ""
		elseif (ch == "\t") then
			if (string.len(curString) > 0) then
				draw.SimpleText(curString, font, curX, curY, colour, xalign, yalign)
			end
			local tmpSizeX,tmpSizeY =  surface.GetTextSize(curString)
			curX = math.ceil( (curX + tmpSizeX) / 50 ) * 50
			curString = ""
		else
			curString = curString .. ch
		end
	end	
	if (string.len(curString) > 0) then
		draw.SimpleText(curString, font, curX, curY, colour, xalign, yalign)
	end
end

local function FillRGBA(x,y,w,h,col)
    surface.SetDrawColor( col.r, col.g, col.b, col.a );
    surface.DrawRect( x, y, w, h );
end

local function OutlineRGBA(x,y,w,h,col)
    surface.SetDrawColor( col.r, col.g, col.b, col.a );
    surface.DrawOutlinedRect( x, y, w, h );
end

/*********************
Name: IsVehicle
Purpose: Find vehicles
*********************/
function x22.IsVehicle( e )	
	local ply = LocalPlayer()	
	if ( string.find( e:GetClass(), "prop_vehicle_" ) && ply:GetMoveType() ~= 0 ) then
		return true
	end
	return false
end

/***************************
Name: SetColors
Purpose: Set Colors
****************************/
function SetColors(e)
	local ply, class, model = LocalPlayer(), e:GetClass(), e:GetModel()
	local col	
	if ( e:IsPlayer() ) then
		col = Color(0,255,0,255)
	elseif ( e:IsNPC() ) then 
		col = Color( 255, 0, 0, 20 )		
	elseif IsCustomEnt( e:GetClass() ) then
		col = Color( 0, 200, 255, 50 )		
	else
		col = Color( 255, 255, 255, 255 )		
	end	
	return col
end

/******************************
Name: Get Admin Type
Purpose: Get Admin Type..
*******************************/
local function GetAdminType(e)
	if e:IsAdmin() && !e:IsSuperAdmin() then
		return " [Admin] "
	elseif( e:IsSuperAdmin() ) then
		return " [SuperAdmin] "
	end
	return " "
end

function CheckUpdate()
x22.Print("Checking cheat version...")
	http.Fetch("https://dl.dropbox.com/u/91139226/version.txt", function(body, len, headers, code) 
		if body == x22.version then 
			x22.Notify(sound, green,"Your version of x22 is up to date! You are currently running veresion "..x22.version) 
		else
			x22.Notify(sound, red,"Your version of x22 is outdated! Please update to version "..body)
		end 
	end)
end
CheckUpdate()

function DoUpdate()
	x22.Notify(false,green, "Please visit https://dl.dropbox.com/u/150309237/x22/x22.lua for the latest update of the cheat.")
end

/****************************
Name: Create ConVars
Purpose: Create ConVars..
*****************************/
AddConVar("ESP_Info",								0)
AddConVar("ESP_admins",								0)
AddConVar("ESP_friends",							0)
AddConVar("ESP_Box",								0)
AddConVar("ESP_Skeleton",							0)
AddConVar("ESP_Tracer",								0)
AddConVar("ESP_Crosshair",							0)
AddConVar("ESP_Crosshair_Type",						"CSS")
AddConVar("ESP_Chams",								0)
AddConVar("ESP_Chams_Material",						"Solid")
AddConVar("ESP_Ents",								0)
AddConVar("ESP_Distance",							1000)
AddConVar("ESP_Info_Type",							"info")
AddConVar("ESP_Text",								"ESPFont")
AddConVar("ESP_lasersights",						0)



/***********************************
concommands to find entities and shit
**************************************/

AddCMD("_ents",function()
	PrintTable(ents.GetAll())
end)

--[[
	CHAMS
]]--

-- OnScreen and IsCloseEnough check
function OnScreen(ent)
	local a, f = debug.getregistry().Player["GetAimVector"](LocalPlayer()):Angle() - (ent:GetPos() - LocalPlayer():GetShootPos()):Angle(), debug.getregistry().Player["GetFOV"](LocalPlayer())	
	return (math.NormalizeAngle(a.y) < f + 2 && math.NormalizeAngle(a.p) < f + 2)
end
function IsCloseEnough(ent)
	local dist = ent:GetPos():Distance( LocalPlayer():GetPos() )
	if( dist <= GetConVarNumber("Numb_ESP_Distance") and ent:GetPos() != Vector( 0, 0, 0 ) ) and OnScreen(ent) then
		return true
	end
	return false	
end

function Chams()			
local mat = Numb:CreateMaterial()
	if GetConVarNumber("Numb_ESP_Chams") == 1 then
		for k,v in pairs(ents.GetAll()) do
			local col;
			if IsValid(v) and (IsCloseEnough(v) and v:IsPlayer() and v:Alive() and v:Health() > 0)  or (IsCloseEnough(v) and v:IsWeapon()) or (IsCloseEnough(v) and v:IsNPC()) then
				if (v:IsPlayer()) then
					col = team.GetColor(v:Team())
				elseif (v:IsWeapon()) then
					col = Color(255,0,0,255)
				elseif (v:IsNPC()) then
					col = Color(0,255,0,255)
				else
					col = Color(255,255,255,255)
				end
				cam.Start3D(EyePos(),EyeAngles())
					render.SuppressEngineLighting( true )
					render.SetColorModulation(col.r / 255, col.g / 255, col.b / 255);
					render.SetBlend(col.a / 255);
					render.MaterialOverride( mat )
					v:DrawModel()		
					render.SuppressEngineLighting( false )
					render.SetColorModulation(1,1,1)
					render.MaterialOverride( )
					v:DrawModel()
				cam.End3D()
			end
		end
	end
end
hook.Add('PostDrawEffects', 'Chams', Chams)

local IsLock = false;

--[[ 
	ESP
]]--
local function GetBoxColor(e)
	if CanSee(e) then
		return Color(0,255,0)
	elseif !CanSee(e) then
		return Color(255,0,0)
	end
end

function ESP()
	for k, e in pairs( player.GetAll() ) do
local TeamColor = team.GetColor(e:Team())
local HPColor = Color(255,255,255,255)
local Dist = e:GetPos():Distance(LocalPlayer():GetPos());
local wep = "Unknown"
local SteamID = e:SteamID()
local Name = e:Nick()
local InfoCol = white
if GetConVarNumber("Numb_PERP_RPNames") == 1 then
	Name = e:GetRPName()
else
	Name = e:Nick()
end
local maxX, minX, maxY, minY, maxX2, minX2, maxY2, minY2, minYhp, maxYhp = CreatePos( e )
-- This is bad
if e:Health() >= 90 then HPColor = Color(0,255,0,255)
	elseif e:Health() >= 70 then HPColor = Color(255,255,0,255)
	elseif e:Health() >= 50 then HPColor = Color(255,165,0,255)
	elseif e:Health() >= 30 then HPColor = Color(255,140,0,255)
	elseif e:Health() >= 20 then HPCOlor = Color(255, 255, 255, 255)
	elseif e:Health() >= 10 then HPColor = Color(255,0,0,255)
	else HPColor = Color(255,0,0,255)
end
draw.SimpleTextOutlined("xInstantHook v2.0 for Garry's Mod","Logo",25,15,Color(255,255,255,255),5,1,1,black)
if ( e:IsPlayer() && e:Alive() && e != LocalPlayer() && IsCloseEnough(e) ) then
			if e:GetActiveWeapon() != nil then
				if type(e:GetActiveWeapon()) == "Weapon" then
					if e:GetActiveWeapon() and e:GetActiveWeapon():IsValid() then
						wep = e:GetActiveWeapon():GetPrintName()
						
						-- ESP Info
							if GetConVarNumber("Numb_ESP_Info") == 1 then
								draw.SimpleTextOutlined( "Name:	" ..e:Name, "Trebuchet19gh", maxX2, minY2, TeamColor,4,1,1,Color(255,0,0))
								draw.SimpleTextOutlined( "H: " .. e:Health(), "Trebuchet19gh", maxX2, minY2 + 10, HPColor, 4,1, 1, black )
								draw.SimpleTextOutlined( "D: " .. math.floor(Dist), "Trebuchet19gh", maxX2, minY2 + 20, InfoCol, 4, 1, 1, black )
								draw.SimpleTextOutlined( "W: " .. wep, "Trebuchet19gh", maxX2, minY2 + 30, InfoCol, 4, 1, 1, black)
							end
								if e:IsAdmin or e:IsSuperAdmin() then
									if(GetConVarNumber("numb_esp_admins") == 1 ) then
										draw.SimpleTextOutlined( "-[ADMIN]-", "ESPFont", maxX2, minY2 - 20, red, 4, 1,1,black)
									end
								end
								if e:GetFriendStatus() == "friend" then
									if( GetConVarNumber("numb_ESP_Friends") == 1 ) then
										draw.SimpleTextOutlined( "[Friend]", "ESPFont", maxX2, minY2 - 10, iceblue, 4, 1,1,black)
									end
								end
							end
							-- ESP BOX --
							if GetConVarNumber("Numb_ESP_Box") == 1 then
								surface.SetDrawColor(GetBoxColor(e))				
								surface.DrawLine( maxX, maxY, maxX, minY )
								surface.DrawLine( maxX, minY, minX, minY )					
								surface.DrawLine( minX, minY, minX, maxY )
								surface.DrawLine( minX, maxY, maxX, maxY )
							end
							-- ESP SKELETON --
							local bones = {
							{ S = "ValveBiped.Bip01_Head1", E = "ValveBiped.Bip01_Neck1" },
							{ S = "ValveBiped.Bip01_Neck1", E = "ValveBiped.Bip01_Spine4" },
							{ S = "ValveBiped.Bip01_Spine4", E = "ValveBiped.Bip01_Spine2" },
							{ S = "ValveBiped.Bip01_Spine2", E = "ValveBiped.Bip01_Spine1" },
							{ S = "ValveBiped.Bip01_Spine1", E = "ValveBiped.Bip01_Spine" },
							{ S = "ValveBiped.Bip01_Spine", E = "ValveBiped.Bip01_Pelvis" },
							
							{ S = "ValveBiped.Bip01_Spine4", E = "ValveBiped.Bip01_L_UpperArm" },
							{ S = "ValveBiped.Bip01_L_UpperArm", E = "ValveBiped.Bip01_L_Forearm" },
							{ S = "ValveBiped.Bip01_L_Forearm", E = "ValveBiped.Bip01_L_Hand" },

							{ S = "ValveBiped.Bip01_Spine4", E = "ValveBiped.Bip01_R_UpperArm" },
							{ S = "ValveBiped.Bip01_R_UpperArm", E = "ValveBiped.Bip01_R_Forearm" },
							{ S = "ValveBiped.Bip01_R_Forearm", E = "ValveBiped.Bip01_R_Hand" },

							{ S = "ValveBiped.Bip01_Pelvis", E = "ValveBiped.Bip01_L_Thigh" },
							{ S = "ValveBiped.Bip01_L_Thigh", E = "ValveBiped.Bip01_L_Calf" },
							{ S = "ValveBiped.Bip01_L_Calf", E = "ValveBiped.Bip01_L_Foot" },
							{ S = "ValveBiped.Bip01_L_Foot", E = "ValveBiped.Bip01_L_Toe0" },

							{ S = "ValveBiped.Bip01_Pelvis", E = "ValveBiped.Bip01_R_Thigh" },
							{ S = "ValveBiped.Bip01_R_Thigh", E = "ValveBiped.Bip01_R_Calf" },
							{ S = "ValveBiped.Bip01_R_Calf", E = "ValveBiped.Bip01_R_Foot" },
							{ S = "ValveBiped.Bip01_R_Foot", E = "ValveBiped.Bip01_R_Toe0" },
							}
							if GetConVarNumber("Numb_ESP_Skeleton") == 1 then
								for k, v in pairs( bones ) do
									local sPos, ePos = e:GetBonePosition( e:LookupBone( v.S ) ):ToScreen(), e:GetBonePosition( e:LookupBone( v.E ) ):ToScreen()
										if e:IsPlayer() and !e:IsNPC() then
											surface.SetDrawColor(team.GetColor(e:Team()))
										end
										surface.DrawLine(sPos.x,sPos.y,ePos.x,ePos.y)
								end
							end
							-- ESP TRACER --
							if GetConVarNumber("Numb_ESP_Tracer") == 1 then	
								cam.Start3D( EyePos() , EyeAngles())
								render.SetMaterial( Material( "trails/laser" ) )
								StartPos = LocalPlayer():GetActiveWeapon():GetPos()
								EndPos = e:GetBonePosition(e:LookupBone("ValveBiped.Bip01_Head1"))
								render.DrawBeam(StartPos, EndPos , 3, 0, 0, Color(0,255,0,255))
								cam.End3D()
							end
							
							-- ESP CROSSHAIR --
							if GetConVarNumber("Numb_ESP_Crosshair") == 1 then
								if GetConVarString("Numb_ESP_Crosshair_Type") == "Spinning" then
									local x, y = ScrW() / 2, ScrH() / 2	
									local Speed = 1
									surface.SetDrawColor( 255, 0, 0, 255 )
									CHPosx = math.Clamp(LocalPlayer():GetEyeTrace().HitPos:ToScreen().x,0,ScrW())
									CHPosy = math.Clamp(LocalPlayer():GetEyeTrace().HitPos:ToScreen().y,0,ScrH())
									mathsin = math.sin(CurTime()*Speed)*4
									mathcos = math.cos(CurTime()*Speed)*4
									mathsin2 = math.sin(CurTime()*Speed+0.1)*4
									mathcos2 = math.cos(CurTime()*Speed+0.1)*4
									mathsin3 = math.sin(CurTime()*Speed-0.1)*4
									mathcos3 = math.cos(CurTime()*Speed-0.1)*4
									surface.DrawLine( CHPosx+mathcos*2,CHPosy+mathsin*2,CHPosx+mathcos*5,CHPosy+mathsin*5 );
									surface.DrawLine( CHPosx-mathcos*2,CHPosy-mathsin*2,CHPosx-mathcos*5,CHPosy-mathsin*5 );
									surface.DrawLine( CHPosx+mathsin*2,CHPosy-mathcos*2,CHPosx+mathsin*5,CHPosy-mathcos*5 );
									surface.DrawLine( CHPosx-mathsin*2,CHPosy+mathcos*2,CHPosx-mathsin*5,CHPosy+mathcos*5 );
								elseif GetConVarString("Numb_ESP_Crosshair_Type") == "Jewish" then
									surface.SetDrawColor( 255, 0, 0, 255 )
									surface.DrawLine(ScrW()/2, ScrH()/2, ScrW()/2 + 20, ScrH()/2)
									surface.DrawLine(ScrW()/2 + 20, ScrH()/2, ScrW()/2 + 20, ScrH()/2 + 20)
									surface.DrawLine(ScrW()/2 , ScrH()/2, ScrW()/2 - 20, ScrH()/2)
									surface.DrawLine(ScrW()/2 - 20 , ScrH()/2, ScrW()/2 - 20, ScrH()/2 - 20)
									surface.DrawLine(ScrW()/2, ScrH()/2, ScrW()/2, ScrH()/2 - 20)
									surface.DrawLine(ScrW()/2, ScrH()/2 - 20, ScrW()/2 + 20, ScrH()/2 - 20)
									surface.DrawLine(ScrW()/2, ScrH()/2, ScrW()/2, ScrH()/2 + 20)
									surface.DrawLine(ScrW()/2, ScrH()/2 + 20, ScrW()/2 - 20, ScrH()/2 + 20)
								elseif GetConVarString("Numb_ESP_Crosshair_Type") == "Basic" then
									local x, y, s = ScrW() / 2, ScrH() / 2, 10
									surface.SetDrawColor( 255, 0, 0, 255 )
									surface.DrawLine( x, y - s, x, y + s )
									surface.DrawLine( x - s, y, x + s, y )
								elseif GetConVarString("Numb_ESP_Crosshair_Type") == "X-Cross" then
									local x, y, w = ScrW() / 2, ScrH() / 2, 7
									surface.SetDrawColor( 255, 0, 0, 255 )
									surface.DrawLine(x - w, y - w, x + w, y + w)
									surface.DrawLine(x - w, y + w, x + w, y - w)
								elseif GetConVarString("Numb_ESP_Crosshair_Type") == "Dot" then
								draw.RoundedBox( 4, ( ScrW() / 2 ) - 3, ( ScrH() / 2 ) - 3, 7, 7, Color( 255, 255, 255, 255 ) )
								elseif GetConVarString("numb_ESP_Crosshair_Type") == "CSS" then
								        local g = 5
										local s, x, y, l = 10, ScrW() / 2, ScrH() / 2, g + 15
										surface.SetDrawColor( 255, 0, 0, 255 )
										surface.DrawLine( x - l, y, x - g, y )
										surface.DrawLine( x + l, y, x + g, y )
										surface.DrawLine( x, y - l, x, y - g )
										surface.DrawLine( x, y + l, x, y + g )
								elseif GetConVarString("numb_ESP_Crosshair_Type") == "Cross Boxed" then
									surface.SetDrawColor( 255, 0, 0, 255 )
										surface.DrawLine( x - length, y, x - gap, y )
										surface.DrawLine( x + length, y, x + gap, y )
										surface.DrawLine( x, y - length, x, y - gap )
										surface.DrawLine( x, y + length, x, y + gap )
										surface.DrawOutlinedRect( x - length - 2, y - length - 2, ( length + 2 ) * 2 + 1, ( length + 2 ) * 2 + 1 )
										surface.DrawLine(ScrW() / 2 - 30, ScrH() / 2, ScrW() / 2 + 32 , ScrH() / 2)
										surface.DrawLine(ScrW() / 2 - 0, ScrH() / 2 - 30, ScrW() / 2 - 0 , ScrH() / 2 + 32)
										draw.RoundedBox( 4, ( ScrW() / 2 ) - 3, ( ScrH() / 2 ) - 3, 7, 7, Color( 0, 0, 0, 50 ) )
								end
							end
							if GetConVarNumber("Numb_MISC_CSNoclip") == 1 then
								me_pos = LocalPlayer():EyePos():ToScreen()
								draw.SimpleText("You are here!", "ESPFont_Small", me_pos.x,me_pos.y +10, red, 4, 1 )
							end
					end
				end
			end
		end
	for _, v in ipairs( ents.GetAll() ) do
		if( v:IsValid() and IsCustomEnt( v:GetClass() )) then
			if GetConVarNumber("Numb_ESP_Ents") == 1 then
				local wepn = v:GetClass()
				local wname = string.Replace(wepn,"weapon_","")
				wname = string.Replace(wname,"_"," ")
				wname = string.upper(wname)
				local entpos = v:GetPos():ToScreen()
				draw.SimpleTextOutlined(wname, "ESPFont_Small", entpos.x + 50, entpos.y - 15, red, TEXT_ALIGN_CENTER, TEXT_ALIGN_LEFT, .6, black )
			end
		end                    
	end
end
hook.Add('HUDPaint', 'ESP', ESP)


