--[[
	MOD/lua/lesp.lua
	ice cube | STEAM_0:1:36452221 <86.180.113.76:65403> | [07-01-14 11:54:42PM]
	===BadFile===
]]


lesp3 = {}
lesp3.version = 1
lesp3.s = {}

-- Framework Functions


concommand.Add( "lesp3_version", function()
	LocalPlayer():ChatPrint( "[Lesp3] Revision " .. lesp3.version )
end )

function lesp3.loadSettings()
	if file.Exists( "lesp3_settings.txt", "DATA" ) then
		local yay, nay = pcall( function() return util.JSONToTable( file.Read( "lesp3_settings.txt" ) ) end )
		if yay then
			lesp3.s = nay
		else
			print( "[Lesp3] " .. nay )
		end
	else
		print( "[Lesp3] Settings file doesn't exist" )
	end
end

function lesp3.saveSettings()
	file.Write( "lesp3_settings.txt", util.TableToJSON( lesp3.s ) )
end

local function drawText( text, font, x, y, color, alignx, aligny, outline, coloro )
	surface.SetFont( font )
	local w, h = surface.GetTextSize( text )
	surface.SetTextColor( coloro )
	x, y, outline = math.floor( x - ( ( alignx or 0 ) * w ) ), math.floor( y - ( ( aligny or 0 ) * h ) ), math.floor( outline )
	for i = -outline, outline do
		for j = -outline, outline do
			surface.SetTextPos( x + i, y + j )
			surface.DrawText( text )
		end
	end
	surface.SetTextColor( color )
	surface.SetTextPos( x, y )
	surface.DrawText( text )
end

-- PESP

do

lesp3.s.pesp = lesp3.s.pesp or {}
local s = lesp3.s.pesp
s.load = s.load or true
s.on = s.on or true
s.node = s.node or true
s.name = s.name or true
s.realname = s.realname or false
s.healthbar = s.healthbar or true
s.healthnum = s.healthnum or false
s.weapon = s.weapon or false
s.distance = s.distance or false
s.money = s.money or false
s.job = s.job or false

surface.CreateFont( "lesp3_pesp_text", { size = ScoreboardText, weight = 700 } )

if s.load then
	hook.Add( "HUDPaint", "lesp3.pesp", function()
		if not s.on then return end
		for k, v in pairs( player.GetAll() ) do
			if v == LocalPlayer() then continue end
			if not v:Alive() then continue end
			local p = v:EyePos():ToScreen()
			if s.node then
				surface.SetDrawColor( v:GetFriendStatus() == "friend" and Color( 0, 255, 0 ) or Color( 0, 0, 0 ) )
				surface.DrawOutlinedRect( p.x - 6, p.y - 6, 13, 13 )
				surface.SetDrawColor( team.GetColor( v:Team() ) )
				surface.DrawOutlinedRect( p.x - 5, p.y - 5, 11, 11 )
				surface.DrawOutlinedRect( p.x - 4, p.y - 4, 9, 9 )
				surface.SetDrawColor( v:GetFriendStatus() == "friend" and Color( 0, 255, 0 ) or Color( 0, 0, 0 ) )
				surface.DrawOutlinedRect( p.x - 3, p.y - 3, 7, 7 )
				surface.SetDrawColor( v:IsSuperAdmin() and Color( 255, 0, 0 ) or v:IsAdmin() and Color( 0, 255, 0 ) or Color( 0, 0, 255 ) )
				surface.DrawRect( p.x - 2, p.y - 2, 5, 5 )
			end
			local y = p.y
			if s.name then
				drawText( v:Name(), "lesp3_pesp_text", p.x + 12, y, v:GetFriendStatus() == "friend" and Color( 100, 255, 100 ) or Color( 255, 255, 255 ), 0, 0.5, 1, Color( 0, 0, 0 ) )
				y = y + 14
			end
			if s.healthbar then
				surface.SetDrawColor( 0, 0, 0, 255 )
				surface.DrawRect( p.x + 12, y - 6, 52, 5 )
				surface.SetDrawColor( 0, 255, 0, 255 )
				surface.DrawRect( p.x + 13, y - 5, math.Clamp( v:Health() / 2, 0, 50 ), 3 )
				if v:Armor() > 0 then
					surface.SetDrawColor( 0, 0, 0, 255 )
					surface.DrawRect( p.x + 12, y - 2, 52, 5 )
					surface.SetDrawColor( 40, 80, 255, 255 )
					surface.DrawRect( p.x + 13, y - 1, math.Clamp( v:Armor() / 2, 0, 50 ), 3 )
				end
				y = y + ( s.healthnum and 0 or ( v:Armor() > 0 and 10 or 6 ) )
			end
			if s.healthnum then
				drawText( v:Health() .. " / " .. v:Armor(), "lesp3_pesp_text", p.x + 12 + ( s.healthbar and 55 or 0 ), y, Color( 255, 255, 255 ), 0, 0.5, 1, Color( 0, 0, 0 ) )
				y = y + 14
			end
			if s.weapon and v:GetActiveWeapon() and v:GetActiveWeapon():IsValid() then
				drawText( v:GetActiveWeapon():GetPrintName(), "lesp3_pesp_text", p.x + 12, y, Color( 255, 255, 255 ), 0, 0.5, 1, Color( 0, 0, 0 ) )
				y = y + 14
			end
			if s.distance then
				drawText( math.floor( v:GetPos():Distance( LocalPlayer():GetPos() ) ), "lesp3_pesp_text", p.x + 12, y, Color( 255, 255, 255 ), 0, 0.5, 1, Color( 0, 0, 0 ) )
			end
			y = p.y
			if s.realname and v.SteamName then
				drawText( v:SteamName(), "lesp3_pesp_text", p.x - 12, y, Color( 255, 255, 255 ), 1, 0.5, 1, Color( 0, 0, 0 ) )
				y = y + 14
			end
			if s.money and v.DarkRPVars and v.DarkRPVars.money then
				drawText( "$" .. v.DarkRPVars.money, "lesp3_pesp_text", p.x - 12, y, Color( 255, 255, 255 ), 1, 0.5, 1, Color( 0, 0, 0 ) )
				y = y + 14
			end
			if s.money and v.DarkRPVars and v.DarkRPVars.job then
				drawText( v.DarkRPVars.job, "lesp3_pesp_text", p.x - 12, y, Color( 255, 255, 255 ), 1, 0.5, 1, Color( 0, 0, 0 ) )
			end
			
		end
	end )
end

end

-- EESP

do

lesp3.s.eesp = lesp3.s.eesp or {}


end

concommand.Add( "skid_disablecamera", function( ply, com, args )
	if not LocalPlayer():GetActiveWeapon() or not LocalPlayer():GetActiveWeapon():IsValid() or LocalPlayer():GetActiveWeapon():GetClass() ~= "gmod_camera" then print( "Get your camera out, faggot." ) end
	LocalPlayer():GetActiveWeapon().PrimaryAttack = LocalPlayer():GetActiveWeapon().DoShootEffect
end )
