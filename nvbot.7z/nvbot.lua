--[[
	MOD/lua/general.lua
	Bonk | STEAM_0:0:27503788 <83.86.185.239:27005> | [11-10-13 08:02:19PM]
	===BadFile===
]]

// Test Version 2 - nVbot

local nV = { };

-----------------------------
nV.CustomPrefix = "nVbot";
-----------------------------

function nV.RandomString( len, numbers, special )
	local chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"..(numbers == true && "1234567890" or "")..(special == true && "!?@#$%^&*[](),.-+={}:;'\"<>|\\" or "");
	local result = "";
	
	if (len < 1) then
		len = math.random( 10, 20 );
	end
	
	for i = 1, len do
		result = result..string.char( string.byte( chars, math.random( 1, string.len( chars ) ) ) );
	end
	
	return tostring( result );
end

nV.MetaPlayer = FindMetaTable( "Player" );
nV.CreateClientConVar = CreateClientConVar;

local function CreateClientConVar( cvarname, default, save, onmenu )
	nV.CreateClientConVar( cvarname, default, save, false );
	return {cvar = GetConVar( cvarname ), OnMenu = onmenu, name = cvarname, main = string.find( cvarname, "enable" )};
end

nV.RandomPrefix = nV.CustomPrefix or nV.RandomString( math.random( 5, 8 ), false );
nV.DeadPlayers = { };
nV.Traitors = { };
nV.TWeaponsFound = { };
nV.Recoils = { };
nV.RandomHooks = { hook = { }, name = { } };
nV.ply = LocalPlayer;
nV.players = player.GetAll;
nV.Target = nil;
nV.mouse1 = false;
nV.AimbotKeyDown = false;
nV.ShouldFire = 0;
nV.Aimbotting = false;
nV.CVARS = {Bools = { }, Numbers = { }};
nV.CVARS.Bools["Aimbot"] = CreateClientConVar( nV.RandomPrefix.."_aimbot_enabled", "0", true, true );
nV.CVARS.Bools["Aim on key"] = CreateClientConVar( nV.RandomPrefix.."_aim_on_key", "1", true, true );
nV.CVARS.Bools["Aim on mouse1"] = CreateClientConVar( nV.RandomPrefix.."_aim_on_mouse", "1", true, true );
nV.CVARS.Numbers["Max Angle"] = CreateClientConVar( nV.RandomPrefix.."_aimbot_max_angle", "30", true, true );
nV.CVARS.Bools["Aim at team mates"] = CreateClientConVar( nV.RandomPrefix.."_aimbot_friendly_fire", "1", true, true );
nV.CVARS.Bools["Aim at steam friends"] = CreateClientConVar( nV.RandomPrefix.."_aimbot_steam_friends", "0", true, true );
nV.CVARS.Bools["ESP"] = CreateClientConVar( nV.RandomPrefix.."_esp_enabled", "1", true, true );
nV.CVARS.Bools["ESP: Show health"] = CreateClientConVar( nV.RandomPrefix.."_esp_show_health", "1", true, true );
nV.CVARS.Bools["ESP: Show user group (admins)"] = CreateClientConVar( nV.RandomPrefix.."_esp_show_admins", "1", true, true );
nV.CVARS.Bools["ESP: Show weapon"] = CreateClientConVar( nV.RandomPrefix.."_esp_show_weapon", "1", true, true );
nV.CVARS.Bools["ESP: Show name"] = CreateClientConVar( nV.RandomPrefix.."_esp_show_name", "1", true, true );
nV.CVARS.Bools["ESP: TTT Show traitors"] = CreateClientConVar( nV.RandomPrefix.."_esp_show_traitors", "1", true, true );
nV.CVARS.Bools["ESP: TTT Show dead bodies"] = CreateClientConVar( nV.RandomPrefix.."_esp_show_dead_bodies", "1", true, true );
nV.CVARS.Bools["ESP: TTT Show C4"] = CreateClientConVar( nV.RandomPrefix.."_esp_show_c4", "1", true, true );
nV.CVARS.Bools["ESP: GMODZ Show items"] = CreateClientConVar( nV.RandomPrefix.."_esp_show_gmodz_items", "1", true, true );
nV.CVARS.Bools["ESP: GMODZ Show inventories"] = CreateClientConVar( nV.RandomPrefix.."_esp_show_gmodz_inventories", "1", true, true );
nV.CVARS.Bools["Chams"] = CreateClientConVar( nV.RandomPrefix.."_chams_enabled", "1", true, true );
nV.CVARS.Bools["Crosshair"] = CreateClientConVar( nV.RandomPrefix.."_crosshair_enabled", "1", true, true );
nV.CVARS.Bools["No Recoil"] = CreateClientConVar( nV.RandomPrefix.."_no_recoil", "1", true, true );
nV.CVARS.Bools["No Visual Recoil"] = CreateClientConVar( nV.RandomPrefix.."_no_visual_recoil", "1", true, true );
nV.CVARS.Bools["Traitor Detector"] = CreateClientConVar( nV.RandomPrefix.."_traitor_detector", "1", true, true );
nV.CVARS.Bools["Show spectators"] = CreateClientConVar( nV.RandomPrefix.."_show_spectators", "1", true, true );
nV.CVARS.Bools["Simplify spectator list"] = CreateClientConVar( nV.RandomPrefix.."_show_spectators_simplify", "0", true, true );
nV.CVARS.Bools["Bunny hop"] = CreateClientConVar( nV.RandomPrefix.."_bunnyhop", "1", true, true );
nV.CVARS.Bools["Auto pistol"] = CreateClientConVar( nV.RandomPrefix.."_auto_pistol", "1", true, true );
nV.CVARS.Bools["Trigger bot"] = CreateClientConVar( nV.RandomPrefix.."_triggerbot", "1", true, true );
nV.CVARS.Bools["Trigger bot team mates"] = CreateClientConVar( nV.RandomPrefix.."_triggerbot_friendly_fire", "1", true, true );
nV.CVARS.Bools["Trigger bot steam friends"] = CreateClientConVar( nV.RandomPrefix.."_triggerbot_steam_friends", "1", true, true );
nV.Mat = CreateMaterial( string.lower( nV.RandomString( math.random( 5, 8 ), false, false ) ), "VertexLitGeneric", { ["$basetexture"] = "models/debug/debugwhite", ["$model"] = 1, ["$ignorez"] = 1 } );
nV.HeadPos = nil;
nV.JumpReleased = false;
nV.TraceRes = nil;
nV.Font = nil;
nV.IsTraitor = nil;
nV.IsTTT = false;
nV.IsGmodZ = false;
nV.PrintEx = MsgC;
nV.LatestVersion = nil;
nV.Version = "0.8.2";
nV.V = 82;
nV.TimerName = nV.RandomString( 0, false, false );
nV.Unloaded = false;
nV.ToggleFade = nil;

function nV.Init( )
	nV.Font = nV.RandomString( 0, false, false );
	surface.CreateFont( nV.Font, { font = "Arial", size = 14, weight = 750, antialias = false, outline = true } );
	nV.IsTTT = string.find( GAMEMODE.Name , "Terror" );
	nV.IsGmodZ = ( string.lower( GAMEMODE.Name ) == "gmodz" );
	
	RunConsoleCommand( "showconsole" );
	Msg( "\n\n\n" );
	nV.Print( true, true, Color( 25, 225, 80 ), "Loaded!", Color( 255, 255, 255 ), "\tv"..nV.Version );
	nV.Print( true, true, Color( 255, 255, 255 ), "Your random prefix is "..nV.RandomPrefix );
	nV.Print( true, true, Color( 255, 255, 255 ), "Checking for updates..." );
	MsgC( Color( 255, 255, 255 ), "Loaded without error. Enjoy :>" );
	
	if (nV.IsTTT) then
		nV.IsTraitor = nV.MetaPlayer.IsTraitor
		
		function nV.MetaPlayer:IsTraitor()
			if (self == nV.ply()) then return nV.IsTraitor( self ); end
			
			if (!table.HasValue( nV.Traitors, self ) || !nV.CVARS.Bools["Traitor Detector"].cvar:GetBool()) then
				return nV.IsTraitor( self );
			else
				return true;
			end
		end
	end
end

function nV.Print( timestamp, stamp, ... )
	if (timestamp) then
		Msg( "["..os.date("%H:%M:%S").."] " );
	end
	
	if (stamp) then
		MsgC( Color( 50, 100, 255 ), "[nVbot] " );
	end
	
	local t = {...};
	
	if (#t == 1) then
		nV.PrintEx( Color( 255, 255, 255 ), t[1] );
	else
		for i = 1, #t, 2 do
			nV.PrintEx( t[i], t[i+1] );
		end
	end
	
	Msg( '\n' );
end

function nV.PrintChat( ... )
	chat.AddText( Color( 50, 100, 255 ), "[nVbot] ", ... );
end

function nV.Error( error )
	Msg( "["..os.date("%H:%M:%S").."] " );
	MsgC( Color( 255, 50, 50 ), "[nVbot] ERROR: " );
	MsgC( Color( 255, 255, 255 ), error.."\n" );
end

function nV.IsOnTeam( ply )
	if ( nV.IsTTT ) then
		return ply:IsTraitor() == nV.ply():IsTraitor();
	else
		return ply:Team() == nV.ply():Team();
	end
end

function nV.GetValidPlayers( )
	local players = { };
	
	for _, ply in pairs( nV.players() ) do
		if ( ply != nV.ply && IsValid( ply ) && 
		ply:IsPlayer() && 
		ply:Alive() && 
		ply:Health() >= 1 &&
		( ply:GetFriendStatus() != "friend" || nV.CVARS.Bools["Aim at steam friends"].cvar:GetBool() ) &&
		( !nV.IsOnTeam( ply ) || nV.CVARS.Bools["Aim at team mates"].cvar:GetBool() ) ) then
			table.insert( players, ply );
		end
	end
	
	return players
end

function nV.IsVisible( ply )
	if (!IsValid( ply )) then return false end
	
	local vecPos, _ = ply:GetBonePosition( ply:LookupBone( "ValveBiped.Bip01_Head1" ) or 12 );
	local trace = { start = nV.ply():EyePos(), endpos = vecPos, filter = nV.ply(), mask = MASK_SHOT };
	local traceRes = util.TraceLine( trace );
	
	nV.TraceRes = traceRes;
	
	if (traceRes.HitWorld || traceRes.Entity != ply) then return false end;
	
	return true;
end

function nV.ClosestAngle( players )
	local flAngleDifference = nil;
	local newAngle = nil;
	local viewAngles = nV.ply():EyeAngles();
	
	for _, ply in pairs( players ) do
		local vecPos, ang = ply:GetBonePosition( ply:LookupBone( "ValveBiped.Bip01_Head1" ) or 12 );
		local oldpos = vecPos;
		vecPos = vecPos - nV.VelocityPrediction( nV.ply() ) + nV.VelocityPrediction( ply )
		local angAngle = ( vecPos - nV.ply():EyePos() ):Angle()
		local flDif = math.abs( math.AngleDifference( angAngle.p, viewAngles.p ) ) + math.abs( math.AngleDifference( angAngle.y, viewAngles.y ) );
		
		if ((flAngleDifference == nil || flDif < flAngleDifference) && (!nV.CVARS.Numbers["Max Angle"].cvar:GetBool() || flDif < nV.CVARS.Numbers["Max Angle"].cvar:GetFloat())) then
			nV.HeadPos = oldpos:ToScreen();
			nV.Target = ply;
			flAngleDifference = flDif;
			newAngle = angAngle;
		end
	end
	
	return newAngle;
end

function nV.VelocityPrediction( ply ) return ply:GetAbsVelocity() * 0.012; end

function nV.Aimbot( )
	nV.HeadPos = nil;
	nV.Aimbotting = false;
	
	if (!nV.CVARS.Bools["Aimbot"].cvar:GetBool() || !nV.mouse1 && (nV.CVARS.Bools["Aim on key"].cvar:GetBool() == true || nV.CVARS.Bools["Aim on mouse1"].cvar:GetBool() == true) && !nV.AimbotKeyDown) then return end
	
	local players = {};
	
	for _, ply in pairs( nV.GetValidPlayers() ) do
		if (nV.IsVisible( ply )) then
			table.insert( players, ply );
		end
	end
	
	if (table.Count( players ) == 0) then 
		nV.Target = nil;
		return
	end;
	
	local newAngle = nV.ClosestAngle( players );
	
	if ( newAngle != nil ) then 
		nV.ply():SetEyeAngles( newAngle );
		nV.Aimbotting = true;
	end
end

function nV.TableSortByDistance( former, latter ) return latter:GetPos():Distance( nV.ply():GetPos() ) > former:GetPos():Distance( nV.ply():GetPos() ) end
function nV.TableSortByAsc( former, latter ) print( "1" ) return string.byte( string.lower( former.name ), 1 ) < string.byte( string.lower( latter.name ), 1 ) end

function nV.GetPlayersByDistance( )
	local players = nV.players( );
	
	table.sort( players, nV.TableSortByDistance );
	
	return players;
end

function nV.CreateMove( cmd )
	if (nV.IsTTT && nV.ply():Alive() && nV.ply():Health() >= 1 && nV.ply():Team() != TEAM_SPECTATOR) then
		nV.ply().voice_battery = 100;
	end
	
	if (cmd:KeyDown( IN_ATTACK ) && !nV.mouse1 && nV.CVARS.Bools["Aim on mouse1"].cvar:GetBool() == true ) then
		nV.mouse1 = true;
		nV.Aimbot( );
	elseif ( !cmd:KeyDown( IN_ATTACK ) && nV.mouse1 && nV.CVARS.Bools["Aim on mouse1"].cvar:GetBool() == true ) then
		nV.mouse1 = false;
	end
	
	if (nV.CVARS.Bools["No Recoil"].cvar:GetBool() && IsValid( nV.ply() ) && nV.ply():Alive() && nV.ply():Health() > 0 && IsValid( nV.ply():GetActiveWeapon() )) then
		if ( nV.ply():GetActiveWeapon().Primary && nV.ply():GetActiveWeapon().Primary.Recoil ) then
			nV.Recoils[nV.ply():GetActiveWeapon():EntIndex()] = nV.ply():GetActiveWeapon().Primary.Recoil;
			nV.ply():GetActiveWeapon().Primary.Recoil = 0;
		end
	end
	
	local triggerbot = false;
	
	if (nV.CVARS.Bools["Trigger bot"].cvar:GetBool()) then
		local trace = nV.ply():GetEyeTrace();
		
		if (IsValid( trace.Entity ) && trace.Entity:IsPlayer() && (trace.Entity:Team() != nV.ply():Team() || nV.CVARS.Bools["Trigger bot team mates"].cvar:GetBool()) && (trace.Entity:GetFriendStatus() != "friend" || nV.CVARS.Bools["Trigger bot steam friends"].cvar:GetBool())) then
			triggerbot = true;
		end
	end
	
	if (!cmd:KeyDown( IN_ATTACK ) && (nV.CVARS.Bools["Trigger bot"].cvar:GetBool() && nV.Aimbotting || triggerbot)) then
		cmd:SetButtons( IN_ATTACK + cmd:GetButtons() );
	end
	
	if (cmd:KeyDown( IN_ATTACK ) && nV.CVARS.Bools["Auto pistol"].cvar:GetBool() && IsValid( nV.ply():GetActiveWeapon() ) && nV.ply():GetActiveWeapon():GetClass() != "weapon_ar2" && nV.ply():GetActiveWeapon():GetClass() != "weapon_smg1" && (!nV.ply():GetActiveWeapon().Primary or nV.ply():GetActiveWeapon().Primary.Automatic == false)) then
		if (nV.ShouldFire == 3) then
			cmd:RemoveKey( IN_ATTACK );
			nV.ShouldFire = 0;
		end
		
		nV.ShouldFire = nV.ShouldFire + 1;
	else
		nV.ShouldFire = 0;
	end
	
	if (cmd:KeyDown( IN_JUMP )) then
		if (!nV.JumpReleased) then
			if (nV.CVARS.Bools["Bunny hop"].cvar:GetBool() && !nV.ply():OnGround()) then
				cmd:RemoveKey( IN_JUMP );
			end
		else
			nV.JumpReleased = false
		end
	elseif (!nV.JumpReleased) then
		nV.JumpReleased = true;
	end
end

function nV.NoVisualRecoil( ply, pos, angles, fov )
   if (nV.CVARS.Bools["No Visual Recoil"].cvar:GetBool() && nV.ply():Health() > 0 && nV.ply():Team() != TEAM_SPECTATOR && nV.ply():Alive()) then
	   return GAMEMODE:CalcView( ply, nV.ply():EyePos(), nV.ply():EyeAngles(), fov, 0.1 );
   end
end

function nV.AddToColor( color, add )
	return color + add <= 255 and color + add or color + add - 255
end

function nV.SubtractFromColor( color, sub )
	return color - sub >= 0 and color - sub or color - sub + 255
end

function nV.ESP( ) 
	if (nV.ToggleFade or 0 > CurTime()) then
		draw.DrawText( "Aimbot: "..(nV.AimbotKeyDown and "on" or "off"), nV.Font, ScrW()/2, ScrH()/2, Color( 255, 255, 255, 255 * (nV.ToggleFade - CurTime()) ), 1 );
	end
	
	if (!nV.CVARS.Bools["Crosshair"].cvar:GetBool() && !nV.CVARS.Bools["ESP"].cvar:GetBool() && !nV.CVARS.Bools["Show spectators"].cvar:GetBool()) then return end;
	
	if ( nV.CVARS.Bools["Crosshair"].cvar:GetBool() ) then
		surface.SetDrawColor( Color( 255, 255, 255 ) );
		surface.DrawLine( ScrW()/2-10, ScrH()/2, ScrW()/2-4, ScrH()/2 );
		surface.DrawLine( ScrW()/2+10, ScrH()/2, ScrW()/2+4, ScrH()/2 );
		surface.DrawLine( ScrW()/2, ScrH()/2-10, ScrW()/2, ScrH()/2-4 );
		surface.DrawLine( ScrW()/2, ScrH()/2+10, ScrW()/2, ScrH()/2+4 );
	end
	
	if (nV.CVARS.Bools["Show spectators"].cvar:GetBool()) then
		local spectators = 0;
		for _, ply in pairs( nV.players() ) do
			if (ply != nV.ply() && (ply:GetObserverMode() == OBS_MODE_IN_EYE|| ply:GetObserverMode() == OBS_MODE_CHASE) && ply:GetObserverTarget() == nV.ply()) then
				if (spectators == 0 && !nV.CVARS.Bools["Simplify spectator list"].cvar:GetBool()) then
					draw.DrawText( "Spectating you: "..ply:Nick(), nV.Font, ScrW()/2, 25, Color( 255, 100, 50 ), 1 );
				elseif (!nV.CVARS.Bools["Simplify spectator list"].cvar:GetBool()) then
					draw.DrawText( ply:Nick(), nV.Font, ScrW()/2, 25 + spectators*13, Color( 255, 100, 50 ), 1 );
				else
					draw.DrawText( "Someone is spectating you!", nV.Font, ScrW()/2, 25, Color( 255, 100, 50 ), 1 );
					break;
				end
				
				spectators = spectators + 1;
			end
		end
	end
	
	if ( !nV.CVARS.Bools["ESP"].cvar:GetBool() ) then return end
	
	surface.SetFont( nV.Font );
	
	for _, ply in pairs( nV.players() ) do
		if (ply != nV.ply() && ply:Health() >= 1 && ply:Alive() && ply:Team() != TEAM_SPECTATOR) then
			local min, max = ply:GetRenderBounds();
			local pos = ply:GetPos() + Vector( 0, 0, ( min.z + max.z ) );
			local color = Color( 50, 255, 50, 255 );
			
			if ( ply:Health() <= 10 ) then color = Color( 255, 0, 0, 255 );
			elseif ( ply:Health() <= 20 ) then color = Color( 255, 50, 50, 255 );
			elseif ( ply:Health() <= 40 ) then color = Color( 250, 250, 50, 255 );
			elseif ( ply:Health() <= 60 ) then color = Color( 150, 250, 50, 255 ); 
			elseif ( ply:Health() <= 80 ) then color = Color( 100, 255, 50, 255 ); end
			
			pos = ( pos + Vector( 0, 0, 10 ) ):ToScreen();
			
			if ( true or nV.CVARS.Bools["ESP: Show name"].cvar:GetBool() ) then
				local width, height = surface.GetTextSize( tostring( ply:Nick() ) ); 
				draw.DrawText( ply:Nick(), nV.Font, pos.x, pos.y-height/2, ( nV.IsTTT && ply:IsTraitor() ) and Color( 255, 150, 150, 255 ) or Color( 255, 255, 255, 255 ), 1 );
			end
			
			if ( true or nV.CVARS.Bools["ESP: Show user group (admins)"].cvar:GetBool() && ply:GetNetworkedString( "UserGroup" ) != "user" ) then
				local width, height = surface.GetTextSize( ply:GetNetworkedString( "UserGroup" ) );
				draw.DrawText( ply:GetNetworkedString( "UserGroup" ), nV.Font, pos.x, pos.y-height-3, Color( 255, 200, 50, 255 ), 1 );
				pos.y = pos.y - (height - 6);
			end
			
			if ( nV.IsTTT && nV.CVARS.Bools["ESP: TTT Show traitors"].cvar:GetBool() && ply:IsTraitor() ) then
				local width, height = surface.GetTextSize( "TRAITOR" );
				draw.DrawText( "TRAITOR", nV.Font, pos.x, pos.y-height-3, Color( 255, 0, 0, 255 ), 1 );
			end
			
			pos = ply:GetPos():ToScreen();
			
			if (nV.CVARS.Bools["ESP: Show health"].cvar:GetBool()) then
				local width, height = surface.GetTextSize( "Health: "..tostring( ply:Health() ) );
				draw.DrawText( "Health: "..tostring( ply:Health() ), nV.Font, pos.x, pos.y, color, 1 );
				pos.y = pos.y + 13;
			end
			
			if (nV.CVARS.Bools["ESP: Show weapon"].cvar:GetBool() && IsValid( ply:GetActiveWeapon() )) then
				local width, height = surface.GetTextSize( ply:GetActiveWeapon():GetPrintName() or ply:GetActiveWeapon():GetClass() );
				draw.DrawText( ply:GetActiveWeapon():GetPrintName() or ply:GetActiveWeapon():GetClass(), nV.Font, pos.x, pos.y, Color( 255, 200, 50 ), 1 );
			end
		end
	end
	
	if (nV.IsTTT) then
		if (nV.CVARS.Bools["ESP: TTT Show C4"].cvar:GetBool()) then
			for _, ent in pairs( ents.FindByClass( "ttt_c4" ) ) do
				if (!nV.ply():IsTraitor() or !ent:GetArmed()) then
					local pos = ent:GetPos():ToScreen();
					local width, height = surface.GetTextSize( "C4" );
					
					draw.DrawText( !ent:GetArmed() and "C4 - Unarmed" or "C4 - "..string.FormattedTime(ent:GetExplodeTime() - CurTime(), "%02i:%02i"), nV.Font, pos.x, pos.y-height/2, Color( 255, 200, 200, 255 ), 1 );
				end
			end
		end
		
		if (nV.CVARS.Bools["ESP: TTT Show dead bodies"].cvar:GetBool()) then
			for _, ent in pairs( ents.FindByClass( "prop_ragdoll" ) ) do
				local name = CORPSE.GetPlayerNick( ent, false );
				
				if ( name != false ) then
					local pos = ent:GetPos():ToScreen();
					local width, height = surface.GetTextSize( name );
					
					draw.DrawText( name, nV.Font, pos.x, pos.y-height/2, Color( 255, 255, 255, 255 ), 1 );
					
					if ( !CORPSE.GetFound(ent, false) ) then
						draw.DrawText( "Unidentified", nV.Font, pos.x, pos.y-height/2+12, Color( 200, 200, 0, 255 ), 1 );
					end
				end
			end
		end
	end

	if (nV.IsGmodZ) then
		for _, ent in pairs( ents.FindByClass( "gmodz_item" ) ) do
			if (ent.id) then
				local item = items[ent.id];
				
				if (item) then
					local name = item.name or "ERROR";
					local pos = ent:GetPos():ToScreen();
					local width, height = surface.GetTextSize( name );
					
					draw.DrawText( name, nV.Font, pos.x, pos.y-height/2, Color( 255, 255, 220, 255 ), 1 );
				end
			else
				net.Start( "item_ask_info" );
					net.WriteEntity( ent );
				net.SendToServer();
			end
		end
	end
	
	if (nV.HeadPos != nil) then
		local width = 5;
		local height = 5;
		surface.SetDrawColor( Color( 255, 0, 0, 255 ) );
		surface.DrawOutlinedRect( nV.HeadPos.x-width/2, nV.HeadPos.y-height/2, width, height );
	end
end

function nV.Chams()
	if (nV.CVARS.Bools["Chams"].cvar:GetBool()) then
		for _, ply in pairs( nV.GetPlayersByDistance( ) ) do
			if (ply != nV.ply() && IsValid( ply ) && ply:Alive() && ply:Health() > 0 && ply:Team() != TEAM_SPECTATOR) then
				local color = (nV.IsTTT and ply:IsTraitor( )) and Color( 200, 50, 50 ) or team.GetColor( ply:Team( ) );
				
				cam.Start3D( nV.ply():EyePos(), nV.ply():EyeAngles() );
					render.SuppressEngineLighting( true );
					render.SetColorModulation( color.r/255, color.g/255, color.b/255, 1 );
					render.MaterialOverride( nV.Mat );
					ply:DrawModel();
					render.SetColorModulation( nV.AddToColor( color.r, 150 )/255, nV.AddToColor( color.g, 150 )/255, nV.AddToColor( color.b, 150 )/255, 1 );
					
					if (IsValid( ply:GetActiveWeapon() )) then
						ply:GetActiveWeapon():DrawModel() 
					end
					
					if (nV.IsTTT && ply:IsTraitor()) then
						render.SetColorModulation( 1, 0, 0, 1 );
					else
						render.SetColorModulation( 1, 1, 1, 1 );
					end
					
					render.MaterialOverride();
					render.SetModelLighting( 4, color.r/255, color.g/255, color.b/255 );
					ply:DrawModel();
					render.SuppressEngineLighting( false );
				cam.End3D();
			end
		end
		
		for _, ent in pairs( ents.FindByClass( "ttt_c4" ) ) do
			cam.Start3D( nV.ply():EyePos(), nV.ply():EyeAngles() );
				render.SuppressEngineLighting( true );
				render.SetColorModulation( 1, 0, 0, 1 );
				render.MaterialOverride( nV.Mat );
				ent:DrawModel( );
				
				render.SetColorModulation( 1, 1, 1, 1 );
				render.MaterialOverride();
				render.SetModelLighting( BOX_TOP, 1, 1, 1 )
				ent:DrawModel();
					
				render.SuppressEngineLighting( false );
			cam.End3D();
		end
		
		if (nV.IsTTT) then
			for _, ent in pairs( ents.FindByClass( "prop_ragdoll" ) ) do
				if ( CORPSE.GetPlayerNick(ent, false) != false ) then
					cam.Start3D( nV.ply():EyePos(), nV.ply():EyeAngles() );
						render.SuppressEngineLighting( true );
						render.SetColorModulation( 1, 0.8, 0.5, 1 );
						render.MaterialOverride( nV.Mat );
						ent:DrawModel( );
						
						render.SetColorModulation( 1, 1, 1, 1 );
						render.MaterialOverride();
						render.SetModelLighting( BOX_TOP, 1, 1, 1 )
						ent:DrawModel();
							
						render.SuppressEngineLighting( false );
					cam.End3D();
				end
			end
		end
	end
end

function nV.PlayerDeath( ply )
	nV.PrintChat( Color( 255, 255, 255 ), ply:Nick().." has died!" );
end

timer.Create( nV.TimerName, 0.25, 0, function( )	
	if (!nV.IsTTT || GetRoundState() != 3) then 
		table.Empty( nV.DeadPlayers );
		return;
	end
	
	for _, ply in pairs( nV.players() ) do
		if ((!ply:Alive() || ply:Health() <= 0) && !table.HasValue( nV.DeadPlayers, ply )) then
			table.insert( nV.DeadPlayers, ply );
			nV.PlayerDeath( ply );
		end
	end
end )

function nV.TraitorDetector()
	if (!nV.IsTTT || nV.ply():IsTraitor()) then return end
	
	if (GetRoundState() == 2) then
		for _, wep in pairs(ents.GetAll()) do
			if (wep.CanBuy && wep:IsWeapon() && !table.HasValue(nV.TWeaponsFound, wep:EntIndex())) then
				table.insert( nV.TWeaponsFound, wep:EntIndex() )
			end
		end
	end
	
	if (GetRoundState() != 3 && GetRoundState() != 2) then
		table.Empty( nV.Traitors );
		table.Empty( nV.TWeaponsFound );
		return;
	end
	
	for _, wep in pairs(ents.GetAll()) do
		if (wep:IsWeapon() && wep.CanBuy && IsValid( wep:GetOwner() ) && wep:GetOwner():IsPlayer() && !table.HasValue( nV.TWeaponsFound, wep:EntIndex() )) then
			local ply = wep:GetOwner();
			table.insert( nV.TWeaponsFound, wep:EntIndex() );
			
			if (!ply:IsDetective()) then
				if (!table.HasValue(nV.Traitors, ply)) then
					table.insert(nV.Traitors, ply);
				end
				if (ply != nV.ply() && !nV.ply():IsTraitor() && nV.CVARS.Bools["Traitor Detector"].cvar:GetBool()) then
					chat.AddText( Color( 255, 150, 150 ), ply:Nick(), Color( 255, 255, 255 ), " is a ", Color( 255, 50, 50 ), "traitor: ", Color( 200, 120, 50 ), wep:GetPrintName() or wep:GetClass() );
				end
			end
		end
	end
end

function nV.AddHook( hookname, name, func )
	table.insert( nV.RandomHooks.hook, hookname );
	table.insert( nV.RandomHooks.name, name );
	hook.Add( hookname, name, func );
end

function nV.Menu( )
	local UsedCVARS = { };
	
	local Panel = vgui.Create( "DFrame" );
	Panel:SetSize( 500, 300 );
	Panel:SetPos( ScrW()/2-Panel:GetWide()/2, ScrH()/2-Panel:GetTall()/2 );
	Panel:SetTitle( "nVbot - nVar's Baby" );
	Panel:MakePopup();
	
	local SettingsSheet = vgui.Create( "DPropertySheet", Panel );
	SettingsSheet:SetPos( 0, 23 );
	SettingsSheet:SetSize( SettingsSheet:GetParent():GetWide(), SettingsSheet:GetParent():GetTall() - 23 );
	
	local MainPanel = vgui.Create( "DPanel", Panel );
	MainPanel:SetPos( 0, 0 );
	MainPanel:SetSize( MainPanel:GetParent():GetWide(), MainPanel:GetParent():GetTall() - 23 );
	MainPanel.Paint = function() end;
	
	local AimPanel = vgui.Create( "DPanel", Panel );
	AimPanel:SetPos( 0, 0 );
	AimPanel:SetSize( MainPanel:GetParent():GetWide(), MainPanel:GetParent():GetTall() - 23 );
	AimPanel.Paint = function() end;
	AimPanel:SetVisible( false );
	
	local ESPPanel = vgui.Create( "DPanel", Panel );
	ESPPanel:SetPos( 0, 0 );
	ESPPanel:SetSize( MainPanel:GetParent():GetWide(), MainPanel:GetParent():GetTall() - 23 );
	ESPPanel.Paint = function() end;
	ESPPanel:SetVisible( false );
	
	local MiscPanel = vgui.Create( "DPanel", Panel );
	MiscPanel:SetPos( 0, 25 );
	MiscPanel:SetSize( MainPanel:GetParent():GetWide(), MainPanel:GetParent():GetTall() - 23 );
	MiscPanel.Paint = function() end;
	MiscPanel:SetVisible( false );
	
	SettingsSheet:AddSheet("General", MainPanel, "gui/silkicons/user", false, false, "General settings");
	SettingsSheet:AddSheet("Aimhax", AimPanel, "gui/silkicons/user", false, false, "Aimbot settings");
	SettingsSheet:AddSheet("ESP/Chams", ESPPanel, "gui/silkicons/user", false, false, "ESP/Chams settings");
	SettingsSheet:AddSheet("Misc", MiscPanel, "gui/silkicons/user", false, false, "Misc settings");
	
	local Label = vgui.Create( "DLabel", MainPanel );
	Label:SetPos( 10, 5 );
	Label:SetColor( Color( 122, 122, 122, 122 ) );
	Label:SetText( "Settings" );
	Label:SizeToContents();
	
	Label = vgui.Create( "DLabel", MainPanel );
	Label:SetPos( 275, 5 );
	Label:SetColor( Color( 122, 122, 122, 122 ) );
	Label:SetText( "More coming soon" );
	Label:SizeToContents();
	
	local List = vgui.Create( "DPanelList", MainPanel );
	List:SetPos( 10, 20 );
	List:SetSize( 200, 200 );
	List:SetSpacing( 5 );
	List:EnableHorizontal( false );
	List:EnableVerticalScrollbar( true );
	List:SetPadding( 5 );
	function List:Paint()
		draw.RoundedBox( 4, 0, 0, List:GetWide(), List:GetTall(), Color( 0, 0, 0, 150 ) );
	end
	
	table.sort( nV.CVARS.Bools, nV.TableSortByAsc );
	
	for name, base in pairs(nV.CVARS.Bools) do
		if (base.OnMenu && base.main) then
			local CheckBox = vgui.Create( "DCheckBoxLabel" );
			CheckBox:SetText( name );
			CheckBox:SetConVar( base.cvar:GetName() );
			CheckBox:SetValue( base.cvar:GetBool() );
			CheckBox:SizeToContents();
			List:AddItem( CheckBox );
			table.insert( UsedCVARS, base );
		end
	end
	
	List = vgui.Create( "DPanelList", MainPanel );
	List:SetPos( 275, 20 );
	List:SetSize( 200, 200 );
	List:SetSpacing( 5 );
	List:EnableHorizontal( false );
	List:EnableVerticalScrollbar( true );
	List:SetPadding( 5 );
	function List:Paint()
		draw.RoundedBox( 4, 0, 0, List:GetWide(), List:GetTall(), Color( 0, 0, 0, 150 ) );
	end
	
	Label = vgui.Create( "DLabel", AimPanel );
	Label:SetPos( 10, 5 );
	Label:SetColor( Color( 255, 255, 255, 255 ) );
	Label:SetText( "Aimbot settings" );
	Label:SizeToContents();
	
	local List = vgui.Create( "DPanelList", AimPanel );
	List:SetPos( 10, 20 );
	List:SetSize( 200, 200 );
	List:SetSpacing( 5 );
	List:EnableHorizontal( false );
	List:EnableVerticalScrollbar( true );
	List:SetPadding( 5 );
	function List:Paint()
		draw.RoundedBox( 4, 0, 0, List:GetWide(), List:GetTall(), Color( 0, 0, 0, 150 ) );
	end
	
	for name, base in pairs(nV.CVARS.Bools) do
		if (base.OnMenu && !base.main && string.find( base.cvar:GetName(), "aim" )) then
			local CheckBox = vgui.Create( "DCheckBoxLabel" );
			CheckBox:SetText( name );
			CheckBox:SetConVar( base.cvar:GetName() );
			CheckBox:SetValue( base.cvar:GetBool() );
			CheckBox:SizeToContents();
			List:AddItem( CheckBox );
			table.insert( UsedCVARS, base );
		end
	end
	
	local FOVSlider = vgui.Create( "DNumSlider", AimPanel );
	FOVSlider:SetPos( 275, -15 );
	FOVSlider:SetSize( 150, 100 );
	FOVSlider:SetText( "Max Angle" );
	FOVSlider:SetMin( 0 );
	FOVSlider:SetMax( 180 );
	FOVSlider:SetDecimals( 0 );
	FOVSlider:SetConVar( nV.RandomPrefix.."_aimbot_max_angle" );
	FOVSlider.Paint = function()
		draw.RoundedBox( 4, 0, 36, FOVSlider:GetWide(), 25, Color( 0, 0, 0, 150 ) );
	end
	
	Label = vgui.Create( "DLabel", ESPPanel );
	Label:SetPos( 10, 5 );
	Label:SetColor( Color( 255, 255, 255, 255 ) );
	Label:SetText( "ESP/Chams settings" );
	Label:SizeToContents();
	
	List = vgui.Create( "DPanelList", ESPPanel );
	List:SetPos( 10, 20 );
	List:SetSize( 200, 200 );
	List:SetSpacing( 5 );
	List:EnableHorizontal( false );
	List:EnableVerticalScrollbar( true );
	List:SetPadding( 5 );
	function List:Paint()
		draw.RoundedBox( 4, 0, 0, List:GetWide(), List:GetTall(), Color( 0, 0, 0, 150 ) );
	end
	
	for name, base in pairs(nV.CVARS.Bools) do
		if (base.OnMenu && !base.main && (string.find( base.cvar:GetName(), "esp" ) || string.find( base.cvar:GetName(), "cham" ))) then
			local CheckBox = vgui.Create( "DCheckBoxLabel" );
			CheckBox:SetText( name );
			CheckBox:SetConVar( base.cvar:GetName() );
			CheckBox:SetValue( base.cvar:GetBool() );
			CheckBox:SizeToContents();
			List:AddItem( CheckBox );
			table.insert( UsedCVARS, base );
		end
	end
	
	Label = vgui.Create( "DLabel", MiscPanel );
	Label:SetPos( 10, 5 );
	Label:SetColor( Color( 255, 255, 255, 255 ) );
	Label:SetText( "Misc settings" );
	Label:SizeToContents();
	
	List = vgui.Create( "DPanelList", MiscPanel );
	List:SetPos( 10, 20 );
	List:SetSize( 200, 200 );
	List:SetSpacing( 5 );
	List:EnableHorizontal( false );
	List:EnableVerticalScrollbar( true );
	List:SetPadding( 5 );
	function List:Paint()
		draw.RoundedBox( 4, 0, 0, List:GetWide(), List:GetTall(), Color( 0, 0, 0, 150 ) );
	end
	
	for name, base in pairs(nV.CVARS.Bools) do
		if (base.OnMenu && !table.HasValue( UsedCVARS, base )) then
			local CheckBox = vgui.Create( "DCheckBoxLabel" );
			CheckBox:SetText( name );
			CheckBox:SetConVar( base.cvar:GetName() );
			CheckBox:SetValue( base.cvar:GetBool() );
			CheckBox:SizeToContents();
			List:AddItem( CheckBox );
		end
	end
end

function nV.UpdateMenu()
	local Panel = vgui.Create( "DFrame" );
	Panel:SetSize( 800, 600 );
	Panel:SetPos( ScrW()/2-Panel:GetWide()/2, ScrH()/2-Panel:GetTall()/2 );
	Panel:SetTitle( "nVbot - Notice" );
	Panel:MakePopup();
	
	local Label = vgui.Create( "DLabel", Panel );
	Label:SetColor( Color( 255, 255, 255, 255 ) );
	Label:SetFont( "DermaLarge" );
	Label:SetText( "Your version is outdated! "..nV.Version );
	Label:SizeToContents();
	Label:SetPos( Label:GetParent():GetWide()/2-Label:GetWide()/2-5, 50 );
	Label.Paint = function()
		Label:SetColor( Color( 255, 255 - (math.sin( CurTime() * 4 ) * 255), 255 - (math.sin( CurTime() * 4 ) * 255), 255 ) );
	end
	
	local Button = vgui.Create( "DButton", Panel );
	Button:SetText( "Save" );
	Button:SetSize( Button:GetParent():GetWide() - 50, 25 );
	Button:SetPos( 25, Button:GetParent():GetTall() - 30 );
	Button.DoClick = function()
		HTML:SetVisible( false );
		Panel:SetSize( 400, 150 );
		Panel:SetPos( ScrW()/2-Panel:GetWide()/2, ScrH()/2-Panel:GetTall()/2 );
		Label:SetText( "Saved to data/nVbotv"..nV.V..".txt" );
		Label:SizeToContents();
		Label:SetPos( Label:GetParent():GetWide()/2-Label:GetWide()/2-5, 50 );
		file.Write( "nVbotv"..nV.V..".txt", nV.LatestVersion );
	end
end

nV.Init();

nV.AddHook( "RenderScreenspaceEffects" , nV.RandomString( 0, true, true ), nV.Chams );
nV.AddHook( "Think", nV.RandomString( 0, true, true ), nV.Aimbot );
nV.AddHook( "Think", nV.RandomString( 0, true, true ), nV.TraitorDetector );
nV.AddHook( "CreateMove", nV.RandomString( 0, true, true ), nV.CreateMove );
nV.AddHook( "CalcView", nV.RandomString( 0, true, true ), nV.NoVisualRecoil );
nV.AddHook( "HUDPaint", nV.RandomString( 0, true, true ), nV.ESP );

concommand.Add( nV.RandomPrefix.."_unload", function( ply, cmd, args ) 
	for i = 1, #nV.RandomHooks.hook do
		hook.Remove( nV.RandomHooks.hook[i], nV.RandomHooks.name[i] );
		nV.Print( true, true, Color( 255, 255, 255 ), "Unhooked "..nV.RandomHooks.hook[i].." using name "..nV.RandomHooks.name[i] );
	end
	
	concommand.Remove( nV.RandomPrefix.."_unload" );
	concommand.Remove( nV.RandomPrefix.."_menu" );
	concommand.Remove( "+"..nV.RandomPrefix.."_aimbot" );
	concommand.Remove( "-"..nV.RandomPrefix.."_aimbot" );
	concommand.Remove( nV.RandomPrefix.."_aimbot_toggle" );
	timer.Destroy( nV.TimerName );
	nV.Unloaded = true;
	nV.Print( true, true, Color( 255, 255, 255 ), "Unloaded successfully!" );
end );

concommand.Add( nV.RandomPrefix.."_menu", nV.Menu );
concommand.Add( "+"..nV.RandomPrefix.."_aimbot", function( ply, cmd, args )
	nV.AimbotKeyDown = true;
	
	nV.Aimbot();
end );

concommand.Add( "-"..nV.RandomPrefix.."_aimbot", function( ply, cmd, args ) 
	nV.AimbotKeyDown = false;
end );

concommand.Add( nV.RandomPrefix.."_aimbot_toggle", function( ply, cmd, args ) 
	nV.AimbotKeyDown = !nV.AimbotKeyDown;
	nV.ToggleFade = CurTime() + 1.3;
	
	if (nV.AimbotKeyDown == true) then
		nV.Aimbot();
	end
end );