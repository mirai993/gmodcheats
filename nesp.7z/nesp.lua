--[[
	lua/stuff/esp.lua
	Noiwæx | (STEAM_0:1:20360963)
	===DStream===
]]

--[[
	nESP by Noiwex
	
	'nesp_enabled' 0|1 -- disable/enable nESP
	'nesp_spectators' 0|1 -- show spectators
	'nesp_radius' int -- radius, 0 to unlimited
]]

local math=math
local draw=draw
local surface=surface
local string=string
local table=table
local player=player
local Vector=Vector
local LocalPlayer=LocalPlayer
local Color=Color
local _R=_R

nESP = {}
local nESP = _G["nESP"]
nESP.Enabled = CreateClientConVar("nesp_enabled", "1", true, false)
nESP.TargetID = CreateClientConVar("nesp_popup", "1", true, false)
nESP.Radius = CreateClientConVar("nesp_radius", "0", true, false)
nESP.Spec = CreateClientConVar("nesp_spectators", "0", true, false)
nESP.IntEnabled = nESP.IntEnabled or false --aha

nESP.Profiles = {
	player = function(e)
		if e == LocalPlayer() then return end
		if nESP.Spec:GetBool() == false and e:Team() == TEAM_SPECTATOR then return end
		
		local info = {
						"Health: " .. e:Health(),
						(e:Armor() > 0 and "Armor: " .. e:Armor()) or nil,
						"Distance: " .. math.floor(e:GetPos():Distance(LocalPlayer():GetPos())),
						(e.DarkRPVars and 
							(
								(e.DarkRPVars.money and e.DarkRPVars.salary and e.DarkRPVars.salary > 0 and Format("Money: %d (+%d)",e.DarkRPVars.money,e.DarkRPVars.salary) )
									or
								(e.DarkRPVars.money and "Money: " .. e.DarkRPVars.money)
							)
						) or nil,
						(e:GetActiveWeapon() and ValidEntity(e:GetActiveWeapon()) and "Weapon: " .. e:GetActiveWeapon():GetClass()) or nil,
						(e:IsSuperAdmin() and "Super Admin") or (e:IsAdmin() and "Admin") or nil
					 }
		
		nESP.DrawInfo(e,info,nil,(_R.Player.IsTraitor and e:IsTraitor() and Color(255,0,0)) or (_R.Player.IsDetective and e:IsDetective() and Color(0,0,255)) or nil )
	end,
	
	ttt_c4 = function(e)
		local t = math.max(0, e:GetExplodeTime() - CurTime())
		nESP.DrawInfo(e,{},"Bomb",Color(255,0,0),t)
	end,
	
	prop_ragdoll = function(e)
		if CORPSE then
			local pl = CORPSE.GetPlayerNick(e,false)
			
			if not e.NoTarget then
				if CORPSE.GetFound(e, false) then
					nESP.DrawInfo(e, {}, pl, Color(255,128,0))
				else
					nESP.DrawInfo(e, {}, "Unknown body", Color(255,128,0))
				end
			end
		end
	end,
}

function nESP.DrawInfo(e,info,name,col,lbl)
	local pos
	if e:LookupAttachment("eyes") ~= 0 then
		pos = (e:GetAttachment(e:LookupAttachment("eyes")).Pos + Vector(0,0,5)):ToScreen()
		pos.x = math.floor(pos.x)
		pos.y = math.floor(pos.y)
	else
		pos = e:GetPos():ToScreen()
		pos.x = math.floor(pos.x)
		pos.y = math.floor(pos.y)
	end
	
	if not pos.visible then return end		
				 
	surface.SetFont "Default"
	local w,h = surface.GetTextSize(name or (e:IsPlayer() and e:Name()) or e:GetClass())
	local infoheight = #info * h
	
	if e:IsPlayer() and e:GetFriendStatus() == "friend" then
		draw.SimpleText("★","Default",pos.x-h,pos.y - infoheight - h - 1,Color(255,255,0),TEXT_ALIGN_LEFT,TEXT_ALIGN_BOTTOM)
	end
	draw.RoundedBox(4,pos.x,pos.y - infoheight - h - 1,w+7,h+1,col or (e:IsPlayer() and team.GetColor(e:Team())) or Color(128,128,128))
	draw.SimpleText(name or (e:IsPlayer() and e:Name()) or e:GetClass(),"Default",pos.x+5,pos.y - infoheight - h,color_black,TEXT_ALIGN_LEFT,TEXT_ALIGN_BOTTOM)
	draw.SimpleText(name or (e:IsPlayer() and e:Name()) or e:GetClass(),"Default",pos.x+4,pos.y - infoheight - h - 1,color_white,TEXT_ALIGN_LEFT,TEXT_ALIGN_BOTTOM)
	
	draw.SimpleText("— " .. (lbl or (e:IsPlayer() and team.GetName(e:Team()))),"Default",pos.x+10+w,pos.y - infoheight - h,color_black,TEXT_ALIGN_LEFT,TEXT_ALIGN_BOTTOM)
	draw.SimpleText("— " .. (lbl or (e:IsPlayer() and team.GetName(e:Team()))),"Default",pos.x+9+w,pos.y - infoheight - h - 1,color_white,TEXT_ALIGN_LEFT,TEXT_ALIGN_BOTTOM)
	
	local i = 0
	
	for k,v in pairs(info) do
		i = i + 1 -- because using k will mess it up
		local ew,eh = surface.GetTextSize(v)
		surface.SetDrawColor(0,0,0,128)
		surface.DrawRect(pos.x,pos.y - infoheight + (i-1) * (h+1),ew,eh + 1)
		draw.SimpleText(v,"Default",pos.x,pos.y + 1 - infoheight + (i-1) * (h+1),color_white,TEXT_ALIGN_LEFT,TEXT_ALIGN_BOTTOM)
	end
end

hook.Add("HUDPaint","ESP",function()
	/*if not nESP.Enabled:GetBool() and nESP.TargetID:GetBool() then
		nESP.DrawInfo(LocalPlayer():GetEyeTrace().Entity)
	end*/
	if nESP.IntEnabled and nESP.Enabled:GetBool() then
	
		for k,v in pairs( (nESP.Radius:GetInt() > 0 and ents.FindInSphere(LocalPlayer():GetPos(),nESP.Radius:GetInt())) or  player.GetAll()) do
			nESP.Profiles.player(v)
		end
		
		for c,f in pairs(nESP.Profiles) do
			if c == "player" then continue end
			for k,v in pairs(ents.FindByClass(c)) do
				f(v)
			end
		end
	end
end)

/*hook.Add("OnEntityCreated","nESP_Ragdolls",function(e)
	if ValidEntity(e) and e:GetClass() == "prop_ragdoll" then
		local c = LocalPlayer()
		local d = math.huge
		for k,v in pairs(player.GetAll()) do
			if v:GetPos():Distance(e:GetPos()) <= d and not v:Alive() then
				c = v
			end
		end
		
		print(c:GetName() .. " has died")
	end
end)*/

hook.Add("KeyPress","nESP_ShowItUp",function() -- AAAAAAAA LAAAAG CRAAAASH, ah nope
	nESP.IntEnabled = true
	
	hook.Remove("KeyPress","nESP_ShowItUp")
end)