--[[
	Xray.lua
	(-SG-) Ty Dollaz | (STEAM_0:0:40143824)
	===DStream===
]]

-- new and improved xray by tyler --

if ( SERVER ) then return end;

require("cvar2")

local hack 				= {};
local HACK_ORANGE 		= Color(255,69,0,255)
local HACK_CYAN 		= Color(0,255,255,255)
local HACK_RED 			= Color(255,0,0,255)
local HACK_GREEN 		= Color(0,255,0,255)
local HACK_BLACK 		= Color(0,0,0,255)
local HACK_WHITE 		= Color(255,255,255,255)
local HACK_PINK 		= Color(255,0,255,255)
local HACK_BLUE 		= Color(0,0,255,255)
local HACK_GREY			= Color(50,50,50,255)
local TEAM_SPECTATOR 	= 1002;
local AddConVar 		= CreateClientConVar;
local util 				= util;
local vgui 				= vgui;
local table 			= table;
local math 				= math;
local string 			= string;
local print 			= print;
local surface 			= surface;
local LocalPlayer 		= LocalPlayer;
local RunConsoleCommand = RunConsoleCommand;
local CreateMaterial    = CreateMaterial
local draw 				= draw;
local ScrW 				= ScrW;
local ScrH 				= ScrH;
local MsgN 				= MsgN;
local Msg 				= Msg;
local _R 				= _R;
local _G 				= _G;
local timer 			= timer;
local concommand		= concommand;
local hook 				= hook;

AddConVar("xray_esp_box",0,true,false)
AddConVar("xray_esp_info",0,true,false)
AddConVar("xray_esp_props",0,true,false)
AddConVar("xray_misc_fullbright",0,true,false)

surface.CreateFont("ScoreboardText",15,1000,true,false,"ESPFont")

function hack.notify(msg)
chat.AddText(
	HACK_CYAN, "[XRay]: ",
	HACK_WHITE, msg.."")
end

function Visible( ent )
local tracer = {}
tracer.start = LocalPlayer():GetShootPos()
tracer.endpos = GetPosition()
tracer.filter = { LocalPlayer() }
tracer.mask = MASK_SHOT
local trace = util.TraceLine( tracer )
if trace.Fraction >= 1 then return true else return false end
end

local function GetCoordinates( ent )
local min, max = ent:OBBMins(), ent:OBBMaxs()
local corners = {
Vector( min.x, min.y, min.z ),
Vector( min.x, min.y, max.z ),
Vector( min.x, max.y, min.z ),
Vector( min.x, max.y, max.z ),
Vector( max.x, min.y, min.z ),
Vector( max.x, min.y, max.z ),
Vector( max.x, max.y, min.z ),
Vector( max.x, max.y, max.z )
}	
local minX, minY, maxX, maxY = ScrW() * 2, ScrH() * 2, 0, 0
for _, corner in pairs( corners ) do
local onScreen = ent:LocalToWorld( corner ):ToScreen()
minX, minY = math.min( minX, onScreen.x ), math.min( minY, onScreen.y )
maxX, maxY = math.max( maxX, onScreen.x ), math.max( maxY, onScreen.y )
end
return minX, minY, maxX, maxY
end

function BoxESP()
if GetConVarNumber("xray_esp_box") == 1 then
	for _, ply in pairs( player.GetAll() ) do
		if( ply == LocalPlayer() ) then continue end
		if( !ply:Alive() or ply:InVehicle() or ply:GetMoveType() == MOVETYPE_OBSERVER or ply:GetMoveType() == MOVETYPE_NONE ) then continue end	
		local x1, y1, x2, y2 = GetCoordinates( ply )	
		surface.SetDrawColor( 0, 255, 255 )		
		surface.DrawLine( x1, y1, x2, y1 )
		surface.DrawLine( x2, y1, x2, y2 )
		surface.DrawLine( x1, y2, x2, y2 )
		surface.DrawLine( x1, y1, x1, y2 )
	end
end
end
hook.Add("HUDPaint","DrawBoxESP",BoxESP)

function ESPInfo()
for k, v in ipairs( player.GetAll() ) do
	if( v:Alive() && v != LocalPlayer() and v:Team() != TEAM_SPECTATOR ) then
		local pos = v:EyePos():ToScreen()
		pos.y = pos.y - 32
		local astatus = ""
		local weaponp = ""
		local rank = ""
		local wep = ""
		local InfoColor = HACK_ORANGE
		if( v:IsAdmin() ) then rank = " [A]" end
		if( v:IsSuperAdmin() ) then rank = " [SA]" end
		local name = v:Nick() .. rank
		
		if( ValidEntity( v:GetActiveWeapon() ) ) then
				wep = v:GetActiveWeapon():GetPrintName().." | "
				wep = string.gsub( wep, "#HL2_", "" )
				wep = string.gsub( wep, "#GMOD_", "" )
			end
			
			local color = team.GetColor(v:Team())
			local dist = math.floor( v:GetPos():Distance( LocalPlayer():GetPos() ) )
			if GetConVarNumber("xray_esp_info") == 1 then
				draw.SimpleText(v:Name(), "ESPFont", pos.x, pos.y, InfoColor, TEXT_ALIGN_CENTER )
				draw.SimpleText("HP: " .. v:Health(), "ESPFont", pos.x, pos.y + 12, InfoColor, TEXT_ALIGN_CENTER )
				draw.SimpleText("Distance: " .. math.floor(dist), "ESPFont", pos.x, pos.y + 22, InfoColor, TEXT_ALIGN_CENTER);
				draw.SimpleText("Weapon: " .. wep, "ESPFont", pos.x, pos.y + 32, InfoColor, TEXT_ALIGN_CENTER );
				draw.SimpleText("Rank: " ..rank, "ESPFont", pos.x, pos.y + 42, InfoColor,TEXT_ALIGN_CENTER);	
			end
		end
	end
end
hook.Add("HUDPaint","ESPINFO",ESPInfo)

function PropsChams(ent)
if GetConVarNumber("xray_esp_props") == 1 then
for k,v in pairs(ents.FindByClass("prop_physics")) do
--if ValidEntity(ent) then
if Visible(ent) then 
_R.Entity.SetColor(v,255,255,0,130)
_R.Entity.SetMaterial(v,"xray_chams")
else
_R.Entity.SetColor(v,0,255,255,130)
_R.Entity.SetMaterial(v,"xray_chams")
end
end
end
end
hook.Add("HUDPaint","Fuckshitstack",PropsChams)

local neededAngles = Angle(-90, 0, 0)

function HeadLines2()
cam.Start3D(EyePos(), EyeAngles())
for k,ply in pairs(player.GetAll()) do
if ply != LocalPlayer() && ply:Alive() then
local shootPos = ply:GetShootPos()
local data = {}
data.start = shootPos
data.endpos = shootPos + neededAngles:Forward() * 10000
data.filter = ply
local tr = util.TraceLine(data)
cam.Start3D2D(shootPos, neededAngles, 1)
if ValidEntity(tr.Entity) then
surface.SetDrawColor(255, 140, 0, 255)
else
surface.SetDrawColor(0, 0, 255, 255)
end
surface.DrawLine(0, 0, tr.HitPos:Distance(shootPos), 0)
cam.End3D2D()
end
end
cam.End3D()
end
hook.Add("HUDPaint", "HeadLines2", HeadLines2)


