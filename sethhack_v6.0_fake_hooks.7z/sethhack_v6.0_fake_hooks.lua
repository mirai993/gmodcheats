--[[
	MOD/lua/sethhooks.lua [#4841 (#4957), 2703525316, UID:2399519970]
	{(ACS 2.0)} Trainer Blue | STEAM_0:0:77823910 <50.126.114.173:27005> | [04.05.14 10:57:14PM]
	===BadFile===
]]

local SH = {}; // since SH is already local, you dont need to use local SH["blah"], just SH["blah"] = blah
SH["twep"] = { 
"weapon_ttt_c4",
 "weapon_ttt_knife",
  "weapon_ttt_phammer",
   "weapon_ttt_sipistol", "weapon_ttt_flaregun",
    "weapon_ttt_push",
     "weapon_ttt_radio",
      "weapon_ttt_teleport",
       "(Disguise)" ,
       "spiderman's_swep",
        "weapon_ttt_trait_defilibrator",
         "weapon_ttt_xbow",
          "weapon_ttt_dhook",
           "weapon_awp",
            "weapon_jihadbomb",
             "weapon_ttt_knife",
              "weapon_ttt_c4",
               "weapon_ttt_decoy",
                "weapon_ttt_flaregun",
                 "weapon_ttt_phammer",
                  "weapon_ttt_push",
                   "weapon_ttt_radio",
                    "weapon_ttt_sipistol",
                     "weapon_ttt_teleport",
                      "weapon_ttt_awp",
                       "weapon_ttt_silencedsniper",
                        "weapon_ttt_turtlenade",
                         "weapon_ttt_death_station",
                          "weapon_ttt_tripmine"
         }
SH["OldHook"] = hook;
SH["OldRunConsoleCommand"] = RunConsoleCommand;
SH["Detours"] = {}
SH["vars"] = {
    ["aimbot_enabled"] = false,
    ["esp_enabled"] = false,
    ["kaylaisawesome"] = true,
    ["tylerisawesome"] = true,
    ["spamenabled"] = false,
    ["spamstring"] = "SethHack v6.0 brah. get the latest update at freerat.co.uk",
    ACFixed = false,    
}
SH["spectators"] = {
    
}
SH["hooks"] = {
}
function SH.Message(msg)
chat:AddText(Color(240,15,0), "[SH] ", Color(100,5,150), msg .. "\n")
end
function SH.AddHook( Type, Function )
    Name = tostring( Function )
    table["insert"]( SH["hooks"], Name .. ":" .. Type)
    SH.Message("Adding hook " .. Name .. " with type " .. Type)
    return SH["OldHook"]["Add"]( Type, Name, Function )
end
function SH.esp()
    if gmod["GetGamemode"]()["Name"]:lower() == "trouble in terrorist town" then
    for k, v in pairs( player["GetAll"]() ) do
        if ( v:Alive() && v != LocalPlayer() && (v.HatTraitor) && !v:IsDetective() ) then
            local pos = ( v:GetPos() - Vector( 0, 0, 10 ) ):ToScreen() 
            draw["SimpleTextOutlined"]( v:Nick() .. " - TRAITOR", "default", pos.x, pos.y, Color(255, 0, 0, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, Color( 0, 0, 0, 255 ) )
        end
        if ( v:Alive() && v != LocalPlayer() && v:Team() == 1 && !(v.HatTraitor) && !v:IsDetective()) then
            local pos = ( v:GetPos()):ToScreen() 
            draw["SimpleTextOutlined"]( v:Nick() .. " - Unknown", "default", pos.x, pos.y, team["GetColor"]( v:Team() ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, Color( 0, 0, 0, 255 ) )
        end
        if ( v:Alive() && v != LocalPlayer() && v:IsDetective()) then
            local pos = ( v:GetPos()):ToScreen() 
            draw["SimpleTextOutlined"]( v:Nick() .. " - DETECTIVE", "default", pos.x, pos.y, Color(0, 100, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, Color( 0, 0, 0, 255 ) )
        end
    end
else
        if ( v:Alive() && v != LocalPlayer()) then
            local pos = ( v:GetPos()):ToScreen() 
            draw["SimpleTextOutlined"]( v:Nick() .. " - " .. v:Health(), "default", pos.x, pos.y, Color(0, 100, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, Color( 0, 0, 0, 255 ) )
        end
end
end
for _,v in pairs(player.GetAll()) do
        v.HatTraitor = nil
end
for _,v in pairs(ents.GetAll()) do
        v.HatESPTracked = nil
end
function hooks()
if gmod["GetGamemode"]()["Name"]:lower() == "trouble in terrorist town" then
SH["AddHook"]("PostDrawOpaqueRenderables", function()
        if GAMEMODE.round_state != ROUND_ACTIVE then
                for _,v in pairs(player.GetAll()) do
                        v.HatTraitor = nil
                end
                for _,v in pairs(ents.GetAll()) do
                        v.HatESPTracked = nil
                end
                return
        end
        for _,v in pairs( ents.GetAll() ) do
                if v and IsValid(v) and (table.HasValue(SH["twep"], v:GetClass()) and !v.HatESPTracked) then
                        local pl = v.Owner
                        if pl and IsValid(pl) and pl:IsTerror() then
                                if pl:IsDetective() then
                                        v.HatESPTracked = true
                                else
                                        v.HatESPTracked = true
                                        pl.HatTraitor = true
                                        chat.AddText( pl, Color(255,125,0), " is a " .. "traitor",Color(255,125,0), " with a " .. v:GetClass()..", they are now added to ESP.")
                                end
                        end
                end
        end
          end)
end
SH["AddHook"]( "HUDPaint", SH.esp )
end
hooks()