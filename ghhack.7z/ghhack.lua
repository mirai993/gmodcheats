/*
      __          __                       __         
     /\ \        /\ \                     /\ \        
   __\ \ \___    \ \ \___      __      ___\ \ \/'\    
 /'_ `\ \  _ `\   \ \  _ `\  /'__`\   /'___\ \ , <    
/\ \L\ \ \ \ \ \   \ \ \ \ \/\ \L\.\_/\ \__/\ \ \\`\  
\ \____ \ \_\ \_\   \ \_\ \_\ \__/.\_\ \____\\ \_\ \_\
 \/___L\ \/_/\/_/    \/_/\/_/\/__/\/_/\/____/ \/_/\/_/
   /\____/                                            
   \_/__/                                             

	CREDITS:

	1. Blue Kirby for the chams and some bypassing & one function
	2. Me for everything else
*/


local GH = {}
GH.A = false;
GH.Ents = {
	"money_printer",
	"spawned_shipment",
	"spawned_weapon",
	"spawned_money"
}
GH.HellNo = {
	"gh.lua",
	"gmcl_cvar3_win32.dll"
}

function GH.Copy(orig)
    local orig_type = type(orig)
    local copy
    if orig_type == 'table' then
        copy = {}
        for orig_key, orig_value in pairs(orig) do
            copy[orig_key] = orig_value
        end
    else
        copy = orig
    end
    return copy
end

local _G = GH.Copy(_G);
local math = _G.math;
local hook = _G.hook;
local timer = _G.timer;
local surface = _G.surface;
local player = _G.player;
local ents = _G.ents;
local table = _G.table;
local cam = _G.cam;
local render = _G.render;
local team = _G.team;
local IN_SPEED = _G.IN_SPEED
local string = _G.string
local concommand = _G.concommand
local util = _G.util
local input = _G.input
local IN_ATTACK = _G.IN_ATTACK
local tostring = _G.tostring;
local GetPos = _G.GetPos;
local ToScreen = _G.ToScreen;
local Nick = _G.Nick;
local GetClass = _G.GetClass;
local CreateMaterial = _G.CreateMaterial;
local EyePos = _G.EyePos;
local EyeAngles = _G.EyeAngles;
local Team = _G.Team;
local DrawModel = _G.DrawModel;
local IsValid = _G.IsValid;
local GetActiveWeapon = _G.GetActiveWeapon;
local LocalPlayer = _G.LocalPlayer;
local SetEyeAngles = _G.SetEyeAngles;
local RunConsoleCommand = _G.RunConsoleCommand;
local require = _G.require;
local GetConVarNumber = _G.GetConVarNumber;
local CreateClientConVar = _G.CreateClientConVar;
local MsgN = _G.MsgN;
local GetConVar = _G.GetConVar;
local GetString = _G.GetString;
local GetAimVector = _G.GetAimVector;
local Vector = _G.Vector;
local SelectWeapon = _G.SelectWeapon;
local Spawn = _G.Spawn;
local SetModel = _G.SetModel;
local SetPos = _G.SetPos;
local SetAngles = _G.SetAngles;
local KeyDown = _G.KeyDown;
local SetSize = _G.SetSize;
local Center = _G.Center;
local SetTitle = _G.SetTitle;
local SetPos = _G.SetPos;
local EnableHorizontal = _G.EnableHorizontal;
local EnableVerticalScrollbar = _G.EnableVerticalScrollbar;
local SetValue = _G.SetValue;
local SetConVar = _G.SetConVar;
local AddItem = _G.AddItem;
local GetBonePosition = _G.GetBonePosition;
local LookupBone = _G.LookupBone;
local GetAbsVelocity = _G.GetAbsVelocity;
local Angle = _G.Angle;
local IsPlayer = _G.IsPlayer;
local Health = _G.Health;
local Alive = _G.Alive;
local SetEyeAngles = _G.SetEyeAngles;
local SetImage = _G.SetImage;
local Remove = _G.Remove;
local Material = _G.Material;

local old_tostring = tostring;
local old_mathrandom = math.random;
local old_hookadd = hook.Add;
local old_timercreate = timer.Create;
local old_timersimple = timer.Simple;
local old_setdrawcolor = surface.SetDrawColor;
local old_setfont = surface.SetFont;
local old_pgetall = player.GetAll;
local old_gettextsize = surface.GetTextSize;
local old_drawrect = surface.DrawRect;
local old_settextcolor = surface.SetTextColor;
local old_settextpos = surface.SetTextPos;
local old_drawtext = surface.DrawText;
local old_egetall  = ents.GetAll;
local old_hasvalue = table.HasValue;
local old_creatematerial = CreateMaterial;
local old_teamgetcolor = team.GetColor;
local old_camstart3d = cam.Start3D;
local old_suppresslighting = render.SuppressEngineLighting;
local old_setcolormodulation = render.SetColorModulation;
local old_materialoverride = render.MaterialOverride;
local old_isvalid = IsValid;
local old_setmodellighting = render.SetModelLighting;
local old_camend3d = cam.End3D;
local old_angle = Angle;
local old_fileexists = file.Exists;
local old_require = require;
local old_runconsolecommand = RunConsoleCommand;
local old_getconvarnumber = GetConVarNumber;
local old_createclientconvar = CreateClientConVar;
local old_msgn = MsgN;
local old_entscreate = ents.Create;
local old_getconvar = GetConVar;
local old_vector = Vector;
local old_mathcos = math.cos;
local old_mathsin = math.sin;
local old_vguicreate = vgui.Create;
local old_stringchar = string.char;
local old_concommandadd = concommand.Add;
local old_mathabs = math.abs;
local old_mathangledifference = math.AngleDifference;
local old_utiltraceline = util.TraceLine;
local old_tableinsert = table.insert;
local old_setmaterial = surface.SetMaterial;
local old_drawtexturedrect = surface.DrawTexturedRect;
local old_material = Material;
local old_fileread = file.Read;
local old_entsfindinsphere = ents.FindInSphere;
local old_iskeydown = input.IsKeyDown;

function GH.Random()
	return old_tostring(old_mathrandom(1, 5000) .. old_mathrandom(1, 5000) .. old_stringchar(old_mathrandom(1, 52)))
end

function GH.DetourFunc(lib, name, ...)
	if lib == nil then return name(...); end

	return lib(...);
end

function GH.AddHook(hookname, func)
	return GH.DetourFunc(old_hookadd, nil, hookname, GH.Random(), func)
end

function GH.AddTimer(sec, rep, func)
	return GH.DetourFunc(old_timercreate, nil, GH.Random(), sec, rep, func)
end

function GH.AddSimpleTimer(sec, func)
	return GH.DetourFunc(old_timersimple, nil, sec, func)
end

function GH.AddConVar(name, default)
	return GH.DetourFunc(nil, old_createclientconvar, name, default)
end

function GH.AddConCommand(name, func)
	return GH.DetourFunc(old_concommandadd, nil, name, func)
end

function file.Read(name, path)
	if !GH.DetourFunc(old_hasvalue, nil, GH.HellNo, name) then
		return GH.DetourFunc(old_fileread, nil, name, path)
	else
		return [[
		print("Test lua script")
		print("Hello world!")
		]]
	end
end

function file.Exists(name, path)
	if !GH.DetourFunc(old_fileexists, nil, GH.HellNo, name) then
		return GH.DetourFunc(old_fileexists, nil, name, path)
	else
		return false;
	end
end

function GetConVarNumber(convar)
	if ( convar == "host_timescale" ) then
		return "1"
	elseif ( convar == "sv_cheats" ) then
		return "0"
	else
		return GH.DetourFunc(old_getconvarnumber, nil, convar)
	end
end

/*
   ___                                _   _             
  / _ \_ __ ___ _ __   __ _ _ __ __ _| |_(_) ___  _ __  
 / /_)/ '__/ _ \ '_ \ / _` | '__/ _` | __| |/ _ \| '_ \ 
/ ___/| | |  __/ |_) | (_| | | | (_| | |_| | (_) | | | |
\/    |_|  \___| .__/ \__,_|_|  \__,_|\__|_|\___/|_| |_|
               |_|                                      

Functions used for the hack.
*/

function GH.M()
	return old_creatematerial(GH.Random(), "VertexLitGeneric", { 
		["$basetexture"] = "models/debug/debugwhite",
		["$model"] = 1,
		["$ignorez"] = 1 
	});
end

function GH.AddToColor(color, add)
	return color + add <= 255 and color + add or color + add - 255
end

function GH.IsVisible( ply )
	if (!IsValid( ply )) then return false end
	
	local vecPos, _ = ply:GetBonePosition( ply:LookupBone( "ValveBiped.Bip01_Head1" ) or 12 );
	local trace = { start = LocalPlayer():EyePos(), endpos = vecPos, filter = LocalPlayer(), mask = MASK_SHOT };
	local traceRes = GH.DetourFunc(old_utiltraceline, nil, trace);
	
	GH.TraceRes = traceRes;
	
	if (traceRes.HitWorld || traceRes.Entity != ply) then return false end;
	
	return true;
end

function GH.Players()
	local players = {}
	local trace = LocalPlayer():GetEyeTrace()

	for k,v in pairs(GH.DetourFunc(old_entsfindinsphere, nil, trace.HitPos, 500)) do
		if v:IsPlayer() and v ~= LocalPlayer() and v:Alive() and GH.IsVisible(v) then
			players[k] = v
		end
	end

	return players
end

/*
   ___ _                           __  __    ___ 
  / _ \ | __ _ _   _  ___ _ __    /__\/ _\  / _ \
 / /_)/ |/ _` | | | |/ _ \ '__|  /_\  \ \  / /_)/
/ ___/| | (_| | |_| |  __/ |    //__  _\ \/ ___/ 
\/    |_|\__,_|\__, |\___|_|    \__/  \__/\/     
               |___/                             
Pickup players on the screen.
*/

function GH.E()
	if GH.DetourFunc(nil, old_getconvarnumber, "gh_e") == 1 then
		for k,v in pairs(GH.DetourFunc(old_pgetall, nil)) do
			local pos = v:GetPos():ToScreen()

			GH.DetourFunc(old_setfont, nil, "ChatFont")
			local x, y = GH.DetourFunc(old_gettextsize, nil, v:Nick())

			GH.DetourFunc(old_setdrawcolor, nil, 0, 0, 0, 215)
			GH.DetourFunc(old_drawrect, nil, pos.x, pos.y, x, y)

			GH.DetourFunc(old_settextcolor, nil, 255, 255, 255, 255)
			GH.DetourFunc(old_settextpos, nil, pos.x, pos.y)
			GH.DetourFunc(old_drawtext, nil, v:Nick())
		end
	end
end

/*
   __      _   _ _             __  __    ___ 
  /__\ __ | |_(_) |_ _   _    /__\/ _\  / _ \
 /_\| '_ \| __| | __| | | |  /_\  \ \  / /_)/
//__| | | | |_| | |_| |_| | //__  _\ \/ ___/ 
\__/|_| |_|\__|_|\__|\__, | \__/  \__/\/     
                     |___/                   
Picks up entities on the screen.
*/

function GH.EE()
	if GH.DetourFunc(nil, old_getconvarnumber, "gh_ee") == 1 then
		for k,v in pairs(GH.DetourFunc(old_egetall, nil)) do
			if GH.DetourFunc(old_hasvalue, nil, GH.Ents, v:GetClass()) then
				local pos = v:GetPos():ToScreen()

				GH.DetourFunc(old_setfont, nil, "ChatFont")
				local x, y = GH.DetourFunc(old_gettextsize, nil, v:GetClass())

				GH.DetourFunc(old_setdrawcolor, nil, 0, 0, 0, 215)
				GH.DetourFunc(old_drawrect, nil, pos.x, pos.y, x, y)

				GH.DetourFunc(old_settextcolor, nil, 255, 255, 255, 255)
				GH.DetourFunc(old_settextpos, nil, pos.x, pos.y)
				GH.DetourFunc(old_drawtext, nil, v:GetClass())
			end
		end
	end
end

/*
   ___ _                         
  / __\ |__   __ _ _ __ ___  ___ 
 / /  | '_ \ / _` | '_ ` _ \/ __|
/ /___| | | | (_| | | | | | \__ \
\____/|_| |_|\__,_|_| |_| |_|___/
                                 
See players through walls.

Credits:
Blue Kirby
*/

function GH.C()
	if GH.DetourFunc(nil, old_getconvarnumber, "gh_ch") == 1 then
		for k,ply in pairs(GH.DetourFunc(old_pgetall, nil)) do
			local color = GH.DetourFunc(old_teamgetcolor, nil, ply:Team())
			GH.DetourFunc(old_camstart3d, nil, EyePos(), EyeAngles());
					GH.DetourFunc(old_suppresslighting, nil, true);
					GH.DetourFunc(old_setcolormodulation, nil, color.r/255, color.g/255, color.b/255, 1 );
					GH.DetourFunc(old_materialoverride, nil, GH.M());
					ply:DrawModel();
					GH.DetourFunc(old_setcolormodulation, nil, GH.AddToColor( color.r, 150 )/255, GH.AddToColor( color.g, 150 )/255, GH.AddToColor( color.b, 150 )/255, 1);
					
					if (old_isvalid(ply:GetActiveWeapon())) then
						ply:GetActiveWeapon():DrawModel();
					end
					
					GH.DetourFunc(old_materialoverride, nil);
					GH.DetourFunc(old_setmodellighting, nil, 4, color.r/255, color.g/255, color.b/255);
					ply:DrawModel();
					GH.DetourFunc(old_suppresslighting, nil, false);
			GH.DetourFunc(old_camend3d, nil)
		end
	end
end

/*
 __                     _                  _    
/ _\_ __   ___  ___  __| | /\  /\__ _  ___| | __
\ \| '_ \ / _ \/ _ \/ _` |/ /_/ / _` |/ __| |/ /
_\ \ |_) |  __/  __/ (_| / __  / (_| | (__|   < 
\__/ .__/ \___|\___|\__,_\/ /_/ \__,_|\___|_|\_\
   |_|                                          
Zoom Zoom.
*/

function GH.S()
	if GH.DetourFunc(nil, old_getconvarnumber, "gh_s") == 1 then
		GH.DetourFunc(old_require, nil, "cvar3")

		GH.DetourFunc(old_getconvar, nil, "sv_cheats"):SetValue(1)
		GH.DetourFunc(old_getconvar, nil, "host_timescale"):SetValue(10)
	end
end

function GH.OS()
	if GH.DetourFunc(nil, old_getconvarnumber, "gh_s") == 1 then	
		GH.DetourFunc(old_require, nil, "cvar3")

		GH.DetourFunc(old_getconvar, nil, "sv_cheats"):SetValue(0)
		GH.DetourFunc(old_getconvar, nil, "host_timescale"):SetValue(1)
	end
end

/*
           _           _           _   
     /\   (_)         | |         | |  
    /  \   _ _ __ ___ | |__   ___ | |_ 
   / /\ \ | | '_ ` _ \| '_ \ / _ \| __|
  / ____ \| | | | | | | |_) | (_) | |_ 
 /_/    \_\_|_| |_| |_|_.__/ \___/ \__|
                                       
                                       
Aiming
*/

function GH.Aim()
	if ( GH.DetourFunc(old_getconvarnumber, nil, "gh_a") == 1 and GH.DetourFunc(old_iskeydown, nil, KEY_B) ) then
		for k,v in pairs(GH.Players()) do
			local head = v:LookupBone("ValveBiped.Bip01_Head1")
			local headpos, headang = v:GetBonePosition(head)

			LocalPlayer():SetEyeAngles((headpos - LocalPlayer():GetShootPos()):Angle())
		end
	end
end

/*
                         
  /\/\   ___ _ __  _   _ 
 /    \ / _ \ '_ \| | | |
/ /\/\ \  __/ | | | |_| |
\/    \/\___|_| |_|\__,_|
                         
Nice and fancy
*/

function GH.Menu()
	local a = GH.DetourFunc(old_vguicreate, nil, "DPanel")
	a:SetSize(175, 115)
	a:Center()
	a:MakePopup()
	a.Paint = function()
		GH.DetourFunc(old_setdrawcolor, nil, 0, 0, 0, 190)
		GH.DetourFunc(old_drawrect, nil, 0, 0, a:GetWide(), a:GetTall())

		GH.DetourFunc(old_setdrawcolor, nil, 0, 0, 0, 225)
		GH.DetourFunc(old_drawrect, nil, 0, 0, a:GetWide(), 25)

		GH.DetourFunc(old_settextcolor, nil, 255, 255, 255, 255)
		GH.DetourFunc(old_settextpos, nil, 5, 2)
		GH.DetourFunc(old_setfont, nil, "ChatFont")
		GH.DetourFunc(old_drawtext, nil, "[GH] Menu")
	end

	local close = GH.DetourFunc(old_vguicreate, nil, "DImageButton", a)
	close:SetPos(a:GetWide() - 18, 2)
	close:SetSize(16, 16)
	close:SetImage("icon16/cross.png")
	close.DoClick = function()
		a:Remove()
	end

	local b = GH.DetourFunc(old_vguicreate, nil, "DPanelList", a)
	b:SetPos(5, 30)
	b:SetSize(165, 80)
	b:EnableHorizontal(false)
	b:EnableVerticalScrollbar(true)

	local c = GH.DetourFunc(old_vguicreate, nil, "DCheckBoxLabel")
	c:SetText("ESP")
	c:SetConVar("gh_e")
	b:AddItem(c)

	local d = GH.DetourFunc(old_vguicreate, nil, "DCheckBoxLabel")
	d:SetText("ESP Ents")
	d:SetConVar("gh_ee")
	b:AddItem(d)

	local e = GH.DetourFunc(old_vguicreate, nil, "DCheckBoxLabel")
	e:SetText("Chams")
	e:SetConVar("gh_ch")
	b:AddItem(e)

	local f = GH.DetourFunc(old_vguicreate, nil, "DCheckBoxLabel")
	f:SetText("SpeedHack")
	f:SetConVar("gh_s")
	b:AddItem(f)

	local e = GH.DetourFunc(old_vguicreate, nil, "DCheckBoxLabel")
	e:SetText("Aimbot")
	e:SetConVar("gh_a")
	b:AddItem(e)
end

/*
  _____       _ _   _       _ _          _   _             
  \_   \_ __ (_) |_(_) __ _| (_)______ _| |_(_) ___  _ __  
   / /\/ '_ \| | __| |/ _` | | |_  / _` | __| |/ _ \| '_ \ 
/\/ /_ | | | | | |_| | (_| | | |/ / (_| | |_| | (_) | | | |
\____/ |_| |_|_|\__|_|\__,_|_|_/___\__,_|\__|_|\___/|_| |_|
                                                           
When the hack loads up.
*/

function GH.LoadHooks()
	GH.AddHook("HUDPaint", GH.E)
	GH.AddHook("HUDPaint", GH.EE)
	GH.AddHook("RenderScreenspaceEffects", GH.C)
	GH.AddHook("Think", GH.Aim)
end

function GH.LoadConVars()
	GH.AddConVar("gh_e", "0")
	GH.AddConVar("gh_ee", "0")
	GH.AddConVar("gh_ch", "0")
	GH.AddConVar("gh_s", "0")
	GH.AddConVar("gh_a", "0")
end

function GH.LoadConCommands()
	GH.AddConCommand("gh_m", GH.Menu)
	GH.AddConCommand("+gh_s", GH.S)
	GH.AddConCommand("-gh_s", GH.OS)
end

function GH.Bypass()
	-- DAZ anti cheat
	for i = 100, 100000 do
		hook.Remove("Think", tostring( i ))
	end

	-- stronghold anti-cheat
	hook.Remove("Think", "PlayerInfoThing")

	-- gmodz anti cheat
	timer.Destroy("AntiCheatTimer")
	timer.Destroy("testing123")

	-- sammy servers anti cheat
	hook.Add("Think", "sh_menu", function()
		return true
	end)
	hook.Remove("Think", "sh_menu")
end

function GH.Init()
	GH.DetourFunc(old_msgn, nil, "[GH] Initializing...")
	GH.DetourFunc(old_msgn, nil, "[GH] Loaded Version: 1.51")
	GH.DetourFunc(old_msgn, nil, "[GH] Adding Hooks...")
	GH.LoadHooks()
	GH.DetourFunc(old_msgn, nil, "[GH] Hooks loaded.")
	GH.DetourFunc(old_msgn, nil, "[GH] Adding ConVars...")
	GH.LoadConVars()
	GH.DetourFunc(old_msgn, nil, "[GH] ConVars loaded.")
	GH.DetourFunc(old_msgn, nil, "[GH] Loading ConCommands...")
	GH.LoadConCommands()
	GH.DetourFunc(old_msgn, nil, "[GH] ConCommands loaded.")
	GH.DetourFunc(old_msgn, nil, "[GH] Bypassing specific anti-cheats. Expect lag.")
	GH.Bypass()
	GH.DetourFunc(old_msgn, nil, "[GH] Bypassed.")
	GH.DetourFunc(old_msgn, nil, "[GH] Initialized.")
end
GH.Init()