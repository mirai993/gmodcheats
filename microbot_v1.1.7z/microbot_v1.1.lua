--[[
	EXECUTABLE_PATH/scripts/Micro.lua
	-=TRR- is Up=Dayzlayer | STEAM_0:1:65860748 <86.169.139.24:27005> | [19-10-13 04:18:47PM]
	===BadFile===
]]

--[[***DO NOT RELEASE - PRIVATE SCRIPT***]]--

--[[CREDITS: Capt. Micro - all of the things]]--

if (SERVER) then Error("MICROBOT.MAIN: ERROR: WILL CRASH") end

local oldPrint = print
local print = function(str)
	oldPrint("MICROBOT.MAIN: " .. tostring(str))
end

--[[FIX COLOR]]--
if (_G['Color'] == nil) then --if Color() doesn't exists
	_G['Color'] = function(r, g, b, a)
		a = a or 255
		return {r = tonumber(r), g = tonumber(g), b = tonumber(b), a = tonumber(a)}
	end
end

--[[VARIABLES]]--
local ubot = {}

	--[[USER OPTIONS]]--
	ubot.IncludeAimCmd = false	--TRUE to create +/-ubot_viser concommand
								--NOTE: this will disable the "DisableAimKey"
	ubot.ToggleAimKey = KEY_K
	ubot.ShowGUIKey = KEY_L
	--[[USER OPTIONS]]--

--[[DO NOT EDIT]]--
ubot.lp = LocalPlayer()
ubot.scr = {['w'] = ScrW(), ['h'] = ScrH(), ['hw'] = ScrW() / 2, ['hh'] = ScrH() / 2}
local timer = timer
local hook = hook
local team = team
local surface = surface
local render = render
local string = string
local vgui = vgui
local math = math
local util = util
local cam = cam
local SetMaterialOverride = SetMaterialOverride
local RunConsoleCommand = RunConsoleCommand --fon.ec_ClientCmd_Unrestricted
local ValidEntity = ValidEntity
local HSVToColor = HSVToColor
local tostring = tostring
local IsValid = IsValid
local Vector = Vector
local Color = Color
local pairs = pairs
local type = type

--[[USEFULL]]--
string.random = function(minl, maxl)
	local tempstr = ""
	for i=0,math.random(minl,maxl) do
		local c = math.random(65,116)
		if (c >= 91) && (c <= 96) then c = c + 6 end
		tempstr = tempstr .. string.char(c)
	end
	return tempstr
end

ubot.nums2vec = function(x,y,z) return Vector(x,y,z) end
ubot.nums2ang = function(p,y,r) return Angle(p,y,r) end
ubot.IsFriend = function(ent) return (ent:GetFriendStatus() == 'friend') end
ubot.GetBonePos = function(ent, bone) return ent:GetBonePosition(ent:LookupBone(bone)) end
ubot.Distance = function(ent) return ubot.lp:GetShootPos():Distance(ent:GetPos()) end
ubot.num2vec = function(num) return Vector(num, num, num) end

ubot.NormalizeAngle = function(a)
	a = a % 360
	return (a > 180) and a - 360 or a
end

ubot.InFOV = function(ent, fov)
	local lpos = ubot.lp:WorldToLocal(ubot.lp:OBBCenter())
	local epos = ent:WorldToLocal(ent:OBBCenter())
	local ang = (epos - lpos):Angle()
	local currang = ubot.lp:EyeAngles()
	ang.p = math.NormalizeAngle(ang.p)
	ang.y = math.NormalizeAngle(ang.y)
	currang.p = math.NormalizeAngle(currang.p)
	currang.y = math.NormalizeAngle(currang.y)
	local diffP = math.abs(math.abs(currang.p) - math.abs(ang.p))
	local diffY = math.abs(math.abs(currang.y) - math.abs(ang.y))
	if (diffP > fov) or (diffY > fov) then return false end
	return true
end

ubot.IsBehindWall = function(ent)
	local tr = util.GetPlayerTrace(ubot.lp, ubot.lp:EyePos() - ent:LocalToWorld(ent:OBBCenter()))
	return not (tr.Entity == ent)
end

ubot.IsValid = function(ent)
	if (not IsValid(ent)) then return false end
	if (ent == ubot.lp) then return false end
	if ent:IsWorld() then return false end
	if ent:IsWeapon() then return false end
	if (ent:GetMoveType() == MOVETYPE_NONE) then return false end
	if (ent:GetMoveType() == MOVETYPE_OBSERVER) then return false end
	if ent:IsPlayer() then
		if ubot.config.get('misc', 'Target Steam Friends') then
			return ent:Alive()
		else return (ent:Alive() and (not ubot.IsFriend(ent))) end
	end
	return true
end

ubot.ClientIsCrouching = function()
	if ubot.lp:KeyDown(IN_DUCK) and ubot.ClientOnGround() then
		return true
	end
	return false
end

ubot.ClientOnGround = function()
	local ground = ubot.lp:GetGroundEntity()
	if IsValid(ground) or ground:IsWorld() or ubot.lp:IsOnGround() then
		return true
	end
	return false
end

--[[HOOKS]]--
ubot.hooks = {}

ubot.AddHook = function(event_name, name, func)
	if (ubot.hooks[event_name] == nil) then ubot.hooks[event_name] = {} end
	ubot.hooks[event_name][name] = string.random(4,10)
	hook.Add(event_name, ubot.hooks[event_name][name], func)
	print("ADDED HOOK ["..event_name.."]["..name.."] = "..tostring(func))
end

ubot.RemoveHook = function(event_name, name, func)
	hook.Remove(event_name, ubot.hooks[event_name][name])
	print("REMOVED HOOK ["..event_name.."]["..name.."]")
	ubot.hooks[event_name][name] = nil
end

--[[CONFIG]]--
ubot.config = {}

ubot.config.get = function(cfg, key)
	return ubot.config[cfg][key] or false
end

ubot.config.save = function()
	--[[AimCfg = util.TableToKeyValues(ubot.config.aimbot)
	EspCfg = util.TableToKeyValues(ubot.config.esp)
	MiscCfg = util.TableToKeyValues(ubot.config.misc)
	file.Write("microbot.aimcfg.txt", AimCfg)
	file.Write("microbot.espcfg.txt", EspCfg)
	file.Write("microbot.misccfg.txt", MiscCfg)--]]
end

ubot.config.load = function()
	--[[AimCfg = file.Read("microbot.aimcfg.txt")
	EspCfg = file.Read("microbot.espcfg.txt")
	MiscCfg = file.Read("microbot.misccfg.txt")
	ubot.config.aimbot = util.KeyValuesToTable(AimCfg)
	ubot.config.esp = util.KeyValuesToTable(EspCfg)
	ubot.config.misc = util.KeyValuesToTable(MiscCfg)--]]
end

ubot.config.aimbot = {
{['Enabled'] = false},
{['Method'] = {'None', 'All', 'Sphere', 'InFOV', 'LockOn', 'AllNoWall', 'SphereNoWall'}},
{['Method Var'] = 512},
{['Trigger Bot'] = false},
{['Predict Spread'] = false},
{['Friendly Fire'] = false},
{['Include Players'] = false},
{['Include NPCs'] = false},
{['Include Props'] = false},
{['Bone'] = {'head','neck','chest','crotch'}},
{['No Shake'] = false},
}

ubot.config.esp = {
{['Enabled'] = false},
{['Include Friendly'] = false},
{['Include Players'] = false},
{['Include NPCs'] = false},
{['Include Props'] = false},
{['Show Name'] = false},
{['Show Health'] = false},
{['Show Armor'] = false},
{['Show Distance'] = false},
{['Custom Crosshair'] = false},
{['BHOP Enabled'] = false}
}

ubot.config.misc = {
{['ESP Default'] = Color(255,0,0)},
{['ESP Crosshair'] = Color(255,0,0)},
{['ESP Text'] = Color(0,0,255)},
{['ESP Text Spacing'] = 2},
{['ESP Font'] = {'DebugFixed','DebugFixedSmall','DefaultFixedOutline','MenuItem','Default','TabLarge',
'DefaultBold','DefaultUnderline','DefaultSmall','DefaultSmallDropShadow','DefaultVerySmall',
'DefaultLarge','UiBold','MenuLarge','ConsoleText','Marlett','Trebuchet18','Trebuchet19',
'Trebuchet20','Trebuchet22','Trebuchet24','HUDNumber','HUDNumber1','HUDNumber2','HUDNumber3',
'HUDNumber4','HUDNumber5','HudHintTextLarge','HudHintTextSmall','CenterPrintText',
'HudSelectionText','DefaultFixed','DefaultFixedDropShadow','CloseCaption_Normal',
'CloseCaption_Bold','CloseCaption_BoldItalic','TitleFont','TitleFont2','ChatFont','TargetID',
'TargetIDSmall','HL2MPTypeDeath','BudgetLabel'}},
{['Target Steam Friends'] = false},
{['Screenshot/Demo Protection'] = true},
}

ubot.config.bones = {
	["head"] = {
		['default'] = "ValveBiped.Bip01_Head1",
		['folder:zombie'] = "ValveBiped.HC_Body_Bone",
		['mdl:fast.mdl'] = "ValveBiped.HC_BodyCube",
		['mdl:poison.mdl'] = "ValveBiped.Headcrab_Cube1",
		['mdl:manhack.mdl'] = "Manhack.MH_Control",
		['mdl:combine_scanner.mdl'] = "Scanner.Body",
		['mdl:barnacle.mdl'] = "Barnacle.innards",
		['mdl:combine_helicopter.mdl'] = "Chopper.Body",
		['mdl:combine_strider.mdl'] = "Combine_Strider.Body_Bone",
		['mdl:combine_dropship.mdl'] = "D_ship.Pelvis",
		['mdl:gunship.mdl'] = "Gunship.Body",
		['mdl:pigeon.mdl'] = "Crow.Head"
	},
	["neck"] = {
		['default'] = "ValveBiped.Bip01_Neck1",
		['folder:zombie'] = "ValveBiped.HC_Body_Bone",
		['mdl:fast.mdl'] = "ValveBiped.Bip01_Spine4",
		['mdl:poison.mdl'] = "ValveBiped.Headcrab_Cube1",
		['mdl:headcrabblack.mdl'] = "HCblack.body",
		['mdl:headcrabclassic.mdl'] = "HeadcrabClassic.BodyControl",
		['mdl:headcrab.mdl'] = "HCfast.body",
		['mdl:manhack.mdl'] = "Manhack.MH_Control",
		['mdl:combine_scanner.mdl'] = "Scanner.Body",
		['mdl:barnacle.mdl'] = "Barnacle.body",
		['mdl:combine_helicopter'] = "Chopper.Body",
		['mdl:combine_strider'] = "Combine_Strider.Body_Bone",
		['mdl:combine_dropship'] = "D_ship.Pelvis",
		['mdl:gunship.mdl'] = "Gunship.Body",
		['mdl:pigeon.mdl'] = "Crow.Head"
	},
	["chest"] = {
		['default'] = "ValveBiped.Bip01_Spine2",
		['mdl:headcrabblack.mdl'] = "HCblack.body",
		['mdl:headcrabclassic.mdl'] = "HeadcrabClassic.BodyControl",
		['mdl:headcrab.mdl'] = "HCfast.body",
		['mdl:manhack.mdl'] = "Manhack.MH_Control",
		['mdl:combine_scanner.mdl'] = "Scanner.Body",
		['mdl:barnacle.mdl'] = "Barnacle.body",
		['mdl:combine_helicopter'] = "Chopper.Body",
		['mdl:combine_strider'] = "Combine_Strider.Body_Bone",
		['mdl:combine_dropship'] = "D_ship.Pelvis",
		['mdl:gunship.mdl'] = "Gunship.Body",
		['mdl:pigeon.mdl'] = "Crow.Body"
	},
	["crotch"] = {
		['default'] = "ValveBiped.Bip01_Pelvis",
		['folder:zombie'] = "ValveBiped.Bip01_Spine",
		['mdl:headcrabblack.mdl'] = "HCblack.body",
		['mdl:headcrabclassic.mdl'] = "HeadcrabClassic.BodyControl",
		['mdl:headcrab.mdl'] = "HCfast.body",
		['mdl:manhack.mdl'] = "Manhack.MH_Control",
		['mdl:combine_scanner.mdl'] = "Scanner.Body",
		['mdl:barnacle.mdl'] = "Barnacle.body",
		['mdl:combine_helicopter'] = "Chopper.Body",
		['mdl:combine_strider'] = "Combine_Strider.Body_Bone",
		['mdl:combine_dropship'] = "D_ship.Pelvis",
		['mdl:gunship.mdl'] = "Gunship.Body",
		['mdl:pigeon.mdl'] = "Crow.Body"
	}
}

--[[AIMBOT]]--
ubot.aimbot = {}
ubot.aimbot.shooting = false
ubot.aimbot.nextshot = 0
ubot.aimbot.starget = nil
ubot.aimbot.currSeed = 0

ubot.aimbot.AimCmdOn = false
ubot.aimbot.PlusAimCmd = function(ply, cmd, args)
	ubot.aimbot.AimCmdOn = true
end
ubot.aimbot.MinusAimCmd = function(ply, cmd, args)
	ubot.aimbot.AimCmdOn = false
	ubot.aimbot.shooting = false
	ubot.aimbot.starget = nil
end
if (ubot.IncludeAimCmd) then
	concommand.Remove("+ubot_viser")
	concommand.Remove("-ubot_viser")
	concommand.Add("+ubot_viser", ubot.aimbot.PlusAimCmd)
	concommand.Add("-ubot_viser", ubot.aimbot.MinusAimCmd)
end

ubot.aimbot.IsValid = function(ent)
	if (not ubot.IsValid(ent)) then return false end
	if ent:IsPlayer() and ubot.config.get('aimbot', 'Include Players') then
		if (ent:Team() == ubot.lp:Team()) then
			return ubot.config.get('aimbot', 'Friendly Fire')
		else return true end
	elseif ent:IsNPC() then
		return IsFriendEntityName(ent:GetClass()) and
			(ubot.config.get('aimbot', 'Include NPCs') and
			ubot.config.get('aimbot', 'Friendly Fire')) or
			ubot.config.get('aimbot', 'Include NPCs')
	elseif (not ent:IsPlayer()) and (not ent:IsNPC()) then
		return ubot.config.get('aimbot', 'Include Props')
	end
	return false
end

ubot.aimbot.methods = {
['None'] = function(x) return {} end,
['All'] = function(x) return ents.GetAll() end,
['Sphere'] = function(x) return ents.FindInSphere(ubot.lp:GetShootPos(), x or 512) end,
['InFOV'] = function(x)
	local prechk = ents.GetAll()
	local result = {}
	for k,v in pairs(prechk) do
		if (ubot.aimbot.IsValid(v)) then
			if ubot.InFOV(v, x) then table.insert(result, v) end
		end
	end
	return result
end,
['_LockOn'] = nil, ['LockOn'] = function(x)
	if (not ubot.IsValid(ubot.aimbot.methods["_LockOn"])) then
		ubot.aimbot.methods["_LockOn"] = ubot.lp:GetEyeTrace().Entity
	end
	if ubot.IsValid(ubot.aimbot.methods["_LockOn"]) and ubot.lp:Alive() then
		return {ubot.aimbot.methods["_LockOn"]}
	end
	return {}
end,
['AllNoWall'] = function(x)
	local prechk = ents.GetAll()
	local result = {}
	for k,v in pairs(prechk) do
		if (ubot.aimbot.IsValid(v)) then
			if not ubot.IsBehindWall(v) then table.insert(result, v) end
		end
	end
	return result
end,
['SphereNoWall'] = function(x)
	local prechk = ents.FindInSphere(ubot.lp:GetShootPos(), x or 512)
	local result = {}
	for k,v in pairs(prechk) do
		if (ubot.aimbot.IsValid(v)) then
			if not ubot.IsBehindWall(v) then table.insert(result, v) end
		end
	end
	return result
end
}

ubot.aimbot.GetAimPos = function(ent)
	if (ent == nil) or (not ubot.aimbot.IsValid(ent)) then return Vector(0,0,0) end
	local bones = ubot.config.bones[ubot.config.get('aimbot', 'Bone') or 'head']
	local exp = string.Explode('/', string.lower(ent:GetModel()))
	if (#exp ~= 3) then
		if ent:IsPlayer() or ent:IsNPC() then
			return ubot.GetBonePos(ent, bones['default'])
		else
			return ent:LocalToWorld(ent:OBBCenter())
		end
	end
	if (bones['mdl:'..exp[3]] ~= nil) then
		return ubot.GetBonePos(ent, bones['mdl:'..exp[3]])
	elseif (bones['folder:'..exp[2]] ~= nil) then
		return ubot.GetBonePos(ent, bones['folder:'..exp[2]])
	else
		return ubot.GetBonePos(ent, bones['default'])
	end
end

GetBoneName = function(lookup, section, ent)
	local bones = bones[section or 'head'] --default to head
	local expmdl = string.Explode('/', string.lower(ent:GetModel()))
	if (#expmdl ~= 3) then
		if ent:IsPlayer() or ent:IsNPC() then
			return ubot.GetBonePos(ent, bones['default'])
		else
			return ent:LocalToWorld(ent:OBBCenter())
		end
	end
	if (bones['mdl:'..expmdl[3]] ~= nil) then
		return bones['mdl:'..expmdl[3]]
	elseif (bones['folder:'..expmdl[2]] ~= nil) then
		return bones['folder:'..exp[2]]
	else
		return bones['default']
	end
end

ubot.aimbot.CrossbowFix = function(aimpos, target)
	if (ubot.lp:GetActiveWeapon().GetPrintName ~= nil) then
		if (ubot.lp:GetActiveWeapon():GetPrintName() == "#HL2_Crossbow") then
			local angp = math.sin((aimpos - ubot.lp:GetShootPos()):Angle().p)
			aimpos = aimpos + Vector(0,0, (ubot.Distance(target) / 244.286) + angp)
			return aimpos
		end
	end
	return aimpos
end

ubot.aimbot.GetCone = function(wep)
	local cone = wep.Cone
	if (wep.Primary ~= nil) then
		if (wep.Primary.Cone ~= nil) then cone = wep.Primary.Cone end
	end
	if (cone == nil) then cone = 0 end
	
	--ZOMBIE SURVIVAL CONFIG
	if (string.find(GAMEMODE.Name, "Zombie Survival") ~= nil) then
		cone = wep.Cone
		local ironsights = wep:GetNWBool("Ironsights", false)
		if (ironsights) and (wep.ConeIron) then cone = wep.ConeIron end
		if ubot.clientCrouching() and (wep.ConeIronCrouching and wep.ConeCrouching) then
			cone = (ironsights and wep.ConeIronCrouching or wep.ConeCrouching)
		end
		if (not ironsights) and ubot.IsMoving(tbl.lp) and (wep.ConeMoving) then
			cone = wep.ConeMoving
		end
	end
	
	return cone
end

ubot.aimbot.PredictSpread = function(ucmd, ang)
	local cnum = fon.CUserCmd_GetCommandNumber(ucmd)
	if (cnum ~= 0) then
		ubot.aimbot.currSeed = fon.fon_MD5_PseudoRandom(cnum)
	end
	local wep = ubot.lp:GetActiveWeapon()
	local vecCone = ubot.num2vec(ubot.aimbot.GetCone(wep) * -1)
	return fon.fon_ManipulateShot(ubot.aimbot.currSeed or 0,
		(ang or ubot.lp:GetAimVector():Angle()):Forward(), vecCone):Angle()
end

ubot.aimbot.tempAng = nil
ubot.aimbot.nextGUIkey = 0
ubot.aimbot.preAimAng = nil
ubot.aimbot.toggleaim = true
ubot.aimbot.nexttogglekey = 0
ubot.aimbot.CreateMove = function(ucmd)
	if (input.IsKeyDown(ubot.ShowGUIKey) and (CurTime() > ubot.aimbot.nextGUIkey)) then
		if input.IsKeyDown(KEY_DELETE) then
			for k,v in pairs(ubot.hooks) do
				for rk,rv in pairs(v) do
					ubot.RemoveHook(k,rk)
				end
			end
			ubot.gui.frame:SetVisible(false)
			ubot.gui = {}
		else
			if (not ubot.gui.frame:IsVisible()) then
				ubot.gui.frame:SetVisible(true)
				local x, y = ubot.gui.frame:GetPos()
				gui.SetMousePos(x + 25, y + 35)
			else
				ubot.config.save()
				ubot.gui.frame:SetVisible(false)
			end
		end
		ubot.aimbot.nextGUIkey = CurTime() + 0.5
	end
	
	if (not ubot.aimbot.IsValid(ubot.aimbot.starget)) then
		ubot.aimbot.preAimAng = nil
		ubot.aimbot.starget = nil
		ubot.aimbot.methods["_LockOn"] = nil
	end
	
	if ubot.config.get('esp', 'BHOP Enabled') and (bit.band(ucmd:GetButtons(), IN_JUMP) > 0) then
		if not ubot.ClientOnGround() then
			ucmd:SetButtons(bit.band(ucmd:GetButtons(), bit.bnot(IN_JUMP)))
		end
	end
	
	if ubot.config.get('aimbot', 'Trigger Bot') and ubot.aimbot.IsValid(ubot.lp:GetEyeTrace().Entity) then
		if (ubot.aimbot.nextshot < CurTime()) and IsValid(ubot.lp:GetActiveWeapon()) then
			ubot.aimbot.nextshot = (ubot.lp:GetActiveWeapon().Primary
				and ubot.lp:GetActiveWeapon().Primary.Delay or 0.1)
			ucmd:SetButtons(bit.bor(ucmd:GetButtons(), IN_ATTACK))
		else
			ucmd:SetButtons(bit.band(ucmd:GetButtons(), bit.bnot(IN_ATTACK)))
		end
	end
	
	if ubot.config.get('aimbot', 'Enabled') then
		if (not ubot.lp:Alive()) then ubot.aimbot.methods['_LockOn'] = nil end
		local aimang = nil
		
		if (input.IsKeyDown(ubot.ToggleAimKey) and (CurTime() > ubot.aimbot.nexttogglekey)) then
			ubot.aimbot.toggleaim = not ubot.aimbot.toggleaim
			ubot.aimbot.nexttogglekey = CurTime() + 0.2
		end
		
		local AimDisabled = false
		if (ubot.IncludeAimCmd) then
			AimDisabled = not ubot.aimbot.AimCmdOn
		elseif (not ubot.aimbot.toggleaim) then
			AimDisabled = true
		end
	
		
		if (not AimDisabled) then
			local xvar = ubot.config.get('aimbot', 'Method Var') or 0
			local _targets = ubot.aimbot.methods[ubot.config.get('aimbot', 'Method') or 'None'](xvar) or {}
			local targets = {}
			for k,v in pairs(_targets) do if ubot.aimbot.IsValid(v) then table.insert(targets, v) end end
			table.sort(targets, function(a,b) return ubot.Distance(a) < ubot.Distance(b) end)
			if (#targets ~= 0) and (targets ~= nil) then
				ubot.aimbot.starget = targets[1]
				if (ubot.aimbot.starget ~= nil) and ubot.aimbot.IsValid(ubot.aimbot.starget) then
					local aimpos = ubot.aimbot.GetAimPos(ubot.aimbot.starget)
					aimpos = ubot.aimbot.CrossbowFix(aimpos, ubot.aimbot.starget)
					aimang = (aimpos - ubot.lp:GetShootPos()):Angle()
				end
			end
		else
			ubot.aimbot.methods["_LockOn"] = nil
		end
		
		--[[if ubot.lp:GetActiveWeapon().Base == "weapon_cs_base" then
			if ubot.config.get('aimbot', 'Predict Spread') and ucmd:KeyDown(IN_ATTACK) then
				if (aimang == nil) then
					aimang = ubot.lp:EyeAngles()
					if (ubot.aimbot.tempAng == nil) then
						ubot.aimbot.tempAng = ubot.lp:EyeAngles()
					end
					aimang = ubot.aimbot.tempAng
				end
				aimang = ubot.aimbot.PredictSpread(ucmd, aimang)
			else
				if (ubot.aimbot.tempAng ~= nil) then ubot.aimbot.tempAng = nil end
			end
		end]]--
		
		if (aimang ~= nil) then
			ubot.aimbot.preAimAng = ubot.lp:EyeAngles()
			aimang.p = ubot.NormalizeAngle(aimang.p)
			aimang.y = ubot.NormalizeAngle(aimang.y)
			aimang.r = ubot.NormalizeAngle(aimang.r)
			ucmd:SetViewAngles(aimang)
		end
	end
end
ubot.AddHook("CreateMove", "ubot.aimbot.CreateMove", ubot.aimbot.CreateMove)

ubot.aimbot.CalcView = function(ply, pos, ang, fov, nearZ, farZ)
	if (not ubot.config.get('aimbot', 'No Shake')) then return end
	if (ubot.aimbot.preAimAng == nil) then return end
	return {origin = pos, angles = ubot.aimbot.preAimAng, fov = fov, nearZ = nearZ, farZ = farZ}
end
ubot.AddHook("CalcView", "ubot.aimbot.CalcView", ubot.aimbot.CalcView)

--[[ESP]]--
ubot.esp = {}
ubot.esp.matwhite = CreateMaterial("WhiteMaterial", "VertexLitGeneric", {
	['$basetexture'] = 'color/white', ['$vertexalpha'] = '1', ['$model'] = '1'
});

ubot.esp.getcm = function(ent)
	if ent:IsPlayer() then
		local tc = team.GetColor(ent:Team())
		if (tc.a < 50) then return 0, 0, 0 end
		return tc.r/255, tc.g/255, tc.b/255
	else
		local c = ubot.config.get('misc', 'ESP Default')
		if (c ~= false) then return c.r/255, c.g/255, c.b/255
		else return 1, 0, 0 end
	end
end

ubot.esp.IsValid = function(ent)
	if (not ubot.IsValid(ent)) then return false end
	if ent:IsPlayer() and ubot.config.get('esp', 'Include Players') then
		if (ent:Team() == ubot.lp:Team()) then
			return ubot.config.get('esp', 'Include Friendly')
		else return true end
	elseif ent:IsNPC() then
		return IsFriendEntityName(ent:GetClass()) and
			(ubot.config.get('esp', 'Include NPCs') and
			ubot.config.get('esp', 'Friendly Fire')) or
			ubot.config.get('esp', 'Include NPCs')
	elseif (not ent:IsPlayer()) and (not ent:IsNPC()) then
		return ubot.config.get('esp', 'Include Props')
	end
	return false
end

ubot.esp.GetDrawPos = function(ent)
	local bones = ubot.config.bones['head']
	local exp = string.Explode('/', string.lower(ent:GetModel()))
	if (#exp ~= 3) then
		if ent:IsPlayer() or ent:IsNPC() then
			return ubot.GetBonePos(ent, bones['default'])
		else
			return ent:LocalToWorld(ent:OBBCenter())
		end
	end
	if (bones['mdl:'..exp[3]] ~= nil) then
		return ubot.GetBonePos(ent, bones['mdl:'..exp[3]])
	elseif (bones['folder:'..exp[2]] ~= nil) then
		return ubot.GetBonePos(ent, bones['folder:'..exp[2]])
	else
		return ubot.GetBonePos(ent, bones['default'])
	end
end

ubot.esp.PreDrawOpaqueRenderables = function()
	local nodraw = ubot.config.get('esp', 'Enabled')
	
	for k,v in pairs(ents.GetAll()) do
		if ubot.esp.IsValid(v) then
			v:SetNoDraw(nodraw)
			v:CreateShadow()
		end
	end
end
ubot.AddHook("PreDrawOpaqueRenderables", "ubot.esp.PreDOR", ubot.esp.PreDrawOpaqueRenderables)

ubot.esp.PostDrawOpaqueRenderables = function()
	if ubot.config.get('esp', 'Enabled') then
		render.ClearStencil()
		render.SetStencilEnable(true)
		render.SetStencilFailOperation(STENCILOPERATION_KEEP)
		render.SetStencilPassOperation(STENCILOPERATION_KEEP)
		render.SetStencilZFailOperation(STENCILOPERATION_REPLACE)
		render.SetStencilCompareFunction(STENCILCOMPARISONFUNCTION_ALWAYS)
		
		render.SetStencilReferenceValue(1)
		render.SetBlend(0.9) --CLOSE ENOUGH
			for k,v in pairs(ents.GetAll()) do
				if ubot.esp.IsValid(v) then
					local r,g,b = ubot.esp.getcm(v)
					render.SetColorModulation(r or 1,g or 0,b or 0)
						render.MaterialOverride(ubot.esp.matwhite)
							v:DrawModel()
						render.MaterialOverride()
					render.SetColorModulation(1,1,1)
				end
			end
		render.SetBlend(1)
		
		render.SetStencilCompareFunction(STENCILCOMPARISONFUNCTION_EQUAL)
		render.SuppressEngineLighting(true)
			cam.IgnoreZ(true)
				for k,v in pairs(ents.GetAll()) do
					if ubot.esp.IsValid(v) then
						local r,g,b = ubot.esp.getcm(v)
						render.SetColorModulation(r or 1,g or 0,b or 0)
							render.MaterialOverride(ubot.esp.matwhite)
								v:DrawModel()
							render.MaterialOverride()
						render.SetColorModulation(1,1,1)
					end
				end
			cam.IgnoreZ(false)
		render.SuppressEngineLighting(false)
		render.SetStencilEnable(false)
	end
end
ubot.AddHook("PostDrawOpaqueRenderables", "ubot.esp.PDOR", ubot.esp.PostDrawOpaqueRenderables)

ubot.esp.HUDPaint = function()
	if ubot.config.get('esp', 'Enabled') then
		if ubot.config.get('esp', 'Custom Crosshair') then
			local ccgap = 5
			local cclen = ccgap + 10
			local cccol = ubot.config.get('misc', 'ESP Crosshair')
			if (cccol ~= false) then
				surface.SetDrawColor(cccol)
			end
			
			if (cccol == false) then
				local tr = ubot.lp:GetEyeTrace()
				if (not ubot.aimbot.IsValid(tr.Entity)) then
					surface.SetDrawColor(Color(255, 0, 0, 255))
				else
					surface.SetDrawColor(Color(0, 255, 0, 255))
				end
			end
			surface.DrawLine(ubot.scr.hw - cclen, ubot.scr.hh, ubot.scr.hw - ccgap, ubot.scr.hh)
			surface.DrawLine(ubot.scr.hw + cclen, ubot.scr.hh, ubot.scr.hw + ccgap, ubot.scr.hh)
			surface.DrawLine(ubot.scr.hw, ubot.scr.hh - ccgap, ubot.scr.hw, ubot.scr.hh - cclen)
			surface.DrawLine(ubot.scr.hw, ubot.scr.hh + ccgap, ubot.scr.hw, ubot.scr.hh + cclen)
		end
		
		surface.SetFont(ubot.config.get('misc', 'ESP Font') or 'DefaultSmall')
		local spacing = ubot.config.get('misc', 'ESP Text Spacing') or 2
		local tcol = ubot.config.get('misc', 'ESP Text')
		if (not tcol) then tcol = Color(0, 0, 255) end
		surface.SetTextColor(tcol)
		for k,v in pairs(ents.GetAll()) do
			if ubot.esp.IsValid(v) then
				local headpos = v:OBBCenter()
				headpos.z = v:OBBMaxs().z
				headpos = v:LocalToWorld(headpos)
				headpos.z = headpos.z + 10
				headpos = headpos:ToScreen()
				
				if ubot.config.get('esp', 'Show Distance') then
					local text = "Dist: " .. tostring(math.Round(ubot.Distance(v)))
					tw, th = surface.GetTextSize(text)
					surface.SetTextPos(headpos.x - tw/2, headpos.y - th/2)
					surface.DrawText(text)
					headpos.y = headpos.y - th - (spacing - 2)
				end
				if ubot.config.get('esp', 'Show Armor') then
					local text = "Armor: " .. tostring(v.Armor and v:Armor() or 'unknown')
					tw, th = surface.GetTextSize(text)
					surface.SetTextPos(headpos.x - tw/2, headpos.y - th/2)
					surface.DrawText(text)
					headpos.y = headpos.y - th - (spacing - 2)
				end
				if ubot.config.get('esp', 'Show Health') then
					local text = "HP: " .. tostring(v.Health and v:Health() or 'unknown')
					tw, th = surface.GetTextSize(text)
					surface.SetTextPos(headpos.x - tw/2, headpos.y - th/2)
					surface.DrawText(text)
					headpos.y = headpos.y - th - (spacing - 2)
				end
				if ubot.config.get('esp', 'Show Name') then
					local text = tostring(v.Nick and (v:Nick()..'['..v:GetFriendStatus()..']') or 'unknown')
					tw, th = surface.GetTextSize(text)
					surface.SetTextPos(headpos.x - tw/2, headpos.y - th/2)
					surface.DrawText(text)
					headpos.y = headpos.y - th - (spacing - 2)
				end
			end
		end
	end
end
ubot.AddHook("HUDPaint", "ubot.esp.HUDP", ubot.esp.HUDPaint)

--[[GUI]]--
ubot.gui = {}
ubot.gui.cfg2gui = function(parent, cfgtbl)
	parent.TextColor = Color(90,90,90,255)
	parent.items = {}
	parent.index = 0
	for k,v in pairs(cfgtbl) do
		for ck,cv in pairs(v) do k, v = ck, cv end
		if (type(v) == "boolean") then
			parent.items[k] = vgui.Create("DCheckBoxLabel")
			parent.items[k]:SetParent(parent)
			parent.items[k]:SetPos(0, parent.index * 20)
			parent.items[k]:SetText(k)
			parent.items[k]:SizeToContents()
			parent.items[k]:SetTextColor(parent.TextColor)
			parent.items[k]:SetValue(v)
			parent.items[k].OnChange = function()
				cfgtbl[k] = parent.items[k]:GetChecked()
			end
		elseif (type(v) == "table") then
			parent.items['_'..k] = vgui.Create("DLabel")
			parent.items['_'..k]:SetParent(parent)
			parent.items['_'..k]:SetPos(1, (parent.index * 20) + 4)
			parent.items['_'..k]:SetText(k..':')
			parent.items['_'..k]:SizeToContents()
			parent.items['_'..k]:SetTextColor(parent.TextColor)
			
			if (v.r ~= nil) and (v.g ~= nil) and (v.b ~= nil) then
				--[[
				parent.items[k] = vgui.Create("DRGBBar")
				parent.items[k]:SetParent(parent)
				parent.items[k]:SetPos(parent.items['_'..k]:GetWide() + 10, (parent.index * 20))
				parent.items[k]:SetSize(80, 21)
				parent.items[k]:SetColor(v)
				parent.items[k].OnColorChange = function()
					cfgtbl[k] = HSVToColor(parent.items[k]:GetHue(), 1, 1)
				end
				--]]
			else
				parent.items[k] = vgui.Create("DComboBox")
				parent.items[k]:SetParent(parent)
				parent.items[k]:SetPos(parent.items['_'..k]:GetWide() + 10, (parent.index * 20))
				parent.items[k]:SetSize(80, 21)
				for rk,rv in pairs(v) do parent.items[k]:AddChoice(rv) end
				parent.items[k]:ChooseOptionID(1)
				parent.items[k].OnSelect = function(Index, Value, Data)
					cfgtbl[k] = Data
				end
			end
			parent.index = parent.index + 0.5
		elseif (type(v) == "string") then
			parent.items['_'..k] = vgui.Create("DLabel")
			parent.items['_'..k]:SetParent(parent)
			parent.items['_'..k]:SetPos(1, (parent.index * 20) + 4)
			parent.items['_'..k]:SetText(k..':')
			parent.items['_'..k]:SizeToContents()
			parent.items['_'..k]:SetTextColor(parent.TextColor)
			
			parent.items[k] = vgui.Create("DTextEntry")
			parent.items[k]:SetParent(parent)
			parent.items[k]:SetPos(parent.items['_'..k]:GetWide() + 10, (parent.index * 20))
			parent.items[k]:SetSize(80, 21)
			parent.items[k]:SetEditable(true)
			parent.items[k]:SetValue(v)
			parent.items[k].OnEnter = function()
				cfgtbl[k] = parent.items[k]:GetValue()
			end
		elseif (type(v) == "number") then
			parent.items[k] = vgui.Create("DNumSlider")
			parent.items[k]:SetParent(parent)
			parent.items[k]:SetPos(0, (parent.index * 20))
			parent.items[k]:SetWide(130)
			parent.items[k]:SetText(k)
			parent.items[k]:SetMinMax(0, v * 2)
			parent.items[k]:SetDecimals(0)
			parent.items[k]:SetValue(v)
			parent.items[k].ValueChanged = function(self, val)
				cfgtbl[k] = tonumber(val) or 0
			end
			parent.index = parent.index + 1.3
		end
		parent.index = parent.index + 1
	end
end

ubot.gui.MakeMenuDone = false
ubot.gui.MakeMenu = function()
	if (not ubot.gui.MakeMenuDone) then
		ubot.gui.frame = vgui.Create("DFrame")
		ubot.gui.frame:SetSize(200, 350)
		ubot.gui.frame:Center() --22px title bar
		ubot.gui.frame:SetTitle("MicroBot")
		ubot.gui.frame:SetDeleteOnClose(false)
		ubot.gui.frame:MakePopup()
		ubot.gui.frame:SetVisible(true)

		ubot.gui.sheet = vgui.Create("DPropertySheet")
		ubot.gui.sheet:SetParent(ubot.gui.frame)
		ubot.gui.sheet:SetPos(5, 24)
		ubot.gui.sheet:SetSize(190, 321)

		ubot.gui.aimbot = vgui.Create("DPanel")
		ubot.gui.aimbot.Paint = nil
		ubot.gui.cfg2gui(ubot.gui.aimbot, ubot.config.aimbot)
		ubot.gui.sheet:AddSheet("Aimbot", ubot.gui.aimbot, "gui/info", false, false, "Aimbot Config")

		ubot.gui.esp = vgui.Create("DPanel")
		ubot.gui.esp.Paint = nil
		ubot.gui.cfg2gui(ubot.gui.esp, ubot.config.esp)
		ubot.gui.sheet:AddSheet("ESP", ubot.gui.esp, "gui/info", false, false, "ESP Config")

		ubot.gui.misc = vgui.Create("DPanel")
		ubot.gui.misc.Paint = nil
		ubot.gui.cfg2gui(ubot.gui.misc, ubot.config.misc)
		ubot.gui.sheet:AddSheet("Misc", ubot.gui.misc, "gui/info", false, false, "Misc Config")
		
		ubot.config.load()
		ubot.gui.MakeMenuDone = true
	end
end

ubot.gui.MakeMenu()