local G = table.Copy(_G)
local prism = {}

//━━━ BASIC VARIABLES ━━━\\ 
prism.localplayer = G.LocalPlayer()
prism.scrw = G.ScrW()
prism.scrh = G.ScrH()
prism.gravity = G.GetConVar("sv_gravity")
prism.lerp = G.GetConVar("cl_interp")

prism.surfacepenetration = {
    [MAT_ANTLION] = 1,
    [MAT_BLOODYFLESH] = 0,
    [MAT_CONCRETE] = 1,
    [MAT_DIRT] = 1,
    [MAT_EGGSHELL] = 0,
    [MAT_FLESH] = 0,
    [MAT_GRATE] = 0,
    [MAT_ALIENFLESH] = 0,
    [MAT_CLIP] = 0,
    [MAT_SNOW] = 1,
    [MAT_PLASTIC] = 1,
    [MAT_METAL] = 1,
    [MAT_SAND] = 1,
    [MAT_FOLIAGE] = 0,
    [MAT_COMPUTER] = 0,
    [MAT_SLOSH] = 0,
    [MAT_TILE] = 1,
    [MAT_GRASS] = 1,
    [MAT_VENT] = 0,
    [MAT_WOOD] = 1,
    [MAT_DEFAULT] = 1,
    [MAT_GLASS] = 0,
    [MAT_WARPSHIELD] = 1,
}

prism.bones = {
	{"Head", "ValveBiped.Bip01_Head1"},
	{"Neck", "ValveBiped.Bip01_Neck1"},
	{"Spine", "ValveBiped.Bip01_Spine"},
	{"Spine1", "ValveBiped.Bip01_Spine1"},
	{"Spine2", "ValveBiped.Bip01_Spine2"},
	{"Spine4", "ValveBiped.Bip01_Spine4"},
	{"R Upperarm", "ValveBiped.Bip01_R_UpperArm"},
	{"R Forearm", "ValveBiped.Bip01_R_Forearm"},
	{"R Hand", "ValveBiped.Bip01_R_Hand"},
	{"L Upperarm", "ValveBiped.Bip01_L_UpperArm"},
	{"L Forearm", "ValveBiped.Bip01_L_Forearm"},
	{"L Hand", "ValveBiped.Bip01_L_Hand"},
	{"R Thigh", "ValveBiped.Bip01_R_Thigh"},
	{"R Calf", "ValveBiped.Bip01_R_Calf"},
	{"R Foot", "ValveBiped.Bip01_R_Foot"},
	{"R Toes", "ValveBiped.Bip01_R_Toe0"},
	{"L Thigh", "ValveBiped.Bip01_L_Thigh"},
	{"L Calf", "ValveBiped.Bip01_L_Calf"},
	{"L Foot", "ValveBiped.Bip01_L_Foot"},
	{"L Toes", "ValveBiped.Bip01_L_Toe0"}
}

prism.lagcomp_storage = {}

G.surface.CreateFont( "ESPFont", {
	font = "Bahnschrift Light", --  Use the font-name which is shown to you by your operating system Font Viewer, not the file name
    size = 13,
    weight = 400,
    antialias = false,
    outline = true,
    shadow = true,
} )

G.surface.CreateFont( "SmallESPFont", {
	font = "BudgetLabel",
    size = 12,
	weight = 500,
    antialias = false, -- because outline fucks up if you don't
    outline = true 
} )

//━━━ DETOURS ━━━\\ 
// ALPHA

file.Read = function(fileName, gamePath)
    if string.EndsWith(string.lower(fileName), "prism.lua") then 
        return "Prism>All"
    end

    return G.file.Read(fileName, gamePath)
end

//━━━ Load Message ━━━\\ 
local txt = "P R I S M\nby paradox\nprism_help in console for more info!\n"

for i = 1, #txt do
    MsgC(HSVToColor( i * 10 % 360, 1, 1 ), string.sub( txt, i, i ))
end

//━━━ CONSOLE VARIABLES ━━━\\ 
prism.cvars = {
    --["exampletrue"] = 1,
    --["examplefalse"] = 0,

    ["aimbot"] = 1,
    ["aimbot_target_type"] = "FOV", -- Distance, FOV, Health
    ["aimbot_target_fov"] = 180,
    ["aimbot_target_hitbox"] = "head", -- head, body, hitscan 
    ["aimbot_target_no_admin"] = 0,
    ["aimbot_target_no_laggy"] = 0,
    ["aimbot_target_no_noclip"] = 0,
    ["aimbot_target_no_cloaked"] = 0,
    ["aimbot_target_no_bots"] = 0,
    ["aimbot_aiming_trackmode"] = "prediction", -- none, prediction, backtrack
    ["aimbot_aiming_trackmode_backtrack"] = 12, -- backtrack amount if backtrack is track mode
    ["aimbot_aiming_smooth"] = 0,
    ["aimbot_aiming_silent"] = 0,
    ["aimbot_aiming_autofire"] = 0,

    ["esp"] = 1,
    ["esp_name"] = 1,
    ["esp_box"] = 1,
    ["esp_health_bar"] = 1,
    ["esp_weapon"] = 1,
    ["esp_glow"] = 1,

    ["misc_bunnyhop"] = 1,
    ["misc_autostrafe"] = 1,
}

for k,v in G.pairs(prism.cvars) do 
    prism.cvars[k] = G.CreateClientConVar("prism_" .. k, v)
end

//━━━ MENU ━━━\\ 
local menu = {}

menu.tabitems = {
    {

    },
    {

    },
    {

    },
    {
        
    }
}

menu.tabs = {
    ["aimbot"] = "icon16/bomb.png",
    ["esp"] = "icon16/color_wheel.png",
    ["misc"] = "icon16/lightning.png",
    ["other"] = "icon16/package.png",
}

function prism.OutlinedBox(x, y, w, h, thickness, clr)
    surface.SetDrawColor(clr)
    for i = 0, thickness - 1 do
      surface.DrawOutlinedRect(x + i, y + i, w - i * 2, h - i * 2)
    end
end

function prism.AddItems(panel,id)
    local tabitems = menu.tabitems[id]


end

function prism.CreateMenu()
    menu.DermaPanel = vgui.Create("DFrame")
    menu.DermaPanel:SetSize(400, 400) 
    menu.DermaPanel:Center() 
    menu.DermaPanel:SetTitle("") 
    menu.DermaPanel:SetDraggable(false) 
    menu.DermaPanel:MakePopup()
    menu.DermaPanel.Paint = function(self, w, h)
        draw.RoundedBox(2, 0, 0, 920, 700, Color(17, 17, 17))
        draw.RoundedBox(2, 0, 0, self:GetWide(), 25, Color(0, 0, 0, 200))
        draw.RoundedBox(2, 0, 0, self:GetWide(), self:GetTall(), Color(30, 30, 30))
        // surface.SetDrawColor(20, 20, 20)
        // surface.DrawRect(8, 9, 101, 683)
        prism.OutlinedBox(3, 3, w - 6, h - 6, 5, Color(50, 50, 50))
        prism.OutlinedBox(4.8, 4.8, w - 8, h - 8, 3, Color(42, 42, 42))
    end

    menu.sheet = vgui.Create( "DColumnSheet", menu.DermaPanel )
    menu.sheet:Dock( FILL )

    for k,v in G.SortedPairs(menu.tabs) do         
        local tab = vgui.Create( "DPanel", menu.sheet )

        menu.tabs[k] = tab
        
        tab:SetSize(265, 360)
        tab.Paint = function( self, w, h )         
            draw.RoundedBox(2, 0, 0, self:GetWide(), self:GetTall(), Color(70, 70, 70)) -- TEMP
        end
        
        local b = menu.sheet:AddSheet( k, tab, v )
        
        b.Button.Paint = function(self, w, h) draw.RoundedBox( 4, 0, 0, w, h, Color( 30, 30, 30 ) ) end   
        
        prism.AddItems(tab,k)
    end
end

prism.CreateMenu()

//━━━ USEFUL FUNCTIONS ━━━\\ 
function prism.RandomString(length) 
    local str = ""
    length = length or 20

    for i = 1,length do 
        str = str .. G.string.char(G.math.random(97,122))
    end

    return str 
end

function prism.IsBadMovement(cmd)
    local mt = prism.localplayer:GetMoveType()

    if mt == MOVETYPE_LADDER || mt == MOVETYPE_NOCLIP || ( mt == MOVETYPE_OBSERVER && prism.localplayer:Team() == TEAM_SPECTATOR) then return false end 

    if !prism.localplayer:Alive() || prism.localplayer:Health() < 0 then return false end // Not movement but I use it in aimbot so might as well 

    return true 
end

function prism.NormalizeAngle(ang, disablerollfix)
    ang.y = math.NormalizeAngle(ang.y) -- Snap angle to between -180/180
    ang.x = math.Clamp(ang.x, -89, 89) -- Snap pitch
    
    if !disablerollfix then 
        ang.z = 0
    end
    
    return ang
end

//━━━ LAG COMPENSATION & PREDICTION ━━━\\
function prism.PredictCrossbow(ply,cmd,ang)
    local gravity = prism.gravity:GetFloat()
    local interp = prism.lerp:GetFloat()

    local target_speed = ply:GetAbsVelocity()
    
    target_speed.z = ply:IsOnGround() && target_speed.z - (gravity * G.engine.TickInterval()) || target_speed.z

    local positions = ang:Distance(prism.localplayer:GetPos()) // positions

    local comp_time = (positions/3500) + interp

    return ang + (target_speed * comp_time)
end

function prism.Prediction(ply,cmd,ang)
    local tick_interval = G.engine.TickInterval()
    local lerp_ticks = prism.lerp:GetFloat()
    
    local simtime = (.5 + ply:GetAnimTimeInterval()) * tick_interval -- Should give us the TIME_TO_TICK'd SimTime

    local lerp_remainder = math.fmod(lerp_ticks, tick_interval)

    if(lerp_remainder > 0) then
        local extended = simtime + (tick_interval - lerp_remainder)

        local extended2 = (extended - simtime) / tick_interval

        extended2 = extended2 + (ply:Ping()*extended2)

        return ang + Vector(extended2,extended2,0)
    end

    return ang 
end

function prism.Backtrack(ply,cmd,ang)
    local backtrack_time = CurTime() + (prism.cvars["aimbot_aiming_trackmode_backtrack"]:GetFloat() / 12)

    prism.lagcomp_storage[ply] = prism.lagcomp_storage[ply] or {}
    
    local oldRecord = prism.lagcomp_storage[ply]
    local currentRecord = {}

    local tick_interval = G.engine.TickInterval()
    local animTime = ply:GetAnimTimeInterval()
    local eSimTime = (.5 + animTime) * tick_interval

    if G.table.IsEmpty(oldRecord) || #oldRecord < 64 then 
        currentRecord["backtrack_time"] = CurTime()
        currentRecord["animTime"] = animTime
        currentRecord["eSimTime"] = eSimTime
        currentRecord["pos"] = ply:GetPos()
    
        table.insert(prism.lagcomp_storage[ply],#prism.lagcomp_storage+1,currentRecord)
        return ang
    elseif #oldRecord <= 64 then 
        local i = 1

        while i < #oldRecord do 
            local tr = oldRecord[i] -- Temp Record

            if #oldRecord-i < 65 then 
                table.remove(oldRecord, i)
            end
            
            i = i + 1
        end
    end

    if cmd:TickCount() != 0 then 
        // TODO: Make module for this, or contact vectivus
        G.RunConsoleCommand("cl_interp", eSimTime)
    else 
        G.RunConsoleCommand("cl_interp", 0)
    end
    
    currentRecord["backtrack_time"] = CurTime()
    currentRecord["animTime"] = animTime
    currentRecord["eSimTime"] = eSimTime
    currentRecord["pos"] = ply:GetPos()

    table.insert(prism.lagcomp_storage[ply],#prism.lagcomp_storage+1,currentRecord)

    return ang
end

function prism.Predict(ply,cmd,ang)
    local wep = prism.localplayer:GetActiveWeapon()
    if !wep then return ang end 

    if wep:GetClass() == "weapon_crossbow" then return prism.PredictCrossbow(ply,cmd,ang) end

    local track_mode = G.string.lower(prism.cvars["aimbot_aiming_trackmode"]:GetString())

    if track_mode == "prediction" then
        ang = prism.Prediction(ply,cmd,ang)
    elseif track_mode == "backtrack" then 
        ang = prism.Backtrack(ply,cmd,ang)
    end

    return ang // TODO: Look into BIG module
    // TODO: Look into ply:GetAnimTimeIntervals reset time for LBY breaking
end

//━━━ AIMBOT ━━━\\ 
function prism.CalculateFOV(ply,angle,fov,getnormals)
    local normal_calc = (ply:GetPos() - prism.localplayer:GetPos()):Angle()

    local normal_x = math.abs(math.NormalizeAngle(angle.x - normal_calc.x))
    local normal_y = math.abs(math.NormalizeAngle(angle.y - normal_calc.y))

    if getnormals then return G.Angle(normal_x,normal_y,0) end 

    if normal_y > fov || normal_x > fov then return false end 

    return true 
end 

function prism.TargetChecks(ply)
    if ply == prism.localplayer ||
    ( prism.cvars["aimbot_target_no_admin"]:GetBool() && (ply:IsAdmin() || ply:IsSuperAdmin()) ) ||
    ( prism.cvars["aimbot_target_no_bots"]:GetBool() && ply:IsBot() ) ||
    ( prism.cvars["aimbot_target_no_cloaked"]:GetBool() && (ply:GetColor().a != 255) ) ||
    ( prism.cvars["aimbot_target_no_laggy"]:GetBool() && (ply:Ping() > 200 || ply:PacketLoss() > 90)) ||
    ( prism.cvars["aimbot_target_no_noclip"]:GetBool() && ply:GetMoveType() == MOVETYPE_NOCLIP ) ||
    ( !ply:Alive() || ply:Health() <= 0 ) then return false end
    
    local ltw = ply:LocalToWorld(ply:OBBCenter())
    local leye = prism.localplayer:GetAngles()
    
    if !prism.CalculateFOV(ply,leye,prism.cvars["aimbot_target_fov"]:GetFloat()) then return end  
    
    return prism.HitboxVisible(ltw)
end

function prism.FindTarget(cmd)
    
    local best = {NULL,0}
    local targeting_mode = G.string.lower(prism.cvars["aimbot_target_type"]:GetString())
    local distance = prism.localplayer:GetPos()

    if targeting_mode != "fov" || targeting_mode != "distance" || trageting_mode != "health" then targeting_mode = "fov" end  

    for k,v in G.ipairs(player.GetAll()) do 
        if !prism.TargetChecks(v) then continue end 

        if targeting_mode == "fov" then 
            local ep = v:EyePos():ToScreen()
            
            ep = G.math.Dist(prism.scrw / 2, prism.scrh / 2, ep.x, ep.y)
            
            if best[1] then -- If a best exists
                if ep > best[2] then -- If this is better then the current best
                    best = {v,ep} -- Current best dethroned
                end
            else -- If it doesn't this one has to be best since no other one exists
                best = {v,ep}
            end 
        elseif targeting_mode == "distance" then 
            local vec = distance:Distance(v:GetPos())


        elseif targeting_mode == "health" then 

        end
    end

    return best[1] 
end

function prism.HitboxVisible(hangle)
    local trc = util.TraceLine({
        start = prism.localplayer:GetShootPos(),
        endpos = hangle,
        filter = {prism.localplayer},
        mask = MASK_SHOT,
    })

    local surface = prism.surfacepenetration[trc.MatType]

    if !surface then 
        return trc.Fraction == 1
    end

    return trc.Fraction >= prism.surfacepenetration[trc.MatType] 
end

function prism.GetHitbox(ply,cmd)

    local prefered_hitbox = G.string.lower(prism.cvars["aimbot_target_hitbox"]:GetString())

    if prefered_hitbox == "head" then 
        local blookup = ply:GetBoneMatrix(ply:LookupBone("ValveBiped.Bip01_Head1")) // Do this instead of just using GetBonePos(0) since some custom models
        // can have custom locations

        // We get bone matrix for lag fixes (higher framerates then the server tickrate)
        // Makes you lag behind, thats why most peoples aimbot is pretty shit
        local ang = blookup:GetTranslation()
        
        return ang 
    elseif prefered_hitbox == "body" then 
        local blookup = ply:LookupBone("ValveBiped.Bip01_Spine") 

        // Some retards don't like to use spine in there models and just start straight up with Spine1
        // We aint havin any of that shit
        if blookup then // Playermodel dev got a brain
            return ply:GetBoneMatrix(blookup):GetTranslation() 
        else // Or not
            return ply:LocalToWorld(ply:OBBCenter()) // We'll just return the center of the hitbox instead
        end
    else 
        for k,v in G.pairs(prism.bones) do 
            local blookup = ply:LookupBone(v[2]) 

            if !blookup then continue end 

            local ang = ply:GetBoneMatrix(blookup)
            
            if !ang then continue end 

            ang = ang:GetTranslation()

            if prism.HitboxVisible(ang) then return ang end 
        end 
    end
end

function prism.Aimbot(cmd,bm)
    if !bm || !prism.cvars["aimbot"]:GetBool() then return end 

    local silent = prism.cvars["aimbot_aiming_silent"]:GetBool()

    if silent && cmd:CommandNumber() == 0 || silent && G.input.IsKeyDown(KEY_E) then return end 

    local ply = prism.FindTarget(cmd)

    if !ply || !G.IsValid(ply) then return end 

    local ang = prism.GetHitbox(ply)

    if !ang then return end 

    // Call upon the prediction gods
    ang = prism.Predict(ply,cmd,ang)

    if !ang then return end 

    ang = (ang-prism.localplayer:GetShootPos()):Angle() // Actually convert it to ang

    if prism.cvars["aimbot_aiming_smooth"]:GetFloat() != 0 && !silent then 
        ang = G.LerpAngle(prism.cvars["aimbot_aiming_smooth"]:GetFloat()/1000, cmd:GetViewAngles(), ang)
    end

    cmd:SetViewAngles(prism.NormalizeAngle(ang))

    if prism.cvars["aimbot_aiming_autofire"]:GetBool() then 
        if (prism.localplayer:KeyDown(1)) then
            cmd:SetButtons(G.bit.band(cmd:GetButtons(), G.bit.bnot(1)))
        else
            cmd:SetButtons(G.bit.bor(cmd:GetButtons(), 1))
        end
    end

    if silent then 
        prism.MovementFix(cmd)
    end
end

function prism.FixAngles(cmd)
    prism.facing_angle = prism.facing_angle or cmd:GetViewAngles()

    prism.facing_angle = prism.facing_angle + G.Angle(cmd:GetMouseY() * .023, cmd:GetMouseX() * - .023, 0)

    if cmd:CommandNumber() == 0 && prism.cvars["aimbot_aiming_silent"]:GetBool() then 
        cmd:SetViewAngles(prism.NormalizeAngle(prism.facing_angle))
    end
end

//━━━ MOVEMENT ━━━\\ 
function prism.MovementFix(cmd)
    prism.facing_angle = prism.facing_angle or cmd:GetViewAngles()

    local view = cmd:GetViewAngles()

    local vec = G.Vector( cmd:GetForwardMove(), cmd:GetSideMove(), 0 )
    local mang = vec:Angle()
    
    local vel = G.math.sqrt( vec.x*vec.x + vec.y*vec.y )
    local yaw = view.y - prism.facing_angle.y + mang.y

    if (((view.x+90)%360) > 180) then
        yaw = 180 - yaw
    end
    yaw = ((yaw + 180)%360)-180;

    cmd:SetForwardMove(math.cos(math.rad(yaw)) * vel)
    cmd:SetSideMove(math.sin(math.rad(yaw)) * vel)
end

function prism.Bunnyhop(cmd,bm)
    if !prism.cvars["misc_bunnyhop"]:GetBool() || !bm then return end 

    if !prism.localplayer:IsOnGround() && cmd:KeyDown(IN_JUMP) then 
        cmd:RemoveKey(IN_JUMP)
    end
end

function prism.Autostrafe(cmd,bm)
    if !prism.cvars["misc_autostrafe"]:GetBool() || !bm then return end
    
    if !prism.localplayer:IsOnGround() && cmd:KeyDown(IN_JUMP) then 
        if cmd:GetMouseX() > 1 then 
            // Player wants to move right
            cmd:SetSideMove(10000)
        elseif cmd:GetMouseX() <= -1 then 
            // Player wants to mvoe left
            cmd:SetSideMove(-10000)
        else 
            // Static mouse, I don't know what you want from me so you'll get nothing
            cmd:SetForwardMove(10000 / prism.localplayer:GetVelocity():Length2D())
        end
    elseif cmd:KeyDown(IN_JUMP) then // Mid-Jump
        cmd:SetForwardMove(10000) // Don't edit anything
    end
end

//━━━ ESP ━━━\\ 
function prism.ESP()
    local name = prism.cvars["esp_name"]:GetBool()
    local box = prism.cvars["esp_box"]:GetBool()
    local weapon = prism.cvars["esp_weapon"]:GetBool()
    local health = prism.cvars["esp_health_bar"]:GetBool()
    local glow = prism.cvars["esp_glow"]:GetBool()

    for k,v in G.pairs(G.player.GetAll()) do 
        if !v || v:IsDormant() || !v:Alive() || v:Health() <= 0 || v == prism.localplayer then continue end 

        local up_bound = 0 
        local down_bound = 0

        local pos = v:GetPos()
        local min, max = v:GetCollisionBounds()
        local pos2 = (pos + G.Vector(0, 0, max.z)):ToScreen()

        pos = pos:ToScreen()
        
        local h = pos.y - pos2.y
        local w = h / 2

        if name then 
            G.draw.SimpleText(v:Name(), "ESPFont", pos.x, pos.y - h - 5, G.Color(255,255,255), 1, 1)
        end
        
        if box then 
            G.surface.SetDrawColor(255,255,255) -- the white
            G.surface.DrawOutlinedRect(pos.x - w / 2, pos.y - h + 2, w, h)
            G.surface.SetDrawColor(0,0,0,75) -- the outline
            G.surface.DrawOutlinedRect(pos.x - w / 2 - 1, pos.y - h - 1 + 4, w + 2, h - 2)
        end

        if weapon then 
            local wep = v:GetActiveWeapon()       
            if G.IsValid(wep) then 
                G.draw.SimpleText(G.string.lower(G.language.GetPhrase(wep:GetClass())), "SmallESPFont", pos.x, pos.y + 8, G.Color(255,255,255), 1, 1)
            else -- if they are stripped or gamemode restricts their guns
                G.draw.SimpleText("unarmed", "SmallESPFont", pos.x, pos.y + 8, G.Color(255,255,255), 1, 1)
            end
        end

        if health then 
            -- lerping healthbar --
            v.health = v:Health()
            v.healthnum = v:Health()
            v.oldHP = v.oldHP or 100

            if(v.oldHP ~= v.health and v.health == 100) then v.oldHP = 100 end 

            if(oldHP ~= v:Health()) then 
                v.health = G.Lerp(0.025,v.oldHP,v:Health())
                v.oldHP = G.Lerp(0.025,v.oldHP,v:Health())
                v.healthnum = G.Lerp(0.030,v.oldHP,v:Health())
            else
                v.oldHP = v.health
            end
            --------------------------------------------

            local hp = h * v.health / 100
            if(hp > h) then hp = h end
            local diff = h - hp

            G.surface.SetDrawColor(0, 0, 0, 150)
            G.surface.DrawRect(pos.x - w / 2 - 6, pos.y - h + 2, 3, h)
            G.surface.DrawRect(pos.x - w / 2 - 7, pos.y - h + 2, 3, h)

            local col = Color((150 - v.health) * 2.55, v.health * 2.55, 0, 255)
            if(v:Health() > 75) then 
                col = G.Color(v.health * 1.50, v.health * 2.55, 0, 255)
            end 
            G.surface.SetDrawColor(col)

            if v:Health() <= 92 then 
                -- because skeet.
                local rounded = G.math.Round(v.health)
                G.draw.SimpleText(rounded .. "%", "SmallESPFont", pos.x - w / 2 - (15+(rounded >= 10 and 4 or .5 )), pos.y - h + diff + 4, col, 1, 1)
            end

            G.surface.DrawRect(pos.x - w / 2 - 6, pos.y - h + 2 + diff, 2, hp)
        end 

        if glow then 
            G.halo.Add({v, v:GetActiveWeapon()}, G.Color(75,0,130), 1, 1, 5, true, true)
        end
    end
end

//━━━ ANTI-AIM ━━━\\ 

//━━━ HOOKS ━━━\\ 
hook.Add("CreateMove", "prism", function(cmd)

    local bm = prism.IsBadMovement(cmd)

    // Movement
    prism.Autostrafe(cmd,bm)
    prism.Bunnyhop(cmd,bm)

    // Angles
    prism.FixAngles(cmd)
    prism.Aimbot(cmd,bm)

end)

hook.Add("DrawOverlay", "prism", function()
    if !prism.cvars["esp"]:GetBool() then return end 

    prism.ESP()
end)

//━━━ RELOAD ━━━\\ 
// For debugging purposes
G.concommand.Add("prism_reload", function()
    hook.Remove("CreateMove", "prism")
    hook.Remove("DrawOverlay", "prism")
end)