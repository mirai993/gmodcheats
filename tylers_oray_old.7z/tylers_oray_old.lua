--[[
	XRay.lua
	(-SG-) Tyler | (STEAM_0:0:40143824)
	===DStream===
]]

-- tyler's shitty xray script --

require("cvar2")

local SpamMessage = "noob .."
local speed = 3.5

-- starting shit --
surface.PlaySound("buttons/button19.wav") 
chat.AddText(
    Color(255,0,0,255), "[XRay]: ",
    Color(0,255,0,255), "Loaded "
)


-- commands --
CreateClientConVar("XRay_wireframe",0,true,false)
CreateClientConVar("XRay_info",1,true,false)
CreateClientConVar("Xray_chams",1,true,false)
CreateClientConVar("XRay_box",1,true,false)
CreateClientConVar("XRay_chat",0,true,false)
CreateClientConVar("XRay_sky",1,true,false)
CreateClientConVar("XRay_weapons",1,true,false)
CreateClientConVar("XRay_props",1,true,false)
CreateClientConVar("XRay_bhop",1,true,false)
CreateClientConVar("XRay_fps",0,true,false)
CreateClientConVar("XRay_fullbright",1,true,false)
CreateClientConVar("XRay_flashlight",0,true,false)



-- force sv_cheats --
function Forcethese()
if ( 1 + 1 == 2 ) then -- I love have an "if" statement in every function
cvar2.SetValue("sv_cheats","1")
cvar2.SetValue("sv_allow_voice_from_file","1")
cvar2.SetValue("sv_scriptenforcer","0") -- i have no idea why im doing this, it's useless
end
end
hook.Add("Think","forcethisshit",Forcethese)

-- all models wireframe --
function wireframe()
if GetConVarNumber("XRay_wireframe") == 1 then
cvar2.SetValue("r_drawothermodels","2")
else
cvar2.SetValue("r_drawothermodels","1")
end
end
hook.Add("Think","youcallthiswireframe",wireframe)

-- info --
function Info()
if GetConVarNumber("XRay_info") == 1 then
for k, v in pairs( player.GetAll() ) do
if( v:Alive() && v != LocalPlayer() ) then
local Pos = ( v:GetPos() + Vector( 0, 0, 75 ) ):ToScreen();
surface.SetDrawColor( team.GetColor( v:Team() ) )
draw.SimpleText( v:Name(), "BudgetLabel", Pos.x, Pos.y, team.GetColor( v:Team() ), TEXT_ALIGN_CENTER )
draw.SimpleText( "HP:" .. v:Health(), 'BudgetLabel', Pos.x, Pos.y + 12, team.GetColor( v:Team() ), TEXT_ALIGN_CENTER )
end
end
end
end
hook.Add("HUDPaint","badinfo",Info)

-- box --
local function DrawBoundingBox() -- thanks Anthr4x
if GetConVarNumber("xray_box") == 1 then
cam.Start3D(EyePos(), EyeAngles());
for k, ply in pairs(player.GetAll()) do
if ( ply:Alive() && ( ValidEntity(ply) && ply != LocalPlayer() )) then
local ang = ply:EyeAngles();
ang.p = 0;
ang.r = 0;
local pos = ply:GetPos();
local width = 32;
local height = 74;
local scale = 2;

local ang1 = Angle(ang.p, ang.y, ang.r);
local pos1 = pos;
pos1 = pos1 - (ang1:Forward() * (width / 2));
pos1 = pos1 - (ang1:Right() * (width / 2));
cam.Start3D2D(pos1, ang1, (1 / scale));
surface.SetDrawColor(Color(255, 0, 0, 255));
surface.DrawOutlinedRect(0, 0, (width * scale), (width * scale));
surface.SetDrawColor(Color(0, 0, 0, 0));
surface.DrawRect(0, 0, (width * scale), (width * scale));
cam.End3D2D();
-- Top Face
local ang2 = Angle(ang.p, ang.y, ang.r);
local pos2 = pos;
pos2 = pos2 - (ang2:Forward() * (width / 2));
pos2 = pos2 - (ang2:Right() * (width / 2));
pos2 = pos2 + (ang2:Up() * (height));
cam.Start3D2D(pos2, ang2, (1 / scale));
surface.SetDrawColor(Color(255, 0, 0, 255));
surface.DrawOutlinedRect(0, 0, (width * scale), (width * scale));
surface.SetDrawColor(Color(0, 0, 0, 0));
surface.DrawRect(0, 0, (width * scale), (width * scale));
cam.End3D2D();

-- Front Face
local ang3 = Angle(ang.p + 90, ang.y, ang.r);
local pos3 = pos;
pos3 = pos3 - (ang3:Forward() * height);
pos3 = pos3 - (ang3:Right() * (width / 2));
pos3 = pos3 + (ang3:Up() * (width / 2));
cam.Start3D2D(pos3, ang3, (1 / scale));
surface.SetDrawColor(Color(255, 0, 0, 255));
surface.DrawOutlinedRect(0, 0, (height * scale), (width * scale));
surface.SetDrawColor(Color(0, 0, 0, 0));
surface.DrawRect(0, 0, (height * scale), (width * scale));
cam.End3D2D();

					-- Back Face
local ang4 = Angle(ang.p + 90, ang.y, ang.r);
local pos4 = pos;
pos4 = pos4 - (ang4:Forward() * height);
pos4 = pos4 - (ang4:Right() * (width / 2));
pos4 = pos4 - (ang4:Up() * (width / 2));
cam.Start3D2D(pos4, ang4, (1 / scale));
surface.SetDrawColor(Color(255, 0, 0, 255));
surface.DrawOutlinedRect(0, 0, (height * scale), (width * scale));
surface.SetDrawColor(Color(0, 0, 0, 0));
surface.DrawRect(0, 0, (height * scale), (width * scale));
cam.End3D2D();

-- Right Face
local ang5 = Angle(ang.p + 90, ang.y, ang.r + 90);
local pos5 = pos;
pos5 = pos5 - (ang5:Forward() * height);
pos5 = pos5 - (ang5:Right() * (width / 2));
pos5 = pos5 - (ang5:Up() * (width / 2));
cam.Start3D2D(pos5, ang5, (1 / scale));
surface.SetDrawColor(Color(255, 0, 0, 255));
surface.DrawOutlinedRect(0, 0, (height * scale), (width * scale));
surface.SetDrawColor(Color(0, 0, 0, 0));
surface.DrawRect(0, 0, (height * scale), (width * scale));
cam.End3D2D();
-- Left Face
local ang6 = Angle(ang.p + 90, ang.y, ang.r + 90);
local pos6 = pos;
pos6 = pos6 - (ang6:Forward() * height);
pos6 = pos6 - (ang6:Right() * (width / 2));
pos6 = pos6 + (ang6:Up() * (width / 2));
cam.Start3D2D(pos6, ang6, (1 / scale));
surface.SetDrawColor(Color(255, 0, 0, 255));
surface.DrawOutlinedRect(0, 0, (height * scale), (width * scale));
surface.SetDrawColor(Color(0, 0, 0, 0));
surface.DrawRect(0, 0, (height * scale), (width * scale));
cam.End3D2D();
end
end
cam.End3D();
end
end
hook.Add("HUDPaint", "BoundingBox", DrawBoundingBox)

-- chams --
local function XRayMakeMat()	
local Texture = {
["$basetexture"] = "models/debug/debugwhite",
["$model"]       = 1,
["$translucent"] = 1,
["$alpha"]       = 1,
["$nocull"]      = 1,
["$ignorez"]	 = 1
}
local material = CreateMaterial( "xray_solid", "VertexLitGeneric", Texture )
return material
end

function Chams()
local Div = (1 / 255)
local m = XRayMakeMat()
if GetConVarNumber("xray_chams") == 1 then
for k,v in pairs(player.GetAll()) do
if ValidEntity(v) and v:Health() > 0 and v:Team() != TEAM_SPECTATOR then
cam.Start3D(EyePos(),EyeAngles())
local TCol = team.GetColor(v:Team())
render.SuppressEngineLighting( true )
render.SetColorModulation( ( TCol.r * Div ), ( TCol.g * Div ), ( TCol.b * Div ) )
SetMaterialOverride( m )
v:DrawModel()
render.SuppressEngineLighting( false )
render.SetColorModulation(1,1,1)
SetMaterialOverride( )
cam.End3D()
end
end
end
end
hook.Add("HUDPaint","fuckchamsfuck",Chams)

-- remove skybox --
function RemoveSky()
if GetConVarNumber("XRay_sky") == 1 then
cvar2.SetValue("gl_clear","1")
cvar2.SetValue("r_drawskybox","0")
cvar2.SetValue("r_3dsky","0")
else
cvar2.SetValue("gl_clear","0")
cvar2.SetValue("r_drawskybox","1")
cvar2.SetValue("r_3dsky","1")
end
end	
hook.Add("HUDPaint","Ilikemyskyblack",RemoveSky)

-- radar --                -- thanks pbot
function DoChecksRadar( e )
local ply, val = LocalPlayer(), 0
if ( e:IsPlayer() && e:GetMoveType() == MOVETYPE_OBSERVER ) then return false end
if ( !e:IsValid() || !e:IsPlayer() && !e:IsNPC() || e == ply ) then return false end
if ( e:IsPlayer() && !e:Alive() ) then return false end
if ( e:IsNPC() && e:GetMoveType() == 0 ) then return false end
if ( e:IsWeapon() && e:GetMoveType() == 0 ) then return false end	
return true
	
end

local Radar = vgui.Create( "DFrame" )
Radar:SetSize( 300, 300 )
local rW, rH, x, y = Radar:GetWide(), Radar:GetTall(), ScrW() / 2, ScrH() / 2	
local sW, sH = ScrW(), ScrH()
Radar:SetPos( sW - rW - 10, sH - rH - ( sH - rH ) + 10 )
Radar:SetTitle("")
Radar:SetVisible( true )
Radar:SetDraggable( true )
Radar:ShowCloseButton( false )
Radar:MakePopup()
Radar.Paint = function()
draw.RoundedBox( 0, 0, 0, rW, rH, Color( 0, 0, 0, 40 ) )
surface.SetDrawColor( 255, 0, 0, 255 )
surface.DrawOutlinedRect( 0, 0, rW, rH )		
local ply = LocalPlayer()	
local radar = {}
radar.h		= 300
radar.w		= 300
radar.org	= 5000	
local x, y = ScrW() / 2, ScrH() / 2	
local half = rH / 2
local xm = half
local ym = half		
surface.DrawLine( xm, ym - 100, xm, ym + 100 )
surface.DrawLine( xm - 100, ym, xm + 100, ym )	
for k, e in pairs( ents.GetAll() ) do
if ( DoChecksRadar(e) ) then				
local s = 6
local col = {}
local color = Color( 255,255,255,200 )
local plyfov = ply:GetFOV() / ( 70 / 1.13 )
local zpos, npos = ply:GetPos().z - ( e:GetPos().z ), ( ply:GetPos() - e:GetPos() )			
npos:Rotate( Angle( 180, ( ply:EyeAngles().y ) * -1, -180 ) )
local iY = npos.y * ( radar.h / ( ( radar.org * ( plyfov  * ( ScrW() / ScrH() ) ) ) + zpos * ( plyfov  * (ScrW() / ScrH() ) ) ) )
local iX = npos.x * ( radar.w / ( ( radar.org * ( plyfov  * ( ScrW() / ScrH() ) ) ) + zpos * ( plyfov  * (ScrW() / ScrH() ) ) ) )			
local pX = ( radar.w / 2 )
local pY = ( radar.h / 2 )				
local posX = pX - iY - ( s / 2 )
local posY = pY - iX - ( s / 2 )			
local text = e:GetClass()
if ( e:IsPlayer() ) then 
text = e:Nick() .. " ["..e:Health().."]"
end
if iX < ( radar.h / 2 ) && iY < ( radar.w / 2 ) && iX > ( -radar.h / 2 ) && iY > ( -radar.w / 2 ) then
draw.RoundedBox( s, posX, posY, s, s, color )
end
end
end
end
Radar:SetVisible( true )
Radar:SetMouseInputEnabled( false )
Radar:SetKeyboardInputEnabled( false )
concommand.Add( "+mouseenable", function() Radar:SetMouseInputEnabled( true ) end )
concommand.Add( "-mouseenable", function() Radar:SetMouseInputEnabled( false ) end )
RRadar = Radar

-- chat spammer --
function ChatSpam()
if GetConVarNumber( "XRay_chat" ) == 1 then
RunConsoleCommand( "say", ""..table.Random(Messages).."" )
end
end
hook.Add( "Think","chatspamomg",ChatSpam)

function Weapons()
if GetConVarNumber("XRay_weapons") == 1 then
for k, v in pairs( ents.GetAll() ) do
if ValidEntity( v ) then
if v:IsWeapon() && v:GetMoveType() != 0 then
if string.sub( v:GetClass(), 1, 7 ) == "weapon_" then
WeaponPos = v:EyePos():ToScreen()
draw.SimpleText( v:GetClass(), "BudgetLabel", WeaponPos.x, WeaponPos.y, Color( 255, 0, 0, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
end
end
end
end
end
end
hook.Add( "HUDPaint", "WeaponFinder", Weapons )

function Props()
if GetConVarNumber("XRay_props") == 1 then
for k,v in pairs(ents.FindByClass("prop_physics")) do
if ValidEntity(v) then
_R.Entity.SetColor(v,math.random(1,255),math.random(1,255),math.random(1,255),200)
_R.Entity.SetMaterial(v,"XRay_chams")
end
end
end
end
hook.Add( "HUDPaint", "propchams", Props )


-- bunnyhop --
function Bunnyhop()
if GetConVarNumber( "XRay_bhop" ) == 1 then
if input.IsKeyDown( KEY_SPACE ) then
if LocalPlayer():IsOnGround() then
RunConsoleCommand("+Jump")
timer.Create("Bhop",0.01, 0 ,function() RunConsoleCommand("-Jump") end)
end
end
end
end   
hook.Add("Think", "niggerhops", Bunnyhop)

-- speed hack --        
concommand.Add( "+sh", function( p, c, a ) -- whats wrong with having a speedhack on an xray?
cvar2.SetValue( "sv_cheats", "1" )
cvar2.SetValue( "host_timescale", speed )
end)
concommand.Add( "-sh", function( p, c, a )
cvar2.SetValue( "host_timescale", "1.0" )
end)

-- max fps--
function FPS()
if GetConVarNumber("XRay_fps") == 1 then
cvar2.SetValue("gl_clear","1")
cvar2.SetValue("r_drawskybox","0")
cvar2.SetValue("r_3dsky","0")
end
end
hook.Add("Think","MaxFPS",FPS)

-- fullbright --
function Fullbright()
if GetConVarNumber("XRay_fullbright") == 1 then
cvar2.SetValue("mat_fullbright","1")
else
cvar2.SetValue("mat_fullbright","0")
end
end
hook.Add("Think","LightItUp",Fullbright)

-- flashlight spam --
function Flashlight(ucmd)
if GetConVarNumber("XRay_flashlight") == 1 and !InChat then
RunConsoleCommand( "impulse", "100" )
end
end
hook.Add("Think","FlashlightSpam",Flashlight)



-- menu --   
local Menu -- i only added the menu because i was bored
function Menu()
local x, y = ScrW() / 2, ScrH() / 2

local Panel = vgui.Create( "DPropertySheet" )
Panel:SetParent( menu )
Panel:SetPos( x - 800 / 2, y - 500 / 2)
Panel:SetSize( 200, 300 )
Panel:MakePopup()
Menu = Panel
	
local XRay = vgui.Create( "DPanelList", Panel )
	
local Text = vgui.Create("DLabel")
Text:SetText( "Tyler's XRay" )
Text:SetParent( XRay )
Text:SetWide( 100 )
Text:SetPos( 10, 0 )
Text:SetTextColor( Color( 255, 0, 200, 255 ) )
				
local Checkbox = vgui.Create( "DCheckBoxLabel" )
Checkbox:SetText( "Wireframe Models" )
Checkbox:SetParent( XRay )
Checkbox:SetPos( 10, 20 )
Checkbox:SetConVar( "XRay_wireframe" )
Checkbox:SizeToContents()
		
local Checkbox = vgui.Create( "DCheckBoxLabel" )
Checkbox:SetText( "Player Info" )
Checkbox:SetParent( XRay )
Checkbox:SetPos( 10, 40 )
Checkbox:SetConVar( "XRay_info" )
Checkbox:SizeToContents()
		
local Checkbox = vgui.Create( "DCheckBoxLabel" )
Checkbox:SetText( "Player Chams" )
Checkbox:SetParent( XRay )
Checkbox:SetPos( 10, 60 )
Checkbox:SetConVar( "XRay_chams" )
Checkbox:SizeToContents()

local Checkbox = vgui.Create( "DCheckBoxLabel" )
Checkbox:SetText( "Player Box" )
Checkbox:SetParent( XRay )
Checkbox:SetPos( 10, 80 )
Checkbox:SetConVar( "XRay_box" )
Checkbox:SizeToContents()
			
local Checkbox = vgui.Create( "DCheckBoxLabel" )
Checkbox:SetText( "Remove Skybox" )
Checkbox:SetParent( XRay )
Checkbox:SetPos( 10, 100 )
Checkbox:SetConVar( "XRay_sky" )
Checkbox:SizeToContents()
	
local Checkbox = vgui.Create( "DCheckBoxLabel" )
Checkbox:SetText( "Weapon Finder" )
Checkbox:SetParent( XRay )
Checkbox:SetPos( 10, 120 )
Checkbox:SetConVar( "XRay_weapons" )
Checkbox:SizeToContents()
		
local Checkbox = vgui.Create( "DCheckBoxLabel" )
Checkbox:SetText( "Prop Chams" )
Checkbox:SetParent( XRay )
Checkbox:SetPos( 10, 140 )
Checkbox:SetConVar( "XRay_props" )
Checkbox:SizeToContents()
		
local Checkbox = vgui.Create( "DCheckBoxLabel" )
Checkbox:SetText( "Bunny Hop" )
Checkbox:SetParent( XRay )
Checkbox:SetPos( 10, 160 )
Checkbox:SetConVar( "XRay_bhop" )
Checkbox:SizeToContents()	

local Checkbox = vgui.Create( "DCheckBoxLabel" )
Checkbox:SetText( "Max FPS" )
Checkbox:SetParent( XRay )
Checkbox:SetPos( 10, 180 )
Checkbox:SetConVar( "XRay_fps" )
Checkbox:SizeToContents()

local Checkbox = vgui.Create( "DCheckBoxLabel" )
Checkbox:SetText( "Fullbright" )
Checkbox:SetParent( XRay )
Checkbox:SetPos( 10, 200 )
Checkbox:SetConVar( "XRay_fullbright" )
Checkbox:SizeToContents()	

local Checkbox = vgui.Create( "DCheckBoxLabel" )
Checkbox:SetText( "Flashlight Spammer" )
Checkbox:SetParent( XRay )
Checkbox:SetPos( 10, 220 )
Checkbox:SetConVar( "XRay_flashlight" )
Checkbox:SizeToContents()	

local Checkbox = vgui.Create( "DCheckBoxLabel" )
Checkbox:SetText( "Chat Spammer" )
Checkbox:SetParent( XRay )
Checkbox:SetPos( 10, 240 )
Checkbox:SetConVar( "XRay_chat" )
Checkbox:SizeToContents()	
		
Panel:AddSheet( "XRay", XRay, "gui/silkicons/star", false, false, "XRay Settings" )
end
concommand.Add( "+XRay_menu", Menu ) 
concommand.Add( "-XRay_menu", function() 
Menu:SetVisible( false )
end )