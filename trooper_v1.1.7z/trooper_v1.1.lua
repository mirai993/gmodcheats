// Trooper Mini-Hack created by Assault_Trooper

local Version = "v1.1 Public"
print( "Trooper Hack " .. Version .. " loaded!" )

local AimbotSwitch = CreateClientConVar( "trooper_aimbot", 0, true, false )
local WallhackSwitch = CreateClientConVar( "trooper_wallhack", 0, true, false )
local AutoshootSwitch = CreateClientConVar( "trooper_autoshoot", 0, true, false )
local NorecoilSwitch = CreateClientConVar( "trooper_norecoil", 0, true, false )
local FriendSwitch = CreateClientConVar( "trooper_friends", 0, true, false )
local TeamSwitch = CreateClientConVar( "trooper_team", 0, true, false )
local TargetSwitch = CreateClientConVar( "trooper_target", 0, true, false )
local BoneSwitch = CreateClientConVar( "trooper_aimbot_bone", 1, true, false )
local DarkrpSwitch = CreateClientConVar( "trooper_wallhack_darkrp", 0, true, false )
local HealthSwitch = CreateClientConVar( "trooper_wallhack_health", 0, true, false )
local WeaponSwitch = CreateClientConVar( "trooper_wallhack_weapon", 0, true, false )
local UsergroupSwitch = CreateClientConVar( "trooper_wallhack_usergroup", 0, true, false )
local TargetTypeSwitch = CreateClientConVar( "trooper_target_type", 0, true, false )

local Target
local Bone
local Firing = false

local Menu = {}

local BannedWeapons = {"weapon_physcannon", "weapon_physgun", "weapon_frag", "weapon_real_cs_smoke", "arrest_stick", "unarrest_stick", "stunstick",
"weapon_real_cs_flash", "weapon_real_cs_grenade", "spidermans_swep", "manhack_welder", "laserpointer", "remotecontroller", "med_kit",
"door_ram", "pocket", "weaponchecker", "lockpick", "keypad_cracker", "keys", "weapon_real_cs_knife", "gmod_tool", "gmod_camera", "weapon_crowbar",
"weapon_stunstick", "weapon_knife", "weapon_fishing_rod", "none"}

local DarkrpEnts = { "money_printer", "drug_lab", "gunlab", "microwave", "spawned_shipment", "food", "melon", "drug", "spawned_weapon" }

local function PlayerID( ply )

for k,v in pairs ( player.GetAll() ) do

if v == ply then return k end

end

end

local function WeaponCheck()

if LocalPlayer() and LocalPlayer():GetActiveWeapon() and LocalPlayer():GetActiveWeapon():IsValid() then
if table.HasValue( BannedWeapons, LocalPlayer():GetActiveWeapon():GetClass() ) then return false end

if LocalPlayer():GetActiveWeapon():Clip1() == 0 then 

return false 

else 

return true 

end

if !LocalPlayer():GetActiveWeapon() then return -1 end

end
end

local function GetTarget( ent )

if ent:IsValid() and ( ent:IsPlayer() or ent:IsNPC() ) then

if BoneSwitch:GetInt() == 1 then
Bone = ent:LookupBone( "ValveBiped.Bip01_Head1" )
elseif BoneSwitch:GetInt() == 2 then
Bone = ent:LookupBone( "ValveBiped.Bip01_Spine" )
end

return ent:GetBonePosition( Bone )

end

end

local function StatusCheck( ply )

if ply:IsWorld() then return false end
if !( ply:IsPlayer() or ply:IsNPC() ) then return false end
if FriendSwitch:GetBool() and ply:GetFriendStatus() == "friend" then return false end
if TeamSwitch:GetBool() and ply:Team() == LocalPlayer():Team() then return false end
if TargetSwitch:GetBool() and ply != Target then return false end
if TargetTypeSwitch:GetInt() == 2 and !ply:IsPlayer() then return false end
if TargetTypeSwitch:GetInt() == 3 and !ply:IsNPC() then return false end

return true

end

hook.Add( "CreateMove", "TrooperAim", function( UCMD )

local trace = LocalPlayer():GetEyeTrace()

if trace.Entity:IsValid() and AimbotSwitch:GetBool() and WeaponCheck() and StatusCheck( trace.Entity ) then

UCMD:SetViewAngles( ( GetTarget( trace.Entity ) - LocalPlayer():GetShootPos() ):Angle() )

end

if AutoshootSwitch:GetBool() and WeaponCheck() and LocalPlayer():Alive() and LocalPlayer():GetActiveWeapon():IsValid() and trace.Entity:IsValid() and StatusCheck( trace.Entity ) then

if !Firing then

RunConsoleCommand( "+attack" )
LocalPlayer():GetActiveWeapon().SetNextPrimaryFire( LocalPlayer():GetActiveWeapon() )
Firing = true

end

else

if Firing then

RunConsoleCommand( "-attack" ) 
Firing = false

end

end

if NorecoilSwitch:GetBool() and WeaponCheck() and LocalPlayer():Alive() and LocalPlayer():GetActiveWeapon():IsValid() and LocalPlayer():GetActiveWeapon().Primary then

LocalPlayer():GetActiveWeapon().Primary.Recoil = 0

end

end )

local function WeaponGet( ply )

if ply:IsValid() and ply:GetActiveWeapon() and ply:GetActiveWeapon():IsValid() then

return ply:GetActiveWeapon():GetClass()

else

return "none"

end

end

local function UsergroupGet( ply )

if ply:IsValid() then

local Group

if ply:IsUserGroup( "superadmin" ) then
Group = "Superadmin"
elseif ply:IsUserGroup( "admin" ) then
Group = "Admin"
else
Group = "Player"
end

return Group

else

return "none"

end

end

hook.Add( "HUDPaint", "TrooperWH", function()

if WallhackSwitch:GetBool() then

for k,v in pairs ( player.GetAll() ) do

local Position = ( v:GetPos() + Vector( 0,0,80 ) ):ToScreen()
local Name = ""
local nColor = Color( 255, 255, 255, 255 )

if v == LocalPlayer() then Name = "" else Name = v:Name() end
if !v:Alive() then 
Name = "*Dead* " .. Name 
nColor = Color( 0,0,0,255 )
else
nColor = team.GetColor( v:Team() ) 
end

draw.DrawText( Name, "MenuLarge", Position.x, Position.y, nColor, 1 )

if HealthSwitch:GetBool() then

draw.DrawText( "HP: " .. v:Health(), "UiBold", Position.x , Position.y + 12, nColor, 1 )

end

if WeaponSwitch:GetBool() then

local Math
if HealthSwitch:GetBool() then Math = 22 else Math = 12 end

draw.DrawText( "Weapon: " .. WeaponGet( v ), "UiBold", Position.x , Position.y + Math, nColor, 1 )

end

if UsergroupSwitch:GetBool() then

local Math
if WeaponSwitch:GetBool() and HealthSwitch:GetBool() then
Math = 32
elseif !HealthSwitch:GetBool() and WeaponSwitch:GetBool() or !WeaponSwitch:GetBool() and HealthSwitch:GetBool() then
Math = 22
else
Math = 12
end

draw.DrawText( "Usergroup: " .. UsergroupGet( v ), "UiBold", Position.x , Position.y + Math, nColor, 1 )

end

end

end

if DarkrpSwitch:GetBool() then

for count, ent in pairs ( ents.GetAll() ) do

if table.HasValue( DarkrpEnts, ent:GetClass() ) then

local Position = ent:GetPos():ToScreen()
draw.DrawText( ent:GetClass(), "MenuLarge", Position.x, Position.y, nColor, 1 )

end

end

end

end )

concommand.Add( "+trooper_menu", function()

Menu.Main = vgui.Create( "DFrame")
Menu.Main:SetSize( 400, 280 )
Menu.Main:SetTitle( "Trooper Hack " .. Version )
Menu.Main:Center()
Menu.Main:MakePopup()

local AdvTab = vgui.Create( "DPropertySheet", Menu.Main )
AdvTab:SetPos( 5, 25 )
AdvTab:SetSize( 390, 250 )

local Page1 = vgui.Create( "DImage" )
Page1:SetImage( "console/intro" )
AdvTab:AddSheet( "Aimbot", Page1, "gui/silkicons/bomb", false, false, "Aimbot configuration" )

local AimbotToggle = vgui.Create( "DCheckBoxLabel", Page1 )
AimbotToggle:SetPos( 10, 10 )
AimbotToggle:SetText( "Aimbot" )
AimbotToggle:SetValue( GetConVar( AimbotSwitch:GetName() ):GetInt() )
AimbotToggle:SetConVar( AimbotSwitch:GetName() )
AimbotToggle:SizeToContents()

local AimbotTarget = vgui.Create( "DMultiChoice", Page1 )
AimbotTarget:SetPos( 270, 5 )
AimbotTarget:SetSize( 100, 20 )
AimbotTarget:SetEditable( false )
AimbotTarget:AddChoice( "Head" )
AimbotTarget:AddChoice( "Center" )
AimbotTarget:ChooseOptionID( BoneSwitch:GetInt() )
AimbotTarget.OnSelect = function( index, value, data )
RunConsoleCommand( BoneSwitch:GetName(), value )
end

local AutoshootToggle = vgui.Create( "DCheckBoxLabel", Page1 )
AutoshootToggle:SetPos( 10, 40 )
AutoshootToggle:SetText( "Autoshoot" )
AutoshootToggle:SetValue( AutoshootSwitch:GetInt() )
AutoshootToggle:SetConVar( AutoshootSwitch:GetName() )
AutoshootToggle:SizeToContents()

local NorecoilToggle = vgui.Create( "DCheckBoxLabel", Page1 )
NorecoilToggle:SetPos( 10, 70 )
NorecoilToggle:SetText( "No-recoil" )
NorecoilToggle:SetValue( NorecoilSwitch:GetInt() )
NorecoilToggle:SetConVar( NorecoilSwitch:GetName() )
NorecoilToggle:SizeToContents()

local TeamToggle = vgui.Create( "DCheckBoxLabel", Page1 )
TeamToggle:SetPos( 10, 100 )
TeamToggle:SetText( "Ignore team-mates" )
TeamToggle:SetValue( TeamSwitch:GetInt() )
TeamToggle:SetConVar( TeamSwitch:GetName() )
TeamToggle:SizeToContents()

local FriendToggle = vgui.Create( "DCheckBoxLabel", Page1 )
FriendToggle:SetPos( 10, 130 )
FriendToggle:SetText( "Ignore steam friends" )
FriendToggle:SetValue( FriendSwitch:GetInt() )
FriendToggle:SetConVar( FriendSwitch:GetName() )
FriendToggle:SizeToContents()

local TargetToggle = vgui.Create( "DCheckBoxLabel", Page1 )
TargetToggle:SetPos( 10, 160 )
TargetToggle:SetText( "Specific target" )
TargetToggle:SetValue( TargetSwitch:GetInt() )
TargetToggle:SetConVar( TargetSwitch:GetName() )
TargetToggle:SizeToContents( index, value, data )
TargetToggle.OnChange = function()
TeamToggle:SetDisabled( TargetSwitch:GetBool() )
FriendToggle:SetDisabled( TargetSwitch:GetBool() )
end

local TargetList = vgui.Create( "DMultiChoice", Page1 )
TargetList:SetPos( 220, 155 )
TargetList:SetSize( 130, 20 )
TargetList:SetEditable( false )
for k,v in pairs ( player.GetAll() ) do
TargetList:AddChoice( v:Name() )
end
TargetList:ChooseOptionID( PlayerID( Target ) or 1 )
TargetList.OnSelect = function( index, value, data )
Target = player.GetByID( value )
end

local InfoSelect = vgui.Create( "DLabel", Page1 )
InfoSelect:SetPos( 20, 190 )
InfoSelect:SetText( "Target:" )
InfoSelect:SizeToContents()

local TargetType = vgui.Create( "DMultiChoice", Page1 )
TargetType:SetPos( 60, 185 )
TargetType:SetSize( 70, 20 )
TargetType:SetEditable( false )
TargetType:AddChoice( "All" )
TargetType:AddChoice( "Player" )
TargetType:AddChoice( "NPC" )
TargetType:ChooseOptionID( TargetTypeSwitch:GetInt() )
TargetType.OnSelect = function( index, value, data )
RunConsoleCommand( TargetTypeSwitch:GetName(), value )
end

local Page2 = vgui.Create( "DImage" )
Page2:SetImage( "console/intro" )
AdvTab:AddSheet( "Wallhack", Page2, "gui/silkicons/group", false, false, "Wallhack configuration" )

local WallhackToggle = vgui.Create( "DCheckBoxLabel", Page2 )
WallhackToggle:SetPos( 10, 10 )
WallhackToggle:SetText( "Wallhack" )
WallhackToggle:SetValue( WallhackSwitch:GetInt() )
WallhackToggle:SetConVar( WallhackSwitch:GetName() )
WallhackToggle:SizeToContents()

local HealthToggle = vgui.Create( "DCheckBoxLabel", Page2 )
HealthToggle:SetPos( 30, 40 )
HealthToggle:SetText( "Show health")
HealthToggle:SetValue( HealthSwitch:GetInt() )
HealthToggle:SetConVar( HealthSwitch:GetName() )
HealthToggle:SizeToContents()

local WeaponToggle = vgui.Create( "DCheckBoxLabel", Page2 )
WeaponToggle:SetPos( 30, 70 )
WeaponToggle:SetText( "Show weapon" )
WeaponToggle:SetValue( WeaponSwitch:GetInt() )
WeaponToggle:SetConVar( WeaponSwitch:GetName() )
WeaponToggle:SizeToContents()

local UsergroupToggle = vgui.Create( "DCheckBoxLabel", Page2 )
UsergroupToggle:SetPos( 30, 100 )
UsergroupToggle:SetText( "Show usergroup" )
UsergroupToggle:SetValue( UsergroupSwitch:GetInt() )
UsergroupToggle:SetConVar( UsergroupSwitch:GetName() )
UsergroupToggle:SizeToContents()

WallhackToggle.OnChange = function()
HealthToggle:SetDisabled( !WallhackSwitch:GetBool() )
WeaponToggle:SetDisabled( !WallhackSwitch:GetBool() )
UsergroupToggle:SetDisabled( !WallhackSwitch:GetBool() )
end

local DarkrpToggle = vgui.Create( "DCheckBoxLabel", Page2 )
DarkrpToggle:SetPos( 10, 130 )
DarkrpToggle:SetText( "DarkRP Entities" )
DarkrpToggle:SetValue( DarkrpSwitch:GetInt() )
DarkrpToggle:SetConVar( DarkrpSwitch:GetName() )
DarkrpToggle:SizeToContents()

end )

concommand.Add( "-trooper_menu", function()

Menu.Main:Remove()

end )
