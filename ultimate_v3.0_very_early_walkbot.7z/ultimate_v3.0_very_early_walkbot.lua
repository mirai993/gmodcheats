require("zxcmodule")

local surface, draw = surface, draw
local math, player = math, player
local table, util = table, util

local scrw, scrh = ScrW(), ScrH()

local pairs, ipairs = pairs, ipairs
local Vector, Angle, Color = Vector, Angle, Color
local IsValid = IsValid
local TraceLine, TraceHull = util.TraceLine, util.TraceHull

local mtan = math.tan
local mabs, msin, mcos, mClamp, mrandom, mRand = math.abs, math.sin, math.cos, math.Clamp, math.random, math.Rand
local mceil, mfloor, msqrt, mrad, mdeg = math.ceil, math.floor, math.sqrt, math.rad, math.deg
local mmin, mmax = math.min, math.max
local mNormalizeAng = math.NormalizeAngle
local band, bor, bnot = bit.band, bit.bor, bit.bnot
local matan2, mRound = math.atan2, math.Round

local TICK_INTERVAL = engine.TickInterval()

local sSetColor = surface.SetDrawColor
local sDrawRect = surface.DrawRect
local dDrawOutline = surface.DrawOutlinedRect
local sSetFont = surface.SetFont
local sGetTextSize = surface.GetTextSize

local sSetTColor = surface.SetTextColor
local sSetTPos = surface.SetTextPos
local sDrawText = surface.DrawText

local splay = surface.PlaySound

local input = input 
local iIsKeyDown = input.IsKeyDown

local me = LocalPlayer()

local function drawRect(x,y,w,h,color)
    sSetColor(color.r,color.g,color.b,color.a)
    sDrawRect(x,y,w,h)
end

local function drawOutline(x,y,w,h,color)
    sSetColor(color.r,color.g,color.b,color.a)
    dDrawOutline(x,y,w,h)
end

local function drawTexture(x,y,w,h,c,m)
	surface.SetDrawColor( c ) 
	surface.SetMaterial( m )
	surface.DrawTexturedRect( x, y, w, h ) 
end

local colors = {}

for i = 1,255 do  // 50 shades of grey
    colors[i] = Color(i,i,i,255)
end

surface.CreateFont( "pixel-font", {
	font = "Open Sans", 
	extended = false,
	size = 15,
	weight = 100,
	additive = false,
} )

local sui = {}

sui.cfg = {
    // aimbot
    ["Enable aimbot"] = false,
    ["Silent me"] = 1,
    ["Norecoil"] = false,
    ["Nospread"] = false,
    ["Rapid fire"] = false,
    ["Delay"] = false,
    ["Run'n'Gun"] = false,
    ["Force backstab"] = false,
    ["Double tap"] = false,
    ["Wallz"] = false,
    ["pSilent"] = false,
    ["Auto fire"] = false,
    ["Auto reload"] = false,

    ["Autopeak"] = false,

    ["Autopeak settings-Auto pullback"] = false,
    ["Autopeak settings-Auto reset"] = false,
    ["Autopeak settings-Animation"] = false,

    ["Autopeak style"] = 1,

    // Targeting
    ["Target selection"] = 1,
    ["Hitbox selection"] = 1,

    ["Ignore players-Friends"] = false,
    ["Ignore players-Teammates"] = false,
    ["Ignore players-Admins"] = false,
    ["Ignore players-Bots"] = false,
    ["Ignore players-Steam friends"] = false,
    ["Ignore players-Frozen"] = false,
    ["Ignore players-Nodraw"] = false,
    ["Ignore players-Nocliping"] = false,
    ["Ignore players-God time"] = false,
    ["Ignore players-High veloicty"] = false,
    ["Ignore players-Head unhitable"] = false,

    ["interp"] = false,
    ["extrapolate"] = false,
    ["lagfix"] = false,
    ["forwardtrack"] = false,

    ["Resolver-Fake AA"] = false,
    ["Resolver-Animations"] = false,
    ["Resolver-Error models"] = false,

    --["pSilent"] = false,

    ["Multipoint"] = false,
    ["Multipoint scale"] = 6,

    ["Enable hitscan"] = false,
    ["Scan hitboxes-Head"] = false,
    ["Scan hitboxes-Upper body"] = false,
    ["Scan hitboxes-Lower body"] = false,
    ["Scan hitboxes-Penis"] = false,
    ["Scan hitboxes-Legs"] = false,
    ["Scan hitboxes-Arms"] = false,
    ["Scan hitboxes-Foot"] = false,

    ["Bt mode"] = 1,
    ["interp scale"] = 0.2,

    ["fake latency"] = false,
    ["latency amt"] = 0.2,
    // anti me
    ["Anti aim"] = false,

    ["Yaw base"] = 1,
    ["Pitch"] = 1,
    ["Pitch min jitter"] = 45,
    ["Pitch max jitter"] = -45,
    ["Custom pitch"] = 89,

    ["Yaw"] = 1,
    ["Spin speed"] = 5,
    ["switch real time"] = 0.6,
    ["Jitter range"] = 89,
    ["Custom real yaw"] = 1,
   
    ["Fake Yaw"] = 1,
    ["fSpin speed"] = 5,
    ["switch fake time"] = 0.6,
    ["fJitter range"] = 89,
    ["Custom fake yaw"] = 1,

    ["Free standing"] = false,
    ["Dancer"] = false,
    ["Dance"] = 1,
    ["Arm breaker"] = false,
    ["Arm breaker mode"] = 1,
    ["Fake duck"] = false,
    ["Fake duck mode"] = 1,
    ["Fake walk"] = false,
    ["Crimwalk"] = false,

    ["Air crouch"] = false,
    ["Air crouch mode"] = 1,

    // fake lag
    ["Fake lag"] = false,

    ["Fake lag options-Disable on ladder"] = false,
    ["Fake lag options-Disable in attack"] = false,
    ["Fake lag options-Randomise"] = false,

    ["Lag mode"] = 1,

    ["Lag limit"] = 1,
    ["Lag randomisation"] = 1,
    
    // sequance manip
    ["Sequance manip"] = false,
    ["Sequance safe mode"] = false,
    ["OutSequance"] = 500,

    // tickbase manip
    ["Warp"] = false,
    ["Warp shift"] = 24,
    ["Warp on peek"] = false,

    // ESP
    ["Bounding box"] = false,



    // Movement
    ["Bhop"] = false,
    ["Safe hop"] = false,
    ["Edge jump"] = false,
    ["Air duck"] = false,

    ["Air strafer"] = false,
    ["Strafe mode"] = 1,
    ["Ground strafer"] = false,

    ["Circle strafe"] = false,
    ["CStrafe ticks"] = 64,
    ["CStrafe angle step"] = 1,
    ["CStrafe angle max step"] = 10, 
    ["CStrafe ground diff"] = 10,

    // Misc
    ["Name Convar"] = "",
    ["Disconnect reason"] = "VAC banned from secure server",
    ["cmd spam"] = false,
    ["cmd command"] = "lua_dumptimers_sv",
    ["cmd delay"] = 1,
    ["cmd force"] = 100,
    ["Auto reconnect"] = false,

   
}


sui.frame = vgui.Create("DFrame",nil,"sui")
sui.upbar = vgui.Create("DFrame",nil,"sui_")
sui.tab = "Aimbot"
sui.bgp = nil
sui.leftPanel = nil
sui.middlePanel = nil
sui.rightPanel = nil
sui.multicombo = false
sui.tabs = {}

// elements
function sui.checkbox(str,cfg,pan,color)
    local p = vgui.Create("DPanel",pan)
    p:SetTall(35)
    p:Dock(TOP)
    p:DockMargin(3,3,3,0)

    p.Paint = function(s,w,h)
        if sui.cfg[cfg] then
            sSetTColor(colors[235])
        else
            sSetTColor(colors[200])
        end

        sSetFont("pixel-font")
        sSetTPos(12,h/2-15/2)
        sDrawText(str)

        sSetColor(colors[54])
        dDrawOutline(0,0,w,h)
    end

    local c = p:Add("DCheckBox")
    c:SetPos(270,7)
    c:SetSize(20,20)
    c:SetValue(sui.cfg[cfg])

    function c:Paint(w,h)
        if sui.cfg[cfg] or self:OnDepressed() then
            sSetColor(colors[54])
        elseif self:IsHovered() then
            sSetColor(colors[40])
        else
            sSetColor(colors[35])
        end
        
        sDrawRect(4,4,w-8,h-8)

        sSetColor(colors[54])
        dDrawOutline(0,0,w,h)
    end

    function c:OnChange( bVal )
        sui.cfg[cfg] = bVal
    end
end

function sui.dropdownButton(str,v,p,a)
    local b = p:Add("DButton")
    b:Dock(TOP)
    b:SetTall(20)
    b:DockMargin(2,2,2,0)
    b:SetText("")
    
    function b:Paint(w,h)
        drawRect(0,0,w,h,colors[24])

        sSetTColor(colors[145])
        sSetColor(colors[40])

        if sui.cfg[str.."-"..v] then
            sSetTColor(colors[245]) 
            sSetColor(colors[54])
        end

        sSetTPos(5,3)
        sSetFont("pixel-font")
        sDrawText(v)

        dDrawOutline(0,0,w,h)
    end

    function b:DoClick()
        sui.cfg[str.."-"..v] = not sui.cfg[str.."-"..v] 
    end
end

function sui.button(str,func,pan)
    local p = vgui.Create("DPanel",pan)
    p:SetTall(35)
    p:Dock(TOP)
    p:DockMargin(3,3,3,0)

    sSetFont("pixel-font")
    local pw, ph = sGetTextSize(str)

    p.Paint = function(s,w,h)
        sSetColor(colors[54])
        dDrawOutline(0,0,w,h)
    end

    local d = p:Add("DButton")
    d:Dock(FILL)
    d:DockMargin(4,4,4,4)
    d:SetText("")

    function d:Paint(w,h)
        if self:OnDepressed() then
            sSetColor(colors[54])
            sSetTColor(colors[252])
        elseif self:IsHovered() then
            sSetColor(colors[40])
            sSetTColor(colors[242])
        else
            sSetColor(colors[35])
            sSetTColor(colors[235])
        end

        sDrawRect(0,0,w,h)

        sSetColor(colors[54])
        dDrawOutline(0,0,w,h)

        sSetFont("pixel-font")
        sSetTPos(w/2-pw/2,h/2-15/2)
        sDrawText(str)
    end

    function d:DoClick()
        func()
    end

end

function sui.textInput(str,cfg,pan,chars)
    local p = vgui.Create("DPanel",pan)
    p:SetTall(35)
    p:Dock(TOP)
    p:DockMargin(3,3,3,0)

    sSetFont("pixel-font")
    local pw, ph = sGetTextSize(str)

    p.Paint = function(s,w,h)
        sSetColor(colors[54])
        dDrawOutline(0,0,w,h)
    end
	
	local textInput = p:Add("DTextEntry")
	textInput:Dock(FILL)
	textInput:DockMargin(4,4,4,4)
	textInput:IsMultiline( false )
	textInput:SetMaximumCharCount(chars)
	textInput:SetPlaceholderText(str)
	textInput:SetFont( "pixel-font" )
    textInput:SetPaintBackground(false)
    textInput:SetTextColor(Color(255,255,2555))

	if sui.cfg[cfg] != nil and sui.cfg[cfg] != "" then
		textInput:SetValue(sui.cfg[cfg])
	end

	textInput.Think = function()
		if textInput:IsEditing() then
			editingText	= true
		else
			editingText = false
		end
		sui.cfg[cfg] = textInput:GetValue()
	end 

	textInput.OnValueChange = function()
		sui.cfg[cfg] = textInput:GetValue()
	end
end

function sui.multiCombo(str,choices,pan)
    local p = vgui.Create("DPanel",pan)
    p:SetTall(35)
    p:Dock(TOP)
    p:DockMargin(3,3,3,0)

    p.Paint = function(s,w,h)
        sSetTColor(colors[235])

        sSetFont("pixel-font")
        sSetTPos(12,h/2-15/2)
        sDrawText(str)

        sSetColor(colors[54])
        dDrawOutline(0,0,w,h)
    end

    local d = p:Add("DButton")
    d:SetPos(125,7)
    d:SetSize(165,20)
    d:SetText("")
    
    d.preview = {}

    function d:Paint(w,h)
        local preview = ""

        for k, v in pairs(choices) do
            if sui.cfg[str.."-"..v] == true and (d.preview[v] == false or d.preview[v] == nil) and not table.HasValue(d.preview, v) then
                table.insert(d.preview,v) 
            elseif sui.cfg[str.."-"..v] == false and (d.preview[v] == true or d.preview[v] == nil) and table.HasValue(d.preview, v) then
                table.RemoveByValue(d.preview,v)
            elseif d.preview[v] == false then 
                table.RemoveByValue(d.preview,v)
            end
        end

        preview = table.concat(d.preview,", ")

        sSetColor(25,25,25)
        sDrawRect(0,0,w,h)
    
        sSetTColor(245,245,245)
        sSetTPos(8,20/2-15/2)
        sSetFont("pixel-font")
        sDrawText(preview)
    
        sSetColor(32,32,32)
        sDrawRect(w-25,0,25,25)
    
        sSetTColor(222,222,222)
        sSetTPos(w-20,20/2-15/2)
        sSetFont("pixel-font")
        sDrawText("▼")

        sSetColor(colors[54])
        dDrawOutline(0,0,w,h)
    end

    function d:DoClick()
        local x,y = self:LocalToScreen( 0, self:GetTall() )
        d.reload = true
        if IsValid(sui.multicombo) then
            sui.multicombo:Remove()
        end
        --local x,y = input.GetCursorPos()
        local ctoh = #choices
    
        sui.multicombo = vgui.Create("DPanel")
        sui.multicombo:SetPos(x,y-1)
        sui.multicombo:SetSize(165,ctoh*22+2)
        sui.multicombo:MakePopup()
        sui.multicombo:RequestFocus()
    
        sui.multicombo.lt = 0
    
        function sui.multicombo:Paint(w,h)
            if sui.multicombo.lt < 15 then
                sui.multicombo.lt = sui.multicombo.lt + 1
            end

            drawRect(0,0,w,h,colors[24])
            drawOutline(0,0,w,h,colors[54])
    
            if IsValid(sui.multicombo) and not sui.multicombo:HasFocus() and sui.multicombo.lt >= 14 then
                sui.multicombo:Remove()
            end
        end
    
        for k, v in pairs(choices) do
            sui.dropdownButton(str,v,sui.multicombo,d.preview)
        end
    end

end

function sui.dropdown(str, choices, cfg, pan)
    local p = vgui.Create("DPanel",pan)
    p:SetTall(35)
    p:Dock(TOP)
    p:DockMargin(3,3,3,0)

    p.Paint = function(s,w,h)
        if sui.cfg[cfg] then
            sSetTColor(colors[235])
        else
            sSetTColor(colors[200])
        end

        sSetFont("pixel-font")
        sSetTPos(12,h/2-15/2)
        sDrawText(str)

        sSetColor(colors[54])
        dDrawOutline(0,0,w,h)
    end

    local dropdown = p:Add("DComboBox")
    dropdown:SetPos(125,7)
    dropdown:SetSize(165,20)

    for k, v in ipairs(choices) do
        dropdown:AddChoice(v)
    end
    dropdown:SetSortItems(false)

    if sui.cfg[cfg] <= #choices then
        dropdown:ChooseOptionID(sui.cfg[cfg])
    else
        dropdown:ChooseOptionID(1)
    end

    function dropdown:OnSelect(index, value, data)
        sui.cfg[cfg] = index
    end

    dropdown.Paint = function(self,w,h)
        sSetColor(25,25,25)
        sDrawRect(0,0,w,h)
    
        sSetColor(32,32,32)
        sDrawRect(w-25,0,25,25)
    
        sSetTColor(222,222,222)
        sSetTPos(w-20,20/2-15/2)
        sSetFont("pixel-font")
        sDrawText("▼")

        sSetColor(colors[54])
        dDrawOutline(0,0,w,h)
    end

    function dropdown:OnMenuOpened(m)
        function m:Paint(w,h)
            sSetColor(colors[24])
            sDrawRect(0,0,w,h)
            sSetColor(colors[54])
            dDrawOutline(0,-1,w,h+1)
        end
    end

    dropdown.DropButton.Paint = nil
    dropdown.PerformLayout = function(self)
        self:SetTextColor(Color(255,255,255))
        self:SetFont("pixel-font")
    end
end

function DMenuOption.Paint(s,w,h)
    if not s:IsHovered() then return end

    sSetColor(colors[48])
    dDrawOutline(3,3,w-6,h-6)
end

DMenuOption.PerformLayout = function(self)
    self:SetTextColor(colors[235])
    self:SetFont("pixel-font")
end

function sui.slider(str,cfg,min,max,dec,pan)
    local p = vgui.Create("DPanel",pan)
    p:SetTall(35)
    p:Dock(TOP)
    p:DockMargin(3,3,3,0)

    p.Paint = function(s,w,h)
        sSetTColor(colors[200])

        sSetFont("pixel-font")
        sSetTPos(12,h/2-15/2)
        sDrawText(str)

        sSetColor(colors[54])
        dDrawOutline(0,0,w,h)
    end

    local slider = p:Add("DNumSlider")
    slider:SetPos(125,7)
    slider:SetSize(165,20)
    slider:SetMin(min)
    slider:SetMax(max)
    slider:SetDefaultValue(sui.cfg[cfg])
    slider:ResetToDefaultValue()
    slider:SetDecimals(dec)

    slider.Label:Hide()

    slider.TextArea.Paint = function(s,w,h)
        if s:IsEditing() then
            sSetColor(colors[32])
        else
            sSetColor(colors[24])
        end
        
        sDrawRect(0,0,w,h)

        sSetColor(colors[54])
        dDrawOutline(0,0,w,h)

        sSetTColor(colors[235])
        sSetTPos(3,20/2-15/2)
        sSetFont("pixel-font")
        sDrawText(s:GetValue())
    end

    slider.TextArea:DockMargin(5,0,0,0)

    function slider:OnValueChanged()
        sui.cfg[cfg] = slider:GetValue()
    end
    
    slider.Slider.Paint = function(self,w,h)
        local getwidth, gettall = slider.Slider.Knob:GetPos()

        if self:IsHovered() or slider.Slider.Knob:IsHovered() then
            sSetColor(colors[30])
            sDrawRect(0,0,w,h)
            sSetColor(colors[48])
        else
            sSetColor(colors[25])
            sDrawRect(0,0,w,h)
            sSetColor(colors[40])
        end
        
        sDrawRect(0,0,getwidth,h)    

        sSetColor(colors[54])
        dDrawOutline(0,0,w,h)
    end
    
    slider.Slider.Knob:SetSize(15,18)	
    slider.Slider.Knob.Paint = function(self,w,h)
        if slider.Slider:IsHovered() or self:IsHovered() then
            sSetColor(colors[54])
        else
            sSetColor(colors[48])
        end
        
        sDrawRect(0,0,w,h)    
    end

    if !rp then
        slider.Slider:SetNotches(0)
        slider.Slider:SetNotchColor(Color(0,0,0,0))
    end

    slider.Scratch:SetVisible(false)
end

// tabs
function sui.tabs.Aimbot()
    // left panel
    sui.checkbox("Enable aimbot","Enable aimbot",sui.leftPanel)
    //sui.dropdown("Silent me", {"None","Clientside","Serverside"}, "Silent me", sui.leftPanel)
    //sui.checkbox("Run'n'Gun","Run'n'Gun",sui.leftPanel)
    //sui.checkbox("Force backstab","Force backstab",sui.leftPanel)
    //sui.checkbox("Double tap","Double tap",sui.leftPanel)
    sui.checkbox("Auto fire","Auto fire",sui.leftPanel)
    sui.checkbox("Auto reload","Auto reload",sui.leftPanel)
    sui.checkbox("Auto wallbang","Wallz",sui.leftPanel)
    sui.checkbox("Delay","Delay",sui.leftPanel)
    sui.checkbox("Rapid fire","Rapid fire",sui.leftPanel)
    --sui.checkbox("Autopeak","Autopeak",sui.leftPanel)
    --sui.multiCombo("Autopeak settings",{"Auto pullback","Auto reset","Animation"},sui.leftPanel)
    --sui.dropdown("Autopeak style", {"Circle","Glow","Filled circle"}, "Autopeak style", sui.leftPanel)

    // middle panel
    sui.checkbox("Norecoil","Norecoil",sui.middlePanel)
    sui.checkbox("Nospread","Nospread",sui.middlePanel)

   -- sui.dropdown("Backtrack", {"None","Legit","Rage"}, "Bt mode", sui.middlePanel)
    --sui.checkbox("Forwardtrack","forwardtrack",sui.middlePanel)

    sui.checkbox("Adjust command tick","lagfix",sui.middlePanel)
    sui.checkbox("pSilent","pSilent",sui.middlePanel)
    sui.multiCombo("Resolver",{"Fake AA","Animations","Error models"},sui.middlePanel)

    --sui.checkbox("Interpolation","interp",sui.middlePanel)
    --sui.slider("Fake interp","interp scale",0.1,5,2,sui.middlePanel)
    --sui.checkbox("Extrapolation","extrapolate",sui.middlePanel)

    --sui.checkbox("Fake latency","fake latency",sui.middlePanel)
    --sui.slider("Latency","latency amt",0.1,500,1,sui.middlePanel)
    
    // right panel
    sui.dropdown("Target selection", {"Closest distance","Field of view","Lowest health"}, "Target selection", sui.rightPanel)
    sui.dropdown("Hitbox selection", {"Head","Upper body","Lower body","Cock","Balls"}, "Hitbox selection", sui.rightPanel)
    sui.checkbox("Hitscan","Enable hitscan",sui.rightPanel)
    sui.multiCombo("Scan hitboxes",{"Head","Upper body","Lower body","Penis","Legs","Arms","Foot"},sui.rightPanel)
    sui.checkbox("Multipoint","Multipoint",sui.rightPanel)
    sui.slider("Multipoint scale","Multipoint scale",1,8,0,sui.rightPanel)
    

    sui.multiCombo("Ignore players",{"Friends","Bots","Steam friends","Frozen","Teammates","Admins","Nodraw","Nocliping","God time","High veloicty","Head unhitable"},sui.rightPanel)
end

function sui.tabs.Antime()
    // left panel
    sui.checkbox("Anti aim","Anti aim",sui.leftPanel)
    sui.dropdown("Yaw base", {"Viewangles","Static","At targets (Distance)","At me targets"}, "Yaw base", sui.leftPanel)

    sui.dropdown("Pitch", {"Viewangles","Zero","Down","Up","Fake down","Fake fake down","Jitter","Custom","Cadillac pitch","Cadillac jitter","Cadillac jitter up","Dalbaeb pitch","Dalbaeb pitch extreme"}, "Pitch", sui.leftPanel)
    sui.slider("Pitch min jitter","Pitch min jitter",-89,89,0,sui.leftPanel)
    sui.slider("Pitch max jitter","Pitch max jitter",-89,89,0,sui.leftPanel)
    sui.slider("Custom pitch","Custom pitch",-89,89,0,sui.leftPanel)

    sui.dropdown("Yaw", {"Forward","Backward","Left","Right","Spin","Reverse spin","Jitter","Center jitter","Custom","Switch","Tank AA"}, "Yaw", sui.leftPanel)
    sui.slider("Spin speed","Spin speed",1,100,0,sui.leftPanel)
    sui.slider("Jitter range","Jitter range",1,180,0,sui.leftPanel)
    sui.slider("Custom yaw","Custom real yaw",-360,360,0,sui.leftPanel)
    sui.slider("Switch time"," switch real time",0.1,10,1,sui.leftPanel)
   
    
    sui.dropdown("Fake yaw", {"Forward","Backward","Left","Right","Spin","Reverse spin","Jitter","Center jitter","Custom","Switch","Tank AA"}, "Fake Yaw", sui.leftPanel)
    sui.slider("Spin speed","fSpin speed",1,100,0,sui.leftPanel)
    sui.slider("Jitter range","fJitter range",1,180,0,sui.leftPanel)
    sui.slider("Custom yaw","Custom fake yaw",-360,360,0,sui.leftPanel)
    sui.slider("Switch time"," switch fake time",0.1,10,1,sui.leftPanel)


    // middle panel
    sui.checkbox("Freestanding","Free standing",sui.middlePanel)
    sui.checkbox("Dancer","Dancer",sui.middlePanel)
    sui.dropdown("Dance", {"Sex","1488 hz"}, "Dance", sui.middlePanel)
    sui.checkbox("Arm breaker","Arm breaker",sui.middlePanel)
    sui.dropdown("Arm breaker mode", {"Up","Down","Jitter","Fast Jitter"}, "Arm breaker mode", sui.middlePanel)
    sui.checkbox("Fake duck","Fake duck",sui.middlePanel)
    sui.dropdown("Fake duck mode", {"Default","Full"}, "Fake duck mode", sui.middlePanel)
    sui.checkbox("Fake walk","Fake walk",sui.middlePanel)
    sui.checkbox("Crimwalk","Crimwalk",sui.middlePanel)
    sui.checkbox("Air crouch","Air crouch",sui.middlePanel)
    sui.dropdown("Air crouch mode", {"Default","Spam"}, "Air crouch mode", sui.middlePanel)

    // right panel
    sui.checkbox("Fake lag","Fake lag",sui.rightPanel)
    sui.dropdown("Fake lag type", {"Static","Adaptive"}, "Lag mode", sui.rightPanel)
    sui.multiCombo("Fake lag options",{"Disable on ladder","Disable in attack","Randomise","Anti lagback"},sui.rightPanel)
    sui.slider("Fake lag limit","Lag limit",1,21,0,sui.rightPanel)
    sui.slider("Min randomisation","Lag randomisation",1,21,0,sui.rightPanel)

    sui.checkbox("Sequance manipulation","Sequance manip",sui.rightPanel)
    sui.checkbox("Sequance safe mode","Sequance safe mode",sui.rightPanel)
    sui.slider("Out sequance","OutSequance",1,5550,0,sui.rightPanel)

    sui.checkbox("Warp","Warp",sui.rightPanel)
    sui.slider("Warp shift","Warp shift",1,24,0,sui.rightPanel)
    sui.checkbox("Warp on peek","Warp on peek",sui.rightPanel)
end

function sui.tabs.ESP()
    // left panel
    sui.checkbox("Bounding box","Bounding box",sui.leftPanel)
    sui.dropdown("Box style", {"Default","Outlined","Corner","Outlined corner","3D Box"}, "Box style", sui.leftPanel)
    sui.dropdown("Box fill", {"None","Full","Gradient"}, "Box fill", sui.leftPanel)
    sui.checkbox("Health bar","Health bar",sui.leftPanel)
    sui.multiCombo("HP Bar",{"Filled background","Outline","Gradient","Auto color"},sui.rightPanel)
    sui.checkbox("Armor bar","Armor bar",sui.leftPanel)
    sui.multiCombo("AP Bar",{"Filled background","Outline","Gradient"},sui.rightPanel)
    sui.checkbox("Hitboxes","Hitboxes",sui.leftPanel)
    sui.checkbox("Skeleton","Skeleton",sui.leftPanel)
    sui.checkbox("Aim point","Aim point",sui.leftPanel)
    sui.checkbox("Aim line","Aim line",sui.leftPanel)
    sui.checkbox("Backtrack ticks","Backtrack ticks",sui.leftPanel)
    // middle panel
    sui.checkbox("Name","Name",sui.middlePanel)
    sui.checkbox("Health","Health",sui.middlePanel)
    sui.checkbox("Armor","Armor",sui.middlePanel)
    sui.checkbox("Weapon","Weapon",sui.middlePanel)
    sui.checkbox("Velocity","Velocity",sui.middlePanel)
    sui.checkbox("Simtime","Simtime",sui.middlePanel)
    sui.checkbox("Team","Team",sui.middlePanel)
    sui.checkbox("Group","Group",sui.middlePanel)
    sui.checkbox("Ping","Ping",sui.middlePanel)
    sui.checkbox("LBY / Target LBY","Players lby",sui.middlePanel)



end

function sui.tabs.Movement()
    // left panel
    sui.checkbox("Bunny hop","Bhop",sui.leftPanel)
    sui.checkbox("Safe hop","Safe hop",sui.leftPanel)
    sui.checkbox("Edge jump","Edge jump",sui.leftPanel)
    sui.checkbox("Air duck","Air duck",sui.leftPanel)

    // middle panel
    sui.checkbox("Air strafer","Air strafer",sui.middlePanel)
    sui.dropdown("Strafe mode", {"Default","Multidir"}, "Strafe mode", sui.middlePanel)
    sui.checkbox("Ground strafer","Ground strafer",sui.middlePanel)

    sui.checkbox("Circle strafe","Circle strafe",sui.middlePanel)
    sui.slider("Predict ticks","CStrafe ticks",1,128,0,sui.middlePanel)
    sui.slider("Angle step","CStrafe angle step",1,15,0,sui.middlePanel)
    sui.slider("Max angle step","CStrafe angle max step",1,100,0,sui.middlePanel)
    sui.slider("Ground diff","CStrafe ground diff",1,64,0,sui.middlePanel)







    // right panel
    sui.checkbox("Bunny hop","Bhop",sui.rightPanel)



end

function sui.tabs.Misc()

    

    // right panel
    sui.textInput("Name","Name Convar",sui.rightPanel,255)
    sui.button("Change name",sui.NetSetName,sui.rightPanel)
    sui.textInput("Disconnect reason","Disconnect reason",sui.rightPanel,255)
    sui.button("Disconnect",sui.NetDisconnect,sui.rightPanel)
    sui.checkbox("Command spammer","cmd spam",sui.rightPanel)
    sui.textInput("Cammand","cmd command",sui.rightPanel,255)
    sui.slider("Delay","cmd delay",0.5,5,1,sui.rightPanel)
    sui.slider("Force","cmd force",1,2000,0,sui.rightPanel)
    sui.checkbox("Auto reconnect","Auto reconnect",sui.rightPanel)
   
end

function sui.tabs.Cfg()

end

sui.menutabs = {}

sui.menutabs["Aimbot"] = sui.tabs.Aimbot
sui.menutabs["Anti-Aim"] = sui.tabs.Antime
sui.menutabs["ESP"] = sui.tabs.ESP
sui.menutabs["Movement"] = sui.tabs.Movement
sui.menutabs["Misc"] = sui.tabs.Misc
sui.menutabs["Config"] = sui.tabs.Cfg


// tab init
function sui.InitScrollPanel(p)
    p:SetWide(305)
    p:Dock(LEFT)
    p:DockMargin(4,4,0,4)

    function p:Paint(w,h)
        drawOutline(0,0,w,h,Color(54,54,54))
    end

    local vbar = p:GetVBar()

    vbar:SetWide(3)

    function vbar:Paint(w,h) 
        if self:IsHovered() then
            sSetColor(colors[32])
        else
            sSetColor(colors[24])
        end

        sDrawRect(0,0,w,h)
    end

    vbar.btnUp.Paint = nil

    vbar.btnDown.Paint = nil

    function vbar.btnGrip:Paint(w,h) 
        if self:IsHovered() then
            sSetColor(colors[54])
        else
            sSetColor(colors[48])
        end

        sDrawRect(0,0,w,h)
    end
end

function sui.InitTab(name)
    if sui.bgp != nil then sui.bgp:Remove() end

    if sui.leftPanel != nil then sui.leftPanel:Remove() end
    if sui.middlePanel != nil then sui.middlePanel:Remove() end
    if sui.rightPanel != nil then sui.rightPanel:Remove() end

    sui.bgp = sui.frame:Add("DPanel")
    sui.bgp:SetTall(634)
    sui.bgp:Dock(TOP)
    sui.bgp.Paint = nil 

    sui.leftPanel = sui.bgp:Add("DScrollPanel")
    sui.middlePanel = sui.bgp:Add("DScrollPanel")
    sui.rightPanel = sui.bgp:Add("DScrollPanel")
    sui.InitScrollPanel(sui.leftPanel)
    sui.InitScrollPanel(sui.middlePanel)
    sui.InitScrollPanel(sui.rightPanel)

    sui.menutabs[tostring(name)]()
end

function sui.tabButton(tab,pan,sd)
    sSetFont("pixel-font")
    local pw, ph = sGetTextSize(tab)

    local b = pan:Add("DButton")
    b:SetWide(pw+20) 
    b:Dock(LEFT)
    if sd then
        b:DockMargin(1,1,1,1)
    else
        b:DockMargin(4,0,0,1)
    end
    b:SetText("")
    
    function b:Paint(w,h) 
        if sui.tab == tab or self:OnDepressed() then
            sSetColor(colors[54])
            sSetTColor(245,245,245,255)
        elseif self:IsHovered() then
            sSetColor(colors[40])
            sSetTColor(225,225,225,255)
        else
            sSetColor(colors[30])
            sSetTColor(200,200,200,255)
        end
        
        sDrawRect(0,0,w,h)

        sSetFont("pixel-font")
        sSetTPos(w/2-pw/2,h/2-ph/2)
        sDrawText(tab)
    end

    function b:DoClick()
        sui.tab = tab
        sui.InitTab(tab)
        splay("ui/click.wav")
    end
end

// frame
local g = Material("gui/gradient_up")
function sui.Init()
    sui.frame:SetTitle("")
    sui.frame:ShowCloseButton(false)
    sui.frame:SetSize(950, 700)
    sui.frame:Center()
    sui.frame:MakePopup()

    sSetFont("pixel-font")
    local pw, ph = sGetTextSize("Bandera drip")

    function sui.frame:Paint(w,h)
        drawRect(0,0,w,h,colors[24]) --Color(24,24,24,245)
        drawRect(0,0,w,25,colors[54])
        drawTexture(0,0,w,25,colors[64],g)
        drawOutline(0,0,w,h,colors[54])

        sSetTColor(colors[222])
        sSetFont("pixel-font")
        sSetTPos(w/2-pw/2,25/2-ph/2)
        sDrawText("Bandera drip")
    end

    local tabs = sui.frame:Add("DPanel")
    tabs:SetTall(32)
    tabs:Dock(TOP)

    function tabs:Paint(w,h)
        drawRect(4,h-1,w-8,1,colors[54])
    end

    sui.tabButton("Aimbot",tabs)
    sui.tabButton("Anti-Aim",tabs)
    sui.tabButton("ESP",tabs)
    sui.tabButton("Visuals",tabs)
    sui.tabButton("Movement",tabs)
    sui.tabButton("Misc",tabs)
    sui.tabButton("Keybinds",tabs)
    sui.tabButton("Skins",tabs)
    sui.tabButton("Config",tabs)

    sui.InitTab(sui.tab)

    sui.upbar:SetTitle("")
    sui.upbar:ShowCloseButton(false)
    sui.upbar:SetSize(scrw, 32)
    sui.upbar:SetPos(0,0)
    sui.upbar:MakePopup()
    sui.upbar:SetDraggable(false)

    sSetFont("pixel-font")
    local pw, ph = sGetTextSize("Bandera drip")

    function sui.upbar:Paint(w,h)
        drawRect(0,0,w,h,colors[24]) 
        drawRect(0,0,pw+10,h,colors[54])
        drawTexture(0,0,pw+10,h,colors[64],g)
        drawOutline(0,0,w,h,colors[54])

        sSetTColor(colors[222])
        sSetFont("pixel-font")
        sSetTPos(5,32/2-ph/2)
        sDrawText("Bandera drip")
    end

    local uptabs = sui.upbar:Add("DPanel")
    uptabs:SetPos(pw+12,2)
    uptabs:SetSize(scrw-pw-14,28)
    uptabs.Paint = nil

    sui.tabButton("GLua",uptabs,true)
    sui.tabButton("NetChan",uptabs,true)
    sui.tabButton("CVars",uptabs,true)
    sui.tabButton("Spammers",uptabs,true)
    sui.tabButton("Console",uptabs,true)
    sui.tabButton("Players",uptabs,true)
    sui.tabButton("Entitys",uptabs,true)

end

function sui.menuThink()
    if iIsKeyDown(KEY_DELETE) and not keypressed then
        if sui.frame:IsVisible() then
            if sui.leftPanel != nil then sui.leftPanel:Remove() end
            if sui.middlePanel != nil then sui.middlePanel:Remove() end
            if sui.rightPanel != nil then sui.rightPanel:Remove() end

            if IsValid(sui.multicombo) then
                sui.multicombo:Remove()
            end

            sui.leftPanel = nil
            sui.middlePanel = nil
            sui.rightPanel = nil
            sui.multicombo = false

            sui.frame:SetVisible(false)
            sui.upbar:SetVisible(false)
        else
            sui.InitTab(sui.tab)
            sui.frame:SetVisible(true)
            sui.upbar:SetVisible(true)
        end
    end

    keypressed = iIsKeyDown(KEY_DELETE)
end

sui.Init()

// CreateMove

ded.SpoofConVar("cl_interpolate")
ded.SpoofedConVarSetNumber("cl_interpolate",0)


do 
    local tickrate = tostring(mRound(1 / TICK_INTERVAL))

    --ded.SpoofConVar("cl_extrapolate")
    --ded.SpoofedConVarSetNumber("cl_extrapolate",0)

	RunConsoleCommand("cl_cmdrate", tickrate)
	RunConsoleCommand("cl_updaterate", tickrate)

	RunConsoleCommand("cl_interp", "0")
	RunConsoleCommand("cl_interp_ratio", "0")

end

sui.target = nil
sui.targetVector = Vector(0,0,0)
sui.targetAngle = Angle(0,0,0)
sui.targetFOV = 360
sui.targetHealth = 100
sui.targetDistance = 1337

sui.fa = me:EyeAngles()
sui.silentAnglePos = me:EyePos()
sui.nextTick = false
sui.bsendpacket = true

sui.badSweps = {
    ["gmod_camera"] = true,
	["manhack_welder"] = true,
	["weapon_medkit"] = true,
	["gmod_tool"] = true,
	["weapon_physgun"] = true,
	["weapon_physcannon"] = true,
	["weapon_bugbait"] = true,
}

sui.badSeqs = {
	[ACT_VM_RELOAD] = true,
	[ACT_VM_RELOAD_SILENCED] = true,
	[ACT_VM_RELOAD_DEPLOYED] = true,
	[ACT_VM_RELOAD_IDLE] = true,
	[ACT_VM_RELOAD_EMPTY] = true,
	[ACT_VM_RELOADEMPTY] = true,
	[ACT_VM_RELOAD_M203] = true,
	[ACT_VM_RELOAD_INSERT] = true,
	[ACT_VM_RELOAD_INSERT_PULL] = true,
	[ACT_VM_RELOAD_END] = true,
	[ACT_VM_RELOAD_END_EMPTY] = true,
	[ACT_VM_RELOAD_INSERT_EMPTY] = true,
	[ACT_VM_RELOAD2] = true
}

sui.cones = {};
sui.nullVec = Vector() * -1;
sui.resolvedBoys = {}
sui.hurteddeg = {}

function sui.AutoWall(dir, plyTarget)
	local weap = me:GetActiveWeapon()
	if !IsValid(weap) then return false end
	local class = weap:GetClass()
    if class == "swb_knife" or class == "swb_knife_m" then return false end

	local eyePos = me:EyePos()
	
	local function CW2Autowall()
		local normalmask = bor(CONTENTS_SOLID, CONTENTS_OPAQUE, CONTENTS_MOVEABLE, CONTENTS_DEBRIS, CONTENTS_MONSTER, CONTENTS_HITBOX, 402653442, CONTENTS_WATER)
		local wallmask = bor(CONTENTS_TESTFOGVOLUME, CONTENTS_EMPTY, CONTENTS_MONSTER, CONTENTS_HITBOX)
		
		local tr = TraceLine({
			start = eyePos,
			endpos = eyePos + dir * weap.PenetrativeRange,
			filter = me,
			mask = normalmask
		})
		
		if tr.Hit and !tr.HitSky then
			local canPenetrate, dot = weap:canPenetrate(tr, dir)
			
			if canPenetrate and dot > 0.26 then
				tr = TraceLine({
					start = tr.HitPos,
					endpos = tr.HitPos + dir * weap.PenStr * (weap.PenetrationMaterialInteraction[tr.MatType] or 1) * weap.PenMod,
					filter = me,
					mask = wallmask
				})
				
				tr = TraceLine({
					start = tr.HitPos,
					endpos = tr.HitPos + dir * 0.1,
					filter = me,
					mask = normalmask
				}) -- run ANOTHER trace to check whether we've penetrated a surface or not
				
				if tr.Hit then return false end
				
				-- FireBullets
				tr = TraceLine({
					start = tr.HitPos,
					endpos = tr.HitPos + dir * 32768,
					filter = me,
					mask = MASK_SHOT
				})
				
				return tr.Entity == plyTarget
			end
		end
		
		return false
	end
	
	local function SWBAutowall()
		local normalmask = bor(CONTENTS_SOLID, CONTENTS_OPAQUE, CONTENTS_MOVEABLE, CONTENTS_DEBRIS, CONTENTS_MONSTER, CONTENTS_HITBOX, 402653442, CONTENTS_WATER)
		local wallmask = bor(CONTENTS_TESTFOGVOLUME, CONTENTS_EMPTY, CONTENTS_MONSTER, CONTENTS_HITBOX)
		local penMod = {[MAT_SAND] = 0.5, [MAT_DIRT] = 0.8, [MAT_METAL] = 1.1, [MAT_TILE] = 0.9, [MAT_WOOD] = 1.2}
		
		
		local tr = TraceLine({
			start = eyePos,
			endpos = eyePos + dir * weap.PenetrativeRange,
			filter = me,
			mask = normalmask
		})
		
		if tr.Hit and !tr.HitSky then
			local dot = -dir:Dot(tr.HitNormal)
			
			if weap.CanPenetrate and dot > 0.26 then
				tr = TraceLine({
					start = tr.HitPos,
					endpos = tr.HitPos + dir * weap.PenStr * (penMod[tr.MatType] or 1) * weap.PenMod,
					filter = me,
					mask = wallmask
				})
				
				tr = TraceLine({
					start = tr.HitPos,
					endpos = tr.HitPos + dir * 0.1,
					filter = me,
					mask = normalmask
				}) -- run ANOTHER trace to check whether we've penetrated a surface or not
				
				if tr.Hit then return false end
				
				-- FireBullets
				tr = TraceLine({
					start = tr.HitPos,
					endpos = tr.HitPos + dir * 32768,
					filter = me,
					mask = MASK_SHOT
				})
				
				return tr.Entity == plyTarget
			end
		end
		
		return false
	end
	
	local function M9KAutowall()
		if !weap.Penetration then
			return false
		end

		local function BulletPenetrate(tr, bounceNum, damage)
			if damage < 1 then
				return false
			end
			
			local maxPenetration = 14
			if weap.Primary.Ammo == "SniperPenetratedRound" then -- .50 Ammo
				maxPenetration = 20
			elseif weap.Primary.Ammo == "pistol" then -- pistols
				maxPenetration = 9
			elseif weap.Primary.Ammo == "357" then -- revolvers with big ass bullets
				maxPenetration = 12
			elseif weap.Primary.Ammo == "smg1" then -- smgs
				maxPenetration = 14
			elseif weap.Primary.Ammo == "ar2" then -- assault rifles
				maxPenetration = 16
			elseif weap.Primary.Ammo == "buckshot" then -- shotguns
				maxPenetration = 5
			elseif weap.Primary.Ammo == "slam" then -- secondary shotguns
				maxPenetration = 5
			elseif weap.Primary.Ammo == "AirboatGun" then -- metal piercing shotgun pellet
				maxPenetration = 17
			end

			local isRicochet = false
			if weap.Primary.Ammo == "pistol" or weap.Primary.Ammo == "buckshot" or weap.Primary.Ammo == "slam" then
				isRicochet = true
			else
				/*
				TODO: Predict ricochetCoin?
				if weap.RicochetCoin == 1 then
					isRicochet = true
				elseif weap.RicochetCoin >= 2 then
					isRicochet = false
				end*/
			end

			if weap.Primary.Ammo == "SniperPenetratedRound" then
				isRicochet = true
			end

			local maxRicochet = 0
			if weap.Primary.Ammo == "SniperPenetratedRound" then -- .50 Ammo
				maxRicochet = 10
			elseif weap.Primary.Ammo == "pistol" then -- pistols
				maxRicochet = 2
			elseif weap.Primary.Ammo == "357" then -- revolvers with big ass bullets
				maxRicochet = 5
			elseif weap.Primary.Ammo == "smg1" then -- smgs
				maxRicochet = 4
			elseif weap.Primary.Ammo == "ar2" then -- assault rifles
				maxRicochet = 5
			elseif weap.Primary.Ammo == "buckshot" then -- shotguns
				maxRicochet = 0
			elseif weap.Primary.Ammo == "slam" then -- secondary shotguns
				maxRicochet = 0
			elseif weap.Primary.Ammo == "AirboatGun" then -- metal piercing shotgun pellet
				maxRicochet = 8
			end

			if tr.MatType == MAT_METAL and isRicochet and weap.Primary.Ammo != "SniperPenetratedRound" then
				return false
			end

			if bounceNum > maxRicochet then
				return false
			end

			local penetrationDir = tr.Normal * maxPenetration
			if tr.MatType == MAT_GLASS or tr.MatType == MAT_PLASTIC or tr.MatType == MAT_WOOD or tr.MatType == MAT_FLESH or tr.MatType == MAT_ALIENFLESH then
				penetrationDir = tr.Normal * (maxPenetration * 2) -- WAS 200
			end

			if tr.Fraction <= 0 then
				return false
			end

			local trace = {}
			trace.endpos = tr.HitPos
			trace.start = tr.HitPos + penetrationDir
			trace.mask = MASK_SHOT
			trace.filter = me

			local trace = TraceLine(trace)

			if trace.StartSolid or trace.Fraction >= 1 then
				return false
			end

			local penTrace = {}
			penTrace.endpos = trace.HitPos + tr.Normal * 32768
			penTrace.start = trace.HitPos
			penTrace.mask = MASK_SHOT
			penTrace.filter = me

			penTrace = TraceLine(penTrace)

			if penTrace.Entity == plyTarget then return true end

			local damageMulti = 0.5
			if weap.Primary.Ammo == "SniperPenetratedRound" then
				damageMulti = 1
			elseif tr.MatType == MAT_CONCRETE or tr.MatType == MAT_METAL then
				damageMulti = 0.3
			elseif tr.MatType == MAT_WOOD or tr.MatType == MAT_PLASTIC or tr.MatType == MAT_GLASS then
				damageMulti = 0.8
			elseif tr.MatType == MAT_FLESH or tr.MatType == MAT_ALIENFLESH then
				damageMulti = 0.9
			end
			
			if penTrace.MatType == MAT_GLASS then
				bounceNum = bounceNum - 1
			end

			return BulletPenetrate(penTrace, bounceNum + 1, damage * damageMulti)
		end

		local trace = TraceLine({
			start = eyePos,
			endpos = eyePos + dir * 32768,
			filter = me,
			mask = MASK_SHOT
		})

		return BulletPenetrate(trace, 0, weap.Primary.Damage)
	end
	
	if class:StartWith("cw_") then
		return CW2Autowall()
	elseif class:StartWith("m9k_") then
		return M9KAutowall()
	elseif class:StartWith("swb_") then
		return SWBAutowall()
	end
	
	return false
end

do 
    function sui.VisibleCheck(who,where,pr)
        local startpos = me:EyePos()

        if pr then
            startpos = startpos + (me:GetVelocity() * TICK_INTERVAL) * extrselfticks
        end

        local tr = TraceLine({
            mask = MASK_SHOT,
            ignoreworld = false,
            filter = me,
            start = me:EyePos(),
            endpos = where
        })

        local canhit = tr.Entity == who or tr.Fraction == 1

        if sui.cfg["Ignore players-Head unhitable"] and tr.HitGroup != 1 then return false end
        
        if !canhit and sui.targetVector and sui.cfg["Wallz"] then 
            return sui.AutoWall(sui.targetAngle:Forward(), who)
        end

        return canhit
    end
end

do
    local bones = {
        [1] = "ValveBiped.Bip01_Head1",
        [2] = "ValveBiped.Bip01_Spine4",
        [3] = "ValveBiped.Bip01_Spine",
        [4] = "ValveBiped.Bip01_Pelvis",
        [5] = "ValveBiped.Bip01_L_Thigh",
    } 

    local hitscanbones = {
        [1] = "ValveBiped.Bip01_Head1",
        [2] = "ValveBiped.Bip01_Spine4",
        [3] = "ValveBiped.Bip01_Spine",
        [4] = "ValveBiped.Bip01_Pelvis",
        [5] = "ValveBiped.Bip01_L_Thigh",
        [6] = "ValveBiped.Bip01_R_Thigh",
        [7] = "ValveBiped.Bip01_R_Forearm",
        [8] = "ValveBiped.Bip01_L_Forearm",
        [9] = "ValveBiped.Bip01_L_Foot",
        [10] = "ValveBiped.Bip01_R_Foot",
    }

    local shouldscan = {
        [1] = "Scan hitboxes-Head",
        [2] = "Scan hitboxes-Upper body",
        [3] = "Scan hitboxes-Lower body",
        [4] = "Scan hitboxes-Penis",
        [5] = "Scan hitboxes-Legs",
        [6] = "Scan hitboxes-Legs",
        [7] = "Scan hitboxes-Arms",
        [8] = "Scan hitboxes-Arms",
        [9] = "Scan hitboxes-Foot",
        [10] = "Scan hitboxes-Foot",
    }

    function sui.getmeHitbox(v) 
        local mps = sui.cfg["Multipoint scale"]
        local pos = v:LocalToWorld(v:OBBCenter())
        local bone = bones[sui.cfg["Hitbox selection"]]

        if v:LookupBone(bone) != nil then
            pos = v:GetBonePosition(v:LookupBone(bone)) + (sui.cfg["Multipoint"] && Vector(0,0,mps) || Vector(0,0,0))
        end

        if sui.cfg["Enable hitscan"] then
            for i = 1,#hitscanbones do 
                if not sui.cfg[shouldscan[i]] then continue end
                if v:LookupBone(hitscanbones[i]) == nil then continue end
                if not sui.VisibleCheck(v,cvp) then continue end

                pos = v:GetBonePosition(v:LookupBone(hitscanbones[i])) 
            end

            return pos
        end

        return pos
    end
end

do
    local maxvel = GetConVar("sv_maxvelocity"):GetFloat()

    function sui.ValidateTarget(tar)
        if !IsValid(tar) then return false end
    
        if tar == me then return false end
        if tar:IsDormant() then return false end
        if !tar:Alive() then return false end
        if tar:Team() == TEAM_SPECTATOR then return false end
    
        if sui.cfg["Ignore players-High veloicty"] and tar:GetVelocity():Length() > maxvel - 600 then return false end
        if sui.cfg["Ignore players-Frozen"] and tar:IsFrozen() then return false end
        if sui.cfg["Ignore players-God time"] and tar:GetColor().a != 255 then return false end
        if sui.cfg["Ignore players-Nodraw"] and tar:GetNoDraw() then return false end 
        if sui.cfg["Ignore players-Admins"] and tar:IsAdmin() then return false end 
        if sui.cfg["Ignore players-Bots"] and tar:IsBot() then return false end 
        if sui.cfg["Ignore players-Steam friends"] and tar:GetFriendStatus() == "friend" then return false end 
        if sui.cfg["Ignore players-Nocliping"] and tar:IsEFlagSet(EFL_NOCLIP_ACTIVE) then return false end 
        if sui.cfg["Ignore players-Teammates"] and tar:Team() == me:Team() then return false end 
       -- if sui.cfg["Ignore players-Friends"] and table.HasValue(sui.cfg["friends"], tar:SteamID()) then return false end

        return true
    end
end

do
    function sui.addResolverStep(ent)
        if not sui.cfg["Resolver-Fake AA"] then return end
        if sui.hurteddeg[ent] > 0 then return end
        if sui.resolvedBoys[ent] != nil then
            sui.resolvedBoys[ent] = (sui.resolvedBoys[ent] + 30)%360
        else
            sui.resolvedBoys[ent] = 0
        end
    end
    
end

function sui.SetEntAngles(ent,angles)
    ent:InvalidateBoneCache()
    ent:SetupBones()
    ent:SetRenderAngles(angles)
    ent:SetNetworkAngles(angles)
    ded.SetCurrentLBY(ent:EntIndex(),angles.y)
end

local pitches = {-89,0,89}
function sui.visualResolver(ent)
    if sui.resolvedBoys[ent] == nil then return end
    local targetAngles = ent:GetAngles()
    targetAngles.r = 0

    targetAngles.y = mNormalizeAng(ded.GetEntEyeYaw(ent:EntIndex())+sui.resolvedBoys[ent])
    targetAngles.x = table.Random(pitches)

    sui.SetEntAngles(ent,targetAngles)
end

function sui.MovementFix( cmd, wish_yaw )

	local pitch = mNormalizeAng( cmd:GetViewAngles().x )
	local inverted = -1
	
	if ( pitch > 89 || pitch < -89 ) then
		inverted = 1
	end

	local ang_diff = math.rad( mNormalizeAng( ( cmd:GetViewAngles().y - wish_yaw )*inverted ) )

	local forwardmove = cmd:GetForwardMove()
	local sidemove = cmd:GetSideMove()

	local new_forwardmove = forwardmove*-math.cos( ang_diff )*inverted + sidemove*math.sin( ang_diff )
	local new_sidemove = forwardmove*math.sin( ang_diff )*inverted + sidemove*math.cos( ang_diff )

	cmd:SetForwardMove( new_forwardmove )
	cmd:SetSideMove( new_sidemove )
	
end

function sui.SilentAngles(cmd)
	if !sui.fa then sui.fa = cmd:GetViewAngles() end
	sui.fa = sui.fa + Angle(cmd:GetMouseY() * GetConVarNumber("m_yaw"), cmd:GetMouseX() * -GetConVarNumber("m_yaw"), 0)
	sui.fa.p = mClamp(sui.fa.p, -89, 89)
	--sui.fa.y = mNormalizeAng(sui.fa.y)
    sui.fa.r = 0
    sui.fa:Normalize()
end

function sui.CanShoot(cmd)
	local me = me
	local weap = me:GetActiveWeapon()
	if !IsValid(weap) then return false end
	local wact = weap:GetSequence()

	if sui.badSweps[weap:GetClass()] then
		return false
	end

    if me:GetMoveType() == MOVETYPE_NOCLIP then
        return false
    end

    if cmd:KeyDown(IN_ATTACK) then
        return false
    end

	if sui.cfg["Delay"] and weap:GetNextPrimaryFire() >= ded.GetServerTime(cmd) then
		return false
	end

	return weap:Clip1() != 0 and !sui.badSeqs[wact] 
end

GAMEMODE["EntityFireBullets"] = function(self, p, data) 
    local w = me:GetActiveWeapon()
    local spread = data.Spread * -1
    if !w or !IsValid(w) then return end

	if me:GetShootPos() == data.Src and IsFirstTimePredicted() then
        if sui.target != nil then
            if sui.hurteddeg[sui.target] != nil then
                sui.hurteddeg[sui.target] = sui.hurteddeg[sui.target] - 1
                sui.addResolverStep(sui.target)
            else
                sui.hurteddeg[sui.target] = 1
            end

            if sui.hurteddeg[sui.target] < 0 then sui.hurteddeg[sui.target] = 0 end

            print(sui.hurteddeg[sui.target])
       end
    end


	if sui.cones[w:GetClass()] == spread or spread == sui.nullVec then return end
    sui.cones[w:GetClass()] = spread;
    
end

function sui.Spread(cmd,ang,spread)
	local w = me:GetActiveWeapon()
	local class = w:GetClass()

	if (!w || !w:IsValid() || !sui.cones[w:GetClass()]) then return ang end

	spread = (spread.x + spread.y) / 2
	local dir = ded.PredictSpread(cmd, ang, spread)
	local newangle = ang + dir:Angle()
	newangle:Normalize()

	return newangle
end

function sui.NoRecoil(ang)  
	local w = me:GetActiveWeapon()
	local c = w:GetClass()

	if c:StartWith("m9k_") or c:StartWith("bb_") or c:StartWith("unclen8_") then
		return ang
	else
	    ang = ang - me:GetViewPunchAngles()
    end

	return ang
end

function sui.NoSpread(cmd, ang)
	local w = me:GetActiveWeapon()
	local class = w:GetClass()

    if !IsValid(w) then 
        return ang
    end

    if class == "swb_knife" or class == "swb_knife_m" then return ang end

    if class:StartWith("cw_") then		
		local function CalculateSpread()
			if not w.AccuracyEnabled then
				return
			end
			
			local me = ang:Forward()
			local CT = CurTime()
			local dt = TICK_INTERVAL --FrameTime()
			
			if !me.LastView then
				me.LastView = me
				me.ViewAff = 0
			else
				me.ViewAff = LerpCW20(dt * 10, me.ViewAff, (me - me.LastView):Length() * 0.5)
				me.LastView = me
			end
			
            
			local baseCone, maxSpreadMod = w:getBaseCone()
			w.BaseCone = baseCone
			
			if me:Crouching() then
				w.BaseCone = w.BaseCone * w:getCrouchSpreadModifier()
			end
			
			w.CurCone = w:getFinalSpread(me:GetVelocity():Length2D(), maxSpreadMod)
			
			if CT > w.SpreadWait then
				w.AddSpread = mClamp(w.AddSpread - 0.5 * w.AddSpreadSpeed * dt, 0, w:getMaxSpreadIncrease(maxSpreadMod))
				w.AddSpreadSpeed = mClamp(w.AddSpreadSpeed + 5 * dt, 0, 1)
			end

		end
		
		-- samoware.SetContextVector(cmd, memevec)
		
		CalculateSpread()
		
		local cone = w.CurCone
		if !cone then return ang end

		if me:Crouching() then
			cone = cone * 0.85
		end

		math.randomseed(cmd:CommandNumber())
		ang = ang - Angle(mRand(-cone, cone), mRand(-cone, cone), 0) * 25
    elseif class:StartWith("swb_") and class != "swb_knife" and class != "swb_knife_m" then
        local function CalculateSpread()
			local vel = me:GetVelocity():Length()
			local dir = ang:Forward()
			
			if !me.LastView then
				me.LastView = dir
				me.ViewAff = 0
			else
				me.ViewAff = Lerp(0.25, me.ViewAff, (dir - me.LastView):Length() * 0.5)
				--  me.LastView = dir
			end
			
			if IsValid(w.dt) and IsValid(w.meSpread) and w.dt.State == SWB_meING then
				w.BaseCone = w.meSpread
				
				if w.Owner.Expertise then
					w.BaseCone = w.BaseCone * (1 - w.Owner.Expertise["steadyme"].val * 0.0015)
				end
			else
				w.BaseCone = w.HipSpread
				
				if w.Owner.Expertise then
					w.BaseCone = w.BaseCone * (1 - w.Owner.Expertise["wepprof"].val * 0.0015)
				end
			end
			
			if me:Crouching() then
				w.BaseCone = w.BaseCone * (w.dt.State == SWB_meING and 0.9 or 0.75)
			end
			
			w.CurCone = mClamp(w.BaseCone + w.AddSpread + (vel / 10000 * w.VelocitySensitivity) * (w.dt.State == SWB_meING and w.meMobilitySpreadMod or 1) + me.ViewAff, 0, 0.09 + w.MaxSpreadInc)
			
			if CurTime() > w.SpreadWait then
				w.AddSpread = mClamp(w.AddSpread - 0.005 * w.AddSpreadSpeed, 0, w.MaxSpreadInc)
				w.AddSpreadSpeed = mClamp(w.AddSpreadSpeed + 0.05, 0, 1)
			end
		end
		
		CalculateSpread()
		
		local cone = w.CurCone
		if !cone then return ang end

		if me:Crouching() then
			cone = cone * 0.85
		end

		math.randomseed(cmd:CommandNumber())
		ang = ang - Angle(mRand(-cone, cone), mRand(-cone, cone), 0) * 25
	elseif sui.cones[class] then
		local spread = sui.cones[class]
		return sui.Spread(cmd, ang, spread)
	end

	return ang
end

function sui.SelectTarget(cmd)
    local newTarget = nil 
    local newTargetPos = Vector(0,0,0)
    local newTargetAngle = Angle(0,0,0)
    local newTargetFOV = 360
    local newTargetHealth = math.huge
    local newTargetDistance = math.huge

    for k, v in pairs(player.GetAll()) do
		if sui.ValidateTarget(v) then
            local meVector = sui.getmeHitbox(v)
            local meAngle = (meVector - me:EyePos()):Angle()
            meAngle:Normalize()    
            local meFov = mabs(mNormalizeAng(sui.fa.y - meAngle.y)) + mabs(mNormalizeAng(sui.fa.p - meAngle.p))    

            if sui.cfg["Target selection"] == 1 then
                if (me:GetPos()):DistToSqr(v:GetPos()) < newTargetDistance then
                    newTarget = v
                    newTargetPos = meVector
                    newTargetAngle = meAngle
                    newTargetDistance = (me:GetPos()):DistToSqr(v:GetPos())     
                end 
            elseif sui.cfg["Target selection"] == 2 then
                if meFov < newTargetFOV then
                    newTarget = v
                    newTargetPos = meVector
                    newTargetAngle = meAngle
                    newTargetFOV = meFov      
                end
            elseif sui.cfg["Target selection"] == 3 then
                if v:Health() < newTargetHealth then
                    newTarget = v
                    newTargetPos = meVector
                    newTargetAngle = meAngle
                    newTargetHealth = v:Health()      
                end  
            end
        end
    end

    sui.target = newTarget
    sui.targetVector = newTargetPos
    sui.targetAngle = newTargetAngle
    sui.targetFOV = newTargetFOV
    sui.targetHealth = newTargetHealth
    sui.targetDistance = newTargetDistance
end

function sui.TIME_TO_TICKS(time)
	return mfloor(0.5 + time / TICK_INTERVAL)
end

function sui.Aim(cmd)
    if cmd:CommandNumber() == 0 then return end

    if sui.cfg["Enable aimbot"] and sui.CanShoot(cmd) and sui.ValidateTarget(sui.target) and not sui.nextTick and sui.VisibleCheck(sui.target,sui.targetVector) then
        local finalAngle = sui.targetAngle

        if sui.cfg["Norecoil"] then
            finalAngle = sui.NoRecoil(finalAngle)
        end

        if sui.cfg["Nospread"] then
            finalAngle = sui.NoSpread(cmd,finalAngle)
        end

        cmd:SetViewAngles(finalAngle) --pSilent

        if sui.cfg["lagfix"] and ded.GetSimTime(sui.target:EntIndex()) > 0 then
            local simtime = ded.GetSimTime(sui.target:EntIndex())
            local tick = sui.TIME_TO_TICKS(simtime)
            ded.SetCommandTick(cmd, tick)
        end

        if sui.cfg["Auto fire"] then
            if not sui.cfg["pSilent"] then
                sui.bsendpacket = true
            else
                sui.bsendpacket = false
            end
            cmd:AddKey(IN_ATTACK)      
            if not sui.cfg["pSilent"] then sui.nextTick = true end
        end
    else
        sui.AntiAim(cmd)
    end

end

function sui.autoReload(cmd)
    if !sui.cfg["Auto reload"] then return end

	local wep = me:GetActiveWeapon()

	if IsValid(wep) then
		if wep.Primary then
			if wep:Clip1() == 0 and wep:GetMaxClip1() > 0 and me:GetAmmoCount(wep:GetPrimaryAmmoType()) > 0 then
				cmd:AddKey(IN_RELOAD)
			end
		end
	end
end

// adaptive Cstrafe

sui.prev_yaw = 0
sui.last_ground_pos = 0
sui.cstrafe_dir = 0

function sui.PredictVelocity( velocity, viewangles, dir, maxspeed, accel )

	local forward = viewangles:Forward()
	local right = viewangles:Right()
	
	local fmove = 0
	local smove = ( dir == 1 ) && -10000 || 10000
	
	forward.z = 0
	right.z = 0
	
	forward:Normalize()
	right:Normalize()

	local wishdir = Vector( forward.x*fmove + right.x*smove, forward.y*fmove + right.y*smove, 0 )
	local wishspeed = wishdir:Length()
	
	wishdir:Normalize()
	
	if ( wishspeed != 0 && wishspeed > maxspeed ) then
		wishspeed = maxspeed
	end
	
	local wishspd = wishspeed
	
	if ( wishspd > 30 ) then
		wishspd = 30
	end
	
	local currentspeed = velocity:Dot( wishdir )
	local addspeed = wishspd - currentspeed
	
	if ( addspeed <= 0 ) then
		return velocity
	end
	
	local accelspeed = accel * wishspeed * TICK_INTERVAL
	
	if ( accelspeed > addspeed ) then
		accelspeed = addspeed
	end
	
	return velocity + ( wishdir * accelspeed )

end
    
function sui.PredictMovement( viewangles, dir, angle )

	local pm

	local sv_airaccelerate = GetConVarNumber( "sv_airaccelerate" )
	local sv_gravity = GetConVarNumber( "sv_gravity" )
	local maxspeed = me:GetMaxSpeed()
	local jump_power = me:GetJumpPower()

	local origin = me:GetNetworkOrigin()
	local velocity = me:GetAbsVelocity()
	
	local mins = me:OBBMins()
	local maxs = me:OBBMaxs()

    local pticks = mRound(sui.cfg["CStrafe ticks"])
	
	local on_ground = me:IsFlagSet( FL_ONGROUND )
	
	for i = 1, pticks do

		viewangles.y = mNormalizeAng( mdeg( matan2( velocity.y, velocity.x ) ) + angle )

		velocity.z = velocity.z - ( sv_gravity * TICK_INTERVAL * 0.5 )

		if ( on_ground ) then
		
			velocity.z = jump_power
			velocity.z = velocity.z - ( sv_gravity * TICK_INTERVAL * 0.5 )
			
		end

		velocity = sui.PredictVelocity( velocity, viewangles, dir, maxspeed, sv_airaccelerate )
		
		local endpos = origin + ( velocity * TICK_INTERVAL )

		pm = util.TraceHull( {
			start = origin,
			endpos = endpos,
			filter = me,
			maxs = maxs,
			mins = mins,
			mask = MASK_PLAYERSOLID
		} )
		
		if ( ( pm.Fraction != 1 && pm.HitNormal.z <= 0.9 ) || pm.AllSolid || pm.StartSolid ) then
			return false
		end
		
		if ( pm.Fraction != 1 ) then
		
			local time_left = TICK_INTERVAL

			for j = 1, 2 do
			
				time_left = time_left - ( time_left * pm.Fraction )

				local dot = velocity:Dot( pm.HitNormal )
				
				velocity = velocity - ( pm.HitNormal * dot )

				dot = velocity:Dot( pm.HitNormal )

				if ( dot < 0 ) then
					velocity = velocity - ( pm.HitNormal * dot )
				end

				endpos = pm.HitPos + ( velocity * time_left )

				pm = util.TraceHull( {
					start = pm.HitPos,
					endpos = endpos,
					filter = me,
					maxs = maxs,
					mins = mins,
					mask = MASK_PLAYERSOLID
				} )

				if ( pm.Fraction == 1 || pm.AllSolid || pm.StartSolid ) then
					break
				end
			
			end
			
		end
		
		origin = pm.HitPos
		
		if ( ( sui.last_ground_pos - origin.z ) > mRound(sui.cfg["CStrafe ground diff"]) ) then
			return false
		end
		
		pm = util.TraceHull( {
			start =  Vector( origin.x, origin.y, origin.z + 2 ),
			endpos = Vector( origin.x, origin.y, origin.z - 1 ),
			filter = me,
			maxs = Vector( maxs.x, maxs.y, maxs.z * 0.5 ),
			mins = mins,
			mask = MASK_PLAYERSOLID
		} )
		
		on_ground = ( ( pm.Fraction < 1 || pm.AllSolid || pm.StartSolid ) && pm.HitNormal.z >= 0.7 )
		
		velocity.z = velocity.z - ( sv_gravity * engine.TickInterval() * 0.5 )
		
		if ( on_ground ) then
			velocity.z = 0
		end


	end

	return true

end

function sui.CircleStrafe( cmd )

	local angle = 0
	
	while ( sui.cstrafe_dir < 2 ) do
	
		angle = 0
		local path_found = false
		local step = ( sui.cstrafe_dir == 1 ) && mRound(sui.cfg["CStrafe angle step"]) || -mRound(sui.cfg["CStrafe angle step"])
		
		while ( true ) do
		
			if ( sui.cstrafe_dir == 1 ) then
			
				if ( angle > mRound(sui.cfg["CStrafe angle max step"]) ) then
					break
				end
			
			else
			
				if ( angle < -mRound(sui.cfg["CStrafe angle max step"]) ) then
					break
				end
			
			end

			if ( sui.PredictMovement( cmd:GetViewAngles(), sui.cstrafe_dir, angle ) ) then
			
				path_found = true
				break
			
			end

			angle = angle + step
		
		end
		
		if ( path_found ) then
			break
		end
		
		sui.cstrafe_dir = sui.cstrafe_dir + 1
	
	end
	
	if ( sui.cstrafe_dir < 2 ) then
	
		local velocity = me:GetAbsVelocity()
		local viewangles = cmd:GetViewAngles()
		
		viewangles.y = mNormalizeAng( mdeg( matan2( velocity.y, velocity.x ) ) + angle )
		
		cmd:SetViewAngles( viewangles )
		cmd:SetSideMove( ( sui.cstrafe_dir == 1 ) && -10000 || 10000 )
	
	else
	
		sui.cstrafe_dir = 0
	
	end

end

function sui.AutoStrafe( cmd )

	if ( input.IsKeyDown( KEY_G ) and sui.cfg["Circle strafe"] ) then
	
		sui.CircleStrafe( cmd )
	
    elseif sui.cfg["Air strafer"] then

		local ang_diff = mNormalizeAng( sui.fa.y - sui.prev_yaw )
		
		if ( mabs( ang_diff ) > 0 ) then
		
			if ( ang_diff > 0 ) then
				cmd:SetSideMove( -10000 )
			else
				cmd:SetSideMove( 10000 )
			end
		
		else
		
			local vel = me:GetAbsVelocity()
			local vel_yaw = mNormalizeAng( mdeg( matan2( vel.y, vel.x ) ) )
			local vel_yaw_diff = mNormalizeAng( sui.fa.y - vel_yaw )
			
			if ( vel_yaw_diff > 0 ) then
				cmd:SetSideMove( -10000 )
			else
				cmd:SetSideMove( 10000 )
			end

			local viewangles = cmd:GetViewAngles()
			viewangles.y = vel_yaw
			cmd:SetViewAngles( viewangles )
			
		end

		sui.prev_yaw = sui.fa.y
		
	end
	
end

// Anti aim
do
    local pitchFlip = false
    local tankside = 1

    local aapitch = 0

    local realyaw = 0
    local realswitch = 1
    local realswitchtime = 0

    local fakeyaw = 0
    local fakeswitch = 1
    local fakeswitchtime = 0

    local targetang = Angle(0,0,0)

    local switchyaw = {
        [1] = -180,
        [2] = 89,
        [3] = -89,
    }
 

    local function calcPitch()
        local minpj, maxpj = sui.cfg["Pitch min jitter"], sui.cfg["Pitch max jitter"]
        local cp = sui.cfg["Custom pitch"]

        local pitches = {
            [1] = sui.fa.x, -- viewangles
            [2] = 0, -- zero
            [3] = 89, -- down
            [4] = -89, -- up
            [5] = -180, -- fake down
            [6] = 180.00000762939, -- fake fake down
            [7] = mrandom(minpj,maxpj), -- jitter
            [8] = cp, -- custom
            [9] = pitchFlip && 179.9 || 89, -- cadillac pitch
            [10] = pitchFlip && -89 || 89, -- cadillac jitter
            [11] = pitchFlip && -180 || 271, -- cadillac jitter up
            [12] = pitchFlip && 0 || 89, -- dalbaeb pitch
            [13] = pitchFlip && 0 || 179.9, -- dalbaeb pitch extreme
        }

        aapitch = pitches[sui.cfg["Pitch"]]
    end

    local function calcyaw()
        local baseang = targetang.y
        local yaws = {
            [1] = 0, -- forwrard  
            [2] = -180, -- backward
            [3] = 89, -- left
            [4] = -89, -- right
            [5] = mNormalizeAng(CurTime()*sui.cfg["Spin speed"]), -- spin
            [6] = -mNormalizeAng(CurTime()*sui.cfg["Spin speed"]), -- reverse spin
            [7] = mrandom(sui.cfg["Jitter range"],sui.cfg["Jitter range"]), -- jitter
            [8] = - 180 - mrandom(sui.cfg["Jitter range"],sui.cfg["Jitter range"]), -- center jitter
            [9] = sui.cfg["Custom real yaw"], -- custom
            [10] = switchyaw[realswitch], -- switch
            [11] = tankside && 89 || -89, -- tank aa
        }

        if CurTime() > realswitchtime then
            realswitch = mrandom(1,3)
            realswitchtime = CurTime() + sui.cfg["switch real time"]
        end

        realyaw = baseang + yaws[sui.cfg["Yaw"]]
    end

    local function calcfakeyaw()
        local baseang = targetang.y
        local yaws = {
            [1] = 0, -- forwrard  
            [2] = -180, -- backward
            [3] = 89, -- left
            [4] = -89, -- right
            [5] = mNormalizeAng(CurTime()*sui.cfg["fSpin speed"]), -- spin
            [6] = -mNormalizeAng(CurTime()*sui.cfg["fSpin speed"]), -- reverse spin
            [7] = mrandom(sui.cfg["fJitter range"],sui.cfg["fJitter range"]), -- jitter
            [8] = - 180 - mrandom(sui.cfg["fJitter range"],sui.cfg["fJitter range"]), -- center jitter
            [9] = sui.cfg["Custom fake yaw"], -- custom
            [10] = switchyaw[fakeswitch], -- switch
            [11] = tankside && -89 || 89, -- tank aa
        }

        if CurTime() > fakeswitchtime then
            fakeswitch = mrandom(1,3)
            fakeswitchtime = CurTime() + sui.cfg["switch fake time"]
        end

        fakeyaw =  baseang + yaws[sui.cfg["Fake Yaw"]]
    end

    function sui.AntiAim(cmd)
        if not me:Alive() then return end

        if sui.target != nil then
            targetang = (sui.target:GetPos() - me:EyePos()):Angle()
        else
            targetang = sui.fa
        end

        if sui.bsendpacket then
            tankside = !tankside
        end

        if fakeswitch == realswitch then
            fakeswitch = mrandom(1,3)
        end

        if sui.bsendpacket then
            pitchFlip = !pitchFlip
        end

        calcPitch()
        calcyaw()
        calcfakeyaw()

        --if sui.cfg["Anti aim"] == 1 then
        
       -- end


        if ( sui.cfg["Anti aim"] ) and ( !cmd:KeyDown(IN_ATTACK) and !cmd:KeyDown(IN_USE)  ) and ( me:GetMoveType() != MOVETYPE_NOCLIP and me:GetMoveType() != MOVETYPE_LADDER ) then
            local aang = Angle(aapitch,(sui.bsendpacket && fakeyaw || realyaw),0)
            cmd:SetViewAngles(aang)
        else
            cmd:SetViewAngles(sui.fa)
            
        end
    end
end

// Fake lag
do
    sui.fakeLagTicks = 0
    sui.fakeLagfactor = 0
    local function shouldlag(cmd)
        if not sui.cfg["Fake lag"] then return false end
        if not me:Alive() then return false end
        if sui.cfg["Fake lag options-Disable on ladder"] and me:GetMoveType() == MOVETYPE_LADDER then return false end
        if sui.cfg["Fake lag options-Disable in attack"] and cmd:KeyDown(IN_ATTACK) then return false end

        return true
    end

    function sui.FakeLag(cmd)
        local factor = mRound(sui.cfg["Lag limit"])

        if sui.cfg["Fake lag options-Randomise"] then 
            factor =  mrandom(sui.cfg["Lag randomisation"],factor) 
        end

        local velocity = me:GetVelocity():Length2D()
        local pertick = velocity * TICK_INTERVAL
        local adaptive_factor = mClamp(mceil(64 / pertick),1,factor)

        if sui.cfg["Lag mode"] == 1 then
            sui.fakeLagfactor = factor
        elseif sui.cfg["Lag mode"] == 2 then
            sui.fakeLagfactor = adaptive_factor
        end

        if shouldlag(cmd) then
            sui.bsendpacket = false

            if sui.fakeLagTicks <= 0 then
                sui.fakeLagTicks = sui.fakeLagfactor
                sui.bsendpacket = true
            else
                sui.fakeLagTicks = sui.fakeLagTicks - 1
            end

        else
            if sui.fakeLagfactor > 0 then sui.fakeLagfactor = 0 end
            sui.bsendpacket = true
        end
    end
end


// create move hook

function sui.CreateMove(cmd)

    sui.SilentAngles(cmd)

    --cmd:SetViewAngles( sui.fa )

    if ( ded.GetNetChokedPackets() > 14 ) then ded.SetNetChokedPackets( 14 ) end

    if cmd:CommandNumber() == 0 then 
        return 
    end

    if sui.nextTick then 
        cmd:RemoveKey(IN_ATTACK) 
        sui.nextTick = !sui.nextTick 
    end

    if ( me:IsFlagSet( FL_ONGROUND ) ) then
		sui.last_ground_pos = me:GetNetworkOrigin().z
	end

	if ( cmd:KeyDown( IN_JUMP ) ) then

		if ( !me:IsFlagSet( FL_ONGROUND ) ) and sui.cfg["Bhop"] then
			cmd:RemoveKey( IN_JUMP )
		end

		sui.AutoStrafe( cmd )
	end
	
    sui.FakeLag(cmd)

	ded.StartPrediction(cmd)
        local wish_yaw = sui.fa.y

        if ( input.IsKeyDown( KEY_G ) and sui.cfg["Circle strafe"] ) then
            wish_yaw = cmd:GetViewAngles().y
        end

        sui.SelectTarget(cmd)
        sui.Aim(cmd)
        
        sui.MovementFix( cmd, wish_yaw )
    ded.FinishPrediction()

    if sui.cfg["Rapid fire"] then
        if me:KeyDown( IN_ATTACK ) then
            cmd:RemoveKey(IN_ATTACK)
        end
    end

    sui.autoReload(cmd)

    ded.SetBSendPacket(sui.bsendpacket)
end


 
// Misc
function sui.NetSetName()
    local n = sui.cfg["Name Convar"]

    ded.NetSetConVar("name",n)
end

function sui.NetDisconnect()
    local r = sui.cfg["Disconnect reason"]

    ded.NetDisconnect(r)
end

do
    local printed = false
    function sui.AutoRestart()
        if not sui.cfg["Auto reconnect"] then return end
    
        if ded.IsTimingOut() then
            if not printed then
                MsgC( Color(185,0,0), "[NetChan]", color_white, " Autoreconnect (Timing out)! \n" )
                printed = true 
            end

            RunConsoleCommand("retry")
        end
    end
end

do
    local cmdcd = CurTime()

    function sui.CommandSpammer()
        if not sui.cfg["cmd spam"] or ded.IsTimingOut() then return end
    
        local force = sui.cfg["cmd force"]
        local cooldown = sui.cfg["cmd delay"]
        local command = sui.cfg["cmd command"]

        if CurTime() > cmdcd then
            
            for i = 1,force do
                RunConsoleCommand(command)
            end

            cmdcd = CurTime() + cooldown
        end
    end
end

function sui.Think()

    --[[if sui.cfg["interp"] and GetConVar("cl_interpolate"):GetInt() == 0 then
        ded.SpoofedConVarSetNumber("cl_interpolate",1)
    elseif GetConVar("cl_interpolate"):GetInt() == 1 then 
        ded.SpoofedConVarSetNumber("cl_interpolate",0)
    end

    if sui.cfg["extrapolate"] and GetConVar("cl_extrapolate"):GetInt() == 0 then
        print("extra")
        ded.SpoofedConVarSetNumber("cl_extrapolate",1)
    elseif GetConVar("cl_extrapolate"):GetInt() == 1 then
        print("no extra")
        ded.SpoofedConVarSetNumber("cl_extrapolate",0)
    end]]

    sui.AutoRestart()
    sui.CommandSpammer()
end


// players

do
    local FRAME_START = 0
    local FRAME_NET_UPDATE_START = 1
    local FRAME_NET_UPDATE_POSTDATAUPDATE_START = 2
    local FRAME_NET_UPDATE_POSTDATAUPDATE_END = 3
    local FRAME_NET_UPDATE_END = 4
    local FRAME_RENDER_START = 5
    local FRAME_RENDER_END = 6

    function sui.PostFrameStageNotify(stage)
        if stage == FRAME_RENDER_START then
           for k, v in pairs(player.GetAll()) do
                if v == me or v:IsDormant() then continue end
                
                if sui.cfg["Resolver-Fake AA"] then
                    sui.visualResolver(v)
                end
            end
        end
    end
end

// game events
gameevent.Listen( "player_hurt" )
function sui.entityKilledEvent( data )
    local health = data.health
	local priority = SERVER and data.Priority or 5
	local hurted = Player( data.userid )
	local attackerid = data.attacker

	if attackerid == me:UserID() then

        if sui.cfg["Resolver-Fake AA"] and sui.target != nil then 
            if hurted == sui.target then

                if sui.hurteddeg[sui.target] <= 0 then
                    if sui.resolvedBoys[hurted] == nil then
                        sui.resolvedBoys[hurted] = 0
                    else
                        sui.resolvedBoys[hurted] = sui.resolvedBoys[hurted] - 30
                    end
                end

                if sui.hurteddeg[hurted] != nil then
                    sui.hurteddeg[hurted] = sui.hurteddeg[hurted] + 2
                else
                    sui.hurteddeg[hurted] = 0
                end

                chat.AddText("hurted "..hurted:Name().." at "..sui.resolvedBoys[hurted]) 
            end
        end

    end
end

// calc view 

sui.vieworigin = me:EyePos()
function sui.SilentViewAngles( ply, origin, angles, fov, znear, zfar )
    local view = {
		origin = origin,
		angles = sui.fa,
		fov = fov,
		znear = znear,
		zfar = zfar,
	}

    sui.vieworigin = origin

	return view
end

function sui.CalcViewModelView(wep, vm, oldPos, oldAng, pos, ang)
    pos = sui.vieworigin 
	ang = sui.fa

	return pos, ang
end

// hudpaint 

function sui.overlay()
   for k,v in pairs(player.GetAll()) do
        if v == me or not v:Alive() then continue end
        local pos = v:GetShootPos():ToScreen()


        sSetFont("BudgetLabel")
        sSetTColor(255,255,255)
        sSetTPos(pos.x,pos.y-15)
        sDrawText(v:Name())

        cam.Start3D()
            v:DrawModel()
        cam.End3D()
   end
end


// hooks
hook.Add("CreateMove","sui.CreateMove",sui.CreateMove)
hook.Add("Think","sui.menuThink",sui.menuThink)
hook.Add("CalcView","sui.SilentViewAngles",sui.SilentViewAngles)
hook.Add("CalcViewModelView","sui.CalcViewModelView",sui.CalcViewModelView)
hook.Add("Think","sui.Think",sui.Think)
hook.Add("PostFrameStageNotify","sui.PostFrameStageNotify",sui.PostFrameStageNotify)
hook.Add("player_hurt", "sui.entityKilled", sui.entityKilledEvent) 
hook.Add("HUDPaint","sui.paintOverlay",sui.overlay)

function GAMEMODE:CreateMove( cmd ) return true end
function GAMEMODE:CalcView( view ) return true end

