print("biggadabooddadadadeeieeooo")
CreateClientConVar("hoobendooben", 0, true, false) -- player xray
CreateClientConVar("hoobendoob2",  0, true, false) -- prop xray :DD
CreateClientConVar("realsosa", 0, true, false) -- espee
CreateClientConVar("realsosahp", 0, true, false) -- esp hp

local me = LocalPlayer()
local poochams = GAMEMODE.PreDrawEffects
local balls = GAMEMODE.HUDPaint

RunConsoleCommand("cl_updaterate", 1000) -- runs interp commands so props feel less fucking retarded, thanks trial.
RunConsoleCommand("cl_cmdrate", 0) 
RunConsoleCommand("cl_interp", 0)
RunConsoleCommand("physgun_timetoarrive", 0)
RunConsoleCommand("cl_interp_ratio", 0)


local function lavacolor(n, t)
	if n == 1 then
		return math.Round((255 - (math.floor(math.sin(RealTime() * 3.5 ) * 40 + 50 ) ) ) / t, 2), math.Round((math.floor(math.sin(RealTime() * 3.5 + 2 ) * 55 + 65 ) ) / t, 2), 0
	elseif n == 2 then
		return 255 / t , 0.6- math.Round((math.floor(math.sin(RealTime() * 3.5 + 2 ) * 55 + 65 ) ) / t, 2), 0
	end
end -- testan


render.CapturePixels = function() return nil end
render.Capture = function() return nil end -- stop the admens spying on me :D 





local ChamsMaterial3 = CreateMaterial("shin-e", "VertexLitGeneric", {
		["$basetexture"] = "models/debug/debugwhite",
		["$envmap"] = "effects/cubemapper",
		["$envmapcontrast"] = 10,
		["$normalmapalphaenvmapmask"] = 1,
		["$rimlight"] = 1,
		["$rimlightboost"] = 15,
		["$rimlightexponent"] = 50,
		["$rimmask"] = 0,
		["$phong"] = 1,
		["$phongboost"] = 100,
		["$phongexponent"] = 200,
		["$bumpmap"] = "gm_construct/water_13",
		["$phongfresnelranges"] = "[0 0.5 1]",
		["$basemapalphaphongmask"] = 1,
		["$basemapluminancephongmask"] = 1,
		["$nofog"] = 1,
		["$model"] = 1,
		["$nocull"] = 0,
		["$selfillum"] = 1,
		["$halflambert"] = 1,
		["$znearer"] = 0,
		["$flat"] = 1
})  







-- yes very giood job ur done im horny as fuck man im a freak man im a freak
function GAMEMODE.PreDrawEffects()
  poochams()
	if GetConVarNumber("hoobendooben") == 1 then
		for k,v in pairs(player.GetAll()) do
			if (v:Alive()) then
				v:SetColor(0,0,0,0)
				cam.IgnoreZ(true)
				if v == me then continue end
				render.SuppressEngineLighting(true)
				render.SetBlend(1)
				render.SetColorModulation(lavacolor(2,255))
				render.MaterialOverride(ChamsMaterial3)
				v:DrawModel()
			end -- end playor check :DD
			render.SuppressEngineLighting(false)
			cam.IgnoreZ(false)
			render.MaterialOverride(nil)
			render.SetColorModulation(0,0,0)
		end
	end

   	for k,v in pairs(ents.FindByClass("prop_physics")) do
   		if IsValid(v) then
   			cam.Start3D()
   			   if GetConVarNumber("hoobendoob2") == 1 then
   			   	v:SetColor(Color(0,0,0,0))
   			   	cam.IgnoreZ(true)
   			   	render.SuppressEngineLighting(true)
   			   	render.SetBlend(0.5)
   			   	render.SetColorModulation(lavacolor(2,255))
   			   	render.MaterialOverride(ChamsMaterial3)
   			   v:DrawModel()

   			   	render.SuppressEngineLighting(false) 
			    cam.IgnoreZ(false)
				render.MaterialOverride(nil)
				render.SetColorModulation(0,0,0) 
			end
		end
	end
end 

    surface.CreateFont("esp_font", {    	-- esp font thank u profforsz
    	font = "Trebuchet24",
     	size = 18,
     	antialias = true
     })
    surface.CreateFont("esphp_font", {    	-- esp font thank u profforsz 
    	font = "Trebuchet18",
     	size = 18,
     	antialias = true
     })


function GAMEMODE.HUDPaint(gm)
	balls(gm)
	if GetConVarNumber("realsosa") == 1 then
		for k,v in pairs(player.GetAll()) do
			 if (v:Alive()) then
			 	local pos2d = (v:GetPos() + Vector(0, 0, 105)):ToScreen()
			 	surface.SetFont("esp_font")
			    local w, h = surface.GetTextSize(v:Nick())
			    if v == me then continue end
			 	surface.SetTextColor(Color(0,255,0)) 
      			surface.SetTextPos(pos2d.x - w / 2 , pos2d.y - h / 1) 
      			surface.DrawText(v:Nick())	 
      		end
      	end
    end

    if GetConVarNumber("realsosahp") == 1 then 
    	for k,v in pairs(player.GetAll()) do
    		if (v:Alive()) then
    			local pos2d = (v:GetPos() + Vector(0, 0, 95)):ToScreen()
    			surface.SetFont("esphp_font")
    			local w, h = surface.GetTextSize(v:Health())
    			if v == me then continue end
    			surface.SetTextColor(Color(255,0,0))
    			surface.SetTextPos(pos2d.x - w / 2 , pos2d.y - h / 2)
    			surface.DrawText(v:Health())
    		end
    	end
    end
end