// note by paradox: I'm not naming it what he said it was named so I named it after the author.


--[[
*********************************
Name: ScriptUsedForSomethingReallySuperLegit
Date: 24/04/2014 @ 19:31
Author: TroubleMakers

Author's Note:
	Just a basic optimised ESP for C+Ping skids.
	If you want serious hacks, PM me your Skype/Steam ID.
*********************************
]]

local _GLOB 			= _G.table.Copy(_G)
local _REG 				= _GLOB.table.Copy(debug.getregistry())
local LocalPly 			= _GLOB.LocalPlayer()

local Teammate_Color 	= _GLOB.Color( 41, 128, 185 )
local Enemy_Color 		= _GLOB.Color( 231, 76, 60 )
local Other_Color 		= _GLOB.Color( 205, 228, 140 )
local Black_Color 		= _GLOB.Color( 0, 0, 0 )
local Friend_Color		= _GLOB.Color( 255, 255, 0 )
local White_Color		= _GLOB.Color( 240, 240, 240 )

_GLOB.surface.CreateFont( "FontUsedForSomethingReallySuperLegit", { font = "Default", size = 12, antialias = false, outline = true, } )

local function GetColor( self_team, v )

	if _REG.Entity.IsValid(v) then 

		if _REG.Player.Team( v ) == self_team then
			return Teammate_Color
		else
			return Enemy_Color
		end

	end

	return Other_Color
end

local function GetWeapon( ent )

	local cur_wep = _REG.Player.GetActiveWeapon(ent)

	if cur_wep != nil then
		if _REG.Weapon.IsWeapon(cur_wep) then
			if cur_wep and _REG.Entity.IsValid(cur_wep) then
				return cur_wep
			end
		end
	end

	return false
end

local function DrawText( text, font, x, y, color )
	_GLOB.surface.SetFont( font )
	_GLOB.surface.SetTextColor( color )
	_GLOB.surface.SetTextPos( x, y ) 
	_GLOB.surface.DrawText( text )
end

_GLOB.hook.Add("HUDPaint",_GLOB.tostring(_GLOB.math.random()),function()

	local self_team = LocalPly:Team()

	local players = player.GetAll()
	
	for int = 1, #players do local ent = players[int]
	
		if ent != LocalPly then
			
			-- Localise Stuff
				local ESP_Height = 0
				local ent_obbcenter = _REG.Vector.ToScreen( _REG.Entity.LocalToWorld( ent, _REG.Entity.OBBCenter( ent ) ) )
				local ent_health = _REG.Entity.Health( ent )
				local ent_name = _REG.Player.Nick( ent )
				local ent_weapon = GetWeapon( ent )
				local ent_col = GetColor( self_team, ent )
				local ent_hcol = _GLOB.Color(255 - 2.55 * ent_health, 2.55 * ent_health, 0, 255)
				local ent_steam_friendstatus = _REG.Player.GetFriendStatus( ent )
					
				if _REG.Player.Alive( ent ) then
				
					for h_int = 0, _REG.Entity.GetHitBoxCount( ent, 0 ) do
					
						local hitbox = _REG.Entity.GetHitBoxBone( ent, h_int, 0 );
						local hitbox_pos = _REG.Entity.GetBonePosition( ent, hitbox );
						
						if hitbox_pos then
						
							local screen_hitbox_pos = _REG.Vector.ToScreen( hitbox_pos );
							_GLOB.surface.SetDrawColor( White_Color )
							_GLOB.surface.DrawRect( screen_hitbox_pos.x-1, screen_hitbox_pos.y-1, 2, 2)

						end

					end
				
					if ent_steam_friendstatus == "friend" then
					
						_GLOB.surface.SetFont("FontUsedForSomethingReallySuperLegit")
					
						local lenght = _GLOB.surface.GetTextSize(ent_name)
					
						DrawText(" - Friend", "FontUsedForSomethingReallySuperLegit", ent_obbcenter.x+lenght, ent_obbcenter.y, Friend_Color)
					
					end
				
					DrawText(ent_name, "FontUsedForSomethingReallySuperLegit", ent_obbcenter.x, ent_obbcenter.y, ent_col)
					ESP_Height = ESP_Height + 12.5

					if ent_weapon then
					
						DrawText(ent_weapon:GetPrintName(), "FontUsedForSomethingReallySuperLegit", ent_obbcenter.x, ent_obbcenter.y + ESP_Height, ent_col)
						ESP_Height = ESP_Height + 12.5
						
					end
					
					DrawText(ent_health.." HP", "FontUsedForSomethingReallySuperLegit", ent_obbcenter.x, ent_obbcenter.y + ESP_Height, ent_hcol)
					ESP_Height = ESP_Height + 12.5
					
				end

			end
	end
	
end)

_GLOB.chat.AddText(_GLOB.Color(255,150,0),"[ScriptUsedForSomethingReallySuperLegit] ",Color(240,240,240),"Cheat Loaded. If you need help/notice any error, feel free to PM me. \n - If you want complete exploits/cheats/hacks, just PM me your Skype/Steam ID. ")