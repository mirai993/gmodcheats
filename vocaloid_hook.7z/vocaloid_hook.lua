--[[
	EXECUTABLE_PATH/test
	Da masta, Da Leada | STEAM_0:0:77475961 <82.238.182.218:27005> | [19-11-13 08:41:04PM]
	===BadFile===
]]

notification.AddProgress("enjoy", "vocaloid²Hook - Made by TheMikuChibi :)")
timer.Simple(2, function()
		notification.Kill("enjoy")
	end
)

CreateClientConVar( "MikuHUDInfoN", 0, true, false )
CreateClientConVar( "MikuHUDInfoB", 0, true, false )
CreateClientConVar( "MikuHUDLove", 0, true, false )
CreateClientConVar( "MikuHUDLoveGH", 0, true, false )
CreateClientConVar( "MikuHUDVocaloid", 0, true, false )
CreateClientConVar( "MikuHUDFov", 0, true, false )

function AddCheckBox( text, cvar, parent, x, y, tt )
local checkbox = vgui.Create( "DCheckBoxLabel", parent )
checkbox:SetPos( x, y )
checkbox:SetText( text )
checkbox:SetConVar( cvar )
checkbox:SetTextColor(white)
checkbox:SetTooltip( tt or "No Tool Tip" )
checkbox:SizeToContents()	
end

function AddText( text, parent, x, y )
local label = vgui.Create("DLabel")
label:SetParent(parent)
label:SetPos(x,y)
label:SetText(text)
label:SetTextColor(Color(255,255,255,255))
label:SizeToContents()
end

-- gui.InternalMouseWheeled( number delta ) Simulates something :)
-- Creating Font for Later use... --Original one is "ChatFont"
surface.CreateFont("HUDFont",{font = "ScoreboardText", size = 17, weight = 400, antialias = 0})
surface.CreateFont("HUDFont_Small",{font = "Default", size = 12, weight = 200, antialias = 0})
surface.CreateFont("HUDActual",{font = "akbar", size = 21, weight = 400, antialias = 0})
surface.CreateFont("HUDScoreboardText",{font = "ScoreboardText", size = 15, weight = 700, antialias = 0})
surface.CreateFont("HUDcoolvetica",{font = "coolvetica", size = 16, weight = 500, antialias = 0})
surface.CreateFont("HUDScoreboardTextt",{font = "ScoreboardTextt", size = 15, weight = 1000, antialias = 1})
surface.CreateFont("HUDcoolvetica2",{font = "coolvetica", size = 20, weight = 500, antialias = 1})
surface.CreateFont("HUDWater",{font = "akbar", size = 35, weight = 500, antialias = 0})

function MikuHUDFov( ply, pos, angles, fov )
	if GetConVarNumber("MikuHUDFov") == 1 then
		if LocalPlayer():GetActiveWeapon().Primary then
			LocalPlayer():GetActiveWeapon().Primary.Recoil = 0
		end
		return GAMEMODE:CalcView( ply, LocalPlayer():EyePos(), LocalPlayer():EyeAngles(), fov, 1 );
	else
		if LocalPlayer():GetActiveWeapon().Primary then
			LocalPlayer():GetActiveWeapon().Primary.Recoil = 0.1
		end
	end
end

local shouldFire = 0
function MikuHUDLove()
if GetConVarNumber("MikuHUDLove") == 1 then
	local ply = LocalPlayer()
	local trace = util.GetPlayerTrace( ply )
	local traceRes = util.TraceLine( trace )
	if traceRes.HitNonWorld then
		local target = traceRes.Entity
		if target:IsPlayer() or target:IsNPC() then
			local targethead = target:LookupBone("ValveBiped.Bip01_Head1")
			if (targethead) then else return; end
			local targetheadpos,targetheadang = target:GetBonePosition(targethead)
			ply:SetEyeAngles((targetheadpos - ply:GetShootPos()):Angle())
			if GetConVarNumber("MikuHUDLoveGH") == 1 then
			halo.Add( {target}, Color( 255, 0, 0 ), 10, 10, 10,true, true)
			end
		end
	end
end
end

function CreateHUDCookie(v)
local ply = LocalPlayer()
local ang = Angle( 0, LocalPlayer():EyeAngles().y, 0 )
local nom = v:GetPos()
local center = v:LocalToWorld( v:OBBCenter() )
local min, max = v:OBBMins(), v:OBBMaxs()
local dim = max - min	local z = max + min	
local frt	= ( v:GetForward() ) * ( dim.y / 2 )
local rgt	= ( v:GetRight() ) * ( dim.x / 2 )
local top	= ( v:GetUp() ) * ( dim.z / 2 )
local bak	= ( v:GetForward() * -1 ) * ( dim.y / 2 )
local lft	= ( v:GetRight() * -1 ) * ( dim.x / 2 )
local btm	= ( v:GetUp() * -1 ) * ( dim.z / 2 )
local s = 1
local FRT 	= center + frt / s + rgt / s + top / s; FRT = FRT:ToScreen()
local BLB 	= center + bak / s + lft / s + btm / s; BLB = BLB:ToScreen()
local FLT	= center + frt / s + lft / s + top / s; FLT = FLT:ToScreen()
local BRT 	= center + bak / s + rgt / s + top / s; BRT = BRT:ToScreen()
local BLT 	= center + bak / s + lft / s + top / s; BLT = BLT:ToScreen()
local FRB 	= center + frt / s + rgt / s + btm / s; FRB = FRB:ToScreen()
local FLB 	= center + frt / s + lft / s + btm / s; FLB = FLB:ToScreen()
local BRB 	= center + bak / s + rgt / s + btm / s; BRB = BRB:ToScreen()	
local z = 100
if ( v:Health() <= 50 ) then z = 100 end
local x, y = ( ( v:Health() / 100 ) ), 1
if ( v:Health() <= 0 ) then x = 1 end
local FRT3 	= center + frt + rgt + top / x; FRT3 = FRT3; FRT3 = FRT3:ToScreen()
local BLB3 	= center + bak + lft + btm / x; BLB3 = BLB3; BLB3 = BLB3:ToScreen()
local FLT3	= center + frt + lft + top / x; FLT3 = FLT3; FLT3 = FLT3:ToScreen()
local BRT3 	= center + bak + rgt + top / x; BRT3 = BRT3; BRT3 = BRT3:ToScreen()
local BLT3 	= center + bak + lft + top / x; BLT3 = BLT3; BLT3 = BLT3:ToScreen()
local FRB3 	= center + frt + rgt + btm / x; FRB3 = FRB3; FRB3 = FRB3:ToScreen()
local FLB3 	= center + frt + lft + btm / x; FLB3 = FLB3; FLB3 = FLB3:ToScreen()
local BRB3 	= center + bak + rgt + btm / x; BRB3 = BRB3; BRB3 = BRB3:ToScreen()	
local x, y, z = 1.1, 0.9, 1
local FRT2 	= center + frt / y + rgt / z + top / x; FRT2 = FRT2:ToScreen()
local BLB2 	= center + bak / y + lft / z + btm / x; BLB2 = BLB2:ToScreen()
local FLT2	= center + frt / y + lft / z + top / x; FLT2 = FLT2:ToScreen()
local BRT2 	= center + bak / y + rgt / z + top / x; BRT2 = BRT2:ToScreen()
local BLT2 	= center + bak / y + lft / z + top / x; BLT2 = BLT2:ToScreen()
local FRB2 	= center + frt / y + rgt / z + btm / x; FRB2 = FRB2:ToScreen()
local FLB2 	= center + frt / y + lft / z + btm / x; FLB2 = FLB2:ToScreen()
local BRB2 	= center + bak / y + rgt / z + btm / x; BRB2 = BRB2:ToScreen()	
local maxX = math.max( FRT.x,BLB.x,FLT.x,BRT.x,BLT.x,FRB.x,FLB.x,BRB.x )
local minX = math.min( FRT.x,BLB.x,FLT.x,BRT.x,BLT.x,FRB.x,FLB.x,BRB.x )
local maxY = math.max( FRT.y,BLB.y,FLT.y,BRT.y,BLT.y,FRB.y,FLB.y,BRB.y )
local minY = math.min( FRT.y,BLB.y,FLT.y,BRT.y,BLT.y,FRB.y,FLB.y,BRB.y )
local minYhp2 = math.min( FRT.y,BLB.y,FLT.y,BRT.y,BLT.y,FRB.y,FLB.y,BRB.y )
local maxXhp = math.max( FRT3.x,BLB3.x,FLT3.x,BRT3.x,BLT3.x,FRB3.x,FLB3.x,BRB3.x )
local minXhp = math.min( FRT3.x,BLB3.x,FLT3.x,BRT3.x,BLT3.x,FRB3.x,FLB3.x,BRB3.x )
local maxYhp = math.max( FRT3.y,BLB3.y,FLT3.y,BRT3.y,BLT3.y,FRB3.y,FLB3.y,BRB3.y )
local minYhp = math.min( FRT3.y,BLB3.y,FLT3.y,BRT3.y,BLT3.y,FRB3.y,FLB3.y,BRB3.y )	
local maxX2 = math.max( FRT2.x,BLB2.x,FLT2.x,BRT2.x,BLT2.x,FRB2.x,FLB2.x,BRB2.x )
local minX2 = math.min( FRT2.x,BLB2.x,FLT2.x,BRT2.x,BLT2.x,FRB2.x,FLB2.x,BRB2.x )
local maxY2 = math.max( FRT2.y,BLB2.y,FLT2.y,BRT2.y,BLT2.y,FRB2.y,FLB2.y,BRB2.y )
local minY2 = math.min( FRT2.y,BLB2.y,FLT2.y,BRT2.y,BLT2.y,FRB2.y,FLB2.y,BRB2.y )
local mon = nom + Vector( 0, 0, LocalPlayer():OBBMaxs()[3] )			
local BOXPOS1 = Vector( 16, 16, 0 )
BOXPOS1:Rotate( ang )
BOXPOS1 = ( nom + BOXPOS1 ):ToScreen()
local BOXPOS2 = Vector( 16, -16, 0 )
BOXPOS2:Rotate( ang )
BOXPOS2 = ( nom + BOXPOS2 ):ToScreen()
local BOXPOS3 = Vector( -16, -16, 0 )
BOXPOS3:Rotate( ang )
BOXPOS3 = ( nom + BOXPOS3 ):ToScreen()
local BOXPOS4 = Vector( -16, 16, 0 )
BOXPOS4:Rotate( ang )
BOXPOS4 = ( nom + BOXPOS4 ):ToScreen()
local BOXPOS5 = Vector( 16, 16, 0 )
BOXPOS5:Rotate( ang )
BOXPOS5 = ( mon + BOXPOS5 ):ToScreen()
local BOXPOS6 = Vector( 16, -16, 0 )
BOXPOS6:Rotate( ang )
BOXPOS6 = ( mon + BOXPOS6 ):ToScreen()
local BOXPOS7 = Vector( -16, -16, 0 )
BOXPOS7:Rotate( ang )
BOXPOS7 = ( mon + BOXPOS7 ):ToScreen()
local BOXPOS8 = Vector( -16, 16, 0 )
BOXPOS8:Rotate( ang )
BOXPOS8 = ( mon + BOXPOS8 ):ToScreen()
return maxX, minX, maxY, minY, maxX2, minX2, maxY2, minY2, minYhp, maxYhp, BOXPOS1, BOXPOS2, BOXPOS3, BOXPOS4, BOXPOS5, BOXPOS6, BOXPOS7, BOXPOS8
end

function MikuHUDInfo()
for k,v in pairs ( player.GetAll() ) do
draw.DrawText( "vocaloid²Hook by TheMikuChibi", "HUDActual", ScrW()/2, ScrW()/2, Color( 255, 0, 0, 255 ), 1 )
	local maxX, minX, maxY, minY, maxX2, minX2, maxY2, minY2, minYhp, maxYhp = CreateHUDCookie(v)
			local targpos = (v:GetPos()):ToScreen()
			local targname = ""
			targname = v:Name()
		if v:Alive()  then
			if GetConVarNumber("MikuHUDInfoN") == 1 then
				draw.DrawText( targname, "HUDActual", targpos.x, targpos.y, Color(0,162,232,255), 1 )
			end
			if GetConVarNumber("MikuHUDInfoB") == 1 and v != LocalPlayer() then
				surface.SetDrawColor(Color(0,162,232,255))	
				surface.DrawLine( maxX, maxY, maxX, minY )
				surface.DrawLine( maxX, minY, minX, minY )					
				surface.DrawLine( minX, minY, minX, maxY )
				surface.DrawLine( minX, maxY, maxX, maxY )
			end
		end
	end
for k,v in pairs ( ents.FindByClass("npc*") ) do
	local maxX, minX, maxY, minY, maxX2, minX2, maxY2, minY2, minYhp, maxYhp = CreateHUDCookie(v)
			local targpos = (v:GetPos()):ToScreen()
			local targname = ""
			targname = v:GetClass()
			if GetConVarNumber("MikuHUDInfoN") == 1 then
				draw.DrawText( targname, "HUDActual", targpos.x, targpos.y, Color( 255, 255, 0, 255 ), 1 )
			end
			if GetConVarNumber("MikuHUDInfoB") == 1 and v != LocalPlayer() then
				surface.SetDrawColor(Color( 255, 255, 0, 255 ))	
				surface.DrawLine( maxX, maxY, maxX, minY )
				surface.DrawLine( maxX, minY, minX, minY )					
				surface.DrawLine( minX, minY, minX, maxY )
				surface.DrawLine( minX, maxY, maxX, maxY )
			end
	end
end

function MikuHUDVocaloid()
if GetConVarNumber("MikuHUDVocaloid") == 1 then
	for k,v in pairs ( player.GetAll() ) do
		if v:Alive() then
		halo.Add( {v}, Color( 255, 255, 0 ), 5, 5, 5 ,true, true)
		end
	end
end
end

function HUDMenu() -- Starting the function.
local HUDMenu = vgui.Create( "DFrame" ) -- Creating the Vgui.
HUDMenu:SetPos( ScrW(), 5 ) -- Setting the position of the menu.
HUDMenu:SetSize( 260, 210 ) -- Setting the size of the menu.
HUDMenu:SetTitle( "vocaloid²Hook Menu" ) -- The menu title.
HUDMenu:ShowCloseButton( true )
HUDMenu:SetVisible(true)
HUDMenu:SetDraggable(false)
HUDMenu:MakePopup()
function HUDMenu:Paint()
	draw.RoundedBox( 8, 0, 0, self:GetWide(), self:GetTall(), Color( 0,0,0,200 ) ) -- This paints, and round's the corners etc.
end -- Now we ONLY end the painting function.
  
if !HUDMenu.Open then
	HUDMenu:MoveTo(5, 5, 0.7, 0,1)
end
 
AddText("ExtraSensory Position", HUDMenu, 10, 25 )
AddCheckBox("Names","MikuHUDInfoN",HUDMenu,10,40,"Show players and NPCs names on the ESP")
AddCheckBox("Boxes","MikuHUDInfoB",HUDMenu,10,60,"Show players and NPCs boxes on the ESP")
AddCheckBox("Glow Halo","MikuHUDVocaloid",HUDMenu,10,80,"Will draw a Glow Halo around players")
AddText("Assisting", HUDMenu, 10, 95 )
AddCheckBox("Aiming Assistant","MikuHUDLove",HUDMenu,10,110,"Will lock your view when you pass on a player")
AddCheckBox("Glow Halo Target","MikuHUDLoveGH",HUDMenu,125,110,"Will draw a Glow Halo around")
AddText("Removals", HUDMenu, 10, 125 )
AddCheckBox("No Recoil","MikuHUDFov",HUDMenu,10,140,"When enabled, the recoil will be removed")
  
-- Here we are, the close button. The last button for this, because this is used instead of ShowCloseButton( false )
local close_button = vgui.Create( "DButton", HUDMenu )
close_button:SetPos( 5, 185 )
close_button:SetSize( 250, 20 )
close_button:SetText( "Close this menu" )
 
close_button.Paint = function()
    draw.RoundedBox( 8, 0, 0, close_button:GetWide(), close_button:GetTall(), Color( 0,0,0,225 ) )
    surface.DrawRect( 0, 0, close_button:GetWide(), close_button:GetTall() )
end
 
close_button.DoClick = function()
    HUDMenu:Close()
end
 
end
concommand.Add("HUDMenu", HUDMenu) -- Adding the Console Command. So whenever you enter your gamemode, simply type HUDMenu in console.
 
-- Now, we're gonna start the functions
hook.Add("HUDPaint","MikuHUDInfo",MikuHUDInfo) --ExtraSensory Position
hook.Add("Think","MikuHUDLove",MikuHUDLove) --Aim Assist
hook.Add("CalcView","MikuHUDFov",MikuHUDFov) --NoRecoil
hook.Add("PreDrawHalos","AddHalos",MikuHUDVocaloid) --Glow Halo

/*
Less Almost Spread:
cl_predict 0 (laggs)

Best SpeedHack:
host_timescale 3.0 (1.0 = default)

2nd SpeedHack:
host_framerate 20

sound esp:
snd_show 1
snd_visualize 1

wireframe model hack:
r_drawothermodels 2 (Default= 1)

Asus Wallhack1 and no flash:
Mat_fillrate 1

Asus Wallhack2:
mat_proxy 2 (Default=0)

Player Box ESP/Wallhack: (a bit laggy)
r_partition_level 0 (default= -1)

Brushmodel Wallhack:
r_drawbrushmodels 0

Entity Box Wallhack:
mem_force_flush 1

Player/ Weapon ESP:
r_drawmodelstatsoverlay 1

Enamy Checker:
cl_leveloverview 2

Shadow ESP:
r_shadowwireframe 1

Impact ESP/Impact Predictor/ Tracer ESP: xxx
r_visualizetraces 1
r_rainspeed 0

tracer esp:
r_visualizelighttraces 1

Fire / Smoke ESP:
cl_particles_show_bbox 1

Chrome Models:
r_showenvcubemap 1

No Smoke:
r_drawparticles 0

No Flash:
snd_digital_surround 1

Events:
Fire beacon: r_drawlights 1
Player Boxes: r_drawrenderboxes 1
Living/Dead Player Indicator: vcollide_wireframe 1

no fog:
fog_enable 0

fullbright:
mat_fullbright 1

White Walls:
mat_fullbright 2

vBlue Walls:
mat_normalmaps 1

Luxels (Squares On Walls):
mat_luxels 1

Unlock max down and up sight:
cl_pitchup 900
cl_pitchdown 900

No Bob:
cl_bobcycle 0

hitlocation ESP:
r_modelwireframedecal 1

Wire Frame Wallhack Menu:
perfui

thirdperson:
thirdperson
firstperson

Low Resolution Images, Celled Walls:
mat_showlowresimage 1

texture location:
mat_surfaceid (voor memory addres), mat_surfacemat (voor texture naam)

Memory Adress Finder:
vgui_drawtree 1
*/