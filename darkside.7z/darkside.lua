			-- darkside  	   
			local vgui, surface, Color, input, hook, KEY_INSERT, pairs, string, timer, file, util = vgui, surface, Color, input, hook, KEY_INSERT, pairs, string, timer, file, util;  	   
			local KEY_UP, KEY_DOWN, KEY_RIGHT, KEY_LEFT = KEY_UP, KEY_DOWN, KEY_RIGHT, KEY_LEFT;  	   
			local player = player;  	   
			local Vector = Vector;  	   
			local Angle = Angle;  	   
			local bit = bit;  	   
			local FindMetaTable = FindMetaTable;  	   
			local team = team;  	   
			local me = LocalPlayer();  	   
			local draw = draw;  	   
			local SortedPairs = SortedPairs;  	   
			local aimtarget;  	   
			local pcall = pcall;  	   
			local require = require;  	   
			local debug = debug;  	   
			local table = table;  	   
			local gameevent = gameevent;  	   
			local Entity = Entity;  	   
			local ScrW, ScrH = ScrW, ScrH;  	   
			local RunConsoleCommand = RunConsoleCommand;  	   
			local GAMEMODE = GAMEMODE;  	   
			local CurTime = CurTime;  	   
			local cam = cam;  	   
			local CreateMaterial = CreateMaterial;  	   
				   
			local em = FindMetaTable"Entity";  	   
			local pm = FindMetaTable"Player";  	   
			local cm = FindMetaTable"CUserCmd";  	   
			local wm = FindMetaTable"Weapon";  	   
			local am = FindMetaTable"Angle";  	   
			local vm = FindMetaTable"Vector";  	   
			local ply = LocalPlayer()	   
			local aiming;  	   
				   
			local chatspam = {  	   
					"Suckmycock",  	   
					"Fix brain and fix aim",  	   
					"1 stupid dog",  	   
					"1111111111111",  	   
					"lol :D missed shot due to loser",  	   
					"Good work darkside",  	   
					"how are y? Stupid dooog ",  	   
					"love you :)))))))",  	 	   
			}  	   


local function coordinates( ent )
local min, max = ent:OBBMins(), ent:OBBMaxs()
local corners = {
        Vector( min.x, min.y, min.z ),
        Vector( min.x, min.y, max.z ),
        Vector( min.x, max.y, min.z ),
        Vector( min.x, max.y, max.z ),
        Vector( max.x, min.y, min.z ),
        Vector( max.x, min.y, max.z ),
        Vector( max.x, max.y, min.z ),
        Vector( max.x, max.y, max.z )
}
 
local minX, minY, maxX, maxY = ScrW() * 2, ScrH() * 2, 0, 0
for _, corner in pairs( corners ) do
        local onScreen = ent:LocalToWorld( corner ):ToScreen()
        minX, minY = math.min( minX, onScreen.x ), math.min( minY, onScreen.y )
        maxX, maxY = math.max( maxX, onScreen.x ), math.max( maxY, onScreen.y )
end
function drawfillbox( mag,value,left,top,right,bottom,r,g,b,a )
    local poly = {
    {x=left,y=top},
    {x=right,y=top},
    {x=right,y=bottom},
    {x=left,y=bottom}
	}
	surface.SetDrawColor( r,g,b,a )
	draw.NoTexture()
	surface.DrawPoly(poly)
	draw.SimpleTextOutlined(value,"default",left + (right - left) / 2,top,Color(r,g,b,a),mag,1,1,Color(0,0,0))
end
return minX, minY, maxX, maxY
end




				   
			local chatspam2 = {  	   
				"hax",  	   
			}  	   
				   
			local chatspam3 = {  	   
				"swag",  	   
			}  	   
				   
					   surface.CreateFont("wmfont2", {
					font = "Roboto",
					size = 17,
					
				});

					   surface.CreateFont("wmfont3", {
					font = "Console",
					size = 13,
					weight = 900,
					shadow = true,
					antialias = false,
				});	   
				   
		local function GetPos(v)

			if(gBool("Ragebot", "Bodyaim")) then return( em.LocalToWorld(v, em.OBBCenter(v)) ); end

			local eyes = em.LookupAttachment(v, "eyes");
			
			if(!eyes) then return( em.LocalToWorld(v, em.OBBCenter(v)) ); end
			
			local pos = em.GetAttachment(v, eyes);
			
			if(!pos) then return( em.LocalToWorld(v, em.OBBCenter(v)) ); end
			
			return(pos.Pos);
		end
				   
				   
				   
				   
			local omsg;  	   
				   
			local menvars = {  	   
				["Cheat Name"] = "cloudhack.ru",  	   
			}  	   
				   
			if (file.Exists("rmenu/"..menvars["Cheat Name"].."/mvars.txt", "DATA")) then  	   
				menvars = util.JSONToTable(file.Read("rmenu/"..menvars["Cheat Name"].."/mvars.txt"), "DATA");  	   
			else  	   
				file.CreateDir("rmenu");  	   
				file.CreateDir("rmenu/"..menvars["Cheat Name"]);  	   
				file.Write("rmenu/"..menvars["Cheat Name"].."/mvars.txt", util.TableToJSON(menvars, true));  	   
			end  	   
				   
			local vars = {  	   
				["ESP"] = { 
					{"Name", 0, 1}, 	
					{"Box", 0, 2, "0 = Off | 1 = Default | 2 = Corner"},  	   
					{"Healthbar", 1, 1},  	     	   
					{"Skeleton", 0, 1}, 
					{"Chams", 0, 1},
					{"Halo", 0, 1},
					{"Weapon", 0, 1},		
					{"Health", 0, 1},  	   
					{"Distance", 0, 1},		  	   
					{"Rank", 0, 1},  	   
				},  	   
				["Miscellaneous"] = {  	   
					{"Thirdperson", 0, 1},  	   
					{"Max dist",1, 13},  	   
					{"Chatspam", 0, 1},  	   
					{"Quakesounds", 0, 1},  	   
					{"Bunnyhop", 0, 1},
					{"FullBright", 0, 1},
					{"Nigga Mode", 0, 1},
					{"Flashlight spam", 0, 1},
					{"Hide HUD", 0, 1},
					{"Kill Say", 0, 1},
					{"Watermark", 0, 1},
				},  	   
				["Aimbot"] = {  	   
					{"Enabled", 0, 1},  	   
					{"Bullettime", 0, 1},  	   
					{"Aim on Mouse", 0, 1},  	   
					{"Target Method", 1, 3, "0 = Normal | 1 = Nextshot | 2 = Distance | 3 = Health"},  	   
					{"Autoshoot", 1, 1},  	   
					{"NoSpread", 1, 1},
					{"NoRecoil", 0, 1},				
					{"Target Team", 1, 1},  	   
					{"Target Friends", 0, 1},  	   
					{"BAim", 0, 1},  	   
				},  	   
				["Triggerbot"] = {  	   
					{"Enabled", 0, 1},  	   
					{"Target Friends", 0, 1},  	   
					{"Target Team", 1, 1},  	   
				},   		
				["Other"] = {  	   
					{"Autism", 0, 1},  	   
					{"Crosshair", 1, 1},  	     	   
					{"No Hands", 0, 1},  	   
					{"No Sky", 0, 1},
					{"Radar", 0, 1},  	   
					{"HN Radar", 0, 1},
					{"Thirdperson", 0, 1},
					{"RCS Control", 0, 1},
					{"ESP Dist", 0, 1},
					{"Custom Fov", 0, 1},
					{"", ""}, 
					{"Max Dist", 900, 3000},
					{"Fov", 100, 125},
					{"Thirdperson D", 100, 125},				
				}, 
				["WallHack"] = {  	        		 	   
					{"Name", 1, 1},  	     	   
					{"Box", 0, 1},  	   
					{"Group", 0, 1},
					{"Team", 0, 1},  	   
					{"Armor", 0, 1},
					{"Health", 0, 1},
					{"Weapon", 0, 1},
				    {"Skeleton", 0, 1},
				},		
				["Anti-hit"] = {  	   
					{"Spinbot", 0, 1},  	   
					{"Speed", 1, 23},  	   
					{"", ""},  	   
					{"Antiaim", 0, 1},  	   
					{"Method", 1, 2, "0 = Normal | 1 = Jitter | 2 = Sideways Follow"},  	   
					{"Min X", -181},  	   
					{"Min Y", 0},  	   
					{"Max X", -270},  	   
					{"Max Y", 360},  	   
						   
				},  	   
				["Menu"] = {  	   
					{"Autism", 0, 1},  	   
					{"Pos X", 5},  	   
					{"Pos Y", 105},  	   
					{"", ""},  	   
					{"Background R", 0, 255},  	   
					{"Background G", 0, 255},  	   
					{"Background B", 0, 255},  	   
					{"Background A", 245, 255},  	   
					{"", ""},  	   
					{"Bar R", 255, 255},  	   
					{"Bar G", 255, 255},  	   
					{"Bar B", 255, 255},  	   
					{"", ""},  	   
					{"Text R", 255, 255},  	   
					{"Text G", 255, 255},  	   
					{"Text B", 255, 255},  	   
					{"", ""},  	   
					{"Outline R", 0, 255},  	   
					{"Outline G", 0, 255},  	   
					{"Outline B", 0, 255},  	   
				},				
			};  	   
				   
				   
			local function gBool(a, b)  	   
				if (!vars[a]) then return false; end  	   
				local bool;  	   
				for k,v in next, vars[a] do  	   
					if v[1] == b then bool = (v[2] > 0 && true); end  	   
				end  	   
				return(bool);  	   
			end  	   
				   
				   
				   
				   
			local function gInt(a, b)  	   
				if (!vars[a]) then return 0; end  	   
				local val;  	   
				for k, v in next, vars[a] do  	   
					if v[1] == b then val = v[2]; end  	   
				end  	   
				return(val || 0);  	   
			end  	   
				   
			local menuopen, selmade;  	   
			local cursel = 1;  	   
				   
			local showtabs = {};  	   
				   
			local function UpdateVar(h, var)  	   
				if (!vars[h]) then return; end  	   
				for k,v in pairs(vars[h]) do  	   
					if v[1] == var[1] then  	   
						vars[h][k] = var;  	   
					end  	   
				end  	   
			end  	   
				   
			local function loadconfig()  	   
				if (file.Exists("rmenu/"..menvars["Cheat Name"].."/vars.txt", "DATA")) then  	   
					local ttt = util.JSONToTable(file.Read("rmenu/"..menvars["Cheat Name"].."/vars.txt", "DATA"));  	   
					for k,v in pairs(ttt) do  	   
						for _,i in pairs(v) do  	   
							UpdateVar(k, i);  	   
						end  	   
					end  	   
				end  	   
			end  	   
				   
			local drawtext;  	   
			local mh;  	   
				   
			local function Menu()  	   
				local larrowdown, rarrowdown, darrowdown, uarrowdown;  	   
				local main = vgui.Create("DFrame");  	   
				main:SetSize(170, 5);  	   
				main:SetTitle("");  	   
				main:ShowCloseButton(false);  	   
				main:SetDraggable(false);  	   
				main:SetPos(gInt("Menu", "Pos X"), gInt("Main", "Pos Y"));  	   
					   
				local allitems = 0;  	   
				local sel = 0;  	   
					   
				function main:Paint(w, h)  	   
					menvars["BGColor"] = Color(gInt("Menu", "Background R"), gInt("Menu", "Background G"), gInt("Menu", "Background B"), gInt("Menu", "Background A"))  	   
					menvars["TXTColor"] = Color(gInt("Menu", "Text R"), gInt("Menu", "Text G"), gInt("Menu", "Text B"), 255)  	   
					menvars["OutlineColor"] = Color(gInt("Menu", "Outline R"), gInt("Menu", "Outline G"), gInt("Menu", "Outline B"), 255)  	   
					menvars["BarColor"] = Color(gInt("Menu", "Bar R"), gInt("Menu", "Bar G"), gInt("Menu", "Bar B"), 255 || Color(70,90,200))  	   
					local backcolor = menvars["BGColor"];  	   
					local txtcolor = menvars["TXTColor"];  	   
					local outcolor = menvars["OutlineColor"];  	   
					local barcol = menvars["BarColor"];  	   
					if (gBool("Menu", "Autism")) then  	   
						backcolor = Color(math.random(255), math.random(255), math.random(255), backcolor.a);  	   
						barcol = Color(math.random(0), math.random(0), math.random(255));  	   
						outcolor = barcol;  	   
						local aa = math.random(3);  	   
						txtcolor = Color(aa == 1 && math.random(255) - barcol.r || math.random(255), aa == 2 && math.random(255) - barcol.g || math.random(255), aa == 3 && math.random(255) - barcol.b || math.random(255));  	   
					end  	   
					allitems = 0;  	   
					surface.SetTextColor(txtcolor);  	   
					local hh = 25;  	   
					surface.SetFont("wmfont3");  	   
					surface.SetDrawColor(backcolor);  	   
					surface.DrawRect(0, 0, w, h);  	   
				   
						   
					surface.SetDrawColor(barcol);  	   
					surface.DrawRect(0, 0, w, 20);  	   
						   
					local ww, hh2 = surface.GetTextSize(menvars["Cheat Name"]);  	   
						   
					surface.SetTextPos(w / 2 - (ww / 2), 2);  	   
					surface.DrawText(menvars["Cheat Name"]);  	   
						   
					for k,v in SortedPairs(vars) do  	   
						allitems = allitems + 1;  	   
						local citem = allitems;  	   
						if (cursel == citem) then  	   
							if (sel != 0) then  	   
								showtabs[k] = !showtabs[k];  	   
								sel = 0;  	   
							end  	   
							surface.SetDrawColor(barcol);  	   
							surface.DrawRect(0, hh, w, 15);  	   
						end  	   
						surface.SetTextPos(5, hh);  	   
						surface.DrawText((showtabs[k] and "[-] " or "[+] ")..k);  	   
						hh = hh + 15;  	   
						if (!showtabs[k]) then continue; end  	   
						for _, var in next, vars[k] do  	   
							allitems = allitems + 1;  	   
							local curitem = allitems;	  	   
							if (cursel == curitem) then  	   
								if (sel != 0) then  	   
									if (k == "Menu" && string.find(vars[k][_][1], "Pos")) then sel = sel * 5; end  	   
									if (vars[k][_][1] != "" && !(vars[k][_][3] && (vars[k][_][2] + sel >  vars[k][_][3]))) then  	   
										vars[k][_][2] = (vars[k][_][2] + sel >= 0 && vars[k][_][2] + sel || (vars[k][_][1] == "Max X" || vars[k][_][1] == "Max Y" || vars[k][_][1] == "Min Y" || vars[k][_][1] == "Min X") && vars[k][_][2] + sel || vars[k][_][2]);  	   
										timer.Simple(.05, function()  	   
											if ((larrowdown || rarrowdown)  && cursel == curitem && k == "Menu" || (larrowdown || rarrowdown) && cursel == curitem && (vars[k][_][1] == "Max X" || vars[k][_][1] == "Max Y" || vars[k][_][1] == "Min Y" || vars[k][_][1] == "Min X")) then  	   
												larrowdown = false;  	   
												rarrowdown = false;  	   
											end  	   
										end);  	   
									end  	   
									sel = 0;  	   
								end  	   
								drawtext = (vars[k][_][4] && vars[k][_][4] || "");  	   
								mh = hh;  	   
								surface.SetDrawColor(barcol);  	   
								surface.DrawRect(0, hh, w, 16);  	   
							end  	   
							surface.SetTextPos(15, hh);  	   
							local n = vars[k][_][1];  	   
							if (n != "") then  	   
								surface.DrawText(vars[k][_][1]..":");  	   
							end  	   
							surface.SetTextPos(130, hh);  	   
							if (n != "" && k != "Menu" && vars[k][_][1] != "Max X" && vars[k][_][1] != "Max Y" && vars[k][_][1] != "Min Y" && vars[k][_][1] != "Min X") then  	   
								surface.DrawText("[ "..vars[k][_][2].." ]");  	   
							else  	   
								surface.DrawText(vars[k][_][2]);  	   
							end  	   
							hh = hh + 15;  	   
						end  	   
					end  	   
						   
					allitems = allitems + 1;  	   
					local curitem = allitems;  	   
						   
					if (cursel == curitem) then  	   
						if (sel != 0) then  	   
							showtabs["Config"] = !showtabs["Config"];  	   
							sel = 0;  	   
						end  	   
						surface.SetDrawColor(barcol);  	   
						surface.DrawRect(0, hh, w, 15);  	   
					end  	   
						   
					surface.SetTextPos(5, hh);  	   
					surface.DrawText((showtabs["Config"] and "[-] " or "[+] ").."Config");  	   
					   
					hh = hh + 15;  	   
						   
					if (showtabs["Config"]) then  	   
						allitems = allitems + 1;  	   
						local citem = allitems;  	   
						local tr = "[ 0 ]";  	   
						if (cursel == citem) then  	   
							if (sel != 0) then  	   
								sel = 0;  	   
								tr = "[ 1 ]";  	   
								file.Write("rmenu/"..menvars["Cheat Name"].."/vars.txt", util.TableToJSON(vars, true));  	   
								file.Write("rmenu/"..menvars["Cheat Name"].."/mvars.txt", util.TableToJSON(menvars, true));  	   
							end  	   
							surface.SetDrawColor(barcol);  	   
							surface.DrawRect(0, hh, w, 15);  	   
						end  	   
						surface.SetTextPos(15, hh);  	   
						surface.DrawText("Save:");  	   
						surface.SetTextPos(130, hh);  	   
						surface.DrawText(tr);  	   
						hh = hh+15;  	   
							   
							   
						allitems = allitems + 1;  	   
						local citem2 = allitems;  	   
						local tr2 = "[ 0 ]";  	   
						if (cursel == citem2) then  	   
							if (sel != 0) then  	   
								sel = 0;  	   
								tr2 = "[ 1 ]";  	   
								loadconfig();  	   
							end  	   
							surface.SetDrawColor(barcol);  	   
							surface.DrawRect(0, hh, w, 15);  	   
						end  	   
						surface.SetTextPos(15, hh);  	   
						surface.DrawText("Load:");  	   
						surface.SetTextPos(130, hh);  	   
						surface.DrawText(tr2);  	   
						hh = hh+15;  	   
					end  	   
						   
						   
						   
					main:SetSize(170, hh + 5);  	   
						   
					main:SetPos(gInt("Menu", "Pos X"), gInt("Menu", "Pos Y"));  	   
				   
					surface.SetDrawColor(outcolor);  	   
					surface.DrawOutlinedRect(0, 0, 170, hh + 5);  	   
				end  	   
					   
				function main:Think()  	   
					if (input.IsKeyDown(KEY_UP) && !uarrowdown) then  	   
						if (cursel - 1 > 0) then  	   
							cursel = cursel - 1;  	   
						else  	   
							cursel = allitems;  	   
						end  	   
						uarrowdown = true;  	   
					elseif (!input.IsKeyDown(KEY_UP)) then  	   
						uarrowdown = false;  	   
					end  	   
						   
					if (input.IsKeyDown(KEY_DOWN) && !darrowdown) then  	   
						if (cursel < allitems) then  	   
							cursel = cursel + 1;  	   
						else  	   
							cursel = 1;  	   
						end  	   
						darrowdown = true;  	   
					elseif (!input.IsKeyDown(KEY_DOWN)) then  	   
						darrowdown = false;  	   
					end  	   
						   
					if (input.IsKeyDown(KEY_LEFT) && !larrowdown) then  	   
						sel = -1;  	   
						larrowdown = true;  	   
					elseif (!input.IsKeyDown(KEY_LEFT)) then  	   
						larrowdown = false;  	   
					end  	   
						   
					if (input.IsKeyDown(KEY_RIGHT) && !rarrowdown) then  	   
						sel = 1;  	   
						rarrowdown = true;  	   
					elseif (!input.IsKeyDown(KEY_RIGHT)) then  	   
						rarrowdown = false;  	   
					end  	   
					if (input.IsKeyDown(KEY_INSERT) && !insertdown2) then  	   
						main:Close();  	   
						drawtext = "";  	   
						menuopen = false;  	   
					end  	   
				end 
	if input.IsKeyDown(KEY_F)and (!gBool("Miscellaneous", "Chatspam")) then SetImpulse(100)end			
			end  	   
				   
			local insertdown = false;  	   
				   
			function GAMEMODE:Think()  	   
				if (input.IsKeyDown(KEY_INSERT) && !menuopen && !insertdown) then  	   
					menuopen = true;  	   
					insertdown = true;  	   
					Menu();  	   
				elseif (!input.IsKeyDown(KEY_INSERT) && !menuopen) then  	   
					insertdown = false;  	   
				end  	   
				if (input.IsKeyDown(KEY_INSERT) && insertdown && menuopen) then  	   
					insertdown2 = true;  	   
				else  	   
					insertdown2 = false;  	   
				end  	   
				if (gInt("Miscellaneous", "Chatspam") == 1) then  	   
					local msg;  	   
					repeat  	   
						msg = chatspam[math.random(#chatspam)];  	   
					until msg != omsg;  	   
					omsg = msg;  	   
					RunConsoleCommand("say", msg);  	   
				end  	   
				if (gInt("Miscellaneous", "Chatspam") == 2) then  	   
					local msg;  	   
					repeat  	   
						msg = chatspam2[math.random(#chatspam2)];  	   
					until msg != omsg;  	   
					omsg = msg;  	   
					RunConsoleCommand("say", msg);  	   
				end  	   
				if (gInt("Miscellaneous", "Chatspam") == 3) then  	   
					local msg;  	   
					repeat  	   
						msg = chatspam3[math.random(#chatspam3)];  	   
					until msg != omsg;  	   
					omsg = msg;  	   
					RunConsoleCommand("say", msg);  	   
				end  	   
			end  	   
				   
			loadconfig();  	   
				   
			local em = FindMetaTable("Entity");  	   
			local cm = FindMetaTable("CUserCmd");  	   
			local pm = FindMetaTable("Player");  	   
			local vm = FindMetaTable("Vector");  	   
			local am = FindMetaTable("Angle");  	   
			local wm = FindMetaTable("Weapon");  	   
				   
				   
				   
				   
				   
			local function ESP(ent)  	   
				local pos = em.GetPos(ent);  	   
				local pos2 = pos + Vector(0, 0, 70);  	   
				local pos = vm.ToScreen(pos);  	   
				local pos2 = vm.ToScreen(pos2);  	   
				local h = pos.y - pos2.y;  	   
				local w = h / 2;  	   
				local col = (gBool("Other", "Autism") && Color(math.random(255), math.random(255), math.random(255)) || Color(0,0,0));		
                if (gInt("ESP", "Box") == 1) then 				
					surface.SetDrawColor(col);  	   
					surface.DrawOutlinedRect(pos.x - w / 2, pos.y - h, w, h);  	   
					surface.DrawOutlinedRect(pos.x - w / 2 + 2, pos.y - h + 2, w - 4, h - 4);  	   
					local ocol = (gBool("Other", "Autism") && Color(math.random(255), math.random(255), math.random(255)) || team.GetColor(pm.Team(ent)));  	   
					surface.SetDrawColor(ocol);  	   
					surface.DrawOutlinedRect(pos.x - w / 2 - 1, pos.y - h - 1, w + 2, h + 2);  	   
					surface.DrawOutlinedRect(pos.x - w / 2 + 1, pos.y - h + 1, w - 2, h - 2);  	   
				end  	   
				if (gBool("ESP", "Healthbar")) then  	   
					local bgcol = (gBool("Other", "Autism") && Color(math.random(255), math.random(255), math.random(255)) || Color(0, 0, 0));  	   
					surface.SetDrawColor(bgcol);  	   
					surface.DrawRect(pos.x - (w/2) - 7, pos.y - h - 1, 5, h + 2);  	   
					local hp = em.Health(ent);  	   
					local col1 = gBool("Other", "Autism") && Color(math.random(255), math.random(255), math.random(255)) || Color(0,255,0);  	   
					surface.SetDrawColor((100 - hp) * 2.55, hp * 2.55, 0);  	   
					local hp = hp * h / 100;  	   
					local diff = h - hp;  	   
					surface.DrawRect(pos.x - (w / 2) - 6, pos.y - h + diff, 3, hp);  	   
				end  	   
					   
				local hh = 0;  	   
					   
				local txtstyle = gBool("ESP", "Text Style");  	   
					   
				if (gBool("ESP", "Name")) then  	   
					local col1 = gBool("Other", "Autism") && Color(math.random(255), math.random(255), math.random(255)) || Color(255,255,255);  	   
					local col2 = gBool("Other", "Autism") && Color(math.random(255), math.random(255), math.random(255)) || Color(73,92,200);  	   
					local friendstatus = pm.GetFriendStatus(ent);  	   
					if (!txtstyle) then  	   
						draw.SimpleText(pm.Name(ent), "wmfont3", pos.x, pos.y - h - (friendstatus == "friend" && 7 || 7), col1, 1, 1);  	   
						if (friendstatus == "friend") then  	   
							draw.SimpleText("Friend", "wmfont3", pos.x, pos.y - h - 17, col2, 1, 1);  	   
						end  	   
					else  	   
						draw.SimpleText(pm.Name(ent), "wmfont3", pos.x + (w/2) + 5, pos.y - h + 3 + hh, col1, 0, 1);  	   
						hh = hh + 10;  	   
						if (friendstatus == "friend") then  	   
							draw.SimpleText("Friend", "wmfont3", pos.x + (w/2) + 5, pos.y - h + 3 + hh, col2, 0, 1);  	   
							hh = hh + 10;  	   
						end  	   
					end  	   
				end  	   
				if (gBool("ESP", "Health")) then  	   
					hh = hh + 10;  	   
					local col1 = gBool("Other", "Autism") && Color(math.random(255), math.random(255), math.random(255)) || Color((100 - em.Health(ent)) * 2.55, em.Health(ent) * 2.55, 0);  	   
						draw.SimpleText(""..em.Health(ent), "wmfont3", pos.x, pos.y - 2, col1, 1, 0);  	   
				end  	   
				if (gBool("ESP", "Distance")) then  	   
					local col = gBool("Other", "Autism") && Color(math.random(255), math.random(255), math.random(255)) || Color(255,255,255);  	   
						draw.SimpleText(""..math.ceil(vm.Distance(em.GetPos(ent), em.GetPos(me))), "wmfont3", pos.x, pos.y - 2 + hh, col, 1, 0);  	   
					hh = hh + 10;  	   
				end  	   
				if (gBool("ESP", "Rank")) then  	   
					local col = gBool("Other", "Autism") && Color(math.random(255), math.random(255), math.random(255)) || Color(255,255,255);  	   
						draw.SimpleText(""..pm.GetUserGroup(ent), "wmfont3", pos.x, pos.y - 2 + hh, col, 1, 0);  	   
				end  	   
			end  	   
				   
			local function GB(ent, bone)  	   
				local bone = em.LookupBone(ent, bone);  	   
				return(bone && vm.ToScreen(em.GetBonePosition(ent, bone)) || nil);  	   
			end  	   
				   
			local function DrawCrosshair()  	   
				if (!gBool("Other", "Crosshair")) then return; end  	   
				surface.SetDrawColor((gBool("Other", "Autism") && Color(math.random(255), math.random(255), math.random(255))) || Color(0,255,0));  	   
				local w, h = ScrW(), ScrH();  	   
				surface.DrawLine(w / 2 - 15, h / 2, w / 2 - 5, h / 2);  	   
				surface.DrawLine(w / 2 + 15, h / 2, w / 2 + 5, h / 2);  	   
				surface.DrawLine(w / 2, h / 2 - 15, w / 2, h / 2 - 5);  	   
				surface.DrawLine(w / 2, h / 2 + 15, w / 2, h / 2 + 5);  	   
			end  	   
	  
			local function Skeleton(ent)  	   
				if (!gBool("ESP", "Skeleton")) then return; end  	   
				   
				local b = {  	   
					head = GB(ent, "ValveBiped.Bip01_Head1"),  	   
					neck = GB(ent, "ValveBiped.Bip01_Neck1"),  	   
					spine4 = GB(ent, "ValveBiped.Bip01_Spine4"),  	   
					spine2 = GB(ent, "ValveBiped.Bip01_Spine2"),  	   
					spine1 = GB(ent, "ValveBiped.Bip01_Spine1"),  	   
					spine = GB(ent, "ValveBiped.Bip01_Spine"),  	   
					rarm = GB(ent, "ValveBiped.Bip01_R_UpperArm"),  	   
					rfarm = GB(ent, "ValveBiped.Bip01_R_Forearm"),  	   
					rhand = GB(ent, "ValveBiped.Bip01_R_Hand"),  	   
					larm = GB(ent, "ValveBiped.Bip01_L_UpperArm"),  	   
					lfarm = GB(ent, "ValveBiped.Bip01_L_Forearm"),  	   
					lhand = GB(ent, "ValveBiped.Bip01_L_Hand"),  	   
					rthigh = GB(ent, "ValveBiped.Bip01_R_Thigh"),  	   
					rcalf = GB(ent, "ValveBiped.Bip01_R_Calf"),  	   
					rfoot = GB(ent, "ValveBiped.Bip01_R_Foot"),  	   
					rtoe = GB(ent, "ValveBiped.Bip01_R_Toe0"),  	   
					lthigh = GB(ent, "ValveBiped.Bip01_L_Thigh"),  	   
					lcalf = GB(ent, "ValveBiped.Bip01_L_Calf"),  	   
					lfoot = GB(ent, "ValveBiped.Bip01_L_Foot"),  	   
					ltoe = GB(ent, "ValveBiped.Bip01_L_Toe0"),  	   
				}  	   
					   
				if (!b.head||!b.neck||!b.spine4||!b.spine2||!b.spine1||!b.spine||!b.rarm||!b.rfarm||!b.rarm||!b.rhand||!b.larm||!b.lfarm||!b.lhand||!b.rthigh||!b.rcalf||!b.rfoot||!b.rtoe||!b.lthigh||!b.lcalf||!b.lfoot||!b.ltoe) then return; end  	   
					   
				local col = gBool("Other", "Autism") && Color(math.random(255), math.random(255), math.random(255)) || Color(255,255,255);  	   
					   
				surface.SetDrawColor(col);  	   
				surface.DrawLine(b.head.x, b.head.y, b.neck.x, b.neck.y);  	   
				surface.DrawLine(b.neck.x, b.neck.y, b.spine4.x, b.spine4.y);  	   
				surface.DrawLine(b.spine4.x, b.spine4.y, b.spine2.x, b.spine2.y);  	   
				surface.DrawLine(b.spine2.x, b.spine2.y, b.spine1.x, b.spine1.y);  	   
				surface.DrawLine(b.spine1.x, b.spine1.y, b.spine.x, b.spine.y);  	   
					   
				surface.DrawLine(b.spine4.x, b.spine4.y, b.rarm.x, b.rarm.y);  	   
				surface.DrawLine(b.rarm.x, b.rarm.y, b.rfarm.x, b.rfarm.y);  	   
				surface.DrawLine(b.rfarm.x, b.rfarm.y, b.rhand.x, b.rhand.y);  	   
					   
				surface.DrawLine(b.spine4.x, b.spine4.y, b.larm.x, b.larm.y);  	   
				surface.DrawLine(b.larm.x, b.larm.y, b.lfarm.x, b.lfarm.y);  	   
				surface.DrawLine(b.lfarm.x, b.lfarm.y, b.lhand.x, b.lhand.y);  	   
					   
				surface.DrawLine(b.spine.x, b.spine.y, b.rthigh.x, b.rthigh.y);  	   
				surface.DrawLine(b.rthigh.x, b.rthigh.y, b.rcalf.x, b.rcalf.y);  	   
				surface.DrawLine(b.rcalf.x, b.rcalf.y, b.rfoot.x, b.rfoot.y);  	   
				surface.DrawLine(b.rfoot.x, b.rfoot.y, b.rtoe.x, b.rtoe.y);  	   
					   
				surface.DrawLine(b.spine.x, b.spine.y, b.lthigh.x, b.lthigh.y);  	   
				surface.DrawLine(b.lthigh.x, b.lthigh.y, b.lcalf.x, b.lcalf.y);  	   
				surface.DrawLine(b.lcalf.x, b.lcalf.y, b.lfoot.x, b.lfoot.y);  	   
				surface.DrawLine(b.lfoot.x, b.lfoot.y, b.ltoe.x, b.ltoe.y);  	   
			end  	   
				   
			function GAMEMODE:DrawOverlay()  	   
				local allplys = player.GetAll();  	   
				for i = 1, #allplys do  	   
					local v = allplys[i];  	   
					if (!v || !em.IsValid(v) || v == me || em.Health(v) < 1) then continue; end  	   
					ESP(v);  	   
					Skeleton(v);				
				end 			
				DrawCrosshair();  	   
				   
				if (!mh || !drawtext || drawtext == "") then return; end  	   
				surface.SetTextColor(menvars["TXTColor"]);  	   
				surface.SetFont("wmfont3");  	   
				local w, h = surface.GetTextSize(drawtext);  	   
				surface.SetTextPos( gInt("Menu", "Pos X") + 180, mh + (h / 2.5));  	   
				surface.DrawText(drawtext);  	   
			end  	   
				   
			local fa = em.EyeAngles(me);  	   
				   
			local function Bunnyhop(ucmd)  	   
				if (!gBool("Miscellaneous", "Bunnyhop")) then return; end  	   
				if (!em.IsOnGround(me) && cm.KeyDown(ucmd, 2)) then  	   
					cm.SetButtons(ucmd, bit.band(cm.GetButtons(ucmd), bit.bnot(2)));  	   
				end 		
			end  	   
						
				
			local function FixMovement(ucmd, aa)  	   
				local ang = Vector(cm.GetForwardMove(ucmd), cm.GetSideMove(ucmd), 0)  	   
				local ang = am.Forward((vm.Angle(vm.GetNormal(ang)) + (cm.GetViewAngles(ucmd) - Angle(0, fa.y, 0)))) * vm.Length(ang)  	   
				cm.SetForwardMove(ucmd, ang.x);  	   
				cm.SetSideMove(ucmd, ( aa && ang.y * -1 || ang.y));  	   
			end  	   
				   
			local e, err = pcall(function() require("dickwrap") end);  	   
				   
			if (err) then  	   
				dickwrap = {};  	   
				dickwrap.Predict = function(ucmd, ang)  	   
					return ang;  	   
				end  	   
			end  	   
				   
			local cones = {};  	   
				   
			local ofb = em.FireBullets;  	   
				   
			local aimignore;  	   
				   
			local nullcone = Vector() * -1;  	   
				   
			function em.FireBullets(p, data)  	   
				if (p != me) then return ofb(p, data); end  	   
				if (gInt("Aimbot", "Target Method") == 1) then  	   
					aimignore = aimtarget;  	   
					aimtarget = nil;  	   
				end  	   
				local Spread = data.Spread * -1;  	   
				local w = pm.GetActiveWeapon(me);  	   
				if (!w || !em.IsValid(w)) then return ofb(p, data); end  	   
				local class = em.GetClass(w);  	   
				if (cones[class] == Spread) then return ofb(p, data); end  	   
				if (Spread == nullcone) then return ofb(p, data); end  	   
				cones[class] = Spread;  	   
				return ofb(p, data);  	   
			end  	   
				   
			local function PredictSpread(ucmd, ang)  	   
				local w = pm.GetActiveWeapon(me);  	   
				if (!w || !em.IsValid(w)) then return ang; end  	   
				local class = em.GetClass(w);  	   
				if (!cones[class]) then return ang; end  	   
				return vm.Angle(dickwrap.Predict(ucmd, am.Forward(ang), cones[class]));  	   
			end  	   
				   
			local function GetPos(v)  	    	   
				local eyes = em.LookupAttachment(v, "eyes");  	   
				local pos = eyes && em.GetAttachment(v, eyes);  	   
				return(pos && pos.Pos || em.LocalToWorld(v, em.OBBCenter(v)));  	   
			end  	   
				   
			local function Valid(ent)  	   
				if (!ent || !em.IsValid(ent) || ent == me || ent == aimignore || em.Health(ent) < 1 || em.IsDormant(ent) || pm.Team(ent) == 1002 || (!gBool("Aimbot", "Target Team") && (pm.Team(ent) == pm.Team(me))) || (!gBool("Aimbot", "Target Friends") && pm.GetFriendStatus(ent) == "friend") ) then return false; end  	   
				local tr = {  	   
					mask = 1174421507,  	   
					endpos = GetPos(ent),  	   
					start = em.EyePos(me),  	   
					filter = {me, ent},  	   
				};  	   
				return (util.TraceLine(tr).Fraction == 1);  	   
			end  	   
				   
			local function GetTarget()  	   
				local aimmethod = gInt("Aimbot", "Target Method");  	   
				if (Valid(aimtarget) && aimmethod != 3 && aimmethod != 2) then return; end  	   
				aimtarget = nil;  	   
				local allplys = player.GetAll();  	   
				if (aimmethod == 1) then  	   
					local plys = {}  	   
					local vals = {}  	   
					for i = 1, #allplys do  	   
						table.insert(vals, i);  	   
					end  	   
					for i = 1, #allplys do  	   
						local rand = table.Random(vals);  	   
						local v = allplys[i];  	   
						table.insert(plys, rand, v);  	   
						table.remove(vals, rand);  	   
					end  	   
					local num = 1;  	   
					repeat  	   
						local v = plys[num];  	   
						if Valid(v) then  	   
							aimtarget = v;  	   
						end  	   
						num = num + 1;  	   
					until(aimtarget || num > #plys)  	   
				elseif(aimmethod == 0) then  	   
					local num = 1;  	   
					repeat  	   
						local v = allplys[num];  	   
						if (Valid(v)) then aimtarget = v; end  	   
						num = num + 1;  	   
					until(aimtarget || num > #allplys);  	   
				elseif (aimmethod == 2) then  	   
					local dists = {};  	   
					local num = 1;  	   
					repeat  	   
						local v = allplys[num];  	   
						if (Valid(v)) then  	   
							local d = vm.Distance(em.GetPos(v), em.GetPos(me));  	   
							table.insert(dists, {d, v});  	   
						end  	   
						num = num + 1;  	   
					until(num > #allplys)  	   
					table.sort(dists, function(a, b) return a[1] < b[1] end);  	   
					aimtarget = (dists[1] && dists[1][2] || nil);   	   
				elseif (aimmethod == 3) then  	   
					local health = {};  	   
					local num = 1;  	   
					repeat  	   
						local v = allplys[num];  	   
						if (Valid(v)) then  	   
							table.insert(health, {em.Health(v), v});  	   
						end  	   
						num = num + 1;  	   
					until(num > #allplys)  	   
					table.sort(health, function(a, b) return a[1] < b[1] end);  	   
					aimtarget = (health[1] && health[1][2] || nil);   	   
				end  	   
				aimignore = nil;  	   
			end  	   
				   
			local function Antiaim(ucmd)  	   
				if (!gBool("Anti-hit", "Antiaim") || cm.KeyDown(ucmd, 1) || aiming) then return; end  	   
				local aam = gInt("Anti-hit", "Method");  	   
				if (aam == 0) then  	   
					local aang = Angle(gInt("Anti-hit", "Min X"), gInt("Anti-hit", "Min Y"), 0);  	   
					cm.SetViewAngles(ucmd, aang);  	   
					FixMovement(ucmd, true);  	   
				elseif(aam == 1) then  	   
					local aang = Angle(math.random(gInt("Anti-hit", "Min X"), gInt("Anti-hit", "Max X")), math.random(gInt("Anti-hit", "Min Y"), gInt("Anti-hit", "Max Y")), 0);  	   
					cm.SetViewAngles(ucmd, aang);  	   
					FixMovement(ucmd, true);  	   
				elseif(aam == 2) then  	   
					local aang = Angle(gInt("Anti-hit", "Min X"), math.NormalizeAngle(fa.y + 90), 0);  	   
					cm.SetViewAngles(ucmd, aang);  	   
					FixMovement(ucmd, true);  	   
				end  	   
			end  	   
				   
			local function Aimbot(ucmd)  	   
				fa = fa + Angle(cm.GetMouseY(ucmd) * .023, cm.GetMouseX(ucmd) * -.023, 0);  	   
				fa.p = math.Clamp(fa.p, -89, 89);  	   
				fa.x = math.NormalizeAngle(fa.x);  	   
				fa.y = math.NormalizeAngle(fa.y);  	   
				GetTarget();  	   
				if (aimtarget) then  	   
					local canbot = gBool("Aimbot", "Enabled");  	   
					local canbot = canbot && !gBool("Aimbot", "Aim on Mouse");  	   
					if (!canbot) then  	   
						canbot = gBool("Aimbot", "Enabled") && gBool("Aimbot", "Aim on Mouse") && input.IsMouseDown( 109 );  	   
					end  	   
					if (canbot) then  	   
						aiming = true;  	   
						local w = pm.GetActiveWeapon(me);  	   
						local nextfire = ( (w && w.Primary && w.Primary.RPM && (60/w.Primary.RPM)) || 0);  	   
						if ((w && em.GetClass(w) == "m9k_minigun")) then  	   
							nextfire = nextfire*3;  	   
						end  	   
						local btime = gBool("Aimbot", "Bullettime Check");  	   
						local canaim = (btime && (wm.GetNextPrimaryFire(w) - nextfire) <= CurTime());  	   
						if (!btime) then  	   
							canaim = true;  	   
						end  	   
						if (canaim) then  	   
							local pos = vm.Angle(GetPos(aimtarget) - em.EyePos(me));  	   
							if (gBool("Aimbot", "NoSpread")) then  	   
								pos = PredictSpread(ucmd, pos);  	   
							end  	   
							pos.x = math.NormalizeAngle(pos.x);  	   
							pos.y = math.NormalizeAngle(pos.y);  	   
							cm.SetViewAngles(ucmd, pos);  	   
							if (gBool("Aimbot", "Autoshoot")) then  	   
								cm.SetButtons(ucmd, bit.bor(ucmd.GetButtons(ucmd), 1));  	   
							end  	   
							FixMovement(ucmd);  	   
							return;  	   
						end  	   
					end  	   
				end  	   
				aiming = false;  	   
				if( (gBool("Anti-hit", "Antiaim") || gBool("Anti-hit", "Spinbot")) && !cm.KeyDown(ucmd, 1) ) then return; end  	   
				if (gBool("Aimbot", "NoSpread") && cm.KeyDown(ucmd, 1)) then  	   
					local hey = PredictSpread(ucmd, fa);  	   
					hey.x = math.NormalizeAngle(hey.x);  	   
					hey.y = math.NormalizeAngle(hey.y);  	   
					cm.SetViewAngles(ucmd, hey);  	   
					return  	   
				end  	   
				cm.SetViewAngles(ucmd, fa);  	   
			end  	   

	local function GetAngle(ang)
		if(!gBool( "Aimbot", "NoRecoil")) then return ang + pm.GetPunchAngle(me); end
		return ang;
	end
				   
			local function Spinbot(ucmd)  	   
				if (!gBool("Anti-hit", "Spinbot") || gBool("Anti-hit", "Antiaim") || cm.KeyDown(ucmd, 1)) then return; end  	   
				cm.SetViewAngles(ucmd, Angle(fa.x, cm.GetViewAngles(ucmd).y + gInt("Anti-hit", "Speed"), 0));  	   
				FixMovement(ucmd);  	   
			end  	   
				   
			local function Triggerbot(ucmd)  	   
				if (!gBool("Triggerbot", "Enabled")) then return; end  	   
				local tr = pm.GetEyeTrace(me);  	   
				if (!em.IsValid(tr.Entity) || !tr.Entity:IsPlayer() || em.Health(tr.Entity) < 1 || em.IsDormant(tr.Entity)) then return; end  	   
				if (!gBool("Triggerbot", "Target Friends") && pm.GetFriendStatus(tr.Entity) == "friend") then return; end  	   
				if (!gBool("Triggerbot", "Target Team") && pm.Team(me) == pm.Team(tr.Entity)) then return; end  	   
				cm.SetButtons(ucmd, bit.bor(cm.GetButtons(ucmd), 1));  	   
			end  	   
				   
			function GAMEMODE:CreateMove(ucmd)  	   
				Bunnyhop(ucmd);  	   
				Triggerbot(ucmd);  	   
				Aimbot(ucmd);  	   
				Spinbot(ucmd);  	   
				Antiaim(ucmd);
	end		
				

function tp(ply, pos, ang, fov)
	ang:Normalize()
	if gBool("Other", "Thirdperson") then
		ply:SetColor(Color(255,255,255,100))
		ply:SetRenderMode(RENDERMODE_TRANSALPHA)

		local view = {}
		view.origin = pos - (ang:Forward() * 100)
		view.angles = ang
		view.fov = fov
		
		return view
	end
end
hook.Add("CalcView", "thirdperson", tp)

function ThirdPersonDLP()
	return gBool("Other", "Thirdperson")
end
hook.Add("ShouldDrawLocalPlayer", "thirdperson", ThirdPersonDLP)


hook.Add("HUDPaint", "esp", function()
if gBool("Miscellaneous", "Watermark")  then 
	draw.SimpleText("cloudhack.ru ","wmfont2",12,10,Color(255,255,255))
end



 local memfootprintss = gcinfo()
for k,v in pairs(player.GetAll()) do
		local left,top,right,bottom = coordinates(v)
		local dist = v:GetPos():Distance(LocalPlayer():GetPos())
		if v ~= LocalPlayer() then	
		if dist > 20 then
		if v:Alive() then
		if left ~= 0 and right ~= 0 and top ~= 0 and bottom ~= 0 then
		

	        if gBool("WallHack", "Box")  then
		        surface.SetDrawColor(Color(255,255,255))
		        surface.DrawLine( left, top, right, top )
		        surface.DrawLine( left, top, left, bottom )
		        surface.DrawLine( right, top,  right, bottom )
		        surface.DrawLine( left, bottom, right, bottom )
 
		        surface.SetDrawColor(Color(0,0,0))
		        surface.DrawLine( left-1, top-1, right+1, top-1 )
		        surface.DrawLine( left-1, top-1, left-1, bottom+1 )
		        surface.DrawLine( right+1, top-1, right+1, bottom+1 )
		        surface.DrawLine( left-1, bottom+1, right+1, bottom+1 )
 
		        surface.SetDrawColor(Color(0,0,0))
		        surface.DrawLine( left+1, top+1, right-1, top+1 )
		        surface.DrawLine( left+1, top+1, left+1, bottom-1 )
		        surface.DrawLine( right-1, top+1, right-1, bottom-1 )
		        surface.DrawLine( left+1, bottom-1, right-1, bottom-1 )
		    end
 
	        local hpdraw = {
	        {x=left-4,y=top},
	        {x=left-2,y=top},
	        {x=left-2,y=bottom},
	        {x=left-4,y=bottom}
	    	}
			if gBool("WallHack", "Name")  then 
				draw.SimpleTextOutlined(v:GetName(),"default",left + (right - left) / 2, top - 10,Color(255,255,255),1,1,1,Color(0,0,0))
			end
		
			if IsValid(v:GetActiveWeapon()) and gBool("WallHack", "Weapon") then
			draw.SimpleTextOutlined(v:GetActiveWeapon():GetPrintName() or v:GetActiveWeapon():GetClass(),"default",left + (right - left) / 2, bottom + 10,Color(255,255,255),1,1,1,Color(0,0,0))
			end
			w, h = ScrW(), ScrH()
    		w = w/2
			local hp = math.min(v:Health(), 100)
			local height = bottom - top - 1
            local healthbar_height = (hp / 100) * height
            local healthbar_height2 = (100 / 100) * height
			local width = (w * (hp / 100.0))
			local red = 255 - (hp*2.55)
			local green = hp * 2.55
			if gBool("WallHack", "Health")  then numb = v:Health().."%" else numb = "" end
			if gBool("WallHack", "Health")  then
				drawfillbox( 0,"", left - 8, bottom - healthbar_height2 - 2,left - 2, bottom,0,0,0,255 )
				drawfillbox( 0,"", left - 7, bottom - healthbar_height2 - 1,left - 3, bottom-1,0,200,0,40 )
				drawfillbox( 0,numb, left - 7, bottom - healthbar_height - 1,left - 3, bottom-1,red,green,0,255 )
			end
			local ar = math.min(v:Armor(), 100)
            local armorbar_height = (ar / 100) * height
            local numb
            if gBool("WallHack", "Armor")  then numb = v:Armor().."%" else numb = "" end
			if gBool("WallHack", "Armor")  then
				drawfillbox( 0,"", left - 15, bottom - healthbar_height2 - 2,left - 10, bottom,0,0,0,255 )
				drawfillbox( 0,"", left - 14, bottom - healthbar_height2 - 1,left - 11, bottom-1,0,200,0,40 )
				drawfillbox( 2,numb, left - 14, bottom - armorbar_height - 1,left - 11, bottom-1,19,136,191,255 )
			end
			local plys = v
			local Bones = {}
			local sBones = {
			"ValveBiped.Bip01_Head1",
			"ValveBiped.Bip01_Neck1",
			"ValveBiped.Bip01_Spine4",
			"ValveBiped.Bip01_Spine2",
			"ValveBiped.Bip01_Spine1",
			"ValveBiped.Bip01_Spine",
			"ValveBiped.Bip01_Pelvis",
			"ValveBiped.Bip01_R_UpperArm",
			"ValveBiped.Bip01_R_Forearm",
			"ValveBiped.Bip01_R_Hand",
			"ValveBiped.Bip01_L_UpperArm",
			"ValveBiped.Bip01_L_Forearm",
			"ValveBiped.Bip01_L_Hand",
			"ValveBiped.Bip01_R_Thigh",
			"ValveBiped.Bip01_R_Calf",
			"ValveBiped.Bip01_R_Foot",
			"ValveBiped.Bip01_R_Toe0",
			"ValveBiped.Bip01_L_Thigh",
			"ValveBiped.Bip01_L_Calf",
			"ValveBiped.Bip01_L_Foot",
			"ValveBiped.Bip01_L_Toe0"
			}
			local Success = true
			for k, v in pairs(sBones) do
				if plys:LookupBone(v) != nil && plys:GetBonePosition(plys:LookupBone(v)) != nil then
					table.insert( Bones, plys:GetBonePosition(plys:LookupBone(v)):ToScreen() )
				else
					Success = false
				end
			end
			surface.SetDrawColor(Color(255,255,255))
			if Success and gBool("WallHack", "Skeleton")  then
				surface.DrawLine( Bones[1].x, Bones[1].y, Bones[2].x, Bones[2].y )
				surface.DrawLine( Bones[2].x, Bones[2].y, Bones[3].x, Bones[3].y )
				surface.DrawLine( Bones[3].x, Bones[3].y, Bones[4].x, Bones[4].y )
				surface.DrawLine( Bones[4].x, Bones[4].y, Bones[5].x, Bones[5].y )
				surface.DrawLine( Bones[5].x, Bones[5].y, Bones[6].x, Bones[6].y )
				surface.DrawLine( Bones[6].x, Bones[6].y, Bones[7].x, Bones[7].y )
 
				//Legs
				surface.DrawLine( Bones[7].x, Bones[7].y, Bones[14].x, Bones[14].y )
				surface.DrawLine( Bones[14].x, Bones[14].y, Bones[15].x, Bones[15].y )
				surface.DrawLine( Bones[15].x, Bones[15].y, Bones[16].x, Bones[16].y )
				surface.DrawLine( Bones[16].x, Bones[16].y, Bones[17].x, Bones[17].y )
 
				surface.DrawLine( Bones[7].x, Bones[7].y, Bones[18].x, Bones[18].y )
				surface.DrawLine( Bones[18].x, Bones[18].y, Bones[19].x, Bones[19].y )
				surface.DrawLine( Bones[19].x, Bones[19].y, Bones[20].x, Bones[20].y )
				surface.DrawLine( Bones[20].x, Bones[20].y, Bones[21].x, Bones[21].y )
 
				//Arms
				surface.DrawLine( Bones[3].x, Bones[3].y, Bones[8].x, Bones[8].y )
				surface.DrawLine( Bones[8].x, Bones[8].y, Bones[9].x, Bones[9].y )
				surface.DrawLine( Bones[9].x, Bones[9].y, Bones[10].x, Bones[10].y )
 
				surface.DrawLine( Bones[3].x, Bones[3].y, Bones[11].x, Bones[11].y )
				surface.DrawLine( Bones[11].x, Bones[11].y, Bones[12].x, Bones[12].y )
				surface.DrawLine( Bones[12].x, Bones[12].y, Bones[13].x, Bones[13].y )
 
			end
			if gBool("WallHack", "Team") then
				draw.SimpleTextOutlined(team.GetName(v:Team()),"default",right+3, top,team.GetColor(v:Team()),0,0,1,Color(0,0,0))
			end
			if gBool("WallHack", "Group")  then
				draw.SimpleTextOutlined(v:GetUserGroup(),"default",right+3, top+11,Color(255,255,255),0,0,1,Color(0,0,0))
			end
			if gBool("ESP", "Halo")  then
					local wep = v:GetActiveWeapon()
		halo.Add({v, wep}, Color(220,220,220), .55, .55, 5, true, true)
		end
		end
if (gInt("ESP", "Box") == 2) then 	
    surface.SetDrawColor(255,255,255)
	x1, y1, x2, y2 = ScrW() * 2, ScrH() * 2, - ScrW(), - ScrH()
		min, max = v:GetCollisionBounds()
		corners = {v:LocalToWorld(Vector(min.x, min.y, min.z)):ToScreen(), v:LocalToWorld(Vector(min.x, max.y, min.z)):ToScreen(), v:LocalToWorld(Vector(max.x, max.y, min.z)):ToScreen(), v:LocalToWorld(Vector(max.x, min.y, min.z)):ToScreen(), v:LocalToWorld(Vector(min.x, min.y, max.z)):ToScreen(), v:LocalToWorld(Vector(min.x, max.y, max.z)):ToScreen(), v:LocalToWorld(Vector(max.x, max.y, max.z)):ToScreen(), v:LocalToWorld(Vector(max.x, min.y, max.z)):ToScreen()}
		for _k, _v in next, corners do
			x1, y1 = math.min(x1, _v.x), math.min(y1, _v.y)
			x2, y2 = math.max(x2, _v.x), math.max(y2, _v.y)
		end
		diff, diff2 = math.abs(x2 - x1), math.abs(y2 - y1)
				surface.DrawLine(x1 + 1, y1 + 1, x1 + (diff*0.225), y1 + 1)
				surface.DrawLine(x1 + 1, y1 + 1, x1 + 1, y1 + (diff2*0.225))
				surface.DrawLine(x1 + 1, y2 - 1, x1 + (diff*0.225), y2 - 1)
				surface.DrawLine(x1 + 1, y2 - 1, x1 + 1, y2 - (diff2*0.225))
				surface.DrawLine(x2 - 1, y1 + 1, x2 - (diff*0.225), y1 + 1)
				surface.DrawLine(x2 - 1, y1 + 1, x2 - 1, y1 + (diff2*0.225))
				surface.DrawLine(x2 - 1, y2 - 1, x2 - (diff*0.225), y2 - 1)
				surface.DrawLine(x2 - 1, y2 - 1, x2 - 1, y2 - (diff2*0.225))
end				
	end
end
end
end   
    
    if gBool("Other", "Radar") then
        local x = ScrW() - 5
        local y = 5
        if gBool("Other", "Radar") then
            y = 210
        end

    end

    if gBool("Other", "Radar") then
        local size = 200
        local x = ScrW() - size - 8
        local y = 0 + 8

        surface.SetDrawColor(Color(120, 120, 255, 20))
        surface.DrawRect(x - 2, y - 2, size + 4, size + 4)
        surface.SetDrawColor(Color(0, 0, 0, 200))
        surface.DrawRect(x, y, size, size)
        surface.SetDrawColor(Color(255, 255, 255, 255))
        surface.DrawLine(x, y, x + (size / 2), y + (size / 2))
        surface.DrawLine(x + size, y, x + (size / 2), y + (size / 2))
        surface.SetDrawColor(Color(255, 255, 255))
        surface.DrawRect((x -2)+ (size/2), (y-2) + (size/2), 4, 4)

        for k,v in pairs(player.GetAll()) do
            if v == ply || !v:Alive() then continue end
            local n = v:Nick()
            if gm == "Murder" then
                n = v:GetNWString("bystanderName")
            end
            if gBool("Other", "HN Radar") then
                n = ""
            end

            local c = v:GetPlayerColor()
            local col = Color(c.x * 255, c.y * 255, c.z * 255)

            local lx = ply:GetPos().x - v:GetPos().x
            local ly = ply:GetPos().y - v:GetPos().y
            local ang = EyeAngles().y
            local cos = math.cos(math.rad(-ang))
            local sin = math.sin(math.rad(-ang))
            local px = (ly * cos) + (lx * sin)
            local py = (lx * cos) - (ly * sin)
            px = px / 20
            py = py / 20
            px = math.Clamp(px, -(size * 0.50), size * 0.50)
            py = math.Clamp(py, -(size * 0.50), size * 0.50)
            draw.SimpleTextOutlined(n, "default", x + size - (size * 0.50) + px - 13, y + size - (size * 0.50) + py - 7, col, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER, 1, Color(0, 0, 0))
            surface.SetDrawColor(col)
            surface.DrawRect(x + size - (size * 0.50) + px, y + size - (size * 0.50) + py, 3, 3)
        end
    end
end)

	hook.Add("CalcView", "Hook20", function(me, pos, ang, fov)
	if me:Alive() and me:Health() > 0 and me:Team() ~= TEAM_SPECTATOR then
			if gBool("Other", "Custom Fov") and not gBool("Miscellaneous", "Thirdperson") then
				local view = {}
				view.origin = pos
				view.angles = angles
				view.fov = gInt("Other", "Fov")
			if (ply:Health() > 0 and ply:GetMoveType() ~= 10 and ply:GetObserverTarget() == nil) then
				if (gBool("Other", "RCS Control")) then
					view.origin = ply:EyePos()
					view.angles = ply:EyeAngles()
				end
			end
			if (FreeCam and gBool("Other", "Custom Fov") and gBool("Other", "Free Cam") and CamKeyCheck() and not gBool("Miscellaneous", "Thirdperson") and not menuopen and not me:IsTyping() and not gui.IsGameUIVisible() and not gui.IsConsoleVisible() and not (IsValid(g_SpawnMenu) && g_SpawnMenu:IsVisible()) and not (me:Team() == TEAM_SPECTATOR) and not (me:Health() < 1) and not (me:Alive())) then
				view.origin = CamPos
				view.angles = ply:EyeAngles()
				view.fov = gInt("Other", "Fov")
			end
				return view
			else
				local view = {
				angles = GetAngle(fa), 
				origin = (gBool("Miscellaneous", "Thirdperson") and pos + am.Forward(fa) * (gInt("Miscellaneous", "Max Dist") * - 10) or pos), 
				}
			return view
			end
		end
	end)		
				   
			local quake=0;  	   
				   
			local ks = {  	   
				nil,  	   
				"quake/doublekill.wav",  	   
				"quake/triplekill.wav",  	   
				"quake/dominating.wav",  	   
				"quake/killingspree.wav",  	   
				"quake/rampage.wav",  	   
				"quake/megakill.wav",  	   
				"quake/monsterkill.wav",  	   
				"quake/ultrakill.wav",  	   
				"quake/unstoppable.wav",  	   
				"quake/godlike.wav",  	   
			}  	   
				   
			gameevent.Listen("entity_killed") -- thanks to d3x for the entity_killed bullshit since there arent any default shared playerdeath hooks or whatever  	   
				   
			function GAMEMODE:entity_killed(event)  	   
				if (!gBool("Miscellaneous", "Quakesounds")) then quake = 0; return; end  	   
				local attacker = Entity(event.entindex_attacker)  	   
				local victim = Entity(event.entindex_killed)  	   
					   
				if (!em.IsValid(victim) || !em.IsValid(attacker) || victim == attacker || attacker != me || !pm.IsPlayer(victim)) then  	   
					if(me == victim) then  	   
						quake = 0;  	   
					end  	   
					return;  	   
				end  	   
					   
				quake = quake+1;  	   
					   
				if (quake>=13) then quake = 0; end  	   
					   
				if (!ks[quake]) then return; end  	   
					   
				surface.PlaySound(ks[quake]);  	   
			end  	   
				   
			local mat = CreateMaterial("", "VertexLitGeneric", {  	   
				["$basetexture"] = "models/debug/debugwhite",   	   
				["$model"] = 1,   	   
				["$ignorez"] = 1,  	   
			});  	   
				   
			local mat2 = CreateMaterial(" ", "VertexLitGeneric", {  	   
				["$basetexture"] = "models/debug/debugwhite",   	   
				["$model"] = 1,   	   
				["$ignorez"] = 0,  	   
			});  	   
				

	hook.Add("RenderScene", "Hook1", function()
		if gBool("Miscellaneous", "Nigga Mode") then
			for k, v in pairs(game.GetWorld():GetMaterials()) do
			Material(v):SetVector("$color", Vector(0.07, 0.07, 0.07))
			end
			render.SuppressEngineLighting(true)
			render.ResetModelLighting(0.2, 0.2, 0.2)
			else
			for k, v in pairs(game.GetWorld():GetMaterials()) do
			Material(v):SetVector("$color", Vector(1, 1, 1))
			end
			render.SuppressEngineLighting(false)
			render.ResetModelLighting(1, 1, 1)
		end
		render.SetLightingMode(gBool("Miscellaneous", "FullBright") and 1 or 0)
	end)

	hook.Add("PostDrawViewModel", "Hook2", function(vm)
		if(!vm) then return end
		render.SetLightingMode(0)
		for k, v in next, vm:GetMaterials() do
			render.MaterialOverrideByIndex(k - 1, nil)
		end
	end)

	hook.Add("PreDrawEffects", "Hook3", function()
		render.SetLightingMode(0)
	end)			
				
				
	hook.Add("HUDShouldDraw", "Hook4", function(name)
		if (!gBool("Miscellaneous", "Hide HUD")) then return; end  
			return false
	end)
				  
			function GAMEMODE:RenderScreenspaceEffects()  	   
				if (!gBool("ESP", "Chams")) then return; end  	   
				local allplys = player.GetAll();  	   
				for i = 1, #allplys do  	   
					local v = allplys[i];					
					if (!v || !em.IsValid(v) || v == me || em.Health(v) < 1 || pm.Team(v) == 1002) then continue; end
                    				
					local col = gBool("Other", "Autism") && Color(math.random(255), math.random(255), math.random(255)) || team.GetColor(pm.Team(v));  	   
					cam.Start3D();  	   
						render.MaterialOverride(mat);  	   
						render.SetColorModulation(col.b / 255, col.r / 255, col.g / 255);  	   
						em.DrawModel(v);  	   
						render.MaterialOverride(mat2);  	   
						render.SetColorModulation(col.r / 255, col.g / 255, col.b / 255);  	   
						em.DrawModel(v);  	   
						render.SetColorModulation(1, 1, 1);  	   
					cam.End3D();  	   
				end  	   
			end  	   
				   
			function GAMEMODE:ShouldDrawLocalPlayer()  	   
				return(gBool("Miscellaneous", "Thirdperson"));  	   
			end  	   
				   
			function GAMEMODE:PreDrawSkyBox()  	   
				if (!gBool("Other", "No Sky")) then return; end  	   
				render.Clear(50, 50, 50, 255);  	   
				return true;  	   
			end  	   
				   
				
		local function Filter(v)
			local enemy = gBool("Other", "Enemies only");
			local dist = gBool("Other", "ESP Dist")
			if(enemy) then
				if(pm.Team(v) == pm.Team(me)) then return false; end
			end
			if(dist) then
				local maxdist = gBool("Other", "Max Dist");
				if( vm.Distance( em.GetPos(v), em.GetPos(me) ) > (maxdist * 5) ) then return false; end
			end
			return true;
		end
		
		local function Filter(v)
		if(gBool("Other", "Enemies only")) then
			local dist = gBool("Other", "ESP Dist")
				if(vm.Distance(em.GetPos(v), em.GetPos(me)) > (dist * 5)) then return false end
			end
		return true
	end


				
			local ogethands = pm.GetHands; -- Note: Only for c_ viewmodels  	   
				   
			function pm.GetHands(...)  	   
				return(!gBool("Other", "No Hands") && ogethands(...));  	   
			end

			hook.Add("entity_killed", "", function(data)
			 local att_index = data.entindex_attacker;
			 local vic_index = data.entindex_killed;
			if (!gBool("Miscellaneous", "Kill Say")) then return; end  
			 if(vic_index != att_index && att_index == me:EntIndex()) then
			 RunConsoleCommand("say", "Get Good, Get cloudhack")
			 end


			end);