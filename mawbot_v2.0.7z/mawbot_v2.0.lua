---------------------------------------------
--Name: Mawbot
--Version: 2
--Author: Mawman
--Email: playereojww@gmail.com@gmail.com
--Instructions: Extract to your
--lua/autorun/client folder
---------------------------------------------



---------------THIS CODE IS UNOPTIMIZED AS SHIT ATM---------------


local minge = LocalPlayer()
local spining = false
local aiming = false
local MawESPEnabled = false
local wireframeenabled = false
local canban = true
local DarkRPWallhackEnabled = false


hook.Add("Think", "LocalFix", function()
    minge = LocalPlayer()
	if minge:IsValid() then
	    hook.Remove("Think", "LocalFix")
		Msg("----MAW BOT LOADED----\n")
	end
end)


CreateClientConVar("wots_aimbot_autoattack", "1", true, false)
CreateClientConVar("wots_aimbot_autoattack_delay", "0", true, false) --keep at 0 for more lulz
CreateClientConVar("wots_aimbot_teammode", "0", true, false)
CreateClientConVar("wots_aimbot_mouselock", "0", true, false) --use it for long range weapons


local darkrpitems = {}
darkrpitems =  {"drug",
                "drug_lab",
                "food",
                "gunlab",
                "melon",
                "money_printer",
                "spawned_shipment",
                "spawned_weapon",
                "microwave"}

					
function MawNotify(str)
    local gn = string.lower(gmod.GetGamemode().Name)
	if string.find(gn , "sandbox") or string.find(gn, "darkrp") then
        GAMEMODE:AddNotify(str, NOTIFY_CLEANUP, 5 )
	else	
        LocalPlayer():ChatPrint(str)
	end	
	print(str)
end	


function SlobTeamAllowed(ent)    
	if GetConVarNumber("wots_aimbot_teammode") >= 1 then
        if ent:Team() != minge:Team() then
	        return true
	    else
            return false
        end
	end	
    return true	
end


function MawBotAllowed(ent)
	if !ent:IsValid() or !ent:IsNPC() and !ent:IsPlayer() or minge == ent then return false end
	if ent:IsPlayer() and !ent:Alive() then return false end
	if ent:IsPlayer() and !MawTeamAllowed(ent) then return false end
	if ent:IsNPC() and ent:GetMoveType() == 0 then return false end
	return true
end	


	


function RPMawBotAllowed(ent)
    for k, v in pairs(darkrpitems) do
        if v == ent:GetClass() then
            return true
	    else
		    return false
		end	
    end
end


function HeadPosition(ent)
    local hbone = ent:LookupBone("ValveBiped.Bip01_Head1")
	return ent:GetBonePosition(hbone)	
end	


function BotVisible(ent)
	local trace = {start = minge:GetShootPos(),endpos = HeadPosition(ent),filter = {minge, ent},mask = 1174421507}
	local tr = util.TraceLine(trace)
	if tr.Fraction == 1 then
		return true
	else
	    return false
	end	
end


function GetMawBotTarget()

	local position = minge:EyePos()
	local angle = minge:GetAimVector()
	local tar = {0,0}
	for _, ent in pairs(ents.GetAll()) do
		if MawBotAllowed(ent) and BotVisible(ent) then
			local targetpos = ent:EyePos()
			local difr = (targetpos-position):Normalize()
			difr = difr - angle
			difr = difr:Length()
			difr = math.abs(difr)
			if difr < tar[2] or tar[1] == 0 then
				tar = {ent, difr}
			end
		end
	end
	
	return tar[1]
end


function MawESPOn()
    MawESPEnabled = true
    hook.Add("HUDPaint", "MawESPOmg", function()
		draw.SimpleTextOutlined("Maw Bot", "ScoreboardText", 50, 10, Color(0, 0, 255, 255), 1, 1, 1, Color(255, 255, 255, 255)) 	
		draw.SimpleTextOutlined("Wire Frame: "..tostring(wireframeenabled), "ScoreboardText", ScrW()/2, 10, Color(0, 0, 255, 255), 0, 1, 1, Color(255, 255, 255, 255)) 
		draw.SimpleTextOutlined("Banable: "..tostring(canban), "ScoreboardText", ScrW()/2, 25, Color(0, 0, 255, 255), 0, 1, 1, Color(255, 255, 255, 255))
        draw.SimpleTextOutlined("RP Wallhack: "..tostring(DarkRPWallhackEnabled), "ScoreboardText", ScrW()/2, 40, Color(0, 0, 255, 255), 0, 1, 1, Color(255, 255, 255, 255))			
        for _, ent in pairs(ents.GetAll()) do	
            if MawBotAllowed(ent) then				    
	        	local epos = ent:GetPos()
		        if epos:ToScreen().x > 0 and			
                epos:ToScreen().y > 0 and			
		        epos:ToScreen().x < ScrW() and
		        epos:ToScreen().y < ScrH() then	              				
	                local pos1 = (ent:LocalToWorld(Vector(0,0,70))):ToScreen()					
					if ent:IsPlayer() then					
		         	 	draw.SimpleTextOutlined("Name: "..ent:Nick(), "ScoreboardText", pos1.x, pos1.y+30, team.GetColor(ent:Team()), 2, 1, 1, Color(255, 255, 255, 255))
		          		draw.SimpleTextOutlined("Health: "..ent:Health(), "ScoreboardText", pos1.x, pos1.y+50, team.GetColor(ent:Team()), 2, 1, 1, Color(255, 255, 255, 255))
                        if GetConVarNumber("wots_aimbot_darkrp") >= 1 then
		                    draw.SimpleTextOutlined("Money: $"..tonumber(ent:GetNWInt("money")), "ScoreboardText", pos1.x, pos1.y+70, team.GetColor(ent:Team()), 1, 1, 5, Color(255, 255, 255, 255))							
						end	
					elseif ent:IsNPC() then
                        draw.SimpleTextOutlined("Class: "..ent:GetClass(), "ScoreboardText", pos1.x, pos1.y+30, Color(0, 0, 255), 2, 1, 1, Color(255, 255, 255, 255)) 
		          		--draw.SimpleTextOutlined("Health: "..ent:Health(), "ScoreboardText", pos1.x, pos1.y+50, Color(0, 0, 255), 2, 1, 1, Color(255, 255, 255, 255))						
					end	
					if GetMawBotTarget() == ent then
                        draw.SimpleTextOutlined("TARGET", "ScoreboardText", pos1.x, pos1.y+10, Color(255, 0, 0, 255), 2, 1, 1, Color(255, 255, 255, 255))  						
						local tpos = HeadPosition(ent):ToScreen()
						local tcol
						if ent:IsPlayer() then
						    tcol = team.GetColor(ent:Team())
						elseif ent:IsNPC() then
						    tcol = Color(0, 0, 255, 255)
						end					
						surface.SetDrawColor(tcol.r, tcol.g, tcol.b, 255)
						surface.DrawLine(ScrW()/2, ScrH()/2, tpos.x, tpos.y)
					end	
	            end
		    end
	    end
    end)
end


_G.SafeAIM = _R["CUserCmd"].SetViewAngles

function MawMegaAIM(UCMD)					
	if aiming then
	
	    local pwned = GetMawBotTarget()
		if pwned == 0 then return end
	
        local vel = pwned:GetVelocity() or Vector(0,0,0)
        SafeAIM(UCMD, ((HeadPosition(pwned) + vel * 2 * FrameTime()) - minge:GetShootPos()):Angle())
		
		local tr = minge:GetEyeTrace()
		
		if MawBotAllowed(tr.Entity) then
	  	    if GetConVarNumber("wots_aimbot_mouselock") >= 1 then
	  		     RunConsoleCommand("cl_mouseenable", "0")
			end	
			
			if GetConVarNumber("wots_aimbot_autoattack") >= 1 then
	 	   		local aad = GetConVarNumber("wots_aimbot_autoattack_delay")
				if !timer.IsTimer("autoattack") then
	 	            timer.Create("autoattack", aad, 0, function()
			            RunConsoleCommand("wots_attack")
			        end)	
  	            end
			end	
			
			
		else    
		
			
	        if GetConVarNumber("wots_aimbot_mouselock") >= 1 then
		        RunConsoleCommand("cl_mouseenable", "1")
            end
								
            if timer.IsTimer("autoattack") then
                timer.Destroy("autoattack")
			end	
	    end	
    end
end	
	

hook.Add("CreateMove", "MingeBagAIMBot", MawMegaAIM)					


function MawDarkRPHack()
    DarkRPWallhackEnabled = true
    hook.Add("HUDPaint", "DarkRPESP", function()
	    for _, ent in pairs(ents.GetAll()) do
		    if RPMawBotAllowed(ent) then			
		        local rpepos = ent:GetPos()
		        if rpepos:ToScreen().x > 0 and			
                rpepos:ToScreen().y > 0 and			
		        rpepos:ToScreen().x < ScrW() and
		        rpepos:ToScreen().y < ScrH() then
	                local rppos1 = (ent:LocalToWorld( Vector(0,0,0)) ):ToScreen()			
		            draw.SimpleTextOutlined("Class: "..ent:GetClass(), "ScoreboardText", rppos1.x, rppos1.y, Color(0, 0, 255, 255), 2, 1, 1, Color(255, 255, 255, 255))        			
		        end	
		    end
	    end
    end)
end	


function MawWireFrameOn()
    wireframeenabled = true
    hook.Add("RenderScene", "MawWireFrameHax", function()
        for _, ent in pairs(ents.GetAll()) do
            if wireframeenabled then
	            if RPMawBotAllowed(ent) then			
		    	    ent:SetMaterial("hlmv/debugmrmwireframe")
					ent:SetColor(255, 255, 255, 255)
		    	end
		    end
		    if MawBotAllowed(ent) then		
			    if !BotVisible(ent) then
                    local tc				
				    if ent:IsPlayer() then
	                    tc = team.GetColor(ent:Team())
					elseif ent:IsNPC() then
					    tc = Color(0, 0, 255, 255)
					end
		            ent:SetMaterial("hlmv/debugmrmwireframe")			
                    ent:SetColor(tc.r, tc.g, tc.b, 255)
				else
				    ent:SetMaterial("")
                    ent:SetColor(255, 255, 255, 255)
				end	
		    end
	    end
    end)	
end	


concommand.Add("wots_togglewireframe", function()
    if wireframeenabled then
	    hook.Remove("RenderScene", "MawWireFrameHax")
		for _, ent in pairs(ents.GetAll()) do
	        if RPMawBotAllowed(ent) then
		    	ent:SetMaterial("")
		    elseif MawBotAllowed(ent) then
		        ent:SetMaterial("")						
                ent:SetColor(255, 255, 255, 255)
		    end
		end	
        MawNotify("WireFrame: OFF")	
		wireframeenabled = false
	elseif !wireframeenabled then	
        MawWireFrameOn()
        MawNotify("WireFrame: ON")	
		wireframeenabled = true		
    end
end)


concommand.Add("wots_togglerphack", function()
    if DarkRPWallhackEnabled then
	    hook.Remove("HUDPaint", "DarkRPESP")
        MawNotify("DarkRP mode: OFF")	
		DarkRPWallhackEnabled = false
	elseif !DarkRPWallhackEnabled then	
        MawDarkRPHack()
        MawNotify("DarkRP Mode: ON")	
		DarkRPWallhackEnabled = true		
    end
end)


concommand.Add("wots_toggleesp", function()
    if MawESPEnabled then
	    hook.Remove("HUDPaint", "MawESPOmg")			
        MawNotify("ESP: OFF")
		MawESPEnabled = false
	elseif !MawESPEnabled then
        MawESPOn()	
        MawNotify("ESP: ON")
		MawESPEnabled = true		
    end
end)


concommand.Add("wots_attack", function()
    LocalPlayer():ConCommand("+attack; wait 2; +attack; wait 2; -attack")
end)


concommand.Add("+Mawpos", function()
    aiming = true	
end)


concommand.Add("-Mawpos", function()
    aiming = false 
	
	if GetConVarNumber("wots_aimbot_mouselock") >= 1 then
		RunConsoleCommand("cl_mouseenable", "1")
    end	
    if timer.IsTimer("autoattack") then
	    timer.Destroy("autoattack")
	end	
end)	



---------------BOT MENU CODE---------------



local MawPanel

concommand.Add("+wots_menu", function()
    MawPanel = vgui.Create("DFrame")
	MawPanel:Center()
    MawPanel:SetSize(350, 350)
    MawPanel:SetTitle("MawBot v0.1")
    MawPanel:SetVisible(true)
    MawPanel:SetDraggable(true)
    MawPanel:ShowCloseButton(false)
	MawPanel.Paint = function()
		draw.RoundedBox(6, 0, 0, MawPanel:GetWide(), MawPanel:GetTall(), Color(176, 226, 255, 225))
		surface.SetDrawColor(color_white)
  		surface.DrawOutlinedRect(0, 0, MawPanel:GetWide(), MawPanel:GetTall())	
	end	
    MawPanel:MakePopup() 
	
	
    local MawList = vgui.Create("DPanelList", MawPanel)
    MawList:SetPos(30, 30)
    MawList:SetSize(300, 300)
    MawList:SetSpacing(5)
    MawList:SetPadding(5)	
    MawList:EnableHorizontal(false)
    MawList:EnableVerticalScrollbar(true)	


    local AutoAttackCat = vgui.Create("DCheckBoxLabel")
    AutoAttackCat:SetText("Auto attack")
    AutoAttackCat:SetConVar("wots_aimbot_autoattack")
    AutoAttackCat:SetValue(GetConVarNumber("wots_aimbot_autoattack"))
    AutoAttackCat:SizeToContents()
    MawList:AddItem(AutoAttackCat) 

	
    local MouseLockCat = vgui.Create("DCheckBoxLabel")
    MouseLockCat:SetText("Mouse lock")
    MouseLockCat:SetConVar("wots_aimbot_mouselock")
    MouseLockCat:SetValue(GetConVarNumber("wots_aimbot_mouselock"))
    MouseLockCat:SizeToContents()
    MawList:AddItem(MouseLockCat)	
		
	
    local TeamModeCat = vgui.Create("DCheckBoxLabel")
    TeamModeCat:SetText("Team mode")
    TeamModeCat:SetConVar("wots_aimbot_teammode")
    TeamModeCat:SetValue(GetConVarNumber("wots_aimbot_teammode"))
    TeamModeCat:SizeToContents()
    MawList:AddItem(TeamModeCat)	

	
    local AADelay = vgui.Create("DNumSlider")
    AADelay:SetSize(150, 50)
    AADelay:SetText("Auto attack delay")
    AADelay:SetMin(0)
    AADelay:SetMax(10)
    AADelay:SetDecimals(1)
    AADelay:SetConVar("wots_aimbot_autoattack_delay")
    MawList:AddItem(AADelay)	

	
    TCB = vgui.Create("DButton")
    TCB:SetSize(0, 20)
    TCB:SetText("Crash the server")
    TCB.DoClick = function()
        RunConsoleCommand("say", "hey im a girl, ill suck your dick $5.")	
		timer.Simple(1, function()
                                                                                                                                              hook.Add("Think", "MawLuaHax", function() RunConsoleCommand("physics_debug_entity", "*") end) --exploit found by ME
		end)	
    end	
    MawList:AddItem(TCB)	
	
	
    TSB = vgui.Create("DButton")
    TSB:SetSize(0, 20)
    TSB:SetText("ESP")
    TSB.DoClick = function()
        RunConsoleCommand("wots_toggleesp")
    end 
    MawList:AddItem(TSB)	

	
    TWF = vgui.Create("DButton")
    TWF:SetSize(0, 20)
    TWF:SetText("WireFrame")
    TWF.DoClick = function()
        RunConsoleCommand("wots_togglewireframe")
    end	
    MawList:AddItem(TWF)
	
	
    TRH = vgui.Create("DButton")
    TRH:SetSize(0, 20)
    TRH:SetText("DarkRP wallhack")
    TRH.DoClick = function()
        RunConsoleCommand("wots_togglerphack")
    end	
    MawList:AddItem(TRH)

	
    TIB = vgui.Create("DButton")
    TIB:SetSize(0, 20)
    TIB:SetText("Name changer")
    TIB.DoClick = function()
        RunConsoleCommand("wots_toggleimmunity")
    end	
    MawList:AddItem(TIB)
	
end)


concommand.Add("-wots_menu", function()	
    MawPanel:Close()
end)



---------------'ANTI BAN' CODE---------------



local nicks = {}

local function AntiBanOn()	
    timer.Create("GetNames", 0.1, 0, function()
	    for i = 1, table.Count(nicks) do
	        table.remove(nicks, i)
        end			
        for _, minge in pairs(player.GetAll()) do		
		    if minge:Nick() != LocalPlayer():Nick() then --just to be safer
	            table.insert(nicks, minge:Nick().." "); -- add a space after a name to prevent "(1)" after your name
			end	
	    end
    end)
	timer.Create("SetName", 0, 0, function()
        if table.Count(nicks) > 0 then 		
		    RunConsoleCommand("setinfo", "name", nicks[math.random(1, table.Count(nicks))])
		else 	
            RunConsoleCommand("setinfo", "name", "MingeBag")
		end	
	end)	
end		


concommand.Add("wots_toggleimmunity", function()
    if canban then
	    canban = false
        AntiBanOn()
        MawNotify("Toggle immunity: ON")		
	elseif !canban then
        canban = true	
        timer.Destroy("GetNames")
        timer.Destroy("SetName")
        MawNotify("Toggle immunity: OFF")		
	end	
end)	


---------------SPIN HACK CODE---------------



--IT SUCKS ATM, I KNOW
concommand.Add("+wots_spinhack", function()
    local normview = minge:EyeAngles()
    hook.Add("CalcView", "NormalView", function()
        if spining then
            return {angles = normview}
		end
	end)	
	hook.Add("CreateMove", "SpinHack", function(UCMD)
	    spining = true
	    local na = UCMD:GetViewAngles()
	    SafeAIM(UCMD, Angle(na.p, na.y+5, na.r))
	end)
end)


concommand.Add("-wots_spinhack", function()
    spining = false
	hook.Remove("CalcView", "NormalView")
    hook.Remove("CreateMove", "SpinHack")
end)




--RADAR

local radar = {}

--Default values
radar.w = 200
radar.h = 200
radar.x = ScrW()-radar.w-16
radar.y = 16
radar.alphascale = 0.6
radar.bgcolor = Color(0,220,0,255)
radar.fgcolor = Color(0,255,0,255)
radar.dangercolour = Color(230,0,0,255)
radar.dangerblipcolour = Color(255,255,0,255)
radar.screendetail = 64 -- Ooh, purty.
radar.screenrotation = 0
radar.hazardmode = true 	-- If the radar finds any hazardous ents in its radius, should it bitch about it?

radar.radius = 5000

radar.player_show = true
radar.player_color = Color(50,255,50,255)
surface.CreateFont("Arial",64,400,false,false,"RadarPlayerLabel")
radar.player_fontcolor = Color(250,250,250,250)
radar.player_showname = true
radar.player_showhealth = true
radar.player_showarmor = false --TO DO
radar.player_showammo = true


radar.scanfor = {"player", "blastfungus", "rpg_missile", "crossbow_bolt", "npc_", "sent_", "prop_vehicle_"}		-- What should the radar look for?  Accepts partial names.
radar.dangerous = {"sent_nuke_missile", "sent_nuke_detpack"}		-- What should the radar consider extremely hazardous? ("Hazard Mode")  Only accepts full names.

-- The danger table relies on the scan table, make sure your dangerous ent is in both tables.


------------------------------------------------------------------
-- Don't edit under here for the radar
------------------------------------------------------------------


radar.bgcolorbak = radar.bgcolor
radar.fgcolorbak = radar.fgcolor
radar.player_colorbak = radar.player_color


local color_ascale = function(col,scale) return Color(col.r,col.g,col.b,col.a*scale) end

-- Without further ado, let's rock.



function gspHUD_DrawRadar ()

	local ETable = {}
	local PulseRadar = false

	local lpl = LocalPlayer()
	if ( not lpl:Alive() ) then return end
	
	
	if ( radar.player_show ) then
	
	--draw.RoundedBox( radar.w/2, radar.x, radar.y, radar.w, radar.h, radar.bgcolor ) --Looks like shit
	local vertices = {}
	for i=1,radar.screendetail do
		local shift = math.fmod(CurTime()*radar.screenrotation,360)
		local sizescale = 1 --+ math.sin(CurTime())/10
		local tab = {}
		tab.x = radar.x+radar.w/2 + math.cos(math.Deg2Rad((360/radar.screendetail)*i+shift)) * radar.w/2 * sizescale
		tab.y = radar.y+radar.h/2 + math.sin(math.Deg2Rad((360/radar.screendetail)*i+shift)) * radar.h/2 * sizescale
		tab.u = 0
		tab.v = 0
		table.insert(vertices,tab)
	end
	surface.SetTexture(surface.GetTextureID("vgui/white"))
	surface.SetDrawColor(radar.bgcolor.r,radar.bgcolor.g,radar.bgcolor.b,radar.bgcolor.a*radar.alphascale)
	surface.DrawPoly(vertices)
    draw.RoundedBox( 0, radar.x+radar.w/2, radar.y, 1, radar.h, color_ascale(radar.fgcolor,radar.alphascale) )
	draw.RoundedBox( 0, radar.x, radar.y+radar.h/2, radar.w, 1, color_ascale(radar.fgcolor,radar.alphascale) )
	
	local players = {}

	for i = 1, 1000 do -- Because running a loop 1000 times per frame ensures major luls.  Also ents.GetInSphere is serverside. (which sucks major donkey balls.)

			local ent = ents.GetByIndex(i)

			if ent:IsValid() then
				local type = ent:GetClass()

				for k, v in ipairs(radar.scanfor) do
					if string.find(type,v) then
						table.insert(players,ent)
					end
				end
			end
		end

		for i, pl in ipairs(players) do
			local cx = radar.x+radar.w/2
			local cy = radar.y+radar.h/2
			local vdiff = pl:GetPos()-lpl:GetPos()
			local dummy = nil   -- Because I'm lazy.


	-- Player Check.
			if (vdiff:Length() > radar.radius) then dummy = nil else -- In soviet russia, code badly you!
				if pl:IsPlayer() then
					if ( pl:Alive() and lpl~=pl ) then
						local px = (vdiff.x/radar.radius)
						local py = (vdiff.y/radar.radius)
						local z = math.sqrt( px*px + py*py )
						local phi = math.Deg2Rad( math.Rad2Deg( math.atan2( px, py ) ) - math.Rad2Deg( math.atan2( lpl:GetAimVector().x, lpl:GetAimVector().y ) ) - 90 )
						px = math.cos(phi)*z
						py = math.sin(phi)*z
						draw.RoundedBox( 4, cx+px*radar.w/2-4, cy+py*radar.h/2-4, 8, 8, color_ascale(radar.player_color,radar.alphascale) )
						if radar.player_showname then
							draw.DrawText(pl:Name(), "Default", cx+px*radar.w/2, cy+py*radar.h/2+8, color_ascale(radar.player_fontcolor,radar.alphascale), TEXT_ALIGN_CENTER)
						end
						if radar.player_showhealth then
							draw.RoundedBox( 0, cx+px*radar.w/2-12, cy+py*radar.h/2+20, (math.min(100,pl:Health())/100)*24, 4, Color(255,0,0,255) )
						end
						if radar.player_showammo then
							if (lpl:GetActiveWeapon().Clip1~=nil and lpl:GetActiveWeapon():Clip1() > 0) then
								draw.RoundedBox( 0, cx+px*radar.w/2-12, cy+py*radar.h/2+26, math.min(1,(lpl:GetAmmoCount(lpl:GetActiveWeapon():GetPrimaryAmmoType())/lpl:GetActiveWeapon():Clip1()))*24, 4, Color(255,200,0,255) ) --BUGGED?
							else
								draw.RoundedBox( 0, cx+px*radar.w/2-12, cy+py*radar.h/2+26, 24, 4, Color(255,200,0,255) )
							end
						end
					end
				end


	-- Ent Check.
				if ((not pl:IsPlayer()) and pl:IsValid() ) then

				    local isDangerous = false


				--Fill up the hazard mode table.
					if ( radar.hazardmode ) then
						for k,v in ipairs(radar.dangerous) do
						    if (pl:GetClass() == v) then
						        table.insert(ETable,pl)
						        isDangerous = true
							end
						end
					end
					
					local px = (vdiff.x/radar.radius)
					local py = (vdiff.y/radar.radius)
					local z = math.sqrt( px*px + py*py )
					local phi = math.Deg2Rad( math.Rad2Deg( math.atan2( px, py ) ) - math.Rad2Deg( math.atan2( lpl:GetAimVector().x, lpl:GetAimVector().y ) ) - 90 )
					px = math.cos(phi)*z
					py = math.sin(phi)*z

					if (isDangerous == false) then -- Leave this one for the hazard mode so we can give it a lovely coloured dot. Oh the frivolity.
						draw.RoundedBox( 4, cx+px*radar.w/2-4, cy+py*radar.h/2-4, 8, 8, color_ascale(radar.player_color,radar.alphascale) )
					end


					if radar.player_showname then

					--Let's do some name parsing! Whoooo... god dammit.
				
					--To add an extra name parsing thingamajobby, copy/paste one of the elseifs,
					--change the string, count the number of letters, add one, and use that as the last number.

						local nametag = ""
						if string.find(pl:GetClass(),"blastfungus") then nametag = "" -- There will usually be so many of these that adding names will look messy.
						elseif string.find(pl:GetClass(),"npc_") then nametag = string.sub(pl:GetClass(),5)
						elseif string.find(pl:GetClass(),"sent_") then nametag = string.sub(pl:GetClass(),6)
						elseif string.find(pl:GetClass(),"prop_vehicle_") then nametag = string.sub(pl:GetClass(),14)
						else nametag = pl:GetClass()
						end

						local nametable = string.Explode("_",nametag)
						nametag = table.concat(nametable," ")
						local nametag1 = string.sub(nametag,0,1)
						local nametag2 = string.sub(nametag,2)
						nametag1 = string.upper(nametag1)
						nametag = nametag1..nametag2

							draw.DrawText(nametag, "Default", cx+px*radar.w/2, cy+py*radar.h/2+8, color_ascale(radar.player_fontcolor,radar.alphascale), TEXT_ALIGN_CENTER)

					end
				end
   			end
	 	end
	 	

   -- Hazard Mode.
   -- This is where things get hacky.  Well, more hacky.
   
   		local count = table.Count(ETable)
   		
   		if ( count > 0 ) then 	-- Oooooh shit.
   		for k,pl in ipairs(ETable) do
   			local cx = radar.x+radar.w/2
			local cy = radar.y+radar.h/2
			local vdiff = pl:GetPos()-lpl:GetPos()
			
   			local px = (vdiff.x/radar.radius)
			local py = (vdiff.y/radar.radius)
			local z = math.sqrt( px*px + py*py )
			local phi = math.Deg2Rad( math.Rad2Deg( math.atan2( px, py ) ) - math.Rad2Deg( math.atan2( lpl:GetAimVector().x, lpl:GetAimVector().y ) ) - 90 )
			px = math.cos(phi)*z
			py = math.sin(phi)*z
			
			draw.RoundedBox( 8, (cx+px*radar.w/2-8), (cy+py*radar.h/2-8), 16, 16, color_ascale(radar.dangerblipcolour,radar.alphascale) ) -- M-M-MONSTER DOT.
		end
			
			radar.bgcolor = Color(255,255,255,0)
			radar.fgcolor = Color(60,60,60,100)
			
			PulseRadar = true
			
			
 			
		end
		
		gspHUD_Radar_pulse(PulseRadar)
		
	end
end


function gspHUD_Radar_pulse(var)

	if ( var ) then

	-- Let's figure out the colour shift.
		local diff = {}
		diff.r = radar.dangercolour.r - radar.bgcolorbak.r
		diff.g = radar.dangercolour.g - radar.bgcolorbak.g
		diff.b = radar.dangercolour.b - radar.bgcolorbak.b

	
	-- Now let's throw sine at it and see what happens.	
		radar.bgcolor = Color( ((0.5*math.sin(CurTime()*2)+0.51)*diff.r), ((0.5*math.sin(CurTime()*2)+0.51)*diff.g), ((0.5*math.sin(CurTime()*2)+0.51)*diff.b), 255 ) -- 0.51... lol.
	

	-- Contrasting the crosshair thingy.
		radar.fgcolor = Color( 255-radar.bgcolor.r, 255-radar.bgcolor.g, 255-radar.bgcolor.b, 255 )
	
	
	-- Greying out the 'passive' blips.
		radar.player_color = Color(160,160,160,100)
	
	-- DEBUGGING WHAT
--		draw.DrawText(radar.bgcolor.r, "Default", ScrW() - 400, 300, color_ascale(radar.player_fontcolor,radar.alphascale), TEXT_ALIGN_CENTER)
--		draw.DrawText(radar.bgcolor.g, "Default", ScrW() - 400, 340, color_ascale(radar.player_fontcolor,radar.alphascale), TEXT_ALIGN_CENTER)
--		draw.DrawText(radar.bgcolor.b, "Default", ScrW() - 400, 380, color_ascale(radar.player_fontcolor,radar.alphascale), TEXT_ALIGN_CENTER)
		
--		draw.DrawText(diff.r, "Default", ScrW() - 300, 300, color_ascale(radar.player_fontcolor,radar.alphascale), TEXT_ALIGN_CENTER)
--		draw.DrawText(diff.g, "Default", ScrW() - 300, 340, color_ascale(radar.player_fontcolor,radar.alphascale), TEXT_ALIGN_CENTER)
--		draw.DrawText(diff.b, "Default", ScrW() - 300, 380, color_ascale(radar.player_fontcolor,radar.alphascale), TEXT_ALIGN_CENTER)
	
	else
		if ( radar.bgcolor ~= radar.bgcolorbak ) then

   		 	radar.bgcolor = radar.bgcolorbak
			radar.fgcolor = radar.fgcolorbak
			radar.player_color = radar.player_colorbak
	
		end
	
	end
end


function gspHUD_Radar_cc_radarvar_autocomplete ( command, args )
	argv = string.Explode(" ",string.sub(args,2))
	--Msg("Autocomplete args: '"..string.sub(args,2).."' argc: "..table.getn(argv).."\n")
	if (table.getn(argv)>1) then if (radar[argv[1]]~=nil) then return {command.." "..argv[1].." "..radar[argv[1]]} else return {} end end
	local ret = {}
	for k,v in pairs(radar) do
		table.insert(ret,command.." "..k)
	end
	return ret
end

function gspHUD_Radar_cc_radarvar ( pl, command, args )
	--Msg(type(args).."\n")
	--argv = string.Explode(" ",string.sub(args,2))
	if ( table.getn(args) < 1 ) then Msg(HUD_PRINTCONSOLE,"No var given!\n"); return end
	if ( radar[args[1]] == nil ) then Msg(HUD_PRINTCONSOLE,"Unknown radar var '"..args[1].."'!\n"); return end
	if ( table.getn(args) < 2 ) then Msg(HUD_PRINTCONSOLE,"No value given!\n"); return end
	radar[args[1]] = tonumber(args[2])
end

concommand.Add( "gsphud_radarvar", gspHUD_Radar_cc_radarvar, gspHUD_Radar_cc_radarvar_autocomplete )


hook.Add( "HUDPaint", "gspHUD_DrawRadar", gspHUD_DrawRadar )
