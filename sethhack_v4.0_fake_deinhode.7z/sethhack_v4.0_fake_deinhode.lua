/*
	welcom to da 4th version of bacon-- SETHHACK!
	coded by SETH!
	best hack in the world
	DONT MSS WITH SETH!!!
	rlly or i will fkn devnul ur ass
	also pls buy devull privat at seth@devnull.co.uk.cc.com.im.net.org
*/

local seth = "GOD"

local function isSethGod()
	if( seth != "GOD" ) then
		return "DEVULL"
	end
	return "ok welcome to sethhack v4, seth is god ok"
end

local print = MsgN
local MsgN = print // MSGN = MSGN... MAGIC!!! but its private method DONT STEAL

local function prt_isSethGod()
	print( isSethGod() )
end

local ur = "done"

local function askServer( msg )
	RunConsoleCommand( "say", msg )
end

local vars = {
	"triggabot",
	"autoshout",
	"aimnpc",
	"espplayer",
	"espentity",
	"bhop",
	"randomlymissshot",
}

local sh={}

local CreateConVar = CreateClientConVar
local CreateClientConVar = CreateConVar

local function ummCreateCvarsMAYBE()
	for k, v in pairs( vars ) do
		sh[v]=CreateClientConVar( "vip_sh_" .. v, 0, true, false )
	end
end

ummCreateCvarsMAYBE()

local deinhode_legit_config = {
	{ "triggabot", 1 },
	{ "autoshout", 0 },
	{ "aimnpc", 0 },
	{ "espplayer", 1 },
	{ "espentity", 0 },
	{ "bhop", 1 },
	{ "randomlymissshot", 1 },
}

local function loadLegitConfig()
	for k, v in pairs( deinhode_legit_config ) do
		if( sh[v[1]] ) then
			RunConsoleCommand( "vip_sh_" .. v[1], v[2] )
		end
	end
end

/*
	-________________________- SETH AIMBOT -________________________-
*/
local AIMBOT = false
local TAREGT = nil
local BESTPOS = 0

local eyeAng = Angle( 0, 0, 0 )

local function clear( ifer )
	if( ifer == "ON" ) then
		AIMBOT = true
		TAREGT = nil // NIL IS THE SAMETHING AS A NIGGER
		BESTPOS = 0
	else
		AIMBOT = false
		TAREGT = nil // NIL IS THE SAMETHING AS A NIGGER
		BESTPOS = 0
	end
end

local function findTarget()
	TAREGT = nil
	BESTPOS = 0
	for k, e in ipairs( ( sh['aimnpc']:GetBool() == true && ents.GetAll() || player.GetAll() ) ) do
		if( ( e:IsPlayer() && e:Alive() ) || ( e:IsNPC() && e:GetMoveType() != 0 ) ) then
			local dist = math.Dist( ScrW() / 2,ScrH() / 2, e:EyePos():ToScreen().x, e:EyePos():ToScreen().y )
			if( BESTPOS == 0 || dist <= BESTPOS || TAREGT == nil ) then
				TAREGT = e
				BESTPOS = dist
			end
		end
	end
	return TAREGT || nil
end

local function useVIP_Aimbot()
	local tar = findTarget()
	
	//=LocalPlayer():SetEyeAngles( LocalPlayer():EyePos() )
	
	if( tar && AIMBOT && tar != LocalPlayer() ) then
		local head = tar:GetBonePosition( tar:LookupBone( "ValveBiped.Bip01_Head1" ) )
		head = ( head - LocalPlayer():GetShootPos() ):Angle()
		LocalPlayer():SetEyeAngles( head )
		
		if( sh['autoshout']:GetBool() ) then
			RunConsoleCommand( "+attack" )W
			timer.Simple( 0.1, function() RunConsoleCommand( "-attack" ) end )
		end
	end
	
	if( sh['triggabot']:GetBool() ) then
		local e = LocalPlayer():GetEyeTrace().Entity
		if( e && ValidEntity( e ) && e:IsPlayer() && e != LocalPlayer()  ) then
			RunConsoleCommand( "+attack" )
			timer.Simple( 0.1, function() RunConsoleCommand( "-attack" ) end )
		end
	end
end
hook.Add( "Think", "VIP_SETHHACK_V4_AIMBOT_BY_SETH", useVIP_Aimbot )

concommand.Add( "+vip_sh_aim", function()
	AIMBOT = true
	TARGET = nil
end )

concommand.Add( "-vip_sh_aim", function()
	AIMBOT = false
	TARGET = nil
	BESTPOS = 0
end )

/*
	-________________________- SETH ESP -________________________-
*/
local function SETH______________ESP()
	local ply = LocalPlayer()
	for k, e in ipairs( ( sh['espentity']:GetBool() == true && ents.GetAll() || player.GetAll() ) ) do
		if( ValidEntity( e ) && ( ( e:IsPlayer() && e:Alive() ) || !e:IsPlayer() && e:GetMoveType() != 0 ) && e != LocalPlayer() ) then
			if( e:IsPlayer() && sh["espplayer"]:GetBool() == true || !e:IsPlayer() && ValidEntity( e ) ) then
				local pos = e:LocalToWorld( e:OBBCenter() ):ToScreen()
				surface.SetDrawColor( e:IsPlayer() && team.GetColor( e:Team() ) || color_white )
				surface.DrawOutlinedRect( pos.x - 25 / 2, pos.y - 25 / 2, 25, 25 )
				draw.SimpleText( e:IsPlayer() && e:Nick() || e:GetClass(), "Default", ( pos.x ), ( pos.y - 25 / 2 ) - 7, e:IsPlayer() && team.GetColor( e:Team() ) || color_white, 1, 1 )
			end
		end
	end
end
hook.Add( "HUDPaint", "SEHHEHEHEHEHEHHEHEH", SETH______________ESP )