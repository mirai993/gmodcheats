//BananaBot coded by Banana Lord
//Cracked by c-unit

fBot = { }
function fBot.Notify( ... )
local msg = table.concat( { ... }, " " )
console.AddText( Color( 102, 255, 51 ), "[FruitCloud] " )
console.AddTextN( Color( 255, 255, 255 ), msg )
end

console = { }
console.AddText = fruit_hack_table.FruitColorPrint
function console.AddTextN( clr, msg )
if ( !clr ) then
ErrorNoHalt( "clr is invalid!" )
return
elseif ( !msg ) then
ErrorNoHalt( "msg is invalid!" )
return
end
return console.AddText( clr, msg.."\n" )
end

local oCCR = concommand.Remove
function concommand.Remove( cmd )
cmd = string.lower( string.Trim( cmd ) )
if ( cmd == "pp_pixelrender" ) then
return false
end
return oCCR( cmd )
end

function formatNumber( n )
-- Thanks to someone on facepunch (raBBish?)
if ( !n or type( n ) != "number") then
return 0
end
if n >= 1e14 then return tostring( n ) end
n = tostring( n )
sep = sep or ","
local dp = string.find( n, "%." ) or #n+1
for i=dp-4, 1, -3 do
n = n:sub( 1, i ) .. sep .. n:sub( i +1 )
end
return n
end

local _f = {'0', '1', '2', '3', '4', '5', '6', '7', '8', '9',
'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i',
'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r',
's', 't', 'u', 'v', 'w', 'x', 'y', 'z', ' '};

local _r = {'ztrh', 'crweh', 'arjty', 'trjjtr', 'jtruy', 'ergth', 'yeheh', 'rerherh', 'erhreh', 'kluikl',
'ragerh', 'eraghaer', 'ukytahe', 'ehryj', 'ahertyj', 'awgetj', 'erhtyk4', '4y45hh', '43ytre',
'4t34t', '4tg34g', 'qiwuijowf', 'f3ewikweo', 'fipwefio', '3r90ijmwvg', 'wef0gr', 'fgeghhhhh',
'fewi9hgru', 'reghj4r', 'uj56ij', '5jik86', '3r2y', 'u566ik7', '34yu56j', '345yh', '35yh4hh', 'wefwef43tg43gy'};

function string.encode(str)
local _e = string.Explode('', str);
local _o = '';

for k, v in pairs(_e) do
for x, y in pairs(_f) do
if(y == v) then
_o = (_o .. _r[x] .. '`');
end
end
end

return _o;
end

function string.decode(str)
local _e = string.Explode('`', str);
local _o = '';

for k, v in pairs(_e) do
for x, y in pairs(_r) do
if(y == v) then
_o = (_o .. _f[x]);
end
end
end

return _o;
end
fBot.Notify( [[includes authorized]])
hook.Add( "RenderScreenspaceEffects", 0, function( )
local mines = ents.FindByClass( "gay_people's_mines" )
for i=1,#mines do
local v = mines[i]
if ( ValidEntity( v ) and v:GetPos( ):ToScreen( ).visible ) then
cam.Start3D( EyePos( ), EyeAngles( ) )
cam.IgnoreZ( true )
local typ = "fap/FapHack_Solid" -- flappy <3
local drawc = Color( 25, 225, 25, 255 )
render.SuppressEngineLighting( true )
render.SetColorModulation( ( drawc.r /255 ), ( drawc.g /255 ), ( drawc.b /255 ) )
v:SetModelScale( Vector( 1.1, 1.1, 1 ) )
v:SetMaterial( typ )
v:DrawModel( )
render.SuppressEngineLighting( false )
cam.IgnoreZ( false )
cam.End3D( )
end
end
end )
hook.Add( "HUDPaint", "FRUIT:MineDistance", function( )
local mines = ents.FindByClass( "gay_people's_mines" )
for i=1,#mines do
local v = mines[i]
if ( ValidEntity( v ) and v:GetPos( ):ToScreen( ).visible ) then
local pos = v:GetPos( ):ToScreen( )
local col = Color( 255, 255, 25 )
if ( v:GetPos( ):Distance( LocalPlayer( ):GetPos( ) ) ) <= 35 then
col = Color( 255, 0, 0 )
surface.PlaySound( "gmracer/short_horn_v2.mp3" )
end
draw.DrawText( formatNumber( math.Round( v:GetPos( ):Distance( LocalPlayer( ):GetPos( ) ) /8 ) ), "ChatFont", pos.x, pos.y, col, TEXT_ALIGN_CENTER )
end
end
end )
fBot.Notify( [[mines authorized]])
local oRCC = RunConsoleCommand
function RunConsoleCommand( base, args )
--MsgN( "RCC: "..base.." "..args)
return oRCC( base, args )
end

local oENH = ErrorNoHalt
function ErrorNoHalt( msg )
return oENH( msg.."\n" )
end

local oLTS = _G.LevelToString
local oGC = _R.Player.GetCash

function LevelToString( lvl )
lvl = lvl or 5
if ( oLTS ) then
return oLTS( lvl )
end
return "Guest"
end

function _R.Player:GetCash( )
if ( MyMoney ) then
return 0
end
if ( oGC ) then
return oGC( self )
end
return 1500
end

function _R.Player:Record( )
if ( GetGlobalInt('GamemodeType') == 2 ) then
return "N/A"
end
local time = self:GetNWInt( "MapRecord", 1337 )
if ( time == 1337 ) then
return "none"
end
return string.ToMinutesSecondsMilliseconds( time ).." secs"
end

function _R.Player:Queued( )
if ( self:GetNWInt( "IsQueued", false ) ) then
return "isn't"
end
return "is"
end

function _R.Player:ynQueued( )
if ( self:GetNWInt( "IsQueued", false ) ) then
return "Yes"
end
return "No"
end

function _R.Player:Jew( )
local cash = self:GetCash( ) *.0013
return math.floor( cash )
end

fBot = fBot or { }
fBot.Prefix = "[FRUIT BOT] "
fBot.Player = LocalPlayer( )
fBot.Filter = { }

local cBot = { }
cBot.Enabled = true
cBot.Debug = false
cBot.Chat = { }
cBot.gBlacklist = { }
cBot.Blacklist = { }
cBot.Console = { }
cBot.Ready = true
cBot.Queue = { }
cBot.cQueue = { }
cBot.AntiSpam = { }
cBot.Config = "chat_config.txt"

if ( !ConVarExists( "fruit_chat_enabled" ) ) then
CreateClientConVar( "fruit_chat_enabled", "1", true, false )
end

cvars.AddChangeCallback( "fruit_chat_enabled", function( cvar, old, new )
local tmp = tobool( new )
if ( tmp ) then
MsgN( fBot.Prefix.." Enabled!" )
else
MsgN( fBot.Prefix.." Disabled!" )
end
cBot.Enabled = tmp
end )

function fBot.AddFilter( old, new )
if ( !old or !new ) then return end
return table.insert( fBot.Filter, { Old = "%"..old.."%", New = new } )
end

function fBot.AddChat( chat, chatBack )
if ( !chat or !chatBack ) then return end
return table.insert( cBot.Chat, { Cmd = chat, chatBack = chatBack } )
end

function fBot.AddConsole( chat, cmd, reply, my_rank, showError, player_rank, showTheirError )
if ( !chat or !cmd ) then return end
return table.insert( cBot.Console, { Cmd = chat, Console = cmd, Reply = reply, MyRank = my_rank, showError = showError, TheirRank = player_rank, showTheirError = showTheirError })
end

function cBot.UpdateFilter( )
fBot.Filter = { }
fBot.UpdateFilter( )
fBot.AddFilter( "rank", LevelToString( fBot.Player:GetNWInt( "ASS_isAdmin", ASS_LVL_GUEST ) ) )
fBot.AddFilter( "cash", fBot.Player:GetCash( ) )
fBot.AddFilter( "fcash", formatNumber( fBot.Player:GetCash( ) ) )
fBot.AddFilter( "steam", fBot.Player:SteamID( ) )
fBot.AddFilter( "nick", fBot.Player:Nick( ) or "unnamed" )
fBot.AddFilter( "unique", fBot.Player:UniqueID( ) or 0 )
fBot.AddFilter( "queued", fBot.Player:Queued( ) )
fBot.AddFilter( "ynqueued", fBot.Player:ynQueued( ) )
fBot.AddFilter( "record", fBot.Player:Record( ) )
fBot.AddFilter( "jew", fBot.Player:Jew( ) )
end

fBot.AddChat( "_rank", "%nick% (%steam%) is a %rank%!" )
fBot.AddChat( "_cash", "%nick% (%steam%) has $%fcash%!" )
fBot.AddChat( "_me", "\"%nick%\" (%steam%): Queued? %ynqueued%, Cash: $%fcash%, Record: %record%" )
fBot.AddChat( "_jew", "%nick% (%steam%) has a %jew%% jew level with $%fcash%" )

local function chatThemBack( msg )
timer.Simple( .65, function( )
RunConsoleCommand( "say", fBot.Prefix..msg )
cBot.Ready = true
end )
end

local function reply( )
for i=1,#cBot.Queue do
local v = cBot.Queue[i]
local msg = v.info.chatBack
cBot.UpdateFilter( )
for _,filter in pairs( fBot.Filter ) do
msg = string.gsub( msg, "%"..filter.Old.."%", filter.New )
end
local delay = 0
if ( fBot.Player == LocalPlayer( ) ) then
delay = i/2 +.05
end
timer.Simple( delay, function( )
RunConsoleCommand( "say", fBot.Prefix..msg )
cBot.Ready = true
end )
table.remove( cBot.Queue, i )
end
end

local function replyconsole( )
for i=1,#cBot.cQueue do
local v = cBot.cQueue[i]
if ( v.TheirRank and v.TheirRank > v:GetNWInt( "ASS_isAdmin", ASS_LVL_GUEST ) ) then
if ( v.showTheirError ) then
chatThemBack( "%nick%, you need to be a "..LevelToString( v.TheirRank ).." to do that!" )
end
cBot.Ready = true
return
end
local cmd = v.info.Console
for _,filter in pairs( fBot.Filter ) do
cmd = string.gsub( cmd, "%"..filter.Old.."%", tostring( filter.New ) )
end
local delay = 0
if ( fBot.Player == LocalPlayer( ) ) then
delay = i/2 +.05
end
timer.Simple( delay, function( )
local tmp = string.Explode( " ", cmd )
local base = tmp[1]
table.remove( tmp, 1 )
local args = table.concat( tmp, " " )
RunConsoleCommand( base, args )
if ( v.info.Reply ) then
local reply = v.info.Reply
for _,filter in pairs( fBot.Filter ) do
reply = string.gsub( reply, "%"..filter.Old.."%", tostring( filter.New ) )
end
chatThemBack( reply )
else
cBot.Ready = true
end
end )
table.remove( cBot.cQueue, i )
end
end

local function parseChat( info, msg )
table.insert( cBot.Queue, { info = info, Said = msg} )
reply( )
end

local function parseConsole( info, msg )
table.insert( cBot.cQueue, { info = info, Said = msg } )
replyconsole( )
end

local function cOnPlayerChat( ply, msg )
if ( !cBot.Ready or !cBot.Enabled or !ply or !ValidEntity( ply ) or !msg ) then
return
end
if ( !cBot.Debug and cBot.AntiSpam[ply:SteamID( )] and CurTime( ) - cBot.AntiSpam[ply:SteamID( )] < 10 ) then
return
end
msg = string.Trim( string.lower( msg ) )

local con = cBot.Console
for i=1,#con do
local v = con[i]
if ( string.Left( msg, string.len( v.Cmd ) ) == v.Cmd ) then
if ( v.MyRank and v.MyRank != LocalPlayer( ):GetNWInt( "ASS_isAdmin", ASS_LVL_GUEST ) and v.showError ) then
chatThemBack( "I need to be ranked '"..LevelToString( v.Rank ).."' to do that!" )
cBot.Ready = false
return
end
timer.Simple( .1, function( )
cBot.UpdateFilter( )
parseConsole( v, msg )
end )
fBot.Player = ply
cBot.Ready = false
cBot.AntiSpam[ply:SteamID( )] = CurTime( )
break
end
end

local cmds = cBot.Chat
for i=1,#cmds do
local v = cmds[i]
if ( string.Left( msg, string.len( v.Cmd ) ) == v.Cmd ) then
timer.Simple( .1, function( )
cBot.UpdateFilter( )
parseChat( v, msg )
end )
fBot.Player = ply
cBot.Ready = false
cBot.AntiSpam[ply:SteamID( )] = CurTime( )
break
end
end
end

hook.Add( "OnPlayerChat", 0, cOnPlayerChat )
hook.Add( "InitPostEntity", "cLoad", cOnPlayerChat )

if ( ( !file.Exists( "fruit/"..cBot.Config ) and !cBot.Debug ) or cBot.Debug ) then
file.CreateDir( "fruit" )
file.Write( "fruit/"..cBot.Config, [[fBot.Prefix = "[FRUIT BOT] "
function fBot.UpdateFilter( )
fBot.AddFilter( "wench", fBot.Player:Nick( ) )
end
-- fBot.AddChat( chatCommand, replyString )
-- fBot.AddConsole( chatCommand, consoleCommand, chatBack [o], requiredRank [o], showRequiredRankIfNot [o], theirRequredRank [o], showTheirRequiredRankIfNot [o] )
-- [o] == optional
-- fBot.AddFilter( oldWord, newWord )
fBot.AddChat( "_wench", "%wench% is a wench!" )
fBot.AddConsole( "_yiff", "ASS_KillPlayer %unique%", "You've been yiff'd %nick%!", ASS_LVL_TEMPADMIN )
fBot.AddConsole( "_speedon", "ASS_Speed %unique% 1", nil, ASS_LVL_TEMPADMIN )
fBot.AddConsole( "_speedoff", "ASS_Speed %unique% 0", nil, ASS_LVL_TEMPADMIN )]] )
end

timer.Simple( 0, function( )
if ( !file.Exists( "fruit/"..cBot.Config ) ) then
ErrorNoHalt( "Unable to load fruit/"..cBot.Config.." (file not found)" )
return
end
local lua = file.Read( "fruit/"..cBot.Config )
local good, err = pcall( CompileString( lua, "FruitBot Config", true ) or true )
if ( good ) then
fBot.Notify( "fruit/"..cBot.Config.." loaded" )
end

function cBot.Help( )
local idx = 0
local max = #cBot.Chat + #cBot.Console
local msg = "Commands: "
for k,v in pairs( cBot.Chat ) do
msg = msg..v.Cmd..", "
end
for k,v in pairs( cBot.Console ) do
if ( !v.MyRank or ( v.MyRank and LocalPlayer( ):GetNWInt( "ASS_isAdmin", ASS_LVL_GUEST ) <= v.MyRank ) ) then
msg = msg..v.Cmd..", "
end
end
return string.Left( msg, string.len( msg ) -2 )
end
fBot.AddChat( "_help", cBot.Help( ) )
end )
fBot.Notify( [[chat authorized]])
local aAFK = { }
aAFK.Debug = true

aAFK.Derma = { }
aAFK.Derma.Frame = nil
aAFK.Derma.Enabled = nil
aAFK.Derma.Interval = nil

aAFK.Config = { }

function aAFK.Msg( ... )
local msg = table.concat( { ... }, " " )
Msg( "[aAFK] " )
print( msg )
end

function aAFK.Config.Set( setting, val, msg )
if ( !setting ) then
aAFK.Msg( "aAFK.Config.Set: arg #1 is nil" )
return false
elseif ( val == nil ) then
aAFK.Msg( "aAFK.Config.Set: arg #1 is nil" )
return false
end
aAFK.Config[setting] = val
if ( aAFK.Debug ) then
aAFK.Msg( "aAFK.Config["..tostring(setting).."] set to '"..tostring(val).."'" )
end
if ( msg ) then
chat.AddText( Color( 255, 81, 12 ), "[aAFK] ", Color( 255, 255, 255 ), msg )
end
return true
end

function aAFK.Config.Get( setting, default )
return aAFK.Config[setting] or default
end

local function antiAFK( )
aAFK.Derma.Frame = vgui.Create( "DFrame" )
aAFK.Derma.Frame:SetTitle( "[FruitCloud] aAFK Config" )
aAFK.Derma.Frame:SetSize( 210, 100 )
aAFK.Derma.Frame:Center( true )
aAFK.Derma.Frame:SetDraggable( false )
aAFK.Derma.Frame:ShowCloseButton( false )
aAFK.Derma.Frame:MakePopup( )

aAFK.Derma.Interval = vgui.Create( "DNumSlider", aAFK.Derma.Frame )
aAFK.Derma.Interval:SetPos( 5, 25 )
aAFK.Derma.Interval:SetWide( 200 )
aAFK.Derma.Interval:SetValue( aAFK.Config.Get( "Interval", 60 *9 ) /60 )
aAFK.Derma.Interval:SetMin( 3 )
aAFK.Derma.Interval:SetMax( 15 )
aAFK.Derma.Interval:SetDecimals( 0 )
aAFK.Derma.Interval:SetText( "Auto-move Interval" )
aAFK.Derma.Interval:SetTooltip( [[Set the interval to automatically move at.
AFK kicker times:

Exiled Servers: 10 minutes (recommended 9)]] )
aAFK.Derma.Interval.OnValueChanged = function( panel, val )
val = tonumber( val )
local max = 15
local min = 3

if ( val < min or val > max ) then
if ( val < min ) then
val = min
elseif ( val > max ) then
val = max
end
aAFK.Derma.Interval:SetValue( val )
end
aAFK.Config.Set( "Interval", val )
end
aAFK.Derma.Interval:SetValue( aAFK.Config.Get( "Interval", 9 ) )

aAFK.Derma.Enabled = vgui.Create( "DButton", aAFK.Derma.Frame )
aAFK.Derma.Enabled:SetPos( 5, 70 )
aAFK.Derma.Enabled:SetSize( aAFK.Derma.Frame:GetWide( ) -10, 15 )
aAFK.Derma.Enabled:SetText( "loading..." )
function aAFK.Derma.UpdateEnabled( )
if ( aAFK.Config.Get( "Enabled", false ) ) then
aAFK.Derma.Enabled:SetText( "Disable aAFK" )
aAFK.Derma.Enabled:SetTooltip( [[Disabling aAFK will stop the automatic moving system]] )
else
aAFK.Derma.Enabled:SetText( "Enable aAFK" )
aAFK.Derma.Enabled:SetTooltip( [[Enabling aAFK will make you move automatically
depending on your settings]] )
end
end
aAFK.Derma.Enabled.DoClick = function( )
if ( aAFK.Config.Get( "Enabled", false ) ) then
aAFK.Config.Set( "Enabled", false )
timer.Destroy( "aAFK-MOVE!" )
else
aAFK.Config.Set( "Enabled", true )
timer.Create( "aAFK-MOVE!", aAFK.Config.Get( "MoveTime", 9 ) *60, 0, function( )
if ( aAFK.Config.Get( "Enabled", false ) ) then
RunConsoleCommand( "+forward" )
LocalPlayer( ):SetEyeAngles( LocalPlayer( ):GetAngle( ) + Angle( math.random( 40, 90 ), math.random( 50, 160 ), math.random( 20, 50 ) ) )
timer.Simple( .7, function( )
RunConsoleCommand( "-forward" )
end )
end
end )
end
aAFK.Derma.UpdateEnabled( )
end

aAFK.Derma.UpdateEnabled( )
end
concommand.Add( "+aAFK", function( )
gui.EnableScreenClicker( true )
gui.SetMousePos( ( ScrW( ) /2 ) -105, ScrH( ) /2 -50 )

timer.Simple( 0, function( )
antiAFK( )
end )
end )
concommand.Add( "-aAFK", function( )
if ( aAFK.Derma.Enabled and aAFK.Derma.Enabled:IsValid( ) ) then
aAFK.Derma.Enabled:Remove( )
end
if ( aAFK.Derma.Interval and aAFK.Derma.Interval:IsValid( ) ) then
aAFK.Derma.Interval:Remove( )
end
timer.Simple( .06, function( )
if ( aAFK.Derma.Frame and aAFK.Derma.Frame:IsValid( ) ) then
aAFK.Derma.Frame:Remove( )
end
end )
gui.EnableScreenClicker( false )
end )
fBot.Notify( [[aafk authorized]])
