// hvh is aids

/*
	[S]kid[S]corcher
	Version: 4.5 private
	Credits:
		kalis0x - basically the entire cheat
		Nanocat - walkbot
		Razor - ASUS walls, aaa help, autostrafe
*/

require("bsendpacket")
require("dickwrap")
require("mega")

surface.CreateFont("wireless gamer", {font = "Open Sans MS", size = 45})
surface.CreateFont("visual gamer", {font = "Courier New", size = 15, weight = 500, outline = true})
surface.CreateFont("gamer title", {font = "Trebuchet", size = 18, weight = 650})
surface.CreateFont("gamer tab", {font = "Trebuchet", size = 16, weight = 550})
local me = LocalPlayer()
ok = {}
ok.rang = {}
ok.cvars = {}
ok.ys = GetConVarNumber("m_yaw")
ok.aat = nil
ok.aas = false
ok.atk = false
ok.ld = false
ok.gd = false
ok.hm = 0
ok.dc = 0
ok.ct = 0
ok.flt = 0
ok.fltm = 0
ok.er = 0
ok.eg = 0
ok.eb = 0
ok.fa = nil
ok.sp = nil
ok.ep = nil
ok.atl = 0

function ok.Log(...)
	MsgC(Color(5, 130, 255), "[SkidScorcher] ", Color(255, 190, 5), ...)
	MsgN("")
end

ok.Log("Loading...")

function ok.CreateConsoleVar(name, default)
	local ret = CreateClientConVar(name, default)
	ok.cvars[name] = tostring(default)
	ok.Log("Created convar: ", Color(255, 120, 5), name, Color(255, 0, 0), " (default: " .. tostring(default) .. ", value: ", ret:GetString(), ")")
	return ret
end

ok.vars = {
	aimbot = {
		enabled = ok.CreateConsoleVar("ok_aimbot", 1),
		point = ok.CreateConsoleVar("ok_aimbot_point", 0.5),
		multipoint = ok.CreateConsoleVar("ok_aimbot_multipoint", 1),
		mpmode = ok.CreateConsoleVar("ok_aimbot_multipoint_mode", 1),
		autowall = ok.CreateConsoleVar("ok_aimbot_autowall", 0),
		silent = ok.CreateConsoleVar("ok_aimbot_silent", 1),
		nospread = ok.CreateConsoleVar("ok_aimbot_nospread", 1),
		bodyaim = ok.CreateConsoleVar("ok_aimbot_body", 0),
		static = ok.CreateConsoleVar("ok_aimbot_staticaa", 1),
		nextshot = ok.CreateConsoleVar("ok_aimbot_nextshot", 1),
		autoshoot = ok.CreateConsoleVar("ok_aimbot_autoshoot", 1),
		team = ok.CreateConsoleVar("ok_aimbot_ignoreteam", 1),
		friends = ok.CreateConsoleVar("ok_aimbot_ignorefriends", 0)
	},

	visuals = {
		esp = ok.CreateConsoleVar("ok_visuals_esp", 1),
		name = ok.CreateConsoleVar("ok_visuals_esp_name", 1),
		box = ok.CreateConsoleVar("ok_visuals_esp_box", 1),
		weapon = ok.CreateConsoleVar("ok_visuals_esp_weapon", 1),
		rank = ok.CreateConsoleVar("ok_visuals_esp_rank", 1),
		angles = ok.CreateConsoleVar("ok_visuals_esp_angles", 1),
		health = ok.CreateConsoleVar("ok_visuals_esp_health", 1),
		snapline = ok.CreateConsoleVar("ok_visuals_snapline", 1),
		chams = ok.CreateConsoleVar("ok_visuals_chams", 1),
		wepchams = ok.CreateConsoleVar("ok_visuals_wepchams", 1),
		watermark = ok.CreateConsoleVar("ok_visuals_watermark", 1),
		fullbright = ok.CreateConsoleVar("ok_visuals_fullbright", 1),
		asus = ok.CreateConsoleVar("ok_visuals_asuswalls", 1),
		viewmodel = ok.CreateConsoleVar("ok_visuals_viewmodel", 1),
		fov = ok.CreateConsoleVar("ok_visuals_fov", 90)
	},

	misc = {
		autohop = ok.CreateConsoleVar("ok_misc_autohop", 1),
		highjump = ok.CreateConsoleVar("ok_misc_highjump", 0),
		thirdperson = ok.CreateConsoleVar("ok_thirdperson", 1),
		killspam = ok.CreateConsoleVar("ok_misc_killspam", 0),
		ksmode = ok.CreateConsoleVar("ok_misc_killspam_mode", 1),
		robo = ok.CreateConsoleVar("ok_misc_killspam_robo", 1),
		autostrafe = ok.CreateConsoleVar("ok_misc_autostrafe", 1),
		autogain = ok.CreateConsoleVar("ok_misc_autostrafe_gain", 1),
		autogainmin = ok.CreateConsoleVar("ok_misc_autostrafe_gain_min", 1.25),
		autogainmax = ok.CreateConsoleVar("ok_misc_autostrafe_gain_max", 5.25),
		autogainmult = ok.CreateConsoleVar("ok_misc_autostrafe_gain_velmult", 0.01),
		autogainkey = ok.CreateConsoleVar("ok_misc_autostrafe_gain_key", "f"),
		walkbot = ok.CreateConsoleVar("ok_misc_walkbot", 0),
		walkbotrec = ok.CreateConsoleVar("ok_misc_walkbot_rec", 0),
		robobitch = ok.CreateConsoleVar("ok_misc_robot", 0)
	},

	hvh = {
		antiaim = ok.CreateConsoleVar("ok_hvh_antiaim", 1),
		spinbot = ok.CreateConsoleVar("ok_hvh_aa_spin", 0),
		spinspeed = ok.CreateConsoleVar("ok_hvh_aa_spin_speed", 8),
		edge = ok.CreateConsoleVar("ok_hvh_aa_edge", 1),
		edgemet = ok.CreateConsoleVar("ok_hvh_aa_edge_met", 1),
		adaptive = ok.CreateConsoleVar("ok_hvh_aa_adaptive", 1),
		adapyaw = ok.CreateConsoleVar("ok_hvh_adap_yaw", 450),
		adapmax = ok.CreateConsoleVar("ok_hvh_adap_max", 15),
		adapspeed = ok.CreateConsoleVar("ok_hvh_adap_speed", 1),
		fakeangles = ok.CreateConsoleVar("ok_hvh_aa_fakeangles", 0),
		pitch = ok.CreateConsoleVar("ok_hvh_aa_pitch", -91),
		pitchrand = ok.CreateConsoleVar("ok_hvh_aa_pitch_addrand", 1),
		pitchrandmin = ok.CreateConsoleVar("ok_hvh_aa_pitch_rand_min", -3),
		pitchrandmax = ok.CreateConsoleVar("ok_hvh_aa_pitch_rand_max", 3),
		yaw = ok.CreateConsoleVar("ok_hvh_aa_yaw", -541),
		roll = ok.CreateConsoleVar("ok_hvh_aa_roll", 0),
		fakelag = ok.CreateConsoleVar("ok_hvh_fakelag", 0),
		flchoke = ok.CreateConsoleVar("ok_hvh_fl_choke", 9),
		flsend = ok.CreateConsoleVar("ok_hvh_fl_send", 4),
		aaa = ok.CreateConsoleVar("ok_hvh_antiaa", 1)
	}
}

ok.pitches = {
	["-89"] = {
		-1.05,
	},

	["89"] = {
		-5.00,
		1.05,
	}
}

ok.cones = {}

function ok.GetCone(wep)
	local cone = 0
	if !wep then return nil end
	if wep.Cone then cone = wep.Cone end
	if wep.Primary and wep.Primary.Cone then cone = wep.Primary.Cone end
	if wep.Secondary and wep.Secondary.Cone then cone = wep.Secondary.Cone end
	if cone != 0 then return Vector(-cone, -cone, -cone) end
	return nil
end

function ok.Compensate(cmd, ang)
	local wep = me:GetActiveWeapon()
	if !IsValid(wep) then return ang end
	local cone = ok.cones[wep:GetClass()]
	if !cone then return ang end
	return (ok.vars["aimbot"]["nospread"]:GetBool() and dickwrap.Predict(cmd, ang:Forward(), cone):Angle()) or ang
end

ok.pti = 0

function ok.SetTickInterval()
	local interp = GetConVar("cl_interp"):GetFloat()
	local ratio = GetConVar("cl_interp_ratio"):GetFloat()
	local updaterate = GetConVar("cl_updaterate"):GetFloat()
	local interpolation = math.max(interp, ratio / updaterate)
	ok.pti = engine.TickInterval() * interpolation
end

function ok.CheckVis(ent)
	local bodyaim = ok.vars["aimbot"]["bodyaim"]:GetBool()
	local sp = me:GetShootPos()
	local ep
	local bone, ang, min, max
	if bodyaim then
		bone, ang = ent:GetBonePosition(ent:GetHitBoxBone(15, 0))
		min, max = ent:GetHitBoxBounds(15, 0)
		min:Rotate(ang)
		max:Rotate(ang)
		ep = bone + ((min + max) * ok.vars["aimbot"]["point"]:GetFloat())
	else
		bone, ang = ent:GetBonePosition(ent:GetHitBoxBone(0, 0))
		min, max = ent:GetHitBoxBounds(0, 0)
		min:Rotate(ang)
		max:Rotate(ang)
		ep = bone + ((min + max) * ok.vars["aimbot"]["point"]:GetFloat())
	end

	local evel = ent:GetVelocity()
	local mevel = me:GetVelocity()
	local ti = engine.TickInterval()
	local rft = RealFrameTime()
	ep = ep + ((evel * ti * rft) - (mevel * ti * rft))
	local tdata = {
		start = sp,
		endpos = ep,
		filter = {ent, me},
		mask = MASK_SHOT
	}

	local trace = util.TraceLine(tdata)
	if trace.Fraction != 1 and ok.vars["aimbot"]["multipoint"]:GetBool() then
		local mode = ok.vars["aimbot"]["mpmode"]:GetInt()
		if mode == 1 then // corners
			local tests = {
				Vector(min.x, min.y, min.z),
				Vector(min.x, max.y, min.z),
				Vector(max.x, max.y, min.z),
				Vector(max.x, min.y, min.z),
				Vector(min.x, min.y, max.z),
				Vector(min.x, max.y, max.z),
				Vector(max.x, max.y, max.z),
				Vector(max.x, min.y, max.z)
			}

			for i = 1, #tests do
				ep = bone + tests[i]
				ep = ep + ((evel * ti * rft) - (mevel * ti * rft))
				tdata.endpos = ep
				trace = util.TraceLine(tdata)
				if trace.Fraction == 1 then
					return true, sp, ep
				end
			end
		else // hitscan
			local group = 0
			for hitbox = 0, ent:GetHitBoxCount(group) - 1 do
				bone, ang = ent:GetBonePosition(ent:GetHitBoxBone(hitbox, group))
				min, max = ent:GetHitBoxBounds(hitbox, group)
				min:Rotate(ang)
				max:Rotate(ang)
				ep = bone + ((min + max) * 0.5)
				ep = ep + ((evel * ti * rft) - (mevel * ti * rft))
				tdata.endpos = ep
				trace = util.TraceLine(tdata)
				if trace.Fraction == 1 then
					return true, sp, ep
				end
			end
		end
	end

	return trace.Fraction == 1, sp, ep
end

function ok.CanWallbang(sp, ep, ent)
    local tdata = {
    	start = sp,
    	endpos = ep,
    	filter = {ent, me},
    	mask = 1577075107
    }

    local wall = util.TraceLine(tdata)
    tdata.start = ep 
    tdata.endpos = sp
    local wall2 = util.TraceLine(tdata)
    if 17.49 > (wall2.HitPos - wall.HitPos):Length2D() then
    	return true
    else
    	return false
    end
end

function ok.GetTarget()
	local vis
	ok.sp, ok.ep, ok.aat = nil, nil, nil

	for k,v in next, player.GetAll() do
		if !ok.vars["aimbot"]["enabled"]:GetBool() or !v or !v:IsPlayer() or 0 >= v:Health() or v:IsDormant() or v == me then continue end
		if ok.vars["aimbot"]["team"]:GetBool() and v:Team() == me:Team() then continue end
		if ok.vars["aimbot"]["friends"]:GetBool() and v:GetFriendStatus() == "friend" then continue end
		local sp, ep
		vis, sp, ep = ok.CheckVis(v)
		ok.aat = v
		if vis or (ok.vars["aimbot"]["autowall"]:GetBool() and ok.CanWallbang(sp, ep, v)) then ok.sp = sp ok.ep = ep break else continue end
	end
end

function ok.DoSilent(cmd)
	if !ok.fa then ok.fa = cmd:GetViewAngles() end
	ok.fa = ok.fa + Angle(cmd:GetMouseY() * ok.ys, cmd:GetMouseX() * -ok.ys, 0)
	ok.fa.p = math.Clamp(ok.fa.p, -89, 89)
	ok.fa.y = math.NormalizeAngle(ok.fa.y)
end

function ok.FixMove(cmd, ang)
	local angs = cmd:GetViewAngles()
	local fa = ok.fa
	if ang then
		fa = ang
	end

	local viewang = Angle(0, angs.y, 0)
	local fix = Vector(cmd:GetForwardMove(), cmd:GetSideMove(), 0)
	fix = (fix:Angle() + (viewang - fa)):Forward() * fix:Length()
	
	if angs.p > 90 or angs.p < -90 then
		fix.x = -fix.x
	end
	
	cmd:SetForwardMove(fix.x)
	cmd:SetSideMove(fix.y)
end

function ok.GetCurTime()
	if IsFirstTimePredicted() then
		ok.ct = CurTime() + engine.TickInterval()
	end
end

function ok.CanFire(nextshot)
	if !nextshot then return true end
	if !ok.ct or ok.ct == 0 then return false end
	local wep = me:GetActiveWeapon() or NULL
	if !IsValid(wep) then return false end
	return wep:GetActivity() != ACT_RELOAD and ok.ct > wep:GetNextPrimaryFire()
end

ok.as_max = 10^4
ok.as_l = 400

function ok.AutoHop(cmd)
	if !ok.vars["misc"]["autohop"]:GetBool() or cmd:CommandNumber() == 0 then return end
	local autostrafe = ok.vars["misc"]["autostrafe"]:GetBool()
	if me:IsOnGround() and cmd:KeyDown(IN_JUMP) then
		cmd:SetButtons(bit.bor(cmd:GetButtons(), IN_JUMP))
		if autostrafe then
			cmd:SetForwardMove(ok.as_max)
		end
	else
		if autostrafe and cmd:KeyDown(IN_JUMP) then
			local mousex = cmd:GetMouseX()
			if -1 > mousex or mousex > 1 then
				cmd:SetSideMove((mousex > 0) and 400 or -400)
			else
				cmd:SetForwardMove(5850 / me:GetVelocity():Length2D())
				cmd:SetSideMove((cmd:CommandNumber() % 2 == 0) and ok.as_l or -ok.as_l)
			end
		end

		cmd:RemoveKey(IN_JUMP)
	end
end

function ok.Aimbot(cmd)
	local autoshoot = ok.vars["aimbot"]["autoshoot"]:GetBool()
	local nextshot = ok.vars["aimbot"]["nextshot"]:GetBool()
	local silent = ok.vars["aimbot"]["silent"]:GetBool()
	local fakelag = ok.vars["hvh"]["fakelag"]:GetBool()
	local antiaim = ok.vars["hvh"]["antiaim"]:GetBool()
	local static = ok.vars["aimbot"]["static"]:GetBool()
	ok.DoSilent(cmd)
	if cmd:CommandNumber() == 0 and !ok.vars["misc"]["thirdperson"]:GetBool() and (silent or antiaim or ok.vars["misc"]["walkbot"]:GetBool()) then cmd:SetViewAngles(ok.fa) return end

	if !fakelag then
		bSendPacket = true
	end

	if ok.sp and ok.ep then
		local aafix = false
		local ap = ok.Compensate(cmd, (ok.ep - ok.sp):Angle())
		ap.p, ap.y = math.NormalizeAngle(ap.p), math.NormalizeAngle(ap.y)
		if ok.CanFire(nextshot) and (autoshoot or cmd:KeyDown(IN_ATTACK)) then
			if static then
				aafix = true
				ap.p = -ap.p - 540
				ap.y = ap.y + 180
			end
			
			cmd:SetViewAngles(ap)
			if autoshoot then
				if nextshot then
					cmd:SetButtons(bit.bor(cmd:GetButtons(), IN_ATTACK))
				else
					if ok.atk then
						cmd:SetButtons(bit.bor(cmd:GetButtons(), IN_ATTACK))
					else
						cmd:RemoveKey(IN_ATTACK)
					end

					ok.atk = !ok.atk
				end
			end

			if silent then
				ok.FixMove(cmd)
			end

			if !fakelag then
				bSendPacket = false
			end
		else
			if autoshoot and nextshoot then
				cmd:RemoveKey(IN_ATTACK)
			end

			if antiaim then
				ok.AntiAim(cmd, true)
			elseif silent then
				cmd:SetViewAngles(ok.fa)
			end

			if !fakelag then
				bSendPacket = true
			end
		end

		return
	end

	if antiaim or silent or ok.vars["misc"]["walkbot"]:GetBool() then
		cmd:SetViewAngles(ok.fa)
	end
end

ok.aa_as = false
ok.paa_s = 0
ok.paa_m = 15
ok.aa_a = 0
ok.as_y = 0
ok.sb_c = 0

function ok.AntiAim(cmd, force)
	if cmd:CommandNumber() == 0 and !ok.vars["misc"]["thirdperson"]:GetBool() then return end
	if me:GetActiveWeapon() != NULL and me:GetActiveWeapon():GetClass():lower():find("knife") or 0 >= me:Health() then return end
	if !force and (ok.sp != nil or ok.ep != nil) then return end
	if !force and cmd:KeyDown(IN_ATTACK) then
		if ok.vars["aimbot"]["static"]:GetBool() then
			cmd:SetViewAngles(Angle(-ok.fa.p - 180, ok.fa.y + 180, 0))
			ok.FixMove(cmd)
		end

		return
	end

	if ok.vars["hvh"]["antiaim"]:GetBool() then
		local fakeangles = ok.vars["hvh"]["fakeangles"]:GetBool()
		local pitch = ok.vars["hvh"]["pitch"]:GetFloat() or 262
		if ok.vars["hvh"]["pitchrand"]:GetBool() then
			pitch = pitch + math.random(ok.vars["hvh"]["pitchrandmin"]:GetFloat(), ok.vars["hvh"]["pitchrandmax"]:GetFloat())
		end

		local yaw = ok.vars["hvh"]["yaw"]:GetFloat() or 450
		local roll = ok.vars["hvh"]["roll"]:GetFloat() or 0

		if ok.vars["hvh"]["adaptive"]:GetBool() then
			local adapmax = ok.vars["hvh"]["adapmax"]:GetInt()
			local adapspeed = ok.vars["hvh"]["adapspeed"]:GetInt()
			if ok.aa_a >= adapmax then
				ok.aa_a = adapmax
				ok.aa_as = false
			elseif -adapmax >= ok.aa_a then
				ok.aa_a = -adapmax
				ok.aa_as = true
			end

			if ok.aa_as then
				ok.aa_a = ok.aa_a + adapspeed
			else
				ok.aa_a = ok.aa_a - adapspeed
			end

			local adapyaw = ok.vars["hvh"]["adapyaw"]:GetFloat()
			local aay = (ok.aat and ok.aat != NULL) and ((ok.aat:GetPos() + ok.aat:OBBCenter()) - me:GetShootPos()):Angle().y or 0
			aay = aay + math.Rand(0.03, 0.08)
			if !fakeangles then
				cmd:SetViewAngles(Angle(pitch, aay + adapyaw + ok.aa_a, roll))
			else
				if bSendPacket then
					cmd:SetViewAngles(Angle(pitch, aay + adapyaw, roll))
				else
					cmd:SetViewAngles(Angle(pitch, aay + adapyaw - 90, roll))
				end
			end
		elseif ok.vars["hvh"]["spinbot"]:GetBool() then
			local speed = ok.vars["hvh"]["spinspeed"]:GetFloat()
			ok.sb_c = ok.sb_c + speed
			if ok.sb_c >= 360 then
				ok.sb_c = 0
			end

			cmd:SetViewAngles(Angle(pitch, math.NormalizeAngle(ok.sb_c), roll))
		else
			if ok.paa_s > ok.paa_m then
				cmd:SetViewAngles(Angle(-math.random(1, 89) - 180, yaw - 360 + math.Rand(0, 2), roll))
			else
				cmd:SetViewAngles(Angle(-math.random(1, 89) - 180, yaw + 450 + math.Rand(0, 2), roll))
			end

			ok.paa_s = ok.paa_s + 1
			if ok.paa_s >= (ok.paa_m * 2 + 1) then
				ok.paa_s = 0
			end
		end

		if ok.vars["hvh"]["edge"]:GetBool() then
			local setp = false
			local edge = false
			local ang = Angle(0, 0, 0)
			local eyepos = me:GetShootPos() - Vector(0, 0, 5)

			for y = 1, 8 do
				local tmp = Angle(0, y * 45, 0)
				local forward = tmp:Forward()
				forward = forward * 35

				local tdata
				local _filter = {}
				for k,v in next, player.GetAll() do
					_filter[k] = v
				end

				tdata = {start = eyepos, endpos = eyepos + forward, filter = _filter, mask = MASK_SOLID}
				local trace = util.TraceLine(tdata)
			
				if trace.Fraction != 1 then
					local negate = trace.HitNormal * -1
					tmp.y = negate:Angle().y
					
					local left = (tmp + Angle(0, 11.25, 0)):Forward() * 17.5
					local right = (tmp - Angle(0, 11.25, 0)):Forward() * 17.5
					tdata = {start = eyepos, endpos = eyepos + left, filter = _filter, mask = MASK_SOLID}
					local lt = util.TraceLine(tdata)
					tdata = {start = eyepos, endpos = eyepos + right, filter = _filter, mask = MASK_SOLID}
					local rt = util.TraceLine(tdata)
					local ltw = lt.Fraction == 1
					local rtw = rt.Fraction == 1

					local edgem = ok.vars["hvh"]["edgemet"]:GetInt()
					if edgem == 1 then
						if ltw or rtw then
							tmp.y = tmp.y + 180
						end

						ang.y = 270 - tmp.y + 360
					elseif edgem == 2 or edgem == 3 then
						ang.y = tmp.y + (edgem == 2 and 180 or 360)
					elseif edgem == 4 then
						if ltw or rtw then
							tmp.y = tmp.y + 180
						end

						ang.y = 270 - tmp.y + math.random(-15, 15) + math.Rand(0.03, 0.08)
					end

					edge = true
					break
				end
			end

			if edge then
				if !fakeangles then
					cmd:SetViewAngles(Angle(ang.p != 0 and ang.p or pitch, ang.y, roll))
				else
					if bSendPacket then
						cmd:SetViewAngles(Angle(ang.p != 0 and ang.p or pitch, ang.y, roll))
					else
						cmd:SetViewAngles(Angle(pitch, ang.y - 90, roll))
					end
				end
			end
		end

		pitch = cmd:GetViewAngles().p
		ok.aas = !ok.aas
		ok.FixMove(cmd)
	end
end

function ok.FakeLag(cmd)
	if cmd:CommandNumber() == 0 then return end
	local choke = ok.vars["hvh"]["flchoke"]:GetInt()
	local send = ok.vars["hvh"]["flsend"]:GetInt()
	ok.fltm = choke + send

	if ok.vars["hvh"]["fakelag"]:GetBool() then
		ok.flt = ok.flt + 1
		
		if ok.flt > ok.fltm then
			ok.flt = 1
		end

		if send >= ok.flt then
			bSendPacket = true
		else
			bSendPacket = false
		end
	end
end

function ok.CheckAAA(ply, ang)
	local pitch = ang.x
	local yaw = ang.y

	if pitch >= 90 and 180 > pitch then
		pitch = 89
	elseif pitch >= 180 then
		pitch = -89
	end

	if pitch > -0.1 and 0.1 > pitch and pitch != 0 then
		pitch = 89
		yaw = yaw + 180
	end

	ply:SetPoseParameter("aim_pitch", pitch)
	ply:SetPoseParameter("head_pitch", pitch)
	ply:SetRenderAngles(Angle(0, math.NormalizeAngle(yaw), 0))
	ply:InvalidateBoneCache()
end

function ok.HighJump(cmd)
	if !ok.vars["misc"]["highjump"]:GetBool() then return end
	local pos = me:GetPos()
	local tdata = {start = pos, endpos = pos - Vector(0, 0, 1337), mask = MASK_SOLID}
	local trace = util.TraceLine(tdata)
	local len = (pos - trace.HitPos).z
	if len > 25 and 51.5 > len then
		cmd:SetButtons(bit.bor(cmd:GetButtons(), IN_DUCK))
	else
		cmd:RemoveKey(IN_DUCK)
	end
end

function ok.Visuals()
	if ok.vars["visuals"]["watermark"]:GetBool() then
		ok.er = math.sin(CurTime() * 4) * 127 + 128
		ok.eg = math.sin(CurTime() * 4 + 2) * 127 + 128
		ok.eb = math.sin(CurTime() * 4 + 4) * 127 + 128
		draw.SimpleText("SkidScorcher", "wireless gamer", 4, 40, Color(ok.er, ok.eg, ok.eb), TEXT_ALIGN_LEFT, TEXT_ALIGN_BOTTOM)
	end

	for k,v in next, player.GetAll() do
		if !ok.vars["visuals"]["esp"]:GetBool() or !v:IsValid() or !v:IsPlayer() or !v:Alive() or 0 >= v:Health() then continue end
		if !ok.vars["misc"]["thirdperson"]:GetBool() and v == me then continue end
		local min, max = v:GetCollisionBounds()
		local pos = v:GetPos()
		local top, bottom = (pos + Vector(0, 0, max.z)):ToScreen(), (pos - Vector(0, 0, 8)):ToScreen()
		local middle = bottom.y - top.y
		local width = middle / 2.425

		if ok.vars["visuals"]["name"]:GetBool() then
			draw.SimpleText(v:Nick(), "visual gamer", bottom.x, top.y, Color(255, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_BOTTOM)
		end

		if ok.vars["visuals"]["box"]:GetBool() then
			surface.SetDrawColor(me:Team() == v:Team() and Color(0, 100, 255) or Color(200, 225, 0))
			surface.DrawOutlinedRect(bottom.x - width, top.y, width * 2, middle)
			surface.SetDrawColor(Color(0, 0, 0))
			surface.DrawOutlinedRect(bottom.x - width - 1, top.y - 1, width * 2 + 2, middle + 2)
			surface.DrawOutlinedRect(bottom.x - width + 1, top.y + 1, width * 2 - 2, middle - 2)
		end

		ok.drawpos = 0

		if ok.vars["visuals"]["weapon"]:GetBool() then
			local wep = v:GetActiveWeapon()
			if wep and wep != NULL then
				draw.SimpleText(wep.GetPrintName and wep:GetPrintName() or wep:GetClass(), "visual gamer", bottom.x, bottom.y + ok.drawpos, Color(255, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
				ok.drawpos = ok.drawpos + 10
			end
		end

		if ok.vars["visuals"]["rank"]:GetBool() then
			draw.SimpleText(v.GetUserGroup and v:GetUserGroup() or "__norank", "visual gamer", bottom.x, bottom.y + ok.drawpos, Color(255, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
			ok.drawpos = ok.drawpos + 10
		end

		if ok.vars["visuals"]["angles"]:GetBool() then
			if ok.rang[v] then
				local ang = ok.rang[v]
				draw.SimpleText("x: " .. tostring(math.Round(ang.x)) .. " y: " .. tostring(math.Round(ang.y)), "visual gamer", bottom.x, bottom.y + ok.drawpos, Color(255, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
				ok.drawpos = ok.drawpos + 10
			end
		end

		if ok.vars["visuals"]["health"]:GetBool() then
			local health = math.Clamp(v:Health(), 0, 100)
			local green = health * 2.55
			local red = 255 - green
			surface.SetDrawColor(Color(0, 0, 0))
			surface.DrawRect(bottom.x + width + 2, top.y - 1, 4, middle + 2)
			surface.SetDrawColor(Color(red, green, 0))
			local height = health * middle / 100
			surface.DrawRect(bottom.x + width + 3, top.y + (middle - height), 2, height)
		end
	end

	if ok.vars["visuals"]["snapline"]:GetBool() and ok.ep then
		local pos = ok.ep:ToScreen()
		if pos.visible then
			surface.SetDrawColor(Color(255, 255, 255))
			surface.DrawLine(ScrW() / 2, ScrH(), pos.x, pos.y)
		end
	end
end

ok.wepchams = CreateMaterial("wireless_weapon_mat", "VertexLitGeneric", {
	["$ignorez"] = 1,
	["$model"] = 1,
	["$basetexture"] = "models/debug/debugwhite"
})

ok.chams1 = CreateMaterial("wireless_gamer_mat", "VertexLitGeneric", {
	["$ignorez"] = 1,
	["$model"] = 1,
	["$basetexture"] = "models/debug/debugwhite"
})

ok.chams2 = CreateMaterial("wired_gamer_mat", "VertexLitGeneric", {
	["$ignorez"] = 0,
	["$model"] = 1,
	["$basetexture"] = "models/debug/debugwhite"
})

function ok.GetWepChamsColor()
	return 255 / 255, 255 / 255, 255 / 255
end

function ok.GetChamsColor(t, v)
	if t then
		if v then
			return 50 / 255, 200 / 255, 25 / 255
		else
			return 0, 100 / 255, 255 / 255
		end	
	else
		if v then
			return 200 / 255, 125 / 255, 0
		else
			return 200 / 255, 225 / 255, 0
		end
	end
end

function ok.Chams()
	for k,v in next, ents.GetAll() do
		if !ok.vars["visuals"]["wepchams"]:GetBool() or !v:IsValid() or !v:IsWeapon() then continue end
		cam.Start3D()
		render.MaterialOverride(ok.wepchams)
		render.SetColorModulation(ok.GetWepChamsColor(false))
		v:DrawModel()
		cam.End3D()
	end

	for k,v in next, player.GetAll() do
		if !ok.vars["visuals"]["chams"]:GetBool() or !v:IsValid() or !v:IsPlayer() or !v:Alive() or 0 >= v:Health() then continue end
		if !ok.vars["misc"]["thirdperson"]:GetBool() and v == me then continue end
		cam.Start3D()
		render.MaterialOverride(ok.chams1)
		render.SetColorModulation(ok.GetChamsColor(me:Team() == v:Team(), false))
		v:DrawModel()

		if v == me then
			render.SetColorModulation(ok.GetChamsColor(me:Team() == v:Team(), false))
		else
			render.SetColorModulation(ok.GetChamsColor(me:Team() == v:Team(), true))
		end

		render.MaterialOverride(ok.chams2)
		v:DrawModel()
		cam.End3D()
	end
end

function ok.CalcView(ply, pos, angle, fov, nearZ, farZ)
	local view = {}
	view.angles = (ok.vars["hvh"]["antiaim"]:GetBool() or ok.vars["aimbot"]["silent"]:GetBool() or ok.vars["misc"]["walkbot"]:GetBool()) and ok.fa or angle
	view.origin = ok.vars["misc"]["thirdperson"]:GetBool() and (pos - ok.fa:Forward() * 100) or pos
	view.fov = ok.vars["visuals"]["fov"]:GetInt()

	return view
end

function ok.ShouldDrawLocalPlayer()
	return ok.vars["misc"]["thirdperson"]:GetBool()
end

function ok.PreDrawOpaqueRenderables()
	for k,v in next, player.GetAll() do
		local ang = v:EyeAngles()
		ok.rang[v] = ang
		if ok.vars["hvh"]["aaa"]:GetBool() then
			ok.CheckAAA(v, ang)
		end
	end
end

function ok.ResetConsoleVars()
	for k,v in next, ok.cvars do
		me:ConCommand(k .. " " .. v)
		ok.Log("Reset convar: ", Color(255, 120, 5), k, Color(255, 0, 0), " (value: ", v, ")")
	end
end

function ok.FindPlayerWithID(userid)
	for k,v in next, player.GetAll() do
		if v:UserID() == userid then
			return v
		end
	end

	return false
end

function ok.PlayerHurt(data)
	if !ok.vars["misc"]["killspam"]:GetBool() or ok.vars["misc"]["ksmode"]:GetInt() == 2 then return end
	local health = data.health
	local id = data.userid
	local attackerid = data.attacker
	local target = ok.FindPlayerWithID(id)
	local attacker = ok.FindPlayerWithID(attackerid)
	if !target or !attacker then return end
	if attacker != NULL and target != NULL then
		if attacker == me then
			target.hits = target.hits and target.hits + 1 or 1
			target.hitsme = 0
			if health == 0 then
				if ok.vars["misc"]["robo"]:GetBool() then
					MEGA.TextToSpeech("easy " .. tostring(target.hits) .. " tap")
				end

				me:ConCommand("say", "[SS] owned " .. target:Nick() .. " in " .. tostring(target.hits) .. " shot" .. (target.hits > 1 and "s" or ""))
				target.hits = 0
			end
		elseif target == me then
			attacker.hitsme = attacker.hitsme and attacker.hitsme + 1 or 1
			attacker.hits = 0
			if health == 0 then
				local pingadvantage = target:Ping() - attacker:Ping()
				if pingadvantage > 50 then
					me:ConCommand("say [SS] ping advantage: i have " .. tostring(pingadvantage) .. " more ping than " .. attacker:Nick())
				elseif attacker.hitsme > 1 then
					me:ConCommand("say [SS] it took " .. attacker:Nick() .. " " .. tostring(attacker.hitsme) .. " shots to kill me")
					attacker.hitsme = 0
				else
					me:ConCommand("say [SS] i just got owned by " .. attacker:Nick())
				end
			end
		end
	end
end

function ok.EntityKilled(data)
	if !ok.vars["misc"]["killspam"]:GetBool() or ok.vars["misc"]["ksmode"]:GetInt() == 1 then return end
	local target = Entity(data.entindex_killed)
	local attacker = Entity(data.entindex_attacker)
	if !target or !attacker then return end
	if attacker != NULL and target != NULL then
		if attacker == me then
			if ok.vars["misc"]["robo"]:GetBool() then
				MEGA.TextToSpeech("owned")
			end

			local str = "say [SS] owned"
			if target:IsPlayer() then
				str = str .. " " .. target:Nick()
			end

			me:ConCommand(str)
		elseif target == me then
			local str = "say [SS] i just got owned"
			if attacker:IsPlayer() then
				str = str .. " by " .. attacker:Nick()
			end

			me:ConCommand(str)
		end
	end
end

ok.ga_y = 0

function ok.AutoGain(cmd)
	if !ok.vars["misc"]["autogain"]:GetBool() or cmd:CommandNumber() == 0 then return end
	local min = ok.vars["misc"]["autogainmin"]:GetFloat()
	local max = ok.vars["misc"]["autogainmax"]:GetFloat()
	local mult = ok.vars["misc"]["autogainmult"]:GetFloat()
	ok.ga_y = ok.ga_y + math.Clamp((me:GetVelocity():Length2D() * mult), min, max)
	math.NormalizeAngle(ok.ga_y)

	local key = _G["KEY_" .. string.upper(ok.vars["misc"]["autogainkey"]:GetString())] or KEY_F
	if input.IsKeyDown(key) then
		cmd:SetForwardMove(10^4)
		cmd:SetSideMove(0)
		ok.FixMove(cmd, Angle(ok.fa.p, ok.ga_y, 0))
	end
end

ok.wbh = "\x6Fkwb\n"
ok.wbm = -1
ok.wbfs = nil
ok.wbwp = {}
ok.wbpd = 1
ok.wbnw = 1
ok.wblp = Vector()
ok.wbly = 0
ok.wbcm = nil

function ok.RecordVector(vec)
	ok.wbfs:WriteFloat(vec.x)
 	ok.wbfs:WriteFloat(vec.y)
  	ok.wbfs:WriteFloat(vec.z)
  	ok.wbfs:Flush()
end

function ok.Walkbot(cmd)
	local walkbot = ok.vars["misc"]["walkbot"]:GetBool()
	local wbrec = ok.vars["misc"]["walkbotrec"]:GetBool()
	if !walkbot and !wbrec then
		if ok.wfs then
			ok.wfs:Close()
		end

		ok.wbcm = nil
		ok.wbm = -1
		ok.wbnw = 1
		ok.wbpd = 1
		return
	end

	if wbrec then
		if !ok.wbfs then 
			ok.wbfs = file.Open("ok_wb_" .. util.CRC(game.GetMap()) .. ".dat", "wb", "DATA")
       
        	if ok.wbfs then
                ok.wbfs:Write(ok.wbh)
                ok.wbfs:Write(util.CRC(game.GetMap()))
                ok.wblp = me:GetPos()
            end
		end

		ok.wbcm = nil
		ok.wbm = 0
	elseif walkbot then
		if ok.wfs then
			ok.wfs:Close()
		end
		
		local fs = file.Open("ok_wb_" .. util.CRC(game.GetMap()) .. ".dat", "rb", "DATA")
        if fs and !ok.wbcm then
        	ok.wbcm = true
       		local head = fs:Read(#ok.wbh)
       		local mcrc = fs:Read(#util.CRC(game.GetMap()))
         	if head == ok.wbh then
            	if mcrc == util.CRC(game.GetMap()) then
                 	ok.wbpd = 1
                	ok.wbnd = 1
                   	ok.wbm = 1
                               
            		table.Empty(ok.wbwp) 
                 	local x = fs:ReadFloat()
                 	local y = fs:ReadFloat()
                	local z = fs:ReadFloat()
                               
                   	while x and y and z do
                       	table.insert(ok.wbwp, Vector(x, y, z))
                                       
                       	x = fs:ReadFloat()
                      	y = fs:ReadFloat()
                    	z = fs:ReadFloat()
                    end
              	else
                	ok.Log("Bad map crc for walkbot data file! Disabling")
                	ok.vars["misc"]["walkbot"]:SetBool(false)
                	ok.wbcm = nil
                	fs:Close()
                	return
            	end
          	else
           		ok.Log("Bad header for walkbot data file! Disabling")
           		ok.vars["misc"]["walkbot"]:SetBool(false)
           		ok.wbcm = nil
           		fs:Close()
           		return
         	end
               
         	fs:Close()
        elseif !fs then
        	ok.Log("Walkbot failed, no data for this map! Disabling")
        	ok.vars["misc"]["walkbot"]:SetBool(false)
        	ok.wbcm = nil
        	return
        end

		ok.wbm = 1
	end

   	local pos = me:GetPos()
  	if ok.wbfs then
      	if ok.wbm == 0 then
      		if math.abs(math.abs(ok.wbly) - math.abs(ok.fa.y)) > 10 and ok.wblp:Distance(pos) > 52 or ok.wblp:Distance(pos) > 392 then           
            	ok.wblp = pos
               	ok.wbly = ok.fa.y
                               
              	ok.RecordVector(util.QuickTrace(pos + me:OBBCenter(), pos - Vector(0, 0, 8192), me).HitPos)
          	end
      	end
  	end
       
  	if ok.wbm == 1 then
     	local vec = ok.wbwp[ok.wbnw] - pos
       	if vec:Length2D() < me:GetVelocity():Length2D() * 0.1 then
     		if ok.wbwp[ok.wbnw + ok.wbpd] then
       			ok.wbnw = ok.wbnw + ok.wbpd
        	else
        		if ok.wbpd == 1 then
        			ok.wbpd = -1
        		elseif ok.wbpd == -1 then
        			ok.wbpd = 1
        		end
          	end
     	end
       	
     	local ang = vec:Angle()
      	cmd:SetForwardMove(10^4)
      	cmd:SetSideMove(0)
      	ok.FixMove(cmd, Angle(ok.fa.p, ang.y, 0))
  	end
end

function ok.DrawWalkbotBox(v, c)
   	surface.SetDrawColor(c)
       
   	local b1 = (v + Vector(5, 5, 0)):ToScreen()
   	local b2 = (v + Vector(5, -5, 0)):ToScreen()
  	local b3 = (v + Vector(-5, 5, 0)):ToScreen()
  	local b4 = (v + Vector(-5, -5, 0)):ToScreen()
       
   	local t1 = (v + Vector(5, 5, 32)):ToScreen()
   	local t2 = (v + Vector(5, -5, 32)):ToScreen()
   	local t3 = (v + Vector(-5, 5, 32)):ToScreen()
  	local t4 = (v + Vector(-5, -5, 32)):ToScreen()
 
 	surface.DrawLine(b1.x, b1.y, b3.x, b3.y)
  	surface.DrawLine(b2.x, b2.y, b4.x, b4.y)
 	surface.DrawLine(b1.x, b1.y, b2.x, b2.y)
	surface.DrawLine(b3.x, b3.y, b4.x, b4.y)
       
 	surface.DrawLine(b1.x, b1.y, t1.x, t1.y)
  	surface.DrawLine(b2.x, b2.y, t2.x, t2.y)
  	surface.DrawLine(b3.x, b3.y, t3.x, t3.y)
  	surface.DrawLine(b4.x, b4.y, t4.x, t4.y)
       
  	surface.DrawLine(t1.x, t1.y, t3.x, t3.y)
  	surface.DrawLine(t2.x, t2.y, t4.x, t4.y)
  	surface.DrawLine(t1.x, t1.y, t2.x, t2.y)
  	surface.DrawLine(t3.x, t3.y, t4.x, t4.y)
end

function ok.DrawWalkbot()
 	if ok.wbm == 0 and ok.wbfs then
 		draw.SimpleText("WALKBOT RECORDING", "Trebuchet24", ScrW(), 0, Color(255, 255, 255), TEXT_ALIGN_RIGHT, TEXT_ALIGN_TOP)
 	elseif ok.wbm == 1 then
     	local prev
    	for k,v in next, ok.wbwp do
           	local scr = v:ToScreen()
         	if not scr.visible then continue end
                       
          	if prev and prev.x and prev.y then
           		surface.SetDrawColor(Color(255, 255, 255))
           		surface.DrawLine(prev.x, prev.y, scr.x, scr.y)
           	 end
                       
         	ok.DrawWalkbotBox(v, ok.wbnw == k and Color(50, 200, 25) or Color(225, 25, 10))
         	prev = scr
     	end
   	end
end

function ok.CreateMove(cmd)
	ok.AutoHop(cmd)
	ok.GetTarget()
	ok.Aimbot(cmd)
	ok.AntiAim(cmd)
	ok.FakeLag(cmd)
	ok.HighJump(cmd)
	ok.AutoGain(cmd)
	ok.Walkbot(cmd)
end

function ok.AddHook(htype, name, func)
	hook.Add(htype, name, func)
	ok.Log("Created ", Color(255, 120, 5), htype, Color(255, 190, 5), " hook: ", Color(255, 120, 5), name, Color(255, 0, 0), " (" .. tostring(func) .. ")")
end

ok.curtab = 0
ok.menuitems = {}

function ok.CreateTab(frame, name, index, max)
	local tab = vgui.Create("DButton", frame)
	tab:SetText("")
	tab:SetSize(frame:GetWide() / max - 1, 30)
	tab:SetPos((index - 1) * (tab:GetWide() + 1), 24)
	function tab.Paint(self, width, height)
		surface.SetDrawColor(Color(100, 100, 100))
		surface.DrawRect(0, 0, width, height)
		if ok.curtab == index then
			surface.SetDrawColor(Color(255, 255, 255, 15))
			surface.DrawRect(0, 0, width, height)
		end

		draw.SimpleText(name, "gamer tab", width / 2, height / 2, Color(255, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end

	function tab.DoClick()
		ok.curtab = index
		for i = 1, #ok.menuitems do
			local items = ok.menuitems[i]
			for k,v in next, items do
				v:SetVisible(i == index)
			end
		end
	end
end

function ok.CreateCheckbox(frame, name, tab, index, cvtab, cvname)
	local cvar = ok.vars[cvtab][cvname]
	local check = vgui.Create("DButton", frame)
	check:SetText("")
	surface.SetFont("gamer tab")
	local wid = surface.GetTextSize(name)
	check:SetSize(26 + wid, 18)
	local x = 10
	local y = 64 + (22 * (index - 1))
	if (y + 27) >= frame:GetTall() then
		local firstindex = 0
		for i = 1, index do
			local _y = 64 + (22 * (i - 1))
			if (_y + 27) >= frame:GetTall() then
				firstindex = i
				break
			end
		end

		x = (x * 2.5) + 192
		y = 64 + (22 * (index - (firstindex - 1) - 1))
	end

	check:SetPos(x, y)
	function check.Paint(self, width, height)
		surface.SetDrawColor(Color(100, 100, 100))
		surface.DrawOutlinedRect(0, 0, 18, height)
		if cvar:GetBool() then
			surface.DrawRect(0, 0, 18, height)
		end

		draw.SimpleText(name, "gamer tab", 24, height / 2, Color(255, 255, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
	end

	function check.DoClick()
		cvar:SetBool(!cvar:GetBool())
	end

	if ok.curtab != tab then
		check:SetVisible(false)
	end

	ok.menuitems[tab][#ok.menuitems[tab] + 1] = check
end

function ok.CreateSlider(frame, name, tab, index, cvtab, cvname, min, max, dec)
	min = min * 10
	max = max * 10
	local cvar = ok.vars[cvtab][cvname]
	local slider = vgui.Create("DButton", frame)
	slider:SetText("")
	slider:SetSize(192, 32)
	local x = 10
	local y = 64 + (22 * (index - 1))
	if (y + 27) >= frame:GetTall() then
		local firstindex = 0
		for i = 1, index do
			local _y = 64 + (22 * (i - 1))
			if (_y + 27) >= frame:GetTall() then
				firstindex = i
				break
			end
		end

		x = (x * 2.5) + 192
		y = 64 + (22 * (index - (firstindex - 1) - 1))
	end

	slider:SetPos(x, y)
	function slider.Paint(self, width, height)
		draw.SimpleText(name .. " [" .. math.Round(cvar:GetFloat(), dec) .. "]", "gamer tab", width / 2, height / 2 - (height / 4), Color(255, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		surface.SetDrawColor(Color(100, 100, 100))
		surface.DrawRect(0, height / 1.25, width, 1)
		surface.DrawRect(math.Clamp(((cvar:GetFloat() * 10) - min) / (max - min) * width - 2, 0, width - 4), height / 1.25 - 4, 4, 8)
		if input.IsMouseDown(MOUSE_LEFT) then
			local fx, fy = frame:GetPos()
			local sx, sy = slider:GetPos()
			local rx = fx + sx
			local ry = fy + sy
			local ssx, ssy = slider:GetSize()
			local mx = gui.MouseX()
			local my = gui.MouseY()
			local rmx = mx - rx
			if ((mx >= rx) and ((rx + ssx) >= mx)) and ((my >= ry) and ((ry + ssy) >= my)) then
				cvar:SetFloat(math.Round(rmx / width * ((max / 10) - (min / 10)) + (min / 10), dec))
			end
		end
	end

	function slider.DoClick() end

	if ok.curtab != tab then
		slider:SetVisible(false)
	end

	ok.menuitems[tab][#ok.menuitems[tab] + 1] = slider
end

function ok.Menu()
	ok.menuitems = {{}, {}, {}, {}}
	local frame = vgui.Create("DFrame")
	frame:SetTitle("")
	frame:SetSize(600, 450)
	frame:SetPos(0, 0)
	frame:ShowCloseButton(false)
	frame:SetDraggable(false)
	frame:Center()
	frame:MakePopup()
	function frame.Paint(self, width, height)
		surface.SetDrawColor(Color(75, 75, 75))
		surface.DrawRect(0, 0, width, height)
		draw.SimpleText("SkidScorcher", "gamer title", width / 2, 12, Color(255, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end

	local close = vgui.Create("DButton", frame)
	close:SetText("")
	close:SetSize(24, 24)
	close:SetPos(frame:GetWide() - 24, 0)
	function close.Paint(self, width, height)
		surface.SetDrawColor(Color(255, 0, 0))
		surface.DrawRect(0, 0, width, height)
	end

	function close.DoClick()
		frame:Remove()
	end

	//// TABS \\\\
	ok.CreateTab(frame, "Aimbot", 1, 4)
	ok.CreateTab(frame, "Visuals", 2, 4)
	ok.CreateTab(frame, "Misc", 3, 4)
	ok.CreateTab(frame, "HvH", 4, 4)

	//// AIMBOT TAB \\\\
	ok.CreateCheckbox(frame, "Enabled", 1, 1, "aimbot", "enabled")
	ok.CreateSlider(frame, "Hitbox Point", 1, 2, "aimbot", "point", 0.01, 1, 2)
	ok.CreateCheckbox(frame, "Multi Point", 1, 4, "aimbot", "multipoint")
	ok.CreateSlider(frame, "Multi Point Mode", 1, 5, "aimbot", "mpmode", 1, 2, 0)
	ok.CreateCheckbox(frame, "AutoWall", 1, 7, "aimbot", "autowall")
	ok.CreateCheckbox(frame, "Silent", 1, 8, "aimbot", "silent")
	ok.CreateCheckbox(frame, "NoSpread", 1, 9, "aimbot", "nospread")
	ok.CreateCheckbox(frame, "BodyAim", 1, 10, "aimbot", "bodyaim")
	ok.CreateCheckbox(frame, "Static AA", 1, 11, "aimbot", "static")
	ok.CreateCheckbox(frame, "NextShot", 1, 12, "aimbot", "nextshot")
	ok.CreateCheckbox(frame, "AutoShoot", 1, 13, "aimbot", "autoshoot")
	ok.CreateCheckbox(frame, "Ignore Team", 1, 14, "aimbot", "team")
	ok.CreateCheckbox(frame, "Ignore Friends", 1, 15, "aimbot", "friends")

	//// VISUALS TAB \\\\
	ok.CreateCheckbox(frame, "ESP Enabled", 2, 1, "visuals", "esp")
	ok.CreateCheckbox(frame, "Name ESP", 2, 2, "visuals", "name")
	ok.CreateCheckbox(frame, "Box ESP", 2, 3, "visuals", "box")
	ok.CreateCheckbox(frame, "Weapon ESP", 2, 4, "visuals", "weapon")
	ok.CreateCheckbox(frame, "Rank ESP", 2, 5, "visuals", "rank")
	ok.CreateCheckbox(frame, "Angle ESP", 2, 6, "visuals", "angles")
	ok.CreateCheckbox(frame, "Healthbar", 2, 7, "visuals", "health")
	ok.CreateCheckbox(frame, "Snapline", 2, 8, "visuals", "snapline")
	ok.CreateCheckbox(frame, "Player Chams", 2, 9, "visuals", "chams")
	ok.CreateCheckbox(frame, "Weapon Chams", 2, 10, "visuals", "wepchams")
	ok.CreateCheckbox(frame, "Watermark", 2, 11, "visuals", "watermark")
	ok.CreateCheckbox(frame, "Fullbright", 2, 12, "visuals", "fullbright")
	ok.CreateCheckbox(frame, "ASUS Walls", 2, 13, "visuals", "asus")
	ok.CreateSlider(frame, "Viewmodel", 2, 14, "visuals", "viewmodel", 0, 2, 0)
	ok.CreateSlider(frame, "FOV", 2, 16, "visuals", "fov", 65, 125, 0)

	//// MISC TAB \\\\
	ok.CreateCheckbox(frame, "AutoHop", 3, 1, "misc", "autohop")
	ok.CreateCheckbox(frame, "HighJump", 3, 2, "misc", "highjump")
	ok.CreateCheckbox(frame, "Third Person", 3, 3, "misc", "thirdperson")
	ok.CreateCheckbox(frame, "KillSpam", 3, 4, "misc", "killspam")
	ok.CreateSlider(frame, "KillSpam Mode", 3, 5, "misc", "ksmode", 1, 2, 0)
	ok.CreateCheckbox(frame, "KillSpam TTS", 3, 7, "misc", "robo")
	ok.CreateCheckbox(frame, "AutoStrafe", 3, 8, "misc", "autostrafe")
	ok.CreateCheckbox(frame, "AutoGain", 3, 9, "misc", "autogain")
	ok.CreateSlider(frame, "AutoGain Min", 3, 10, "misc", "autogainmin", 0.75, 1.25, 2)
	ok.CreateSlider(frame, "AutoGain Max", 3, 12, "misc", "autogainmax", 4.25, 5.75, 2)
	ok.CreateSlider(frame, "AutoGain Multiplier", 3, 14, "misc", "autogainmult", 0.01, 0.035, 3)
	ok.CreateCheckbox(frame, "Walkbot", 3, 16, "misc", "walkbot")
	ok.CreateCheckbox(frame, "Record Path", 3, 17, "misc", "walkbotrec")
	ok.CreateCheckbox(frame, "Robot", 3, 18, "misc", "robobitch")

	//// HVH TAB \\\\
	ok.CreateCheckbox(frame, "AntiAim", 4, 1, "hvh", "antiaim")
	ok.CreateCheckbox(frame, "Spinbot", 4, 2, "hvh", "spinbot")
	ok.CreateSlider(frame, "Spinbot Speed", 4, 3, "hvh", "spinspeed", 1, 45, 0)
	ok.CreateCheckbox(frame, "Edge AntiAim", 4, 5, "hvh", "edge")
	ok.CreateSlider(frame, "Edge Method", 4, 6, "hvh", "edgemet", 1, 4, 0)
	ok.CreateCheckbox(frame, "Adaptive AntiAim", 4, 8, "hvh", "adaptive")
	ok.CreateSlider(frame, "Adaptive Yaw", 4, 9, "hvh", "adapyaw", 270, 540, 0)
	ok.CreateSlider(frame, "Adaptive Max", 4, 11, "hvh", "adapmax", 2, 30, 0)
	ok.CreateSlider(frame, "Adaptive Speed", 4, 13, "hvh", "adapspeed", 1, 15, 0)
	ok.CreateSlider(frame, "AntiAim Pitch", 4, 15, "hvh", "pitch", -250, 250, 0)
	ok.CreateSlider(frame, "AntiAim Yaw", 4, 17, "hvh", "yaw", 270, 541, 0)
	ok.CreateSlider(frame, "AntiAim Roll", 4, 18, "hvh", "roll", -720, -360, 0)
	ok.CreateCheckbox(frame, "Add Rand Pitch", 4, 20, "hvh", "pitchrand")
	ok.CreateSlider(frame, "Rand Min", 4, 21, "hvh", "pitchrandmin", -15, 15, 0)
	ok.CreateSlider(frame, "Rand Max", 4, 23, "hvh", "pitchrandmax", 0, 45, 0)
	ok.CreateCheckbox(frame, "FakeLag", 4, 25, "hvh", "fakelag")
	ok.CreateSlider(frame, "FakeLag Choke", 4, 26, "hvh", "flchoke", 2, 14, 0)
	ok.CreateSlider(frame, "FakeLag Send", 4, 28, "hvh", "flsend", 1, 14, 0)
	ok.CreateCheckbox(frame, "Anti-AntiAim", 4, 30, "hvh", "aaa")
end

ok.lmc = false
function ok.PreRender()
	if !ok.vars["visuals"]["fullbright"]:GetBool() then return end
	render.SetLightingMode(1)
	ok.lmc = true
end

function ok.PostRender()
	if !ok.vars["visuals"]["fullbright"]:GetBool() then return end
	if ok.lmc then
		render.SetLightingMode(0)
		ok.lmc = false
	end
end

function ok.PatchViewModel(vm, ply, wep)
	if !vm or !ply then return end
	local viewmodel = ok.vars["visuals"]["viewmodel"]:GetInt()
	if 0 >= viewmodel then return end
   	render.MaterialOverride((viewmodel == 1) and Material("models/wireframe") or Material("models/debug/debugwhite"))
   	render.SetColorModulation(0, 100 / 255, 255 / 255)
end

function ok.RenderScene()
	for k,v in next, game.GetWorld():GetMaterials() do
		local mat = Material(v)
		if ok.vars["visuals"]["asus"]:GetBool() then
			mat:SetFloat("$alpha", 0.75)
		else
			mat:SetFloat("$alpha", 1)
		end
	end
end

function ok.PostDraw2DSkyBox(ply, pos)
	if ok.vars["visuals"]["asus"]:GetBool() then
		render.Clear(0, 0, 0, 0, true, true)
	end
end

function ok.SetTickIntervalHook()
	ok.SetTickInterval()
end

function ok.Robot()
	if ok.vars["misc"]["robobitch"]:GetBool() then
		me:ConCommand("act robot")
	end
end

ok.AddHook("Think", "ok.SetTickIntervalHook", ok.SetTickIntervalHook)
ok.AddHook("Move", "ok.GetCurTime", ok.GetCurTime)
ok.AddHook("DrawOverlay", "ok.Visuals", ok.Visuals)
ok.AddHook("RenderScreenspaceEffects", "ok.Chams", ok.Chams)
ok.AddHook("CreateMove", "ok.CreateMove", ok.CreateMove)
ok.AddHook("CalcView", "ok.CalcView", ok.CalcView)
ok.AddHook("ShouldDrawLocalPlayer", "ok.ShouldDrawLocalPlayer", ok.ShouldDrawLocalPlayer)
ok.AddHook("PreDrawOpaqueRenderables", "ok.PreDrawOpaqueRenderables", ok.PreDrawOpaqueRenderables)
ok.AddHook("PreRender", "ok.PreRender", ok.PreRender)
ok.AddHook("PostRender", "ok.PostRender", ok.PostRender)
ok.AddHook("PreDrawHUD", "ok.PostRender", ok.PostRender) // gmod becomes satanic without this
ok.AddHook("PreDrawViewModel", "ok.PatchViewModel", ok.PatchViewModel)
ok.AddHook("RenderScene", "ok.RenderScene", ok.RenderScene)
ok.AddHook("PostDraw2DSkyBox", "ok.PostDraw2DSkyBox", ok.PostDraw2DSkyBox)
ok.AddHook("DrawOverlay", "ok.DrawWalkbot", ok.DrawWalkbot)
timer.Create("ok.Robot", 0.5, 0, ok.Robot)
gameevent.Listen("player_hurt")
ok.AddHook("player_hurt", "ok.PlayerHurt", ok.PlayerHurt)
gameevent.Listen("entity_killed")
ok.AddHook("entity_killed", "ok.EntityKilled", ok.EntityKilled)
concommand.Add("ok_menu", ok.Menu)
ok.Log("Created concommand: ", Color(255, 120, 5), "ok_menu", Color(255, 0, 0), " (" .. tostring(ok.Menu) .. ")")
concommand.Add("ok_resetcv", ok.ResetConsoleVars)
ok.Log("Created concommand: ", Color(255, 120, 5), "ok_resetcv", Color(255, 0, 0), " (" .. tostring(ok.ResetConsoleVars) .. ")")
ok.Log("Loaded!")