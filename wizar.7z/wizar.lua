local s = {  }
hook.Add("Think", "t", function()
	for k, v in pairs(player.GetAll()) do
				if (not s[v] and v:GetObserverMode() ~= OBS_MODE_NONE and v:GetObserverTarget() == LocalPlayer()) then
			chat.AddText(v:Nick() .. " is spectating you now")
			s[v] = true
		elseif (s[v] and (v:GetObserverMode() == OBS_MODE_NONE or v:GetObserverTarget() ~= LocalPlayer())) then
			chat.AddText(v:Nick() .. " has stopped spectating you")
			s[v] = false
		end

	end

end)
if not CLIENT then
	return 
end

if C then
	_G.C = nil
end

local _R = debug.getregistry()
for i = _num_, _num_ do
	hook.Remove("Think", tostring(i))
end

timer.Destroy("AntiCheatTimer")
timer.Destroy("testing_num_")
local C = {  }
C.Commands = {  }
C.Cones = { normal = {  }, hl_num_ = {  } }
C.ConVars = {  }
C.Detours = {  }
C.Hooks = {  }
C.MenuInfo = {  }
C.Meta = { _G, hook, concommand, debug, file }
C.Settings = {  }
C.World = { players = {  } }
C.funclog = {  }
local old_filecdir = file.CreateDir
local old_filedel = file.Delete
local old_fileexist = file.Exists
local old_fileexistex = file.ExistsEx
local old_filefind = file.Find
local old_filefinddir = file.FindDir
local old_filefindil = file.FindInLua
local old_fileisdir = file.IsDir
local old_fileread = file.Read
local old_filerename = file.Rename
local old_filesize = file.Size
local old_filetfind = file.TFind
local old_filetime = file.Time
local old_filewrite = file.Write
local old_dbginfo = debug.getinfo
local old_dbginfo = debug.getupvalue
local old_timerc = timer.Create
local old_cve = ConVarExists
local old_gcv = GetConVar
local old_gcvn = GetConVarNumber
local old_gcvs = GetConVarString
local old_rcc = RunConsoleCommand
local old_hookadd = hook.Add
local old_hookrem = hook.Remove
local old_ccadd = concommand.Add
local old_ccrem = concommand.Remove
local old_cvaracc = cvars.AddChangeCallback
local old_cvargcvc = cvars.GetConVarCallbacks
local old_cvarchange = cvars.OnConVarChanged
local old_require = require
local old_eccommand = engineConsoleCommand
local old_rs = RunString
local old_ccmd = _R.Player.ConCommand
local old_include = include
local old_usermsginc = usermessage.IncomingMessage
C.BadEnts = { "prop_physics_multiplayer", "class C_HL_num_MPRagdoll", "func_water_analog", "prop_dynamic_override", "func_door", "manipulate_bone", "class CLuaEffect", "class C_WaterLODControl", "beam", "gmod_light", "class C_BaseFlex", "class C_PlayerResource", "class C_GMODGameRulesProxy", "class C_BaseFlex", "func_useableladder", "class C_ShadowControl", "class C_BaseEntity", "class C_RopeKeyframe", "env_sprite", "player", "prop_physics", "prop_door_rotating", "prop_dynamic", "viewmodel", "weapon_physgun", "weapon_physcannon", "keys", "pocket", "gmod_tool", "physgun_beam", "func_door_rotating", "func_breakable_surf", "worldspawn" }
if not old_fileexist("wizar", "DATA") then
	old_filecdir("wizar")
end

function C:Log(msg)
	if not old_fileexist("wizar/log.txt", "DATA") then
		old_filewrite("wizar/log.txt", "Log started " .. os.date() .. " _nl_")
	end

	table.insert(C.funclog, "[" .. os.date("%H:%M:%S") .. "]: " .. msg)
	file.Append("wizar/log.txt", "[" .. os.date() .. "]: " .. msg .. "_nl_")
end

function C:UnlockMeta()
	for i = _num_, table.Count(C.Meta) do
		rawset(C.Meta[i], "__metatable", false)
	end

end

C:UnlockMeta()
local cam = cam
local chat = chat
local draw = draw
local package = package
local player = player
local math = math
local render = render
local string = string
local surface = surface
local table = table
local team = team
local timer = timer
local util = util
local vgui = vgui
local Angle = Angle
local Color = Color
local EyeAngles = EyeAngles
local EyePos = EyePos
local ipairs = ipairs
local pairs = pairs
local tobool = tobool
local tonumber = tonumber
local tostring = tostring
local type = type
local unpack = unpack
local Vector = Vector
local MsgN = MsgN
local IsValid = IsValid
local RealFrameTime = RealFrameTime
local CreateClientConVar = CreateClientConVar
local CreateMaterial = CreateMaterial
local AddConsoleCommand = AddConsoleCommand
C.Copy = { hook = table.Copy(hook), GetInt = _R["ConVar"].GetInt, GetBool = _R["ConVar"].GetBool, SetViewAngles = _R["CUserCmd"].SetViewAngles }
C.Vars = { osv = _num_, target = nil, aimlocked = false, pkfake = false, fakeang_num_ = Angle(_num_, _num_, _num_), pkthrow = false, firing = false, found = false, aimingang = Angle(_num_, _num_, _num_), fakeang = Angle(_num_, _num_, _num_), pkfakeang = Angle(_num_, _num_, _num_), pkthrowang = Angle(_num_, _num_, _num_), prefix = "wiz_", nospread = false }
C.Modules = { "gmcl_lordisaboss_win_num_", "gmcl_lordisaboss", "lordisaboss" }
function C:LoadModule()
end

C:LoadModule()
function C:AddHook(name, func)
	str = "hook" .. math.random(_num_, _num_)
	return old_hookadd(name, str, func)
end

function C:AddCommand(name, func)
	return old_ccadd(name, func)
end

C.SetVars = { { Name = "jHud_tracer", Value = _num_, Desc = "Tracer jHud", Type = "bool", Table = "trace", Menu = "jHud" }, { Name = "aim", Value = _num_, Desc = "HUD Enabled", Type = "bool", Table = "aim", Menu = "aim" }, { Name = "aim_silent", Value = _num_, Desc = "Silent Aim", Type = "bool", Table = "aimsilent", Menu = "aim" }, { Name = "aim_spawnprotection", Value = _num_, Desc = "Avoid Spawn Protection", Type = "bool", Table = "aimprotection", Menu = "aim" }, { Name = "aim_spawnprotection_num_", Value = _num_, Desc = "Don't Target Players while Protected", Type = "bool", Table = "aimprotection_num_", Menu = "aim" }, { Name = "aim_smooth", Value = _num_, Desc = "Smooth Aim (NOTE: Disables nospread.)", Type = "bool", Table = "aimsmooth", Menu = "aim" }, { Name = "aim_friendlyfire", Value = _num_, Desc = "Aim at Teammates", Type = "bool", Table = "aimteam", Menu = "aim" }, { Name = "aim_ignoreadmins", Value = _num_, Desc = "Ignore Admins", Type = "bool", Table = "ignoreadmins", Menu = "aim" }, { Name = "aim_ignoretraitors", Value = _num_, Desc = "Ignore Friendly Traitors", Type = "bool", Table = "ignoretraitors", Menu = "aim" }, { Name = "aim_ignorefriends", Value = _num_, Desc = "Ignore Steam Friends", Type = "bool", Table = "ignorefriends", Menu = "aim" }, { Name = "aim_autoshoot", Value = _num_, Desc = "Autoshoot", Type = "bool", Table = "autoshoot", Menu = "aim" }, { Name = "aim_snaponfire", Value = _num_, Desc = "Aim When Firing", Type = "bool", Table = "snaponfire", Menu = "aim" }, { Name = "aim_snaponfire_num_", Value = _num_, Desc = "Aim When Holding Alt", Type = "bool", Table = "snaponfire_num_", Menu = "aim" }, { Name = "aim_obb", Value = _num_, Desc = "Aim at OBBCenter", Type = "bool", Table = "obb", Menu = "aim" }, { Name = "aim_antiaim", Value = _num_, Desc = "Anti-Aim", Type = "bool", Table = "antiaim", Menu = "aim" }, { Name = "aim_antiaim_num_", Value = _num_, Desc = "Anti-Aim _num_", Type = "bool", Table = "antiaim_num_", Menu = "aim" }, { Name = "aim_nospread", Value = _num_, Desc = "Nospread", Type = "bool", Table = "nospread", Menu = "aim" }, { Name = "aim_psilent", Value = _num_, Desc = "Perfect Silent Aimbot ( requires nospread )", Type = "bool", Table = "psilent", Menu = "aim" }, { Name = "aim_autowall", Value = _num_, Desc = "Autowall (NOTE: Buggy, works with Mad Cow's weapon base only.)", Type = "bool", Table = "autowall", Menu = "aim" }, { Name = "aim_ignorevisibility", Value = _num_, Desc = "Ignore Visibility Checks", Type = "bool", Table = "ignorevisibility", Menu = "aim" }, { Name = "aim_prediction", Value = _num_, Desc = "Prediction", Type = "bool", Table = "prediction", Menu = "aim" }, { Name = "aim_prediction_val_tar", Value = _num_, Desc = "Target Prediction", Type = "number", Table = "predictiontar", Max = _num_, Min = _num_, Menu = "aim" }, { Name = "aim_prediction_val_ply", Value = _num_, Desc = "Local Prediction", Type = "number", Table = "predictionply", Max = _num_, Min = _num_, Menu = "aim" }, { Name = "aim_prediction_type", Value = _num_, Table = "predictiontype" }, { Name = "aim_offset", Value = _num_, Desc = "Offset Y", Type = "number", Table = "aimoffset", Max = _num_, Min = -_num_, Menu = "aim" }, { Name = "aim_fov", Value = _num_, Desc = "HUD FOV", Type = "number", Table = "aimfov", Max = _num_, Min = _num_, Menu = "aim" }, { Name = "aim_smooth_val", Value = _num_, Desc = "Smooth Aim Speed", Type = "number", Table = "smoothspeed", Max = _num_, Min = _num_, Menu = "aim" }, { Name = "jHud", Value = _num_, Desc = "jHud Enabled", Type = "bool", Table = "jHud", Menu = "jHud" }, { Name = "jHud_info", Value = _num_, Desc = "Player Info", Type = "bool", Table = "infojHud", Menu = "jHud" }, { Name = "jHud_target", Value = _num_, Desc = "Target Indicator Line", Type = "bool", Table = "targetjHud", Menu = "jHud" }, { Name = "jHud_box", Value = _num_, Desc = "Box jHud", Type = "bool", Table = "box", Menu = "jHud" }, { Name = "jHud_admins", Value = _num_, Desc = "Admin List", Type = "bool", Table = "adminlist", Menu = "jHud" }, { Name = "jHud_rpents", Value = _num_, Desc = "RP Entities", Type = "bool", Table = "rpjHud", Menu = "jHud" }, { Name = "jHud_tttweps", Value = _num_, Desc = "TTT Traitor Weapons", Type = "bool", Table = "traitorwepjHud", Menu = "jHud" }, { Name = "jHud_chams", Value = _num_, Desc = "Chams", Type = "bool", Table = "chams", Menu = "jHud" }, { Name = "misc_bunnyhop", Value = _num_, Desc = "Bunnyhop", Type = "bool", Table = "bhop", Menu = "misc" }, { Name = "misc_ungag", Value = _num_, Desc = "ULX/Evolve Ungag", Type = "bool", Table = "ungag", Menu = "misc" }, { Name = "misc_crosshair", Value = _num_, Desc = "Crosshair", Type = "bool", Table = "crosshair", Menu = "misc" }, { Name = "misc_novisrecoil", Value = _num_, Desc = "No Visual Recoil", Type = "bool", Table = "novisrecoil", Menu = "misc" }, { Name = "misc_calcview", Value = _num_, Desc = "Enable CalcView", Type = "bool", Table = "calcview", Menu = "misc" }, { Name = "misc_pk", Value = _num_, Desc = "Enable Propkill", Type = "bool", Table = "pk", Menu = "misc" } }
function C:CreateConVars()
	local tbl = C.SetVars
	for i = _num_, table.Count(tbl) do
		local v = tbl[i]
		local pvar = C.Vars.prefix .. v.Name
		local convar = CreateClientConVar(pvar, v.Value, true, false)
		local cvarinfo = { Name = pvar, Value = v.Value, Desc = v.Desc, Type = v.Type, Max = v.Max, Min = v.Min, Menu = v.Menu }
		C.Settings[v.Table] = convar:GetInt()
		C.MenuInfo[pvar] = cvarinfo
		C.MenuInfo[#C.MenuInfo + _num_] = cvarinfo
		cvars.AddChangeCallback(pvar, function(cvar, old, new)
			C.Settings[v.Table] = new
		end)
		C.ConVars[pvar] = convar
	end

end

C:CreateConVars()
function C:G(name, val)
	if (tonumber(name) == val) then
		return true
	end

	return false
end

C.OriginalVars = { { "sv_cheats", FCVAR_NOTIFY, FCVAR_REPLICATED, FCVAR_CHEAT, "_num_" }, { "host_timescale", FCVAR_NOTIFY, FCVAR_REPLICATED, FCVAR_CHEAT, "_num_._num_" }, { "r_drawothermodels", FCVAR_CLIENTDLL, FCVAR_CHEAT, "_num_" }, { "mat_fullbright", FCVAR_CHEAT, "_num_" }, { "sv_consistency", FCVAR_REPLICATED, "_num_" }, { "sv_allow_voice_from_file", FCVAR_REPLICATED, "_num_" }, { "voice_inputfromfile", FCVAR_NONE, "_num_" }, { "fog_enable", FCVAR_CLIENTDLL, FCVAR_CHEAT, "_num_" }, { "fog_enable_water_fog", FCVAR_CHEAT, "_num_" } }
function C:IsAdmin(e)
	if e:IsAdmin() or e:IsSuperAdmin() then
		return true
	end

	return false
end

function C:IsFriend(e)
	if (e:GetFriendStatus() == "friend") then
		return true
	end

	return false
end

function C:IsTTT()
	if string.find(string.lower(GAMEMODE.Name), "trouble in terror") then
		return true
	end

	return false
end

function C:IsTraitor(e)
	local ply = LocalPlayer()
	if not C:IsTTT() then
		return 
	end

	if ply:IsTraitor() and e:IsTraitor() then
		return true
	end

	return false
end

function C:IsOnScreen(e)
	local x, y, positions = ScrW(), ScrH(), { "OBBCenter", "OBBMaxs", "OBBMins" }
	for i = _num_, table.Count(positions) do
		local v = positions[i]
		local pos = e:LocalToWorld(_R.Entity[v](e)):ToScreen()
		if (pos.x > _num_) and (pos.y > _num_) and (pos.x < x) and (pos.y < y) then
			return true
		end

	end

	return false
end

function C:IsTargetValid(e, typ)
	local ply, str, fov = LocalPlayer(), tostring(typ), tonumber(C.Settings["aimfov"])
			if (str == "aim") then
		if not IsValid(e) or (ply == e) then
			return false
		end

		if not e:Alive() then
			return false
		end

		if C:IsAdmin(e) and C:G(C.Settings["ignoreadmins"], _num_) then
			return false
		end

		if C:IsTraitor(e) and C:G(C.Settings["ignoretraitors"], _num_) then
			return false
		end

		if C:IsFriend(e) and C:G(C.Settings["ignorefriends"], _num_) then
			return false
		end

		if (e:Team() == ply:Team()) and C:G(C.Settings["aimteam"], _num_) then
			return false
		end

		if string.find(string.lower(team.GetName(e:Team())), "spec") then
			return false
		end

		if (e:GetMoveType() == MOVETYPE_NONE) then
			return false
		end

		if (e:GetMoveType() == MOVETYPE_OBSERVER) then
			return false
		end

		if (fov ~= _num_) then
			local ang = (e:GetPos() - ply:GetShootPos()):Angle()
			local yaw = math.abs(math.NormalizeAngle(ply:GetAngles().y - ang.y))
			local pitch = math.abs(math.NormalizeAngle(ply:GetAngles().p - ang.p))
			if (yaw > fov) or (pitch > fov) then
				return false
			end

		end

		return true
	elseif (str == "jHud") then
		if not IsValid(e) or (ply == e) then
			return false
		end

		if not e:Alive() then
			return false
		end

		if string.find(string.lower(team.GetName(e:Team())), "spec") then
			return false
		end

		if (e:GetMoveType() == MOVETYPE_NONE) then
			return false
		end

		if (e:GetMoveType() == MOVETYPE_OBSERVER) then
			return false
		end

		if not C:IsOnScreen(e) then
			return false
		end

		return true
	elseif (str == "chams") then
		if not IsValid(e) or (ply == e) then
			return false
		end

		if not e:Alive() then
			return false
		end

		if C:IsAdmin(e) and C:G(C.Settings["ignoreadmins"], _num_) then
			return false
		end

		if C:IsTraitor(e) and C:G(C.Settings["ignoretraitors"], _num_) then
			return false
		end

		if C:IsFriend(e) and C:G(C.Settings["ignorefriends"], _num_) then
			return false
		end

		if (e:Team() == ply:Team()) and C:G(C.Settings["aimteam"], _num_) then
			return false
		end

		if string.find(string.lower(team.GetName(e:Team())), "spec") then
			return false
		end

		if (e:GetMoveType() == MOVETYPE_NONE) then
			return false
		end

		if (e:GetMoveType() == MOVETYPE_OBSERVER) then
			return false
		end

		return true
	end

	return false
end

function C:GetPlayerColor(e)
	local vis, invis
	if C:IsTargetValid(e, "chams") then
		vis = Color(_num_, _num_, _num_, _num_)
		invis = Color(_num_, _num_, _num_, _num_)
	else
		vis = Color(_num_, _num_, _num_, _num_)
		invis = Color(_num_, _num_, _num_, _num_)
	end

	return vis, invis
end

print("Looking for nospread")
if file.Exists("lua/bin/gmcl_lordisaboss_win_num_.dll", "MOD") then
	require("lordisaboss")
	C.Vars.nospread = true
	print("Nospread module loaded not _nl_")
	print("Made by gr_num_wn not _nl_")
else
	C.Vars.nospread = false
	print("Nospread module not found_nl_")
	print("Made by gr_num_wn not _nl_")
end

C.ZombieModels = { { "models/zombie/fast_torso.mdl", "ValveBiped.HC_BodyCube" }, { "models/zombie/fast.mdl", "ValveBiped.HC_BodyCube" }, { "models/headcrabclassic.mdl", "HeadcrabClassic.SpineControl" }, { "models/headcrabblack.mdl", "HCBlack.body" }, { "models/headcrab.mdl", "HCFast.body" }, { "models/zombie/poison.mdl", "ValveBiped.Headcrab_Cube_num_" }, { "models/zombie/classic.mdl", "ValveBiped.HC_Body_Bone" }, { "models/zombie/classic_torso.mdl", "ValveBiped.HC_Body_Bone" }, { "models/zombie/zombie_soldier.mdl", "ValveBiped.HC_Body_Bone" } }
function C:GetPosition(e, pos, typ)
		if (tostring(typ) == "attachment") then
		return e:GetAttachment(e:LookupAttachment(pos))
	elseif (tostring(typ) == "bone") then
		return e:GetBonePosition(e:LookupBone(pos))
	end

end

function C:GetTargetLocation(e)
	if C:G(C.Settings["obb"], _num_) then
		return e:LocalToWorld(e:OBBCenter())
	end

	for i = _num_, table.Count(C.ZombieModels) do
		if (e:GetModel() == C.ZombieModels[i][_num_]) then
			return C:GetPosition(e, C.ZombieModels[i][_num_], "bone")
		end

	end

	if (e:LookupAttachment("forward") ~= _num_) then
		local forward = C:GetPosition(e, "forward", "attachment")
		if forward and forward.Pos then
			return forward.Pos
		end

	end

	if (e:LookupAttachment("eyes") ~= _num_) then
		eyes = C:GetPosition(e, "eyes", "attachment")
		if eyes and eyes.Pos then
			return eyes.Pos
		end

	end

	if e:LookupBone("ValveBiped.Bip_num__Head_num_") then
		return C:GetPosition(e, "ValveBiped.Bip_num__Head_num_", "bone")
	end

	return e:LocalToWorld(e:OBBCenter())
end

function C:GetPredictionPos(e)
	return Vector(_num_, _num_, _num_)
end

function C:IsPenetrable(tr)
	local ply, maxpenetration = LocalPlayer(), _num_
	local wep = ply:GetActiveWeapon()
	if (wep.Base == "weapon_mad_base") then
												if (wep.Primary.Ammo == "AirboatGun") then
			maxpenetration = _num_
		elseif (wep.Primary.Ammo == "Gravity") then
			maxpenetration = _num_
		elseif (wep.Primary.Ammo == "AlyxGun") then
			maxpenetration = _num_
		elseif (wep.Primary.Ammo == "Battery") then
		elseif (wep.Primary.Ammo == "StriderMinigun") or (wep.Primary.Ammo == "CombineCannon") then
			maxpenetration = _num_
		elseif (wep.Primary.Ammo == "SniperPenetratedRound") then
			maxpenetration = _num_
		else
			maxpenetration = _num_
		end

		if not tr.Entity:IsPlayer() then
			if ((tr.MatType == MAT_METAL) and wep.Ricochet) or (tr.MatType == MAT_SAND) then
				return false
			end

			local direction = tr.Normal * maxpenetration
			local surfaces = { MAT_GLASS, MAT_PLASTIC, MAT_WOOD, MAT_FLESH, MAT_ALIENFLESH }
			for i = _num_, table.Count(surfaces) do
				if (tr.MatType == surfaces[i]) then
					direction = tr.Normal * (maxpenetration * _num_)
				end

			end

			local trace = util.TraceLine({ start = tr.HitPos + direction, endpos = tr.HitPos, filter = { wep.Owner }, mask = MASK_SHOT })
			if trace.StartSolid or (trace.Fraction >= _num_._num_) or (tr.Fraction <= _num_._num_) then
				return false
			end

		end

	else
		return false
	end

	return true
end

function C:TargetVisible(e)
	local ply = LocalPlayer()
	if C:G(C.Settings["ignorevisibility"], _num_) then
		return true
	end

	local trace = util.TraceLine({ start = ply:GetShootPos(), endpos = C:GetTargetLocation(e) + C:GetPredictionPos(e), filter = { ply, e }, mask = MASK_SHOT + CONTENTS_WINDOW })
	if (trace.Fraction >= _num_._num_) or (C:G(C.Settings["autowall"], _num_) and C:IsPenetrable(trace)) then
		return true
	end

	return false
end

function C:GetAimTarget()
	if C:IsTargetValid(C.Vars.target, "aim") and C:TargetVisible(C.Vars.target) then
		return C.Vars.target
	else
		C.Vars.target = nil
	end

	local ply, tar = LocalPlayer(), { _num_, _num_ }
	if C:G(C.Settings["aim"], _num_) then
		if C.World.rpents.players ~= nil then
			for i = _num_, table.Count(C.World.rpents.players) do
				local e = C.World.rpents.players[i]
				if C:IsTargetValid(e, "aim") and C:TargetVisible(e) then
					local pos = C:GetTargetLocation(e) + C:GetPredictionPos(e)
					local vec = (pos - ply:GetShootPos()):GetNormal()
					local d = math.deg(math.acos(ply:GetAimVector():Dot(vec)))
					if (d < tar[_num_]) or (tar[_num_] == _num_) then
						tar = { e, d }
					end

				end

			end

		end

		return ((tar[_num_] ~= _num_) and (tar[_num_] ~= ply) and tar[_num_]) or nil
	end

end

function C:GetSmoothAngle(ang)
	local ply = LocalPlayer()
	local smoothang = Angle(_num_, _num_, _num_)
	if C:G(C.Settings["aimsmooth"], _num_) then
		local speed = RealFrameTime() / (tonumber(C.Settings["smoothspeed"]) / _num_)
		smoothang = LerpAngle(speed, ply:GetAimVector():Angle(), ang)
	else
		return Angle(ang.p, ang.y, _num_)
	end

	return Angle(smoothang.p, smoothang.y, _num_)
end

function C.OnToggled()
	local ply = LocalPlayer()
	if not IsValid(ply) then
		return 
	end

	C.Vars.aacorrectang = ply:GetAimVector():Angle()
	C.Vars.fakeang = ply:GetAimVector():Angle()
end

C:AddHook("OnToggled", C.OnToggled)
function C.what(cmd)
	local ply, tar = LocalPlayer(), C:GetAimTarget()
	local wep = ply:GetActiveWeapon()
	C.Vars.fakeang.p = math.Clamp(C.Vars.fakeang.p + (cmd:GetMouseY() * _num_._num_), -_num_, _num_)
	C.Vars.fakeang.y = math.NormalizeAngle(C.Vars.fakeang.y + (cmd:GetMouseX() * -_num_._num_))
	if C:G(C.Settings["aimsilent"], _num_) and C:G(C.Settings["antiaim"], _num_) then
		C.Copy.SetViewAngles(cmd, C.Vars.fakeang)
	end

	if C:G(C.Settings["aim"], _num_) and ply:Alive() and tar then
		if C:G(C.Settings["aimprotection"], _num_) then
			if (tar:GetColor(r, g, b, a).a < _num_) then
				return 
			end

		else
			if C:G(C.Settings["spawnprotection_num_"], _num_) then
				if LocalPlayer():GetColor(r, g, b, a).a < _num_ then
					return 
				end

			end

		end

		C.Vars.target = tar
		C.Vars.found = true
		local pos = C:GetTargetLocation(tar) + C:GetPredictionPos(tar)
		pos = pos + Vector(_num_, _num_, tonumber(C.Settings["aimoffset"]))
		local ang = (pos - ply:GetShootPos()):Angle()
		C.Vars.aimingang = ang
		ang = C:GetSmoothAngle(ang)
		ang = Angle(math.NormalizeAngle(ang.p), math.NormalizeAngle(ang.y), _num_)
		if C:G(C.Settings["psilent"], _num_) then
			if C:G(C.Settings["nospread"], _num_) then
				if C:G(C.Settings["snaponfire_num_"], _num_) then
					if C:G(C.Settings["snaponfire"], _num_) then
						if cmd:KeyDown(IN_ATTACK) then
							C.Vars.aimlocked = true
						else
							C.Vars.aimlocked = false
						end

					end

				end

			end

		end

		if C:G(C.Settings["psilent"], _num_) then
			if C:G(C.Settings["nospread"], _num_) then
				if C:G(C.Settings["snaponfire"], _num_) then
					if C:G(C.Settings["snaponfire_num_"], _num_) then
						if input.IsKeyDown(KEY_LALT) then
							C.Vars.aimlocked = true
						else
							C.Vars.aimlocked = false
						end

					end

				end

			end

		end

		if C:G(C.Settings["snaponfire"], _num_) then
			if C:G(C.Settings["psilent"], _num_) then
				if cmd:KeyDown(IN_ATTACK) then
					C.Copy.SetViewAngles(cmd, ang)
					C.Vars.aimlocked = true
				else
					C.Vars.aimlocked = false
				end

			end

		else
			if C:G(C.Settings["snaponfire_num_"], _num_) then
				if C:G(C.Settings["psilent"], _num_) then
					if input.IsKeyDown(KEY_LALT) then
						C.Copy.SetViewAngles(cmd, ang)
						C.Vars.aimlocked = true
					else
						C.Vars.aimlocked = false
					end

				end

			end

		end

		if C:G(C.Settings["autoshoot"], _num_) and not C.Vars.firing then
			RunConsoleCommand("+attack")
			C.Vars.firing = true
			timer.Simple(_num_._num_, function()
				RunConsoleCommand("-attack")
				C.Vars.firing = false
			end)
		end

	else
		C.Vars.target = nil
		C.Vars.aimlocked = false
		C.Vars.found = false
	end

	if C:G(C.Settings["aimsilent"], _num_) and C.Vars.aimlocked then
		local move = Vector(cmd:GetForwardMove(), cmd:GetSideMove(), _num_)
		local norm = move:GetNormal()
		local set = (norm:Angle() + (C.Vars.aimingang - C.Vars.fakeang)):Forward() * move:Length()
		cmd:SetForwardMove(set.x)
		cmd:SetSideMove(set.y)
		cmd:SetUpMove(set.z)
	end

end

function C.TTTPropkill(cmd)
	local ply = LocalPlayer()
	if C:IsTTT() then
				if C:G(C.Settings["pk"], _num_) then
			C.Vars.pkthrowang = cmd:GetViewAngles()
			C.Vars.pkfakeang = C.Vars.pkthrowang - Angle(_num_, _num_, _num_)
			local move = Vector(cmd:GetForwardMove(), cmd:GetSideMove(), _num_)
			local norm = move:GetNormal()
			local ang = ply:GetAimVector():Angle()
			if C:G(C.Settings["aimsilent"], _num_) then
				ang = C.Vars.fakeang
			end

			local set = (norm:Angle() + (C.Vars.pkfakeang - ang)):Forward() * move:Length()
			cmd:SetForwardMove(set.x)
			cmd:SetSideMove(set.y)
		elseif not C.Vars.pkfake and C.Vars.pkthrow then
			C.Vars.pkthrow = false
			C.Copy.SetViewAngles(cmd, C.Vars.pkfakeang)
			if C:G(C.Settings["aimsilent"], _num_) then
				C.Vars.fakeang = C.Vars.pkfakeang
				C.Copy.SetViewAngles(cmd, C.Vars.fakeang)
			end

		else
			C.Vars.pkthrowang = cmd:GetViewAngles()
			C.Vars.pkfakeang = C.Vars.pkthrowang
		end

	end

end

function C.Bunnyhop(cmd)
	local ply = LocalPlayer()
	if C:G(C.Settings["bhop"], _num_) then
		if (ply:GetMoveType() ~= MOVETYPE_WALK) then
			return 
		end

		if ply and cmd:KeyDown(IN_JUMP) then
			if ply:IsOnGround() then
				cmd:SetButtons(cmd:GetButtons(), IN_JUMP)
			else
				cmd:SetButtons(cmd:GetButtons() - IN_JUMP)
			end

		end

	end

end

function C.aimoftheanti(cmd, u)
	local curview = cmd:GetViewAngles()
	if C:G(C.Settings["antiaim"], _num_) then
		local ply = LocalPlayer()
		if not C.Vars.firing then
			local v = cmd:GetViewAngles()
			cmd:SetViewAngles(Angle(-_num_, v.y, _num_))
		else
			LocalPlayer():SetEyeAngles(aacorrectang)
		end

	end

end

function C.anti_num_(cmd, u)
	local curview = cmd:GetViewAngles()
	if C:G(C.Settings["antiaim_num_"], _num_) then
		local ply = LocalPlayer()
		if not C.Vars.firing then
			local v = cmd:GetViewAngles()
			cmd:SetViewAngles(Angle(-_num_, -_num_, -_num_))
		else
			LocalPlayer():SetEyeAngles(curview)
		end

	end

end

function C.CalcView(e, origin, angles)
	local ply = LocalPlayer()
	local wep = ply:GetActiveWeapon()
	if wep.Primary then
		wep.Primary.Recoil = _num_
	end

	if wep.Secondary then
		wep.Secondary.Recoil = _num_
	end

	if GAMEMODE:CalcView(e, origin, angles) ~= nil then
		local view = GAMEMODE:CalcView(e, origin, angles) or {  }
		if C:G(C.Settings["calcview"], _num_) then
																		if C.Vars.pkfake and C:IsTTT() then
				view.angles = C.Vars.pkfakeang
			elseif C.Vars.aimlocked and C:G(C.Settings["aimsmooth"], _num_) and C:G(C.Settings["aimsilent"], _num_) then
				view.angles = ply:GetAimVector():Angle()
			elseif C.Vars.aimlocked and C:G(C.Settings["aimsilent"], _num_) then
				view.angles = C.Vars.aimingang
			elseif C:G(C.Settings["aimsilent"], _num_) or C:G(C.Settings["antiaim"], _num_) then
				view.angles = C.Vars.fakeang
			elseif C:G(C.Settings["aimsilent"], _num_) and C:G(C.Settings["novisrecoil"], _num_) then
				view.angles = C.Vars.fakeang
			elseif C:G(C.Settings["novisrecoil"], _num_) and C:G(C.Settings["aimsilent"], _num_) then
				view.angles = ply:GetAimVector():Angle()
			else
				view = GAMEMODE:CalcView(e, origin, angles)
			end

		else
			view = GAMEMODE:CalcView(e, origin, angles)
		end

		return view
	end

end

C:AddHook("CalcView", C.CalcView)
function C.DrawTargetLine()
	local w, h = ScrW() / _num_, ScrH() / _num_
	if C:G(C.Settings["jHud"], _num_) and C:G(C.Settings["aim"], _num_) and C:G(C.Settings["targetjHud"], _num_) then
		if (C.Vars.target ~= nil) then
			if C:IsTargetValid(C.Vars.target, "jHud") then
				local pos = C:GetTargetLocation(C.Vars.target):ToScreen()
				surface.SetDrawColor(team.GetColor(C.Vars.target:Team()))
				surface.DrawLine(w, h, pos.x, pos.y)
			end

		end

	end

end

function C:GetStatusColor(e)
	local pos = C:GetTargetLocation(e):ToScreen()
	local statuscol = Color(_num_, _num_, _num_, _num_)
			if C:IsFriend(e) then
		statuscol = Color(_num_, _num_, _num_, _num_)
	elseif C:IsAdmin(e) then
		statuscol = Color(_num_, _num_, _num_, _num_)
	elseif C:IsTraitor(e) and C:IsTTT() then
		statuscol = Color(_num_, _num_, _num_, _num_)
	else
		statuscol = Color(_num_, _num_, _num_, _num_)
	end

	return statuscol
end

function C:DrawPlayerInfo(e, pos)
	draw.SimpleTextOutlined(string.Left(tostring(e:Nick()), _num_), "Default", pos.x, pos.y - _num_, C:GetStatusColor(e), TEXT_ALIGN_CENTER, TEXT_ALIGN_BOTTOM, _num_, Color(_num_, _num_, _num_, _num_))
	local col = Color(_num_, _num_, _num_, _num_)
	if (e:Health() <= _num_) and (e:Health() > _num_) then
		col = Color(_num_, _num_._num_ * e:Health(), _num_._num_ * e:Health(), _num_)
	else
		col = Color(_num_, _num_, _num_, _num_)
	end

	draw.SimpleTextOutlined(("Health: " .. tostring(e:Health())), "Default", pos.x, pos.y - _num_, col, TEXT_ALIGN_CENTER, TEXT_ALIGN_BOTTOM, _num_, Color(_num_, _num_, _num_, _num_))
end

function C.DrawPlayerjHud()
	local ply = LocalPlayer()
	if C:G(C.Settings["jHud"], _num_) and C:G(C.Settings["infojHud"], _num_) then
		if C.World.rpents.players ~= nil then
			for i = _num_, table.Count(C.World.rpents.players) do
				local e = C.World.rpents.players[i]
				if C:IsTargetValid(e, "jHud") then
					local pos = (C:GetTargetLocation(e) + Vector(_num_, _num_, _num_)):ToScreen()
					C:DrawPlayerInfo(e, pos)
				end

			end

		end

	end

end

function C.DrawAdminList()
	if C:G(C.Settings["jHud"], _num_) and C:G(C.Settings["adminlist"], _num_) then
		local admins, w, h, y = {  }, ScrW(), ScrH(), _num_
		draw.SimpleTextOutlined("ADMINS:", "Default", w - (w - _num_), (h - h) + _num_, Color(_num_, _num_, _num_, _num_), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER, _num_, Color(_num_, _num_, _num_, _num_))
		if C.World.rpents.players ~= nil then
			for i = _num_, table.Count(C.World.rpents.players) do
				local e = C.World.rpents.players[i]
				if IsValid(e) and C:IsAdmin(e) then
					table.insert(admins, e:Nick())
				end

			end

			for i = _num_, table.Count(admins) do
				draw.SimpleTextOutlined(tostring(admins[i]), "Default", w - (w - _num_), ((h - h) + _num_) + y, Color(_num_, _num_, _num_, _num_), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER, _num_, Color(_num_, _num_, _num_, _num_))
				y = y + _num_
			end

		end

	end

end

C.World.rpents = {  }
function C:DrawRPEntities()
	if C:G(C.Settings["jHud"], _num_) and C:G(C.Settings["rpjHud"], _num_) then
		for i = _num_, table.Count(C.World.rpents) do
			if C.World.rpents[i] ~= nil then
				local ent = ents.FindByClass(C.World.rpents[i])
				for e = _num_, table.Count(ent) do
					local pos = ent[e]:GetPos():ToScreen()
					draw.SimpleTextOutlined(tostring(C.World.rpents[i]), "DefaultSmall", pos.x, pos.y, Color(_num_, _num_, _num_, _num_), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, _num_, Color(_num_, _num_, _num_, _num_))
				end

			end

		end

	end

end

C.traitors = {  }
C.World.rpents.traitorweapons = {  }
function C.DrawTraitorWeapons()
	if C:G(C.Settings["jHud"], _num_) then
		if C:G(C.Settings["traitorwepjHud"], _num_) and C:IsTTT() then
			for _, e in pairs(ents.GetAll()) do
				if (e.CanBuy and table.HasValue(e.CanBuy, ROLE_TRAITOR) and not table.HasValue(C.World.rpents.traitorweapons, e)) then
										if (e:GetMoveType() == MOVETYPE_NONE) then
						table.insert(C.World.rpents.traitorweapons, e)
						local v = e.Owner
						if (v:Alive() and not v:IsDetective()) then
							if (not table.HasValue(C.traitors, v)) then
								table.insert(C.traitors, v)
							end

						end

					elseif (e:GetMoveType() ~= MOVETYPE_NONE) then
						table.insert(C.World.rpents.traitorweapons, e)
					end

				end

			end

		end

	end

end

function C.DrawCrosshair()
	if C:G(C.Settings["crosshair"], _num_) then
		local w, h = ScrW() / _num_, ScrH() / _num_
		local e_num_, e_num_ = _num_, _num_
		if C:G(C.Settings["aim"], _num_) then
			surface.SetDrawColor(_num_, _num_, _num_, _num_)
		else
			surface.SetDrawColor(_num_, _num_, _num_, _num_)
		end

		surface.DrawLine(w - e_num_, h, w, h)
		surface.DrawLine(w + e_num_, h, w, h)
		surface.DrawLine(w, h - e_num_, w, h)
		surface.DrawLine(w, h + e_num_, w, h)
				if C.Vars.found and not C.Vars.aimlocked then
			surface.SetDrawColor(_num_, _num_, _num_, _num_)
			surface.DrawOutlinedRect((w - e_num_) - _num_, (h - e_num_) - _num_, ((e_num_ + _num_) * _num_) + _num_, ((e_num_ + _num_) * _num_) + _num_)
		elseif C.Vars.found and C.Vars.aimlocked then
			surface.SetDrawColor(_num_, _num_, _num_, _num_)
			surface.DrawLine(w - e_num_, h, w - e_num_, h)
			surface.DrawLine(w + e_num_, h, w + e_num_, h)
			surface.DrawLine(w, h - e_num_, w, h - e_num_)
			surface.DrawLine(w, h + e_num_, w, h + e_num_)
		end

		if C.Vars.found and (C.Vars.target ~= nil) then
			draw.SimpleTextOutlined("Target: " .. string.Left(tostring(C.Vars.target:Nick()), _num_), "Default", w, h + _num_, Color(_num_, _num_, _num_, _num_), TEXT_ALIGN_CENTER, TEXT_ALIGN_BOTTOM, _num_, Color(_num_, _num_, _num_, _num_))
		end

	end

end

function C:GetChamsMaterial()
	local params = { ["$basetexture"] = "models/debug/debugwhite", ["$model"] = _num_, ["$ignorez"] = _num_ }
	return CreateMaterial("\_num_\_num_", "VertexLitGeneric", params)
end

function C.RenderScreenspaceEffects()
	if C:G(C.Settings["jHud"], _num_) and C:G(C.Settings["chams"], _num_) then
		cam.Start_num_D(EyePos(), EyeAngles())
		render.SuppressEngineLighting(tobool(C.Settings["renderfullbright"]))
		render.MaterialOverride(C:GetChamsMaterial())
		if C.World.rpents.players ~= nil then
			for i = _num_, table.Count(C.World.rpents.players) do
				local e = C.World.rpents.players[i]
				local vis, invis = C:GetPlayerColor(e)
				if C:IsTargetValid(e, "jHud") then
					render.SetColorModulation((invis.r / _num_), (invis.g / _num_), (invis.b / _num_))
					e:DrawModel()
				end

			end

			render.MaterialOverride()
			if C.World.rpents.players ~= nil then
				for i = _num_, table.Count(C.World.rpents.players) do
					local e = C.World.rpents.players[i]
					local vis, invis = C:GetPlayerColor(e)
					if C:IsTargetValid(e, "jHud") then
						render.SetColorModulation((vis.r / _num_), (vis.g / _num_), (vis.b / _num_))
						e:SetMaterial("models/debug/debugwhite")
						e:DrawModel()
						e:SetMaterial("")
					end

				end

				render.SuppressEngineLighting(false)
				cam.End_num_D()
			end

		end

	end

end

C:AddHook("RenderScreenspaceEffects", C.RenderScreenspaceEffects)
function C.UnGag()
	local ply = LocalPlayer()
	if ply and C:G(C.Settings["ungag"], _num_) then
		if ulx and ulx.gagUser then
			ulx.gagUser(false)
			C.Copy.hook.Remove("PlayerBindPress", "ULXGagForce")
			timer.Destroy("GagLocalPlayer")
		end

		if evolve then
			ply:SetNWBool("Muted", false)
		end

	end

end

function concommand.Add(cmd, func)
	C:Log("concommand.Add: " .. cmd .. " [" .. debug.getinfo(_num_).short_src .. "]")
	return old_ccadd(cmd, func)
end

function concommand.Remove(cmd)
	C:Log("concommand.Remove: " .. cmd .. " [" .. debug.getinfo(_num_).short_src .. "]")
	return old_ccrem(cmd)
end

function RunString(s)
	C:Log("RunString: " .. tostring(s) .. " [" .. debug.getinfo(_num_).short_src .. "]")
	return old_rs(s)
end

function file.Delete(fn)
	if not table.HasValue(C.Modules, fn) then
		C:Log("file.Delete: " .. fn .. " [" .. debug.getinfo(_num_).short_src .. "]")
		return old_filedel(fn)
	else
		C:Log("BLOCKED file.Delete: " .. fn .. " [" .. debug.getinfo(_num_).short_src .. "]")
		return 
	end

end

function file.Exists(fn, ad)
	if C.Modules ~= nil then
		if not table.HasValue(C.Modules, fn) then
			C:Log("file.Exists: " .. fn .. " [" .. debug.getinfo(_num_).short_src .. "]")
			return old_fileexist(fn, ad)
		else
			C:Log("BLOCKED file.Exists: " .. fn .. " [" .. debug.getinfo(_num_).short_src .. "]")
			return 
		end

	end

end

function file.Find(fn)
	if not table.HasValue(C.Modules, fn) then
		C:Log("file.Find: " .. fn .. " [" .. debug.getinfo(_num_).short_src .. "]")
		return old_filefind(fn)
	else
		C:Log("BLOCKED file.Find: " .. fn .. " [" .. debug.getinfo(_num_).short_src .. "]")
		return 
	end

end

function file.Read(fn, ad)
	if not table.HasValue(C.Modules, fn) then
		C:Log("file.Read: " .. fn .. " [" .. debug.getinfo(_num_).short_src .. "]")
		return old_fileread(fn, ad)
	else
		C:Log("BLOCKED file.Read: " .. fn .. " [" .. debug.getinfo(_num_).short_src .. "]")
		return 
	end

end

function file.Write(fn, data)
	C:Log("file.Write: " .. fn .. " [" .. debug.getinfo(_num_).short_src .. "]")
	return old_filewrite(fn, data)
end

function timer.Create(index, sec, rep, func)
	C:Log("timer.Create: " .. index .. " [" .. debug.getinfo(_num_).short_src .. "]")
	return old_timerc(index, sec, rep, func)
end

function C.GetAllPlayers()
	C.World.rpents.players = {  }
	for i = _num_, table.Count(player.GetAll()) do
		local e = player.GetAll()[i]
		if IsValid(e) then
			table.insert(C.World.rpents.players, e)
		end

	end

end

function C.CreateMove(cmd)
	C.what(cmd)
	C.Bunnyhop(cmd)
	C.TTTPropkill(cmd)
	C.anti_num_(cmd, u)
	C.aimoftheanti(cmd, u)
	if (C.Vars.aimlocked and C:G(C.Settings["nospread"], _num_) and C.Vars.nospread) then
		local active = false
		local pos = C:GetTargetLocation(C.Vars.target) + C:GetPredictionPos(C.Vars.target)
		local ply = LocalPlayer()
		local weapon = ply:GetActiveWeapon()
				if IsValid(weapon) and weapon.Primary and weapon.Primary.Cone and pos ~= nil then
			local ang = (pos - ply:GetShootPos()):Angle()
			local vecCone = Vector(-weapon.Primary.Cone, -weapon.Primary.Cone, _num_)
			ang = DS_manipulateShot(DS_md_num_PseudoRandom(DS_getUCMDCommandNumber(cmd)), ang:Forward(), vecCone):Angle()
			cmd:SetViewAngles(ang)
		elseif IsValid(weapon) and weapon.Cone and pos ~= nil then
			local ang = (pos - ply:GetShootPos()):Angle()
			local vecCone = Vector(-weapon.Cone, -weapon.Cone, _num_)
			ang = DS_manipulateShot(DS_md_num_PseudoRandom(DS_getUCMDCommandNumber(cmd)), ang:Forward(), vecCone):Angle()
			cmd:SetViewAngles(ang)
		end

	end

end

C:AddHook("CreateMove", C.CreateMove)
function C.HUDPaintHook()
	C.DrawTargetLine()
	C.DrawPlayerjHud()
	C.DrawAdminList()
	C.DrawRPEntities()
	C.DrawTraitorWeapons()
	C.DrawCrosshair()
end

C:AddHook("HUDPaint", C.HUDPaintHook)
function C.ThinkHook()
	C.GetAllPlayers()
	C.UnGag()
end

C:AddHook("Think", C.ThinkHook)
function C:b_num_x(e, pos)
	for k, e in pairs(player.GetAll()) do
		if e ~= LocalPlayer() and IsValid(e) and e:Team() ~= TEAM_SPECTATOR then
			local Bottom = (e:GetPos() + Vector(_num_, _num_, _num_)):ToScreen()
			local Top = (e:GetPos() + Vector(_num_, _num_, _num_)):ToScreen()
			local Height = (Bottom.y - Top.y)
			local Width = (Height / _num_)
			if C:G(C.Settings["jHud"], _num_) and C:G(C.Settings["box"], _num_) then
				if e:Alive() then
					surface.SetDrawColor(C:GetStatusColor(e))
					surface.DrawOutlinedRect(Top.x - Width, Top.y, Width * _num_, Height)
					surface.SetDrawColor(C:GetStatusColor(e))
				end

			end

		end

	end

end

C:AddHook("HUDPaint", C.b_num_x)
function C:DrawPlayerInfo(e, pos)
	draw.SimpleTextOutlined(string.Left(tostring(e:Nick()), _num_), "Default", pos.x, pos.y - _num_, C:GetStatusColor(e), TEXT_ALIGN_CENTER, TEXT_ALIGN_BOTTOM, _num_, Color(_num_, _num_, _num_, _num_))
	local col = Color(_num_, _num_, _num_, _num_)
	if (e:Health() <= _num_) and (e:Health() > _num_) then
		col = Color(_num_, _num_._num_ * e:Health(), _num_._num_ * e:Health(), _num_)
	else
		col = Color(_num_, _num_, _num_, _num_)
	end

	draw.SimpleTextOutlined("Health: " .. e:Health(), "Default", pos.x, pos.y - _num_, col, TEXT_ALIGN_CENTER, TEXT_ALIGN_BOTTOM, _num_, Color(_num_, _num_, _num_, _num_))
end

function C.Menu()
	local w, h, s = ScrW() / _num_, ScrH() / _num_, _num_
	local x, y = _num_, _num_
	local px, py = x - _num_, y - _num_
	local tx, ty = x - _num_, y - _num_
	C.panel = vgui.Create("DFrame")
	C.panel:SetPos(w - x / _num_, h - y / _num_)
	C.panel:SetSize(x, y)
	C.panel:SetTitle(":: eH H_num_k :: Made by eH Gr_num_wn")
	C.panel:SetVisible(true)
	C.panel:SetDraggable(true)
	C.panel:ShowCloseButton(true)
	C.panel:MakePopup()
	C.panel.Paint = function()
		draw.RoundedBox(_num_, _num_, _num_, x, y, Color(_num_, _num_, _num_, _num_))
		surface.SetDrawColor(Color(_num_, _num_, _num_, _num_))
		surface.DrawOutlinedRect(_num_, _num_, x, y)
	end
	local page = vgui.Create("DPropertySheet")
	page:SetParent(C.panel)
	page:SetPos(_num_, _num_)
	page:SetSize(px, py)
	page.Paint = function()
		draw.RoundedBox(_num_, _num_, _num_, px, py, Color(_num_, _num_, _num_, _num_))
	end
	local aim = vgui.Create("DPanel", page)
	aim.Paint = function()
		draw.RoundedBox(_num_, _num_, _num_, tx, ty, Color(_num_, _num_, _num_, _num_))
		surface.SetDrawColor(Color(_num_, _num_, _num_, _num_))
		surface.DrawOutlinedRect(_num_, _num_, tx, ty)
	end
	local aimlist = vgui.Create("DPanelList")
	aimlist:SetPos(_num_, _num_)
	aimlist:SetParent(aim)
	aimlist:SetSize(tx - _num_, ty - _num_)
	aimlist:EnableVerticalScrollbar(true)
	aimlist:SetSpacing(s)
	aimlist.Paint = function()
		draw.RoundedBox(_num_, _num_, _num_, tx - _num_, ty - _num_, Color(_num_, _num_, _num_, _num_))
	end
	local jHud = vgui.Create("DPanel", page)
	jHud.Paint = function()
		draw.RoundedBox(_num_, _num_, _num_, tx, ty, Color(_num_, _num_, _num_, _num_))
		surface.SetDrawColor(Color(_num_, _num_, _num_, _num_))
		surface.DrawOutlinedRect(_num_, _num_, tx, ty)
	end
	local jHudlist = vgui.Create("DPanelList")
	jHudlist:SetPos(_num_, _num_)
	jHudlist:SetParent(jHud)
	jHudlist:SetSize(tx - _num_, ty - _num_)
	jHudlist:EnableVerticalScrollbar(true)
	jHudlist:SetSpacing(s)
	jHudlist.Paint = function()
		draw.RoundedBox(_num_, _num_, _num_, tx - _num_, ty - _num_, Color(_num_, _num_, _num_, _num_))
	end
	local misc = vgui.Create("DPanel", page)
	misc.Paint = function()
		draw.RoundedBox(_num_, _num_, _num_, tx, ty, Color(_num_, _num_, _num_, _num_))
		surface.SetDrawColor(Color(_num_, _num_, _num_, _num_))
		surface.DrawOutlinedRect(_num_, _num_, tx, ty)
	end
	local misclist = vgui.Create("DPanelList")
	misclist:SetPos(_num_, _num_)
	misclist:SetParent(misc)
	misclist:SetSize(tx - _num_, ty - _num_)
	misclist:EnableVerticalScrollbar(true)
	misclist:SetSpacing(s)
	misclist.Paint = function()
		draw.RoundedBox(_num_, _num_, _num_, tx - _num_, ty - _num_, Color(_num_, _num_, _num_, _num_))
	end
	for _, v in ipairs(C.MenuInfo) do
				if (v.Type == "bool") then
			local checkbox = vgui.Create("DCheckBoxLabel")
			checkbox:SetText(v.Desc)
			checkbox:SetConVar(v.Name)
			checkbox:SetValue(GetConVarNumber(v.Name))
			checkbox:SetTextColor(Color(_num_, _num_, _num_, _num_))
									if (v.Menu == "aim") then
				aimlist:AddItem(checkbox)
			elseif (v.Menu == "jHud") then
				jHudlist:AddItem(checkbox)
			elseif (v.Menu == "misc") then
				misclist:AddItem(checkbox)
			end

		elseif (v.Type == "number") then
			local slider = vgui.Create("DNumSlider")
			slider:SetText("")
			slider:SetMax(v.Max or _num_)
			slider:SetMin(v.Min or _num_)
			slider:SetDecimals(_num_)
			slider:SetConVar(v.Name)
			slider:SetValue(GetConVarNumber(v.Name))
			local label = vgui.Create("DLabel")
			label:SetParent(slider)
			label:SetWide(_num_)
			label:SetText(v.Desc)
			label:SetTextColor(Color(_num_, _num_, _num_, _num_))
									if (v.Menu == "aim") then
				aimlist:AddItem(slider)
			elseif (v.Menu == "jHud") then
				jHudlist:AddItem(slider)
			elseif (v.Menu == "misc") then
				misclist:AddItem(slider)
			end

		end

	end

	local label = vgui.Create("DLabel")
	label:SetText("Prediction Type")
	label:SetTextColor(Color(_num_, _num_, _num_, _num_))
	aimlist:AddItem(label)
	aimlist:AddItem(multichoice)
	local button = vgui.Create("DButton")
	button:SetText("No Name")
	button.DoClick = function()
	end
	misclist:AddItem(button)
	local button = vgui.Create("DButton")
	button:SetText("Steal Random Name")
	button.DoClick = function()
	end
	misclist:AddItem(button)
	local log = vgui.Create("DPanel", page)
	log.Paint = function()
		draw.RoundedBox(_num_, _num_, _num_, tx, ty, Color(_num_, _num_, _num_, _num_))
		surface.SetDrawColor(Color(_num_, _num_, _num_, _num_))
		surface.DrawOutlinedRect(_num_, _num_, tx, ty)
	end
	local LogPanel = vgui.Create("DPanelList", log)
	LogPanel:SetPos(_num_, _num_)
	LogPanel:SetSize(page:GetWide() - _num_, _num_)
	LogPanel:SetSpacing(_num_)
	LogPanel:EnableHorizontal(false)
	LogPanel:EnableVerticalScrollbar(false)
	local DLog = vgui.Create("DListView", LogPanel)
	DLog:SetPos(_num_, _num_)
	DLog:SetMultiSelect(false)
	DLog:SetSize(LogPanel:GetWide() - _num_, LogPanel:GetTall() - _num_)
	DLog:AddColumn("Log")
	DLog:SetMultiline(true)
	for i = #C.funclog, _num_, -_num_ do
		DLog:AddLine(C.funclog[i])
	end

	local ClearLogs = vgui.Create("DButton", log)
	ClearLogs:SetText("Clear log")
	ClearLogs:SetPos(_num_, _num_)
	ClearLogs:SetSize(_num_, _num_)
	ClearLogs.DoClick = function()
		C.funclog = {  }
		MsgC(Color(_num_, _num_, _num_), ":: ", Color(_num_, _num_, _num_), "Cleared log._nl_")
	end
	local EntityjHud = vgui.Create("DListView", EntityjHud)
	EntityjHud:SetPos(_num_, _num_)
	EntityjHud:SetSize(_num_, _num_)
	EntityjHud:AddColumn("Not On ESP")
	for k, v in pairs(ents.GetAll()) do
		if (not table.HasValue(C.World.rpents, v:GetClass()) and not table.HasValue(C.BadEnts, v:GetClass())) then
			EntityjHud:AddLine(v:GetClass())
		end

	end

	local CustomEnts = vgui.Create("DListView", EntityjHud)
	CustomEnts:SetPos(_num_, _num_)
	CustomEnts:SetSize(_num_, _num_)
	CustomEnts:AddColumn("On ESP")
	for k, v in pairs(C.World.rpents) do
		CustomEnts:AddLine(v)
	end

	local ButtonAdd = vgui.Create("DButton", EntityjHud)
	ButtonAdd:SetText("-->")
	ButtonAdd:SetSize(_num_, _num_)
	ButtonAdd:SetPos(_num_, _num_)
	ButtonAdd.DoClick = function()
		local line = EntityjHud:GetSelectedLine()
		if line ~= nil then
			local entclass = EntityjHud:GetLine(line):GetValue(_num_)
			if not table.HasValue(C.World.rpents, entclass) then
				table.insert(C.World.rpents, entclass)
				CustomEnts:AddLine(entclass)
				EntityjHud:RemoveLine(line)
			end

		end

	end
	local ButtonRemove = vgui.Create("DButton", EntityjHud)
	ButtonRemove:SetText("<--")
	ButtonRemove:SetSize(_num_, _num_)
	ButtonRemove:SetPos(_num_, _num_)
	ButtonRemove.DoClick = function()
		local line = CustomEnts:GetSelectedLine()
		if line ~= nil then
			local entclass = CustomEnts:GetLine(line):GetValue(_num_)
			if table.HasValue(C.World.rpents, entclass) then
				for k, v in pairs(C.World.rpents) do
					if v == entclass then
						table.remove(C.World.rpents, k)
					end

				end

				EntityjHud:AddLine(entclass)
				CustomEnts:RemoveLine(line)
			end

		end

	end
	page:AddSheet("what", aim, nil, false, false, nil)
	page:AddSheet("jHud", jHud, nil, false, false, nil)
	page:AddSheet("Misc", misc, nil, false, false, nil)
	page:AddSheet("Log", log, nil, false, false, nil)
	page:AddSheet("Entity jHud", EntityjHud, nil, false, false, nil)
end

C:AddCommand("datmenu", C.Menu)
C:Log("Successfully loaded.")
