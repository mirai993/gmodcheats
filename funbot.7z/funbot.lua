--[[
	lua/FunBot.lua
	DJ Simple | (STEAM_0:1:60333045)
	===DStream===
]]

-- Fun bot by simple
-- Round one

-- Locals
local FB = {}
local client = LocalPlayer()
local CCCV = CreateClientConVar;
local GCVN = GetConVarNumber;
local Name = ( 'FunBot [v1] ' )
local SpamMessage = GetConVarString("fb_misc_spam_message")
local TAC 	= TEXT_ALIGN_CENTER;
local TAL 	= TEXT_ALIGN_LEFT;
local TAR	= TEXT_ALIGN_RIGHT;

local Colors				= {}
Red							= Color(255,0,0,255);
Black						= Color(0,0,0,255);
Green						= Color(0,255,0,255);
Orange						= Color(255,100,0,255);
White						= Color(255,255,255,255);
Blue						= Color(0,0,255,255);
Cyan						= Color(0,255,255,255);
Pink 						= Color(255,0,255,255);
Blue						= Color(0,0,255,255);
Grey						= Color(100,100,100,255);
Gold						= Color(255,228,0,255);

-- Require
require('cvar3')

-- Client Stuff
if ( not CLIENT ) then
	client:ChatPrint('[FB] Running Server-Side')
else
	client:ChatPrint('[FB] Running Client-Side')
end

-- CVars

-- ESP
CCCV('fb_esp_info', 				0, true, false)
CCCV('fb_esp_healthbar', 			0, true, false)
CCCV('fb_esp_dead', 				0, true, false)
CCCV('fb_esp_ESPNPC', 				0, true, false)
CCCV('fb_esp_playerbox', 			1, true, false)
-- Visual
CCCV('fb_vis_cheatinfobox', 1, true, false)

-- Removels
CCCV('fb_rem_skybox', 0, true, false)
CCCV('fb_rem_recoil', 0, true, false)

-- Misc
CCCV('fb_misc_cheats', 0, true, false)
CCCV('fb_misc_bhop', 0, true, false)
CCCV('fb_misc_chatspam', 0, true, false)
CCCV('fb_misc_spam_message', "test", true, false)




-- Core

-- ESP
function ESP()
	if( GCVN('fb_esp_info') == 1 ) then
		for k, v in pairs( player.GetAll() ) do
			if IsValid( v ) then
				if v ~= LocalPlayer() then
					local Pos = ( v:EyePos() ):ToScreen()
						if v:Alive() and v:Team() ~= TEAM_SPECTATOR then
						draw.SimpleText( "N: "	..v:Nick(), "TabLarge", Pos.x + 25, Pos.y, Green, TAL, TAC ) 
						draw.SimpleText( "H: "	..v:Health(), "TabLarge", Pos.x + 25, Pos.y + 10, Green, TAL, TAC)
						if v:IsAdmin() then
						draw.SimpleText( "Admin", "TabLarge", Pos.x + 25, Pos.y - 20, Red, TAL, TAC )
					end
						if v:GetFriendStatus() == "friend" then
						draw.SimpleText( "Friends", "TabLarge", Pos.x + 25, Pos.y - 10, Blue, TAL, TAC )
					end
				end
			end
		end
	end
end
if( GCVN('fb_esp_healthbar') >= 1 ) then
		for k, v in pairs( player.GetAll() ) do
			if IsValid( v ) then
				if v ~= LocalPlayer() then
				local Pos = ( v:EyePos() ):ToScreen()
				if v:Health() >= 75 then
				HPColor = Green
				elseif v:Health() >= 35 and v:Health() < 75 then
				HPColor = Gold
				elseif v:Health() < 35 then
				HPColor = Red
			end
				draw.RoundedBox( 0, Pos.x-20, Pos.y-30, 42, 6,Color(0,0,0,255))
				draw.RoundedBox( 0, Pos.x-20, Pos.y-30, 0.4 * math.Clamp( v:Health(), 1, 100 ), 4,HPColor)
			end
if( GCVN('fb_esp_dead') >= 1 ) then
		for k, v in pairs( player.GetAll() ) do
			if IsValid( v ) then
				if v ~= LocalPlayer() then
				local Pos = ( v:EyePos() ):ToScreen()
					if v:Health() < 1 then
					draw.SimpleText( "-[Dead]- ( " .. v:Nick() .. " )", "TargetID", Pos.x, Pos.y - 10, Red, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
				end
			end

if GCVN( "fb_esp_NPCESP" ) >= 1 then
	for k, v in pairs( ents.GetAll() ) do
		if IsValid( v ) then
			if v:IsNPC() then
				local NpcESPPos = ( v:EyePos() ):ToScreen()
					draw.SimpleText( v:GetClass(), "TabLarge", NpcESPPos.x, NpcESPPos.y - 22, Color( 255, 0, 0, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
				end
			end
		end
	end
end


if GCVN("fb_esp_playerbox") == 1 then
	for k, v in pairs ( player.GetAll() ) do
		if v ~= LocalPlayer() then
			if v:Alive() and v:Team() ~= TEAM_SPECTATOR then
				local PlayerBoxPos = v:EyePos():ToScreen()
				surface.SetDrawColor( team.GetColor( v:Team() ) )
				surface.DrawOutlinedRect( PlayerBoxPos.x - 40 / 2, PlayerBoxPos.y - 40 / 2, 40, 80 )
									end
								end
							end
						end
					end
				end
			end
		end
	end
end


-- Visuals

-- cheat info
function CheatInfo()
	if( GCVN( 'fb_vis_cheatinfobox' ) == 1 ) then
	draw.RoundedBox(10, 1600, ScrH() - 1075, 300, 425, Color(25,25,25,200))
	draw.SimpleTextOutlined( Name .. " by SimpleIsTheBest", "TargetID", 10, 10, g, 0, 0, 1, b )
	draw.SimpleText("Removeles Information: ", "TargetID", 0 + 1610, ScrH() - 725, Color(255,255,255), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
	draw.SimpleText("Other Information: ", "TargetID", 0 + 1610, ScrH() - 800, Color(255,255,255), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
	draw.SimpleText("Misc Information: ", "TargetID", 0 + 1610, ScrH() - 900, Color(255,255,255), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
	draw.SimpleText("ESP Information: ", "TargetID", 0 + 1610, ScrH() - 1050, Color(255,255,255), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
			if( GetConVarNumber('fb_esp_info') == 1 ) then
				draw.SimpleText( "ESP Info = [ On ] ", "TargetID", 0 + 1610, ScrH() - 1025, Color(0,255,0), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
			else
				draw.SimpleText(" ESP Info = [ Off ] ", "TargetID", 0 + 1610, ScrH() - 1025, Color(255,0,0), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
			end
			if( GetConVarNumber('fb_esp_healthbar') == 1 ) then
				draw.SimpleText("HealthBar = [ On ] ", "TargetID", 0 + 1610, ScrH() - 1000, Color(0,255,0), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
			else
				draw.SimpleText("HealthBar = [ Off ]", "TargetID", 0 + 1610, ScrH() - 1000, Color(255,0,0), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
			end
		    if( GetConVarNumber('fb_esp_dead') == 1 ) then
				draw.SimpleText("Dead Info = [ On ] ", "TargetID", 0 + 1610, ScrH() - 975, Color(0,255,0), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
			else
				draw.SimpleText("Dead Info = [ Off ] ", "TargetID", 0 + 1610, ScrH() - 975, Color(255,0,0), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
			end
			if( GetConVarNumber('fb_esp_NPCESP') == 1 ) then
				draw.SimpleText("NPC ESP = [ On ] ", "TargetID", 0 + 1610, ScrH() - 950, Color(0,255,0), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
			else
				draw.SimpleText("NPC ESP = [ Off ] ", "TargetID", 0 + 1610, ScrH() - 950, Color(255,0,0), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
			end
			if( GetConVarNumber('fb_esp_playerbox') == 1 ) then
				draw.SimpleText("PlayerBox ESP = [ On ] ", "TargetID", 0 + 1610, ScrH() - 925, Color(0,255,0), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
			else
				draw.SimpleText("PlayerBox ESP = [ Off ] ", "TargetID", 0 + 1610, ScrH() - 925, Color(255,0,0), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
			end
			if( GetConVarNumber('fb_misc_cheats') == 1 ) then
				draw.SimpleText("Cheat Bypass = [ On ] ", "TargetID", 0 + 1610, ScrH() - 875, Color(0,255,0), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
			else
				draw.SimpleText("Cheat Bypass = [ Off ] ", "TargetID", 0 + 1610, ScrH() - 875, Color(255,0,0), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
			end
			if( GetConVarNumber('fb_misc_bhop') == 1 ) then
				draw.SimpleText("Bunny Hop = [ On ] ", "TargetID", 0 + 1610, ScrH() - 850, Color(0,255,0), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
			else
				draw.SimpleText("Bunny Hop = [ Off ] ", "TargetID", 0 + 1610, ScrH() - 850, Color(255,0,0), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
			end
			if( GetConVarNumber('fb_misc_chatspam') == 1 ) then
				draw.SimpleText("ChatSpam = [ On ] ", "TargetID", 0 + 1610, ScrH() - 825, Color(0,255,0), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
			else
				draw.SimpleText("ChatSpam = [ Off ] ", "TargetID", 0 + 1610, ScrH() - 825, Color(255,0,0), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
			end
			if( GetConVarNumber('sv_cheats') == 1 ) then
				draw.SimpleText("Cheats = [ On ] ", "TargetID", 0 + 1610, ScrH() - 775, Color(0,255,0), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
			else
				draw.SimpleText("Cheats = [ Off ] ", "TargetID", 0 + 1610, ScrH() - 775, Color(255,0,0), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
			end
			if( GetConVarNumber('sv_allowcslua') == 1 ) then
				draw.SimpleText("ScriptEnforcer = [ On ] ", "TargetID", 0 + 1610, ScrH() - 750, Color(0,255,0), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
			else
				draw.SimpleText("ScriptEnforcer = [ Off ]", "TargetID", 0 + 1610, ScrH() - 750, Color(255,0,0), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
			end
			if( GetConVarNumber('fb_rem_recoil') == 1 ) then
				draw.SimpleText("No Recoil = [ On ] ", "TargetID", 0 + 1610, ScrH() - 700, Color(0,255,0), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
			else
				draw.SimpleText("No Recoil = [ Off ]", "TargetID", 0 + 1610, ScrH() - 700, Color(255,0,0), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
			end
			if( GetConVarNumber('fb_rem_skybox') == 1 ) then
				draw.SimpleText("No Skybox = [ On ] ", "TargetID", 0 + 1610, ScrH() - 675, Color(0,255,0), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
			else
				draw.SimpleText("No Skybox = [ Off ]", "TargetID", 0 + 1610, ScrH() - 675, Color(255,0,0), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
		end
	end
end

-- Misc	
function Misc()
	if GetConVarNumber("fb_misc_cheats") >= 1 then
		GetConVar('sv_cheats'):SetValue(1)
	else
		GetConVar('sv_cheats'):SetValue(0)
	end

	if GetConVarNumber( "fb_misc_bhop" ) >= 1 then
		if input.IsKeyDown( KEY_SPACE ) then
			if LocalPlayer():IsOnGround() then
				RunConsoleCommand("+Jump")
				timer.Create("Bhop",0.01, 0 ,function() RunConsoleCommand("-Jump") end)
			end
		end
		if GetConVarNumber("fb_misc_chatspam") == 1 then
			RunConsoleCommand("say",""..SpamMessage.."")
		end
	end
end

-- Visuals
function Visuals()
	if( GCVN('fb_rem_nosky') >= 1 ) then
		GetConVar('r_drawskybox'):SetValue(1)
		GetConVar('gl_clear'):SetValue(0)
		GetConVar('r_3dsky'):SetValue(0)
	else
		GetConVar('r_drawskybox'):SetValue(0)
		GetConVar('gl_clear'):SetValue(1)
		GetConVar('r_3dsky'):SetValue(1)
	end
end

function Recoil( u, o )
	if( GCVN('fb_rem_recoil') == 1 ) then
		local w = client:GetActiveWeapon()
		if ( w.Primary ) then w.Primary.Recoil = 0.0 end
		if ( w.Secondary ) then w.Secondary.Recoil = 0.0 end
	end
end





/*------------------------------
Hooking System
------------------------------*/
hook.Add("HUDPaint","ESP", ESP)
hook.Add('HUDPaint','InfoBox', CheatInfo)
hook.Add('HUDPaint','SkyBox', Visuals)
hook.Add("Think","RandomShit", Misc)
hook.Add('CalcView', 'RemoveRecoil', Recoil )
