local DH = {} 
DH.Ver = '07.18.18' 

local sizeX = 716
local sizeY = 460	

local dFont = 'BudgetLabel'

local allply = player.GetAll()

local me = LocalPlayer()

local faply = NULL
local faply1 = NULL
local nulVec = Vector()
local SessionID = util.CRC(os.time())
local globalOrig = nulVec
local silentAngle

local cm
local ip = true
local lMouse = false
local rMouse = false
local AAchoke = false
local wheelUp = false 
local wheelDown = false 
local aimenable = false 
local insertDown = false 
local aimandshoot = false
local menuVisible = false
local rapidtoggle = false 
local cStrafeToggle = false
local ActivatedModebox = false

local bones = {Head = 'ValveBiped.Bip01_Head1',Spine='ValveBiped.Bip01_Spine2',Pelvis='ValveBiped.Bip01_Pelvis'} 
local aaTbl = {} 
local bttab = {}
local aaTblR = {} 
local rndYAW =   {-179,-135,-90,-45,0,45,90,135} --{-180,-135,90,-45,0,45,90,135,180} 
local rndPITCH = {-89,-45,0,45,89} 
local ATabAnim = {}
local fakeAngles = {p=0,y=0}
local realAngles = {p=0,y=0}
local menuFixed = {} 
local spreadTables = {}
local badSequences = {
[ACT_VM_RELOAD] = true,
[ACT_VM_RELOAD_SILENCED] = true,
[ACT_VM_RELOAD_DEPLOYED] = true,
[ACT_VM_RELOAD_IDLE] = true,
[ACT_VM_RELOAD_EMPTY] = true,
[ACT_VM_RELOADEMPTY] = true,
[ACT_VM_RELOAD_M203] = true,
[ACT_VM_RELOAD_INSERT] = true,
[ACT_VM_RELOAD_INSERT_PULL] = true,
[ACT_VM_RELOAD_END] = true,
[ACT_VM_RELOAD_END_EMPTY] = true,
[ACT_VM_RELOAD_INSERT_EMPTY] = true,
[ACT_VM_RELOAD2] = true}

local startsys = SysTime()
local sv_gravity = GetConVar('sv_gravity'):GetFloat() 
local sv_friction = GetConVar('sv_friction'):GetFloat()
local sv_stopspeed = GetConVar('sv_stopspeed'):GetFloat() 
local sv_accelerate = GetConVar('sv_accelerate'):GetFloat() 

local GUser = 1
local fakeMode = 0
local killCount = 0 
local maxtickbt = 1
local servertime = 0 
local cStrafeRad = 0
local cStrafeBuff = 0 
local fakelagTickCount = 0 
local fakeLagSendCount = 0

local chamsmat_1 = CreateMaterial('randomname3312','VertexLitGeneric',{['$ignorez']=1,['$model']=1,['$basetexture']='models/debug/debugwhite',})  
local chamsmat_2 = CreateMaterial('randomname33s2','VertexLitGeneric',{['$ignorez']=0,['$model']=1,['$basetexture']='models/debug/debugwhite',})  

local ATab = 1 
local ATabs = {'AIMBOT','VISUALS','HVH','MISC','SETTINGS','PLAYERS'} 

DH.Menu = {} 
DH.Menu['HvH'] = {} 
DH.Menu['Misc'] = {} 
DH.Menu['Aimbot'] = {} 
DH.Menu['General'] = {} 
DH.Menu['Filters'] = {} 
DH.Menu['Visuals'] = {} 
DH.Menu['EVisuals'] = {} 
DH.Menu['Settings'] = {} 
DH.Menu['WhiteList'] = {} 

DH.Vars = {}
DH.Vars['FoV'] = 90 
DH.Vars['RealYaw'] = 0
DH.Vars['Cone FOV'] = 20
DH.Vars['RealPitch'] = 0
DH.Vars['Aim Smooth'] = 0
DH.Vars['ASUS Alpha'] = 75 
DH.Vars['OwnFakeYaw'] = 0
DH.Vars['Rapid Delay'] = 0
DH.Vars['PlayerAAYaw'] = 0 
DH.Vars['FakeLag Int'] = 1  
DH.Vars['OwnFakePitch'] = 0
DH.Vars['ESP Distance'] = 15000
DH.Vars['FakeLag Send'] = 1
DH.Vars['FakeLag Choke'] = 1
DH.Vars['EESP Distance'] = 15000
DH.Vars['PlayerAAPitch'] = 0
DH.Vars['CStrafe Radius'] = 5
DH.Vars['Thirdperson FoV'] = 120

DH.Vars['Main_Red']   = 255
DH.Vars['Main_Green'] = 0
DH.Vars['Main_Blue']  = 0

local DefVars = table.Copy(DH.Vars)

DH.Modes =  
{ 
	['Save'] = {main = 'Legit'},
	['Bone'] = {main = 'Head'}, 
	['Aimbot'] = {main = 'Disable'},
	['AAType'] = {main = 'None'}, 	
	['Predict'] = {main = 'Engine'}, 
	['AATable'] = {main = allply[1]:Name()}, 
	['BoneMode'] = {main = 'Center'}, 
	['AA MethodX'] = {main = 'None'}, 
	['AA MethodY'] = {main = 'None'}, 
	['FindMethod'] = {main = 'My pos'}, 
} 

--RunConsoleCommand('cl_interp',0.066)  
--RunConsoleCommand('cl_interp_ratio',2)  
--RunConsoleCommand('cl_updaterate',120)  

RunConsoleCommand('cl_interp',0)
RunConsoleCommand('cl_updaterate',100000)
RunConsoleCommand('cl_cmdrate',100000)
RunConsoleCommand('cl_interp_ratio',1)

local color_0 = Color(0,0,0)
local color_32 = Color(32,32,32)
local color_64 = Color(64,64,64) 
local color_128 = Color(128,128,128) 
local color_190 = Color(190,190,190)
local color_210 = Color(210,210,210)
local color_240 = Color(240,240,240)
local color_red = HSVToColor(0,1,0.7)
local color_main = HSVToColor(0,1,0.7)

--Copy Funcs

local gmath = math
local gteam = team
local gutil = util
local gtable = table
local gpairs = pairs
local ginput = input
local gengine = engine
local gtostring = tostring

local gbit = bit
local bor  = gbit.bor
local band = gbit.band
local bnot = gbit.bnot

local mabs = gmath.abs
local mcos = gmath.cos
local msin = gmath.sin
local mrad = gmath.rad
local mdeg = gmath.deg
local macos = gmath.acos 
local mceil = gmath.ceil
local mRand = gmath.Rand
local mHuge = gmath.huge
local mRound = gmath.Round
local mClamp = gmath.Clamp
local mrandom = gmath.random

local ggui = gui
local mousePos = ggui.MousePos

local ScW,ScH = ScrW(),ScrH() 
local MsX,MsY = mousePos() 

local gstring = string
local len = gstring.len
local sfind = gstring.find
local sRight = gstring.Right
local sExplode = gstring.Explode

local surface = surface
local sSetFont = surface.SetFont
local sDrawText = surface.DrawText
local sDrawRect = surface.DrawRect
local sDrawLine = surface.DrawLine
local sCreateFont = surface.CreateFont
local sSetTextPos = surface.SetTextPos
local sGetTextSize = surface.GetTextSize
local sSetDrawColor = surface.SetDrawColor
local sSetTextColor = surface.SetTextColor
local sDrawOutlinedRect = surface.DrawOutlinedRect

local grender = render
local rDrawLine = grender.DrawLine
local rSetBlend = grender.SetBlend
local rSetLightingMode = grender.SetLightingMode
local rMaterialOverride = grender.MaterialOverride 
local rSetColorModulation = grender.SetColorModulation
local rSuppressEngineLighting = grender.SuppressEngineLighting

local gcam = cam
local cEnd3D = gcam.Start3D
local cStart3D = gcam.End3D
local cEnd3D2D = gcam.End3D2D
local cStart3D2D = gcam.Start3D2D

local tSort = gtable.sort
local tRandom = gtable.Random
local isValid = IsValid
local realTime = RealTime
local frameTime = FrameTime
local isKeyDown = ginput.IsKeyDown
local traceLine = gutil.TraceLine
local setMousePos = ggui.SetMousePos
local isMouseDown = ginput.IsMouseDown
local teamGetColor = gteam.GetColor
local tickInterval = gengine.TickInterval
local realFrameTime = RealFrameTime
local WasMousePressed = ginput.WasMousePressed
local RunConsoleCommand = RunConsoleCommand
local EnableScreenClicker = ggui.EnableScreenClicker
local SvTickCount = 0

local function unload()  
	for k,v in gpairs(hook.GetTable()) do 
		for k1,v1 in gpairs(v) do if sfind(gtostring(k1),'DH|') then hook.Remove(k,k1) end end 
	end 
	timer.Destroy('UpdatePlayer')
	
	bSendPacket = true
	EnableScreenClicker(false) 
end 
unload()  

local function AddHek(txt,fnc)
	local sys,txsz = gtostring((SysTime()-startsys)*10000)..'\n',#txt
	MsgC('DenzHook added! ['..txt..'] '..(' '):rep((#sys+2-txsz)+20)..sys)
	hook.Add(txt,'DH|'..gutil.CRC(mrandom(10^4)+SysTime()),fnc) 
end 

for k,v in gpairs(DH.Menu) do menuFixed[k] = {} for s,z in gpairs(v) do menuFixed[k][z] = false end end 
DH.Menu = menuFixed 

local function GetTextSize(font,str) 
	sSetFont(font) 
	return sGetTextSize(str) 
end 
 
local function InBox(x,y,x1,y1) 
	return MsX>x and MsX<x1 and MsY>y and MsY<y1 
end 
 
local function DrawBox(col,x,y,sx,sy) 
	sSetDrawColor(col.r,col.g,col.b,col.a) 
	sDrawRect(x,y,sx,sy) 
end 
 
local function DrawText(col,x,y,str,font) 
	sSetTextColor(col.r,col.g,col.b,col.a) 
	sSetTextPos(x,y) 
	sSetFont(font) 
	sDrawText(str) 
end 
 
local function DrawLine(col,x,y,x1,y1) 
	sSetDrawColor(col.r,col.g,col.b,col.a) 
	sDrawLine(x,y,x1,y1) 
end 

local function DrawRect(col,X,Y,W,H,Rev) 
	X, Y = mRound(X),mRound(Y) 
	W, H = mRound(W),mRound(H) 
	if Rev then 
		X = W<0 and X+W or X 
		W = W<0 and -W or W 
		Y = H<0 and Y+H or Y 
		H = H<0 and -H or H 
	end 
	sSetDrawColor(col.r,col.g,col.b,col.a) 
	sDrawRect(X,Y,W,H) 
end 

local function DrawOutlinedRect(col,x,y,w,h,fill) 
	sSetDrawColor(col.r,col.g,col.b,col.a) 
	x, y = mceil(x),mceil(y) 
	w, h = mceil(w),mceil(h) 
	fill = mceil(fill) 
	local fx, fy = mClamp(fill,0,w/2),mClamp(fill,0,h/2) 
	sDrawRect(x,y,w,fy) 
	sDrawRect(x+w-fx,y+fy,fx,h-fy*2) 
	sDrawRect(x,y+h-fy,w,fy) 
	sDrawRect(x,y+fy,fx,h-fy*2) 
end 
 
sCreateFont('Theme',{font='Arial',size=13,weight=500}) 
local function ThemeBox(name,x,y,x1,y1) 
	DrawText(color_white,x+30,y-7,name,'Theme') 
 
	local w,h = GetTextSize('Theme',name) 
	sSetDrawColor(color_main) 
	sDrawLine(x,y,x+25,y) 
	sDrawLine(x+w+35,y,x+x1,y) 
	sDrawLine(x,y+y1,x+x1,y+y1) 
	sDrawLine(x,y+y1,x,y) 
	sDrawLine(x+x1,y+y1,x+x1,y) 
end 
 
local function CheckBox(indx,name,x,y,rname) 
	local txt = rname or name 
	DrawText(color_white,x+20,y,txt,dFont) 
	if InBox(x+1,y+1,x+14,y+14) then 
		if lMouse and !ActivatedModebox then DH.Menu[indx][name] = !DH.Menu[indx][name] end 
	end 
 
	DrawRect(color_main,x+2,y+2,12,12) 
	if DH.Menu[indx][name] then DrawRect(color_0,x+4,y+4,8,8) end 
	 
	sSetDrawColor(0,0,0,122) 
	sDrawOutlinedRect(x+1,y+1,14,14)	 
end 

local function Button(name,x,y,w,h,func)
	local sw,sh = GetTextSize(dFont,name) 
	local color = color_32
	if InBox(x,y,x+w,y+h) then 
		color = color_main
		if lMouse and !ActivatedModebox then func() end 
	end 
	DrawRect(color,x,y,w,h) 
	DrawText(color_white,x+w/2-sw/2,y,name,dFont) 
end 

local function WhitelistButton(pl,x,y,w,h)
	local sw,sh = GetTextSize(dFont,pl:Name()) 
	local color = color_32
	local id = pl:SteamID()
	if InBox(x,y,x+w,y+h) then 
		color = color_main
		if lMouse then
			DH.Menu.WhiteList[id] = !DH.Menu.WhiteList[id]
		end 
		if rMouse then
			pl:ShowProfile()
		end 
	end 
	if DH.Menu.WhiteList[id] == true then color = color_main end
	
	DrawRect(color,x,y,w,h) 
	DrawText(color_white,x+w/2-sw/2,y,pl:Name(),dFont) 
end 

local function AddSlider(name,x,y,len,min,max,rname,buff) 
	local txt = rname or name
	local w,h = GetTextSize(dFont,txt)
	
	DH.Vars[name..'buff'] = DH.Vars[name..'buff'] or mRound((DH.Vars[name])*len/(max+min)-min)
	DH.Vars[name] = mRound(min+(DH.Vars[name..'buff']/len*(max-min)))
	--if name == 'FoV' then print((min*DH.Vars[name]-len*DH.Vars[name])/len) end
	--Round(min+((DH.Vars[name])/len*(max-min)))
	--Round(min+(DH.Vars[name]*len/(max+min)))
	--DH.Vars[name]*len/(max+min)
	--x*y/(z1+z2)
	
	DrawText(color_white,x+len/2-w/2,y+5,txt,dFont) 
	
	w,h = GetTextSize(dFont,DH.Vars[name])
	DrawText(color_white,x+len/2-w/2,y-7,DH.Vars[name],dFont) 

	w,h = GetTextSize(dFont,tostring(max))
	DrawText(color_white,x,y+5,tostring(min),dFont) 
	DrawText(color_white,x+len-w,y+5,tostring(max),dFont) 

	local slidcol = color_white
	
	if InBox(x-1,y,x+len+1,y+18) then 
		if wheelUp then  
			DH.Vars[name..'buff'] = DH.Vars[name..'buff'] + 0.2
		end 
		if wheelDown then  
			DH.Vars[name..'buff'] = DH.Vars[name..'buff'] - 0.2
		end
		if isMouseDown(MOUSE_LEFT) and !ActivatedModebox then 
			slidcol = color_main
			DH.Vars[name..'buff'] = mClamp(MsX,x,x+len)-x
		end 
	end 

	DrawRect(color_main,x,y+5,len,3) 
	DrawRect(slidcol,x+DH.Vars[name..'buff'],y+2,3,6) 
end 

local function ModeBox(indx,x,y,w,h,tab) 
	if !DH.Modes then DH.Modes = {idnx={main=tab[1],tab=false}} end 
	local name = ((indx == 'AA MethodX' and 'X ' or indx == 'AA MethodY' and 'Y ') or '')..DH.Modes[indx].main
	local sw,sh = GetTextSize(dFont,name) 
	local boxcol = color_64
	if InBox(x,y,x+w,y+h) and !ActivatedModebox then boxcol = color_main if lMouse then lMouse=false DH.Modes[indx].tab = !DH.Modes[indx].tab end end

	if DH.Modes[indx].tab then 
		boxcol = color_main
		local cnt = 0
		for k,z in gpairs(tab) do 
			cnt = cnt + 1
			local choosecol = DH.Modes[indx].main == z and color_main or color_32
			local v='' for i=1,13 do v = v..z[i] end
			local sw,sh = GetTextSize(dFont,v) 
			if InBox(x,y+cnt*h,x+w+w,y+cnt*h+h) then
				if lMouse then 
					DH.Modes[indx].main = z 
					DH.Modes[indx].tab  = false 
					timer.Simple(0.3,function() ActivatedModebox = false end)
				else
					ActivatedModebox = true
				end
				choosecol = color_main
			end 
			DrawRect(choosecol,x,y+cnt*h,w,h) 
			DrawText(color_white,x+w/2-sw/2,y+cnt*h,v,dFont) 
		end 
		cnt = 0
	end
	
	DrawRect(color_32,x,y,w,h) 
	DrawRect(boxcol,x+w-10,y+3,8,8) 
	local v='' for i=1,13 do v = v..name[i] end
	sw,sh = GetTextSize(dFont,v)
	DrawText(color_white,x+w/2-sw/2,y,v,dFont) 
end 
 
local function LoadConfig(name) 
	if !file.IsDir('denzware','DATA') then file.CreateDir('denzware') end 
	if !file.Exists('denzware/pdata.txt','DATA') then file.Write('denzware/pdata.txt','DONE!') end 
	local tbl =  file.Exists("denzware/"..name..'.txt','DATA') and gutil.JSONToTable(file.Read("denzware/"..name..'.txt') or '') or DefVars
	--print(file.Read("denzware/"..name..'.txt','DATA'))
	
	if tbl == '' then 
		tbl = DefVars
	end

	
	allply = player.GetAll()
end 

local buff = table.Copy(DH)
LoadConfig('Custom')
if !DH.Menu['Settings']['Autoload'] then DH = buff end

local function SaveConfig(name)
	local buff = table.Copy(DH)
	for k,v in pairs(DH) do if type(v) =='table' and next(v) == nil then buff[k] = nil end end
	for k,v in pairs(DH.Menu) do if next(v) == nil then buff.Menu[k] = nil end end
	file.Write('denzware/'..name..'.txt',gutil.TableToJSON(buff or {['Corrupted file!'] = true})) 
end

local function DeleteConfig(name) file.Delete('denzware/'..name..'.txt') end 

//Menu Hook 
local function ownerName()
	local Members = {['STEAM_0:0:34824919'] = 'Denz'}
	return Members[me:SteamID()] or me:Name()
end

local function clearAATB(v)
	DH.Vars['PlayerAAYaw'] = 0
	DH.Vars['PlayerAAPitch'] = 0
	DH.Modes['AAType'].main = 'None'
	v.AAYaw = 0
	v.AAPitch = 0
	v.AAMethod = 'None'
	v.ResolveTableP = nil
	v.ResolveTableY = nil
	v.KResolveTableP = nil
	v.KResolveTableY = nil
	DH.Vars['PlayerAAYawbuff'] = 0
	DH.Vars['PlayerAAPitchbuff'] = 0
end

sCreateFont('Tabs',{font='Impact',size=40,weight = 500})--Comic Sans MS
AddHek('DrawOverlay',function() 
	if DH.Menu['Visuals']['Watermark'] then DrawText(color_main,4,0,'DenzHak v.'..DH.Ver,dFont) end
	if DH.Menu['Misc']['Info Panel'] then 
		if me:Alive() then
			local eye = me:EyeAngles()

			local selfInfo = 
			{
				{'Welcome '..ownerName()..'! Session ID:'..SessionID , col=1},
				{'Your STATS:'                          , col=1},
				{'   Health:  '..me:Health()               },
				{'   Ping:    '..me:Ping()                 },
				{'   FPS:     '..mRound(1/FrameTime())     },
				{'   FakeLag: '..DH.Vars['FakeLag Choke']..' '..DH.Vars['FakeLag Send']},
				{'   Yaw:     '..mRound(eye.y,3)            },
				{'   Pitch:   '..mRound(eye.p,3)            },
				{'   AntiAim: '..DH.Modes['AA Method'].main },
				{'   real Y:  '..mRound(realAngles.y,3)%360 },
				{'   real P:  '..mRound(realAngles.p,3)     },
				{'   fake Y:  '..mRound(fakeAngles.y,3)%360 },
				{'   fake P:  '..mRound(fakeAngles.p,3)     },
			}
			
			for k,v in pairs(selfInfo) do
				col = v.col == 1 and Color(255,255,0) or Color(255,255,255)
				
				if DH.Modes['AA Method'].main == 'None' and (k == 10 or k == 11 or k == 12 or k == 13) then continue end
				--if mRound(realAngles.y) == mRound(fakeAngles.y) and mRound(realAngles.p) == mRound(fakeAngles.p) and (k == 12 or k == 13) then continue end
				
				DrawText(col,4,12*k,v[1],dFont)
			end
		end
		
		if IsValid(aaply) and aaply:Alive() then 
			local y,p = 0,0
			local real = aaply:EyeAngles()
			local Method = aaply.AAMethod and aaply.AAMethod or 'None'
			
			if aaply.AAESP then y,p = aaply.AAESP.y or 0,aaply.AAESP.p or 0 end
			
			local btrak = 'false'
			if bttab[aaply] then
				if bttab[aaply][(SvTickCount or 0)-maxtickbt] then
					btrak = 'true'
				end
			end
			
			local targetInfo =
			{
				{'Target STATS:'                ,col=1},
				{'   Nick:    '..aaply:Name()         },
				{'   Rank:    '..aaply:GetUserGroup() },
				{'   Health:  '..aaply:Health()       },
				{'   Ping:    '..aaply:Ping()         },
				{'   Yaw:     '..mRound(real.y,3)     },
				{'   Pitch:   '..mRound(real.p,3)     },
				{'   AAA:     '..Method               },
				{'   BTrack:  '..btrak                },
				{'   AAA Y:   '..y		              },
				{'   AAA P:   '..p                    },
			}
		
			for k,v in pairs(targetInfo) do
				col = v.col == 1 and Color(255,255,0) or Color(255,255,255)
				
				if Method == 'None' and (k == 10 or k == 11) then continue end
				DrawText(col,4,12*k+156,v[1],dFont)
			end
		end
	end
	
	if !menuVisible then return end 
	
	color_main = Color(DH.Vars['Main_Red'],DH.Vars['Main_Green'],DH.Vars['Main_Blue'])
	
	MsX,MsY = mousePos() 
    local sx,sy = sizeX,sizeY 
    local offX,offY = ScW/2-sx/2,ScH/2-sy/2 
	 
	DrawBox(DH.Menu['HvH']['Real Angles'] and Color(18,18,18,120) or Color(18,18,18,255),offX,offY,sx,sy)//MainBox 
	DrawBox(color_main,offX,offY,sx,2)//TopBox 
	DrawRect(color_main,offX+160,offY,1,sizeY)
	
	local namen = 'DenzHak v.'..DH.Ver
	local namenlen = len(namen)
	for i=0,namenlen do
		DrawText(HSVToColor((RealTime()*25+i)%360,1,1),sizeX-namenlen*9+offX+i*8,offY+10,namen[i],dFont)
	end
	
	//Tabs 
	for k,v in gpairs(ATabs) do 
		local w = sx/#ATabs 
		local x,y = GetTextSize('Tabs',v) 
		local tabcolor = color_128
		if InBox(offX+5,offY+y/2+k*30-25+4-7,offX+5+x,offY+y/2+k*30-25+32-7) then 
			ATabAnim[k] = SysTime()
			tabcolor = color_240
			if lMouse then ATab = k end
		else
			local mem1 = mClamp(255-((SysTime()-(ATabAnim[k] or 0))*255),0,100)
			local mem2 = mClamp(255-((SysTime()-(ATabAnim[k] or 0))*255),60,90)
			
			local h,s,v = ColorToHSV(Color(DH.Vars['Main_Red'],DH.Vars['Main_Green'],DH.Vars['Main_Blue']))
			
			tabcolor = HSVToColor(h,mem1/100,mem2/100)--HSVToColor(0,mem1/100,mem2/100) --HSVToColor(0,mem1/100,mem2/100)--Color(mem,mem,mem)
		end
		
		DrawText(ATab == k and color_white or tabcolor,offX+5,offY+y/2+k*30-25-7,v,'Tabs') 
	end 
	 
	//Auto Adjust Box 
	sizeY = 460

	local dx,dy = offX+180,offY+10
	
	Button('Save',offX+5,offY+340+20*3,72.5,15, function() SaveConfig(DH.Modes['Save'].main) end) 
	Button('Load',offX+82,offY+340+20*3,72.5,15, function() LoadConfig(DH.Modes['Save'].main) end) 
	Button('Unload',offX+5,offY+340+20*5,72.5,15,function() unload() timer.Simple(0.1,function() if DH then DH=nil end end) end) 
	Button('Fast Quit',offX+82,offY+340+20*5,72.5,15,  function() RunConsoleCommand('gamemenucommand','quitnoconfirm') end) 
	
	ModeBox('Save',offX+5,offY+340+20*4,150,15,{'Rage','Legit','Custom'}) 

	//Aimbot Checkboxes 
	if ATab == 1 then //Aimbot 
		ThemeBox('Aimbot',dx-10,dy+10,155,355) 

		CheckBox('Aimbot','Silent',dx,dy+20*6) 
		CheckBox('Aimbot','Spread',dx,dy+20*7) 
		CheckBox('Aimbot','Autoshoot',dx,dy+20*8) 
		CheckBox('Aimbot','AA Static',dx,dy+20*9) 
		CheckBox('Aimbot','Auto Walls',dx,dy+20*10) 
		CheckBox('Aimbot','Rapid Fire',dx,dy+20*11)
		CheckBox('Aimbot','One Tap',dx,dy+20*12)		
		AddSlider('Rapid Delay',dx,dy+20*13,140,0,500) 
		
		CheckBox('Aimbot','RMB Fix',dx,dy+20*14) 

		CheckBox('Aimbot','Cone',dx,dy+20*15) 
		AddSlider('Cone FOV',dx,dy+20*16,140,0,360)

		AddSlider('Aim Smooth',dx,dy+20*17,140,0,100) 
		
		ModeBox('BoneMode',dx,dy+20*5,135,15,{'Borders','Hitscan','Center'}) 
		ModeBox('Predict',dx,dy+20*4,135,15,{'Engine','EngineC','VelBase','Ping','GTick','Classic','MTick','None'}) 
		ModeBox('Bone',dx,dy+20*3,135,15,{'Head','Pelvis','Spine'}) 
		ModeBox('FindMethod',dx,dy+20*2,135,15,{'Crosshair','My pos','Crosshair 2D','Random'}) 
		ModeBox('Aimbot',dx,dy+20*1,135,15,{'Disable','Auto','Key'})
	end 
	
	//Visuals 
	if ATab == 2 then 
		ThemeBox('Players',dx-10,dy+10,155,340) 
		 
		CheckBox('Visuals','Enabled',dx,dy+20*1) 
		CheckBox('Visuals','Box',dx,dy+20*2) 
		CheckBox('Visuals','3DBox',dx,dy+20*3) 
		CheckBox('Visuals','Name',dx,dy+20*4) 
		CheckBox('Visuals','Rank',dx,dy+20*5) 
		CheckBox('Visuals','Health',dx,dy+20*6) 
		CheckBox('Visuals','Hit Boxes',dx,dy+20*7) 
		CheckBox('Visuals','Skeletones',dx,dy+20*8)	 
		CheckBox('Visuals','AA Mode',dx,dy+20*9)	 
		CheckBox('Visuals','Chams',dx,dy+20*10)
		CheckBox('Visuals','Fullbright',dx,dy+20*11)	 
		CheckBox('Visuals','Tracers',dx,dy+20*12)	 
		CheckBox('Visuals','Aim Dot',dx,dy+20*13)	 
		CheckBox('Visuals','Halo',dx,dy+20*14)	 
		CheckBox('Visuals','Whitelist',dx,dy+20*15)	 
		 
		AddSlider('ESP Distance',dx,dy+20*16,140,0,285000) 
		 
		ThemeBox('Entities',dx+155,dy+10,155,115) 
		CheckBox('EVisuals','Enabled',dx+165,dy+20*2) 
		CheckBox('EVisuals','Props',dx+165,dy+20*3)  
		CheckBox('EVisuals','Weapons',dx+165,dy+20*4) 
		CheckBox('EVisuals','Money',dx+165,dy+20*5) 
		 
		AddSlider('EESP Distance',dx+165,dy+20*1,140,0,285000) 
		
		ThemeBox('Misc',dx+155,dy+135,155,295) 
		CheckBox('Visuals','Crosshair 2D',dx+165,dy+125+20*1) 
		CheckBox('Visuals','Crosshair 3D',dx+165,dy+125+20*2)
		CheckBox('Visuals','StaticView',dx+165,dy+125+20*3) 
		CheckBox('Visuals','ASUS',dx+165,dy+125+20*4) 
	
		AddSlider('ASUS Alpha',dx+165,dy+125+20*5,140,0,100) 
		CheckBox('Misc','Thirdperson',dx+165,dy+125+20*6) 
		 
		AddSlider('FoV',dx+165,dy+125+20*7,140,30,140) 
		AddSlider('Thirdperson FoV',dx+165,dy+125+20*8,140,0,500)
		
		CheckBox('Visuals','Night Mode',dx+165,dy+125+20*9)
		CheckBox('Visuals','Watermark',dx+165,dy+125+20*10)
		CheckBox('Visuals','Spectators',dx+165,dy+125+20*11)
		CheckBox('Visuals','Angles',dx+165,dy+125+20*12)
		CheckBox('Visuals','No Hands',dx+165,dy+125+20*13)
		CheckBox('Visuals','Cone',dx+165,dy+125+20*14)
		
	end 

	//HVH
	if ATab == 3 then
		//Anti-Aim
		ThemeBox('Anti-Aim',dx-10,dy+10,155,135) 
		
		CheckBox('HvH','Real Angles',dx,dy+20*3) 

		AddSlider('OwnFakeYaw',dx,dy+20*4,140,-180,180,'Fake Yaw') 
		AddSlider('RealYaw',dx,dy+20*5,140,-180,180,'Real Yaw') 
		AddSlider('RealPitch',dx,dy+20*6,140,-89,89,'Real Pitch') 
		
		//Anti-Anti-Aim
		local NameTbl = {}
		for k,v in gpairs(allply) do
			if !isValid(v) then continue end
			NameTbl[v:SteamID()] = v:Name()
			if DH.Modes['AATable'].main == v:Name() and GUser != v:SteamID() then
				DH.Vars['PlayerAAYaw'] = v.AAYaw or 0
				DH.Vars['PlayerAAPitch'] = v.AAPitch or 0 
				DH.Modes['AAType'].main   = v.AAMethod or 'None'
				
				DH.Vars['PlayerAAYawbuff'] = v.AAYaw
				DH.Vars['PlayerAAPitchbuff'] = v.AAPitch
				
				GUser = v:SteamID()
			end
			
			if DH.Modes['AATable'].main == v:Name() then
				v.AAYaw = v.AAYaw and DH.Vars['PlayerAAYaw'..'buff'] or 0
				v.AAPitch = v.AAPitch and DH.Vars['PlayerAAPitch'..'buff'] or 0
				v.AAMethod = v.AAMethod and DH.Modes['AAType'].main or 'None'
			end
		end
		
		ThemeBox('Anti-Anti-Aim',dx-10,dy+155,155,175) 

		CheckBox('Aimbot','Backtrack',dx,dy+145+20*1)
		CheckBox('Aimbot','Shoot Aim FIX',dx,dy+145+20*2)
		
		AddSlider('PlayerAAYaw',dx,dy+145+20*3,140,-180,180,'Player Yaw') 
		AddSlider('PlayerAAPitch',dx,dy+145+20*4,140,-90,90,'Player Pitch') 
		
		Button('Reset AA Table',dx,dy+145+20*7,135,15,function()  
			DH.Modes['AATable'].main = 'None'
			for k,v in gpairs(allply) do
				clearAATB(v)
			end
		end)
		
		Button('Reset Player',dx,dy+145+20*8,135,15,function()  
			for k,v in gpairs(allply) do
				if DH.Modes['AATable'].main == v:Name() then
					clearAATB(v)
				end
			end
		end)
		
		ModeBox('AAType',dx,dy+145+20*6,135,15,{'None','Razor','Basic','Auto','Custom','Static','Random','Resolver Flick','Resolver Kill','180 Gay','180 90 -90'})
		ModeBox('AATable',dx,dy+145+20*5,135,15,NameTbl) --INDEX
		
		ModeBox('AA MethodX',dx,dy+20*2,135,15,
		{
			'None','FakeUp','FakeFakeUp','FakeUpward','Custom','Random','Flick',
		})
		
		ModeBox('AA MethodY',dx,dy+20*1,135,15,
		{
			'None','Spinbot','FakeSpin','OnEnemy','OnEnemyCustom','FakeY','Backward','Random','Edge','Invert','Flick','OnEnemyFlick'
		})
		
		ThemeBox('Fake Lag',dx+155,dy+10,155,95) 
	
		CheckBox('HvH','Fake Lag',dx+165,dy+20*1)
		AddSlider('FakeLag Send', dx+165,dy+20*2,140,1,14) 
		AddSlider('FakeLag Choke',dx+165,dy+20*3,140,1,14) 

		Button('bSendPacket '..tostring(bSendPacket),dx+165,dy+20*4,135,15,function() bSendPacket=!bSendPacket end) 
		
		ThemeBox('Enable Modules',dx+155,dy+115,155,55) 
		
		CheckBox('HvH','Engine Predict',dx+165,dy+105+20*1) 
		CheckBox('HvH','Spread Dickwrap',dx+165,dy+105+20*2) 
	end
	
	//Misc 
	if ATab == 4 then 
		ThemeBox('Misc',dx-10,dy+10,155,195) 
		 
		CheckBox('Misc','BunnyHop',dx,dy+20*1) 
		CheckBox('Misc','Autostrafer',dx,dy+20*2)
		CheckBox('Misc','Edge Jump',dx,dy+20*3) 
		CheckBox('Misc','Flashlight',dx,dy+20*4) 
		CheckBox('Misc','Chat KillRow',dx,dy+20*5) 
		CheckBox('Misc','Info Panel',dx,dy+20*6) 
		CheckBox('Misc','CStrafe',dx,dy+20*7) 
		CheckBox('Misc','HitDebug',dx,dy+20*8) 
		
		--AddSlider('CStrafe Radius',dx,dy+20*8,140,0,20) 
	end 
	 
	//Settings 
	if ATab == 5 then 
		ThemeBox('General',dx-10,dy+10,155,95) 
		Button('Denz HvH',dx,dy+20*1,135,15,function() me:ConCommand('connect 54.36.191.235') end) 
		Button('Overload',dx,dy+20*2,135,15,function() while true do end end) 
		
		CheckBox('Settings','Sound OFF',dx,dy+20*3) 
		CheckBox('Settings','Autoload',dx,dy+20*4) 
		
		ThemeBox('Main Color', dx+155,dy+10,155,75) 
		AddSlider('Main_Red',  dx+165,dy+20*1,140,0,255) 
		AddSlider('Main_Green',dx+165,dy+20*2,140,0,255) 
		AddSlider('Main_Blue', dx+165,dy+20*3,140,0,255) 
		
		color_main = Color(DH.Vars['Main_Red'],DH.Vars['Main_Green'],DH.Vars['Main_Blue'])
	end 
	
	if ATab == 6 then
		//WhiteList 
		ThemeBox('White List',dx-10,dy+10,155,15+(#allply)*20) 

		for k,v in gpairs(allply) do 
			if !v:IsValid() then continue end 
			local name = '' 
			local id = v:SteamID()
			for i=1,15 do name = name..v:Nick()[i] end
			name = name..(#v:Nick() >= 15 and '..' or '')
			if v:IsBot() or !v:SteamID() then id = v:UserID() end
			WhitelistButton(v,dx,dy+20*k,135,15)
		end 
		
		//Filters 
		ThemeBox('Filters',dx+155,dy+10,155,95) 
		 
		CheckBox('Filters','No Friends',dx+165,dy+20*1) 
		CheckBox('Filters','No Admins',dx+165,dy+20*2) 
		CheckBox('Filters','No Teammates',dx+165,dy+20*3) 
		CheckBox('Filters','No Bots',dx+165,dy+20*4) 
	end
end) 

AddHek('Move',function()
	if(not IsFirstTimePredicted()) then return end 
	servertime = CurTime()+tickInterval()
end)

local HitDelay = false
local HitGroup = {'Head','Chest','Stomach','LeftArm','RightArm','Leftleg','Rightleg','err','err','err','err'}
AddHek('ScalePlayerDamage',function(pl,hg)
	if DH.Menu['Misc']['HitDebug'] and IsValid(pl)  and !HitDelay then
		MsgC(Color(255,125,125),'HIT_DEBUG% ',Color(125,255,125),HitGroup[hg]..'\n')
		HitDelay = true
		timer.Simple(0.1,function() HitDelay = false end)
	end
end)

require'bsendpacket'
require"spreadthebutter"
require'big'

AddHek('Think',function()
	if(not insertDown and isKeyDown(KEY_INSERT)) then 
		menuVisible = !menuVisible 
		EnableScreenClicker(menuVisible) 
		setMousePos(MsX,MsY) 
	end 
	insertDown = isKeyDown(KEY_INSERT)  
end)  

AddHek('Tick',function()
	SvTickCount = SvTickCount + 1 
end)

----MENU END 

local rang = {}
local gay180 = {135,180,-135}
local function aaa() 
	for k,v in gpairs(allply) do 
		if v == me or !isValid(v) then continue end	
		
		v.aaaTick = v.aaaTick or 0
		local ang = v:EyeAngles() 
		local p,y,r = ang.p,ang.y,ang.r
		rang[v] = ang
		v.AAESP = {}
		v.AAESP.mode = 'off'
		
		if IsValid(v:GetActiveWeapon()) and DH.Menu['HvH']['Shoot Aim FIX'] then
			if v:GetActiveWeapon():GetSequence() > 0 then 
				v:SetPoseParameter("aim_pitch", v.AAESP.p or 0);
				v:SetPoseParameter("head_pitch",v.AAESP.p or 0);
				v:SetPoseParameter("body_yaw",0);
				v:SetPoseParameter("aim_yaw", 0);
				v:InvalidateBoneCache()
				v:SetRenderAngles(Angle(0, math.NormalizeAngle(v.AAESP.y or 0), 0))
				v.AAESP.p = v.AAESP.p or 0
				v.AAESP.y = v.AAESP.y or 0
			continue end
		end
		
		if v.AAMethod == 'None' or v.AAMethod == nil then continue end
		
		if v.AAMethod == 'Resolver Flick' then 
			v.ResolveTableP = v.ResolveTableP or {}
			v.ResolveTableY = v.ResolveTableY or {}
			local rp, ry = mRound(p/40)*40, mRound((y%180)/40)*40
			local kek = true
			for i = 1,#v.ResolveTableP do
				if v.ResolveTableP[i] == rp and v.ResolveTableY[i] == ry then
					kek = false
					break
				end
			end
			
			if kek then 
				v.ResolveTableP[#v.ResolveTableP+1] = rp
				v.ResolveTableY[#v.ResolveTableP+1] = ry
			end

			local rnd = mrandom(#v.ResolveTableP-3,#v.ResolveTableP)
			p = v.ResolveTableP[v.aaaTick%#v.ResolveTableP-3] or p
			y = v.ResolveTableY[v.aaaTick%#v.ResolveTableY-3] or y
			
			v.AAESP.mode = 'Flick'
		end
		
		if v.AAMethod == 'Basic' then 
			if p > 89.95 and 91 > p then
				p = p - 90
			elseif p >= 89 and 180.087936 >= p then
				p = 89
			elseif p > 180.087936 and 271 > p then
				p = 271
			end
			y = rndYAW[v.aaaTick%#rndYAW+1]
			v.AAESP.mode = 'Basic'
		end
		
		if v.AAMethod == 'Resolver Kill' then 
			if v:Health()<1 and !v.KResolveTableY then
				v.KResolveTableP = mClamp(p,-49,49) 
				v.KResolveTableY = y%180
			end
			p = v.KResolveTableP or rndPITCH[v.aaaTick%#rndPITCH+1]
			y = v.KResolveTableY or rndYAW[v.aaaTick%#rndYAW+1] 
			v.AAESP.mode = 'Resolver Kill'
		end
		
		if v.AAMethod == 'Auto' then 
			v.AAESP.mode = 'Auto'
			local rp = mRound(p)
			local r3 = mRound(p,3)
			
			if  r3 == 89.121   then y = y + 180    v.AAESP.mode = 'Backward 1' end 
			if  r3 == 89.824   then y = y + 180    v.AAESP.mode = 'Backward 2' end
			if  r3 == 11.953   then y = y + 180  p = 49  v.AAESP.mode = 'Backward 3' end
			
			if  r3 == 1.055    then p = (v.aaaTick%2 == 0 and -49) or 49 y = y + 180 v.AAESP.mode = 'Spinbot' end 
			if  r3 == 178.945  then p = (v.aaaTick%2 == 0 and -49) or 49   v.AAESP.mode = '178.945' end
			
			if  r3 == 178.945  then p = (v.aaaTick%2 == 0 and -49) or 49   v.AAESP.mode = '178.945' end
			
			if  r3 == 178.770  then p = 0  y = y - 90 v.AAESP.mode = '178.769' end
			
			if  r3 >= 72.070 and r3 <= 72.246 then y = y - 180 v.AAESP.mode = '612 Backward' end

			if y == 5.0089 then y = y + 180  v.AAESP.mode = '5.00..' end
			
			if -mRound(p,6) == 0.000005 then 
				p = (v.aaaTick%2 == 0 and -49) or 49
				y = y-180
				v.AAESP.mode = 'Huge fuck' 
			end
			
			if  mRound(p,3) == 87.012 or mRound(p,3) == 1.934 or mRound(p,3) == 2.637 or mRound(p,3) == 5.449 or mRound(p,3) == 88.066 then 
				p = 49--(v.aaaTick%2 == 0 and -49) or 49  
				y = (v.aaaTick%2 == 0 and 0) or 180  
				y = y + mRand(-10,10)
				
				local pitches = { -181, 541, 262 }
				local yaws = { 262, -262, 181, -181, 541, -541 }
				
				p = pitches[v.aaaTick%#pitches+1]
				y = yaws[v.aaaTick%#yaws+1]
				
				v.AAESP.mode = 'Strange' 
			end
			
			if  mRound(p,3) == 88.945 then 
				y = y - gay180[v.aaaTick%#gay180+1]
				v.AAESP.mode = 'Fake Angle' 
			end 
			
			if rp == 180 then p = (v.aaaTick%2 == 0 and -49) or 49 v.AAESP.mode = '180 Pitch' end
	
			if (p == 271.0546875) then p = (v.aaaTick%2 == 0 and -49) or 49 v.AAESP.mode = '271. up/down' end
			if (p == 322.03125)   then p = (v.aaaTick%2 == 0 and -49) or 49 v.AAESP.mode = '322. up/down' end
		end
		
		if v.AAMethod == 'Static' then p,y = v.AAPitch,  v.AAYaw v.AAESP.mode = 'Static' end
		if v.AAMethod == 'Custom' then p,y = v.AAPitch,y+v.AAYaw v.AAESP.mode = 'Custom' end
		
		if v.AAMethod == 'Random' then 
			p,y = rndPITCH[v.aaaTick%#rndPITCH+1],rndYAW[v.aaaTick%#rndYAW+1]
			v.AAESP.mode = 'Random'
		end
		
		if v.AAMethod == '180 90 -90' then 
			y = (me:GetPos()-v:GetPos()):Angle().y-gay180[v.aaaTick%#gay180+1]
			p = 49
			v.AAESP.mode = '180 90 -90'
		end
		
		if v.AAMethod == '180 Gay' then 
			y = (me:GetPos()-v:GetPos()):Angle().y-180+v.AAYaw
			p = 49
			v.AAESP.mode = 'Backward Mode'
		end

		v:SetPoseParameter("aim_pitch", p);
		v:SetPoseParameter("head_pitch",p);
		v:SetPoseParameter("body_yaw",0);
		v:SetPoseParameter("aim_yaw", 0);
		v:InvalidateBoneCache()
		v:SetRenderAngles(Angle(0, math.NormalizeAngle(y), 0))
		v.AAESP.p = p or 0
		v.AAESP.y = y or 0
		--v:SetupBones()
		--print(v)
		--v:InvalidateBoneCache();
		--v:SetRenderAngles(Angle(0,y,0));
	end 
end 

local function getBPred(ent) 
	ent.drop     = ent.drop or 0 
	ent.speed    = ent.speed or 0 
	ent.control  = ent.control or 0 
	ent.wishvel  = ent.wishvel or nulVec
	ent.newspeed = ent.newspeed or 0  
	 
	local vel,grnd = ent:GetVelocity(),ent:IsOnGround() 
	local ent_gravity = ent:GetGravity() or 1 
	if !grnd then vel.z=vel.z-(ent_gravity*sv_gravity*.5*frameTime()) end 
	if ent:WaterLevel() < 2  then 
		ent.speed = vel:Length() 
		if ent.speed > 0.1 then 
			if grnd then 
				ent.control = ent.speed < sv_stopspeed and sv_stopspeed or ent.speed 
				ent.drop = ent.control * sv_friction * frameTime()
			end 
			ent.newspeed = ent.speed - ent.drop 
			if ent.newspeed < 0 then ent.newspeed = 0 end 
			if ent.newspeed != ent.speed then 
				 ent.newspeed = ent.newspeed / ent.speed 
				 vel.x = vel.x * ent.newspeed 
				 vel.y = vel.y * ent.newspeed 
				 vel.z = vel.z * ent.newspeed 
			end 
		end 
		ent.wishvel=(1-ent.newspeed)*Vector(vel.x,vel.y,vel.z) 
	end 
 
	local wishdir,wishspeed = ent.wishvel,ent.wishvel:Length() 
 
	if wishspeed != 0 then 
		wishdir = wishdir / wishspeed 
		if (wishspeed > ent:GetMaxSpeed()) then 
			ent.wishvel = ent.wishvel * ( ent:GetMaxSpeed() / wishspeed ) 
			wishspeed = ent:GetMaxSpeed() 
		end 
	end 
    
	local addspeed,accelspeed,currentspeed = 0,0,0 
	currentspeed = vel:Dot(wishdir) 
	addspeed = wishspeed-currentspeed 
	if addspeed > 0 then 
		accelspeed = sv_accelerate * frameTime() * wishspeed 
		if accelspeed > addspeed then accelspeed = addspeed end 
		vel.x = vel.x*accelspeed*wishdir.x 
		vel.y = vel.y*accelspeed*wishdir.y 
		vel.z = vel.z*accelspeed*wishdir.z 
	end 
	vel.z = grnd and 0 or vel.z-(ent_gravity*sv_gravity*0.5*frameTime()) 
	return Vector(vel.x,vel.y,vel.z) 
end 

local function veloPredict(vec,trg) 
	local lvel,tvel,frm,eng = me:GetVelocity(),trg:GetVelocity(),realFrameTime(),tickInterval()
	
	if DH.Modes['Predict'].main == 'None'    then return vec end 
	if DH.Modes['Predict'].main == 'EngineC' then return (lvel*eng) - (vec + tvel*eng) end 
	if DH.Modes['Predict'].main == 'VelBase' then return vec+((lvel-tvel)*(frm/(1/eng))) end 
	if DH.Modes['Predict'].main == 'Classic' then return vec-(lvel*eng) end
	if DH.Modes['Predict'].main == 'Engine'  then return vec+((tvel*eng/2*frm)-(lvel*eng)) end 
	if DH.Modes['Predict'].main == 'MTick'   then return 
		vec+((getBPred(trg))-(getBPred(me)))
		--vec+((getBPred(trg)*eng)-(getBPred(me)*eng)) 
	end
	if DH.Modes['Predict'].main == 'Ping'    then return vec+(tvel-lvel)*(me:Ping()*.001)*2 end 
	if DH.Modes['Predict'].main == 'GTick'   then return vec+(((tvel*frm/25)-(tvel*frm/33))-((lvel*frm/25)+(lvel*frm/33))) end 
end 
 
local function EdgeJump(cmd) 
	if me:IsOnGround() and me:WaterLevel() < 2 and me:GetMoveType() == MOVETYPE_WALK then 
		local StartPos,EndPos=me:GetPos(),me:GetPos()-Vector(0,0,18)
		local DirVec=Vector(me:GetVelocity():Angle():Forward().x,me:GetVelocity():Angle():Forward().y,0)*8 
		local DirVec2=Vector(me:GetVelocity():Angle():Forward().x,me:GetVelocity():Angle():Forward().y,0)*16 
		local f={start=StartPos-DirVec,endpos=EndPos-DirVe,filter=me,mask=MASK_PLAYERSOLID} 
		local s={start=StartPos-DirVec2,endpos=EndPos-DirVec2,filter=me,mask=MASK_PLAYERSOLID} 
		if traceLine(f).Fraction==1 and traceLine(s).Fraction!=1 then cmd:SetButtons(bor(cmd:GetButtons(),IN_JUMP)) end 
	end 
end 

--local faktik = 0
--local lagside = true
local function fakelag(cmd) 
	local choke = DH.Vars['FakeLag Choke']
	local send = DH.Vars['FakeLag Send']
	fakeLagTickCount = choke + send
	if DH.Menu['HvH']['Fake Lag'] then
		--cmd:SetSideMove(lagside and 4000 or -4000)
		--faktik = faktik + 1
		--if faktik > 4 then faktik = 0 lagside = !lagside end
		
		fakeLagSendCount = fakeLagSendCount + 1
		if fakeLagSendCount > fakeLagTickCount then fakeLagSendCount = 1 end
		bSendPacket = send >= fakeLagSendCount and true or false
		
		local speed = me:GetVelocity():Length()
		local speedpertick = speed * engine.TickInterval()
		local choketimer = Lerp(speedpertick, choke, fakeLagSendCount)
		if(choketimer / 500 * speedpertick - (engine.TickInterval() / 2) < 500) then 
			bSendPacket = true 
		elseif(choketimer > 500) then 
			bsendpacket = false 
		elseif(LocalPlayer():KeyDown(IN_JUMP) && choketimer > 500) then 
			bSendPacket = true 
		elseif(LocalPlayer():KeyDown(IN_JUMP) && choketimer < 500) then 
			bSendPacket = false 
		end
		RunConsoleCommand('cl_interp',0)
		RunConsoleCommand('cl_updaterate',100000)
		RunConsoleCommand('cl_interp_ratio',1)
	
		--if true then return end
		if choke > 5 and speed == 0 and fakeMode != 1 then
			fakeMode = 1
			RunConsoleCommand('cl_updaterate',1048576)
			RunConsoleCommand('cl_cmdrate',1048576)
			RunConsoleCommand('cl_interp',0.695)
		end
		
		if choke <= 5 and choke > 1 and speed == 0 and fakeMode != 2 then
			fakeMode = 2
			RunConsoleCommand('cl_updaterate',66)
			RunConsoleCommand('cl_cmdrate',66)
			RunConsoleCommand('cl_interp',0.7)
		end

		if choke == 1 and speed == 0 and fakeMode != 3 then
			fakeMode = 3
			RunConsoleCommand('cl_updaterate',67)
			RunConsoleCommand('cl_cmdrate',67)
			RunConsoleCommand('cl_interp',1)
		end
	end
end 

local function isVisible(vec,v) 
	if DH.Menu['Aimbot']['Auto Walls'] then return true end
	local tr=traceLine({start=me:EyePos(),endpos=vec,filter=me,mask=MASK_SHOT})
	if DH.Menu['Aimbot']['Cone'] and (mabs(mdeg(macos(me:GetEyeTrace().Normal:Dot(tr.Normal))))>=DH.Vars['Cone FOV']) then return false end 
	return tr.Fraction == 1 or (tr.Entity==v and tr.HitGroup == HITGROUP_HEAD)--tr.HitBox == ent:LookupBone(bones[DH.Modes['Bone'].main])
end 

gameevent.Listen('entity_killed') 
AddHek('entity_killed',function(data) 
	if Entity(data.entindex_killed) == me then killCount=0 end 
	if Entity(data.entindex_attacker) == me then
		if !Entity(data.entindex_killed):IsPlayer() then return end
		Entity(data.entindex_killed).aaaTick = Entity(data.entindex_killed).aaaTick - 1
		if DH.Menu['Misc']['Chat KillRow'] then 
			local a = ' got raped!' 
			killCount = killCount+1 
			--me:ConCommand("say [IDEOTBOX] owned " .. Entity(data.entindex_killed):Nick())
			local text = Entity(data.entindex_killed):Name()..', Got Raped'
		end 
	end 
end) 

local function GetHitBox(ply,b)
	for group = 0, ply:GetHitBoxGroupCount()-1 do
		for hitbox = 0, ply:GetHitBoxCount(group)-1 do
			local bone = ply:GetHitBoxBone(hitbox,group)
			if bone and bone == b then
				return hitbox
			end
		end
	end
	return 0
end

local function findHitbox(ent)
	local ep
	local group = 0
	local min,max = ent:GetHitBoxBounds(0,0)
	local bone,ang = ent:GetBonePosition(ent:LookupBone(bones[DH.Modes['Bone'].main]) or 0)
	for hitbox = 0, ent:GetHitBoxCount(group) - 1 do
		bone, ang = ent:GetBonePosition(ent:GetHitBoxBone(hitbox, group))
		min, max = ent:GetHitBoxBounds(hitbox, group)
		min:Rotate(ang)
		max:Rotate(ang)
		ep = bone + ((min + max) * 0.5)
		ep = veloPredict(ep,ent)
		if isVisible(ep,ent) then return ep end
	end
end	

local NonPlayerModels = {
	["models/player/zombie/fast_torso.mdl"]        = "ValveBiped.HC_BodyCube",
	["models/player/zombie_fast.mdl"]              = "ValveBiped.HC_BodyCube",
	["models/zombie/fast.mdl"]                     = "ValveBiped.HC_BodyCube",
	["models/zombie/zombie_fast.mdl"]              = "ValveBiped.HC_BodyCube",
	["models/headcrabclassic.mdl"]                 = "HeadcrabClassic.SpineControl",
	["models/headcrabblack.mdl"]                   = "HCBlack.body",
	["models/headcrab.mdl"]                        = "HCFast.body",
	["models/player/zombie/poison.mdl"]            = "ValveBiped.Headcrab_Cube1",
	["models/player/fatty/fatty.mdl"]              =  "ValveBiped.Bip01_Head1",
	["models/player/zombie_classic.mdl"]           = "ValveBiped.HC_Body_Bone",
	["models/player/zombie/zombie_soldier.mdl"]    = "ValveBiped.HC_Body_Bone",
	["models/zombie/poison.mdl"]                   = "ValveBiped.Headcrab_Cube1",
}

local function aimbotGetBone(ent) 
	if !isValid(ent) then return end 

	local ep
	local min,max = ent:GetHitBoxBounds(0,0)
	if !min or !max then return ent:GetBonePosition(ent:LookupBone(bones[DH.Modes['Bone'].main]) or 0) end
	local bone,ang = ent:GetBonePosition(ent:LookupBone(bones[DH.Modes['Bone'].main]) or 0)
	min:Rotate(ang)
	max:Rotate(ang)
	ep = bone + ((min + max) * 0.5)
	
	if DH.Modes['BoneMode'].main == 'Center' then 
		--if isnumber(ent:LookupBone(bones[DH.Modes['Bone'].main])) then return end
		--print(ent:LookupBone(bones[DH.Modes['Bone'].main]))
		local bon = ent:LookupBone(bones[DH.Modes['Bone'].main])
		--print(ent:GetModel())
		for k,v in pairs(NonPlayerModels) do
			if ent:GetModel() == k then
				bon = ent:LookupBone(v)
				
				if bon then
					if ent:GetBoneMatrix(bon) then
						local matx = ent:GetBoneMatrix(bon)
						if matx then
							local ep = veloPredict(matx:GetTranslation()+matx:GetForward()*4,ent)
							return ep
						end
					end
				end
			end
		end
		
		if bon then
			if ent:GetBoneMatrix(bon) then
				local matx = ent:GetBoneMatrix(bon)
				if matx then
					local ep = veloPredict(matx:GetTranslation()+matx:GetForward()*4,ent)
					if isVisible(ep,ent) then return ep end
					--return ep
				end
			end
		end
		findHitbox(ent)
	end
	
	if DH.Modes['BoneMode'].main == 'Hitscan' then 
		findHitbox(ent)
	end
	
	if DH.Modes['BoneMode'].main == 'Borders' then
		local off = .5
		local b = ent:LookupBone(bones[DH.Modes['Bone'].main])
		if !b then 
			if isVisible(ep,ent) then
				return ep 
			end
			return ep
		end
		local M = ent:GetBoneMatrix(b) or Matrix()
		if M then
			local ep = veloPredict(M:GetTranslation()+M:GetForward()*4,ent)
			if isVisible(ep,ent) then return ep end
			
			local hb = GetHitBox(ent,b)
			local IN = {ent:GetHitBoxBounds(hb,0)}
			for i = 1,2 do
				local x = M:GetRight()*(-IN[i].y+(-IN[i].y < 0 and off or -off))
				for j = 1,2 do
					local y = M:GetForward()*(IN[j].x+(IN[j].x < 0 and off or -off))
					for k = 1,2 do
						local z = M:GetUp()*(IN[k].z+(IN[k].z < 0 and off or -off))
						local ep = veloPredict(M:GetTranslation()+x+y+z,ent)
						if isVisible(ep,ent) then return ep end
					end
				end
			end
		end
	end
	
	return isVisible(ep,ent) and ep
end 
 
local function canFire()
    local wep = me:GetActiveWeapon()
    if(!wep || !wep:IsValid()) then return false end
    local sequence = wep:GetSequence()
    if(badSequences[sequence]) then return false end
	--if DH.Menu['HvH']['Fake Lag'] and !bSendPacket then return false end
	if DH.Menu['Aimbot']['Rapid Fire'] then
	
		if DH.Menu['Aimbot']['One Tap'] then
			if (wep:GetNextPrimaryFire()<=servertime-me:Ping()/200) then return true end
			return false
		end
			
		if(wep:GetNextPrimaryFire()<=servertime-DH.Vars['Rapid Delay']/100) then return true end
		
		return false
	end
    if(wep:GetNextPrimaryFire()<=servertime) then return true end
    return false
end

local function rapidfire(cmd) 
	if isValid(me) and isValid(me:GetActiveWeapon()) then
		if !canFire() then cmd:SetButtons(band(cmd:GetButtons(),bnot(IN_ATTACK))) return end
		if me:KeyDown(IN_ATTACK) then 
			if me:GetActiveWeapon():GetClass() == 'weapon_physgun' then return end
			if rapidtoggle then
				cmd:SetButtons(bor(cmd:GetButtons(),IN_ATTACK)) 
				rapidtoggle = false 
			else
				cmd:SetButtons(band(cmd:GetButtons(),bnot(IN_ATTACK))) 
				rapidtoggle = true	 
			end 
		end 
	end 
end 

local function Backtrack(ent,cmd)
	bttab[ent] = bttab[ent] or {}
	
	local tickcount = SvTickCount or 0

	ent.lasttick = tickcount
	if bttab[ent][tickcount-(maxtickbt+5)] then
		bttab[ent][tickcount-(maxtickbt+5)] = nil
	end
	
	bttab[ent][tickcount] = {
		eye = ent:EyeAngles(),
		pos = ent:GetPos(),
		head = aimbotGetBone(ent),
	}
end

AddHek('PreDrawOpaqueRenderables',function() 
	--FRAME_NET_UPDATE_POSTDATAUPDATE_START
	aaa() 
end)

local function getPlayer(mode,enbl,aapl) 
	if !enbl then return end 
	local pltbl = {} 
	for k,v in gpairs(allply) do 
		if !isValid(v) then continue end 
		
		if !v or !v:IsPlayer() or v:IsDormant() or v == me or 0 >= v:Health() then continue end	
		if !aimbotGetBone(v) and !aapl then continue end 

		if (v:GetMoveType() == MOVETYPE_NONE) or (v:GetMoveType() == MOVETYPE_OBSERVER) then continue end  
		if DH.Menu['Filters']['No Teammates'] and (me:Team() == v:Team()) then continue end 
		if DH.Menu['Filters']['No Friends'] and v:GetFriendStatus() == 'friend' then continue end 
		if DH.Menu['Filters']['No Admins'] and v:IsAdmin() then continue end 
		if DH.Menu['Filters']['No Bots'] and v:IsBot() then continue end 
		if DH.Menu.WhiteList[v:SteamID()] then continue end 
		if v:Team() == TEAM_SPECTATOR then continue end 
		
		if DH.Menu['Aimbot']['Backtrack'] then Backtrack(v,cm) end
		
		pltbl[#pltbl+1] = v 
	end 
 
	if mode == 'Crosshair' then 
		--local pos = me:GetEyeTrace().HitPos 
		local pos = DH.Menu['Aimbot']['Silent'] and silentAngle or me:GetEyeTrace().HitPos 
		tSort(pltbl,function(a,b) 
		return (a:GetPos()-pos):LengthSqr() < (b:GetPos()-pos):LengthSqr() end) 
	end 
	 
	if mode == 'My pos' then 
		local pos = me:GetPos() 
		tSort(pltbl,function(a,b) return(a:GetPos()-pos):LengthSqr() < (b:GetPos()-pos):LengthSqr()end) 
		return pltbl[1] 
	end 
 
	if mode == 'Crosshair 2D' then 
		tSort(pltbl,function(a,b) 
		local ats,bts = a:GetPos():ToScreen(), b:GetPos():ToScreen() 
			return Vector(ScW/2-ats.x,ScH/2-ats.y,0):LengthSqr() < Vector(ScW/2-bts.x,ScH/2-bts.y,0):LengthSqr() 
		end) 
		return pltbl[1]  
	end 
 
	if mode == 'Random' then return pltbl[mRand(1,#pltbl)] end 
	return pltbl[1]
end 
 
local function bhop(cmd) 
	if !DH.Menu['Misc']['BunnyHop'] then return end 
	if me:IsOnGround() and cmd:KeyDown(IN_JUMP) then
		cmd:SetButtons(bor(cmd:GetButtons(), IN_JUMP))
		if DH.Menu['Misc']['Autostrafer'] then
			cmd:SetForwardMove(10^4)
		end
	else
		if DH.Menu['Misc']['Autostrafer'] and cmd:KeyDown(IN_JUMP) then
			cmd:SetForwardMove(5850 / me:GetVelocity():Length2D())
			cmd:SetSideMove((cmd:CommandNumber() % 2 == 0) and 400 or -400)
		end
		cmd:RemoveKey(IN_JUMP)
	end
end 

AddHek('EntityFireBullets',function(ply,data) 
	local spread = data.Spread * -1
	if !ply:GetActiveWeapon() then return end
	if !ply:GetActiveWeapon():GetClass()  then return end
	local wep = ply:GetActiveWeapon():GetClass() 
	if(spreadTables[wep] == spread) then return  end 
	if(spread == Vector()) then return  end 
	spreadTables[wep] = spread  
end) 

local function removeSpread(cmd,ang) 
	if !DH.Menu['Aimbot']['Spread'] then return ang end 
	local wep = me:GetActiveWeapon()  
	if(not wep or not isValid(wep)) then return ang end 
	local class = wep:GetClass()  
	if(not spreadTables[class]) then return ang end 

	local ViewPunch = me:GetViewPunchAngles()

	return DS_manipulateShot(DS_md5PseudoRandom(  cmd:CommandNumber() ), ang:Forward(), spreadTables[class]):Angle()  -- ViewPunch
end 

local function fixMove(cmd,ang1) 
	local vec = Vector(cmd:GetForwardMove(),cmd:GetSideMove(),0) 
	local vel = (vec.x*vec.x+vec.y*vec.y)^0.5
	local mang = vec:Angle() 
	local yaw = cmd:GetViewAngles().y - ang1.y + mang.y 
	if (((cmd:GetViewAngles().p+90)%360) > 180) then yaw = 180 - yaw; end 
	yaw = mrad((yaw+180)%360-180) 
	cmd:SetForwardMove(mcos(yaw)*vel) 
	cmd:SetSideMove(msin(yaw)*vel) 
end 

local function cStrafe(cmd) 
	if !DH.Menu['Misc']['CStrafe'] then return end

	if isKeyDown(KEY_F) and !cStrafeToggle then
		cStrafeToggle = true
		local len = 4096
		for i = 1, 30 do
			local initpos = me:GetPos()+me:OBBCenter()
			local xpos = mcos(mrad(i*12))*4096
			local ypos = msin(mrad(i*12))*4096
			local trace = gutil.TraceLine({start=initpos,endpos=initpos+Vector(xpos,ypos,0),filter=me,mask=MASK_PLAYERSOLID})
			len = math.min(len,(trace.HitPos-initpos):Length2D())
		end
		cStrafeRad = mClamp(len-46,0,512)
	end
	if isKeyDown(KEY_F) then
		cmd:SetForwardMove(4000) cmd:SetSideMove(0) fixMove(cmd,Angle(0,CurTime()*(512-cStrafeRad)%360,0))
	else
		cStrafeToggle = false
	end
end

local function getEnemypos()
	return (isValid(aaply) and aaply:GetPos()-me:EyePos() or Vector()):Angle()
	--return (isValid(aaply) and (veloPredict(aaply:GetPos() or Vector(),aaply)-me:EyePos()):Angle()) or silentAngle 
end

local AATick = 0
local oldYaw = 0
local oldedge = 0
me.fakelagpos = me:GetPos()

--wtf dude are u retard??
local edge =
{
	p=
	{
		Vector(15,25,20),Vector(15,-25,20),Vector(-15,25,20),Vector(-15,-25,20), 
		Vector(25,15,20),Vector(-25,15,20),Vector(25,-15,20),Vector(-25,-15,20), 
	},
	ps=
	{
		Vector(15,-25,20),Vector(15,25,20),Vector(-15,-25,20),Vector(-15,25,20),
		Vector(-25,15,20),Vector(25,15,20),Vector(-25,-15,20),Vector(25,-15,20)
	},
	a={180,180,0,0,-90,-90,90,90}
}

local pDance = 0
local function aAimbot(cmd,oldaim)
	if DH.Modes['AA MethodX'].main == 'None' and DH.Modes['AA MethodY'].main == 'None'then 
		local ang = cmd:GetViewAngles()
		if bSendPacket then 
			me.fakelagpos = me:GetPos()
			fakeAngles.p = ang.p
			fakeAngles.y = ang.y
		else
			realAngles.p = ang.p 
			realAngles.y = ang.y
		end
		return
	end
	
	if me:GetMoveType() == MOVETYPE_LADDER then return end 
	
	local y,p = 0,0
	if cmd:KeyDown(IN_ATTACK) then if aimandshoot then return end return end

	--start
	--p 
	local xmod = DH.Modes['AA MethodX'].main
	local ymod = DH.Modes['AA MethodY'].main
	
	if xmod == 'FakeUp'     then p = 180.000008      end
	if xmod == 'FakeFakeUp' then p = 180.00000762939 end
	if xmod == 'FakeUpward' then p = -612.3+mRand(-7,7) end
	if xmod == 'Random'     then p = tRandom({-181,541,262}) end
	if xmod == 'Custom'     then p = DH.Vars['RealPitch']    end
	if xmod == 'Flick'      then p = AAchoke and 180 or -180 AAchoke=!AAchoke end

	--y
	if ymod == 'Spinbot'       then y = RealTime()*720%360  end
	if ymod == 'OnEnemy'       then y = getEnemypos().yaw-4 end
	if ymod == 'OnEnemyCustom' then y = getEnemypos().yaw+DH.Vars['RealYaw'] end
	if ymod == 'FakeSpin'      then y = bSendPacket and RealTime()*720%360 or RealTime()*720%360-90 end
	if ymod == 'FakeY'         then y = bSendPacket and DH.Vars['RealYaw'] or DH.Vars['OwnFakeYaw'] end
	if ymod == 'Random'        then y = tRandom({262,-262,181,-181,541,-541}) end
	
	if ymod == 'Backward'      then y = getEnemypos().yaw-180 end
	
	if ymod == 'Flick'  then y = AAchoke and y+90 or y-90
	if SvTickCount%66/2 == 0   then AAchoke=!AAchoke end end
	
	if ymod == 'OnEnemyFlick'  then y = AAchoke and getEnemypos().yaw-90 or getEnemypos().yaw+90 
	if SvTickCount%66/2 == 0   then AAchoke=!AAchoke end end
	--end
	
	if DH.Modes['AA MethodY'].main == 'Invert' then 
		local ey = getEnemypos().yaw
		
		DH.InvertBool = DH.InvertBool or false
		
		if bSendPacket then
			y = ey-(AAchoke and 170 or 190)+mrandom(1,13)+mRand(0.03,0.08)
			p = AAchoke and -612.3+mRand(0.02,0.09) or -612.2+mRand(0.02,0.09)  
		else
			y = (DH.InvertBool and ey+90 or ey-90)+mrandom(1,13)+mRand(0.03,0.08) --ey-90 and ey-190 or 
			p = AAchoke and -612.3+mRand(0.02,0.09) or -612.2+mRand(0.02,0.09)  
		end
		AAchoke=!AAchoke
		
		DH.InvertBool = oldYaw > ey and true or false
		oldYaw = ey
	end 
	
	if DH.Modes['AA MethodY'].main == 'Edge' then 
		for i=1,#edge.p do
			local start  = me:EyePos()-edge.p[i]
			local endpos = me:EyePos()-edge.ps[i]
			local tr     = traceLine({start=start,endpos=endpos,filter=me,mask=MASK_SOLID}) 
			
			if tr.Fraction != 1 then
				y = edge.a[i]
				oldedge = y
				break
			end
			y = oldedge
		end

		if bSendPacket then
			y = y+mrandom(1,13)
		else
			y = y
		end
		AAchoke = !AAchoke
	end
	
	cmd:SetViewAngles(Angle(p,y,0))  
	
	--p = ((mRound(p) == -612) and 89) or p
	if bSendPacket then 
		me.fakelagpos = me:GetPos()
		fakeAngles.p = p
		fakeAngles.y = y
	else
		realAngles.p = p 
		realAngles.y = y
	end
end 

local function silent(cmd) 
	if !DH.Menu['Aimbot']['Silent'] then return end
	silentAngle = silentAngle or cmd:GetViewAngles()
	silentAngle = silentAngle+Angle(cmd:GetMouseY()*.023,cmd:GetMouseX()*-.023,0)
	silentAngle.p = mClamp(silentAngle.p, -89, 89)
	if cmd:CommandNumber() == 0 then return end 
	cmd:SetViewAngles(silentAngle) 
end 

function TimeToTicks(time)
	return math.floor(0.5 + time / engine.TickInterval())
end

function TicksToTime(ticks)
	return ticks * engine.TickInterval()
end

function fakeLagPredict(cmd,ent)
	ent = ent or LocalPlayer()
	local simtime = engineprediction.GetSimulationTime(ent:EntIndex())
	if 16 > math.abs(TimeToTicks(simtime) - cmd:TickCount()) then
		engineprediction.SetTickCount(cmd, TimeToTicks(simtime))
	end
end

DH.ZoomFov = false
local function aimbot(cmd,tps) 

    aimenable = DH.Modes['Aimbot'].main == 'Auto'
	aimandshoot = false
	--if DH.Menu['Aimbot']['Kill Once'] and preventKill then aimenable = false end

	if DH.Modes['Aimbot'].main == 'Key' then 
		if isMouseDown(MOUSE_MIDDLE) then aimenable = true else aimenable = false end 
	end 
	
	DH.ZoomFov = isMouseDown(MOUSE_RIGHT) or false
	
	if cmd:KeyDown(IN_ATTACK) then 
		local rang = DH.Menu['Aimbot']['Silent'] and silentAngle or cmd:GetViewAngles() --fuckmee
		local sAng = DH.Menu['Aimbot']['Silent'] and removeSpread(cmd,rang) or cmd:GetViewAngles()
		if DH.Menu['Aimbot']['AA Static'] then sAng.p,sAng.y = -sAng.p - 540,sAng.y + 180 end

		cmd:SetViewAngles(Angle(math.NormalizeAngle(sAng.p),math.NormalizeAngle(sAng.y),0))
	end
	
	if aimenable and canFire() then
		aimandshoot = true
		if isValid(aimply) then
			--if !DH.Menu['Aimbot']['Backtrack'] then fakeLagPredict(cmd,aimply) end
			bsendpacket = false
			aimply.aaaTick=aimply.aaaTick+1
			local posAim = ((aimbotGetBone(aimply) or Vector())-me:GetShootPos()):Angle()
			
			if DH.Menu['Aimbot']['Backtrack'] then
				if bttab[aimply] then
					local tickcnt = aimply.lasttick
					if bttab[aimply][tickcnt-maxtickbt] then
						if bttab[aimply][tickcnt-maxtickbt].head then
							posAim = (( bttab[aimply][tickcnt-maxtickbt].head or Vector())-me:GetShootPos()):Angle()
						end
					end
				end
			end
			
			if posAim == Vector() then return end
			angs = removeSpread(cmd,posAim) 
			
			if DH.Menu['Aimbot']['Autoshoot'] then cmd:SetButtons(bor(cmd:GetButtons(),IN_ATTACK)) end 
			if DH.Vars['Aim Smooth'] > 0 then angs = LerpAngle(1-DH.Vars['Aim Smooth']/100,cmd:GetViewAngles(),angs) end	

			if DH.Menu['Aimbot']['AA Static'] then angs.p,angs.y = -angs.p - 540,angs.y + 180 end		

			cmd:SetViewAngles(angs)  
		end
	end
end 

timer.Create('UpdatePlayer',tickInterval(),0,function()
	allply = player.GetAll()
	
	for k,v in pairs(allply) do v.aaaTick = v.aaaTick or 0 end
	table.RemoveByValue(allply,me)
	aimply = getPlayer(DH.Modes['FindMethod'].main,DH.Menu['Visuals']['Aim Dot'] and true or aimandshoot)

	if DH.Modes['AA MethodY'].main != 'None' then aaply = getPlayer(DH.Modes['FindMethod'].main,true,true) end
end)

AddHek('CreateMove',function(cmd)	 
	lMouse = WasMousePressed(MOUSE_LEFT)
	rMouse = WasMousePressed(MOUSE_RIGHT)
	wheelUp   = WasMousePressed(MOUSE_WHEEL_UP) 
	wheelDown = WasMousePressed(MOUSE_WHEEL_DOWN) 
	cm = cmd
	local cmdnum = cmd:CommandNumber()
	
	silent(cmd)
	if cmdnum == 0 then return end

	if DH.Menu['Misc']['BunnyHop']     then bhop(cmd) end 
	if DH.Menu['Misc']['Edge Jump']    then EdgeJump(cmd) end 
	if DH.Menu['Misc']['Flashlight']   then cmd:SetImpulse(100) end 
	if DH.Menu['Aimbot']['Rapid Fire'] then rapidfire(cmd) end 
	
	big.StartPrediction(cmd, cmd:CommandNumber());
	
	fakelag(cmd)
	aimbot(cmd) 
	
	aAimbot(cmd,cmd:GetViewAngles())

	fixMove(cmd,DH.Menu['Aimbot']['Silent'] and silentAngle or cmd:GetViewAngles())
	cStrafe(cmd)
	
	big.FinishPrediction()
end) 

AddHek('PreDrawPlayerHands',function()
	return DH.Menu['Visuals']['No Hands']
end)

local HandMat = Material("debug/showdestalpha");
AddHek('PreDrawViewModel',function(vm)
	if !DH.Menu['Visuals']['No Hands'] or !vm then return end
	for k,v in next,vm:GetMaterials() do
		if(v:find("v_hands")) then
			render.MaterialOverrideByIndex(k-1,HandMat)
		end
	end
end)

AddHek('PreRender',function() 
	rSetLightingMode(DH.Menu['Visuals']['Fullbright'] and 1 or 0)
	
	for k,v in pairs(game.GetWorld():GetMaterials()) do
		Material(v):SetFloat("$alpha",(DH.Menu['Visuals']['ASUS'] and DH.Vars['ASUS Alpha']/100) or 1)
	end
	
	if DH.Menu['HvH']['Real Angles'] && DH.Menu['Visuals']['Thirdperson'] then
		if faply == NULL then faply = ClientsideModel(me:GetModel(),1) end
		faply:SetNoDraw(true)
		faply:SetSequence(me:GetSequence())
		faply:SetCycle(me:GetCycle())

		if me:Alive() then
			faply:SetModel(me:GetModel())
			faply:SetPos(me.fakelagpos)
			faply:SetAngles(Angle(0,fakeAngles.y,0))
			faply:SetPoseParameter("aim_pitch",fakeAngles.p);
			faply:SetPoseParameter("move_x",me:GetPoseParameter("move_x"));
			faply:SetPoseParameter("move_y",me:GetPoseParameter("move_y"));
			faply:SetPoseParameter("head_pitch",fakeAngles.p);
			faply:SetPoseParameter("body_yaw",fakeAngles.y );
			faply:SetPoseParameter("aim_yaw",0);
			faply:InvalidateBoneCache();
			faply:SetRenderAngles(Angle(0,fakeAngles.y, 0));
		end
		
		if faply1 == NULL then faply1 = ClientsideModel(me:GetModel(),1) end
		faply1:SetNoDraw(true)
		faply1:SetSequence(me:GetSequence())
		faply1:SetCycle(me:GetCycle())

		if me:Alive() then
			faply1:SetModel(me:GetModel())
			faply1:SetPos(me:GetPos())
			faply1:SetAngles(Angle(0,realAngles.y,0))
			faply1:SetPoseParameter("aim_pitch",realAngles.p);
			faply1:SetPoseParameter("move_x",me:GetPoseParameter("move_x"));
			faply1:SetPoseParameter("move_y",me:GetPoseParameter("move_y"));
			faply1:SetPoseParameter("head_pitch",realAngles.p);
			faply1:SetPoseParameter("body_yaw",realAngles.y);
			faply1:SetPoseParameter("aim_yaw",0);
			faply1:InvalidateBoneCache();
			faply1:SetRenderAngles(Angle(0,realAngles.y,0));
		end
	end
end) 

AddHek('PreDrawEffects',function()
	rSetLightingMode(0)
	--render.SetBlend(1)
end)

AddHek('PrePlayerDraw',function(ply)
	return ply == LocalPlayer() and DH.Menu['HvH']['Real Angles']
end)

AddHek('CalcView',function(me,origin,angles) 
	if GetViewEntity() ~= me then return end 
	local view = {} 
	globalOrig = origin  
	view.drawviewer = DH.Menu['Misc']['Thirdperson']
	view.angles = Either(DH.Menu['Aimbot']['Silent'],silentAngle,angles) 
	if DH.Menu['Misc']['Thirdperson'] then view.origin = origin-((DH.Menu['Aimbot']['Silent'] and silentAngle or angles):Forward()*DH.Vars['Thirdperson FoV']) end 
	if DH.ZoomFov and DH.Menu['Aimbot']['RMB Fix'] then return view end
	view.fov =  DH.Vars['FoV'] or 90
	return view  
end) 
 
AddHek('CalcViewModelView',function(wep,vm,oldPos,oldAng,pos,ang) 
	return DH.Menu['Visuals']['StaticView'] and globalOrig or pos,DH.Menu['Aimbot']['Silent'] and silentAngle or ang 
end)

local function drawESP(v) 
 	local mpos = v:GetPos()  
	local pos = mpos:ToScreen() 
	
	if DH.Vars['ESP Distance']<(mpos-me:GetPos()):Length2DSqr()/5000 then return end 
	
	local espind = 0
	local Right,Up = 0,0
	if DH.Menu['Visuals']['Box'] then  
		local color = teamGetColor(v:Team())  
		local bpos, bcent = mpos,  v:OBBCenter() 
		local bmin, bmax  = v:OBBMins(), v:OBBMaxs() 
		local postab = { 
			(bpos+Vector(bmin.x,bmin.y,bmax.z)):ToScreen(), 
			(bpos+Vector(bmin.x,bmax.y,bmax.z)):ToScreen(), 
			(bpos+Vector(bmax.x,bmax.y,bmax.z)):ToScreen(), 
			(bpos+Vector(bmax.x,bmin.y,bmax.z)):ToScreen(), 
			(bpos+Vector(bmin.x,bmin.y,bmin.z)):ToScreen(), 
			(bpos+Vector(bmin.x,bmax.y,bmin.z)):ToScreen(), 
			(bpos+Vector(bmax.x,bmax.y,bmin.z)):ToScreen(), 
			(bpos+Vector(bmax.x,bmin.y,bmin.z)):ToScreen() 
		} 
		local x1, x2, y1, y2 = MSW, -1, MSH, -1
		local x1, x2, y1, y2 = mHuge,-mHuge,mHuge,-mHuge 
		for k,v in gpairs(postab) do 
			if v.x < x1 then x1 = v.x end 
			if v.x > x2 then x2 = v.x end 
			if v.y < y1 then y1 = v.y end 
			if v.y > y2 then y2 = v.y end 
		end 
		Right,Up = x2,y1
	
		DrawOutlinedRect(color,x1,y1,x2-x1,y2-y1,1) 
	end 
	
	if DH.Menu['Visuals']['3DBox'] then  
		local color = teamGetColor(v:Team())  
		local bpos, bcent = mpos,v:OBBCenter():ToScreen()
		local bmin, bmax  = v:OBBMins(), v:OBBMaxs()

		local tb = { 
			(bpos+Vector(bmin.x,bmin.y,bmax.z)):ToScreen(), 
			(bpos+Vector(bmin.x,bmax.y,bmax.z)):ToScreen(), 
			(bpos+Vector(bmax.x,bmax.y,bmax.z)):ToScreen(), 
			(bpos+Vector(bmax.x,bmin.y,bmax.z)):ToScreen(), 
			(bpos+Vector(bmin.x,bmin.y,bmin.z)):ToScreen(), 
			(bpos+Vector(bmin.x,bmax.y,bmin.z)):ToScreen(), 
			(bpos+Vector(bmax.x,bmax.y,bmin.z)):ToScreen(), 
			(bpos+Vector(bmax.x,bmin.y,bmin.z)):ToScreen() 
		} 
		
		Right,Up = tb[1].x,tb[1].y
		
		DrawLine(color,tb[1].x,tb[1].y,tb[4].x,tb[4].y)
		DrawLine(color,tb[1].x,tb[1].y,tb[5].x,tb[5].y)
		DrawLine(color,tb[2].x,tb[2].y,tb[1].x,tb[1].y)
		DrawLine(color,tb[2].x,tb[2].y,tb[3].x,tb[3].y)
		DrawLine(color,tb[2].x,tb[2].y,tb[6].x,tb[6].y)
		DrawLine(color,tb[3].x,tb[3].y,tb[7].x,tb[7].y)
		DrawLine(color,tb[4].x,tb[4].y,tb[8].x,tb[8].y)
		DrawLine(color,tb[4].x,tb[4].y,tb[3].x,tb[3].y)
		DrawLine(color,tb[5].x,tb[5].y,tb[8].x,tb[8].y)
		DrawLine(color,tb[6].x,tb[6].y,tb[5].x,tb[5].y)
		DrawLine(color,tb[6].x,tb[6].y,tb[7].x,tb[7].y)
		DrawLine(color,tb[7].x,tb[7].y,tb[8].x,tb[8].y)
		DrawLine(color,tb[8].x,tb[8].y,tb[7].x,tb[7].y)
	end 
	
	local spe = 1
	if DH.Menu['Visuals']['Spectators'] then  
		if v:GetObserverMode() ~= OBS_MODE_NONE and v:GetObserverTarget() == me then
			spe = spe + 1
			local name = v:Name() 
			DrawText(color_white,500,10+spe*30,name,dFont)
		end
	end
	
	if DH.Menu['Visuals']['Name'] then  
		espind = espind + 1
		local name = v:Name() 
		DrawText(color_white,Right+5,Up+10*espind,name,dFont)  
	end 
	 
	if DH.Menu['Visuals']['Rank'] then  
		espind = espind + 1
		local rank = v:GetUserGroup()  
		DrawText(color_white,Right+5,Up+10*espind,rank,dFont)  
	end 
	
	if DH.Menu['Visuals']['Health'] then  
		espind = espind + 1
		local ap = v:Armor()
		local hp = '['..v:Health()..'] '..(ap > 1 and '['..ap..']' or '') 
		DrawText(color_white,Right+5,Up+10*espind,hp,dFont) 
	end 
	
 	if DH.Menu['Visuals']['AA Mode'] then  
		if !v.AAESP then return end
		espind = espind + 1
		DrawText(color_white,Right+5,Up+10*espind,v.AAESP.mode or 'OFF',dFont) 
		
		if v.AAESP.p then espind = espind + 1 DrawText(Color(255,255,0),Right+5,Up+10*espind,'RPitch: '..mRound(v.AAESP.p,4),dFont) end
		if v.AAESP.y then espind = espind + 1 DrawText(Color(255,255,0),Right+5,Up+10*espind,'RYaw: '..mRound(v.AAESP.y,4),dFont) end
		
		local mem = v:EyeAngles()
		espind = espind + 1
		DrawText(Color(0,255,0),Right+5,Up+10*espind, 'Pitch: '..mRound(mem.p,4),dFont) 
		espind = espind + 1
		DrawText(Color(0,255,0),Right+5,Up+10*espind,'Yaw: '..mRound(mem.y,4),dFont) 
	end 
  
	if DH.Menu['Visuals']['Aim Dot'] then 
		if isValid(aimply) then 
			local gg = aimbotGetBone(aimply) 
			if !gg then return end 
			local kek = gg:ToScreen() //Predict for dot? 
			sSetDrawColor(0,0,0,255) 
			sDrawRect(kek.x-3,kek.y-3,6,6) 
			sSetDrawColor(0,192,0) 
			sDrawRect(kek.x-2,kek.y-2,4,4) 
			if bttab[aimply] then
				for i=1,15 do
					if bttab[aimply][aimply.lasttick-i] then
						if bttab[aimply][aimply.lasttick-i].head then
							local pos = (bttab[aimply][aimply.lasttick-i].head):ToScreen()
							sSetDrawColor(125+i*5,125,255) 
							sDrawRect(pos.x-2,pos.y-2,4,4)
						end
					end
				end
			end
		end 
	end 
 
	if DH.Menu['Visuals']['Skeletones'] then  
		local pos = v:GetPos() 
		for i = 0, v:GetBoneCount()-1 do 
			local parent = v:GetBoneParent(i) 
			if(!parent) then continue end 
			local bonepos = v:GetBonePosition(i) 
			if(bonepos == pos) then continue end 
			local parentpos = v:GetBonePosition(parent) 
			if(!bonepos or !parentpos) then continue end 
			local screen1, screen2 = bonepos:ToScreen(),parentpos:ToScreen() 
			sSetDrawColor(255,255,255) 
			--DrawText(Color(255,255,125),screen1.x,screen1.y,v:GetBoneName(i),dFont) 
			sDrawLine(screen1.x,screen1.y,screen2.x,screen2.y) 
		end 
	end 
 
	if DH.Menu['Visuals']['Hit Boxes'] then 
		for group = 0,v:GetHitBoxGroupCount()-1 do 
			local count = v:GetHitBoxCount(group) - 1 
			for hitbox = 0,count do 
				local bone = v:GetHitBoxBone(hitbox,group) 
				if(!bone) then continue end 
				local min,max = v:GetHitBoxBounds(hitbox,group) 
				local bonepos,boneang = v:GetBonePosition(bone) 
				cStart3D() grender.DrawWireframeBox(bonepos,boneang,min,max,color_main,true) cEnd3D() 
			end 
		end 
	end 
	 
	if DH.Menu['Visuals']['Tracers'] then 
		local col = teamGetColor(v:Team())  
		if v:GetEyeTrace().Entity == me then col = color_red end 
		local b = v:LookupBone("ValveBiped.Bip01_Head1") 
		if b then 
			local ShootBone = v:GetBonePosition(b) --Fix later 
			cStart3D() rDrawLine(ShootBone,v:GetEyeTrace().HitPos,col,false) cEnd3D()
		end 
	end 

	if DH.Menu['Visuals']['Halo'] then 
		local color = teamGetColor(v:Team())
		halo.Add({v},color,1,1,5,true,true) 
		if isValid(v:GetActiveWeapon()) then 
			halo.Add({v:GetActiveWeapon()},color,1,1,5,true,true) 
		end 
	end 
end 
 
local function drawEntity(str) 
	if CaptureDetect then return end
	for k,v in gpairs(ents.FindByClass(str)) do 
		if (isValid(v) and not v:IsDormant()) then	 
			local mpos = v:GetPos()  
			local pos  = mpos:ToScreen()  
			local str = sExplode('/',v:GetModel()) 
			local nn = str[#str] 
			
			if DH.Vars['EESP Distance'] < (mpos-me:GetPos()):Length2DSqr()/5000 then return end 
 
			local w,h = GetTextSize(dFont,nn) 
			DrawText(color_white,pos.x-w/2,pos.y-h/2+5,nn,dFont)   
		end 
	end 
end 
 
local function drawEESP() 
	if DH.Menu['EVisuals']['Money']   then drawEntity'money*'  end --fix/opti.pls
	if DH.Menu['EVisuals']['Props']   then drawEntity'prop_*'  end 
	if DH.Menu['EVisuals']['Weapons'] then drawEntity'weapon*' end 
end 
 
local function MiscVisuals() 
	if DH.Menu['Visuals']['Crosshair 2D'] then 
		local color = teamGetColor(me:Team())
		DrawRect(color,ScW/2-8,ScH/2-1,16,2) 
		DrawRect(color,ScW/2-1,ScH/2-8,2,16) 
	end 
	if DH.Menu['Visuals']['Cone'] then 
		local size = DH.Vars['Cone FOV']
		local color = teamGetColor(me:Team())
		surface.DrawCircle(ScW/2,ScH/2,size*math.pi*4,color.r,color.g,color.b,255)
	end 
end 

AddHek('PostDrawTranslucentRenderables',function() 
	if DH.Menu['Visuals']['Crosshair 3D'] then 
		local tr = traceLine({start=me:EyePos(),endpos=me:EyePos()+(DH.Menu['Aimbot']['Silent'] and silentAngle or me:EyeAngles()):Forward()*1000,filter=me,mask=MASK_SOLID}) 
		local dis = mClamp(((tr.HitPos-me:EyePos()):Length())/500,0,1.95) 
		local ang = tr.HitNormal:Angle() 
		local pos = tr.HitPos+tr.HitNormal*dis*6 
		local color = teamGetColor(me:Team())
		
		cStart3D2D(pos,ang+Angle(90,0,0),dis) 
			DrawRect(color,-8,-1,4,2) 
			DrawRect(color,4,-1,4,2) 
			DrawRect(color,-1,-8,2,4) 
			DrawRect(color,-1,4,2,4) 
		cEnd3D2D()
	end 	
	
	if DH.Menu['Visuals']['Angles'] then 
		if DH.Modes['AA MethodY'].main == 'None' then return end
		
		local pos = me:GetPos()
		cStart3D2D(pos,Angle(0,45+me:GetRenderAngles().y,0),1) 
			DrawLine(Color(0,255,0)  ,0,0,25,25)
		cEnd3D2D()
		
		cStart3D2D(pos,Angle(0,45+fakeAngles.y,0),1) 
			DrawLine(color_red  ,0,0,25,25)
		cEnd3D2D()
		
		cStart3D2D(pos,Angle(0,45+realAngles.y,0),1) 
			DrawLine(color_white,0,0,25,25)
		cEnd3D2D()
	end
end) 
 
AddHek('HUDPaint',function() --DrawOverlay
	if CaptureDetect then return end
	
	if DH.Menu['Visuals']['Enabled'] then  
		for k,v in next,allply do if (isValid(v) and v ~= me and v:Alive() and not v:IsDormant()) then drawESP(v) end end 
	end 
	
	if DH.Menu['EVisuals']['Enabled'] then drawEESP() end 
	MiscVisuals() 
end) 
 
AddHek('RenderScreenspaceEffects',function() 
	if DH.Menu['HvH']['Real Angles'] then
		cStart3D()
			if faply1:IsValid() then
				faply1:DrawModel()
			end
			
			if faply:IsValid() then
				rMaterialOverride(chamsmat_2)
				rSetColorModulation(.95,.61,.07) 
				faply:DrawModel()
			end
		
			rMaterialOverride(chamsmat_2)
			rSetColorModulation(.95,.01,.77) 
			me:DrawModel()
		cEnd3D()
	end
	
	if DH.Menu['Visuals']['Chams'] and DH.Menu['Visuals']['Enabled'] then
		for k,v in next,allply do	 
			if not isValid(v) then continue end 
			if(v:Health()<1 or v == me) then continue end  
			cStart3D()  
				rSuppressEngineLighting(true) 
				rMaterialOverride(chamsmat_1)  
				rSetColorModulation(.63,.094,.082)  
				rSetBlend(1)  
				v:DrawModel()  
				
				if (isValid(v:GetActiveWeapon())) then rSetColorModulation(1,.078,0.57) v:GetActiveWeapon():DrawModel() end 
				rSuppressEngineLighting(true)		 
				rSetColorModulation(.95,.61,.07)  
				rMaterialOverride(chamsmat_2)  
				rSetBlend(1)  
				v:DrawModel()  
				 
				if (isValid(v:GetActiveWeapon())) then rSetColorModulation(1,0.95,0.57) v:GetActiveWeapon():DrawModel() end 
				rSetColorModulation(1,1,1)  
				rSuppressEngineLighting(false) 
			cEnd3D()  
		end 
	end
end)