--[[
	MOD/lua/2014.lua
	Woto | STEAM_0:1:16770039 <37.221.173.228:27005> | [23-10-13 04:46:19AM]
	===BadFile===
]]

--RenderMaterialOverlay
local lAngle				= Angle
local lAddConsoleCommand 	= AddConsoleCommand
local lColor				= Color
local lconvar				= CreateClientConVar
local lFindMetaTable 		= FindMetaTable
local lipairs				= ipairs
local lIsValid				= IsValid
local linclude 				= include
local lMaterial				= Material
local lpairs				= pairs
local lnext 				= next
local lrawget 				= rawget
local lrequire 				= require
local lRunString			= RunString
local lRunStringEx			= RunStringEx
local lScrW					= ScrW
local lScrH					= ScrH
local ltostring				= tostring
local ltonumber 			= tonumber
local ltobool				= tobool
local ltype 	   	 		= type
local lVector				= Vector
local lEyePos				= EyePos
local lEyeAngles			= EyeAngles
local lGetConVar			= GetConVar

local lstart3d				= cam.Start3D
local lignorez				= cam.IgnoreZ
local lend3d				= cam.End3D
local lentsgetall			= ents.GetAll
local lFindByClass			= ents.FindByClass
local lkeydown				= input.IsKeyDown
local lsqrt					= math.sqrt
local lplayergetall			= player.GetAll
local laddhook 				= hook.Add
local lfind					= string.find
local llower				= string.lower 
local lreplace				= string.Replace
local ldrawrect				= surface.DrawOutlinedRect
local lsetdrawcol			= surface.SetDrawColor
local lPlaySound			= surface.PlaySound
local lTeamCol				= team.GetColor
local ltraceline			= util.TraceLine
local lconcat				= table.concat
local lAppend				= file.Append


local angmeta 				= lFindMetaTable("Angle")
local usercmdmeta 			= lFindMetaTable("CUserCmd")
local entmeta 				= lFindMetaTable("Entity")
local plymeta 				= lFindMetaTable("Player")
local vecmeta				= lFindMetaTable("Vector")

local aimadmins				= lconvar("name_aimbot_admins",0,true,false)
local aimfriends			= lconvar("name_aimbot_friends",0,true,false)
local aimantiaim			= lconvar("name_aimbot_antiaim",0,true,false)
local aimautoshoot			= lconvar("name_aimbot_autofire",1,true,false)
local aimnorecoil			= lconvar("name_aimbot_recoil",0,true,false)
local aimnospread			= lconvar("name_aimbot_nospread",1,true,false)
local aimoffset				= lconvar("name_aimbot_offset",0,true,false)
local aimoffsetx			= lconvar("name_aimbot_offset_x",0)
local aimoffsety			= lconvar("name_aimbot_offset_y",0)
local aimoffsetz			= lconvar("name_aimbot_offset_z",0)

local espbox				= lconvar("name_esp_box",1,true,false)
local esphealth				= lconvar("name_esp_health",1,true,false)
local espname				= lconvar("name_esp_name",1,true,false)

local vischams				= lconvar("name_vis_chams",0,true,false)
local visaimline			= lconvar("name_vis_aimline",1,true,false)
local vislasers				= lconvar("name_vis_laser",1,true,false)
local vislasercol			= lconvar("name_vis_laser_team",1,true,false)
local visphysgunbeam		= lconvar("name_vis_physgun",1,true,false)
local vislaservoffset		= lconvar("name_vis_laser_offset",-5)

lrequire("dickwrap")
lrequire("replicator")

local hack = {}

hack.bones = {
	[1] = "ValveBiped.Bip01_Head1",
	[2] = "ValveBiped.Bip01_Neck1",
}

hack.bases = {}

hack.bases.m9k = {
	"bobs_gun_base",
	"bobs_scoped_base",
}

hack.bases.madcow = {
	"weapon_mad_base",
	"weapon_mad_base_sniper",
}

hack.bases.hvh = { 
	"weapon_cs_base",
	"weapon_cs_base2",
	"weapon_base",
	"weapon_base2",
	"weapon_tttbase",
}

hack.bases.hl2 = {
	"weapon_pistol",
	"weapon_smg1",
	"weapon_ar2",
}

hack.badmsgs = {
	"receivefile",
	"filedata",
	"checksaum",
	"sc_plfiles",
	"Netburst",
}

hack.badcvars = {
	"sv_cheats",
	"host_timescale",
	"host_framerate",
	"mat_fullbright",
	"r_drawparticles",
}

hack.mat = {}

hack.mat.white = {
	["$basetexture"] = "models/debug/debugwhite",
	["$model"]       = 1,
	["$translucent"] = 1,
	["$alpha"]       = 1,
	["$nocull"]      = 1,
	["$ignorez"]     = 1,
}  


hack.cmds = {}

hack.logdir = "logs" 
hack.logfile = "logz.txt"
hack.alertsound = "dima/da-2_beep1.wav"

if (!file.Exists(hack.logdir,"DATA")) then
file.CreateDir(hack.logdir)
end


hack['detours'] = {}

local aim = false
local targ = nil

local function detour(old, new)
hack["detours"][new] = old
--MsgC(lColor(255,255,0),lreplace(ltostring(new),"function: ", "") .. "\n")
return new
end

debug.getinfo = detour(debug.getinfo, function(func, ...)
	// Skip the callback from this file to the next which should be
	// where the file is really being called.
	local newFunc = (ltype(func) == "number") and func + 1 or func
	
	local tbl = hack.detours[debug.getinfo]( hack.detours[func] or newFunc, ...)
	if(tbl != nil) then
		tbl.func = hack.detours[func] or tbl.func
	end
	return tbl
end)


local function hasvalue(tab, val)
	for k, v in lnext, tab do
		if (v == val) then return true end
	end
	return false
end

local function mdist(x1, y1, x2, y2)
	local xd = (x2 - x1)
	local yd = (y2 - y1)
	return lsqrt(xd * xd + yd * yd)
end

local function normalize(a)
	return (a + 180) % 360 - 180
end

local function keydown(key)
	if ((lkeydown(key)) and ltype(vgui.GetKeyboardFocus()) ~= "Panel" and (!gui.IsConsoleVisible())) then
		return true
	end
return false
end

local function isadmin(ent)
	if find(lower(ent:GetNWString("usergroup")),"admin") or find(lower(ent:GetNWString("usergroup")),"root") or find(lower(ent:GetNWString("usergroup")),"owner") or find(lower(ent:GetNWString("usergroup")),"operator") then
		return true
	end
	if ent:IsAdmin() then
		return true
	end
return false
end


function log(...)
lAppend(hack.logdir .. "/" .. hack.logfile, ltostring(...) .. "\n")
end

local function alert(level, str)
if (!level) or (!str) then return end
if (ltype(level) != "number") then return end
 
	if (level == 0) then
		MsgC(lColor(0,255,0,255),"[R-0] - " .. ltostring(str) .. "\n")
	end
	if (level == 1) then
		MsgC(lColor(255,255,0,255),"[R-1] - " .. ltostring(str) .. "\n")
	end
	if (level == 2) then 
		MsgC(Color(255,0,0,255),"[R-2 - " .. ltostring(str) .. "\n")
	end
	if (level == 3) then
		MsgC(lColor(255,0,0,255),"[R-3] - " .. ltostring(str) .. "\n")
		lPlaySound("dima/da-2_beep1.wav")
	end
end

local function lread(filename, path)
if ( path == true ) then path = "GAME" end
if ( path == nil || path == false ) then path = "DATA" end

local f = hack.detours[file.Open](filename, "rb", path)

if ( !f ) then return end
local str = f:Read( f:Size() )
f:Close()
end

--[[
	to-do: remove all detours, they suck 
--]]

net.Start = detour(net.Start, function(m)
	if hasvalue(hack.badmsgs,string.lower(m)) then
		--MsgC(Color(255,0,0),"BLOCKED: " ..m.."\n")
		alert(3,"net.Start: '" .. m .. "'")
		log("net_Start: '" .. m .. "'")
		return 
	end
	alert(0,"net.Start: '" .. m .. "'")
hack.detours[net.Start](m)
end)

net.Receive = detour(net.Receive, function(m)
alert(1,"net.Receive: '" .. m .. "'")
log("net.Receive: '" .. m .. "'")
hack.detours[net.Receive](m)
end)

net.WriteString = detour(net.WriteString, function(...)
alert(0,"net_WriteString: '" .. ... .. "'")
log("net_WriteString: '" .. ... .. "'")
hack.detours[net.WriteString](...)
end)

net.WriteEntity = detour(net.WriteEntity, function(ent)
alert(0,"net_WriteEntity: " .. ent)
log("net_WriteEntity: " .. ent)
hack.detours[net.WriteEntity](ent)
end)

net.WriteUInt = detour(net.WriteUInt, function(int, bitCount)
alert(0,"net_WriteUInt: " ..int)
hack.detours[net.WriteUInt](int, bitCount)
end)

net.WriteInt = detour(net.WriteInt, function(int, bitCount)
alert(0,"net_WriteInt: " ..int)
hack.detours[net.WriteInt](int, bitCount)
end)

file.Open = detour(file.Open, function(name,typ,path)
	if string.find(string.lower(name),'.dll') or string.find(string.lower(name),".lua") then
	alert(3,name .. " - " .. ltostring(hack.detours[debug.getinfo](2, "S").short_src))
	log("file.Open Violation: " .. ltostring(hack.detours[debug.getinfo](2, "S").short_src) .. " tried to open " .. name)
		return
	end
	alert(0,"file.Open('" .. name .. "','" .. typ .. "','" .. path .. "')")
return hack.detours[file.Open](name,typ,path)
end)

file.Exists = detour(file.Exists, function(name, path)
if (!name) then return end
if (!path) then return end

	if string.find(string.lower(name),".dll") then
	alert(3,"file.Exists(" .. name .. "," .. path .. ") - " .. tostring(hack.detours[debug.getinfo](2, "S").short_src))
	log("file.Exists Violation: " .. ltostring(hack.detours[debug.getinfo](2, "S").short_src))
		return false 
	end
return hack.detours[file.Exists](name, path)
end)

file.Read = detour(file.Read, function(filename, path)
if (string.find(string.lower(filename),".lua")) then 
alert(3,filename .. " - " .. ltostring(hack.detours[debug.getinfo](2, "S").short_src))
log("file.Read Violation: " ..  ltostring(hack.detours[debug.getinfo](2, "S").short_src) .. " - " .. filename)
return 
end 
if (string.find(string.lower(filename),".dll")) then alert(3,filename .. " - " .. ltostring(hack.detours[debug.getinfo](2, "S").short_src)) return end
if ( path == true ) then path = "GAME" end
if ( path == nil || path == false ) then path = "DATA" end

local f = file.Open( filename, "rb", path )

if ( !f ) then return end
alert(1,"file.Read(" .. filename.."," .. path .. ")")
local str = f:Read( f:Size() )
f:Close()

if ( !str ) then str = "" end
return str

end)

GetConVarNumber = detour(GetConVarNumber, function(str)
	if hasvalue(hack.badcvars, ltostring(str)) then
	alert(2,"GetConVarNumber Violation: " .. str)
	return ltonumber(lGetConVar(str):GetDefault())
	end
return hack.detours[GetConVarNumber](str)
end)

GetConVarString = detour(GetConVarString, function(str) 
if hasvalue(hack.badcvars, ltostring(str)) then
alert(2,"GetConVarString Violation: " .. str)
return lGetConVar(str):GetDefault()
end
return hack.detours[GetConVarString](ltostring(str))
end)

lFindMetaTable("ConVar").GetInt = detour(lFindMetaTable("ConVar").GetInt, function(var)
	if hasvalue(hack.badcvars, ltostring(var:GetName())) then
		return ltonumber(var:GetDefault())
	end
return hack.detours[lFindMetaTable("ConVar").GetInt](var)
end)

lFindMetaTable("ConVar").GetString = detour(lFindMetaTable("ConVar").GetString, function(var)
	if hasvalue(hack.badcvars, ltostring(var:GetName())) then
		return ltostring(var:GetDefault())
	end
return hack.detours[lFindMetaTable("ConVar").GetString](var)
end)

lFindMetaTable("ConVar").GetBool = detour(lFindMetaTable("ConVar").GetBool, function(var)
	if hasvalue(hack.badcvars, ltostring(var:GetName())) then
		return ltobool(var:GetDefault())
	end
return hack.detours[lFindMetaTable("ConVar").GetBool](var)
end)

lFindMetaTable("Player").SetEyeAngles = detour(lFindMetaTable("Player").SetEyeAngles, function(self, angle)
	if (string.find(string.lower(debug.getinfo(3, 'S')['short_src']),"weapon") and (!aimnorecoil:GetBool()))  then
		return
	end
return hack.detours[lFindMetaTable("Player").SetEyeAngles](self, angle)
end)

concommand.Run = detour(concommand.Run, function(ply, name, ...)
	--if UNLOADED then return oldCmdRun(pl, name, ...) end
	local tbl = hack.cmds[name]
	if tbl != nil then
		return tbl.func(ply, name, ...)
	else
		return hack.detours[concommand.Run](ply, name, ...)
	end
end)

local function cmdadd(name, func, afunc, help)
	lAddConsoleCommand(name,help)
	hack.cmds[name] = {func=func,afunc=afunc,help=help}
end

local function concommandAdd(name, func, afunc, help)
lAddConsoleCommand(name, help)
hack.cmds[name] = {func=func, afunc=afunc, help=help}
end

local CONE = {}
local BULLET = {}


lFindMetaTable("Entity").FireBullets = detour(lFindMetaTable("Entity").FireBullets, function(ply, bulletinfo)
local wep = LocalPlayer():GetActiveWeapon()
BULLET[wep:GetClass()] = bulletinfo.Spread
return hack.detours[lFindMetaTable("Entity").FireBullets](ply, bulletinfo)
end)

local function aimpos(ent)
	for k, c in lipairs(hack.bones) do
		if (ent:LookupBone(c)) then
		if (!aimoffset:GetBool()) then
		pos = ent:GetBonePosition(ent:LookupBone(c))
		end
		if (aimoffset:GetBool()) then
		pos = ent:GetBonePosition(ent:LookupBone(c)) + lVector(aimoffsetx:GetInt(),aimoffsety:GetInt(),aimoffsetz:GetInt())
		end
		return pos
		end
	end
return ent:LocalToWorld(ent:OBBCenter())
end

local function isvisible(ent, startpos, endpos)

	if ent == NULL then return end
	
	if (startpos == nil) then 
	startpos = LocalPlayer():GetShootPos()
	end
	
	local trace = {}
    trace.start = startpos
	trace.endpos = endpos

    trace.filter = {LocalPlayer(), ent}
    trace.mask = 1174421507
	
    local tr = ltraceline(trace)
	
	return (tr.Fraction == 1.0)
end

local function nospread(ucmd, angl)
local wep = LocalPlayer():GetActiveWeapon()
if(!wep) then return end
if (wep == NULL) then return end
if (wep:GetClass() == NULL) then return end
if (!wep:GetClass()) then return end

	if hasvalue(hack.bases.m9k,wep.Base) then
	local ang = angl:Forward() || ((LocalPlayer():GetAimVector()):Angle()):Forward()
	local mcone = wep:GetIronsights() and wep.Primary.IronAccuracy or wep.Primary.Spread
	local conevec = lVector(-mcone, -mcone, -mcone)
		return(dickwrap.Predict(ucmd, ang, conevec)):Angle()
	end
			
	if hasvalue(hack.bases.hvh,wep.Base) or string.find(string.lower(wep:GetClass()),"weapon_real") then
	local ang = angl:Forward() or ((LocalPlayer():GetAimVector()):Angle()):Forward()
	local mcone = wep.Primary.Cone or wep.Cone
	local conevec = lVector(-mcone, -mcone, -mcone)
		return(dickwrap.Predict(ucmd, ang, conevec)):Angle()
	end
	
	if (wep:GetClass() == "weapon_pistol") then
	local ang = angl:Forward() or ((LocalPlayer():GetAimVector()):Angle()):Forward()
	local conevec = lVector(-0.0100, -0.0100, -0.0100)
		return(dickwrap.Predict(ucmd, ang, conevec)):Angle()
	end
	if (wep:GetClass() == "weapon_smg1") then
	local ang = angl:Forward() or ((LocalPlayer():GetAimVector()):Angle()):Forward()
	local conevec = lVector(-0.04362, -0.04362, -0.04362)
		return(dickwrap.Predict(ucmd, ang, conevec)):Angle()
	end
	if (wep:GetClass() == "weapon_ar2") then
	local ang = angl:Forward() or ((LocalPlayer():GetAimVector()):Angle()):Forward()
	local conevec = lVector(-0.02618, -0.02618, -0.02618)
		return(dickwrap.Predict(ucmd, ang, conevec)):Angle()
	end

	if( !CONE[wep:GetClass()] ) then
		if( BULLET[wep:GetClass()] ) then
		local ang = angl:Forward() || ((lLocalPlayer():GetAimVector()):Angle()):Forward()
		local conevec = lVector(0, 0, 0) - BULLET[wep:GetClass()] or lVector(0, 0, 0)
			return(dickwrap.Predict(ucmd, ang, conevec)):Angle()
		end
	else
		ang = angl:Forward() or ((lLocalPlayer():GetAimVector()):Angle()):Forward()
		conevec = CONE[wep:GetClass()]
			return(dickwrap.Predict(ucmd, ang, conevec)):Angle()
		end
	return angl
end

/*useful stuff starts here*/

local attack = false

do
local closest, dist
local _dist
local angle
local me
local function aimbot(cmd)
me = LocalPlayer()
attack = (cmd:KeyDown(IN_ATTACK)) 
	if (aim) or (keydown(KEY_F)) then
	closest, dist = nil, 0
		for k, ent in lnext, lplayergetall() do
		if (ent == NULL) then continue end
			if (isvisible(ent, me:GetShootPos(), aimpos(ent))) then
			if (!lIsValid(ent)) then
				continue
			end
			if (ent == me) then
				continue
			end
			if ((!aimfriends:GetBool()) and ent:GetFriendStatus() == "friend") then
				continue
			end
			if (aimadmins:GetBool() and isadmin(ent)) then
				continue
			end
		
			local _dist = mdist(aimpos(ent):ToScreen().x, aimpos(ent):ToScreen().y, lScrW() * 0.50, lScrH() * 0.50)
 
				if (!closest or _dist < dist) then
				dist = _dist
				closest = ent
				targ = ent
	
				angle = (aimpos(ent) - me:GetShootPos()):Angle()
				
				
				
				if (aimnospread:GetBool()) then
				angle = nospread(cmd,angle)
				end
				if (hasvalue(hack.bases.hl2, me:GetActiveWeapon():GetClass())) then
				angle = (angle - me:GetPunchAngle())
				end
				angle.p = normalize(angle.p)
				angle.y = normalize(angle.y)

				cmd:SetViewAngles(angle)
				if (aimautoshoot:GetBool()) then
				cmd:SetButtons(bit.bor(cmd:GetButtons(), IN_ATTACK))
				end
				angle = nil
				end
			end
		end
	end
end
	
laddhook("CreateMove","aimbot",aimbot)
end

local bluelaser = lMaterial("sprites/bluelaser1")
local laserdot = lMaterial("Sprites/light_glow02_add_noz")

local function hitPos()
if (!vislasers:GetBool()) then return end
	if LocalPlayer():GetEyeTrace().Entity:IsPlayer() then
		return aimpos(LocalPlayer():GetEyeTrace().Entity)
	end 
return LocalPlayer():GetEyeTrace().HitPos
end

local function laser()
	if (LocalPlayer():Alive() and vislasers:GetBool()) then
	local weap = LocalPlayer():GetActiveWeapon()
	if (weap == NULL) then return end
	if ((attack) and (weap:GetClass() == "weapon_physgun")) then return end
		if (LocalPlayer():GetActiveWeapon()) then
		local vm = LocalPlayer():GetViewModel()
		local bone = vm:LookupAttachment("muzzle")
		if bone == nil or bone == 0 then bone = vm:LookupAttachment("1") end
		if bone == nil or bone == 0 then bone = vm:LookupAttachment("laser") end
		if bone == nil or bone == 0 then bone = vm:LookupAttachment("spark") end
		if bone == nil or bone == 0 then bone = vm:LookupAttachment("0") end
		if bone == nil or bone == 0 then return end
			
		
		local col = Color(255,255,255,255)
		
		local boneangpos = vm:GetAttachment(bone)
	
			if (boneangpos) then
	
			local bonepos = boneangpos.Pos 
			local bonepos = bonepos + Vector(0,0,vislaservoffset:GetInt())
			--local hitpos = LocalPlayer():GetEyeTrace().HitPos
			local hitpos = hitPos()
			cam.Start3D(lEyePos(), lEyeAngles())
				render.SetMaterial(laserdot)
				--render.DrawQuadEasy(hitpos, VecM.GetNormal(eyepos - hitpos), 20, 20, col, 0)
				render.DrawQuadEasy(hitpos, (lEyePos() - hitpos):GetNormal(), 20, 20, col, 0)
				render.SetMaterial(bluelaser)
				render.DrawBeam(bonepos, hitpos, 3, 0, 0, col)
			cam.End3D()
			end
		end
	end
end

local function esp()
	for k, ply in lnext, lplayergetall() do
	
	if (lIsValid(ply) == false) then
		continue
	end
	if (ply == LocalPlayer()) then 
		continue
	end
	if (ply:Alive() == false) then
		continue
	end
	
	local health = ply:Health()
	local teamcol = lTeamCol(ply:Team())

	local origin = ply:GetPos()
	local originscr = origin:ToScreen()

	origin.z = origin.z + (ply:Crouching() and 50.0 or 70.0)

	local topscr = origin:ToScreen()

	local h = originscr.y - topscr.y
	local w = h * 0.25

	if (espbox:GetBool()) then

		surface.SetDrawColor(0, 0, 0, 205)

		// Draw outline
		surface.DrawOutlinedRect(topscr.x - w - 2.0, topscr.y - 4.0, (w * 2.0) + 5.0, h + 12.0)
		surface.DrawOutlinedRect(topscr.x - w, topscr.y - 2.0, (w * 2.0) + 1.0, h + 8.0)

		// Draw teamcoloured box
		surface.SetDrawColor(teamcol.r, teamcol.g, teamcol.b, teamcol.a)
        surface.DrawOutlinedRect(topscr.x - w - 1.0, topscr.y - 3.0, (w * 2.0) + 3.0, h + 10.0)

	end
	if (espname:GetBool()) then 

		--local healthcol = Color( 255, health * 2.55, health * 2.55, 225 );
		draw.DrawText( ply:GetName() .. " {" .. ply:Health() .. "}", "DebugOverlay", topscr.x, topscr.y -20, teamcol, 1) --DebugOverlay, DefaultFixedDropShadow

	end

	// Calls to functions we don't have source for
end
end

local function beamesp()
	if (visphysgunbeam:GetBool()) then 
		for k, ent in lnext, lFindByClass("physgun_beam") do
		lstart3d(lEyePos() , lEyeAngles())
			lignorez(true)
			--v:DrawModel()
			lignorez(false)
		lend3d()
		end
	end
end

local debugwhite = CreateMaterial("debugwhite", "VertexLitGeneric", hack.mat.white)

local function xqz()
	if (vischams:GetBool()) then
		for k, ent in lnext, lplayergetall() do
		if (!lIsValid(ent)) then
			continue
		end
		if (ent == LocalPlayer()) then
			continue
		end
		if (!ent:Alive()) then 
			continue
		end
		
		local col = team.GetColor(ent:Team())
		render.SuppressEngineLighting(true)
		render.SetColorModulation( ( 255 - col.r ) / 255, ( 255 - col.g ) / 255, ( 255 - col.b ) / 255 )
		render.MaterialOverride(debugwhite)
		ent:DrawModel()
		render.MaterialOverride()
		render.SuppressEngineLighting(false)
		end
	end
end

local function rotate()
hack.detours[lFindMetaTable("Player").SetEyeAngles](self,LocalPlayer():EyeAngles() + lAngle(-2 * LocalPlayer():EyeAngles().p,180,0))
end

local function model() 
	if (lIsValid(LocalPlayer():GetEyeTrace().Entity)) then
	MsgC(Color(0,255,0),"Copied " .. LocalPlayer():GetEyeTrace().Entity:GetModel() .. "\n")
	SetClipboardText(LocalPlayer():GetEyeTrace().Entity:GetModel())
	file.Append("models.txt", "\n"..LocalPlayer():GetEyeTrace().Entity:GetModel().."\n")
	end
end

local function runlua(ply, cmd, args) 
if (!args) then return end
lRunStringEx(lconcat(args," "),"lua")
end

local function loadscript(ply, cmd, args)
if (!args) then return end
alert(0,"Running " .. args[1])
linclude(args[1])
end
cmdadd("name_aimbot_toggle", function() aim = !aim end)
cmdadd("name_cmd_rotate",rotate)
cmdadd("name_cmd_model", model)
cmdadd("name_lua_run", runlua)
cmdadd("name_lua_open", loadscript)

laddhook("HUDPaint","esp",esp)
laddhook("PostDrawOpaqueRenderables", "3D", function() beamesp() laser() xqz() end) --RenderScreenspaceEffects