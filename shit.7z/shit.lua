--[[
	MOD/lua/aim.lua [#4730 (#4730), 50580742, UID:1764561559]
	Calver | STEAM_0:0:36375256 <92.24.185.41:27005> | [07.04.14 04:29:28PM]
	===BadFile===
]]

local te = table.Empty
local concommand = concommand
local util = util
local player = player
local table = table
 
local pairs = pairs
local CreateClientConVar = CreateClientConVar
 
local var = CreateClientConVar("shit_fov", 0, true, false);  
local as = CreateClientConVar("shit_as",1,true,false)
local enabled = CreateClientConVar('shit_enable',1,true,false)
local ateam = CreateClientConVar('shit_aim_ignoreteam',0,true,false)
local shitf = CreateClientConVar('shit_aim_friends',0,true,false)
local shittb = CreateClientConVar('shit_tb',0,true,false)
local shitsh = CreateClientConVar('shit_antispawn',1,true,false)
local shitof = CreateClientConVar('shit_aim_offset',-5)
 
 
local Shit = {};
Shit.Aimspots = {
        "head",
        "forward",
        "eyes",
};
       
Shit.Aiming = false;
 
 
       
function Shit:GetHeadPos( e )
        for _, v in pairs( self.Aimspots ) do
        if IsValid(e) then
                if( e:GetAttachment( e:LookupAttachment( v ) ) ) then
                        return( e:GetAttachment( e:LookupAttachment( v ) ).Pos + Vector(0,0,shitof:GetInt())  );
                end
        end
end
end    
function Shit:IsVisible( e )
        local trace = {
                start = LocalPlayer():GetShootPos(),
                endpos = self:GetHeadPos( e ),
                filter = { e, LocalPlayer() },
                mask = MASK_SHOT
        };
        local tr = util.TraceLine( trace );
        return( tr.Fraction == 1.0 );
end
 
 
function Shit:Prediction( e, vec ) //Hermes v2
/*local view = Vector( 0, 0, 0 );
local fps = RealFrameTime() / 66;
local vel = e:GetVelocity() - LocalPlayer():GetVelocity();
view.x = vec.x + fps * vel.x;
view.y = vec.y + fps * vel.y;
view.z = vec.z + fps * vel.z;
return view;*/
if IsValid(e) then
return( vec + ( e:GetVelocity() * ( RealFrameTime() / 25 ) - ( LocalPlayer():GetVelocity() * ( RealFrameTime() / 66 ) ) ) );
end
end
 
function Shit:NormalizeAngles( ang )
        ang.p = math.NormalizeAngle( ang.p );
        ang.y = math.NormalizeAngle( ang.y );
        ang.r = 0;
        return ang;
end
 
function Shit:RemoveRecoil( u )
        local pang = u:GetViewAngles() - LocalPlayer():GetPunchAngle();
        self:NormalizeAngles( pang );
        u:SetViewAngles( pang );
end
 
local function FOVRestrict(v, value)
 
        return LocalPlayer():GetAimVector():DotProduct( (v:GetPos() - LocalPlayer():GetPos()):GetNormal() ) > value
end
 
function Shit:Aimbot( u )
 
if enabled:GetBool() then
        if( !self.Aiming ) then
                return;
        end
        for _, v in pairs( player.GetAll() ) do
                if( v == LocalPlayer() ||
                !self:IsVisible( v ) ||
                !v:Alive() ||
                v:InVehicle() ||
                v:GetMoveType() == MOVETYPE_OBSERVER ||
                GetConVar( "sbox_noclip" ):GetInt() == 0 && v:GetMoveType() == MOVETYPE_NOCLIP) then
                        continue;
                end
               
                if ateam:GetBool() and v:Team() == LocalPlayer():Team() then
                        continue
                end
               
                if !shitf:GetBool() and v:GetFriendStatus() == "friend" then
                continue
                end
               
                if shitsh:GetBool() and v:GetColor().a == 200 then
                continue
                end
 
                if(!FOVRestrict(v, var:GetFloat())) then
                        continue;
                end    
               
                if v:Health() < 0 then continue
                end
               
                       
                local pos = self:GetHeadPos( v );
                pos = self:Prediction( v, pos );
                local angl = ( pos - LocalPlayer():GetShootPos() ):Angle();
                self:NormalizeAngles( angl );
                self:RemoveRecoil( u );
                u:SetViewAngles( angl );
       
               
                if as:GetBool() then u:SetButtons( bit.bor( u:GetButtons(), IN_ATTACK ) )
        end
end
end
end
concommand.Add( "+aimbot", function() Shit.Aiming = true end );
concommand.Add( "-aimbot", function() Shit.Aiming = false end );
 
local function HookCreateMove( u )
        Shit:Aimbot( u );
end
hook.Add( "CreateMove", "nrc", HookCreateMove );
 
wep = _G.LocalPlayer():GetActiveWeapon();
if( _G.IsValid( wep ) ) then
if( wep.Primary ) then
wep.Primary.Recoil = 0.0
end
if( wep.Secondary ) then
wep.Secondary.Recoil = 0.0
end
end
 
       
 
function table.Empty(tbl)
        if tbl == debug.getregistry() or tbl == _G then return
        MsgC(Color(100,100,255),"Crash attempt blocked\n")
end
 te(tbl)
end
 
concommand.Add('col', function()
        print(LocalPlayer():GetColor().a)
end)