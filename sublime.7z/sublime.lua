local sublime = sublime 

local command = {}
local entities = {}

local me = LocalPlayer()
local myPos
local myWep 

// Target prediction
local TICK_INTERVAL = engine.TickInterval()
local SV_GRAVITY = GetConVar("sv_gravity"):GetFloat()

local function StrafePrediction( ent, vVelocity )
    if not ent.m_vecLastVelocity then 
        ent.m_vecLastVelocity = vVelocity  
    end

    local vLastVelocity = ent.m_vecLastVelocity  
    local flCurrentYaw = math.deg( math.atan2( vVelocity.y, vVelocity.x ) )  
    local flLastYaw = math.deg( math.atan2( vLastVelocity.y, vLastVelocity.x ) )  
    local rotation = Angle( 0, math.NormalizeAngle( flCurrentYaw - flLastYaw ), 0 )  

    ent.m_vecLastVelocity = vVelocity 
    
    return rotation
end

local traceData = {}
local function PerformStrafePrediction( ent, ticks )
	local Vel = ent:GetVelocity()
	local PredPos = ent:GetNetworkOrigin()
	local Rotation = StrafePrediction(ent, Vel)
	local Grav = Vector(0, 0, SV_GRAVITY)
	
    traceData = {}
    traceData.filter = ent
    traceData.mask = MASK_PLAYERSOLID
    traceData.mins = ent:OBBMins()
    traceData.maxs = ent:OBBMaxs()
    
	for i = 1, ticks do
        traceData.start = PredPos
        traceData.endpos = PredPos - Grav * TICK_INTERVAL

        local traceResult = util.TraceHull( traceData )  
		
		Vel = Vel - Grav * TICK_INTERVAL
		
        local nextPos = PredPos + Vel * TICK_INTERVAL
        
		Vel:Rotate(Rotation)
		
        traceData.start = PredPos + Vector(0, 0, ent:GetStepSize())
        traceData.endpos = nextPos  
        
        local traceResult = util.TraceHull( traceData )  
		
		PredPos = traceResult.HitPos
	end
    
	return PredPos
end

local function Extrapolate( ply, pos )
    pos = PerformStrafePrediction( ply, 16 )

    debugoverlay.Box(pos, ply:OBBMins(), ply:OBBMaxs(), 0.1, Color( 0, 0, 255, 32 ), true )

    return pos 
end

// Angle calculation
local PROJECTILE_INTERVAL = 0.05
local CONST_GRAVITY = 9.81 * 51.4285714

local function CalcAimbot()
    local bestDistance = math.huge 
    local bestPlayer = NULL 
    local bestPosition = myPos

    entities = player.GetAll() 

    for i = 1, #entities do
        local ent = entities[ i ]
    
        if ent == me or not ent:Alive() or ent:IsDormant() then
            continue 
        end

        local position = ent:GetPos()
        local distance = position:DistToSqr( myPos )

        if distance < bestDistance then
            bestDistance = distance
            bestPlayer = ent
            bestPosition = position
        end
    end

    if not IsValid( bestPlayer ) then
        return nil, nil 
    end

    local swepRange = myWep.Range * PROJECTILE_INTERVAL

    local travelTime = math.ceil( math.sqrt( bestDistance ) / swepRange )

    print( swepRange, travelTime, math.sqrt( bestDistance ) )

    bestPosition = Extrapolate( bestPlayer, bestPosition )
    bestPosition = bestPosition + bestPlayer:OBBCenter()

    local hitAng = ( bestPosition - myPos ):Angle()

    return bestPlayer, hitAng
end

local shouldRender = false
local function CreateMoveHk( cmd )
    command = {
        viewAngles  = cmd:GetViewAngles(),
        number      = cmd:CommandNumber(),
    }

    if command.number == 0 or not input.IsKeyDown( KEY_F ) then
        return 
    end

    myPos = me:EyePos()
    myWep = me:GetActiveWeapon()

    if not IsValid( myWep ) then
        return 
    end

    local ply, ang = CalcAimbot()

    if not IsValid( ply ) then
        return 
    end

    ang:Normalize()
    cmd:SetViewAngles( ang )
end

hook.Add( "CreateMove", "PredictedAimbot", CreateMoveHk )


