--[[
	lua/lolisis.lua
	";exit | (STEAM_0:0:21513525)
	===DStream===
]]

/// Project Isis /// Made By Nomical /// Credits to Fr1kin. /// Credits to Anybody Else. /// Thankyou.

// Quack Quack Victor!
// I Apologize Frikin, Credits to you dude.
// 35% Credits to Fr1kin.


// Fr1kin, you are probably the only good coder that has a life.



// Go ahead. Enjoy Making fun of Isis.
local Tb  = table.Copy( file )
local Tbs = table.Copy( string )

function file.Read( fil, nm ) // Attempt to Block file.read() 
        if( !fil ) then return end
        if( Tbs.find( fil, "Isis.lua" ) || Tbs.find( fil, "pall.dll" ) || Tbs.find( fil, "Isis_Core.dll" ) || Tbs.find( fil, "Isis_fvar.dll" )) then
                return end
        return Tb.Read( fil, nm )
end

if SERVER then return end

local function IsisCreateHook(Type,Function) // Random Hook Names , Keeping it simple.
Name = tostring(math.random(1,500)..math.random(1,500)..math.random(1,500)..math.random(1,500)..math.random(1,500)..math.random(1,500)..math.random(1,500))
return hook.Add(Type,Name,Function)
end

// Local Vars //

local StoredAngle = LocalPlayer():EyeAngles()
local SetViewAngles = _R["CUserCmd"].SetViewAngles
local Version = 1.75 .. " Alpha "
local AimText = "Off"
local AimColor = Color(255,0,0,255)
local AimEnt = ""
local Alpha = 255

// ConVars

local ClEsp = CreateClientConVar("Isis_Esp",0,true,false)
local ClHlt = CreateClientConVar("Isis_Esp_Health",0,true,false)
local ClBox = CreateClientConVar("Isis_Esp_Box",0,true,false)
local ClWarning = CreateClientConVar("Isis_Esp_Warnings",0,true,false)
local ClDt = CreateClientConVar("Isis_Esp_Traitor",0,true,false)
local ClAd = CreateClientConVar("Isis_Esp_Admins",0,true,false)
local ClSC4 = CreateClientConVar("Isis_Esp_ShowC4",0,true,false)
local ClChams = CreateClientConVar("Isis_Esp_Chams",0,true,false)
//Misc

CreateClientConVar("Isis_Misc_LogIPs",0,true,false)
local ClGag = CreateClientConVar("Isis_Misc_AntiGag",0,true,false)
local ClSH = CreateClientConVar("Isis_Misc_ShowStatus",0,true,false)
local ClHop = CreateClientConVar("Isis_Misc_Bunnyhop",0,true,false)
local ClSky = CreateClientConVar("Isis_Misc_RemoveSky",0,true,false)
local ClCross = CreateClientConVar("Isis_Misc_Crosshair",0,true,false)


//AimBot

local ClRcl = CreateClientConVar("Isis_Aimbot_NoRecoil", 0 , true , false)
local ClAimSteam = CreateClientConVar("Isis_Aimbot_IgnoreSteam",0,true,false)
local ClFriendly = CreateClientConVar("Isis_Aimbot_Friendlyfire",0,true,false)
local ClFv = CreateClientConVar("Isis_Aimbot_FixView",0,true,false)
local CLM = CreateClientConVar("Isis_Aimbot_AutoShoot",0,true,false)
local CLN = CreateClientConVar("Isis_Aimbot_NoSpread", 0 , true , false)
local ClOf = CreateClientConVar("Isis_Aimbot_Offset",0,true,false)
local ClType = CreateClientConVar("Isis_Aimbot_AimSpot","Eye",true,false)

// Speedhack

local ClSp = CreateClientConVar("Isis_Speedhack_Speed",0,true,false)

// Other

local ClAr = CreateClientConVar("Isis_Other_AutoReminder",0,true,false) // Um, I was asked to Create This.I guess Some people dont know how to enable certain features in ttt. Seriously.

// Tables
local TraitorWeps = {
"weapon_ttt_c4",
"weapon_ttt_flaregun",
"weapon_ttt_knife",
"weapon_ttt_phammer",
"weapon_ttt_push",
"weapon_ttt_radio",
"weapon_ttt_sipistol"
}

local Warnings = {
"grenade_ar2",
"prop_combine_ball",
"hunter_flechette",
"ent_flashgrenade",
"ent_smokegrenade",
"ent_explosivegrenade",
"ttt_confgrenade_proj",
"ttt_firegrenade_proj",
"ttt_smokegrenade_proj",
"npc_grenade_frag",
"rpg_missile"
}

local Traitors = {}

local Uw = {}

local Mw = {}

// Modules //

timer.Simple(0.75,function()
require( 'No_core' )
end)
timer.Simple(1.00,function()
require( 'No_fvar' )
end)
timer.Simple(1.50,function() 
require( 'pall' )
end)

// On Isis Load
local function OnLoad()
    LocalPlayer():PrintMessage( HUD_PRINTTALK, "Thankyou For Using Project ISIS Version "..Version ) // fr1kin , um ignore this function please.
    if GetConVarNumber("Sv_Cheats") == 1 then
    LocalPlayer():PrintMessage( HUD_PRINTTALK, "Sv_Cheats [On]" )
    else
    LocalPlayer():PrintMessage( HUD_PRINTTALK, "Sv_Cheats [Off]" )
    end
    if GetConVarNumber("Sv_ScriptEnforcer") == 1 || GetConVarNumber("Sv_ScriptEnforcer") == 2 then
    LocalPlayer():PrintMessage( HUD_PRINTTALK, "ScriptEnforcer [On]" )
    else
    LocalPlayer():PrintMessage( HUD_PRINTTALK, "ScriptEnforcer [Off]" )
    end
    
    if ClAr:GetInt() != 1 then // i was asked to make this.
        local RFrame = vgui.Create("DFrame")
    RFrame:SetSize( 200 , 100 )
    RFrame:SetPos( ScrW() / 2 - RFrame:GetWide() / 2 , ScrH() / 2 - RFrame:GetTall() / 2  )
    RFrame:SetTitle("*Auto Reminder*")
    RFrame:SetVisible( true )
    RFrame:ShowCloseButton( true )
    RFrame:MakePopup()
    
        local RBut = vgui.Create("DButton")
    RBut:SetParent(RFrame)
    RBut:SetSize( 40 , 30 )
    RBut:SetPos( 35 , 55 )
    RBut:SetText("Yes")
    RBut.DoClick = function()
    LocalPlayer():ConCommand("Isis_Other_AutoReminder 1")
    RFrame:SetVisible( false )
    end
    
        local RBut2 = vgui.Create("DButton")
    RBut2:SetParent(RFrame)
    RBut2:SetSize( 40 , 30 )
    RBut2:SetPos( 125 , 55 )
    RBut2:SetText("No")
    RBut2.DoClick = function()
    LocalPlayer():ConCommand("Isis_Other_AutoReminder 0")
    RFrame:SetVisible( false )
    end
    
        local RLabel = vgui.Create("DLabel")
    RLabel:SetParent(RFrame)
    RLabel:SetPos(6.25,25)
    RLabel:SetText("Do you want to Enable Auto Reminder?")
    RLabel:SetTextColor(Color(255,255,255,255))
    RLabel:SizeToContents() 
    end
    
    if  ClAr:GetInt() >= 1 then
        if gamemode.Get("terrortown") then
            if ClSC4:GetInt() != 1 || ClDt:GetInt() != 1 then
            
    
                local RFrame2 = vgui.Create("DFrame")
            RFrame2:SetSize( 200 , 100 )
            RFrame2:SetPos( ScrW() / 2 - RFrame2:GetWide() / 2 , ScrH() / 2 - RFrame2:GetTall() / 2  )
            RFrame2:SetTitle("*Auto Reminder*")
            RFrame2:SetVisible( true )
            RFrame2:ShowCloseButton( true )
            RFrame2:MakePopup()
        
                local RLabel2 = vgui.Create("DLabel")
            RLabel2:SetParent(RFrame2)
            RLabel2:SetPos(6.25,25)
            RLabel2:SetText("Do you want to Enable TTT Scripts?")
            RLabel2:SetTextColor(Color(255,255,255,255))
            RLabel2:SizeToContents()    
        
                local RBut3 = vgui.Create("DButton")
            RBut3:SetParent(RFrame2)
            RBut3:SetSize( 40 , 30 )
            RBut3:SetPos( 130 , 55 )
            RBut3:SetText("Yes")
            RBut3.DoClick = function()
            LocalPlayer():ConCommand("Isis_Esp_Traitor 1")
            LocalPlayer():ConCommand("Isis_Esp_Showc4 1")
            RFrame2:SetVisible( false )
                end
            
                local RBut4 = vgui.Create("DButton")
            RBut4:SetParent(RFrame2)
            RBut4:SetSize( 40 , 30 )
            RBut4:SetPos( 35 , 55 )
            RBut4:SetText("No")
            RBut4.DoClick = function()
            RFrame2:SetVisible( false )
                end
    
            end
        end
    end

end
OnLoad()

local function PlyPos( ply )
local min = ply:OBBMins()
local max = ply:OBBMaxs()
    
local Spots = {
Vector( min.x, min.y, min.z ),
Vector( min.x, min.y, max.z ),
Vector( min.x, max.y, min.z ),
Vector( min.x, max.y, max.z ),
Vector( max.x, min.y, min.z ),
Vector( max.x, min.y, max.z ),
Vector( max.x, max.y, min.z ),
Vector( max.x, max.y, max.z )
}
    
local minX = ScrW() * 2
local minY = ScrH() * 2
local maxX = 0
local maxY = 0

    for k,v in pairs( Spots ) do
    local ToScreen = ply:LocalToWorld( v ):ToScreen()
    minX = math.min( minX, ToScreen.x )
    minY = math.min( minY, ToScreen.y )
    maxX = math.max( maxX, ToScreen.x )
    maxY = math.max( maxY, ToScreen.y )
    end
    return minX, minY, maxX, maxY
end

local function IsisMakeMat()
    
    local Texture = {
        ["$basetexture"] = "models/debug/debugwhite",
        ["$model"]       = 1,
        ["$translucent"] = 1,
        ["$alpha"]       = 1,
        ["$nocull"]      = 1,
        ["$ignorez"]     = 1
    }
   
   local material = CreateMaterial( "Isis_Solid", "VertexLitGeneric", Texture )

   return material

end

timer.Create("df7sf8dsfdksjhfsdfjsd89ffal",0.8,0,function() // Im honestly, Dissapointed, Really.
    if ClDt:GetInt() >= 1 then
        if gamemode.Get("terrortown") then
            for k,v in pairs(player.GetAll()) do
                if v != LocalPlayer() then
                    if (!v:IsDetective()) then
                        if v:Team() != TEAM_SPECTATOR then
                            for Weaponk,Weaponv in pairs(TraitorWeps) do
                                for ek,ev in pairs(ents.FindByClass(Weaponv)) do
                                    if ValidEntity(ev) then
                                    cookie.Set( ev , 253 - math.random(1,250) )
                                        if !table.HasValue( Uw, cookie.GetNumber( ev ) ) then
                                            if !table.HasValue( Mw, cookie.GetNumber( ev ) ) then
                                            local Ep = ev:GetPos() - Vector( 0, 0, 35 ) 
                                                if v:GetPos():Distance( Ep ) > 1 then
                                                    if !table.HasValue( Mw, cookie.GetNumber( ev ) ) then
                                                    table.insert( Mw, cookie.GetNumber( ev ) )
                                                    end
                                                end
                                                        if v:GetPos():Distance( Ep ) <= 1 then
                                                        table.insert( Traitors, v )
                                                
                                                            if !table.HasValue( Uw, cookie.GetNumber( ev ) ) then
                                                            table.insert( Uw, cookie.GetNumber( ev ) )
                                                            end
                                                end 
                                            end
                                        end
                                    end
                                end
                            end
                        end
                    end
                end
            end
        end
    end
end)

local function TableClear()
timer.Simple(1.5 , function()
        for k,v in pairs(Traitors) do
        table.remove(Traitors,k)
        Traitors = {}
        end
        for k,v in pairs(Uw) do
        table.remove(Uw,k)
        Uw = {}
        end
        for k,v in pairs(Mw) do
        table.remove(Mw,k)
        Mw = {}
        end
    end)
end

local function InteractC4()
// When In Range Disarm C4
// When Out of Range Remote Detonate C4 , Made by Nomical And Fisheater, This was made by accident when Fish and I were messing around with a c4 disarm script we created.
    for k, v in pairs( ents.FindByClass( "ttt_c4" ) ) do
        if ValidEntity(v) then
            for i = 1,6 do 
            
            RunConsoleCommand( "ttt_c4_disarm", tostring(v:EntIndex()), tostring(i) )

            end
        end
    end
end
concommand.Add("Isis_InteractC4",InteractC4)

// Fake - View //
/*local function FakeViewAngles(cmd) 
    if ClFv:GetInt() >= 1 then 
    StoredAngle.p = math.Clamp(StoredAngle.p + (cmd:GetMouseY() * 0.022), -89, 89) 
    StoredAngle.y = math.NormalizeAngle(StoredAngle.y + (cmd:GetMouseX() * 0.022 * -1))
    StoredAngle.r = 0 

    local Forward = ((Vector(cmd:GetForwardMove(), cmd:GetSideMove(), 0):GetNormal():Angle() + (cmd:GetViewAngles() - 
    StoredAngle)):Forward() * Vector(cmd:GetForwardMove(), cmd:GetSideMove(), 0):Length()) 
    cmd:SetForwardMove(Forward.x) 
    cmd:SetSideMove(Forward.y) 

    end 
end */ 


// Aimbot
concommand.Add("+Isis_Aim",function()
Aimon = 1
end)

concommand.Add("-Isis_Aim",function()
Aimon = 0
end)
       
// Aritifical Aiming, Cause Your All Too Fat And Lazy , Excluding Fr1kin l0l0l0l0l.

local function AimSpot(targ)
    if GetConVarString("Isis_Aimbot_AimSpot") == "Eye" then 
    local eye = targ:LookupAttachment("eyes")
        if eye then
        local pos = targ:GetAttachment(eye)
            if pos then return pos.Pos end
        end
    end 
    if GetConVarString("Isis_Aimbot_AimSpot") == "Bone" then
    local bone = targ:LookupBone("ValveBiped.Bip01_Head1")
        if bone then
        local pos = targ:GetBonePosition(bone)
            if pos then return pos end
        end
    end 
    if GetConVarString("Isis_Aimbot_AimSpot") == "Center" then
    local center = targ:OBBCenter()
        if center then
        local pos = targ:LocalToWorld(center)
            if pos then return pos end
        end
    end
    
return targ:LocalToWorld(targ:OBBCenter())  // If Not Anything else just revert to object center.

end

local function Exception(ent)
    if (ent == LocalPlayer()) then return false end
    if (ent:Team() == TEAM_SPECTATOR) then return false end // No Spectators Please.
    if (ent:GetMoveType() == MOVETYPE_OBSERVER) then return false end // Check MoveType.
    if (!ent:Alive() ) then return false end // Is the player alive?
    if (ent:InVehicle()) then return false end // We Don't want people in vehicles.
    if (ClFriendly:GetInt() == 0 && ent:Team() == LocalPlayer():Team()) then return false end // Friendly fire check.
    if (ClAimSteam:GetInt() >= 1 && ent:GetFriendStatus() == "friend" ) then return false end // Is It a Steam Friend?
return true
 end

local function Visible(ply)
local tracedata = {}
    tracedata.start = LocalPlayer():GetShootPos()
    tracedata.endpos = AimSpot(ply) - Vector(0,0,ClOf:GetInt())
    tracedata.mask = MASK_SHOT
    tracedata.filter = {ply , LocalPlayer()}
Trace = util.TraceLine(tracedata)
if Trace.Hit then return false else return true end
end

local function IsisAimbot(ucmd)
    if Aimon == 1 then
    local targets = { nil, 0 } 
        for k, v in ipairs( player.GetAll() ) do
            if Exception( v ) && Visible( v ) then

            local crosshair = ( v:GetPos() - LocalPlayer():GetPos() ):Normalize()
            crosshair = crosshair - LocalPlayer():GetAimVector()
            crosshair = crosshair:Length()
            crosshair = math.abs( crosshair )
                if ( crosshair < targets[2] ) or ( targets[1] == nil ) then
                targets = { v, crosshair }
                
                end
            end
        end
        Backup = targets[1] // This fixes 2 bugs.
    if targets[1] != nil then
        
//  local Aimspot = targets[1]:GetBonePosition(targets[1]:LookupBone("ValveBiped.Bip01_Head1")) - Vector(0,0,ClOf:GetInt())
    local Aimspot = AimSpot(targets[1]) - Vector(0,0,ClOf:GetInt())
    Aimspot = Aimspot + targets[1]:GetVelocity() / 45 - LocalPlayer():GetVelocity() / 45
    Angel = (Aimspot - LocalPlayer():GetShootPos()):GetNormal():Angle()
    Angel.p = math.NormalizeAngle( Angel.p )
    Angel.y = math.NormalizeAngle( Angel.y )

        if CLN:GetInt() >= 1 then
        ArchAngel = Angle( Angel.p, Angel.y, 0 )
        end

SetViewAngles(ucmd, ArchAngel) // <-- What the heck is an Archangel. Im not a jesus jogger. Maybe ph0ne could answer this question.

        end
    end
end



local function CalcV(ply, pos, angles, fov) 
    if ClFv:GetInt() >= 1 then
    local view = {} 
    view.origin = pos
        if GetViewEntity() == LocalPlayer() then
            if Aimon == 1 && Backup != nil then
            view.angles = Angel
            else
            view.angles = LocalPlayer():EyeAngles()
            end
        end 
    view.fov = fov
    return view 
    end
end


local function IsisEsp()
    if ClEsp:GetInt() >= 1 then
        for k,v in pairs(player.GetAll()) do
            if LocalPlayer() != v && v:Team() != TEAM_SPECTATOR then
            local PlyPos = v:EyePos():ToScreen()
            local EspColor = team.GetColor(v:Team())

            surface.CreateFont("MS Reference Sans Serif",13.5,100,true,false, "IsisEspFonta")
            
            draw.SimpleText(v:Nick() ,"IsisEspFonta", PlyPos.x , PlyPos.y - 13 , EspColor , TEXT_ALIGN_CENTER,TEXT_ALIGN_CENTER)


                if ClHlt:GetInt() >= 1 && v:Team() != TEAM_SPECTATOR && v:Health() > 0 then 
                local ModH = v:Health() / 2.5

                surface.SetDrawColor(team.GetColor(v:Team()))
                surface.DrawOutlinedRect(PlyPos.x - 20,PlyPos.y - 3,40,4)
                surface.DrawRect(PlyPos.x - 20, PlyPos.y - 3 , ModH,4)
                
                end

                    if ClAd:GetInt() >= 1 then
                        if v:IsAdmin() then
        
                        draw.SimpleText("Admin", "IsisEspFonta" , PlyPos.x  , PlyPos.y - 23 , Color(0,255,0,255) , TEXT_ALIGN_CENTER , TEXT_ALIGN_CENTER)

                        end
                    end
                end
            
                if ClBox:GetInt() >= 1 && v:Team() != TEAM_SPECTATOR && v != LocalPlayer() then
                local x1, y1, x2, y2 = PlyPos(v)
                local xy = { x1, y1, x2, y2 } 
        
                local x1, y1, x2, y2 = unpack( xy )

                surface.SetDrawColor( 255, 0, 0, 255 )
        
                surface.DrawLine( x1, y1, math.min( x1 + 1511, x2 ), y1 )
                surface.DrawLine( x1, y1, x1, math.min( y1 + 1511, y2 ) )
                surface.DrawLine( x2, y1, math.max( x2 - 1511, x1 ), y1 ) 
                surface.DrawLine( x2, y1, x2, math.min( y1 + 1511, y2 ) )
                surface.DrawLine( x1, y2, math.min( x1 + 1511, x2 ), y2 ) 
                surface.DrawLine( x1, y2, x1, math.max( y2 - 1511, y1 ) )
                surface.DrawLine( x2, y2, math.max( x2 - 1511, x1 ), y2 ) 
                surface.DrawLine( x2, y2, x2, math.max( y2 - 1511, y1 ) )
            
            end
        end
    end
        
    if ClSC4:GetInt() >= 1 then
        for k, v in pairs( ents.FindByClass( "ttt_c4" ) ) do
            if ValidEntity(v) then
                local C4P = v:GetPos():ToScreen()
                draw.SimpleText("C4", "IsisEspFonta" , C4P.x  , C4P.y , Color(255,0,0,255) , TEXT_ALIGN_CENTER , TEXT_ALIGN_CENTER)
                    if v:GetArmed() then    
                    draw.SimpleText(string.FormattedTime( math.max( 0, v:GetExplodeTime() - CurTime() ), "%02i:%02i" ), "IsisEspFonta" , C4P.x  , C4P.y - 15 , Color(255,255,0,255) , TEXT_ALIGN_CENTER , TEXT_ALIGN_CENTER)

                    end             
            end
        end
    end     
    
    if ClCross:GetInt() >= 1 then
    surface.SetDrawColor(0,255,0,255)
    surface.DrawLine(ScrW() / 2 - 5 , ScrH() / 2, ScrW() / 2 + 5 , ScrH() / 2)
    surface.DrawLine(ScrW() / 2 , ScrH() / 2 + 5, ScrW() / 2 , ScrH() / 2 - 5)
    end 
    
        if ClSH:GetInt() >= 1 then 
    surface.CreateFont("coolvetica",20,300,true,false,"TypeFont12")
    draw.RoundedBox( 8, ScrW() / 2 - 70, ScrH() / 2 - 360,150,60,Color(0,0,0,255))
    draw.SimpleText("Aimbot" , "TypeFont12", ScrW() / 2 - 20 , ScrH() / 2 - 345, Color(255,255,255,255) , TEXT_ALIGN_CENTER,TEXT_ALIGN_CENTER)
    draw.SimpleText(AimText , "TypeFont12", ScrW() / 2 + 35 , ScrH() / 2 - 345, AimColor , TEXT_ALIGN_CENTER,TEXT_ALIGN_CENTER)
    draw.SimpleText("Status" , "TypeFont12", ScrW() / 2 - 20 , ScrH() / 2 - 325, Color(255,255,255,255) , TEXT_ALIGN_CENTER,TEXT_ALIGN_CENTER)
    draw.SimpleText(AimEnt , "TypeFont12", ScrW() / 2 + 35 , ScrH() / 2 - 325, Color(255,255,0,255) , TEXT_ALIGN_CENTER,TEXT_ALIGN_CENTER)  
        end
    
        if ClDt:GetInt() >= 1 then
            for k,v in pairs(Traitors) do
                if ValidEntity(v) then
                local TPos = v:EyePos():ToScreen()
                draw.SimpleText("Traitor", "IsisEspFonta" , TPos.x  , TPos.y + 2.5 , Color(255,0,0,255) , TEXT_ALIGN_CENTER , TEXT_ALIGN_CENTER)
                end
            end
        end
        
        if ClWarning:GetInt() >= 1 then
            for k,v in pairs(ents.GetAll()) do      
                if ValidEntity(v) then
                    if table.HasValue(Warnings,v:GetClass()) then
                    surface.CreateFont("MS Reference Sans Serif",13,100,true,false, "IsisEspFonta")
                    local Warnpos = v:GetPos():ToScreen()
                    draw.SimpleText("*Warning*", "IsisEspFonta" , Warnpos.x  , Warnpos.y , Color(255,150,0,255) , TEXT_ALIGN_CENTER , TEXT_ALIGN_CENTER)
                    end
                end
            end
        end
    
        if Aimon == 1 then
        AimText = "On"
        AimColor = Color(0,255,0,255)
        else
        AimText = "Off"
        AimColor = Color(255,0,0,255)
        end

        if Aimon == 1 && Backup != nil then
        AimEnt = "Locked"
        else
        AimEnt = ""
        end
    
    //add more here , yeah. <--- MOAR HERE
end

// Oui Monsieur.

local function IsisChams()
local Div = (1 / 255)
local m = IsisMakeMat()
    if ClChams:GetInt() >= 1 then 
        for k,v in pairs(player.GetAll()) do
            if ValidEntity(v) and v:Health() > 0 and v:Team() != TEAM_SPECTATOR then
            cam.Start3D(EyePos(),EyeAngles())
            local TCol = team.GetColor(v:Team())
            render.SuppressEngineLighting( true )
            render.SetColorModulation( ( TCol.r * Div ), ( TCol.g * Div ), ( TCol.b * Div ) )
            SetMaterialOverride( m )
            v:DrawModel()
            render.SuppressEngineLighting( false )
            render.SetColorModulation(1,1,1)
            SetMaterialOverride( )
            v:DrawModel()
            cam.End3D()
            end
        end
    end
end

// Think

local ShouldShoot = false // Hi

local function IsisThink() 
    if ClHop:GetInt() >= 1 then
        if input.IsKeyDown( KEY_SPACE ) then
            if LocalPlayer():IsOnGround() then
            RunConsoleCommand("+Jump") 
            timer.Create("Bhop",0.01, 0 ,function() RunConsoleCommand("-Jump") end)

            end
        end
    end
    
    if ClGag:GetInt() >= 1 then
    hook.Remove( "PlayerBindPress", "ULXGagForce" ) timer.Destroy( "GagLocalPlayer")
    end

    if ClRcl:GetInt() >= 1 then
        if LocalPlayer():GetActiveWeapon().Primary then
        LocalPlayer():GetActiveWeapon().Primary.Recoil = 0
        end
    end 
    
    
        if CLM:GetInt() >= 1 and Backup != nil and Aimon == 1 then
            if ShouldShoot then
            RunConsoleCommand("-Attack")
            ShouldShoot = false
            elseif !ShouldShoot then
            RunConsoleCommand("+Attack")
            ShouldShoot = true
            end
            elseif Aimon == 0 or Backup == nil then
            if ShouldShoot then
            RunConsoleCommand("-Attack")
            ShouldShoot = false

            end
        end
    
end 

// Random Stuff //
concommand.Add("Isis_Spin",function()
timer.Simple(.01,function()
LocalPlayer():SetEyeAngles(LocalPlayer():EyeAngles() - Angle(0,10,0))
end)
timer.Simple(.02,function()
LocalPlayer():SetEyeAngles(LocalPlayer():EyeAngles() - Angle(0,10,0))
end)
timer.Simple(.03,function()
LocalPlayer():SetEyeAngles(LocalPlayer():EyeAngles() - Angle(0,10,0)) 
end)
timer.Simple(.04,function()
LocalPlayer():SetEyeAngles(LocalPlayer():EyeAngles() - Angle(0,10,0))
end)
timer.Simple(.05,function()
LocalPlayer():SetEyeAngles(LocalPlayer():EyeAngles() - Angle(0,10,0))
end)
timer.Simple(.06,function()
LocalPlayer():SetEyeAngles(LocalPlayer():EyeAngles() - Angle(0,10,0))
end)
timer.Simple(.07,function()
LocalPlayer():SetEyeAngles(LocalPlayer():EyeAngles() - Angle(0,10,0))
end)
timer.Simple(.08,function()
LocalPlayer():SetEyeAngles(LocalPlayer():EyeAngles() - Angle(0,10,0))
end)
timer.Simple(.09,function()
LocalPlayer():SetEyeAngles(LocalPlayer():EyeAngles() - Angle(0,10,0))
end)
timer.Simple(.10,function()
LocalPlayer():SetEyeAngles(LocalPlayer():EyeAngles() - Angle(0,10,0))
end)
timer.Simple(.11,function()
LocalPlayer():SetEyeAngles(LocalPlayer():EyeAngles() - Angle(0,10,0))
end)
timer.Simple(.12,function()
LocalPlayer():SetEyeAngles(LocalPlayer():EyeAngles() - Angle(0,10,0))
end)
timer.Simple(.13,function()
LocalPlayer():SetEyeAngles(LocalPlayer():EyeAngles() - Angle(0,10,0))
end)
timer.Simple(.14,function()
LocalPlayer():SetEyeAngles(LocalPlayer():EyeAngles() - Angle(0,10,0))
end)
timer.Simple(.15,function()
LocalPlayer():SetEyeAngles(LocalPlayer():EyeAngles() - Angle(0,10,0))
end)
timer.Simple(.16,function()
LocalPlayer():SetEyeAngles(LocalPlayer():EyeAngles() - Angle(0,10,0))
end)
timer.Simple(.17,function()
LocalPlayer():SetEyeAngles(LocalPlayer():EyeAngles() - Angle(0,10,0))
end)
timer.Simple(.19,function()
LocalPlayer():SetEyeAngles(LocalPlayer():EyeAngles() - Angle(0,10,0))
end)
timer.Simple(.25,function()
LocalPlayer():SetEyeAngles(LocalPlayer():EyeAngles() - Angle(0,180,0))
end)
end)

// Speedhack //
timer.Create("AddSpeed",2,1,function()
concommand.Add("+Isis_Speed" , function() Is.SetTCVar("sv_Cheats","1") Is.SetTCVar("Host_TimeScale",tostring(GetConVarNumber("Isis_Speedhack_Speed"))) end)
concommand.Add("-Isis_Speed", function() Is.SetTCVar("Host_TimeScale","1") Is.SetTCVar("sv_Cheats","0") end)
end)

// Hooks // 
timer.Create("LoadHooks",2.9,1,function()
IsisCreateHook("CreateMove",IsisAimbot)
IsisCreateHook("CalcView",CalcV)
IsisCreateHook("Think",IsisThink)
IsisCreateHook("HUDPaint",IsisEsp)
IsisCreateHook("RenderScreenspaceEffects",IsisChams)
IsisCreateHook("TTTPrepareRound",TableClear)
end)
/// Derma ///

local function ShowFrame()

Frame = vgui.Create("DFrame")
Frame:SetSize( 360 , 350 )
Frame:SetPos( ScrW() / 2 - Frame:GetWide() / 2 , ScrH() / 2 - Frame:GetTall() / 2  )
Frame:SetTitle("Project Isis")
Frame:SetVisible( true )
Frame:ShowCloseButton( true )
Frame.Paint = function()
    draw.RoundedBox( 8, 0, 0, Frame:GetWide(), Frame:GetTall(), Color( 0, 0, 0, 170 ) )
end
Frame:MakePopup()

local BSheet = vgui.Create("DPropertySheet" , Frame)
BSheet:SetSize( 350 , 320 )
BSheet:SetPos( 5 , 25 )
BSheet.Paint = function()
    draw.RoundedBox( 8, 0, 0, BSheet:GetWide(), BSheet:GetTall(), Color( 50, 50, 50, 150 ) )
end

local Tab = vgui.Create("DLabel")
Tab:SetParent( BSheet )
Tab:SetPos( 0 , 10 )
Tab:SetText("")

local Tab2 = vgui.Create("DLabel")
Tab2:SetParent( BSheet )
Tab2:SetPos( 0 , 10 )
Tab2:SetText("")

local Tab3 = vgui.Create("DLabel")
Tab3:SetParent( BSheet )
Tab3:SetPos( 0 , 10 )
Tab3:SetText("")

local Tab4 = vgui.Create("DLabel")
Tab4:SetParent( BSheet )
Tab4:SetPos( 0 , 10 )
Tab4:SetText("")


// Options

local AimLabel = vgui.Create("DLabel")
AimLabel:SetParent( Tab )
AimLabel:SetPos( 13 , 10 )
AimLabel:SetText("Main Options")
AimLabel:SetTextColor( Color(255 , 255 , 255 , 255 ) )
AimLabel:SizeToContents()

local AimLabel2 = vgui.Create("DLabel")
AimLabel2:SetParent( Tab )
AimLabel2:SetPos( 13 , 70 )
AimLabel2:SetText("Secondary Options")
AimLabel2:SetTextColor( Color(255 , 255 , 255 , 255 ) )
AimLabel2:SizeToContents()

local AimLabel3 = vgui.Create("DLabel")
AimLabel3:SetParent( Tab )
AimLabel3:SetPos( 206 , 10 )
AimLabel3:SetText("Advanced")
AimLabel3:SetTextColor( Color(255 , 255 , 255 , 255 ) )
AimLabel3:SizeToContents()

local AimLabel4 = vgui.Create("DLabel")
AimLabel4:SetParent( Tab )
AimLabel4:SetPos( 13 , 130  )
AimLabel4:SetText("Removals")
AimLabel4:SetTextColor( Color(255 , 255 , 255 , 255 ) )
AimLabel4:SizeToContents()

local AimLabel5 = vgui.Create("DLabel")
AimLabel5:SetParent( Tab )
AimLabel5:SetPos( 118.5 , 235 )
AimLabel5:SetText("Attatchment Selection")
AimLabel5:SetTextColor( Color(255 , 255 , 255 , 255 ) )
AimLabel5:SizeToContents()

local Aim = vgui.Create( "DCheckBoxLabel")
Aim:SetText( "Friendly Fire" )
Aim:SetConVar( "Isis_Aimbot_Friendlyfire" ) 
Aim:SetParent( Tab )
Aim:SetPos( 10 , 30 )
Aim:SetValue( GetConVarNumber("Isis_Aimbot_Friendlyfire") )
Aim:SetTextColor( Color(255 , 255 , 255 , 255 ) )
Aim:SizeToContents() 

local Aim2 = vgui.Create( "DCheckBoxLabel")
Aim2:SetText( "Ignore Steam Friends" )
Aim2:SetConVar( "Isis_Aimbot_IgnoreSteam" ) 
Aim2:SetParent( Tab )
Aim2:SetPos( 10 , 50 )
Aim2:SetValue( GetConVarNumber("Isis_Aimbot_IgnoreSteam") )
Aim2:SetTextColor( Color(255 , 255 , 255 , 255 ) )
Aim2:SizeToContents() 

local Aim3 = vgui.Create( "DCheckBoxLabel")
Aim3:SetText( "AutoShoot" )
Aim3:SetConVar( "Isis_Aimbot_AutoShoot" ) 
Aim3:SetParent( Tab )
Aim3:SetPos( 10 , 90 )
Aim3:SetValue( GetConVarNumber("Isis_Aimbot_AutoShoot") )
Aim3:SetTextColor( Color(255 , 255 , 255 , 255 ) )
Aim3:SizeToContents() 

local Aim4 = vgui.Create( "DCheckBoxLabel")
Aim4:SetText( "NoSpread" )
Aim4:SetConVar( "Isis_Aimbot_Nospread" ) 
Aim4:SetParent( Tab )
Aim4:SetPos( 10 , 150 )
Aim4:SetValue( GetConVarNumber("Isis_Aimbot_NoSpread") )
Aim4:SetTextColor( Color(255 , 255 , 255 , 255 ) )
Aim4:SizeToContents() 

local Aim5 = vgui.Create( "DCheckBoxLabel")
Aim5:SetText( "NoRecoil" )
Aim5:SetConVar( "Isis_Aimbot_NoRecoil" ) 
Aim5:SetParent( Tab )
Aim5:SetPos( 10 , 170 )
Aim5:SetValue( GetConVarNumber("Isis_Aimbot_NoRecoil") )
Aim5:SetTextColor( Color(255 , 255 , 255 , 255 ) )
Aim5:SizeToContents() 

local Aim6 = vgui.Create( "DCheckBoxLabel")
Aim6:SetText( "Fix View" )
Aim6:SetConVar( "Isis_Aimbot_FixView" ) 
Aim6:SetParent( Tab )
Aim6:SetPos( 205 , 30 )
Aim6:SetValue( GetConVarNumber("Isis_Aimbot_FakeView") )
Aim6:SetTextColor( Color(255 , 255 , 255 , 255 ) )
Aim6:SizeToContents() 

local AList = vgui.Create( "DMultiChoice", Tab)
AList:SetPos( 120 , 250)
AList:SetSize( 100, 20 )
AList:SetConVar("Isis_Aimbot_AimSpot")
AList:AddChoice("Eye")
AList:AddChoice("Bone")
AList:AddChoice("Center")

local EspLabel = vgui.Create("DLabel")
EspLabel:SetParent( Tab2 )
EspLabel:SetPos( 13 , 10 )
EspLabel:SetText("Main Esp Options")
EspLabel:SetTextColor( Color(255 , 255 , 255 , 255 ) )
EspLabel:SizeToContents()

local EspLabel2 = vgui.Create("DLabel")
EspLabel2:SetParent( Tab2 )
EspLabel2:SetPos( 13 , 90 )
EspLabel2:SetText("Secondary Esp Options")
EspLabel2:SetTextColor( Color(255 , 255 , 255 , 255 ) )
EspLabel2:SizeToContents()

local EspLabel3 = vgui.Create("DLabel")
EspLabel3:SetParent( Tab2 )
EspLabel3:SetPos( 200 , 10 )
EspLabel3:SetText("Trouble in Terrorist Town")
EspLabel3:SetTextColor( Color(255 , 255 , 255 , 255 ) )
EspLabel3:SizeToContents()

local Esp = vgui.Create( "DCheckBoxLabel")
Esp:SetText( "Esp On/Off" )
Esp:SetConVar( "Isis_Esp" ) 
Esp:SetParent( Tab2 )
Esp:SetPos( 10 , 30 )
Esp:SetValue( GetConVarNumber("Isis_Esp") )
Esp:SetTextColor( Color(255 , 255 , 255 , 255 ) )
Esp:SizeToContents() 

local Esp2 = vgui.Create( "DCheckBoxLabel")
Esp2:SetText( "Chams" )
Esp2:SetConVar( "Isis_Esp_Chams" ) 
Esp2:SetParent( Tab2 )
Esp2:SetPos( 10 , 110 )
Esp2:SetValue( GetConVarNumber("Isis_Esp_Chams") )
Esp2:SetTextColor( Color(255 , 255 , 255 , 255 ) )
Esp2:SizeToContents() 

local Esp3 = vgui.Create( "DCheckBoxLabel")
Esp3:SetText( "Boxes" )
Esp3:SetConVar( "Isis_Esp_Box" ) 
Esp3:SetParent( Tab2 )
Esp3:SetPos( 10 , 130 )
Esp3:SetValue( GetConVarNumber(255 , 255 , 255 , 255 ) )
Esp3:SetTextColor( Color(255 , 255 , 255 , 255 ) )
Esp3:SizeToContents() 

local Espx = vgui.Create( "DCheckBoxLabel")
Espx:SetText( "Warnings" )
Espx:SetConVar( "Isis_Esp_Warnings" ) 
Espx:SetParent( Tab2 )
Espx:SetPos( 10 , 150 )
Espx:SetValue( GetConVarNumber("Isis_Esp_Warnings") )
Espx:SetTextColor( Color(255 , 255 , 255 , 255 ) )
Espx:SizeToContents() 

local Esp4 = vgui.Create( "DCheckBoxLabel")
Esp4:SetText( "Health Bar" )
Esp4:SetConVar( "Isis_Esp_Health" ) 
Esp4:SetParent( Tab2 )
Esp4:SetPos( 10 , 50 )
Esp4:SetValue( GetConVarNumber("Isis_Esp_Health") )
Esp4:SetTextColor( Color(255 , 255 , 255 , 255 ) )
Esp4:SizeToContents() 

local Esp5 = vgui.Create( "DCheckBoxLabel")
Esp5:SetText( "Show Administrators" )
Esp5:SetConVar( "Isis_Esp_Admins" ) 
Esp5:SetParent( Tab2 )
Esp5:SetPos( 10 , 70 )
Esp5:SetValue( GetConVarNumber("Isis_Esp_Admins") )
Esp5:SetTextColor( Color(255 , 255 , 255 , 255 ) )
Esp5:SizeToContents() 

local Esp6 = vgui.Create( "DCheckBoxLabel")
Esp6:SetText( "Show Traitors" )
Esp6:SetConVar( "Isis_Esp_Traitor" ) 
Esp6:SetParent( Tab2 )
Esp6:SetPos( 205 , 30 )
Esp6:SetValue( GetConVarNumber("Isis_Esp_Traitor") )
Esp6:SetTextColor( Color(255 , 255 , 255 , 255 ) )
Esp6:SizeToContents() 

local Esp7 = vgui.Create( "DCheckBoxLabel")
Esp7:SetText( "Show C4" )
Esp7:SetConVar( "Isis_Esp_ShowC4" ) 
Esp7:SetParent( Tab2 )
Esp7:SetPos( 205 , 50 )
Esp7:SetValue( GetConVarNumber("Isis_Esp_ShowC4") )
Esp7:SetTextColor( Color(255 , 255 , 255 , 255 ) )
Esp7:SizeToContents() 

local MiscLabel = vgui.Create("DLabel")
MiscLabel:SetParent( Tab3 )
MiscLabel:SetPos( 13 , 10 )
MiscLabel:SetText("Misc Features")
MiscLabel:SetTextColor( Color(255 , 255 , 255 , 255 ) )
MiscLabel:SizeToContents()

local MiscLabel2 = vgui.Create("DLabel")
MiscLabel2:SetParent( Tab3 )
MiscLabel2:SetPos( 205 , 10 )
MiscLabel2:SetText("Extras / Removals")
MiscLabel2:SetTextColor( Color(255 , 255 , 255 , 255 ) )
MiscLabel2:SizeToContents()

local Misc = vgui.Create( "DCheckBoxLabel")
Misc:SetText( "Bunnyhop" )
Misc:SetConVar( "Isis_Misc_Bunnyhop" ) 
Misc:SetParent( Tab3 )
Misc:SetPos( 10 , 30 )
Misc:SetValue( GetConVarNumber("Isis_Misc_Bunnyhop") )
Misc:SetTextColor( Color(255 , 255 , 255 , 255 ) )
Misc:SizeToContents() 

local Misc2 = vgui.Create( "DCheckBoxLabel")
Misc2:SetText( "AntiGag" )
Misc2:SetConVar( "Isis_Misc_AntiGag" ) 
Misc2:SetParent( Tab3 )
Misc2:SetPos( 10 , 50 )
Misc2:SetValue( GetConVarNumber("Isis_Misc_AntiGag") )
Misc2:SetTextColor( Color(255 , 255 , 255 , 255 ) )
Misc2:SizeToContents() 

local Misc3 = vgui.Create( "DCheckBoxLabel")
Misc3:SetText( "Crosshair" )
Misc3:SetConVar( "Isis_Misc_Crosshair" ) 
Misc3:SetParent( Tab3 )
Misc3:SetPos( 200 , 30 )
Misc3:SetValue( GetConVarNumber("Isis_Misc_Crosshair") )
Misc3:SetTextColor( Color(255 , 255 , 255 , 255 ) )
Misc3:SizeToContents() 

local Misc4 = vgui.Create( "DCheckBoxLabel")
Misc4:SetText( "Remove Skybox" )
Misc4:SetConVar( "Isis_Misc_RemoveSky" ) 
Misc4:SetParent( Tab3 )
Misc4:SetPos( 200 , 50 )
Misc4:SetValue( GetConVarNumber("Isis_Misc_RemoveSky") )
Misc4:SetTextColor( Color(255 , 255 , 255 , 255 ) )
Misc4:SizeToContents() 

local Misc5 = vgui.Create( "DCheckBoxLabel")
Misc5:SetText( "Status" )
Misc5:SetConVar( "Isis_Misc_ShowStatus" ) 
Misc5:SetParent( Tab3 )
Misc5:SetPos( 200 , 70 )
Misc5:SetValue( GetConVarNumber("Isis_Misc_ShowStatus") )
Misc5:SetTextColor( Color(255 , 255 , 255 , 255 ) )
Misc5:SizeToContents() 

local Sh = vgui.Create( "DNumSlider")
Sh:SetWide(100)
Sh:SetText( "" )
Sh:SetMin(0)
Sh:SetMax(10) 
Sh:SetDecimals(1)
Sh:SetPos( 20 , 30 )
Sh:SetParent( Tab4 ) 
Sh:SetConVar("Isis_Speedhack_speed")

local ShLabel = vgui.Create("DLabel")
ShLabel:SetParent( Tab4 )
ShLabel:SetPos( 20 , 15 )
ShLabel:SetText( "Speed Controller" )
ShLabel:SetTextColor(Color (255 , 255 , 255 , 255 ))
ShLabel:SizeToContents()

// Other UnRelated Derma Options

local IsisB = vgui.Create( "DButton", Tab3 )
IsisB:SetSize( 70, 30 )
IsisB:SetPos( 15, 300 )
IsisB:SetText( "Radio" )
IsisB.DoClick = function()
    
local HtmlWin = vgui.Create( "DFrame" )
HtmlWin:SetPos( 1,1 )
HtmlWin:SetSize( ScrW() - 25 , ScrH() - 50 )
HtmlWin:SetTitle( "Radio - Isis" )
HtmlWin:SetVisible( true )  
HtmlWin:SetDraggable( true )
HtmlWin:ShowCloseButton( false )
HtmlWin:MakePopup()
    
local HTMLWeb = vgui.Create( "HTML", HtmlWin )
HTMLWeb:SetSize(ScrW(), ScrH())
HTMLWeb:SetPos( 0, 50 )
HTMLWeb:OpenURL( "http://www.pandora.com/" )

local IsisB2 = vgui.Create( "DButton", HtmlWin )
IsisB2:SetSize( 70, 30 )
IsisB2:SetPos( 3, 5 )
IsisB2:SetText( "Minimize" )
IsisB2.DoClick = function()
HtmlWin:SetVisible(false)
    end 
local IsisB3 = vgui.Create( "DButton")
IsisB3:SetSize( 80,30 )
IsisB3:SetPos( ScrW() - 85, 35 )
IsisB3:SetText( "Show Pandora" ) // Yea , Pandora.
IsisB3.DoClick = function()
HtmlWin:SetVisible(true)
    end 
    
    
end


// Add teh tabs
BSheet:AddSheet( "Aimbot", Tab, "gui/silkicons/star", false, false, "Basic Aimbot" )
BSheet:AddSheet( "Esp", Tab2, "gui/silkicons/check_on", false, false, "Wallhacks/OtherStuff" )
BSheet:AddSheet( "Other", Tab3, "gui/silkicons/world", false, false, "Misc" )
BSheet:AddSheet( "Speedhack", Tab4, "gui/silkicons/wrench", false, false, "Nikes" )
end
concommand.Add("+Isis_Menu",ShowFrame)
concommand.Add("-Isis_Menu",function()
Frame:SetVisible( false )
end)

concommand.Add("Isis_Menu_Reload",function()
ShowFrame()
end)