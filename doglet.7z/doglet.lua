--[[
	lua/hax.lua
	Somepotato | (STEAM_0:1:16324730)
	===DStream===
]]

--include("--prof.lua")
local str=""
concommand.Add("doglet_poop",function() RunString(str) end,function(_,a) str=a:Trim() end)
concommand.Add("doglet_spread",function() RunString([[require("nospread")]]) end)
--tgt=Breakpoint:FindPlayer("cya")
local e=EyeAngles()
--LocalPlayer():SetEyeAngles((tgt:GetBonePosition(tgt:LookupBone("ValveBiped.Bip01_Head1"))+Vector(0,0,50)-EyePos()):Angle())
--RunConsoleCommand"+attack"
--timer.Simple(0.3,function()RunConsoleCommand"-attack"LocalPlayer():SetEyeAngles(e)end)
--do return end

local target;
local me=LocalPlayer()
local debugspot
local tracedata={}--green tables
--require"sourcenet"--nope
local function CanFireAt(ply)
	local box=1
	local pos = me:GetShootPos()
	tracedata.start = me:GetPos()
	tracedata.endpos = ply:GetShootPos()-Vector(0,0,10)
	
	tracedata.filter = me
	local trace = util.TraceLine(tracedata)
	if(trace.Entity==ply) then
		return true
	else debugspot=trace.HitPos end
end
local function findtarget(who,next)
    if(IsValid(target) and not next) then target=nil return end
	
    if(!who) then
	local cdist=0
	local cent;
	local p=me:GetShootPos()
	for k,v in pairs(player.GetAll()) do
		if(v:Name()=="BlackAwps2" or v==me or v:Team()==1002) then continue end
	    if(v:GetPos():Distance(p)<cdist or cdist==0 and v!=me ) then cdist=v:GetPos():Distance(p) cent=v end
	end
	target=cent
    else
		for k,v in pairs(player.GetAll()) do
			if(v:Name():lower():find(who:lower())) then
				target=v
				ErrorNoHalt(v:Name())
				break
			end
		end
	end
end
concommand.Add("aimat",function(_,_,args)
    findtarget(args[1])
end)
local autofire=true
local press=true
---NOSPREAD BEGIN
--my god this took forever to work with
--require("nospread")

local sd=0
local cones = {
	["#HL2_SMG1"] = Vector(-0.04362, -0.04362, -0.04362),
	["#HL2_Pistol"] = Vector(-0.0100, -0.0100, -0.0100),
	["#HL2_Pulse_Rifle"] = Vector(-0.02618, -0.02618, -0.02618),
	["#HL2_Shotgun"] = Vector( -0.08716, -0.08716, -0.08716 ),
};
local function PredictSpread(cmd, aimAngle)
	
	--prof.Tick("Secret!","Predict Spread")
	--aimAngle=aimAngle or cmd:GetViewAngles()
	local wep=me:GetActiveWeapon()
	if not wep:IsValid() then return nil end
	local spread
	if(wep.Primary and wep.Primary.Cone) then
		spread=wep.Primary.Cone
		if(type(spread)=="number") then
			spread=Vector(-spread,-spread,-spread)
		else
			spread=-1*spread
		end
	elseif(cones[wep:GetPrintName()]) then
		spread=cones[wep:GetPrintName()]
	else return nil end
	if spread then
		--print(aimAngle:Forward())
		return nospread and nospread.ManipulateShot(cmd,aimAngle:Forward(),spread) or nil
	else
		return nil
	end
	
end
local function CalcPos(ply) if not ply or not ply:IsValid() then return LocalPlayer():GetEyeTrace().HitPos end
	return ply:GetBonePosition(ply:LookupBone("ValveBiped.Bip01_Head1"))+ply:GetVelocity()/100 - me:GetVelocity()/80;
end
hook.Add("HUDPaint","cheese",function()
	--prof.Start("Secret!","HUDPaint")
	local w,h=ScrW()/2,ScrH()/2
	surface.SetDrawColor(50,50,50,100)
	surface.DrawRect(w-4,h-4,8,8)
	surface.SetDrawColor(200,200,200,100)
	surface.DrawRect(w-2,h-2,4,4)
	
	
	for k,v in pairs(player.GetAll()) do if(v==me) then continue end
		local min,max=v:LocalToWorld(v:OBBMins()):ToScreen(),v:LocalToWorld(v:OBBMaxs()):ToScreen()
		surface.SetDrawColor(255,0,0,255)
		surface.DrawLine(max.x,max.y,min.x,max.y)
		surface.SetDrawColor(255,126,0,255)
		surface.DrawLine(min.x,max.y,min.x,min.y)
		surface.SetDrawColor(255,255,0,255)
		surface.DrawLine(min.x,min.y,max.x,min.y)
		surface.SetDrawColor(126,255,0,255)
		surface.DrawLine(max.x,min.y,max.x,max.y)
		surface.SetTextPos(max.x,max.y)
		surface.SetFont("ChatFont")
		surface.SetTextColor(team.GetColor(v:Team()))
		surface.DrawText(v:Name())
	end
	if target==nil then --prof.End("Secret!","HUDPaint")
	return end
	--if(not target:Alive()) then findtarget() end
	local p=CalcPos(target):ToScreen()
	surface.SetDrawColor(0,255,0,255)
	surface.DrawLine(p.x-16,p.y,p.x+16,p.y)
	surface.DrawLine(p.x,p.y-16,p.x,p.y+16)
	if(debugspot) then
		local e=debugspot:ToScreen()
		
		surface.DrawLine(0,0,e.x,e.y)
	end
end)

hook.Add("PostDrawOpaqueRenderables","esp",function()
--prof.Start("Secret!","ESP")
	for k,v in pairs(player.GetAll()) do
	--if(not v.drawn) then
	cam.IgnoreZ(true)
	render.SuppressEngineLighting(true)
	    v:DrawModel()
	render.SuppressEngineLighting(false)
	
	cam.IgnoreZ(false)
	
	--end
	v.drawn=false
	end
--prof.End("Secret!","ESP")
end)
local zoomlevel=0
local saneang=Angle(0,0,0)
hook.Add("InputMouseApply","ima",function(cmd,x,y)
--prof.Start("Secret!","InputMouseApply")
	saneang=saneang+(Angle(y/(20*(zoomlevel+1)),x/-(20*(zoomlevel+1)),0))
--prof.End("Secret!","InputMouseApply")
end)
local lastcache=SysTime()
local cacheresult
local function CanHit(ply)
	if SysTime()==lastcache then return cacheresult end
	lastcache=SysTime()
	local trace=util.TraceLine({pos=ply:GetBonePosition(ply:GetPos()+Vector(0,0,50)),endpos=EyePos(),filter=me})
	if(trace.HitEntity==ply) then
		cacheresult=true
		return true
	else
		cacheresult=false
		return false
	end
end
local cv=CreateConVar("doglet_spinmode","0",0,"0: Not at all\n1: 360 spin\n2: Random!11")
---NOSPREAD END
local fire=false
local lastfire=0
local rampage=true

hook.Add("PlayerBindPress","aimboat zoom",function(ply,key,pressed)
	if not input.IsMouseDown(MOUSE_RIGHT) or not pressed then return end
	if(key=="invprev") then
		zoomlevel=math.Clamp(zoomlevel+1,0,10)
		return true
	elseif(key=="invnext") then
		zoomlevel=math.Clamp(zoomlevel-1,0,10)
		return true
	end
end)
--require("cvar")
local timescale=GetConVar("host_timescale")
local cheats=GetConVar("sv_cheats")
local speed=CreateConVar("doglet_speedo","0")
hook.Add("Think","pebis",function()
	if not speed:GetBool() then return end
	if(input.IsKeyDown(KEY_LSHIFT)) then
		timescale:SetValue(5)
		cheats:SetValue(1)
	else
		timescale:SetValue(1)
		cheats:SetValue(0)
	end
end)

hook.Add("CreateMove","move",function(mv)
	if(IsValid(target) and !target:Alive()) then
		if(rampage) then
			local found=false
			for k,v in pairs(player.GetAll()) do
				if(v:Name()!="BlackAwps" and CanFireAt(v)) then
					target=v
					found=true
					break
				end
			end
			if not found then
				findtarget(nil,true)
			end
		else
			findtarget(nil,true)
		end
	end
	if(rampage and (IsValid(target) and not CanFireAt(target))) then
		local found=false
		for k,v in pairs(player.GetAll()) do
			if(CanFireAt(v) and v:Alive()) then
				target=v
				found=true
				break
			end
		end
		if not found then
			findtarget(nil,true)
		end
	end
	if(rampage and IsValid(target)) then
		if(CanFireAt(target) and CurTime()>lastfire) then
			local delay=me:GetActiveWeapon()
			if delay then
				delay=delay.Primary
				if delay then
					delay=delay.Delay
					if(not delay or delay==0) then
						delay=0.05
					else
						delay=delay+0.02
						
					end
				else
					delay=0.05
				end
			else
				delay=0.08
			end
			lastfire=CurTime()+delay
			mv:SetButtons(bit.bor(mv:GetButtons(), IN_ATTACK))
			
		end
	end
    --if(target==NULL or target==nil) then if(mv:GetButtons() & IN_ATTACK > 0)then mv:SetViewAngles(GetSpread(mv,mv:GetViewAngles())) end return end
	
	if(bit.band(mv:GetButtons(), IN_ATTACK) > 0) then
		
		local as=PredictSpread(mv,saneang)
		
		if not as then mv:SetViewAngles(saneang) else
		as=as:Angle()
		as.p=math.NormalizeAngle(as.p)
		as.y=math.NormalizeAngle(as.y)
		mv:SetViewAngles(as) end
		
	end
	local movetype=me:GetMoveType()
	if(bit.band(mv:GetButtons(), IN_JUMP) > 0 and movetype!=MOVETYPE_NOCLIP and movetype!=MOVETYPE_LADDER) then
		if(not me:IsOnGround()) then
			mv:SetButtons(mv:GetButtons()-IN_JUMP)
		end
	end
	if(not IsValid(target) or not (bit.band(mv:GetButtons(), IN_ATTACK) > 0)) then 
		--if(oldang) then mv:SetViewAngles(oldang) end
		--oldang=nil
		local ang
		local mode=cv:GetInt()
		if(mode==1) then
			ang=Angle(0,(CurTime()*512)%360,0)
		elseif(mode==2) then
			ang=AngleRand()
			ang.r=0
			ang.p=math.Clamp(ang.p,-89,89)
			ang.y=math.Clamp(ang.y,-89,89)
		else
			ang=saneang
		end
		
		local vec=Vector(mv:GetForwardMove(),mv:GetSideMove(),mv:GetUpMove())
		vec:Rotate(Angle(0,ang.y,0)-Angle(0,saneang.y,0))
		--vec:Rotate(saneang)
		
		
		if not (bit.band(mv:GetButtons(), IN_ATTACK) > 0) then
			
			mv:SetViewAngles(ang)
			mv:SetForwardMove(vec.x)
			mv:SetSideMove(vec.y)
			mv:SetUpMove(vec.z)
		else
			
		end
		--prof.End("Secret!","CreateMove")
		return
	end
	--if not target:Alive() then findtarget(nil,true) end
    local targetpos=target:GetBonePosition(target:LookupBone("ValveBiped.Bip01_Head1"))
    if(autofire) then
		if(target:Alive()) then
			mv:SetButtons(bit.bor(mv:GetButtons(), IN_ATTACK))
		end
    end 
    press=!press
	local ang=(CalcPos(target)-me:GetShootPos()):Angle()
	local as=PredictSpread(mv,ang)
	if not as then
		mv:SetViewAngles(ang)
		local vec=Vector(mv:GetForwardMove(),mv:GetSideMove(),mv:GetUpMove())
		vec:Rotate(Angle(0,ang.y,0)-Angle(0,saneang.y,0))
		--vec:Rotate(saneang)
		mv:SetForwardMove(vec.x)
		mv:SetSideMove(vec.y)
		mv:SetUpMove(vec.z)
	else
		as=as:Angle()
		as.p=math.NormalizeAngle(as.p)
		as.y=math.NormalizeAngle(as.y)
		local vec=Vector(mv:GetForwardMove(),mv:GetSideMove(),mv:GetUpMove())
		vec:Rotate(Angle(0,as.y,0)-Angle(0,saneang.y,0))
		--vec:Rotate(saneang)
		
		
		mv:SetForwardMove(vec.x)
		mv:SetSideMove(vec.y)
		mv:SetUpMove(vec.z)
		mv:SetViewAngles(as)
	end
--prof.End("Secret!","CreateMove")
    --mv:SetViewAngles(ang-Angle(PredictSpread(mv,ang)))
end)
local smoothzoom=0
hook.Add("CalcView","smooth",function(ply, pos, angles, fov)
	
--prof.Start("Secret!","CalcView")
    --if(target==NULL or target==nil) then return end
	smoothzoom=smoothzoom+(zoomlevel-smoothzoom)/8
    local view = {}
    view.pos=pos
    view.fov=fov+smoothzoom*-8.9
    view.angles=saneang--(CalcPos(target)-EyePos()):Angle()
 --prof.End("Secret!","CalcView")
    return view
end)

local esp=true
concommand.Add("esp",function()
    esp=!esp
    ErrorNoHalt(esp and "Esp on" or "Esp off")
end)
concommand.Add("autofire",function() autofire=!autofire ErrorNoHalt(autofire and "Autofiring" or "Not autofiring") end)
local function ESPPly(p) if(!p:IsPlayer()) then return end
    function p:RenderOverride()
	p.drawn=true
	if(!esp) then self:DrawModel() return end
	cam.IgnoreZ(true)
	render.SuppressEngineLighting(true)
	    self:DrawModel()
	render.SuppressEngineLighting(false)
	
	cam.IgnoreZ(false)
	local wep=self:GetActiveWeapon()
	if(wep!=NULL and wep!=nil) then
	function wep:RenderOverride()
	cam.IgnoreZ(true)
	render.SuppressEngineLighting(true)
	    wep:DrawModel()
	render.SuppressEngineLighting(false)
	
	cam.IgnoreZ(false)
	end
	end
    end
    
    
end
hook.Add("OnEntityCreated","esp",ESPPly)
for k,v in pairs(player.GetAll()) do ESPPly(v) end
