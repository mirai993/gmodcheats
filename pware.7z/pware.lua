require("bsendpacket")
require("dickwrap")
//require("mega")

print ("Checking Server Data..")
print ("Success!")
chat.AddText( Color( 0, 255, 255 ), "[PWare] HVH Cheat ", Color( 0, 200, 255), str )
chat.AddText( Color( 0, 255, 255 ), "[PWare] Private Ware ", Color( 0, 200, 255), str )
chat.AddText( Color( 0, 255, 255 ), "[PWare] Made By Noone ", Color( 0, 200, 255), str )
surface.PlaySound("HL1/fvox/bell.wav")

Watermark = vgui.Create( "HTML" )
Watermark:SetPos( -20, -20)
Watermark:SetSize( ScrW(), ScrH())
Watermark:OpenURL( "http://gtalogo.com/img/4858.png" )

local Frame = vgui.Create( "DFrame" )
Frame:Center()
Frame:SetSize( 500, 200 )
Frame:SetTitle( "PWare Menu" )
Frame:SetDraggable( true )
Frame:MakePopup()
Frame.Paint = function()
	draw.RoundedBox( 8, 0, 0, Frame:GetWide(), Frame:GetTall(), Color( 0, 0, 0, 150 ) )
end

local DermaCheckbox = vgui.Create( "DCheckBoxLabel" ) 
DermaCheckbox:SetParent( Frame )
DermaCheckbox:SetPos( 45, 53 )						
DermaCheckbox:SetText( "Anti-Aim" )					
DermaCheckbox:SetConVar( "sbox_godmode" )			
DermaCheckbox:SetValue( 0 )			 
DermaCheckbox:SizeToContents()	

local DComboBox = vgui.Create( "DComboBox", Frame )
DComboBox:SetPos( 40, 70 )
DComboBox:SetSize( 100, 20 )
DComboBox:SetValue( "Emotion" )
DComboBox:AddChoice( "Jitter" )
DComboBox:AddChoice( "Fake-Angle" )
DComboBox:AddChoice( "Down" )
DComboBox:AddChoice( "Up" )
DComboBox.OnSelect = function( panel, index, value )
	print( value .." was selected!" )
end

local DermaNumSlider = vgui.Create( "DNumSlider", Frame )
DermaNumSlider:SetPos( 70, 110 )			
DermaNumSlider:SetSize( 300, 100 )		
DermaNumSlider:SetText( "X" )	
DermaNumSlider:SetMin( 0 )				
DermaNumSlider:SetMax( 256 )				
DermaNumSlider:SetDecimals( 0 )			
DermaNumSlider:SetConVar( "sbox_maxprops" ) 

local DermaNumSlider1 = vgui.Create( "DNumSlider", Frame )
DermaNumSlider1:SetPos( 70, 80 )			
DermaNumSlider1:SetSize( 300, 100 )		
DermaNumSlider1:SetText( "Y" )	
DermaNumSlider1:SetMin( 0 )				
DermaNumSlider1:SetMax( 256 )				
DermaNumSlider1:SetDecimals( 0 )			
DermaNumSlider1:SetConVar( "sbox_maxprops" ) 



local bhop = { };
                    bhop.MetaPlayer = FindMetaTable( "Player") 
                    bhop.oldKeyDown = bhop.MetaPlayer['KeyDown']
                    local bhopOn = true;
                    local bhopSOn = true;
                    local bhopHooks = { hook = { }, name = { } };
                    bhop.left = false
                    bhop.right = false
                    bhop.jump = false
                    bhop.what = true
                    function bhop.AddHook(hookname, name, func)
                            table.insert( bhopHooks.hook, hookname );
                            table.insert( bhopHooks.name, name );
                            hook.Add( hookname, name, func );
                    end
                    bhop.MetaPlayer['KeyDown'] = function( self, key )
                    if self != LocalPlayer() then return end
                        if (key == IN_MOVELEFT) and bhop.left then
                            return true
                        elseif (key == IN_MOVERIGHT) and bhop.right then
                            return true
                        elseif (key == IN_JUMP) and bhop.jump then
                            return true
                        else
                            return bhop.oldKeyDown( self, key )
                        end
                    end

                    function bhop.spamjump()
                            bhop.what = false
                            bhop.jump = true
                            timer.Simple(.05, function() 
                                bhop.jump = false
                                timer.Simple( .25, function()
                                    bhop.what = true
                                end)
                            end)
                    end

     
        local oldEyePos = LocalPlayer():EyeAngles()--This is to see where player is looking
        function bhop.CreateMove( cmd )
                        local JumpReleased = false;
                if (cmd:KeyDown( IN_JUMP )) then

                        if (!JumpReleased) then
                                if (bhopOn && !LocalPlayer():OnGround()) then --Bhop here
                                        cmd:RemoveKey( IN_JUMP );
                                        if bhop.what then
                                            bhop.spamjump()
                                        end
                                end
                        else
                                JumpReleased = false
                        end
                                       
                                if(bhopSOn ) then--auto strafer
                                        local traceRes = LocalPlayer():EyeAngles()
                               
                                        if( traceRes.y > oldEyePos.y ) then --If you move your mouse left, walk left, if you're jumping
                                                oldEyePos = traceRes;
                                                cmd:SetSideMove( -1000000 )
                                                bhop.left = true
                                                timer.Simple(1, function() bhop.left = false end)
                                        end
         
                                        if( oldEyePos.y > traceRes.y )  then --If you move your mouse right, move right,  while jumping
                                                oldEyePos = traceRes;
                                                cmd:SetSideMove( 1000000 )
                                                bhop.right = true
                                                timer.Simple(1, function() bhop.right = false end)
                                        end
                                end
                elseif (!JumpReleased) then
                        JumpReleased = true;
                end
         
        end
           
        bhop.AddHook( "CreateMove", tostring(math.random(0, 133712837)), bhop.CreateMove )--add the hook
            concommand.Add( "bhop", function () --Toggler
                    if bhopOn then
                            print("Bhop off")
                            bhopOn = false;
                    else
                            print("Bhop on")
                            bhopOn = true;
                    end
            end )
            concommand.Add( "bhop_strafe",  function ()
                    if bhopSOn then
                            print("Strafe off")
                            bhopSOn = false;
                    else
                            print("Strafe on")
                            bhopSOn = true;
                    end
            end)
            concommand.Add("bhop_unload", function()
                for i = 1, #bhopHooks.hook do
                hook.Remove( bhopHooks.hook[i], bhopHooks.name[i] );
                print( "Unhooked "..bhopHooks.hook[i].." using name "..bhopHooks.name[i] );
            end
                    concommand.Remove("bhop_strafe")
                    concommand.Remove("bhop")
                    bhopOn = false;
                    bhopSOn = false;
                    print("Bhop unloaded")
                    table.Empty( bhopHooks )
                    concommand.Remove( "bhop_unload" )
            end)
           
		   if CLIENT then
	local thirdperson_enabled = true


	hook.Add("CalcView","Thirdperson",function(ply,pos,ang,fov,nearz,farz)
		if not thirdperson_enabled then return end

		local tr = util.TraceLine( {
			start = pos,
			endpos = pos-(ang:Forward()*100),
			filter = nil
		} )

		local view = {}

		view.origin = tr.HitPos
		view.angles = angles
		view.fov = fov

		return view

	end)
	
	hook.Add("ShouldDrawLocalPlayer","Thirdperson_ShouldDrawPlayer",function(ply)
		return thirdperson_enabled
	end)

	net.Receive("thirdperson_toggle",function(len)
		thirdperson_enabled = not thirdperson_enabled
	end)


else
	
	util.AddNetworkString("thirdperson_toggle")

	concommand.Add("thirdperson_toggle",function(ply,cmd,args)

		net.Start("thirdperson_toggle")
		net.Send(ply)
	end)

	
end

function SchoolShow( ply )
	concommand.Run( ply, "thirdperson_toggle" )
end
hook.Add("ShowSpare2", "School", SchoolShow)

        RunConsoleCommand( "fov_desired", "110" )
		
		
hook.Add( "HUDPaint", "Wallhack", function()
 
	for k,v in pairs ( player.GetAll() ) do
 
		local Position = ( v:GetPos() + Vector( 0,0,80 ) ):ToScreen()
		local Name = ""
 
		if v == LocalPlayer() then Name = "" else Name = v:Name() end
	
		draw.DrawText( Name, "CloseCaption_Bold", Position.x, Position.y, Color( 255, 255, 255, 255 ), 1 )
		CreateClientConVar( "wallhack_enabled", 0, true, false )
 
	end
 
end )

bools = true
	if(bools) then
      if(!bSendPacket) then
             yawangle = yawangle + 2035
      end
      if(bSendPacket) then
        yawangle = 1
      end
      bools = true
      else
      if(!bSendPacket) then
             yawangle = yawangle - 2075
      end
      if(bSendPacket) then
        yawangle = 1
      end
    	bools = true
	end
	
	function aimbot() 
	local ply = LocalPlayer()
	local trace = util.GetPlayerTrace( ply ) 
	local traceRes = util.TraceLine( trace ) 
	if traceRes.HitNonWorld then 
		local target = traceRes.Entity 
		if target:IsPlayer() then
			local targethead = target:LookupBone("ValveBiped.Bip01_Head1") 
			local targetheadpos,targetheadang = target:GetBonePosition(targethead) 
			ply:SetEyeAngles((targetheadpos - ply:GetShootPos()):Angle()) 
		end
	end
end
hook.Add("Think","aimbot",aimbot)

// pCircleStrafe BOI! GET YOU SOME!

local CSBOI = {}
CSBOI.CircleStrafeVal = 0
CSBOI._G = table.Copy(_G)
CSBOI.localply = CSBOI._G.LocalPlayer()
CSBOI.cl_forwardspeed_cvar = CSBOI._G.GetConVar("cl_forwardspeed")
CSBOI.cl_forwardspeed_value = 10000
if (CSBOI.cl_forwardspeed_cvar) then
	CSBOI.cl_forwardspeed_value = CSBOI.cl_forwardspeed_cvar:GetFloat()
end
CSBOI.cl_sidespeed_cvar = CSBOI._G.GetConVar("cl_sidespeed")
CSBOI.cl_sidespeed_value = 10000
if (CSBOI.cl_sidespeed_cvar) then
	CSBOI.cl_sidespeed_value = CSBOI.cl_sidespeed_cvar:GetFloat()
end

function CSBOI.ClampMove(cmd)
	if (cmd:GetForwardMove() > CSBOI.cl_forwardspeed_value) then
		cmd:SetForwardMove(CSBOI.cl_forwardspeed_value)
	end
	if (cmd:GetSideMove() > CSBOI.cl_sidespeed_value) then
		cmd:SetSideMove(CSBOI.cl_sidespeed_value)
	end
end

function CSBOI.FixMove(cmd, rotation)
	local rot_cos = CSBOI._G.math.cos(rotation)
	local rot_sin = CSBOI._G.math.sin(rotation)
	local cur_forwardmove = cmd:GetForwardMove()
	local cur_sidemove = cmd:GetSideMove()
	cmd:SetForwardMove(((rot_cos * cur_forwardmove) - (rot_sin * cur_sidemove)))
	cmd:SetSideMove(((rot_sin * cur_forwardmove) + (rot_cos * cur_sidemove)))
end

CSBOI.CircleStrafeSpeed = 2
function CSBOI.CircleStrafe(cmd)
	if (CSBOI._G.input.IsKeyDown(KEY_E)) then
		CSBOI.CircleStrafeVal = CSBOI.CircleStrafeVal + CSBOI.CircleStrafeSpeed
		if ((CSBOI.CircleStrafeVal > 0) and ((CSBOI.CircleStrafeVal / CSBOI.CircleStrafeSpeed) > 361)) then
			CSBOI.CircleStrafeVal = 0
		end
		CSBOI.FixMove(cmd, CSBOI._G.math.rad((CSBOI.CircleStrafeVal - CSBOI._G.engine.TickInterval())))
		return false
	else
		CSBOI.CircleStrafeVal = 0
	end
	return true
end

function CSBOI.RunIt(cmd)
	if (CSBOI.localply) then
		if (cmd:KeyDown(IN_JUMP)) then
			local local_velocity = CSBOI.localply:GetVelocity()
			if (local_velocity:Length2D() < 50) then
				cmd:SetForwardMove(CSBOI.cl_forwardspeed_value)
			end
			local shouldautostrafe = CSBOI.CircleStrafe(cmd)		
			if (!CSBOI.localply:OnGround()) then
				if (shouldautostrafe) then
					// Do your AutoStrafe Here
				end
				cmd:SetButtons(cmd:GetButtons() - IN_JUMP)
			end
		else
			CSBOI.CircleStrafeVal = 0
		end
	end
	CSBOI.ClampMove(cmd)
end
CSBOI._G.hook.Add("CreateMove", "CSBOI", CSBOI.RunIt)

local storedColors = {};
local storedMaterials = {};
local storedRenderModes = {};

local function setIfNonExistant(ent)
	if(!storedMaterials[ent] and !storedColors[ent]) then
		storedMaterials[ent] = ent:GetMaterial();
		storedColors[ent] = ent:GetColor();
		storedRenderModes[ent] = ent:GetRenderMode();
	end
end

local function XRay()
	for i,v in pairs(ents.GetAll()) do
		if IsValid(v) then
			setIfNonExistant(v);
			if(v:IsPlayer()) then
				if(v:IsAdmin() || v:IsSuperAdmin()) then
					v:SetColor(Color(255, 255, 255, 255));
				elseif(v:GetFriendStatus() == "friend") then
					v:SetColor(Color(255, 155, 50, 255));
				else
					v:SetColor(Color(255, 255, 155, 100));
				end
			elseif(v:IsNPC()) then
				v:SetColor(Color(155, 0, 0, 155));
			elseif(v:IsVehicle()) then
				v:SetColor(Color(0, 155, 0, 155));
			elseif(v:IsWeapon()) then
				v:SetColor(Color(255, 0, 155, 155));
			else
				local class = string.lower(v:GetClass());
				if(string.find(class, "printer")) then
					v:SetColor(Color(255, 0, 155, 155));
				elseif(string.find(class, "func") || string.find(class, "prop_door")) then
					v:SetColor(Color(100, 100, 0, 40));
				elseif(string.find(class, "ghost")) then
					v:SetColor(Color(255, 255, 255, 100));
				else
					v:SetColor(Color(50, 50, 255, 40));
				end
			end
			v:SetMaterial("yay");
			v:SetRenderMode(RENDERMODE_TRANSALPHA);
		end
	end
end

local function TurnOffXRay()
	for i,v in pairs(ents.GetAll()) do
		if(IsValid(v)) then
			if(storedMaterials[v]) then
				v:SetMaterial(storedMaterials[v]);
			end
			if(storedColors[v]) then
				v:SetColor(storedColors[v]);
			end
			if(storedRenderModes[v]) then
				v:SetRenderMode(storedRenderModes[v]);
			end
		end
	end
	storedColors = {};
	storedMaterials = {};
	storedRenderModes = {};
end

local xRayOn = false
concommand.Add("minge_toggle_xray", function(client, command, arguments)
	if(xRayOn) then
		hook.Remove("RenderScene", "XRay");
		TurnOffXRay();
		xRayOn = false;
	else
		hook.Add("RenderScene", "XRay", XRay);
		xRayOn = true;
	end
end)

	RunConsoleCommand( "minge_toggle_xray", "" )
	
    hook.Add( "GetPreferredCarryAngles", "MyPreferredCarryAngles", function( ent )
	return Angle( 0, 0, 0 )
end )


local TriggerBot = CreateClientConVar( "triggerbot_enabled", 1, true, false )
 
hook.Add( "Think", "Triggerbot", function()
 
    local Target = LocalPlayer():GetEyeTrace().Entity
 
    if TriggerBot:GetInt() == 1 and LocalPlayer():Alive() and LocalPlayer():GetActiveWeapon():IsValid() and ( Target:IsPlayer() or Target:IsNPC() ) then
 
        if !Firing then
 
            RunConsoleCommand( "+attack" )
            LocalPlayer():GetActiveWeapon().SetNextPrimaryFire( LocalPlayer():GetActiveWeapon() )
            Firing = true
 
        else
 
            RunConsoleCommand( "-attack" ) 
            Firing = false
 
        end
 
    end
 
end )

local function Aimbot(cmd)
local oView = cmd:GetViewAngles()
if LocalPlayer():GetActiveWeapon() then
local BulletTime = true
if LocalPlayer():GetActiveWeapon():GetNextPrimaryFire() > SysTime() then
BulletTime = false
end
if cmd:GetButtons() and IN_ATTACK and BulletTime then
bSendPacket = false
else
bSendPacket = true
cmd:SetViewAngles(oView)
end
end
end

local Queue = 0

local function FakeLag(cmd)
Queue = Queue + 1

if Queue >= 0 then
if Queue < 5 then
bSendPacket = false
else
bSendPacket = true
end
else
bSendPacket = true
end
	
if Queue >= 5 then
Queue = 0
end
end

hook.Add("CreateMove", "FakeLag", FakeLag)

RunConsoleCommand( "say", "PWARE HVH REKING NOOBS LOADED!" ) 










		 
