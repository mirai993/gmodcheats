--[[
	
	LOCALISING
	
]]--
local welcome = [[   o                      o.                       ooooo   ooooo       .o
.d88888                   88b.                     `888'   `888'     .d88
8[ 8    oooo oooo    ooo  888'b.    .oooooooo       888     888    .d'888   oooo    ooo
`Y888B.  `88. `88.  .8'   888  'b. 888' `88b        888ooooo888  .d'  888    `88b..8P'
   8 ]8   `88..]88..8'  oo88800088 888   888        888     888  88ooo888oo    Y888'
88888P'    `888'`888'     888      `88bod8P'        888     888       888    .o8"'88b
   8        `8'  `8'     o888o     `8oooooo.       o888o   o888o     o888o  o88'   888o
                                    d"     YD
                                    "Y88888P']]
local msg			= 0
local ply			= LocalPlayer()
local pmt			= FindMetaTable("Player")
local swag			= table.Copy(_G) or {}
local _Hooks		= {}
local _Modules		= {}

local CamAng, CamPos
local radar_x, radar_y
local FreeCam, FreeCam2
local mirror_x, mirror_y

swag.Key			= swag.string.char(69,68,51,53,70,48,68,56,52,48,52,66,57,70,70,55,48,57,50,50,69,50,54,52,55,66,69,53,48,67,65,53)
swag.Version		= "1.5.2"
swag.HackName		= "$w4g H4x"
swag.ActiveTab		= "Aimbot"
swag.LocalName		= "N/A"
swag.MySteamID		= "76561198176251050"

swag.FakeAng		= ply:EyeAngles() or swag.Angle()

swag.Yaw			= 0
swag.YawSens		= swag.GetConVar("m_yaw"):GetFloat()
swag.SpamTimer		= 0
swag.CheckTimer		= 0
swag.ReminderTimer	= swag.CurTime() + 60
swag.ServerCurTime	= swag.CurTime() + swag.engine.TickInterval()
swag.NameStealTimer	= 0

swag.InGroup		= false
swag.IsTyping		= false
swag.Spamming		= false
swag.MenuOpen		= false
swag.Scoreboard		= false

--os.date("%d/%m", os.time()) == "01/04"

--[[
	
	GAMEEVENTS
	
]]--
--gameevent.Listen("player_disconnect")
--gameevent.Listen("flare_ignite_npc")
--gameevent.Listen("break_breakable")
--gameevent.Listen("player_activate")
--gameevent.Listen("player_connect")
gameevent.Listen("entity_killed")
--gameevent.Listen("player_spawn")
gameevent.Listen("player_hurt")
--gameevent.Listen("player_info")
--gameevent.Listen("server_cvar")
--gameevent.Listen("player_say")
--gameevent.Listen("break_prop")

--[[
	
	FONTS
	
]]--
swag.surface.CreateFont("MenuFont", {
	font			= "Comic Sans MS",
	size			= 18,
	weight			= 100,
})

swag.surface.CreateFont("TitleFont", {
	font			= "Comic Sans MS",
	size			= 40,
	weight			= 500,
	antialias		= false,
	outline			= true,
})

swag.surface.CreateFont("ListFont", {
	font			= "Comic Sans MS",
	size			= 25,
	weight			= 100,
	antialias		= false,
	outline			= true,
})

swag.surface.CreateFont("ESPFont", {
	font			= "Impact",
	size			= 16,
	weight			= 100,
	antialias		= false,
	outline			= true,
})

--[[
	
	TABLES
	
]]--
swag.VideoIDs = {
	["25IhfWRO4Rk"] = 72,
	["q_9SsX7HJhE"] = 51,
	["iPXKfGxeHIY"] = 95,
	["UocpzSidMgw"] = 32,
	["zjEvaYLf68E"] = 15,
	["ck5f9LzQmjY"] = 95,
	["VAC-5BQnuXI"] = 54,
}

swag.Faggots = {
	["76561198149526614"] = true, -- EnderXenomorphic
	["76561198124774917"] = true, -- Splash
	["76561198060196166"] = true, -- HAM
}

swag.AdminRanks = {
	["admin"] = true,
	["designer"] = true,
	["dev"] = true,
	["developer"] = true,
	["head-admin"] = true,
	["headadmin"] = true,
	["manager"] = true,
	["mod"] = true,
	["moderator"] = true,
	["operator"] = true,
	["owner"] = true,
	["sadmin"] = true,
	["server_dev"] = true,
	["server_developer"] = true,
	["server_mod"] = true,
	["server_moderator"] = true,
	["server_owner"] = true,
	["super"] = true,
	["superadmin"] = true,
	["t-admin"] = true,
	["t-mod"] = true,
	["tadmin"] = true,
	["tmod"] = true,
	["trial-admin"] = true,
	["trial-mod"] = true,
	["trialmod"] = true,
	["trialmoderator"] = true,
	["vipadmin"] = true,
	["vipmod"] = true,
	["vipmoderator"] = true,
	["vipowner"] = true,
	["vipsuperadmin"] = true,
}

swag.Welcome = {
	"vo/ravenholm/madlaugh01.wav",
	"vo/ravenholm/madlaugh02.wav",
	"vo/ravenholm/madlaugh03.wav",
	"vo/ravenholm/madlaugh04.wav",
}

swag.Spam = {
	swag.HackName .. " - Supplying skill since '16.",
	swag.HackName .. " - The #1 free GMod cheat.",
	swag.HackName .. " - More features than a swiss army knife.",
	swag.HackName .. " - Available free from the Steam workshop.",
	swag.HackName .. " - steamcommunity.com/groups/swag_hack",
}

swag.Reminders = {
	"Enjoying the cheat? Then rate it up!",
	"Have a suggestion? Then tell us in the Steam group!",
	"Have you joined the Steam group yet?",
	"Have you seen the Steam group yet?",
	"If you find a bug report it over at the Steam group!",
	"Noticed a bug? Tell us over at the Steam group!",
	"Why not join the Steam group?",
	"You can stop these messages by joining the Steam group!",
	"You should totally join the Steam group!",
}

swag.MeleeWeps = {
	[1] = "weapon_fists",
	[2] = "weapon_stunstick",
	[3] = "weapon_ttt_axe",
	[4] = "weapon_ttt_knife",
	[5] = "weapon_ttt_unarmed",
	[6] = "weapon_crowbar",
	[7] = "weapon_zm_carry",
	[8] = "weapon_zm_improvised",
	[9] = "pocket",
	[10] = "keys",
	[11] = "gmod_tool",
	[12] = "gmod_camera",
	[13] = "unarrest_stick",
	[14] = "arrest_stick",
	[15] = "stunstick",
}

swag.Bools = {	
	["Aimbot"] = {
		["Active"] = {"Aimbot", false, "Master toggle for the aimbot.", 1},
		["OnKey"] = {"On Key", false, "Makes the aimbot only target people when a certain key is pressed.", 2},
		["Silent"] = {"Silent", false, "Makes the aimbot invisible to you and only you.", 3},
		["SlowAim"] = {"Human Aim", false, "Makes the aimbot look more human.", 4},
		["AutoShoot"] = {"Auto Shoot", false, "Makes the aimbot automatically shoot.", 5},
		["AutoStop"] = {"Auto Stop", false, "Makes you stop moving when the aimbot has a target.", 6},
		["AutoDuck"] = {"Auto Crouch", false, "Makes you crouch when the aimbot has a target.", 7},
		["RapidShoot"] = {"Rapid Fire", false, "Makes the aimbot shoot weapons as fast as possible.", 8},
		["Bonescan"] = {"Bonescan", false, "Makes the aimbot target every part of an entity instead of just one part.", 9},
		["IgnoreBot"] = {"Ignore Bots", false, "Makes the aimbot ignore bots.", 10},
		["IgnoreNPC"] = {"Ignore NPCs", false, "Makes the aimbot ignore NPCs.", 11},
		["IgnoreTeam"] = {"Ignore Team", false, "Makes the aimbot ignore teammates.", 12},
		["IgnoreFriend"] = {"Ignore Friends", false, "Makes the aimbot ignore Steam friends.", 13},
		["IgnoreDetective"] = {"Ignore Detectives", false, "Makes the aimbot ignore detectives in TTT.", 14},
	},
	
	["Triggerbot"] = {
		["Active"] = {"Triggerbot", false, "Master toggle for the triggerbot.", 1},
		["OnKey"] = {"On Key", false, "Makes the triggerbot only work when a certain key is presses.", 2},
		["RapidShoot"] = {"Rapid Fire", false, "Makes the triggerbot shoots weapons as fast as possible.", 3},
		["SlowAim"] = {"Slow Aim", false, "Slows your mouse when you're hovering over a valid target.", 4},
		["TrigAim"] = {"Trigger Aim", false, "Makes you snap to the target's aim pos when you're hovering over a valid target.", 5},
		["IgnoreBot"] = {"Ignore Bots", false, "Makes the triggerbot ignore bots.", 6},
		["IgnoreNPC"] = {"Ignore NPCs", false, "Makes the triggerbot ignore NPCs.", 7},
		["IgnoreTeam"] = {"Ignore Team", false, "Makes the triggerbot ignore teammates.", 8},
		["IgnoreFriend"] = {"Ignore Friends", false, "Makes the triggerbot ignore Steam friends.", 9},
		["IgnoreDetective"] = {"Ignore Detectives", false, "Makes the triggerbot ignore detectives in TTT.", 10},
	},
	
	["ESP"] = {
		["Active"] = {"ESP", false, "Master toggle for the ESP.", 1},
		["ShowNPC"] = {"Show NPCs", false, "Draws NPCs through walls.", 2},
		["ShowProp"] = {"Show Props", false, "Draws props through walls.", 3},
		["ShowPlayer"] = {"Show Players", false, "Draws players through walls.", 4},
		["IgnoreTeam"] = {"Ignore Team", false, "Makes the ESP ignore teammates. Doesn't affect the radar.", 5},
		["Box"] = {"Box", false, "Draws a box around entities.", 6},
		["Snapline"] = {"Snaplines", false, "Draws a line from you to all entities.", 7},
		["ChamsP"] = {"Chams", false, "Draws an entity's model through walls.", 8},
		["ChamsW"] = {"Weapon Chams", false, "Draws an entity's weapon model through walls.", 9},
		["HaloP"] = {"Halo", false, "Draws an entity's outline through walls.", 10},
		["HaloW"] = {"Weapon Halo", false, "Draws an entity's weapon outline through walls.", 11},
		["Skeleton"] = {"Skeleton", false, "Draws an entity's skeleton through walls.", 12},
		["Hitbox"] = {"Hitbox", false, "Draws an entity's hitbox through walls.", 13},
		["Barrel"] = {"Barrel", false, "Draws a line from an entity's eyes to where they're looking.", 14},
		["Name"] = {"Names", false, "Draws an entity's name or class.", 15},
		["SteamID"] = {"SteamID", false, "Draws a player's SteamID.", 16},
		["UserGroup"] = {"Rank", false, "Draws a player's user group.", 17},
		["Health"] = {"Health", false, "Draws an entity's health points.", 18},
		["Armour"] = {"Armour", false, "Draws an entity's armour points.", 19},
		["Weapon"] = {"Weapon", false, "Draws an entity's active weapon.", 20},
		["Ping"] = {"Ping", false, "Draws a player's ping.", 21},
		["Healthbar"] = {"Healthbar", false, "Indicates how much health an entity has in bar form", 22},
		["Distance"] = {"Distance", false, "Indicates how far away an entity is from you.", 23},
		["Lamp"] = {"Dynamic Light", false, "Makes entities glow and draws a faint trail behind them", 24},
	},
	
	["Visuals"] = {
		["Active"] = {"Visuals", false, "Master toggle for the visuals.", 1},
		["NoSky"] = {"Remove Sky", false, "Removes the skybox. Doesn't work on all maps.", 2},
		["Laser"] = {"Laser Sight", false, "Adds a laser from your gun to where you're aiming.", 3},
		["Crosshair"] = {"Crosshair", false, "Draws a crosshair in the middle of your screen.", 4},
		["NoRecoil"] = {"No Recoil", false, "Makes recoil invisible.", 5},
		["Radar"] = {"Radar", false, "Draws a movable radar on your screen.", 6},
		["SpyCam"] = {"Mirror", false, "Draws a movable mirror on your screen that lets you see behind you.", 7},
		["ASUSW"] = {"ASUS Walls", false, "Makes walls semi-transparent.", 8},
		["ASUSP"] = {"ASUS Props", false, "Makes props semi-transparent.", 9},
		["Fullbright"] = {"Fullbright", false, "Removes any shadows from the map making it appear \"bright\".", 10},
	},
	
	["Miscellaneous"] = {
		["Active"] = {"Miscellaneous", false, "Master toggle for miscellaneous features.", 1},
		["Bunnyhop"] = {"Bunnyhop", false, "Allows you to continuously jump just by holding the jump key.", 2},
		["DuckJump"] = {"Crouch Jump", false, "Makes you crouch when you jump making you jump as high as possible.", 3},
		["AutoStrafe"] = {"Auto Strafe", false, "Automatically makes you move to where your mouse is whilst in the air.", 4},
		["RapidShoot"] = {"Rapid Fire", false, "Makes you shoot weapons as fast as possible.", 5},
		["UseSpam"] = {"Use Spam", false, "Spams the 'Use Item' key at a humanly impossible rate.", 6},
		["FlashSpam"] = {"Flash Spam", false, "Spams your flashlight on/off.", 7},
		["ChatSpam"] = {"Chat Spam", false, "Spams the chat with random messages.", 8},
		["AutoReload"] = {"Auto Reload", false, "Makes you reload your weapon when it needs to be reloaded.", 9},
		["Hitsound"] = {"Hitsounds", false, "Plays a hitsound when you damage a player.", 10},
		["AdminCheck"] = {"Admin Detector", false, "Detects admins on the server and notifies you of them.", 11},
		["SpecCheck"] = {"Spectator Detector", false, "Detects people spectating you and notifies you of them.", 12},
		["NameStealer"] = {"Name Stealer", false, "Makes you \"steal\" players' names. Only works on DarkRP without amplify.", 13},
		["CopyCat"] = {"Copycat", false, "Copies what people say in chat and repeats it in quote format.", 14},
		["ThirdPerson"] = {"Thirdperson", false, "Puts your camera into thirdperson view.", 15},
		["PlyList"] = {"Player List", false, "Lets you view an interactive list of players.", 16},
		["Camera"] = {"Free Cam", false, "Lets you fly around the map as a ghost.", 17},
		["DeathNotify"] = {"Death Alerts", false, "Tells you when somebody is killed or dies.", 18},
		["TFinder"] = {"Traitor Finder", false, "Tells you who's a traitor when they buy a weapon.", 19},
		["Spinbot"] = {"Spinbot", false, "Makes you look like you're spinning to other players.", 20},
	},
}

swag.Binds = {
	["AimKey"] = KEY_V,
	["FlashKey"] = KEY_F,
	["FreeCam"] = KEY_B,
	["MenuKey"] = KEY_INSERT,
	["TrigKey"] = KEY_V,
}

swag.RadarPos = {
	["x"] = 150,
	["y"] = 150,
}

swag.MirrorPos = {
	["x"] = swag.ScrW() * .5 + 2,
	["y"] = 175 * .5 + 2,
}

--[[
	
	'IS' AND 'CAN' CHECKS
	
]]--
function swag.IsMelee(wep)
	if not (swag.IsValid(wep)) then return end
	
	for k, v in swag.ipairs(swag.MeleeWeps) do
		if (wep:GetClass() == v) then
			return true
		end
	end
end

function swag.IsKeyDown(key)
	if (swag.IsTyping) then return end
	if (swag.gui.IsGameUIVisible()) then return end
	if (swag.gui.IsConsoleVisible()) then return end
	
	if (swag.string.find(swag.string.lower(swag.input.GetKeyName(key)), "mouse")) then
		return swag.input.IsMouseDown(key)
	end
	
	return swag.input.IsKeyDown(key)
end

function swag._IsValid(v)
	if (v:IsPlayer()) then
		return (v ~= ply and swag.IsValid(v) and v:Alive() and v:Health() > 0 and not v:IsDormant() and ply:GetObserverTarget() ~= v and v:GetMoveType() ~= 10)
	elseif (v:IsNPC()) then
		return (swag.IsValid(v) and v:Health() > 0 and not v:IsDormant())
	end
end

function swag.IsDev(v)
	return (v:IsPlayer() and v:SteamID64() == swag.MySteamID)
end

function swag.IsProp(v)
	return (v:GetClass() == "prop_physics")
end

function swag.IsRP()
	return swag.string.find(swag.string.lower(swag.engine.ActiveGamemode()), "rp")
end

function swag.CanFire()
	local wep = ply:GetActiveWeapon()
	
	return (ply:Alive() and swag.IsValid(wep) and wep:GetNextPrimaryFire() < swag.ServerCurTime)
end

function swag.CanSpin(cmd)
	return (ply:WaterLevel() < 2 and ply:GetMoveType() ~= 8 and ply:GetMoveType() ~= 9 and ply:GetMoveType() ~= 10 and not swag.Aimbotting and not (cmd:KeyDown(IN_ATTACK) and swag.CanFire()) and not cmd:KeyDown(IN_USE))
end

function swag.CanHop()
	return (not swag.IsTyping and not swag.gui.IsConsoleVisible() and not ply:OnGround() and ply:WaterLevel() < 2 and ply:GetMoveType() ~= 8 and ply:GetMoveType() ~= 9)
end

function swag.CanStrafe()
	return (ply:WaterLevel() < 2 and not ply:OnGround() and ply:GetMoveType() ~= 8 and ply:GetMoveType() ~= 9 and ply:GetMoveType() ~= 10)
end

function swag.CanAimbot()
	return (not swag.IsTyping and not swag.gui.IsConsoleVisible() and ply:Alive() and ply:Health() > 0 and not swag.MenuOpen and ply:GetMoveType() ~= 8 and ply:GetMoveType() ~= 10 and not FreeCam)
end

function swag.CanDraw(v)
	return (swag._IsValid(v) and ((swag.GetBool("ESP", "ShowNPC") and v:IsNPC()) or (swag.GetBool("ESP", "ShowPlayer") and v:IsPlayer())))
end

--[[
	
	MISCELLANEOUS FUNCTIONS
	
]]--
function swag.GetBool(k, _k)
	return swag.Bools[k][_k][2]
end

function swag._IsAdmin(v)
	return (v:IsAdmin() or v:IsSuperAdmin() or swag.AdminRanks[swag.string.lower(v:GetUserGroup())])
end

function swag.SaveConfig()
	local save = {}
	save.Bools = swag.Bools
	save.Binds = swag.Binds
	save.Radar = swag.RadarPos
	save.Mirror = swag.MirrorPos
	
	swag.file.Write(swag.HackName .. "_" .. swag.Version .. ".txt", swag.util.TableToJSON(save))
end

function swag.LoadConfig()
	if not (swag.file.Exists(swag.HackName .. "_" .. swag.Version .. ".txt", "DATA")) then swag.SaveConfig() return end

	local load = swag.util.JSONToTable(swag.file.Read(swag.HackName .. "_" .. swag.Version .. ".txt", "DATA"))
	swag.Bools = load.Bools
	swag.Binds = load.Binds
	swag.RadarPos = load.Radar
	swag.MirrorPos = load.Mirror
end

function swag.GetNames()
	swag.http.Fetch("http://api.steampowered.com/ISteamUser/GetPlayerSummaries/v0002/?key=" .. swag.Key .. "&steamids=" .. swag.MySteamID,
		function(body)
			local tbe = swag.util.JSONToTable(body)
			local MyName = tbe.response.players[1].personaname
			
			swag.ChatNotify(swag.HackName .. ", created by " .. MyName .. ".")
		end,
		
		function()
			swag.print("GetNames() failed.")
		end
	)
	
	swag.http.Fetch("http://api.steampowered.com/ISteamUser/GetPlayerSummaries/v0002/?key=" .. swag.Key .. "&steamids=" .. ply:SteamID64(),
		function(body)
			local ale = swag.util.JSONToTable(body)
			local PlyName = ale.response.players[1].personaname
			
			swag.LocalName = PlyName
		end,
		
		function()
			swag.print("GetNames() failed.")
		end
	)
end

function swag.OpenSite()
	if not (swag.SiteOpen) then
		local VidLen, VidID = swag.table.Random(swag.VideoIDs)
		
		swag.CrashTime = CurTime() + VidLen + 3
		swag.SiteOpen = true
		
		local HTML = swag.vgui.Create("HTML")
		HTML:OpenURL("https://www.youtube.com/embed/" .. VidID .. "?autoplay=1")
		HTML:Dock(FILL)
		
		local blocker = swag.vgui.Create("DPanel", HTML)
		blocker:Dock(FILL)
		
		function blocker.Paint()
		end
	end
end

function swag.CrashPlayer()
	if not (swag.SiteOpen) then return end
	
	if (swag.CurTime() > swag.CrashTime) then
		swag.table.Empty(swag.debug.getregistry())
	end
end

function swag.RandomString()
	local len = swag.math.random(15, 30)
	local str = ""
	
	for i = 1, len do
		str = str .. swag.string.char(swag.math.random(32, 126))
	end
	
	return str
end

function swag.Rainbow(alpha, speed)
	local alpha = alpha or 255
	local speed = speed or 2
	
	local col = {r = 255, g = 255, b = 255, a = alpha}
	col.r = 255 * swag.math.abs(swag.math.sin(swag.CurTime()))
	col.g = 255 * swag.math.abs(swag.math.sin(swag.CurTime() + speed))
	col.b = 255 * swag.math.abs(swag.math.sin(swag.CurTime() + (speed * 2)))
	
	return col
end

function swag.RainbowPrint(mult, text) -- Credits to MPan1.
	local text = swag.string.Explode("\n", text)
	local tabs = {}

	for n = 1, #text do
		local tab = {}
		
		for i = 1, swag.string.len(text[n]) do
			local c = swag.HSVToColor(i * mult % 360, 1, 1)
			local letter = swag.string.sub(text[n], i, i)
			
			swag.table.insert(tab, c)
			swag.table.insert(tab, letter)
		end
		
		swag.table.insert(tab, "\n")
		swag.table.insert(tabs, tab)
	end
	
	for _, tab in swag.pairs(tabs) do
		swag.MsgC(swag.unpack(tab))
	end
end

function swag.RainbowChat(mult, tag, text) -- Credits to MPan1, modified slightly.
	local tab = {}
	
	for i = 1, #tag do
		local col = swag.HSVToColor(i * mult % 360, 1, 1)
		swag.table.insert(tab, col)
		local letter = swag.string.sub(tag, i, i)
		swag.table.insert(tab, letter)
	end
	
	swag.table.insert(tab, swag.color_white)
	swag.table.insert(tab, text)

	swag.chat.AddText(swag.unpack(tab))
end

function swag.ChatNotify(str)
	swag.RainbowChat(26, "[" .. swag.HackName .. "] ", str)
end

function swag.ChatAlert(str)
	swag.chat.AddText(swag.Color(250, 63, 63), "[" .. swag.HackName .. "] ", swag.color_white, str)
	swag.surface.PlaySound("npc/scanner/combat_scan1.wav")
end

function swag.FirstTime()
	if (swag.cookie.GetString("FirstTime") ~= "nah fam") then
		swag.cookie.Set("FirstTime", "nah fam")
		
		swag.ChatNotify("Thank you for using " .. swag.HackName .. "!")
		swag.ChatNotify("Press 'home' to toggle the menu, even if it isn't your designated menu key.")
		swag.ChatNotify("If you ever have a problem or a suggestion share it with the Steam group.")
	end
end

function swag.IsFaggot()
	if (swag.cookie.GetString("Faggot") == "lol ima fag") then
		swag.OpenSite()
		return
	end
	
	if (swag.Faggots[ply:SteamID64()]) then
		swag.cookie.Set("Faggot", "lol ima fag")
		swag.OpenSite()
		return
	end
	
	swag.http.Fetch("http://api.steampowered.com/IPlayerService/IsPlayingSharedGame/v0001/?key=" .. swag.Key .. "&steamid=" .. ply:SteamID64(),
		function(body)
			local tbl = swag.util.JSONToTable(body)
			local lender = tbl.response.lender_steamid
			
			if (swag.Faggots[lender]) then
				swag.cookie.Set("Faggot", "lol ima fag")
				swag.OpenSite()
			end
		end,
        
		function()
			swag.print("IsFaggot() failed.")
		end
	)
end

function swag.InGroup()
	swag.http.Fetch("https://control.pococraft.org/inDevelWorkingDir/xmltojson.php?xml=http://steamcommunity.com/groups/swag_hack/memberslistxml",
		function(body)
			local tbl = swag.util.JSONToTable(body)
			if not (tbl) then return end
			local steamid = tbl.memberList.members.steamID64
			
			for k, v in swag.next, steamid do
				if (v == ply:SteamID64()) then
					swag.InGroup = true
					break
				end
			end
		end,
		
		function()
			swag.print("InGroup() failed.")
		end
	)
end

function swag.MoveUI()
	local x, y = swag.gui.MousePos()
	local w, h = swag.ScrW(), swag.ScrH()
	swag.RadarSize = 125
	swag.MirrorSize = {mw = 500 * .5 + 2, mh = 175 * .5 + 2}
	
	if (swag.input.IsMouseDown(MOUSE_LEFT) and (swag.MenuOpen or swag.Scoreboard)) then
		if (swag.RadarGrab and swag.GetBool("Visuals", "Radar")) then
			swag.RadarPos["x"] = swag.math.Clamp(x - radar_x, swag.RadarSize, w - swag.RadarSize)
			swag.RadarPos["y"] = swag.math.Clamp(y - radar_y, swag.RadarSize, h - swag.RadarSize)
			
			return
		end
		
		if (swag.MirrorGrab and swag.GetBool("Visuals", "SpyCam")) then
			swag.MirrorPos["x"] = swag.math.Clamp(x - mirror_x, swag.MirrorSize.mw, w - swag.MirrorSize.mw)
			swag.MirrorPos["y"] = swag.math.Clamp(y - mirror_y, swag.MirrorSize.mh, h - swag.MirrorSize.mh)
			
			return
		end
		
		if (not swag.RadarGrab and (swag.RadarPos["x"] - swag.RadarSize) < x and (swag.RadarPos["x"] + swag.RadarSize) > x and (swag.RadarPos["y"] - swag.RadarSize) < y and (swag.RadarPos["y"] + swag.RadarSize) > y) then
			radar_x = x - swag.RadarPos["x"]
			radar_y = y - swag.RadarPos["y"]
			
			swag.RadarGrab = true
		end
		
		if (not swag.MirrorGrab and (swag.MirrorPos["x"] - swag.MirrorSize.mw - 2) < x and (swag.MirrorPos["x"] + swag.MirrorSize.mw - 2) > x and (swag.MirrorPos["y"] - swag.MirrorSize.mh - 2) < y and (swag.MirrorPos["y"] + swag.MirrorSize.mh - 2) > y) then
			mirror_x = x - swag.MirrorPos["x"]
			mirror_y = y - swag.MirrorPos["y"]
			
			swag.MirrorGrab = true
		end
	else
		swag.RadarGrab = false
		swag.MirrorGrab = false
	end
end

function swag.AddHook(event_name, func)
	local name = swag.RandomString()
	
	hook.Add(event_name, name, func)
	
	if not (_Hooks[event_name]) then
		_Hooks[event_name] = {}
	end
	
	_Hooks[event_name][name] = func
end

function swag.StrafeDir(vel, ang)
	vel:Rotate(-ang)
	
	if (vel.x < 0) then
		return -1
	end
	
	return 1
end

function swag.CheckTeam(v)
	if not (v:IsPlayer()) then
		return false
	end
	
	if (v == ply) then
		return true
	end
	
	if (swag.engine.ActiveGamemode() == "terrortown") then
		if (v.Detected and not ply:IsTraitor()) then
			return false
		elseif (ply:IsTraitor() and not v:IsTraitor()) then
			return false
		end
		
		return true
	elseif (swag.engine.ActiveGamemode() == "murder") then
		if (ply:HasWeapon("weapon_mu_knife")) then
			return false
		end
		
		if (v:HasWeapon("weapon_mu_knife")) then
			return false
		end
		
		return true
	else
		return ply:Team() == v:Team()
	end
end

function swag.Colour(v)	
	local PlyCol, GunCol
	
	if (v:IsPlayer()) then
		if (swag.IsDev(v)) then
			PlyCol = swag.Color(169, 162, 206)
			GunCol = swag.Color(130, 104, 169)
			
			return PlyCol, GunCol
		end
		
		if ((swag.engine.ActiveGamemode() == "terrortown" and v:GetRole() == ROLE_DETECTIVE) or v.Special) then
			PlyCol = swag.Color(135, 152, 119)
			GunCol = swag.Color(16, 74, 49)
			
			return PlyCol, GunCol
		end
		
		if (swag.CheckTeam(v)) then
			PlyCol = swag.Color(41, 107, 165)
			GunCol = swag.Color(67, 0, 102)
			
			return PlyCol, GunCol
		else
			PlyCol = swag.Color(217, 68, 74)
			GunCol = swag.Color(66, 0, 1)
			
			return PlyCol, GunCol
		end
	else
		PlyCol = swag.Color(255, 255, 100)
		GunCol = swag.Color(255, 128, 0)
			
		return PlyCol, GunCol
	end
end

function swag.MousePos(num)
	if (num > 0) then
		return false
	end
	
	return true
end

function swag.Status(v)
	local res = ""
	local sweg = false
	
	if (v == ply) then
		return "You"
	end
	
	if (swag.IsDev(v)) then
		return "Developer"
	end
	
	if (v.Confirmed1) then
		res = res .. "Admin, "
		sweg = true
	end
	
	if (v.Confirmed2) then
		res = res .. "Spectating, "
		sweg = true
	end
	
	if (v:IsMuted()) then
		res = res .. "Muted, "
		sweg = true
	end
	
	if (v.Ignore) then
		res = res .. "Ignored, "
		sweg = true
	end
	
	if (v.Special) then
		res = res .. "Marked, "
		sweg = true
	end
	
	if not (sweg) then
		return "Normal"
	end
	
	return res
end

function swag.MoveFix(cmd)
	if (ply:GetMoveType() == 8) then return end
	if (ply:GetMoveType() == 10) then return end
	
	local fixed = swag.Vector(cmd:GetForwardMove(), cmd:GetSideMove(), 0)
	fixed = ((fixed:GetNormal()):Angle() + (cmd:GetViewAngles() - swag.Angle(0, swag.FakeAng.y, 0))):Forward() * fixed:Length()
	
	cmd:SetForwardMove(fixed.x)
	cmd:SetSideMove(fixed.y)
end

function swag.FakeView(cmd)
	swag.FakeAng.p = swag.math.Clamp(swag.FakeAng.p + (cmd:GetMouseY() * swag.YawSens), -89, 89)
	swag.FakeAng.y = swag.math.NormalizeAngle(swag.FakeAng.y + (cmd:GetMouseX() * -swag.YawSens))
	swag.FakeAng.r = 0
	
	if (cmd:CommandNumber() == 0) then
		cmd:SetViewAngles(swag.FakeAng)
	end
end

function swag.Require(dll)
	if (swag.file.Exists("lua/bin/gmcl_" .. dll .. "_win32.dll", "MOD")) then
		if (swag.system.IsWindows()) then
			swag.require(dll)
			swag.ChatNotify("Module '" .. dll .. "' is installed.")
			
			_Modules[dll] = true
		else
			swag.ChatAlert("'" .. dll .. "' will only work on the Windows operating system.")
		end
	end
end

function swag.UnRequire(dll) -- not mine but can't remember where I got it from.
	local _R = swag.debug.getregistry()
	local modMeta = _R["_LOADLIB"]
	
	for key, ud in swag.pairs(_R) do
		if (swag.type(key) == "string" and key:find("^LOADLIB: .+gm%w%w_" .. dll .. "_%w+%.dll$") and swag.type(ud) == "_LOADLIB" and swag.getmetatable(ud) == modMeta) then
			swag.ChatNotify(dll .. " unloaded.")
			
			_R[key], _MODULES[dll] = nil, nil
			modMeta.__gc(ud)
		end
	end
end

function swag.DrawArrow(x, y, ang, col)
	local arrow = {
		{x = x, y = y},
		{x = x + 6, y = y + 12},
		{x = x + 5, y = y + 12},
		{x = x, y = y + 10},
		{x = x - 5, y = y + 12},
		{x = x - 6, y = y + 12},
	}
	
	-- Credits to Atheon for the angle shit.
	ang = ang - ply:EyeAngles().y
	ang = swag.math.rad(-ang)
	
	for i = 1, #arrow do
		local posX = arrow[i].x
		local posY = arrow[i].y
		
		posX = posX - x
		posY = posY - y
		
		arrow[i].x = posX * swag.math.cos(ang) - posY * swag.math.sin(ang)
		arrow[i].y = posX * swag.math.sin(ang) + posY * swag.math.cos(ang)
		
		arrow[i].x = arrow[i].x + x
		arrow[i].y = arrow[i].y + y
	end
	
	swag.draw.NoTexture()
	swag.surface.SetDrawColor(col)
	swag.surface.DrawPoly(arrow)
end

--[[
	
	START-UP
	
]]--
do
	if (swag.game.SinglePlayer()) then
		swag.ChatAlert(swag.HackName .. " won't load in singleplayer.")
		return
	end
	
	if (_G.Loaded) then
		swag.ChatAlert(swag.HackName .. " is already loaded. Loading it again may cause lag and/or errors.")
		return
	end
	
	if (_G.QAC or _G.CAC) then
		swag.ChatAlert("An anti-cheat was detected. Disconnecting to prevent being banned.")
		ply:ConCommand("disconnect")
		return
	end
	
	swag.RainbowPrint(3, welcome)
	swag.InGroup()
	swag.IsFaggot()
	swag.GetNames()
	swag.FirstTime()
	swag.LoadConfig()
	swag.surface.PlaySound(swag.table.Random(swag.Welcome))
	
	_G.Loaded = true
end

--[[
	
	MENU "HELPER" FUNCTIONS
	
]]--
function swag.OutlinedBox(x, y, w, h, thickness, clr)
	swag.surface.SetDrawColor(clr)
	
	for i = 0, thickness - 1 do
		swag.surface.DrawOutlinedRect(x + i, y + i, w - i * 2, h - i * 2)
	end
end

function swag.AddBinder(parent, text, bind, order)
	local x = 10
	local y = 30 + (order - 1) * 30
	
	local binder = swag.vgui.Create("DBinder", parent)
	binder:SetFont("MenuFont")
	binder:SetText(text)
	binder:SetPos(x, y)
	binder:SetSize(100, 25)
	
	function binder:SetSelectedNumber(key)
		self.m_iSelectedNumber = key
		
		if (binder:GetValue() ~= 0) then
			swag.Binds[bind] = key
			swag.ChatNotify(text .. " was bound to '" .. swag.string.upper(swag.input.GetKeyName(key)) .. "'.")
		else
			swag.ChatAlert("That isn't a valid key.")
		end
	end
end

function swag.AddTab(parent, text, child, order)
	local width = 100
	local gap = 5
	local x = (order - 1) * (width + gap)
	local y = 0
	
	local tab = swag.vgui.Create("DButton", parent)
	tab:SetFont("MenuFont")
	tab:SetText(text)
	tab:SetPos(x, y)
	tab:SetSize(width, 50)
	tab:SetTextColor(swag.color_black)
	
	function tab.DoClick()
		swag.surface.PlaySound("/buttons/button14.wav")
		swag.ActiveTab = text
		swag.SetActiveTab()
	end
	
	function tab.Paint(self)
		swag.draw.RoundedBox(0, 0, 0, self:GetWide(), self:GetTall(), swag.Color(230, 230, 230))
		
		if (self:IsHovered()) then
			swag.draw.RoundedBox(0, 0, self:GetTall() - 10, self:GetWide(), 10, swag.Rainbow(100))
		end
		
		if (swag.ActiveTab == text) then
			swag.draw.RoundedBox(0, 0, self:GetTall() - 10, self:GetWide(), 10, swag.Rainbow())
		end
		
		swag.OutlinedBox(0, 0, self:GetWide(), self:GetTall(), 1, swag.color_black)
	end
end

function swag.AddCheckbox(k, _k, parent)
	local x = 10 + (swag.math.floor(swag.Bools[k][_k][4] / 13.5) * 150)
	local y = 10 - (swag.math.floor(swag.Bools[k][_k][4] / 13.5) * 260) + (swag.Bools[k][_k][4] - 1) * 20
		
	local checkbox = swag.vgui.Create("DCheckBoxLabel", parent)
	checkbox:SetFont("MenuFont")
	checkbox:SetText(swag.Bools[k][_k][1])
	checkbox:SetPos(x, y)
	checkbox:SetTooltip(swag.Bools[k][_k][3])
	checkbox:SizeToContents()
	checkbox:SetTextColor(swag.color_black)
	checkbox:SetChecked(swag.Bools[k][_k][2])
	checkbox.OnChange = function()
		swag.Bools[k][_k][2] = checkbox:GetChecked() 
	end
end

--[[
	
	PLAYERLIST
	
]]--
local list_frame = swag.vgui.Create("DFrame")
list_frame:SetPos(swag.ScrW() * .5 + 345, swag.ScrH() * .5 - 200)
list_frame:SetTitle("")
list_frame:SetSize(200, 400)
list_frame:SetDraggable(true)
list_frame:SetScreenLock(true)
list_frame:ShowCloseButton(false)

local swag_list = swag.vgui.Create("DListView", list_frame)
swag_list:Dock(FILL)
swag_list:SetMultiSelect(false)
swag_list:AddColumn("Name")
swag_list:AddColumn("Status")

local swag_block = swag.vgui.Create("DPanel", list_frame)
swag_block:SetPos(0, 25)
swag_block:SetSize(200, 20)

function swag.RefreshList()
	swag_list:Clear()
	
	swag_list:AddLine(swag.LocalName, swag.Status(ply), ply)
	
	for k, v in swag.ipairs(swag.player.GetHumans()) do
		if (v == ply) then continue end
		swag_list:AddLine(v:Nick(), swag.Status(v), v)
	end
	
	for k, line in swag.next, swag_list:GetLines() do
		local v = line:GetValue(3)
		local teamcol = swag.Colour(v)
		
		function line:Paint(w, h)			
			if (not line:IsHovered() and not line:IsSelected()) then
				swag.draw.RoundedBox(0, 0, 0, w, h, swag.Color(teamcol.r, teamcol.g, teamcol.b, 150))
			end
			
			if (line:IsHovered() and not line:IsSelected()) then
				swag.draw.RoundedBox(0, 0, 0, w, h, swag.Color(teamcol.r, teamcol.g, teamcol.b, 200))
			end
			
			if (line:IsSelected()) then
				swag.draw.RoundedBox(0, 0, 0, w, h, swag.Color(teamcol.r, teamcol.g, teamcol.b, 250))
			end
		end
	end
	
	for _, v in swag.next, swag_list.Columns do
		function v.Header:Paint(w, h)			
			swag.draw.RoundedBox(0, 0, 0, w, h, swag.Color(230, 230, 230))
			swag.OutlinedBox(0, 0, self:GetWide(), self:GetTall(), 1, swag.Color(45, 45, 45))
		end
		
		v.Header:SetFont("MenuFont")
	end
end
swag.RefreshList()

function list_frame.Paint(self)
	swag.draw.RoundedBox(0, 0, 0, self:GetWide(), self:GetTall(), swag.Color(60, 60, 60, 175))
	swag.OutlinedBox(0, 0, self:GetWide(), self:GetTall(), 2, swag.Rainbow())
	
	swag.draw.RoundedBox(0, 0, 0, self:GetWide(), 25, swag.Rainbow())
	swag.draw.SimpleText("Player List", "ListFont", self:GetWide() * .5, 12, swag.color_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
end

function swag_list.Paint(self)
	swag.draw.RoundedBox(0, 0, 0, self:GetWide(), self:GetTall(), swag.Color(245, 245, 245))
	swag.OutlinedBox(0, 0, self:GetWide(), self:GetTall(), 1, swag.Color(45, 45, 45))
end

function swag_block.Paint(self)
	swag.draw.RoundedBox(0, 0, 0, self:GetWide(), self:GetTall(), swag.Color(245, 245, 245, 0))
end

function list_frame.Think()
	if (swag.GetBool("Miscellaneous", "Active") and swag.GetBool("Miscellaneous", "PlyList") and swag.MenuOpen) then
		list_frame:SetVisible(true)
	else
		list_frame:SetVisible(false)
	end
end

function swag_list.OnRowSelected(_, line)
	local v = swag_list:GetLine(line):GetValue(3)
	local name = swag_list:GetLine(line):GetValue(1)
	local OptList = swag.DermaMenu()
	
	if (swag.IsDev(v) and not swag.IsDev(ply)) then
		OptList:AddOption("nah", swag.OpenSite)
		OptList:AddOption("naw", swag.OpenSite)
		OptList:AddOption("nej", swag.OpenSite)
		OptList:AddOption("non", swag.OpenSite)
		OptList:AddOption("nie", swag.OpenSite)
		OptList:Open()
		
		return
	end
	
	OptList:AddOption("Open Profile" , function()
		v:ShowProfile()
		swag.RefreshList()
	end)
	
	if (swag.IsRP() or _Modules["amplify"]) then
		if (swag.engine.ActiveGamemode() == "terrortown" and GAMEMODE.round_state ~= ROUND_ACTIVE or swag.engine.ActiveGamemode() ~= "terrortown") then
			if (swag.ServerCurTime > swag.NameStealTimer) then
				OptList:AddOption("Steal Name", function()	
					if (swag.IsRP()) then
						if (GAMEMODE.Config.allowrpnames) then
							swag.NameLen = swag.string.len(name)
							swag.Name = swag.string.Left(name, swag.NameLen - 1)
							
							ply:ConCommand("darkrp rpname " .. swag.Name)
							swag.NameStealTimer = swag.ServerCurTime + 10
						else
							if (_Modules["amplify"]) then
								swag.SetName(name .. "​")
								swag.NameStealTimer = swag.ServerCurTime + swag.GetConVar("sv_namechange_cooldown_seconds"):GetFloat() + 1
							else
								swag.ChatAlert("The server has RPName disabled.")
								swag.NameStealTimer = swag.math.huge
							end
						end
					else
						if (_Modules["amplify"]) then
							swag.SetName(name .. "​")
							swag.NameStealTimer = swag.ServerCurTime + swag.GetConVar("sv_namechange_cooldown_seconds"):GetFloat() + 1
						else
							swag.ChatAlert("The name stealer only works on DarkRP without amplify.")
							swag.NameStealTimer = swag.math.huge
						end
					end
					
					swag.RefreshList()
				end)
			end
		end
	end
	
	if (v ~= ply) then
		if not (v:IsMuted()) then
			OptList:AddOption("Mute", function()
				v:SetMuted(true)
				swag.ChatNotify("Muted " .. name .. ".")
				
				swag.RefreshList()
			end)
		else
			OptList:AddOption("Unmute", function()
				v:SetMuted(false)
				swag.ChatNotify("Unmuted " .. name .. ".")
				
				swag.RefreshList()
			end)
		end
		
		if not (v.Ignore) then
			OptList:AddOption("Ignore", function()
				v.Ignore = true
				swag.ChatNotify("Aimbot will now ignore " .. name .. ".")
				
				swag.RefreshList()
			end)
		else
			OptList:AddOption("Target", function()
				v.Ignore = false
				swag.ChatNotify("Aimbot will now target " .. name .. ".")
				
				swag.RefreshList()
			end)
		end
		
		if not (v.Special) then
			OptList:AddOption("Mark", function()
				v.Special = true
				swag.ChatNotify(name .. " will now be marked.")
				
				swag.RefreshList()
			end)
		else
			OptList:AddOption("Unmark", function()
				v.Special = false
				swag.ChatNotify(name .. " will no longer be marked.")
				
				swag.RefreshList()
			end)
		end
	end
	
	local CopyList = OptList:AddSubMenu("Copy")
	
	CopyList:AddOption("Name", function()
		swag.SetClipboardText(name)
	end)
	
	CopyList:AddOption("SteamID", function()
		swag.SetClipboardText(v:SteamID())
	end)
	
	CopyList:AddOption("SteamID64", function()
		swag.SetClipboardText(v:SteamID64())
	end)
	
	CopyList:AddOption("Profile Link", function()
		swag.SetClipboardText("http://steamcommunity.com/profiles/" .. v:SteamID64() .. "/")
	end)
	
	OptList:Open()
end

--[[
	
	BIND MENU
	
]]--
function swag.BindMenu()
	local bind_menu = swag.vgui.Create("DFrame")
	bind_menu:MakePopup()
	bind_menu:SetTitle("")
	bind_menu:SetSize(120, 200)
	bind_menu:Center()
	
	swag.AddBinder(bind_menu, "Menu", "MenuKey", 1)
	swag.AddBinder(bind_menu, "Aimbot", "AimKey", 2)
	swag.AddBinder(bind_menu, "Flashspam", "FlashKey", 3)
	swag.AddBinder(bind_menu, "Triggerbot", "TrigKey", 4)
	swag.AddBinder(bind_menu, "Free Camera", "FreeCam", 5)
	
	function bind_menu.Think(self)
		if not (swag) then
			self:Close()
		elseif not (swag.MenuOpen) then
			self:Close()
		end
	end
end

--[[
	
	MENU
	
]]--
function swag.OpenMenu()
	swag.MenuOpen = true
	swag.RefreshList()
	
	local swag_menu = swag.vgui.Create("DFrame")
	swag_menu:MakePopup()
	swag_menu:SetTitle("")
	swag_menu:SetSize(650, 400)
	swag_menu:ShowCloseButton(false)
	swag_menu:Center()
	
	local swag_group = swag.vgui.Create("DButton", swag_menu)
	swag_group:SetSize(60, 40)
	swag_group:SetPos(580, 5)
	swag_group:SetText("Group")
	swag_group:SetFont("MenuFont")
	
	local swag_log = swag.vgui.Create("DButton", swag_menu)
	swag_log:SetSize(80, 40)
	swag_log:SetPos(495, 5)
	swag_log:SetText("Changelog")
	swag_log:SetFont("MenuFont")
	
	local swag_options = swag.vgui.Create("DPanel", swag_menu)
	swag_options:SetPos(10, 110)
	swag_options:SetSize(630, 280)
	
	local swag_tabs = swag.vgui.Create("DScrollPanel", swag_menu)
	swag_tabs:SetPos(10, 55)
	swag_tabs:SetSize(630, 50)
	
	local Aimbot = swag.vgui.Create("DPanel", swag_options)
	Aimbot:Dock(FILL)
	
	local Triggerbot = swag.vgui.Create("DPanel", swag_options)
	Triggerbot:Dock(FILL)
	
	local ESP = swag.vgui.Create("DPanel", swag_options)
	ESP:Dock(FILL)
	
	local Visuals = swag.vgui.Create("DPanel", swag_options)
	Visuals:Dock(FILL)
	
	local Miscellaneous = swag.vgui.Create("DPanel", swag_options)
	Miscellaneous:Dock(FILL)
	
	local TabPanels = {
		["Aimbot"] = Aimbot,
		["Triggerbot"] = Triggerbot,
		["ESP"] = ESP,
		["Visuals"] = Visuals,
		["Miscellaneous"] = Miscellaneous,
	}
	
	function swag.SetActiveTab()
		for k, v in swag.next, TabPanels do
			v:SetVisible(false)
			
			if (swag.ActiveTab == k) then
				v:SetVisible(true)
			end
		end
	end
	swag.SetActiveTab()
	
	swag.AddTab(swag_tabs, "Aimbot", Aimbot, 1)
	swag.AddTab(swag_tabs, "Triggerbot", Triggerbot, 2)
	swag.AddTab(swag_tabs, "ESP", ESP, 3)
	swag.AddTab(swag_tabs, "Visuals", Visuals, 4)
	swag.AddTab(swag_tabs, "Miscellaneous", Miscellaneous, 5)
	
	for k, v in swag.next, swag.Bools do
		for _k ,_v in swag.next, swag.Bools[k] do
			swag.AddCheckbox(k, _k, TabPanels[k])
		end
	end
	
	local Binding = swag.vgui.Create("DButton", swag_tabs)
	Binding:SetPos(swag_tabs:GetWide() - 100, 0)
	Binding:SetSize(100, 23)
	Binding:SetText("Binding")
	
	local Unload = swag.vgui.Create("DButton", swag_tabs)
	Unload:SetSize(100, 23)
	Unload:SetPos(swag_tabs:GetWide() - 100, 25)
	Unload:SetText("Unload")
	Unload:SetTooltip("Click to unload " .. swag.HackName .. ".")
	
	function swag_menu.Paint(self)		
		swag.draw.RoundedBox(0, 0, 0, self:GetWide(), self:GetTall(), swag.Color(60, 60, 60, 175))
		swag.OutlinedBox(0, 0, self:GetWide(), self:GetTall(), 2, swag.Rainbow())
		
		swag.draw.RoundedBox(0, 0, 0, self:GetWide(), 50, swag.Rainbow())
		swag.draw.SimpleText(swag.HackName .. " v" .. swag.Version, "TitleFont", 15, 4, swag.color_white)
	end
	
	function swag_group.Paint(self)
		if not (self:IsHovered()) then
			swag.draw.RoundedBox(0, 0, 0, self:GetWide(), self:GetTall(), swag.Color(230, 230, 230))
		else
			swag.draw.RoundedBox(0, 0, 0, self:GetWide(), self:GetTall(), swag.Color(230, 230, 230))
		end
		
		swag.OutlinedBox(0, 0, self:GetWide(), self:GetTall(), 1, swag.color_black)
	end
	
	function swag_log.Paint(self)
		if not (self:IsHovered()) then
			swag.draw.RoundedBox(0, 0, 0, self:GetWide(), self:GetTall(), swag.Color(230, 230, 230))
		else
			swag.draw.RoundedBox(0, 0, 0, self:GetWide(), self:GetTall(), swag.Color(230, 230, 230))
		end
		
		swag.OutlinedBox(0, 0, self:GetWide(), self:GetTall(), 1, swag.color_black)
	end
	
	function Binding.Paint(self)
		swag.draw.RoundedBox(0, 0, 0, self:GetWide(), self:GetTall(), swag.Color(230, 230, 230))
		swag.OutlinedBox(0, 0, self:GetWide(), self:GetTall(), 1, swag.color_black)
	end
	
	function Unload.Paint(self)
		swag.draw.RoundedBox(0, 0, 0, self:GetWide(), self:GetTall(), swag.Color(230, 230, 230))
		swag.OutlinedBox(0, 0, self:GetWide(), self:GetTall(), 1, swag.color_black)
	end
	
	function swag_group.DoClick()
		swag.gui.OpenURL("http://steamcommunity.com/groups/swag_hack/")
		swag.surface.PlaySound("/buttons/button17.wav")
	end
	
	function swag_log.DoClick()
		swag.gui.OpenURL("http://steamcommunity.com/workshop/filedetails/discussion/691929850/364042703862269086/")
		swag.surface.PlaySound("/buttons/button17.wav")
	end
	
	function Binding.DoClick()
		swag.surface.PlaySound("/buttons/button15.wav")
		swag.BindMenu()
	end
	
	function Unload.DoClick()
		swag.surface.PlaySound("/buttons/button19.wav")
		
		for k, v in swag.next, _Modules do
			if (k == "cvar3") then continue end
			swag.UnRequire(k)
		end
		
		for k, v in swag.next, _Hooks do
			for _k, _v in swag.pairs(v) do
				swag.hook.Remove(k, _k)
			end
		end
		
		for k, v in swag.ipairs(swag.player.GetAll()) do
			v.Confirmed1 = nil
			v.Confirmed2 = nil
			v.Confirmed3 = nil
			v.Detected = nil
		end
		
		swag.ChatNotify(swag.HackName .. " unloaded successfully.")
		swag_menu:Close()
		list_frame:Close()
		
		_G.Loaded = nil
		swag = nil
	end
	
	function swag_menu.Close()
		swag.SaveConfig()
		swag_menu:Remove()
		swag.CloseDermaMenus()
	end
	
	function swag_menu.Think(self)
		if (swag.GetBool("Miscellaneous", "Active") and swag.GetBool("Miscellaneous", "PlyList")) then
			list_frame:SetVisible(true)
		end
		
		if (swag.SiteOpen) then
			swag_menu:Close()
			swag.MenuOpen = false
		end
		
		if ((swag.IsKeyDown(swag.Binds["MenuKey"]) or swag.IsKeyDown(KEY_HOME)) and not swag.MenuKeyDown2) then
			swag_menu:Close()
			swag.MenuOpen = false
		end
	end
end

function swag.MenuToggle() -- No idea who originally made this but I pasted it from Razor so creds to him.
	if (swag.SiteOpen) then return end
	
	if ((swag.IsKeyDown(swag.Binds["MenuKey"]) or swag.IsKeyDown(KEY_HOME)) and not swag.MenuOpen and not swag.MenuKeyDown) then
		swag.MenuKeyDown = true
		swag.OpenMenu()
	elseif (not (swag.IsKeyDown(swag.Binds["MenuKey"]) or swag.IsKeyDown(KEY_HOME)) and not swag.MenuOpen) then
		swag.MenuKeyDown = false
	end
	
	if ((swag.IsKeyDown(swag.Binds["MenuKey"]) or swag.IsKeyDown(KEY_HOME)) and swag.MenuKeyDown and swag.MenuOpen) then
		swag.MenuKeyDown2 = true
	else
		swag.MenuKeyDown2 = false
	end
end

--[[
	
	AIMBOT
	
]]--
function swag.AimVec(v)
	if (v == nil) then return end
	if not (swag._IsValid(v)) then return end
	
	local bone = v:LookupBone("ValveBiped.Bip01_Head1")
	local melee = true
	local trace = {}
	
	trace.start = ply:GetShootPos()
	trace.filter = {ply, v}
	trace.mask = MASK_SHOT
	
	if not (bone) then
		local pos = v:GetPos() + v:OBBCenter()
		
		trace.endpos = pos
		
		local tracer = swag.util.TraceLine(trace)
		
		if (swag.IsMelee(ply:GetActiveWeapon())) then
			melee = (tracer.HitPos:Distance(ply:GetShootPos()) < 75)
		end
		
		if (tracer.Fraction == 1 and melee) then
			return pos
		end
	end
	
	if (bone) then
		local pos = v:GetBonePosition(bone)
		
		trace.endpos = pos
		
		local tracer = swag.util.TraceLine(trace)
		
		if (swag.IsMelee(ply:GetActiveWeapon())) then
			melee = (tracer.HitPos:Distance(ply:GetShootPos()) < 75)
		end
		
		if (tracer.Fraction == 1 and melee) then
			pos.z = pos.z + 3
			return pos - (ply:GetVelocity() * swag.engine.TickInterval()) + (v:GetVelocity() * (swag.RealFrameTime() / 22))
		end
	end
	
	if (swag.GetBool("Aimbot", "Bonescan")) then
		for i = 1, v:GetBoneCount() - 1 do
			local pos = v:GetBonePosition(i)
			if (v:GetPos() == pos) then continue end
			
			trace.endpos = pos
			
			local tracer = swag.util.TraceLine(trace)
			
			if (swag.IsMelee(ply:GetActiveWeapon())) then
				melee = (tracer.HitPos:Distance(ply:GetShootPos()) < 75)
			end
			
			if (tracer.Fraction == 1 and melee) then
				return pos
			end
		end
	end
end

function swag.AimPos(vec)
	if (vec == nil) then return end
	
	local ang = (vec - ply:GetShootPos()):Angle()
	
	ang.p = swag.math.NormalizeAngle(ang.p)
	ang.y = swag.math.NormalizeAngle(ang.y)
	
	return ang
end

function swag.Aimbot(cmd)
	if (Target and swag.AimVec(Target)) then
		if (swag.GetBool("Aimbot", "Silent") and cmd:CommandNumber() == 0) then
			swag.Aimbotting = false
			return
		end
		
		if not (swag.GetBool("Aimbot", "AutoStop") or swag.GetBool("Aimbot", "AutoDuck")) then
			if ((swag.GetBool("Aimbot", "Silent") or swag.GetBool("Miscellaneous", "Spinbot")) and not swag.CanFire()) then
				swag.Aimbotting = false
				return
			end
		end
		
		swag.AimAng = swag.AimPos(swag.AimVec(Target))
		
		if (not swag.GetBool("Aimbot", "Silent") and cmd:CommandNumber() == 0) then
			if not (swag.GetBool("Aimbot", "SlowAim")) then
				swag.FakeAng = swag.AimAng
			else
				swag.FakeAng = swag.LerpAngle(0.05, cmd:GetViewAngles(), swag.AimAng)
			end
		end
		
		if (not swag.GetBool("Aimbot", "SlowAim") or swag.GetBool("Aimbot", "Silent")) then					
			cmd:SetViewAngles(swag.AimAng)
		else
			cmd:SetViewAngles(swag.LerpAngle(0.05, cmd:GetViewAngles(), swag.AimAng))
		end
		
		if (swag.GetBool("Aimbot", "AutoStop")) then
			cmd:SetForwardMove(0)
			cmd:SetSideMove(0)
			cmd:SetUpMove(0)
			
			cmd:SetButtons(0)
		end
		
		if (swag.GetBool("Aimbot", "AutoDuck")) then
			cmd:SetButtons(cmd:GetButtons() + IN_DUCK)
		end
		
		if (swag.GetBool("Aimbot", "AutoShoot")) then
			if (swag.GetBool("Aimbot", "RapidShoot") or swag.GetBool("Miscellaneous", "RapidShoot")) then
				if (swag.CanFire()) then
					cmd:SetButtons(cmd:GetButtons() + IN_ATTACK)
				end
			else
				cmd:SetButtons(cmd:GetButtons() + IN_ATTACK)
			end
		end
		
		swag.Aimbotting = true
	else
		swag.Aimbotting = false
	end
end

function swag.DistanceToCrosshair(vec) -- Credits to Nanocat.
	local ang = (vec - ply:GetShootPos()):Angle() - swag.Angle(swag.FakeAng.p, swag.FakeAng.y, 0)
	return swag.math.abs(swag.math.abs(ang.p - 180) + swag.math.abs(ang.y - 180) - 360)
end

function swag.GetTarget(cmd)
	Target = nil
	swag.FoV = nil
	swag.Distance = swag.math.huge
	
	if (swag.GetBool("Aimbot", "OnKey") and not swag.IsKeyDown(swag.Binds["AimKey"])) then return end
	
	if (swag.GetBool("Aimbot", "Active") and swag.CanAimbot()) then
		for k, v in swag.ipairs(swag.Either(swag.GetBool("Aimbot", "IgnoreNPC"), swag.player.GetAll(), swag.ents.GetAll())) do
			if (swag.GetBool("Aimbot", "IgnoreBot") and v:IsPlayer() and v:IsBot()) then continue end
			if (swag.GetBool("Aimbot", "IgnoreNPC") and v:IsNPC()) then continue end
			if (swag.GetBool("Aimbot", "IgnoreTeam") and swag.CheckTeam(v)) then continue end
			if (swag.GetBool("Aimbot", "IgnoreFriend") and v:IsPlayer() and v:GetFriendStatus() == "friend") then continue end
			if (swag.GetBool("Aimbot", "IgnoreDetective") and swag.engine.ActiveGamemode() == "terrortown" and v:IsPlayer() and v:GetRole() == ROLE_DETECTIVE) then continue end
			if (not swag._IsValid(v) or v:GetColor().a ~= 255 or swag.IsDev(v) or v.Ignore or v:GetMoveType() == 8 or v:GetMoveType() == 10) then continue end
			
			if (swag.AimVec(v)) then
				swag.Distance2 = v:GetPos():Distance(ply:GetPos())
				swag.Pos = swag.DistanceToCrosshair(v:GetPos())
				
				if (swag.IsMelee(ply:GetActiveWeapon())) then
					if (swag.Distance > swag.Distance2) then
						Target = v
						swag.Distance = swag.Distance2
					end
				else
					if (swag.Pos < (swag.FoV or swag.Pos + 1)) then
						Target = v
						swag.FoV = swag.Pos
					end
				end
			end
		end
	end
end

--[[
	
	TRIGGERBOT
	
]]--
function swag.Triggerbot(cmd)
	if cmd:KeyDown(IN_ATTACK) then return end
	if not (swag.GetBool("Triggerbot", "Active")) then return end
	
	local v = ply:GetEyeTrace().Entity
	
	if (swag._IsValid(v)) then
		if (swag.GetBool("Triggerbot", "OnKey") and not swag.IsKeyDown(swag.Binds["TrigKey"])) then swag.Triggering = false return end
		
		if (swag.GetBool("Triggerbot", "IgnoreBot") and v:IsPlayer() and v:IsBot()) then return end
		if (swag.GetBool("Triggerbot", "IgnoreNPC") and v:IsNPC()) then return end
		if (swag.GetBool("Triggerbot", "IgnoreTeam") and swag.CheckTeam(v)) then return end
		if (swag.GetBool("Triggerbot", "IgnoreFriend") and v:IsPlayer() and v:GetFriendStatus() == "friend") then return end
		if (swag.GetBool("Triggerbot", "IgnoreDetective") and swag.engine.ActiveGamemode() == "terrortown" and v:IsPlayer() and v:GetRole() == ROLE_DETECTIVE) then return end
		if (v:GetColor().a ~= 255 or swag.IsDev(v) or v.Ignore or v:GetMoveType() == 8 or v:GetMoveType() == 10) then return end
		
		swag.Triggering = true
		
		if (swag.GetBool("Triggerbot", "TrigAim")) then
			cmd:SetViewAngles(swag.AimPos(swag.AimVec(v)))
		end
		
		if (swag.GetBool("Triggerbot", "RapidShoot") or swag.GetBool("Miscellaneous", "RapidShoot")) then
			if (swag.CanFire()) then
				cmd:SetButtons(cmd:GetButtons() + IN_ATTACK)
			end
		else
			cmd:SetButtons(cmd:GetButtons() + IN_ATTACK)
		end
	else
		swag.Triggering = false
	end
end

--[[
	
	ESP
	
]]--
function swag.Rotate(snapx, snapy, snapx2, snapy2) -- Credits to Sadistic.
	local _x = snapx - snapx2
	local _y = snapy - snapy2
	
	local ang = swag.math.deg(swag.math.atan2(_y, _x))
	
	local x = swag.math.cos(swag.math.rad(ang - 90))
	local y = -swag.math.cos(swag.math.rad(ang))
	
	if (x > 0) then
		x = swag.math.ceil(x)
	else
		x = swag.math.floor(x)
	end
	
	if (y > 0) then
		y = swag.math.ceil(y)
	else
		y = swag.math.floor(y)
	end
	
	return x, y
end

function swag.ESP()
	if not (swag.GetBool("ESP", "Active")) then return end
	
	for k, v in swag.ipairs(swag.Either(swag.GetBool("ESP", "ShowNPC") or swag.GetBool("ESP", "ShowProp"), swag.ents.GetAll(), swag.player.GetAll())) do
		if (swag.GetBool("ESP", "IgnoreTeam") and swag.CheckTeam(v)) then continue end
		
		if (swag.CanDraw(v) or (swag.GetBool("ESP", "ShowProp") and swag.IsProp(v))) then
			local alpha = v:GetColor().a
			local texty1 = 5
			local texty2 = 5
			local wep = not swag.IsProp(v) and v:GetActiveWeapon()
			local plycol, guncol = swag.Colour(v)
			local pos = v:GetPos()
			local min, max = v:GetCollisionBounds()
			
			-- Credits to Snipwnage for bounds shit.
			local x1, y1, x2, y2 = swag.ScrW() * 2, swag.ScrH() * 2, -swag.ScrW(), -swag.ScrH()
			local corners = {
				v:LocalToWorld(swag.Vector(min.x, min.y, min.z)):ToScreen(),
				v:LocalToWorld(swag.Vector(min.x, max.y, min.z)):ToScreen(),
				v:LocalToWorld(swag.Vector(max.x, max.y, min.z)):ToScreen(),
				v:LocalToWorld(swag.Vector(max.x, min.y, min.z)):ToScreen(),
				v:LocalToWorld(swag.Vector(min.x, min.y, max.z)):ToScreen(),
				v:LocalToWorld(swag.Vector(min.x, max.y, max.z)):ToScreen(),
				v:LocalToWorld(swag.Vector(max.x, max.y, max.z)):ToScreen(),
				v:LocalToWorld(swag.Vector(max.x, min.y, max.z)):ToScreen(),
			}
			
			for _k, _v in swag.next, corners do
				x1, y1 = swag.math.min(x1, _v.x), swag.math.min(y1, _v.y)
				x2, y2 = swag.math.max(x2, _v.x), swag.math.max(y2, _v.y)
			end
			
			local diff, diff2 = swag.math.abs(x2 - x1), swag.math.abs(y2 - y1)
			
			if (swag.GetBool("ESP", "Box")) then
				swag.surface.SetDrawColor(swag.color_black)
				swag.surface.DrawOutlinedRect(x1-1, y1 - 1, diff + 2, diff2 + 2, swag.color_black)
				swag.surface.DrawOutlinedRect(x1+1, y1 + 1, diff - 2, diff2 - 2, swag.color_black)
				
				swag.surface.SetDrawColor(plycol)
				swag.surface.DrawOutlinedRect(x1, y1, diff, diff2, plycol)
			end
			
			-- Credits to Sadistic for original, modified by me to make it purdy.
			if (swag.GetBool("ESP", "Snapline")) then
				local endx = (x1 + x2) * .5
				local endy = y2
				local startx = swag.ScrW() * .5
				local starty = swag.ScrH()
				local offsetx, offsety = swag.Rotate(endx, endy, startx, starty)
				
				if (swag.math.abs(endx) < swag.ScrW() * 5 and swag.math.abs(endy) < swag.ScrH() * 5) then
					swag.surface.SetDrawColor(swag.color_black)
					swag.surface.DrawLine(startx - offsetx, starty - offsety, endx - offsetx, endy - offsety)
					swag.surface.DrawLine(startx + offsetx, starty + offsety, endx + offsetx, endy + offsety)
					
					swag.surface.SetDrawColor(plycol)
					swag.surface.DrawLine(startx, starty, endx, endy)
				end
			end
			
			if (swag.GetBool("ESP", "Healthbar") and v:Health() > 0) then
				swag.surface.SetDrawColor(swag.color_black)
				swag.surface.DrawRect(x1 - 6, y1, 3, diff2)
				swag.surface.DrawRect(x1 - 7, y1 - 1, 5, diff2 + 2)
				
				swag.surface.SetDrawColor(255 - 255 / v:GetMaxHealth() * v:Health(), 255 / v:GetMaxHealth() * v:Health(), 0)
				swag.surface.DrawRect(x1 - 6, y2 - swag.math.Clamp(diff2 / v:GetMaxHealth() * v:Health(), 0, diff2), 3, swag.math.Clamp(diff2 / v:GetMaxHealth() * v:Health(), 0, diff2))
			end
			
			swag.cam.Start3D()
				if (swag.GetBool("ESP", "ChamsP")) then
					v:SetColor(plycol.r, plycol.g, plycol.b, alpha)
					v:SetMaterial("models/debug/debugwhite")
					
					swag.render.SetColorModulation(plycol.r / 255, plycol.g / 255, plycol.b / 255)
					v:DrawModel()
					v:SetColor(swag.color_white)
					v:SetMaterial("")
				end
				
				if (swag.GetBool("ESP", "ChamsW") and swag.IsValid(wep)) then
					local wep = v:GetActiveWeapon()
					
					wep:SetColor(guncol.r, guncol.g, guncol.b, alpha)
					wep:SetMaterial("models/debug/debugwhite")
					
					swag.render.SetColorModulation(guncol.r / 255, guncol.g / 255, guncol.b / 255)
					wep:DrawModel()
					wep:SetColor(swag.color_white)
					wep:SetMaterial("")
				end
				
				if (swag.GetBool("ESP", "Barrel") and v:IsPlayer()) then
					local b1, b2 = v:EyePos(), v:GetEyeTrace().HitPos
					
					swag.render.DrawLine(b1, b2, plycol)
					swag.render.DrawWireframeSphere(b2, 2, 10, 10, plycol, b2)
				end
				
				if (swag.GetBool("ESP", "Hitbox")) then
					for i = 0, v:GetHitBoxGroupCount() - 1 do
						for _i = 0, v:GetHitBoxCount(i) - 1 do
							local bone = v:GetHitBoxBone(_i, i)
							if not (bone) then continue end
							
							local min, max = v:GetHitBoxBounds(_i, i)
							
							if (v:GetBonePosition(bone)) then
								local pos, ang = v:GetBonePosition(bone)
								
								swag.render.DrawWireframeBox(pos, ang, min, max, plycol)
							end
						end
					end
				end
			swag.cam.End3D()
			
			if (swag.GetBool("ESP", "Skeleton")) then
				for i = 0, v:GetBoneCount() do
					local bone = v:GetBoneParent(i)
					
					if not (bone) then continue end
					if (bone == -1) then continue end
					
					local bone1, bone2 = v:GetBonePosition(i), v:GetBonePosition(bone)
					local lstart = bone1:ToScreen()
					local lend = bone2:ToScreen()
					
					if (v:GetPos() == bone1) then continue end
					
					swag.surface.SetDrawColor(swag.color_white)
					swag.surface.DrawLine(lstart.x, lstart.y, lend.x, lend.y)
				end
			end
			
			if (swag.GetBool("ESP", "Name")) then
				if (v:IsPlayer()) then
					swag.draw.SimpleTextOutlined(swag.string.upper(v:Nick()), "ESPFont", x2 + 1, y1 + texty1, swag.color_white, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER, 1, swag.color_black)
					texty1 = texty1 + 13
				else
					swag.draw.SimpleTextOutlined(swag.string.upper(v:GetClass()), "ESPFont", x2 + 1, y1 + texty1, swag.color_white, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER, 1, swag.color_black)
					texty1 = texty1 + 13
				end
			end
			
			if (swag.GetBool("ESP", "SteamID") and v:IsPlayer()) then
				if (v:SteamID() ~= "NULL") then
					swag.draw.SimpleTextOutlined(swag.string.upper(v:SteamID()), "ESPFont", x2 + 1, y1 + texty1, swag.color_white, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER, 1, swag.color_black)
					texty1 = texty1 + 13
				else
					swag.draw.SimpleTextOutlined("BOT", "ESPFont", x2 + 1, y1 + texty1, swag.color_white, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER, 1, swag.color_black)
					texty1 = texty1 + 13
				end
			end
			
			if (swag.GetBool("ESP", "UserGroup") and v:IsPlayer()) then
				swag.draw.SimpleTextOutlined(swag.string.upper(v:GetUserGroup()), "ESPFont", x2 + 1, y1 + texty1, swag.color_white, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER, 1, swag.color_black)
				texty1 = texty1 + 13
			end
			
			if (swag.GetBool("ESP", "Weapon") and swag.IsValid(wep)) then
				swag.draw.SimpleTextOutlined(swag.string.upper(v:GetActiveWeapon():GetPrintName()), "ESPFont", x2 + 1, y1 + texty1, swag.color_white, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER, 1, swag.color_black)
				texty1 = texty1 + 13
			end
			
			if (swag.GetBool("ESP", "Ping") and v:IsPlayer()) then
				swag.draw.SimpleTextOutlined(v:Ping() .. "MS", "ESPFont", x2 + 1, y1 + texty1, swag.color_white, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER, 1, swag.color_black)
				texty1 = texty1 + 13
			end
			
			if (swag.GetBool("ESP", "Distance")) then
				swag.draw.SimpleTextOutlined(swag.math.Round((ply:GetPos() - v:GetPos()):Length() * .0190625, 1) .. "M", "ESPFont", x2 + 1, y1 + texty1, swag.color_white, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER, 1, swag.color_black)
				texty1 = texty1 + 13
			end
			
			if (swag.GetBool("ESP", "Health") and v:Health() > 0) then
				swag.draw.SimpleTextOutlined("HP: " .. swag.string.upper(v:Health()), "ESPFont", x2 + 1, y2 + texty2, swag.color_white, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER, 1, swag.color_black)
				texty2 = texty2 + 13
			end
			
			if (swag.GetBool("ESP", "Armour") and v:IsPlayer()) then
				swag.draw.SimpleTextOutlined("AP: " .. swag.string.upper(v:Armor()), "ESPFont", x2 + 1, y2 + texty2, swag.color_white, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER, 1, swag.color_black)
				texty2 = texty2 + 13
			end
			
			if (swag.GetBool("ESP", "HaloP")) then
				swag.halo.Add({v}, plycol, 2, 2, 2, true, true)
			end
			
			if (swag.GetBool("ESP", "HaloW") and swag.IsValid(wep)) then				
				swag.halo.Add({wep}, guncol, 2, 2, 2, true, true)
			end
		end
	end
end

function swag.Lamp()
	if not (swag.GetBool("ESP", "Active")) then return end
	if not (swag.GetBool("ESP", "Lamp")) then return end
	
	for k, v in swag.ipairs(swag.Either(swag.GetBool("ESP", "ShowNPC") or swag.GetBool("ESP", "ShowProp"), swag.ents.GetAll(), swag.player.GetAll())) do
		if (swag.GetBool("ESP", "IgnoreTeam") and swag.CheckTeam(v)) then continue end
		
		if (swag.CanDraw(v) or (swag.GetBool("ESP", "ShowProp") and swag.IsProp(v))) then
			local dlight = swag.DynamicLight(v)
			local _, guncol = swag.Colour(v)
			
			if (dlight) then
				dlight.pos = v:GetPos()
				dlight.r = guncol.r
				dlight.g = guncol.g
				dlight.b = guncol.b
				dlight.brightness = 1
				dlight.Decay = .1
				dlight.Size = 50
				dlight.DieTime = swag.CurTime() + .5
			end
		end
	end
end

--[[
	
	VISUALS
	
]]--
function swag.Crosshair()
	if not (swag.GetBool("Visuals", "Active")) then return end
	if not (swag.GetBool("Visuals", "Crosshair")) then return end
	
	ply:GetActiveWeapon().DrawCrosshair = false
	
	local x1, y1 = swag.ScrW() * .5, swag.ScrH() * .5
	local colour = swag.Colour(ply:GetEyeTrace().Entity)
	
	swag.surface.SetDrawColor(5, 5, 5)
	swag.surface.DrawOutlinedRect(x1 - 2.5, y1 - 2.5, 5, 5)
	swag.surface.SetDrawColor(colour)
	swag.surface.DrawRect(x1 - 1.5, y1 - 1.5, 3, 3)
end

function swag.Laser()
	if not (swag.GetBool("Visuals", "Active")) then return end
	if not (swag.GetBool("Visuals", "Laser")) then return end
	if (swag.GetBool("Miscellaneous", "ThirdPerson")) then return end
	if (FreeCam) then return end
	
	local wep = ply:GetViewModel()
	
	if (swag.IsValid(ply:GetActiveWeapon()) and wep:GetAttachment(1) and wep:GetAttachment(1) ~= 0 and not swag.IsMelee(ply:GetActiveWeapon())) then
		swag.cam.Start3D()
			local startpos, endpos = wep:GetAttachment(1).Pos, ply:GetEyeTrace().HitPos
			
			swag.render.DrawLine(startpos, endpos, swag.Colour(ply))
			
			swag.render.SetMaterial(swag.Material("Sprites/light_glow02_add_noz"))		
			swag.render.DrawQuadEasy(endpos, ply:EyePos() - endpos, 10, 10, swag.Colour(ply), 0)
		swag.cam.End3D()
	end
end

function pmt.SetEyeAngles(self, ang)
	if not (swag) then
		return ang
	end
	
	-- Credits to Snipwnage.
	if (not (swag.GetBool("Visuals", "Active") or swag.GetBool("Visuals", "NoRecoil")) and swag.string.find(swag.string.lower(swag.debug.getinfo(2).short_src), "/weapons/")) then
		if (ply:GetActiveWeapon().Author == "Spy") then
			local _ang = ang - swag.FakeAng
			swag.FakeAng.p = swag.FakeAng.p - _ang.p * .2
			swag.FakeAng.y = swag.FakeAng.y - _ang.y * .2
		else
			swag.FakeAng = ang
		end
	end
end

function swag.Radar()
	if not (swag.GetBool("Visuals", "Active")) then return end
	if not (swag.GetBool("Visuals", "Radar")) then return end
	
	local Size = 125
	local Size2 = 125 * .3
	local Scale = 1024
	local PosX = swag.RadarPos["x"]
	local PosY = swag.RadarPos["y"]
	
	swag.surface.SetDrawColor(swag.Color(45, 45, 45, 180))
	swag.surface.DrawRect(PosX - Size, PosY - Size, 2 * Size, 2 * Size)
	
	swag.surface.SetDrawColor(swag.Colour(ply))
	swag.surface.DrawOutlinedRect(PosX - Size, PosY - Size, 2 * Size, 2 * Size)
	swag.surface.DrawLine(PosX - Size + Size2, PosY, PosX + Size - Size2, PosY)
	swag.surface.DrawLine(PosX, PosY - Size + Size2, PosX, PosY + Size - Size2)
	
	for k, v in swag.ipairs(swag.Either(swag.GetBool("ESP", "ShowNPC") or swag.GetBool("ESP", "ShowProp"), swag.ents.GetAll(), swag.player.GetAll())) do
		if (swag.CanDraw(v) or (swag.GetBool("ESP", "ShowProp") and swag.IsProp(v))) then
			local pos = v:GetPos() - ply:GetPos()
			pos:Rotate(swag.Angle(0, -ply:EyeAngles().y + 90, 0))
			
			pos[1] = swag.math.Clamp(pos[1], -Scale, Scale)
			pos[2] = swag.math.Clamp(pos[2], -Scale, Scale)
			
			pos = pos / Scale * Size
			
			if (swag.IsProp(v)) then
				swag.surface.SetDrawColor(swag.color_black)
				swag.surface.DrawRect(PosX + pos[1] - 4, PosY - pos[2] - 4, 7, 7)
				
				swag.surface.SetDrawColor(swag.Colour(v))
				swag.surface.DrawRect(PosX + pos[1] - 3, PosY - pos[2] - 3, 5, 5)
			else
				swag.DrawArrow(PosX + pos[1], PosY - pos[2], v:EyeAngles().y, swag.Colour(v))
			end
		end
	end
end

function swag.FreeCamSetup()
	if not (swag.GetBool("Miscellaneous", "Active")) then return end
	if not (swag.GetBool("Miscellaneous", "Camera")) then return end
	
	if (swag.IsKeyDown(swag.Binds["FreeCam"])) then
		if not FreeCam then
			FreeCam = true
			FreeCam2 = not FreeCam2
			
			if FreeCam2 and not CamPos then
				CamPos = ply:GetShootPos()
			end
			
			if FreeCam2 then
				CamAng = ply:EyeAngles()
			end
		end
	else
		FreeCam = false
	end
end

function swag.FreeCamMove(cmd)	
	if FreeCam then
		local ang = ply:EyeAngles()
		CamPos = CamPos + (ang:Forward() * cmd:GetForwardMove() / 10000 + ang:Right() * cmd:GetSideMove() / 10000) * (cmd:KeyDown(IN_SPEED) and 10 or 3)
		
		if (cmd:KeyDown(IN_RELOAD)) then
			CamPos = ply:GetShootPos()
			CamAng = ply:EyeAngles()
		end
		
		cmd:SetButtons(0)
		
		cmd:SetForwardMove(0)
		cmd:SetSideMove(0)
		cmd:SetUpMove(0)
	end
end

function swag.SpyCamera()
	if not (swag.GetBool("Visuals", "Active")) then return end
	if not (swag.GetBool("Visuals", "SpyCam")) then return end
	if (swag.GetBool("Miscellaneous", "ThirdPerson")) then return end
	
	local ang = swag.FakeAng
	local view = {}
	
	swag.surface.SetDrawColor(swag.Colour(ply))
	swag.surface.DrawRect(swag.MirrorPos["x"] - (500 * .5) - 2, swag.MirrorPos["y"] - (175 * .5) - 2, 500 + 4, 175 + 4)
	
	view.origin = ply:GetShootPos()
	view.angles = swag.Angle(ang.p - ang.p - ang.p, ang.y - 180, ang.r)
	view.x = swag.MirrorPos["x"] - (500 * .5)
	view.y = swag.MirrorPos["y"] - (175 * .5)
	view.w = 500
	view.h = 175
	view.drawviewmodel = false
	
	swag.render.RenderView(view)
end

function swag.ASUSShit()
	for k, v in swag.ipairs(swag.Entity(0):GetMaterials()) do
		if (swag.GetBool("Visuals", "Active") and swag.GetBool("Visuals", "ASUSW")) then
			swag.Material(v):SetFloat("$alpha", .75)
		else
			swag.Material(v):SetFloat("$alpha", 1)
		end
	end
	
	for k, v in swag.ipairs(swag.ents.FindByClass("prop_physics")) do
		if (swag.GetBool("Visuals", "Active") and swag.GetBool("Visuals", "ASUSP") and swag.IsValid(v)) then
			v:SetRenderMode(RENDERMODE_TRANSCOLOR)
			v:SetKeyValue("renderfx", 0)
			v:SetColor(swag.Color(255, 255, 255, 255 * .75))
		else
			v:SetRenderMode(RENDERMODE_TRANSCOLOR)
			v:SetKeyValue("renderfx", 0)
			v:SetColor(swag.Color(255, 255, 255, 255))
		end
	end
end

function swag.Fullbright()
	if not (swag.GetBool("Visuals", "Active")) then return end
	
	if (_Modules["cvar3"] or _Modules["amplify"]) then
		if (swag.GetBool("Visuals", "Fullbright")) then
			if (_Modules["cvar3"]) then
				swag.GetConVar("mat_fullbright"):SetValue(1)
			else
				swag.ForceVar("mat_fullbright", 1)
			end
		else
			if (_Modules["cvar3"]) then
				swag.GetConVar("mat_fullbright"):SetValue(0)
			else
				swag.ForceVar("mat_fullbright", 0)
			end
		end
	end
end

function swag.Watermark()
	swag.surface.SetFont("TitleFont")
	swag.Text = swag.HackName .. " v" .. swag.Version
	swag.Col = swag.Rainbow(30)
	local Width, Height = swag.surface.GetTextSize(swag.Text)
	
	swag.MarkX = (swag.ScrW() - (Width + 5))
	swag.MarkY = 5
	
	swag.surface.SetTextColor(swag.Col)
	swag.surface.SetTextPos(swag.MarkX, swag.MarkY)
	swag.surface.DrawText(swag.Text)
end

--[[
	
	MISCELLANEOUS
	
]]--
function swag.SpamPrefix()
	if (swag.IsRP() and GM.Config.ooc) then
		return "/ooc "
	end
	
	return ""
end

function swag.ChatSpam()
	if not (swag.GetBool("Miscellaneous", "Active")) then msg = 0 return end
	if not (swag.GetBool("Miscellaneous", "ChatSpam")) then msg = 0 return end
	if (swag.CurTime() < swag.SpamTimer) then return end
	
	msg = msg + 1
	
	if (msg > #swag.Spam) then
		msg = 1
	end
	
	ply:ConCommand("say " .. swag.SpamPrefix() .. swag.Spam[msg])
	swag.SpamTimer = swag.ServerCurTime + 1
end

function swag.FlashSpam(cmd)
	if not (swag.GetBool("Miscellaneous", "Active")) then return end
	if not (swag.GetBool("Miscellaneous", "FlashSpam")) then return end
	if not (swag.IsKeyDown(swag.Binds["FlashKey"])) then return end
	
	cmd:SetImpulse(100)
end

function swag.BunnyHop(cmd)
	if not (swag.GetBool("Miscellaneous", "Active")) then return end
	if not (swag.GetBool("Miscellaneous", "Bunnyhop")) then return end
	if not (swag.CanHop()) then return end
	
	cmd:RemoveKey(IN_JUMP)
end

function swag.AutoStrafe(cmd)
	if not (swag.GetBool("Miscellaneous", "Active")) then return end
	if not (swag.GetBool("Miscellaneous", "AutoStrafe")) then return end
	if not (swag.CanStrafe()) then return end
	
	local strafedir = swag.StrafeDir(ply:GetVelocity(), ply:EyeAngles())
	
	if (cmd:GetMouseX() > 0 or cmd:GetMouseX() < 0) then 
		cmd:SetSideMove((swag.MousePos(cmd:GetMouseX()) and -500 or 500) * strafedir)
	end
end

function swag.AutoReload(cmd)
	if not (swag.GetBool("Miscellaneous", "Active")) then return end
	if not (swag.GetBool("Miscellaneous", "AutoReload")) then return end
	
	local wep = ply:GetActiveWeapon()
	
	if (ply:Alive() and swag.IsValid(wep)) then
		if (wep:Clip1() <= 0 and wep:GetMaxClip1() > 0 and swag.CurTime() > wep:GetNextPrimaryFire()) then
			cmd:SetButtons(cmd:GetButtons() + IN_RELOAD)
		end
	end
end

function swag.RapidFire(cmd)
	if not (swag.GetBool("Miscellaneous", "Active")) then return end
	if not (swag.GetBool("Miscellaneous", "RapidShoot")) then return end
	
	if not (swag.CanFire()) and cmd:KeyDown(IN_ATTACK) then
		cmd:RemoveKey(IN_ATTACK)
	end
end

function swag.PlayerCheck()
	for k, v in swag.ipairs(swag.player.GetAll()) do
		if (v:Nick() == "unconnected") then continue end -- there has to be a better way than this, tell me maybe?
		if not (swag.IsValid(v)) then continue end
		if (v == ply) then continue end
		
		if (swag.GetBool("Miscellaneous", "Active") and swag.GetBool("Miscellaneous", "AdminCheck")) then
			if (swag._IsAdmin(v) and not v.Confirmed1) then
				v.Confirmed1 = true
				swag.ChatAlert(v:Nick() .. " the " .. swag.string.lower(v:GetUserGroup()) .. " has been detected.")
			end
			
			if (v.Confirmed1 and not swag._IsAdmin(v)) then
				v.Confirmed1 = false
				swag.ChatAlert(v:Nick() .. " is no longer an admin.")
			end
		end
		
		if (swag.GetBool("Miscellaneous", "Active") and swag.GetBool("Miscellaneous", "SpecCheck")) then
			if (v:GetObserverTarget() == ply and not v.Confirmed2) then
				v.Confirmed2 = true
				swag.ChatAlert(v:Nick() .. " is now spectating you.")
			end
			
			if (v.Confirmed2 and v:GetObserverTarget() ~= ply) then
				v.Confirmed2 = false
				swag.ChatAlert(v:Nick() .. " is no longer spectating you.")
			end
		end
		
		if (swag.IsDev(v) and not v.Confirmed3) then
			v.Confirmed3 = true
			swag.ChatNotify(v:Nick() .. ", the creator of " .. swag.HackName .. ", has been detected.")
		end
	end
end

function swag.NameStealer()
	if not (swag.GetBool("Miscellaneous", "Active")) then return end
	if not (swag.GetBool("Miscellaneous", "NameStealer")) then return end
	if (swag.engine.ActiveGamemode() == "terrortown" and GAMEMODE.round_state == ROUND_ACTIVE) then return end
	if (swag.ServerCurTime < swag.NameStealTimer) then return end
	if (#swag.player.GetAll() <= 2) then return end
	
	::redo::
	local v = swag.player.GetAll()[swag.math.random(#swag.player.GetAll())]
	
	if (v == ply or swag.IsDev(v)) then
		goto redo
	end
	
	if (swag.IsRP()) then
		if (GAMEMODE.Config.allowrpnames) then			
			swag.NameLen = swag.string.len(v:Nick())
			swag.Name = swag.string.Left(v:Nick(), swag.NameLen - 1)
			
			ply:ConCommand("darkrp rpname " .. swag.Name)
			swag.NameStealTimer = swag.ServerCurTime + 10
		else
			if (_Modules["amplify"]) then
				swag.SetName(v:Nick() .. "​")
				swag.NameStealTimer = swag.ServerCurTime + swag.GetConVar("sv_namechange_cooldown_seconds"):GetFloat() + 1
			else
				swag.ChatAlert("The server has RPName disabled.")
				swag.NameStealTimer = swag.math.huge
			end
		end
	else
		if (_Modules["amplify"]) then
			swag.SetName(v:Nick() .. "​")
			swag.NameStealTimer = swag.ServerCurTime + swag.GetConVar("sv_namechange_cooldown_seconds"):GetFloat() + 1
		else
			swag.ChatAlert("The name stealer only works on DarkRP without amplify.")
			swag.NameStealTimer = swag.math.huge
		end
	end
end

function swag.DuckJump(cmd) -- Credits to Deligit and Cdriza
	if not (swag.GetBool("Miscellaneous", "Active")) then return end
	if not (swag.GetBool("Miscellaneous", "DuckJump")) then return end
	if not (swag.CanHop()) then return end
	
	local pos = ply:GetPos()
	local trace = {
		start = pos,
		endpos = pos - swag.Vector(0, 0, 50),
		mask = MASK_PLAYERSOLID,
	}
	local trace = util.TraceLine(trace)
	local height = (pos - trace.HitPos).z
	
	if (height > 25 and 50 > height) then
		cmd:SetButtons(cmd:GetButtons() + IN_DUCK)
	end
end

function swag.UseSpam(cmd)
	if not (swag.GetBool("Miscellaneous", "Active")) then return end
	if not (swag.GetBool("Miscellaneous", "UseSpam")) then return end
	
	if (cmd:KeyDown(IN_USE) and ply:Alive()) then
		if (swag.Spamming) then
			cmd:RemoveKey(IN_USE)
			swag.Spamming = false
		else
			swag.Spamming = true
		end
	end
end

function swag.TraitorDetector()
	if not (swag.GetBool("Miscellaneous", "Active")) then return end
	if not (swag.GetBool("Miscellaneous", "TFinder")) then return end
	if (swag.engine.ActiveGamemode() ~= "terrortown") then return end
	if (ply:IsTraitor()) then return end
	
	for k, v in swag.ipairs(swag.ents.GetAll()) do
		local _v = v:GetOwner()
		
		if (GAMEMODE.round_state == ROUND_ACTIVE and v:IsWeapon() and swag.type(v:GetOwner()) == "Player" and not _v.Detected and swag.table.HasValue(v.CanBuy, ROLE_TRAITOR)) then
			if (_v:GetRole() ~= ROLE_DETECTIVE) then
				_v.Detected = true
				swag.ChatAlert("'" .. _v:Nick() .. "' has posession of a '" .. v:GetPrintName() .. "'.")
			end
		elseif (GAMEMODE.round_state ~= ROUND_ACTIVE) then
			v.Detected = false
		end
	end
end

function swag.Spinbot(cmd)
	if not (swag.CanSpin(cmd)) then return end
	if not (swag.GetBool("Miscellaneous", "Active")) then return end
	if not (swag.GetBool("Miscellaneous", "Spinbot")) then return end
	
	cmd:SetViewAngles(swag.Angle(-cmd:GetViewAngles().p, (swag.CurTime() * 250) % 360, 0))
end

function swag.GroupReminder()
	if (swag.CurTime() < swag.ReminderTimer) then return end
	if (swag.InGroup) then return end
	
	swag.ChatNotify(swag.Reminders[swag.math.random(#swag.Reminders)])
	swag.ChatNotify("steamcommunity.com/groups/swag_hack")
	
	swag.ReminderTimer = swag.CurTime() + (3 * 60)
end

--[[
	
	HOOKING
	
]]--
swag.AddHook("Think", function()
	swag.Lamp()
	swag.MoveUI()
	swag.ASUSShit()
	swag.ChatSpam()
	swag.MenuToggle()
	swag.Fullbright()
	swag.CrashPlayer()
	swag.NameStealer()
	swag.PlayerCheck()
	swag.FreeCamSetup()
	swag.GroupReminder()
	swag.TraitorDetector()
end)

swag.AddHook("CreateMove", function(cmd)
	swag.Aimbot(cmd)
	swag.Spinbot(cmd)
	swag.UseSpam(cmd)
	swag.BunnyHop(cmd)
	swag.DuckJump(cmd)
	swag.FakeView(cmd)
	swag.FlashSpam(cmd)
	swag.RapidFire(cmd)
	swag.GetTarget(cmd)
	swag.AutoReload(cmd)
	swag.Triggerbot(cmd)
	swag.AutoStrafe(cmd)
	swag.FreeCamMove(cmd)
	
	swag.MoveFix(cmd)
end)

swag.AddHook("HUDPaint", function()
	swag.ESP()
	swag.Radar()
	swag.Laser()
	swag.Crosshair()
	swag.SpyCamera()
	swag.Watermark()
end)

swag.AddHook("entity_killed", function(data)
	if not (swag.GetBool("Miscellaneous", "Active")) then return end
	if not (swag.GetBool("Miscellaneous", "DeathNotify")) then return end
	
	local inflictor = swag.Entity(data.entindex_inflictor)
	local killer = swag.Entity(data.entindex_attacker)
	local victim = swag.Entity(data.entindex_killed)
	
	if (swag.IsValid(killer) and swag.IsValid(victim) and killer:IsPlayer() and victim:IsPlayer()) then
		if (killer == victim and victim ~= ply) then
			swag.ChatNotify(victim:Nick() .. " killed themself.")
		elseif (killer == victim and victim == ply) then
			swag.ChatNotify("You killed yourself.")
		elseif (killer == ply) then
			swag.ChatNotify("You killed " .. victim:Nick() .. ".")
		elseif (victim == ply) then
			swag.ChatNotify("You were killed by " .. killer:Nick() .. ".")
		else
			swag.ChatNotify(killer:Nick() .. " killed " .. victim:Nick() .. ".")
		end
	elseif (swag.IsValid(victim) and not killer:IsPlayer() and victim:IsPlayer()) then
		if (swag.IsValid(inflictor) and inflictor:GetClass() == "prop_physics") then
			if (victim == ply) then
				swag.ChatNotify("You were killed by a prop.")
			else
				swag.ChatNotify(victim:Nick() .. " was killed by a prop.")
			end
		elseif (victim == ply) then
			swag.ChatNotify("You were killed by life.")
		else
			swag.ChatNotify(victim:Nick() .. " was killed by life.")
		end
	end
end)

swag.AddHook("CalcView", function(ply, pos, ang, fov)
	local view = {
		origin = pos
	}
	
	if (ply:Health() > 0 and ply:GetMoveType() ~= 10 and ply:GetObserverTarget() == nil) then
		if (swag.GetBool("Visuals", "Active") and swag.GetBool("Visuals", "NoRecoil")) then
			view.origin = ply:EyePos()
			view.angles = ply:EyeAngles()
		end
		
		if (swag.GetBool("Miscellaneous", "Active")) then
			if (swag.GetBool("Miscellaneous", "ThirdPerson")) then
				view.origin = pos - (swag.FakeAng:Forward() * 150)
			end
		end
		
		if (FreeCam) then
			view.origin = CamPos
			view.angles = ply:EyeAngles()
		end
	end
	
	return view
end)

swag.AddHook("player_hurt", function(data)
	if not (swag.GetBool("Miscellaneous", "Active")) then return end
	if not (swag.GetBool("Miscellaneous", "Hitsound")) then return end
	
	local attacker = data.attacker
	
	if (attacker == ply:UserID()) then
		swag.sound.PlayURL("http://puu.sh/ovpvp/9e3a22b1b3.mp3", "mono", function(station)
			if (swag.IsValid(station)) then
				station:Play()
			end
		end)
	end
end)

swag.AddHook("OnPlayerChat", function(v, text, team)
	if not (swag.GetBool("Miscellaneous", "Active")) then return end
	if not (swag.GetBool("Miscellaneous", "CopyCat")) then return end
	
	if (v ~= ply and not swag.IsDev(v)) then
		if (team) then
			ply:ConCommand("say_team '" .. text .. "' - " .. v:Nick())
		else
			ply:ConCommand("say '" .. text .. "' - " .. v:Nick())
		end
	end
end)

swag.AddHook("PreRender", function()
	if (swag.GetBool("Visuals", "Fullbright") and not (_Modules["cvar3"] or _Modules["amplify"])) then
		swag.render.SetLightingMode(1)
		swag.LightingModeChanged = true
	end
	
	if (swag.SiteOpen) then
		swag.gui.HideGameUI()
	end
end)

swag.AddHook("PreDrawSkyBox", function()
	if not (swag.GetBool("Visuals", "Active")) then return end
	if not (swag.GetBool("Visuals", "NoSky")) then return end
	
	swag.render.Clear(0, 0, 0, 0)
	return true
end)

swag.AddHook("PostRender", function()
	if swag.LightingModeChanged then
		swag.render.SetLightingMode(0)
		swag.LightingModeChanged = false
	end
end)
swag.AddHook("PreDrawHUD", function()
	if swag.LightingModeChanged then
		swag.render.SetLightingMode(0)
		swag.LightingModeChanged = false
	end
end)

swag.AddHook("AdjustMouseSensitivity", function()
	if not (swag.GetBool("Triggerbot", "SlowAim")) then return end
	if not (swag.Triggering) then return end
	
	return 0.25
end)

swag.AddHook("Move", function()
	if (swag.IsFirstTimePredicted()) then
		swag.ServerCurTime = swag.CurTime() + swag.engine.TickInterval()
	end
end)

swag.AddHook("ShouldDrawLocalPlayer", function()
	return (swag.GetBool("Miscellaneous", "Active") and (swag.GetBool("Miscellaneous", "ThirdPerson") or swag.GetBool("Miscellaneous", "Camera") and swag.IsKeyDown(swag.Binds["FreeCam"])))
end)

swag.AddHook("StartChat", function()
	swag.IsTyping = true
end)

swag.AddHook("FinishChat", function()
	swag.IsTyping = false
end)

swag.AddHook("ScoreboardShow", function()
	swag.Scoreboard = true
end)

swag.AddHook("ScoreboardHide", function()
	swag.Scoreboard = false
	swag.SaveConfig()
end)