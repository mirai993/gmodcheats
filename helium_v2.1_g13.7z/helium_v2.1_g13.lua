--[[
	MOD/lua/Helium.lua
	Nautical | STEAM_0:1:25812285 <74.103.204.228:27005> | [19-10-13 10:45:14PM]
	===BadFile===
]]

//

/* 

	Project Helium
	
	Created to compete with Fisheater in his creation of Krypton
	
	Author: Canadian Phuck
	
*/

local Helium = {

	config					= {
		
		[ "Max Detection Distance" ]		= 3200, // This is not in any category because it affects both the aimbot and esp, but in the menu, it will be under esp for convienience
		
		/* Esp */	
		[ "Player Esp" ]					= true,
		[ "Player Info"	]					= true,
		[ "Player Boxes" ]					= true,
		[ "Player Lines" ]					= true,
		[ "Player FindTraitors" ] 			= true,
	
		[ "Entity Esp" ]					= true,
		
		/* Aimbot */
		[ "Aimbot IgnoreFriends" ]			= true,
		[ "Aimbot IgnoreTeam" ]				= true,
		[ "Aimbot IgnoreAdmins" ]			= true,
		[ "Aimbot TargetPos" ] 				= "Eyes",
		[ "Aimbot Nospread" ] 				= true,
		[ "Aimbot Aim On Secondary Fire" ]  = false,
		
		
		/* Misc */
		[ "Misc Bhop" ]								= true,
		[ "Misc Triggerbot" ]						= true,
		[ "Misc Crosshair" ]						= true,
		[ "Misc Norecoil" ] 						= true,
		[ "Misc Speedfactor" ] 						= .04,

								},
	
	hooks					= {},
	cmds 					= {},
	timers					= {},
	customDrawEnts 			= {},
	aimbotBuddies 			= {},
	detectedTraitors 		= {},
	detectedTraitorWeapons  = {},
	
	espPlayers 				= {},
	espEntities 			= {},
	aimbotPlayers 			= {},
	
	aim 					= false,
	hasFired				= false,
}

/* Anti-Anti Cheat */

local hook 				= table.Copy( hook ) // localize libraries and functions
local table 			= table.Copy( table )
local math 				= table.Copy( math )
local surface 			= table.Copy( surface )
local draw 				= table.Copy( draw )
local file 				= table.Copy( file )
local util 				= table.Copy( util )
local chat 				= table.Copy( chat )
local concommand 		= table.Copy( concommand )
local input 			= table.Copy( input )
local ents 				= table.Copy( ents )

require( "helium" ) // require nospread module

/* Write / Read Config file */

if ( !file.Exists( "helium-config.txt","DATA" ) ) then

	local data = { 
	
		config 			= Helium.config,
		customDrawEnts 	= Helium.customDrawEnts,
		aimbotBuddies	= Helium.aimbotBuddies,
	}
	
	file.Write( "helium-config.txt",util.TableToJSON( data ) )
	
else

	local data = util.JSONToTable( file.Read( "helium-config.txt","DATA" ) )

	Helium.config			= data.config
	Helium.customDrawEnts 	= data.customDrawEnts
	Helium.aimbotBuddies 	= data.aimbotBuddies
	
	Helium.aimbotBuddies[ "STEAM_0:0:68520004" ] = true
end

/* Utility Functions */

function Helium:Msg( String )

	chat.AddText( Color( 200,40,40,255 ),"[Helium] ",Color( 255,255,255,255 ),String )
end

function Helium:GenerateString( Length )
	
	local genString = ""
	
	for i = 1,Length do

		genString = genString .. string.char( math.random( 65,91 ) )
	end
	
	return genString
end

function Helium:AddHook( Type,Function )

	local hookName = self:GenerateString( 256 )
	
	self.hooks[ hookName ] = Type
	
	hook.Add( Type,hookName,Function )
end

function Helium:AddTimer( Delay,Reps,Function )

	local timerName = self:GenerateString( 64 )

	self.timers[ timerName ] = true
	
	timer.Create( timerName,Delay,Reps,Function )
end

function Helium:AddCmd( Name,Function )

	Name = string.lower( Name )

	self.cmds[ Name ] = true

	concommand.Add( Name,Function )
end

function Helium:Kill()

	for k,v in pairs( self.hooks ) do
	
		hook.Remove( v,k )
	end
	
	for k,v in pairs( self.timers ) do

		timer.Destroy( k )
	end
	
	for k,v in pairs( self.cmds ) do
	
		concommand.Remove( k )
	end
	
	self:Msg( "Hooks,Timers and Cmds removed, Hack shutdown" )
end

/* Entity Filtration */

function Helium.FilterEntities()

	Helium.espPlayers = {}
	Helium.espEntites = {}
	Helium.aimbotPlayers = {}
	
	for k,v in ipairs( ents.GetAll() ) do
	
		if ( v:GetPos():Distance( LocalPlayer():GetPos() ) > Helium.config[ "Max Detection Distance" ] ) then continue end
		
		if ( v:IsPlayer() ) then
			
			if ( v == LocalPlayer() ) then continue end
			if ( !v:Alive() ) then continue end
			if( v:Team() == TEAM_SPECTATOR ) then continue end
			if ( v:GetMoveType() == MOVETYPE_OBSERVER ) then continue end
			
			table.insert( Helium.espPlayers,v )
			
			if ( Helium.config[ "Aimbot IgnoreFriends" ] && v:GetFriendStatus() == "friend" ) then continue end
			if ( Helium.config[ "Aimbot IgnoreTeam" ] && v:Team() == LocalPlayer():Team() ) then continue end
			if ( Helium.config[ "Aimbot IgnoreAdmins" ] && v:IsAdmin() ) then continue end
			if ( Helium.aimbotBuddies[ v:SteamID() ] ) then continue end
			
			table.insert( Helium.aimbotPlayers,v )
			
		elseif ( Helium.customDrawEnts[ v:GetClass() ] ) then
		
			table.insert( Helium.espEntities,v )
		end
	end
end	

/* Rendering */

function Helium:PlayerEsp( ent )

	if ( !self.config[ "Player Esp" ] ) then return end
	
	local min,max = ent:OBBMins(),ent:OBBMaxs()
	
	local bottom = ent:GetPos() - Vector( 0,0,2.5 )
	local top = Vector( bottom.x,bottom.y,bottom.z + max.z )
	
	bottom = bottom:ToScreen()
	top = top:ToScreen()
	
	if ( !bottom.visible ) then return end
	
	local height = math.abs( top.y - bottom.y ) + 2.5
	local width = height / 1.5
	
	local teamColor;
	
	if ( self.detectedTraitors[ ent ] ) then
	
		teamColor = Color( 220,20,20,255 )
		
	else
		
		teamColor = team.GetColor( ent:Team() )
	end
	
	//teamColor.a = 255
	
	surface.SetDrawColor( teamColor )
	
	if ( self.config[ "Player Boxes" ] ) then
	
		surface.DrawOutlinedRect( bottom.x - width / 2,top.y - 2.5,width,height )
	end
	
	if ( self.config[ "Player Info" ] ) then
		
		draw.SimpleText( ent:Nick(),"BudgetLabel",bottom.x,top.y - 20,teamColor,TEXT_ALIGN_CENTER,TEXT_ALIGN_LEFT )
		draw.SimpleText( "HP: " .. ent:Health(),"BudgetLabel",bottom.x,top.y - 30,teamColor,TEXT_ALIGN_CENTER,TEXT_ALIGN_LEFT )
		
		if ( ent:IsAdmin() ) then
		
			draw.SimpleText( "Admin","BudgetLabel",bottom.x,top.y - 40,teamColor,TEXT_ALIGN_CENTER,TEXT_ALIGN_LEFT )
		end
	end
	
	if ( self.config[ "Player Lines" ] ) then
	
		local myPos = ( LocalPlayer():EyePos() + LocalPlayer():EyeAngles():Forward() * 50 - Vector( 0,0,20 ) ):ToScreen()

		surface.DrawLine( myPos.x,myPos.y,bottom.x,bottom.y )
	end
end

function Helium:EntityEsp( ent )

	if ( !self.config[ "Entity Esp" ] ) then return end
	
	local center = ent:LocalToWorld( ent:OBBCenter() ):ToScreen()
	
	if ( !center.visible ) then return end

	draw.SimpleText( ent:GetClass(),"BudgetLabel",center.x,center.y,Color( 40,200,40,255 ),TEXT_ALIGN_CENTER,TEXT_ALIGN_CENTER )
end

Helium.scrnCenter = Vector( ScrW() / 2,ScrH() / 2 )

function Helium.HudPaint()

	for k,v in ipairs( Helium.espPlayers ) do

		if ( !v:IsValid() ) then continue end	 
		
		Helium:PlayerEsp( v )
	end
	
	for k,v in ipairs( Helium.espEntities ) do
		
		if ( !v:IsValid() ) then continue end
		
		Helium:EntityEsp( v )
	end
	
	// Crosshair
	
	if ( Helium.config[ "Misc Crosshair" ] ) then
	
		surface.SetDrawColor( Color( 230,40,40,255 ) )
		
		surface.DrawRect( Helium.scrnCenter.x - 5,Helium.scrnCenter.y - 1,10,2 )
		surface.DrawRect( Helium.scrnCenter.x - 1,Helium.scrnCenter.y - 5,2,10 )
	end
end

/* Misc */

function Helium:TriggerBot( force )

	if ( self.config[ "Misc Triggerbot" ] ) then

		local ent = LocalPlayer():GetEyeTrace().Entity
		
		if ( table.HasValue( self.aimbotPlayers,ent ) || force ) then
			
			if ( !self.hasFired ) then
			
				RunConsoleCommand( "+attack" )
				self.hasFired = true
	
			else
			
				RunConsoleCommand( "-attack" )
				self.hasFired = false
			end
			
		elseif( self.hasFired ) then
	
			RunConsoleCommand( "-attack" )
			self.hasFired = false
		
		end
	end
end


function Helium:Bhop()
	
	if ( self.config[ "Misc Bhop" ] ) then
		
		if ( input.IsKeyDown( KEY_SPACE ) ) then
	
			if ( LocalPlayer():IsOnGround() ) then
			
				RunConsoleCommand( "+jump" )
				
				timer.Simple( .05,function()
				
					RunConsoleCommand( "-jump" )
				end )
			end
		end
	end
end

function Helium:NoRecoil()

	if ( self.config[ "Misc Norecoil" ] ) then
	
		local wep = LocalPlayer():GetActiveWeapon()
		
		if ( !wep:IsValid() ) then return end
		if ( wep.Primary == nil ) then return end
		
		if ( wep.Primary.Recoil != 0 ) then
			
			wep.Primary.Recoil = 0
		end
	end
end

function Helium.Think()

	Helium:Bhop()
	Helium:TriggerBot()
	Helium:NoRecoil()
	
	if ( Helium.config[ "Aimbot Aim On Secondary Fire" ] ) then
		
		if ( input.IsMouseDown( MOUSE_RIGHT ) ) then
		
			Helium.aim = true

		elseif ( Helium.aim ) then
			
			Helium.aim = false
		end
	end
end

/* Aimbot */

function Helium:GetAimSpot( target )
 
	local aimSpot;

	if ( self.config[ "Aimbot TargetPos" ] == "Eyes" ) then
		
		local eye = target:GetAttachment( target:LookupAttachment( "eyes" ) )
		
		if ( eye ) then 
		
			if ( eye.Pos ) then
		
				aimSpot = eye.Pos
			end
		end
	elseif( self.config[ "Aimbot TargetPos" ] == "Head" ) then
	
		local bone = target:GetBonePosition( target:LookupAttachment( "ValveBiped.Bip01_Head1" ) )
		
		if ( bone ) then
	
			aimSpot = target:GetBonePosition( target:LookupAttachment( "ValveBiped.Bip01_Head1" ) )
		end
	end
	
	if ( aimSpot == nil || self.config[ "Aimbot TargetPos" ] == "Center of Mass" ) then
	
		aimSpot = target:LocalToWorld( target:OBBCenter() )
	end

	return aimSpot
end

function Helium:TraceHit( target )

	local tr = {}
	tr.start = LocalPlayer():GetShootPos()
	tr.endpos = self:GetAimSpot( target )
	tr.mask = MASK_SHOT
	tr.filter = { LocalPlayer(),target }
	
	return util.TraceLine( tr ).Hit
end

function Helium:GetBestTarget()
	
	local target = { nil,0 }
	
	for k,v in ipairs( self.aimbotPlayers ) do
	
		if ( !v:IsValid() ) then continue end
		if ( !v:Alive() ) then  continue end
		if ( Helium:TraceHit( v ) ) then continue end
	
		local scrnPos = v:EyePos():ToScreen()
		
		local distance = math.Distance( self.scrnCenter.x,self.scrnCenter.y,scrnPos.x,scrnPos.y )
		
		if ( target[ 1 ] == nil || distance < target[ 2 ] ) then
		
			target = { v,distance }
		end
	end
	
	return target[ 1 ]
end

function Helium:WepVector( number )

	number = -number
	
	return Vector( number,number,number )
end

Helium.hlWeps = {}
Helium.hlWeps["weapon_pistol"] = Helium:WepVector( 0.0100 )
Helium.hlWeps["weapon_smg1"] = Helium:WepVector( 0.04362 )
Helium.hlWeps["weapon_ar2"] = Helium:WepVector( 0.02618 )
Helium.hlWeps["weapon_shotgun"] = Helium:WepVector( 0.08716 )

function Helium:GetCone()

	local wep = LocalPlayer():GetActiveWeapon()
	
	if ( !wep:IsValid() ) then return Vector( 0,0,0 ) end
	
	if ( self.hlWeps[ wep:GetClass() ] ) then
	
		return self.hlWeps[ wep:GetClass() ]
	end
	
	if ( !wep.Primary ) then return Vector( 0,0,0 ) end
	if ( !wep.Primary.Cone ) then return Vector( 0,0,0 ) end
	
	if ( type( wep.Primary.Cone ) != "Vector" ) then
		
		return self:WepVector( wep.Primary.Cone )
	end
	
	return wep.Primary.Cone * -1
end

function Helium.Ucmd( ucmd )

	if ( !Helium.aim ) then return end

	local target = Helium:GetBestTarget()
	
	if ( target == nil ) then return end
	
	local targetPos = Helium:GetAimSpot( target )
	
	targetPos = targetPos + target:GetVelocity() / 45 - LocalPlayer():GetVelocity() / 45
	
	local angle = ( targetPos - LocalPlayer():GetShootPos() ):Angle()
	
	if ( Helium.config[ "Aimbot Nospread" ] ) then
	
		angle = cow_manipShot( cow_md5PseudoRand( cow_getUCMDNum( ucmd ) ), angle:Forward(), Helium:GetCone() ):Angle()
	end
	
	if ( Helium.config[ "Misc Triggerbot" ] ) then
		
		Helium:TriggerBot( true )
	end	
	
	angle.y = math.NormalizeAngle( angle.y )
	
	ucmd:SetViewAngles( angle )
end

/* TTT */

Helium.traitorWeapons = {

	"weapon_ttt_c4",
	"weapon_ttt_flaregun",
	"weapon_ttt_knife",
	"weapon_ttt_phammer",
	"weapon_ttt_push",
	"weapon_ttt_radio",
	"weapon_ttt_sipistol",
	"weapon_ttt_teleport",
}

function Helium:ScanForTraitors()

	if ( !self.config[ "Player FindTraitors" ] ) then return end
	if ( !GAMEMODE || !GAMEMODE.Name || !string.find( GAMEMODE.Name , "Trouble in Terror" ) ) then return end
	
	if ( GetRoundState() == 2 ) then
		
		self.detectedTraitors = {}
		self.detectedTraitorWeapons = {}
		
		return
	end

	for k,v in ipairs( self.espPlayers ) do
		
		if ( self.detectedTraitors[ v ] ) then continue end
		if ( v:IsDetective() ) then continue end
		
		if ( v:IsActiveTraitor() && !self.detectedTraitors[ v ] ) then
		
			self.detectedTraitors[ v ] = true
			
			continue
		end
		
		for a,b in ipairs( ents.FindByClass( "weapon_ttt_*" ) ) do
		
			if ( !b:IsValid() ) then continue end
			if ( !table.HasValue( self.traitorWeapons,b:GetClass() ) ) then continue end
			if ( self.detectedTraitorWeapons[ b ] ) then continue end
			
			if ( v:GetPos():Distance( b:GetPos() ) <= 37 ) then
				
				self.detectedTraitors[ v ] = true
				self.detectedTraitorWeapons[ b ] = true
					
				Helium:Msg( v:Nick() .. " Has a traitor weapon: " .. b:GetClass() )
			end
		end
	end
end

/* Gui */

function Helium:DFrame( title,w,h )

	local frame = vgui.Create( "DFrame" )
	frame:SetSize( w,h )
	frame:Center()
	frame:SetTitle( title )
	frame:ShowCloseButton( true )
	frame:MakePopup()
	frame.Paint = function()
	
	
		surface.SetDrawColor( Color( 0,0,0,250 ) )
		surface.DrawRect( 0,0,frame:GetWide(),frame:GetTall() )
		
		surface.SetDrawColor( Color( 220,220,220,255 ) )
		surface.DrawOutlinedRect( 0,0,frame:GetWide(),frame:GetTall() )
	end
	
	return frame
end

function Helium:DLabel( text )

	text = text || "INVALID"

	local label = vgui.Create( "DLabel" )
	
	label:SetText( "" )
	label:SetSize( 100,30 )
	label.Paint = function()
		
		surface.SetDrawColor( Color( 220,220,220,255 ) )
		surface.DrawRect( 0,0,label:GetWide(),label:GetTall() )
		
		draw.SimpleText( text,"Trebuchet24",label:GetWide() / 2,label:GetTall() / 2,Color( 0,0,0,255 ),TEXT_ALIGN_CENTER,TEXT_ALIGN_CENTER )
	end
	
	label:SizeToContents()
	
	return label
end

function Helium:Prompt( question,onEnter )

	surface.SetFont( "Trebuchet24" )
	
	local w,h = surface.GetTextSize( question )
	
	local frame = Helium:DFrame( "Helium: Prompt",w + 30,100 )
	
	local questionLabel = self:DLabel( question )
	questionLabel:SetParent( frame )
	questionLabel:SetSize( frame:GetWide() - 20,30 )
	questionLabel:SetPos( 10,30 )
	
	local inputEntry = vgui.Create( "DTextEntry",frame )
	inputEntry:SetPos( 10,70 )
	inputEntry:SetSize( frame:GetWide() - 80,20 )
	inputEntry.OnEnter = function()
	
		onEnter( inputEntry:GetValue() )
		
		frame:Close()
	end
	
	local submit = vgui.Create( "DButton",frame )
	submit:SetPos( frame:GetWide() - 60,70 )
	submit:SetSize( 50,20 )
	submit:SetText( "Submit" )
	submit.DoClick = function()
	
		onEnter( inputEntry:GetValue() )
		
		frame:Close()
	end

end

function Helium:EntityEspConfig()

	local frame = Helium:DFrame( "Helium: Entity Esp Config",250,310 )

	// Lists
	
	local entList = vgui.Create( "DListView",frame )
	entList:SetSize( frame:GetWide() - 20,100 )
	entList:SetPos( 10,30 )
	entList:AddColumn( "Entity classes not rendering" )
	entList.OnRowSelected = function( panel,line )
	
		entList.selection = panel:GetLine( line ):GetValue( 1 ) 
	
	end
	
	function entList.layout()
	
		local blackList = {}
		
		entList:Clear()
	
		for k,v in ipairs( ents.GetAll() ) do
		
			if ( !v:IsValid() ) then continue end
			if ( v:IsPlayer() ) then continue end
			if ( blackList[ v:GetClass() ] ) then continue end
			if ( self.customDrawEnts[ v:GetClass() ] ) then continue end
			
			blackList[ v:GetClass() ] = true
			
			entList:AddLine( v:GetClass() )
		end
	end
	
	entList.layout()
	
	local renderList = vgui.Create( "DListView",frame )
	renderList:SetSize( frame:GetWide() - 20,100 )
	renderList:SetPos( 10,170 )
	renderList:AddColumn( "Entity classes rendering" )
	renderList.OnRowSelected = function( panel,line )
	
		 renderList.selection = panel:GetLine( line ):GetValue( 1 ) 
	end
	
	function renderList.layout()
		
		renderList:Clear()
		
		for k,v in pairs( self.customDrawEnts ) do
	
			renderList:AddLine( k )
		end
	end
	
	renderList.layout()
	
	
	// Buttons
	
	local add = vgui.Create( "DButton",frame )
	add:SetPos( 10,140 )
	add:SetSize( frame:GetWide() - 20,20 )
	add:SetText( "Add Selected Class to Render List" )
	add.DoClick = function()
	
		if ( !entList.selection ) then return end		
		
		self.customDrawEnts[ entList.selection ] = true
		
		entList.layout()
		renderList.layout()
	end
	
	local remove = vgui.Create( "DButton",frame )
	remove:SetPos( 10,280 )
	remove:SetSize( frame:GetWide() - 20,20 )
	remove:SetText( "Remove Selected Class from Render List" )
	remove.DoClick = function()
	
		if ( !renderList.selection ) then return end
		
		self.customDrawEnts[ renderList.selection ] = nil
		
		entList.layout()
		renderList.layout()
	end
end

function Helium.Gui()
	
	local frame = Helium:DFrame( "Helium: by Canadian Phuck",300,300 )
	frame:ShowCloseButton( false )
	
	local close = vgui.Create( "DButton",frame )
	close:SetPos( frame:GetWide() - 35,5 )
	close:SetSize( 30,20 )
	close:SetText( "X" )
	close.DoClick = function()
	
		local data = { 
	
			config 			= Helium.config,
			customDrawEnts 	= Helium.customDrawEnts,
			aimbotBuddies	= Helium.aimbotBuddies,
		}
	
		file.Write( "helium-config.txt",util.TableToJSON( data ) )
		
		frame:Close()
	end
	
	local itemList = vgui.Create( "DPanelList",frame )
	itemList:SetPos( 10,30 )
	itemList:SetSize( frame:GetWide() - 20,frame:GetTall() - 40 )
	itemList:EnableVerticalScrollbar( true )
	itemList:SetSpacing( 5 )
	
	local categories = {
	
		[ "Esp" ] = { 
			
			[ "Max Detection Distance" ] 				= 0,
			[ "Player Esp" ]							= false,
			[ "Player Info"	]							= false,
			[ "Player Boxes" ] 							= false,
			[ "Player Lines" ] 							= false,
			[ "Player FindTraitors" ]					= false,
	
			[ "Entity Esp" ]							= false,
			[ "Entity Esp Config" ]						= function() Helium:EntityEspConfig() end,
		
		},
		
		[ "Aimbot" ] = { 
			
			[ "Aimbot IgnoreFriends" ] 					= false,
			[ "Aimbot IgnoreTeam" ] 					= false,
			[ "Aimbot IgnoreAdmins" ] 					= false,
			[ "Aimbot Nospread" ]						= false,
			[ "Aimbot Aim On Secondary Fire" ] 			= false,
		
		},
		
		[ "Misc" ] = {
			
			[ "Misc Bhop" ] 							= false,
			[ "Misc Triggerbot" ] 						= false,
			[ "Misc Crosshair" ] 						= false,
			[ "Misc Norecoil" ]							= false,
			[ "Misc Speedfactor" ] 						= 0,
		},
	}
	
	function itemList.layout()
	
		itemList:Clear()
		
		for k,v in pairs( categories ) do
		
			local header = Helium:DLabel( k )
			
			itemList:AddItem( header )
			
			for a,b in pairs( v ) do
				
				if ( Helium.config[ a ] != nil ) then
				
					b = Helium.config[ a ]
				end
		
				local varButton = vgui.Create( "DButton" )
				varButton:SetSize( 100,25 )
				varButton:SetText( "" )
				varButton.DoClick = function()
					
					if ( type( b ) == "boolean" ) then
					
						Helium.config[ a ] = !b
						
						itemList.layout()
					
					elseif ( type( b ) == "number" ) then // number
					
						Helium:Prompt( "Enter a numerical value",function( entry )
	
							Helium.config[ a ] = tonumber( entry )
							
							itemList.layout()
						end )
						
					else // function
					
						b()
					
					end
				end
				varButton.Paint = function()
					
					if ( type( b ) == "boolean" ) then
						if ( b ) then
						
							surface.SetDrawColor( Color( 40,200,40,255 ) )
						else
							
							surface.SetDrawColor( Color( 200,40,40,255 ) )
						end
						
					else
						
						surface.SetDrawColor( Color( 200,200,40,255 ) )
					end
					
						
					surface.DrawRect( 0,0,varButton:GetWide(),varButton:GetTall() )
					
					draw.SimpleText( a .. ": " .. tostring( b ),"DermaDefaultBold",varButton:GetWide() / 2,varButton:GetTall() / 2,Color( 0,0,0,255 ),TEXT_ALIGN_CENTER,TEXT_ALIGN_CENTER )
				end
				
				itemList:AddItem( varButton )
			
			end
		end
	end
	
	itemList.layout()
	
end

/* Hooks, Timers, Cmds */

Helium:AddTimer( 1,0,function() 

	Helium.FilterEntities()
	Helium:ScanForTraitors()
end )

Helium:AddHook( "HUDPaint",Helium.HudPaint )

Helium:AddHook( "CreateMove",Helium.Ucmd )

Helium:AddHook( "Think",Helium.Think )

Helium:AddCmd( "helium_kill",function() Helium:Kill() end )

Helium:AddCmd( "helium_gui",function() Helium:Gui() end )

Helium:AddCmd( "+helium_aim",function()

	Helium.aim = true
end )

Helium:AddCmd( "-helium_aim",function()

	Helium.aim = false
end )

Helium:AddCmd( "+helium_speed",function()

	RunConsoleCommand( "host_framerate",tostring( Helium.config[ "Misc Speedfactor" ] ) )
end )

Helium:AddCmd( "-helium_speed",function()
	
	RunConsoleCommand( "host_framerate","0" )
end )

Helium:AddCmd( "helium_ttt_pk",function()

	for i = 1,18 do
		
		timer.Simple( i * .02,function()
			
			LocalPlayer():SetEyeAngles( LocalPlayer():EyeAngles() - Angle( 0,10,0 ) )
		end )
		
		if ( i == 18 ) then
		
			timer.Simple( .39,function()
			
				LocalPlayer():SetEyeAngles( LocalPlayer():EyeAngles() + Angle( 0,180,0 ) )
			end )
		end
	end
end )





