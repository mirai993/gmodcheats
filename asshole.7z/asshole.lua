--[[
	lua/autorun/client/scripts/boobies.lua
	Oubliette | (STEAM_0:1:34029133)
	===DStream===
]]

local isActive = false;
local targ;

concommand.Add("asshole_activate", function() isActive = !isActive; end);
concommand.Add("asshole_rtarget", function() targ = nil; end);

/*
local last_fire = CurTime();
local function TriggerBot( cmd )
	if (CurTime() > last_fire+(LocalPlayer():GetActiveWeapon().Primary and LocalPlayer():GetActiveWeapon().Primary.Delay or 0.03) ) then 
		RunConsoleCommand("+attack");last_fire = CurTime();firing = true;
	elseif firing then 
		RunConsoleCommand("-attack")
		firing = false;
	end
end


hook.Add( "InputMouseApply", "Tits", function( cmd )
	
	if ( targ && IsValid( targ ) && targ:IsPlayer() && targ:Alive() && isActive ) then 

		local trace = {}

		local id = targ:LookupBone( "ValveBiped.Bip01_Head1" );

		local point = targ:GetBonePosition( id );
		local mpos,tpos = LocalPlayer():GetShootPos(),point;

		trace.start = mpos;
		trace.endpos = point;
		trace.filter = {LocalPlayer()};
		trace.mask = mask

		local trres = util.TraceLine(trace);

		if ( trres.Entity == targ ) then 

			local ang = ( tpos - mpos ):Angle();

			ang.p,ang.y,ang.r = math.NormalizeAngle(ang.p),math.NormalizeAngle(ang.y),math.NormalizeAngle(ang.r);

			cmd:SetViewAngles( ang );

			TriggerBot( cmd );

		else 

			targ = nil;

		end

	else

		targ = LocalPlayer():GetEyeTrace().Entity or nil;

		if ( firing ) then TriggerBot( cmd ); end

	end

end);

*/

hook.Add( "HUDPaint", "NiceAss", function()

	if ( !isActive ) then return; end

	for _, ply in pairs( player.GetAll() ) do 

		if ( !ply || !IsValid( ply ) || !ply:Alive() ) then continue; end

		local pos = ply:GetPos():ToScreen();

		draw.SimpleText( ply:GetName(), "default", pos.x, pos.y, Color( 255, 255, 255, 255 ), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP );
		draw.SimpleText( "H : " .. ply:Health(), "default", pos.x, pos.y - 10, Color( 255, 255, 255, 255 ), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP );
		draw.SimpleText( "Dist : " .. math.Round( ply:GetPos():Distance( LocalPlayer():GetPos() ) / 16 ) .. "ft", "default", pos.x, pos.y - 20, Color( 255, 255, 255, 255 ), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP );

	end

end);
