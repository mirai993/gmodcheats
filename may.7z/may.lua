// note by paradox: https://www.mpgh.net/forum/showthread.php?t=1448187

require("bsendpacket")

local falseangs = LocalPlayer():EyeAngles()

function IsValidTarget(ent)
	if IsValid(ent) and ent:IsPlayer() and ent != LocalPlayer() and ent:Alive() and LocalPlayer():Alive() and !ent:IsDormant() and LocalPlayer():Team() != TEAM_SPECTATOR and ent:Team() != TEAM_SPECTATOR then
		return true
	end
end

function IsTargetVisible(ent)
	local penvalues = {
		["SniperPenetratedRound"] = 20, 
		["Pistol"] = 9, 
		["357"] = 12, 
		["SMG1"] = 14, 
		["AR2"] = 16, 
		["Buckshot"] = 5
	} //These are for M9K
	local trace = util.TraceLine({mask = MASK_ALL, start = LocalPlayer():GetShootPos(), endpos = ent:GetBonePosition(ent:LookupBone("ValveBiped.Bip01_Head1")), filter = {LocalPlayer(), ent}})
	local wall = util.TraceLine({mask = MASK_SHOT, start = LocalPlayer():GetShootPos(), endpos = ent:GetBonePosition(ent:LookupBone("ValveBiped.Bip01_Head1")), filter = {LocalPlayer(), ent}})
    local wall2 = util.TraceLine({mask = MASK_SHOT, start = ent:GetBonePosition(ent:LookupBone("ValveBiped.Bip01_Head1")), endpos = LocalPlayer():GetShootPos(), filter = {LocalPlayer(), ent}})

	if trace.Fraction == 1 or (IsValid(LocalPlayer():GetActiveWeapon()) and wall.HitPos:Distance(wall2.HitPos) < penvalues[game.GetAmmoName(LocalPlayer():GetActiveWeapon():GetPrimaryAmmoType())]) then
		return true
	end
end

//Credits to Mr.Hankey
function CorrectMovement(vOldAngles, cmd, fOldForward, fOldSidemove)
	local deltaView = cmd:GetViewAngles().y - vOldAngles.y
	local f1 = 0
	local f2 = 0

	if vOldAngles.y < 0 then
		f1 = 360 + vOldAngles.y
	else
		f1 = vOldAngles.y
	end

	if cmd:GetViewAngles().y < 0 then
		f2 = 360 + cmd:GetViewAngles().y
	else
		f2 = cmd:GetViewAngles().y
	end

	if f2 < f1 then
		deltaView = math.abs(f2 - f1)
	else
		deltaView = 360 - math.abs(f1 - f2)
	end

	deltaView = 360 - deltaView
 
    cmd:SetForwardMove(math.cos(math.rad(deltaView)) * fOldForward + math.cos(math.rad(deltaView + 90)) * fOldSidemove)
    cmd:SetSideMove(math.sin(math.rad(deltaView)) * fOldForward + math.sin(math.rad(deltaView + 90)) * fOldSidemove)
end

hook.Add("HUDPaint", "may_hudpaint", function()
	for k, v in pairs(player.GetAll()) do
		if IsValidTarget(v) then
			v:SetColor(Color(0, 255, 0))
			v:SetMaterial("models/debug/debugwhite")
			halo.Add({v}, Color(255, 0, 0), 2, 2, 1, true, true)
		end
	end
end)

local servertime = 0

hook.Add("Move", "may_move", function()
	if IsFirstTimePredicted then
		servertime = CurTime()
	end
end)

hook.Add("CreateMove", "may_createmove", function(cmd)
	falseangs.p = falseangs.p + (cmd:GetMouseY() * GetConVarNumber("m_pitch"))
	falseangs.y = falseangs.y - (cmd:GetMouseX() * GetConVarNumber("m_yaw"))
	falseangs:Normalize()

	if falseangs.p >= 90 then
		falseangs.p = 90
	elseif falseangs.p <= -90 then
		falseangs.p = -90
	end

	local target = nil

	for k, v in next, player.GetAll() do
		if IsValidTarget(v) and IsTargetVisible(v) then
			target = v
		end
	end

	if target != nil and IsValid(LocalPlayer():GetActiveWeapon()) and LocalPlayer():GetActiveWeapon():GetNextPrimaryFire() < servertime then
		bSendPacket = false
		cmd:SetViewAngles((target:GetBonePosition(target:LookupBone("ValveBiped.Bip01_Head1")) - LocalPlayer():GetShootPos()):Angle())

		local firing = false

		if IsValid(LocalPlayer():GetActiveWeapon()) and LocalPlayer():GetActiveWeapon().Primary and LocalPlayer():GetActiveWeapon().Primary.Automatic then
			cmd:SetButtons(bit.bor(cmd:GetButtons(), IN_ATTACK))

			firing = true
		else
			if firing then
				cmd:RemoveKey(IN_ATTACK)

				firing = false
			else
				cmd:SetButtons(bit.bor(cmd:GetButtons(), IN_ATTACK))

				firing = true
			end
		end
	else
		bSendPacket = true
		cmd:SetViewAngles(falseangs)
	end

	local direction = {}
	direction.x = 0
	direction.y = 0

	if cmd:KeyDown(IN_FORWARD) then
		if cmd:KeyDown(IN_SPEED) then
			direction.x = LocalPlayer():GetRunSpeed()
		else
			direction.x = LocalPlayer():GetWalkSpeed()
		end
	end

	if cmd:KeyDown(IN_BACK) then
		if cmd:KeyDown(IN_SPEED) then
			direction.x = -LocalPlayer():GetRunSpeed()
		else
			direction.x = -LocalPlayer():GetWalkSpeed()
		end
	end

	if cmd:KeyDown(IN_MOVELEFT) then
		if cmd:KeyDown(IN_SPEED) then
			direction.y = -LocalPlayer():GetRunSpeed()
		else
			direction.y = -LocalPlayer():GetWalkSpeed()
		end
	end

	if cmd:KeyDown(IN_MOVERIGHT) then
		if cmd:KeyDown(IN_SPEED) then
			direction.y = LocalPlayer():GetRunSpeed()
		else
			direction.y = LocalPlayer():GetWalkSpeed()
		end
	end

	if !LocalPlayer():IsOnGround() then
		direction.x = 5850 / LocalPlayer():GetVelocity():Length2D()

		if cmd:CommandNumber() % 2 == 0 then
			direction.y = -LocalPlayer():GetVelocity():Length2D()
		elseif cmd:CommandNumber() % 2 != 0 then
			direction.y = LocalPlayer():GetVelocity():Length2D()
		end
	end

	if cmd:KeyDown(IN_JUMP) and !LocalPlayer():IsOnGround() and LocalPlayer():GetMoveType() != MOVETYPE_LADDER then
		cmd:RemoveKey(IN_JUMP)
	end

	CorrectMovement(falseangs, cmd, direction.x, direction.y)
end)

hook.Add("CalcView", "may_calcview", function(ply, origin, angles, fov, znear, zfar)
	local view = {}

	view.origin = origin
	view.angles = falseangs
	view.fov = fov

	return view
end)

hook.Add("CalcViewModelView", "may_calcviewmodelview", function(wep, vm, oldPos, oldAng, pos, ang)
	return LocalPlayer():GetShootPos(), falseangs
end)