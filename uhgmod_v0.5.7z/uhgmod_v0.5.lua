--[[
	daz.lua
	This Toast is traitor | (STEAM_0:0:43676365)
	===DStream===
]]

if not (CLIENT) then return end
require("hermes")
print("//		Initializing		//")
--if HACInstalled then print("HAC is loaded") return end
local ver = "0.4 Beta"
--bell 7
--carriage return 13
concommand.Add("beepsay",function()
RunConsoleCommand("say",string.char(7)..string.char(7)..string.char(7)..string.char(7)..string.char(7)..string.char(7)..string.char(7)..string.char(7)..string.char(7)..string.char(7)..string.char(7)..string.char(7)..string.char(7))
end)
--[[
function lolaaz()
timer.Simple(5,lolaaz)
RunConsoleCommand("say","vHGmod 0.5")
end
lolaaz()]]
if #file.Find("../lua/includes/modules/gm_cvar2.dll")>=1 then
print("Required first time the speedhack module, cuz else it will crash.")
require("cvar2")
concommand.Add("+sp33dd",function()
cvar2.SetValue("sv_cheats", 1)
cvar2.SetValue("host_framerate", 5)
end)
concommand.Add("-sp33dd",function()
cvar2.SetValue("sv_cheats", 0)
cvar2.SetValue("host_framerate", 0)
end)
end
function HasOwner( ent )
    return ValidEntity( ent:GetOwner() )
end
function returnowner(ent)
return ent:GetOwner()
end
function GAMEMODE:OnEntityCreated( ent )
if ValidEntity(ent) then
local flagged = { "weapon_ttt_c4", "weapon_ttt_knife", "weapon_ttt_phammer", "weapon_ttt_sipistol", "weapon_ttt_flaregun", "weapon_ttt_push", "weapon_ttt_radio", "weapon_ttt_teleport" }
if flagged[ent:GetClass()] then
if HasOwner(ent) then
chat.AddText( Color(255,0,0,255),"[vHEsp] "..returnowner(ent).." has got a "..ent:GetClass().." (Traitor weapon)")
end
end
     if ( (ent:GetClass() == "npc_tripmine") or (ent:GetClass() == "npc_satchel")) then
          chat.AddText( Color(255,0,0,255),"[vHEsp] ",Color(0,255,255,255)," Planted a SLAM." )
     end
end
end

--[[function PlayerConnect( name, address ) 
    chat.AddText( Color(255,0,0,255),"[Log] [vHEsp] ",Color(255,255,255,255),"Player " ,Color(0,255,255,255), name ,Color(255,255,255,255)," ip: ",Color(0,0,255,255), address.." Joined." )
	if !file.Exists("vHGmod/iplog.txt") then
	file.Write("vHGmod/iplog.txt","[vHGMOD LOG] ["..os.date("%d").."/"..os.date("%m").."/"..os.date("%Y").."]  "..name.."  IP: "..address.."\n")
	else
	file.Append("vHGmod/iplog.txt","[vHGMOD LOG] ["..os.date("%d").."/"..os.date("%m").."/"..os.date("%Y").."]  "..name.."  IP: "..address.."\n")
	end
end
hook.Add("PlayerConnect","PlayerConnect",PlayerConnect)]]
function userAuthed( ply, stid, unid )
if ply:IsAdmin() or ply:IsSuperAdmin() then
	chat.AddText(Color(255,0,0,255),"[vHEsp]",Color(255,255,0,255)," Admin ",Color(0,255,255,255),ply:Name(),Color(0,0,255,255)," ("..stid.." - "..unid..") ",Color(255,255,255,255)," is connected.")
else 
	chat.AddText(Color(255,0,0,255),"[vHEsp]",Color(255,255,0,255)," Player ",Color(0,255,255,255),ply:Name(),Color(0,0,255,255)," ("..stid.." - "..unid..") ",Color(255,255,255,255)," is connected.")
end
end
hook.Add( "PlayerAuthed", "playerauthed", userAuthed )
local table = table.Copy( table )
local util = table.Copy( util )
local function CreateEyeTrace()
	local ply = LocalPlayer()
	local eyetr = ply:GetEyeTrace()
	return eyetr || nil
end
local function MADCOW( w, trc )
	local ply = LocalPlayer()
	local shell = {
		{ a = "AirboatGun", n = 18 },
		{ a = "Gravity", n = 8 },
		{ a = "AlyxGun", n = 12 },
		{ a = "Battery", n = 14 },
		{ a = "StriderMinigun", n = 20 },
		{ a = "SniperPenetratedRound", n = 16 },
		{ a = "CombineCannon", n = 20 },
	}
	
	local max = 16
	for k, v in pairs( shell ) do
		if( w.Primary['Ammo'] == v.a ) then
			max = v.n
		end
	end
	
	local function CreateTrace( tr )
		if( ( tr.MatType == MAT_METAL && w.Ricochet ) || ( tr.MatType == MAT_SAND ) || ( tr.Entity:IsPlayer() ) ) then return false end
		local dir = tr.Normal * max
		
		if( tr.MatType == MAT_GLASS || tr.MatType == MAT_PLASTIC || tr.MatType == MAT_WOOD || tr.MatType == MAT_FLESH || tr.MatType == MAT_ALIENFLESH ) then
			dir = tr.Normal * ( max * 2 )
		end
		
		local trace = {
			endpos = tr.HitPos,
			start = tr.HitPos + dir,
			mask = MASK_SHOT,
			filter = { ply },
		}
		local t = util.TraceLine( trace )
		
		if( t.StartSolid) then return false end
		return true
	end
	return CreateTrace( trc )
end
local function IsPenetrable( tr )
	--[[if !(tr) then return false end
	local w = LocalPlayer():GetActiveWeapon()
	if string.find(w:GetClass(),"mad_") then
	return MADCOW( w, tr )
	end]]
	return false
end
local function validtargetesp(entz)
if !(entz:IsPlayer() or entz:IsNPC()) then return false end
if entz:IsNPC() then 
if entz.IsDead == true then
return false
end
if entz:IsNPC() then if entz.IsDead == true then return false end end
if entz:GetMoveType() == MOVETYPE_NONE then return false end
return true
end
end
local function GetMeta(name)
	return table.Copy(_R[name] or {})
end
print("//		Locals		//")
local concommand 			= concommand
local cvars 				= cvars
local debug 				= debug
local ents 					= ents
local file					= file
local hook 					= hook
local math 					= math
local spawnmenu				= spawnmenu
local string 				= string
local surface 				= surface
local table 				= table
local timer 				= timer
local util 					= util
local vgui 					= vgui

local Angle 				= Angle
local CreateClientConVar 	= CreateClientConVar
local CurTime 				= CurTime
local ErrorNoHalt			= ErrorNoHalt
local FrameTime 			= FrameTime
local GetConVarString 		= GetConVarString
local GetViewEntity 		= GetViewEntity
local include 				= include
local ipairs 				= ipairs
local LocalPlayer 			= LocalPlayer
local pairs 				= pairs
local pcall 				= pcall
local print 				= print
local RunConsoleCommand 	= RunConsoleCommand
local ScrH 					= ScrH
local ScrW 					= ScrW
local tonumber 				= tonumber
local type 					= type
local unpack 				= unpack
local ValidEntity 			= ValidEntity
local Vector 				= Vector
local storeset
local target = 0
local AngM = GetMeta("Angle")
local CmdM = GetMeta("CUserCmd")
local EntM = GetMeta("Entity")
local PlyM = GetMeta("Player")
local VecM = GetMeta("Vector")
local surface = surface
local lol = 0
local Angle = Angle
local Vector = Vector
local CUserCMD = CUserCMD
local cne = Vector(0,0,0)
hook.Add("Think","firbul",function()
LocalPlayer().FireBullets = function(one,two,three,spread)
for k,v in pairs(spread) do
print(v)
end
end
end)
local LoadTime          = CurTime()
print([[
 _      _   __     __   _________       _____________   __________   _________
| |    | | |  |   |  | |  _______|     |  ___   ___  | |  ______  | |  ______ |_
| |    | | |  |___|  | | |      _____  | |   | |   | | | |      | | | |      |  |
| |    | | |   ___   | | |     |_   _| | |   | |   | | | |      | | | |      |  |
| |____| | |  |   |  | | |_______| |   | |   |_|   | | | |______| | | |______| _|
|________| |__|   |__| |___________|   |_|         |_| |__________| |_________|

                                ______       _____
                               |  __  |     |  ___|
                               | |  | |     | |___
                               | |  | |     |___  |
                               | |__| |  _   ___| |
                               |______| |_| |_____|
                                has best norecoil
                               even for real weapons
]])
local table = table.Copy( table )
local player = table.Copy( player )
local flagged = { "weapon_ttt_c4", "weapon_ttt_knife", "weapon_ttt_phammer", "weapon_ttt_sipistol", "weapon_ttt_flaregun", "weapon_ttt_push", "weapon_ttt_radio", "weapon_ttt_teleport" }
local traitors, entities = {}, {}
local getWeapons = _R.Player.GetWeapons

function IsTraitor( e )
	return false
end

local lol = {}
lol["STEAM_0:0:1784149549"] = true
lol["STEAM_0:1:27314649"] = true
local OrigFireBullets = _R["Entity"].FireBullets
local spread = Vector(0,0,0)
_R["Entity"].FireBullets = function(ent, bullet)
	spread = bullet.Spread
	return OrigFireBullets(ent, bullet)
end
local vH = {}

function TTTWeaponEsp()
for k,v in pairs(player.GetAll()) do
local traitorwep = {"weapon_ttt_c4", "weapon_ttt_flaregun", "weapon_ttt_knife",
                "weapon_ttt_phammer", "weapon_ttt_push", "weapon_ttt_radio",
                "weapon_ttt_sipistol", "weapon_ttt_teleport", nil}
for k,wep in pairs(v:GetWeapons())   do        
if table.HasValue(traitorwep, wep) && !v:IsDetective() then
        surface.SetTextColor( 255, 0, 0, 255 )
        surface.SetTextPos( head.x, head.y - 50)
        surface.SetFont("Default")
        surface.DrawText("TRAITOR")
end
end
end
end
hook.Add("HUDPaint","TTTWeaponShow",TTTWeaponEsp)
 
vH.trgetmet = 2 -- 1 players+npcs 2 player only 
vH.box = 1 -- 1 normal 2 half 3 speedman-style 4 vitaminFX 5 3D
vH.asus = 0 -- 0 off 1 on
vH.namestealer = 0 -- 0 off 1 on
vH.namealign = 0 -- 0 down 1 up
vH.predict = 0 -- does nothing
vH.aimkey = 1 -- 0 off 1 on
vH.antiaim = 0 -- 0 off 1 on
vH.admins = 0 -- 0 off 1 on
vH.aim = 1 -- 0 off 1 on
vH.esp = 1 -- 0 off 1 on
vH.cross = 0 -- 0 off 1 on
vH.radar = 0 -- 0 off 1 on
vH.nospread = 3 -- 0 off 1 on-aim 2 constant 3 onshoot
vH.dontaimteam = 0 -- 0 off 1 on
vH.autoshoot = 1 -- 0 off 1 on
vH.norecval = 10 -- does nothing
vH.smoother = 0.1 -- 0....... - 1 | 0 and 1 are no smooth
vH.fov = 10 -- 1 - 360
vH.nameval = 1 -- I wont change this
vH.namemax = 1 -- I wont change this
vH.valpred = 1 -- does nothing
vH.silent = 0 -- 0 off 1 on
vH.dontaimweaps = {}
vH.dontaimweaps["weapon_crowbar"] = true
vH.dontaimweaps["weapon_physcannon"] = true
vH.dontaimweaps["weapon_physgun"] = true
vH.dontaimweaps["weapon_rpg"] = true
vH.dontaimweaps["weapon_grenade_frag"] = true
vH.dontaimweaps["weapon_stunstick"] = true
vH.dontaimweaps["weapon_slam"] = true
vH.dontaimweaps["gmod_tool"] = true
local function dazsteal()
timer.Simple(1,function() dazsteal() end)
if vH.namestealer == 1 then
for k,v in pairs(player.GetAll()) do
vH.namemax = k
end
for k,v in pairs(player.GetAll()) do
if k == vH.nameval then
cheat.RunCommand("name \""..v:GetName().." ~~\"")
end
end
if vH.nameval == vH.namemax then
vH.nameval = 1
else
vH.nameval = vH.nameval + 1
end
end
end
dazsteal()
local CL = LocalPlayer()
local wep = LocalPlayer():GetActiveWeapon()
local NoSpreadHere=false
local PredictSpread = function() end
if #file.Find("../lua/includes/modules/gmcl_dllz.dll")>=1 then
NoSpreadHere=true

local function GetCone(wep)
    local cone = wep.Cone
    if not cone and type(wep.Primary) == "table" and type(wep.Primary.Cone) == "number" then
        cone = wep.Primary.Cone
    end
    if wep:GetClass() == "ose_turretcontroller" then return 0 end
    return cone or 0
end

require("dllz")
local currentseed, cmd2, seed = currentseed or 0, 0, 0
local wep, vecCone, valCone
PredictSpread = function(cmd,aimAngle)
    cmd2, seed = hl2_ucmd_getpr3diction(cmd)
    if cmd2 ~= 0 then
        currentseed = seed
    end
    wep = LocalPlayer():GetActiveWeapon()
    vecCone = Vector(0,0,0)
	if !(cne == Vector(0,0,0)) then
	return hl2_manipshot(currentseed or 0, (aimAngle or CL:GetAimVector():Angle()):Forward(), cne):Angle()
	end
    if wep and wep:IsValid() and type(wep.Initialize) == "function" then
        valCone = GetCone(wep)
        if( tonumber( valCone ) ) then
        vecCone = Vector( -valCone, -valCone, -valCone )
        elseif( type( valCone ) == "Vector" ) then
        vecCone = -1 * valCone
        end
	end
	if wep and wep:IsValid() then
	if wep:GetClass() == "weapon_smg1" then
	vecCone = Vector(-0.04362,-0.04362,-0.04362)
	elseif wep:GetClass() == "weapon_pistol" then
	vecCone = Vector( -0.0100, -0.0100, -0.0100 )
	elseif wep:GetClass() == "weapon_ar2" then
	vecCone = Vector( -0.02618, -0.02618, -0.02618 )
	elseif wep:GetClass() == "weapon_shotgun" then
	vecCone = Vector( -0.08716, -0.08716, -0.08716 )
	elseif wep:GetClass() == "weapon_iceaxe" then
	vecCone = Vector(-0.15,-0.15,-0.15)
	elseif wep:GetClass() == "weapon_sniper" then
	vecCone = Vector(-0.01,-0.01,0)
	elseif wep:GetClass() == "weapon_hmg1" then
	vecCone = Vector(-0.07,-0.07,-0.07)
	elseif wep:GetClass() == "weapon_smg2" then
	vecCone = Vector(-0.07,-0.07,-0.07)
	elseif wep:GetClass() == "weapon_ar1" then
	vecCone = Vector(-0.07,-0.07,0)
	elseif wep:GetClass() == "weapon_bsmg1" then
	vecCone = Vector(-0.04362,-0.04362,-0.04362)
	elseif wep:GetClass() == "mill_deagle" then
	vecCone = Vector(-0.5,-0.5,-0.5)
	elseif wep:GetClass() == "weapon_para" then
	vecCone = Vector(-0.05,-0.05,0)
	elseif wep:GetClass() == "awp" then
	vecCone = Vector(-0.05,-0.05,0) * LocalPlayer():GetActiveWeapon().xhair.loss
	if LocalPlayer():Crouching() then
	vecCone = vecCone * .95
	end
	if !LocalPlayer():IsOnGround() then
	vecCone = vecCone * 20
	end
	elseif wep:GetClass() == "g3sg1" then
	vecCone = Vector(-0.015,-0.015,0) * LocalPlayer():GetActiveWeapon().xhair.loss
	if LocalPlayer():Crouching() then
	vecCone = vecCone * .95
	end
	if !LocalPlayer():IsOnGround() then
	vecCone = vecCone * 20
	end
	elseif wep:GetClass() == "scout" then
	vecCone = Vector(-0.05,-0.05,0) * LocalPlayer():GetActiveWeapon().xhair.loss
	if LocalPlayer():Crouching() then
	vecCone = vecCone * .95
	end
	if !LocalPlayer():IsOnGround() then
	vecCone = vecCone * 20
	end
	elseif wep:GetClass() == "sg550" then
	vecCone = Vector(-0.004,-0.004,0) * LocalPlayer():GetActiveWeapon().xhair.loss
	if LocalPlayer():Crouching() then
	vecCone = vecCone * .95
	end
	if !LocalPlayer():IsOnGround() then
	vecCone = vecCone * 20
	end
	end
	end
	if vH.nospread == 4 then
	return hl2_manipshot(currentseed or 0, (aimAngle or CL:GetAimVector():Angle()):Forward(), -spread):Angle()
	else
	return hl2_manipshot(currentseed or 0, (aimAngle or CL:GetAimVector():Angle()):Forward(), vecCone):Angle()
	end
end
else
print("cant find dec0")
PredictSpread = function(cmd,aimAngle)
return aimAngle
end
end
local function changenorecval()
if vH.norecval > 101 then
vH.norecval = 1
else
vH.norecval = vH.norecval + 1
end
end
local dontaim = {"npc_hunter","npc_dog","npc_monk","npc_alyx","npc_mossman","npc_barney","npc_eli","npc_gman","npc_citizen","npc_turret_floor","npc_grenade_frag","rebelturret","npc_vortigaunt","npc_barnacle","npc_barnacle_tongue_tip","npc_kleiner","npc_satchel","npc_rollermine"}
local function changepredval()
if vH.valpred > 5 then
vH.valpred = 0
else
vH.valpred = vH.valpred + 0.1
end
end

local function smoothens(input,input2)
if vH.smoother == 0 then
return input2
else
		local view2 = Angle(0,0,0)
		--[[
		view2.p = math.ApproachAngle( input.p, input2.p, vH.smoother)
		view2.y = math.ApproachAngle( input.y, input2.y, vH.smoother)
		]]
		view2 = LerpAngle( vH.smoother, input, input2)
		return view2
end
end
local function box( e )
local lr
local tbtm
if vH.box == 1 then
lr = 2
tbtm = 2
elseif vH.box == 2 then
lr = 4
tbtm = 2.5
elseif vH.box == 3 then
lr = 2
tbtm = 2
else
lr = 2
tbtm = 2
end
	local ply, pos = LocalPlayer(), nil
	local center = e:LocalToWorld( e:OBBCenter() )
	local min, max = e:OBBMins(), e:OBBMaxs()
	local dim = max - min
	local z = max + min
	local frt	= ( e:GetForward() ) * ( dim.y / 2 )
	local rgt	= ( e:GetRight() ) * ( dim.x / lr )
	local top	= ( e:GetUp() ) * ( dim.z / tbtm )
	local bak	= ( e:GetForward() * -1 ) * ( dim.y / 2 )
	local lft	= ( e:GetRight() * -1 ) * ( dim.x / lr )
	local btm	= ( e:GetUp() * -1 ) * ( dim.z / tbtm )
	local d, v = math.Round( e:GetPos():Distance( ply:GetShootPos() ) )
	v = d / 30
	
	pos = e:LocalToWorld( top + top ) + Vector( 0, 0, v + 10 )
	if ( e:IsWeapon() ) then pos = e:LocalToWorld( e:OBBCenter() ) end
	
	local FRT 	= center + frt + rgt + top; FRT = FRT:ToScreen()
	local BLB 	= center + bak + lft + btm; BLB = BLB:ToScreen()
	local FLT	= center + frt + lft + top; FLT = FLT:ToScreen()
	local BRT 	= center + bak + rgt + top; BRT = BRT:ToScreen()
	local BLT 	= center + bak + lft + top; BLT = BLT:ToScreen()
	local FRB 	= center + frt + rgt + btm; FRB = FRB:ToScreen()
	local FLB 	= center + frt + lft + btm; FLB = FLB:ToScreen()
	local BRB 	= center + bak + rgt + btm; BRB = BRB:ToScreen()
	
	pos = pos:ToScreen()
	
	local maxX = math.max( FRT.x,BLB.x,FLT.x,BRT.x,BLT.x,FRB.x,FLB.x,BRB.x )
	local minX = math.min( FRT.x,BLB.x,FLT.x,BRT.x,BLT.x,FRB.x,FLB.x,BRB.x )
	local maxY = math.max( FRT.y,BLB.y,FLT.y,BRT.y,BLT.y,FRB.y,FLB.y,BRB.y)
	local minY = math.min( FRT.y,BLB.y,FLT.y,BRT.y,BLT.y,FRB.y,FLB.y,BRB.y )
	
	return maxX, minX, maxY, minY
end

aimmodels = {
        ["models/combine_scanner.mdl"] = "Scanner.Body",
        ["models/hunter.mdl"] = "MiniStrider.body_joint",
        ["models/combine_turrets/floor_turret.mdl"] = "Barrel",
        ["models/dog.mdl"] = "Dog_Model.Eye",
        ["models/antlion.mdl"] = "Antlion.Body_Bone",
        ["models/antlion_guard.mdl"] = "Antlion_Guard.Body",
        ["models/antlion_worker.mdl"] = "Antlion.Head_Bone",
        ["models/zombie/fast_torso.mdl"] = "ValveBiped.HC_BodyCube",
        ["models/zombie/fast.mdl"] = "ValveBiped.HC_BodyCube",
        ["models/headcrabclassic.mdl"] = "HeadcrabClassic.SpineControl",
        ["models/headcrabblack.mdl"] = "HCBlack.body",
        ["models/headcrab.mdl"] = "HCFast.body",
        ["models/zombie/poison.mdl"] = "ValveBiped.Headcrab_Cube1",
        ["models/zombie/classic.mdl"] = "ValveBiped.HC_Body_Bone",
        ["models/zombie/classic_torso.mdl"] = "ValveBiped.HC_Body_Bone",
        ["models/zombie/zombie_soldier.mdl"] = "ValveBiped.HC_Body_Bone",
        ["models/combine_strider.mdl"] = "Combine_Strider.Body_Bone",
        ["models/lamarr.mdl"] = "HeadcrabClassic.SpineControl"
}
local bones = {
	// Main body
	{ S = "ValveBiped.Bip01_Head1", E = "ValveBiped.Bip01_Neck1" },
	{ S = "ValveBiped.Bip01_Neck1", E = "ValveBiped.Bip01_Spine4" },
	{ S = "ValveBiped.Bip01_Spine4", E = "ValveBiped.Bip01_Spine2" },
	{ S = "ValveBiped.Bip01_Spine2", E = "ValveBiped.Bip01_Spine1" },
	{ S = "ValveBiped.Bip01_Spine1", E = "ValveBiped.Bip01_Spine" },
	{ S = "ValveBiped.Bip01_Spine", E = "ValveBiped.Bip01_Pelvis" },
	
	// Left Arm
	{ S = "ValveBiped.Bip01_Spine2", E = "ValveBiped.Bip01_L_UpperArm" },
	{ S = "ValveBiped.Bip01_L_UpperArm", E = "ValveBiped.Bip01_L_Forearm" },
	{ S = "ValveBiped.Bip01_L_Forearm", E = "ValveBiped.Bip01_L_Hand" },
	
	// Right Arm
	{ S = "ValveBiped.Bip01_Spine2", E = "ValveBiped.Bip01_R_UpperArm" },
	{ S = "ValveBiped.Bip01_R_UpperArm", E = "ValveBiped.Bip01_R_Forearm" },
	{ S = "ValveBiped.Bip01_R_Forearm", E = "ValveBiped.Bip01_R_Hand" },
	
	// Left leg
	{ S = "ValveBiped.Bip01_Pelvis", E = "ValveBiped.Bip01_L_Thigh" },
	{ S = "ValveBiped.Bip01_L_Thigh", E = "ValveBiped.Bip01_L_Calf" },
	{ S = "ValveBiped.Bip01_L_Calf", E = "ValveBiped.Bip01_L_Foot" },
	{ S = "ValveBiped.Bip01_L_Foot", E = "ValveBiped.Bip01_L_Toe0" },
	
	// Right leg
	{ S = "ValveBiped.Bip01_Pelvis", E = "ValveBiped.Bip01_R_Thigh" },
	{ S = "ValveBiped.Bip01_R_Thigh", E = "ValveBiped.Bip01_R_Calf" },
	{ S = "ValveBiped.Bip01_R_Calf", E = "ValveBiped.Bip01_R_Foot" },
	{ S = "ValveBiped.Bip01_R_Foot", E = "ValveBiped.Bip01_R_Toe0" },
}

local function boneesp( e,drawcolor )
	--[[if ( !e:IsPlayer() ) then return end
	if drawcolor then
	surface.SetDrawColor( drawcolor )
	else
	surface.SetDrawColor( 0, 255, 0, 255 )
	end
	for k, v in pairs( bones ) do
		local sPos, ePos = e:GetBonePosition( e:LookupBone( v.S ) ):ToScreen(), e:GetBonePosition( e:LookupBone( v.E ) ):ToScreen()
		
		surface.DrawLine( sPos.x, sPos.y, ePos.x, ePos.y )
	end]]
end
local aimmodels
aimmodels = {
        ["models/combine_scanner.mdl"] = "Scanner.Body",
        ["models/hunter.mdl"] = "MiniStrider.body_joint",
        ["models/combine_turrets/floor_turret.mdl"] = "Barrel",
        ["models/dog.mdl"] = "Dog_Model.Eye",
        ["models/antlion.mdl"] = "Antlion.Body_Bone",
        ["models/antlion_guard.mdl"] = "Antlion_Guard.Body",
        ["models/antlion_worker.mdl"] = "Antlion.Head_Bone",
        ["models/zombie/fast_torso.mdl"] = "ValveBiped.HC_BodyCube",
        ["models/zombie/fast.mdl"] = "ValveBiped.HC_BodyCube",
        ["models/headcrabclassic.mdl"] = "HeadcrabClassic.SpineControl",
        ["models/headcrabblack.mdl"] = "HCBlack.body",
        ["models/headcrab.mdl"] = "HCFast.body",
        ["models/zombie/poison.mdl"] = "ValveBiped.Headcrab_Cube1",
        ["models/zombie/classic.mdl"] = "ValveBiped.HC_Body_Bone",
        ["models/zombie/classic_torso.mdl"] = "ValveBiped.HC_Body_Bone",
        ["models/zombie/zombie_soldier.mdl"] = "ValveBiped.HC_Body_Bone",
        ["models/combine_strider.mdl"] = "Combine_Strider.Body_Bone",
        ["models/lamarr.mdl"] = "HeadcrabClassic.SpineControl"
}
local PredictWeapons = {
		["weapon_crossbow"] = 3110,
	}

local function WeaponPrediction( e, pos )
	local ply = LocalPlayer()
	if ( ValidEntity( e ) && ( type( e:GetVelocity() ) == "Vector" ) ) then
	if ValidEntity(ply:GetActiveWeapon()) then
		local dis, wep = e:GetPos():Distance( ply:GetPos() ), ply:GetActiveWeapon():GetClass()
		if ( wep && PredictWeapons[ wep ]  ) then
			local t = (dis / 3500) + 0.05
					local mul = 0.0075
					local pos = ( pos + e:GetVelocity() * t )
			pos = pos - (e:GetVelocity() * mul)
			local crossbowspeed = (LocalPlayer():GetCurrentCommand():GetViewAngles()):Forward() * 3500
			local time2crossbow = (pos:Length() - LocalPlayer():GetPos():Length() )/(((crossbowspeed):Length()) - ((e:GetVelocity()):Length()))
			pos.z = pos.z
			return pos
		end
	end
	end
	return pos
end
local function prediction( tar, compensate )
	local ply = LocalPlayer()
		local tarFrames, plyFrames = ( FrameTime() / 25 ), ( FrameTime() / 66 )
		return compensate + ( ( tar:GetVelocity() * ( tarFrames ) ) - ( ply:GetVelocity() * ( plyFrames ) ) )
		--return compensate + tar:GetVelocity() * (1/66) - LocalPlayer():GetVelocity() * (1/66)
end
local function HeadPos(ply) 
    if ValidEntity(ply) then 
if (ply:GetClass()=="npc_tripmine") && (ply:GetClass()=="npc_satchel") && (ply:GetClass()=="npc_grenade_frag") then
return false
end
local pos
local usingAttachments
	if ( ply:GetAttachment( ply:LookupAttachment( "eyes" ) ) ) then
		pos = ply:GetAttachment( ply:LookupAttachment( "eyes" ) ).Pos;
	elseif ( ply:GetAttachment( ply:LookupAttachment( "forward" ) ) ) then
		pos = ply:GetAttachment( ply:LookupAttachment("forward") ).Pos;
	elseif ( ply:GetAttachment( ply:LookupAttachment( "head" ) ) ) then
		pos = ply:GetAttachment( ply:LookupAttachment( "head" ) ).Pos;
	else
	local bone = (aimmodels[ ply:GetModel() ] or "ValveBiped.Bip01_Head1")
	local hbone = ply:LookupBone(bone) 
        pos = ply:GetBonePosition(hbone) 
	end
	return WeaponPrediction(ply,prediction(ply,pos))
    else return end 
end
local function Visible(ply) 
    local trace = {start = LocalPlayer():GetShootPos(),endpos = HeadPos(ply),filter = {LocalPlayer(), ply}} 
    local tr = util.TraceLine(trace) 
	local u = LocalPlayer():GetCurrentCommand( )
	if IsPenetrable( tr ) then
	return true
	end
		if (u:GetButtons() & IN_ATTACK > 0) then
		--[[if tr.MatType == 87 then
		local trace2 = {start = (tr.HitPos*2),endpos = HeadPos(ply),filter = {LocalPlayer(), ply}} 
		local tr2 = util.TraceLine(trace) 
		if tr2.Fraction == 1 then 
        return true 
		else 
		local trace3 = {start = (tr.HitPos/2),endpos = HeadPos(ply),filter = {LocalPlayer(), ply}} 
		local tr3 = util.TraceLine(trace) 
		if tr3.Fraction == 1 then 
        return true 
		else 
        return false 
		end 
		end
	return true		
	end]]--
	--return true
	end
if tr.Fraction == 1 then 
return true 
else
	return false
end    
end
local tar = nil
local current = 1
local correctView = Angle( 0, 0, 0 )
local silent = Angle( 0, 0, 0 )
local view = Angle( 0, 0, 0 )
local SetViewAngles = _R["CUserCmd"].SetViewAngles
local function fovcheck(input,input2)
if (vH.fov/2) < 180 then
local angY = math.abs( math.NormalizeAngle( input.y - input2.y ) )
local angP = math.abs( math.NormalizeAngle( input.p - input2.p ) )
if angY < (vH.fov/2)+1 && angP < (vH.fov/2)+1 then
return true
else
return false
end
else
return true
end
end
local gmod_GetWeapons = _R['Player'].GetWeapons

local TGuns = {"weapon_ttt_c4", "weapon_ttt_knife", "weapon_ttt_phammer", "weapon_ttt_sipistol", "weapon_ttt_flaregun", "weapon_ttt_push", "weapon_ttt_radio", "weapon_ttt_teleport"}
local traitors = {}
local allocatedweapons = {}
local cleared = false
print("//		Traitors	//")
function CheckTraitors()
	if not GAMEMODE or not GAMEMODE.Name or not string.find(GAMEMODE.Name , "Trouble in Terror") then return end
	
	for k , pl in ipairs(player.GetAll()) do
		if pl != LocalPlayer() then
			for _ , wep in pairs(gmod_GetWeapons(pl)) do
				if table.HasValue(TGuns , wep:GetClass()) and not table.HasValue(traitors , pl) and not table.HasValue(allocatedweapons , wep) and not pl:IsDetective() then
					chat.AddText(Color(50 , 205 , 50) , "[vHGmod] " ,  Color(235 , 235 , 235) , string.format("Player %s has collected traitor weapon %s" , pl:Nick() , wep:GetClass()) )
					table.insert(traitors,  pl)
					table.insert(allocatedweapons , wep)
					cleared = false
				end
			end
		end
		if table.HasValue(traitors , pl) and !( pl:Health() > 0 or pl:GetMoveType() != MOVETYPE_OBSERVER ) then
			chat.AddText(Color(50 , 205 , 50) , "[vHGmod] " ,  Color(235 , 235 , 235) , string.format("Traitor %s has died" , pl:Nick()))
			for a , b in pairs(traitors) do
				if b == pl then
					traitors[a] = nil
				end
			end
		end
	end
end

hook.Add("Think" , CheckTraitors)

local function checkteam(pl)
if string.find(team.GetName(pl:Team()),"spec") then
return false
end
if vH.dontaimteam == 1 then
if string.find(GAMEMODE.Name , "Trouble in Terror") then
if traitors[LocalPlayer()] then
if traitors[ply] then
return false
else
return true
end
else
if traitors[ply] then
return true
else
return false
end
end
else
if LocalPlayer():Team() == pl:Team() then
return false
else
return true
end
end
else
return true
end
end
local cppweaps = {}
cppweaps["weapon_357"] = true
cppweaps["weapon_smg1"] = true
cppweaps["weapon_ar2"] = true
cppweaps["weapon_shotgun"] = true
cppweaps["weapon_pistol"] = true
cppweaps["weapon_crossbow"] = true
cppweaps["weapon_rpg"] = true
local cppweapsrec = {}
cppweapsrec["weapon_357"] = 0.8
cppweapsrec["weapon_smg1"] = 1
cppweapsrec["weapon_ar2"] = 1.03
cppweapsrec["weapon_shotgun"] = 1
cppweapsrec["weapon_pistol"] = 1
cppweapsrec["weapon_crossbow"] = 1
print("//		Aim shit	//")
local function anglepunch()
if (!(LocalPlayer():GetActiveWeapon() == nil) && ValidEntity(LocalPlayer():GetActiveWeapon())) then
if cppweaps[LocalPlayer():GetActiveWeapon():GetClass()] then
return (((LocalPlayer():GetPunchAngle( )) or Angle(0,0,0))*(cppweapsrec[LocalPlayer():GetActiveWeapon():GetClass()] or 0.8))
else
return Angle(0,0,0)
end
else
return Angle(0,0,0)
end
end
local function validtarget(entz)
if !ValidEntity(entz) then return false end
for k,v in pairs(dontaim) do
if entz:GetClass() == v then return false end
end
if entz:IsPlayer() then if checkteam(entz) then else return false end end
if !(entz:IsPlayer() or entz:IsNPC()) then return false end
if entz == LocalPlayer() then return false end
if !Visible(entz) then return false end
if entz:IsPlayer() then if !(entz:Alive()) then return false end end
if entz:GetMoveType() == MOVETYPE_NONE then return false end
return true
end
local function GetMeta(name)
	return table.Copy(_R[name] or {})
end
local VecM = GetMeta("Vector")
local function get(a,b)
return math.deg(math.acos(VecM["Dot"](a, b)))
end
local function FindTarget()
	local ply = LocalPlayer()
	if !ValidEntity(ply) then return end
	local maxAng = 5000
	local aimVec, shootPos = ply:GetAimVector(), ply:GetShootPos()
	local targets
	if vH.trgetmet == 1 then
	targets = ents.GetAll()
	else
	targets = player.GetAll()
	end
	if vH.trgetmet == 1 then
	for i, ent in pairs(ents.GetAll()) do
		if validtarget(ent) == false then
			targets[i] = nil
		end
	end
	else
	for i, ent in pairs(player.GetAll()) do
		if validtarget(ent) == false then
			targets[i] = nil
		end
	end
	end
	local closestTarget, lowestAngle = _, maxAng
	for _, target in pairs(targets) do
			local targetPos = HeadPos(target)
			local angle = get((correctView):Forward(), (targetPos - shootPos):GetNormal())

			if angle < lowestAngle then
				lowestAngle = angle
				closestTarget = target
			end
	end
	if closestTarget then
	target = closestTarget
	return closestTarget
	end
	return false
end

local function validtarget2(entz)
if !ValidEntity(entz) then return false end
if !(entz:IsPlayer() or entz:IsNPC()) then return false end
if entz == LocalPlayer() then return false end
if entz:IsNPC() then 
if entz.IsDead == true then
return false
end
end
if entz:IsPlayer() then if entz:Health() < 1 then return false end end
if entz:IsPlayer() then if !checkteam(entz) then return false end end
if entz:IsNPC() then if entz.IsDead == true then return false end end
return true
end

local function Bot( u )
		if input.IsKeyDown( KEY_SPACE ) then
			if LocalPlayer():IsOnGround() then
			RunConsoleCommand("+Jump") 
			timer.Create("Bhop",0.01, 0 ,function() RunConsoleCommand("-Jump") end)
			end
		end
		local ply = LocalPlayer()
		if LocalPlayer():Alive() then
		local ply = LocalPlayer()
		local mouse = Angle(u:GetMouseY() * GetConVarNumber("m_pitch"), u:GetMouseX() * -GetConVarNumber("m_yaw"),0) or Angle(0,0,0)
        correctView = correctView + mouse
		end
		correctView.p = math.Clamp(math.NormalizeAngle( correctView.p ),-89,89)
		correctView.y = math.NormalizeAngle( correctView.y )
		local ply = LocalPlayer()
		if vH.nospread == 2 then
			view = PredictSpread(u,correctView)
		else
			view = correctView
		end
		if (vH.nospread == 3) or (vH.nospread == 4) then
		if (u:GetButtons() & IN_ATTACK > 0) then
		--if ( ply:GetActiveWeapon():Clip1() >= 1 ) then
			view = PredictSpread(u,view)
		--end
		end
		end
		if (u:GetButtons() & IN_ATTACK > 0) then
		--if ( ply:GetActiveWeapon():Clip1() >= 1 ) then
			view = view-anglepunch()
		--end
		else
		if !(LocalPlayer():GetMoveType() == MOVETYPE_LADDER or LocalPlayer():GetMoveType() == MOVETYPE_NOCLIP) then
		if !(( u:KeyDown( IN_ATTACK | IN_ATTACK2 | IN_USE ) )) then
		if vH.antiaim == 1 then
		view.p = view.p
		view = view + Vector(180,180,180)
		else
		view = view
		end
		end
		end
		end
		view.p = math.NormalizeAngle( view.p )
		view.y = math.NormalizeAngle( view.y )
		local x, y, z = view.p, view.y, view.r
		--cheat.SetViewAngles( u, Vector(x,y,z) )
		SetViewAngles( u, view )
		if vH.aimkey == 1 then
		if (u:GetButtons() & IN_ATTACK > 0) then
		--if ( ply:GetActiveWeapon():Clip1() >= 1 ) then
		else
		return end
		--else return end
		end
		if vH.aim==1 then else return end
		if ValidEntity(LocalPlayer():GetActiveWeapon()) then
		if vH.dontaimweaps[LocalPlayer():GetActiveWeapon():GetClass()] then return end
		else
		return
		end
		local trget = FindTarget()
		if trget && ValidEntity(trget) then
		local targetheadpos = HeadPos(trget)
		local velocity = trget:GetVelocity() or Vector(0,0,0)
		local velocityplayer = ply:GetVelocity() or Vector(0,0,0)
		local ang
		local vec
		local targetpos = cheat.LagCompensation( targetheadpos, LocalPlayer():Ping() )
		ang = (((targetheadpos-(ply:GetShootPos())):Angle()))
		vec = (targetheadpos)
		if not fovcheck(ang,correctView) then return end
		if vH.silent == 0 then
		local angz = smoothens(correctView,ang)
		correctView = angz
		end
		if vH.autoshoot == 1 then
			RunConsoleCommand( "+attack" )
			timer.Simple( 0.05, function() RunConsoleCommand( "-attack" ) end )
		end
		if (vH.nospread == 1) or (vH.nospread == 2) then
			ang = PredictSpread(u,ang)
		end
		if (vH.nospread == 3) or (vH.nospread == 4) then
		if (u:GetButtons() & IN_ATTACK > 0) then
		--if ( ply:GetActiveWeapon():Clip1() >= 1 ) then
			ang = PredictSpread(u,ang)
		--end
		end
		end
		if (u:GetButtons() & IN_ATTACK > 0) then
		--if ( ply:GetActiveWeapon():Clip1() >= 1 ) then
			ang = ang-anglepunch()
		--end
		end
		if !(LocalPlayer():GetMoveType() == MOVETYPE_LADDER or LocalPlayer():GetMoveType() == MOVETYPE_NOCLIP) then
		if !(( u:KeyDown( IN_ATTACK | IN_ATTACK2 | IN_USE ) )) then
		if vH.antiaim == 1 then
		ang = ang + Vector(180,180,180)
		else
		ang = ang
		end
		end
		end
		if vH.silent == 1 then
		local move = Vector(CmdM["GetForwardMove"](u), CmdM["GetSideMove"](u), 0)
		local norm = VecM["GetNormal"](move)
		local set = AngM["Forward"](VecM["Angle"](norm) + (ang - correctView)) * VecM["Length"](move)
		CmdM["SetForwardMove"](u, set.x)
		CmdM["SetSideMove"](u, set.y)
		end
		ang.p = math.NormalizeAngle(ang.p)
		ang.y = math.NormalizeAngle(ang.y)
		local x, y, z = ang.p, ang.y, ang.r
		--cheat.SetViewAngles( u, Vector(x,y,z) )
		SetViewAngles( u, ang )
		end
		end
hook.Add("CreateMove","nospreadnaim",Bot)
	local function NoRecoil( u, o )
		return { origin = o, angles = correctView}
	end
	hook.Add( "CalcView","lol", NoRecoil )

local varmenu = {}
varmenu.current = 1
varmenu.showmenu = 0
local radar = {}
function DrawFadingColorBoxradar(x,y,w,h,alpha,mode)
if mode== 2 then
	local calculater = h/100
	local calculate = h/200
	local calculate2 = h/200
		for i=0,h do
		surface.SetDrawColor( 200-i/calculate, 200-i/calculate, 200-i/calculate, alpha)
		surface.DrawLine( x, i+y, x+w, i+y )
		end
else
	local calculater = h/100
	local calculate = h/200
	local calculate2 = h/200
		for i=0,h do
		surface.SetDrawColor( i/calculate, i/calculate, i/calculate, alpha)
		surface.DrawLine( x, i+y, x+w, i+y )
		end
end
end
function DrawRotatingCrosshair(x,y,time,length,gap)
    surface.DrawLine(
        x + (math.sin(math.rad(time)) * length),
        y + (math.cos(math.rad(time)) * length),
        x + (math.sin(math.rad(time)) * gap),
        y + (math.cos(math.rad(time)) * gap)
    )
end
print("//		Radar		//")
local function drawbradar()
surface.SetDrawColor( 0, 0, 0, 255 ); -- 68,68,68,255
surface.DrawRect( 0, 0, 200, 200 ); 
DrawFadingColorBoxradar(0,0,200,30,255,2)
DrawFadingColorBoxradar(0,200-31,200,30,255,1)
surface.SetDrawColor( 90, 106, 79, 255 ); 
surface.DrawOutlinedRect( 0, 0, 200, 200 ); 
surface.DrawLine( 10, 100, 190, 100 ); 
surface.DrawLine( 100, 10, 100, 190 );
		local time = (CurTime()*2) * -180
		DrawRotatingCrosshair(100,100,time,90,0)
--Default values
radar.w = 200
radar.h = 200
radar.x = 0
radar.y = 0
radar.alphascale = 0.6
radar.bgcolor = Color(255,0,0,255)
radar.fgcolor = Color(0,0,255,255)
radar.dangercolour = Color(220,0,0,255)
radar.dangerblipcolour = Color(255,255,0,255)
radar.screendetail = 64
radar.screenrotation = 0
radar.hazardmode = false    --doesnt work

radar.radius = 5000

radar.player_show = true
radar.player_color = Color(0,150,255,255)
surface.CreateFont("Arial",64,400,false,false,"RadarPlayerLabel")
radar.player_fontcolor = Color(255,255,255,255)
radar.player_showname = true
radar.player_showhealth = true
radar.player_showarmor = false --TO DO
radar.player_showammo = true


radar.scanfor = {"player", "blastfungus", "rpg_missile", "crossbow_bolt", "npc_", "sent_", "prop_vehicle_"}		-- What should the radar look for?  Accepts partial names.
radar.dangerous = {"sent_nuke_missile", "sent_nuke_detpack"}    --doesnt work

radar.bgcolorbak = radar.bgcolor
radar.fgcolorbak = radar.fgcolor
radar.player_colorbak = radar.player_color


local color_ascale = function(col,scale) return Color(col.r,col.g,col.b,col.a*scale) end

	local ETable = {}
	local PulseRadar = false

	local lpl = LocalPlayer()
	
	
	if ( radar.player_show ) then
	local vertices = {}
	for i=1,radar.screendetail do
		local shift = math.fmod(CurTime()*radar.screenrotation,360)
		local sizescale = 1
		local tab = {}
		tab.x = radar.x+radar.w/2 + math.cos(math.Deg2Rad((360/radar.screendetail)*i+shift)) * radar.w/2 * sizescale
		tab.y = radar.y+radar.h/2 + math.sin(math.Deg2Rad((360/radar.screendetail)*i+shift)) * radar.h/2 * sizescale
		tab.u = 0
		tab.v = 0
		table.insert(vertices,tab)
	end
	local players = {}

	for k,ent in pairs(player.GetAll()) do

			if ent:IsValid() then
				local type = ent:GetClass()

				for k, v in ipairs(radar.scanfor) do
					if string.find(type,v) then
						table.insert(players,ent)
					end
				end
			end
		end
		for i, pl in ipairs(players) do
			local cx = radar.x+radar.w/2
			local cy = radar.y+radar.h/2
			local vdiff = pl:GetPos()-lpl:GetPos()
			local dummy = nil
				if pl:IsPlayer() then
					if ( pl:Alive() and lpl~=pl ) then
						local px = (vdiff.x/radar.radius)
						local py = (vdiff.y/radar.radius)
						local z = math.sqrt( px*px + py*py )
						local phi = math.Deg2Rad( math.Rad2Deg( math.atan2( px, py ) ) - math.Rad2Deg( math.atan2( lpl:GetAimVector().x, lpl:GetAimVector().y ) ) - 90 )
						px = math.cos(phi)*z
						py = math.sin(phi)*z
						draw.RoundedBox( 0, math.Clamp(cx+px*radar.w/2-4,0,190), math.Clamp(cy+py*radar.h/2-4,0,190), 8, 8, Color(0,100,255,255) )
						surface.SetDrawColor( 0,0,0,255 )
						surface.DrawOutlinedRect( math.Clamp(cx+px*radar.w/2-4,0,190), math.Clamp(cy+py*radar.h/2-4,0,190), 8, 8)
					end
				end
				if ((not pl:IsPlayer()) and pl:IsValid() ) then

				    local isDangerous = false
					if ( radar.hazardmode ) then
						for k,v in ipairs(radar.dangerous) do
						    if (pl:GetClass() == v) then
						        table.insert(ETable,pl)
						        isDangerous = true
							end
						end
					end
					
					local px = (vdiff.x/radar.radius)
					local py = (vdiff.y/radar.radius)
					local z = math.sqrt( px*px + py*py )
					local phi = math.Deg2Rad( math.Rad2Deg( math.atan2( px, py ) ) - math.Rad2Deg( math.atan2( lpl:GetAimVector().x, lpl:GetAimVector().y ) ) - 90 )
					px = math.cos(phi)*z
					py = math.sin(phi)*z

					if (isDangerous == false) then
						draw.RoundedBox( 0, math.Clamp(cx+px*radar.w/2-4,0,190), math.Clamp(cy+py*radar.h/2-4,0,190), 8, 8, Color(255,255,255,255) )
						surface.SetDrawColor( 0,0,0,255 )
						surface.DrawOutlinedRect( math.Clamp(cx+px*radar.w/2-4,0,190), math.Clamp(cy+py*radar.h/2-4,0,190), 8, 8)
					if pl:IsNPC() then
					if validtargetesp(pl) then
						if( Visible(pl) ) then
                        drawColor = Color( 255, 0, 0, 255 )
						else
                        drawColor = Color( 0, 255, 255, 255 )
						end
						draw.RoundedBox( 0, math.Clamp(cx+px*radar.w/2-4,0,190), math.Clamp(cy+py*radar.h/2-4,0,190), 8, 8, drawColor)
						surface.SetDrawColor( 0,0,0,255 )
						surface.DrawOutlinedRect( math.Clamp(cx+px*radar.w/2-4,0,190), math.Clamp(cy+py*radar.h/2-4,0,190), 8, 8)
					end
					end
					end


					if radar.player_showname then

						local nametag = ""
						if string.find(pl:GetClass(),"blastfungus") then nametag = ""
						elseif string.find(pl:GetClass(),"npc_") then nametag = string.sub(pl:GetClass(),5)
						elseif string.find(pl:GetClass(),"sent_") then nametag = string.sub(pl:GetClass(),6)
						elseif string.find(pl:GetClass(),"prop_vehicle_") then nametag = string.sub(pl:GetClass(),14)
						else nametag = pl:GetClass()
						end

						local nametable = string.Explode("_",nametag)
						nametag = table.concat(nametable," ")
						local nametag1 = string.sub(nametag,0,1)
						local nametag2 = string.sub(nametag,2)
						nametag1 = string.upper(nametag1)
						nametag = nametag1..nametag2


					end
				end
   			end
	 	end
   		local count = table.Count(ETable)
   		
   		if ( count > 0 ) then
   		for k,pl in ipairs(ETable) do
   			local cx = radar.x+radar.w/2
			local cy = radar.y+radar.h/2
			local vdiff = pl:GetPos()-lpl:GetPos()
			
   			local px = (vdiff.x/radar.radius)
			local py = (vdiff.y/radar.radius)
			local z = math.sqrt( px*px + py*py )
			local phi = math.Deg2Rad( math.Rad2Deg( math.atan2( px, py ) ) - math.Rad2Deg( math.atan2( lpl:GetAimVector().x, lpl:GetAimVector().y ) ) - 90 )
			px = math.cos(phi)*z
			py = math.sin(phi)*z
						draw.RoundedBox( 0, math.Clamp(cx+px*radar.w/2-4,0,190), math.Clamp(cy+py*radar.h/2-4,0,190), 8, 8, color_ascale(radar.player_color,255) )
						surface.SetDrawColor( 0,0,0,255 )
						surface.DrawOutlinedRect( math.Clamp(cx+px*radar.w/2-4,0,190), math.Clamp(cy+py*radar.h/2-4,0,190), 8, 8)
		end
			
			radar.bgcolor = Color(255,255,255,0)
			radar.fgcolor = Color(60,60,60,100)
			
			PulseRadar = true
		end
end
print("//		ESP		//")
local function drawesp()
                    local textData = {} 
                    textData.pos = {} 
                    textData.pos[1] = ScrW()-20; 
                    textData.pos[2] = 10; 
                    textData.color = drawColor; 
                    textData.text = "vHGmod 0.5 spread: "..tostring(spread) 
                    textData.font = "DefaultFixed"; 
                    textData.xalign = TEXT_ALIGN_RIGHT; 
                    textData.yalign = TEXT_ALIGN_CENTER; 
                    draw.Text( textData ); 
if vH.esp == 1 then
        for k, v in pairs(ents.GetAll()) do 
            if( ValidEntity(v) and v ~= LocalPlayer() ) then
                if( v:IsNPC() ) then 
				if validtargetesp(v) then
                    local drawColor = Color(255, 255, 255, 255); 
                    local drawPosit = v:GetPos():ToScreen(); 
                    local vis = ""
                    if( Visible(v) ) then 
						vis = "Visible"
                        drawColor = Color( 255, 0, 0, 255 ); 
                    else 
						vis = "Invisible"
                        drawColor = Color( 0, 255, 255, 255 ); 
                    end
					surface.SetDrawColor(drawColor)
					local head = HeadPos(v):ToScreen()
					local maxX, minX, maxY, minY = box(v)
					local lol = maxY-minY
					local lol2 = maxX-minX
					local minz, maxz = v:OBBMins(), v:OBBMaxs()
					minz = (v:GetPos()+minz):ToScreen()
					maxz = (v:GetPos()+maxz):ToScreen()
					if vH.box == 3 then
					local lol2 = maxX-minX
					local lol3 = lol2/2
					local plrpos = v:GetPos()+v:OBBCenter()
					local plrpos = plrpos:ToScreen()
					for i = 0,4 do
					surface.DrawOutlinedRect( plrpos.x-lol3-2+i, plrpos.y-lol3-2+i, lol2+2-(i*2),lol2+2-(i*2) )
					end
					surface.SetDrawColor(Color(0,0,0,255))
					surface.DrawOutlinedRect( plrpos.x-lol3-2+4, plrpos.y-lol3-2+4, lol2+2-8,lol2+2-8 )
					surface.DrawOutlinedRect( plrpos.x-lol3-2, plrpos.y-lol3-2, lol2+2,lol2+2 )
					surface.SetDrawColor(drawColor)
					elseif vH.box == 4 then 
					local plrpos = v:GetPos()+v:OBBCenter()
					local plrpos = plrpos:ToScreen()
					local lol2 = maxY-minY
					local lol3 = lol2/2
					surface.DrawOutlinedRect( plrpos.x-lol3, plrpos.y-lol3, lol2,lol2 )
					elseif vH.box == 5 then
					local minz, maxz = v:OBBMins(), v:OBBMaxs()
					local plrpos = v:GetPos()
					local drawColor2 = drawColor
					drawColor2.a = 0
					debugoverlay.Box(plrpos, minz, maxz, FrameTime()*1.5, drawColor2,true)
					else
					surface.DrawLine( maxX, maxY, maxX, minY )
					surface.DrawLine( maxX, minY, minX, minY )
					
					surface.DrawLine( minX, minY, minX, maxY )
					surface.DrawLine( minX, maxY, maxX, maxY )
					end
					
                    local textData = {} 
                     
                    textData.pos = {} 
                    textData.pos[1] = drawPosit.x; 
                    textData.pos[2] = maxY+10; 
                    textData.color = drawColor; 
                    textData.text = v:GetClass(); 
                    textData.font = "DefaultFixed"; 
                    textData.xalign = TEXT_ALIGN_CENTER; 
                    textData.yalign = TEXT_ALIGN_CENTER; 
                    draw.Text( textData ); 
                    textData.pos = {} 
                    textData.pos[1] = drawPosit.x; 
                    textData.pos[2] = maxY+25; 
                    textData.color = drawColor; 
                    textData.text = vis; 
                    textData.font = "DefaultFixed"; 
                    textData.xalign = TEXT_ALIGN_CENTER; 
                    textData.yalign = TEXT_ALIGN_CENTER; 
                    draw.Text( textData );
					end
					local targetheadpos = HeadPos(v)
					local targetheadpos = targetheadpos:ToScreen()
					surface.SetDrawColor(Color(255,0,0,255))
					surface.DrawLine( targetheadpos.x-10, targetheadpos.y, targetheadpos.x+10, targetheadpos.y )
					surface.DrawLine( targetheadpos.x, targetheadpos.y-10, targetheadpos.x, targetheadpos.y+10 )
					elseif( v:IsPlayer() and v:Health() > 0 and v:Alive() ) then 
                    local drawColor = team.GetColor(v:Team()); 
                    local drawPosit = v:GetPos():ToScreen(); 
                     
                    if( Visible(v) ) then 
                        drawColor.a = 255; 
                    else 
                        drawColor.r = 255 - drawColor.r; 
                        drawColor.g = 255 - drawColor.g; 
                        drawColor.b = 255 - drawColor.b; 
                    end 
                    surface.SetDrawColor(drawColor)
					
                    local textData = {} 
                    local maxX, minX, maxY, minY = box(v)
					local lol = maxY-minY
					surface.SetDrawColor(drawColor)
					if vH.box == 3 then
					local lol2 = maxX-minX
					local lol3 = lol2/2
					local plrpos = v:GetPos()+v:OBBCenter()
					local plrpos = plrpos:ToScreen()
					surface.SetDrawColor(drawColor)
					for i = 0,4 do
					surface.DrawOutlinedRect( plrpos.x-lol3-2+i, plrpos.y-lol3-2+i, lol2+2-(i*2),lol2+2-(i*2) )
					end
					surface.SetDrawColor(Color(0,0,0,255))
					surface.DrawOutlinedRect( plrpos.x-lol3-2+4, plrpos.y-lol3-2+4, lol2+2-8,lol2+2-8 )
					surface.DrawOutlinedRect( plrpos.x-lol3-2, plrpos.y-lol3-2, lol2+2,lol2+2 )
					surface.SetDrawColor(drawColor)
					elseif vH.box == 4 then 
					local plrpos = v:GetPos()+v:OBBCenter()
					local plrpos = plrpos:ToScreen()
					local lol2 = maxY-minY
					local lol3 = lol2/2
					surface.DrawOutlinedRect( plrpos.x-lol3, plrpos.y-lol3, lol2,lol2 )
					elseif vH.box == 5 then
					local minz, maxz = v:OBBMins(), v:OBBMaxs()
					local plrpos = v:GetPos()
					local drawColor2 = drawColor
					drawColor2.a = 0
					debugoverlay.Box(plrpos, minz, maxz, FrameTime()*1.5, drawColor2,true)
					else
					surface.DrawLine( maxX, maxY, maxX, minY )
					surface.DrawLine( maxX, minY, minX, minY )
					
					surface.DrawLine( minX, minY, minX, maxY )
					surface.DrawLine( minX, maxY, maxX, maxY )
					end
					
					if vH.namealign == 1 then
                    textData.pos = {} 
                    textData.pos[1] = drawPosit.x; 
                    textData.pos[2] = minY-40; 
                    textData.color = drawColor; 
                    textData.text = v:GetName(); 
                    textData.font = "DefaultFixed"; 
                    textData.xalign = TEXT_ALIGN_CENTER; 
                    textData.yalign = TEXT_ALIGN_CENTER; 
                    draw.Text( textData );
					if traitors[v] then
					textData.pos = {} 
                    textData.pos[1] = drawPosit.x; 
                    textData.pos[2] = minY-50; 
                    textData.color = drawColor; 
                    textData.text = "Traitor"; 
                    textData.font = "DefaultFixed"; 
                    textData.xalign = TEXT_ALIGN_CENTER; 
                    textData.yalign = TEXT_ALIGN_CENTER; 
                    draw.Text( textData );
					end
					else
					textData.pos = {} 
                    textData.pos[1] = drawPosit.x; 
                    textData.pos[2] = maxY+10; 
                    textData.color = drawColor; 
                    textData.text = v:GetName(); 
                    textData.font = "DefaultFixed"; 
                    textData.xalign = TEXT_ALIGN_CENTER; 
                    textData.yalign = TEXT_ALIGN_CENTER; 
                    draw.Text( textData );
					if traitors[v] then
					textData.pos = {} 
                    textData.pos[1] = drawPosit.x; 
                    textData.pos[2] = maxY+20; 
                    textData.color = drawColor; 
                    textData.text = "Traitor"; 
                    textData.font = "DefaultFixed"; 
                    textData.xalign = TEXT_ALIGN_CENTER; 
                    textData.yalign = TEXT_ALIGN_CENTER; 
                    draw.Text( textData );
					end
					end
					
					textData.pos[1] = drawPosit.x; 
                    textData.pos[2] = minY-30; 
                    textData.color = drawColor; 
                    textData.text = team.GetName(v:Team()); 
                    textData.font = "DefaultFixed"; 
                    textData.xalign = TEXT_ALIGN_CENTER; 
                    textData.yalign = TEXT_ALIGN_CENTER; 
					draw.Text( textData ); 
					
					textData.pos[1] = drawPosit.x; 
                    textData.pos[2] = minY-20; 
                    textData.color = drawColor; 
                    textData.text = v:SteamID(); 
                    textData.font = "DefaultFixed"; 
                    textData.xalign = TEXT_ALIGN_CENTER; 
                    textData.yalign = TEXT_ALIGN_CENTER; 
					draw.Text( textData ); 
					
					if v:IsAdmin() or v:IsSuperAdmin() or v:IsBot() then
					local admstring
					if v:IsAdmin() then
					admstring = "Admin"
					end
					if v:IsSuperAdmin() then
					admstring = "Super Admin"
					end
					if v:IsBot() then
					admstring = "Bot"
					end
					textData.pos[1] = drawPosit.x; 
                    textData.pos[2] = minY-10; 
                    textData.color = drawColor; 
                    textData.text = admstring; 
                    textData.font = "DefaultFixed"; 
                    textData.xalign = TEXT_ALIGN_CENTER; 
                    textData.yalign = TEXT_ALIGN_CENTER; 
					draw.Text( textData ); 
					end
					textData.pos[1] = minX-8; 
                    textData.pos[2] = minY+((maxY-minY)/2); 
                    textData.color = drawColor; 
                    textData.text = "HP: "..v:Health(); 
                    textData.font = "DefaultFixed"; 
                    textData.xalign = TEXT_ALIGN_RIGHT; 
                    textData.yalign = TEXT_ALIGN_CENTER; 
					draw.Text( textData ); 
					
					textData.pos[1] = maxX+8; 
                    textData.pos[2] = minY+((maxY-minY)/2); 
                    textData.color = drawColor; 
                    textData.text = "AP: "..v:Armor(); 
                    textData.font = "DefaultFixed"; 
                    textData.xalign = TEXT_ALIGN_LEFT; 
                    textData.yalign = TEXT_ALIGN_CENTER; 
					draw.Text( textData ); 
					
					local max_armor = 100; 
                     
                    if( v:Armor() > max_armor ) then 
                       max_armor = v:Armor(); 
                    end 
					local targetheadpos = HeadPos(v)
					local targetheadpos = targetheadpos:ToScreen()
					surface.SetDrawColor(Color(255,0,0,255))
					surface.DrawLine( targetheadpos.x-10, targetheadpos.y, targetheadpos.x+10, targetheadpos.y )
					surface.DrawLine( targetheadpos.x, targetheadpos.y-10, targetheadpos.x, targetheadpos.y+10 )
                    if v:GetActiveWeapon() then if ValidEntity(v:GetActiveWeapon()) then
					if v:GetActiveWeapon():GetClass() == "weapon_ak47" then
					draw.SimpleText( "b" , "CSKillIcons", drawPosit.x, maxY+35, drawColor, TEXT_ALIGN_CENTER, TEXT_ALIGN_LEFT, 1)
					elseif v:GetActiveWeapon():GetClass() == "weapon_para" then
					draw.SimpleText( "z" , "CSKillIcons", drawPosit.x, maxY+35, drawColor, TEXT_ALIGN_CENTER, TEXT_ALIGN_LEFT, 1)
					elseif v:GetActiveWeapon():GetClass() == "weapon_mp5" then
					draw.SimpleText( "x" , "CSKillIcons", drawPosit.x, maxY+35, drawColor, TEXT_ALIGN_CENTER, TEXT_ALIGN_LEFT, 1)
					elseif v:GetActiveWeapon():GetClass() == "weapon_m4" then
					draw.SimpleText( "w" , "CSKillIcons", drawPosit.x, maxY+35, drawColor, TEXT_ALIGN_CENTER, TEXT_ALIGN_LEFT, 1)
					elseif v:GetActiveWeapon():GetClass() == "weapon_glock" then
					draw.SimpleText( "c" , "CSKillIcons", drawPosit.x, maxY+35, drawColor, TEXT_ALIGN_CENTER, TEXT_ALIGN_LEFT, 1)
					elseif v:GetActiveWeapon():GetClass() == "weapon_tmp" then
					draw.SimpleText( "d" , "CSKillIcons", drawPosit.x, maxY+35, drawColor, TEXT_ALIGN_CENTER, TEXT_ALIGN_LEFT, 1)
					elseif v:GetActiveWeapon():GetClass() == "weapon_deagle" then
					draw.SimpleText( "f" , "CSKillIcons", drawPosit.x, maxY+35, drawColor, TEXT_ALIGN_CENTER, TEXT_ALIGN_LEFT, 1)
					elseif v:GetActiveWeapon():GetClass() == "weapon_pumpshotgun" then
					draw.SimpleText( "k" , "CSKillIcons", drawPosit.x, maxY+35, drawColor, TEXT_ALIGN_CENTER, TEXT_ALIGN_LEFT, 1)
					end
					end
					end
					if v:Alive() then
					if vH.box == 3 or vH.box == 4 then
					else
					local center = Vector( x,y, 0 )
                    local mx = max_armor; 
                    local mw = v:Armor(); 
                    local drw = mx / lol
                    local drawPosHealth = drawPosit; 
					surface.SetDrawColor(0,0,0,255)
					surface.DrawRect(maxX+2,minY-1,6,lol+2)
					surface.SetDrawColor(0,0,255,255)
					surface.DrawRect(maxX+3,minY-(mw/drw)+(mx/drw),4,mw/drw)
					local max_health = 100; 
                     
                    if( v:Health() > max_health ) then 
						max_health = v:Health(); 
                    end 
                    
                    local mx = max_health; 
                    local mw = v:Health(); 
                    local drw = mx / lol
                    local drawPosHealth = drawPosit; 
					surface.SetDrawColor(0,0,0,255)
					surface.DrawRect(minX-8,minY-1,6,lol+2)
					surface.SetDrawColor(255-(mw*2+50),mw*2+50,0,255)
					surface.DrawRect(minX-7,minY-(mw/drw)+(mx/drw),4,mw/drw)
					end
					end
	elseif v:GetClass() == "npc_tripmine" then
	local drawPosit = v:GetPos():ToScreen(); 
	local textData = {}
	textData.pos = {} 
    textData.pos[1] = drawPosit.x; 
    textData.pos[2] = drawPosit.y; 
    textData.color = Color(0,150,255); 
    textData.text = "S.L.A.M. !!!"; 
    textData.font = "DefaultFixed"; 
    textData.xalign = TEXT_ALIGN_CENTER; 
    textData.yalign = TEXT_ALIGN_CENTER; 
    draw.Text( textData );
	end
    end 
	end
	end
	end
	local function admintype(plys)
	local admintypez = ""
	if plys:IsAdmin() then
	admintypez = "Admin"
	end
	if plys:IsSuperAdmin() then
	admintypez = "Super Admin"
	end
	return admintypez
	end
local function adminsget()
local adminnum = 0
local lawl = 15
for k, plys in pairs(player.GetAll()) do
if plys:IsAdmin() then
adminnum = adminnum + 1
end
end
	    --surface.SetDrawColor( 90, 106, 79, 255 ); 
		--surface.DrawRect( ScrW()-200, 0, 200, 20*(adminnum+1)+1 ); 
		surface.SetDrawColor( 0, 0, 0, 255 ); -- 68, 68, 68, 255
		surface.DrawRect( ScrW()-199, 18, 200, 20*(adminnum+1)+1 ); 
				
		DrawFadingColorBoxradar(ScrW()-199,0,200,17,255,2)
		DrawFadingColorBoxradar(ScrW()-199,20*(adminnum+1)+1,200,17,255,1)
		
		surface.SetDrawColor( 75, 81, 71, 255 ); 
		draw.SimpleTextOutlined( "Admins", "Default", ScrW()-100, 16/2, Color( 180, 180, 180, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, Color( 0, 0, 0, 255 ) )
local lawl = 15
for k, plys in pairs(player.GetAll()) do
if plys:IsAdmin() then
adminnum = adminnum + 1
plyscolor = team.GetColor(plys:Team())
draw.SimpleText(plys:GetName().." ["..admintype(plys).."]", "TabLarge", ScrW()-190, lawl+5, plyscolor)
lawl = lawl + 10
end
end
surface.SetDrawColor( 90, 106, 79, 255 ); 
surface.DrawOutlinedRect( ScrW()-200, 0, 200, 20*(adminnum+1)); 
end
local function drawmenu()
surface.SetDrawColor( 255, 255, 255, 255 )
surface.DrawRect( 0, 0, 340, 300 )
	local calculate = 22/150
		for i=0,22 do
		surface.SetDrawColor( 150-i/calculate, 150-i/calculate, 150-i/calculate, 255)
		surface.DrawLine( 0, i, 340, i )
		end
	local calculate = 15/200
		for i=0,15 do
		surface.SetDrawColor( 200-(i/calculate)+20, 200-(i/calculate)+20, 200-(i/calculate)+20, 200)
		surface.DrawLine( 0, i+285, 340, i+285 )
		end
		--                            name                font     x    y          r     g   b    a        xalign             yalign          idk       r  g  b  a (outline)
		draw.SimpleTextOutlined( "vHGmod 0.5 Testens", "Default", 150, 11, Color( 180, 180, 180, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, Color( 0, 0, 0, 255 ) )
end
--drawmenu()
local function lol()
		--admin list
		if vH.admins == 1 then
		adminsget()
		end
		--esp
		if vH.esp == 1 then
		drawesp()
		end
		--menu
		if varmenu.showmenu == 1 then
	    --surface.SetDrawColor( 90, 106, 79, 255 ); 
		--surface.DrawRect( ScrW()/2-100, 0, 200, 16*10+1 ); 
		surface.SetDrawColor( 0, 0, 0, 255 ); -- 68,68,68,255
		surface.DrawRect( ScrW()/2-100, 15, 200, 16*9-3 ); 
		DrawFadingColorBoxradar(ScrW()/2-100,0,200,30,255,2)
		DrawFadingColorBoxradar(ScrW()/2-100,16*10-30,200,30,255,1)
		surface.SetDrawColor( 0, 100, 200, 255 ); 
		if varmenu.current == 1 then
		surface.DrawRect(ScrW()/2-99,16,198,16); 
		elseif varmenu.current == 2 then
		surface.DrawRect(ScrW()/2-99,16*2,198,16); 
		elseif varmenu.current == 3 then
		surface.DrawRect(ScrW()/2-99,16*3,198,16); 
		elseif varmenu.current == 4 then
		surface.DrawRect(ScrW()/2-99,16*4,198,16); 
		elseif varmenu.current == 5 then
		surface.DrawRect(ScrW()/2-99,16*5,198,16); 
		elseif varmenu.current == 6 then
		surface.DrawRect(ScrW()/2-99,16*6,198,16); 
		elseif varmenu.current == 7 then
		surface.DrawRect(ScrW()/2-99,16*7,198,16); 
		elseif varmenu.current == 8 then
		surface.DrawRect(ScrW()/2-99,16*8,198,16); 
		elseif varmenu.current == 9 then
		surface.DrawRect(ScrW()/2-99,16*9,198,16); 
		end
		draw.SimpleTextOutlined( "valveHacks for GMOD by BB9", "Default", ScrW()/2, 16/2, Color( 180, 180, 180, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, Color( 0, 0, 0, 255 ) )
		draw.SimpleTextOutlined( "Aimbot: "..vH.aim, "Default", ScrW()/2-80, 16/2+16, Color( 255, 255, 255, 255 ), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER, 1, Color( 0, 0, 0, 255 ) )
		draw.SimpleTextOutlined( "Crosshair: "..vH.cross, "Default", ScrW()/2-80, 16/2+(16*2), Color( 255, 255, 255, 255 ), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER, 1, Color( 0, 0, 0, 255 ) )
		draw.SimpleTextOutlined( "ESP: "..vH.esp, "Default", ScrW()/2-80, 16/2+(16*3), Color( 255, 255, 255, 255 ), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER, 1, Color( 0, 0, 0, 255 ) )
		draw.SimpleTextOutlined( "Radar: "..vH.radar, "Default", ScrW()/2-80, 16/2+(16*4), Color( 255, 255, 255, 255 ), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER, 1, Color( 0, 0, 0, 255 ) )
		draw.SimpleTextOutlined( "NoSpread: "..vH.nospread, "Default", ScrW()/2-80, 16/2+(16*5), Color( 255, 255, 255, 255 ), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER, 1, Color( 0, 0, 0, 255 ) )
		draw.SimpleTextOutlined( "NoRecoil Value: "..(vH.norecval/10), "Default", ScrW()/2-80, 16/2+(16*6), Color( 255, 255, 255, 255 ), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER, 1, Color( 0, 0, 0, 255 ) )
		draw.SimpleTextOutlined( "AutoShoot: "..vH.autoshoot, "Default", ScrW()/2-80, 16/2+(16*7), Color( 255, 255, 255, 255 ), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER, 1, Color( 0, 0, 0, 255 ) )
		draw.SimpleTextOutlined( "ValPred: "..vH.valpred, "Default", ScrW()/2-80, 16/2+(16*8), Color( 255, 255, 255, 255 ), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER, 1, Color( 0, 0, 0, 255 ) )
		draw.SimpleTextOutlined( "Silent Aim: "..vH.silent, "Default", ScrW()/2-80, 16/2+(16*9), Color( 255, 255, 255, 255 ), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER, 1, Color( 0, 0, 0, 255 ) )
		surface.SetDrawColor( 90, 106, 79, 255 ); 
		surface.DrawOutlinedRect( ScrW()/2-101, 0, 202, 162 ); 
		end
		--crosshair
		if vH.cross == 1 then
		--[[surface.SetDrawColor( 255, 255, 255, 255 ); 
		surface.DrawLine(ScrW()/2-15,ScrH()/2,ScrW()/2-5,ScrH()/2)
		surface.DrawLine(ScrW()/2,ScrH()/2+5,ScrW()/2,ScrH()/2+15)
		surface.DrawLine(ScrW()/2+5,ScrH()/2,ScrW()/2+15,ScrH()/2)
		surface.DrawLine(ScrW()/2,ScrH()/2-15,ScrW()/2,ScrH()/2-5)]]
		surface.SetDrawColor(255,255,255,255)
		surface.DrawLine(ScrW()/2,ScrH()/2-10,ScrW()/2,ScrH()/2+10)
		surface.DrawLine(ScrW()/2-10,ScrH()/2,ScrW()/2+10,ScrH()/2)
		local h = 20
		local x = ScrW()/2
		local y = ScrH()/2-30
		local calculate = h/255
		local calculate2 = h/255
		for i=0,h do
		surface.SetDrawColor( i/calculate, i/calculate, i/calculate, 255)
		surface.DrawLine( x, i+y, x+1, i+y )
		end
		local h = 20
		local x = ScrW()/2
		local y = ScrH()/2+10
		local calculate = h/255
		local calculate2 = h/255
		for i=0,h do
		surface.SetDrawColor( 255-i/calculate, 255-i/calculate, 255-i/calculate, 255)
		surface.DrawLine( x, i+y, x+1, i+y )
		end
		local h = 20
		local x = ScrW()/2-30
		local y = ScrH()/2
		local calculate = h/255
		local calculate2 = h/255
		for i=0,h do
		surface.SetDrawColor( i/calculate, i/calculate, i/calculate, 255)
		surface.DrawLine( x+i, y, x+i, y+1 )
		end
		local h = 20
		local x = ScrW()/2+10
		local y = ScrH()/2
		local calculate = h/255
		local calculate2 = h/255
		for i=0,h do
		surface.SetDrawColor( 255-i/calculate, 255-i/calculate, 255-i/calculate, 255)
		surface.DrawLine( x+i, y, x+i, y+1 )
		end
		end
		--radar
		if vH.radar == 1 then
		drawbradar()
		end
end
hook.Add("HUDPaint","menuespandcrosshair",lol)
print("//		Unhook		//")
local timerruns = 1
function unhookz()
timerruns = 0
	hook.Remove("RenderScreenspaceEffects","bChams")
	hook.Remove("RenderScreenspaceEffects","asus")
	hook.Remove( "HUDPaint","menuespandcrosshair" )
	hook.Remove( "CalcView","lol" )
	hook.Remove( "HUDPaint","crosshair")
	hook.Remove( "Think","aimbot" )
	hook.Remove( "CreateMove","nospreadnaim" )
	print("Unloaded Hooks")
end

local function KeyPress()
if timerruns == 1 then
timer.Simple(0.1,function () KeyPress() end)
end
    if( input.IsKeyDown( KEY_DELETE ) ) then
	timerruns = 0
	print("Destroyed timer")
unhookz()
	print("Unloaded Hooks")
	end
    if( input.IsKeyDown( KEY_INSERT ) ) then
	if varmenu.showmenu == 0 then
	varmenu.showmenu = 1
	else
	varmenu.showmenu = 0
	end
    end
	if varmenu.showmenu == 1 then
	if( input.IsKeyDown( KEY_DOWN ) ) then
	if varmenu.current == 1 then
	varmenu.current = 2
	elseif varmenu.current == 2 then
	varmenu.current = 3
	elseif varmenu.current == 3 then
	varmenu.current = 4
	elseif varmenu.current == 4 then
	varmenu.current = 5
	elseif varmenu.current == 5 then
	varmenu.current = 6
	elseif varmenu.current == 6 then
	varmenu.current = 7
	elseif varmenu.current == 7 then
	varmenu.current = 8
	elseif varmenu.current == 8 then
	varmenu.current = 9
	elseif varmenu.current == 9 then
	varmenu.current = 1
	end
	end
	if( input.IsKeyDown( KEY_UP ) ) then
	if varmenu.current == 9 then
	varmenu.current = 8
	elseif varmenu.current == 8 then
	varmenu.current = 7
	elseif varmenu.current == 7 then
	varmenu.current = 6
	elseif varmenu.current == 6 then
	varmenu.current = 5
	elseif varmenu.current == 5 then
	varmenu.current = 4
	elseif varmenu.current == 4 then
	varmenu.current = 3
	elseif varmenu.current == 3 then
	varmenu.current = 2
	elseif varmenu.current == 2 then
	varmenu.current = 1
	elseif varmenu.current == 1 then
	varmenu.current = 9
	end
	end
	if( input.IsKeyDown( KEY_RIGHT ) ) then
	if varmenu.current == 1 then
	if vH.aim == 1 then
	vH.aim = 0
	else
	vH.aim = 1
	end
	elseif varmenu.current == 2 then
	if vH.cross == 1 then
	vH.cross = 0
	else
	vH.cross = 1
	end
	elseif varmenu.current == 3 then
	if vH.esp == 1 then
	vH.esp = 0
	else
	vH.esp = 1
	end
	elseif varmenu.current == 4 then
	if vH.radar == 1 then
	vH.radar = 0
	else
	vH.radar = 1
	end
	elseif varmenu.current == 5 then
	if vH.nospread == 1 then
	vH.nospread = 2
	elseif vH.nospread == 2 then
	vH.nospread = 3
	elseif vH.nospread == 3 then
	vH.nospread = 0
	else
	vH.nospread = 1
	end
	elseif varmenu.current == 6 then
	changenorecval()
	elseif varmenu.current == 7 then
	if vH.autoshoot == 1 then
	vH.autoshoot = 0
	else
	vH.autoshoot = 1
	end
	elseif varmenu.current == 8 then
	changepredval()
	elseif varmenu.current == 9 then
	if vH.silent == 1 then
	vH.silent = 0
	else
	vH.silent = 1
	end
	end
	end
	end
	end
KeyPress()
local function bMaterial()
local Texture = {
  ["$basetexture"] = "models/debug/debugwhite", -- models/debug/debugwhite
  ["$model"]       = 1,
  ["$translucent"] = 1,
  ["$alpha"]       = 1,
  ["$nocull"]      = 1,
  ["$ignorez"]  = 1
}
local Texture2 = {
  ["$basetexture"] = "models/debug/debugwhite", -- models/debug/debugwhite
  ["$model"]       = 1,
  ["$translucent"] = 1,
  ["$alpha"]       = 1,
  ["$nocull"]      = 1
}
   
local material = CreateMaterial( "b_solid", "VertexLitGeneric", Texture )
local material2 = CreateMaterial( "b_solid2", "VertexLitGeneric", Texture2 )

return material,material2

end
local function bChams()
for k, v in pairs( ents.GetAll() ) do
if ValidEntity( v ) then
cam.Start3D( EyePos(), EyeAngles() )
if v:IsNPC() then
if validtargetesp(v) then
local m,m2 = bMaterial()
render.SetColorModulation( 0, 255, 255 )
SetMaterialOverride( m )
v:DrawModel()
render.SetColorModulation( 255, 0, 0 )
SetMaterialOverride(m2)
v:DrawModel()
SetMaterialOverride(0)
end
elseif v:IsPlayer() then
if v:Health() > 1 then
cam.Start3D( EyePos(), EyeAngles() )
local m,m2 = bMaterial()
local dcolor = Color(255,255,255,255)
local dcolor2 = Color(255,255,255,255)
dcolor.r = team.GetColor(v:Team()).r
dcolor.g = team.GetColor(v:Team()).g
dcolor.b = team.GetColor(v:Team()).b
dcolor2.r = 255-dcolor.r
dcolor2.g = 255-dcolor.g
dcolor2.b = 255-dcolor.b
render.SetColorModulation( dcolor2.r,dcolor2.g,dcolor2.b )
SetMaterialOverride( m )
v:DrawModel()
render.SetColorModulation( dcolor.r,dcolor.g,dcolor.b )
SetMaterialOverride(m2)
v:DrawModel()
SetMaterialOverride(0)
end
end
cam.End3D()
end
end
end
hook.Add( "RenderScreenspaceEffects", "bChams", bChams )
LoadTime = math.floor(LoadTime - CurTime())
if LoadTime < 0 then
	LoadTime = -LoadTime
end
print("[aiaiaaz v0.2] | Loaded in "..LoadTime.." seconds")
print("                                   By BB9")
local function lol2()
if vH.cross == 1 then
local ply = LocalPlayer()
local angz = ply:GetShootPos()+ply:GetAimVector()
local x = (angz):ToScreen().x
local y = (angz):ToScreen().y
if LocalPlayer():Alive() then
local self = {}
local ViewModel = LocalPlayer():GetViewModel()
	if not ViewModel:IsValid() then return end
	self.EjectionPort = ViewModel:GetAttachment("1")
	if not self.EjectionPort then return end
 
	self.Angle = self.EjectionPort.Ang
	self.Forward = self.Angle:Forward()
	self.Position = self.EjectionPort.Pos
local angz2 = self.Position
local x2 = (angz2):ToScreen().x
local y2 = (angz2):ToScreen().y
surface.SetDrawColor(0,100,255,255)
surface.DrawLine(x,y,x2,y2)
surface.SetDrawColor(255,255,255,255)
	local center = Vector( x,y, 0 )
for i = 1,50 do
	local scale = Vector( i/10, i/10, 0 )
	local segmentdist = 360 / ( 2 * math.pi * math.max( scale.x, scale.y ) / 2 )
 
	for a = 0, 360 - segmentdist, segmentdist do
		surface.DrawLine( center.x + math.cos( math.rad( a ) ) * scale.x, center.y - math.sin( math.rad( a ) ) * scale.y, center.x + math.cos( math.rad( a + segmentdist ) ) * scale.x, center.y - math.sin( math.rad( a + segmentdist ) ) * scale.y )
	end
end
end
end
end
hook.Add("HUDPaint","crosshair",lol2)

function wallz()
if vH.asus == 1 then
	cam.Start3D( EyePos(), EyeAngles() )
		for k, v in pairs( ents.GetAll() ) do
			if v:IsNPC() or v:IsPlayer() then
				render.SuppressEngineLighting( true )
				render.SetColorModulation( 1, 1, 1 )
				render.SetBlend( 1 )
				v:DrawModel()
				render.SuppressEngineLighting( false )
			elseif v:IsWeapon() then
				render.SuppressEngineLighting( true )
				render.SetColorModulation( 1, 1, 1 )
				render.SetBlend( 1 )
				v:DrawModel()
				render.SuppressEngineLighting( false )
			elseif v:GetClass() == "worldspawn" then
				render.SuppressEngineLighting( true )
				local alpha = 150
				render.SetColorModulation( 1, 1, 1 )
				render.SetBlend( 1-alpha/255 )
				cam.IgnoreZ(1)
				v:DrawModel()
				cam.IgnoreZ(0)
				render.SuppressEngineLighting( false )
			end
			end
			local ViewModel = LocalPlayer():GetViewModel()
			if ViewModel:IsValid() then 
				render.SuppressEngineLighting( true )
				render.SetColorModulation( 1, 1, 1 )
				render.SetBlend( 1 )
				cam.IgnoreZ(1)
				ViewModel:DrawModel()
				cam.IgnoreZ(0)
				render.SuppressEngineLighting( false )
			end
	cam.End3D()
	end
	end
	hook.Add("RenderScreenspaceEffects","asus",wallz)
