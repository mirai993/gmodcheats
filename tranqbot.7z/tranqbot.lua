--[[
	Tranqbot.lua
	Gangster vs Gangster
	===DStream===
]]

-------------------------------
--TranqBot By Smelly & Tyzer!--
-------------------------------

local DermaPanel = vgui.Create( "DFrame",DermaPanel )
DermaPanel:SetPos( 300,200 ) 
DermaPanel:SetSize( 700, 490 )
DermaPanel:SetTitle( "The Tranquility Aimbot - By Tyzer And Smelly!" ) 
DermaPanel:SetVisible( true )
DermaPanel:SetDraggable( true )
DermaPanel:ShowCloseButton( true )
DermaPanel:MakePopup()

local PropertySheet = vgui.Create( "DPropertySheet" )
PropertySheet:SetParent( DermaPanel )
PropertySheet:SetPos( 10, 27 )
PropertySheet:SetSize( 670, 450 )
 
 --Aimbot Stuff
local AimbotOn = vgui.Create( "DCheckBoxLabel" )
AimbotOn:SetPos( 15, 60 )
AimbotOn:SetText("Aimbot On/Off")

local AimbotRange = vgui.Create( "DNumSlider" )
AimbotRange:SetParent( AimbotOn )
AimbotRange:SetPos( 0, 20 )
AimbotRange:SetSize( 150, 100 )
AimbotRange:SetText( "Aimbot Range!" )
AimbotRange:SetMin( 0 )
AimbotRange:SetMax( 52000 )
AimbotRange:SetDecimals( 0 )
 
--ESP Shit
local ESPON = vgui.Create( "DCheckBoxLabel" )
ESPON:SetText("ESP On/Off!")

local ESPRange = vgui.Create( "DNumSlider" )
ESPRange:SetParent( ESPON )
ESPRange:SetPos( 0, 20 )
ESPRange:SetSize( 150, 100 )
ESPRange:SetText( "ESP Range!" )
ESPRange:SetMin( 0 )
ESPRange:SetMax( 52000 )
ESPRange:SetDecimals( 0 )

--Entity Shit
local EntityOn = vgui.Create( "DCheckBoxLabel" )
EntityOn:SetText("Entities Finder On/Off!")

local EntityRange = vgui.Create( "DNumSlider" )
EntityRange:SetParent( EntityOn )
EntityRange:SetPos( 0, 20 )
EntityRange:SetSize( 150, 100 )
EntityRange:SetText( "Entity Finder Range!" )
EntityRange:SetMin( 0 )
EntityRange:SetMax( 52000 )
EntityRange:SetDecimals( 0 )

--Friends Shit
local FriendsOn = vgui.Create( "DCheckBoxLabel" )
FriendsOn:SetText("Friends List On/Off!")

--Special Shit
local SpecialOn = vgui.Create( "DCheckBoxLabel" )
SpecialOn:SetText("Special Items On/Off!")

--IP Logging Shit
local LoggingOn = vgui.Create( "DCheckBoxLabel" )
LoggingOn:SetText("IP Logging On/Off!")

--Other Shit
local OtherOn = vgui.Create( "DCheckBoxLabel" )
OtherOn:SetText("Misc Items On/Off!")

--Updates Shit
local UpdateOn = vgui.Create( "DCheckBoxLabel" )
UpdateOn:SetText("Updates On/Off")

--Help & Support Shit
local SupportOn = vgui.Create( "DCheckBoxLabel" )
SupportOn:SetText("Help N' Support On/Off")
 
PropertySheet:AddSheet( "Aimbot!", AimbotOn, "gui/silkicons/user", false, false, "Aimbot!" )
PropertySheet:AddSheet( "ESP!", ESPON, "gui/silkicons/group", false, false, "ESP!")
PropertySheet:AddSheet( "Entities!", EntityOn, "gui/silkicons/folder", false, false, "Entities!")
PropertySheet:AddSheet( "Friends!", FriendsOn, "gui/silkicons/shield", false, false, "Friend's List!")
PropertySheet:AddSheet( "Special!", SpecialOn, "gui/silkicons/mvp_vip", false, false, "Special Stuff!")
PropertySheet:AddSheet( "IP Logs!", LoggingOn, "gui/silkicons/page_edit", false, false, "Players IP's!")
PropertySheet:AddSheet( "Others!", OtherOn, "gui/silkicons/folder_page_white", false, false, "Others Stuff!")
PropertySheet:AddSheet( "Updates!", UpdateOn, "gui/silkicons/newspaper", false, false, "TranqBot Updates's!")
PropertySheet:AddSheet( "Help N' Support!", SupportOn, "gui/silkicons/help", false, false, "Help N' Support!")