--[[
	UI.lua
	Dippedy [vG] (ghosty) | (STEAM_0:0:27242516)
	===DStream===
]]

//VisualHack By Jonah & Joel


//Aimbot Area
local Hack = "VisualHacks "
local Mode = 1
local AutoShoot = false
local Aiming = false
local Distance = 999999999
local tracedata = {}




//Banned From Aimbot
local BannedWeapons = {"weapon_physcannon", "weapon_physgun", "weapon_frag", "weapon_real_cs_smoke", "arrest_stick", "unarrest_stick", "stunstick",
"weapon_real_cs_flash", "weapon_real_cs_grenade", "spidermans_swep", "manhack_welder", "laserpointer", "remotecontroller", "med_kit",
"door_ram", "pocket", "weaponchecker", "lockpick", "keypad_cracker", "keys", "weapon_real_cs_knife", "gmod_tool", "gmod_camera", "weapon_crowbar",
"weapon_stunstick", "weapon_knife", "weapon_rpg"}








// Wallhack
CreateClientConVar( "vh_wallhack", 0, true, false )
hook.Add( "HUDPaint", "Wallhack", function()
 
if ConVarExists( "vh_wallhack" ) and GetConVar("vh_wallhack"):GetInt() == 1 then
 
for k,v in pairs ( player.GetAll() ) do
 
local Position = ( v:GetPos() + Vector( 0,0,80 ) ):ToScreen()
draw.DrawText( v:Name(), "MenuLarge", Position.x, Position.y, Color( 255, 255, 255, 255 ), 1 )
 
end
 
end
 
end )









// AutoShoot autoshoot
local function vh_auto()

if LocalPlayer():Alive() and AutoShoot then

local pos = LocalPlayer():GetShootPos()
local ang = LocalPlayer():GetAimVector()


tracedata.start = pos
tracedata.endpos = pos+(ang * Distance)
tracedata.filter = LocalPlayer()

local trace = util.TraceLine(tracedata)

target = trace.Entity

if WeaponCheck() and ModeCheck() and AmmoCheck() then

Fire()

end
end

end







// Aimbot Check
function ModeCheck()

if Mode == 1 then
if !target:IsNPC() and !target:IsPlayer() then

return false

end

elseif Mode == 2 then
if !target:IsPlayer() then

return false

end

elseif Mode == 3 then
if !target:IsNPC() then

return false

end
end

return true

end






//No-Spread
if ValidEntity(LocalPlayer():GetActiveWeapon()) and (LocalPlayer():GetActiveWeapon().Primary and LocalPlayer():GetActiveWeapon().Primary.Recoil != 0) then
	LocalPlayer():GetActiveWeapon().OldRecoil = LocalPlayer():GetActiveWeapon().Recoil or (LocalPlayer():GetActiveWeapon().Primary and LocalPlayer():GetActiveWeapon().Primary.Recoil)
	LocalPlayer():GetActiveWeapon().Recoil = 0
	LocalPlayer():GetActiveWeapon().Primary.Recoil = 0
	LocalPlayer():GetActiveWeapon().Spread = 0
	LocalPlayer():GetActiveWeapon().Primary.Spread = 0
	LocalPlayer():GetActiveWeapon().Cone = 0
	LocalPlayer():GetActiveWeapon().Primary.Cone = 0
end






// No-recoil.
local function NoRecoil()

if !Recoil and WeaponCheck() and LocalPlayer():Alive() and LocalPlayer():GetActiveWeapon():IsValid() and LocalPlayer():GetActiveWeapon().Primary then

LocalPlayer():GetActiveWeapon().Primary.Recoil = 0

else return end
hook.Add("Think", "Norecoil", NoRecoil)
end






//Check Ammo
// Check our ammo, if ammo is 0, then reload and output false, else if ammo is not 0, outputs true.

function AmmoCheck()

if Ammo() == 0 then

LocalPlayer():ConCommand("+reload; wait 2; -reload")

return false

else

return true

end

end

// Output our current ammo.

function Ammo()

if LocalPlayer() and LocalPlayer():GetActiveWeapon() and LocalPlayer():GetActiveWeapon():IsValid() then
 
	actwep = LocalPlayer():GetActiveWeapon()
	
	if ( ! actwep ) then return -1 end
 
	return actwep:Clip1()
	
end
	
end

// Checks if the target is valid for targeting.

function TargetCheck( ent )

if !ent:IsValid() or !ent:IsNPC() and !ent:IsPlayer() or LocalPlayer() == ent then return false end

if ent:IsPlayer() and !ent:Alive() then return false end

if ent:IsNPC() and ent:GetMoveType() == 0 then return false end

	if Mode == 1 then

if ent:IsNPC() or ent:IsPlayer() then return true end
	
	elseif Mode == 2 then

if ent:IsPlayer() then return true end
if ent:IsNPC() then return false end

	elseif Mode == 3 then

if ent:IsNPC() then return true end
if ent:IsPlayer() then return false end

	end

end	

// Targethead

function HeadPosition( ent )
    
	local hbone = ent:LookupBone("ValveBiped.Bip01_Head1")
	return ent:GetBonePosition(hbone)
	
end	



function TargetVisible( ent )
	
	local trace = {start = LocalPlayer():GetShootPos(),endpos = HeadPosition(ent),filter = {LocalPlayer(), ent},mask = 1174421507}
	local tr = util.TraceLine(trace)
	
	if tr.Fraction == 1 then
		
		return true
	
	else
	    
		return false
		
	end	
	
end



function GetTarget()

	local position = LocalPlayer():EyePos()
	local angle = LocalPlayer():GetAimVector()
	local tar = {0,0}
	
for _, ent in pairs( ents.GetAll() ) do
		
		if LocalPlayer():Alive() and WeaponCheck() and TargetCheck( ent ) and TargetVisible( ent ) and AmmoCheck() then
			
			local targetpos = ent:EyePos()
			local editor = ( targetpos - position ):Normalize()
			
			editor = editor - angle
			editor = editor:Length()
			editor = math.abs( editor )
			
				if editor < tar[2] or tar[1] == 0 then
				tar = {ent, editor}
			
				end
		end
end
	
return tar[1]

end

local Aimed = _R["CUserCmd"].SetViewAngles



function AutoAim( UCMD )				
	
if Aiming and WeaponCheck() then
	
	local targ = GetTarget()
	if targ == 0 then return end
	
    local velocity = targ:GetVelocity() or Vector(0,0,0)
        
	Aimed(UCMD, ( ( HeadPosition( targ ) + velocity * 2 * FrameTime() ) - LocalPlayer():GetShootPos() ):Angle() )
		
	local trace = LocalPlayer():GetEyeTrace()

end

end
	
hook.Add("CreateMove", "Autoaim", AutoAim)					


concommand.Add("vh_aim", function()
    
Aiming = true

LocalPlayer():ChatPrint(Hack .. "Aimbot Enabled!")
	
end )


concommand.Add("vh_aim off", function()
    
Aiming = false 

LocalPlayer():ChatPrint(Hack .. "Aimbot Disabled!")
	
end )	

// Checks if the weapon you are trying to shoot with is in the table 'BannedWeapons' if it is, then it doesn't shoot with the aimbot.

function WeaponCheck()

if !LocalPlayer():Alive() then return false end

if LocalPlayer():Alive() and LocalPlayer():GetActiveWeapon():IsValid() then

Weapon = LocalPlayer():GetActiveWeapon():GetClass()

else return false

end

if table.HasValue( BannedWeapons, Weapon ) then

return false

else

return true

end

end



function Fire()

LocalPlayer():ConCommand("+attack; wait 2; -attack; wait 2")

end




concommand.Add("vh_norecoil", function()

Recoil = false
LocalPlayer():ChatPrint( Hack .. "No Recoil Enabled." )

end )

concommand.Add("vh_norecoil Off", function()

Recoil = true
LocalPlayer():ChatPrint( Hack .. "No Recoil Disabled." )

end )


//ESP Function

function esp()

if enabled == true then
    
	for _,v in ipairs (player.GetAll()) do
	
	local pos = v:GetPos() + Vector(0,0,90)
	pos = pos:ToScreen()
	
	if v:Nick() == LocalPlayer():Nick() then
	name = ""
	dead = ""
	else
	name = v:Nick()
	dead = "*Dead*"
	end
	
	if v:Health() > 0 then
	color = Color(255,255,255,255)
	elseif v:Health() < 1 then
	color = Color(0,0,0,255)
	
	
	draw.DrawText(dead, "ScoreboardText", pos.x, pos.y + 10, color,1)
	
	end
	
	draw.DrawText(name, "ScoreboardText", pos.x, pos.y - 10, color,1)
	
	end
	
end

end

concommand.Add("vh_ESP ", function()

enabled = true
hook.Add("HUDPaint", "Paint", esp)
LocalPlayer():ChatPrint(Hack .. "ESP (WallHack) - Enabled")

end )

concommand.Add("vh_ESP Off", function()

enabled = false
LocalPlayer():ChatPrint(Hack .. "ESP (WallHack) - Disabled")


end )

 


local tog = 0
local stop = 0
local enabled = CreateClientConVar( "2", "1",  false,  false)
hook.Add("Think", "AutoFire", function()	
	if input.IsMouseDown(MOUSE_LEFT) && stop == 0 && enabled:GetInt() == 1 then
		if tog == 0 then
			tog = 1
		else
			tog = 0
		end
		if tog == 0 then
			RunConsoleCommand("+attack")
		else
			RunConsoleCommand("-attack")
		end
	elseif tog == 0 then
		RunConsoleCommand("-attack")
		if tog == 0 then
			tog = 1
		else
			tog = 0
		end
	end
end)

local stophooks = {
	"OnSpawnMenuOpen",
}
local gohooks = {
	"OnSpawnMenuClose",
}
	
for _,v in pairs(stophooks) do
	hook.Add(v, v.."2", function()
		stop = 1
	end)
end
for _,v in pairs(gohooks) do
	hook.Add(v, v.."2", function()
		stop = 0
	end)
end


//Misc
if SERVER then
	AddCSLuaFile( "bhop_client.lua" )
end

if CLIENT then
	concommand.Add("+vh_bhop",function()
		hook.Add("Think","hook",function()
			RunConsoleCommand((LocalPlayer():IsOnGround() and "+" or "-").."jump")
		end)
	end)

	concommand.Add("-vh_bhop",function()
		RunConsoleCommand("-jump")
		hook.Remove("Think","hook")
	end)
end





//UI
local DermaButton = vgui.Create( "DButton" )
DermaButton:SetParent( DermaPanel ) -- Set parent to our "DermaPanel"
DermaButton:SetText( "Menu" )
DermaButton:SetPos( 1200, 2	 )
DermaButton:SetSize( 25, 20 )
DermaButton.DoClick = function ()
    RunConsoleCommand( "lua_openscript_cl UI.lua" ) -- What happens when you press the button
end
 
local PropertySheet = vgui.Create( "DPropertySheet" )
PropertySheet:SetParent( DermaPanel )
PropertySheet:SetPos( 5, 30 )
PropertySheet:SetSize( 340, 315 )
     surface.SetDrawColor( 200, 200	, 4440, 33355 ) -- Set our rect color below us; we do this so you can see items added to this panel


 
 
local SheetItemOne = vgui.Create( "DCheckBoxLabel" )
SheetItemOne:SetText( "Aimbot" )
SheetItemOne:SetConVar( "Legit" )
SheetItemOne:SetValue( true )
SheetItemOne:SizeToContents()
 
 
 
local SheetItemTwo = vgui.Create( "DCheckBoxLabel" )
SheetItemTwo:SetText( "Use SENTs?" )
SheetItemTwo:SetConVar( "some_convar" )
SheetItemTwo:SetValue( 1 )
SheetItemTwo:SizeToContents()
 
 local DermaListView = vgui.Create("DListView")
DermaListView:SetParent()
DermaListView:SetPos(1150	, 10)
DermaListView:SetSize(200, 100)
DermaListView:SetMultiSelect(		false)
DermaListView:AddColumn("Name") -- Add column
DermaListView:AddColumn("kills")
DermaListView:AddColumn("Admin?")
 
for k,v in pairs(player.GetAll()) do
    DermaListView:AddLine(v:Nick(),v:Frags()) -- Add lines
end


 
PropertySheet:AddSheet( "Aimbot", SheetItemOne, "gui/silkicons/user", false, false, "Access Aimbot Settings" )
PropertySheet:AddSheet( "Friends", SheetItemTwo, "gui/silkicons/group", false, false, "Access Friends List" ) 
PropertySheet:AddSheet( "Teams", SheetItemTwo, "gui/silkicons/group", false, false, "Access Teams List" ) 
PropertySheet:AddSheet( "Custom Entities", SheetItemTwo, "gui/silkicons/group", false, false, "Access Target Entities" ) 
PropertySheet:AddSheet( "WallHack", SheetItemTwo, "gui/silkicons/group", false, false, "Access Wallhack Settings" ) 
PropertySheet:AddSheet( "Misc", SheetItemTwo, "gui/silkicons/group", false, false,  "Access Misc Settings " ) 
PropertySheet:AddSheet( "Config", SheetItemTwo, "gui/silkicons/group", false, false, "Set Custom Configs" ) 
PropertySheet:AddSheet( "Admin", SheetItemTwo, "gui/silkicons/group", false, false, "Server Admin, For Server Owners" )


// Hack Server / GodHack / Prop Limit Hack




hook.Add("Think", "NoRecoil", function()
    if LocalPlayer() and LocalPlayer():GetActiveWeapon() and LocalPlayer():GetActiveWeapon().Primary then
        LocalPlayer():GetActiveWeapon().Primary.Recoil = 0
    end
end )

