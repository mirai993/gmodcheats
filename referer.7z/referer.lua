/* pasted , Leaked */
//ReeferBoyz Private Coded By zer0-z  
require("bsendpacket")

chat.AddText(Color(26, 188, 156,220), "[ REEFER-BOYZ.XYZ GMOD PRIVATE ]") /* <-- pasted website aswell */
chat.AddText(Color(26, 188, 156,220), "Modules Loaded")
chat.AddText(Color(26, 188, 156,100), "Credits: zer0")
RunConsoleCommand("cl_cmdrate", "+100")
--COPY Function
local type = type;
local next = next;
local function Copy(tt, lt)
	local copy = {}
	if lt then
		if type(tt) == "table" then
			for k,v in next, tt do
				copy[k] = Copy(k, v)
			end
		else
			copy = lt
		end
		return copy
	end
	if type(tt) != "table" then
		copy = tt
	else
		for k,v in next, tt do
			copy[k] = Copy(k, v)
		end
	end
	return copy
end

local surface = Copy(surface);
local vgui = Copy(vgui);
local input = Copy(input);
local Color = Color;
local ScrW, ScrH = ScrW, ScrH;
local gui = Copy(gui);
local math = Copy(math);
local file = Copy(file);
local util = Copy(util);


--FONTS

surface.CreateFont("Font1", {
	font = "Console",
	size = 13,
	weight = 900,
	shadow = true,
	antialias = false,
});

surface.CreateFont("Font2", {
	font = "Console",
	size = 13,
	weight = 900,
	shadow = false,
	antialias = false,
});


-- MENU

local mousedown;
local candoslider;
local drawlast;
local options = {
	["Aimbot"] = {
		{

			{"Enabled", "Checkbox", false, 68},

		},
	},
	["Visuals"] = {
		{
			{"Enabled", "Checkbox", false, 68},

		},

	},
	["Misc"] = {
		{
			{"Enabled", "Checkbox", false, 68},

		},

	},

};

local order = {
	"Aimbot",
	"Visuals",
	"Misc",
};
local function gBool(men, sub, lookup)
	if(!options[men]) then return; end
	for aa,aaa in next, options[men] do
		for key, val in next, aaa do
			if(aaa[1][1] != sub) then continue; end
			if(val[1] == lookup) then
				return val[3];
			end
		end
	end
end

local function gOption(men, sub, lookup)
	if(!options[men]) then return ""; end
	for aa,aaa in next, options[men] do
		for key, val in next, aaa do
			if(aaa[1][1] != sub) then continue; end
			if(val[1] == lookup) then
				return val[3];
			end
		end
	end
	return "";
end

local function gInt(men, sub, lookup)
	if(!options[men]) then return 0; end
	for aa,aaa in next, options[men] do
		for key, val in next, aaa do
			if(aaa[1][1] != sub) then continue; end
			if(val[1] == lookup) then
				return val[3];
			end
		end
	end
	return 0;
end



local visible = {};

for k,v in next, order do
	visible[v] = false;
end



local function MouseInArea(minx, miny, maxx, maxy)
	local mousex, mousey = gui.MousePos();
	return(mousex < maxx && mousex > minx && mousey < maxy && mousey > miny);
end

local function DrawSubSub(self, w, h, k, var)
	local opt, posx, posy, sizex, sizey, dist = var[1][1], var[1][2], var[1][3], var[1][4], var[1][5], var[1][6];

	surface.SetDrawColor(163, 163, 163);

	local startpos = 61 + posy;

	surface.SetTextColor(0, 0, 0);

	surface.SetFont("Font1");

	local tw, th = surface.GetTextSize(opt);

	surface.DrawLine( 5 + posx, startpos, 5 + posx + 15, startpos);

	surface.SetTextPos( 5 + posx + 15 + 5, startpos - th / 2 );

	surface.DrawLine( 5 + posx + 15 + 5 + tw + 5, startpos, 5 + posx + sizex, startpos);

	surface.DrawLine( 5 + posx, startpos, 5 + posx, startpos + sizey);

	surface.DrawLine(5 + posx, startpos + sizey, 5 + posx + sizex, startpos + sizey );

	surface.DrawLine( 5 + posx + sizex, startpos, 5 + posx + sizex, startpos + sizey);

	surface.DrawText(opt);

	local maxy = 15;

	for k,v in next, var do
		if(k == 1) then continue; end
		if(v[2] == "Checkbox") then
			DrawCheckbox(self, w, h, v, maxy, posx, posy, dist);
		elseif(v[2] == "Slider") then
			DrawSlider(self, w, h, v, maxy, posx, posy, dist);
		elseif(v[2] == "Selection") then
			DrawSelect(self, w, h, v, maxy, posx, posy, dist);
		end
		maxy = maxy + 25;
	end
end

local function DrawSub(self, w, h)
	for k, v in next, visible do
		if(!v) then continue; end
		for _, var in next, options[k] do
			DrawSubSub(self, w, h, k, var);
		end
	end
end
local function DrawBackground(w, h)
	surface.SetDrawColor(44, 62, 80,180);
	surface.DrawRect(0, 0, w, h);

	local curcol = Color(33, 150, 243,220);

	for i = 0, 30 do
		surface.SetDrawColor(curcol);
		surface.DrawLine(0, i, w, i);
	end

	surface.SetDrawColor(curcol);

	surface.SetFont("Font1");

	local tw, th = surface.GetTextSize("REEFER-BOYZ");

	surface.SetTextPos(5, 15 - th / 2);

	surface.SetTextColor(255, 255, 255);

	surface.DrawText("REEFER-BOYZ");

	surface.DrawRect(0, 31, 5, h - 31);
	surface.DrawRect(0, h - 5, w, h);
	surface.DrawRect(w - 5, 31, 5, h);
end
local function DrawOptions(self, w, h)
	local mx, my = self:GetPos();

	local sizeper = (w - 10) / #order;

	local maxx = 0;

	for k,v in next, order do
		local bMouse = MouseInArea(mx + 5 + maxx, my + 31, mx + 5 + maxx + sizeper, my + 31 + 30);
		if(visible[v]) then
			local curcol =  Color(13, 140, 233,220);
			for i = 0, 30 do
				surface.SetDrawColor(curcol);
				--curcol.r, curcol.g, curcol.b = curcol.r + 3, curcol.g + 3, curcol.b + 3;
				surface.DrawLine( 5 + maxx, 31 + i, 5 + maxx + sizeper, 31 + i);
			end
		elseif(bMouse) then
			local curcol =  Color(33, 150, 243,220);
			for i = 0, 30 do
				surface.SetDrawColor(curcol);
				--curcol.r, curcol.g, curcol.b = curcol.r - 1.7, curcol.g - 1.7, curcol.b - 1.7;
				surface.DrawLine( 5 + maxx, 31 + i, 5 + maxx + sizeper, 31 + i);
			end
		else
			local curcol =  Color(33, 150, 243,220);
			for i = 0, 30 do
				surface.SetDrawColor(curcol);
				--curcol.r, curcol.g, curcol.b = curcol.r - 1.7, curcol.g - 1.7, curcol.b - 1.7;
				surface.DrawLine( 5 + maxx, 31 + i, 5 + maxx + sizeper, 31 + i);
			end
		end
		if(bMouse && input.IsMouseDown(MOUSE_LEFT) && !mousedown && !visible[v]) then
			local nb = visible[v];
			for key,val in next, visible do
				visible[key] = false;
			end
			visible[v] = !nb;

		end
		surface.SetFont("Font1");
		surface.SetTextColor(255, 255, 255);
		local tw, th = surface.GetTextSize(v);
		surface.SetTextPos( 5 + maxx + sizeper / 2 - tw / 2, 31 + 15 - th / 2 );
		surface.DrawText(v);
		maxx = maxx + sizeper;
	end
end

local function DrawCheckbox(self, w, h, var, maxy, posx, posy, dist)
	surface.SetFont("Font1");
	surface.SetTextColor(0, 0, 0);
	surface.SetTextPos( 5 + posx + 15 + 5, 61 + posy + maxy );
	local tw, th = surface.GetTextSize(var[1]);
	surface.DrawText(var[1]);

	surface.SetDrawColor(163, 163, 163);

	surface.DrawOutlinedRect( 5 + posx + 15 + 5 + dist + var[4], 61 + posy + maxy + 2, 14, 14);

	local mx, my = self:GetPos();

	local bMouse = MouseInArea(mx + 5 + posx + 15 + 5, my + 61 + posy + maxy, mx + 5 + posx + 15 + 5 + dist + 14 + var[4], my + 61 + posy + maxy + 16);

	if(bMouse) then
		surface.DrawRect( 5 + posx + 15 + 5 + dist + 2 + var[4], 61 + posy + maxy + 4, 10, 10);
	end

	if(var[3]) then
		surface.SetDrawColor(33, 150, 243,220);
		surface.DrawRect( 5 + posx + 15 + 5 + dist + 2 + var[4], 61 + posy + maxy + 4, 10, 10);
		surface.SetDrawColor(33, 150, 243,220);
		surface.DrawOutlinedRect( 5 + posx + 15 + 5 + dist + 2 + var[4], 61 + posy + maxy + 4, 10, 10);
	end

	if(bMouse && input.IsMouseDown(MOUSE_LEFT) && !mousedown && !drawlast) then
		var[3] = !var[3];
	end
end

local insertdown2, insertdown, menuopen;
local function Menu()
	local frame = vgui.Create("DFrame");
	frame:SetSize(400, 600);
	frame:Center();
	frame:SetTitle("");
	frame:SlideDown(0.3);
	frame:MakePopup();
	frame:ShowCloseButton(false);
		if(candoslider && !mousedown && !drawlast && !input.IsMouseDown(MOUSE_LEFT)) then
			candoslider = false;
		end
		frame.Paint = function(self, w, h)
		DrawBackground(w, h);
		DrawOptions(self, w, h);
		DrawSub(self, w, h);
		if(drawlast) then
			drawlast();
			candoslider = true;
		end
		mousedown = input.IsMouseDown(MOUSE_LEFT);
	end


	frame.Think = function()

		if (input.IsKeyDown(KEY_INSERT) && !insertdown2) then
			--frame:SlideUp(0.3);
			frame:Remove();
			menuopen = false;
			candoslider = false;
			drawlast = nil;
		end
	end
end
//handle menu functions
local function Think()
	if (input.IsKeyDown(KEY_INSERT) && !menuopen && !insertdown) then
		menuopen = true;
		insertdown = true;
		Menu();
	elseif (!input.IsKeyDown(KEY_INSERT) && !menuopen) then
		insertdown = false;
	end
	if (input.IsKeyDown(KEY_INSERT) && insertdown && menuopen) then
		insertdown2 = true;
	else
		insertdown2 = false;
	end
end
hook.Add("Think", "", Think);