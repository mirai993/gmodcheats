--[[
	MOD/lua/exl.lua [#20998 (#21578), 3911438724]
	Styles | STEAM_0:0:40652210 <72.160.189.134:50856> | [25.02.14 08:55:12AM]
	===BadFile===
]]

-- let's set some shit up
local exl = {}

local me = LocalPlayer()

local reg = debug.getregistry()

-- localization, for this script of course.

local concommand                        = concommand
local cvars                             = cvars
local debug                             = debug
local ents                                      = ents
local file                                      = file
local hook                                      = hook
local math                                      = math
local spawnmenu                         = spawnmenu
local string                            = string
local surface                           = surface
local table                             = table
local timer                             = timer
local util                                      = util
local vgui                                      = vgui
local Angle                             = Angle
local CreateClientConVar        = CreateClientConVar
local CurTime                           = CurTime
local ErrorNoHalt                       = ErrorNoHalt
local FrameTime                         = FrameTime
local GetConVarString           = GetConVarString
local GetViewEntity             = GetViewEntity
local include                           = include
local ipairs                            = ipairs
local LocalPlayer                       = LocalPlayer
local pairs                             = pairs
local pcall                             = pcall
local print                             = print
local RunConsoleCommand         = RunConsoleCommand
local ScrH                                      = ScrH
local ScrW                                      = ScrW
local tonumber                          = tonumber
local type                                      = type
local unpack                            = unpack
local IsValid                   = IsValid
local Vector                            = Vector

-- because anticheats

exl.setting = CreateClientConVar( "exl_push", 1, true, false )
exl.setting = CreateClientConVar( "exl_pos", 1, true, false )
exl.setting = CreateClientConVar( "exl_pos_clip", 1, true, false )
exl.setting = CreateClientConVar( "exl_pos_auto", 1, true, false )
exl.setting = CreateClientConVar( "exl_goup", 1, true, false )
exl.setting = CreateClientConVar( "exl_see", 1, true, false )
exl.setting = CreateClientConVar( "exl_see_other", 1, true, false )
exl.setting = CreateClientConVar( "exl_see_dollas", 1, true, false )
exl.setting = CreateClientConVar( "exl_see_far", 1, true, false )
exl.setting = CreateClientConVar( "exl_see_cond", 1, true, false )
exl.setting = CreateClientConVar( "exl_see_glock", 1, true, false )
exl.setting = CreateClientConVar( "exl_acid", 1, true, false )
exl.setting = CreateClientConVar( "exl_acid_people", 1, true, false )
exl.setting = CreateClientConVar( "exl_acid_things", 1, true, false )

function exl:conmsg(str)
MsgC( Color( 255, 255, 255 ), "<EXL> " .. str .. "\n" )
end

function exl:chatmsg(str)
chat.AddText( Color( 255, 255, 255 ), "EXL: " .. str )
end

--[[
*******************************

ginger brony deagle master mode

*******************************
]]

exl.PredictWeapons = {
		["weapon_crossbow"] = 3110,
	}

function exl:GetPos( e, pos )
	if ( type( pos ) == "string" ) then
		return ( e:GetBonePosition( e:LookupBone( pos ) ) )
	elseif ( type( pos ) == "Vector" ) then
		return ( e:LocalToWorld( pos ) )
	end
	return ( e:LocalToWorld( pos ) )
end

function exl:WeaponPrediction( e, pos )
	local ply = LocalPlayer()
	if ( IsValid( e ) && ( type( e:GetVelocity() ) == "Vector" ) ) then
		local dis, wep = e:GetPos():Distance( ply:GetPos() ), ( ply.GetActiveWeapon && IsValid( ply:GetActiveWeapon() ) && ply:GetActiveWeapon():GetClass() )
		if ( wep && exl.PredictWeapons[ wep ]  ) then
			local t = dis / exl.PredictWeapons[ wep ]
			return ( pos + e:GetVelocity() * t )
		end
		return pos
	end
	return pos
end

function exl:GenerateSpot( e )
	local spt = e:LocalToWorld( e:OBBCenter() )
	spt = exl:GetPos( e, "ValveBiped.Bip01_Head1" )
	
	local m = e:GetModel()
	if ( m == "models/crow.mdl" || m == "models/pigeon.mdl" ) then 	spt = exl:GetPos( e, Vector( 0, 0, 5 ) ) end
	if ( m == "models/seagull.mdl" ) then 							spt = exl:GetPos( e, Vector( 0, 0, 6 ) ) end
	if ( m == "models/combine_scanner.mdl" ) then 					spt = exl:GetPos( e, "Scanner.Body" ) end
	if ( m == "models/hunter.mdl" ) then 							spt = exl:GetPos( e, "MiniStrider.body_joint" ) end
	if ( m == "models/combine_turrets/floor_turret.mdl" ) then		spt = exl:GetPos( e, "Barrel" ) end
	if ( m == "models/dog.mdl" ) then 								spt = exl:GetPos( e, "Dog_Model.Eye" ) end
	if ( m == "models/vortigaunt.mdl" ) then 						spt = exl:GetPos( e, "ValveBiped.Head" ) end
	if ( m == "models/antlion.mdl" ) then 							spt = exl:GetPos( e, "Antlion.Body_Bone" ) end
	if ( m == "models/antlion_guard.mdl" ) then 					spt = exl:GetPos( e, "Antlion_Guard.Body" ) end
	if ( m == "models/antlion_worker.mdl" ) then 					spt = exl:GetPos( e, "Antlion.Head_Bone" ) end
	if ( m == "models/zombie/fast_torso.mdl" ) then 				spt = exl:GetPos( e, "ValveBiped.HC_BodyCube" ) end
	if ( m == "models/zombie/fast.mdl" ) then 						spt = exl:GetPos( e, "ValveBiped.HC_BodyCube" ) end
	if ( m == "models/headcrabclassic.mdl" ) then 					spt = exl:GetPos( e, "HeadcrabClassic.SpineControl" ) end
	if ( m == "models/headcrabblack.mdl" ) then 					spt = exl:GetPos( e, "HCBlack.body" ) end
	if ( m == "models/headcrab.mdl" ) then 							spt = exl:GetPos( e, "HCFast.body" ) end
	if ( m == "models/zombie/poison.mdl" ) then 					spt = exl:GetPos( e, "ValveBiped.Headcrab_Cube1" ) end
	if ( m == "models/zombie/classic.mdl" ) then 					spt = exl:GetPos( e, "ValveBiped.HC_Body_Bone" ) end
	if ( m == "models/zombie/classic_torso.mdl" ) then 				spt = exl:GetPos( e, "ValveBiped.HC_Body_Bone" ) end
	if ( m == "models/zombie/zombie_soldier.mdl" ) then				spt = exl:GetPos( e, "ValveBiped.HC_Body_Bone" ) end
	if ( m == "models/combine_strider.mdl" ) then 					spt = exl:GetPos( e, "Combine_Strider.Body_Bone" ) end
	if ( m == "models/combine_dropship.mdl" ) then 					spt = exl:GetPos( e, "D_ship.Spine1" ) end
	if ( m == "models/combine_helicopter.mdl" ) then 				spt = exl:GetPos( e, "Chopper.Body" ) end
	if ( m == "models/gunship.mdl" ) then 							spt = exl:GetPos( e, "Gunship.Body" ) end
	if ( m == "models/lamarr.mdl" ) then 							spt = exl:GetPos( e, "HeadcrabClassic.SpineControl" ) end
	if ( m == "models/mortarsynth.mdl" ) then 						spt = exl:GetPos( e, "Root Bone" ) end
	if ( m == "models/synth.mdl" ) then 							spt = exl:GetPos( e, "Bip02 Spine1" ) end
	if ( m == "mmodels/vortigaunt_slave.mdl" ) then 				spt = exl:GetPos( e, "ValveBiped.Head" ) end
	
	return exl:WeaponPrediction( e, spt )
end

function exl:cansee( e )
	if ( !IsValid(e) ) then return false end
	
	local ply, spt = LocalPlayer(), exl:GenerateSpot(e)
	
    local visible = {

			start = ply:GetShootPos(),
			endpos = spt,
			filter = { ply, e }

		}

	local trace = util.TraceLine( visible )
	
	if trace.Fraction == 1 then
		return true
    end
    return false 
end

function exl:canlook( e )
	local ply = LocalPlayer()
	
	if ( !IsValid( e ) ) then return false end
	if ( e:IsNPC() && !util.IsValidModel( e:GetModel() || "" ) ) then return false end
	if ( e:GetMoveType() == MOVETYPE_NONE ) then return false end
	if ( !e:IsValid() || !e:IsPlayer() && !e:IsNPC() || e == ply ) then return false end
	if ( e:IsPlayer() && e:GetMoveType() == MOVETYPE_OBSERVER ) then return false end
	if ( e:IsPlayer() && !e:Alive() ) then return false end
	if ( e:IsPlayer() && GetConVarNumber( "exl_team" ) == 1 && ( e:Team() == ply:Team() ) ) then return false end
	--if ( e:IsPlayer() && ( e:GetFriendStatus() == "friend" ) ) then return false end
	--if ( e:IsNPC() ) then return false end
	return true
end

function exl:clip()
if ( me:GetActiveWeapon() && me:GetActiveWeapon():IsValid() && me:GetActiveWeapon():GetClass() == "weapon_crossbow" ) then return end
		if me && me:GetActiveWeapon() && me:GetActiveWeapon():IsValid() and GetConVarNumber( "exl_pos_clip" ) == 1 then
		local wep = me:GetActiveWeapon()
		if !wep then return -1 end
		if wep:Clip1() == 0 then
			RunConsoleCommand( "+reload" )
			timer.Simple( 0.25, function() RunConsoleCommand( "-reload" ) end )
		end
	end
end
hook.Add( "Think", "clip", exl.clip )
	
exl.lookang	= Angle( 0, 0, 0 )
	
function exl.pos( ucmd )
	local ply 	= LocalPlayer()
	local m 	= Angle( ucmd:GetMouseY() * GetConVarNumber( "m_pitch" ), ucmd:GetMouseX() * -GetConVarNumber("m_yaw"), 0 ) or Angle( 0, 0, 0 )
	exl.Viewfix 	= ucmd:GetViewAngles()
	exl.lookang 	= exl.lookang + m

	if ( exl.looking ) then
	
		if ( !exl:canlook(exl.Target) || !exl:cansee(exl.Target) ) then
			exl.Target = nil
			local f, o, a, t, b = 360, { p, y }
			for k, e in pairs( ents.GetAll() ) do
				if ( exl:canlook(e) && exl:cansee(e) ) then
					local tP, oP = math.Round( e:GetPos():Distance( ply:GetPos() ) ), math.Round( ply:GetPos():Distance( e:GetPos() ) )
					b = exl:GenerateSpot(e)
					
					a, t = ply:GetAimVector():Angle(), (b - ply:GetShootPos()):Angle()
					o.p, o.y = math.abs(math.NormalizeAngle(a.p - t.p)) / 2, math.abs(math.NormalizeAngle(a.y - t.y)) / 2
					
					if ( !exl.Target || tP > oP ) && ( o.p <= f && o.y <= f ) then exl.Target = e end
				end
			end
		end

		if ( exl.looking && exl.Target != nil && GetConVarNumber( "exl_pos_auto" ) == 1 ) then
			RunConsoleCommand( "+attack" )
			timer.Simple( 0.1, function() RunConsoleCommand( "-attack" ) end )
		end
		
		if ( !IsValid(exl.Target) || !exl.looking ) then return end
		local comp, myPos = exl:GenerateSpot(exl.Target), ply:GetShootPos()
		comp = comp + ( exl.Target:GetVelocity() / 45 - ply:GetVelocity() / 45 )
		
		local ang = ( comp-myPos ):Angle()
		ang.p = math.NormalizeAngle( ang.p )
		ang.y = math.NormalizeAngle( ang.y )
		
		ang.r = 0
		
		exl.lookang 	= ang
		exl.Viewfix 	= ang
	end
	
	exl.lookang.r	= 0
	exl.Angles 	= exl.lookang
	exl.Angles.p	= math.NormalizeAngle( exl.Angles.p )
	exl.Angles.y	= math.NormalizeAngle( exl.Angles.y )
	exl.Angles.y = math.NormalizeAngle( exl.Angles.y + ( ucmd:GetMouseX() * -0.022 * 1 ) )
	exl.Angles.p = math.Clamp( exl.Angles.p + ( ucmd:GetMouseY() * 0.022 * 1 ), -89, 90 )
	ucmd:SetViewAngles( exl.Angles )
end
concommand.Add( "+pos", function() exl.looking = true end )
concommand.Add( "-pos", function() exl.looking = false exl.Target = nil end )
hook.Add( "CreateMove", "gay", exl.pos )

function exl:push( ucmd )
	local wep = LocalPlayer():GetActiveWeapon()
	if ( GetConVarNumber( "exl_push" ) == 1 && !exl.looking ) then
		if ( wep.Primary ) then wep.Primary.Recoil = 0 end
		return { origin = 90, angles = exl.Angles }
	elseif ( GetConVarNumber( "exl_push" ) == 1 && exl.looking && exl.Target != nil  ) then
		if ( wep.Primary ) then wep.Primary.Recoil = 0 end
		return { origin = 90, angles = exl.Angles }
	elseif ( GetConVarNumber( "exl_push" ) == 1 && exl.looking && exl.Target == nil ) then
		if ( wep.Primary ) then wep.Primary.Recoil = 0 end
		return { origin = 90, angles = exl.Viewfix }
	end
	return
end
hook.Add( "CalcView", "something", exl.push )

local me = LocalPlayer()
function exl:goup()
if GetConVarNumber( "exl_goup" ) == 1 then
     if (input.IsKeyDown( KEY_SPACE ) ) then
        if me:IsOnGround() then
            RunConsoleCommand("+jump")
            HasJumped = 1
        else
            RunConsoleCommand("-jump")
            HasJumped = 0
        end
    elseif GetConVarNumber( "exl_goup" ) == 1 and me:IsOnGround() then
        if HasJumped == 1 then
            RunConsoleCommand("-jump")
            HasJumped = 0
        end
    end
end
end
hook.Add("Think", "gottagoup", exl.goup)
exl:conmsg("module pos loaded.")

--[[
**************************

magical eyes of magicness

*************************
]]

local toscreen = reg.Vector.ToScreen
local dist = reg.Vector.Distance
local eyeang = reg.Entity.EyeAngles
local entindex = reg.Entity.EntIndex
local findattach = reg.Entity.LookupAttachment
local getattach = reg.Entity.GetAttachment
local getclass = reg.Entity.GetClass
local getpos = reg.Entity.GetPos
local getnwint = reg.Entity.GetNWInt
local getnwstring = reg.Entity.GetNWString
local getprint = reg.Weapon.GetPrintName
local shootpos = reg.Player.GetShootPos
local job = reg.Player.Team
local wep = reg.Player.GetActiveWeapon
local aimvect = reg.Player.GetAimVector
local name = reg.Player.Nick
local admen = reg.Player.IsAdmin
local super = reg.Player.IsSuperAdmin

--[[hook.Add("InitPostEntity", "getstuff", function()
	timer.Simple(10, function() name = reg.Player.Nick
	admen = reg.Player.IsAdmin
	super = reg.Player.IsSuperAdmin end)
end)]]

local DrawLijst =  {}

local vect = FindMetaTable("Vector")

function vect:IsInSight(ignore, ply)
	ply = ply or LocalPlayer()
	local trace = {}
	trace.start = shootpos(ply)
	trace.endpos = self
	trace.filter = ignore
	trace.mask = CONTENTS_SOLID + CONTENTS_MOVEABLE + CONTENTS_OPAQUE + CONTENTS_DEBRIS + CONTENTS_HITBOX + CONTENTS_MONSTER
	local TheTrace = util.TraceLine(trace)
	return TheTrace.Hit, TheTrace.HitPos, trace.Entity
end

local function geteyetrace(ply) -- what is this?
	local HeadPos = shootpos(ply)
	local tracedata = {}
	tracedata.start = HeadPos
	tracedata.endpos = HeadPos + FGetAimVector(ply) * 10000
	tracedata.filter = ply
	tracedata.mask = CONTENTS_SOLID + CONTENTS_MOVEABLE + CONTENTS_OPAQUE + CONTENTS_DEBRIS + CONTENTS_HITBOX + CONTENTS_MONSTER

	local trace = util.TraceLine(tracedata)
	return trace
end
	
function exl:see()
	local ScrWidth, ScrHeight = ScrW(), ScrH()
	local aimVec = LocalPlayer():GetAimVector()
	local localPos = EyePos()
	if GetConVarNumber( "exl_see" ) == 1 then
		local numberusedalot = 10

		for k,v in pairs(DrawLijst) do
			if aimVec:Dot((v.pos - localPos):GetNormalized()) < 0.5 then continue end

			local pos = toscreen(v.pos)
			pos.x = math.Clamp(pos.x, 0, ScrWidth)
			pos.y = math.Clamp(pos.y, 45, ScrHeight)

			for a,b in pairs(v.data) do
				local w = -0.5 * numberusedalot
				local clr = Color( v.teamcolor.r,v.teamcolor.g,v.teamcolor.b, 185 )
				draw.DrawText( b, "BudgetLabel", pos.x, (pos.y + (a-1) * (8 + 4) - 4 * numberusedalot), clr, TEXT_ALIGN_RIGHT )
			end
		end
	end

end
hook.Add("HUDPaint", "see", exl.see)

local function HeadPos(ent)
	if not IsValid(ent) then return Vector(0,0,0) end
	local head = findattach(ent, "eyes")
	local Head = getattach(ent, head)
	if not Head then
		return shootpos(ent)
	end
	return Head.Pos
end

--[[ local function gunpos(ply)
	local wep = ply:GetActiveWeapon()
	if not IsValid(wep) then return HeadPos(ply) end
	local att = wep:LookupAttachment("muzzle")
	if not wep:GetAttachment(1) then
		return HeadPos(ply)
	end
	return wep:GetAttachment(1).Pos
end ]]

local NoLookingAtWeapons = {
	["weapon_physgun"] = true,
	["weapon_physcannon"] = true,
	["gmod_camera"] = true,
	["keys"] = true,
	["pocket"] = true}
local tick = 0
local ticktable = {}
for i=0,1000,10 do
	ticktable[i] = true
end

function exl:calc()
	local AllPly = player.GetAll()
	for k = 1, #AllPly do
		local v = AllPly[k]
		if v ~= LocalPlayer() then
			local entindex = entindex(v)
			local a = DrawLijst[entindex] or {}

			a.data = a.data or {}

			local teamcolor = a.teamcolor or team.GetColor(job(v))
			a.teamcolor = teamcolor
			local wep = wep(v)
			a.pos = HeadPos(v)
			a.dir = aimvect(v)
			a.origin = EyePos()


			if ticktable[tick+((k-1)*2)] or not DrawLijst[entindex] then
				a.data = {}
				local ADataCount = 0 -- It's faster to not user table.insert.

				teamcolor = team.GetColor(job(v))
					a.data[ADataCount + 1] = name(v)
					ADataCount = ADataCount + 1
				if GetConVarNumber( "exl_see_cond" ) == 1 then
					a.data[ADataCount + 1] = "Health: " .. v:Health()
					ADataCount = ADataCount + 1
				end

				local money = (v.DarkRPVars and v.DarkRPVars.money) or getnwint(v, "money")

				if GetConVarNumber( "exl_see_dollas" ) == 1 and money ~= 0 then
					a.data[ADataCount + 1] = "Money: " .. tostring(money)
					ADataCount = ADataCount + 1
				end

				if GetConVarNumber( "exl_see_glock" ) == 1 and wep:IsValid() then
					a.data[ADataCount + 1] = FGetPrintName(wep)
					ADataCount = ADataCount + 1
				end

				if GetConVarNumber( "exl_see_far" ) == 1 then
					a.data[ADataCount + 1] = "Distance: " .. tostring(math.floor(dist(a.pos, LocalPlayer():GetPos())))
					ADataCount = ADataCount + 1
				end

				if v:GetObserverTarget() ~= NULL and v:GetObserverTarget() ~= nil then
						a.data[ADataCount] = "Spectating: "..(v:GetObserverTarget().Nick and v:GetObserverTarget():Nick() or v:GetObserverTarget():GetClass())
					ADataCount = ADataCount + 1
				end

				a.teamcolor = {}
				local entered = false
				local usergroup = string.lower(getnwstring(v, "UserGroup"))
				if usergroup ~= "user" and usergroup ~= "" and usergroup ~= "superadmin" and usergroup ~= "admin" and usergroup ~= "undefined" and usergroup ~= "guest" then
					a.data[ADataCount + 1] = usergroup
					ADataCount = ADataCount + 1
					entered = true
				end

				local ASSadmin = getnwint(v, "ASS_isAdmin", 0)
				if LevelToString ~= nil then
					local ASSAdminString = LevelToString(ASSadmin)
					if ASSAdminString ~= "Guest" and ASSAdminString ~= "Admin" and ASSAdminString ~= "Super Admin" and not table.HasValue(a.data, LevelToString(ASSadmin)) then
						a.data[ADataCount + 1] = LevelToString(ASSadmin)
						ADataCount = ADataCount + 1
						entered = true
					end

					if (usergroup == "superadmin" or usergroup == "admin") and not entered then
						a.data[ADataCount + 1] = LevelToString(ASSadmin)
						ADataCount = ADataCount + 1
					end
				end

				local IsAdmin, IsSuperAdmin = admen(v), super(v)
				if IsAdmin and not IsSuperAdmin then
					if not table.HasValue(a.data, "Admin") then
						a.data[ADataCount + 1] = "Admin"
						ADataCount = ADataCount + 1
					end
					if teamcolor.r == 255 and teamcolor.g == 255 and teamcolor.b == 100 then
						a.teamcolor.r = 30
						a.teamcolor.g = 200
						a.teamcolor.b = 50
					else
						a.teamcolor.r = teamcolor.r
						a.teamcolor.g = teamcolor.g
						a.teamcolor.b = teamcolor.b
					end
				elseif super(v) then
					if not table.HasValue(a.data, "superadmin") and not table.HasValue(a.data, "Owner") and not table.HasValue(a.data, "Super Admin") then
						a.data[ADataCount + 1] = "Super Admin"
						ADataCount = ADataCount + 1
					end
					if teamcolor.r == 255 and teamcolor.g == 255 and teamcolor.b == 100 then
						a.teamcolor.r = 30
						a.teamcolor.g = 200
						a.teamcolor.b = 50
					else
						a.teamcolor.r = teamcolor.r
						a.teamcolor.g = teamcolor.g
						a.teamcolor.b = teamcolor.b
					end
				elseif not IsAdmin then
					if teamcolor.r == 255 and teamcolor.g == 255 and teamcolor.b == 100 then
						a.teamcolor.r = 100
						a.teamcolor.g = 150
						a.teamcolor.b = 245
					else
						a.teamcolor.r = teamcolor.r
						a.teamcolor.g = teamcolor.g
						a.teamcolor.b = teamcolor.b
					end
				end
			end

			DrawLijst[entindex] = a
		end
	end
	end

	tick = tick + 1
	if tick >= 1000 then
		DrawLijst = {}
		tick = 0

		ticktable = {}
	for i=1,1000,#AllPly*2 do
			ticktable[i] = true
	end
end
hook.Add("Think", "calc", exl.calc)
exl:conmsg("module see loaded.")

--timer.Simple( 3, function() hook.Remove("Think", "calc") end )
--timer.Simple( 3.5, function() hook.Add("Think", "calc", exl.calc) end )

function exl:getents(ent)
	if !(ent:IsValid()) then return false end 
	if (ent:GetClass() == nil) or (ent:GetClass() == "") or (string.find(ent:GetClass(), "physgun")) or (ent:GetOwner() == LocalPlayer()) then 
		return false 
	end
	if string.find(ent:GetClass(), "drug") or string.find(ent:GetClass(), "food") or
	string.find(ent:GetClass(), "drug") or string.find(ent:GetClass(), "gun") or
	string.find(ent:GetClass(), "melon") or string.find(ent:GetClass(), "money") or
	string.find(ent:GetClass(), "spawned") or string.find(ent:GetClass(), "microwave") or
	string.find(ent:GetClass(), "ent") or string.find(ent:GetClass(), "weapon_ttt") or

	ent:GetModel() == "models/props/cs_assault/money.mdl" then
		return true
	else
		return false
	end
end

function drawents()
		for _, ent in pairs(ents.GetAll()) do
			if exl:getents(ent) and GetConVarNumber("exl_see_other") == 1 then
				local postent = ent:GetPos()
				if postent:ToScreen().x > 0 and
				postent:ToScreen().y > 0 and
				postent:ToScreen().x < ScrW() and
				postent:ToScreen().y < ScrH() then
	                local entpos = (ent:LocalToWorld( Vector(0,0,0)) ):ToScreen()
                    if ent:GetModel() != "models/props/cs_assault/money.mdl" then
						draw.DrawText(ent:GetClass(), "BudgetLabel", entpos.x, entpos.y, Color(255, 255, 255, 255), TEXT_ALIGN_RIGHT)
					else
						draw.DrawText("Money", "BudgetLabel", entpos.x, entpos.y, Color(255, 255, 255, 255), TEXT_ALIGN_RIGHT)
					end
				end
			end
		end
end
hook.Add("HUDPaint", "otherthings", drawents)
exl:conmsg("module ents loaded.")

exl:conmsg("initialized...")
exl:chatmsg("initialized...")