require( "nyx" )
_nyx.Init()

function GetWeaponVector( value, typ )
local s = ( -value )      
	if ( typ == true ) then
		s = ( -value )
	elseif ( typ == false ) then
		s = ( value )
	else
		s = ( value )
	end
	return Vector( s, s, s )
end

local CustomCones 			= {
	[ "weapon_pistol" ] 	= GetWeaponVector( 0.0100, true, true ),
	[ "weapon_smg1" ] 		= GetWeaponVector( 0.04362, true, true ),
	[ "weapon_ar2" ]		= GetWeaponVector( 0.02618, true, true ),
	[ "weapon_shotgun" ]	= GetWeaponVector( 0.08716, true, true ),
	[ "weapon_zs_zombie" ]	= GetWeaponVector( 0.0, true, true ),
}
local NormalCones 			= {
	[ "weapon_cs_base" ]	= true,
	[ "weapon_sh_base" ] 	= true,
	[ "weapon_zs_base" ] 	= true,
}
 
function GetCone( wep )
	local cone = wep.Cone      
	if ( !cone && ( type( wep.Primary ) == "table" ) && ( type( wep.Primary.Cone ) == "number" ) ) then 
		cone = wep.Primary.Cone 
	end
	if ( !cone ) then 
		cone = 0 
	end
	if ( type( wep.Base ) == "string" && NormalCones[ wep.Base ] ) then 
		return cone
	end
return cone || 0
end

function PredictSpread( cmd, ang )
local w = LocalPlayer():GetActiveWeapon()
local vecCone, valCone = Vector( 0, 0, 0 )
	if ( w && w:IsValid() && ( type( w.Initialize ) == "function" ) ) then
		valCone = GetCone( w )                    
		if ( type( valCone ) == "number" ) then
			vecCone = Vector( -valCone, -valCone, -valCone )                      
		elseif ( type( valCone ) == "Vector" ) then
			vecCone = valCone * -1     
		elseif ( CL:KeyDown( IN_SPEED ) or CL:KeyDown( IN_JUMP ) ) then
			vecCone = valCone + (cone * 2 )                        
		end
	else
		if ( w:IsValid() ) then
			local class = w:GetClass()
			if ( CustomCones[ class ] ) then
				vecCone = CustomCones[ class ]
			end
		end
	end
return ( _nyx.RemoveSpread( cmd, ang, vecCone ) ):Angle()
end


function NoSpread( ucmd )
	nospreadangle = ucmd:GetViewAngles()
	nospreadangle.p = math.NormalizeAngle( nospreadangle.p )
	nospreadangle.y = math.NormalizeAngle( nospreadangle.y )
	
	local correct = 1
	nospreadangle.p = math.Clamp( nospreadangle.p + ( ucmd:GetMouseY() * 0.022 ), -89, 89 )
	nospreadangle.y = math.NormalizeAngle( nospreadangle.y + ( ucmd:GetMouseX() * -0.022 ) )
	ucmd:SetViewAngles( nospreadangle )
	
	if ( ucmd:GetButtons() && IN_ATTACK > 0 ) then
		local fakeang = PredictSpread( ucmd, nospreadangle )
		fakeang.p = math.NormalizeAngle( fakeang.p )				
		fakeang.y = math.NormalizeAngle( fakeang.y )
		ucmd:SetViewAngles( fakeang )
	end
end
hook.Add("CreateMove","testsetsetes",NoSpread)


local gm = table.Copy( GAMEMODE )
function GAMEMODE:CalcView( ply, origin, angles, fov )
	local view = gm.CalcView( self, ply, origin, angles, fov ) || {};
	view.angles = nospreadangle
return view;
end
