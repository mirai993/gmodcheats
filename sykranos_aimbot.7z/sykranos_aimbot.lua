--[[
	lua/aimbot.lua
	killer | (STEAM_0:0:19370286)
	===DStream===
]]

local function ShouldAttack()
	if input.IsKeyDown(KEY_F) then
		return true
	end
return false
end

function TargetVisible( e, spos, apos, w )
if not w then w = LocalPlayer():GetActiveWeapon() end
local trace = util.TraceLine( {
start = spos,
endpos = apos,
mask = MASK_SHOT,
filter = { LocalPlayer(), e }
} )

return trace.Fraction > .99
end

local function GetClosest( entities )

local pos = LocalPlayer():GetEyeTrace().HitPos

if ( !pos ) then return; end

local dist, r_ent;
for _, ent in pairs( entities ) do 

local tdist = ent:GetPos():Distance( pos );

if ( !r_ent || !dist || tdist < dist ) then 

r_ent = ent;
dist = tdist;

end

end

return r_ent;

end

local function CalcPos(ply)
	if IsValid(ply) then
		if type(ply) == 'Player' then
		pos = vdc.GetHitboxPos(ply:EntIndex(),0) --or (entity:LocalToWorld( entity:OBBCenter()))
		end
	end
return pos
end

local function IsSpectator(pl)
	if pl:GetObserverMode() != 0 or string.find(string.lower(team.GetName(pl)),'spectator') or pl:GetMoveType() == 'MOVETYPE_OBSERVER' then
		return true
	end
return false
end

local function Aimbot(c)
local ply = table.Random(player.GetAll())
--local ply = GetClosest(player.GetAll())
	if (ply:Alive()) and LocalPlayer() != ply then
	if (!vdc.IsDormant(ply:EntIndex())) then

		
		if (ShouldAttack()) then
			if (!IsSpectator(ply)) then
				if TargetVisible(ply,LocalPlayer():EyePos(),ply:EyePos())  then
				
				--local ang = (CalcPos(ply) - LocalPlayer():GetShootPos():Angle())


				local ang = (CalcPos(ply) - LocalPlayer():GetShootPos()):Angle()
				ang.p = math.NormalizeAngle(ang.p)
				ang.y = math.NormalizeAngle(ang.y)
				ang.r = 0
					
					 MsgN(ang)
					 if not string.find(tostring(ang),'#') then
					c:SetViewAngles(ang)
					c:SetButtons(bit.bor(c:GetButtons(),IN_ATTACK))
					end
				end
			end
		end
	end
end
end
hook.Add("CreateMove","Aimbot",Aimbot)
