 /* FROM ME THE RAZOR */
 
    /* locals */
 
    local next = next;
    local type = type;
    local require = require;
 
    local function copytable(orig)
        return table.Copy(orig)
    end
 
    require("dickwrap");
    require("bsendpacket")
 
    local dickwrap = copytable(dickwrap);
    local surface = copytable(surface);
    local player = copytable(player);
    local string = copytable(string);
    local util = copytable(util);
    local render = copytable(render);
    local input = copytable(input);
    local http = copytable(http, true);
    local timer = copytable(timer);
    local file = copytable(file);
    local game = copytable(game);
    local vgui = copytable(vgui);
    local table = copytable(table);
    local physenv = copytable(physenv);
    local bit = copytable(bit);
    local gameevent = copytable(gameevent);
    local math = copytable(math);
    local cam = copytable(cam);
    local engine = copytable(engine);
 
    local Color = Color;
    local Vector = Vector;
    local Angle = Angle;
    local print = print;
    local FindMetaTable = FindMetaTable;
    local GetConVarNumber = GetConVarNumber;
    local GetConVar = GetConVar;
    local LocalPlayer = LocalPlayer;
    local IsFirstTimePredicted = IsFirstTimePredicted;
    local CurTime = CurTime;
    local Material = Material;
    local ScrW = ScrW;
    local Entity = Entity;
    local RealFrameTime = RealFrameTime;
    local ScrH = ScrH;
 
    local EntM, PlyM, CmdM, VecM, WepM, AngM, MatM, ConM;
 
    EntM = copytable(FindMetaTable"Entity");
    PlyM = copytable(FindMetaTable"Player");
    CmdM = copytable(FindMetaTable"CUserCmd");
    VecM = copytable(FindMetaTable"Vector");
    WepM = copytable(FindMetaTable"Weapon");
    AngM = copytable(FindMetaTable"Angle");
    MatM = copytable(FindMetaTable"IMaterial");
    ConM = copytable(FindMetaTable"ConVar");
 
    /* hook */
 
    GAMEMODE["storedFuncs"] = GAMEMODE["storedFuncs"] || {};
    GAMEMODE["addedHooks"] = GAMEMODE["addedHooks"] || {};
 
    GAMEMODE["AddHook"] = function(self, type, name, func)
        self["addedHooks"][type] = self["addedHooks"][type] || {};
 
        self["addedHooks"][type][name] = func;
 
        self["storedFuncs"][type] = self["storedFuncs"][type] || function() end;
 
        self[type] = function(self, ...)
        self["storedFuncs"][type](self, ...);
 
        for k,v in next, self["addedHooks"][type] do
            local args = {v(...)};
            if(#args == 0) then continue; end
            return(unpack(args));
        end
 
        end
    end
 
    GAMEMODE["RemoveHook"] = function(self, type, name)
        if(!self["addedHooks"][type]) then return; end
        self["addedHooks"][type][name] = nil;
    end
 
    GAMEMODE["RemoveDetour"] = function(self, type)
        if(!self["storedFuncs"][type]) then return; end
        self[type] = self["storedFuncs"][type];
    end
 
    /* other vars */
 
    local me = LocalPlayer();
    local oldAngles = Angle();
 
    /* init stuff */
 
    gameevent.Listen("entity_killed");
 
    /* utility functions */
 
    local function normalizeAngle(ang)
        ang.p = math.NormalizeAngle(ang.p);
        ang.p = math.Clamp(ang.p, -89, 89);
 
        ang.y = math.NormalizeAngle(ang.y);
    end
 
    local function FixMovement(ucmd, antiAim)
        local move = Vector(CmdM.GetForwardMove(ucmd), CmdM.GetSideMove(ucmd), CmdM.GetUpMove(ucmd));
        local speed = math.sqrt(move.x * move.x + move.y * move.y);
        local ang = VecM.Angle(move);
        local yaw = math.rad(CmdM.GetViewAngles(ucmd).y - oldAngles.y + ang.y);
        CmdM.SetForwardMove(ucmd, (math.cos(yaw) * speed) * ( antiAim && -1 || 1 ));
        CmdM.SetSideMove(ucmd, math.sin(yaw) * speed);
    end
 
    local function mouseInArea(x, y, w, h, self)
        local mx, my = self:GetPos();
 
        local minx, miny = mx + x, my + y;
        local maxx, maxy = minx + w, miny + h;
 
        local cx, cy = input.GetCursorPos();
 
        return(cx < maxx && cx > minx && cy < maxy && cy > miny);
    end
 
    /* menu */
 
    local menuVars = {
        {
            "Aimbot",
            false,
            {},
            {"Checkbox", "Enabled", false};
            {"Checkbox", "Nextshot", false};
            {"Checkbox", "On Key", false};
            {"Checkbox", "Autofire", false};
            {"Checkbox", "Silent", false};
            {"Checkbox", "pSilent", false};
            {"Checkbox", "Bone Scan", false};
            {"Checkbox", "Bullettime", false};
            {"Checkbox", "Autopistol", false};
            {"Checkbox", "Ignore NEWSBOT", false};
            {"Checkbox", "Ignore Friends", false};
            {"Checkbox", "Ignore Team", false};
        },
        {
            "Visuals",
            false,
            {},
            {"Checkbox", "Enabled", false},
            {"Checkbox", "2D Box", false},
            {"Checkbox", "3D Box", false},
            {"Checkbox", "Skeleton", false},
            {"Checkbox", "Show Hitboxes", false},
            {"Checkbox", "Bullet Traces", false},
            {"Checkbox", "Name", false},
            {"Checkbox", "Health", false},
            {"Checkbox", "Asus Walls", false},
            {"Checkbox", "Wireframe Viewmodel", false},
            {"Checkbox", "Mirror", false},
            {"Slider", "Mirror Scale", 8, 30},
            {"Slider", "FoV", 75, 130},
        },
        {
            "HvH",
            false,
            {},
            {"Checkbox", "AntiAim", false},
            {"Checkbox", "Fakeangles", false},
            {"Checkbox", "Static AA", false},
            {"Checkbox", "Fakelag", false},
            {"Checkbox", "Fakeedge", false},
            {"Checkbox", "Fakelag Prediction", false},
            {"Checkbox", "Invert AA Pitch", false},
            {"Checkbox", "Invert FA Pitch", false},
            {"Slider", "Fakelag Choke", 7, 14},
            {"Slider", "Fakelag Send", 3, 14},
            {"Slider", "AntiAim Pitch", 180, 180},
            {"Slider", "AntiAim Yaw", 180, 360},
            {"Slider", "Fakeangles Pitch", 181, 360},
            {"Slider", "Fakeangles Yaw", 180, 360},
        },
        {
            "Misc",
            false,
            {},
            {"Checkbox", "Bunnyhop", false},
            {"Checkbox", "Thirdperson", false},
            {"Checkbox", "I AM THE GREATEST", false},
            {"Checkbox", "HACKERMODE", false},
            {"Checkbox", "pSpeed", false},
            {"Checkbox", "SWAG", false},
            {"Slider", "pSpeed Speed", 6, 20},
            {"Slider", "HACKERMODE Density", 500, 1500},
        },
 
    };
 
    local function saveConfig()
        file.Write("newshack.txt", util.TableToJSON(menuVars, true));
    end
 
    local function loadConfig()
        local data = file.Read("newshack.txt", "DATA");
        if(!data) then return; end
        local tab = util.JSONToTable(data);
 
        local tabs = {};
 
        for __,_ in next, tab do
            tabs[_[1]] = _;
        end
 
        for k,v in next, menuVars do
            if(!tabs[v[1]]) then
                continue;
            end
            for ok, ov in next, tabs[v[1]] do
                if(ok < 3) then continue; end
                for nk, nv in next, v do
                    if(nk < 3) then continue; end
                    if(nv[2] == ov[2]) then
                        nv[3] = ov[3];
                        if(nv[1] == "Slider") then
                            nv[5] = ov[5];
                        end
                    end
                end
            end
        end
    end
 
    loadConfig();
 
    local breakingnewsloop = {
        "p$ilent Pa$tes More than ever",
        "Senator Is Still A fag",
		"Shameless owns all",
    };
 
    local breakingnewsx = 0;
    local breakingnewsindex = 1;
 
    local function createBreakingNews()
        local firstFrame = vgui.Create("DFrame");
        local text = "Pa$ting News";
        surface.SetFont("TargetID");
        local tw, th = surface.GetTextSize(text);
        firstFrame:SetTitle("");
        firstFrame:SetPos(0, 0);
        firstFrame:SetSize(5 + tw + 5, 30);
        firstFrame:SetVisible(true);
        firstFrame:SetDraggable(false);
        firstFrame:ShowCloseButton(false);
        function firstFrame:Paint(w, h)
            surface.SetDrawColor(120, 120, 120, 180);
            surface.DrawRect(0, 0, w, h);
            surface.SetDrawColor(0, 0, 0);
            surface.DrawLine(99, h - 1, w, h - 1);
            surface.SetTextColor(math.cos(CurTime()) * 255, math.sin(CurTime()) * 255, math.abs(math.sin(CurTime()) - math.cos(CurTime())) * 255 );
            surface.SetFont("TargetID");
            local tw, th = surface.GetTextSize(text);
            surface.SetTextPos(5, 15 - th / 2);
            surface.DrawText(text);
        end
        
        local secondFrame = vgui.Create("DFrame");
        secondFrame:SetSize(ScrW() - 10 - tw, 30);
        secondFrame:SetVisible(true);
        secondFrame:SetDraggable(false);
        secondFrame:SetTitle("");
        secondFrame:ShowCloseButton(false);
        secondFrame:SetPos(10 + tw, 0);
 
        function secondFrame:Paint(w, h)
            surface.SetDrawColor(120, 120, 120, 180);
            surface.DrawRect(0, 0, w, h);
            surface.SetDrawColor(0, 0, 0);
            surface.DrawLine(0, h - 1, w, h - 1);
            if(breakingnewsindex == 0) then
                breakingnewsindex = 1;
            elseif(breakingnewsindex > #breakingnewsloop) then
                breakingnewsindex = 1;
            end
            if(!breakingnewsloop[breakingnewsindex]) then
                breakingnewsindex = 1;
            end
            local text = breakingnewsloop[breakingnewsindex];
            breakingnewsx = breakingnewsx + RealFrameTime() * 250 ;
            surface.SetFont("TargetID");
            local tw, th = surface.GetTextSize(text);
            surface.SetTextPos(w - breakingnewsx, 15 - th / 2);
            surface.SetTextColor(220, 220, 220);
            surface.DrawText(text);
 
            if(breakingnewsx > w + tw) then
                breakingnewsx = 0;
                breakingnewsindex = breakingnewsindex + 1;
            end
        end
 
        return firstFrame, secondFrame;
    end
 
    local function gBool(subMenu, sOption)
        local sub;
        for k,v in next, menuVars do
            if(v[1] != subMenu) then continue; end
            sub = v;
            break;
        end
        for k,v in next, sub do
            if(k <= 3) then continue; end
            if(v[2] == sOption) then return v[3]; end
        end
        return false;
    end
 
    local mDownArray = {};
 
    local frames = {};
    local menuOpen, insertDown, mouseDown;
 
    local function drawCheckbox(checkBox, iHeight, self, sLabel)
        local bMouse = mouseInArea(5, iHeight, 12, 12, self);
 
        if(bMouse && !mDownArray[sLabel] && input.IsMouseDown(MOUSE_LEFT)) then
            checkBox[3] = !checkBox[3];
        end
 
        local draw;
 
        if(bMouse && !checkBox[3]) then
            draw = true;
            surface.SetDrawColor(50, 50, 50, 120);
        elseif(bMouse && checkBox[3]) then
            draw = true;
            surface.SetDrawColor(90, 90, 90, 120);
        end
 
        if(draw) then
            surface.DrawRect(5, iHeight, 12, 12);
        end
 
        surface.SetDrawColor(0, 0, 0);
        surface.DrawOutlinedRect(5, iHeight, 12, 12);
 
        if(checkBox[3]) then
            surface.DrawRect(8, iHeight + 3, 6, 6);
        end
 
        surface.SetFont("BudgetLabel");
 
        local tw, th = surface.GetTextSize(checkBox[2]);
 
        surface.SetTextColor(220, 220, 220);
        surface.SetTextPos(5 + 12 + 5, iHeight + 6 - th / 2);
        surface.DrawText(checkBox[2]);
    end
 
    local function drawSlider(sliderElement, iHeight, self, sLabel)
        if(!sliderElement[5]) then
            sliderElement[5] = sliderElement[3];
        end
        local currentNumber = sliderElement[3];
        local max = sliderElement[4];
        surface.SetDrawColor(50, 50, 50);
        surface.DrawRect(5, iHeight, 190, 16);
        local width = math.ceil(sliderElement[5] * 190 / max);
        surface.SetDrawColor(255, 93, 0);
        surface.DrawRect(5, iHeight, width, 16);
        surface.SetTextColor(220, 220, 220);
        surface.SetFont("BudgetLabel");
        local tw, th = surface.GetTextSize(sliderElement[2]..": "..currentNumber);
        surface.SetTextPos(10, iHeight + 8 - th / 2);
        surface.DrawText(sliderElement[2]..": "..currentNumber);
 
        local bMouse = mouseInArea(5, iHeight, 190, 16, self);
 
        if(bMouse && input.IsMouseDown(MOUSE_LEFT)) then
            local mw, mh = input.GetCursorPos();
            local mx, my = self:GetPos();
            local new = ( ((mw - (mx + 5 - 190)) - (190 + 1)) / (190 - 2) * max);
            sliderElement[3] = math.ceil(new);    
            sliderElement[5] = new;    
        end
    end
 
    local function getHeight(subMenu)
        local ret = 0;
        for i = 3, #subMenu do
            local element = subMenu[i];
            if(element[1] == "Checkbox") then
                ret = ret + 16;
            elseif(element[1] == "Slider") then
                ret = ret + 20;
            end
        end
        return ret;
    end
 
    local function createNewSub(subMenu, iIndex)
        local newFrame = vgui.Create("DFrame");
        newFrame:SetSize(200, 26 + getHeight(subMenu) + 10);
        newFrame:SetTitle("");
        newFrame:ShowCloseButton(false);
        newFrame:MakePopup();
        if(subMenu[3][1]) then
            newFrame:SetPos(subMenu[3][1], subMenu[3][2]);
        else
            newFrame:SetPos(110 + iIndex * 205, 40);
        end
 
        function newFrame:Paint(w, h)
            local x, y = self:GetPos();
            subMenu[3][1] = x;
            subMenu[3][2] = y;
 
            surface.SetDrawColor(150, 150, 150, 180);
            surface.DrawRect(0, 0, w, h);
 
            surface.SetDrawColor(0, 0, 0, 180);
            surface.DrawRect(0, 0, w, 26);
            surface.SetDrawColor(0, 0, 0);
            surface.DrawOutlinedRect(0, 0, w, h);
            surface.DrawOutlinedRect(0, 0, w, 26);
 
            surface.SetFont("BudgetLabel");
            local tw, th = surface.GetTextSize(subMenu[1]);
            surface.SetTextColor(220, 220, 220);
            surface.SetTextPos(5, 13 - th / 2);
            surface.DrawText(subMenu[1]);
 
            local height = 32;
 
            for k,v in next, subMenu do
                if(k <= 3) then
                    continue;
                end
                if(v[1] == "Checkbox") then
                    drawCheckbox(v, height, self, subMenu[1]);
                    height = height + 16;
                elseif(v[1] == "Slider") then
                    drawSlider(v, height, self);
                    height = height + 20;
                end
            end
 
            mDownArray[subMenu[1]] = input.IsMouseDown(MOUSE_LEFT);
        end
 
        return newFrame;
    end
 
    local function adjustSub(subMenu)
        local sub, index;
        for k,v in next, menuVars do
            if (v[1] == subMenu) then
                sub = v;
                index = k;
            end
        end
        if(!sub) then return; end
 
        if(!sub[2]) then
            if(frames[subMenu]) then
                frames[subMenu]:Close();
            end
        else
            frames[subMenu] = createNewSub(sub, index - 1);
        end
    end
 
    local function drawOptions(self)
        local hh = 0;
        for k,v in next, menuVars do
 
            local bMouse = mouseInArea(10, hh, 80, 20, self);
 
            if(bMouse && input.IsMouseDown(MOUSE_LEFT) && !mouseDown) then
                v[2] = !v[2];
                adjustSub(v[1]);
            end
 
            local color = Color(100, 100, 100);
 
            if(bMouse && !v[2]) then
                color = Color(120, 120, 120);
            elseif(v[2] && !bMouse) then
                color = Color(150, 150, 150);
            elseif(v[2] && bMouse) then
                color = Color(170, 170, 170);
            end
 
            surface.SetDrawColor(color.r, color.g, color.b);
            surface.DrawRect(10, hh, 80, 20);
            surface.SetDrawColor(0, 0, 0);
            surface.DrawOutlinedRect(10, hh, 80, 20);
            surface.SetFont("BudgetLabel");
            local tw, th = surface.GetTextSize(v[1]);
            surface.SetTextPos(50 - tw / 2, hh + 10 - th / 2);
            surface.SetTextColor(220, 220, 220);
            surface.DrawText(v[1]);
 
            hh = hh + 25;
        end    
    end
 
    local function paintMain(w, h, self)
        local cur = 120;
 
        surface.SetFont("BudgetLabel");
        surface.SetTextColor(220, 220, 220);
        local tw, th = surface.GetTextSize("+++ NEWSBOT +++")
 
        surface.DisableClipping(true);
        surface.SetTextPos(ScrW() - tw - 5, 15 - th + 2);
        surface.DrawText("+++ PA$TE BOT +++");
 
        surface.DisableClipping(false);
 
        for i = 0, h do
            local sub = 120 / h;
            cur = cur - sub;
            surface.SetDrawColor(cur, cur, cur, 180);
            surface.DrawLine(0, i, ScrW(), i);
        end
 
        surface.SetDrawColor(0, 0, 0);
        surface.DrawLine(w - 1, 0, w - 1, h);
 
        drawOptions(self);
    end
 
    local paintIsDown;
 
    local hackerModeLetters = {};
    local hackerModeLettersTable = {
        "a",
        "b",
        "c",
        "d",
        "e",
        "f",
        "g",
        "h",
        "i",
        "j",
        "k",
        "l",
        "m",
        "n",
        "o",
        "p",
        "q",
        "r",
        "s",
        "t",
        "u",
        "v",
        "w",
        "x",
        "y",
        "z",
        "A",
        "B",
        "C",
        "D",
        "E",
        "F",
        "G",
        "H",
        "I",
        "J",
        "K",
        "L",
        "M",
        "N",
        "O",
        "P",
        "Q",
        "R",
        "S",
        "T",
        "U",
        "V",
        "W",
        "X",
        "Y",
        "Z",
        "0",
        "1",
        "2",
        "3",
        "4",
        "5",
        "6",
        "7",
        "8",
        "9",
        "/",
        "\\",
        "!",
        "$",
        "%",
        "&",
        "(",
        ")",
        "{",
        "}",
    }
 
    local function paintLoad(w, h, self)
        local color = Color(100, 100, 100);
        local bMouse = mouseInArea(10, h - 30, 80, 20, self);
        if(bMouse && !input.IsMouseDown(MOUSE_LEFT)) then
            color = Color(120, 120, 120);
        elseif (bMouse && input.IsMouseDown(MOUSE_LEFT)) then
            color = Color(150, 150, 150);
            if(!paintIsDown) then
                loadConfig();
            end
        end
        surface.SetDrawColor(color.r, color.g, color.b);
        surface.DrawRect(10, h - 30, 80, 20);
        surface.SetDrawColor(0, 0, 0);
        surface.DrawOutlinedRect(10, h - 30, 80, 20);
        surface.SetFont("BudgetLabel");
        surface.SetTextColor(220, 220, 220);
        local tw, th = surface.GetTextSize("Load");
        surface.SetTextPos(10 + 40 - tw / 2, h - 30 + 10 - th / 2);
        surface.DrawText("Load")
        paintIsDown = input.IsMouseDown(MOUSE_LEFT);
    end
 
    local function paintSave(w, h, self)
        local color = Color(100, 100, 100);
        local bMouse = mouseInArea(10, h - 55, 80, 20, self);
        if(bMouse && !input.IsMouseDown(MOUSE_LEFT)) then
            color = Color(120, 120, 120);
        elseif (bMouse && input.IsMouseDown(MOUSE_LEFT)) then
            color = Color(150, 150, 150);
            if(!paintIsDown) then
                saveConfig();
            end
        end
        surface.SetDrawColor(color.r, color.g, color.b);
        surface.DrawRect(10, h - 55, 80, 20);
        surface.SetDrawColor(0, 0, 0);
        surface.DrawOutlinedRect(10, h - 55, 80, 20);
        surface.SetFont("BudgetLabel");
        surface.SetTextColor(220, 220, 220);
        local tw, th = surface.GetTextSize("Save");
        surface.SetTextPos(10 + 40 - tw / 2, h - 55 + 10 - th / 2);
        surface.DrawText("Save")
    end
 
    local function createMenu()
        local newFrame = vgui.Create("DFrame");
        newFrame:SetSize(100, ScrH() - 30);
        newFrame:SetPos(0, 30);
        newFrame:ShowCloseButton(false);
        newFrame:SetTitle("");
        newFrame:MakePopup();
        function newFrame:Paint(w, h)
            paintMain(w, h, self);
            paintSave(w, h, self);
            paintLoad(w, h, self);
            mouseDown = input.IsMouseDown(MOUSE_LEFT);
        end
 
        function newFrame:Think()
 
        end
 
        for k,v in next, menuVars do
            adjustSub(v[1]);
        end
 
        return newFrame;
    end
 
    local function changeState()
        if(menuOpen) then
            for k,v in next, frames do
                if(!v:IsValid()) then continue; end
                v:Close();
            end
            frames = {};
            menuOpen = false;
        else
            breakingnewsx = 0;
            --breakingnewsindex = 1;
            frames[1] = createMenu();
            local f1, f2 = createBreakingNews();
            frames[2] = f1;
            frames[3] = f2;
            --frames[4] = playSong();
            menuOpen = true;
        end
    end
 
    local function Think()
        if(input.IsKeyDown(KEY_INSERT) && !insertDown) then
            changeState();
        end
        insertDown = input.IsKeyDown(KEY_INSERT);
    end
 
    GAMEMODE:AddHook("Think", "", Think);
 
    /* i am the greatest meme */
 
    local function entity_killed(info)
 
        if(!gBool("Misc", "I AM THE GREATEST")) then return; end
 
        local killer = Entity(info.entindex_attacker);
        local killed = Entity(info.entindex_killed);
 
        if(!EntM.IsValid(killer) || !EntM.IsValid(killed) || killer != me || killer == killed || !killed:IsPlayer()) then
            return;
        end
 
        PlyM.ConCommand(me, "say +++ BREAKING NEWS +++ NEWSBOT IS SHIT");
    end
 
    GAMEMODE:AddHook("entity_killed", "", entity_killed);
 
    /* esp meme */
 
    local function box(ply)
        local pos = EntM.GetPos(ply);
        local min, max = EntM.GetCollisionBounds(ply);
        local pos2 = pos + Vector(0, 0, max.z);
        local pos = VecM.ToScreen(pos);
        local pos2 = VecM.ToScreen(pos2);
 
        local h = pos.y - pos2.y;
        local w = h / 1.7;
 
        if(gBool("Visuals", "2D Box")) then
 
            surface.SetDrawColor(255, 0, 0);
            surface.DrawOutlinedRect(pos.x - w / 2, pos.y - h, w, h);
            surface.SetDrawColor(0, 0, 0);
            surface.DrawOutlinedRect(pos.x - w / 2 - 1, pos.y - h - 1, w + 2, h + 2);
            surface.DrawOutlinedRect(pos.x - w / 2 + 1, pos.y - h + 1, w - 2, h - 2);
 
        end
 
        if(gBool("Visuals", "Health")) then
 
            local hp = EntM.Health(ply);
            if(hp > 100) then hp = 100; end
            local hp = hp * h / 100;
 
            local diff = hp - h;
 
            surface.SetDrawColor(0, 0, 0);
            surface.DrawRect(pos.x - w / 2 - 5, pos.y - h - 1, 3, h + 2);
            local ihp = EntM.Health(ply);
            surface.SetDrawColor((100 - ihp) * 2.55, ihp * 2.55, 0);
            surface.DrawRect(pos.x - w / 2 - 4, pos.y - h - diff, 1, hp);
 
        end
 
        if(gBool("Visuals", "3D Box")) then
            local pos = EntM.GetPos(ply);
            local min, max = EntM.GetCollisionBounds(ply);
            min = min + pos;
            max = max + pos;
            local corners = {
                Vector(min.x, min.y, min.z);
                Vector(max.x, min.y, min.z);
                Vector(max.x, max.y, min.z);
                Vector(min.x, max.y, min.z);
 
                Vector(min.x, min.y, max.z);
                Vector(max.x, min.y, max.z);
                Vector(max.x, max.y, max.z);
                Vector(min.x, max.y, max.z);
            };
 
            for k,v in next, corners do
                corners[k] = VecM.ToScreen(v);
            end
 
            surface.SetDrawColor(0, 161, 255);
 
            surface.DrawLine(corners[1].x, corners[1].y, corners[2].x, corners[2].y);
            surface.DrawLine(corners[2].x, corners[2].y, corners[3].x, corners[3].y);
            surface.DrawLine(corners[3].x, corners[3].y, corners[4].x, corners[4].y);
            surface.DrawLine(corners[4].x, corners[4].y, corners[1].x, corners[1].y);
 
            surface.DrawLine(corners[1].x, corners[1].y, corners[5].x, corners[5].y);
            surface.DrawLine(corners[2].x, corners[2].y, corners[6].x, corners[6].y);
            surface.DrawLine(corners[3].x, corners[3].y, corners[7].x, corners[7].y);
            surface.DrawLine(corners[4].x, corners[4].y, corners[8].x, corners[8].y);
 
            surface.DrawLine(corners[5].x, corners[5].y, corners[6].x, corners[6].y);
            surface.DrawLine(corners[6].x, corners[6].y, corners[7].x, corners[7].y);
            surface.DrawLine(corners[7].x, corners[7].y, corners[8].x, corners[8].y);
            surface.DrawLine(corners[8].x, corners[8].y, corners[5].x, corners[5].y);
        end
 
        if(gBool("Visuals", "Name")) then
 
            surface.SetFont("BudgetLabel");
            local name = PlyM.Name(ply);
            local tw, th = surface.GetTextSize(name);
            surface.SetTextPos(pos.x - tw / 2, pos.y);
            surface.SetTextColor(220, 220, 220);
            surface.DrawText(name);
 
        end
    end
 
    local function skeleton(ply)
        if(!gBool("Visuals", "Skeleton")) then
            return;
        end
        local pos = EntM.GetPos(ply);
        for i = 0, EntM.GetBoneCount(ply) do
            local parent = EntM.GetBoneParent(ply, i);
            if(!parent) then continue; end
            local bonepos = EntM.GetBonePosition(ply, i);
            if(bonepos == pos) then continue; end
            local parentpos = EntM.GetBonePosition(ply, parent);
            if(!bonepos || !parentpos) then continue; end
            local screen1, screen2 = VecM.ToScreen(bonepos), VecM.ToScreen(parentpos);
            surface.SetDrawColor(255, 255, 255);
            surface.DrawLine(screen1.x, screen1.y, screen2.x, screen2.y);
        end
    end
 
    local function esp()
        if(!gBool("Visuals", "Enabled")) then
            return;
        end
        for k,v in next, player.GetAll() do
            if(!EntM.IsValid(v) || v == me || EntM.Health(v) < 1 || PlyM.Team(v) == TEAM_SPECTATOR || EntM.IsDormant(v)) then
                continue;
            end
            box(v);
            skeleton(v);
        end
    end
 
    GAMEMODE:AddHook("DrawOverlay", "", esp);
 
    local function paintHackerMode()
        if(!gBool("Misc", "HACKERMODE")) then hackerModeLetters = {}; return; end
        local maxDists = ScrW() / 5;
        if(#hackerModeLetters < gBool("Misc", "HACKERMODE Density")) then
            for i = 0, 10 do
                hackerModeLetters[#hackerModeLetters + 1] = {
                    -20,
                    5 * math.random(maxDists),
                    math.random(1, 20),
                }
            end
        end
        for k,v in next, hackerModeLetters do
            surface.SetFont("BudgetLabel");
            v[1] = v[1] + v[3];
            if(v[1] >= ScrH()) then
                table.remove(hackerModeLetters, k);
                continue;
            end
            surface.SetTextColor(0, 255, 0);
            surface.SetTextPos(v[2], v[1]);
            surface.DrawText(hackerModeLettersTable[math.random(#hackerModeLettersTable)]);
        end
    end
 
    /* firebullets */
 
    local aimTarget, aimIgnore, aimPos;
    local cones = {};
    local nullvec = Vector() * -1;
 
    GAMEMODE:AddHook("EntityFireBullets", "", function(ply, data)
        aimIgnore = aimTarget;
        local spread = data.Spread * -1;
 
        local wep = EntM.GetClass(PlyM.GetActiveWeapon(ply));
 
        if(cones[wep] == spread) then return; end
        if(spread == nullvec) then return; end
 
        cones[wep] = spread;
    end);
 
    local function removeSpread(cmd, ang)
        local wep = PlyM.GetActiveWeapon(me);
        if(!wep || !EntM.IsValid(wep)) then return ang; end
        local class = EntM.GetClass(wep);
        if(!cones[class]) then return ang; end
        return VecM.Angle(dickwrap.Predict(cmd, AngM.Forward(ang), cones[class]));
    end
 
    /* aimb0t */
 
    local curTime = 0;
 
    local bulletTime;
 
    local reload = {
        [ACT_VM_RELOAD] = true,
        [ACT_VM_RELOAD_DEPLOYED] = true,
        [ACT_VM_RELOAD_EMPTY] = true,
        [ACT_VM_RELOAD_IDLE] = true,
        [ACT_VM_RELOAD_SILENCED] = true,
    }
 
    local function canFire()
        if(!gBool("Aimbot", "Bullettime")) then
            bulletTime = true;
            return;
        end
        bulletTime = false;
        local wep = PlyM.GetActiveWeapon(me);
        if(!wep || !EntM.IsValid(wep)) then return; end
 
        local clip = WepM.Clip1(wep);
        if(clip <= 0) then return; end
 
        if(reload[EntM.GetSequence(wep)]) then
            return;
        end
        
        local wepTime = WepM.GetNextPrimaryFire(wep);
 
        if(curTime >= wepTime) then
            bulletTime = true;
        end
    end
 
    local function move()
        if(!IsFirstTimePredicted()) then return; end
        curTime = CurTime() + engine.TickInterval();
    end
 
    GAMEMODE:AddHook("Move", "", move);
 
    local function bunnyHop(cmd)
        if(!gBool("Misc", "Bunnyhop")) then return; end
        if(CmdM.KeyDown(cmd, 2) && !EntM.IsOnGround(me)) then
            CmdM.RemoveKey(cmd, 2);
        end
    end
 
    local function fakeMouseSamples(cmd)
        normalizeAngle(oldAngles);
        oldAngles = oldAngles + Angle(CmdM.GetMouseY(cmd) * .022, CmdM.GetMouseX(cmd) * -.022, 0);
        normalizeAngle(oldAngles);
        if(gBool("Misc", "Thirdperson")) then return; end
        CmdM.SetViewAngles(cmd, oldAngles);
    end
 
    local steamIds = {
        ["STEAM_0:0:41191102"] = true,
        ["STEAM_0:1:53661328"] = true,
        ["STEAM_0:1:102370353"] = true,
        ["STEAM_0:1:53189353"] = true,
        ["STEAM_0:0:89312873"] = true,
    };
 
    local function Valid(v)
        if(!EntM.IsValid(v)) then return false; end
        if(v == me) then return false; end
        if(EntM.Health(v) < 1) then return false; end
        if(EntM.IsDormant(v)) then return false; end
 
        if(PlyM.Team(v) == TEAM_SPECTATOR) then return false; end
        if(PlyM.Team(v) == TEAM_CONNECTING) then return false; end
        if(gBool("Aimbot", "Ignore NEWSBOT") && steamIds[PlyM.SteamID(v)]) then return false; end
        if(gBool("Aimbot", "Ignore Friends") && PlyM.GetFriendStatus(v) == "friend") then return false; end
        if(gBool("Aimbot", "Ignore Team") && PlyM.Team(v) == PlyM.Team(me)) then return false; end
        return true;
    end
 
    local function isVisible(pos, ply)
        local trace = {
            start = EntM.EyePos(me),
            endpos = pos,
            mask = MASK_SHOT,
            filter = {me, ply},
        };
 
        return (util.TraceLine(trace).Fraction == 1);
    end
 
    //require("aaa");
 
    local function antiAntiAim(ply)
    end
 
    local fakelagBucket = {};
    local nullVel = Vector();
 
    local function fakelagPredict(v)
        if(!gBool("HvH", "Fakelag Prediction")) then return; end
        if(!fakelagBucket[v]) then
            fakelagBucket[v] = {
                EntM.GetVelocity(v),
                EntM.GetPos(v),
                0,
            };
        end
 
        local oldVel = fakelagBucket[v][1];
        local oldPos = fakelagBucket[v][2];
 
        fakelagBucket[v][1] = EntM.GetVelocity(v);
        fakelagBucket[v][2] = EntM.GetPos(v);
 
        if(oldVel == nullVel) then 
            fakelagBucket[v][3] = 0;
            return; 
        end
 
        if(fakelagBucket[v][1] == oldVel && oldPos == fakelagBucket[v][2]) then
            fakelagBucket[v][3] = fakelagBucket[v][3] + 1;
 
            return(oldVel + (oldVel * (engine.TickInterval() * fakelagBucket[v][3])));
        else
            fakelagBucket[v][3] = 0;
        end
    end
 
    local function boneScan(ply, fake)
        for group = 0, EntM.GetHitBoxGroupCount(ply)do
            local count = EntM.GetHitBoxCount( ply, group );
            for hitbox = 1, count do
                local bone = EntM.GetHitBoxBone(ply, hitbox, group);
                if(!bone) then continue; end
                local bonepos = EntM.GetBonePosition(ply, bone);
                if(!isVisible(bonepos + fake, ply)) then continue; end
                return bonepos + fake;
            end
        end
    end
 
    local function getPos(v, mypos)
        local dist = 0;
        local fake = fakelagPredict(v) || nullVel;
        if(mypos) then
            dist = VecM.Distance(mypos, EntM.GetPos(v));
        end
        local hitbox = EntM.GetHitBoxBone(v, 0, 0);
        if(!hitbox) then 
            local center = EntM.LocalToWorld(v, EntM.OBBCenter(v));
            if(!isVisible(center + fake, v)) then
                return;
            end
            return center + fake, dist;
        end
        local min, max = EntM.GetHitBoxBounds(v, 0, 0);
        local bonepos = EntM.GetBonePosition(v, hitbox);
 
        local pos = bonepos + ((min + max) * .5) + fake;
 
        if(!isVisible(pos, v)) then
            if(!gBool("Aimbot", "Bone Scan")) then
                return;
            end
            local pos = boneScan(v, fake);
            if(pos) then 
                return pos, dist; 
            else 
                return; 
            end
        end
 
        return pos, dist;
    end
 
    local function sorterFunc(a, b)
        return a[2] < b[2];
    end
 
    local function getTarget()
        local dists = {};
        local mypos = EntM.GetPos(me);
        for k,v in next, player.GetAll() do
            if(!Valid(v)) then continue; end
            local pos, distance = getPos(v, mypos);
            if(!pos) then continue; end
            dists[#dists + 1] = {v, distance, pos};
        end
 
        if(#dists == 0) then return; end
 
        table.sort(dists, sorterFunc);
 
        local target = dists[1];
 
        aimPos = target[3];
        aimTarget = target[1];
    end
 
    local function nextShot()
        local possibleTargets = {};
        for k,v in next, player.GetAll() do
            if(v == aimIgnore) then continue; end
            if(!Valid(v)) then continue; end
            local pos = getPos(v, mypos);
            if(!pos) then continue; end
            possibleTargets[#possibleTargets + 1] = {v, pos}
        end
        if(#possibleTargets == 0) then return; end
        local randomized = {};
        for k, v in next, possibleTargets do
            randomized[math.random(100)] = v;
        end
 
        for k,v in next, randomized do
            aimTarget = v[1];
            aimPos = v[2];
            break;
        end
    end
 
    local curCmd;
 
    local cinterp = GetConVar("cl_interp");
    local cratio = GetConVar("cl_interp_ratio");
    local cupdaterate = GetConVar("cl_updaterate");
    local cfriction = GetConVar("sv_friction");
    local caccelerate = GetConVar("sv_accelerate");
    local cairaccelerate = GetConVar("sv_airaccelerate");
    local cmaxvel = GetConVar("sv_maxvelocity");
    local cgravity = GetConVar("sv_gravity");
 
    local function getPredTickInterval()
        local interp = ConM.GetFloat(cinterp);
        local ratio = ConM.GetFloat(cratio);
        local cupdaterate = ConM.GetFloat(cupdaterate);
        local interpolation = math.max(interp, ratio / cupdaterate);
        local tickInt = engine.TickInterval() * interpolation;
        return tickInt;
    end
 
    local function CheckVelocity(origVel)
        local org = EntM.GetPos(me);
 
        for i = 1, 3 do
            if(origVel[i] > ConM.GetFloat(cmaxvel)) then
                origVel[i] = ConM.GetFloat(cmaxvel);
            elseif(origVel[i] < -ConM.GetFloat(cmaxvel)) then
                origVel[i] = -ConM.GetFloat(cmaxvel);
            end
        end
    end
 
    local function startGravity(origVel)
        local ent_gravity;
 
        if(EntM.GetGravity(me)) then
            ent_gravity = EntM.GetGravity(me);
        else
            ent_gravity = 1;
        end
 
        origVel[3] = origVel[3] - (ent_gravity * ConM.GetFloat(cgravity) * 0.5 * getPredTickInterval());
 
        CheckVelocity(origVel);
    end
 
    local function FinishGravity(origVel)
        local ent_gravity;
 
        if(EntM.GetGravity(me)) then
            ent_gravity = EntM.GetGravity(me);
        else
            ent_gravity = 1;
        end
 
        origVel[3] = origVel[3] - (ent_gravity * ConM.GetFloat(cgravity) * getPredTickInterval() * 0.5);
 
        CheckVelocity(origVel);
    end
 
    local function Friction(origVel, wishVel)
        local speed, newspeed, control;
        local friction;
        local drop;
 
        speed = VecM.Length(origVel);
 
        if(speed < 0.1) then
            return;
        end
 
        drop = 0;
 
        if(EntM.IsOnGround(me)) then
            friction = ConM.GetFloat(cfriction);
            drop = friction * getPredTickInterval(); 
        end
 
        newspeed = speed - drop;
 
        if(newspeed < 0) then
            newspeed = 0;
        end
 
        if(newspeed != speed) then
            newspeed = newspeed / speed;
            for i = 1, 3 do
                origVel[i] = origVel[i] * newspeed;
            end
        end
 
        wishVel = wishVel - (1 - newspeed) * origVel;
    end
 
    local function Accelerate(wishDir, wishSpeed, accelerate, velo)
        local currentSpeed = VecM.Dot(EntM.GetVelocity(me), wishDir);
        local addSpeed = wishSpeed - currentSpeed;
        
        if(addSpeed <= 0) then
            return;
        end
 
        local accelSpeed = accelerate * getPredTickInterval() * wishSpeed * 1;
 
        if(accelSpeed > addSpeed) then
            accelSpeed = addSpeed;
        end
 
        for i = 1, 3 do
            velo[i] = velo[i] + accelSpeed * wishDir[i];
        end
    end
 
    local function AirAccelerate(wishDir, wishSpeed, accelerate, velo)
        local currentSpeed = VecM.Dot(EntM.GetVelocity(me), wishDir);
        local addSpeed = wishSpeed - currentSpeed;
        
        if(addSpeed <= 0) then
            return;
        end
 
        local accelSpeed = accelerate * wishSpeed * getPredTickInterval() * 1;
 
        if(accelSpeed > addSpeed) then
            accelSpeed = addSpeed;
        end
 
        for i = 1, 3 do
            velo[i] = velo[i] + accelSpeed * wishDir[i];
        end
    end
 
    local function airMove(outWishVel)
        local wishVel = Vector();
        local speed = 0;
        local forwardMove, sideMove = 0;
        local wishDir = Vector();
        local wishSpeed = 0;
 
        local distance = Vector();
        local forward, right, up;
 
        local eyeAngs = EntM.EyeAngles(me);
 
        forward = AngM.Forward(eyeAngs);
        right = AngM.Right(eyeAngs);
        up = AngM.Up(eyeAngs);
 
        local groundEntity = EntM.GetGroundEntity(me);
 
        forwardMove = CmdM.GetForwardMove(curCmd);
        sideMove = CmdM.GetSideMove(curCmd);
 
        if(forward.z != 0) then
            forward.z = 0;
            VecM.Normalize(forward);
        end
 
        if(right.z != 0) then
            right.z = 0;
            VecM.Normalize(right);
        end
 
        for i = 1, 3 do
            wishVel[i] = forward[i] * forwardMove + right[i] * sideMove;
        end
 
        wishVel.z = 0;
 
        wishDir = Vector(wishVel.x, wishVel.y, wishVel.z);
 
        local mag = VecM.Length(wishDir);
        local den = 1 / (mag + 1.19209290E-07);
        wishDir.x = wishDir.x * den;
        wishDir.y = wishDir.y * den;
        wishDir.z = wishDir.z * den;
 
        wishSpeed = mag;
 
        local maxSpeed = ConM.GetFloat(cmaxvel);
 
        if(wishSpeed > maxSpeed) then
            for i = 1, 3 do
                wishVel[i] = wishVel[i] / (maxSpeed/wishSpeed);
            end
            wishSpeed = maxSpeed;
        end
 
        local myVel = EntM.GetVelocity(me);
 
        AirAccelerate(wishDir, wishSpeed, ConM.GetFloat(cairaccelerate), outWishVel);
 
        outWishVel = outWishVel + wishDir * wishSpeed;
    end
 
    local function walkMove(outWishVel)
        local wishVel = Vector();
        local speed = 0;
        local forwardMove, sideMove = 0;
        local wishDir = Vector();
        local wishSpeed = 0;
 
        local distance = Vector();
        local forward, right, up;
 
        local eyeAngs = EntM.EyeAngles(me);
 
        forward = AngM.Forward(eyeAngs);
        right = AngM.Right(eyeAngs);
        up = AngM.Up(eyeAngs);
 
        local groundEntity = EntM.GetGroundEntity(me);
 
        forwardMove = CmdM.GetForwardMove(curCmd);
        sideMove = CmdM.GetSideMove(curCmd);
 
        if(forward.z != 0) then
            forward.z = 0;
            VecM.Normalize(forward);
        end
 
        if(right.z != 0) then
            right.z = 0;
            VecM.Normalize(right);
        end
 
        for i = 1, 3 do
            wishVel[i] = forward[i] * forwardMove + right[i] * sideMove;
        end
 
        wishVel.z = 0;
 
        wishDir = Vector(wishVel.x, wishVel.y, wishVel.z);
 
        local mag = VecM.Length(wishDir);
        local den = 1 / (mag + 1.19209290E-07);
        wishDir.x = wishDir.x * den;
        wishDir.y = wishDir.y * den;
        wishDir.z = wishDir.z * den;
 
        wishSpeed = mag;
 
        local maxSpeed;
 
        if(PlyM.KeyDown(me, IN_DUCK)) then
            maxSpeed = PlyM.GetCrouchedWalkSpeed(me);
        elseif(PlyM.KeyDown(me, IN_SPEED)) then
            maxSpeed = PlyM.GetRunSpeed(me);
        else
            maxSpeed = PlyM.GetWalkSpeed(me);
        end
 
        if(wishSpeed > maxSpeed) then
            for i = 1, 3 do
                wishVel[i] = wishVel[i] / (maxSpeed/wishSpeed);
            end
            wishSpeed = maxSpeed;
        end
 
        local myVel = EntM.GetVelocity(me);
        myVel.z = 0;
        Accelerate(wishDir, wishSpeed, ConM.GetFloat(caccelerate), outWishVel);
        myVel.z = 0;
 
        myVel.x = myVel.x * getPredTickInterval();
        myVel.y = myVel.y * getPredTickInterval();
 
        outWishVel = outWishVel + wishDir * wishSpeed;
    end
 
    local function fullWalkMove(origVel, origAngles, m_vecForward, m_vecRight, m_vecUp)
        startGravity(origVel);
 
        local outWishVel = Vector(origVel.x, origVel.y, origVel.z);
 
        if(EntM.IsOnGround(me)) then
            outWishVel[3] = 0;
            Friction(origVel, outWishVel);
        end
 
        CheckVelocity(outWishVel);
        if(EntM.IsOnGround(me)) then
            walkMove(outWishVel);
        else
            airMove(outWishVel);
        end
 
        CheckVelocity(outWishVel);
 
        FinishGravity(outWishVel);
 
        if(EntM.IsOnGround(me)) then
            outWishVel[3] = 0;
        end
 
        aimPos = aimPos + outWishVel * getPredTickInterval();
    end
 
    local function predict()
        local origVel = EntM.GetVelocity(me);
        local origAngles = EntM.EyeAngles(me);
        local m_vecForward;
        local m_vecRight;
        local m_vecUp;
 
        m_vecForward = AngM.Forward(origAngles);
        m_vecRight = AngM.Right(origAngles);
        m_vecUp = AngM.Up(origAngles);
 
        local fallVelocity = 0;
 
        if(!EntM.IsOnGround(me)) then
            fallVelocity = -origVel[3];
        end
 
        local moveType = EntM.GetMoveType(me);
 
        if(moveType == MOVETYPE_WALK) then
            fullWalkMove(origVel, origAngles, m_vecForward, m_vecRight, m_vecUp);
        end
    end
 
    local fakechoke = 0;
 
    local function aimBot(cmd)
        curCmd = cmd;
        if(!bulletTime) then return; end
        if(gBool("Aimbot", "On Key") && !input.IsKeyDown(KEY_N)) then return; end
        if(gBool("Aimbot", "Nextshot")) then
            nextShot();
        else
            getTarget();
        end
 
        if(!aimTarget) then return; end
        predict();
        local ang = VecM.Angle(aimPos - EntM.EyePos(me));
        ang = removeSpread(cmd, ang);
        ang.x = math.NormalizeAngle(ang.x);
        ang.y = math.NormalizeAngle(ang.y);
 
        local static = gBool("HvH", "Static AA");
 
        if(static && bulletTime) then
            local oang = ang;
            ang.x = -180 - oang.x + 720;
            ang.y = ang.y +    180;
            --ang.y = fuckUp(ang.y);
        end
 
        CmdM.SetViewAngles(cmd, ang);
 
        if(gBool("Aimbot", "Silent")) then
            FixMovement(cmd, static);
        else
            oldAngles = ang;
        end
 
        if(gBool("Aimbot", "Autofire")) then
            CmdM.SetButtons(cmd, bit.bor(CmdM.GetButtons(cmd), 1));
        end
 
        if(gBool("Aimbot", "pSilent")) then
            bSendPacket = false;
        end
    end
 
    local loop = {1, 6, 11, 16};
    local aaLoop = 1;
 
    local function autoPistol(cmd)
        if(!gBool("Aimbot", "Autopistol")) then return; end
        if(PlyM.KeyDown(me, 1)) then
            CmdM.RemoveKey(cmd, 1);
        end
    end
 
    bSendPacket = true;
    pspeed = gBool("Misc", "pSpeed");
    pspeedspeed = gBool("Misc", "pSpeed Speed");
    //require("hi"); // module (c) me 2015
 
    local function pSpeed()
        pspeed = gBool("Misc", "pSpeed");
        pspeedspeed = gBool("Misc", "pSpeed Speed");
    end
 
    local fakelagTick, fakelagSend = 0;
    local switch;
 
    local edgeAngle, edgeBool;
 
    local function getX(up)
        local x = gBool("HvH", "AntiAim Pitch");
        if(gBool("HvH", "Invert AA Pitch")) then
            x = -x;
        end
 
        if(x > 180) then return (up && x || -x); end
        if(x < 180) then return (up && -x || x); end
        return x;
    end
 
    local function antiAim(cmd)
        if(!gBool("HvH", "AntiAim")) then return; end
        if(aimTarget) then return; end
        if(CmdM.KeyDown(cmd, 1) && bulletTime) then return; end
        if(aaLoop > #loop) then aaLoop = 1; end
        local yaw = gBool("HvH", "AntiAim Yaw");
        if(gBool("HvH", "Fakelag")) then
            if(gBool("HvH", "Fakeangles")) then
                if(!bSendPacket) then
                    CmdM.SetViewAngles(cmd, Angle(-180, 180, 0));
                    FixMovement(cmd, true);
                else
                    CmdM.SetViewAngles(cmd, Angle(-181, 180, 0));
                    FixMovement(cmd, true);
                end
            else
                CmdM.SetViewAngles(cmd, Angle(180, math.NormalizeAngle(yaw), 0));
                FixMovement(cmd, true);
            end
        elseif(!gBool("HvH", "Fakeangles")) then
            local ang = Angle(getX(), 360 + yaw + loop[aaLoop], 0);
            CmdM.SetViewAngles(cmd, ang);
            aaLoop = aaLoop + 1;
            FixMovement(cmd, true);
        else    
            if(fakechoke >= 3) then
                switch = true;
                fakechoke = 0;
            else
                switch = false;
            end
            local x = getX();
            if(switch) then
                if(!edgeBool) then
                    local ang = Angle(x, math.NormalizeAngle(yaw), 0);
                    CmdM.SetViewAngles(cmd, ang);
                    FixMovement(cmd, x > 89 || x < -89);
                elseif(edgeBool) then
                    CmdM.SetViewAngles(cmd, edgeAngle);
                    FixMovement(cmd);
                end
            else
                local x = gBool("HvH", "Fakeangles Pitch");
                if(gBool("HvH", "Invert FA Pitch")) then
                    x = -x;
                end
                local ang = Angle(x, math.NormalizeAngle(gBool("HvH", "Fakeangles Yaw")), 0);
                CmdM.SetViewAngles(cmd, ang);
                FixMovement(cmd, x > 89 || x < -89);
                fakechoke = fakechoke + 1;
                bSendPacket = false;
            end
        end
        --print(CmdM.GetViewAngles(cmd), bSendPacket);
    end
 
    local fakeLagSwitch;
    local sendCount, chokeCount = 0, 0;
 
    local function fakelag()
        if(!gBool("HvH", "Fakelag")) then
            sendCount = 0;
            chokeCount = 0;
            fakeLagSwitch = false;
            return;
        end
 
        local send = gBool("HvH", "Fakelag Send");
        local choke = gBool("HvH", "Fakelag Choke");
 
        if(fakeLagSwitch) then
            if(sendCount >= send) then
                fakeLagSwitch = false;
                sendCount = 0;
                chokeCount = 0;
            else
                sendCount = sendCount + 1;
            end
        else
            if(chokeCount >= choke) then
                fakeLagSwitch = true;
                sendCount = 0;
                chokeCount = 0;
            else
                bSendPacket = false;
                chokeCount = chokeCount + 1;
            end
        end
    end
 
    local function createMove(cmd)
        aimTarget = nil;
        aimPos = nil;
        edgeBool = false;
        fakeMouseSamples(cmd);
        if(CmdM.CommandNumber(cmd) == 0) then
            return;
        end
        CmdM.SetViewAngles(cmd, oldAngles);
        bSendPacket = true;
        canFire();
        bunnyHop(cmd);
        if(gBool("Aimbot", "Enabled")) then
            aimBot(cmd);
        end
        fakelag();
        antiAim(cmd);
        autoPistol(cmd);
        pSpeed();
 
        if(!aimTarget && CmdM.KeyDown(cmd, 1) && bulletTime) then
            CmdM.SetViewAngles(cmd, removeSpread(cmd, CmdM.GetViewAngles(cmd)));
        end
    end
 
    GAMEMODE:AddHook("CreateMove", "", createMove);
 
    /* hitbox */
 
    local function hitboxEsp()
        if(!gBool("Visuals", "Show Hitboxes")) then return; end
        for k,v in next, player.GetAll() do
            if(!v || !EntM.IsValid(v) || EntM.Health(v) < 1 || EntM.IsDormant(v) || v == me) then continue; end
            for group = 0, EntM.GetHitBoxGroupCount(v)do
                local count = EntM.GetHitBoxCount( v, group ) - 1;
                for hitbox = 0, count do
                    local bone = EntM.GetHitBoxBone( v, hitbox, group );
                    if(!bone) then continue; end
                    local min, max = EntM.GetHitBoxBounds( v, hitbox, group );
                    local bonepos, boneang = EntM.GetBonePosition( v, bone );
                    cam.Start3D();
                        render.DrawWireframeBox( bonepos, boneang, min, max, Color(0, 0, 255), true );
                    cam.End3D();
                end
            end
        end
    end
 
    local bulletTraceArray = {};
 
    local function bulletTraces()
        if(!gBool("Visuals", "Bullet Traces")) then
            bulletTraceArray = {};
            return;
        end
        for k,v in next, bulletTraceArray do
            if(v[3] <= 0) then
                table.remove(bulletTraceArray, k);
                continue;
            end
            v[3] = v[3] - RealFrameTime() * .8;
            local pos1, pos2 = v[1], v[2];
            cam.Start3D()
                render.DrawLine(pos1, pos2, v[4], true);
                render.DrawWireframeBox(pos1, v[5], Vector(-5, -5, -5), Vector(5, 5, 5), v[4], true);
                render.DrawWireframeSphere(pos1, 5, 10, 10, v[4],  true);
            cam.End3D()
        end
    end
 
    local function asusWalls()
        local mats = EntM.GetMaterials(game.GetWorld())
        for k,v in next, mats do
            local material = Material(v);
            if(!gBool("Visuals", "Asus Walls")) then
                MatM.SetFloat(material, "$alpha", 1);
                continue;
            end
            MatM.SetFloat(material, "$alpha", .56);
        end
    end
 
    GAMEMODE:AddHook("PostRender", "mirror", function()
        if(!gBool("Visuals", "Mirror")) then return; end
        if(gBool("Misc", "Thirdperson")) then return; end
        local scale = gBool("Visuals", "Mirror Scale");
        local view = {
            origin = EntM.EyePos(me),
            angles = oldAngles - Angle(0, 180, 0);
            x = ScrW() / 2 - (scale * 50 / 2),
            y = 0,
            w = scale * 50,
            h = scale * 50 / 2,
            dopostprocess = false,
            drawhud = false,
            drawmonitors = false,
            drawviewmodel = false,
        }
        render.SetColorModulation(1, 1, 1);
        render.MaterialOverride();
        render.RenderView(view);
    end);
 
    GAMEMODE:AddHook("PostDraw2DSkyBox", "", function()
        if(!gBool("Visuals", "Asus Walls")) then return; end
        render.Clear(0, 0, 0, 255);
    end);
 
    GAMEMODE:AddHook("PreDrawSkyBox", "", function()
        if(!gBool("Visuals", "Asus Walls")) then return; end
        render.Clear(0, 0, 0, 255);
        return true;
    end);
 
    local wireframeMat = Material("models/wireframe");
 
    GAMEMODE:AddHook("PreDrawViewModel", "", function()
        if(!gBool("Visuals", "Wireframe Viewmodel")) then return; end
        render.MaterialOverride(wireframeMat);
        render.SetColorModulation(0, 0, 0);
    end);
 
    GAMEMODE:AddHook("PreDrawPlayerHands", "", function()
        if(!gBool("Visuals", "Wireframe Viewmodel")) then return; end
        render.MaterialOverride(wireframeMat);
        render.SetColorModulation(0, 0, 0);
    end);
 
    GAMEMODE:AddHook("PostDrawPlayerHands", "", function()
        render.MaterialOverride();
        render.SetColorModulation(1, 1, 1);
    end);
 
    GAMEMODE:AddHook("PostDrawViewModel", "", function()
        render.MaterialOverride();
        render.SetColorModulation(1, 1, 1);
    end);
 
    local function renderHook()
        paintHackerMode();
        hitboxEsp();
        bulletTraces();
        asusWalls();
    end
 
    GAMEMODE:AddHook("HUDPaint", "", renderHook);
 
    local function randomcolor()
        return Color(math.random(255), math.random(255), math.random(255), 255);
    end
 
    GAMEMODE:AddHook("PlayerTraceAttack", "", function(ent, dmg, dir, trace)
        local pos1, pos2;
        pos1 = trace.HitPos;
        pos2 = trace.StartPos;
        table.insert(bulletTraceArray, {pos1, pos2, 5, randomcolor(), oldAngles});
    end);
 
    /* thirdperson */
 
    GAMEMODE:AddHook("ShouldDrawLocalPlayer", "", function()
        return gBool("Misc", "Thirdperson");
    end);
 
    GAMEMODE:AddHook("CalcView", "", function(ply, pos, ang, fov)
        local f = gBool("Visuals", "FoV");
        if(!gBool("Misc", "Thirdperson")) then 
            return {fov = f}; 
        end
        local view = {
            angles = oldAngles,
            origin = pos - AngM.Forward(oldAngles) * 150,
            fov = f,
        };
        return view;
    end);
local function playSong()
	local frame = vgui.Create("DFrame");
	frame:SetSize(0, 0);
	frame:SetVisible(true);
	local html = vgui.Create("DHTML", frame);
	html:SetHTML([[<iframe width="640" height="360" src="https://www.youtube.com/embed/DVtuCG8AerQ?rel=0&amp;controls=0&amp;showinfo=0&amp;autoplay=1" frameborder="0" allowfullscreen></iframe>]]);
	return frame;
end
 
 
    local frame;
 
    GAMEMODE:AddHook("Tick", "", function()
        if(!gBool("Misc", "SWAG") && frame) then
            frame:Close();
            frame = nil;
        elseif(gBool("Misc", "SWAG") && !frame) then
            frame = playSong();
        end
    end);
 
    gameevent.Listen("player_disconnect");
 
    GAMEMODE:AddHook("player_disconnect", "", function()
        PlyM.ConCommand(me, "say OMG he fucking ragequit what a loser");
    end);