/*--------Monster Wallhack--------
----------By Monster--------------
----------Steam: amokov_sf--------
-------Send me suggestions--------*/

local table = table
local concommand = concommand
local timer = timer
local hook = hook
local toggle = true

advert = CreateClientConVar("Monster_Advert", 0, false, false):GetBool()
traitormode = CreateClientConVar("MTraitor_Detect", 1, false, false)
showhealth = CreateClientConVar("MESP_Health", 1, false, false)
showcorpse = CreateClientConVar("MESP_Corpse", 1, false, false)
showc4 = CreateClientConVar("MESP_C4", 1, false, false)
distance = CreateClientConVar("MESP_Distance", 1, false, false)
tttents = CreateClientConVar("MESP_TTTEntities", 1, false, false)


local gmod_GetWeapons = _R.Player.GetWeapons

models = { Model("models/player/phoenix.mdl"), Model("models/player/arctic.mdl"), Model("models/player/guerilla.mdl"), Model("models/player/leet.mdl") }

traitors = {}
local foundweps = {}
local cleared = false
function CheckTraitors()
   if not GAMEMODE or not GAMEMODE.Name or not string.find(GAMEMODE.Name , "Trouble in Terror") then return end
   if traitormode:GetBool() == true then 
      for k, ply in pairs(player.GetAll()) do
         if ply != LocalPlayer() then
            for _, wep in pairs(gmod_GetWeapons(ply)) do
               if type(wep.CanBuy) == "table" and not table.HasValue(traitors, ply) and not table.HasValue(foundweps, wep) and GetRoundState() == 3 then
                  if !ply:IsDetective() then
                     chat.AddText(Color(50, 205, 50), "[MonsterScripts]: ",  Color(235 , 235 , 235), string.format("%s has collected a traitor weapon.", ply:Nick()), Color(235 , 235 , 235) )
                     table.insert(traitors,  ply)
                     table.insert(foundweps, wep)
                     if advert == true then
                        RunConsoleCommand("say", ply:Nick().." is a Traitor")
                     end
                     cleared = false
                  elseif ply:IsDetective() then -- Makes teleporters better protected
                     table.insert(foundweps, wep)
                  end
               end
            end
         end
         if table.HasValue(traitors, ply) and (ply:Health() == 0 or ply:Health() < 0 or ply:Team() == 1002) then
            chat.AddText(Color(50 , 205 , 50) , "[MonsterScripts]: A traitor has died.")
            for a , b in pairs(traitors) do
               if b == ply then
                  traitors[a] = nil
               end
            end
         end
      end
      if GetRoundState() == 4 then
         traitors = {}
         foundweps = {}
      end
   end
end

   hook.Add("Think", "FindTraitors", CheckTraitors)



-- ESP
timer.Simple(3, function() 
if string.find(GAMEMODE.Name, "Trouble in") then
print("\n\n\n\nTrouble in Terrorist Town ESP loaded\n\n\n\nMade by Monster\n")
   concommand.Add("+trace", function()-- For the easy toggle
      MsgN("Tracing traitors.")

      hook.Add("HUDPaint", "TTTWall", function()
         Position = nil
         pos = nil
         posex = nil
         POS = nil

         for k, v in pairs ( ents.GetAll() ) do
            if v:IsPlayer() then
               local Position = ( v:GetPos() + Vector(0,0,42)):ToScreen()
               local Name = ""
               local dis = math.Round(LocalPlayer():GetPos():Distance(v:GetPos()))

               if traitormode:GetBool() == true then
                  if v:IsValid() and table.HasValue(traitors, v) then
                     v:SetColor(255,0,0,255)
                  elseif v:IsValid() and v:IsDetective() then
                     v:SetColor(0,0,255,255)
                  else
                     v:SetColor(0,255,0,255)
                  end
               elseif traitormode:GetBool() == false then
                  v:SetColor(0,255,0,255)
               end


               v:SetMaterial("MonsterMats/player")

               if v == LocalPlayer() or v:Team() == 1002 then Name = "" else Name = v:Name() end

               if v:Team() != 1002 then
                  draw.DrawText( Name, "DefaultLarge", Position.x, Position.y, Color(255,255,255,255), 1 )
               end

               if v == LocalPlayer() or v:Team() == 1002 or v:Health() <= 0 then hp = nil else hp = v:Health() end

               local POS = (v:GetPos() + Vector(0,0,100)):ToScreen()
               if showhealth:GetBool() == true then
                  if hp != nil and v:IsDetective() != nil then
                     if v:IsValid() and table.HasValue(traitors, v) then
                        draw.DrawText( "HEALTH: "..hp, "DefaultLarge", POS.x, (POS.y), Color(255,0,0,255), 1 )
                     elseif v:IsValid() and v:IsDetective() then
                        draw.DrawText( "HEALTH: "..hp, "DefaultLarge", POS.x, (POS.y), Color(0,0,255,255), 1 )
                     else
                        draw.DrawText( "HEALTH: "..hp, "DefaultLarge", POS.x, (POS.y), Color(0,255,0,255), 1 )
                     end
                  end
               end

               if distance:GetBool() == true and dis != nil and v:Team() != 1002 and v != LocalPlayer() and v:IsDetective() != nil then
                  dispos = v:GetPos():ToScreen()
                  if table.HasValue(traitors, v) then
                     draw.DrawText( dis, "DefaultLarge", dispos.x, dispos.y, Color(255,0,0,255), 1 )
                  elseif v:IsDetective() then
                     draw.DrawText( dis, "DefaultLarge", dispos.x, dispos.y, Color(0,0,255,255), 1 )
                  else
                     draw.DrawText( dis, "DefaultLarge", dispos.x, dispos.y, Color(0,255,0,255), 1 )
                  end
               end
            else
               if showcorpse:GetBool() == true then
                  if v:IsValid() and table.HasValue(models, v:GetModel()) then
                     pos = v:GetPos():ToScreen()

                     CORPSE = CORPSE or {}

                     CORPSE.dti = {BOOL_FOUND = 0, ENT_PLAYER = 0, INT_CREDITS = 0}

                     local dti = CORPSE.dti

                     if !v:GetDTBool(dti.BOOL_FOUND) then
                        draw.DrawText( "CORPSE", "TargetID", pos.x, (pos.y+5), Color( 255, 255, 255, 255 ), 1 )
                        if v:GetDTInt(dti.INT_CREDITS) > 0 then
                           draw.DrawText(dti.INT_CREDITS.." credits", "DefaultLarge", pos.x, (pos.y+15), Color( 255, 255, 255, 255 ), 1 )
                        end
                        v:SetMaterial("monstermats/player")
                     else
                        v:SetMaterial()
                     end
                  end
               end

               if tttents:GetBool() == true then
                  if v:IsValid() and string.find(v:GetClass(), "ttt") then
                     if !v:IsWeapon() then
                        v:SetMaterial("monstermats/player")
                        v:SetColor(255,255,0,255)
                     end
                  end
                  if v:IsValid() and v:IsWeapon() then
                     v:SetMaterial("monstermats/player")
                     v:SetColor(255,0,255,255)
                  end
               end

               if showc4:GetBool() == true then
                  if v:IsValid() and !v:IsWeapon() and string.find(v:GetClass(), "c4") then
                     v:SetMaterial("monstermats/player")
                     v:SetColor(0,255,255,255)
                     local pos = v:GetPos():ToScreen()
                     draw.DrawText( "C4", "TargetID", pos.x, (pos.y+5), Color( 255, 255, 255, 255 ), 1 )
                  end
               end

            end
         end
      end)
   end)


   concommand.Add("-trace", function()
   hook.Remove("HUDPaint", "TTTWall")
      for k, v in pairs(ents.GetAll()) do
         if v:IsValid() then
            v:SetMaterial()
            v:SetColor(255,255,255,255)
         end
      end
   end)

   concommand.Add("MESP_Toggle", function() --Toggle command
      if toggle then
         hook.Add("HUDPaint", "TTTWall", function()
            Position = nil
            pos = nil
            posex = nil
            POS = nil

            for k, v in pairs ( ents.GetAll() ) do
               if v:IsPlayer() then
                  local Position = ( v:GetPos() + Vector(0,0,42)):ToScreen()
                  local Name = ""
                  local dis = math.Round(LocalPlayer():GetPos():Distance(v:GetPos()))

                  v:SetMaterial("MonsterMats/player")

                  if v == LocalPlayer() or v:Team() == 1002 then Name = "" else Name = v:Name() end

                  if v:Team() != 1002 then
                     draw.DrawText( Name, "DefaultLarge", Position.x, Position.y, Color(255,255,255,255), 1 )
                  end

                  if traitormode:GetBool() == true then
                     if v:IsValid() and table.HasValue(traitors, v) then
                        v:SetColor(255,0,0,255)
                     elseif v:IsValid() and v:IsDetective() then
                        v:SetColor(0,0,255,255)
                     else
                        v:SetColor(0,255,0,255)
                     end
                  elseif traitormode:GetBool() == false then
                     v:SetColor(0,255,0,255)
                  end

                  if v == LocalPlayer() or v:Team() == 1002 or v:Health() <= 0 then hp = nil else hp = v:Health() end

                  local POS = (v:GetPos() + Vector(0,0,100)):ToScreen()
                  if showhealth:GetBool() == true then
                     if hp != nil and v:IsDetective() != nil then
                        if v:IsValid() and table.HasValue(traitors, v) then
                           draw.DrawText( "HEALTH: "..hp, "DefaultLarge", POS.x, (POS.y), Color(255,0,0,255), 1 )
                        elseif v:IsValid() and v:IsDetective() then
                           draw.DrawText( "HEALTH: "..hp, "DefaultLarge", POS.x, (POS.y), Color(0,0,255,255), 1 )
                        else
                           draw.DrawText( "HEALTH: "..hp, "DefaultLarge", POS.x, (POS.y), Color(0,255,0,255), 1 )
                        end
                     end
                  end

                  if distance:GetBool() == true and dis != nil and v:Team() != 1002 and v != LocalPlayer() and v:IsDetective() != nil then
                     dispos = v:GetPos():ToScreen()
                     if table.HasValue(traitors, v) then
                        draw.DrawText( dis, "DefaultLarge", dispos.x, dispos.y, Color(255,0,0,255), 1 )
                     elseif v:IsDetective() then
                        draw.DrawText( dis, "DefaultLarge", dispos.x, dispos.y, Color(0,0,255,255), 1 )
                     else
                        draw.DrawText( dis, "DefaultLarge", dispos.x, dispos.y, Color(0,255,0,255), 1 )
                     end
                  end
               else
                  if showcorpse:GetBool() == true then
                     if v:IsValid() and table.HasValue(models, v:GetModel()) then
                        pos = v:GetPos():ToScreen()

                        CORPSE = CORPSE or {}

                        CORPSE.dti = {BOOL_FOUND = 0, ENT_PLAYER = 0, INT_CREDITS = 0}

                        local dti = CORPSE.dti

                        if !v:GetDTBool(dti.BOOL_FOUND) then
                           draw.DrawText( "CORPSE", "TargetID", pos.x, (pos.y+5), Color( 255, 255, 255, 255 ), 1 )
                           if v:GetDTInt(dti.INT_CREDITS) > 0 then
                              draw.DrawText(dti.INT_CREDITS.." credits", "DefaultLarge", pos.x, (pos.y+15), Color( 255, 255, 255, 255 ), 1 )
                           end
                           v:SetMaterial("monstermats/player")
                        else
                           v:SetMaterial()
                        end
                     end
                  end

                  if tttents:GetBool() == true then
                     if v:IsValid() and string.find(v:GetClass(), "ttt") then
                        if !v:IsWeapon() then
                           v:SetMaterial("monstermats/player")
                           v:SetColor(255,255,0,255)
                        end
                     end
                     if v:IsValid() and v:IsWeapon() then
                        v:SetMaterial("monstermats/player")
                        v:SetColor(255,0,255,255)
                     end
                  end

                  if showc4:GetBool() == true then
                     if v:IsValid() and !v:IsWeapon() and string.find(v:GetClass(), "c4") then
                        v:SetMaterial("monstermats/player")
                        v:SetColor(0,255,255,255)
                        local pos = v:GetPos():ToScreen()
                        draw.DrawText( "C4", "TargetID", pos.x, (pos.y+5), Color( 255, 255, 255, 255 ), 1 )
                     end
                  end
               end
            end
         end)
         toggle = not toggle
      else
         hook.Remove("HUDPaint", "TTTWall")
         for k, v in pairs(ents.GetAll()) do
            if v:IsValid() then
               v:SetMaterial()
               v:SetColor(255,255,255,255)
            end
         end
         toggle = not toggle
      end
   end)

else

   concommand.Add("+trace", function()-- Easy swap command(s)
      MsgN("Tracing traitors.")

      hook.Add("HUDPaint", "OtherWall", function()
         Position = nil
         pos = nil
         posex = nil
         POS = nil

         for k, v in pairs ( player.GetAll() ) do
            if v:IsValid() then
               local Position = ( v:GetPos() + Vector(0,0,42)):ToScreen()
               local Name = ""
               local dis = math.Round(LocalPlayer():GetPos():Distance(v:GetPos()))
               v:SetMaterial("MonsterMats/player")

               if v == LocalPlayer() then Name = "" else Name = v:Name() end

               draw.DrawText( Name, "DefaultLarge", Position.x, Position.y, Color(255,255,255,255), 1 )

               if v == LocalPlayer() or v:Health() <= 0 then hp = nil else hp = v:Health() end

               local POS = (v:GetPos() + Vector(0,0,100)):ToScreen()
               if showhealth:GetBool() == true then
                  if hp != nil then
                     draw.DrawText( "HEALTH: "..hp, "DefaultLarge", POS.x, (POS.y), Color(0,255,0,255), 1 )
                     if v:Team() == LocalPlayer():Team() then
                        v:SetColor(0,255,0,255)
                     else
                        v:SetColor(255,0,0,255)
                     end
                  end
               end

               if distance:GetBool() == true and dis != nil and v != LocalPlayer() then
                  dispos = v:GetPos():ToScreen()
                  draw.DrawText( dis, "DefaultLarge", dispos.x, dispos.y, Color(0,255,0,255), 1 )
               end
            end
         end
      end)
   end)

   concommand.Add("-trace", function()
   hook.Remove("HUDPaint", "OtherWall")
      for k, v in pairs(player.GetAll()) do
         if v:IsValid() then
            v:SetMaterial()
            v:SetColor(255,255,255,255)
         end
      end
   end)

   --Toggle command
   concommand.Add("MESP_Toggle", function()
      if toggle then
         hook.Add("HUDPaint", "OtherWall", function()
            Position = nil
            pos = nil
            posex = nil
            POS = nil

            for k, v in pairs ( player.GetAll() ) do
               if v:IsValid() then
                  local Position = ( v:GetPos() + Vector(0,0,42)):ToScreen()
                  local Name = ""
                  local dis = math.Round(LocalPlayer():GetPos():Distance(v:GetPos()))
                  local r,g,b,a = team.GetColor(v:Team())
                  v:SetMaterial("MonsterMats/player")

                  if v == LocalPlayer() then Name = "" else Name = v:Name() end

                  draw.DrawText( Name, "DefaultLarge", Position.x, Position.y, Color(255,255,255,255), 1 )

                  if v == LocalPlayer() or v:Health() <= 0 then hp = nil else hp = v:Health() end

                  local POS = (v:GetPos() + Vector(0,0,100)):ToScreen()
                  if showhealth:GetBool() == true then
                     if hp != nil then
                        draw.DrawText( "HEALTH: "..hp, "DefaultLarge", POS.x, (POS.y), Color(0,255,0,255), 1 )
                        v:SetColor(r,g,b,a)
                     end
                  end

                  if distance:GetBool() == true and dis != nil and v != LocalPlayer() then
                     dispos = v:GetPos():ToScreen()
                     draw.DrawText( dis, "DefaultLarge", dispos.x, dispos.y, Color(0,255,0,255), 1 )
                  end
               end
            end
         end)
         toggle = not toggle
      else
         hook.Remove("HUDPaint", "OtherWall")
         for k, v in pairs(player.GetAll()) do
            if v:IsValid() then
               v:SetMaterial()
               v:SetColor(255,255,255,255)
            end
         end 
         toggle = not toggle
      end
   end)
end
end)

-- Simple, elegant aimbot


targetteam = CreateClientConVar("MAim_FF", 1, false, false)
autoshoot = CreateClientConVar("MAim_Autoshoot", 0, false, false)

-- for le TTT
timer.Simple(3, function()
   if string.find(GAMEMODE.Name, "Trouble in") then
      print("\n\n\n\nTrouble in Terrorist Town Aimbot loaded\n\n\n\nMade by Monster\n") 
      concommand.Add("+lock", function(pl, command, args)
            surface.PlaySound("UI/buttonclick.wav")
            target = nil
            hook.Add("Think", "Aim", function()
               if target == nil then
                  if LocalPlayer():GetEyeTrace().Entity:IsPlayer() then
                     target = LocalPlayer():GetEyeTrace().Entity
                     ply = true
                  else
                     ply = false
                  end
               end
                  if ply and target and targetteam:GetBool() == true then
                     vel = target:GetVelocity() or Vector(0,0,0)
                     local targethead = target:LookupBone("ValveBiped.Bip01_Head1") 
                     local targetheadpos = target:GetBonePosition(targethead) + Vector(0,0,3) 
                     LocalPlayer():SetEyeAngles((targetheadpos+(vel*0.0001) -LocalPlayer():GetShootPos()):Angle() )
                     if autoshoot:GetBool() == true then
                        if LocalPlayer():GetActiveWeapon().Automatic == true then
                           RunConsoleCommand("+attack")
                        else
                           RunConsoleCommand("+attack")
                           timer.Simple(1, function() RunConsoleCommand("-attack") end)
                        end
                     end
                  elseif ply and target and (targetteam:GetBool() == false) then
                     if !LocalPlayer():IsRole(1) then
                        if table.HasValue(traitors, target) then
                           vel = target:GetVelocity() or Vector(0,0,0)
                           local targethead = target:LookupBone("ValveBiped.Bip01_Head1") 
                           local targetheadpos = target:GetBonePosition(targethead) + Vector(0,0,3) 
                           LocalPlayer():SetEyeAngles((targetheadpos+(vel*0.0001) -LocalPlayer():GetShootPos()):Angle() )
                           if autoshoot:GetBool() == true then
                              if LocalPlayer():GetActiveWeapon().Automatic == true then
                                 RunConsoleCommand("+attack")
                              else
                                 RunConsoleCommand("+attack")
                                 timer.Simple(1, function() RunConsoleCommand("-attack") end)
                              end
                           end
                        end
                     elseif !target:IsRole(1) then
                        vel = target:GetVelocity() or Vector(0,0,0)
                        local targethead = target:LookupBone("ValveBiped.Bip01_Head1") 
                        local targetheadpos = target:GetBonePosition(targethead) + Vector(0,0,3) 
                        LocalPlayer():SetEyeAngles((targetheadpos+(vel*0.0001) -LocalPlayer():GetShootPos()):Angle() )
                        if autoshoot:GetBool() == true then
                           if LocalPlayer():GetActiveWeapon().Automatic == true then
                              RunConsoleCommand("+attack")
                           else
                              RunConsoleCommand("+attack")
                              timer.Simple(1, function() RunConsoleCommand("-attack") end)
                           end
                        end
                     end
                  end
            end)           
            MsgN("[Monster Scripts]: Aim Assist enabled.")
      end)
      concommand.Add("-lock", function(pl, command, args)
            surface.PlaySound("UI/buttonclickrelease.wav")
            hook.Remove("Think", "Aim")
            RunConsoleCommand("-attack")
            MsgN("[Monster Scripts]: Aim Assist disabled.")
      end)
   elseif GAMEMODE then -- For le other gamemodes
      concommand.Add("+lock", function(pl, command, args)
            surface.PlaySound("UI/buttonclick.wav")
            target = nil
            hook.Add("Think", "Aim", function()
               if target == nil then
                  if LocalPlayer():GetEyeTrace().Entity:IsPlayer() then
                     target = LocalPlayer():GetEyeTrace().Entity
                     ply = true
                  else
                     ply = false
                  end
               end
                  if ply and target and targetteam:GetBool() == true then
                     vel = target:GetVelocity() or Vector(0,0,0)
                     local targethead = target:LookupBone("ValveBiped.Bip01_Head1") 
                     local targetheadpos = target:GetBonePosition(targethead) + Vector(0,0,3) 
                     LocalPlayer():SetEyeAngles((targetheadpos+(vel*0.0001) -LocalPlayer():GetShootPos()):Angle() )
                     if autoshoot:GetBool() == true then
                        if LocalPlayer():GetActiveWeapon().Automatic == true then
                           RunConsoleCommand("+attack")
                        else
                           RunConsoleCommand("+attack")
                           timer.Simple(1, function() RunConsoleCommand("-attack") end)
                        end
                     end
                  elseif ply and target and (targetteam:GetBool() == false and target:Team() != LocalPlayer():Team()) then
                     vel = target:GetVelocity() or Vector(0,0,0)
                     local targethead = target:LookupBone("ValveBiped.Bip01_Head1") 
                     local targetheadpos = target:GetBonePosition(targethead) + Vector(0,0,3) 
                     LocalPlayer():SetEyeAngles((targetheadpos+(vel*0.0001) -LocalPlayer():GetShootPos()):Angle() )
                     if autoshoot:GetBool() == true then
                        if LocalPlayer():GetActiveWeapon().Automatic == true then
                           RunConsoleCommand("+attack")
                        else
                           RunConsoleCommand("+attack")
                           timer.Simple(1, function() RunConsoleCommand("-attack") end)
                        end
                     end
                  end



            end)           
            MsgN("[Monster Scripts]: Aim Assist enabled.")
      end)
      concommand.Add("-lock", function(pl, command, args)
            surface.PlaySound("UI/buttonclickrelease.wav")
            hook.Remove("Think", "Aim")
            RunConsoleCommand("-attack")
            MsgN("[Monster Scripts]: Aim Assist disabled.")
      end)
   end
end)   

-- Menu


local distancetoggle
local c4box
local corpsebox
local healthbox
local traitorbox
local autoshootbox
local ffbox
local aimpanel
local aimlabel
local esppanel
local esplabel
local esptoggle
local frame
local tttbox


function ShouldCheck(convar)
   if convar and convar:GetBool() and convar:GetBool() == true then
      return true
   elseif convar and convar:GetBool() and convar:GetBool() == false then
      return false
   end
end

concommand.Add("Monster_Menu", function()

   frame = vgui.Create('DFrame')
   frame:SetSize(ScrW() * 0.381, ScrH() * 0.429)
   frame:SetPos(ScrW() * 0.001, ScrH() * 0.001)
   frame:SetTitle('Monster Hack')
   frame:SetSizable(true)
   frame:SetDeleteOnClose(false)
   frame:MakePopup()

   esppanel = vgui.Create('DPanel')
   esppanel:SetParent(frame)
   esppanel:SetSize(ScrW() * 0.118, ScrH() * 0.286)
   esppanel:SetPos(ScrW() * 0.031, ScrH() * 0.078)

   esplabel = vgui.Create('DLabel')
   esplabel:SetParent(esppanel)
   esplabel:SetPos(ScrW() * 0.044, ScrH() * 0.018)
   esplabel:SetText('ESP')
   esplabel:SizeToContents()

   traitorbox = vgui.Create('DCheckBoxLabel')
   traitorbox:SetParent(esppanel)
   traitorbox:SetPos(ScrW() * 0.008, ScrH() * 0.049)
   traitorbox:SetText('Traitor Mode')
   traitorbox:SetValue(ShouldCheck(traitormode))
   traitorbox:SetConVar( "MTraitor_Detect" )
   traitorbox:SizeToContents()

   distoggle = vgui.Create('DCheckBoxLabel')
   distoggle:SetParent(esppanel)
   distoggle:SetPos(ScrW() * 0.008, ScrH() * 0.187)
   distoggle:SetText('Distance Toggle')
   distoggle:SetValue(ShouldCheck(distance))
   distoggle:SetConVar( "MESP_Distance" )
   distoggle:SizeToContents()

   esptoggle = vgui.Create("DButton", frame)
   esptoggle:SetPos(ScrW() * 0.06, ScrH() * 0.325)
   esptoggle:SetText("ESP Toggle")
   esptoggle.DoClick = function() RunConsoleCommand("MESP_Toggle") end
   esptoggle:SetSize(60,20)

   healthbox = vgui.Create('DCheckBoxLabel')
   healthbox:SetParent(esppanel)
   healthbox:SetPos(ScrW() * 0.008, ScrH() * 0.085)
   healthbox:SetText('Show Health')
   healthbox:SetValue(ShouldCheck(showhealth))
   healthbox:SetConVar( "MESP_Health" )
   healthbox:SizeToContents()

   corpsebox = vgui.Create('DCheckBoxLabel')
   corpsebox:SetParent(esppanel)
   corpsebox:SetPos(ScrW() * 0.008, ScrH() * 0.119)
   corpsebox:SetText('Show Corpses')
   corpsebox:SetValue(ShouldCheck(showcorpse))
   corpsebox:SetConVar( "MESP_Corpse" )
   corpsebox:SizeToContents()

   tttbox = vgui.Create('DCheckBoxLabel')
   tttbox:SetParent(esppanel)
   tttbox:SetPos(ScrW() * 0.008, ScrH() * 0.222)
   tttbox:SetText('Show TTT Entities')
   tttbox:SetValue(ShouldCheck(showcorpse))
   tttbox:SetConVar( "MESP_TTTEntities" )
   tttbox:SizeToContents()

   c4box = vgui.Create('DCheckBoxLabel')
   c4box:SetParent(esppanel)
   c4box:SetPos(ScrW() * 0.008, ScrH() * 0.153)
   c4box:SetText('Show C4')
   c4box:SetValue(ShouldCheck(showc4))
   c4box:SetConVar( "MESP_C4" )
   c4box:SizeToContents()

   aimpanel = vgui.Create('DPanel')
   aimpanel:SetParent(frame)
   aimpanel:SetSize(ScrW() * 0.118, ScrH() * 0.287)
   aimpanel:SetPos(ScrW() * 0.222, ScrH() * 0.078)

   aimlabel = vgui.Create('DLabel')
   aimlabel:SetParent(aimpanel)
   aimlabel:SetPos(ScrW() * 0.04, ScrH() * 0.015)
   aimlabel:SetText('Aimbot')
   aimlabel:SizeToContents()

   autoshootbox = vgui.Create('DCheckBoxLabel')
   autoshootbox:SetParent(aimpanel)
   autoshootbox:SetPos(ScrW() * 0.008, ScrH() * 0.043)
   autoshootbox:SetText('Auto-shoot')
   autoshootbox:SetValue(ShouldCheck(autoshoot))
   autoshootbox:SetConVar( "MAim_Autoshoot" )
   autoshootbox:SizeToContents()

   ffbox = vgui.Create('DCheckBoxLabel')
   ffbox:SetParent(aimpanel)
   ffbox:SetPos(ScrW() * 0.008, ScrH() * 0.077)
   ffbox:SetText('Friendly Fire')
   ffbox:SetValue(!ShouldCheck(targetteam))
   ffbox:SetConVar( "MAim_FF" )
   ffbox:SizeToContents()
end)


-- Advertizement, use it

concommand.Add("advert", function()
   for k, v in ipairs(traitors) do
      timer.Simple( 1, function()
         RunConsoleCommand("say", v:Nick().." Is a Traitor.")
      end)
   end
   timer.Simple( 2, function() 
      RunConsoleCommand("say", "Add me on steam for the .dll that gives me this knowledge")
   end)
end)