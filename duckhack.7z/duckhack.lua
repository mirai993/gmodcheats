--[[
    M   M         A     D D      H   H     A       C C   K   K
   M M M M       A A    D  D     H   H    A A     C   C  K  K
  M   M   M     A A A   D   D    H H H   A A A   C       KK
 M         M   A     A  D  D     H   H  A     A   C   C  K  K
M           M A       A D D      H   H A       A   C C   K   K
--]]
 
local SkelOptn = 0
local PrOptn = 0
local KyOptn = 0
local EntOptn = 0
local plyrBxOptn = 0
local PlyrOptn = 0
local SPOptn = 0
local MDOptn = 0
local SSCOptn = 0
local CROptn = 0
 
function MadMenu ( )
local DermaPanel = vgui.Create( "DFrame" )
   DermaPanel:SetPos( 50,50 )
   DermaPanel:SetSize( 200, 250 )
   DermaPanel:SetTitle( "MadHack Menu" )
   DermaPanel:SetVisible( true )
   DermaPanel:SetDraggable( true )
   DermaPanel:ShowCloseButton( true )
   DermaPanel:MakePopup()
 
local PropertySheet = vgui.Create( "DPropertySheet" )
PropertySheet:SetParent( DermaPanel )
PropertySheet:SetPos( 5, 30 )
PropertySheet:SetSize( 180, 210 )
 
local SheetItemPanel = vgui.Create( "DPanel", DermaPanel )
SheetItemPanel:SetPos( 25, 50 )
SheetItemPanel:SizeToContents()
SheetItemPanel.Paint = function()
    surface.SetDrawColor( 50, 50, 50, 255 )
    surface.DrawRect( 0, 0, SheetItemPanel:GetWide(), SheetItemPanel:GetTall() )
end
 
local AIMKBTN = vgui.Create( "DButton", SheetItemPanel )
local PRECBTN = vgui.Create( "DButton", SheetItemPanel )
local SheetItemone = vgui.Create( "DButton", SheetItemPanel )
   SheetItemone:SetText( "Turn Off" )
   SheetItemone:SetPos( 20, 20 )
   SheetItemone:SetSize( 120, 20 )
   SheetItemone.DoClick = function ()
    RunConsoleCommand( "-KeyAimbot" )
        KyOptn = (0)
        AIMKBTN:SetText( "Aim On Key : Off" )
        RunConsoleCommand( "-PrecisionAimbot" )
        PrOptn = (0)
        PRECBTN:SetText( "Precision : Off" )
  end
   
//local PRECBTN = vgui.Create( "DButton", SheetItemPanel )
   if ( PrOptn == 0 ) then
    PRECBTN:SetText( "Precision : Off" )
   else
    PRECBTN:SetText( "Precision : On" )
   end
   PRECBTN:SetPos( 20, 50 )
   PRECBTN:SetSize( 120, 20 )
   PRECBTN.DoClick = function ()
   if ( PrOptn == 0 ) then
        RunConsoleCommand( "+PrecisionAimbot" )
        PRECBTN:SetText( "Precision : On" )
        else
        RunConsoleCommand( "-PrecisionAimbot" )
        PRECBTN:SetText( "Precision : Off" )
        end
  end
 
//local AIMKBTN = vgui.Create( "DButton", SheetItemPanel )  
   if ( KyOptn == 0 ) then
   AIMKBTN:SetText( "Aim On Key : Off" )
   else
   AIMKBTN:SetText( "Aim On Key : On" )
   end
   AIMKBTN:SetPos( 20, 80 )
   AIMKBTN:SetSize( 120, 20 )
   AIMKBTN.DoClick = function ()
   if ( KyOptn == 0 ) then
        RunConsoleCommand( "+KeyAimbot" )  
    AIMKBTN:SetText( "Aim On Key : On" )
        else
        RunConsoleCommand( "-KeyAimbot" )
        AIMKBTN:SetText( "Aim On Key : Off" )
        end
  end
 
local SheetItemPaneltwo = vgui.Create( "DPanel", DermaPanel )
SheetItemPaneltwo:SetPos( 25, 50 )
SheetItemPaneltwo:SizeToContents()
SheetItemPaneltwo.Paint = function()
    surface.SetDrawColor( 50, 50, 50, 255 )
    surface.DrawRect( 0, 0, SheetItemPaneltwo:GetWide(), SheetItemPaneltwo:GetTall() )
end
 
local EntityBtn = vgui.Create( "DButton", SheetItemPaneltwo )
local PlyrBtn = vgui.Create( "DButton", SheetItemPaneltwo )
local PlyrNmBtn = vgui.Create( "DButton", SheetItemPaneltwo )
local SkelBtn = vgui.Create( "DButton", SheetItemPaneltwo )
local SheetItemtwo = vgui.Create( "DButton", SheetItemPaneltwo )
   SheetItemtwo:SetText( "Turn Off" )
   SheetItemtwo:SetPos( 20, 20 )
   SheetItemtwo:SetSize( 120, 20 )
   SheetItemtwo.DoClick = function ()
    RunConsoleCommand( "-EntityESP" )
        EntityBtn:SetText( "Show Entitys : Off" )
        EntOptn = 0
        RunConsoleCommand( "-NameESP" )
        PlyrOptn = 0
        PlyrNmBtn:SetText( "Show Names : Off" )
        RunConsoleCommand( "-PlayerBoxESP" )
        plyrBxOptn = 0
        PlyrBtn:SetText( "Show Players : Off" )
        RunConsoleCommand( "-SkESP" )
        SkelOptn = 0
        SkelBtn:SetText( "Skeleton Cham : Off" )
  end
   
   if ( EntOptn == 0 ) then
   EntityBtn:SetText( "Show Entitys : Off" )
   else
   EntityBtn:SetText( "Show Entitys : On" )
   end
   EntityBtn:SetPos( 20, 50 )
   EntityBtn:SetSize( 120, 20 )
   EntityBtn.DoClick = function ()
     if ( EntOptn == 0 ) then
        RunConsoleCommand( "+EntityESP" )
        EntityBtn:SetText( "Show Entitys : On" )
        else
        RunConsoleCommand( "-EntityESP" )
        EntityBtn:SetText( "Show Entitys : Off" )
        end
  end
   
   if ( plyrBxOptn == 0 ) then
   PlyrBtn:SetText( "Show Players : Off" )
   else
   PlyrBtn:SetText( "Show Players : On" )
   end
   PlyrBtn:SetPos( 20, 80 )
   PlyrBtn:SetSize( 120, 20 )
   PlyrBtn.DoClick = function ()
     if ( plyrBxOptn == 0 ) then
        RunConsoleCommand( "+PlayerBoxESP" )
    PlyrBtn:SetText( "Show Players : On" )
        else
        RunConsoleCommand( "-PlayerBoxESP" )
        PlyrBtn:SetText( "Show Players : Off" )
        end
  end
     
   if ( PlyrOptn == 0 ) then
   PlyrNmBtn:SetText( "Show Names : Off" )
   else
   PlyrNmBtn:SetText( "Show Names : On" )
   end
   PlyrNmBtn:SetPos( 20, 110 )
   PlyrNmBtn:SetSize( 120, 20 )
   PlyrNmBtn.DoClick = function ()
    if ( PlyrOptn == 0 ) then
        RunConsoleCommand( "+NameESP" )
    PlyrNmBtn:SetText( "Show Names : On" )
        else
        RunConsoleCommand( "-NameESP" )
    PlyrNmBtn:SetText( "Show Names : Off" )    
        end
  end
   
   if ( SkelOptn == 0 ) then
   SkelBtn:SetText( "Skeleton Cham : Off" )
   else
   SkelBtn:SetText( "Skeleton Cham : On" )
   end
   SkelBtn:SetPos( 20, 140 )
   SkelBtn:SetSize( 120, 20 )
   SkelBtn.DoClick = function ()
    if ( SkelOptn == 0 ) then
        RunConsoleCommand( "+SkESP" )
        SkelBtn:SetText( "Skeleton Cham : On" )
        else
        RunConsoleCommand( "-SkESP" )
        SkelBtn:SetText( "Skeleton Cham : Off" )
        end
  end
 
local SheetItemPanelthree = vgui.Create( "DPanel", DermaPanel )
SheetItemPanelthree:SetPos( 25, 50 )
SheetItemPanelthree:SizeToContents()
SheetItemPanelthree.Paint = function()
    surface.SetDrawColor( 50, 50, 50, 255 )
    surface.DrawRect( 0, 0, SheetItemPanelthree:GetWide(), SheetItemPanelthree:GetTall() )
end
 
 local SheetItemthree = vgui.Create( "DButton", SheetItemPanelthree )
   if ( SPOptn == 0 ) then
   SheetItemthree:SetText( "Spectate : Off" )
   else
   SheetItemthree:SetText( "Spectate : On" )
   end
   SheetItemthree:SetPos( 20, 20 )
   SheetItemthree:SetSize( 120, 20 )
   SheetItemthree.DoClick = function ()
   if ( SPOptn == 0 ) then
        RunConsoleCommand( "SM_toggle" )
    SheetItemthree:SetText( "Spectate : On" )
        else
        RunConsoleCommand( "SM_toggle" )
        SheetItemthree:SetText( "Spectate : Off" )
        end
  end
 
 local CRBtn = vgui.Create( "DButton", SheetItemPanelthree )
   if ( CROptn == 0 ) then
   CRBtn:SetText( "Laser Sight : Off" )
   else
   CRBtn:SetText( "Laser Sight : On" )
   end
   CRBtn:SetPos( 20, 50 )
   CRBtn:SetSize( 120, 20 )
   CRBtn.DoClick = function ()
     if ( CROptn == 0 ) then
        RunConsoleCommand( "+laser" )  
        CRBtn:SetText( "Laser Sight : On" )
        else
        RunConsoleCommand( "-laser" )  
        CRBtn:SetText( "Laser Sight : Off" )
        end
  end
   
local TBtn = vgui.Create( "DButton", SheetItemPanelthree )
   if ( MDOptn == 0 ) then
   TBtn:SetText( "Mad Vision : Off" )
   else
   TBtn:SetText( "Mad Vision : On" )
   end
   TBtn:SetPos( 20, 80 )
   TBtn:SetSize( 120, 20 )
   TBtn.DoClick = function ()
    if ( MDOptn == 0 ) then
        RunConsoleCommand( "toggle_madvision" )  
        TBtn:SetText( "Mad Vision : On" )
        else
        RunConsoleCommand( "toggle_madvision" )  
        TBtn:SetText( "Mad Vision : Off" )
        end
  end
 
  local SSCBtn = vgui.Create( "DButton", SheetItemPanelthree )
   if ( SSCOptn == 0 ) then
   SSCBtn:SetText( "Third Person : Off" )
   else
   SSCBtn:SetText( "Third Person : On" )
   end
   SSCBtn:SetPos( 20, 110 )  
   SSCBtn:SetSize( 120, 20 )
   SSCBtn.DoClick = function ()
     if ( SSCOptn == 0 ) then
        RunConsoleCommand( "+ThirdPerson" )  
        SSCBtn:SetText( "Third Person : On" )
        else
        RunConsoleCommand( "-ThirdPerson" )  
        SSCBtn:SetText( "Third Person : Off" )
        end
  end
     
PropertySheet:AddSheet( "Aimbot", SheetItemPanel, "gui/silkicons/user", false, false, "Aimbot" )
PropertySheet:AddSheet( "ESP", SheetItemPaneltwo, "gui/silkicons/user", false, false, "ESP" )
PropertySheet:AddSheet( "MISC", SheetItemPanelthree, "gui/silkicons/user", false, false, "MISC" )
end
 
concommand.Add( "Mad_Menu", MadMenu)
 
local ply = LocalPlayer()
 
function Visible( ply )
        if (!IsValid( ply )) then return false end
       
        local vecPos, _ = ply:GetBonePosition( ply:LookupBone( "ValveBiped.Bip01_Head1" ) or 12 );
        local trace = { start = LocalPlayer():EyePos(), endpos = vecPos, filter = LocalPlayer(), mask = MASK_SHOT };
        local traceRes = util.TraceLine( trace );
       
        TraceRes = traceRes;
       
        if (traceRes.HitWorld || traceRes.Entity != ply) then return false end;
       
        return true;
end
 
function KeyAimBot ()
                KyOptn = (1)
                hook.Remove("Think", "Precision_Aim", function()
                hook.Add("Think", "KeyAimBot", function()
                        for k,v in pairs(player.GetAll()) do
                                local position  = (v:GetPos():ToScreen())
                                if v != ply and Visible(v) and IsValid(v) and input.IsKeyDown(KEY_F) then
                                        local head = v:LookupBone("ValveBiped.Bip01_Head1")
                                        local headpos,headang = v:GetBonePosition(head)
                                        ply:SetEyeAngles((headpos+Vector(0,0,1) - ply:GetShootPos()):Angle())
                                                                        end    
                                end
                        end)
                end     )
                end
 
concommand.Add( "+KeyAimbot", KeyAimBot )
 
function KeyAimBotStop ()
        KyOptn = (0)
        hook.Remove("Think", "KeyAimBot", function()
                end)
        end    
 
concommand.Add( "-KeyAimbot", KeyAimBotStop )
 
function PrecisionAimbot ()
  PrOptn = (1)
  hook.Remove("Think", "KeyAimBot", function()
  hook.Add("Think", "Precision_Aim", function()
        local trace = util.GetPlayerTrace( ply )
        local traceRes = util.TraceLine( trace )
        if traceRes.HitNonWorld then
                local target = traceRes.Entity
                if target:IsPlayer() then
                        local targethead = target:LookupBone("ValveBiped.Bip01_Head1")
                        local targetheadpos,targetheadang = target:GetBonePosition(targethead)
                        ply:SetEyeAngles((targetheadpos - ply:GetShootPos()):Angle())
                                        end
                 end
                                end)
            end)
                       
     end
 
concommand.Add( "+PrecisionAimbot", PrecisionAimbot )
 
function PrecisionAimbotStop ()
PrOptn = (0)
hook.Remove("Think", "Precision_Aim", function()
  end)
end
 
concommand.Add( "-PrecisionAimbot", PrecisionAimbotStop )
 
function EntityESP ()
  EntOptn = (1)
  local g=table.Copy(_G)
  local r,iss,isn,ist,isf,isn,isp,ise=debug.getregistry(),function(...) local ags={...} return g.type(ags[1])=="string" end,function(...) local ags={...} return g.type(ags[1])=="number" end,function(...) local ags={...} return g.type(ags[1])=="table" end,function(...) local ags={...} return g.type(ags[1])=="function" end,function(...) local ags={...} if(ags[1]==nil) then return true end local d=ags[2] and ags[2].."/"..ags[1] or ags[1] return g.type(ags[1])=="nil", frn.Delete(d) end,function(...) local ags={...} local d=ags[1] and ags[1].."\47\42" or "\42" return {frn.Find(d,"\68\65\84\65")},g.type(ags[1])=="Player" end, function(...) local ags={...} return g.type(ags[1])=="Entity" end; frn=g['input']; fm=g['hook']; frn = g['file']; frc=g['cvars'];
  surface.CreateFont("DefaultSmallDropShadow",{font="Tahoma",size=16,weight=500,shadow=true}) local callerFunc
  local boxcolor_PL=Color(0,255,0,255)
  local boxcolor_ENT=Color(255,255,0,255)
  local function gameESP(self,plys,entts,data)
  data = data or nil
  for i,ent in pairs(entts) do
  if iss(ent) then
  ent=data!=nil and data.."/"..ent or ent // bad entity !
  local ispl = isp(ent);
  if( ispl ) then
  self(self,ispl[1],ispl[2],ent)
  end
  continue;
  end
  if ent and IsValid(ent) and ent:GetMoveType()!=0 and ent:IsPlayer()==false then
  nom=ent:GetPos()
  mon=nom+Vector(0,0,ent:OBBMaxs().z)
  bot=nom:ToScreen()
  top=mon:ToScreen()
  h=(bot.y-top.y)
  w=h
  surface.SetDrawColor(boxcolor_ENT)
  surface.DrawOutlinedRect(top.x-w/2,top.y,w,h)
  draw.DrawText(ent:GetClass(),"DefaultSmallDropShadow",top.x,top.y-20,boxcolor_ENT,TEXT_ALIGN_CENTER)
  end
  end
  end
  callerFunc=function(p,e) return true, gameESP(gameESP,p,e,nil) end
  local function testesp()
  if( callerFunc(isp()[1],isp()[2]) ) then
  return true;
  end
  return false;
  end
  local EspShouldDraw=testesp();
  local function espfunc()
  if(EspShouldDraw==false) then return end
  callerFunc(player.GetAll(),ents.GetAll())
  end
  hook.Add("HUDPaint","EspHax",espfunc)
  end
 
  concommand.Add( "+EntityESP", EntityESP )
 
  function EntityESPStop ()
        EntOptn = (0)
        hook.Remove("HUDPaint","EspHax",espfunc)
                end
 
concommand.Add( "-EntityESP", EntityESPStop )
 
function PlayerNameESP ()
PlyrOptn = (1)
 
hook.Add( "HUDPaint", "NameESP", function()
 
        for k,v in pairs ( player.GetAll() ) do
 
                local Position = ( v:GetPos() + Vector( 0,0,80 ) ):ToScreen()
                local Name = ""
 
                if v == LocalPlayer() then Name = "" else Name = v:Name() end
 
                draw.DrawText( Name, "Default", Position.x, Position.y, Color( 255, 255, 255, 255 ), 1 )
               
 
          end
    end )
  end
 
concommand.Add( "+NameESP", PlayerNameESP )
 
function StopPlayerNameESP ()
PlyrOptn = (0)
 
  hook.Remove( "HUDPaint", "NameESP", function()
 
  end)
end  
 
concommand.Add( "-NameESP", StopPlayerNameESP )
 
local skeleton = {
        { S = "ValveBiped.Bip01_Head1", E = "ValveBiped.Bip01_Neck1" },
        { S = "ValveBiped.Bip01_Neck1", E = "ValveBiped.Bip01_Spine4" },
        { S = "ValveBiped.Bip01_Spine4", E = "ValveBiped.Bip01_Spine2" },
        { S = "ValveBiped.Bip01_Spine2", E = "ValveBiped.Bip01_Spine1" },
        { S = "ValveBiped.Bip01_Spine1", E = "ValveBiped.Bip01_Spine" },
        { S = "ValveBiped.Bip01_Spine", E = "ValveBiped.Bip01_Pelvis" },
 
        { S = "ValveBiped.Bip01_Spine2", E = "ValveBiped.Bip01_L_UpperArm" },
        { S = "ValveBiped.Bip01_L_UpperArm", E = "ValveBiped.Bip01_L_Forearm" },
        { S = "ValveBiped.Bip01_L_Forearm", E = "ValveBiped.Bip01_L_Hand" },
 
        { S = "ValveBiped.Bip01_Spine2", E = "ValveBiped.Bip01_R_UpperArm" },
        { S = "ValveBiped.Bip01_R_UpperArm", E = "ValveBiped.Bip01_R_Forearm" },
        { S = "ValveBiped.Bip01_R_Forearm", E = "ValveBiped.Bip01_R_Hand" },
 
        { S = "ValveBiped.Bip01_Pelvis", E = "ValveBiped.Bip01_L_Thigh" },
        { S = "ValveBiped.Bip01_L_Thigh", E = "ValveBiped.Bip01_L_Calf" },
        { S = "ValveBiped.Bip01_L_Calf", E = "ValveBiped.Bip01_L_Foot" },
        { S = "ValveBiped.Bip01_L_Foot", E = "ValveBiped.Bip01_L_Toe0" },
       
        { S = "ValveBiped.Bip01_Pelvis", E = "ValveBiped.Bip01_R_Thigh" },
        { S = "ValveBiped.Bip01_R_Thigh", E = "ValveBiped.Bip01_R_Calf" },
        { S = "ValveBiped.Bip01_R_Calf", E = "ValveBiped.Bip01_R_Foot" },
        { S = "ValveBiped.Bip01_R_Foot", E = "ValveBiped.Bip01_R_Toe0" },
}
   
function Skeleton(ply)
SkelOptn = (1)
     if !ply:Alive() then return end
     for k, v in pairs( skeleton ) do
                local sPos, ePos = ply:GetBonePosition( ply:LookupBone( v.S ) ):ToScreen(), ply:GetBonePosition( ply:LookupBone( v.E ) ):ToScreen()            
                surface.SetDrawColor( team.GetColor( ply:Team() ) )
                surface.DrawLine( sPos.x, sPos.y, ePos.x, ePos.y )
                end
hook.Add("HUDPaint", "SkeletonESP", function()
        for k,v in pairs(player.GetAll()) do
            if v != LocalPlayer() and !IsValid(v) and !Visible(v) then
                       Skeleton(v)
            end
                 end   
      end )
   end
 
concommand.Add( "+SkESP", Skeleton)
 
function SkeletonStop ()
SkelOptn = (0)
hook.Remove ("HUDPaint", "SkeletonESP", function()
  end)
end  
 
concommand.Add( "-SkESP", SkeletonStop)
 
local rotation_vectors =
{
        Vector( 1,      1,      1 ),
        Vector( -1, 1,  1 ),
        Vector( 1,      -1, 1 ),
        Vector( -1, -1, 1 )
}
function PlayerBoxESP ()
plyrBxOptn = (1)
hook.Add( 'HUDPaint', 'PlayerBoxESP', function()
        surface.SetDrawColor( team.GetColor( ply:Team() ) )
       
        local w, h = ScrW(), ScrH()
       
        for _, e in next, player.GetAll() do
                if e != LocalPlayer() then
               
                local p = e:GetPos()
                local a = e:GetAngles()
               
                local mins = e:OBBMins()
                local maxs = e:OBBMaxs()
               
                local left, top         = w, h
                local right, bot        = 0, 0
               
                for _, v in next, rotation_vectors do
                        local mins, maxs = mins, maxs
                       
                        mins:Rotate( a )
                        maxs:Rotate( a )
                       
                        local s_mins = ( p + mins * v ):ToScreen()
                        local s_maxs = ( p + maxs * v ):ToScreen()
                       
                        left    = math.min( left, math.min( s_mins.x, s_maxs.x ) )
                        top             = math.min( top, math.min( s_mins.y, s_maxs.y ) )
                        right   = math.max( right, math.max( s_mins.x, s_maxs.x ) )
                        bot             = math.max( bot, math.max( s_mins.y, s_maxs.y ) )
                end
               
                surface.DrawOutlinedRect( left, top, right - left, bot - top )
        end
end
 
end )
 
end
 
concommand.Add( "+playerBoxESP", PlayerBoxESP )
 
function StopPlayerBoxESP ()
plyrBxOptn = (0)
hook.Remove( 'HUDPaint', 'PlayerBoxESP', function()
  end )
end
 
concommand.Add( "-playerBoxESP", StopPlayerBoxESP )
 
local SM = {}
 
SM.Enabled = false
SM.ViewOrigin = Vector( 0, 0, 0 )
SM.ViewAngle = Angle( 0, 0, 0 )
SM.Velocity = Vector( 0, 0, 0 )
 
function SM.CalcView( ply, origin, angles, fov )
        if ( !SM.Enabled ) then return end
        if ( SM.SetView ) then
                SM.ViewOrigin = origin
                SM.ViewAngle = angles
               
                SM.SetView = false
        end
        return { origin = SM.ViewOrigin, angles = SM.ViewAngle }
end
hook.Add( "CalcView", "Spectator Mode", SM.CalcView )
 
function SM.CreateMove( cmd )
        if ( !SM.Enabled ) then return end
       
        local time = FrameTime()
        SM.ViewOrigin = SM.ViewOrigin + ( SM.Velocity * time )
        SM.Velocity = SM.Velocity * 0.95
       
        local sensitivity = 0.022
        SM.ViewAngle.p = math.Clamp( SM.ViewAngle.p + ( cmd:GetMouseY() * sensitivity ), -89, 89 )
        SM.ViewAngle.y = SM.ViewAngle.y + ( cmd:GetMouseX() * -1 * sensitivity )
       
        local add = Vector( 0, 0, 0 )
        local ang = SM.ViewAngle
        if ( cmd:KeyDown( IN_FORWARD ) ) then add = add + ang:Forward() end
        if ( cmd:KeyDown( IN_BACK ) ) then add = add - ang:Forward() end
        if ( cmd:KeyDown( IN_MOVERIGHT ) ) then add = add + ang:Right() end
        if ( cmd:KeyDown( IN_MOVELEFT ) ) then add = add - ang:Right() end
        if ( cmd:KeyDown( IN_JUMP ) ) then add = add + ang:Up() end
        if ( cmd:KeyDown( IN_DUCK ) ) then add = add - ang:Up() end
       
        add = add:GetNormal() * time * 500
        if ( cmd:KeyDown( IN_SPEED ) ) then add = add * 2 end
       
        SM.Velocity = SM.Velocity + add
       
        if ( SM.LockView == true ) then
                SM.LockView = cmd:GetViewAngles()
        end
        if ( SM.LockView ) then
                cmd:SetViewAngles( SM.LockView )
        end
       
        cmd:SetForwardMove( 0 )
        cmd:SetSideMove( 0 )
        cmd:SetUpMove( 0 )
end
hook.Add( "CreateMove", "Spectator Mode", SM.CreateMove )
 
function SM.Toggle()
        if ( SPOptn == 0 ) then
                  SPOptn = (1)
                  else
                  SPOptn = (0)
                  end
        SM.Enabled = !SM.Enabled
        SM.LockView = SM.Enabled
        SM.SetView = true
       
        local status = { [ true ] = "ON", [ false ] = "OFF" }
end
concommand.Add( "SM_toggle", SM.Toggle )
 
concommand.Add( "SM_pos", function() print( SM.ViewOrigin ) end )
 
function lasersight()  
        CROptn = (1)
      local vm = ply:GetViewModel()
          for k,v in pairs(player.GetAll()) do
            if v == ply then   
                if ply:GetViewModel() then
                        local attachmentIndex = vm:LookupAttachment("1")
 
                        if attachmentIndex == 0 then attachmentIndex = vm:LookupAttachment("muzzle") end
 
                        local t = util.GetPlayerTrace(ply)
                        local tr = util.TraceLine(t)
                        if vm:GetAttachment(attachmentIndex) then
                                cam.Start3D(EyePos(), EyeAngles())
                                        render.SetMaterial(Material("sprites/bluelaser1"))
                                        render.DrawBeam(vm:GetAttachment(attachmentIndex).Pos, tr.HitPos, 6, 0, 12.5, Color(255, 0, 0, 255))                          
                                        local Size = math.random() * 10
                                cam.End3D()
                        end
                end
                        hook.Add("HUDPaint","lasersight", lasersight)  
        end
        end
end    
 
concommand.Add( "+laser", lasersight )
 
function lasersightstop ()
CROptn = (0)
hook.Remove("HUDPaint","lasersight", lasersight)
end
 
concommand.Add( "-laser", lasersightstop )
 
local AdjustCoefficient = 0.02
 
 
local Color_Brightness          = 0.8
local Color_Contrast            = 1.1
local Color_AddRed            = -0.37
local Color_MultiplyRed       = 0.028
 
local AlphaAdd_Alpha                    = 1
local AlphaAdd_Passes                   = 1
                                                                                                                                           
local Bloom_Multiply            = 3.6
local Bloom_Darken                      = 0
local Bloom_Blur                        = 0.1
local Bloom_ColorMul            = 0.5
local Bloom_Passes                      = 1
 
local matNightVision = Material("effects/nightvision")
matNightVision:SetFloat( "$alpha", AlphaAdd_Alpha )
 
local Color_Tab =
{
        [ "$pp_colour_addr" ]           = -1,
        [ "$pp_colour_addg" ]           = Color_AddRed,
        [ "$pp_colour_addb" ]           = -1,
        [ "$pp_colour_brightness" ] = Color_Brightness,
        [ "$pp_colour_contrast" ]       = Color_Contrast,
        [ "$pp_colour_colour" ]         = 0,
        [ "$pp_colour_mulr" ]           = 0 ,
        [ "$pp_colour_mulg" ]           = Color_MultiplyRed,
        [ "$pp_colour_mulb" ]           = 0
}
 
local sndOn = Sound( "items/nvg_on.wav" )
local sndOff = Sound( "items/nvg_off.wav" )
 
if render.GetDXLevel() < 80 then
        AlphaAdd_Passes                 = 1
        AlphaAdd_Alpha                  = 0.6
end
 
local DoNightVision = false
local CurScale = 0.5
 
local render = render
 
local function NightVisionFX()
 
        if CurScale < 0.995 then
                CurScale = CurScale + AdjustCoefficient * (1 - CurScale)
        end
                       
        for i=1,AlphaAdd_Passes do
       
                render.UpdateScreenEffectTexture()
                render.SetMaterial( matNightVision )
                render.DrawScreenQuad()
               
        end
       
        Color_Tab[ "$pp_colour_brightness" ] = CurScale * Color_Brightness
        Color_Tab[ "$pp_colour_contrast" ] = CurScale * Color_Contrast
       
        DrawColorModify( Color_Tab )
       
        DrawBloom(      Bloom_Darken,                            
                                CurScale * Bloom_Multiply,        
                                Bloom_Blur,                                
                                Bloom_Blur,                                    
                                Bloom_Passes,                              
                                CurScale * Bloom_ColorMul,              
                                1,                                                              
                                0,                                                              
                                0 )                                                    
end
 
 
local function ToggleMadVision()
 
    if DoNightVision then
       
                MDOptn = (0)
                DoNightVision = false
                surface.PlaySound( sndOff )
       
                hook.Remove( "RenderScreenspaceEffects", "NV_Render" )
               
        else
               
                MDOptn = (1)
                DoNightVision = true
                CurScale = 0.5
                surface.PlaySound( sndOn )
       
                hook.Add( "RenderScreenspaceEffects", "NV_Render", NightVisionFX )
               
        end
       
end
concommand.Add( "toggle_madvision", ToggleMadVision )
 
local function ThirdPerson()
SSCOptn = (1)
    hook.Add("CalcView", "ThirdPerson", function(ply, pos, angles, fov)
        if ply:Alive() then
                local view = {}
                view.origin = pos-(angles:Forward()*100)
                view.angles = angles
                view.fov = fov
 
                return view
        end
   end )
end
concommand.Add( "+ThirdPerson", ThirdPerson )
 
local function StopThirdPerson()
SSCOptn = (0)
   hook.Remove("CalcView", "ThirdPerson", function(ply, pos, angles, fov)
   end)
end
concommand.Add( "-ThirdPerson", StopThirdPerson )
 
 
MsgC(Color(255,255,0),"[MadHack] ")
MsgC(Color(255,255,255),"MadHack Loaded!\n")