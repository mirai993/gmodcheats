/*
	
	snixzzCloud v2
	Author: Tyler Wearing (A.K.A 0xymoron) http://steamcommunity.com/id/sidewaysgamingdotnet/
	
	Credits
	ConnorMcF: Coding the entire web-end & making this entire thing possible <3 http://steamcommunity.com/profiles/76561198056767761/
	
	snixzzCloud is a Garry's Mod Lua script that loads a database of other Garry's Mod Lua scripts to load in-game without any installation.
	The idea was based on the SethHack ScriptCloud. It was an awesome concept but their website was trash.
	
	-=====================================================================-

	Hosted by http://snixzz.net ~ A Garry's Mod cheat provider & community.

	-=====================================================================-
	
	** WARNING **
	You should NEVER load this file, use the launcher provided @ http://snixzz.net/Cloud/ to get the latest & most stable version.
	
*/

local cloud = {}

local g = table.Copy( _G )
local r = g.debug.getregistry()

cloud.Info = {
	
	["Version"] = "2.0a",
	["Updated"] = "3/23/2016",
	
}

cloud.Variables = {

	["Data Directory"] = "sc2",
	
	["Debug"] = true,

}

cloud.Web = { -- URLs & apis, added for convenience 
	
	["Host"] = "http://pc.connormcf.com:3000",

}

cloud.Scripts = {} -- Table which will contain script names, ids, & descriptions.
cloud.Stats = {} -- Table which will contain stats for every script

cloud.Colors = {

	["Red"] = g.Color( 238, 30, 30 ),
	["Green"] = g.Color( 12, 230, 12 ),
	["Blue"] = g.Color( 38, 38, 234 ),
	["Yellow"] = g.Color( 255, 255, 0 ),

}

/**********************

	Custom Functions
	
***********************/

-- Simple console printing
function cloud.Msg( col, msg )
	
	g.MsgC( col or color_white, "[snixzzCloud v2] " )
	g.MsgC( color_white, msg .. "\n" )
	
end

-- Simple chat printing
function cloud.Chat( col, msg )
	
	g.chat.AddText(
		
		col or color_white, "[snixzzCloud v2] ",
		color_white, msg
	
	)
	
end

/********************

	Cache Data
	
********************/

function cloud.UpdateScriptList()

	cloud.Msg( cloud.Colors.Yellow, "Attempting to get script list." )
	
	g.http.Fetch( cloud.Web.Host .. "/api/scripts", 
		
		function( body )
			
			cloud.ScriptCache = g.util.JSONToTable( body )
			
			cloud.Msg( cloud.Colors.Green, "Successfully updated script list." )
			
			cloud.Scripts = {}
	
			for k, v in g.next, cloud.ScriptCache do
		
				cloud.Scripts[v.id] = v
	
			end
			
		end,
		
		function( error )
			
			cloud.ScriptCache = cloud.ScriptCache or {}
			cloud.Scripts = cloud.Scripts or {}
			
			cloud.Chat( cloud.Colors.Red, "Failed to update script list [" .. error .. "]" )
			
		end
		
	)
	
end

/********************

	Stats API
	
********************/

function cloud.GetScriptStats( id )

	if !cloud.Scripts[id] then
		
		cloud.Chat( cloud.Colors.Red, "Failed to find script id '" .. id .. "' in script database!" )
		
		return
	end

	cloud.Msg( cloud.Colors.Yellow, "Attempting to get stats for script id '" .. id .. "'" )
	
	g.http.Fetch( cloud.Web.Host .. "/api/script?id=" .. id,
	
		function( body )
			
			local tab = g.util.JSONToTable( body )

			cloud.Stats[id] = tab
			
			cloud.Msg( cloud.Colors.Green, "Successfully got stats for script id '" .. id .. "'" )
			
		end,
		
		function( error )
			
			cloud.Chat( cloud.Colors.Red, "Failed to get stats for script id '" .. id .. "' [" .. error .. "]" )
			
		end
		
	)	
	
end

function cloud.GetGlobalStats()
	
	cloud.Msg( cloud.Colors.Yellow, "Attempting to get global stats." )
	
	g.http.Fetch( cloud.Web.Host .. "/api/stats",
	
		function( body )
			
			local tab = g.util.JSONToTable( body )
			
			cloud.Stats["totalScripts"] = tab.totalScripts			
			cloud.Stats["totalInits"] = tab.totalInits
		
		end,
		
		function( error )
			
			cloud.Stats["totalScripts"] = "Unknown"
			cloud.Stats["totalInits"] = "Unknown"
			
			cloud.Chat( cloud.Colors.Red, "Failed to get global stats. [" .. error .. "]" )
			
		end
		
	)		
	
end

/************************

	Get & load scripts
	
************************/

function cloud.GetScriptSource( id )

	if !cloud.Scripts[id] then
		
		cloud.Chat( cloud.Colors.Red, "Failed to find script id '" .. id .. "' in script database!" )
		
		return
	end

	cloud.Msg( cloud.Colors.Yellow, "Attempting to get script source for id '" .. id .. "'" )
	
	g.http.Fetch( cloud.Web.Host .. "/dl/" .. id .. ".lua",
	
		function( body )
		
			cloud.Scripts[id]["Source"] = body
			
			cloud.Msg( cloud.Colors.Green, "Successfully got source for script id '" .. id .. "'" )
		
		end,
		
		function( error )
		
			cloud.Scripts[id]["Source"] = "print( 'invalid source' )"
			
			cloud.Chat( cloud.Colors.Red, "Failed to get source for script id '" .. id .. "' [" .. error .. "]" )
		
		end
	
	)
	
end

function cloud.RunScript( id )
	
	cloud.Msg( cloud.Colors.Yellow, "Attempting to execute script id '" .. id .. "'" )
	
end

/*****************

	Init func
	
*****************/

function cloud.Init()

	cloud.Chat( cloud.Colors.Yellow, "Loading snixzzCloud version " .. cloud.Info.Version .. " last updated " .. cloud.Info.Updated )

	cloud.UpdateScriptList()
	cloud.GetGlobalStats()
	
	-- Pre-cache scripts, stats, & more
	g.timer.Simple( 1.5, function()
	
		for k, v in g.next, cloud.Scripts do
		
			cloud.GetScriptStats( k ) -- Save script stats
			cloud.GetScriptSource( k ) -- Save script source
		
		end
		
	end )
	
end

cloud.Init()