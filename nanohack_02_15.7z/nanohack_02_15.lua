local ScrW = ScrW
local ScrH = ScrH
local pcall = pcall
local Color = Color
local Angle = Angle
local Vector = Vector
local EyePos = EyePos
local unpack = unpack
local require = require
local IsValid = IsValid
local CurTime = CurTime
local Material = Material
local GetConVar = GetConVar
local EyeAngles = EyeAngles
local LerpVector = LerpVector
local LocalPlayer = LocalPlayer
local RealFrameTime = RealFrameTime

local SetStencilCompareFunction = render.SetStencilCompareFunction
local SetStencilReferenceValue = render.SetStencilReferenceValue
local SetStencilZFailOperation = render.SetStencilZFailOperation
local SetStencilFailOperation = render.SetStencilFailOperation
local SetStencilPassOperation = render.SetStencilPassOperation
local SuppressEngineLighting = render.SuppressEngineLighting
local SetColorModulation = render.SetColorModulation
local MaterialOverride = render.MaterialOverride
local SetStencilEnable = render.SetStencilEnable
local ClearStencil = render.ClearStencil
local SetViewPort = render.SetViewPort
local SetMaterial = render.SetMaterial
local RenderView = render.RenderView
local DrawBeam = render.DrawBeam
local SetBlend = render.SetBlend

local pi = math.pi
local abs = math.abs
local min = math.min
local max = math.max
local fmod = math.fmod
local floor = math.floor
local Clamp = math.Clamp
local round = math.Round
local random = math.random
local Approach = math.Approach
local NormalizeAngle = math.NormalizeAngle

local HasValue = table.HasValue
local insert = table.insert
local remove = table.remove
local Random = table.Random
local Empty = table.Empty

local IgnoreZ = cam.IgnoreZ
local Start3D = cam.Start3D
local End3D = cam.End3D

local IsKeyDown = input.IsKeyDown
local IsMouseDown = input.IsMouseDown

local DrawOutlinedRect = surface.DrawOutlinedRect
local SetTextColor = surface.SetTextColor
local SetDrawColor = surface.SetDrawColor
local GetTextSize = surface.GetTextSize
local RoundedBoxEx = draw.RoundedBoxEx
local SetTextPos = surface.SetTextPos
local DrawCircle = surface.DrawCircle
local RoundedBox = draw.RoundedBox
local DrawText = surface.DrawText
local DrawRect = surface.DrawRect
local DrawLine = surface.DrawLine
local SetFont = surface.SetFont

local bor = bit.bor
local band = bit.band
local bnot = bit.bnot

local format = string.format
local strstr = string.find
local gsub = string.gsub

local MousePos = gui.MousePos
local vgui_Create = vgui.Create
local chat_AddText = chat.AddText

local GetAllPlayers = player.GetAll
local GetAllEnts = ents.GetAll

local TraceLine = util.TraceLine
local JSONToTable = util.JSONToTable
local TableToJSON = util.TableToJSON
local HealthToString = util.HealthToString
local GetPlayerTrace = util.GetPlayerTrace

local Exists = file.Exists
local MkDir = file.CreateDir
local Write = file.Write
local IsDir = file.IsDir
local Read = file.Read
local Dir = file.Find

local MOUSE_LEFT, MOUSE_MIDDLE, MOUSE_RIGHT =
	MOUSE_LEFT, MOUSE_MIDDLE, MOUSE_RIGHT
	
local KEY_W, KEY_A, KEY_S, KEY_D, KEY_E, KEY_N, KEY_SPACE, KEY_INSERT =
	KEY_W, KEY_A, KEY_S, KEY_D, KEY_E, KEY_N, KEY_SPACE, KEY_INSERT
	
local STENCILOPERATION_KEEP, STENCILOPERATION_REPLACE, STENCILCOMPARISONFUNCTION_ALWAYS, STENCILCOMPARISONFUNCTION_EQUAL =
	STENCILOPERATION_KEEP, STENCILOPERATION_REPLACE, STENCILCOMPARISONFUNCTION_ALWAYS, STENCILCOMPARISONFUNCTION_EQUAL
	
local IN_ATTACK, IN_ATTACK2, IN_RELOAD, IN_JUMP =
	IN_ATTACK, IN_ATTACK2, IN_RELOAD, IN_JUMP
	
local color_white, color_black, color_red, color_yellow, color_green, color_blue, color_dark, color_orange =
	Color( 255, 255, 255 ), Color( 0, 0, 0 ), Color( 255, 0, 0 ), Color( 255, 255, 0 ), Color( 0, 255, 0 ), Color( 0, 0, 255 ), Color( 0, 0, 0, 128 ), Color( 255, 120, 0, 255 )

local NH =
{
	ESP = false,
	NICK = false,
	INFO = false,
	CHAMS = false,
	LASER = false,
	TRACE = false,
	RADAR = false,
	NOSKY = false,
	WEPESP = false,
	ESPDST = false,
	BARREL = false,
	ESPBAR = false,
	SPYCAM = false,
	NOHANDS = false,
	FREECAM = false,
	DRAWBOX = false,
	TRIGGER = false,
	POSPRED = false,
	CROWBAR = false,
	FAKEVIEW = false,
	IGNORE_T = false,
	NORECOIL = false,
	WALLHACK = false,
	BONESCAN = false,
	AUTOSHOT = false,
	BUNNYHOP = false,
	SVCHEATS = false,
	SPECLIST = false,
	NOSPREAD = false,
	AUTOWALL = false,
	TRIGGERAIM = false,
	RADAR_NICK = false,
	AIMENABLED = false,
	AUTOPISTOL = false,
	DETECTSPEC = false,
	AUTORELOAD = false,
	THIRDPERSON = false,
	NAMESTEALER = false,
	IGNORE_TEAM = false,
	IGNORE_STEAM = false,
	DETECTRAITOR = false,
	ANTIAIMPROXY = false,
	ESPINCLUDENPCS = false,
	RADINCLUDENPCS = false,
	ESPINCLUDEPLAYERS = false,
	RADINCLUDEPLAYERS = false,
	BUTTON = 0,
	AIMMODE = 0,
	ANTIAIM = 0,
	BOXMODE = 1,
	AIMRANGE = 0,
	CROSSMODE = 0,
	SPEEDHACK = 1,
	RADAR_SIZE = 128,
	RADAR_SCALE = 2048,
	FSTR = 'default',
	LOOKUPBONE = 'Head',
	MENU_POS = { ScrW() / 2 - 240, ScrH() / 2 - 180 },
	SPEC_POS = { ScrW() * 0.1, ScrH() / 2 },
	DRONE_POS = { 10, 10 },
	RADAR_POS = { ScrW() * 0.1, ScrH() / 2 },
	LASERCOLOR = { r = 255, g = 255, b = 255, a = 255 },
	CROSSCOLOR = { r = 255, g = 255, b = 255, a = 255 }
}


local nh_menu
local nh_lpdc
local nh_campos
local nh_camang
local nh_target
local nh_lastpos
local nh_nickorig
local nh_gx, nh_gy
local nh_dx, nh_dy
local nh_sx, nh_sy
local nh_down_l, nh_down_r
local nh_aimbot = false
local nh_keydown = false
local nh_freecam = false
local nh_spec_grab = false
local nh_radar_grab = false
local nh_drone_grab = false

local nh_self = LocalPlayer()
local nh_oldpunch = Angle()
local nh_buttons = { MOUSE_LEFT, MOUSE_MIDDLE, MOUSE_RIGHT }
local nh_bones =
{
	Head = 'ValveBiped.Bip01_Head1',
	Neck = 'ValveBiped.Bip01_Neck1',
	Spine = 'ValveBiped.Bip01_Spine',
	Spine1 = 'ValveBiped.Bip01_Spine1',
	Spine2 = 'ValveBiped.Bip01_Spine2',
	Spine3 = 'ValveBiped.Bip01_Spine3',
	Spine4 = 'ValveBiped.Bip01_Spine4',
	[ 'R Hand' ] = 'ValveBiped.Bip01_R_Hand',
	[ 'L Hand' ] = 'ValveBiped.Bip01_L_Hand',
	[ 'R Calf' ] = 'ValveBiped.Bip01_R_Calf',
	[ 'R Foot' ] = 'ValveBiped.Bip01_R_Foot',
	[ 'R Toes' ] = 'ValveBiped.Bip01_R_Toe0',
	[ 'L Calf' ] = 'ValveBiped.Bip01_L_Calf',
	[ 'L Foot' ] = 'ValveBiped.Bip01_L_Foot',
	[ 'L Toes' ] = 'ValveBiped.Bip01_L_Toe0',
	[ 'L Thigh' ] = 'ValveBiped.Bip01_L_Thigh',
	[ 'R Thigh' ] = 'ValveBiped.Bip01_R_Thigh',
	[ 'L Forearm' ] = 'ValveBiped.Bip01_L_Forearm',
	[ 'R Forearm' ] = 'ValveBiped.Bip01_R_Forearm',
	[ 'L Upperarm' ] = 'ValveBiped.Bip01_L_UpperArm',
	[ 'R Upperarm' ] = 'ValveBiped.Bip01_R_UpperArm'
}

local nh_spectators = {}
local nh_rayt_buff = {}
local nh_namebuff = {}
local nh_targets = {}
local nh_keypads = {}
local nh_hooks = {}
local nh_next = 0
local nh_item = 1
local nh_p = nh_self:EyeAngles().p
local nh_y = nh_self:EyeAngles().y

local function NH_REGISTERHOOK( str, func )
	hook.Add( str, '', func )
end

local function NH_BUILDTRACE()
	local tr = GetPlayerTrace( nh_self )
	tr.mask = NH.AUTOWALL and 1174421507 or nil
	
	if NH.ANTIAIM ~= 0 then
		local vec = Vector( 16384, 0, 0 )
			vec:Rotate( Angle( nh_p, nh_y, 0 ) )
		
		local src = nh_self:GetShootPos()
		tr.endpos = src + vec
	end
	
	local tr = TraceLine( tr )
	return tr
end
local plr = GetAllPlayers()
local function NH_TARGETS( rad, esp, func )
	Empty( nh_targets )
	local plr = GetAllPlayers()
	
	if rad or esp then
		local ent = GetAllEnts()
		for i = 1, #ent do
			local pl = ent[ i ]
			if pl ~= nh_self and ( ( rad and NH.RADINCLUDENPCS or esp and NH.ESPINCLUDENPCS ) and pl:IsNPC() and pl:GetMoveType() ~= 0 and pl:GetClass() ~= 'npc_turret_floor' and pl:GetClass() ~= 'npc_grenade_frag' or ( rad and NH.RADINCLUDEPLAYERS or esp and NH.ESPINCLUDEPLAYERS ) and pl:IsPlayer() and pl:GetMoveType() ~= MOVETYPE_OBSERVER and pl:Health() > 0 ) then
				insert( nh_targets, pl )
			end
		end
	else
		local ent = GetAllEnts()
		for i = 1, #ent do
			local pl = ent[ i ]
			if pl ~= nh_self and ( ( NH.AIMMODE == 0 or NH.AIMMODE == 2 ) and pl:IsNPC() and pl:GetMoveType() ~= 0 and pl:GetClass() ~= 'npc_turret_floor' and pl:GetClass() ~= 'npc_grenade_frag' or ( NH.AIMMODE == 0 or NH.AIMMODE == 1 ) and pl:IsPlayer() and pl:GetMoveType() ~= MOVETYPE_OBSERVER and pl:Health() > 0 ) then
				insert( nh_targets, pl )
			end
		end
	end
end

local function NH_GETDIST( vec )
	local a = ( vec - nh_self:GetShootPos() ):Angle() - Angle( nh_p, nh_y, 0 )
	return abs( abs( a.p - 180 ) + abs( a.y - 180 ) - 360 )
end

local function NH_CANTARGET( ply, comp )
	if not ply:IsNPC() and not ply:IsPlayer() then return false end
	if ply:IsPlayer() and NH.AIMMODE == 2 then return false end
	if ply:IsNPC() and NH.AIMMODE == 1 then return false end
	if NH.IGNORE_T and nh_self.GetRole  and ply.GetRole and nh_self:GetRole() ~= ROLE_INNOCENT and nh_self:GetRole() == ply:GetRole() then return false end
	if comp and NH.AIMRANGE ~= 0 and NH_GETDIST( ply:GetPos() + ply:OBBCenter() ) > NH.AIMRANGE then return false end
	if comp and ply:IsPlayer() and ply:InVehicle() then return false end
	
	if ply:IsPlayer() and NH.AIMMODE == 0 or NH.AIMMODE == 1 then
		if NH.IGNORE_TEAM and ply:Team() == nh_self:Team() then return false end
		if NH.IGNORE_STEAM then
			if not ply.GetFriendSt then ply.GetFriendSt = ply:GetFriendStatus() == 'friend' end
			if ply.GetFriendSt then return false end
		else
			if ply.GetFriendSt then
				ply.GetFriendSt = nil
			end
		end
	end
	
	return true
end

local function NH_GETPLAYERCOLOR( ply )
	if NH_CANTARGET( ply ) then return color_red else return color_green end
end

local function NH_PREDICTPOS( pl, pos )
	local rft = RealFrameTime()
	return pos + nh_self:GetVelocity() * rft / 45 - pl:GetVelocity() * rft / 65
end

local function NH_GETBONEPOS( pl )
	local pos = nh_self:GetShootPos()
	
	nh_rayt_buff.filter = nh_self
	nh_rayt_buff.mask = NH.AUTOWALL and 1174421507 or nil
	
	if pl:GetBoneCount() < 2 then
		local over = pl:GetPos() + Vector( 0, 0, pl:OBBMaxs()[3] - ( pl:Crouching() and 45 or 25 ) )
		
		nh_rayt_buff.start = pos
		nh_rayt_buff.endpos = over
		
		local tr = TraceLine( nh_rayt_buff )
		
		if tr.Entity == pl then
			return over
		end
	end

	local mpos
	local bone = NH.LOOKUPBONE
	local aaproxy = NH.ANTIAIMPROXY and ( pl:EyeAngles().p < -89 or pl:EyeAngles().p > 89 )
	if aaproxy and ( bone == 'Head' or bone == 'Neck' ) then
		mpos = pl:GetPos() + pl:OBBCenter()
	end
	
	local NH_BONE
	if not aaproxy then
		NH_BONE = pl:LookupBone( nh_bones[ bone ] )
	end
	
	if NH_BONE then
		local endp = aaproxy and mpos or pl:GetBonePosition( NH_BONE )
		
		nh_rayt_buff.start = pos
		nh_rayt_buff.endpos = endp
		
		local tr = TraceLine( nh_rayt_buff )
		
		if tr.Entity == pl then
			return endp
		end
	end
	
	if NH.BONESCAN then
		for bone = 0, pl:GetBoneCount() - 1 do
			local endp = pl:GetBonePosition( bone )
			
			nh_rayt_buff.start = pos
			nh_rayt_buff.endpos = endp
			
			local tr = TraceLine( nh_rayt_buff )
			
			if tr.Entity == pl then
				return endp
			end
		end
	end
end

local title =
{
	'Because Lua is undetected',
	'That\'s why you should use an anti-cheat',
	'Show them how cool you are',
	'This is it! Awesome!',
	'Shoot them all bullets you got!'
}

local function NH_OPENMENU() end
local function NH_CLOSEMENU()
	if nh_menu and not nh_menu.Block and ( nh_menu.Hold or 0 ) < 15 then
		nh_menu.Block = true
		nh_menu:ShowCloseButton( true )
	end
	
	if not nh_menu or nh_menu.Block then return end
	
	nh_menu:Close()
	nh_menu = nil
end

local function NH__ABOT( panel )
	panel.Paint = nil
	panel:SetSize( 360, 335 )
	
	local y = 11
	local ch = vgui_Create( 'DCheckBoxLabel', panel )
		ch:SetPos( 5, y )
		ch:SetText( 'Enable aimbot' )
		ch:SizeToContents()
		ch.Think = function()
			ch:SetValue( NH.AIMENABLED )
		end
		
		ch.OnChange = function( self )
			NH.AIMENABLED = self:GetChecked()
		end
		
		y = y + 17.5
	local ch = vgui_Create( 'DCheckBoxLabel', panel )
		ch:SetPos( 5, y )
		ch:SetText( 'AutoShot' )
		ch:SizeToContents()
		ch.Think = function()
			ch:SetValue( NH.AUTOSHOT )
		end
		
		ch.OnChange = function( self )
			NH.AUTOSHOT = self:GetChecked()
		end
		
		y = y + 17.5
	local ch = vgui_Create( 'DCheckBoxLabel', panel )
		ch:SetPos( 5, y )
		ch:SetText( 'FakeView' )
		ch:SizeToContents()
		ch.Think = function()
			ch:SetValue( NH.FAKEVIEW )
		end
		
		ch.OnChange = function( self )
			NH.FAKEVIEW = self:GetChecked()
		end
		
		y = y + 17.5
	local ch = vgui_Create( 'DCheckBoxLabel', panel )
		ch:SetPos( 5, y )
		ch:SetText( 'BoneScan' )
		ch:SizeToContents()
		ch.Think = function()
			ch:SetValue( NH.BONESCAN )
		end
		
		ch.OnChange = function( self )
			NH.BONESCAN = self:GetChecked()
		end
		
		y = y + 17.5
	local ch = vgui_Create( 'DCheckBoxLabel', panel )
		ch:SetPos( 5, y )
		ch:SetText( 'Crowbar/Knife/Axe bot' )
		ch:SizeToContents()
		ch.Think = function()
			ch:SetValue( NH.CROWBAR )
		end
		
		ch.OnChange = function( self )
			NH.CROWBAR = self:GetChecked()
		end
		
		y = y + 17.5
	local ch = vgui_Create( 'DCheckBoxLabel', panel )
		ch:SetPos( 5, y )
		ch:SetText( 'AutoWall' )
		ch:SizeToContents()
		ch.Think = function()
			ch:SetValue( NH.AUTOWALL )
		end
		
		ch.OnChange = function( self )
			NH.AUTOWALL = self:GetChecked()
		end
		
		y = y + 17.5
	local ch = vgui_Create( 'DCheckBoxLabel', panel )
		ch:SetPos( 5, y )
		ch:SetText( '[TTT] Ignore role mates' )
		ch:SizeToContents()
		ch.Think = function()
			ch:SetValue( NH.IGNORE_T )
		end
		
		ch.OnChange = function( self )
			NH.IGNORE_T = self:GetChecked()
		end
		
		y = y + 17.5
	local ch = vgui_Create( 'DCheckBoxLabel', panel )
		ch:SetPos( 5, y )
		ch:SetText( 'Ignore team mates' )
		ch:SizeToContents()
		ch.Think = function()
			ch:SetValue( NH.IGNORE_TEAM )
		end
		
		ch.OnChange = function( self )
			NH.IGNORE_TEAM = self:GetChecked()
		end
		
		y = y + 17.5
	local ch = vgui_Create( 'DCheckBoxLabel', panel )
		ch:SetPos( 5, y )
		ch:SetText( 'Ignore Steam friends' )
		ch:SizeToContents()
		ch.Think = function()
			ch:SetValue( NH.IGNORE_STEAM )
		end
		
		ch.OnChange = function( self )
			NH.IGNORE_STEAM = self:GetChecked()
		end
		
		y = y + 17.5
	local ch = vgui_Create( 'DCheckBoxLabel', panel )
		ch:SetPos( 5, y )
		ch:SetText( 'Aim prediction' )
		ch:SizeToContents()
		ch.Think = function()
			ch:SetValue( NH.POSPRED )
		end
		
		ch.OnChange = function( self )
			NH.POSPRED = self:GetChecked()
		end
		
		y = y + 17.5
	local ch = vgui_Create( 'DCheckBoxLabel', panel )
		ch:SetPos( 5, y )
		ch:SetText( 'NoSpread' )
		ch:SizeToContents()
		ch.Think = function()
			ch:SetValue( NH.NOSPREAD )
		end
		
		ch.OnChange = function( self )
			NH.NOSPREAD = self:GetChecked()
		end
		
	local label = vgui_Create( 'DLabel', panel )
		label:SetPos( 245, 2 )
		label:SetText( 'Aimbot settings' )
		label:SizeToContents()
	
	local clk = Color( 255, 0, 0, 180 )
	local maus = vgui_Create( 'DPanel', panel )
		maus:SetPos( 300, 18 )
		maus:SetSize( 48, 64 )
		maus.Paint = function()
			local x, y = MousePos()
			local rx, ry = nh_menu:GetPos()
				x, y = x - rx - 425, y - ry - 41
			
			RoundedBox( 10, 0, 0, 48, 64, color_white )
			
			if x > 0 and x < 48 and y > 24 and y < 64 or NH.BUTTON == 0 then
				RoundedBoxEx( 10, 0, 24, 48, 40, clk, false, false, true, true )
				
				if IsMouseDown( MOUSE_LEFT ) and NH.BUTTON ~= 0 then
					NH.BUTTON = 0
				end
			end
			
			if x > 0 and x < 22 and y > 0 and y < 24 or NH.BUTTON == 1 then
				RoundedBoxEx( 10, 0, 0, 24, 24, clk, true, false, false, false )
				
				if IsMouseDown( MOUSE_LEFT ) and NH.BUTTON ~= 1 then
					NH.BUTTON = 1
				end
			end
			
			if x > 27 and x < 48 and y > 0 and y < 24 or NH.BUTTON == 3 then
				RoundedBoxEx( 10, 24, 0, 24, 24, clk, false, true, false, false )
				
				if IsMouseDown( MOUSE_LEFT ) and NH.BUTTON ~= 3 then
					NH.BUTTON = 3
				end
			end
			
			if x > 22 and x < 27 and y > 0 and y < 24 and IsMouseDown( MOUSE_LEFT ) then
				NH.BUTTON = 2
			end
			
			SetDrawColor( color_black )
			DrawLine( 0, 24, 48, 24 )
			DrawLine( 24, 0, 24, 24 )
			
			SetDrawColor( ( NH.BUTTON == 2 or x > 22 and x < 27 and y > 0 and y < 24 ) and clk or color_black )
			DrawRect( 22, 2, 5, 20 )
		end
		
	local label = vgui_Create( 'DLabel', panel )
		label:SetPos( 220, 88 )
		label:SetText( 'Target bone:' )
		label:SizeToContents()
	
	local bone = vgui_Create( 'DComboBox', panel )
		bone:SetPos( 220, 106 )
		bone:SetWide( 128 )
		for k in pairs( nh_bones ) do
			bone:AddChoice( k )
		end
		
		bone.Color = color_black
		bone.OnCursorEntered = function( self )
			self.Color = color_red
		end
		
		bone.OnCursorExited = function( self )
			self.Color = color_black
		end
		
		bone:ChooseOption( NH.LOOKUPBONE )
		
		bone.OnSelect = function( self )
			NH.LOOKUPBONE = self:GetValue()
		end
		
		bone.Paint = function( self )
			SetDrawColor( self.Color )
			DrawOutlinedRect( 0, 0, self:GetSize() )
		end
		
		bone.PaintOver = function( self )
			SetFont( 'DermaDefault' )
			SetTextColor( color_white )
			SetTextPos( 8, 4 )
			DrawText( self:GetValue() )
		end
		
	local label = vgui_Create( 'DLabel', panel )
		label:SetPos( 220, 138 )
		label:SetText( 'Aim mode:' )
		label:SizeToContents()
	
	local aimm = vgui_Create( 'DComboBox', panel )
		aimm:SetPos( 220, 156 )
		aimm:SetWide( 128 )
		aimm:AddChoice( 'Players and NPCs' )
		aimm:AddChoice( 'Players' )
		aimm:AddChoice( 'NPCs' )
		aimm.Color = color_black
		aimm.OnCursorEntered = function( self )
			self.Color = color_red
		end
		
		aimm.OnCursorExited = function( self )
			self.Color = color_black
		end
		
		aimm:ChooseOptionID( NH.AIMMODE + 1 )
		
		aimm.OnSelect = function( self, index )
			NH.AIMMODE = index - 1
		end
		
		aimm.Paint = function( self )			
			SetDrawColor( self.Color )
			DrawOutlinedRect( 0, 0, self:GetSize() )
		end
		
		aimm.PaintOver = function( self )
			SetFont( 'DermaDefault' )
			SetTextColor( color_white )
			SetTextPos( 8, 4 )
			DrawText( self:GetValue() )
		end
		
	local label = vgui_Create( 'DLabel', panel )
		label:SetPos( 220, 188 )
		label.Think = function()
			label:SetText( 'Aimbot range ' .. ( NH.AIMRANGE == 0 and 'unlimited' or 'limit: ' .. NH.AIMRANGE .. 'd' ) )
			label:SizeToContents()
		end
		
	local rad = vgui_Create( 'DSlider', panel )
		rad:SetPos( 220, 200 )
		rad:SetWide( 128 )
		rad:SetSlideX( NH.AIMRANGE / 180 )
		rad.Paint = function()
			SetDrawColor( color_black )
			DrawRect( 0, 9, 128, 3 )
		end
		
		rad.Think = function()
			NH.AIMRANGE = round( rad:GetSlideX() * 180 )
		end
end

local function NH__AUTO( panel )
	panel.Paint = nil
	panel:SetSize( 360, 335 )
	
	local y = 11
	local ch = vgui_Create( 'DCheckBoxLabel', panel )
		ch:SetPos( 5, y )
		ch:SetText( 'TriggerBot' )
		ch:SizeToContents()
		ch.Think = function()
			ch:SetValue( NH.TRIGGER )
		end
		
		ch.OnChange = function( self )
			NH.TRIGGER = self:GetChecked()
			
			if not NH.TRIGGER then
				NH.TRIGGERAIM = false
			end
		end
		
		y = y + 17.5
	local ch = vgui_Create( 'DCheckBoxLabel', panel )
		ch:SetPos( 5, y )
		ch:SetText( 'TriggerAim' )
		ch:SizeToContents()
		ch.Think = function()
			ch:SetValue( NH.TRIGGERAIM )
		end
		
		ch.OnChange = function( self )
			NH.TRIGGERAIM = self:GetChecked()
			
			if NH.TRIGGERAIM then
				NH.TRIGGER = true
			end
		end
		
		y = y + 17.5
	local ch = vgui_Create( 'DCheckBoxLabel', panel )
		ch:SetPos( 5, y )
		ch:SetText( 'AutoPistol' )
		ch:SizeToContents()
		ch.Think = function()
			ch:SetValue( NH.AUTOPISTOL )
		end
		
		ch.OnChange = function( self )
			NH.AUTOPISTOL = self:GetChecked()
		end
		
		y = y + 17.5
	local ch = vgui_Create( 'DCheckBoxLabel', panel )
		ch:SetPos( 5, y )
		ch:SetText( 'AutoReload' )
		ch:SizeToContents()
		ch.Think = function()
			ch:SetValue( NH.AUTORELOAD )
		end
		
		ch.OnChange = function( self )
			NH.AUTORELOAD = self:GetChecked()
		end
end

local function NH__VIS( panel )
	panel.Paint = nil
	panel:SetSize( 360, 335 )
	
	local y = 11
	local ch = vgui_Create( 'DCheckBoxLabel', panel )
		ch:SetPos( 5, y )
		ch:SetText( 'Wallhack' )
		ch:SizeToContents()
		ch.Think = function()
			ch:SetValue( NH.WALLHACK )
		end
		
		ch.OnChange = function( self )
			NH.WALLHACK = self:GetChecked()
			
			if not NH.WALLHACK then
				NH.CHAMS = false
			end
		end
		
		y = y + 17.5
	local ch = vgui_Create( 'DCheckBoxLabel', panel )
		ch:SetPos( 5, y )
		ch:SetText( 'Visuals: Include players' )
		ch:SizeToContents()
		ch.Think = function()
			ch:SetValue( NH.ESPINCLUDEPLAYERS )
		end
		
		ch.OnChange = function( self )
			NH.ESPINCLUDEPLAYERS = self:GetChecked()
		end
		
		y = y + 17.5
	local ch = vgui_Create( 'DCheckBoxLabel', panel )
		ch:SetPos( 5, y )
		ch:SetText( 'Visuals: Include NPCs' )
		ch:SizeToContents()
		ch.Think = function()
			ch:SetValue( NH.ESPINCLUDENPCS )
		end
		
		ch.OnChange = function( self )
			NH.ESPINCLUDENPCS = self:GetChecked()
		end
		
		y = y + 17.5
	local ch = vgui_Create( 'DCheckBoxLabel', panel )
		ch:SetPos( 5, y )
		ch:SetText( 'Chams' )
		ch:SizeToContents()
		ch.Think = function()
			ch:SetValue( NH.CHAMS )
		end
		
		ch.OnChange = function( self )
			NH.CHAMS = self:GetChecked()
			
			if NH.CHAMS then
				NH.WALLHACK = true
			end
		end
		
		y = y + 17.5
	local ch = vgui_Create( 'DCheckBoxLabel', panel )
		ch:SetPos( 5, y )
		ch:SetText( 'NoSky' )
		ch:SizeToContents()
		ch.Think = function()
			ch:SetValue( NH.NOSKY )
		end
		
		ch.OnChange = function( self )
			NH.NOSKY = self:GetChecked()
		end
		
		y = y + 17.5
	local ch = vgui_Create( 'DCheckBoxLabel', panel )
		ch:SetPos( 5, y )
		ch:SetText( 'NoHands' )
		ch:SizeToContents()
		ch.Think = function()
			ch:SetValue( NH.NOHANDS )
		end
		
		ch.OnChange = function( self )
			NH.NOHANDS = self:GetChecked()
		end
		
		y = y + 17.5
	local ch = vgui_Create( 'DCheckBoxLabel', panel )
		ch:SetPos( 5, y )
		ch:SetText( 'NoVisualRecoil' )
		ch:SizeToContents()
		ch.Think = function()
			ch:SetValue( NH.NORECOIL )
		end
		
		ch.OnChange = function( self )
			NH.NORECOIL = self:GetChecked()
		end
		y = y + 17.5
	local ch = vgui_Create( 'DCheckBoxLabel', panel )
		ch:SetPos( 5, y )
		ch:SetText( 'Full bright' )
		ch:SizeToContents()
		ch.ConVar = GetConVar( 'mat_fullbright' )
		ch.Think = function()
			ch:SetValue( ch.ConVar:GetInt() ~= 0 )
		end
		
		ch.OnChange = function( self )
			print('nope')
		end
		
		y = y + 17.5
	local ch = vgui_Create( 'DCheckBoxLabel', panel )
		ch:SetPos( 5, y )
		ch:SetText( 'Draw beam' )
		ch:SizeToContents()
		ch.Think = function()
			ch:SetValue( NH.LASER )
		end
		
		ch.OnChange = function( self )
			NH.LASER = self:GetChecked()
		end
		
		y = y + 17.5
	local ch = vgui_Create( 'DCheckBoxLabel', panel )
		ch:SetPos( 5, y )
		ch:SetText( 'Drone camera [N]' )
		ch:SizeToContents()
		ch.Think = function()
			ch:SetValue( NH.FREECAM )
		end
		
		ch.OnChange = function( self )
			NH.FREECAM = self:GetChecked()
		end
		
		y = y + 17.5
	local ch = vgui_Create( 'DCheckBoxLabel', panel )
		ch:SetPos( 5, y )
		ch:SetText( 'Spy camera' )
		ch:SizeToContents()
		ch.Think = function()
			ch:SetValue( NH.SPYCAM )
		end
		
		ch.OnChange = function( self )
			NH.SPYCAM = self:GetChecked()
		end
		
	local label = vgui_Create( 'DLabel', panel )
		label:SetPos( 260, 2 )
		label:SetText( 'Beam color' )
		label:SizeToContents()
		
	local rgb = vgui_Create( 'DLabel', panel )
		rgb:SetPos( 221, 20 )
		rgb:SetText( 'R: 255\nG: 255\nB: 255' )
		rgb:SizeToContents()
		rgb.Think = function()
			rgb:SetText( format( 'R: %i\nG: %i\nB: %i', NH.LASERCOLOR.r, NH.LASERCOLOR.g, NH.LASERCOLOR.b ) )
		end
		
	local ind = vgui_Create( 'DPanel', panel )
		ind:SetPos( 310, 20 )
		ind:SetSize( 40, 40 )
		ind.Paint = function()
			SetDrawColor( NH.LASERCOLOR )
			DrawRect( 0, 0, ind:GetSize() )
			
			SetDrawColor( color_black )
			DrawOutlinedRect( 0, 0, ind:GetSize() )
		end
		
	local r = vgui_Create( 'DSlider', panel )
		r:SetPos( 220, 60 )
		r:SetWide( 128 )
		r:SetSlideX( NH.LASERCOLOR.r / 255 )
		r.Paint = function()
			SetDrawColor( color_black )
			DrawRect( 0, 9, 128, 3 )
		end
		
		r.Think = function()
			NH.LASERCOLOR.r = r:GetSlideX() * 255
		end
		
	local g = vgui_Create( 'DSlider', panel )
		g:SetPos( 220, 80 )
		g:SetWide( 128 )
		g:SetSlideX( NH.LASERCOLOR.g / 255 )
		g.Paint = function()
			SetDrawColor( color_black )
			DrawRect( 0, 9, 128, 3 )
		end
		
		g.Think = function()
			NH.LASERCOLOR.g = g:GetSlideX() * 255
		end
		
	local b = vgui_Create( 'DSlider', panel )
		b:SetPos( 220, 100 )
		b:SetWide( 128 )
		b:SetSlideX( NH.LASERCOLOR.b / 255 )
		b.Paint = function()
			SetDrawColor( color_black )
			DrawRect( 0, 9, 128, 3 )
		end
		
		b.Think = function()
			NH.LASERCOLOR.b = b:GetSlideX() * 255
		end
end

local function NH__ESP( panel )
	panel.Paint = nil
	panel:SetSize( 360, 335 )
	
	local y = 11
	local ch = vgui_Create( 'DCheckBoxLabel', panel )
		ch:SetPos( 5, y )
		ch:SetText( 'Nick ESP' )
		ch:SizeToContents()
		ch.Think = function()
			ch:SetValue( NH.NICK )
		end
		
		ch.OnChange = function( self )
			NH.NICK = self:GetChecked()
		end
		
		y = y + 17.5
	local ch = vgui_Create( 'DCheckBoxLabel', panel )
		ch:SetPos( 5, y )
		ch:SetText( 'Health and armor ESP' )
		ch:SizeToContents()
		ch.Think = function()
			ch:SetValue( NH.INFO )
		end
		
		ch.OnChange = function( self )
			NH.INFO = self:GetChecked()
			
			if not NH.INFO then
				NH.WEPESP = false
			end
		end
		
		y = y + 17.5
	local ch = vgui_Create( 'DCheckBoxLabel', panel )
		ch:SetPos( 5, y )
		ch:SetText( 'Weapon ESP' )
		ch:SizeToContents()
		ch.Think = function()
			ch:SetValue( NH.WEPESP )
		end
		
		ch.OnChange = function( self )
			NH.WEPESP = self:GetChecked()
			
			if NH.WEPESP then
				NH.INFO = true
			end
		end
		
		y = y + 17.5
	local ch = vgui_Create( 'DCheckBoxLabel', panel )
		ch:SetPos( 5, y )
		ch:SetText( 'Barrel ESP' )
		ch:SizeToContents()
		ch.Think = function()
			ch:SetValue( NH.BARREL )
		end
		
		ch.OnChange = function( self )
			NH.BARREL = self:GetChecked()
		end
		
		y = y + 17.5
	local ch = vgui_Create( 'DCheckBoxLabel', panel )
		ch:SetPos( 5, y )
		ch:SetText( 'Distance ESP' )
		ch:SizeToContents()
		ch.Think = function()
			ch:SetValue( NH.ESPDST )
		end
		
		ch.OnChange = function( self )
			NH.ESPDST = self:GetChecked()
		end
		
		y = y + 17.5
	local ch = vgui_Create( 'DCheckBoxLabel', panel )
		ch:SetPos( 5, y )
		ch:SetText( 'Health and armor bars' )
		ch:SizeToContents()
		ch.Think = function()
			ch:SetValue( NH.ESPBAR )
		end
		
		ch.OnChange = function( self )
			NH.ESPBAR = self:GetChecked()
		end
		
		y = y + 17.5
	local ch = vgui_Create( 'DCheckBoxLabel', panel )
		ch:SetPos( 5, y )
		ch:SetText( 'Lines' )
		ch:SizeToContents()
		ch.Think = function()
			ch:SetValue( NH.TRACE )
		end
		
		ch.OnChange = function( self )
			NH.TRACE = self:GetChecked()
		end
	
	local label = vgui_Create( 'DLabel', panel )
		label:SetPos( 260, 2 )
		label:SetText( 'ESP boxes' )
		label:SizeToContents()
	
	local espbox = vgui_Create( 'DComboBox', panel )
		espbox:SetPos( 220, 18 )
		espbox:SetWide( 128 )
		espbox:AddChoice( 'Off' )
		espbox:AddChoice( '2D boxes' )
		espbox:AddChoice( '3D boxes' )
		espbox.Color = color_black
		espbox.OnCursorEntered = function( self )
			self.Color = color_red
		end
		
		espbox.OnCursorExited = function( self )
			self.Color = color_black
		end
		
		if NH.ESP then
			espbox:ChooseOptionID( 2 )
		elseif NH.DRAWBOX then
			espbox:ChooseOptionID( 3 )
		else
			espbox:ChooseOptionID( 1 )
		end
		
		espbox.OnSelect = function( self, index )
			if index == 1 then
				NH.ESP = false
				NH.DRAWBOX = false
				
				return
			end
			
			if index == 2 then
				NH.ESP = true
				NH.DRAWBOX = false
			else
				NH.ESP = false
				NH.DRAWBOX = true
			end
		end
		
		espbox.Paint = function( self )
			SetDrawColor( self.Color )
			DrawOutlinedRect( 0, 0, self:GetSize() )
		end
		
		espbox.PaintOver = function( self )
			SetFont( 'DermaDefault' )
			SetTextColor( color_white )
			SetTextPos( 8, 4 )
			DrawText( espbox:GetValue() )
		end
		
	local espdem = vgui_Create( 'DPanel', panel )
		espdem:SetPos( 156, 48 )
		espdem:SetSize( 192, 256 )
		espdem.Paint = function()
			SetDrawColor( color_red )
			DrawOutlinedRect( 56, 0, 80, 200 )
			
			if NH.BOXMODE == 1 then
				SetDrawColor( color_black )
				DrawRect( 56, 202, 80, 4 )
				
				SetDrawColor( color_red )
				DrawRect( 57, 203, 71.76, 2 )
				
				SetDrawColor( color_black )
				DrawRect( 56, 205, 80, 4 )
				
				SetDrawColor( color_blue )
				DrawRect( 57, 206, 26.52, 2 )
				
				SetFont( 'DermaDefault' )
				SetTextColor( color_green )
				SetTextPos( 96 - GetTextSize( 'NanoCat' ) / 2, 208 )
				DrawText( 'NanoCat' )
				
				local str = { 'H: 92' }
				str[ 2 ] = 'W: weapon_crowbar'
				
				SetTextColor( color_yellow )
				
				local y = 1
				local w = max( GetTextSize( str[ 1 ] ), GetTextSize( str[ 2 ] or '' ) )
				for i = 1, 2 do
					local t = str[ i ]
					
					if t then
						SetTextPos( 96 - w / 2, 208 + y * 12 )
						DrawText( str[ i ] )
						
						if i == 1 then
							SetTextPos( 96 + w / 2 - GetTextSize( 'A: 34' ), 208 + y * 12 )
							DrawText( 'A: 34' )
						end
						
						y = y + 1
					end
				end
			elseif NH.BOXMODE == 0 then
				SetDrawColor( color_black )
				DrawRect( 50, 0, 4, 200 )
				
				SetDrawColor( color_red )
				DrawRect( 51, 17.84, 2, 182.16 )
				
				SetDrawColor( color_black )
				DrawRect( 46, 0, 4, 200 )
				
				SetDrawColor( color_blue )
				DrawRect( 47, 132.64, 2, 67.32 )
				
				SetFont( 'DermaDefault' )
				SetTextColor( color_green )
				SetTextPos( 42 - GetTextSize( 'NanoCat' ), 0 )
				DrawText( 'NanoCat' )
				
				SetTextColor( color_yellow )
				SetTextPos( 42 - GetTextSize( 'H: 92' ), 12 )
				DrawText( 'H: 92' )
				
				SetTextPos( 42 - GetTextSize( 'A: 34' ), 24 )
				DrawText( 'A: 34' )
				
				SetTextPos( 42 - GetTextSize( 'W: weapon_crowbar' ), 36 )
				DrawText( 'W: weapon_crowbar' )
			elseif NH.BOXMODE == 2 then
				SetDrawColor( color_black )
				DrawRect( 138, 0, 4, 200 )
				
				SetDrawColor( color_red )
				DrawRect( 139, 17.84, 2, 182.16 )
				
				SetDrawColor( color_black )
				DrawRect( 142, 0, 4, 200 )
				
				SetDrawColor( color_blue )
				DrawRect( 143, 132.64, 2, 67.32 )
				
				SetFont( 'DermaDefault' )
				SetTextColor( color_green )
				SetTextPos( 150, 0 )
				DrawText( 'NanoCat' )
				
				SetTextColor( color_yellow )
				SetTextPos( 150, 12 )
				DrawText( 'H: 92' )
				
				SetTextPos( 150, 24 )
				DrawText( 'A: 34' )
				
				SetTextPos( 150, 36 )
				DrawText( 'W: weapon_crowbar' )
			end
		end
		
	local esp2dp = vgui_Create( 'DComboBox', panel )
		esp2dp:SetPos( 156, 305 )
		esp2dp:SetWide( 192 )
		esp2dp:AddChoice( 'Left' )
		esp2dp:AddChoice( 'Middle' )
		esp2dp:AddChoice( 'Right' )
		esp2dp.Color = color_black
		esp2dp.OnCursorEntered = function( self )
			self.Color = color_red
		end
		
		esp2dp.OnCursorExited = function( self )
			self.Color = color_black
		end
		
		esp2dp:ChooseOptionID( NH.BOXMODE + 1 )
		esp2dp.OnSelect = function( self, index )
			NH.BOXMODE = index - 1
		end
		
		esp2dp.Paint = function( self )
			SetDrawColor( self.Color )
			DrawOutlinedRect( 0, 0, self:GetSize() )
		end
		
		esp2dp.PaintOver = function( self )
			SetFont( 'DermaDefault' )
			SetTextColor( color_white )
			SetTextPos( 8, 4 )
			DrawText( esp2dp:GetValue() )
		end
end

local function NH__HUD( panel )
	panel.Paint = nil
	panel:SetSize( 360, 335 )
	
	local y = 11
	local ch = vgui_Create( 'DCheckBoxLabel', panel )
		ch:SetPos( 5, y )
		ch:SetText( 'Draw radar' )
		ch:SizeToContents()
		ch.Think = function()
			ch:SetValue( NH.RADAR )
		end
		
		ch.OnChange = function( self )
			NH.RADAR = self:GetChecked()
			
			if not NH.RADAR then
				NH.RADAR_NICK = false
			end
		end
		
		y = y + 17.5
	local ch = vgui_Create( 'DCheckBoxLabel', panel )
		ch:SetPos( 5, y )
		ch:SetText( 'Radar: Include players' )
		ch:SizeToContents()
		ch.Think = function()
			ch:SetValue( NH.RADINCLUDEPLAYERS )
		end
		
		ch.OnChange = function( self )
			NH.RADINCLUDEPLAYERS = self:GetChecked()
		end
		
		y = y + 17.5
	local ch = vgui_Create( 'DCheckBoxLabel', panel )
		ch:SetPos( 5, y )
		ch:SetText( 'Radar: Include NPCs' )
		ch:SizeToContents()
		ch.Think = function()
			ch:SetValue( NH.RADINCLUDENPCS )
		end
		
		ch.OnChange = function( self )
			NH.RADINCLUDENPCS = self:GetChecked()
		end
		
		y = y + 17.5
	local ch = vgui_Create( 'DCheckBoxLabel', panel )
		ch:SetPos( 5, y )
		ch:SetText( 'Draw nick and classname on radar' )
		ch:SizeToContents()
		ch.Think = function()
			ch:SetValue( NH.RADAR_NICK )
		end
		
		ch.OnChange = function( self )
			NH.RADAR_NICK = self:GetChecked()
			
			if NH.RADAR_NICK then
				NH.RADAR = true
			end
		end
		
		y = y + 17.5
	local ch = vgui_Create( 'DCheckBoxLabel', panel )
		ch:SetPos( 5, y )
		ch:SetText( 'Draw spectators list' )
		ch:SizeToContents()
		ch.Think = function()
			ch:SetValue( NH.SPECLIST )
		end
		
		ch.OnChange = function( self )
			NH.SPECLIST = self:GetChecked()
			
			if NH.SPECLIST then
				NH.DETECTSPEC = true
			end
		end
		
	local label = vgui_Create( 'DLabel', panel )
		label:SetPos( 225, 2 )
		label:SetText( 'Custom crosshair settings' )
		label:SizeToContents()
		
	local rgb = vgui_Create( 'DLabel', panel )
		rgb:SetPos( 221, 20 )
		rgb:SetText( 'R: 255\nG: 255\nB: 255' )
		rgb:SizeToContents()
		rgb.Think = function()
			rgb:SetText( format( 'R: %i\nG: %i\nB: %i', NH.CROSSCOLOR.r, NH.CROSSCOLOR.g, NH.CROSSCOLOR.b ) )
		end
		
	local crmode = vgui_Create( 'DComboBox', panel )
		crmode:SetPos( 220, 120 )
		crmode:SetWide( 128 )
		crmode:AddChoice( 'Off' )
		crmode:AddChoice( 'Dot' )
		crmode:AddChoice( 'Cross' )
		crmode:AddChoice( 'Cross in a box' )
		crmode:AddChoice( 'Cross in a circle' )
		crmode:ChooseOptionID( NH.CROSSMODE + 1 )
		crmode.Color = color_black
		crmode.OnCursorEntered = function( self )
			self.Color = color_red
		end
		
		crmode.OnCursorExited = function( self )
			self.Color = color_black
		end
		
		crmode.OnSelect = function( self, index )
			NH.CROSSMODE = index - 1
		end
		
		crmode.Paint = function( self )
			SetDrawColor( self.Color )
			DrawOutlinedRect( 0, 0, self:GetSize() )
		end
		
		crmode.PaintOver = function( self )
			SetFont( 'DermaDefault' )
			SetTextColor( color_white )
			SetTextPos( 8, 4 )
			DrawText( crmode:GetValue() )
		end
		
	local ind = vgui_Create( 'DPanel', panel )
		ind:SetPos( 310, 20 )
		ind:SetSize( 40, 40 )
		ind.Paint = function()
			SetDrawColor( NH.CROSSCOLOR )
			
			if NH.CROSSMODE == 1 then
				DrawRect( 19, 19, 2, 2 )
				
				DrawRect( 17, 19, 2, 2 )
				DrawRect( 21, 19, 2, 2 )
				
				DrawRect( 19, 17, 2, 2 )
				DrawRect( 19, 21, 2, 2 )
				
				DrawRect( 18, 18, 2, 2 )
				DrawRect( 18, 20, 2, 2 )
				DrawRect( 20, 18, 2, 2 )
				DrawRect( 20, 20, 2, 2 )
			end
			
			if NH.CROSSMODE == 2 then
				DrawLine( 5, 20, 35, 20 )
				DrawLine( 20, 5, 20, 35 )
			end
			
			if NH.CROSSMODE == 3 then
				DrawLine( 5, 20, 35, 20 )
				DrawLine( 20, 5, 20, 35 )
				DrawOutlinedRect( 0, 0, 40, 40 )
			end
			
			if NH.CROSSMODE == 4 then
				DrawLine( 5, 20, 35, 20 )
				DrawLine( 20, 5, 20, 35 )
				DrawCircle( 20, 20, 20, NH.CROSSCOLOR )
			end
		end
		
	local r = vgui_Create( 'DSlider', panel )
		r:SetPos( 220, 60 )
		r:SetWide( 128 )
		r:SetSlideX( NH.CROSSCOLOR.r / 255 )
		r.Paint = function()
			SetDrawColor( color_black )
			DrawRect( 0, 9, 128, 3 )
		end
		
		r.Think = function()
			NH.CROSSCOLOR.r = r:GetSlideX() * 255
		end
		
	local g = vgui_Create( 'DSlider', panel )
		g:SetPos( 220, 80 )
		g:SetWide( 128 )
		g:SetSlideX( NH.CROSSCOLOR.g / 255 )
		g.Paint = function()
			SetDrawColor( color_black )
			DrawRect( 0, 9, 128, 3 )
		end
		
		g.Think = function()
			NH.CROSSCOLOR.g = g:GetSlideX() * 255
		end
		
	local b = vgui_Create( 'DSlider', panel )
		b:SetPos( 220, 100 )
		b:SetWide( 128 )
		b:SetSlideX( NH.CROSSCOLOR.b / 255 )
		b.Paint = function()
			SetDrawColor( color_black )
			DrawRect( 0, 9, 128, 3 )
		end
		
		b.Think = function()
			NH.CROSSCOLOR.b = b:GetSlideX() * 255
		end
		
	local label = vgui_Create( 'DLabel', panel )
		label:SetPos( 220, 150 )
		label.Think = function( self )
			self:SetText( 'Radar radius: ' .. NH.RADAR_SCALE .. 'u' )
			self:SizeToContents()
		end
		
	local rad = vgui_Create( 'DSlider', panel )
		rad:SetPos( 220, 160 )
		rad:SetWide( 128 )
		rad:SetSlideX( ( NH.RADAR_SCALE - 128 ) / 16256 )
		rad.Paint = function()
			SetDrawColor( color_black )
			DrawRect( 0, 9, 128, 3 )
		end
		
		rad.Think = function()
			NH.RADAR_SCALE = rad:GetSlideX() * 16256 + 128
		end
		
	local label = vgui_Create( 'DLabel', panel )
		label:SetPos( 220, 180 )
		label.Think = function( self )
			self:SetText( 'Radar size: ' .. NH.RADAR_SIZE * 2 .. 'px' )
			self:SizeToContents()
		end
		
	local sz = vgui_Create( 'DSlider', panel )
		sz:SetPos( 220, 190 )
		sz:SetWide( 128 )
		sz:SetSlideX( ( NH.RADAR_SIZE - 64 ) / 192 )
		sz.Paint = function()
			SetDrawColor( color_black )
			DrawRect( 0, 9, 128, 3 )
		end
		
		sz.Think = function()
			NH.RADAR_SIZE = sz:GetSlideX() * 192 + 64
		end
end

local fsStatus
local function NH__CONF( panel )
	panel.Paint = nil
	panel:SetSize( 360, 335 )
	
	local status = vgui_Create( 'DLabel', panel )
		status:SetPos( 5, 59 )
		status.SetValue = function( self, str )
			self:SetText( str )
			self:SizeToContents()
		end
		
		status:SetValue( fsStatus or ' ' )
		fsStatus = nil
	
	local save = vgui_Create( 'DComboBox', panel )
		save:SetPos( 5, 6 )
		save:SetWide( 128 )
		save.Color = color_black
		
		for _, f in pairs( Dir( 'nh/*', 'DATA' ) or {} ) do
			save:AddChoice( gsub( f, '.txt', '' ) )
		end
		
		save:SetText( NH.FSTR )
		save.OnCursorEntered = function( self )
			self.Color = color_red
		end
		
		save.OnCursorExited = function( self )
			self.Color = color_black
		end
		
		save.OnSelect = function( self )
			NH.FSTR = self:GetValue()
		end
		
		save.Paint = function( self )			
			SetDrawColor( self.Color )
			DrawOutlinedRect( 0, 0, self:GetSize() )
		end
		
		save.PaintOver = function( self )
			SetFont( 'DermaDefault' )
			SetTextColor( color_white )
			SetTextPos( 8, 4 )
			DrawText( save:GetValue() )
		end
		
		save.Think = function( self )
			self:SetValue( NH.FSTR )
		end
		
	local savet = vgui_Create( 'DTextEntry', panel )
		savet:SetPos( 5, 7 )
		savet:SetWide( 104 )
		savet:SetText( NH.FSTR )
		savet.Paint = nil
		savet.OnCursorEntered = function( self )
			save.Color = color_red
		end
		
		savet.OnCursorExited = function( self )
			save.Color = color_black
		end
		
		savet.OnChange = function( self )
			save:SetText( self:GetValue() )
			NH.FSTR = self:GetValue()
		end
		
		savet.Think = function( self )
			self:SetValue( NH.FSTR )
		end
		
	local saveb = vgui_Create( 'DButton', panel )
		saveb:SetPos( 5, 33 )
		saveb:SetSize( 61.5, save:GetTall() )
		saveb:SetText( 'Save' )
		saveb.Color = color_black
		
		saveb.OnCursorEntered = function( self )
			self.Color = color_red
		end
		
		saveb.OnCursorExited = function( self )
			self.Color = color_black
		end
		
		saveb.Paint = function( self )			
			SetDrawColor( self.Color )
			DrawOutlinedRect( 0, 0, self:GetSize() )
		end
		
		saveb.PaintOver = function( self )
			SetFont( 'DermaDefault' )
			SetTextColor( color_white )
			SetTextPos( 18, 4 )
			DrawText( saveb:GetValue() )
		end
		
		saveb.DoClick = function()
			if not IsDir( 'nh', 'DATA' ) then
				MkDir( 'nh' )
			end
			
			if IsDir( 'nh', 'DATA' ) then
				Write( 'nh/' .. NH.FSTR .. '.txt', TableToJSON( NH ) )
				
				if Exists( 'nh/' .. NH.FSTR .. '.txt', 'DATA' ) then
					status:SetValue( 'Config was successfuly saved as "' .. NH.FSTR .. '.txt"!' )
				else
					status:SetValue( 'Unknown saving error!' )
				end
			else
				status:SetValue( 'Saving error! Could not create a dir!' )
			end
		end
		
	local loadb = vgui_Create( 'DButton', panel )
		loadb:SetPos( 71.5, 33 )
		loadb:SetSize( 61.5, saveb:GetTall() )
		loadb:SetText( 'Load' )
		loadb.Color = color_black
		
		loadb.OnCursorEntered = function( self )
			self.Color = color_red
		end
		
		loadb.OnCursorExited = function( self )
			self.Color = color_black
		end
		
		loadb.Paint = function( self )
			SetDrawColor( self.Color )
			DrawOutlinedRect( 0, 0, self:GetSize() )
		end
		
		loadb.PaintOver = function( self )
			SetFont( 'DermaDefault' )
			SetTextColor( color_white )
			SetTextPos( 19, 4 )
			DrawText( loadb:GetValue() )
		end
		
		loadb.DoClick = function()
			if Exists( 'nh/' .. NH.FSTR .. '.txt', 'DATA' ) then
				local tbl = JSONToTable( Read( 'nh/' .. NH.FSTR .. '.txt', 'DATA' ) )
				
				if tbl then
					local outdated = false
					for k in pairs( NH ) do
						if type( tbl[ k ] ) ~= type( NH[ k ] ) then
							outdated = true
							break
						end
					end
					
					if outdated then
						status:SetValue( 'Error! File is damaged or got bad format!' )
					else
						NH = tbl
						fsStatus = 'Config was successfuly loaded from "' .. NH.FSTR .. '.txt"!'
						
						local Hold = nh_menu.Hold
						nh_menu:Remove()
						nh_menu = nil
						
						NH_OPENMENU()
						nh_menu.Hold = Hold
					end
				else
					status:SetValue( 'Error! File is damaged or got bad format!' )
				end
			else
				status:SetValue( 'Error! File does not exist' )
			end
		end
end

local function NH__MISC( panel )
	panel.Paint = nil
	panel:SetSize( 360, 335 )
	
	local y = 11
	local ch = vgui_Create( 'DCheckBoxLabel', panel )
		ch:SetPos( 5, y )
		ch:SetText( 'sv_cheats bypass' )
		ch:SizeToContents()
		ch.Think = function()
			ch:SetValue( NH.SVCHEATS )
		end
		
		ch.OnChange = function( self )
			NH.SVCHEATS = self:GetChecked()
			
			if not NH.SVCHEATS then
				NH.SPEEDHACK = 1
			end
		end
		
		y = y + 17.5
	local ch = vgui_Create( 'DCheckBoxLabel', panel )
		ch:SetPos( 5, y )
		ch:SetText( 'BHOP' )
		ch:SizeToContents()
		ch.Think = function()
			ch:SetValue( NH.BUNNYHOP )
		end
		
		ch.OnChange = function( self )
			NH.BUNNYHOP = self:GetChecked()
		end
		
		y = y + 17.5
	local ch = vgui_Create( 'DCheckBoxLabel', panel )
		ch:SetPos( 5, y )
		ch:SetText( 'Name stealer' )
		ch:SizeToContents()
		ch.Think = function()
			ch:SetValue( NH.NAMESTEALER )
		end
		
		ch.OnChange = function( self )
			NH.NAMESTEALER = self:GetChecked()
		end
		
		y = y + 17.5
	local ch = vgui_Create( 'DCheckBoxLabel', panel )
		ch:SetPos( 5, y )
		ch:SetText( 'Spectator detector' )
		ch:SizeToContents()
		ch.Think = function()
			ch:SetValue( NH.DETECTSPEC )
		end
		
		ch.OnChange = function( self )
			NH.DETECTSPEC = self:GetChecked()
			
			if not NH.DETECTSPEC then
				NH.SPECLIST = false
			end
		end
		
		y = y + 17.5
	local ch = vgui_Create( 'DCheckBoxLabel', panel )
		ch:SetPos( 5, y )
		ch:SetText( '[TTT] Traitor detector' )
		ch:SizeToContents()
		ch.Think = function()
			ch:SetValue( NH.DETECTRAITOR )
		end
		
		ch.OnChange = function( self )
			NH.DETECTRAITOR = self:GetChecked()
		end
		
		y = y + 17.5
	local ch = vgui_Create( 'DCheckBoxLabel', panel )
		ch:SetPos( 5, y )
		ch:SetText( 'Third person' )
		ch:SizeToContents()
		ch.Think = function()
			ch:SetValue( NH.THIRDPERSON )
		end
		
		ch.OnChange = function( self )
			NH.THIRDPERSON = self:GetChecked()
		end
		
		y = y + 17.5
	local ch = vgui_Create( 'DCheckBoxLabel', panel )
		ch:SetPos( 5, y )
		ch:SetText( 'AntiAim proxy' )
		ch:SizeToContents()
		ch.Think = function()
			ch:SetValue( NH.ANTIAIMPROXY )
		end
		
		ch.OnChange = function( self )
			NH.ANTIAIMPROXY = self:GetChecked()
		end
		
	local label = vgui_Create( 'DLabel', panel )
		label:SetPos( 220, 2 )
		label.Think = function( self )
			self:SetText( 'AntiAim mode' )
			self:SizeToContents()
		end
		
	local aa = vgui_Create( 'DComboBox', panel )
		aa:SetPos( 220, 18 )
		aa:SetWide( 128 )
		aa:AddChoice( 'Off' )
		aa:AddChoice( 'Invert' )
		aa:AddChoice( 'Invert spin' )
		aa:ChooseOptionID( NH.ANTIAIM + 1 )
		aa.Color = color_black
		aa.OnCursorEntered = function( self )
			self.Color = color_red
		end
		
		aa.OnCursorExited = function( self )
			self.Color = color_black
		end
		
		aa.OnSelect = function( self, index )
			NH.ANTIAIM = index - 1
		end
		
		aa.Paint = function( self )			
			SetDrawColor( self.Color )
			DrawOutlinedRect( 0, 0, self:GetSize() )
		end
		
		aa.PaintOver = function( self )
			SetFont( 'DermaDefault' )
			SetTextColor( color_white )
			SetTextPos( 8, 4 )
			DrawText( aa:GetValue() )
		end
		
	local label = vgui_Create( 'DLabel', panel )
		label:SetPos( 220, 45 )
		label.Think = function( self )
			self:SetText( 'SpeedHack (ON E): ' .. ( NH.SPEEDHACK == 1 and 'off' or NH.SPEEDHACK ) )
			self:SizeToContents()
		end
		
	local spd = vgui_Create( 'DSlider', panel )
		spd:SetPos( 220, 55 )
		spd:SetWide( 128 )
		spd:SetSlideX( ( NH.SPEEDHACK - 1 ) / 9 )
		spd.Paint = function()
			SetDrawColor( color_black )
			DrawRect( 0, 9, 128, 3 )
		end
		
		spd.Think = function()
			NH.SPEEDHACK = round( spd:GetSlideX() * 9 + 1 )
			
			if NH.SPEEDHACK > 1 then
				NH.SVCHEATS = true
			end
		end
end

function NH_OPENMENU()
	if nh_menu then
		nh_menu.Hold = ( nh_menu.Hold or 0 ) + 1
		return
	end
	
	nh_menu = vgui_Create( 'DFrame' )
	nh_menu:SetPos( NH.MENU_POS[1], NH.MENU_POS[2] )
	nh_menu:SetSize( 480, 360 )
	nh_menu:MakePopup()
	nh_menu:SetTitle( 'NanoHack - ' .. Random( title ) )
	nh_menu:ShowCloseButton( false )
	nh_menu.Close = function()
		NH.MENU_POS = { nh_menu:GetPos() }
		
		nh_menu:Remove()
		nh_menu = nil
	end
	
	nh_menu.Paint = function( self )
		local x, y = self:GetPos()
		local w, h = self:GetSize()
		
		SetDrawColor( color_dark )
		DrawRect( 0, 0, w, h )
		
		SetDrawColor( color_black )
		DrawRect( 0, 0, w, 25 )
		DrawLine( 122, 0, 122, h )
		DrawOutlinedRect( 0, 0, w, h )
		
		self:SetPos( Clamp( x, 0, ScrW() - 480 ), Clamp( y, 0, ScrH() - 360 ) )
	end
	
	local cs = vgui_Create( 'DColumnSheet', nh_menu )
		cs:SetPos( 5, 25 )
		cs:SetSize( 480, 335 )	
	
	local abot = vgui_Create( 'DPanel', nh_menu )
		NH__ABOT( abot )
	
	cs:AddSheet( 'Aimbot', abot )
	
	local auto = vgui_Create( 'DPanel', nh_menu )
		NH__AUTO( auto )
	
	cs:AddSheet( 'Automation', auto )
	
	local vis = vgui_Create( 'DPanel', nh_menu )
		NH__VIS( vis )
	
	cs:AddSheet( 'Visuals', vis )
	
	local esp = vgui_Create( 'DPanel', nh_menu )
		NH__ESP( esp )
	
	cs:AddSheet( 'ESP', esp )
	
	local hud = vgui_Create( 'DPanel', nh_menu )
		NH__HUD( hud )
	
	cs:AddSheet( 'HUD', hud )
	
	local conf = vgui_Create( 'DPanel', nh_menu )
		NH__CONF( conf )
	
	cs:AddSheet( 'Load/Save', conf )
	
	local misc = vgui_Create( 'DPanel', nh_menu )
		NH__MISC( misc )
	
	cs:AddSheet( 'Misc', misc )
	
	cs.Items[ nh_item ].Button:DoClick()
	
	for i = 1, #cs.Items do
		local item = cs.Items[ i ]
		item.Button.Color = color_black
		item.Button.Paint = function( self )
			local w, h = self:GetSize()
			SetDrawColor( nh_item == i and color_red or self.Color )
			DrawOutlinedRect( 0, 0, w, h )
			
			if nh_item == i then
				DrawOutlinedRect( 1, 1, w - 2, h - 2 )
			end
		end
		
		item.Button.PaintOver = function( self )
			SetFont( 'DermaDefault' )
			SetTextColor( color_white )
			SetTextPos( self:GetWide() / 2 - GetTextSize( self:GetValue() ) / 2, 4 )
			DrawText( self:GetValue() )
		end
		
		item.Button.OnCursorEntered = function( self )
			self.Color = color_red
		end
		
		item.Button.OnCursorExited = function( self )
			self.Color = color_black
		end
		
		local clk = item.Button.DoClick
		item.Button.DoClick = function( self )
			clk( self )
			nh_item = i
		end
		
		item.Button:DockMargin( 0, 3, 6, 0 )
	end
end

local function NH_GUI()
	local x, y = MousePos()
	if IsMouseDown( MOUSE_LEFT ) then
		local w, h = ScrW(), ScrH()
		local vpw, vph = w / 4, h / 4 
		if nh_drone_grab then
			NH.DRONE_POS[1] = Clamp( x - nh_gx, 0, w - vpw )
			NH.DRONE_POS[2] = Clamp( y - nh_gy, 0, h - vph )
			
			return
		end
		
		if nh_radar_grab then
			NH.RADAR_POS[1] = Clamp( x - nh_dx, NH.RADAR_SIZE, w - NH.RADAR_SIZE )
			NH.RADAR_POS[2] = Clamp( y - nh_dy, NH.RADAR_SIZE, h - NH.RADAR_SIZE )
			
			return
		end
		
		local hg = 40 + #nh_spectators * 16
		if nh_spec_grab then
			NH.SPEC_POS[1] = Clamp( x - nh_sx, 128, w - 128 )
			NH.SPEC_POS[2] = Clamp( y - nh_sy, 0, h - hg )
			
			return
		end
		
		if NH.FREECAM and not nh_radar_grab and not nh_spec_grab and not nh_drone_grab and NH.DRONE_POS[1] < x and ( NH.DRONE_POS[2] + vpw ) > x and NH.DRONE_POS[2] < y and ( NH.DRONE_POS[2] + vph ) > y then
			nh_gx = x - NH.DRONE_POS[1]
			nh_gy = y - NH.DRONE_POS[2]
			
			nh_drone_grab = true
		end
	
		if NH.RADAR and not nh_radar_grab and not nh_spec_grab and not nh_drone_grab and ( NH.RADAR_POS[1] - NH.RADAR_SIZE ) < x and ( NH.RADAR_POS[1] + NH.RADAR_SIZE ) > x and ( NH.RADAR_POS[2] - NH.RADAR_SIZE ) < y and ( NH.RADAR_POS[2] + NH.RADAR_SIZE ) > y then
			nh_dx = x - NH.RADAR_POS[1]
			nh_dy = y - NH.RADAR_POS[2]
			
			nh_radar_grab = true
		end
		
		if NH.SPECLIST and not nh_radar_grab and not nh_spec_grab and not nh_drone_grab and ( NH.SPEC_POS[1] - 128 ) < x and ( NH.SPEC_POS[1] + 128 ) > x and ( NH.SPEC_POS[2] ) < y and ( NH.SPEC_POS[2] + hg ) > y then
			nh_sx = x - NH.SPEC_POS[1]
			nh_sy = y - NH.SPEC_POS[2]
			
			nh_spec_grab = true
		end
	else
		nh_drone_grab = false
		nh_radar_grab = false
		nh_spec_grab = false
	end
end

local nextfire = 0
local aa_yaw = 0
local attack

NH_REGISTERHOOK( 'CreateMove', function( cmd )
	local tr = NH_BUILDTRACE()
	
	nh_p = NormalizeAngle( Clamp( nh_p + cmd:GetMouseY() * 0.022, -89, 89 ) )
	nh_y = NormalizeAngle( nh_y - cmd:GetMouseX() * 0.022 )
	
	if nh_freecam then
		local ang = Angle( nh_p, nh_y, 0 )
		nh_campos = nh_campos + ( ang:Forward() * cmd:GetForwardMove() / 10000 + ang:Right() * cmd:GetSideMove() / 10000 ) * ( band( cmd:GetButtons(), IN_SPEED ) ~= 0 and 15 or 5 )
		
		if band( cmd:GetButtons(), IN_RELOAD ) ~= 0 then
			nh_campos = nh_self:GetShootPos()
			nh_camang = Angle( nh_p, nh_y, 0 )
		end
		
		cmd:SetButtons( 0 )
		
		cmd:SetForwardMove( 0 )
		cmd:SetSideMove( 0 )
		cmd:SetUpMove( 0 )
	end
	
	if NH.BUNNYHOP and band( cmd:GetButtons(), IN_JUMP ) ~= 0 then
		if not nh_self:IsOnGround() then
			cmd:SetButtons( band( cmd:GetButtons(), bnot( IN_JUMP ) ) )
		end
	end
	
	local w = nh_self:GetActiveWeapon()
	local valid = IsValid( w )
	if NH.AUTORELOAD and valid and w:Clip1() == 0 then
		cmd:SetButtons( bor( cmd:GetButtons(), IN_RELOAD ) )
	end
	
	local crowbar = true
	if NH.CROWBAR and valid and ( w:GetClass() == 'weapon_crowbar' or w:GetClass() == 'weapon_ttt_knife' or w:GetClass() == 'weapon_ttt_axe' ) then
		crowbar = tr.HitPos:Distance( nh_self:GetShootPos() ) < 75
	end
	
	if valid and crowbar and ( ( nh_aimbot and NH.AUTOSHOT and nh_target ) or NH.TRIGGER and IsValid( tr.Entity ) and NH_CANTARGET( tr.Entity ) ) then
		if nh_keydown then
			cmd:SetButtons( bor( cmd:GetButtons(), IN_ATTACK ) )
			nh_keydown = false
		else
			cmd:SetButtons( band( cmd:GetButtons(), IN_ATTACK ) )
			nh_keydown = true
		end
	end
	
	if NH.AUTOPISTOL then
		if band( cmd:GetButtons(), IN_ATTACK ) ~= 0 and valid and ( w.Primary and not w.Primary.Automatic or w:GetClass() == 'weapon_pistol' ) and w:Clip1() > 0 then
			if nh_down_l then
				cmd:SetButtons( bor( cmd:GetButtons(), IN_ATTACK ) )
				nh_down_l = false
			else
				cmd:SetButtons( band( cmd:GetButtons(), bnot( IN_ATTACK ) ) )
				nh_down_l = true
			end
		end
	end
	
	attack = band( cmd:GetButtons(), IN_ATTACK ) ~= 0
	
	local blockaim
	if NH.ANTIAIM ~= 0 then
		local ct = CurTime()
		if nextfire < ct then
			attack = false
			blockaim = true
		end
		
		if nextfire < ct then
			nextfire = ct + ( w.Primary and w.Primary.Delay and ( w.Primary.Delay - 0.001 ) or 0.001 )
		end
		
		if not attack then
			local ang = cmd:GetViewAngles()
			
			aa_yaw = NormalizeAngle( aa_yaw - 75 )
			
			ang.p = -181
			ang.y = NH.ANTIAIM == 1 and nh_y - 180 or aa_yaw
			ang.r = NH.ANTIAIM == 1 and -181 or ( ang.r == -181 and 181 or -181 )
			
			cmd:SetForwardMove( -cmd:GetForwardMove() )
			cmd:SetSideMove( -cmd:GetSideMove() )
			cmd:SetViewAngles( ang )
		else
			cmd:SetViewAngles( Angle( nh_p, nh_y, 0 ) )
		end
	else
		local ang = cmd:GetViewAngles()
		
		if NH.FAKEVIEW then
			if not nh_aimbot and not IsValid( nh_target ) then
				nh_p = ang.p
				nh_y = ang.y
			else
				ang.p = nh_p
				ang.y = nh_y
			end
		else
			nh_p = ang.p
			nh_y = ang.y
		end
		
		ang.r = 0
		
		cmd:SetViewAngles( ang )
	end
	
	if nh_aimbot and not blockaim and IsValid( nh_target ) and nh_target:Health() > 0 and NH_CANTARGET( nh_target ) or NH.TRIGGERAIM and IsValid( tr.Entity ) and tr.Entity:Health() > 0 and NH_CANTARGET( tr.Entity ) then
		local nh_target = IsValid( nh_target ) and nh_target or tr.Entity
		local bp = NH_GETBONEPOS( nh_target )
		
		if bp then
			local vec = NH.POSPRED and NH_PREDICTPOS( nh_target, bp ) or bp
			local ang = ( vec - nh_self:GetShootPos() ):Angle()
			
			if NH.ANTIAIM == 0 then
				ang.p = NormalizeAngle( ang.p )
			end
			
			cmd:SetViewAngles( ang )
			
			if not NH.FAKEVIEW and NH.ANTIAIM ~= 0 then
				nh_p = ang.p
				nh_y = ang.y
			end
		end
	end
	
	--if NH.NOSPREAD and w.Base and strstr( w.Base, 'weapon_sh' ) and ( attack or band( cmd:GetButtons(), IN_ATTACK ) ~= 0 ) and band( cmd:GetButtons(), IN_ATTACK2 ) == 0 then
	--	cmd:SetButtons( bor( cmd:GetButtons(), IN_ATTACK2 ) )
	--end
	
	if NH.FAKEVIEW or NH.ANTIAIM ~= 0 then
		local m = NH.ANTIAIM ~= 0 and not attack and -1 or 1
		local move = Vector( cmd:GetForwardMove(), cmd:GetSideMove(), 0 )
		local vec = ( move:Angle() + ( cmd:GetViewAngles() - Angle( nh_p, nh_y, 0 ) ) ):Forward() * move:Length()
		
		cmd:SetForwardMove( vec[1] * m )
		cmd:SetSideMove( vec[2] * m )
	end
end )

NH_REGISTERHOOK( 'ShouldDrawLocalPlayer', function()
	if nh_freecam or NH.THIRDPERSON then return true end
end )

local buff = {}
NH_REGISTERHOOK( 'CalcView', function( ply, origin, angles, ... )
	Empty( buff )
	
	if nh_freecam then
		buff.origin = nh_campos
		buff.angles = Angle( nh_p, nh_y, 0 )
		return nh_cc_buff
	end
	
	if NH.THIRDPERSON then
		local ang = NH.ANTIAIM ~= 0 and Angle( nh_p, nh_y, 0 ) or nh_self:EyeAngles()
		
		buff.origin = nh_self:GetShootPos() - ang:Forward() * 100
		buff.angles = ang
		return buff
	end
	
	if origin:Distance( nh_self:GetShootPos() ) < 20 then
		if NH.FAKEVIEW then
			buff.angles = Angle( nh_p, nh_y, 0 )
			return buff
		end
	
		if NH.ANTIAIM ~= 0 then
			buff.angles = ( nh_lpress or nh_aimbot and nh_target ) and angles or Angle( nh_p, nh_y, 0 )
			return buff
		end
		
		if NH.NORECOIL then
			buff.angles = nh_self:EyeAngles()
			return buff
		end
	end
end )

local n_next = 0
NH_REGISTERHOOK( 'Think', function()
	nh_aimbot = NH.AIMENABLED and ( NH.BUTTON == 0 and true or IsMouseDown( nh_buttons[ NH.BUTTON ] ) )
	
	NH_GUI()
	
	if IsKeyDown( KEY_N ) and NH.FREECAM then
		if not nh_lpdc then
			nh_lpdc = true
			nh_freecam = not nh_freecam
			
			if not nh_freecam and nh_campos:Distance( nh_self:GetShootPos() ) < 25 then
				nh_campos, nh_camang = nil
			end
			
			if nh_freecam and not nh_campos then
				nh_campos = nh_self:GetShootPos()
			end
		end
	else
		nh_lpdc = false
	end
	
	if not NH.FREECAM then
		nh_freecam = false
		nh_campos, nh_camang = nil
	end
	
	if nh_freecam then
		nh_camang = Angle( nh_p, nh_y, 0 )
	end
	
	if IsKeyDown( KEY_INSERT ) then
		NH_OPENMENU()
	else
		NH_CLOSEMENU()
	end
	
	local w = nh_self:GetActiveWeapon()
	if w and w.Base == 'weapon_tttbase' then
		if NH.NORECOIL then
			if not w.shootbullet then
				w.shootbullet = w.ShootBullet
				w.ShootBullet = function( self, dmg, _, numbul, cone )
					self.shootbullet( self, dmg, 0, numbul, cone )
				end
			end
		else
			if w.shootbullet then
				w.ShootBullet = w.shootbullet
			end
		end
	end
	
	for i = 1, #plr do
		local pl = plr[ i ]
		
		if NH.DETECTRAITOR and KARMA and pl.GetRole and pl:GetRole() ~= ROLE_DETECTIVE then
			local w = pl:GetActiveWeapon()
			
			if IsValid( w ) and w.m_traitor ~= pl and w.CanBuy and HasValue( w.CanBuy, ROLE_TRAITOR ) then
				w.m_traitor = pl
				chat_AddText( color_red, '[NanoHack] ', color_orange, pl:Nick(), color_white, ' got traitor weapon ', color_orange, '"' .. w:GetClass() .. '"', color_white, '!' )
			end
		end
		
		if NH.DETECTSPEC then
			if pl:GetObserverTarget() == nh_self and not HasValue( nh_spectators, pl ) then
				insert( nh_spectators, pl )
				chat_AddText( color_red, '[NanoHack] ', color_orange, pl:Nick(), color_white, ' is spectating you!' )
			elseif pl:GetObserverTarget() ~= nh_self and HasValue( nh_spectators, pl ) then
				for i = 1, #nh_spectators do
					if nh_spectators[ i ] == pl then
						remove( nh_spectators, i )
					end
				end
				
				chat_AddText( color_red, '[NanoHack] ', color_orange, pl:Nick(), color_white, ' is no longer spectating you!' )
			end
		end
	end
	
	if NH.DETECTSPEC then
		for i = 1, #nh_spectators do
			if not IsValid( nh_spectators[ i ] ) then
				remove( nh_spectators, i )
			end
		end
	else
		Empty( nh_spectators )
	end
	
	if nh_aimbot then
		NH_TARGETS()
		
		local fov
		local found = false
		
		for i = 1, #nh_targets do
			local pl = nh_targets[ i ]
			local dst = NH_GETDIST( pl:GetPos() )
			if dst < ( fov or dst + 1 ) and pl:Health() > 0 and NH_CANTARGET( pl, true ) and NH_GETBONEPOS( pl ) then
				nh_target = pl
				fov = dst
				found = true
			end
		end
		
		if not found then
			nh_target = nil
		end
	end
end )

NH_REGISTERHOOK( 'PostDrawOpaqueRenderables', function()
	if NH.LASER then
		local tr = nh_self:GetEyeTrace()
		local src = IsValid( nh_self:GetViewModel() ) and nh_self:GetViewModel():GetAttachment( 1 ) and nh_self:GetViewModel():GetAttachment( 1 ).Pos or nh_self:GetPos() + Vector( 0, 0, 10 )
		
		SetMaterial( Material( 'trails/laser' ) )
		DrawBeam( src, tr.HitPos, 8, 12, 12, NH.LASERCOLOR )
	end
	
	if NH.WALLHACK and NH.CHAMS then
		local cham = Material( 'models/debug/debugwhite' )
		
		NH_TARGETS( false, true )
		ClearStencil()
		SetStencilEnable( true )
		SetStencilFailOperation( STENCILOPERATION_KEEP )
		SetStencilPassOperation( STENCILOPERATION_KEEP )
		SetStencilZFailOperation( STENCILOPERATION_REPLACE )
		SetStencilReferenceValue( 1 )
		MaterialOverride( cham )
		
		for i = 1, #nh_targets do
			local pl = nh_targets[ i ]
			if IsValid( pl ) then
				local w = pl:GetActiveWeapon()
				local wv = IsValid( w )
				local rgb = NH_GETPLAYERCOLOR( pl )
				
				SetColorModulation( rgb.r / 255, rgb.g / 255, rgb.b / 255 ) -- 318.75
				SetStencilCompareFunction( STENCILCOMPARISONFUNCTION_ALWAYS )
				SetBlend( 0.6 )
				
				pl:DrawModel()
				if wv then w:DrawModel() end
				
				SetBlend( 1 )
				
				SetStencilCompareFunction( STENCILCOMPARISONFUNCTION_EQUAL )
				SuppressEngineLighting( true )
				IgnoreZ( true )
				
				pl:DrawModel()
				if wv then w:DrawModel() end
				
				SuppressEngineLighting( false )
				IgnoreZ( false )
			end
		end
		
		MaterialOverride()
		SetColorModulation( 1, 1, 1 )
		SetStencilEnable( false )
	end
end )

NH_REGISTERHOOK( 'HUDPaint', function()
	NH_TARGETS( false, true )
	local w, h = ScrW(), ScrH()
	local hw, hh = w / 2, h / 2
	local str = 'NanoHack'
	if IsKeyDown( KEY_E ) and NH.SPEEDHACK ~= 1 then
		str = str .. ' - SpeedHacking at ' .. NH.SPEEDHACK
	end
	
	if NH.WALLHACK and not NH.CHAMS then
		Start3D( EyePos(), EyeAngles() )
		SuppressEngineLighting( true )
		
		for i = 1, #nh_targets do
			local pl = nh_targets[ i ]
			local w = pl:GetActiveWeapon()
			
			pl:DrawModel()
			if IsValid( w ) then w:DrawModel() end
		end
		
		SuppressEngineLighting( false )
		End3D()
	end
	
	for i = 1, #nh_targets do
		local pl = nh_targets[ i ]
		if NH.TRACE then
			local scr = pl:GetPos():ToScreen()
			
			SetDrawColor( NH_GETPLAYERCOLOR( pl ) )
			DrawLine( hw, hh, Clamp( scr.x, 0, w ), Clamp( scr.y, 0, h ) )
		end
			
		if NH.BARREL then
			if pl:IsPlayer() then
				local col = NH_GETPLAYERCOLOR( pl )
				local orig = pl:GetShootPos()
				local dest = orig + pl:GetAimVector() * 256
					orig, dest = orig:ToScreen(), dest:ToScreen()
				
				SetDrawColor( col )
				DrawLine( orig.x, orig.y, dest.x, dest.y )
			end
		end
		
		if NH.DRAWBOX then
			SetDrawColor( NH_GETPLAYERCOLOR( pl ) )
			
			local ang = Angle( 0, pl:EyeAngles().y, 0 )
			local nom = pl:GetPos()
			local mon = nom + Vector( 0, 0, pl:OBBMaxs()[3] )
			
			local bnd1 = Vector( 16, 16, 0 )
				bnd1:Rotate( ang )
				bnd1 = ( nom + bnd1 ):ToScreen()
				
			local bnd2 = Vector( 16, -16, 0 )
				bnd2:Rotate( ang )
				bnd2 = ( nom + bnd2 ):ToScreen()
				
			local bnd3 = Vector( -16, -16, 0 )
				bnd3:Rotate( ang )
				bnd3 = ( nom + bnd3 ):ToScreen()
				
			local bnd4 = Vector( -16, 16, 0 )
				bnd4:Rotate( ang )
				bnd4 = ( nom + bnd4 ):ToScreen()
				
			local bnd5 = Vector( 16, 16, 0 )
				bnd5:Rotate( ang )
				bnd5 = ( mon + bnd5 ):ToScreen()
				
			local bnd6 = Vector( 16, -16, 0 )
				bnd6:Rotate( ang )
				bnd6