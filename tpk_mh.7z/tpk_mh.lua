--[[
	MOD/lua/tpk.lua
	falco_backwards 1 | STEAM_0:1:2490980 <83.255.96.191:27005> | [04-03-14 12:08:27AM]
	===BadFile===
]]

local rearview = CreateClientConVar("mh_rearview", "0", false, false)

concommand.Add("mh_turn180", function() LocalPlayer():SetEyeAngles(LocalPlayer():EyeAngles()+Angle(0,180,0)) end)

hook.Add("CalcView", "tttrv", function(_,a,b,c)
if rearview:GetBool() then 
        b = b + Angle(0,180,0)
    end
return GAMEMODE:CalcView(_,a,b,c)
end)

hook.Add("CreateMove", "tttbw", function(cmd)
if rearview:GetBool() then
cmd:SetForwardMove(-cmd:GetForwardMove())
cmd:SetSideMove(-cmd:GetSideMove())
        cmd:SetUpMove(-cmd:GetUpMove())
end
end)