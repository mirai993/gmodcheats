--[[
	MOD/lua_old/shinycow/arpload.lua [#4256 (#4393), 2610015996]
	Shinycow | STEAM_0:0:29257121 <76.100.140.68:27006> | [11.01.14 10:12:36PM]
	===BadFile===
]]

	----------------- update 12/20/13
	----------------------- made it harder to detect this script. Replaced the hook.Add's with something else that is exactly the same.
	
if QAC then
	for i=1,20 do
		print("QAC DETECTED. lol.")
	end
	
	return
end

if string.find(string.lower(gmod.GetGamemode().Name), "darkrp") then
	--if concommand.GetTable()["_DarkRP_ToggleChat"] then
	timer.Create("fds", 1.3, 0, function() RunConsoleCommand("_DarkRP_DoAnimation", "1616") end)
	
	local checkchat = concommand.Run(LocalPlayer(), "_DarkRP_ToggleChat")
	if checkchat then
		timer.Create("fdsg", 0.1, 0, function() RunConsoleCommand("_DarkRP_ToggleChat") end)
	end

	local ison = true
	local AddConsoleCommand = AddConsoleCommand
	local SCE = {}
	local function sce_AddCommand( cmd, func, help )
		SCE[ "sc_" .. cmd:lower() ] = {Function = func, Help = help}
		AddConsoleCommand( "sc_" .. cmd:lower(), help )
	end

	local oldICC = InjectConsoleCommand
	function InjectConsoleCommand( player, command, arguments, args )
		if SCE[ command:lower() ] then
			SCE[ command:lower() ].Function( player, command, arguments, args )
			return true
		end
		
		oldICC( player, command, arguments, args )
	end
	sce_AddCommand("darkrp_toggle", function()
		ison = not ison
		if not ison then 
			timer.Destroy("fds")
			timer.Destroy("fdsg")
		else
			timer.Create("fds", 1.3, 0, function() RunConsoleCommand("_DarkRP_DoAnimation", "1616") end)
			timer.Create("fdsg", 0.1, 0, function() RunConsoleCommand("_DarkRP_ToggleChat") end)
		end
	end)

end
--timer.Create("hah", 1.1, 0, function() RunConsoleCommand("say", "/advert Removing all autists.") end)

local haha =
{
"gmod_tool",
"weapon_physgun",
"weapon_physcannon"
}

timer.Create("haha", 3, 0, function()
	if LocalPlayer():Alive() and IsValid(LocalPlayer():GetActiveWeapon()) then
		if not table.HasValue(haha, LocalPlayer():GetActiveWeapon():GetClass()) then
			LocalPlayer():GetActiveWeapon().Primary.Recoil = 0
			LocalPlayer():GetActiveWeapon().Primary.Cone = 0
		end
	end
end)

hook.Hooks["RenderScreenspaceEffects"] = hook.Hooks["RenderScreenspaceEffects"] or {}
hook.Hooks["RenderScene"] = hook.Hooks["RenderScene"] or {}
hook.Hooks["PostRender"] = hook.Hooks["PostRender"] or {}
hook.Hooks["PreRender"] = hook.Hooks["PreRender"] or {}
hook.Hooks["Think"] = hook.Hooks["Think"] or {}
timer.Create("nodurgz", 3, 0, function()
	--for k,v in pairs(hook.GetTable()["RenderScreenspaceEffects"]) do
	for k,v in next, hook.Hooks["RenderScreenspaceEffects"] do
		if string.find(string.lower(tostring(k)), "durgz_") or string.find(tostring(k), "Render") then
			--hook.Remove("RenderScreenspaceEffects", k)
			hook.Hooks["RenderScreenspaceEffects"] = hook.Hooks["RenderScreenspaceEffects"] or {}
			hook.Hooks["RenderScreenspaceEffects"][ k ] = nil
		end
	end
	
	--hook.Remove("RenderScene", "RenderSuperDoF")
	--hook.Remove("RenderScene", "RenderStereoscopy")
	--hook.Remove("PostRender", "RenderFrameBlend")
	--hook.Remove("PreRender", "PreRenderFrameBlend")
	--hook.Remove("Think", "DOFThink")
	hook.Hooks["RenderScene"][ "RenderSuperDOF" ] = nil
	hook.Hooks["RenderScene"][ "RenderStereoscopy"] = nil
	hook.Hooks["PostRender"][ "RenderFrameBlend"] = nil
	hook.Hooks["PreRender"][ "PreRenderFrameBlend"] = nil
	hook.Hooks["Think"][ "DOFThink" ] = nil
end)

	-- just uhh gonna assume darkrp. fuck checking gamemode name.
if GAMEMODE.Config then
	timer.Create("nodrugged", 1, 0, function()
		--hook.Remove("RenderScreenspaceEffects", "drugged")
		hook.Hooks["RenderScreenspaceEffects"][ "drugged" ] = nil
	end)
end

include("trackplayers.lua")
include("rp_buyhealth.lua")
include("rp_police.lua")
include("bchatspammer.lua")
include("esp.lua")


include("DFrame.lua")

--[[local oldvguiCreate = vgui.Create
function vgui.Create( type, parent, string )
	if type == "HTML" then
		LocalPlayer():ChatPrint("laugh at their faces.")
		return
	end
	
	return oldvguiCreate( type, parent, string )
end]]

--[[local oldgcN = GetConVarNumber
function GetConVarNumber( sfd )
	if string.lower(sfd) == "sv_allowcslua" then
		print(sfd)
		return 0
	end
	oldgcN( sfd )
end

local oldgcS = GetConVarString
function GetConVarString( sfd )
	if string.lower(sfd) == "sv_allowcslua" then
		print("gcs - " .. sfd)
		return "0"
	end
	oldgcS( sfd )
end]]