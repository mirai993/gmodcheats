--[[
	40.lua
	Erfie - New Phone :D | (STEAM_0:0:11602053)
	===DStream===
]]

--[[
          
   _____                        
  /  _  \   ____   ____   ____  
 /  /_\  \ /    \ /  _ \ /    \ 
/    |    \   |  (  <_> )   |  \
\____|__  /___|  /\____/|___|  /
        \/     \/            \/ 
				Dark Rp Generator
--]]
-- I've reserved all rights to this piece of script.  If you wish to distribute it please talk to me on sethhack forums
local version = "6.21"
local ddm
local choice
local conv = CreateClientConVar("cr_printtoconsole","0")
local convchief = CreateClientConVar("cr_ischiefserver","0")

local function getplayers()
for k,v in pairs(player.GetAll()) do
	ddm:AddChoice(v:Nick())
	end
end
local function dispbox()
    inf = vgui.Create("DFrame")
	inf:SetSize(400,400)
	inf:Center()
	inf:MakePopup()
	inf:SetTitle("Anon's Player Info version: "..version)
	inf:SetSkin("DarkRP")
	inf:SetBackgroundBlur(false)
	-- Main box dropdown menu
	ddm = vgui.Create("DMultiChoice",inf)
	ddm:SetSize(200,20)
	ddm:SetPos(5,35)
	
	getplayers()
	function ddm:OnSelect(index,value,data)
		choice = value
		-- Model
		for k,v in pairs(player.GetAll()) do
			if choice == v:Nick() then
				local mdl = vgui.Create( "DModelPanel", inf )
				mdl:SetModel( v:GetModel() )
				mdl:SetPos(150,25)
				mdl:SetSize( 300,300 )
				mdl:SetCamPos(Vector( 50, 90, 120 ))
				mdl:SetLookAt(Vector( 0, 0, 0 ))
		end
	end
end

	-- Checkbox for PIC
	local cbpc = vgui.Create("DCheckBoxLabel",inf)
	cbpc:SetPos(5,65)
	cbpc:SetText("Print in Console")
	cbpc:SetConVar("cr_printtoconsole")
	cbpc:SetValue(0)
	cbpc:SizeToContents()
	-- button to render info
	local bdm = vgui.Create("DButton",inf)
	bdm:SetSize(100,20)
	bdm:SetPos(5,380)
	bdm:SetText("Get Information!")
	-- On click of button
	bdm.DoClick = function()
	
		if conv:GetInt() == 1 then
			printconsole()	
		else
			dispinfobox()
		end
		inf:Close()
	end
	-- disp table
	local dpb = vgui.Create("DButton",inf)
	-- play with if you dare.
	dpb:SetSize(100,20)
	dpb:SetPos(115,380)
	dpb:SetText("Show Table")
	dpb.DoClick = function()
	disptabledtv()
	end	
end
function disptabledtv()
local dtv = vgui.Create("DListView")
	dtv:SetParent(inf)
	dtv:SetPos(5, 100)
	dtv:SetSize(250, 170)
	dtv:SetMultiSelect(false)
	dtv:AddColumn("Statistics")
	dtv:AddColumn("Values")
	-- on right click copy
	dtv.OnRowSelected = function( panel, line )
		LocalPlayer():ChatPrint("Copied to Clipboard:  "..dtv:GetLine(line):GetValue(1))
		SetClipboardText( dtv:GetLine(line):GetValue(2) ) 
		
	end
	for k,v in pairs(player.GetAll()) do
		if choice == v:Nick() then
			if v:IsSuperAdmin()  then
				Rank = "Super Admin"
			elseif v:IsAdmin() and !v:IsSuperAdmin() then
				Rank = "Admin"
			elseif !v:IsAdmin() and !v:IsSuperAdmin() then
				Rank = "Guest"
			
			end
			-- dec vars
			
			local money = v.DarkRPVars.money or 0
			local job = v.DarkRPVars.job or "Citizen"
			local salary = v.DarkRPVars.salary or 0
			
			-- ADDS LINES TO THE FKING DLISTVIEWBOX
			dtv:AddLine("Steam Name",v:SteamName())
			dtv:AddLine("Nick Name",v:Nick())
			dtv:AddLine("Health",v:Health())
			dtv:AddLine("Armor",v:Armor())
			dtv:AddLine("Money",money)
			dtv:AddLine("Job Name",job)
			dtv:AddLine("Rank",Rank)
			dtv:AddLine("SteamID",v:SteamID())
			dtv:AddLine("Entity Number",v:EntIndex())
			dtv:AddLine("Alive?",v:Alive())
			
		end
	end
end
 function dispinfobox()
	-- og dframe
	local ibox = vgui.Create("DFrame")
	ibox:SetSize(765,75)
	ibox:Center()
	ibox:MakePopup()
	ibox:SetTitle(choice.."'s Information")
	ibox:SetSkin("DarkRP")
	ibox:SetBackgroundBlur(false)
	ibox:SetDraggable(true)
	ibox:ShowCloseButton(true)
-- Adds columns
-- infolist
	local infolist = vgui.Create("DListView", ibox)
	infolist:SetPos(5, 25)
	infolist:SetSize(750, 35)
	infolist:AddColumn("Steam Name")
	infolist:AddColumn("Nick Name")
	infolist:AddColumn("Health")
	infolist:AddColumn("Armor")
	infolist:AddColumn("Money")
	infolist:AddColumn("Salary")
	infolist:AddColumn("Job name")
	infolist:AddColumn("Rank")
	infolist:AddColumn("SteamID")
	infolist:AddColumn("Entity")
	infolist:AddColumn("Alive")

	-- start parsing deh data
	for k,v in pairs(player.GetAll()) do
		if choice == v:Nick() then
		local rank = "Guest"
		local job,salary,money
			if v:IsSuperAdmin()  then
				Rank = "Super Admin"
					elseif v:IsAdmin() and !v:IsSuperAdmin() then
						Rank = "Admin"
					elseif !v:IsAdmin() and !v:IsSuperAdmin() then
						Rank = "Guest"
			end
			
			money = v.DarkRPVars.money or 0
			job = v.DarkRPVars.job or "Citizen"
			salary = v.DarkRPVars.salary or 0
			
			
			-- infolist
				infolist:AddLine(
				v:SteamName(),
				v:Nick(),
				v:Health(),
				v:Armor(),
				"$"..money,
				"$"..salary,
				job,
				Rank,
				v:SteamID(),
				v:EntIndex(),
				v:Alive())
		end
			
		end
	end
function printconsole()
local rank = "Guest"
local Money,Job,Salary
for k,v in pairs(player.GetAll()) do
	if v:Nick() == choice then
			if v:IsSuperAdmin()  then
			Rank = "Super Admin"
		elseif v:IsAdmin() and !v:IsSuperAdmin() then
			Rank = "Admin"
			elseif !v:IsAdmin() and !v:IsSuperAdmin() then
			Rank = "Guest"
		end
		
		local Money = v.DarkRPVars.money or 0
		local Job = v.DarkRPVars.job or "Citizen"
		local Salary = v.DarkRPVars.salary or 0
		
			money = 0
				job = 0
				salary = 0
		
		print("SteamName: "..v:SteamName())
		print("Nickname:  "..v:Nick())
		print("Health:  "..v:Health())
		print("Armor:  "..v:Armor())
		print("Cash:  $"..Money)
		print("Salary:  $"..Salary)
		print("Job:  "..Job)
		print("Rank:  "..Rank)
		print("SteamID:  "..v:SteamID())
		print("Entity:  "..v:EntIndex())
		
		print("----")
	end
		end

end
concommand.Add("+pinfo",dispbox)