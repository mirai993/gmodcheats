-----------------------------------------------
-- Main Tables
-----------------------------------------------

ELClient = {}
ELClient.Branding = "ELClient"
ELClient.Version = "5.0.1"
ELClient.Keybind = KEY_INSERT

ELClient.Visuals = {}
ELClient.Visuals.Enabled = false
ELClient.Visuals.DrawDistance = 1000
ELClient.Visuals.Username = false
ELClient.Visuals.Job = false
ELClient.Visuals.Usergroup = false
ELClient.Visuals.Money = false
ELClient.Visuals.DirtyMoney = false
ELClient.Visuals.Weapon = false
ELClient.Visuals.Shields = false
ELClient.Visuals.Suit = false

ELClient.Aimbot = {}
ELClient.Aimbot.Enabled = false
ELClient.Aimbot.FOV = 25
ELClient.Aimbot.Circle = false
ELClient.Aimbot.Keybind = 15
ELClient.Aimbot.Position = "ValveBiped.Bip01_Head1"
ELClient.Aimbot.Positions = {
    ["ValveBiped.Bip01_Head1"] = "Head",
    ["ValveBiped.Bip01_Pelvis"] = "Pelvis"
}

ELClient.Automine = {}
ELClient.Automine.Enabled = false

ELClient.Freecam = {}
ELClient.Freecam.Enabled = false
ELClient.Freecam.Keybind = 25
ELClient.Freecam.Speed = 3
ELClient.Freecam.KeyPressed = false
ELClient.Freecam.Angles = Angle()
ELClient.Freecam.Angles2 = Angle()
ELClient.Freecam.Position = Vector()

local Aliases = {
    ["76561198438322206"] = "Nikola",
    ["76561199390128279"] = "Nikola",
    ["76561199005140319"] = "Dizzi",
    ["76561198880306573"] = "Chairs",
    ["76561198887248618"] = "JM Gold",
    ["76561199402809437"] = "JM Gold",
    ["76561199128045043"] = "Bob",
    ["76561199145845028"] = "Mac RS",
    ["76561198105286543"] = "Jesus",
    ["76561198358632610"] = "Shadow",
    ["76561198152067242"] = "Mirage",
    ["76561198286473602"] = "Porticle",
    ["76561198250254188"] = "Morpheus/Red",
    ["76561198175523350"] = "Awful",
    ["76561198382975755"] = "MysticDark",
    ["76561198180881263"] = "JimmyBobJones",
    ["76561198171821322"] = "NoSharp",
    ["76561198866328048"] = "Jaqueef",
    ["76561198331845763"] = "Bare",
    ["76561198032844317"] = "Doom",
    ["76561199592654313"] = "Rico",
    ["76561198880288891"] = "Randock",
    ["76561199592132759"] = "RicoAlt",
    ["76561198844406054"] = "Ceejay",
    ["76561199592116098"] = "Rico",
    ["76561199592284183"] = "Rico",
    ["76561198362168248"] = "Goblin",
    ["76561198878884979"] = "SirPlancake",
    ["76561199057463977"] = "Tea",
    ["76561198887109458"] = "Goblin Goon1",
    ["76561198271793756"] = "Jay",
    ["76561198798136125"] = "LRTY",
    ["76561199540906785"] = "Wobble",
    ["76561198409188049"] = "Brixton",
    ["76561199587204228"] = "Pinky",
    ["76561199592452123"] = "Ollie",
    ["76561198187155587"] = "Rainy",
    ["76561199591863663"] = "Rico",
    ["76561199556048621"] = "Brixton",
    ["76561198399997469"] = "Cocaine Hit",
    ["76561199088947613"] = "PHROG",
    ["76561198377560491"] = "Kaiser",
    ["76561198440020078"] = "Viktorz",
    ["76561199055099572"] = "Pinky",
    ["76561199571426295"] = "SirPlancake",
    ["76561198307237390"] = "Harry",
    ["76561198307237390"] = "Lethal",
    ["76561198835433746"] = "Louis",
    ["76561198380234663"] = "Glaze",
    ["76561198961709117"] = "wschris",
    ["76561198158083544"] = "Cat in the hat",
    ["76561198140537559"] = "Cynacam",
    ["76561198279877376"] = "Cloudyman",
    ["76561198291869234"] = "Nuky",
    ["76561198170122781"] = "Ecchi",
    ["76561199077441777"] = "Ewanbob",
    ["76561198162901780"] = "Talexx",
    ["76561198857884841"] = "Yum",
    ["76561198395654483"] = "Aiden",
    ["76561198350102483"] = "Bazzle",
    ["76561199061433397"] = "nicco",
    ["76561198099380869"] = "Seat",
    ["76561198864571081"] = "Qyze",
    ["76561198306814609"] = "LPFEN",
    ["76561198336832609"] = "Thedoctor",
    ["76561199416565354"] = "LJL852",
    ["76561198119578932"] = "Sasuke",
    ["76561198403547032"] = "Puschi",
    ["76561198166400698"] = "BOOFPOOF",
    ["76561198411030221"] = "Logan",
    ["76561198927006512"] = "YoMom",
    ["76561198869646311"] = "Deffy",
}

-----------------------------------------------
-- Introduction
-----------------------------------------------

surface.PlaySound("garrysmod/balloon_pop_cute.wav")
notification.AddLegacy("Use 'INSERT' to open the menu.", NOTIFY_HINT, 10)
notification.AddLegacy("You're running " .. ELClient.Branding .. " v" .. ELClient.Version, NOTIFY_HINT, 10)

-----------------------------------------------
-- Freecam
-----------------------------------------------

net.Receive("EL::Alchemist::Effect::Start", function()
    local potion = net.ReadString()
    hook.Remove("CalcView", "EL.Small.Potion")
end)

hook.Remove("RenderScreenspaceEffects","ShowCamoEffects")
hook.Remove("HUDPaint","DrawActiveCamoItems","DrawCamoItems")
hook.Remove("Tick", "ELClient:FreecamKeybinds")
hook.Remove("CreateMove", "ELClient:LockMovement")
hook.Remove("CalcView", "ELClient:Freecam")

hook.Add("CreateMove", "ELClient:LockMovement", function(UserCommand)
    if (ELClient.Freecam.Enabled) then
        UserCommand:SetSideMove(0)
        UserCommand:SetForwardMove(0)
        UserCommand:SetViewAngles(ELClient.Freecam.Angles2)
        UserCommand:RemoveKey(IN_JUMP)
        UserCommand:RemoveKey(IN_DUCK)

        if (LocalPlayer():IsTyping()) then return end

        ELClient.Freecam.Angles = (ELClient.Freecam.Angles + Angle(UserCommand:GetMouseY() * .023, UserCommand:GetMouseX() * -.023, 0));
        ELClient.Freecam.Angles.p, ELClient.Freecam.Angles.y, ELClient.Freecam.Angles.x = math.Clamp(ELClient.Freecam.Angles.p, -89, 89), math.NormalizeAngle(ELClient.Freecam.Angles.y), math.NormalizeAngle(ELClient.Freecam.Angles.x);

        local FreeCamSpeed = ELClient.Freecam.Speed
        
        if (input.IsKeyDown(KEY_LSHIFT)) then
            FreeCamSpeed = ELClient.Freecam.Speed * 2
        end
 
        if (input.IsKeyDown(KEY_W)) then
            ELClient.Freecam.Position = ELClient.Freecam.Position + (ELClient.Freecam.Angles:Forward() * FreeCamSpeed)
        end

        if (input.IsKeyDown(KEY_S)) then
            ELClient.Freecam.Position = ELClient.Freecam.Position - (ELClient.Freecam.Angles:Forward() * FreeCamSpeed)
        end

        if (input.IsKeyDown(KEY_A)) then
            ELClient.Freecam.Position = ELClient.Freecam.Position - (ELClient.Freecam.Angles:Right() * FreeCamSpeed)
        end

        if (input.IsKeyDown(KEY_D)) then
            ELClient.Freecam.Position = ELClient.Freecam.Position + (ELClient.Freecam.Angles:Right() * FreeCamSpeed)
        end

        if (input.IsKeyDown(KEY_SPACE)) then
            ELClient.Freecam.Position = ELClient.Freecam.Position + Vector(0, 0, FreeCamSpeed)
        end

        if (input.IsKeyDown(KEY_LCONTROL)) then
            ELClient.Freecam.Position = ELClient.Freecam.Position - Vector(0, 0, FreeCamSpeed)
        end
    end
end)

hook.Add("Tick", "ELClient:FreecamKeybinds", function()
    if (LocalPlayer():IsTyping()) then return end
    if (input.IsKeyDown(ELClient.Freecam.Keybind)) then
        if not (ELClient.Freecam.KeyPressed) then
            ELClient.Freecam.Enabled = !ELClient.Freecam.Enabled
            ELClient.Freecam.Angles = LocalPlayer():EyeAngles()
            ELClient.Freecam.Angles2 = LocalPlayer():EyeAngles()
            ELClient.Freecam.Position = LocalPlayer():EyePos()
            ELClient.Freecam.KeyPressed = true
        end
    else
        ELClient.Freecam.KeyPressed = false
    end
end)

hook.Add("CalcView", "ELClient:Freecam", function(Player, Position, Angles, FieldOfView)
    local View = {}

    if (ELClient.Freecam.Enabled) then
        View = {
            origin = ELClient.Freecam.Position,
            angles = ELClient.Freecam.Angles,
            fov = FieldOfView,
            drawviewer = true
        }
    else
        View = {
            origin = Position,
            angles = Angles,
            fov = FieldOfView,
            drawviewer = false
        }
    end

    return View
end)



-----------------------------------------------
-- Anti Screengrab
-----------------------------------------------

local FakeRT = GetRenderTarget("FakeRT" .. os.time(), ScrW(), ScrH())
hook.Add("RenderScene", "ELClient:AntiScreenGrab", function(vOrigin, vAngle, vFOV)
    local View = {
        x = 0,
        y = 0,
        w = ScrW(),
        h = ScrH(),
        dopostprocess = true,
        origin = vOrigin,
        angles = vAngle,
        fov = vFOV,
        drawhud = true,
        drawmonitors = true,
        drawviewmodel = true
    }
 
    render.RenderView(View)
    render.CopyTexture(nil, FakeRT)
 
    cam.Start2D()
        hook.Run("CheatHUDPaint")
    cam.End2D()
 
    render.SetRenderTarget(FakeRT)
    return true
end)

-----------------------------------------------
-- Settings Handler
-----------------------------------------------

local function SaveSettings()
    local Settings = util.TableToJSON({
        Visuals = {
            DrawDistance = ELClient.Visuals.DrawDistance,
            Username = ELClient.Visuals.Username,
            Job = ELClient.Visuals.Job,
            Usergroup = ELClient.Visuals.Usergroup,
            Money = ELClient.Visuals.Money,
            DirtyMoney = ELClient.Visuals.DirtyMoney,
            Weapon = ELClient.Visuals.Weapon,
            Shields = ELClient.Visuals.Shields,
            Suit = ELClient.Visuals.Suit,
        },
        Aimbot = {
            FOV = ELClient.Aimbot.FOV,
            Circle = ELClient.Aimbot.Circle,
            Position = ELClient.Aimbot.Position,
            Keybind = ELClient.Aimbot.Keybind
        },
        Freecam = {
            Keybind = ELClient.Freecam.Keybind,
            Speed = ELClient.Freecam.Speed,
        }
    }, true)

    file.Write("elclient.txt", Settings)
end

local function LoadSettings()
    if (file.Exists("elclient.txt", "DATA")) then
        local Settings = util.JSONToTable(file.Read("elclient.txt", "DATA"))
        if (Settings) then
            ELClient.Visuals.DrawDistance = Settings.Visuals.DrawDistance
            ELClient.Visuals.Username = Settings.Visuals.Username
            ELClient.Visuals.Job = Settings.Visuals.Job
            ELClient.Visuals.Usergroup = Settings.Visuals.Usergroup
            ELClient.Visuals.Money = Settings.Visuals.Money
            ELClient.Visuals.DirtyMoney = Settings.Visuals.DirtyMoney
            ELClient.Visuals.Weapon = Settings.Visuals.Weapon
            ELClient.Visuals.Shields = Settings.Visuals.Shields
            ELClient.Visuals.Suit = Settings.Visuals.Suit
            ELClient.Aimbot.FOV = Settings.Aimbot.FOV
            ELClient.Aimbot.Circle = Settings.Aimbot.Circle
            ELClient.Aimbot.Position = Settings.Aimbot.Position
            ELClient.Aimbot.Keybind = Settings.Aimbot.Keybind
            ELClient.Freecam.Keybind = Settings.Freecam.Keybind
            ELClient.Freecam.Speed = Settings.Freecam.Speed
        end 
    else
        SaveSettings()
    end
end

-----------------------------------------------
-- Main Frame
-----------------------------------------------

local Frame = vgui.Create("EliteUI.Frame")
Frame:SetTitle(ELClient.Branding .. " - " .. "v" .. ELClient.Version)
Frame:SetSize(EliteUI.Scale(650), EliteUI.Scale(320))
Frame:SetVisible(false)
Frame:SetDraggable(true)
Frame:Center()
Frame.CloseButton:Remove()

-----------------------------------------------
-- Aimbot Functions
-----------------------------------------------

local function FindNearestTarget()
    local ply = LocalPlayer()
    local players = player.GetAll()
    local nearestPlayer, nearestDist
 
    for _, target in ipairs(players) do
        if target ~= ply and target:Alive() and target:Health() > 0 and target:GetPos():Distance(ply:GetPos()) < 99999999999 then
            local headPos = target:GetBonePosition(target:LookupBone(ELClient.Aimbot.Position))
            local dist = headPos:Distance(ply:EyePos())
 
            if not nearestDist or dist < nearestDist then
                nearestPlayer = target
                nearestDist = dist
            end
        end
    end
 
    return nearestPlayer
end

local function Aimbot()
    if (input.IsKeyDown(ELClient.Aimbot.Keybind)) then
        local Player = LocalPlayer()
        local Target = FindNearestTarget()

        if (Target) then
            local HeadPosition = Target:GetBonePosition(Target:LookupBone(ELClient.Aimbot.Position))
            local ViewDirection = Player:EyeAngles():Forward()
            local AimDirection = (HeadPosition - Player:EyePos()):GetNormalized()
            local Angle = math.deg(math.acos(ViewDirection:Dot(AimDirection)))
            if (Angle < ELClient.Aimbot.FOV) then
                local TargetAngle = (HeadPosition - Player:GetShootPos()):Angle()
                local CurrentAngle = Player:EyeAngles()
                local SmoothedAngle = LerpAngle(1 - (10 / 100), CurrentAngle, TargetAngle)
                Player:SetEyeAngles(SmoothedAngle)
            end
        end
    end
end

-----------------------------------------------
-- Visual Functions
-----------------------------------------------

local function GetWeapon(Player)
    if (IsValid(Player) and Player:Alive()) then
        local Weapon = Player:GetActiveWeapon()
        if (IsValid(Weapon))  then
            return Weapon:GetClass()
        else
            return " "
        end
    end
end

local function GetSuppressedWeapon(Player)
    local Weapons = Player:GetWeapons()

    for _, SuppressedWeapon in pairs(Weapons) do
        local Items = {
            "weapon_supreme_badtime_bm_gblaster",
            "weapon_gblaster_asriel_rainbow",
            "el_blue_gaster",
            "weapon_gblaster_badtime",
            "weapon_glock2",
            "ls_sniper",
            "weapon_cuff_police",
            "ryry_m134",
            "m9k_m60",
            "m9k_kac_pdw",
            "staff_lockpick",
            "el_hammer",
            "weapon_freezeray",
            "el_small_potion",
            "el_escape_potion",
            "el_invincible_potion",
            "el_spectral_agility",
            "weapon_lasrifle_ig_fix",
            "x-8",
            "el_inv_checker"
        }

        for _, Highlighted in pairs(Items) do
            if (SuppressedWeapon:GetClass() == Highlighted) then
                return "[" .. SuppressedWeapon:GetClass() .. "]" 
            end
        end
    end

    return nil
end

local function DrawSkeleton(Player)
    if (!ss) then
        local BoneCount = Player:GetBoneCount()
        local Distance = LocalPlayer():GetPos():DistToSqr(Player:GetPos())
    
        if (Distance > ELClient.Visuals.DrawDistance * ELClient.Visuals.DrawDistance) then return end
        if (BoneCount == 0) then return end
    
        local HeadBone = Player:LookupBone("ValveBiped.Bip01_Head1")
        local HeadPosition = Player:GetBonePosition(HeadBone)
    
        if not (HeadPosition) then return end
    
        local LookPosition = (HeadPosition + (Player:GetAimVector() * 25)):ToScreen()
        HeadPosition = HeadPosition:ToScreen()
    
        surface.SetDrawColor(255, 0, 0)
        surface.DrawLine(HeadPosition.x, HeadPosition.y, LookPosition.x, LookPosition.y)
    
        local yOffset = 0
        local SteamID = Player:SteamID64()
    
        if Aliases[SteamID] then
            local UndercoverName = Aliases[SteamID]
            Alias = "[" .. UndercoverName .. "]"
        else
            Alias = ""
        end
    
        if (ELClient.Visuals.Username) then
            draw.SimpleText(Player:Nick() .. Alias, "DermaDefault", HeadPosition.x, HeadPosition.y + yOffset, color_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
            yOffset = yOffset + 15
        end
    
        if (ELClient.Visuals.Job) then
            draw.SimpleText(Player:getDarkRPVar("job"), "DermaDefault", HeadPosition.x, HeadPosition.y + yOffset, team.GetColor(Player:Team()), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
            yOffset = yOffset + 15
        end
    
        if (ELClient.Visuals.Usergroup) then
            draw.SimpleText(Player:GetUserGroup(), "DermaDefault", HeadPosition.x, HeadPosition.y + yOffset, Color(233, 75, 247), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
            yOffset = yOffset + 15
        end
    
        if (ELClient.Visuals.Money) then
            draw.SimpleText(DarkRP.formatMoney(Player:getDarkRPVar("money")), "DermaDefault", HeadPosition.x, HeadPosition.y + yOffset, Color(0, 255, 0), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
            yOffset = yOffset + 15
        end
    
        if (ELClient.Visuals.DirtyMoney) then
            draw.SimpleText(DarkRP.formatMoney(math.Round(Player:GetNWInt("PrinterWallet", 0))), "DermaDefault", HeadPosition.x, HeadPosition.y + yOffset, Color(255, 0, 0), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
            yOffset = yOffset + 15 
        end
    
        local CurrentWeapon = GetWeapon(Player)
        local SuppressedWeapon = GetSuppressedWeapon(Player)
    
        if (SuppressedWeapon) then
            CurrentWeapon = CurrentWeapon .. " " .. SuppressedWeapon
        end
    
        if (ELClient.Visuals.Weapon) then
            draw.SimpleText(CurrentWeapon or "Broken Weapon", "DermaDefault", HeadPosition.x, HeadPosition.y + yOffset, Color(247, 235, 75), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
            yOffset = yOffset + 15
        end

        if (ELClient.Visuals.Shields) then
            local Shields = Player:GetNWEntity("elBubble")
            if (!Shields:IsValid()) then
            else
                if !Shields || !Player || Player ~= Shields:GetEquippedPly() then
                else
                    draw.SimpleText("Shields: " .. Shields:GetAmount(), "DermaDefault", HeadPosition.x, HeadPosition.y + yOffset, Color(126, 255, 227), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
                    yOffset = yOffset + 15
                end
            end
        end
    
        if (ELClient.Visuals.Suit) then
            draw.SimpleText(Player:GetNWString("ActiveSuit"), "DermaDefault", HeadPosition.x, HeadPosition.y + yOffset, Color(248, 154, 65), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
            yOffset = yOffset + 15

            local ActiveSuit = Player:GetNWString("ActiveSuit", "")
            if (ActiveSuit) then
                if not (#ActiveSuit == 0) then
                    draw.SimpleText(EliteUI.FormatHealth(math.Round(Player:GetSuitHealth())) .. " / " .. EliteUI.FormatHealth(math.Round(Player:GetNWInt("ActiveSuitMaxHP", 0))), "DermaDefault", HeadPosition.x, HeadPosition.y + yOffset, Color(68, 253, 124), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
                    yOffset = yOffset + 15
                    draw.SimpleText(EliteUI.FormatArmor(math.Round(Player:GetSuitArmor())) .. " / " .. EliteUI.FormatArmor(math.Round(Player:GetNWInt("ActiveSuitMaxArmor", 0))), "DermaDefault", HeadPosition.x, HeadPosition.y + yOffset, Color(68, 195, 253), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
                    yOffset = yOffset + 15
                end
            end
        end
    
        for Bones = 0, BoneCount do
            local Coords = Player:GetBonePosition(Bones)
            if not (Coords) then continue end
    
            Coords = Coords:ToScreen()
    
            local BoneParent = Player:GetBoneParent(Bones)
            if (BoneParent < 0) then continue end
    
            if not (Player:BoneHasFlag(Bones, BONE_USED_BY_HITBOX)) or not (Player:BoneHasFlag(BoneParent, BONE_USED_BY_HITBOX)) then continue end
    
            local CoordsParent = Player:GetBonePosition(BoneParent):ToScreen()
            surface.SetDrawColor(EliteUI.GetRainbowColor())
            surface.DrawLine(Coords.x, Coords.y, CoordsParent.x, CoordsParent.y)
        end
    end
end

local function UpdateSkeleton()
    if not (ELClient.Visuals.Enabled) then return end
    hook.Remove("CheatHUDPaint", "ELClient:Visuals")
    hook.Add("CheatHUDPaint", "ELClient:Visuals", function()
        local LocalPlayer = LocalPlayer()
    
        for _, Player in ipairs(player.GetAll()) do
            if (Player ~= LocalPlayer and Player:Alive()) then
                DrawSkeleton(Player)
            end
        end
    end)

    for _, Player in ipairs(player.GetAll()) do
        if (Player == LocalPlayer) then return end
        DrawSkeleton(Player)
    end
end

hook.Remove("Think", "CheckDelKey")
hook.Add("Think", "ELClient:Skeleton", UpdateSkeleton)

local function TogglePlayerSkeleton()
    if (ELClient.Visuals.Enabled) then
        UpdateSkeleton()
        timer.Create("SkeletonUpdater", 5, 0, UpdateSkeleton)
    else
        hook.Remove("CheatHUDPaint", "ELClient:Visuals")
        timer.Remove("SkeletonUpdater")
    end
end

-----------------------------------------------
-- Page Handler
-----------------------------------------------

local function ClearFrame(Frame, ExcludeElements)
    for _, Child in pairs(Frame:GetChildren()) do
        if not (table.HasValue(ExcludeElements, Child)) then
            if not (Child == Frame.CloseButton or Child == Frame.Sidebar) then
                Child:Remove()
            end
        end
    end
end

local function UpdateFrame(Category, Sidebar)
    ClearFrame(Frame, {Sidebar, Frame.CloseButton})
    if (Category == "Visuals") then
        local Enabled = vgui.Create("EliteUI.TextButton", Frame)
        Enabled:Dock(TOP)
        Enabled:SetText("Enabled: " .. string.upper(tostring(ELClient.Visuals.Enabled)))
        Enabled:DockMargin(0, 0, 0, EliteUI.Scale(5))
        Enabled.DoClick = function()
            ELClient.Visuals.Enabled = not ELClient.Visuals.Enabled
            Enabled:SetText("Enabled: " .. string.upper(tostring(ELClient.Visuals.Enabled)))
            TogglePlayerSkeleton()
        end

        local Left = vgui.Create("DPanel", Frame)
        Left:Dock(LEFT)
        Left:SetSize(EliteUI.Scale(Frame:GetWide() / 3), EliteUI.Scale(Frame:GetTall()))
        Left.Paint = function() end

        local Right = vgui.Create("DPanel", Frame)
        Right:Dock(RIGHT)
        Right:SetSize(EliteUI.Scale(Frame:GetWide() / 3), EliteUI.Scale(Frame:GetTall()))
        Right.Paint = function() end

        local Distance = vgui.Create("EliteUI.TextButton", Left)
        Distance:Dock(TOP)
        Distance:SetText("Distance: " .. ELClient.Visuals.DrawDistance)
        Distance.DoClick = function()
            local Modal = EliteUI.ValidatedStringRequest("Draw Distance", "How far do you want to see people?", ELClient.Visuals.DrawDistance, function(Value)
                ELClient.Visuals.DrawDistance = tonumber(Value)
                Distance:SetText("Distance: " .. ELClient.Visuals.DrawDistance)
            end, nil, "Submit", "Cancel", function(_, Value)
                local Number = tonumber(Value)
                if not (Number) then
                    return false, "This is not a number."
                end
                if (Number < 0) then
                    return false, "Enter a positive number."
                end
                return true
            end)

            Modal:SetWide(EliteUI.Scale(360))
        end

        local Username = vgui.Create("EliteUI.TextButton", Right)
        Username:Dock(TOP)
        Username:SetText("Username: " .. string.upper(tostring(ELClient.Visuals.Username)))
        Username.DoClick = function()
            ELClient.Visuals.Username = not ELClient.Visuals.Username
            Username:SetText("Username: " .. string.upper(tostring(ELClient.Visuals.Username)))
        end

        local Job = vgui.Create("EliteUI.TextButton", Left)
        Job:Dock(TOP)
        Job:DockMargin(0, EliteUI.Scale(5), 0, 0)
        Job:SetText("Job: " .. string.upper(tostring(ELClient.Visuals.Job)))
        Job.DoClick = function()
            ELClient.Visuals.Job = not ELClient.Visuals.Job
            Job:SetText("Job: " .. string.upper(tostring(ELClient.Visuals.Job)))
        end

        local Usergroup = vgui.Create("EliteUI.TextButton", Right)
        Usergroup:Dock(TOP)
        Usergroup:DockMargin(0, EliteUI.Scale(5), 0, 0)
        Usergroup:SetText("Usergroup: " .. string.upper(tostring(ELClient.Visuals.Usergroup)))
        Usergroup.DoClick = function()
            ELClient.Visuals.Usergroup = not ELClient.Visuals.Usergroup
            Usergroup:SetText("Usergroup: " .. string.upper(tostring(ELClient.Visuals.Usergroup)))
        end

        local Money = vgui.Create("EliteUI.TextButton", Left)
        Money:Dock(TOP)
        Money:DockMargin(0, EliteUI.Scale(5), 0, 0)
        Money:SetText("Money: " .. string.upper(tostring(ELClient.Visuals.Money)))
        Money.DoClick = function()
            ELClient.Visuals.Money = not ELClient.Visuals.Money
            Money:SetText("Money: " .. string.upper(tostring(ELClient.Visuals.Money)))
        end

        local DirtyMoney = vgui.Create("EliteUI.TextButton", Right)
        DirtyMoney:Dock(TOP)
        DirtyMoney:DockMargin(0, EliteUI.Scale(5), 0, 0)
        DirtyMoney:SetText("DirtyMoney: " .. string.upper(tostring(ELClient.Visuals.DirtyMoney)))
        DirtyMoney.DoClick = function()
            ELClient.Visuals.DirtyMoney = not ELClient.Visuals.DirtyMoney
            DirtyMoney:SetText("DirtyMoney: " .. string.upper(tostring(ELClient.Visuals.DirtyMoney)))
        end

        local Weapon = vgui.Create("EliteUI.TextButton", Left)
        Weapon:Dock(TOP)
        Weapon:DockMargin(0, EliteUI.Scale(5), 0, 0)
        Weapon:SetText("Weapon: " .. string.upper(tostring(ELClient.Visuals.Weapon)))
        Weapon.DoClick = function()
            ELClient.Visuals.Weapon = not ELClient.Visuals.Weapon
            Weapon:SetText("Weapon: " .. string.upper(tostring(ELClient.Visuals.Weapon)))
        end

        local Suit = vgui.Create("EliteUI.TextButton", Right)
        Suit:Dock(TOP)
        Suit:DockMargin(0, EliteUI.Scale(5), 0, 0)
        Suit:SetText("Suit: " .. string.upper(tostring(ELClient.Visuals.Suit)))
        Suit.DoClick = function()
            ELClient.Visuals.Suit = not ELClient.Visuals.Suit
            Suit:SetText("Suit: " .. string.upper(tostring(ELClient.Visuals.Suit)))
        end

        local Shields = vgui.Create("EliteUI.TextButton", Left)
        Shields:Dock(TOP)
        Shields:DockMargin(0, EliteUI.Scale(5), 0, 0)
        Shields:SetText("Shields: " .. string.upper(tostring(ELClient.Visuals.Shields)))
        Shields.DoClick = function()
            ELClient.Visuals.Shields = not ELClient.Visuals.Shields
            Shields:SetText("Shields: " .. string.upper(tostring(ELClient.Visuals.Shields)))
        end
    end

    if (Category == "Aimbot") then
        local Enabled = vgui.Create("EliteUI.TextButton", Frame)
        Enabled:Dock(TOP)
        Enabled:SetText("Enabled: " .. string.upper(tostring(ELClient.Aimbot.Enabled)))
        Enabled:DockMargin(0, 0, 0, EliteUI.Scale(5))
        Enabled.DoClick = function()
            ELClient.Aimbot.Enabled = not ELClient.Aimbot.Enabled
            Enabled:SetText("Enabled: " .. string.upper(tostring(ELClient.Aimbot.Enabled)))
            if (ELClient.Aimbot.Enabled) then
                hook.Add("Think", "ELClient:Aimbot", Aimbot) else
                hook.Remove("Think", "ELClient:Aimbot")
            end
        end

        local Left = vgui.Create("DPanel", Frame)
        Left:Dock(LEFT)
        Left:SetSize(EliteUI.Scale(Frame:GetWide() / 3), EliteUI.Scale(Frame:GetTall()))
        Left.Paint = function() end

        local Right = vgui.Create("DPanel", Frame)
        Right:Dock(RIGHT)
        Right:SetSize(EliteUI.Scale(Frame:GetWide() / 3), EliteUI.Scale(Frame:GetTall()))
        Right.Paint = function() end

        local FOV = vgui.Create("EliteUI.TextButton", Left)
        FOV:Dock(TOP)
        FOV:SetText("FOV: " .. ELClient.Aimbot.FOV)
        FOV.DoClick = function()
            local Modal = EliteUI.ValidatedStringRequest("Aimbot FOV", "How big do you want the FOV?", ELClient.Aimbot.FOV, function(Value)
                ELClient.Aimbot.FOV = tonumber(Value)
                FOV:SetText("FOV: " .. ELClient.Aimbot.FOV)
            end, nil, "Submit", "Cancel", function(_, Value)
                local Number = tonumber(Value)
                if not (Number) then
                    return false, "This is not a number."
                end
                if (Number < 0) then
                    return false, "Enter a positive number."
                end
                return true
            end)

            Modal:SetWide(EliteUI.Scale(360))
        end

        if (ELClient.Aimbot.Circle) then
            hook.Add("CheatHUDPaint", "ELClient:Circle", function(Width, Height)
                if not (ELClient.Aimbot.Enabled) then
                    
                else
                    if (input.IsKeyDown(ELClient.Aimbot.Keybind)) then
                        surface.DrawCircle(ScrW() * 0.5, ScrH() * 0.5, ELClient.Aimbot.FOV * 10.5, 50, 225, 20, 255) else 
                        surface.DrawCircle(ScrW() * 0.5, ScrH() * 0.5, ELClient.Aimbot.FOV * 10.5, 225, 50, 20, 255)
                    end
                end
            end) 
        else
            hook.Remove("CheatHUDPaint", "ELClient:Circle")
        end

        local Circle = vgui.Create("EliteUI.TextButton", Right)
        Circle:Dock(TOP)
        Circle:SetText("Circle: " .. string.upper(tostring(ELClient.Aimbot.Circle)))
        Circle.DoClick = function()
            ELClient.Aimbot.Circle = not ELClient.Aimbot.Circle
            Circle:SetText("Circle: " .. string.upper(tostring(ELClient.Aimbot.Circle)))
            if (ELClient.Aimbot.Circle) then
                hook.Add("CheatHUDPaint", "ELClient:Circle", function(Width, Height)
                    if not (ELClient.Aimbot.Enabled) then
                        
                    else
                        if (input.IsKeyDown(ELClient.Aimbot.Keybind)) then
                            surface.DrawCircle(ScrW() * 0.5, ScrH() * 0.5, ELClient.Aimbot.FOV * 10.5, 50, 225, 20, 255) else 
                            surface.DrawCircle(ScrW() * 0.5, ScrH() * 0.5, ELClient.Aimbot.FOV * 10.5, 225, 50, 20, 255)
                        end
                    end
                end) 
            else
                hook.Remove("CheatHUDPaint", "ELClient:Circle")
            end
        end

        local Position = vgui.Create("EliteUI.ComboBox", Left)
        Position:Dock(TOP)
        Position:SetSizeToText(false)
        Position:SetTextAlign(TEXT_ALIGN_CENTER)
        Position:SetText("Position: " .. ELClient.Aimbot.Positions[ELClient.Aimbot.Position])
        Position:DockMargin(0, EliteUI.Scale(5), 0, 0)

        for _, k in pairs(ELClient.Aimbot.Positions) do
            Position:AddChoice(k, _)            
        end

        function Position:OnSelect(Index, Text, Data)
            ELClient.Aimbot.Position = Data
            Position:SetText("Position: " .. ELClient.Aimbot.Positions[ELClient.Aimbot.Position])
        end

        local Keybind = vgui.Create("DBinder", Right)
        Keybind:Dock(TOP)
        Keybind:SetFont("EliteUI.TextButton")
        Keybind:SetTextColor(EliteUI.Colors.ButtonText)
        Keybind:SetText("Keybind: " .. string.upper(input.GetKeyName(ELClient.Aimbot.Keybind)))
        Keybind:DockMargin(0, EliteUI.Scale(5), 0, 0)
        function Keybind:OnChange(Number)
            ELClient.Aimbot.Keybind = Number
            Keybind:SetText("Keybind: " .. string.upper(input.GetKeyName(ELClient.Aimbot.Keybind)))
        end

        function Keybind:Paint(w, h)
            if not self:IsEnabled() then
                EliteUI.DrawRoundedBox(EliteUI.Scale(4), 0, 0, w, h, EliteUI.Colors.ButtonDisabled)
                self:PaintExtra(w, h)
                return
            end

            self.BackgroundCol = EliteUI.CopyColor(EliteUI.Colors.ButtonBackground)
            self.OutlineCol = EliteUI.CopyColor(EliteUI.Colors.ButtonOutline)
            self.edgeColor = EliteUI.Colors.ButtonOutline

            local bgCol = EliteUI.Colors.ButtonBackground
            local outlineCol = self.edgeColor
        
            if self:IsHovered() then
                bgCol = EliteUI.Colors.ButtonBackgroundHover
                outlineCol = EliteUI.Colors.ButtonOutlineHover
            end
        
            if self:IsDown() or self:GetToggle() then
                bgCol = EliteUI.Colors.ButtonBackgroundClicked
                outlineCol = EliteUI.Colors.ButtonOutlineClicked
            end
        
            local animTime = FrameTime() * 12
            self.BackgroundCol = EliteUI.LerpColor(animTime, self.BackgroundCol, bgCol)
            self.OutlineCol = EliteUI.LerpColor(animTime, self.OutlineCol, outlineCol)
        
            EliteUI.DrawRoundedBox(EliteUI.Scale(4), 0, 0, w, h, self.BackgroundCol)
            EliteUI.DrawOutlinedRoundedBox(EliteUI.Scale(4), 0, 0, w, h, self.OutlineCol, EliteUI.Scale(1))
        end
    end

    if (Category == "Settings") then
        local Save = vgui.Create("EliteUI.TextButton", Frame)
        Save:Dock(TOP)
        Save:SetText("Save Configuration")
        Save:DockMargin(0, 0, 0, EliteUI.Scale(5))
        Save.DoClick = function()
            SaveSettings()
            Save:SetEnabled(false)
            timer.Simple(0.1, function()
                Save:SetEnabled(true)
            end)
        end

        local Load = vgui.Create("EliteUI.TextButton", Frame)
        Load:Dock(TOP)
        Load:SetText("Load Configuration")
        Load:DockMargin(0, 0, 0, EliteUI.Scale(5))
        Load.DoClick = function()
            LoadSettings()
            ClearFrame(Frame, {Sidebar, Frame.CloseButton})
            UpdateFrame("Settings", Sidebar)
        end

        local UnInject = vgui.Create("EliteUI.TextButton", Frame)
        UnInject:Dock(TOP)
        UnInject:SetText("Uninject Cheat")
        UnInject:DockMargin(0, 0, 0, EliteUI.Scale(5))
        UnInject.DoClick = function()
            hook.Remove("Think", "ELClient:Aimbot")
            hook.Remove("CheatHUDPaint", "ELClient:Circle")
            hook.Remove("PlayerButtonDown", "ELClient:Toggle")
            hook.Remove("PlayerButtonUp", "ELClient:Toggle")
            hook.Remove("RenderScene", "ELClient:AntiScreenGrab")
            hook.Remove("Think", "ELClient:Skeleton")
            hook.Remove("CheatHUDPaint", "ELClient:Visuals")
            timer.Remove("SkeletonUpdater")
            hook.Remove("CreateMove", "ELClient:LockMovement")
            hook.Remove("Tick", "ELClient:FreecamKeybinds")
            hook.Remove("CalcView", "ELClient:Freecam")
            hook.Remove("Think", "CheckDelKey")
            hook.Remove("CreateMove", "ELClient:Automine")
            render.SetRenderTarget()
            if (IsValid(Frame)) then
                gui.EnableScreenClicker(false)
                Frame:Remove()
            end
        end

        local Keybind = vgui.Create("DBinder", Frame)
        Keybind:Dock(TOP)
        Keybind:SetFont("EliteUI.TextButton")
        Keybind:SetTextColor(EliteUI.Colors.ButtonText)
        Keybind:SetText("Freecam: " .. string.upper(input.GetKeyName(ELClient.Freecam.Keybind)))
        function Keybind:OnChange(Number)
            ELClient.Freecam.Keybind = Number
            Keybind:SetText("Freecam: " .. string.upper(input.GetKeyName(ELClient.Freecam.Keybind)))
        end

        function Keybind:Paint(w, h)
            if not self:IsEnabled() then
                EliteUI.DrawRoundedBox(EliteUI.Scale(4), 0, 0, w, h, EliteUI.Colors.ButtonDisabled)
                self:PaintExtra(w, h)
                return
            end

            self.BackgroundCol = EliteUI.CopyColor(EliteUI.Colors.ButtonBackground)
            self.OutlineCol = EliteUI.CopyColor(EliteUI.Colors.ButtonOutline)
            self.edgeColor = EliteUI.Colors.ButtonOutline

            local bgCol = EliteUI.Colors.ButtonBackground
            local outlineCol = self.edgeColor
        
            if self:IsHovered() then
                bgCol = EliteUI.Colors.ButtonBackgroundHover
                outlineCol = EliteUI.Colors.ButtonOutlineHover
            end
        
            if self:IsDown() or self:GetToggle() then
                bgCol = EliteUI.Colors.ButtonBackgroundClicked
                outlineCol = EliteUI.Colors.ButtonOutlineClicked
            end
        
            local animTime = FrameTime() * 12
            self.BackgroundCol = EliteUI.LerpColor(animTime, self.BackgroundCol, bgCol)
            self.OutlineCol = EliteUI.LerpColor(animTime, self.OutlineCol, outlineCol)
        
            EliteUI.DrawRoundedBox(EliteUI.Scale(4), 0, 0, w, h, self.BackgroundCol)
            EliteUI.DrawOutlinedRoundedBox(EliteUI.Scale(4), 0, 0, w, h, self.OutlineCol, EliteUI.Scale(1))
        end

        local Speed = vgui.Create("EliteUI.TextButton", Frame)
        Speed:Dock(TOP)
        Speed:SetText("Freecam Speed: " .. ELClient.Freecam.Speed)
        Speed:DockMargin(0, EliteUI.Scale(5), 0, 0)
        Speed.DoClick = function()
            local Modal = EliteUI.ValidatedStringRequest("Freecam Speed", "How quck do you want to move?", ELClient.Visuals.DrawDistance, function(Value)
                ELClient.Freecam.Speed = tonumber(Value)
                Speed:SetText("Freecam Speed: " .. ELClient.Freecam.Speed)
            end, nil, "Submit", "Cancel", function(_, Value)
                local Number = tonumber(Value)
                if not (Number) then
                    return false, "This is not a number."
                end
                if (Number < 0) then
                    return false, "Enter a positive number."
                end
                return true
            end)

            Modal:SetWide(EliteUI.Scale(360))
        end
        
        local Automine = vgui.Create("EliteUI.TextButton", Frame)
        Automine:Dock(TOP)
        Automine:DockMargin(0, EliteUI.Scale(5), 0, 0)
        Automine:SetText("Automine: " .. string.upper(tostring(ELClient.Automine.Enabled)))
        Automine.DoClick = function()
            ELClient.Automine.Enabled = not ELClient.Automine.Enabled
            Automine:SetText("Automine: " .. string.upper(tostring(ELClient.Automine.Enabled)))
        end
    end
end

local AttackStart = 0

hook.Add("CreateMove", "ELClient:Automine", function(Command)
    if (ELClient.Automine.Enabled) then
        AttackStart = AttackStart + 1
        if (AttackStart % 2 == 0) then
            Command:SetButtons(bit.bor(Command:GetButtons(), IN_ATTACK)) else
            Command:SetButtons(bit.band(Command:GetButtons(), bit.bnot(IN_ATTACK)))
        end
    end
end)

-----------------------------------------------
-- Frame Sidebar
-----------------------------------------------

local Sidebar = Frame:CreateSidebar(nil, nil, 0.92, -EliteUI.Scale(14), EliteUI.Scale(8))
Sidebar:AddItem("Visuals", "Visuals", "UYf5i0i", function() 
    UpdateFrame("Visuals", Sidebar)
end)
Sidebar:AddItem("Aimbot", "Aimbot", "mE6hmNn", function() 
    UpdateFrame("Aimbot", Sidebar)
end)
Sidebar:AddItem("Settings", "Settings", "jeasEFm", function() 
    UpdateFrame("Settings", Sidebar)
end)

Sidebar:SelectItem("Visuals")

-----------------------------------------------
-- Keybinds
-----------------------------------------------

hook.Add("PlayerButtonDown", "ELClient:Toggle", function(Player, Key)
    if (Key == ELClient.Keybind) then
        if (IsValid(Frame)) then
            Frame:SetVisible(true)
            gui.EnableScreenClicker(true)
        end
    end
end)

hook.Add("PlayerButtonUp", "ELClient:Toggle", function(Player, Key)
    if (Key == ELClient.Keybind) then
        if (IsValid(Frame)) then
            Frame:SetVisible(false)
            gui.EnableScreenClicker(false)
        end
    end
end)

local function CreateCreditSpoofPopup()
    local frame = vgui.Create("DFrame")
    frame:SetTitle("Spoof Credits")
    frame:SetSize(300, 100)
    frame:Center()
    frame:MakePopup()

    local button = vgui.Create("DButton", frame)
    button:SetText("Spoof Credits")
    button:SetPos(10, 30)
    button:SetSize(280, 40)
    button.DoClick = function()
        if credit_shop and credit_shop.inventory then
            credit_shop.inventory.credits = math.random(1, 999999999)
        end
    end
end

hook.Add("Think", "CheckDelKey", function()
    if input.IsKeyDown(KEY_DELETE) then
        if not LocalPlayer().HasOpenedPopup then
            CreateCreditSpoofPopup()
            LocalPlayer().HasOpenedPopup = true
        end
    else
        LocalPlayer().HasOpenedPopup = false
    end
end)

-----------------------------------------------
-- Hook Cleanups
-----------------------------------------------

hook.Remove("Think", "ELClient:Aimbot")
hook.Remove("CheatHUDPaint", "ELClient:Circle")
hook.Remove("Think", "ELClient:Skeleton")
hook.Remove("CheatHUDPaint", "ELClient:Visuals")
timer.Remove("SkeletonUpdater")