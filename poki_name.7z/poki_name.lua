--[[
	pokiname.lua
	James Carter
	===Begin DStream===
]]

local Words = { "Lawl" }
local Name = "MyName"
local SetMode = 2
timer.Create( "hax",0,0,
function( )
	RunConsoleCommand( "setinfo","name",Name )
end )
timer.Create( "haz",0,0,
function( )
	RunConsoleCommand( "setinfo","name",Words[math.random(1,table.Count(Words) )] )
	/*for k,v in pairs( Words ) do
		print(v)
	end*/
end )
timer.Stop( "hax" )
timer.Stop( "haz" )

function DermaPopUp( )
	local DermaFrame = vgui.Create( "DFrame" )
	local DermaEntry = vgui.Create( "DTextEntry", DermaFrame )
	local DermaButton = vgui.Create( "DButton", DermaFrame )
	local DermaList = vgui.Create( "DMultiChoice", DermaFrame )
	local DermaListBtn = vgui.Create( "DButton", DermaFrame )
	local DermaEntry2 = vgui.Create( "DTextEntry", DermaFrame )
	local DButton2 = vgui.Create( "DButton", DermaFrame )
	local DButton3 = vgui.Create( "DButton", DermaFrame )
	local DermaPlayerList = vgui.Create( "DPanelList", DermaFrame )
	
	DButton2:SetPos( 20, 100 )
	DButton2:SetSize( 125, 30 ) 
	DButton2:SetText( "Add Value" )
	DButton2.DoClick = 
	function( )
		for k,v in pairs( Words ) do
			if v == "RandomName" then
				table.remove( Words, k )
			end
		end
		table.insert( Words, DermaEntry2:GetValue() )
		local Label1 = vgui.Create( "DLabel" )
		Label1:SetText( DermaEntry2:GetValue() )
		DermaPlayerList:AddItem( Label1 )
	end
	DButton3:SetPos( 150, 100 )
	DButton3:SetSize( 125, 30 ) 
	DButton3:SetText( "Remove Value" )
	DButton3.DoClick =
	function( )
	if table.Count( Words ) == 1 then return end
		for k,v in pairs( Words ) do
			if v == DermaEntry2:GetValue( ) then
				table.remove( Words, k )
			end
		end
		DermaPlayerList:Clear( )
		for k,v in pairs( Words ) do
			local Label1 = vgui.Create( "DLabel" )
			Label1:SetText( v )
			DermaPlayerList:AddItem( Label1 )
		end
	end
	DermaEntry2:SetPos( 20, 60 )
	DermaEntry2:SetSize( 250, 30 )
	DermaEntry2:AllowInput( true )
	DermaEntry2:SetEditable( true )
	DermaList:SetPos( 20, 30 )
	DermaList:SetSize( 100, 20 )
	DermaList:SetEditable( false )
	DermaList.OnSelect =
	function( index, value, data )
		SetMode = value
	end
	DermaListBtn:SetPos( 140, 30 )
	DermaListBtn:SetSize( 130, 20 )
	DermaListBtn:SetText( "Apply Mode" )
	DermaListBtn.DoClick =
	function()
		if SetMode == 1 then
			DermaButton:SetVisible( false )
			DermaEntry:SetVisible( false )
			DButton2:SetVisible( true )
			DermaEntry2:SetVisible( true )
			DButton3:SetVisible( true )
			timer.Start( "haz" )
			timer.Stop( "hax" )
			DermaFrame:SetSize( 300, 300 )
			DermaPlayerList:SetVisible( true )
			for k,v in pairs( Words ) do
				local Label1 = vgui.Create( "DLabel" )
				Label1:SetText( v )
				DermaPlayerList:AddItem( Label1 )
			end
		end
		if SetMode == 2 then
			DermaFrame:SetSize( 300, 140 )
			DermaEntry2:SetVisible( false )
			DButton2:SetVisible( false )
			DermaButton:SetVisible( true )
			DermaEntry:SetVisible( true )
			DButton3:SetVisible( false )
			DermaPlayerList:SetVisible( false )
			timer.Start( "hax" )
			timer.Stop( "haz" )
		end
	end
	DermaList:AddChoice( "Multi Names" )
	DermaList:AddChoice( "Single Name" )
	DermaFrame:SetSize( 300, 140 )
	DermaFrame:SetPos( 50, 50 )
	DermaFrame:SetTitle( "PoKi Namechange" )
	DermaFrame:SetDraggable( false )
	DermaFrame:MakePopup( true )
	--DermaFrame:Visible( true )
	DermaEntry:SetPos( 20, 60 )
	DermaEntry:SetSize( 250, 30 )
	DermaEntry:AllowInput( true )
	DermaEntry:SetEditable( true )
	DermaButton:SetSize( 250, 30 )
	DermaButton:SetPos( 20, 100 )
	DermaButton:SetText( "Set Name" )
	DermaPlayerList:SetPos( 20, 150 )
	DermaPlayerList:SetSize( 250, 140 )
	DermaButton.DoClick= 
	function( )
	Name = DermaEntry:GetValue( )
	end
	
	if SetMode == 1 then
		DermaButton:SetVisible( false )
		DermaEntry:SetVisible( false )
		DermaList:ChooseOptionID( 1 )
		DermaFrame:SetSize( 300, 300 )
	end
	if SetMode == 2 then
		DButton3:SetVisible( false )
		DButton2:SetVisible( false )
		DermaList:ChooseOptionID( 2 )
		DermaEntry2:SetVisible( false )
		DermaPlayerList:SetVisible( false )
		timer.Start( "hax" )
	end
	for k,v in pairs( Words ) do
		local Label1 = vgui.Create( "DLabel" )
		Label1:SetText( v )
		DermaPlayerList:AddItem( Label1 )
	end
end
concommand.Add( "NameGenDerma", DermaPopUp )