////////////////////
//      Aimbot    //
////////////////////

if !nospread then require( "nospread" ) end

surface.CreateFont( "Tahoma", 16, 1000, true, false, "ScoreboardText" )

local BAimBot = {
	Target = nil,
	AimVector = nil,
	Scanning = false,
	WeaponSpreads = {
		weapon_357 = 0,
		weapon_smg1 = 0.04362,
		weapon_ar2 = 0.02618,
		weapon_pistol = 0.00873,
		weapon_shotgun = 0.08716,
	},
	AutomaticWeapons = {
		["weapon_smg1"] = true,
		["weapon_ar2"] = true,
	},
	Hooks = {},
	DontAimAt = {},
	VisiblePix = {},
}

local enabled = CreateClientConVar("aimbot_enabled", "1", true)
local teams = CreateClientConVar("aimbot_teams", "0", true)
local headshots = CreateClientConVar("aimbot_headshots", "1", true)
local targetnpcs = CreateClientConVar("aimbot_npcs", "1", true)
local targetplayers = CreateClientConVar("aimbot_players", "1", true)
local autoshoot = CreateClientConVar("aimbot_autoshoot", "1", true)
local autoshootdelay = CreateClientConVar("aimbot_autoshoot_custom_delay", "0", true)
local constantsnap = CreateClientConVar("aimbot_snap_always", "1", true)
local targetvisible = CreateClientConVar("aimbot_visibleonly", "1", true)
local norecoil	= CreateClientConVar( "aimbot_norecoil", "0", true)
local filterglass = CreateClientConVar( "aimbot_filter_glass", "0", true)
local filterfriends = CreateClientConVar( "aimbot_filter_friends", "1", true)
local spinbot = CreateClientConVar( "aimbot_spinbot", "0", true)
local spinbotsinwave = CreateClientConVar( "aimbot_spinbot_sine_p", "0", true)
local spazbot = CreateClientConVar( "aimbot_spazbot", "0", true)
local smoothangles = CreateClientConVar( "aimbot_smooth", "0", true)
local fixedview = CreateClientConVar( "aimbot_fixed_view", "0", true)
local nospreadenable = CreateClientConVar( "aimbot_nospread", "1", true)
local targetprops = CreateClientConVar("aimbot_props", "0", true)
local enablebeam = CreateClientConVar("aimbot_beam", "1", true)

concommand.Add("aimbot_addtofilter", function( ply, cmd, args )
	if !args[1] then
		print("Usage: aimbot_addtofilter <name/partofname>")
	else
		table.insert( BAimBot.DontAimAt, args[1] )
		PrintTable( BAimBot.DontAimAt )
	end
end )

concommand.Add("aimbot_clearfilter", function( ply, cmd, args )
	BAimBot.DontAimAt = {}
end )

function BAimBot:GenerateRandom()
	local j, r = 0, ""
	for i = 1, math.random(3, 19) do
		j = math.random(65, 116)
		if ( j > 90 && j < 97 ) then j = j + 6 end
		r = r .. string.char(j)
	end
	return r
end

function BAimBot:AddHook( h, f )
	local n = self:GenerateRandom()
	self.Hooks[n] = h
	hook.Add(h, n, f)
end

function BAimBot:GetAimLocation( ent )	
	local eyes = ent:LookupAttachment("eyes")

	if headshots:GetBool() and eyes != 0 and ( ent:IsPlayer() or ent:IsNPC() ) then
		return ent:GetAttachment( eyes ).Pos
	else
		return ent:LocalToWorld( ent:OBBCenter() )
	end
end

local visibletrace = {}

MASK_SHOT_NOWINDOW = CONTENTS_SOLID | CONTENTS_MOVEABLE | CONTENTS_MONSTER | CONTENTS_DEBRIS | CONTENTS_HITBOX

function BAimBot:Visible( e )
	
	visibletrace.start = LocalPlayer():GetShootPos()
	visibletrace.endpos = self:GetAimLocation( e )
	visibletrace.filter = LocalPlayer()
	if filterglass:GetBool() then
		visibletrace.mask = MASK_SHOT_NOWINDOW
	else
		visibletrace.mask = MASK_SHOT
	end
	return util.TraceLine( visibletrace ).Entity == e
end

function BAimBot:IsValidTarget( npc )
	local m = npc:GetMoveType()
	return IsValid( npc ) and m != MOVETYPE_NONE and m != MOVETYPE_OBSERVER and m != MOVETYPE_PUSH
end

function BAimBot:IsOnIgnorList(ply)
	if ( filterfriends:GetBool() and ply:GetFriendStatus() == "friend" ) then
		return true
	else
		for k,names in ipairs(self.DontAimAt) do
			if string.find( string.lower( ply:Nick() ), string.lower( names ), 1, true ) != nil or string.lower( ply:Nick() ) == string.lower( names ) then
				return true
			end
		end
		return false
	end
end

function BAimBot:ShouldTargetTeams( ent )
	if teams:GetBool() == true and ent:Team() != LocalPlayer():Team() then
		return true
	else
		return teams:GetBool() == false
	end
end

function BAimBot:ShouldTargetVisible( ent )
	if targetvisible:GetBool() == true then
		return self:Visible(ent)
	else
		return targetvisible:GetBool() == false
	end
end

function BAimBot:GetClosestNigger( tbl )
	local Target = nil
	for k, v in ipairs( tbl ) do
		if !IsValid( Target ) then
			Target = v
		elseif v:GetPos():Distance(LocalPlayer():GetPos()) < Target:GetPos():Distance(LocalPlayer():GetPos()) then
			Target = v
		end
	end
	self.Target = Target
end

local Targets = {}

function BAimBot:GetFilteredTargets()
	local shouldtargetplayers = targetplayers:GetBool()
	local shouldtargetnpcs = targetnpcs:GetBool()
	local shouldtargetprops = targetprops:GetBool()
	
	Targets = {}
	
	if shouldtargetplayers then
		for _,v in pairs( player.GetAll() ) do
			if ValidEntity( v ) and v != LocalPlayer() and self:IsValidTarget(v) and !self:IsOnIgnorList(v) and v:Alive() and self:ShouldTargetTeams(v) and self:ShouldTargetVisible( v ) then
				table.insert( Targets, v )
			end
		end
	end
	if shouldtargetnpcs then
		for _,v in pairs( ents.FindByClass( "npc_*" ) ) do
			if ValidEntity( v ) and self:IsValidTarget(v) and self:ShouldTargetVisible( v ) then
				table.insert( Targets, v )
			end
		end
	end
	if shouldtargetprops then
		for _,v in pairs( ents.FindByClass( "prop_" ) ) do
			if ValidEntity( v ) and self:IsValidTarget(v) and self:ShouldTargetVisible( v ) then
				table.insert( Targets, v )
			end
		end
	end
	
	return Targets
end

function BAimBot:GetAllAvailableTargets()
	local Targets = BAimBot:GetFilteredTargets()
	if #Targets > 0 then
		self:GetClosestNigger( Targets )
	else
		self.Target = nil
	end
end

concommand.Add( "+iliek2rape", function( p,c,a )
	BAimBot.Scanning = true
	BAimBot.Target = nil
end )

concommand.Add( "-iliek2rape", function( p,c,a )
	BAimBot.Scanning = false
	BAimBot.Target = nil
end )

concommand.Add( "togglerape", function( p,c,a )
	BAimBot.Scanning = !BAimBot.Scanning
	BAimBot.Target = nil
end )

function BAimBot:HUDPaint()

	if ( !enabled:GetBool() ) then return end

	if self.Scanning == true then
		surface.SetFont( "ScoreboardText" )
		if self.Target then
			local text = tostring( self.Target )
			local textsize = surface.GetTextSize( text )
			draw.SimpleText( text, "ScoreboardText", ScrW() / 2 - ( textsize / 2 ), ScrH() / 10, Color( 255, 0, 0, 225 ) )
		else
			local text = "Scanning.."
			local textsize = surface.GetTextSize( text )
			draw.SimpleText( text, "ScoreboardText", ScrW() / 2 - ( textsize / 2 ), ScrH() / 10, Color( 255, 0, 0, 225 ) )
		end
	end
end

function BAimBot:GetConeForWeap( weap )

	if weap.Initialize and type( weap.Initialize ) == "function" and weap.Primary and weap.Primary.Cone then
		if type( weap.Base ) == "string" and weap.Base == "bo_base" then
			return weap.Primary.Cone / weap:GetStanceAccuracyBonus()
		elseif type( weap.Base ) == "string" and weap.Base == "weapon_tttbase" then
			local sights = weap:GetNWBool( "Ironsights", false )
			weap.Primary.Cone = sights and ( weap.Primary.Cone * 0.9 ) or weap.Primary.Cone
			return weap.Primary.Cone
		elseif weap.Primary.Cone then
			return weap.Primary.Cone
		end
	elseif self.WeaponSpreads[ weap:GetClass() ] then
		return self.WeaponSpreads[ weap:GetClass() ]
	end
	
	return 0
end

function BAimBot:PredictSpread( cmd, angles )
	angles = angles or LocalPlayer():GetAimVector():Angle()
	
	local seed = nospread.GetSeed( nospread.GetCMDNumber( cmd ) )
	
	local weap = LocalPlayer():GetActiveWeapon()
	local vecCone = Vector( 0, 0, 0 )
	
	if IsValid( weap ) then
		valCone = self:GetConeForWeap( weap )
		if type( valCone ) == "number" then
			vecCone = Vector( -valCone, -valCone, -valCone )
		elseif type( valCone ) == "Vector" then
			vecCone = -1 * valCone
		end
	end
	
	return nospread.ManipulateShot( seed, angles:Forward(), vecCone ) or vector_origin
end

function BAimBot:Think()
	if ( !enabled:GetBool() ) then return end
	if self.Scanning then
		if !IsValid( self.Target ) then
			self:GetAllAvailableTargets()
		end
		if IsValid( self.Target ) and self:IsValidTarget( self.Target ) and ( ( self.Target:IsPlayer() and self.Target:Alive() ) or self.Target:IsNPC() or string.find( self.Target:GetClass(), "prop_" ) ) and self:ShouldTargetVisible( self.Target ) then
			self.AimVector = ( self:GetAimLocation( self.Target ) + ( self.Target:GetVelocity() / 45 ) - ( LocalPlayer():GetVelocity() / 45 ) - LocalPlayer():GetShootPos() ):Angle()
		else
			self.AimVector = false
		end
	end
end

local spinang = angle_zero
local smoothang = angle_zero
local custommouse = angle_zero

local mPitch = GetConVar( "m_pitch" )
local mYaw = GetConVar( "m_yaw" )
local shootingtime = 0
local shootingmode = false

function BAimBot:IsPropRotating( weapon, buttons )
	return IsValid( weapon ) and weapon:GetClass() == "weapon_physgun" and buttons & IN_USE > 0
end

function BAimBot:IsAutomaticWeapon( weap )
	if IsValid( weap ) and self.AutomaticWeapons[ weap:GetClass() ] or ( weap.Primary and weap.Primary.Automatic ) then
		return true
	else
		return false
	end
end

local vecMove = Vector()

function BAimBot:ShouldViewMinip( cmd )
	return ( cmd:GetButtons() & ( IN_ATTACK | IN_ATTACK2 ) ) == 0 and LocalPlayer():GetMoveType() == MOVETYPE_WALK and !LocalPlayer():KeyDown( IN_USE )
end

function BAimBot:CreateMove( cmd )

	if ( !enabled:GetBool() ) then return end
	
	local weapon = LocalPlayer():GetActiveWeapon()

	if fixedview:GetBool() and !self:IsPropRotating( weapon, cmd:GetButtons() ) then
		custommouse = custommouse and custommouse + Angle( cmd:GetMouseY() * mPitch:GetFloat(), cmd:GetMouseX() * -mYaw:GetFloat(), 0 ) or Angle( 0, 0, 0 )
		custommouse.r = 0
	end
	
	if spazbot:GetBool() and self:ShouldViewMinip( cmd ) then
		spinang.y = math.random( 1, 360 )
		spinang.p = math.random( -89, 89 )
		cmd:SetViewAngles( spinang )
	elseif spinbot:GetBool() and self:ShouldViewMinip( cmd ) then
		spinang.y = spinang.y + spinbot:GetInt()
		spinang.p = spinbotsinwave:GetBool() and ( math.sin( RealTime() * 8 ) * 45 ) or custommouse.p
		cmd:SetViewAngles( spinang )
	else
		spinang.y = custommouse.y
		if fixedview:GetBool() then
			cmd:SetViewAngles( custommouse )
		end
	end
	
	if self.Scanning and self.AimVector then
	
		if smoothangles:GetFloat() != 0 then
			smoothang = nospreadenable:GetBool() and LerpAngle( RealFrameTime() * 10, smoothang, self:PredictSpread( cmd, self.AimVector ):Angle() ) or self.AimVector
		else
			smoothang = nospreadenable:GetBool() and self:PredictSpread( cmd, self.AimVector ):Angle() or self.AimVector
		end
		
		if autoshoot:GetBool() then
			local setbut = cmd.DerptyDerp or cmd.SetButtons
			if !self:IsAutomaticWeapon( weapon ) then -- Handle semi-auto weapons differently
				
				local autodelay = autoshootdelay:GetFloat()
				
				local shotdelay = weapon.Primary and weapon.Primary.Delay or autodelay -- The weapons shot delay or the set value
				
				if autodelay > shotdelay then
					shotdelay = autodelay -- Use the set delay if it's greater than our weapons actual speed
				end
				
				if shootingtime <= RealTime() and !shootingmode then
					shootingmode = true
					shootingtime = RealTime() + shotdelay/2
					setbut( cmd, cmd:GetButtons() | IN_ATTACK ) -- We are only clicking/shooting for half of our delay. The other half is doing nothing allowing it to realize we let go of click
				elseif shootingtime <= RealTime() and shootingmode then
					shootingmode = false
					shootingtime = RealTime() + shotdelay/2
				end
			else
				setbut( cmd, cmd:GetButtons() | IN_ATTACK )
			end
		end
		
		if constantsnap:GetBool() or ( !constantsnap:GetBool() and ( cmd:GetButtons() & IN_ATTACK > 0 ) ) then
			cmd:SetViewAngles( smoothang )
		end
		
	else
		self.Target = nil
	end
	
	if ( fixedview:GetBool() or spinbot:GetBool() ) and LocalPlayer():GetMoveType() == MOVETYPE_WALK then
		vecMove.x = cmd:GetForwardMove()
		vecMove.y = cmd:GetSideMove()
		vecMove.z = cmd:GetUpMove()
		
		vecMove:Rotate( Angle( 0, cmd:GetViewAngles().y, 0 ) - Angle( 0, custommouse.y, 0 ) )
		
		cmd:SetForwardMove( vecMove.x )
		cmd:SetSideMove( vecMove.y )
		cmd:SetUpMove( vecMove.z )
	end
	
end

function BAimBot:Unload()
	for n, h in pairs( self.Hooks ) do
		MsgN(string.format("Removing: %s[%s]", h, n))
		hook.Remove(h, n)
	end
	self.Hooks = {}
end

function BAimBot:Reload()
	self:Unload()
	local filepath = debug.getinfo(1, "S").short_src
	if filepath then
		filepath = filepath:gsub( "lua\\", "" )
		MsgN( string.format("Reloading file: -> %s", filepath) )
		include( filepath )
	else
		Msg("Cannot reload..\n")
	end
end

local view = {}

function BAimBot:CalcView( ply, origin, angles, fov )

	if enabled:GetBool() and GetViewEntity() == ply then
	
		local w = ply:GetActiveWeapon()
		if ( w.Primary ) then w.Primary.Recoil = 0 end
		
		if fixedview:GetBool() then
			view.angles = custommouse
		elseif norecoil:GetBool() then
			view.angles	= ply:GetAimVector():Angle()
		end
		
		return view
		
	end

end

local LaserBeam = Material( "sprites/physbeam" )

function BAimBot:RenderScreenspaceEffects()
	if enablebeam:GetBool() then
		cam.Start3D( EyePos(), EyeAngles() )
			for _,ply in ipairs( player.GetAll() ) do
			
				local trace = ply:GetEyeTraceNoCursor()
				
				local beamstartpos = ply:EyePos()
				
				if !ply:ShouldDrawLocalPlayer() and ply == LocalPlayer() then
					beamstartpos = beamstartpos + ply:GetUp() * -16
				end
				
				local beamendpos = trace.HitPos
				
				if beamstartpos then
					render.SetMaterial( LaserBeam )
					render.DrawBeam( beamstartpos, beamendpos, 2, 1, 0, color_white )
				end
				
			end
		cam.End3D()
	end
end

BAimBot:AddHook( "CalcView", function(p,o,a,f) return BAimBot:CalcView(p,o,a,f) end )
BAimBot:AddHook( "CreateMove", function(c) BAimBot:CreateMove(c) end )
BAimBot:AddHook( "Think", function() BAimBot:Think() end )
BAimBot:AddHook( "HUDPaint", function() BAimBot:HUDPaint() end )
BAimBot:AddHook( "RenderScreenspaceEffects", function() BAimBot:RenderScreenspaceEffects() end )

concommand.Add( "aimbot_unload", function() BAimBot:Unload() end )
concommand.Add( "aimbot_reload", function() BAimBot:Reload() end )

