/*

	   _________  (_)  __________ |__ \
	  / ___/ __ \/ / |/_/_  /_  / __/ /
	 (__  ) / / / />  <  / /_/ /_/ __/ 
	/____/_/ /_/_/_/|_| /___/___/____/ 
	by 0xymoron
	

	
	If you have successfully stolen, cracked, or leaked this; congratulations buddy.
	I hope it fuels your ego & helps grow your tiny e-penis.
	The "encryption" was just there to fool people who don't know basic Lua.
	Don't let OJ get ahold of it, he'll rename it and claim it as his own.
	
	Yes, there is some borrowed code/methods in here, but not much at all.
	I reused a bunch of stuff from snixzz1 & that has since been removed, but some still remains.
	
	!!! You do not have permission to redistribute this. !!!
	!!! You do not have permission to modify this, use any of this, or manipulate it in any way. !!!
		
	----------------- 
	
		Credits
		
	-----------------
	
	fr1kin <3 - for teaching me Lua in the first place & tons of help along the way.
	Function - for helping test shit, small fixes, dragon dildos, & bae
	Styler - for Silent aim method
	thedynesty2 - for testing & shit
	OJ - pasting everything he's ever seen & telling people he coded shit until it gets leaked.
	crdriza - general help & shit
	
	daz - some stuff
	& whoever else gave me fancy methods of doing shit

	
	--------------------------
	
		TODO List & Ideas
	
	--------------------------
	
	- *** [Slowly replace userdata shit with _R.Entity]
		e.g: _R.Entity.GetPos( player ) instead of player:GetPos()
	
	- [Continue optimizing ESP]
		Ideas: 
		- Use OnEntityCreated/Removed to shorten needed loops
		- Only update loop when an entity is created or removed
		- Separate functions for each feature with "if !bool then return end" instead of "if bool then (doshit) end"
		- New fonts?
		- Buy a new fucking graphics card. <-- <-- <-- <-- <--
	
	- [Get Coder/Code a C++ login & loader] <- implying i'll ever do this
		- Use SteamID verification, 1 SteamID per customer
		- IP whitelist on source file
		- AES? encryption for module
		- Auto download gmcl_modules or add needed functions to injected .dll
		- Load before autorun & hide logged location of source.
		- encrypt lua before running
		- GarrysMod/ data directory, or SQL.
	
	------------------------------
	
		Interesting functions
		
	------------------------------
	
	gcinfo() - Get Lua memory usage in KB
	AngRand() - Generates a random pitch, yaw, & roll -90 to 90 & -180 to 180
	IsUselessModel( mdl ) - 
	JoinServer( ip )
	HSVToColor( RealTime() * 120 % 360, 1, 1 ) - Rainbow! ~ I forgot who gave me this, but thanks.

*/

local dickheads = {
	["STEAM_0:0:103305234"] = true,
}

if dickheads[_G.debug.getregistry().Player.SteamID( _G.Entity( _G.LocalPlayer():EntIndex() ) )] then g.MsgN( "Blacklisted." ) return end

if _G.snixzz then
	_G.snixzz = nil 
	MsgC( Color( 255, 0, 0 ), "[snixzz2] Detected an anti-cheat, or snixzz2 was reloaded.\n" )
end

local snixzz = {}
snixzz.DataFolder = "advdupe2 - Copy" -- sneaky sneaky :^)
snixzz.Info = {
	["Version"] = "build 1.4.0",
	["Updated"] = "9/22/15",
	["Size"] = "95kb",
	["Lines"] = "3,071",
}

local G = table.Copy( _G ) -- fuck listing all functions manually, this is quicker.
local _R = G.debug.getregistry()

snixzz.Detours = {
	["net.Start"] = {
		["checksaum"] = true,
		["checksum"] = true,
		["gcontrolled_vars"] = true,
		["controlled_vars"] = true,
		["quack"] = true,
		["leyac_cmd"] = true, -- old but blocks old versions
	},
	["Commands"] = {
	},
}
snixzz["Spoof"] = {
	["sv_allowcslua"] = G.GetConVarNumber( "sv_allowcslua" ), // some anti-cheats man..
	["sv_cheats"] = 0,
	["host_timescale"] = 1,
	["host_framerate"] = 0,
}	

// Aimbot vars nd shit
snixzz.Target = nil
snixzz.Typing = false
snixzz.Locked = false

snixzz.Bools = {
	
	-- Load settings
	["load_unhooked"] = false,
	
	-- Aimbot & view settings
	["aim_toggle"] = false,
	["aim_autoshoot"] = true,
	["aim_antiaim"] = true,
	["aim_silent"] = true,
	["aim_psilent"] = false,
	["aim_anti"] = false,
	["aim_nospread"] = true,
	["aim_norecoil"] = true,
	["aim_prediction"] = true,	
	["aim_antiantiaim"] = false,
	["aim_checkfov"] = false,
	["aim_ignorelos"] = false,
	["aim_ignoresteam"] = true,
	["aim_ignoreadmins"] = false,
	["aim_ignorebots"] = false,
	["aim_ignoreteam"] = false,
	["aim_ignorefriends"] = true,
	
	-- ESP settings
	["esp_enabled"] = true,
	["esp_name"] = true,
	["esp_health_text"] = true,
	["esp_health_bar"] = true,
	["esp_chams"] = true,
	["esp_chams_weapon"] = true,
	["esp_weapon"] = true,
	["esp_box"] = true,
	["esp_crosshair"] = false,
	["esp_crosshair_box"] = false,
	["esp_laser"] = true,
	["esp_nohands"] = true,
	["esp_status"] = true,
	["esp_list"] = true,
	["esp_snaplines"] = false,
	["esp_distance"] = false,
	["esp_dynamiclight"] = false,
	["esp_wireweapon"] = false,
	["esp_aimpos"] = false,

	["misc_bhop"] = true,
	["misc_bhop_autostrafe"] = false,
	["misc_namechanger"] = false,
	["misc_debug"] = true,
	["misc_triggerbot"] = false,
	["misc_triggerbot_nospread"] = true,
	["misc_fakelag"] = false,
	["misc_thirdperson"] = false,
	
}

snixzz.Vars = {
	
	-- Aimbot Vars
	["aim_distance"] = 2147483647,
	["aim_fov"] = 180,
	["aim_offset"] = 0,
	["aim_method"] = "Hitbox",
	["aim_anti_method"] = "Classic",
	["aim_hitbox"] = "Head",
	["aim_bone"] = "Head",
	["aim_target_method"] = "Distance",
	["aim_prediction_method"] = "Engine Vlocity",
	["aim_anti_spin_speed"] = 10,
	
	-- ESP Vars
	["esp_distance"] = 3000,
	["esp_chams_material"] = "Solid",
	["esp_asus_alpha"] = 0.95,
	["esp_box_width"] = 1.5,
	["esp_fov"] = 90,
	["esp_laser_attachment"] = "Iron Sights",
	
	-- Misc Vars
	["speedhack_speed"] = 3.5,
	["speedhack_type"] = "pSpeed",
	
	["misc_triggerbot_method"] = "Hitbox",
	["misc_menucolor"] = Color( 0, 188, 255, 75 ),
	["misc_menucolor2"] = Color( 255, 0, 0, 90 ),
	["misc_lasercolor"] = Color( 255, 0, 0, 255 ),
	["misc_thirdperson_distance"] = 90,
	["misc_fakelag_rate"] = 9,
	
}

snixzz.Binds = {
	["+aimbot"] = KEY_F,
	["+menu"] = KEY_INSERT,
	["+speedhack"] = KEY_B,
	["+triggerbot"] = KEY_G,
}

snixzz.Entities = {}
snixzz.Friends = {}
snixzz.BadEntities = {
	["env_sprite"] = true,
	["player"] = true,
	["prop_physics"] = true,
	["prop_door_rotating"] = true,
	["prop_dynamic"] = true,
	["viewmodel"] = true,
	["weapon_physgun"] = true,
	["weapon_physcannon"] = true,
	["keys"] = true,
	["pocket"] = true,
	["gmod_tool"] = true,
	["physgun_beam"] = true,
	["func_door_rotating"] = true,
	["func_breakable_surf"] = true,
	["worldspawn"] = true,
}

snixzz.Keys = {
	[1] = { Name = "A", Key = KEY_A },
	[2] = { Name = "B", Key = KEY_B },
	[3] = { Name = "C", Key = KEY_C },
	[4] = { Name = "D", Key = KEY_D },
	[5] = { Name = "E", Key = KEY_E },
	[6] = { Name = "F", Key = KEY_F },
	[7] = { Name = "G", Key = KEY_G },		
	[8] = { Name = "H", Key = KEY_H },
	[9] = { Name = "I", Key = KEY_I },
	[10] = { Name = "J", Key = KEY_J },
	[11] = { Name = "K", Key = KEY_K },
	[12] = { Name = "L", Key = KEY_L },
	[13] = { Name = "M", Key = KEY_M },
	[14] = { Name = "N", Key = KEY_N },
	[15] = { Name = "O", Key = KEY_O },
	[16] = { Name = "P", Key = KEY_P },
	[17] = { Name = "Q", Key = KEY_Q },
	[18] = { Name = "R", Key = KEY_R },
	[19] = { Name = "S", Key = KEY_S },
	[20] = { Name = "T", Key = KEY_T },
	[21] = { Name = "U", Key = KEY_U },
	[22] = { Name = "V", Key = KEY_V },
	[23] = { Name = "W", Key = KEY_W },
	[24] = { Name = "X", Key = KEY_X },
	[25] = { Name = "Y", Key = KEY_Y },
	[26] = { Name = "Z", Key = KEY_Z },
	[27] = { Name = "SPACE", Key = KEY_SPACE },
	[28] = { Name = "TAB", Key = KEY_TAB },
	[29] = { Name = "Left Shift", Key = KEY_LSHIFT },
	[30] = { Name = "Right Shift", Key = KEY_RSHIFT },
	[31] = { Name = "Left Alt", Key = KEY_LALT },
	[32] = { Name = "Right Alt", Key = KEY_RALT },
	[33] = { Name = "Delete", Key = KEY_DELETE },
	[34] = { Name = ".", Key = KEY_PERIOD },
	[35] = { Name = "/", Key = KEY_SLASH },
	[36] = { Name = "[", Key = KEY_LBRACKET },
	[37] = { Name = ";", Key = KEY_SEMICOLON },
	[38] = { Name = "'", Key = KEY_APOSTROPHE },
	[39] = { Name = ",", Key = KEY_COMMA },	
	[40] = { Name = "Insert", Key = KEY_INSERT },
}

snixzz.DefaultConfig = G.file.Read( snixzz.DataFolder .. "/defaultconfig.txt", "DATA" ) or "default"

// nospread shit
snixzz.RecoilBackup = {}

snixzz.BadWeapons = {
	["gmod_tool"] = true,
	["gmod_camera"] = true,
	["weapon_physgun"] = true,
	["weapon_crowbar"] = true,
	["keys"] = true,
	["pocket"] = true,
}

snixzz["Colors"] = {
	["White"] = Color( 255, 255, 255, 255 ),
	["Black"] = Color( 0, 0, 0, 255 ),
	["Green"] = Color( 0, 255, 0, 255 ),
	["Red"] = Color( 255, 0, 0, 255 ),
	["DarkRed"] = Color( 200, 50, 50, 255 ),
	["Cyan"] = Color( 0, 255, 255, 255 ),
	["Purple"] = Color( 255, 0, 255 ),
}

snixzz.AdminGroups = {
	["trialmod"] = true,
	["tmod"] = true,
	["trial-mod"] = true,
	["trialmoderator"] = true,
	["t-mod"] = true,
	["mod"] = true,
	["moderator"] = true,
	["operator"] = true,
	["vipmod"] = true,
	["vipmoderator"] = true,
	["admin"] = true,
	["vipadmin"] = true,
	["head-admin"] = true,
	["headadmin"] = true,
	["manager"] = true,
	["developer"] = true,
	["dev"] = true,
	["superadmin"] = true,
	["sadmin"] = true,
	["super"] = true,
	["vipsuperadmin"] = true, -- i cry
	["owner"] = true,
	["root_user"] = true,
	["vipowner"] = true, -- wouldn't be surprised it
	["doubleadmin"] = true, -- what the fuck is this
}

G.surface.CreateFont( "snixzz_status", { font = "coolvetica", size = 20, antialias = true } ) -- HudHintTextLarge
G.surface.CreateFont( "snixzz_logo", { size = 25, weight = 0, antialias = true, shadow = false, font = "Tahoma" } )
G.surface.CreateFont( "snixzz_logo_small", { size = 13, weight = 0, antialias = true, shadow = false, font = "Tahoma" } )
G.surface.CreateFont( "ESPFont", { size = 14, weight = 200, antialias = false, shadow = true, font = "Arial" } )

/* General notification/display functions */

local sound
function snixzz.Sound( Error )
	if Error then
		sound = G.Sound( "/HL1/fvox/buzz.wav" )
	else
		sound = G.Sound( "/buttons/button17.wav" )
	end
	local createSound = G.CreateSound( G.LocalPlayer(), sound )
	createSound:Play()
end

function snixzz.Message( col, text )
	G.MsgC( snixzz.Colors.Cyan, "[snixzz2]: " )
	G.MsgC( col, text .. "\n" )
end

function snixzz.ACNotify( text )
	G.MsgC( snixzz.Colors.White, "[snixzz2]: " )
	G.MsgC( snixzz.Colors.Red, text .. "\n" )
	snixzz.logEvent( "anticheat", text )
	snixzz.Sound( Error )
end

function snixzz.Debug( text )
	if snixzz.Bools["misc_debug"] then
		G.MsgC( snixzz.Colors.Purple, "[snixzz2Debug]: " )
		G.MsgC( Color( 255, 255, 255 ), text .. "\n" )
	end
	snixzz.logEvent( "Debug", text )
end

function snixzz.LogDetour( text )
	if snixzz.Bools["misc_debug"] then
		G.MsgC( snixzz.Colors.White, "[snixzz2Detour]: " )
		G.MsgC( Color( 255, 255, 255 ), text .. "\n" )
	end
	snixzz.logEvent( "Detour", text )
end

/* Detour function */
function snixzz.Detour( Old, New )
	snixzz.Detours[New] = Old
	snixzz.Message( Color( 200, 150, 255 ), "Detouring function " .. G.tostring( Old ) .. "." )
	snixzz.logEvent( "Load", "Detouring function " .. G.tostring( Old ) .. "." )
	return New
end

-- Load the modules
G.require( "bsendpacket" ) bSendPacket = true
G.require( "snixzz2" )
G.require( "pspeed" )
G.require( "name_enabler" )

-- C++ Module functions
snixzz.Functions = {

	-- gmcl_frozen
	["PredictSpread"] = _G.NHTable.ZeroSpread,
	["SetMuted"] = _G.NHTable.SetMuted,
	["LocalPlayer"] = _G.NHTable.SetLPIndex,
	["SetCvarName"] = _G.NHTable.SetCvarName,
	["ConCommand"] = _G.NHTable.ClientCMD,
	["IsMuted"] = _G.NHTable.IsMuted,
	["NoDraw"] = _G.NHTable.NoDraw,
	["RawGet"] = _G.NHTable.RawGet,
	["SetViewAngles"] = _G.NHTable.SetViewAngles,
	["AsusWalls"] = _G.NHTable.AsusWalls,
	["GetCvar"] = _G.NHTable.GetCvar,
	["IsDormant"] = _G.NHTable.IsDormant,
	["GetServerIP"] = _G.NHTable.GetServerIP,
	["Changename"] = _G.NHTable.Changename,
	["IsVisible"] = _G.NHTable.IsVisible,
	["SetCvarValue"] = _G.NHTable.SetCvarValue,
	
	-- gmcl_pspeed
 	["SetSpeed"] = _G.SetSpeed,

}

snixzz.ACStatus = {
	["CAC"] = "DETECTED",
	["LeyAC"] = "DETECTED",
	["TAC v4"] = "UNDETECTED",
	["HERP-AC"] = "BYPASSED",
	["TAC v2"] = "BYPASSED",
	["QAC"] = "BYPASSED",
	["VAC"] = "UNDETECTED", -- Shut up, it does exist. it's a tiny blacklist.
	["GAC"] = "UNDETECTED",
	["Kevlar"] = "UNDETECTED",
	["Daz's AC"] = "UNDETECTED",
	["GModZ AC"] = "UNDETECTED",
	["VBAC"] = "UNDETECTED",
}

/*
	Logging system
*/
snixzz.LogCache = {}
snixzz.ConsoleLogs = {}
snixzz.LastLog = 0
snixzz.MaxLogs = 15
snixzz.NoLog = { -- Types of logs to not save in data/
	["Setting"] = true,
	["Load"] = true,
	["Detours"] = true,
	["Config"] = true,
	["Info"] = true,
	["debug"] = true,
	["Timer"] = true,
	["Hook"] = true,
	["Main"] = true,
}

snixzz.Lines = {}
function snixzz.logEvent( Type, str )

	G.table.insert( snixzz.Lines, str )
	if snixzz.Console then
		snixzz.Console:AddLine( str )
	end
	
	snixzz.LogCache[Type] = str

	snixzz.ConsoleLogs[snixzz.LastLog + 1] = str
	snixzz.LastLog = snixzz.LastLog + 1
	
	if snixzz.LastLog == snixzz.MaxLogs then
		snixzz.ConsoleLogs = {}
		snixzz.LastLog = 0
	end
	
	if !snixzz.NoLog[Type] then
		local logFile = "[" .. G.os.date() .. "] " .. str .. "\n"
		G.file.Append( snixzz.DataFolder .. "/logs/" .. Type .. ".txt", logFile )
	end
end

/* Anti-Cheat bypass functions */
-- This is all really outdated. TODO: Update thhis
snixzz.Backup = {}
function snixzz.AntiCheats()
	
	-- Notify of detoured functions i guess
	for k, v in G.pairs( snixzz.Functions ) do
		snixzz.Message( Color( 200, 255, 0 ), "Copied function " .. G.tostring( v ) .. " '" .. k .. "'" )
		v = nil
	end 

	-- HERP-AC c+p shitty ac
	if _G.CheckVars then
		snixzz.ACNoitfy( "function CheckVars exists, detouring the scan." )
		_G.CheckVars = snixzz.Detour( _G.CheckVars, function()
			snixzz.Message( Color( 50, 255, 50 ), "HERP-AC attempted to scan cvars, stopping that..." )
		end )
	end
	
	-- Tyler's Anti-Cheat v2 (shameless bypass of my own anti-cheat)
	if _G.RunCheck then
		snixzz.ACNoitfy( "function RunCheck exists, detouring." )
		_G.RunCheck = snixzz.Detour( _G.RunCheck, function()
			snixzz.Message( Color( 50, 255, 50 ), "TAC attempted to run a check, returning no information." )
		end )
 	end
	
	-- Prestige Gaming CAC
	if _G.CAC then
		snixzz.ACNoitfy( "table CAC exists, bypassing anti-cheat." )
		function CAC:FilePlayer() snixzz.ACNoitfy( "CAC:FilePlayer() Attempted to run" ) end
		G.timer.Destroy( "CAC" )
	end

	-- Some shitty PERP anti-cheat
	G.concommand.Remove( "0_u_found" )
	G.concommand.Add( "0_u_found", function()
		snixzz.ACNoitfy( "anti-cheat concommand 0_u_found blocked" )
	end )
	G.hook.Remove( "InitPostEntity", "detrp" )
	
	-- Anti-cheat current detection status
	for k, v in G.pairs( snixzz.ACStatus ) do
		G.MsgC( Color( 255, 150, 0 ), "[snixzz2] " )
		G.MsgC( Color( 255, 255, 255 ), k .. ": " )
		if v == "DETECTED" then
			G.MsgC( Color( 255, 0, 0 ), v .. "\n" )
		elseif v == "BYPASSED" then
			G.MsgC( Color( 255, 255, 0 ), v .. "\n" )
		elseif v == "UNDETECTED" then
			G.MsgC( Color( 0, 255, 0 ), v .. "\n" )
		end
	end
	
	G.hook.Remove( "OnGamemodeLoaded", "___scan_g_init" )
	G.hook.GetTable()["OnGamemodeLoaded"]["___scan_g_init"] = function() end
		
end
snixzz.AntiCheats()

-- TODO: Add runstring section to menu
local compiledString
function snixzz.RunString( str )

	compiledString = G.CompileString( str, "[C]", false )
	
	if G.type( compiledString ) == "string" then
		snixzz.Message( Color( 0, 255, 255 ), "Failed to run Lua. '" .. str .. "'" )
		return
	end

	compiledString()
	
end

local Name
snixzz.Hooks = {}
function snixzz.AddHook( Type, Func )
	Name = G.tostring( Func )
	snixzz.Message( Color( 255, 255, 0 ), "Adding unsecure hook '" .. Name .. "'" )
	snixzz.Hooks[Type] = Name
	return G.hook.Add( Type, Name, Func )
end

snixzz.TimerCache = {}
function snixzz.RegisterTimer( delay, rep, func )
	Name = G.tostring( func )
	snixzz.Message( Color( 125, 0, 282 ), "Adding timer " .. Name .. " with delay '" .. Name .. "'" )
	snixzz.logEvent( "Load", "Adding timer " .. Name .. " with delay '" .. Name .. "'" )
	G.table.insert( snixzz.TimerCache, Name )
	return G.timer.Create( Name, delay, rep, func )
end

function snixzz.ForceCvar( cvar, value ) -- removed until further notice
	if snixzz.Spoof[cvar] == nil then
		snixzz.Spoof[cvar] = G.GetConVarNumber( cvar )
	end
	--G.GetConVar( cvar ):SetValue( value )
end

/*

	Settings & Menu backend.
	Config system recycled from hake v2
	Re-wrote a bit of it.
	
*/

function snixzz.CreateOption( dtype, parent, oText, oBool, xPos, yPos, oWide, xPos2, yPos2, oDec, func )
	local addx, addy = 3, 3.5
	
	if dtype == "Checkbox" then
		dtype = "DCheckBoxLabel"
		local text, bool, x, y = oText, oBool, xPos, yPos
		local checkbox = G****ui.Create( dtype, parent )
		checkbox:SetText( text )
		checkbox:SetPos( x + addx, y + addy )
		checkbox:SizeToContents()
		checkbox:SetTextColor( G.color_white )
		checkbox:SetChecked( snixzz.Bools[bool] ) 
		checkbox.OnChange = function( check ) 
			snixzz.Bools[bool] = checkbox:GetChecked() 
		end 	
		
	elseif dtype == "Slider" then
		dtype = "DNumSlider"
		local text, var, min, max, wide, x, y, Dec = oText, oBool, xPos, yPos, oWide, xPos2, yPos2, oDec
		local slider = G****ui.Create( dtype, parent )
		slider:SetPos( x + addx, y + addy )
		slider:SetWide( wide )
		slider:SetText( text )
		slider:SetMin( min )
		slider:SetMax( max )
		slider:SetDecimals( Dec )
		slider:SetValue( snixzz.Vars[var] ) 
		slider.OnValueChanged = function( p, v ) 
			snixzz.Vars[var] = v 
		end
		
	elseif dtype == "Label" then
		dtype = "DLabel"
		local text, x, y = oText, oBool, xPos
		local label = G****ui.Create( dtype, parent )
		label:SetPos( x, y )
		label:SetText( text )
		label:SizeToContents()
		label:SetTextColor( G.color_white )
		
	end
end

function snixzz.ConfigExists( cfg )
	if G.file.Exists( snixzz.DataFolder .. "/configs/" .. snixzz.Info.Version .. "/" .. cfg .. ".txt", "DATA" ) then
		return true
	else
		return false
	end
end

function snixzz.SaveConfig( cfg )
	local save = {}
	save.Vars = snixzz.Vars
	save.Bools = snixzz.Bools
	save.Binds = snixzz.Binds
	save.Entities = snixzz.Entities
	save.Friends = snixzz.Friends
	cfg = G.string.gsub( cfg, " ", "_" )
	if !snixzz.ConfigExists( cfg ) then
		G.table.insert( snixzz.Configs, cfg )
		G.file.Write( snixzz.DataFolder .. "/configs/" .. snixzz.Info.Version .. "/" .. cfg .. ".txt", G.util.TableToJSON( save ) )
		snixzz.Message( snixzz.Colors.Green, "Created config " .. cfg .. "!" )
		snixzz.logEvent( "Config", "Created config '" .. cfg .. "'" )
	else
		snixzz.Message( snixzz.Colors.Red, "Config " .. cfg .. " already exists!" )
		snixzz.logEvent( "Config", "Config " .. cfg .. " already exists" )
	end
end

function snixzz.UpdateConfig()
	local cfg = snixzz.CurrentConfig
	if cfg != "default" then
		if snixzz.ConfigExists( cfg ) then
			local save = {}
			save.Vars = snixzz.Vars
			save.Bools = snixzz.Bools
			save.Binds = snixzz.Binds
			save.Entities = snixzz.Entities
			save.Friends = snixzz.Friends
			G.file.Write( snixzz.DataFolder .. "/configs/" .. snixzz.Info.Version .. "/" .. cfg .. ".txt", G.util.TableToJSON( save ) )
			snixzz.Message( snixzz.Colors.Green, "Updated '" .. cfg .. "' with current settings" )
			snixzz.logEvent( "Config", "Updated '" .. cfg .. "' with current settings" )
		else
			snixzz.Message( snixzz.Colors.Red, "Config " .. cfg .. " wasn't found!" )
			snixzz.logEvent( "Config", "Config '" .. cfg .. "' wasn't found" )
		end
	else
		snixzz.Message( snixzz.Colors.Red, "You can't modify 'default' config!" )
		snixzz.logEvent( "Config", "You can't modify 'default' config!" )
	end		
end
	
function snixzz.LoadConfig( cfg )
	cfg = G.string.lower( cfg )
	if snixzz.CurrentConfig != cfg then
		if snixzz.ConfigExists( cfg ) then
			local ToRead = G.util.JSONToTable( G.file.Read( snixzz.DataFolder .. "/configs/" .. snixzz.Info.Version .. "/" .. cfg .. ".txt", "DATA" ) )
			snixzz.Vars = ToRead.Vars
			snixzz.Bools = ToRead.Bools
			snixzz.Binds = ToRead.Binds
			snixzz.Entities = ToRead.Entities
			snixzz.Friends = ToRead.Friends
			snixzz.CurrentConfig = cfg
			snixzz.Message( snixzz.Colors.Green, "Loaded config '" .. cfg .. "'" )
			snixzz.logEvent( "Config", "Loaded config '" .. cfg .."'" )
		else
			snixzz.LoadConfig( "default" )
			snixzz.CurrentConfig = "default"
			snixzz.Message( Color( 255, 0, 0 ), "Invalid config file! '" .. cfg .. "' Loading default!" )
			snixzz.logEvent( "Config", "Invalid config file '" .. cfg .."' Loading default!" )
		end
	else
		snixzz.Message( snixzz.Colors["White"], "Config " .. cfg .. " is already loaded!" )
		snixzz.logEvent( "Config", "Config '" .. cfg .."' is already loaded." )
	end
end

function snixzz.DeleteConfig( cfg )
	cfg = G.string.lower( cfg )
	if cfg != snixzz.DefaultConfig then
		if G.file.Exists( snixzz.DataFolder .. "/configs/" .. snixzz.Info.Version .. "/" .. cfg .. ".txt", "DATA" ) then
			G.file.Delete( snixzz.DataFolder .. "/configs/" .. snixzz.Info.Version .. "/" .. cfg .. ".txt" )
			snixzz.Message( snixzz.Colors["DarkRed"], "Deleted config " .. cfg )
			snixzz.logEvent( "Config", "Deleted config '" .. cfg .. "'" )
		else
			snixzz.Message( Color( 255, 0, 0 ), "Unable to find config " .. cfg "!" )
			snixzz.logEvent( "Config", "Unable to find config '" .. cfg .."'" )
		end
	else
		snixzz.Message( snixzz.Colors["Red"], "You cannot delete the default config!" )
		snixzz.logEvent( "Config", "You cannot delete the default config" )
	end
end

function snixzz.RenameConfig( Old, New )
	New = G.string.gsub( New, " ", "_" )
	New = G.string.lower( New )
	if Old != snixzz.DefaultConfig then
		if !snixzz.ConfigExists( New ) then
			local OldConfig = G.file.Read( snixzz.DataFolder .. "/configs/" .. snixzz.Info.Version .. "/" .. Old .. ".txt", "DATA" )
			if snixzz.ConfigExists( Old ) then
				G.file.Delete( snixzz.DataFolder .. "/configs/" .. snixzz.Info.Version .. "/" .. Old .. ".txt", "DATA" )
			end
			G.file.Write( snixzz.DataFolder .. "/configs/" .. snixzz.Info.Version .. "/" .. New .. ".txt", OldConfig )
			snixzz.Message( snixzz.Colors["DarkRed"], "Renamed " .. Old .. " to " .. New .. "." )
			snixzz.logEvent( "Config", "Renamed config '" .. Old .. "' to '" .. New .. "'" )
		else
			snixzz.Message( Color( 255, 0, 0 ), "Config " .. New .. " already exists! Pick a different name." )
			snixzz.logEvent( "Config", "Config '" .. New .. "' already exists, pick a different name" )
		end
	else
		snixzz.Message( snixzz.Colors["Red"], "You cannot rename the default config!" )
		snixzz.logEvent( "Config", "You cannot rename the default config" )
	end
end

function snixzz.SetDefaultConfig( cfg )
	if cfg != snixzz.DefaultConfig then
		if snixzz.ConfigExists( cfg ) then
			snixzz.DefaultConfig = cfg 
			G.file.Write( snixzz.DataFolder .. "/defaultconfig.txt", snixzz.DefaultConfig )
			snixzz.Message( Color( 255, 255, 0 ), "Set '" .. cfg .. "' as the default config." )
			snixzz.logEvent( "Config", "Set '" .. cfg .. "' as the default config" )
		else
			snixzz.Message( Color( 255, 0, 0 ), "'" .. cfg .. "' is not a valid config!" )
			snixzz.logEvent( "Config", "Config '" .. cfg .. "' is not a valid config" )
		end
	else
		snixzz.Message( Color( 255, 0, 0 ), "'" .. cfg .. "' is already the default config!" )
		snixzz.logEvent( "Config", "Config '" .. cfg .."' is already the default config" )
	end
end

function snixzz.BindKey( Bind, Key ) 
	if snixzz.Binds[Bind] then 
		for _, v in G.pairs( snixzz.Keys ) do 
			if Key == v.Name then 
				snixzz.Binds[ Bind ] = v.Key 
				snixzz.Message( snixzz.Colors["Green"], "Bound " .. Bind .. " to " .. Key .. "!" )
				snixzz.logEvent( "Config", "Bound '" .. Bind .. "' to '" .. Key .. "'" )
			end 
		end  
	end 
end

function snixzz.Unbind( Bind )
	if snixzz.Binds[ Bind ] then
		snixzz.Binds[ Bind ] = nil
		snixzz.Message( snixzz.Colors["DarkRed"], "Unbound " .. Bind .. "!" )
		snixzz.logEvent( "Config", "Unbound '" .. Bind .. "'" )
	end
end 

function snixzz.GetConfigs() 
	local files = G.file.Find( snixzz.DataFolder .. "/configs/" .. snixzz.Info.Version .. "/*.txt", "DATA") 
	for k, v in G.pairs( files ) do 
		files[ k ] = G.string.Replace( v, ".txt", "" ) 
	end  
	return files 
end 
snixzz.Configs = snixzz.GetConfigs()

/*

	filesystem 

*/

snixzz.DataFiles = {
	"defaultconfig.txt",
	"logs/Main.txt",
	"logs/AntiCheat.txt",
	"logs/Detour.txt",
	"logs/Debug.txt",
}
snixzz.DataFolders = {
	"configs",
	"configs/" .. snixzz.Info.Version,
	"logs",
}

function snixzz.FileSystem()
	
	if !G.file.IsDir( snixzz.DataFolder, "DATA" ) then
		G.file.CreateDir( snixzz.DataFolder )
		snixzz.Message( Color( 0, 255, 0 ), "Creating '" .. snixzz.DataFolder .. "' main data folder." )
	end
	
	for k, v in G.next, snixzz.DataFolders do
		if !G.file.IsDir( snixzz.DataFolder .. "/" ..  v, "DATA" ) then
			G.file.CreateDir( snixzz.DataFolder .. "/" .. v )
			snixzz.Message( Color( 0, 255, 0 ), "Creating '" .. snixzz.DataFolder .. "/" .. v .. "' data folder." )
		end
	end

	for k, v in G.next, snixzz.DataFiles do
		if !G.file.Exists( snixzz.DataFolder .. "/" ..  v, "DATA" ) then
			if v == "defaultconfig.txt" then	
				G.file.Write( snixzz.DataFolder .. "/" .. v, snixzz.DefaultConfig )
			else
				G.file.Write( snixzz.DataFolder .. "/" .. v, "=== snixzz2 by 0xymoron ===\n\n" )
			end
			snixzz.Message( Color( 0, 255, 0 ), "Creating '" .. snixzz.DataFolder .. "/" .. v .. "' data file." )
		end
	end
	
	if !snixzz.ConfigExists( "default" ) then
		snixzz.SaveConfig( "default" )
	end
end
snixzz.Message( Color( 255, 255, 0 ), "Loading filesystem.." )
snixzz.FileSystem()

/*
	ESP	functions
*/

-- borrowed from snipwnage2's cheat with permission
function snixzz.GetBounds( v )

	local eyePos = v:EyeAngles()
	local min = v:OBBMins()
	local max = v:OBBMaxs()
	
	local corners = {
		G.Vector( min.x, min.y, min.z ),
		G.Vector( min.x, min.y, max.z ),
		G.Vector( min.x, max.y, min.z ),
		G.Vector( min.x, max.y, max.z ),
		G.Vector( max.x, min.y, min.z ),
		G.Vector( max.x, min.y, max.z ),
		G.Vector( max.x, max.y, min.z ),
		G.Vector( max.x, max.y, max.z ),
	}
	
	local minx = G.math.huge 
	local miny = G.math.huge 
	local maxx = -G.math.huge
	local maxy = -G.math.huge
	
	for _, corner in G.next, corners do
		local screen = v:LocalToWorld( corner ):ToScreen()
		minx = G.math.min( minx, screen.x )
		miny = G.math.min( miny, screen.y )
		maxx = G.math.max( maxx, screen.x )
		maxy = G.math.max( maxy, screen.y )
	end
	
	return minx, miny, maxx, maxy
end

-- Thanks gmod wiki!
function snixzz.DrawOutlinedBox( x, y, w, h, thickness, color )
	G.surface.SetDrawColor( color )
	for i = 0, thickness - 1 do
		G.surface.DrawOutlinedRect( x + i, y + i, w - i * 2, h - i * 2 )
	end
end

function snixzz.IsAdmin( v )

	if v:IsAdmin() then
		return true
	end
	
	if snixzz.AdminGroups[v:GetUserGroup()] then
		return true
	end
	
end

function snixzz.ShouldDraw( v )

	// better fps maybe
	local distance = v:GetPos():Distance( G.LocalPlayer():GetPos() )
	if snixzz.Vars["esp_distance"] != 0 && distance >= snixzz.Vars["esp_distance"] then
		return false
	end

	if !v:IsPlayer() or !v:Alive() or v == G["LocalPlayer"]() then
		return false
	end
		
	if ( v:Team() == TEAM_SPECTATOR or G.string.find( G.team.GetName( v:Team() ), "spectator" ) ) then
		return false
	end	
	
	if snixzz.Functions.IsDormant( v:EntIndex() ) then
		return false
	end
	
	return true	
end

/********************/
/*					*/
/* Aimbot functions */
/*					*/
/********************/


function snixzz.IsValid( v )

	if !G.IsValid( v ) or v == G.LocalPlayer() or !v:IsPlayer() then
		return false
	end

	// visible check
	if !snixzz.Bools["aim_ignorelos"] then
		if !snixzz.IsVisible( v ) then
			return false
		end
	end
	
	if snixzz.Bools["aim_checkfov"] then
		if !snixzz.InFov( v ) then
			return false
		end
	end
	
	if snixzz.Bools["aim_ignoreadmins"] then
		if snixzz.IsAdmin( v ) then
			return false
		end
	end
	
	if snixzz.Bools["aim_ignorefriends"] then
		if snixzz.Friends[v:Nick()] then
			return false
		end
	end
	
	if snixzz["IsDormant"]( v:EntIndex() ) then 
		return false
	end
	
	if snixzz.Bools["aim_ignorebots"] && v:IsBot() then
		return false
	end
	
	if ( !v:Alive() || !v:IsPlayer() || v:InVehicle() ) then 
		return false 
	end
	
	if ( G.GetConVarNumber( "sbox_noclip" ) == 0 && v:GetMoveType() == MOVETYPE_NOCLIP ) then 
		return false 
	end
	
	-- Ignore Steam friends
	if snixzz.Bools["aim_ignoresteam"] then
		if v:GetFriendStatus() == "friend" then 
			return false 
		end
	end
	
	-- Friendly Fire
	if snixzz.Bools["aim_ignoreteam"] then
		if ( v:Team() == G.LocalPlayer():Team() ) then
			return false
		end
	end
			
	if ( v:GetMoveType() == MOVETYPE_OBSERVER || v:Team() == TEAM_SPECTATOR ) then 
		return false 
	end
	
	// ignore T buddies
	if G.string.find( G.GAMEMODE.Name, "Trouble in Terror" ) then
		if ( G.LocalPlayer():IsTraitor() && v:IsTraitor() ) then
			return false
		end
	end
	
	// spawn protection (multiple server detection methods)
	local col = v:GetColor()
	if col.a < 255 then
		return false
	end
	if G.LocalPlayer():GetColor().a < 255 then
		return false
	end
	
	// gun game server
	if v:GetMaterial() == "models/props_combine/stasisshield_sheet" then
		return false
	end

	return true
end


snixzz.Cones = {
	["HL2"] = {
		["weapon_pistol"] = G.Vector( 0.01, 0.01, 0.01 ),
		["weapon_smg1"] = G.Vector( 0.04362, 0.04362, 0.04362 ),
		["weapon_ar2"] = G.Vector( 0.02618, 0.02618, 0.02618 ),
		["weapon_shotgun"] = G.Vector( 0.08716, 0.08716, 0.08716 ),
	},
	["Normal"] = {}
}

snixzz.SimpleSpread = {
	["weapon_cs_base"] = true,
	["weapon_zs_base"] = true,
}
local wepCone
function snixzz.GetCone( wep )

	if !G.IsValid( wep ) then
		return 0
	end
	
	if snixzz.Cones.Normal[wep:GetClass()] then
		return snixzz.Cones.Normal[wep:GetClass()]
		
	elseif snixzz.SimpleSpread[wep.Base] then
		return wep.Cone or wep.Primary.Cone or 0
		
	elseif snixzz.Cones.HL2[wep:GetClass()] then
		return snixzz.Cones.HL2[wep:GetClass()]
		
	else
		wepCone = wep.Cone
		if !wepCone then
			wepCone = wep.Primary && wep.Primary.Cone or 0
		end	
	end
	
	return wepCone or 0
	
end
		
local spreadCone = G.Vector( 0, 0, 0 )
local getCone = G.Vector( 0, 0, 0 )
function snixzz.PredictSpread( cmd, ang )
	local wep = G.LocalPlayer():GetActiveWeapon() or NULL
	
	if !G.IsValid( wep ) then
		return ang
	end
	
	if G.type( wep.Initialize ) == "function" then
		getCone = snixzz.GetCone( wep )
			
		if G.type( getCone ) == "number" then
			spreadCone = G.Vector( -getCone, -getCone, -getCone )
		elseif G.type( getCone ) == "Vector" then
			spreadCone = getCone * -1
		end
	else
		if snixzz.Cones.HL2[wep:GetClass()] then
			spreadCone = snixzz.Cones.HL2[wep:GetClass()]
		end
	end
	
	return snixzz.Functions.PredictSpread( cmd, ang, spreadCone )
end

snixzz.PunchWeps = {
	["weapon_pistol"] = true,
	["weapon_smg1"] = true,
	["weapon_ar2"] = true,
	["weapon_shotgun"] = true,
}

local wep
local punchAngle
function snixzz.CorrectRecoil( ucmd )
	wep = G.LocalPlayer():GetActiveWeapon()
	
	if G.IsValid( wep ) then
		if snixzz.PunchWeps[wep:GetClass()] then
			punchAngle = ucmd:GetViewAngles() - G.LocalPlayer():GetPunchAngle()
			snixzz.Functions.SetViewAngles( ucmd, punchAngle )
		end
	end
end

snixzz.Bones = {
	["Head"] = "ValveBiped.Bip01_Head1",
	["Neck"] = "ValveBiped.Bip01_Neck1",
	["Spine"] = "ValveBiped.Bip01_Spine",
	["Spine2"] = "ValveBiped.Bip01_Spine2",
	["Spine4"] =  "ValveBiped.Bip01_Spine4",
	["Pelvis"] = "ValveBiped.Bip01_Pelvis",
	["R Upperarm"] = "ValveBiped.Bip01_R_UpperArm",
	["R Forearm"] = "ValveBiped.Bip01_R_Forearm",
	["R Hand"] = "ValveBiped.Bip01_R_Hand",
	["L Upperarm"] = "ValveBiped.Bip01_L_UpperArm",
	["L Forearm"] = "ValveBiped.Bip01_L_Forearm",
	["L Hand"] = "ValveBiped.Bip01_L_Hand",
	["R Thigh"] = "ValveBiped.Bip01_R_Thigh",
	["R Calf"] = "ValveBiped.Bip01_R_Calf",
	["R Foot"] = "ValveBiped.Bip01_R_Foot",
	["R Toes"] = "ValveBiped.Bip01_R_Toe0",
	["L Thigh"] = "ValveBiped.Bip01_L_Thigh",
	["L Calf"] = "ValveBiped.Bip01_L_Calf",
	["L Foot"] = "ValveBiped.Bip01_L_Foot",
	["L Toes"] = "ValveBiped.Bip01_L_Toe0",
}

snixzz.Hitboxes = {
	["Head"] = 0,	
	["L Upperarm"] = 1,
	["L Forearm"] = 2,
	["L Hand"] = 3,
	["R Upperarm"] = 4,
	["R Forearm"] = 5,
	["R Hand"] = 6,
	["L Thigh"] = 7,
	["L Calf"] = 8,
	["F Foot"] = 9,
	["L Toe"] = 10,
	["R Thigh"] = 11,
	["R Calf"] = 12,
	["R Foot"] = 13,
	["R Toe"] = 14,
	["Pelvis"] = 15,
	["Spine"] = 16,
}

snixzz.Hitgroups = {
	[HITGROUP_HEAD] = "Head",
	[HITGROUP_CHEST] = "Chest",
	[HITGROUP_STOMACH] = "Stomach",
	[HITGROUP_LEFTARM] = "Left Arm",
	[HITGROUP_RIGHTARM] = "Right Arm",
	[HITGROUP_LEFTLEG] = "Left Leg",
	[HITGROUP_RIGHTLEG] = "Right Leg",
}

function snixzz.GetPos( v )	
	if snixzz.Vars["aim_method"] == "Hitbox" then
	
		local Hitbox = v:GetHitBoxBone( snixzz.Hitboxes[snixzz.Vars["aim_hitbox"]], 0 )	
		local HitboxPos = v:GetBonePosition( Hitbox )
	
		local min, max = v:GetHitBoxBounds( snixzz.Hitboxes[snixzz.Vars["aim_hitbox"]], 0 )
		
		return HitboxPos + ( min + max ) / 2
		
	elseif snixzz.Vars["aim_method"] == "Bone" then
		local Bone = snixzz.Bones[snixzz.Vars["aim_bone"]]
		local BonePos = v:LookupBone( Bone )
		if BonePos then
			local pos, ang = v:GetBonePosition( BonePos )
			return pos, ang
		end
	end	
	return v:LocalToWorld( v:OBBCenter() )
end

function snixzz.InFov( v ) 
	-- wip
	return true
end

-- thanks asutorea
function snixzz.CanFire()
	local wep = G.LocalPlayer():GetActiveWeapon()
	if snixzz.properCurTime == nil then return false end
	return G.IsValid( wep ) && !snixzz.BadWeapons[wep:GetClass()] && wep:GetActivity() != ACT_RELOAD && wep:GetNextPrimaryFire() < snixzz.properCurTime && G.LocalPlayer():Alive()
end

-- pAntiAnti Aim
function snixzz.FixAngle( v )
	local eyeAngles = _R.Entity.EyeAngles( v )
	
	if eyeAngles.p < -89 then
		_R.Entity.SetPoseParameter( v, "aim_pitch", eyeAngles.p + 180 )
		_R.Entity.InvalidateBoneCache( v )
	elseif eyeAngles.p > 89 then
		_R.Entity.SetPoseParameter( v, "aim_pitch", eyeAngles.p - 180 )
		_R.Entity.InvalidateBoneCache( v )
	end
	
end

function snixzz.IsVisible( v )
	if snixzz.Bools["aim_antiantiaim"] then
		snixzz.FixAngle( v )
	end
	return snixzz.Functions.IsVisible( G.LocalPlayer():GetShootPos(), snixzz.GetPos( v ), v:EntIndex() )
end

function snixzz.OnScreen( v )
	local a, f = _R.Player.GetAimVector( G.LocalPlayer() ):Angle() - ( v:GetPos() - G.LocalPlayer():GetShootPos() ):Angle(), _R.Player.GetFOV( G.LocalPlayer() )     
	return ( G.math.NormalizeAngle( a.y ) < f + 2 && G.math.NormalizeAngle( a.p ) < f + 2 )
end

function snixzz.IsDormant( index )
	return snixzz.Functions.IsDormant( index )
end

function snixzz.FixMove( ucmd, aa )
	local fixAngle = G.Vector( ucmd:GetForwardMove(), ucmd:GetSideMove(), 0 )
	fixAngle = (( fixAngle:GetNormal() ):Angle() + ( ucmd:GetViewAngles() - G.Angle( 0, snixzz.Silent.y, 0 ) ) ):Forward() * fixAngle:Length()
	
	if aa then
		ucmd:SetForwardMove( fixAngle.x )
		ucmd:SetSideMove( fixAngle.y * -1 )
		return
	end
	
	ucmd:SetForwardMove( fixAngle.x )
	ucmd:SetSideMove( fixAngle.y )
end

function snixzz.NormalizeAngles( ang )
	ang.p = G.math.NormalizeAngle( ang.p )
	ang.y = G.math.NormalizeAngle( ang.y )
	ang.r = 0
	return ang
end

snixzz.PredPositions = {}
local tbl = snixzz.PredPositions[v] or {}

function snixzz.GetPredictionPos( v, pos )
	tbl.pos = tbl.pos or pos or _R.Entity.GetPos( v )
	
	local realTime = G.RealTime()
	if tbl.realTime != realTime then
		tbl.realTime = realTime
		tbl.pos = pos or _R.Entity.GetPos( v )
	end	
	
	tbl.velocity = v:GetVelocity()	
	snixzz.PredPositions = tbl	
	
	return tbl.pos
end

snixzz.PredictionMethods = { "Velocity 0.0075", "Engine Velocity", "Classic", "Herpes", "ColdFire", "FapHack" }
snixzz.PredWeapons = {
	["weapon_crossbow"] = 3110,
	["weapon_frag"] = 3110,
}
local tPos, lVelocity, tVelocity, tDistance, predTime
-- Some methods are BASED on other cheat's methods, I suck at prediction.
function snixzz.Prediction( Pos, v )

	local wep = G.LocalPlayer():GetActiveWeapon()
	lVelocity = _R.Entity.GetVelocity( G.LocalPlayer() )
	tVelocity = _R.Entity.GetVelocity( v )
	tPos = _R.Entity.GetPos( v )
	lPos = _R.Entity.GetPos( G.LocalPlayer() )
	tDistance = lPos:Distance( tPos )
	
	if G.IsValid( v ) && G.type( tVelocity ) == "Vector" && G.type( tPos ) == "Vector" then		

		if wep && G.IsValid( wep ) && snixzz.PredWeapons[wep:GetClass()] then		
			predTime = distance / snixzz.PredWeapons[wep:GetClass()]
			Pos = Pos + tVelocity * predTime			
		else		
		
			if snixzz.Vars["aim_prediction_method"] == "Velocity 0.0075" then
				Pos = Pos + lVelocity * 0.0075 + tVelocity * 0.0075
					
			elseif snixzz.Vars["aim_prediction_method"] == "Engine Velocity" then
				Pos = Pos + tVelocity * G.engine.TickInterval() - lVelocity * G.engine.TickInterval()
				
			elseif snixzz.Vars["aim_prediction_method"] == "Classic" then
				Pos = Pos + tVelocity / 45 - lVelocity / 45
			
			elseif snixzz.Vars["aim_prediction_method"] == "Herpes" then
				tPos = snixzz.GetPredictionPos( v, Pos ) - Pos
				Pos = Pos + ( tPos * 2 ) - ( lVelocity / 50 )
			
			elseif snixzz.Vars["aim_prediction_method"] == "ColdFire" then
				Pos = Pos - tVelocity:GetNormal() / 5.8 + lVelocity:GetNormal() / 3
				
			elseif snixzz.Vars["aim_prediction_method"] == "FapHack" then
				Pos = Pos + tVelocity * 0.02 - lVelocity * 0.05
				
			end			
		end
	
	else
		Pos = Pos
	end
	
	return Pos
end

function snixzz.GetTarget()
	
	local x, y = G.ScrW(), G.ScrH()
	local vPos
	local oldPos = G.LocalPlayer():EyePos():ToScreen()
	local distance = G.math.huge
	local AngA
	local AngB
	
	for k, v in G.next, G.player.GetAll() do

		vPos = v:GetPos():ToScreen()
		distance2 = v:GetPos():DistToSqr( G.LocalPlayer():GetPos() )
		AngA = G.math.Dist( x / 2, y / 2, oldPos.x, oldPos.y )
		AngB = G.math.Dist( x / 2, y / 2, vPos.x, vPos.y )
		
		if snixzz.IsValid( v ) then
		
			if snixzz.Vars["aim_target_method"] == "Distance" then
				if distance2 < distance then
					distance = distance2
					snixzz["Target"] = v
				end
				
			elseif snixzz.Vars["aim_target_method"] == "Crosshair" then
				if AngB <= AngA then
					snixzz.Target = v
				end
				
			end			
		else
			continue
		end
	end
	return snixzz["Target"]		
end

snixzz.Firing = false
function snixzz.Fire( ucmd )
	if snixzz.Firing then
		ucmd:RemoveKey( G.IN_ATTACK )
		snixzz.Firing = false
	else
		ucmd:SetButtons( G.bit.bor( ucmd:GetButtons(), G.IN_ATTACK ) )
		snixzz.Firing = true
	end
end

snixzz.FakeSwitch = false
snixzz.FakeAngle = G.Angle()
snixzz.AntiAimMethods = { "Classic", "Classic Inverted", "Static", "Jitter", "Random Pitch", "Fake Angles", "Fake Jitter", "Spin", "Fake Spin" }
function snixzz.AntiAim( ucmd )
	local pitches = { -181, 541, 262 }
	local yaws = { 262, -262, 181, -181, 541, -541 }
	
	-- OG anti-aim
	if snixzz.Vars["aim_anti_method"] == "Classic" then
		snixzz.Functions.SetViewAngles( ucmd, G.Angle( 181, ucmd:GetViewAngles().y, 180 ) )
		snixzz.FixMove( ucmd )
		
	-- Looking down instead of up
	elseif snixzz.Vars["aim_anti_method"] == "Classic Inverted" then
		snixzz.Functions.SetViewAngles( ucmd, G.Angle( -181, ucmd:GetViewAngles().y, 180 ) )
		snixzz.FixMove( ucmd )
		
	-- Static
	elseif snixzz.Vars["aim_anti_method"] == "Static" then
		snixzz.Functions.SetViewAngles( ucmd, G.Angle( -snixzz.Angles.p + 900, snixzz.Angles.y + 180, 0 ) )
		snixzz.FixMove( ucmd, true )
		
	-- Jitter - credits to cdriza
	elseif snixzz.Vars["aim_anti_method"] == "Jitter" then
		snixzz.Functions.SetViewAngles( ucmd, G.Angle( G.table.Random( pitches ), G.table.Random( yaws ), 0 ) )
		snixzz.FixMove( ucmd, true )
		
	-- Randomized pitch
	elseif snixzz.Vars["aim_anti_method"] == "Random Pitch" then
		snixzz.Functions.SetViewAngles( ucmd, G.Angle( G.math.random( -180, -186.49999 ), ucmd:GetViewAngles().y, 180 ) )
		snixzz.FixMove( ucmd, true )
		
	-- bSendPacket Fake Angles
	elseif snixzz.Vars["aim_anti_method"] == "Fake Angles" then
		snixzz.FakeAngle = ucmd:GetViewAngles()
		if snixzz.FakeSwitch then
			bSendPacket = true
			snixzz.Functions.SetViewAngles( ucmd, G.Angle( -192, snixzz.FakeAngle.y + 90, 0 ) )
		else
			bSendPacket = false			
			snixzz.Functions.SetViewAngles( ucmd, G.Angle( -192, snixzz.FakeAngle.y - 90, 0 ) )
		end
		snixzz.FixMove( ucmd, true )
		snixzz.FakeSwitch = !snixzz.FakeSwitch
	
	-- bSendPacket Fake Jitter
	elseif snixzz.Vars["aim_anti_method"] == "Fake Jitter" then
		snixzz.FakeAngle = ucmd:GetViewAngles()
		if snixzz.FakeSwitch then
			bSendPacket = true
			snixzz.Functions.SetViewAngles( ucmd, G.Angle( G.math.random( -180, -186.49999 ), snixzz.FakeAngle.y + 90, 0 ) )
		else
			bSendPacket = false			
			snixzz.Functions.SetViewAngles( ucmd, G.Angle( G.math.random( -180, -186.49999 ), snixzz.FakeAngle.y - 90, 0 ) )
		end
		snixzz.FixMove( ucmd, true )
		snixzz.FakeSwitch = !snixzz.FakeSwitch
		
	-- Simple spinbot with -192 pitch
	elseif snixzz.Vars["aim_anti_method"] == "Spin" then
		snixzz.Functions.SetViewAngles( ucmd, ucmd:GetViewAngles() + G.Angle( 0, G.math.fmod( G.CurTime() / .1 * 2 * snixzz.Vars["aim_anti_spin_speed"], 360 ), 0 ) )
		snixzz.FixMove( ucmd, false )
	
	-- bSendPacket Spinbot
	elseif snixzz.Vars["aim_anti_method"] == "Fake Spin" then
		snixzz.FakeAngle = ucmd:GetViewAngles()
		if FakeSwitch then
			bSendPacket = true			
			snixzz.Functions.SetViewAngles( ucmd, ucmd:GetViewAngles() + G.Angle( 0, G.math.fmod( G.CurTime() / .1 * 2 * snixzz.Vars["aim_anti_spin_speed"], 360 ), 0 ) )
		else
			bSendPacket = false
			snixzz.Functions.SetViewAngles( ucmd, ucmd:GetViewAngles() + G.Angle( 0, -G.math.fmod( G.CurTime() / .1 * 2 * snixzz.Vars["aim_anti_spin_speed"], 360 ), 0 ) )
		end
		snixzz.FixMove( ucmd, false )
	end
	
end

-- To shorten up my aimbot checks a bit.
function snixzz.ShouldAim( ucmd, isToggled )
	return snixzz.Target && snixzz.IsValid( snixzz.Target ) && ucmd:CommandNumber() != 0	
end

/*=======================


Hooked functions below


=========================*/
snixzz.Status = "Waiting..."
snixzz.StatusColor = Color( 255, 255, 0, 150 )
snixzz.Silent = G.Angle()
snixzz.BulletTime = true
snixzz.pDelay = 0
//snixzz.SpreadPos = G.Vector( 0, 0, 0 )

function snixzz.CreateMove( ucmd )

	snixzz.Target = snixzz.GetTarget()
	snixzz.Offset = G.Vector( 0, 0, snixzz.Vars["aim_offset"] )

	// Silent aim
	if snixzz.Bools["aim_silent"] then
		snixzz.Silent = snixzz.Silent + G.Angle( ucmd:GetMouseY() * 0.023, -ucmd:GetMouseX() * 0.023, 0 )
		snixzz.Silent.p = G.math.Clamp( snixzz.Silent.p, -89, 89 )
		if ucmd:CommandNumber() == 0 then
			ucmd:SetViewAngles( snixzz.Silent )
			return
		end		
		snixzz.Angles = snixzz.Silent
	else
		snixzz.Angles = ucmd:GetViewAngles()
	end
	
	// Aimbot core
	if ( G.input.IsKeyDown( snixzz.Binds["+aimbot"] ) && !snixzz.Typing && snixzz.ShouldAim( ucmd ) or snixzz.Bools["aim_toggle"] ) && snixzz.ShouldAim( ucmd ) then
		
		if snixzz.Bools["aim_prediction"] then
			snixzz.Angles = snixzz.Prediction( snixzz.GetPos( snixzz.Target ) - snixzz.Offset, snixzz.Target )
		else
			snixzz.Angles = snixzz.GetPos( snixzz.Target ) - snixzz.Offset
		end
			
		snixzz.Angles = ( snixzz.Angles - G.LocalPlayer():GetShootPos() ):GetNormal():Angle()
	
		-- Normalize that shit
		snixzz["NormalizeAngles"]( snixzz["Angles"] )
		
		-- View punch fix
		if snixzz.Bools["aim_norecoil"] then
			snixzz.CorrectRecoil( ucmd )
		end
			
		-- Spread Prediction
		if snixzz.Bools["aim_nospread"] then
			snixzz.SetAngle = snixzz.PredictSpread( ucmd, G.Angle( snixzz.Angles.p, snixzz.Angles.y, 0 ) )
		else
			snixzz.SetAngle = snixzz.Angles
		end

		if snixzz.Bools["aim_psilent"] then
		
			if G.LocalPlayer():Alive() && G.IsValid( G.LocalPlayer():GetActiveWeapon() ) then
			
				if G.LocalPlayer():GetActiveWeapon():GetNextPrimaryFire() >= snixzz.properCurTime then
					snixzz.BulletTime = false
				else
					snixzz.BulletTime = true
				end
				
				if ucmd:CommandNumber() == 0 then
					if snixzz.Vars["aim_psilent_method"] == "bSendPacket" then
						bSendPacket = true
					end
				else
					if snixzz.Vars["aim_psilent_method"] == "bSendPacket" then
						bSendPacket = false
					end
					snixzz.pDelay = snixzz.pDelay + 1
				end
			end
			
			if snixzz.BulletTime && !bSendPacket then
				if snixzz.pDelay >= 4 then
					snixzz.Functions.SetViewAngles( ucmd, snixzz.SetAngle )
					snixzz.pDelay = 0
				end
			end				
		else		
			snixzz.Functions.SetViewAngles( ucmd, snixzz.SetAngle )			
		end

		if snixzz.Bools["aim_autoshoot"] && snixzz.CanFire( ucmd ) then
			snixzz.Fire( ucmd )		
		end
		
		-- Silent aim view correction
		if snixzz.Bools["aim_silent"] then
			snixzz.FixMove( ucmd )
		end
			
		-- status bullshit
		snixzz.Status = "Locked! (" .. snixzz.Target:Nick() .. ")"
		snixzz.StatusColor = Color( 255, 0, 0, 150 )
		snixzz["Locked"] = true
							
	else
		-- More status bullshit, aimbot not active.
		snixzz.Status = "Searching..."
		snixzz.StatusColor = Color( 0, 255, 0, 150 )
		snixzz.Locked = false		
	end
	
	-- Triggerbot
	if snixzz.Bools["misc_triggerbot"] or G.input.IsKeyDown( snixzz.Binds["+triggerbot"] ) then
		snixzz.StatusColor = Color( 255, 255, 0, 150 )
		snixzz.Status = "Triggerbot Searching.."
		local hitgroup = G.LocalPlayer():GetEyeTrace().HitGroup
		local entity = G.LocalPlayer():GetEyeTrace().Entity
		snixzz.SpreadPos = G.LocalPlayer():GetEyeTrace().HitPos

		if snixzz.Vars["misc_triggerbot_method"] == "Body" then
			if snixzz.IsValid( entity ) then
								
				if snixzz.Bools["misc_triggerbot_nospread"] then
					snixzz.NoSpreadAng = ( snixzz.SpreadPos - G.LocalPlayer():GetShootPos() ):GetNormal():Angle()
					snixzz.NoSpreadAng = snixzz.PredictSpread( ucmd, snixzz.NoSpreadAng )
					snixzz.Functions.SetViewAngles( ucmd, snixzz.NoSpreadAng )
				end
				
				snixzz.StatusColor = Color( 255, 0, 0, 150 )
				snixzz.Status = "Firing! (" .. entity:Nick() .. ")"
				if snixzz.CanFire() then
					snixzz.Fire( ucmd )
				end
			end
			
		elseif snixzz.Vars["misc_triggerbot_method"] == "Hitbox" then
			if snixzz.Hitgroups[hitgroup] != nil && snixzz.IsValid( entity ) then
								
				if snixzz.Bools["misc_triggerbot_nospread"] then
					snixzz.NoSpreadAng = ( snixzz.SpreadPos - G.LocalPlayer():GetShootPos() ):GetNormal():Angle()
					snixzz.NoSpreadAng = snixzz.PredictSpread( ucmd, snixzz.NoSpreadAng )
					snixzz.Functions.SetViewAngles( ucmd, snixzz.NoSpreadAng )
				end
				
				snixzz.StatusColor = Color( 255, 0, 0, 150 )
				snixzz.Status = "Firing! (" .. entity:Nick() or hitbox .. ")"
				if snixzz.CanFire() then
					snixzz.Fire( ucmd ) 
				end
			end
		end
	end
		
	-- Anti-Aim
	if snixzz.Bools["aim_anti"] && !snixzz.Locked && !G.LocalPlayer():KeyDown( G.IN_ATTACK ) && G.LocalPlayer():GetMoveType() != G.MOVETYPE_LADDER then
		snixzz.AntiAim( ucmd )
	end
	
	if snixzz.Bools["misc_fakelag"] then
		snixzz.LagTicks = snixzz.LagTicks + 1
		
		if snixzz.LagTicks >= snixzz.Vars["misc_fakelag_rate"] then
			snixzz.ForceCvar( "host_timescale", 0 )
			snixzz.LagTicks = 0		
		else
			snixzz.ForceCvar( "host_timescale", 1 )
		end
		
	end
	
	// Bunnyhop & autostrafe
	if snixzz.Bools["misc_bhop"] then
		if !G.LocalPlayer():GetMoveType() != G.MOVETYPE_NOCLIP && G.LocalPlayer():GetMoveType() != MOVETYPE_LADDER && !snixzz.Typing then		
			if !G.LocalPlayer():IsOnGround() then				
				ucmd:SetButtons( G.bit.band( ucmd:GetButtons(), G.bit.bnot( G.IN_JUMP ) ) )
			end			
			if snixzz.Bools["misc_bhop_autostrafe"] then			
				if ucmd:GetMouseX() < 0 then
					ucmd:SetSideMove( -10000 )
				elseif ucmd:GetMouseX() > 0 then
					ucmd:SetSideMove( 10000 )
				end
			end		
		end		
	end
	
	-- SpeedHack (pSpeed method)
	if G.input.IsKeyDown( snixzz.Binds["+speedhack"] ) && !snixzz.Typing then
		if snixzz.Vars["speedhack_type"] == "pSpeed" then
			snixzz.Functions.SetSpeed( snixzz.Vars["speedhack_speed"] )
		elseif snixzz.Vars["speedhack_type"] == "Cvar" then
			snixzz.ForceCvar( "sv_cheats", 1 )
			snixzz.ForceCvar( "host_timescale", snixzz.Vars["speedhack_speed"] )
		end
	else
		if snixzz.Vars["speedhack_type"] == "pSpeed" then
			snixzz.Functions.SetSpeed( 0 )
		elseif snixzz.Vars["speedhack_type"] == "Cvar" then
			snixzz.ForceCvar( "sv_cheats", 0 )
			snixzz.ForceCvar( "host_timescale", 1 )
		end
	end
	
	// No hands
	if snixzz.Bools["esp_nohands"] then
		snixzz.Functions.NoDraw( G.Material( "models/weapons/v_models/hands/v_hands" ), true )
	else
		snixzz.Functions.NoDraw( G.Material( "models/weapons/v_models/hands/v_hands" ), false )
	end
	
end

function snixzz.CalcView( ply, origin, angles, fov )

	local ply = G.LocalPlayer()
	local wep = ply:GetActiveWeapon()
	local view = { ply = ply, origin = pos, angles = angles, fov = fov }
		
	// Advanced NoRecoil. TODO: Recoil Control System
	if snixzz.Bools["aim_norecoil"] then
		if wep.Primary then
			if !snixzz.RecoilBackup[wep:GetClass()] then
				snixzz.RecoilBackup[wep:GetClass()] = wep.Primary.Recoil
			end
			wep.Primary.Recoil = 0
		elseif wep.Secondary then
			if !snixzz.RecoilBackup then
				snixzz.RecoilBackup[wep:GetClass()] = wep.Secondary.Recoil
			end
			wep.Secondary.Recoil = 0
		end
	else
		if wep.Primary then
			if wep.Primary.Recoil == 0 then
				wep.Primary.Recoil = snixzz.RecoilBackup[wep:GetClass()]
			end
		else
			if wep.Secondary then
				if wep.Secondary.Recoil == 0 then
					wep.Secondary.Recoil = snixzz.RecoilBackup[wep:GetClass()]
				end
			end
		end
	end
	
	// Silent aim
	if snixzz.Bools["aim_silent"] then
		view.angles = snixzz.Silent
		view.vm_angles = snixzz.Silent
	else
		view.angles = G.LocalPlayer():EyeAngles()
		view.angles.r = 0
	end
	
	view.fov = snixzz.Vars["esp_fov"]
	
	if snixzz.Bools["misc_thirdperson"] then
		view.origin = G.LocalPlayer():GetShootPos() - snixzz.Silent:Forward() * snixzz.Vars["misc_thirdperson_distance"]
	else
		view.origin = origin
	end

	return view	
end

snixzz.LaserAttachments = { -- WIP
	["Barrel"] = "muzzle",
	["Iron Sights"] = "2",
	["fuk"] = "1",
}
function snixzz.HUDPaint()

	local vwep;
	local textpos;
	local x1, y1, x2, y2;
	local diff;
	local diff2;
	local color;
	local boxcolor;
	local startx;
	local starty;
	local endpos;
	local pos;
	local wep = G.LocalPlayer():GetActiveWeapon()
	local viewmodel = G.LocalPlayer():GetViewModel()		
	local weapon
	local dynLight
	
	-- Menu header
	if snixzz.MenuOpen then
		G.surface.SetDrawColor( snixzz.Vars["misc_menucolor2"] )
		G.surface.DrawRect( 20, 50, 420, 60 )
		
		G.surface.SetDrawColor( Color( 0, 0, 0, 255 ) )
		G.surface.DrawOutlinedRect( 20, 50, 420, 60, 2 )		

		G.draw.SimpleTextOutlined( "snixzz2", "snixzz_logo", 25, 55, snixzz.Colors.White, TEXT_ALIGN_LEFT,TEXT_ALIGN_LEFT, 1.5, Color( 0, 0, 0 ) )
		G.draw.SimpleTextOutlined( "by 0xymoron", "snixzz_logo_small", 95, 65, snixzz.Colors.White, TEXT_ALIGN_LEFT,TEXT_ALIGN_LEFT, 1, Color( 0, 0, 0 ) )
		
		-- Big ass shit
		G.draw.SimpleTextOutlined( 
			snixzz.Info.Version .. "   Last Updated: " .. snixzz.Info.Updated, 
			"snixzz_logo_small", 
			snixzz.Frame:GetWide() + 15, 65,
			snixzz.Colors.White, TEXT_ALIGN_RIGHT, TEXT_ALIGN_BOTTOM, 1, Color( 30, 30, 30, 255 ) 
		)
		
	end
	
	if !snixzz.Bools["esp_enabled"] then return end
	
	-- Laser Sight
	if snixzz.Bools["esp_laser"] then
					
		if viewmodel && G.IsValid( wep ) && G.IsValid( viewmodel ) then
			if wep:GetClass() != "weapon_physgun" then
						
				local muzzle = viewmodel:LookupAttachment( "muzzle" )
				if muzzle == 0 then
					muzzle = viewmodel:LookupAttachment( "1" )
				end
							
				local trace = G.LocalPlayer():GetEyeTrace().HitPos
							
				if viewmodel:GetAttachment( muzzle ) then						
					G.cam.Start3D( G.EyePos(), G.EyeAngles() )
									
						local startpos = viewmodel:GetAttachment( muzzle ).Pos						
						local endpos = trace	
									
						if snixzz.Bools["aim_silent"] && snixzz.Locked && G.IsValid( snixzz.Target ) then
							endpos = snixzz.GetPos( snixzz.Target )
						else
							endpos = trace
						end
									
						-- Laser
						G.render.SetMaterial( G.Material( "trails/laser" ) )													
						G.render.DrawBeam( startpos, endpos, 4, 0, 0, snixzz.Vars["misc_lasercolor"] )
								
						-- HitPos Dot
						G.render.SetMaterial( G.Material( "Sprites/light_glow02_add_noz" ) )
							G.render.DrawQuadEasy( 
							endpos, -- trace
							( G.EyePos() - trace ):GetNormal(), 
							25, 25, 
							Color( 255, 255, 255, 255 ), 0 
						)
								
					G.cam.End3D()
				end
			end
		end
	end
	
	-- Dynamic Light around player
	if snixzz.Bools["esp_dynamiclight"] then
		dynLight = G.DynamicLight( G.LocalPlayer():EntIndex() )
		dynLight.pos = G.LocalPlayer():GetShootPos()
		dynLight.r = 255
		dynLight.g = 255
		dynLight.b = 255
		dynLight.brightness = 1.75
		dynLight.Decay = 850
		dynLight.Size = 250
		dynLight.DieTime = G.CurTime() + 1
	end
	
	if snixzz.Bools["esp_wireweapon"] then
		_R.Entity.SetMaterial( viewmodel, "models/wireframe" )
		_R.Entity.SetColor( viewmodel, snixzz.Vars["misc_lasercolor"] )
	else
		_R.Entity.SetMaterial( viewmodel, "" )
		_R.Entity.SetColor( viewmodel, Color( 255, 255, 255 ) )
	end
			
	for k, v in G.next, G.player.GetAll() do
	
		textpos = 0 -- -2
		x1, y1, x2, y2 = snixzz.GetBounds( v )
		diff = G.math.abs( x2 - x1 )
		diff2 = G.math.abs( y2 - y1 )
		if G.IsValid( v:GetActiveWeapon() ) then
			weapon = v:GetActiveWeapon():GetPrintName()
		else
			weapon = "Unknown"
		end
		
		// Player esp	
		if snixzz.ShouldDraw( v ) then					
			color = G.team.GetColor( v:Team() )				
				
			// ESP text
			if snixzz.Bools["esp_name"] then
				G.draw.SimpleText( v:Nick(), "ESPFont", x2 + 2, y1 + textpos, color, TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT )
				textpos = textpos + 12
			end
				
			-- health text 
			if snixzz.Bools["esp_health_text"] then
				G.draw.SimpleText( "HP: " .. v:Health(), "ESPFont", x2 + 2, y1 + textpos, color, TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT )
				textpos = textpos + 12
			end
				
			-- ESP weapon
			if snixzz.Bools["esp_weapon"] then
				G.draw.SimpleText( weapon, "ESPFont", x2 + 2, y1 + textpos, color, TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT )
				textpos = textpos + 12
			end
			
			-- Distance ESP
			if snixzz.Bools["esp_distance"] then
				G.draw.SimpleText( "D: " .. G.math****und( v:GetPos():Distance( G.LocalPlayer():GetPos() ) ), "ESPFont", x2 + 2, y1 + textpos, color, TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT )
				textpos = textpos + 12
			end
				
			// Box ESP
			if snixzz.Bools["esp_box"] then
				snixzz.DrawOutlinedBox( x1, y1, diff, diff2, snixzz.Vars["esp_box_width"], color )
			end
							
			-- Health Bar
			if snixzz.Bools["esp_health_bar"] then
				
				G.surface.SetDrawColor( Color( 0, 0, 0 ) )
				G.surface.DrawRect( x1 -6, y1, 3, diff2 )
				G.surface.SetDrawColor( Color( 0, 255, 0 ) )
				G.surface.DrawRect( x1 - 6, y2 - diff2 / 100 * v:Health(), 3, diff2 / 100 * v:Health() )

			end
		
			-- Snaplines
			if snixzz.Bools["esp_snaplines"] then
				
				startx = G.ScrW() / 2
				starty = G.ScrH() / 2
				endpos = snixzz.GetPos( v ):ToScreen()
					
				G.surface.SetDrawColor( color )
				G.surface.DrawLine( startx, starty, endpos.x, endpos.y )
			end
				
			-- Chams! Much faster than RenderScreenSpaceEffects
			if snixzz.Bools["esp_chams"] then
				G.cam.Start3D()
					
					v:SetColor( color )
						
					if snixzz.Vars["esp_chams_material"] == "Solid" then
						v:SetMaterial( "models/debug/debugwhite" )
					elseif snixzz.Vars["esp_chams_material"] == "Wireframe" then
						v:SetMaterial( "models/wireframe" )
					elseif snixzz.Vars["esp_chams_material"] == "XQZ" then
						v:SetMaterial( "" )
					end
						
					-- Weapon Chams
					if G.IsValid( v:GetActiveWeapon() ) then
						v:GetActiveWeapon():DrawModel()
					end
						
					-- Player chams
					if snixzz.Vars["esp_chams_material"] != "XQZ" then
						G.render.SetColorModulation( color.r / 255, color.g / 255, color.b / 255 )
					end
					v:DrawModel()	
					v:SetColor( Color( 255, 255, 255 ) )	
					v:SetMaterial( "" )

				G.cam.End3D()
			end
									
			-- For prediction testing & shit
			if snixzz.Bools["esp_aimpos"] then
				local predictedPos = snixzz.Prediction( snixzz.GetPos( v ), v ):ToScreen()
				G.draw****undedBox( 4, predictedPos.x, predictedPos.y, 7, 7, Color( 255, 0, 0, 255 ) )
			end
			
		else
			continue;
		end	
	
	end

	// Aim status & shit
	if snixzz.Bools["esp_status"] then
		G.draw.DrawText( snixzz.Status, "snixzz_status", G.ScrW() / 2, G.ScrH() * 0.5 + 50, snixzz.StatusColor, TEXT_ALIGN_CENTER )
	end
	
	// Crosshair
	local x = ScrW() / 2
	local y = ScrH() / 2
	
	local crosscolor = Color( 0, 0, 0, 255 )
	local crosslength = 50
	local gap = 2
	
	local boxsize = 5
		
	-- Box
	if snixzz.Bools["esp_crosshair_box"] then
		G.surface.SetDrawColor( Color( 255, 255, 255 ) )
		G.surface.DrawOutlinedRect( x - boxsize - 2, y - boxsize - 2, ( boxsize + 2 ) * 2 + 1, ( boxsize + 2 ) * 2 + 1 )
	end
	
	-- Crosshair
	if snixzz.Bools["esp_crosshair"] then
		G.surface.SetDrawColor( 0, 0, 0, 255 )
		G.surface.DrawLine( x - crosslength, y, x - gap, y )
		G.surface.DrawLine( x + crosslength, y, x + gap, y )
		
		G.surface.DrawLine( x, y - crosslength, x, y - gap )
		G.surface.DrawLine( x, y + crosslength, x, y + gap )
	end
end

snixzz.properCurTime = 0
snixzz.LagVar = 12
snixzz.LagTicks = 0
local dynLight
function snixzz.Move()

	if G.IsFirstTimePredicted() then return end
	snixzz.properCurTime = G.CurTime() + G.engine.TickInterval()
	
	-- Menu opening
	if ( G.input.IsKeyDown( snixzz.Binds["+menu"] ) && !snixzz.Typing && !snixzz.MenuOpen && !gui.IsConsoleVisible() ) then
		snixzz.Menu()
		snixzz.MenuOpen = true
	end
			
end

function snixzz.Namechanger()
	if snixzz.Bools["misc_namechanger"] then
		snixzz.NextName = G.table.Random( G.player.GetAll() ):Nick()
		G.chat.AddText( Color( 0, 255, 255 ), "[snixzz2] Changed your name to " .. snixzz.NextName ) 
		if G.string.find( G.string.lower( G.GAMEMODE.Name ), "rp" ) or G.string.find( G.string.lower( GAMEMODE.Name ), "purge" ) then
			-- Overly comlpicated Steam name stealer & RP name stealer. Accuse 2 different people at once.
			snixzz.NextName = G.table.Random( G.player.GetAll() ):Nick()
			snixzz.Functions.ConCommand( "name " .. snixzz.NextName .. " %" )
			G.timer.Simple( 0.5, function()
				snixzz.NextName = G.table.Random( G.player.GetAll() ):Nick()
				snixzz.Functions.ConCommand( "darkrp rpname " .. snixzz.NextName .. "q" ) -- ** TODO: CHANGE q TO SOMETHING ELSE.
			end )
		else
			snixzz.NextName = G.table.Random( G.player.GetAll() ):Nick()
			snixzz.Functions.ConCommand( "name " .. snixzz.NextName .. " %" )
		end
	end
end
if G.string.find( G.string.lower( G.GAMEMODE.Name ), "rp" ) or G.string.find( G.string.lower( G.GAMEMODE.Name ), "purge" ) then
	snixzz.RegisterTimer( 10, 0, snixzz.Namechanger )
else
	snixzz.RegisterTimer( G.GetConVarNumber( "sv_namechange_cooldown_seconds" ), 0, snixzz.Namechanger )
end

/*
	DETOURS
*/

_R.Entity.FireBullets = snixzz.Detour( _R.Entity.FireBullets, function( e, bullet )
	snixzz.Cones.Normal[ G.LocalPlayer():GetActiveWeapon():GetClass() ] = bullet["Spread"]
	return snixzz.Detours[ _R.Entity.FireBullets ]( e, bullet )
end )

_R.Player.IPAddress = snixzz.Detour( _R.Player.IPAddress, function()
	snixzz.FakeIP = G.tostring( G.math.random( 1, 99 ), G.math.random( 1, 99 ), G.math.random( 1, 99 ), G.math.random( 1, 99 ), ":27005" )
	snixzz.ACNotify( "Server tried to get _R.Player.IPAddress, returning '" .. snixzz.FakeIP .. "'" )
	snixzz.logEvent( "anticheat", "Tried getting player:IPAddress(), returnin fake IP '" .. snixzz.FakeIP .. "'" )
	return snixzz.FakeIP
end )

_R.Entity.SetHands = snixzz.Detour( _R.Entity.SetHands, function( ent )
	if snixzz.Bools["esp_nohands"] then 
		return
	else
		return ent
	end
end )

_R.Player.GetHands = snixzz.Detour( _R.Player.GetHands, function()
	if snixzz.Bools["esp_nohands"] then
		return false
	else
		return true
	end
end )

render.Capture = snixzz.Detour( render.Capture, function( data )
	snixzz.ACNotify( "An anti-cheat attempted to capture your screen." )
	return -- no.
end )

file.Exists = snixzz.Detour( file.Exists, function( filename, dir )
	snixzz.LogDetour( "file.Exists( '" .. filename .. "', '" .. dir .. "' )" )
	if G.string.find( filename, "snixzz" ) then
		snixzz.ACNotify( "An anti-cheat attempted to search for snixzz" )
		return false
	else
		return snixzz.Detours[ file.Exists ]( filename, dir )
	end
end )

file.Read = snixzz.Detour( file.Read, function( filename, dir )
	snixzz.LogDetour( "file.Read( '" .. filename .. "', '" .. dir .. "' )" )
	if G.string.find( filename, "snixzz" ) then
		snixzz.ACNotify( "An anti-cheat attempted to search for snixzz" )
		return "print( 'Hello World' )"
	else
		return snixzz.Detours[ file.Read ]( filename, dir )
	end
end )

snixzz.FakeFiles = {
	"demo_recording.lua",
	"vgui/dbutton.lua",
	"vgui/dgrid.lua",
	"menu/menu.lua",
	"menu/mainmenu.lua",
	"menu/loading.lua",
	"menu/video.lua",
	"menu/errors.lua",
}

file.Find = snixzz.Detour( file.Find, function( filename, dir )
	snixzz.LogDetour( "file.Find( '" .. filename .. "', '" .. dir .. "' )" )
	if G.string.find( filename, "snixzz" ) then 
		return G.table.Random( snixzz.FakeFiles ) -- lol fuck you
	else
		return snixzz.Detours[ file.Find ]( filename, dir )
	end
end )	

net.Receive = snixzz.Detour( net.Receive, function( name, func )
	snixzz.LogDetour( "net.Receive( '" .. name .. "' )" )
	return snixzz.Detours[ net.Receive ]( name, func )
end )

net.Start = snixzz.Detour( net.Start, function( name )
	if snixzz.Detours["net.Start"][name] then
		snixzz.ACNotify( "Blocked net.Start ( '" .. name .. "' )" )
		return
	else
		snixzz.LogDetour( "net.Start( '" .. name .. "' )" )
		return snixzz.Detours[ net.Start ]( name )
	end
end )

net.WriteString = snixzz.Detour( net.WriteString, function( str )
	if G.string.find( str, "snixzz" ) then
		snixzz.ACNotify( "Blocked net.WriteString ( '" .. str .. "' )" )
		return "nil"
	else
		snixzz.LogDetour( "net.WriteString( " .. str .. " )" )
		return snixzz.Detours[ net.WriteString ]( str )
	end
end )

_R.Player.ConCommand = snixzz.Detour( _R.Player.ConCommand, function( ply, args )
	snixzz.LogDetour( ply:Nick() .. " - _R.Player.ConCommand( '" .. args .. "' ) " )
	return snixzz.Detours[ _R.Player.ConCommand ]( ply, args )
end )

/*
_R.ConVar.GetBool = snixzz.Detour( _R.Convar.GetBool, function( cvar )
	snixzz.LogDetour( "_R.ConVar.GetBool( '" .. cvar:GetName() .. "'" )
	for k, v in G.pairs( snixzz.Spoof ) do
		if cvar:GetName() == k then
			snixzz.ACNotify( "_R.ConVar.GetBool( '" .. cvar:GetName() .. "' ) returning " .. G.tostring( v ) )
			return v
		else
			return snixzz.Detours[_R.ConVar.GetBool]( cvar )
		end
	end
end )*/

GetConVarNumber = snixzz.Detour( GetConVarNumber, function( cvar )
	if snixzz.Spoof[cvar] != nil then
		return snixzz.Spoof[cvar]
	else
		return snixzz.Detours[GetConVarNumber]( cvar )
	end
end )

snixzz.IgnoreCMDs = {
	["hvh_playheadshotsound"] = true,
	["hvh_hitsound"] = true,
	["r_cleardecals"] = true,
	["ulx_showmotd"] = true,
}
RunConsoleCommand = snixzz.Detour( RunConsoleCommand, function( cmd, ... )
	local str = cmd
	if !snixzz.IgnoreCMDs[cmd] then	
		if ... then
			local args = { ... }
			str = str .. ", " .. ( ... )
			
			snixzz.LogDetour( "RunConsoleCommand( '" .. cmd .. "' {" .. G.table.concat( args, ", " ) .. "} )" )
		else		
			snixzz.LogDetour( "RunConsoleCommand( '" .. cmd .. "' )")
		end
	end
	return snixzz.Detours[ RunConsoleCommand ]( cmd, ... )
end )

snixzz.FakeHooks = {
	["HUDPaint"] = "Bypassing my own anti-cheat", -- idk
}

hook.GetTable = snixzz.Detour( hook.GetTable, function()
	snixzz.LogDetour( "hook.GetTable() was checked, returning bullshit." )
	return snixzz.FakeHooks
end )

/*
	
	Menu Core
	
*/

snixzz.UpdateLog = "Loading.."

function snixzz.UpdateChangelog()
	G.http.Fetch( "https://162.248.94.135/snixzz2_changelog.txt", -- dirscan me please
		function( body, len, headers, code )
			snixzz.UpdateLog = body
			snixzz.logEvent( "Main", "Updated Changelog" )
		end,
		function( error )
			snixzz.UpdateLog = error
			snixzz.logEvent( "Main", "Failed to update changelog '" .. error .. "'" )
		end
	)
end

snixzz.UpdateChangelog()

function snixzz.CMenu()

	snixzz.CFrame = G****ui.Create( "DFrame" )
	snixzz.CFrame:SetParent( CFrame )
	snixzz.CFrame:SetPos( 20, 80 )
	snixzz.CFrame:SetSize( 430, 420 )
	snixzz.CFrame:SetTitle( "snixzz2 " .. snixzz.Info.Version .. " Changelog" )
	snixzz.CFrame:SetVisible( true )
	snixzz.CFrame:SetDraggable( true )
	snixzz.CFrame:ShowCloseButton( true )
	snixzz.CFrame:MakePopup()
	snixzz.CFrame.Paint = function() 
		G.draw****undedBox( 0, 0, 0, snixzz.CFrame:GetWide(), snixzz.CFrame:GetTall(), snixzz.Vars["misc_menucolor"] ) -- 30
		G.surface.SetDrawColor( Color( 0, 0, 0 ) )
		G.surface.DrawOutlinedRect( 0, 0, snixzz.CFrame:GetWide(), snixzz.CFrame:GetTall() )
	end
	
	local ChangelogText = G****ui.Create( "DTextEntry", snixzz.CFrame )
	ChangelogText:SetPos( 5, 35 )
	ChangelogText:SetSize( snixzz.CFrame:GetWide() - 10, snixzz.CFrame:GetTall() - 40 )
	ChangelogText:SetText( snixzz.UpdateLog )
	ChangelogText:SetEditable( false )
	ChangelogText:SetMultiline( true )
	
end
	

snixzz.MenuToggle = false

function snixzz.DoMenuToggle()
	snixzz.MenuOpen = true
	snixzz.Frame:SetVisible( true )
end

function snixzz.Menu()
	local tabs, menuheight, menuwidth, w, h = {}, 430, 420, ScrW() / 2, ScrH() / 2
	
	snixzz.Frame = G****ui.Create( "DPropertySheet" )
	snixzz.Frame:SetParent( snixzz.Frame )
	snixzz.Frame:SetPos( 20, 80 )
	snixzz.Frame:SetSize( menuwidth, menuheight )
	snixzz.Frame:SetVisible( true )
	snixzz.Frame:MakePopup()
	snixzz.Frame.Think = function()
		if !G.input.IsKeyDown( snixzz.Binds["+menu"] ) && !snixzz.MenuToggle then
			snixzz.MenuOpen = false
			snixzz.Changelog:SetVisible( false )
			snixzz.Frame:SetVisible( false )
		end
	end	
	snixzz.Frame.Paint = function() 
		G.draw****undedBox( 0, 0, 30, snixzz.Frame:GetWide(), snixzz.Frame:GetTall(), snixzz.Vars["misc_menucolor"] )
		G.surface.SetDrawColor( Color( 0, 0, 0 ) )
		G.surface.DrawOutlinedRect( 0, 0, snixzz.Frame:GetWide(), snixzz.Frame:GetTall() )
	end
	
	-- Menu Toggle button
	local Toggle = G****ui.Create( "DButton" )
	Toggle:SetParent( snixzz.Frame )
	Toggle:SetText( "Hold Open" )
	Toggle:SetTextColor( snixzz.Colors.Green )
	Toggle:SetPos( 0, 0 )
	Toggle:SetPos( snixzz.Frame:GetWide() - 60, 0 )
	Toggle:SetSize( 60, 30 )
	Toggle.DoClick = function()
		snixzz.MenuToggle = !snixzz.MenuToggle
		snixzz.DoMenuToggle()
		if snixzz.MenuToggle == true then
			Toggle:SetText( "Close" )
			Toggle:SetTextColor( Color( 255, 255, 0 ) )
			snixzz.Sound()
		else
			Toggle:SetText( "Hold Open" )
			Toggle:SetTextColor( snixzz.Colors.Green )
			snixzz.Sound()
		end
	end
	Toggle.Paint = function() 
		G.surface.SetDrawColor( Color( 0, 0, 0 ) )
		G.surface.DrawOutlinedRect( 0, 0, Toggle:GetWide(), Toggle:GetTall() )
	end
	
	snixzz.Changelog = G****ui.Create( "DButton" )
	--Changelog:SetParent( snixzz.Frame )
	snixzz.Changelog:SetText( "Changelog" )
	snixzz.Changelog:SetTextColor( color_white )
	snixzz.Changelog:SetPos( snixzz.Frame:GetWide() - 240, 60 )
	--snixzz.Changelog:SetPos( snixzz.Frame:GetWide() - 60, 0 )
	snixzz.Changelog:SetSize( 70, 18 )
	snixzz.Changelog:SetFont( "snixzz_logo_small" )
	snixzz.Changelog.DoClick = function()
		snixzz.Sound()
		snixzz.UpdateChangelog()
		snixzz.CMenu()
	end
	snixzz.Changelog.Paint = function() 
		G.surface.SetDrawColor( Color( 0, 0, 0 ) )
		G.surface.DrawOutlinedRect( 0, 0, snixzz.Changelog:GetWide(), snixzz.Changelog:GetTall() )
	end

	-- Parents for the tabs
	tabs.aimbot = G****ui.Create( "DLabel", snixzz.Frame )
	tabs.aimbot:SetPos( 0, 0 )
	tabs.aimbot:SetText( "" )

	tabs.esp = G****ui.Create( "DLabel", snixzz.Frame )
	tabs.esp:SetPos( 0, 0 )
	tabs.esp:SetText( "" )

	tabs.misc = G****ui.Create( "DLabel", snixzz.Frame )
	tabs.misc:SetPos( 0, 0 )
	tabs.misc:SetText( "" )
	
	tabs.lists = G****ui.Create( "DLabel", snixzz.Frame )
	tabs.lists:SetPos( 0, 0 )
	tabs.lists:SetText( "" )

	tabs.console = G****ui.Create( "DLabel", snixzz.Frame )
	tabs.console:SetPos( 0, 0 )
	tabs.console:SetText( "" )

	tabs.config = G****ui.Create( "DLabel", snixzz.Frame )
	tabs.config:SetPos( 0, 0 )
	tabs.config:SetText( "" )
	
	snixzz.Frame:AddSheet( "Aimbot", tabs.aimbot, "icon16/lightning.png", false, false )
	snixzz.Frame:AddSheet( "Visual", tabs.esp, "icon16/eye.png", false, false )
	snixzz.Frame:AddSheet( "Misc", tabs.misc, "icon16/plugin.png", false, false )
	snixzz.Frame:AddSheet( "Lists", tabs.lists, "icon16/user_add.png", false, false )
	snixzz.Frame:AddSheet( "Console", tabs.console, "icon16/application_xp_terminal.png", false, false )
	snixzz.Frame:AddSheet( "Config", tabs.config, "icon16/wrench.png", false, false )

	-- Aimbot Settings
	snixzz.CreateOption( "Checkbox", tabs.aimbot, "Aimbot Toggle", "aim_toggle", 5, 5 )
	snixzz.CreateOption( "Checkbox", tabs.aimbot, "Autoshoot", "aim_autoshoot", 5, 25 )
	snixzz.CreateOption( "Checkbox", tabs.aimbot, "Silent Aim", "aim_silent", 5, 45 )
	snixzz.CreateOption( "Checkbox", tabs.aimbot, "pSilent [Beta]", "aim_psilent", 5, 65 )
	snixzz.CreateOption( "Checkbox", tabs.aimbot, "Spread Prediction", "aim_nospread", 5, 85 )
	snixzz.CreateOption( "Checkbox", tabs.aimbot, "Aim Prediction", "aim_prediction", 5, 105 )
	snixzz.CreateOption( "Checkbox", tabs.aimbot, "Remove Recoil", "aim_norecoil", 5, 125 )
	snixzz.CreateOption( "Checkbox", tabs.aimbot, "Check FOV", "aim_checkfov", 5, 145 )	
	
	snixzz.CreateOption( "Checkbox", tabs.aimbot, "Ignore Team", "aim_ignoreteam", 130, 5 )
	snixzz.CreateOption( "Checkbox", tabs.aimbot, "Ignore Admins", "aim_ignoreadmins", 130, 25 )
	snixzz.CreateOption( "Checkbox", tabs.aimbot, "Ignore Steam Friends", "aim_ignoresteam", 130, 45 )
	snixzz.CreateOption( "Checkbox", tabs.aimbot, "Ignore Bots", "aim_ignorebots", 130, 65 )
	snixzz.CreateOption( "Checkbox", tabs.aimbot, "Ignore LOS", "aim_ignorelos", 130, 85 )
	snixzz.CreateOption( "Checkbox", tabs.aimbot, "Ignore Friends", "aim_ignorefriends", 130, 105 )
	
	snixzz.CreateOption( "Checkbox", tabs.aimbot, "Anti Anti-Aim", "aim_antiantiaim", 275, 5 )
	snixzz.CreateOption( "Checkbox", tabs.aimbot, "Anti-Aim", "aim_anti", 275, 25 )

	snixzz.CreateOption( "Slider", tabs.aimbot, "Spinbot Speed", "aim_anti_spin_speed", 10, 50, 420, 5, 325, 0 )
	snixzz.CreateOption( "Slider", tabs.aimbot, "Field of View", "aim_fov", 1, 180, 420, 5, 345, 0 )
	snixzz.CreateOption( "Slider", tabs.aimbot, "Aimspot Offset", "aim_offset", -20, 20, 425, 5, 365, 0 )
	
	
	snixzz.CreateOption( "Label", tabs.aimbot, "Prediction Method", 115, 250 )
	local PredictionMethod = G****ui.Create( "DComboBox", tabs.aimbot )
	PredictionMethod:SetPos( 115, 265 )
	PredictionMethod:SetSize( 105, 20 )
	PredictionMethod:SetText( snixzz.Vars["aim_prediction_method"] )
	PredictionMethod:SetTextColor( color_white )
	for k, v in G.next, snixzz.PredictionMethods do
		PredictionMethod:AddChoice( v )
	end
	PredictionMethod.OnSelect = function( self )
		snixzz.Vars["aim_prediction_method"] = self:GetValue()
		snixzz.Message( Color( 0, 255, 255 ), "Set prediction method to '" .. self:GetValue() .. "'" )
		snixzz.logEvent( "Setting", "Set prediction method to '" .. self:GetValue() .. "'" )
		snixzz.Sound()
	end	
	PredictionMethod.Paint = function() 
		G.surface.SetDrawColor( Color( 0, 0, 0 ) )
		G.surface.DrawOutlinedRect( 0, 0, PredictionMethod:GetWide(), PredictionMethod:GetTall() )
	end
	
	// AntiAim Method
	snixzz.CreateOption( "Label", tabs.aimbot, "Anti-Aim Method", 5, 250 )
	local AntiAimMethod = G****ui.Create( "DComboBox", tabs.aimbot )
	AntiAimMethod:SetPos( 5, 265 )
	AntiAimMethod:SetSize( 105, 20 )
	AntiAimMethod:SetText( snixzz.Vars["aim_anti_method"] )
	AntiAimMethod:SetTextColor( color_white )
	for k, v in G.next, snixzz.AntiAimMethods do
		AntiAimMethod:AddChoice( v )
	end
	AntiAimMethod.OnSelect = function( self )
		snixzz.Vars["aim_anti_method"] = self:GetValue()
		snixzz.Message( Color( 0, 255, 255 ), "Set anti-aim method to '" .. self:GetValue() .. "'" )
		snixzz.logEvent( "Setting", "Set anti-aim method to '" .. self:GetValue() .. "'" )
		snixzz.Sound()
	end		
	AntiAimMethod.Paint = function() 
		G.surface.SetDrawColor( Color( 0, 0, 0 ) )
		G.surface.DrawOutlinedRect( 0, 0, AntiAimMethod:GetWide(), AntiAimMethod:GetTall() )
	end

	-- Aimbot hitbox/bone method & spot selection
	snixzz.CreateOption( "Label", tabs.aimbot, "Aimbot Method", 5, 290 )
	local AimbotMethod = G****ui.Create( "DComboBox", tabs.aimbot )
	AimbotMethod:SetPos( 5, 305 )
	AimbotMethod:SetSize( 105, 20 )
	AimbotMethod:SetText( snixzz.Vars["aim_method"] )
	AimbotMethod:AddChoice( "Hitbox" )
	AimbotMethod:AddChoice( "Bone" )
	AimbotMethod:SetTextColor( color_white )
	AimbotMethod.OnSelect = function( self )
		snixzz.Vars["aim_method"] = self:GetValue()
		snixzz.Message( Color( 0, 255, 255 ), "Set aimbot method to '" .. self:GetValue() .. "'" )
		snixzz.logEvent( "Setting", "Set aimbot method to '" .. self:GetValue() .. "'" )
		snixzz.Sound()
		 -- Close to menu to avoid bugs.
		snixzz.Frame:SetVisible( false )
		snixzz.Changelog:SetVisible( false )
		snixzz.MenuOpen = false
		snixzz.MenuToggle = false
	end
	AimbotMethod.Paint = function() 
		G.surface.SetDrawColor( Color( 0, 0, 0 ) )
		G.surface.DrawOutlinedRect( 0, 0, AimbotMethod:GetWide(), AimbotMethod:GetTall() )
	end
	
	-- SPOT SELECTION. I AM PROUD OF THIS!
	snixzz.CreateOption( "Label", tabs.aimbot, "Aim Spot", 115, 290 )
	local Aimspot = G****ui.Create( "DComboBox", tabs.aimbot )
	Aimspot:SetPos( 115, 305 )
	Aimspot:SetSize( 105, 20 )
	Aimspot:SetTextColor( color_white )
	if snixzz.Vars["aim_method"] == "Hitbox" then
		Aimspot:SetText( snixzz.Vars["aim_hitbox"] )
	elseif snixzz.Vars["aim_method"] == "Bone" then
		Aimspot:SetText( snixzz.Vars["aim_bone"] )
	end
	if snixzz.Vars["aim_method"] == "Hitbox" then
		for k, v in G.next, snixzz.Hitboxes do
			Aimspot:AddChoice( k )
		end
	elseif snixzz.Vars["aim_method"] == "Bone" then
		for k, v in G.next, snixzz.Bones do
			Aimspot:AddChoice( k )
		end
	end
	Aimspot.OnSelect = function( self )
		if snixzz.Vars["aim_method"] == "Hitbox" then
			snixzz.Vars["aim_hitbox"] = self:GetValue()
			snixzz.Message( Color( 0, 255, 255 ), "Set aimbot hitbox to '" .. self:GetValue() .. "'" )
			snixzz.logEvent( "Setting", "Set aimbot hitbox to '" .. self:GetValue() .. "'" )
		elseif snixzz.Vars["aim_method"] == "Bone" then
			snixzz.Vars["aim_bone"] = self:GetValue()
			snixzz.Message( Color( 0, 255, 255 ), "Set aimbot bone to '" .. self:GetValue() .. "'" )
			snixzz.logEvent( "Setting", "Set aimbot bone to '" .. self:GetValue() .. "'" )
		end
		snixzz.Sound()
	end
	Aimspot.Paint = function() 
		G.surface.SetDrawColor( Color( 0, 0, 0 ) )
		G.surface.DrawOutlinedRect( 0, 0, Aimspot:GetWide(), Aimspot:GetTall() )
	end
	
	// Target method
	snixzz.CreateOption( "Label", tabs.aimbot, "Target Method", 225, 290 )
	local TargetMethod = G****ui.Create( "DComboBox", tabs.aimbot )
	TargetMethod:SetPos( 225, 305 )
	TargetMethod:SetSize( 105, 20 )
	TargetMethod:SetText( snixzz.Vars["aim_target_method"] )
	TargetMethod:SetTextColor( color_white )
	TargetMethod:AddChoice( "Distance" )
	TargetMethod:AddChoice( "Crosshair" )
	TargetMethod.OnSelect = function( self )
		snixzz.Vars["aim_target_method"] = self:GetValue()
		snixzz.Message( Color( 0, 255, 255 ), "Set target method to '" .. self:GetValue() .. "'" )
		snixzz.logEvent( "Setting", "Set target method to '" .. self:GetValue() .. "'" )
		snixzz.Sound()
	end	
	TargetMethod.Paint = function() 
		G.surface.SetDrawColor( Color( 0, 0, 0 ) )
		G.surface.DrawOutlinedRect( 0, 0, TargetMethod:GetWide(), TargetMethod:GetTall() )
	end

	-- Visual Settings
	snixzz.CreateOption( "Checkbox", tabs.esp, "Enable Visuals", "esp_enabled", 5, 5 )
	snixzz.CreateOption( "Checkbox", tabs.esp, "Player Name", "esp_name", 5, 45 )
	snixzz.CreateOption( "Checkbox", tabs.esp, "Player Health", "esp_health_text", 5, 65 )
	snixzz.CreateOption( "Checkbox", tabs.esp, "Player Weapon", "esp_weapon", 5, 85 )
	snixzz.CreateOption( "Checkbox", tabs.esp, "Player Distance", "esp_distance", 5, 105 )
	snixzz.CreateOption( "Checkbox", tabs.esp, "Player Box", "esp_box", 5, 125 )
	snixzz.CreateOption( "Checkbox", tabs.esp, "Player Chams", "esp_chams", 5, 145 )
	snixzz.CreateOption( "Checkbox", tabs.esp, "Health Bar", "esp_health_bar", 5, 165 )

	snixzz.CreateOption( "Checkbox", tabs.esp, "Crosshair", "esp_crosshair", 130, 5 )
	snixzz.CreateOption( "Checkbox", tabs.esp, "Crosshair Box", "esp_crosshair_box", 130, 25 )
	snixzz.CreateOption( "Checkbox", tabs.esp, "Remove Hands", "esp_nohands", 130, 45 )
	snixzz.CreateOption( "Checkbox", tabs.esp, "Aimbot Status", "esp_status", 130, 65 )
	snixzz.CreateOption( "Checkbox", tabs.esp, "Laser Sights", "esp_laser", 130, 85 )
	snixzz.CreateOption( "Checkbox", tabs.esp, "Aim Snaplines", "esp_snaplines", 130, 105 )
	snixzz.CreateOption( "Checkbox", tabs.esp, "Dynamic Light", "esp_dynamiclight", 130, 125 )
	snixzz.CreateOption( "Checkbox", tabs.esp, "Wireframe Weapon", "esp_wireweapon", 130, 145 )
	snixzz.CreateOption( "Checkbox", tabs.esp, "Draw Aimbot Position", "esp_aimpos", 130, 165 )	

	snixzz.CreateOption( "Slider", tabs.esp, "Field of View", "esp_fov", 90, 140, 420, 5, 325, 1 )
	snixzz.CreateOption( "Slider", tabs.esp, "Box Width", "esp_box_width", 1, 2.5, 420, 5, 345, 1 )
	snixzz.CreateOption( "Slider", tabs.esp, "Render Distance", "esp_distance", 0, 7500, 415, 5, 365, 0 )

	
	snixzz.CreateOption( "Label", tabs.esp, "Chams Material", 5, 290 )
	local ChamsType = G****ui.Create( "DComboBox", tabs.esp )
	ChamsType:SetPos( 5, 305 )
	ChamsType:SetSize( 105, 20 )
	ChamsType:SetText( snixzz.Vars["esp_chams_material"] )
	ChamsType:AddChoice( "Solid" )
	ChamsType:AddChoice( "Wireframe" )
	ChamsType:AddChoice( "XQZ" )
	ChamsType:SetTextColor( color_white )
	ChamsType.OnSelect = function( self )
		snixzz.Vars["esp_chams_material"] = self:GetValue()
		snixzz.Message( Color( 0, 255, 255 ), "Set chams material to '" .. self:GetValue() .. "'" )
		snixzz.logEvent( "Setting", "Set chams material to '" .. self:GetValue() .. "'" )
		snixzz.Sound()
	end
	ChamsType.Paint = function() 
		G.surface.SetDrawColor( Color( 0, 0, 0 ) )
		G.surface.DrawOutlinedRect( 0, 0, ChamsType:GetWide(), ChamsType:GetTall() )
	end
	
	--------------
	-- Misc tab --
	--------------
	snixzz.CreateOption( "Checkbox", tabs.misc, "Bunnyhop", "misc_bhop", 5, 5 )
	snixzz.CreateOption( "Checkbox", tabs.misc, "Bunnyhop AutoStrafe [Beta]", "misc_bhop_autostrafe", 5, 25 )
	snixzz.CreateOption( "Checkbox", tabs.misc, "Name Stealer", "misc_namechanger", 5, 45 )
	snixzz.CreateOption( "Checkbox", tabs.misc, "Debug Messages", "misc_debug", 5, 65 )
	snixzz.CreateOption( "Checkbox", tabs.misc, "Triggerbot", "misc_triggerbot", 5, 85 )
	snixzz.CreateOption( "Checkbox", tabs.misc, "Triggerbot NoSpread", "misc_triggerbot_nospread", 5, 105 )
	snixzz.CreateOption( "Checkbox", tabs.misc, "Fake Lag", "misc_fakelag", 5, 125 )
	snixzz.CreateOption( "Checkbox", tabs.misc, "Thirdperson", "misc_thirdperson", 5, 145 )
	snixzz.CreateOption( "Slider", tabs.misc, "Fake Lag Delay (Ticks)", "misc_fakelag_rate", 2, 25, 415, 5, 325, 0 )
	snixzz.CreateOption( "Slider", tabs.misc, "Thirdperson Distance", "misc_thirdperson_distance", 50, 180, 415, 5, 345, 1 )
	snixzz.CreateOption( "Slider", tabs.misc, "Speedhack Speed", "speedhack_speed", 1.5, 5, 420, 5, 365, 1 )
	
	snixzz.CreateOption( "Label", tabs.misc, "Triggerbot Method", 5, 290 )
	local Trigmethod = G****ui.Create( "DComboBox", tabs.misc )
	Trigmethod:SetPos( 5, 305 )
	Trigmethod:SetSize( 105, 20 )
	Trigmethod:SetText( snixzz.Vars["misc_triggerbot_method"] )
	Trigmethod:AddChoice( "Body" )
	Trigmethod:AddChoice( "Hitbox" )
	Trigmethod:SetTextColor( color_white )
	Trigmethod.OnSelect = function( self )
		snixzz.Vars["misc_triggerbot_method"] = self:GetValue()
		snixzz.Message( Color( 0, 255, 255 ), "Set triggerbot method to '" .. self:GetValue() .. "'" )
		snixzz.logEvent( "Setting", "Set triggerbot method to '" .. self:GetValue() .. "'" )
		snixzz.Sound()
	end
	Trigmethod.Paint = function() 
		G.surface.SetDrawColor( Color( 0, 0, 0 ) )
		G.surface.DrawOutlinedRect( 0, 0, Trigmethod:GetWide(), Trigmethod:GetTall() )
	end	
	
	snixzz.CreateOption( "Label", tabs.misc, "Speedhack Method", 115, 290 )
	local SpeedMethod = G****ui.Create( "DComboBox", tabs.misc )
	SpeedMethod:SetPos( 115, 305 )
	SpeedMethod:SetSize( 105, 20 )
	SpeedMethod:SetText( snixzz.Vars["speedhack_type"] )
	SpeedMethod:AddChoice( "pSpeed" )
	SpeedMethod:AddChoice( "Cvar" )
	SpeedMethod:SetTextColor( color_white )
	SpeedMethod.OnSelect = function( self )
		snixzz.Vars["speedhack_type"] = self:GetValue()
		snixzz.Message( Color( 0, 255, 255 ), "Set speedhack method to '" .. self:GetValue() .. "'" )
		snixzz.logEvent( "Setting", "Set speedhack method to '" .. self:GetValue() .. "'" )
		snixzz.Sound()
	end
	SpeedMethod.Paint = function() 
		G.surface.SetDrawColor( Color( 0, 0, 0 ) )
		G.surface.DrawOutlinedRect( 0, 0, SpeedMethod:GetWide(), SpeedMethod:GetTall() )
	end	
	
	---------------
	-- Lists Tab --
	---------------
	
	-- Friends/enemies
	
	local Enemies = G****ui.Create( "DListView", tabs.lists )
	Enemies:SetPos( 5, 5 ) -- 200
	Enemies:SetSize( 170, 190 )
	Enemies:AddColumn( "Enemies" )
	for k, v in G.next, G.player.GetAll() do
		if !snixzz.Friends[v:Nick()] && v != G.LocalPlayer() then
			Enemies:AddLine( v:Nick() )
		end
	end
	
	local Friends = G****ui.Create( "DListView", tabs.lists )
	Friends:SetPos( 230, 5 )
	Friends:SetSize( 170, 190 )
	Friends:AddColumn( "Friends" )
	for k, v in G.next, snixzz.Friends do
		Friends:AddLine( k )
	end
	
	local AddFriend = G****ui.Create( "DButton", tabs.lists ) 
	AddFriend:SetText( "-->" ) 
	AddFriend:SetSize( 30, 20 )
	AddFriend:SetPos( 187.5, 10 )
	AddFriend:SetTextColor( color_white )
	AddFriend.DoClick = function() 
	local line = Enemies:GetSelectedLine()
		if line != nil then 
			local ply = Enemies:GetLine( line ):GetValue(1)  
			if !snixzz.Friends[ply] then
				snixzz.Friends[ply] = true
				snixzz.Message( snixzz.Colors.Green, "Added '" .. ply .. "' to friends list." )
				snixzz.logEvent( "Config", "Added '" .. ply .. "' to friends list." )
				Friends:AddLine( ply ) 
				Enemies:RemoveLine( line ) 
				snixzz.Sound()
			end 
		end
	end
	AddFriend.Paint = function() 
		G.surface.SetDrawColor( Color( 0, 0, 0 ) )
		G.surface.DrawOutlinedRect( 0, 0, AddFriend:GetWide(), AddFriend:GetTall() )
	end
	
	local RemoveFriend = G****ui.Create( "DButton", tabs.lists ) 
	RemoveFriend:SetText("<--") 
	RemoveFriend:SetSize( 30, 20 ) 
	RemoveFriend:SetPos( 187.5, 45 )
	RemoveFriend:SetTextColor( color_white )
	RemoveFriend.DoClick = function() 
		local line = Friends:GetSelectedLine() 
		if line != nil then 
			local ply = Friends:GetLine( line ):GetValue(1) 
			if snixzz.Friends[ply] then
				for k, v in G.next, snixzz.Friends do 
					if k == ply then 
						snixzz.Friends[k] = nil
						snixzz.Message( snixzz.Colors.Red, "Removed '" .. ply .. "' from the friends list." )
						snixzz.logEvent( "Config", "Removed '" .. ply .. "' from the friends list." )
						snixzz.Sound()
					end 
				end 
				Enemies:AddLine( ply ) 
				Friends:RemoveLine( line ) 
			end
		end 
	end 
	RemoveFriend.Paint = function() 
		G.surface.SetDrawColor( Color( 0, 0, 0 ) )
		G.surface.DrawOutlinedRect( 0, 0, RemoveFriend:GetWide(), RemoveFriend:GetTall() )
	end
	
	-----------------
	-- Console Tab --
	-----------------
	
	snixzz.Console = G****ui.Create( "DListView", tabs.console )
	snixzz.Console:SetPos( 5, 5 )
	snixzz.Console:SetSize( snixzz.Frame:GetWide() - 25, snixzz.Frame:GetTall() - 70 )
	snixzz.Console:AddColumn( "snixzz2 Console" )
	for k, v in G.next, snixzz.Lines do
		snixzz.Console:AddLine( v )
	end
	snixzz.Console.OnClickLine = function( parent, line, isselected )
		G.SetClipboardText( line:GetValue( 1 ) )
	end
	
	local ConsoleEntry = vgui.Create( "DTextEntry", tabs.console )
	ConsoleEntry:SetPos( 5, 370 )
	ConsoleEntry:SetSize( snixzz.Frame:GetWide() - 115, 20 )
	ConsoleEntry:SetText( "Work in progress..." )
	ConsoleEntry:SetDisabled( true )
	ConsoleEntry.OnEnter = function( self )
		snixzz.Functions.ClientCMD( self:GetValue() )
		snixzz.logEvent( "Main", "Running console command '" .. self:GetValue() .. "'" )
	end
	
	local ConsoleClear = G****ui.Create( "DButton", tabs.console ) 
	ConsoleClear:SetText( "Clear Console" ) 
	ConsoleClear:SetSize( 85, 20 )
	ConsoleClear:SetPos( snixzz.Frame:GetWide() - 105, 370 )
	ConsoleClear:SetTextColor( color_white )
	ConsoleClear.DoClick = function() 
		snixzz.Lines = {}
		snixzz.Console:Clear()
		snixzz.logEvent( "Main", "Cleared console" )
	end 
	ConsoleClear.Paint = function() 
		G.surface.SetDrawColor( Color( 0, 0, 0 ) )
		G.surface.DrawOutlinedRect( 0, 0, ConsoleClear:GetWide(), ConsoleClear:GetTall() )
	end
	
	----------------
	-- Config Tab --
	----------------
	--Menu Settings
	snixzz.CreateOption( "Label", tabs.config, "Menu Color", 230, 5 )
	local MenuColor = G****ui.Create( "DColorMixer", tabs.config )
	MenuColor:SetPos( 230, 20 ) 
	MenuColor:SetSize( 170, 100 )
	MenuColor:SetPalette( false )
	MenuColor:SetAlphaBar( true )
	MenuColor:SetWangs( false )
	MenuColor:SetColor( snixzz.Vars["misc_menucolor"] )
	MenuColor.ValueChanged = function()
		snixzz.Vars["misc_menucolor"] = MenuColor:GetColor()
	end
	
	snixzz.CreateOption( "Label", tabs.config, "Secondary Menu Color", 230, 125 )
	local MenuColor2 = G****ui.Create( "DColorMixer", tabs.config )
	MenuColor2:SetPos( 230, 140 ) 
	MenuColor2:SetSize( 170, 100 )
	MenuColor2:SetPalette( false )
	MenuColor2:SetAlphaBar( true )
	MenuColor2:SetWangs( false )
	MenuColor2:SetColor( snixzz.Vars["misc_menucolor2"] )
	MenuColor2.ValueChanged = function()
		snixzz.Vars["misc_menucolor2"] = MenuColor2:GetColor()
	end
	
	snixzz.CreateOption( "Label", tabs.config, "Laser Color", 230, 245 )
	local LaserCol = G****ui.Create( "DColorMixer", tabs.config )
	LaserCol:SetPos( 230, 260 ) 
	LaserCol:SetSize( 170, 100 )
	LaserCol:SetPalette( false )
	LaserCol:SetAlphaBar( false )
	LaserCol:SetWangs( false )
	LaserCol:SetColor( snixzz.Vars["misc_lasercolor"] )
	LaserCol.ValueChanged = function()
		snixzz.Vars["misc_lasercolor"] = LaserCol:GetColor()
	end
	
	local CfgList = G****ui.Create( "DListView", tabs.config ) 
	CfgList:SetPos( 5, 5 ) 
	CfgList:SetMultiSelect( false ) 
	CfgList:SetSize( 220, 80 )
	CfgList:AddColumn( "Config" ) 
	for k, v in G.next, snixzz.Configs do 
		CfgList:AddLine( v ) 
	end 
	CfgList.DoDoubleClick = function() 
		local line = CfgList:GetSelectedLine() 
		if line != nil then 
			local config = CfgList:GetLine( line ):GetValue( 1 ) 
			snixzz.LoadConfig( config ) 
			snixzz.Sound()
		end 
	end 
		
	-- Right from gInject. Im lazy with menus. I'll re-write it later
	local CreateConfig = G****ui.Create( "DButton", tabs.config ) 
	CreateConfig:SetText( "Create New" ) 
	CreateConfig:SetSize( 105, 30 )
	CreateConfig:SetPos( 5, 90 )
	CreateConfig:SetTextColor( color_white )
	CreateConfig.DoClick = function() 
		G.Derma_StringRequest( "New Config", "Name of the new config", "", function( txt ) 
			snixzz.SaveConfig( txt ) 
			snixzz.Sound()
		end )
	end 
	CreateConfig.Paint = function() 
		G.surface.SetDrawColor( Color( 0, 0, 0 ) )
		G.surface.DrawOutlinedRect( 0, 0, CreateConfig:GetWide(), CreateConfig:GetTall() )
	end
	
	local RenameConfig = G****ui.Create( "DButton", tabs.config ) 
	RenameConfig:SetText( "Rename" ) 
	RenameConfig:SetSize( 105, 30 )
	RenameConfig:SetPos( 5, 125 )
	RenameConfig:SetTextColor( color_white )
	RenameConfig.DoClick = function()
		G.Derma_StringRequest( "Rename Config", "Name of the new config", "", function( NewConfig ) 
			local line = CfgList:GetSelectedLine() 
			if line != nil then 
				local OldConfig = CfgList:GetLine( line ):GetValue( 1 ) 
				if OldConfig != "default" then
					snixzz.RenameConfig( OldConfig, NewConfig )
					G.table.remove( snixzz.Configs, CfgList:GetSelectedLine() )
					G.table.insert( snixzz.Configs, NewConfig )
					snixzz.Sound()
				end
			end
		end )
	end	
	RenameConfig.Paint = function() 
		G.surface.SetDrawColor( Color( 0, 0, 0 ) )
		G.surface.DrawOutlinedRect( 0, 0, RenameConfig:GetWide(), RenameConfig:GetTall() )
	end
	
	local DeleteConfig = G****ui.Create( "DButton", tabs.config ) 
	DeleteConfig:SetText( "Delete" ) 
	DeleteConfig:SetSize( 105, 30 )
	DeleteConfig:SetPos( 118, 90 )
	DeleteConfig:SetTextColor( color_white )
	DeleteConfig.DoClick = function() 
		local line = CfgList:GetSelectedLine() 
		if line != nil then
			local config = CfgList:GetLine( line ):GetValue( 1 ) 
			if config != "default" then
				for k, v in G.next, snixzz.Configs do 
					if v == config then 
						snixzz.DeleteConfig( config )
						G.table.remove( snixzz.Configs, k ) 
						snixzz.Sound()
					end 
				end
			end
		end 
	end 
	DeleteConfig.Paint = function() 
		G.surface.SetDrawColor( Color( 0, 0, 0 ) )
		G.surface.DrawOutlinedRect( 0, 0, DeleteConfig:GetWide(), DeleteConfig:GetTall() )
	end
	
	local LoadConfig = G****ui.Create( "DButton", tabs.config ) 
	LoadConfig:SetText( "Load" ) 
	LoadConfig:SetSize( 105, 30 )
	LoadConfig:SetPos( 118, 125 )
	LoadConfig:SetTextColor( color_white )
	LoadConfig.DoClick = function()
		local line = CfgList:GetSelectedLine() 
		if line != nil then 
			local config = CfgList:GetLine( line ):GetValue( 1 ) 
			snixzz.LoadConfig( config )
			snixzz.Frame:SetVisible( false )
			snixzz.Changelog:SetVisible( false )
			snixzz.MenuOpen = false
			snixzz.MenuToggle = false
			snixzz.Sound()
		end
	end
	LoadConfig.Paint = function() 
		G.surface.SetDrawColor( Color( 0, 0, 0 ) )
		G.surface.DrawOutlinedRect( 0, 0, LoadConfig:GetWide(), LoadConfig:GetTall() )
	end
	
	local SetDefaultCfg = G****ui.Create( "DButton", tabs.config ) 
	SetDefaultCfg:SetText( "Set Default" ) 
	SetDefaultCfg:SetSize( 105, 30 )
	SetDefaultCfg:SetPos( 118, 160 )
	SetDefaultCfg:SetTextColor( color_white )
	SetDefaultCfg.DoClick = function()
		local line = CfgList:GetSelectedLine() 
		if line != nil then 
			local config = CfgList:GetLine( line ):GetValue( 1 ) 
			snixzz.SetDefaultConfig( config )
			snixzz.LoadConfig( config )
			snixzz.Sound()
		end
	end	
	SetDefaultCfg.Paint = function() 
		G.surface.SetDrawColor( Color( 0, 0, 0 ) )
		G.surface.DrawOutlinedRect( 0, 0, SetDefaultCfg:GetWide(), SetDefaultCfg:GetTall() )
	end
		
	local UpdateConfig = G****ui.Create( "DButton", tabs.config ) 
	UpdateConfig:SetText( "Save Changes" ) 
	UpdateConfig:SetSize( 105, 30 )
	UpdateConfig:SetPos( 118, 195 )
	UpdateConfig:SetTextColor( color_white )
	UpdateConfig.DoClick = function()
		snixzz.Sound()
		snixzz.UpdateConfig()
	end	
	UpdateConfig.Paint = function() 
		G.surface.SetDrawColor( Color( 0, 0, 0 ) )
		G.surface.DrawOutlinedRect( 0, 0, UpdateConfig:GetWide(), UpdateConfig:GetTall() )
	end
	
	// Binds
	local BindCommands = G****ui.Create( "DComboBox", tabs.config )
	BindCommands:SetPos( 5, 160 )
	BindCommands:SetSize( 105, 20 )
	BindCommands:SetTextColor( color_white )
	for k, v in G.next, snixzz.Binds do
		BindCommands:AddChoice( k )
	end
	BindCommands.Paint = function() 
		G.surface.SetDrawColor( Color( 0, 0, 0 ) )
		G.surface.DrawOutlinedRect( 0, 0, BindCommands:GetWide(), BindCommands:GetTall() )
	end
	
	local BindKeys = G****ui.Create( "DComboBox", tabs.config )
	BindKeys:SetPos( 5, 185 )
	BindKeys:SetSize( 105, 20 )
	BindKeys:SetTextColor( color_white )
	for k, v in G.next, snixzz.Keys do
		BindKeys:AddChoice( v.Name )
	end
	BindKeys.Paint = function() 
		G.surface.SetDrawColor( Color( 0, 0, 0 ) )
		G.surface.DrawOutlinedRect( 0, 0, BindKeys:GetWide(), BindKeys:GetTall() )
	end
	
	local RebindKey = G****ui.Create( "DButton", tabs.config ) 
	RebindKey:SetText( "Bind" ) 
	RebindKey:SetSize( 105, 20 )
	RebindKey:SetPos( 5, 210 )
	RebindKey:SetTextColor( color_white )
	RebindKey.DoClick = function() 
		local Key = BindKeys:GetValue()
		local Command = BindCommands:GetValue()
		if ( BindKeys:GetValue() != "" && BindCommands:GetValue() != "" ) then
			snixzz.Frame:SetVisible( false )
			snixzz.Changelog:SetVisible( false )
			snixzz.MenuOpen = false
			snixzz.MenuToggle = false
			snixzz.BindKey( Command, Key )
			snixzz.Sound()
		end
	end
	RebindKey.Paint = function() 
		G.surface.SetDrawColor( Color( 0, 0, 0 ) )
		G.surface.DrawOutlinedRect( 0, 0, RebindKey:GetWide(), RebindKey:GetTall() )
	end
	
	snixzz.CreateOption( "Checkbox", tabs.config, "Load with GAMEMODE hooks (Buggy, may break parts of gamemode)", "load_unhooked", 5, 375 )

	
end

/*

	Hooking & loading.
	
*/

snixzz.GMHooks = { -- Return the server's original hooks for selected types
	["CreateMove"] = GAMEMODE.CreateMove,
	["HUDPaint"] = GAMEMODE.HUDPaint,
	["StartChat"] = GAMEMODE.StartChat,
	["FinishChat"] = GAMEMODE.FinishChat,
}

function GAMEMODE:StartChat() 
	snixzz.Typing = true 
	return snixzz.GMHooks.StartChat() 
end 

function GAMEMODE:FinishChat() 
	snixzz.Typing = false 
	return snixzz.GMHooks.FinishChat()
end 

function GAMEMODE:ShouldDrawLocalPlayer( ply )
	return snixzz.Bools["misc_thirdperson"]
end

if snixzz.Bools["load_unhooked"] then

	function GAMEMODE:CreateMove( ucmd )
		snixzz.CreateMove( ucmd )
		return snixzz.GMHooks.CreateMove( ucmd )
	end

	function GAMEMODE:HUDPaint( self )
		snixzz.HUDPaint()
		return snixzz.GMHooks.HUDPaint( self )
	end

	function GAMEMODE:CalcView( ply, origin, angles, fov )
		return snixzz.CalcView( ply, origin, angles, fov )
	end

	function GAMEMODE:Move()
		return snixzz.Move()
	end
	
	snixzz.Message( Color( 255, 0, 134 ), "Hooking functions into the gamemode's hook system." )
	
else

	snixzz.AddHook( "CreateMove", snixzz.CreateMove )
	snixzz.AddHook( "HUDPaint", snixzz.HUDPaint )
	snixzz.AddHook( "CalcView", snixzz.CalcView )
	snixzz.AddHook( "Move", snixzz.Move )
	
	snixzz.Message( Color( 255, 150, 0 ), "Loading unsecured hooks. More detectable but more reliable." )
	
end

snixzz.LoadConfig( snixzz.DefaultConfig )
snixzz.logEvent( "Load", "Playing " .. GAMEMODE.Name .. " on " .. GetHostName() )

G.chat.AddText( 
snixzz.Colors.DarkRed, "[snixzz2] ",
snixzz.Colors.Cyan, "Loaded lua. ",
snixzz.Colors.Purple, snixzz.Info.Version .. ", ",
snixzz.Colors.White, "Last updated ",
snixzz.Colors.Green, snixzz.Info.Updated .. ", ",
Color( 255, 255, 0 ), snixzz.Info.Size .. ", ",
Color( 0, 100, 240 ), snixzz.Info.Lines .. " ",
snixzz.Colors.White, "lines long." )
snixzz.Sound()