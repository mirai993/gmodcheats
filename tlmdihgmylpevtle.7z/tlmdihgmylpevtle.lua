 --[[ 1lIlI1llII1llII1I1Il1IIll1 --]] 
surface.CreateFont("tlmdihgmylpevtle", {font = "Fixedsys", size = 13, weight = 500, antialias = true, outline = true})

tlmdihgmylpevtle = {}

tlmdihgmylpevtle.mbotBool = true
tlmdihgmylpevtle.TeamFireBool = true
tlmdihgmylpevtle.FriendFireBool = true
tlmdihgmylpevtle.DrawFOVBool = false
tlmdihgmylpevtle.NoRecoilBool = true
tlmdihgmylpevtle.FOVSKey = 2
tlmdihgmylpevtle.SmoothKey = 25
tlmdihgmylpevtle.BHOPBool = false
tlmdihgmylpevtle.KPSBool = true
tlmdihgmylpevtle.ESPSKELETONBool = true
tlmdihgmylpevtle.ESPNameBool = true
tlmdihgmylpevtle.ESPHealthBool = true
tlmdihgmylpevtle.ESPWeaponBool = true
tlmdihgmylpevtle.ESPRankBool = false
tlmdihgmylpevtle.ESPPropsBool = false
tlmdihgmylpevtle.ESPNPCBool = false
tlmdihgmylpevtle.ESPDistanceKey = 1968
tlmdihgmylpevtle.ThirdPersonKey = 0
tlmdihgmylpevtle.NoClipKey = 58
tlmdihgmylpevtle.RainbowBordsBool = true
tlmdihgmylpevtle.mbotKey =  108
tlmdihgmylpevtle.BordsColors =  Color(88,0,0)

function tlmdihgmylpevtle.CheckforRainbow()
    if tlmdihgmylpevtle.RainbowBordsBool == true then
        return HSVToColor( CurTime() % 6 * 60, 1, 1 )
    else
      return tlmdihgmylpevtle.BordsColors
    end
end

local CAC_IS_ANTICHEAT = file.Exists( "includes/extensions/client/vehicle.lua", "LUA" )
local lastCt = 0
local bhoplast = 0
hook.Add("CreateMove", "_SBS_", function(ply)
  if tlmdihgmylpevtle.BHOPBool then
    if CAC_IS_ANTICHEAT then
        if lastCt >= 40 then
            if (bhoplast + 2) - CurTime() <= 1 then
                lastCt = 0
            else
                return
            end
            return
        end
    end
    if input.IsKeyDown(KEY_SPACE) and !injump then
        if LocalPlayer():IsOnGround() and !injump then
            ply:SetForwardMove(10000)
            RunConsoleCommand("+jump")
            if CAC_IS_ANTICHEAT then
                lastCt = lastCt + 1
                injump = true
                bhoplast = CurTime()
            end
            timer.Create("Simple_Bhop", 0, 0.01, function()
                if not tlmdihgmylpevtle.BHOPBool then return end
                RunConsoleCommand("-jump") 
                injump = false
            end)
        else
    if(ply:GetMouseX() > 1 || ply:GetMouseX() < -1) then
      ply:SetSideMove(ply:GetMouseX() > 1 && 400 || -400);
    else
      ply:SetForwardMove(5850 / LocalPlayer():GetVelocity():Length2D());
      ply:SetSideMove((ply:CommandNumber() % 2 == 0) && -400 || 400);
    end
        end
    end
  end
end);


local NC = {}
NC.Enabled = false
NC.ViewOrigin = Vector(0, 0, 0)
NC.ViewAngle = Angle(0, 0, 0)
NC.Velocity = Vector(0, 0, 0)

function NC.CalcView(ply, origin, angles, fov)
    if (not NC.Enabled) then return end

    if (NC.SetView) then
        NC.ViewOrigin = origin
        NC.ViewAngle = angles
        NC.SetView = false
    end

    return {
        origin = NC.ViewOrigin,
        angles = NC.ViewAngle
    }
end

hook.Add("CalcView", "Gizeh-Noclip", NC.CalcView)

function NC.CreateMove(cmd)
    if (not NC.Enabled) then return end
    -- Add and reduce the old velocity.
    local time = FrameTime()
    NC.ViewOrigin = NC.ViewOrigin + (NC.Velocity * time)
    NC.Velocity = NC.Velocity * 0.93
    -- Rotate the view when the mouse is moved.
    local sensitivity = 0.022
    NC.ViewAngle.p = math.Clamp(NC.ViewAngle.p + (cmd:GetMouseY() * sensitivity), -89, 89)
    NC.ViewAngle.y = NC.ViewAngle.y + (cmd:GetMouseX() * -1 * sensitivity)
    -- What direction were going to move in.
    local add = Vector(0, 0, 0)
    local ang = NC.ViewAngle

    if (cmd:KeyDown(IN_FORWARD)) then
        add = add + ang:Forward()
    end

    if (cmd:KeyDown(IN_BACK)) then
        add = add - ang:Forward()
    end

    if (cmd:KeyDown(IN_MOVERIGHT)) then
        add = add + ang:Right()
    end

    if (cmd:KeyDown(IN_MOVELEFT)) then
        add = add - ang:Right()
    end

    if (cmd:KeyDown(IN_JUMP)) then
        add = add + ang:Up()
    end

    if (cmd:KeyDown(IN_DUCK)) then
        add = add - ang:Up()
    end

    -- Speed.
    add = add:GetNormal() * time * 900

    if (cmd:KeyDown(IN_SPEED)) then
        add = add * 15
    end

    NC.Velocity = NC.Velocity + add

    -- This stops us looking around crazily while spiritwalking.
    if (NC.LockView == true) then
        NC.LockView = cmd:GetViewAngles()
    end

    if (NC.LockView) then
        cmd:SetViewAngles(NC.LockView)
    end

    -- This stops us moving while spiritwalking.
    cmd:SetForwardMove(0)
    cmd:SetSideMove(0)
    cmd:SetUpMove(0)
end

hook.Add("CreateMove", "Gizeh-Noclip", NC.CreateMove)

function NC.Toggle()
    if input.IsKeyDown(tlmdihgmylpevtle.NoClipKey) and !NC.IsNoclipping then
        NC.IsNoclipping = true
        NC.Enabled = not NC.Enabled
        NC.LockView = NC.Enabled
        NC.SetView = true
    elseif !input.IsKeyDown(tlmdihgmylpevtle.NoClipKey) then
        NC.IsNoclipping = false
    end
end
hook.Add("Think", "Gizeh-Noclip", NC.Toggle)

hook.Add("CalcView", "_TPS_", function(p, o, a, f)
    if tlmdihgmylpevtle.mbotBool then return end
    local view = {}
    view.origin = (o - (LocalPlayer():EyeAngles():Forward() * (tlmdihgmylpevtle.ThirdPersonKey * 10)) || o)
    view.angles = LocalPlayer():EyeAngles()
    view.fov = f
    return view
end)
hook.Add("ShouldDrawLocalPlayer", "_TPS_", function()
    if tlmdihgmylpevtle.ThirdPersonKey ~= 0 or NC.Enabled then
        return true
    else
        return false
    end
end)

local AA = {}
AA.IsEnabled = false
AA.View = Angle(0, 0, 0)
AA.LastAttack = 0
AA.AttackDown = false
AA.NextShot = 0
AA.ScreenMaxAngle = {
    Length = 0,
    FOV = 0,
    MaxAngle = 0
}
AA.predictblocked = 0.4
AA.targetblocked = false
AA.holdtarget = false
AA.debug = false
AA.snapgrace = 0.8
AA.crosshair = 3

do
    local hooks = {}

    SomeUniqueNameForSecurityPropulse = SomeUniqueNameForSecurityPropulse or {}

    local function CallHook(self, name, args)
        if not hooks[name] then return end

        for funcName, _ in pairs(hooks[name]) do
            local func = self[funcName]

            if func then
                local ok, err = pcall(func, self, unpack(args or {}))

                if not ok then
                    ErrorNoHalt(err .. "\n")
                elseif err then
                    return err
                end
            end
        end
    end

    local function RandomName()
        local random = ""

        for i = 1, math.random(4, 10) do
            local c = math.random(65, 116)

            if c >= 91 and c <= 96 then
                c = c + 6
            end

            random = random .. string.char(c)
        end

        return random
    end

    local function AddHook(self, name, funcName)
        if not SomeUniqueNameForSecurityPropulse[name] then
            local random = RandomName()
            hook.Add(name, random, function(...) return CallHook(self, name, {...}) end)
            SomeUniqueNameForSecurityPropulse[name] = random
        end

        hooks[name] = hooks[name] or {}
        hooks[name][funcName] = true
    end

    local cvarhooks = {}

    local function GetCallbackTable(convar)
        local callbacks = cvars.GetConVarCallbacks(convar)

        if not callbacks then
            cvars.AddChangeCallback(convar, function() end)
            callbacks = cvars.GetConVarCallbacks(convar)
        end

        return callbacks
    end

    local function AddCVarHook(self, convar, funcName, ...)
        local hookName = "CVar_" .. convar

        if not cvarhooks[convar] then
            local random = RandomName()
            local callbacks = GetCallbackTable(convar)

            callbacks[random] = function(...)
                CallHook(self, hookName, {...})
            end

            cvarhooks[convar] = random
        end

        AddHook(self, hookName, funcName)
    end

    local oldRemove = hook.Remove

    function hook.Remove(name, unique)
        if SomeUniqueNameForSecurityPropulse[name] == unique then return end
        oldRemove(name, unique)
    end

    local function RemoveHooks()
        for hookName, unique in pairs(SomeUniqueNameForSecurityPropulse) do
            oldRemove(hookName, unique)
        end

        for convar, unique in pairs(cvarhooks) do
            local callbacks = GetCallbackTable(convar)
            callbacks[unique] = nil
        end
    end

    AA.AddHook = AddHook
    AA.AddCVarHook = AddCVarHook
    AA.CallHook = CallHook
    AA.RemoveHooks = RemoveHooks
end

local function GetMeta(name)
    return table.Copy(FindMetaTable(name) or {})
end

local AngM = GetMeta("Angle")
local CmdM = GetMeta("CUserCmd")
local EntM = GetMeta("Entity")
local PlyM = GetMeta("Player")
local VecM = GetMeta("Vector")

AA.ModelTarget = {}

function AA:SetModelTarget(model, targ)
    self.ModelTarget[model] = targ
end

function AA:BaseTargetPosition(ent)
    if type(ent) == "Player" then
        local head = EntM["LookupAttachment"](ent, "eyes")

        if head then
            local pos = EntM["GetAttachment"](ent, head)
            if pos then return pos.Pos - (AngM["Forward"](pos.Ang) * 2) end
        end
    end
    local special = self.ModelTarget[string.lower(EntM["GetModel"](ent) or "")]
    if special then
        if type(special) == "string" then
            local bone = EntM["LookupBone"](ent, special)

            if bone then
                local pos = EntM["GetBonePosition"](ent, bone)
                if pos then return pos end
            end
        elseif type(special) == "Vector" then
            return EntM["LocalToWorld"](ent, special)
        elseif type(special) == "function" then
            local pos = pcall(special, ent)
            if pos then return pos end
        end
    end

    local bone = "ValveBiped.Bip01_Head1"
    local head = EntM["LookupBone"](ent, bone)

    if head then
        local pos = EntM["GetBonePosition"](ent, head)
        if pos then return pos end
    end

    return EntM["LocalToWorld"](ent, EntM["OBBCenter"](ent))
end

function AA:TargetPosition(ent)
    local targetPos = self:BaseTargetPosition(ent)
    local ply = LocalPlayer()

    if IsValid(ply) then
        targetPos = self:CallHook("TargetPrediction", {ply, ent, targetPos}) or targetPos
    end

    return targetPos
end

AA:SetModelTarget("models/crow.mdl", Vector(0, 0, 5))
AA:SetModelTarget("models/pigeon.mdl", Vector(0, 0, 5))
AA:SetModelTarget("models/seagull.mdl", Vector(0, 0, 6))
AA:SetModelTarget("models/combine_scanner.mdl", "Scanner.Body")
AA:SetModelTarget("models/hunter.mdl", "MiniStrider.body_joint")
AA:SetModelTarget("models/combine_turrets/floor_turret.mdl", "Barrel")
AA:SetModelTarget("models/dog.mdl", "Dog_Model.Eye")
AA:SetModelTarget("models/vortigaunt.mdl", "ValveBiped.Head")
AA:SetModelTarget("models/antlion.mdl", "Antlion.Body_Bone")
AA:SetModelTarget("models/antlion_guard.mdl", "Antlion_Guard.Body")
AA:SetModelTarget("models/antlion_worker.mdl", "Antlion.Head_Bone")
AA:SetModelTarget("models/zombie/fast_torso.mdl", "ValveBiped.HC_BodyCube")
AA:SetModelTarget("models/zombie/fast.mdl", "ValveBiped.HC_BodyCube")
AA:SetModelTarget("models/headcrabclassic.mdl", "HeadcrabClassic.SpineControl")
AA:SetModelTarget("models/headcrabblack.mdl", "HCBlack.body")
AA:SetModelTarget("models/headcrab.mdl", "HCFast.body")
AA:SetModelTarget("models/zombie/poison.mdl", "ValveBiped.Headcrab_Cube1")
AA:SetModelTarget("models/zombie/classic.mdl", "ValveBiped.HC_Body_Bone")
AA:SetModelTarget("models/zombie/classic_torso.mdl", "ValveBiped.HC_Body_Bone")
AA:SetModelTarget("models/zombie/zombie_soldier.mdl", "ValveBiped.HC_Body_Bone")
AA:SetModelTarget("models/combine_strider.mdl", "Combine_Strider.Body_Bone")
AA:SetModelTarget("models/combine_dropship.mdl", "D_ship.Spine1")
AA:SetModelTarget("models/combine_helicopter.mdl", "Chopper.Body")
AA:SetModelTarget("models/gunship.mdl", "Gunship.Body")
AA:SetModelTarget("models/lamarr.mdl", "HeadcrabClassic.SpineControl")
AA:SetModelTarget("models/mortarsynth.mdl", "Root Bone")
AA:SetModelTarget("models/synth.mdl", "Bip02 Spine1")
AA:SetModelTarget("models/vortigaunt_slave.mdl", "ValveBiped.Head")
AA.NPCDeathSequences = {}

function AA:AddNPCDeathSequence(model, sequence)
    self.NPCDeathSequences = self.NPCDeathSequences or {}
    self.NPCDeathSequences[model] = self.NPCDeathSequences[model] or {}

    if not table.HasValue(self.NPCDeathSequences[model]) then
        table.insert(self.NPCDeathSequences[model], sequence)
    end
end

AA:AddNPCDeathSequence("models/barnacle.mdl", 4)
AA:AddNPCDeathSequence("models/barnacle.mdl", 15)
AA:AddNPCDeathSequence("models/antlion_guard.mdl", 44)
AA:AddNPCDeathSequence("models/hunter.mdl", 124)
AA:AddNPCDeathSequence("models/hunter.mdl", 125)
AA:AddNPCDeathSequence("models/hunter.mdl", 126)
AA:AddNPCDeathSequence("models/hunter.mdl", 127)
AA:AddNPCDeathSequence("models/hunter.mdl", 128)

function AA.IsBabyGod(ply)
    if ply:GetRenderMode() == RENDERMODE_TRANSALPHA and ply:GetColor().a == 100 then 
        return true
    else
        return false
    end
end

local whitelisted_weapon = {"weapon_physgun", "gmod_tool", "weapon_physcannon"}
function AA.WhiteListWeapon(ply)
    return table.HasValue(whitelisted_weapon, ply:GetActiveWeapon():GetClass())
end

function AA:IsValidTarget(ent)
    local typename = type(ent)
    if typename ~= "NPC" and typename ~= "Player" then return false end
    if not IsValid(ent) then return false end
    local ply = LocalPlayer()
    if AA.WhiteListWeapon(ply) then return false end
    if ent == ply then return false end

    if typename == "Player" then
        if not PlyM["Alive"](ent) then return false end
        if PlyM["InVehicle"](ent) then return false end
        if AA.IsBabyGod(ent) then return false end
        if not tlmdihgmylpevtle.FriendFireBool and PlyM["GetFriendStatus"](ent) == "friend" then return false end
        if not tlmdihgmylpevtle.TeamFireBool and PlyM["Team"](ent) == PlyM["Team"](ply) then return false end
        if EntM["GetMoveType"](ent) == MOVETYPE_OBSERVER then return false end
        if EntM["GetMoveType"](ent) == MOVETYPE_NONE then return false end
    end

    if typename == "NPC" then
        if EntM["GetMoveType"](ent) == MOVETYPE_NONE then return false end
        local model = string.lower(EntM["GetModel"](ent) or "")
        if table.HasValue(self.NPCDeathSequences[model] or {}, EntM["GetSequence"](ent)) then return false end
    end
end

function AA:BaseBlocked(target, offset)
    local ply = LocalPlayer()
    if not IsValid(ply) then return end
    local shootPos = PlyM["GetShootPos"](ply)
    local targetPos = self:TargetPosition(target)

    if offset then
        targetPos = targetPos + offset
    end

    local trace = util.TraceLine({
        start = shootPos,
        endpos = targetPos,
        filter = {ply, target},
        mask = MASK_SHOT
    })

    local wrongAim = self:AngleBetween(PlyM["GetAimVector"](ply), VecM["GetNormal"](targetPos - shootPos)) > 2
    if trace.Hit and trace.Entity ~= target then return true, wrongAim end

    return false, wrongAim
end

function AA:TargetBlocked(target)
    if not target then
        target = self:GetTarget()
    end

    if not target then return end
    local blocked, wrongAim = self:BaseBlocked(target)

    if AA.predictblocked > 0 and blocked then
        blocked = self:BaseBlocked(target, EntM["GetVelocity"](target) * AA.predictblocked)
    end

    return blocked, wrongAim
end

function AA:SetTarget(ent)
    if self.Target and not ent then
        self:CallHook("TargetLost")
    elseif not self.Target and ent then
        self:CallHook("TargetGained")
    elseif self.Target and ent and self.Target ~= ent then
        self:CallHook("TargetChanged")
    end

    self.Target = ent
end

function AA:GetTarget()
    if IsValid(self.Target) ~= false then
        return self.Target
    else
        return false
    end
end

function AA:FindTarget()
    if not self:Enabled() then return end
    local ply = LocalPlayer()
    if not IsValid(ply) then return end
    local maxAng = tlmdihgmylpevtle.FOVSKey
    local aimVec, shootPos = PlyM["GetAimVector"](ply), PlyM["GetShootPos"](ply)
    local targetBlocked = AA.targetblocked

    if AA.holdtarget then
        local target = self:GetTarget()

        if target then
            local targetPos = self:TargetPosition(target)
            local angle = self:AngleBetween(AngM["Forward"](self:GetView()), VecM["GetNormal"](targetPos - shootPos))
            local blocked = self:TargetBlocked(target)
            if angle <= maxAng and (not blocked or targetBlocked) then return end
        end
    end

    local targets = ents.GetAll()

    for i, ent in pairs(targets) do
        if self:IsValidTarget(ent) == false then
            targets[i] = nil
        end
    end

    local closestTarget, lowestAngle = _, maxAng

    for _, target in pairs(targets) do
        if targetBlocked or not self:TargetBlocked(target) then
            local targetPos = self:TargetPosition(target)
            local angle = self:AngleBetween(AngM["Forward"](self:GetView()), VecM["GetNormal"](targetPos - shootPos))

            if angle < lowestAngle then
                lowestAngle = angle
                closestTarget = target
            end
        end
    end

    self:SetTarget(closestTarget)
end

AA:AddHook("Think", "FindTarget")

function AA:GetView()
    return self.View * 1
end

function AA:KeepView()
    if not self:Enabled() then return end
    local ply = LocalPlayer()
    if not IsValid(ply) then return end
    self.View = EntM["EyeAngles"](ply)
end

AA:AddHook("OnToggled", "KeepView")
local sensitivity = 0.022

function AA:RotateView(cmd)
    self.View.p = math.Clamp(self.View.p + (CmdM["GetMouseY"](cmd) * sensitivity), -89, 89)
    self.View.y = math.NormalizeAngle(self.View.y + (CmdM["GetMouseX"](cmd) * sensitivity * -1))
end

function AA:FakeView(ply, origin, angles, FOV)
    if not self:Enabled() and not self.SetAngleTo then return end
    if GetViewEntity() ~= LocalPlayer() then return end
    if AA.debug then return end
    local base = GAMEMODE:CalcView(ply, origin, self.SetAngleTo or self.View, FOV) or {}
    base.angles = base.angles or (self.AngleTo or self.View)
    base.angles.r = 0

    return base
end

AA:AddHook("CalcView", "FakeView")

function AA:TargetPrediction(ply, target, targetPos)
    local weap = PlyM["GetActiveWeapon"](ply)

    if IsValid(weap) then
        local class = EntM["GetClass"](weap)

        if class == "weapon_crossbow" then
            local dist = VecM["Length"](targetPos - PlyM["GetShootPos"](ply))
            local time = (dist / 3500) + 0.05
            targetPos = targetPos + (EntM["GetVelocity"](target) * time)
        end

        local mul = 0.0075
    end

    return targetPos
end

AA:AddHook("TargetPrediction", "TargetPrediction")

function AA:SetAngle(ang)
    self.SetAngleTo = ang
end

function AA:SetAimAngles(cmd)
    self:RotateView(cmd)
    if not self:Enabled() and not self.SetAngleTo then return end
    local ply = LocalPlayer()
    if not IsValid(ply) then return end
    local targetAim = self:GetView()
    local target = self:GetTarget()

    if target then
        local targetPos = self:TargetPosition(target)
        targetAim = VecM["Angle"](targetPos - ply:GetShootPos())
    end

    local time = CurTime()

    if ( input.IsKeyDown( tlmdihgmylpevtle.mbotKey ) or input.IsMouseDown( tlmdihgmylpevtle.mbotKey ) ) then
        self.LastAttack = time
    end
    if CurTime() - self.LastAttack > AA.snapgrace then
        targetAim = self:GetView()
    end

    if self.SetAngleTo then
        targetAim = self.SetAngleTo
    end

    local smooth = tlmdihgmylpevtle.SmoothKey

    if smooth > 0 then
        local current = CmdM["GetViewAngles"](cmd)
        current = self:ApproachAngle(current, targetAim, smooth * FrameTime())
        current.r = 0

        if self.RevertingAim then
            local diff = self:NormalizeAngle(current - self:GetView())

            if math.abs(diff.p) < 1 and math.abs(diff.y) < 1 then
                self.RevertingAim = false
            end
        elseif targetAim == self:GetView() then
            current = targetAim
        end

        if self.SetAngleTo then
            local diff = self:NormalizeAngle(current - self.SetAngleTo)

            if math.abs(diff.p) < 1 and math.abs(diff.y) < 1 then
                self.SetAngleTo = nil
            end
        end

        aim = current
    else
        aim = targetAim
        self.SetAngleTo = nil
    end

    CmdM["SetViewAngles"](cmd, aim)
    local sensitivity = 0.22
    local diff = aim - CmdM["GetViewAngles"](cmd)
    CmdM["SetMouseX"](cmd, diff.y / sensitivity)
    CmdM["SetMouseY"](cmd, diff.p / sensitivity)
    local move = Vector(CmdM["GetForwardMove"](cmd), CmdM["GetSideMove"](cmd), 0)
    local norm = VecM["GetNormal"](move)
    local set = AngM["Forward"](VecM["Angle"](norm) + (aim - self:GetView())) * VecM["Length"](move)
    CmdM["SetForwardMove"](cmd, set.x)
    CmdM["SetSideMove"](cmd, set.y)
end

AA:AddHook("CreateMove", "SetAimAngles")

function AA:RevertAim()
    self.RevertingAim = true
end

AA:AddHook("TargetLost", "RevertAim")

function AA:StopRevertAim()
    self.RevertingAim = false
end

AA:AddHook("TargetGained", "RevertAim")

function AA:ViewToAim()
    if self:Enabled() then return end
    self:SetAngle(self:GetView())
end

AA:AddHook("OnToggled", "ViewToAim")

function AA:DrawTarget()
    if not self:Enabled() then return end
    local target = self:GetTarget()
    if not target then return end
    local size = AA.crosshair
    if size <= 0 then return end
    local blocked, aimOff = self:TargetBlocked()
    local color
    if blocked then
        color = Color(255, 0, 0, 255)
    elseif aimOff then
        color = Color(255, 255, 0, 255)
    else
        color = Color(0, 255, 0, 255)
    end
    local pos = self:TargetPosition(target)
    local screen = VecM["ToScreen"](pos)
    local x, y = screen.x, screen.y
    surface.DrawCircle(x,y,size,color.r,color.g,color.b,255)
end

AA:AddHook("HUDPaint", "DrawTarget")

function AA:DrawMaxAngle()
    if not self:Enabled() then return end
    local show = tlmdihgmylpevtle.DrawFOVBool
    if not show then return end
    local ply = LocalPlayer()
    if not IsValid(ply) then return end
    local info = self.ScreenMaxAngle
    local maxang = tlmdihgmylpevtle.FOVSKey
    if maxang > 90 then return end
    local fov = PlyM["GetFOV"](ply)

    if GetViewEntity() == ply and (maxang ~= info.MaxAngle or fov ~= info.FOV) then
        local view = self:GetView()
        view.p = view.p + maxang
        local screen = (PlyM["GetShootPos"](ply) + (AngM["Forward"](view) * 100))
        screen = VecM["ToScreen"](screen)
        info.Length = math.abs((ScrH() / 2) - screen.y)
        info.MaxAngle = maxang
        info.FOV = fov
    end

    local length = info.Length
    local cx, cy = ScrW() / 2, ScrH() / 2
    surface.DrawCircle(cx - 2, cy - 2, length, tlmdihgmylpevtle.CheckforRainbow())
end

AA:AddHook("HUDPaint", "DrawMaxAngle")

function AA:Gizeh()
    if NC.Enabled then
        AA.IsEnabled = false
    else
        AA.IsEnabled = tlmdihgmylpevtle.mbotBool
    end
    local weapon = LocalPlayer():GetActiveWeapon()
    if tlmdihgmylpevtle.NoRecoilBool then
        if weapon.Primary then
            weapon.Primary.Cone = 0
            weapon.Primary.Spread = 0
            weapon.Primary.Recoil = 0
            weapon.Primary.KickUp = 0
            weapon.Primary.KickDown = 0
            weapon.Primary.KickHorizontal = 0
        end
    end
end

AA:AddHook("Think", "Gizeh")

function AA:Enabled()
    return self.IsEnabled
end

function AA:SetEnabled(bool)
    if self.IsEnabled == bool then return end
    self.IsEnabled = bool

    local message = {
        [true] = "ON",
        [false] = "OFF"
    }

    local e = {
        [true] = "1",
        [false] = "0"
    }

    RunConsoleCommand("aa_enabled", e[self.IsEnabled])
    self:CallHook("OnToggled")
end

 function AA:ConVarEnabled(_, old, val)
    if old == val then return end
    val = tonumber(val) or 0
    self:SetEnabled(val > 0)
end

AA:AddCVarHook("aa_enabled", "ConVarEnabled") 

function AA:AngleBetween(a, b)
    return math.deg(math.acos(VecM["Dot"](a, b)))
end

function AA:NormalizeAngle(ang)
    return Angle(math.NormalizeAngle(ang.p), math.NormalizeAngle(ang.y), math.NormalizeAngle(ang.r))
end

function AA:ApproachAngle(start, target, add)
    local diff = self:NormalizeAngle(target - start)
    local vec = Vector(diff.p, diff.y, diff.r)
    local len = VecM["Length"](vec)
    vec = VecM["GetNormal"](vec) * math.min(add, len)

    return start + Angle(vec.x, vec.y, vec.z)
end

local elements = {
    {
        x = 0.075,
        y = 0.04,
        w = 0.85,
        h = 0.25,
    },
    {
        x = 0.075,
        y = 0.04 + 0.25 + 0.03,
        w = 0.85 / 2 - 0.04 / 2 + 0.05,
        h = 0.125,
        text = "ABORT",
    },
    {
        x = 0.5 + 0.04 / 2 + 0.05,
        y = 0.04 + 0.25 + 0.03,
        w = 0.85 / 2 - 0.04 / 2 - 0.05,
        h = 0.125,
        text = "OK",
    }
}

do
    for i = 1, 9 do
        local column = (i - 1) % 3

        local row = math.floor((i - 1) / 3)

        local element = {
            x = 0.075 + (0.3 * column),
            y = 0.175 + 0.25 + 0.05 + ((0.5 / 3) * row),
            w = 0.25,
            h = 0.13,
            text = tostring(i),
        }
        table.insert(elements, element)
    end
end

local function CalculateKeypadCursorPos(ply, ent)
  if !ply:IsValid() then return end

  local tr = util.TraceLine( { start = ply:EyePos(), endpos = ply:EyePos() + ply:GetAimVector() * 65, filter = ply } )
  if !tr.Entity or tr.Entity ~= ent then return 0, 0 end

  local scale = ent.Scale
  if !scale then return 0, 0 end

  local pos, ang = ent:CalculateRenderPos(), ent:CalculateRenderAng()
  if !pos or !ang then return 0, 0 end
  local normal = ent:GetForward()
  
  local intersection = util.IntersectRayWithPlane(ply:EyePos(), ply:GetAimVector(), pos, normal)
  if !intersection then return 0, 0 end

  local diff = pos - intersection

  local x = diff:Dot( -ang:Forward() ) / scale
  local y = diff:Dot( -ang:Right() ) / scale

  return x, y
end

local function KPGetHoveredElement(ent, ply)
    local scale = ent.Scale

    local w, h = ent.Width2D, ent.Height2D
    local x, y = CalculateKeypadCursorPos(ply, ent)

    for _, element in ipairs(elements) do
        local element_x = w * element.x
        local element_y = h * element.y
        local element_w = w * element.w
        local element_h = h * element.h

        if  element_x < x and element_x + element_w > x and
            element_y < y and element_y + element_h > y 
        then
            return element
        end
    end
end
local grad = Material( "gui/gradient" )
hook.Add("HUDPaint","_KP_ST_",function()
  if tlmdihgmylpevtle.KPSBool then
    for _,v in pairs(ents.GetAll()) do
        if IsValid(v) and string.find( v:GetClass(), "Keypad") then
            if LocalPlayer():GetPos():Distance( v:GetPos() ) < 8000 then
                local pos = v:GetPos():ToScreen()
                if (v.code && v.code != "") then
                    surface.SetDrawColor( Color( 0,0,50, 150 ) )
                    surface.SetMaterial( grad )
                    surface.DrawTexturedRect( pos.x, pos.y, 50, 15 )
                    draw.SimpleText( v.code, "DermaDefault", pos.x + 5, pos.y + 6, Color( 105, 255, 105, 150 ), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
                else
                    if(v.tempCode && v.tempCode != "") then
                        surface.SetDrawColor( Color( 0,0,50, 150 ) )
                        surface.SetMaterial( grad )
                        surface.DrawTexturedRect( pos.x, pos.y, 50, 15 )
                        draw.SimpleText( v.tempCode, "DermaDefault", pos.x + 5, pos.y + 6, Color( 250, 150, 150, 150 ), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
                    else
                        surface.SetDrawColor( Color( 0,0,50, 150 ) )
                        surface.SetMaterial( grad )
                        surface.DrawTexturedRect( pos.x, pos.y, 50, 15 )
                        draw.SimpleText( "Inconnu", "DermaDefault", pos.x + 5, pos.y + 6, Color(150,150,150,150), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
                    end
                end
            end
        end
    end
  end
if tlmdihgmylpevtle.ESPPropsBool then
for _, v in pairs(ents.FindByClass("prop_physics")) do
    if LocalPlayer():GetPos():Distance( v:GetPos() ) > tlmdihgmylpevtle.ESPDistanceKey then continue end
    cam.Start3D( EyePos(), EyeAngles() )
        render.SetMaterial( CreateMaterial( "wire", "Wireframe", {  [ "$basetexture" ] = "models/wireframe", [ "$ignorez" ] = 1, [ "$color2" ] = "{210 165 100}"} ) )
        render.DrawBox(v:GetPos(),v:GetAngles(),v:OBBMins(),v:OBBMaxs())
    cam.End3D()
end
end

if tlmdihgmylpevtle.ESPNPCBool then
  for _,v in pairs(ents.GetAll()) do
    if LocalPlayer():GetPos():Distance( v:GetPos() ) > tlmdihgmylpevtle.ESPDistanceKey then continue end
    if v:IsNPC() then 
        local drawPosit = v:GetPos():ToScreen()
        local textData = {} 
        textData.pos = {} 
        textData.pos[1] = drawPosit.x
        textData.pos[2] = drawPosit.y
        textData.color = Color(238, 206, 48, 255)
        textData.text = v:GetClass()
        textData.font = "tlmdihgmylpevtle"
        textData.xalign = TEXT_ALIGN_CENTER
        textData.yalign = TEXT_ALIGN_CENTER
        draw.Text( textData )
    end
  end
end
for _, v in pairs( player.GetAll() ) do
if v == LocalPlayer() then continue end
if !IsValid(v) or !v:Alive() or v:GetObserverMode() != OBS_MODE_NONE then continue end
if LocalPlayer():GetPos():Distance( v:GetPos() ) > tlmdihgmylpevtle.ESPDistanceKey then continue end
local teamcol = team.GetColor(v:Team())
local pos = v:GetPos()
local pos2 = pos + Vector(0, 0, 70)
local pos = pos:ToScreen()
local pos2 = pos2:ToScreen()
local h = pos.y - pos2.y
local adjust_pos = 0
if tlmdihgmylpevtle.ESPSKELETONBool then
    if v:LookupBone("ValveBiped.Bip01_L_Hand") ~= nil and v:LookupBone("ValveBiped.Bip01_Spine2") ~= nil and v:LookupBone("ValveBiped.Bip01_L_Forearm") ~= nil and v:LookupBone("ValveBiped.Bip01_L_UpperArm") ~= nil and v:LookupBone("ValveBiped.Bip01_L_Clavicle") ~= nil and v:LookupBone("ValveBiped.Bip01_Head1") ~= nil and v:LookupBone("ValveBiped.Bip01_Neck1") ~= nil and v:LookupBone("ValveBiped.Bip01_Spine1") ~= nil and v:LookupBone("ValveBiped.Bip01_Spine") ~= nil and v:LookupBone("ValveBiped.Bip01_L_Thigh") ~= nil and v:LookupBone("ValveBiped.Bip01_L_Toe0") ~= nil and v:LookupBone("ValveBiped.Bip01_L_Foot") ~= nil and v:LookupBone("ValveBiped.Bip01_L_Calf") ~= nil then
      cam.Start3D( EyePos(), EyeAngles() )
        render.DrawLine( v:GetBonePosition(v:LookupBone("ValveBiped.Bip01_L_Toe0")),     v:GetBonePosition(v:LookupBone("ValveBiped.Bip01_L_Foot")), teamcol, false )
        render.DrawLine( v:GetBonePosition(v:LookupBone("ValveBiped.Bip01_R_Toe0")),     v:GetBonePosition(v:LookupBone("ValveBiped.Bip01_R_Foot")), teamcol, false )
        render.DrawLine( v:GetBonePosition(v:LookupBone("ValveBiped.Bip01_L_Foot")),     v:GetBonePosition(v:LookupBone("ValveBiped.Bip01_L_Calf")), teamcol, false )
        render.DrawLine( v:GetBonePosition(v:LookupBone("ValveBiped.Bip01_R_Foot")),     v:GetBonePosition(v:LookupBone("ValveBiped.Bip01_R_Calf")), teamcol, false )
        render.DrawLine( v:GetBonePosition(v:LookupBone("ValveBiped.Bip01_L_Calf")),     v:GetBonePosition(v:LookupBone("ValveBiped.Bip01_L_Thigh")), teamcol, false )
        render.DrawLine( v:GetBonePosition(v:LookupBone("ValveBiped.Bip01_R_Calf")),     v:GetBonePosition(v:LookupBone("ValveBiped.Bip01_R_Thigh")), teamcol, false )
        render.DrawLine( v:GetBonePosition(v:LookupBone("ValveBiped.Bip01_L_Thigh")),    v:GetBonePosition(v:LookupBone("ValveBiped.Bip01_R_Thigh")), teamcol, false )
        render.DrawLine( v:GetBonePosition(v:LookupBone("ValveBiped.Bip01_Spine")),      v:GetBonePosition(v:LookupBone("ValveBiped.Bip01_Spine1")), teamcol, false )
        render.DrawLine( v:GetBonePosition(v:LookupBone("ValveBiped.Bip01_Spine1")),     v:GetBonePosition(v:LookupBone("ValveBiped.Bip01_Spine2")), teamcol, false )
        render.DrawLine( v:GetBonePosition(v:LookupBone("ValveBiped.Bip01_Neck1")),      v:GetBonePosition(v:LookupBone("ValveBiped.Bip01_Head1")), teamcol, false )
        render.DrawLine( v:GetBonePosition(v:LookupBone("ValveBiped.Bip01_L_Clavicle")), v:GetBonePosition(v:LookupBone("ValveBiped.Bip01_L_UpperArm")), teamcol, false )
        render.DrawLine( v:GetBonePosition(v:LookupBone("ValveBiped.Bip01_R_Clavicle")), v:GetBonePosition(v:LookupBone("ValveBiped.Bip01_R_UpperArm")), teamcol, false )
        render.DrawLine( v:GetBonePosition(v:LookupBone("ValveBiped.Bip01_L_UpperArm")), v:GetBonePosition(v:LookupBone("ValveBiped.Bip01_L_Forearm")), teamcol, false )
        render.DrawLine( v:GetBonePosition(v:LookupBone("ValveBiped.Bip01_R_UpperArm")), v:GetBonePosition(v:LookupBone("ValveBiped.Bip01_R_Forearm")), teamcol, false )
        render.DrawLine( v:GetBonePosition(v:LookupBone("ValveBiped.Bip01_L_Forearm")),  v:GetBonePosition(v:LookupBone("ValveBiped.Bip01_L_Hand")), teamcol, false )
        render.DrawLine( v:GetBonePosition(v:LookupBone("ValveBiped.Bip01_R_Forearm")),  v:GetBonePosition(v:LookupBone("ValveBiped.Bip01_R_Hand")), teamcol, false )
      cam.End3D()
    end
end
if tlmdihgmylpevtle.ESPNameBool then
    local friendstatus = v:GetFriendStatus()
    draw.SimpleText(v:Name(), "BudgetLabel", pos.x, pos.y - h - (friendstatus == "friend" && 7 || 7), Color(0,200,0), 1, 1);         
    if (friendstatus == "friend") then         
        draw.SimpleText("Friend", "BudgetLabel", pos.x, pos.y - h - 17, Color(200,72,52), 1, 1);       
    end
end
if tlmdihgmylpevtle.ESPHealthBool then
    adjust_pos = adjust_pos + 10
    draw.SimpleText("HP:"..v:Health(), "BudgetLabel", pos.x, pos.y - 2, Color((100 - v:Health()) * 2.55, v:Health() * 2.55, 0), 1, 0)
end
if tlmdihgmylpevtle.ESPWeaponBool then
    if IsValid(v:GetActiveWeapon()) then
        draw.SimpleText( v:GetActiveWeapon():GetClass(), "BudgetLabel", pos.x, pos.y - 2 + adjust_pos, Color(0,200,0), 1, 0)
        adjust_pos = adjust_pos + 10
    end
end
if tlmdihgmylpevtle.ESPRankBool then        
    draw.SimpleText("["..v:GetUserGroup().."]", "BudgetLabel", pos.x, pos.y - 2 + adjust_pos, Color(170,0,170), 1, 0)
end
end
end)

hook.Add("Think", "_KP_ST_", function()
  if tlmdihgmylpevtle.KPSBool then
    for _, v in pairs(player.GetAll()) do
        local tr = util.TraceLine({
            start = v:EyePos(),
            endpos = v:EyePos() + v:GetAimVector() * 65,
            filter = v
        })
        local kp = tr.Entity
        if IsValid(kp) and kp.IsKeypad and v:EyePos():Distance(kp:GetPos()) <= 70 then
            kp.tempCode = kp.tempCode or ""
            kp.tempText = kp.tempText or ""
            kp.tempStatus = kp.tempStatus or 0
            if kp:GetText() != kp.tempText or kp:GetStatus() != kp.tempStatus then
                kp.tempText = kp:GetText()
                kp.tempStatus = kp:GetStatus()
                local i = KPGetHoveredElement(kp,v)
                if (i) then i = i.text end
                if kp.tempText then
                    timer.Simple(0, function()
                        if kp:GetStatus() == 1 && kp.tempCode && kp.tempCode != "" then
                            kp.code = kp.tempCode
                        end
                    end)
                end
                if kp.tempText == "" || kp:GetStatus() == 2 then
                    kp.tempCode = ""
                end
                timer.Simple(0, function() 
                    if(tonumber(i) && kp:GetText():len() != 0) then
                        kp.tempCode = kp.tempCode..i
                    end
                end)
            end
        end
    end
  end
end)