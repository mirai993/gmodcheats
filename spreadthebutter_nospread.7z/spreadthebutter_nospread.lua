/*
	
	NoSpread.lua
	Shitty constant nospread
	REQUIRES:
		gmcl_spreadthebutter (rename it to gmcl_nospread)
		
	This was thrown together using the nospread functions from hake v2
	
	codet by tyler !11122
		
*/

require( "nospread" )

print( "Hey, are you black?" )
 
local NormalCones 			= {
	[ "weapon_cs_base" ]	= true,
	[ "weapon_zs_base" ] 	= true,
}

local HL2Cones 				= {
	[ "weapon_pistol" ] 	= Vector( 0.0100, 0.0100, 0.0100 ),
	[ "weapon_smg1" ] 		= Vector( 0.04362, 0.04362, 0.04362 ),
	[ "weapon_ar2" ]		= Vector( 0.02618, 0.02618, 0.02618 ),
	[ "weapon_shotgun" ]	= Vector( 0.08716, 0.08716, 0.08716 ),
}
local CustomCones 			= {
	[ "weapon_sh_base" ]	= function( wep )
								local Cone = wep.Primary.Cone
								local Recoil = WeaponRecoil[ wep:GetClass() ]
								local IsSniper = wep.Sniper and 2 or 1								
								local Stance = wep.Owner:IsOnGround() and wep.Owner:Crouching() and 10
								or !wep.Sprinting and wep.Owner:IsOnGround() and 15
								or wep.Walking and wep.Owner:IsOnGround() and 20
								or !wep.Owner:IsOnGround() and 25
								or wep.Primary.Ammo == "buckshot" and 0
									
								local WepType = wep.Sniper and 8
								or wep.SMG and 2
								or wep.Pistol and 2
								or wep.Primary.Ammo == "buckshot" and 0
								or 1.6								
								local Shotgun = wep.Primary.Ammo == "buckshot" and wep.Primary.Cone or 0			
								if wep:GetIronsights() then
									return Cone
								else
									return Cone * Recoil * Stance * WepType + Shotgun
								end
							end,
	[ "weapon_zs_base" ] = function( wep )
								local Cone = wep.Cone or wep.Primary.Cone or 0		
								if LocalPlayer():GetVelocity():Length() > 20 then
									return wep.ConeMoving
								end									
								if LocalPlayer():Crouching() then
									return wep.ConeCrouching
								end		
								return Cone
							end,
}
 
function GetCone( wep )
	if !IsValid( wep ) then return 0 end
	
	if HL2Cones[ wep:GetClass() ] then return HL2Cones[ wep:GetClass() ] end
	if NormalCones[ wep.Base ] then return wep.Cone or wep.Primary.Cone or 0 end
	
	local Cone = wep.Cone
	
	if !Cone then
		Cone = wep.Primary and wep.Primary.Cone or 0
	end
	
	return Cone
end

function PredictSpread( cmd, ang )
local w = LocalPlayer():GetActiveWeapon()
local vecCone, valCone = Vector( 0, 0, 0 )
	if ( w && w:IsValid() && ( type( w.Initialize ) == "function" ) ) then
		valCone = GetCone( w )                    
		if ( type( valCone ) == "number" ) then
			vecCone = Vector( -valCone, -valCone, -valCone )                      
		elseif ( type( valCone ) == "Vector" ) then
			vecCone = valCone * -1     
		elseif bit.band( cmd:GetButtons(), IN_SPEED ) or bit.band( cmd:GetButtons(), IN_JUMP ) then
			vecCone = valCone + (cone * 2 )                        
		end
	else
		if ( w:IsValid() ) then
			local class = w:GetClass()
			if ( CustomCones[ class ] ) then
				vecCone = CustomCones[ class ]
			elseif ( HL2Cones[ class ] ) then
				vecCone = HL2Cones[ class ]
			end
		end
	end
return DS_manipulateShot( DS_md5PseudoRandom( DS_getUCMDCommandNumber( cmd ) ), ang:Forward(), vecCone ):Angle()
end

local angles = Angle( 0, 0, 0 )

function GetAngles()
	if ( !ValidEntity( LocalPlayer() ) ) then return end
	angles = LocalPlayer():EyeAngles()
end

function Parkinsons( ucmd )
	angles.p = math.NormalizeAngle( angles.p )
	angles.y = math.NormalizeAngle( angles.y )
	
	local correct = 1
	angles.y = math.NormalizeAngle( angles.y + ( ucmd:GetMouseX() * -0.022 * correct ) )
	angles.p = math.Clamp( angles.p + ( ucmd:GetMouseY() * 0.022 * correct ), -89, 90 )
	ucmd:SetViewAngles( angles )
	
	if ( ucmd:GetButtons() && IN_ATTACK > 0 ) then
		local FakeAngle = PredictSpread( ucmd, angles )
		FakeAngle.p = math.NormalizeAngle( FakeAngle.p )
		FakeAngle.y = math.NormalizeAngle( FakeAngle.y )
		ucmd:SetViewAngles( FakeAngle )
	end
end

function CalcView( ply, origin, angles, FOV )
	local ply = LocalPlayer()
	local w = ply:GetActiveWeapon()
	
	local wep = ply:GetActiveWeapon()
	if wep.Primary then wep.Primary.Recoil = 0 end
	if wep.Secondary then wep.Secondary.Recoil = 0 end
	local view = GAMEMODE:CalcView( ply, origin, angles, zoomFOV ) || {}
	view.angles = angles
	view.angles.r = 0
	view.fov = zoomFOV
	return view
end

// i suggest ripping a hook system, this is shit
hook.Remove( "CalcView", "I hate making hook names", CalcView )
hook.Remove( "CreateMove", "YouHaveParkinsons", Parkinsons )