/*
ta daa.
now u can has win.
written by, Nautical ;]
btw, DIDN'T USE ANY OF ANYONE ELSES AIMBOTSCRIPTS unlike what SOME PEOPLE DO *cough z-machine cough*
sorry i said z-machine.
~~~~~~~~~~~~~
68.42.246.26    
Go team Nautical! 
~~~~~~~~~~~~~
*/

---------------------------------------------------------------------------------------------------------------------------
------------------------------------------------------infoz----------------------------------------------------------------
---------------------------------------------------------------------------------------------------------------------------
local showaim = CreateClientConVar( "nbot_showAngle", 1, true, false )
local showhead = CreateClientConVar( "nbot_showhead", 1, true, false )
local showents = CreateClientConVar( "nbot_showEntities", 0, true, false )

local showinfo = CreateClientConVar( "nbot_showinfo", 1, true, false )
local showhealth = CreateClientConVar( "nbot_showHP", 1, true, false )
local showdistance = CreateClientConVar( "nbot_showdistance", 0, true, false )
local showvis = CreateClientConVar( "nbot_showSeeYou", 0, true, false )
local showname = CreateClientConVar( "nbot_showname", 1, true, false )


local showskele = CreateClientConVar( "nbot_showskeleton", 0, true, false )
local aimfix = CreateClientConVar( "nbot_aimfixer", 1, true, false )
local autoshoot = CreateClientConVar( "nbot_autoshoot", 0, true, false )
local selectperson = CreateClientConVar( "nbot_UseSelectedPerson", 0, true, false )
local speedoffset = CreateClientConVar( "nbot_speedoffset", 8, true, false )

local Wi = LocalPlayer():BoundingRadius() * 0.5
local lastperson = nil
local trigger = 0
local enttab = {}
local zm = 0
local onlyshoot = nil
local mytext = "NBot Options - By Nautical :3|| 68.42.246.26"
---------------------------------------------------------------------------------------------------------------------------
---------------------------------------------misc hoooks-----------------------------------------------------------------
---------------------------------------------------------------------------------------------------------------------------
local function shootFixr(ply,key)

	if key == IN_ATTACK and aimfix:GetInt() >= 1 then
		local trace = LocalPlayer():GetEyeTrace()
		if trace.Entity == nil or trace.Entity == NULL then return end
		if trace.HitWorld then return end
		if LocalPlayer():GetEyeTrace().Entity:IsPlayer() then
			LocalPlayer():SetEyeAngles((trace.Entity:GetBonePosition(trace.Entity:LookupBone("ValveBiped.Bip01_Head1")) - LocalPlayer():GetShootPos()):Angle())
			timer.Simple(0.00001,function()
				return true
			end)
		else
			LocalPlayer():SetEyeAngles((trace.Entity:GetPos() - LocalPlayer():GetShootPos()):Angle())
			timer.Simple(0.00001,function()
				return true
			end)
		end
	end
end
 hook.Add( "KeyPress", "timeToShoot", shootFixr ) 
---------------------------------------------------------------------------------------------------------------------------
---------------------------------------------esp--------------------------------------------------------------------------
---------------------------------------------------------------------------------------------------------------------------
local function letsMakeAnESP()
	local midwayx = ScrW()/2
	local midwayy = ScrH()/2
	
	surface.CreateFont( "Coolvetica", 15, 500, true, false, "thenewcool" )  
	surface.SetTexture(surface.GetTextureID("models/shiny"))
	if LocalPlayer():GetEyeTrace().Entity != nil and LocalPlayer():GetEyeTrace().HitNonWorld then
		surface.SetDrawColor(255, 10, 20, 255)
		surface.DrawLine( midwayx, midwayy - 10, midwayx, midwayy + 10)
		surface.DrawLine( midwayx + 10, midwayy, midwayx - 10, midwayy)
	else
		surface.SetDrawColor(20, 255, 10, 255)
		surface.DrawLine( midwayx - 10, midwayy - 10, midwayx + 10, midwayy + 10)
		surface.DrawLine( midwayx + 10, midwayy + 10, midwayx - 10, midwayy - 10)	
	end
	
	local dist
	local var
	local n_head 
	for k,v in pairs (ents.GetAll()) do
		dist = v:GetPos():Distance(LocalPlayer():GetPos())
		var = math.Clamp(dist, 4, 20)
		local filter = string.sub(v:GetClass(), 1,4)
		if (v:IsPlayer()) and (v:Alive() == true) and (v:EntIndex() != LocalPlayer():EntIndex()) then
			n_head = v:GetBonePosition(v:LookupBone("ValveBiped.Bip01_Head1")):ToScreen() 
			local w, h = surface.GetTextSize( v:Nick() )
			local aw = w / 2
			local pos, ang = n_head

			local frwrd = (v:EyePos() + (v:GetAimVector() * 200)):ToScreen()
			local eyeone = n_head //yeah, started out trying to get the two eye positions, quicker doin it this way.
			local eyetwo = v:GetBonePosition(v:LookupBone("ValveBiped.Bip01_Pelvis")):ToScreen() 
			local vteam = v:Team()
			local teamcol = team.GetColor(vteam)
			local teamnam = team.GetName(vteam)
			
			if showinfo:GetInt() >= 1 then
				if showname:GetInt() >= 1 then
					draw.SimpleText( v:Nick().." - "..teamnam, "thenewcool", pos.x - aw, pos.y + 18 , teamcol)
				end
				if showhealth:GetInt() >= 1 then
					draw.SimpleText("HP:"..v:Health(), "thenewcool", pos.x - aw, pos.y + 29 , Color(60,70,255,255))
				end
				if showdistance:GetInt() >= 1 then
					draw.SimpleText("Distance: "..tostring(v:GetPos():Distance(LocalPlayer():GetPos())), "thenewcool", pos.x - aw, pos.y + 40 , Color(255,70,70,255))
				end
				if showvis:GetInt() >= 1 then
					draw.SimpleText("Can they see you?: "..CanVictimSeeUs(v), "thenewcool", pos.x - aw, pos.y + 51, Color(255,255,70,255))
				end
			end
			
			if CanVictimSeeUs(v) == "YES!!!" then
				surface.SetDrawColor( 255, 10, 25, 255 )
				//view angles
				if showaim:GetInt() >= 1 then
					surface.DrawLine( eyeone.x, eyeone.y, eyetwo.x, eyetwo.y)
					surface.DrawLine( eyeone.x, eyeone.y, frwrd.x, frwrd.y)
					surface.DrawLine( eyetwo.x, eyetwo.y, frwrd.x, frwrd.y)
				end
				//target
				if showhead:GetInt() >= 1 then
					surface.DrawLine( pos.x + 10, pos.y, pos.x - 10, pos.y)
					surface.DrawLine( pos.x, pos.y + 10, pos.x, pos.y - 10)
				end
			else
				surface.SetDrawColor( 0, 255, 0, 255 )	
				//view angles
				if showaim:GetInt() >= 1 then
					surface.DrawLine( eyeone.x, eyeone.y, eyetwo.x, eyetwo.y)
					surface.DrawLine( eyeone.x, eyeone.y, frwrd.x, frwrd.y)
					surface.DrawLine( eyetwo.x, eyetwo.y, frwrd.x, frwrd.y)
				end
				//target
				if showhead:GetInt() >= 1 then
					surface.DrawLine( pos.x + 10, pos.y, pos.x - 10, pos.y)
					surface.DrawLine( pos.x, pos.y + 10, pos.x, pos.y - 10)
				end
			end
			--surface.DrawOutlinedRect( pos.x, pos.y, var, var ) ......lolzno.
		elseif v:IsNPC() and v:Health() > 1 then 
			local pos = v:GetBonePosition(v:LookupBone("ValveBiped.Bip01_Head1")):ToScreen() 
			surface.DrawLine( pos.x + 10, pos.y, pos.x - 10, pos.y)
			surface.DrawLine( pos.x, pos.y + 10, pos.x, pos.y - 10)
		elseif showents:GetInt() >= 1 and nFilter(filter) == true then 
			// ROFLROFLROFL
				local pos = v:LocalToWorld(v:OBBCenter()):ToScreen()
				local w, h = surface.GetTextSize( v:GetClass() )
				local aw = w / 2
				surface.SetDrawColor( 0, 112, 255, 255 )
				draw.SimpleText( v:GetClass(), "thenewcool", pos.x - aw, pos.y + 18 , Color(0,112,255))

				surface.DrawLine( pos.x + 2, pos.y, pos.x - 2, pos.y)
				surface.DrawLine( pos.x, pos.y + 2, pos.x, pos.y - 2)
			end
		end
	end
 hook.Add("HUDPaintBackground", "myEsp", letsMakeAnESP)

local function skeleton()
	//hehe skeletable!
	//note; this will get CONFUSING ;/
	if showskele:GetInt() >= 1 then
		surface.SetDrawColor( 10, 30, 255, 255 )
		local skelecore = {
		"ValveBiped.Bip01_Head1", //core
		"ValveBiped.Bip01_Neck1", 
		"ValveBiped.Bip01_Spine4",
		"ValveBiped.Bip01_Spine2",
		"ValveBiped.Bip01_Spine1",
		"ValveBiped.Bip01_Spine"
		}	
		local skelearm_R = {
		"ValveBiped.Bip01_Neck1",
		"ValveBiped.Bip01_R_UpperArm", //right arm
		"ValveBiped.Bip01_R_Forearm", 
		"ValveBiped.Bip01_R_Hand"
		}
		local skelearm_L = {
		"ValveBiped.Bip01_Neck1",
		"ValveBiped.Bip01_L_UpperArm",//left arm
		"ValveBiped.Bip01_L_Forearm",
		"ValveBiped.Bip01_L_Hand"
		}
		local skeleleg_R = {
		"ValveBiped.Bip01_Spine",
		"ValveBiped.Bip01_R_Thigh",//right leg
		"ValveBiped.Bip01_R_Calf",
		"ValveBiped.Bip01_R_Foot",
		"ValveBiped.Bip01_R_Toe0"
		}
		local skeleleg_L = {
		"ValveBiped.Bip01_Spine",
		"ValveBiped.Bip01_L_Thigh",//left leg
		"ValveBiped.Bip01_L_Calf",
		"ValveBiped.Bip01_L_Foot",
		"ValveBiped.Bip01_L_Toe0"
		}
		local curbone
		local nextbone
		for k,v in pairs (ents.GetAll()) do	
			if (v:IsPlayer()) and (v:Alive() == true) and (v:EntIndex() != LocalPlayer():EntIndex()) then
				-----------------------------core-----------------------------
				for n,b in pairs(skelecore) do
					curbone = v:GetBonePosition(v:LookupBone(b)):ToScreen()
					nextbone = v:GetBonePosition(v:LookupBone(tostring(skelecore[n+1]))):ToScreen()
					surface.DrawLine( curbone.x, curbone.y, nextbone.x, nextbone.y)
				end
				-----------------------------arms-----------------------------
				for n,b in pairs(skelearm_R) do
					curbone = v:GetBonePosition(v:LookupBone(b)):ToScreen()
					nextbone = v:GetBonePosition(v:LookupBone(tostring(skelearm_R[n+1]))):ToScreen()
					surface.DrawLine( curbone.x, curbone.y, nextbone.x, nextbone.y)
				end
				for n,b in pairs(skelearm_L) do
					curbone = v:GetBonePosition(v:LookupBone(b)):ToScreen()
					nextbone = v:GetBonePosition(v:LookupBone(tostring(skelearm_L[n+1]))):ToScreen()
					surface.DrawLine( curbone.x, curbone.y, nextbone.x, nextbone.y)
				end
				-----------------------------legs-----------------------------
				for n,b in pairs(skeleleg_R) do
					curbone = v:GetBonePosition(v:LookupBone(b)):ToScreen()
					nextbone = v:GetBonePosition(v:LookupBone(tostring(skeleleg_R[n+1]))):ToScreen()
					surface.DrawLine( curbone.x, curbone.y, nextbone.x, nextbone.y)
				end
				for n,b in pairs(skeleleg_L) do
					curbone = v:GetBonePosition(v:LookupBone(b)):ToScreen()
					nextbone = v:GetBonePosition(v:LookupBone(tostring(skeleleg_L[n+1]))):ToScreen()
					surface.DrawLine( curbone.x, curbone.y, nextbone.x, nextbone.y)
				end
			end
		end
	end
 end
 hook.Add("HUDPaintBackground", "DrawSkel", skeleton)
  
 ---------------------------------------------------------------------------------------------------------------------------
 -----------------------------------------------visual checks/other global functions--------------------------------------------
 ---------------------------------------------------------------------------------------------------------------------------
 
 function HasVictimLOS(t)//ehm, i can't remember if i made this or not, but if i didn't, thanks whoever made it :( srrsly.
	local tr = util.TraceLine(
	{
		start 	= LocalPlayer():GetPos(),
		endpos 	= t:LocalToWorld( t:OBBCenter() ),
		filter 	= { LocalPlayer() },
		mask 	= CONTENTS_SOLID | CONTENTS_OPAQUE | CONTENTS_MOVEABLE 
	} )
	if tr.Fraction > 0.98 then return true end
	return false
end

 function CanVictimSeeUs(t)
 
	if not HasVictimLOS(t) then return "Nope..." end

	local fov = t:GetFOV()
	local Disp = LocalPlayer():GetPos() - t:GetPos()
	local Dist = Disp:Length()
	
	local MaxCos = math.abs( math.cos( math.acos( Dist / math.sqrt( Dist * Dist + Wi * Wi ) ) + fov * ( math.pi / 180 ) ) )
	Disp:Normalize()

	if Disp:Dot( t:EyeAngles():Forward() ) > MaxCos then
		return "YES!!!"
	end
	
	return "Nope..."
	
end

function checkVicts(t)
	for k,v in pairs(enttab) do
		if v:EntIndex() == t:EntIndex() then
			return true
		else
			return false
		end
	end
end

function nFilter(txt)
	local p 
	for k,v in pairs {"prop", "env_", "func", "clas", "phys", "weap", "gmod", "keys",  "beam", "lett","poin", "gun_", "tase", "lock", "door", "play", "view" } do 
		if txt != v then
			p = true
		else
			return false
		end
	end
	if p then
		return true
	end
end
---------------------------------------------------------------------------------------------------------------------------
-------------------------------------------aim functions/command controls----------------------------------------------
---------------------------------------------------------------------------------------------------------------------------
local function cmdOn(ply,command,args)	
	if selectperson:GetInt() >= 1 then
		if onlyshoot != nil then
			lastperson = onlyshoot
			trigger = 1
		else
			LocalPlayer():PrintMessage(HUD_PRINTTALK, "You havn't selected anyone yet!")
		end
	return
	end

	local perA
	
	local lenA
	local lenV
	for m,p in pairs(enttab) do
		table.remove(enttab, m)
	end
	if not #enttab != 0 then
		for k,v in pairs(player.GetAll()) do
			if v:EntIndex() != LocalPlayer():EntIndex() then
				table.insert(enttab, v)
			end
		end
	end
	trigger = 1
	for k,v in pairs(enttab) do
		if perA == nil then
			perA = v
			lenA = math.Dist(perA:GetPos():ToScreen().x, perA:GetPos():ToScreen().y, ScrW()/2, ScrH()/2)
		else 
		lenV = math.Dist(v:GetPos():ToScreen().x, v:GetPos():ToScreen().y, ScrW()/2, ScrH()/2)		
			if lenV < lenA then
				perA = v
				lenA = math.Dist(perA:GetPos():ToScreen().x, perA:GetPos():ToScreen().y, ScrW()/2, ScrH()/2)
			end
		end
		lastperson = perA
/*		if lastperson == nil or lastperson == NULL then
			LocalPlayer():PrintMessage(HUD_PRINTTALK, "No one else on the map! :P")
			trigger = 0
			return
		end
*/
	end
end

local function cmdOff(ply,command,args)
	trigger = 0
end
concommand.Add("+nBot", cmdOn)	
concommand.Add("-nBot", cmdOff)

function beginAim(ply,command,args) // where the magic happens
	if trigger == 1 then 
		local compensate = lastperson:GetBonePosition(lastperson:LookupBone("ValveBiped.Bip01_Head1")) + (lastperson:GetVelocity() * (speedoffset:GetInt()/lastperson:GetVelocity():Length()))
		angle = (compensate - LocalPlayer():GetShootPos()):Angle()
		LocalPlayer():SetEyeAngles(angle)
	end
	if autoshoot:GetInt() >= 1 then
		if LocalPlayer():GetEyeTrace().PhysicsBone == 10 then
			LocalPlayer():ConCommand("+attack")
		else
			LocalPlayer():ConCommand("-attack")
		end
	end
end

hook.Add("Think", "catchme", beginAim)

---------------------------------------------------------------------------------------------------------------------------
-----------------------------------------------------vgui/options---------------------------------------------------------
---------------------------------------------------------------------------------------------------------------------------
local pan
local function showPanel()
	
	panel = vgui.Create( "DFrame" )
	panel:SetPos( 50, 50)
	panel:SetSize(382, 280)
	panel:SetTitle( mytext )
	panel:SetVisible( true )
	panel:SetDraggable( true )
	panel:ShowCloseButton( true )
	panel:SetSizable(true)
	panel:MakePopup()
	pan = panel
	local w = panel:GetWide()
	local h =  panel:GetTall()
	
	local PropertySheet = vgui.Create( "DPropertySheet" )
	PropertySheet:SetParent( panel )
	PropertySheet:SetPos( 5, 30 )
	PropertySheet:SetSize( w-10, h-35 ) 
	
//begin esp
	local ESP = vgui.Create( "DPanel", PropertySheet )
	ESP:SetSize( w-20, h-45 )
	ESP.Paint = function()
		surface.SetDrawColor( 171, 171, 171, 255 )
		surface.DrawRect( 0, 0, ESP:GetWide(), ESP:GetTall() )
	end
	
	local cbox1 = vgui.Create( "DCheckBoxLabel", ESP )
	cbox1:SetPos( 10,10 )
	cbox1:SetText( "Show Skeleton" )
	cbox1:SetConVar( "nbot_showskeleton" ) 
	cbox1:SetValue( showskele:GetInt() )
	cbox1:SizeToContents() 
	
	local cbox2 = vgui.Create( "DCheckBoxLabel", ESP )
	cbox2:SetPos( 10,30 )
	cbox2:SetText( "Show Head Marker" )
	cbox2:SetConVar( "nbot_showhead" ) 
	cbox2:SetValue( showhead:GetInt() )
	cbox2:SizeToContents() 
	
	local cbox3 = vgui.Create( "DCheckBoxLabel", ESP )
	cbox3:SetPos( 10,50 )
	cbox3:SetText( "Show View Angle" )
	cbox3:SetConVar( "nbot_ShowAngle" ) 
	cbox3:SetValue( showaim:GetInt() )
	cbox3:SizeToContents() 
	
	local cbox9 = vgui.Create( "DCheckBoxLabel", ESP )
	cbox9:SetPos( 10,70 )
	cbox9:SetText( "Show Entites" )
	cbox9:SetConVar( "nbot_ShowEntities" ) 
	cbox9:SetValue( showents:GetInt() )
	cbox9:SizeToContents()
	
//begin text
	local TEXT = vgui.Create( "DPanel", PropertySheet )
	TEXT:SetSize( w-20, h-45 )
	TEXT.Paint = function()
		surface.SetDrawColor( 171, 171, 171, 255 )
		surface.DrawRect( 0, 0, TEXT:GetWide(), TEXT:GetTall() )
	end
	
	local cbox4 = vgui.Create( "DCheckBoxLabel", TEXT )
	cbox4:SetPos( 10,10 )
	cbox4:SetText( "Show Any Text Info." )
	cbox4:SetConVar( "nbot_showinfo" ) 
	cbox4:SetValue( showinfo:GetInt() )
	cbox4:SizeToContents()
	
	local cbox5 = vgui.Create( "DCheckBoxLabel", TEXT )
	cbox5:SetPos( 10,30 )
	cbox5:SetText( "Can they see you? " )
	cbox5:SetConVar( "nbot_ShowSeeYou" ) 
	cbox5:SetValue( showvis:GetInt()*showinfo:GetInt() )
	cbox5:SizeToContents()
	
	local cbox6 = vgui.Create( "DCheckBoxLabel", TEXT )
	cbox6:SetPos( 10,50 )
	cbox6:SetText( "Show HP" )
	cbox6:SetConVar( "nbot_ShowHP" ) 
	cbox6:SetValue( showhealth:GetInt()*showinfo:GetInt() )
	cbox6:SizeToContents()
	
	local cbox7 = vgui.Create( "DCheckBoxLabel", TEXT )
	cbox7:SetPos( 10,70 )
	cbox7:SetText( "Show Distance" )
	cbox7:SetConVar( "nbot_showdistance" ) 
	cbox7:SetValue( showdistance:GetInt()*showinfo:GetInt() )
	cbox7:SizeToContents()
	
	local cbox8 = vgui.Create( "DCheckBoxLabel", TEXT )
	cbox8:SetPos( 10,90 )
	cbox8:SetText( "Show Name" )
	cbox8:SetConVar( "nbot_showname" ) 
	cbox8:SetValue( showname:GetInt()*showinfo:GetInt() )
	cbox8:SizeToContents()
	--cbox9 is up top, for orginizational sake.
	
//begin aim/shoot
	local AIMSHOOT = vgui.Create( "DPanel", PropertySheet )
	AIMSHOOT:SetSize( w-20, h-45 )
	AIMSHOOT.Paint = function()
		surface.SetDrawColor( 171, 171, 171, 255 )
		surface.DrawRect( 0, 0, AIMSHOOT:GetWide(), AIMSHOOT:GetTall() )
	end
	
	local cbox10 = vgui.Create( "DCheckBoxLabel", AIMSHOOT )
	cbox10:SetPos( 10,50 )
	cbox10:SetText( "Fix your aim (The little of which I can)" )
	cbox10:SetConVar( "nbot_aimfixer" ) 
	cbox10:SetValue( aimfix:GetInt() )
	cbox10:SizeToContents()
		
	local cbox11 = vgui.Create( "DCheckBoxLabel", AIMSHOOT )
	cbox11:SetPos( 10,70 )
	cbox11:SetText( "Auto Shoot" )
	cbox11:SetConVar( "nbot_autoshoot" ) 
	cbox11:SetValue( autoshoot:GetInt() )
	cbox11:SizeToContents()
	
	local cbox12 = vgui.Create( "DCheckBoxLabel", AIMSHOOT )
	cbox12:SetPos( 10,90 )
	cbox12:SetText( "Only Aim at This Person" )
	cbox12:SetConVar( "nbot_UseSelectedPerson" ) 
	cbox12:SetValue( selectperson:GetInt() )
	cbox12:SizeToContents()
	
	local DermaListView = vgui.Create("DListView")
	DermaListView:SetParent(AIMSHOOT)
	DermaListView:SetPos(10, 110)
	DermaListView:SetSize(w-40, h-180)
	DermaListView:SetMultiSelect(false)
	DermaListView:AddColumn("Player")
	for k,v in pairs(player.GetAll()) do
		DermaListView:AddLine(v:Nick()) // Add column
	end	
	DermaListView.OnRowSelected = function()
	local selected = DermaListView:GetLine(DermaListView:GetSelectedLine()):GetValue(1)
		for k,v in pairs(player.GetAll()) do
			if v != LocalPlayer() then
				if v:Nick() == selected then
				onlyshoot = v
				end
			end
		end
	end
	
    local NumSliderThingy = vgui.Create( "DNumSlider", AIMSHOOT )
	NumSliderThingy:SetPos(10, 10)
	NumSliderThingy:SetSize( w-30, 40 ) // Keep the second number at 100
	NumSliderThingy:SetText( "Speed Offset (Default is *8*-11, works pretty well for bullets.)" )
	NumSliderThingy:SetMin( 1 ) // Minimum number of the slider
	NumSliderThingy:SetMax( 200 ) // Maximum number of the slider
	NumSliderThingy:SetDecimals( 0 ) // Sets a decimal. Zero means it's a whole number
	NumSliderThingy:SetConVar( "nbot_speedoffset" ) // Set the convar 

//begin instruction
	local INSTRUCTION = vgui.Create( "DPanel", PropertySheet )
	INSTRUCTION:SetSize( w-20, h-45 )
	INSTRUCTION.Paint = function()
		surface.SetDrawColor( 171, 171, 171, 255 )
		surface.DrawRect( 0, 0, INSTRUCTION:GetWide(), INSTRUCTION:GetTall() )
	end
	INSTRUCTION.Label1 = vgui.Create("Label", INSTRUCTION)
	INSTRUCTION.Label1:SetPos(10,10)
	INSTRUCTION.Label1:SetText([[Hello Peoples!
	Nautical's NBot is a simple aimbot, to be used in most servers/gamemodes. 
	NBot will not work with script enforcer *tear* so if it's 
	on in this server, you wouldn't be reading this! :3
	TO USE: 
	-Bind a key to "+nBot", for example 'c'; bind c +nBot
	
	-Bind a key to +nBot_Options, like above.
	
	-Hold down your +nBot_Options key to view the aimbot options, and 
	customize it!
	
	-Hold down your +nBot_aimon to aim twards the person you're 
	closest to aiming at, or if you have any other options on,
	it will aim at your selected settings.
	]])
	INSTRUCTION.Label1:SizeToContents() 

	PropertySheet:AddSheet( "Aiming and Shooting", AIMSHOOT, "gui/silkicons/key", false, false, "Aiming and Shooting Options" )
	PropertySheet:AddSheet( "ESP", ESP, "gui/silkicons/world", false, false, "Extra Sensory Perception Options" )
	PropertySheet:AddSheet( "Text", TEXT, "gui/silkicons/magnifier", false, false, "Text Options" ) 
	PropertySheet:AddSheet( "Instruction", INSTRUCTION, "gui/silkicons/wrench", false, false, "Need help?" )
end


local function hidePanel()
	if pan:IsVisible() then
		pan:Close()
	end
end
concommand.Add("+nbot_Options", showPanel)
concommand.Add("-nbot_Options", hidePanel)
