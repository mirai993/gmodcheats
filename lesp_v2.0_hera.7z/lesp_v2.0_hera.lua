--[[
	MOD/lua/autorun/client/lesp.lua [#93877 (#96708), 1073988030]
	wegweg | STEAM_0:1:9769081 <90.184.179.6:1024> | [29.12.13 03:57:54PM]
	===BadFile===
]]

--[[

-================================-


lesp v4 - A Garry's Mod aimbot [Multi-Hack]


-================================-

]]--


/************************************
Name: Localizing
Purpose: Make the cheat run faster
************************************/

local g 					= table.Copy(_G)

local lesp					= {} -- Nothing!
lesp.settings				= {} -- Not started yet.
lesp.hooks					= {} -- Store hooks in a table
lesp.concommands			= {} -- Store concommands in a table
lesp.convars				= {} -- Store the ConVars in a table
lesp.timers					= {} -- Store Timers in a table
lesp.cones					= { normal = {}, hl2 = {}, custom = {}} -- I probably won't even need this, I won't have NoSpread for a long time. Anyways, store cones here.
lesp.files					= {"LESP.lua","Log.txt"} -- Files to hide and protect
lesp.version				= "2.0" -- Version of the cheat.
lesp.ents					= { -- ents to be picked up by entity esp, add more if you want.
"ent_pot",
"npc_vendor",
"weapon_perp_glock",
"ent_item",
"ent_prop_item",
"sent_spawnpoint",
"spawned_weapon",
"spawned_shipment",
"weed_plant",
"gift",
"spawned_money",
"base_item",
"weapon_ak47_dayz",
"weapon_mp5_dayz",
"weapon_deagle_dayz",
"sapphire_money_printer",
"amethyst_money_printer",
"topaz_money_printer",
"emerald_money_printer",
"msc_scrapnug",
"food_rawant",
"ent_resource",
"food_rawhead",
"gmodz_item", -- TPS DayZ
}
lesp.dontlog				= { -- commands to be ignored by the runconsolecommand logger
"+jump",
"-jump", 
"+attack", 
"-attack", 
"impulse"
} 
lesp.badcmds				= { -- commands to be blocked
"__ac",
"__imacheater",
"gm_possess",
"achievementRefresh", -- fuck u lifepunch
"__uc_", -- RIOT
"_____b__c",
"___m",
"sc",
"bg",
"bm",
"kickme",
"gw_iamacheater",
"imafaggot",
"birdcage_browse",
"reportmod",
"_fuckme",
"st_openmenu",
"_NOPENOPE",
"__ping",
"ar_check",
"GForceRecoil",
"~__ac_auth",
"blade_client_check",
"blade_client_detected_message",
"disconnect",
"exit",
"retry",
"kill",
"-voicerecord",
"+voicerecord",
"dac_imcheating", -- fuck u bich
"dac_pleasebanme", -- fuck u bich
}
lesp.invalidents			= {"player","prop_physics","viewmodel",} -- Ents to not show on the ESP
lesp.weapons				= {["weapon_crossbow"] = 3110,}
lesp.spectators				= {} -- Store spectators here.
lesp.admins					= {} -- store admins here
lesp.config					= {} -- user config

local colors				= {}
red							= Color(255,0,0,255);
black						= Color(0,0,0,255);
green						= Color(0,255,0,255);
white						= Color(255,255,255,255);
blue						= Color(0,0,255,255);
cyan						= Color(0,255,255,255);
pink 						= Color(255,0,255,255);
blue						= Color(0,0,255,255);
grey						= Color(100,100,100,255);
gold						= Color(255,228,0,255);
lblue						= Color(155,205,248);
lgreen						= Color(174,255,0);
iceblue						= Color(116,187,251,255);

local _G					= table.Copy(_G)

local math 					= _G.math
local string 				= _G.string
local hook 					= _G.hook
local table 				= _G.table
local timer 				= _G.timer
local surface 				= _G.surface
local concommand 			= _G.concommand
local cvars 				= _G.cvars
local ents 					= _G.ents
local player 				= _G.player
local team 					= _G.team
local util 					= _G.util
local draw 					= _G.draw
local usermessage 			= _G.usermessage
local vgui 					= _G.vgui
local http 					= _G.http
local cam 					= _G.cam
local render 				= _G.render

local MsgN 					= _G.MsgN
local Msg 					= _G.Msg
local Vector 				= _G.Vector
local Angle 				= _G.Angle
local pairs 				= _G.pairs
local ipairs 				= _G.ipairs
local CreateSound 			= _G.CreateSound
local setmetatable 			= _G.setmetatable
local Sound 				= _G.Sound
local print 				= _G.print
local pcall 				= _G.pcall
local type 					= _G.type
local LocalPlayer 			= _G.LocalPlayer
local KeyValuesToTable 		= _G.KeyValuesToTable
local TableToKeyValues 		= _G.TableToKeyValues
local Color 				= _G.Color
local CreateClientConVar 	= _G.CreateClientConVar
local ErrorNoHalt 			= _G.ErrorNoHalt
local IsValid 				= _G.IsValid
local CreateMaterial 		= _G.CreateMaterial
local tonumber 				= _G.tonumber
local tostring 				= _G.tostring
local CurTime			 	= _G.CurTime
local FrameTime 			= _G.FrameTime
local ScrW 					= _G.ScrW
local ScrH 					= _G.ScrH
local SetClipboardText 		= _G.SetClipboardText
local GetHostName 			= _G.GetHostName
local unpack 				= _G.unpack
local AddConsoleCommand 	= _G.AddConsoleCommand 
local require				= _G.require
local include				= _G.include

local MOVETYPE_OBSERVER 	= _G.MOVETYPE_OBSERVER
local MOVETYPE_NONE 		= _G.MOVETYPE_NONE
local TEXT_ALIGN_LEFT 		= _G.TEXT_ALIGN_LEFT
local TEXT_ALIGN_TOP 		= _G.TEXT_ALIGN_TOP
local TEXT_ALIGN_RIGHT 		= _G.TEXT_ALIGN_RIGHT
local TEXT_ALIGN_BOTTOM		= _G.TEXT_ALIGN_BOTTOM
local IN_JUMP 				= _G.IN_JUMP
local IN_FORWARD 			= _G.IN_FORWARD
local IN_BACK 				= _G.IN_BACK
local IN_MOVERIGHT 			= _G.IN_MOVERIGHT
local IN_MOVELEFT 			= _G.IN_MOVELEFT
local IN_SPEED 				= _G.IN_SPEED
local IN_DUCK 				= _G.IN_DUCK
local TEAM_SPECTATOR 		= 1002

-- old [detour]
local old_filecdir 			= file.CreateDir;
local old_filedel 			= file.Delete;
local old_fileexist 		= file.Exists;
local old_fileexistex 		= file.ExistsEx;
local old_filefind 			= file.Find;
local old_filefinddir 		= file.FindDir;
local old_filefindil 		= file.FindInLua;
local old_fileisdir			= file.IsDir;
local old_fileread 			= file.Read;
local old_filerename 		= file.Rename;
local old_filesize 			= file.Size;
local old_filetfind			= file.TFind;
local old_filetime 			= file.Time;
local old_filewrite 		= file.Write;
local old_dbginfo 			= debug.getinfo;
local old_dbginfo 			= debug.getupvalue;
local old_cve 				= ConVarExists;
local old_gcv 				= GetConVar;
local old_gcvn 				= GetConVarNumber;
local old_gcvs 				= GetConVarString;
local old_rcc 				= RunConsoleCommand;
local old_hookadd			= hook.Add;
local old_hookrem 			= hook.Remove;
local old_ccadd				= concommand.Add;
local old_ccrem 			= concommand.Remove;
local old_cvaracc 			= cvars.AddChangeCallback;
local old_cvargcvc 			= cvars.GetConVarCallbacks;
local old_cvarchange 		= cvars.OnConVarChanged;
local old_require			= require;
local old_eccommand 		= engineConsoleCommand;

--Fonts--
surface.CreateFont("ESPFont",{font = "ScoreboardText", size = 17, weight = 400, antialias = 0})
surface.CreateFont("ESPFont_Small",{font = "Default", size = 13, weight = 200, antialias = 0})
surface.CreateFont("Logo",{font = "akbar", size = 21, weight = 400, antialias = 0})
surface.CreateFont("lesp_ScoreboardText",{font = "ScoreboardText", size = 15, weight = 700, antialias = 0})
surface.CreateFont("lesp_coolvetica",{font = "coolvetica", size = 16, weight = 500, antialias = 0})
surface.CreateFont("lesp_hvh",{font = "ScoreboardTextt", size = 15, weight = 1000, antialias = 1})


g.rawset(_G, "RunConsoleCommand", oRunConsoleCommand) 

--Materials--
function lesp:CreateMaterial()
local BaseInfo = {
["$basetexture"] = "models/debug/debugwhite",
["$model"]       = 1,
["$translucent"] = 1,
["$alpha"]       = 1,
["$nocull"]      = 1,
["$ignorez"]	 = 1
}	
local mat	
if GetConVarString("lesp_ESP_Chams_Material") == "Solid" then
	mat = CreateMaterial( "lesp_solid", "VertexLitGeneric", BaseInfo )
elseif GetConVarString("lesp_ESP_Chams_Material") == "Wireframe" then
	mat = CreateMaterial( "lesp_wire", "Wireframe", BaseInfo )
end
   return mat
end

/**************************************
Name: Logger
Purpose: Logs functions and shit
**************************************/
concommand.Add("lesp_StartLog",function()
file.Write("lesp/log.txt","Log created: ("..os.date()..") \n")
end)

function Log(msg)
file.Append("lesp/log.txt","["..os.date().."]: "..msg.."\n")
end
Log("Loading....")


/*******************************************
Name: Print/Chat functions
Purpose: Notify the user of what's going on
********************************************/
function lesp.Print(msg)
	--print("[lesp] "..msg) Disabled due to spam
end

function lesp.Notify(dosound,col,msg)
	if col then
		col = col
	end
chat.AddText(
iceblue, "[LESP] ",
col, msg)
	if dosound == sound then
		local beep = Sound( "/buttons/button17.wav" )
		local beepsound = CreateSound( LocalPlayer(), beep )
		beepsound:Play()
	end
end

/***********************************************
Name: Hook functions
Purpose: Add hooks and protect from anticheats
************************************************/

-- Addhook
local function AddHook(Type,Function)
	Name = Type.." | "..math.random(1,1000),math.random(1,2000),math.random(1,3000) -- Simple hook names
	lesp.Print("[ADDED] Hook: ["..Type.."] | Name: "..Name.."")
	return old_hookadd(Type,Name,Function)
end

-- RemoveHook
local function RemoveHook(Type,Function)
	lesp.Print("[REMOVED] Hook: ["..Type.."]")
	return old_hookrem(Type,Function)
end

/**********************************
Name: File Shit
Purpose: Anything relating to file.
***********************************/
-- Write file
function AddFile(Name,Data)
	lesp.Print("[WROTE] File: "..Name.."")
	return old_filewrite(Name,Data)
end

/**************
Random String
**************/
function RandomString( len )
	local ret = ""
		for i = 1 , len do
			ret = ret .. string.char( math.random( 65 , 116 ) )
        end
	return ret
end

/**********************
Name: Timer shit
Purpose: Anything timer
***********************/
function AddTimer( sec, rep, func )
	local index = RandomString( 10 )	
	lesp.timers[ index ] = sec	
	timer.Create( index, sec, rep, func )
end

/******************************************
Name: ConCommand Shit
Purpose: Anything related to concommands
********************************************/

function AddCMD(Name,Function)
	lesp.Print("[ADDED] ConCommand: "..Name.."")
	return old_ccadd(Name,Function)
end

function RemoveCMD(Name)
	lesp.Print("[REMOVED] ConCommand: "..Name.."")
	return old_ccrem(Name)
end

/*******************************************
Name: ConVars
Purpose: Anything with ConVars
********************************************/

-- AddConVar
function AddConVar(convar,str,save,data)
	return CreateClientConVar("lesp_"..convar,str,true,false), lesp.Print("[ADDED] ConVar: lesp_"..convar.." ["..str.."]")
end

/***************************************
Name: RunConsoleCommand shit
Purpose: Detours, Loggers, blockers
****************************************/

function RunConsoleCommand(cmd,...)
	if !table.HasValue(lesp.dontlog, cmd) then
		lesp.Print("RunConsoleCommand: "..cmd)
		Log("RunConsoleCommand: "..cmd)
	end
	if !table.HasValue(lesp.badcmds,cmd) then 
		return old_rcc(cmd,...)
	else
		lesp.Notify(sound,red,"Blocked command: "..cmd)
		Log("BLOCKED COMMAND: "..cmd)
		return
	end
end

/**************************************
Name: Entity Shit
Purpose: Anything to do with entities
***************************************/
-- entity finder [addent]
function AddEnt(entclass)
	if(!table.HasValue(lesp.ents,entclass)) then
		table.insert(lesp.ents,entclass)
		lesp.Print("[ADDED] Ent: "..entclass.." to ESP")
		file.Write("lesp/ents.txt", glon.encode( lesp.ents ))
	end
end

-- entity finder [removeent]
function RemoveEnt(entclass)
	for k, v in pairs(lesp.ents) do
		if(string.Trim(v) == entclass) then
			lesp.ents[k] = nil
			lesp.Print("[REMOVED] Ent: "..entclass.." from the ESP")
		end
	end
	file.Write("lesp/ents.txt", glon.encode( lesp.ents ))
end

-- entity finder [clear ents]
function ClearEnts()
	lesp.ents = {}
	file.Write("lesp/ents.txt", glon.encode( lesp.ents ))
end

-- entity finder [IsCustomEnt()]
function IsCustomEnt( entclass )
	return table.HasValue( lesp.ents, entclass )
end


/**************************
Name: Derma shit
Purpose: Anything Derma
***************************/
function AddCheckBox( text, cvar, parent, x, y, tt )
local checkbox = vgui.Create( "DCheckBoxLabel", parent )
checkbox:SetPos( x, y )
checkbox:SetText( text )
checkbox:SetConVar( cvar )
checkbox:SetTextColor(white)
checkbox:SetTooltip( tt or "No Tool Tip" )
checkbox:SizeToContents()	
end

// AddSlider for the derma
function AddSlider( text, cvar, parent, min, max, decimals, x, y, wide, tt )
local slider = vgui.Create( "DNumSlider" )
slider:SetParent( parent )
slider:SetPos( x, y )
slider:SetWide( wide )
slider:SetText( text )
--slider:SetTextColor(BLACK)
slider:SetMin( min ) 
slider:SetMax( max ) 
slider:SetDecimals( decimals ) 
slider:SetConVar( cvar )
slider:SetTooltip( tt or "No Tool Tip" )
end

Gradient = surface.GetTextureID( "gui/gradient" )
function DrawBox( x, y, wide, tall, dropsize )
	draw.RoundedBoxEx( 4, x, y, wide, dropsize, iceblue, true, true, false, false )
	draw.RoundedBoxEx( 4, x, y + dropsize, wide, tall - dropsize, Color( 0, 0, 0, 100 ), false, false, true, true )
end

/********************************************************
Name: Hide the cheat from client
Purpose: Don't show the where the cheat loads from, etc
*********************************************************/
function error(...) lesp.Notify(red,"Error in the Lua script!") end
function Error(...) lesp.Notify(red,"Error in the Lua script!") end
function ErrorNoHalt(...) lesp.Notify(red,"Error in the Lua script!") end

/*************************
Name: CreatePos
Purpose: Create a position
Credits: BaconBot
***************************/
function CreatePos(v)
local ply = LocalPlayer()
local center = v:LocalToWorld( v:OBBCenter() )
local min, max = v:OBBMins(), v:OBBMaxs()
local dim = max - min	local z = max + min	
local frt	= ( v:GetForward() ) * ( dim.y / 2 )
local rgt	= ( v:GetRight() ) * ( dim.x / 2 )
local top	= ( v:GetUp() ) * ( dim.z / 2 )
local bak	= ( v:GetForward() * -1 ) * ( dim.y / 2 )
local lft	= ( v:GetRight() * -1 ) * ( dim.x / 2 )
local btm	= ( v:GetUp() * -1 ) * ( dim.z / 2 )
local s = 1
local FRT 	= center + frt / s + rgt / s + top / s; FRT = FRT:ToScreen()
local BLB 	= center + bak / s + lft / s + btm / s; BLB = BLB:ToScreen()
local FLT	= center + frt / s + lft / s + top / s; FLT = FLT:ToScreen()
local BRT 	= center + bak / s + rgt / s + top / s; BRT = BRT:ToScreen()
local BLT 	= center + bak / s + lft / s + top / s; BLT = BLT:ToScreen()
local FRB 	= center + frt / s + rgt / s + btm / s; FRB = FRB:ToScreen()
local FLB 	= center + frt / s + lft / s + btm / s; FLB = FLB:ToScreen()
local BRB 	= center + bak / s + rgt / s + btm / s; BRB = BRB:ToScreen()	
local z = 100
if ( v:Health() <= 50 ) then z = 100 end
local x, y = ( ( v:Health() / 100 ) ), 1
if ( v:Health() <= 0 ) then x = 1 end
local FRT3 	= center + frt + rgt + top / x; FRT3 = FRT3; FRT3 = FRT3:ToScreen()
local BLB3 	= center + bak + lft + btm / x; BLB3 = BLB3; BLB3 = BLB3:ToScreen()
local FLT3	= center + frt + lft + top / x; FLT3 = FLT3; FLT3 = FLT3:ToScreen()
local BRT3 	= center + bak + rgt + top / x; BRT3 = BRT3; BRT3 = BRT3:ToScreen()
local BLT3 	= center + bak + lft + top / x; BLT3 = BLT3; BLT3 = BLT3:ToScreen()
local FRB3 	= center + frt + rgt + btm / x; FRB3 = FRB3; FRB3 = FRB3:ToScreen()
local FLB3 	= center + frt + lft + btm / x; FLB3 = FLB3; FLB3 = FLB3:ToScreen()
local BRB3 	= center + bak + rgt + btm / x; BRB3 = BRB3; BRB3 = BRB3:ToScreen()	
local x, y, z = 1.1, 0.9, 1
local FRT2 	= center + frt / y + rgt / z + top / x; FRT2 = FRT2:ToScreen()
local BLB2 	= center + bak / y + lft / z + btm / x; BLB2 = BLB2:ToScreen()
local FLT2	= center + frt / y + lft / z + top / x; FLT2 = FLT2:ToScreen()
local BRT2 	= center + bak / y + rgt / z + top / x; BRT2 = BRT2:ToScreen()
local BLT2 	= center + bak / y + lft / z + top / x; BLT2 = BLT2:ToScreen()
local FRB2 	= center + frt / y + rgt / z + btm / x; FRB2 = FRB2:ToScreen()
local FLB2 	= center + frt / y + lft / z + btm / x; FLB2 = FLB2:ToScreen()
local BRB2 	= center + bak / y + rgt / z + btm / x; BRB2 = BRB2:ToScreen()	
local maxX = math.max( FRT.x,BLB.x,FLT.x,BRT.x,BLT.x,FRB.x,FLB.x,BRB.x )
local minX = math.min( FRT.x,BLB.x,FLT.x,BRT.x,BLT.x,FRB.x,FLB.x,BRB.x )
local maxY = math.max( FRT.y,BLB.y,FLT.y,BRT.y,BLT.y,FRB.y,FLB.y,BRB.y )
local minY = math.min( FRT.y,BLB.y,FLT.y,BRT.y,BLT.y,FRB.y,FLB.y,BRB.y )
local minYhp2 = math.min( FRT.y,BLB.y,FLT.y,BRT.y,BLT.y,FRB.y,FLB.y,BRB.y )
local maxXhp = math.max( FRT3.x,BLB3.x,FLT3.x,BRT3.x,BLT3.x,FRB3.x,FLB3.x,BRB3.x )
local minXhp = math.min( FRT3.x,BLB3.x,FLT3.x,BRT3.x,BLT3.x,FRB3.x,FLB3.x,BRB3.x )
local maxYhp = math.max( FRT3.y,BLB3.y,FLT3.y,BRT3.y,BLT3.y,FRB3.y,FLB3.y,BRB3.y )
local minYhp = math.min( FRT3.y,BLB3.y,FLT3.y,BRT3.y,BLT3.y,FRB3.y,FLB3.y,BRB3.y )	
local maxX2 = math.max( FRT2.x,BLB2.x,FLT2.x,BRT2.x,BLT2.x,FRB2.x,FLB2.x,BRB2.x )
local minX2 = math.min( FRT2.x,BLB2.x,FLT2.x,BRT2.x,BLT2.x,FRB2.x,FLB2.x,BRB2.x )
local maxY2 = math.max( FRT2.y,BLB2.y,FLT2.y,BRT2.y,BLT2.y,FRB2.y,FLB2.y,BRB2.y )
local minY2 = math.min( FRT2.y,BLB2.y,FLT2.y,BRT2.y,BLT2.y,FRB2.y,FLB2.y,BRB2.y )
return maxX, minX, maxY, minY, maxX2, minX2, maxY2, minY2, minYhp, maxYhp
end


/*************************************
Name: PlayerVisible
Purpose: Check if a player is visible
*************************************/
local function CanSee(ply)
    local trace = {start = LocalPlayer():GetShootPos(),endpos = {}}
    local tr = util.TraceLine(trace)
    if tr.Fraction == 1 then
        return true
    else
        return false
    end    
end

/**********************************
Name: GetColors
Purpose: Make a cool color!
***********************************/
local function GetColorCrosshair()
	if LocalPlayer():GetEyeTrace().Entity:IsPlayer() then
		return 0,255,0,255
	end
	if LocalPlayer():GetEyeTrace().Entity:IsNPC() then
		return 0,0,255,255
	end
	return team.GetColor(LocalPlayer():Team())
end

local function GetColorVisible(e)
	if CanSee(e) then
		return 0,255,0,255
	end
	if !CanSee(e) then
		return 255,0,0,255
	end
end


/**************************************
Name: Number shit
Purpose: Format number, round number, etc
**************************************/
function CommaValue(amount)
	local formatted = amount
	while true do  
		formatted, k = string.gsub(formatted, "^(-?%d+)(%d%d%d)", '%1,%2')
		if (k==0) then
			break
		end
	end
	return formatted
end

function RoundNum(val, decimal)
	if (decimal) then
		return math.floor( (val * 10^decimal) + 0.5) / (10^decimal)
	else
		return math.floor(val+0.5)
	end
end

function FormatNum(amount, decimal, prefix, neg_prefix)
	local str_amount,  formatted, famount, remain
	decimal = decimal or 2
	neg_prefix = neg_prefix or "-"
	famount = math.abs(RoundNum(amount,decimal))
	famount = math.floor(famount)
	remain = RoundNum(math.abs(amount) - famount, decimal)
	formatted = CommaValue(famount)
	if (decimal > 0) then
		remain = string.sub(tostring(remain),3)
		formatted = formatted .. "." .. remain .. string.rep("0", decimal - string.len(remain))
	end
	formatted = (prefix or "") .. formatted 
	if (amount<0) then
		if (neg_prefix=="()") then
			formatted = "("..formatted ..")"
		else
			formatted = neg_prefix .. formatted 
		end
	end
	return formatted
end

function ConvertTime(sSeconds)
	local nSeconds = tonumber(sSeconds)
	if nSeconds <= 0 then
			return 0;
		else
			local nHours = string.format("%02.f", math.floor(nSeconds/3600));
			local nMins = string.format("%02.f", math.floor(nSeconds/60 - (nHours*60)));
			local nSecs = string.format("%02.f", math.floor(nSeconds - nHours*3600 - nMins *60));
		if tonumber( nHours ) > 0 then
			return nHours..":"..nMins..":"..nSecs
		elseif tonumber( nMins ) > 0 and tonumber( nHours ) == 0 then
			return nMins..":"..nSecs
		elseif tonumber( nSecs ) > 0 and tonumber( nMins ) == 0 then
			return nMins..":"..nSecs
		end
	end
end

/**********************
Name: DrawText
Purpose: Draws text...
**********************/
function lesp.DrawText( text, font, x, y, colour, xalign, yalign )
	if (font == nil) then font = "Default" end
	if (x == nil) then x = 0 end
	if (y == nil) then y = 0 end	
	local curX = x
	local curY = y
	local curString = ""	
	surface.SetFont(font)
	local sizeX, lineHeight = surface.GetTextSize("\n")	
	for i=1, string.len(text) do
		local ch = string.sub(text,i,i)
		if (ch == "\n") then
			if (string.len(curString) > 0) then
				draw.SimpleText(curString, font, curX, curY, colour, xalign, yalign)
			end			
			curY = curY + (lineHeight/2)
			curX = x
			curString = ""
		elseif (ch == "\t") then
			if (string.len(curString) > 0) then
				draw.SimpleText(curString, font, curX, curY, colour, xalign, yalign)
			end
			local tmpSizeX,tmpSizeY =  surface.GetTextSize(curString)
			curX = math.ceil( (curX + tmpSizeX) / 50 ) * 50
			curString = ""
		else
			curString = curString .. ch
		end
	end	
	if (string.len(curString) > 0) then
		draw.SimpleText(curString, font, curX, curY, colour, xalign, yalign)
	end
end

local function FillRGBA(x,y,w,h,col)
    surface.SetDrawColor( col.r, col.g, col.b, col.a );
    surface.DrawRect( x, y, w, h );
end

local function OutlineRGBA(x,y,w,h,col)
    surface.SetDrawColor( col.r, col.g, col.b, col.a );
    surface.DrawOutlinedRect( x, y, w, h );
end

/*********************
Name: IsVehicle
Purpose: Find vehicles
*********************/
function lesp.IsVehicle( e )	
	local ply = LocalPlayer()	
	if ( string.find( e:GetClass(), "prop_vehicle_" ) && ply:GetMoveType() ~= 0 ) then
		return true
	end
	return false
end

/***************************
Name: SetColors
Purpose: Set Colors
****************************/
function SetColors(e)
	local ply, class, model = LocalPlayer(), e:GetClass(), e:GetModel()
	local col	
	if ( e:IsPlayer() ) then
		col = Color(0,255,0,255)
	elseif ( e:IsNPC() ) then 
		col = Color( 255, 0, 0, 20 )		
	elseif IsCustomEnt( e:GetClass() ) then
		col = Color( 0, 200, 255, 50 )		
	else
		col = Color( 255, 255, 255, 255 )		
	end	
	return col
end

/******************************
Name: Get Admin Type
Purpose: Get Admin Type..
*******************************/
local function GetAdminType(e)
	if e:IsAdmin() && !e:IsSuperAdmin() then
		return " [A] "
	elseif( e:IsSuperAdmin() ) then
		return " [SA] "
	end
	return " "
end

function CheckUpdate()
lesp.Notify(black,"Checking version.")
	http.Fetch("zarpgaming.com/lesp.txt", function(body, len, headers, code) 
		if body == lesp.version then 
			lesp.Notify(sound,green,"Your version of LESP is up to date!") 
		else
			lesp.Notify(sound,green,"Your version of LESP is up to date!") 
		end 
	end)
end
CheckUpdate()

/*******************************************
Name: Anti-Cheat bypasses
Purpose: Bypass shitty LUA anti-cheats
********************************************/

lesp.Print("[Anti-Cheat] Detected by: Cherry's AC (Working on a bypass method)")
lesp.Print("[Anti-Cheat] Detected by: LIFEPUNCH Anti-Cheat")
lesp.Print("[Anti-Cheat] Will bypass: SourceMod Anti-Cheat") -- SHOULD bypass by default, haven't got any problems yet.


/****************************
Name: Create ConVars
Purpose: Create ConVars..
*****************************/
AddConVar("ESP_Info",0)
AddConVar("ESP_Box",0)
AddConVar("ESP_HPBar",0)
AddConVar("ESP_Skeleton",0)
AddConVar("ESP_Tracer",0)
AddConVar("ESP_Crosshair",0)
AddConVar("ESP_Chams",0)
AddConVar("ESP_Chams_Material","Solid")
AddConVar("ESP_Ents",0)
AddConVar("ESP_Distance",1000)
AddConVar("ESP_Info_Type","info")
AddConVar("ESP_Radar",0)

AddConVar("MISC_Bunnyhop",0)
AddConVar("MISC_TTT",0)
AddConVar("MISC_ChatSpam",0)
AddConVar("MISC_ChatSpam_Msg","visit www.sethhack.seth.im.me.co.cc.net.org.dk.uk.com.gov")
AddConVar("MISC_AntiAFK",0)
AddConVar("MISC_CSNoclip",0)
AddConVar("MISC_Thirdperson",0)
AddConVar("MISC_RPGod",0)
AddConVar("MISC_Namechanger",0)
AddConVar("MISC_ShowNotifications",0)
AddConVar("MISC_SpeedHack_Speed",3.5)
AddConVar("MISC_ShowSpec",0)
AddConVar("MISC_ShowAdmins",0)
AddConVar("MISC_Thirdperson_dist",200)
AddConVar("MISC_Flashlight",0)

AddConVar("PERP_Fuel",0)
AddConVar("PERP_Druggy",0)
AddConVar("PERP_Weed",0)
AddConVar("PERP_RPNames",0)
AddConVar("PERP_PlayerInfo",0)

AddConVar("AIM_Friendly",0)
AddConVar("AIM_Steam",0)
AddConVar("AIM_Admins",0)
AddConVar("AIM_Auto",0)
AddConVar("AIM_NoRecoil",0)
AddConVar("AIM_Offset",0)
AddConVar("AIM_AimSpot","Eye")
AddConVar("AIM_Trigger",0)
AddConVar("AIM_Silent",0)
AddConVar("AIM_SH",0)
AddConVar("AIM_Anti",0)
AddConVar("AIM_Spin",0)
AddConVar("AIM_AntiAA",0)
AddConVar("AIM_AntiSnap",0)
AddConVar("AIM_AntiSnap_Speed",5)
AddConVar("AIM_Fov",180)
AddConVar("AIM_Reload",0)

/***********************************
concommands to find entities and shit
**************************************/

AddCMD("_ents",function()
PrintTable(ents.GetAll())
end)

AddCMD("_players",function()
PrintTable(player.GetAll())
end)


/**********************
Set some ConVars to 0
**********************/
old_rcc("lesp_PERP_Fuel","0")
old_rcc("lesp_PERP_Druggy","0")
old_rcc("lesp_PERP_Weed","0")
old_rcc("lesp_PERP_RPNames","0")
old_rcc("lesp_PERP_PlayerInfo","0")
old_rcc("lesp_MISC_ChatSpam","0")
old_rcc("lesp_ESP_Tracer","0")



/*******************
Start of cheat
*******************/


--[[
	CHAMS
]]--

-- distance check
function IsCloseEnough(ent)
	local dist = ent:GetPos():Distance( LocalPlayer():GetPos() )
	if( dist <= GetConVarNumber("lesp_ESP_Distance") and ent:GetPos() != Vector( 0, 0, 0 ) ) then
		return true
	end
	return false	
end

function Chams()
local mat = lesp:CreateMaterial()
	if GetConVarNumber("lesp_ESP_Chams") == 1 then
		for k,v in pairs(player.GetAll()) do
			local TCol = team.GetColor(v:Team())
			if IsValid(v) and v:Health() > 0 and v:Team() != TEAM_SPECTATOR and IsCloseEnough(v) then
			//Players
			cam.Start3D(EyePos(),EyeAngles())
			render.SuppressEngineLighting( true )
			render.SetColorModulation( ( TCol.r * ( 1 / 255 ) ), ( TCol.g * ( 1 / 255 ) ), ( TCol.b * ( 1 / 255 ) ) )
			render.MaterialOverride( mat )
			v:DrawModel()
			render.SuppressEngineLighting( false )
			render.SetColorModulation(1,1,1)
			render.MaterialOverride( )
			v:DrawModel()
			cam.End3D()
			end
		end
	end
end


local IsLock = false;
--[[ 
	ESP
]]--
function ESP()
	for k, e in pairs( player.GetAll() ) do
local TeamColor = team.GetColor(e:Team())
local HPColor = Color(255,255,255,255)
local Dist = e:GetPos():Distance(LocalPlayer():GetPos());
local wep = "Unknown"
local SteamID = e:SteamID()
local Name = e:Nick()
local hvhpos = ( e:GetPos() + Vector( 0, 0, 130 ) ):ToScreen();
if GetConVarNumber("lesp_PERP_RPNames") == 1 then
	Name = e:GetRPName()
else
	Name = e:Nick()
end
local maxX, minX, maxY, minY, maxX2, minX2, maxY2, minY2, minYhp, maxYhp = CreatePos( e )
-- This is bad
if e:Health() >= 90 then HPColor = Color(0,255,0,255)
	elseif e:Health() >= 70 then HPColor = Color(255,255,0,255)
	elseif e:Health() >= 50 then HPColor = Color(255,165,0,255)
	elseif e:Health() >= 30 then HPColor = Color(255,140,0,255)
	elseif e:Health() >= 20 then HPCOlor = Color(255,69,0,255)
	elseif e:Health() >= 10 then HPColor = Color(255,0,0,255)
	else HPColor = Color(255,0,0,255)
end
draw.SimpleTextOutlined("LESP v2","Logo",1285,15,Color(255,255,255,255),4,1,1,black)
		if ( e:IsPlayer() && e:Alive() && e != LocalPlayer() && IsCloseEnough(e) ) then
			if e:GetActiveWeapon() != nil then
				if type(e:GetActiveWeapon()) == "Weapon" then
					if e:GetActiveWeapon() and e:GetActiveWeapon():IsValid() then
						wep = e:GetActiveWeapon():GetPrintName()
						
							-- ESP INFO
							if (GetConVarNumber("lesp_ESP_Info") == 1 && GetConVarString("lesp_ESP_Info_Type") == "info") then
								draw.SimpleTextOutlined( Name..GetAdminType(e), "lesp_coolvetica", maxX2, minY2, TeamColor,4,1,1,Color(0,0,0))
								draw.SimpleTextOutlined( "H: " .. e:Health(), "ESPFont_Small", maxX2, minY2 + 10, HPColor, 4,1, 1, black )
								draw.SimpleTextOutlined( "D: " .. math.floor(Dist), "ESPFont_Small", maxX2, minY2 + 20, iceblue, 4, 1, 1, black )
								draw.SimpleTextOutlined( "W: " .. wep, "ESPFont_Small", maxX2, minY2 + 30, iceblue, 4, 1, 1, black)
								if e:GetFriendStatus() == "friend" then
									draw.SimpleTextOutlined( "[Friend]", "ESPFont_Small", maxX2, minY2 - 10, iceblue, 4, 1,1,black)
								end
									if e:IsAdmin() then
										draw.SimpleText("[Admin]","ESPFont_Small",maxX2,minY2 -20,cyan,4,1,1,black)
									end
							elseif GetConVarString("lesp_ESP_Info_Type") == "hvh" then
								draw.SimpleTextOutlined(e:Nick().." ["..e:Health().."]","Default",hvhpos.x,hvhpos.y,TeamColor,4,.5,.5,black,TEXT_ALIGN_CENTER)
							end
							
							-- ESP BOX --
							if GetConVarNumber("lesp_ESP_Box") == 1 then
								surface.SetDrawColor(0,0,255,255)				
								surface.DrawLine( maxX, maxY, maxX, minY )
								surface.DrawLine( maxX, minY, minX, minY )					
								surface.DrawLine( minX, minY, minX, maxY )
								surface.DrawLine( minX, maxY, maxX, maxY )
							end
							-- ESP SKELETON --
							local bones = {
							{ S = "ValveBiped.Bip01_Head1", E = "ValveBiped.Bip01_Neck1" },
							{ S = "ValveBiped.Bip01_Neck1", E = "ValveBiped.Bip01_Spine4" },
							{ S = "ValveBiped.Bip01_Spine4", E = "ValveBiped.Bip01_Spine2" },
							{ S = "ValveBiped.Bip01_Spine2", E = "ValveBiped.Bip01_Spine1" },
							{ S = "ValveBiped.Bip01_Spine1", E = "ValveBiped.Bip01_Spine" },
							{ S = "ValveBiped.Bip01_Spine", E = "ValveBiped.Bip01_Pelvis" },
							
							{ S = "ValveBiped.Bip01_Spine4", E = "ValveBiped.Bip01_L_UpperArm" },
							{ S = "ValveBiped.Bip01_L_UpperArm", E = "ValveBiped.Bip01_L_Forearm" },
							{ S = "ValveBiped.Bip01_L_Forearm", E = "ValveBiped.Bip01_L_Hand" },

							{ S = "ValveBiped.Bip01_Spine4", E = "ValveBiped.Bip01_R_UpperArm" },
							{ S = "ValveBiped.Bip01_R_UpperArm", E = "ValveBiped.Bip01_R_Forearm" },
							{ S = "ValveBiped.Bip01_R_Forearm", E = "ValveBiped.Bip01_R_Hand" },

							{ S = "ValveBiped.Bip01_Pelvis", E = "ValveBiped.Bip01_L_Thigh" },
							{ S = "ValveBiped.Bip01_L_Thigh", E = "ValveBiped.Bip01_L_Calf" },
							{ S = "ValveBiped.Bip01_L_Calf", E = "ValveBiped.Bip01_L_Foot" },
							{ S = "ValveBiped.Bip01_L_Foot", E = "ValveBiped.Bip01_L_Toe0" },

							{ S = "ValveBiped.Bip01_Pelvis", E = "ValveBiped.Bip01_R_Thigh" },
							{ S = "ValveBiped.Bip01_R_Thigh", E = "ValveBiped.Bip01_R_Calf" },
							{ S = "ValveBiped.Bip01_R_Calf", E = "ValveBiped.Bip01_R_Foot" },
							{ S = "ValveBiped.Bip01_R_Foot", E = "ValveBiped.Bip01_R_Toe0" },
							}
							if GetConVarNumber("lesp_ESP_Skeleton") == 1 then
								for k, v in pairs( bones ) do
									local sPos, ePos = e:GetBonePosition( e:LookupBone( v.S ) ):ToScreen(), e:GetBonePosition( e:LookupBone( v.E ) ):ToScreen()
										if e:IsPlayer() and !e:IsNPC() then
											surface.SetDrawColor(team.GetColor(e:Team()))
										end
										surface.DrawLine(sPos.x,sPos.y,ePos.x,ePos.y)
								end
							end
							-- ESP TRACER --
							if GetConVarNumber("lesp_ESP_Tracer") == 1 then	
								cam.Start3D( EyePos() , EyeAngles())
								render.SetMaterial( Material( "trails/laser" ) )
								StartPos = LocalPlayer():GetActiveWeapon():GetPos()
								EndPos = e:GetBonePosition(e:LookupBone("ValveBiped.Bip01_Head1"))
								render.DrawBeam(StartPos, EndPos , 3, 0, 0, Color(0,255,0,255))
								cam.End3D()
							end
							
							-- ESP CROSSHAIR --
							if GetConVarNumber("lesp_ESP_Crosshair") == 1 then
								local x, y = ScrW() / 2, ScrH() / 2	
								local Speed = 1
								surface.SetDrawColor(GetColorCrosshair()) 
								CHPosx = math.Clamp(LocalPlayer():GetEyeTrace().HitPos:ToScreen().x,0,ScrW())
								CHPosy = math.Clamp(LocalPlayer():GetEyeTrace().HitPos:ToScreen().y,0,ScrH())
								mathsin = math.sin(CurTime()*Speed)*4
								mathcos = math.cos(CurTime()*Speed)*4
								mathsin2 = math.sin(CurTime()*Speed+0.1)*4
								mathcos2 = math.cos(CurTime()*Speed+0.1)*4
								mathsin3 = math.sin(CurTime()*Speed-0.1)*4
								mathcos3 = math.cos(CurTime()*Speed-0.1)*4
								surface.DrawLine( CHPosx+mathcos*2,CHPosy+mathsin*2,CHPosx+mathcos*5,CHPosy+mathsin*5 );
								surface.DrawLine( CHPosx-mathcos*2,CHPosy-mathsin*2,CHPosx-mathcos*5,CHPosy-mathsin*5 );
								surface.DrawLine( CHPosx+mathsin*2,CHPosy-mathcos*2,CHPosx+mathsin*5,CHPosy-mathcos*5 );
								surface.DrawLine( CHPosx-mathsin*2,CHPosy+mathcos*2,CHPosx-mathsin*5,CHPosy+mathcos*5 );
							end
					end
				end
			end
		end
	end
	for _, v in ipairs( ents.GetAll() ) do
		if( v:IsValid() and IsCustomEnt( v:GetClass() )) then
			if GetConVarNumber("lesp_ESP_Ents") == 1 then
				local wepn = v:GetClass()
				local wname = string.Replace(wepn,"weapon_","")
				wname = string.Replace(wname,"_"," ")
				wname = string.upper(wname)
				local entpos = v:GetPos():ToScreen()
				draw.SimpleTextOutlined(wname, "ESPFont_Small", entpos.x + 50, entpos.y - 15, color_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_LEFT, .6, black )
				surface.SetDrawColor(255,0,255,255)
				surface.DrawLine(entpos.x,entpos.y,entpos.x,entpos.y-10)
				surface.DrawLine(entpos.x,entpos.y,entpos.x+10,entpos.y)
			end
		end                    
	end
end 

/************
Radar
NOTES: removed for now, re-making.
************/
/*
function DoChecksRadar( e )
	local ply, val = LocalPlayer(), 0	
	if ( e:IsPlayer() && e:GetMoveType() == MOVETYPE_OBSERVER ) then return false end	
	if ( !e:IsValid() || !e:IsPlayer() && !e:IsNPC() || e == ply ) then return false end
	if ( e:IsPlayer() && !e:Alive() ) then return false end
	if ( e:IsNPC() && e:GetMoveType() == 0 ) then return false end
	if ( e:IsWeapon() && e:GetMoveType() == 0 ) then return false end	
	return true	
end

local RRadar

function Radar()
if GetConVarNumber("lesp_ESP_Radar") == 1 then	
	local Radar = vgui.Create( "DFrame" )
	Radar:SetSize( 250, 250 )	
	local rW, rH, x, y = Radar:GetWide(), Radar:GetTall(), ScrW() / 2, ScrH() / 2	
	local sW, sH = ScrW(), ScrH()
	Radar:SetPos( sW - rW - 0.1, sH - rH - ( sH - rH ) + 30 )
	Radar:SetTitle( "[lesp] Radar" )
	Radar:SetVisible( true )
	Radar:SetDraggable( true )
	Radar:ShowCloseButton( false )
	Radar:MakePopup()
	Radar.Paint = function()
		draw.RoundedBox( 2, 0, 0, rW, rH, Color( 0, 0, 0, 100 ) )
		surface.SetDrawColor( 255, 255, 255, 255 )	
		local ply = LocalPlayer()		
		local radar = {}
		radar.h		= 250
		radar.w		= 250
		radar.org	= 5000		
		local x, y = ScrW() / 2, ScrH() / 2		
		local half = rH / 2
		local xm = half
		local ym = half		
		surface.DrawLine( xm, ym - 100, xm, ym + 100 )
		surface.DrawLine( xm - 100, ym, xm + 100, ym )		
		for k, e in pairs( ents.GetAll() ) do
			if ( DoChecksRadar(e) ) then				
				local s = 6
				local col = SetColors(e)
				local color = Color( col.r, col.g, col.b, 255 )
				local plyfov = ply:GetFOV() / ( 70 / 1.13 )
				local zpos, npos = ply:GetPos().z - ( e:GetPos().z ), ( ply:GetPos() - e:GetPos() )			
				npos:Rotate( Angle( 180, ( ply:EyeAngles().y ) * -1, -180 ) )
				local iY = npos.y * ( radar.h / ( ( radar.org * ( plyfov  * ( ScrW() / ScrH() ) ) ) + zpos * ( plyfov  * (ScrW() / ScrH() ) ) ) )
				local iX = npos.x * ( radar.w / ( ( radar.org * ( plyfov  * ( ScrW() / ScrH() ) ) ) + zpos * ( plyfov  * (ScrW() / ScrH() ) ) ) )								
				local pX = ( radar.w / 2 )
				local pY = ( radar.h / 2 )			
				local posX = pX - iY - ( s / 2 )
				local posY = pY - iX - ( s / 2 )				
				local text = e:GetClass()				
				if ( e:IsPlayer() ) then 
					text = e:Nick() .. " ["..e:Health().."]"
				elseif ( e:IsNPC() ) then
					text = ""
				elseif (IsCustomEnt(e:GetClass())) then
					text = "Item"
				end					
				if iX < ( radar.h / 2 ) && iY < ( radar.w / 2 ) && iX > ( -radar.h / 2 ) && iY > ( -radar.w / 2 ) then				
					draw.RoundedBox( s, posX, posY, s, s, color )
					lesp.DrawText(
						text,
						"DefaultSmall",
						pX - iY - 4,
						pY - iX - 15 - ( s / 2 ),
						color,
						1,
						TEXT_ALIGN_TOP
					)
				end
			end
		end
	end
	Radar:SetMouseInputEnabled( false )
	Radar:SetKeyboardInputEnabled( false )	
	RRadar = Radar
end
end
Radar()
*/

/**************************
NOTIFICATIONS!
YES, Bringing them back.
**************************/
function Notifications()
local NotifPos = 5
	if GetConVarNumber("lesp_MISC_ShowNotifications") == 1 then
		draw.RoundedBox( 8, -10, 0, 10000, 30, Color(0,0,0,100))
		
		if ShouldAim == 1 then
			draw.SimpleText("| Aimbot: ON", "Logo", 0,NotifPos, Color(0,255,0,255))
		else
			draw.SimpleText("| Aimbot: OFF", "Logo", 0, NotifPos, Color(255,0,0,255))
		end
		
		if GetConVarNumber("lesp_AIM_Auto") == 1 then
			draw.SimpleText("| Autoshoot: ON", "Logo", 100,NotifPos, Color(0,255,0,255))
		else
			draw.SimpleText("| Autoshoot: OFF", "Logo", 100, NotifPos, Color(255,0,0,255))
		end
		
		if GetConVarNumber("lesp_AIM_Trigger") == 1 then
			draw.SimpleText("| TriggerBot: ON", "Logo", 220,NotifPos, Color(0,255,0,255))
		else
			draw.SimpleText("| TriggerBot: OFF", "Logo", 220, NotifPos, Color(255,0,0,255))
		end
		
		if GetConVarNumber("lesp_AIM_NoRecoil") == 1 then
			draw.SimpleText("| No Recoil: ON", "Logo", 340,NotifPos, Color(0,255,0,255))
		else
			draw.SimpleText("| No Recoil: OFF", "Logo", 340,NotifPos, Color(255,0,0,255))
		end
		
		if GetConVarNumber("lesp_AIM_Admins") == 1 then
			draw.SimpleText("| Target Admins: ON", "Logo", 450,NotifPos, Color(0,255,0,255))
		else
			draw.SimpleText("| Target Admins: OFF", "Logo", 450,NotifPos, Color(255,0,0,255))
		end
		
		if GetConVarNumber("lesp_AIM_Friendly") == 1 then
			draw.SimpleText("| Friendly Fire: ON", "Logo", 590,NotifPos, Color(0,255,0,255))
		else
			draw.SimpleText("| Friendly Fire: OFF", "Logo", 590,NotifPos, Color(255,0,0,255))
		end
		
		if GetConVarNumber("lesp_AIM_Steam") == 1 then
			draw.SimpleText("| Target Steam Friends: ON", "Logo", 720,NotifPos, Color(0,255,0,255))
		else
			draw.SimpleText("| Target Steam Friends: OFF", "Logo", 720, NotifPos, Color(255,0,0,255))
		end
		
		if GetConVarNumber("host_timescale") >= 1.1 then
			draw.SimpleText("| SpeedHack: ON", "Logo", 910,NotifPos, Color(0,255,0,255))
		else
			draw.SimpleText("| SpeedHack: OFF", "Logo", 910, NotifPos, Color(255,0,0,255))
		end
	end
end


/*****************************************
Name: Aimbot/Aim functions
Purpose: Aim for you, because you suck
Credits: isis
*******************************************/

local Tb  = table.Copy( file )
local Tbs = table.Copy( string )
local Uw = {}
local Mw = {}
local function PlyPos( ply )
local min = ply:OBBMins()
local max = ply:OBBMaxs()
	
local Spots = {
	Vector( min.x, min.y, min.z ),
	Vector( min.x, min.y, max.z ),
	Vector( min.x, max.y, min.z ),
	Vector( min.x, max.y, max.z ),
	Vector( max.x, min.y, min.z ),
	Vector( max.x, min.y, max.z ),
	Vector( max.x, max.y, min.z ),
	Vector( max.x, max.y, max.z )
}	
local minX = ScrW() * 2
local minY = ScrH() * 2
local maxX = 0
local maxY = 0

	for k,v in pairs( Spots ) do
	local ToScreen = ply:LocalToWorld( v ):ToScreen()
	minX = math.min( minX, ToScreen.x )
	minY = math.min( minY, ToScreen.y )
	maxX = math.max( maxX, ToScreen.x )
	maxY = math.max( maxY, ToScreen.y )
	end
	return minX, minY, maxX, maxY
end
AddCMD("+lesp_Aim",function()
Aimon = 1
end)

AddCMD("-lesp_Aim",function()
Aimon = 0
IsLock = false
end)

local function AimSpot(targ)
	if GetConVarString("lesp_AIM_AimSpot") == "Eye" then 
	local eye = targ:LookupAttachment("eyes")
		if eye then
		local pos = targ:GetAttachment(eye)
			if pos then return pos.Pos end
		end
	end	
	if GetConVarString("lesp_AIM_AimSpot") == "Bone" then
	local bone = targ:LookupBone("ValveBiped.Bip01_Head1")
		if bone then
		local pos = targ:GetBonePosition(bone)
			if pos then return pos end
		end
	end	
	if GetConVarString("lesp_AIM_AimSpot") == "Center" then
	local center = targ:OBBCenter()
		if center then
		local pos = targ:LocalToWorld(center)
			if pos then return pos end
		end
	end
	
return targ:LocalToWorld(targ:OBBCenter())

end

local function Exception(ent)
	if (ent == LocalPlayer()) then return false end
	if (ent:Team() == TEAM_SPECTATOR) then return false end
	if (ent:GetMoveType() == MOVETYPE_OBSERVER) then return false end
	if (!ent:Alive() ) then return false end
	if (ent:InVehicle()) then return false end 
	if (GetConVarNumber("lesp_AIM_Friendly") == 0 && ent:Team() == LocalPlayer():Team()) then return false end  
	if (GetConVarNumber("lesp_AIM_Steam") == 0 && ent:GetFriendStatus() == "friend" ) then return false end
return true
end

local function Visible(ply)
local tracedata = {}
	tracedata.start = LocalPlayer():GetShootPos()
	tracedata.endpos = AimSpot(ply) - Vector(0,0,GetConVarNumber("lesp_AIM_Offset"))
	tracedata.mask = MASK_SHOT
	tracedata.filter = {ply , LocalPlayer()}
	Trace = util.TraceLine(tracedata)
	if Trace.Hit then return false else return true end
end

function InFov( ent )
	local fov = GetConVarNumber("lesp_AIM_Fov")
	if( fov != 180 ) then
		local lpang = LocalPlayer():GetAngles()
		local ang = ( ent:GetBonePosition( ent:LookupBone("ValveBiped.Bip01_Head1") ) - LocalPlayer():EyePos() ):Angle()
		local ady = math.abs( math.NormalizeAngle( lpang.y - ang.y ) )
		local adp = math.abs( math.NormalizeAngle( lpang.p - ang.p ) )
		if( ady > fov || adp > fov ) then return false end
	end
	return true
end

local LastReload = 0
local dontreload = {"weapon_physgun" , "gmod_tool" , "weapon_gravgun"}
function AutoReload()
    if (GetConVarNumber("lesp_AIM_Reload") == 1 and LocalPlayer():Alive() and IsValid( LocalPlayer():GetActiveWeapon() ) and !table.HasValue( dontreload, LocalPlayer():GetActiveWeapon():GetClass() ) ) then
		if( LocalPlayer():GetActiveWeapon():Clip1() <= 0 and CurTime() > ( LastReload + 5 ) ) then
			old_rcc( "+reload" )
			LastReload = CurTime()
			AddTimer( .2, 1, function()
				old_rcc( "-reload" )
			end )
		end
    end
end

local function Aimbot(ucmd)
local asspeed = GetConVarNumber("lesp_AIM_AntiSnap_Speed") / 10
	if Aimon == 1 then		
		local ArchAngel = Angle(0,0,0)
		local target;
		local distance = math.huge;
		for _, ply in pairs(player.GetAll()) do
			if (ply != LocalPlayer() and ply:Alive() and Visible(ply) and Exception(ply)) and InFov(ply) then
				local thedist = ply:GetPos():DistToSqr(LocalPlayer():GetPos());
				if (thedist < distance) then
					distance = thedist;
					target = ply;
				end
			end
		end
		if target != nil then
		local Aimspot = AimSpot(target) - Vector(0,0,GetConVarNumber("lesp_AIM_Offset"))
		Aimspot = Aimspot + target:GetVelocity() / 45 - LocalPlayer():GetVelocity() / 45
		Angel = (Aimspot - LocalPlayer():GetShootPos()):GetNormal():Angle()
		Angel.p = math.NormalizeAngle( Angel.p )
		Angel.y = math.NormalizeAngle( Angel.y )
		
		if GetConVarNumber("lesp_AIM_AntiSnap") == 1 then 
			Angle1 = LocalPlayer():EyeAngles()
			local Smooth1 = math.Approach(Angle1.p, Angel.p, asspeed)
			local Smooth2 = math.Approach(Angle1.y , Angel.y, asspeed)       
			ArchAngel = Angle (Smooth1, Smooth2, 0)
		else			
			ArchAngel = Angle( Angel.p, Angel.y, 0 )
		end
				debug.getregistry()["CUserCmd"].SetViewAngles(ucmd, ArchAngel)
				IsLock = 1
			if GetConVarNumber("lesp_AIM_Auto") == 1 then
                ucmd:SetButtons(bit.bor(ucmd:GetButtons(),IN_ATTACK)) 
			end
			if GetConVarNumber("lesp_AIM_SH") == 1 then
				ucmd:SetButtons(bit.bor(ucmd:GetButtons(),IN_ATTACK2))  
			end
		end
	end
end

/**************************
Name: Anti-Aim
Purpose: HVH feature
**************************/
AddHook("CreateMove",function(cmd, u)
	if GetConVarNumber("lesp_AIM_Anti") == 1 then
		if (LocalPlayer():KeyDown(IN_ATTACK)) then return end
		local aa = cmd:GetViewAngles()
		cmd:SetViewAngles(Angle(-181, aa.y, 180))
	end
end)

/*************************
Name: SpinBot
Purpose: Spin, dumbass
*************************/


/******************************
Name: SILENT AIM
Purpose: FAKE AIM VIEW
******************************/

-- make me

/****************************
Name: Misc
Purpose: Misc features
*****************************/

function NameChanger()
	if GetConVarNumber("lesp_MISC_Namechanger") == 1 then
		AddTimer( 1, 1, function() 
			print("fuck you")
		end )
	end
end

function Misc()
	if GetConVarNumber("lesp_MISC_BunnyHop") == 1 then
		if input.IsKeyDown(KEY_SPACE) then
			if LocalPlayer():IsOnGround() then
				old_rcc("+Jump")
				timer.Create("Bhop",0.01, 0 ,function() old_rcc("-Jump") end)
			end
		end
	end
	if GetConVarNumber("lesp_AIM_NoRecoil") == 1 then
		if LocalPlayer():GetActiveWeapon().Primary then
			LocalPlayer():GetActiveWeapon().Primary.Recoil = 0
		end
	end
	if GetConVarNumber("lesp_MISC_ChatSpam") == 1 then
		LocalPlayer():ConCommand("say "..GetConVarString("lesp_MISC_ChatSpam_Msg").."["..math.random(1,999).."]")
	end
	if GetConVarNumber("lesp_MISC_RPGod") == 1 then
		if LocalPlayer():Health() < 100 then
			LocalPlayer():ConCommand("say /buyhealth"); -- spam buyhealth
		end
	end
	if GetConVarNumber("lesp_MISC_Flashlight") == 1 then
		old_rcc("impulse","100")
	end
end

AddHook("CalcView",function(ply, pos, angles, fov)
	if GetConVarNumber("lesp_MISC_Thirdperson") == 1 and LocalPlayer():Alive() then
		local view = {}
		view.origin = pos-(angles:Forward()*GetConVarNumber("lesp_MISC_Thirdperson_Dist"))
		view.angles = angles
		view.fov = fov
		return view
	end
end)
AddHook("ShouldDrawLocalPlayer",function()
	if GetConVarNumber("lesp_MISC_Thirdperson") == 1 then
		return true
	end
end)
function ShowNotifi()
	-- now spectating
	for k, v in pairs(player.GetAll()) do
		if (IsValid(v:GetObserverTarget()) and v:GetObserverTarget():IsPlayer() and v:GetObserverTarget() == LocalPlayer()) then
			if(not table.HasValue(lesp.spectators, v)) then
				table.insert(lesp.spectators, v);
				if GetConVarNumber("lesp_MISC_ShowSpec") == 1 then
					lesp.Notify(true,red,""..v:Nick().." is now spectating you!")
					surface.PlaySound("buttons/blip1.wav")
				end
			end
		end
	end
	-- no longer spectating
	for k, v in pairs(lesp.spectators) do
		if (not IsValid(v) or not IsValid(v:GetObserverTarget()) or not v:GetObserverTarget():IsPlayer() or (v:GetObserverTarget() ~= LocalPlayer())) then
			table.remove(lesp.spectators, k);
			if GetConVarNumber("lesp_MISC_ShowSpec") == 1 then
				lesp.Notify(true,green,""..v:Nick().." is no longer spectating you!")
			end
		end
	end
	-- admin join
	if GetConVarNumber("lesp_MISC_ShowAdmins") == 1 then
		for k, v in pairs(player.GetAll()) do
			if (v:IsAdmin() and not table.HasValue(lesp.admins, v)) then
				table.insert(lesp.admins, v);
				lesp.Notify(true,white,"Admin " .. v:Nick() .. " has joined!")
				surface.PlaySound("buttons/blip1.wav");
			end
		end
	end
end


local commands = { "forward" , "back" , "jump" , "moveleft" , "moveright", "duck" }
function AntiAfk()
	if GetConVarNumber("lesp_MISC_AntiAFK") == 1 then
		local command1 = table.Random( commands )
		local command2 = table.Random( commands )
		AddTimer( 1, 1, function() 
			old_rcc( "+"..command1 ) 
			old_rcc( "+"..command2 ) 
		end )
		AddTimer( 2, 1, function() 
			old_rcc("-"..command1 ) 
			old_rcc("-"..command2 ) 
		end )
	end
end
AddTimer( 5 , 0 , function() AntiAfk() end )

// Traitor finder functions
local Traitors = {};
local PlayerIsTraitor = false
timer.Simple( 3, function()
	if ( gmod.GetGamemode().Name ) == "Trouble in Terrorist Town" then
		local TWeapons = { "weapon_ttt_c4", "weapon_ttt_knife", "weapon_ttt_phammer", "weapon_ttt_sipistol", "weapon_ttt_flaregun", "weapon_ttt_push", "weapon_ttt_radio", "weapon_ttt_teleport", "(Disguise)" }
		local UsedWeapons = {}
		local MapWeapons = {}
function IsATraitor( ply )
	for k, v in pairs( Traitors ) do
		if v == ply then
			return true
		else
			return false
		end
	end
end

timer.Create("TTT", 0.8, 0, function()
	if GetConVarNumber("lesp_MISC_TTT") == 1 then
		if !IsATraitor( ply ) then 
			for k, v in pairs( ents.FindByClass( "player" ) ) do 
				if IsValid( v ) then
					if (!v:IsDetective()) then
						if v:Team() ~= TEAM_SPECTATOR then
							for wepk, wepv in pairs( TWeapons ) do
								for entk, entv in pairs( ents.FindByClass( wepv ) ) do
									if IsValid( entv ) then
										cookie.Set( entv, 100 - wepk )
										if !table.HasValue( UsedWeapons, cookie.GetNumber( entv ) ) then
											if !table.HasValue( MapWeapons, cookie.GetNumber( entv ) ) then
												local EntPos = ( entv:GetPos() - Vector(0,0,35) )
													if entv:GetClass() == wepv then
														if v:GetPos():Distance( EntPos ) <= 1 then
															table.insert( Traitors, v )
															lesp.Notify(sound,red,v:Nick() .. " has traitor weapon: " .. wepv )
															if !table.HasValue( UsedWeapons, cookie.GetNumber( entv ) ) then
																table.insert( UsedWeapons, cookie.GetNumber( entv ) )
															else
															if !table.HasValue( MapWeapons, cookie.GetNumber( entv ) ) then
																table.insert( MapWeapons, cookie.GetNumber( entv ) )
															end
														end
													end
												end
											end
										end
									end
								end
							end
						end
					end
				end
			end
		end
	end
end )

AddHook("HUDPaint",function()
	if GetConVarNumber("lesp_MISC_TTT") == 1 then
		for k, e in pairs( Traitors ) do
			local maxX, minX, maxY, minY, maxX2, minX2, maxY2, minY2, minYhp, maxYhp = CreatePos( e )
			if IsValid( e ) then
				if e:Team() ~= TEAM_SPECTATOR then
					if ( !e:IsDetective() ) then
						PlayerIsTraitor = true
						draw.SimpleTextOutlined( "[TRAITOR]", "ESPFont", maxX2, minY2 -20, red, 4, 1, 1, black )
					end
				end
			end
		end
	end
end )

AddHook("TTTPrepareRound",function()
timer.Simple( 2, function()
	for k, v in pairs( Traitors ) do
		table.remove( Traitors, k )
		Traitors = {}
	end
		for k, v in pairs( UsedWeapons ) do
			table.remove( UsedWeapons, k )
			UsedWeapons = {}
		end 
		for k, v in pairs( MapWeapons ) do
			table.remove( MapWeapons, k )
			MapWeapons = {}
		end 
	end ) 
end )
	end 
end )

/***************************************
Name: PERP Hack
Purpose: hacks and exploits for PERP
***************************************/
local WeedGrowTime = 60 * 20
function PERP_Druggy()
	local buying = GetGlobalInt("perp_druggy_buy", 0 )
	local selling = GetGlobalInt("perp_druggy_sell", 0 )	
	local cantrobbank = GetGlobalBool("perp_bank_robbing_timer")
	local moneyinbank = GetGlobalInt("perp_realtor_money")	
	if GetConVarNumber("lesp_PERP_Druggy") == 1 then
		local posx = 17
		local posy = 15
		DrawBox( posx, posy, 122, 60, 20 )
		draw.SimpleText("Druggy", "ESPFont", posx + 61, posy + 1, Color( 255, 255, 255, 255 ), TEXT_ALIGN_CENTER )
			local buyingtbl = {
				"Buying Weed",
				"Buying Meth",
				"Buying Shrooms",
				"Buying LSD",
				"Buying Shrooms",
				"Buying Cocaine",
			}
			buyingtbl[0] = "Not Buying"
			draw.SimpleText( buyingtbl[buying], "ESPFont", posx + 61, posy + 42, white, TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP )
			local sellingtbl = {
				"Selling Seeds",
				"Selling LSD",
				--"Selling Muscle",
				"Selling Shrooms",
				"Selling Cocaine",
			}
			sellingtbl[0] = "Not Selling"
			draw.SimpleText( sellingtbl[selling], "ESPFont", posx + 61, posy + 62, white, TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
	end
end

timer.Remove("DoFuel");
timer.Create("DoFuel",5,0,function()
	if GetConVarNumber("lesp_PERP_Fuel") == 1 then
		DoFuel();
	end
end)

function PERP_Weed()
	if GetConVarNumber("lesp_PERP_Weed") == 1 then
		local plants = {}
		for k, ent in pairs( ents.FindByClass("ent_pot") ) do
			table.insert( plants, ent )
		end
		for k, ent in pairs( ents.FindByClass("ent_coca") ) do
			table.insert( plants, ent )
		end
		local col = nil
		for k, ent in pairs( plants ) do
			local pos = ent:GetPos() + Vector(0, 0, 10)
			local ang = ent:GetAngles()
			local drawpos = pos:ToScreen()
			local timeleft = 85564
			if( ent:GetClass() == "ent_coca" ) then col = Color( 0, 0, 255 ) else col = Color( 255, 0, 0 ) end
			if( ent.dt != nil ) then
				timeleft = ent:GetTable().GrowthTime - ( CurTime() - ent.dt.SpawnTime )
			elseif( ent:GetTable().SpawnTime != nil ) then
				timeleft = ent:GetTable().GrowthTime - (CurTime() - ent:GetTable().SpawnTime)
			end
			if( LocalPlayer():GetShootPos():Distance( pos ) <= 4000 ) then
				if( timeleft > 1 and timeleft != 85564 ) then
					draw.SimpleText( ConvertTime( timeleft ) , "ESPFont_Small", drawpos.x, drawpos.y, col, 1, 1 )
				elseif( timeleft != 85564 ) then
					draw.SimpleText( "DONE!", "ESPFont", drawpos.x, drawpos.y, green, 1, 1 )
				end
			end
		end
	end
end

// player info (yourself)
function PERP_PlayerInfo()
	if GetConVarNumber("lesp_PERP_PlayerInfo") == 1 then
		draw.RoundedBox( 0, 17, 80, 175, 200, Color(0,0,0,70) )
		draw.SimpleText("PERP INFO", "lesp_ScoreboardText", 60,90, white, 1, 1 )
		draw.SimpleText("HP: "..LocalPlayer():Health(), "lesp_ScoreboardText", 55,110, white, 1, 1 )
		draw.SimpleText("Armor: "..LocalPlayer():Armor(), "lesp_ScoreboardText", 55,130, white, 1, 1 )	
		draw.SimpleText("Bank: "..FormatNum( LocalPlayer():GetBank(), 2, "$" ), "lesp_ScoreboardText", 75,150, white, 1, 1 )
	end
end


/*************************
MENU FUNCTIONS
*************************/
AddCMD("+Lesp_Menu", function()
Menu = vgui.Create("DFrame")
Menu:SetSize(450,360)
Menu:SetTitle("                                                  :: LESP :: Version "..lesp.version.." ::") -- Ignore the spacing.
Menu:Center()
Menu:MakePopup()
Menu.Paint = function()
local mW, mH, x, y = Menu:GetWide(), Menu:GetTall(), ScrW() / 2, ScrH() / 2
draw.RoundedBox( 0, 0, 0, mW, mH, Color(116,187,251,50 ) )
surface.SetDrawColor(black);
surface.DrawOutlinedRect( 0, 0, mW , mH )
surface.DrawOutlinedRect( 0, 25, mW, mH )
end

local Sheet = vgui.Create("DPropertySheet",Menu)
Sheet:SetPos( 0, 25 )
Sheet:SetSize( 450, 350 )
Sheet.Paint = function()
draw.RoundedBox( 0, 0, 0, Sheet:GetWide(), Sheet:GetTall(), Color(0,0,0,150) )
end

// fuck;
local Page1 = vgui.Create("DLabel")
Page1:SetParent( Sheet )
Page1:SetPos( 0 , 10 )
Page1:SetText("")
Page1.Paint = function()
draw.SimpleTextOutlined("LESP v"..lesp.version.." - A Cheat By Agentlulz","Logo",20,3,cyan,TEXT_ALIGN_LEFT,TEXT_ALIGN_LEFT,2,black)
draw.SimpleTextOutlined("ConVar Forces","Logo",170,60,red,TEXT_ALIGN_LEFT,TEXT_ALIGN_LEFT,2,black)
draw.SimpleTextOutlined("Updates","Logo",190,120,lgreen,TEXT_ALIGN_LEFT,TEXT_ALIGN_LEFT,2,black)
draw.SimpleTextOutlined("Configs","Logo",190,180,pink,TEXT_ALIGN_LEFT,TEXT_ALIGN_LEFT,2,black)
end
local Page2 = vgui.Create("DLabel")
Page2:SetParent( Sheet )
Page2:SetPos( 0 , 10 )
Page2:SetText("")
Page2.Paint = function()
end
local Page3 = vgui.Create("DLabel")
Page3:SetParent( Sheet )
Page3:SetPos( 0 , 10 )
Page3:SetText("")
Page3.Paint = function()
end
local Page4 = vgui.Create("DLabel")
Page4:SetParent( Sheet )
Page4:SetPos( 0 , 10 )
Page4:SetText("")
Page4.Paint = function()
end
local Page5 = vgui.Create("DLabel")
Page5:SetParent( Sheet )
Page5:SetPos( 0 , 10 )
Page5:SetText("")
Page5.Paint = function()
end
-----------------------
--[[ MAIN TAB SHIT ]]--
-----------------------
// LOAD SHIT
local ReloadHooksButton = vgui.Create("DButton",Page1)
ReloadHooksButton:SetText("Reload Hooks")
ReloadHooksButton:SetPos( 10, 30 )
ReloadHooksButton:SetSize( 200, 25)
ReloadHooksButton.DoClick = function()
lesp.hooks:reload()
lesp.Notify(green,"Reloaded hooks")
end

local UnloadCheat = vgui.Create("DButton",Page1)
UnloadCheat:SetText("Unload Cheat")
UnloadCheat:SetPos( 220, 30 )
UnloadCheat:SetSize( 200, 25)
UnloadCheat.DoClick = function()
unload()
lesp.Notify(red,"UNLOADED ENTIRE CHEAT!")
end

// CONVAR Forces
local svcheats = vgui.Create("DButton",Page1)
svcheats:SetText("sv_cheats")
svcheats:SetPos( 10,90 )
svcheats:SetSize( 200, 25)
svcheats.DoClick = function()
lesp.Notify(white,"Not done!")
print("fuck you")
end

local allowvoice = vgui.Create("DButton",Page1)
allowvoice:SetText("sv_allow_voice_from_file")
allowvoice:SetPos( 220,90 )
allowvoice:SetSize( 200, 25)
allowvoice.DoClick = function()
lesp.Notify(white,"Not done!")
end

// UPDATE SHIT
local checkupdate = vgui.Create("DButton",Page1)
checkupdate:SetText("Check for updates")
checkupdate:SetPos( 10,150 )
checkupdate:SetSize( 200, 25)
checkupdate.DoClick = function()
CheckUpdate()
end

local doupdate = vgui.Create("DButton",Page1)
doupdate:SetText("Update the cheat")
doupdate:SetPos( 220,150 )
doupdate:SetSize( 200, 25)
doupdate.DoClick = function()
lesp.Notify(white,"Not done.")
end

local hvhconfig = vgui.Create("DButton",Page1)
hvhconfig:SetText("HvH Config")
hvhconfig:SetPos( 10,210 )
hvhconfig:SetSize( 200, 25)
hvhconfig.DoClick = function()
lesp.Notify(white,"Loaded Hack VS Hack config.")
print("WIP")
end

local legitconfig = vgui.Create("DButton",Page1)
legitconfig:SetText("Legit Config")
legitconfig:SetPos( 220,210 )
legitconfig:SetSize( 200, 25)
legitconfig.DoClick = function()
lesp.Notify(white,"Loaded legit config.")
print("WIP")
end

local userconfig = vgui.Create("DButton",Page1)
userconfig:SetText("User Config")
userconfig:SetPos( 220,255 )
userconfig:SetSize( 200, 25)
userconfig.DoClick = function()
lesp.Notify(white,"Loaded user config.")
print("WIP")
end

local rageconfig = vgui.Create("DButton",Page1)
rageconfig:SetText("Rage Config")
rageconfig:SetPos( 10,255 )
rageconfig:SetSize( 200, 25)
rageconfig.DoClick = function()
lesp.Notify(white,"Loaded rage config.")
print("WIP")
end


-------------------------
--[[ AIMBOT TAB SHIT ]]--
-------------------------
AddCheckBox("Autoshoot","lesp_AIM_Auto",Page2,10,10,"Autoshoot when locked")
AddCheckBox("Friendly Fire","lesp_AIM_Friendly",Page2,10,30,"Target your own team")
AddCheckBox("Target Steam Friends","lesp_AIM_Steam",Page2,10,50,"Target Steam Friends")
AddCheckBox("Target Admins","lesp_AIM_Admins",Page2,10,70,"Target Admins")
AddCheckBox("No-Recoil","lesp_AIM_NoRecoil",Page2,10,90,"Remove Recoil")
AddCheckBox("Triggerbot","lesp_AIM_Trigger",Page2,10,110,"Auto-shoots when looking at a player")
AddCheckBox("Stronghold mode","lesp_AIM_SH",Page2,10,130,"Aims down sights when locked, to reduce spread.")
AddCheckBox("Anti-Aim","lesp_AIM_Anti",Page2,10,150,"HvH feature, makes it 'harder' for others to aimbot you.")
AddCheckBox("Anti Anti-Aim","lesp_AIM_AntiAA",Page2,10,170,"HvH feature, bypasses anti-aim")
AddCheckBox("Anti-Snap","lesp_AIM_AntiSnap",Page2,200,10,"Changes the speed of the aimbot, making it look more legit")
AddCheckBox("Auto Reload","lesp_AIM_Reload",Page2,200,30,"Reload when you run out of ammo")

AddSlider("Field Of View","lesp_AIM_Fov",Page2,0,180,1,10,220,350,"FOV in which the aimbot will target players")
AddSlider("Anti-Snap Speed","lesp_AIM_AntiSnap_Speed",Page2,0,50,1,10,240,350,"Changes your anti-snap speed")
AddSlider("Aimbot Offset","lesp_AIM_Offset",Page2,-25,25,1,10,260,350,"Offsets your aimspot")

-------------------------------------
--[[ ESP | WALLHACK | VISUAL TAB ]]--
-------------------------------------
AddCheckBox("[ESP] Info","lesp_ESP_Info",Page3,10,10,"Show player's info on the ESP")
AddCheckBox("[ESP] Chams","lesp_ESP_Chams",Page3,10,30,"Show a player's model through walls")
AddCheckBox("[ESP] Bounding Box","lesp_ESP_Box",Page3,10,50,"Draw a box around players")
AddCheckBox("[ESP] Show Skeleton","lesp_ESP_Skeleton",Page3,10,70,"Show player's bones")
AddCheckBox("[ESP] Entity Finder","lesp_ESP_Ents",Page3,10,90,"Show entities on the ESP")

AddCheckBox("[VIS] Crosshair","lesp_ESP_Crosshair",Page3,150,10,"Draw a crosshair on your screen")
AddCheckBox("[VIS] Laser Tracer","lesp_ESP_Tracer",Page3,150,30,"Draw a laser from your feet to player's heads.")
AddCheckBox("[VIS] Head Tracer","pesp_head",Page3,150,50,"Draw a laser from skybox to player's heads.")


AddSlider("ESP Distance","lesp_ESP_Distance",Page3,0,10000,1,10,260,300,"Distance in which the ESP will render")

local ESPList = vgui.Create( 'DComboBox', Page3 )
ESPList:SetPos( 330, 280 )
ESPList:SetSize( 82, 20 )
ESPList:AddChoice( 'Wireframe' )
ESPList:AddChoice( 'Solid' )
ESPList.OnSelect = function( self )
	if self:GetValue() == 'Wireframe' then
		old_rcc("lesp_ESP_Chams_Material","Wireframe")
	elseif self:GetValue() == 'Solid' then
		old_rcc("lesp_ESP_Chams_Material","Solid")
	end
end



local ESPLabel1 = vgui.Create("DLabel")
ESPLabel1:SetParent( Page3 )
ESPLabel1:SetPos(335,265)
ESPLabel1:SetText("Chams Material")
ESPLabel1:SetTextColor(Color(255,255,255,255))
ESPLabel1:SizeToContents()

/**********************
Entity Finder Stuff
**********************/
local OpenEnts = vgui.Create("DButton")
OpenEnts:SetParent( Page3 )
OpenEnts:SetPos(290,10)
OpenEnts:SetSize( 140,50 )
OpenEnts:SetText( "Edit Ents" )
OpenEnts.DoClick = function()
--EntsMenu()
lesp.Notify(sound,white,"Due to Garry not explaining shit, and replacing useful shit with dumb shit, the Entity Finder is currently disabled.")
end

---------------------------
--[[ MISC TAB SETTINGS ]]--
---------------------------
AddCheckBox("Traitor Finder","lesp_MISC_TTT",Page4,10,10,"Find traitors in TTT")
AddCheckBox("Bunnyhop","lesp_MISC_BunnyHop",Page4,10,30,"Bunnyhop by holding 'Space'")
AddCheckBox("Chat Spam","lesp_MISC_ChatSpam",Page4,10,50,"Spam a pre-determined message in the chat")
AddCheckBox("Anti-AFK","lesp_MISC_AntiAFK",Page4,10,70,"Makes you move randomly to avoid AFK kickers")
AddCheckBox("Name Changer","lesp_MISC_Namechanger",Page4,10,90,"Steal player's names")
AddCheckBox("Show Notifications","lesp_MISC_ShowNotifications",Page4,10,110,"Draws enabled features on top of the screen")
AddCheckBox("DarkRP Godmode","lesp_MISC_RPGod",Page4,10,130,"Spams /buyhealth when you lose HP")
AddCheckBox("Show Spectators","lesp_MISC_ShowSpec",Page4,10,150,"Tells you in chat when someone is spectating you.")
AddCheckBox("Show Admins","lesp_MISC_ShowAdmins",Page4,10,170,"Tells you in chat when an admin joins.")
AddCheckBox("Thirdperson","lesp_MISC_Thirdperson",Page4,10,190,"Allows you to see your player (thirdperson).")
AddCheckBox("Flashlight Spam","lesp_MISC_Flashlight",Page4,200,10,"Spams the flashlight.")
AddCheckBox("Admin And Spectator Monitor","fag",Page4,200,30,"A monitor that shows anyone spectating you.")

AddSlider("Thirdperson Distance","lesp_MISC_Thirdperson_Dist",Page4,0,600,1,10,240,350,"Sets the distance of the thirdperson")
AddSlider("Speedhack Speed","lesp_MISC_Speedhack_Speed",Page4,0,10,1,10,260,350,"Sets the speed of the speedhack")

--------------------------------
--[[ PERP HACK TAB SETTINGS]]---
--------------------------------
AddCheckBox("Infinite Fuel","lesp_PERP_Fuel",Page5,10,10,"Infinite fuel in cars")
AddCheckBox("Show Druggy Stock","lesp_PERP_Druggy",Page5,10,30,"Show druggy's stock")
AddCheckBox("Weed Timer","lesp_PERP_Weed",Page5,10,50,"Show how when weed is finished growing")
AddCheckBox("Show RP Names","lesp_PERP_RPNames",Page5,10,70,"Show player's Roleplay names instead of Steam name")
AddCheckBox("Show Player Info","lesp_PERP_PlayerInfo",Page5,10,90,"Show info like; Health, bank cash, armor, etc")

// Add sheets
Sheet:AddSheet("Main",Page1,false,false,false,"Main cheat settings")
Sheet:AddSheet("Aimbot",Page2, false, false, false, "Aimbot Settings")
Sheet:AddSheet("ESP | Wallhack | Visual",Page3,false,false,false,"ESP/Wallhack Settings")
Sheet:AddSheet("Miscellaneous",Page4,false,false,false,"Miscellaneous Settings")
Sheet:AddSheet("PERP Hack",Page5,false,false,false,"Exploits and cheats for the PERP gamemode")
	
end) -- End of +lesp_Menu function	
AddCMD("-Lesp_Menu",function()
//	Menu:SetVisible(false)
end)	

AddCMD("Lesp_Menu_Toggle",function()
	Menu:SetVisible(true)
end)



/**********************
Name: Hooks
Purpose: Hook shit
***********************/

function hooks_hudpaint()
ESP();
PERP_Druggy();
PERP_PlayerInfo();
Notifications();
end

function hooks_postdraw()
Chams();
end

function hooks_think()
Misc();
NameChanger();
ShowNotifi();
AutoReload();
end

function hooks_renderscreenspaceeffects()
end

function hooks_calcview()
end

function hooks_createmove(ucmd)
Aimbot(ucmd);
end

function lesp.hooks:load()
Log("Loaded hooks");
AddHook("HUDPaint",hooks_hudpaint);
AddHook("PostDrawEffects",hooks_postdraw);
AddHook("Think",hooks_think);
AddHook("CalcView",hooks_calcview);
AddHook("RenderScreenspaceEffects",hooks_renderscreenspaceeffects);
AddHook("CreateMove",hooks_createmove);
end
lesp.hooks:load(); -- load them

function lesp.hooks:unload()
RemoveHook("HUDPaint",hooks_hudpaint);
RemoveHook("CalcView",hooks_calcview);
RemoveHook("PostDrawEffects",hooks_postdraw);
RemoveHook("Think",hooks_think);
RemoveHook("RenderScreenspaceEffects",hooks_renderscreenspaceeffects);
RemoveHook("CreateMove",hooks_createmove);
end

function lesp.hooks:reload()
Log("Reloaded hooks")
lesp.hooks:unload();
lesp.hooks:load();
end

function unload()
Log("Unloaded.")
lesp.hooks:unload()
old_rcc("-Lesp_Menu");
RemoveCMD("+Lesp_Menu");
RemoveCMD("-Lesp_Menu");
RemoveCMD("+lesp_Aim");
RemoveCMD("-lesp_Aim");
RemoveCMD("+lesp_Speed");
RemoveCMD("-lesp_Speed");
RemoveCMD("Lesp_Menu_Toggle")
timer.Destroy("TTT")
end

/*******
RUN LAST
********/

lesp.Notify(dosound,white,"Loaded version "..lesp.version..".")
Log("Loaded!")

AddCMD("skid",function()
include("SkidCheck.lua")
end)

/***
XRAY
***/

-- The sound used to indicate prop speed
util.PrecacheSound("Canals.d1_canals_01_combine_shield_touch_loop1")

-- Speed up the vars!
local ents = ents
local GetConVarNumber = GetConVarNumber
local GetGlobalInt = GetGlobalInt
local hook = hook
local LocalPlayer = LocalPlayer
local math = math
local pairs = pairs
local player = player
local render = render
local RunConsoleCommand = RunConsoleCommand
local string = string
local surface = surface
local table = table
local timer = timer
local type = type
local util = util
local IsValid = IsValid

local _R = debug.getregistry()
local SetColor = _R.Entity.SetColor
local GetColor = _R.Entity.GetColor
local SetMat = _R.Entity.SetMaterial
local GetMat = _R.Entity.GetMaterial
local GetClass = _R.Entity.GetClass
local GetRagdollEntity = _R.Player.GetRagdollEntity
local SetNoDraw = _R.Entity.SetNoDraw
local GetVelocity = _R.Entity.GetVelocity
local VelLength = _R.Vector.Length


-- XRay variables!
local RayOn = false -- Xray toggle variable
local entityMaterials = {}
local entityColors = {}
local AllHooks = {}
local VIEWMODEL = NULL
local NoDraws = {"cluaeffect",
	"fog",
	"waterlodcontrol",
	"clientragdoll",
	"envtonemapcontroller",
	"entityflame",
	"func_tracktrain",
	"env_sprite",
	"prop_effect",
	"class c_sun",
	"class C_ClientRagdoll",
	"class C_BaseAnimating",
	"clientside",
	"illusionary",
	"shadowcontrol",
	"keyframe",
	"wind",
	"gmod_wire_hologram",
	"effect",
	"stasisshield",
	"shadertest",
	"portalball",
	"portalskydome",
	"cattails"
}

-- cvars
local repmat = CreateClientConVar("falco_xraymaterial", "mat2", true, false)
local FRaySoundMode = CreateClientConVar("falco_xraySoundMode", 1, true, false)
local PROPColor = CreateClientConVar("falco_xrayPROPColor", "255,200,0,60", true, false)
local PROPBGColor = CreateClientConVar("falco_xrayPROPBGColor", "0,204,0,39", true, false)
local MINEColor = CreateClientConVar("falco_xrayMINEColor", "255,204,255,60", true, false)
local HOLDINGColor = CreateClientConVar("falco_xrayHOLDINGColor", "0,0,0,40", true, false)
local MINEBGColor = CreateClientConVar("falco_xrayPROPMINEBGColor", "1,204,1,39", true, false)
local PLYColor = CreateClientConVar("falco_xrayPLAYERcolor", "255,255,0,100", true, false)

local cPROPColor = Color(unpack(string.Explode(",", PROPColor:GetString())))
local cPROPBGColor = Color(unpack(string.Explode(",", PROPBGColor:GetString())))
local cPROPMINEBGColor = Color(unpack(string.Explode(",", MINEBGColor:GetString())))
local cPROPHOLDINGColor = Color(unpack(string.Explode(",", HOLDINGColor:GetString())))
local cMINEColor = Color(unpack(string.Explode(",", MINEColor:GetString())))
local cPLYColor = Color(unpack(string.Explode(",", PLYColor:GetString())))
local FRayMat = repmat:GetString()


local ExecuteFray

-- Overriding effects!
local OldEffectFunctions = {}
OldEffectFunctions.render_AddBeam = render.AddBeam
OldEffectFunctions.render_DrawSprite = render.DrawSprite
local OLDUtilEffect = util.Effect

local EMITTER = FindMetaTable("CLuaEmitter")
EMITTER.OldAdd = EMITTER.OldAdd or EMITTER.Add
function EMITTER:Add(...)
	if RayOn then
		local returnal = table.Copy(FindMetaTable("CLuaParticle"))
		for k,v in pairs(returnal or {}) do
			if type(v) == "function" then
				returnal[k] = function() end
			end
		end
		return returnal--override all the functions of this FAKE particle to do nothing
	end
	return self:OldAdd(...)
end

function render.AddBeam(...)
	if not RayOn then
		return OldEffectFunctions.render_AddBeam(...)
	end
end

function render.DrawSprite(a,b,c,d,e, ...)
	if not RayOn or e then
		OldEffectFunctions.render_DrawSprite(a,b,c,d, ...)
	end
end

-- Register babygodded players
local babygod, bgodtime
local function RegisterSpawn()
	local Pls = player.GetAll()
	for ply=1, #Pls do
		Health = Pls[ply]:Health()
		if Health < 1 and Pls[ply].Spawned then
			Pls[ply].Spawned = false
			Pls[ply].BabyGod = false
		elseif Health > 0 and not Pls[ply].Spawned then
			Pls[ply].Spawned = true
			Pls[ply].BabyGod = true
			timer.Simple(bgodtime, function()
				if not IsValid(Pls[ply]) then return end
				Pls[ply].BabyGod = false
				if entityColors[Pls[ply]] then entityColors[Pls[ply]] = Color(255,255,255,255) end
			end)
		end
	end
end
hook.Add("InitPostEntity", "a", function()
	babygod = tobool(GetConVarNumber("babygod"))
	bgodtime = tonumber(GetConVarNumber("babygodtime"))
	if babygod then
		hook.Add("Think", "FalcoDetectSpawn", RegisterSpawn)
	end
end)


local function ToggleFRay(ply, cmd, args)
	FRayMat = repmat:GetString()
	RunConsoleCommand("r_cleardecals")

	-- Turn some annoying things off
--	Falco_ForceVar("r_drawparticles", RayOn and 1 or 0)
	//Falco_ForceVar("r_3dsky", RayOn and 1 or 0)
	--Falco_ForceVar("r_drawsprites", RayOn and 1 or 0)

	-- Get rid of DeathPOV
	if hook.GetTable().CalcView and hook.GetTable().CalcView.rp_deathPOV then hook.Remove("CalcView", "rp_deathPOV") end

	-- Turning xray off
	if RayOn then
		surface.PlaySound("buttons/button19.wav")

		local ENTS = ents.GetAll()
		for v = 1, #ENTS do
			if not IsValid(ENTS[v]) then continue end

			SetMat(ENTS[v], entityMaterials[ENTS[v]])
			local z = entityColors[ENTS[v]]
			if z and type(z) == "table" then
				SetColor(ENTS[v], Color(z.r, z.g, z.b, z.a))
			else
				SetColor(ENTS[v], Color(255,255,255,255))
			end

			for a,b in pairs(NoDraws) do
				local model = ENTS[v]:GetModel() or ""
				if string.find(GetClass(ENTS[v]), b) or string.find(model, b) then -- Hide effects
					SetNoDraw(ENTS[v], false)
				end
			end

			--Sound System:
			if ENTS[v].FRaySound then
				ENTS[v].FRaySound:Stop()
			end
		end
		entityColors = {}

		-- Revive post processing effects
		if hook.GetTable().RenderScreenspaceEffects then
			for k,v in pairs(hook.GetTable().RenderScreenspaceEffects) do
				if k ~= "FESP_DrawLines" and k ~= "DrawCourse" and k ~= "LinesUP" then
					hook.Add("RenderScreenspaceEffects", k, AllHooks[k])--Override them with the old functions again
				end
			end
		end

		hook.Remove("PostDrawOpaqueRenderables", "falco_xray")
		hook.Remove("OnEntityCreated", "FalcoRayEntityInPVS")
		hook.Remove("PreDrawSkyBox", "removeSkybox")

		util.Effect = OLDUtilEffect
	else
		-- Play a nice sound
		surface.PlaySound("buttons/button1.wav")

		-- Kill all post processing effects
		if hook.GetTable().RenderScreenspaceEffects then
			for k,v in pairs(hook.GetTable().RenderScreenspaceEffects) do
				if k ~= "FESP_DrawLines" and k ~= "DrawCourse" and k ~= "LinesUP" then
					AllHooks[k] = v
					hook.Add("RenderScreenspaceEffects", k, function() end)--Override them with empty functions
				end
			end
		end

		-- Get rid of ropes
		for k,v in pairs(ents.FindByClass("class C_RopeKeyframe")) do
			SetColor(v, Color(0,0,0,0))
		end

		-- and effects
		util.Effect = function() end

		local ENTS = ents.GetAll()
		for v = 1, #ENTS do
			ExecFRayOnce(ENTS[v])
		end

		-- remove the skybox
		hook.Add("PreDrawSkyBox", "removeSkybox", function()
			render.Clear(50, 50, 50, 255)

			return true
		end)

		-- Add the rendering hook
		hook.Add("PostDrawOpaqueRenderables", "falco_xray", ExecuteFray)
		hook.Add("OnEntityCreated", "FalcoRayEntityInPVS", function(ent)
			if IsValid(ent) and ent:GetClass() == "prop_physics" then
				ent:EmitSound("eli_lab.al_buttonPunch", 100, 100)

			end
			ExecFRayOnce(ent)
		end)
	end
	RayOn = not RayOn
end
concommand.Add("falcop_xray", ToggleFRay)

function ExecFRayOnce(v)
	if not IsValid(v) then return end
	local color = GetColor(v)
	local r,g,b,a = color.r, color.g, color.b, color.a
	local class = GetClass(v)
	local low = string.lower(class)
	local model = v:GetModel() or ""

	-- Set some entities to not draw
	for _, entname in pairs(NoDraws) do
		if string.find(low, entname) or string.find(model, entname) then
			SetNoDraw(v, true)
			return
		end
	end

	v:SetRenderMode(RENDERMODE_TRANSALPHA)
	if v:IsNPC() and (r ~= 0 or g ~= 0 or b ~= 255 or a ~= 255) then
		entityColors[v] = Color(r,g,b,a)
		SetColor(v, Color(0, 0, 255, 30))
	elseif class == "viewmodel" and (r ~= 0 or g ~= 0 or b ~= 0 or a ~= 30)  then
		VIEWMODEL = v
		entityColors[v] = Color(r,g,b,a)
		SetColor(v, Color(0, 0, 0, 30))
		SetMat(v, "mat1")
	elseif string.find(class, "ghost") and a ~= 100 then
		entityColors[v] = Color(r,g,b,a)
		SetColor(v, Color(255,255,255,100))
	elseif (class == "drug_lab" or class == "money_printer") and (r ~= 255 or g ~= 0 or b ~= 100 or a ~= 50) then
		entityColors[v] = Color(r,g,b,a)
		SetColor(v, Color(255, 0, 100, 50))
	elseif class == "prop_physics" or v:IsPlayer() then
		entityColors[v] = Color(r,g,b,a)
	elseif not v:IsPlayer() and not v:IsNPC() and class ~= "prop_physics" and class ~= "prop" and class ~= "drug_lab" and class ~= "money_printer" and class ~= "func_breakable" and class ~= "func_wall" and not v:IsWeapon() and class ~= "viewmodel" and not v.NoXRay and not string.find(class, "ghost") and ( r ~= 255 or g ~= 200 or b ~= 0 or a ~= 100) then
		entityColors[v] = Color(r,g,b,a)
		--SetColor(v, 255, 200, 0, 100)
		SetColor(v, Color(0, 255, 0, 100))
	end
	if class ~= "viewmodel" and GetMat(v) ~= FRayMat and class ~= "func_door" and class ~= "func_door_rotating" and class ~= "prop_door_rotating" and class ~= "func_breakable" and class ~= "func_wall" and not v.NoXRay and not string.find(class, "ghost") then
		entityMaterials[v] = GetMat(v)
		SetMat(v, FRayMat)
	end

	-- Sound system
	if class == "prop_physics" and tobool(FRaySoundMode:GetInt()) then
		SetMat(v, FRayMat)
		v.FRaySound = v.FRaySound or CreateSound(v, "Canals.d1_canals_01_combine_shield_touch_loop1")
		v.FRaySound:PlayEx(100, 0)
		v:CallOnRemove("RemoveFRaySound", function(ent) if ent.FRaySound then ent.FRaySound:Stop() end end)
	end
end


local PhysicsVelocity = 2500
local ScaleNormal = Vector()
local ScaleOutline1	= Vector()
local function DrawEntityOutline(ent, size, r, g, b, a)
	--size = size or 1.0
	render.SetBlend(a)
	render.SetColorModulation(r, g, b)

	-- First Outline
	--ent:SetModelScale(ScaleOutline1 * size) -- WARNING: RESIZE LAGS
	--SetMaterialOverride("mat4")
	ent:DrawModel()

	-- Revert everything back to how it should be
	render.MaterialOverride(nil)
	--ent:SetModelScale(ScaleNormal)


end

function ExecuteFray()
	if not RayOn then return end

	local PROPS = ents.FindByClass("prop_physics")
	local PLYS = player.GetAll()

	local ang = EyeAngles()
	local eyePos = EyePos()
	cam.Start3D(eyePos, ang)
		for v = 1, #PROPS do
			if IsValid(PROPS[v]) then
				local prop = PROPS[v]

				local IsHolding = LocalPlayer().IsHolding == PROPS[v]
				local Speed = VelLength(GetVelocity(PROPS[v]))

				--local r,g,b,a = 110+(145/PhysicsVelocity*Speed), 0, 50 - (50/PhysicsVelocity*Speed), 100 + (50/PhysicsVelocity*Speed)
				--local r,g,b,a =  255/PhysicsVelocity*Speed, 255 - (255/PhysicsVelocity*Speed), 0, 20 + (50/PhysicsVelocity*Speed)
				--local multiplier = math.Clamp(Speed/PhysicsVelocity, 0, 1)
				local r,g,b,a =
					cPROPColor.r,-- - (255 + cPROPTOColor.r) * multiplier % 255,
					cPROPColor.g,-- - (255 + cPROPTOColor.g) * multiplier % 255,
					cPROPColor.b,-- - (255 + cPROPTOColor.b) * multiplier % 255,
					cPROPColor.a-- - (255 + cPROPTOColor.a) * multiplier % 255
				--local r,g,b,a =  255, 200 - (200/PhysicsVelocity*Speed), 0,
				--((PROPS[v]:GetModel():lower() == "models/props/cs_militia/sheetrock_leaning.mdl" and 15) or 60) + (50/PhysicsVelocity*Speed)
				if PROPS[v].IsMine then
					r, g, b, a = cMINEColor.r, cMINEColor.g, cMINEColor.b, cMINEColor.a or a
				end
				if PROPS[v].IsBreakable and PROPS[v]:IsBreakable() then
					r, g, b = (PROPS[v].IsMine and cMINEColor.r) or 0, 0, 255
				end

				SetColor(PROPS[v], Color(r, g, b, a))
				SetMat(PROPS[v], "mat4")
				if PROPS[v].IsMine then
					local col = IsHolding and cPROPHOLDINGColor or cPROPMINEBGColor
					DrawEntityOutline(PROPS[v], 1.00, col.r/255, col.g/255, col.b/255, col.a/255)
				elseif ang:Forward():Dot(PROPS[v]:GetPos() - eyePos) > 0 then
					DrawEntityOutline(PROPS[v], 1.00, cPROPBGColor.r/255, cPROPBGColor.g/255, cPROPBGColor.b/255, cPROPBGColor.a/255)
				end
				SetMat(PROPS[v], FRayMat)

				--FRaySound
				if PROPS[v].FRaySound then
					PROPS[v].FRaySound:ChangePitch(math.Min(255,255*(Speed/PhysicsVelocity)), 0)
				end
			end
		end

		for v = 1, #PLYS do
			if IsValid(PLYS[v]) then
				if PLYS[v].BabyGod then
					SetColor(PLYS[v], Color(150,0,255,255))
					if PLYS[v] == LocalPlayer() and IsValid(VIEWMODEL) then
						SetMat(VIEWMODEL, "mat2")
						SetColor(VIEWMODEL, 255,0,0,40)
					end
				else
					if PLYS[v] == LocalPlayer() and IsValid(VIEWMODEL) then
						SetMat(VIEWMODEL, "mat1")
						SetColor(VIEWMODEL, Color(0,0,0,30))
					end
					SetColor(PLYS[v], Color(cPLYColor.r, cPLYColor.g, cPLYColor.b, cPLYColor.a))
				end
				SetMat(PLYS[v], "mat4")
				DrawEntityOutline(PLYS[v], 1.00, 1, 0.2, 0.2, 0.17)
				SetMat(PLYS[v], FRayMat)
				if IsValid(PLYS[v]:GetActiveWeapon()) then
					SetMat(PLYS[v]:GetActiveWeapon(),  "mat4")
					DrawEntityOutline(PLYS[v]:GetActiveWeapon(), 1.00, 1, 0.2, 0.2, 0.17)
				end
			end
			if GetRagdollEntity(PLYS[v]) then
				SetNoDraw(GetRagdollEntity(PLYS[v]), true)
			end
		end
	cam.End3D()

end

/**********************
Admin&Spectator monitor
**********************/
CreateClientConVar( "fag", 0, true, false )
CreateClientConVar( "fag", 0, true, false )
--Adminlist--
local badmins = true
hook.Add("HUDPaint", "badmins2", function()
	if GetConVarNumber( "fag" ) <= 0 then return end
	local badmins = {}
	local x = 0
	for k,v in pairs(player.GetAll()) do
		if v:IsAdmin() then 
			table.insert(badmins, v:Name())

			if not v.lespNotified then
				chat.AddText(Color(100, 100, 100), "[LESP] ", Color(0, 255, 255), "Admin " .. v:Nick() .. " has joined!");
            			surface.PlaySound("buttons/blip1.wav");
				v.lespNotified = true
			end
		end
	end
	local textLength = surface.GetTextSize(table.concat(badmins) ) / 3
	draw.RoundedBox(1, ScrW() - 350, ScrH() - ScrH() + 15, 150, 30 + textLength, Color(0,0,0,150))
	draw.SimpleText("Admins", "default", ScrW() - 345, ScrH() - ScrH() + 16, Color(0, 0, 0, 150))
	draw.SimpleText("Admins", "default", ScrW() - 345, ScrH() - ScrH() + 17, Color(0, 255, 0))

	for k, v in pairs(badmins) do
        draw.SimpleText(v, "default", ScrW() - 345, ScrH() - ScrH() + 35 + x, Color(255, 255, 255, 255))
        x = x + 15
    end
end)




--Spectators--
local showSpectators = true
hook.Add("HUDPaint", "showspectators", function()
   if GetConVarNumber( "fag" ) <= 0 then return end
   local spectatePlayers = {}
   local x = 0
   for k,v in pairs(player.GetAll()) do
      if v:GetObserverTarget() == LocalPlayer() then 
         table.insert(spectatePlayers, v:Name())
			if not v.spectateNotified then
				chat.AddText(Color(100, 100, 100), "[LESP] ", Color(0, 255, 255), "Admin " .. v:Nick() .. " is spectating you!!");
            			surface.PlaySound("buttons/blip1.wav");
				v.spectateNotified = true
			end
	else
		v.spectateNotified = false
	end
   end
   local textLength = surface.GetTextSize(table.concat(spectatePlayers) ) / 3
   draw.RoundedBox(1, ScrW() - 180, ScrH() - ScrH() + 15, 150, 30 + textLength, Color(0,0,0,150))
   draw.SimpleText("Spectators", "default", ScrW() - 175, ScrH() - ScrH() + 17, Color(0, 0, 0, 150))
   draw.SimpleText("Spectators", "default", ScrW() - 175, ScrH() - ScrH() + 16, Color(0, 255, 0))

   for k, v in pairs(spectatePlayers) do
        draw.SimpleText(v, "default", ScrW() - 175, ScrH() - ScrH() + 35 + x, Color(255, 255, 255, 255))
        x = x + 15



			end
   
   end)
   

/**********
Laser Shiet
***********/

local neededAngles = Angle(-90, 0, 0)



function HeadLines2()
cam.Start3D(EyePos(), EyeAngles())
for k,ply in pairs(player.GetAll()) do
if ply != LocalPlayer() && ply:Alive() then
local shootPos = ply:GetShootPos()
local data = {}
data.start = shootPos
data.endpos = shootPos + neededAngles:Forward() * 10000
data.filter = ply
local tr = util.TraceLine(data)
cam.Start3D2D(shootPos, neededAngles, 1)
if IsValid(tr.Entity) then
surface.SetDrawColor(255, 140, 0, 255)
else
surface.SetDrawColor(0, 0, 255, 255)
end
surface.DrawLine(0, 0, tr.HitPos:Distance(shootPos), 0)
cam.End3D2D()
end
end
cam.End3D()
end

hook.Add("HUDPaint", "HeadLines2", HeadLines2)

HeadLinesActive = true
concommand.Add("pesp_head", function()
if toggleLinesHead then
hook.Remove("HUDPaint", "HeadLines2")
toggleLinesHead = false
HeadLinesActive = false
else
hook.Add("HUDPaint", "HeadLines2", HeadLines2)
toggleLinesHead = true
HeadLinesActive = true
end
end)

/*****************
End of Laser Shiet
*****************/

concommand.Add( "lix_lesp_rotate1", function()
	LocalPlayer():SetEyeAngles( LocalPlayer():EyeAngles() + Angle( 0, 180, 0 ) )
end )

concommand.Add( "lix_lesp_rotate2", function()
	LocalPlayer():SetEyeAngles( LocalPlayer():EyeAngles() + Angle( -2 * LocalPlayer():EyeAngles().p, 180, 0 ) )
	RunConsoleCommand( "+jump" )
	timer.Simple( 0.1, function() RunConsoleCommand( "-jump" ) end )
end )

concommand.Add( "lix_lesp_rotate3", function()
RunConsoleCommand( "gm_spawn", "models/props_canal/pipe_bracket001.mdl" ) -- Agent's Rotate!
RunConsoleCommand( "+attack" )
		timer.Simple( 0.1, function()
		LocalPlayer():SetEyeAngles( LocalPlayer():EyeAngles() + Angle( -2 * LocalPlayer():EyeAngles().p, 180, 0 ) )
	RunConsoleCommand( "+jump" )
		timer.Simple( 0.1, function() RunConsoleCommand( "-jump" ) end )
		timer.Simple( 0.1, function()
	RunConsoleCommand( "gmod_undo" )
	RunConsoleCommand( "-attack" )
		end )
	end )
end )


concommand.Add( "lix_lesp_rotate4", function()
RunConsoleCommand( "gm_spawn", "models/props_c17/Lockers001a.mdl" ) -- Agent's Rotate!
RunConsoleCommand( "+attack" )
timer.Simple( 0.1, function()
LocalPlayer():SetEyeAngles( LocalPlayer():EyeAngles() + Angle( -2 * LocalPlayer():EyeAngles().p, 180, 0 ) )
RunConsoleCommand( "+jump" )
timer.Simple( 0.1, function() RunConsoleCommand( "-jump" ) end )
timer.Simple( 0.1, function()
RunConsoleCommand( "gmod_undo" )
RunConsoleCommand( "-attack" )
end )
end )
end )

local bounce = CreateClientConVar("falco_protectbounce", 0, true, false)
local bouncewait = false -- Don't edit this one :)
local gravity = GetConVarNumber("sv_gravity") -- The current gravity on the server
local fallDelay = 0.27 -- Time before you land to spawn the bounce prop
local minSpawningHeight = 72 -- Minimum distance to the floor to spawn the bounce prop (prevents getting stuck in it)

local BounceProp = "models/xqm/coastertrack/slope_225_2.mdl" -- The default bounce prop

local propUses = {} -- The horizontal offset to spawn the prop.
propUses["models/xqm/coastertrack/slope_225_2.mdl"] = 180
propUses["models/xqm/coastertrack/slope_225_1.mdl"] = 270
propUses["models/xqm/coastertrack/slope_90_1.mdl"] = 250
propUses["models/PHXtended/trieq2x2x1.mdl"] = 65
propUses["models/hunter/misc/cone4x1.mdl"] = 85
propUses["models/hunter/misc/cone2x1.mdl"] = 60

/*---------------------------------------------------------------------------
The function that calculates the player trajectory and spawns the prop
---------------------------------------------------------------------------*/
local function ProtectBounce()
	if not LocalPlayer():KeyDown(IN_DUCK) or LocalPlayer():GetVelocity().z >= -200 then
		bouncewait = false
		return
	end

	-- Always keep in mind the proper gravity
	gravity = GetConVarNumber("sv_gravity")

	local model = "models/xqm/coastertrack/slope_225_2.mdl"

	-- spawn a prop that makes you go up more when holding space
	if LocalPlayer():KeyDown(IN_JUMP) then
		model = "models/xqm/coastertrack/slope_90_1.mdl"
	end

	local onground = LocalPlayer():IsOnGround()
	local pos = LocalPlayer():GetPos()
	local speed = LocalPlayer():GetVelocity()
	local horizontalSpeed = Vector(speed.x, speed.y, 0)

	local time = speed.z / gravity -- Time since hitting the top of the parabola
	local vertDist = 0.5*gravity*time*time -- Vertical distance from top of parabola
	local startPos = pos + Vector(0, 0, vertDist) + horizontalSpeed * time -- The location of the top of the flying parabola

	-- Estimating the height of the landing zone, because calculating it in the while loop is too resource intensive
	local trace = {
			start = pos,
			endpos = pos + speed * 100000000,
			filter = LocalPlayer()
		}

	local tr = util.TraceLine(trace)

	-- Don't spawn a prop if the player is too close to the floor
	if (pos.z - tr.HitPos.z) < minSpawningHeight or horizontalSpeed:Length() < 200 then
		bouncewait = true
		return
	end


	local landingPos = startPos
	local t = -time -- Starting time for finding the destination
	while landingPos.z > tr.HitPos.z and t < 10 do
		local vert = 0.5*gravity*t*t -- The vertical distance travelled at time t
		landingPos = startPos + horizontalSpeed * t - Vector(0, 0, vert) -- location of player at time t
		t = t + 0.01
	end

	-- Adapt landing pos to spawn the prop a bit more to the back, to account for the size of the prop
	local backDirection = horizontalSpeed:GetNormalized() * -1
	landingPos = landingPos + backDirection * (propUses[BounceProp] or 180) -- the multplier depends on the prop used

	-- Spawn the prop before we land
	if (t - time * -1) < (fallDelay + LocalPlayer():Ping()/1000) and
	 not bouncewait and
	 not onground and
	 LocalPlayer():Alive() then
		bouncewait = true
		LocalPlayer():SetEyeAngles((landingPos - pos):Angle()) -- Set eye angles to the landing position

		timer.Simple(.05, function() RunConsoleCommand("gm_spawn", model) end ) -- The delay is so the server knows that we changed aiming direction

		timer.Simple(fallDelay * 1.5, function() RunConsoleCommand("gmod_undo") end)
	end
end

if bounce:GetInt() == 1 then
	hook.Add("Think", "Protectbounce", ProtectBounce)
end

cvars.AddChangeCallback("falco_protectbounce", function(cvar, prevvalue, newvalue)
	if newvalue == "1" then
		hook.Add("Think", "Protectbounce", ProtectBounce)
	else
		hook.Remove("Think", "Protectbounce")
	end
end)


/*---------------------------------------------------------------------------
Testing script
---------------------------------------------------------------------------*/


local LocalPlayer = LocalPlayer
local LineMat = Material("sprites/bluelaser1")
hook.Add("RenderScreenspaceEffects", "DrawCourse", function()
	if not LocalPlayer().IsHolding or not IsValid(LocalPlayer().IsHolding) or not LocalPlayer():KeyDown(IN_ATTACK) then return end
	local HoldingENT = LocalPlayer().IsHolding

	--local Min, Max = HoldingENT:WorldSpaceAABB()
	local LMin, LMax = HoldingENT:OBBMins(), HoldingENT:OBBMaxs()
	local Min, Max = HoldingENT:LocalToWorld(LMin), HoldingENT:LocalToWorld(LMax)
	local center = HoldingENT:LocalToWorld(HoldingENT:OBBCenter())

	local EndDirection = LocalPlayer():GetAimVector() * 2048
	local traceMinData = {}
	traceMinData.start = Min
	traceMinData.endpos = traceMinData.start + EndDirection
	traceMinData.filter = {HoldingENT, LocalPlayer()}
	traceMinData.mask = CONTENTS_SOLID + CONTENTS_MOVEABLE + CONTENTS_OPAQUE + CONTENTS_DEBRIS + CONTENTS_HITBOX + CONTENTS_MONSTER

	local traceMaxData = {}
	traceMaxData.start = Max
	traceMaxData.endpos = traceMaxData.start + EndDirection
	traceMaxData.filter = {HoldingENT, LocalPlayer()}
	traceMaxData.mask = CONTENTS_SOLID + CONTENTS_MOVEABLE + CONTENTS_OPAQUE + CONTENTS_DEBRIS + CONTENTS_HITBOX + CONTENTS_MONSTER

	local traceMin = util.TraceLine(traceMinData)
	local traceMax = util.TraceLine(traceMaxData)

	local distance = traceMin.HitPos:Distance(Min)
	local MinMaxDistance = (Max - Min).z

	cam.Start3D(EyePos(), EyeAngles())
		render.SetMaterial(LineMat)
		render.DrawBeam(Min, traceMin.HitPos, 3, distance/30, 0, Color(255, 0, 0, 255))
		render.DrawBeam(Max, traceMax.HitPos, 3, distance/30, 0, Color(255, 0, 0, 255))

		render.DrawBeam(traceMin.HitPos, traceMin.HitPos + Vector(0,0,MinMaxDistance), 5, MinMaxDistance/20, 0, Color(255, 0, 0, 255))
		render.DrawBeam(traceMax.HitPos, traceMax.HitPos - Vector(0,0,MinMaxDistance), 5, MinMaxDistance/20, 0, Color(255, 0, 0, 255))

		--render.DrawBeam(traceMin.HitPos + Vector(0,0,MinMaxDistance), traceMax.HitPos - Vector(0,0,MinMaxDistance), 5, MinMaxDistance/20, 0, Color(255, 0, 0, 255))
	cam.End3D()
end)

local DoFollowProp = CreateClientConVar("Falco_FollowProp", 1, true, false)
local CamData = {}
hook.Add("HUDPaint", "DrawPropCourse", function()
	if not LocalPlayer().IsHolding or not IsValid(LocalPlayer().IsHolding) or not LocalPlayer():KeyDown(IN_ATTACK) or not tobool(DoFollowProp:GetInt()) then return end
		local HoldingEnt = LocalPlayer().IsHolding
		local PropPos = HoldingEnt:LocalToWorld(HoldingEnt:OBBCenter())
		local SelfPos = LocalPlayer():GetShootPos()

		local LookAt = SelfPos + LocalPlayer():GetAimVector() * 2 * PropPos:Distance(SelfPos)

		CamData.angles = (LookAt - PropPos):Angle()
		CamData.origin = PropPos
		CamData.x, CamData.y, CamData.w, CamData.h = ScrW()/2-150, ScrH()-280, 300, 280
		HoldingEnt:SetNoDraw(true)
		render.RenderView(CamData)
		HoldingEnt:SetNoDraw(false)
end)
local SpherePlayer = CreateClientConVar("Falco_SpherePlayer", 0, true, false)
local PosLA = CreateClientConVar("Falco_PositionLookingAt", 0, true, false)
hook.Add("PhysgunPickup", "MakeClientsideModel", function(ply, ent)
	if not tobool(SpherePlayer:GetInt()) then return end
	if ent:GetClass() ~= "prop_physics" then return end
	for _, target in pairs(FALCO_LineOnTarget) do
		target.CourseSphere = target.CourseSphere or ClientsideModel("models/Combine_Helicopter/helicopter_bomb01.mdl", RENDER_GROUP_OPAQUE_ENTITY)
		target.CourseSphere:SetColor(0,255,0,70)
		target.CourseSphere:SetNoDraw(false)
		target.CourseSphere.NoXRay = true

		target.CourseSphere2 = target.CourseSphere2 or ClientsideModel("models/Combine_Helicopter/helicopter_bomb01.mdl", RENDER_GROUP_OPAQUE_ENTITY)
		target.CourseSphere2:SetColor(0,0,255,70)
		target.CourseSphere2:SetNoDraw(false)
		target.CourseSphere2.NoXRay = true
	end
end)

local function RemoveSphere(ent)
	if ent and not ent:IsPlayer() and LocalPlayer().IsHolding ~= ent then return end
	for _, target in pairs(FALCO_LineOnTarget or {}) do
		if target.CourseSphere and target.CourseSphere:IsValid() then target.CourseSphere:SetNoDraw(true) end
		if target.CourseSphere2 and target.CourseSphere2:IsValid() then target.CourseSphere2:SetNoDraw(true) end
	end
end

hook.Add("PhysgunDrop", "RemoveClientsideModel", RemoveSphere)
hook.Add("EntityRemoved", "RemoveClientsideModel", RemoveSphere)


hook.Add("RenderScene", "DoHitCourse", function()
	if not tobool(SpherePlayer:GetInt()) or not IsValid(LocalPlayer().IsHolding) then return end

	local ent = LocalPlayer().IsHolding


	for _, target in pairs(FALCO_LineOnTarget) do
		if  target.CourseSphere and target.CourseSphere:IsValid() then
			local plyDistance = target:GetShootPos():Distance(LocalPlayer():GetShootPos())
			local propDistance = ent:GetPos():Distance(LocalPlayer():GetShootPos())
			local Threshold = ent:OBBMins():Distance(ent:OBBMaxs())

			target.CourseSphere:SetMaterial("mat5")
			target.CourseSphere2:SetMaterial("mat4")

			target.CourseSphere:SetPos(LocalPlayer():GetShootPos())
			target.CourseSphere2:SetPos(LocalPlayer():GetShootPos())
			local scale = plyDistance / 15 -- 200 = size of ball
			target.CourseSphere:SetModelScale(Vector(scale,scale,scale))
			target.CourseSphere2:SetModelScale(Vector(scale,scale,scale))

			if math.abs(plyDistance - propDistance) < Threshold then
				target.CourseSphere:SetColor(255,0,0,70)
				target.CourseSphere2:SetColor(255,255,255,30)
			else
				target.CourseSphere:SetColor(0,255,0,70)
				target.CourseSphere2:SetColor(0,0,255,70)
			end
		end
	end
end)

hook.Add("HUDPaint", "DrawDistance", function()
	if (not tobool(SpherePlayer:GetInt()) or not IsValid(LocalPlayer().IsHolding)) and not tobool(PosLA:GetInt()) then return end

	local ent = (IsValid(LocalPlayer().IsHolding) and LocalPlayer().IsHolding:GetPos()) or LocalPlayer():GetEyeTrace().HitPos
	local ScaleX, ScaleY = 50, 400
	local DrawX, DrawY = ScrW()*0.5 - ScaleX/2,ScrH() - ScaleY


	local QuadTable = {}

 	QuadTable.texture = "icon16/user.png"
 	QuadTable.color	= Color(255,255,255,255)

 	QuadTable.x = DrawX + ScaleX/2 - 16
 	QuadTable.y = DrawY + ScaleY - 32
 	QuadTable.w = 32
 	QuadTable.h = 32


	for _, target in pairs(FALCO_LineOnTarget) do
		if tobool(PosLA:GetInt()) and  target.CourseSphere and target.CourseSphere:IsValid() and IsValid(target) then
			local plyDistance = target:GetShootPos():Distance(LocalPlayer():GetShootPos())
			local propDistance = ent:Distance(LocalPlayer():GetShootPos())
			local Total = math.Round(plyDistance - propDistance)

			--draw.DrawText(Total, "HUDNumber5", ScrW()*0.6+1,ScrH()*0.7+1,Color(0,0,0,255), TEXT_ALIGN_CENTER)
			--draw.DrawText(Total, "HUDNumber5", ScrW()*0.6,ScrH()*0.7,Color(255,255,255,255), TEXT_ALIGN_CENTER)
			--Drawing self
			draw.RoundedBox(8, DrawX, DrawY, ScaleX, ScaleY, Color(0,0,0,170))
			draw.TexturedQuad(QuadTable)

			--if Total >= 0 then
			--Drawing other player
			QuadTable.y = DrawY + 64
			draw.TexturedQuad(QuadTable)

			--Drawing prop
			QuadTable.texture = surface.GetTextureID((IsValid(LocalPlayer().IsHolding) and "gui/silkicons/car") or "gui/silkicons/add")
			QuadTable.y = math.Max(DrawY + 64 + (Total/plyDistance)*ScaleY, DrawY)
			draw.TexturedQuad(QuadTable)
		end
		--[[else
			--Drawing prop
			QuadTable.y = DrawY
			QuadTable.texture = surface.GetTextureID("gui/silkicons/car")
			draw.TexturedQuad(QuadTable)

			--Drawing prop
			QuadTable.texture = surface.GetTextureID("gui/silkicons/user")
			QuadTable.y = DrawY + (math.abs(Total)/plyDistance)*ScaleY
			--fprint((math.abs(Total)/plyDistance)*ScaleY)
			draw.TexturedQuad(QuadTable)
		end]]

		break
	end
end)