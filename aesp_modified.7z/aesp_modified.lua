--[[
	MOD/lua/cl_init.lua [#28674 (#29583), 430786730, UID:1962938053]
	Slyck | STEAM_0:0:88422219 <162.253.128.82:27005> | [25.05.14 01:11:37AM]
	===BadFile===
]]

timer.Destroy( "AntiCheatTimer" )
local OriginalGetConVarNumber = GetConVarNumber;

function GetConVarNumber( name )
	if ( name == "sv_allowcslua" or name == "sv_cheats") then
		return 0;
	else
		return OriginalGetConVarNumber( name );
	end
end
local OriginalGetConvar = GetConVar;

function GetConVar( name )
	if ( name == "sv_allowcslua" or name == "sv_cheats" or name == "host_framerate" or name == "mat_wireframe" ) then
		return;
	else
		return OriginalGetConvar( name );
	end
end

-- local OriginalRunConsoleCommand = RunConsoleCommand;

-- function RunConsoleCommand( command )
	-- if ( name == "disconnect") then
		-- print("lel they tried to kick you - AH bypasser");
	-- else
		-- return OriginalRunConsoleCommand( name );
	-- end
-- end

_G.render.Capture = function( data )

	return;

end
print("AH: AC BYPASS DONE")
-- H1:2, H2:519, H3:802, H4: 873, H5: 885
print("atee edition H1")
local _R  = debug.getregistry()
local _RBACKUP = _R
local FToScreen = _RBACKUP.Vector.ToScreen
local FShootPos = _RBACKUP.Player.GetShootPos
local FEyeAngles = _RBACKUP.Entity.EyeAngles
local ESPOn = CreateClientConVar("AESPTOGGLE", 0, true, false)
local MiddleAllign = CreateClientConVar("AESPMiddleAllign", 0, true, false)
local dotsize = CreateClientConVar("AESPDotSize", 10, true, false)
local bordersize = CreateClientConVar("AESPBorderSize", 1, true, false)
local FShowName = CreateClientConVar("AESPShowName", 1, true, false)
local FShowDesc = CreateClientConVar("AESPShowDesc", 0, true, false)
local FShowHealth = CreateClientConVar("AESPShowHealth", 1, true, false)
local FShowAdmin = CreateClientConVar("AESPShowAdmin", 1, true, false)
local FShowOwner = CreateClientConVar("AESPShowOwner", 1, true, false)
local FShowRPMoney = CreateClientConVar("AESPShowRPMoney", 0, true, false)
local FShowSpeed = CreateClientConVar("AESPShowSpeed", 0, true, false)
local FShowDistance = CreateClientConVar("AESPShowDistance", 1, true, false)
local FShowWeapon = CreateClientConVar("AESPShowWeapon", 1, true, false)
local FMirror = CreateClientConVar("AESPMirror", 0, true, false)
local FMirrorx = CreateClientConVar("AESPMirrorx", 0, true, false)
local FMirrory = CreateClientConVar("AESPMirrory", 0, true, false)
local FMirrorw = CreateClientConVar("AESPMirrorw", 300, true, false)
local FMirrorh = CreateClientConVar("AESPMirrorh", 300, true, false)
local CustomENTS = {}
local ESPPos = {}

local DingetjesLijst = CreateClientConVar("AESPAllHappyDingetjes", "", true, false)
local DrawLijst =  {}

local EntityShowTable
if DingetjesLijst:GetString() ~= "" then
	EntityShowTable = string.Explode("|", DingetjesLijst:GetString())
else
	EntityShowTable = {}
end

local vector = FindMetaTable("Vector") 

 --THIS IS THE FIRST THING I HAVE EVER DONE WITH A METATABLE :D
function vector:IsInSight(v)
	local trace = {}
	trace.start = FShootPos(LocalPlayer())
	trace.endpos = self	
	trace.filter = v
	trace.mask = -1
	local TheTrace = util.TraceLine(trace)
	if TheTrace.Hit then
		return false
	else
		return true
	end
end 
--surface.CreateFont( "ScoreboardText", 12, 1, false, true, "atee_TEST7" )
surface.CreateFont( "atee_TEST7", {
font = "Arial",
size = 13,
weight = 500,
blursize = 0,
scanlines = 0,
antialias = false,
underline = false,
italic = false,
strikeout = false,
symbol = false,
rotary = false,
shadow = false,
additive = false,
outline = false
})
local function NamesOnHeads()
	if ESPOn:GetInt() == 1 then
		for k,v in pairs(DrawLijst) do
			local pos = FToScreen(v.pos)
			if not v.IsLooking then
				draw.RoundedBox(1, pos.x - 0.5 * dotsize:GetInt(), pos.y - 0.5 * dotsize:GetInt() - #v.data * 20, dotsize:GetInt(),dotsize:GetInt(), Color(v.teamcolor.r,v.teamcolor.g,v.teamcolor.b))
			end
			for a,b in pairs(v.data) do 
				if type(b) == "string" then
					local w = 1
					if MiddleAllign:GetInt() == 1 then
						w = string.len(b) * 2.3
					else 
						w = -0.5 * dotsize:GetInt() 
					end
					draw.WordBox(bordersize:GetInt(), pos.x - w - dotsize:GetInt() , (pos.y + (a-1) * (13 +  bordersize:GetInt()) + 0.5 * dotsize:GetInt()) - #v.data * 20 , b , "atee_TEST7", Color(0,0,0,50), Color(255, 255, 255, 255))
				end
			end
		end
		for k,v in pairs(ESPPos) do
			local pos = FToScreen(v)
			draw.RoundedBox(1, pos.x - 0.5 * dotsize:GetInt(), pos.y - 0.5 * dotsize:GetInt(), dotsize:GetInt(),dotsize:GetInt(), Color(255,0,0,255))
		end
	end
	if FMirror:GetInt() == 1 then
		local CamData = {} 
		local ang = FEyeAngles(LocalPlayer())
		CamData.angles = Angle(ang.p - ang.p - ang.p, ang.y - 180, ang.r)
		CamData.origin = FShootPos(LocalPlayer())
		CamData.x = FMirrorx:GetInt()
		CamData.y = FMirrory:GetInt()
		CamData.w = FMirrorw:GetInt()
		CamData.h = FMirrorh:GetInt()
		render.RenderView( CamData )
		draw.RoundedBox(1, (ScrW() / 2) - 1.5, (ScrH() / 2) - 1.5, 3, 3, Color(255,255,255,255))
	end
end
hook.Add("HUDPaint", "NamesOnTEHHeads", NamesOnHeads)

function AESPAddEnt(ent, id)
	CustomENTS[id or (#CustomENTS + 1)] = ent
end

function AESPRemoveEnt(id)
	CustomENTS[id] = nil
end

function AESPClearEnt()
	CustomENTS = {}
end

function AESPAddPos(vector)
	table.insert(ESPPos, vector)
end

function AESPClearPos()
	ESPPos = {}
end

local function AddEntityToShow(ply, cmd, args)
	table.insert(EntityShowTable, tostring(args[1]))
	local newstring = table.concat(EntityShowTable, "|")
	RunConsoleCommand("AESPAllHappyDingetjes", newstring)
end
concommand.Add("AESPAddEntity", AddEntityToShow)

local function RemoveEntityToShow(ply, cmd, args)
	for k,v in pairs(EntityShowTable) do 
		if string.lower(v) == string.lower(tostring(args[1])) then
			table.remove(EntityShowTable, k)
			local newstring = table.concat(EntityShowTable, "|")
			if table.Count(EntityShowTable) > 0 then
				RunConsoleCommand("AESPAllHappyDingetjes", newstring)
			else
				RunConsoleCommand("AESPAllHappyDingetjes", "")
			end
		end
	end
end
concommand.Add("AESPRemoveEntity", RemoveEntityToShow)

local function HeadPos(ent)
	if not IsValid(ent) then return Vector(0,0,0) end
	local head = ent:LookupAttachment("eyes")
	if not ent:GetAttachment(head) then
		return ent:GetShootPos()
	end
	return ent:GetAttachment(head).Pos
end	

local NoLookingAtWeapons = {"weapon_physgun", "weapon_physcannon", "gmod_camera", "keys", "pocket"}
local tick = 0
local function AESPThink()
	if ESPOn:GetInt() == 1 then
		for k,v in pairs(player.GetAll()) do 
			if v ~= LocalPlayer() and v:Alive() then
				local a = {}
				local teamcolor = team.GetColor(v:Team())
				local wep = v:GetActiveWeapon()
				a.data = {}
				if FShowName:GetInt() == 1 then
					table.insert(a.data, v:Nick())
				end
				 if FShowDesc:GetInt() == 1 then
					 table.insert(a.data, "Desc: " .. tostring(v:GetSharedVar( "physDesc" )))
				 end
				if FShowHealth:GetInt() == 1 then
					table.insert(a.data, "Health: " .. tostring(v:Health()))
				end
				if FShowRPMoney:GetInt() == 1 and v:GetNetworkedInt("money") ~= 0 then
					table.insert(a.data, "Money: " .. tostring(v:GetNetworkedInt("money")))
				end
				
				local speed = math.floor(v:GetVelocity():Length())
				if FShowSpeed:GetInt() == 1 and speed > 0 then
					table.insert(a.data, "Speed: " .. tostring(speed))
				end
				if FShowWeapon:GetInt() == 1 and wep:IsValid() then
					table.insert(a.data, wep:GetPrintName())
				end
				
				a.pos = HeadPos(v)
				if FShowDistance:GetInt() == 1 then
					table.insert(a.data, "Distance: " .. tostring(math.floor(a.pos:Distance(LocalPlayer():GetPos()))))
				end
				
				a.teamcolor = {}
				if v:IsAdmin() and not v:IsSuperAdmin() then
					if FShowAdmin:GetInt() == 1 then
						table.insert(a.data,"Admin")
					end
					if teamcolor.r == 255 and teamcolor.g == 255 and teamcolor.b == 100 then
						a.teamcolor.r = 30 
						a.teamcolor.g = 200
						a.teamcolor.b = 50
					else
						a.teamcolor.r = teamcolor.r 
						a.teamcolor.g = teamcolor.g
						a.teamcolor.b = teamcolor.b
					end
				elseif v:IsSuperAdmin() then
					if FShowAdmin:GetInt() == 1 then
						table.insert(a.data, "Super Admin")
					end
					if teamcolor.r == 255 and teamcolor.g == 255 and teamcolor.b == 100 then
						a.teamcolor.r = 30 
						a.teamcolor.g = 200
						a.teamcolor.b = 50
					else
						a.teamcolor.r = teamcolor.r 
						a.teamcolor.g = teamcolor.g
						a.teamcolor.b = teamcolor.b
					end
				elseif not v:IsAdmin() then
					if teamcolor.r == 255 and teamcolor.g == 255 and teamcolor.b == 100 then
						a.teamcolor.r = 100 
						a.teamcolor.g = 150
						a.teamcolor.b = 245
					else
						a.teamcolor.r = teamcolor.r 
						a.teamcolor.g = teamcolor.g
						a.teamcolor.b = teamcolor.b
					end
				end
				
				DrawLijst[v:EntIndex()] = a
			end
			

			if DingetjesLijst:GetString() ~= "" then
				for k,v in pairs(ents.GetAll()) do
					for a, b in pairs(EntityShowTable) do
						local a = {}
						if v:IsValid() and string.find(v:GetClass(), b)  then
							local pos = v:GetPos()
							a.data = {}
							if FShowName:GetInt() == 1 then
								table.insert(a.data, v:GetClass())
							end
							a.pos = pos
							a.teamcolor = Color(255,255,255,255)
							local owner = v:GetNWString("Owner")
							if FShowOwner:GetInt() == 1 and owner ~= "" then
								table.insert(a.data, owner)
							end
							local speed = math.floor(v:GetVelocity():Length())
							if FShowSpeed:GetInt() == 1 and speed > 0 then
								table.insert(a.data, "speed: " .. tostring(speed))
							end
							
							if FShowDistance:GetInt() == 1 then
								table.insert(a.data, "Distance: " .. tostring(math.floor(a.pos:Distance(LocalPlayer():GetPos()))))
							end
							DrawLijst[v:EntIndex()] = a
						end
					end 
				end
			end
			
			for k,v in pairs(CustomENTS) do
				if not IsValid(v) then CustomENTS[k] = nil return end
				local a = {}
				a.data = {}
				table.insert(a.data, v:GetClass())
				a.pos = v:GetPos()
				a.teamcolor = Color(255,0,0,255)
				local owner = v:GetNWString("Owner")
				if FShowOwner:GetInt() == 1 and owner ~= "" then
					table.insert(a.data, owner)
				end
				local speed = math.floor(v:GetVelocity():Length())
				if FShowSpeed:GetInt() == 1 and speed > 0 then
					table.insert(a.data, "speed: " .. tostring(speed))
				end
				if FShowDistance:GetInt() == 1 then
					table.insert(a.data, "Distance: " .. tostring(math.floor(a.pos:Distance(LocalPlayer():GetPos()))))
				end
				DrawLijst[v:EntIndex()] = a
			end
			tick = tick + 1
			if tick > 1000 then
				for k,v in pairs(DrawLijst) do
					DrawLijst = {}
				end
				tick = 0
			end
		end
	end
end
hook.Add("Think", "FespThink", AESPThink)

function AESPVgui()
	local frame = vgui.Create( "DFrame" )
	frame:SetTitle( "Atee Edition" )
	frame:SetSize( 280, 660 ) 
	frame:Center()
	frame:SetVisible( true )
	frame:MakePopup( )
	
	local Panel = vgui.Create( "DPanelList", frame )
	Panel:SetPos(20,30)
	Panel:SetSize(240, 610)
	Panel:SetSpacing(5)
	Panel:EnableHorizontal( false )
	Panel:EnableVerticalScrollbar( true )
	
	local ToggleEsp = vgui.Create( "DCheckBoxLabel", frame )
	ToggleEsp:SetText("Toggle AESP")
	ToggleEsp:SetConVar("AESPTOGGLE")
	Panel:AddItem(ToggleEsp)
	
	local ShowName = vgui.Create( "DCheckBoxLabel", frame )
	ShowName:SetText("Show names")
	ShowName:SetConVar("AESPShowName")
	Panel:AddItem(ShowName)
	
	local ToggleDesc = vgui.Create( "DCheckBoxLabel", frame )
	ToggleDesc:SetText("Show their description(Clockwork)")
	ToggleDesc:SetConVar("AESPShowDesc")
	Panel:AddItem(ToggleDesc)
	
	
	local ShowHealth = vgui.Create( "DCheckBoxLabel", frame )
	ShowHealth:SetText("Show health")
	ShowHealth:SetConVar("AESPShowHealth")
	Panel:AddItem(ShowHealth)
	
	local ShowAdmin = vgui.Create( "DCheckBoxLabel", frame )
	ShowAdmin:SetText("Show admin")
	ShowAdmin:SetConVar("AESPShowAdmin")
	Panel:AddItem(ShowAdmin)
	
	local ShowOwner = vgui.Create( "DCheckBoxLabel", frame )
	ShowOwner:SetText("Show owner")
	ShowOwner:SetConVar("AESPShowOwner")
	Panel:AddItem(ShowOwner)
	
	local ToggleRPMoney = vgui.Create( "DCheckBoxLabel", frame )
	ToggleRPMoney:SetText("Show their money(DarkRP)")
	ToggleRPMoney:SetConVar("AESPShowRPMoney")
	Panel:AddItem(ToggleRPMoney)
	
	
	local ToggleSpeed = vgui.Create( "DCheckBoxLabel", frame )
	ToggleSpeed:SetText("Show their speed")
	ToggleSpeed:SetConVar("AESPShowSpeed")
	Panel:AddItem(ToggleSpeed)
	
	local ToggleDistance = vgui.Create( "DCheckBoxLabel", frame )
	ToggleDistance:SetText("Show the Distance")
	ToggleDistance:SetConVar("AESPShowDistance")
	Panel:AddItem(ToggleDistance)

	local ToggleWeapon = vgui.Create( "DCheckBoxLabel", frame )
	ToggleWeapon:SetText("Show the Weapon")
	ToggleWeapon:SetConVar("AESPShowWeapon")
	Panel:AddItem(ToggleWeapon)
	
	local AllignMiddle = vgui.Create( "DCheckBoxLabel", frame )
	AllignMiddle:SetText("Allign in the middle")
	AllignMiddle:SetConVar("AESPMiddleAllign")
	Panel:AddItem(AllignMiddle)
	
	
	local mirrorbutton = vgui.Create( "DButton", frame)
	mirrorbutton:SetText( "Mirror" )
	mirrorbutton:SetSize(220, 20)
	function mirrorbutton:DoClick()
		frame:SetVisible(false)
		RunConsoleCommand("Atee_Mirror")
	end	
	Panel:AddItem(mirrorbutton)
	
	local dotsizeslider = vgui.Create( "DNumSlider", frame )
	dotsizeslider:SetValue(dotsize:GetInt())
	dotsizeslider:SetConVar("AESPDotSize")
	dotsizeslider:SetMin(0)
	dotsizeslider:SetMax(50)
	dotsizeslider:SetText("The size of the dots")
	dotsizeslider:SetDecimals(0)
	Panel:AddItem(dotsizeslider)
	
	local bordersizeslider = vgui.Create( "DNumSlider", frame )
	bordersizeslider:SetValue(bordersize:GetInt())
	bordersizeslider:SetConVar("AESPBorderSize")
	bordersizeslider:SetMin(0)
	bordersizeslider:SetMax(50)
	bordersizeslider:SetText("The size of the borders around the text")
	bordersizeslider:SetDecimals(0)
	Panel:AddItem(bordersizeslider)
	
	local EntList = vgui.Create("DListView", frame)
	EntList:SetSize(260, 70)
	EntList:AddColumn("AESP shows these entities:")
	EntList:SetMultiSelect(false)
	for k,v in pairs(EntityShowTable) do
		EntList:AddLine(v)
	end
	function EntList:OnClickLine(line)
		line:SetSelected(true)
		RunConsoleCommand("AESPRemoveEntity", line:GetValue(1))
		EntList:RemoveLine(EntList:GetSelectedLine())
	end
	
	local AddEntLabel = vgui.Create( "DLabel", frame )
	AddEntLabel:SetText("\nSelect custom entities\nto make AESP show\nuse the ClassName of the ent(advanced)")
	AddEntLabel:SizeToContents()
	Panel:AddItem(AddEntLabel)
	
	local AddEntTextEntry = vgui.Create("DTextEntry", frame)
	local notagain = notagain or 0
	function AddEntTextEntry:OnEnter()
		if notagain < RealTime() then	
			local text = AddEntTextEntry:GetValue()
			EntList:AddLine(text)
			RunConsoleCommand("AESPAddEntity", text)
			AddEntTextEntry:SetText("")
			AddEntTextEntry:RequestFocus( )
			notagain = RealTime() + 0.1
		end
	end
	Panel:AddItem(AddEntTextEntry)
	
	
	local AddEntLabel2 = vgui.Create( "DLabel", frame )
	AddEntLabel2:SetText("\nLook at something\nClick the next button\nAnd AESP will detect all of his kind")
	AddEntLabel2:SizeToContents()
	Panel:AddItem(AddEntLabel2)
	
	local AddLookingAtButton = vgui.Create("DButton", frame)
	AddLookingAtButton:SetText("Add Looking at")
	function AddLookingAtButton:DoClick( ) 
		local trace = LocalPlayer():GetEyeTrace()
		if trace.Hit and trace.Entity:IsValid() then
			RunConsoleCommand("AESPAddEntity", trace.Entity:GetClass())
			EntList:AddLine(trace.Entity:GetClass())
		end
	end
	Panel:AddItem(AddLookingAtButton)
	Panel:AddItem(EntList)
	
end
concommand.Add("atee_ESPConfig", AESPVgui)

local function fmirrorderma()
	local frame = vgui.Create( "DFrame" )
	frame:SetTitle( "AESP miror config" )
	frame:SetSize( 300, 300 ) 
	frame:Center()
	frame:SetVisible( true )
	frame:MakePopup( )
	
	local Panel = vgui.Create( "DPanelList", frame )
	Panel:SetPos(20,30)
	Panel:SetSize(260, 260)
	Panel:SetSpacing(5)
	Panel:EnableHorizontal( false )
	Panel:EnableVerticalScrollbar( true )
	
	local Mirror = vgui.Create( "DCheckBoxLabel", frame )
	Mirror:SetText("Enable mirror")
	Mirror:SetConVar("AESPMirror")
	Panel:AddItem(Mirror)
	
	local slidermirrorx = vgui.Create( "DNumSlider", frame )
	slidermirrorx:SetValue(FMirrorx:GetInt())
	slidermirrorx:SetConVar("AESPMirrorx")
	slidermirrorx:SetMin(0)
	slidermirrorx:SetMax(ScrW())
	slidermirrorx:SetText("Mirror X position")
	slidermirrorx:SetDecimals(0)
	Panel:AddItem(slidermirrorx)
	function slidermirrorx:Think()
		slidermirrorx:SetMax(ScrW() - FMirrorw:GetInt())
	end
	local slidermirrory = vgui.Create( "DNumSlider", frame )
	slidermirrory:SetValue(FMirrory:GetInt())
	slidermirrory:SetConVar("AESPMirrory")
	slidermirrory:SetMin(0)
	slidermirrory:SetMax(ScrH())
	slidermirrory:SetText("Mirror Y position")
	slidermirrory:SetDecimals(0)
	Panel:AddItem(slidermirrory)
	function slidermirrory:Think()
		slidermirrory:SetMax(ScrH() - FMirrorh:GetInt())
	end
	
	local slidermirrorw = vgui.Create( "DNumSlider", frame )
	slidermirrorw:SetValue(FMirrorw:GetInt())
	slidermirrorw:SetConVar("AESPMirrorw")
	slidermirrorw:SetMin(0)
	slidermirrorw:SetMax(ScrW())
	slidermirrorw:SetText("Mirror width")
	slidermirrorw:SetDecimals(0)
	Panel:AddItem(slidermirrorw)
	
	local slidermirrorh = vgui.Create( "DNumSlider", frame )
	slidermirrorh:SetValue(FMirrorh:GetInt())
	slidermirrorh:SetConVar("AESPMirrorh")
	slidermirrorh:SetMin(0)
	slidermirrorh:SetMax(ScrH())
	slidermirrorh:SetText("Mirror height")
	slidermirrorh:SetDecimals(0)
	Panel:AddItem(slidermirrorh)
end
concommand.Add("Atee_Mirror", fmirrorderma)

print("atee edition H2")

aimmodels = {
    ["models/combine_scanner.mdl"] = "Scanner.Body",
    ["models/hunter.mdl"] = "MiniStrider.body_joint",
    ["models/combine_turrets/floor_turret.mdl"] = "Barrel",
    ["models/domdl"] = "Dog_Model.Eye",
    ["models/antlion.mdl"] = "Antlion.Body_Bone",
    ["models/antlion_guard.mdl"] = "Antlion_Guard.Body",
    ["models/antlion_worker.mdl"] = "Antlion.Head_Bone",
    ["models/zombie/fast_torso.mdl"] = "ValveBiped.HC_BodyCube",
    ["models/zombie/fast.mdl"] = "ValveBiped.HC_BodyCube",
    ["models/headcrabclassic.mdl"] = "HeadcrabClassic.SpineControl",
    ["models/headcrabblack.mdl"] = "HCBlack.body",
    ["models/headcrab.mdl"] = "HCFast.body",
    ["models/zombie/poison.mdl"] = "ValveBiped.Headcrab_Cube1",
    ["models/zombie/classic.mdl"] = "ValveBiped.HC_Body_Bone",
    ["models/zombie/classic_torso.mdl"] = "ValveBiped.HC_Body_Bone",
    ["models/zombie/zombie_soldier.mdl"] = "ValveBiped.HC_Body_Bone",
    ["models/combine_strider.mdl"] = "Combine_Strider.Body_Bone",
    ["models/lamarr.mdl"] = "HeadcrabClassic.SpineControl"
};

nicebones = {
    {"Head", "ValveBiped.Bip01_Head1"},
    {"Neck", "ValveBiped.Bip01_Neck1"},
    {"Spine", "ValveBiped.Bip01_Spine"},
    {"Spine1", "ValveBiped.Bip01_Spine1"},
    {"Spine2", "ValveBiped.Bip01_Spine2"},
    {"Spine4", "ValveBiped.Bip01_Spine4"},
    {"R Upperarm", "ValveBiped.Bip01_R_UpperArm"},
    {"R Forearm", "ValveBiped.Bip01_R_Forearm"},
    {"R Hand", "ValveBiped.Bip01_R_Hand"},
    {"L Upperarm", "ValveBiped.Bip01_L_UpperArm"},
    {"L Forearm", "ValveBiped.Bip01_L_Forearm"},
    {"L Hand", "ValveBiped.Bip01_L_Hand"},
    {"R Thigh", "ValveBiped.Bip01_R_Thigh"},
    {"R Calf", "ValveBiped.Bip01_R_Calf"},
    {"R Foot", "ValveBiped.Bip01_R_Foot"},
    {"R Toes", "ValveBiped.Bip01_R_Toe0"},
    {"L Thigh", "ValveBiped.Bip01_L_Thigh"},
    {"L Calf", "ValveBiped.Bip01_L_Calf"},
    {"L Foot", "ValveBiped.Bip01_L_Foot"},
    {"L Toes", "ValveBiped.Bip01_L_Toe0"}
};

local CustomCones = {
    ["#HL2_SMG1"] = Vector(-0.04362, -0.04362, -0.04362),
    ["#HL2_Pistol"] = Vector(-0.0100, -0.0100, -0.0100),
    ["#HL2_Pulse_Rifle"] = Vector(-0.02618, -0.02618, -0.02618),
    ["#HL2_Shotgun"] = Vector( -0.08716, -0.08716, -0.08716 ),
};

local me = LocalPlayer()

function PredictSpread(cmd, aimAngle)
    cmd2, seed = hl2_ucmd_getprediction(cmd)
    currentseed = 0, 0, 0;
    if(cmd2 ~= 0) then currentseed = seed; end
    wep = me:GetActiveWeapon();
    vecCone, valCone = Vector(0, 0, 0);
    if(IsValid(wep)) then
        if(wep.Base) then
            valCone = wep.Primary and wep.Primary.Cone or 0;
            if(tonumber(valCone)) then
                vecCone = Vector(-valCone, -valCone, -valCone);
            elseif(type(valCone) == "Vector") then
                vecCone = -1 * valCone;
            end
        else
            local pn = wep:GetPrintName();
            if(CustomCones[pn]) then vecCone = CustomCones[pn]; end
        end
    end
    return hl2_shotmanip(currentseed or 0, (aimAngle or me:GetAimVector():Angle()):Forward(), vecCone):Angle();
end

local ARTime;
function Autoreload(uc)
    if(me:Alive() and IsValid(me:GetActiveWeapon())) then
        if(me:GetActiveWeapon():Clip1() <= 0) then
            if(not ARTime or ARTime < CurTime()) then
                RunConsoleCommand("+reload");
                ARTime = CurTime() + 5;
                timer.Simple(.2, function()
                    RunConsoleCommand("-reload");
                end);
            end
        end
    end
end

function GetShootPos(ent)
    local bname = aimmodels[ent:GetModel()];
    if(not bname) then
        bname = "ValveBiped.Bip01_Head1";
    end
    
    local bone = ent:LookupBone(bname);
    if(bone) then
        local pos, ang = ent:GetBonePosition(bone);
        return pos, ang;
    end
    
    return ent:LocalToWorld(ent:OBBCenter());
end

function HasLOS(ent)
    local trace = {start = me:GetShootPos(), endpos = GetShootPos(ent), filter = {me, ent}, mask = 1174421507};
    local tr = util.TraceLine(trace);
    return(tr.Fraction == 1);
end

function CanShoot(ent)
    if(not IsValid(ent)) then return false; end
    if(me == ent) then return false; end

    if(ent:GetMoveType() == 0) then return false; end
    if(ent:IsPlayer() and not ent:Alive()) then return false; end
    if(ent:IsPlayer() and (ent:Team() == TEAM_SPECTATOR or ent:Team() == 1002)) then return false; end
    
    if(ent:IsPlayer() and ent:Health() <= 0) then return false; end
    if(ent:IsPlayer() and ent:Team() == me:Team() and GetConVar("ah_targetteam"):GetBool() == false) then return false; end
    
    local fov = 180
    if(fov ~= 180) then
        local lpang = me:GetAngles();
        local ang = (ent:GetPos() - me:GetPos()):Angle();
        local ady = math.abs(math.NormalizeAngle(lpany - any))
        local adp = math.abs(math.NormalizeAngle(lpanp - anp ))
        if(ady > fov or adp > fov) then return false; end
    end
    
    return true;
end

function GetAimTarg()
    if(CanShoot(vars.aimtarg) and HasLOS(vars.aimtarg)) then 
        return vars.aimtarg; 
    else 
        vars.aimtarg = nil;
    end
    
    local position = LocalPlayer():EyePos();
    local angle = LocalPlayer():GetAimVector();
    local tar = {0, 0};
    local tab = player.GetAll();
    
    for k, v in ipairs(tab) do
        if(CanShoot(v) and HasLOS(v)) then
            local plypos = v:EyePos();
            MsgN(plypos)
            MsgN(position)
            MsgN(plypos - position)
            vectorTest = plypos - position
            normalized = vectorTest:Normalize()

            local difr = plypos - position;
            difr:Normalize()
            difr = difr - angle;
            difr = difr:Length();
            difr = math.abs(difr);
            if(difr < tar[2] or tar[1] == 0) then
                tar = {v, difr};
            end	
        end
    end
    return tar[1];
end

function Triggerbot(uc)
    if(not me:Alive()) then return; end
    local ent = me:GetEyeTrace().Entity;
    
    if((vars.tlock and vars.aim and IsValid(vars.aimtarg) and HasLOS(vars.aimtarg)) or 
    (IsValid(ent) and (ent:IsPlayer() or 
    ent:IsNPC()) and CanShoot(ent))) then
        if(vars.firing) then return; end
        RunConsoleCommand("+attack");
        SetVar("firing",true);
        timer.Simple(me:GetActiveWeapon().Primary and me:GetActiveWeapon().Primary.Delay or 0.05, function()
            RunConsoleCommand("-attack");
            SetVar("firing",false);
        end);
    end
end

concommand.Add("+ah_triggerbot", function()
    RunConsoleCommand("_ah_triggerbot", "1");
end)
concommand.Add("-ah_triggerbot", function()
    RunConsoleCommand("_ah_triggerbot", "0");
end)

concommand.Add("sh_addlookingent", function()
    local ent = me:GetEyeTrace().Entity;
    if(not IsValid(ent)) then return; end
    local v = ent:GetClass();
    
    custe[v] = true;
    local t = data.GetOptionTab("ESPEnts") or {};
    t[v] = true;
    data.SetOptionTab("ESPEnts", t);
    
    me:ChatPrint("Added " .. v);
end)

function Antisnap(ang)
    anp = math.NormalizeAngle(anp);
    any = math.NormalizeAngle(any);
    lpang = me:EyeAngles();
    local as = GetCVNum("sh_antisnapspeed");
    lpanp = math.Approach(lpanp, anp, as)
    lpany = math.Approach(lpany, any, as)
    lpanr = 0;
    ang = lpang;
    return ang;
end

function Aimbot(uc)
    if(not vars.aim) then return; end
    if(uc:GetButtons() == KEY_NONE) then return; end
    
    local ply = GetAimTarg();
    if(ply == 0) then vars.tlock = false; SetVar("aimang", nil); return; end
    SetVar("aimtarg",ply);
    
    local pos, ang = GetShootPos(ply);
    pos = pos + ply:GetVelocity()/50 - me:GetVelocity()/50 - Vector(0,0,0);

    ang = (pos-me:GetShootPos()):Angle();
    
    SetVar("aimang", ang);

    SetVar("tlock",true);
    
    uc:SetViewAngles(ang);
end

local g_ents = {}
local g_players = {}

vars = {
    aim = false,
    aimtarg = nil,
    tlock = false,
    chatting = false,
    LastCommand = "",
};

function SetVar(var, val)
    vars[var] = val;
end

concommand.Add("+ah_aim", function() SetVar("aim", true); end);
concommand.Add("-ah_aim", function()
    SetVar("aim", false);
    SetVar("aimtarg",nil);
    SetVar("aimang", nil);
end)

CreateClientConVar("ah_autoshoot", "0", true, false)
CreateClientConVar("ah_autoreload", "1", true, false)
CreateClientConVar("ah_targetteam", "1", true, false)

hook.Add("CreateMove", "CreateMoveClientLol123bbq", function(uc)
    local autoreload = GetConVar("ah_autoreload"):GetBool();
    local triggerbot = GetConVar("ah_autoshoot"):GetBool();

    Aimbot(uc);
    if (autoreload) then
        Autoreload(uc);
    end
    if (triggerbot) then
        Triggerbot(uc);
    end
end);

hook.Add("Tick", "HOLYFUCKINGTICK", function()
    g_ents = ents.GetAll();
    g_players = player.GetAll();
end)

print("atee edition H3");

local AHNC = {}
 
AHNC.Enabled = false
AHNC.ViewOrigin = Vector( 0, 0, 0 )
AHNC.ViewAngle = Angle( 0, 0, 0 )
AHNC.Velocity = Vector( 0, 0, 0 )
 
function AHNC.CalcView( ply, origin, angles, fov )
        if ( !AHNC.Enabled ) then return end
        if ( AHNC.SetView ) then
                AHNC.ViewOrigin = origin
                AHNC.ViewAngle = angles
               
                AHNC.SetView = false
        end
        return { origin = AHNC.ViewOrigin, angles = AHNC.ViewAngle }
end
hook.Add( "CalcView", "AteeNC", AHNC.CalcView )
 
function AHNC.CreateMove( cmd )
        if ( !AHNC.Enabled ) then return end
       
        local time = FrameTime()
        AHNC.ViewOrigin = AHNC.ViewOrigin + ( AHNC.Velocity * time )
        AHNC.Velocity = AHNC.Velocity * 0.95
       
        local sensitivity = 0.022
        AHNC.ViewAngle.p = math.Clamp( AHNC.ViewAngle.p + ( cmd:GetMouseY() * sensitivity ), -89, 89 )
        AHNC.ViewAngle.y = AHNC.ViewAngle.y + ( cmd:GetMouseX() * -1 * sensitivity )
       
        local add = Vector( 0, 0, 0 )
        local ang = AHNC.ViewAngle
        if ( cmd:KeyDown( IN_FORWARD ) ) then add = add + ang:Forward() end
        if ( cmd:KeyDown( IN_BACK ) ) then add = add - ang:Forward() end
        if ( cmd:KeyDown( IN_MOVERIGHT ) ) then add = add + ang:Right() end
        if ( cmd:KeyDown( IN_MOVELEFT ) ) then add = add - ang:Right() end
        if ( cmd:KeyDown( IN_JUMP ) ) then add = add + ang:Up() end
        if ( cmd:KeyDown( IN_DUCK ) ) then add = add - ang:Up() end
       
        add = add:GetNormal() * time * 500
        if ( cmd:KeyDown( IN_SPEED ) ) then add = add * 2 end
       
        AHNC.Velocity = AHNC.Velocity + add
       
        if ( AHNC.LockView == true ) then
                AHNC.LockView = cmd:GetViewAngles()
        end
        if ( AHNC.LockView ) then
                cmd:SetViewAngles( AHNC.LockView )
        end
       
        cmd:SetForwardMove( 0 )
        cmd:SetSideMove( 0 )
        cmd:SetUpMove( 0 )
end
hook.Add( "CreateMove", "AteeNC", AHNC.CreateMove )
 
function AHNC.Toggle()
        AHNC.Enabled = !AHNC.Enabled
        AHNC.LockView = AHNC.Enabled
        AHNC.SetView = true
       
        local status = { [ true ] = "ON", [ false ] = "OFF" }
        print( "AteeNC " .. status[ AHNC.Enabled ] )
end
concommand.Add( "ahnc_toggle", AHNC.Toggle )
 
concommand.Add( "ahnc_pos", function() print( AHNC.ViewOrigin ) end )

print("atee H4")
