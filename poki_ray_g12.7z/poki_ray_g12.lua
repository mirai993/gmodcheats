--[[
	autorun/client/PoKiRay.lua
	Master | (STEAM_0:1:22519569)
	===DStream===
]]

local RayOn = false
local AllMats = {}
local allcolors = {}
local FSetColor = _R.Entity.SetColor
local FSetMat = _R.Entity.SetMaterial
local FGetMat = _R.Entity.GetMaterial
local function TogglePoKiRay()
	if not LocalPlayer():Alive() then return end
	if RayOn then
		surface.PlaySound("buttons/button19.wav") 
		for k,v in pairs(ents.GetAll()) do
			v:SetMaterial(AllMats[v])
			v:SetColor(255,255,255,255)
		end
	else
		surface.PlaySound("buttons/button1.wav") 
	end
	RayOn = not RayOn
end
concommand.Add("PoKiRay", TogglePoKiRay)

function DoPoKiRay()
	if not RayOn then return end
	for k,v in pairs(ents.GetAll()) do
		if ValidEntity(v) then
			local r,g,b,a = v:GetColor()
			local class = string.lower(v:GetClass())
			if v:IsPlayer() and (r ~= 255 or g ~= 0 or b ~= 0 or a ~= 255) then
				allcolors[v] = Color(r,g,b,a)
				FSetColor(v,255,0,0,255)
			elseif v:IsNPC() and (r ~= 0 or g ~= 255 or b ~= 0 or a ~= 255) then
				allcolors[v] = Color(r,g,b,a)
				FSetColor(v, 0, 255, 0, 255)
			elseif (class == "prop_physics" or class == "prop") and (r ~= 0 or g ~= 0 or b ~= 255 or a > 40) then
				allcolors[v] = Color(r,g,b,a)
				FSetColor(v, 0, 0, 255, math.Clamp(a, 0, 40))
			elseif v:IsWeapon() and (r ~= 140 or g ~= 0 or b ~= 255 or a ~= 255) then
				allcolors[v] = Color(r,g,b,a)
				FSetColor(v, 140, 0, 255, 255)
			elseif v:GetClass() == "viewmodel" and (r ~= 0 or g ~= 0 or b ~= 0 or a ~= 30)  then
				allcolors[v] = Color(r,g,b,a)
				FSetColor(v, 0, 0, 0, 30)
			elseif v:GetClass() == "env_spritetrail" and (r ~= 255 or g ~= 255 or b ~= 255 or a ~= 255) then
				allcolors[v] = Color(r,g,b,a)
				FSetColor(v, 255, 255, 255, 255)
			elseif not v:IsPlayer() and not v:IsNPC() and v:GetClass() ~= "prop_physics" and v:GetClass() ~= "prop" and v:GetClass() ~= "env_spritetrail" and not v:IsWeapon() and v:GetClass() ~= "viewmodel" and ( r ~= 255 or g ~= 200 or b ~= 0 or a ~= 100) then
				allcolors[v] = Color(r,g,b,a)
				FSetColor(v, 255, 200, 0, 100)
			end
			if v:GetClass() ~= "viewmodel" and FGetMat(v) ~= "PoKiRayMat" and class ~= "func_door" and class ~= "func_door_rotating" and class ~= "prop_door_rotating" then
				AllMats[v] = FGetMat(v)
				FSetMat(v, "PoKiRayMat")
			end
		end
	end
end
hook.Add( "RenderScene", "PoKiRay", DoPoKiRay)