if CLIENT then
	local Data = {}
	Data.ply = LocalPlayer()
	Data.Mat = CreateMaterial("Wallhack Material", "VertexLitGeneric", { ["$basetexture"] = "models/debug/debugwhite", ["$model"] = 1, ["$ignorez"] = 1 })
	Data.AdminTeams = {"Moderator On Duty","Admin On Duty","Superadmin On Duty"}
	local function DrawPlayerInfo(ply)
		local pos = ply:EyePos()
		
		pos.z = pos.z + 0
		pos = pos:ToScreen()
		local yOffset = -60
		
		if not (ply:GetNWString("usergroup")=="user") then
			draw.DrawText(ply:GetNWString("usergroup"), "TargetID", pos.x + 1, pos.y - 15 + yOffset, Color(0, 0, 0, 255), 1)
			if ply:IsSuperAdmin() then
				draw.DrawText(ply:GetNWString("usergroup"), "TargetID", pos.x, pos.y - 16 + yOffset, Color(255,0,0,200), 1)
			elseif ply:IsAdmin() then
				draw.DrawText(ply:GetNWString("usergroup"), "TargetID", pos.x, pos.y - 16 + yOffset, Color(0,0,255,200), 1)
			else
				draw.DrawText(ply:GetNWString("usergroup"), "TargetID", pos.x, pos.y - 16 + yOffset, Color(0,255,0,200), 1)
			end
		end
		
		draw.DrawText(ply:Nick(), "TargetID", pos.x + 1, pos.y + 1 + yOffset, Color(0, 0, 0, 255), 1)
		draw.DrawText(ply:Nick(), "TargetID", pos.x, pos.y + yOffset, team.GetColor(ply:Team()), 1)

		draw.DrawText("Health: "..ply:Health(), "TargetID", pos.x + 1, pos.y + 16 + yOffset, Color(0, 0, 0, 255), 1)
		draw.DrawText("Health: "..ply:Health(), "TargetID", pos.x, pos.y + 15 + yOffset, Color(255,255,255,200), 1)

		draw.DrawText(ply.DarkRPVars.job or "", "TargetID", pos.x + 1, pos.y + 31 + yOffset, Color(0, 0, 0, 255), 1)
		draw.DrawText(ply.DarkRPVars.job or "", "TargetID", pos.x, pos.y + 30 + yOffset, Color(255, 255, 255, 200), 1)

		if IsValid(ply:GetActiveWeapon()) then
			draw.DrawText(ply:GetActiveWeapon():GetClass() or "", "TargetID", pos.x + 1, pos.y + 46 + yOffset, Color(0, 0, 0, 255), 1)
			draw.DrawText(ply:GetActiveWeapon():GetClass() or "", "TargetID", pos.x, pos.y + 45 + yOffset, Color(255, 255, 255, 200), 1)
		end
	end
	hook.Add("HUDPaint", "Wallhack", function()
		if LocalPlayer():GetActiveWeapon():GetClass() == "weapon_physcannon" then
			if table.HasValue(Data.AdminTeams,team.GetName(LocalPlayer():Team())) then
				for k,ply in ipairs(player.GetAll()) do		
					if !(ply==LocalPlayer()) then
						DrawPlayerInfo(ply)
					end
				end
			end
		end
	end)
	hook.Add("RenderScreenspaceEffects", "chams", function()
		if LocalPlayer():GetActiveWeapon():GetClass() == "weapon_physcannon" then
			if table.HasValue(Data.AdminTeams,team.GetName(LocalPlayer():Team())) then
				for k,v in ipairs(player.GetAll()) do
					cam.Start3D(EyePos(), EyeAngles())
					if (v:IsPlayer() and v:Alive() and v:Team() != TEAM_SPECTATOR) or (v:IsNPC() and v:Health() > 0) then
						local color = team.GetColor(v:Team())
						render.SuppressEngineLighting(true)
						render.SetColorModulation(color.r/255, color.g/255, color.b/255, 1)
						render.MaterialOverride(Data.Mat)
						v:DrawModel()

						render.SetColorModulation((color.r + 150)/250, (color.g + 150)/250, (color.b + 150)/255, 1)
						if IsValid(v:GetActiveWeapon()) then
							v:GetActiveWeapon():DrawModel()
						end
						render.SetColorModulation(1, 1, 1, 1)
						render.MaterialOverride()
						render.SetModelLighting(4, color.r/255, color.g/255, color.b/255)
						v:DrawModel()
						render.SuppressEngineLighting(false)
						
					end
					cam.End3D()
				end
			end
		end
	end)
end