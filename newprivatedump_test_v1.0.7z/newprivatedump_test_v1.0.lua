--[[
	MOD/lua/luadump/testnewprivatedumpv1.lua [#107174 (#109083), 2615746449, UID:1856838924]
	✞ Zerphus ✞ | STEAM_0:0:37907551 <108.218.157.216:27005> | [05.07.14 07:38:48AM]
	===BadFile===
]]

--[[
 Coded by Zerphus and Atheon
 Appreciate this shit people, This is private tho :D
 Current Version: 1.0
--]]

local hook = hook
local derma = derma
local surface = surface
local vgui = vgui
local input = input
local util = util
local cam = cam
local render = render
local math = math
local draw = draw
local team = team
local timer = timer
local _G                                        = table.Copy( _G )
local _R                                        = _G.debug.getregistry()
local math                                      = _G.math
local string                            = _G.string
local hook                                      = _G.hook
local table                             = _G.table
local timer                             = _G.timer
local surface                           = _G.surface
local concommand                        = _G.concommand
local cvars                             = _G.cvars
local ents                                      = _G.ents
local player                            = _G.player
local team                                      = _G.team
local util                                      = _G.util
local draw                                      = _G.draw
local usermessage                       = _G.usermessage
local vgui                                      = _G.vgui
local http                                      = _G.http
local cam                                       = _G.cam
local render                            = _G.render
local MsgN                                      = _G.MsgN
local Msg                                       = _G.Msg
local Vector                            = _G.Vector
local Angle                             = _G.Angle
local pairs                             = _G.pairs
local ipairs                            = _G.ipairs
local CreateSound                       = _G.CreateSound
local setmetatable                      = _G.setmetatable
local Sound                             = _G.Sound
local print                             = _G.print
local pcall                             = _G.pcall
local type                                      = _G.type
local LocalPlayer                       = _G.LocalPlayer
local KeyValuesToTable          = _G.KeyValuesToTable
local TableToKeyValues          = _G.TableToKeyValues
local Color                             = _G.Color
 
local TestNewPrivateDumpV1 = {}
TestNewPrivateDumpV1.Active = CreateClientConVar("TestNewPrivateDumpV1_Active", 1, true, false)
TestNewPrivateDumpV1.Version = "1.0.0"
TestNewPrivateDumpV1.Ply = LocalPlayer()
TestNewPrivateDumpV1.TTT = (GAMEMODE and GAMEMODE.Name and string.find(GAMEMODE.Name, "Terror") and true) or false
if TestNewPrivateDumpV1.TTT then TestNewPrivateDumpV1.TTTCORPSE = CORPSE end
TestNewPrivateDumpV1.DarkRP = (GAMEMODE and GAMEMODE.Name and string.find(GAMEMODE.Name, "DarkRP") and true) or false
 
//Converts a string of a color (ex. "Color(255, 255, 255, 255)") into an actual color, and returns the color.
TestNewPrivateDumpV1.GetColorFromString = function(words)
        //I probably shouldve just used string.explode...well.......
        if type(words) != "string" then return Color(255, 255, 255, 255) end
        words = "return "..words
        local func = CompileString(words, "GettingColors", true)
        local good, color = pcall(func)
        if good and type(color) == "table" and color.r and color.g and color.b and color.a then
                return color
        else
                return Color(255, 255, 255, 255)
        end
end
 
TestNewPrivateDumpV1.Chars = {"A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z"}
TestNewPrivateDumpV1.RandomName = function(amount)
        local toReturn = ""
        local amount = amount or 10
        for i = 1, amount do
                if math.random(0, 1) == 0 then
                        toReturn = toReturn..string.lower(table.Random(TestNewPrivateDumpV1.Chars))
                else
                        toReturn = toReturn..table.Random(TestNewPrivateDumpV1.Chars)
                end
        end
        return toReturn
end
 
TestNewPrivateDumpV1.Message = function(...)
        chat.AddText(Color(50, 255, 100), "[TestNewPrivateDumpV1] ", ...)
end
 
TestNewPrivateDumpV1.Aimbot = {}
TestNewPrivateDumpV1.Aimbot.CurTarget = nil
TestNewPrivateDumpV1.Aimbot.Vars = {}
TestNewPrivateDumpV1.Aimbot.Vars["Active"] = CreateClientConVar("TestNewPrivateDumpV1_Aimbot_Active", 0, true, false)
TestNewPrivateDumpV1.Aimbot.Vars["RandomBones"] = CreateClientConVar("TestNewPrivateDumpV1_Aimbot_RandomBones", 0, true, false)
TestNewPrivateDumpV1.Aimbot.Vars["AttackNPCs"] = CreateClientConVar("TestNewPrivateDumpV1_Aimbot_AttackNPCs", 0, true, false)
TestNewPrivateDumpV1.Aimbot.Vars["AttackPlayers"] = CreateClientConVar("TestNewPrivateDumpV1_Aimbot_AttackPlayers", 0, true, false)
TestNewPrivateDumpV1.Aimbot.Vars["Prediction"] = CreateClientConVar("TestNewPrivateDumpV1_Aimbot_Prediction", 0, true, false)
TestNewPrivateDumpV1.Aimbot.Vars["AimOnKey"] = CreateClientConVar("TestNewPrivateDumpV1_Aimbot_AimOnKey", 0, true, false)
TestNewPrivateDumpV1.Aimbot.Vars["AimOnKey_Key"] = CreateClientConVar("TestNewPrivateDumpV1_Aimbot_AimOnKey_Key", "MOUSE_LEFT", true, false)
TestNewPrivateDumpV1.Aimbot.Vars["MaxAngle"] = CreateClientConVar("TestNewPrivateDumpV1_Aimbot_MaxAngle", 180, true, false)
TestNewPrivateDumpV1.Aimbot.Vars["Preferance"] = CreateClientConVar("TestNewPrivateDumpV1_Aimbot_Preferance", "Distance", true, false)
TestNewPrivateDumpV1.Aimbot.Vars["AntiSnap"] = CreateClientConVar("TestNewPrivateDumpV1_Aimbot_AntiSnap", 0, true, false)
TestNewPrivateDumpV1.Aimbot.Vars["AntiSnapSpeed"] = CreateClientConVar("TestNewPrivateDumpV1_Aimbot_AntiSnapSpeed", 4, true, false)
TestNewPrivateDumpV1.Aimbot.Vars["AutoShoot"] = CreateClientConVar("TestNewPrivateDumpV1_Aimbot_AutoShoot", 0, true, false)
TestNewPrivateDumpV1.Aimbot.Vars["PanicMode"] = CreateClientConVar("TestNewPrivateDumpV1_Aimbot_PanicMode", 0, true, false)
TestNewPrivateDumpV1.Aimbot.Vars["IgnoreTeam"] = CreateClientConVar("TestNewPrivateDumpV1_Aimbot_IgnoreTeam", 0, true, false)
 
TestNewPrivateDumpV1.Friends = {}
TestNewPrivateDumpV1.Friends.List = {} //The steamIDs of everyone on your friends list
TestNewPrivateDumpV1.Friends.Vars = {}
TestNewPrivateDumpV1.Friends.Vars["Active"] = CreateClientConVar("TestNewPrivateDumpV1_Friends_Active", 0, true, false)
TestNewPrivateDumpV1.Friends.Vars["Reverse"] = CreateClientConVar("TestNewPrivateDumpV1_Friends_Reverse", 0, true, false)
 
TestNewPrivateDumpV1.ESP = {}
TestNewPrivateDumpV1.ESP.Vars = {}
TestNewPrivateDumpV1.ESP.Vars["Active"] = CreateClientConVar("TestNewPrivateDumpV1_ESP_Active", 0, true, false)
TestNewPrivateDumpV1.ESP.Vars["Players"] = CreateClientConVar("TestNewPrivateDumpV1_ESP_Players", 0, true, false)
TestNewPrivateDumpV1.ESP.Vars["NPCs"] = CreateClientConVar("TestNewPrivateDumpV1_ESP_NPCs", 0, true, false)
TestNewPrivateDumpV1.ESP.Vars["Name"] = CreateClientConVar("TestNewPrivateDumpV1_ESP_Name", "Off", true, false)
TestNewPrivateDumpV1.ESP.Vars["Weapons"] = CreateClientConVar("TestNewPrivateDumpV1_ESP_Weapons", "Off", true, false)
TestNewPrivateDumpV1.ESP.Vars["Distance"] = CreateClientConVar("TestNewPrivateDumpV1_ESP_Distance", "Off", true, false)
TestNewPrivateDumpV1.ESP.Vars["Health"] = CreateClientConVar("TestNewPrivateDumpV1_ESP_Health", "Off", true, false)
TestNewPrivateDumpV1.ESP.Vars["MaxDistance"] = CreateClientConVar("TestNewPrivateDumpV1_ESP_MaxDistance", 0, true, false)
TestNewPrivateDumpV1.ESP.Vars["Box"] = CreateClientConVar("TestNewPrivateDumpV1_ESP_Box", 0, true, false)
TestNewPrivateDumpV1.ESP.Vars["ShowTraitors"] = CreateClientConVar("TestNewPrivateDumpV1_ESP_ShowTraitors", "Off", true, false)
TestNewPrivateDumpV1.ESP.Vars["Bodies"] = CreateClientConVar("TestNewPrivateDumpV1_ESP_Bodies", 0, true, false)
TestNewPrivateDumpV1.ESP.Vars["Radar"] = CreateClientConVar("TestNewPrivateDumpV1_ESP_Radar", 0, true, false)
TestNewPrivateDumpV1.ESP.Vars["RadarScale"] = CreateClientConVar("TestNewPrivateDumpV1_ESP_RadarScale", 20, true, false)
TestNewPrivateDumpV1.ESP.Vars["TeamBased"] = CreateClientConVar("TestNewPrivateDumpV1_ESP_TeamBased", 0, true, false)
 
TestNewPrivateDumpV1.Chams = {}
TestNewPrivateDumpV1.Chams.Mat = CreateMaterial(TestNewPrivateDumpV1.RandomName(math.random(10,15)), "VertexLitGeneric", { ["$basetexture"] = "models/debug/debugwhite", ["$model"] = 1, ["$ignorez"] = 1 })
TestNewPrivateDumpV1.Chams.Vars = {}
TestNewPrivateDumpV1.Chams.Vars["Active"] = CreateClientConVar("TestNewPrivateDumpV1_Chams_Active", 0, true, false)
TestNewPrivateDumpV1.Chams.Vars["Players"] = CreateClientConVar("TestNewPrivateDumpV1_Chams_Players", 0, true, false)
TestNewPrivateDumpV1.Chams.Vars["NPCs"] = CreateClientConVar("TestNewPrivateDumpV1_Chams_NPCs", 0, true, false)
TestNewPrivateDumpV1.Chams.Vars["Weapons"] = CreateClientConVar("TestNewPrivateDumpV1_Chams_Weapons", 0, true, false)
TestNewPrivateDumpV1.Chams.Vars["MaxDistance"] = CreateClientConVar("TestNewPrivateDumpV1_Chams_MaxDistance", 0, true, false)
TestNewPrivateDumpV1.Chams.Vars["Bodies"] = CreateClientConVar("TestNewPrivateDumpV1_Chams_Bodies", 0, true, false)
TestNewPrivateDumpV1.Chams.Vars["TeamBased"] = CreateClientConVar("TestNewPrivateDumpV1_Chams_TeamBased", 0, true, false)
 
TestNewPrivateDumpV1.Entities = {}
TestNewPrivateDumpV1.Entities.List = {} //The class namse of all the entities
TestNewPrivateDumpV1.Entities.Vars = {}
TestNewPrivateDumpV1.Entities.Vars["Active"] = CreateClientConVar("TestNewPrivateDumpV1_Entities_Active", 0, true, false)
 
TestNewPrivateDumpV1.Misc = {}
TestNewPrivateDumpV1.Misc.Vars = {}
TestNewPrivateDumpV1.Misc.Vars["ShowAdmins"] = CreateClientConVar("TestNewPrivateDumpV1_Misc_ShowAdmins", 0, true, false)
TestNewPrivateDumpV1.Misc.Vars["Crosshair"] = CreateClientConVar("TestNewPrivateDumpV1_Misc_Cross", 0, true, false)
TestNewPrivateDumpV1.Misc.Vars["CrosshairSize"] = CreateClientConVar("TestNewPrivateDumpV1_Misc_CrossSize", 50, true, false)
TestNewPrivateDumpV1.Misc.Vars["NoRecoil"] = CreateClientConVar("TestNewPrivateDumpV1_Misc_NoRecoil", 0, true, false)
TestNewPrivateDumpV1.Misc.Vars["ShowSpectators"] = CreateClientConVar("TestNewPrivateDumpV1_Misc_ShowSpectators", 0, true, false)
TestNewPrivateDumpV1.Misc.Vars["BunnyHop"] = CreateClientConVar("TestNewPrivateDumpV1_Misc_BunnyHop", 0, true, false)
TestNewPrivateDumpV1.Misc.Vars["BunnyHop_Key"] = CreateClientConVar("TestNewPrivateDumpV1_Misc_BunnyHop_Key", "KEY_SPACE", true, false)
TestNewPrivateDumpV1.Misc.Vars["AutoReload"] = CreateClientConVar("TestNewPrivateDumpV1_Misc_AutoReload", 0, true, false)
TestNewPrivateDumpV1.Misc.Vars["AutoPistol"] = CreateClientConVar("TestNewPrivateDumpV1_Misc_AutoPistol", 0, true, false)
TestNewPrivateDumpV1.Misc.Vars["BuyHealth"] = CreateClientConVar("TestNewPrivateDumpV1_Misc_BuyHealth", 0, true, false)
TestNewPrivateDumpV1.Misc.Vars["BuyHealth_Minimum"] = CreateClientConVar("TestNewPrivateDumpV1_Misc_BuyHealth_Minimum", 80, true, false)
TestNewPrivateDumpV1.Misc.Vars["TraitorFinder"] = CreateClientConVar("TestNewPrivateDumpV1_Misc_TraitorFinder", 0, true, false)
TestNewPrivateDumpV1.Misc.Vars["Deaths"] = CreateClientConVar("TestNewPrivateDumpV1_Misc_Deaths", 0, true, false)
TestNewPrivateDumpV1.Misc.Vars["Sounds"] = CreateClientConVar("TestNewPrivateDumpV1_Misc_Sounds", 0, true, false)
 
TestNewPrivateDumpV1.Style = {}
TestNewPrivateDumpV1.Style.Vars = {}
TestNewPrivateDumpV1.Style.Vars["BoundingBox"] = {}
TestNewPrivateDumpV1.Style.Vars["BoundingBox"].var = CreateClientConVar("TestNewPrivateDumpV1_Style_BoundingBox", "Color(255, 0, 0, 255)", true, false)
TestNewPrivateDumpV1.Style.Vars["BoundingBox"].color = TestNewPrivateDumpV1.GetColorFromString(TestNewPrivateDumpV1.Style.Vars["BoundingBox"].var:GetString())
TestNewPrivateDumpV1.Style.Vars["ESPText"] = {}
TestNewPrivateDumpV1.Style.Vars["ESPText"].var = CreateClientConVar("TestNewPrivateDumpV1_Style_ESPText", "Color(255, 255, 255, 255)", true, false)
TestNewPrivateDumpV1.Style.Vars["ESPText"].color = TestNewPrivateDumpV1.GetColorFromString(TestNewPrivateDumpV1.Style.Vars["ESPText"].var:GetString())
TestNewPrivateDumpV1.Style.Vars["Crosshair"] = {}
TestNewPrivateDumpV1.Style.Vars["Crosshair"].var = CreateClientConVar("TestNewPrivateDumpV1_Style_Cross", "Color(255, 255, 255, 255)", true, false)
TestNewPrivateDumpV1.Style.Vars["Crosshair"].color = TestNewPrivateDumpV1.GetColorFromString(TestNewPrivateDumpV1.Style.Vars["Crosshair"].var:GetString())
TestNewPrivateDumpV1.Style.Vars["BodyText"] = {}
TestNewPrivateDumpV1.Style.Vars["BodyText"].var = CreateClientConVar("TestNewPrivateDumpV1_Style_BodyText", "Color(255, 255, 255, 255)", true, false)
TestNewPrivateDumpV1.Style.Vars["BodyText"].color = TestNewPrivateDumpV1.GetColorFromString(TestNewPrivateDumpV1.Style.Vars["BodyText"].var:GetString())
TestNewPrivateDumpV1.Style.Vars["Chams"] = {}
TestNewPrivateDumpV1.Style.Vars["Chams"].var = CreateClientConVar("TestNewPrivateDumpV1_Style_Chams", "Color(0, 255, 0, 255)", true, false)
TestNewPrivateDumpV1.Style.Vars["Chams"].color = TestNewPrivateDumpV1.GetColorFromString(TestNewPrivateDumpV1.Style.Vars["Chams"].var:GetString())
TestNewPrivateDumpV1.Style.Vars["BodyChams"] = {}
TestNewPrivateDumpV1.Style.Vars["BodyChams"].var = CreateClientConVar("TestNewPrivateDumpV1_Style_BodyChams", "Color(0, 255, 0, 255)", true, false)
TestNewPrivateDumpV1.Style.Vars["BodyChams"].color = TestNewPrivateDumpV1.GetColorFromString(TestNewPrivateDumpV1.Style.Vars["BodyChams"].var:GetString())
 
//This loads our friends list and custom entities list.
/*TestNewPrivateDumpV1.SavedData = CreateClientConVar("TestNewPrivateDumpV1_SaveData", TestNewPrivateDumpV1.RandomName(math.random(10, 15)), true, false)
if file.Exists(TestNewPrivateDumpV1.SavedData:GetString()..".txt", "DATA") then
        local info = string.Explode("\n", file.Read(TestNewPrivateDumpV1.SavedData:GetString()..".txt", "DATA"))
        if type(info) == "table" and info[1] and info[2] then
                TestNewPrivateDumpV1.Friends.List = util.JSONToTable(info[1])
                TestNewPrivateDumpV1.Entities.List = util.JSONToTable(info[2])
        end
end
 
TestNewPrivateDumpV1.SaveData = function()
        file.Write(TestNewPrivateDumpV1.SavedData:GetString()..".txt", util.TableToJSON(TestNewPrivateDumpV1.Friends.List))
        file.Append(TestNewPrivateDumpV1.SavedData:GetString()..".txt", "\n")
        file.Append(TestNewPrivateDumpV1.SavedData:GetString()..".txt", util.TableToJSON(TestNewPrivateDumpV1.Entities.List))
end*/
 
//This is all the bones i look for in the order im looking for them. Feel free to change the order if you want to attack the foot before the head or something like that.
TestNewPrivateDumpV1.Bones = {
"ValveBiped.Bip01_Head1",
"ValveBiped.Bip01_Neck1",
"ValveBiped.Bip01_Spine4",
"ValveBiped.Bip01_Spine2",
"ValveBiped.Bip01_Spine1",
"ValveBiped.Bip01_Spine",
"ValveBiped.Bip01_R_UpperArm",
"ValveBiped.Bip01_R_Forearm",
"ValveBiped.Bip01_R_Hand",
"ValveBiped.Bip01_L_UpperArm",
"ValveBiped.Bip01_L_Forearm",
"ValveBiped.Bip01_L_Hand",
"ValveBiped.Bip01_R_Thigh",
"ValveBiped.Bip01_R_Calf",
"ValveBiped.Bip01_R_Foot",
"ValveBiped.Bip01_R_Toe0",
"ValveBiped.Bip01_L_Thigh",
"ValveBiped.Bip01_L_Calf",
"ValveBiped.Bip01_L_Foot",
"ValveBiped.Bip01_L_Toe0"
}
 
//If random bones is enabled this list is gone through, randomly, and if none of the bones on this list are found the entire list (above) is gone through.
//If you edit this be sure to edit the function below it.
TestNewPrivateDumpV1.RandomBones = {
"ValveBiped.Bip01_Head1",
"ValveBiped.Bip01_Neck1",
"ValveBiped.Bip01_Spine4",
"ValveBiped.Bip01_Spine2",
"ValveBiped.Bip01_R_UpperArm",
"ValveBiped.Bip01_L_UpperArm"
}
TestNewPrivateDumpV1.GetRandomBones = function()
        local temp = {}
        local function GetBones() //Ahh recursion, i love you.
                if #TestNewPrivateDumpV1.RandomBones > 0 then
                        local random = math.random(1, #TestNewPrivateDumpV1.RandomBones)
                        table.insert(temp, TestNewPrivateDumpV1.RandomBones[random])
                        table.remove(TestNewPrivateDumpV1.RandomBones, random)
                        GetBones()
                else
                        table.insert(TestNewPrivateDumpV1.RandomBones, "ValveBiped.Bip01_Head1")
                        table.insert(TestNewPrivateDumpV1.RandomBones, "ValveBiped.Bip01_Neck1")
                        table.insert(TestNewPrivateDumpV1.RandomBones, "ValveBiped.Bip01_Spine4")
                        table.insert(TestNewPrivateDumpV1.RandomBones, "ValveBiped.Bip01_Spine2")
                        table.insert(TestNewPrivateDumpV1.RandomBones, "ValveBiped.Bip01_R_UpperArm")
                        table.insert(TestNewPrivateDumpV1.RandomBones, "ValveBiped.Bip01_L_UpperArm")
                end
        end
        GetBones()
        return temp
end
 
//A list of all keyboard keys, for binding
TestNewPrivateDumpV1.Keys = {
[0] = "KEY_NONE",
[1] = "KEY_0",
[2] = "KEY_1",
[3] = "KEY_2",
[4] = "KEY_3",
[5] = "KEY_4",
[6] = "KEY_5",
[7] = "KEY_6",
[8] = "KEY_7",
[9] = "KEY_8",
[10] = "KEY_9",
[11] = "KEY_A",
[12] = "KEY_B",
[13] = "KEY_C",
[14] = "KEY_D",
[15] = "KEY_E",
[16] = "KEY_F",
[17] = "KEY_G",
[18] = "KEY_H",
[19] = "KEY_I",
[20] = "KEY_J",
[21] = "KEY_K",
[22] = "KEY_L",
[23] = "KEY_M",
[24] = "KEY_N",
[25] = "KEY_O",
[26] = "KEY_P",
[27] = "KEY_Q",
[28] = "KEY_R",
[29] = "KEY_S",
[30] = "KEY_T",
[31] = "KEY_U",
[32] = "KEY_V",
[33] = "KEY_W",
[34] = "KEY_X",
[35] = "KEY_Y",
[36] = "KEY_Z",
[37] = "KEY_PAD_0",
[38] = "KEY_PAD_1",
[39] = "KEY_PAD_2",
[40] = "KEY_PAD_3",
[41] = "KEY_PAD_4",
[42] = "KEY_PAD_5",
[43] = "KEY_PAD_6",
[44] = "KEY_PAD_7",
[45] = "KEY_PAD_8",
[46] = "KEY_PAD_9",
[47] = "KEY_PAD_DIVIDE",
[48] = "KEY_PAD_MULTIPLY",
[49] = "KEY_PAD_MINUS",
[50] = "KEY_PAD_PLUS",
[51] = "KEY_PAD_ENTER",
[52] = "KEY_PAD_DECIMAL",
[53] = "KEY_LBRACKET",
[54] = "KEY_RBRACKET",
[55] = "KEY_SEMICOLON",
[56] = "KEY_APOSTROPHE",
[57] = "KEY_BACKQUOTE",
[58] = "KEY_COMMA",
[59] = "KEY_PERIOD",
[60] = "KEY_SLASH",
[61] = "KEY_BACKSLASH",
[62] = "KEY_MINUS",
[63] = "KEY_EQUAL",
[64] = "KEY_ENTER",
[65] = "KEY_SPACE",
[66] = "KEY_BACKSPACE",
[67] = "KEY_TAB",
[68] = "KEY_CAPSLOCK",
[69] = "KEY_NUMLOCK",
[70] = "KEY_ESCAPE",
[71] = "KEY_SCROLLLOCK",
[72] = "KEY_INSERT",
[73] = "KEY_DELETE",
[74] = "KEY_HOME",
[75] = "KEY_END",
[76] = "KEY_PAGEUP",
[77] = "KEY_PAGEDOWN",
[78] = "KEY_BREAK",
[79] = "KEY_LSHIFT",
[80] = "KEY_RSHIFT",
[81] = "KEY_LALT",
[82] = "KEY_RALT",
[83] = "KEY_LCONTROL",
[84] = "KEY_RCONTROL",
[85] = "KEY_LWIN",
[86] = "KEY_RWIN",
[87] = "KEY_APP",
[88] = "KEY_UP",
[89] = "KEY_LEFT",
[90] = "KEY_DOWN",
[91] = "KEY_RIGHT",
[92] = "KEY_F1",
[93] = "KEY_F2",
[94] = "KEY_F3",
[95] = "KEY_F4",
[96] = "KEY_F5",
[97] = "KEY_F6",
[98] = "KEY_F7",
[99] = "KEY_F8",
[100] = "KEY_F9",
[101] = "KEY_F10",
[102] = "KEY_F11",
[103] = "KEY_F12",
//[104] = "KEY_CAPSLOCKTOGGLE", //THESE
//[105] = "KEY_NUMLOCKTOGGLE", //MOFOS
//[106] = "KEY_SCROLLLOCKTOGGLE", //SHOULD DIE
[107] = "KEY_XBUTTON_UP",
[108] = "KEY_XBUTTON_DOWN",
[109] = "KEY_XBUTTON_LEFT",
[110] = "KEY_XBUTTON_RIGHT",
[111] = "KEY_XBUTTON_START",
[112] = "KEY_XBUTTON_BACK",
[113] = "KEY_XBUTTON_STICK1",
[114] = "KEY_XBUTTON_STICK2",
[115] = "KEY_XBUTTON_A",
[116] = "KEY_XBUTTON_B",
[117] = "KEY_XBUTTON_X",
[118] = "KEY_XBUTTON_Y",
[119] = "KEY_XBUTTON_BLACK",
[120] = "KEY_XBUTTON_WHITE",
[121] = "KEY_XBUTTON_LTRIGGER",
[122] = "KEY_XBUTTON_RTRIGGER",
[123] = "KEY_XSTICK1_UP",
[124] = "KEY_XSTICK1_DOWN",
[125] = "KEY_XSTICK1_LEFT",
[126] = "KEY_XSTICK1_RIGHT",
[127] = "KEY_XSTICK2_UP",
[128] = "KEY_XSTICK2_DOWN",
[129] = "KEY_XSTICK2_LEFT",
[130] = "KEY_XSTICK2_RIGHT"
}
//A list of all mouse keys, for binding
TestNewPrivateDumpV1.MouseKeys = {
[107] = "MOUSE_LEFT",
[108] = "MOUSE_RIGHT",
[109] = "MOUSE_MIDDLE",
[110] = "MOUSE_4",
[111] = "MOUSE_5"
}
//Tells me if a specific key is pressed. Loops through both tables.
TestNewPrivateDumpV1.KeyPressed = function(key)
        if TestNewPrivateDumpV1.InChat then return false end
       
        for k = 107, 111 do
                if key == TestNewPrivateDumpV1.MouseKeys[k] then
                        if input.IsMouseDown(k) then
                                return true
                        else
                                return false
                        end
                end
        end
       
        for k = 0, 130 do
                if key == TestNewPrivateDumpV1.Keys[k] then
                        if input.IsKeyDown(k) then
                                return true
                        else
                                return false
                        end
                end
        end
       
        return false
end
 
//Very simple. If the boolean is true it returns 1. If the boolean is false then it returns 0. I dont think i ended up using this anywhere, but whatever, ill leave it here.
TestNewPrivateDumpV1.BoolToInt = function(bool)
        if bool then
                return 1
        else
                return 0
        end
end
 
//Checking if a bone is visible, pos is the position of the bone and ent is the entity whos bone were looking for.
TestNewPrivateDumpV1.SpotIsVisible = function(pos, ent)
        ent = ent or TestNewPrivateDumpV1.Aimbot.CurTarget
        local tracedata = {}
        tracedata.start = TestNewPrivateDumpV1.Ply:GetShootPos()
        tracedata.endpos = pos
        tracedata.filter = {TestNewPrivateDumpV1.Ply, ent}
       
        local trace = util.TraceLine(tracedata)
        if trace.HitPos:Distance(pos) < 0.005 then
                return true
        else
                return false
        end
end
 
//Checks all of the entities bones to find if we can see this entity or not.
TestNewPrivateDumpV1.CanSee = function(ent)
        for k = 1, #TestNewPrivateDumpV1.Bones do
                local v = TestNewPrivateDumpV1.Bones[k]
                local bone = ent:LookupBone(v)
                if bone != nil then
                        local pos, ang = ent:GetBonePosition(bone)
                        if TestNewPrivateDumpV1.SpotIsVisible(pos, ent) then
                                return true
                        end
                end
        end
        return false
end
 
//This returns the next entity we should attack.
TestNewPrivateDumpV1.GetTarget = function()
        if TestNewPrivateDumpV1.Aimbot.Vars["AttackNPCs"]:GetBool() or TestNewPrivateDumpV1.Aimbot.Vars["AttackPlayers"]:GetBool() then
                local targets = {}
                local everything = ents.GetAll()
                for k = 1, #everything do
                        local v = everything[k]
                        if TestNewPrivateDumpV1.Aimbot.Vars["AttackNPCs"]:GetBool() and v:IsNPC() then
                                if TestNewPrivateDumpV1.CanSee(v) then
                                        table.insert(targets, {["Target"] = v, ["Pos"] = v:LocalToWorld(v:OBBCenter())})
                                end
                        elseif TestNewPrivateDumpV1.Aimbot.Vars["AttackPlayers"]:GetBool() and v:IsPlayer() and v != TestNewPrivateDumpV1.Ply then
                                if TestNewPrivateDumpV1.CanSee(v) then
                                        table.insert(targets, {["Target"] = v, ["Pos"] = v:LocalToWorld(v:OBBCenter())})
                                end
                        end
                end
               
                for k,v in SortedPairs(targets, true) do //It will already be sorted so this shouldn't be too resource heavy, the main point of this is to loop through the table backwards
                        local v = v["Target"]
                        local shouldremove = false
                        if TestNewPrivateDumpV1.Aimbot.Vars["IgnoreTeam"]:GetBool() and v:IsPlayer() then
                                if TestNewPrivateDumpV1.TTT then
                                        if TestNewPrivateDumpV1.Ply:GetRole() == 1 and v:GetRole() == 1 then
                                                shouldremove = true
                                        end
                                               
                                        if TestNewPrivateDumpV1.Ply:GetRole() != 1 and not table.HasValue(TestNewPrivateDumpV1.Traitors, v) then
                                                shouldremove = true
                                        end
                                else
                                        if v:Team() == TestNewPrivateDumpV1.Ply:Team() then
                                                shouldremove = true
                                        end
                                end
                        end
                       
                        if TestNewPrivateDumpV1.Friends.Vars["Active"]:GetBool() then
                                if TestNewPrivateDumpV1.Friends.Vars["Reverse"]:GetBool() then
                                        if not table.HasValue(TestNewPrivateDumpV1.Friends.List, v:SteamID()) then
                                                shouldremove = true
                                        end
                                else
                                        if table.HasValue(TestNewPrivateDumpV1.Friends.List, v:SteamID()) then
                                                shouldremove = true            
                                        end
                                end
                        end
                       
                        if shouldremove then
                                table.remove(targets, k)
                        end
                end
               
                if #targets == 0 then
                        return nil
                elseif #targets == 1 then
                        targets[1]["Target"].BoneToAimAt = nil
                        return targets[1]["Target"]
                end
               
                if TestNewPrivateDumpV1.Aimbot.Vars["Preferance"]:GetString() == "Distance" then
                        local min = {["Distance"] = TestNewPrivateDumpV1.Ply:GetPos():Distance(targets[1]["Pos"]), ["Target"] = targets[1]["Target"]}
                        for k = 1, #targets do
                                local v = targets[k]
                               
                                local distance = TestNewPrivateDumpV1.Ply:GetPos():Distance(v["Pos"])
                                if distance < min["Distance"] then
                                        min = {["Distance"] = distance, ["Target"] = v["Target"]}
                                end
                        end
                        min["Target"].BoneToAimAt = nil
                        return min["Target"]
                elseif TestNewPrivateDumpV1.Aimbot.Vars["Preferance"]:GetString() == "Angle" then            
                        local min = {["Angle"] = TestNewPrivateDumpV1.AngleTo(targets[1]["Pos"]), ["Target"] = targets[1]["Target"]}
                        for k = 1, #targets do
                                local v = targets[k]
                               
                                local angle = TestNewPrivateDumpV1.AngleTo(v["Pos"])
                                if angle < min["Angle"] then
                                        min = {["Angle"] = angle, ["Target"] = v["Target"]}
                                end
                        end
                        min["Target"].BoneToAimAt = nil
                        return min["Target"]
                end
        else
                return nil
        end
end
 
//This returns the total angle away from the target we are, and then the pitch and yaw seperately
TestNewPrivateDumpV1.AngleTo = function(pos)
        local myAngs = TestNewPrivateDumpV1.Ply:GetAngles()
        local needed = (pos - TestNewPrivateDumpV1.Ply:GetShootPos()):Angle()
       
        myAngs.p = math.NormalizeAngle(myAngs.p)
        needed.p = math.NormalizeAngle(needed.p)
       
        myAngs.y = math.NormalizeAngle(myAngs.y)
        needed.y = math.NormalizeAngle(needed.y)
       
        local p = math.NormalizeAngle(needed.p - myAngs.p)
        local y = math.NormalizeAngle(needed.y - myAngs.y)
       
        return math.abs(p) + math.abs(y), {p = p, y = y}
end
 
//Returns true if our target meets our preferances.
TestNewPrivateDumpV1.ValidTarget = function()
        if TestNewPrivateDumpV1.Aimbot.CurTarget == nil then return false end
        if not IsValid(TestNewPrivateDumpV1.Aimbot.CurTarget) then return false end
        if TestNewPrivateDumpV1.Aimbot.CurTarget:IsPlayer() and (not TestNewPrivateDumpV1.Aimbot.CurTarget:Alive() or TestNewPrivateDumpV1.Aimbot.CurTarget:Team() == TEAM_SPECTATOR or TestNewPrivateDumpV1.Aimbot.CurTarget:Health() < 1) then return false end
        if not TestNewPrivateDumpV1.Aimbot.Vars["AttackNPCs"]:GetBool() and TestNewPrivateDumpV1.Aimbot.CurTarget:IsNPC() then return false end
        if not TestNewPrivateDumpV1.Aimbot.Vars["AttackPlayers"]:GetBool() and TestNewPrivateDumpV1.Aimbot.CurTarget:IsPlayer() then return false end
        if not TestNewPrivateDumpV1.CanSee(TestNewPrivateDumpV1.Aimbot.CurTarget) then return false end
        if TestNewPrivateDumpV1.Aimbot.Vars["IgnoreTeam"]:GetBool() and TestNewPrivateDumpV1.Aimbot.CurTarget:IsPlayer() then
                if TestNewPrivateDumpV1.TTT then
                        if TestNewPrivateDumpV1.Ply:GetRole() == 1 and TestNewPrivateDumpV1.Aimbot.CurTarget:GetRole() == 1 then return false end                            
                        if TestNewPrivateDumpV1.Ply:GetRole() != 1 and not table.HasValue(TestNewPrivateDumpV1.Traitors, TestNewPrivateDumpV1.Aimbot.CurTarget) then return false end
                else
                        if TestNewPrivateDumpV1.Aimbot.CurTarget:Team() == TestNewPrivateDumpV1.Ply:Team() then return false end
                end
        end
       
        return true
end
 
hook.Add("RenderScreenspaceEffects", TestNewPrivateDumpV1.RandomName(math.random(10, 15)), function()
        if TestNewPrivateDumpV1.Active:GetBool() then
                local everything = ents.GetAll()
                for k = 1, #everything do
                        local v = everything[k]
                       
                        if TestNewPrivateDumpV1.Chams.Vars["Active"]:GetBool() and v != TestNewPrivateDumpV1.Ply and (TestNewPrivateDumpV1.Chams.Vars["MaxDistance"]:GetInt() == 0 or v:GetPos():Distance(TestNewPrivateDumpV1.Ply:GetPos()) < TestNewPrivateDumpV1.Chams.Vars["MaxDistance"]:GetInt()) then
                                cam.Start3D(EyePos(), EyeAngles())
                                        if (v:IsPlayer() and v:Alive() and v:Team() != TEAM_SPECTATOR and TestNewPrivateDumpV1.Chams.Vars["Players"]:GetBool()) or (v:IsNPC() and v:Health() > 0 and TestNewPrivateDumpV1.Chams.Vars["NPCs"]:GetBool()) then
                                                local color = TestNewPrivateDumpV1.Style.Vars["Chams"].color
                                                if TestNewPrivateDumpV1.Chams.Vars["TeamBased"]:GetBool() and v:IsPlayer() then
                                                        color = team.GetColor(v:Team())
                                                        if TestNewPrivateDumpV1.TTT then
                                                                if v:GetRole() == 2 then
                                                                        color = Color(0, 0, 255, 255)
                                                                elseif table.HasValue(TestNewPrivateDumpV1.Traitors, v) then
                                                                        color = Color(255, 0, 0, 255)
                                                                else
                                                                        color = Color(0, 255, 0, 255)
                                                                end
                                                        end
                                                end
                                                render.SuppressEngineLighting(true)
                                                render.SetColorModulation(color.r/255, color.g/255, color.b/255, 1)
                                                render.MaterialOverride(TestNewPrivateDumpV1.Chams.Mat)
                                                v:DrawModel()
                                               
                                                render.SetColorModulation((color.r + 150)/250, (color.g + 150)/250, (color.b + 150)/255, 1)                                            
                                                if IsValid(v:GetActiveWeapon()) and TestNewPrivateDumpV1.Chams.Vars["Weapons"]:GetBool() then
                                                        v:GetActiveWeapon():DrawModel()
                                                end
                                               
                                                render.SetColorModulation(1, 1, 1, 1)
                                                render.MaterialOverride()
                                                render.SetModelLighting(4, color.r/255, color.g/255, color.b/255)
                                                v:DrawModel()
                                                render.SuppressEngineLighting(false)
                                        elseif TestNewPrivateDumpV1.TTT and TestNewPrivateDumpV1.Chams.Vars["Bodies"]:GetBool() and v:GetClass() == "prop_ragdoll" then
                                                local color = TestNewPrivateDumpV1.Style.Vars["BodyChams"].color
                                                render.SuppressEngineLighting(true)    
                                                render.SetColorModulation(color.r/255, color.g/255, color.b/255, 1)
                                                render.MaterialOverride(TestNewPrivateDumpV1.Chams.Mat)
                                                v:DrawModel()  
                                                render.SetColorModulation(1, 1, 1, 1)
                                                render.MaterialOverride()
                                                render.SetModelLighting(4, color.r/255, color.g/255, color.b/255)
                                                v:DrawModel()
                                                render.SuppressEngineLighting(false)
                                        elseif TestNewPrivateDumpV1.Entities.Vars["Active"]:GetBool() and table.HasValue(TestNewPrivateDumpV1.Entities.List, v:GetClass()) then
                                                local color = TestNewPrivateDumpV1.Style.Vars["Chams"].color                                  
                                                render.SuppressEngineLighting(true)    
                                                render.SetColorModulation(color.r/255, color.g/255, color.b/255, 1)
                                                render.MaterialOverride(TestNewPrivateDumpV1.Chams.Mat)
                                                v:DrawModel()  
                                                render.SetColorModulation(1, 1, 1, 1)
                                                render.MaterialOverride()
                                                render.SetModelLighting(4, color.r/255, color.g/255, color.b/255)
                                                v:DrawModel()
                                                render.SuppressEngineLighting(false)
                                        end
                                cam.End3D()
                        end
                end
        end
end)
 
//Helper function on radar. I just copied this one from the wiki.
TestNewPrivateDumpV1.DrawFilledCircle = function(x, y, radius, quality)
        local circle = {}
    local tmp = 0
    for i = 1, quality do
        tmp = math.rad(i * 360) / quality
        circle[i] = {x = x + math.cos(tmp) * radius, y = y + math.sin(tmp) * radius}
    end
        surface.DrawPoly(circle)
end
 
//Another helper fuction on the radar.
TestNewPrivateDumpV1.DrawArrow = function(x, y, myRotation)
        local arrow = {}      
        arrow[1] = {x = x, y = y}
        arrow[2] = {x = x + 4, y = y + 7.5}
        arrow[3] = {x = x, y = y + 5}
        arrow[4] = {x = x - 4, y = y + 7.5}
       
        //Now that i have the arrow determined, i have to rotate it to match the targets angle
        myRotation = myRotation * -1
        myRotation = math.rad(myRotation)
        for i = 1, 4 do
                local theirX = arrow[i].x
                local theirY = arrow[i].y
               
                theirX = theirX - x
                theirY = theirY - y
               
                arrow[i].x = theirX * math.cos(myRotation) - theirY * math.sin(myRotation)
                arrow[i].y = theirX * math.sin(myRotation) + theirY * math.cos(myRotation)
               
                arrow[i].x = arrow[i].x + x
                arrow[i].y = arrow[i].y + y
        end
 
        surface.DrawPoly(arrow)
end
 
TestNewPrivateDumpV1.Traitors = {}
TestNewPrivateDumpV1.SuperAdmins = {}
TestNewPrivateDumpV1.Admins = {}
TestNewPrivateDumpV1.Spectators = {}
local radarX, radarY, radarWidth, radarHeight = 100, 200, 150, 150
hook.Add("HUDPaint", TestNewPrivateDumpV1.RandomName(math.random(10, 15)), function()
        if TestNewPrivateDumpV1.Active:GetBool() then
                local everything = ents.GetAll()
               
                if TestNewPrivateDumpV1.ESP.Vars["Active"]:GetBool() and TestNewPrivateDumpV1.ESP.Vars["Radar"]:GetBool() then //Setting up the background here. And since the ESP doesnt draw you
                        draw.RoundedBox(0, radarX, radarY, radarWidth, radarHeight, Color(100, 100, 100, 255 ))
                        draw.NoTexture()
                        if TestNewPrivateDumpV1.ESP.Vars["TeamBased"]:GetBool() then
                                local color = team.GetColor(TestNewPrivateDumpV1.Ply:Team())
                                if TestNewPrivateDumpV1.TTT then
                                        if TestNewPrivateDumpV1.Ply:GetRole() == 2 then
                                                color = Color(0, 0, 255, 255)
                                        elseif TestNewPrivateDumpV1.Ply:GetRole() == 1 then
                                                color = Color(255, 0, 0, 255)
                                        else
                                                color = Color(0, 255, 0, 255)
                                        end
                                end
                                surface.SetDrawColor(color)
                        else
                                surface.SetDrawColor(TestNewPrivateDumpV1.Style.Vars["ESPText"].color)
                        end
                        TestNewPrivateDumpV1.DrawArrow(radarX + (radarWidth / 2), radarY + (radarHeight / 2), 0)
                end
               
                for k = 1, #everything do
                        local v = everything[k]
               
                        if TestNewPrivateDumpV1.ESP.Vars["Active"]:GetBool() and v != TestNewPrivateDumpV1.Ply and (TestNewPrivateDumpV1.ESP.Vars["MaxDistance"]:GetInt() == 0 or v:GetPos():Distance(TestNewPrivateDumpV1.Ply:GetPos()) < TestNewPrivateDumpV1.ESP.Vars["MaxDistance"]:GetInt()) then                                                                            
                                if (v:IsPlayer() and v:Alive() and v:Team() != TEAM_SPECTATOR and TestNewPrivateDumpV1.ESP.Vars["Players"]:GetBool()) or (v:IsNPC() and v:Health() > 0 and TestNewPrivateDumpV1.ESP.Vars["NPCs"]:GetBool()) then
                                        local color = TestNewPrivateDumpV1.Style.Vars["ESPText"].color
                                        if TestNewPrivateDumpV1.ESP.Vars["TeamBased"]:GetBool() and v:IsPlayer() then
                                                color = team.GetColor(v:Team())
                                                if TestNewPrivateDumpV1.TTT then
                                                        if v:GetRole() == 2 then
                                                                color = Color(0, 0, 255, 255)
                                                        elseif table.HasValue(TestNewPrivateDumpV1.Traitors, v) then
                                                                color = Color(255, 0, 0, 255)
                                                        else
                                                                color = Color(0, 255, 0, 255)
                                                        end
                                                end
                                        end
                                       
                                        local Min, Max = v:GetCollisionBounds()
                                        if TestNewPrivateDumpV1.ESP.Vars["Box"]:GetBool() then
                                                local one = v:LocalToWorld(Min):ToScreen()
                                                local two = v:LocalToWorld(Vector(Min.x, Min.y, Max.z)):ToScreen()
                                                local three = v:LocalToWorld(Vector(Min.x, Min.y + (Max.y * 2), Min.z)):ToScreen()
                                                local four = v:LocalToWorld(Vector(Min.x + (Max.x * 2), Min.y, Min.z)):ToScreen()
                                                local five = v:LocalToWorld(Max):ToScreen()
                                                local six = v:LocalToWorld(Vector(Max.x, Max.y, Min.z)):ToScreen()
                                                local seven = v:LocalToWorld(Vector(Max.x, Max.y + (Min.y * 2), Max.z)):ToScreen()
                                                local eight = v:LocalToWorld(Vector(Max.x + (Min.x * 2), Max.y, Max.z)):ToScreen()                            
                                               
                                                if TestNewPrivateDumpV1.ESP.Vars["TeamBased"]:GetBool() then
                                                        surface.SetDrawColor(color)
                                                else
                                                        surface.SetDrawColor(TestNewPrivateDumpV1.Style.Vars["BoundingBox"].color)
                                                end
                                                local function connect(tabone, tabtwo)
                                                        surface.DrawLine(tabone.x, tabone.y, tabtwo.x, tabtwo.y)
                                                end
                                               
                                                connect(one, two)
                                                connect(three, eight)
                                                connect(four, seven)
                                                connect(six, five)
                                                connect(four, six)
                                                connect(four, one)
                                                connect(one, three)
                                                connect(three, six)
                                                connect(five, eight)
                                                connect(eight, two)
                                                connect(two, seven)
                                                connect(seven, five)
                                        end
                                       
                                        surface.SetFont("ESPFont")
                                        local top = v:GetPos() + Vector(0, 0, Max.z + 10) // A little above their head so its not constantly covering their face.
                                        local topscreen = top:ToScreen()
                                        local topy = topscreen.y
                                       
                                        local bottom = v:GetPos()
                                        local bottomscreen = bottom:ToScreen()
                                        local bottomy = bottomscreen.y
                                       
                                        local function DrawAbove(text)
                                                local W, H = surface.GetTextSize(text)
                                                surface.SetTextPos(topscreen.x - W / 2, topy)
                                                surface.DrawText(text)
                                               
                                                topy = topy + H
                                        end
                                       
                                        local function DrawBelow(text)
                                                local W, H = surface.GetTextSize(text)
                                                surface.SetTextPos(bottomscreen.x - W / 2, bottomy)
                                                surface.DrawText(text)
                                               
                                                bottomy = bottomy + H
                                        end
                                       
                                        surface.SetTextColor(Color(255, 0, 0, 255))
                                        if TestNewPrivateDumpV1.ESP.Vars["ShowTraitors"]:GetString() != "Off" and table.HasValue(TestNewPrivateDumpV1.Traitors, v) then
                                                if TestNewPrivateDumpV1.ESP.Vars["ShowTraitors"]:GetString() == "Above" then
                                                        DrawAbove("Traitor")
                                                else
                                                        DrawBelow("Traitor")
                                                end
                                        end
                                       
                                        surface.SetTextColor(color)
                                        if v:IsPlayer() then
                                                if TestNewPrivateDumpV1.ESP.Vars["Name"]:GetString() == "Above" then
                                                        DrawAbove("Name: "..v:Nick())
                                                elseif TestNewPrivateDumpV1.ESP.Vars["Name"]:GetString() == "Below" then
                                                        DrawBelow("Name: "..v:Nick())
                                                end
                                        else
                                                if TestNewPrivateDumpV1.ESP.Vars["Name"]:GetString() == "Above" then
                                                        DrawAbove("Name: "..v:GetClass())
                                                elseif TestNewPrivateDumpV1.ESP.Vars["Name"]:GetString() == "Below" then
                                                        DrawBelow("Name: "..v:GetClass())
                                                end
                                        end
                                       
                                        if TestNewPrivateDumpV1.ESP.Vars["Weapons"]:GetString() == "Above" and IsValid(v:GetActiveWeapon()) then
                                                DrawAbove("Weapon: "..v:GetActiveWeapon():GetClass())
                                        elseif TestNewPrivateDumpV1.ESP.Vars["Weapons"]:GetString() == "Below" and IsValid(v:GetActiveWeapon()) then
                                                DrawBelow("Weapon: "..v:GetActiveWeapon():GetClass())
                                        end            
                                       
                                        if TestNewPrivateDumpV1.ESP.Vars["Distance"]:GetString() == "Above" then
                                                DrawAbove("Distance: "..bottom:Distance(TestNewPrivateDumpV1.Ply:GetPos()))
                                        elseif TestNewPrivateDumpV1.ESP.Vars["Distance"]:GetString() == "Below" then
                                                DrawBelow("Distance: "..bottom:Distance(TestNewPrivateDumpV1.Ply:GetPos()))
                                        end    
                                       
                                        if TestNewPrivateDumpV1.ESP.Vars["Health"]:GetString() == "Above" then
                                                DrawAbove("HP: "..v:Health())
                                        elseif TestNewPrivateDumpV1.ESP.Vars["Health"]:GetString() == "Below" then
                                                DrawBelow("HP: "..v:Health())
                                        end
                                       
                                        if TestNewPrivateDumpV1.ESP.Vars["Radar"]:GetBool() then
                                                surface.SetDrawColor(color)
                                                local myPos = TestNewPrivateDumpV1.Ply:GetPos()
                                                local theirPos = v:GetPos()
                                                local myAngles = TestNewPrivateDumpV1.Ply:GetAngles()
                                               
                                                local theirX = (radarX + (radarWidth / 2)) + ((theirPos.x - myPos.x) / TestNewPrivateDumpV1.ESP.Vars["RadarScale"]:GetInt())
                                                local theirY = (radarY + (radarHeight / 2)) + ((myPos.y - theirPos.y) / TestNewPrivateDumpV1.ESP.Vars["RadarScale"]:GetInt())
                                               
                                                //Now i have to rotate this
                                                local myRotation = myAngles.y - 90
                                                myRotation = math.rad(myRotation)
                                               
                                                theirX = theirX - (radarX + (radarWidth / 2))
                                                theirY = theirY - (radarY + (radarHeight / 2))
                                                local newX = theirX * math.cos(myRotation) - theirY * math.sin(myRotation)
                                                local newY = theirX * math.sin(myRotation) + theirY * math.cos(myRotation)
                                                newX = newX + (radarX + (radarWidth / 2))
                                                newY = newY + (radarY + (radarHeight / 2))
                                               
                                                //And now that its rotated i can check if its within our radars bounds and draw it
                                                if newX < (radarX + radarWidth) and newX > radarX and newY < (radarY + radarHeight) and newY > radarY then
                                                        TestNewPrivateDumpV1.DrawArrow(newX, newY, v:EyeAngles().y - myAngles.y)
                                                end
                                        end
                                elseif TestNewPrivateDumpV1.TTT and TestNewPrivateDumpV1.ESP.Vars["Bodies"]:GetBool() and v:GetClass() == "prop_ragdoll" then
                                        surface.SetFont("ESPFont")
                                       
                                        //Im just going to position this info at the center of the player, if i get any complaints ill change it
                                        local pos = v:LocalToWorld(v:OBBCenter())
                                        local poscreen = pos:ToScreen()
                                        local W, H = surface.GetTextSize("Sample") //It doesnt have to be perfect but this will help center the text more.
                                        local y = poscreen.y - (H * 1.5)
                                       
                                        local function DrawText(text)
                                                local W, H = surface.GetTextSize(text)
                                                surface.SetTextPos(poscreen.x - W / 2, y)
                                                surface.DrawText(text)
                                               
                                                y = y + H
                                        end
                                       
                                        surface.SetTextColor(TestNewPrivateDumpV1.Style.Vars["BodyText"].color)
                                        DrawText("Credits: "..TestNewPrivateDumpV1.TTTCORPSE.GetCredits(v, 0))
                                        DrawText("Name: "..TestNewPrivateDumpV1.TTTCORPSE.GetPlayerNick(v, "Unknown"))
                                        DrawText("Found: "..tostring(TestNewPrivateDumpV1.TTTCORPSE.GetFound(v, false)))
                                       
                                        if TestNewPrivateDumpV1.ESP.Vars["Radar"] then
                                                surface.SetDrawColor(TestNewPrivateDumpV1.Style.Vars["BodyText"].color)
                                                local myPos = TestNewPrivateDumpV1.Ply:GetPos()
                                                local theirPos = v:GetPos()
                                               
                                                local theirX = (radarX + (radarWidth / 2)) + ((theirPos.x - myPos.x) / TestNewPrivateDumpV1.ESP.Vars["RadarScale"]:GetInt())
                                                local theirY = (radarY + (radarHeight / 2)) + ((myPos.y - theirPos.y) / TestNewPrivateDumpV1.ESP.Vars["RadarScale"]:GetInt())
                                               
                                                //Now i have to rotate this
                                                local myRotation = TestNewPrivateDumpV1.Ply:GetAngles().y - 90
                                                myRotation = math.rad(myRotation)
                                               
                                                theirX = theirX - (radarX + (radarWidth / 2))
                                                theirY = theirY - (radarY + (radarHeight / 2))
                                                local newX = theirX * math.cos(myRotation) - theirY * math.sin(myRotation)
                                                local newY = theirX * math.sin(myRotation) + theirY * math.cos(myRotation)
                                                newX = newX + (radarX + (radarWidth / 2))
                                                newY = newY + (radarY + (radarHeight / 2))
                                               
                                                //And now that its rotated i can check if its within our radars bounds and draw it
                                                if newX < (radarX + radarWidth) and newX > radarX and newY < (radarY + radarHeight) and newY > radarY then
                                                        TestNewPrivateDumpV1.DrawFilledCircle(newX, newY, 2, 4)
                                                end
                                        end
                                elseif TestNewPrivateDumpV1.Entities.Vars["Active"]:GetBool() and table.HasValue(TestNewPrivateDumpV1.Entities.List, v:GetClass()) then
                                        surface.SetFont("ESPFont")
                                        surface.SetTextColor(TestNewPrivateDumpV1.Style.Vars["ESPText"].color)
                                       
                                        local text = v:GetClass()
                                        local W, H = surface.GetTextSize(text)
                                       
                                        local PosScreen = v:GetPos():ToScreen()
                                        surface.SetTextPos(PosScreen.x - W / 2, PosScreen.y)
                                        surface.DrawText(text)
                                end
                        end
                       
                        surface.SetFont("default")
                        if v:IsPlayer() and v:IsSuperAdmin() then
                                if not table.HasValue(TestNewPrivateDumpV1.SuperAdmins, v) then
                                        table.insert(TestNewPrivateDumpV1.SuperAdmins, v)
                                        TestNewPrivateDumpV1.Message("Super Admin "..v:Nick().." joined the game.")
                                        if TestNewPrivateDumpV1.Misc.Vars["Sounds"]:GetBool() then
                                                surface.PlaySound("vo/npc/Alyx/watchout02.wav")
                                        end    
                                end
                        end                    
                        if v:IsPlayer() and v:IsAdmin() and not v:IsSuperAdmin() then
                                if not table.HasValue(TestNewPrivateDumpV1.Admins, v) then
                                        table.insert(TestNewPrivateDumpV1.Admins, v)
                                        TestNewPrivateDumpV1.Message("Admin "..v:Nick().." joined the game.")
                                        if TestNewPrivateDumpV1.Misc.Vars["Sounds"]:GetBool() then
                                                surface.PlaySound("vo/npc/Alyx/watchout01.wav")
                                        end    
                                end
                        end            
                        for k,v in SortedPairs(TestNewPrivateDumpV1.Admins, true) do
                                if not IsValid(v) then
                                        table.remove(TestNewPrivateDumpV1.Admins, k)
                                end
                        end
                        for k,v in SortedPairs(TestNewPrivateDumpV1.SuperAdmins, true) do
                                if not IsValid(v) then
                                        table.remove(TestNewPrivateDumpV1.SuperAdmins, k)
                                end
                        end
                               
                        if v:IsPlayer() and v:GetObserverTarget() == TestNewPrivateDumpV1.Ply then
                                if not table.HasValue(TestNewPrivateDumpV1.Spectators, v) then
                                        table.insert(TestNewPrivateDumpV1.Spectators, v)
                                        TestNewPrivateDumpV1.Message(v:Nick().." started spectating you.")
                                        if TestNewPrivateDumpV1.Misc.Vars["Sounds"]:GetBool() then
                                                surface.PlaySound("vo/npc/female01/ohno.wav")
                                        end                            
                                end
                        end
                        for k,v in SortedPairs(TestNewPrivateDumpV1.Spectators, true) do
                                if IsValid(v) then
                                        if v:GetObserverTarget() != TestNewPrivateDumpV1.Ply then
                                                table.remove(TestNewPrivateDumpV1.Spectators, k)
                                        end
                                else
                                        table.remove(TestNewPrivateDumpV1.Spectators, k)
                                end
                        end
                       
                        if TestNewPrivateDumpV1.TTT and TestNewPrivateDumpV1.Misc.Vars["TraitorFinder"]:GetBool() then
                                if GetRoundState() == 3 and v:IsWeapon() and type(v:GetOwner()) == "Player" and v.Buyer == nil and v.CanBuy and table.HasValue(v.CanBuy, 1) then
                                        local owner = v:GetOwner()
                                        if owner:GetRole() == 2 then
                                                v.Buyer = owner
                                        else
                                                TestNewPrivateDumpV1.Message(owner:Nick().." bought a traitor weapon: "..v:GetClass())
                                                v.Buyer = owner
                                                table.insert(TestNewPrivateDumpV1.Traitors, owner)
                                                if TestNewPrivateDumpV1.Misc.Vars["Sounds"]:GetBool() then
                                                        surface.PlaySound("weapons/shotgun/shotgun_cock.wav")
                                                end    
                                        end
                                elseif GetRoundState() != 3 then
                                        table.Empty(TestNewPrivateDumpV1.Traitors)
                                end
                        end
                       
                        if TestNewPrivateDumpV1.Misc.Vars["Deaths"]:GetBool() and v:IsPlayer() then
                                if v:Alive() then
                                        v.IsAlive = true
                                elseif v.IsAlive then
                                        TestNewPrivateDumpV1.Message(3, v:Nick().." just died.")
                                        v.IsAlive = false
                                        if TestNewPrivateDumpV1.Misc.Vars["Sounds"]:GetBool() then
                                                surface.PlaySound("npc/combine_soldier/vo/onedown.wav")
                                        end    
                                end                            
                        end
                end
               
                surface.SetFont("default")
                surface.SetTextColor(Color(255, 255, 255, 255))
                local AdminWidest = 0
                local AdminTotalHeight = 0
                local AdminHeight = 20
                if TestNewPrivateDumpV1.Misc.Vars["ShowAdmins"]:GetBool() then
                        for k,v in pairs(TestNewPrivateDumpV1.SuperAdmins) do
                                local W, H = surface.GetTextSize(v:Nick().." - Super Admin")
                                if W > AdminWidest then
                                        AdminWidest = W
                                end
                                AdminTotalHeight = AdminTotalHeight + H
                        end
                        for k,v in pairs(TestNewPrivateDumpV1.Admins) do
                                local W, H = surface.GetTextSize(v:Nick().." - Admin")
                                if W > AdminWidest then
                                        AdminWidest = W
                                end
                                AdminTotalHeight = AdminTotalHeight + H
                        end
                        draw.RoundedBox(8, ScrW() - AdminWidest - 30, 10, AdminWidest + 20, AdminTotalHeight + 20, Color(0, 0, 0, 150 ))
                        for k,v in pairs(TestNewPrivateDumpV1.SuperAdmins) do
                                local text = v:Nick().." - Super Admin"
                                local W, H = surface.GetTextSize(text)
                                surface.SetTextPos(ScrW() - 20 - AdminWidest, AdminHeight)
                                surface.DrawText(text)
                                AdminHeight = AdminHeight + H
                        end
                        for k,v in pairs(TestNewPrivateDumpV1.Admins) do
                                local text = v:Nick().." - Admin"
                                local W, H = surface.GetTextSize(text)
                                surface.SetTextPos(ScrW() - 20 - AdminWidest, AdminHeight)
                                surface.DrawText(text)
                                AdminHeight = AdminHeight + H
                        end
                end
               
                local SpecWidest = 0
                local SpecTotalHeight = 0
                local SpecHeight = AdminTotalHeight + 50
                if TestNewPrivateDumpV1.Misc.Vars["ShowSpectators"]:GetBool() then
                        for k,v in pairs(TestNewPrivateDumpV1.Spectators) do
                                local W, H = surface.GetTextSize(v:Nick())
                                if W > SpecWidest then
                                        SpecWidest = W
                                end
                                SpecTotalHeight = SpecTotalHeight + H
                        end
                        draw.RoundedBox(8, ScrW() - SpecWidest - 30, 40 + AdminTotalHeight, SpecWidest + 20, SpecTotalHeight + 20, Color(0, 0, 0, 150 ))
                        for k,v in pairs(TestNewPrivateDumpV1.Spectators) do
                                local text = v:Nick()
                                local W, H = surface.GetTextSize(text)
                                surface.SetTextPos(ScrW() - 20 - SpecWidest, SpecHeight)
                                surface.DrawText(text)
                                SpecHeight = SpecHeight + H
                        end
                end
               
                if TestNewPrivateDumpV1.Misc.Vars["Crosshair"]:GetBool() then
                        local size = TestNewPrivateDumpV1.Misc.Vars["CrosshairSize"]:GetInt()
                        local MiddleScreen = {x = surface.ScreenWidth() / 2, y = surface.ScreenHeight() / 2}
                        surface.SetDrawColor(TestNewPrivateDumpV1.Style.Vars["Crosshair"].color)
                        surface.DrawLine(MiddleScreen.x, MiddleScreen.y, MiddleScreen.x - size, MiddleScreen.y)
                        surface.DrawLine(MiddleScreen.x, MiddleScreen.y, MiddleScreen.x, MiddleScreen.y - size)
                        surface.DrawLine(MiddleScreen.x, MiddleScreen.y, MiddleScreen.x + size, MiddleScreen.y)
                        surface.DrawLine(MiddleScreen.x, MiddleScreen.y, MiddleScreen.x, MiddleScreen.y + size)
                end
        end
end)
 
hook.Add("Think", TestNewPrivateDumpV1.RandomName(math.random(10, 15)), function()
        if TestNewPrivateDumpV1.Active:GetBool() then
                if TestNewPrivateDumpV1.Aimbot.Vars["Active"]:GetBool() and not (TestNewPrivateDumpV1.Aimbot.Vars["PanicMode"]:GetBool() and #TestNewPrivateDumpV1.Spectators > 0) then
                        if not TestNewPrivateDumpV1.Aimbot.Vars["AimOnKey"]:GetBool() or (TestNewPrivateDumpV1.Aimbot.Vars["AimOnKey"]:GetBool() and TestNewPrivateDumpV1.KeyPressed(TestNewPrivateDumpV1.Aimbot.Vars["AimOnKey_Key"]:GetString())) then
                                if TestNewPrivateDumpV1.ValidTarget() then
                                        local BoneOrder = {}
                                        if TestNewPrivateDumpV1.Aimbot.CurTarget.BoneToAimAt and TestNewPrivateDumpV1.Aimbot.Vars["RandomBones"]:GetBool() then
                                                table.insert(BoneOrder, TestNewPrivateDumpV1.Aimbot.CurTarget.BoneToAimAt)
                                                table.Add(BoneOrder, TestNewPrivateDumpV1.GetRandomBones())
                                                table.Add(BoneOrder, TestNewPrivateDumpV1.Bones)
                                        else
                                                if TestNewPrivateDumpV1.Aimbot.Vars["RandomBones"]:GetBool() then
                                                        table.Add(BoneOrder, TestNewPrivateDumpV1.GetRandomBones())
                                                        table.Add(BoneOrder, TestNewPrivateDumpV1.Bones)
                                                else
                                                        table.Add(BoneOrder, TestNewPrivateDumpV1.Bones)
                                                end
                                        end
                                        for k = 1, #BoneOrder do
                                                local v = BoneOrder[k]
                                                local bone = TestNewPrivateDumpV1.Aimbot.CurTarget:LookupBone(v)
                                                if bone != nil then
                                                        local pos, ang = TestNewPrivateDumpV1.Aimbot.CurTarget:GetBonePosition(bone)
                                                        if v == "ValveBiped.Bip01_Head1" then
                                                                pos = pos + Vector(0, 0, 3) //Aiming a little higher for the head
                                                        end
                                                        local total, needed = 300, {300, 300}
                                                       
                                                        if TestNewPrivateDumpV1.Aimbot.Vars["Prediction"]:GetBool() then
                                                                local tarSpeed = TestNewPrivateDumpV1.Aimbot.CurTarget:GetVelocity() * 0.013
                                                                local plySpeed = TestNewPrivateDumpV1.Ply:GetVelocity() * 0.013
                                                                total, needed = TestNewPrivateDumpV1.AngleTo(pos - plySpeed + tarSpeed)
                                                        else
                                                                total, needed = TestNewPrivateDumpV1.AngleTo(pos)
                                                        end
                                                               
                                                        if TestNewPrivateDumpV1.SpotIsVisible(pos) and total < TestNewPrivateDumpV1.Aimbot.Vars["MaxAngle"]:GetInt() then
                                                                local myAngles = TestNewPrivateDumpV1.Ply:GetAngles()                                                        
                                                                local NewAngles = Angle(myAngles.p + needed.p, myAngles.y + needed.y, 0)
                                                               
                                                                if TestNewPrivateDumpV1.Aimbot.Vars["AntiSnap"]:GetBool() then
                                                                        local speed = TestNewPrivateDumpV1.Aimbot.Vars["AntiSnapSpeed"]:GetInt()
                                                                        NewAngles = (Angle(math.Approach(myAngles.p, NewAngles.p, speed), math.Approach(myAngles.y, NewAngles.y, speed), 0))
                                                                end
                                                               
                                                                TestNewPrivateDumpV1.Ply:SetEyeAngles(NewAngles)
                                                                TestNewPrivateDumpV1.Aimbot.CurTarget.BoneToAimAt = BoneOrder[k]
                                                                break
                                                        end
                                                end
                                        end
                                else
                                        TestNewPrivateDumpV1.Aimbot.CurTarget = TestNewPrivateDumpV1.GetTarget()
                                end
                        else
                                TestNewPrivateDumpV1.Aimbot.CurTarget = nil
                        end
                end
               
                if TestNewPrivateDumpV1.Misc.Vars["NoRecoil"]:GetBool() then
                        if IsValid(TestNewPrivateDumpV1.Ply:GetActiveWeapon()) then
                                local weapon = TestNewPrivateDumpV1.Ply:GetActiveWeapon()
                                if weapon.Primary then
                                        weapon.OldRecoil = weapon.OldRecoil or weapon.Primary.Recoil or weapon.Recoil
                                        weapon.Primary.Recoil = 0
                                        weapon.Recoil = 0
                                else
                                        weapon.OldRecoil = weapon.OldRecoil or weapon.Recoil
                                        weapon.Recoil = 0
                                end
                        end
                elseif IsValid(TestNewPrivateDumpV1.Ply:GetActiveWeapon()) then
                        local weapon = TestNewPrivateDumpV1.Ply:GetActiveWeapon()
                        if weapon.Primary then
                                weapon.Primary.Recoil = weapon.OldRecoil or weapon.Primary.Recoil or weapon.Recoil
                                weapon.Recoil = weapon.OldRecoil or weapon.Recoil or weapon.Primary.Recoil
                        else
                                weapon.Recoil = weapon.OldRecoil or weapon.Recoil
                        end
                end
               
                if TestNewPrivateDumpV1.DarkRP and TestNewPrivateDumpV1.Misc.Vars["BuyHealth"]:GetBool() then
                        if TestNewPrivateDumpV1.Ply:Alive() and TestNewPrivateDumpV1.Ply:Health() < TestNewPrivateDumpV1.Misc.Vars["BuyHealth_Minimum"]:GetInt() then
                                TestNewPrivateDumpV1.Ply:ConCommand("say /buyhealth")
                        end
                end
        end
end)
 
TestNewPrivateDumpV1.Misc.NextReload = CurTime()
TestNewPrivateDumpV1.Misc.ShootNext = true
hook.Add("CreateMove", TestNewPrivateDumpV1.RandomName(math.random(10, 15)), function(cmd)
        if TestNewPrivateDumpV1.Active:GetBool() then        
                local DontShoot = {"gmod_tool", "gmod_camera", "weapon_physgun", "weapon_physcannon"}
                if TestNewPrivateDumpV1.Aimbot.Vars["AutoShoot"]:GetBool() and TestNewPrivateDumpV1.Aimbot.Vars["Active"]:GetBool() and TestNewPrivateDumpV1.Ply:GetEyeTrace().Entity == TestNewPrivateDumpV1.Aimbot.CurTarget and IsValid(TestNewPrivateDumpV1.Ply:GetActiveWeapon()) and not table.HasValue(DontShoot, TestNewPrivateDumpV1.Ply:GetActiveWeapon():GetClass()) then
                        cmd:SetButtons(cmd:GetButtons() + IN_ATTACK)
                end
               
                if TestNewPrivateDumpV1.Misc.Vars["BunnyHop"]:GetBool() and cmd:KeyDown(IN_JUMP) and TestNewPrivateDumpV1.KeyPressed(TestNewPrivateDumpV1.Misc.Vars["BunnyHop_Key"]:GetString()) then
                        cmd:SetButtons(cmd:GetButtons() - IN_JUMP)
                end
                if TestNewPrivateDumpV1.Misc.Vars["BunnyHop"]:GetBool() and TestNewPrivateDumpV1.Ply:OnGround() and TestNewPrivateDumpV1.KeyPressed(TestNewPrivateDumpV1.Misc.Vars["BunnyHop_Key"]:GetString()) then
                        cmd:SetButtons(cmd:GetButtons() + IN_JUMP)
                end
               
                local DontReload = {"gmod_tool", "gmod_camera", "weapon_physgun", "weapon_physcannon", "weapon_crowbar"}
                if TestNewPrivateDumpV1.Misc.Vars["AutoReload"]:GetBool() and IsValid(TestNewPrivateDumpV1.Ply:GetActiveWeapon()) and TestNewPrivateDumpV1.Ply:GetActiveWeapon():Clip1() < 1 and not table.HasValue(DontReload, TestNewPrivateDumpV1.Ply:GetActiveWeapon():GetClass()) and TestNewPrivateDumpV1.Misc.NextReload < CurTime() then
                        cmd:SetButtons(cmd:GetButtons() + IN_RELOAD)
                end
               
                if TestNewPrivateDumpV1.Misc.Vars["AutoPistol"]:GetBool() and IsValid(TestNewPrivateDumpV1.Ply:GetActiveWeapon()) then
                        local weapon = TestNewPrivateDumpV1.Ply:GetActiveWeapon()
                        if weapon.Primary and type(weapon.Primary.Automatic) == "boolean" and not weapon.Primary.Automatic then
                                if cmd:KeyDown(IN_ATTACK) then
                                        if TestNewPrivateDumpV1.Misc.ShootNext then
                                                TestNewPrivateDumpV1.Misc.ShootNext = false
                                        else
                                                cmd:SetButtons(cmd:GetButtons() - IN_ATTACK)
                                                TestNewPrivateDumpV1.Misc.ShootNext = true
                                        end
                                end                                    
                        elseif type(weapon.Automatic) == "boolean" and not weapon.Automatic then
                                if cmd:KeyDown(IN_ATTACK) then
                                        if TestNewPrivateDumpV1.Misc.ShootNext then
                                                TestNewPrivateDumpV1.Misc.ShootNext = false
                                        else
                                                cmd:SetButtons(cmd:GetButtons() - IN_ATTACK)
                                                TestNewPrivateDumpV1.Misc.ShootNext = true
                                        end
                                end
                        end
                end
        end
end)
 
//Used to see if the player is typing in chat or not. Binds arent called when you're in chat.
TestNewPrivateDumpV1.InChat = false
hook.Add("StartChat", TestNewPrivateDumpV1.RandomName(math.random(10, 15)), function()
        TestNewPrivateDumpV1.InChat = true
end)
hook.Add("FinishChat", TestNewPrivateDumpV1.RandomName(math.random(10, 15)), function()
        TestNewPrivateDumpV1.InChat = false
end)
 
concommand.Add("TestNewPrivateDumpV1_Menu", function()
        //Im only using DColumnSheet because everyone used DPropertySheet. I just want to be different
        local main = vgui.Create("DFrame")
        main:SetSize(500,496)
        main:Center()
        main:SetTitle("")
        main:MakePopup()
        main:ShowCloseButton(false)
        main.Paint = function()
                draw.RoundedBox( 0, 0, 0, main:GetWide(), main:GetTall(), Color( 0, 0, 0, 150 ) )
        end
       
        local PanicButton = vgui.Create("DButton", main)
        PanicButton:SetSize(50, 20)
        PanicButton:SetPos(415, 3)
        local function Enable()
                PanicButton:SetText("Disable")
                PanicButton.DoClick = function()
                        PanicButton:SetText("Enable")
                        PanicButton.DoClick = Enable
                        TestNewPrivateDumpV1.Ply:ConCommand("TestNewPrivateDumpV1_Active 0")
                end
                TestNewPrivateDumpV1.Ply:ConCommand("TestNewPrivateDumpV1_Active 1")
        end
        local function Disable()
                PanicButton:SetText("Enable")
                PanicButton.DoClick = function()
                        PanicButton:SetText("Disable")
                        PanicButton.DoClick = Disable
                        TestNewPrivateDumpV1.Ply:ConCommand("TestNewPrivateDumpV1_Active 1")
                end
                TestNewPrivateDumpV1.Ply:ConCommand("TestNewPrivateDumpV1_Active 0")
        end
        if TestNewPrivateDumpV1.Active:GetBool() then
                PanicButton:SetText("Disable")
                PanicButton.DoClick = Disable
        else
                PanicButton:SetText("Enable")
                PanicButton.DoClick = Enable
        end
       
        local CloseButton = vgui.Create("DButton", main)
        CloseButton:SetSize(30, 20)
        CloseButton:SetPos(465, 3)
        CloseButton:SetText("X")
        CloseButton.DoClick = function()
                main:Close()
        end
       
        local title = vgui.Create("DLabel", main)
        title:SetColor(Color(255, 255, 255, 255))
        title:SetFont("TitleFont")
        title:SetText("TestNewPrivateDumpV1 - "..TestNewPrivateDumpV1.Version)
        title:SizeToContents()
        title:SetPos(main:GetWide() / 2 - title:GetWide() / 2,3)      
       
        ColumnSheet = vgui.Create("DColumnSheet",main)
        ColumnSheet:SetPos(5, 25)
        ColumnSheet:SetSize(500 ,465)
       
        local y = 40
        local function ToggleOption(name, parent, var)
                local Options = vgui.Create("DComboBox", parent)
                Options:SetSize(100, 20)
                Options:SetPos(parent:GetWide() * 0.75 - Options:GetWide() / 2, y)
                Options:AddChoice("Off", 0)
                Options:AddChoice("On", 1)
                Options.OnSelect = function(panel,index,value,data)
                        TestNewPrivateDumpV1.Ply:ConCommand(var.." "..data)
                end
                Options:SetText(Options:GetOptionText(GetConVar(var):GetInt() + 1))
               
                local text = vgui.Create("DLabel", parent)
                text:SetColor(Color(0, 0, 0, 255))
                text:SetFont("CatagoryText")
                text:SetText(name)
                text:SizeToContents()
                text:SetPos(parent:GetWide() / 4 - text:GetWide() / 2, y + Options:GetTall() / 2 - text:GetTall() / 2)
               
                y = y + Options:GetTall() + 20
        end
       
        local function SetKeyOption(name, parent, var)        
                local Options = vgui.Create("DButton", parent)
                Options:SetSize(100, 20)
                Options:SetPos(parent:GetWide() * 0.75 - Options:GetWide() / 2, y)
                Options:SetText(GetConVar(var):GetString())
                Options.DoClick = function()
                        Options:SetText("Press a key...")
                        Options.Think = function()
                                for k = 107, 111 do
                                        if input.IsMouseDown(k) then
                                                TestNewPrivateDumpV1.Ply:ConCommand(var.." "..TestNewPrivateDumpV1.MouseKeys[k])
                                                Options:SetText(TestNewPrivateDumpV1.MouseKeys[k])
                                                Options.Think = nil
                                        end
                                end
                               
                                for k = 0, 130 do
                                        if input.IsKeyDown(k) then
                                                TestNewPrivateDumpV1.Ply:ConCommand(var.." "..TestNewPrivateDumpV1.Keys[k])
                                                Options:SetText(TestNewPrivateDumpV1.Keys[k])
                                                Options.Think = nil
                                        end
                                end
                        end
                end
               
                local text = vgui.Create("DLabel", parent)
                text:SetColor(Color(0, 0, 0, 255))
                text:SetFont("CatagoryText")
                text:SetText(name)
                text:SizeToContents()
                text:SetPos(parent:GetWide() / 4 - text:GetWide() / 2, y + Options:GetTall() / 2 - text:GetTall() / 2)
               
                y = y + Options:GetTall() + 20
        end
       
        local function SetNumberOption(name, parent, var, min, max, decimals)          
                local Options = vgui.Create("DNumberWang", parent)
                Options:SetSize(100, 20)
                Options:SetPos(parent:GetWide() * 0.75 - Options:GetWide() / 2, y)
                Options:SetMin(min)
                Options:SetMax(max)
                Options:SetDecimals(decimals)
                Options:SetConVar(var)
               
                local text = vgui.Create("DLabel", parent)
                text:SetColor(Color(0, 0, 0, 255))
                text:SetFont("CatagoryText")
                text:SetText(name)
                text:SizeToContents()
                text:SetPos(parent:GetWide() / 4 - text:GetWide() / 2, y + Options:GetTall() / 2 - text:GetTall() / 2)
               
                y = y + Options:GetTall() + 20
        end
       
        local function MultiOption(name, parent, var, tab)            
                local Options = vgui.Create("DComboBox", parent)
                Options:SetSize(100, 20)
                Options:SetPos(parent:GetWide() * 0.75 - Options:GetWide() / 2, y)
                for i = 1, #tab do
                        Options:AddChoice(tab[i])
                end
                Options.OnSelect = function(panel,index,value,data)
                        TestNewPrivateDumpV1.Ply:ConCommand(var.." "..value)
                end
                Options:SetText(GetConVar(var):GetString())
               
                local text = vgui.Create("DLabel", parent)
                text:SetColor(Color(0, 0, 0, 255))
                text:SetFont("CatagoryText")
                text:SetText(name)
                text:SizeToContents()
                text:SetPos(parent:GetWide() / 4 - text:GetWide() / 2, y + Options:GetTall() / 2 - text:GetTall() / 2)
               
                y = y + Options:GetTall() + 20
        end
       
        //Starting the Aimbot panel
        local Aimbot = vgui.Create("DPanel")
        Aimbot:SetSize(379, 465)
        Aimbot.Paint = function()
                draw.RoundedBox( 0, 0, 0, Aimbot:GetWide(), Aimbot:GetTall(), Color( 240, 240, 240, 255 ) )
        end
       
        local title = vgui.Create("DLabel", Aimbot)
        title:SetColor(Color(0, 0, 0, 255))
        title:SetFont("CatagoryHeader")
        title:SetText("Aimbot")
        title:SizeToContents()
        title:SetPos(Aimbot:GetWide() / 2 - title:GetWide() / 2, 0)
       
        ToggleOption("Active", Aimbot, "TestNewPrivateDumpV1_Aimbot_Active")
        ToggleOption("Random Bones", Aimbot, "TestNewPrivateDumpV1_Aimbot_RandomBones")
        MultiOption("Preferance", Aimbot, "TestNewPrivateDumpV1_Aimbot_Preferance", {"Distance", "Angle"})    
        ToggleOption("Attack Players", Aimbot, "TestNewPrivateDumpV1_Aimbot_AttackPlayers")
        ToggleOption("Attack NPCs", Aimbot, "TestNewPrivateDumpV1_Aimbot_AttackNPCs")
        ToggleOption("Prediction", Aimbot, "TestNewPrivateDumpV1_Aimbot_Prediction")
        ToggleOption("Aim On Key", Aimbot, "TestNewPrivateDumpV1_Aimbot_AimOnKey")
        SetKeyOption("Key", Aimbot, "TestNewPrivateDumpV1_Aimbot_AimOnKey_Key")
        ToggleOption("Anti Snap", Aimbot, "TestNewPrivateDumpV1_Aimbot_AntiSnap")
        SetNumberOption("Anti Snap Speed", Aimbot, "TestNewPrivateDumpV1_Aimbot_AntiSnapSpeed", 1, 5, 2)
        SetNumberOption("Max Angle", Aimbot, "TestNewPrivateDumpV1_Aimbot_MaxAngle", 0, 270, 0)
        ToggleOption("Auto Shoot", Aimbot, "TestNewPrivateDumpV1_Aimbot_AutoShoot")
        ToggleOption("Panic Mode", Aimbot, "TestNewPrivateDumpV1_Aimbot_PanicMode")
        ToggleOption("Ignore Team", Aimbot, "TestNewPrivateDumpV1_Aimbot_IgnoreTeam")
       
        if y > 465 then
                Aimbot:SetTall(y)
        end
       
        //This is the best way i can find to add a scrollbar to the menu...
        AimbotList = vgui.Create( "DPanelList" )
        AimbotList:SetSize(379, 465)
        AimbotList:SetSpacing(0)
        AimbotList:EnableHorizontal(false)
        AimbotList:EnableVerticalScrollbar(true)
        AimbotList:AddItem(Aimbot)
       
        ColumnSheet:AddSheet("Aimbot", AimbotList, "icon16/application_xp_terminal.png")
       
        //Starting the Friends panel
        local FriendsPanel = vgui.Create("DPanel")
        FriendsPanel:SetSize(379, 465)
        FriendsPanel.Paint = function()
                draw.RoundedBox( 0, 0, 0, FriendsPanel:GetWide(), FriendsPanel:GetTall(), Color( 240, 240, 240, 255 ) )
        end
       
        local title = vgui.Create("DLabel", FriendsPanel)
        title:SetColor(Color(0, 0, 0, 255))
        title:SetFont("CatagoryHeader")
        title:SetText("Friends")
        title:SizeToContents()
        title:SetPos(FriendsPanel:GetWide() / 2 - title:GetWide() / 2, 3)
       
        local Friends = {}
        local Enemies = {}
       
        local players = player.GetAll()
        for k = 1, #players do
                local v = players[k]
                if v != TestNewPrivateDumpV1.Ply then
                        if table.HasValue(TestNewPrivateDumpV1.Friends.List, v:SteamID()) then
                                table.insert(Friends, v)
                        else
                                table.insert(Enemies, v)
                        end
                end
        end
       
        y = 40
        local EnemiesList = vgui.Create("DListView", FriendsPanel) //Need this up here so FriendsList can reference it.
        local FriendsList = vgui.Create("DListView", FriendsPanel)
        FriendsList:SetSize(150, 200)
        FriendsList:SetPos(FriendsPanel:GetWide() * 0.25 - FriendsList:GetWide() / 2, y)
        FriendsList:SetMultiSelect(false)
        FriendsList:AddColumn("Friends")
        for k = 1, #Friends do
                FriendsList:AddLine(Friends[k]:Nick())
        end
        FriendsList.DoDoubleClick = function(panel, index, line)
                table.insert(Enemies, Friends[index])
                table.remove(Friends, index)
               
                FriendsList:Clear()
                EnemiesList:Clear()
                for k = 1, #Friends do
                        FriendsList:AddLine(Friends[k]:Nick())
                end
                for k = 1, #Enemies do
                        EnemiesList:AddLine(Enemies[k]:Nick())
                end
               
                TestNewPrivateDumpV1.Friends.List = {}
                for k = 1, #Friends do
                        table.insert(TestNewPrivateDumpV1.Friends.List, Friends[k]:SteamID())
                end
                //TestNewPrivateDumpV1.SaveData()
        end
       
        EnemiesList:SetSize(150, 200)
        EnemiesList:SetPos(FriendsPanel:GetWide() * 0.75 - EnemiesList:GetWide() / 2, y)
        EnemiesList:SetMultiSelect(false)
        EnemiesList:AddColumn("Enemies")
        for k = 1, #Enemies do
                EnemiesList:AddLine(Enemies[k]:Nick())
        end
        EnemiesList.DoDoubleClick = function(panel, index, line)
                table.insert(Friends, Enemies[index])
                table.remove(Enemies, index)
               
                FriendsList:Clear()
                EnemiesList:Clear()
                for k = 1, #Friends do
                        FriendsList:AddLine(Friends[k]:Nick())
                end
                for k = 1, #Enemies do
                        EnemiesList:AddLine(Enemies[k]:Nick())
                end
               
                TestNewPrivateDumpV1.Friends.List = {}
                for k = 1, #Friends do
                        table.insert(TestNewPrivateDumpV1.Friends.List, Friends[k]:SteamID())
                end
                //TestNewPrivateDumpV1.SaveData()
        end
       
        y = y + EnemiesList:GetTall() + 20
        ToggleOption("Use", FriendsPanel, "TestNewPrivateDumpV1_Friends_Active")
        ToggleOption("Reverse", FriendsPanel, "TestNewPrivateDumpV1_Friends_Reverse")
       
        if y > 465 then
                FriendsPanel:SetTall(y)
        end
       
        local FriendsPanelList = vgui.Create( "DPanelList" )
        FriendsPanelList:SetSize(379, 465)
        FriendsPanelList:SetSpacing(0)
        FriendsPanelList:EnableHorizontal(false)
        FriendsPanelList:EnableVerticalScrollbar(true)
        FriendsPanelList:AddItem(FriendsPanel)
       
        ColumnSheet:AddSheet("Friends", FriendsPanelList, "icon16/group.png")
 
        //Starting the ESP panel
        local ESP = vgui.Create("DPanel")
        ESP:SetSize(379, 465)
        ESP.Paint = function()
                draw.RoundedBox( 0, 0, 0, ESP:GetWide(), ESP:GetTall(), Color( 240, 240, 240, 255 ) )
        end
       
        local title = vgui.Create("DLabel", ESP)
        title:SetColor(Color(0, 0, 0, 255))
        title:SetFont("CatagoryHeader")
        title:SetText("ESP")
        title:SizeToContents()
        title:SetPos(ESP:GetWide() / 2 - title:GetWide() / 2, 3)
       
        y = 40
        ToggleOption("Active", ESP, "TestNewPrivateDumpV1_ESP_Active")
        ToggleOption("Player Info", ESP, "TestNewPrivateDumpV1_ESP_Players")
        ToggleOption("NPC Info", ESP, "TestNewPrivateDumpV1_ESP_NPCs")
        MultiOption("Name", ESP, "TestNewPrivateDumpV1_ESP_Name", {"Off", "Above", "Below"})  
        MultiOption("Weapon", ESP, "TestNewPrivateDumpV1_ESP_Weapons", {"Off", "Above", "Below"})    
        MultiOption("Health", ESP, "TestNewPrivateDumpV1_ESP_Health", {"Off", "Above", "Below"})      
        MultiOption("Distance", ESP, "TestNewPrivateDumpV1_ESP_Distance", {"Off", "Above", "Below"})
        MultiOption("Show Traitors", ESP, "TestNewPrivateDumpV1_ESP_ShowTraitors", {"Off", "Above", "Below"})
        ToggleOption("Bounding Box", ESP, "TestNewPrivateDumpV1_ESP_Box")
        ToggleOption("Body Info", ESP, "TestNewPrivateDumpV1_ESP_Bodies")
        ToggleOption("2D Radar", ESP, "TestNewPrivateDumpV1_ESP_Radar")
        SetNumberOption("Radar Scale", ESP, "TestNewPrivateDumpV1_ESP_RadarScale", 1, 100, 0)
        SetNumberOption("Max Distance", ESP, "TestNewPrivateDumpV1_ESP_MaxDistance", 0, 8000, 0)
        ToggleOption("Team Based", ESP, "TestNewPrivateDumpV1_ESP_TeamBased")
       
        if y > 465 then
                ESP:SetTall(y)
        end
       
        ESPList = vgui.Create( "DPanelList" )
        ESPList:SetSize(379, 465)
        ESPList:SetSpacing(0)
        ESPList:EnableHorizontal(false)
        ESPList:EnableVerticalScrollbar(true)
        ESPList:AddItem(ESP)
       
        ColumnSheet:AddSheet("ESP", ESPList, "icon16/pencil.png")
       
        //Starting the Chams panel
        local Chams = vgui.Create("DPanel")
        Chams:SetSize(379, 465)
        Chams.Paint = function()
                draw.RoundedBox( 0, 0, 0, Chams:GetWide(), Chams:GetTall(), Color( 240, 240, 240, 255 ) )
        end
       
        local title = vgui.Create("DLabel", Chams)
        title:SetColor(Color(0, 0, 0, 255))
        title:SetFont("CatagoryHeader")
        title:SetText("Chams")
        title:SizeToContents()
        title:SetPos(Chams:GetWide() / 2 - title:GetWide() / 2, 3)
       
        y = 40
        ToggleOption("Active", Chams, "TestNewPrivateDumpV1_Chams_Active")
        ToggleOption("Draw Players", Chams, "TestNewPrivateDumpV1_Chams_Players")
        ToggleOption("Draw NPCs", Chams, "TestNewPrivateDumpV1_Chams_NPCs")
        ToggleOption("Draw Weapons", Chams, "TestNewPrivateDumpV1_Chams_Weapons")
        ToggleOption("Draw Bodies", Chams, "TestNewPrivateDumpV1_Chams_Bodies")
        ToggleOption("Team Based", Chams, "TestNewPrivateDumpV1_Chams_TeamBased")
        SetNumberOption("Max Distance", Chams, "TestNewPrivateDumpV1_Chams_MaxDistance", 0, 8000, 0)
       
        if y > 465 then
                Chams:SetTall(y)
        end
       
        ChamsList = vgui.Create( "DPanelList" )
        ChamsList:SetSize(379, 465)
        ChamsList:SetSpacing(0)
        ChamsList:EnableHorizontal(false)
        ChamsList:EnableVerticalScrollbar(true)
        ChamsList:AddItem(Chams)
       
        ColumnSheet:AddSheet("Chams", ChamsList, "icon16/eye.png")
       
        //Starting the Finder panel
        local Finder = vgui.Create("DPanel")
        Finder:SetSize(379, 465)
        Finder.Paint = function()
                draw.RoundedBox( 0, 0, 0, Finder:GetWide(), Finder:GetTall(), Color( 240, 240, 240, 255 ) )
        end
       
        local title = vgui.Create("DLabel", Finder)
        title:SetColor(Color(0, 0, 0, 255))
        title:SetFont("CatagoryHeader")
        title:SetText("Entity Finder")
        title:SizeToContents()
        title:SetPos(Finder:GetWide() / 2 - title:GetWide() / 2, 3)
       
        local ToShow = {}
        local Others = {}
       
        local All = ents.GetAll()
        for k = 1, #All do
                local v = All[k]
                if table.HasValue(TestNewPrivateDumpV1.Entities.List, v:GetClass()) then
                        if not table.HasValue(ToShow, v:GetClass()) then
                                table.insert(ToShow, v:GetClass())
                        end
                elseif not table.HasValue(Others, v:GetClass()) then
                        table.insert(Others, v:GetClass())
                end
        end
       
        y = 40
        local IgnoreList = vgui.Create("DListView", Finder) //Need this up here so ToShowList can reference it.
        local ToShowList = vgui.Create("DListView", Finder)
        ToShowList:SetSize(150, 200)
        ToShowList:SetPos(Finder:GetWide() * 0.25 - ToShowList:GetWide() / 2, y)
        ToShowList:SetMultiSelect(false)
        ToShowList:AddColumn("To Show")
        for k = 1, #ToShow do
                ToShowList:AddLine(ToShow[k])
        end
        ToShowList.DoDoubleClick = function(panel, index, line)
                table.insert(Others, ToShow[index])
                table.remove(ToShow, index)
               
                ToShowList:Clear()
                IgnoreList:Clear()
                for k = 1, #ToShow do
                        ToShowList:AddLine(ToShow[k])
                end
                for k = 1, #Others do
                        IgnoreList:AddLine(Others[k])
                end
               
                TestNewPrivateDumpV1.Entities.List = {}
                for k = 1, #ToShow do
                        table.insert(TestNewPrivateDumpV1.Entities.List, ToShow[k])
                end
                //TestNewPrivateDumpV1.SaveData()
        end
       
        IgnoreList:SetSize(150, 200)
        IgnoreList:SetPos(Finder:GetWide() * 0.75 - IgnoreList:GetWide() / 2, y)
        IgnoreList:SetMultiSelect(false)
        IgnoreList:AddColumn("Others")
        for k = 1, #Others do
                IgnoreList:AddLine(Others[k])
        end
        IgnoreList.DoDoubleClick = function(panel, index, line)
                table.insert(ToShow, Others[index])
                table.remove(Others, index)
               
                ToShowList:Clear()
                IgnoreList:Clear()
                for k = 1, #ToShow do
                        ToShowList:AddLine(ToShow[k])
                end
                for k = 1, #Others do
                        IgnoreList:AddLine(Others[k])
                end
               
                TestNewPrivateDumpV1.Entities.List = {}
                for k = 1, #ToShow do
                        table.insert(TestNewPrivateDumpV1.Entities.List, ToShow[k])
                end
                //TestNewPrivateDumpV1.SaveData()
        end
       
        y = y + IgnoreList:GetTall() + 20
        ToggleOption("Active", Finder, "TestNewPrivateDumpV1_Entities_Active")
       
        if y > 465 then
                Finder:SetTall(y)
        end
       
        local FinderList = vgui.Create( "DPanelList" )
        FinderList:SetSize(379, 465)
        FinderList:SetSpacing(0)
        FinderList:EnableHorizontal(false)
        FinderList:EnableVerticalScrollbar(true)
        FinderList:AddItem(Finder)
       
        ColumnSheet:AddSheet("Finder", FinderList, "icon16/magnifier.png")
       
        //Starting the Misc panel
        local Misc = vgui.Create("DPanel")
        Misc:SetSize(379, 465)
        Misc.Paint = function()
                draw.RoundedBox( 0, 0, 0, Misc:GetWide(), Misc:GetTall(), Color( 240, 240, 240, 255 ) )
        end
       
        local title = vgui.Create("DLabel", Misc)
        title:SetColor(Color(0, 0, 0, 255))
        title:SetFont("CatagoryHeader")
        title:SetText("Misc")
        title:SizeToContents()
        title:SetPos(Misc:GetWide() / 2 - title:GetWide() / 2, 3)
       
        y = 40
        ToggleOption("Show Admins", Misc, "TestNewPrivateDumpV1_Misc_ShowAdmins")
        ToggleOption("Crosshair", Misc, "TestNewPrivateDumpV1_Misc_Cross")
        SetNumberOption("Corsshair Size", Misc, "TestNewPrivateDumpV1_Misc_CrossSize", 0, 1000, 0)
        ToggleOption("No Recoil", Misc, "TestNewPrivateDumpV1_Misc_NoRecoil")
        ToggleOption("Spectators", Misc, "TestNewPrivateDumpV1_Misc_ShowSpectators")
        ToggleOption("Auto Reload", Misc, "TestNewPrivateDumpV1_Misc_AutoReload")
        ToggleOption("Bunny Hop", Misc, "TestNewPrivateDumpV1_Misc_BunnyHop")
        SetKeyOption("Key", Misc, "TestNewPrivateDumpV1_Misc_BunnyHop_Key")
        ToggleOption("Auto Pistol", Misc, "TestNewPrivateDumpV1_Misc_AutoPistol")
        ToggleOption("Buy Health", Misc, "TestNewPrivateDumpV1_Misc_BuyHealth")
        SetNumberOption("Minimum", Misc, "TestNewPrivateDumpV1_Misc_BuyHealth_Minimum", 0, 100, 0)
        ToggleOption("Traitor Finder", Misc, "TestNewPrivateDumpV1_Misc_TraitorFinder")
        ToggleOption("Show Deaths", Misc, "TestNewPrivateDumpV1_Misc_Deaths")
        ToggleOption("Sounds", Misc, "TestNewPrivateDumpV1_Misc_Sounds")
 
        if y > 465 then
                Misc:SetTall(y)
        end
       
        MiscList = vgui.Create( "DPanelList" )
        MiscList:SetSize(379, 465)
        MiscList:SetSpacing(0)
        MiscList:EnableHorizontal(false)
        MiscList:EnableVerticalScrollbar(true)
        MiscList:AddItem(Misc)
 
        ColumnSheet:AddSheet("Misc", MiscList, "icon16/package.png")
       
        local function ColorOption(name, parent, tab)
                local Options = vgui.Create("DColorMixer", parent)
                Options:SetSize(150, 100)
                Options:SetPos(parent:GetWide() * 0.75 - Options:GetWide() / 2, y)
                Options:SetColor(tab.color)//TestNewPrivateDumpV1.GetColorFromString(GetConVar(var):GetString()))
                Options:SetWangs(false)
                Options:SetPalette(false)
                Options.ValueChanged = function(panel, color)
                        TestNewPrivateDumpV1.Ply:ConCommand(tab.var:GetName().." ".."Color("..color.r..","..color.g..","..color.b..","..color.a..")")
                        tab.color = TestNewPrivateDumpV1.GetColorFromString(tab.var:GetString())
                end
               
                local text = vgui.Create("DLabel", parent)
                text:SetColor(Color(0, 0, 0, 255))
                text:SetFont("CatagoryText")
                text:SetText(name)
                text:SizeToContents()
                text:SetPos(parent:GetWide() / 4 - text:GetWide() / 2, y + Options:GetTall() / 2 - text:GetTall() / 2)
               
                y = y + Options:GetTall() + 10
        end
        //Starting the Style panel
        local Style = vgui.Create("DPanel")
        Style:SetSize(379, 465)
        Style.Paint = function()
                draw.RoundedBox( 0, 0, 0, Style:GetWide(), Style:GetTall(), Color( 240, 240, 240, 255 ) )
        end
       
        local title = vgui.Create("DLabel", Style)
        title:SetColor(Color(0, 0, 0, 255))
        title:SetFont("CatagoryHeader")
        title:SetText("Style")
        title:SizeToContents()
        title:SetPos(Style:GetWide() / 2 - title:GetWide() / 2, 3)
       
        y = 50
        ColorOption("Bounding Box", Style, TestNewPrivateDumpV1.Style.Vars["BoundingBox"])
        ColorOption("ESP Text", Style, TestNewPrivateDumpV1.Style.Vars["ESPText"])
        ColorOption("Crosshair", Style, TestNewPrivateDumpV1.Style.Vars["Crosshair"])
        ColorOption("TTT Body Text", Style, TestNewPrivateDumpV1.Style.Vars["BodyText"])
        ColorOption("Chams", Style, TestNewPrivateDumpV1.Style.Vars["Chams"])
        ColorOption("TTT Body Chams", Style, TestNewPrivateDumpV1.Style.Vars["BodyChams"])
       
        if y > 465 then
                Style:SetTall(y)
        end
       
        StyleList = vgui.Create( "DPanelList" )
        StyleList:SetSize(379, 465)
        StyleList:SetSpacing(0)
        StyleList:EnableHorizontal(false)
        StyleList:EnableVerticalScrollbar(true)
        StyleList:AddItem(Style)
       
        ColumnSheet:AddSheet("Style", StyleList, "icon16/color_wheel.png")
end)
 
 
//Just some fonts
surface.CreateFont("TitleFont", {font = "Arial", size = 20})
surface.CreateFont("CatagoryHeader", {font = "CloseCaption_Normal", size = 34})
surface.CreateFont("CatagoryText", {font = "CloseCaption_Normal", size = 28})
surface.CreateFont("ESPFont", {font = "CloseCaption_Normal", weight = 1000, size = 15})
 
--[[
        DPropertySheet - Slightly edited so it looks good.
--]]
local PANEL = {}
AccessorFunc( PANEL, "ActiveButton", "ActiveButton" )
 
--[[---------------------------------------------------------
Name: Init
-----------------------------------------------------------]]
function PANEL:Init()
        self.Navigation = vgui.Create( "DScrollPanel", self )
        self.Navigation:Dock( LEFT )
        self.Navigation:SetWidth( 100 )
        self.Navigation:DockMargin( 0, 0, 10, 0 )
 
        self.Content = vgui.Create( "Panel", self )
        self.Content:Dock( FILL )
 
        self.Items = {}
end
 
function PANEL:UseButtonOnlyStyle()
        self.ButtonOnly = true
end
 
--[[---------------------------------------------------------
Name: AddSheet
-----------------------------------------------------------]]
function PANEL:AddSheet( label, panel, material )
        if ( !IsValid( panel ) ) then return end
 
        local Sheet = {}
 
        if ( self.ButtonOnly ) then
                Sheet.Button = vgui.Create( "DImageButton", self.Navigation )
        else
                Sheet.Button = vgui.Create( "DButton", self.Navigation )
        end
        Sheet.Button:SetImage( material )
        Sheet.Button.Target = panel
        Sheet.Button:Dock( TOP )
        Sheet.Button:SetText( label )
        Sheet.Button:DockMargin( 0, 0, 0, 5 )
 
        Sheet.Button.DoClick = function ()
                self:SetActiveButton( Sheet.Button )
        end
 
        Sheet.Panel = panel
        Sheet.Panel:SetParent( self.Content )
        Sheet.Panel:SetVisible( false )
 
        if ( self.ButtonOnly ) then
                Sheet.Button:SizeToContents()
                Sheet.Button:SetColor( Color( 150, 150, 150, 255 ) )
        end
 
        table.insert( self.Items, Sheet )
 
        if ( !IsValid( self.ActiveButton ) ) then
                self:SetActiveButton( Sheet.Button )
        end
end
 
--[[---------------------------------------------------------
Name: SetActiveTab
-----------------------------------------------------------]]
function PANEL:SetActiveButton( active )
        if ( self.ActiveButton == active ) then return end
 
        if ( self.ActiveButton && self.ActiveButton.Target ) then      
                self.ActiveButton.Target:SetVisible( false )
                self.ActiveButton:SetSelected( false )
                self.ActiveButton:SetColor( Color( 0, 0, 0, 255 ) )
        end
        self.ActiveButton = active
        active.Target:SetVisible( true )
        active:SetSelected( true )
        active:SetColor( Color( 150, 150, 150, 255 ) )
 
        self.Content:InvalidateLayout()
end
 
derma.DefineControl( "DColumnSheet", "", PANEL, "Panel" )
 
TestNewPrivateDumpV1.Message("Hack Loaded")