--[[
	lua/hemihack.lua
	Kinderknacht | (STEAM_0:0:50357078)
	===DStream===
]]

/*Hemi Hacks by: Hemirox*/

require( "hemihack" )

local cvars = require ( "cvars" )
local shouldload = CreateClientConVar( "hh_shouldload", "0", true, false )

local DermaPanel = vgui.Create( "DFrame" )
DermaPanel:SetPos( ScrW() - 200, ScrH() / 2 )
DermaPanel:SetSize( 150, 50 )
DermaPanel:SetTitle( "" )
DermaPanel:SetVisible( true )
DermaPanel:SetDraggable( false )
DermaPanel:ShowCloseButton( false )
DermaPanel:MakePopup()
DermaPanel.Paint = function()
    draw.RoundedBoxEx( 6, 0 , 0, DermaPanel:GetWide(), DermaPanel:GetTall(), Color( 145, 10, 10, 255 ), true, true, true, true )
	draw.SimpleText( "HemiHack Loader v2.1", "defaultsmall", 10, 2, Color( 200, 200, 200, 255 ), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER )
end
 
local CheckBoxThing = vgui.Create( "DCheckBoxLabel", DermaPanel )
CheckBoxThing:SetPos( 10, 25 )
CheckBoxThing:SetText( "Load Hemi Hack" )
CheckBoxThing:SetConVar( "hh_shouldload" )
CheckBoxThing:SizeToContents()