-- note by paradox: He said it was NCMD but I can say that I have never seen this script ever before.

--[[
	> File stolen by <
		 ________  _______   ________   ________  ___  ___  ___  ________   ________
		|\   __  \|\  ___ \ |\   ___  \|\   ____\|\  \|\  \|\  \|\   ___  \|\   ____\
		\ \  \|\  \ \   __/|\ \  \\ \  \ \  \___|\ \  \\\  \ \  \ \  \\ \  \ \  \___|_
		 \ \   ____\ \  \_|/_\ \  \\ \  \ \  \  __\ \  \\\  \ \  \ \  \\ \  \ \_____  \
		  \ \  \___|\ \  \_|\ \ \  \\ \  \ \  \|\  \ \  \\\  \ \  \ \  \\ \  \|____|\  \
		   \ \__\    \ \_______\ \__\\ \__\ \_______\ \_______\ \__\ \__\\ \__\____\_\  \
			\|__|     \|_______|\|__| \|__|\|_______|\|_______|\|__|\|__| \|__|\_________\
																			  \|_________|

	> Server IP: 23.247.169.1_27015 <
	> File Path: [C] <
]]

--no ultrah nooooo! pleas dont do this!!
local cmd = cmd
local sets = {}
local think = {}
local hudpaint = {}
local createmove = {}
local renderscreenspaceeffects = {}
local ohooks = {}
local abs = math.abs
local sqrt = math.sqrt
local bolt_velocity_air = 2500
local bolt_velocity_water = 1500
local project_slice_time = engine.TickInterval()
local ofuncs = {}
local friends = {}
local binds = {}
local bindsdebug = {}
local debugmouse = false
local mainmenu_e = false
local me = LocalPlayer()
local type = type
local RunConsoleCommand = RunConsoleCommand
local IsValid = IsValid
local EyePos = EyePos
local EyeAngles = EyeAngles
local tostring = tostring
local Vector = Vector
local ScrW = ScrW
local ScrH = ScrH
local _R = debug.getregistry()
local SetColor = _R.Entity.SetColor
local GetColor = _R.Entity.GetColor
local SetMaterial = _R.Entity.SetMaterial
local GetMaterial = _R.Entity.GetMaterial
local GetClass = _R.Entity.GetClass
local GetRagdollEntity = _R.Player.GetRagdollEntity
local SetNoDraw = _R.Entity.SetNoDraw
local GetVelocity = _R.Entity.GetVelocity
local string = string
local util = util
local math = math
local draw = draw
local render = render
local hook = hook
local cam = cam
local table = table
local player = player
local ents = ents
local team = team
local concommand = concommand
local cvars = cvars
local debug = debug
local ents = ents
local file = file
local hook = hook
local math = math
local input = input
local spawnmenu = spawnmenu
local string = string
local surface = surface
local table = table
local timer = timer
local util = util
local vgui = vgui
local Angle = Angle
local CreateClientConVar = CreateClientConVar
local CurTime = CurTime
local ErrorNoHalt = ErrorNoHalt
local FrameTime = FrameTime
local GetConVarString = GetConVarString
local GetViewEntity = GetViewEntity
local include = include
local ipairs = ipairs
local pairs = pairs
local pcall = pcall
local print = print
local RunConsoleCommand = RunConsoleCommand
local ScrH = ScrH
local ScrW = ScrW
local tonumber = tonumber
local type = type
local IsValid = IsValid

ohooks.renderscreenspaceeffects = GAMEMODE.RenderScreenspaceEffects
ohooks.hudpaint = GAMEMODE.HUDPaint
ohooks.think = GAMEMODE.Think
ohooks.calcview = GAMEMODE.CalcView
ohooks.createmove = GAMEMODE.CreateMove
ohooks.drawphysgunbeam = GAMEMODE.DrawPhysgunBeam
ohooks.predrawhalos = GAMEMODE.PreDrawHalos
ohooks.renderscene = GAMEMODE.RenderScene
ohooks.predrawviewmodel = GAMEMODE.PreDrawViewModel
ohooks.predraweffects = GAMEMODE.PreDrawEffects
ohooks.shoulddrawlocalplayer = GAMEMODE.ShouldDrawLocalPlayer
ohooks.predrawplayerhands = GAMEMODE.PreDrawPlayerHands
ohooks.postdrawviewmodel = GAMEMODE.PostDrawViewmodel
ohooks.drawoverlay = GAMEMODE.DrawOverlay

ofuncs.setviewangles = FindMetaTable( "CUserCmd" ).SetViewAngles
ofuncs.clearbuttons = FindMetaTable( "CUserCmd" ).ClearButtons
ofuncs.clearmovement = FindMetaTable( "CUserCmd" ).ClearMovement
ofuncs.hookremoveing = hook.Remove
ofuncs.hookcalling = hook.Call
ofuncs.onet = net
ofuncs.filefind = file.Find
ofuncs.fileread = file.Read
ofuncs.fileexists = file.Exists

local ropes = {
   "particle/tinyfiresprites/tinyfiresprites",
   "particle/water/watersplash_001a_additive",
   "particle/antlion_goop3/antlion_goop3",
   "vgui/gfx/vgui/solid_background",
   "sprites/white",
   "sprites/physcannon_bluecore1",
   "pp/texturize",
   "pp/colour",
   "pp/toytown-top",
   "sprites/autoaim_1a",
   "katharsmodels/contraband/contraband_two",
   "particle/droplets/droplets",
   "pp/sunbeams",
   "pp/bloom",
}

sets[ "target" ] = nil
sets[ "lastprop" ] = nil
sets[ "currprop" ] = nil

sets[ "physcolordef" ] = Vector( 1, 1, 1 )
sets[ "aim_view" ] = Angle()
sets[ "spinnan" ] = Angle()
sets[ "debug_spectator" ] = false
sets[ "debugxray" ] = false
sets[ "lastoption" ] = ""

sets[ "aimbot" ] = {}
sets[ "movement" ] = {}
sets[ "spam" ] = {}
sets[ "render" ] = {}
sets[ "debug" ] = {}

sets[ "aimbot" ][ "active" ] = true
sets[ "aimbot" ][ "triggerbot" ] = false
sets[ "aimbot" ][ "silent" ] = true
sets[ "aimbot" ][ "crossbow" ] = false
sets[ "aimbot" ][ "method" ] = 0
sets[ "aimbot" ][ "bots" ] = true
sets[ "aimbot" ][ "key2fire" ] = KEY_F
sets[ "aimbot" ][ "autofire" ] = false
sets[ "aimbot" ][ "crossbowlines" ] = false
sets[ "aimbot" ][ "debugpacketmin" ] = 0
sets[ "aimbot" ][ "debugpacketLimit" ] = 14
sets[ "aimbot" ][ "bspenable" ] = false
sets[ "aimbot" ][ "packetvar" ] = 2
sets[ "aimbot" ][ "debugpacketkey" ] = KEY_G

sets[ "debug" ][ "deleteweapons" ] = false
sets[ "debug" ][ "targetfriends" ] = true
sets[ "debug" ][ "deleteents" ] = false

sets[ "movement" ][ "bhopper" ] = true
sets[ "movement" ][ "showspeed" ] = true
sets[ "movement" ][ "spinbot_speed" ] = 10
sets[ "movement" ][ "actiontoggle" ] = false
sets[ "movement" ][ "propcam" ] = false
sets[ "movement" ][ "mirrorcam" ] = false
sets[ "movement" ][ "antiaim_method" ] = 1
sets[ "movement" ][ "antiaim_PITCH" ] = 0
sets[ "movement" ][ "antiaim_YAW" ] = 0
sets[ "movement" ][ "antiaim" ] = false
sets[ "movement" ][ "fakeduck" ] = false

sets[ "spam" ][ "rope" ] = true
sets[ "spam" ][ "rapidfire" ] = true
sets[ "spam" ][ "autopistol" ] = true
sets[ "spam" ][ "meme" ] = false
sets[ "spam" ][ "autism" ] = false

sets[ "render" ][ "tracers" ] = true
sets[ "render" ][ "halos" ] = true
sets[ "render" ][ "dormant" ] = true
sets[ "render" ][ "boxes" ] = false
sets[ "render" ][ "bones" ] = false
sets[ "render" ][ "xray" ] = true
sets[ "render" ][ "thirdperson" ] = false
sets[ "render" ][ "wireframe" ] = true
sets[ "render" ][ "tesp" ] = true
sets[ "render" ][ "tname" ] = true
sets[ "render" ][ "tadmin" ] = false
sets[ "render" ][ "thp" ] = true
sets[ "render" ][ "twep" ] = false
sets[ "render" ][ "fullbright" ] = false
sets[ "render" ][ "money" ] = false
sets[ "render" ][ "fov" ] = 100
sets[ "render" ][ "nohands" ] = true
sets[ "render" ][ "physoverride" ] = true
sets[ "render" ][ "physcolor" ] = Vector( 1, 0, 1 )
sets[ "render" ][ "wireframecolor" ] = Vector( 1, 0, 1 )
sets[ "render" ][ "playerbeams" ] = false

surface.CreateFont( "FONT1", {
   font = "Tahoma",
   size = 15,
   weight = 700,
   antialias = false
} )

surface.CreateFont( "FONT2", {
   font  = "Roboto",
   size  = 45,
   weight   = 600,
   antialias   = 1,
} )

if not file.Find( "noob.txt", "DATA" ) then
file.Write( "noob.txt", util.TableToJSON( sets ) )
end

if isstring( file.Read( "noob.txt", "DATA" ) ) then
local filedata = util.JSONToTable( tostring( file.Read( "noob.txt", "DATA" ) ) )
for i, v in pairs( sets ) do
if istable( v ) then
for i2, v2 in pairs( v ) do
if filedata[ i ][ i2 ] == nil then
filedata[ i ][ i2 ] = v2
MsgC( Color( 255, 255, 0 ), "Setting ", Color( 255, 155, 0 ), i2, Color( 255, 255, 0 ), " was nil, repaired.\n" )
end
end
else
if filedata[ i ] == nil then
filedata[ i ] = v
MsgC( Color( 255, 255, 0 ), "Setting " .. i .. " was nil, repaired.\n" )
end
end
end
file.Write( "noob.txt", util.TableToJSON( filedata ) )
sets = filedata
else
MsgC( Color( 255, 0, 0 ), "Error reading cheat settings.\n" )
end
MsgC( Color( 0, 255, 0 ),"cheat loaded ,, have fun , ", me:Nick() , " :^) ")

if file.Exists( "cfg/cfg/gmcl_bsendpacket_win32.dll", "MOD" ) then
   require( "bSendPacket" )
else
   MsgC( Color( 255, 0, 0 ), "\n!bSP\n" )
end

FindMetaTable( "CUserCmd" ).SetViewAngles = function( cmd, ang )
local src = string.lower( debug.getinfo(2).short_src )
if string.find( src, "taunt_camera" ) then return
else
return ofuncs.setviewangles( cmd, ang )
end
end

FindMetaTable( "CUserCmd" ).ClearButtons = function( cmd )
local src = string.lower( debug.getinfo(2).short_src )
if string.find( src, "taunt_camera" ) then return
else
return functions.clearbuttons( cmd )
end
end

FindMetaTable( "CUserCmd" ).ClearMovement = function( cmd )
local src = string.lower( debug.getinfo(2).short_src )
if string.find( src, "taunt_camera" ) then return
else
return functions.clearmovemenet( cmd )
end
end

gameevent.Listen("entity_killed")
hook.Add("entity_killed", "", function(data)
 local att_index = data.entindex_attacker;
 local vic_index = data.entindex_killed;
 local memes = { "sit", "owned", "ez", "bad", "LOOL", "pwn", "get fucked", "easy"}
 if sets[ "spam" ][ "meme" ] and (vic_index != att_index && att_index == me:EntIndex()) then
 RunConsoleCommand("say", memes[ math.random( #memes ) ] )
end
end)

render.Capture = function()
surface.PlaySound( "ambient/alarms/klaxon1.wav" )
local src = string.lower( debug.getinfo(2).short_src )
local files, dirs = ofuncs.oldfind( "ASG/*", "DATA" )
local rand = randomTab( files )
print( "[" .. src .. "] is trying to capture screen, deploying counter measures. (" .. rand .. ")" )
return ofuncs.oldread( "ASG/" .. rand, "DATA" )
end

IsPlayingTaunt = function() return false end
system.HasFocus = function() return false end
render.CapturePixels = nil

local function addBind( key, action )
if binds[ key ] then
print( "bind for " .. tostring( key ) .. " already exists, overiding anyways." )
end
binds[ key ] = action
bindsdebug[ key ] = false
end

local function fixMovement( cmd )
local vec = Vector( cmd:GetForwardMove(), cmd:GetSideMove(), 0 )
local vel = math.sqrt( vec.x*vec.x + vec.y*vec.y )
local mang = vec:Angle()
local yaw = cmd:GetViewAngles().y - sets[ "aim_view" ].y + mang.y
if (((cmd:GetViewAngles().p+90)%360) > 180) then
yaw = 180 - yaw
end
yaw = ((yaw + 180)%360)-180;
cmd:SetForwardMove(math.cos(math.rad(yaw)) * vel)
cmd:SetSideMove(math.sin(math.rad(yaw)) * vel)
end

local function getFirePos( ent )
local eyes = ent:LookupAttachment( "eyes" )
if eyes ~= 0 then
eyes = ent:GetAttachment( eyes )
if eyes && eyes.Pos then
local trace = util.TraceLine( {
start = me:GetShootPos(),
endpos = eyes.Pos,
mask = 1174421507,
filter = {me, ent}
} )
if trace.Fraction == 1.0 then
return eyes.Pos
end
end
end
local pos = ent:LocalToWorld( ent:OBBCenter() )
local trace = util.TraceLine( {
start = me:GetShootPos(),
endpos = pos,
mask = 1174421507,
filter = {me, ent}
} )
if trace.Fraction == 1.0 then
return pos
end
end

local function normalizeAngle( ang )
ang.x = math.NormalizeAngle( ang.x )
ang.p = math.Clamp( ang.p, -89, 89 )
return ang
end

local function getWeapon( ent )
local wep = ent:GetActiveWeapon()
if ( wep:IsValid() ) then
return wep
else
return false
end
end

local function shouldFire( b )
local wep = getWeapon( me )
local camera = b && "gmod_camera" or ""
local weps = {
"weapon_physgun",
"gmod_tool",
camera,
"h&&s",
"none",
"pocket",
"inventory",
"weapon_physcannon",
"weapon_vape_mega",
"weapon_vape_dragon",
}
if me:Alive() && wep then
wep = wep:GetClass()
for k, v in pairs( weps ) do
if wep == v then return false end
end
return true
end
return false
end

local function clearnFire( cmd, key )
cmd:SetViewAngles( sets[ "aim_view" ] )
cmd:RemoveKey( key )
cmd:SetButtons(cmd:GetButtons() + key )
end

function fixView( cmd )
if sets[ "currprop" ] and input.IsKeyDown( KEY_E ) then return end
if not sets[ "aim_view" ] then sets[ "aim_view" ] = cmd:GetViewAngles( cmd ) end
sets[ "aim_view" ] = sets[ "aim_view" ] + Angle( cmd:GetMouseY() * .023, cmd:GetMouseX() * -.023, 0 )
sets[ "aim_view" ] = normalizeAngle( sets[ "aim_view" ] )
if cmd:CommandNumber() == 0 then
cmd:SetViewAngles( sets[ "aim_view" ] )
return
end
end

local function getClosestPROX()
local dists = {}
local found = false
for _, v in pairs( player.GetAll() ) do
if not v:Alive() or v == me or not getFirePos( v ) or friends[ v:SteamID() ] == true or v:IsDormant() or ( not sets[ "aimbot" ][ "bots" ] and v:IsBot() ) then continue end
found = true
table.insert( dists, { v, v:GetPos():Distance( me:GetPos() ) } ) end
table.sort( dists, function( a, b ) return a[ 2 ] < b[ 2 ] end )
if found == false then return nil end
return dists[ 1 ][ 1 ]
end

local function getClosestFOV()
local dist = 0
local pos = nil
local targ = nil
for k, v in pairs( player.GetAll() ) do
if not v:Alive() or v == me or not getFirePos(v) or friends[ v:SteamID() ] == true or v:IsDormant()or ( not sets[ "aimbot" ][ "bots" ] and v:IsBot() ) then continue end
local pos = getFirePos(v):ToScreen()
local vec = (Vector(pos.x, pos.y) - Vector(ScrW() / 2, ScrH() / 2)):Length2D()
if dist < vec && targ ~= nil then continue end
dist = vec
targ = v
end
return targ
end

local function predtest(pos, target)
    local lply, lpos, lvel = LocalPlayer(), LocalPlayer():GetPos(), LocalPlayer():GetAbsVelocity()
    local tpos, tvel = target:GetPos(), target:GetVelocity()
    local v0 = 3500 -- inital velocity
    if target:IsValid() and pos then
        local dist = tpos:Distance( lpos )
        local comptime = lply:Ping()/1000 -- Ping() sucks balls
        local t = (dist / v0) + comptime
        local final = pos + (tvel * t)
        return final
    end
    return pos
end

local function uninterpolate(pos, trg)
    pos = trg:GetNetworkOrigin() + (pos-trg:GetPos())
    return pos
end

local function aimbot( cmd )
if ( not cmd:CommandNumber() or not ( input.IsKeyDown( sets[ "aimbot" ][ "key2fire" ] ) or sets[ "aimbot" ][ "autofire" ] ) ) or ( not sets[ "aimbot" ][ "autofire" ] and vgui.GetKeyboardFocus() ~= nil ) or ( not sets[ "aimbot" ][ "autofire" ] and gui.IsConsoleVisible() ) or not shouldFire() or not me:GetActiveWeapon():IsValid() or not sets[ "aimbot" ][ "active" ] then sets[ "target" ] = nil return end
if not sets[ "aimbot" ][ "method" ] then targ = getClosestPROX() else targ = getClosestFOV() end
if not IsEntity( targ ) then sets[ "target" ] = nil return end
sets[ "target" ] = targ
local firepos = getFirePos( targ )
local centerpos = uninterpolate(targ:LocalToWorld(targ:OBBCenter()), targ)
if firepos == nil then return end
local shootpos = ( me:GetShootPos() + me:GetAbsVelocity() * engine.TickInterval() )
if not firepos or not shootpos or not centerpos then return end
local predpos = Either(sets[ "aimbot" ][ "crossbow" ], predtest(centerpos, targ), firepos)
debugoverlay.Line(shootpos, predpos, 0.1, Color(255,0,0), true )
local ang = (predpos - shootpos):Angle()
ang = normalizeAngle( ang )
cmd:SetViewAngles( ang )
if sets[ "aimbot" ][ "silent" ] then
fixMovement( cmd )
else
sets[ "aim_view" ] = ang
end
if sets[ "aimbot" ][ "triggerbot" ] then
cmd:SetButtons( cmd:GetButtons() + 1 )
end
end

local function mainmenu()
mainmenu_e = true

local function checkbox( name, val, cat, parent, tooltip )
local checkbox = vgui.Create( "DCheckBoxLabel", parent )
checkbox:SetText( name )
checkbox:SetTextColor( Color( 255, 255, 255 ) )
checkbox:DockMargin( 0, 0, 0, 2 )
checkbox:Dock( TOP )
if isstring( cat ) then
checkbox:SetChecked( sets[ cat ][ val ] )
else
checkbox:SetChecked( sets[ val ] )
end
if isstring( tooltip ) then
checkbox:SetTooltip( tooltip )
end

function checkbox:OnChange()
if isstring( cat ) then
sets[ cat ][ val ] = self:GetChecked()
else
sets[ val ] = self:GetChecked()
end
file.Write( "noob.txt", util.TableToJSON( sets ) )
end
function checkbox:PaintOver()
draw.RoundedBox( 0, 0, 0, 15, 15, Color( 0, 0, 0 ) )
if checkbox:GetChecked() then
draw.RoundedBox( 0, 4, 4, 7.5, 7.5, Color( 100, 0, 0 ) )
end
end
end

local function button( text, parent, x, y, x2, y2, func)
local button = vgui.Create( "DButton", parent )
button:SetPos( x, y )
button:SetSize( x2, y2 )
button:SetText( text )
button.DoClick = func
function button:Paint()
draw.RoundedBox( 0, 0, 0, self:GetWide(), self:GetTall(), Color( 155, 155, 155 ) )
end
end

local function paintButton( button, x, y, active )
if active == button then
surface.SetDrawColor( Color( 255, 155, 155 ) )
else
if button:IsHovered() then
surface.SetDrawColor( Color( 155, 155, 155 ) )
else
surface.SetDrawColor( Color( 105, 105, 105 ) )
end
end
surface.DrawRect( 0, 0, x, y )
surface.SetFont( "FONT1" )
surface.SetTextColor( Color( 255, 255, 255 ) )
local width, height = surface.GetTextSize( button:GetText() )
surface.SetTextPos( x / 2 - ( width / 1.875), y / 2 - ( height / 1.875 ) )
surface.DrawText( button:GetText() )
end

local function paintListView( list )
function list:Paint()
surface.SetDrawColor( Color( 50, 50, 50 ) )
surface.DrawRect( 0, 0, self:GetWide(), self:GetTall() )
end

function list.VBar:Paint()
surface.SetDrawColor( Color( 60, 60, 60 ) )
surface.DrawRect( 0, 0, self:GetWide(), self:GetTall() )
end

function list.VBar.btnGrip:Paint()
surface.SetDrawColor( Color( 100, 50, 50 ) )
surface.DrawRect( 0, 0, self:GetWide(), self:GetTall() )

surface.SetDrawColor( Color( 200, 0, 0 ) )
surface.DrawOutlinedRect( 0, 0, self:GetWide(), self:GetTall() )
end

function list.VBar.btnUp:Paint()
surface.SetDrawColor( Color( 100, 100, 100 ) )
surface.DrawRect( 0, 0, self:GetWide(), self:GetTall() )
end

function list.VBar.btnDown:Paint()
surface.SetDrawColor( Color( 100, 100, 100 ) )
surface.DrawRect( 0, 0, self:GetWide(), self:GetTall() )
end

for k, v in pairs( list.Columns ) do
function v.Header:Paint()
surface.SetDrawColor( Color( 155, 105, 105 ) )
surface.DrawRect( 2.5, 0, self:GetWide() - 5, self:GetTall() )
self:SetTextColor( Color( 255, 255, 255 ) )
end
end
end

local frame = vgui.Create( "DFrame" )
frame:SetSize( 550, 350 )
frame:Center()
frame:MakePopup()
frame:ShowCloseButton( false )
frame:SetTitle( ":^)" )
function frame:Paint()
draw.RoundedBoxEx( 5, 0, 0, self:GetWide(), 25, Color( 50, 50, 50 ), true, true )
draw.RoundedBox( 0, 0, 25, self:GetWide(), self:GetTall() - 25, Color( 65, 65, 65 ) )
end

local cbutton = vgui.Create( "DButton", frame )
cbutton:SetText( "" )
cbutton:SetSize( 15, 15 )
cbutton:SetPos( frame:GetWide() - cbutton:GetWide() - 5, 12.5 - ( cbutton:GetTall() - 7 ) )
function cbutton:DoClick()
frame:Close()
mainmenu_e = false
end
function cbutton:Paint()
draw.RoundedBox( 5, 0, 0, self:GetWide(), self:GetTall(), Color( 255, 150, 150) )
end

local tabs = {}
tabs["Rendering"] = vgui.Create( "DPanel", options )
tabs["Movement"] = vgui.Create( "DPanel", options )
tabs["Aimbot"] = vgui.Create( "DPanel", options )
tabs["Spam"] = vgui.Create( "DPanel", options )
tabs["Hook List"] = vgui.Create( "DPanel", options )
tabs["Friends"] = vgui.Create( "DPanel", options )
tabs["Sliders"] = vgui.Create( "DPanel", options )

local options = vgui.Create( "DColumnSheet", frame )
options:Dock( FILL )

function options:Paint()
surface.SetDrawColor( Color( 50, 50, 50 ) )
surface.DrawRect( 0, 0, self:GetWide() ,self:GetTall() )
end

for i, v in pairs( tabs ) do
v:Dock( FILL )
options:AddSheet( i, v )

v:DockPadding( 3, 3, 3, 3 )

function v:Paint()
surface.SetDrawColor( Color( 50, 50, 50 ) )
surface.DrawRect( 0, 0, self:GetWide(), self:GetTall() )
surface.SetDrawColor( Color( 230, 230, 230 ) )
surface.DrawOutlinedRect( 0, 0, self:GetWide(), self:GetTall() )
end
end

for k, v in pairs( options.Navigation.pnlCanvas:GetChildren() ) do
if v:GetText() == sets[ "lastoption" ] then
options:SetActiveButton( v )
end

local doclick = v.DoClick

function v:DoClick()
doclick()
sets[ "lastoption" ] = options:GetActiveButton():GetText()
end

function v:PaintOver()
paintButton( self, self:GetWide(), self:GetTall(), options.ActiveButton )
end
end

local unload = vgui.Create( "DButton", frame )
unload:SetSize( 100, 22 )
unload:SetPos( 15, frame:GetTall() - 32 )
unload:SetText( "Unload" )

function unload:PaintOver()
paintButton( self, self:GetWide(), self:GetTall() )
end

function unload:DoClick()
bSendPacket = true
GAMEMODE.HUDPaint = ohooks.hudpaint
GAMEMODE.CreateMove = ohooks.createmove
GAMEMODE.Think = ohooks.think
GAMEMODE.DrawPhysgunBeam = ohooks.drawphysgunbeam
GAMEMODE.RenderScene = ohooks.renderscene
GAMEMODE.PostDrawViewmodel = ohooks.postdrawviewmodel
GAMEMODE.PreDrawEffects = ohooks.predraweffects
GAMEMODE.PreDrawHalos = ohooks.predrawhalos
GAMEMODE.CalcView = ohooks.calcview
GAMEMODE.PreDrawViewModel = ohooks.predrawviewmodel
GAMEMODE.ShouldDrawLocalPlayer = ohooks.shoulddrawlocalplayer
GAMEMODE.PreDrawPlayerHands = ohooks.predrawplayerhands
GAMEMODE.RenderScreenspaceEffects = ohooks.renderscreenspaceeffects
hook.Remove("entity_killed", "")
frame:Close()
end

local spawnmenufix = vgui.Create( "DImageButton", frame )
spawnmenufix:SetSize( 20, 20 )
spawnmenufix:SetPos( 15, frame:GetTall() - 65    )
spawnmenufix:SetText( "" )
spawnmenufix:SetTooltip( "Reset Spawn Menu" )
spawnmenufix:SetIcon( "icon16/application_view_tile.png")

function spawnmenufix:DoClick()
for k, v in pairs(debug.getregistry()) do
if ispanel(v) and v.GetSkin and v.SetSkin then v:SetSkin("Default") end
end
end

local crash = vgui.Create( "DImageButton", frame )
crash:SetSize( 20, 20 )
crash:SetPos( 40, frame:GetTall() - 65     )
crash:SetText( "" )
crash:SetTooltip( "Epic crashan" )
crash:SetIcon( "icon16/cancel.png")

function crash:DoClick()
for i = 0, 200 do
RunConsoleCommand( "gm_spawn", "models/props_c17/gate_door02a.mdl" )
end
end

local rejoinan = vgui.Create( "DImageButton", frame )
rejoinan:SetSize( 20, 20 )
rejoinan:SetPos(  65 , frame:GetTall() - 65   )
rejoinan:SetText( "" )
rejoinan:SetTooltip( "Rejoin the server" )
rejoinan:SetIcon( "icon16/arrow_refresh.png" )

function rejoinan:DoClick()
RunConsoleCommand( "retry" )
end

local sudoku = vgui.Create( "DImageButton", frame )
sudoku:SetSize( 20, 20 )
sudoku:SetPos(  90 , frame:GetTall() - 65     )
sudoku:SetText( "" )
sudoku:SetTooltip( "kill urself noob" )
sudoku:SetIcon( "icon16/bomb.png" )

function sudoku:DoClick()
RunConsoleCommand( "kill" )
end

local grooving = {
[1] = {"dance", 1},
[2] = {"laugh", 1},
[3] = {"agree", 1},
[4] = {"cheer", 1},
[5] = {"robot", 1},
[6] = {"zombie", 1},
[7] = {"wave", 1},
[8] = {"pers", 1},
[9] = {"muscle", 1},
}
local selected = ""
local dancebox = vgui.Create("DComboBox", tabs[ "Movement" ])
dancebox:SetSize(100, 20)
dancebox:SetPos( 3 , frame:GetTall() - 60  )
dancebox:SetValue( "Actions" )
for k, v in pairs(grooving) do
dancebox:AddChoice(v[1])
timer.Create(v[1], v[2], 0, function()
if sets[ "movement" ][ "actiontoggle" ] == true and v[1] == selected then RunConsoleCommand("act", v[1]) end
end)
end
dancebox.OnSelect = function( _, _, val)
selected = val
end
local startdance = vgui.Create( "DImageButton", tabs[ "Movement" ] )
startdance:SetSize( 20, 20 )
startdance:SetPos(  110 , frame:GetTall() - 60  )
startdance:SetText( "" )
startdance:SetTooltip( "Start" )
startdance:SetIcon( "icon16/tick.png" )
function startdance:DoClick()
sets[ "movement" ][ "actiontoggle" ] = true
end
local cleardance = vgui.Create( "DImageButton", tabs[ "Movement" ] )
cleardance:SetSize( 20, 20 )
cleardance:SetPos(  135 , frame:GetTall() - 60  )
cleardance:SetText( "" )
cleardance:SetTooltip( "Stop" )
cleardance:SetIcon( "icon16/cross.png" )
function cleardance:DoClick()
sets[ "movement" ][ "actiontoggle" ] = false
end

checkbox( "Aimbot", "active", "aimbot", tabs[ "Aimbot" ] )
checkbox( "Triggerbot", "triggerbot", "aimbot", tabs[ "Aimbot" ] )
checkbox( "FOV Aim (Defaults to proximity)", "method", "aimbot", tabs[ "Aimbot"] )
checkbox( "Silent", "silent", "aimbot", tabs[ "Aimbot" ] )
checkbox( "crossbow pred", "crossbow", "aimbot", tabs[ "Aimbot" ] )
checkbox( "Target bots", "bots", "aimbot", tabs[ "Aimbot" ] )
checkbox( "Auto Fire", "autofire", "aimbot", tabs[ "Aimbot" ] )
checkbox( "Crossbow Lines", "crossbowlines", "aimbot", tabs[ "Aimbot" ] )

checkbox( "Rapid fire", "rapidfire", "spam", tabs[ "Spam" ] )
checkbox( "Auto pistol", "autopistol", "spam", tabs[ "Spam" ] )
checkbox( "Rope spam", "rope", "spam", tabs[ "Spam" ] )
checkbox( "Chat kill taunt", "meme", "spam", tabs[ "Spam" ] )
checkbox( "Watermark", "autism", "spam", tabs[ "Spam" ])

checkbox( "Bunny hop", "bhopper", "movement", tabs[ "Movement" ] )
checkbox( "Speedometer", "showspeed", "movement", tabs[ "Movement" ] )
checkbox( "Spinbot", "spinbot", "movement", tabs[ "Movement" ] )
checkbox( "Delete entities", "deleteents", "movement", tabs[ "Movement" ] )
checkbox( "Anti-aim", "antiaim", "movement", tabs[ "Movement" ] )
checkbox( "Fake duck", "fakeduck", "movement", tabs[ "Movement" ] )
checkbox( "Fake lag" , "bspenable", "aimbot", tabs[ "Movement" ] )
checkbox( "Prop camera", "propcam", "movement", tabs[ "Movement" ] )
checkbox( "Mirror camera", "mirrorcam", "movement", tabs[ "Movement" ] )

checkbox( "Third person", "thirdperson", "render", tabs[ "Rendering" ] )
checkbox( "ESP enabled", "tesp", "render", tabs[ "Rendering" ] )
checkbox( "ESP health", "thp", "render", tabs[ "Rendering" ] )
checkbox( "ESP weapon", "twep", "render", tabs[ "Rendering" ] )
checkbox( "ESP name", "tname", "render", tabs[ "Rendering" ] )
checkbox( "ESP IsAdmin", "tadmin", "render", tabs[ "Rendering" ] )
checkbox( "3D Boxes", "boxes", "render", tabs[ "Rendering" ] )
checkbox( "Tracers", "tracers", "render", tabs[ "Rendering" ] )
checkbox( "Halos", "halos", "render", tabs[ "Rendering" ] )
checkbox( "XRay", "xray", "render", tabs[ "Rendering" ] )
checkbox( "Bones", "bones", "render", tabs[ "Rendering" ] )
checkbox( "Full bright", "fullbright", "render", tabs[ "Rendering" ] )
checkbox( "Show money", "money", "render", tabs[ "Rendering" ] )
checkbox( "Wireframe", "wireframe", "render", tabs[ "Rendering" ] )
checkbox( "No hands", "nohands", "render", tabs[ "Rendering" ] )
checkbox( "Physgun override", "physoverride", "render", tabs[ "Rendering" ] )
checkbox( "Eye Beams", "eyebeams", "render", tabs[ "Rendering" ] )

local hooklist = vgui.Create( "DListView", tabs[ "Hook List" ] )
hooklist:Dock( FILL )
hooklist:AddColumn( "Type" )
hooklist:AddColumn( "Name" )
paintListView( hooklist )

local function refreshHooks()
hooklist:Clear()
for htype, hooks in pairs( hook.GetTable() ) do
if !istable(hooks) then continue end
for hname, _ in pairs( hooks ) do
htype = tostring( htype )
hname = tostring( hname )
hooklist:AddLine( htype, hname )
end
end
for _, line in pairs( hooklist.Lines ) do

function line:Paint()
if line:IsHovered() then
surface.SetDrawColor( Color( 100, 100, 100 ) )
else
surface.SetDrawColor( Color( 50, 50, 50 ) )
end
surface.DrawRect( 0, 0, self:GetWide(), self:GetTall() )
end
for _, column in pairs( line.Columns ) do
column:SetTextColor( Color( 255, 255, 255 ) )
end
end
end

function hooklist:OnRowSelected()
for k, v in pairs( hooklist:GetSelected() ) do
local htype = tostring( v:GetValue( 1 ) )
local hname = tostring( v:GetValue( 2 ) )
hook.Remove( htype, hname )
end
refreshHooks()
end
refreshHooks()
local friendslist = vgui.Create( "DListView", tabs[ "Friends" ] )
friendslist:Dock( FILL )
friendslist:AddColumn( "Player" )
friendslist:AddColumn( "Steam ID" )
friendslist:AddColumn( "Is friend" )
paintListView( friendslist )

local function updateFriends()
friendslist:Clear()
for k, v in pairs( player.GetAll() ) do
if v == me or v:IsBot() then continue end
if friends[ v:SteamID() ] == true then
friendslist:AddLine( v:Nick(), v:SteamID(), "true")
else
friendslist:AddLine( v:Nick(), v:SteamID(), "false")
end
end
for _, line in pairs( friendslist.Lines ) do

function line:Paint()
if self:IsHovered() then
surface.SetDrawColor( Color( 100, 100, 100 ) )
else
surface.SetDrawColor( Color( 50, 50, 50 ) )
end
surface.DrawRect( 0, 0, self:GetWide(), self:GetTall() )
end
for _, column in pairs( line.Columns ) do
column:SetTextColor( Color( 255, 255, 255 ) )
end
end
end
updateFriends()

function friendslist:OnRowSelected()
local line = self:GetLine( self:GetSelectedLine() ):GetValue( 2 )
friends[ line ] = not friends[ line ]
updateFriends()
end

local phyrslider = vgui.Create( "DNumSlider", tabs[ "Sliders" ] )
phyrslider:SetMin( 0 )
phyrslider:SetMax( 1 )
phyrslider:SetText( "Physgun red" )
phyrslider:Dock( TOP )
phyrslider:SetValue( sets[ "render" ][ "physcolor" ].x )
function phyrslider:OnValueChanged( number )
sets[ "render" ][ "physcolor" ].x = number
end
local phygslider = vgui.Create( "DNumSlider", tabs[ "Sliders" ] )
phygslider:SetMin( 0 )
phygslider:SetMax( 1 )
phygslider:SetText( "Physgun green" )
phygslider:Dock( TOP )
phygslider:SetValue( sets[ "render" ][ "physcolor" ].y )
function phygslider:OnValueChanged( number )
sets[ "render" ][ "physcolor" ].y = number
end
local phybslider = vgui.Create( "DNumSlider", tabs[ "Sliders" ] )
phybslider:SetMin( 0 )
phybslider:SetMax( 1 )
phybslider:SetText( "Physgun blue" )
phybslider:Dock( TOP )
phybslider:SetValue( sets[ "render" ][ "physcolor" ].z )
function phybslider:OnValueChanged( number )
sets[ "render" ][ "physcolor" ].z = number
end
local wfrslider = vgui.Create( "DNumSlider", tabs[ "Sliders" ] )
wfrslider:SetMin( 0 )
wfrslider:SetMax( 255 )
wfrslider:SetText( "Wireframe red" )
wfrslider:Dock( TOP )
wfrslider:SetValue( sets[ "render" ][ "wireframecolor" ].x )
function wfrslider:OnValueChanged( number )
sets[ "render" ][ "wireframecolor" ].x = number
end
local wfgslider = vgui.Create( "DNumSlider", tabs[ "Sliders" ] )
wfgslider:SetMin( 0 )
wfgslider:SetMax( 255 )
wfgslider:SetText( "Wireframe green" )
wfgslider:Dock( TOP )
wfgslider:SetValue( sets[ "render" ][ "wireframecolor" ].y )
function wfgslider:OnValueChanged( number )
sets[ "render" ][ "wireframecolor" ].y = number
end
local wfbslider = vgui.Create( "DNumSlider", tabs[ "Sliders" ] )
wfbslider:SetMin( 0 )
wfbslider:SetMax( 255 )
wfbslider:SetText( "Wireframe blue" )
wfbslider:Dock( TOP )
wfbslider:SetValue( sets[ "render" ][ "wireframecolor" ].z )
function wfbslider:OnValueChanged( number )
sets[ "render" ][ "wireframecolor" ].z = number
end
local fovslider = vgui.Create( "DNumSlider", tabs[ "Sliders" ] )
fovslider:SetMin( 0 )
fovslider:SetMax( 200 )
fovslider:SetText( "FOV" )
fovslider:Dock( TOP )
fovslider:SetValue( sets[ "render" ][ "fov" ] )
function fovslider:OnValueChanged( number )
sets[ "render" ][ "fov" ] = number
end
local packetslider = vgui.Create( "DNumSlider", tabs[ "Movement" ] )
packetslider:SetMin( 0 )
packetslider:SetMax( 14 )
packetslider:SetText( "Fakelag amount" )
packetslider:Dock( TOP )
packetslider:SetValue( sets["aimbot"]["packetvar"] )
function packetslider:OnValueChanged( number )
sets["aimbot"]["packetvar"] = number
end
local spinslider = vgui.Create( "DNumSlider", tabs[ "Movement" ] )
spinslider:SetMin( -10 )
spinslider:SetMax( 10 )
spinslider:SetText( "Spinbot Speed" )
spinslider:Dock( TOP )
spinslider:SetValue( sets[ "movement" ][ "spinbot_speed" ] )
function spinslider:OnValueChanged( number )
sets[ "movement" ][ "spinbot_speed" ] = number
end
local Yawaimslider = vgui.Create( "DNumSlider", tabs[ "Movement" ] )
Yawaimslider:SetMin( -270 )
Yawaimslider:SetMax( 270 )
Yawaimslider:SetText( "Antiaim Yaw" )
Yawaimslider:Dock( TOP )
Yawaimslider:SetValue( sets[ "movement" ][ "antiaim_YAW" ] )
function Yawaimslider:OnValueChanged( number )
sets[ "movement" ][ "antiaim_YAW" ] = number
end
local Pitchaimslider = vgui.Create( "DNumSlider", tabs[ "Movement" ] )
Pitchaimslider:SetMin( -80 )
Pitchaimslider:SetMax( 80 )
Pitchaimslider:SetText( "Antiaim Pitch" )
Pitchaimslider:Dock( TOP )
Pitchaimslider:SetValue( sets[ "movement" ][ "antiaim_PITCH" ] )
function Pitchaimslider:OnValueChanged( number )
sets[ "movement" ][ "antiaim_PITCH" ] = number
end
local aimselect = vgui.Create( "DComboBox", tabs[ "Movement" ] )
aimselect:SetPos( 315 , frame:GetTall() - 60  )
aimselect:SetSize(100, 20)
aimselect:SetValue( "Antiaim Method")
aimselect:AddChoice( "Fixed" )
aimselect:AddChoice( "Reverse" )
aimselect:AddChoice( "Jitter" )
aimselect:AddChoice( "Dynamic Jitter" )
aimselect.OnSelect = function( _, i )
if i == 1 then sets[ "movement" ][ "antiaim_method" ] = 1
elseif i == 2 then sets[ "movement" ][ "antiaim_method" ] = 2
elseif i == 3 then sets[ "movement" ][ "antiaim_method" ] = 3
elseif i == 4 then sets[ "movement" ][ "antiaim_method" ] = 4
end
end

end --menu end

local x, y = ScrW()/2, ScrH()/2
local xspeed, yspeed = 2, 2
function hudpaint.autism()
   if not sets["spam"]["autism"] then return end
   local col = HSVToColor(  ( CurTime() * 100) % 360, 1, 1 )
   x = x + xspeed
   y = y + yspeed
   if x + 45 > ScrW() or (x == 0) then 
      xspeed = xspeed * -1 
   end
   if y + 45 > ScrH() or (y == 0) then 
      yspeed = yspeed * -1
   end
   draw.SimpleText(":^)", "FONT2", x, y, Color( col.r, col.g, col.b))
end

function hudpaint.tracers()
if not sets[ "render" ][ "tracers" ] then return end
for k, v in pairs( player.GetAll() ) do
if not v:IsValid() or v == me or not v:Alive() then continue end
cam.Start3D()
local vpos = v:GetPos():ToScreen()
cam.End3D()
if vpos.y > 2000 or vpos.y < -2000 then continue end
if vpos.x > 2000 or vpos.x < -2000 then continue end
if v:IsBot() then 
surface.SetDrawColor(160, 32, 240)
elseif friends[ v:SteamID() ] == true then
surface.SetDrawColor(0, 255, 0)
elseif v:IsAdmin() or v:IsSuperAdmin() then
surface.SetDrawColor(255, 255, 255)
else
surface.SetDrawColor(255, 0, 0)
end
surface.DrawLine(ScrW() / 2, ScrH() / 1, vpos.x , vpos.y)
end
end

function hudpaint.playerbeams()
if not sets[ "render" ][ "eyebeams" ] then return end
for k, v in pairs( player.GetAll() ) do
if not v:IsValid() or v == me or not v:Alive() then continue end
local pos = v:GetShootPos()
local hitpos = v:GetEyeTrace().HitPos
if v:GetEyeTrace().Entity == me then
noobcolor = Color(255, 0, 0)
draw.SimpleText( "O.O " .. v:GetName(), "DermaDefault", 10, 40, Color(255, 0, 0) )
else
noobcolor = Color(0, 255, 0)
end
cam.Start3D()
render.SetColorMaterial()
render.DrawBeam(pos, hitpos, 5, 1, 1, noobcolor )
cam.End3D()
end
end

function hudpaint.crossbowlines()
if sets[ "movement" ][ "antiaim" ] or not sets["aimbot"]["crossbowlines"] then return end
if (not me:GetActiveWeapon(me):IsValid() or me:GetActiveWeapon():GetClass() != "weapon_crossbow") then return end
local pos = me:GetShootPos()
local vel = me:GetAngles():Forward() * bolt_velocity_air
local accel = physenv.GetGravity() * 0.05
while (true) do
local nextpos = pos + (vel * project_slice_time)
local tracedata = {
start = pos,
endpos = nextpos,
filter = { me },
}
local traceresult = util.TraceLine(tracedata)
cam.Start3D()
if (traceresult.Fraction != 1) then
local hitpos = traceresult.HitPos
local hitdot = traceresult.HitNormal:Dot(-traceresult.Normal)
local speed = vel:Length()
if (hitdot < 0.5 and speed > 100) then
vel = (2.0 * traceresult.HitNormal * hitdot * speed + vel) * 0.75
accel = physenv.GetGravity() * 1
render.DrawLine(pos, hitpos, Color(255, 0, 0), true)
render.DrawWireframeSphere(hitpos, 3, 10, 10, Color(0, 255, 0), true)
pos = hitpos
cam.End3D()
else
local spherecolor
if (traceresult.Entity:IsPlayer()) then
spherecolor = Color(0, 0, 255)
else
spherecolor = Color(255, 0, 0)
end
render.DrawLine(pos, hitpos, Color(255, 0, 0), true)
render.DrawWireframeSphere(hitpos, 3, 10, 10, spherecolor, true)
cam.End3D()
break
end
else
vel = vel + (1/2 * accel * project_slice_time)
render.DrawLine(pos, nextpos, Color(255, 0, 0), true)
pos = nextpos
cam.End3D()
end
end
end

function hudpaint.boxes()
if not sets[ "render" ][ "boxes" ] then return end
for k, v in pairs( player.GetAll() ) do
if not v:IsValid() or v == me or not v:Alive() then continue end
local addon_crouch = v:Crouching() && 25 or 0
cam.Start3D()
render.DrawWireframeBox( v:GetPos(), Angle( 0, 0, 0 ), Vector( 20, 20, 0 ), Vector( -20, -20, 75 - addon_crouch ), Color( sets[ "render" ][ "wireframecolor" ].x, sets[ "render" ][ "wireframecolor" ].y, sets[ "render" ][ "wireframecolor" ].z ) )
cam.End3D()
end
end

function hudpaint.bones()
if not sets[ "render" ][ "bones" ] then return end
for i, v in pairs( player.GetAll() ) do
if not v:IsValid() or v == me or not v:Alive() then continue end
for i = 0, v:GetBoneCount() do
local parent = v:GetBoneParent( i )
local bonePos = v:GetBonePosition( i )
if not bonePos or not parent or bonePos == v:GetPos() or v == me then continue end
local parentPos = v:GetBonePosition( parent )
if not parentPos then continue end
local boneToScreen = { bonePos:ToScreen(), parentPos:ToScreen() }
surface.SetDrawColor( Color( sets[ "render" ][ "wireframecolor" ].x, sets[ "render" ][ "wireframecolor" ].y, sets[ "render" ][ "wireframecolor" ].z ) )
surface.DrawLine( boneToScreen[ 1 ].x, boneToScreen[ 1 ].y, boneToScreen[ 2 ].x, boneToScreen[ 2 ].y )
end
end
end

function hudpaint.tesp()
if not sets[ "render" ][ "tesp" ] then return end
for k, v in pairs( player.GetAll() ) do
if not v:IsValid() or not v:Alive() or v == me then continue end
local text = ""
local pos1 = v:GetPos()
local pos2 = pos1 + Vector( 0, 0, 75 )
local pos2d1 = pos1:ToScreen()
local pos2d2 = pos2:ToScreen()
if v == sets[ "target" ] then
draw.SimpleText( "[TARGET]", "FONT1", pos2d2.x, pos2d2.y - 13, Color( 255, 55, 55 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
elseif friends[ v:SteamID() ] == true then
draw.SimpleText( "[FRIEND]", "FONT1", pos2d2.x, pos2d2.y - 13, Color( 55, 255, 55 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
end

if sets[ "render" ][ "tname" ] then text = v:Nick() end

if sets[ "render" ][ "thp" ] then text = text .. " (" .. tostring( v:Health() ) .. ")" end
draw.SimpleTextOutlined( text, "FONT1", pos2d2.x, pos2d2.y, team.GetColor( v:Team() ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, Color( 0, 0, 0, 255 ) )

if sets[ "render" ][ "dormant" ] and v:IsDormant() then
draw.SimpleText( "[DORMANT]", "FONT1", pos2d2.x, pos2d2.y - 13, Color( 255, 0, 0 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
end
if sets[ "render" ][ "twep" ] and getWeapon( v ) then
draw.SimpleTextOutlined( getWeapon( v ):GetClass(), "FONT1", pos2d1.x, pos2d1.y, Color( 0, 255, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, Color( 0, 0, 0, 255 ) )
end
if sets[ "render" ][ "tadmin" ] and v:IsAdmin() or v:IsSuperAdmin() then
draw.SimpleText("faggot", "FONT1", pos2d1.x, pos2d1.y - 23, Color( 255, 255, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER  )
end
end
if not sets[ "render" ][ "money" ] then return end
for k, v  in pairs( ents.FindByClass( "spawned_money" ) ) do
draw.SimpleText( "spawned_money", "DermaDefault", v:GetPos():ToScreen().x, v:GetPos():ToScreen().y, Color( 0, 255, 0 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
end
end

function hudpaint.spectators() -- not reliable
local spectator = Color( 0, 255, 0 )
for i, v in pairs( player.GetAll() ) do
if v == me or v:GetObserverTarget() ~= me then continue end
local mode = v:GetObserverMode()
local mode2 = ""
if mode == 4 then mode2 = "First person"
elseif mode == 5 or mode == 3 then mode2 = "Third person"
elseif mode == 2 then mode2 = "Freeze cam" end
draw.SimpleText( v:Nick() .. " (" .. mode2 .. ")", "CloseCaption_Normal", 0, 120 + 20 * ( i - 1 ), Color( 255, 155, 0 ) )
spectator = Color( 255, 0, 0 )
end
if spectator == Color( 255, 0, 0 ) and not sets[ "debug_spectator" ] then
surface.PlaySound( "buttons/button16.wav" )
sets[ "debug_spectator" ] = true
elseif spectator == Color( 0, 255, 0 ) then
sets[ "debug_spectator" ] = false
end
draw.SimpleText( "-!-", "DermaLarge", 10, 10, spectator )
end

function hudpaint.xray()
for i, v in pairs( ents.FindByClass( "prop_physics" ) ) do
if sets[ "render" ][ "xray" ] and v:IsValid() and not v:IsDormant() then
cam.Start3D( EyePos(), EyeAngles())
cam.IgnoreZ( true )
render.SuppressEngineLighting( true )
render.SetBlend( 0.8 )
render.SetColorModulation((sets[ "render" ][ "wireframecolor" ].x)/255, (sets[ "render" ][ "wireframecolor" ].y)/255, (sets[ "render" ][ "wireframecolor" ].z)/255 )
v:DrawModel()
v:SetColor( ColorAlpha( v:GetColor(), 255 ) )
v:SetMaterial( "models/debug/debugwhite" )
render.MaterialOverride()
render.SuppressEngineLighting( false )
cam.IgnoreZ( false )
cam.End3D()
sets[ "debugxray" ] = false
elseif not sets[ "debugxray" ] then
v:SetColor( ColorAlpha( v:GetColor(), 255 ) )
v:SetMaterial( v:GetMaterial() )
if i == #ents.FindByClass( "prop_physics" ) then
sets[ "debugxray" ] = true
end
end
end
end

function hudpaint.mirrorcam1()
if sets[ "movement" ][ "spinbot" ] or sets[ "movement" ][ "antiaim" ] or not sets[ "movement" ][ "mirrorcam" ] then return end
local mirrorcamdata = {
w = 300,
h = 100,
x = (ScrW() / 2.5) + 30,
y = 15,
drawhud = false,
dopostprocess = false,
drawviewer = false,
}
mirrorcamdata.origin = me:EyePos()
mirrorcamdata.angles = Angle(0, me:EyeAngles().y - 180, 0)
render.RenderView( mirrorcamdata )
end

function hudpaint.propcam1()
if not sets[ "movement" ][ "propcam" ] or not IsValid( sets[ "lastprop" ] ) then return end
local propcamdata = {
w = 350,
h = 225,
x = ScrW() -400,
y = 10,
drawhud = false,
dopostprocess = false,
drawviewmodel = false,
}
propcamdata.origin = sets[ "lastprop" ]:LocalToWorld(sets[ "lastprop" ]:OBBCenter()) - (sets[ "aim_view" ]:Forward() * 72)
propcamdata.angles = sets[ "aim_view" ]
render.RenderView( propcamdata )
end

function hudpaint.showspeed()
if not sets[ "movement" ][ "showspeed" ] then return end
local speed = math.floor(me:GetVelocity():Length())
local col = Vector(255, 255, 255)
   if speed > 2500 then
      col = Vector(math.Rand( 0, 255 ), math.Rand( 0, 255 ), math.Rand( 0, 255 ))
   elseif speed > 1000 then
      col = HSVToColor(  ( CurTime() * 100) % 360, 1, 1 )
    end
   draw.SimpleTextOutlined(speed, "FONT1", (ScrW() / 2) - 20, ScrH() - ScrH() + 7, Color( col.r, col.g, col.b ), 5, 1, 1, Color(0, 0, 0) )
end

function createmove.fakeduck(cmd)
if not sets[ "movement" ][ "fakeduck" ] then return end
if (cmd:KeyDown(IN_DUCK) && !bSendPacket) then cmd:RemoveKey(IN_DUCK) end
end


function createmove.rapidfire( cmd )
local wep = getWeapon( me )
if me:KeyDown( IN_ATTACK ) and me:Alive() and sets[ "spam" ][ "rapidfire" ] then
if shouldFire() then
cmd:RemoveKey( IN_ATTACK )
elseif wep and sets[ "spam" ]["autopistol"] and wep:GetClass() == "gmod_tool" then
cmd:RemoveKey( IN_ATTACK )
end
end
end

function createmove.bhop( cmd )
if not sets[ "movement" ][ "bhopper" ] then return end
if ( input.IsKeyDown( sets[ "aimbot" ][ "key2fire" ] ) or sets[ "aimbot" ][ "autofire" ] or sets[ "movement" ][ "spinbot" ] or sets[ "movement" ][ "antiaim" ] or sets["movement"]["fakeduck"]) then 
   if not IsValid(me) or me:GetMoveType() == 8 or me:WaterLevel() == 3 or me:WaterLevel() == 2 or me:IsOnGround() then return end
   if cmd:KeyDown( IN_JUMP ) then cmd:RemoveKey( IN_JUMP ) end
else 
      if ( not me:OnGround() and cmd:KeyDown( IN_JUMP) ) then
      cmd:RemoveKey(IN_JUMP)
      if ( cmd:GetMouseX() > 1 or cmd:GetMouseX() < -1 ) then
         cmd:SetSideMove( cmd:GetMouseX() > 1 and 400 or -400)
      else
         cmd:SetSideMove((cmd:CommandNumber() % 2 == 0) and -400 or 400)
      end
   elseif (cmd:KeyDown(IN_JUMP)) then
      cmd:SetForwardMove(450)
   end
end
end

function createmove.ropespam( cmd )
if not me:Alive() or not getWeapon( me ) then return end
if not cmd:KeyDown( IN_ATTACK ) or getWeapon( me ):GetClass() ~= "gmod_tool" then return end
if me:GetTool() == nil then return end
if sets[ "spam" ][ "rope" ] && me:GetTool().Name == "#tool.rope.name" then
RunConsoleCommand( "rope_width", 5000 )
GetConVar( "rope_material" ):SetString( table.Random( ropes ) )
if rs_reverse == true then
rs = -rs
rs_reverse = false
else
rs = Angle( math.random( 80 ), math.random( 360 ), 0 )
rs_reverse = true
end
rs = normalizeAngle( rs )
cmd:SetViewAngles(rs)
fixMovement( cmd )
cmd:RemoveKey( IN_ATTACK )
cmd:SetButtons( cmd:GetButtons() + IN_ATTACK)
end
end

function createmove.spinbot( cmd )
if not sets[ "movement" ][ "spinbot" ] or ( ( input.IsKeyDown( sets[ "aimbot" ][ "key2fire" ] ) or sets[ "aimbot" ][ "autofire" ] ) and sets[ "target" ] ~= nil ) then return end
if cmd:KeyDown( IN_ATTACK ) then
clearnFire( cmd, IN_ATTACK ) return
end
if cmd:KeyDown( IN_USE ) then
clearnFire( cmd, IN_USE ) return
end
if cmd:KeyDown( 32 ) or me:WaterLevel() > 1 or me:GetMoveType() == MOVETYPE_LADDER or me:GetMoveType() == MOVETYPE_NOCLIP or not me:Alive() then return end
local sp = ( CurTime() * (sets[ "movement" ][ "spinbot_speed" ]) *50 ) %360, 0
sets.spinnan = Angle( sets[ "aim_view" ].p, sp, 0 )
sets.spinnan = normalizeAngle( sets.spinnan )
cmd:SetViewAngles( sets.spinnan )
fixMovement( cmd )
end


function createmove.antiaim( cmd )
if not sets[ "movement" ][ "antiaim" ] or sets[ "movement" ][ "spinbot" ] or ( ( input.IsKeyDown( sets[ "aimbot" ][ "key2fire" ] ) or sets[ "aimbot" ][ "autofire" ] ) and sets[ "target" ] ~= nil ) then return end
if cmd:KeyDown( IN_ATTACK ) then
clearnFire( cmd, IN_ATTACK ) return
end
if cmd:KeyDown( IN_USE ) then
clearnFire( cmd, IN_USE ) return
end
if cmd:KeyDown( 32 ) or me:WaterLevel() > 1 or me:GetMoveType() == MOVETYPE_LADDER or me:GetMoveType() == MOVETYPE_NOCLIP or not me:Alive() then return end
if (sets[ "movement" ][ "antiaim_method" ] == 1) then
sets.aang = Angle( sets[ "movement" ][ "antiaim_PITCH" ], sets[ "movement" ][ "antiaim_YAW" ], 0)
sets.aang = normalizeAngle( sets.aang )
cmd:SetViewAngles(sets.aang)
fixMovement( cmd )
elseif (sets[ "movement" ][ "antiaim_method" ] == 2) then
sets.aang = Angle(math.NormalizeAngle(sets[ "aim_view" ].p ),  math.NormalizeAngle(sets[ "aim_view" ].y + 180 ), 0)
sets.aang = normalizeAngle( sets.aang )
cmd:SetViewAngles(sets.aang)
fixMovement( cmd )
elseif (sets[ "movement" ][ "antiaim_method" ] == 3) then
sets.aang = Angle(math.random(-sets[ "movement" ][ "antiaim_PITCH" ], sets[ "movement" ][ "antiaim_PITCH" ]), math.random(-sets[ "movement" ][ "antiaim_YAW" ], sets[ "movement" ][ "antiaim_YAW" ]), 0)
sets.aang = normalizeAngle( sets.aang )
cmd:SetViewAngles(sets.aang)
fixMovement( cmd )
elseif (sets[ "movement" ][ "antiaim_method" ] == 4) then
sets.aang = Angle(math.NormalizeAngle(sets[ "aim_view" ].p + math.random(-sets[ "movement" ][ "antiaim_PITCH" ], sets[ "movement" ][ "antiaim_PITCH" ])),  math.NormalizeAngle(sets[ "aim_view" ].y + math.random(-sets[ "movement" ][ "antiaim_YAW" ], sets[ "movement" ][ "antiaim_YAW" ]) ), 0)
sets.aang = normalizeAngle( sets.aang )
cmd:SetViewAngles(sets.aang)
fixMovement( cmd )
end
end

function createmove.fakelag( cmd )
if sets["aimbot"]["bspenable"] then
if cmd:CommandNumber( cmd ) ~= 0 then
if sets["aimbot"]["debugpacketmin"] >=  sets["aimbot"]["packetvar"] then
sets["aimbot"]["debugpacketmin"] = 0
bSendPacket = true
else
sets["aimbot"]["debugpacketmin"] =  sets["aimbot"]["debugpacketmin"] + 1
bSendPacket = false
end
end
else
bSendPacket = true
end
end

function think.binds()
for i, v in pairs( binds ) do
if input.IsKeyDown( i ) and not bindsdebug[ i ] then
v()
bindsdebug[ i ] = true
elseif not input.IsKeyDown( i ) then
bindsdebug[ i ] = false
end
end
end

function think.colors()
for k, v in pairs( player.GetAll() ) do
if friends[ v:SteamID() ] == true then
v:SetWeaponColor( Vector( 0, 1, 0 ) )
elseif v ~= me then
v:SetWeaponColor( Vector( 1, 0, 0 ) )
end
if sets[ "render" ][ "physoverride" ] then
v:SetWeaponColor( sets[ "render" ][ "physcolor" ] )
else
v:SetWeaponColor( sets[ "physcolordef" ] )
end
end
end

function menucheck()
if mainmenu_e == true then return end
mainmenu()
end

addBind( KEY_INSERT, menucheck)

addBind( KEY_DELETE, function()
for i, v in pairs( ents.GetAll() ) do
if v:IsWorld() or v:IsWeapon() then continue end
net.Start( "properties" )
net.WriteString( "remove" , 32 )
net.WriteEntity( v )
net.SendToServer()
end
end)

timer.Create( "", 1, 0, function()
if sets[ "movement" ][ "deleteents" ] then
for i, v in pairs( ents.GetAll() ) do
if v:IsWorld() or v:IsWeapon() then continue end
net.Start( "properties" )
net.WriteString( "remove" , 32 )
net.WriteEntity( v )
net.SendToServer()
end
end
end)

function GAMEMODE.RenderScreenspaceEffects( gm )
for k, v in pairs( renderscreenspaceeffects) do v() end
return ohooks.renderscreenspaceeffects( gm )
end

function GAMEMODE.HUDPaint( gm )
for k, v in pairs( hudpaint ) do
v()
end
ohooks.hudpaint( gm )
end

function GAMEMODE.CreateMove( gm, cmd )
if me:InVehicle() then return end
fixView( cmd )
aimbot( cmd )
for k, v in pairs( createmove ) do
v( cmd )
end
ohooks.createmove( gm, cmd )
end

function GAMEMODE.Think( gm )
ohooks.think( gm )
for k, v in pairs( think ) do
v()
end
end

function GAMEMODE.DrawPhysgunBeam( gm, ply, physgun, enabled, target, bone, hitpos )
if enabled and IsValid( target ) and ply == me then
sets[ "currprop" ] = target
else
sets[ "currprop" ] = nil
end
if ply == me and IsValid( target ) then
sets[ "lastprop" ] = target
end
return ohooks.drawphysgunbeam( gm, ply, physgun, enabled, target, bone, hitpos )
end

function GAMEMODE.RenderScene( gm, vec, ang, fov )
ohooks.renderscene( gm, vec, ang, fov )
render.SetLightingMode( sets[ "render" ][ "fullbright" ] and 1 or 0 )
end

function GAMEMODE.PostDrawViewmodel( gm, ent, ply, wep )
ohooks.postdrawvewmodel( gm, ent, ply, wep )
render.SetLightingMode(0)
end

function GAMEMODE.PreDrawEffects( gm )
ohooks.predraweffects( gm )
render.SetLightingMode(0)
end

function GAMEMODE.PreDrawHalos( gm )
ohooks.predrawhalos( gm )
if not sets[ "render" ][ "halos" ] then return end
halo.Add( player.GetAll(), Color( sets[ "render" ][ "wireframecolor" ].x, sets[ "render" ][ "wireframecolor" ].y, sets[ "render" ][ "wireframecolor" ].z ), 2, 2, 1, true, true )
end

function GAMEMODE.CalcView( gm, ply, origin, angles, fov )
local view = {}
if not me:InVehicle() then
view.angles = sets[ "aim_view" ]
view.origin = sets[ "render" ][ "thirdperson" ] and origin - ( sets[ "aim_view" ]:Forward() * 100 ) or origin
view.fov = sets[ "render" ][ "fov" ]
return view
end
return ohooks.calcview( gm, ply, origin, angles, fov )
end

function GAMEMODE.PreDrawViewModel( _, _, _, wep )
if not sets[ "render" ][ "wireframe" ] or not IsValid( wep ) then return end
render.MaterialOverride( Material("models/wireframe") )
render.SetColorModulation((sets[ "render" ][ "wireframecolor" ].x)/255, (sets[ "render" ][ "wireframecolor" ].y)/255, (sets[ "render" ][ "wireframecolor" ].z)/255 )
end

function GAMEMODE.ShouldDrawLocalPlayer()
return sets[ "render" ][ "thirdperson" ]
end

function GAMEMODE.PreDrawPlayerHands()
return sets[ "render" ][ "nohands" ]
end


