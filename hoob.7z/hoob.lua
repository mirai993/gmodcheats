require("krokodil2")

local mod = table.Copy(noob)
if (_G.noob) then _G.noob = nil end

local settings = {
	["cmd"] = {
		["cmd.scanning"] = true,
		["cmd.autoshoot"] = true,
		["cmd.nospread"] = true,
		["cmd.friends"] = true,
		["cmd.team"] = false,
		["cmd.spawn protection"] = true,
		["cmd.obbcenter"] = false,
		["cmd.npcs"] = false,
	},
	
	["render"] = {
		["render.names"] = true,
		["render.usergroups"] = true,
		["render.box"] = true,
		["render.xray"] = true,
		["render.cam"] = false,
		["render.crosshair"] = true,
	},
	
	["dev"] = {
		["dev.predict"] = true,
		["dev.angles"] = true,
		["dev.healthspam"] = true,
		["dev.priority"] = false,
		--["dev.bhop"] = true,
	},
	
	priority_target = nil,
	prop = nil,
	masterrender = true,
	menu = {},
	friends_list = {},
	menu_key = GetConVarNumber("menu_key"),
	bound_keys = {
		["f"] = true,
		["t"] = true,
	},
	
	net = {
		["wire_expression2_playercore_sendmessage"] = true,
		["wire_expression2_download"] = true,
		["wire_expression2_file_upload"] = true,
		["wire_expression2_file_chunk"] = true,
	},
}

local killcam_props = {
	w = 350,
	h = 225,
	--x = ScrW() - 360,
	x = ScrW() - 1140,
	y = 10,
	drawhud = false,
	dopostprocess = false,
	drawviewmodel = false,
}

local white = {
	["$basetexture"] = "models/debug/debugwhite",
	["$model"]       = 1,
	["$translucent"] = 1,
	["$alpha"]       = 1,
	["$nocull"]      = 1,
	["$ignorez"]     = 1,
}

local debugwhite = CreateMaterial("debugwhite", "VertexLitGeneric", white)

local fangles


/*
local color_correction = { --old/new
	Color(255,255,100,255) = Color(255,255,0,255),
	Color(25,25,25,255) = Color(100,100,100,255),
	Color(75,75,75,255) = Color(255,255,255,255),
	Color(80,45,0,255) = Color(100,70,50,255),
}
*/	


local weapon = {
	bases = {
		m9k = {
			["bobs_gun_base"] = true,
			["bobs_scoped_base"] = true,
		},
		madcow = {
			["weapon_mad_base"] = true,
			["weapon_mad_base_sniper"] = true,
		},
		hvh = { 
			["weapon_cs_base"] = true,
			["weapon_cs_base4"] = true,
			["weapon_base"] = true,
			["weapon_base2"] = true,
			["weapon_tttbase"] = true,
		},
		noob = {
			["weapon_cs_base2"] = true,
			["weapon_cs_base3"] = true,
		},
		im = {
			["weapon_im_base"] = true,
		}
	},
	
	hl2 = {
	["weapon_smg1"] = true,
	["weapon_ar2"] = true,
	}
}

local npcs = {
	["npc_headcrab_fast"] = true,
	["npc_headcrab"] = true,
	["npc_zombie"] = true,
	["npc_zombie_torso"] = true,
	["npc_fastzombie"] = true,	
}
--fr1kin
local hitboxes = {
	["models/alyx_ep2.mdl"] = {
		["default"] = 0;
		["center"] = 15;
		["upper"] = 17;
		["lower"] = 16;
	},
	
	["models/headcrabblack.mdl"] = {
		["default"] = 0;
		["center"] = 0;
		["upper"] = 0;
		["lower"] = 0;
	},
	["models/headcrabclassic.mdl"] = {
		["default"] = 0;
		["center"] = 0;
		["upper"] = 0;
		["lower"] = 0;
	},
	["models/player/Group01/Female_01.mdl"] = {
		["default"] = 0;
		["center"] = 15;
		["upper"] = 17;
		["lower"] = 16;
	},
	["models/player/Group01/Female_02.mdl"] = {
		["default"] = 0;
		["center"] = 15;
		["upper"] = 17;
		["lower"] = 16;
	},
	["models/player/Group01/Female_03.mdl"] = {
		["default"] = 0;
		["center"] = 15;
		["upper"] = 17;
		["lower"] = 16;
	},
	["models/player/Group01/Female_04.mdl"] = {
		["default"] = 0;
		["center"] = 15;
		["upper"] = 17;
		["lower"] = 16;
	},
	["models/player/Group01/Female_06.mdl"] = {
		["default"] = 0;
		["center"] = 15;
		["upper"] = 17;
		["lower"] = 16;
	},
	["models/player/Group01/Female_07.mdl"] = {
		["default"] = 0;
		["center"] = 15;
		["upper"] = 17;
		["lower"] = 16;
	},
	["models/player/Group01/Male_01.mdl"] = {
		["default"] = 0;
		["center"] = 15;
		["upper"] = 16;
		["lower"] = 16;
	},
	["models/player/Group01/male_02.mdl"] = {
		["default"] = 0;
		["center"] = 15;
		["upper"] = 16;
		["lower"] = 16;
	},
	["models/player/Group01/male_03.mdl"] = {
		["default"] = 0;
		["center"] = 15;
		["upper"] = 16;
		["lower"] = 16;
	},
	["models/player/Group01/Male_04.mdl"] = {
		["default"] = 0;
		["center"] = 15;
		["upper"] = 16;
		["lower"] = 16;
	},
	["models/player/Group01/Male_05.mdl"] = {
		["default"] = 0;
		["center"] = 15;
		["upper"] = 16;
		["lower"] = 16;
	},
	["models/player/Group01/male_06.mdl"] = {
		["default"] = 0;
		["center"] = 15;
		["upper"] = 16;
		["lower"] = 16;
	},
	["models/player/Group01/male_07.mdl"] = {
		["default"] = 0;
		["center"] = 15;
		["upper"] = 16;
		["lower"] = 16;
	},
	["models/player/Group01/male_08.mdl"] = {
		["default"] = 0;
		["center"] = 15;
		["upper"] = 16;
		["lower"] = 16;
	},
	["models/player/Group01/male_09.mdl"] = {
		["default"] = 0;
		["center"] = 15;
		["upper"] = 16;
		["lower"] = 16;
	},
	["models/player/Group03/Female_01.mdl"] = {
		["default"] = 6;
		["center"] = 15;
		["upper"] = 17;
		["lower"] = 16;
	},
	["models/player/Group03/Female_02.mdl"] = {
		["default"] = 6;
		["center"] = 15;
		["upper"] = 17;
		["lower"] = 16;
	},
	["models/player/Group03/Female_03.mdl"] = {
		["default"] = 6;
		["center"] = 15;
		["upper"] = 17;
		["lower"] = 16;
	},
	["models/player/Group03/Female_04.mdl"] = {
		["default"] = 6;
		["center"] = 15;
		["upper"] = 17;
		["lower"] = 16;
	},
	["models/player/Group03/Female_06.mdl"] = {
		["default"] = 6;
		["center"] = 15;
		["upper"] = 17;
		["lower"] = 16;
	},
	["models/player/Group03/Female_07.mdl"] = {
		["default"] = 6;
		["center"] = 15;
		["upper"] = 17;
		["lower"] = 16;
	},
	["models/player/Group03/Male_01.mdl"] = {
		["default"] = 0;
		["center"] = 15;
		["upper"] = 16;
		["lower"] = 16;
	},
	["models/player/Group03/male_02.mdl"] = {
		["default"] = 0;
		["center"] = 15;
		["upper"] = 16;
		["lower"] = 16;
	},
	["models/player/Group03/male_03.mdl"] = {
		["default"] = 0;
		["center"] = 15;
		["upper"] = 16;
		["lower"] = 16;
	},
	["models/player/Group03/Male_04.mdl"] = {
		["default"] = 0;
		["center"] = 15;
		["upper"] = 16;
		["lower"] = 16;
	},
	["models/player/Group03/Male_05.mdl"] = {
		["default"] = 0;
		["center"] = 15;
		["upper"] = 16;
		["lower"] = 16;
	},
	["models/player/Group03/male_06.mdl"] = {
		["default"] = 0;
		["center"] = 15;
		["upper"] = 16;
		["lower"] = 16;
	},
	["models/player/Group03/male_07.mdl"] = {
		["default"] = 0;
		["center"] = 15;
		["upper"] = 16;
		["lower"] = 16;
	},
	["models/player/Group03/male_08.mdl"] = {
		["default"] = 0;
		["center"] = 15;
		["upper"] = 16;
		["lower"] = 16;
	},
	["models/player/Group03/male_09.mdl"] = {
		["default"] = 0;
		["center"] = 15;
		["upper"] = 16;
		["lower"] = 16;
	},
	["models/player/Hostage/Hostage_01.mdl"] = {
		["default"] = 0;
		["center"] = 15;
		["upper"] = 16;
		["lower"] = 16;
	},
	["models/player/Hostage/Hostage_02.mdl"] = {
		["default"] = 0;
		["center"] = 15;
		["upper"] = 16;
		["lower"] = 16;
	},
	["models/player/Hostage/hostage_03.mdl"] = {
		["default"] = 0;
		["center"] = 15;
		["upper"] = 16;
		["lower"] = 16;
	},
	["models/player/Hostage/hostage_04.mdl"] = {
		["default"] = 0;
		["center"] = 15;
		["upper"] = 16;
		["lower"] = 16;
	},
	["models/player/alyx.mdl"] = {
		["default"] = 0;
		["center"] = 15;
		["upper"] = 17;
		["lower"] = 16;
	},
	["models/player/arctic.mdl"] = {
		["default"] = 1;
		["center"] = 16;
		["upper"] = 17;
		["lower"] = 0;
	},
	["models/player/arctic.mdl"] = {
		["default"] = 1;
		["center"] = 16;
		["upper"] = 17;
		["lower"] = 0;
	},
	["models/player/barney.mdl"] = {
		["default"] = 0;
		["center"] = 15;
		["upper"] = 16;
		["lower"] = 16;
	},
	["models/player/breen.mdl"] = {
		["default"] = 0;
		["center"] = 15;
		["upper"] = 16;
		["lower"] = 16;
	},
	["models/player/charple01.mdl"] = {
		["default"] = 0;
		["center"] = 15;
		["upper"] = 16;
		["lower"] = 16;
	},
	["models/player/classic.mdl"] = {
		["default"] = 0;
		["center"] = 15;
		["upper"] = 16;
		["lower"] = 16;
	},
	["models/player/combie_soldier.mdl"] = {
		["default"] = 1;
		["center"] = 0;
		["upper"] = 17;
		["lower"] = 17;
	},
	["models/player/combine_soldier_prisonguard.mdl"] = {
		["default"] = 1;
		["center"] = 16;
		["upper"] = 17;
		["lower"] = 17;
	},
	["models/player/combine_super_soldier.mdl"] = {
		["default"] = 1;
		["center"] = 0;
		["upper"] = 17;
		["lower"] = 17;
	},
	["models/player/corpse1.mdl"] = {
		["default"] = 0;
		["center"] = 15;
		["upper"] = 16;
		["lower"] = 16;
	},
	["models/player/dod_american.mdl"] = {
		["default"] = 0;
		["center"] = 15;
		["upper"] = 16;
		["lower"] = 16;
	},
	["models/player/dod_german.mdl"] = {
		["default"] = 0;
		["center"] = 15;
		["upper"] = 16;
		["lower"] = 16;
	},
	["models/player/eli.mdl"] = {
		["default"] = 0;
		["center"] = 13;
		["upper"] = 14;
		["lower"] = 14;
	},
	["models/player/gasmask.mdl"] = {
		["default"] = 0;
		["center"] = 15;
		["upper"] = 16;
		["lower"] = 16;
	},
	["models/player/gman_high.mdl"] = {
		["default"] = 0;
		["center"] = 15;
		["upper"] = 16;
		["lower"] = 16;
	},
	["models/player/guerilla.mdl"] = {
		["default"] = 0;
		["center"] = 15;
		["upper"] = 16;
		["lower"] = 16;
	},
	["models/player/Kleiner.mdl"] = {
		["default"] = 0;
		["center"] = 15;
		["upper"] = 16;
		["lower"] = 16;
	},
	["models/player/leet.mdl"] = {
		["default"] = 0;
		["center"] = 15;
		["upper"] = 16;
		["lower"] = 16;
	},
	["models/player/magnusson.mdl"] = {
		["default"] = 0;
		["center"] = 15;
		["upper"] = 16;
		["lower"] = 16;
	},
	["models/player/monk.mdl"] = {
		["default"] = 0;
		["center"] = 15;
		["upper"] = 16;
		["lower"] = 16;
	},
	["models/player/mossman.mdl"] = {
		["default"] = 0;
		["center"] = 15;
		["upper"] = 17;
		["lower"] = 16;
	},
	["models/player/dod_american.mdl"] = {
		["default"] = 0;
		["center"] = 15;
		["upper"] = 16;
		["lower"] = 16;
	},
	["models/player/odessa.mdl"] = {
		["default"] = 0;
		["center"] = 15;
		["upper"] = 16;
		["lower"] = 16;
	},
	["models/player/Phoenix.mdl"] = {
		["default"] = 0;
		["center"] = 15;
		["upper"] = 16;
		["lower"] = 16;
	},
	["models/player/police.mdl"] = {
		["default"] = 0;
		["center"] = 15;
		["upper"] = 16;
		["lower"] = 16;
	},
	["models/player/riot.mdl"] = {
		["default"] = 0;
		["center"] = 15;
		["upper"] = 16;
		["lower"] = 16;
	},
	["models/player/soldier_stripped.mdl"] = {
		["default"] = 0;
		["center"] = 15;
		["upper"] = 16;
		["lower"] = 16;
	},
	["models/player/swat.mdl"] = {
		["default"] = 0;
		["center"] = 15;
		["upper"] = 16;
		["lower"] = 16;
	},
	["models/player/urban.mdl"] = {
		["default"] = 0;
		["center"] = 15;
		["upper"] = 16;
		["lower"] = 16;
	},
	["models/player/zombie_soldier.mdl"] = {
		["default"] = 0;
		["center"] = 15;
		["upper"] = 16;
		["lower"] = 16;
	},
	["models/player/zombiefast.mdl"] = {
		["default"] = 0;
		["center"] = 15;
		["upper"] = 16;
		["lower"] = 16;
	},	
	['models/player/arctic.mdl'] = {
		["default"] = 0
	},
}



local hudpaint 			= GAMEMODE.HUDPaint
local createmove		= GAMEMODE.CreateMove
local think 			= GAMEMODE.Think
local calcview			= GAMEMODE.CalcView
local pickup 			= GAMEMODE.PhysgunPickup
local render3d			= GAMEMODE.PostDrawOpaqueRenderables
local finishmove		= GAMEMODE.FinishMove
local setupmove			= GAMEMODE.SetupMove
local bindpress			= GAMEMODE.PlayerBindPress
local playertick		= GAMEMODE.PlayerTick

local gm 				= table.Copy(GAMEMODE)

local white 			= Color(255,255,255,255)
local white_smoke 		= Color(245,245,245)
local white2 			= Color(220,220,220)
local midnight 			= Color(40,40,40,255)
local obsidian 			= Color(50,50,50,255)
local blue 				= Color(0,191,255)

local matBlurScreen 	= Material("pp/blurscreen")
local angmeta 			= table.Copy(FindMetaTable("Angle"))
local cmdmeta 			= table.Copy(FindMetaTable("CUserCmd"))
local entmeta 			= table.Copy(FindMetaTable("Entity"))
local plymeta 			= table.Copy(FindMetaTable("Player"))
local vecmeta			= table.Copy(FindMetaTable("Vector"))
local wepmeta			= table.Copy(FindMetaTable("Weapon"))

--fr1kin again
local function AngleMatrix( ang, matrix )
        local rp = math.rad( ang.p );
        local sp, cp = math.sin( rp ), math.cos( rp );
        local ry = math.rad( ang.y );
        local sy, cy = math.sin( ry ), math.cos( ry );
        local rr = math.rad( ang.r );
        local sr, cr = math.sin( rr ), math.cos( rr );
        matrix[0].x = cp * cy;
        matrix[1].x = cp * sy;
        matrix[2].x = -sp;
        local crcy = cr * cy;
        local crsy = cr * sy;
        local srcy = sr * cy;
        local srsy = sr * sy;
        matrix[0].y = sp * srcy - crsy;
        matrix[1].y = sp * srsy + crcy;
        matrix[2].y = sr * cp;
        matrix[0].z = ( sp * crcy + srsy );
        matrix[1].z = ( sp * crsy - srcy );
        matrix[2].z = cr * cp;
        return matrix;
end
 
local function RotateVector( vec, matrix, set )
        set.x = vec:DotProduct( matrix[0] );
        set.y = vec:DotProduct( matrix[1] );
        set.z = vec:DotProduct( matrix[2] );
        return set;
end
 
local function Get3DCoords( org, mins, maxs, ang, keeplocal )
        local vecs = {
                [0] = Vector( mins.x, mins.y, mins.z ), // front-bottom-right
                [1] = Vector( maxs.x, mins.y, mins.z ), // front-top-right
                [2] = Vector( maxs.x, maxs.y, mins.z ), // back-top-right
                [3] = Vector( mins.x, maxs.y, mins.z ), // back-bottom-right
                [4] = Vector( mins.x, mins.y, maxs.z ), // front-bottom-left
                [5] = Vector( maxs.x, mins.y, maxs.z ), // front-top-left
                [6] = Vector( maxs.x, maxs.y, maxs.z ), // back-top-left
                [7] = Vector( mins.x, maxs.y, maxs.z ), // back-bottom-left
        };
        local angmatrix = {
                [0] = Vector( 0, 0, 0 ),
                [1] = Vector( 0, 0, 0 ),
                [2] = Vector( 0, 0, 0 ),
        };
       
        AngleMatrix( ang, angmatrix );
       
        local retv = {};
        for i = 0, 7 do
                if( !vecs[i] ) then     continue; end
                retv[i] = Vector( 0, 0, 0 );
                RotateVector( vecs[i], angmatrix, retv[i] );
                if( !keeplocal ) then
                        retv[i] = retv[i] + org;
                end
        end
       
        return retv;
end


local function GetHitboxCenter( ent, hitbox )
        local bpos, bang = ent:GetBonePosition( ent:GetHitBoxBone( hitbox, 0 ) );
        local mins, maxs = ent:GetHitBoxBounds( hitbox, 0 );
        local matrix = {
                [0] = Vector( 0, 0, 0 ),
                [1] = Vector( 0, 0, 0 ),
                [2] = Vector( 0, 0, 0 ),
        };
        AngleMatrix( bang, matrix );
        local rmins, rmaxs = Vector( 0, 0, 0 ), Vector( 0, 0, 0 );
        RotateVector( mins, matrix, rmins );
        RotateVector( maxs, matrix, rmaxs );
        return bpos + ( ( rmins + rmaxs ) / 2 );
end

local function isfriend(stid)
	return tobool(settings.friends_list[stid])
end

local function keydown(key)
	if ((input.IsKeyDown(key)) and type(vgui.GetKeyboardFocus()) ~= "Panel" and (!gui.IsConsoleVisible())) then
		return true
	end
return false
end

local function subvec(cone)
	return Vector(-cone, -cone, 0)
end

local function get_cone()

	if (!settings["cmd"]["cmd.nospread"]) then
		return subvec(0)
	end

	local hoob = LocalPlayer()
	local wep = plymeta.GetActiveWeapon(hoob)
	local class = wep:GetClass()
	
	if (class == "weapon_smg1") then
		return subvec(0.04362)
	end
	if (class == "weapon_ar2") then
		return subvec(0.02618)
	end
	
	if wep.Base and (weapon.bases.hvh[wep.Base]) then
		if wep.Cone or wep.Primary.Cone then
			return subvec(wep.Cone or wep.Primary.Cone)
		end
	end
	if wep.Base and wep.Base == "dm_weapon_base" then
		return subvec(wep.Primary.Spread or wep.Spread)
	end
	
	if wep.Base and (weapon.bases.m9k[wep.Base]) then
		if (wep:GetIronsights()) then
			cone = wep.Primary.IronAccuracy
		else
			cone = wep.Primary.Spread
		return subvec(cone)
		end
	end
	
	if (weapon.bases.noob[wep.Base]) then
		return subvec(wep.Cone or wep.Primary.Cone + .05)
	end
return subvec(0)
end

local function applyspread(ucmd, angle, ply)
	local hoob = ply
	local nangle = angle:Forward() or ((hoob:GetAimVector()):Angle()):Forward()
	local cone = get_cone()
	return (mod.PredictSpread(ucmd, nangle, get_cone())):Angle()
end


local function visible(ent, startpos, endpos, ply)
	local hoob = ply
	local trace = {}
    trace.start = startpos
	trace.endpos = endpos

    trace.filter = {hoob, ent}
    trace.mask = 1174421507
	
    local tr = util.TraceLine(trace)
	
	return (tr.Fraction == 1.0)
end

local function aimpos(ent, ply)

	if (settings["cmd"]["cmd.obbcenter"]) then
		return entmeta.LocalToWorld(ent, entmeta.OBBCenter(ent))
	end
	if (hitboxes[entmeta.GetModel(ent)]) then
		--print(entity:GetHitBoxBone(typewriter.hitboxes[entity:GetModel()]))
		--local pos = entity:GetBonePosition(entity:GetHitBoxBone(typewriter.specialHitboxes[entity:GetModel()],0))
		local pos = GetHitboxCenter(ent, hitboxes[entmeta.GetModel(ent)]["default"])
		--MsgN('using hitboxes')
		return pos
	end
	
	if ent:IsNPC() and (entmeta.LookupAttachment(ent,"eyes") != 0) then
		local pos = entmeta.GetAttachment(ent,entmeta.LookupAttachment(ent,"eyes"))
		local Pos = pos.Pos
		local Ang = pos.Ang
		local angvec = angmeta.Forward(Ang)
		Pos = Pos + angvec * - 4  
		return Pos
	end
	
	if (entmeta.IsNPC(ent)) then
		if (badnpcs[ent:GetModel()]) then
			local pos = ent:GetBonePosition(ent:LookupBone(npcs[ent:GetModel()]))
			return pos
        end
	end
	
	
	if (entmeta.LookupBone(ent, "ValveBiped.Bip01_Head1")) then
		local id = entmeta.LookupBone(ent, "ValveBiped.Bip01_Head1")
		local pos, ang = entmeta.GetBonePosition(ent, id)
		local angvec = angmeta.Forward(ang)
		local pos = pos + angvec * 4
		return pos
	end

return entmeta.LocalToWorld(ent, entmeta.OBBCenter(ent))
end

local function aimposnpc(ent)       
    if (npcs[ent:GetModel()]) then
    local pos = ent:GetBonePosition(ent:LookupBone(npcs[ent:GetModel()]))
		return pos
    end
return ent:LocalToWorld(ent:OBBCenter())
end

local function mdist(x1, y1, x2, y2)
	local xd = (x2 - x1)
	local yd = (y2 - y1)
	return math.sqrt(xd * xd + yd * yd)
end

local function predict(target, pos)
	--return pos + target:GetVelocity() * (1/66) - LocalPlayer():GetVelocity() * (1/66) 
end

local function predict(cmd,target, predPos)
  predPos = predPos + (target:GetVelocity() * engine.TickInterval() * RealFrameTime() ) - (LocalPlayer():GetVelocity(me) * engine.TickInterval() * RealFrameTime() )
  return predPos
end

local function test(ply, mv) 
    for k, v in next, player.GetAll() do
	if(v == LocalPlayer()) then continue end
      local myvel = (mv:GetVelocity() * engine.TickInterval())
	local entvel = (v:GetVelocity() * engine.TickInterval())
	myvel = myvel + Vector(engine.TickInterval(), engine.TickInterval(), 0)
	if(!ply:OnGround()) then
	myvel.z = myvel.z + engine.TickInterval()
	end
	entvel = entvel + Vector(engine.TickInterval(), engine.TickInterval(), 0)

	if(v:GetGravity() == 0) then
	grav = 1.0
	else
	grav = v:GetGravity()
	end

	if(!v:OnGround()) then
	entvel.z = (-(grav * GetConVar("sv_gravity"):GetFloat() * 0.5 * engine.TickInterval())) + (v:GetVelocity().z * engine.TickInterval());
	end

	movementvel = myvel - entvel
//print(entvel.z)
    end
end



local function scan(cmd)
	settings.target = nil
	local hoob = settings.hoob
	if (!IsValid(hoob)) then return end
	local wep = plymeta.GetActiveWeapon(hoob)
	
	if (!IsValid(hoob)) then return end
	if (!IsValid(wep)) then return end
	if (!keydown(KEY_F)) then return end
	if !settings["cmd"]["cmd.scanning"] then return end
	local closest, dist = nil, 0
	
	if (!settings["cmd"]["cmd.npcs"]) then
		getall = player.GetAll
	else
		getall = ents.FindByClass
	end
	
	for k, ent in next, getall("npc_*") do
			
		if (!IsValid(ent)) then
			continue
		end

		if entmeta.Health(ent) < 0 then
			continue
		end
							
		if (ent == hoob) then
			continue
		end
		
		
		if (!settings["cmd"]["cmd.npcs"]) and ent:IsNPC() then
			continue
		end
		
		if (settings["cmd"]["cmd.npcs"]) and (!npcs[ent:GetClass()]) then
			continue
		end
		
		if (!settings["cmd"]["cmd.npcs"]) then
		
			
			if (!plymeta.Alive(ent)) then
				continue
			end
			
			if (entmeta.IsDormant(ent)) then
				continue
			end
		
			if plymeta.GetFriendStatus(ent) == "friend" and (settings["cmd"]["cmd.friends"]) then
				continue
			end

			
			if ent.SteamID and settings.friends_list[ent:SteamID()] then
				continue
			end
		
			if (settings["cmd"]["cmd.team"]) and (team.GetName(plymeta.Team(ent)) == team.GetName(plymeta.Team(hoob))) then
				continue
			end
			
			if (settings["dev"]["dev.priority"]) and (settings.priority_target != ent:SteamID()) then
				continue
			end
		
			if (entmeta.GetMoveType(ent) == MOVETYPE_OBSERVER) or (entmeta.GetMoveType(ent) == 8) then
				continue
			end
		
			if (settings["cmd"]["cmd.spawn protection"]) then
				if entmeta.GetMaterial(ent) == "models/alyx/emptool_glow" or entmeta.GetColor(ent).a != 255 then
					continue
				end
			end
			
		end
		
		--MsgN(aimpos(ent,hoob) - settings.positions[ent])
		
		local tpos = aimpos(ent,hoob)
		local shootpos = plymeta.GetShootPos(hoob)

	
		if !visible(ent,shootpos,tpos,hoob) then
			continue
		end
		
				
			local _dist = mdist(tpos:ToScreen().x, tpos:ToScreen().y, ScrW() * 0.50, ScrH() * 0.50)
			
				if (ent.SteamID and ent:SteamID() == settings.priority_target) or (!closest or _dist < dist) then
				dist = _dist
				closest = ent
				targ = ent
				settings.t = targ
	
				angles = (tpos - shootpos):Angle()
				angle = (tpos - shootpos - movementvel):Angle()
				
				fangles = angles
				
				settings.target = targ
				
				angles = applyspread(cmd,angles,hoob)

				angles.p = math.NormalizeAngle(angles.p)
				angles.y = math.NormalizeAngle(angles.y)
				angles.r = 0

				if (table.HasValue(weapon.hl2, entmeta.GetClass(plymeta.GetActiveWeapon(hoob)))) or wep.Base == "fas2_base" then
					angles = (angles - plymeta.GetPunchAngle(hoob))
				end
				
				--cmdmeta.SetViewAngles(cmd,angles)
				cmd:SetViewAngles(angles)
				--MsgN(cmd)
				
				if keydown(KEY_LALT) and keydown(KEY_2) then
					settings.prop = settings.target
				end
				
				if (settings["cmd"]["cmd.autoshoot"]) then
					if wep.Primary and wep.Primary.Automatic == true then
					cmd:SetButtons(bit.bor(cmd:GetButtons(), IN_ATTACK))
				end
				
			end
		end
	end
end

FindMetaTable("Player").SetEyeAngles = function(ply,ang)
	local src = string.lower(debug.getinfo(2).short_src)
	if (string.find(src,"weapon")) and (settings["cmd"]["cmd.nospread"]) then
		return
	end
return plymeta.SetEyeAngles(ply,ang)
end
	
local function esp()
	if (settings["render"]["render.crosshair"]) then
	
		local w = ScrW() / 2
		local h = ScrH() / 2
		
		surface.SetDrawColor(Color(0,0,0,255))
		surface.DrawRect(w - 1, h - 3, 3, 7)
		surface.DrawRect(w - 3, h - 1, 7, 3)
		surface.SetDrawColor(Color(200,0,0,255))
		surface.DrawLine(w, h - 2, w, h + 2)
		surface.DrawLine(w - 2, h, w + 2, h)
		
	end
	
	local fps = math.Round(1/RealFrameTime())

	local hoob = LocalPlayer()
	
	for k, v in next, player.GetAll() do 
	
	if v == hoob then
		continue
	end
	
	if (!IsValid(v)) then 
		continue
	end
		
	if (!plymeta.Alive(v)) then
		continue
	end
		
	if (v == me) then
		continue
	end
		
	local x, y, color
	local mon, nom
	local h, w
	local bot, top
	local pos, hitPos
	local mat
	local teamcolor = team.GetColor(plymeta.Team(v))
	local realcol = Color(teamcolor.r, teamcolor.g, teamcolor.b, 255)
		
	nom = entmeta.GetPos(v)
	mon = nom + Vector(0, 0, entmeta.OBBMaxs(v).z)

	bot = nom:ToScreen()
	top = mon:ToScreen()

	--h = ( bot.y - top.y )
	--w = h
	h = (bot.y - top.y)
	w = h / 4.0
	
	surface.SetDrawColor(Color(teamcolor.r,teamcolor.g,teamcolor.b,255))
	
	if plymeta.GetFriendStatus(v) == "friend" or settings.friends_list[plymeta.SteamID(v)] then
		surface.SetDrawColor(Color(20,255,20,255))
	elseif settings.priority_target == plymeta.SteamID(v) then
		surface.SetDrawColor(Color(255,127,80))
	else
		surface.SetDrawColor(Color(255,20,20,255))
	end
	
	

	
	if fps < 20 then
		font = "Default"
	else
		font = "BudgetLabel"
	end

	if (realcol == Color(255,255,100,255)) then
		realcol = Color(255,255,0)
	end
	
	if (realcol == Color(25,25,25,255)) then
		realcol = Color(200,200,200,255)
	end
	
	if settings.priority_target == plymeta.SteamID(v) then
		realcol = Color(255,127,80)
	end
	
	if (settings["render"]["render.box"]) then
		surface.DrawOutlinedRect(top.x - w, top.y, w * 2, (bot.y - top.y))
	end
	
	x = (top.x)
	y = top.y - 24

	
	if (settings["render"]["render.names"]) then
		if plymeta.Armor(v) != 0 then
			draw.SimpleText(plymeta.Nick(v) .. " [" .. entmeta.Health(v) .. "/" .. plymeta.Armor(v) .. ")", font, x, y, realcol,1)
		else
			draw.SimpleText(plymeta.Nick(v) .. " [" .. entmeta.Health(v) .. ")", font, x, y, realcol,1)
		end
	end
	
	if (settings["render"]["render.usergroups"]) and plymeta.GetUserGroup(v) != "user" then
		draw.SimpleText(plymeta.GetUserGroup(v), font, x, y + 10, Color(10,255,0,255),1)
	end
	end
end

local function xray()
	if (settings["render"]["render.xray"]) then
		if IsValid(settings.prop) then 
		
		local prop = settings.prop
			
		render.SuppressEngineLighting(true)
		render.SetColorModulation(255/ 255, 165 / 255, 0 / 255)
		render.SetBlend(60 / 255)

		render.MaterialOverride(debugwhite)
		entmeta.DrawModel(prop)
		render.MaterialOverride()
		render.SuppressEngineLighting(false)
		end
	end
end


local function drawBlur(panel, color) --i am the admen now
	panel.Paint = function(self)
		 
		surface.SetMaterial( matBlurScreen )
		surface.SetDrawColor( 255, 255, 255, 255 )
		 
		local x1, y1 = self:LocalToScreen( 1, 1 )
		local x2, y2 = self:LocalToScreen( self:GetWide() - 1, self:GetTall() - 1 )
		x1 = x1 + 5 y1 = y1 + 5
		x2 = x2 - 5 y2 = y2 - 5
		 
		matBlurScreen:SetFloat( "$blur", 5 )
		render.UpdateScreenEffectTexture()
		surface.DrawPoly( {
			{ x = 1, y = 1, u = x1/ScrW(), v = y1/ScrH() },
			{ x = self:GetWide() - 1, y = 1, u = x2/ScrW(), v = y1/ScrH() },
			{ x = self:GetWide() - 1, y = self:GetTall() - 1, u = x2/ScrW(), v = y2/ScrH() },
			{ x = 1, y = self:GetTall() - 1, u = x1/ScrW(), v = y2/ScrH() }
		} )
		 
		surface.SetDrawColor(color)
		surface.DrawRect( 2, 1, self:GetWide() - 2, self:GetTall() - 2 )
		
		surface.SetDrawColor( 50, 50, 50, 255 )
		--surface.SetDrawColor(color_black)
		surface.DrawOutlinedRect(1, 0, self:GetWide(), self:GetTall() )
		surface.DrawOutlinedRect(0.3, 0, self:GetWide(), self:GetTall() )


	end
end

local lastp = nil

local function gradient(x, y, w, h ,col,coll,a)

	local col1, col2 = col, coll
	
	for i = 1, h, 2 do
		local col = (i / h)
		surface.SetDrawColor(( col1.r * (1 - col)) + (col2.r * col), (col1.g * (1 - col)) + (col2.g * col), (col1.b * (1 - col)) + (col2.b * col), a)
		surface.DrawRect(x, y + i, w, 2)
	end
end
	
local function checkbox(var, tab,tab2)
	
	if tab then lastp = tab end
	if (!tab) then tab = lastp end
	local title = var:Replace("."," ")
	local name = vgui.Create("DCheckBoxLabel", tab)
	name:SetText(title)
	name:DockMargin(10,10,0,10)
	name:Dock(TOP)
	
	name:SetChecked(settings[tab2][var])
	
	name.Label.m_colText = color_white
	name.Label.m_FontName = "DebugFixedSmall"

	function name.OnChange( self, b )
		settings[tab2][var] = b
		print(settings[tab2][var])
	end
	
	name.PaintOver = function(pan)
		--surface.SetDrawColor(Color(40,40,40,255)) --inner checkbox
		surface.SetDrawColor(midnight)
		surface.DrawRect(0,0,17,pan:GetTall() )
		surface.SetDrawColor(color_black) --checkbox outline
		surface.DrawOutlinedRect(0,0,17,pan:GetTall())
		if (pan:GetChecked()) then
		surface.SetDrawColor(white)
		surface.DrawRect(5.9, 5.9, 6, 6) -- surface.DrawRect(5.9, 5.9, 6, 6)
		surface.SetDrawColor(color_black) --checkbox checked outline
		surface.DrawOutlinedRect(5.9, 5.9, 6, 6) --surface.DrawOutlinedRect(5.9, 5.9, 6, 6)
		end
	end
end

local function fixtabselect(self)
end

local function menu()

	local mFrame = vgui.Create("DFrame")
	mFrame:SetTitle("")
	mFrame:SetSize(450,350)
	mFrame:Center()
	mFrame:MakePopup()
	
	
	
	mFrame:ShowCloseButton(false)
	mFrame:SetVisible(false)
	mFrame.Paint = function(self) 
		gradient(0,9, self:GetWide(), 30,  Color(150,150,150,200), Color(200,200,255),200)
	end

	
	local cmdTab = vgui.Create("DPanel", mFrame)
	local renderTab = vgui.Create("DPanel", mFrame)
	local devTab = vgui.Create("DPanel", mFrame)
	local friendTab = vgui.Create("DPanel", mFrame)
	
	table.insert(settings.menu, cmdTab)
	table.insert(settings.menu, renderTab)
	table.insert(settings.menu, devTab)

	local tabHolder = vgui.Create("DPropertySheet", mFrame)
	tabHolder.m_fFadeTime = 0
	tabHolder:SetSize(mFrame:GetWide(),330)
	tabHolder:Center()

	drawBlur(tabHolder,Color(30,30,30,150))

	
	tabHolder:AddSheet("cmd", cmdTab, nil, false, false,nil)
	tabHolder:AddSheet("render", renderTab, nil, false, false,nil)
	tabHolder:AddSheet("misc", miscTab, nil, false, false, nil)
	tabHolder:AddSheet("dev", devTab, nil, false, false,nil)
	tabHolder:AddSheet("friends", friendTab, nil, false, false,nil)
	
	for k, v in pairs(tabHolder.tabScroller.Panels) do
	v.ApplySchemeSettings = function(self)
		fixtabselect(self)
	end
	
	v.Paint = function(self)
		p = self:GetPropertySheet():GetActiveTab()
		if v == p then
			--surface.SetDrawColor(Color(30,30,30,100))
			--surface.DrawRect(0,0,p:GetWide() -1,p:GetTall())
			gradient(0,0, p:GetWide(), p:GetTall(),  Color(170,170,180,200), Color(200,200,200),200)
		end
		
		end
	end
	
	for k, v in pairs(settings.menu) do
		v.Paint = function(self) 
		gradient(0,0, self:GetWide(), self:GetTall(),  Color(60,80,80,200), Color(60,60,80,200),100)
		surface.SetDrawColor(blue)
		surface.SetDrawColor(midnight) --inner outline
		surface.DrawOutlinedRect(0,0,self:GetWide() ,self:GetTall())
		
		end
	end
	

	for k, v in pairs(settings["cmd"],true) do
		checkbox(k,cmdTab, "cmd")
	end
	for k, v in pairs(settings["render"]) do
		checkbox(k,renderTab, "render")
	end
	for k, v in pairs(settings["dev"]) do
		checkbox(k,devTab, "dev")
	end
	
	friendTab:SetSize(mFrame:GetWide() - 14,280)
	friendTab:Center()
	
	local AppList = vgui.Create( "DListView",friendTab)
	AppList:SetMultiSelect( false )
	AppList:SetSize(friendTab:GetWide(),friendTab:GetTall())
	AppList:Center()
	AppList:AddColumn("name")
	AppList:AddColumn("steamid")
	AppList:AddColumn("friend")
	AppList:SetSortable(false)

	for k, v in next, player.GetAll() do
	if (!IsValid(v)) then
		continue
	end
	
	AppList:AddLine(v:Nick(),v:SteamID(),isfriend(v:SteamID()))	
	
	end
	
	AppList.DoDoubleClick = function(lineid, line)

		local name = AppList:GetLine(line):GetValue(1)
		local stid = AppList:GetLine(line):GetValue(2)
		
		if (!isfriend(stid)) then
			settings.friends_list[stid] = true
		else
			settings.friends_list[stid] = false
		end
		
		--PrintTable(settings.friends_list)
		AppList:GetLine(line):SetValue(3, isfriend(stid))
		
	end
	
	AppList.OnRowRightClick = function(lineid, line)

		local stid = AppList:GetLine(line):GetValue(2)		
		settings.priority_target = stid
		settings.friends_list[stid] = false
		AppList:GetLine(line):SetValue(3, "priority")
			
		--AppList:Clear()
	end	

	function menu_bind()	
	
		if (vgui.GetKeyboardFocus()) and string.find(string.lower(tostring(vgui.GetKeyboardFocus())),"chat",1) then return end
		if (gui.IsConsoleVisible()) then return end
		if input.IsKeyDown(settings.menu_key) and (!mFrame:IsVisible()) then
			gui.EnableScreenClicker(true) mFrame:Show()
		end
		if !input.IsKeyDown(settings.menu_key) and (mFrame:IsVisible()) then
			gui.EnableScreenClicker(false) mFrame:Hide()
		end
		
		if (mFrame:IsVisible()) and (input.IsKeyDown(settings.menu_key) and input.IsKeyDown(KEY_LCONTROL)) then
			--refresh
			AppList:Clear()
			for k, v in next, player.GetAll() do
				if (!IsValid(v)) then
					continue
				end
			AppList:AddLine(v:Nick(),v:SteamID(),isfriend(v:SteamID()))	
			end
		end
		
	end		
	
end

menu()

local function KillCam()
	if (!settings["render"]["render.cam"]) then return end 
	if (!IsValid(settings.prop)) then return end
	
	local ent = settings.prop

	local hoob = LocalPlayer()
	local shotdir = vecmeta.Angle(vecmeta.GetNormal(entmeta.GetPos(ent) - entmeta.GetPos(hoob)))
	killcam_props.origin = entmeta.GetPos(ent) - angmeta.Forward(shotdir) * 72 + Vector(0, 0, 36)
	killcam_props.angles =  shotdir

	render.RenderView( killcam_props )
end

GAMEMODE.CalcView = function(gm, ply, origin, angles, fov, znear, zfar)
	settings.hoob = ply
	if keydown(KEY_F) and (settings.target) and (IsValid(settings.target))  then
		if (settings["cmd"]["cmd.nospread"]) then
		--MsgN(ply)
		--angles = --(aimpos(settings.target, ply) - shootpos):Angle()
		angles = fangles
		end
	end
	
	angles.p = math.NormalizeAngle(angles.p)
	angles.y = math.NormalizeAngle(angles.y)		
	angles.r = math.NormalizeAngle(angles.r)
	
return calcview(gm, ply, origin, angles, fov, znear, zfar)
end

GAMEMODE.HUDPaint   = function(...)
    esp(...)
	KillCam(...)
    return
hudpaint(...)
end  
 
GAMEMODE.SetupMove = function(gm,ply,move,cmd)
	--settings.hoob = ply
return
setupmove(gm, ply, move, cmd)
end

GAMEMODE.CreateMove = function(gm,cmd)
    scan(cmd)
	return
createmove(gm,cmd)
end

GAMEMODE.Think = function(gm)
	if (settings["dev"]["dev.healthspam"]) and entmeta.Health(LocalPlayer()) < 100 then
		if (LocalPlayer().levelup) then
			if LocalPlayer().levelup.experience > 40 then 
				net.Start("levelup_useperk")
				net.WriteInt(5,8)
				net.SendToServer()
			end
		end
	end
	menu_bind()
	
	if keydown(KEY_LALT) and keydown(KEY_1) then
		settings.prop = LocalPlayer().PlayerTrace.Entity
	end
	
	return
think(gm)
end

GAMEMODE.PhysgunPickup = function(gm,ply,entity)
	if IsValid(LocalPlayer()) and ply == LocalPlayer() then
		if entity:GetClass() == "prop_physics" then
			settings.prop = entity
		end
	end
return pickup(gm,ply,entity)
end

GAMEMODE.PostDrawOpaqueRenderables = function(gm, b1, b2)
	xray(b1,b2)
	return render3d(gm, b1, b2)
end

GAMEMODE.PlayerBindPress = function(gm, ply, bind, pressed)
	if (settings.bound_keys[input.LookupBinding(bind)]) then
		return true
	end
return bindpress(gm, ply, bind, pressed)
end


GAMEMODE.PlayerTick = function(gm, ply, mv)
	test(ply,mv)
	return playertick(gm, ply, mv)
end
	

local receive = net.Receive


function net.Receive(noob, func)
	
	if (settings.net[noob]) then
		return
	end

	if (string.find(noob,"wire",1)) then
		return
	end
return receive(noob,func)
end