--[[
	lua/helios.lua
	sup dude | (STEAM_0:0:35901997)
	===DStream===
]]

local helios = {
	hHook     = { sbList={}, list={}; };
	fHook     = { list={}; };

	visuals   = {};
	update    = {};

	lp        = LocalPlayer();

	derma     = {};

	convars   = {};

	targets   = {};

	trp       = {};

	_G        = table.Copy(_G);
} _G = table.Copy(helios["_G"]);

-- helios->hHook->sbHijackAdd (Sandbox Hooks): Find an already running hook and hijack it to point to our new function(s)
function helios.hHook.sbHijackAdd(hEvent, Function, NewFunction)
	for Event, FuncTbl in pairs(hook.Hooks) do
		if(Event == hEvent) then
			for FuncName, Func in pairs(FuncTbl) do
				if(FuncName == Function) then
					helios["hHook"]["sbList"][FuncName] = table.Copy(_G.hook.Hooks[Event])[FuncName];
					hook.Hooks[Event][FuncName] = function(...)
						helios["hHook"]["sbList"][FuncName]({...});
						NewFunction({...});
					end
					print("[helios->Hooking] Hijacked hook [" .. hEvent .. "->" .. Function .. "]");
				end
			end
		end
	end
end

-- helios->hHook->hijackAdd (Non-Sandbox Hooks): Find an already running hook and hijack it to point to our new function(s)
function helios.hHook.hijackAdd(hEvent, Function, NewFunction)
	for Event, FuncTbl in pairs(hook.Hooks) do
		if(Event == hEvent) then
			for FuncName, Func in pairs(FuncTbl) do
				if(FuncName == Function) then
					if(helios["_G"] ~= nil) then
						helios["hHook"]["list"][FuncName] = table.Copy(_G.hook.Hooks[Event])[FuncName];
						hook.Hooks[Event][FuncName] = nil;
						
						helios["_G"]["hook"].Add(hEvent, Function, function(...)
							helios["hHook"]["list"][FuncName]({...});
							NewFunction({...});
						end)

						print("[helios->Hooking] Hijacked hook [" .. hEvent .. "->" .. Function .. "]");
					end
				end
			end
		end
	end
end
print("[helios->Main] Hooking functions created");

function helios.genConVars()
	helios["convars"]["esp"] = helios["_G"].CreateClientConVar("helios_esp", 1, false, false);
	helios["convars"]["lights"] = helios["_G"].CreateClientConVar("helios_lights", 1, false, false);
	helios["convars"]["chams"] = helios["_G"].CreateClientConVar("helios_chams", 1, false, false);
	helios["convars"]["tracers"] = helios["_G"].CreateClientConVar("helios_tracers", 1, false, false);
	helios["convars"]["eyelasers"] = helios["_G"].CreateClientConVar("helios_eyelasers", 1, false, false);
	print("[helios->Main] Convars Created");
end
helios.genConVars();

function helios.visuals.isVisible(ply)
	helios["trp"].Trace = {};

	helios["trp"].Trace.start  = helios["lp"]:EyePos();
	helios["trp"].Trace.endpos = ply:EyePos();
	helios["trp"].Trace.filter = {helios["lp"], ply};

	helios["tr"] = util.TraceLine(helios["trp"].Trace);

	if(helios["tr"].Hit) then
		return true;
	end
end

function helios.visuals.Chams()
	for _, v in pairs(player.GetAll()) do
		if(GetConVarNumber("helios_chams") == 1 && v:Alive() && v:Health() > 0 && v ~= helios["lp"]) then
			helios["pcolor"] = team.GetColor(v:Team());
			cam.Start3D(EyePos(), EyeAngles());
				render.SuppressEngineLighting(true);
				render.SetBlend(0.2);
				render.MaterialOverride(Material("models/debug/debugwhite"));
				render.SetColorModulation(helios["pcolor"].r / 255, helios["pcolor"].g / 255, helios["pcolor"].b / 255);
				v:DrawModel();
				render.SuppressEngineLighting(false);
				render.MaterialOverride();
				render.SetColorModulation(1, 1, 1);
			cam.End3D();
		end

		if(GetConVarNumber("helios_eyelasers") == 1 && v:Alive() && v:Health() > 0 && v ~= helios["lp"]) then
			cam.Start3D(EyePos(), EyeAngles());
			render.SetMaterial(Material("cable/redlaser"));
			render.DrawBeam(v:EyePos(), v:GetEyeTrace().HitPos, 10, 1, 1, Color(0, 255, 0, 255));
			cam.End3D();
		end

		if(GetConVarNumber("helios_tracers") == 1 && v:Alive() && v:Health() > 0 && v ~= helios["lp"] && !helios["visuals"].isVisible(v)) then
			cam.Start3D(EyePos(), EyeAngles());
				if(LocalPlayer():GetViewModel():GetAttachment(LocalPlayer():GetViewModel():LookupAttachment("muzzle")) ~= nil) then
					render.SetMaterial(Material("cable/hydra"));
					render.DrawBeam(LocalPlayer():GetViewModel():GetAttachment(LocalPlayer():GetViewModel():LookupAttachment("muzzle")).Pos, v:EyePos(), 3, 1, 1, Color(0, 255, 0, 255));
				end
			cam.End3D();
		end


		if(GetConVarNumber("helios_lights") && v:Alive() && v:Health() > 0 && v ~= helios["lp"]) then
			helios["plight"] = DynamicLight(v:EntIndex());
			if(helios["plight"]) then
				helios["plight"].Pos = v:GetPos() + Vector(0, 0, 10);
				helios["plight"].r = helios["pcolor"].r;
				helios["plight"].g = helios["pcolor"].g;
				helios["plight"].b = helios["pcolor"].b;
				helios["plight"].Brightness = 5;
				helios["plight"].Decay = 125 * 5;
				helios["plight"].Size = 128;
				helios["plight"].DieTime = CurTime() + 1;
			else
				helios["plight"].DieTime = 1;
			end
		end
	end
end

function helios.visuals.eyeLasers()

end

hook.Add("HUDPaint", "FlashEffect1", helios.visuals.Chams);

function helios.Aimbot(ucmd)
	for _,v in pairs(player.GetAll()) do
		if(v ~= helios["lp"]) then
			local targethead = v:LookupBone("ValveBiped.Bip01_Head1") -- In this aimbot we only aim for the head.
			if(input.IsKeyDown(KEY_LALT) && v:Team() ~= helios["lp"] && targethead != nil && v:IsValid() && v:Health() > 0 && !helios["visuals"].isVisible(v)) then
				local targetheadpos,targetheadang = v:GetBonePosition(targethead) -- Get the position/angle of the head.
				ucmd:SetViewAngles((targetheadpos - LocalPlayer():GetShootPos()):Angle())
			end
		end
	end
end

hook.Add("CreateMove", "lel", helios.Aimbot);

--[[
				if(GetConVarNumber("helios_lasers")) then
					render.SetMaterial(Material("cable/redlaser"));
					render.DrawBeam(v:EyePos(), v:LocalToWorld(Vector(0, 0, 250)), 10, 1, 1, Color(0, 255, 0, 255));
				end

								if(GetConVarNumber("helios_lights")) then
					helios["plight"] = DynamicLight(v:EntIndex());
					if(helios["plight"]) then
						helios["plight"].Pos = v:GetPos() + Vector(0, 0, 10);
						helios["plight"].r = helios["pcolor"].r;
						helios["plight"].g = helios["pcolor"].g;
						helios["plight"].b = helios["pcolor"].b;
						helios["plight"].Brightness = 5;
						helios["plight"].Decay = 125 * 5;
						helios["plight"].Size = 128;
						helios["plight"].DieTime = CurTime() + 1;
					end
				end
]]--

function helios.FireBullet()    RunConsoleCommand("+attack"); end
function helios.EndFireBullet() RunConsoleCommand("-attack"); end

function helios.TriggerBot()
	/*helios.Pos          = helios["lp"]:GetShootPos();
	helios.Ang          = helios["lp"]:GetAimVector();
	helios.Trace        = {};
	helios.Trace.start  = helios.Pos;
	helios.Trace.endpos = helios.Pos + (helios.Ang * GetConVarNumber("def_triggerbot_distance"));
	helios.Trace.filter = helios["lp"];

	helios.LTrace       = util.TraceLine(helios.Trace);

	if(helios.LTrace.HitNonWorld) then
		helios.Target = helios.LTrace.Entity;
		if(helios.Target:IsPlayer()) then
			if(input.IsKeyDown(KEY_LALT) && helios.Target != helios["lp"] && helios.Target:Alive() && helios.Target:Health() > 0 && IsValid(helios.Target)) then
				helios.FireBullet();
				timer.Simple(0.001, function() helios.EndFireBullet() end);
			end
		end
	end*/
end

hook.Add("Think", "lelele", helios.TriggerBot);