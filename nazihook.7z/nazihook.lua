local dontaimteam = 0
local eyang = _R["Player"].SetEyeAngles
local varmenu = {}
varmenu.current = 1
varmenu.showmenu = 1
local nH = {}
nH.aim = 1
nH.esp = 1
nH.nospread = 1
nH.autoshoot = 0
nH.onshoot = 0
nH.silent = 1
local timerruns = 1
cne = Vector(0,0,0)
local function KeyPress()
if timerruns == 1 then
timer.Simple(0.1,function () KeyPress() end)
end
    if( input.IsKeyDown( KEY_DELETE ) ) then
    timerruns = 0
    print("Destroyed timer")
    hook.Remove( "HUDPaint","menuespandcrosshair" )
    hook.Remove( "CalcView","lol" )
    hook.Remove( "CreateMove","nospreadnaim" )
    print("Unloaded Hooks")
    end
    if( input.IsKeyDown( KEY_INSERT ) ) then
    if varmenu.showmenu == 0 then
    varmenu.showmenu = 1
    else
    varmenu.showmenu = 0
    end
    end
    if varmenu.showmenu == 1 then
    if( input.IsKeyDown( KEY_DOWN ) ) then
    if varmenu.current == 1 then
    varmenu.current = 2
    elseif varmenu.current == 2 then
    varmenu.current = 3
    elseif varmenu.current == 3 then
    varmenu.current = 4
    elseif varmenu.current == 4 then
    varmenu.current = 5
    elseif varmenu.current == 5 then
    varmenu.current = 1
    end
    end
    if( input.IsKeyDown( KEY_UP ) ) then
    if varmenu.current == 5 then
    varmenu.current = 4
    elseif varmenu.current == 4 then
    varmenu.current = 3
    elseif varmenu.current == 3 then
    varmenu.current = 2
    elseif varmenu.current == 2 then
    varmenu.current = 1
    elseif varmenu.current == 1 then
    varmenu.current = 5
    end
    end
    if( input.IsKeyDown( KEY_RIGHT ) ) then
    if varmenu.current == 1 then
    if nH.aim == 1 then
    nH.aim = 0
    else
    nH.aim = 1
    end
    elseif varmenu.current == 2 then
    if nH.esp == 1 then
    nH.esp = 0
    else
    nH.esp = 1
    end
    elseif varmenu.current == 3 then
    if nH.nospread == 1 then
    nH.nospread = 0
    else
    nH.nospread = 1
    end
    elseif varmenu.current == 4 then
    if nH.autoshoot == 1 then
    nH.autoshoot = 0
    else
    nH.autoshoot = 1
    nH.onshoot = 0
    end
    elseif varmenu.current == 5 then
    if nH.onshoot == 1 then
    nH.onshoot = 0
    else
    nH.onshoot = 1
    nH.autoshoot = 0
    end
    end
    end
    end
    end
KeyPress()

local cppweapsrec = {}
cppweapsrec["weapon_357"] = 0.8
cppweapsrec["weapon_smg1"] = 1
cppweapsrec["weapon_ar2"] = 1.1
cppweapsrec["weapon_shotgun"] = 1
cppweapsrec["weapon_pistol"] = 1
local cppweaps = {}
cppweaps["weapon_357"] = true
cppweaps["weapon_smg1"] = true
cppweaps["weapon_ar2"] = true
cppweaps["weapon_shotgun"] = true
cppweaps["weapon_pistol"] = true
cppweaps["weapon_crossbow"] = true
cppweaps["weapon_rpg"] = true
local dontaimweaps = {}
dontaimweaps["weapon_crowbar"] = true
dontaimweaps["weapon_physcannon"] = true
dontaimweaps["weapon_physgun"] = true
dontaimweaps["weapon_rpg"] = true
dontaimweaps["weapon_grenade_frag"] = true
dontaimweaps["weapon_stunstick"] = true
dontaimweaps["weapon_slam"] = true
dontaimweaps["gmod_tool"] = true
local function anglepunch()
if !(LocalPlayer():GetActiveWeapon() == nil) then
if cppweaps[LocalPlayer():GetActiveWeapon():GetClass()] then
return (((LocalPlayer():GetPunchAngle( )) or Angle(0,0,0))*(cppweapsrec[LocalPlayer():GetActiveWeapon():GetClass()] or 0.8))
else
return Angle(0,0,0)
end
else
return Angle(0,0,0)
end
end
hook.Add("Think","firebulltimer",function()
LocalPlayer().FireBullets=function(bullet)
local cne=Vector(-bullet.Spread.x,-bullet.Spread.y,-bullet.Spread.z)
end
_R.Entity.FireBullets=function(bullet)
local cne=Vector(-bullet.Spread.x,-bullet.Spread.y,-bullet.Spread.z)
end
if LocalPlayer():GetActiveWeapon() and ValidEntity(LocalPlayer():GetActiveWeapon()) then
LocalPlayer():GetActiveWeapon().ShootBullets=function(bla,bla2,spr)
local cne=Vector(-spr,-spr,-spr)
end
end
end)
local CL = LocalPlayer()
local wep = LocalPlayer():GetActiveWeapon()
local NoSpreadHere=false
if #file.Find("../lua/includes/modules/gmcl_deco.dll")>=1 then
NoSpreadHere=true

local MoveSpeed = 1

mysetupmove = function(objPl, move)
    if move then
        MoveSpeed = (move:GetVelocity():Length())/move:GetMaxSpeed()
    end
end

local ID_GAMETYPE = ID_GAMETYPE or -1
local GameTypes = {
    {check=function ()
        return string.find(GAMEMODE.Name,"Garry Theft Auto") ~= nil
    end,getcone=function (wep,cone)
        if type(wep.Base) == "string" then
            if wep.Base == "civilian_base" then
                local scale = cone
                if CL:KeyDown(IN_DUCK) then
        scale = math.Clamp(cone/1.5,0,10)
                elseif CL:KeyDown(IN_WALK) then
        scale = cone
                elseif (CL:KeyDown(IN_SPEED) or CL:KeyDown(IN_JUMP)) then
        scale = cone + (cone*2)
                elseif (CL:KeyDown(IN_FORWARD) or CL:KeyDown(IN_BACK) or CL:KeyDown(IN_MOVELEFT) or CL:KeyDown(IN_MOVERIGHT)) then
        scale = cone + (cone*1.5)
                end
                scale = scale + (wep:GetNWFloat("Recoil",0)/3)
                return Vector(scale,0,0)
            end
        end
        return Vector(cone,cone,cone)
    end},
    {check=function ()
        return type(TEAM_ZOMBIE) == "number" and type(TEAM_SURVIVORS) == "number" and string.find(GAMEMODE.Name,"Zombie Survival") ~= nil and type(NUM_WAVES) == "number"
    end,getcone=function (wep,cone)
        if wep:GetNetworkedBool("Ironsights",false) then
            if CL:Crouching() then
                return wep.ConeIronCrouching or cone
            end
            return wep.ConeIron or cone
        elseif 25 < LocalPlayer():GetVelocity():Length() then
            return wep.ConeMoving or cone
        elseif CL:Crouching() then
            return wep.ConeCrouching or cone
        end
        return cone
    end},
    {check=function ()
        return type(TEAM_ZOMBIE) == "number" and type(TEAM_SURVIVORS) == "number" and string.find(GAMEMODE.Name,"Zombie Survival") ~= nil
    end,getcone=function (wep,cone)
        if CL:GetVelocity():Length() > 25 then
            return wep.ConeMoving or cone
        elseif CL:Crouching() then
            return wep.ConeCrouching or cone
        end
        return cone
    end},
    {check=function ()
        return type(gamemode.Get("ZombRP")) == "table" or type(gamemode.Get("DarkRP")) == "table"
    end,getcone=function (wep, cone)
        if type(wep.Base) == "string" and (wep.Base == "ls_snip_base" or wep.Base == "ls_snip_silencebase") then
            if CL:GetNWInt( "ScopeLevel", 0 ) > 0 then
                print("using scopecone")
                return wep.Primary.Cone
            end
            print("using unscoped cone")
            return wep.Primary.UnscopedCone
        end
        if type(wep.GetIronsights) == "function" and wep:GetIronsights() then
            return cone
        end
        return cone + .05
    end},
    {check=function ()
        return (GAMEMODE.Data == "falloutmod" and type(Music) == "table")
    end,getcone=function(wep,cone)
        if wep.Primary then
            local LastShootTime = wep.Weapon:GetNetworkedFloat( "LastShootTime", 0 )
            local lastshootmod = math.Clamp(wep.LastFireMax + 1 - math.Clamp( (CurTime() - LastShootTime) * wep.LastFireModifier, 0.0, wep.LastFireMax ), 1.0,wep.LastFireMaxMod)
            local accuracy = wep.Primary.Accuracy
            if CL:IsMoving() then accuracy = accuracy * wep.MoveModifier end
            if wep.Weapon:GetNetworkedBool( "Ironsights", false ) then accuracy = accuracy * 0.75 end
            accuracy = accuracy * ((16-(Skills.Marksman or 1))/11)
            if CL:KeyDown(IN_DUCK) then
                return accuracy*wep.CrouchModifier*lastshootmod
            else
                return accuracy*lastshootmod
            end
        end
    end}
}
Check = function()
    for k, v in pairs(GameTypes) do
        if v.check() then
            ID_GAMETYPE = k
            break
        end
    end
end

local tblNormalConeWepBases = {
    ["weapon_cs_base"] = true
}
local function GetCone(wep)
    local cone = wep.Cone
    if not cone and type(wep.Primary) == "table" and type(wep.Primary.Cone) == "number" then
        cone = wep.Primary.Cone
    end
    if wep:GetClass() == "ose_turretcontroller" then return 0 end
    return cone or 0
end

require("deco")
local currentseed, cmd2, seed = currentseed or 0, 0, 0
local wep, vecCone, valCone
PredictSpread = function(cmd,aimAngle)
    cmd2, seed = hl2_ucmd_getprediction(cmd)
    if cmd2 ~= 0 then
        currentseed = seed
    end
    wep = LocalPlayer():GetActiveWeapon()
    vecCone = Vector(0,0,0)
    if wep and wep:IsValid() and type(wep.Initialize) == "function" then
        valCone = GetCone(wep)
        if( tonumber( valCone ) ) then
        vecCone = Vector( -valCone, -valCone, -valCone )
        elseif( type( valCone ) == "Vector" ) then
        vecCone = -1 * valCone
        end
    end
    if wep:GetClass() == "weapon_smg1" then
    vecCone = Vector(-0.04362,-0.04362,-0.04362)
    elseif wep:GetClass() == "weapon_pistol" then
    vecCone = Vector( -0.0100, -0.0100, -0.0100 )
    elseif wep:GetClass() == "weapon_ar2" then
    vecCone = Vector( -0.02618, -0.02618, -0.02618 )
    elseif wep:GetClass() == "weapon_shotgun" then
    vecCone = Vector( -0.08716, -0.08716, -0.08716 )
    elseif wep:GetClass() == "weapon_iceaxe" then
    vecCone = Vector(-0.15,-0.15,-0.15)
    elseif wep:GetClass() == "weapon_sniper" then
    vecCone = Vector(-0.01,-0.01,-0.01)
    elseif wep:GetClass() == "weapon_hmg1" then
    vecCone = Vector(-0.07,-0.07,-0.07)
    elseif wep:GetClass() == "weapon_smg2" then
    vecCone = Vector(-0.07,-0.07,-0.07)
    elseif wep:GetClass() == "weapon_ar1" then
    vecCone = Vector(-0.07,-0.07,0)
    elseif wep:GetClass() == "weapon_oicw" then
    if wep.Zoom == 0 then
    vecCone = Vector(-0.07,-0.07,-0.07)
    else
    vecCone = Vector(-0.01,-0.01,-0.01)
    end
    elseif wep:GetClass() == "weapon_bsmg1" then
    vecCone = Vector(-0.04362,-0.04362,-0.04362)
    elseif wep:GetClass() == "mill_deagle" then
    vecCone = Vector(-0.5,-0.5,-0.5)
    elseif wep:GetClass() == "weapon_para" then
    vecCone = Vector(-0.05,-0.05,0)
    end
    if !(cne == Vector(0,0,0)) then
    vecCone = cne
    end
    return hl2_shotmanip(currentseed or 0, aimAngle:Forward(), vecCone):Angle()
end
end
local dontaim = {"npc_hunter","npc_dog","npc_monk","npc_alyx","npc_mossman","npc_barney","npc_eli","npc_gman","npc_citizen","npc_turret_floor","npc_grenade_frag","rebelturret","npc_vortigaunt","npc_barnacle","npc_barnacle_tongue_tip","npc_kleiner","npc_satchel","npc_rollermine"}
local dontaim = {""}
aimmodels = {
        ["models/combine_scanner.mdl"] = "Scanner.Body",
        ["models/hunter.mdl"] = "MiniStrider.body_joint",
        ["models/combine_turrets/floor_turret.mdl"] = "Barrel",
        ["models/dog.mdl"] = "Dog_Model.Eye",
        ["models/antlion.mdl"] = "Antlion.Body_Bone",
        ["models/antlion_guard.mdl"] = "Antlion_Guard.Body",
        ["models/antlion_worker.mdl"] = "Antlion.Head_Bone",
        ["models/zombie/fast_torso.mdl"] = "ValveBiped.HC_BodyCube",
        ["models/zombie/fast.mdl"] = "ValveBiped.HC_BodyCube",
        ["models/headcrabclassic.mdl"] = "HeadcrabClassic.SpineControl",
        ["models/headcrabblack.mdl"] = "HCBlack.body",
        ["models/headcrab.mdl"] = "HCFast.body",
        ["models/zombie/poison.mdl"] = "ValveBiped.Headcrab_Cube1",
        ["models/zombie/classic.mdl"] = "ValveBiped.HC_Body_Bone",
        ["models/zombie/classic_torso.mdl"] = "ValveBiped.HC_Body_Bone",
        ["models/zombie/zombie_soldier.mdl"] = "ValveBiped.HC_Body_Bone",
        ["models/combine_strider.mdl"] = "Combine_Strider.Body_Bone",
        ["models/lamarr.mdl"] = "HeadcrabClassic.SpineControl"
}
local function HeadPos(ply)
    if ValidEntity(ply) then
if (ply:GetClass()=="npc_tripmine") && (ply:GetClass()=="npc_satchel") && (ply:GetClass()=="npc_grenade_frag") then
return false
end
    local bone = (aimmodels[ ply:GetModel() ] or "ValveBiped.Bip01_Head1")
    local hbone = ply:LookupBone(bone)
        return ply:GetBonePosition(hbone)
    else return end
end
local function Visible(ply)
    local trace = {start = LocalPlayer():GetShootPos(),endpos = HeadPos(ply),filter = {LocalPlayer(), ply}}
    local tr = util.TraceLine(trace)
    if tr.Fraction == 1 then
        return true
    else
        return false
    end   
end
local tar = nil
local correctView = Angle( 0, 0, 0 )
local silent = Angle( 0, 0, 0 )
local view = Angle( 0, 0, 0 )
local SetViewAngles = _R["CUserCmd"].SetViewAngles
local function fovcheck(input,input2)
return true
end
local function checkteam(pl)
if dontaimteam == 1 then
if LocalPlayer():Team() == pl:Team() then
return false
end
else
return true
end
end

local function validtarget(entz)
if !(LocalPlayer():GetActiveWeapon() == nil) then
if dontaimweaps[LocalPlayer():GetActiveWeapon():GetClass()] then return false end
else
return false
end
if !ValidEntity(entz) then return false end
for k,v in pairs(dontaim) do
if entz:GetClass() == v then return false end
end
if !(entz:IsPlayer() or entz:IsNPC()) then return false end
if entz == LocalPlayer() then return false end
if !Visible(entz) then return false end
if entz:IsNPC() then
if entz.IsDead == true then
return false
end
end
if entz:GetMoveType() == MOVETYPE_NONE then return false end
if entz:IsPlayer() then if entz:Health() < 1 then return false end end
if entz:IsPlayer() then if !checkteam(entz) then return false end end
if entz:IsNPC() then if entz.IsDead == true then return false end end
if entz:GetMoveType() == MOVETYPE_NONE then return false end
return true
end
local function validtarget2(entz)
if !ValidEntity(entz) then return false end
for k,v in pairs(dontaim) do
if entz:GetClass() == v then return false end
end
if !(entz:IsPlayer() or entz:IsNPC()) then return false end
if entz == LocalPlayer() then return false end
if entz:IsNPC() then
if entz.IsDead == true then
return false
end
end
if entz:IsPlayer() then if entz:Health() < 1 then return false end end
if entz:IsPlayer() then if !checkteam(entz) then return false end end
if entz:IsNPC() then if entz.IsDead == true then return false end end
return true
end
local function GetMeta(name)
    return table.Copy(_R[name] or {})
end
local function get(a,b)
return math.abs((a.x or 0)-(b.x or 0))+math.abs((a.y or 0)-(b.y or 0))
end
local VecM = GetMeta("Vector")
local function FindTarget()
    local ply = LocalPlayer()
    if !ValidEntity(ply) then return end
    local maxAng = 500000000000000
    local aimVec, shootPos = ply:GetAimVector(), ply:GetShootPos()

    local targets = ents.GetAll()
    for i, ent in pairs(targets) do
        if validtarget(ent) == false then
            targets[i] = nil
        end
    end

    local closestTarget, lowestAngle = _, maxAng
    for _, target in pairs(targets) do
            local targetPos = HeadPos(target)
            local angle = LocalPlayer():GetShootPos():Distance(targetPos)

            if angle < lowestAngle then
                lowestAngle = angle
                closestTarget = target
            end
    end
    if closestTarget then
    oldtarget = closestTarget
    return closestTarget
    end
    return false
end
PredictWeapons = {
        ["weapon_crossbow"] = 3110,
    }

function WeaponPrediction( e, pos )
    local ply = LocalPlayer()
    if ( ValidEntity( e ) && ( type( e:GetVelocity() ) == "Vector" ) ) then
    if ValidEntity(ply:GetActiveWeapon()) then
        local dis, wep = e:GetPos():Distance( ply:GetPos() ), ply:GetActiveWeapon():GetClass()
        if ( wep && PredictWeapons[ wep ]  ) then
            local t = (dis / 3500) + 0.05
                    local mul = 0.0074
                    local pos = ( pos + e:GetVelocity() * t )
            pos = pos - (e:GetVelocity() * mul)
            return pos
        end
    end
    end
    return pos
end
local function calcs( u )
        local ply = LocalPlayer()
        if LocalPlayer():Alive() then
        local ply = LocalPlayer()
        local mouse = Angle(u:GetMouseY() * GetConVarNumber("m_pitch"), u:GetMouseX() * -GetConVarNumber("m_yaw"),0) or Angle(0,0,0)
        correctView = correctView + mouse
        end
        correctView.p = math.Clamp(math.NormalizeAngle( correctView.p ),-89,89)
        correctView.y = math.NormalizeAngle( correctView.y )
        local view = correctView
        if nH.nospread == 1 then
        if (u:GetButtons() & IN_ATTACK > 0) then
        if ( ply:GetActiveWeapon():Clip1() >= 1 ) then
            view = PredictSpread(u,view)
        end
        else
        if !(u:GetButtons() & IN_USE > 0) then
        view = view + Vector(180,180,180)
        end
        end
        end
        SetViewAngles( u,view-anglepunch())
        if !(nH.aim==1) then return end
        if nH.onshoot == 1 then
        if !(u:GetButtons() & IN_ATTACK > 0) then
        return
        end
        end
        if FindTarget() && ValidEntity(FindTarget()) then
        local targetheadpos = HeadPos(FindTarget())
        local velocity = FindTarget():GetVelocity() or Vector(0,0,0)
        local velocityplayer = ply:GetVelocity() or Vector(0,0,0)
        local ang = (((targetheadpos + velocity*FrameTime()))- (ply:GetShootPos()+velocityplayer*FrameTime())):Angle()
        if fovcheck(correctView,ang) then
        if !nH.silent == 1 then
        correctView = ang
        end
        if nH.autoshoot == 1 & nH.onshoot == 0 then
            RunConsoleCommand( "+attack" )
            timer.Simple( 0.1, function() RunConsoleCommand( "-attack" ) end )
        end
        local angz = (WeaponPrediction( FindTarget(),(((targetheadpos + velocity*FrameTime()))- (ply:GetShootPos()+velocityplayer*FrameTime())):Angle()-anglepunch()))
        if nH.nospread == 1 then
        if (u:GetButtons() & IN_ATTACK > 0) then
        if ( ply:GetActiveWeapon():Clip1() >= 1 ) then
        angz = PredictSpread(u,angz)
        end
        end
        end
        SetViewAngles( u,angz )
        --SetViewAngles( u,PredictSpread(u,ang)-anglepunch() )
        end
        end
end
hook.Add("CreateMove","aim",calcs)
    local function Norec( u, o )
        return { origin = o, angles = correctView}
    end
    hook.Add( "CalcView","lol", Norec )
function DrawFadingColorBox(x,y,w,h,alpha)
    local calculate = h/255
        for i=0,h do
        surface.SetDrawColor( i/calculate, i/calculate, 0, alpha)
        surface.DrawLine( x, i+y, x+w, i+y )
        end
end
local function drawradar()
LocalPlayer():GetViewModel().Angle = view
local radar = {}
DrawFadingColorBox(0,0,200,200,200)
DrawFadingColorBox(0,200,200,17,200)
surface.SetDrawColor( 255, 0, 0, 255 );
surface.DrawOutlinedRect( 0, 0, 200, 200 );
surface.DrawOutlinedRect( 0, 0, 200, 217 );
draw.SimpleText( "NaziHook Private Radar", "Default", 100, 200+(16/2), Color(255,0,0,255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1)
--surface.DrawLine( 10, 100, 190, 100 );
--surface.DrawLine( 100, 10, 100, 190 );
local x = 100
local y = 100
surface.DrawLine( x-90, y, x+90, y )
surface.DrawLine( x, y-90, x, y+90 )

surface.DrawLine( x+90, y+90, x+90, y )
surface.DrawLine( x-90, y-90, x-90, y )

surface.DrawLine( x+90, y-90, x, y-90 )
surface.DrawLine( x-90, y+90, x, y+90 )
--Default values
radar.w = 200
radar.h = 200
radar.x = 0
radar.y = 0
radar.alphascale = 0.6
radar.bgcolor = Color(255,0,0,255)
radar.fgcolor = Color(0,0,255,255)
radar.dangercolour = Color(220,0,0,255)
radar.dangerblipcolour = Color(255,255,0,255)
radar.screendetail = 64
radar.screenrotation = 0
radar.hazardmode = false    --doesnt work

radar.radius = 5000

radar.player_show = true
radar.player_color = Color(0,150,255,255)
surface.CreateFont("Arial",64,400,false,false,"RadarPlayerLabel")
radar.player_fontcolor = Color(255,255,255,255)
radar.player_showname = true
radar.player_showhealth = true
radar.player_showarmor = false --TO DO
radar.player_showammo = true


radar.scanfor = {"player", "blastfungus", "rpg_missile", "crossbow_bolt", "npc_", "sent_", "prop_vehicle_"}        -- What should the radar look for?  Accepts partial names.
radar.dangerous = {"sent_nuke_missile", "sent_nuke_detpack"}    --doesnt work

radar.bgcolorbak = radar.bgcolor
radar.fgcolorbak = radar.fgcolor
radar.player_colorbak = radar.player_color


local color_ascale = function(col,scale) return Color(col.r,col.g,col.b,col.a*scale) end

    local ETable = {}
    local PulseRadar = false

    local lpl = LocalPlayer()
    
    
    if ( radar.player_show ) then
    local vertices = {}
    for i=1,radar.screendetail do
        local shift = math.fmod(CurTime()*radar.screenrotation,360)
        local sizescale = 1
        local tab = {}
        tab.x = radar.x+radar.w/2 + math.cos(math.Deg2Rad((360/radar.screendetail)*i+shift)) * radar.w/2 * sizescale
        tab.y = radar.y+radar.h/2 + math.sin(math.Deg2Rad((360/radar.screendetail)*i+shift)) * radar.h/2 * sizescale
        tab.u = 0
        tab.v = 0
        table.insert(vertices,tab)
    end
    local players = {}

    for k,ent in pairs(ents.GetAll()) do

            if ent:IsValid() then
                local type = ent:GetClass()

                for k, v in ipairs(radar.scanfor) do
                    if string.find(type,v) then
                        table.insert(players,ent)
                    end
                end
            end
        end
        for i, pl in ipairs(players) do
            local cx = radar.x+radar.w/2
            local cy = radar.y+radar.h/2
            local vdiff = pl:GetPos()-lpl:GetPos()
            local dummy = nil
                if pl:IsPlayer() then
                    if ( pl:Alive() and lpl~=pl ) then
                        local px = (vdiff.x/radar.radius)
                        local py = (vdiff.y/radar.radius)
                        local z = math.sqrt( px*px + py*py )
                        local phi = math.Deg2Rad( math.Rad2Deg( math.atan2( px, py ) ) - math.Rad2Deg( math.atan2( lpl:GetAimVector().x, lpl:GetAimVector().y ) ) - 90 )
                        px = math.cos(phi)*z
                        py = math.sin(phi)*z
                        draw.RoundedBox( 0, math.Clamp(cx+px*radar.w/2-4,0,190), math.Clamp(cy+py*radar.h/2-4,0,190), 8, 8, Color(0,100,255,255) )
                        surface.SetDrawColor( 0,0,0,255 )
                        surface.DrawOutlinedRect( math.Clamp(cx+px*radar.w/2-4,0,190), math.Clamp(cy+py*radar.h/2-4,0,190), 8, 8)
                    end
                end
                if ((not pl:IsPlayer()) and pl:IsValid() ) then

                    local isDangerous = false
                    if ( radar.hazardmode ) then
                        for k,v in ipairs(radar.dangerous) do
                            if (pl:GetClass() == v) then
                                table.insert(ETable,pl)
                                isDangerous = true
                            end
                        end
                    end
                    
                    local px = (vdiff.x/radar.radius)
                    local py = (vdiff.y/radar.radius)
                    local z = math.sqrt( px*px + py*py )
                    local phi = math.Deg2Rad( math.Rad2Deg( math.atan2( px, py ) ) - math.Rad2Deg( math.atan2( lpl:GetAimVector().x, lpl:GetAimVector().y ) ) - 90 )
                    px = math.cos(phi)*z
                    py = math.sin(phi)*z

                    if (isDangerous == false) then
                        draw.RoundedBox( 0, math.Clamp(cx+px*radar.w/2-4,0,190), math.Clamp(cy+py*radar.h/2-4,0,190), 8, 8, Color(255,255,255,255) )
                        surface.SetDrawColor( 0,0,0,255 )
                        surface.DrawOutlinedRect( math.Clamp(cx+px*radar.w/2-4,0,190), math.Clamp(cy+py*radar.h/2-4,0,190), 8, 8)
                    if pl:IsNPC() then
                        if( Visible(pl) ) then
                        drawColor = Color( 255, 0, 0, 255 )
                        else
                        drawColor = Color( 0, 255, 255, 255 )
                        end
                        draw.RoundedBox( 0, math.Clamp(cx+px*radar.w/2-4,0,190), math.Clamp(cy+py*radar.h/2-4,0,190), 8, 8, drawColor)
                        surface.SetDrawColor( 0,0,0,255 )
                        surface.DrawOutlinedRect( math.Clamp(cx+px*radar.w/2-4,0,190), math.Clamp(cy+py*radar.h/2-4,0,190), 8, 8)
                    end
                    end


                    if radar.player_showname then

                        local nametag = ""
                        if string.find(pl:GetClass(),"blastfungus") then nametag = ""
                        elseif string.find(pl:GetClass(),"npc_") then nametag = string.sub(pl:GetClass(),5)
                        elseif string.find(pl:GetClass(),"sent_") then nametag = string.sub(pl:GetClass(),6)
                        elseif string.find(pl:GetClass(),"prop_vehicle_") then nametag = string.sub(pl:GetClass(),14)
                        else nametag = pl:GetClass()
                        end

                        local nametable = string.Explode("_",nametag)
                        nametag = table.concat(nametable," ")
                        local nametag1 = string.sub(nametag,0,1)
                        local nametag2 = string.sub(nametag,2)
                        nametag1 = string.upper(nametag1)
                        nametag = nametag1..nametag2


                    end
                end
              end
         end
          local count = table.Count(ETable)
          
          if ( count > 0 ) then
          for k,pl in ipairs(ETable) do
              local cx = radar.x+radar.w/2
            local cy = radar.y+radar.h/2
            local vdiff = pl:GetPos()-lpl:GetPos()
            
              local px = (vdiff.x/radar.radius)
            local py = (vdiff.y/radar.radius)
            local z = math.sqrt( px*px + py*py )
            local phi = math.Deg2Rad( math.Rad2Deg( math.atan2( px, py ) ) - math.Rad2Deg( math.atan2( lpl:GetAimVector().x, lpl:GetAimVector().y ) ) - 90 )
            px = math.cos(phi)*z
            py = math.sin(phi)*z
                        draw.RoundedBox( 0, math.Clamp(cx+px*radar.w/2-4,0,190), math.Clamp(cy+py*radar.h/2-4,0,190), 8, 8, color_ascale(radar.player_color,255) )
                        surface.SetDrawColor( 0,0,0,255 )
                        surface.DrawOutlinedRect( math.Clamp(cx+px*radar.w/2-4,0,190), math.Clamp(cy+py*radar.h/2-4,0,190), 8, 8)
        end
            
            radar.bgcolor = Color(255,255,255,0)
            radar.fgcolor = Color(60,60,60,100)
            
            PulseRadar = true
        end
end

local function box( e )
    local ply, pos = LocalPlayer(), nil
    local center = e:LocalToWorld( e:OBBCenter() )
    local min, max = e:OBBMins(), e:OBBMaxs()
    local dim = max - min
    local z = max + min
    
    local frt    = ( e:GetForward() ) * ( dim.y / 2 )
    local rgt    = ( e:GetRight() ) * ( dim.x / 2 )
    local top    = ( e:GetUp() ) * ( dim.z / 2 )
    local bak    = ( e:GetForward() * -1 ) * ( dim.y / 2 )
    local lft    = ( e:GetRight() * -1 ) * ( dim.x / 2 )
    local btm    = ( e:GetUp() * -1 ) * ( dim.z / 2 )
    
    local d, v = math.Round( e:GetPos():Distance( ply:GetShootPos() ) )
    v = d / 30
    
    pos = e:LocalToWorld( top + top ) + Vector( 0, 0, v + 10 )
    if ( e:IsWeapon() ) then pos = e:LocalToWorld( e:OBBCenter() ) end
    
    local FRT     = center + frt + rgt + top; FRT = FRT:ToScreen()
    local BLB     = center + bak + lft + btm; BLB = BLB:ToScreen()
    local FLT    = center + frt + lft + top; FLT = FLT:ToScreen()
    local BRT     = center + bak + rgt + top; BRT = BRT:ToScreen()
    local BLT     = center + bak + lft + top; BLT = BLT:ToScreen()
    local FRB     = center + frt + rgt + btm; FRB = FRB:ToScreen()
    local FLB     = center + frt + lft + btm; FLB = FLB:ToScreen()
    local BRB     = center + bak + rgt + btm; BRB = BRB:ToScreen()
    
    pos = pos:ToScreen()
    
    local maxX = math.max( FRT.x,BLB.x,FLT.x,BRT.x,BLT.x,FRB.x,FLB.x,BRB.x )
    local minX = math.min( FRT.x,BLB.x,FLT.x,BRT.x,BLT.x,FRB.x,FLB.x,BRB.x )
    local maxY = math.max( FRT.y,BLB.y,FLT.y,BRT.y,BLT.y,FRB.y,FLB.y,BRB.y)
    local minY = math.min( FRT.y,BLB.y,FLT.y,BRT.y,BLT.y,FRB.y,FLB.y,BRB.y )
    
    return maxX, minX, maxY, minY
end

local function espzor()
if (ValidEntity(FindTarget())) then
local x = ScrW() /2
local y = ScrH() /2
surface.SetDrawColor(Color(0,255,0,255))
surface.DrawLine( x-50, y, x+50, y )
surface.DrawLine( x, y-50, x, y+50 )

surface.DrawLine( x+50, y+50, x+50, y )
surface.DrawLine( x-50, y-50, x-50, y )

surface.DrawLine( x+50, y-50, x, y-50 )
surface.DrawLine( x-50, y+50, x, y+50 )
else
local x = ScrW() /2
local y = ScrH() /2
surface.SetDrawColor(Color(255,0,0,255))
surface.DrawLine( x-50, y, x+50, y )
surface.DrawLine( x, y-50, x, y+50 )

surface.DrawLine( x+50, y+50, x+50, y )
surface.DrawLine( x-50, y-50, x-50, y )

surface.DrawLine( x+50, y-50, x, y-50 )
surface.DrawLine( x-50, y+50, x, y+50 )
end
if !(ValidEntity(FindTarget())) then
draw.SimpleText( "[NaziHook] Searching for target.", "Default", ScrW()/2, 16/2, Color(255,0,0,255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1)
else
if FindTarget():IsNPC() then
draw.SimpleText( "[NaziHook] Target: "..FindTarget():GetClass(), "Default", ScrW()/2, 16/2,Color(0,255,0,255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1)
else
draw.SimpleText( "[NaziHook] Target: "..FindTarget():GetName(), "Default", ScrW()/2, 16/2,Color(0,255,0,255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1)
end
end
if nH.esp == 1 then
        for k, v in pairs(ents.GetAll()) do
            if( ValidEntity(v) and v ~= LocalPlayer() ) then
                if( v:IsNPC() ) then
                    local drwclr = Color(255, 255, 255, 255);
                    local vis = ""
                    if( Visible(v) ) then
                        vis = "Visible"
                        drwclr = Color( 255, 0, 0, 255 );
                    else
                        vis = "Invisible"
                        drwclr = Color( 0, 255, 255, 255 );
                    end
                    if !validtarget2(v) then
                    return
                    end
                    surface.SetDrawColor(drwclr)
                    local head = HeadPos(v):ToScreen()
                    local maxX, minX, maxY, minY = box(v)
                    local lol = maxY-minY
                    local x = head.x
                    local y = head.y
                    local lol = maxY-minY
                    surface.DrawLine( maxX, maxY, maxX, head.y )
                    surface.DrawLine( maxX, head.y, minX, head.y )
                    
                    surface.DrawLine( minX, head.y, minX, maxY )
                    surface.DrawLine( minX, maxY, maxX, maxY )
if FindTarget() == v then
surface.SetDrawColor(Color(255,255,0,255))
end
--[[surface.DrawLine( x-5, y, x+5, y )
surface.DrawLine( x, y-5, x, y+5 )

surface.DrawLine( x+5, y+5, x+5, y )
surface.DrawLine( x-5, y-5, x-5, y )

surface.DrawLine( x+5, y-5, x, y-5 )
surface.DrawLine( x-5, y+5, x, y+5 )]]--
//X
--[[
surface.DrawRect( x, y - 5, 1,11);
surface.DrawRect( x - 5, y, 11,1);
//X

//Outer Horizontal
surface.DrawRect( x - 1, y  - 6, 3,1);
surface.DrawRect( x - 1, y  + 6, 3,1);
surface.DrawRect( x - 1, y  - 8, 3,1);
surface.DrawRect( x - 1, y  + 8, 3,1);
            
surface.DrawRect( x - 2, y  - 8, 1,3);
surface.DrawRect( x - 2, y  + 6, 1,3);

surface.DrawRect( x + 2, y  - 8, 1,3);
surface.DrawRect( x + 2, y  + 6, 1,3);
//Outer Horizontal

//Outer Vertically
surface.DrawRect( x - 6, y  - 1, 1,3);
surface.DrawRect( x + 6, y  - 1, 1,3);
surface.DrawRect( x - 8, y  - 1, 1,3);
surface.DrawRect( x + 8, y  - 1, 1,3);
            
surface.DrawRect( x - 8, y  - 2, 3,1);
surface.DrawRect( x + 6, y  - 2, 3,1);

surface.DrawRect( x - 8, y  + 2, 3,1);
surface.DrawRect( x + 6, y  + 2, 3,1);
//Outer Vertically
surface.SetDrawColor(drwclr)
if FindTarget() == v then
surface.SetDrawColor(Color(255,255,0,255))
end
//Outer Horizontal FILL
surface.DrawRect( x - 1, y - 7, 3,1);
surface.DrawRect( x - 1, y + 7, 3,1);
//Outer Horizontal FILL

//Outer Vertically FILL
surface.DrawRect( x - 7, y - 1, 1,3);
surface.DrawRect( x + 7, y - 1, 1,3);
//Outer Vertically FILL
]]--
                end
            end
        end
end
        if varmenu.showmenu == 1 then
        surface.SetDrawColor( 255, 0, 0, 255 );
        surface.DrawRect( ScrW()/2-100, 0, 200, 16*6+1 );
        surface.SetDrawColor( 100, 0, 0, 255 );
        surface.DrawRect( ScrW()/2-99, 18, 198, 16*5-3 );
        surface.SetDrawColor( 0, 255, 0, 255 );
        if varmenu.current == 1 then
        surface.DrawRect(ScrW()/2-99,16,198,16);
        elseif varmenu.current == 2 then
        surface.DrawRect(ScrW()/2-99,16*2,198,16);
        elseif varmenu.current == 3 then
        surface.DrawRect(ScrW()/2-99,16*3,198,16);
        elseif varmenu.current == 4 then
        surface.DrawRect(ScrW()/2-99,16*4,198,16);
        elseif varmenu.current == 5 then
        surface.DrawRect(ScrW()/2-99,16*5,198,16);
        end
        surface.SetDrawColor( 255, 255, 255, 255 );
        surface.DrawOutlinedRect( ScrW()/2-102, 0, 203, 16*6+1 );
        surface.DrawOutlinedRect( ScrW()/2-102, 0, 203, 16*1+1 );
        draw.SimpleText( "NaziHook Private version", "Default", ScrW()/2, 16/2, Color( 255, 255, 0, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1)
        draw.SimpleTextOutlined( "Aimbot: "..nH.aim, "Default", ScrW()/2-80, 16/2+16, Color( 255, 255, 255, 255 ), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER, 1, Color( 0, 0, 0, 255 ) )
        draw.SimpleTextOutlined( "Nospread: "..nH.nospread, "Default", ScrW()/2-80, 16/2+(16*3), Color( 255, 255, 255, 255 ), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER, 1, Color( 0, 0, 0, 255 ) )
        draw.SimpleTextOutlined( "ESP: "..nH.esp, "Default", ScrW()/2-80, 16/2+(16*2), Color( 255, 255, 255, 255 ), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER, 1, Color( 0, 0, 0, 255 ) )
        draw.SimpleTextOutlined( "Autoshoot: "..nH.autoshoot, "Default", ScrW()/2-80, 16/2+(16*4), Color( 255, 255, 255, 255 ), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER, 1, Color( 0, 0, 0, 255 ) )
        draw.SimpleTextOutlined( "Onshoot: "..nH.onshoot, "Default", ScrW()/2-80, 16/2+(16*5), Color( 255, 255, 255, 255 ), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER, 1, Color( 0, 0, 0, 255 ) )
        end
        drawradar()
        end
local timerruns = 1
hook.Add("HUDPaint","esp",espzor)
local function unhookz()
timerruns = 0
    hook.Remove("Think","firebulltimer")
    hook.Remove( "HUDPaint","esp" )
    hook.Remove( "CalcView","lol" )
    hook.Remove( "CreateMove","aim" )
    hook.Remove( "HUDPaint", "OnPaint" )
    print("Unloaded Hooks")
end
local function keyz()
if timerruns == 1 then
timer.Simple(0.1,function () keyz() end)
end
    if( input.IsKeyDown( KEY_DELETE ) ) then
unhookz()
    end
    end
keyz()
function OnPaint()
drawradar()
end

hook.Add( "HUDPaint", "OnPaint", OnPaint )