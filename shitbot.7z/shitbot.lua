--[[
	testesp.lua
	Jesse Jackson | (STEAM_0:1:43732934)
	===DStream===
]]

/*
					Shitty hack. Inspired by many hacks.
					Thanks:
					Discord, fr1kin, and Sykranos.
*/

/*******************
		Locals
*******************/
local concommand 			= concommand
local cvars 				= cvars
local debug 				= debug
local ents 					= ents
local file					= file
local hook 					= hook
local math 					= math
local spawnmenu				= spawnmenu
local string 				= string
local surface 				= surface
local table 				= table
local timer 				= timer
local util 					= util
local Angle 				= Angle
local CreateClientConVar 	= CreateClientConVar
local CurTime 				= CurTime
local ErrorNoHalt			= ErrorNoHalt
local FrameTime 			= FrameTime
local GetConVarString 		= GetConVarString
local GetViewEntity 		= GetViewEntity
local include 				= include
local ipairs 				= ipairs
local LocalPlayer 			= LocalPlayer
local pairs 				= pairs
local pcall 				= pcall
local print 				= print
local RunConsoleCommand		= RunConsoleCommand
local ScrH 					= ScrH
local ScrW 					= ScrW
local tonumber 				= tonumber
local type 					= type
local unpack 				= unpack
local ValidEntity 			= ValidEntity
local Vector 				= Vector

/*******************
		Setup
/******************/
local SB = {}
SB.CC = CreateClientConVar
SB.CCAdd = concommand.Add

local function OnLoad()
	if file.Find("lua\includes\modules\gm_cvar2.dll") then
		require("cvar2")
		MsgN("-[ShitBot]- Cvar2 Module Loaded!")
	if file.Find("lua\includes\modules\gmcl_dec0.dll") then
		require("dec0")
		MsgN("-[ShitBot]- Nospread Module Loaded!")
	end
end
OnLoad()
end

SB.Fvar = cvar2.SetValue

function SB:AddHook(Type,Function)
Name = tostring(math.random(1,100000))
return hook.Add(Type,Name,Funtion)
end

SB.Cvars = 
{
	SB.CC("SB_Aim_Enabled",0,true,false)
	SB.CC("SB_Aim_FF",0,true,false)
	SB.CC("SB_Aim_Offset","Eye",true,false)
	SB.CC("SB_Aim_Steam",0,true,false)
	SB.CC("SB_Aim_NoRecoil",0,true,false)
	SB.CC("SB_ESP_Enabled",0,true,false)
	SB.CC("SB_ESP_Health",0,true,false)
	SB.CC("SB_ESP_Admin",0,true,false)
	SB.CC("SB_Misc_Bhop",0,true,false)
	SB.CC("SB_Misc_Spam",0,true,false)
	SB.CC("SB_Vis_XQZ",0,true,false)
}

/*******************
		Aimbot
*******************/

local function AimSpot(tar)
	if GetConVarString("SB_Aim_Offset" == "Eye" then
	local eye = tar:LookupAttachment("eyes")
		if eye then
		local pos = tar:GetAttachment(eye)
			if pos then return pos.Pos end
		end
	end	
	if GetConVarString("SB_Aim_Offset" == "Bone" then
		local HBone = tar:LookupBone("ValveBiped.Bip01_Head1")
		if HBone then
			local pos = tar:GetBonePosition(HBone)
			if pos then return pos end
		end
	end	
end

local function GetTarg(ent)
	if (ent == LocalPlayer()) then return false end
	if (ent:Team() == TEAM_SPECTATOR) then return false end 
	if (ent:GetMoveType() == MOVETYPE_OBSERVER) then return false end 
	if (!ent:Alive() ) then return false end 
	if (ent:InVehicle()) then return false end 
	if (GetConVarNumber("SB_Aim_FF") == 0 && ent:Team() == LocalPlayer():Team()) then return false end
	if (GetConVarNumber("SB_Aim_Steam") == 1 && ent:GetFriendStatus() == "friend" ) then return false end 
end

function SB:Aimbot(cmd)
local SetViewAngles = _R.CUserCmd.SetViewAngles
	if GetConVarNumber("SB_Aim_Enabled") == 1 then
		for k,v in pairs(player.GetAll()) do
			if GetTarg( v ) then
			SetViewAngles(cmd,(AimSpot:GetVelocity()/45-LocalPlayer():GetShootPos()):Angle())
			end
		end
	end
end

SB.CCAdd("+SB_Aim",function()
	RunConsoleCommand("SB_Aim_Enabled",1)
end)

SB.CCAdd("-SB_Aim",function()
	RunConsoleCommand("SB_Aim_Enabled",0)
end)

function SB:NoRecoil()
	if GetConVarNumber("SB_Aim_NoRecoil") == 1 then
		if LocalPlayer():GetActiveWeapon().Primary then
		LocalPlayer():GetActiveWeapon().Primary.Recoil = 0
		end
	end
end

/*******************
		ESP
*******************/

function SB:ESP()
	if GetConVarNumber("SB_ESP_Enabled") == 1 then
		for k,v in pairs(player.GetAll()) do
		local Pos = ( v:LocalToWorld( v:OBBCenter() ) - Vector( 15, 10, -40 ) ):ToScreen()
		local TEAMCOL = team.GetColor(v:Team())
			if v == LocalPlayer() then continue end
				if v:Alive() and v:Health() then
					draw.SimpleText(v:Name() ,"Trebuchet22" ,Pos.x ,Pos.y ,TEAMCOL ,TEXT_ALIGN_LEFT)
					if GetConVarNumber("SB_ESP_Health") == 1 then
						draw.SimpleText("H: " .. v:Health() ,"Trebuchet22" ,Pos.x ,Pos.y + 10 ,TEAMCOL ,TEXT_ALIGN_LEFT)
					if GetConVarNumber("SB_ESP_Admin") == 1 then
						if v:IsAdmin() then
							draw.SimpleText("Admin" ,"Trebuchet22" ,Pos.x ,Pos.y + 20 ,TEAMCOL ,TEXT_ALIGN_LEFT)
							end
						end
					end
				end
			end
		end
	end
						
function SB:XQZ()
	if GetConVarNumber("SB_Vis_XQZ") == 1 then
		local WHITE = Color(255,255,255)
		if v:Alive() and v:Health() > 0 then
			cam.Start3D( EyePos() , EyeAngles() )
			cam.IgnoreZ(true)
			render.SetColorModulation((WHITE.r * 1/255), (WHITE.g * 1/255), (WHITE.b * 1/255))
			v:DrawModel()
			cam.IgnoreZ(false)
			cam.End3D()
			end
		end
	end

/*******************
		Misc.
*******************/
SB.CCAdd("SB_Misc_Flood",function()
	include("flood.lua")
end)

SB.CCAdd("SB_Misc_Crash",function()
	include("crash.lua")
end)

SB.CCAdd("SB_Misc_DarkRP",function()
	include("name.lua")
end)

function SB:BHop()
	if GetConVarNumber("SB_Misc_Bhop") == 1 then
		if input.IsKeyDown(KEY_SPACE) then
		if LocalPlayer():IsOnGround() then
		RunConsoleCommand("+Jump")
			timer.Create(0.01, 0, function() RunConsoleCommand("-Jump") end)
			end
		end
	end
end
local urdone = SB.Fvar("host_timescale",50000000)
function SB:Spam()
	if GetConVarNumber("SB_Misc_Spam") == 1 then
		RunConsoleCommand("say", "steamcommunity.com/groups/SeriousRPmasters")
	end
end

SB.CCAdd("+SB_Speed",function()
	SB.Fvar("sv_cheats",1)
	SB.Fvar("host_timescale",2.5)
end)

SB.CCAdd("-SB_Speed",function()
	SB.Fvar("sv_cheats",0)
	SB.Fvar("host_timescale",1)
end)

SB.CCAdd("SB_Done",function()
	MsgN("ur done")
	SB.Fvar("sv_cheats",1)
	urdone
end)

/*******************
		Hooks
/******************/

function HookThink()
	SB:BHop();
	SB:Spam();
	SB:NoRecoil();
end
SB:AddHook("Think",HookThink)

function HookBot()
	SB:Aimbot(cmd);
end
SB:AddHook("CreateMove",HookBot)

function HookESP()
	SB:ESP();
	SB:XQZ();
end
SB:AddHook("HUDPaint",HookESP)
	