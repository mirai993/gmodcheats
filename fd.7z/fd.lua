local FakeDuckCmd = CreateClientConVar("fakeduck",0)

hook.Add("Tick","Derama",function()
    if(input.IsKeyDown(KEY_LALT)) then
        isFakeDucking = true
        if (GetConVar("fakeduck"):GetInt() == 1) then
            if(LocalPlayer():GetCurrentViewOffset().z >= 28 + FrameTime()) then
                RunConsoleCommand("+duck")
            elseif(LocalPlayer():GetCurrentViewOffset().z <= 28) then
                RunConsoleCommand("-duck")
            end
        else
            if(isFakeDucking) then
                RunConsoleCommand("-duck")
            end
        end
    else
        if(isFakeDucking) then
            RunConsoleCommand("-duck")
            isFakeDucking = false
        end
        isFakeDucking = false
    end
end)