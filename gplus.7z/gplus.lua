--[[
	MOD/lua/gPlus.lua [#3078 (#3165), 3992788569, UID:2843759159]
	Slyck | STEAM_0:0:88422219 <162.253.128.82:27005> | [25.05.14 01:11:37AM]
	===BadFile===
]]

--[[ GPLUS By pakaro ]]--

local gPlus = {}
function gESP()
    for k,v in ipairs(player.GetAll()) do
    if v != LocalPlayer() then
    local ps =  (v:GetShootPos()):ToScreen()
        draw.SimpleTextOutlined(v:Nick(), "Default", ps.x, ps.y, Color(255, 255, 255, 255), 1, 1, 1, Color(0,0,0,255))
        draw.SimpleTextOutlined(v:GetUserGroup(), "Default", ps.x, ps.y-9, Color(255, 255, 255, 255), 1, 1, 1, Color(0,0,0,255))
        draw.SimpleTextOutlined(math.Clamp(v:Health(), 0, 100), "Default", ps.x, ps.y+9, Color(255, 0, 0, 255), 1, 1, 1, Color(0,0,0,255))
		if v:GetFriendStatus() == "friend" then
	draw.RoundedBox(6, ps.x-3, ps.y-17, 6, 6, Color(0, 0, 0, 255))
	draw.RoundedBox(2, ps.x-2, ps.y-16, 4, 4, Color(0, 255, 0, 255))	
	    end
	end
    end
end
hook.Add("HUDPaint", "ESP", gESP)

hook.Add("Think","gVisuals", function()
	local p = LocalPlayer()
    wep = LocalPlayer():GetActiveWeapon()
    if ( wep["Primary"] ) then wep["Primary"]["Recoil"] = 0 end
	if ( wep["Primary"] ) then wep["Primary"]["Spread"] = 0 end
	if ( wep["Primary"] ) then wep["Primary"]["Cone"] = 0 end
    if ( wep["Secondary"] ) then wep["Secondary"]["Recoil"] = 0 end
	if ( wep["Secondary"] ) then wep["Secondary"]["Spread"] = 0 end
	if ( wep["Secondary"] ) then wep["Secondary"]["Cone"] = 0 end
end)
    
function gVisible( ent )
    local tracer = {}
    tracer.start = LocalPlayer():GetShootPos()
    tracer.endpos = ent:GetShootPos()
    tracer.filter = { LocalPlayer(), ent }
    tracer.mask = MASK_SHOT
    local trace = util.TraceLine( tracer )
    if trace.Fraction >= 1 then return true else return false end
end

local function gAimbot(ucmd)
local ply = LocalPlayer()
	for k,v in pairs(player.GetAll()) do
	local aimbotdot = (v:GetShootPos())

gPlusNoAim = {"STEAM_0:0:50632533", "STEAM_0:1:48906331", "STEAM_0:0:60046963", "STEAM_0:1:36511408", "STEAM_0:1:59601079", "STEAM_0:1:76165626", "STEAM_0:1:43296744", "STEAM_0:0:82005992", "STEAM_0:0:85462439", "STEAM_0:0:88422219"}
	if v:Alive() and IsValid(v) and v != LocalPlayer() and gVisible(v) and v:Team() ~= TEAM_SPECTATOR and !table.HasValue(gPlusNoAim, v:SteamID()) then
			gAimpos = v:LookupAttachment("eyes")
			gAimpos = v:GetAttachment(gAimpos)
			gAimpos = (gAimpos.Pos - LocalPlayer():GetShootPos()):Angle()
			ucmd:SetViewAngles(gAimpos)
			
						end
					end
				end
		
	

concommand.Add("+gPlus_aim", function()
	hook.Add("CreateMove", "Aimbot", gAimbot)
end )

concommand.Add("-gPlus_aim", function()
	hook.Remove("CreateMove", "Aimbot")
end )

concommand.Add("+gPlus_speed", function()
RunConsoleCommand("host_framerate", "5")
end)
concommand.Add("-gPlus_speed", function()
RunConsoleCommand("host_framerate", "0")
end)

concommand.Add("gPlus_ropes", function()
print("Giant list of ropes")
print("-------------------")
print("pp/bokehblur")
print("effects/tflogo")
print("effects/cake")
print("effects/bonk")
print("matsys_regressiontest/background")
print("particle/fire_particle_6/fire_particle_6")
print("particle/blood_mist/blood_mist")
print("particle/particle_cloud")
print("-------------------")
end)

