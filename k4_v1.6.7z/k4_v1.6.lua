/*
	Bibzy [STEAM_0:1:20799072 | 72.219.39.92:27005]
	K0N4t4_noa.txt (30011 bytes)
*/

-- K0N4T4 -- Written by Sokyru (Izuumi)/KioFoxx
-- Large amount credit goes to Hyperion for providing the perfect reference for a damn good gmod hack :P
-- Get cslua bypass here (So many thanks to Karniox for this):http://karniox.blogspot.com/search/label/gm
-- Need cvar3(download gmcl_cvar3_win32.dll and put in lua/bin): http://blackawps-glua-modules.googlecode.com/svn/trunk/gm_cvar3/Release/

--***********PATCH NOTES***************
-- Bug fixes.
-- Started on menu. (Actually done stuff this time, thats the whole point of this update)
-- Added AimCheck, WallCheck, and TracerCheck.
-- Speedhack finished. Bind a key to +speedhack, and -speedhack.
-- ************************************

-- *********************************************************
-- Prop detection wallhack is coming at some point.
-- GBinds will be added so that manual binding of commands won't be necessary soon.
-- *********************************************************

--***********KNOWN BUGS****************
-- When Wallhack is turned off, other players turn blue for some reason.
-- www.K0N4T4.us is a parked domain with nothing on it atm.
--------------------------------------------------------------
--There're probably a lot more bugs that I don't know about. If you run into any, please report them to me via Steam.
--Also, if you have any suggestions, give them to me because they may get used. Trying to make this hack awesome.
--*************************************

--**********COMMANDS*******************
--K4_aimbot
--K4_esp
--K4_wallhack
--K4_wallhack_wire
--K4_aimbot_bone <boneNamehere>
--K4_aimbot_onshoot
--K4_aimbot_infov
--K4_aimbot_fov <fovNumHere>
--K4_aimbot_silent
--K4_bhop (useless atm, just bind space to +bhop)
--K4_tracers
--K4_menu(contains nothing during this release)
--************************************


// Little piece of C+P from Hera because I'm lazy.
function AddCMD(Name,Function)
  K0N4T4Print("[ADDED] ConCommand: "..Name.."")
	return old_ccadd(Name,Function)
end

function AddConVar(convar,str,save,data)
	return CreateClientConVar("K4_"..convar,str,true,false), K0N4T4Print("[ADDED] ConVar: K4_"..convar.." ["..str.."]")
end

function K0N4T4Print(msg)
	print("[K0N4T4] "..msg)
end

local g = table.Copy(_G)
--

/***********************
ConVar's
***********************/
local dBotOn     = CreateClientConVar("K4_aimbot", "1", true, false)
local espOn 	 = CreateClientConVar("K4_esp", "1", true, false)
local wallHackOn = CreateClientConVar("K4_wallhack", "1", true, false)
local wHackWire  = CreateClientConVar("K4_wallhack_wire", "0", true, false)
local boneaim    = CreateClientConVar("K4_aimbot_bone", "ValveBiped.Bip01_Head1", true, false)
local K0N4T4     = CreateClientConVar("K4_aimbot_onshoot", "0", true, false)
local infov1     = CreateClientConVar("K4_aimbot_infov", 0, true, false)
local infov2     = CreateClientConVar("K4_aimbot_fov", 90, true, false)
local silentAim  = CreateClientConVar("K4_aimbot_silent", "0", true, false)
local bhop       = CreateClientConVar("K4_bhop", "0", true, false)
local tracers    = CreateClientConVar("K4_ESP_Tracer", "1", true, false)
local menu       = CreateClientConVar("K4_menu", "0", true, false)
local shspeed    = CreateClientConVar("K4_sh_speed", "6.0", true, false)
local removerec  = CreateClientConVar("K4_remove_recoil", "0", true, false)
local logIds     = CreateClientConVar("K4_log_steamids", "1", true, false)
local TalkLogs   = CreateClientConVar("K4_saylogs", "0", true, false)
local EspDist    = CreateClientConVar("K4_ESP_Distance", "180", true, false)
local espBox  	 = CreateClientConVar("K4_ESP_Box", "1", true, false)
local espSkel    = CreateClientConVar("K4_ESP_Skeleton", "1", true, false)
local chamsMat   = CreateClientConVar("K4_ESP_Chams_Material","Solid", true, false)



-- Locals, do not edit. --
local tblDB      = {}
local k	         = table.Copy(_G)
local K4         = {}
local Menu       = {}
      K4.version = "1.6"
local phase      = "Alpha"
local old_ccadd	 = concommand.Add;
local plr        = LocalPlayer()
local TEAM_SPECTATOR 		= 1002
local POSSID = { "STEAM_0:0:45411948", "STEAM_0:0:49922973", "STEAM_0:1:55924920", "STEAM_0:1:20799072", "STEAM_0:0:41674244", "STEAM_0:1:56590487", "STEAM_0:0:33162590", "STEAM_0:1:20305110", "STEAM_0:1:48107578" }
local NOSSID    = { "STEAM_0:1:7099" }
local host       = GetConVarString("ip")
function K4:CreateMaterial()
local BaseInfo = {
["$basetexture"] = "models/debug/debugwhite",
["$model"]       = 1,
["$translucent"] = 1,
["$alpha"]       = 1,
["$nocull"]      = 1,
["$ignorez"]	 = 1
}	
local mat	
if GetConVarString("K4_ESP_Chams_Material") == "Solid" then
	mat = CreateMaterial( "K4_solid", "VertexLitGeneric", BaseInfo )
elseif GetConVarString("K4_ESP_Chams_Material") == "Wireframe" then
	mat = CreateMaterial( "K4_wire", "Wireframe", BaseInfo )
end
   return mat
end



/*
Shortcuts, shortcuts everywhere
*/

local colors				= {}
red							= Color(255,0,0,255);
black						= Color(0,0,0,255);
green						= Color(0,255,0,255);
white						= Color(255,255,255,255);
blue						= Color(0,0,255,255);
cyan						= Color(0,255,255,255);
pink 						= Color(255,0,255,255);
blue						= Color(0,0,255,255);
grey						= Color(100,100,100,255);
gold						= Color(255,228,0,255);
lblue						= Color(155,205,248);
lgreen						= Color(174,255,0);
iceblue						= Color(116,187,251,255);
purple  					= Color(255,0,255,255);



/******************************
Name: Get Admin Type
Purpose: Get Admin Type..
*******************************/
local function GetAdminType(e)
	if e:IsAdmin() && !e:IsSuperAdmin() then
		return " [A] "
	elseif( e:IsSuperAdmin() ) then
		return " [SA] "
	end
	return " "
end

/*************************
Name: Notify
Purpose: Chat functions
Credits: Hera
*************************/

function K4.Notify(dosound,col,msg)
	if col then
		col = col
	end
chat.AddText(
purple, "[K4] ",
col, msg)
	if dosound == sound then
		local beep = Sound( "/buttons/button17.wav" )
		local beepsound = CreateSound( LocalPlayer(), beep )
		beepsound:Play()
	end
end


/*************************
Name: CreatePos
Purpose: Create a position
Credits: BaconBot
***************************/
function CreatePos(v)
local ply = LocalPlayer()
local center = v:LocalToWorld( v:OBBCenter() )
local min, max = v:OBBMins(), v:OBBMaxs()
local dim = max - min	local z = max + min	
local frt	= ( v:GetForward() ) * ( dim.y / 2 )
local rgt	= ( v:GetRight() ) * ( dim.x / 2 )
local top	= ( v:GetUp() ) * ( dim.z / 2 )
local bak	= ( v:GetForward() * -1 ) * ( dim.y / 2 )
local lft	= ( v:GetRight() * -1 ) * ( dim.x / 2 )
local btm	= ( v:GetUp() * -1 ) * ( dim.z / 2 )
local s = 1
local FRT 	= center + frt / s + rgt / s + top / s; FRT = FRT:ToScreen()
local BLB 	= center + bak / s + lft / s + btm / s; BLB = BLB:ToScreen()
local FLT	= center + frt / s + lft / s + top / s; FLT = FLT:ToScreen()
local BRT 	= center + bak / s + rgt / s + top / s; BRT = BRT:ToScreen()
local BLT 	= center + bak / s + lft / s + top / s; BLT = BLT:ToScreen()
local FRB 	= center + frt / s + rgt / s + btm / s; FRB = FRB:ToScreen()
local FLB 	= center + frt / s + lft / s + btm / s; FLB = FLB:ToScreen()
local BRB 	= center + bak / s + rgt / s + btm / s; BRB = BRB:ToScreen()	
local z = 100
if ( v:Health() <= 50 ) then z = 100 end
local x, y = ( ( v:Health() / 100 ) ), 1
if ( v:Health() <= 0 ) then x = 1 end
local FRT3 	= center + frt + rgt + top / x; FRT3 = FRT3; FRT3 = FRT3:ToScreen()
local BLB3 	= center + bak + lft + btm / x; BLB3 = BLB3; BLB3 = BLB3:ToScreen()
local FLT3	= center + frt + lft + top / x; FLT3 = FLT3; FLT3 = FLT3:ToScreen()
local BRT3 	= center + bak + rgt + top / x; BRT3 = BRT3; BRT3 = BRT3:ToScreen()
local BLT3 	= center + bak + lft + top / x; BLT3 = BLT3; BLT3 = BLT3:ToScreen()
local FRB3 	= center + frt + rgt + btm / x; FRB3 = FRB3; FRB3 = FRB3:ToScreen()
local FLB3 	= center + frt + lft + btm / x; FLB3 = FLB3; FLB3 = FLB3:ToScreen()
local BRB3 	= center + bak + rgt + btm / x; BRB3 = BRB3; BRB3 = BRB3:ToScreen()	
local x, y, z = 1.1, 0.9, 1
local FRT2 	= center + frt / y + rgt / z + top / x; FRT2 = FRT2:ToScreen()
local BLB2 	= center + bak / y + lft / z + btm / x; BLB2 = BLB2:ToScreen()
local FLT2	= center + frt / y + lft / z + top / x; FLT2 = FLT2:ToScreen()
local BRT2 	= center + bak / y + rgt / z + top / x; BRT2 = BRT2:ToScreen()
local BLT2 	= center + bak / y + lft / z + top / x; BLT2 = BLT2:ToScreen()
local FRB2 	= center + frt / y + rgt / z + btm / x; FRB2 = FRB2:ToScreen()
local FLB2 	= center + frt / y + lft / z + btm / x; FLB2 = FLB2:ToScreen()
local BRB2 	= center + bak / y + rgt / z + btm / x; BRB2 = BRB2:ToScreen()	
local maxX = math.max( FRT.x,BLB.x,FLT.x,BRT.x,BLT.x,FRB.x,FLB.x,BRB.x )
local minX = math.min( FRT.x,BLB.x,FLT.x,BRT.x,BLT.x,FRB.x,FLB.x,BRB.x )
local maxY = math.max( FRT.y,BLB.y,FLT.y,BRT.y,BLT.y,FRB.y,FLB.y,BRB.y )
local minY = math.min( FRT.y,BLB.y,FLT.y,BRT.y,BLT.y,FRB.y,FLB.y,BRB.y )
local minYhp2 = math.min( FRT.y,BLB.y,FLT.y,BRT.y,BLT.y,FRB.y,FLB.y,BRB.y )
local maxXhp = math.max( FRT3.x,BLB3.x,FLT3.x,BRT3.x,BLT3.x,FRB3.x,FLB3.x,BRB3.x )
local minXhp = math.min( FRT3.x,BLB3.x,FLT3.x,BRT3.x,BLT3.x,FRB3.x,FLB3.x,BRB3.x )
local maxYhp = math.max( FRT3.y,BLB3.y,FLT3.y,BRT3.y,BLT3.y,FRB3.y,FLB3.y,BRB3.y )
local minYhp = math.min( FRT3.y,BLB3.y,FLT3.y,BRT3.y,BLT3.y,FRB3.y,FLB3.y,BRB3.y )	
local maxX2 = math.max( FRT2.x,BLB2.x,FLT2.x,BRT2.x,BLT2.x,FRB2.x,FLB2.x,BRB2.x )
local minX2 = math.min( FRT2.x,BLB2.x,FLT2.x,BRT2.x,BLT2.x,FRB2.x,FLB2.x,BRB2.x )
local maxY2 = math.max( FRT2.y,BLB2.y,FLT2.y,BRT2.y,BLT2.y,FRB2.y,FLB2.y,BRB2.y )
local minY2 = math.min( FRT2.y,BLB2.y,FLT2.y,BRT2.y,BLT2.y,FRB2.y,FLB2.y,BRB2.y )
return maxX, minX, maxY, minY, maxX2, minX2, maxY2, minY2, minYhp, maxYhp
end


-- Initialization stuffs --
/////////////////////////////////////////////////////////
if !table.HasValue(POSSID, LocalPlayer():SteamID()) then
	chat.AddText(
    Color(255,0,255,255), "[ERROR] ",
	Color(255,0,0,0), "Unauthorized UserID Detected. Aborting..." )
surface.PlaySound("buttons/button18.wav") 
return end


if table.HasValue(NOSSID, LocalPlayer():SteamID()) then
	RunConsoleCommand("bind all exit") --hi garry :D
 return end

 ///////////////////////////////////////////////////

chat.AddText(
    Color(255,0,255,255), "[K4] ",
	Color(0,255,0,255), "Version " ..K4.version.. " " ..phase.. " Loaded" )
surface.PlaySound("buttons/button14.wav")

////////////////////////////////////////////////////

function CheckUpdate()
K4.Notify(black,"Checking version.")
	http.Fetch("https://dl.dropbox.com/s/z1ueorym392oez4/check.txt", function(body, len, headers, code) 
		if body == K4.version then 
			K4.Notify(sound,green,"Your version of K0N4T4 is up to date!") 
		else
			K4.Notify(sound,red,"Your version of K0N4T4 is outdated! Please updated to version "..body)
		end 
	end)
end
CheckUpdate()

///////////////////////////////////////////////////

surface.CreateFont( "Logo", { font = "Calibri", size = 100, weight = 700, } )
surface.CreateFont( "Misc", { font = "Calibri", size = 40, weight = 700, } )
surface.CreateFont( "esp", { font = "Arial Black", size = 16, weight = 70 } )
surface.CreateFont("ESPFont",{font = "ScoreboardText", size = 17, weight = 400, antialias = 0})
surface.CreateFont("ESPFont_Small",{font = "Default", size = 12, weight = 200, antialias = 0})
surface.CreateFont("Logo",{font = "akbar", size = 21, weight = 400, antialias = 0})
surface.CreateFont("K4_ScoreboardText",{font = "ScoreboardText", size = 15, weight = 700, antialias = 0})
surface.CreateFont("K4_coolvetica",{font = "ScoreboardText", size = 16, weight = 500, antialias = 0})
surface.CreateFont("K4_hvh",{font = "ScoreboardTextt", size = 15, weight = 1000, antialias = 1})


//SteamID logger, for when you run into an asshole and can't find him again.

function PrintSteamIDS()
	if logIds:GetBool() then
		if not !file.Exists("DATA","steamids.txt") then
			file.Write("steamids.txt","START_LOG")
		end
		for k, v in pairs( player.GetAll() ) do
			str = tostring( os.date() ).. ": | " ..v:Nick().. " | " ..v:SteamID().. " | PING: " ..v:Ping().. " | SERVER : (" ..GetHostName().. ") | MAP :  " ..game.GetMap().. "|\n"
			file.Append("steamids.txt", str)
			print(tostring( os.date() ).. ": | " ..v:Nick().. " | " ..v:SteamID().. " | PING: " ..v:Ping().. " | SERVER : (" ..GetHostName().. ") | MAP :  " ..game.GetMap().. "|\n")

		end
	end
end
PrintSteamIDS()

-- function ChatSteamIDS()
-- 	if TalkLogs:GetBool() then
-- 		for k, v in pairs( player.GetAll() ) do
-- 			RandInt = scareKids[ math.random( #scareKids ) ]
-- 			str = " | " ..v:Nick().. " | " ..v:SteamID().. " | " ..RandInt.. " | PING: " ..v:Ping().. " | SERVER : (" ..GetHostName().. ") | MAP :  " ..game.GetMap().. "|\n"
-- 			RunConsoleCommand("say", str)
-- 		end
-- 	end
-- end

-- ChatSteamIDS()

//Animation Changer, DARKRP ONLY
-- written by sokyru
-- edited by Kio-Foxx
-- original script written by Shinycow

local Enabled = CreateClientConVar("_k4_SwimAnimation", "0", true, false)
local Enabled2 = CreateClientConVar("_k4_Autistic", "0", true, false)
local Enabled3 = CreateClientConVar("_k4_DanceThing", "0", true, false)
local Enabled4 = CreateClientConVar("_k4_Swing", "0", true, false)

concommand.Add("k4_anim",function(ply,cmd,args,str)
	args[1] = string.lower(args[1])
	if(args[1] == "0") then
		RunConsoleCommand("_k4_SwimAnimation", "0")
		RunConsoleCommand("_k4_Autistic", "0")
		RunConsoleCommand("_k4_DanceThing", "0")
		RunConsoleCommand("_k4_Swing", "0")
    elseif(args[1] == "1" or args[1] == "swim" or args[1] == "ground") then
    	RunConsoleCommand("_k4_SwimAnimation", args[2])
    elseif(args[1] == "2" or args[1] == "zombie" or args[1] == "autisim") then
    	RunConsoleCommand("_k4_Autistic", args[2])
    elseif(args[1] == "3" or args[1] == "dance") then
    	RunConsoleCommand("_k4_DanceThing", args[2])
    elseif(args[1] == "4" or args[1] == "swing") then
    	RunConsoleCommand("_k4_Swing", args[2])
    elseif(args[1] == "help") then
    	print([[This is the shortcut command for animation forcing! || 1 = Swim in the ground | 2 = Zombie walk | 3 = Dance | 4 = Swing your arms when you attack. | 0 = Set all to 0]])
    end
end, function()
	return {"k4_anim 1 1","k4_anim 2 1","k4_anim 3 1","k4_anim 4 1", "k4_anim 1 0","k4_anim 2 0","k4_anim 3 0","k4_anim 4 0"}
end)

local function doAnim()
	if Enabled:GetBool() then
		RunConsoleCommand("_DarkRP_DoAnimation", "1627")
	end
end

timer.Create("anim", 1, 0, doAnim)

local function doAutism()
	if Enabled2:GetBool() then
		RunConsoleCommand("_DarkRP_DoAnimation", "1631")
	end
end

timer.Create("anim2", 1, 0, doAutism)

local function doDance()
	if Enabled3:GetBool() then
		RunConsoleCommand("_DarkRP_DoAnimation", "1635")
	end
end

timer.Create("anim3", 8, 0, doDance)

local function doSwing()
	if Enabled4:GetBool() and ( LocalPlayer():KeyPressed(IN_ATTACK) or LocalPlayer():KeyReleased(IN_ATTACK) ) and (!timer.Exists("_k4_timer_delay")) then
		RunConsoleCommand("_DarkRP_DoAnimation", "1633")
		timer.Create("_k4_timer_delay", 1, 1, function() timer.Destroy("_k4_timer_delay") end)
	end
end
hook.Add("Think", "_k4_swing_hook", doSwing())

// Derma Crahp

concommand.Add("+dmenu", function()

local DButton = vgui.Create( "DNumSlider" )
     DButton:SetMin(0)
	 DButton:SetMax(25)
	 DButton:SetPos( 700, 350 )
     DButton:SetText( "Player Speed" )
     DButton:SetSize( 120, 10 )
	 DButton:SetConVar("K4_sh_speed")
	 DButton:MakePopup()

local hud = function()	 
		draw.RoundedBox(10, 635, ScrH() - 565 - 300, 650, 650, Color(25,25,25,200))
		draw.DrawText("K0N4T4", "Logo", 700, 220, Color(255, 255, 255, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT)
		draw.DrawText("V1", "Logo", 1120, 220, Color(255, 0, 0, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT)
	end
end)

function DRemove()
	concommand.Remove("+dmenu")
end

concommand.Add("-dmenu", DRemove)

--Speedhack, now works! :D

require("cvar3")
 
TS = GetConVar('host_timescale')
CH = GetConVar('sv_cheats')

function speedon()
	speed = GetConVarNumber("K4_sh_speed")
	CH:SetValue( 1.0 )
	TS:SetValue( speed )
end
 
function speedoff()
	CH:SetValue(0)
end
 
concommand.Add("+speedhack", speedon)
concommand.Add("-speedhack", speedoff)


hook.Add("HUDPaint", "K0N4T4Watermark", function()
	draw.DrawText("K0N4T4 V1", "Misc", 10, 10, Color(255, 255, 255, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT)
end)

local function IsVisible( ent ) /* Huge credits to whoever made this tracer function! */
	local tracer = {}
	if(LocalPlayer():GetShootPos() != nil && ent:IsValid() && ent != nil && LocalPlayer():GetActiveWeapon():IsValid() && LocalPlayer():GetActiveWeapon() != nil && ent:LookupBone("ValveBiped.Bip01_Head1") != nil && ent:GetBonePosition(ent:LookupBone("ValveBiped.Bip01_Head1")) != nil) then
		tracer.start = LocalPlayer():GetShootPos()
		tracer.endpos = ent:GetBonePosition(ent:LookupBone("ValveBiped.Bip01_Head1"))
		tracer.filter = { LocalPlayer(), ent }
		tracer.mask = MASK_SHOT
		local trace = util.TraceLine( tracer )
		if trace.Fraction >= 1 then return true else return false end
	end
end

local function InFov(ent)
	for k,v in pairs(ents.FindInCone(LocalPlayer():GetShootPos(), LocalPlayer():GetAimVector(), 3000, GetConVarNumber("K4_aim_fov")))  do
		if(v:IsPlayer() && ent == v) then
			return true
		else
			return false
		end
	end
end

local function WHCheck(v)
	if v:Alive() == true && v:Health() ~= 0 && v:Health() >= 0 && v ~= LocalPlayer() && LocalPlayer():Alive() then
		return true
	else
		return false
	end
end

--[[
 CRAPAIM: Crap aimbot I based off of dead's. It's complete crap to say the least.
]]--

local function K0N4T4Aim()
        for k,v in pairs(player.GetAll()) do
                local bone = tostring(boneaim:GetString())
                if IsVisible( v ) and LocalPlayer():Alive() and v:Alive() and v ~= LocalPlayer() and v:Team() ~= TEAM_SPECTATOR and LocalPlayer():Team() ~= TEAM_SPECTATOR and GetConVarNumber("K4_aimbot") == 1 and LocalPlayer():GetActiveWeapon():GetClass() ~= "weapon_physgun" and LocalPlayer():GetActiveWeapon():GetClass() ~= "gmod_tool" and LocalPlayer():GetActiveWeapon():GetClass() ~= "gmod_camera" and LocalPlayer():GetActiveWeapon():GetClass() ~= "weapon_crowbar" then
                        if GetConVarNumber("K4_aimbot_onshoot") >= 1 then
                                if LocalPlayer():KeyDown(IN_ATTACK) then
                                        if(GetConVarNumber("K4_aimbot_infov") == 1) then
                                                if(InFov(v)) then
                                                        local head = v:LookupBone(bone)
                                                        local headpos,targetheadang = v:GetBonePosition(head)
                                                        LocalPlayer():SetEyeAngles((headpos - LocalPlayer():GetShootPos()):Angle())
                                                end
                                        else
                                                local head = v:LookupBone(bone)
                                                local headpos,targetheadang = v:GetBonePosition(head)
                                                LocalPlayer():SetEyeAngles((headpos - LocalPlayer():GetShootPos()):Angle())
                                        end
                                end
                        else
                                if(GetConVarNumber("K4_aimbot_infov") == 1) then
                                        if(InFov(v)) then
                                                local head = v:LookupBone(bone)
                                                local headpos,targetheadang = v:GetBonePosition(head)
                                                LocalPlayer():SetEyeAngles((headpos - LocalPlayer():GetShootPos()):Angle())
                                        end
                                else
                                        local head = v:LookupBone(bone)
                                        local headpos,targetheadang = v:GetBonePosition(head)
                                        LocalPlayer():SetEyeAngles((headpos - LocalPlayer():GetShootPos()):Angle())
                                end
                        end
                end
        end
end
hook.Add("Think", "K0N4T4Aim", K0N4T4Aim)

--[[ AIMBOT: C+P from K4 V4 until I feel like writing an undetected one like this huehueuhue. 
	Doesn't even work yet, need to rewrite and fix.
]]--

--Silent Aimbot
function aimbot()
	if silentAim:GetBool() then
		local ply = LocalPlayer() 
		local trace = util.GetPlayerTrace( ply )
		local traceRes = util.TraceLine( trace )
		if traceRes.HitNonWorld then 
			local target = traceRes.Entity
			if target:IsPlayer() then 
				local targethead = target:LookupBone("ValveBiped.Bip01_Head1") 
				local targetheadpos,targetheadang = target:GetBonePosition(targethead) 
				ply:SetEyeAngles((targetheadpos - ply:GetShootPos()):Angle()) 
			end
		end
	end
end
hook.Add("Think","aimbot",aimbot) 

--No Recoil
function NoRec()
	if GetConVarNumber("K4_remove_recoil") == 1 then
		if LocalPlayer():GetActiveWeapon().Primary then
			LocalPlayer():GetActiveWeapon().Primary.Recoil = 0
		end
	end
end

hook.Add("Think", "recoil", NoRec)

-- Esp --
local function K0N4T4Esp()
	if espOn:GetBool() then
		for k, e in pairs (player.GetAll() ) do
			local maxX, minX, maxY, minY, maxX2, minX2, maxY2, minY2, minYhp, maxYhp = CreatePos( e )
			local Name = e:Nick()
			local TeamColor = team.GetColor(e:Team())
			local HPColor = Color(255,255,255,255)
			local Dist = e:GetPos():Distance(LocalPlayer():GetPos());
			local wep = "Unknown"
			local ESP = (e:EyePos()):ToScreen()
			if e:GetActiveWeapon() and e:GetActiveWeapon():IsValid() then
				wep = e:GetActiveWeapon():GetPrintName()
					if e == LocalPlayer() then Name = "" else Name = e:Nick()
									draw.SimpleTextOutlined( Name..GetAdminType(e), "K4_coolvetica", maxX2, minY2, TeamColor,4,1,1,Color(0,0,0))
									draw.SimpleTextOutlined( "H: " .. e:Health(), "ESPFont_Small", maxX2, minY2 + 10, HPColor, 4,1, 1, black )
									draw.SimpleTextOutlined( "D: " .. math.floor(Dist), "ESPFont_Small", maxX2, minY2 + 20, iceblue, 4, 1, 1, black )
									draw.SimpleTextOutlined( "W: " .. wep, "ESPFont_Small", maxX2, minY2 + 30, iceblue, 4, 1, 1, black)
									if e:GetFriendStatus() == "friend" then
										draw.SimpleTextOutlined( "[Friend]", "ESPFont_Small", maxX2, minY2 - 10, iceblue, 4, 1,1,black)
									end
										if e:IsAdmin() && !e:IsSuperAdmin() then
											draw.SimpleText("[Admin]","ESPFont_Small",maxX2,minY2 -20,cyan,4,1,1,black)
										end
										if e:IsSuperAdmin() then
											draw.SimpleText("[Super Admin]", "ESPFont_Small",maxX2,minY2 -20,white,4,1,1,black)
										end

							if GetConVarNumber("K4_ESP_Box") == 1 then
								surface.SetDrawColor(0,0,255,255)				
								surface.DrawLine( maxX, maxY, maxX, minY )
								surface.DrawLine( maxX, minY, minX, minY )					
								surface.DrawLine( minX, minY, minX, maxY )
								surface.DrawLine( minX, maxY, maxX, maxY )
							end



							local bones = {
							{ S = "ValveBiped.Bip01_Head1", E = "ValveBiped.Bip01_Neck1" },
							{ S = "ValveBiped.Bip01_Neck1", E = "ValveBiped.Bip01_Spine4" },
							{ S = "ValveBiped.Bip01_Spine4", E = "ValveBiped.Bip01_Spine2" },
							{ S = "ValveBiped.Bip01_Spine2", E = "ValveBiped.Bip01_Spine1" },
							{ S = "ValveBiped.Bip01_Spine1", E = "ValveBiped.Bip01_Spine" },
							{ S = "ValveBiped.Bip01_Spine", E = "ValveBiped.Bip01_Pelvis" },
							
							{ S = "ValveBiped.Bip01_Spine4", E = "ValveBiped.Bip01_L_UpperArm" },
							{ S = "ValveBiped.Bip01_L_UpperArm", E = "ValveBiped.Bip01_L_Forearm" },
							{ S = "ValveBiped.Bip01_L_Forearm", E = "ValveBiped.Bip01_L_Hand" },

							{ S = "ValveBiped.Bip01_Spine4", E = "ValveBiped.Bip01_R_UpperArm" },
							{ S = "ValveBiped.Bip01_R_UpperArm", E = "ValveBiped.Bip01_R_Forearm" },
							{ S = "ValveBiped.Bip01_R_Forearm", E = "ValveBiped.Bip01_R_Hand" },

							{ S = "ValveBiped.Bip01_Pelvis", E = "ValveBiped.Bip01_L_Thigh" },
							{ S = "ValveBiped.Bip01_L_Thigh", E = "ValveBiped.Bip01_L_Calf" },
							{ S = "ValveBiped.Bip01_L_Calf", E = "ValveBiped.Bip01_L_Foot" },
							{ S = "ValveBiped.Bip01_L_Foot", E = "ValveBiped.Bip01_L_Toe0" },

							{ S = "ValveBiped.Bip01_Pelvis", E = "ValveBiped.Bip01_R_Thigh" },
							{ S = "ValveBiped.Bip01_R_Thigh", E = "ValveBiped.Bip01_R_Calf" },
							{ S = "ValveBiped.Bip01_R_Calf", E = "ValveBiped.Bip01_R_Foot" },
							{ S = "ValveBiped.Bip01_R_Foot", E = "ValveBiped.Bip01_R_Toe0" },
							}
							if GetConVarNumber("K4_ESP_Skeleton") == 1 then
								for k, v in pairs( bones ) do
									local sPos, ePos = e:GetBonePosition( e:LookupBone( v.S ) ):ToScreen(), e:GetBonePosition( e:LookupBone( v.E ) ):ToScreen()
										if e:IsPlayer() and !e:IsNPC() then
											surface.SetDrawColor(team.GetColor(e:Team()))
										end
									surface.DrawLine(sPos.x,sPos.y,ePos.x,ePos.y)
								end
							end

							if GetConVarNumber("K4_ESP_Tracer") == 1 then	
								cam.Start3D( EyePos() , EyeAngles())
								render.SetMaterial( Material( "trails/laser" ) )
								StartPos = LocalPlayer():GetActiveWeapon():GetPos()
								EndPos = e:GetBonePosition(e:LookupBone("ValveBiped.Bip01_Head1"))
								render.DrawBeam(StartPos, EndPos , 3, 0, 0, Color(0,255,0,255))
								cam.End3D()
							end
					end
				end
			end
		end
	end
	

hook.Add ("HUDPaint", "esp", K0N4T4Esp)


-- Wallhack

function IsCloseEnough(ent)
	local dist = ent:GetPos():Distance( LocalPlayer():GetPos() )
	if( dist <= GetConVarNumber("K4_ESP_Distance") and ent:GetPos() != Vector( 0, 0, 0 ) ) then
		return true
	end
	return false	
end

function Chams()
local mat = K4:CreateMaterial()
	if GetConVarNumber("K4_wallhack") == 1 then
		for k,v in pairs(player.GetAll()) do
			local TCol = team.GetColor(v:Team())
			if IsValid(v) and v:Health() > 0 and v:Team() != TEAM_SPECTATOR and IsCloseEnough(v) then
			//Players
			cam.Start3D(EyePos(),EyeAngles())
			render.SuppressEngineLighting( false )
			render.SetColorModulation( ( TCol.r * ( 1 / 255 ) ), ( TCol.g * ( 1 / 255 ) ), ( TCol.b * ( 1 / 255 ) ) )
			render.MaterialOverride( mat )
			v:DrawModel()
			render.SuppressEngineLighting( false )
			render.SetColorModulation(1,1,1)
			render.MaterialOverride( )
			v:DrawModel()
			cam.End3D()
			end
		end
	end
end

local IsLock = false;



-- Bhop --
	if CLIENT then
		concommand.Add("+bhop",function()
			hook.Add("Think","hook",function()
				RunConsoleCommand(((LocalPlayer():IsOnGround() or LocalPlayer():WaterLevel() > 0) and "+" or "-").."jump")
			end)
		end)

		concommand.Add("-bhop",function()
			RunConsoleCommand("-jump")
			hook.Remove("Think","hook")
		end)
	end

--[[
HUD SHIT
]]--

--Below is aimbot status check

hook.Add("HUDPaint", "AimStatus", function()
	draw.DrawText("Aimbot: ", "Misc", 1700, 10, Color(255, 255, 255, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT)
end)

function AimCheck()
	if GetConVarNumber("K4_aimbot") >= 1 then
		hook.Remove("HUDPaint", "DAimStatus2")
		hook.Add("HUDPaint", "DAimStatus1", function()
			draw.DrawText("On", "Misc", 1815, 10, Color(79, 225, 38, 107), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT)
		end)
	elseif GetConVarNumber("K4_aimbot") < 1 then
		hook.Remove("HUDPaint", "DAimStatus1")
		hook.Add("HUDPaint", "DAimStatus2", function()
			draw.DrawText("Off", "Misc", 1815, 10, Color(255, 0, 0, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT)
		end)
	end
end

hook.Add("Think", "AimCheck", AimCheck)


-- Below is Wallhack status check

hook.Add("HUDPaint", "WHStatus", function()
	draw.DrawText("Wallhack: ", "Misc", 1700, 50, Color(255, 255, 255, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT)
end)

function WallCheck()
	if GetConVarNumber("K4_wallhack") >= 1 then
		hook.Remove("HUDPaint", "WHStatus2")
		hook.Add("HUDPaint", "WHStatus1", function()
			draw.DrawText("On", "Misc", 1840, 50, Color(79, 225, 38, 107), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT)
		end)
	elseif GetConVarNumber("K4_wallhack") < 1 then
		hook.Remove("HUDPaint", "WHStatus1")
		hook.Add("HUDPaint", "WHStatus2", function()
			draw.DrawText("Off", "Misc", 1840, 50, Color(255, 0, 0, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT)
		end)
	end
end

hook.Add("Think", "WallCheck", WallCheck)

-- Below is Tracers Check

hook.Add("HUDPaint", "TracerStatus", function()
	draw.DrawText("Tracers: ", "Misc", 1700, 90, Color(255, 255, 255, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT)
end)

function TracerCheck()
	if GetConVarNumber("K4_tracers") >= 1 then
		hook.Remove("HUDPaint", "TStatus2")
		hook.Add("HUDPaint", "TStatus1", function()
			draw.DrawText("On", "Misc", 1815, 90, Color(79, 225, 38, 107), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT)
		end)
	elseif GetConVarNumber("K4_tracers") < 1 then
		hook.Remove("HUDPaint", "TStatus1")
		hook.Add("HUDPaint", "TStatus2", function()
			draw.DrawText("Off", "Misc", 1815, 90, Color(255, 0, 0, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT)
		end)
	end
end

hook.Add("Think", "TracerCheck", TracerCheck)

--Spawnprotection timer, for F2S:Stronghold, does not work.

function SPTimer()
	hook.Add("HUDPaint", "SpProtect4", function()
		draw.DrawText("4", "Misc", 1815, 90, Color(255, 0, 0, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT)
	end)
	sleep(1000)
	hook.Remove("HUDPaint", "SpProtect4")
	hook.Add("HUDPaint", "SpProtect3", function()
		draw.DrawText("3", "Misc", 1815, 90, Color(255, 0, 0, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT)
	end)
	sleep(1000)
	hook.Remove("HUDPaint", "SpProtect3")
	hook.Add("HUDPaint", "SpProtect2", function()
		draw.DrawText("2", "Misc", 1815, 90, Color(255, 0, 0, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT)
	end)
	sleep(1000)
	hook.Remove("HUDPaint", "SpProtect2")
	hook.Add("HUDPaint", "SpProtect1", function()
		draw.DrawText("2", "Misc", 1815, 90, Color(255, 0, 0, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT)
	end)
	sleep(1000)
	hook.Remove("HUDPaint", "SpProtect1")
end

hook.Add("PlayerSpawn", "SpawnProtectTime", SPTimer)


function hooks_postdraw()
Chams();
end

hook.Add("PostDrawEffects", "test", hooks_postdraw)

