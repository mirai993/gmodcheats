////////////////////////////
// fixed by paradox       //
local ply = LocalPlayer() // remove this line if you want the orignal code
////////////////////////////



surface.CreateFont( "CR", { font = "Arial", size = 14, weight = 750, antialias = false, outline = true } );
Chams = CreateMaterial( "Mat", "VertexLitGeneric", { ["$basetexture"] = "models/debug/debugwhite", ["$model"] = 1, ["$ignorez"] = 1 } )

hook.Add( "HUDPaint", "WaterMark", function()
	
	local h = ScrH() / 2
	local w = ScrW() / 2
	draw.SimpleTextOutlined( "Cyan", "DermaLarge", w - 29, h / 16, Color( 0, 255, 255 ), 1, 1, 1, Color( 0, 0, 0 ) )
	draw.SimpleTextOutlined( "Red", "DermaLarge", w + 29, h / 16, Color( 255, 0, 0 ), 1, 1, 1, Color( 0, 0, 0 ) )
	
end)

hook.Add( "HUDPaint", "ESPBoxChams", function()
 
	for k,v in pairs ( player.GetAll() ) do
		
		if v ~=LocalPlayer() and v:Alive() and v:IsValid() and v:Health() >= 1 then
		
			local ply = LocalPlayer()
			local origin = v:GetPos()
			local top = v:OBBMaxs()
			local bottom = v:OBBMins()
			local eye = v:EyeAngles()
			
			cam.Start3D()
					render.DrawWireframeBox( origin, Angle( 0, eye.y, 0), bottom, top, Color( 255, 0, 0 ) )
					render.MaterialOverride( Chams );
					render.SuppressEngineLighting( true )
					render.SetColorModulation( 0, 255, 255 )
					v:DrawModel();
					if ply then
					render.SuppressEngineLighting( false )
					end
					if v:IsValid( v:GetActiveWeapon() ) then
						render.SetColorModulation( 255, 0, 0 )
						v:GetActiveWeapon():DrawModel()
					end
			cam.End3D()
			
		end
	end
end)

hook.Add( "HUDPaint", "CrossHair", function()

		local h = ScrH() / 2
		local w = ScrW() / 2
		local h1 = ScrH() / 2 - 1
		local w1 = ScrW() / 2 - 1
		
		surface.SetDrawColor( 0, 255, 255 )
		surface.DrawLine( w + 11, h, w - 11, h )
		surface.DrawLine( w, h + 11, w, h - 11 )
		
end)

hook.Add( "EntityFireBullets", "NoSpread",function(ent,bullet)

		bullet.Spread = Vector(0,0,0)
	
	return true
end)

hook.Add( "HUDPaint", "PlayerInfo", function()
	
	for k,v in pairs ( player.GetAll() ) do
		
		if v ~=LocalPlayer() and v:Alive() and v:IsValid() and v:Health() > 0 then
		
			local origin = v:GetPos()
			local pos = ( origin + Vector( 0, 0, 90 )):ToScreen()
			local getName = "Name: " .. v:Nick()
			local getHealth = "Health: " .. v:Health()
			local getWeapon = "Weapon: " .. v:GetActiveWeapon():GetPrintName()
			local ply = LocalPlayer()

			draw.SimpleTextOutlined( getName, "CR", pos.x, pos.y, Color( 255, 255, 255 ), 1, 1, 1, Color( 0, 0, 0 ) )
			draw.SimpleTextOutlined( getHealth, "CR", pos.x, pos.y + 15, Color( 255, 0, 0 ), 1, 1, 1, Color( 0, 0, 0 ) )
			draw.SimpleTextOutlined( getWeapon, "CR", pos.x, pos.y + 30, Color( 0, 255, 255 ), 1, 1, 1, Color( 0, 0, 0 ) )
			draw.SimpleTextOutlined( getWeapon, "CR", pos.x, pos.y + 30, Color( 0, 255, 255 ), 1, 1, 1, Color( 0, 0, 0 ) )
			
		end
	end
end)

hook.Add( "Think", "BunnyHop", function()
	local bhop = false

	if input.IsKeyDown( KEY_SPACE ) and ply:IsOnGround() then
		
		RunConsoleCommand( "+jump" )
		bhop = true
		
	else
	
		RunConsoleCommand( "-jump" )
		bhop = false
		
	end
end)

hook.Add( "Think", "Aimbot", function()

	for k,v in pairs ( player.GetAll() ) do
	
			if v:Alive() and v:IsValid() then
		
				local head = v:LookupBone("ValveBiped.Bip01_Head1")
				local headpos,headang = v:GetBonePosition(head)
			
				if input.IsKeyDown( KEY_LALT ) then
		
				ply:SetEyeAngles((headpos - ply:GetShootPos()):Angle())
		
			end
		end
	end
end)

