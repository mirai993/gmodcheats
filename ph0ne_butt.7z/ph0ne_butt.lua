--[[==================================================================
** Coded by ph0ne
** Credits:
	+ aVoN, C0BRA, Flapadar, fr1kin, noPE, RabidToaster, victormeriqui
	+ wiki.garrysmod.com - For when all else fails.
==================================================================]]--

--[[--------------------------------------------
	INITIALIZATION
	Desc: Start shit.
--]]--------------------------------------------

if !CLIENT then return end
if C then _G.C = nil end

local C     = {}
C.commands  = {}
C.cones     = {}
C.convars   = {}
C.detours	= {}
C.hooks     = {}
C.info		= {}
C.modules   = {}
C.set	    = {}
C.world	    = { players = {}, entities = {} }
C.spread 	= { vec = {} }

--[[--------------------------------------------
	LOCAL COPIES
	Desc: Make shit faster, create overrides.
--]]--------------------------------------------

local oC  = table.Copy( cvars )
local oCA = table.Copy( cam )
local oDR = table.Copy( draw )
local oF  = table.Copy( file )
local oG  = table.Copy( _G )
local oH  = table.Copy( hook )
local oM  = table.Copy( math )
local oR  = table.Copy( render )
local oS  = table.Copy( string )
local oSU = table.Copy( surface )
local oT  = table.Copy( timer )
local oU  = table.Copy( util )
local oV  = table.Copy( vgui )

local AngM = table.Copy( _R["Angle"] || {} )
local CmdM = table.Copy( _R["CUserCmd"] || {} )
local ConM = table.Copy( _R["ConVar"] || {} )
local EntM = table.Copy( _R["Entity"] || {} )
local PlyM = table.Copy( _R["Player"] || {} )
local VecM = table.Copy( _R["Vector"] || {} )

local Angle 	= Angle
local Color 	= Color
local EyeAngles = EyeAngles
local EyePos 	= EyePos
local pairs 	= pairs
local tonumber  = tonumber
local tostring  = tostring
local type 		= type
local Vector 	= Vector

--[[--------------------------------------------
	VARS
	Desc: Make it so I can store more data.
--]]--------------------------------------------

C.vars = {
	oldsilentval = 0,
	aimtarg		 = nil,
	aimlocked    = false,
	pkfake 	     = false,
	pkthrow 	 = false,
	firing  	 = false,
	found 	     = false,
	aimingang    = Angle( 0, 0, 0 ), -- Nospread correction/aimbot target.
	aacorrectang = Angle( 0, 0, 0 ), -- Anti-aim correction.
	antiaimang   = Angle( 0, 0, 0 ), -- Random PYR angles.
	fakeang 	 = Angle( 0, 0, 0 ), -- Silent aim.
	pkfakeang    = Angle( 0, 0, 0 ), -- Propkilling fake 180 view.
	pkthrowang   = Angle( 0, 0, 0 ), -- Propkilling real view.
	recoilang    = Angle( 0, 0, 0 ), -- No visual recoil.
	path 	 	 = "lua\\autorun\\client\\ph0ne.lua",
	prefix	     = "ph0ne_"
}

--[[--------------------------------------------
	FILES
	Desc: Protect filenames with a table.
--]]--------------------------------------------

C.files = {
	"ph0ne.lua", "ph0ne",
	"gmcl_sys.dll", "sys",
	"gmcl_ph0nage.dll", "ph0nage"
}

for _, v in pairs( C.files ) do
	C.modules[v] = v
end

--[[--------------------------------------------
	DETOURS
	Desc: Act like I'm not cheating.
--]]--------------------------------------------

function C:detour( old, new ) -- Big thanks to noPE.
	C.detours[new] = old
	return new
end

debug.getinfo = C:detour( debug.getinfo, function( func, thread )
	return C.detours[debug.getinfo]( C.detours[func] || func, thread )
end )

debug.getupvalue = C:detour( debug.getupvalue, function( func, up )
	return C.detours[debug.getinfo]( C.detours[func] || func, up )
end )

concommand.Run = C:detour( concommand.Run, function( pl, name, ... )
	local tbl = C.commands[name]
	if ( tbl != nil ) then
		return tbl.func( pl, name, ... )
	else
		return C.detours[concommand.Run]( pl, name, ... )
	end
end )

--[[--------------------------------------------
	ANTI-DETECTION / OVERRIDES
	Desc: Fool shitty anticheats.
--]]--------------------------------------------

function require( module )
	local callpath = debug.getinfo(2)['short_src']
	if callpath && ( callpath == C.vars.path ) then return oG.require( module ) end
	for k, v in pairs( C.modules ) do
		if oS.find( oS.lower( module ), v ) then return end
	end
	return oG.require( module )
end

function cvars.AddChangeCallback( cvar, callback )
	local callpath = debug.getinfo(2)['short_src']
	if callpath && ( callpath == C.vars.path ) then return oC.AddChangeCallback( cvar ) end
	for k, v in pairs( C.convars ) do
		if oS.find( oS.lower( cvar ), v ) then return end
	end
	if ( cvar == "host_framerate" ) then return 0 end
	return oC.AddChangeCallback( cvar, callback )
end

function GetConVar( cvar )
	local callpath = debug.getinfo(2)['short_src']
	if callpath && ( callpath == C.vars.path ) then return oG.GetConVar( cvar ) end
	for k, v in pairs( C.convars ) do
		if oS.find( oS.lower( cvar ), v ) then return end
	end
	return oG.GetConVar( cvar )
end

function ConVarExists( cvar )
	local callpath = debug.getinfo(2)['short_src']
	if callpath && ( callpath == C.vars.path ) then return oG.ConVarExists( cvar ) end
	for k, v in pairs( C.convars ) do
		if oS.find( oS.lower( cvar ), v ) then return end
	end
	return oG.ConVarExists( cvar )
end

function GetConVarNumber( cvar )
	local callpath = debug.getinfo(2)['short_src']
	if callpath && ( callpath == C.vars.path ) then return oG.GetConVarNumber( cvar ) end
	for k, v in pairs( C.convars ) do
		if oS.find( oS.lower( cvar ), v ) then return end
	end
	if ( cvar == "host_framerate" ) then return 0 end
	return oG.GetConVarNumber( cvar )
end

function GetConVarString( cvar )
	local callpath = debug.getinfo(2)['short_src']
	if ( callpath && callpath == C.vars.path ) then return oG.GetConVarString( cvar ) end
	for k, v in pairs( C.convars ) do
		if oS.find( oS.lower( cvar ), v ) then return end
	end
	if ( cvar == "host_framerate" ) then return "0" end
	return oG.GetConVarString( cvar )
end

function _R.ConVar.GetInt( cvar )
	local callpath = debug.getinfo(2)['short_src']
	if callpath && ( callpath == C.vars.path ) then return ConM.GetInt( cvar ) end
	for k, v in pairs( C.convars ) do
		if ( oS.find( oS.lower( cvar:GetName() ), v ) ) then return end
	end
	if ( cvar:GetName() == "host_framerate" ) then return 0 end
	return ConM.GetInt( cvar )
end

function _R.ConVar.GetBool( cvar )
	local callpath = debug.getinfo(2)['short_src']
	if callpath && ( callpath == C.vars.path ) then return ConM.GetBool( cvar ) end
	for k, v in pairs( C.convars ) do
		if ( oS.find( oS.lower( cvar:GetName() ), v ) ) then return end
	end
	if ( cvar:GetName() == "host_framerate" ) then return false end
	return ConM.GetBool( cvar )
end

function file.Read( path, bool )
	local callpath = debug.getinfo(2)['short_src']
	if callpath && ( callpath == C.vars.path ) then return oF.Read( path, bool ) end
	for k, v in pairs( C.modules ) do
		if oS.find( oS.lower( path ), v ) then return nil end
	end
	return oF.Read( path, bool )
end

function file.Exists( path, bool )
	local callpath = debug.getinfo(2)['short_src']
	if callpath && ( callpath == C.vars.path ) then return oF.Exists( path, bool ) end
	for k, v in pairs( C.modules ) do
		if oS.find( oS.lower( path ), v ) then return nil end
	end
	return oF.Exists( path, bool )
end

function file.ExistsEx( path , addons )
	local callpath = debug.getinfo(2)['short_src']
	if callpath && ( callpath == C.vars.path ) then return oF.ExistsEx( path, addons ) end
	for k, v in pairs( C.modules ) do
		if oS.find( oS.lower( path ), v ) then return nil end
	end
	return oF.ExistsEx( path, addons )
end

function file.Write( path, cont, ... )
	local callpath = debug.getinfo(2)['short_src']
	if callpath && ( callpath == C.vars.path ) then return oF.Write( path, cont, ... ) end
	for k, v in pairs( C.modules ) do
		if oS.find( oS.lower( path ), v ) then return nil end
	end
	return oF.Write( path, cont, ... )
end

function file.Time( path )
	local callpath = debug.getinfo(2)['short_src']
	if callpath && ( callpath == C.vars.path ) then return oF.Time( path ) end
	for k, v in pairs( C.modules ) do
		if oS.find( oS.lower( path ), v ) then return 0 end
	end
	return oF.Time( path )
end

function file.Size( path )
	local callpath = debug.getinfo(2)['short_src']
	if callpath && ( callpath == C.vars.path ) then return oF.Size( path ) end
	for k, v in pairs( C.modules ) do
		if oS.find( oS.lower( path ), v ) then return -1 end
	end
	return oF.Size( path )
end

function file.Find( path, bool )
	local callpath = debug.getinfo(2)['short_src']
	if callpath && ( callpath == C.vars.path ) then return oF.Find( path, bool ) end
	for k, v in pairs( C.modules ) do
		if oS.find( oS.lower( path ), v ) then oF.Find[k] = nil end
	end
	return oF.Find( path, bool )
end

function file.FindInLua( path, bool )
	local callpath = debug.getinfo(2)['short_src']
	if callpath && ( callpath == C.vars.path ) then return oF.FindInLua( path, bool ) end
	for k, v in pairs( C.modules ) do
		if oS.find( oS.lower( path ), v ) then oF.FindInLua[k] = nil end
	end
	return oF.FindInLua( path, bool )
end

function file.TFind( name, call )
	local callpath = debug.getinfo(2)['short_src']
	if callpath then
		return oF.TFind( name, function( name, folder, files )
			for k, v in pairs( folder ) do
				for _, e in pairs( C.modules ) do
					if oS.find( oS.lower( e ), v ) then folder[k] = nil end
				end
			end
			for k, v in pairs( files ) do
				for _, e in pairs( C.modules ) do
					if oS.find( oS.lower( e ), v ) then files[k] = nil end
				end
			end
			return call( path, folder, files )
		end )
	end
	return oF.TFind( name, function( path, folder, files ) 
		return call( path, folder, files )
	end )
end

--[[--------------------------------------------
	HOOKING
	Desc: Put the HEAT in CHEAT.
--]]--------------------------------------------

function hook.Call( name, gm, ... )
	local ret
	for k, v in pairs( C.hooks ) do
		if ( v.name == name ) then
			if ( ... == nil ) then
				ret = v.func()
			else
				ret = v.func( ... )
			end
			if ( ret != nil ) then return ret end
		end
	end
	return oH.Call( name, gm, ... )
end

function C:randstring()
	local rand = ""
	for i = 1, oM.random( 4, 10 ) do
		local add = oM.random( 65, 116 )
		if ( add >= 91 ) && ( add <= 96 ) then
			add = add + 6
		end
		rand = rand .. oS.char( add )
	end
	return rand
end

function C:addhook( name, func )
	local id = C:randstring()
	C.hooks[id] = { name = name, func = func }
end

--[[--------------------------------------------
	CONCOMMANDS
	Desc: Provide quick access.
--]]--------------------------------------------

function engineConsoleCommand( p, c, a )
	local str = oS.lower( c )
	if C.commands[str] then C.commands[str]( p, c, a ); return true end
	return oG.engineConsoleCommand( p, c, a )
end

function C:addcommand( name, func )
	C.commands[name] = func
	oG.AddConsoleCommand( name )
end

--[[--------------------------------------------
	BINARY MODULES
	Desc: Provide added C++ functionality.
--]]--------------------------------------------

if !hack || ( type( hack ) != "table" ) then
	require( "sys" )
end

if package.loaded.sys then
	C.hack = table.Copy( hack )
	_G.hack = nil
	package.loaded.sys = nil
end

if !cheat || ( type( cheat ) != "table" ) then
	require( "ph0nage" )
end

if package.loaded.ph0nage then
	C.cheat = table.Copy( cheat )
	_G.cheat = nil
	package.loaded.ph0nage = nil
end

C.cheat.ColorMsg( "\n:: ", Color( 255, 255, 255 ) )
C.cheat.ColorMsg( "CBaseAimbot initialized, now loading...\n", Color( 255, 0, 0 ) )

--[[--------------------------------------------
	CONVARS
	Desc: Make it so I decide how I wanna roll.
--]]--------------------------------------------

/*

function C:CreateConVar( cvar, val, name )
	local convar = oG.CreateClientConVar( C.vars.prefix .. cvar, val, true, false )
	if ( type( val ) == "number" ) then C.set[name] = ConM.GetInt( convar ) end
	table.insert( C.convars, C.vars.prefix .. cvar )
	oC.AddChangeCallback( C.vars.prefix .. cvar, function( cvar, old, new ) C.set[name] = new end )
	return convar
end

C:CreateConVar( "aim", 0, "aim" )
C:CreateConVar( "aim_silent", 0, "aimsilent" )
C:CreateConVar( "aim_team", 1, "aimteam" )
C:CreateConVar( "aim_ignoreadmins", 1, "ignoreadmins" )
C:CreateConVar( "aim_ignorefriendlytraitors", 1, "ignoretraitors" )
C:CreateConVar( "aim_ignorefriends", 1, "ignorefriends" )
C:CreateConVar( "aim_snaponfire", 0, "snaponfire" )
C:CreateConVar( "aim_autoshoot", 0, "autoshoot" )
C:CreateConVar( "aim_ignorevisibility", 0, "ignorevisibility" )
C:CreateConVar( "aim_obbcenter", 0, "useobb" )
C:CreateConVar( "aim_nospread", 1, "nospread" )
C:CreateConVar( "aim_comp", 1, "velocitycomp" )
C:CreateConVar( "aim_comp_val", 66, "compval" )
C:CreateConVar( "aim_fov", 180, "aimfov" )
C:CreateConVar( "aim_offset", 0, "aimoffset" )
C:CreateConVar( "esp", 1, "esp" )
C:CreateConVar( "esp_info", 1, "infoesp" )
C:CreateConVar( "esp_adminlist", 1, "adminlist" )
C:CreateConVar( "esp_rpents", 0, "rpesp" )
C:CreateConVar( "esp_traitorweps", 1, "traitorwepesp" )
C:CreateConVar( "esp_skeleton", 0, "skeleton" )
C:CreateConVar( "esp_chams", 1, "chams" )
C:CreateConVar( "esp_chams_type", 1, "chamstype" )
C:CreateConVar( "bhop", 1, "bhop" )
C:CreateConVar( "crosshair", 1, "crosshair" )
C:CreateConVar( "namesteal_auto", 0, "namestealconstant" )
C:CreateConVar( "novisualrecoil", 1, "novisrecoil" )
C:CreateConVar( "ungag", 0, "ungag" )
C:CreateConVar( "antiaim", 0, "antiaim" )
C:CreateConVar( "calcview", 1, "calcview" )
*/

C.svars = {
	{ Name = "aim", Value = 0, Desc = "Aimbot Enabled", Type = "bool", Table = "aim", Menu = "aim" },
	{ Name = "aim_silent", Value = 1, Desc = "No View Change", Type = "bool", Table = "aimsilent", Menu = "aim" },
	{ Name = "aim_friendlyfire", Value = 1, Desc = "Aim at Teammates", Type = "bool", Table = "aimteam", Menu = "aim" },
	{ Name = "aim_ignoreadmins", Value = 0, Desc = "Ignore Steam Friends", Type = "bool", Table = "ignoreadmins", Menu = "aim" },
	{ Name = "aim_ignoretraitors", Value = 0, Desc = "Ignore Friendly Traitors", Type = "bool", Table = "ignoretraitors", Menu = "aim" },
	{ Name = "aim_ignorefriends", Value = 0, Desc = "Ignore Steam Friends", Type = "bool", Table = "ignorefriends", Menu = "aim" },
	{ Name = "aim_autoshoot", Value = 0, Desc = "Autoshoot", Type = "bool", Table = "autoshoot", Menu = "aim" },
	{ Name = "aim_snaponfire", Value = 0, Desc = "Snap On Fire", Type = "bool", Table = "snaponfire", Menu = "aim" },
	{ Name = "aim_antiaim", Value = 0, Desc = "Anti-Aim", Type = "bool", Table = "antiaim", Menu = "aim" },
	{ Name = "aim_nospread", Value = 1, Desc = "Nospread", Type = "bool", Table = "nospread", Menu = "aim" },
	{ Name = "aim_ignorevisibility", Value = 0, Desc = "Ignore Visibility Checks", Type = "bool", Table = "ignorevisibility", Menu = "aim" },
	{ Name = "aim_obbcenter", Value = 1, Desc = "Aim at OBBCenter", Type = "bool", Table = "useobb", Menu = "aim" },
	{ Name = "aim_comp", Value = 1, Desc = "Velocity Compenaation", Type = "bool", Table = "velocitycomp", Menu = "aim" },
	{ Name = "aim_comp_val", Value = 45, Desc = "Compensation", Type = "number", Table = "compval", Max = 66, Min = 25, Menu = "aim" },
	{ Name = "aim_offset", Value = 0, Desc = "Offset Y", Type = "number", Table = "aimoffset", Max = 50, Min = -50, Menu = "aim" },
	{ Name = "aim_fov", Value = 180, Desc = "Aimbot FOV", Type = "number", Table = "aimfov", Max = 180, Min = 0, Menu = "aim" },
	{ Name = "esp", Value = 1, Desc = "ESP Enabled", Type = "bool", Table = "esp", Menu = "esp" },
	{ Name = "esp_info", Value = 1, Desc = "Player ESP", Type = "bool", Table = "infoesp", Menu = "esp" },
	{ Name = "esp_admins", Value = 1, Desc = "Admin List", Type = "bool", Table = "adminlist", Menu = "esp" },
	{ Name = "esp_rpents", Value = 0, Desc = "RP Entities", Type = "bool", Table = "rpesp", Menu = "esp" },
	{ Name = "esp_tttweps", Value = 0, Desc = "TTT Traitor Weapons", Type = "bool", Table = "traitorwepesp", Menu = "esp" },
	{ Name = "esp_skeleton", Value = 0, Desc = "Skeleton", Type = "bool", Table = "skeleton", Menu = "esp" },
	{ Name = "esp_chams", Value = 1, Desc = "Chams", Type = "bool", Table = "chams", Menu = "esp" },
	{ Name = "esp_chams_type", Value = 1, Desc = "Chams Type", Type = "number", Table = "chamstype", Max = 3, Min = 1, Menu = "esp" },
	{ Name = "misc_bunnyhop", Value = 0, Desc = "Bunnyhop", Type = "bool", Table = "bhop", Menu = "misc" },
	{ Name = "misc_ungag", Value = 0, Desc = "ULX/Evolve Ungag", Type = "bool", Table = "ungag", Menu = "misc" },
	{ Name = "misc_namesteal", Value = 0, Desc = "Namestealer", Type = "bool", Table = "namestealer", Menu = "misc" },
	{ Name = "misc_crosshair", Value = 1, Desc = "Crosshair", Type = "bool", Table = "crosshair", Menu = "misc" },
	{ Name = "misc_novisrecoil", Value = 1, Desc = "No Visual Recoil", Type = "bool", Table = "novisrecoil", Menu = "misc" },
	{ Name = "misc_calcview", Value = 1, Desc = "Enable CalcView", Type = "bool", Table = "calcview", Menu = "misc" }
}

for _, v in pairs( C.svars ) do
	local pvar = C.vars.prefix .. v.Name
	local convar = oG.CreateClientConVar( pvar, v.Value, true, false )
	local cvarinfo = { Name = pvar, Value = v.Value, Desc = v.Desc, Type = v.Type, Max = v.Max, Min = v.Min }
	C.set[v.Table] = ConM.GetInt( convar )
	table.insert( C.convars, pvar )
	C.info[pvar] = cvarinfo
	C.info[#C.info + 1] = cvarinfo
	oC.AddChangeCallback( pvar, function( cvar, old, new ) C.set[v.Table] = new end )
end


function C:G( name, val )
	if ( tonumber( name ) == val ) then return true end
	return false
end

--[[--------------------------------------------
	UTIL FUNCTIONS
	Desc: Check and return bools.
--]]--------------------------------------------

function C:admin( e )
	if e:IsAdmin() || e:IsSuperAdmin() then return true end
	return false
end

function C:friend( e )
	if ( PlyM.GetFriendStatus( e ) == "friend" ) then return true end
	return false
end

function C:traitor( e )
	local ply = LocalPlayer()
	if !oS.find( GAMEMODE.Name, "Trouble in Terror" ) then return end
	if ply:IsTraitor() && e:IsTraitor() then return true end
	return false
end

function C:onscreen( e ) -- Reduce FPS lag by not drawing or rendering objects on screen.
	local x, y, positions = ScrW(), ScrH(), { "OBBCenter", "OBBMaxs", "OBBMins" }
	local pos = positions
	for i = 1, table.Count( pos ) do
		local v = pos[i]
		local pos = VecM.ToScreen( EntM.LocalToWorld( e, _R.Entity[v]( e ) ) )
		if ( pos.x > 0 ) && ( pos.y > 0 ) && ( pos.x < x ) && ( pos.y < y ) then return true end
	end
	return false
end

--[[--------------------------------------------
	NOSPREAD
	Desc: Get diagnosed with Parkinson's.
--]]--------------------------------------------

function _R.Entity.FireBullets( ent, bullet )
	local ply = LocalPlayer()
	local wep = PlyM.GetActiveWeapon( ply )
	local class = EntM.GetClass( wep )
	C.spread.vec[class] = bullet.Spread
	return EntM.FireBullets( ent, bullet )
end

C.cones["weapon_smg1"]    = Vector( -0.04362, -0.04362, -0.04362 )
C.cones["weapon_pistol"]  = Vector( -0.0100, -0.0100, -0.0100 )
C.cones["weapon_ar2"]	  = Vector( -0.02618, -0.02618, -0.02618 )
C.cones["weapon_shotgun"] = Vector( -0.08716, -0.08716, -0.08716 )

function C:predictspread( ucmd, angle )
	local ply, cone = LocalPlayer(), Vector( 0, 0, 0 )
	local ang = AngM.Forward( angle || VecM.Angle( PlyM.GetAimVector( ply ) ) )
	local wep = PlyM.GetActiveWeapon( ply )
	if C:G( C.set['aim'], 1 ) && C:G( C.set['nospread'], 1 ) && wep && ValidEntity( wep ) then
		local class = EntM.GetClass( wep )
		if !C.cones[class] then
			if C.spread.vec[class] then
				cone = Vector( 0, 0, 0 ) - C.spread.vec[class] || Vector( 0, 0, 0 )
				return VecM.Angle( C.hack.CompensateWeaponSpread( ucmd, cone, ang ) )
			end
		else
			cone = C.cones[class]
			return VecM.Angle( C.hack.CompensateWeaponSpread( ucmd, cone, ang ) )
		end
	end
	return Angle( angle.p, angle.y, angle.r )
end

--[[--------------------------------------------
	AIMBOT
	Desc: Because aiming manually is too hard.
--]]--------------------------------------------

function C.aimspot( e )
	if C:G( C.set['useobb'], 1 ) then return EntM.LocalToWorld( e, EntM.OBBCenter( e ) ) end
	local forward = EntM.LookupAttachment( e, "forward" )
	if ( forward != 0 ) then
		forward = EntM.GetAttachment( e, forward ); if forward && forward.Pos then return forward.Pos end
	end
	local eyes = EntM.LookupAttachment( e, "eyes" )
	if ( eyes != 0 ) then
		eyes = EntM.GetAttachment( e, eyes ); if eyes && eyes.Pos then return eyes.Pos end
	end
	local bone = "ValveBiped.Bip01_Head1"
	if EntM.LookupBone( e, bone ) then
		bone = EntM.GetBonePosition( e, bone ); if bone then return bone end
	end
	return EntM.LocalToWorld( e, EntM.OBBCenter( e ) )
end

function C:visible( e )
	local ply = LocalPlayer()
	if C:G( C.set['ignorevisibility'], 1 ) then return true end
	local trace = oU.TraceLine( {
		start = PlyM.GetShootPos( ply ),
		endpos = C.aimspot( e ),
		filter = { ply, e },
		mask = MASK_SHOT + CONTENTS_WINDOW
	} )
	if !trace.Hit then return true end
	return false
end

function C:aimvalid( e )
	local ply = LocalPlayer()
	if !EntM.IsValid( e ) || ( ply == e ) then return false end
	if !PlyM.Alive( e ) then return false end
	if C.cheat.IsDormant( EntM.EntIndex( e ) ) then return false end
	if C:admin( e ) && C:G( C.set['ignoreadmins'], 1 ) then return false end
	if C:traitor( e ) && C:G( C.set['ignoretraitors'], 1 ) then return false end
	if ( PlyM.Team( e ) == PlyM.Team( ply ) ) && C:G( C.set['aimteam'], 0 ) then return false end
	if oS.find( oS.lower( team.GetName( PlyM.Team( e ) ) ), "spec" ) then return false end	
	if C:friend( e ) && C:G( C.set['ignorefriends'], 1 ) then return false end
	if ( EntM.GetMoveType( e ) == MOVETYPE_NONE ) then return false end
	if ( EntM.GetMoveType( e ) == MOVETYPE_OBSERVER ) then return false end
	return true
end

function C:dot( myang, targetang )
	return oM.deg( oM.acos( VecM.Dot( myang, targetang ) ) )
end

function C.aimtarget() 
	local ply, tar, d = LocalPlayer(), false
	if C:G( C.set['aim'], 1 ) then
		local ent = C.world.players
		for i = 1, table.Count( ent ) do
			local e = ent[i]
			if C:aimvalid( e ) && C:visible( e ) then
				local aim = C.aimspot( e )
				d = C:dot( AngM.Forward( EntM.GetAngles( ply ) ), VecM.GetNormal( aim - PlyM.GetShootPos( ply ) ) )
				if ( d < tonumber( C.set['aimfov'] ) ) && ( !tar || ( tar.dist > d ) ) then
					tar = { e = e, pos = aim, dist = d }
				end
			end
		end
	end
	return tar
end

function C.ontoggled()
	local ply = LocalPlayer()
	if C:G( C.set['aimsilent'], 1 ) then
		C.vars.fakeang = EntM.EyeAngles( ply )
	end
	if C:G( C.set['antiaim'], 1 ) then
		C.vars.aacorrectang = EntM.EyeAngles( ply )
	end
end
C:addhook( "OnToggled", C.ontoggled )

function C:normalizeang( ang )
	return Angle(
		oM.NormalizeAngle( ang.p ),
		oM.NormalizeAngle( ang.y ),
		oM.NormalizeAngle( ang.r )
	)
end

function C:doaimbot( ucmd, ang )
	CmdM.SetViewAngles( ucmd, ang )
	local d = ang - CmdM.GetViewAngles( ucmd )
	CmdM.SetMouseX( ucmd, d.y / 0.22 )
	CmdM.SetMouseY( ucmd, d.p / 0.22 )
end

function C.aimbot( ucmd )
	local ply, tar = LocalPlayer(), C.aimtarget()
	C.vars.fakeang.p = oM.Clamp( C.vars.fakeang.p + ( CmdM.GetMouseY( ucmd ) * 0.022 ), -89, 90 )
	C.vars.fakeang.y = oM.NormalizeAngle( C.vars.fakeang.y + ( CmdM.GetMouseX( ucmd ) * -0.022 ) )
	if C:G( C.set['aimsilent'], 1 ) then CmdM.SetViewAngles( ucmd, C.vars.fakeang ) end
	if C:G( C.set['aim'], 1 ) && PlyM.Alive( ply ) && tar then
		C.vars.aimtarg = tar.e
		local ang = C.vars.fakeang; C.vars.found = true
		tar.pos = tar.pos + Vector( 0, 0, tonumber( C.set['aimoffset'] ) )
		if C:G( C.set['velocitycomp'], 1 ) then
			local vc =  1 / tonumber( C.set['compval'] )
			tar.pos = tar.pos + ( EntM.GetVelocity( tar.e ) * vc - EntM.GetVelocity( ply ) * vc )
		end
		ang = VecM.Angle( tar.pos - PlyM.GetShootPos( ply ) ); C.vars.aimingang = ang
		if C:G( C.set['nospread'], 1 ) then ang = C:predictspread( ucmd, ang ) end
		ang = C:normalizeang( ang )
		if C:G( C.set['snaponfire'], 1 ) then
			if CmdM.KeyDown( ucmd, IN_ATTACK ) then
				C:doaimbot( ucmd, ang ); C.vars.aimlocked = true
			else
				C.vars.aimlocked = false
			end
		else
			C:doaimbot( ucmd, ang ); C.vars.aimlocked = true
		end
	else
		C.vars.aimlocked = false; C.vars.found = false
	end
end

function C.silentaimstrafecorrection( ucmd )
	if C:G( C.set['aimsilent'], 1 ) && C.vars.aimlocked then
		local move = Vector( CmdM.GetForwardMove( ucmd ), CmdM.GetSideMove( ucmd ), 0 )
		local norm = VecM.GetNormal( move )
		local set = AngM.Forward( VecM.Angle( norm ) + ( C.vars.aimingang - C.vars.fakeang ) ) * VecM.Length( move )
		CmdM.SetForwardMove( ucmd, set.x ); CmdM.SetSideMove( ucmd, set.y )
	end
end
	
--[[--------------------------------------------
	AUTOSHOOT
	Desc: For furiously furious operations.
--]]--------------------------------------------

function C.autoshoot( ucmd )
	local ply = LocalPlayer()
	local wep = PlyM.GetActiveWeapon( ply )
	if C:G(C.set['aim'], 1 ) && C:G( C.set['autoshoot'], 1 ) then
		if C.vars.found && C.vars.aimlocked && !C.vars.firing then
			C.cheat.RunCommand( "+attack" ); C.vars.firing = true
			oT.Simple( ( wep.Primary && wep.Primary.Delay ) || 0.05, function()
				C.cheat.RunCommand( "-attack" ); C.vars.firing = false
			end )
		end
	end
end

--[[--------------------------------------------
	PROPKILLING
	Desc: Kill fgts in TTT without losing karma.
--]]--------------------------------------------

function C.pkillon()
	if !oS.find( GAMEMODE.Name, "Trouble in Terror" ) then return end
	if C:G( C.set['aimsilent'], 1 ) then
		C.vars.oldsilentval = 1
	else
		C.vars.oldsilentval = 0
	end
	C.cheat.RunCommand( "ph0ne_aim_silent 0" ); C.vars.pkfake = true
end
C:addcommand( "+ph0ne_pk", C.pkillon )

function C.pkilloff()
	if !oS.find( GAMEMODE.Name, "Trouble in Terror" ) then return end
	C.vars.pkfake = false; C.vars.pkthrow = true
	if C:G( C.set['aimsilent'], 0 ) then
		if ( C.vars.oldsilentval == 1 ) then
			C.cheat.RunCommand( "ph0ne_aim_silent 1" )
		else
			C.cheat.RunCommand( "ph0ne_aim_silent 0" )
		end
	end
end
C:addcommand( "-ph0ne_pk", C.pkilloff )

function C.propkill( ucmd )
	if oS.find( GAMEMODE.Name, "Trouble in Terror" ) then
		if C.vars.pkfake && !C.vars.pkthrow then
			C.vars.pkthrowang = CmdM.GetViewAngles( ucmd )
			C.vars.pkfakeang = C.vars.pkthrowang - Angle( 0, 180, 0 )
		elseif !C.vars.pkfake && C.vars.pkthrow then
			C.vars.pkthrow = false; CmdM.SetViewAngles( ucmd, C.vars.pkfakeang )
			if C:G( C.set['aimsilent'], 1 ) then C.vars.fakeang = C.vars.pkfakeang; CmdM.SetViewAngles( ucmd, C.vars.fakeang ) end
		else
			C.vars.pkthrowang = CmdM.GetViewAngles( ucmd ); C.vars.pkfakeang = C.vars.pkthrowang
		end
	end
end

function C.propkillstrafecorrection( ucmd )
	if C.vars.pkfake && !C.vars.pkthrow then		
		local move = Vector( CmdM.GetForwardMove( ucmd ), CmdM.GetSideMove( ucmd ), 0 )
		local norm = VecM.GetNormal( move )
		local ang; if C:G( C.set['aimsilent'], 1 ) then ang = C.vars.fakeang else ang = C.vars.recoilang end
		local set = AngM.Forward( VecM.Angle( norm ) + ( C.vars.pkfakeang - ang ) ) * VecM.Length( move )
		CmdM.SetForwardMove( ucmd, set.x ); CmdM.SetSideMove( ucmd, set.y )
	end
end

--[[--------------------------------------------
	BUNNYHOPPING
	Desc: Speedhack without speedhacking.
--]]--------------------------------------------
	
function C.bhop( ucmd )	
	local ply = LocalPlayer()
	local buttons = CmdM.GetButtons( ucmd )
	if C:G( C.set['bhop'], 1 ) then
		if ( EntM.GetMoveType( ply ) != MOVETYPE_WALK ) then return end
		if ply && CmdM.KeyDown( ucmd, IN_JUMP ) then
			if EntM.IsOnGround( ply ) then
				CmdM.SetButtons( ucmd, buttons | IN_JUMP )
			else
				CmdM.SetButtons( ucmd, buttons - IN_JUMP )
			end
		end
	end
end

--[[--------------------------------------------
	ANTI-AIM
	Desc: Mess with shitty aimbots.
--]]--------------------------------------------

function C:RA( ang )
	return tonumber( oM.random( -ang, ang ) )
end

function C.antiaim( ucmd )
	local ply = LocalPlayer()
	if !PlyM.Alive( ply ) then return end
	if C:G( C.set['antiaim'], 1 ) && !C.vars.aimlocked then
		C.vars.aacorrectang.p = oM.Clamp( C.vars.aacorrectang.p + ( CmdM.GetMouseY( ucmd ) * 0.022 ), -89, 90 )
		C.vars.aacorrectang.y = oM.NormalizeAngle( C.vars.aacorrectang.y + ( CmdM.GetMouseX( ucmd ) * -0.022 ) )
		C.vars.antiaimang = Angle( C:RA( 89 ), C:RA( 179 ), 0 )
		CmdM.SetViewAngles( ucmd, C.vars.antiaimang )
	elseif C.vars.aimlocked then
		C.vars.aacorrectang = CmdM.GetViewAngles( ucmd )
	elseif C:G( C.set['antiaim'], 0 ) then
		C.vars.aacorrectang = CmdM.GetViewAngles( ucmd )
		CmdM.SetViewAngles( ucmd, C.vars.aacorrectang ) -- Reset the view.
	end
end

function C.antiaimstrafecorrection( ucmd )
	local ply = LocalPlayer(); if !PlyM.Alive( ply ) then return end
	if C:G( C.set['antiaim'], 1 ) && !C.vars.aimlocked then
		local ang; if C:G( C.set['aimsilent'], 1 ) then ang = C.vars.fakeang else ang = C.vars.aacorrectang end
		local move = Vector( CmdM.GetForwardMove( ucmd ), CmdM.GetSideMove( ucmd ), 0 )
		local norm = VecM.GetNormal( move )
		local set = AngM.Forward( VecM.Angle( norm ) + ( C.vars.antiaimang - ang ) ) * VecM.Length( move )
		CmdM.SetForwardMove( ucmd, set.x ); CmdM.SetSideMove( ucmd, set.y )
	end
end

--[[--------------------------------------------
	CALCVIEW
	Desc: Make myself appear normal.
--]]--------------------------------------------

function C.setnovisualrecoil( ucmd )
	if C:G( C.set['novisrecoil'], 1 ) then
		C.vars.recoilang = CmdM.GetViewAngles( ucmd )
	end
end

function C.calcview( ply, origin, angles )
	local ply, view = LocalPlayer(), {}; view.origin = origin
	local wep = PlyM.GetActiveWeapon( ply )
	if wep.Primary then wep.Primary.Recoil = 0 end
	if wep.Secondary then wep.Secondary.Recoil = 0 end
	if C:G( C.set['calcview'], 1 ) then
		if C.vars.pkfake && oS.find( GAMEMODE.Name, "Trouble in Terror" ) then
			view.angles = C.vars.pkfakeang
		elseif C.vars.aimlocked && C:G( C.set['aimsilent'], 0 ) then
			view.angles = C.vars.aimingang
		elseif C:G( C.set['aimsilent'], 1 ) then
			view.angles = C.vars.fakeang
		elseif C:G( C.set['antiaim'], 1 ) then
			view.angles = C.vars.aacorrectang
		elseif C:G( C.set['aimsilent'], 1 ) && C:G( C.set['novisrecoil'], 1 ) then
			view.angles = C.vars.fakeang
		elseif C:G( C.set['novisrecoil'], 1 ) && C:G( C.set['aimsilent'], 0 ) then
			view.angles = C.vars.recoilang
		else
			view = GAMEMODE:CalcView( ply, origin, angles )
		end
	else
		view = GAMEMODE:CalcView( ply, origin, angles )
	end
	return view
end
C:addhook( "CalcView", C.calcview )

--[[--------------------------------------------
	ESP
	Desc: Get info on targets.
--]]--------------------------------------------

function C:espvalid( e )
	local ply = LocalPlayer()
	if !EntM.IsValid( e ) || ( ply == e ) then return false end
	if !PlyM.Alive( e ) then return false end
	if C.cheat.IsDormant( EntM.EntIndex( e ) ) then return false end
	if oS.find( oS.lower( team.GetName( PlyM.Team( e ) ) ), "spec" ) then return false end
	if ( EntM.GetMoveType( e ) == MOVETYPE_NONE ) then return false end
	if ( EntM.GetMoveType( e ) == MOVETYPE_OBSERVER ) then return false end
	if !C:onscreen( e ) then return false end
	return true
end

C.skeleton = { -- Thanks, victor. I'd be too lazy to get these myself.
	{"ValveBiped.Bip01_Head1", 		"ValveBiped.Bip01_Spine4"},
	{"ValveBiped.Bip01_Spine4", 	"ValveBiped.Bip01_Spine2"},
	{"ValveBiped.Bip01_Spine2", 	"ValveBiped.Bip01_Spine"},
	{"ValveBiped.Bip01_Spine4", 	"ValveBiped.Bip01_L_UpperArm"},
	{"ValveBiped.Bip01_Spine4", 	"ValveBiped.Bip01_R_UpperArm"},
	{"ValveBiped.Bip01_R_UpperArm", "ValveBiped.Bip01_R_Forearm"},
	{"ValveBiped.Bip01_L_UpperArm", "ValveBiped.Bip01_L_Forearm"},
	{"ValveBiped.Bip01_R_Forearm",  "ValveBiped.Bip01_R_Hand"},
	{"ValveBiped.Bip01_L_Forearm",  "ValveBiped.Bip01_L_Hand"},
	{"ValveBiped.Bip01_Spine", 		"ValveBiped.Bip01_Pelvis"},
	{"ValveBiped.Bip01_Pelvis",		"ValveBiped.Bip01_R_Thigh"},
	{"ValveBiped.Bip01_Pelvis", 	"ValveBiped.Bip01_L_Thigh"},
	{"ValveBiped.Bip01_R_Thigh", 	"ValveBiped.Bip01_R_Calf"},
	{"ValveBiped.Bip01_L_Thigh", 	"ValveBiped.Bip01_L_Calf"},
	{"ValveBiped.Bip01_R_Calf", 	"ValveBiped.Bip01_R_Foot"},
	{"ValveBiped.Bip01_L_Calf", 	"ValveBiped.Bip01_L_Foot"},
	{"ValveBiped.Bip01_R_Foot", 	"ValveBiped.Bip01_R_Toe0"},
	{"ValveBiped.Bip01_L_Foot", 	"ValveBiped.Bip01_L_Toe0"},
}

function C:fillrgba( x, y, w, h, col )
	oSU.SetDrawColor( col )
	oSU.DrawRect( x, y, w, h )
end

function C:colorstatus( e )
	local statuscol = color_white
	if C:friend( e ) then
		statuscol = Color( 0, 255, 0, 255 )
	elseif C:admin( e ) then
		statuscol = Color( 215, 255, 0, 255 )
	elseif C:traitor( e ) && oS.find( GAMEMODE.Name, "Trouble in Terror" ) then
		statuscol = Color( 255, 0, 0, 155 )
	else
		statuscol = color_white
	end
	local namecol = color_white
	if ( C.vars.aimtarg != nil ) then
		if C:G( C.set['aim'], 1 ) && ( e == C.vars.aimtarg ) && C:visible( e ) then
			namecol = Color( 0, 255, 0, 255 )
		else
			namecol = color_white
		end
	else
		namecol = color_white
	end
	return statuscol, namecol
end

function C:espline( e, pos, opos, col )
	oSU.SetDrawColor( col )
	oSU.DrawLine( opos.x, opos.y, pos.x + 7, pos.y - 3.5 )
	oSU.DrawLine( pos.x + 7, pos.y - 3.5, pos.x + 60, pos.y - 3.5 )
end

function C:espname( e, pos, col )
	oDR.RoundedBox( 0, pos.x + 7, pos.y - 15, 7, 7, team.GetColor( PlyM.Team( e ) ) )
	oDR.SimpleTextOutlined(
		tostring( PlyM.Nick( e ) ), "Default",
		pos.x + 18, pos.y - 5,
		col,
		TEXT_ALIGN_LEFT, TEXT_ALIGN_BOTTOM,
		1, color_black
	)
end

function C:esphealth( e, pos )
	local health, maxhealth = EntM.Health( e ), 100
	if ( health > maxhealth ) then health = maxhealth end
	local maxh, heatlhval = ( maxhealth / 4 ), ( health / 2 )
	local hposx, hposy = pos.x - ( maxh / 2 ), ( pos.y + 10 )
	C:fillrgba( hposx + 22.5, hposy - 10, maxh + 27, 3 + 2, color_black )
	C:fillrgba( hposx + 23.5, hposy - 9, heatlhval, 3, Color( 0, 255, 0, 255 ) )
end

function C.playeresp()
	local ply = LocalPlayer()
	if C:G( C.set['esp'], 1 ) then
		local ent = C.world.players
		for i = 1, table.Count( ent ) do
			local e = ent[i]
			if C:espvalid( e ) then
				if C:G( C.set['infoesp'], 1 ) then
					local opos = VecM.ToScreen( C.aimspot( e ) )
					local pos = VecM.ToScreen( C.aimspot( e ) + Vector( 0, 0, 12 ) )
					local scol, ncol = C:colorstatus( e )
					C:espline( e, pos, opos, scol )
					C:espname( e, pos, ncol )
					C:esphealth( e, pos )
				end
				if C:G( C.set['skeleton'], 1 ) then
					local skeleton = C.skeleton
					for i = 1, table.Count( skeleton ) do
						local v = skeleton[i]
						local b1 = VecM.ToScreen( EntM.GetBonePosition( e, EntM.LookupBone( e, v[1] ) ) )
						local b2 = VecM.ToScreen( EntM.GetBonePosition( e, EntM.LookupBone( e, v[2] ) ) )
						oSU.SetDrawColor( team.GetColor( PlyM.Team( e ) ) )
						oSU.DrawLine( b1.x, b1.y, b2.x, b2.y )
					end
				end
			end
		end
	end
end

function C.adminlist()
	if C:G( C.set['esp'], 1 ) && C:G( C.set.adminlist, 1 ) then
		local admins, w, h, space = {}, ScrW(), ScrH(), 0
		local ax, ayh, aya = ( w - ( w - 20 ) ), ( ( h - h ) + 301 ), ( ( h - h ) + 315 )
		oDR.SimpleTextOutlined(
			"ADMINS:", "DefaultBold",
			ax, ayh,
			Color( 255, 105, 105, 255 ),
			TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER,
			1, color_black
		)
		local ent = C.world.players
		for i = 1, table.Count( ent ) do
			local e = ent[i]
			if oG.ValidEntity( e ) and C:admin( e ) then
				table.insert( admins, PlyM.Nick( e ) )
			end
		end
		for i = 1, table.Count( admins ) do
			oDR.SimpleTextOutlined(
				admins[i], "DefaultBold",
				ax, aya + space,
				color_white,
				TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER,
				1, color_black
			)
			space = space + 15
		end
	end
end

C.rpents = {
	money_printer = "printer",
	gunlab 	      = "gunlab",
	drug_lab      = "drug_lab",
	spawned_money = "money",
	dispenser     = "dispenser",
	gunvault      = "gunvault",
	drugfactory   = "drugfactory",
	gunfactory    = "gunfactory",
	microwave     = "microwave",
	powerplant    = "powerplant",
}

C.traitorweapons = {
	"weapon_ttt_c4",
	"weapon_ttt_decoy",
	"weapon_ttt_flaregun",
	"weapon_ttt_knife",
	"weapon_ttt_phammer",
	"weapon_ttt_push",
	"weapon_ttt_radio",
	"weapon_ttt_sipistol",
	"weapon_ttt_teleport"
}

function C.entityesp()
	local ply = LocalPlayer()
	if C:G( C.set['esp'], 1 ) then
		local tc = TEXT_ALIGN_CENTER
		local yellow = Color( 255, 255, 0, 255 )
		local black = Color( 0, 0, 0, 255 )
		local red = Color( 255, 0, 0, 255 )
		if C:G( C.set['rpesp'], 1 ) then
			local ent = C.world.entities
			for i = 1, table.Count( ent ) do
				local e = ent[i]
				for k, t in pairs ( C.rpents ) do
					if oG.ValidEntity( e ) and ( EntM.GetClass( e ) == k ) then
						local pos = VecM.ToScreen( EntM.GetPos( e ) )
						oDR.SimpleTextOutlined( t, "MenuItem", pos.x, pos.y, yellow, tc, tc, 1, black )
					end
				end
			end
		end
		if C:G( C.set['traitorwepesp'], 1 ) && oS.find( GAMEMODE.Name, "Trouble in Terror" ) then
			local ent = C.traitorweapons
			for i = 1, table.Count( ent ) do
				local e = ent[i]
				for k, t in pairs( ents.FindByClass( e ) ) do
					local pos, size = VecM.ToScreen( EntM.GetPos( t ) ), 6
					local c = size / 2
					oDR.RoundedBox( 0, pos.x - c, pos.y - c, size, size, red )
				end
			end
		end
	end
end

--[[--------------------------------------------
	CROSSHAIR
	Desc: ArtificialAiming ripoff.
--]]--------------------------------------------

function C:boxoutline( x, y, w, h, col )
	oSU.SetDrawColor( col )
	oSU.DrawOutlinedRect( x, y, w, h )
end

function C.crosshair()
	if C:G( C.set['crosshair'], 1 ) then
		local w, h, length = ScrW() / 2, ScrH() / 2, 5
		if C:G( C.set['aim'], 1 ) then
			oSU.SetDrawColor( 255, 0, 0, 255 )
		else
			oSU.SetDrawColor( 255, 255, 0, 255 )
		end
		oSU.DrawLine( w - length, h, w, h )
   		oSU.DrawLine( w + length, h, w, h )
		oSU.DrawLine( w, h - length, w, h )
		oSU.DrawLine( w, h + length, w, h )
		if C.vars.found && !C.vars.aimlocked then
			C:boxoutline(
				( w - length ) - 2,
				( h - length ) - 2,
				( ( length + 2 ) * 2 ) + 1,
				( ( length + 2 ) * 2 ) + 1,
				Color( 255, 255, 0 , 255 )
			)
		elseif C.vars.aimlocked && C.vars.found then
			C:boxoutline(
				( w - length ) - 2,
				( h - length ) - 2,
				( ( length + 2 ) * 2 ) + 1,
				( ( length + 2 ) * 2 ) + 1,
				Color( 255, 0, 0 , 255 )
			)
		end
	end
end

--[[--------------------------------------------
	CHAMS
	Desc: See fgts through da wall.
--]]--------------------------------------------

function C:chamsmat()
	local info, mat = {
		["$basetexture"] = "models/debug/debugwhite",
		["$model"]       = 1,
		["$translucent"] = 1,
		["$alpha"]       = 1,
		["$nocull"]      = 1,
		["$ignorez"]	 = 1
	}
	if C:G( C.set['chamstype'], 1 ) then
		mat = oG.CreateMaterial( "solid", "UnlitGeneric", info )
	elseif C:G( C.set['chamstype'], 2 ) then
		mat = oG.CreateMaterial( "wire", "Wireframe", info )
	end
	return mat
end

function C.chams()
	if C:G( C.set['esp'], 1 ) && C:G( C.set['chams'], 1 ) then
		local ent = C.world.players
		for i = 1, table.Count( ent ) do
			local e = ent[i]
			if C:espvalid( e ) then
				local col, c = team.GetColor( PlyM.Team( e ) ), ( 1 / 255 )
				oCA.Start3D( EyePos(), EyeAngles() )
					if !C:G( C.set['chamstype'], 3 ) then
						oR.SuppressEngineLighting( true )
							oG.SetMaterialOverride( C:chamsmat() )
								oR.SetColorModulation( ( col.r * c ), ( col.g * c ), ( col.b * c ) )
								if C:G( C.set['chamstype'], 2 ) then oR.SetBlend( 1 ) else oR.SetBlend( 0.85 ) end
								EntM.DrawModel( e )
							oG.SetMaterialOverride()
								oR.SetColorModulation( 1, 1, 1 )
								oR.SetBlend( 1 )
								EntM.DrawModel( e )
						oR.SuppressEngineLighting( false )
					else
						oG.SetMaterialOverride()
						oCA.IgnoreZ( true )
							EntM.DrawModel( e )
						oCA.IgnoreZ( false )
					end
				oCA.End3D()
			end
		end
	end
end
C:addhook( "RenderScreenspaceEffects", C.chams )

--[[--------------------------------------------
	NAME CHANGING
	Desc: Rage the admins.
--]]--------------------------------------------

function C.stealnames()
	local ply, e = LocalPlayer(), C.world.players
	local randname = e[ oM.random( 1, #e ) ]
	if C:G( C.set['namestealconstant'], 1 ) then
		if ply && ( randname != ply ) && ( PlyM.Nick( randname ) != PlyM.Nick( ply ) ) then
			C.cheat.RunCommand( "name " .. PlyM.Nick( randname ) .. "~ ~~" )
		end
	end
end

function C.stealname()
	local ply, e = LocalPlayer(), C.world.players
	local randname = e[ oM.random( 1, #e ) ]
	if ply && ( randname != ply ) && ( PlyM.Nick( randname ) != PlyM.Nick( ply ) ) then
		C.cheat.RunCommand( "name " .. PlyM.Nick( randname ) .. "~ ~~" )
		chat.AddText(
			Color( 255, 0, 0 ), ":: ",
			Color( 255, 255, 255 ), "Your name is now ",
			Color( 255, 0, 0 ), PlyM.Nick( randname ),
			Color( 255, 255, 255 ), "."
		)
	end
end
C:addcommand( "ph0ne_namesteal", C.stealname )

function C.antimute()
	local ply = LocalPlayer()
	if ply then
		C.cheat.RunCommand( "name �" )
		chat.AddText(
			Color( 255, 0, 0 ), ":: ",
			Color( 255, 255, 255 ), "You are now ",
			Color( 255, 0, 0 ), "nameless",
			Color( 255, 255, 255 ), "."
		)
	end
end
C:addcommand( "ph0ne_antimute", C.antimute )

function C.ungag()
	local ply = LocalPlayer()
	if ply && C:G( C.set['ungag'], 1 ) then
		if ulx && ulx.gagUser then
			ulx.gagUser( false )
			oH.Remove( "PlayerBindPress", "ULXGagForce" )
			oT.Destroy( "GagLocalPlayer" )
		end
		if evolve then
			EntM.SetNWBool( ply, "Muted", false )
		end
	end
end

--[[--------------------------------------------
	PLAYERS AND ENTITIES
	Desc: Get all targets faster.
--]]--------------------------------------------

function C.getallents()
	C.world.players = {}
	C.world.entities = {}
	local ent = ents.GetAll()
	for i = 1, table.Count( ent ) do
		local e = ent[i]
		if ValidEntity( e ) then
			if e:IsPlayer() then
				table.insert( C.world.players, e )
			else
				table.insert( C.world.entities, e )
			end
		end
	end
end

--[[--------------------------------------------
	GROUPED HOOKS
	Desc: Optimize the hack.
--]]--------------------------------------------

function C.createmove( ucmd )
	C.aimbot( ucmd )
	C.antiaim( ucmd )
	C.antiaimstrafecorrection( ucmd )
	C.autoshoot( ucmd )
	C.bhop( ucmd )
	C.propkill( ucmd )
	C.propkillstrafecorrection( ucmd )
	C.setnovisualrecoil( ucmd )
	C.silentaimstrafecorrection( ucmd )
end
C:addhook( "CreateMove", C.createmove )

function C.hudpaint()
	C.adminlist()
	C.entityesp()
	C.playeresp()
	C.crosshair()
end
C:addhook( "HUDPaint", C.hudpaint )

function C.think()
	C.getallents()
	C.stealnames()
	C.ungag()
end
C:addhook( "Think", C.think )

--[[--------------------------------------------
	MENU
	Desc: Have an excuse to click on things.
--]]--------------------------------------------

function C.menu()
	local w, h = ScrW() / 2, ScrH() / 2
	local x, y = 400, 300
	local px, py = x - 10, y - 30
	local tx, ty = x - 20, y - 65
	local panel = oV.Create( "DFrame" )
		panel:SetPos( w - 400 / 2, h - 300 / 2 )
		panel:SetSize( x, y )
		panel:SetTitle( "ph0ne" )
		panel:SetVisible( true )
		panel:SetDraggable( true )
		panel:ShowCloseButton( true )
		panel:MakePopup()
		panel.Paint = function()
			oDR.RoundedBox( 0, 0, 0, x, y, Color( 0, 0, 0, 55 ) )
			oSU.SetDrawColor( Color( 0, 0, 0, 255 ) ); oSU.DrawOutlinedRect( 0, 0, x, y )
		end
	local page = oV.Create( "DPropertySheet" )
		page:SetParent( panel )
		page:SetPos( 5, 25 )
		page:SetSize( 390, 270 )
		page.Paint = function ()
			oDR.RoundedBox( 0, 0, 0, px, py, Color( 0, 0, 0, 0 ) )
		end
	local aim = oV.Create( "DPanel", page )
		aim.Paint = function()
			oDR.RoundedBox( 0, 0, 0, tx, ty, Color( 0, 0, 0, 85 ) )
			oSU.SetDrawColor( Color( 0, 0, 0, 255 ) ); oSU.DrawOutlinedRect( 0, 0, tx, ty )
		end
		local aimlist = oV.Create( "DPanelList" )
			aimlist:SetPos( 10, 10 )
			aimlist:SetParent( aim )
			aimlist:SetSize( tx - 15, ty - 20 )
			aimlist:EnableVerticalScrollbar( true )
			aimlist:SetSpacing( 5 )
			aimlist.Paint = function()
				oDR.RoundedBox( 0, 0, 0, tx - 15, ty - 20, Color( 0, 0, 0, 0 ) )
			end
		local aimlist_s = oV.Create( "DPanelList" )
			aimlist_s:SetPos( 10, 200 )
			aimlist_s:SetParent( aim )
			aimlist_s:SetSize( tx - 15, ty - 20 )
			aimlist_s:EnableVerticalScrollbar( true )
			aimlist_s:SetSpacing( 5 )
			aimlist_s.Paint = function()
				oDR.RoundedBox( 0, 0, 0, tx - 15, ty - 20, Color( 0, 0, 0, 0 ) )
			end
	local esp = oV.Create( "DPanel", page )
		esp.Paint = function()
			oDR.RoundedBox( 0, 0, 0, tx, ty, Color( 0, 0, 0, 85 ) )
			oSU.SetDrawColor( Color( 0, 0, 0, 255 ) ); oSU.DrawOutlinedRect( 0, 0, tx, ty )
		end
		local esplist = oV.Create( "DPanelList" )
			esplist:SetPos( 10, 10 )
			esplist:SetParent( esp )
			esplist:SetSize( tx - 15, ty - 20 )
			esplist:EnableVerticalScrollbar( true )
			esplist:SetSpacing( 5 )
			esplist.Paint = function()
				oDR.RoundedBox( 0, 0, 0, tx - 15, ty - 20, Color( 0, 0, 0, 0 ) )
			end
		local esplist_s = oV.Create( "DPanelList" )
			esplist_s:SetPos( 10, 200 )
			esplist_s:SetParent( esp )
			esplist_s:SetSize( tx - 15, ty - 20 )
			esplist_s:EnableVerticalScrollbar( true )
			esplist_s:SetSpacing( 5 )
			esplist_s.Paint = function()
				oDR.RoundedBox( 0, 0, 0, tx - 15, ty - 20, Color( 0, 0, 0, 0 ) )
			end
	local misc = oV.Create( "DPanel", page )
		misc.Paint = function()
			oDR.RoundedBox( 0, 0, 0, tx, ty, Color( 0, 0, 0, 85 ) )
			oSU.SetDrawColor( Color( 0, 0, 0, 255 ) ); oSU.DrawOutlinedRect( 0, 0, tx, ty )
		end
		local misclist = oV.Create( "DPanelList" )
			misclist:SetPos( 10, 10 )
			misclist:SetParent( misc )
			misclist:SetSize( tx - 15, ty - 20 )
			misclist:EnableVerticalScrollbar( true )
			misclist:SetSpacing( 5 )
			misclist.Paint = function()
				oDR.RoundedBox( 0, 0, 0, tx - 15, ty - 20, Color( 0, 0, 0, 0 ) )
			end
		local misclist_s = oV.Create( "DPanelList" )
			misclist_s:SetPos( 10, 200 )
			misclist_s:SetParent( misc )
			misclist_s:SetSize( tx - 15, ty - 20 )
			misclist_s:EnableVerticalScrollbar( true )
			misclist_s:SetSpacing( 5 )
			misclist_s.Paint = function()
				oDR.RoundedBox( 0, 0, 0, tx - 15, ty - 20, Color( 0, 0, 0, 0 ) )
			end
	for k, v in ipairs( C.info ) do
		if ( v.Name == "ph0ne_esp_chams_type" ) then
		elseif ( v.Type == "bool" ) then
			local checkbox = oV.Create( "DCheckBoxLabel" )
			checkbox:SetText( v.Desc )
			checkbox:SetValue( GetConVarNumber( v.Name ) )
			checkbox:SetTextColor( color_white )
			checkbox.change = 0
			checkbox.OnChange = function()
				if ( checkbox.change < CurTime() ) then
					checkbox.change = CurTime() + 0.1
					checkbox:SetValue( tobool( checkbox:GetChecked() && 1 || 0 ) )
					oG.RunConsoleCommand( v.Name, checkbox:GetChecked() && 1 || 0 )
				end
			end
			oC.AddChangeCallback( v.Name, function( cvar, old, new ) 
				if ( checkbox.change < CurTime() ) then
					checkbox.change = CurTime() + 0.1
					checkbox:SetValue( tobool( new ) )
				end
			end )
			if ( v.Menu == "aim" ) then
				aimlist:AddItem( checkbox )
			elseif ( v.Menu == "esp" ) then
				esplist:AddItem( checkbox )
			else
				misclist:AddItem( checkbox )
			end
		elseif ( v.Type == "number" ) then
			local slider = oV.Create( "DNumSlider" )
			slider:SetText( "" )
			slider:SetMax( v.Max || 1 )
			slider:SetMin( v.Min || 0 )
			slider:SetDecimals( 0 )
			slider:SetValue( GetConVarNumber( v.Name ) )
			local label = oV.Create( "DLabel" )
			label:SetParent( slider )
			label:SetWide( 200 )
			label:SetText( v.Desc )
			label:SetTextColor( color_white )
			slider.change = 0
			slider.ValueChanged = function( self, new )
				if ( slider.change < CurTime() ) then
					slider.change = CurTime() + 0.1
					slider:SetValue( new )
					oG.RunConsoleCommand( v.Name, new )
				end
			end
			oC.AddChangeCallback( v.Name, function( cvar, old, new ) 
				if ( slider.change < CurTime() ) then
					slider.change = CurTime() + 0.1
					slider:SetValue( new )
				end
			end )
			if ( v.Menu == "aim" ) then
				aimlist_s:AddItem( checkbox )
			elseif ( v.Menu == "esp" ) then
				esplist_s:AddItem( checkbox )
			else
				misclist_s:AddItem( checkbox )
			end
		end
	end
	page:AddSheet( "Aimbot", aim, nil, false, false, nil )
	page:AddSheet( "ESP", esp, nil, false, false, nil )
	page:AddSheet( "Misc", misc, nil, false, false, nil )
end
C:addcommand( "ph0ne_menu", C.menu )

/*function C.menu()
	local panel = oV.Create( "DFrame" )
	panel:SetPos( ScrW() / 2 - 200 / 2, ScrH() / 2 - 400 / 2 )
	panel:SetSize( 275, 430 )
	panel:SetTitle( "ph0ne" )
	panel:SetVisible( true )
	panel:SetDraggable( true )
	panel:ShowCloseButton( true )
	panel:MakePopup()
	panel.Paint = function()
		oDR.RoundedBox( 0, 0, 0, 255, 430, Color( 0, 0, 0, 55 ) )
		oSU.SetDrawColor( Color( 0, 0, 0, 255 ) ); oSU.DrawOutlinedRect( 0, 0, 255, 430 )
	end
	local propertypage = oV.Create( "DPropertySheet" )
	propertypage:SetParent( panel )
	propertypage:SetPos( 5, 25 )
	propertypage:SetSize( 255, 400 )
	propertypage.Paint = function()
		oDR.RoundedBox( 0, 0, 0, 255 - 15, 400 - 10, Color( 0, 0, 0, 155 ) )
		oSU.SetDrawColor( Color( 0, 0, 0, 255 ) ); oSU.DrawOutlinedRect( 0, 0, 255 - 15, 400 - 10 )
	end
	local aim = oV.Create( "DPanel", propertypage )
	local esp = oV.Create( "DPanel", propertypage )
	local mis = oV.Create( "DPanel", propertypage )
	local aimlist = oV.Create( "DPanelList" )
	aimlist:SetPos( 10, 30 )
	aimlist:SetParent( propertypage )
	aimlist:SetSize( 255 - 15, 400 - 10 )
	aimlist:EnableVerticalScrollbar( true )
	aimlist.Paint = function()
		oDR.RoundedBox( 0, 0, 0, 255 - 15, 400 - 10, Color( 0, 0, 0, 155 ) )
		oSU.SetDrawColor( Color( 0, 0, 0, 255 ) ); oSU.DrawOutlinedRect( 0, 0, 255 - 15, 400 - 10 )
	end
	local multichoice = oV.Create( "DMultiChoice" )
	multichoice:SetEditable( false )
	multichoice:AddChoice( "Solid" )
	multichoice:AddChoice( "Wireframe" )
	multichoice:AddChoice( "XQZ" )
	multichoice:ChooseOptionID( tonumber( C.set.chamstype ) )
	multichoice.OnSelect = function( index, value, data )
		oG.RunConsoleCommand( "ph0ne_esp_chams_type", value )
	end
	--dlist:AddItem( multichoice )
	for k, v in ipairs( C.info ) do
		if ( v.Name == "ph0ne_esp_chams_type" ) then
		elseif ( v.Type == "bool" ) then
			local checkbox = oV.Create( "DCheckBoxLabel" )
			checkbox:SetText( v.Desc )
			checkbox:SetValue( GetConVarNumber( v.Name ) )
			checkbox:SetTextColor( color_white )
			checkbox.change = 0
			checkbox.OnChange = function()
				if ( checkbox.change < CurTime() ) then
					checkbox.change = CurTime() + 0.1
					checkbox:SetValue( tobool( checkbox:GetChecked() && 1 || 0 ) )
					oG.RunConsoleCommand( v.Name, checkbox:GetChecked() && 1 || 0 )
				end
			end
			oC.AddChangeCallback( v.Name, function( cvar, old, new ) 
				if ( checkbox.change < CurTime() ) then
					checkbox.change = CurTime() + 0.1
					checkbox:SetValue( tobool( new ) )
				end
			end )
			aimlist:AddItem( checkbox )
		elseif ( v.Type == "number" ) then
			local slider = oV.Create( "DNumSlider" )
			slider:SetText( "" )
			slider:SetMax( v.Max || 1 )
			slider:SetMin( v.Min || 0 )
			slider:SetDecimals( 0 )
			slider:SetValue( GetConVarNumber( v.Name ) )
			local label = oV.Create( "DLabel" )
			label:SetParent( slider )
			label:SetWide( 200 )
			label:SetText( v.Desc )
			label:SetTextColor( color_white )
			slider.change = 0
			slider.ValueChanged = function( self, new )
				if ( slider.change < CurTime() ) then
					slider.change = CurTime() + 0.1
					slider:SetValue( new )
					oG.RunConsoleCommand( v.Name, new )
				end
			end
			oC.AddChangeCallback( v.Name, function( cvar, old, new ) 
				if ( slider.change < CurTime() ) then
					slider.change = CurTime() + 0.1
					slider:SetValue( new )
				end
			end )
			--dlist:AddItem( slider )
		end
	end
	propertypage:AddSheet( "Aimbot", aim, nil, false, false, nil )
	propertypage:AddSheet( "ESP", esp, nil, false, false, nil )
	propertypage:AddSheet( "Miscellaneous", mis, nil, false, false, nil )
end
C:addcommand( "ph0ne_menu", C.menu )*/

/*function C:createoption( dtype, parent, o1, o2, o3, o4, o5, o6, o7 ) -- Using Seth's wrapper, because I can.
	local addx, addy = 3, 3.5
	if ( dtype == "Checkbox" ) then
		dtype = "DCheckBoxLabel"
		local text, cvar, x, y = o1, o2, o3, o4
		local checkbox = oV.Create( dtype, parent )
		checkbox:SetText( text )
		checkbox:SetPos( x + addx, y + addy )
		checkbox:SetConVar( C.vars.prefix .. cvar )
		checkbox:SetValue( GetConVarNumber( C.vars.prefix .. cvar ) )
		checkbox:SizeToContents()
	elseif ( dtype == "Slider" ) then
		dtype = "DNumSlider"
		local text, cvar, min, max, wide, x, y = o1, o2, o3, o4, o5, o6, o7
		local slider = oV.Create( dtype, parent )
		slider:SetPos( x + addx, y + addy )
		slider:SetWide( wide )
		slider:SetText( text )
		slider:SetMin( min )
		slider:SetMax( max )
		slider:SetDecimals( 0 )
		slider:SetConVar( C.vars.prefix .. cvar )
		slider:SetValue( GetConVarNumber( C.vars.prefix .. cvar ) )
	elseif ( dtype == "Button" ) then
		dtype = "DButton"
		local text, command, x, y = o1, o2, o3, o4
		local button = oV.Create( dtype, parent )
		button:SetParent( parent )
		button:SetSize( 125, 25 )
		button:SetPos( x + addx, y + addy )
		button:SetText( text )
		button.DoClick = function() C.cheat.RunCommand( C.vars.prefix .. command ) end
	elseif ( dtype == "Label" ) then
		dtype = "DLabel"
		local text, x, y = o1, o2, o3
		local label = oV.Create( dtype, parent )
		label:SetPos( x, y )
		label:SetText( text )
		label:SizeToContents()
		label:SetTextColor( color_white )
	end
end

function C.menu()
	local tabs, menuheight, menuwidth, w, h = {}, 245, 320, ScrW() / 2, ScrH() / 2
	local c1, c2 = Color( 0, 0, 0, 75 ), Color( 0, 0, 0, 155 )
	C.frame = oV.Create( "DPropertySheet" )
	C.frame:SetParent( C.frame )
	C.frame:SetPos( w - ( menuwidth / 2 ), h - ( menuheight / 2 ) )
	C.frame:SetSize( menuwidth, menuheight )
	C.frame:SetVisible( true )
	C.frame:MakePopup()
	C.frame.Paint = function() oDR.RoundedBox( 0, 0, 0, C.frame:GetWide(), C.frame:GetTall(), c1 ) end
	C:createoption( "Label", C.frame, "CBaseAimbot", 250, 6.5 )
	tabs.aimbot = oV.Create( "DLabel", C.frame )
	tabs.aimbot:SetPos( 0, 0 )
	tabs.aimbot:SetText( "" )
	tabs.aimbot.Paint = function() oDR.RoundedBox( 1, 0, 0, C.frame:GetWide(), C.frame:GetTall(), c2 ) end
	C.frame:AddSheet( "Aimbot", tabs.aimbot, nil, false, false )
	tabs.esp = oV.Create( "DLabel", C.frame )
	tabs.esp:SetPos( 0, 0 )
	tabs.esp:SetText( "" )
	tabs.esp.Paint = function() oDR.RoundedBox( 1, 0, 0, C.frame:GetWide(), C.frame:GetTall(), c2 ) end
	C.frame:AddSheet( "ESP", tabs.esp, nil, false, false )
	tabs.misc = oV.Create( "DLabel", C.frame )
	tabs.misc:SetPos( 0, 0 )
	tabs.misc:SetText( "" )
	tabs.misc.Paint = function() oDR.RoundedBox( 1, 0, 0, C.frame:GetWide(), C.frame:GetTall(), c2 ) end
	C.frame:AddSheet( "Misc", tabs.misc, nil, false, false )
	C:createoption( "Checkbox", tabs.aimbot, "Aimbot Enabled", "aim", 5, 5 )
	C:createoption( "Checkbox", tabs.aimbot, "No View Change", "aim_silent", 5, 25 )
	C:createoption( "Checkbox", tabs.aimbot, "Aim at Teammates", "aim_team", 5, 45 )
	C:createoption( "Checkbox", tabs.aimbot, "Ignore Admins", "aim_ignoreadmins", 5, 65 )
	C:createoption( "Checkbox", tabs.aimbot, "Ignore Friendly Traitors", "aim_ignorefriendlytraitors", 5, 85 )
	C:createoption( "Checkbox", tabs.aimbot, "Ignore Steam Friends", "aim_ignorefriends", 5, 105 )
	C:createoption( "Checkbox", tabs.aimbot, "Snap On Fire", "aim_snaponfire", 5, 125 )
	C:createoption( "Checkbox", tabs.aimbot, "Autoshoot", "aim_autoshoot", 5, 145 )
	C:createoption( "Checkbox", tabs.aimbot, "Ignore Visibility Checks", "aim_ignorevisibility", 5, 165 )
	C:createoption( "Checkbox", tabs.aimbot, "Aim at OBBCenter", "aim_obbcenter", 5, 185 )
	C:createoption( "Checkbox", tabs.aimbot, "Velocity Compensation", "aim_comp", 150, 5 )
	C:createoption( "Checkbox", tabs.aimbot, "Nospread", "aim_nospread", 150, 25 )
	C:createoption( "Slider", tabs.aimbot, "Compensation Value", "aim_comp_val", 10, 80, 150, 150, 45 )
	C:createoption( "Slider", tabs.aimbot, "FOV", "aim_fov", 0, 180, 150, 150, 90 )
	C:createoption( "Slider", tabs.aimbot, "Offset Y", "aim_offset", -10, 10, 150, 150, 135 )
	C:createoption( "Checkbox", tabs.esp, "ESP Enabled", "esp", 5, 5 )
	C:createoption( "Checkbox", tabs.esp, "Name, Health, Status", "esp_info", 5, 25 )
	C:createoption( "Checkbox", tabs.esp, "Admin List", "esp_adminlist", 5, 45 )
	C:createoption( "Checkbox", tabs.esp, "RP Entities", "esp_rpents", 5, 65 )
	C:createoption( "Checkbox", tabs.esp, "TTT Traitor Weapons", "esp_traitorweps", 5, 85 )
	C:createoption( "Checkbox", tabs.esp, "Skeleton", "esp_skeleton", 5, 105 )
	C:createoption( "Checkbox", tabs.esp, "Chams", "esp_chams", 5, 125 )
	C:createoption( "Slider", tabs.esp, "Chams Type", "esp_chams_type", 1, 3, 100, 200, 10 )
	C:createoption( "Checkbox", tabs.misc, "Bunnyhopping", "bhop", 5, 5 )
	C:createoption( "Checkbox", tabs.misc, "Crosshair", "crosshair", 5, 25 )
	C:createoption( "Checkbox", tabs.misc, "Constant Namesteal", "namesteal_auto", 5, 45 )
	C:createoption( "Checkbox", tabs.misc, "No Visual Recoil", "novisualrecoil", 5, 65 )
	C:createoption( "Checkbox", tabs.misc, "ULX/Evolve Ungag", "ungag", 5, 85 )
	C:createoption( "Checkbox", tabs.misc, "Anti-Aim", "antiaim", 5, 105 )
	C:createoption( "Checkbox", tabs.misc, "Enable CalcView", "calcview", 5, 125 )
	C:createoption( "Button", tabs.misc, "Steal Random Name", "namesteal", 170, 15 )
	C:createoption( "Button", tabs.misc, "Anti-Mute", "antimute", 170, 50 )
end
C:addcommand( "+ph0ne_menu", C.menu )
C:addcommand( "-ph0ne_menu", function() if C.frame then C.frame:Remove() C.frame = nil end end )*/

C.cheat.ColorMsg( ":: ", Color( 255, 255, 255 ) )
C.cheat.ColorMsg( "CBaseAimbot successfully loaded.\n\n", Color( 255, 0, 0 ) )