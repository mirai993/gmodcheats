/*
	
	snixzz 1.0
	
	A cheat made for griefing and hvh
	Author: Tyler
	
	TODO:
		menu/console??
		constant nospread
		silent aim
		debug.getinfo detour
		anti cheat bypassens
		load before autorun
		unload function
		fix snixzz2's nospread
		bone scan? maybe too laggy idk
		improve prediction
		anti-aim
		add vars 
		file protection, maybe loading from C:/snixzz/ along with bypass/main module
		add general exploits
		name changer
		fix HL2 nospread
	
*/

local snixzz = {}
local _R = debug["getregistry"]()
// Yes, I know it doesn't make much of a difference using copied functions, but I chose to do it anyways.
snixzz["Copy"] = {
	["MsgN"] = MsgN,
	["tostring"] = tostring,
	["table"] = table,
	["hook"] = hook,
	["math"] = math,
	["surface"] = surface,
	["draw"] = draw,
	["ScrW"] = ScrW,
	["ScrH"] = ScrH,
	["pairs"] = pairs,
	["util"] = util,
	["http"] = http,
	["player"] = player,
	["input"] = input,
	["IsValid"] = IsValid,
	["LocalPlayer"] = LocalPlayer,
	["GetConVarNumber"] = GetConVarNumber,
	["SetMaterialOverride"] = SetMaterialOverride,
	["CreateMaterial"] = CreateMaterial,
	["Vector"] = Vector,
	["render"] = render,
	["Material"] = Material,
	["EyePos"] = EyePos,
	["EyeAngles"] = EyeAngles,
	["cam"] = cam,
	["team"] = team,
	["ents"] = ents,
	["Color"] = Color,
	["concommand"] = concommand,
	["vgui"] = vgui,
	["string"] = string,
	["RealFrameTime"] = RealFrameTime,
	["RunConsoleCommand"] = RunConsoleCommand,
	["require"] = require,
}

snixzz["Hooks"] = {
}
snixzz["Detours"] = {
}

snixzz["Features"] = {
	["Aimbot"] = MOUSE_MIDDLE,
	["Triggerbot"] = KEY_T,
	["SpeedHack"] = KEY_B,
	["NoSread"] = false, // WIP
	["NoRecoil"] = true,
	["Chams"] = false, // Laggggg
	["SilentAim"] = true,
}

snixzz["Target"] = nil
snixzz["Distance"] = 9999999999999 // max aimbot distance
snixzz["Shooting"] = false
snixzz["Locked"] = false
snixzz["FireBullets"] = {}
snixzz["Whitelist"] = {
}

snixzz["Cones"] = {
	["weapon_pistol"] = snixzz["Copy"]["Vector"]( -0.0100, -0.0100, -0.0100 ),
	["weapon_smg1"] = snixzz["Copy"]["Vector"]( -0.04362, -0.04362, -0.04362 ),
	["weapon_ar2"] = snixzz["Copy"]["Vector"]( -0.02618, -0.02618, -0.02618 ),
	["weapon_shotgun"] = snixzz["Copy"]["Vector"]( -0.08716, -0.08716, -0.08716 ),
}
snixzz["ConeBase"] = {
	["weapon_cs_base"] = true,
	["weapon_zs_base"] = true,
}
snixzz["Attachments"] = {
	"eyes",
	"forward",
	"head",
}

snixzz["Colors"] = {
}

snixzz["Files"] = {}

surface["CreateFont"]( "snixzz", { font = "Trebuchet18", size = 12, antialias = false } )

// snixzz2.dll will eventually replace these...
snixzz["Copy"]["require"]( "nospread" )
snixzz["Copy"]["require"]( "nyx" ) // Has a lot of useful functions, fuck off
_nyx["Init"]()


function snixzz.Detour( Old, New )	
	snixzz["Detours"][New] = Old
	return New
end

/* General notification/display functions */

function snixzz.Message( col, txt )
	MsgC( Color( 255, 89, 15 ), "[snixzz] " )
	MsgC( col, txt .. "\n" )
end

/* Anti-Cheat bypass functions */
_G["GetConVarNumber"] = snixzz["Detour"]( _G["GetConVarNumber"], function(cvar)
if cvar == "sv_cheats" then return 0 end
if cvar == "sv_allowcslua" then return 0 end
if cvar == "host_timescale" then return 1 end
if cvar == "host_framerate" then return 0 end
end)
function snixzz.AntiCheats()
	
	if string["find"]( GetHostName(), "Impacted" ) then
		snixzz["Message"]( Color( 255, 0, 0 ), "Bypassing Impacted anti-cheat" )
		snixzz["Copy"]["hook"]["Remove"]( "detrp" )
		snixzz["Copy"]["concommand"]["Add"]( "0_u_found", function()
snixzz["Message"]( Color( 50, 255, 50 ), "0_u_found blocked" )
end )
	end
	
	// not sure if this will work yet (untested)
	if QAC then
		if QAC == true then
			snixzz["Message"]( Color( 255, 0, 0 ), "This server has QAC installed." )
			hook.Remove("OnGamemodeLoaded", "___scan_g_init")
		end
	end
	if _G["CheckVars"] then
		snixzz["Message"]( Color( 50, 255, 50 ), "function CheckVars exists, detouring." )
		_G["CheckVars"] = snixzz["Detour"]( _G["CheckVars"], function()
			snixzz["Message"]( Color( 50, 255, 50 ), "HERP-AC attempted to scan cvars, stopping that..." )
		end )
	end
	if _G["RunCheck"] then
		snixzz["Message"]( "function RunCheck exists, detouring." )
		_G["RunCheck"] = snixzz["Detour"]( _G["RunCheck"], function()
			snixzz["Message"]( Color( 50, 255, 50 ), "TAC attempted to run a check, returning nothing." )
		end )
 	end
end
snixzz["Copy"]["concommand"]["Add"]("checkdead", function()
	for k,v in pairs(player.GetAll()) do
		if !(v:Alive()) then
			snixzz.Message(Color(255,0,0,255), v:Nick() .. " is dead.")
		end
	end
	end)
snixzz["AntiCheats"]()

/* Hooking functions */

function snixzz.RegisterHook( Type, Function )
	snixzz["Message"]( Color( 255, 255, 255 ), "Hooking function " .. Type .." into " .. snixzz["Copy"]["string"]["Replace"]( snixzz["Copy"]["tostring"]( Function ), "function: ", "" ) )
	snixzz["Copy"]["table"]["insert"]( snixzz["Hooks"], snixzz["Copy"]["string"]["Replace"]( snixzz["Copy"]["tostring"]( Function ), "function: ", "" ) )
	return snixzz["Copy"]["hook"]["Add"]( Type, snixzz["Copy"]["string"]["Replace"]( snixzz["Copy"]["tostring"]( Function ), "function: ", "" ), Function )
end

/* ESP Functions */
function snixzz.CanSeeEnt( ent )    
	local tr = {}
	tr["start"] = snixzz["Copy"]["LocalPlayer"]():GetShootPos()
	tr["endpos"] = ent:GetPos() + snixzz["Copy"]["Vector"]( 0, 0, 5 )
	tr["filter"] = { snixzz["Copy"]["LocalPlayer"](), ent }
	tr["mask"] = MASK_SHOT	
    local trace = snixzz["Copy"]["util"]["TraceLine"]( tr )
    if ( trace["Fraction"] == 1 ) then 
        return true
    else 
        return false
    end     
end

/* Aimbot functions */

function snixzz.GetCone( wep )

	if !snixzz["Copy"]["IsValid"]( wep ) then
		return 0 
	end	
	
	if snixzz["Cones"][ wep:GetClass() ] then
		return snixzz["Cones"][ wep:GetClass() ] 
	end
	if snixzz["ConeBase"][ wep["Base"] ] then return
		wep["Cone"] or wep["Primary"]["Cone"] or 0
	end	
	
	local Cone = wep["Cone"]	
	if !Cone then
		Cone = wep["Primary"] && wep["Primary"]["Cone"] or 0
	end	
	return Cone
end


function snixzz.PredictSpread( cmd, ang )
local w = snixzz["Copy"]["LocalPlayer"]():GetActiveWeapon()
local vecCone, valCone = snixzz["Copy"]["Vector"]( 0, 0, 0 )

	if ( w && w:IsValid() && ( type( w["Initialize"] ) == "function" ) ) then
		valCone = snixzz["GetCone"]( w )                    
		if ( type( valCone ) == "number" ) then
			vecCone = snixzz["Copy"]["Vector"]( -valCone, -valCone, -valCone )                      
		elseif ( type( valCone ) == "Vector" ) then
			vecCone = valCone * -1     
		elseif bit["band"]( cmd:GetButtons(), IN_SPEED ) or bit["band"]( cmd:GetButtons(), IN_JUMP ) then
			vecCone = valCone + ( cone * 2 )                        
		end
	end
	
	return DS_manipulateShot( DS_md5PseudoRandom( DS_getUCMDCommandNumber( cmd ) ), ang:Forward(), vecCone ):Angle()
end

function snixzz.Aimspot( e )

	for k, v in snixzz["Copy"]["pairs"]( snixzz["Attachments"] ) do
		if e:LookupAttachment( v ) then
			local att = e:GetAttachment( e:LookupAttachment( v ) )
			if( att ) then
				return att["Pos"]
			end
		end
	end
	
	return ( e:LocalToWorld( e:OBBCenter() ) )
end

function snixzz.IsVisible( v )
	local tracedata = {}
	tracedata["start"] 	= snixzz["Copy"]["LocalPlayer"]():GetShootPos()
	tracedata["endpos"] = snixzz["Aimspot"]( v )
	tracedata["filter"] = { snixzz["Copy"]["LocalPlayer"](), v }
	tracedata["mask"] = MASK_SHOT 						
	local trace = snixzz["Copy"]["util"]["TraceLine"]( tracedata )
	return trace["Fraction"] == 1
end

function snixzz.IsValid( e )

	if ( !snixzz["Copy"]["IsValid"]( e ) || e == snixzz["Copy"]["LocalPlayer"]() ) then
		return false
	end
	
	if _nyx["IsDormant"]( e:EntIndex() ) then 
		return false
	end
	
	if snixzz["Copy"]["table"]["HasValue"]( snixzz["Whitelist"], e:SteamID() ) then 
		return false	
	end
	
	if ( !e:Alive() || !e:IsPlayer() || e:InVehicle() ) then 
		return false 
	end
	
	if ( snixzz["Copy"]["GetConVarNumber"]( "sbox_noclip" ) == 0 && e:GetMoveType() == MOVETYPE_NOCLIP ) then 
		return false 
	end
	
	//if e:GetFriendStatus() == "friend" then 
	//	return false 
	//end
	if ( e:GetMoveType() == MOVETYPE_OBSERVER || e:Team() == TEAM_SPECTATOR ) then 
		return false 
	end
	
	local col = e:GetColor()
	if col["a"] < 255 then
		return false
	end
	
	if snixzz["Copy"]["LocalPlayer"]():GetColor()["a"] < 255 then
		return false
	end
	
	if !snixzz["IsVisible"]( e ) then
		return false
	end
	if e:Team() == LocalPlayer():Team() then
		return false
	end
	return true
end

function snixzz.GetTarget()
	if !snixzz["Features"]["Aimbot"] then return end
	for k, v in snixzz["Copy"]["pairs"]( snixzz["Copy"]["player"]["GetAll"]() ) do
		if ( snixzz["IsVisible"]( v ) && snixzz["IsValid"]( v ) ) then
			local distance = snixzz["Copy"]["math"]["deg"]( snixzz["Copy"]["math"]["acos"]( snixzz["Copy"]["LocalPlayer"]():GetAimVector():Dot( ( snixzz["Aimspot"]( v ) - snixzz["Copy"]["LocalPlayer"]():GetShootPos() ):GetNormal() ) ) )
			if( distance < snixzz["Distance"] ) then
				snixzz["Target"] = v
			end
		end
	end
	return snixzz["Target"]
end

/*
local function CalculateTargets( cmd )

// Calculate best targets
local best;

local lastDistance = 1024;
local lastPos = nil;

for k, v in g.pairs( g.player.GetAll() ) do

if ( v != me && CanTarget( v ) && NH.InFov( v ) ) then

local pos, ang = FindPoint( v );
if ( NH:IsVisible( r.Player.GetShootPos( me ), pos, v ) ) then

local W, H = g.ScrW(), g.ScrH();
local x, y, onscreen = NH.VectorToLPCameraScreen( r.Vector.GetNormal( pos - r.Entity.EyePos( me ) ), W, H, r.Entity.EyeAngles( me ), g.math.rad( r.Player.GetFOV( me ) ) );

if ( x < 0 || y < 0 || x > W || y > H ) then continue; end;

local dist = g.math.Distance( x, y, W / 2, H / 2 );

if ( dist < lastDistance ) then

best = v;
lastDistance = dist;
lastPos = pos;

end;

end;

end;

end;

BestTarget = best;

end
*/


function snixzz.NormalizeAngles( Angl )
	Angl["p"] = snixzz["Copy"]["math"]["NormalizeAngle"]( Angl["p"] )
	Angl["y"] = snixzz["Copy"]["math"]["NormalizeAngle"]( Angl["y"] )
	Angl["r"] = 0
end

function snixzz.Prediction( Pos, e )
	if ( snixzz["Copy"]["IsValid"]( e ) && type( e:GetVelocity() ) == "Vector" && e["GetPos"] && type( e:GetPos() ) == "Vector" ) then
		local eSpeed = snixzz["Target"]():GetVelocity() * 0.013
        local plySpeed = snixzz["Copy"]["LocalPlayer"]():GetVelocity() * 0.013	
		return ( Pos - plySpeed + eSpeed )
	end
	return Pos
end

/* Material functions */

function snixzz.CreateMaterial()
	local BaseInfo = {
		["$basetexture"] = "models/debug/debugwhite",
		["$model"]       = 1,
		["$translucent"] = 1,
		["$alpha"]       = 1,
		["$nocull"]      = 1,
		["$ignorez"]	 = 1
	}	
   return snixzz["Copy"]["CreateMaterial"]( "snixzzMaterial", "VertexLitGeneric", BaseInfo )
end

/*=======================


Hooked functions below


=========================*/

function snixzz.CalcView( ply, origin, angles, FOV )
	local ply = snixzz["Copy"]["LocalPlayer"]()
	local wep = ply:GetActiveWeapon()

	// visual no recoil
	if ( wep["Primary"]	) then wep["Primary"]["Recoil"] = 0 end
	if ( wep["Secondary"] ) then wep["Secondary"]["Recoil"]	= 0 end

	// other view shit, such as nospread view correction
	local view = GAMEMODE:CalcView( ply, origin, angles, FOV ) || {}
	view["angles"] = snixzz["ViewAngles"]
	view["angles"]["r"] = 0
	return view
	
end

function snixzz.CreateMove( ucmd )
	
	// Aimbot vars
	snixzz["ViewAngles"] = ucmd:GetViewAngles() // For nospread view correction
	snixzz["Angles"] = ucmd:GetViewAngles()
	snixzz["Target"] = snixzz["GetTarget"]()

	// Aimbot core
	if( snixzz["Copy"]["input"]["IsMouseDown"]( snixzz["Features"]["Aimbot"] ) ) then
		if( !snixzz["Target"] ) then return end

		if snixzz["IsValid"]( snixzz["Target"] ) then
			
			snixzz["Locked"] = true // hey you have a target!
		
			snixzz["Angles"] = ( snixzz["Prediction"]( snixzz["Aimspot"]( snixzz["Target"] ) ) - Vector( 0, 0, 0 ) ) // 0 offset
			
			snixzz["Angles"] = ( snixzz["Angles"] - snixzz["Copy"]["LocalPlayer"]():GetShootPos() ):GetNormal():Angle()
			snixzz["SetAngle"] = snixzz["PredictSpread"]( ucmd, Angle( snixzz["Angles"]["p"], snixzz["Angles"]["y"], 0 ) )
			snixzz["ViewAngles"] = snixzz["Angles"]
			
			snixzz["NormalizeAngles"]( snixzz["Angles"] )

			ucmd:SetViewAngles( snixzz["SetAngle"] )
			ucmd:SetButtons( bit["bor"]( ucmd:GetButtons(), IN_ATTACK ) )		
		end
	end
	
	// Bunnyhop
	_nyx["Bunnyhop"]( ucmd, snixzz["Copy"]["LocalPlayer"]():IsOnGround(), snixzz["Copy"]["LocalPlayer"]():GetMoveType() )
	
	// speedhack
	if snixzz["Copy"]["input"]["IsKeyDown"]( snixzz["Features"]["SpeedHack"] ) then
		_nyx["Speedhack"]( true )
	else
		_nyx["Speedhack"]( false )
	end

	// no recoil
	if snixzz["Copy"]["LocalPlayer"]():GetActiveWeapon()["Primary"] then
		snixzz["Copy"]["LocalPlayer"]():GetActiveWeapon()["Primary"]["Recoil"] = 0
	end
	
end

function snixzz.HUDPaint()
	for k, v in snixzz["Copy"]["pairs"]( snixzz["Copy"]["ents"]["GetAll"]() ) do		
		
		// Player esp	
		if ( snixzz["Copy"]["IsValid"]( v ) && v:IsPlayer() && v:Alive() && !_nyx["IsDormant"]( v:EntIndex() ) && v != snixzz["Copy"]["LocalPlayer"]()  && v:Team() != TEAM_SPECTATOR ) then
			// Material
			local mat = snixzz["CreateMaterial"]()
			local font = "snixzz"
			
			// ESP Positions
			local bottom = ( v:GetPos() - snixzz["Copy"]["Vector"]( 0, 0, 10 ) ):ToScreen()
			local top = ( v:GetPos() + snixzz["Copy"]["Vector"]( 0, 0, 70 ) ):ToScreen()
			local height = ( bottom["y"] - top["y"] )
			local width = ( height / 4 )
			
			local wep
			if snixzz["Copy"]["IsValid"]( v:GetActiveWeapon() ) then
				wep = v:GetActiveWeapon():GetPrintName()
			else
				wep = "Unknown"
			end
			
			// player text color
			local color = snixzz["Copy"]["team"]["GetColor"]( v:Team() )
			if v:GetFriendStatus() == "friend" then
				color = Color( 50, 255, 50, 255 )
			elseif ( v:IsAdmin() or v:IsSuperAdmin() ) then
				color = Color( 255, 50, 50, 255 )
			end
			
			// player box color
			local boxcolor = snixzz["Copy"]["team"]["GetColor"]( v:Team() )
			if v == snixzz["Target"] then
				boxcolor = Color( 50, 150, 255, 255 )
			elseif snixzz["CanSeeEnt"]( v ) then
				boxcolor = Color( 50, 255, 50, 255 )
			elseif !snixzz["CanSeeEnt"]( v ) then
				boxcolor = Color( 255, 50, 50, 255 )
			end
			
			// ESP text
			draw["DrawText"]( v:Nick() .. " [" .. v:Health() .. "]", font, top["x"], top["y"] - 14, color, 1 )
			draw["DrawText"]( wep, font, bottom["x"], bottom["y"] - 3, color, 1 )
			
			// Box ESP
			surface["SetDrawColor"]( boxcolor )
			surface["DrawOutlinedRect"]( top["x"] - width, top["y"], width * 2, height )
		end
			
		// crosshair color
		local color2 = Color( 255, 0, 0, 255 )
		if snixzz["Copy"]["LocalPlayer"]():GetEyeTrace()["Entity"]:IsPlayer() then
			color2 = Color( 0, 255, 0, 255 )
		else
			color2 = Color( 255, 0, 0, 255 )
		end
		
		// crosshair core
		surface["SetDrawColor"]( color2 )
		local size = 8 // Swastika size
		surface["DrawLine"]( snixzz["Copy"]["ScrW"]() / 2, snixzz["Copy"]["ScrH"]() / 2, snixzz["Copy"]["ScrW"]() / 2 + size, snixzz["Copy"]["ScrH"]() / 2 )
		surface["DrawLine"]( snixzz["Copy"]["ScrW"]() / 2 + size, snixzz["Copy"]["ScrH"]() / 2, snixzz["Copy"]["ScrW"]() / 2 + size, snixzz["Copy"]["ScrH"]() / 2 + size )
		surface["DrawLine"]( snixzz["Copy"]["ScrW"]() / 2, snixzz["Copy"]["ScrH"]() / 2, snixzz["Copy"]["ScrW"]() / 2 - size, snixzz["Copy"]["ScrH"]() / 2 )
		surface["DrawLine"]( snixzz["Copy"]["ScrW"]() / 2 - size, snixzz["Copy"]["ScrH"]() / 2, snixzz["Copy"]["ScrW"]() / 2 - size, snixzz["Copy"]["ScrH"]() / 2 - size )
		surface["DrawLine"]( snixzz["Copy"]["ScrW"]() / 2, snixzz["Copy"]["ScrH"]() / 2, snixzz["Copy"]["ScrW"]() / 2, snixzz["Copy"]["ScrH"]() / 2 - size )
		surface["DrawLine"]( snixzz["Copy"]["ScrW"]() / 2, snixzz["Copy"]["ScrH"]() / 2 - size, snixzz["Copy"]["ScrW"]() / 2 + size, snixzz["Copy"]["ScrH"]() / 2 - size )
		surface["DrawLine"]( snixzz["Copy"]["ScrW"]() / 2, snixzz["Copy"]["ScrH"]() / 2, snixzz["Copy"]["ScrW"]() / 2, snixzz["Copy"]["ScrH"]() / 2 + size )
		surface["DrawLine"]( snixzz["Copy"]["ScrW"]() / 2, snixzz["Copy"]["ScrH"]() / 2 + size, snixzz["Copy"]["ScrW"]() / 2 - size, snixzz["Copy"]["ScrH"]() / 2 + size )
	end
end

snixzz["Message"]( Color( 255, 180, 180, 255 ), "Loading hooks" )
snixzz["RegisterHook"]( "CreateMove", snixzz["CreateMove"] )
snixzz["RegisterHook"]( "HUDPaint", snixzz["HUDPaint"] )
snixzz["RegisterHook"]( "CalcView", snixzz["CalcView"] )
snixzz["Message"]( Color( 0, 255, 130 ), "snixzz initialized." )


/*
	DETOURS
	Adding them as I go, don't bitch that I haven't detoured every function 
*/

_R["Entity"]["FireBullets"] = snixzz["Detour"]( _R["Entity"]["FireBullets"], function( e, bullet )
	snixzz["FireBullets"][ snixzz["Copy"]["LocalPlayer"]():GetActiveWeapon():GetClass() ] = bullet["Spread"]
	return snixzz["Detours"][ _R["Entity"]["FireBullets"] ]( e, bullet )
end )

file["Exists"] = snixzz["Detour"]( file["Exists"], function( filename, dir )
	if string["find"]( filename, "snixzz" ) then // stay out
		snixzz["Message"]( Color( 255, 0, 0 ), "An anti-cheat attempted to search for snixzz" )
		return false
	else
		return snixzz["Detours"][ file["Exists"] ]( filename, dir )
	end
end )

file["Read"] = snixzz["Detour"]( file["Read"], function( filename, dir )
	if string["find"]( filename, "snixzz" ) then 
		return "No, you can not have my source code."
	else
		return snixzz["Detours"][ file["Read"] ]( filename, dir )
	end
end )

net["Start"] = snixzz["Detour"]( net["Start"], function( name )
	if name == "checksaum" || name == "send" then
		snixzz["Message"]( Color( 255, 0, 0 ), "Blocked net.Send " .. name )
		return
	else
		return snixzz["Detours"][ net["Start"] ]( name )
	end
end )