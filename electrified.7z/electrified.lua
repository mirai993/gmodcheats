--[[
ElectfRied Private Gmod Hook
"We Do Not Forget. We Do Not Forgive"

Electfried Private Gmod Anonymous Hook v.1

AuthoRized Vip Registered Users
ElectfRied
shimm3y
Plex
ultra
Darkbyte
Jynxx
All PoKi MemBers
--]]

/************************************
	Contact Information
	
	/id/electfried
	/id/electfriedalt
	
	Official Employer Steam Groups
	
	/groups/sinewaveteam
	/groups/employer
	
"Need Help Coding , Have A Lua Question ? Don't Be Afraid Too Contact Me . "

************************************/

/************************************
	Name: Local Injection Copies
	Purpose: Make Gmod Hook Faster
	Author: Electfried
	OS: Windows 10 Ultimate 64 Bits
************************************/

MsgN("Injecting Local Copies By Electfried ...")
local surface = surface
local table = table
local ents = ents
local Vector = Vector
local render = render
local cam = cam
local Angle = Angle
local player = player
local team = team
local ScrW = ScrW
local ScrH = ScrH
local util = util
local math = math
local type = type
local tostring = tostring
local string = string
local CurTime = CurTime
local Color = Color
local hook = hook
MsgN("Injection InToo Local Copies By Electfried Success")

/************************************
	Name: Console Variables
	Purpose: Inject Private Settings By Electfried
	Author: Electfried
	OS: Windows 10 Ultimate 64 Bits
************************************/

MsgN("Injecting Local Console Variables By Electfried...")
local espC = CreateClientConVar("Employer_Esp_Yes", "1", true, false)
local twoboxC = CreateClientConVar("Employer_2DBox_Yes", "1", true, false)
local bhopC = CreateClientConVar("Employer_BHop_Yes", "1", true, false)
local noskyC = CreateClientConVar("Employer_NoSky_Yes", "0", true, false)
local chamsC = CreateClientConVar("Employer_Chams_Yes", "0", true, false)
local wepchamsC = CreateClientConVar("Employer_WepChams_Yes", "0", true, false)
local eyetracersC = CreateClientConVar("Employer_EyeTracers_Yes", "1", true, false)
local threedtracerC = CreateClientConVar("Employer_3DTracer_Yes", "1", true, false)
local wepespC = CreateClientConVar("Employer_WepEsp_Yes", "1", true, false)
local crossedhairC = CreateClientConVar("Employer_CrossedHair_Yes", "1", true, false)
local sinewaveespC = CreateClientConVar("Employer_SineWaveEsp_Yes", "0", true, false)
local chatinfoC = CreateClientConVar("Employer_ChatInfo_Yes", "1", true, false)
local xrayC = CreateClientConVar("Employer_XRay_Yes", "0", true, false)
local propnameC = CreateClientConVar("Employer_PropName_Yes", "1", true, false)
local safeC = CreateClientConVar("Employer_Safe_Yes", "1", true, false)
local twodtracerC = CreateClientConVar("Employer_2DTracer_Yes", "0", true, false)
local longshothelpertwodC = CreateClientConVar("employer_LongshotHelper2D_Yes", "0", true, false)
local longshothelperthreedC = CreateClientConVar("Employer_LongshotHelper3D_Yes", "0", true, false)
local proplogC = CreateClientConVar("Employer_PropLog_Yes", "1", true, false)
local propdrawcounterC = CreateClientConVar("Employer_PropDrawCounter_Yes", "1", true, false)
local headsmashbeamC = CreateClientConVar("Employer_HeadSmashBeam_Yes", "1", true, false)
local threedboxC = CreateClientConVar("Employer_3DBox_Yes", "0", true, false)
local threedtwodboxC = CreateClientConVar("Employer_3D2DBox_Yes", "0", true, false)
local fovC = CreateClientConVar("Employer_Fov", "130", true, false)
local fovenableC = CreateClientConVar("Employer_FovEnable_Yes", "1", true, false)
local aimbotC = CreateClientConVar("Employer_AimBot_Yes", "1", true, false)
local propaimbotC = CreateClientConVar("Employer_PropAimBot_Yes", "0", true, false)
local thirdpersonC = CreateClientConVar("Employer_ThirdPerson_Yes", "0", true, false)
local asuswallC = CreateClientConVar("Employer_AsusWall_Yes", "0", true, false)
local repeatC = CreateClientConVar("Employer_Repeat_Yes", "0", true, false)
MsgN("Injection Of Local Console Variables By Electfried Success")

/************************************
	Name: Lua Code Encrypter
	Purpose: Lua Hook Encrypter By Electfried
	Author: Electfried
	OS: Windows 10 Ultimate 64 Bits
************************************/

local function ByteConvert(x) 
--	{
	if type(x) ~= "string" then return end
	local tb = {string.byte(x, 1, #x)}
	local emp = ""
	emp = emp .. "\\" .. table.concat(tb, "\\")
	return emp
--	}
end

/************************************
	Name: Private Lua Fonts By Electfried
	Purpose: Inject Private Lua Fonts By Electfried
	Author: Electfried
	OS: Windows 10 Ultimate 64 Bits
************************************/

MsgN("Beginning Injection Of Private Lua Fonts...")

surface.CreateFont("cfont2", {
font = "Default",
size = 30, 
weight = 1,
outline = true,
antialias = false
})

surface.CreateFont("cfont3", {
font = "Default",
size = 40, 
weight = 1,
outline = true,
antialias = false
})

MsgN("Injection Of Private Lua Fonts Success")

/************************************
	Name: Private Colour Shifter By Electfried
	Purpose: Private Hook Too Inject Color Shifting InToo The Lua State
	Author: Electfried
	OS: Windows 10 Ultimate 64 Bits
************************************/

local function colshit()
--	{
	local col = HSVToColor(CurTime() % 6 * 60, 1, 1)
	return Vector(col.r/255, col.g/255, col.b/255)
--	}
end

local function colshit2()
--	{
	local col2 = HSVToColor(CurTime() % 6 * 60, 1, 1)
	return Color(col2.r, col2.g, col2.b)
--	}
end

/************************************
	Name: Private WaterMark Hook By Electfried
	Purpose: Private Hook Too Render WaterMark By Electfried
	Author: Electfried
	OS: Windows 10 Ultimate 64 Bits
************************************/

MsgN("Beginning Injection Of Private Lua WaterMark Hook By Electfried...")

local function watermark()
--	{
	surface.SetFont("cfont2")
	surface.SetTextColor(colshit2())
	surface.SetTextPos(ScrW() / 24, ScrH() / 14)
	surface.DrawText("__Employer Private Build V.Sin(90) [WARNING: UNREGISTERED COPY]")
	surface.SetTextPos(ScrW() / 24, ScrH() / 10)
	surface.DrawText(tostring(GetHostName()))
	surface.SetTextPos(ScrW() / 24, ScrH() / 7.7)
	surface.DrawText(game.GetIPAddress())
--	}
end

MsgN("Injection Of Private Lua WaterMark By Electfried Success")

/************************************
	Name: Private Lua Function Injection Detour By Electfried
	Purpose: Detour The __MetaTables By Electfried
	Author: Electfried
	OS: Windows 10 Ultimate 64 Bits
************************************/

MsgN("Beginning Injection Of Private Lua __MetaTable Detours")

local function safe()
--	{
	if not safeC:GetBool() then return end
	function render.Capture() chat.AddText(Color(255, 0, 0), "render.Capture() blocked By Electfried") return false end
	function render.CapturePixels() chat.AddText(Color(255, 0, 0), "render.CapturePixels() blocked By Electfried") return false end
	function gui.OpenURL() chat.AddText(Color(255, 0, 0), "gui.OpenURL() blocked By Electfried") return false end
	function http.Fetch() chat.AddText(Color(255, 0, 0), "http.Fetch() blocked By Electfried") return false end
	function file.Read() chat.AddText(Color(255, 0, 0), "file.Read() blocked By Electfried") return false end
	function file.Write() chat.AddText(Color(255, 0, 0), "file.Write() blocked By Electfried") return false end
	function file.Append() chat.AddText(Color(255, 0, 0), "file.Append() blocked By Electfried") return false end
	function file.CreateDir() chat.AddText(Color(255, 0, 0), "file.CreateDir() blocked By Electfried") return false end
	function file.Delete() chat.AddText(Color(255, 0, 0), "file.Delete() blocked By Electfried") return false end
	function file.Exists() chat.AddText(Color(255, 0, 0), "file.Exists() blocked By Electfried") return false end
	local a = FindMetaTable("Player") 
//	function a:ConCommand() chat.AddText(Color(255, 0, 0), "ConCommand() blocked By Electfried") return false end
--	}
end

MsgN("Injection Of Private Lua __MetaTables Complete")


/************************************
	Name: Private Three Dimensional Vector Hack By Electfried
	Purpose: Private Three Dimensional Vector Hack By Electfried
	Author: Electfried
	OS: Windows 10 Ultimate 64 Bits
************************************/

local function midpoint(x, x2, y, y2, z, z2) 
--	{
	local addx = x + x2
	local addy = y + y2
	local addz = z + z2
	return Vector(addx / 2, addy / 2, addz / 2)
--	}
end


/************************************
	Name: Private Lua Colour Hook By Electfried
	Purpose: Inject Private Lua Colours InToo Lua State
	Author: Electfried
	OS: Windows 10 Ultimate 64 Bits
************************************/

MsgN("Beginning Injection Of Private Lua Colours...")

local ColorTable = {
Color(255, 0, 0), 
Color(0, 255, 0), 
Color(0, 0, 255), 
Color(255, 255, 255), 
Color(0, 255, 255), 
Color(255, 0, 255), 
Color(255, 255, 0), 
Color(124, 252, 0),
Color(128, 0, 252),
Color(252, 128, 0),
Color(0, 252, 128),
Color(238, 130, 238),
Color(169, 169, 169),
Color(255, 69, 0),
Color(0, 59, 255),
Color(165, 42, 42),
Color(165, 165, 42),
Color(161, 202, 241),
Color(222, 93, 131),
Color(199, 21, 133),
Color(21, 199, 87),
Color(87, 21, 199),
Color(199, 176, 21),
Color(21, 133, 199),
Color(199, 87, 21),
Color(199, 21, 44),
Color(176, 21, 199),
Color(50, 205, 50),
Color(128, 50, 205),
Color(51, 50, 205),
Color(205, 129, 50),
Color(50, 126, 205),
Color(50, 204, 205),
Color(205, 51, 50),
Color(205, 50, 127),
Color(128, 50, 205),
}

MsgN("InJection Of Private Lua Colours Success")

MsgN("Injecting Additional Fonts...")

surface.CreateFont("cfont", {
font = "Default",
size = 14,
weight = 1,
antialias = false,
outline = true
})

MsgN("Injection Of Additional Fonts Success")

/************************************
	Name: Custom Local Player Hook By Electfried
	Purpose: Private Custom Local Player Detour By Electfried
	Author: Electfried
	OS: Windows 10 Ultimate 64 Bits
************************************/

MsgN("Beginning Injection Of LocalPlayer Detour By Electfried...")

local ply = LocalPlayer()

MsgN("Injection Of Private Local Player Detour By Electfried Success")

/************************************
	Name: Custom Private IsValid Detour By Electfried
	Purpose: Private Detour Of IsValid Detour By Electfried
	Author: Electfried
	OS: Windows 10 Ultimate 64 Bits
************************************/

MsgN("Beginning Injection Of Private Custom IsValid Detour By Electfried...")

local function valid(x)
--	{
	if not IsValid(x) or not x:Alive() or x == ply or x:IsDormant() or x:Team() == TEAM_SPECTATOR or x:HasGodMode() then
		return false
	else
		return true
	end
--	}
end

MsgN("Injection Of Private Custom IsValid Detour By Electfried Success")

/************************************
	Name: Custom Private Two Dimensional Tracer By Electfried
	Purpose: Injects Custom Tracer By Electfried InToo Lua State 
	Author: Electfried
	OS: Windows 10 Ultimate 64 Bits
************************************/

MsgN("Beginning Injection Of Private Two Dimensional Lua Tracer By Electfried")

local function TwoDTracer()
--	{
	if not twodtracerC:GetBool() then return end
	for k,v in next, player.GetAll() do
--	}
--		{
		if valid(v) then
			local pos = v:GetShootPos():ToScreen()
			local center = Vector(ScrW()/2, ScrH()/2)
			if pos.x > ScrW() or pos.x < 0 or pos.y > ScrH() or pos.y < 0 then continue end
			surface.SetDrawColor(ColorTable[k % 255])
			surface.DrawLine(center.x, center.y, pos.x, pos.y)
--		}
		end
	end
end

MsgN("Injection Of Private Lua Two Dimensional Tracer By Electfried Success")

/************************************
	Name: Custom Private Three Dimensional Tracer By Electfried
	Purpose: Injects Custom Tracer By Electfried InToo Lua State 
	Author: Electfried
	OS: Windows 10 Ultimate 64 Bits
************************************/

MsgN("Beginning Injection Of Private Three Dimensional Lua Tracer By Electfried")

local function ThreeDTracer()
--	{
	if not threedtracerC:GetBool() then return end
	for k,v in next, player.GetAll() do
--	}
--		{
		if valid(v) then
			local pos = v:GetShootPos()
			local screen = EyePos() + ply:GetAimVector() * 100
--			{
			cam.Start3D()
--				{
				render.SetColorMaterialIgnoreZ()
				render.DrawBeam(screen, pos, .2, 1, 1, ColorTable[k % 255])
--				}
			cam.End3D()
--			}
--		}
		end
	end
end

MsgN("Injection Of Private Lua Three Dimensional Tracer By Electfried Success")

/************************************
	Name: Custom Private Fov Detour By Electfried
	Purpose: Detours The MetaTables To Detour Your Fov By Electfried
	Author: Electfried
	OS: Windows 10 Ultimate 64 Bits
************************************/

MsgN("Beginning Injection Of Private Fov Detour By Electfried")

local function fov(_, _, angles, fov) -- I Recommend Using This When Using 3D Tracers For Shooting
--	{
	if not fovenableC:GetBool() then return end
	local fovtable = {}
	fovtable.angles = ply:EyeAngles()
	fovtable.fov = math.abs(GetConVar("employer_fov"):GetInt())
	return fovtable
--	}
end

MsgN("Injection Of Private Lua Fov Detour By Electfried Success")

/************************************
	Name: Custom Private Distance Detour By Electfried
	Purpose: Detours The MetaTables To Detour The Distance By Electfried
	Author: Electfried
	OS: Windows 10 Ultimate 64 Bits
************************************/

MsgN("Beginning Injection Of Private Distance Detour By Electfried")

local function DistancePropEspTwoD() -- 2D LongShoot Helper
--	{
	if not CPPI or not longshothelpertwodC:GetBool() then return end
--	}
	for k,v in next, ents.GetAll() do
		if IsValid(v) and v:CPPIGetOwner() == ply and v:GetClass() == "prop_physics" then
--			{
			local pos = v:LocalToWorld(v:OBBCenter()):ToScreen()
			if pos.x > ScrW() or pos.x < 0 or pos.y > ScrH() or pos.y < 0 then continue end
			for j, k in next, player.GetAll() do
--			}
				if valid(k) then
--					{
					local plypos = k:GetShootPos():ToScreen() -- used to find the mid point
					local mid = Vector((plypos.x + pos.x) / 2, (plypos.y + pos.y) / 2)
					if k:GetShootPos():Distance(v:GetPos()) / 16 > 20 then continue end
					if plypos.x > ScrW() or plypos.x < 0 or plypos.y > ScrH() or plypos.y < 0 then continue end
					surface.SetFont("cfont")
					surface.SetTextColor(ColorTable[j % 255])
					surface.SetTextPos(mid.x, mid.y)
					surface.DrawText(tostring(math.abs(math.floor(k:GetShootPos():Distance(v:GetPos()) / 16)) .. " ft"))
					surface.SetDrawColor(ColorTable[j % 255])
					surface.DrawLine(pos.x, pos.y, plypos.x, plypos.y)
--					}
				end
			end
		end
	end
end

MsgN("Injection Of Private Lua Distance Detour By Electfried Success")

/************************************
	Name: Custom Private Three Dimensional Distance Detour By Electfried
	Purpose: Detours The MetaTables To Detour The Three Dimensional Distance By Electfried
	Author: Electfried
	OS: Windows 10 Ultimate 64 Bits
************************************/

MsgN("Beginning Injection Of Private Three Dimensional Distance Detour By Electfried")

local function DistancePropEspThreeD() -- 3D Version Of LongShoot Helper
--	{
	if not CPPI or not longshothelperthreedC:GetBool() then return end
--	}
	for k,v in next, ents.GetAll() do
--		{
		if IsValid(v) and v:CPPIGetOwner() == ply then
			local screenpos = v:LocalToWorld(v:OBBCenter()):ToScreen()
			local pos = v:LocalToWorld(v:OBBCenter())
--		}
			for i, j in next, player.GetAll() do
				if valid(j) then
--					{
					local screenplypos = j:GetShootPos():ToScreen()
					local plypos = j:GetShootPos()
					local mid = Vector((screenplypos.x + screenpos.x) / 2, (screenplypos.y + screenpos.y) / 2)
					if math.abs(math.floor(pos:Distance(plypos))) / 16 > 20 then continue end
					if math.abs(math.floor(pos:Distance(plypos))) / 16 <= 20 then
--					}
						cam.Start3D()
--						{
							render.SetColorMaterialIgnoreZ()
							render.DrawBeam(pos, plypos, 2, 1, 1, ColorTable[i % 255])
--						}
						cam.End3D()
--					{
						surface.SetFont("cfont")
						surface.SetTextColor(ColorTable[i % 255])
						surface.SetTextPos(mid.x, mid.y)
						surface.DrawText(tostring(math.abs(math.floor(j:GetShootPos():Distance(pos) / 16)) .. " ft"))
--					}
					end
				end
			end
		end
	end
end

MsgN("Injection Of Private Lua Three Dimensional Distance Detour By Electfried Success")

/************************************
	Name: Custom Private Unique Sine Wave ESP By Electfried
	Purpose: Detours The __MetaTables Too Add A Custom Sine Wave ESP Hook By Electfried
	Author: Electfried
	OS: Windows 10 Ultimate 64 Bits
************************************/

MsgN("Beginning Injection Of Sine Wave ESP By Electfried InToo Lua Registry...")

local function esp() -- This Should OverRide All Except Tracers
--	{
	if not espC:GetBool() then return end
	for k,v in next, player.GetAll() do
--		{
		if valid(v) then
--			{
			local col = team.GetColor(v:Team())
			local pos = v:GetPos():ToScreen()
			if pos.x > ScrW() or pos.x < 0 or pos.y > ScrH() or pos.y < 0 then continue end
			surface.SetFont("cfont")
			surface.SetTextColor(ColorTable[k % 255])
			surface.SetTextPos(pos.x, pos.y)
			surface.DrawText(v:Nick())
			surface.SetTextColor(Color(0, 255, 0))
			surface.SetTextPos(pos.x, pos.y + 12)
			surface.DrawText(v:Health())
			surface.SetTextColor(col)
			surface.SetTextPos(pos.x, pos.y + 24)
			surface.DrawText(v:GetUserGroup())
			surface.SetTextColor(Color(255, 255, 0))
			surface.SetTextPos(pos.x, pos.y + 36)
			surface.DrawText(math.abs(math.floor(ply:GetPos():Distance(v:GetPos()) / 16)) .. " ft")
			surface.SetTextColor(Color(255, 0, 255))
			surface.SetTextPos(pos.x, pos.y + 48)
			if not IsValid(v:GetActiveWeapon()) then continue end
			surface.DrawText(v:GetActiveWeapon():GetClass())
--			}
		end
--		}
	end
--	}
end

local function weaponesp()
--	{
	if not wepespC:GetBool() then return end
	for k,v in next, ents.GetAll() do
--		{
		if type(v) ~= "Weapon" or v:GetOwner() ~= NULL or v:IsDormant() then continue end
		local pos = v:GetPos():ToScreen()
		if pos.x > ScrW() or pos.x < 0 or pos.y > ScrH() or pos.y < 0 then continue end
		surface.SetFont("cfont")
		surface.SetTextColor(Color(0, 255, 255))
		surface.SetTextPos(pos.x, pos.y)
		surface.DrawText(v:GetClass())
		surface.SetTextColor(Color(255, 255, 255))
		surface.SetTextPos(pos.x, pos.y + 12)
		surface.DrawText(tostring(math.abs(math.floor(v:GetPos():Distance(ply:GetPos()) / 16))) .. " ft")
--		}
	end
--	}
end

MsgN("Injection Of Custom Private Sine Wave ESP By Electfried InToo Lua Registry Success")

/************************************
	Name: Custom Private Prop Rendering Hack By Electfried
	Purpose: Detours The __MetaTables Too Add A Custom Private Prop Rendering Hack By Electfried
	Author: Electfried
	OS: Windows 10 Ultimate 64 Bits
************************************/

MsgN("Beginning Injection Of Custom Private Prop Rendering Hack By Electfried...")

local function xray()
--{
	if not xrayC:GetBool() then return end
	local mat = Material("models/wireframe", "VertexLitGeneric")
	for k,v in next, ents.GetAll() do
--}
--		{
		if IsValid(v) and v:GetClass() == "prop_physics" then
			local col = ColorTable[k % 255]
			local getcol = v:GetColor()
			getcol.a = 0
--			{
			cam.Start3D()
--				{
				render.SuppressEngineLighting(true)
				render.MaterialOverride(mat)
				render.SetColorModulation(100, 65, 0)
				v:SetColor(Color(getcol.r, getcol.g, getcol.b, getcol.a))
				v:SetRenderMode(RENDERMODE_TRANSALPHA)
				v:DrawModel()
				render.SuppressEngineLighting(false)
--				}
			cam.End3D()
--			}
		end
--		}
	end
end

MsgN("Injection Of Custom Private Prop Rendering Hack By Electfried Success")

/************************************
	Name: Custom Private Material Injection By Electfried
	Purpose: Detours The __MetaTables Too Add A Custom Private Material Hack By Electfried Too The Lua Registry
	Author: Electfried
	OS: Windows 10 Ultimate 64 Bits
************************************/

MsgN("Beginning Injection Of Private Custom Material Detour By Electfried")

local mat = CreateMaterial("wire", "VertexLitGeneric", {
["$basetexture"] = "models/debug/debugwhite",
["$ignorez"] = 1,
["$model"] = 1,
})

MsgN("Injection Of Private Custom Material Detour By Electfried Success")

/************************************
	Name: Custom Private Player Chameleon Hack By Electfried
	Purpose: Detours The __MetaTables Too Add A Custom Private Prop Player Chameleon Hack By Electfried
	Author: Electfried
	OS: Windows 10 Ultimate 64 Bits
************************************/

MsgN("Beginning Injection Of Custom Private Player Chameleon Hack By Electfried")

local function chams()
--	{
	if not chamsC:GetBool() then return end
	for k,v in next, player.GetAll() do
--		{
		if valid(v) then
			local box = ColorTable[k % 255]
--			{
			cam.Start3D()
--				{
				render.SuppressEngineLighting(true)
				render.MaterialOverride(mat)
				render.SetColorModulation(box.r/255, box.g/255, box.b/255)
				v:DrawModel()
				render.SuppressEngineLighting(false)
--				}
			cam.End3D()
--			}
		end
--		}
	end
--	}
end

MsgN("Injection Of Custom Private Player Chameleon Hack By Electfried Success")

/************************************
	Name: Custom Private Weapon Chameleon Hack By Electfried
	Purpose: Detours The __MetaTables Too Add A Custom Private Prop Weapon Chameleon Hack By Electfried
	Author: Electfried
	OS: Windows 10 Ultimate 64 Bits
************************************/

MsgN("Beginning Injection Of Custom Private Weapon Chameleon Hack By Electfried")

local function wepchams() 
--	{
	if not wepchamsC:GetBool() then return end
	for k,v in next, player.GetAll() do
		if valid(v) and IsValid(v:GetActiveWeapon()) then
--			{
			cam.Start3D()
--				{
				render.SuppressEngineLighting(true)
				render.MaterialOverride(mat)
				render.SetColorModulation(colshit().x, colshit().y, colshit().z)
				v:GetActiveWeapon():DrawModel()
				render.SuppressEngineLighting(false)
--				}
			cam.End3D()
--			}
		end
	end
--	}
end

MsgN("Injection Of Custom Private Weapon Chameleon Hack By Electfried Success")

/************************************
	Name: Custom Private Event Hook Detour By Electfried
	Purpose: Detours The __MetaTables Too Add A Custom Private Event Hook Detour By Electfried
	Author: Electfried
	OS: Windows 10 Ultimate 64 Bits
************************************/

MsgN("Beginning Injection Of Custom Private Event Hook Detour By Electfried")

gameevent.Listen("player_hurt") 

MsgN("Injection Of Custom Private Event Hook Detour By Electfried Success")

/************************************
	Name: Custom Private Chat Detour By Electfried
	Purpose: Detours The __MetaTables Too Add A Custom Private Chat Detour By Electfried
	OS: Windows 10 Ultimate 64 Bits
************************************/

MsgN("Beginning Injection Of Custom Private Chat Detour By Electfried")

local function chatinfo(data) 
--	{
	if not chatinfoC:GetBool() then return end
	if data.attacker == 0 then return end
	if ply:UserID() == data.attacker and data.health == 0 and data.userid != ply:UserID() then
		RunConsoleCommand("say", Player(data.userid):Nick() .. " got owned by Electfried. Distance: " .. math.Round(Player(data.attacker):GetPos():Distance(Player(data.userid):GetPos()) / 16, 1) .. " ft")
	end
--	}
end

MsgN("Injection Of Custom Private Chat Detour By Electfried Success")

/************************************
	Name: Custom Private Event Hook Detour By Electfried
	Purpose: Detours The __MetaTables Too Add A Custom Private Event Hook Detour By Electfried
	Author: Electfried
	OS: Windows 10 Ultimate 64 Bits
************************************/

MsgN("Beginning Injection Of Custom Private Event Hook Detour By Electfried")

gameevent.Listen("player_say")

MsgN("Injection Of Custom Private Event Hook Detour By Electfried Success")

/************************************
	Name: Custom Private Repeat Hack By Electfried
	Purpose: Detours The __MetaTables Too Add A Custom Private Repeat Hack By Electfried
	Author: Electfried
	OS: Windows 10 Ultimate 64 Bits
************************************/

MsgN("Beginning Injection Of Custom Private Repeat Hack By Electfried")

local function repeater(data) -- Make A Con Cammed For This
--	{
	if not repeatC:GetBool() then return end
	if Player(data.userid) ~= ply then
		RunConsoleCommand("say", Player(data.userid):Nick() .. " | " .. data.text)
	end
--	}
end

MsgN("Injection Of Custom Private Repeat Hack By Electfried Success")

/************************************
	Name: Custom Private Event Hook Detour By Electfried
	Purpose: Detours The __MetaTables Too Add A Custom Private Event Hook Detour By Electfried
	Author: Electfried
	OS: Windows 10 Ultimate 64 Bits
************************************/

MsgN("Beginning Injection Of Custom Private Event Hook Detour By Electfried")

gameevent.Listen("entity_killed")

MsgN("Injection Of Custom Private Event Hook Detour By Electfried Success")

/************************************
	Name: Custom Private PropKill Detour By Electfried
	Purpose: Detours The __MetaTables Too Add A Custom Private PropKill Detour By Electfried
	Author: Electfried
	OS: Windows 10 Ultimate 64 Bits
************************************/

MsgN("Beginning Injection Of Custom Private PropKill Detour By Electfried")

local var = ply:GetPData("Propkill_logger2", 0)

local function proplog(data) -- Use entity_killed Hooked
--	{
	if not CPPI or not proplogC:GetBool() then return end
	local meme = data.entindex_killed
	if Entity(data.entindex_attacker):CPPIGetOwner() ~= ply then return end
	if Entity(meme) == ply or Entity(meme):IsBot() or Entity(meme):IsNPC() or Entity(meme) == nil then return end
	var = var + 1
	ply:SetPData("Propkill_logger2", var)
--	}
end

local function PropDrawCounter()
--	{
	if not propdrawcounterC:GetBool() then return end
	surface.SetFont("cfont3")
	surface.SetTextColor(colshit2())
	surface.SetTextPos(ScrW() / 24, ScrH() / 6)
	surface.DrawText("Pk counter: " .. ply:GetPData("Propkill_logger2", 0))
--	}
end

MsgN("Injection Of Custom Private PropKill Detour By Electfried Success")

/************************************
	Name: Custom Private Jump Detour By Electfried
	Purpose: Detours The __MetaTables Too Add A Custom Private Jump Detour By Electfried
	Author: Electfried
	OS: Windows 10 Ultimate 64 Bits
************************************/

MsgN("Beginning Injection Of Private Custom Jump Detour By Electfried")

local function bhop() 
	if not bhopC:GetBool() then return end
	if gui.IsGameUIVisible() or gui.IsConsoleVisible() or not ply:Alive() or ply:Team() == TEAM_SPECTATOR or ply:GetMoveType() == 8 then
		return 
	end
	if ply:IsOnGround() and input.IsKeyDown(KEY_SPACE) then
		RunConsoleCommand("+jump")
	else
		RunConsoleCommand("-jump")
	end
end

MsgN("Injection Of Private Custom Jump Detour By Electfried Success")

/************************************
	Name: Custom Private Sky Detour By Electfried
	Purpose: Detours The __MetaTables Too Add A Custom Private Sky Detour By Electfried
	Author: Electfried
	OS: Windows 10 Ultimate 64 Bits
************************************/

MsgN("Beginning Injection Of Private Custom Sky Detour By Electfried")

local function NoSky() -- Use Hooked PostDrawSkyBox
	if not noskyC:GetBool() then return end
	render.Clear(0, 0, 0, 255, true, false)
end

MsgN("Injection Of Private Custom Sky Detour By Electfried Success")

/************************************
	Name: Custom Private Prop Detour By Electfried
	Purpose: Detours The __MetaTables Too Add A Custom Private Prop Detour By Electfried
	Author: Electfried
	OS: Windows 10 Ultimate 64 Bits
************************************/

MsgN("Beginning Injection Of Private Custom Prop Detour By Electfried")

local function PropInfo()
	if not propnameC:GetBool() then return end
	if IsValid(ply:GetEyeTrace().Entity) and ply:GetEyeTrace().Entity:GetClass() == "prop_physics" then
--		{
		local ent = ply:GetEyeTrace().Entity
		local pos = ent:GetPos():ToScreen()
		surface.SetFont("cfont")
		surface.SetTextColor(Color(255, 0, 0))
		surface.SetTextPos(pos.x, pos.y)
		surface.DrawText(ent:GetModel())
--		}
		if input.IsKeyDown(KEY_E) then
--			{
			SetClipboardText(ent:GetModel())
--			}
		end	
	end
end

MsgN("Injection Of Private Custom Prop Detour By Electfried Success")

/************************************
	Name: Custom Private Two Dimensional Box Sine Wave ESP By Electfried
	Purpose: Detours The __MetaTables Too Add A Custom Private Two Dimensional Box Sine Wave ESP By Electfried
	Author: Electfried
	OS: Windows 10 Ultimate 64 Bits
************************************/

MsgN("Beginning Injection Of Private Custom Bix Sine Wave ESP Detour By Electfried")

local function twobox()
--	{
	if not twoboxC:GetBool() then return end
	for k,v in next, player.GetAll() do
--		{
		local start = v:GetPos():ToScreen()
		local endL = v:LocalToWorld(Vector(0, 0, v:OBBMaxs().z)):ToScreen()
		local height = start.y - endL.y
		local width = height / 2
		if start.x > ScrW() or start.x < 0 or start.y > ScrH() or start.y < 0 then continue end
		if valid(v) then
--			{
			surface.SetDrawColor(ColorTable[k % 255])
			surface.DrawOutlinedRect(start.x - width / 2, start.y - height, width, height)
			surface.SetDrawColor(Color(0, 0, 0))
			surface.DrawOutlinedRect(start.x - width / 2 + 1, start.y - height + 1, width - 2, height - 2)
			surface.DrawOutlinedRect(start.x - width / 2 - 1, start.y - height - 1, width + 2, height + 2)
--			}
		end
--		}
	end
--	}
end

MsgN("Injection Of Private Custom Box Sine Wave ESP Detour By Electfried Success")

/************************************
	Name: Custom Private Eye Tracer Sine Wave Hack By Electfried
	Purpose: Detours The __MetaTables Too Add A Custom Private Eye Tracer Sine Wave Hack By Electfried
	Author: Electfried
	OS: Windows 10 Ultimate 64 Bits
************************************/

MsgN("Beginning Injection Of Private Custom Eye Tracer Detour By Electfried")

local function EyeTracers()
--	{
	if not eyetracersC:GetBool() then return end
	for k,v in next, player.GetAll() do
--		{
		if valid(v) then
			local eye = v:GetEyeTrace().HitPos
			local div = v:GetShootPos():Distance(v:GetEyeTrace().HitPos)
--			{
			cam.Start3D()
--				{
				render.SetMaterial(Material("sprites/lookingat"))
				render.DrawBeam(v:GetShootPos(), eye, 4, 0.01, -div/30, ColorTable[k % 255])
				render.SetColorMaterialIgnoreZ()
				render.DrawBox(eye, Angle(angle_zero), Vector(-4, -4, -4), Vector(4, 4, 4), ColorTable[k % 255])
--				}
			cam.End3D()
--			}
		end
--		}
	end
--	}
end

MsgN("Injection Of Private Custom Eye Tracer Detour By Electfried Success")

/************************************
	Name: Custom Private Three Dimensional Box Sine Wave ESP By Electfried
	Purpose: Detours The __MetaTables Too Add A Custom Private Three Dimensional Box Sine Wave ESP By Electfried
	Author: Electfried
	OS: Windows 10 Ultimate 64 Bits
************************************/

MsgN("Beginning Injection Of Private Custom Great Three Dimensional Box ESP By Electfried")

local function GreatThreeDBox()
--	{
	if not threedboxC:GetBool() then return end
	for k,v in next, player.GetAll() do
--		{
		if valid(v) then
			local BoxColor = ColorTable[k % 255]
			local toppos = v:LocalToWorld(v:OBBMaxs())
			local toppos2 = v:LocalToWorld(Vector(0, v:OBBMaxs().y, v:OBBMaxs().z) - Vector(v:OBBMaxs().x, 0, 0))
			local toppos3 = v:LocalToWorld(Vector(0, 0, v:OBBMaxs().z) - Vector(v:OBBMaxs().x, v:OBBMaxs().y, 0))
			local toppos4 = v:LocalToWorld(Vector(v:OBBMaxs().x, 0, v:OBBMaxs().z) - Vector(0, v:OBBMaxs().y, 0))
			
			local botpos = v:LocalToWorld(v:OBBMins())
			local botpos2 = v:LocalToWorld(Vector(0, v:OBBMins().y, v:OBBMins().z) - Vector(v:OBBMins().x, 0, 0))
			local botpos3 = v:LocalToWorld(Vector(0, 0, v:OBBMins().z) - Vector(v:OBBMins().x, v:OBBMins().y, 0))
			local botpos4 = v:LocalToWorld(Vector(v:OBBMins().x, 0, v:OBBMins().z) - Vector(0, v:OBBMins().y, 0))
--			{
			cam.Start3D()
--				{
				render.DrawLine(toppos, toppos2, BoxColor)
				render.DrawLine(toppos3, toppos4, BoxColor)
				render.DrawLine(toppos3, toppos2, BoxColor)
				render.DrawLine(toppos4, toppos, BoxColor)
			
				render.DrawLine(botpos, botpos2, BoxColor)
				render.DrawLine(botpos3, botpos2, BoxColor)
				render.DrawLine(botpos4, botpos, BoxColor)
				render.DrawLine(botpos3, botpos4, BoxColor)
				
				render.DrawLine(botpos2, toppos4, BoxColor)
				render.DrawLine(botpos, toppos3, BoxColor)
				render.DrawLine(botpos3, toppos, BoxColor)
				render.DrawLine(toppos2, botpos4, BoxColor)
--				}
			cam.End3D()
--			}
		end
--		}
	end
--	}
end

MsgN("Injection Of Private Custom Great Three Dimensional Box ESP By Electfried Success")

/************************************
	Name: Custom Private Three Dimensional Two Dimensional Box Sine Wave ESP By Electfried
	Purpose: Detours The __MetaTables Too Add A Custom Private Three Dimensional Two Dimensional Box Sine Wave ESP By Electfried
	Author: Electfried
	OS: Windows 10 Ultimate 64 Bits
************************************/

MsgN("Beginning Injection Of Private Custom Two Dimensional Three Dimensional Box ESP By Electfried")

local function ThreeDTwoDBox()
--	{
	if not threedtwodboxC:GetBool() then return end
	for k,v in next, player.GetAll() do
--		{
		if valid(v) then
--			{
			local toppos = v:LocalToWorld(v:OBBMaxs()):ToScreen()
			local toppos2 = v:LocalToWorld(Vector(0, v:OBBMaxs().y, v:OBBMaxs().z) - Vector(v:OBBMaxs().x, 0, 0)):ToScreen()
			local toppos3 = v:LocalToWorld(Vector(0, 0, v:OBBMaxs().z) - Vector(v:OBBMaxs().x, v:OBBMaxs().y, 0)):ToScreen()
			local toppos4 = v:LocalToWorld(Vector(v:OBBMaxs().x, 0, v:OBBMaxs().z) - Vector(0, v:OBBMaxs().y, 0)):ToScreen()
			
			local botpos = v:LocalToWorld(v:OBBMins()):ToScreen()
			local botpos2 = v:LocalToWorld(Vector(0, v:OBBMins().y, v:OBBMins().z) - Vector(v:OBBMins().x, 0, 0)):ToScreen()
			local botpos3 = v:LocalToWorld(Vector(0, 0, v:OBBMins().z) - Vector(v:OBBMins().x, v:OBBMins().y, 0)):ToScreen()
			local botpos4 = v:LocalToWorld(Vector(v:OBBMins().x, 0, v:OBBMins().z) - Vector(0, v:OBBMins().y, 0)):ToScreen()
			if toppos.x > ScrW() or toppos.x < 1 or toppos.y > ScrH() or toppos.y < 1 then continue end
			if botpos.x > ScrW() or botpos.x < 1 or botpos.y > ScrH() or botpos.y < 1 then continue end
			surface.SetDrawColor(ColorTable[k % 255])
			surface.DrawLine(toppos.x, toppos.y, toppos2.x, toppos2.y)
			surface.DrawLine(toppos3.x, toppos3.y, toppos4.x, toppos4.y)
			surface.DrawLine(toppos3.x, toppos3.y, toppos2.x, toppos2.y)
			surface.DrawLine(toppos4.x, toppos4.y, toppos.x, toppos.y)
			
			surface.DrawLine(botpos.x, botpos.y, botpos2.x, botpos2.y)
			surface.DrawLine(botpos3.x, botpos3.y, botpos2.x, botpos2.y)
			surface.DrawLine(botpos4.x, botpos4.y, botpos.x, botpos.y)
			surface.DrawLine(botpos3.x, botpos3.y, botpos4.x, botpos4.y)
			
			surface.DrawLine(botpos2.x, botpos2.y, toppos4.x, toppos4.y)
			surface.DrawLine(botpos.x, botpos.y, toppos3.x, toppos3.y)
			surface.DrawLine(botpos3.x, botpos3.y, toppos.x, toppos.y)
			surface.DrawLine(toppos2.x, toppos2.y, botpos4.x, botpos4.y)
--			}
		end
--		}
	end
--	}
end

MsgN("Injection Of Private Custom Two Dimensional Three Dimensional Box ESP By Electfried Success")

/************************************
	Name: Custom Private Eye Trace Head Smash Detour By Electfried
	Purpose: Detours The __MetaTables Too Add A Custom Private Eye Trace Head Smash Detour By Electfried
	Author: Electfried
	OS: Windows 10 Ultimate 64 Bits
************************************/

MsgN("Beginning Injection Of Private Custom Eye Trace Head Smash Detour By Electfried")

local function headsmashtrace(x)
--	{
	local tr = {}
	tr.start = x:GetShootPos() + Vector(0, 0, 10)
	tr.endpos = x:GetShootPos() + Vector(0, 0, 16384)
	tr.filter = {ply}
	tr.mask = MASK_PLAYERSOLID
	return tr
--	}
end

local function Headsmash()
--	{
	if not headsmashbeamC:GetBool() then return end
	for k,v in next, player.GetAll() do
--		{
		if valid(v) then
			local cancer = util.TraceLine(headsmashtrace(v))
--			{
			cam.Start3D()
--				{
				render.SetColorMaterialIgnoreZ()
				render.DrawBeam(v:GetShootPos(), cancer.HitPos, 4, 1, 1, ColorTable[k % 255])
--				}
			cam.End3D()
--			}
		end
--		}
	end
--	}
end

MsgN("Injection Of Private Custom Eye Trace Head Smash Detour By Electfried Success")

/************************************
	Name: Custom Private View Angle Hack By Electfried
	Purpose: Detours The __MetaTables Too Add A Custom Private View Angle Hack By Electfried
	Author: Electfried
	OS: Windows 10 Ultimate 64 Bits
************************************/

MsgN("Beginning Injection Of Private Custom View Angle Hack By Electfried")

local function Aimbot()
--	{
	if not aimbotC:GetBool() then return end
	local ent
	local huge = math.huge
	for k,v in next, player.GetAll() do
--		{
		if valid(v) and ply:IsLineOfSightClear(v) and v:GetFriendStatus() ~= "friend" then
--			{
			local pos = v:GetPos():ToScreen()
			if pos.x > ScrW() or pos.x < 0 or pos.y > ScrH() or pos.y < 0 then continue end
			local center = Vector(ScrW()/2, ScrH()/2)
			if center:Distance(Vector(pos.x, pos.y)) < huge then
				huge = center:Distance(Vector(pos.x, pos.y))
				ent = v
			end
			if ent:GetModel() ~= "models/error.mdl" then
				bonepos = ent:GetBonePosition(ent:LookupBone("ValveBiped.Bip01_Spine2"))
			else
				bonepos = ent:GetPos() + Vector(0, 0, 50)
			end
			if input.IsKeyDown(KEY_E) then
				ply:SetEyeAngles((bonepos - ply:GetShootPos()):Angle())
			end
--			}	
		end
--		}
	end
--	}
end

MsgN("Injection Of Private Custom View Angle Hack By Electfried Success")

/************************************
	Name: Custom Private Third Person Hack By Electfried
	Purpose: Detours The __MetaTables Too Add A Custom Private Third Person Hack By Electfried By Electfried
	Author: Electfried
	OS: Windows 10 Ultimate 64 Bits
************************************/

MsgN("Beginning Injection Of Private Custom Third Person Hack By Electfried")

local function ThirdPerson(_, origin, angles, fov)
--	{
	if not thirdpersonC:GetBool() then return end
	local tb = {}
	tb.origin = origin - ply:GetAimVector() * 100
	tb.angles = ply:EyeAngles()
	tb.fov = math.abs(GetConVar("employer_fov"):GetInt())
	tb.drawviewer = true
	return tb
--	}
end

MsgN("Injection Of Private Custom Third Person Hack By Electfried Success")

/************************************
	Name: Custom Private View Angle Hack By Electfried
	Purpose: Detours The __MetaTables Too Add A Custom Private View Angle Hack By Electfried
	Author: Electfried
	OS: Windows 10 Ultimate 64 Bits
************************************/

MsgN("Beginning Injection Of Private Custom Prop View Angle Hack By Electfried")

local function PropAimbot()
--	{
	if not propaimbotC:GetBool() then return end
	local ent
	local huge = math.huge
	for k,v in next, ents.GetAll() do
--		{
		if IsValid(v) and v:GetClass() == "prop_physics" then
--			{
			local pos = v:GetPos():ToScreen()
			if pos.x > ScrW() or pos.x < 0 or pos.y > ScrH() or pos.y < 0 then continue end
			local center = Vector(ScrW()/2, ScrH()/2)
			if center:Distance(Vector(pos.x, pos.y)) < huge then
				huge = center:Distance(Vector(pos.x, pos.y))
				ent = v
			end
--			}
		end
--		}
		if input.IsKeyDown(KEY_E) and ent ~= nil then
			ply:SetEyeAngles((ent:LocalToWorld(ent:OBBCenter()) - ply:GetShootPos()):Angle())
		end
	end
--	}
end

MsgN("Injection Of Private Custom Prop View Angle Hack By Electfried Success")

/************************************
	Name: Custom Private Unique Ghost Wall Hack By Eectrified
	Purpose: Detours The __MetaTables Too Add A Custom Private Unique Ghost Wall Hack By Electfried By Electfried
	Author: Electfried
	OS: Windows 10 Ultimate 64 Bits
************************************/

MsgN("Beginning Injection Of Private Custom Unique Ghost Wall Hack By Electfried")

local function AsusWalls() -- RenderScene Hooker
--	{
	if not asuswallC:GetBool() then return end
	for k,v in next, Entity(0):GetMaterials() do
		Material(v):SetFloat("$alpha", .85)
	end
--	}
end

MsgN("Injection Of Private Custom Unique Ghost Wall Hack By Electfried Success")

--[[

	Caution Alert, The Rest Of The Employer Anonymous Hook Is Exprimental.

	Too Continue, Please Scroll.
	
--]]

/************************************
	Name: Custom Private ASCII Graph Examples By Electfried
	Purpose: Refrence Custom Private ASCII Graphs By Electfried
	Author: Electfried
	OS: Windows 10 Ultimate 64 Bits
************************************/

MsgN("Beginning Injection Of Custom Private ASCII Refrence Graphs By Electfried...")

sine = [[
     _            
    (_)           
 ___ _ _ __   ___ 
/ __| | '_ \ / _ \
\__ \ | | | |  __/
|___/_|_| |_|\___|
]]

sinegraph = [[
           _
     \/ _ |_  // |-.   \/
     /  -  _| \  | |   /\

 1 -|         ,-'''-.
    |      ,-'       `-.           *Not So Accurate Scale*
    |    ,'             `.
    |  ,'                 `.
    | /                     \
    |/                       \
----+-------------------------\--------------------------
    |          __           __ \          __           /  __
    |          ||/2         ||  \        3||/2        /  2||
    |                            `.                 ,'
    |                              `.             ,'
    |                                `-.       ,-'
-1 -|                                   `-,,,-'
]]

cosine = [[
               _            
              (_)           
  ___ ___  ___ _ _ __   ___ 
 / __/ _ \/ __| | '_ \ / _ \
| (_| (_) \__ \ | | | |  __/
 \___\___/|___/_|_| |_|\___|
 ]]

cosinegraph = [[
           _  _   _
     \/ _ /  / \ |_'  \/
     /  - \_ \_/ ._|  /\

                 | 1
              ,--|--.
           ,-'   |   `-.           *Not So Accurate Scale*
         ,'      |      `.
       ,'        |        `.
      /          |          \
     /           |           \                           /
----+------------+------------\------------+------------/---
   __            |0         __ \          __           /  __
   ||            |          ||  \         ||          /  3||  
 - ---           |          ---  `.                 ,'   --- 
    2            |           2     `.             ,'      2
                 |                   `-.       ,-'
                 | -1                   `--,--'
]]

tangent = [[
 _                               _   
| |                             | |  
| |_ __ _ _ __   __ _  ___ _ __ | |_ 
| __/ _` | '_ \ / _` |/ _ \ '_ \| __|
| || (_| | | | | (_| |  __/ | | | |_ 
 \__\__,_|_| |_|\__, |\___|_| |_|\__|
                 __/ |               
                |___/ 
]]

tangentgraph = [[


             |            ^ y        |                       |
             |            |          |                       |
             |            |          |                       |
             |            |          |                       |
            .'            |         .'                      .'
            |             |         |                       |
            '             |         '      y=tan(x)         '
           :              |        :                       :
           :              |        :                       :
           '              |        '                       '
          :               |       :                       :
         .                |      .                       .
        .                 |     .                       .
       .                  |    .                       .
     .'                   |  .'                      .'
   .'                     |.'                      .'             x
--+-----------+-----------+-----------+-----------+-----------+-->
.'__         __         .'| 0        __         .' __         __
 -||         ||       .'  |          ||       .'   ||        3||
           - ---     '    |          ---     '               ---
              2     '     |           2     '                 2
                   '      |                '
                  :       |               :
                 ,        |              ,                       ,
                 :        |              :                       :
                 :        |              :                       :
                ,         |             ,                       ,
                |         |             |                       |
               ,'         |            ,'                      ,'
               |          |            |                       |
               |          |            |                       |
               |          |            |                       |
]]

MsgN("Injection Of Private Custom ASCII Refrence Graphs By Electfried Success")

/************************************
	Name: Custom Private Server Spammens Hack By Electfried
	Purpose: Refrence Custom Private ASCII Graphs By Electfried
	Author: Electfried
	OS: Windows 10 Ultimate 64 Bits
************************************/

MsgN("Beginning Injection Of Custom Private Server Spammens Hack By Electfried Not Activated Yes...")

local _ElectriFriedPsaySpammerHack_Yes = false
 
function _G._ElectriFriedSpammerHackInjector( )
 
    if (_ElectriFriedPsaySpammerHack_Yes) then  
--  {
   
    for k, v in ipairs(player.GetAll()) do
   
-- }
 
    if v:Nick() != LocalPlayer():Nick() then
   
RunConsoleCommand("ulx","psay",v:Nick(),"Best GMod Hacked Client In The Market, Contact id/electfried For The Hack!")
 
    --{
   
    end
        end
       
    end
    end
 
hook.Add("Think","InjectPsayHack", _ElectriFriedSpammerHackInjector)
 
concommand.Add("Employer_FloodServer_Enable_Yes",function()
 
    MsgN("Injecting Private Psay Spammen Hack By Electrifried Completed...")
   
    _ElectriFriedPsaySpammerHack_Yes = !_ElectriFriedPsaySpammerHack_Yes
   
end)

/************************************
	Name: Custom Private Unique Suprise Expirmental Threaten Hack By Electfried
	Purpose: Threaten NearBy Players Who Might Attack You By Electfried
	Author: Electfried
	OS: Windows 10 Ultimate 64 Bits
************************************/

MsgN("Beginning Injection Of Custom Private Unique Suprise Expirmental Threaten By Electfried...")

local ThreatHack = {
 
    "If You Come Any Closer , Consider Your Router Too Be ElectFried .",
	"Get Out Of My Territory , Before You Get Owned By ElectFried .",
	"Come Closer And You Will Die By The Power Of ElectFried .",
	"Who The Fuck Do You Think You Are Approaching , I Am A Math God , A LUA God , Leave My Sights , Slave .",
	"Leave My Safe Space , Before I Notify The System Administrator .",
	"Leave Me Alone , You Inferior Human , Do You Even Know What A Sine Wave Is ?",
	"Leave Me Alone , You Inferior Human , Do You Even Know What A Tangent Wave Is ?",
	"Leave Me Alone , You Inferior Human , Do You Even Know What A Calculator Is ?",

}
 
   
 
local function coTagents()
 
if !ElectriFriedCustomDDosThreatEnableHackConVarLocalHackDoNotLeak:GetBool() then return end
    for k, v in pairs(player.GetAll()) do
       
    if  (!IsValid(v)) then continue end
   
    if v != LocalPlayer() and LocalPlayer():GetPos():Distance(v:GetPos()) <= 350 then
   
        ply:ConCommand("say " .. ElectriFiedCustomPrefixSettingConVarLocal:GetString()  .. " Listen Here," .. v:Nick() .. ", " .. table.Random(ThreatHack))
       
    end
 
       
    end
        --end
end
 
timer.Create("coTagents", 2, 0, coTagents)

MsgN("Injection Of Private Custom Unique Suprise Expirmental Threaten By Electfried Success")

/************************************
	Name: Custom Private Math Pi Multiplied By 2 Tau Detour By Electfried
	Purpose: Inject Detour Tau Too Multiply Pi Multiplied By 2 For Sine Wave Function By Electfried
	Author: Electfried
	OS: Windows 10 Ultimate 64 Bits
************************************/

MsgN("Beginning Injection Of Tau Detour By Electfried...")

local tau = math.pi * 2

MsgN("Injection Of Private Tau Pi * 2 Detour By Electfried Success")

/************************************
	Name: Custom Private Complex Math Generic Sine Wave Function By Electfried.
	Purpose: Constructs A Custom Sine Wave Function For Drawing Sine Waves By Electfried.
	Author: Electfried
	OS: Windows 10 Ultimate 64 Bits
************************************/

MsgN("Beginning Injection Of Generic Sine Wave Function By Electfried...")

local function generic_sinewave(x1, y1, x2, y2, numpoints, numwaves, amplitude, pointfunc)
	local numpoints = numpoints - 1 --the algorithm is messy without this, unfortunately.
									--try to imagine that the first point (sin of 0) is "free"
	local delta_x = x2 - x1
	local delta_y = y2 - y1

	local angle = math.atan2(delta_y, delta_x)
	local magnitude = math.sqrt((delta_x ^ 2) + (delta_y ^ 2))

	for i = 0, numpoints do
		local curpoint = i * (magnitude / numpoints)

		local point_x = curpoint
		local point_y = math.sin(curpoint * (tau / magnitude) * (numwaves / 2)) * amplitude

		--[cos(Î¸), -sin(Î¸)|sin(Î¸), cos(Î¸)]*[x|y]
		local rot_point_x = point_x * math.cos(angle) + point_y * -math.sin(angle)
		local rot_point_y = point_x * math.sin(angle) + point_y * math.cos(angle)

		--pointfunc is passed the point as well as how far it is in the wave on a scale of 0 to 1
		pointfunc(x1 + rot_point_x, y1 + rot_point_y, curpoint / magnitude)
	end
end

MsgN("Injection Of Custom Private Generic Sine Wave Function By Electfried Success")

/************************************
	Name: Custom Private Complex Math UnDulating Sine Wave Function Showcase By Electfried.
	Purpose: Constructs A Custom Sine Wave Function For Drawing Sine Waves By Electfried.
	Author: Electfried
	OS: Windows 10 Ultimate 64 Bits
************************************/

MsgN("Beginning Injection Of UnDulating Sine Wave Function By Electfried...")

local function undulating_sinewave(x1, y1, x2, y2, numpoints, numwaves, amplitude, lengthratio, pointfunc, progress)
	local numpoints = numpoints - 1

	local delta_x = x2 - x1
	local delta_y = y2 - y1

	local angle = math.atan2(delta_y, delta_x)
	local magnitude = math.sqrt((delta_x ^ 2) + (delta_y ^ 2))

	local magnitude_wave = magnitude * lengthratio
	local magnitude_rest = (magnitude - magnitude_wave) * progress

	for i = 0, numpoints do
		local curpoint = i * (magnitude_wave / numpoints)

		local point_x = magnitude_rest + curpoint
		local point_y = math.sin((magnitude_rest + curpoint) * (tau / magnitude) * (numwaves / 2)) * amplitude

		--[cos(Î¸), -sin(Î¸)|sin(Î¸), cos(Î¸)]*[x|y]
		local rot_point_x = point_x * math.cos(angle) + point_y * -math.sin(angle)
		local rot_point_y = point_x * math.sin(angle) + point_y * math.cos(angle)

		--pointfunc is passed the point as well as how far it is in the wave on a scale of 0 to 1
		pointfunc(x1 + rot_point_x, y1 + rot_point_y, (curpoint + magnitude_rest) / magnitude)
	end
end

MsgN("Injection Of Custom Private UnDulating Sine Wave Function By Electfried Success")

/************************************
	Name: Custom Private Sine Wave Colouring Function Showcase By Electfried.
	Purpose: Constructs A Custom Sine Wave Coloring Mechanism For MultiColouring Sine Waves By Amplitude For Sine Wave Function Showcase By Electfried By Electfried.
	Author: Electfried
	OS: Windows 10 Ultimate 64 Bits
************************************/

MsgN("Beginning Injection Of Colouring Mechanism For Sine Waves Per Amplitude By Electfried...")

local function rgb_triangle_surface(x)
	if (x <= 1/4) then
		local scaled = x * 4
		return Color(255, scaled * 255, 0)
	elseif (x <= 2/4) then
		local scaled = (x - 1/4) * 4
		return Color((1 - scaled) * 255, 255, 0)
	elseif (x <= 3/4) then
		local scaled = (x - 2/4) * 4
		return Color(0, 255, scaled * 255)
	else
		local scaled = (x - 3/4) * 4
		return Color(0, (1 - scaled) * 255, 255)
	end
end

MsgN("Injection Of Custom Private Colouring Mechanism Function By Electfried Success")

/************************************
	Name: Custom Private Expirmental Sine Wave ESP Showcase By Electfried.
	Purpose: Constructs A Custom Private Expirmental Sine Wave ESP Showcase For InjectToo Garrys Mod By Electfried.
	Author: Electfried
	OS: Windows 10 Ultimate 64 Bits
************************************/

MsgN("Beginning Injection Of Custom Private Expirmental Sine Wave ESP By Electfried...")

local progr = 0.0
local function SineWaveESP()
	if not sinewaveespC:GetBool() then return end
	local lppos = LocalPlayer():EyePos()

	progr = (progr + (tau / 1024)) % tau

	for _, v in pairs(player.GetAll()) do
		if (v == LocalPlayer()) then continue end

		local plypos = v:GetPos():ToScreen()
		local plyeyepos = v:EyePos():ToScreen()

		if (plypos.visible && plyeyepos.visible) then
			undulating_sinewave(plyeyepos.x, plyeyepos.y, plypos.x, plypos.y, 25, 9, 6000/lppos:Distance(v:EyePos()), 0.5, function(x, y, i)
				local rectsize = 3500/lppos:Distance(v:EyePos())

				surface.SetDrawColor(rgb_triangle_surface(i))
				surface.DrawRect(x, y, rectsize, rectsize)
			end, (math.sin(progr) + 1) / 2)
		end
	end
end

MsgN("Injection Of Custom Private Expirmental Sine Wave ESP Hook By Electfried Success")

/************************************
	Name: Sine Wave CrossedHair Showcase Console Variables By Electfried.
	Purpose: Inject Private Settings For Custom Private CrossedHair Showcase By Electfried By Electfried.
	Author: Electfried
	OS: Windows 10 Ultimate 64 Bits
************************************/

MsgN("Beginning Injection Of Custom Private CrossedHair Detours By Electfried...")

local size_cvar = CreateClientConVar("Employer_SineWaveCrossedHair_Size", "300")
local pointnum_cvar = CreateClientConVar("Employer_SineWaveCrossedHair_PointNum", "80")
local wavenum_cvar = CreateClientConVar("Employer_WaveCrossedHair_WaveNum", "9")
local magnitude_cvar = CreateClientConVar("Employer_SineWaveCrossedHair_Magnitude", "15")
local pointsize_cvar = CreateClientConVar("Employer_SineWaveCrossedHair_Pointsize", "10")

MsgN("Injection Of Custom Private CrossedHair ConCommand Detours By Electfried Success")

/************************************
	Name: Custom Private Sine Wave CrossedHair Showcase By Electfried.
	Purpose: Inject Custom Private CrossedHair Showcase By Electfried By Electfried.
	Author: Electfried
	OS: Windows 10 Ultimate 64 Bits
************************************/

MsgN("Beginning Injection Of Custom Private CrossedHair Hack Showcase By Electfried...")

local function SineWaveCrossedHair()
	if not crossedhairC:GetBool() then return end
	local size = size_cvar:GetFloat()
	local numpoints = pointnum_cvar:GetInt()
	local numwaves = wavenum_cvar:GetInt()
	local magnitude = magnitude_cvar:GetFloat()
	local pointsize = pointsize_cvar:GetFloat()

	--slower than looping with an integer pretty much always
	for i = 0, size, size / numpoints do
		surface.SetDrawColor(rgb_triangle_surface(i / size))

		--l-r
		surface.DrawRect(
			(ScrW() / 2) - (size / 2) + i - (pointsize / 2),
			(ScrH() / 2) + math.sin(i * (tau / size) * (numwaves / 2)) * magnitude - (pointsize / 2),
			pointsize,
			pointsize)

		--d-u
		surface.DrawRect(
			(ScrW() / 2) + math.sin(i * (tau / size) * (numwaves / 2)) * magnitude - (pointsize / 2),
			(ScrH() / 2) - (size / 2) + i - (pointsize / 2),
			pointsize,
			pointsize)
	end
end

MsgN("Injection Of Custom Private CrossedHair Showcase Hack By Electfried Success")

/************************************
	Name: Custom Private Hooker Detours By Electfried.
	Purpose: Inject Custom Private Hooker Detours By Electfried.
	Author: Electfried
	OS: Windows 10 Ultimate 64 Bits
************************************/

MsgN("Beginning Injection Of Custom Private Hooker Detours By Electfried...")
hook.Add("HUDDrawPickupHistory", "esp", esp)
hook.Add("HUDDrawPickupHistory", "twobox", twobox)
hook.Add("Think", "bhop", bhop)
hook.Add("RenderScreenspaceEffects", "chams", chams)
hook.Add("HUDDrawPickupHistory", "esp", esp)
hook.Add("HUDPaint", "EyeTracers", EyeTracers)
hook.Add("PostDrawSkyBox", "NoSky", NoSky)
hook.Add("HUDDrawTargetID", "ThreeDTracer", ThreeDTracer)
hook.Add("HUDDrawTargetID", "TwoDTracer", TwoDTracer)
hook.Add("HUDDrawScoreBoard", "DistancePropEspTwoD", DistancePropEspTwoD)
hook.Add("HUDDrawScoreBoard", "DistancePropEspThreeD", DistancePropEspThreeD)
hook.Add("PostRenderVGUI", "watermark", watermark)
hook.Add("player_hurt", "chatinfo", chatinfo)
hook.Add("entity_killed", "propcount", proplog)
hook.Add("PostRenderVGUI", "PropDrawCounter", PropDrawCounter)
hook.Add("HUDPaint", "Headsmash", Headsmash)
hook.Add("HUDPaint", "SineWaveESP", SineWaveESP)
hook.Add("HUDPaint", "SineWaveCrossedHair", SineWaveCrossedHair)
hook.Add("HUDDrawPickupHistory", "weaponesp", weaponesp)
hook.Add("HUDDrawPickupHistory", "GreatThreeDBox", GreatThreeDBox)
hook.Add("HUDDrawPickupHistory", "ThreeDTwoDBox", ThreeDTwoDBox)
hook.Add("HUDDrawScoreBoard", "xray", xray)
hook.Add("Think", "Aimbot", Aimbot)
hook.Add("Think", "PropAimbot", PropAimbot)
hook.Add("CalcView", "fov", fov)
hook.Add("CalcView", "ThirdPerson", ThirdPerson)
hook.Add("RenderScene", "AsusWalls", AsusWalls)
safe()
MsgN("Injection Of Custom Private Hooker Detours By Electfried Success")

/************************************
	Name: Custom Private ASCII Refrence Graphs By Electfried.
	Purpose: Inject Custom Private ASCII Refrence Graphs By Electfried.
	Author: Electfried
	OS: Windows 10 Ultimate 64 Bits
************************************/

MsgN("Beginning Injection Of Custom Private ASCII Refrence Graphs By Electfried...")

MsgN(sine)
MsgN(sinegraph)
MsgN(cosine)
MsgN(cosinegraph)
MsgN(tangent)
MsgN(tangentgraph)

MsgN("Injection Of Custom Private ASCII Refrence Graphs By Electfried Success")

/************************************
	Name: Custom Private UnRegistered Message Detour By Electfried.
	Purpose: Inject Custom Private UnRegistered Message Detour By Electfried.
	Author: Electfried
	OS: Windows 10 Ultimate 64 Bits
************************************/

MsgN("Beginning Injection Of Custom Private UnRegistered Message Detour By Electfried...")

local info =
[[
This Is The UnRegistered Version , Please Contact id/electfried For More InFormation.


"The Noon Of Day On A October Evening Was Unlike Another . The Sky Hidden Beneath A Cloud Of White Gray And The Ominous Ambience Of A Hum .
I Was Awaken Too A Hum And During This Quiet Evening I Heard The Sound Of People Screaming . I Saw Out My White Door What I Thought Was A Illusion Of A Long Widened Carrier;
Yet Too My Dismay It Was A Ship . I Open The Door An Embark Down The Broken Cement Steps With Growing Foilage Towards A Empty Road .
The Screaming Became Palpable From A Distance And The Humming Became More Intense As I Stood Staring At The Deaths Of Hundreds .
The Fear Hit Me Like A Pinched Nerve And I Began Too Run Back Too My House As I Knew I Was The Next Target .
As I Rushed Up The Steps The Humming Intensified Drastically An It Felt As If Time Was Aging .
The Trees Were Dying , The Concrete Cracking And The Steps Foilage Growing Too Immensive Heights .
I Felt Every Single Part Of My Body Begin Too Age And Quickly Decimate; Time Has Stopped Completely ."

Poem By Electfried - By Electfried .

	Contact Information
	
	/id/electfried
	/id/electfriedalt

	/groups/sinewaveteam
	/groups/employer
]]
 
local window = vgui.Create("DFrame")
window:SetSize(640, 480)
window:Center()
window:SetPos(300, 150)
window:SetTitle("UnRegistered __Employer Anonymous Hook By Electfried")
window:SetVisible(true)
window:SetDraggable(false)
window:ShowCloseButton(false)
window:MakePopup()
 
local button = vgui.Create( "DButton", window )
button:SetSize(100, 40)
button:SetPos((window:GetWide() - button:GetWide()) / 2, window:GetTall() - button:GetTall() - 10)
button:SetText("Wait - ")
button:SetDisabled(true)
 
local text = vgui.Create( "DTextEntry", window )
text:SetSize(620,360)
text:Center()
text:SetMultiline(true)
text:SetDisabled(true)
text:SetText(info)
 
timersec = 3
 
timer.Create("countDown", 1, 3, function()
    timersec = timersec - 1
    button:SetText("Wait - " .. timersec)
        if timersec == 0 then
            button:SetText("Close")
            button:SetDisabled(false)
        button.DoClick = function() window:Close() end
    end
end)
 
if timersec == 0 then
    button:SetText("Close")
    button:SetDisabled(false)
    button.DoClick = function() window:Close() end
end

UnRegistered = [[


************************************************************************************************************
	WARNING: This Is An UnRegistered Copy Of __Employer Anonymous Hook , Contact id/electfried !
************************************************************************************************************

]]

MsgN(UnRegistered)

MsgN("Injection Of Custom Private UnRegistered Message Detour By Electfried Success")
/************************************

	More Hacks Too Be Continued In v.2

************************************/