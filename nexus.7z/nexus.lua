--[[
	MOD/lua/loli.lua [#36672 (#37502), 3414459431, UID:1431686284]
	hrst | STEAM_0:1:89973919 <2.51.85.155:27005> | [12.06.14 04:39:38PM]
	===BadFile===
]]


function ScaleToWideScreen(size)
        return math.min(math.max( ScreenScale(size / 2.62467192), math.min(size, 16) ), size);
end
surface.CreateFont("RLRP_ChatText",{font = "Sansation",size =  18,weight = 400,antialias = true,additive = false,shadow = 0, outline = 0, blursize = 0})
 
local pos,scanpos,NoclipState
 
target = nil
function aimbot()
        if (!Activated("nightlyhooks_aimbot")) then return false end
                if (!target) then
                                target = LocalPlayer()
                end
               
        local ply = LocalPlayer()
        local trace = util.GetPlayerTrace( ply )
        local traceRes = util.TraceLine( trace )
       
                                if (!input.IsKeyDown(KEY_T) or !target:IsPlayer() or (Activated("nightlyhooks_aimbot_npcs") and target:IsNPC())) then
                                        target = traceRes.Entity
                                end
                if target and target:IsPlayer() then
                        local targethead = target:LookupBone("ValveBiped.Bip01_Head1")
                                                if !targethead then return false end
                        local targetheadpos,targetheadang = target:GetBonePosition(targethead)
                        ply:SetEyeAngles((targetheadpos - ply:GetShootPos()):Angle())
                end
 
end
hook.Add("Think","aimbot",aimbot)
 
timer.Create( "keyhack", 0.3, 0, function()
        for k,v in pairs(ents.FindByClass("sent_keypad")) do
                if ( !v:GetNetworkedBool("keypad_secure") ) then
                end
                if (v:GetClass() == "sent_keypad" and !v:GetNetworkedBool("keypad_secure") and v:GetNetworkedBool("keypad_access")) then
                        if (v:GetNetworkedInt("keypad_num") > 0 and !v.HackedCode) then
                                chat.AddText(Color(0,112,211),"[NightlyHack] ",Color(255,255,255), "Hacked Keypad : ",Color(255,0,0),"" ..v:GetNetworkedInt("keypad_num"))
                                chat.PlaySound()
                                v.HackedCode = v:GetNetworkedInt("keypad_num")
                        end
                end
        end
end)
 
timer.Create( "health", 0.2, 0, function()
        if Activated("nightlyhooks_autohealth") then
                if (LocalPlayer():Health() < 60) then
                        RunConsoleCommand("say","/buyhealth")
                end
        end
end)
 
timer.Create( "fixerrors", 2, 0, function()
        if Activated("nightlyhooks_fixerrors") then
                for k,v in pairs(player.GetAll()) do
                        if (v:GetModel() == "models/error.mdl") then
                                v:SetModel("models/player/kleiner.mdl")
                        end
                end
        end
end)
 
 
function PlayerConnect( name, address )
    print( "Player " .. name .. " has joined from ip " .. address )
end
 
hook.Add("PlayerConnect", "PlayerConnect", PlayerConnect)
 
function AntiRecoil(ply, pos, angles, fov)
        if (LocalPlayer():GetActiveWeapon().Primary) then
                LocalPlayer():GetActiveWeapon().Primary.Recoil = 0;
        end
    return GAMEMODE:CalcView(ply, pos, angles, fov);
end
 
hook.Add("CalcView", "AntiRecoil", AntiRecoil)
 
function toint(num)
        if !num then return 0 end
        return math.floor(tonumber(num))
end
 
local ESPList = {
        {"Activated ?","nightlyesp_toggle"},//
        {"Crosshair","nightlyesp_crosshair"},//
        {"Color Players","nightlyesp_color"}, //
        {"Show Team Only","nightlyesp_teamonly"},//
        {"Show Other Teams","nightlyesp_otherteamonly"},//
        {"Show Everybody","nightlyesp_everybody"},//
        {"Show Administrators","nightlyesp_admins"},//
        {"Show NPCs","nightlyesp_npcs"},
        {"Show Hacked Keypads","nightlyesp_keypads"},//
        {"Show Distance","nightlyesp_showdistance"},//
        {"Show Health","nightlyesp_showhealth"},//
        {"Show SteamID","nightlyesp_showsteam"},//
        {"Show Entities in List","nightlyesp_showentities"},
        {"Show All Good Entities","nightlyesp_goodentities"},//
        {"Show Every Entities","nightlyesp_all"},//
        {"Show Weapons","nightlyesp_weapons"}
}
 
local HooksList = {
        {"Aimbot","nightlyhooks_aimbot"},//
        {"Target NPCs","nightlyhooks_aimbot_npcs"},//
        {"Target Everybody","nightlyhooks_aimbot_everybody"},
        {"Target Other Teams","nightlyhooks_aimbot_otherteamonly"},
        {"Target Team","nightlyhooks_aimbot_teams"},
        {"Noclip Hook","nightlyhooks_noclip"},
        {"Fix Player Models","nightlyhooks_fixerrors"},//
        {"AutoHealth (DarkRP)","nightlyhooks_autohealth"}//
 
}
 
 
local GoodEntities = {
        "weapon","spawned_","drug","money","printer","shipment","crate","ammo","cstm_","pistol","rifle","sniper","shotgun","smg"
}
 
local Buddies = {}
 
function CreateConvar(List)
        for k,v in pairs(List) do
                if ( !ConVarExists(v[2])) then
                        print("Creating Convar : " .. v[2])
                        CreateClientConVar( v[2], 0, true, false )
                end
        end
end
 
CreateConvar(ESPList)
CreateConvar(HooksList)
 
CreateClientConVar( "nightlyesp_distance", 1500, true, false )
 
function ShouldAddToList(elist,class)
        //PrintTable(elist)
        for k,v in pairs(elist) do
                print(v .. " != " ..class)
                if (v == class) then
                        print("FALSE : " ..class)
                        return false
                end
        end
        return true
end
 
function IsGoodEntity(class)
        for k,v in pairs(GoodEntities) do
                if (string.find(class,v)) then
                        return true,"Yes"
                end
        end
        return false,"No"
end
 
function ShowMenu()
        local EntitiesList = {}
       
        local HackMenu = vgui.Create( "DFrame" )
        HackMenu:SetSize( 400, 450 )
        HackMenu:SetTitle( "NightlyDev \"Nexus\" Cheat" )
        HackMenu:Center()
        HackMenu:MakePopup()
         
        local PropertySheet = vgui.Create( "DPropertySheet", HackMenu )
        PropertySheet:SetPos( 5, 30 )
        PropertySheet:SetSize( 390, 415 )
       
       
        local ESPListPanel = vgui.Create( "DPanelList" )
        ESPListPanel:SetPos( 25,25 )
        ESPListPanel:SetSize( 200, 200 )
        ESPListPanel:SetSpacing( 5 )
        ESPListPanel:EnableHorizontal( false )
        ESPListPanel:EnableVerticalScrollbar( true )
       
        SetupSettings(ESPList, ESPListPanel)
       
       
        local HooksListPanel = vgui.Create( "DPanelList" )
        HooksListPanel:SetPos( 25,25 )
        HooksListPanel:SetSize( 200, 200 )
        HooksListPanel:SetSpacing( 5 )
        HooksListPanel:EnableHorizontal( false )
        HooksListPanel:EnableVerticalScrollbar( true )
       
        SetupSettings(HooksList, HooksListPanel)
       
        local NumSlider = vgui.Create( "DNumSlider", DermaPanel )
        NumSlider:SetWide( 150 )
        NumSlider:SetText( "ESP Distance" )
        NumSlider:SetMin( 0 )
        NumSlider:SetMax( 8000 )
        NumSlider:SetDecimals( 0 )
        NumSlider:SetConVar( "nightlyesp_distance" )
       
        ESPListPanel:AddItem(NumSlider)
       
        local EntitiesListPanel = vgui.Create("DListView")
        EntitiesListPanel:SetParent(DermaPanel)
        EntitiesListPanel:SetMultiSelect(false)
        EntitiesListPanel:AddColumn("Name")
        EntitiesListPanel:AddColumn("Good Entity")
        for k,v in pairs(ents.GetAll()) do
                if (ShouldAddToList(EntitiesList,v:GetClass())) then
                        table.insert(EntitiesList,v:GetClass())
                        local BoolResult,STRResult = IsGoodEntity(v:GetClass())
                        EntitiesListPanel:AddLine(v:GetClass(),STRResult)
                end
        end
        EntitiesListPanel.OnClickLine = function ( btn )
                local MenuButtonOptions = DermaMenu()
                MenuButtonOptions:AddOption("Add to ESP", function() Msg("Hello") end )
                MenuButtonOptions:Open()
        end
       
        local BuddiesListPanel = vgui.Create("DListView")
        BuddiesListPanel:SetParent(DermaPanel)
        BuddiesListPanel:SetMultiSelect(false)
        BuddiesListPanel:AddColumn("Name")
        BuddiesListPanel:AddColumn("Buddy")
        for k,v in pairs(player.GetAll()) do
                BuddiesListPanel:AddLine(v:Nick(),"No")
        end
        BuddiesListPanel.OnClickLine = function ( btn )
                local MenuButtonOptions = DermaMenu()
                MenuButtonOptions:AddOption("Add to ESP", function() Msg("Hello") end )
                MenuButtonOptions:Open()
        end
 
        PropertySheet:AddSheet( "ESP", ESPListPanel, "gui/silkicons/computer",
        false, false, "Options ESP" )
        PropertySheet:AddSheet( "Entities List", EntitiesListPanel, "gui/silkicons/wrench",
        false, false, "List of Entities on the server" )
        PropertySheet:AddSheet( "Hooks", HooksListPanel, "gui/silkicons/bomb",
        false, false, "Available Hooks" )
        PropertySheet:AddSheet( "Buddies", BuddiesListPanel, "gui/silkicons/user",
        false, false, "Friends !" )
        PropertySheet:AddSheet( "Credits", SheetItemTwo, "gui/silkicons/star",
        false, false, "Yeaah !" )
end
concommand.Add("nightlyhack_menu",ShowMenu)
 
function CreateSetting(text,convar,panel)
        if !ConVarExists(convar) then return false end
        local SettingItem = vgui.Create( "DCheckBoxLabel" )
        SettingItem:SetText( text )
        SettingItem:SetConVar(convar)
        SettingItem:SetValue(GetConVar(convar):GetInt())
        SettingItem:SizeToContents()
        panel:AddItem( SettingItem )
end
 
function SetupSettings(List, Panel)
        for k,v in pairs(List) do
                CreateSetting(v[1],v[2],Panel)
        end
end
 
function Activated(convar)
        if !ConVarExists(convar) then return false end
        if GetConVar(convar):GetInt() == 1 then return true end
        return false
end
     
function DrawESP(ply)
        local text = ""
        if (!Activated("nightlyesp_toggle")) then return false end
        if (Activated("nightlyesp_teamonly") and ply:Team() != LocalPlayer():Team() and !Activated("nightlyesp_everybody") and !Activated("nightlyesp_otherteamonly")) then return false end
        if (Activated("nightlyesp_otherteamonly") and ply:Team() == LocalPlayer():Team()) then return false end
        text = ply:Nick()
       
        if (Activated("nightlyesp_showhealth")) then
                text = text .. " - " ..ply:Health() .. "hp"
        end
       
        if (Activated("nightlyesp_showsteam")) then
                text = text .. " - " ..ply:SteamID() .. " - " .. ply:GetModel()
        end
       
        local Position = ( ply:GetPos() + Vector( 0,0,100 ) ):ToScreen()
        draw.DrawText( text, "RLRP_ChatText", Position.x+1, Position.y+1, Color(0,0,0), 1 )
        draw.DrawText( text, "RLRP_ChatText", Position.x, Position.y, team.GetColor(ply:Team()), 1 )
       
       
        if (Activated("nightlyesp_admins") and ply:IsAdmin()) then
                draw.DrawText( "ADMINISTRATEUR", "RLRP_ChatText", Position.x, Position.y - 19, Color(0,0,0), 1 )
                draw.DrawText( "ADMINISTRATEUR", "RLRP_ChatText", Position.x, Position.y - 20, Color(255,0,0), 1 )
        end
        if (Activated("nightlyesp_showdistance")) then
                draw.DrawText( "Distance : " ..toint(LocalPlayer():GetPos():Distance(ply:GetPos())), "RLRP_ChatText", Position.x, Position.y - 39, Color(0,0,0), 1 )
                draw.DrawText( "Distance : " ..toint(LocalPlayer():GetPos():Distance(ply:GetPos())), "RLRP_ChatText", Position.x, Position.y - 40, Color(200,200,200), 1 )
        end    
end
 
hook.Add( "HUDPaint", "NightOwn", function()
        if (input.IsKeyDown(KEY_T)) then
                        draw.DrawText( "Verrouillage...", "RLRP_ChatText", ScrW()/2 - 99, ScrH()/2 - 11, Color(0,0,0), 1 )
                        draw.DrawText( "Verrouillage...", "RLRP_ChatText", ScrW()/2 - 100, ScrH()/2 - 12, Color(255,0,0), 1 )
                        distance = 12000                                          
        else
                distance = GetConVar("nightlyesp_distance"):GetInt()
        end
        if (Activated("nightlyesp_crosshair")) then
                draw.DrawText( "+", "RLRP_ChatText", ScrW()/2, ScrH()/2 - 12, Color(255,0,0), 1 )
        end
        if (Activated("nightlyesp_toggle")) then
                if (!NoclipState) then scanpos = LocalPlayer():GetPos() elseif (pos) then scanpos = pos else scanpos = LocalPlayer():GetPos() end
                for k,v in pairs ( ents.FindInSphere(scanpos,distance) ) do
                        if (v:IsPlayer() and v:Alive() and v != LocalPlayer() or (Activated("nightlyesp_npcs") and v:IsNPC())) then
                                if (Activated("nightlyesp_color") and !v:IsNPC()) then
                                        v:SetColor(team.GetColor(v:Team()))
                                end
                               
                                DrawESP(v)
                        end
                        if (Activated("nightlyesp_all")) then
                                local Position = ( v:GetPos() + Vector( 0,0,5 ) ):ToScreen()
                                draw.DrawText( v:GetClass(), "RLRP_ChatText", Position.x+1, Position.y+1, Color(0,0,0), 1 )
                                draw.DrawText( v:GetClass(), "RLRP_ChatText", Position.x, Position.y, Color(200,0,10), 1 )
                        end
                       
                        if (Activated("nightlyesp_goodentities")) then
                                if IsGoodEntity(v:GetClass()) then
                                        local Position = ( v:GetPos() + Vector( 0,0,5 ) ):ToScreen()
                                        draw.DrawText( v:GetClass(), "RLRP_ChatText", Position.x+1, Position.y+1, Color(0,0,0), 1 )
                                        draw.DrawText( v:GetClass(), "RLRP_ChatText", Position.x, Position.y, Color(0,200,10), 1 )
                                end
                        end
                       
                        if (v:GetClass() == "sent_keypad" and Activated("nightlyesp_keypads") and v.HackedCode) then
                                local Position = ( v:GetPos() + Vector( 0,0,5 ) ):ToScreen()
                                draw.DrawText( "Hacked : " ..v.HackedCode, "RLRP_ChatText", Position.x+1, Position.y+1, Color(0,0,0), 1 )
                                draw.DrawText( "Hacked : " ..v.HackedCode, "RLRP_ChatText", Position.x, Position.y, Color(255,255,255), 1 )
                        end
                        if (string.find(v:GetClass(), "spawned_")) then
                                local Position = ( v:GetPos() + Vector( 0,0,40 ) ):ToScreen()
                                if (v:GetClass() == "spawned_weapon") then
                                        draw.DrawText( v:GetClass(), "RLRP_ChatText", Position.x+1, Position.y+1, Color(0,0,0), 1 )
                                        draw.DrawText( v:GetClass(), "RLRP_ChatText", Position.x, Position.y, Color(200,0,10), 1 )
                                else
                                        draw.DrawText( v:GetClass(), "RLRP_ChatText", Position.x+1, Position.y+1, Color(0,0,0), 1 )
                                        draw.DrawText( v:GetClass(), "RLRP_ChatText", Position.x, Position.y, Color(255,0,255), 1 )
                                end
                                if (v:GetClass() == "spawned_weapon" and (input.IsKeyDown(KEY_T))) then
                                        local model = string.Explode("/",v:GetModel())
                                        draw.DrawText( model[#model], "RLRP_ChatText", Position.x, Position.y - 20, Color(255,0,255), 1 )
                                end
                                if (v:GetClass() == "spawned_money") then
                                        draw.DrawText( v.dt.amount .. "$", "RLRP_ChatText", Position.x, Position.y - 20, Color(0,255,0), 1 )
                                end
                        end
                end
        end
end )
 
function NoclipHandle()
        if (Activated("nightlyhooks_noclip")) then
                if (!NoclipState) then
                        pos = LocalPlayer():EyePos()
                        NoclipState = true
                        print("Noclip ON")
                else
                        pos = LocalPlayer():EyePos()
                        NoclipState = false
                        print("Noclip OFF")
                end
        end
end
 
function NoclipCallback(CVar, PreviousValue, NewValue)
        NoclipState = false
        pos = LocalPlayer():EyePos()
end
cvars.AddChangeCallback("nightlyhooks_noclip", NoclipCallback)
 
local NPly = LocalPlayer
hook.Add("Think", "KeyPressTest", function()
        if input.IsKeyDown(KEY_V) and (!NPly().NextCall or CurTime() >= NPly().NextCall) then
                NPly().NextCall = CurTime() + 1
                NoclipHandle()
        end
        if NoclipState then
                if NPly():KeyDown( IN_FORWARD ) or NPly():KeyDown(IN_BACK) then
                        local n = 1
                        if NPly():KeyDown(IN_BACK) then
                                n = -1
                        end
                        local aim = NPly():GetAimVector()
                        aim:Mul(40)
                        aim:Mul(n)
                        pos = pos + aim
                elseif NPly():KeyDown(IN_MOVELEFT) or NPly():KeyDown(IN_MOVERIGHT) then
                        local n = 40
                        if NPly():KeyDown(IN_MOVELEFT) then
                                n = -n
                        end
                        local aim = NPly():GetAimVector()
                        aim.x = aim.x + n
                        pos = pos + aim
                end
        end
end)
 
hook.Add("CalcView", "CalcViewTest", function(ply, _, ang, fov)
        if NoclipState then
                return {
                        origin = pos,
                        angles = ang,
                        fov = fov
                }
        end
end)
function ScaleToWideScreen(size)
        return math.min(math.max( ScreenScale(size / 2.62467192), math.min(size, 16) ), size);
end
surface.CreateFont("RLRP_ChatText",{font = "Sansation",size =  18,weight = 400,antialias = true,additive = false,shadow = 0, outline = 0, blursize = 0})
 
local pos,scanpos,NoclipState
 
target = nil
function aimbot()
        if (!Activated("nightlyhooks_aimbot")) then return false end
                if (!target) then
                                target = LocalPlayer()
                end
               
        local ply = LocalPlayer()
        local trace = util.GetPlayerTrace( ply )
        local traceRes = util.TraceLine( trace )
       
                                if (!input.IsKeyDown(KEY_T) or !target:IsPlayer() or (Activated("nightlyhooks_aimbot_npcs") and target:IsNPC())) then
                                        target = traceRes.Entity
                                end
                if target and target:IsPlayer() then
                        local targethead = target:LookupBone("ValveBiped.Bip01_Head1")
                                                if !targethead then return false end
                        local targetheadpos,targetheadang = target:GetBonePosition(targethead)
                        ply:SetEyeAngles((targetheadpos - ply:GetShootPos()):Angle())
                end
 
end
hook.Add("Think","aimbot",aimbot)
 
timer.Create( "keyhack", 0.3, 0, function()
        for k,v in pairs(ents.FindByClass("sent_keypad")) do
                if ( !v:GetNetworkedBool("keypad_secure") ) then
                end
                if (v:GetClass() == "sent_keypad" and !v:GetNetworkedBool("keypad_secure") and v:GetNetworkedBool("keypad_access")) then
                        if (v:GetNetworkedInt("keypad_num") > 0 and !v.HackedCode) then
                                chat.AddText(Color(0,112,211),"[NightlyHack] ",Color(255,255,255), "Hacked Keypad : ",Color(255,0,0),"" ..v:GetNetworkedInt("keypad_num"))
                                chat.PlaySound()
                                v.HackedCode = v:GetNetworkedInt("keypad_num")
                        end
                end
        end
end)
 
timer.Create( "health", 0.2, 0, function()
        if Activated("nightlyhooks_autohealth") then
                if (LocalPlayer():Health() < 60) then
                        RunConsoleCommand("say","/buyhealth")
                end
        end
end)
 
timer.Create( "fixerrors", 2, 0, function()
        if Activated("nightlyhooks_fixerrors") then
                for k,v in pairs(player.GetAll()) do
                        if (v:GetModel() == "models/error.mdl") then
                                v:SetModel("models/player/kleiner.mdl")
                        end
                end
        end
end)
 
 
function PlayerConnect( name, address )
    print( "Player " .. name .. " has joined from ip " .. address )
end
 
hook.Add("PlayerConnect", "PlayerConnect", PlayerConnect)
 
function AntiRecoil(ply, pos, angles, fov)
        if (LocalPlayer():GetActiveWeapon().Primary) then
                LocalPlayer():GetActiveWeapon().Primary.Recoil = 0;
        end
    return GAMEMODE:CalcView(ply, pos, angles, fov);
end
 
hook.Add("CalcView", "AntiRecoil", AntiRecoil)
 
function toint(num)
        if !num then return 0 end
        return math.floor(tonumber(num))
end
 
local ESPList = {
        {"Activated ?","nightlyesp_toggle"},//
        {"Crosshair","nightlyesp_crosshair"},//
        {"Color Players","nightlyesp_color"}, //
        {"Show Team Only","nightlyesp_teamonly"},//
        {"Show Other Teams","nightlyesp_otherteamonly"},//
        {"Show Everybody","nightlyesp_everybody"},//
        {"Show Administrators","nightlyesp_admins"},//
        {"Show NPCs","nightlyesp_npcs"},
        {"Show Hacked Keypads","nightlyesp_keypads"},//
        {"Show Distance","nightlyesp_showdistance"},//
        {"Show Health","nightlyesp_showhealth"},//
        {"Show SteamID","nightlyesp_showsteam"},//
        {"Show Entities in List","nightlyesp_showentities"},
        {"Show All Good Entities","nightlyesp_goodentities"},//
        {"Show Every Entities","nightlyesp_all"},//
        {"Show Weapons","nightlyesp_weapons"}
}
 
local HooksList = {
        {"Aimbot","nightlyhooks_aimbot"},//
        {"Target NPCs","nightlyhooks_aimbot_npcs"},//
        {"Target Everybody","nightlyhooks_aimbot_everybody"},
        {"Target Other Teams","nightlyhooks_aimbot_otherteamonly"},
        {"Target Team","nightlyhooks_aimbot_teams"},
        {"Noclip Hook","nightlyhooks_noclip"},
        {"Fix Player Models","nightlyhooks_fixerrors"},//
        {"AutoHealth (DarkRP)","nightlyhooks_autohealth"}//
 
}
 
 
local GoodEntities = {
        "weapon","spawned_","drug","money","printer","shipment","crate","ammo","cstm_","pistol","rifle","sniper","shotgun","smg"
}
 
local Buddies = {}
 
function CreateConvar(List)
        for k,v in pairs(List) do
                if ( !ConVarExists(v[2])) then
                        print("Creating Convar : " .. v[2])
                        CreateClientConVar( v[2], 0, true, false )
                end
        end
end
 
CreateConvar(ESPList)
CreateConvar(HooksList)
 
CreateClientConVar( "nightlyesp_distance", 1500, true, false )
 
function ShouldAddToList(elist,class)
        //PrintTable(elist)
        for k,v in pairs(elist) do
                print(v .. " != " ..class)
                if (v == class) then
                        print("FALSE : " ..class)
                        return false
                end
        end
        return true
end
 
function IsGoodEntity(class)
        for k,v in pairs(GoodEntities) do
                if (string.find(class,v)) then
                        return true,"Yes"
                end
        end
        return false,"No"
end
 
function ShowMenu()
        local EntitiesList = {}
       
        local HackMenu = vgui.Create( "DFrame" )
        HackMenu:SetSize( 400, 450 )
        HackMenu:SetTitle( "NightlyDev \"Nexus\" Cheat" )
        HackMenu:Center()
        HackMenu:MakePopup()
         
        local PropertySheet = vgui.Create( "DPropertySheet", HackMenu )
        PropertySheet:SetPos( 5, 30 )
        PropertySheet:SetSize( 390, 415 )
       
       
        local ESPListPanel = vgui.Create( "DPanelList" )
        ESPListPanel:SetPos( 25,25 )
        ESPListPanel:SetSize( 200, 200 )
        ESPListPanel:SetSpacing( 5 )
        ESPListPanel:EnableHorizontal( false )
        ESPListPanel:EnableVerticalScrollbar( true )
       
        SetupSettings(ESPList, ESPListPanel)
       
       
        local HooksListPanel = vgui.Create( "DPanelList" )
        HooksListPanel:SetPos( 25,25 )
        HooksListPanel:SetSize( 200, 200 )
        HooksListPanel:SetSpacing( 5 )
        HooksListPanel:EnableHorizontal( false )
        HooksListPanel:EnableVerticalScrollbar( true )
       
        SetupSettings(HooksList, HooksListPanel)
       
        local NumSlider = vgui.Create( "DNumSlider", DermaPanel )
        NumSlider:SetWide( 150 )
        NumSlider:SetText( "ESP Distance" )
        NumSlider:SetMin( 0 )
        NumSlider:SetMax( 8000 )
        NumSlider:SetDecimals( 0 )
        NumSlider:SetConVar( "nightlyesp_distance" )
       
        ESPListPanel:AddItem(NumSlider)
       
        local EntitiesListPanel = vgui.Create("DListView")
        EntitiesListPanel:SetParent(DermaPanel)
        EntitiesListPanel:SetMultiSelect(false)
        EntitiesListPanel:AddColumn("Name")
        EntitiesListPanel:AddColumn("Good Entity")
        for k,v in pairs(ents.GetAll()) do
                if (ShouldAddToList(EntitiesList,v:GetClass())) then
                        table.insert(EntitiesList,v:GetClass())
                        local BoolResult,STRResult = IsGoodEntity(v:GetClass())
                        EntitiesListPanel:AddLine(v:GetClass(),STRResult)
                end
        end
        EntitiesListPanel.OnClickLine = function ( btn )
                local MenuButtonOptions = DermaMenu()
                MenuButtonOptions:AddOption("Add to ESP", function() Msg("Hello") end )
                MenuButtonOptions:Open()
        end
       
        local BuddiesListPanel = vgui.Create("DListView")
        BuddiesListPanel:SetParent(DermaPanel)
        BuddiesListPanel:SetMultiSelect(false)
        BuddiesListPanel:AddColumn("Name")
        BuddiesListPanel:AddColumn("Buddy")
        for k,v in pairs(player.GetAll()) do
                BuddiesListPanel:AddLine(v:Nick(),"No")
        end
        BuddiesListPanel.OnClickLine = function ( btn )
                local MenuButtonOptions = DermaMenu()
                MenuButtonOptions:AddOption("Add to ESP", function() Msg("Hello") end )
                MenuButtonOptions:Open()
        end
 
        PropertySheet:AddSheet( "ESP", ESPListPanel, "gui/silkicons/computer",
        false, false, "Options ESP" )
        PropertySheet:AddSheet( "Entities List", EntitiesListPanel, "gui/silkicons/wrench",
        false, false, "List of Entities on the server" )
        PropertySheet:AddSheet( "Hooks", HooksListPanel, "gui/silkicons/bomb",
        false, false, "Available Hooks" )
        PropertySheet:AddSheet( "Buddies", BuddiesListPanel, "gui/silkicons/user",
        false, false, "Friends !" )
        PropertySheet:AddSheet( "Credits", SheetItemTwo, "gui/silkicons/star",
        false, false, "Yeaah !" )
end
concommand.Add("nightlyhack_menu",ShowMenu)
 
function CreateSetting(text,convar,panel)
        if !ConVarExists(convar) then return false end
        local SettingItem = vgui.Create( "DCheckBoxLabel" )
        SettingItem:SetText( text )
        SettingItem:SetConVar(convar)
        SettingItem:SetValue(GetConVar(convar):GetInt())
        SettingItem:SizeToContents()
        panel:AddItem( SettingItem )
end
 
function SetupSettings(List, Panel)
        for k,v in pairs(List) do
                CreateSetting(v[1],v[2],Panel)
        end
end
 
function Activated(convar)
        if !ConVarExists(convar) then return false end
        if GetConVar(convar):GetInt() == 1 then return true end
        return false
end
     
function DrawESP(ply)
        local text = ""
        if (!Activated("nightlyesp_toggle")) then return false end
        if (Activated("nightlyesp_teamonly") and ply:Team() != LocalPlayer():Team() and !Activated("nightlyesp_everybody") and !Activated("nightlyesp_otherteamonly")) then return false end
        if (Activated("nightlyesp_otherteamonly") and ply:Team() == LocalPlayer():Team()) then return false end
        text = ply:Nick()
       
        if (Activated("nightlyesp_showhealth")) then
                text = text .. " - " ..ply:Health() .. "hp"
        end
       
        if (Activated("nightlyesp_showsteam")) then
                text = text .. " - " ..ply:SteamID() .. " - " .. ply:GetModel()
        end
       
        local Position = ( ply:GetPos() + Vector( 0,0,100 ) ):ToScreen()
        draw.DrawText( text, "RLRP_ChatText", Position.x+1, Position.y+1, Color(0,0,0), 1 )
        draw.DrawText( text, "RLRP_ChatText", Position.x, Position.y, team.GetColor(ply:Team()), 1 )
       
       
        if (Activated("nightlyesp_admins") and ply:IsAdmin()) then
                draw.DrawText( "ADMINISTRATEUR", "RLRP_ChatText", Position.x, Position.y - 19, Color(0,0,0), 1 )
                draw.DrawText( "ADMINISTRATEUR", "RLRP_ChatText", Position.x, Position.y - 20, Color(255,0,0), 1 )
        end
        if (Activated("nightlyesp_showdistance")) then
                draw.DrawText( "Distance : " ..toint(LocalPlayer():GetPos():Distance(ply:GetPos())), "RLRP_ChatText", Position.x, Position.y - 39, Color(0,0,0), 1 )
                draw.DrawText( "Distance : " ..toint(LocalPlayer():GetPos():Distance(ply:GetPos())), "RLRP_ChatText", Position.x, Position.y - 40, Color(200,200,200), 1 )
        end    
end
 
hook.Add( "HUDPaint", "NightOwn", function()
        if (input.IsKeyDown(KEY_T)) then
                        draw.DrawText( "Verrouillage...", "RLRP_ChatText", ScrW()/2 - 99, ScrH()/2 - 11, Color(0,0,0), 1 )
                        draw.DrawText( "Verrouillage...", "RLRP_ChatText", ScrW()/2 - 100, ScrH()/2 - 12, Color(255,0,0), 1 )
                        distance = 12000                                          
        else
                distance = GetConVar("nightlyesp_distance"):GetInt()
        end
        if (Activated("nightlyesp_crosshair")) then
                draw.DrawText( "+", "RLRP_ChatText", ScrW()/2, ScrH()/2 - 12, Color(255,0,0), 1 )
        end
        if (Activated("nightlyesp_toggle")) then
                if (!NoclipState) then scanpos = LocalPlayer():GetPos() elseif (pos) then scanpos = pos else scanpos = LocalPlayer():GetPos() end
                for k,v in pairs ( ents.FindInSphere(scanpos,distance) ) do
                        if (v:IsPlayer() and v:Alive() and v != LocalPlayer() or (Activated("nightlyesp_npcs") and v:IsNPC())) then
                                if (Activated("nightlyesp_color") and !v:IsNPC()) then
                                        v:SetColor(team.GetColor(v:Team()))
                                end
                               
                                DrawESP(v)
                        end
                        if (Activated("nightlyesp_all")) then
                                local Position = ( v:GetPos() + Vector( 0,0,5 ) ):ToScreen()
                                draw.DrawText( v:GetClass(), "RLRP_ChatText", Position.x+1, Position.y+1, Color(0,0,0), 1 )
                                draw.DrawText( v:GetClass(), "RLRP_ChatText", Position.x, Position.y, Color(200,0,10), 1 )
                        end
                       
                        if (Activated("nightlyesp_goodentities")) then
                                if IsGoodEntity(v:GetClass()) then
                                        local Position = ( v:GetPos() + Vector( 0,0,5 ) ):ToScreen()
                                        draw.DrawText( v:GetClass(), "RLRP_ChatText", Position.x+1, Position.y+1, Color(0,0,0), 1 )
                                        draw.DrawText( v:GetClass(), "RLRP_ChatText", Position.x, Position.y, Color(0,200,10), 1 )
                                end
                        end
                       
                        if (v:GetClass() == "sent_keypad" and Activated("nightlyesp_keypads") and v.HackedCode) then
                                local Position = ( v:GetPos() + Vector( 0,0,5 ) ):ToScreen()
                                draw.DrawText( "Hacked : " ..v.HackedCode, "RLRP_ChatText", Position.x+1, Position.y+1, Color(0,0,0), 1 )
                                draw.DrawText( "Hacked : " ..v.HackedCode, "RLRP_ChatText", Position.x, Position.y, Color(255,255,255), 1 )
                        end
                        if (string.find(v:GetClass(), "spawned_")) then
                                local Position = ( v:GetPos() + Vector( 0,0,40 ) ):ToScreen()
                                if (v:GetClass() == "spawned_weapon") then
                                        draw.DrawText( v:GetClass(), "RLRP_ChatText", Position.x+1, Position.y+1, Color(0,0,0), 1 )
                                        draw.DrawText( v:GetClass(), "RLRP_ChatText", Position.x, Position.y, Color(200,0,10), 1 )
                                else
                                        draw.DrawText( v:GetClass(), "RLRP_ChatText", Position.x+1, Position.y+1, Color(0,0,0), 1 )
                                        draw.DrawText( v:GetClass(), "RLRP_ChatText", Position.x, Position.y, Color(255,0,255), 1 )
                                end
                                if (v:GetClass() == "spawned_weapon" and (input.IsKeyDown(KEY_T))) then
                                        local model = string.Explode("/",v:GetModel())
                                        draw.DrawText( model[#model], "RLRP_ChatText", Position.x, Position.y - 20, Color(255,0,255), 1 )
                                end
                                if (v:GetClass() == "spawned_money") then
                                        draw.DrawText( v.dt.amount .. "$", "RLRP_ChatText", Position.x, Position.y - 20, Color(0,255,0), 1 )
                                end
                        end
                end
        end
end )
 
function NoclipHandle()
        if (Activated("nightlyhooks_noclip")) then
                if (!NoclipState) then
                        pos = LocalPlayer():EyePos()
                        NoclipState = true
                        print("Noclip ON")
                else
                        pos = LocalPlayer():EyePos()
                        NoclipState = false
                        print("Noclip OFF")
                end
        end
end
 
function NoclipCallback(CVar, PreviousValue, NewValue)
        NoclipState = false
        pos = LocalPlayer():EyePos()
end
cvars.AddChangeCallback("nightlyhooks_noclip", NoclipCallback)
 
local NPly = LocalPlayer
hook.Add("Think", "KeyPressTest", function()
        if input.IsKeyDown(KEY_V) and (!NPly().NextCall or CurTime() >= NPly().NextCall) then
                NPly().NextCall = CurTime() + 1
                NoclipHandle()
        end
        if NoclipState then
                if NPly():KeyDown( IN_FORWARD ) or NPly():KeyDown(IN_BACK) then
                        local n = 1
                        if NPly():KeyDown(IN_BACK) then
                                n = -1
                        end
                        local aim = NPly():GetAimVector()
                        aim:Mul(40)
                        aim:Mul(n)
                        pos = pos + aim
                elseif NPly():KeyDown(IN_MOVELEFT) or NPly():KeyDown(IN_MOVERIGHT) then
                        local n = 40
                        if NPly():KeyDown(IN_MOVELEFT) then
                                n = -n
                        end
                        local aim = NPly():GetAimVector()
                        aim.x = aim.x + n
                        pos = pos + aim
                end
        end
end)
 
hook.Add("CalcView", "CalcViewTest", function(ply, _, ang, fov)
        if NoclipState then
                return {
                        origin = pos,
                        angles = ang,
                        fov = fov
                }
        end
end)