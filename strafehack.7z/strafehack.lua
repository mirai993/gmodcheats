local bhop = { }
bhop.MetaPlayer = FindMetaTable( "Player") 
bhop.oldKeyDown = bhop.MetaPlayer['KeyDown']
bhop.On = true
bhop.SOn = true
bhop.Hooks = { hook = { }, name = { } }
bhop.jump = false
function bhop.AddHook(hookname, name, func)
	table.insert( bhop.Hooks.hook, hookname )
	table.insert( bhop.Hooks.name, name )
	hook.Add( hookname, name, func ) --Hopefully you have something better
end
bhop.MetaPlayer['KeyDown'] = function( self, key )
	if self ~= LocalPlayer() then return end
	
	if (key == IN_MOVELEFT) and bhop.left then
		return true
	elseif (key == IN_MOVERIGHT) and bhop.right then
		return true
	elseif (key == IN_JUMP) and bhop.jump then
		return true
	else
		return bhop.oldKeyDown( self, key )
	end
end

local oldEyePos = LocalPlayer():EyeAngles()--This is to see where player is looking
function bhop.CreateMove( cmd )
	bhop.jump = false
	if (cmd:KeyDown( IN_JUMP )) then
	
		if (not bhop.jump) then
			if (bhop.On and not LocalPlayer():OnGround()) then --Bhop here
				cmd:RemoveKey( IN_JUMP )
			end
		else
			bhop.jump = false
		end

		if(bhop.SOn ) then--auto strafer
			local traceRes = LocalPlayer():EyeAngles()
								   
			if( traceRes.y > oldEyePos.y ) then --If you move your mouse left, walk left, if you're jumping
				oldEyePos = traceRes
				cmd:SetSideMove( -1000000 )
				bhop.left = true
				bhop.right = false 
			elseif( oldEyePos.y > traceRes.y )  then --If you move your mouse right, move right,  while jumping
				oldEyePos = traceRes
				cmd:SetSideMove( 1000000 )
				bhop.right = true
				bhop.left = false
			end
		end
	elseif (not bhop.jump) then
		bhop.jump = true
	end		 
end
		   
bhop.AddHook( "CreateMove", tostring(math.random(0, 133712837)), bhop.CreateMove )--add the hook

concommand.Add( "bhop_bhop", function () --Toggler
	bhop.On = not bhop.On	
	local state = "off"
	if bhop.On then state = "on" end
	print("Bhop ".. state)
end)
	
concommand.Add( "bhop_strafe",  function ()
	bhop.SOn = not bhop.SOn
	local state = "off"
	if bhop.SOn then state = "on" end
	print("Strafe ".. state)
end)

concommand.Add("bhop_unload", function()
	for i = 1, #bhop.Hooks.hook do
		hook.Remove( bhop.Hooks.hook[i], bhop.Hooks.name[i] )
		print( "Unhooked "..bhop.Hooks.hook[i].." using name "..bhop.Hooks.name[i] )
	end
	
	concommand.Remove("ski_strafe")
	concommand.Remove("ski_bhop")
	concommand.Remove( "ski_unload" )
	bhop = nil
	
	print("Bhop unloaded")
end)
