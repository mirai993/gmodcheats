// pls shit codez
local form;
concommand.Add( "+shits", function()
	if( !form ) then
		form = vgui.Create( "ContextMenu" );
	end
	form:SetWorldClicker( true );
	form:MakePopup()
	form:SetVisible( true )
	form:SetKeyboardInputEnabled( false )
	form:SetMouseInputEnabled( true )
end )
concommand.Add( "-shits", function()
	form:SetVisible( false )
	form:SetKeyboardInputEnabled( true )
	form:SetMouseInputEnabled( true )
end )

hook.Add( "Think", "aim", function()
	if( !form || form && !form:IsVisible() ) then return end
	local target;
	for k, v in pairs( player.GetAll() ) do
		if( v && v:IsValid() && v:Alive() && v:GetMoveType() != 0 && v != LocalPlayer() ) then
			target = v;
			break;
		end
	end
	if( target ) then
		local pos = target:LocalToWorld( target:OBBCenter() ):ToScreen();
		if( pos && pos.visible ) then
			gui.SetMousePos( pos.x, pos.y );
		end
	end
end )