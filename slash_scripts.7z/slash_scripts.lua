--menu functions
-- thank you cae for these
local binds = {}
local bindsdebug = {}

idle_sequence = 0

local function addBind(key, action)
   if binds[key] then
       print("bind for " .. tostring(key) .. " already exists, overiding anyways.")
   end

   binds[key] = action
   bindsdebug[key] = false
end

function binds_think()
   for i, v in pairs(binds) do
       if input.IsKeyDown(i) and not bindsdebug[i] then
           v()
           bindsdebug[i] = true
       elseif not input.IsKeyDown(i) then
           bindsdebug[i] = false
       end
   end
end
---------------------

local function create_font(local_name, font_name, underlined, font_size, font_italic, outlined)
   if font_size == nil then font_size = 15 end 
   if underlined == nil then underlined = false end
   if font_italic == nil then font_italic = false end
   if outlined == nil then outlined = false end

   surface.CreateFont(local_name, {
      font = font_name,
      size = font_size,
      underline = underlined,
      italic = font_italic,
      outline = outlined
   })
end

local function flip_convar(convar)
   if GetConVarNumber(convar) == 1 then RunConsoleCommand(convar, 0) end
   if GetConVarNumber(convar) == 0 then RunConsoleCommand(convar, 1) end
 end

local function menu_toggle()
   flip_convar("ss_menu")
end

local menu_X = 0
local menu_Y = 0
local features_table = {}

local function menu_add_item(tab, item_name, var, isString)
   if GetConVarString("ss_tab") != tab and tab != "global" then return end
  
   if var != nil then 
      table.insert(features_table, menu_Y .. " " .. var)
      if isString != nil then 
         var = GetConVarString(var)
         var_text = var
         var_colour = Color(255, 255, 255, 255)
      end

      if isString == nil then
         var = GetConVarNumber(var)
         var_text = "???"
         var_colour = Color(255, 255, 255, 255)
   
         if var == 1 then 
            var_colour = Color(0, 255, 0, 255)
            var_text = "ON"
         end
   
         if var == 0 then 
            var_colour = Color(255, 0, 0, 255)
            var_text = "OFF"
         end
      end
      	
      draw.DrawText(var_text, "menu_item", menu_X + 250, menu_Y, var_colour)
   end
   draw.DrawText(item_name, "menu_item", menu_X, menu_Y)
   menu_Y = menu_Y + 20
end

local function menu_draw()
   if GetConVarNumber("ss_menu") != 1 then return end
   features_table = {}
   menu_X = ScrW() / 110
   menu_Y = ScrH() / 10 + 40
   --draw menu framework
   surface.SetDrawColor(0, 0, 0, 200)
   surface.DrawRect(ScrW() / 110, ScrH() / 10, 310, 300)
   
   surface.SetDrawColor(4, 247, 122, 230)
   surface.DrawRect(ScrW() / 110, ScrH() / 10, 310, 30)
   
   draw.DrawText("Slash Scripts", "menu_title", ScrW() / 110, ScrH() / 10)
   --end menu framework
   menu_add_item("global", "Tab", "ss_tab", true)

   menu_add_item("visuals", "Text ESP", "ss_esp_text")
   menu_add_item("visuals", "Draw Physgun Model", "ss_physgun_draw")
   menu_add_item("visuals", "No beam curvature", "ss_physgun_beamshit")
   menu_add_item("visuals", "Xray", "ss_esp_xray")
   menu_add_item("visuals", "Spec list", "ss_speclist")
   
   menu_add_item("visuals", "Model name", "ss_esp_modelname")

   menu_add_item("viewmodel", "Model changer", "ss_promode")
   menu_add_item("viewmodel", "Use last prop angle", "ss_viewmodel_lastprop")
   menu_add_item("viewmodel", "use wireframe", "ss_viewmodel_wireframe")
   menu_add_item("viewmodel", "use material", "ss_viewmodel_material")

   menu_add_item("misc", "Draw Debug Info", "ss_misc_debug")

end

local selected_X = menu_X
local selected_Y = ScrH() / 10 + 40

local function selected_draw()
   if GetConVarNumber("ss_menu") != 1 then return end
   surface.SetDrawColor(10, 183, 252, 150)
   surface.DrawRect(menu_X, selected_Y, 310, 16)
end

local active_anim

local function HandleUp()
   surface.PlaySound("UI/buttonrollover.wav")
   if timer.Exists("input_animation") then return end
   if selected_Y < ScrH() / 10 + 40 then return end

   timer.Create("", 0, 20, function()
      selected_Y = selected_Y - 1
   end )
end
 
local function HandleDown()
   surface.PlaySound("UI/buttonrollover.wav")
   if timer.Exists("input_animation") then return end
   timer.Create("input_animation", 0, 20, function()
      selected_Y = selected_Y + 1
   end )
end

local tab_array = {
   "visuals",
   "misc",
   "viewmodel",
   "settings"
}

local function HandleRight()
   for k,v in ipairs( features_table ) do
      v_split = string.Split(v, " ")
      if tostring(v_split[2]) == tostring("ss_tab") then 
         for k,v in ipairs( tab_array ) do
             if v == GetConVarString("ss_tab") and tostring(v_split[1]) == tostring(selected_Y) then
                 if k == 4 then newtab_index = 1 end  
                 if k != 4 then newtab_index = k + 1 end
                 RunConsoleCommand("ss_tab", tab_array[newtab_index])
                 return
             end
         end
         
      end
      if tostring(v_split[1]) == tostring(selected_Y) then
         surface.PlaySound("UI/buttonclickrelease.wav")
		   flip_convar(v_split[2])
		end 
    end
    
end

--end menu functions

--features

---visual features

local function esp_text()
   for k, v in pairs( player.GetAll() ) do
      if GetConVarNumber("ss_esp_text") != 1 then return end 

      if v ~= LocalPlayer() and v:Health() > 0 and v:Team() ~= TEAM_SPECTATOR then 
         local pos = ( v:GetShootPos() + Vector( 0, 0, LocalPlayer():GetShootPos():Distance( v:GetShootPos() ) / 30 ) ):ToScreen()
         esp_y = pos.y
         draw.DrawText(v:Nick(), "text_esp", pos.x, esp_y, Color(255, 255, 255, 255))
         esp_y = esp_y + 10
         
      end 
   end
end

local function draw_typing()
   istyping_string = "Players Typing:"
   amount = 0
   for k, v in pairs( player.GetAll() ) do
      if v:IsTyping() == true then
         amount = amount + 1
         istyping_string = istyping_string .. "   ".. v:Nick() .. "   "
      end
   end
   if amount == 0 then return end
   draw.DrawText(istyping_string .. "(" .. amount .. ")", "menu_item", 25, 600, Color(0, 255, 0, 255))
end

last_prop = nil

local function DrawPhysGun()
   if( IsValid( LocalPlayer():GetViewModel() ) ) then
      if GetConVarNumber("ss_physgun_draw") == 1 then should_draw = false end 
      if GetConVarNumber("ss_physgun_draw") == 0 then should_draw = true end              
		LocalPlayer():GetViewModel():SetNoDraw( should_draw )      
	end
end

local function BeamShit(ply, wep, enabled, target, bone, deltaPos)
 
   if ply != LocalPlayer() then return end
   if IsValid(target) then
      last_prop = target
   end
   if GetConVarNumber("ss_physgun_beamshit") != 1 then return end
   if ( !enabled ) then return false end
   
   local hitpos = ply:GetEyeTrace().HitPos
   if ( IsValid( target ) ) then
      local mt = target:GetBoneMatrix( bone )
      if mt == nil then return end
      if ( target:TranslatePhysBoneToBone( bone ) >= 0 ) then
          mt = target:GetBoneMatrix( target:TranslatePhysBoneToBone( bone ) )
      end
      hitpos = LocalToWorld( deltaPos, Angle( 0, 0, 0 ), mt:GetTranslation(), mt:GetAngles() )
   end
   
   local srcPos = wep:GetAttachment( 1 ).Pos
   if ( !ply:ShouldDrawLocalPlayer() ) then
      srcPos = ply:GetViewModel():GetAttachment( 1 ).Pos
   end 
   
   render.SetMaterial(Material("models/weapons/v_toolgun/screen_bg"))
 
   render.DrawBeam(srcPos, hitpos, 5, 0, 0, Color(255, 255, 255) )
   return false
end

local function DrawModelName()
   if GetConVarNumber("ss_esp_modelname") != 1 then return end
   for i, v in pairs(ents.FindByClass("prop_physics")) do 
      local pos = ( v:GetPos() + Vector( 0, 0, LocalPlayer():GetPos():Distance( v:GetPos() ) / 30 ) ):ToScreen()
      --local pos = v:GetPos():ToScreen()
      text = v:GetModel()
      if text == "models/props/de_tides/gate_large.mdl" then text = "Tide" end
      if text == "models/props/cs_militia/refrigerator01.mdl" then text = "Fridge" end
      draw.DrawText(text, "text_esp_13", pos.x, pos.y, Color(255, 89, 0))
   end
end

local function DrawXray(entity, material, colour, blend)

   render.SuppressEngineLighting(true)
   render.SetBlend(0.55)
   render.SetColorModulation(colour.x, colour.y, colour.z)

   entity:DrawModel()
   entity:SetRenderMode(RENDERMODE_TRANSALPHA)
   entity:SetMaterial(material) 
   entity:SetColor(ColorAlpha(entity:GetColor(), 0))

              
  render.MaterialOverride()
  render.SuppressEngineLighting(false)

end


offset = 0
local function xray()
   for i, v in pairs(ents.FindByClass("prop_physics")) do
      
     

		if GetConVarNumber( "ss_esp_xray" ) == 1 and not v:IsDormant() then
			cam.Start3D()
         cam.IgnoreZ(true)

         

         if v == last_prop then
            DrawXray(v, "models/wireframe", Vector(0, 1, 0), 1)
            render.DrawWireframeBox( v:GetPos(), v:GetAngles(), v:OBBMaxs() - Vector( 0, 0, 0 ), v:OBBMins() + Vector( 0, 0, 0 ), Color( 0, 255, 255 ) )
         end
         
         if v != last_prop then 
            pos = v:GetPos()
            z_value = pos.z / 1.5
            render.DrawWireframeBox( pos, v:GetAngles(), v:OBBMaxs() - Vector( 0, 0, 0 ), v:OBBMins() + Vector( 0, 0, 0 ), Color( 255, 0, 0 ) )  
            DrawXray(v, v:GetMaterial(), Vector(1, 1, 1), 0.5)
            DrawXray(v, "models/wireframe", Vector(0, 0, 1), 1)
            DrawXray(v, "models/wireframe", Vector(1, 0, 0), 1)
            DrawXray(v, v:GetMaterial(), Vector(0, 0, 1), 0.5 )
         end

			cam.End3D()
		end
	end

	for i, v in pairs(player.GetAll()) do
		if GetConVarNumber( "ss_esp_xray" ) == 1 and not v:IsDormant() then
			cam.Start3D()
			cam.IgnoreZ(true)
			render.SuppressEngineLighting(true)
			render.SetBlend(0.5)
			render.SetColorModulation(0, 1, 0)
			v:DrawModel()
         v:SetRenderMode(RENDERMODE_TRANSALPHA)
			v:SetMaterial("models/debug/debugwhite") -- models/weapons/v_toolgun/screen_bg 
			v:SetColor(ColorAlpha(v:GetColor(), 0))
			render.MaterialOverride()
			render.SuppressEngineLighting(false)
			cam.End3D()
		end
   end
   
   for i, v in pairs(player.GetAll()) do
		if GetConVarNumber( "ss_esp_xray" ) == 1 and not v:IsDormant() then
			cam.Start3D()
			cam.IgnoreZ(true)
			render.SuppressEngineLighting(true)
			render.SetBlend(0.5)
			render.SetColorModulation(1, 1, 0)
			v:DrawModel()
         v:SetRenderMode(RENDERMODE_TRANSALPHA)
         v:SetMaterial("Models/effects/comball_sphere") -- models/weapons/v_toolgun/screen_bg 
         v:DrawModel()
         v:DrawModel() -- remove this if you want, just makes it look nicer
         v:DrawModel()
         v:DrawModel()
			v:SetColor(ColorAlpha(v:GetColor(), 0))
			render.MaterialOverride()
			render.SuppressEngineLighting(false)
			cam.End3D()
		end
	end
end

local function FOV()
	local view = {}
	view.fov = GetConVarNumber("ss_fov")
	return view
end

local function Speclist()
   y = 30
   for i, v in pairs(player.GetAll()) do
      
      if v:GetObserverTarget() == LocalPlayer() and GetConVarNumber("ss_speclist") == 1 then
         draw.DrawText(v:Nick().. " --> " .. LocalPlayer():Nick(), "text_esp", menu_X, y)

         y = y + 25
      end
   end
end



local function prop_tracers()
   for k, v in pairs( player.GetAll() ) do
      cam.Start3D()
      if v ~= LocalPlayer() and v:Health() > 0  and v:Team() ~= TEAM_SPECTATOR and IsValid(v) and last_prop != nil and last_prop != NULL  then
          render.SetMaterial( Material("cable/physbeam") ) 
          render.DrawBeam(v:GetPos(), last_prop:GetPos(), 15, 0, 0, Color(255, 255, 255, 255))
      end
      cam.End3D()
   end
	 
end

model = nil

local function TF2Resolve(type)
   if type == "set" then 
      for k, v in pairs( player.GetAll() ) do
         if GetConVarString("ss_viewmodel_model") == "models/weapons/v_models/v_knife_spy.mdl" and last_prop != nil and last_prop != NULL and v != LocalPlayer() then -- spy memes
           if v:GetPos():Distance(last_prop:GetPos()) < 500 then 
               model:SetSequence(6)
              return
           end
         end
        end
     
      if GetConVarString("ss_viewmodel_model") == "models/weapons/v_models/v_medigun_medic.mdl" and last_prop != nil and last_prop != NULL then  
         model:SetSequence(4)
         return
      end

      if GetConVarString("ss_viewmodel_model") == "models/weapons/v_models/v_minigun_heavy.mdl" and last_prop != nil and last_prop != NULL then
         model:SetSequence(5)
         return
      end

      if GetConVarString("ss_viewmodel_model") == "models/weapons/v_models/v_pistol_engineer.mdl" and last_prop != nil and last_prop != NULL then
         model:SetSequence(2)
         return
      end

      if GetConVarString("ss_viewmodel_model") == "models/weapons/v_models/v_rocketlauncher_soldier.mdl" and last_prop != nil and last_prop != NULL then
         model:SetSequence(3)
         return
      end
   end

   if type == "get" then 
      PrintTable(model:GetSequenceList())
      if (GetConVarString("ss_viewmodel_model") == "models/weapons/v_models/v_knife_spy.mdl") then idle_sequence = 2 return end
      if (GetConVarString("ss_viewmodel_model") == "models/weapons/v_models/v_medigun_medic.mdl") then idle_sequence = 2 return end
      if (GetConVarString("ss_viewmodel_model") == "models/weapons/v_models/v_shotgun_engineer.mdl") then idle_sequence = 2 return end
      if (GetConVarString("ss_viewmodel_model") == "models/weapons/v_models/v_pistol_engineer.mdl") then idle_sequence = 1 return end
      if (GetConVarString("ss_viewmodel_model") == "models/weapons/v_models/v_rocketlauncher_soldier.mdl") then idle_sequence = 1 return end
   end
end

local function ProMode()
  
   if GetConVarNumber("ss_promode") != 1 then return end
   if GetConVarNumber("ss_physgun_draw") != 0 then 
      print("[SS] Pro Mode requires ss_physgun_draw == 0, setting.")
      RunConsoleCommand("ss_physgun_draw", "0")
   end
   model:SetSequence(idle_sequence)
   for i, v in pairs(ents.FindByClass("viewmodel")) do
      if model == nil then return end
      model:SetNoDraw( true )
      TF2Resolve("set")
      cam.Start3D()
      cam.IgnoreZ(true)
      v:SetRenderMode(RENDERMODE_NORMAL)
      pos = v:GetPos()
      angle = v:GetAngles()
      
      render.SetBlend(GetConVarNumber("ss_viewmodel_blend"))
    

      if last_prop != nil and last_prop != NULL then 
         prop_angle = last_prop:EyeAngles()
         if GetConVarNumber("ss_viewmodel_lastprop") == 1 then 
            angle = Angle(prop_angle.x, angle.y, prop_angle.z)
         end
      end
     
      
      model:SetColor(ColorAlpha(model:GetColor(), 0))
      render.SetColorModulation(1, 1, 1)
      model:SetPos(Vector(pos.x, pos.y, pos.z - 10))
      model:SetAngles(angle)

      model:SetMaterial() 
      model:DrawModel()

      if GetConVarNumber("ss_viewmodel_material") == 1 then
         render.SetBlend(1)
          model:SetMaterial("Models/effects/comball_tape") 
          model:DrawModel()
      end

      if GetConVarNumber("ss_viewmodel_wireframe") == 1 then 
         model:SetMaterial("models/wireframe") 
         model:DrawModel()
      end

      cam.End3D()
     
    end
    
end


local debug_X = ScrW() / 110
local debug_Y = ScrH() / 10 + 310

local function AddDebugItem(text)
   draw.DrawText(text, "menu_item", debug_X, debug_Y)
   debug_Y = debug_Y + 20
end

local function DrawDebugInfo()
   if GetConVarNumber("ss_misc_debug") != 1 then return end
   debug_Y = ScrH() / 10 + 310
   debug_X = ScrW() / 110
   if GetConVarNumber("ss_menu") == 0 then debug_Y = ScrH() / 10 + 40 end

   surface.SetDrawColor(0, 0, 0, 200)
   surface.DrawRect(debug_X, debug_Y, 310, 150)

   surface.SetDrawColor(4, 247, 122, 230)
   surface.DrawRect(debug_X, debug_Y, 310, 30)
   draw.DrawText("Debug Infomation", "menu_title", debug_X, debug_Y)
   debug_Y = debug_Y + 30
   AddDebugItem("Server IPAddress: " .. game.GetIPAddress())
   AddDebugItem("Map: " .. game.GetMap())
   AddDebugItem("LocalPlayer SteamID: " .. LocalPlayer():SteamID())
   AddDebugItem("FastDL Url: " .. GetConVarString("sv_downloadurl"))

end




local function DrawHUD()
   draw.RoundedBox(8, 35, 930, 230, 30, Color(0, 0, 0, 60))
   draw.DrawText("Slash Scripts" .. " Version 2.0", "ChatFont", 40, 935, Color(255, 0, 0 , 255))

end


---end visual features

--end features


local function THINK()
   binds_think()
end

local function HUDPAINT()
   selected_draw()
   menu_draw()
   DrawDebugInfo()
   Speclist()
   esp_text()
   DrawPhysGun()
   xray()
   prop_tracers()
   draw_typing()
   DrawModelName()
   ProMode()
   DrawHUD()

end

local function DRAWPHYSGUNBEAM(ply, wep, enabled, target, bone, deltaPos)
   BeamShit(ply, wep, enabled, target, bone, deltaPos)
end


local function Unload()
   print("Unloading Slash Scripts...")
   surface.PlaySound("vo/Citadel/gman_exit03.wav")

   hook.Remove("HUDPaint", "SSHUDPAINT")
   hook.Remove("Think", "SSTHINK")
   hook.Remove("CalcView", "SSCALCVIEW")
   hook.Remove("DrawPhysGunBeam", "SSBEAM")
end
-- end hooks

--initialization
local function convar_initialization()
   CreateClientConVar("ss_menu", "1", true, false)
   CreateClientConVar("ss_tab", "visuals", true, false)
   
   CreateClientConVar("ss_misc_debug", "1", true, false)

   CreateClientConVar("ss_esp_text", "0", true, false)
   CreateClientConVar("ss_esp_xray", "0", true, false)
   CreateClientConVar("ss_speclist", "0", true, false)
   CreateClientConVar("ss_promode", "0", true, false)
   CreateClientConVar("ss_esp_modelname", "0", true, false)
   

   CreateClientConVar("ss_fov", "90", true, false)

   CreateClientConVar("ss_viewmodel_lastprop", "0", true, false)
   CreateClientConVar("ss_viewmodel_model", "models/weapons/cstrike/c_rif_ak47.mdl", true, false)
   CreateClientConVar("ss_viewmodel_blend", "1", true, false)
   CreateClientConVar("ss_viewmodel_wireframe", "0", true, false)
   CreateClientConVar("ss_viewmodel_material", "0", true, false)

   CreateClientConVar("ss_physgun_draw", "1", true, false)
   CreateClientConVar("ss_physgun_beamshit", "0", true, false)

   concommand.Add("ss_unload", Unload)
end

local function font_initialization()
   create_font("menu_title", "Roboto", true, 25, true)
   create_font("menu_item", "Roboto", false, 15, false)
   create_font("text_esp", "Consolas", false, 15, false, true)
   create_font("text_esp_13", "Consolas", false, 13, false, true)
end

local function bind_initialization()
   addBind(KEY_INSERT, menu_toggle)
   addBind(KEY_UP, HandleUp)
   addBind(KEY_DOWN, HandleDown)
   addBind(KEY_RIGHT, HandleRight)
end

local function hook_initialization()
   hook.Add("HUDPaint", "SSHUDPAINT", HUDPAINT)
   hook.Add("Think", "SSTHINK", THINK)
   hook.Add("CalcView", "SSCALCVIEW", FOV)
   hook.Add("DrawPhysgunBeam", "SSBEAM", DRAWPHYSGUNBEAM)
end

local function var_initialization()
   model = ClientsideModel(GetConVarString("ss_viewmodel_model"))
   TF2Resolve("get")
end

local function initialization()
   convar_initialization()
   bind_initialization()
   hook_initialization()
   font_initialization()
   var_initialization()

   surface.PlaySound("vo/gman_misc/gman_riseshine.wav")
end
---end initialization


initialization()

local function rotate()
	LocalPlayer():SetEyeAngles( Angle( LocalPlayer():EyeAngles().p, LocalPlayer():EyeAngles().y - 180, LocalPlayer():EyeAngles().r ) )
end
concommand.Add("rotateshot", function() -- creates a concommand with a function 
   if last_prop == nil or last_prop == NULL then
      LocalPlayer():ChatPrint("[180shot] you're not holding a prop.")
      return
   end

	if hook.GetTable().CalcView["180shot"] then -- will look through the hook table and if it finds 180shot then do
		rotate() -- rotate, which is above in my script, this is just calling its function
		hook.Remove("CalcView", "180shot") -- not entirely sure why its doing this, i think its doing this right after the 180shot has been done
		timer.Destroy("180shot") -- will remove the timer as 180shot has been done, I THINK
		return
	end

	hook.Add("CalcView", "180shot", function(ply, origin, angle, fov)
		local view = {} -- creating an empty table called view
		view.origin = origin -- adding origin too the viewe table
		view.angles = angle - Angle(0,180,0) -- adding angles in the view table with the vector angle 0 angle(0,180,0)
		view.fov = GetConVarNumber("ss_fov")-- does nothing too the fov but adds the fov into the table

		if not LocalPlayer():KeyDown(IN_ATTACK) then -- it the local player isnt holding down the attack key then
			hook.Remove("CalcView", "180shot") -- removes the hook cause the player isnt holding the attack key
			rotate() -- will rotate
			timer.Destroy("180shot") -- will remove the timer as 180shot has been done, I THINK
		end

		return view -- returns the view table with all the new shit it has to do 
	end)
	rotate() -- rotates
	timer.Create("180shot", 5, 1, function() -- creates a timer with a function
		hook.Remove("CalcView", "180shot") -- removes the hook as 180shot hsa been done
		rotate() -- rotates
	end)
end)
-- im very confused on a fair bit of this, as i get better at lua ill learn how to do all this myself, but for now this will work
