--[[
	cl_hitladar.lua
	This Toast is traitor | (STEAM_0:0:43676365)
	===DStream===
]]

local correctView = Angle( 0, 0, 0 )
local CL = LocalPlayer()
local wep = LocalPlayer():GetActiveWeapon()
local NoSpreadHere=false
local PredictSpread = function() end
if #file.Find("../lua/includes/modules/gmcl_dllz.dll")>=1 then
NoSpreadHere=true

local function GetCone(wep)
    local cone = wep.Cone
    if not cone and type(wep.Primary) == "table" and type(wep.Primary.Cone) == "number" then
        cone = wep.Primary.Cone
    end
    if wep:GetClass() == "ose_turretcontroller" then return 0 end
    return cone or 0
end

require("dllz")
local getpr3d = hl2_ucmd_getpr3diction
local manipshot = hl2_manipshot
local currentseed, cmd2, seed = currentseed or 0, 0, 0
local wep, vecCone, valCone
PredictSpread = function(cmd,aimAngle)
    cmd2, seed = getpr3d(cmd)
    if cmd2 ~= 0 then
        currentseed = seed
    end
    wep = LocalPlayer():GetActiveWeapon()
    vecCone = Vector(0,0,0)
    if wep and wep:IsValid() and type(wep.Initialize) == "function" then
        valCone = GetCone(wep)
        if( tonumber( valCone ) ) then
        vecCone = Vector( -valCone, -valCone, -valCone )
        elseif( type( valCone ) == "Vector" ) then
        vecCone = -1 * valCone
        end
    end
	if wep:GetClass() == "weapon_smg1" then
	vecCone = Vector(-0.04362,-0.04362,-0.04362)
	elseif wep:GetClass() == "weapon_pistol" then
	vecCone = Vector( -0.0100, -0.0100, -0.0100 )
	elseif wep:GetClass() == "weapon_ar2" then
	vecCone = Vector( -0.02618, -0.02618, -0.02618 )
	elseif wep:GetClass() == "weapon_shotgun" then
	vecCone = Vector( -0.08716, -0.08716, -0.08716 )
	elseif wep:GetClass() == "weapon_iceaxe" then
	vecCone = Vector(-0.15,-0.15,-0.15)
	elseif wep:GetClass() == "weapon_sniper" then
	vecCone = Vector(-0.01,-0.01,0)
	elseif wep:GetClass() == "weapon_hmg1" then
	vecCone = Vector(-0.07,-0.07,-0.07)
	elseif wep:GetClass() == "weapon_smg2" then
	vecCone = Vector(-0.07,-0.07,-0.07)
	elseif wep:GetClass() == "weapon_ar1" then
	vecCone = Vector(-0.07,-0.07,0)
	elseif wep:GetClass() == "weapon_bsmg1" then
	vecCone = Vector(-0.04362,-0.04362,-0.04362)
	elseif wep:GetClass() == "mill_deagle" then
	vecCone = Vector(-0.5,-0.5,-0.5)
	elseif wep:GetClass() == "weapon_para" then
	vecCone = Vector(-0.05,-0.05,0)
	elseif wep:GetClass() == "awp" then
	vecCone = Vector(-0.05,-0.05,0) * LocalPlayer():GetActiveWeapon().xhair.loss
	if LocalPlayer():Crouching() then
	vecCone = vecCone * .95
	end
	if !LocalPlayer():IsOnGround() then
	vecCone = vecCone * 20
	end
	elseif wep:GetClass() == "g3sg1" then
	vecCone = Vector(-0.015,-0.015,0) * LocalPlayer():GetActiveWeapon().xhair.loss
	if LocalPlayer():Crouching() then
	vecCone = vecCone * .95
	end
	if !LocalPlayer():IsOnGround() then
	vecCone = vecCone * 20
	end
	elseif wep:GetClass() == "scout" then
	vecCone = Vector(-0.05,-0.05,0) * LocalPlayer():GetActiveWeapon().xhair.loss
	if LocalPlayer():Crouching() then
	vecCone = vecCone * .95
	end
	if !LocalPlayer():IsOnGround() then
	vecCone = vecCone * 20
	end
	elseif wep:GetClass() == "sg550" then
	vecCone = Vector(-0.004,-0.004,0) * LocalPlayer():GetActiveWeapon().xhair.loss
	if LocalPlayer():Crouching() then
	vecCone = vecCone * .95
	end
	if !LocalPlayer():IsOnGround() then
	vecCone = vecCone * 20
	end
	end
	if silencer then
	vecCone = vecCone * 1.5
	end
    return manipshot(currentseed or 0, (aimAngle or CL:GetAimVector():Angle()):Forward(), vecCone):Angle()
end
else
print("cant find dec0")
PredictSpread = function(cmd,aimAngle)
return aimAngle
end
end
local timerruns = 1
local silencer = false
local function DrawCursor(posx,posy) 
    local w = posx; 
    local h = posy; 
	local u = LocalPlayer():GetCurrentCommand( )
	if (input.IsMouseDown(MOUSE_LEFT)) then
	surface.SetDrawColor(0,255,0,255)
	else
	surface.SetDrawColor(255,0,0,255)
	end
	surface.DrawLine(w,h,w+10,h+5)
	surface.DrawLine(w,h,w,h+10)
	surface.DrawLine(w+10,h+5,w,h+10)
end 
local function unhookz()
	hook.Remove( "CalcView","lol" )
	hook.Remove( "CreateMove","aim")
	hook.Remove("HUDPaint","drawstate")
	hook.Remove("HUDPaint","drwradar")
	hook.Remove("Think","toggleit")
	print("Unloaded Hooks")
	timerruns = 0
end
local trfind

local view = Angle( 0, 0, 0 )
local spreadvector = Angle(0,0,0)
local mpos = Angle(0,0,0)
local ply = LocalPlayer()
local stop = 0xFFFF - IN_JUMP
local enabled = false
local function get(a,b)
return (a:Distance(b)/100)
end
local function checkteam(pl)
return true
end
local function HeadPos(ply) 
    if ValidEntity(ply) then 
if (ply:GetClass()=="npc_tripmine") && (ply:GetClass()=="npc_satchel") && (ply:GetClass()=="npc_grenade_frag") then
return false
end
	local bone = (aimmodels[ ply:GetModel() ] or "ValveBiped.Bip01_Head1")
	local hbone = ply:LookupBone(bone) 
        return ply:GetBonePosition(hbone) 
    else return end 
end
local function Visible(ply) 
    local trace = {start = LocalPlayer():GetShootPos(),endpos = HeadPos(ply),filter = {LocalPlayer(), ply}} 
    local tr = util.TraceLine(trace) 
    if tr.Fraction == 1 then 
        return true 
    else 
        return false 
    end     
end
local function validtarget(entz)
if !ValidEntity(entz) then return false end
if !(entz:IsPlayer() or entz:IsNPC()) then return false end
if entz == LocalPlayer() then return false end
if !Visible(entz) then return false end
if entz:IsNPC() then 
if entz.IsDead == true then
return false
end
if entz:GetMoveType() == MOVETYPE_NONE then return false end
if entz:IsPlayer() then if entz:Health() < 1 then return false end end
if entz:IsPlayer() then if !checkteam(entz) then return false end end
if entz:IsNPC() then if entz.IsDead == true then return false end end
if entz:GetMoveType() == MOVETYPE_NONE then return false end
return true
end
end
aimmodels = {
        ["models/combine_scanner.mdl"] = "Scanner.Body",
        ["models/hunter.mdl"] = "MiniStrider.body_joint",
        ["models/combine_turrets/floor_turret.mdl"] = "Barrel",
        ["models/dog.mdl"] = "Dog_Model.Eye",
        ["models/antlion.mdl"] = "Antlion.Body_Bone",
        ["models/antlion_guard.mdl"] = "Antlion_Guard.Body",
        ["models/antlion_worker.mdl"] = "Antlion.Head_Bone",
        ["models/zombie/fast_torso.mdl"] = "ValveBiped.HC_BodyCube",
        ["models/zombie/fast.mdl"] = "ValveBiped.HC_BodyCube",
        ["models/headcrabclassic.mdl"] = "HeadcrabClassic.SpineControl",
        ["models/headcrabblack.mdl"] = "HCBlack.body",
        ["models/headcrab.mdl"] = "HCFast.body",
        ["models/zombie/poison.mdl"] = "ValveBiped.Headcrab_Cube1",
        ["models/zombie/classic.mdl"] = "ValveBiped.HC_Body_Bone",
        ["models/zombie/classic_torso.mdl"] = "ValveBiped.HC_Body_Bone",
        ["models/zombie/zombie_soldier.mdl"] = "ValveBiped.HC_Body_Bone",
        ["models/combine_strider.mdl"] = "Combine_Strider.Body_Bone",
        ["models/lamarr.mdl"] = "HeadcrabClassic.SpineControl"
}

local cppweaps = {}
cppweaps["weapon_357"] = true
cppweaps["weapon_smg1"] = true
cppweaps["weapon_ar2"] = true
cppweaps["weapon_shotgun"] = true
cppweaps["weapon_pistol"] = true
cppweaps["weapon_crossbow"] = true
cppweaps["weapon_rpg"] = true
local cppweapsrec = {}
cppweapsrec["weapon_357"] = 0.8
cppweapsrec["weapon_smg1"] = 1
cppweapsrec["weapon_ar2"] = 1.03
cppweapsrec["weapon_shotgun"] = 1
cppweapsrec["weapon_pistol"] = 1
cppweapsrec["weapon_crossbow"] = 1
local function anglepunch()
if (!(LocalPlayer():GetActiveWeapon() == nil) && ValidEntity(ply:GetActiveWeapon())) then
if cppweaps[LocalPlayer():GetActiveWeapon():GetClass()] then
return (((LocalPlayer():GetPunchAngle( )) or Angle(0,0,0))*(cppweapsrec[LocalPlayer():GetActiveWeapon():GetClass()] or 0.8))
else
return Angle(0,0,0)
end
else
return Angle(0,0,0)
end
end
function calcnorec( u )
		local ply = LocalPlayer()
		if LocalPlayer():Alive() then
		local ply = LocalPlayer()
		if enabled then
		local mouseget = Angle(u:GetMouseY() * (GetConVarNumber("m_pitch")*10), u:GetMouseX() * (GetConVarNumber("m_yaw")*10),0) or Angle(0,0,0)
        mpos = mpos + mouseget
	
		mpos.p = math.Clamp(mpos.p,0,ScrH())
		mpos.y = math.Clamp(mpos.y,0,ScrW())
		if (input.IsMouseDown(MOUSE_LEFT)) then
		if u:GetButtons() & IN_ATTACK > 0 then
		u:SetButtons( 0 )
		end
		--if (mpos.y >= rdrpos.y && mpos.p >= rdrpos.p && mpos.y <= (rdrpos.y+200) && mpos.p <= (rdrpos.p+16)) then
		local x = (ScrW()/2)-(255/2)+10
		if (mpos.y >= x && mpos.p >= 5 && mpos.y <= x+10 && mpos.p <= 15) then
		unhookz()
		end
		end
		return
		end
		end
		local ply = LocalPlayer()
		if LocalPlayer():Alive() then
		--local mouse = Angle(u:GetMouseY() * GetConVarNumber("m_pitch"), u:GetMouseX() * -GetConVarNumber("m_yaw"),0) or Angle(0,0,0)
       -- correctView = correctView + mouse
		--correctView.p = math.NormalizeAngle( correctView.p )
		--correctView.y = math.NormalizeAngle( correctView.y )
		--view = correctView
		--view.p = math.NormalizeAngle( view.p )
		--view.y = math.NormalizeAngle( view.y )
		--spreadvector = PredictSpread(u,correctView)
	--	if (u:GetButtons() & IN_ATTACK > 0) then
	--	if ( ply:GetActiveWeapon():Clip1() >= 1 ) then
	--	view = PredictSpread(u,view)
	--	end
	--	end
		end
end
local function fovcheck()
			local u = LocalPlayer():GetCurrentCommand()
			local s, e = LocalPlayer():GetShootPos(), PredictSpread(u,LocalPlayer():EyeAngles()-anglepunch()):Forward()
			local t = {}
			t.start = s
			t.endpos = s + (e * 16384)
			t.filter = { LocalPlayer() }
local Target = util.TraceLine(t)
if LocalPlayer():Alive() and LocalPlayer():GetActiveWeapon():IsValid() then
if Target.Entity:IsNPC() then
return true 
end
if Target.Entity:IsPlayer() and Target.Entity:Alive() then
return true
end
end
end
local function shoot()
		if fovcheck() then

		end
end
hook.Add("Think","trigga",shoot)
--function NoRecoil( u, o )
		--if enable then
	--	local ply = LocalPlayer()
	--	return { origin = o, angles = correctView }
		--end
--end
--hook.Add( "CreateMove","aim", calcnorec )
--hook.Add( "CalcView","lol", NoRecoil )
 
hook.Add("Think","toggleit",toggle)

function DrawESP() 

end
hook.Add("HUDPaint","drawstate",DrawESP)

function GetCoordiantes(ent)
    local min,max = ent:OBBMins(),ent:OBBMaxs()
    local corners = {
        Vector(min.x,min.y,min.z),
        Vector(min.x,min.y,max.z),
        Vector(min.x,max.y,min.z),
        Vector(min.x,max.y,max.z),
        Vector(max.x,min.y,min.z),
        Vector(max.x,min.y,max.z),
        Vector(max.x,max.y,min.z),
        Vector(max.x,max.y,max.z)
    }

    local minx,miny,maxx,maxy = ScrW() * 2,ScrH() * 2,0,0
    for _,corner in pairs(corners) do
        local screen = ent:LocalToWorld(corner):ToScreen()
        minx,miny = math.min(minx,screen.x),math.min(miny,screen.y)
        maxx,maxy = math.max(maxx,screen.x),math.max(maxy,screen.y)
    end
    return minx,miny,maxx,maxy
end

function DrawPl(ent,clorred,clorgreen)
cam.Start2D()
render.SuppressEngineLighting( true )
render.SetColorModulation( clorred,clorgreen,0 )
ent:DrawModel()
render.SuppressEngineLighting( false )
cam.End2D()
end
hitladar = {}
hitladar.enabled = 1
function round(num, idp)
  local mult = 10^(idp or 0)
  return math.floor(num * mult + 0.5) / mult
end
function Visible(ply)
local trace = {start = LocalPlayer():GetShootPos(),endpos = ply:GetBonePosition( ply:LookupBone( "ValveBiped.Bip01_Head1" ) ),filter = {LocalPlayer(), ply}}
local tr = util.TraceLine(trace)
if tr.Fraction == 1 then
return true
else
return false
end
end
hook.Add("HUDPaint","drwradar",function()
if hitladar.enabled == 1 then
for k, kps in pairs(ents.FindByClass("sent_keypad")) do
local targetpos = kps:GetPos()
allmineposition = kps:GetPos() + kps:OBBCenter()
allmineposition = allmineposition:ToScreen()
local x = allmineposition.x
local y = allmineposition.y
if Visible(kps) then
surface.SetDrawColor( 255,0,0,255 )
surface.SetTextColor( 255,0,0,255 )
else
surface.SetDrawColor( 0,255,0,255 )
surface.SetTextColor( 0,255,0,255 )
end
surface.SetFont("TabLarge")
surface.SetTextPos(x+10,y-15)
if kps.Password then
surface.DrawText("Password: "..kps.Password)
end
surface.DrawLine( x-10, y-10, x-5, y-5 )
surface.DrawLine( x+10, y+10, x+5, y+5 )
surface.DrawLine( x-10, y+10, x-5, y+5 )
surface.DrawLine( x+10, y-10, x+5, y-5 )
end
for k, kps in pairs(ents.FindByClass("npc_*")) do
local targetpos = kps:GetPos()
allmineposition = kps:GetPos() + kps:OBBCenter()
allmineposition = allmineposition:ToScreen()
if Visible(kps) then
surface.SetDrawColor( 255,0,0,255 )
        local x1,y1,x2,y2 = GetCoordiantes(kps)
        local edgesize = 5
        
        -- Top left.
        surface.DrawLine(x1,y1,math.min(x1 + edgesize,x2),y1)
        surface.DrawLine(x1,y1,x1,math.min(y1 + edgesize,y2))

        -- Top right.
        surface.DrawLine(x2,y1,math.max(x2 - edgesize,x1),y1)
        surface.DrawLine(x2,y1,x2,math.min(y1 + edgesize,y2))

        -- Bottom left.
        surface.DrawLine(x1,y2,math.min(x1 + edgesize,x2),y2)
        surface.DrawLine(x1,y2,x1,math.max(y2 - edgesize,y1))

        -- Bottom right.
        surface.DrawLine(x2,y2,math.max(x2 - edgesize,x1),y2)
        surface.DrawLine(x2,y2,x2,math.max(y2 - edgesize,y1))
else
surface.SetDrawColor( 0,255,0,255 )
        local x1,y1,x2,y2 = GetCoordiantes(kps)
        local edgesize = 5
        
        -- Top left.
        surface.DrawLine(x1,y1,math.min(x1 + edgesize,x2),y1)
        surface.DrawLine(x1,y1,x1,math.min(y1 + edgesize,y2))

        -- Top right.
        surface.DrawLine(x2,y1,math.max(x2 - edgesize,x1),y1)
        surface.DrawLine(x2,y1,x2,math.min(y1 + edgesize,y2))

        -- Bottom left.
        surface.DrawLine(x1,y2,math.min(x1 + edgesize,x2),y2)
        surface.DrawLine(x1,y2,x1,math.max(y2 - edgesize,y1))

        -- Bottom right.
        surface.DrawLine(x2,y2,math.max(x2 - edgesize,x1),y2)
        surface.DrawLine(x2,y2,x2,math.max(y2 - edgesize,y1))
end
for k, kps in pairs(player.GetAll()) do
local targetpos = kps:GetPos()
allmineposition = kps:GetPos() + kps:OBBCenter()
allmineposition = allmineposition:ToScreen()
if Visible(kps) then
surface.SetDrawColor( 255,0,0,255 )
        local x1,y1,x2,y2 = GetCoordiantes(kps)
        local edgesize = 5
        
        -- Top left.
        surface.DrawLine(x1,y1,math.min(x1 + edgesize,x2),y1)
        surface.DrawLine(x1,y1,x1,math.min(y1 + edgesize,y2))

        -- Top right.
        surface.DrawLine(x2,y1,math.max(x2 - edgesize,x1),y1)
        surface.DrawLine(x2,y1,x2,math.min(y1 + edgesize,y2))

        -- Bottom left.
        surface.DrawLine(x1,y2,math.min(x1 + edgesize,x2),y2)
        surface.DrawLine(x1,y2,x1,math.max(y2 - edgesize,y1))

        -- Bottom right.
        surface.DrawLine(x2,y2,math.max(x2 - edgesize,x1),y2)
        surface.DrawLine(x2,y2,x2,math.max(y2 - edgesize,y1))
else
surface.SetDrawColor( 0,255,0,255 )
        local x1,y1,x2,y2 = GetCoordiantes(kps)
        local edgesize = 5
        
        -- Top left.
        surface.DrawLine(x1,y1,math.min(x1 + edgesize,x2),y1)
        surface.DrawLine(x1,y1,x1,math.min(y1 + edgesize,y2))

        -- Top right.
        surface.DrawLine(x2,y1,math.max(x2 - edgesize,x1),y1)
        surface.DrawLine(x2,y1,x2,math.min(y1 + edgesize,y2))

        -- Bottom left.
        surface.DrawLine(x1,y2,math.min(x1 + edgesize,x2),y2)
        surface.DrawLine(x1,y2,x1,math.max(y2 - edgesize,y1))

        -- Bottom right.
        surface.DrawLine(x2,y2,math.max(x2 - edgesize,x1),y2)
        surface.DrawLine(x2,y2,x2,math.max(y2 - edgesize,y1))
end
end
end
--[[local x = ScrW() / 2
local y = ScrH() / 2
	local pos = LocalPlayer():GetPos();
	local ang = LocalPlayer():GetAngles();
cam.Start3D( pos + ang:Forward() * 32 + ang:Up() * 8, ang )
surface.SetDrawColor( 0,150,255,100 )
surface.DrawRect(x-50,y-50,100,100)
surface.SetDrawColor( 255,0,0,200 )
surface.DrawOutlinedRect(x-50,y-50,100,100)
surface.DrawLine( x-40, y, x+40, y )
surface.DrawLine( x, y-40, x, y+40 )

surface.DrawLine( x+40, y+40, x+40, y )
surface.DrawLine( x-40, y-40, x-40, y )

surface.DrawLine( x+40, y-40, x, y-40 )
surface.DrawLine( x-40, y+40, x, y+40 )
cam.End3D()
]]--
local x = (ScrW()/2)-(255/2)+10
		local y = 5
		local calculate = 24/200
		for i=0,24 do
		surface.SetDrawColor( i/calculate, i/calculate, i/calculate, 200)
		surface.DrawLine( (ScrW()/2)-(255/2), i, (ScrW()/2)-(255/2)+254.5, i )
		end
		surface.SetDrawColor( 255, 255, 255, 200)
		surface.DrawLine( x, y, x+10, y+10 )
		surface.DrawLine( x, y+9, x+10, y-1 )
		surface.DrawOutlinedRect( x, y, 10, 10 ); 
		surface.DrawOutlinedRect( (ScrW()/2)-(255/2), 0, 255, 26 ); 
		surface.SetTextColor( 255, 255, 255, 200)
		surface.SetFont("Default")
		surface.SetTextPos(x+15,y)
		surface.DrawText("HITLADAR BY BB9")
		local x = (ScrW()/2)-(255/2)
local y = 25
	local calculate = 30/200
	local calculate2 = 30/200
		for i=0,30 do
		surface.SetDrawColor( 200-i/calculate, 200-i/calculate, 200-i/calculate, 200)
		surface.DrawLine( x, i+y, x+254.5, i+y )
		end
surface.SetDrawColor( 0, 0, 0, 200 ); 
surface.DrawRect( x, y+31, 255, 255-60 ); 
local y = 25+255-29
local calculate = 29/200
		for i=0,29 do
		surface.SetDrawColor( i/calculate, i/calculate, i/calculate, 200)
		surface.DrawLine( x, i+y, x+254.5, i+y )
		end
		surface.SetDrawColor( 255, 255, 255, 200)
		local y = 25
		surface.DrawOutlinedRect( x, y, 255, 255 ); 
local radar = {}
--Default values
radar.w = 255
radar.h = 255
radar.x = (ScrW()/2)-(255/2)
radar.y = 25
radar.alphascale = 0.6
radar.bgcolor = Color(255,0,0,255)
radar.fgcolor = Color(0,0,255,255)
radar.dangercolour = Color(220,0,0,255)
radar.dangerblipcolour = Color(255,255,0,255)
radar.screendetail = 64 -- Ooh, purty.
radar.screenrotation = 0
radar.hazardmode = true 	-- If the radar finds any hazardous ents in its radius, should it bitch about it?

radar.radius = 5000

radar.player_show = true
radar.player_color = Color(0,150,255,255)
surface.CreateFont("Arial",64,400,false,false,"RadarPlayerLabel")
radar.player_fontcolor = Color(255,255,255,255)
radar.player_showname = true
radar.player_showhealth = true
radar.player_showarmor = false --TO DO
radar.player_showammo = true


radar.scanfor = {"player", "blastfungus", "rpg_missile", "crossbow_bolt", "npc_", "sent_", "prop_vehicle_"}		-- What should the radar look for?  Accepts partial names.
radar.dangerous = {"sent_nuke_missile", "sent_nuke_detpack"}		-- What should the radar consider extremely hazardous? ("Hazard Mode")  Only accepts full names.

-- The danger table relies on the scan table, make sure your dangerous ent is in both tables.


------------------------------------------------------------------
-- Don't edit under here unless you're the trigonometry GOD. D: --
------------------------------------------------------------------


radar.bgcolorbak = radar.bgcolor
radar.fgcolorbak = radar.fgcolor
radar.player_colorbak = radar.player_color


local color_ascale = function(col,scale) return Color(col.r,col.g,col.b,col.a*scale) end

-- Without further ado, let's rock.

	local ETable = {}
	local PulseRadar = false

	local lpl = LocalPlayer()
	
	
	if ( radar.player_show ) then
	
	--draw.RoundedBox( radar.w/2, radar.x, radar.y, radar.w, radar.h, radar.bgcolor ) --Looks like shit
	local vertices = {}
	for i=1,radar.screendetail do
		local shift = math.fmod(CurTime()*radar.screenrotation,360)
		local sizescale = 1 --+ math.sin(CurTime())/10
		local tab = {}
		tab.x = radar.x+radar.w/2 + math.cos(math.Deg2Rad((360/radar.screendetail)*i+shift)) * radar.w/2 * sizescale
		tab.y = radar.y+radar.h/2 + math.sin(math.Deg2Rad((360/radar.screendetail)*i+shift)) * radar.h/2 * sizescale
		tab.u = 0
		tab.v = 0
		table.insert(vertices,tab)
	end
	surface.SetTexture(surface.GetTextureID("vgui/white"))
	surface.SetDrawColor(0,0,255,255)
    draw.RoundedBox( 0, radar.x+radar.w/2, radar.y, 1, radar.h, Color(255,255,255,255) )
	draw.RoundedBox( 0, radar.x, radar.y+radar.h/2, radar.w, 1, Color(255,255,255,255) )
	local players = {}

	for i = 1, 1000 do -- Because running a loop 1000 times per frame ensures major luls.  Also ents.GetInSphere is serverside. (which sucks major donkey balls.)

			local ent = ents.GetByIndex(i)

			if ent:IsValid() then
				local type = ent:GetClass()

				for k, v in ipairs(radar.scanfor) do
					if string.find(type,v) then
						table.insert(players,ent)
					end
				end
			end
		end

		for i, pl in ipairs(players) do
			local cx = radar.x+radar.w/2
			local cy = radar.y+radar.h/2
			local vdiff = pl:GetPos()-lpl:GetPos()


	-- Player Check.
			if true then
				if pl:IsPlayer() then
					if ( pl:Alive() and lpl~=pl ) then
						local px = (vdiff.x/radar.radius)
						local py = (vdiff.y/radar.radius)
						local z = math.sqrt( px*px + py*py )
						local phi = math.Deg2Rad( math.Rad2Deg( math.atan2( px, py ) ) - math.Rad2Deg( math.atan2( lpl:GetAimVector().x, lpl:GetAimVector().y ) ) - 90 )
						px = math.cos(phi)*z
						py = math.sin(phi)*z
						--draw.RoundedBox( 0, cx+px*radar.w/2-4, cy+py*radar.h/2-4, 8, 8, color_ascale(radar.player_color,255) )
						--surface.SetDrawColor( 0,0,0,255 )
						--surface.DrawOutlinedRect( cx+px*radar.w/2-4, cy+py*radar.h/2-4, 8, 8)
						local y = cy+py*radar.h/2
						local x = cx+px*radar.w/2
						local y = math.Clamp(y-4,0+radar.y,245+radar.y)
						local x = math.Clamp(x-4,0+radar.x,245+radar.x)
						if Visible(pl) then
						surface.SetDrawColor( 255,0,0,255 )
						else
						surface.SetDrawColor( 0,255,0,255 )
						end
						surface.DrawLine( x-4, y, x+4, y )
						surface.DrawLine( x, y-4, x, y+4 )
						
						surface.DrawLine( x+4, y+4, x+4, y )
						surface.DrawLine( x-4, y-4, x-4, y )
						
						surface.DrawLine( x+4, y-4, x, y-4 )
						surface.DrawLine( x-4, y+4, x, y+4 )
						if radar.player_showname then
							draw.DrawText(pl:Name(), "Default", cx+px*radar.w/2, cy+py*radar.h/2+8, color_ascale(radar.player_fontcolor,radar.alphascale), TEXT_ALIGN_CENTER)
						end
						if radar.player_showhealth then
							draw.RoundedBox( 0, cx+px*radar.w/2-12, cy+py*radar.h/2+20, (math.min(100,pl:Health())/100)*24, 4, Color(255,0,0,255) )
						end
						if radar.player_showammo then
							if (lpl:GetActiveWeapon().Clip1~=nil and lpl:GetActiveWeapon():Clip1() > 0) then
								draw.RoundedBox( 0, cx+px*radar.w/2-12, cy+py*radar.h/2+26, math.min(1,(lpl:GetAmmoCount(lpl:GetActiveWeapon():GetPrimaryAmmoType())/lpl:GetActiveWeapon():Clip1()))*24, 4, Color(255,200,0,255) ) --BUGGED?
							else
								draw.RoundedBox( 0, cx+px*radar.w/2-12, cy+py*radar.h/2+26, 24, 4, Color(255,200,0,255) )
							end
						end
					end
				end


	-- Ent Check.
				if ((not pl:IsPlayer()) and pl:IsValid() ) then

				    local isDangerous = false


				--Fill up the hazard mode table.
					if ( radar.hazardmode ) then
						for k,v in ipairs(radar.dangerous) do
						    if (pl:GetClass() == v) then
						        table.insert(ETable,pl)
						        isDangerous = true
							end
						end
					end
					
					local px = (vdiff.x/radar.radius)
					local py = (vdiff.y/radar.radius)
					local z = math.sqrt( px*px + py*py )
					local phi = math.Deg2Rad( math.Rad2Deg( math.atan2( px, py ) ) - math.Rad2Deg( math.atan2( lpl:GetAimVector().x, lpl:GetAimVector().y ) ) - 90 )
					px = math.cos(phi)*z
					py = math.sin(phi)*z

					if (isDangerous == false) then -- Leave this one for the hazard mode so we can give it a lovely coloured dot. Oh the frivolity.
						--draw.RoundedBox( 0, cx+px*radar.w/2-4, cy+py*radar.h/2-4, 8, 8, color_ascale(radar.player_color,255) )
						--surface.SetDrawColor( 0,0,0,255 )
						--surface.DrawOutlinedRect( cx+px*radar.w/2-4, cy+py*radar.h/2-4, 8, 8)
						local y = cy+py*radar.h/2
						local x = cx+px*radar.w/2
						local y = math.Clamp(y-4,0+radar.y,245+radar.y)
						local x = math.Clamp(x-4,0+radar.x,245+radar.x)
						if Visible(pl) then
						surface.SetDrawColor( 255,0,0,255 )
						else
						surface.SetDrawColor( 0,255,0,255 )
						end
						surface.DrawLine( x-4, y, x+4, y )
						surface.DrawLine( x, y-4, x, y+4 )
						
						surface.DrawLine( x+4, y+4, x+4, y )
						surface.DrawLine( x-4, y-4, x-4, y )
						
						surface.DrawLine( x+4, y-4, x, y-4 )
						surface.DrawLine( x-4, y+4, x, y+4 )
					end


					if radar.player_showname then

					--Let's do some name parsing! Whoooo... god dammit.
				
					--To add an extra name parsing thingamajobby, copy/paste one of the elseifs,
					--change the string, count the number of letters, add one, and use that as the last number.

						local nametag = ""
						if string.find(pl:GetClass(),"blastfungus") then nametag = "" -- There will usually be so many of these that adding names will look messy.
						elseif string.find(pl:GetClass(),"npc_") then nametag = string.sub(pl:GetClass(),5)
						elseif string.find(pl:GetClass(),"sent_") then nametag = string.sub(pl:GetClass(),6)
						elseif string.find(pl:GetClass(),"prop_vehicle_") then nametag = string.sub(pl:GetClass(),14)
						else nametag = pl:GetClass()
						end

						local nametable = string.Explode("_",nametag)
						nametag = table.concat(nametable," ")
						local nametag1 = string.sub(nametag,0,1)
						local nametag2 = string.sub(nametag,2)
						nametag1 = string.upper(nametag1)
						nametag = nametag1..nametag2


					end
				end
   			end
	 	end
	 	

   -- Hazard Mode.
   -- This is where things get hacky.  Well, more hacky.
   
   		local count = table.Count(ETable)
   		
   		if ( count > 0 ) then 	-- Oooooh shit.
   		for k,pl in ipairs(ETable) do
   			local cx = radar.x+radar.w/2
			local cy = radar.y+radar.h/2
			local vdiff = pl:GetPos()-lpl:GetPos()
			
   			local px = (vdiff.x/radar.radius)
			local py = (vdiff.y/radar.radius)
			local z = math.sqrt( px*px + py*py )
			local phi = math.Deg2Rad( math.Rad2Deg( math.atan2( px, py ) ) - math.Rad2Deg( math.atan2( lpl:GetAimVector().x, lpl:GetAimVector().y ) ) - 90 )
			px = math.cos(phi)*z
			py = math.sin(phi)*z
						local y = cy+py*radar.h/2
						local x = cx+px*radar.w/2
						local y = math.Clamp(y-4,0+radar.y,245+radar.y)
						local x = math.Clamp(x-4,0+radar.x,245+radar.x)
			--draw.RoundedBox( 0, (cx+px*radar.w/2-8), (cy+py*radar.h/2-8), 16, 16, color_ascale(radar.dangerblipcolour,255) )
			--surface.SetDrawColor( 0,0,0,255 )
			--surface.DrawOutlinedRect( cx+px*radar.w/2-4, cy+py*radar.h/2-4, 8, 8)
			if Visible(pl) then
			surface.SetDrawColor( 255,0,0,255 )
			else
			surface.SetDrawColor( 0,100,255,255 )
			end
			surface.DrawLine( x-5, y, x+5, y )
			surface.DrawLine( x, y-5, x, y+5 )
			surface.DrawLine( x+5, y+5, x+5, y )
			surface.DrawLine( x-5, y-5, x-5, y )	
			surface.DrawLine( x+5, y-5, x, y-5 )
			surface.DrawLine( x-5, y+5, x, y+5 )
		end
			
			radar.bgcolor = Color(255,255,255,0)
			radar.fgcolor = Color(60,60,60,100)
			
			PulseRadar = true
			
			
 			
		end
	end
	end
	if enabled then
DrawCursor(mpos.y,mpos.p) 
end
	end)
	local function keyz()
if timerruns == 1 then
timer.Simple(0.1,function () keyz() end)
end
    if( input.IsKeyDown( KEY_INSERT ) ) then
	if enabled then
	enabled = false
	else
	enabled = true
	local u = LocalPlayer():GetCurrentCommand()
	correctView = (u:GetViewAngles())
	end
	end
	if( input.IsKeyDown( KEY_F12 ) ) then
	silencer = !silencer
	LocalPlayer():ChatPrint("[Hitladar 0.2] Switched silencer mode "..tostring(silencer))
	end
	if( input.IsKeyDown( KEY_DELETE ) ) then
	unhookz()
	timerruns = 0
	end
	end
keyz()