--[[
	Erf.lua
	Erfie - New Phone :D | (STEAM_0:0:11602053)
	===DStream===
]]

---Erf Config---
local ErfXCvar = CreateClientConVar("Erf_Xhair", 0, true, false)
local ErfWeaponDraw = CreateClientConVar("Erf_WeaponDraw", 0, true, false)
local ErfBhopCvar = CreateClientConVar("Erf_Bhop" , 0, true , false)
local ErfAntiGag = CreateClientConVar("Erf_AntiGag", 0, true, false)
local ErfNPCEsp = CreateClientConVar("Erf_NPCEsp", 0, true, false)
local ErfNadeEsp = CreateClientConVar("Erf_NadeEsp", 0, true, false)
local ErfCombineEsp = CreateClientConVar("Erf_CombineEsp", 0, true, false)
local ErfCrossbowEsp = CreateClientConVar("Erf_CrossbowEsp", 0, true, false)
local ErfRpgESP = CreateClientConVar("Erf_RpgEsp", 0, true, false)
local ErfExtraESP = CreateClientConVar("Erf_EspExtra", 0, true, false)
local ErfDrawLaser = CreateClientConVar("Erf_Laser", 0, true, false)
local ErfEspBox = CreateClientConVar("Erf_EspBox", 0, true, false)
local ErfNoRecoil = CreateClientConVar("Erf_NoRecoil", 0, true, false)
local ErfKeyPad = CreateClientConVar("Erf_KeyPad", 0, true, false)
local ErfWallZ = CreateClientConVar("Erf_Wallhack", 0, true, false)
local ErfWeaponEsp = CreateClientConVar("Erf_WeaponEsp", 0, true, false)
local ErfNPCBox = CreateClientConVar("Erf_NpcEspBox", 0, true, false)
local ErfE2ESP = CreateClientConVar("Erf_E2Esp", 0, true, false)
local ErfSpec = CreateClientConVar("Erf_Spec", 0, true, false)
local ErfSkeleton = CreateClientConVar("Erf_Skeleton", 0, true, false)
local ErfAniXHair = CreateClientConVar("Erf_AniXHair", 0, true, false)
local ErfNewEspBase = CreateClientConVar("Erf_NewEsp", 0, true, false)
local ErfNewEspAdmin = CreateClientConVar("Erf_NewEspShowAdmin", 0, true, false)
local ErfNewEspHP = CreateClientConVar("Erf_NewEspHp", 0, true, false)
local ErfNewEspFriends = CreateClientConVar("Erf_NewEspShowFriend", 0, true, false)
CreateClientConVar( "Erf_NewEspAlpha", 150, false, false)
---------------

--Localising Vars--
ErfBot = {}

local ErfBotCon = GetConVarNumber


--Customized funcs--
function ErfBot.DrawWB(x,y,text,color)

return draw.WordBox(0, x, y, text, "Default", color, Color(255,255,255,255))
	
end


---TeamColor Function---
function getColor(ply)
if(ply:GetFriendStatus() == "friend") then
Colour = Color(255,255,255,255)
else
Colour =  team.GetColor(ply:Team())
end
return Colour
end

---------------------------------------

---XRay---
local sndOn = Sound( "items/nvg_on.wav" )
local sndOff = Sound( "items/nvg_off.wav" )

local XRayOn = true

local pairs = pairs
local string = string
local render = render
local LocalPlayer = LocalPlayer 


local function XRayMat()
for k,v in pairs( ents.GetAll() ) do
	
if ValidEntity(v) and (v:GetClass() == "prop_physics") then
		
v:SetMaterial("MaterialsForHax/hax")
v:SetColor(0,150,0,130)
end
end
end	



local function XRayToggle()
 
if XRayOn then --
		
hook.Remove( "RenderScene", "XRay_ApplyMats" )
hook.Remove( "RenderScreenspaceEffects", "XRay_RenderModify" )
	
XRayOn = false --
surface.PlaySound( sndOff )
		

for k,v in pairs( ents.GetAll() ) do
if ValidEntity(v) and (v:GetClass() == "prop_physics") then
				
v:SetMaterial("")
v:SetColor(255,255,255,255)
		
end
end
		
else
	
hook.Add( "RenderScene", "XRay_ApplyMats", XRayMat )

	
XRayOn = true --
surface.PlaySound( sndOn )

end
 
end
concommand.Add( "Erf_Xray",XRayToggle)




---MoarShitzz--
function DrawMoarXHair()
if ErfAniXHair:GetBool() then

local xx = ScrW()/2
local yy = ScrH()/2

surface.DrawCircle( xx, yy, math.sin( CurTime() * 0.5 ) * 15, Color(NumSliderRed:GetValue(),NumSliderGreen:GetValue(),NumSliderBlue:GetValue(),255))
end
end
hook.Add("HUDPaint","Lolzzz",DrawMoarXHair)

---Skeleton---
local skeleton = {
	// Main body
	
	{ S = "ValveBiped.Bip01_Head1", E = "ValveBiped.Bip01_Neck1" },
	{ S = "ValveBiped.Bip01_Neck1", E = "ValveBiped.Bip01_Spine4" },
	{ S = "ValveBiped.Bip01_Spine4", E = "ValveBiped.Bip01_Spine2" },
	{ S = "ValveBiped.Bip01_Spine2", E = "ValveBiped.Bip01_Spine1" },
	{ S = "ValveBiped.Bip01_Spine1", E = "ValveBiped.Bip01_Spine" },
	{ S = "ValveBiped.Bip01_Spine", E = "ValveBiped.Bip01_Pelvis" },
	
	// Left Arm
	{ S = "ValveBiped.Bip01_Spine4", E = "ValveBiped.Bip01_L_UpperArm" },
	{ S = "ValveBiped.Bip01_L_UpperArm", E = "ValveBiped.Bip01_L_Forearm" },
	{ S = "ValveBiped.Bip01_L_Forearm", E = "ValveBiped.Bip01_L_Hand" },
	
	// Right Arm
	{ S = "ValveBiped.Bip01_Spine4", E = "ValveBiped.Bip01_R_UpperArm" },
	{ S = "ValveBiped.Bip01_R_UpperArm", E = "ValveBiped.Bip01_R_Forearm" },
	{ S = "ValveBiped.Bip01_R_Forearm", E = "ValveBiped.Bip01_R_Hand" },
	
	// Left leg
	{ S = "ValveBiped.Bip01_Pelvis", E = "ValveBiped.Bip01_L_Thigh" },
	{ S = "ValveBiped.Bip01_L_Thigh", E = "ValveBiped.Bip01_L_Calf" },
	{ S = "ValveBiped.Bip01_L_Calf", E = "ValveBiped.Bip01_L_Foot" },
	{ S = "ValveBiped.Bip01_L_Foot", E = "ValveBiped.Bip01_L_Toe0" },
	
	// Right leg
	{ S = "ValveBiped.Bip01_Pelvis", E = "ValveBiped.Bip01_R_Thigh" },
	{ S = "ValveBiped.Bip01_R_Thigh", E = "ValveBiped.Bip01_R_Calf" },
	{ S = "ValveBiped.Bip01_R_Calf", E = "ValveBiped.Bip01_R_Foot" },
	{ S = "ValveBiped.Bip01_R_Foot", E = "ValveBiped.Bip01_R_Toe0" },
}
local function Skeleton(e)	
	if ErfSkeleton:GetBool() then
	if !e:Alive() then return end
	for k, v in pairs( skeleton ) do
		local sPos, ePos = e:GetBonePosition( e:LookupBone( v.S ) ):ToScreen(), e:GetBonePosition( e:LookupBone( v.E ) ):ToScreen()
		
		surface.SetDrawColor(getColor(e))
		--surface.SetDrawColor(SkeleSliderRed:GetValue(), SkeleSliderGreen:GetValue(), SkeleSliderBlue:GetValue(), 255 )
		surface.DrawLine( sPos.x, sPos.y, ePos.x, ePos.y )
	end
end
end
hook.Add("HUDPaint", "SkeletonESP", function()
	for k,v in pairs(player.GetAll()) do
				if(v!=LocalPlayer()) then
		       Skeleton(v)
            end
		end
end)


---Spec---


function Spec()
if ErfSpec:GetBool() then

            local spectatePlayers = {}
            local x = 0
            for k,v in pairs(player.GetAll()) do
                    if v:GetObserverTarget() == LocalPlayer() then
                            table.insert(spectatePlayers, v:Name())
                    end
            end
            local textLength = surface.GetTextSize(table.concat(spectatePlayers) ) / 3
            draw.RoundedBox(1, ScrW() - 180, ScrH() - ScrH() + 15, 150, 30 + textLength, Color(0,0,0,150))
            draw.SimpleText("Spectators", "ScoreboardText", ScrW() - 140, ScrH() - ScrH() + 17, Color(0, 0, 0, 150))
            draw.SimpleText("Spectators", "ScoreboardText", ScrW() - 140, ScrH() - ScrH() + 16, Color(255, 255, 255, 255))
     
            for k, v in pairs(spectatePlayers) do
            draw.SimpleText(v, "ScoreboardText", ScrW() - 140, ScrH() - ScrH() + 35 + x, Color(255, 255, 255, 255))
            x = x + 15
        end
    end
	end
hook.Add("HUDPaint", "Spec's", Spec)


---E2 ESP---
function E2ESP()
if ErfE2ESP:GetBool() then
for k,v in pairs(ents.GetAll()) do
if v:GetClass() == "gmod_wire_expression2" then

E2Pos = v:EyePos():ToScreen()

draw.SimpleText("E2","CV20" , E2Pos.x, E2Pos.y, Color(EspSliderRed:GetValue(),EspSliderGreen:GetValue(),EspSliderBlue:GetValue()),TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)

end
end
end
end
hook.Add("HUDPaint","E2 ESP",E2ESP)


---ShoulderView---
local Enabled = false

function ShoulderView()

Enabled = not Enabled

if(Enabled) then

hook.Add("CalcView","ShoulderView",ShoulderView)
hook.Add("ShouldDrawLocalPlayer","ShouldDrawLocalPlayer",DrawLocalPlayer)

else

hook.Remove("CalcView","ShoulderView")
hook.Remove("ShouldDrawLocalPlayer","ShouldDrawLocalPlayer")

end

end
concommand.Add("Erf_View",ShoulderView)

function ShoulderView(ply,pos,angles,fov)

if (Enabled) then

local view = {}

view.origin = pos - (angles:Forward()*anglesForward:GetValue()) + (angles:Right()*anglesSite:GetValue()) + (angles:Up()*anglesUpDown:GetValue())

view.angles = angles

view.fov = fov

return view
	
end

end

function DrawLocalPlayer(ply)
if (Enabled) then

return true

else

return false

end

end


---NPCBox---
function ThisIsNPCBox()
if ErfNPCBox:GetBool() then
for k,v in pairs(ents.GetAll()) do
if v:IsNPC() then

local ang = math.Deg2Rad((LocalPlayer():GetPos()-v:GetPos()):Angle().y)
local sin = math.sin(ang)
local cos = math.cos(ang)

local topleft = (v:GetPos() - Vector(-sin*v:OBBMaxs().x,cos*v:OBBMaxs().y,-v:OBBMaxs().z)):ToScreen()
local bottomright = (v:GetPos() + Vector(-sin*v:OBBMaxs().x,cos*v:OBBMaxs().y,0)):ToScreen()



if(v:GetClass() == "npc_crow") then
topleft = (v:GetPos() - Vector(-sin*v:OBBMaxs().x,cos*v:OBBMaxs().y,-v:OBBMaxs().z/2)):ToScreen()
bottomright = (v:GetPos() + Vector(-sin*v:OBBMaxs().x,cos*v:OBBMaxs().y,-v:OBBMaxs().z/10)):ToScreen()
else
topleft = (v:GetPos() - Vector(-sin*v:OBBMaxs().x,cos*v:OBBMaxs().y,-v:OBBMaxs().z)):ToScreen()
bottomright = (v:GetPos() + Vector(-sin*v:OBBMaxs().x,cos*v:OBBMaxs().y,0)):ToScreen()
end

surface.SetDrawColor(EspSliderRed:GetValue(),EspSliderGreen:GetValue(),EspSliderBlue:GetValue(),255)
surface.DrawOutlinedRect( topleft.x, topleft.y, bottomright.x-topleft.x , bottomright.y-topleft.y )
end
end
end
end
hook.Add("HUDPaint","NPC ESP BOX",ThisIsNPCBox)
----


---WeaponsEsp---
function WeaponEsp()
if ErfWeaponEsp:GetBool() then
for k, v in pairs(ents.GetAll()) do 
if ValidEntity(v) then
if v:IsWeapon() && v:GetMoveType() != 0 then
if string.sub(v:GetClass(),1 ,7) == "weapon_" then 

WeaPos = v:EyePos():ToScreen()

draw.SimpleText(v:GetClass() ,"CV20" , WeaPos.x, WeaPos.y, Color(EspSliderRed:GetValue(),EspSliderGreen:GetValue(),EspSliderBlue:GetValue()),TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)

end
end
end
end
end
end
hook.Add("HUDPaint","WeaponEsp",WeaponEsp)

---PeepsWallZ---
function Wallz()
if ErfWallZ:GetBool() then
for k, v in pairs(ents.GetAll()) do 
if ValidEntity(v) then
if v:IsPlayer() or v:IsNPC() then
v:SetMaterial("")
cam.Start3D(EyePos(), EyeAngles())
v:DrawModel()
cam.End3D()
end
end
end
end
end
hook.Add("HUDPaint","Wallhackz",Wallz)

---NoRecoilz--
function DerpNoRecoil()
if ErfNoRecoil:GetBool() then
if LocalPlayer():GetActiveWeapon().Primary then
LocalPlayer():GetActiveWeapon().Primary.Recoil = 0
end
end
end
hook.Add("Think", "No Recoilz",DerpNoRecoil) 


---Bhop----
function Bhop() 
if ErfBhopCvar:GetBool() then
if input.IsKeyDown( KEY_SPACE ) then
if LocalPlayer():IsOnGround() then
RunConsoleCommand("+Jump") 
timer.Create("Bhop",0.01, 0 ,function() RunConsoleCommand("-Jump") end)
end
end
end
end
hook.Add("Think", "LulBhop", Bhop)
---Bhop End---

---Anti Gag---
function AntiGag()
if ErfAntiGag:GetBool() then
if( ulx && ulx.gagUser ) then
ulx.gagUser( false )
end
end
end
---Anti Gag End---

---GetDistance---
function getDistance(ent)
local Distance = math.floor((LocalPlayer():GetPos() + LocalPlayer():OBBCenter()):Distance( ent:GetPos() + ent:OBBCenter()))
return Distance
end
---GetDistance End---


function ThisIsEspBox()
if ErfEspBox:GetBool() then
for k,v in pairs(player.GetAll()) do
if v:Alive() then
if(v!=LocalPlayer()) then

local ang = math.Deg2Rad((LocalPlayer():GetPos()-v:GetPos()):Angle().y)
local sin = math.sin(ang)
local cos = math.cos(ang)

local topleft = (v:GetPos() - Vector(-sin*v:OBBMaxs().x,cos*v:OBBMaxs().y,-v:OBBMaxs().z)):ToScreen()
local bottomright = (v:GetPos() + Vector(-sin*v:OBBMaxs().x,cos*v:OBBMaxs().y,0)):ToScreen()


if(v:InVehicle()) then
topleft = (v:GetPos() - Vector(-sin*v:OBBMaxs().x,cos*v:OBBMaxs().y,-v:OBBMaxs().z/2)):ToScreen()
bottomright = (v:GetPos() + Vector(-sin*v:OBBMaxs().x,cos*v:OBBMaxs().y,0)):ToScreen()
else
topleft = (v:GetPos() - Vector(-sin*v:OBBMaxs().x,cos*v:OBBMaxs().y,-v:OBBMaxs().z)):ToScreen()
bottomright = (v:GetPos() + Vector(-sin*v:OBBMaxs().x,cos*v:OBBMaxs().y,0)):ToScreen()
end

surface.SetDrawColor(getColor(v))
surface.DrawOutlinedRect( topleft.x, topleft.y, bottomright.x-topleft.x , bottomright.y-topleft.y )
end
end
end
end
end
hook.Add("HUDPaint","Box ESP",ThisIsEspBox)


function NPCESP()
if ErfNPCEsp:GetBool() then
for k,v in pairs(ents.GetAll()) do
if v:IsNPC() then
local NpcESPPos = (v:EyePos()):ToScreen()

draw.SimpleText(" "..v:GetClass(),"CV20",NpcESPPos.x, NpcESPPos.y, Color(255,255,255,255), TEXT_ALIGN_CENTER,TEXT_ALIGN_CENTER)

end
end
end
end
hook.Add("HUDPaint","NPC's ESP",NPCESP)


function NadeESP()
if ErfNadeEsp:GetBool() then
for k,v in pairs(ents.FindByClass("npc_grenade_frag")) do

local pos = (v:GetPos() + v:OBBCenter()):ToScreen()

surface.SetDrawColor(EspSliderRed:GetValue(),EspSliderGreen:GetValue(),EspSliderBlue:GetValue(),255)
surface.DrawOutlinedRect(pos.x-5, pos.y-5, 10 , 10)
surface.SetTextColor(EspSliderRed:GetValue(),EspSliderGreen:GetValue(),EspSliderBlue:GetValue(),255)
surface.SetTextPos(pos.x+10, pos.y-8) 
surface.SetFont("CV20")
surface.DrawText( "Grenade" )
end
end
end
hook.Add("HUDPaint","Nade ESP",NadeESP)


function CombineESP()
if ErfCombineEsp:GetBool() then
for k,v in pairs(ents.FindByClass("prop_combine_ball")) do

local pos = (v:GetPos() + v:OBBCenter()):ToScreen()

surface.SetDrawColor(EspSliderRed:GetValue(),EspSliderGreen:GetValue(),EspSliderBlue:GetValue(),255)
surface.DrawOutlinedRect(pos.x-5, pos.y-5, 10 , 10)
surface.SetTextColor(EspSliderRed:GetValue(),EspSliderGreen:GetValue(),EspSliderBlue:GetValue(),255)
surface.SetTextPos(pos.x+10, pos.y-8) 
surface.SetFont("CV20")
surface.DrawText( "Combine Ball" )
end
end
end
hook.Add("HUDPaint","Combine ESP",CombineESP)


function CrossbowboltESP()
if ErfCrossbowEsp:GetBool() then
for k,v in pairs(ents.FindByClass("crossbow_bolt")) do

local tracepos = v:GetPos() + v:OBBCenter()
local traceang = v:GetForward()
local tracedata = {}
tracedata.start = tracepos
tracedata.endpos = tracepos+(traceang*80000000000)
tracedata.filter = v
local trace = util.TraceLine(tracedata)

local pos = (v:GetPos() + v:OBBCenter()):ToScreen()
local tracehit = (trace.HitPos):ToScreen()

surface.SetDrawColor(EspSliderRed:GetValue(),EspSliderGreen:GetValue(),EspSliderBlue:GetValue(),255)
surface.DrawOutlinedRect( pos.x-5, pos.y-5, 10 , 10 )
surface.SetDrawColor(EspSliderRed:GetValue(),EspSliderGreen:GetValue(),EspSliderBlue:GetValue(),255)
surface.DrawLine(pos.x, pos.y, tracehit.x, tracehit.y)
surface.SetTextColor(EspSliderRed:GetValue(),EspSliderGreen:GetValue(),EspSliderBlue:GetValue(),255)
surface.SetTextPos( pos.x+10, pos.y-8 ) 
surface.SetFont("CV20")
surface.DrawText( "RPG Missile" )
end
end
end
hook.Add("HUDPaint","CrossbowboltESP",CrossbowboltESP)


function RpgESP()
if ErfRpgESP:GetBool() then
for k,v in pairs(ents.FindByClass("rpg_missile")) do

local tracepos = v:GetPos() + v:OBBCenter()
local traceang = v:GetForward()
local tracedata = {}
tracedata.start = tracepos
tracedata.endpos = tracepos+(traceang*80000000000)
tracedata.filter = v
local trace = util.TraceLine(tracedata)

local pos = (v:GetPos() + v:OBBCenter()):ToScreen()
local tracehit = (trace.HitPos):ToScreen()

surface.SetDrawColor(EspSliderRed:GetValue(),EspSliderGreen:GetValue(),EspSliderBlue:GetValue(),255)
surface.DrawOutlinedRect( pos.x-5, pos.y-5, 10 , 10 )
surface.SetDrawColor(EspSliderRed:GetValue(),EspSliderGreen:GetValue(),EspSliderBlue:GetValue(),255)
surface.DrawLine(pos.x, pos.y, tracehit.x, tracehit.y)
surface.SetTextColor(EspSliderRed:GetValue(),EspSliderGreen:GetValue(),EspSliderBlue:GetValue(),255)
surface.SetTextPos( pos.x+10, pos.y-8 ) 
surface.SetFont("CV20")
surface.DrawText( "RPG Missile" )
end
end
end
hook.Add("HUDPaint","RpgESP",RpgESP)


function ExtraESP()
if ErfExtraESP:GetBool() then
for k,v in pairs(player.GetAll())  do
if v:Alive() then
if(v!=LocalPlayer()) then

local PlayerSpot = v:EyePos():ToScreen()

surface.SetDrawColor(getColor(v))

draw.SimpleText("Props: "..v:GetCount("props") + v:GetCount("effects") + v:GetCount("ragdolls"), "CV20", PlayerSpot.x, PlayerSpot.y +35, Colour, TEXT_ALIGN_CENTER,TEXT_ALIGN_CENTER)

if(v:GetActiveWeapon()==NULL) then
draw.SimpleText("Weapon: None","CV20",PlayerSpot.x , PlayerSpot.y + 52, Colour, TEXT_ALIGN_CENTER,TEXT_ALIGN_CENTER)
else
draw.SimpleText("Weapon: "..v:GetActiveWeapon():GetPrintName(),"CV20",PlayerSpot.x, PlayerSpot.y + 52, Colour, TEXT_ALIGN_CENTER,TEXT_ALIGN_CENTER)

end
end
end
end
end
end
hook.Add("HUDPaint","ExtraESP",ExtraESP)


function DrawLaser()  
if ErfDrawLaser:GetBool() then 
for k,v in pairs(player.GetAll()) do
if (v!=LocalPlayer() and v:Alive() and v:IsPlayer()) then

cam.Start3D( EyePos() , EyeAngles())
render.SetMaterial( Material( "cable/physbeam" ) )
render.DrawBeam(v:GetBonePosition(v:LookupBone("ValveBiped.Bip01_Head1")) , v:GetEyeTrace().HitPos , 5, 0, 0, Color(255,255,255, 255 ))
cam.End3D()
end
end
end
end
hook.Add("HUDPaint","DrawLaser",DrawLaser)
------

---NewEsp---
function ErfBot.NameTags()
if ErfNewEspBase:GetBool() then
for k,v in pairs(player.GetAll()) do

if(v!=LocalPlayer()) then

LocalPlayer():GetViewModel():SetColor(255,255,255,NumSliderThingy:GetValue())

ErfBot.DrawWB(v:GetShootPos():ToScreen().x-surface.GetTextSize( v:Name() ) /2,v:GetShootPos():ToScreen().y-33,v:Name(),Color(team.GetColor(v:Team()).r,team.GetColor(v:Team()).g,team.GetColor(v:Team()).b,ErfBotCon("Erf_NewEspAlpha")))

if ErfNewEspAdmin:GetBool() and v:IsAdmin() and not v:IsSuperAdmin() then

ErfBot.DrawWB(v:GetShootPos():ToScreen().x-surface.GetTextSize( "Admin" ) /2,v:GetShootPos():ToScreen().y-46,"Admin",Color(250,50,50,ErfBotCon("Erf_NewEspAlpha")))

end

if ErfNewEspAdmin:GetBool() and v:IsSuperAdmin() then

ErfBot.DrawWB(v:GetShootPos():ToScreen().x-surface.GetTextSize( "Super Admin" ) /2,v:GetShootPos():ToScreen().y-46,"Super Admin",Color(250,50,50,ErfBotCon("Erf_NewEspAlpha")))
	
end

if ErfNewEspHP:GetBool() then

ErfBot.DrawWB(v:GetShootPos():ToScreen().x-surface.GetTextSize( "Health: "..v:Health() ) /2,v:GetShootPos():ToScreen().y-20,"Health: "..v:Health(),Color(50,50,50,ErfBotCon("Erf_NewEspAlpha")))

end				

if ErfNewEspFriends:GetBool() and v:GetFriendStatus() == "friend" then

ErfBot.DrawWB(v:GetShootPos():ToScreen().x-surface.GetTextSize( "Friend" ) /2,v:GetShootPos():ToScreen().y-10,"Friend",Color(50,50,50,ErfBotCon("Erf_NewEspAlpha")))

end


end		
end		
end	
end
hook.Add("HUDPaint","TBNames",ErfBot.NameTags)



---Ze Menu---
concommand.Add("+Erf_Menu", function() frame:SetVisible( true ) end)
concommand.Add("-Erf_Menu", function() frame:SetVisible( false ) end)

frame = vgui.Create("DFrame")
frame:SetSize( 350, 350 ) --250 300
frame:SetTitle( "Erf Bot" )
frame:Center()
frame:SetVisible( false )
frame:SetDraggable( false )
frame:ShowCloseButton( false )
frame:MakePopup()


local T1B = vgui.Create("DImage",frame)
T1B:SetMaterial(Material("Models/effects/splodearc_sheet"))
T1B:SetPos(0,0)
T1B:SetSize(350,350)



---Tab One---
local PropertySheet = vgui.Create( "DPropertySheet" )
PropertySheet:SetParent( frame )
PropertySheet:SetPos( 10, 30 )
PropertySheet:SetSize( 330, 310 ) --230 310


local TestingPanel = vgui.Create( "DPanel", frame )
TestingPanel:SetPos( 10, 10 )
TestingPanel:SetSize( 480, 280 )
TestingPanel.Paint = function() 
surface.SetDrawColor( 50, 50, 50, 255 )
surface.DrawRect( 0, 0, TestingPanel:GetWide(), TestingPanel:GetTall() ) 
end


PropertySheet:AddSheet("ESP", TestingPanel, "gui/silkicons/picture_edit", false, false, "ESP/Console Commands.")
---Tab One End---

SheetItemOne = vgui.Create("DCheckBoxLabel", TestingPanel)
SheetItemOne:SetPos(10,10)
SheetItemOne:SetText("Enable Player ESP.")
SheetItemOne:SizeToContents()
SheetItemOne:SetConVar("Erf_NewEsp")

SheetItemTwo = vgui.Create("DCheckBoxLabel", TestingPanel)
SheetItemTwo:SetPos(10,30)
SheetItemTwo:SetText("Enable Player ESP Box.")
SheetItemTwo:SizeToContents()
SheetItemTwo:SetConVar("Erf_EspBox")

SheetItemFour = vgui.Create("DCheckBoxLabel", TestingPanel)
SheetItemFour:SetPos(10,50)
SheetItemFour:SetText("Enable Extra ESP.")
SheetItemFour:SizeToContents()
SheetItemFour:SetConVar("Erf_EspExtra")

SheetItemThree = vgui.Create("DCheckBoxLabel", TestingPanel)
SheetItemThree:SetPos(10,70)
SheetItemThree:SetText("Enable NPC ESP.")
SheetItemThree:SizeToContents()
SheetItemThree:SetConVar("Erf_NPCEsp")

SheetItemFive = vgui.Create("DCheckBoxLabel", TestingPanel)
SheetItemFive:SetPos(10,90)
SheetItemFive:SetText("Enable Nade ESP.")
SheetItemFive:SizeToContents()
SheetItemFive:SetConVar("Erf_NadeEsp")

SheetItemSix = vgui.Create("DCheckBoxLabel", TestingPanel)
SheetItemSix:SetPos(10,110)
SheetItemSix:SetText("Enable Combine ESP.")
SheetItemSix:SizeToContents()
SheetItemSix:SetConVar("Erf_CombineEsp")

SheetItemSeven = vgui.Create("DCheckBoxLabel", TestingPanel)
SheetItemSeven:SetPos(10,130)
SheetItemSeven:SetText("Enable Crossbow Bolt ESP.")
SheetItemSeven:SizeToContents()
SheetItemSeven:SetConVar("Erf_CrossbowEsp")

SheetItem8 = vgui.Create("DCheckBoxLabel", TestingPanel)
SheetItem8:SetPos(10,150)
SheetItem8:SetText("Enable Rpg ESP.")
SheetItem8:SizeToContents()
SheetItem8:SetConVar("Erf_RpgEsp")

SheetItem10 = vgui.Create("DCheckBoxLabel", TestingPanel)
SheetItem10:SetPos(10,170)
SheetItem10:SetText("Enable Weapon Esp.")
SheetItem10:SizeToContents()
SheetItem10:SetConVar("Erf_WeaponEsp")

SheetItem9 = vgui.Create("DCheckBoxLabel", TestingPanel)
SheetItem9:SetPos(10,190)
SheetItem9:SetText("Enable L4D Glow.")
SheetItem9:SizeToContents()
SheetItem9:SetConVar("Erf_Glow")

SheetItem11 = vgui.Create("DCheckBoxLabel", TestingPanel)
SheetItem11:SetPos(10,210)
SheetItem11:SetText("Enable Wallhack.")
SheetItem11:SizeToContents()
SheetItem11:SetConVar("Erf_Wallhack")

NumSliderThingy = vgui.Create("DNumSlider", TestingPanel)
NumSliderThingy:SetPos(10,230) 
NumSliderThingy:SetSize(150,100) 
NumSliderThingy:SetText("View Model Alpha")
NumSliderThingy:SetMin(0) 
NumSliderThingy:SetMax(255) 
NumSliderThingy:SetDecimals(0)
NumSliderThingy:SetValue(255)

SheetItem12 = vgui.Create("DCheckBoxLabel", TestingPanel)
SheetItem12:SetPos(170,10)
SheetItem12:SetText("Enable E2 ESP.")
SheetItem12:SizeToContents()
SheetItem12:SetConVar("Erf_E2Esp")

SheetItem13 = vgui.Create("DCheckBoxLabel", TestingPanel)
SheetItem13:SetPos(170,30)
SheetItem13:SetText("Enable Skeleton ESP.")
SheetItem13:SizeToContents()
SheetItem13:SetConVar("Erf_Skeleton")


---Tab 2---

local TestingPanelTwo = vgui.Create( "DPanel", frame )
TestingPanelTwo:SetPos( 10, 30 )
TestingPanelTwo:SetSize( 380, 280 )
TestingPanelTwo.Paint = function() 
surface.SetDrawColor( 50, 50, 50, 255 )
surface.DrawRect( 0, 0, TestingPanelTwo:GetWide(), TestingPanelTwo:GetTall() ) 
end


PropertySheet:AddSheet("Misc", TestingPanelTwo, "gui/silkicons/plugin", false, false, "Misc.")
---Tab 2 End---

SheetItemOne = vgui.Create("DCheckBoxLabel", TestingPanelTwo)
SheetItemOne:SetPos(10,10)
SheetItemOne:SetText("Bunny Hop.")
SheetItemOne:SizeToContents()
SheetItemOne:SetConVar("Erf_Bhop")

SheetItemTwo = vgui.Create("DCheckBoxLabel", TestingPanelTwo)
SheetItemTwo:SetPos(10,30)
SheetItemTwo:SetText("Xhair.")
SheetItemTwo:SizeToContents()
SheetItemTwo:SetConVar("Erf_Xhair")

SheetItemThree = vgui.Create("DCheckBoxLabel", TestingPanelTwo)
SheetItemThree:SetPos(10,50)
SheetItemThree:SetText("Laser's.")
SheetItemThree:SizeToContents()
SheetItemThree:SetConVar("Erf_Laser")

SheetItemFour = vgui.Create("DCheckBoxLabel", TestingPanelTwo)
SheetItemFour:SetPos(10,70)
SheetItemFour:SetText("AntiGag.")
SheetItemFour:SizeToContents()
SheetItemFour:SetConVar("Erf_AntiGag")

SheetItemFive = vgui.Create("DCheckBoxLabel", TestingPanelTwo)
SheetItemFive:SetPos(10,90)
SheetItemFive:SetText("Enable XRay.")
SheetItemFive:SizeToContents()
SheetItemFive:SetConVar("Erf_Xray")




---Tab 3---

local TestingPanelThree = vgui.Create( "DPanel", frame )
TestingPanelThree:SetPos( 10, 50 )
TestingPanelThree:SetSize( 380, 280 )
TestingPanelThree.Paint = function() 
surface.SetDrawColor( 50, 50, 50, 255 )
surface.DrawRect( 0, 0, TestingPanelThree:GetWide(), TestingPanelThree:GetTall() ) 
end


PropertySheet:AddSheet("Customizable Tab", TestingPanelThree, "gui/silkicons/table_edit", false, false, "Customize Esp.")
---Tab 3 End---

EspSliderRed = vgui.Create("DNumSlider", TestingPanelThree)
EspSliderRed:SetPos(10,10)
EspSliderRed:SetSize(150,100)
EspSliderRed:SetText("ESP Red Color")
EspSliderRed:SetMin(0)
EspSliderRed:SetMax(255)
EspSliderRed:SetDecimals(0)
EspSliderRed:SetValue(255)

EspSliderGreen = vgui.Create("DNumSlider", TestingPanelThree)
EspSliderGreen:SetPos(10,50)
EspSliderGreen:SetSize(150,100)
EspSliderGreen:SetText("ESP Green Color")
EspSliderGreen:SetMin(0)
EspSliderGreen:SetMax(255)
EspSliderGreen:SetDecimals(0)
EspSliderGreen:SetValue(255)

EspSliderBlue = vgui.Create("DNumSlider", TestingPanelThree)
EspSliderBlue:SetPos(10,90)
EspSliderBlue:SetSize(150,100)
EspSliderBlue:SetText("ESP Blue Color")
EspSliderBlue:SetMin(0)
EspSliderBlue:SetMax(255)
EspSliderBlue:SetDecimals(0)
EspSliderBlue:SetValue(255)

NumSliderRed = vgui.Create("DNumSlider", TestingPanelThree)
NumSliderRed:SetPos(10,150)
NumSliderRed:SetSize(150,100)
NumSliderRed:SetText("Xhair Red Color")
NumSliderRed:SetMin(0)
NumSliderRed:SetMax(255)
NumSliderRed:SetDecimals(0)
NumSliderRed:SetValue(255)

NumSliderGreen = vgui.Create("DNumSlider", TestingPanelThree)
NumSliderGreen:SetPos(10,190)
NumSliderGreen:SetSize(150,100)
NumSliderGreen:SetText("XHair Green Color")
NumSliderGreen:SetMin(0)
NumSliderGreen:SetMax(255)
NumSliderGreen:SetDecimals(0)
NumSliderGreen:SetValue(255)

NumSliderBlue = vgui.Create("DNumSlider", TestingPanelThree)
NumSliderBlue:SetPos(10,230)
NumSliderBlue:SetSize(150,150)
NumSliderBlue:SetText("XHair Blue Color")
NumSliderBlue:SetMin(0)
NumSliderBlue:SetMax(255)
NumSliderBlue:SetDecimals(0)
NumSliderBlue:SetValue(255)


---Tab 4---
local TestingPanel4 = vgui.Create( "DPanel", frame )
TestingPanel4:SetPos( 10, 90 )
TestingPanel4:SetSize( 380, 280 )
TestingPanel4.Paint = function() 
surface.SetDrawColor( 50, 50, 50, 255 )
surface.DrawRect( 0, 0, TestingPanel4:GetWide(), TestingPanel4:GetTall() ) 
end


PropertySheet:AddSheet("3RD Person",TestingPanel4, "gui/silkicons/table_edit", false, false, "3RD Person Controls.")
---Tab 4 End---


SheetItemOne = vgui.Create("DCheckBoxLabel", TestingPanel4)
SheetItemOne:SetPos(10,10)
SheetItemOne:SetText("Enable 3RD View.")
SheetItemOne:SizeToContents()
SheetItemOne:SetConVar("Erf_View")

anglesForward = vgui.Create("DNumSlider", TestingPanel4)
anglesForward:SetPos(10,50)
anglesForward:SetSize(190,100)
anglesForward:SetText("3RD View Forward.")
anglesForward:SetMin(1)
anglesForward:SetMax(200)
anglesForward:SetDecimals(0)

anglesSite = vgui.Create("DNumSlider", TestingPanel4)
anglesSite:SetPos(10,90)
anglesSite:SetSize(190,100)
anglesSite:SetText("3RD View Sides.")
anglesSite:SetMin(-50)
anglesSite:SetMax(50)
anglesSite:SetDecimals(0)

anglesUpDown = vgui.Create("DNumSlider", TestingPanel4)
anglesUpDown:SetPos(10,150)
anglesUpDown:SetSize(190,100)
anglesUpDown:SetText("3RD View Up/Down.")
anglesUpDown:SetMin(-10)
anglesUpDown:SetMax(10)
anglesUpDown:SetDecimals(0)










----
function DrawXHair()
if ErfXCvar:GetBool() then

local x = ScrW()/2
local y = ScrH()/2

surface.SetDrawColor(NumSliderRed:GetValue(),NumSliderGreen:GetValue(),NumSliderBlue:GetValue(),255)

local gap = 0
local length = gap + 10
 
surface.DrawLine(x - length, y, x - gap, y)
surface.DrawLine(x + length, y, x + gap, y)
surface.DrawLine(x, y - length, x, y - gap)
surface.DrawLine(x, y + length, x, y + gap)
end
end
hook.Add("HUDPaint", "DrawXHair", DrawXHair) 
----



---L4D---
local convar = CreateClientConVar( "Erf_Glow", 0, true )
local teamcolors = CreateClientConVar( "l4d_teamcolors", "1", true )
local passes = CreateClientConVar( "l4d_passes", "3", true )
 
local MaterialBlurX = Material( "pp/blurx" )
local MaterialBlurY = Material( "pp/blury" )
local MaterialWhite = CreateMaterial( "WhiteMaterial", "VertexLitGeneric", {
    ["$basetexture"] = "color/white",
    ["$vertexalpha"] = "1",
    ["$model"] = "1",
} )
local MaterialComposite = CreateMaterial( "CompositeMaterial", "UnlitGeneric", {
    ["$basetexture"] = "_rt_FullFrameFB",
    ["$additive"] = "1",
} )
 
local RT1 = render.GetBloomTex0()
local RT2 = render.GetBloomTex1()
 
/*------------------------------------
    RenderGlow()
------------------------------------*/
local function RenderGlow( entity )
 
    // tell the stencil buffer we're going to write a value of one wherever the model
    // is rendered
    render.SetStencilEnable( true )
    render.SetStencilFailOperation( STENCILOPERATION_KEEP )
    render.SetStencilZFailOperation( STENCILOPERATION_REPLACE )
    render.SetStencilPassOperation( STENCILOPERATION_REPLACE )
    render.SetStencilCompareFunction( STENCILCOMPARISONFUNCTION_ALWAYS )
    render.SetStencilWriteMask( 1 )
    render.SetStencilReferenceValue( 1 )
     
    // this uses a small hack to render ignoring depth while not drawing color
    // i couldn't find a function in the engine to disable writing to the color channels
    // i did find one for shaders though, but I don't feel like writing a shader for this.
    cam.IgnoreZ( true )
        render.SetBlend( 0 )
            SetMaterialOverride( MaterialWhite )
                entity:DrawModel()
            SetMaterialOverride()
        render.SetBlend( 1 )
    cam.IgnoreZ( false )
     
    local w, h = ScrW(), ScrH()
     
    // draw into the white texture
    local oldRT = render.GetRenderTarget()
     
    render.SetRenderTarget( RT1 )
     
        render.SetViewPort( 0, 0, RT1:GetActualWidth(), RT1:GetActualHeight() )
         
        cam.IgnoreZ( true )
         
            render.SuppressEngineLighting( true )
             
            if entity:IsPlayer() then
             
                if teamcolors:GetBool() then
                    local color = team.GetColor( entity:Team() )
                    render.SetColorModulation( color.r/255, color.g/255, color.b/255 )
                else
                    local scale = math.Clamp( entity:Health() / 100, 0, 1 )
                    local r,g,b = (255 - scale * 255), (55 + scale * 200), (50)
                    render.SetColorModulation( r/255, g/255, b/255 )
                end
                 
            else
             
                render.SetColorModulation( 1, 165/255, 0 )
                 
            end
             
                SetMaterialOverride( MaterialWhite )
                    entity:DrawModel()
                SetMaterialOverride()
                 
            render.SetColorModulation( 1, 1, 1 )
            render.SuppressEngineLighting( false )
             
        cam.IgnoreZ( false )
         
        render.SetViewPort( 0, 0, w, h )
    render.SetRenderTarget( oldRT )
     
    // don't need this for the next pass
    render.SetStencilEnable( false )
 
end
 
/*------------------------------------
    RenderScene()
------------------------------------*/
hook.Add( "RenderScene", "ResetGlow", function( Origin, Angles )
 
    local oldRT = render.GetRenderTarget()
    render.SetRenderTarget( RT1 )
        render.Clear( 0, 0, 0, 255, true )
    render.SetRenderTarget( oldRT )
     
end )
 
/*------------------------------------
    RenderScreenspaceEffects()
------------------------------------*/
hook.Add( "RenderScreenspaceEffects", "CompositeGlow", function()
 
    MaterialBlurX:SetMaterialTexture( "$basetexture", RT1 )
    MaterialBlurY:SetMaterialTexture( "$basetexture", RT2 )
    MaterialBlurX:SetMaterialFloat( "$size", 2 )
    MaterialBlurY:SetMaterialFloat( "$size", 2 )
         
    local oldRT = render.GetRenderTarget()
     
    for i = 1, passes:GetFloat() do
	 
        // blur horizontally
        render.SetRenderTarget( RT2 )
        render.SetMaterial( MaterialBlurX )
        render.DrawScreenQuad()
 
        // blur vertically
        render.SetRenderTarget( RT1 )
        render.SetMaterial( MaterialBlurY )
        render.DrawScreenQuad()
         
    end
 
    render.SetRenderTarget( oldRT )
     
    // tell the stencil buffer we're only going to draw
    // where the <span class="highlight">player</span> models are not.
    render.SetStencilEnable( true )
    render.SetStencilReferenceValue( 0 )
    render.SetStencilTestMask( 1 )
    render.SetStencilCompareFunction( STENCILCOMPARISONFUNCTION_EQUAL )
    render.SetStencilPassOperation( STENCILOPERATION_ZERO )
     
    // composite the scene
    MaterialComposite:SetMaterialTexture( "$basetexture", RT1 )
    render.SetMaterial( MaterialComposite )
    render.DrawScreenQuad()
 
    // don't need this anymore
    render.SetStencilEnable( false )
     
end )
 
local playerheldweap = nil
 
hook.Add( "PostPlayerDraw", "RenderEntityGlow", function( ply )
 
    if !convar:GetBool() then return end
 
    if( ScrW() == ScrH() ) then return end
 
    // prevent recursion
    if( OUTLINING_ENTITY ) then return end
    OUTLINING_ENTITY = true
     
    RenderGlow( ply )
     
    playerheldweap = ply:GetActiveWeapon()
     
    if IsValid( playerheldweap ) and playerheldweap:IsWeapon() then
        RenderGlow( playerheldweap )
    end
     
    // prevents recursion time
    OUTLINING_ENTITY = false
         
end )
---L4D End---

---KeyBaooardz---
local X = -50
local Y = -100
local W = 100
local H = 200

local KeyPos =	{	{X+5, Y+100, 25, 25, -2.2, 3.45, 1.3, -0},
					{X+37.5, Y+100, 25, 25, -0.6, 1.85, 1.3, -0},
					{X+70, Y+100, 25, 25, 1.0, 0.25, 1.3, -0},

					{X+5, Y+132.5, 25, 25, -2.2, 3.45, 2.9, -1.6},
					{X+37.5, Y+132.5, 25, 25, -0.6, 1.85, 2.9, -1.6},
					{X+70, Y+132.5, 25, 25, 1.0, 0.25, 2.9, -1.6},

					{X+5, Y+165, 25, 25, -2.2, 3.45, 4.55, -3.3},
					{X+37.5, Y+165, 25, 25, -0.6, 1.85, 4.55, -3.3},
					{X+70, Y+165, 25, 25, 1.0, 0.25, 4.55, -3.3},

					{X+5, Y+67.5, 40, 25, -2.2, 4.25, -0.3, 1.6},
					{X+55, Y+67.5, 40, 25, 0.3, 1.65, -0.3, 1.6}
				}

local KP = _R.Entity
//lua_run_cl p = LocalPlayer() KeyPressed(p:GetEyeTrace().Entity, p ) print( p:GetEyeTrace().Entity.log ) 
local function KeyPressed( kp, pl )
	if not ValidEntity(pl) or not pl:IsPlayer() then return end
	local t = {}
		t.start = pl:GetShootPos()
		t.endpos = pl:GetAimVector() * 32 + t.start
		t.filter = pl
	local tr = util.TraceLine(t)
	
	local pos = kp:WorldToLocal(tr.HitPos)
	local Num = tostring( kp:GetNetworkedInt("keypad_num") )
	
	for k,v in pairs(KeyPos) do
		local x = (pos.y - v[5]) / (v[5] + v[6])
		local y = 1 - (pos.z + v[7]) / (v[7] + v[8])
		
		if (x >= 0) and (y >= 0) and (x <= 1) and (y <= 1) then 
			// this is the shit our peeeps aiming at, x and y are between 0 and 1 if were on the correct square, took me some time to figgure out what he was doing
			local key = tostring(k)
			local log = kp.log or ""
			kp.log = string.Right( log .. k, 10 )
		end
	end
end

hook.Add("HUDPaint", "getdemcodes", function()
	for k,kp in pairs( ents.FindByClass("sent_keypa*") ) do
		local last = kp.last or 0
		local new = string.len( tostring( kp:GetNetworkedInt("keypad_num") ) )
		
		local hascode = kp:GetNetworkedInt("keypad_num")
		if hascode == 0 then new = 0 end
		
		local Access = kp:GetNetworkedBool("keypad_access") // if they got in
		local ShowAccess = kp:GetNetworkedBool("keypad_showaccess") // wether its showing
		
		
		if last != new or ShowAccess then
		
			if ShowAccess then // accept or cancle been pressed 
				
				if Access and ShowAccess then
					if kp.log != " " then
						local Num = string.len( tostring( kp:GetNetworkedInt("keypad_num") ) )
						kp.code = string.Right( kp.log, Num )
						kp.log = " "
						kp.last = 0
						print( "Code found: " .. kp.code )
					end
				else
					kp.log = ""
					kp.last = 0
				end
			elseif new > last then
				local pl
				for i, ply in pairs( player.GetAll() ) do
					tr = ply:GetEyeTrace()
					if tr.Entity == kp and (tr.HitPos - ply:GetShootPos()):Length() < 80 then
						pl = ply
					end
				end
				kp.last = new
				KeyPressed( kp, pl )
			end
		end
		kp.last = new
	end
end)

hook.Add( "HUDPaint", "crkpswd", function()
	local e = LocalPlayer():GetEyeTrace().Entity
	if ValidEntity(e) and string.find(e:GetClass(), "sent_keypad") then
		local text = "%code"
		local code = e.code or "Not Found"
		
		text = string.Replace( text, "%code", code )
		draw.WordBox( 8, ScrW() / 2, ScrH() / 2, text, "Default", Color(50,50,75,100), Color(255,255,255,255) )
	end
	
	for k,v in pairs(ents.FindByClass("sent_keypa*")) do
		local pos = v:GetPos():ToScreen()
		//draw.RoundedBox( 6, 100, 50, 100, 23, Color( 255, 255, 255, 150 ) )
		--draw.RoundedBox( 4, pos.x-5, pos.y-5, 10, 10, Color( 255, 0, 0, 150 ) )
		  draw.RoundedBox( 4, pos.x-3, pos.y-3, 6, 6, Color( 255, 0, 0, 150 ) )
	end
end)

function angle()

Col = Color(255,255,255)

if player.GetByID(1):Visible(player.GetByID(5)) then
draw.SimpleTextOutlined("visible" ,"CV20",ScrW()/2,ScrH()/2,Col,TEXT_ALIGN_CENTER,TEXT_ALIGN_CENTER,.6,Color(30,30,30,165))
else
draw.SimpleTextOutlined("notvisible","CV20",ScrW()/2,ScrH()/2,Col,TEXT_ALIGN_CENTER,TEXT_ALIGN_CENTER,.6,Color(30,30,30,165))
end
 

end

hook.Add("HUDPaint","paintang",angle)



