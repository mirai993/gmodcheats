-- Global variables
local menu
local keyDebounce = false
local bhopEnabled = false -- Track bunnyhop state
local npcESPEnabled = false -- Track NPC ESP state
local playerESPEnabled = false -- Track Player ESP state
local entityESPEnabled = false -- Track Entity ESP state
local fullBrightEnabled = false -- Track the Full Bright state
local fakeDuckEnabled = false -- Track FakeDuck state
local thirdPersonEnabled = false -- Track third-person mode state
thirdPersonEnabled = false  -- Track thirdperson state
local attackerInfoEnabled = false -- Track attacker info state
local aimbotEnabled = false -- Track aimbot state
local aimbotDistance = 1000  -- Default aimbot distance 
 
render.Capture = function()
	return
end
 
-- Function to update the player list in the box
local function UpdatePlayerList(playerListPanel)
    -- Clear any previous player list items
    playerListPanel:Clear()
 
    -- Create a label for each player and add it to the panel
    for _, ply in ipairs(player.GetAll()) do
        local playerName = ply:Nick()
        local playerSteamID = ply:SteamID()
        local playerRank = ply:GetUserGroup()
 
        -- Create a label to display the player's information
        local playerLabel = vgui.Create("DLabel", playerListPanel)
        playerLabel:SetText(playerName .. " | SteamID: " .. playerSteamID .. " | Rank: " .. playerRank)
        playerLabel:SizeToContents()  -- Resize the label based on its contents
        playerLabel:SetTextColor(Color(255, 255, 255))  -- Set text color to white
        playerLabel:SetPos(10, 25 * _ - 20)  -- Position the label (stacked vertically)
    end
end
 
-- Function to toggle bunnyhop
local function ToggleBunnyhop()
    bhopEnabled = not bhopEnabled
    if bhopEnabled then
        hook.Add("CreateMove", "GeosBhop", function(cmd)
            local ply = LocalPlayer()
            if input.IsKeyDown(KEY_SPACE) and ply:IsOnGround() then
                cmd:SetButtons(bit.bor(cmd:GetButtons(), IN_JUMP)) -- Continue the bunnyhop normally
            else
                cmd:SetButtons(bit.band(cmd:GetButtons(), bit.bnot(IN_JUMP))) -- Remove IN_JUMP if not on ground
            end
        end)
    else
        hook.Remove("CreateMove", "GeosBhop")
    end
end
 
-- Function to toggle NPC ESP
local function ToggleNPCESP()
    npcESPEnabled = not npcESPEnabled
    print("NPC ESP " .. (npcESPEnabled and "enabled" or "disabled"))
end
 
-- Function to toggle Player ESP
local function TogglePlayerESP()
    playerESPEnabled = not playerESPEnabled
    print("Player ESP " .. (playerESPEnabled and "enabled" or "disabled"))
end
 
-- Function to toggle Entity ESP
local function ToggleEntityESP()
    entityESPEnabled = not entityESPEnabled
    print("Entity ESP " .. (entityESPEnabled and "enabled" or "disabled"))
end
 
-- Fullbright toggle function
local function ToggleFullBright()
    fullBrightEnabled = not fullBrightEnabled
 
    if fullBrightEnabled then
        -- Enable fullbright rendering
        hook.Add("PreRender", "FullBrightMode", function()
            render.SetLightingMode(1)
        end)
 
        -- Reset lighting mode at the end of rendering
        hook.Add("PostRender", "FullBrightReset", function()
            render.SetLightingMode(0)
        end)
 
        -- Also reset during HUD drawing to avoid conflicts
        hook.Add("PreDrawHUD", "FullBrightResetHUD", function()
            render.SetLightingMode(0)
        end)
    else
        -- Disable fullbright rendering
        hook.Remove("PreRender", "FullBrightMode")
        hook.Remove("PostRender", "FullBrightReset")
        hook.Remove("PreDrawHUD", "FullBrightResetHUD")
    end
end
 
-- Function to toggle FakeDuck
local function ToggleFakeDuck()
    fakeDuckEnabled = not fakeDuckEnabled
    if fakeDuckEnabled then
        -- Apply crouch movement while standing
        hook.Add("CreateMove", "FakeDuckMovement", function(cmd)
            local ply = LocalPlayer()
            if ply:IsOnGround() and input.IsKeyDown(KEY_LCONTROL) then -- LControl key for crouching
                cmd:SetButtons(bit.bor(cmd:GetButtons(), IN_DUCK)) -- Simulate crouch
            else
                cmd:SetButtons(bit.band(cmd:GetButtons(), bit.bnot(IN_DUCK))) -- Remove crouch if not on the ground or not holding LControl
            end
        end)
    else
        -- Remove the crouch simulation
        hook.Remove("CreateMove", "FakeDuckMovement")
    end
end
 
-- Function to toggle third-person camera
function ToggleThirdPerson()
    thirdPersonEnabled = not thirdPersonEnabled  -- Toggle the state
 
    if thirdPersonEnabled then
        -- Set up the camera for third-person mode
        hook.Add("CalcView", "ThirdPersonView", function(ply, pos, angles, fov)
            local zoom = 50  -- Set the zoom factor (adjustable)
            local distance = zoom * 10  -- Adjust the distance based on zoom level
 
            -- Adjust the camera's position and angle for third-person view
            local newPos = pos - (angles:Forward() * distance)
            local newAngles = angles
 
            -- Set up the camera data for rendering
            return {
                origin = newPos,
                angles = newAngles,
                fov = fov,
                drawviewer = true
            }
        end)
    else
        -- Disable third-person mode and restore normal view
        hook.Remove("CalcView", "ThirdPersonView")
    end
end
 
local function StartBackdoorDetection()
-- Function to find backdoors
local cooldown = 1.1
local messagesStarted = false
 
local function ValidNetString(str)
    return isstring(str) and util.NetworkStringToID(str) != 0 and str != ""
end
 
local timerCount = 0
for count = 0, 65536 do
    local currentNetMSg = util.NetworkIDToString(count)
    
    -- Only proceed if the current message string is valid and non-empty
    if currentNetMSg and currentNetMSg != "" then
        if messagesStarted and not currentNetMSg then
            print("Finished")
            break
        end
 
        messagesStarted = true
        
        -- If the message hasn't been received yet
        if not net.Receivers[currentNetMSg] then
            -- Validate the message string
            if ValidNetString(currentNetMSg) then
                timerCount = timerCount + cooldown
                timer.Simple(timerCount, function()
                    print("Sent net message: " .. currentNetMSg)
                    net.Start(currentNetMSg)
                    net.WriteString('util.AddNetworkString("foundwhatwelookinfor")')
                    net.WriteBit(1)
                    net.SendToServer()
 
                    -- Check for backdoor
                    if ValidNetString("foundwhatwelookinfor") then
                        print("Found backdoor: " .. currentNetMSg)
                        RunConsoleCommand("disconnect")
                    else
                        print("Not backdoor")
                    end
                    print("---------------------------------------------")
                end)
            end
        end
    end
end
end
 
-- Function to create the menu
local function CreateMenu()
    if IsValid(menu) then return end -- Prevent creating multiple menus
 
    -- Create the main frame
    menu = vgui.Create("DFrame")
    menu:SetSize(800, 800)
    menu:Center()
    menu:SetTitle("") -- Remove the default title
    menu:ShowCloseButton(false) -- Hide the default close button
    menu:SetDraggable(true)
    menu:MakePopup()
 
    -- Styling: Paint the menu background
    menu.Paint = function(self, w, h)
        surface.SetDrawColor(30, 30, 44, 255) -- Dark blue-gray background
        surface.DrawRect(0, 0, w, h)
 
        draw.SimpleText("HAM's Lua Menu", "DermaLarge", w / 2, 20, Color(255, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
    end
 
    -- Add a button for Bunnyhop
    local bunnyhopButton = vgui.Create("DButton", menu)
    bunnyhopButton:SetText("Bhop (OFF)")
    bunnyhopButton:SetSize(190, 30)
    bunnyhopButton:SetPos(10, 55)
    bunnyhopButton:SetTextColor(Color(255, 255, 255))
    bunnyhopButton.Paint = function(self, w, h)
        if bhopEnabled then
            surface.SetDrawColor(50, 150, 50, 255) -- Green background when enabled
        else
            surface.SetDrawColor(150, 50, 50, 255) -- Red background when disabled
        end
        surface.DrawRect(0, 0, w, h)
    end
    bunnyhopButton.DoClick = function()
        ToggleBunnyhop()
        bunnyhopButton:SetText(bhopEnabled and "Bhop (ON)" or "Bhop (OFF)")
        bunnyhopButton:PaintManual() -- Force repaint for immediate visual update
        print("Bunnyhop toggled! Current state: " .. (bhopEnabled and "Enabled" or "Disabled"))
    end
	
	
	-- Add the large player list box on the right-hand side
    local playerListPanel = vgui.Create("DPanel", menu)
    playerListPanel:SetSize(400, 400)  -- Set the size of the player list box
    playerListPanel:SetPos(380, 51)    -- Position it on the right-hand side, below the first button
    playerListPanel.Paint = function(self, w, h)
        surface.SetDrawColor(0, 0, 0, 150)  -- Dark background for the box
        surface.DrawRect(0, 0, w, h)
    end
 
    -- Call the function to update the player list
    UpdatePlayerList(playerListPanel)
 
    -- You could also add a button to refresh the player list if desired
    local refreshButton = vgui.Create("DButton", menu)
    refreshButton:SetText("Refresh Player List")
    refreshButton:SetSize(190, 30)
    refreshButton:SetPos(10, 255)
    refreshButton:SetTextColor(Color(255, 255, 255))
    refreshButton.Paint = function(self, w, h)
        surface.SetDrawColor(50, 150, 50, 255)  -- Green background for the button
        surface.DrawRect(0, 0, w, h)
    end
    refreshButton.DoClick = function()
        UpdatePlayerList(playerListPanel)  -- Refresh the list when the button is clicked
    end
 
    -- Add a button for NPC ESP
    local npcESPButton = vgui.Create("DButton", menu)
    npcESPButton:SetText("NPC ESP (OFF)")
    npcESPButton:SetSize(190, 30)
    npcESPButton:SetPos(10, 95)
    npcESPButton:SetTextColor(Color(255, 255, 255))
    npcESPButton.Paint = function(self, w, h)
        if npcESPEnabled then
            surface.SetDrawColor(50, 150, 50, 255) -- Green background when enabled
        else
            surface.SetDrawColor(150, 50, 50, 255) -- Red background when disabled
        end
        surface.DrawRect(0, 0, w, h)
    end
    npcESPButton.DoClick = function()
        ToggleNPCESP()
        npcESPButton:SetText(npcESPEnabled and "NPC ESP (ON)" or "NPC ESP (OFF)")
        npcESPButton:PaintManual() -- Force repaint for immediate visual update
        print("NPC ESP toggled! Current state: " .. (npcESPEnabled and "Enabled" or "Disabled"))
    end
 
    -- Add a button for Player ESP
    local playerESPButton = vgui.Create("DButton", menu)
    playerESPButton:SetText("Player ESP (OFF)")
    playerESPButton:SetSize(190, 30)
    playerESPButton:SetPos(10, 135)
    playerESPButton:SetTextColor(Color(255, 255, 255))
    playerESPButton.Paint = function(self, w, h)
        if playerESPEnabled then
            surface.SetDrawColor(50, 150, 50, 255) -- Green background when enabled
        else
            surface.SetDrawColor(150, 50, 50, 255) -- Red background when disabled
        end
        surface.DrawRect(0, 0, w, h)
    end
    playerESPButton.DoClick = function()
        TogglePlayerESP()
        playerESPButton:SetText(playerESPEnabled and "Player ESP (ON)" or "Player ESP (OFF)")
        playerESPButton:PaintManual() -- Force repaint for immediate visual update
        print("Player ESP toggled! Current state: " .. (playerESPEnabled and "Enabled" or "Disabled"))
    end
 
    -- Add a button for Entity ESP
    local entityESPButton = vgui.Create("DButton", menu)
    entityESPButton:SetText("Entity ESP (OFF)")
    entityESPButton:SetSize(190, 30)
    entityESPButton:SetPos(10, 175)
    entityESPButton:SetTextColor(Color(255, 255, 255))
    entityESPButton.Paint = function(self, w, h)
        if entityESPEnabled then
            surface.SetDrawColor(50, 150, 50, 255) -- Green background when enabled
        else
            surface.SetDrawColor(150, 50, 50, 255) -- Red background when disabled
        end
        surface.DrawRect(0, 0, w, h)
    end
    entityESPButton.DoClick = function()
        ToggleEntityESP()
        entityESPButton:SetText(entityESPEnabled and "Entity ESP (ON)" or "Entity ESP (OFF)")
        entityESPButton:PaintManual() -- Force repaint for immediate visual update
        print("Entity ESP toggled! Current state: " .. (entityESPEnabled and "Enabled" or "Disabled"))
    end
	
	-- Add a button for Full Bright
	local fullBrightButton = vgui.Create("DButton", menu)
	fullBrightButton:SetText("Full Bright (OFF)")
	fullBrightButton:SetSize(190, 30)
	fullBrightButton:SetPos(10, 215)  
	fullBrightButton:SetTextColor(Color(255, 255, 255))
	fullBrightButton.Paint = function(self, w, h)
		if fullBrightEnabled then
			surface.SetDrawColor(50, 150, 50, 255) -- Green background when enabled
		else
			surface.SetDrawColor(150, 50, 50, 255) -- Red background when disabled
		end
		surface.DrawRect(0, 0, w, h)
	end
	fullBrightButton.DoClick = function()
		ToggleFullBright()
		fullBrightButton:SetText(fullBrightEnabled and "Full Bright (ON)" or "Full Bright (OFF)")
		fullBrightButton:PaintManual() -- Force repaint for immediate visual update
		print("Full Bright toggled! Current state: " .. (fullBrightEnabled and "Enabled" or "Disabled"))
	end
	
	-- Add a button for FakeDuck
	local fakeDuckButton = vgui.Create("DButton", menu)
	fakeDuckButton:SetText("FakeDuck (OFF)")
	fakeDuckButton:SetSize(190, 30)
	fakeDuckButton:SetPos(10, 295) 
	fakeDuckButton:SetTextColor(Color(255, 255, 255))
	fakeDuckButton.Paint = function(self, w, h)
		if fakeDuckEnabled then
			surface.SetDrawColor(50, 150, 50, 255) -- Green background when enabled
		else
			surface.SetDrawColor(150, 50, 50, 255) -- Red background when disabled
		end
		surface.DrawRect(0, 0, w, h)
	end
	fakeDuckButton.DoClick = function()
		ToggleFakeDuck()
		fakeDuckButton:SetText(fakeDuckEnabled and "FakeDuck (ON)" or "FakeDuck (OFF)")
		fakeDuckButton:PaintManual() -- Force repaint for immediate visual update
		print("FakeDuck toggled! Current state: " .. (fakeDuckEnabled and "Enabled" or "Disabled"))
	end
	
	-- Add a button for backdoor checker
	local detectionButton = vgui.Create("DButton", menu)
	detectionButton:SetSize(190, 30)
	detectionButton:SetPos(10, 335)  
	detectionButton:SetText("Run Backdoor Detection")
	detectionButton:SetTextColor(Color(255, 255, 255))  -- Set the text color to white
 
	-- Paint function for green background
	detectionButton.Paint = function(self, w, h)
		surface.SetDrawColor(50, 150, 50, 255)  -- Green background for the button
		surface.DrawRect(0, 0, w, h)
	end
 
	-- When button is clicked, run the backdoor detection
	detectionButton.DoClick = function()
		StartBackdoorDetection()
	end
	
	-- Create the menu button for third-person toggle
	local thirdPersonButton = vgui.Create("DButton", menu)
	thirdPersonButton:SetText("Third Person (OFF)")  -- Initial text is OFF
	thirdPersonButton:SetSize(190, 30)
	thirdPersonButton:SetPos(10, 375)  -- Position it below other buttons
	thirdPersonButton:SetTextColor(Color(255, 255, 255))  -- White text
 
	-- Paint function to update button color and text
	thirdPersonButton.Paint = function(self, w, h)
		if thirdPersonEnabled then
			-- Green background when enabled
			surface.SetDrawColor(50, 150, 50, 255)
			self:SetText("Third Person (ON)")  -- Change text to ON
		else
			-- Red background when disabled
			surface.SetDrawColor(150, 50, 50, 255)
			self:SetText("Third Person (OFF)")  -- Change text to OFF
		end
		surface.DrawRect(0, 0, w, h)  -- Draw the rectangle with the appropriate color
	end
 
	-- Button click handler
	thirdPersonButton.DoClick = function()
		-- Toggle third person view
		ToggleThirdPerson()
 
		-- Force a manual repaint so the button text and color updates immediately
		thirdPersonButton:InvalidateLayout(true)
	end
 
	-- Add a button for AttackerInfo
	local attackerInfoButton = vgui.Create("DButton", menu)
	attackerInfoButton:SetText("AttackerInfo (OFF)")
	attackerInfoButton:SetSize(190, 30)
	attackerInfoButton:SetPos(10, 415) 
	attackerInfoButton:SetTextColor(Color(255, 255, 255))
 
	local attackerInfoEnabled = false -- State of the feature
 
	-- Function to handle painting the button
	attackerInfoButton.Paint = function(self, w, h)
		if attackerInfoEnabled then
			surface.SetDrawColor(50, 150, 50, 255) -- Green background when enabled
		else
			surface.SetDrawColor(150, 50, 50, 255) -- Red background when disabled
		end
		surface.DrawRect(0, 0, w, h)
	end
 
	-- Function to toggle AttackerInfo
	local function ToggleAttackerInfo()
		attackerInfoEnabled = not attackerInfoEnabled
		attackerInfoButton:SetText(attackerInfoEnabled and "AttackerInfo (ON)" or "AttackerInfo (OFF)")
		print("AttackerInfo toggled! Current state: " .. (attackerInfoEnabled and "Enabled" or "Disabled"))
	end
 
	-- Button click logic
	attackerInfoButton.DoClick = function()
		ToggleAttackerInfo()
	end
	
	-- Add a button for Aimbot
	local aimbotButton = vgui.Create("DButton", menu)
	aimbotButton:SetText("Aimbot (OFF)")
	aimbotButton:SetSize(190, 30)
	aimbotButton:SetPos(10, 455) 
	aimbotButton:SetTextColor(Color(255, 255, 255))
 
	-- Function to handle painting the button
	aimbotButton.Paint = function(self, w, h)
		if aimbotEnabled then
			surface.SetDrawColor(50, 150, 50, 255) -- Green background when enabled
		else
			surface.SetDrawColor(150, 50, 50, 255) -- Red background when disabled
		end
		surface.DrawRect(0, 0, w, h)
	end
	
	local function ToggleAimbot()
    aimbotEnabled = not aimbotEnabled
    aimbotButton:SetText(aimbotEnabled and "Aimbot (ON)" or "Aimbot (OFF)")
    print("Aimbot toggled! Current state: " .. (aimbotEnabled and "Enabled" or "Disabled"))
	end
	
	-- Button click logic for aimbot
	aimbotButton.DoClick = function()
		ToggleAimbot()
	end
	
	-- Add a slider to change the aimbot distance
	local aimbotDistanceSlider = vgui.Create("DNumSlider", menu)
	aimbotDistanceSlider:SetPos(380, 455)  
	aimbotDistanceSlider:SetSize(250, 30)  -- Set the size of the slider
	aimbotDistanceSlider:SetText("Aimbot Distance:")
	aimbotDistanceSlider:SetMin(100)  -- Set the minimum distance (100 units)
	aimbotDistanceSlider:SetMax(5000)  -- Set the maximum distance (5000 units)
	aimbotDistanceSlider:SetValue(aimbotDistance)  -- Set the initial value based on the current aimbot distance
	aimbotDistanceSlider:SetDecimals(0)  -- No decimal places for distance
	aimbotDistanceSlider.TextArea:SetTextColor(Color(255, 255, 255))  -- Set the text color to white
 
	-- Update the aimbot distance when the slider value changes
	aimbotDistanceSlider.OnValueChanged = function(self, value)
		aimbotDistance = value
		print("Aimbot distance set to: " .. aimbotDistance)
	end
	
	-- Add a button for NPC Aimbot
	local npcAimbotButton = vgui.Create("DButton", menu)
	npcAimbotButton:SetText("NPC Aimbot (OFF)")  -- Initial state (OFF)
	npcAimbotButton:SetSize(190, 30)
	npcAimbotButton:SetPos(10, 495)  -- Position it below other buttons
	npcAimbotButton:SetTextColor(Color(255, 255, 255))
 
	npcAimbotButton.Paint = function(self, w, h)
		if npcAimbotEnabled then
			surface.SetDrawColor(50, 150, 50, 255)  -- Green background when enabled
		else
			surface.SetDrawColor(150, 50, 50, 255)  -- Red background when disabled
		end
		surface.DrawRect(0, 0, w, h)
	end
 
	-- Toggle NPC Aimbot
	npcAimbotButton.DoClick = function()
		npcAimbotEnabled = not npcAimbotEnabled
		npcAimbotButton:SetText(npcAimbotEnabled and "NPC Aimbot (ON)" or "NPC Aimbot (OFF)")
		print("NPC Aimbot toggled! Current state: " .. (npcAimbotEnabled and "Enabled" or "Disabled"))
	end
	
	-- Add a text box with some notes
	local notesLabel = vgui.Create("DLabel", menu)
	notesLabel:SetPos(200, 700)
	notesLabel:SetSize(255, 55)  -- Set the size of the text box
	notesLabel:SetText("FakeDuck is untested. Damage info is also broken. if you know how to fix it, please get in touch - https://steamcommunity.com/id/HAMisMYname")
	notesLabel:SetTextColor(Color(255, 255, 255))  -- White text
	notesLabel:SetFont("DermaDefault")
	notesLabel:SetWrap(true)  -- Make text wrap within the text box
	notesLabel.Paint = function(self, w, h)
        surface.SetDrawColor(0, 0, 0, 150)  -- Dark background for the box
        surface.DrawRect(0, 0, w, h)
    end
	
end
 
-- Function to find the nearest NPC within the aimbot distance
local function GetNearestNPC()
    local closestNPC = nil
    local closestDistance = aimbotDistance  -- Use the same aimbot distance for NPCs
 
    for _, npc in ipairs(ents.FindByClass("npc_*")) do
        local dist = npc:GetPos():Distance(LocalPlayer():GetPos())
        if dist < closestDistance then
            closestNPC = npc
            closestDistance = dist
        end
    end
 
    return closestNPC
end
 
-- Function to aim at the NPC's head (not feet)
local function AimAtNPC()
    if npcAimbotEnabled then
        local npc = GetNearestNPC()
        if npc then
            -- Try to get the NPC's head bone position
            local headBoneIndex = npc:LookupBone("ValveBiped.Bip01_Head1")
            if headBoneIndex then
                local headPos = npc:GetBonePosition(headBoneIndex)  -- Get the head bone position
                -- If the head position is valid, perform the aimbot
                if headPos and headPos != npc:GetPos() then
                    local direction = (headPos - LocalPlayer():GetShootPos()):Angle()
                    LocalPlayer():SetEyeAngles(direction)
                end
            end
        end
    end
end
 
-- Hook to continuously aim at the nearest NPC
hook.Add("Think", "NPC_Aimbot_Think", function()
    if npcAimbotEnabled then
        AimAtNPC()
    end
end)
 
-- Function to handle the aimbot targeting logic
local function AimbotLogic()
    if not aimbotEnabled then return end  -- If the aimbot is off, don't proceed
 
    -- Find the closest enemy within the aimbot distance
    local closestTarget = nil
    local closestDistance = aimbotDistance
    local localPlayer = LocalPlayer()
 
    for _, ent in ipairs(ents.GetAll()) do
        if ent:IsPlayer() and ent != localPlayer and ent:Alive() then
            local dist = localPlayer:GetPos():Distance(ent:GetPos())
            if dist <= aimbotDistance and dist < closestDistance then
                closestTarget = ent
                closestDistance = dist
            end
        end
    end
 
    -- Aim at the closest enemy if one is found
    if closestTarget then
        local aimPos = closestTarget:GetPos() + Vector(0, 0, 50)  -- Adjust aim point to head height
        localPlayer:SetEyeAngles((aimPos - localPlayer:GetShootPos()):Angle())
    end
end
 
-- Hook the aimbot logic into the game's think function to check every frame
hook.Add("Think", "AimbotThink", function()
    AimbotLogic()
end)
 
-- Function to detect damage and display attacker info
local previousHealth = 0 -- Variable to track the player's previous health
local function OnEntityTakeDamage()
    hook.Add("Think", "MonitorPlayerDamage", function()
        local ply = LocalPlayer()
        if not IsValid(ply) or not ply:Alive() then return end -- Ensure the player is valid and alive
 
        -- Get the player's current health
        local currentHealth = ply:Health()
 
        -- Check if the player has taken damage
        if currentHealth < previousHealth then
            local damageTaken = previousHealth - currentHealth -- Calculate how much damage was taken
 
            -- Guess the attacker using player's most recent damage info
            local attacker = ply:GetNWEntity("LastAttacker") -- Use NW variable for attacker info
 
            if IsValid(attacker) then
                -- Display attacker info in chat
                if attacker:IsPlayer() then
                    chat.AddText(Color(255, 100, 100), attacker:Nick(), Color(255, 255, 255), " attacked you for ", Color(255, 255, 0), damageTaken, Color(255, 255, 255), " damage.")
                    print("Attacked by player: " .. attacker:Nick())
                elseif attacker:IsNPC() then
                    chat.AddText(Color(255, 100, 100), attacker:GetClass(), Color(255, 255, 255), " attacked you for ", Color(255, 255, 0), damageTaken, Color(255, 255, 255), " damage.")
                    print("Attacked by NPC: " .. attacker:GetClass())
                else
                    chat.AddText(Color(255, 255, 255), "You were attacked by something unknown for ", Color(255, 255, 0), damageTaken, Color(255, 255, 255), " damage.")
                    print("Unknown attacker caused damage.")
                end
            else
                chat.AddText(Color(255, 255, 255), "You took ", Color(255, 255, 0), damageTaken, Color(255, 255, 255), " damage, but the attacker is unknown.")
                print("No valid attacker.")
            end
        end
 
        -- Update previous health
        previousHealth = currentHealth
    end)
end
 
-- Hook to listen for the HOME key
hook.Add("Think", "OpenMenuKeyListener", function()
    if input.IsKeyDown(KEY_HOME) then
        if not keyDebounce then
            keyDebounce = true -- Set debounce to prevent rapid toggling
 
            if not IsValid(menu) then
                CreateMenu()
            else
                menu:SetVisible(not menu:IsVisible())
                if menu:IsVisible() then
                    menu:MakePopup() -- Ensure the menu regains focus
                end
            end
        end
    else
        keyDebounce = false -- Reset debounce when key is released
    end
end)
 
-- Function to calculate screen coordinates of the entity's bounding box
local function GetEntityScreenBounds(ent)
    local min, max = ent:OBBMins(), ent:OBBMaxs()
    local corners = {
        Vector(min.x, min.y, min.z),
        Vector(min.x, min.y, max.z),
        Vector(min.x, max.y, min.z),
        Vector(min.x, max.y, max.z),
        Vector(max.x, min.y, min.z),
        Vector(max.x, min.y, max.z),
        Vector(max.x, max.y, min.z),
        Vector(max.x, max.y, max.z)
    }
 
    local minX, minY, maxX, maxY = ScrW() * 2, ScrH() * 2, 0, 0
    for _, corner in pairs(corners) do
        local onScreen = ent:LocalToWorld(corner):ToScreen()
        minX, minY = math.min(minX, onScreen.x), math.min(minY, onScreen.y)
        maxX, maxY = math.max(maxX, onScreen.x), math.max(maxY, onScreen.y)
    end
 
    return minX, minY, maxX, maxY
end
 
-- Hook to render Entity ESP
hook.Add("HUDPaint", "EntityESP", function()
    if entityESPEnabled then
        for _, ent in ipairs(ents.GetAll()) do
            -- Skip entities that are not valid or are ragdolls, players, NPCs, props, equipped weapons, "physgun_beam",
            -- or are of certain classes: "class C_BaseEntity", "env_", "class C_RopeKeyframe", and "func_breakable"
            local className = ent:GetClass()
            if ent:IsValid() 
                and not ent:IsRagdoll() 
                and not ent:IsPlayer() 
                and not ent:IsNPC() 
                and not className:find("prop_") 
                and not (ent:IsWeapon() and IsValid(ent:GetOwner())) -- Exclude equipped weapons
                and not (className == "physgun_beam") -- Exclude physgun_beam
                and not (className == "class C_BaseEntity") -- Exclude class C_BaseEntity
                and not className:find("^env_") -- Exclude any class starting with "env_"
                and not (className == "class C_RopeKeyframe") -- Exclude class C_RopeKeyframe
                and not (className == "func_breakable") -- Exclude func_breakable
                and ent:GetPos():Distance(LocalPlayer():GetPos()) > 200 then
 
                -- Draw the green box around the entity
                local x1, y1, x2, y2 = GetEntityScreenBounds(ent)
                if x1 < ScrW() and x2 > 0 and y1 < ScrH() and y2 > 0 then
                    surface.SetDrawColor(0, 255, 0, 255) -- Green box
                    surface.DrawLine(x1, y1, x2, y1)
                    surface.DrawLine(x1, y1, x1, y2)
                    surface.DrawLine(x2, y1, x2, y2)
                    surface.DrawLine(x1, y2, x2, y2)
 
                    -- Draw the entity's name above the box
                    local entityName = ent:GetClass()
                    local textX, textY = (x1 + x2) / 2, y1 - 10
                    draw.SimpleText(entityName, "Default", textX, textY, Color(0, 255, 0, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_BOTTOM)
                end
            end
        end
    end
end)
 
-- Hook to render Player ESP
hook.Add("HUDPaint", "PlayerESP", function()
    if playerESPEnabled then
        for _, ply in ipairs(player.GetAll()) do
            if ply:IsValid() and ply ~= LocalPlayer() and ply:Alive() then
                -- Draw the player box and name
                local x1, y1, x2, y2 = GetEntityScreenBounds(ply)
                if x1 < ScrW() and x2 > 0 and y1 < ScrH() and y2 > 0 then
                    surface.SetDrawColor(255, 0, 0, 255) -- Red box for players
                    surface.DrawLine(x1, y1, x2, y1)
                    surface.DrawLine(x1, y1, x1, y2)
                    surface.DrawLine(x2, y1, x2, y2)
                    surface.DrawLine(x1, y2, x2, y2)
 
                    -- Draw player name above the box
                    local playerName = ply:Nick()
                    local textX, textY = (x1 + x2) / 2, y1 - 10
                    draw.SimpleText(playerName, "Default", textX, textY, Color(255, 255, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_BOTTOM)
                end
            end
        end
    end
end)
 
-- Hook to render NPC ESP
hook.Add("HUDPaint", "NPCESP", function()
    if npcESPEnabled then
        for _, npc in ipairs(ents.FindByClass("npc_*")) do
            if npc:IsValid() then
                -- Draw the NPC box and name
                local x1, y1, x2, y2 = GetEntityScreenBounds(npc)
                if x1 < ScrW() and x2 > 0 and y1 < ScrH() and y2 > 0 then
                    surface.SetDrawColor(255, 0, 0, 255) -- Red box for NPC
                    surface.DrawLine(x1, y1, x2, y1)
                    surface.DrawLine(x1, y1, x1, y2)
                    surface.DrawLine(x2, y1, x2, y2)
                    surface.DrawLine(x1, y2, x2, y2)
 
                    -- Draw NPC name above the box
                    local npcName = npc:GetClass()
                    local textX, textY = (x1 + x2) / 2, y1 - 10
                    draw.SimpleText(npcName, "Default", textX, textY, Color(255, 0, 0, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_BOTTOM)
                end
            end
        end
    end
end)