require("concommand")
require("hook")
require("cvar2")

local cvar2 = cvar2
local hook = hook
local concommand = concommand

local hyd_on = CreateClientConVar("hyd_on", 1, true, false)
local hyd_box = CreateClientConVar("hyd_box", 0, true, false)
local hyd_drawinfo = CreateClientConVar("hyd_drawinfo", 1, true, false)
local hyd_crosshair = CreateClientConVar("hyd_crosshair", 1, true, false)
local ESPData = {}
local IPS = {}
local HToScreen = _R.Vector.ToScreen
local HVector = _R.Vector
local friends = {}

function Wallhacks()
    DrawColorModify = function() end
    DrawBloom = function() end
    DrawSunbeams = function() end
    DrawSobel = function() end
    DrawSharpen = function() end
    DrawTexturize = function() end
    DrawShadow = function() end
    DrawToyTown = function() end
    DrawMaterialOverlay = function() end
    DrawMotionBlur = function() end
    if hyd_on:GetBool() then
		for k, v in pairs(ESPData) do
		    local vars = v.vars
			local friends = v.friends
			local pos = HToScreen(v.headpos)
			local ypos = pos.y - 28 - (#vars * 10)
			local color = v.color
			if friends then
				color = Color(0, 255, 0, 255)
			end
			for k, v in pairs(vars) do
				if hyd_drawinfo:GetBool() then
					if hyd_box:GetBool() then
						draw.WordBox(2, pos.x, ypos + (k * 20), v, "BudgetLabel", Color(0, 0, 0, 75), Color(255, 255, 255, 255))
					else
					    draw.DrawText(v, "BudgetLabel", pos.x, ypos + (k * 10), Color(255, 255, 255, 255), TEXT_ALIGN_LEFT)
					end
				end
			end
			draw.RoundedBox(1, pos.x, pos.y - 0.5 * 15 - (#vars * 15), 10, 10, color)
		end 
	end
	if hyd_crosshair:GetBool() then
	    surface.SetDrawColor(255, 0, 0, 255)
	    surface.DrawLine((ScrW() / 2) + 5, ScrH() / 2, (ScrW() / 2) + 15, ScrH() / 2)
	    surface.DrawLine((ScrW() / 2) - 5, ScrH() / 2, (ScrW() / 2) - 15, ScrH() / 2)
	    surface.DrawLine(ScrW() / 2, (ScrH() / 2) + 5, ScrW() / 2, (ScrH() / 2) + 15)
	    surface.DrawLine(ScrW() / 2, (ScrH() / 2) - 5, ScrW() / 2, (ScrH() / 2) - 15)
    end
end
hook.Add("HUDPaint", "Wallhacks", Wallhacks)

if hyd_on:GetBool() == 0 then
    hook.Remove("HUDPaint", "Wallhacks")
	hook.Remove("Think", "Tables")
end

function GetUserHeadpos(ent)
	if ValidEntity(ent) then
	    return ent:GetAttachment(ent:LookupAttachment("eyes")).Pos
	else
		return HVector(0, 0, 0)
	end
end

function GetUserName(ent)
    if ent:IsBot() then
    	return "Bot"
    elseif ent:UniqueID() == "STEAM_0:1:27874209" then
    	return "Darko"
    elseif ent:UniqueID() == "STEAM_0:0:32982037" then
    	return "DksKnight"
    elseif ent:UniqueID() == "STEAM_0:1:34780787" then
    	return "Smokey Green"
    elseif ent:UniqueID() == "STEAM_0:1:40527896" then
    	return "Annin"
    else
    	return ent:Name()
    end
end

function GetUserRank(ent)
    if ent:IsValid() then
        if ent:IsSuperAdmin() then
			return "Superadmin"
		elseif ent:IsAdmin() then
			return "Admin"
		else
			if pcall(function() ent:GetUserGroup() end) then
				return ent:GetUserGroup()
			elseif pcall(function() ent:EV_GetRank() end) then
				return ent:EV_GetRank()
			else
				return "User"
			end
		end
	end
end

function GetUserHP(ent)
	if ent:Alive() then
		return "Health: " .. ent:Health()
	else
		return "Dead"
	end
end

function GetUserWep(ent)
	if ent:Alive() and ValidEntity(ent:GetActiveWeapon()) then
		return ent:GetActiveWeapon():GetPrintName()
	else
		return "Unknown"
	end
end

function GetUserDist(ent)
	return "Distance: " .. math.Round(ent:GetPos():Distance(LocalPlayer():GetPos()))
end

function GetUserCash(ent)
    if ent.DarkRPVars and ent.DarkRPVars.money then
		return "$" .. ent.DarkRPVars.money or  "$" .. ent:GetNWInt("money")
	else
		return "Unknown"
	end
end

local tick = 0
local hyd_name = CreateClientConVar("hyd_name", 1, true, false)
local hyd_hp = CreateClientConVar("hyd_hp", 1, true, false)
local hyd_wep = CreateClientConVar("hyd_wep", 1, true, false)
local hyd_dist = CreateClientConVar("hyd_dist", 1, true, false)
local hyd_cash = CreateClientConVar("hyd_cash", 1, true, false)
local hyd_ip = CreateClientConVar("hyd_ip", 1, true, false)
function Tables()
	if hyd_on:GetBool() then
	    for k, v in pairs(player.GetAll()) do
		    if v != LocalPlayer() and ValidEntity(v) then
			    local data = {}
			    data.entity = v
				data.headpos = GetUserHeadpos(v)
				data.friends = v:SteamID() == "STEAM_0:1:27874209" or v:SteamID() == "STEAM_0:0:32982037" or v:SteamID() == "STEAM_0:1:34780787" or v:SteamID() == "STEAM_0:1:40527896"
				data.color = team.GetColor(v:Team())
				data.vars = {}
				
			    if hyd_name:GetBool() then
			    	table.insert(data.vars, GetUserName(v) .. " (" .. GetUserRank(v) .. ")")
			    end

			    if hyd_hp:GetBool() then
			    	table.insert(data.vars, GetUserHP(v))
			    end

			    if hyd_wep:GetBool() then
			    	table.insert(data.vars, GetUserWep(v))
			    end

			    if hyd_dist:GetBool() then
			    	table.insert(data.vars, GetUserDist(v))
			    end

			    if hyd_cash:GetBool() and v.DarkRPVars then
			    	table.insert(data.vars, GetUserCash(v))
			    end
                
                if hyd_ip:GetBool() then
                	if not v:IsBot() then
                	    table.insert(data.vars, IPS[v:Name()])
                	end
                end
                ESPData[v:EntIndex()] = data
			end
			for k, v in pairs(ESPData) do
                if not ValidEntity(v.entity) or v.entity == nil then
                    table.remove(ESPData, k)
                    ESPData[k] = nil
                end
            end
		    tick = tick + 1
			    if tick > 1000 then
				for k, v in pairs(ESPData) do
					ESPData = {}
				end
		        tick = 0
		    end
		end
	end
end
hook.Add("Think", "Tables", Tables)

concommand.Add("hyd_rotate", function() LocalPlayer():SetEyeAngles(LocalPlayer():EyeAngles() - Angle(0, 180, 0))end)

concommand.Add("hyd_rotate2", function() local a = LocalPlayer():EyeAngles() LocalPlayer():SetEyeAngles(Angle(a.p-a.p-a.p, a.y-180, a.r))end)

concommand.Add("hyd_rotate3", function() local a = LocalPlayer():EyeAngles() LocalPlayer():SetEyeAngles(Angle(a.p-a.p-a.p, a.y-180, a.r)) RunConsoleCommand("+jump") timer.Simple(0.2, RunConsoleCommand, "-jump")end)

concommand.Add("hyd_rotate4", function() RunConsoleCommand("gm_spawn", "models/props_junk/sawblade001a.mdl") RunConsoleCommand("+attack") timer.Simple(0.2, function() LocalPlayer():SetEyeAngles(LocalPlayer():EyeAngles() + Angle(-2 * LocalPlayer():EyeAngles().p, 180, 0 )) RunConsoleCommand("+jump") timer.Simple( 0.2, RunConsoleCommand, "-jump" ) timer.Simple( 0.2, function() RunConsoleCommand("gmod_undo") RunConsoleCommand("-attack")end)end)end)

concommand.Add("hyd_auto", function() RunConsoleCommand("+jump") RunConsoleCommand("gm_spawn", "models/props_junk/sawblade001a.mdl") timer.Simple(0.2, RunConsoleCommand, "-jump")end)

hook.Add("Think", "Anti-Admin", function()
    if LocalPlayer():GetNWBool("Muted") then
        LocalPlayer():SetNWBool("Muted", false)
    end
    hook.Remove("PlayerBindPress", "ULXGagForce")
    timer.Destroy("GagLocalPlayer")
    if LocalPlayer():GetNWBool("EV_Blinded") then
        LocalPlayer():SetNWBool("EV_Blinded", false)
    end
end)

if cvar2 then
    if cvar2.SetValue then
        cvar2.SetValue("sv_cheats", 1)
    else
        MsgN("Error: gm_cvar2 could not be found.")
    end
end

local light = false
concommand.Add("hyd_light", function()
	light = not light
	if light then
		RunConsoleCommand("mat_fullbright", 1)
	else
		RunConsoleCommand("mat_fullbright", 0)
	end
end)

concommand.Add("hyd_speed", function(p, c, args)
    if args[1] == nil then MsgN("You need to specify a value, prefferably in range of 0.2 to 10") return end

    if cvar2 then
        if cvar2.SetValue then
            cvar2.SetValue("host_timescale", args[1])
        else
            MsgN("Error: gm_cvar2 could not be found.")
        end
        else
            MsgN("Error: gm_cvar2 could not be found.")
        end
end)

local hyd_headbeams = CreateClientConVar("hyd_headbeams", 1, true, false)
hook.Add("RenderScreenspaceEffects", "Headbeams", function()
    if hyd_headbeams:GetBool() then
    	for k, v in pairs(player.GetAll()) do
    		if v:Alive() and v !=LocalPlayer() then
    			local pos = v:EyePos()
    			local ang = Angle(-90,0,0)
    			local laser = {}
    			laser.start = pos
    			laser.endpos = pos + ang:Forward() * 10000
    			laser.filter = v
    			local tr = util.TraceLine(laser)
    			cam.Start3D(EyePos(), EyeAngles())
    			render.SetMaterial(Material("cable/cable2"))
    			render.DrawBeam(tr.StartPos, tr.HitPos, 15, 0, 0, Color(255, 0, 0, 255))
    			cam.End3D()
    		end
    	end
    end
end)

local hyd_eyebeams = CreateClientConVar("hyd_eyebeams", 1, true, false)
hook.Add("RenderScreenspaceEffects", "Eyebeams", function()
    if hyd_eyebeams:GetBool() then
    	for k, v in pairs(player.GetAll()) do
    		if v:Alive() and v !=LocalPlayer() then
    			local pos = v:EyePos()
    			local ang = v:EyeAngles()
    			local laser = {}
    			laser.start = pos
    			laser.endpos = pos + ang:Forward() * 10000
    			laser.filter = v
    			local tr = util.TraceLine(laser)
    			cam.Start3D(EyePos(), EyeAngles())
    			render.SetMaterial(Material("cable/cable2"))
    			render.DrawBeam(tr.StartPos, tr.HitPos, 1, 0, 0, Color(0, 0, 255, 255))
    			cam.End3D()
    		end
    	end
    end
end)

//Xray
local onecolorplayer = CreateClientConVar( "hyd_xrayonecolorplayer", 0, true, false )
local onecolorprop = CreateClientConVar( "hyd_xrayonecolorprop", 0, true, false )
local bluephysgun = CreateClientConVar( "hyd_xraybluephysgun", 1, true, false )
local nophysgun = CreateClientConVar( "hyd_xraynophysgun", 0, true, false )
local xray = false

function Xray()
    if not xray then return end
    for k,v in pairs(ents.FindByClass("prop_physics")) do
	    if ValidEntity(v) then
		if v:GetVelocity():Length() > 1 then
		    v:SetColor( 0, 80, 170, 160)
		    v:SetMaterial("mat2")
	    else
			v:SetColor( 150, 0, 0, 160)
		    v:SetMaterial("mat1")
		end
		if onecolorprop:GetBool() then
            v:SetColor( 0, 80, 170, 160)
			v:SetMaterial("mat2")
		end
	end
	end
	for k,v in pairs(player.GetAll()) do
	    if ValidEntity(v) then
		    local playertrace = { }
			playertrace.start = LocalPlayer():GetShootPos()
			playertrace.endpos = v:GetPos() + Vector( 0, 0, 50 )
			playertrace.filter = LocalPlayer()
			local canisee = util.TraceLine( playertrace )
			local radius = ents.FindInSphere( canisee.HitPos, 40 )
			if table.HasValue( radius, v ) then
			    v:SetColor( 230, 230, 30, 140)
				v:SetMaterial("mat2")
			else
			    v:SetColor( 240, 130, 20, 140)
				v:SetMaterial("mat2")
			end
		    if onecolorplayer:GetBool() then
			    v:SetColor( 230, 230, 30, 140)
				v:SetMaterial("mat2")
			end
		end
	end
	for k,v in pairs(ents.GetAll()) do
	    if bluephysgun:GetBool() then
		    if v:GetClass() == "viewmodel" then
			    v:SetColor(0, 80, 170, 70)
				v:SetMaterial("mat2")
			end
		end
		if nophysgun:GetBool() then
		    if v:GetClass() == "viewmodel" then
			    v:SetColor(0, 0, 0, 0)
				v:SetMaterial("")
			end
		end
	end
	for k,v in pairs(ents.GetAll()) do
		for a, b in pairs(player.GetAll()) do
		    if b.DarkRPVars then
		        if v:IsNPC() then
			        v:SetColor(140, 0, 0, 160)
				    v:SetMaterial("mat1")
			    elseif v:IsWeapon() then
			        v:SetColor(0, 140, 0, 160)
				    v:SetMaterial("mat1")
			    elseif string.match(v:GetClass(), "printer") then
			        v:SetColor(0, 0, 140, 160)
				    v:SetMaterial("mat2")
			    elseif v:GetClass() == "drug_lab" or v:GetClass() == "lsd_lab" or v:GetClass() == "durgz_weed" or v:GetClass() == "durgz_cocaine" or v:GetClass() == "durgz_cigarette" or v:GetClass() == "durgz_alcohol" or v:GetClass() == "durgz_aspirin" or v:GetClass() == "durgz_lsd" or v:GetClass() == "durgz_pcp" or v:GetClass() == "durgz_mushroom" or v:GetClass() == "durgz_heroin" then
			        v:SetColor(240, 130, 0, 160)
				    v:SetMaterial("mat2")
			    end
			end
		end
	end
end

concommand.Add("hyd_xray", function()
    xray = not xray
    if xray then
      hook.Add( "RenderScene", "Xray", Xray)
    else
	    for k,v in pairs(ents.GetAll()) do
		    v:SetColor(255, 255, 255, 255)
			v:SetMaterial("")
		end
	    hook.Remove( "RenderScene", "Xray", Xray)
	end
end)
//xray end

concommand.Add("hyd_who", function()
	for k, v in ipairs(player.GetAll()) do
		Msg(v:Nick() .. " (" .. GetUserRank(v) .. ")\n")
	end
end)

hook.Add("PlayerConnect", "Ips", function(name, ip)
    chat.AddText(Color(255, 0, 0, 255), name .. " has connected with the IP: \n" .. ip)
    IPS[name] = ip
end)

concommand.Add("hyd_swas", function()
	RunConsoleCommand("say", "卐")
end)

concommand.Add("hyd_spectate", function(p, c, args)
	local ply = LocalPlayer()
	for k, v in pairs(player.GetAll()) do
		if string.match(string.lower(v:Nick()), string.lower(args[1])) then
			ply = v
		end
	end
	hook.Add("HUDPaint", "SpectatePlayer", function()
		if ply and ply:IsValid() then
			local CamData = {}
			CamData.origin = GetUserHeadpos(ply)
			CamData.angles = ply:EyeAngles()
			CamData.x = 0
			CamData.y = 0
			CamData.w = ScrW()
			CamData.h = ScrH()
			render.RenderView(CamData)
			hook.Remove("HUDPaint", "Wallhacks")
		end
	end)
end)

concommand.Add("hyd_stopspec", function()
	hook.Remove("HUDPaint", "SpectatePlayer")
	hook.Add("HUDPaint", "Wallhacks", Wallhacks)
end)

concommand.Add("hyd_addfriend", function(p, c, args)
    for k, v in pairs(player.GetAll()) do
    	table.insert(friends, {args[1], args[2]})
    end
end)

function ReadFriends()
    for k, v in pairs(player.GetAll()) do
    	for a, b in pairs(friends) do
    	    if b[2] == v:SteamID() then
    	    	return b[1]
    	    end
    	end
    end
end

local MenuFrame
function Menu()
	gui.EnableScreenClicker(true)
	
	if !MenuFrame then
		MenuFrame = vgui.Create("DFrame")
		MenuFrame:SetSize(500, 600)
		MenuFrame:Center()
		MenuFrame:ShowCloseButton(false)
		MenuFrame:SetDraggable(false)
		MenuFrame:SetTitle( "" )
		MenuFrame.Paint = function() end
		
		local Sheet = vgui.Create("DPropertySheet", MenuFrame)
		Sheet:SetPos(0, 0)
		Sheet:SetSize(600, 600)

		local Tab = vgui.Create("DPanelList")
		Tab:SetSpacing(5)
		Tab:SetPadding(5)
		
		local Control = vgui.Create("DCheckBoxLabel")
		Control:SetText("Enabled")
		Control:SetConVar("hyd_on")
		Tab:AddItem(Control)

		local Control = vgui.Create("DCheckBoxLabel")
		Control:SetText("Show hacks in a box")
		Control:SetConVar("hyd_box")
		Tab:AddItem(Control)
		
		local Control = vgui.Create("DCheckBoxLabel")
		Control:SetText("Show Health")
		Control:SetConVar("hyd_hp")
		Tab:AddItem(Control)
		
		local Control = vgui.Create("DCheckBoxLabel")
		Control:SetText("Show Weapon")
		Control:SetConVar("hyd_wep")
		Tab:AddItem(Control)
		
		local Control = vgui.Create("DCheckBoxLabel")
		Control:SetText("Show Distance")
		Control:SetConVar("hyd_dist")
		Tab:AddItem(Control)
		
		local Control = vgui.Create("DCheckBoxLabel")
		Control:SetText("Show Cash")
		Control:SetConVar("hyd_cash")
		Tab:AddItem(Control)
		
		local Control = vgui.Create("DCheckBoxLabel")
		Control:SetText("Show IP")
		Control:SetConVar("hyd_ip")
		Tab:AddItem(Control)
		
		Sheet:AddSheet("Hydro wallhack config", Tab, "gui/silkicons/group", false, false, "Hydro wallhack configuration")

		local Tab2 = vgui.Create("DPanelList")
		Tab2:SetSpacing(5)
		Tab:SetPadding(5)

		local Control = vgui.Create("DCheckBoxLabel")
		Control:SetText("One Color For Players")
		Control:SetConVar("hyd_xrayonecolorplayer")
		Tab2:AddItem(Control)
		
		local Control = vgui.Create("DCheckBoxLabel")
		Control:SetText("One Color For Props")
		Control:SetConVar("hyd_xrayonecolorprop")
		Tab2:AddItem(Control)
		
		local Control = vgui.Create("DCheckBoxLabel")
		Control:SetText("Blue Physghun")
		Control:SetConVar("hyd_xraybluephysgun")
		Tab2:AddItem(Control)
		
		local Control = vgui.Create("DCheckBoxLabel")
		Control:SetText("No Physgun")
		Control:SetConVar("hyd_xraynophysgun")
		Tab2:AddItem(Control)
		
		Sheet:AddSheet("Hydro xray config", Tab2, "gui/silkicons/group", false, false, "Hydro xray configuration")

		local Tab3 = vgui.Create("DPanelList")
		Tab2:SetSpacing(5)
		Tab:SetPadding(5)

		local Control = vgui.Create("DCheckBoxLabel")
		Control:SetText("Headbeams")
		Control:SetConVar("hyd_headbeams")
		Tab3:AddItem(Control)
		
		local Control = vgui.Create("DCheckBoxLabel")
		Control:SetText("Eyebeams")
		Control:SetConVar("hyd_eyebeams")
		Tab3:AddItem(Control)

		local Control = vgui.Create("DCheckBoxLabel")
		Control:SetText("Crosshair")
		Control:SetConVar("hyd_crosshair")
		Tab3:AddItem(Control)

		Sheet:AddSheet("Hydro misc", Tab3, "gui/silkicons/group", false, false, "Hydro miscellaneous")
	else
		MenuFrame:SetVisible( true )
	end
end

function MenuOff()
	if MenuFrame then
		MenuFrame:SetVisible(false)
		gui.EnableScreenClicker(false)
	end
end
concommand.Add("+hyd_menu", Menu)
concommand.Add("-hyd_menu", MenuOff)

MsgN("Hydro loaded, made by DksKnight and Smokey Green (Thank Annin and RockerZilla for the head beams)")