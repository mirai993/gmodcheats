local function swagmod()
MsgC(Color(math.random(0, 255), math.random(0, 255), math.random(0, 255)), "\nType\n")
MsgC(Color(math.random(0, 255), math.random(0, 255), math.random(0, 255)), "\n'SWAG_menu'\n")
MsgC(Color(math.random(0, 255), math.random(0, 255), math.random(0, 255)), "\nin console\n")
local ply = LocalPlayer()
local cmd = cmd
local bhopper = CreateClientConVar("bhop", 1, false, false)
local shouldshowspeed = CreateClientConVar("showspeed", 1, false, false)
local halos_enable = CreateClientConVar("halos_enable", 1 , false, false)
local tesp_enable = CreateClientConVar("tesp_enable", 1 , false, false)
local tespHP_enable = CreateClientConVar("esp_thp", 1 , false, false)
local tespWep_enable = CreateClientConVar("esp_twep", 1 , false, false)
local tespDormant_enable = CreateClientConVar("esp_tdormant", 1 , false, false)
local boxes = CreateClientConVar("boxes_enable", 1 , false, false)
local swag_enable = CreateClientConVar("swagmode", 0 , false, false)
local SWAGAssist = CreateClientConVar("swagassist", 1 , false, false)
local skellies = 10

local function keydown(key)
	if ((input.IsKeyDown(key)) and type(vgui.GetKeyboardFocus()) ~= "Panel" and (!gui.IsConsoleVisible())) then return true 
	end
		return false 
end 
surface.CreateFont( "FONT", {
   font  = "Roboto",
   size  = 18,
   weight   = 600,
   antialias   = 1,
} )
surface.CreateFont( "FONT2", {
   font  = "Comic Sans MS",
   size  = 50,
   weight   = 133769,
   antialias   = 1,
} )
hook.Add("HUDPaint", "showspeed", function()
	if shouldshowspeed:GetBool() then 
		local speed = math.floor(ply:GetVelocity():Length())
		draw.SimpleTextOutlined(speed, "Default", (ScrW() / 2) - 20, ScrH() - ScrH() + 7, Color( math.random(0, 255), math.random(0, 255), math.random(0, 255)), 4, 1, 1, Color(0, 0, 0, 255) )
	end 
end)

hook.Add("CreateMove","hag", function(cmd) 
	if (bhopper:GetBool()) then 
		if (!IsValid(ply)) then return end 
		if ply:GetMoveType() == 8 then return end 
		if ply:WaterLevel() == 3 or ply:WaterLevel() == 2 then return end 
			if( ply:GetMoveType() ~= MOVETYPE_NOCLIP and not ply:InVehicle() ) then 
				if( keydown( KEY_SPACE ) and cmd:KeyDown( IN_JUMP ) and not ply:IsOnGround() ) then cmd:RemoveKey( IN_JUMP )
				end 
			end 
	end 
end)
hook.Add("HUDPaint", "skellymodelfuckery", function()
local col = HSVToColor(  ( CurTime() * 100) % 360, 1, 1 )
	for k, v in pairs(player.GetAll()) do
		v:SetModel("models/player/skeleton.mdl")
		v:SetColor( Color(col.r, col.g, col.b))
		v:SetMaterial( "models/debug/debugwhite" )
		if v:IsValid() then v:SetWeaponColor( Vector(col.r, col.g, col.b) ) end
	end
end)

local function s_menu()
local frame = vgui.Create("DFrame")
	frame:SetSize(120, 240)
	frame:Center()
	frame:SetTitle("SWAGMod")
	frame.lblTitle:SetColor(Color( math.random(0, 255), math.random(0, 255), math.random(0, 255) ))
	frame.lblTitle:SetFontInternal("TargetID")
	frame:SetVisible(true)
	frame:MakePopup()
	frame:ShowCloseButton( false )
	frame.Paint = function(s , w , h)
		draw.RoundedBox(5, 0, 0, w, h, Color(0, 0, 0))
		draw.RoundedBox(5, 2, 2, w-4, h-4, Color( math.random(0, 255), math.random(0, 255), math.random(0, 255) ))
	end
local cbutton = vgui.Create( "DButton", frame )
	cbutton:SetText( "" )
	cbutton:SetSize( 15, 15 )
	cbutton:SetPos( frame:GetWide() - cbutton:GetWide() - 5, 12.5 - ( cbutton:GetTall() - 7 ) )
	cbutton.Paint = function(s , w , h)
		draw.RoundedBox( 5, 0, 0, w, h, Color(204, 51, 0) )
	end 
	cbutton.DoClick = function( button )
		frame:Close()
	end 
local buttonBHOP = vgui.Create("DButton", frame)
	buttonBHOP:SetPos(5, 25)
	buttonBHOP:SetSize(52, 40)
	buttonBHOP:SetText("Bhop")
	buttonBHOP.Paint = function(s , w , h)
		draw.RoundedBox(0, 0, 0, w, h, Color( math.random(0, 255), math.random(0, 255), math.random(0, 255) ))
	end
	buttonBHOP.DoClick = function( button )
		if GetConVarNumber("admins_suck_dick") == 1 then ply:ConCommand( "admins_suck_dick 0")
			surface.PlaySound( "ambient/alarms/klaxon1.wav" )
		end 
		if GetConVarNumber("admins_suck_dick") == 0 then ply:ConCommand( "admins_suck_dick 1")
			surface.PlaySound( "buttons/button16.wav" )
		end 
	end 
local buttonESP = vgui.Create("DButton", frame) 
	buttonESP:SetPos(5, 70)
	buttonESP:SetSize(52, 40)
	buttonESP:SetText("HALOS")
	buttonESP.Paint = function(s , w , h)
		draw.RoundedBox(0, 0, 0, w, h, Color( math.random(0, 255), math.random(0, 255), math.random(0, 255) ))
	end 
	buttonESP.DoClick = function( button )
		if GetConVarNumber("halos_enable") == 1 then ply:ConCommand( "halos_enable 0")
			surface.PlaySound( "ambient/alarms/klaxon1.wav" )
		end 
		if GetConVarNumber("halos_enable") == 0 then ply:ConCommand( "halos_enable 1")
			surface.PlaySound( "buttons/button16.wav" )
		end 
	end 
local buttonTESP = vgui.Create("DButton", frame) 
	buttonTESP:SetPos(60, 25)
	buttonTESP:SetSize(55, 40)
	buttonTESP:SetText("TESP")
	buttonTESP.Paint = function(s , w , h)
		draw.RoundedBox(0, 0, 0, w, h, Color( math.random(0, 255), math.random(0, 255), math.random(0, 255) ))
	end 
	buttonTESP.DoClick = function( button )
		if GetConVarNumber("tesp_enable") == 1 then ply:ConCommand( "tesp_enable 0")
			surface.PlaySound( "ambient/alarms/klaxon1.wav" )
		end 
		if GetConVarNumber("tesp_enable") == 0 then ply:ConCommand( "tesp_enable 1")
			surface.PlaySound( "buttons/button16.wav" )
		end 
	end
local buttonTHP = vgui.Create("DButton", frame) 
	buttonTHP:SetPos(90, 70)
	buttonTHP:SetSize(25, 15)
	buttonTHP:SetText("THP")
	buttonTHP.Paint = function(s , w , h)
		draw.RoundedBox(0, 0, 0, w, h, Color( math.random(0, 255), math.random(0, 255), math.random(0, 255) ))
	end 
	buttonTHP.DoClick = function( button )
		if GetConVarNumber("esp_thp") == 1 then ply:ConCommand( "esp_thp 0")
			surface.PlaySound( "ambient/alarms/klaxon1.wav" )
		end 
		if GetConVarNumber("esp_thp") == 0 then ply:ConCommand( "esp_thp 1")
			surface.PlaySound( "buttons/button16.wav" )
		end 
	end 
local buttonTWEP = vgui.Create("DButton", frame) 
	buttonTWEP:SetPos(60, 70)
	buttonTWEP:SetSize(25, 15)
	buttonTWEP:SetText("WEP")
	buttonTWEP.Paint = function(s , w , h)
		draw.RoundedBox(0, 0, 0, w, h, Color( math.random(0, 255), math.random(0, 255), math.random(0, 255) ))
	end 
	buttonTWEP.DoClick = function( button )
		if GetConVarNumber("esp_twep") == 1 then ply:ConCommand( "esp_twep 0")
			surface.PlaySound( "ambient/alarms/klaxon1.wav" )
		end 
		if GetConVarNumber("esp_twep") == 0 then ply:ConCommand( "esp_twep 1")
			surface.PlaySound( "buttons/button16.wav" )
		end 
	end 
local buttonBOXES = vgui.Create("DButton", frame) 
	buttonBOXES:SetPos(5, 115)
	buttonBOXES:SetSize(52, 40)
	buttonBOXES:SetText("BOXES")
	buttonBOXES.Paint = function(s , w , h)
		draw.RoundedBox(0, 0, 0, w, h, Color( math.random(0, 255), math.random(0, 255), math.random(0, 255) ))
	end 
	buttonBOXES.DoClick = function( button )
		if GetConVarNumber("boxes_enable") == 1 then ply:ConCommand( "boxes_enable 0")
			surface.PlaySound( "ambient/alarms/klaxon1.wav" )
		end 
		if GetConVarNumber("boxes_enable") == 0 then ply:ConCommand( "boxes_enable 1")
			surface.PlaySound( "buttons/button16.wav" )
		end 
	end 
local buttonPH = vgui.Create("DButton", frame) 
	buttonPH:SetPos(60, 90)
	buttonPH:SetSize(55, 65)
	buttonPH:SetText("inject swag")
	buttonPH.Paint = function(s , w , h)
		draw.RoundedBox(0, 0, 0, w, h, Color( math.random(0, 255), math.random(0, 255), math.random(0, 255) ))
	end 
	buttonPH.DoClick = function( button )
		if GetConVarNumber("swagmode") == 1 then ply:ConCommand( "swagmode 0")
			surface.PlaySound( "ambient/alarms/klaxon1.wav" )
		end 
		if GetConVarNumber("swagmode") == 0 then ply:ConCommand( "swagmode 1")
			surface.PlaySound( "buttons/button16.wav" )
			ply:ConCommand( "say ./inj thatSwag.so")
		end 
	end
local buttonSA = vgui.Create("DButton", frame) 
	buttonSA:SetPos(5, 160)
	buttonSA:SetSize(110, 40)
	buttonSA:SetText("SWAG ASSIST")
	buttonSA.Paint = function(s , w , h)
		draw.RoundedBox(0, 0, 0, w, h, Color( math.random(0, 255), math.random(0, 255), math.random(0, 255) ))
	end 
	buttonSA.DoClick = function( button )
		if GetConVarNumber("swagassist") == 1 then ply:ConCommand( "swagassist 0")
			surface.PlaySound( "ambient/alarms/klaxon1.wav" )
		end 
		if GetConVarNumber("swagassist") == 0 then ply:ConCommand( "swagassist 1")
			surface.PlaySound( "buttons/button16.wav" )
		end 
	end
local skellyslider = vgui.Create( "DNumSlider", frame )
	skellyslider:SetMin( 1 )
	skellyslider:SetMax( 50 )
	skellyslider:SetText( "skellies" )
	skellyslider:Dock( BOTTOM )
	skellyslider:SetValue( skellies )
function skellyslider:OnValueChanged( number )
	skellies = number
end
end
concommand.Add("SWAG_menu", s_menu)

hook.Add("PlayerFootstep", "moanStep", function(ply, pos, foot, sound2, volume, filter) ply:EmitSound( "vo/npc/female01/pain06.wav",75,math.random( 50, 150 ), 0.5) end )

timer.Simple( 10, function() ply:EmitSound( "vo/npc/male01/question06.wav", 75, 100, 0.5) end)

hook.Add( "HUDPaint", "espboxes", function()
if not (boxes:GetBool()) then return end
for k, v in pairs( player.GetAll() ) do
if not v:IsValid() or v == ply or not v:Alive() then continue end
local addon_crouch = v:Crouching() && 25 or 0
cam.Start3D()
render.DrawWireframeBox( v:GetPos(), Angle( 0, 0, 0 ), Vector( 20, 20, 0 ), Vector( -20, -20, 75 - addon_crouch ), Color(math.random(0, 255), math.random(0, 255), math.random(0, 255)) )
cam.End3D()
end
end)

hook.Add( "PreDrawHalos", "playerhalos", function()
	local col = HSVToColor(  ( CurTime() * 100) % 360, 1, 1 )
if (halos_enable:GetBool()) then
	halo.Add( player.GetAll(), Color( col.r, col.g, col.b ), 2, 2, 5, true, true )
else return 
	end
end)

hook.Add( "HUDPaint", "tesp", function()
if not (tesp_enable:GetBool()) then return end
for k, v in pairs( player.GetAll() ) do
if not v:IsValid() or not v:Alive() or v == ply then continue end
local text = ""
local pos1 = v:GetPos()
local pos2 = pos1 + Vector( 0, 0, 75 )
local pos2d1 = pos1:ToScreen()
local pos2d2 = pos2:ToScreen()
if (tesp_enable:GetBool()) then text = v:Nick() end

if (tespHP_enable:GetBool()) then text = text .. " (" .. tostring( v:Health() ) .. ")" end
draw.SimpleText( text, "FONT", pos2d2.x, pos2d2.y, Color( math.random(0, 255), math.random(0, 255), math.random(0, 255) ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )

if (tespDormant_enable:GetBool()) and v:IsDormant() then
draw.SimpleText( "[DORMANT]", "FONT", pos2d2.x, pos2d2.y - 13, Color( 255, 0, 0 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
end
if (tespWep_enable:GetBool()) then 
 draw.SimpleText( v:GetActiveWeapon():GetClass(), "Default", pos2d1.x, pos2d1.y, Color( math.random(0, 255), math.random(0, 255), math.random(0, 255) ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
end
end
draw.SimpleText("SWAGMOD", "DermaLarge", math.random(1, ScrW()), math.random(1, ScrH()), Color( math.random(0, 255), math.random(0, 255), math.random(0, 255)))
draw.SimpleText(":^)", "DermaLarge", math.random(1, ScrW()), math.random(1, ScrH()), Color( math.random(0, 255), math.random(0, 255), math.random(0, 255)))
end)

local emitter = ParticleEmitter( ply:GetPos() )
		local time = 0

		hook.Add( "Think", "wat", function()
			if not (swag_enable:GetBool()) then return end
			if CurTime() < time then
				return
			end

			time = CurTime() +0.05
			for i = 1, 16 do
				local part = emitter:Add(
					"particles/balloon_bit", 
					ply:GetPos() +Vector( 
						math.random( -256, 256 ), 
						math.random( -256, 256 ), 
						256
					)
				)
				
				if part then
					local Size = math.random( 4, 7 )
					
					part:SetColor( math.random(0, 255), math.random(0, 255), math.random(0, 255), 255 )
					part:SetVelocity( Vector( 40, 25, -math.random(300, 400) ) )
					part:SetDieTime( 4.5 )
					part:SetGravity( Vector(40, 0, -250) )
					part:SetLifeTime( 0 )
					part:SetStartSize( Size /2 )
					part:SetEndSize( Size )
					part:SetCollide( true )
				end
			end
		end )

hook.Add( "RenderScreenspaceEffects", "hhh", function()
    local col = HSVToColor(  ( CurTime() * 100) % 360, 1, 1 )
	if not (swag_enable:GetBool()) then return end
			local sinScaler = math.sin( CurTime() )
			DrawBloom(
				0,
				3,
				sinScaler *math.Rand(1, 8),
				sinScaler *math.Rand(1, 8),
				6,
				math.Rand(0.5, 1),
				col.r/255,
				col.g/255,
				col.b/255
			)

			DrawColorModify{
				["$pp_colour_addr"] = 0,
				["$pp_colour_addg"] = 0,
				["$pp_colour_addb"] = 00,
				["$pp_colour_brightness" ] = 0,
				["$pp_colour_contrast" ] = 1,
				["$pp_colour_colour" ] = 1,
				["$pp_colour_mulr" ] = 0,
				["$pp_colour_mulg" ] = 0,
				["$pp_colour_mulb" ] = 1
			}
		end )
		local mdl = ClientsideModel( "models/player/skeleton.mdl", RENDERGROUP_BOTH )
		mdl:SetNoDraw( true )
		local posCache, time = {}, 0

		hook.Add( "HUDPaint", "dance", function()
			if not mdl.SeqStart or CurTime() > (mdl.SeqStart +mdl.SeqDuration) then
				local idx = mdl:LookupSequence("taunt_dance")
				mdl.SeqDuration = mdl:SequenceDuration( idx )
				mdl.SeqStart = CurTime()
				mdl:ResetSequence( idx )
			end

			mdl:SetCycle( (CurTime() -mdl.SeqStart) /mdl.SeqDuration )

			
			local w, h = 150, 150
			local ang = Angle( 0, 0, 0 )	
			local col = HSVToColor(  ( CurTime() * 100) % 360, 1, 1 )
			for i = 1, skellies do
				if CurTime() > time then
					posCache[i] = { math.random( 0, ScrW() -w ), math.random( 0, ScrH() -h ) }
				end
				local x, y = posCache[i][1], posCache[i][2]

				cam.Start3D( (ang:Forward() *64) +(ang:Up() *32), (ang:Forward()*-1):Angle(), 90, x, y, w, h )
					cam.IgnoreZ( true )
					render.SuppressEngineLighting( true )
					
					render.SetLightingOrigin( mdl:GetPos() )
					render.ResetModelLighting( 1, 1, 1 )
					render.SetColorModulation( col.r, col.g, col.b )

					mdl:DrawModel()
					
					render.SuppressEngineLighting( false )
					cam.IgnoreZ( false )
				cam.End3D()
			end

			if CurTime() > time then
				time = CurTime() +0.15
			end
end )

local function getFirePos( ent )
local eyes = ent:LookupAttachment( "ValveBiped.Bip01_R_Hand" )
if eyes ~= 0 then
eyes = ent:GetAttachment( eyes )
if eyes && eyes.Pos then
local trace = util.TraceLine( {
start = ply:GetShootPos(),
endpos = eyes.Pos,
mask = 1174421507,
filter = {ply, ent}
} )
if trace.Fraction == 1.0 then
return eyes.Pos
end
end
end
local pos = ent:LocalToWorld( ent:OBBCenter() )
local trace = util.TraceLine( {
start = ply:GetShootPos(),
endpos = pos,
mask = 1174421507,
filter = {ply, ent}
} )
if trace.Fraction == 1.0 then
return pos
end
end

local function targeting() -- Starting the function
local dists = {}
local found = false
for _, v in pairs( player.GetAll() ) do
if not v:Alive() or v == ply or not getFirePos(v) or v:IsDormant() then continue end
found = true
table.insert( dists, { v, v:GetPos():Distance( ply:GetPos() ) } ) end
table.sort( dists, function( a, b ) return a[ 2 ] < b[ 2 ] end )
if found == false then return nil end
return dists[ 1 ][ 1 ]
end

local function SWAGassist()
				if SWAGAssist:GetBool() and keydown(KEY_F) then 
				target = targeting()
				if not IsEntity( target ) then target = nil return end
				local targethead = target:LookupBone("ValveBiped.Bip01_L_Foot") -- In this aimbot we only aim for the head.
				local targetheadpos,targetheadang = target:GetBonePosition(targethead) -- Get the position/angle of the head.
				ply:SetEyeAngles((targetheadpos - ply:GetShootPos()):Angle()) -- And finally, we snap our aim to the head of the target.
	end
end
hook.Add("Think", "swag", SWAGassist)


local x, y = ScrW()/2, ScrH()/2
local xspeed, yspeed = 1, 1
hook.Add("HUDPaint", "noobsaver", function()
	local col = HSVToColor(  ( CurTime() * 100) % 360, 1, 1 )
	x = x + xspeed
	y = y + yspeed
	if x + 200 > ScrW() or (x == 0) then 
		xspeed = xspeed * -1 
		ply:EmitSound( "vo/Citadel/al_dad.wav",75,math.random( 50, 150 ), 0.5)
	end
	if y + 45 > ScrH() or (y == 0) then 
		yspeed = yspeed * -1
		ply:EmitSound( "vo/Citadel/al_dad.wav",75,math.random( 50, 150 ), 0.5)
	end
	draw.SimpleText("SWAGMOD", "FONT2", x, y, Color( col.r, col.g, col.b))
	print(x, y)
end)

end

concommand.Add("SWAGMOD", swagmod)