--[[
	autorun/client/PropPushUp.lua
	Master | (STEAM_0:1:22519569)
	===DStream===
]]

local function PropPushUp()
	local ply = LocalPlayer()
	local Angles = ply:EyeAngles()
	ply:ConCommand("use weapon_physgun")

	ply:SetEyeAngles(Angle(90, 0, 0))

	timer.Simple(0.1, function()
		ply:ConCommand("gm_spawn models/props_phx/construct/metal_plate1.mdl")
		ply:ConCommand("+attack")
		ply:ConCommand("+jump")
	end)

	timer.Simple(0.3, function()
		ply:SetEyeAngles(Angle(-90, 0, 0))
		ply:ConCommand("-jump")
	end)

	timer.Simple(0.5, function()
		ply:ConCommand("-attack")
		ply:ConCommand("undo")
		ply:SetEyeAngles(Angles)
	end)
end

concommand.Add("prop_pushup", PropPushUp)