-- Setup Our Tables --
local propKillScript = {}
local me = LocalPlayer() -- dont use, i use cuz gmod gey
propKillScript.randomstring = function()
    local res = ""
	for i = 1, 55 do
		res = res .. string.char(math.random(97, 122))
	end
	return res
end

propKillScript.Username = "paradox"

local function Encode (array, key)
	
	local out = {}
	for i = 1, #array do
		out [i] = util.Base64Encode(array[i])
	end
	
	return out
end

local function BytesToString (array)
	local out = {}
	
	for i = 1, #array do
		out [#out + 1] = string.char (array [i])
	end
	
	return table.concat (out)
end

local function errorHandler()
    -- ha
end

local function DumpDataToMemory(codeArray,key)
    local code = Encode(codeArray, key)
    xpcall( RunStringEx, errorHandler, code )
end

DumpDataToMemory({
    "local e = math.random(1,999) ^ 2 e = e + 2.2 e = e + 2324 e = e * 252 e = e / 23 e = e + 2.2 e = e + 2324 e = e * 252 e = e / 23 e = e + 2.2 e = e + 2324 e = e * 252 e = e / 23 e = e + 2.2 e = e + 2324 e = e * 252 e = e / 23 e = e + 2.2 e = e + 2324 e = e * 252 e = e / 23 e = e + 2.2 e = e + 2324 e = e * 252 e = e / 23 e = e + 2.2 e = e + 2324 e = e * 252 e = e / 23 e = e + 2.2 e = e + 2324 e = e * 252 e = e / 23 e = e + 2.2 e = e + 2324 e = e * 252 e = e / 23 e = e + 2.2 e = e + 2324 e = e * 252 e = e / 23 e = e + 2.2 e = e + 2324 e = e * 252 e = e / 23 e = e + 2.2 e = e + 2324 e = e * 252 e = e / 23 e = e + 2.2 e = e + 2324 e = e * 252 e = e / 23 e = e + 2.2 e = e + 2324 e = e * 252 e = e / 23 e = e + 2.2 e = e + 2324 e = e * 252 e = e / 23 e = e + 2.2 e = e + 2324 e = e * 252 e = e / 23 e = e + 2.2 e = e + 2324 e = e * 252 e = e / 23 e = e + 2.2 e = e + 2324 e = e * 252 e = e / 23 e = e + 2.2 e = e + 2324 e = e * 252 e = e / 23 e = e + 2.2 e = e + 2324 e = e * 252 e = e / 23 e = e + 2.2 e = e + 2324 e = e * 252 e = e / 23 e = e + 2.2 e = e + 2324 e = e * 252 e = e / 23 e = e + 2.2 e = e + 2324 e = e * 252 e = e / 23 e = e + 2.2 e = e + 2324 e = e * 252 e = e / 23 e = e + 2.2 e = e + 2324 e = e * 252 e = e / 23 e = e + 2.2 e = e + 2324 e = e * 252 e = e / 23 e = e + 2.2 e = e + 2324 e = e * 252 e = e / 23 e = e + 2.2 e = e + 2324 e = e * 252 e = e / 23 e = e + 2.2 e = e + 2324 e = e * 252 e = e / 23 e = e + 2.2 e = e + 2324 e = e * 252 e = e / 23 e = e + 2.2 e = e + 2324 e = e * 252 e = e / 23 e = e + 2.2 e = e + 2324 e = e * 252 e = e / 23 e = e + 2.2 e = e + 2324 e = e * 252 e = e / 23"
}, string.char (math.random (0, 255)) .. string.char (math.random (0, 255)) .. string.char (math.random (0, 255)) .. string.char (math.random (0, 255)))

propKillScript.copied = {}
propKillScript.colors = {}
propKillScript.menu = {
    -- AIMBOT --
    false, -- Enable
    false, -- Autoshoot
    false, -- Ignore teams
    false, -- Ignore friends
    false, -- Ignore admins
    false, -- Ignore bots
    false, -- Non stick
    0, -- Triggerbot delay
    0, -- FOV
    0, -- Anti-Snap
    0, -- Bind
    0, -- Triggerbot overburst
    -- Player ESP --
    false, -- Enable
    false, -- Box
    false, -- Name
    false, -- Weapon
    false, -- Health
    false, -- Skelleton
    false, -- Health Number
    false, -- Glow
    false, -- Halo
    false, -- Visible Check
    90, -- FOV
    0, -- Max distance
    -- More aimbot --
    false, -- Use keybind 
    false, -- LOS Check
    "", -- Hitbox selector
    -- ESP Colors --
    Color(255,0,0),
    Color(255,0,0),
    Color(255,0,0),
    Color(255,0,0),
    Color(255,0,0),
    -- Visuals --
    false, -- Prop name
    false, -- Prop hitboxes
    false, -- Prop chams
    false, -- Prop beams
    Color(255,0,0), -- Prop name color
    Color(255,0,0), -- Prop hitboxes color
    Color(255,0,0), -- Prop chams color
    Color(255,0,0), -- Prop beam color
    false, -- Prop model
    -- ESP Dormant --
    false, -- Dormant
    -- More visuals --
    false, -- Limit props
    -- Misc tab --
    false, -- Bunny-hop
    false, -- Auto strafe
    false, -- Logs
    -- Visuals -- 
    false, -- Prop snaplines
    false, -- Watermark
    -- Misc tab -- 
    false, -- Chat spammer
    false, -- FPS Id
    false, -- Edge jump
    0, -- Edge jump bind
    false, -- Edge jump use key
    false, -- Fast walk (exploit)
    false, -- Fast stop
    false, -- Air duck
    -- Antiaim tab --
    false,  -- Enabled
    0, -- yaw
    0, -- pitch
    0, -- roll
    false, -- max lby
    false, -- lby breaker
    false, -- extend on hurt
    -- Player ESP --
    false, -- chams
    Color(0,0,0), -- chams color
    -- Antiaim tab --
    false, -- TP
    false, -- Draw fake
    false, -- Stablize LBY
    false, -- Break lag comp
    false, -- Avoid overlap
    -- N/A -- 
    true, -- anti ban
    true, -- detours
    true, -- anti mac
    true, -- anti qac
    -- Panels tab --  
    false, -- Show aimbot hitboxes on player preview
    -- Antiaim tab --
    false, -- Slide break
    0, -- fake-duck
    -- Advanced Aimbot Tab --
    false, -- RCS Compensate
    false, -- Spread Compensate
    0, -- Strength
    false, -- Humanize 81
    0, -- Humanize Scale
    0, -- Humanize Speed
    false, -- Bezier Curve 84
    0 -- Bezier Curve Threshold
}
--------------------------
-- Setup Our Bypass Tables --
local copied_GTable = table.Copy(_G)
propKillScript.copied.rcc = copied_GTable.RunConsoleCommand 
propKillScript.copied.xpcall = copied_GTable.xpcall 
propKillScript.copied.rawget = copied_GTable.rawget
propKillScript.copied.pcall = copied_GTable.pcall
propKillScript.copied.require = copied_GTable.require
propKillScript.copied.hook = copied_GTable.hook 
propKillScript.copied.file = copied_GTable.file 
propKillScript.copied.timer = copied_GTable.timer 
propKillScript.copied.net = copied_GTable.net
propKillScript.copied.table = copied_GTable.table
propKillScript.copied.render = copied_GTable.render
local rccStuff = {
    "_restart",
    "_____b__c",
    "___m",
    "sc",
    "bg",
    "bm",
    "kickme",
    "gw_iamacheater",
    "imafaggot",
    "birdcage_browse",
    "reportmod",
    "_fuckme",
    "st_openmenu",
    "_NOPENOPE",
    "__ping",
    "ar_check",
    "GForceRecoil",
    "bind",
    "bind_mac",
    "bindtoggle",
    "impulse",
    "+forward",
    "-forward",
    "+back",
    "-back",
    "+moveleft",
    "-moveleft",
    "+moveright",
    "-moveright",
    "+left",
    "-left",
    "+right",
    "-right",
    "cl_yawspeed",
    "pp_texturize",
    "pp_texturize_scale",
    "mat_texture_limit",
    "pp_bloom",
    "pp_dof",
    "pp_bokeh",
    "pp_motionblur",
    "pp_toytown",
    "pp_stereoscopy",
    "retry",
    "connect",
    "kill",
    "+voicerecord",
    "-voicerecord",
    "startmovie",
    "cl_interp",
    "cl_interp_ratio",
    "cl_updaterate",
    "physgun_maxrange", -- fucking elitelupus
    "mat_fullbright",
    "sv_allow_voice_from_file",
    "sv_consistency",
    "retard_script_unloadhook",
    "record"
}
local hookaddstuff = {
    "___scan_g_init",
    "showMotd",
    "ULXCheckSuicide",
    "ULXGimpCheck",
    "ulx_blind",
    "ulxPlayerSay",
    "gAC_AntiCobalt.StartCommand" -- only detections i could find :/
}
local netstartstuff = {
    "GimmeThatScreen_Embedded",
    "GimmeThatScreen_Request",
    "GimmeThatScreen_Provide",
    "GimmeThatScreen_OpMapBytes",
    "ScreengrabFinished",
    "ScreengrabRequest",
    "ScreengrabSendPart",
    "Progress",
    "ScreengrabInitCallback",
    "rtxappend2"
}
--------------------------

_G.RunConsoleCommand = function(cmd,arg)
    if(cmd == nil) then return propKillScript.copied.rcc(cmd,arg) end -- Load fake error message
    for k,v in pairs(rccStuff) do 
        if(v == cmd) then 
            if(propKillScript.menu[46]) then 
            MsgN(os.date("%H:%M:%S").." - " .. "The command " .. cmd .. " was on the blocked list, if you think this is a mistake please contact paradox.")
            end
            return 
        end
    end
    if(propKillScript.menu[46]) then 
    MsgN(os.date("%H:%M:%S").." - " .. "The command " .. cmd .. " passed all verification checks, it will now be ran.")
    end
    return propKillScript.copied.rcc(cmd,arg)
end

_G.net.Start = function(msgName,unreliable)
    for k,v in pairs(netstartstuff) do 
        if(v == msgName) then 
            if(propKillScript.menu[46]) then 
                MsgN(os.date("%H:%M:%S").." - " .. "The net message " .. msgName .. " was on the blacklist.")
            end
        return 
        end 
    end
    if(propKillScript.menu[46]) then 
        MsgN(os.date("%H:%M:%S").." - " .. "The net message " .. msgName .. " wasn't on the blacklist, therefore it was ran.")
    end
    return propKillScript.copied.net.Start(msgName,unreliable)
end

_G.table.getn = function(table)
    table = util.TypeToString(table)
    table = util.Base64Decode(table)
    table = string.ToTable(table)
    return #table-- Should fuck up the screengrab and make it black or make it look like a damn warzone
end

/*
_G.render.Capture = function(cD)
    cD = util.TypeToString(cD)
    cD = util.Base64Decode(cD)
    cD = string.ToTable(cD)
    return propKillScript.copied.render.Capture(cD)
end Detected by GimmieDATScreen*/

_G.xpcall = function(func,callbackError,args) 
    if(propKillScript.menu[46]) then 
        MsgN(os.date("%H:%M:%S").." - " .. "XPCall was called, it called the function " .. util.TypeToString(func) .. " and it has passed all verification checks, it will now be ran.")
    end
    return propKillScript.copied.xpcall(func,callbackError,args)
end

_G.rawget = function(tbl,inx)
    if(propKillScript.menu[46]) then 
        MsgN(os.date("%H:%M:%S").." - ".. "Rawget was called, it will now be ran, the table it was calling:")
        PrintTable(tbl)
    end
    return propKillScript.copied.rawget(tbl,inx)
end 

_G.pcall = function(func,args)
    if(propKillScript.menu[46]) then 
        MsgN(os.date("%H:%M:%S").." - " .. "Pcall was called, it was asking for the function " .. util.TypeToString(func) .. ", which will now be ran." )
    end
    return propKillScript.copied.pcall(func,args)
end

_G.require = function(themodule)
    if(propKillScript.menu[46]) then 
        MsgN(os.date("%H:%M:%S").." - " .. "Require was called, it was asking for the module " .. util.TypeToString(themodule) .. ", which will now be ran." )
    end
    return propKillScript.copied.require(themodule)
end 

_G.hook.Add = function(eventName,id,func)

    for k,v in pairs(hookaddstuff) do 
        if(v == id) then 
            if(propKillScript.menu[46]) then 
            MsgN(os.date("%H:%M:%S").." - " .. "Hook denied " .. util.TypeToString(id) .. "." )
            end
            return 
        end
    end
    if(propKillScript.menu[46]) then 
    MsgN(os.date("%H:%M:%S").." - " .. "Hook added " .. util.TypeToString(id) .. "." )
    end 
    return propKillScript.copied.hook.Add(eventName,id,func)
end

_G.hook.Remove = function(eventName,args)
    if(args == nil) then return propKillScript.copied.hook.Remove(eventName,args) end 

    if(propKillScript.menu[46]) then 
    MsgN(os.date("%H:%M:%S").." - " .. "Hook removed " .. util.TypeToString(args) .. "." )
    end
    return propKillScript.copied.hook.Remove(eventName,args)
end

_G.hook.GetTable = function() 
    if(propKillScript.menu[46]) then 
    MsgN(os.date("%H:%M:%S").." - " .. "Hook table was detoured." )
    end
    return propKillScript.copied.hook.GetTable()
end

_G.file.Append = function(name,content)
    if(propKillScript.menu[46]) then 
        MsgN(os.date("%H:%M:%S").." - " .. "file.Append was called on the file data/" .. name ..  "." )
    end
    return propKillScript.copied.file.Append(name,content)
end

_G.file.Exists = function(name,pathway)
    if(string.lower(name) == "retard_script_lite.lua") then 
        if(propKillScript.menu[46]) then 
            MsgN(os.date("%H:%M:%S").." - " .. "file.Exists was called on a protected file." )
        end
        return 
    end 
    if(propKillScript.menu[46]) then 
    MsgN(os.date("%H:%M:%S").." - " .. "file.Exists was called on the file " .. name ..  "." )
    end 
    return propKillScript.copied.file.Exists(name,pathway)
end

/*
_G.file.Find = function(name,path,sorting)
    return propKillScript.copied.file.Find(nil,nil,nil)
end*/

_G.file.Read = function(filename,gamepath)
    if(filename == "retard_script_lite.lua") then 
        if(propKillScript.menu[46]) then 
            MsgN(os.date("%H:%M:%S").." - " .. "file.Read was called on a protected file." )
        end
        return 
    end 
    MsgN(os.date("%H:%M:%S").." - " .. "file.Read was called on the file " .. filename ..  "." )
    return propKillScript.copied.file.Read(filename,gamepath)
end

_G.file.Size = function(filename,gamepath)
    if(filename == "retard_script_lite.lua") then 
        if(propKillScript.menu[46]) then 
            MsgN(os.date("%H:%M:%S").." - " .. "file.Size was called on a protected file." )
        end
        return -1
    end 
    MsgN(os.date("%H:%M:%S").." - " .. "file.Size was called on the file " .. filename ..  "." )
    return propKillScript.copied.file.Size(filename,gamepath)
end

_G.file.Write = function(name,content)
    if(propKillScript.menu[46]) then 
        MsgN(os.date("%H:%M:%S").." - " .. "file.Write was called on the file " .. name ..  "." )
    end
    return propKillScript.copied.file.Write(name,content)
end

_G.timer.Create = function(id,delay,rep,func)
    if(propKillScript.menu[46]) then 
        MsgN(os.date("%H:%M:%S").." - " .. "Timer added: " .. id ..  "." )
    end
    return propKillScript.copied.timer.Create(id,delay,rep,func)
end

_G.timer.Simple = function(delay,func)
    if(propKillScript.menu[46]) then 
        MsgN(os.date("%H:%M:%S").." - " .. "Timer added: " .. util.TypeToString(func) ..  "." )
    end
    return propKillScript.copied.timer.Simple(delay,func)
end

_G.timer.Remove = function(id)
    if(propKillScript.menu[46]) then 
        MsgN(os.date("%H:%M:%S").." - " .. "Timer removed: " .. id ..  "." )
    end
    return propKillScript.copied.timer.Remove(id)
end

_G.timer.Destroy = function(id)
    if(propKillScript.menu[46]) then 
        MsgN(os.date("%H:%M:%S").." - " .. "Timer removed: " .. id ..  " (called in destroy, reverting to alias remove)." )
    end
    return propKillScript.copied.timer.Remove(id)
end

--------------------------
-- Setup Our Colors --
propKillScript.colors.red = Color(255,0,0)
propKillScript.colors.green = Color(0,255,0)
propKillScript.colors.blue = Color(0,0,255)
propKillScript.colors.cyan = Color(70,130,191)
propKillScript.colors.pink = Color(255,192,203)
propKillScript.colors.gray = Color(169,169,169)
propKillScript.colors.silver = Color(192,192,192)
-------------------------------------------------

-- Setup our menu --
surface.CreateFont( "PKMainTextFont", { font = "coolvetica", extended = true, size = 20 } )
surface.CreateFont( "PKToptextfont", { font = "coolvetica", extended = true, size = 40 } )
surface.CreateFont( "PKToptextsmallfont", { font = "Verdana", extended = true, size = 12 } )
surface.CreateFont( "PKIders", { font = "Verdana", extended = true, size = 45 } )
surface.CreateFont( "PKMainTextFontSmall", { font = "Comic Sans MS", extended = true, size = 18, weight = 300 } )
local menu = menu or {}

function propKillScript.Checkbox(frame,x,y,txt,autovalue,valueToChange,tooltip)
    local DermaCheckbox = frame:Add( "DCheckBoxLabel" ) -- Create the checkbox
    DermaCheckbox:SetPos( x, y )						-- Set the position
    DermaCheckbox:SetText(txt)					-- Set the text next to the box
    DermaCheckbox:SetValue( autovalue )						-- Initial value
    DermaCheckbox:SizeToContents()						-- Make its size the same as the contents
    DermaCheckbox:SetFont("PKMainTextFontSmall") -- Set our font to the script font
    DermaCheckbox:SetTooltip(tooltip) -- Set our tooltip from the value passed

    function DermaCheckbox:OnChange(val)
        propKillScript.menu[valueToChange] = val -- Set our value
    end

end

function propKillScript.Slider(frame,x,y,sizex,sizey,txt,min,max,decmials,valueToChange,tooltip,set)
    local DermaNumSlider = vgui.Create( "DNumSlider", frame )
    DermaNumSlider:SetPos( x, y )				-- Set the position
    DermaNumSlider:SetSize( 150, 80 )			-- Set the size
    DermaNumSlider:SetText( txt )	-- Set the text above the slider
    DermaNumSlider:SetMin( min )				 	-- Set the minimum number you can slide to
    DermaNumSlider:SetMax( max )				-- Set the maximum number you can slide to
    DermaNumSlider:SetTooltip(tooltip) -- Set our tooltip from the value passed
    DermaNumSlider:SetDecimals( decmials )				-- Decimal places - zero for whole number
    DermaNumSlider:SetValue( set )
    DermaNumSlider.OnValueChanged = function( self, value )
        value = math.Round(value) -- Round our value (stupid ass click to set values gay)
        propKillScript.menu[valueToChange] = value -- Set our value
    end
end

function propKillScript.Binder(frame,x,y,sizex,sizey,valueToChange,tooltip,setvalue)
    local binder = vgui.Create( "DBinder", frame )
    binder:SetSize( sizex, sizey)
    binder:SetPos( x, y )
    binder:SetTooltip(tooltip)
    binder:SetValue( setvalue )
    function binder:OnChange( num )
        propKillScript.menu[valueToChange] = num
    end
end



function propKillScript.HitboxSelector()
    HitboxSelectorFrame = vgui.Create( "DFrame" )	
    HitboxSelectorFrame:SetSize( 200, 200 ) 				
    HitboxSelectorFrame:SetPos(500, 425)					
    HitboxSelectorFrame:SetTitle( "Aimbot hitbox" )					
    HitboxSelectorFrame:SetDraggable( true )
    HitboxSelectorFrame:ShowCloseButton( false )			
    HitboxSelectorFrame:MakePopup()
    function HitboxSelectorFrame:Paint( w, h )
        draw.RoundedBox( 8, 0, 0, w, h, Color( 0, 0, 0,150 ) )
    end

    local CloseButton = vgui.Create( "DButton", HitboxSelectorFrame ) // Create the button and parent it to the frame
    CloseButton:SetText( "X" )					// Set the text on the button
    CloseButton:SetPos( 175, 5 )					// Set the position on the frame
    CloseButton:SetSize( 15, 15 )					// Set the size
    CloseButton.DoClick = function()				// A custom function run when clicked ( note the . instead of : )
        HitboxSelectorFrame:Remove()
    end

    local HitboxSelector = vgui.Create("DCategoryList",HitboxSelectorFrame)

    HitboxSelector:Dock(NODOCK)
    HitboxSelector:SetPos(0,25)
    HitboxSelector:SetSize(200,175)
    local Hitbox_Selector = HitboxSelector:Add( "" )
    local Head = Hitbox_Selector:Add( "Head" )
    Head.DoClick = function()
        propKillScript.menu[27] = "ValveBiped.Bip01_Head1"
    end
    local Pelvis = Hitbox_Selector:Add( "Pelvis" )
    Pelvis.DoClick = function()
        propKillScript.menu[27] = "ValveBiped.Bip01_Pelvis"
    end
    local Spine = Hitbox_Selector:Add( "Spine" )
    Spine.DoClick = function()
        propKillScript.menu[27] = "ValveBiped.Bip01_Spine1"
    end
    local Spine2 = Hitbox_Selector:Add( "Spine 2" )
    Spine2.DoClick = function()
        propKillScript.menu[27] = "ValveBiped.Bip01_Spine2"
    end
    local Neck = Hitbox_Selector:Add( "Neck" )
    Neck.DoClick = function()
        propKillScript.menu[27] = "ValveBiped.Bip01_Neck1"
    end
    local LeftShoulder = Hitbox_Selector:Add( "Left Shoulder" )
    LeftShoulder.DoClick = function()
        propKillScript.menu[27] = "ValveBiped.Bip01_L_Clavicle"
    end
    local RightShoulder = Hitbox_Selector:Add( "Right Shoulder" )
    RightShoulder.DoClick = function()
        propKillScript.menu[27] = "ValveBiped.Bip01_R_Clavicle"
    end
    local LeftArm = Hitbox_Selector:Add( "Left Arm" )
    LeftArm.DoClick = function()
        propKillScript.menu[27] = "ValveBiped.Bip01_L_Forearm"
    end
    local RightArm = Hitbox_Selector:Add( "Right Arm" )
    RightArm.DoClick = function()
        propKillScript.menu[27] = "ValveBiped.Bip01_R_Forearm"
    end
    local RightCalf = Hitbox_Selector:Add( "Right Calf" )
    RightCalf.DoClick = function()
        propKillScript.menu[27] = "ValveBiped.Bip01_R_Calf"
    end
    local LeftCalf = Hitbox_Selector:Add( "Left Calf" )
    LeftCalf.DoClick = function()
        propKillScript.menu[27] = "ValveBiped.Bip01_L_Calf"
    end
    local Nearest = Hitbox_Selector:Add( "Nearest" )
    Nearest.DoClick = function()
        propKillScript.menu[27] = "Nearest"
    end
end
propKillScript.HitboxSelector()
HitboxSelectorFrame:SetVisible(false)


function propKillScript.ESPShowcase()
    ESPShowcaseFrame = vgui.Create( "DFrame" )	
    ESPShowcaseFrame:SetSize( 200, 200 ) 				
    ESPShowcaseFrame:SetPos(500, 425)					
    ESPShowcaseFrame:SetTitle( "ESP Showcase" )					
    ESPShowcaseFrame:SetDraggable( true )
    ESPShowcaseFrame:ShowCloseButton( false )			
    ESPShowcaseFrame:MakePopup()
    function ESPShowcaseFrame:Paint( w, h )
        draw.RoundedBox( 8, 0, 0, w, h, Color( 0, 0, 0,150 ) )
        if(propKillScript.menu[13]) then 
            if(propKillScript.menu[15]) then 
                draw.Text( {
                    text = "Player",
                    pos = { 80, 25 },
                    font = "BudgetLabel",
                    color = propKillScript.menu[31],
                } ) 
            end

            if(propKillScript.menu[16]) then 
                draw.Text( {
                    text = "weapon_ar2",
                    pos = { 70, 175 },
                    font = "BudgetLabel",
                    color = propKillScript.menu[30],
                } ) 
            end

        if(propKillScript.menu[19]) then 
            draw.Text( {
                text = "100",
                pos = { 30, 40 },
                font = "BudgetLabel",
                color = Color(0,255,0),
            } ) 
        end

            if(propKillScript.menu[17]) then 
                draw.RoundedBox( 0, 66, 41, 5, 135, Color(0,0,0,255) ) 
                draw.RoundedBox( 0, 65, 40, 5, 135, Color(0,255,0,255) ) 
            end

        end
    end

    local CloseButton = vgui.Create( "DButton", ESPShowcaseFrame ) // Create the button and parent it to the frame
    CloseButton:SetText( "X" )					// Set the text on the button
    CloseButton:SetPos( 175, 5 )					// Set the position on the frame
    CloseButton:SetSize( 15, 15 )					// Set the size
    CloseButton.DoClick = function()				// A custom function run when clicked ( note the . instead of : )
        ESPShowcaseFrame:Remove()
    end

    ESPShowcaser_ = vgui.Create( "DModelPanel", ESPShowcaseFrame )
    ESPShowcaser_:SetPos(25,25)
    ESPShowcaser_:SetSize(150,150)
    ESPShowcaser_:SetModel( "models/player/breen.mdl" ) -- you can only change colors on playermodels
    ESPShowcaser_:SetCamPos(Vector(40, 40, 40))

    function ESPShowcaser_:LayoutEntity( Entity ) return end -- disables default rotation
    function ESPShowcaser_.Entity:GetPlayerColor() return Vector (1, 0, 0) end
end
propKillScript.ESPShowcase()
ESPShowcaseFrame:SetVisible(false)

function ESPShowcaser_:PreDrawModel(ent)
    local boneAt = propKillScript.menu[27]
    if(boneAt == nil) then 
        local bone = ent:LocalToWorld(ent:OBBCenter())
    else
        local bone = ent:LookupBone(boneAt)
    end
    for i = 0, ent:GetHitBoxGroupCount() - 1 do
        for _i = 0, ent:GetHitBoxCount(i) - 1 do
            local bone = ent:GetHitBoxBone(_i, i)
            local min, max = ent:GetHitBoxBounds(_i, i)			
        end
    end
    local pos,ang = ent:GetBonePosition(bone)
    cam.Start3D()
    render.DrawWireframeBox(pos, ang, min, max, Color(255,0,0))
    cam.End3D()
end 
local hasCalledAntiCheat = false 
local function AntiCheat(calltype)
    
    if(calltype == "status") then 
        if(hasCalledAntiCheat) then 
            return "Finalized" 
        else
            return "Hasn't scaned"
        end 
    end

    local returninfo = {}

    if(propKillScript.copied.file.Exists("autorun/client/!!_cl_qac.lua", "LUA")) then
        returninfo[1] = "Detected"
    else
        returninfo[1] = "Not found"
    end
    if(propKillScript.copied.file.Exists("autorun/client/cl_mac.lua", "LUA")) then 
        returninfo[2] = "Detected"
    else
        returninfo[2] = "Not found"
    end
    if(propKillScript.copied.file.Exists("swiftac.lua", "LUA") and propKillScript.copied.file.Exists("postprocess/texturize.lua", "LUA") ) then 
        returninfo[3] = "Detected"
    else
        returninfo[3] = "Not found"
    end
    if(propKillScript.copied.file.Exists("autorun/glorifiedanticheat.lua", "LUA")) then
        returninfo[4] = "Detected"
    else 
        returninfo[4] = "Not found"
    end
    if(propKillScript.copied.file.Exists("autorun/client/!!!cac.lua", "LUA")) then
        returninfo[5] = "Detected"
    else 
        returninfo[5] = "Not found"
    end
    if(propKillScript.copied.file.Exists("autorun/sh_screengrab_v2.lua", "LUA")) then
        returninfo[6] = "Detected"
    else 
        returninfo[6] = "Not found"
    end
    if(propKillScript.copied.file.Exists("autorun/client/detour.lua", "LUA")) then
        returninfo[7] = "Detected"
    else 
        returninfo[7] = "Not found"
    end
    if(propKillScript.copied.file.Exists("autorun/client/cl_cardinal.lua", "LUA")) then
        returninfo[8] = "Detected"
    else 
        returninfo[8] = "Not found"
    end
    if(propKillScript.copied.file.Exists("autorun/client/gts_autorun.lua", "LUA")) then
        returninfo[9] = "Detected"
    else 
        returninfo[9] = "Not found"
    end
    if(propKillScript.copied.file.Exists("autorun/send-lua-and-net-send.lua", "LUA")) then
        returninfo[10] = "Detected"
    else 
        returninfo[10] = "Not found"
    end
    if(propKillScript.copied.file.Exists("autorun/client/!!!!!!!!!!!!!!!!!!!!!!aaaaaaaaaaa.lua", "LUA")) then
        returninfo[11] = "Detected"
    else 
        returninfo[11] = "Not found"
    end
    if(propKillScript.copied.file.Exists("autorun/client/hex_ac.lua", "LUA")) then
        returninfo[12] = "Detected"
    else 
        returninfo[12] = "Not found"
    end

    if(_G['rb'] ~= nil) then 
        returninfo[13] = "Detected"
    else 
        returninfo[13] = "Not found"
    end

    hasCalledAntiCheat = true 
    return returninfo 
end

local ACInfo = {}
function propKillScript.AntiCheatPage()
    local ACStatus = AntiCheat("status")

    AntiCheatPageFrame = vgui.Create( "DFrame" )	
    AntiCheatPageFrame:SetSize( 300, 300 ) 				
    AntiCheatPageFrame:SetPos(400, 400)					
    AntiCheatPageFrame:SetTitle( "Anti Cheating" )					
    AntiCheatPageFrame:SetDraggable( true )
    AntiCheatPageFrame:ShowCloseButton( false )			
    AntiCheatPageFrame:MakePopup()
    function AntiCheatPageFrame:Paint( w, h )
        draw.RoundedBox( 8, 0, 0, w, h, Color( 0, 0, 0,150 ) )
        draw.Text( {
            text = "State: " .. ACStatus,
            pos = { 10, 30 },
            font = "BudgetLabel",
            color = Color(255,255,255),
        } ) 
    end

    local CloseButton = vgui.Create( "DButton", AntiCheatPageFrame ) // Create the button and parent it to the frame
    CloseButton:SetText( "X" )					// Set the text on the button
    CloseButton:SetPos( 275, 5 )					// Set the position on the frame
    CloseButton:SetSize( 15, 15 )					// Set the size
    CloseButton.DoClick = function()				// A custom function run when clicked ( note the . instead of : )
        AntiCheatPageFrame:Remove()
    end

    local AppList = vgui.Create( "DListView", AntiCheatPageFrame )
    AppList:SetSize(300,230)
    AppList:SetPos(0,65)
    AppList:SetMultiSelect( false )
    AppList:AddColumn( "Module" )
    AppList:AddColumn( "Status" )
    AppList:AddColumn( "Version" )

    AppList:AddLine( "QAC", "Not scanned", "1.21" )
    AppList:AddLine( "VAC", "Not scanned", "-" )
    AppList:AddLine( "MAC", "Not scanned", "1.30" )
    AppList:AddLine( "SwiftAC", "Not scanned", "-" )
    AppList:AddLine( "gAC", "Not scanned", "2.1.6" )
    AppList:AddLine( "CAC", "Not scanned", "-" )
    AppList:AddLine( "Screengrab", "Not scanned", "2.0" )
    AppList:AddLine( "ROTAC", "Not scanned", "-" )
    AppList:AddLine( "Cardinal-System", "Not scanned", "-" )
    AppList:AddLine( "GimmeThatScreen", "Not scanned", "1.2" )
    AppList:AddLine( "GMAC", "Not scanned", "-" )
    AppList:AddLine( "G-Security", "Not scanned", "-" )
    AppList:AddLine( "HexAC", "Not scanned", "-" )
    AppList:AddLine( "GMOD Anti-Cheat", "Not scanned", "-" )
    AppList:AddLine( "ScriptEnforcer", "Not scanned", "-" )

    local ACRefresh = vgui.Create( "DButton", AntiCheatPageFrame ) // Create the button and parent it to the frame
    ACRefresh:SetText( "Run Detections" )					// Set the text on the button
    ACRefresh:SetPos( 180, 25 )					// Set the position on the frame
    ACRefresh:SetSize( 100, 20 )					// Set the size
    ACRefresh.DoClick = function()				// A custom function run when clicked ( note the . instead of : )
        ACInfo = AntiCheat()
        ACStatus = "Finalized"

        AppList:Clear()
        AppList:AddLine( "QAC", ACInfo[1], "1.21" )
        AppList:AddLine( "VAC", "Detected", "-" )
        AppList:AddLine( "MAC", ACInfo[2], "1.30" )
        AppList:AddLine( "SwiftAC", ACInfo[3], "-" )
        AppList:AddLine( "gAC", ACInfo[4], "2.1.6" )
        AppList:AddLine( "CAC", ACInfo[5], "-" )
        AppList:AddLine( "Screengrab", ACInfo[6], "2.0" )
        AppList:AddLine( "ROTAC", ACInfo[7], "-" )
        AppList:AddLine( "Cardinal-System", ACInfo[8], "-" )
        AppList:AddLine( "GimmeThatScreen", ACInfo[9], "1.2" )
        AppList:AddLine( "GMAC", ACInfo[10], "-" )
        AppList:AddLine( "G-Security", ACInfo[11], "-" )
        AppList:AddLine( "HexAC", ACInfo[12], "1.12" )
        AppList:AddLine( "GMOD Anti-Cheat", "Detected", "-" )
        AppList:AddLine( "ScriptEnforcer", ACInfo[13], "-" )

    end
    
end

local function GenerateTips()
    local pitch = propKillScript.menu[58]
    local yaw = propKillScript.menu[59]
    local breakRoll = propKillScript.menu[60]
    local whatToSay = {}

    if(pitch <= 70) then 
        whatToSay[1] = "I think you need to up your pitch to 89 or above. \n"
    end

    if(yaw == 360) then 
        whatToSay[2] = "I think you need to lower your yaw slightly. \n"
    end

    if(breakRoll == 0) then 
        whatToSay[3] = "I think you need to up your roll (break roll) to 10 or above. \n"
    end

    if(not propKillScript.menu[70]) then 
        if(yaw > 50 and breakRoll > 7) then 
        whatToSay[4] = "I think you need to turn on avoid overlap with your current settings. \n"
        end 
    else
        if(breakRoll == 15) then 
            whatToSay[5] = "I think you should turn off avoid overlap with your current break roll setting. \n"
        end
    end

    return whatToSay
end


function propKillScript.AntiAimShowcasePage()
    AAPageFrame = vgui.Create( "DFrame" )	
    AAPageFrame:SetSize( 500, 150 ) 				
    AAPageFrame:SetPos(200, 360)					
    AAPageFrame:SetTitle( "Anti-Aim Information" )					
    AAPageFrame:SetDraggable( true )
    AAPageFrame:ShowCloseButton( true )			
    AAPageFrame:MakePopup()
    function AAPageFrame:Paint( w, h )
        draw.RoundedBox( 8, 0, 0, w, h, Color( 0, 0, 0,150 ) )
        draw.Text( {
            text = "PITCH: " .. propKillScript.menu[58],
            pos = { 10, 30 },
            font = "BudgetLabel",
            color = Color(255,255,255),
        } ) 
        draw.Text( {
            text = "YAW: " .. propKillScript.menu[59],
            pos = { 10, 40 },
            font = "BudgetLabel",
            color = Color(255,255,255),
        } ) 
        draw.Text( {
            text = "Break Roll: " .. propKillScript.menu[60],
            pos = { 10, 50 },
            font = "BudgetLabel",
            color = Color(255,255,255),
        } ) 
        draw.Text( {
            text = "AI Generated Tips:",
            pos = { 10, 60 },
            font = "BudgetLabel",
            color = Color(255,255,255),
        } ) 
        for k,v in pairs(GenerateTips()) do 
            draw.Text( {
                text = v,
                pos = { 10, (k * 10) + 70 },
                font = "BudgetLabel",
                color = Color(255,255,255),
            } ) 
        end
    end
end


function propKillScript.AdvancedAimbotSettings()
    AdvAimbotFrame = vgui.Create( "DFrame" )	
    AdvAimbotFrame:SetSize( 500, 300 ) 				
    AdvAimbotFrame:SetPos(200, 400)				
    AdvAimbotFrame:SetTitle( "Advanced Aimbot Settings" )					
    AdvAimbotFrame:SetDraggable( true )
    AdvAimbotFrame:ShowCloseButton( true )			
    AdvAimbotFrame:MakePopup()
    function AdvAimbotFrame:Paint( w, h )
        draw.RoundedBox( 8, 0, 0, w, h, Color( 0, 0, 0,150 ) )
    end

    propKillScript.Checkbox(AdvAimbotFrame,15,30,'RCS Compensation',propKillScript.menu[78],78,'Compensates for recoil on most weapons (excluding TFA).') 
    propKillScript.Checkbox(AdvAimbotFrame,15,45,'Spread Compensation',propKillScript.menu[79],79,'Compensates for spread on most weapons.') 
    propKillScript.Checkbox(AdvAimbotFrame,15,60,'Humanize',propKillScript.menu[81],81,'Humanizes the aimbot pathing.') 
    propKillScript.Checkbox(AdvAimbotFrame,15,75,'Benzier Curve',propKillScript.menu[84],84,'Uses the formula for a Benzier Curve to create a curvature in the aimbot pathing.')
    
    propKillScript.Slider(AdvAimbotFrame,285,-15,30,90,"Aimbot Strength",0,100,0,80,'The strength of the aimbot.',propKillScript.menu[80])
    propKillScript.Slider(AdvAimbotFrame,285,30,30,90,"Humanize Scale",0,100,0,82,'The humanize amount.',propKillScript.menu[82])
  --  propKillScript.Slider(menu.aimbotpage,285,-15,30,90,"Humanize Speed",0,100,0,80,'The speed of humanize.',propKillScript.menu[83])
    propKillScript.Slider(AdvAimbotFrame,285,75,30,90,"Curve threshold",0,100,0,85,'The curvature amount.',propKillScript.menu[85])
end

function propKillScript.PListFunc()
    PListFrame = vgui.Create( "DFrame" )	
    PListFrame:SetSize( 300, 345 )				
    PListFrame:SetPos(400, 400)				
    PListFrame:SetTitle( "Player list" )					
    PListFrame:SetDraggable( true )
    PListFrame:ShowCloseButton( true )			
    PListFrame:MakePopup()
    function PListFrame:Paint( w, h )
        draw.RoundedBox( 8, 0, 0, w, h, Color( 0, 0, 0,150 ) )
    end

    local SelectedStuff = {}
    local AppList = vgui.Create( "DListView", PListFrame )
    AppList:SetSize(300,230)
    AppList:SetPos(0,65)
    AppList:SetMultiSelect( false )
    AppList:AddColumn( "Username" )
    AppList:AddColumn( "UserID" )
    AppList:AddColumn( "SteamID" )
    AppList:AddColumn( "RH-User" )
    AppList.OnRowSelected = function( lst, index, pnl )
        SelectedStuff = {
            pnl:GetColumnText( 1 ),
            pnl:GetColumnText( 2 ),
            pnl:GetColumnText( 3 ),
            pnl:GetColumnText( 4 )
        }
    end

    for k,v in pairs(player.GetAll()) do
        if(v:SteamID() == "STEAM_0:1:193781969" or v:SteamID() == "STEAM_0:0:552655971" or v:SteamID() == "STEAM_0:0:109145007") then 
            AppList:AddLine(v:Name(),v:UserID(),v:SteamID(),"Yes")
        else
            AppList:AddLine(v:Name(),v:UserID(),v:SteamID(),"No")
        end
    end

    local PListRefresh = vgui.Create( "DButton", PListFrame ) // Create the button and parent it to the frame
    PListRefresh:SetText( "Refresh" )					// Set the text on the button
    PListRefresh:SetPos( 120, 25 )					// Set the position on the frame
    PListRefresh:SetSize( 50, 15 )					// Set the size
    PListRefresh.DoClick = function()				// A custom function run when clicked ( note the . instead of : )
        AppList:Clear()
        for k,v in pairs(player.GetAll()) do
            if(v:SteamID() == "STEAM_0:1:193781969" or v:SteamID() == "STEAM_0:0:552655971" or v:SteamID() == "STEAM_0:0:109145007") then 
                AppList:AddLine(v:Name(),v:UserID(),v:SteamID(),"Yes")
            else
                AppList:AddLine(v:Name(),v:UserID(),v:SteamID(),"No")
            end
        end
    end
    
    local PListNotePlayer = vgui.Create( "DButton", PListFrame ) // Create the button and parent it to the frame
    PListNotePlayer:SetText( "Record Player" )					// Set the text on the button
    PListNotePlayer:SetPos( 100, 300 )					// Set the position on the frame
    PListNotePlayer:SetSize( 100, 15 )					// Set the size
    PListNotePlayer.DoClick = function()				// A custom function run when clicked ( note the . instead of : )
        file.Write("player_record_" .. SelectedStuff[1] .. ".txt", "")
        local prettyprinted = util.TableToJSON(SelectedStuff,true)
        prettyprinted = util.JSONToTable(prettyprinted)
        for k,v in ipairs(prettyprinted) do 
            file.Append("player_record_" .. SelectedStuff[1] .. ".txt", v .. "; ")
        end    
    end
end

file.CreateDir("rh")
function propKillScript.Menu()
    menu.Frame = vgui.Create( "DFrame" )	
    menu.Frame:SetSize( 500, 380 ) 				
    menu.Frame:Center()
    menu.Frame:SetTitle( "" )					
    menu.Frame:SetDraggable( true )
    menu.Frame:ShowCloseButton( false )	
    menu.Frame:MakePopup()
    function menu.Frame:Paint( w, h )
        draw.RoundedBox( 8, 0, 0, w, h, Color( 0, 0, 0,150 ) )
        draw.DrawText("RETARD SCRIPT", "PKToptextfont", 220,4, Color(210, 210, 210,255), TEXT_ALIGN_CENTER)
        draw.DrawText("                        V1", "PKToptextfont", 250,4, Color(0, 192, 255,255), TEXT_ALIGN_CENTER)
        draw.DrawText("                                                             by paradox and scottpot8", "PKToptextsmallfont", 220,35, Color(255, 255, 255, 255), TEXT_ALIGN_CENTER)

    end
    propKillScript.Checkbox(menu.Frame,15,360,'Anti ban',propKillScript.menu[71],71,'Loads custom detours, and anti cheat bypasses every few ticks.')
    propKillScript.Checkbox(menu.Frame,465,360,'',propKillScript.menu[72],72,'Custom detours.')
    propKillScript.Checkbox(menu.Frame,440,360,'',propKillScript.menu[73],73,'Anti-MAC.')
    propKillScript.Checkbox(menu.Frame,415,360,'',propKillScript.menu[74],74,'Anti-QAC.')

    local CloseButton = vgui.Create( "DButton", menu.Frame ) // Create the button and parent it to the frame
    CloseButton:SetText( "X" )					// Set the text on the button
    CloseButton:SetPos( 465, 10 )					// Set the position on the frame
    CloseButton:SetSize( 20, 20 )					// Set the size
    CloseButton.DoClick = function()				// A custom function run when clicked ( note the . instead of : )
        menu.Frame:Remove()
    end

    local sheet = vgui.Create( "DPropertySheet", menu.Frame )
    sheet:SetPos(5,60)
    sheet:SetSize(490,300)

    menu.aimbotpage = vgui.Create( "DPanel", sheet )
    menu.aimbotpage.Paint = function( self, w, h ) draw.RoundedBox( 2, 0, 0, w, h, Color(0,0,0,200) ) end 
    sheet:AddSheet( "Auto-Aimer", menu.aimbotpage )

    menu.antiaimpage = vgui.Create( "DPanel", sheet )
    menu.antiaimpage.Paint = function( self, w, h ) draw.RoundedBox( 2, 0, 0, w, h, Color(0,0,0,200) ) end 
    sheet:AddSheet( "Anti-Hit", menu.antiaimpage )
    
    menu.playeresppage = vgui.Create( "DPanel", sheet )
    menu.playeresppage.Paint = function( self, w, h ) draw.RoundedBox( 2, 0, 0, w, h, Color(0,0,0,200) ) end 
    sheet:AddSheet( "Player Visuals", menu.playeresppage )
    
    menu.visualesppage = vgui.Create( "DPanel", sheet )
    menu.visualesppage.Paint = function( self, w, h ) draw.RoundedBox( 2, 0, 0, w, h, Color(0,0,0,200) ) end 
    sheet:AddSheet( "Visuals", menu.visualesppage )

    menu.miscpage = vgui.Create( "DPanel", sheet )
    menu.miscpage.Paint = function( self, w, h ) draw.RoundedBox( 2, 0, 0, w, h, Color(0,0,0,200) ) end 
    sheet:AddSheet( "Miscellaneous", menu.miscpage )

    menu.panelspage = vgui.Create( "DPanel", sheet )
    menu.panelspage.Paint = function( self, w, h ) draw.RoundedBox( 2, 0, 0, w, h, Color(0,0,0,200) ) end 
    sheet:AddSheet( "Panels", menu.panelspage )

    menu.configpage = vgui.Create( "DPanel", sheet )
    menu.configpage.Paint = function( self, w, h ) draw.RoundedBox( 2, 0, 0, w, h, Color(0,0,0,200) ) end 
    sheet:AddSheet( "Configurations", menu.configpage )

    -- Our panels page 
    local PlayerESPPreview = vgui.Create( "DButton", menu.panelspage ) // Create the button and parent it to the frame
    PlayerESPPreview:SetText( "Player Preview" )					// Set the text on the button
    PlayerESPPreview:SetPos( 15, 15 )					// Set the position on the frame
    PlayerESPPreview:SetSize( 100, 20 )					// Set the size
    PlayerESPPreview.DoClick = function()				// A custom function run when clicked ( note the . instead of : )
        if(ESPShowcaseFrame and ESPShowcaseFrame:IsVisible()) then ESPShowcaseFrame:Remove() return end
        propKillScript.ESPShowcase() // Call our ESP showcaser selection function
    end

    local AntiCheatPage = vgui.Create( "DButton", menu.panelspage ) // Create the button and parent it to the frame
    AntiCheatPage:SetText( "Anti Cheating" )					// Set the text on the button
    AntiCheatPage:SetPos( 15, 45 )					// Set the position on the frame
    AntiCheatPage:SetSize( 100, 20 )					// Set the size
    AntiCheatPage.DoClick = function()				// A custom function run when clicked ( note the . instead of : )
        if(AntiCheatPageFrame and AntiCheatPageFrame:IsVisible()) then AntiCheatPageFrame:Remove() return end
        propKillScript.AntiCheatPage() // Call our anti cheat selection function
    end

    local AntiAimshowcasePage = vgui.Create( "DButton", menu.panelspage ) // Create the button and parent it to the frame
    AntiAimshowcasePage:SetText( "Anti-Aim" )					// Set the text on the button
    AntiAimshowcasePage:SetPos( 15, 75 )					// Set the position on the frame
    AntiAimshowcasePage:SetSize( 100, 20 )					// Set the size
    AntiAimshowcasePage.DoClick = function()				// A custom function run when clicked ( note the . instead of : )
        if(AAPageFrame and AAPageFrame:IsVisible()) then AAPageFrame:Remove() return end
        propKillScript.AntiAimShowcasePage() // Call our aa selection function
    end

    local PListPage = vgui.Create( "DButton", menu.panelspage ) // Create the button and parent it to the frame
    PListPage:SetText( "Player List" )					// Set the text on the button
    PListPage:SetPos( 15, 105 )					// Set the position on the frame
    PListPage:SetSize( 100, 20 )					// Set the size
    PListPage.DoClick = function()				// A custom function run when clicked ( note the . instead of : )
        if(PListFrame and PListFrame:IsVisible()) then PListFrame:Remove() return end
        propKillScript.PListFunc() // Call our aa selection function
    end

    -- Our aimbot page
    propKillScript.Checkbox(menu.aimbotpage,15,15,'Enabled',propKillScript.menu[1],1,'Enables the aimbot.')
    propKillScript.Checkbox(menu.aimbotpage,15,30,'Triggerbot',propKillScript.menu[2],2,'Automaticly fires when the crosshair is on the player.')
    propKillScript.Checkbox(menu.aimbotpage,15,45,'Ignore Team',propKillScript.menu[3],3,'Ignores teammate based on gamemode.')
    propKillScript.Checkbox(menu.aimbotpage,15,60,'Ignore Friends',propKillScript.menu[4],4,'Ignores steam friends.')
    propKillScript.Checkbox(menu.aimbotpage,15,75,'Ignore Admins',propKillScript.menu[5],5,'Ignores ULX and default staff.')
    propKillScript.Checkbox(menu.aimbotpage,15,90,'Ignore Bots',propKillScript.menu[6],6,'Ignores bots based on Player:Bot().')
    propKillScript.Checkbox(menu.aimbotpage,15,105,'Non-Sticky',propKillScript.menu[7],7,'Stops aiming if the crosshair is on the player.')
    propKillScript.Checkbox(menu.aimbotpage,15,120,'Use key bind',propKillScript.menu[25],25,'Uses the key bind bound by the binder below.')
    propKillScript.Checkbox(menu.aimbotpage,15,135,'Ignore LOS check',propKillScript.menu[26],26,'Aims at people through walls.')
    propKillScript.Slider(menu.aimbotpage,285,-15,30,90,"TB Delay",0,150,0,8,'The delay before triggerbot fires.',propKillScript.menu[8])
    propKillScript.Slider(menu.aimbotpage,285,25,30,90,"Overburst",0,30,0,12,'The amount of overburst applied to the triggerbot.',propKillScript.menu[12])
    propKillScript.Slider(menu.aimbotpage,285,65,30,90,"FOV",0,180,0,9,'Minimum FOV from the middle of the screen to the target for the aimbot to kick in.',propKillScript.menu[9])
    propKillScript.Slider(menu.aimbotpage,285,105,30,90,"Anti-Snap",0,100,0,10,'Smoothing applied to the aimbot.',propKillScript.menu[10])
    propKillScript.Binder(menu.aimbotpage,15,155,100,20,11,'Key bound to aimbot.',propKillScript.menu[11])
    local HitboxSelectButton = vgui.Create( "DButton", menu.aimbotpage ) // Create the button and parent it to the frame
    HitboxSelectButton:SetText( "Hitboxes" )					// Set the text on the button
    HitboxSelectButton:SetPos( 15, 175 )					// Set the position on the frame
    HitboxSelectButton:SetSize( 100, 20 )					// Set the size
    HitboxSelectButton.DoClick = function()				// A custom function run when clicked ( note the . instead of : )
        if(HitboxSelectorFrame and HitboxSelectorFrame:IsVisible()) then HitboxSelectorFrame:Remove() return end
        propKillScript.HitboxSelector() // Call our hitbox selection function
    end
    local AdvancedSelectButton = vgui.Create( "DButton", menu.aimbotpage ) // Create the button and parent it to the frame
    AdvancedSelectButton:SetText( "Advanced" )					// Set the text on the button
    AdvancedSelectButton:SetPos( 15, 195 )					// Set the position on the frame
    AdvancedSelectButton:SetSize( 100, 20 )					// Set the size
    AdvancedSelectButton.DoClick = function()				// A custom function run when clicked ( note the . instead of : )
        if(AdvAimbotFrame and AdvAimbotFrame:IsVisible()) then AdvAimbotFrame:Remove() return end
        propKillScript.AdvancedAimbotSettings() // Call our hitbox selection function
    end


    -- Our player visuals
    propKillScript.Checkbox(menu.playeresppage,15,15,'Enabled',propKillScript.menu[13],13,'Enables the player esp.')
    propKillScript.Checkbox(menu.playeresppage,15,30,'Box',propKillScript.menu[14],14,'Draws a 2D box around all players.')
    propKillScript.Checkbox(menu.playeresppage,15,45,'Name',propKillScript.menu[15],15,'Draws the players name above their head.')
    propKillScript.Checkbox(menu.playeresppage,15,60,'Weapon',propKillScript.menu[16],16,'Draws the gun that the player is currently holding.')
    propKillScript.Checkbox(menu.playeresppage,15,75,'Health',propKillScript.menu[17],17,'Draws a bar thats colored based on the health of the player.')
    propKillScript.Checkbox(menu.playeresppage,15,90,'Skelleton',propKillScript.menu[18],18,'Draws the players skelleton.')
    propKillScript.Checkbox(menu.playeresppage,15,105,'Health Number',propKillScript.menu[19],19,'Draws the players health number on the bottom.')
    propKillScript.Checkbox(menu.playeresppage,15,120,'Glow',propKillScript.menu[20],20,'Draws a glow effect around the player.')
    propKillScript.Checkbox(menu.playeresppage,15,135,'Halo',propKillScript.menu[21],21,'Draws a halo effect around the player.')
    propKillScript.Checkbox(menu.playeresppage,15,150,'Chams',propKillScript.menu[64],64,'Overrites the players model color and material.')
    propKillScript.Checkbox(menu.playeresppage,15,165,'Visible Check',propKillScript.menu[22],22,'Only draws the esp if the player is visible.')
    propKillScript.Checkbox(menu.playeresppage,15,180,'Dormant',propKillScript.menu[42],42,'Draws the player even if you are far away.')
    propKillScript.Slider(menu.playeresppage,285,-15,30,90,"Field of view",0,170,0,23,'Changes the FOV of your game.',propKillScript.menu[23]) 
    propKillScript.Slider(menu.playeresppage,285,30,30,90,"Max Dist",0,4092,0,24,'Wont load esp if the player is further than the set value.',propKillScript.menu[24]) 
    
    local box_color_picker = vgui.Create("DRGBPicker", menu.playeresppage)
    box_color_picker:SetPos(150, 5)
    box_color_picker:SetSize(75, 75)
    local box_color_cube = vgui.Create("DColorCube", menu.playeresppage)
    box_color_cube:SetPos(175, 5)
    box_color_cube:SetSize(75, 75)
    function box_color_picker:OnChange(col)
        local h = ColorToHSV(col)
        local _, s, v = ColorToHSV(box_color_cube:GetRGB())
        
        col = HSVToColor(h, s, v)
        box_color_cube:SetColor(col)
    end
    function box_color_cube:OnUserChanged(col)
        propKillScript.menu[32] = col 
    end
    box_color_cube:SetVisible(false)
    box_color_picker:SetVisible(false)
    local boxcolorpickerbutton = vgui.Create( "DButton", menu.playeresppage ) // Create the button and parent it to the frame
    boxcolorpickerbutton:SetText( "[]" )					// Set the text on the button
    boxcolorpickerbutton:SetPos( 65, 30 )					// Set the position on the frame
    boxcolorpickerbutton:SetSize( 14, 16 )					// Set the size
    boxcolorpickerbutton.DoClick = function()				// A custom function run when clicked ( note the . instead of : )
        if(box_color_cube:IsVisible()) then 
        box_color_cube:SetVisible(false)
        box_color_picker:SetVisible(false)
        else
        box_color_cube:SetVisible(true)
        box_color_picker:SetVisible(true)
        end
    end

    local chams_color_picker = vgui.Create("DRGBPicker", menu.playeresppage)
    chams_color_picker:SetPos(150, 140)
    chams_color_picker:SetSize(75, 75)
    local chams_color_cube = vgui.Create("DColorCube", menu.playeresppage)
    chams_color_cube:SetPos(175, 140)
    chams_color_cube:SetSize(75, 75)
    function chams_color_picker:OnChange(col)
        local h = ColorToHSV(col)
        local _, s, v = ColorToHSV(chams_color_cube:GetRGB())
        
        col = HSVToColor(h, s, v)
        chams_color_cube:SetColor(col)
    end
    function chams_color_cube:OnUserChanged(col)
        propKillScript.menu[65] = col 
    end
    chams_color_cube:SetVisible(false)
    chams_color_picker:SetVisible(false)
    local chamscolorpickerbutton = vgui.Create( "DButton", menu.playeresppage ) // Create the button and parent it to the frame
    chamscolorpickerbutton:SetText( "[]" )					// Set the text on the button
    chamscolorpickerbutton:SetPos( 80, 150 )					// Set the position on the frame
    chamscolorpickerbutton:SetSize( 14, 16 )					// Set the size
    chamscolorpickerbutton.DoClick = function()				// A custom function run when clicked ( note the . instead of : )
        if(chams_color_cube:IsVisible()) then 
        chams_color_cube:SetVisible(false)
        chams_color_picker:SetVisible(false)
        else
        chams_color_cube:SetVisible(true)
        chams_color_picker:SetVisible(true)
        end
    end

    local name_color_picker = vgui.Create("DRGBPicker", menu.playeresppage)
    name_color_picker:SetPos(150, 45)
    name_color_picker:SetSize(75, 75)
    local name_color_cube = vgui.Create("DColorCube", menu.playeresppage)
    name_color_cube:SetPos(175, 45)
    name_color_cube:SetSize(75, 75)
    function name_color_picker:OnChange(col)
        local h = ColorToHSV(col)
        local _, s, v = ColorToHSV(name_color_cube:GetRGB())
        
        col = HSVToColor(h, s, v)
        name_color_cube:SetColor(col)
    end
    function name_color_cube:OnUserChanged(col)
        propKillScript.menu[31] = col 
    end
    name_color_cube:SetVisible(false)
    name_color_picker:SetVisible(false)
    local namecolorpickerbutton = vgui.Create( "DButton", menu.playeresppage ) // Create the button and parent it to the frame
    namecolorpickerbutton:SetText( "[]" )					// Set the text on the button
    namecolorpickerbutton:SetPos( 80, 45 )					// Set the position on the frame
    namecolorpickerbutton:SetSize( 14, 16 )					// Set the size
    namecolorpickerbutton.DoClick = function()				// A custom function run when clicked ( note the . instead of : )
        if(name_color_cube:IsVisible()) then
        name_color_cube:SetVisible(false)
        name_color_picker:SetVisible(false)
        else
        name_color_cube:SetVisible(true)
        name_color_picker:SetVisible(true)
        end
    end

    local weapon_color_picker = vgui.Create("DRGBPicker", menu.playeresppage)
    weapon_color_picker:SetPos(150, 85)
    weapon_color_picker:SetSize(75, 75)
    local weapon_color_cube = vgui.Create("DColorCube", menu.playeresppage)
    weapon_color_cube:SetPos(175, 85)
    weapon_color_cube:SetSize(75, 75)
    function weapon_color_picker:OnChange(col)
        local h = ColorToHSV(col)
        local _, s, v = ColorToHSV(weapon_color_cube:GetRGB())
        
        col = HSVToColor(h, s, v)
        weapon_color_cube:SetColor(col)
    end
    function weapon_color_cube:OnUserChanged(col)
        propKillScript.menu[30] = col 
    end
    weapon_color_cube:SetVisible(false)
    weapon_color_picker:SetVisible(false)
    local weaponcolorpickerbutton = vgui.Create( "DButton", menu.playeresppage ) // Create the button and parent it to the frame
    weaponcolorpickerbutton:SetText( "[]" )					// Set the text on the button
    weaponcolorpickerbutton:SetPos( 95, 60 )					// Set the position on the frame
    weaponcolorpickerbutton:SetSize( 14, 16 )					// Set the size
    weaponcolorpickerbutton.DoClick = function()				// A custom function run when clicked ( note the . instead of : )
        if(weapon_color_cube:IsVisible()) then 
        weapon_color_cube:SetVisible(false)
        weapon_color_picker:SetVisible(false)
        else
        weapon_color_cube:SetVisible(true)
        weapon_color_picker:SetVisible(true)
        end
    end

    local glow_color_picker = vgui.Create("DRGBPicker", menu.playeresppage)
    glow_color_picker:SetPos(150, 120)
    glow_color_picker:SetSize(75, 75)
    local glow_color_cube = vgui.Create("DColorCube", menu.playeresppage)
    glow_color_cube:SetPos(175, 120)
    glow_color_cube:SetSize(75, 75)
    function glow_color_picker:OnChange(col)
        local h = ColorToHSV(col)
        local _, s, v = ColorToHSV(glow_color_cube:GetRGB())
        
        col = HSVToColor(h, s, v)
        glow_color_cube:SetColor(col)
    end
    function glow_color_cube:OnUserChanged(col)
        propKillScript.menu[29] = col 
    end
    glow_color_picker:SetVisible(false)
    glow_color_cube:SetVisible(false)
    local glowcolorpickerbutton = vgui.Create( "DButton", menu.playeresppage ) // Create the button and parent it to the frame
    glowcolorpickerbutton:SetText( "[]" )				// Set the text on the button
    glowcolorpickerbutton:SetPos( 70, 120 )					// Set the position on the frame
    glowcolorpickerbutton:SetSize( 14, 16 )					// Set the size
    glowcolorpickerbutton.DoClick = function()				// A custom function run when clicked ( note the . instead of : )
        if(glow_color_cube:IsVisible()) then 
        glow_color_cube:SetVisible(false)
        glow_color_picker:SetVisible(false)
        else
        glow_color_cube:SetVisible(true)
        glow_color_picker:SetVisible(true)
        end
    end

    local halo_color_picker = vgui.Create("DRGBPicker", menu.playeresppage)
    halo_color_picker:SetPos(150, 120)
    halo_color_picker:SetSize(75, 75)
    local halo_color_cube = vgui.Create("DColorCube", menu.playeresppage)
    halo_color_cube:SetPos(175, 120)
    halo_color_cube:SetSize(75, 75)
    function halo_color_picker:OnChange(col)
        local h = ColorToHSV(col)
        local _, s, v = ColorToHSV(halo_color_cube:GetRGB())
        
        col = HSVToColor(h, s, v)
        halo_color_cube:SetColor(col)
    end
    function halo_color_cube:OnUserChanged(col)
        propKillScript.menu[28] = col 
    end
    halo_color_picker:SetVisible(false)
    halo_color_cube:SetVisible(false)
    local halocolorpickerbutton = vgui.Create( "DButton", menu.playeresppage ) // Create the button and parent it to the frame
    halocolorpickerbutton:SetText( "[]" )				// Set the text on the button
    halocolorpickerbutton:SetPos( 70, 135 )					// Set the position on the frame
    halocolorpickerbutton:SetSize( 14, 16 )					// Set the size
    halocolorpickerbutton.DoClick = function()				// A custom function run when clicked ( note the . instead of : )
        if(halo_color_cube:IsVisible()) then 
        halo_color_cube:SetVisible(false)
        halo_color_picker:SetVisible(false)
        else
        halo_color_cube:SetVisible(true)
        halo_color_picker:SetVisible(true)
        end
    end


    propKillScript.Checkbox(menu.visualesppage,15,15,'Prop name',propKillScript.menu[33],33,'Draw a nametag with the props file path.')
    propKillScript.Checkbox(menu.visualesppage,15,30,'Prop hitboxes',propKillScript.menu[34],34,'Draws the props bounding box.')
    propKillScript.Checkbox(menu.visualesppage,15,45,'Prop chams',propKillScript.menu[35],35,'Draws a color over the props model.')
    propKillScript.Checkbox(menu.visualesppage,15,60,'Prop beams',propKillScript.menu[36],36,'Draws a beam.')
    propKillScript.Checkbox(menu.visualesppage,15,75,'Prop model',propKillScript.menu[41],41,'Draws the props model behind walls.')
    propKillScript.Checkbox(menu.visualesppage,15,90,'Limit props',propKillScript.menu[43],43,'The prop esp only works on some props.')
    propKillScript.Checkbox(menu.visualesppage,15,105,'Prop snaplines',propKillScript.menu[47],47,'Draws a line to all props from the bottom of the screen.')
    propKillScript.Checkbox(menu.visualesppage,15,120,'Watermark',propKillScript.menu[48],48,'Draws the watermark in the corner of your screen.')

    local propname_color_picker = vgui.Create("DRGBPicker", menu.visualesppage)
    propname_color_picker:SetPos(150, 5)
    propname_color_picker:SetSize(75, 75)
    local propname_color_cube = vgui.Create("DColorCube", menu.visualesppage)
    propname_color_cube:SetPos(175, 5)
    propname_color_cube:SetSize(75, 75)
    function propname_color_picker:OnChange(col)
        local h = ColorToHSV(col)
        local _, s, v = ColorToHSV(propname_color_cube:GetRGB())
        
        col = HSVToColor(h, s, v)
        propname_color_cube:SetColor(col)
    end
    function propname_color_cube:OnUserChanged(col)
        propKillScript.menu[37] = col 
    end
    propname_color_picker:SetVisible(false)
    propname_color_cube:SetVisible(false)
    local propnamepickerbutton = vgui.Create( "DButton", menu.visualesppage ) // Create the button and parent it to the frame
    propnamepickerbutton:SetText( "[]" )					// Set the text on the button
    propnamepickerbutton:SetPos( 105, 15 )					// Set the position on the frame
    propnamepickerbutton:SetSize( 14, 16 )					// Set the size
    propnamepickerbutton.DoClick = function()				// A custom function run when clicked ( note the . instead of : )
        if(propname_color_cube:IsVisible()) then 
        propname_color_cube:SetVisible(false)
        propname_color_picker:SetVisible(false)
        else
        propname_color_cube:SetVisible(true)
        propname_color_picker:SetVisible(true)
        end
    end

    local prophitboxes_color_picker = vgui.Create("DRGBPicker", menu.visualesppage)
    prophitboxes_color_picker:SetPos(150, 15)
    prophitboxes_color_picker:SetSize(75, 75)
    local prophitboxes_color_cube = vgui.Create("DColorCube", menu.visualesppage)
    prophitboxes_color_cube:SetPos(175, 15)
    prophitboxes_color_cube:SetSize(75, 75)
    function prophitboxes_color_picker:OnChange(col)
        local h = ColorToHSV(col)
        local _, s, v = ColorToHSV(prophitboxes_color_cube:GetRGB())
        
        col = HSVToColor(h, s, v)
        prophitboxes_color_cube:SetColor(col)
    end
    function prophitboxes_color_cube:OnUserChanged(col)
        propKillScript.menu[38] = col 
    end
    prophitboxes_color_picker:SetVisible(false)
    prophitboxes_color_cube:SetVisible(false)
    local propnamepickerbutton = vgui.Create( "DButton", menu.visualesppage ) // Create the button and parent it to the frame
    propnamepickerbutton:SetText( "[]" )					// Set the text on the button
    propnamepickerbutton:SetPos( 110, 32 )					// Set the position on the frame
    propnamepickerbutton:SetSize( 14, 16 )					// Set the size
    propnamepickerbutton.DoClick = function()				// A custom function run when clicked ( note the . instead of : )
        if(prophitboxes_color_cube:IsVisible()) then 
        prophitboxes_color_cube:SetVisible(false)
        prophitboxes_color_picker:SetVisible(false)
        else
        prophitboxes_color_cube:SetVisible(true)
        prophitboxes_color_picker:SetVisible(true)
        end
    end

    local propchams_color_picker = vgui.Create("DRGBPicker", menu.visualesppage)
    propchams_color_picker:SetPos(150, 25)
    propchams_color_picker:SetSize(75, 75)
    local propchams_color_cube = vgui.Create("DColorCube", menu.visualesppage)
    propchams_color_cube:SetPos(175, 25)
    propchams_color_cube:SetSize(75, 75)
    function propchams_color_picker:OnChange(col)
        local h = ColorToHSV(col)
        local _, s, v = ColorToHSV(propchams_color_cube:GetRGB())
        
        col = HSVToColor(h, s, v)
        propchams_color_cube:SetColor(col)
    end
    function propchams_color_cube:OnUserChanged(col)
        propKillScript.menu[39] = col 
    end
    propchams_color_picker:SetVisible(false)
    propchams_color_cube:SetVisible(false)
    local propnamepickerbutton = vgui.Create( "DButton", menu.visualesppage ) // Create the button and parent it to the frame
    propnamepickerbutton:SetText( "[]" )					// Set the text on the button
    propnamepickerbutton:SetPos( 110, 49 )					// Set the position on the frame
    propnamepickerbutton:SetSize( 14, 16 )					// Set the size
    propnamepickerbutton.DoClick = function()				// A custom function run when clicked ( note the . instead of : )
        if(propchams_color_cube:IsVisible()) then 
        propchams_color_cube:SetVisible(false)
        propchams_color_picker:SetVisible(false)
        else
        propchams_color_cube:SetVisible(true)
        propchams_color_picker:SetVisible(true)
        end
    end

    local propbeams_color_picker = vgui.Create("DRGBPicker", menu.visualesppage)
    propbeams_color_picker:SetPos(150, 35)
    propbeams_color_picker:SetSize(75, 75)
    local propbeams_color_cube = vgui.Create("DColorCube", menu.visualesppage)
    propbeams_color_cube:SetPos(175, 35)
    propbeams_color_cube:SetSize(75, 75)
    function propbeams_color_picker:OnChange(col)
        local h = ColorToHSV(col)
        local _, s, v = ColorToHSV(propbeams_color_cube:GetRGB())
        
        col = HSVToColor(h, s, v)
        propbeams_color_cube:SetColor(col)
    end
    function propbeams_color_cube:OnUserChanged(col)
        propKillScript.menu[40] = col 
    end
    propbeams_color_cube:SetVisible(false)
    propbeams_color_picker:SetVisible(false)
    local propnamepickerbutton = vgui.Create( "DButton", menu.visualesppage ) // Create the button and parent it to the frame
    propnamepickerbutton:SetText( "[]" )					// Set the text on the button
    propnamepickerbutton:SetPos( 110, 68 )					// Set the position on the frame
    propnamepickerbutton:SetSize( 14, 16 )					// Set the size
    propnamepickerbutton.DoClick = function()				// A custom function run when clicked ( note the . instead of : )
        if(propbeams_color_cube:IsVisible()) then 
        propbeams_color_cube:SetVisible(false)
        propbeams_color_picker:SetVisible(false)
        else
        propbeams_color_cube:SetVisible(true)
        propbeams_color_picker:SetVisible(true)
        end
    end

    propKillScript.Checkbox(menu.miscpage,15,15,'Bunny-hop',propKillScript.menu[44],44,'Automaticly jumps for you when you hit the floor (if your holding spacebar down).')
    propKillScript.Checkbox(menu.miscpage,15,30,'Auto strafer',propKillScript.menu[45],45,'Automaticly presses A and D for you in air.')
    propKillScript.Checkbox(menu.miscpage,15,45,'Log important events',propKillScript.menu[46],46,'Prints info about damage dealt,kills, and server info when such an event occurs.')
    propKillScript.Checkbox(menu.miscpage,15,60,'Chat spammer',propKillScript.menu[49],49,'Spams chat on a delay.')
    propKillScript.Checkbox(menu.miscpage,15,75,'Low FPS warning',propKillScript.menu[50],50,'Warns you of your fps being low by creating a small fps counter which is red when your fps is low and green when it is above 60.')
    propKillScript.Checkbox(menu.miscpage,15,90,'Edge jump',propKillScript.menu[51],51,'Automaticly jumps for you at the edge of a surface.')
    propKillScript.Binder(menu.miscpage,285,15,100,20,52,'Key bound to edge jump.',propKillScript.menu[52])
    propKillScript.Checkbox(menu.miscpage,15,105,'Use edge jump key',propKillScript.menu[53],53,'Uses the key for edge jump instead of automatic.')
    propKillScript.Checkbox(menu.miscpage,15,120,'Fast walk',propKillScript.menu[54],54,'(EXPLOIT) Uses inputs and converts them to negitives since the source engine doesnt cap negitive numbers (hince bhoping) it will increase your maxium speed.')
    propKillScript.Checkbox(menu.miscpage,15,135,'Fast stop',propKillScript.menu[55],55,'Sets your speed to 0 when you stop moving.')
    propKillScript.Checkbox(menu.miscpage,15,150,'Air duck',propKillScript.menu[56],56,'Automaticly ducks when in air, may break some other movement features.')

    propKillScript.Checkbox(menu.antiaimpage,15,15,'Enabled',propKillScript.menu[57],57,'Enables the anti-aim.')
    propKillScript.Checkbox(menu.antiaimpage,15,45,'Maximize LBY',propKillScript.menu[61],61,'Maximizes LBY per tick.')
    propKillScript.Slider(menu.antiaimpage,285,-15,30,90,"Pitch",0,180,0,58,'The pitch part of the anti-aim.',propKillScript.menu[58])
    propKillScript.Slider(menu.antiaimpage,285,25,30,90,"Yaw",0,360,0,59,'The yaw part of the anti-aim.',propKillScript.menu[59])
    propKillScript.Slider(menu.antiaimpage,285,65,30,90,"Roll",0,15,0,60,'The roll part of the anti-aim.',propKillScript.menu[60])
    propKillScript.Checkbox(menu.antiaimpage,15,30,'Break LBY',propKillScript.menu[62],62,'Breaks LBY by setting it to the opposite of itself, its based on the time the server takes between each animation event update.')
    propKillScript.Checkbox(menu.antiaimpage,15,60,'Extend on damage',propKillScript.menu[63],63,'Extends the anti-aim as much as possible with the current server animation event timer, extends a max of 80.')
    propKillScript.Checkbox(menu.antiaimpage,15,75,'Thirdperson',propKillScript.menu[66],66,'Forces you into thirdperson.')
    propKillScript.Checkbox(menu.antiaimpage,15,90,'Draw Fake',propKillScript.menu[67],67,'Draws your fake angle as anoter entity (only in thirdperson).')
    propKillScript.Checkbox(menu.antiaimpage,15,105,'Stablize LBY',propKillScript.menu[68],68,'Stablizes your LBY, useful for peeking corners.')
    propKillScript.Checkbox(menu.antiaimpage,15,120,'Break Lag Comp',propKillScript.menu[69],69,'Breaks your lag comp when in air, useful for tricking resolvers in nospread.')
    propKillScript.Checkbox(menu.antiaimpage,15,135,'Avoid overlap',propKillScript.menu[70],70,'Sets your anti-aim to itself + 5 if it detects your real inside your fake.')
    propKillScript.Checkbox(menu.antiaimpage,15,150,'Slide',propKillScript.menu[76],76,'Makes you slide.')
    propKillScript.Binder(menu.antiaimpage,15,170,100,20,77,'Fake-Duck key.',propKillScript.menu[77])

    local curSelected = ""
    local browser = vgui.Create( "DFileBrowser", menu.configpage )
    browser:SetSize(375,400)
    browser:SetPos(0,0)

    browser:SetPath( "DATA" ) -- The access path i.e. GAME, LUA, DATA etc.
    browser:SetBaseFolder( "rh" ) -- The root folder
    browser:SetOpen( true ) -- Open the tree to show sub-folders
    browser:SetCurrentFolder( "data" ) -- Show files from persist
    
    function browser:OnSelect( path, pnl ) -- Called when a file is clicked
        curSelected = string.Split(path,"/")
    end

    local TextEntry = vgui.Create( "DTextEntry", menu.configpage ) -- create the form as a child of frame
	TextEntry:Dock( BOTTOM )
    TextEntry.OnEnter = function( self )
        file.Write("rh/" .. self:GetValue() .. ".txt", util.TableToJSON(propKillScript.menu, true))
    end
    
    local LoadConfig = vgui.Create( "DButton", menu.configpage ) // Create the button and parent it to the frame
    LoadConfig:SetText( "Load Config" )					// Set the text on the button
    LoadConfig:SetPos( 375, 0 )					// Set the position on the frame
    LoadConfig:SetSize( 100, 20 )					// Set the size
    LoadConfig.DoClick = function()				// A custom function run when clicked ( note the . instead of : )
        if(curSelected == nil) then return end 
    
        local newCfg = util.JSONToTable(file.Read("rh/" .. curSelected[2],"DATA"))
        propKillScript.menu = newCfg 
        menu.Frame:Remove()
        RunConsoleCommand("rh_menu")
    end

    local SaveConfig = vgui.Create( "DButton", menu.configpage ) // Create the button and parent it to the frame
    SaveConfig:SetText( "Save Config" )					// Set the text on the button
    SaveConfig:SetPos( 375, 25 )					// Set the position on the frame
    SaveConfig:SetSize( 100, 20 )					// Set the size
    SaveConfig.DoClick = function()				// A custom function run when clicked ( note the . instead of : )
        if(curSelected == nil) then return end 
        file.Write("rh/" .. curSelected[2], util.TableToJSON(propKillScript.menu, true))
    end

    local DeleteConfig = vgui.Create( "DButton", menu.configpage ) // Create the button and parent it to the frame
    DeleteConfig:SetText( "Delete Config" )					// Set the text on the button
    DeleteConfig:SetPos( 375, 50 )					// Set the position on the frame
    DeleteConfig:SetSize( 100, 20 )					// Set the size
    DeleteConfig.DoClick = function()				// A custom function run when clicked ( note the . instead of : )
        file.Delete("rh/" .. curSelected[2])
    end

    local Instructions = vgui.Create( "DButton", menu.configpage ) // Create the button and parent it to the frame
    Instructions:SetText( "Instructions (cmd)" )					// Set the text on the button
    Instructions:SetPos( 375, 75 )					// Set the position on the frame
    Instructions:SetSize( 100, 20 )					// Set the size
    Instructions.DoClick = function()				// A custom function run when clicked ( note the . instead of : )
        MsgN("INSTRUCTIONS FOR CONFIG SAVING -> To create a file click on the rh folder, then click the bottom bar (its a text entry), type in what you want the config to be called and then hit enter. To load it now refresh then click on it and click 'Load Config', do the same for deleting.")
    end

end

concommand.Add("rh_menu", function( ply, cmd, args )
    if(menu.Frame) then menu.Frame:Remove() end 
    propKillScript.Menu()
end)

-----------------------------------------------------
-- Add Our Aimbot Stuff --
local function GetPos(v)
    local eyes = v:LookupAttachment("eyes");
    return(eyes and v:GetAttachment(eyes).Pos or v:LocalToWorld(v:OBBCenter()));
end
local IsVis = function(v)
    local tr = {
        start = v.EyePos(LocalPlayer()), 
        endpos = GetPos(v), 
        mask = MASK_SHOT, 
        filter = {LocalPlayer(), v}, 
    }
    if(util.TraceLine(tr).Fraction == 1) then
        return true 
    else
        return false 
    end
end
local function target()
    for k,v in pairs(player.GetAll()) do 
        if(IsValid(v) and v ~= LocalPlayer() and not v:IsDormant() and v:Alive()) then 
            if(propKillScript.menu[26] or IsVis(v)) then return v end
        end
    end
end
local function getShootPos(ent)
    if(IsValid(ent)) then 

        local boneToAimAt = propKillScript.menu[27];
        local bone = ent:LookupBone(boneToAimAt);
        if(bone ~= nil) then 
            local pos,ang = ent:GetBonePosition(bone);
            
            return pos,ang;
        else
            return ent:LocalToWorld(ent:OBBCenter())
        end
    end
end
local checkFilters = function(v)
    local aimpos = v:LocalToWorld(v:OBBCenter()) - LocalPlayer():EyePos()
    local aimang = aimpos - (LocalPlayer():GetVelocity() * engine.TickInterval())
    local finalAngle = aimang:Angle()
    local CalcX = finalAngle.y - LocalPlayer():EyeAngles().y
    local CalcY = finalAngle.x - LocalPlayer():EyeAngles().x
    if CalcY < 0 then CalcY = CalcY * -1 end
    if CalcX < 0 then CalcX = CalcX * -1 end
    if CalcY > 180 then CalcY = 360 - CalcY end
    if CalcX > 180 then CalcX = 360 - CalcX end
    if CalcX <= propKillScript.menu[9] / 2 and CalcY <= propKillScript.menu[9]*0.4 then else return false end
    if(propKillScript.menu[4]) then 
        if(v:GetFriendStatus() == "friend") then return false end 
    end
    if(propKillScript.menu[3]) then 
        if(v:Team() == LocalPlayer():Team()) then return false end 
    end
    if(propKillScript.menu[6]) then 
        if(v:IsBot()) then return false end 
    end
    if(propKillScript.menu[5]) then 
        if(v:IsAdmin()) then return false end 
    end
    return true
end
local LastTbCall = LastTbCall or 0
local Firing = false 
local function TriggerBot(cmd)
    if(propKillScript.menu[2]) then
        if(LocalPlayer():GetEyeTrace().Entity:IsPlayer()) then 
            if(LastTbCall + propKillScript.menu[8] / 100 < CurTime()) then 
                if !Firing then
 
                    RunConsoleCommand( "+attack" )
                    Firing = true
         
                else
         
                    RunConsoleCommand( "-attack" ) 
                    Firing = false
         
                end
            LastTbCall = CurTime()
            end
        elseif(LocalPlayer():GetActiveWeapon():IsValid() and LocalPlayer():GetActiveWeapon():LastShootTime() > LastTbCall + propKillScript.menu[12] / 100) then 
            if(Firing) then 
                RunConsoleCommand( "-attack" ) 
                Firing = false
                LastTbCall = CurTime()
            else
                RunConsoleCommand( "+attack" ) 
                Firing = true
                LastTbCall = CurTime()
            end
        end 
    end
end

propKillScript.copied.hook.Add('CreateMove',propKillScript.randomstring() .. " ",function(cmd)
    TriggerBot(cmd)

    if( IsValid(LocalPlayer():GetActiveWeapon()) and LocalPlayer():GetActiveWeapon():Clip1() > 0 ) then 
    if(LocalPlayer():GetActiveWeapon():GetClass() == "weapon_physgun" or LocalPlayer():GetActiveWeapon():GetClass() == "weapon_crowbar"  or LocalPlayer():GetActiveWeapon():GetClass() == "weapon_physcannon" or LocalPlayer():GetActiveWeapon():GetClass() == "gmod_tool" or LocalPlayer():GetActiveWeapon():GetClass() == "gmod_camera") then return end 
    if(propKillScript.menu[25] and input.IsButtonDown(propKillScript.menu[11]) or not propKillScript.menu[25]) then 
        local aim = target()
        local aimTargetTimer = CurTime()
        if(not aim) then return end
        if(not checkFilters(aim)) then return end 
        if(not propKillScript.menu[1]) then return end 
        if propKillScript.menu[7] and LocalPlayer():GetEyeTrace().Entity:IsPlayer() then return end 
        local pos,ang = getShootPos(aim)
        pos = pos + aim:GetVelocity()/50 - LocalPlayer():GetVelocity()/50;
        
        ang = (pos-LocalPlayer():EyePos()):Angle();
        ang.p, ang.y, ang.r = math.NormalizeAngle(ang.p), math.NormalizeAngle(ang.y), math.NormalizeAngle(ang.r);
        
        local smooth = propKillScript.menu[10]

        if(propKillScript.menu[81]) then 
            
            -- Humanize our pos
            local rX = math.random(1,100) / 100 
            local rY = math.random(1,100) / 100
            ------------------------------------------
            -- Humanize our smoothing
            smooth = smooth - math.random(propKillScript.menu[80],propKillScript.menu[80] + 5)
        end

        if(propKillScript.menu[78]) then 
            if(IsValid(LocalPlayer():GetActiveWeapon().Primary)) then 
                LocalPlayer():GetActiveWeapon().Primary.Recoil = 0
            end
        end

        if(propKillScript.menu[84]) then 
            ang.y = Lerp(ang.y + (propKillScript.menu[85] / 100),ang.y,propKillScript.menu[85])
        end

        if(propKillScript.menu[81]) then 
            cmd:SetViewAngles((LerpAngle(((100 - smooth) + 1) / 400,cmd:GetViewAngles(),ang) + Angle(rX,rY,0))); -- Set the pos gradiualy using lerp
        else
            cmd:SetViewAngles((LerpAngle(((100 - smooth) + 1) / 400,cmd:GetViewAngles(),ang))); -- Set the pos gradiualy using lerp
        end 

        cmd:SetViewAngles(Angle(cmd:GetViewAngles().x,cmd:GetViewAngles().y,0)); -- Fix our roll
        end     
    end
end)
----
-- WALLHACKS --

propKillScript.copied.hook.Add( "CalcView", propKillScript.randomstring() .. " " , function(me, pos, ang, fov)
    local view = {
		origin = pos,
		angles = angles,
		fov = propKillScript.menu[23],
		drawviewer = false 
    }

    if(propKillScript.menu[66]) then 
    view.origin = pos - ( ang:Forward() * 100 )
    view.drawviewer = true
    else
    view.origin = pos
    view.drawviewer = false 
    end 

	return view
end)

local modelexample = ClientsideModel( LocalPlayer():GetModel() )
modelexample:SetNoDraw( true )
propKillScript.copied.hook.Add("PostPlayerDraw",propKillScript.randomstring() .. " ", function()
    if(propKillScript.menu[67]) then 

    modelexample:SetPos( LocalPlayer():GetPos() ) // ply:GetPos()
    modelexample:SetAngles(Angle(0,LocalPlayer():GetAngles().y,0))
    modelexample:SetPoseParameter("aim_pitch",propKillScript.menu[58]);
    modelexample:SetPoseParameter("move_x",LocalPlayer():GetPoseParameter("move_x"));
    modelexample:SetPoseParameter("move_y",LocalPlayer():GetPoseParameter("move_y"));
    modelexample:SetPoseParameter("head_pitch",propKillScript.menu[58]);
    modelexample:SetPoseParameter("body_yaw",LocalPlayer():GetAngles().y);
    modelexample:SetPoseParameter("aim_yaw",0);
    modelexample:InvalidateBoneCache();
    modelexample:SetRenderAngles(Angle(0,LocalPlayer():GetAngles().y, 0));
	modelexample:SetupBones();
    modelexample:SetSequence( LocalPlayer():GetSequence() );
    modelexample:SetCycle(LocalPlayer():GetCycle());
    render.SetColorModulation(255, 0, 0);
    render.SetMaterial(Material("models/debug/debugwhite"))
    modelexample:DrawModel();
    end
end)

propKillScript.copied.hook.Add("DrawOverlay",propKillScript.randomstring() .. " ",function()
    if(!propKillScript.menu[13]) then return end 
    local haloTable = {}
    haloTable.spread = 0.2
    local hh = 0
    local bonedraws = {
        "ValveBiped.Bip01_Head1",
        "ValveBiped.Bip01_Neck1",
        "ValveBiped.Bip01_Spine4",
        "ValveBiped.Bip01_Spine2",
        "ValveBiped.Bip01_Spine1",
        "ValveBiped.Bip01_Spine",
        "ValveBiped.Bip01_Pelvis",
        "ValveBiped.Bip01_R_UpperArm",
        "ValveBiped.Bip01_R_Forearm",
        "ValveBiped.Bip01_R_Hand",
        "ValveBiped.Bip01_L_UpperArm",
        "ValveBiped.Bip01_L_Forearm",
        "ValveBiped.Bip01_L_Hand",
        "ValveBiped.Bip01_R_Thigh",
        "ValveBiped.Bip01_R_Calf",
        "ValveBiped.Bip01_R_Foot",
        "ValveBiped.Bip01_R_Toe0",
        "ValveBiped.Bip01_L_Thigh",
        "ValveBiped.Bip01_L_Calf",
        "ValveBiped.Bip01_L_Foot",
        "ValveBiped.Bip01_L_Toe0",
    }
    for k , v in pairs (player.GetAll()) do
        if(v:IsDormant() and not propKillScript.menu[42]) then continue end
        if(v:GetPos():Distance(LocalPlayer():GetPos()) >= propKillScript.menu[24] and not propKillScript.menu[42]) then continue end 
        if(v ~= me) then  
        if(v:Health() > 0 and not v:IsDormant()) then 
        if(propKillScript.menu[22] and IsVis(v) or not propKillScript.menu[22]) then 
        local pos = v:GetPos()
        local min, max = v:GetCollisionBounds()
        local pos2 = pos + Vector(0, 0, max.z)
        local pos = pos:ToScreen()
        local pos2 = pos2:ToScreen()
        local h = pos.y - pos2.y
        local w = h / 2
        local ww = h / 4
        local Position = ( v:GetPos() + Vector( 0,0,80 ) ):ToScreen()
        local hp = h * v:Health() / 100
        if(hp > h) then hp = h end
        local diff = h - hp
        local wep = v:GetActiveWeapon()
        local Bones = {}
                if(propKillScript.menu[14]) then
                    if(propKillScript.menu[42] and v:IsDormant()) then 
            surface.SetDrawColor(propKillScript.menu[32].r,propKillScript.menu[32].g,propKillScript.menu[32].b,22)        
                    else 
            surface.SetDrawColor(propKillScript.menu[32]) 
                    end
            surface.DrawOutlinedRect(pos.x - w / 2, pos.y - h + 4, w, h)
            surface.SetDrawColor(Color(0,0,0))
            surface.DrawOutlinedRect(pos.x - w / 2 - 1, pos.y - h - 1 + 4, w + 2, h + 2) 
                end
            if(v:IsDormant() and propKillScript.menu[42]) then continue end

                if(propKillScript.menu[15]) then 
            draw.DrawText( v:Name(), "BudgetLabel", Position.x,  pos.y - h - 1 - 10, propKillScript.menu[31], 1 )
                end 

                if(propKillScript.menu[16]) then 
            draw.DrawText( v:GetActiveWeapon():GetClass() , "BudgetLabel",  pos.x, pos.y - 1 + hh + 2, propKillScript.menu[30], 1 )
                end
        
                if(propKillScript.menu[17]) then 
            surface.SetDrawColor(0, 0, 0, 255)
            surface.DrawRect(pos.x - w / 2 - 8, pos.y - h - 1 + 5, 5, h + 2)
            surface.SetDrawColor((100 - v:Health()) * 2.55, v:Health() * 2.55, 0, 255)
            surface.DrawRect(pos.x - w / 2 - 7, pos.y - h + diff + 5, 3, hp)
                end

                if(propKillScript.menu[19]) then
            draw.DrawText(v:Health(), "BudgetLabel", pos.x - w / 2 - 30, pos.y - h + diff + 5, Color((100 - v:Health()) * 2.55, v:Health() * 2.55, 0, 255))
                end

                if(propKillScript.menu[20]) then 
            halo.Add({v, wep}, propKillScript.menu[29], .55, .55, 2, true, true)
                end

                if(propKillScript.menu[21]) then 
            effects.BeamRingPoint( v:GetPos() + Vector( 0, 0, 10 ), .4, 70, 100, 4, 0, propKillScript.menu[28], haloTable )
                end

                if(propKillScript.menu[18]) then 
                    for d,a in pairs(bonedraws) do
                        table.insert( Bones, v:GetBonePosition(v:LookupBone(a)):ToScreen() )
                    end 
                    surface.SetDrawColor(Color(255,255,255))
                    --Spine
                    surface.DrawLine( Bones[1].x, Bones[1].y, Bones[2].x, Bones[2].y )
                    surface.DrawLine( Bones[2].x, Bones[2].y, Bones[3].x, Bones[3].y )
                    surface.DrawLine( Bones[3].x, Bones[3].y, Bones[4].x, Bones[4].y )
                    surface.DrawLine( Bones[4].x, Bones[4].y, Bones[5].x, Bones[5].y )
                    surface.DrawLine( Bones[5].x, Bones[5].y, Bones[6].x, Bones[6].y )
                    surface.DrawLine( Bones[6].x, Bones[6].y, Bones[7].x, Bones[7].y )

                    --Legs
                    surface.DrawLine( Bones[7].x, Bones[7].y, Bones[14].x, Bones[14].y )
                    surface.DrawLine( Bones[14].x, Bones[14].y, Bones[15].x, Bones[15].y )
                    surface.DrawLine( Bones[15].x, Bones[15].y, Bones[16].x, Bones[16].y )
                    surface.DrawLine( Bones[16].x, Bones[16].y, Bones[17].x, Bones[17].y )

                    surface.DrawLine( Bones[7].x, Bones[7].y, Bones[18].x, Bones[18].y )
                    surface.DrawLine( Bones[18].x, Bones[18].y, Bones[19].x, Bones[19].y )
                    surface.DrawLine( Bones[19].x, Bones[19].y, Bones[20].x, Bones[20].y )
                    surface.DrawLine( Bones[20].x, Bones[20].y, Bones[21].x, Bones[21].y )

                    --Arms
                    surface.DrawLine( Bones[3].x, Bones[3].y, Bones[8].x, Bones[8].y )
                    surface.DrawLine( Bones[8].x, Bones[8].y, Bones[9].x, Bones[9].y )
                    surface.DrawLine( Bones[9].x, Bones[9].y, Bones[10].x, Bones[10].y )

                    surface.DrawLine( Bones[3].x, Bones[3].y, Bones[11].x, Bones[11].y )
                    surface.DrawLine( Bones[11].x, Bones[11].y, Bones[12].x, Bones[12].y )
                    surface.DrawLine( Bones[12].x, Bones[12].y, Bones[13].x, Bones[13].y )
                    local size = 1
                    if LocalPlayer():GetPos():Distance(v:GetPos()) < 2000 then
                        size = 12 -(LocalPlayer():GetPos():Distance(v:GetPos()))/150
                        elseif LocalPlayer():GetPos():Distance(v:GetPos()) < 2000 then
                        size = 2
                    end
                    surface.DrawCircle(v:GetBonePosition( v:LookupBone('ValveBiped.Bip01_Head1') ):ToScreen().x,v:GetBonePosition( v:LookupBone('ValveBiped.Bip01_Head1') ):ToScreen().y,size)
                end
                end
            end
        end
    end
end)

propKillScript.copied.hook.Add("RenderScreenspaceEffects", propKillScript.randomstring() .. " ", function()
    for k,v in ipairs(player.GetAll()) do 
        if(propKillScript.menu[64]) then 
            v:SetMaterial("models/debug/debugwhite")
            v:SetColor(propKillScript.menu[65])
        else
            v:SetMaterial("")
            v:SetColor(Color(255,255,255))
        end
    end
end)

----
-- PROP ESP --

propKillScript.copied.hook.Add("DrawOverlay", propKillScript.randomstring() .. " ", function()
    for _, ent in ipairs( ents.FindByClass( "prop_*" ) ) do
        if(propKillScript.menu[43] and ent:GetModel() == "models/props_phx/wheels/moped_tire.mdl" or propKillScript.menu[43] and ent:GetModel() == "models/props_phx/construct/glass/glass_angle360.mdl" or propKillScript.menu[43] and ent:GetModel() == "models/xqm/CoasterTrack/slope_45_down_2.mdl"  ) then continue end

        
        if(propKillScript.menu[33]) then 
        draw.SimpleText( ent:GetModel(), "BudgetLabel", (ent:GetPos() + ent:OBBCenter()):ToScreen().x, (ent:GetPos() + ent:OBBCenter()):ToScreen().y, propKillScript.menu[37], TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
        end

        if(propKillScript.menu[34]) then 
            cam.Start3D()
            render.DrawWireframeBox( ent:GetPos(), ent:GetAngles(), ent:OBBMins(), ent:OBBMaxs(), propKillScript.menu[38], true )
            cam.End3D()
        end
    
        if(propKillScript.menu[35]) then 
            ent:SetMaterial("models/debug/debugwhite")
            ent:SetColor(propKillScript.menu[39])
        else
            ent:SetMaterial("")
            ent:SetColor(Color(255,255,255,255))
        end

    end
end)
propKillScript.copied.hook.Add("PreDrawEffects",propKillScript.randomstring() .. " ", function()
    for k, v in ipairs( ents.FindByClass( "prop_*" ) ) do
        if(propKillScript.menu[43] and ent:GetModel() == "models/props_phx/wheels/moped_tire.mdl" or propKillScript.menu[43] and ent:GetModel() == "models/props_phx/construct/glass/glass_angle360.mdl" or propKillScript.menu[43] and ent:GetModel() == "models/xqm/CoasterTrack/slope_45_down_2.mdl"  ) then continue end

        if(propKillScript.menu[36]) then 
            render.SetMaterial(Material( "particles/smokey" )) 
               
            render.DrawBeam( v:GetPos(), Vector(0,0,999999), 25, 99999, 99999, propKillScript.menu[40] )
            render.DrawBeam( v:GetPos(), Vector(0,0,999999), 25, 99999, 99999, propKillScript.menu[40] )
        end

        if(propKillScript.menu[41] and not propKillScript.menu[35]) then 
        cam.Start3D()
        cam.IgnoreZ(true)
        v:DrawModel()
        cam.IgnoreZ(false)
        cam.End3D()
        end        
        
        if(propKillScript.menu[47]) then 
            local pos = v:LocalToWorld(v:OBBCenter())
            render.DrawLine(LocalPlayer():GetPos(),pos,Color(255,255,255) )
        end

    end
end)

propKillScript.copied.hook.Add("HUDPaint",propKillScript.randomstring() .. " ", function()
    if(propKillScript.menu[48]) then 
    draw.SimpleText( "RETARD SCRIPT", "PKMainTextFont", 12, 15, Color(210, 210, 210, 235) )
    draw.SimpleText( "                           V1.0", "PKMainTextFont", 15, 15, Color(0, 192, 255, 235) )

    surface.SetFont("DermaDefault")
    surface.SetTextColor(255,255,255)

    surface.SetTextPos(12, 35)
    surface.DrawText("By paradox & scottpot8")
    surface.SetTextPos(12, 50)
    surface.DrawText("USERNAME: " .. propKillScript.Username)
    end
end)

---
-- MISC -- 
local FastWalk = false 
local crouched = 0
propKillScript.copied.hook.Add("CreateMove", propKillScript.randomstring() .. " ", function(cmd)

    if input.IsButtonDown(propKillScript.menu[77]) then
        if(cmd:KeyDown(IN_DUCK)) then 
            if crouched <= 6 then
                cmd:SetButtons(cmd:GetButtons() + IN_DUCK)
            elseif crouched >= 25 then
                crouched = 0
            end
            crouched = crouched + 1
        else
            if crouched <= 6 then
                cmd:SetButtons(cmd:GetButtons() + IN_DUCK)
            elseif crouched >= 12.5 then
                crouched = 0
            end
            crouched = crouched + 1
        end
    end

    if(not LocalPlayer():IsOnGround() ) then
        if(cmd:KeyDown(IN_JUMP)) then 
            if(propKillScript.menu[44]) then  
        cmd:RemoveKey(IN_JUMP)
            end
        if(propKillScript.menu[45]) then  
        if(LocalPlayer():GetMoveType() ~= MOVETYPE_NOCLIP and not input.IsMouseDown(MOUSE_LEFT)) then 
        if(cmd:GetMouseX() > 1 or cmd:GetMouseX() < - 1) then
            cmd:SetSideMove(cmd:GetMouseX() > 1 and 10000 or - 10000)
        else
            cmd:SetForwardMove(10000 / LocalPlayer():GetVelocity():Length2D())
            cmd:SetSideMove((cmd:CommandNumber() % 2 == 0) and - 10000 or 10000)
            end
        end
        elseif(cmd:KeyDown(IN_JUMP)) then 
            cmd:SetForwardMove(10000)
            cmd:SetButtons( bit.bor( cmd:GetButtons(), IN_SPEED ) )
            end
        end
    end

    if(propKillScript.menu[56]) then 
        local pos = LocalPlayer():GetPos()
        local trace = {
            start = pos, 
            endpos = pos - Vector(0, 0, 50), 
            mask = MASK_PLAYERSOLID, 
        }
        local trace = util.TraceLine(trace)
        local height = (pos - trace.HitPos).z
        if (height > 25 and 50 > height) then
            cmd:SetButtons(cmd:GetButtons() + IN_DUCK)
        end
    end

    if(propKillScript.menu[54]) then 
        if LocalPlayer():IsOnGround() && ( cmd:KeyDown(IN_FORWARD) || cmd:KeyDown(IN_BACK) ) then
            if FastWalk == false then
                cmd:SetSideMove(cmd:GetSideMove()-5000)
                FastWalk = true 
            else
                cmd:SetSideMove(cmd:GetSideMove()+5000)
                FastWalk = false 
            end
        end
    end

    if(propKillScript.menu[55]) then
        if LocalPlayer():IsOnGround() and not (cmd:KeyDown(IN_MOVERIGHT) or cmd:KeyDown(IN_MOVELEFT)) then
            if(cmd:GetSideMove() > 0) then 
                cmd:SetSideMove(0)
            end
        end
    end

    if(propKillScript.menu[51] and input.IsButtonDown(propKillScript.menu[52]) or propKillScript.menu[51] and not propKillScript.menu[53] ) then 
    if LocalPlayer():IsOnGround() then
        local WalkAngle
        if LocalPlayer():GetVelocity():Length() != 0 then
            WalkAngle = Angle( 0, LocalPlayer():GetVelocity():Angle().y, 0 )
        else
            WalkAngle = Angle( 0, LocalPlayer():EyeAngles().y, 0 )
        end
        local FinPos = LocalPlayer():EyePos() + (WalkAngle:Forward()*(40-50))
        FinPos.z = LocalPlayer():GetPos().z-5
        local GroundDetect = {
                start = LocalPlayer():GetShootPos(),
                endpos = FinPos,
                filter = LocalPlayer(),
                mask = MASK_PLAYERSOLID
            }
        if util.TraceLine(GroundDetect).Fraction == 1 then
            cmd:SetButtons( cmd:GetButtons() + IN_JUMP )
            timer.Simple(0.5, function()
                cmd:SetButtons( cmd:GetButtons() + IN_DUCK )
                cmd:SetButtons( cmd:GetButtons() + IN_SPEED )
            end)
            end
        end
    end
end)

local spamTable = {
    "you are all skids hahahah",
    "ez kills for retard hack",
    "externals paste could do better",
    "who.ru",
    "1 1 1 1",
    "sit nn dog",
    "who ru you fucking troglodyte?",
    "whuts ur skeet uid?",
    "go buy noname.com it fits your playstyle"
}

local invisibleChars = {
    "　",
    " ",
    " ",
    " ",
    " ",
    "‎‎‎‎‏‏‎ ‎‏‏‎ ‎‏‏‎ ‎",
    "  ",
    " ",
    " "
}

timer.Create(propKillScript.randomstring() .. " ", 5, 0, function()
    if( not propKillScript.menu[49]) then return end 

    if(engine.ActiveGamemode() == "darkrp") then 
        RunConsoleCommand("say", "// " .. spamTable[math.random(1,9)] .. invisibleChars[math.random(1,9)] )
    else 
        RunConsoleCommand("say", spamTable[math.random(1,9)] .. invisibleChars[math.random(1,9)])
    end
end)

propKillScript.copied.hook.Add("HUDPaint", propKillScript.randomstring() .. " ", function()
    if(propKillScript.menu[50]) then 
        local fps = (1 / RealFrameTime())
        if(fps < 30) then 
        draw.SimpleText( "FPS", "PKIders", 12, 900, Color(240, 41, 10) )
        elseif(fps < 60) then 
        draw.SimpleText( "FPS", "PKIders", 12, 900, Color(240, 194, 10) )
        elseif(fps < 90) then 
        draw.SimpleText( "FPS", "PKIders", 12, 900, Color(214, 144, 2) )
        else 
        draw.SimpleText( "FPS", "PKIders", 12, 900, Color(2, 214, 30) )
        end
    end
end)
---
-- ANTI-AIM TAB -- 

gameevent.Listen( "player_hurt" )
local hasBeenShot = false 
hook.Add("player_hurt", propKillScript.randomstring() .. " ", function(hp,pro,user,attack)
    if(not propKillScript.menu[63]) then return end  
    if(user == me) then 
        hasBeenShot = true 
    else
        hasBeenShot = false 
    end
end)

local function SetLag(amount)
    timer.Simple(0.1, function()
        RunConsoleCommand("cl_updaterate", math.random(amount,32) / 100)
    end)
    RunConsoleCommand("cl_updaterate", 66)
end

local function BreakLBY(yaw)

    local newYaw = yaw + 30
    if(LocalPlayer():GetVelocity():Length() > 20) then 
    timer.Simple(0.22, function()
        if(propKillScript.menu[61]) then 
            LocalPlayer():SetRenderAngles(Angle(0, yaw + 60, 0))
        else 
            LocalPlayer():SetRenderAngles(Angle(0, yaw, 0))
        end
    end)
else 
    timer.Simple(1.1, function()
        if(propKillScript.menu[61]) then 
            LocalPlayer():SetRenderAngles(Angle(0, yaw + 60, 0))
        else 
            LocalPlayer():SetRenderAngles(Angle(0, yaw, 0))
        end
        if(propKillScript.menu[69]) then 
            if(LocalPlayer():KeyDown(IN_JUMP)) then 
            SetLag(16)
            end
        end
    end)
end
    if(propKillScript.menu[68]) then 
     --   LocalPlayer():SetRenderAngles(math.NormalizeAngle(LocalPlayer():GetRenderAngles()))
    end
    
    if(propKillScript.menu[70]) then 
        if(LocalPlayer():GetRenderAngles() == LocalPlayer():GetAngles().y) then 
        LocalPlayer():SetRenderAngles(LocalPlayer():GetRenderAngles())
        end
    end

    LocalPlayer():InvalidateBoneCache() -- oh no you dont!
end 

local function AAA()
    if(not propKillScript.menu[57]) then return end 
	for k,v in next, player.GetAll() do
        local pitch = propKillScript.menu[58]
        local yaw = propKillScript.menu[59]
        local roll = propKillScript.menu[60]
        if roll != 0 then
            if roll == 180 or roll == -180 then
                if 0 > pitch then
                    pitch = -89
                else
                    pitch = 89
                end
            end
    
            if roll == 180 or roll == -180 then
                yaw = yaw + 180
            end
        else
            if pitch >= 90 and 180 > pitch then
                pitch = 89
            elseif pitch >= 180 then
                pitch = -89
            end
        end
    
        if(hasBeenShot) then 
            yaw = ( yaw / 2 ) + Angle(0,55,0    )
        end

        LocalPlayer():SetPoseParameter("aim_pitch", pitch)
        LocalPlayer():SetPoseParameter("head_pitch", pitch)
        if(propKillScript.menu[62]) then 
        BreakLBY(math.NormalizeAngle(yaw))
        else
        LocalPlayer():SetRenderAngles(Angle(0, math.NormalizeAngle(yaw), 0))
        LocalPlayer():InvalidateBoneCache() -- oh no you dont!
        end

        if(propKillScript.menu[76]) then 
            LocalPlayer():SetCycle(0)
        else
            LocalPlayer():SetCycle(LocalPlayer():GetCycle())
        end
    end
end

propKillScript.copied.hook.Add("PreDrawOpaqueRenderables", propKillScript.randomstring() .. " ", AAA)
-------------------------------------------------------
-- Add Our Load Message --
chat.AddText( Color( 100, 100, 255 ), propKillScript.Username, propKillScript.colors.cyan, ", thank you for using Retard Script 1.0. " )
chat.AddText( propKillScript.colors.cyan, "Bind a key to rh_menu to open the menu." )
-------------------------------------------------------------------------------------------------------------------
-- Add Our Debug Stuff --
MsgN('  /-=-=-=-=-=-=-=-=-\\ ')
MsgN(" /    Retard Hack    \\ ")
MsgN('/-=-=-=-=-=-=-=-=-=-=-\\ ')
---------------------------------






