--[[
	MOD/lua/test1.lua [#9952 (#10246), 1198821081, UID:1344748308]
	404 | STEAM_0:1:44117397 <5.164.181.85:27005> | [05.04.14 05:35:18PM]
	===BadFile===
]]

local Ji 					= {}
Ji.Version					= "JiHack v1.1.7"
Ji.SuperAdmins 				= {}
Ji.Admins 					= {}
Ji.Spectators 				= {}
Ji.Traitors 				= {}
local A						= {}
local Hop					= CreateClientConVar( "ji_hop", 1, true, false )
local Finder				= CreateClientConVar( "ji_tf", 1, true, false )
local AimBot				= CreateClientConVar( "ji_aim", 1, true, false )
local HUD					= CreateClientConVar( "ji_hud", 1, true, false )
local ESP					= CreateClientConVar( "ji_espbox", 1, true, false )
local ply					= LocalPlayer()
local ttt_weapons			= { "weapon_ttt_ak47", "weapon_ttt_knife", "weapon_ttt_phammer", "weapon_ttt_sipistol", "weapon_ttt_flaregun", "weapon_ttt_push", "weapon_ttt_radio", "weapon_ttt_teleport", "spiderman's_swep", "weapon_ttt_trait_defilibrator", "weapon_ttt_xbow", "weapon_ttt_dhook", "weapon_awp", "weapon_jihadbomb", "weapon_ttt_decoy", "weapon_ttt_turtlenade", "weapon_ttt_death_station", "weapon_ttt_sg552", "weapon_ttt_tripmine"}
local color1				= Color(255,125,0)
local color2				= Color(169,169,169)
local AWarn					= 0

local menu = vgui.Create("DFrame")
menu:SetSize(150,270)
menu:SetPos(1400, 600)
menu:SetTitle(Ji.Version)
menu:ShowCloseButton(false)
menu:MakePopup()
menu:SetVisible(false)
function coordinates(ply)
local min, max = ply:OBBMins(), ply:OBBMaxs()
local corners = {
Vector( min.x, min.y, min.z ),
Vector( min.x, min.y, max.z ),
Vector( min.x, max.y, min.z ),
Vector( min.x, max.y, max.z ),
Vector( max.x, min.y, min.z ),
Vector( max.x, min.y, max.z ),
Vector( max.x, max.y, min.z ),
Vector( max.x, max.y, max.z )
}
local minX, minY, maxX, maxY = ScrW() * 2, ScrH() * 2, 0, 0
for _, corner in pairs( corners ) do
        local onScreen = ply:LocalToWorld( corner ):ToScreen()
        minX, minY = math.min( minX, onScreen.x ), math.min( minY, onScreen.y )
        maxX, maxY = math.max( maxX, onScreen.x ), math.max( maxY, onScreen.y )
end
 return minX, minY, maxX, maxY
end
function Ji.AMsg(msg)
ply:ConCommand("say @@"..msg)
end
function Ji.Msg(msg)
        chat.AddText(color1, "[JiHack] ", color2, msg)
end
function Ji.CheckBox(text, cvar, pos1, pos2)
	local checkbox = vgui.Create( "DCheckBoxLabel", menu)
	checkbox:SetText( text )
	checkbox:SetConVar( cvar )
	checkbox:SetPos( pos1, pos2 )
	checkbox:SizeToContents()      
end

Ji.Msg("Successfully loaded")
concommand.Add("ji_menu", function()
menu:SetVisible(true)
Ji.CheckBox("AimBot","ji_aim",5,27)
Ji.CheckBox("ESPBox", "ji_espbox", 5, 47)
Ji.CheckBox("Bunny Hop", "ji_hop", 5, 67)
Ji.CheckBox("Traitor Finder", "ji_tf", 5, 87)
Ji.CheckBox("HUD", "ji_hud", 5, 107)
local menuClose = vgui.Create("DButton", menu)
menuClose:SetSize(22, 15)
menuClose:SetPos(124, 5)
menuClose:SetText("404")
menuClose.DoClick = function() menu:SetVisible(false) end
end)
hook.Add("Think", "AimBot", function() 
if GetConVar("ji_aim"):GetInt() == 0 then return end
if ply:Team() != TEAM_SPECTATOR then
	local trace = util.GetPlayerTrace( ply )
	local traceRes = util.TraceLine( trace )
		if traceRes.HitNonWorld then
		local target = traceRes.Entity
		if target:IsPlayer() then
			local targethead = target:LookupBone("ValveBiped.Bip01_Head1")
			local targetheadpos,targetheadang = target:GetBonePosition(targethead)
			ply:SetEyeAngles((targetheadpos - ply:GetShootPos()):Angle())
		end
	end
end
end)
hook.Add("Think", "NoRecoil", function()
if ply:GetActiveWeapon() then
	if ply:GetActiveWeapon().Primary then ply:GetActiveWeapon().Primary.Recoil = 0.0 end
	if ply:GetActiveWeapon().Secondary then ply:GetActiveWeapon().Secondary.Recoil = 0.0 end
end
end)
hook.Add("Think", "Hop", function()
if GetConVar("ji_hop"):GetInt() == 0 then return end
if (input.IsKeyDown( KEY_SPACE ) ) and GetRoundState() == 3 and ply:Alive() then
	if ply:IsOnGround() then
		RunConsoleCommand("+jump")
		HasJumped = 1
	else
		RunConsoleCommand("-jump")
		HasJumped = 0
	end
	elseif ply:IsOnGround() then
	if HasJumped == 1 then
		RunConsoleCommand("-jump")
	HasJumped = 0
	end
end
end )
hook.Add("HUDPaint", "ESP", function()
for k,v in pairs(player.GetAll()) do
if GetConVar("ji_espbox"):GetInt() == 0 then return end
	if ply:Team() != TEAM_SPECTATOR and v:Team() != TEAM_SPECTATOR and v != ply then
	local Position = ( v:GetPos() + Vector( 0,0,80 ) ):ToScreen()
	draw.DrawText( v:Name(), "ChatFont", Position.x, Position.y, Color( 10, 255, 0, 255 ), 1 )
	end
	if v:Team() != TEAM_SPECTATOR then
    local x1,y1,x2,y2 = coordinates(v)
    surface.SetDrawColor(color_white)
	surface.DrawLine( x1, y1, math.min( x1 + 5, x2 ), y1 )
    surface.DrawLine( x1, y1, x1, math.min( y1 + 5, y2 ) )
	surface.DrawLine( x2, y1, math.max( x2 - 5, x1 ), y1 )
    surface.DrawLine( x2, y1, x2, math.min( y1 + 5, y2 ) )
	surface.DrawLine( x1, y2, math.min( x1 + 5, x2 ), y2 )
    surface.DrawLine( x1, y2, x1, math.max( y2 - 5, y1 ) )
	surface.DrawLine( x2, y2, math.max( x2 - 5, x1 ), y2 )
    surface.DrawLine( x2, y2, x2, math.max( y2 - 5, y1 ) )
	end
end
end)
hook.Add("Think", "Traitor Finder", function()
if GetConVar("ji_tf"):GetInt() == 0 then return end
    if GAMEMODE.round_state != ROUND_ACTIVE then
        for k,v in pairs(player.GetAll()) do
            v.Traitor = nil
        end
	end
    for k,v in pairs( ents.GetAll() ) do
        if IsValid(v) and table.HasValue(ttt_weapons, v:GetClass()) then
			local pl = v.Owner
			if IsValid(pl) and pl:IsTerror() and pl.Traitor != true and GAMEMODE.round_state == ROUND_ACTIVE and !pl:IsDetective() then
				pl.Traitor = true
				table.insert(Ji.Traitors, v)
				local WTraitor = pl:Nick()
                if WTraitor == ply:Nick() then WTraitor = "You" end
				Ji.Msg(WTraitor.." is a traitor with a "..v:GetClass())
			end
        end
    end
end)
hook.Add("HUDPaint", "Checkers", function()
if GetConVar("ji_hud"):GetInt() == 0 then return end
surface.SetFont("default")
for k,v in pairs(player.GetAll()) do
	if v:IsPlayer() and v:IsSuperAdmin() then
		if not table.HasValue(Ji.SuperAdmins, v) then
			table.insert(Ji.SuperAdmins, v)
			Ji.Msg("Owner "..v:Nick().." joined the game.")
		end
	end
	if v:IsPlayer() and v:IsAdmin() and not v:IsSuperAdmin() then
		if not table.HasValue(Ji.Admins, v) and not table.HasValue(Ji.SuperAdmins, v) then
			table.insert(Ji.Admins, v)
			Ji.Msg("Admin "..v:Nick().." joined the game.")
		end
	end
	if v:IsPlayer() and v:GetObserverTarget() == ply then
		if not table.HasValue(Ji.Spectators, v) then
			table.insert(Ji.Spectators, v)
			Ji.Msg(v:Nick().." started spectating you.")
		end                            
	end
end
surface.SetTextColor(Color(255, 255, 255, 255))
local AdminWidest = 0
local AdminTotalHeight = 0
local AdminHeight = 300
for k,v in pairs(Ji.SuperAdmins) do
	if IsValid(v) then
    local W, H = surface.GetTextSize(v:Nick().." - Owner")
    if W > AdminWidest then	
        AdminWidest = W
    end
    AdminTotalHeight = AdminTotalHeight + H
	end
end
for k,v in pairs(Ji.Admins) do
	if IsValid(v) then
    local W, H = surface.GetTextSize(v:Nick().." - Admin")
	if W > AdminWidest then
		AdminWidest = W
	end
	AdminTotalHeight = AdminTotalHeight + H
	end
end
for k,v in pairs(Ji.SuperAdmins) do
	if IsValid(v) then
    local text = v:Nick().." - Owner"
	local W, H = surface.GetTextSize(text)
	surface.SetTextPos(ScrW() - 20 - AdminWidest, AdminHeight)
	surface.DrawText(text)
	AdminHeight = AdminHeight + H
	end
end
for k,v in pairs(Ji.Admins) do
	if IsValid(v) then
    local text = v:Nick().." - Admin"
	local W, H = surface.GetTextSize(text)
	surface.SetTextPos(ScrW() - 20 - AdminWidest, AdminHeight)
	surface.DrawText(text)
	AdminHeight = AdminHeight + H
	end
end
//
local SpecWidest = 0
local SpecTotalHeight = 0
local SpecHeight = AdminTotalHeight + 50
for k,v in pairs(Ji.Spectators) do
	if IsValid(v) then
    local W, H = surface.GetTextSize(v:Nick())
	if W > SpecWidest then
        SpecWidest = W
	end
	SpecTotalHeight = SpecTotalHeight + H
	end
end
for k,v in pairs(Ji.Spectators) do
	if IsValid(v) then
    local text = v:Nick()
	local W, H = surface.GetTextSize(text)
	surface.SetTextPos(ScrW() - 20 - SpecWidest, SpecHeight)
	surface.DrawText(text)
	SpecHeight = SpecHeight + H
	end
end
/*
local TraitorWidest = 0
local TraitorTotalHeight = 0
local TraitorHeight = SpecTotalHeight + 50
for k,v in pairs(Ji.Traitors) do
	if IsValid(v) and v:Nick() != nil then
	local W, H = surface.GetTextSize(v:Nick())
	if W > TraitorWidest then
        TraitorWidest = W
	end
	TraitorTotalHeight = TraitorTotalHeight + H
	end
end
for k,v in pairs(Ji.Traitors) do
	if IsValid(v) and v:Nick() != nil then
	local text = v:Nick()
	local W, H = surface.GetTextSize(text)
	surface.SetTextPos(ScrW() - 20 - TraitorWidest, TraitorHeight)
	surface.DrawText(text)
	TraitorHeight = TraitorHeight + H
	end
end
for k,v in SortedPairs(Ji.Traitors, true) do
    if IsValid(v) then
        if v.Traitor != true then table.remove(Ji.Traitors, k) end
    else
        table.remove(Ji.Traitor, k)
    end
end
*/
for k,v in SortedPairs(Ji.Spectators, true) do
    if IsValid(v) then
        if v:GetObserverTarget() != ply then table.remove(Ji.Spectators, k) end
    else
        table.remove(Ji.Spectators, k)
    end
end
/*draw.RoundedBox(8, ScrW() - AdminWidest - 30, 10, AdminWidest + 20, AdminTotalHeight + 20, Color(0, 0, 0, 150 ))
draw.RoundedBox(8, ScrW() - SpecWidest - 30, 40 + AdminTotalHeight, SpecWidest + 20, SpecTotalHeight + 20, Color(0, 0, 0, 150 ))
draw.RoundedBox(8, ScrW() - SpecWidest - 30, 40 + SpecTotalHeight, TraitorWidest + 20, TraitorTotalHeight + 20, Color(0, 0, 0, 150 ))*/
end)
hook.Add("Think", "AWarn", function()
if GAMEMODE.round_state != ROUND_ACTIVE then
	AWarn = 0
else
	if AWarn != 2
	then
		AWarn = 1
	end
end
if AWarn == 1
then
ply:ConCommand("say @@Уважаемые игроки, у Детектива нет(!) права на RDM.")
ply:ConCommand("say @@AFK убивать ТОЛЬКО после 3:30.(Нарушение карается баном на сутки)")
ply:ConCommand("say @@404 всегда к вашим услугам.")
AWarn = 2
end
end)