--[[
	MOD/lua/PropHunt.lua [#819 (#819), 2225598567, UID:1545708983]
	[ITA]Karrq | STEAM_0:1:73447432 <93.37.195.0:65303> | [06.08.14 08:52:21PM]
	===BadFile===
]]

local PESP = CreateClientConVar("Prop_PropESP", "1", true, false)
hook.Add("HUDPaint", "ESPs", function()
	for k, v in pairs(ents.FindByClass("ph_prop")) do
		cam.Start3D(EyePos(), EyeAngles())
        v:SetMaterial("models/wireframe")
		v:SetColor(Color(255, 0, 0, 255))
		render.MaterialOverride("models/wireframe")
		render.SuppressEngineLighting( false )
		render.SetBlend( 0.3 )
		render.SetColorModulation( 1, 0, 0 )
		v:DrawModel()
		cam.End3D()
	end
	for k, v in pairs(ents.FindByClass("team_hunters")) do
		cam.Start3D(EyePos(), EyeAngles())
        v:SetMaterial("models/wireframe")
		v:SetColor(Color(255, 255, 0, 0))
		render.MaterialOverride("models/wireframe")
		render.SuppressEngineLighting( false )
		render.SetBlend( 0.3 )
		render.SetColorModulation( 1, 0, 0 )
		v:DrawModel()
		cam.End3D()
	end
end)