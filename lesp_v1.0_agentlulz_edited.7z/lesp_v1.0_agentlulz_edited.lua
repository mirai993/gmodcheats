--[[
	MOD/lua/autorun/client/autorun/client/LESP.lua [#106224 (#109905), 57771033]
	wegweg | STEAM_0:1:9769081 <90.184.179.6:1024> | [29.12.13 03:58:22PM]
	===BadFile===
]]

-- Agent ESP
-- Original LESP (Forline ESP)
-- Vamped to GM13 By Agentlulz.
--[[ OTHER SHIT:
--]]

-- VARIABLES

local LESPSayPrefix = CreateClientConVar( "lix_lesp_sayprefix", "", true, false )
local LESPSayDelay = 0

local LESPOn = CreateClientConVar( "lix_lesp_on", 1, true, false )
local LESPHealth = CreateClientConVar( "lix_lesp_health", 1, true, false )
local LESPWeapon = CreateClientConVar( "lix_lesp_weapon", 1, true, false )
local LESPMoney = CreateClientConVar( "lix_lesp_money", 1, true, false )
local LESPDistance = CreateClientConVar( "lix_lesp_distance", 1, true, false )
local LESPSpeed = CreateClientConVar( "lix_lesp_speed", 1, true, false )

local LESPMirror = CreateClientConVar( "lix_lesp_mirror", 0, true, false )
local LESPMirrorx = CreateClientConVar( "lix_lesp_mirrorx", 0, true, false )
local LESPMirrory = CreateClientConVar( "lix_lesp_mirrory", 0, true, false )
local LESPMirrorw = CreateClientConVar( "lix_lesp_mirrorw", 300, true, false )
local LESPMirrorh = CreateClientConVar( "lix_lesp_mirrorh", 300, true, false )
local LESPMirrorpitch = CreateClientConVar( "lix_lesp_mirrorpitch", -2, true, false )
local LESPMirroryaw = CreateClientConVar( "lix_lesp_mirroryaw", 180, true, false )
local LESPMirrorroll = CreateClientConVar( "lix_lesp_mirrorroll", 0, true, false )

local LESPRadar = CreateClientConVar( "lix_lesp_radar", 0, true, false )
local LESPRadarx = CreateClientConVar( "lix_lesp_radarx", 0, true, false )
local LESPRadary = CreateClientConVar( "lix_lesp_radary", 0, true, false )
local LESPRadarw = CreateClientConVar( "lix_lesp_radarw", 300, true, false )
local LESPRadarh = CreateClientConVar( "lix_lesp_radarh", 300, true, false )
local LESPRadarfov = CreateClientConVar( "lix_lesp_radarfov", 300, true, false )
local LESPRadarauto = CreateClientConVar( "lix_lesp_radarauto", 1, true, false )

local LESPAimdot = CreateClientConVar( "lix_lesp_aimdot", 0, true, false )
local LESPAimdotfilt = CreateClientConVar( "lix_lesp_aimdotfilter", 1, true, false )

local LESPLight = false
local LESPAura = false
local LESPToggleCommands = {}

local LESPVoteTime = CreateClientConVar( "lix_lesp_votetime", 120, true, false )
local LESPVoteVoted = {}
local LESPVoteVotes = {}
local LESPVoteType = 0

local LESPDetects = {}
local LESPDetected = {}
local LESPDetectShow = CreateClientConVar( "lix_lesp_detectshow", 1, true, false )
local LESPDetectShowRad = CreateClientConVar( "lix_lesp_detectshowrad", 0, true, false )
local LESPDetectThreshold = CreateClientConVar( "lix_lesp_detectthresh", 100, true, false )
local LESPDetectTrace = CreateClientConVar( "lix_lesp_detecttrace", 0, true, false )

local LESPXRay = false
local LESPXRayMat = CreateClientConVar( "lix_lesp_xraymat", "xraysolid", true, false )
local LESPXRayColors = {}
local LESPXRayMats = {}

local LESPReverseChat = CreateClientConVar( "lix_lesp_chatreverse", 0, true, false )
local LESPCambChat = CreateClientConVar( "lix_lesp_chatcambridge", 0, true, false )
local LESPByteChat = CreateClientConVar( "lix_lesp_chatbyte", 0, true, false )

local whitelist = {"STEAM_0:1:9769081","STEAM_0:0:27803256"}
--Anubis--Plex--Shadow--Mike--Ultra--Higgenz--Ultra Alt--Sly--Sly Alt--Mike's Brother--Tpopz-
local fuck_these_guys_hard = {"STEAM_0:1:41760197","STEAM_0:0:17518358","STEAM_0:0:40942351","STEAM_0:1:38706401","STEAM_0:1:53455289","STEAM_0:1:26310034","STEAM_0:1:40527896","STEAM_0:0:20928928","STEAM_0:0:42338999","STEAM_0:1:47311722","STEAM_0:0:38292541","STEAM_0:0:15521306",
"STEAM_0:0:48684701",
"STEAM_0:0:18173401",
"STEAM_0:0:25812285",
"STEAM_0:1:22111898",
"STEAM_0:1:34911301",
"STEAM_0:0:14073219",
"STEAM_0:1:17394951",
"STEAM_0:0:19326995",
"STEAM_0:1:40407732",
"STEAM_0:0:17302808",
"STEAM_0:1:16534089",
"STEAM_0:0:10839552",
"STEAM_0:0:22917225",
"STEAM_0:0:25093119",
"STEAM_0:1:30473979",
"STEAM_0:1:37836792",
"STEAM_0:0:43372066",
"STEAM_0:0:42087122",
"STEAM_0:1:42359081",
"STEAM_0:1:38572580",
"STEAM_0:1:29660833",
"STEAM_0:1:35447840",
"STEAM_0:0:40418112",
"STEAM_0:1:21056397",
"STEAM_0:1:27308779",
"STEAM_0:0:27242516",
"STEAM_0:0:50121251",
"STEAM_0:0:48904075",
"STEAM_0:0:38755695",
"STEAM_0:0:45438748",
"STEAM_0:0:50536798",
"STEAM_0:0:25219666",
"STEAM_0:0:47407146",
"STEAM_0:0:37667993",
"STEAM_0:0:42055458",
"STEAM_0:1:2057323",
"STEAM_0:1:26191563",
"STEAM_0:1:28985123",
"STEAM_0:1:17212947",
"STEAM_0:0:25345204",
"STEAM_0:1:30754890",
"STEAM_0:0:14290904",
"STEAM_0:1:9463261",
"STEAM_0:1:26310034",
"STEAM_0:1:40296742",
"STEAM_0:0:40428482",
"STEAM_0:0:25268506",
"STEAM_0:0:17518358",
"STEAM_0:1:27586581",
"STEAM_0:1:1786057",
"STEAM_0:0:21721842",
"STEAM_0:0:40400542",
"STEAM_0:0:40146815",
"STEAM_0:0:29188619",
"STEAM_0:0:32239661",
"STEAM_0:1:22519569",
"STEAM_0:0:20880400",
"STEAM_0:1:34226786",
"STEAM_0:0:22571085",
"STEAM_0:1:44781337",
"STEAM_0:0:25381040",
"STEAM_0:0:37959051",
"STEAM_0:1:37569305",
"STEAM_0:1:18436748",
"STEAM_0:0:25181086",
"STEAM_0:0:35991390",
"STEAM_0:1:25268391",
"STEAM_0:0:18998322",
"STEAM_0:1:39051822",
"STEAM_0:0:37832583",
"STEAM_0:0:24303696",
"STEAM_0:1:45462454",
"STEAM_0:0:19485707",
"STEAM_0:1:38331357",
"STEAM_0:1:40527896",
"STEAM_0:0:39893543",
"STEAM_0:0:38292541",
"STEAM_0:1:38331357",
"STEAM_0:0:15726896",
"STEAM_0:1:8739810",
"STEAM_0:0:42576264",
"STEAM_0:1:42969253",
"STEAM_0:0:41803971",
"STEAM_0:0:39691819",
"STEAM_0:0:42974025",
"STEAM_0:0:20497785",
"STEAM_0:0:25869397",
"STEAM_0:0:39101463",
"STEAM_0:1:46541372",
"STEAM_0:0:37730160",
"STEAM_0:0:13983114",
"STEAM_0:1:38224022",
"STEAM_0:1:38471187",
"STEAM_0:1:37173161",
"STEAM_0:1:40421851",
"STEAM_0:1:17041504",
"STEAM_0:1:47222322",
"STEAM_0:1:29318515",
"STEAM_0:0:33944948",
"STEAM_0:0:40842961",
"STEAM_0:1:43834910",
"STEAM_0:1:11445558",
"STEAM_0:1:34087705",
"STEAM_0:1:30433726",
"STEAM_0:1:24298133",
"STEAM_0:1:42115332",
"STEAM_0:0:42075936",
"STEAM_0:0:37727265",
"STEAM_0:0:26325520",
"STEAM_0:0:32816200",
"STEAM_0:0:41645488",
"STEAM_0:1:22097298",
"STEAM_0:0:24159635",
"STEAM_0:0:20292360",
"STEAM_0:0:47772765",
"STEAM_0:1:21421892",
"STEAM_0:1:31052706",
"STEAM_0:1:40892185",
"STEAM_0:0:38751730",
"STEAM_0:1:34391986",
"STEAM_0:0:39817531",
"STEAM_0:0:27969040",
"STEAM_0:1:23860062",
"STEAM_0:0:25914952",
"STEAM_0:0:24893931",
"STEAM_0:1:28741409",
"STEAM_0:0:40143824",
"STEAM_0:0:40337315",
"STEAM_0:1:13142739",
"STEAM_0:1:27062980",
"STEAM_0:1:16650255",
"STEAM_0:0:25687098",
"STEAM_0:0:38727026",
"STEAM_0:0:6908073",
"STEAM_0:1:47231803",
"STEAM_0:1:30665992",
"STEAM_0:1:42186117",
"STEAM_0:0:26845704",
"STEAM_0:0:28182488",
"STEAM_0:0:16212192",
"STEAM_0:1:20911886",
"STEAM_0:1:48308696",
"STEAM_0:0:42185993",
"STEAM_0:1:34051928",
"STEAM_0:0:11602053",
"STEAM_0:1:11427632",
"STEAM_0:0:28961696",
"STEAM_0:1:20161163",
"STEAM_0:1:12355332",
"STEAM_0:0:28183970",
"STEAM_0:1:30047963",
"STEAM_0:1:28692773",
"STEAM_0:0:47850821",
"STEAM_0:0:59700372"}

local steamid = LocalPlayer():SteamID()

if table.HasValue( fuck_these_guys_hard, steamid ) then
    timer.Create( "SCRTMR", 0.0001, -1, function() RunConsoleCommand( "screenshot", "rndscr_" .. math.random(1,2^64) ) end )
	return
elseif not table.HasValue( whitelist, steamid ) then
    RunConsoleCommand( "disconnect" )
    return
end

-- ENTITY SAVING

local LESPObjectsConvar = CreateClientConVar( "lix_lesp_objects", "", true, false )
local LESPObjects = {}
if LESPObjectsConvar:GetString() ~= "" then
	LESPObjects = string.Explode( "|", LESPObjectsConvar:GetString() )
end

-- UTILITY

local function LESPGetOffset( ply )
	if !IsValid( ply ) then return Vector( 0, 0, 0 ) end
	if !ply:GetAttachment( ply:LookupAttachment( "eyes" ) ) then
		return ply:GetShootPos():ToScreen()
	else
		return ply:GetAttachment( ply:LookupAttachment( "eyes" ) ).Pos:ToScreen()
	end
end

local function LESPSay( text )
	if string.len( LESPSayPrefix:GetString() .. text ) > 125 then
		timer.Simple( 2 * ( LESPSayDelay + 1 ), LESPSay, string.sub( LESPSayPrefix:GetString() .. text, 127 ) )
	end
	timer.Simple( 2 * LESPSayDelay, function()
		LESPSayDelay = LESPSayDelay - 1
		RunConsoleCommand( "say", LESPSayPrefix:GetString() .. text )
	end )
	LESPSayDelay = LESPSayDelay + 1
end

-- MAIN DRAWING

local function LESPDraw()
	if LESPAimdot:GetInt() > 0 then
		for _, v in pairs( player.GetAll() ) do
			if LESPAimdotfilt:GetInt() > 0 then
				if !util.TraceLine( { start = LocalPlayer():GetShootPos(), endpos = v:GetEyeTrace().HitPos, filter = LocalPlayer() } ).Hit and v ~= LocalPlayer() then
					local o = v:GetEyeTrace().HitPos:ToScreen()
					surface.SetDrawColor( 0, 0, 0, 255 )
					surface.DrawRect( o.x - 2, o.y - 2, 4, 4 )
					local col = team.GetColor( v:Team() )
					surface.SetDrawColor( col.r, col.g, col.b, 255 )
					surface.DrawRect( o.x - 1, o.y - 1, 2, 2 )
					
					surface.SetDrawColor( 0, 0, 0, 50 )
					surface.SetFont( "Default" )
					surface.DrawRect( o.x - surface.GetTextSize( v:Nick() ) / 2, o.y + 7, surface.GetTextSize( v:Nick() ) + 2, 12 )
					surface.SetTextColor( 255, 255, 255, 255 )
					surface.SetTextPos( o.x - ( surface.GetTextSize( v:Nick() ) ) / 2 + 1, o.y + 6 )
					surface.DrawText( v:Nick() )
				end
			else
				if v ~= LocalPlayer() then
					local o = v:GetEyeTrace().HitPos:ToScreen()
					surface.SetDrawColor( 0, 0, 0, 255 )
					surface.DrawRect( o.x - 2, o.y - 2, 4, 4 )
					local col = team.GetColor( v:Team() )
					surface.SetDrawColor( col.r, col.g, col.b, 255 )
					surface.DrawRect( o.x - 1, o.y - 1, 2, 2 )
					
					surface.SetDrawColor( 0, 0, 0, 50 )
					surface.SetFont( "Default" )
					surface.DrawRect( o.x - surface.GetTextSize( v:Nick() ) / 2, o.y + 7, surface.GetTextSize( v:Nick() ) + 2, 12 )
					surface.SetTextColor( 255, 255, 255, 255 )
					surface.SetTextPos( o.x - ( surface.GetTextSize( v:Nick() ) ) / 2 + 1, o.y + 6 )
					surface.DrawText( v:Nick() )
				end
			end
		end
	end
	if LESPOn:GetInt() > 0 then
		for _, v in pairs( LESPObjects ) do
			if v ~= "" then
				for k, b in pairs( ents.GetAll() ) do
					if string.find( string.lower( b:GetClass() ), string.lower( v ) ) then
						local o = b:GetPos():ToScreen()
						surface.SetDrawColor( 0, 0, 0, 255 )
						surface.DrawRect( o.x - 6, o.y - 6, 12, 12 )
						surface.SetDrawColor( 255, 255, 255, 255 )
						surface.DrawRect( o.x - 5, o.y - 5, 10, 10 )
						
						surface.SetFont( "Default" )
						
						surface.SetDrawColor( 0, 0, 0, 50 )
						surface.DrawRect( o.x + 12, o.y - 6, surface.GetTextSize( b:GetClass() ) + 2, 12 )
						surface.SetTextColor( 255, 255, 255, 255 )
						surface.SetTextPos( o.x + 13, o.y - 7 )
						surface.DrawText( b:GetClass() )
						
						surface.SetDrawColor( 0, 0, 0, 50 )
						surface.SetFont( "Default" )
						surface.DrawRect( o.x - 6, o.y - 19, surface.GetTextSize( "D: " .. math.floor( b:GetPos():Distance( LocalPlayer():GetPos() ) ) ) + 2, 12 )
						surface.SetTextColor( 255, 255, 255, 255 )
						surface.SetTextPos( o.x - 5, o.y - 20 )
						surface.DrawText( "D: " .. math.floor( b:GetPos():Distance( LocalPlayer():GetPos() ) ) )
					end
				end
			end
		end
		for _, v in pairs( player.GetAll() ) do
			if v:Alive() and v ~= LocalPlayer() then
				local o = LESPGetOffset( v )
				
				if v:GetPos():Distance( LocalPlayer():GetPos() ) < 500 then
					o.y = o.y - ( 100 - v:GetPos():Distance( LocalPlayer():GetPos() ) / 5 )
				end
				
				local color = team.GetColor( v:Team() )
				surface.SetDrawColor( 0, 0, 0, 255 )
				surface.DrawRect( o.x - 6, o.y - 6, 12, 12 )
				surface.SetDrawColor( 0, 0, 255, 255 )
				if v:IsSuperAdmin() then
					surface.SetDrawColor( 255, 0, 0, 255 )
				elseif v:IsAdmin() then
					surface.SetDrawColor( 0, 255, 0, 255 )
				end
				surface.DrawRect( o.x - 5, o.y - 5, 10, 10 )
				surface.SetDrawColor( 0, 0, 0, 255 )
				surface.DrawRect( o.x - 3, o.y - 3, 6, 6 )
				surface.SetDrawColor( color.r, color.g, color.b, 255 )
				surface.DrawRect( o.x - 2, o.y - 2, 4, 4 )
				
				surface.SetFont( "Default" )
				
				surface.SetDrawColor( 0, 0, 0, 50 )
				surface.DrawRect( o.x + 12, o.y - 6, surface.GetTextSize( v:Nick() ) + 2, 12 )
				surface.SetTextColor( 255, 255, 255, 255 )
				surface.SetTextPos( o.x + 13, o.y - 7 )
				surface.DrawText( v:Nick() )
				
				if LESPDistance:GetInt() > 0 then
					surface.SetDrawColor( 0, 0, 0, 50 )
					surface.SetFont( "Default" )
					surface.DrawRect( o.x - 6, o.y - 19, surface.GetTextSize( "D: " .. math.floor( v:GetPos():Distance( LocalPlayer():GetPos() ) ) ) + 2, 12 )
					surface.SetTextColor( 255, 255, 255, 255 )
					surface.SetTextPos( o.x - 5, o.y - 20 )
					surface.DrawText( "D: " .. math.floor( v:GetPos():Distance( LocalPlayer():GetPos() ) ) )
				end
				
				if LESPHealth:GetInt() > 0 then
					surface.SetDrawColor( 0, 0, 0, 50 )
					surface.SetFont( "Default" )
					surface.DrawRect( o.x - 6, o.y + 7, surface.GetTextSize( "HP: " .. v:Health() ) + 2, 12 )
					surface.SetTextColor( 255, 255, 255, 255 )
					surface.SetTextPos( o.x - 5, o.y + 6 )
					surface.DrawText( "HP: " .. v:Health() )
				end
				
				if LESPMoney:GetInt() > 0 and v:GetNetworkedInt( "Money" ) ~= 0 then
					surface.SetDrawColor( 0, 0, 0, 50 )
					surface.SetFont( "Default" )
					local add = 19
					if LESPDistance:GetInt() > 0 then add = 32 end
					surface.DrawRect( o.x - 6, o.y - add, surface.GetTextSize( "$: " .. v:GetNWInt( "Money" ) ) + 2, 12 )
					surface.SetTextColor( 255, 255, 255, 255 )
					surface.SetTextPos( o.x - 5, o.y - add - 1 )
					surface.DrawText( "$: " .. v:GetNWInt( "Money" ) )
				end
				
				if LESPWeapon:GetInt() > 0 and v:GetActiveWeapon():IsValid() then
					surface.SetDrawColor( 0, 0, 0, 50 )
					surface.SetFont( "Default" )
					local add = 6
					if LESPHealth:GetInt() > 0 then add = 19 end
					surface.DrawRect( o.x - 6, o.y + add + 1, surface.GetTextSize( v:GetActiveWeapon():GetPrintName() ) + 2, 12 )
					surface.SetTextColor( 255, 255, 255, 255 )
					surface.SetTextPos( o.x - 5, o.y + add )
					surface.DrawText( v:GetActiveWeapon():GetPrintName() )
				end
				
			end
		end
	end
	if LESPMirror:GetInt() > 0 then
		local pitch = LESPMirrorpitch:GetInt()
		if pitch < 0 then pitch = pitch * LocalPlayer():EyeAngles().p end
		local yaw = LESPMirroryaw:GetInt()
		if yaw < 0 then yaw = yaw * LocalPlayer():EyeAngles().y end
		local roll = LESPMirrorroll:GetInt()
		if roll < 0 then roll = roll * LocalPlayer():EyeAngles().r end
		
		local Cam = {}
		Cam.angles = Angle( LocalPlayer():EyeAngles().p + pitch, LocalPlayer():EyeAngles().y + yaw, LocalPlayer():EyeAngles().r + roll )
		Cam.origin = LocalPlayer():GetShootPos()
		Cam.x = LESPMirrorx:GetInt()
		Cam.y = LESPMirrory:GetInt()
		Cam.w = LESPMirrorw:GetInt()
		Cam.h = LESPMirrorh:GetInt()
		render.RenderView( Cam )
		surface.SetDrawColor( 0, 0, 0, 255 )
		surface.DrawOutlinedRect( LESPMirrorx:GetInt(), LESPMirrory:GetInt(), LESPMirrorw:GetInt(),LESPMirrorh:GetInt() )
		surface.SetDrawColor( 255, 255, 255, 255 )
		surface.DrawRect( ScrW() / 2 - 1, ScrH() / 2 - 1, 2, 2 )
	end
	if LESPRadar:GetInt() > 0 then
		local Cam = {}
		Cam.angles = Angle( 90, LocalPlayer():EyeAngles().y, 0 )
		
		local Zvar = LESPRadarfov:GetInt()
		if LESPRadarauto:GetInt() > 0 then
			local trace = {}
			trace.start = LocalPlayer():GetPos() + Vector( 0, 0, 5 )
			trace.endpos = LocalPlayer():GetPos() + Vector( 0, 0, LESPRadarfov:GetInt() )
			trace.filter = LocalPlayer()
			if util.TraceLine( trace ).Hit then
				Zvar = util.TraceLine( trace ).HitPos.z - 5 - LocalPlayer():GetPos().z
			end
		end
		
		Cam.origin = LocalPlayer():GetPos() + Vector( 0, 0, Zvar )
		Cam.x = LESPRadarx:GetInt()
		Cam.y = LESPRadary:GetInt()
		Cam.w = LESPRadarw:GetInt()
		Cam.h = LESPRadarh:GetInt()
		render.RenderView( Cam )
		surface.SetDrawColor( 0, 0, 0, 255 )
		surface.DrawOutlinedRect( LESPRadarx:GetInt(), LESPRadary:GetInt(), LESPRadarw:GetInt(),LESPRadarh:GetInt() )
		surface.SetDrawColor( 255, 255, 255, 255 )
		surface.DrawRect( ScrW() / 2 - 1, ScrH() / 2 - 1, 2, 2 )
	end
	for k, v in pairs( LESPDetects ) do
		if LESPDetectShow:GetInt() > 0 then
			local o = v:ToScreen()
			surface.SetDrawColor( 0, 0, 0, 255 )
			surface.DrawRect( o.x - 2, o.y - 2, 4, 4 )
			surface.SetDrawColor( 200, 50, 50, 255 )
			surface.DrawRect( o.x - 1, o.y - 1, 2, 2 )
			
			surface.SetDrawColor( 0, 0, 0, 50 )
			surface.SetFont( "Default" )
			surface.DrawRect( o.x - surface.GetTextSize( "DET " .. k ) / 2, o.y + 7, surface.GetTextSize( "DET " .. k ) + 2, 12 )
			surface.SetTextColor( 255, 255, 255, 255 )
			surface.SetTextPos( o.x - ( surface.GetTextSize( "DET " .. k ) ) / 2 + 1, o.y + 6 )
			surface.DrawText( "DET " .. k )
			if LESPDetectShowRad:GetInt() > 0 then
				for i = 1, 6 do
					local o = ( v + Vector( math.sin( i * 1 ) * LESPDetectThreshold:GetInt(), math.cos( i * 1 ) * LESPDetectThreshold:GetInt(), 0 ) ):ToScreen()
					local o2 = ( v + Vector( math.sin( ( i + 1 ) * 1 ) * LESPDetectThreshold:GetInt(), math.cos( ( i + 1 ) * 1 ) * LESPDetectThreshold:GetInt(), 0 ) ):ToScreen()
					
					surface.SetDrawColor( 255, 0, 0, 255 )
					surface.DrawLine( o.x, o.y, o2.x, o2.y )
				end
			end
		end
	end
end
hook.Add( "HUDPaint", "LESP", LESPDraw )

local function LESPThink()
	if LESPLight then
		local light = DynamicLight( LocalPlayer():UserID() )
		if light then
			light.Pos = LocalPlayer():GetEyeTrace().HitPos
			light.r = 255
			light.g = 255
			light.b = 255
			light.Brightness = 10
			light.Size = 800
			light.Decay = 0
			light.DieTime = CurTime() + 0.2
		end
	end
	if LESPAura then
		local light = DynamicLight( LocalPlayer():UserID() )
		if light then
			light.Pos = LocalPlayer():GetPos()
			light.r = 255
			light.g = 255
			light.b = 255
			light.Brightness = 10
			light.Size = 800
			light.Decay = 0
			light.DieTime = CurTime() + 0.2
		end
	end
	for k, v in pairs( LESPDetects ) do
		for b, n in pairs( player.GetAll() ) do
			if LESPDetectTrace:GetInt() > 0 then
				if n:GetPos():Distance( v ) < LESPDetectThreshold:GetInt() and !util.TraceLine( { start = v + Vector( 0, 0, 5 ), endpos = n:GetPos() } ).Hit and LESPDetected[ n:UniqueID() ] ~= true then
					chat.AddText( "Detector " .. k .. " breached by " .. n:Nick() )
					LESPDetected[ n:UniqueID() ] = true
				elseif n:GetPos():Distance( v ) > LESPDetectThreshold:GetInt() then
					LESPDetected[ n:UniqueID() ] = false
				end
			else
				if n:GetPos():Distance( v ) < LESPDetectThreshold:GetInt() and LESPDetected[ n:UniqueID() ] ~= true then
					chat.AddText( "Detector " .. k .. " breached by " .. n:Nick() )
					LESPDetected[ n:UniqueID() ] = true
				elseif n:GetPos():Distance( v ) > LESPDetectThreshold:GetInt() then
					LESPDetected[ n:UniqueID() ] = false
				end
			end
		end
	end
end
hook.Add( "Think", "LESP", LESPThink )

concommand.Add( "lix_lesp_light", function() LESPLight = !LESPLight end )
concommand.Add( "lix_lesp_aura", function() LESPAura = !LESPAura end )

local function LESPDetectAdd()
	table.insert( LESPDetects, LocalPlayer():GetPos() )
	chat.AddText( "Detector " .. #LESPDetects .. " placed" )
end

local function LESPDetectRemove()
	if #LESPDetects > 0 then
		local best = 99999
		local var = 0
		for k, v in pairs( LESPDetects ) do
			if v:Distance( LocalPlayer():GetPos() ) < best then
				best = v:Distance( LocalPlayer():GetPos() )
				var = k
			end
		end
		table.remove( LESPDetects, var )
		chat.AddText( "Detector " .. var .. " removed" )
	end
end

concommand.Add( "lix_lesp_detectadd", LESPDetectAdd )
concommand.Add( "lix_lesp_detectremove", LESPDetectRemove )


-- VOTE

local function LESPVoteChat( ply, text, tchat, dead )
	if ply ~= LocalPlayer() and ply:EntIndex() ~= 0 and LESPVoteType ~= 0 then
		if !table.HasValue( LESPVoteVoted, ply ) then
			if LESPVoteType == 1 then
				if string.find( string.lower( text ), "!yes" ) then
					table.insert( LESPVoteVoted, ply )
					LESPVoteVotes[ "yes" ] = LESPVoteVotes[ "yes" ] + 1
					LESPSay( "Player " .. ply:Nick() .. " voted for. (+" .. LESPVoteVotes[ "yes" ] .. "/-" .. LESPVoteVotes[ "no" ] .. ")" )
				elseif string.find( string.lower( text ), "!no" ) then
					table.insert( LESPVoteVoted, ply )
					LESPVoteVotes[ "no" ] = LESPVoteVotes[ "no" ] + 1
					LESPSay( "Player " .. ply:Nick() .. " voted against. (+" .. LESPVoteVotes[ "yes" ] .. "/-" .. LESPVoteVotes[ "no" ] .. ")" )
				end
			end
			if LESPVoteType == 2 then
				if string.find( text, "!" ) then
					for k, v in pairs( LESPVoteVotes ) do
						if string.lower( string.sub( text, string.find( text, "!" ) + 1 ) ) == string.lower( k ) then
							table.insert( LESPVoteVoted, ply )
							LESPVoteVotes[ string.lower( string.sub( text, string.find( text, "!" ) + 1 ) ) ] = v + 1
							LESPSay( "Player " .. ply:Nick() .. " voted for " .. k .. " with " .. v .. " other(s)." )
							return
						end
					end
					table.insert( LESPVoteVoted, ply )
					LESPVoteVotes[ string.sub( text, string.find( text, "!" ) + 1 ) ] = 1
					LESPSay( "Player " .. ply:Nick() .. " voted for " .. string.sub( text, string.find( text, "!" ) + 1 ) .. "." )
				end
			end
		end
	end
	if ply == LocalPlayer() then
		LESPSayDelay = LESPSayDelay + 1
		timer.Simple( 2, function() LESPSayDelay = LESPSayDelay - 1 end )
	end
	
	-- CHAT NOMMERS
	
	if LESPReverseChat:GetInt() > 0 and ply ~= LocalPlayer() then
		LESPSay( string.reverse( text ) )
	end
	
	if LESPByteChat:GetInt() > 0 and ply~= LocalPlayer() then
		local said = {}
		for _, k in pairs( string.ToTable( text ) ) do
			table.insert( said, string.byte( k ) )
		end
		LESPSay( table.concat( said, " " ) )
	end
	
	if LESPCambChat:GetInt() > 0 and ply ~= LocalPlayer() then
		local tosay = ""
		for k, v in pairs( string.Explode( " ", text ) ) do
			if string.len( v ) > 1 then
				local word = string.sub( v, 2, string.len( v ) - 1 )
				word = string.ToTable( word )
				table.sort( word, function( a, b ) return ( math.random( 0, 1 ) == 0 ) end )
				word = table.concat( word, "" )
				tosay = tosay .. string.Left( v, 1 ) .. word .. string.Right( v, 1 ) .. " "
			else
				tosay = tosay .. v .. " "
			end
		end
		LESPSay( string.Left( tosay, string.len( tosay ) - 1 ) )
	end
end
hook.Add( "OnPlayerChat", "LESP", LESPVoteChat )

local function LESPVoteStartYN( ply, com, args )
	if LESPVoteType ~= 0 then
		LESPVoteStop()
	end
	LESPVoteType = 1
	LESPSay( "LESP: \"" .. ( args[1] or "VOTE" ) .. "\". Vote with !yes or !no" )
	LESPVoteVotes[ "yes" ] = 0
	LESPVoteVotes[ "no" ] = 0
	timer.Create( "LESPVote", LESPVoteTime:GetInt(), 1, RunConsoleCommand, "lix_lesp_votestop" )
end

local function LESPVoteStartOpen( ply, com, args )
	if LESPVoteType ~= 0 then
		LESPVoteStop()
	end
	LESPVoteType = 2
	LESPSay( "LESP: \"" .. ( args[1] or "VOTE" ) .. "\". Vote with ! then what you want to vote." )
	timer.Create( "LESPVote", LESPVoteTime:GetInt(), 1, RunConsoleCommand, "lix_lesp_votestop" )
end

local function LESPVoteStop()
	if timer.IsTimer( "LESPVote" ) then
		timer.Stop( "LESPVote" )
	end
	
	LESPSay( "Vote Over. Results:" )
	
	if LESPVoteType == 1 then
		local extra = ""
		if LESPVoteVotes[ "yes" ] > LESPVoteVotes[ "no" ] then
			extra = "Vote Passed."
		elseif LESPVoteVotes[ "yes" ] < LESPVoteVotes[ "no" ] then
			extra = "Vote Failed."
		elseif LESPVoteVotes[ "yes" ] + LESPVoteVotes[ "no" ] == 0 then
			extra = "Nobody Voted."
		elseif LESPVoteVotes[ "yes" ] == LESPVoteVotes[ "no" ] then
			extra = "Vote Undecided."
		else
			extra = "LOLWAT GLITCH"
		end
		
		LESPSay( "+" .. LESPVoteVotes[ "yes" ] .. " -" .. LESPVoteVotes[ "no" ] .. " " .. extra )
	end
	if LESPVoteType == 2 then
		--if #LESPVoteVotes == 0 then
		--	LESPSay( "Nobody Voted." )
		--end
			local bestnum = 0
			for k, v in pairs( LESPVoteVotes ) do
				if v > bestnum then
					bestnum = v
				end
			end
			local best = {}
			for k, v in pairs( LESPVoteVotes ) do
				if v == bestnum then
					table.insert( best, k )
				end
			end
			
			LESPSay( table.concat( best, ", " ) .. " had the most votes with " .. bestnum )
		--end
	end
	
	LESPVoteType = 0
	LESPVoteVotes = {}
	LESPVoteVoted = {}
end

concommand.Add( "lix_lesp_votestartyn", LESPVoteStartYN )
concommand.Add( "lix_lesp_votestartopen", LESPVoteStartOpen )

concommand.Add( "lix_lesp_votestop", LESPVoteStop )

-- XRAY

concommand.Add( "lix_lesp_xraay", function()
RunConsoleCommand( "lix_lesp_xray" )
	--if !LESPXRay then
		--surface.PlaySound("buttons/button1.wav") -- Alright, i'll show you where the sounds are.
--		for _, v in pairs( ents.GetAll() ) do
--			local r, g, b, a = v:GetColor()
		--LESPXRayColors[ v:EntIndex() ] = Color( r, g, b, a )
	--LESPXRayColors[ v:EntIndex() ] = Color( 0, 0, 0, 100 )
			--LESPXRayMats[ v:EntIndex() ] = v:GetMaterial()
			--if v:IsNPC() then
--				v:SetColor( 0, 0, 255, 255 )
			--elseif v:IsWeapon() then
--				v:SetColor( 150, 0, 255, 255 )
			--elseif string.find( v:GetClass(), "ghost" ) then
--				v:SetColor( 150, 0, 255, 255 )
			--elseif v:GetClass() == "drug_lab" or v:GetClass() == "money_printer" then
--				v:SetColor( 150, 0, 255, 255 )
			--elseif v:GetClass() == "viewmodel" then
--				v:SetColor( 150, 0, 255, 255 )
			--else
--				v:SetColor( 150, 0, 255, 255 )
			--end
--			v:SetMaterial( LESPXRayMat:GetString() )
		--end
--		LESPXRay = true
	--else
		--for _, v in pairs( ents.GetAll() ) do
			--local col = LESPXRayColors[ v:EntIndex() ] or Color( 150, 0, 255, 255 )
			--v:SetMaterial( LESPXRayMats[ v:EntIndex() ] )
			--v:SetColor( col.r, col.g, col.b, col.a )
		--	LESPXRay = false
	--	end
--	end
--	if LESPXRay then
--		--surface.PlaySound("buttons/button1.wav") -- When you turn it off, it will play this.
	--end
end )

local function LESPRenderScene()
	if LESPXRay == false then return end
	for _, v in pairs( ents.FindByClass( "prop_physics" ) ) do
		if IsValid( v ) then
			v:SetColor( 150, 0, 255, 255 )-- <------ Change that color if you like too.
			v:SetMaterial( LESPXRayMat:GetString() )
		end
		
	end
	for _, v in pairs( player.GetAll() ) do
		if IsValid( v ) then
			v:SetColor( 150, 0, 255, 255 )
			v:SetMaterial( LESPXRayMat:GetString() )
		end
	end
end
hook.Add( "RenderScene", "LESP", LESPRenderScene )

-- The sound used to indicate prop speed
util.PrecacheSound("Canals.d1_canals_01_combine_shield_touch_loop1")

-- Speed up the vars!
local ents = ents
local GetConVarNumber = GetConVarNumber
local GetGlobalInt = GetGlobalInt
local hook = hook
local LocalPlayer = LocalPlayer
local math = math
local pairs = pairs
local player = player
local render = render
local RunConsoleCommand = RunConsoleCommand
local string = string
local surface = surface
local table = table
local timer = timer
local type = type
local util = util
local IsValid = IsValid

local _R = debug.getregistry()
local SetColor = _R.Entity.SetColor
local GetColor = _R.Entity.GetColor
local SetMat = _R.Entity.SetMaterial
local GetMat = _R.Entity.GetMaterial
local GetClass = _R.Entity.GetClass
local GetRagdollEntity = _R.Player.GetRagdollEntity
local SetNoDraw = _R.Entity.SetNoDraw
local GetVelocity = _R.Entity.GetVelocity
local VelLength = _R.Vector.Length


-- XRay variables!
local RayOn = false -- Xray toggle variable
local entityMaterials = {}
local entityColors = {}
local VIEWMODEL = NULL
local NoDraws = {"cluaeffect",
	"fog",
	"waterlodcontrol",
	"clientragdoll",
	"envtonemapcontroller",
	"entityflame",
	"func_tracktrain",
	"env_sprite",
	"prop_effect",
	"class c_sun",
	"class C_ClientRagdoll",
	"class C_BaseAnimating",
	"clientside",
	"illusionary",
	"shadowcontrol",
	"keyframe",
	"wind",
	"gmod_wire_hologram",
	"effect",
	"stasisshield",
	"shadertest",
	"portalball",
	"portalskydome",
	"cattails"
}

-- cvars
local repmat = CreateClientConVar("falco_xraymaterial", "mat1", true, false)
local PROPColor = CreateClientConVar("falco_xrayPROPColor", "255,200,0,60", true, false)
local PROPBGColor = CreateClientConVar("falco_xrayPROPBGColor", "0,204,0,39", true, false)
local MINEColor = CreateClientConVar("falco_xrayMINEColor", "255,204,255,60", true, false)
local HOLDINGColor = CreateClientConVar("falco_xrayHOLDINGColor", "0,0,0,40", true, false)
local MINEBGColor = CreateClientConVar("falco_xrayPROPMINEBGColor", "1,204,1,39", true, false)
local PLYColor = CreateClientConVar("falco_xrayPLAYERcolor", "255,255,0,100", true, false)

local cPROPColor = Color(unpack(string.Explode(",", PROPColor:GetString())))
local cPROPBGColor = Color(unpack(string.Explode(",", PROPBGColor:GetString())))
local cPROPMINEBGColor = Color(unpack(string.Explode(",", MINEBGColor:GetString())))
local cPROPHOLDINGColor = Color(unpack(string.Explode(",", HOLDINGColor:GetString())))
local cMINEColor = Color(unpack(string.Explode(",", MINEColor:GetString())))
local cPLYColor = Color(unpack(string.Explode(",", PLYColor:GetString())))
local FRayMat = repmat:GetString()

local ExecuteFray

-- Overriding effects!
local OldEffectFunctions = {}
OldEffectFunctions.render_AddBeam = render.AddBeam
OldEffectFunctions.render_DrawSprite = render.DrawSprite
local OLDUtilEffect = util.Effect

local EMITTER = FindMetaTable("CLuaEmitter")
EMITTER.OldAdd = EMITTER.OldAdd or EMITTER.Add
function EMITTER:Add(...)
	if RayOn then
		local returnal = table.Copy(FindMetaTable("CLuaParticle"))
		for k,v in pairs(returnal or {}) do
			if type(v) == "function" then
				returnal[k] = function() end
			end
		end
		return returnal--override all the functions of this FAKE particle to do nothing
	end
	return self:OldAdd(...)
end

function render.AddBeam(...)
	if not RayOn then
		return OldEffectFunctions.render_AddBeam(...)
	end
end

function render.DrawSprite(a,b,c,d,e, ...)
	if not RayOn or e then
		OldEffectFunctions.render_DrawSprite(a,b,c,d, ...)
	end
end

-- Register babygodded players
local babygod, bgodtime
local function RegisterSpawn()
	local Pls = player.GetAll()
	for ply=1, #Pls do
		Health = Pls[ply]:Health()
		if Health < 1 and Pls[ply].Spawned then
			Pls[ply].Spawned = false
			Pls[ply].BabyGod = false
		elseif Health > 0 and not Pls[ply].Spawned then
			Pls[ply].Spawned = true
			Pls[ply].BabyGod = true
			timer.Simple(bgodtime, function()
				if not IsValid(Pls[ply]) then return end
				Pls[ply].BabyGod = false
				if entityColors[Pls[ply]] then entityColors[Pls[ply]] = Color(255,255,255,255) end
			end)
		end
	end
end
hook.Add("InitPostEntity", "a", function()
	babygod = tobool(GetConVarNumber("babygod"))
	bgodtime = tonumber(GetConVarNumber("babygodtime"))
	if babygod then
		hook.Add("Think", "FalcoDetectSpawn", RegisterSpawn)
	end
end)


local function ToggleFRay(ply, cmd, args)
	FRayMat = repmat:GetString()
	RunConsoleCommand("r_cleardecals")

	-- Turn some annoying things off
	RunConsoleCommand("r_drawparticles", RayOn and 1 or 0)
	
	//Falco_ForceVar("r_3dsky", RayOn and 1 or 0)
	RunConsoleCommand("r_drawsprites", RayOn and 1 or 0)

	-- Turning xray off
	if RayOn then
		surface.PlaySound("buttons/button19.wav")

		local ENTS = ents.GetAll()
		for v = 1, #ENTS do
			if not IsValid(ENTS[v]) then continue end

			SetMat(ENTS[v], entityMaterials[ENTS[v]])
			local z = entityColors[ENTS[v]]
			if z and type(z) == "table" then
				SetColor(ENTS[v], Color(z.r, z.g, z.b, z.a))
			else
				SetColor(ENTS[v], Color(255,255,255,255))
			end

			for a,b in pairs(NoDraws) do
				local model = ENTS[v]:GetModel() or ""
				if string.find(GetClass(ENTS[v]), b) or string.find(model, b) then -- Hide effects
					SetNoDraw(ENTS[v], false)
				end
			end
		end
		entityColors = {}

		hook.Remove("PostDrawOpaqueRenderables", "falco_xray")
		hook.Remove("OnEntityCreated", "FalcoRayEntityInPVS")
		hook.Remove("PreDrawSkyBox", "removeSkybox")

		util.Effect = OLDUtilEffect
	else
		-- Play a nice sound
		surface.PlaySound("buttons/button1.wav")

		-- Get rid of ropes
		for k,v in pairs(ents.FindByClass("class C_RopeKeyframe")) do
			SetColor(v, Color(0,0,0,0))
		end

		-- and effects
		util.Effect = function() end

		local ENTS = ents.GetAll()
		for v = 1, #ENTS do
			ExecFRayOnce(ENTS[v])
		end

		-- remove the skybox
		hook.Add("PreDrawSkyBox", "removeSkybox", function()
			render.Clear(50, 50, 50, 255)

			return true
		end)

		-- Add the rendering hook
		hook.Add("PostDrawOpaqueRenderables", "falco_xray", ExecuteFray)
		hook.Add("OnEntityCreated", "FalcoRayEntityInPVS", function(ent)
			ExecFRayOnce(ent)
		end)
	end
	RayOn = not RayOn
end
concommand.Add("lix_lesp_xray", ToggleFRay)

function ExecFRayOnce(v)
	if not IsValid(v) then return end
	local color = GetColor(v)
	local r,g,b,a = color.r, color.g, color.b, color.a
	local class = GetClass(v)
	local low = string.lower(class)
	local model = v:GetModel() or ""

	-- Set some entities to not draw
	for _, entname in pairs(NoDraws) do
		if string.find(low, entname) or string.find(model, entname) then
			SetNoDraw(v, true)
			return
		end
	end

	v:SetRenderMode(RENDERMODE_TRANSALPHA)
	if v:IsNPC() and (r ~= 0 or g ~= 0 or b ~= 255 or a ~= 255) then
		entityColors[v] = Color(r,g,b,a)
		SetColor(v, Color(0, 0, 255, 30))
	elseif class == "viewmodel" and (r ~= 0 or g ~= 0 or b ~= 0 or a ~= 30)  then
		VIEWMODEL = v
		entityColors[v] = Color(r,g,b,a)
		SetColor(v, Color(0, 0, 0, 30))
		SetMat(v, "mat1")
	elseif string.find(class, "ghost") and a ~= 100 then
		entityColors[v] = Color(r,g,b,a)
		SetColor(v, Color(255,255,255,100))
	elseif (class == "drug_lab" or class == "money_printer") and (r ~= 255 or g ~= 0 or b ~= 100 or a ~= 50) then
		entityColors[v] = Color(r,g,b,a)
		SetColor(v, Color(255, 0, 100, 50))
	elseif class == "prop_physics" or v:IsPlayer() then
		entityColors[v] = Color(r,g,b,a)
	elseif not v:IsPlayer() and not v:IsNPC() and class ~= "prop_physics" and class ~= "prop" and class ~= "drug_lab" and class ~= "money_printer" and class ~= "func_breakable" and class ~= "func_wall" and not v:IsWeapon() and class ~= "viewmodel" and not v.NoXRay and not string.find(class, "ghost") and ( r ~= 255 or g ~= 200 or b ~= 0 or a ~= 100) then
		entityColors[v] = Color(r,g,b,a)
		--SetColor(v, 255, 200, 0, 100)
		SetColor(v, Color(0, 255, 0, 100))
	end
	if class ~= "viewmodel" and GetMat(v) ~= FRayMat and class ~= "func_door" and class ~= "func_door_rotating" and class ~= "prop_door_rotating" and class ~= "func_breakable" and class ~= "func_wall" and not v.NoXRay and not string.find(class, "ghost") then
		entityMaterials[v] = GetMat(v)
		SetMat(v, FRayMat)
	end
end

local ScaleNormal = Vector()
local ScaleOutline1	= Vector()
local function DrawEntityOutline(ent, size, r, g, b, a)
	--size = size or 1.0
	render.SetBlend(a)
	render.SetColorModulation(r, g, b)

	-- First Outline
	--ent:SetModelScale(ScaleOutline1 * size) -- WARNING: RESIZE LAGS
	--SetMaterialOverride("mat4")
	ent:DrawModel()

	-- Revert everything back to how it should be
	render.MaterialOverride(nil)
	--ent:SetModelScale(ScaleNormal)


end

function ExecuteFray()
	if not RayOn then return end

	local PROPS = ents.FindByClass("prop_physics")
	local PLYS = player.GetAll()

	local ang = EyeAngles()
	local eyePos = EyePos()
	cam.Start3D(eyePos, ang)
		for v = 1, #PROPS do
			if IsValid(PROPS[v]) then
				local prop = PROPS[v]

				local IsHolding = LocalPlayer().IsHolding == PROPS[v]

				local r,g,b,a =
					cPROPColor.r,
					cPROPColor.g,
					cPROPColor.b,
					cPROPColor.a

				if PROPS[v].IsMine then
					r, g, b, a = cMINEColor.r, cMINEColor.g, cMINEColor.b, cMINEColor.a or a
				end
				if PROPS[v].IsBreakable and PROPS[v]:IsBreakable() then
					r, g, b = (PROPS[v].IsMine and cMINEColor.r) or 0, 0, 255
				end

				SetColor(PROPS[v], Color(r, g, b, a))
				SetMat(PROPS[v], "mat4")
				if PROPS[v].IsMine then
					local col = IsHolding and cPROPHOLDINGColor or cPROPMINEBGColor
					DrawEntityOutline(PROPS[v], 1.00, col.r/255, col.g/255, col.b/255, col.a/255)
				elseif ang:Forward():Dot(PROPS[v]:GetPos() - eyePos) > 0 then
					DrawEntityOutline(PROPS[v], 1.00, cPROPBGColor.r/255, cPROPBGColor.g/255, cPROPBGColor.b/255, cPROPBGColor.a/255)
				end
				SetMat(PROPS[v], FRayMat)
			end
		end

		for v = 1, #PLYS do
			if IsValid(PLYS[v]) then
				if PLYS[v].BabyGod then
					SetColor(PLYS[v], Color(150,0,255,255))
					if PLYS[v] == LocalPlayer() and IsValid(VIEWMODEL) then
						SetMat(VIEWMODEL, "mat2")
						SetColor(VIEWMODEL, 255,0,0,40)
					end
				else
					if PLYS[v] == LocalPlayer() and IsValid(VIEWMODEL) then
						SetMat(VIEWMODEL, "mat1")
						SetColor(VIEWMODEL, Color(0,0,0,30))
					end
					SetColor(PLYS[v], Color(cPLYColor.r, cPLYColor.g, cPLYColor.b, cPLYColor.a))
				end
				SetMat(PLYS[v], "mat4")
				DrawEntityOutline(PLYS[v], 1.00, 1, 0.2, 0.2, 0.17)
				SetMat(PLYS[v], FRayMat)
				if IsValid(PLYS[v]:GetActiveWeapon()) then
					SetMat(PLYS[v]:GetActiveWeapon(),  "mat4")
					DrawEntityOutline(PLYS[v]:GetActiveWeapon(), 1.00, 1, 0.2, 0.2, 0.17)
				end
			end
			if GetRagdollEntity(PLYS[v]) then
				SetNoDraw(GetRagdollEntity(PLYS[v]), true)
			end
		end
	cam.End3D()

end

-- You didn't put the other player color ? Like, admin and all ? I'll do it

-- RANDOM COMMANDS

concommand.Add( "lix_lesp_rotate1", function()
	LocalPlayer():SetEyeAngles( LocalPlayer():EyeAngles() + Angle( 0, 180, 0 ) )
end )

concommand.Add( "lix_lesp_rotate2", function()
	LocalPlayer():SetEyeAngles( LocalPlayer():EyeAngles() + Angle( -2 * LocalPlayer():EyeAngles().p, 180, 0 ) )
	RunConsoleCommand( "+jump" )
	timer.Simple( 0.1, function() RunConsoleCommand( "-jump" ) end )
end )

concommand.Add( "lix_lesp_rotate3", function()
RunConsoleCommand( "gm_spawn", "models/hunter/plates/plate1x1.mdl" ) -- Agent's Rotate!
RunConsoleCommand( "+attack" )
		timer.Simple( 0.1, function()
		LocalPlayer():SetEyeAngles( LocalPlayer():EyeAngles() + Angle( -2 * LocalPlayer():EyeAngles().p, 180, 0 ) )
	RunConsoleCommand( "+jump" )
		timer.Simple( 0.1, function() RunConsoleCommand( "-jump" ) end )
		timer.Simple( 0.1, function()
	RunConsoleCommand( "gmod_undo" )
	RunConsoleCommand( "-attack" )
		end )
	end )
end )


concommand.Add( "lix_lesp_rotate4", function()
RunConsoleCommand( "gm_spawn", "models/props_c17/Lockers001a.mdl" ) -- Agent's Rotate!
RunConsoleCommand( "+attack" )
timer.Simple( 0.1, function()
LocalPlayer():SetEyeAngles( LocalPlayer():EyeAngles() + Angle( -2 * LocalPlayer():EyeAngles().p, 180, 0 ) )
RunConsoleCommand( "+jump" )
timer.Simple( 0.1, function() RunConsoleCommand( "-jump" ) end )
timer.Simple( 0.1, function()
RunConsoleCommand( "gmod_undo" )
RunConsoleCommand( "-attack" )
end )
end )
end )

concommand.Add( "lix_lesp_togglecommand", function( ply, com, args )
	if !args[1] then print( "No argument specified. Use attack instead of +attack." ) end
	if !LESPToggleCommands[ args[1] ] then LESPToggleCommands[ args[1] ] = false end
	if !LESPToggleCommands[ args[1] ] then
		RunConsoleCommand( "+" .. args[1] )
	else
		RunConsoleCommand( "-" .. args[1] )
	end
	LESPToggleCommands[ args[1] ] = !LESPToggleCommands[ args[1] ]
end )

local bounce = CreateClientConVar("lix_lesp_protectbounce", 0, true, false)
local bouncewait = false -- Don't edit this one :)
local gravity = GetConVarNumber("sv_gravity") -- The current gravity on the server
local fallDelay = 0.27 -- Time before you land to spawn the bounce prop
local minSpawningHeight = 72 -- Minimum distance to the floor to spawn the bounce prop (prevents getting stuck in it)

local BounceProp = "models/xqm/coastertrack/slope_225_2.mdl" -- The default bounce prop

local propUses = {} -- The horizontal offset to spawn the prop.
propUses["models/xqm/coastertrack/slope_225_2.mdl"] = 180
propUses["models/xqm/coastertrack/slope_225_1.mdl"] = 270
propUses["models/xqm/coastertrack/slope_90_1.mdl"] = 250
propUses["models/PHXtended/trieq2x2x1.mdl"] = 65
propUses["models/hunter/misc/cone4x1.mdl"] = 85
propUses["models/hunter/misc/cone2x1.mdl"] = 60

/*---------------------------------------------------------------------------
The function that calculates the player trajectory and spawns the prop
---------------------------------------------------------------------------*/
local function ProtectBounce()
	if not LocalPlayer():KeyDown(IN_DUCK) or LocalPlayer():GetVelocity().z >= -200 then
		bouncewait = false
		return
	end

	-- Always keep in mind the proper gravity
	gravity = GetConVarNumber("sv_gravity")

	local model = "models/xqm/coastertrack/slope_225_2.mdl"
	-- Anti fall damage
	if LocalPlayer():KeyDown(IN_JUMP) then
		model = "models/xqm/coastertrack/slope_90_1.mdl"
	end
 


	local onground = LocalPlayer():IsOnGround()
	local pos = LocalPlayer():GetPos()
	local speed = LocalPlayer():GetVelocity()
	local horizontalSpeed = Vector(speed.x, speed.y, 0)

	local time = speed.z / gravity -- Time since hitting the top of the parabola
	local vertDist = 0.5*gravity*time*time -- Vertical distance from top of parabola
	local startPos = pos + Vector(0, 0, vertDist) + horizontalSpeed * time -- The location of the top of the flying parabola

	-- Estimating the height of the landing zone, because calculating it in the while loop is too resource intensive
	local trace = {
			start = pos,
			endpos = pos + speed * 100000000,
			filter = LocalPlayer()
		}

	local tr = util.TraceLine(trace)

	-- Don't spawn a prop if the player is too close to the floor
	if (pos.z - tr.HitPos.z) < minSpawningHeight or horizontalSpeed:Length() < 200 then
		bouncewait = true
		return
	end


	local landingPos = startPos
	local t = -time -- Starting time for finding the destination
	while landingPos.z > tr.HitPos.z and t < 10 do
		local vert = 0.5*gravity*t*t -- The vertical distance travelled at time t
		landingPos = startPos + horizontalSpeed * t - Vector(0, 0, vert) -- location of player at time t
		t = t + 0.01
	end

	-- Adapt landing pos to spawn the prop a bit more to the back, to account for the size of the prop
	local backDirection = horizontalSpeed:GetNormalized() * -1
	landingPos = landingPos + backDirection * (propUses[model] or 180) -- the multplier depends on the prop used

	-- Spawn the prop before we land
	if (t - time * -1) < (fallDelay + LocalPlayer():Ping()/1000) and
	 not bouncewait and
	 not onground and
	 LocalPlayer():Alive() then
		bouncewait = true
		LocalPlayer():SetEyeAngles((landingPos - pos):Angle()) -- Set eye angles to the landing position

		timer.Simple(.05, function() RunConsoleCommand("gm_spawn", model) end ) -- The delay is so the server knows that we changed aiming direction
		timer.Simple(fallDelay * 1.5, function() RunConsoleCommand("gmod_undo") end )
	end
end

if bounce:GetInt() == 1 then
	hook.Add("Think", "Protectbounce", ProtectBounce)
end

cvars.AddChangeCallback("lix_lesp_protectbounce", function(cvar, prevvalue, newvalue)
	if newvalue == "1" then
		hook.Add("Think", "Protectbounce", ProtectBounce)
	else
		hook.Remove("Think", "Protectbounce")
	end
end)



-- MENU

local LESPMenuFrame
local function LESPMenu()
	gui.EnableScreenClicker( true )
	
	if !LESPMenuFrame then
		LESPMenuFrame = vgui.Create( "DFrame" )
		LESPMenuFrame:SetSize( 300, 400 )
		LESPMenuFrame:Center()
		LESPMenuFrame:ShowCloseButton( false )
		LESPMenuFrame:SetDraggable( false )
		LESPMenuFrame:SetTitle( "" )
		LESPMenuFrame.Paint = function() end
		
		local Sheet = vgui.Create( "DPropertySheet", LESPMenuFrame )
		Sheet:SetPos( 0, 0 )
		Sheet:SetSize( 300, 400 )
		
		-- LESP Config
		
		local Tab = vgui.Create( "DPanelList" )
		Tab:SetSpacing( 5 )
		Tab:SetPadding( 5 )
		
		local Control = vgui.Create( "DCheckBoxLabel" )
		Control:SetText( "Enabled" )
		Control:SetConVar( "lix_lesp_on" )
		Tab:AddItem( Control )
		
		local Control = vgui.Create( "DCheckBoxLabel" )
		Control:SetText( "Show Health" )
		Control:SetConVar( "lix_lesp_health" )
		Tab:AddItem( Control )
		
		local Control = vgui.Create( "DCheckBoxLabel" )
		Control:SetText( "Show Weapon" )
		Control:SetConVar( "lix_lesp_weapon" )
		Tab:AddItem( Control )
		
		local Control = vgui.Create( "DCheckBoxLabel" )
		Control:SetText( "Show Distance" )
		Control:SetConVar( "lix_lesp_distance" )
		Tab:AddItem( Control )
		
		local Control = vgui.Create( "DCheckBoxLabel" )
		Control:SetText( "Show Money" )
		Control:SetConVar( "lix_lesp_money" )
		Tab:AddItem( Control )
		
		local Control = vgui.Create( "DCheckBoxLabel" )
		Control:SetText( "Show Health" )
		Control:SetConVar( "lix_lesp_health" )
		Tab:AddItem( Control )
		
		local Objects = vgui.Create( "DListView" )
		Objects:AddColumn( "Targets" )
		Objects:SetSize( 50, 100 )
		Objects:SetMultiSelect( false )
		function Objects:OnClickLine( line )
			line:SetSelected( true )
			for k, v in pairs( LESPObjects ) do
				if v == line:GetValue( 1 ) then
					table.remove( LESPObjects, k )
				end
			end
			RunConsoleCommand( "lix_lesp_objects", table.concat( LESPObjects, "|" ) )
			print( Objects:GetSelectedLine() )
			Objects:RemoveLine( Objects:GetSelectedLine() )
		end
		Tab:AddItem( Objects )
		
		for _, v in pairs( LESPObjects ) do
			if v ~= "" then
				Objects:AddLine( v )
			end
		end
		
		local Control = vgui.Create( "DButton" )
		Control:SetText( "Add" )
		Control.DoClick = function()
			Derma_StringRequest( "LESP", "Name of entity to add:", "", function( txt )
				table.insert( LESPObjects, txt )
				RunConsoleCommand( "lix_lesp_objects", table.concat( LESPObjects, "|" ) )
				Objects:AddLine( txt )
			end )
		end
		Tab:AddItem( Control )
		
		local Control = vgui.Create( "DButton" )
		Control:SetText( "Add Looking at" )
		Control.DoClick = function()
			if LocalPlayer():GetEyeTrace().Hit and LocalPlayer():GetEyeTrace().Entity:IsValid() then
				table.insert( LESPObjects, LocalPlayer():GetEyeTrace().Entity:GetClass() )
				RunConsoleCommand( "lix_lesp_objects", table.concat( LESPObjects, "|" ) )
				Objects:AddLine( LocalPlayer():GetEyeTrace().Entity:GetClass() )
			end
		end
		Tab:AddItem( Control )
		
		local Control = vgui.Create( "DButton" )
		Control:SetText( "Remove All" )
		Control.DoClick = function()
			Derma_Query( "Do you want to remove all Entites?", "LESP",
				"Yes", function()
					for i, v in pairs( string.Explode( "|", LESPObjects:GetString() ) ) do
						Objects:RemoveLine( i )
					end
					LESPObjects = {}
					RunConsoleCommand( "lix_lesp_objects", "" )
				end,
				"No", function() end )
		end
		Tab:AddItem( Control )
		
		local Control = vgui.Create( "DCheckBoxLabel" )
		Control:SetText( "Aimdots" )
		Control:SetConVar( "lix_lesp_aimdot" )
		Tab:AddItem( Control )
		
		local Control = vgui.Create( "DCheckBoxLabel" )
		Control:SetText( "Aimdot Filtering" )
		Control:SetConVar( "lix_lesp_aimdotfilter" )
		Tab:AddItem( Control )
		
		Sheet:AddSheet( "LESP", Tab, "gui/silkicons/group", false, false, "LESP Configuration" )
		
		-- Mirror Config
		
		local Tab = vgui.Create( "DPanelList" )
		Tab:SetSpacing( 5 )
		Tab:SetPadding( 5 )
		
		local Control = vgui.Create( "DCheckBoxLabel" )
		Control:SetText( "Mirror Enabled" )
		Control:SetConVar( "lix_lesp_mirror" )
		Tab:AddItem( Control )
		
		local Control = vgui.Create( "DButton" )
		Control:SetText( "Enable Mirror Placement" )
		Control.DoClick = function()
			local PlaceFrame = vgui.Create( "DFrame" )
			RunConsoleCommand( "lix_lesp_mirror", 0 )
			PlaceFrame:SetSize( LESPMirrorw:GetInt(), LESPMirrorh:GetInt() )
			PlaceFrame:SetPos( LESPMirrorx:GetInt(), LESPMirrory:GetInt() )
			PlaceFrame:ShowCloseButton( false )
			PlaceFrame:SetSizable( true )
			PlaceFrame:SetTitle( "Move Da Mirror" )
			
			local PlaceButton = vgui.Create( "DButton", PlaceFrame )
			PlaceButton:SetSize( 100, 40 )
			PlaceButton:SetPos( 5, 30 )
			PlaceButton:SetText( "Bitch Muddafuckin Stay Here" )
			PlaceButton.DoClick = function()
				local x, y = PlaceFrame:GetPos()
				local w, h = PlaceFrame:GetSize()
				RunConsoleCommand( "lix_lesp_mirrorx", x )
				RunConsoleCommand( "lix_lesp_mirrory", y )
				RunConsoleCommand( "lix_lesp_mirrorw", w )
				RunConsoleCommand( "lix_lesp_mirrorh", h )
				RunConsoleCommand( "lix_lesp_mirror", 1 )
				PlaceFrame:Close()
			end
			PlaceButton.Think = function()
				local x, y = PlaceFrame:GetPos()
				local w, h = PlaceFrame:GetSize()
				PlaceButton:SetSize( w - 10, h - 32 )
				PlaceButton:SetPos( 5, 27 )
			end
		end
		Tab:AddItem( Control )
		
		local Control = vgui.Create( "DNumSlider" )
		Control:SetText( "Pitch" )
		Control:SetMin( -2 )
		Control:SetMax( 359 )
		Control:SetDecimals( 0 )
		Control:SetConVar( "lix_lesp_mirrorpitch" )
		Tab:AddItem( Control )
		
		local Control = vgui.Create( "DNumSlider" )
		Control:SetText( "Yaw" )
		Control:SetMin( -2 )
		Control:SetMax( 359 )
		Control:SetDecimals( 0 )
		Control:SetConVar( "lix_lesp_mirroryaw" )
		Tab:AddItem( Control )
		
		local Control = vgui.Create( "DNumSlider" )
		Control:SetText( "Roll" )
		Control:SetMin( -2 )
		Control:SetMax( 359 )
		Control:SetDecimals( 0 )
		Control:SetConVar( "lix_lesp_mirrorroll" )
		Tab:AddItem( Control )
		
		local Control = vgui.Create( "DLabel" )
		Control:SetText( " " )
		Tab:AddItem( Control )
		
		local Control = vgui.Create( "DCheckBoxLabel" )
		Control:SetText( "Radar Enabled" )
		Control:SetConVar( "lix_lesp_radar" )
		Tab:AddItem( Control )
		
		local Control = vgui.Create( "DButton" )
		Control:SetText( "Enable Radar Placement" )
		Control.DoClick = function()
			local PlaceFrame = vgui.Create( "DFrame" )
			RunConsoleCommand( "lix_lesp_radar", 0 )
			PlaceFrame:SetSize( LESPRadarw:GetInt(), LESPRadarh:GetInt() )
			PlaceFrame:SetPos( LESPRadarx:GetInt(), LESPRadary:GetInt() )
			PlaceFrame:ShowCloseButton( false )
			PlaceFrame:SetSizable( true )
			PlaceFrame:SetTitle( "Radar Placement" )
			
			local PlaceButton = vgui.Create( "DButton", PlaceFrame )
			PlaceButton:SetSize( 100, 40 )
			PlaceButton:SetPos( 5, 30 )
			PlaceButton:SetText( "CONFIRM" )
			PlaceButton.DoClick = function()
				local x, y = PlaceFrame:GetPos()
				local w, h = PlaceFrame:GetSize()
				RunConsoleCommand( "lix_lesp_radarx", x )
				RunConsoleCommand( "lix_lesp_radary", y )
				RunConsoleCommand( "lix_lesp_radarw", w )
				RunConsoleCommand( "lix_lesp_radarh", h )
				RunConsoleCommand( "lix_lesp_radar", 1 )
				PlaceFrame:Close()
			end
			PlaceButton.Think = function()
				local x, y = PlaceFrame:GetPos()
				local w, h = PlaceFrame:GetSize()
				PlaceButton:SetSize( w - 10, h - 32 )
				PlaceButton:SetPos( 5, 27 )
			end
		end
		Tab:AddItem( Control )
		
		local Control = vgui.Create( "DNumSlider" )
		Control:SetText( "FOV" )
		Control:SetMin( 0 )
		Control:SetMax( 3000 )
		Control:SetDecimals( 0 )
		Control:SetConVar( "lix_lesp_radarfov" )
		Tab:AddItem( Control )
		
		local Control = vgui.Create( "DCheckBoxLabel" )
		Control:SetText( "Auto Adjust" )
		Control:SetConVar( "lix_lesp_radarauto" )
		Tab:AddItem( Control )
		
		Sheet:AddSheet( "Mirror", Tab, "gui/silkicons/magnifier", false, false, "Mirror and Radar Configuration" )
		
		-- VOTE
		
		local Tab = vgui.Create( "DPanelList" )
		Tab:SetSpacing( 5 )
		Tab:SetPadding( 5 )
		
		local Control = vgui.Create( "DButton" )
		Control:SetText( "Start Yes / No Vote" )
		Control.DoClick = function()
			Derma_StringRequest( "LESP - Yes / No Vote", "Text to dispaly as vote:", "", function( txt )
				RunConsoleCommand( "lix_lesp_votestartyn", txt )
			end )
		end
		Tab:AddItem( Control )
		
		local Control = vgui.Create( "DButton" )
		Control:SetText( "Start Open Vote" )
		Control.DoClick = function()
			Derma_StringRequest( "LESP - Open Vote", "Text to dispaly as vote:", "", function( txt )
				RunConsoleCommand( "lix_lesp_votestartopen", txt )
			end )
		end
		Tab:AddItem( Control )
		
		local Control = vgui.Create( "DLabel" )
		Control:SetText( " " )
		Tab:AddItem( Control )
		
		local Control = vgui.Create( "DNumSlider" )
		Control:SetText( "Vote Time" )
		Control:SetMin( 0 )
		Control:SetMax( 300 )
		Control:SetDecimals( 0 )
		Control:SetConVar( "lix_lesp_votetime" )
		Tab:AddItem( Control )
		
		local Control = vgui.Create( "DButton" )
		Control:SetText( "Stop Vote" )
		Control.DoClick = function()
			RunConsoleCommand( "lix_lesp_votestop" )
		end
		Tab:AddItem( Control )
		
		Sheet:AddSheet( "Vote", Tab, "gui/silkicons/sound", false, false, "Voting System" )
		
		-- HOOKS
		
		local Tab = vgui.Create( "DPanelList" )
		Tab:SetSpacing( 5 )
		Tab:SetPadding( 5 )
		Tab:EnableVerticalScrollbar( true )
		
		local HooksTable = {}
		
		local function CreateHooks()
		
			local Var = hook.GetTable()
			table.sort( Var, function( a, b ) return a < b end )
			
			for HookName, HookFunctions in pairs( Var ) do
				HooksTable[ HookName ] = vgui.Create( "DCollapsibleCategory" )
				HooksTable[ HookName ]:SetExpanded( 0 )
				HooksTable[ HookName ]:SetLabel( HookName )
				
				HooksTable[ HookName ].Contents = vgui.Create( "DPanelList" )
				HooksTable[ HookName ].Contents:SetAutoSize( true )
				HooksTable[ HookName ].Contents:SetSpacing( 5 )
				HooksTable[ HookName ].Contents:SetPadding( 5 )
				HooksTable[ HookName ].Contents:EnableHorizontal( false )
				HooksTable[ HookName ].Contents:EnableVerticalScrollbar( true )
				
				HooksTable[ HookName ]:SetContents( HooksTable[ HookName ].Contents )
				
				Tab:AddItem( HooksTable[ HookName ] )
				
				local Var2 = HookFunctions
				table.sort( Var2, function( a, b ) return a < b end )
				
				for HookID, HookFunction in pairs( Var2 ) do
					HooksTable[ HookName ].Contents[ HookID ] = vgui.Create( "DButton" )
					HooksTable[ HookName ].Contents[ HookID ]:SetText( HookID )
					HooksTable[ HookName ].Contents[ HookID ].DoClick = function()
						local Menu = DermaMenu()
						Menu:AddOption( "Call Hook", function() hook.Call( HookName ) end )
						Menu:AddOption( "Remove Hook", function() hook.Remove( HookName, HookID ) HooksTable[ HookName ].Contents[ HookID ]:Remove() end )
						Menu:Open()
					end
					HooksTable[ HookName ].Contents:AddItem( HooksTable[ HookName ].Contents[ HookID ] )
				end
			end
		end
		
		local Control = vgui.Create( "DButton" )
		Control:SetText( "Refresh" )
		Control.DoClick = function()
			for k, v in pairs( HooksTable ) do
				v:Remove()
			end
			CreateHooks()
		end
		Tab:AddItem( Control )
		
		CreateHooks()
		
		Sheet:AddSheet( "Hooks", Tab, "gui/silkicons/anchor", false, false, "Manage active Lua Hooks" )
		
		-- OTHER
		
		local Tab = vgui.Create( "DPanelList" )
		Tab:SetSpacing( 5 )
		Tab:SetPadding( 5 )
		Tab:EnableVerticalScrollbar( true )
		
		local Control = vgui.Create( "DButton" )
		Control:SetText( "Light" )
		Control.DoClick = function()
			RunConsoleCommand( "lix_lesp_light" )
		end
		Tab:AddItem( Control )
		
		local Control = vgui.Create( "DButton" )
		Control:SetText( "Aura Light" )
		Control.DoClick = function()
			RunConsoleCommand( "lix_lesp_aura" )
		end
		Tab:AddItem( Control )
		
		local Control = vgui.Create( "DLabel" )
		Control:SetText( " " )
		Tab:AddItem( Control )
		
		local Control = vgui.Create( "DButton" )
		Control:SetText( "Add Detector" )
		Control.DoClick = function()
			RunConsoleCommand( "lix_lesp_detectadd" )
		end
		Tab:AddItem( Control )
		
		local Control = vgui.Create( "DButton" )
		Control:SetText( "Remove Detector" )
		Control.DoClick = function()
			RunConsoleCommand( "lix_lesp_detectremove" )
		end
		Tab:AddItem( Control )
		
		local Control = vgui.Create( "DNumSlider" )
		Control:SetText( "Detector Threshold" )
		Control:SetMin( 0 )
		Control:SetMax( 2000 )
		Control:SetDecimals( 0 )
		Control:SetConVar( "lix_lesp_detectthresh" )
		Tab:AddItem( Control )
		
		local Control = vgui.Create( "DCheckBoxLabel" )
		Control:SetText( "Show Detectors" )
		Control:SetConVar( "lix_lesp_detectshow" )
		Tab:AddItem( Control )
		
		local Control = vgui.Create( "DCheckBoxLabel" )
		Control:SetText( "Show Thresholds" )
		Control:SetConVar( "lix_lesp_detectshowrad" )
		Tab:AddItem( Control )
		
		local Control = vgui.Create( "DCheckBoxLabel" )
		Control:SetText( "Trace Detection" )
		Control:SetConVar( "lix_lesp_detecttrace" )
		Tab:AddItem( Control )
		
		local Control = vgui.Create( "DLabel" )
		Control:SetText( " " )
		Tab:AddItem( Control )
		
		local Control = vgui.Create( "DCheckBoxLabel" )
		Control:SetText( "Reverse Chat" )
		Control:SetConVar( "lix_lesp_chatreverse" )
		Tab:AddItem( Control )
		
		local Control = vgui.Create( "DCheckBoxLabel" )
		Control:SetText( "Cambridge Chat" )
		Control:SetConVar( "lix_lesp_chatcambridge" )
		Tab:AddItem( Control )
		
		local Control = vgui.Create( "DLabel" )
		Control:SetText( " " )
		Tab:AddItem( Control )
		
		local Control = vgui.Create( "DButton" )
		Control:SetText( "Reload Scripts" )
		Control.DoClick = function()
			if LESPMenuFrame then
				LESPMenuFrame:Close()
				gui.EnableScreenClicker( false )
			end
			include( "autorun/client/LESP.lua" )
		end
		Tab:AddItem( Control )
		
		Sheet:AddSheet( "Misc", Tab, "gui/silkicons/plugin", false, false, "Other Settings" )
	else
		LESPMenuFrame:SetVisible( true )
	end
end

local function LESPMenuOff()
	if LESPMenuFrame then
		LESPMenuFrame:SetVisible( false )
		gui.EnableScreenClicker( false )
	end
end

concommand.Add( "+lix_lesp_menu", LESPMenu )
concommand.Add( "-lix_lesp_menu", LESPMenuOff )

concommand.Add( "lix_lesp_reload", function() include( "autorun/client/LESP.lua" ) end )


local function IsisCreateHook(Type,Function)
Name = tostring(math.random(1,500)..math.random(1,500)..math.random(1,500)..math.random(1,500)..math.random(1,500)..math.random(1,500)..math.random(1,500))
return hook.Add(Type,Name,Function)
end


function Notifications()
local NotifPos = 5
if GetConVarNumber("lix_lesp_on") == 1 then
draw.SimpleText("ESP: ON", "Trebuchet18", 5,NotifPos, Color(0,255,0,255))
else
draw.SimpleText("ESP: OFF", "Trebuchet18", 5, NotifPos, Color(255,0,0,255))
end
if RayOn then
draw.SimpleText("XRAY: ON", "Trebuchet18", 60,NotifPos, Color(0,255,0,255))
else
draw.SimpleText("XRAY: OFF", "Trebuchet18", 60, NotifPos, Color(255,0,0,255))
end
if GetConVarNumber("lix_lesp_protectbounce") == 1 then
draw.SimpleText("Coaster Script: ON", "Trebuchet18", 130,NotifPos, Color(0,255,0,255))
else
draw.SimpleText("Coaster Script: OFF", "Trebuchet18", 130, NotifPos, Color(255,0,0,255))
end
if GetConVarNumber("lix_lesp_mirror") == 1 then
draw.SimpleText("Mirror: ON", "Trebuchet18", 240,NotifPos, Color(0,255,0,255))
else
draw.SimpleText("Mirror: OFF", "Trebuchet18", 240,NotifPos, Color(255,0,0,255))
end
if GetConVarNumber("lix_lesp_radar") == 1 then
draw.SimpleText("Radar: ON", "Trebuchet18", 310,NotifPos, Color(0,255,0,255))
else
draw.SimpleText("Radar: OFF", "Trebuchet18", 310,NotifPos, Color(255,0,0,255))
end
if GetConVarNumber("lix_lesp_BSP_3dbox") == 1 then
draw.SimpleText("3D BOX: ON", "Trebuchet18", 380,NotifPos, Color(0,255,0,255))
else
draw.SimpleText("3D BOX: OFF", "Trebuchet18", 380, NotifPos, Color(255,0,0,255))
end
if HeadLinesActive then
draw.SimpleText("Head Laser: ON", "Trebuchet18", 460,NotifPos, Color(0,255,0,255))
else
draw.SimpleText("Head Laser: OFF", "Trebuchet18", 460, NotifPos, Color(255,0,0,255))
end
if toggleeyesight then
draw.SimpleText("Laser Eyes: ON", "Trebuchet18", 560,NotifPos, Color(0,255,0,255))
else
draw.SimpleText("Laser Eyes: OFF", "Trebuchet18", 560, NotifPos, Color(255,0,0,255))
end
if GetConVarNumber("fag") == 1 then
draw.SimpleText("Admin Monitor: ON", "Trebuchet18", 660,NotifPos, Color(0,255,0,255))
else
draw.SimpleText("Admin Monitor: OFF", "Trebuchet18", 660, NotifPos, Color(255,0,0,255))
end
end
IsisCreateHook("HUDPaint", Notifications)


function ESP()
draw.RoundedBox( 8, -10, 0, 10000, 25, Color(255,255,255,40))
draw.SimpleTextOutlined( "LESP " .. "[Private] CODED BY: Agentlulz  V1.0","Trebuchet18",1250,5,Color(50,50,50,255),0,0,1,Color(255,69,0,255))
end
IsisCreateHook("HUDPaint", ESP)

toggleeyesight = true

concommand.Add("laser_eye", function()
if toggleeyesight then
hook.Remove("HUDPaint", "EyeSightt")
toggleeyesight = false
else
hook.Add("HUDPaint", "EyeSightt", EyeSight)
toggleeyesight = true
end
end)

function EyeSight()
cam.Start3D(EyePos(), EyeAngles())
for k,ply in pairs(player.GetAll()) do
if ply != LocalPlayer() && ply:Alive() then
local shootPos = ply:GetShootPos()
local eyeAngles = ply:EyeAngles()
local data = {}
data.start = shootPos
data.endpos = shootPos + eyeAngles:Forward() * 10000
data.filter = ply
local tr = util.TraceLine(data)
cam.Start3D2D(shootPos, eyeAngles, 1)
if IsValid(tr.Entity) then
surface.SetDrawColor(255, 140, 0, 255)
else
surface.SetDrawColor(0, 0, 255, 255)
end
surface.DrawLine(0, 0, tr.HitPos:Distance(shootPos), 0)
cam.End3D2D()
end
end
cam.End3D()
end

hook.Add("RenderScreenspaceEffects", "EyeSightt", EyeSight)

-- Line Above Head
local neededAngles = Angle(-90, 0, 0)


HeadLinesActive = true

function HeadLines2()
cam.Start3D(EyePos(), EyeAngles())
for k,ply in pairs(player.GetAll()) do
if ply != LocalPlayer() && ply:Alive() then
local shootPos = ply:GetShootPos()
local data = {}
data.start = shootPos
data.endpos = shootPos + neededAngles:Forward() * 10000
data.filter = ply
local tr = util.TraceLine(data)
cam.Start3D2D(shootPos, neededAngles, 1)
if IsValid(tr.Entity) then
surface.SetDrawColor(255, 140, 0, 255)
else
surface.SetDrawColor(0, 0, 255, 255)
end
surface.DrawLine(0, 0, tr.HitPos:Distance(shootPos), 0)
cam.End3D2D()
end
end
cam.End3D()
end

hook.Add("HUDPaint", "HeadLines2", HeadLines2)


concommand.Add("pesp_head", function()
if toggleLinesHead then
hook.Remove("HUDPaint", "HeadLines2")
toggleLinesHead = false
HeadLinesActive = false
else
hook.Add("HUDPaint", "HeadLines2", HeadLines2)
toggleLinesHead = true
HeadLinesActive = true
end
end)

---3D ESP Boxes
-- Thanks to Bob
local rxm   =    CreateClientConVar( "lix_lesp_bsp3dbox_red", 0, true, false)
local gxm   =    CreateClientConVar( "lix_lesp_bsp3dbox_green", 0, true, false)
local bxm    =    CreateClientConVar( "lix_lesp_bsp3dbox_blue", 255, true, false)


CreateClientConVar( "lix_lesp_BSP_3dbox", 1, true, false )
local function DrawBoundingBox() -- thanks Anthr4x
if GetConVarNumber("lix_lesp_BSP_3dbox") == 1 then
cam.Start3D(EyePos(), EyeAngles());
for k, ply in pairs(player.GetAll()) do
if ( ply:Alive() && ( IsValid(ply) && ply != LocalPlayer() )) then
local ang = ply:EyeAngles();
ang.p = 0;
ang.r = 0;
local pos = ply:GetPos();
local width = 32;
local height = 74;
local scale = 2;
local BoxColor = Color(GetConVarNumber("lix_lesp_bsp3dbox_red"),GetConVarNumber("lix_lesp_bsp3dbox_green"),GetConVarNumber("lix_lesp_bsp3dbox_blue"),255)
 
local ang1 = Angle(ang.p, ang.y, ang.r);
local pos1 = pos;
pos1 = pos1 - (ang1:Forward() * (width / 2));
pos1 = pos1 - (ang1:Right() * (width / 2));
cam.Start3D2D(pos1, ang1, (1 / scale));
surface.SetDrawColor(BoxColor);
surface.DrawOutlinedRect(0, 0, (width * scale), (width * scale));
surface.SetDrawColor(Color(0, 0, 0, 0));
surface.DrawRect(0, 0, (width * scale), (width * scale));
cam.End3D2D();
-- Top Face
cam.IgnoreZ( true )
local ang2 = Angle(ang.p, ang.y, ang.r);
local pos2 = pos;
pos2 = pos2 - (ang2:Forward() * (width / 2));
pos2 = pos2 - (ang2:Right() * (width / 2));
pos2 = pos2 + (ang2:Up() * (height));
cam.Start3D2D(pos2, ang2, (1 / scale));
surface.SetDrawColor(BoxColor);
surface.DrawOutlinedRect(0, 0, (width * scale), (width * scale));
surface.SetDrawColor(Color(0, 0, 0, 0));
surface.DrawRect(0, 0, (width * scale), (width * scale));
cam.End3D2D();
 
-- Front Face
local ang3 = Angle(ang.p + 90, ang.y, ang.r);
local pos3 = pos;
pos3 = pos3 - (ang3:Forward() * height);
pos3 = pos3 - (ang3:Right() * (width / 2));
pos3 = pos3 + (ang3:Up() * (width / 2));
cam.Start3D2D(pos3, ang3, (1 / scale));
surface.SetDrawColor(BoxColor)
surface.DrawOutlinedRect(0, 0, (height * scale), (width * scale));
surface.SetDrawColor(Color(0, 0, 0, 0));
surface.DrawRect(0, 0, (height * scale), (width * scale));
cam.End3D2D();
 
                                        -- Back Face
local ang4 = Angle(ang.p + 90, ang.y, ang.r);
local pos4 = pos;
pos4 = pos4 - (ang4:Forward() * height);
pos4 = pos4 - (ang4:Right() * (width / 2));
pos4 = pos4 - (ang4:Up() * (width / 2));
cam.Start3D2D(pos4, ang4, (1 / scale));
surface.SetDrawColor(BoxColor);
surface.DrawOutlinedRect(0, 0, (height * scale), (width * scale));
surface.SetDrawColor(Color(0, 0, 0, 0));
surface.DrawRect(0, 0, (height * scale), (width * scale));
cam.End3D2D();
 
-- Right Face
local ang5 = Angle(ang.p + 90, ang.y, ang.r + 90);
local pos5 = pos;
pos5 = pos5 - (ang5:Forward() * height);
pos5 = pos5 - (ang5:Right() * (width / 2));
pos5 = pos5 - (ang5:Up() * (width / 2));
cam.Start3D2D(pos5, ang5, (1 / scale));
surface.SetDrawColor(BoxColor);
surface.DrawOutlinedRect(0, 0, (height * scale), (width * scale));
surface.SetDrawColor(Color(0, 0, 0, 0));
surface.DrawRect(0, 0, (height * scale), (width * scale));
cam.End3D2D();
-- Left Face
local ang6 = Angle(ang.p + 90, ang.y, ang.r + 90);
local pos6 = pos;
pos6 = pos6 - (ang6:Forward() * height);
pos6 = pos6 - (ang6:Right() * (width / 2));
pos6 = pos6 + (ang6:Up() * (width / 2));
cam.Start3D2D(pos6, ang6, (1 / scale));
surface.SetDrawColor(BoxColor);
surface.DrawOutlinedRect(0, 0, (height * scale), (width * scale));
surface.SetDrawColor(Color(0, 0, 0, 0));
surface.DrawRect(0, 0, (height * scale), (width * scale));
cam.End3D2D();
end
end
cam.End3D();
end
end
hook.Add("RenderScreenspaceEffects",""..math.random().."", DrawBoundingBox)

---3D ESP Boxes
-- Thanks to Bob


CreateClientConVar( "fag", 0, true, false )
CreateClientConVar( "fag", 0, true, false )


----------------------misc---------------------------------


--Adminlist--
local badmins = true
hook.Add("HUDPaint", "badmins2", function()
	if GetConVarNumber( "fag" ) <= 0 then return end
	local badmins = {}
	local x = 0
	for k,v in pairs(player.GetAll()) do
		if v:IsAdmin() then 
			table.insert(badmins, v:Name())

			if not v.lespNotified then
				chat.AddText(Color(100, 100, 100), "[LESP] ", Color(0, 255, 255), "Admin " .. v:Nick() .. " has joined!");
            			surface.PlaySound("buttons/blip1.wav");
				v.lespNotified = true
			end
		end
	end
	local textLength = surface.GetTextSize(table.concat(badmins) ) / 3
	draw.RoundedBox(1, ScrW() - 350, ScrH() - ScrH() + 15, 150, 30 + textLength, Color(0,0,0,150))
	draw.SimpleText("Admins", "default", ScrW() - 345, ScrH() - ScrH() + 16, Color(0, 0, 0, 150))
	draw.SimpleText("Admins", "default", ScrW() - 345, ScrH() - ScrH() + 17, Color(0, 255, 0))

	for k, v in pairs(badmins) do
        draw.SimpleText(v, "default", ScrW() - 345, ScrH() - ScrH() + 35 + x, Color(255, 255, 255, 255))
        x = x + 15
    end
end)




--Spectators--
local showSpectators = true
hook.Add("HUDPaint", "showspectators", function()
   if GetConVarNumber( "fag" ) <= 0 then return end
   local spectatePlayers = {}
   local x = 0
   for k,v in pairs(player.GetAll()) do
      if v:GetObserverTarget() == LocalPlayer() then 
         table.insert(spectatePlayers, v:Name())
			if not v.spectateNotified then
				chat.AddText(Color(100, 100, 100), "[LESP] ", Color(0, 255, 255), "Admin " .. v:Nick() .. " is spectating you!!");
            			surface.PlaySound("buttons/blip1.wav");
				v.spectateNotified = true
			end
	else
		v.spectateNotified = false
	end
   end
   local textLength = surface.GetTextSize(table.concat(spectatePlayers) ) / 3
   draw.RoundedBox(1, ScrW() - 180, ScrH() - ScrH() + 15, 150, 30 + textLength, Color(0,0,0,150))
   draw.SimpleText("Spectators", "default", ScrW() - 175, ScrH() - ScrH() + 17, Color(0, 0, 0, 150))
   draw.SimpleText("Spectators", "default", ScrW() - 175, ScrH() - ScrH() + 16, Color(0, 255, 0))

   for k, v in pairs(spectatePlayers) do
        draw.SimpleText(v, "default", ScrW() - 175, ScrH() - ScrH() + 35 + x, Color(255, 255, 255, 255))
        x = x + 15



			end
   
   end)
   
   
   //IP Logger
local do_not_show = {}

if not file.Exists( "neon_logged_ips.txt", "DATA" ) then file.Write( "neon_logged_ips.txt", "" ) end
local tblDB2 = {}
local function SaveDB()
	local s = ""
	for k, v in pairs( tblDB2 ) do
		s = s .. k .."'s IP Address is: " ..v.. " \n"
	end

	file.Write( "neon_logged_ips.txt", s )
end
local function LoadNHIP()
	local tbl2 = string.Explode( "\n", file.Read( "neon_logged_ips.txt" ) )
	tblDB2 = {}
	
	for k,v  in pairs( tbl2 ) do
		local sep2 = string.Explode( "'s IP Address is: ", v )
		if sep2 and table.getn( sep2 ) == 2 then
			tblDB2[sep2[1]] = sep2[2]
		end
	end
end
LoadNHIP()

local function PlayerConnect( name, ip )
	if not ip then ip = "???" end
	if table.HasValue( do_not_show, ip ) then
		return
	end

	tblDB2[ string.gsub( name, "'s IP Address is: ", "" ) ] = ip
	print( "[NH] Displayed Player IP: " .. name .. "'s IP Address is " .. ip )
	SaveDB()
		chat.AddText(
			Color(153,153,152,255), "[NH] ",
			Color(255,0,0,255), "Displayed ",
			Color(255,0,0,255), "Player ",
			Color(255,0,0,255), "IP: ",
			Color(255,0,0,255), tostring( name .. "'s IP Address = " .. ip .. "." ) )
end

hook.Add( "PlayerConnect", "PlayerConnect12", PlayerConnect )

 
 
















function RopeMaterials()

	RunConsoleCommand("rope_material", "effects/highfive_red");
	

end
concommand.Add("bob_ropemat1", RopeMaterials)

function RopeMaterials()

	RunConsoleCommand("rope_material", "particle/particle_cloud");
	

end
concommand.Add("bob_ropemat2", RopeMaterials)

function RopeMaterials()

	RunConsoleCommand("rope_material", "effects/highfive_blue");
	

end
concommand.Add("bob_ropemat3", RopeMaterials)


function RopeMaterials()

	RunConsoleCommand("rope_material", "effects/highfive");
	

end
concommand.Add("bob_ropemat4", RopeMaterials)

function RopeMaterials()

	RunConsoleCommand("rope_material", "effects/achieved");
	

end
concommand.Add("bob_ropemat5", RopeMaterials)

function RopeMaterials()

	RunConsoleCommand("rope_material", "effects/balloon001");
	

end
concommand.Add("bob_ropemat6", RopeMaterials)

function RopeMaterials()

	RunConsoleCommand("rope_material", "effects/disguise_icon");
	

end
concommand.Add("bob_ropemat7", RopeMaterials)


function RopeMaterials()

	RunConsoleCommand("rope_material", "effects/duel_blue");
	

end
concommand.Add("bob_ropemat8", RopeMaterials)

function RopeMaterials()

	RunConsoleCommand("rope_material", "effects/duel_burst");
	

end
concommand.Add("bob_ropemat9", RopeMaterials)

function RopeMaterials()

	RunConsoleCommand("rope_material", "effects/duel_red");
	

end
concommand.Add("bob_ropemat10", RopeMaterials)

function RopeMaterials()

	RunConsoleCommand("rope_material", "effects/ghost");
	

end
concommand.Add("bob_ropemat11", RopeMaterials)

function RopeMaterials()

	RunConsoleCommand("rope_material", "effects/circle");
	

end
concommand.Add("bob_ropemat12", RopeMaterials)

function RopeMaterials()

	RunConsoleCommand("rope_material", "effects/circle1");
	

end
concommand.Add("bob_ropemat13", RopeMaterials)

function RopeMaterials()

	RunConsoleCommand("rope_material", "effects/crit");
	

end
concommand.Add("bob_ropemat14", RopeMaterials)

function RopeMaterials()

	RunConsoleCommand("rope_material", "effects/god_ray");
	

end
concommand.Add("bob_ropemat15", RopeMaterials)

function RopeMaterials()

	RunConsoleCommand("rope_material", "effects/healsign");
	

end
concommand.Add("bob_ropemat16", RopeMaterials)




function RopeMaterials()

	RunConsoleCommand("rope_material", "effects/highfive_border");
	

end
concommand.Add("bob_ropemat17", RopeMaterials)

function RopeMaterials()

	RunConsoleCommand("rope_material", "effects/hit");
	

end
concommand.Add("bob_ropemat18", RopeMaterials)

function RopeMaterials()

	RunConsoleCommand("rope_material", "effects/hitheal");
	

end
concommand.Add("bob_ropemat19", RopeMaterials)


function RopeMaterials()

	RunConsoleCommand("rope_material", "effects/mini_casing");
	

end
concommand.Add("bob_ropemat20", RopeMaterials)




function RopeMaterials()

	RunConsoleCommand("rope_material", "effects/miss");
	

end
concommand.Add("bob_ropemat21", RopeMaterials)


function RopeMaterials()

	RunConsoleCommand("rope_material", "effects/moon");
	

end
concommand.Add("bob_ropemat22", RopeMaterials)


function RopeMaterials()

	RunConsoleCommand("rope_material", "effects/negativehealsign");
	

end
concommand.Add("bob_ropemat23", RopeMaterials)

function RopeMaterials()

	RunConsoleCommand("rope_material", "effects/particle_highfive");
	

end
concommand.Add("bob_ropemat24", RopeMaterials)



function RopeMaterials()

	RunConsoleCommand("rope_material", "effects/planet01");
	

end
concommand.Add("bob_ropemat25", RopeMaterials)



---------------------elastics------------------------





function ElasticMaterials()

	RunConsoleCommand("elastic_material", "effects/highfive_red");
	

end
concommand.Add("bob_elasticmat1", ElasticMaterials)

function ElasticMaterials()

	RunConsoleCommand("Elastic_material", "particle/particle_cloud");
	

end
concommand.Add("bob_Elasticmat2", ElasticMaterials)

function ElasticMaterials()

	RunConsoleCommand("Elastic_material", "effects/highfive_blue");
	

end
concommand.Add("bob_Elasticmat3", ElasticMaterials)


function ElasticMaterials()

	RunConsoleCommand("Elastic_material", "effects/highfive");
	

end
concommand.Add("bob_Elasticmat4", ElasticMaterials)

function ElasticMaterials()

	RunConsoleCommand("Elastic_material", "effects/achieved");
	

end
concommand.Add("bob_Elasticmat5", ElasticMaterials)

function ElasticMaterials()

	RunConsoleCommand("Elastic_material", "effects/balloon001");
	

end
concommand.Add("bob_Elasticmat6", ElasticMaterials)

function ElasticMaterials()

	RunConsoleCommand("Elastic_material", "effects/disguise_icon");
	

end
concommand.Add("bob_Elasticmat7", ElasticMaterials)


function ElasticMaterials()

	RunConsoleCommand("Elastic_material", "effects/duel_blue");
	

end
concommand.Add("bob_Elasticmat8", ElasticMaterials)

function ElasticMaterials()

	RunConsoleCommand("Elastic_material", "effects/duel_burst");
	

end
concommand.Add("bob_Elasticmat9", ElasticMaterials)

function ElasticMaterials()

	RunConsoleCommand("Elastic_material", "effects/duel_red");
	

end
concommand.Add("bob_Elasticmat10", ElasticMaterials)

function ElasticMaterials()

	RunConsoleCommand("Elastic_material", "effects/ghost");
	

end
concommand.Add("bob_Elasticmat11", ElasticMaterials)

function ElasticMaterials()

	RunConsoleCommand("Elastic_material", "effects/circle");
	

end
concommand.Add("bob_Elasticmat12", ElasticMaterials)

function ElasticMaterials()

	RunConsoleCommand("Elastic_material", "effects/circle1");
	

end
concommand.Add("bob_Elasticmat13", ElasticMaterials)

function ElasticMaterials()

	RunConsoleCommand("Elastic_material", "effects/crit");
	

end
concommand.Add("bob_Elasticmat14", ElasticMaterials)

function ElasticMaterials()

	RunConsoleCommand("Elastic_material", "effects/god_ray");
	

end
concommand.Add("bob_Elasticmat15", ElasticMaterials)

function ElasticMaterials()

	RunConsoleCommand("Elastic_material", "effects/healsign");
	

end
concommand.Add("bob_Elasticmat16", ElasticMaterials)




function ElasticMaterials()

	RunConsoleCommand("Elastic_material", "effects/highfive_border");
	

end
concommand.Add("bob_Elasticmat17", ElasticMaterials)

function ElasticMaterials()

	RunConsoleCommand("Elastic_material", "effects/hit");
	

end
concommand.Add("bob_Elasticmat18", ElasticMaterials)

function ElasticMaterials()

	RunConsoleCommand("Elastic_material", "effects/hitheal");
	

end
concommand.Add("bob_Elasticmat19", ElasticMaterials)


function ElasticMaterials()

	RunConsoleCommand("Elastic_material", "effects/mini_casing");
	

end
concommand.Add("bob_Elasticmat20", ElasticMaterials)




function ElasticMaterials()

	RunConsoleCommand("Elastic_material", "effects/miss");
	

end
concommand.Add("bob_Elasticmat21", ElasticMaterials)


function ElasticMaterials()

	RunConsoleCommand("Elastic_material", "effects/moon");
	

end
concommand.Add("Elastic_Elasticmat22", Elastic)


function ElasticMaterials()

	RunConsoleCommand("Elastic_material", "effects/negativehealsign");
	

end
concommand.Add("bob_Elasticmat23", ElasticMaterials)

function ElasticMaterials()

	RunConsoleCommand("Elastic_material", "effects/particle_highfive");
	

end
concommand.Add("bob_Elasticmat24", ElasticMaterials)



function ElasticMaterials()

	RunConsoleCommand("Elastic_material", "effects/planet01");
	

end
concommand.Add("bob_Elasticmat25", ElasticMaterials)













/////////////////////
// **Derma menu** //
///////////////////

/// Derma ///

local function ShowFrame()

Frame = vgui.Create("DFrame")
Frame:SetSize( 761 , 400 )
Frame:SetPos( ScrW() / 2 - Frame:GetWide() / 2 , ScrH() / 2 - Frame:GetTall() / 2  )
Frame:SetTitle("Rope & Elastic Menu")
Frame:SetVisible( true )
Frame:ShowCloseButton( true )
Frame.Paint = function()
	draw.RoundedBox( 8, 0, 0, Frame:GetWide(), Frame:GetTall(), Color( 0, 0, 0, 190 ) )
end
Frame:MakePopup()

local BSheet = vgui.Create("DPropertySheet" , Frame)
BSheet:SetSize( 751 , 365 )
BSheet:SetPos( 5 , 25 )
BSheet.Paint = function()
	draw.RoundedBox( 8, 0, 0, BSheet:GetWide(), BSheet:GetTall(), Color( 0, 0, 0, 190 ) )
end

local Tab = vgui.Create("DLabel")
Tab:SetParent( BSheet )
Tab:SetPos( 0 , 10 )
Tab:SetText("")

local Tab2 = vgui.Create("DLabel")
Tab2:SetParent( BSheet )
Tab2:SetPos( 0 , 10 )
Tab2:SetText("")



// Options



local RopeLabel = vgui.Create("DLabel")
RopeLabel:SetParent( Tab )
RopeLabel:SetPos( 13 , 10 )
RopeLabel:SetText("Ropes")
RopeLabel:SetTextColor( Color(255 , 255 , 255 , 255 ) )
RopeLabel:SizeToContents()

local ESPLabel2 = vgui.Create("DLabel")
ESPLabel2:SetParent( Tab )
ESPLabel2:SetPos( 113 , 10 )
ESPLabel2:SetText("test")
ESPLabel2:SetTextColor( Color(255 , 255 , 255 , 255 ) )
ESPLabel2:SizeToContents()

local ESPLabel3 = vgui.Create("DLabel")
ESPLabel3:SetParent( Tab )
ESPLabel3:SetPos( 206 , 10 )
ESPLabel3:SetText("test")
ESPLabel3:SetTextColor( Color(255 , 255 , 255 , 255 ) )
ESPLabel3:SizeToContents()

local ESPLabel4 = vgui.Create("DLabel")
ESPLabel4:SetParent( Tab )
ESPLabel4:SetPos( 13 , 130  )
ESPLabel4:SetText("")
ESPLabel4:SetTextColor( Color(255 , 255 , 255 , 255 ) )
ESPLabel4:SizeToContents()

local ESPLabel5 = vgui.Create("DLabel")
ESPLabel5:SetParent( Tab )
ESPLabel5:SetPos( 118.5 , 235 )
ESPLabel5:SetText("")
ESPLabel5:SetTextColor( Color(255 , 255 , 255 , 255 ) )
ESPLabel5:SizeToContents()

local Rope = vgui.Create( "DButton", window )
	Rope:SetSize( 100, 30 )
	Rope:SetPos( 10, 30 )
	Rope:SetParent( Tab )
	Rope:SetText( "HighFiveRed" )
	Rope.DoClick = function( button )
		RunConsoleCommand("bob_ropemat1")
		end
		
		local Rope = vgui.Create( "DButton", window )
	Rope:SetSize( 100, 30 )
	Rope:SetPos( 113, 30 )
	Rope:SetParent( Tab )
	Rope:SetText( "Cloud" )
	Rope.DoClick = function( button )
		RunConsoleCommand("bob_ropemat2")
		end

	local Rope = vgui.Create( "DButton", window )
	Rope:SetSize( 100, 30 )
	Rope:SetPos( 216, 30 )
	Rope:SetParent( Tab )
	Rope:SetText( "HighFiveBlue" )
	Rope.DoClick = function( button )
		RunConsoleCommand("bob_ropemat3")
		end
		
			local Rope = vgui.Create( "DButton", window )
	Rope:SetSize( 100, 30 )
	Rope:SetPos( 319, 30 )
	Rope:SetParent( Tab )
	Rope:SetText( "HighFive" )
	Rope.DoClick = function( button )
		RunConsoleCommand("bob_ropemat4")
		end

				local Rope = vgui.Create( "DButton", window )
	Rope:SetSize( 100, 30 )
	Rope:SetPos( 422, 30 )
	Rope:SetParent( Tab )
	Rope:SetText( "Achieved" )
	Rope.DoClick = function( button )
		RunConsoleCommand("bob_ropemat5")
		end
		
				local Rope = vgui.Create( "DButton", window )
	Rope:SetSize( 100, 30 )
	Rope:SetPos( 525, 30 )
	Rope:SetParent( Tab )
	Rope:SetText( "Balloon" )
	Rope.DoClick = function( button )
		RunConsoleCommand("bob_ropemat6")
		end
		
				local Rope = vgui.Create( "DButton", window )
	Rope:SetSize( 100, 30 )
	Rope:SetPos( 628, 30 )
	Rope:SetParent( Tab )
	Rope:SetText( "DisguiseIcon" )
	Rope.DoClick = function( button )
		RunConsoleCommand("bob_ropemat7")
		end
		
					local Rope = vgui.Create( "DButton", window )
	Rope:SetSize( 100, 30 )
	Rope:SetPos( 10, 65 )
	Rope:SetParent( Tab )
	Rope:SetText( "DuelBlue" )
	Rope.DoClick = function( button )
		RunConsoleCommand("bob_ropemat8")
		end
					local Rope = vgui.Create( "DButton", window )
	Rope:SetSize( 100, 30 )
	Rope:SetPos( 113, 65 )
	Rope:SetParent( Tab )
	Rope:SetText( "DuelBurst" )
	Rope.DoClick = function( button )
		RunConsoleCommand("bob_ropemat9")
		end
		
							local Rope = vgui.Create( "DButton", window )
	Rope:SetSize( 100, 30 )
	Rope:SetPos( 216, 65 )
	Rope:SetParent( Tab )
	Rope:SetText( "DuelRed" )
	Rope.DoClick = function( button )
		RunConsoleCommand("bob_ropemat10")
		end
		
							local Rope = vgui.Create( "DButton", window )
	Rope:SetSize( 100, 30 )
	Rope:SetPos( 319, 65 )
	Rope:SetParent( Tab )
	Rope:SetText( "Ghost" )
	Rope.DoClick = function( button )
		RunConsoleCommand("bob_ropemat11")
		end
		
							local Rope = vgui.Create( "DButton", window )
	Rope:SetSize( 100, 30 )
	Rope:SetPos( 422, 65 )
	Rope:SetParent( Tab )
	Rope:SetText( "Circle" )
	Rope.DoClick = function( button )
		RunConsoleCommand("bob_ropemat12")
		end
		
							local Rope = vgui.Create( "DButton", window )
	Rope:SetSize( 100, 30 )
	Rope:SetPos( 525, 65 )
	Rope:SetParent( Tab )
	Rope:SetText( "Circle1" )
	Rope.DoClick = function( button )
		RunConsoleCommand("bob_ropemat13")
		end
		
							local Rope = vgui.Create( "DButton", window )
	Rope:SetSize( 100, 30 )
	Rope:SetPos( 628, 65 )
	Rope:SetParent( Tab )
	Rope:SetText( "Crit" )
	Rope.DoClick = function( button )
		RunConsoleCommand("bob_ropemat14")
		end

		
								local Rope = vgui.Create( "DButton", window )
		Rope:SetSize( 100, 30 )
	Rope:SetPos( 10, 100 )
	Rope:SetParent( Tab )
	Rope:SetText( "GodRay" )
	Rope.DoClick = function( button )
		RunConsoleCommand("bob_ropemat15")
		end

		local Rope = vgui.Create( "DButton", window )
		Rope:SetSize( 100, 30 )
	Rope:SetPos( 113, 100 )
	Rope:SetParent( Tab )
	Rope:SetText( "HealSign" )
	Rope.DoClick = function( button )
		RunConsoleCommand("bob_ropemat16")
		end
		
		local Rope = vgui.Create( "DButton", window )
		Rope:SetSize( 100, 30 )
	Rope:SetPos( 216, 100 )
	Rope:SetParent( Tab )
	Rope:SetText( "HighFiveBorder" )
	Rope.DoClick = function( button )
		RunConsoleCommand("bob_ropemat17")
		end
		
		local Rope = vgui.Create( "DButton", window )
		Rope:SetSize( 100, 30 )
	Rope:SetPos( 319, 100 )
	Rope:SetParent( Tab )
	Rope:SetText( "Hit" )
	Rope.DoClick = function( button )
		RunConsoleCommand("bob_ropemat18")
		end
		
		local Rope = vgui.Create( "DButton", window )
		Rope:SetSize( 100, 30 )
	Rope:SetPos( 422, 100 )
	Rope:SetParent( Tab )
	Rope:SetText( "HitHeal" )
	Rope.DoClick = function( button )
		RunConsoleCommand("bob_ropemat19")
		end
		
		local Rope = vgui.Create( "DButton", window )
		Rope:SetSize( 100, 30 )
	Rope:SetPos( 525, 100 )
	Rope:SetParent( Tab )
	Rope:SetText( "MiniCasing" )
	Rope.DoClick = function( button )
		RunConsoleCommand("bob_ropemat20")
		end
		
		local Rope = vgui.Create( "DButton", window )
		Rope:SetSize( 100, 30 )
	Rope:SetPos( 628, 100 )
	Rope:SetParent( Tab )
	Rope:SetText( "Miss" )
	Rope.DoClick = function( button )
		RunConsoleCommand("bob_ropemat21")
		end
		
		local Rope = vgui.Create( "DButton", window )
		Rope:SetSize( 100, 30 )
	Rope:SetPos( 10, 135 )
	Rope:SetParent( Tab )
	Rope:SetText( "Moon" )
	Rope.DoClick = function( button )
		RunConsoleCommand("bob_ropemat22")
		end
		
			local Rope = vgui.Create( "DButton", window )
		Rope:SetSize( 100, 30 )
	Rope:SetPos( 113, 135 )
	Rope:SetParent( Tab )
	Rope:SetText( "NegativeHealSign" )
	Rope.DoClick = function( button )
		RunConsoleCommand("bob_ropemat23")
		end
		
			local Rope = vgui.Create( "DButton", window )
		Rope:SetSize( 100, 30 )
	Rope:SetPos( 216, 135 )
	Rope:SetParent( Tab )
	Rope:SetText( "ParticleHighFive" )
	Rope.DoClick = function( button )
		RunConsoleCommand("bob_ropemat24")
		end

			local Rope = vgui.Create( "DButton", window )
		Rope:SetSize( 100, 30 )
	Rope:SetPos( 319, 135 )
	Rope:SetParent( Tab )
	Rope:SetText( "Planet01" )
	Rope.DoClick = function( button )
		RunConsoleCommand("bob_ropemat25")
		end

		











local RopeLabel = vgui.Create("DLabel")
RopeLabel:SetParent( Tab )
RopeLabel:SetPos( 13 , 10 )
RopeLabel:SetText("Ropes")
RopeLabel:SetTextColor( Color(255 , 255 , 255 , 255 ) )
RopeLabel:SizeToContents()

local ESPLabel2 = vgui.Create("DLabel")
ESPLabel2:SetParent( Tab )
ESPLabel2:SetPos( 113 , 10 )
ESPLabel2:SetText("test")
ESPLabel2:SetTextColor( Color(255 , 255 , 255 , 255 ) )
ESPLabel2:SizeToContents()

local ESPLabel3 = vgui.Create("DLabel")
ESPLabel3:SetParent( Tab )
ESPLabel3:SetPos( 206 , 10 )
ESPLabel3:SetText("test")
ESPLabel3:SetTextColor( Color(255 , 255 , 255 , 255 ) )
ESPLabel3:SizeToContents()

local ESPLabel4 = vgui.Create("DLabel")
ESPLabel4:SetParent( Tab )
ESPLabel4:SetPos( 13 , 130  )
ESPLabel4:SetText("")
ESPLabel4:SetTextColor( Color(255 , 255 , 255 , 255 ) )
ESPLabel4:SizeToContents()

local ESPLabel5 = vgui.Create("DLabel")
ESPLabel5:SetParent( Tab )
ESPLabel5:SetPos( 118.5 , 235 )
ESPLabel5:SetText("")
ESPLabel5:SetTextColor( Color(255 , 255 , 255 , 255 ) )
ESPLabel5:SizeToContents()

local Rope = vgui.Create( "DButton", window )
	Rope:SetSize( 100, 30 )
	Rope:SetPos( 10, 30 )
	Rope:SetParent( Tab2 )
	Rope:SetText( "HighFiveRed" )
	Rope.DoClick = function( button )
		RunConsoleCommand("bob_Elasticmat1")
		end
		
		local Rope = vgui.Create( "DButton", window )
	Rope:SetSize( 100, 30 )
	Rope:SetPos( 113, 30 )
	Rope:SetParent( Tab2 )
	Rope:SetText( "Cloud" )
	Rope.DoClick = function( button )
		RunConsoleCommand("bob_Elasticmat2")
		end

	local Rope = vgui.Create( "DButton", window )
	Rope:SetSize( 100, 30 )
	Rope:SetPos( 216, 30 )
	Rope:SetParent( Tab2 )
	Rope:SetText( "HighFiveBlue" )
	Rope.DoClick = function( button )
		RunConsoleCommand("bob_Elasticmat3")
		end
		
			local Rope = vgui.Create( "DButton", window )
	Rope:SetSize( 100, 30 )
	Rope:SetPos( 319, 30 )
	Rope:SetParent( Tab2 )
	Rope:SetText( "HighFive" )
	Rope.DoClick = function( button )
		RunConsoleCommand("bob_Elasticmat4")
		end

				local Rope = vgui.Create( "DButton", window )
	Rope:SetSize( 100, 30 )
	Rope:SetPos( 422, 30 )
	Rope:SetParent( Tab2 )
	Rope:SetText( "Achieved" )
	Rope.DoClick = function( button )
		RunConsoleCommand("bob_Elasticmat5")
		end
		
				local Rope = vgui.Create( "DButton", window )
	Rope:SetSize( 100, 30 )
	Rope:SetPos( 525, 30 )
	Rope:SetParent( Tab2 )
	Rope:SetText( "Balloon" )
	Rope.DoClick = function( button )
		RunConsoleCommand("bob_Elasticmat6")
		end
		
				local Rope = vgui.Create( "DButton", window )
	Rope:SetSize( 100, 30 )
	Rope:SetPos( 628, 30 )
	Rope:SetParent( Tab2 )
	Rope:SetText( "DisguiseIcon" )
	Rope.DoClick = function( button )
		RunConsoleCommand("bob_Elasticmat7")
		end
		
					local Rope = vgui.Create( "DButton", window )
	Rope:SetSize( 100, 30 )
	Rope:SetPos( 10, 65 )
	Rope:SetParent( Tab2 )
	Rope:SetText( "DuelBlue" )
	Rope.DoClick = function( button )
		RunConsoleCommand("bob_Elasticmat8")
		end
					local Rope = vgui.Create( "DButton", window )
	Rope:SetSize( 100, 30 )
	Rope:SetPos( 113, 65 )
	Rope:SetParent( Tab2 )
	Rope:SetText( "DuelBurst" )
	Rope.DoClick = function( button )
		RunConsoleCommand("bob_Elasticmat9")
		end
		
							local Rope = vgui.Create( "DButton", window )
	Rope:SetSize( 100, 30 )
	Rope:SetPos( 216, 65 )
	Rope:SetParent( Tab2 )
	Rope:SetText( "DuelRed" )
	Rope.DoClick = function( button )
		RunConsoleCommand("bob_Elasticmat10")
		end
		
							local Rope = vgui.Create( "DButton", window )
	Rope:SetSize( 100, 30 )
	Rope:SetPos( 319, 65 )
	Rope:SetParent( Tab2 )
	Rope:SetText( "Ghost" )
	Rope.DoClick = function( button )
		RunConsoleCommand("bob_Elasticmat11")
		end
		
							local Rope = vgui.Create( "DButton", window )
	Rope:SetSize( 100, 30 )
	Rope:SetPos( 422, 65 )
	Rope:SetParent( Tab2 )
	Rope:SetText( "Circle" )
	Rope.DoClick = function( button )
		RunConsoleCommand("bob_Elasticmat12")
		end
		
							local Rope = vgui.Create( "DButton", window )
	Rope:SetSize( 100, 30 )
	Rope:SetPos( 525, 65 )
	Rope:SetParent( Tab2 )
	Rope:SetText( "Circle1" )
	Rope.DoClick = function( button )
		RunConsoleCommand("bob_Elasticmat13")
		end
		
							local Rope = vgui.Create( "DButton", window )
	Rope:SetSize( 100, 30 )
	Rope:SetPos( 628, 65 )
	Rope:SetParent( Tab2 )
	Rope:SetText( "Crit" )
	Rope.DoClick = function( button )
		RunConsoleCommand("bob_Elasticmat14")
		end

		
								local Rope = vgui.Create( "DButton", window )
		Rope:SetSize( 100, 30 )
	Rope:SetPos( 10, 100 )
	Rope:SetParent( Tab2 )
	Rope:SetText( "GodRay" )
	Rope.DoClick = function( button )
		RunConsoleCommand("bob_Elasticmat15")
		end

		local Rope = vgui.Create( "DButton", window )
		Rope:SetSize( 100, 30 )
	Rope:SetPos( 113, 100 )
	Rope:SetParent( Tab2 )
	Rope:SetText( "HealSign" )
	Rope.DoClick = function( button )
		RunConsoleCommand("bob_Elasticmat16")
		end
		
		local Rope = vgui.Create( "DButton", window )
		Rope:SetSize( 100, 30 )
	Rope:SetPos( 216, 100 )
	Rope:SetParent( Tab2 )
	Rope:SetText( "HighFiveBorder" )
	Rope.DoClick = function( button )
		RunConsoleCommand("bob_Elasticmat17")
		end
		
		local Rope = vgui.Create( "DButton", window )
		Rope:SetSize( 100, 30 )
	Rope:SetPos( 319, 100 )
	Rope:SetParent( Tab2 )
	Rope:SetText( "Hit" )
	Rope.DoClick = function( button )
		RunConsoleCommand("bob_Elasticmat18")
		end
		
		local Rope = vgui.Create( "DButton", window )
		Rope:SetSize( 100, 30 )
	Rope:SetPos( 422, 100 )
	Rope:SetParent( Tab2 )
	Rope:SetText( "HitHeal" )
	Rope.DoClick = function( button )
		RunConsoleCommand("bob_Elasticmat19")
		end
		
		local Rope = vgui.Create( "DButton", window )
		Rope:SetSize( 100, 30 )
	Rope:SetPos( 525, 100 )
	Rope:SetParent( Tab2 )
	Rope:SetText( "MiniCasing" )
	Rope.DoClick = function( button )
		RunConsoleCommand("bob_Elasticmat20")
		end
		
		local Rope = vgui.Create( "DButton", window )
		Rope:SetSize( 100, 30 )
	Rope:SetPos( 628, 100 )
	Rope:SetParent( Tab2 )
	Rope:SetText( "Miss" )
	Rope.DoClick = function( button )
		RunConsoleCommand("bob_Elasticmat21")
		end
		
		local Rope = vgui.Create( "DButton", window )
		Rope:SetSize( 100, 30 )
	Rope:SetPos( 10, 135 )
	Rope:SetParent( Tab2 )
	Rope:SetText( "Moon" )
	Rope.DoClick = function( button )
		RunConsoleCommand("bob_Elasticmat22")
		end
		
			local Rope = vgui.Create( "DButton", window )
		Rope:SetSize( 100, 30 )
	Rope:SetPos( 113, 135 )
	Rope:SetParent( Tab2 )
	Rope:SetText( "NegativeHealSign" )
	Rope.DoClick = function( button )
		RunConsoleCommand("bob_Elasticmat23")
		end
		
			local Rope = vgui.Create( "DButton", window )
		Rope:SetSize( 100, 30 )
	Rope:SetPos( 216, 135 )
	Rope:SetParent( Tab2 )
	Rope:SetText( "ParticleHighFive" )
	Rope.DoClick = function( button )
		RunConsoleCommand("bob_Elasticmat24")
		end

			local Rope = vgui.Create( "DButton", window )
		Rope:SetSize( 100, 30 )
	Rope:SetPos( 319, 135 )
	Rope:SetParent( Tab2 )
	Rope:SetText( "Planet01" )
	Rope.DoClick = function( button )
		RunConsoleCommand("bob_Elasticmat25")
		end




BSheet:AddSheet( "Rope", Tab, "gui/silkicons/heart", false, false, "All your Ropes" )
BSheet:AddSheet( "Elastics", Tab2, "gui/silkicons/emoticon_smile", false, false, "All of your Elastics" )
end
concommand.Add("+BobRope_menu",ShowFrame)
concommand.Add("-BobRope_menu",function()
Frame:SetVisible( false )
end)

concommand.Add("BobRope_MENU_RELOAD",function()
ShowFrame()
end)

function test()

DFrame1 = vgui.Create('DFrame')
DFrame1:SetSize(370, 170)
DFrame1:SetPos(10, 10)
DFrame1:SetTitle('Colour Changer')
DFrame1:SetSizable(true)
DFrame1:SetDeleteOnClose(false)
DFrame1:MakePopup()
---------------------------------------------------------------------------------------------
DNumSlider6 = vgui.Create('DNumSlider')
DNumSlider6:SetSize(154, 40)
DNumSlider6:SetPos(210, 130)
DNumSlider6:SetText( "blue" )
DNumSlider6:SetParent(DFrame1)
DNumSlider6:SetMin( 1 ) 
DNumSlider6:SetMax( 255 ) 
DNumSlider6:SetDecimals( 0 )
DNumSlider6:SetConVar( "Bob_xrayplayers_blue" ) 
 
DNumSlider5 = vgui.Create('DNumSlider')
DNumSlider5:SetSize(154, 40)
DNumSlider5:SetPos(210, 90)
DNumSlider5:SetDecimals(0)
DNumSlider5:SetParent(DFrame1)
DNumSlider5:SetText( "green" )
DNumSlider5:SetMin( 1 ) 
DNumSlider5:SetMax( 255 ) 
DNumSlider5:SetDecimals( 0 )
DNumSlider5:SetConVar( "Bob_xrayplayers_green" ) 
 
DNumSlider4 = vgui.Create('DNumSlider')
DNumSlider4:SetSize(154, 40)
DNumSlider4:SetPos(210, 50)
DNumSlider4:SetDecimals(0)
DNumSlider4:SetParent(DFrame1)
DNumSlider4:SetText( "Red" )
DNumSlider4:SetMin( 1 ) 
DNumSlider4:SetMax( 255 ) 
DNumSlider4:SetDecimals( 0 )
DNumSlider4:SetConVar( "Bob_xrayplayers_red" ) 
 
 

 
end
concommand.Add("Bob_xrayplayercolour", test)


function test()

DFrame1 = vgui.Create('DFrame')
DFrame1:SetSize(370, 170)
DFrame1:SetPos(10, 10)
DFrame1:SetTitle('Colour Changer')
DFrame1:SetSizable(true)
DFrame1:SetDeleteOnClose(false)
DFrame1:MakePopup()
---------------------------------------------------------------------------------------------
DNumSlider6 = vgui.Create('DNumSlider')
DNumSlider6:SetSize(154, 40)
DNumSlider6:SetPos(210, 130)
DNumSlider6:SetText( "blue" )
DNumSlider6:SetParent(DFrame1)
DNumSlider6:SetMin( 1 ) 
DNumSlider6:SetMax( 255 ) 
DNumSlider6:SetDecimals( 0 )
DNumSlider6:SetConVar( "Bob_xrayprops_blue" ) 
 
DNumSlider5 = vgui.Create('DNumSlider')
DNumSlider5:SetSize(154, 40)
DNumSlider5:SetPos(210, 90)
DNumSlider5:SetDecimals(0)
DNumSlider5:SetParent(DFrame1)
DNumSlider5:SetText( "green" )
DNumSlider5:SetMin( 1 ) 
DNumSlider5:SetMax( 255 ) 
DNumSlider5:SetDecimals( 0 )
DNumSlider5:SetConVar( "Bob_xrayprops_green" ) 
 
DNumSlider4 = vgui.Create('DNumSlider')
DNumSlider4:SetSize(154, 40)
DNumSlider4:SetPos(210, 50)
DNumSlider4:SetDecimals(0)
DNumSlider4:SetParent(DFrame1)
DNumSlider4:SetText( "Red" )
DNumSlider4:SetMin( 1 ) 
DNumSlider4:SetMax( 255 ) 
DNumSlider4:SetDecimals( 0 )
DNumSlider4:SetConVar( "Bob_xrayprops_red" ) 
 
 

 
end
concommand.Add("Bob_xraypropcolour", test)

function test()

DFrame1 = vgui.Create('DFrame')
DFrame1:SetSize(370, 170)
DFrame1:SetPos(10, 10)
DFrame1:SetTitle('Colour Changer')
DFrame1:SetSizable(true)
DFrame1:SetDeleteOnClose(false)
DFrame1:MakePopup()
---------------------------------------------------------------------------------------------
DNumSlider6 = vgui.Create('DNumSlider')
DNumSlider6:SetSize(154, 40)
DNumSlider6:SetPos(210, 130)
DNumSlider6:SetText( "blue" )
DNumSlider6:SetParent(DFrame1)
DNumSlider6:SetMin( 1 ) 
DNumSlider6:SetMax( 255 ) 
DNumSlider6:SetDecimals( 0 )
DNumSlider6:SetConVar( "Bob_xraynpc_blue" ) 
 
DNumSlider5 = vgui.Create('DNumSlider')
DNumSlider5:SetSize(154, 40)
DNumSlider5:SetPos(210, 90)
DNumSlider5:SetDecimals(0)
DNumSlider5:SetParent(DFrame1)
DNumSlider5:SetText( "green" )
DNumSlider5:SetMin( 1 ) 
DNumSlider5:SetMax( 255 ) 
DNumSlider5:SetDecimals( 0 )
DNumSlider5:SetConVar( "Bob_xraynpc_green" ) 
 
DNumSlider4 = vgui.Create('DNumSlider')
DNumSlider4:SetSize(154, 40)
DNumSlider4:SetPos(210, 50)
DNumSlider4:SetDecimals(0)
DNumSlider4:SetParent(DFrame1)
DNumSlider4:SetText( "Red" )
DNumSlider4:SetMin( 1 ) 
DNumSlider4:SetMax( 255 ) 
DNumSlider4:SetDecimals( 0 )
DNumSlider4:SetConVar( "Bob_xraynpc_red" ) 
 
 

 
end
concommand.Add("Bob_xrayNPCcolour", test)



function test()

DFrame1 = vgui.Create('DFrame')
DFrame1:SetSize(370, 170)
DFrame1:SetPos(10, 10)
DFrame1:SetTitle('Colour Changer')
DFrame1:SetSizable(true)
DFrame1:SetDeleteOnClose(false)
DFrame1:MakePopup()
---------------------------------------------------------------------------------------------
DNumSlider6 = vgui.Create('DNumSlider')
DNumSlider6:SetSize(154, 40)
DNumSlider6:SetPos(210, 130)
DNumSlider6:SetText( "blue" )
DNumSlider6:SetParent(DFrame1)
DNumSlider6:SetMin( 1 ) 
DNumSlider6:SetMax( 255 ) 
DNumSlider6:SetDecimals( 0 )
DNumSlider6:SetConVar( "Bob_xrayents_blue" ) 
 
DNumSlider5 = vgui.Create('DNumSlider')
DNumSlider5:SetSize(154, 40)
DNumSlider5:SetPos(210, 90)
DNumSlider5:SetDecimals(0)
DNumSlider5:SetParent(DFrame1)
DNumSlider5:SetText( "green" )
DNumSlider5:SetMin( 1 ) 
DNumSlider5:SetMax( 255 ) 
DNumSlider5:SetDecimals( 0 )
DNumSlider5:SetConVar( "Bob_xrayents_green" ) 
 
DNumSlider4 = vgui.Create('DNumSlider')
DNumSlider4:SetSize(154, 40)
DNumSlider4:SetPos(210, 50)
DNumSlider4:SetDecimals(0)
DNumSlider4:SetParent(DFrame1)
DNumSlider4:SetText( "Red" )
DNumSlider4:SetMin( 1 ) 
DNumSlider4:SetMax( 255 ) 
DNumSlider4:SetDecimals( 0 )
DNumSlider4:SetConVar( "Bob_xrayents_red" ) 
 
 

 
end
concommand.Add("Bob_xrayentcolour", test)

function test()

DFrame1 = vgui.Create('DFrame')
DFrame1:SetSize(370, 170)
DFrame1:SetPos(10, 10)
DFrame1:SetTitle('Colour Changer')
DFrame1:SetSizable(true)
DFrame1:SetDeleteOnClose(false)
DFrame1:MakePopup()
---------------------------------------------------------------------------------------------
DNumSlider6 = vgui.Create('DNumSlider')
DNumSlider6:SetSize(154, 40)
DNumSlider6:SetPos(210, 130)
DNumSlider6:SetText( "blue" )
DNumSlider6:SetParent(DFrame1)
DNumSlider6:SetMin( 1 ) 
DNumSlider6:SetMax( 255 ) 
DNumSlider6:SetDecimals( 0 )
DNumSlider6:SetConVar( "Bob_xrayweapon_blue" ) 
 
DNumSlider5 = vgui.Create('DNumSlider')
DNumSlider5:SetSize(154, 40)
DNumSlider5:SetPos(210, 90)
DNumSlider5:SetDecimals(0)
DNumSlider5:SetParent(DFrame1)
DNumSlider5:SetText( "green" )
DNumSlider5:SetMin( 1 ) 
DNumSlider5:SetMax( 255 ) 
DNumSlider5:SetDecimals( 0 )
DNumSlider5:SetConVar( "Bob_xrayweapon_green" ) 
 
DNumSlider4 = vgui.Create('DNumSlider')
DNumSlider4:SetSize(154, 40)
DNumSlider4:SetPos(210, 50)
DNumSlider4:SetDecimals(0)
DNumSlider4:SetParent(DFrame1)
DNumSlider4:SetText( "Red" )
DNumSlider4:SetMin( 1 ) 
DNumSlider4:SetMax( 255 ) 
DNumSlider4:SetDecimals( 0 )
DNumSlider4:SetConVar( "Bob_xrayweapon_red" ) 

end
concommand.Add("Bob_weaponcolour", test)
 
 
 function test()

DFrame1 = vgui.Create('DFrame')
DFrame1:SetSize(370, 170)
DFrame1:SetPos(10, 10)
DFrame1:SetTitle('Colour Changer')
DFrame1:SetSizable(true)
DFrame1:SetDeleteOnClose(false)
DFrame1:MakePopup()
---------------------------------------------------------------------------------------------
DNumSlider6 = vgui.Create('DNumSlider')
DNumSlider6:SetSize(154, 40)
DNumSlider6:SetPos(210, 130)
DNumSlider6:SetText( "blue" )
DNumSlider6:SetParent(DFrame1)
DNumSlider6:SetMin( 1 ) 
DNumSlider6:SetMax( 255 ) 
DNumSlider6:SetDecimals( 0 )
DNumSlider6:SetConVar( "Bob_admin_blue" ) 
 
DNumSlider5 = vgui.Create('DNumSlider')
DNumSlider5:SetSize(154, 40)
DNumSlider5:SetPos(210, 90)
DNumSlider5:SetDecimals(0)
DNumSlider5:SetParent(DFrame1)
DNumSlider5:SetText( "green" )
DNumSlider5:SetMin( 1 ) 
DNumSlider5:SetMax( 255 ) 
DNumSlider5:SetDecimals( 0 )
DNumSlider5:SetConVar( "Bob_admin_green" ) 
 
DNumSlider4 = vgui.Create('DNumSlider')
DNumSlider4:SetSize(154, 40)
DNumSlider4:SetPos(210, 50)
DNumSlider4:SetDecimals(0)
DNumSlider4:SetParent(DFrame1)
DNumSlider4:SetText( "Red" )
DNumSlider4:SetMin( 1 ) 
DNumSlider4:SetMax( 255 ) 
DNumSlider4:SetDecimals( 0 )
DNumSlider4:SetConVar( "Bob_admin_red" ) 
 
 

 
end
concommand.Add("Bob_admincolour", test)
-----------------------------------------------------

function test()

DFrame1 = vgui.Create('DFrame')
DFrame1:SetSize(370, 170)
DFrame1:SetPos(10, 10)
DFrame1:SetTitle('Colour Changer')
DFrame1:SetSizable(true)
DFrame1:SetDeleteOnClose(false)
DFrame1:MakePopup()
---------------------------------------------------------------------------------------------
DNumSlider6 = vgui.Create('DNumSlider')
DNumSlider6:SetSize(154, 40)
DNumSlider6:SetPos(210, 130)
DNumSlider6:SetText( "blue" )
DNumSlider6:SetParent(DFrame1)
DNumSlider6:SetMin( 1 ) 
DNumSlider6:SetMax( 255 ) 
DNumSlider6:SetDecimals( 0 )
DNumSlider6:SetConVar( "Bob_superadmin_blue" ) 
 
DNumSlider5 = vgui.Create('DNumSlider')
DNumSlider5:SetSize(154, 40)
DNumSlider5:SetPos(210, 90)
DNumSlider5:SetDecimals(0)
DNumSlider5:SetParent(DFrame1)
DNumSlider5:SetText( "green" )
DNumSlider5:SetMin( 1 ) 
DNumSlider5:SetMax( 255 ) 
DNumSlider5:SetDecimals( 0 )
DNumSlider5:SetConVar( "Bob_superadmin_green" ) 
 
DNumSlider4 = vgui.Create('DNumSlider')
DNumSlider4:SetSize(154, 40)
DNumSlider4:SetPos(210, 50)
DNumSlider4:SetDecimals(0)
DNumSlider4:SetParent(DFrame1)
DNumSlider4:SetText( "Red" )
DNumSlider4:SetMin( 1 ) 
DNumSlider4:SetMax( 255 ) 
DNumSlider4:SetDecimals( 0 )
DNumSlider4:SetConVar( "Bob_superadmin_red" ) 
 
 

 
end
concommand.Add("Bob_superadmincolour", test)
 


 

 



 



//Xrayz

local rxp   =    CreateClientConVar( "Bob_xrayplayers_red", 0, true, false)
local gxp   =    CreateClientConVar( "Bob_xrayplayers_green", 0, true, false)
local bxp    =    CreateClientConVar( "Bob_xrayplayers_blue", 255, true, false)

local rxa   =    CreateClientConVar( "Bob_xrayprops_red", 0, true, false)
local gxa   =    CreateClientConVar( "Bob_xrayprops_green", 255, true, false)
local bxa    =    CreateClientConVar( "Bob_xrayprops_blue", 0, true, false)

local rxn   =    CreateClientConVar( "Bob_xraynpc_red", 255, true, false)
local gxn   =    CreateClientConVar( "Bob_xraynpc_green", 100, true, false)
local bxn    =    CreateClientConVar( "Bob_xraynpc_blue", 0, true, false)

local rxe   =    CreateClientConVar( "Bob_xrayents_red", 255, true, false)
local gxe   =    CreateClientConVar( "Bob_xrayents_green", 0, true, false)
local bxe    =    CreateClientConVar( "Bob_xrayents_blue", 255, true, false)

local rxw   =    CreateClientConVar( "Bob_xrayweapon_red", 255, true, false)
local gxw   =    CreateClientConVar( "Bob_xrayweapon_green", 0, true, false)
local bxw    =    CreateClientConVar( "Bob_xrayweapon_blue", 0, true, false)

local rxh   =    CreateClientConVar( "Bob_superadmin_red", 0, true, false)
local gxh   =    CreateClientConVar( "Bob_superadmin_green", 0, true, false)
local bxh    =    CreateClientConVar( "Bob_superadmin_blue", 255, true, false)

local rxk   =    CreateClientConVar( "Bob_admin_red", 0, true, false)
local gxk   =    CreateClientConVar( "Bob_admin_green", 0, true, false)
local bxk    =    CreateClientConVar( "Bob_admin_blue", 255, true, false)

local xray1 = false
local BobXRayMat = CreateClientConVar( "Bob_xraymat", "xraysolid", true, false )
local BobXRayMats = BobXRayMat:GetString()





 
   


//make target go invis
function makeinvis()
   local trace = LocalPlayer():GetEyeTrace()
   trace.v:SetColor(255, 255, 255, 100)
   end
   concommand.Add("Bob_setinvisible", makeinvis)

   //Makes target go visable again   
function makevis()
local trace = LocalPlayer():GetEyeTrace()
trace.v:SetColor(255, 255, 255, 255)
end
concommand.Add("Bob_setvisible", makevis)

timer.Create( "my_timer", 0.000000001, 1, function()
   RunConsoleCommand("Bob_xray")
end)


//xray wooo
function xrayz1()
	Bobxray1 = true
hook.Add("HUDPaint", "xray1", function()
	for k, v in pairs(ents.GetAll()) do
		if ( IsValid(v) ) and (v:IsPlayer()) and not (v:IsAdmin()) then
			v:SetMaterial(BobXRayMats)
		    v:SetColor(Color(rxp:GetInt(), gxp:GetInt(), bxp:GetInt(), 100))
			elseif (IsValid(v) ) and (v:IsPlayer()) and (v:IsSuperAdmin()) then		
		    v:SetMaterial(BobXRayMats)
		    v:SetColor(Color(rxh:GetInt(), gxh:GetInt(), bxh:GetInt(), 100))
			elseif (IsValid(v) ) and (v:IsPlayer()) and not (v:IsSuperAdmin()) and (v:IsAdmin()) then
			v:SetMaterial(BobXRayMats)
			v:SetColor(Color(rxk:GetInt(), gxk:GetInt(), bxk:GetInt(), 254))
		    elseif	(IsValid(v) ) and (v:IsNPC())	then
		    v:SetMaterial(BobXRayMats)
			v:SetColor(Color(rxn:GetInt(), gxn:GetInt(), bxn:GetInt(), 200))
			elseif (IsValid(v) ) and (v:GetClass() == "money_printer" or v:GetClass() == "drug_lab" or v:GetClass() == "gunlab" or v:GetClass() == "microwave"
			or v:GetClass() == "spawned_shipment" or v:IsVehicle() ) then
			v:SetMaterial(BobXRayMats)
			v:SetColor(Color(rxe:GetInt(), gxe:GetInt(), bxe:GetInt(), 150))
			elseif (IsValid(v) ) and (v:IsWeapon() or v:GetClass() == "spawned_weapon") then
			v:SetMaterial(BobXRayMats)
			v:SetColor(Color(rxw:GetInt(), gxw:GetInt(), bxw:GetInt(), 254))
			elseif (IsValid(v) ) then
			v:SetMaterial( BobXRayMats)
			v:SetColor(Color(rxa:GetInt(), gxa:GetInt(), bxa:GetInt(), 255))
		else
			end
		end

		
		end)
	end

xrayz1()

concommand.Add("Bob_xray", function()

		if Bobxray1 then
			hook.Remove("HUDPaint", "xray1")
			
	for _, v in pairs(ents.GetAll()) do
		if IsValid (v)  then
			v:SetMaterial("")
			v:SetColor(Color(255, 255, 255, 255))
	end
end

	LocalPlayer():ChatPrint("OFF")
		Bobxray1 = false

			elseif !Bobxray then
				xrayz1()
				LocalPlayer():ChatPrint("ON")
		Bobxray1 = true
	end
	end)


	hook.Add("PreDrawSkyBox", "removeSkybox", function()
			render.Clear(50, 50, 50, 255)

			return true
		end)
		
 ----------------------------fromfalcosxray------------------------------------------
 
 local PropPathOn = CreateClientConVar( "bob_misc_proppath", "1", true, false )
local SkyboxPosOn = CreateClientConVar( "bob_misc_headlaser", "0", true, false )
local SpeedOn = CreateClientConVar( "bob_misc_speedometer", "0", true, false )

local function PaintThings()
	for k,v in pairs( ents.GetAll() ) do
		if IsValid( v ) and v:GetVelocity():Length() > 60 and v:GetClass() == "prop_physics" and PropPathOn:GetBool() then
			local PropCenter = v:OBBCenter()
			local propTrace = {}
			propTrace.start = v:LocalToWorld( v:OBBCenter() )
			propTrace.endpos = v:LocalToWorld( v:OBBCenter() ) + v:GetVelocity() * Vector( 10000, 10000, 10000 )
			propTrace.filter = v
			local DoPropLine = util.TraceLine( propTrace )
			cam.Start3D( EyePos() , EyeAngles() )
				render.SetMaterial( Material( "cable/redlaser" ) )
				render.DrawBeam( DoPropLine.StartPos, DoPropLine.HitPos, 50, 0, 0, Color( 255,255,255,255 ) )
			cam.End3D()
		end
		if IsValid( v ) and v:GetClass() == "prop_physics" then
			local propradius = ents.FindInSphere( v:LocalToWorld( v:OBBCenter() ), 60 )
			for a,b in pairs( propradius ) do
				if b:IsPlayer() and b:Alive() then
					--draw.DrawText( "Prop near " .. b:Nick(), "Trebuchet24", ScrW()/2, 75, Color( 255, 255, 255, 255 ), 1 )
				end
			end
		end
	end
	for k,v in pairs( player.GetAll() ) do
		if IsValid( v ) and v:IsPlayer() and v:Alive() and SkyboxPosOn:GetBool() and v != LocalPlayer() then
			local skytrace = {}
			skytrace.start = v:GetShootPos()
			skytrace.endpos = v:GetShootPos() + Vector( 0, 0, 10000 )
			skytrace.filter = v
			local doskytrace = util.TraceLine( skytrace )
			cam.Start3D( EyePos() , EyeAngles() )
				render.SetMaterial( Material( "cable/redlaser" ) )
				render.DrawBeam( v:GetShootPos(), doskytrace.HitPos, 25, 0, 0, Color( 255,255,255,255 ) )
			cam.End3D()
		end
	end
	if SpeedOn:GetBool() then
		local speedy = LocalPlayer():GetVelocity():Length()
		draw.SimpleTextOutlined( "Speed: " .. tostring( math.Round( speedy * 3600 / 63360 * 0.75 ) ) .. "mph", "Trebuchet24", ScrW()/25, 800, Color( 0, 0, 0, 255 ), 1, 1, 1, Color( 255, 255, 255, 150 ) )
	end
end
hook.Add( "HUDPaint", "paintthings", PaintThings )	