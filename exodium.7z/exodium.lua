	-- !!! Leave this here as a reminder !!!
-- Don't give this out to anyone, keep this private to yourself as a personal project.
-- If anything have them talk to me about getting the base.
-- Thank You! - ASTEYA
--[[
Usefull websites
https://chatgpt.com/
https://wiki.facepunch.com/gmod/

addons needed:
https://steamcommunity.com/sharedfiles/filedetails/?id=753407026&searchtext=animated+materials
https://steamcommunity.com/sharedfiles/filedetails/?id=858369543&searchtext=animated+materials

if you somehow got this cheat and your not don fent dealer aka lebron james69 then dude mind your own bussiness!
this cheat was made lebron james69 aka dont fent dealer its been in development since 8/10/2024. The project exodium was started for pure fun when someone called shiba was showcasing there
Cool HUD so i decided to make my own. First it was a simple hud cheat whit admin esp and fov and some cool features then it expanded to exodiumv2 that had a hud whit box only no features
after that someone Named asteya gave lebron james69 aka don fent dealer a menu base. Whit that menu base i decided to continue the development of exodium.
]]

jit.flush()
RunConsoleCommand("stopsound")
_G.setfenv(1, _G) -- fuck gluasteal(this was asteyas thingy)

local ply              = LocalPlayer()
local DebugWhite       = Material("models/debug/debugwhite")
local WireFrame        = Material("models/wireframe")
local TransParentWater = Material("models/rendertarget")
local RedWater         = Material("models/rendertarget")
local Glow             = Material("models/shiny")
local mat0             = Material("smokes_mats/misc/misc18/misc18")
local mat1             = Material("models/debug/debugwhite")
--tables
local Visuals          = {}
local Rage             = {}
local Aim              = {}
local Misc             = {}
local Movement         = {}
local Printers         = {
	
	["sprinter_base"] = true,
	["sprinter_rack"] = true,
	["money_printer"] = true,
	["sugarprint_printer"] = true,
	["sugarprint_printernew"] = true,
	["printer_table"] = true,
	["basic_printer"] = true,
	["cc_3dprinter"] = true,
	["shipment_printer"] = true,
	["bricks_server_gangprinter"] = true,
    ["sprinter_base_phys"] = true,
    ["sugarprint_new"] = true,
    ["sugarprint_mini"] = true,
    ["money_printer_ink"] = true,
    ["money_printer_fix"] = true,
    ["sprinter_reggie_printer"] = true,
	["sprinter_mythic_printer"] = true,
	["sprinter_premium+_printer"] = true,
	["sprinter_mids_printer"] = true,
	["sprinter_rack"] = true,
	["sprinter_premium_printer"] = true,
	["sprinter_dank_printer"] = true,
	["sprinter_chronic_printer"] = true
	
}

local CoinMiners       = {
	
	["bm2_bitminer_server"] = true,
	["bm2_bitminer_rack"] = true,
	["bm2_bitminer_1"] = true,
	["bm2_bitminer_2"] = true,
	["ch_bitminer_shelf"] = true,
	["bit_miner_heavy"] = true,
	["bit_miner_medium"] = true,
	["bit_miner_light"] = true,
	["smoke_btc_shelf"] = true
	
}

local OverAllDrugDealers = {
	
	["npc_druggiebuyer"] = true,
	["npc_drugbuyer"] = true
	
}

require("zxcmodule")

local User = nil
local ConfigFolder = "Exodium"
local ConfigFileExtension = "vtf"
local Derama = {
	ConfigTable = {

--------------------------------------------------------------------------
-- Use this for reference, comment it out whenever.

		["tab.checkbox"] = false,
		["tab.button"] = nil, -- Buttons are set to nil and created later on. Look at how the config buttons work.
		["tab.binder"] = KEY_F,
		["Aim.combobox"] = {
			Option = "normal", -- The selected option.
			Options = {"normal", "Silent Aim", "Perfect Silent Aim"}, -- The options we have to select.
		},
	--Aim
	     
	    ["Aim.AimbotType.combobox"] = {
	    	
	    	Option = "Silent Aim",
	    	Options = {"Silent Aim", "Normal", "Perfect Silent Aim"},
	    	
	    }, 
	
	
	    ["Aim.AimbotBones.combobox"] = {
	    	
	    	Option = "Head",
	    	Options = {"Head", "Neck", "Spine"},
	    },
	    ["Aim.TriggerbotBones.combobox"] = {
	    	
	    	Option = "Head",
	    	Options = {"Head", "Neck", "Spine"},
	    	
	    },
	--Rage
	    ["Rage.Anti.Aims.combobox"] = {
	    	
	    	Option = "Spin",
	    	Options = {"Spin", "Jitter", "Tjitter", "Motion", "Fuckery 3000"},
	    	
	    },
	    
	--Movement
	    ["Movement.Select.bhop"] = {
	    	
	    	Option = "Directional",
	    	Options = {"Directional", "Legit", "Rage"},
	    	
	    },
	    
	--Visuals
        
        ["Visuals.3DBox.checkbox"] = nil,
	    
	    
	    ["Visuals.Chams.Material.combobox"] = {
	    	
	    	Option = "DebugWhite",
	    	Options = {"DebugWhite", "Matrix", "WireFrame", "Military Camo", "glow"},
	    	
	    },
	    
	    ["Visuals.Arms.Material.combobox"] = {
	    	
	    	Option = "Animated Wireframe",
	    	Options = {"Animated Wireframe", "Military Camo", "WireFrame", "Matrix", "DebugWhite", "Exodium Classic"},
	    	
	    },
	    
	    ["Visuals.Weapon.Material.combobox"] = {
	    	
	    	Option = "Wireframe",
	    	Options = {"Animated Wireframe", "Military Camo", "WireFrame", "Matrix", "DebugWhite", "Exodium Classic"},
	    	
	    },
	    
	    ["Visuals.Bullet.Trace.Material.combobox"] = {
	    	
	    	Option = "Beam",
	    	Options = {"Beam"},
	    	
	    },
	    
	    ["Visuals.Health.Line.colormixer"] = Color(0,255,0,255),
	    
	    ["Visuals.LocalPlayer.Chams.Mat.combobox"] = {
	    	
	    	Option = "MotionWireFrame",
	    	Options = {"MotionWireFrame", "WireFrame", "DebugWhite", "RedWater(Animted)", "Glow",},
	    	
	    },
	    
	    ["Visuals.3DBox.colormixer"] = Color(255,0,0,255),
	    
	    ["Visuals.AspectRatio.slider"] = 0,
	    ["Visuals.ViewModel.Fov.slider"] = 54,
	    ["Visuals.PlayeFOV.slider"] = 110,
	    ["Visuals.KillSounds.combobox"] = {
	    	
	    	Option = "Warzone Armor Break",
	    	Options = {"Warzone Armor Break", "Bleep","N-word", "skeet", "neverlose","Monster kill", "exodium","codHitMarker","dominating",},
	    	
	    },
	    
	    ["Visuals.HitSounds.combobox"] = {
	    	
	    	Option = "Warzone Armor",
	    	Options = {"Warzone Armor", "Bleep", "skeet","N-word", "neverlose", "exodium","codHitMarker",},
	    	
	    },
	    
	    ["Visuals.Skybox.textentry"] = "...",

		["tab.slider"] = 15.9,
		["tab.colormixer"] = Color(255, 0, 0, 255),
		["tab.textentry"] = "entry text",

--------------------------------------------------------------------------

		["settings.menu.button"] = KEY_INSERT,
		["settings.unload"] = nil,
		["settings.config"] = {
			Option = "",
			Options = {},
		},

		["settings.config.name"] = "",
		["settings.config.rename"] = nil,
		["settings.config.save"] = nil,
		["settings.config.load"] = nil,
		["settings.config.delete"] = nil,-- 187, 60, 60
		["Misc.TitleBarsAndButtons.colormixer"] = Color( 187, 60, 60 ),
		["Misc.MenuText.colormixer"] = Color( 255,112,112 ),
		["Misc.CreditButer.textentry"] = "0",
	},

	LayoutTable = {

--------------------------------------------------------------------------
-- Use this for reference, comment it out whenever.
-- The "Variable" is the value of the data type of the gui element which is supposed to be set above by first identifying it by a config variable.
-- You can also align the elements using "Align" which you set to a string either "Center" or "Right", "Left" is set automatically.

		{Title = "Aim", Controls = {
			{Type = "CheckBox", Text = "Aimbot", Variable = "Aim.Aimbot.checkbox"},
			{Type = "ComboBox", Text = "Aimbot Type", Variable = "Aim.AimbotType.combobox"},
			{Type = "ComboBox", Text = "Body part", Variable = "Aim.AimbotBones.combobox"},
			{Type = "Binder", Text = "Bind", Variable = "Aim.binder"},
            {Type = "Slider", Align = "Left", Text = "Aimbot Fov", Minimum = 0, Maximum = 180, Decimals = 0, Variable = "Aim.Fov.slider"},
			{Type = "ColorMixer", Align = "Left", Text = "fov Color", Variable = "Aim.fovCircleColor.colormixer"},
			{Type = "CheckBox", Align = "Right", Text = "NoSpread", Variable = "Aim.Nospread.combobox"},
			{Type = "CheckBox", Align = "Right", Text = "NoRecoil", Variable = "Aim.Norecoil.combobox"},
			{Type = "CheckBox", Align = "Right", Text = "Extrapolation", Variable = "Aim.Extrapolation.combobox"},
			{Type = "CheckBox", Align = "Right",Text = "Engine Prediction", Variable = "Aim.AimbotEnginePred.checkbox"},
			{Type = "Slider", Align = "Right", Text = "Projectile prediction", Minimum = 0, Maximum = 100, Variable = "Aim.Projectile.Pred.slider"},
			{Type = "CheckBox", Align = "Center", Text = "TriggerBot", Variable = "Aim.TriggerBot.checkbox"},
			{Type = "Binder", Align = "Center", Text = "Bind", Variable = "Aim.Triggerbot.binder"},
			{Type = "ComboBox", Align = "Center", Text = "Body part", Variable = "Aim.TriggerbotBones.combobox"},
			{Type = "CheckBox", Align = "Center", Text = "Aimbot Target ", Variable = "Aim.Aimbot.Target.checkbox"},
			{Type = "ColorMixer", Align = "Center", Text = "", Variable = "Aim.Aimbot.Target.colormixer"},
		}},

--------------------------------------------------------------------------

		{Title = "Rage", Controls = {
			    
			    {Type = "CheckBox", Text = "Anti Aim", Variable = "Rage.AntiAim.checkbox"},
				{Type = "ComboBox", Text = "", Variable = "Rage.Anti.Aims.combobox"},
				{Type = "CheckBox", Align = "Right", Text = "BruteForce Resolver", Variable = "Rage.Resolver.checkbox"},
				{Type = "Slider", Text = "Pitch", Minimum = -180, Maximum = 180, Variable = "Rage.Pitch.slider"},
				{Type = "Slider", Text = "Yaw", Minimum = -360, Maximum = 360, Variable = "Rage.Yaw.slider"},
				{Type = "Slider", Align = "Center", Text =  "Fake Lag", Minimum = 0, Maximum = 20, Variable = "Rage.FakeLag.slider"},
				{Type = "Slider", Text = "Spin Speed", Minimum = 0, Maximum = 5, Variable = "Rage.Spin.Speed.slider"},
				{Type = "Slider", Text = "Motion Speed", Minimum = 0, Maximum = 5, Variable = "Rage.Motion.Speed.slider"},
			
		}},
	
		{Title = "Visuals", Controls = {
			
			{Type = "Label", Text = "ESPN"},
			{Type = "CheckBox", Text = "3D Box", Variable = "Visuals.3DBox.checkbox"},
			{Type = "ColorMixer", Align = "Left", Text = "", Variable = "Visuals.3DBox.colormixer"},
			{Type = "CheckBox", Text = "Name", Variable = "Visuals.Name.checkbox"},
			{Type = "ColorMixer", Align = "Left", Text = "", Variable = "Visuals.Name.colormixer"},
			{Type = "CheckBox", Text = "Health ", Variable = "Visuals.Health.checkbox"},
			{Type = "ColorMixer", Align = "Left", Text = "", Variable = "Visuals.Health.colormixer"},
			{Type = "CheckBox", Text = "Armour ", Variable = "Visuals.Armor.checkbox"},
			{Type = "ColorMixer", Align = "Left", Text = "", Variable = "Visuals.Armor.colormixer"},
			{Type = "CheckBox", Text = "Ping", Variable = "Visuals.Ping.checkbox"},
			{Type = "CheckBox", Text = "Cheater", Variable = "Visuals.Cheater.Finder.checkbox"},
			{Type = "CheckBox", Align = "Left", Text = "Weapon", Variable = "Visuals.WeaponESP.checkbox"},
			{Type = "CheckBox", Align = "Left", Text = "Job", Variable = "Visuals.JobESP.checkbox"},
			{Type = "CheckBox", Align = "Left", Text = "UserGroup", Variable = "Visuals.UserGroupESP.checkbox"},
			{Type = "Label",    Align = "Center", Text = "Chams"},
			{Type = "CheckBox", Align = "Center", Text = "Chams", Variable = "Visuals.Chams.checkbox"},
			{Type = "ColorMixer", Align = "Center", Text = "", Variable = "Visuals.Chams.colormixer"},
			{Type = "ComboBox", Align = "Center", Text = "Material", Variable = "Visuals.Chams.Material.combobox"},
			{Type = "Label",    Align = "Center", Text = "View Model Chams"},
			{Type = "CheckBox", Align = "Center", Text = "Arms", Variable = "Visuals.Arms.Chams.combobox"},
			{Type = "ColorMixer", Align = "Center", Text = "", Variable = "Visuals.Arms.Chams.colormixer"},
			{Type = "ComboBox", Align = "Center", Text = "Material", Variable = "Visuals.Arms.Material.combobox"},
			{Type = "CheckBox", Align = "Center", Text = "Weapon", Variable = "Visuals.Weapon.Chams.combobox"},
			{Type = "ColorMixer", Align = "Center", Text = "", Variable = "Visuals.Weapon.Chams.colormixer"},
			{Type = "ComboBox", Align = "Center", Text = "Material", Variable = "Visuals.Weapon.Material.combobox"},
			{Type = "Label",    Align = "Right", Text = "Sky"},
			{Type = "CheckBox", Align = "Right", Text = "Skybox Changer", Variable = "Visuals.Skybox.Changer.combobox"},
			{Type = "TextEntry", Align = "Right", Text = "", Variable = "Visuals.Skybox.textentry"},
			{Type = "Label",    Align = "Right", Text = "Sky color Modulation"},
			{Type = "ColorMixer", Align = "Right", Text = "", Variable = "Visuals.Sky.ColorModulation.colormixer"},
			{Type = "Button", Align = "Right", Text = "Remove Modulation", Variable = "Visuals.RemoveColorModulation.button"},
			{Type = "Label",    Align = "Right", Text = "World"},
			{Type = "CheckBox", Align = "Right", Text = "Fullbright", Variable = "Visuals.FullBright.combobox"},
			{Type = "Slider", Align = "Right", Text = "Transparent walls Amount", Minimum = 1, Maximum = 20, Variable = "Visuals.TransparentWalls.slider"},
			{Type = "Label",    Align = "Left",Text = "KillEffect"},
			{Type = "ComboBox", Align = "Left", Text = "Effect", Variable = "Visuals.Kill.Effect.combobox"},
			{Type = "Label",    Align = "Left",Text = "HitEffect"},
			{Type = "ComboBox", Align = "Left", Text = "Effect", Variable = "Visuals.Hit.Effect.combobox"},
			{Type = "Slider", Align = "Right", Text = "Aspect Ratio", Minimum = 0, Maximum = 10, Variable = "Visuals.AspectRatio.slider"},
			{Type = "CheckBox", Align = "Center", Text = "Bullet Tracers", Variable = "Visuals.BulletTracers.combobox"},
			{Type = "ColorMixer", Align = "Center", Text = "", Variable = "Visuals.BulletTracers.Color.colormixer"},
			{Type = "ComboBox", Align = "Center", Text = "Material", Variable = "Visuals.Bullet.Trace.Material.combobox"},
			{Type = "Slider", Align = "Right", Text = "Field Of view", Minimum = 30, Maximum = 180, Variable = "Visuals.PlayeFOV.slider"},
			{Type = "Slider", Align = "Left", Text = " ViewModel Field of View", Minimum = 30, Maximum = 180, Variable = "Visuals.ViewModel.Fov.slider"},
			{Type = "Label", Text = "Grust"},
			{Type = "CheckBox", Align = "Left", Text = "Hemp", Variable = "Visuals.HempESP.combobox"},
			{Type = "CheckBox", Align = "Left", Text = "Stone ore", Variable = "Visuals.StoneOreESP.combobox"},
			{Type = "CheckBox", Align = "Left", Text = "Recycler", Variable = "Visuals.RecyclerESP.combobox"},
			{Type = "CheckBox", Align = "Left", Text = "Sulfur ore", Variable = "Visuals.SulfurOreESP.combobox"},
			{Type = "CheckBox", Align = "Left", Text = "Metal ore", Variable = "Visuals.MetalOreESP.combobox"},
			{Type = "CheckBox", Align = "Left", Text = "Weapons", Variable = "Visuals.WeaponsESP.combobox"},
			{Type = "CheckBox", Align = "Right", Text = "ThirdPerson", Variable = "Visuals.ThirdPerson.checkbox"},
			{Type = "Slider", Align = "Right", Text = " ThirdPerson Field of View", Minimum = 30, Maximum = 180, Variable = "Visuals.Thirdperson.Fov.slider"},
			{Type = "Binder",   Align = "Right",  Text = "Bind", Variable = "Visuals.ThirdPerson.binder"},
			{Type = "Label", Align = "Right", Text = "DarkRP"},
			{Type = "CheckBox", Align = "Right", Text = "Printer ESP", Variable = "Visuals.PrinterESP.combobox"},
			{Type = "ColorMixer", Align = "Right", Text = "", Variable = "Visuals.PrinterESP.colormixer"},
			{Type = "CheckBox", Align = "Right", Text = "BitcoinMiner ESP", Variable = "Visuals.BitcoinminerESP.combobox"},
			{Type = "ColorMixer", Align = "Right", Text = "", Variable = "Visuals.BitcoinMiner.colormixer"},
			{Type = "CheckBox", Align = "Right", Text = "Meth Dealer", Variable = "Visuals.MethDealerESP.combobox"},
			{Type = "CheckBox", Align = "Right", Text = "Zaza Dealer", Variable = "Visuals.ZazaDealerESP.combobox"},
			{Type = "CheckBox", Align = "Right", Text = "Cigs Dealer", Variable = "Visuals.CigsDealerESP.combobox"},
			{Type = "CheckBox", Align = "Right", Text = "OverAll Drug Dealer", Variable = "Visuals.DrugDealer.combobox"},
			{Type = "Label", Align = "Center", Text = "TTT"},
			{Type = "CheckBox", Align = "Center", Text = "Traitor finder", Variable = "Visuals.TraitorESP.combobox"},
			{Type = "Label", Align = "Center", Text = "Exodium Classic HUD"},
			{Type = "CheckBox", Align = "Center", Text = "Exodium v2 HUD", Variable = "Visuals.ExodiumV2.combobox"},
			{Type = "Label", Align = "Center", Text = "Admin ESPN"},
			{Type = "CheckBox", Align = "Center", Text = "3D Box", Variable = "Visuals.3DAdminBox.checkbox"},
			{Type = "CheckBox", Align = "Center", Text = "Glow", Variable = "Visuals.AdminGlow.checkbox"},
			{Type = "Label", Align = "Center", Text = "Local Player"},
			{Type = "CheckBox", Align = "Center", Text = "Glow Outline", Variable = "Visuals.LocalPlayer.Outline.checkbox"},
			{Type = "ColorMixer", Align = "Center", Text = "", Variable = "Visuals.LocalPlayer.Outline.colormixer"},
			{Type = "CheckBox", Align = "Center", Text = "Chams", Variable = "Visuals.LocalPlayer.Chams.checkbox"},
			{Type = "ColorMixer", Align = "Center", Text = "", Variable = "Visuals.LocalPlayer.Chams.colormixer"},
			{Type = "ComboBox", Align = "Center", Text = "Material", Variable = "Visuals.LocalPlayer.Chams.Mat.combobox"},
			{Type = "Label", Align = "Left", Text = "Sound Stuff"},
			{Type = "CheckBox", Align = "Left", Text = "HitSounds", Variable = "Visuals.HitSounds.CheckBox"},
			{Type = "ComboBox", Align = "Left", Text = "KillSounds", Variable = "Visuals.KillSounds.combobox"},
			{Type = "ComboBox", Align = "Left", Text = "HitSounds", Variable = "Visuals.HitSounds.combobox"},
			{Type = "Label", Align = "Center", Text = "Weapon stuff"},
			{Type = "CheckBox", Align = "Center", Text = "no sway", Variable = "Visuals.noSway.Peek"},
			
		}},
		{Title = "Movement", Controls = {
			
			{Type = "CheckBox", Align = "Left", Text = "Bunny Hop", Variable = "Movement.movement.autojump"},
			{Type = "ComboBox", Text = "Bunny hop Mode", Variable = "Movement.Select.bhop" },
			{Type = "CheckBox", Align = "Right", Text = "Circle Strafe", Variable = "Movement.Circle.Strafe"},
			{Type = "Binder",   Align = "Right",  Text = "Cirlce Strafe Key", Variable = "Movement.Circle.Strafe.binder"},
			{Type = "CheckBox", Align = "Right", Text = "Auto Peek", Variable = "Movement.Auto.Peek"},
			{Type = "ColorMixer", Align = "Right", Text = "Auto Peek Color", Variable = "Movement.colormixer"},
			{Type = "Binder",   Align = "Right",  Text = "Auto Peek Key", Variable = "Movement.Auto.Peek.binder"},
			{Type = "CheckBox", Align = "Center", Text = "Walk Bot", Variable = "Movement.Walk.Bot.Peek"},
			{Type = "Binder",   Align = "Center",  Text = "Walk Bot Key", Variable = "Movement.Walk.Bot.binder"},
			{Type = "CheckBox", Align = "Left", Text = "Fake Duck", Variable = "Movement.Fake.Duck.Peek"},
			{Type = "Binder",   Align = "Left",  Text = "Fake Duck Key", Variable = "Movement.Fake.Duck.binder"},
			{Type = "CheckBox", Align = "Center", Text = "SpeedHack", Variable = "Movement.Speed.Hack.Peek"},
			{Type = "Binder",   Align = "Center",  Text = "SpeedHack Key", Variable = "Movement.Speed.Hack.binder"},
			{Type = "Label",    Align = "Center",Text = "Speedhack is only for hvh!"},
			{Type = "CheckBox", Align = "Left", Text = "AirStuck", Variable = "Movement.Air.Stuck.Peek"},
			{Type = "Binder",   Align = "Left",  Text = "AirStuck Key", Variable = "Movement.Air.Stuck.binder"},
			{Type = "CheckBox", Align = "Right", Text = "Slow Motion", Variable = "Movement.Slow.Motion.Peek"},
			{Type = "Slider",   Align = "Right", Text = "Slow Motion amount", Minimum = 0, Maximum = 10, Variable = "Movement.Slow.Motion.slider"},
			

		}},

		{Title = "Nets And Hooks", Controls = {
			
			{Type = "Label", Align = "Right", Text = "Hooks"},
			{Type = "Label", Align = "Left", Text = "Nets"},
			
		}},
		{Title = "Misc", Controls = {
			{Type = "Binder", Text = "Menu Button", Variable = "settings.menu.button"},
			{Type = "Button", Text = "Unload", Variable = "settings.unload"},
			{Type = "ComboBox", Align = "Center", Text = "Config", Variable = "settings.config"},
			{Type = "TextEntry", Align = "Center", Text = "Name", Variable = "settings.config.name"},
			{Type = "Button", Align = "Center", Text = "Rename", Variable = "settings.config.rename"},
			{Type = "Button", Align = "Center", Text = "Save", Variable = "settings.config.save"},
			{Type = "Button", Align = "Center", Text = "Load", Variable = "settings.config.load"},
			{Type = "Button", Align = "Center", Text = "Delete", Variable = "settings.config.delete"},
			{Type = "Label", Align = "Right", Text = "Exploits"},
			{Type = "CheckBox", Align = "Right", Text = "Vendor Exploit(no servers)", Variable = "Misc.Exploits.Vendor.Peek"},
			{Type = "CheckBox", Align = "Right", Text = "Server Crasher(no servers)", Variable = "Misc.Exploits.ServerCrasher.Peek"},
            {Type = "Label", Align = "Center", Text = "Debug stuff"},
            {Type = "CheckBox", Align = "Center", Text = "Debug Info", Variable = "Misc.Debug.Info.Peek"},
            {Type = "CheckBox", Align = "Center", Text = "Show HitBoxes", Variable = "Misc.Hit.Boxes.Peek"},
            {Type = "Label", Align = "Right", Text = "Cheat Protection"},
            {Type = "CheckBox", Align = "Right", Text = "Anti cheat Finder", Variable = "Misc.Anticheat.Finder.Peek"},
            {Type = "CheckBox", Align = "Right", Text = "Screengrab Protection", Variable = "Misc.Screengrabed.Peek"},
            {Type = "Label", Align = "Left", Text = "Menu"},
            {Type = "ColorMixer", Align = "Left", Text = "Menu Color", Variable = "Misc.TitleBarsAndButtons.colormixer"},
            {Type = "ColorMixer", Align = "Left", Text = "Text Color", Variable = "Misc.MenuText.colormixer"},
            {Type = "Label", Align = "Right", Text = "smokes.gg stuff!"},
            {Type = "CheckBox", Align = "Right", Text = "Unclick me when you buy credit!", Variable = "Misc.CreditButer.checkbox"},
            {Type = "TextEntry", Align = "Right", Text = "Credit Buyer", Variable = "Misc.CreditButer.textentry"},
            {Type = "CheckBox", Align = "Center", Text = "Custom Disconnect", Variable = "Misc.CustomDisconnect.checkbox"},
            {Type = "TextEntry", Align = "Center", Text = "", Variable = "Misc.CustomDisconnect.textentry"},
                        {Type = "CheckBox", Align = "Center", Text = "Name Changer", Variable = "Misc.NameChanger.checkbox"},
            {Type = "TextEntry", Align = "Center", Text = "", Variable = "Misc.NameChanger.textentry"}
            
            
            
		}},
	},
}

--Debug Run Stuff Dont remove i know it looks shit and messy but trust me._.
gameevent.Listen( "player_hurt" )
hook.Add("player_hurt", "tadwa", function(data)
local attacker, health, id, victim = data.attacker, data.health, data.userid, Player(data.userid)
    --Derama.ConfigTable["Visuals.HitSounds.combobox"]
if attacker == ply:UserID() then
    end
end)

local Util = {
	Buttons = {},
	Hooks = {}
}

function Util.IsButtonPressed(Button)
	if (Util.Buttons[Button] == nil) then
		Util.Buttons[Button] = true
	end

	return input.IsButtonDown(Button) && !Util.Buttons[Button]
end

function Util.UpdateButtons()
	for Button = BUTTON_CODE_NONE, BUTTON_CODE_COUNT do
		Util.Buttons[Button] = input.IsButtonDown(Button)
	end
end

function Util.AddHook(Event, Func)
	hook.Add(Event, "Derama", Func)
end

function Util.RemoveHook(Event)
	hook.Remove(Event, "Derama")
end

local GUI = {}

function GUI.Label(ScrollPanel, Control, XPosition, YPosition)
	if (!Control.Text) then
		Control.Text = "This is a Label"
	end

	if (!Control.XPosition) then
		Control.XPosition = 0
	end

	if (!Control.YPosition) then
		Control.YPosition = 0
	end

	XPosition = XPosition + Control.XPosition
	YPosition = YPosition + Control.YPosition

	local Label = vgui.Create("DLabel", ScrollPanel)

	Label:SetPos(XPosition, YPosition)
	Label:SetTextColor(Color(0, 0, 0, 0))

	Label.Paint = function(self, Width, Height)
		self:SetText(Control.Text)

		surface.SetFont("DermaDefault")

		draw.SimpleTextOutlined(self:GetText(), "Trebuchet18", 1, 0, Derama.ConfigTable["Misc.MenuText.colormixer"], TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP, 1, Color(0, 0, 0, 255 / 3))

		self:SetWidth(surface.GetTextSize(self:GetText()) + 1)
	end
end

function GUI.CheckBox(ScrollPanel, Control, XPosition, YPosition)
	if (!Control.Text) then
		Control.Text = "This is a CheckBox"
	end

	if (!Control.XPosition) then
		Control.XPosition = 0
	end

	if (!Control.YPosition) then
		Control.YPosition = 0
	end

	XPosition = XPosition + Control.XPosition
	YPosition = YPosition + Control.YPosition

	if (!Control.Variable) then
		Control.Variable = Control.Text
	end

	if (!Derama.ConfigTable[Control.Variable]) then
		Derama.ConfigTable[Control.Variable] = false
	end

	local CheckBox = vgui.Create("DCheckBoxLabel", ScrollPanel)

	CheckBox:SetText(Control.Text)
	CheckBox:SetPos(XPosition, YPosition)

	CheckBox.Label:SetTextColor(Color(0, 0, 0, 0))
	CheckBox.Label:Dock(RIGHT)
	CheckBox.Label:DockMargin(0, 0, 5, 0)

	CheckBox.OnChange = function(self, Value)
		Derama.ConfigTable[Control.Variable] = Value
	end

	CheckBox.Paint = function(self, Width, Height)
		self:SetValue(Derama.ConfigTable[Control.Variable])
	end

	CheckBox.Button.Paint = function(self, Width, Height)
		surface.SetDrawColor(64, 64, 64)

		if (self:IsHovered() || CheckBox.Label:IsHovered()) then
			surface.SetDrawColor(64, 64, 64)
		end

		surface.DrawRect(0, 0, Width, Height)

		if (self:GetChecked()) then
			surface.SetDrawColor(Derama.ConfigTable["Misc.TitleBarsAndButtons.colormixer"])
			surface.DrawRect(2, 2, Width - 4, Height - 4)
			surface.SetDrawColor(Derama.ConfigTable["Misc.TitleBarsAndButtons.colormixer"])
			surface.DrawOutlinedRect(2, 2, Width - 4, Height - 4)
		end

		surface.SetDrawColor(Derama.ConfigTable["Misc.TitleBarsAndButtons.colormixer"])
		surface.DrawOutlinedRect(0, 0, Width, Height)
	end

	CheckBox.Label.Paint = function(self, Width, Height)
		surface.SetFont("DermaDefault")

		draw.SimpleTextOutlined(self:GetText(), "DermaDefault", 1, 0, Derama.ConfigTable["Misc.MenuText.colormixer"], TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP, 1, Color(0, 0, 0, 255 / 3))

		self:SetWidth(surface.GetTextSize(self:GetText()) + 1)
	end
end

function GUI.Button(ScrollPanel, Control, XPosition, YPosition)
	if (!Control.Text) then
		Control.Text = "This is a Button"
	end

	if (!Control.XPosition) then
		Control.XPosition = 0
	end

	if (!Control.YPosition) then
		Control.YPosition = 0
	end

	XPosition = XPosition + Control.XPosition
	YPosition = YPosition + Control.YPosition

	if (!Control.Variable) then
		Control.Variable = Control.Text
	end

	if (!Derama.ConfigTable[Control.Variable]) then
		Derama.ConfigTable[Control.Variable] = function()
			Error("There is no function for this button!")
		end
	end

	local Button = vgui.Create("DButton", ScrollPanel)

	Button:SetText(Control.Text)
	Button:SetSize(190, 20)
	Button:SetPos(XPosition, YPosition)
	Button:SetTextColor(Color(0, 0, 0, 0))

	Button.Paint = function(self, Width, Height)
		surface.SetDrawColor(64,64,64)

		if (self:IsHovered()) then
			surface.SetDrawColor(64,64,64)
		end

		if (self:IsDown()) then
			surface.SetDrawColor(Derama.ConfigTable["Misc.MenuText.colormixer"])
		end

		surface.DrawRect(0, 0, Width, Height)
		surface.SetDrawColor(0, 0, 0, 255)
		surface.DrawOutlinedRect(0, 0, Width, Height)

		draw.SimpleText(self:GetText(), "Trebuchet18", Width / 2, Height / 2, Derama.ConfigTable["Misc.MenuText.colormixer"], TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)

		if (Derama.ConfigTable[Control.Variable]) then
			self.DoClick = Derama.ConfigTable[Control.Variable]
		end
	end
end

function GUI.Binder(ScrollPanel, Control, XPosition, YPosition)
	if (!Control.Text) then
		Control.Text = "This is a Binder"
	end

	if (!Control.XPosition) then
		Control.XPosition = 0
	end

	if (!Control.YPosition) then
		Control.YPosition = 0
	end

	XPosition = XPosition + Control.XPosition
	YPosition = YPosition + Control.YPosition

	GUI.Label(ScrollPanel, Control, XPosition, YPosition)

	if (!Control.Variable) then
		Control.Variable = Control.Text
	end

	if (!Derama.ConfigTable[Control.Variable]) then
		Derama.ConfigTable[Control.Variable] = KEY_NONE
	end

	local Binder = vgui.Create("DBinder", ScrollPanel)

	Binder:SetSize(190, 20)
	Binder:SetPos(XPosition, YPosition + 15)
	Binder:SetTextColor(Color(0, 0, 0, 0))

	Binder.OnChange = function(self, Value)
		Derama.ConfigTable[Control.Variable] = Value
	end

	Binder.Paint = function(self, Width, Height)
		surface.SetDrawColor(64,64,64)

		if (self:IsHovered()) then
			surface.SetDrawColor(64,64,64)
		end

		if (self:IsDown()) then
			surface.SetDrawColor(64,64,64)
		end

		surface.DrawRect(0, 0, Width, Height)
		surface.SetDrawColor(0, 0, 0, 255)
		surface.DrawOutlinedRect(0, 0, Width, Height)

		draw.SimpleText(self:GetText(), "Trebuchet18", Width / 2, Height / 2, Derama.ConfigTable["Misc.MenuText.colormixer"], TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)

		if (!self.Trapping) then
			self:SetValue(Derama.ConfigTable[Control.Variable])
		end
	end
end

function GUI.ComboBox(ScrollPanel, Control, XPosition, YPosition)
	if (!Control.Text) then
		Control.Text = "This is a ComboBox"
	end

	if (!Control.XPosition) then
		Control.XPosition = 0
	end

	if (!Control.YPosition) then
		Control.YPosition = 0
	end

	XPosition = XPosition + Control.XPosition
	YPosition = YPosition + Control.YPosition

	GUI.Label(ScrollPanel, Control, XPosition, YPosition)

	if (!Control.Variable) then
		Control.Variable = Control.Text
	end

	if (!Derama.ConfigTable[Control.Variable]) then
		Derama.ConfigTable[Control.Variable] = {
			Option = "",
			Options = {}
		}
	end

	local ComboBox = vgui.Create("DComboBox", ScrollPanel)

	ComboBox:SetValue(Derama.ConfigTable[Control.Variable].Option)
	ComboBox:SetSize(190, 20)
	ComboBox:SetPos(XPosition, YPosition + 15)
	ComboBox:SetTextColor(Color(0, 0, 0, 0))
	ComboBox:SetSortItems(false)

	ComboBox.DropButton:SetVisible(false)

	ComboBox.OnSelect = function(self, Index, Value)
		Derama.ConfigTable[Control.Variable].Option = Value
	end

	ComboBox.Paint = function(self, Width, Height)
		self:SetValue(Derama.ConfigTable[Control.Variable].Option)

		surface.SetDrawColor(64, 64, 64)

		if (self:IsHovered()) then
			surface.SetDrawColor(64,64, 64)
		end

		if (self:IsHovered() && input.IsButtonDown(MOUSE_LEFT)) then
			surface.SetDrawColor(64, 64, 64)
		end

		if (self:IsMenuOpen()) then
			self.Menu:MoveToFront()

			if (input.IsButtonDown(Derama.ConfigTable["settings.menu.button"])) then
				self:CloseMenu()
			end
		end

		surface.DrawRect(0, 0, Width, Height)
		surface.SetDrawColor(0, 0, 0, 255)
		surface.DrawOutlinedRect(0, 0, Width, Height)

		draw.SimpleText(self:GetText(), "Trebuchet18", 10, Height / 2, Derama.ConfigTable["Misc.MenuText.colormixer"], TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		draw.SimpleText(self:IsMenuOpen() && "5" || "6", "Marlett", Width - 5, Height / 2, Color(0, 0, 0), TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
	end

	local OriginalOnMenuOpened = ComboBox.OnMenuOpened

	ComboBox.OnMenuOpened = function(self, Menu)
		OriginalOnMenuOpened(self, Menu)

		local Children = Menu:GetCanvas():GetChildren()

		for Index, Child in ipairs(Children) do
			Child:SetTextColor(Color(0, 0, 0, 0))

			Child.Paint = function(self, Width, Height)
				surface.SetDrawColor(64,64,64)

				if (self:IsHovered()) then
					surface.SetDrawColor(64,64,64)
				end

				surface.DrawRect(0, 0, Width, Height)
				surface.SetDrawColor(0, 0, 0, 255)

				if (Index == 1 && #Children > 1) then
					surface.DrawOutlinedRect(0, -1, Width, Height + 2)
				elseif (Index == #Children) then
					surface.DrawOutlinedRect(0, -1, Width, Height + 1)
				else
					surface.DrawOutlinedRect(0, -1, Width, Height + 2)
				end

				draw.SimpleText(self:GetText(), "Trebuchet18", 10, Height / 2, Derama.ConfigTable["Misc.MenuText.colormixer"], TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
			end
		end
	end

	local OriginalOpenMenu = ComboBox.OpenMenu

	ComboBox.OpenMenu = function(self, ControlOpener)
		self:Clear()

		local Options = Derama.ConfigTable[Control.Variable].Options

		if (Options) then
			for Index, Option in ipairs(Options) do
				self:AddChoice(tostring(Option))
			end
		end

		OriginalOpenMenu(self, ControlOpener)
	end
end

function GUI.Slider(ScrollPanel, Control, XPosition, YPosition)
	if (!Control.Text) then
		Control.Text = "This is a Slider"
	end

	if (!Control.XPosition) then
		Control.XPosition = 0
	end

	if (!Control.YPosition) then
		Control.YPosition = 0
	end

	XPosition = XPosition + Control.XPosition
	YPosition = YPosition + Control.YPosition

	if (!Control.Variable) then
		Control.Variable = Control.Text
	end

	if (!Derama.ConfigTable[Control.Variable]) then
		Derama.ConfigTable[Control.Variable] = 0
	end

	if (!Control.Minimum) then
		Control.Minimum = -10
	end

	if (!Control.Maximum) then
		Control.Maximum = 10
	end

	if (!Control.Decimals) then
		Control.Decimals = 0
	end

	local Slider = vgui.Create("DNumSlider", ScrollPanel)

	Slider:SetText(Control.Text)
	Slider:SetSize(190, 50)
	Slider:SetPos(XPosition, YPosition + 15)
	Slider:SetMin(Control.Minimum)
	Slider:SetMax(Control.Maximum)
	Slider:SetDecimals(Control.Decimals)

	Slider.Label:SetVisible(false)
	Slider.TextArea:SetVisible(false)

	Slider.OnValueChanged = function(self, Value)
		Derama.ConfigTable[Control.Variable] = math.Truncate(Value, self:GetDecimals())

		if (Derama.ConfigTable[Control.Variable] == -0) then
			Derama.ConfigTable[Control.Variable] = 0
		end

		self:SetValue(Derama.ConfigTable[Control.Variable])
	end

	Slider.Paint = function(self, Width, Height)
		self:SetValue(Derama.ConfigTable[Control.Variable])

		draw.SimpleTextOutlined(self:GetText(), "Trebuchet18", Width / 2, 0, Derama.ConfigTable["Misc.MenuText.colormixer"], TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP, 1, Color(0, 0, 0, 255 / 3))
		draw.SimpleTextOutlined(Derama.ConfigTable[Control.Variable], "Trebuchet18", Width / 2, Height, Derama.ConfigTable["Misc.MenuText.colormixer"], TEXT_ALIGN_CENTER, TEXT_ALIGN_BOTTOM, 1, Color(0, 0, 0, 255 / 3))
	end

	Slider.Slider.Paint = function(self, Width, Height)
		local Dragging = self:GetDragging()

		surface.SetDrawColor(64,64,64)

		if (self:IsHovered()) then
			surface.SetDrawColor(64,64,64)
		end

		if (Dragging) then
			surface.SetDrawColor(64,64,64)
		end

		surface.DrawRect(5, Height / 2 - 3, Width - 10, 4)
		surface.SetDrawColor(Derama.ConfigTable["Misc.TitleBarsAndButtons.colormixer"])
		surface.DrawOutlinedRect(5, Height / 2 - 3, Width - 10, 4)

		local XPosition, YPosition = self.Knob:GetPos()

		surface.SetDrawColor(Derama.ConfigTable["Misc.TitleBarsAndButtons.colormixer"])

		if (self:IsHovered()) then
			surface.SetDrawColor(Derama.ConfigTable["Misc.TitleBarsAndButtons.colormixer"])
		end

		if (Dragging) then
			surface.SetDrawColor(Derama.ConfigTable["Misc.TitleBarsAndButtons.colormixer"])
		end

		surface.DrawRect(XPosition + 5, YPosition, 5, 15)
		surface.SetDrawColor(Derama.ConfigTable["Misc.TitleBarsAndButtons.colormixer"])
		surface.DrawOutlinedRect(XPosition + 5, YPosition, 5, 15)
	end

	Slider.Slider.Knob.Paint = function(self, Width, Height)
	end
end

local AlphaGrid = Material("gui/alpha_grid.png", "nocull")

function GUI.ColorMixer(ScrollPanel, Control, XPosition, YPosition)
	if (!Control.Text) then
		Control.Text = "This is a ColorMixer"
	end

	if (!Control.XPosition) then
		Control.XPosition = 0
	end

	if (!Control.YPosition) then
		Control.YPosition = 0
	end

	XPosition = XPosition + Control.XPosition
	YPosition = YPosition + Control.YPosition

	GUI.Label(ScrollPanel, Control, XPosition + 20, YPosition)

	if (!Control.Variable) then
		Control.Variable = Control.Text
	end

	if (!Derama.ConfigTable[Control.Variable]) then
		Derama.ConfigTable[Control.Variable] = Color(0, 0, 0, 0)
	end

	local Button = vgui.Create("DButton", ScrollPanel)

	Button:SetText("")
	Button:SetSize(15, 15)
	Button:SetPos(XPosition, YPosition)
	Button:SetTextColor(Color(0, 0, 0, 0))

	Button.Paint = function(self, Width, Height)
		surface.SetDrawColor(210, 210, 210, 255)
		surface.SetMaterial(AlphaGrid)
		surface.DrawTexturedRect(0, 0, Width, Height)
		surface.SetDrawColor(Derama.ConfigTable[Control.Variable])
		surface.DrawRect(0, 0, Width, Height)
		surface.SetDrawColor(0, 0, 0, 255)
		surface.DrawOutlinedRect(0, 0, Width, Height)
	end

	local ColorMixer = nil

	Button.DoClick = function(self)
		if (ColorMixer) then
			ColorMixer:SetVisible(!ColorMixer:IsVisible())

			return
		end

		ColorMixer = vgui.Create("DColorMixer", ScrollPanel)

		ColorMixer:SetSize(190, 100)
		ColorMixer:SetPos(XPosition, YPosition)
		ColorMixer:SetPalette(false)
		ColorMixer:SetAlphaBar(true)
		ColorMixer:SetWangs(false)
		ColorMixer:SetColor(Derama.ConfigTable[Control.Variable])

		ColorMixer.ValueChanged = function(self, Value)
			Derama.ConfigTable[Control.Variable] = Value
		end

		ColorMixer.Paint = function(self, Width, Height)
			self:MoveToFront()

			if (self:GetColor() != Derama.ConfigTable[Control.Variable]) then
				self:SetColor(Derama.ConfigTable[Control.Variable])
			end

			if (input.IsButtonDown(Derama.ConfigTable["settings.menu.button"])) then
				self:SetVisible(!self:IsVisible())
			end

			if (!(self:IsHovered() || (self.HSV:IsHovered() || self.HSV.Knob:IsHovered()) || self.Alpha:IsHovered() || self.RGB:IsHovered()) && Util.IsButtonPressed(MOUSE_LEFT)) then
				self:SetVisible(!self:IsVisible())
			end
		end

		ColorMixer.HSV.Knob.Paint = function(self, Width, Height)
			surface.SetDrawColor(210, 210, 210, 255)

			if (self:IsHovered()) then
				surface.SetDrawColor(230, 230, 230, 255)
			end

			if (ColorMixer.HSV.Dragging || self:IsDown()) then
				surface.SetDrawColor(255, 255, 255, 255)
			end

			surface.DrawRect(3, 3, Width - 6, Height - 6)
			surface.SetDrawColor(0, 0, 0, 255)
			surface.DrawOutlinedRect(3, 3, Width - 6, Height - 6)
		end
	end
end

function GUI.TextEntry(ScrollPanel, Control, XPosition, YPosition)
	if (!Control.Text) then
		Control.Text = "This is a TextEntry"
	end

	if (!Control.XPosition) then
		Control.XPosition = 0
	end

	if (!Control.YPosition) then
		Control.YPosition = 0
	end

	XPosition = XPosition + Control.XPosition
	YPosition = YPosition + Control.YPosition

	GUI.Label(ScrollPanel, Control, XPosition, YPosition)

	if (!Control.Variable) then
		Control.Variable = Control.Text
	end

	if (!Derama.ConfigTable[Control.Variable]) then
		Derama.ConfigTable[Control.Variable] = ""
	end

	local TextEntry = vgui.Create("DTextEntry", ScrollPanel)

	TextEntry:SetSize(190, 20)
	TextEntry:SetPos(XPosition, YPosition + 15)
	TextEntry:SetUpdateOnType(true)
	TextEntry:SetTextColor(Derama.ConfigTable["Misc.MenuText.colormixer"])
	TextEntry:SetCursorColor(Color(0, 0, 0, 0))
	TextEntry:SetHighlightColor(Color(0, 0, 0, 0))
	TextEntry:SetPlaceholderColor(Color(0, 0, 0, 0))

	TextEntry.OnValueChange = function(self, Value)
		Derama.ConfigTable[Control.Variable] = Value
	end

	TextEntry.Paint = function(self, Width, Height)
		self:SetValue(Derama.ConfigTable[Control.Variable])

		if (input.IsButtonDown(Derama.ConfigTable["settings.menu.button"])) then
			self:FocusNext()
		end

		surface.SetDrawColor(64,64,64)

		if (self:IsHovered()) then
			surface.SetDrawColor(64,64,64)
		end

		if (self:IsEditing()) then
			surface.SetDrawColor(64,64,64)
		end

		surface.DrawRect(0, 0, Width, Height)
		surface.SetDrawColor(64,64,64)
		surface.DrawOutlinedRect(0, 0, Width, Height)

		draw.SimpleText(self:GetText(), "Trebuchet18", 5, Height / 2, Derama.ConfigTable["Misc.MenuText.colormixer"], TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
	end
end

local Menu = {
	Frame = nil,
	ActiveTab = nil
}

function Menu.LayoutControls(ScrollPanel, TabTitle) -- Mother of god ;-;
	for Index, Tab in ipairs(Derama.LayoutTable) do
		if (Tab.Title == TabTitle) then
			local Controls = Tab.Controls

			if (Controls) then
				local XPosition = 5
				local LeftYPosition = 0
				local CenterYPosition = 0
				local RightYPosition = 0

				for Index, Control in ipairs(Controls) do
					if (!Control.Align || Control.Align == "Left" || (Control.Align != "Center" && Control.Align != "Right")) then
						XPosition = 5

						if (Control.Type == "Label") then
							GUI.Label(ScrollPanel, Control, XPosition, LeftYPosition)
						elseif (Control.Type == "CheckBox") then
							GUI.CheckBox(ScrollPanel, Control, XPosition, LeftYPosition)
						elseif (Control.Type == "Button") then
							GUI.Button(ScrollPanel, Control, XPosition, LeftYPosition)

							LeftYPosition = LeftYPosition + 5
						elseif (Control.Type == "Binder") then
							GUI.Binder(ScrollPanel, Control, XPosition, LeftYPosition)

							LeftYPosition = LeftYPosition + 20
						elseif (Control.Type == "ComboBox") then
							GUI.ComboBox(ScrollPanel, Control, XPosition, LeftYPosition)

							LeftYPosition = LeftYPosition + 20
						elseif (Control.Type == "Slider") then
							LeftYPosition = LeftYPosition - 10

							GUI.Slider(ScrollPanel, Control, XPosition, LeftYPosition)

							LeftYPosition = LeftYPosition + 55
						elseif (Control.Type == "TextEntry") then
							GUI.TextEntry(ScrollPanel, Control, XPosition, LeftYPosition)

							LeftYPosition = LeftYPosition + 20
						elseif (Control.Type == "ColorMixer") then
							GUI.ColorMixer(ScrollPanel, Control, XPosition, LeftYPosition)
						elseif (Control.Type == "Spacer") then
							LeftYPosition = LeftYPosition + (Control.Space || 20)
						end

						LeftYPosition = LeftYPosition + 20
					end

					if (Control.Align == "Center") then
						XPosition = 205

						if (Control.Type == "Label") then
							GUI.Label(ScrollPanel, Control, XPosition, CenterYPosition)
						elseif (Control.Type == "CheckBox") then
							GUI.CheckBox(ScrollPanel, Control, XPosition, CenterYPosition)
						elseif (Control.Type == "Button") then
							GUI.Button(ScrollPanel, Control, XPosition, CenterYPosition)

							CenterYPosition = CenterYPosition + 5
						elseif (Control.Type == "Binder") then
							GUI.Binder(ScrollPanel, Control, XPosition, CenterYPosition)

							CenterYPosition = CenterYPosition + 20
						elseif (Control.Type == "ComboBox") then
							GUI.ComboBox(ScrollPanel, Control, XPosition, CenterYPosition)

							CenterYPosition = CenterYPosition + 20
						elseif (Control.Type == "Slider") then
							CenterYPosition = CenterYPosition - 10

							GUI.Slider(ScrollPanel, Control, XPosition, CenterYPosition)

							CenterYPosition = CenterYPosition + 55
						elseif (Control.Type == "TextEntry") then
							GUI.TextEntry(ScrollPanel, Control, XPosition, CenterYPosition)

							CenterYPosition = CenterYPosition + 20
						elseif (Control.Type == "ColorMixer") then
							GUI.ColorMixer(ScrollPanel, Control, XPosition, CenterYPosition)
						elseif (Control.Type == "Spacer") then
							CenterYPosition = CenterYPosition + (Control.Space || 20)
						end

						CenterYPosition = CenterYPosition + 20
					end

					if (Control.Align == "Right") then
						XPosition = 405

						if (Control.Type == "Label") then
							GUI.Label(ScrollPanel, Control, XPosition, RightYPosition)
						elseif (Control.Type == "CheckBox") then
							GUI.CheckBox(ScrollPanel, Control, XPosition, RightYPosition)
						elseif (Control.Type == "Button") then
							GUI.Button(ScrollPanel, Control, XPosition, RightYPosition)

							RightYPosition = RightYPosition + 5
						elseif (Control.Type == "Binder") then
							GUI.Binder(ScrollPanel, Control, XPosition, RightYPosition)

							RightYPosition = RightYPosition + 20
						elseif (Control.Type == "ComboBox") then
							GUI.ComboBox(ScrollPanel, Control, XPosition, RightYPosition)

							RightYPosition = RightYPosition + 20
						elseif (Control.Type == "Slider") then
							RightYPosition = RightYPosition - 10

							GUI.Slider(ScrollPanel, Control, XPosition, RightYPosition)

							RightYPosition = RightYPosition + 55
						elseif (Control.Type == "TextEntry") then
							GUI.TextEntry(ScrollPanel, Control, XPosition, RightYPosition)

							RightYPosition = RightYPosition + 20
						elseif (Control.Type == "ColorMixer") then
							GUI.ColorMixer(ScrollPanel, Control, XPosition, RightYPosition)
						elseif (Control.Type == "Spacer") then
							RightYPosition = RightYPosition + (Control.Space || 20)
						end

						RightYPosition = RightYPosition + 20
					end
				end
			end
		end
	end
end

function Menu.Render()
	if (Menu.Frame) then
		Menu.Frame:SetVisible(!Menu.Frame:IsVisible())

		return
	end

	Menu.Frame = vgui.Create("DFrame")

	Menu.Frame:SetTitle("Exodium")
	Menu.Frame:SetSize(640, 480)
	Menu.Frame:Center()
	Menu.Frame:MakePopup()
	Menu.Frame:SetScreenLock(true)

	Menu.Frame.lblTitle:SetVisible(false)
	Menu.Frame.btnMinim:SetVisible(false)
	Menu.Frame.btnMaxim:SetVisible(false)
	Menu.Frame.btnClose:SetVisible(false)

	Menu.Frame.Paint = function(self, Width, Height)
		self:MoveToFront()

		surface.SetDrawColor(Derama.ConfigTable["Misc.TitleBarsAndButtons.colormixer"])
		surface.DrawRect(0, 0, Width, 24)
		surface.SetDrawColor(60, 60, 60, 255)
		surface.DrawOutlinedRect(0, 0, Width, 24)
		surface.SetDrawColor(40, 40, 40)
		surface.DrawRect(0, 24, Width, Height - 24)
		surface.SetDrawColor(Derama.ConfigTable["Misc.TitleBarsAndButtons.colormixer"])
		surface.DrawOutlinedRect(0, 23, Width, Height - 23)

		draw.SimpleTextOutlined(self:GetTitle(), "Trebuchet18", 12, 24 / 2, Derama.ConfigTable["Misc.MenuText.colormixer"], TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER, 1, Color(0, 0, 0, 255 / 3))
	end

	local PropertySheet = vgui.Create("DPropertySheet", Menu.Frame)

	PropertySheet.tabScroller:SetOverlap(1)

	PropertySheet:Dock(FILL)
	PropertySheet:SetFadeTime(0)

	local OriginalAddSheet = PropertySheet.AddSheet

	PropertySheet.AddSheet = function(self, Label, Panel, Material, NoStretchX, NoStretchY, Tooltip)
		local Sheet = OriginalAddSheet(self, Label, Panel, Material, NoStretchX, NoStretchY, Tooltip)

		Sheet.Tab:SetTextColor(Color(0, 0, 0, 0))

		Sheet.Tab.GetTabHeight = function(self)
			return 20
		end

		Sheet.Tab.ApplySchemeSettings = function(self)
			local LeftMargin, TopMargin, RightMargin, BottomMargin = PropertySheet.tabScroller:GetDockMargin()

			self:SetSize((PropertySheet:GetWide() - LeftMargin) / #PropertySheet:GetItems(), self:GetTabHeight())

			DLabel.ApplySchemeSettings(self)
		end

		Sheet.Tab.Paint = function(self, Width, Height)
			if (self:GetText() == ActiveTab) then
				PropertySheet:SetActiveTab(self)

				ActiveTab = nil
			end

			surface.SetDrawColor(60, 60, 60, 255)
			surface.DrawOutlinedRect(0, 0, Width, Height)
			surface.SetDrawColor(Derama.ConfigTable["Misc.TitleBarsAndButtons.colormixer"])

			if (self:IsHovered()) then
				surface.SetDrawColor(40, 40, 40)
			end

			if (PropertySheet:GetActiveTab() == self) then
				surface.SetDrawColor(40, 40, 40)
			end

			surface.DrawRect(1, 1, Width - 2, Height)

			draw.SimpleTextOutlined(self:GetText(), "Trebuchet18", Width / 2, Height / 2, Derama.ConfigTable["Misc.MenuText.colormixer"], TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, Color(0, 0, 0, 255 / 3))
		end

		return Sheet
	end

	PropertySheet.Paint = function(self, Width, Height)
		surface.SetDrawColor(40, 40, 40)
		surface.DrawRect(0, 20, Width, Height - 20)
		surface.SetDrawColor(70, 70, 70, 255)
		surface.DrawOutlinedRect(0, 20, Width, Height - 20)
	end

	local AddSheet = function(Control)
		local ScrollPanel = vgui.Create("DScrollPanel", PropertySheet)

		ScrollPanel:Dock(FILL)
		ScrollPanel:DockMargin(5, 10, 10, 10)

		ScrollPanel.VBar.Paint = function(self, Width, Height)
			surface.SetDrawColor(40, 40, 40)
			surface.DrawRect(0, 0, Width, Height)
			surface.SetDrawColor(Derama.ConfigTable["Misc.TitleBarsAndButtons.colormixer"])
			surface.DrawOutlinedRect(0, 0, Width, Height)
		end

		ScrollPanel.VBar.btnUp.Paint = function(self, Width, Height)
			surface.SetDrawColor(40,40,40)

			if (self:IsHovered()) then
				surface.SetDrawColor(40,40,40)
			end

			if (self:IsDown()) then
				surface.SetDrawColor(40,40,40)
			end

			surface.DrawRect(0, 0, Width, Height)
			surface.SetDrawColor(Derama.ConfigTable["Misc.TitleBarsAndButtons.colormixer"])
			surface.DrawOutlinedRect(0, 0, Width, Height)
		end

		ScrollPanel.VBar.btnGrip.Paint = function(self, Width, Height)
			surface.SetDrawColor(Derama.ConfigTable["Misc.TitleBarsAndButtons.colormixer"])

			if (self:IsHovered()) then
				surface.SetDrawColor(Derama.ConfigTable["Misc.TitleBarsAndButtons.colormixer"])
			end

			if (self.Depressed) then
				surface.SetDrawColor(Derama.ConfigTable["Misc.TitleBarsAndButtons.colormixer"])
			end

			surface.DrawRect(0, 0, Width, Height)

			DisableClipping(true)

			surface.SetDrawColor(Derama.ConfigTable["Misc.TitleBarsAndButtons.colormixer"])
			surface.DrawOutlinedRect(0, -1, Width, Height + 2)

			DisableClipping(false)
		end

		ScrollPanel.VBar.btnDown.Paint = function(self, Width, Height)
			surface.SetDrawColor(40,40,40)

			if (self:IsHovered()) then
				surface.SetDrawColor(40,40,40)
			end

			if (self:IsDown()) then
				surface.SetDrawColor(40,40,40)
			end

			surface.DrawRect(0, 0, Width, Height)
			surface.SetDrawColor(Derama.ConfigTable["Misc.TitleBarsAndButtons.colormixer"])
			surface.DrawOutlinedRect(0, 0, Width, Height)
		end

		ScrollPanel.VBar.SetUp = function(self, BarSize, CanvasSize)
			self.BarSize = BarSize
			self.CanvasSize = math.max(CanvasSize - BarSize, 0.1)

			self:DockMargin(0, 0, 0, 0)
			self:SetEnabled(true)
			self:InvalidateLayout()
		end

		PropertySheet:AddSheet(Control.Title, ScrollPanel)

		Menu.LayoutControls(ScrollPanel, Control.Title)
	end

	for Index, Control in ipairs(Derama.LayoutTable) do
		AddSheet(Control)
	end
end

function Menu.Toggle()
	if (Util.IsButtonPressed(Derama.ConfigTable["settings.menu.button"])) then
		Menu.Render()
	end
end

function Menu.Destroy()
	if (Menu.Frame) then
		Menu.Frame:Remove()

		Menu.Frame = nil
	end
end

local function RefreshConfigs()
	if (!file.Exists(ConfigFolder, "DATA")) then
		file.CreateDir(ConfigFolder)
	end

	Derama.ConfigTable["settings.config.name"] = ""
	Derama.ConfigTable["settings.config"] = {
		Option = "",
		Options = {}
	}

	local Configs = {}
	local Files, Folders = file.Find(ConfigFolder .. "/*.vtf", "DATA")

	for Index, File in ipairs(Files) do
		File = string.Replace(File, "." .. ConfigFileExtension, "")

		table.insert(Configs, File)
	end

	Derama.ConfigTable["settings.config"].Options = Configs
end

RefreshConfigs()

local function Buttons()
	Derama.ConfigTable["settings.unload"] = function()
		for EventName, Identifier in pairs(hook.GetTable()) do
			Util.RemoveHook(EventName)
		end

		Menu.Destroy()
	end

	Derama.ConfigTable["settings.config.rename"] = function()
		local Config = string.format("%s/%s.%s", ConfigFolder, Derama.ConfigTable["settings.config"].Option, ConfigFileExtension)

		if (!file.Exists(Config, "DATA")) then
			return
		end

		file.Rename(Config, string.format("%s/%s.%s", ConfigFolder, Derama.ConfigTable["settings.config.name"], ConfigFileExtension))

		RefreshConfigs()
	end

	Derama.ConfigTable["settings.config.save"] = function()
		if (string.len(Derama.ConfigTable["settings.config.name"]) <= 0) then
			return
		end

		file.Write(string.format("%s/%s.%s", ConfigFolder, Derama.ConfigTable["settings.config.name"], ConfigFileExtension), util.TableToJSON(Derama.ConfigTable))

		RefreshConfigs()
	end

	Derama.ConfigTable["settings.config.load"] = function()
		local Config = string.format("%s/%s.%s", ConfigFolder, Derama.ConfigTable["settings.config"].Option, ConfigFileExtension)

		if (!file.Exists(Config, "DATA")) then
			return
		end

		Derama.ConfigTable = util.JSONToTable(file.Read(Config, "DATA"))

		RefreshConfigs()
		Buttons()
	end

	Derama.ConfigTable["settings.config.delete"] = function()
		local Config = string.format("%s/%s.%s", ConfigFolder, Derama.ConfigTable["settings.config"].Option, ConfigFileExtension)

		if (!file.Exists(Config, "DATA")) then
			return
		end

		file.Delete(Config)

		RefreshConfigs()
	end
end

Buttons()

--rgb function for stuff

local function rainbowshit(speed, str, font, x, y )
	
	surface.SetTextPos(x,y)
	surface.SetTextColor( HSVToColor(  ( CurTime() * speed ) % 360, 1, 1 ) )
	surface.SetFont(font)
	surface.DrawText( str )

end

local function BorderRainbow(speed,x,y,w,h)
	
	surface.SetDrawColor( HSVToColor(  ( CurTime() * speed ) % 360, 1, 1 ) )
    surface.DrawRect(x,y,w,h)

end

--[[

Visual Functions

]]

function Visuals.PlayerRelatedViews()
	if (!Derama.ConfigTable["Visuals.3DBox.checkbox"]) then
		return
	end
	
    for k,v in pairs(player.GetAll()) do
    	
    	if v == ply then
    		continue
    	end
    	
    	
    	if v:IsValid() and v:Alive() then
         	render.DrawWireframeBox( v:GetPos(),v:GetAngles(),v:OBBMins(),v:OBBMaxs(),Derama.ConfigTable["Visuals.3DBox.colormixer"], false )
    	end
    	
    end
end

function Visuals.NameESP()
	
   	if (!Derama.ConfigTable["Visuals.Name.checkbox"]) then
		return 
	end
	
    for k,v in pairs(player.GetAll()) do
    	
    	if v == ply then
    		continue
    	end
    	
    	if v:IsValid() and v:Alive() then
    	local pp = v:GetPos() + v:OBBCenter() + Vector(0,0,40)
    	local pp2 = pp:ToScreen()

    	draw.SimpleText(v:Nick(), "BudgetLabel", pp2.x, pp2.y,Derama.ConfigTable["Visuals.Name.colormixer"])
    	end
    	
    end
end

function Visuals.HealthESP()
	
   	if (!Derama.ConfigTable["Visuals.Health.checkbox"]) then
		return 
	end
	
    for k,v in pairs(player.GetAll()) do
    	
    	if v == ply then
    		continue
    	end
    	
    	if v:IsValid() and v:Alive() then
    	local pp = v:GetPos() + v:OBBCenter() + Vector(20,0,0)
    	local pp2 = pp:ToScreen()

    	draw.SimpleText(v:Health(), "BudgetLabel", pp2.x, pp2.y,Derama.ConfigTable["Visuals.Health.colormixer"])
    	end
    	
    end
end

function Visuals.ArmorESP()
	
   	if (!Derama.ConfigTable["Visuals.Armor.checkbox"]) then
		return 
	end
	
    for k,v in pairs(player.GetAll()) do
    	
    	if v == ply then
    		continue
    	end
    	
    	if v:IsValid() and v:Alive() then
    	local pp = v:GetPos() + v:OBBCenter() + Vector(20,0,20)
    	local pp2 = pp:ToScreen()

    	draw.SimpleText(v:Armor(), "BudgetLabel", pp2.x, pp2.y,Derama.ConfigTable["Visuals.Armor.colormixer"])
    	end
    	
    end
end

function Visuals.PingESP()
	
   	if (!Derama.ConfigTable["Visuals.Ping.checkbox"]) then
		return 
	end
	
    for k,v in pairs(player.GetAll()) do
    	
    	if v == ply then
    		continue
    	end
    	
    	if v:IsValid() and v:Alive() then
    	local pp = v:GetPos() + v:OBBMins() + Vector(0,0,40)
    	local pp2 = pp:ToScreen()

    	draw.SimpleText(v:Ping(), "BudgetLabel", pp2.x, pp2.y,Color(255,0,0))
        end
    
    end
end

function Visuals.Chams()
	
	local color = Derama.ConfigTable["Visuals.Chams.colormixer"]
	
   	if (!Derama.ConfigTable["Visuals.Chams.checkbox"]) then
		return 
	end
	
    for k,v in pairs(player.GetAll()) do
    	
    	if v == ply then
    		continue
    	end
    	
    	if v:IsValid() and v:Alive() then
    	cam.Start3D()
    	render.SetColorModulation(color.r / 255, color.g /255, color.b /255)
    	if Derama.ConfigTable["Visuals.Chams.Material.combobox"].Option == "DebugWhite" then
    		render.MaterialOverride(Material("models/debug/debugwhite"))
    	elseif Derama.ConfigTable["Visuals.Chams.Material.combobox"].Option == "WireFrame" then
    		render.MaterialOverride(Material("models/wireframe"))
	    elseif Derama.ConfigTable["Visuals.Chams.Material.combobox"].Option == "glow" then
    		render.MaterialOverride(Material("models/shiny"))
    	    render.SuppressEngineLighting(true)
    	end
    	v:DrawModel()
    	cam.End3D()
        end 
    end
end

function Visuals.PrinterESP()
	
	if (!Derama.ConfigTable["Visuals.PrinterESP.combobox"]) then
		return
	end
	
	
	
	for k,v in pairs(ents.GetAll()) do
		
		local shit = v:GetClass()
		
		if Printers[shit] then
			render.DrawWireframeBox(v:GetPos(), v:GetAngles(), v:OBBMins(), v:OBBMaxs(), Derama.ConfigTable["Visuals.PrinterESP.colormixer"], false)
        end
    end
	
end

function Visuals.CoinMinerESP()
	
	if (!Derama.ConfigTable["Visuals.BitcoinminerESP.combobox"]) then
		return	end
	
	
	
	for k,v in pairs(ents.GetAll()) do
		
		local shit = v:GetClass()
		
		if CoinMiners[shit] then
			render.DrawWireframeBox(v:GetPos(), v:GetAngles(), v:OBBMins(), v:OBBMaxs(), Derama.ConfigTable["Visuals.BitcoinMiner.colormixer"], false)
        end
    end
	
end

function Visuals.HandChams()
	
   	if (!Derama.ConfigTable["Visuals.Arms.Chams.combobox"]) then
		return 
	end
	
	local Color3 = Derama.ConfigTable["Visuals.Arms.Chams.colormixer"]

    render.SuppressEngineLighting(false)
    render.SetColorModulation(Color3.r / 255, Color3.g /255, Color3.b / 255)
    if Derama.ConfigTable["Visuals.Arms.Material.combobox"].Option == "DebugWhite" then
    	render.MaterialOverride(mat1)
    elseif Derama.ConfigTable["Visuals.Arms.Material.combobox"].Option == "WireFrame" then
    	render.MaterialOverride(Material("models/wireframe"))
    elseif Derama.ConfigTable["Visuals.Arms.Material.combobox"].Option == "Military Camo" then
    	render.MaterialOverride(Material("warcamo02"))
    elseif Derama.ConfigTable["Visuals.Arms.Material.combobox"].Option == "Matrix" then
    	render.MaterialOverride(Material("matrix"))
    end
    render.SetBlend(1)

end


function Visuals.WeaponChams()
	
   	if (!Derama.ConfigTable["Visuals.Weapon.Chams.combobox"]) then
		return 
	end
	
	local Color2 = Derama.ConfigTable["Visuals.Weapon.Chams.colormixer"]

    render.SuppressEngineLighting(false)
    render.SetColorModulation(Color2.r / 255, Color2.g /255, Color2.b /255)
    	    if Derama.ConfigTable["Visuals.Weapon.Material.combobox"].Option == "DebugWhite" then
    	render.MaterialOverride(mat1)
    elseif Derama.ConfigTable["Visuals.Weapon.Material.combobox"].Option == "WireFrame" then
    	render.MaterialOverride(Material("models/wireframe"))
    elseif Derama.ConfigTable["Visuals.Weapon.Material.combobox"].Option == "Military Camo" then
    	render.MaterialOverride(Material("warcamo02"))
    elseif Derama.ConfigTable["Visuals.Weapon.Material.combobox"].Option == "Matrix" then
    	render.MaterialOverride(Material("matrix"))
    end
    render.SetBlend(1)

end

function Visuals.Admin3DBox()
	
	if (!Derama.ConfigTable["Visuals.3DAdminBox.checkbox"]) then
		return
	end
	
	for k,v in pairs(GTA) do
		
		if v == ply then
		   continue
    	end
	
		if v:IsValid() and v:Alive() then
			
			if v:IsAdmin() or v:IsSuperAdmin() then
			    render.DrawWireframeBox(v:GetPos(), v:GetAngles(), v:OBBMins(), v:OBBMaxs(), Color(0, 0, 255), false)
		    end
		    
        end
    end
	
end

function Visuals.Exodiumv2Hud()
	if (!Derama.ConfigTable["Visuals.ExodiumV2.combobox"]) then
		return
	end
	
	surface.SetTextPos( 50,405)
	surface.SetTextColor( 51,240,255)
	surface.SetFont("TargetID")
	surface.DrawText("Health: "..ply:Health())
		
	surface.SetTextPos( 50,425)
	surface.SetTextColor( 51,240,255)
	surface.SetFont("TargetID")
	surface.DrawText("Armor: "..ply:Armor())
		
    surface.SetTextPos( 50,445)
	surface.SetTextColor( 174,50,170)
	surface.SetFont("TargetID")
	surface.DrawText("Server Ticks: ".. math.ceil(1 / engine.TickInterval()))
		
	surface.SetTextPos( 50,465)
	surface.SetTextColor( 174,50,170)
	surface.SetFont("TargetID")
	surface.DrawText("Player Ping: "..ply:Ping())
		
	surface.SetTextPos( 50,485)
	surface.SetTextColor( 56,50,170)
	surface.SetFont("TargetID")
	surface.DrawText("Player Fps: ".. math.ceil(1 / FrameTime()))
		
	surface.SetTextPos( 50,505)
	surface.SetTextColor( 56,50,170)
	surface.SetFont("TargetID")
	surface.DrawText("Hello: " .. ply:Nick())
		
    rainbowshit(60, "exodium overlay! v3 Edition ","TargetID", 50, 375)
    
    BorderRainbow(40,30,370,3,170)
	BorderRainbow(40,30,370,320,3)
	BorderRainbow(40,350,370,3,170)
	BorderRainbow(40,30,395,323,3)
	BorderRainbow(40,30,540,323,3)
end

function Visuals.DrugDealer()
	
	if (!Derama.ConfigTable["Visuals.DrugDealer.combobox"]) then
		return
	end
	
	for k,v in pairs(ents.GetAll()) do
		local pp = v:GetPos() + v:OBBCenter() + Vector(0,0,40)
    	local pp2 = pp:ToScreen()
        if OverAllDrugDealers[v:GetClass()] then
        	draw.SimpleText("Drug Dealer", "BudgetLabel", pp2.x, pp2.y,Color(0,0,255))
        end
	end
	
end

function Visuals.AdminGlow()
	
    if (!Derama.ConfigTable["Visuals.AdminGlow.checkbox"]) then
		return
	end
	
	for k,v in pairs(GTA) do
		if v == ply then
			continue
		end
		
		if v:IsAdmin() or v:IsSuperAdmin() then
           halo.Add( v, Color(0,0,255), 2, 9, 2, true, true )
		end

	end
	
end

function Visuals.AspectRatio()
	
	ded.SpoofedConVarSetNumber("r_aspectratio", Derama.ConfigTable["Visuals.AspectRatio.slider"])
	
end

function Visuals.ViewmodelFov()
	
	RunConsoleCommand("viewmodel_fov", Derama.ConfigTable["Visuals.ViewModel.Fov.slider"])
	
end

function Visuals.HitSoundsAndKillSounds(data)
	
	if (!Derama.ConfigTable["Visuals.HitSounds.CheckBox"]) then
		return
	end

	gameevent.Listen( "player_hurt" )
	local attacker, health, id, victim = data.attacker, data.health, data.userid, Player(data.userid)
    --Derama.ConfigTable["Visuals.HitSounds.combobox"]
    if attacker == ply:UserID() then
        if Derama.ConfigTable["Visuals.HitSounds.combobox"].Option == "Bleep" then
            surface.PlaySound("custom.wav")
        elseif Derama.ConfigTable["Visuals.HitSounds.combobox"].Option == "skeet" then
        	surface.PlaySound("skeet.wav")
        elseif Derama.ConfigTable["Visuals.HitSounds.combobox"].Option == "neverlose" then
        	surface.PlaySound("neverlose.wav")
        elseif Derama.ConfigTable["Visuals.HitSounds.combobox"].Option == "N-word" then
        	surface.PlaySound("nigga.wav")
        elseif Derama.ConfigTable["Visuals.HitSounds.combobox"].Option == "codHitMarker" then
        	surface.PlaySound("cod.wav")
		end
    end--"Visuals.KillSounds.combobox"

   if health <= 0 then
   	  if Derama.ConfigTable["Visuals.KillSounds.combobox"].Option == "Bleep" then
            surface.PlaySound("custom.wav")
        elseif Derama.ConfigTable["Visuals.KillSounds.combobox"].Option == "skeet" then
        	surface.PlaySound("skeet.wav")
        elseif Derama.ConfigTable["Visuals.KillSounds.combobox"].Option == "neverlose" then
        	surface.PlaySound("neverlose.wav")
        elseif Derama.ConfigTable["Visuals.KillSounds.combobox"].Option == "N-word" then
        	surface.PlaySound("nigga.wav")
        elseif Derama.ConfigTable["Visuals.KillSounds.combobox"].Option == "codHitMarker" then
        	surface.PlaySound("cod.wav")
        elseif Derama.ConfigTable["Visuals.KillSounds.combobox"].Option == "Warzone Armor Break" then
        	surface.PlaySound("WZ.wav")--WZ Kill
       	elseif Derama.ConfigTable["Visuals.KillSounds.combobox"].Option == "dominating" then
        	surface.PlaySound("dominating.wav")--WZ Kill
	  end
   end
end

function Visuals.NoSway(EyeAngle,OldAngle)
	
	if (!Derama.ConfigTable["Visuals.noSway.Peek"]) then
		return
	end
	
	EyeAngle = OldAngle
	
end

--[[

Aim functions

]]
function Aim.Triggerbot(cmd)
	
	if (!Derama.ConfigTable["Aim.TriggerBot.checkbox"]) then
		return
	end
	
	if input.IsKeyDown(Derama.ConfigTable["Aim.Triggerbot.binder"]) then
		
       if ply:GetEyeTrace().Entity:IsPlayer() then
       	
	   cmd:AddKey(	IN_ATTACK )
	   
	    end
		
	end
	
end


function Aim.Aimbot(cmd)
	
	if (!Derama.ConfigTable["Aim.Aimbot.checkbox"]) then
		return
	end
	
	if input.IsKeyDown(Derama.ConfigTable["Aim.binder"]) then
		--pasted:)
		for k,v in pairs(player.GetAll()) do
			
			if v == ply then
				continue
			end

			local Bones = v:GetBonePosition(v:LookupBone("ValveBiped.Bip01_Spine1"))
			local Bones2 = v:GetBonePosition(v:LookupBone("ValveBiped.Bip01_Head1"))
			local Bones3 = v:GetBonePosition(v:LookupBone("ValveBiped.Bip01_Neck1"))
		
            if Derama.ConfigTable["Aim.AimbotBones.combobox"].Option == "Spine" then
            	
            	if v:Alive() and v:IsValid()then
        	    	
     				cmd:SetViewAngles(Angle((Bones - ply:GetShootPos()):Angle()))
            	    
				end
		    elseif Derama.ConfigTable["Aim.AimbotBones.combobox"].Option == "Head" then
			    if v:Alive() and v:IsValid()then
			       		
     				cmd:SetViewAngles(Angle((Bones2 - ply:GetShootPos()):Angle()))
            	    
            	end
            elseif Derama.ConfigTable["Aim.AimbotBones.combobox"].Option == "Neck" then
        	    if v:Alive() and v:IsValid()then
			       		
     				cmd:SetViewAngles(Angle((Bones3 - ply:GetShootPos()):Angle()))
            	    
            	end
         end
         
            --More shit
        if Derama.ConfigTable["Aim.AimbotBones.combobox"].Option == "Spine" then
            	
            if Derama.ConfigTable["Aim.AimbotEnginePred.checkbox"] and v:Alive() and v:IsValid()then
                ded.StartPrediction(cmd)
     			cmd:SetViewAngles(Angle((Bones - ply:GetShootPos()):Angle()))
                ded.FinishPrediction() 
			end
		    elseif Derama.ConfigTable["Aim.AimbotBones.combobox"].Option == "Head" then
            if Derama.ConfigTable["Aim.AimbotEnginePred.checkbox"] and v:Alive() and v:IsValid()then
                ded.StartPrediction(cmd)
     			cmd:SetViewAngles(Angle((Bones2 - ply:GetShootPos()):Angle()))
                ded.FinishPrediction() 
			end
            elseif Derama.ConfigTable["Aim.AimbotBones.combobox"].Option == "Neck" then
            if Derama.ConfigTable["Aim.AimbotEnginePred.checkbox"] and v:Alive() and v:IsValid()then
                ded.StartPrediction(cmd)
     			cmd:SetViewAngles(Angle((Bones3 - ply:GetShootPos()):Angle()))
                ded.FinishPrediction() 
			end
            end
        
		end

	end

end
--[[

Rage Functions

]]
--[[
--pasted from asteya":-) i think he got this from pasteware or som shi
local angSilentView = nil

function Rage.SilentAngles(pUserCmd)
    if angSilentView == nil then
        angSilentView = pUserCmd:GetViewAngles()
    end

    angSilentView = angSilentView + Angle(pUserCmd:GetMouseY() * 0.023, pUserCmd:GetMouseX() * -0.023, 0)

    angSilentView:Normalize()

    if pUserCmd:CommandNumber() == 0 then
        pUserCmd:SetViewAngles(angSilentView)
    end

    if pUserCmd:CommandNumber() ~= 0 then
        pUserCmd:SetViewAngles(Angle())
    end
end

function Rage.FixMovement(cmd)
    -- NOT NEEDED -- if me:GetActiveWeapon():GetClass() == "weapon_zm_carry" then return end
    
    local vec = Vector(cmd:GetForwardMove(), cmd:GetSideMove(), 0)
    local vel = math.sqrt(vec.x*vec.x + vec.y*vec.y)
    local mang = vec:Angle()
    local yaw = cmd:GetViewAngles().y - angSilentView.y + mang.y

    if ((cmd:GetViewAngles().p+90)%360) > 180 then
        yaw = 180 - yaw
    end

    yaw = ((yaw + 180)%360)-180
    cmd:SetForwardMove(math.cos(math.rad(yaw)) * vel)
    cmd:SetSideMove(math.sin(math.rad(yaw)) * vel)
end--still pasted from asteyas dms
]]
--[[

Misc Functions

]]
function Misc.CreditBuyer()
	
	if (!Derama.ConfigTable["Misc.CreditButer.textentry"]) then
		return
	end
	
    if Derama.ConfigTable["Misc.CreditButer.checkbox"] then
    	
    	net.Start("SMOKES_CURRENCY_EXCHANGE_DO")
        net.WriteUInt(Derama.ConfigTable["Misc.CreditButer.textentry"], 32)
        net.SendToServer()
    	
    end

	
end

function Misc.ShowHitBoxes()
	
	if (!Derama.ConfigTable["Misc.Hit.Boxes.Peek"]) then
		return
	end
	
	for k,v in pairs(GTA) do
		
		if v == ply then
			continue
		end
		
	--	ded.ConVarSetValue("cl_showhitboxes", 0 )
		
	end
	
	
end

function Misc.Screengrab()
	
	if (!Derama.ConfigTable["Misc.Screengrabed.Peek"]) then
		return
	end
	
	render.Capture = function()
		return false
	end
	
	render.CapturePixels = function()
		return false
	end
	
end
function Misc.NameChanger()
	if (!Derama.ConfigTable["Misc.NameChanger.checkbox"]) then
		return
	end
	
	ded.NetSetConVar("name", Derama.ConfigTable["Misc.NameChanger.textentry"] )
	
end
function Misc.CustomDisconnect()
	if (!Derama.ConfigTable["Misc.CustomDisconnect.checkbox"]) then
		return
	end
	
	Derma_Query(
	"Are you sure you want to disconnect?",
	"Confirmation:",
	"Yes",
    function() ded.NetDisconnect(Derama.ConfigTable["Misc.NameChanger.textentry"] ) end,
    "No",
	function() end
    )
	
end
--[[

Movement Functions

]]
function Movement.AutoJump(UserCmd)
	if (!Derama.ConfigTable["Movement.movement.autojump"]) then
		return
	end

    if (UserCmd:KeyDown(IN_JUMP) && !User:IsOnGround()) then
		UserCmd:RemoveKey(IN_JUMP)
	end
end

local function CheckUser()
	local Client = LocalPlayer()

	if (User != Client && Client != NULL) then
		User = Client
	end

	return IsValid(User)
end

local function InitializeHooks() -- Don't be creating multiple hooks with the same events
	Util.AddHook("PreRender", function()
		CheckUser()
	end)
	Util.AddHook("Tick", function()
		Menu.Toggle()
		Util.UpdateButtons()
	end)
	Util.AddHook("HUDPaint", function()
	    Visuals.NameESP()
	    Visuals.HealthESP()
	    Visuals.ArmorESP()
	    Visuals.PingESP()
	    Visuals.Chams()
	    Visuals.Exodiumv2Hud()
	    Visuals.DrugDealer()
	end)
	Util.AddHook("PreDrawHalos", function()
	    Visuals.AdminGlow()
	end)
	
	Util.AddHook("PostDrawTranslucentRenderables", function()
	    Visuals.PlayerRelatedViews()
	    Visuals.PrinterESP()
	    Visuals.CoinMinerESP()
	    Visuals.Admin3DBox()
	end)
	Util.AddHook("CalcView", function(fov,view)
		local view = {
        fov = Derama.ConfigTable["Visuals.PlayeFOV.slider"]
        }
        return view
	end)	
	Util.AddHook("PreDrawViewModel", function()
	    Visuals.WeaponChams()
	end)
	Util.AddHook("PreDrawViewModel", function()
        Visuals.WeaponChams()
     
	end)
	Util.AddHook("PreDrawPlayerHands", function()
	    Visuals.HandChams()
	end)
	Util.AddHook("CalcViewModelView", function(EyeAngle,OldAngle)
        Visuals.NoSway(EyeAngle,OldAngle)
	end)
	Util.AddHook("player_hurt", function(data)
	    Visuals.HitSoundsAndKillSounds(data)
	end)

	Util.AddHook("CreateMove", function(UserCmd, ang)
		Misc.Screengrab()
		Misc.ShowHitBoxes()
		Misc.NameChanger()
		Aim.Aimbot(UserCmd)
		Misc.CreditBuyer()
		Visuals.AspectRatio()
		Aim.Triggerbot(UserCmd)
		Visuals.ViewmodelFov()
		if (UserCmd:CommandNumber() != 0) then -- Predicted so we don't get any hiccups.
			Movement.AutoJump(UserCmd)
		end
	end)
end

local orequire = require

require = function(File)
	orequire(File)

	if (File:find("gamemode") && istable(gamemode)) then
		InitializeHooks()
	end
end

if (CheckUser()) then
	InitializeHooks()
end

print("Exodium loaded!")