--[[
	CS-36893623615
	Price | (STEAM_0:1:23847828)
	===BootyBucket===
]]

/////////////////////////////////////
/// Title: AB ///
/// Coder: EthanTheGreat ///
/////////////////////////////////////
///© 2010 - 3010 Ethan's Worthshop///
/////////////////////////////////////
/// Blah blah blah I don't ///
///honestly care about this script///
/// so take it if you have the ///
/// skillz bitch! ///
/////////////////////////////////////




/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
------------------------------------------------- Client ConVars ----------------------------------------------------
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
CreateClientConVar( "ab_settings_aimbot_friendlyfire", 0, false, false )
CreateClientConVar( "ab_settings_aimbot_steamfriendsfire", 1, false, false )
CreateClientConVar( "ab_settings_aimbot_lossofsight", 1, false, false )
CreateClientConVar( "ab_settings_aimbot_antisnaptoggle", 1, false, false )
CreateClientConVar( "ab_settings_aimbot_antisnapvalue", 8, false, false )
CreateClientConVar( "ab_settings_aimbot_fieldofviewtoggle", 1, false, false )
CreateClientConVar( "ab_settings_aimbot_fieldofviewvalue", 80, false, false )
CreateClientConVar( "ab_settings_aimbot_fieldofviewdrawtoggle", 1, false, false )
CreateClientConVar( "ab_settings_aimbot_humanizeadjusttoggle", 1, false, false )
CreateClientConVar( "ab_settings_aimbot_humanizeadjustvalue_x", 1, false, false )
CreateClientConVar( "ab_settings_aimbot_humanizeadjustvalue_y", 1, false, false )
CreateClientConVar( "ab_settings_aimbot_humanizeadjustvalue_speed", 1, false, false )
CreateClientConVar( "ab_settings_shootonsighttoggle", 1, false, false )
CreateClientConVar( "ab_settings_aimbot_attacknpcs", 0, false, false )



/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
------------------------------------------------- Varibles, & Bools, etc... -----------------------------------------
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
local AB_Aimbot_WhiteList = { }
local AB_Aimbot_HumanizeAdjustment_Angles = { }

local HumanizeAdjustPositiveX = true; local HumanizeAdjustPositiveY = true; local HumanizeAdjustMaxNumX = 0; local HumanizeAdjustMaxNumY = 0;

local function IsNumPos( num ) if num >= 0 then return true else return false end end
local function IsNumInRange( num, min, max ) if num >= min and num <= max then return true else return false end end
local AttackOnSightToggle = false; local AutoFireHasBeenEnabled = false; local AimbotEnabled = false;

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
------------------------------------------------- AB Base Code ------------------------------------------------------
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
------[[ Bulk Of AB Aimbot ]]------
local ModelHeadBones = {
 ["models/zombie/classic.mdl"] = "ValveBiped.HC_Body_Bone" ,
 ["models/zombie/fast.mdl"] = "ValveBiped.HC_BodyCube",
 ["models/zombie/poison.mdl"] = "ValveBiped.Bip01_Spine4" , 
}

local function ReturnTargetHeadPos( ply )
 if ply:IsPlayer( ) then
 for model, bone in pairs( ModelHeadBones ) do
 if model == ply:GetModel( ) then
 return ply:GetBonePosition( ply:LookupBone( bone ) ) + Vector( 0, 0, 3 )
 else
 return ply:GetBonePosition( ply:LookupBone( "ValveBiped.Bip01_Head1" ) ) - Vector( 0, 0, 3 )
 end
 end
 elseif ply:IsNPC( ) then
 return ply:GetBonePosition( ply:LookupBone( "Bip01 Head" ))
 end
end

local function IsPlayerAcceptableAsATarget( ply )
 if ply == nil then return end
 if ply:Alive( ) and ply:GetObserverMode( ) == OBS_MODE_NONE and ply != LocalPlayer( ) then
 local IsPlayerAcceptable = true
 for _, w_ply in pairs( AB_Aimbot_WhiteList ) do
 if w_ply == ply then
 IsPlayerAcceptable = false
 end
 end
 if GetConVarNumber( "ab_settings_aimbot_friendlyfire" ) == 0 then
 if LocalPlayer( ):Team( ) == ply:Team( ) then
 IsPlayerAcceptable = false
 end
 end
 if GetConVarNumber( "ab_settings_aimbot_steamfriendsfire" ) == 0 then
 if ply:GetFriendStatus( ) == "friend" then IsPlayerAcceptable = false end
 end


 if GetConVarNumber( "ab_settings_aimbot_lossofsight" ) == 1 then
 local TraceFromLocalPlayerHPtoPlayerHP = util.TraceLine( { start = ReturnTargetHeadPos( LocalPlayer( ) ), endpos = ReturnTargetHeadPos( ply ), mask = 1174421507,filter = { LocalPlayer( ), ply } } )
 if TraceFromLocalPlayerHPtoPlayerHP.Hit then if !TraceFromLocalPlayerHPtoPlayerHP.Entity != ply then IsPlayerAcceptable = false end end
 end
 if GetConVarNumber( "ab_settings_aimbot_fieldofviewtoggle" ) == 1 then
 local ScreenPositionXIsInRange = IsNumInRange( ReturnTargetHeadPos( ply ):ToScreen( ).x, ( ScrW( ) * ( 1 - ( GetConVarNumber( "ab_settings_aimbot_fieldofviewvalue" ) * 0.01 ) ) ), ( ScrW( ) * ( GetConVarNumber( "ab_settings_aimbot_fieldofviewvalue" ) *0.01 ) ))
 local ScreenPositionYIsInRange = IsNumInRange( ReturnTargetHeadPos( ply ):ToScreen( ).y, ( ScrH( ) * ( 1 - ( GetConVarNumber( "ab_settings_aimbot_fieldofviewvalue" ) * 0.01 ) ) ), ( ScrH( ) * ( GetConVarNumber( "ab_settings_aimbot_fieldofviewvalue" ) * 0.01 ) ))
 if !( ScreenPositionXIsInRange and ScreenPositionYIsInRange ) then IsPlayerAcceptable = false end
 end
 
 if !ply:Alive( ) then IsPlayerAcceptable = false end
 if ply:GetObserverMode( ) != OBS_MODE_NONE then IsPlayerAcceptable = false end
 if ply == LocalPlayer( ) then IsPlayerAcceptable = false end
 if IsPlayerAcceptable then return true else return false end
 end
end

local function ReturnAllEligibleTargets( )
 local ActiveTargets = { }
 for _, ply in pairs( player.GetAll( ) ) do
 if IsPlayerAcceptableAsATarget( ply ) and ply:Alive( ) then table.insert( ActiveTargets, ply ) end
 end
 if GetConVarNumber( "ab_settings_aimbot_attacknpcs" ) == 1 then
 for _, npc in pairs( ents.FindByClass( "npc_*" ) ) do
 if GetConVarNumber( "ab_settings_aimbot_lossofsight" ) == 1 then
 local TraceFromLocalPlayerHPtoPlayerHP = util.TraceLine( { start = ReturnTargetHeadPos( LocalPlayer( ) ), endpos = ReturnTargetHeadPos( npc ), mask = 1174421507,filter = { LocalPlayer( ), npc } } )
 if !TraceFromLocalPlayerHPtoPlayerHP.Hit then table.insert( ActiveTargets, npc ) end
 end
 end
 end
 return ActiveTargets
end

local function ReturnClosestTargetToCrossHair( )
 local LocalPlayerAnglePosition = LocalPlayer( ):EyePos( )
 local LocalPlayerAngleView = LocalPlayer( ):GetAimVector( )
 local TargetInformation = { 0, 0 }
 for _, ply in pairs( ReturnAllEligibleTargets( ) ) do
 local TargetAnglePosition = ply:EyePos( )
 local DistanceToCH = math.abs( ( ( TargetAnglePosition - LocalPlayerAnglePosition ):Normalize( ) - LocalPlayerAngleView ):Length( ) )
 if DistanceToCH < TargetInformation[2] or TargetInformation[1] == 0 then
 TargetInformation = { ply, DistanceToCH }
 end
 end
 if TargetInformation[1] == 0 then
 return false
 else
 return TargetInformation[1]
 end
end

local function ReturnAngleToSnap( ang )
 if GetConVarNumber( "ab_settings_aimbot_humanizeadjusttoggle" ) == 1 then
 end
 if GetConVarNumber( "ab_settings_aimbot_antisnaptoggle" ) == 0 then return ang end
 local Pitch = math.ApproachAngle( math.NormalizeAngle( LocalPlayer( ):EyeAngles( ).p ), math.NormalizeAngle( ang.p ), GetConVarNumber( "ab_settings_aimbot_antisnapvalue" ))
 local Yaw = math.ApproachAngle( math.NormalizeAngle( LocalPlayer( ):EyeAngles( ).y ), math.NormalizeAngle( ang.y ), GetConVarNumber( "ab_settings_aimbot_antisnapvalue" ));
 return Angle( Pitch, Yaw, 0 )
end

local function AimLocalPlayerToTarget( )
 if !ReturnClosestTargetToCrossHair( ) then RunConsoleCommand( "-attack" ) return end
 local AngleToSnap = ReturnAngleToSnap(( ReturnTargetHeadPos( ReturnClosestTargetToCrossHair( )) - LocalPlayer( ):GetShootPos( ) ):Angle( ))
 LocalPlayer( ):SetEyeAngles( AngleToSnap )
end


------[[ Adjust Camera To Target ]]------
local function CameraAdjustToSnapToTarget( ply, pos, ang, fov )
 if !ReturnClosestTargetToCrossHair( ) then return end
 local CameraInformation = { origin = pos, angles = ReturnAngleToSnap( ( ReturnTargetHeadPos( ReturnClosestTargetToCrossHair( ) ) - LocalPlayer( ):GetShootPos( ) ):Angle( ) ), fov = fov }
 return CameraInformation
end


------[[ Field Of View Draw ]]------
local function DrawRangeOfTargetsForFOV( )
 if GetConVarNumber( "ab_settings_aimbot_fieldofviewdrawtoggle" ) == 1 then
 local OutlinedRectPosX = ( ScrW( ) * math.abs( 1 - ( GetConVarNumber( "ab_settings_aimbot_fieldofviewvalue" ) * 0.01 ))); local OutlinedRectPosY = ( ScrH( ) * math.abs( 1 - ( GetConVarNumber( "ab_settings_aimbot_fieldofviewvalue" ) * 0.01 ))); 
 local OutlinedRectSizeX = ( ( ScrW( ) * ( GetConVarNumber( "ab_settings_aimbot_fieldofviewvalue" ) * 0.01 ) ) - ( ScrW( ) * math.abs( 1 - ( GetConVarNumber( "ab_settings_aimbot_fieldofviewvalue" ) * 0.01 ))))
 local OutlinedRectSizeY = ( ( ScrH( ) * ( GetConVarNumber( "ab_settings_aimbot_fieldofviewvalue" ) * 0.01 ) ) - ( ScrH( ) * math.abs( 1 - ( GetConVarNumber( "ab_settings_aimbot_fieldofviewvalue" ) * 0.01 ))))
 
 surface.SetDrawColor( 255, 255, 255, 100 )
 surface.DrawOutlinedRect( OutlinedRectPosX, OutlinedRectPosY, OutlinedRectSizeX, OutlinedRectSizeY )
 end
end



/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
------------------------------------------------- AB Ties Code ------------------------------------------------------
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
concommand.Add( "+ab_aim", function( )
 AimbotEnabled = true
 hook.Add( "Think", "AimLocalPlayerToTarget", AimLocalPlayerToTarget )
 hook.Add( "CalcView", "CameraAdjustToSnapToTarget", CameraAdjustToSnapToTarget )
 hook.Add( "HUDPaint", "DrawRangeOfTargetsForFOV", DrawRangeOfTargetsForFOV )
end )
concommand.Add( "-ab_aim", function( )
 AimbotEnabled = false
 hook.Remove( "Think", "AimLocalPlayerToTarget" )
 hook.Remove( "CalcView", "CameraAdjustToSnapToTarget" )
 hook.Remove( "HUDPaint", "DrawRangeOfTargetsForFOV" )
end )
concommand.Add( "ab_aimbot_whitelist", function( lpply, cmd, args )
 local PlayerHasBeenAddedOrRemoved = false
 for _, ply in pairs( player.GetAll( ) ) do
 if string.find( string.lower( ply:Name( ) ), string.lower( args[1] ) ) then
 local IsPlayerAddedToWhiteList = false;
 for w_plyindex, w_ply in pairs( AB_Aimbot_WhiteList ) do if w_ply == ply then IsPlayerAddedToWhiteList = true end end
 if ply == LocalPlayer( ) then lpply:ChatPrint( "AB - You cannot add yourself!" ) return end
 if !IsPlayerAddedToWhiteList then
 lpply:ChatPrint( "AB - Player " .. ply:Name( ) .. " has been added!" )
 table.insert( AB_Aimbot_WhiteList, ply )
 PlayerHasBeenAddedOrRemoved = true
 else
 lpply:ChatPrint( "AB - Player " .. ply:Name( ) .. " has been removed!" )
 table.remove( AB_Aimbot_WhiteList, w_plyindex )
 PlayerHasBeenAddedOrRemoved = true
 end
 end
 end
 if !PlayerHasBeenAddedOrRemoved then lpply:ChatPrint( "AB - Sorry, the players name you have entered doesn't exist!" ) end
end )
hook.Add( "Think", "ShootOnSight", function( )
 local traceInfo = util.GetPlayerTrace( LocalPlayer( )); traceInfo.mask = 1174421507;
 if AimbotEnabled and GetConVarNumber( "ab_settings_shootonsighttoggle" ) == 1 and util.TraceLine( traceInfo ).Entity == ReturnClosestTargetToCrossHair( ) then
 if !ReturnClosestTargetToCrossHair( ) then RunConsoleCommand( "-attack" ) end
 if !AutoFireHasBeenEnabled then AutoFireHasBeenEnabled = true end 
 if AttackOnSightToggle then AttackOnSightToggle = false RunConsoleCommand( "-attack" ) else AttackOnSightToggle = true RunConsoleCommand( "+attack" ) end
 elseif !AimbotEnabled and GetConVarNumber( "ab_settings_shootonsighttoggle" ) == 1 and AutoFireHasBeenEnabled then
 AutoFireHasBeenEnabled = false; AttackOnSightToggle = false; RunConsoleCommand( "-attack" );
 end
end )
concommand.Add( "ab_readout", function( )
end )

