--[[
	EXECUTABLE_PATH/hvh.lua [#13076 (#13076), 3950354527, UID:66755474]
	功能 | STEAM_0:0:92257099 <188.226.158.240:27005> | [26.07.14 05:25:37PM]
	===BadFile===
]]

require"dyx"

surface.CreateFont("genericfont",{
name = "Fixedsys",
size = 14,
weight = 600,
antialias = true})

debug.getinfo = function()
	return nil
end

local me,ply,eyepos = LocalPlayer()

local getall = player.GetAll
local traceline = util.TraceLine

if not ConVarExists("herus_hs_sv_cheats") then
	me:ConCommand("hs_spoofcvar sv_cheats")
end

timer.Simple(0.1,function()
	if ConVarExists("herus_hs_sv_cheats") then RunConsoleCommand("herus_hs_sv_cheats","1") end
end)

if not ConVarExists("herus_hs_host_timescale") then
	me:ConCommand("hs_spoofcvar host_timescale")
end

if ConVarExists("herus_hs_host_timescale") then RunConsoleCommand("herus_hs_host_timescale","1") end
if ConVarExists("cl_csr_hit_effects") then RunConsoleCommand("cl_csr_hit_effects","0") end
if ConVarExists("cl_csr_extra_muzzle_flash") then RunConsoleCommand("cl_csr_extra_muzzle_flash","0") end

local Vector,Angle,Color = Vector,Angle,Color
local math,next,input = math,next,input

if not firebullets then
	firebullets = debug.getregistry().Entity.FireBullets
end

local spreads = {["weapon_pistol"] = Vector(0.01,0.01,0),
["weapon_smg1"] = Vector(0.04362,0.04362,0),
["weapon_ar2"] = Vector(0.02618,0.02618,0),}

debug.getregistry().Entity.FireBullets = function(ent,bullet)
	local wepon = me:GetActiveWeapon()
	if wepon != NULL and not spreads[wepon:GetClass()] then
		spreads[wepon:GetClass()] = bullet.Spread
	end
	return firebullets(ent,bullet)
end

local interval = engine.TickInterval()
RunConsoleCommand("cl_updaterate",1/interval)
local interp = GetConVarNumber("cl_interp_ratio") / (1/interval)

RunConsoleCommand("cl_interp",interp)
RunConsoleCommand("cl_cmdrate",GetConVarNumber("sv_maxcmdrate"))

local function insight(v,vec)
	local tr = {}
	tr.start = me:GetShootPos()
	tr.endpos = vec
	tr.mask = 1174421507
	tr.filter = {v,me}
	local trace = traceline(tr)
	return trace.Fraction == 1
end

local function transform(a,x)
	local b = Vector(0,0,0)
	local m1,m2,m3 = x[1],x[2],x[3]
	local vec1 = Vector(m1[1],m1[2],m1[3])
	local vec2 = Vector(m2[1],m2[2],m2[3])
	local vec3 = Vector(m3[1],m3[2],m3[3])
	b.x = a:Dot(vec1) + m1[4]
	b.y = a:Dot(vec2) + m2[4]
	b.z = a:Dot(vec3) + m3[4]
	return b
end

local function predict(v,vec)
	local velocity = ((v:GetVelocity() * interval) * 2)
	local lp = (me:GetVelocity() * interval)
	local predicted = velocity - lp
	predicted.z = predicted.z - (GetConVarNumber("sv_gravity") * 0.5 * FrameTime())
	predicted.z = predicted.z + (me:GetVelocity().z * FrameTime())
	return vec + ((predicted * FrameTime()) * interp)
end

local function position(v)
	local pos = v:LocalToWorld(v:OBBCenter())
	pos = insight(v,pos) and pos
	local hitgroup = string.find(v:GetModel(),"combine") and 1 or 0
	local bone = v:GetHitBoxBone(hitgroup,0)
	if not bone then return pos end
	if not v:GetBonePosition(bone) then return pos end
	local matrix = v:GetBoneMatrix(bone)
	if not matrix then return pos end
	local min,max = v:GetHitBoxBounds(hitgroup,0)
	matrix = matrix:ToTable()
	min = transform(min,matrix)
	max = transform(max,matrix)
	pos = (min + max) * 0.5
	if not insight(v,pos) then return end
	return predict(v,pos)
end

local function valid(v)
	if not input.IsKeyDown(KEY_T) then return false end
	if v == me then return false end
	if v:Health() < 1 then return false end
    if v.Whitelisted then return false end
	if _nyx.IsDormant(v:EntIndex()) then return false end
 //	if v:GetFriendStatus() == "friend" then return false end
	//if v:GetNWString("usergroup") != "user" then return false end
	//if v:Team() == me:Team() then return false end
	if v:GetColor().a < 255 then return false end
	if v:InVehicle() then return false end
	if not v:GetMoveType() == bit.bor(2,8) then return false end
	return true
end

for k,v in pairs(player.GetAll()) do
        if v.Whitelisted == nil then
                v.Whitelisted = false
        end
end
 
 
local function shitlist()
        local frame = vgui.Create("DFrame")
        frame:SetSize(500,500)
        frame:Center()
        frame:MakePopup()
        frame:SetTitle("RAZ v2 || Shitlist")
 
        local list1 = vgui.Create("DListView")
        list1:SetParent(frame)
        list1:SetPos(5, 40)
        list1:SetSize(230, 450)
        list1:SetMultiSelect(false)
        list1:AddColumn("Name")
        list1:AddColumn("SteamID")
 
        local list2 = vgui.Create("DListView")
        list2:SetParent(frame)
        list2:SetPos(260, 40)
        list2:SetSize(230, 450)
        list2:SetMultiSelect(false)
        list2:AddColumn("Name")
        list2:AddColumn("SteamID")
 
        local label = vgui.Create("DLabel")
        label:SetParent(frame)
        label:SetPos(80,25)
        label:SetText("Not on whitelist")
        label:SizeToContents()
 
        local label2 = vgui.Create("DLabel")
        label2:SetParent(frame)
        label2:SetPos(350,25)
        label2:SetText("On whitelist")
        label2:SizeToContents()
 
        local at = vgui.Create("DButton",frame)
        at:SetSize(20,20)
        at:SetPos(240,250)
        at:SetText("+")
        at.DoClick = function()
                if list1:GetSelectedLine() != nil then
                        local i1 = list1:GetLine(list1:GetSelectedLine()):GetValue(2)
                        local i2 = list1:GetLine(list1:GetSelectedLine()):GetValue(1)
                        for k,v in pairs(player.GetAll()) do
                                if v:Name() == i2 then
                                        if !(v.Whitelisted) then
                                                v.Whitelisted = true
                                                list1:RemoveLine(list1:GetSelectedLine())
                                                list2:AddLine(i2, i1)
                                        end
                                end
                        end
                end
        end
 
        local rm = vgui.Create("DButton",frame)
        rm:SetSize(20,20)
        rm:SetPos(240,270)
        rm:SetText("-")
        rm.DoClick = function()
                if list2:GetSelectedLine() != nil then
                        local i1 = list2:GetLine(list2:GetSelectedLine()):GetValue(2)
                        local i2 = list2:GetLine(list2:GetSelectedLine()):GetValue(1)
                        for k,v in pairs(player.GetAll()) do
                                if v:Name() == i2 then
                                        if (v.Whitelisted) then
                                                v.Whitelisted = false
                                                list2:RemoveLine(list2:GetSelectedLine())
                                                list1:AddLine(i2, i1)
                                        end
                                end
                        end
                end
        end
 
 
        for k,v in pairs(player.GetAll()) do
                if !(v:SteamID() == LocalPlayer():SteamID()) then
                        if !(v.Whitelisted) then
                                list1:AddLine(v:Name(), v:SteamID())
                        else
                                list2:AddLine(v:Name(), v:SteamID())
                        end
                end
        end
end
 
_G.concommand.Add("whitelist", shitlist)

local function targets()
	local dist1 = 2147483647
	for k,v in next, getall() do
		if not valid(v) then continue end
		local pos = position(v)
		if not pos then continue end
		local dist2 = (me:GetPos() - v:GetPos()):LengthSqr()
		if dist1 < dist2 then continue end
		dist1 = dist2
		ply = v
		eyepos = pos
	end
end

local function hl2()
	local wepon = me:GetActiveWeapon()
	if wepon == NULL then return false end
	local class = wepon:GetClass()
	if class == "weapon_pistol" then return true end
	if class == "weapon_357" then return true end
	if class == "weapon_smg1" then return true end
	if class == "weapon_ar2" then return true end
	return false
end

local function punch()
	local wepon = me:GetActiveWeapon()
	if wepon == NULL then return Angle() end
	if string.find(string.lower(wepon:GetClass()), "fas2") or hl2() then
		return me:GetPunchAngle()
	end
	return Angle()
end

local function automatic()
	local wepon = me:GetActiveWeapon()
	if wepon == NULL then return false end
	if not wepon.Primary then return false end
	if hl2() then return false end
	if wepon:GetClass() == "gmod_tool" then return true end
	return not wepon.Primary.Automatic
end

local fire
local ms = Angle()
local spin = Angle()

local function aimbot(c)
	me.voice_battery = 100
	ms = ms + Angle(c:GetMouseY() * 0.023,-c:GetMouseX() * 0.023,0)
	ms.p = math.Clamp(ms.p,-89,89)
	if c:CommandNumber() == 0 then
		c:SetViewAngles(ms)
		return
	end
	local ang = ms
	local wepon = me:GetActiveWeapon()// - punch()
	ply = nil
	targets()
	if ply then
		ang = (eyepos - me:GetShootPos()):Angle()
		c:SetButtons(c:GetButtons() + 1)
	end
	ang = _nyx.RemoveSpread(c,ang,(wepon != NULL and spreads[wepon:GetClass()]) and -spreads[wepon:GetClass()] or Vector()):Angle()
	ang.p = ang.p > 180 and ang.p - 360 or ang.p
	ang.r = 0
	c:SetViewAngles(ang)
	if me:GetMoveType() == 2 then
		local side = Vector(c:GetForwardMove(), c:GetSideMove(), 0)
		side = ((side:GetNormal()):Angle() + (c:GetViewAngles() - Angle(0,ms.y,0))):Forward() * side:Length()
		c:SetForwardMove(side.x)
		c:SetSideMove(side.y)
		_nyx.Bunnyhop(c,me:OnGround())
	end
	if c:KeyDown(1) and automatic() then
		if not fire then c:SetButtons(c:GetButtons() - 1) end
		fire = not fire
	end
	//c:SetMouseWheel(1337)
end
hook.Add("CreateMove","QTTUKVYFBC",aimbot)

local function calc(ply,origin,angles)
	local view = {}
	view.angles = ms
	view.vm_angles = ms
	view.origin = origin //- (ms:Forward()*180)
	view.fov = 90
	return view
end
hook.Add("CalcView","ROCHHOFXPF",calc)

hook.Add("ShouldDrawLocalPlayer","shoulddrawyourmom",function()
	return false
end)

local SimpleText = draw.SimpleText
local GetColor = team.GetColor

local w,h = ScrW()*0.5,ScrH()*0.5

local function paint()
	local pos = 0
	for k,v in next, getall() do
		if v == me then continue end
		//me:ConCommand("ulx psay "..v:Name().." noob")
		if v:GetObserverTarget() == me and v:GetObserverMode() == bit.bor(OBS_MODE_IN_EYE,OBS_MODE_CHASE) then
			local typ = v:GetObserverMode() == OBS_MODE_IN_EYE and "[FP] " or "[TP] "
			SimpleText(v:Name(),"TargetIDSmall",w,h+pos,v:IsAdmin() and Color(255,0,0) or Color(0,255,0))
			pos = pos + 15
		end
		local obb = (v:LocalToWorld(v:OBBCenter()) + Vector(0,0,10)):ToScreen()
		SimpleText(v:Name(),"TargetIDSmall",obb.x,obb.y,v:Health() < 1 and Color(0,0,0) or GetColor(v:Team()))
	end
	surface.SetDrawColor(Color(80,180,115))
	surface.DrawLine(w-1,h,w-1,h-10)
	surface.DrawLine(w-1,h,w-1,h+10)
	surface.DrawLine(w,h,w-10,h)
	surface.DrawLine(w,h,w+10,h)
end
hook.Add("HUDPaint","PWBISYKVYS",paint)

local DrawLine = render.DrawLine

local function gay()
	for k,v in next, getall() do
		if v == me then continue end
		if v:Health() < 1 then continue end
		local mins,maxs = v:WorldSpaceAABB()
		local hp = Color(0,0,0)
		hp.r = -v:Health() * 2.55
		hp.g = v:Health() * 2.55
		DrawLine(mins,Vector(mins.x,mins.y,maxs.z),hp)
		DrawLine(maxs,Vector(maxs.x,maxs.y,mins.z),hp)
		DrawLine(Vector(maxs.x,mins.y,mins.z),Vector(maxs.x,mins.y,maxs.z),hp)
		DrawLine(Vector(mins.x,maxs.y,mins.z),Vector(mins.x,maxs.y,maxs.z),hp)
		DrawLine(mins,Vector(mins.x,maxs.y,mins.z),hp)
		DrawLine(mins,Vector(maxs.x,mins.y,mins.z),hp)
		DrawLine(Vector(mins.x,maxs.y,mins.z),Vector(maxs.x,maxs.y,mins.z),hp)
		DrawLine(Vector(maxs.x,mins.y,mins.z),Vector(maxs.x,maxs.y,mins.z),hp)
		DrawLine(maxs,Vector(mins.x,maxs.y,maxs.z),hp)
		DrawLine(maxs,Vector(maxs.x,mins.y,maxs.z),hp)
		DrawLine(Vector(maxs.x,mins.y,maxs.z),Vector(mins.x,mins.y,maxs.z),hp)
		DrawLine(Vector(mins.x,maxs.y,maxs.z),Vector(mins.x,mins.y,maxs.z),hp)
	end
end
hook.Add("PostDrawOpaqueRenderables","XKRMEECZHW",gay)

local nametime = 0
local change

local name = me:Name()
local namechange = false

local function think()
	if input.IsKeyDown(KEY_F5) and change then
		namechange = not namechange
		change = false
	end
	if not input.IsKeyDown(KEY_F5) then change = true end
	if namechange and nametime < RealTime() then
		local k = player.GetAll()
		for i=1,#k do
			local v = k[math.random(#k)]
			if string.find(me:Name(),v:Name()) == nil then
				me:ConCommand("hs_namechange "..v:Name().." ")
				break
			end
		end
		nametime = RealTime() + GetConVarNumber("sv_namechange_cooldown_seconds")
	end
end
hook.Add("Think","LUXVRYHOULU",think)

concommand.Add("admens",function()
	for k,v in next, player.GetAll() do
	local usergroup = v:GetNWString("usergroup")
		if string.len(usergroup) > 0 and usergroup != "user" and usergroup != "Guest" then
			print(v:Name()..": "..usergroup)
		end
	end
end)

//notification.AddLegacy = function() end

concommand.Add("owned",function()
	//for i=1,10 do
		for k,v in next, player.GetAll() do
			net.Start('PS_SendPoints')
			net.WriteEntity(v)
			net.WriteInt(0, 32)
			net.SendToServer()
		end
	//end
end)

concommand.Add("motdownage",function()
timer.Create("timerownage",0.01,0,function()
me:ConCommand("ulx motd")
end)
end)