// Starter Steuef

surface.PlaySound ("startup1.wav")
LocalPlayer():ChatPrint("Yeesawn Private Hack Version 2.5 Has Loaded!\n")
MsgC( Color( 0, 255, 102 ), "Menu Loaded!\n" )
LocalPlayer():ChatPrint("Check Console for details!\n")
MsgC( Color( 0, 255, 102 ), "Aimbot Loaded Hold ALT to toggle!\n" )
MsgC( Color( 0, 255, 102 ), "Enjoy the new menu! \n" )
chat.AddText( Color( 255, 0, 0, 0 ), "T", Color( 255, 0, 102, 0 ), "h", Color( 255, 0, 153, 0 ), "a", Color( 102, 51, 204, 0 ), "n", Color( 102, 51, 204, 0 ), "k", Color( 204, 102, 153, 0 ), "s ", Color( 255, 200, 200, 255 ), "F", Color( 255, 153, 0, 0 ), "o", Color( 0, 0, 255, 0 ), "r ", Color( 0, 102, 204, 0 ), "U", Color( 160, 200, 200, 255 ), "s", Color( 204, 0, 0, 0 ), "i", Color( 12, 54, 200, 255 ), "n", Color( 140, 240, 200, 215 ), "g ", Color( 255, 153, 255, 0 ), "Y", Color( 255, 153, 255, 0 ), "e", Color( 255, 153, 255, 0 ), "e", Color( 255, 153, 255, 0 ), "s", Color( 255, 153, 255, 0 ), "a", Color( 255, 153, 255, 0 ), "w", Color( 255, 153, 255, 0 ), "n", Color( 255, 153, 255, 0 ), "H", Color( 255, 153, 255, 0 ), "a", Color( 255, 153, 255, 0 ), "c", Color( 255, 153, 255, 0 ), "k", Color( 255, 153, 255, 0 ), "!" )

// Menu Creation
surface.CreateFont( "yeefont", {
    font = "Default",
    extended = false,
    size = 20,
    weight = 500,
    blursize = 0,
    scanlines = 0,
    antialias = true,
    underline = false,
    italic = false,
    strikeout = false,
    symbol = false,
    rotary = false,
    shadow = false,
    additive = false,
    outline = false,
} )
 
function GetKeyPress()
    if input.IsKeyDown(KEY_INSERT) and alreadypressed == 0 then
        OpenMainMenu()
        alreadypressed = 1
    elseif input.IsKeyDown(KEY_INSERT) then
    else
        alreadypressed = 0
    end
end
hook.Add( "Think", "GetKeyPress", GetKeyPress )
 
 
local yeesawn = vgui.Create( "DFrame" )
yeesawn:SetPos( ScrW() * 0.02604166666, ScrH() * 0.04629629629 )
yeesawn:SetSize( ScrW() * 0.390625, ScrH() * 0.92592592592 )
yeesawn:Center ()
yeesawn:SetTitle( "Yeesawn Private Hack | Version 2.5!" )
yeesawn:SetVisible( true )
yeesawn:SetDraggable( false )
yeesawn:ShowCloseButton( false )
yeesawn:MakePopup( )
yeesawn.btnMaxim:Hide()
yeesawn.btnMinim:Hide()
yeesawn:SetBackgroundBlur( true )
yeesawn.Paint = function()
    surface.SetDrawColor( 50, 50, 100, 255 )
    surface.DrawRect( 0, 0, yeesawn:GetWide(), yeesawn:GetTall() )
    surface.SetDrawColor( 255, 255, 255, 255 )
    surface.DrawOutlinedRect( 0, 0, yeesawn:GetWide(), yeesawn:GetTall() )
end
yeesawn:MakePopup()
yeesawn:SetVisible(false)
OpenMainMenu = function()
    visible = !visible
    yeesawn:SetVisible(visible)
	
end
 
local yeetablol1 = vgui.Create ( "DPanel" , yeesawn )
    yeetablol1:SetPos( ScrW() * 0.00625, ScrH() * 0.0324074074 )
    yeetablol1:SetSize( ScrW() * 0.37760416666, ScrH() * 0.8824074074 )
    yeetablol1:SetVisible( true )
    yeetablol1.Paint = function(s , w , h)
   
        draw.RoundedBox(0,0,0,w , h,Color(25, 25, 50, 255))
end


// Finally Actual Hack Code!

// Weapon Dupe
local Button = vgui.Create( "DButton", yeesawn )
Button:SetText( "Weapon Dupe" )
Button:SetTextColor( Color( 255, 255, 255 ) )
Button:SetPos( 125, 80 )
Button:SetSize( 150, 50 )
Button.Paint = function( self, w, h )
	draw.RoundedBox( 0, 0, 0, w, h, Color( 41, 128, 185, 250 ) )
end

Button.DoClick = function()
LocalPlayer():ChatPrint("Duping......")
RunConsoleCommand("yee_wepdupe")

end
concommand.Add("yee_wepdupe", function()
	

	timer.Simple( 0.4744, function() 
		RunConsoleCommand("say", "/drop")  
	end)
	
	timer.Simple( 1.4135, function() 
		RunConsoleCommand("say", "/sleep")  
	end)
	
	timer.Simple( 7, function() 
		RunConsoleCommand("say", "/sleep")  
	end)
	
end)


// BunnyHop

local Button = vgui.Create( "DButton", yeesawn )
Button:SetText( "Bunny Hop" )
Button:SetTextColor( Color( 255, 255, 255 ) )
Button:SetPos( 125, 145 )
Button:SetSize( 150, 50 )
Button.Paint = function( self, w, h )
	draw.RoundedBox( 0, 0, 0, w, h, Color( 41, 128, 185, 250 ) )
end



Button.DoClick = function()
RunConsoleCommand("yeehop_toggle")
end

hook.Add("Think", "yeehop", function()
if yeehop then
     if (input.IsKeyDown( KEY_SPACE ) ) then
        if LocalPlayer():IsOnGround() then
            RunConsoleCommand("+jump")
            HasJumped = 1
        else
            RunConsoleCommand("-jump")
            HasJumped = 0
        end
    elseif yeehop and LocalPlayer():IsOnGround() then
        if HasJumped == 1 then
            RunConsoleCommand("-jump")
            HasJumped = 0
        end
    end
end
end)

concommand.Add("yeehop_toggle", function()
if yeehop then
    yeehop = !yeehop
    LocalPlayer():ChatPrint("YeeHop turned OFF")
else
    yeehop = !yeehop
    LocalPlayer():ChatPrint("YeeHop turned ON")
	end
end)

// yee ammo

local Button = vgui.Create( "DButton", yeesawn )
Button:SetText( "Ammo Dupe" )
Button:SetTextColor( Color( 255, 255, 255 ) )
Button:SetPos( 125, 210 )
Button:SetSize( 150, 50 )
Button.Paint = function( self, w, h )
	draw.RoundedBox( 0, 0, 0, w, h, Color( 41, 128, 185, 250 ) )
	end
	
Button.DoClick = function()
LocalPlayer():ChatPrint("Duping... Type yee_ammo_dupe into console to stop!")
RunConsoleCommand("yee_ammo_dupe")
end

local ag_toggle = 0
local hook_toggle = 0
function GenAmmo()
	lastgun = LocalPlayer():GetActiveWeapon():GetClass()
	if hook_toggle == 0 then
		hook.Add("CreateMove", "lolammo", function(cmd)
			RunConsoleCommand("darkrp", "drop")
			RunConsoleCommand("use", lastgun)
			if ag_toggle == 0 then
				cmd:SetButtons(bit.bor(cmd:GetButtons(), IN_USE))
				ag_toggle = 1
			else
				cmd:SetButtons(bit.band(cmd:GetButtons(), bit.bnot(IN_USE)))
				ag_toggle = 0
			end
		end)
		hook_toggle = 1
	else
		hook.Remove("CreateMove", "lolammo")
		hook_toggle = 0
	end
end

concommand.Add("yee_ammo_dupe", GenAmmo)

// Aimbot

local function gethead(ent)
        if ent:LookupBone("ValveBiped.Bip01_Head1") then
        local pos = ent:GetBonePosition(ent:GetHitBoxBone(0, 0))
                return pos
        end
        return ent:LocalToWorld(ent:OBBCenter())
end
 
local function aimbot(ucmd)
        local myang = LocalPlayer():GetAngles()
       
        if input.IsKeyDown(KEY_LALT) or aim == true then
                local ply = LocalPlayer()
                local target = nil;
                for k, ent in next, player.GetAll() do
                        if (!IsValid(ent) || ent:GetFriendStatus() == "friend" || ent:InVehicle() || ent == LocalPlayer() || !ent:Alive() || ent:IsNPC() || ent:Team() == TEAM_SPECTATOR) then
                                continue
                        end
 
                        local ang = (ent:GetPos() - LocalPlayer():GetPos()):Angle()
                        local angdiffy = math.abs(math.NormalizeAngle(myang.y - ang.y ))
                        local angdiffp = math.abs(math.NormalizeAngle(myang.p - ang.p ))
               
                        if (angdiffy < 10 and angdiffp < 10) then
                                target = ent
                        end
                end
                if (target != nil) then
                        local angle = (gethead(target) - LocalPlayer():GetShootPos()):Angle()
                        angle.p = math.NormalizeAngle(angle.p)
                        angle.y = math.NormalizeAngle(angle.y)
                        ucmd:SetViewAngles(Lerp(1, ucmd:GetViewAngles(), angle))
                end
        end
end
 
hook.Add("CreateMove", "bot", aimbot)

// no aimbot code

// NameTags ON
local Button = vgui.Create( "DButton", yeesawn )
Button:SetText( "Toggle Name Tags" )
Button:SetTextColor( Color( 255, 255, 255 ) )
Button:SetPos( 125, 280 )
Button:SetSize( 150, 50 )
Button.Paint = function( self, w, h )
	draw.RoundedBox( 0, 0, 0, w, h, Color( 41, 128, 185, 250 ) )
	end
	
Button.DoClick = function()
LocalPlayer():ChatPrint("Name Tags are now on!")
	RunConsoleCommand("yee_esp", 1)
end
CreateClientConVar("yee_esp", 0, true, false)
local function wallhack()
	if GetConVar("yee_esp"):GetInt() == 1 then
		for k, v in pairs (player.GetAll()) do
			local plypos = (v:GetPos() + Vector(0,0,80)):ToScreen()
			if v:IsAdmin() or v:IsSuperAdmin() then
				draw.DrawText("" ..v:Name().. "[Admin]", "TabLarge", plypos.x, plypos.y, Color(220,60,90,255), 1)
			else
				draw.DrawText(v:Name(), "Trebuchet18", plypos.x, plypos.y, Color(255,255,255), 1)
									end
								end
							end
						end
						
hook.Add("HUDPaint", "ESP", wallhack)

// MameTags  OFF

local Button = vgui.Create( "DButton", yeesawn )
Button:SetText( "Deactivate Name Tags" )
Button:SetTextColor( Color( 255, 255, 255 ) )
Button:SetPos( 125, 350 )
Button:SetSize( 150, 50 )
Button.Paint = function( self, w, h )
	draw.RoundedBox( 0, 0, 0, w, h, Color( 41, 128, 185, 250 ) )
	end
	
Button.DoClick = function()
LocalPlayer():ChatPrint("Name Tags are now off!")
	RunConsoleCommand("yee_esp", 0)
		end
		
// Flashlight Spammer ON

local Button = vgui.Create( "DButton", yeesawn )
Button:SetText( "Light Spammer ON" )
Button:SetTextColor( Color( 255, 255, 255 ) )
Button:SetPos( 125, 415 )
Button:SetSize( 150, 50 )
Button.Paint = function( self, w, h )
	draw.RoundedBox( 0, 0, 0, w, h, Color( 41, 128, 185, 250 ) )
	end
	
Button.DoClick = function()
LocalPlayer():ChatPrint("Flashlight Spam Toggled! Hold B")
RunConsoleCommand("yee_flightspam", 1)
	end

CreateClientConVar("yee_flightspam", 0)

local function flashspammer(cmd)
	if  input.IsKeyDown(KEY_B) then
		cmd:SetImpulse(100)
	end
 end


hook.Remove("CreateMove", "flashspam")

if GetConVarNumber("yee_flightspam") == 1 then
	hook.Add("CreateMove", "flashspam", flashspammer)
end

cvars.AddChangeCallback("yee_flightspam", function() 
	if GetConVarNumber("yee_flightspam") == 1 then
		hook.Add("CreateMove", "flashspam", flashspammer)
	else
		hook.Remove("CreateMove", "flashspam")
	end
end)

// Flashlight Spammer OFF

local Button = vgui.Create( "DButton", yeesawn )
Button:SetText( "Light Spammer OFF" )
Button:SetTextColor( Color( 255, 255, 255 ) )
Button:SetPos( 125, 480 )
Button:SetSize( 150, 50 )
Button.Paint = function( self, w, h )
	draw.RoundedBox( 0, 0, 0, w, h, Color( 41, 128, 185, 250 ) )
	end
	
Button.DoClick = function()
LocalPlayer():ChatPrint("Flashlight Spam Deactivated!")
RunConsoleCommand("yee_flightspam", 0)
	end
	
	// E Spam Toggle
	
local Button = vgui.Create( "DButton", yeesawn )
Button:SetText( "E Spam Toggle" )
Button:SetTextColor( Color( 255, 255, 255 ) )
Button:SetPos( 125, 545 )
Button:SetSize( 150, 50 )
Button.Paint = function( self, w, h )
	draw.RoundedBox( 0, 0, 0, w, h, Color( 41, 128, 185, 250 ) )
end

Button.DoClick = function()

RunConsoleCommand("yee_espam", 1 )
LocalPlayer():ChatPrint("E Spam Toggled! To Deactivate Type yee_espam 0 In Console!")
end

local usespam = false

concommand.Add("yee_espam", function()
    usespam = !usespam
end)
timer.Create("usespam", 0.1,0, function()

    if not usespam then return end
    
    RunConsoleCommand("+use")
    timer.Simple(0.00, function()
    RunConsoleCommand("-use")
    end)
end)

// Click Spam | To escape elastic binds
	
	local Button = vgui.Create( "DButton", yeesawn )
Button:SetText( "Click Spam" )
Button:SetTextColor( Color( 255, 255, 255 ) )
Button:SetPos( 125, 615 )
Button:SetSize( 150, 50 )
Button.Paint = function( self, w, h )
	draw.RoundedBox( 0, 0, 0, w, h, Color( 41, 128, 185, 250 ) )
end

Button.DoClick = function()
RunConsoleCommand("yee_clickspam", 1 )
LocalPlayer():ChatPrint("Click Spam Toggled")
end

local clickspam = false
concommand.Add("yee_clickspam", function()
    clickspam = !clickspam
end)
timer.Create("clickspam", 0.1,0, function()

    if not clickspam then return end
    
    RunConsoleCommand("+attack")
    timer.Simple(0.00, function()
    RunConsoleCommand("-attack")
    end)
end)

// Stupid meme
concommand.Add("__memes", function()

MsgC( Color( 244, 66, 66 ), "...ATTEMPTING TO BRUTEFORCE ULX \n" ) timer.Simple( 2, function()
MsgC( Color( 244, 66, 66 ), "Retrying" ) timer.Simple( 2, function()
MsgC( Color( 244, 66, 66 ), "." ) timer.Simple( 2, function()
MsgC( Color( 244, 66, 66 ), "." ) timer.Simple( 2, function()
MsgC( Color( 244, 66, 66 ), ".  " ) timer.Simple( 2, function()
MsgC( Color( 244, 66, 66 ), "Success! \n" ) timer.Simple( 2, function()
chat.AddText( Color( 0, 0, 0, 255 ), "(Console) ", Color( 160, 200, 200, 255 ), "added ", Color( 80, 0, 120, 255 ), "You ", Color( 160, 200, 200, 255 ), "to group ", Color( 0, 255, 0, 255 ), "superadmin" )
end)
end)
end)
end)
end)
end)
end)

// X - Ray ON
local cvar = CreateClientConVar
local getcvarnum = GetConVarNumber

	local Button = vgui.Create( "DButton", yeesawn )
Button:SetText( "Toggle ESP" )
Button:SetTextColor( Color( 255, 255, 255 ) )
Button:SetPos( 125, 685 )
Button:SetSize( 150, 50 )
Button.Paint = function( self, w, h )
	draw.RoundedBox( 0, 0, 0, w, h, Color( 41, 128, 185, 250 ) )
end

Button.DoClick = function()
LocalPlayer():ChatPrint("ESP Toggled")
RunConsoleCommand("xray", 1 )
end

shouldxray = cvar("xray", "0", false, false)
hook.Add( "HUDPaint", "xray", function()
if GetConVarNumber("xray") != 1 then return end 
	for k,v in pairs ( player.GetAll() ) do
	
	local ply = LocalPlayer()
	
	cam.Start3D(EyePos(), EyeAngles())
		render.SetColorModulation( 0, 5, 0)
		v:DrawModel()
	cam.End3D()
end
end)

// X - RAY OFF
local Button = vgui.Create( "DButton", yeesawn )
Button:SetText( "Deactivate ESP" )
Button:SetTextColor( Color( 255, 255, 255 ) )
Button:SetPos( 125, 755 )
Button:SetSize( 150, 50 )
Button.Paint = function( self, w, h )
	draw.RoundedBox( 0, 0, 0, w, h, Color( 41, 128, 185, 250 ) )
end

Button.DoClick = function()
LocalPlayer():ChatPrint("ESP Deactivated")
RunConsoleCommand("xray", 0 )
end