
--[[------------------------------------------------------
    Variables
--------------------------------------------------------]]
local g = {}
g = table.Merge(g,_G) -- some servers break table.Copy _G, workaround
g.Menu = {}

local p = LocalPlayer()
local w, h = ScrW(), ScrH()
local gradient = Material("vgui/gradient-l")
local gradient_down = Material("gui/gradient_down")
--[[------------------------------------------------------
    Detours / Protections
--[[----------------------------------------------------]]

--[[------------------------------------------------------
    Features / Options
--------------------------------------------------------]]
g.Options = {
    ["Aimbot"] = {
        {"section", "General"},
        {"section", "Accuracy"},
        {"section", "Target Selection"},
        {"section", "Hitbox Selection"},
        {"checkbox", "Accuracy", "Compensate Accuracy"},
    },
    ["Miscellaneous"] = {
        {"section", "Movement"},
        {"section", "Fake Lag"},
        {"section", "Camera"},
        {"section", "Anti-Aim"},
        {"checkbox", "Movement", "Auto-BunnyHop"},
        {"checkbox", "Movement", "Auto-Strafe"},
        {"checkbox", "Movement", "Directional"},
    },
    [ "Visuals"] = {
        {"section", "ESP"},
        {"colormixer", "ESP", "2D Boxes",},
        {"colormixer", "ESP", "Name ESP",},
        {"colormixer", "ESP", "Weapon",},
        {"checkbox", "ESP", "Box Filed",},
        {"checkbox", "ESP", "Health Bar",},
        {"checkbox", "ESP", "Skeletons",},
        {"checkbox", "ESP", "Team Colors",},
    },
}
--[[------------------------------------------------------
    Functions
--------------------------------------------------------]]
function g.Scale(i)
    return math.max(i*(ScrH()/1440),1) -- scales UI based on resolution
end
function g.AddHook(txt,func)
    -- hook.Add( txt, "QREX|" .. util.CRC(math.random( 10^4 )+SysTime()), func )
    hook.Add( txt, "QREX|"..txt, func )
end
--[[------------------------------------------------------
    Fonts
--------------------------------------------------------]]
surface.CreateFont("qrex.14",{font="Roboto Bold",size=12,weight=550,})
for i=15, 30 do
    surface.CreateFont("qrex."..i,{font="Roboto Bold",size=g.Scale(i)*1.05,weight=550,})
end
g.AddHook("OnScreenSizeChanged",function()
    for i=15, 30 do
        surface.CreateFont("qrex."..i,{font="Roboto Bold",size=g.Scale(i)*1.05,weight=550,})
    end
end )
--[[------------------------------------------------------
    Background
--------------------------------------------------------]]
local background = vgui.Create( "DFrame" )
background:SetTitle("")
background:MakePopup()
background:SetDraggable(false)
background:SetKeyboardInputEnabled(false)
background:SetSize(w,h)
background:Center()
background.Paint = function(s,w,h)
    draw.RoundedBox(0,0,0,w,h,Color(0,0,0,66))
end
local MenuHandler = vgui.Create( "DIconLayout", background )
MenuHandler:Dock(FILL)
MenuHandler:DockMargin(10,0,10,0)
MenuHandler:SetSpaceX(g.Scale(8))
MenuHandler:SetSpaceY(g.Scale(16))

--[[--------------------------------------------------------------
    VGUI Elements
----------------------------------------------------------------]]
    local Element = {}
    function Element.FindIndex( page, title )
        if !page then return end
        if title then            
            return IsValid(g.Menu[page]) and IsValid(g.Menu[page][title]) and g.Menu[page][title] or nil
        else
            return IsValid(g.Menu[page]) and g.Menu[page] or nil
        end
    end
    --[[------------------------------------------------------
        DFrame > Menu Design
    --------------------------------------------------------]]
        function Element.DScrollPanel( parent )
            if !IsValid(parent) then return end
            local DScrollPanel = vgui.Create( "DScrollPanel", parent )
            local VBar = DScrollPanel:GetVBar()
            VBar:SetWide(5)
            VBar:SetHideButtons(true)
            VBar.Paint = function(s,w,h)
                draw.RoundedBox(0,0,0,w,h,Color(26,26,26))
            end
            VBar.btnGrip.Paint = function(s,h,h)
                draw.RoundedBox(0,0,0,w,h,Color(42,42,42))
            end
            return DScrollPanel
        end
        function Element.CreateDFrame( title )
            local W, H = g.Scale(852), g.Scale(1100)

            local DFrame = vgui.Create( "DFrame", MenuHandler )
            DFrame:DockPadding(0,0,0,0)
            DFrame:SetTitle("")
            DFrame:SetDraggable(false)
            DFrame:SetSize(W,H)
            DFrame.Paint = function( s, w, h )
                surface.SetDrawColor(0,0,0)
                surface.DrawOutlinedRect(0,0,w,h,1)
            end

            local DPanel = vgui.Create( "DPanel", DFrame )
            DPanel:Dock( TOP )
            DPanel:DockMargin(1,1,1,0)
            DPanel:SetTall( g.Scale(35) )
            DPanel.Paint = function( s, w, h )
                draw.RoundedBox(0,0,0,w,h,Color(87,39,210,166))
                draw.SimpleText( title or "", "qrex.20", 4, h/2.1, Color(255,255,255), 0, 1 )
                surface.SetDrawColor(87,39,210)
                surface.DrawRect(0,h-2,w,2)
            end

            local frame_fill = vgui.Create("DPanel",DFrame)
            frame_fill:Dock(FILL)
            frame_fill:DockMargin(1,0,1,1)
            frame_fill.Paint = function(s,w,h)
                draw.RoundedBox(0,0,0,w,h,Color(28,28,28))
            end

            local Navbar = vgui.Create( "DPanel", frame_fill )
            Navbar:Dock( TOP )
            Navbar:DockMargin(4,0,4,0)
            Navbar:SetTall( g.Scale(45) )
            Navbar.Paint = function( s, w, h )
                draw.RoundedBox(0,0,0,w,h,Color(36,36,36))
                surface.SetDrawColor(42,42,42)
                surface.DrawRect(0,h-2,w,2)
            end

            local Populate = vgui.Create( "DPanel", frame_fill )
            Populate:Dock( FILL )
            Populate:DockMargin(8,8,8,8)
            Populate.Paint = nil

            local DScrollPanel = Element.DScrollPanel(Populate)
            DScrollPanel:Dock(FILL)

            local tabs = { "Aimbot", "Visuals", "Miscellaneous" }
            local selected = "Aimbot"
            for i, v in next, tabs do
                if !IsValid(Navbar) then break end

                local DIconLayout = vgui.Create( "DIconLayout", DScrollPanel )
                g.Menu[v] = DIconLayout
                DIconLayout:Dock( FILL )
                -- DIconLayout:SetSpaceX(5)
                -- DIconLayout:SetSpaceY(5)
                DIconLayout.OnMousePressed = function()
                    Element.CloseMixer()
                end

                if i != 1 then DIconLayout:SetVisible(false) end

                local DButton = vgui.Create( "DButton", Navbar )
                DButton:Dock( LEFT )
                DButton:SetText( "" )
                DButton.Think = function(s)
                    s:DockMargin(0,0,2,3)
                    s:SetWide( Navbar:GetWide()/#tabs )
                end
                DButton.Paint = function( s, w, h )
                    local hover = s:IsHovered()
                    local me = (selected == v)
                    draw.RoundedBox(0,0,0,w,h, hover and Color(55,55,55) or Color(44,44,44))
                    draw.SimpleText( v, "qrex.20", w/2, h/2, (me and Color(167,143,228)) or (hover and Color(255,255,255) or Color(255,255,255,155)), 1, 1 )
                end
                DButton.DoClick = function()
                    if selected == v then return end
                    g.Menu[selected]:SetVisible(false)
                    g.Menu[v]:SetVisible(true)
                    selected = v
                end
            end
            DFrame:ShowCloseButton(false)
        end
    --[[------------------------------------------------------
        DPanel > Section
    --------------------------------------------------------]]
        function Element.CreateSection( page, title )
            if !page or !title then return end
            local parent = Element.FindIndex(page)
            if !parent then return end
            local W, H = g.Scale(770), g.Scale(900)
        
            local DPanelSection = vgui.Create( "DPanel" )
            DPanelSection:SetSize(W*.53,H*.55)
            DPanelSection.Paint = function( s, w, h )
                draw.RoundedBox(0,0,0,w,h,Color(32,32,32))
                surface.SetDrawColor(42,42,42)
                surface.DrawOutlinedRect(0,0,w,h,1)
                surface.SetDrawColor(0,0,0)
                surface.DrawOutlinedRect(1,1,w-2,h-2,1)
            end

            local DPanel = vgui.Create( "DPanel", DPanelSection )
            DPanel:Dock( TOP )
            DPanel:DockMargin(3,3,3,5)
            DPanel:SetTall( g.Scale(25) )
            DPanel.Paint = function( s, w, h )
                surface.SetDrawColor(151,112,252,99)
                surface.SetMaterial(gradient)
                surface.DrawTexturedRect(0,0,w,h)
                surface.SetDrawColor(151,112,250)
                surface.DrawRect(0,h-2,w,2)
                draw.SimpleText( title, "qrex.18", 3, h/2, Color(255,255,255), 0, 1 )
            end

            local DScrollPanel = Element.DScrollPanel(DPanelSection)
            parent[title] = DScrollPanel
            DScrollPanel:Dock( FILL )
            DScrollPanel:DockMargin(10,8,2,2)
            DScrollPanel.OnMousePressed = function()
                Element.CloseMixer()
            end

            local VBar = DScrollPanel:GetVBar()
            VBar:SetWide(5)
            VBar:SetHideButtons(true)
            VBar.Paint = function(s,w,h)
                draw.RoundedBox(0,0,0,w,h,Color(26,26,26))
            end
            VBar.btnGrip.Paint = function( s, w, h )
                draw.RoundedBox(0,0,0,w,h,Color(42,42,42))
            end

            parent:Add(DPanelSection)

            return DScrollPanel
        end
    --[[------------------------------------------------------
        DCheckBoxLabel > CreateCheckBox
    --------------------------------------------------------]]
        function Element.CreateCheckBox( page, section, name, overwrite )
            local parent = Element.FindIndex( page, section )
            if !parent then return end

            local DCheckBoxLabel = vgui.Create( "DCheckBoxLabel", (overwrite or parent) )
            DCheckBoxLabel:Dock(TOP)
            DCheckBoxLabel:DockMargin(0,0,0,8)
            DCheckBoxLabel:SetTextColor(Color(255,255,255))
            DCheckBoxLabel:SetFont( "qrex.17" )
            DCheckBoxLabel:SetText( name )
            DCheckBoxLabel:SizeToContents()
            DCheckBoxLabel.Button.Paint = function( s, w, h )
                parent[name] = s:GetChecked()
                draw.RoundedBox(4,0,0,w,h,Color(44,44,44))
                if parent[name] then
                    draw.RoundedBox(4,0,0,w,h,Color(151,112,250))
                    draw.SimpleText( "✔", "qrex.20", w/2, h/2, Color(255,255,255), 1, 1 )
                end
            end
            DCheckBoxLabel.OnMousePressed = function()
                Element.CloseMixer()
            end
            return DCheckBoxLabel
        end
    --[[------------------------------------------------------
        DColorMixer > Color Changer
    --------------------------------------------------------]]
        function Element.CloseMixer()
            if !IsValid(Element.Mixer) then return end
            Element.Mixer:Remove()
        end
        Element.Mixer = nil
        function Element.DColorMixer( page, section, name, color )
            if !page or !section then return end
            local parent =  Element.FindIndex( page, section )
            if !parent then return end
            Element.CloseMixer()
            local x, y = input.GetCursorPos()
            local DPanel = vgui.Create( "DPanel" )
            Element.Mixer = DPanel
            DPanel:SetPos(x,y)
            DPanel:SetSize(g.Scale(200),g.Scale(200))
            DPanel:MoveToFront()
            DPanel:MakePopup()
            DPanel.Paint = function( s, w, h )
                draw.RoundedBox(0,0,0,w,h,Color(30,30,30))
                surface.SetDrawColor(42,42,42)
                surface.DrawOutlinedRect(0,0,w,h,1)
                surface.SetDrawColor(0,0,0)
                surface.DrawOutlinedRect(1,1,w-2,h-2,1)
            end
            local DColorMixer = vgui.Create( "DColorMixer", Element.Mixer )
            DColorMixer:Dock( FILL )
            DColorMixer:DockMargin(6,6,6,6)
            DColorMixer:SetPalette( false )
            DColorMixer:SetWangs( false )
            DColorMixer:SetAlphaBar( false )
            if color then DColorMixer:SetColor(color) end
            DColorMixer.Think = function(s)
                parent[name.."Color"] = s:GetColor()
            end
            return DPanel
        end
        function Element.CreateColorMixer( page, section, name )
            local parent = Element.FindIndex( page, section )
            if !parent then return end
            local DPanel = vgui.Create( "DPanel", parent )
            DPanel:Dock( TOP )
            DPanel:DockMargin(0,0,0,8)
            DPanel:SetTall( g.Scale(22) )
            DPanel.Paint = nil
            local DButton = vgui.Create( "DButton", DPanel )
            DButton:Dock(RIGHT)
            DButton:DockMargin(0,0,10,0)
            DButton:SetWide( g.Scale(65) )
            DButton:SetText( "" )
            DButton.col = nil
            DButton.Paint = function( s, w, h )
                surface.SetDrawColor(0,0,0)
                surface.DrawOutlinedRect(0,0,w,h,1)
                s.col = parent[name.."Color"] or Color(200,200,200)
                surface.SetDrawColor(s.col)
                surface.SetMaterial(gradient_down)
                surface.DrawTexturedRect(1,1,w-2,h-2)
            end
            DButton.DoClick = function(s)
                Element.CloseMixer()
                Element.DColorMixer( page, section, name, s.col )
            end
            local checkbox = Element.CreateCheckBox(page,section,name,DPanel)
            return DPanel
        end
    --[[------------------------------------------------------
        DComboBox > DropDown Boxes
    --------------------------------------------------------]]
        function Element.CreateDropDown( page, section, name, dropdown, tbl )
            if !page or section or !dropdown then return end
            local parent = Element.FindIndex( page, section )
            if !parent then return end
            tbl = tbl or {}
            local DComboBox = vgui.Create( "DComboBox", parent )
            DComboBox:Dock( TOP )
            DComboBox:DockMargin(0,10,10,8)
            DComboBox:SetTextColor(Color(255,255,255))
            DComboBox:SetFont( "qrex.18" )
            DComboBox:SetValue( dropdown )
            for k, v in pairs( tbl ) do DComboBox:AddChoice( k ) end
            DComboBox:GetChildren()[1].Paint = function( s, w, h )
                draw.SimpleText( "▼", "qrex.15", w/2, h/2, Color(194,190,190,44), 1, 1 )
            end
            DComboBox.Paint = function( s, w, h )
                surface.SetDrawColor(0,0,0)
                surface.DrawOutlinedRect(0,0,w,h,1)
                draw.RoundedBox(0,1,1,w-2,h-2,Color(44,44,44))
                DisableClipping(true)
                draw.SimpleText(name,"qrex.17",2,-h*.32,Color(255,255,255,220),0,1)
                DisableClipping(false)
            end
            DComboBox.OnMenuOpened = function( panel )
                panel:GetChildren()[2].Paint = function( s, w, h )
                    surface.SetDrawColor(0,0,0)
                    surface.DrawOutlinedRect(0,0,w,h,1)
                    draw.RoundedBox(0,1,1,w-2,h-2,Color(44,44,44))
                end
            end
            DComboBox.OnSelect = function(_,_,d)
                parent[name] = d
            end
            return DComboBox
        end
    --[[------------------------------------------------------
        DNumSlider > Sliders
    --------------------------------------------------------]]
        function Element.CreateSlider( page, section, name, min, max )
            if !page or !section then return end
            local parent = Element.FindIndex( page, section )
            if !parent then return end
            parent[name] = min

            local DNumSlider = vgui.Create( "DNumSlider", parent )
            DNumSlider:Dock( TOP )
            DNumSlider:DockMargin(-g.Scale(256),8,-g.Scale(47),8)
            DNumSlider:SetTall(5)
            DNumSlider:SetText("")
            DNumSlider:SetMin(min or 0)
            DNumSlider:SetMax(max or 0)
            DNumSlider.Slider.Paint = function( s, w, h )
                local value = tonumber( DNumSlider:GetValue() )
                surface.SetDrawColor(0,0,0)
                surface.DrawOutlinedRect(0,0,w,h,1)
                draw.RoundedBox(0,1,1,w-2,h-2,Color(55,55,55))
                surface.SetDrawColor(133,123,231)
                surface.DrawRect(1,1,w*math.Clamp(value/max,0,1)-2,h-2)
                DisableClipping( true )
                draw.SimpleText( name, "qrex.16", 0, -h*.6, Color(255,255,255,100), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER )
                draw.SimpleTextOutlined(math.ceil(value), "qrex.18", w* math.Clamp(value/max,0,1)-2, h/2+5, Color(255,255,255,100), 1, 1, 1, Color(0,0,0) )
                DisableClipping( false )
            end
            DNumSlider.OnValueChanged = function(_,i)
                parent[name] = i
            end

            DNumSlider.Slider:GetChildren()[1].Paint = nil
            DNumSlider:GetChildren()[1].Paint = nil
            
            return DNumSlider
        end

    function g.GenerateOptions()
        for k, t in SortedPairs(g.Options) do
            for kk, tt in next, t do
                local e = tt[1]
                if e == "section" then
                    Element.CreateSection(k,tt[2])
                elseif e == "checkbox" then
                    Element.CreateCheckBox(k,tt[2],tt[3],tt[4])
                elseif e == "colormixer" then
                    Element.CreateColorMixer(k,tt[2],tt[3],tt[4])
                elseif e == "dropdown" then
                    Element.CreateDropDown(k,tt[2],tt[3],tt[4],tt[5])
                elseif e == "slider" then
                    Element.CreateSlider(k,tt[2],tt[3],tt[4],tt[5])
                end
            end
        end
    end
    Element.CreateDFrame("Qrextomnia.exe");g.GenerateOptions()
--[[--------------------------------------------------------------
    VGUI Elements END
----------------------------------------------------------------]]

--[[--------------------------------------------------------------
    Lag Composition
----------------------------------------------------------------]]
    local LagComposition = {}

    function LagComposition.StoreRecord( p, simulationTime )
        local succ = bSendPacket or pcall(require,"bsendpacket")
        if !succ then return end

        if !IsValid(p) or simulationTime then return end


    end
--[[--------------------------------------------------------------
    Lag Composition END
----------------------------------------------------------------]]

--[[--------------------------------------------------------------
    Navigation Pathing
----------------------------------------------------------------]]
    local Navigation = {}

    function Navigation.PlayerPath( p )
        if !IsValid(p) then return end
        local pos = p:GetPos()
        local vel = Vector(p:GetVelocity())
        local tr = util.TraceHull({
            start = pos,
            endpos = pos+vel,
            mins = p:OBBMins(),
            maxs = p:OBBMaxs(),
            mask = MASK_PLAYERSOLID,
        })
        return tr
    end
--[[--------------------------------------------------------------
    Navigation Pathing END
----------------------------------------------------------------]]

--[[--------------------------------------------------------------
    Aimbot Targeting
----------------------------------------------------------------]]
    local Aimbot = {}
    g.EyeAngle = LocalPlayer():EyeAngles()

    g.AddHook( "InputMouseApply", function( cmd, x, y, ang )
        local m_pitch = GetConVar("m_pitch"):GetFloat()
        local m_yaw = GetConVar("m_yaw"):GetFloat()
        g.EyeAngle.pitch = g.EyeAngle.pitch + (y*m_pitch)
        g.EyeAngle.pitch = math.Clamp(math.NormalizeAngle(g.EyeAngle.pitch),-89,89)
        g.EyeAngle.yaw = g.EyeAngle.yaw - (x*m_yaw)
        g.EyeAngle.yaw = math.NormalizeAngle(g.EyeAngle.yaw)
    end )

    g.AddHook( "CalcView", function( p, _, angles )
        local aim = g.Menu["Aimbot"] and g.Menu["Aimbot"]["Accuracy"]
        if aim and aim["Compensate Accuracy"] then
            angles:Sub(p:GetViewPunchAngles())
        end
    end )
--[[--------------------------------------------------------------
    Aimbot Targeting END
----------------------------------------------------------------]]

--[[--------------------------------------------------------------
    Movement
----------------------------------------------------------------]]
    local Movement = {}
    function Movement.Bunnyhop( cmd )
        local bhop = Element.FindIndex("Miscellaneous","Movement")
        if !bhop or !bhop["Auto-BunnyHop"] then return end
        local p = LocalPlayer()
        if p:OnGround() then
            cmd:KeyDown( IN_JUMP )
        else
            cmd:RemoveKey( IN_JUMP )
        end
    end
    function Movement.AutoStrafe( cmd )
        local bhop = Element.FindIndex("Miscellaneous","Movement")
        if !bhop or !bhop["Auto-BunnyHop"] or !bhop["Auto-Strafe"] then return end
        local p = LocalPlayer()
        local vel = p:GetVelocity()
        if !p:IsOnGround() and p:GetMoveType() != MOVETYPE_NOCLIP and p:Alive() then
            cmd:SetForwardMove(5850/vel:Length2D())
            cmd:SetSideMove(cmd:CommandNumber() % 2 == 0 and -400 or 400)
        end
    end
    function Movement.DirectionalStrafe( cmd )
        local bhop = Element.FindIndex("Miscellaneous","Movement")
        if !bhop or !bhop["Directional"] then return end
        local p = LocalPlayer()
        local vel = p:GetVelocity()

        local view = g.EyeAngle -- new angles
        -- print( "Movement.DirectionalStrafe", view )
    end
    g.AddHook( "CreateMove", function( cmd )
        cmd:SetViewAngles(g.EyeAngle)
        Movement.Bunnyhop(cmd)
        Movement.AutoStrafe(cmd)
        Movement.DirectionalStrafe(cmd)
    end )
--[[--------------------------------------------------------------
    Movement END
----------------------------------------------------------------]]

local base_color = Color(200,200,200)

g.AddHook( "PostDrawOpaqueRenderables", function()
    -- local p = LocalPlayer()
    -- local path = Navigation.PlayerPath(p)
    -- local vel = p:GetVelocity()
    -- cam.Start3D()
    --     render.DrawWireframeBox( path.HitPos, p:GetAngles(), p:OBBMins(), p:OBBMaxs(), Color(255,255,255), true )
    -- cam.End3D()
end )

g.AddHook( "PostDrawHUD", function()
    local visual = Element.FindIndex("Visuals","ESP")
    if !visual then return end
    for _, pp in pairs(player.GetAll()) do
        if !IsValid(pp) then continue end
        if p == pp then continue end
        local pos = pp:GetPos()
        local min, max = pp:GetCollisionBounds()
        local pos2 = pos+Vector(0,0,max.z)
        pos, pos2 = pos:ToScreen(), pos2:ToScreen()
        local h = pos.y-pos2.y
        local w = h/2
        if visual["2D Boxes"] then
            local col = visual["2D BoxesColor"] or base_color
            if visual["Box Filed"] then
                draw.RoundedBox( 0, pos.x-w/2, pos.y-h, w, h, (col and Color(col.r,col.g,col.b,22) or Color(255,255,255,22) ) )
            end
            surface.SetDrawColor(0,0,0,255)
            surface.DrawOutlinedRect(pos.x-w/2+1,pos.y-h+1,w-2,h-2)
            surface.SetDrawColor(0,0,0,255)
            surface.DrawOutlinedRect(pos.x-w/2-1,pos.y-h-1,w+1,h+1)
            surface.SetDrawColor(col)
            surface.DrawOutlinedRect(pos.x-w/2,pos.y-h,w,h)
        end
        if visual["Name ESP"] then
            local col = visual["Name ESPColor"] or Color(255,255,255)
            draw.SimpleTextOutlined(pp:Name(),"qrex.14",pos.x,pos.y-h-(h*.03),(col and Color(col.r,col.g,col.b)),1,1,1,Color(0,0,0))
        end
        if visual["Weapon"] then
            local wep = IsValid( pp:GetActiveWeapon() ) and pp:GetActiveWeapon() or nil
            local col = visual["WeaponColor"] or Color(255,255,255)
            if wep then
                draw.SimpleTextOutlined(language.GetPhrase(wep:GetPrintName()),"qrex.14",pos.x,pos.y+(h*.03),(col and Color(col.r,col.g,col.b)),1,1,1,Color(0,0,0))
            end
        end
        if visual["Health Bar"] then
            pp.oldhp = Lerp( FrameTime() * 5, pp.oldhp or pp:Health(), pp:Health() )
            local clamp = math.Clamp( pp.oldhp/pp:GetMaxHealth(), 0, 1 )
            local c = HSVToColor( clamp*110, 1, 1 )
            local hp = h * pp.oldhp / pp:GetMaxHealth()
            if(hp > h) then hp = h end
            local diff = h-hp
            local x = pos.x-w/2-7
            local ww = 4
            surface.SetDrawColor(0,0,0,220)
            surface.DrawRect(x,pos.y-h-1,ww,(h))
            surface.SetDrawColor(c)
            surface.DrawRect(x+1,pos.y-h+1+diff,ww-2,(h-1)*clamp)
        end
        if visual["Skeletons"] then
            local pos = pp:GetPos() -- needed default pos
            for i=0, pp:GetBoneCount()-1 do
                local parent = pp:GetBoneParent(i)
                if(!parent) then continue end
                local bonepos = pp:GetBonePosition(i)
                if(bonepos == pos) then continue end
                local parentpos = pp:GetBonePosition(parent)
                if(!bonepos or !parentpos) then continue end
                local s1, s2 = bonepos:ToScreen(),parentpos:ToScreen()
                local col = visual["SkeletonsColor"] or color_white
                if visual[ "Team Colors" ] then col = team.GetColor(pp:Team()) end
                surface.SetDrawColor(col)
                surface.DrawLine(s1.x,s1.y,s2.x,s2.y)
            end
        end
    end
end )

hook.Add( "PreRender", "a", function()
    -- print(1)
end )

-- GM:PostRender()

--[[------------------------------------------------------
    Open Menu
--------------------------------------------------------]]
local toggle = false
local openKey = KEY_F2 -- F2
hook.Add( "Think", "qrex.temp", function()
    if input.IsKeyDown(openKey) and !toggle then
        toggle = true
        Element.CloseMixer()
        background:SetVisible(!background:IsVisible())
        gui.EnableScreenClicker(background:IsVisible())
    elseif !input.IsKeyDown(openKey) then
        toggle = false
    end
end )
background:ShowCloseButton(false)



-- function ib.RemapClamped(val, A, B, C, D)
--     if A == B then
--         return val >= B and D or C
--     end
--     local cval = (val - A) / (B - A)
--     cval = math.Clamp(cval, 0.0, 1.0)
--     return C + (D - C) * cval
-- end

-- local function PredictSpread(cmd, ang) -- HUGE FUCKING THANKS TO S0LUM'S NCMD (and data for helping me figure shit out)
-- 	if (me:Team() == TEAM_SPECTATOR and not gBool("Main Menu", "General Utilities", "Spectator Mode")) or not me:Alive() or me:Health() < 1 then return end
--     local wep = me:GetActiveWeapon()
-- 	if gBool("Aim Assist", "Miscellaneous", "Remove Bullet Spread") and me:GetActiveWeapon():IsValid() and me:Alive() and me:Health() > 0 then
-- 		local class = wep:GetClass()
-- 		local cone = bi.spread.Spread[class]
-- 		if not cone then return ang end
		
-- 		if class == 'weapon_pistol' then
-- 			local ramp = ib.RemapClamped(wep:GetInternalVariable('m_flAccuracyPenalty'), 0, 1.5, 0, 1)
-- 			cone = LerpVector(ramp, Vector(0.00873, 0.00873, 0.00873), Vector(0.05234, 0.05234, 0.05234))
-- 		end
-- 		local seed = ib.spread.md5.PseudoRandom(cm.CommandNumber(cmd))
-- 		local x, y = ib.spread.enginespread[seed][1], ib.spread.enginespread[seed][2]
-- 		local forward, right, up = ang:Forward(), ang:Right(), ang:Up()
-- 		local retvec = forward + (x * cone[1] * right * - 1) + (y * cone[2] * up * - 1)
-- 		local spreadangles =  retvec:Angle()
-- 		spreadangles:Normalize()
--     return spreadangles
-- 	end
-- end

