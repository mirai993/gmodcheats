local _R = debug.getregistry()
local dimarcc = RunConsoleCommand
local dimaconvar = CreateClientConVar
local Player = Player
local Entity = Entity
local lookupbone = _R.Entity.LookupBone
local getbonepos = _R.Entity.GetBonePosition
local getattach = _R.Entity.GetAttachment
local lookupattach = _R.Entity.LookupAttachment
local bonecount = _R.Entity.GetBoneCount
local toworld = _R.Entity.LocalToWorld
local obb = _R.Entity.OBBCenter
local setviewangles = _R.Player.SetViewAngles --and here because of would-be anti-cheats that don't want lowly cheaters like me around
local seteyeangles = _R.Player.SetEyeAngles
local dimaalive = _R.Player.Alive
local dimaadmin = _R.Player.IsAdmin
local dimashootpos = _R.Player.GetShootPos

local MsgC = MsgC
local dimarq = require

local dimanorm = math.NormalizeAngle
local dimaplayers = player.GetAll
local dimatraceline = util.TraceLine

dimarq("dickwrap")
dimarq('up')

MsgC(Color(0,255,0),"["..os.date("%H:%M:%S").."] Start\n")
/*
local myCCs = {}

local oldCA = concommand.Add
concommand.Add = function(name, func, ...)

myCCs[ name ] = func
return oldCA(name, func, ...)

end

local oldGT = concommand.GetTable
concommand.GetTable = function(...)

local tbl, tbl2 = oldGT(...)

for k,v in pairs(myCCs) do 

if (tbl) then tbl[k] = nil end
if (tbl2) then tbl2[k] = nil end

end

return tbl, tbl2

end
*/
local dimacca = concommand.Add
local dimaccr = concommand.Remove
local dimahka = hook.Add
local dimagetinfo = debug.getinfo
local dimavgui = vgui.Create
local dimaccv = CreateClientConVar


local Enabled = dimaccv("dima_esp_box", 1, true, false)
local boxtype = dimaccv("dima_esp_box_width", 1)
local ESPE = dimaccv("dima_esp_name", 1, true, false)
local ESPrp = dimaccv("dima_esp_name_rp",1,true,false)
local ESPlines = dimaccv("dima_esp_lines",1,true,false)
local ESPadminson = dimaccv("dima_esp_admincounter",1,true,false)



surface.CreateFont("DefaultSmallDropShadow", {
		font	= "Tahoma",
		size	= 16,
		weight	= 520,
		shadow	= true,
	}
)

surface.CreateFont("DefaultSmallDropShadow1", {
		font	= "Tahoma",
		size	= 15,
		weight	= 500,
		shadow	= false,
		outline = true,
	}
)

local function realname(ply)
	if ESPrp:GetBool() then
		return ply:Nick()
	end
return ply:Name()
end

local function halfbox()
	if boxtype:GetInt() == 1 then return
	2
elseif boxtype:GetInt() == 2 then return
	4
	end
end


local TRANS = Color(0,0,0,255)

local function DrawESP()
	--if not Enabled:GetBool() then return end
	
	local x,y,color
	local mon,nom
	local h,w
	local bot,top
	local sx,sy
	local size = 5
	
	for k,v in pairs( player.GetAll() ) do
		if not IsValid(v) or not v:Alive() or v == LocalPlayer() then
			continue
		end
		if v:Team() == TEAM_SPECTATOR or v:GetMoveType() == MOVETYPE_OBSERVER then
			continue
		end
		
		local tCol = team.GetColor( v:Team() )
		
		nom = v:GetPos()
		mon = nom + Vector( 0, 0, v:OBBMaxs().z )
		
		bot = nom:ToScreen()
		top = mon:ToScreen()
		
		h = ( bot.y - top.y )
		w = h;
		
		sx,sy = 0,0;
		
		
		// Top left
		sx = ( top.x - ( w / halfbox() ) )
		//sx = ( top.x - ( w / 4 ) )
		sy = top.y;
		
		surface.SetDrawColor(TRANS)
		
		surface.DrawRect( sx - 1, sy - 1, size + 2, 3 )
		surface.DrawRect( sx - 1, sy - 1, 3, size + 2 )
		
		surface.SetDrawColor(tCol)
		surface.DrawLine( sx, sy, sx + size, sy )
		surface.DrawLine( sx, sy, sx, sy + size )
		
		// Top right
		sx = ( top.x + ( w / halfbox() ) )
		//sx = ( top.x + ( w / 4 ) )
		sy = top.y;
	
		surface.SetDrawColor(TRANS)
		
		surface.DrawRect( sx - size, sy - 1, size + 2, 3 )
		surface.DrawRect( sx - 1, sy - 1, 3, size + 2 )
		
		surface.SetDrawColor(tCol)
		surface.DrawLine( sx, sy, sx - size, sy )
		surface.DrawLine( sx, sy, sx, sy + size )
		
		//Bottom left
		sx = ( bot.x - ( w / halfbox() ) )
		//sx = ( bot.x - ( w / 4 ) )
		sy = bot.y;
		
		surface.SetDrawColor(TRANS)
		
		surface.DrawRect( sx - 1, sy - 1, size + 2, 3 )
		surface.DrawRect( sx - 1, sy - size, 3, size + 2 )
		
		surface.SetDrawColor(tCol)
		surface.DrawLine( sx, sy, sx + size, sy )
		surface.DrawLine( sx, sy, sx, sy - size )
		
		//Bottom right
		sx = ( bot.x + ( w / halfbox() ) )
		//sx = ( bot.x + ( w / 4 ) )
		sy = bot.y;
		
		surface.SetDrawColor(TRANS)
		
		surface.DrawRect( sx - size, sy - 1, size + 2, 3)
		surface.DrawRect( sx - 1, sy - size, 3, size + 2)
		
		surface.SetDrawColor(tCol)
		surface.DrawLine( sx, sy, sx - size, sy )
		surface.DrawLine( sx, sy, sx, sy - size )
		
	
		
local posX = top.x
local posY = top.y - 20
if ESPE:GetBool() then
draw.SimpleText(realname(v) ..' ['..v:Health()..']', "DefaultSmallDropShadow" ,posX, posY, Color(team.GetColor(v:Team()).r,team.GetColor(v:Team()).g,team.GetColor(v:Team()).b,255), 1 )
end
end
end
dimahka("PostRenderVGUI", "ESP", DrawESP)

local function showadmins()
	local admins = 0
	
	for k,v in pairs(player.GetAll()) do
		if v:IsAdmin() or v:IsSuperAdmin() then
		admins = admins + 1
		end
	end
	--admins > 0
	if ESPadminson:GetBool() then
	draw.SimpleText(admins.."/"..game.MaxPlayers(), "DefaultSmallDropShadow1" ,ScrW() -50, 45, team.GetColor(LocalPlayer():Team()), 1)
	end
	
	
end

dimahka("PostRenderVGUI", "showadmins", showadmins)


--[[
	AIMBOT
--]]

function NormalizeAngle(angle)
        angle.p = dimanorm(angle.p)
        angle.y = dimanorm(angle.y)
        angle.r = 0
        return angle
end

local function GetWeaponVector( value )
	local s = -value
	return Vector( s, s, s ) 


end

local function GetWeaponVector2( value )
	local s = -value
	return Vector( s, s, 0 )
end

local CONE = {}

local _R = debug.getregistry()

local BULLET = {}

local oldBullets = _R.Entity.FireBullets

function _R.Entity.FireBullets(ent,bulletinfo)
	local wep = LocalPlayer():GetActiveWeapon()
	BULLET[wep:GetClass()] = bulletinfo.Spread
	return oldBullets(ent,bulletinfo)
end

local function PredictSpread(ucmd,angl)
	local wep = LocalPlayer():GetActiveWeapon()
	if(wep && IsValid(wep)) then
		if( !CONE[wep:GetClass()] ) then
			if( BULLET[wep:GetClass()] ) then
				local ang = angl:Forward() || ( ( LocalPlayer():GetAimVector() ):Angle() ):Forward()
				local conevec = Vector( 0, 0, 0 ) - BULLET[wep:GetClass()] || Vector( 0, 0, 0 )
				return( dickwrap.Predict( ucmd, ang, conevec ) ):Angle()
			end
		else
			ang = angl:Forward() || ( ( LocalPlayer():GetAimVector() ):Angle() ):Forward()
			conevec = CONE[wep:GetClass()]
			return( dickwrap.Predict( ucmd, ang, conevec ) ):Angle()
		end
	end
	return angl
end

function KeysDown(key1,key2)
	if input.IsKeyDown(key1) and input.IsKeyDown(key2) then
		return true
	end
return false
end

local aimenabled = dimaccv("dima_aim",0,true,false)
local aimadmins = dimaccv("dima_aim_admins",1,true,false)
local aimsteam = dimaccv("dima_aim_steam",0,true,false)
local aimnospread = dimaccv("dima_aim_nospread",1,true,false)
local aimnorecoil = dimaccv("dima_aim_norecoil",1,true,false)
local aimautofire = dimaccv("dima_aim_autofire",1,true,false)
local aimdebug = dimaccv("dima_aim_debug",0,true,false)
local aimdebugfraction = dimaccv("dima_aim_debug_traction",1.0)
local aimstronghold  = dimaccv("dima_aim_sh",1,true,false)
local aimobb = dimaccv("dima_aim_obb",0,true,false)
local aimtest = dimaccv("dima_test",0,true,false)
local dimarot = dimaccv("dima_rotate",1,true,false)
local function ShouldAttack()
	if input.IsKeyDown(KEY_F)  and aimenabled:GetBool() and type(vgui.GetKeyboardFocus()) ~= "Panel" then
		return true
	end
return false
end


local Attachments = {
	"eyes",
	"forward",
	"head",
}
local Bones = {
	"ValveBiped.Bip01_Head1",
	"ValveBiped.Bip01_Neck1",
}


local function CalcPos(ply)

for _, v in pairs(Attachments) do
if (getattach(ply,lookupattach(ply,v)).Pos) then
return getattach(ply,lookupattach(ply,v)).Pos
end
--return getbonepos(ply,lookupbone(ply,"ValveBiped.Bip01_Neck1"))
if bonecount(ply) < 5 or bonecount(ply) == 0 then 
return toworld(ply,obb(ply))
end
end
return toworld(ply,obb(ply))
end
/*
local function FindClosest(entities,vector)

	local dist, closest = 0, nil

	for _, ent in pairs(entities) do 

		local _dist = ent:GetPos():Distance(vector)
		if ( _dist < dist || !closest ) then

			dist = _dist
			closest = ent

		end

	end

	return closest, dist

end
*/

function FindCloestFromCenter2D(entities)
 
        local closest, dist = nil, 0
       
        for _, ent in pairs(entities) do
 
                local pos = ent:GetPos():ToScreen()
 
                --if (!pos.visible) then continue end
 
                local _dist = math.Dist(pos.x, pos.y, ScrW() * 0.50, ScrH() * 0.50)
 
                if (!closest || _dist < dist) then
 
                        dist = _dist
                        closest = ent
 
                end
 
        end
 
        return closest
 
end

function NormalizeAngle(angle)
        angle.p = dimanorm(angle.p)
        angle.y = dimanorm(angle.y)
        angle.r = 0
        return angle
end



function IsVisible(entity, pos)
	
	local ply = LocalPlayer()
	local trace = {
		start = dimashootpos(ply), 
		endpos = CalcPos(entity), 
		filter = {LocalPlayer(),entity}, 
		mask = MASK_SHOT
	}
	
	local tr = dimatraceline(trace)
	
	if(tr.Fraction == 1.0) then
		return true
	end
	return false
end

/*
local function IsSpectator(pl)
	if pl:GetObserverMode() != 0 or string.find(string.lower(team.GetName(pl)),'spectator') or pl:GetMoveType() == 'MOVETYPE_OBSERVER' then
		return true
	end
return false
end
*/
/*
target = nil

local function SelectTarget()
local ply = FindCloestFromCenter2D(player.GetAll())
	if (ply:Alive()) and LocalPlayer() != ply then
		--if (ShouldAttack()) then
		if (!IsSpectator(ply)) then
			if TargetVisible(ply)  then
				
			if aimadmins:GetBool() and ply:IsAdmin() or ply:IsSuperAdmin() then
				return
			end
			
			target = ply
			end
		end
	end
end
*/
local function Aimbot(c)
	if ShouldAttack() then
--local ply = FindClosest(player.GetAll(),LocalPlayer():GetEyeTrace().HitPos)
local ply = FindCloestFromCenter2D(dimaplayers())

		--for k, ply in pairs(player.GetAll()) do
			if dimaalive(ply) and LocalPlayer() != ply then
						
				if aimadmins:GetBool() and dimaadmin(ply) then
					return
				end
				
				if (!aimsteam:GetBool()) and ply:GetFriendStatus() == "friend" then
					return
				end
				
				if aimstronghold:GetBool() and ply:GetColor().a != 255 then
					return
				end
				
				if (IsVisible(ply)) then
				
				--local ang = (CalcPos(ply) - LocalPlayer():GetShootPos():Angle())
				--print(ply:Nick().."\n")
				local ang = (CalcPos(ply) - LocalPlayer():GetShootPos()):Angle()
				if aimnospread:GetBool() then
				ang = PredictSpread(c, ang)
				end
				ang.p = dimanorm(ang.p)
				ang.y = dimanorm(ang.y)
				ang.r = 0
					
					if aimdebug:GetBool() then
					MsgN(ang)
					end
					 
					 
					c:SetViewAngles(ang)
					if aimautofire:GetBool() then
					c:SetButtons(bit.bor(c:GetButtons(),IN_ATTACK))
					
				--	end
				end
			end
end
end
end
dimahka("CreateMove","Aimbot",Aimbot)
--hook.Add("Think","SelectTarget",SelectTarget)
/*
local function lines()
local ply = FindCloestFromCenter2D(player.GetAll())
		if (ply:Alive()) and LocalPlayer() != ply then
			if (!IsSpectator(ply)) then
				if TargetVisible(ply)  then
				if aimadmins:GetBool() and ply:IsAdmin() or ply:IsSuperAdmin() then
					return
				end
				local pos = (CalcPos(ply):ToScreen())
				surface.DrawLine(ScrW() /2, ScrH() /2,pos.x,pos.y)
			--	end
			end
		end
	end
end
				

hook.Add("HUDPaint","lines",lines)
*/
/* and after the aimbot and ESP, we will do detours and other security features should that ever be necessary. */

local _R = debug.getregistry()
local setviewangles = _R.Player.SetViewAngles
local seteyeangles = _R.Player.SetEyeAngles

_R.Player.SetEyeAngles = function(self, a)

local dbgsrc = debug.getinfo(3, 'S')['short_src']
if dbgsrc:lower():find('weapon') then
return
end
return seteyeangles(self, a)
end 

_R.Player.SetViewAngles = function(self, a)

local dbgsrc = debug.getinfo(3, 'S')['short_src']
if dbgsrc:lower():find('weapon') then
return
end
return setviewangles(self, a)
end 



local function dimadl()
local dimaframe = dimavgui("DFrame")
dimaframe:SetSize(400,100)
dimaframe:Center()
dimaframe:SetTitle("dima downloader")
dimaframe:MakePopup()

local dimapath = dimavgui("DTextEntry", dimaframe)
--dimapath:SetPos(25,50)
dimapath:SetSize(350,20)
dimapath:Center()
dimapath:SetText("")
dimapath.OnEnter = function(self)
	MsgC(Color(0,255,0),'Requesting ' .. self:GetValue() ..'\n')
	RequestFile(self:GetValue())
	dimarcc("net_showfragments",1)
end

local dimapast = dimavgui("DButton",dimaframe)
dimapast:SetText("Yesterday")
dimapast:SetPos(24,70)
dimapast:SetSize(60,20)
dimapast.DoClick = function()
local date = tonumber(os.date("%d")) -1 
MsgC(Color(0,255,0),"data/ulx_logs/"..os.date("%m-")..date..os.date("-%y")..".txt\n")
RequestFile("data/ulx_logs/"..os.date("%m-")..date..os.date("-%y")..".txt")
end

local dimapresent = dimavgui("DButton",dimaframe)
dimapresent:SetText("Present")
dimapresent:SetPos(315,70)
dimapresent:SetSize(60,20)
dimapresent.DoClick = function()
MsgC(Color(0,255,0),"downloading present files ["..os.date("%m-%d-%y").."]\n")
RequestFile("data/ulx_logs/"..os.date("%m-%d-%y")..".txt")
end

local dimaconfig = dimavgui("DButton",dimaframe)
dimaconfig:SetText("Config")
dimaconfig:SetPos(170,70)
dimaconfig:SetSize(60,20)
dimaconfig.DoClick = function()
MsgC(Color(0,255,0),"downloading config\n")
RequestFile("data/ulx/config.txt")
end

end

local lastdimadownload = CurTime() +2

local function dimathink()
if CurTime() < lastdimadownload then return end
	if KeysDown(KEY_LALT,KEY_1) then
	dimadl()
	--print('dimadl\n')
	lastdimadownload = CurTime() +2
	end
end

hook.Add("Think","dimathink", dimathink)


local nextcur = CurTime() +0.2

local function dimarotate()
if CurTime() < nextcur then return end
if input.IsKeyDown(KEY_T)  and dimarot:GetBool() and type(vgui.GetKeyboardFocus()) ~= "Panel" then
LocalPlayer():SetEyeAngles(Angle(LocalPlayer():EyeAngles().p, LocalPlayer():EyeAngles().y - 180, LocalPlayer():EyeAngles().r)) 
nextcur = CurTime() +0.2
end
end

dimahka("Think","dimarotate",dimarotate)

local nextgetmodel = CurTime() +0.1

local function dimamodel() 
if CurTime() < nextgetmodel then return end
	if input.IsKeyDown(KEY_RBRACKET) and type(vgui.GetKeyboardFocus()) ~= "Panel" then
		if IsValid(LocalPlayer():GetEyeTrace().Entity) then
		MsgC(Color(0,255,0),"Copied " .. LocalPlayer():GetEyeTrace().Entity:GetModel() .. "\n")
		SetClipboardText(LocalPlayer():GetEyeTrace().Entity:GetModel())
		nextgetmodel = CurTime() +2
		end
	end
end

dimahka("Think","dimamodel",dimamodel)

local dimabhop = dimaccv("dima_bhop",1,true,false)

local jumping = false
dimahka("Think","bhop",function()
if (LocalPlayer() and LocalPlayer():IsOnGround() and input.IsKeyDown(KEY_SPACE) && !jumping  and dimabhop:GetBool()) and type(vgui.GetKeyboardFocus()) ~= "Panel" then 
dimarcc("+jump");jumping=true
elseif (jumping) then
dimarcc("-jump");jumping=false
end
end)

dimahka("InitPostEntity","noob", function()
dimaccr('wesnlr')
MsgC(Color(0,255,0),"["..os.date("H:%M:%S").."] Init.\n")
timer.Create("dimaremovehooks",10,0, function()
--dimahkr("PostPlayerDraw","PS_PostPlayerDraw")
--dimahkr("Think","PS_Think")
end)
end)

local curent = nil

local dimapropmat = CreateClientConVar("dima_prop_mat",1,true,false)

local function onpickup(ply,ent)
	if (ply) and (ent) then
		if ply == LocalPlayer() then
		ent:SetRenderMode(RENDERMODE_TRANSCOLOR) 
		if dimapropmat:GetBool() then
		--ent:SetMaterial("mat")
		end
		ent:SetColor(Color(0,200,0,200))
		curent = ent
		--MsgN(type(curent))
		end
	end
end

local function ondrop(ply,ent)
	if (ply) and (ent) then
		if ply == LocalPlayer() then 
		ent:SetColor(Color(255,255,255))
		ent:SetMaterial("")
		curent = nil
		end
	end
end

local function toprop()
	if type(curent) == "Entity" and (LocalPlayer()) then
	local pos = (curent:GetPos():ToScreen())
	surface.SetDrawColor(team.GetColor(LocalPlayer():Team()))
	surface.DrawLine(ScrW() /2, ScrH() -10, pos.x,pos.y)
	end
end

dimahka("PhysgunPickup","onpickup",onpickup)
dimahka("PhysgunDrop","ondrop", ondrop)
dimahka("HUDPaint","toprop", toprop)
