//CUNIT-174.16.128.243:27005
//sh "STEAM_0:0:25093119"

print("DuckBot Loading...")

local include = include
local require = require

require ("concommand")
require ("gamemode")
require ("weapons")
require ("hook")
require ("timer")
require ("list")
require ("cvars")
require ("http")
require ("datastream")
require ("draw")
require ( "markup" )
require ("controlpanel")
require ("presets")
require ("cookie")

local concommand = concommand
local cvars = cvars
local debug = debug
local ents = ents
local file = file
local hook = hook
local math = math
local string = string
local surface = surface
local table = table
local timer = timer
local util = util
local vgui = vgui
local surface = surface
local draw = draw
local cam = cam
local input = input
local os = os
local render = render

local Entity = Entity
local Player = Player
local Angle = Angle
local CreateClientConVar = CreateClientConVar
local CurTime = CurTime
local ErrorNoHalt = ErrorNoHalt
local FrameTime = FrameTime
local GetConVarString = GetConVarString
local GetViewEntity = GetViewEntity
local include = include
local ipairs = ipairs
local LocalPlayer = LocalPlayer
local pairs = pairs
local pcall = pcall
local print = print
local RunConsoleCommand = RunConsoleCommand
local ScrH = ScrH
local ScrW = ScrW
local tonumber = tonumber
local type = type
local unpack = unpack
local ValidEntity = ValidEntity
local Vector = Vector
local GetConVarNumber = GetConVarNumber

/*
local hook_table = {}
local oldHookCall = hook.Call
function hook.Call(name, gm, ...)
	for k,tbl in pairs(hook_table) do
		if tbl.name == name then
			if ... == nil then
				ret = tbl.func()
			//elseif type(...) == "table" then
			//	return tbl.func(unpack(arg))
			else
				ret = tbl.func(...)
			end
			if ret != nil then // this is so we dont always return a value, EG HUDPaint should not have a return unless overidden
				return ret
			end
		end
	end
	return oldHookCall(name, gm, ...)
end
local function hook.Add(name, id, func)
	hook_table[id] = {name=name, func=func}
	//hook.Add(name,id,func)
end

local cmd_table = {}
local oldCmdRun = concommand.Run
function concommand.Run( pl, name, ... )
	local tbl = cmd_table[name]
	if tbl != nil then
		return tbl.func(pl,name,...)
	else
		return oldCmdRun(pl, name, ...)
	end
end
local function concommand.Add(name, func, afunc, help)
	AddConsoleCommand(name,help)
	cmd_table[name] = {func=func,afunc=afunc,help=help}
	//concommand.Add(name,func,afunc,help)
end
*/

CreateClientConVar("duck_speed", 5, true, false)
CreateClientConVar("Duck_Wallhack_Red", 0, true, false)
CreateClientConVar("Duck_Wallhack_team", 0, true, false)
CreateClientConVar("Duck_Wallhack_Green", 0, true, false)
CreateClientConVar("Duck_Wallhack_Blue", 0, true, false)
CreateClientConVar("Duck_Wallhack_Outline_Red", 0, true, false)
CreateClientConVar("Duck_Wallhack_Outline_Green", 0, true, false)
CreateClientConVar("Duck_Wallhack_Outline_Blue", 0, true, false)
CreateClientConVar("Duck_Wallhack_Outline_Thickness", 0, true, false)
CreateClientConVar("Duck_Wallhack_Material", 0, true, false)
CreateClientConVar("Duck_Wallhack_Outline_Material", 0, true, false)
CreateClientConVar("Duck_Wallhack_OC_Style", 0, true, false)
CreateClientConVar("Duck_Wallhack_C_Style", 0, true, false)
CreateClientConVar("Duck_Wallhack_Outline", 0, true, false)

CreateClientConVar("duck_crosshair_dot", 0, true, false)
CreateClientConVar("duck_crosshair_circle", 0, true, false)
CreateClientConVar("duck_crosshair_cross", 0, true, false)
CreateClientConVar("duck_crosshair_r", 0, true, false)
CreateClientConVar("duck_crosshair_g", 0, true, false)
CreateClientConVar("duck_crosshair_b", 0, true, false)
CreateClientConVar("duck_asus", 0, true, false)
CreateClientConVar("duck_hud", 0, true, false)
CreateClientConVar("duck_spec", 0, true, false)
CreateClientConVar("duck_hud_mirror", 0, true, false)


CreateClientConVar("duck_esp", 0, true, false)
CreateClientConVar("duck_esp_font", 0, true, false)
CreateClientConVar("duck_esp_team", 0, true, false)
CreateClientConVar("duck_esp_pvisible", 0, true, false)
CreateClientConVar("duck_esp_pvisibletype", 0, true, false)
CreateClientConVar("duck_esp_pweapon", 0, true, false)
CreateClientConVar("duck_esp_pweaponicon", 0, true, false)
CreateClientConVar("duck_esp_phealth", 0, true, false)
CreateClientConVar("duck_esp_phtype", 0, true, false)
CreateClientConVar("duck_esp_pskeleton", 0, true, false)
CreateClientConVar("duck_esp_pskeletoncol", 0, true, false)
CreateClientConVar("duck_esp_ttt_traitor", 0, true, false)
CreateClientConVar("duck_esp_ttt_c4", 0, true, false)
CreateClientConVar("duck_esp_ttt_nade", 0, true, false)
CreateClientConVar("duck_esp_aimpos", 0, true, false)

CreateClientConVar("duck_laser", 0, true, false)
CreateClientConVar("duck_laser_dot", 0, true, false)

CreateClientConVar("duck_crosshair", 1, true, false)
CreateClientConVar("duck_crosshair_style", 1, true, false)
CreateClientConVar("duck_fullbright", 0, true, false)

CreateClientConVar("duck_zoom", 0, true, false)

CreateClientConVar("duck_trigger", 0, true, false) 
CreateClientConVar("duck_trigger_head", 0, true, false) 

CreateClientConVar("duck_sys_nospread", 0, true, false)
CreateClientConVar("duck_sys_nospread_onmethod", 0, true, false)

CreateClientConVar("duck_aim_friends", 0, true, false) 
CreateClientConVar("duck_aim_fov", 0, true, false)  
CreateClientConVar("duck_aim_team", 0, true, false)     
CreateClientConVar("duck_aim_plus", 4, true, false )
CreateClientConVar("duck_aim_comp", 45, true, false )
CreateClientConVar("duck_aim_mode", 0, true, false)  
CreateClientConVar("duck_aim_npc", 0, true, false)   
CreateClientConVar("duck_aim_player", 0, true, false)   
CreateClientConVar("duck_aim_auto", 0, true, false)   
CreateClientConVar("duck_aim_draw", 0, true, false) 
CreateClientConVar("duck_radar", 0, true, false) 

CreateClientConVar("duck_spam_time", 0.01, true, false) 

CreateClientConVar("duck_spin", 0, true, false) 
CreateClientConVar("duck_autofire", 0, true, false) 
CreateClientConVar("duck_bhop", 0, true, false) 
CreateClientConVar("duck_view", 0, true, false) 



local function head(ent) 
        local headbone = ent:LookupBone("ValveBiped.Bip01_Head1") 
        return ent:GetBonePosition(headbone) 
end 


local function visible(ent) 
    local trace = {start = LocalPlayer():GetShootPos(),endpos = head(ent)+ent:GetVelocity()*RealFrameTime(),filter = {LocalPlayer(), ent}, mask = MASK_SHOT} 
    local tr = util.TraceLine(trace) 
    if tr.Fraction == 1 then 
        return true 
    else 
        return false 
    end     
end 
	
	local function IsAdmin(ent)
	if ent:IsAdmin() || ent:IsSuperAdmin() then 
		return true
		end
	return false
end

local function GetAdminType(ent)

	
	if ent:IsAdmin() && !ent:IsSuperAdmin()  then
		return "Admin"
		
	elseif ent:IsSuperAdmin() then
		return "Super Admin"
	
	elseif !ent:IsSuperAdmin() || !ent:IsAdmin() then
		return "Guest"
	end
	
	return ""

      end

require("localcommand")//name blocked, fuck


local function AutoJump(UCMD)
    if GetConVarNumber("duck_bhop") == 1 && !LocalPlayer():IsOnGround() then
    if  LocalPlayer():GetMoveType() == 9 then else
	if UCMD:KeyDown(IN_JUMP) then
    UCMD:SetButtons(UCMD:GetButtons() - IN_JUMP)
	end
        end	
			end
end
hook.Add("CreateMove", "jump", AutoJump)

local function Zoom()
		/*local viewpos = {} 
		viewpos.angles = LocalPlayer():EyeAngles()
		viewpos.origin = LocalPlayer():GetShootPos()
		
		for k,v in pairs(ents.FindByClass("prop_combine_ball")) do
			viewpos.origin = v:GetPos() - Vector(-20,0,0)
		end
	return viewpos*/	
end
hook.Add("CalcView", "zoom", Zoom)

/*// make sure this is always reachacble
if not self:Enabled() and WasSilentAimed then
	WasSilentAimed = false
	CmdM.SetViewAngles(cmd, self:GetView())
end

// in hax

local times = 1
if qq:Setting("silentaim") then
	WasSilentAimed = true
	times = -1
	aim.p = (aim.p - 180) * -1
	aim.y = aim.y + 180
end

// when u set ur shit

CmdM.SetSideMove(cmd, set.y * times)*/

local Friends = {""}

local function AimFilter(ent)
	if !ent:IsValid() || (!ent:IsNPC() && !ent:IsPlayer()) || ent == LocalPlayer() || !LocalPlayer():Alive() then return false end
	
	if ent:IsPlayer() then 
	if GetConVarNumber("duck_aim_player") == 0 then if ent:IsPlayer() then return false end end
	if !ent:Alive() || ent:Health() < 1 then return false end
	if  ent:Team() == LocalPlayer():Team() && GetConVarNumber("duck_aim_team") == 1 then return false end
	if table.HasValue(Friends,ent:Nick()) then return false end
	if GetConVarNumber("duck_aim_friends") == 1 && ent:GetFriendStatus() == "friend" then return false end  
	if ent:IsEFlagSet(EFL_DORMANT) then return false end  
	end
	
	if ent:IsNPC() then
	if GetConVarNumber("duck_aim_npc") == 0 then if ent:IsNPC() then return false end end
	if ent:GetMoveType() == 0 then return false end 
	end
	return true
end

local function FOVRestrict(ent, value)
	return LocalPlayer():GetAimVector():DotProduct((ent:GetPos() - LocalPlayer():GetPos()):Normalize()) > value
end

local function Target()
	local position = LocalPlayer():EyePos() 
	local angle = LocalPlayer():GetAimVector()
	local tar = {0,0}
	local e = ents.GetAll()
	for i = 1, table.Count( e ) do
		local ent = e[i]
		if AimFilter(ent) && visible(ent) && FOVRestrict(ent, GetConVarNumber("duck_aim_fov")) then
			local targetpos = head(ent)
			local difr = (targetpos-position):GetNormal()
			difr = difr - angle
			difr = difr:Length()
			difr = math.abs(difr)
			if difr < tar[2] || tar[1] == 0 then
				tar = {ent, difr}
			end
		end
	end

		return tar[1]

end  

//locals
local AimBot 
local ent
local Compensation
local Mypos 
local NSPos
local Nospread
local spt
local m
local Victor = Vector(0,0,0) 

local function DuckAim(UCMD)
	
	ent = Target()
 
	if ent != 0 then
 
    m = ent:GetModel()  
    
	spt = ent:GetBonePosition(ent:LookupBone("ValveBiped.Bip01_Head1"))
	 
	if ( m == "models/crow.mdl" || m == "models/pigeon.mdl" ) then spt = ent:LocalToWorld( Vector( 0, 0, 5 ) )  end
	if ( m == "models/seagull.mdl" ) then spt = ent:LocalToWorld( Vector( 0, 0, 6 ) ) end
	if ( m == "models/combine_scanner.mdl" ) then spt = ent:GetBonePosition( ent:LookupBone( "Scanner.Body" ) ) end
	if ( m == "models/hunter.mdl" ) then spt = ent:GetBonePosition( ent:LookupBone( "MiniStrider.body_joint" ) ) end
	if ( m == "models/combine_turrets/floor_turret.mdl" ) then spt = ent:GetBonePosition( ent:LookupBone( "Barrel" ) ) end
	if ( m == "models/dog.mdl" ) then spt = ent:GetBonePosition( ent:LookupBone( "Dog_Model.Eye" ) ) end
	if ( m == "models/vortigaunt.mdl" ) then spt = ent:GetBonePosition( ent:LookupBone( "ValveBiped.Head" ) ) end
	if ( m == "models/antlion.mdl" ) then spt = ent:GetBonePosition( ent:LookupBone( "Antlion.Body_Bone" ) ) end
	if ( m == "models/antlion_guard.mdl" ) then spt = ent:GetBonePosition( ent:LookupBone( "Antlion_Guard.Body" ) ) end
	if ( m == "models/antlion_worker.mdl" ) then spt = ent:GetBonePosition( ent:LookupBone( "Antlion.Head_Bone" ) ) end
	if ( m == "models/zombie/fast_torso.mdl" ) then spt = ent:GetBonePosition( ent:LookupBone( "ValveBiped.HC_BodyCube" ) ) end
	if ( m == "models/zombie/fast.mdl" ) then spt = ent:GetBonePosition( ent:LookupBone( "ValveBiped.HC_BodyCube" ) ) end
	if ( m == "models/headcrabclassic.mdl" ) then spt = ent:GetBonePosition( ent:LookupBone( "HeadcrabClassic.SpineControl" ) ) end
	if ( m == "models/headcrabblack.mdl" ) then spt = ent:GetBonePosition( ent:LookupBone( "HCBlack.body" ) ) end
	if ( m == "models/headcrab.mdl" ) then spt = ent:GetBonePosition( ent:LookupBone( "HCFast.body" ) ) end
	if ( m == "models/zombie/poison.mdl" ) then spt = ent:GetBonePosition( ent:LookupBone( "ValveBiped.Headcrab_Cube1" ) ) end
	if ( m == "models/zombie/classic.mdl" ) then spt = ent:GetBonePosition( ent:LookupBone( "ValveBiped.HC_Body_Bone" ) ) end
	if ( m == "models/zombie/classic_torso.mdl" ) then spt = ent:GetBonePosition( ent:LookupBone( "ValveBiped.HC_Body_Bone" ) ) end
	if ( m == "models/zombie/zombie_soldier.mdl" ) then spt = ent:GetBonePosition( ent:LookupBone( "ValveBiped.HC_Body_Bone" ) ) end
	if ( m == "models/combine_strider.mdl" ) then spt = ent:GetBonePosition( ent:LookupBone( "Combine_Strider.Body_Bone" ) ) end
	if ( m == "models/combine_dropship.mdl" ) then spt = ent:GetBonePosition( ent:LookupBone( "D_ship.Spine1" ) ) end
	if ( m == "models/combine_helicopter.mdl" ) then spt = ent:GetBonePosition( ent:LookupBone( "Chopper.Body" ) ) end
	if ( m == "models/gunship.mdl" ) then spt = ent:GetBonePosition( ent:LookupBone( "Gunship.Body" ) ) end
	if ( m == "models/lamarr.mdl" ) then spt = ent:GetBonePosition( ent:LookupBone( "HeadcrabClassic.SpineControl" ) ) end
	if ( m == "models/mortarsynth.mdl" ) then spt = ent:GetBonePosition( ent:LookupBone( "Root Bone" ) ) end
	if ( m == "models/synth.mdl" ) then spt = ent:GetBonePosition( ent:LookupBone( "Bip02 Spine1" ) ) end
	if ( m == "mmodels/vortigaunt_slave.mdl" ) then spt = ent:GetBonePosition( ent:LookupBone( "ValveBiped.Head" ) ) end
	
	
  Victor = Vector(0,0,GetConVar("Duck_aim_plus"):GetFloat())
  
  Compensation = spt+Victor--ent:GetBonePosition(ent:GetHitBoxBone(0))+Victor
  Compensation = Compensation + (ent:GetVelocity() / GetConVar("Duck_aim_comp"):GetFloat() - LocalPlayer():GetVelocity() / GetConVar("Duck_aim_comp"):GetFloat()) 


	Mypos = LocalPlayer():EyePos()
    NSPos = (Compensation - Mypos):Angle()
	math.NormalizeAngle(NSPos.p)
	math.NormalizeAngle(NSPos.y)

 
	if AimBot == true then
	
	if GetConVarNumber("duck_aim_auto") == 1 then
    UCMD:SetButtons(UCMD:GetButtons() | IN_ATTACK)	
	end	
		
		UCMD:SetViewAngles(NSPos)			
	end
		end

end
	
 function NoTwitch(angle)
	 	if ent != 0 && AimBot == true then
		local viewpos = {} 

	viewpos.angles = NSPos
	viewpos.fov = FOV
		return viewpos
end
end
	
	concommand.Add("+duck_aimbot", function()
	hook.Add("CalcView", "Twich", NoTwitch) 	
    AimBot = true
	hook.Add("CreateMove", "Aim", DuckAim)
		end)
	 
	concommand.Add("-duck_aimbot", function() 
	hook.Remove("CalcView", "Twich") 	
    AimBot = false
	hook.Remove("CreateMove", "Aim")
	end)

local trigger
local function Trigger(UCMD)
 
	if GetConVarNumber("duck_trigger") == 1 && trigger == true then
		
 
		local nospreadvec = hack.CompensateWeaponSpread(UCMD, Vector(cone, cone, cone), UCMD:GetViewAngles():Forward()):Angle()
		local tracedata = {}
		tracedata.start = LocalPlayer():GetShootPos()
		tracedata.endpos = tracedata.start + (nospreadvec:Forward() * 8192 ) 
		tracedata.filter = LocalPlayer()
		tracedata.mask = MASK_SHOT
		local trace = util.TraceLine(tracedata)
		
		if trace.Hit && trace.HitNonWorld then
		local hit = trace.Entity
		if AimFilter(hit)  then
		if GetConVarNumber("duck_trigger_head") == 1 && trace.HitGroup == 1 then		  
			UCMD:SetButtons(UCMD:GetButtons() | IN_ATTACK)	
			
		elseif GetConVarNumber("duck_trigger_head") == 0 then
			UCMD:SetButtons(UCMD:GetButtons() | IN_ATTACK)	
		end
			end
				end
					end
end

concommand.Add("+duck_trigger", function() trigger = true
local wep = LocalPlayer():GetActiveWeapon()
--if wep && wep.Primary && wep.Primary.Recoil then wep.Primary.Recoil = 0 end
end)
concommand.Add("-duck_trigger", function() trigger = false 
local wep = LocalPlayer():GetActiveWeapon()
--if wep && wep.Primary && wep.Primary.Recoil then wep.Primary.Recoil = 1 end
end)

hook.Add("CreateMove", "Trigger", Trigger)

local fakeview = false
local propthrown = false
local modang = Angle( 0, 0, 0 )
local realang = Angle( 0, 0, 0 )


function propkill( ucmd )
	if !fakeview and propthrown then		
		propthrown = false
		ucmd:SetViewAngles(modang)
	elseif !fakeview then
		local realang = ucmd:GetViewAngles()
		modang = realang
	else	
		local realang = ucmd:GetViewAngles()
		modang = realang
		modang.y = realang.y - 180
		local move = Vector( ucmd:GetForwardMove(), ucmd:GetSideMove(), 0 )
		local norm = move:GetNormal()
		local set = ( norm:Angle() + ( modang - realang ) ):Forward() * move:Length()
		ucmd:SetForwardMove( -set.x )
		ucmd:SetSideMove( -set.y )
	end
end

function decalcview( ucmd, origin, angles )
	local ply = LocalPlayer()
	if fakeview then
		return{
			origin = origin,
			angles = modang 
		}
	else
		return
	end
end

	hook.Add("CalcView", "tttc", decalcview) 
	hook.Add("CreateMove", "tttcm", propkill)
	concommand.Add("+duck_prop", function()
	fakeview = true

		end)
	 
	concommand.Add("-duck_prop", function() 
	fakeview = false
	propthrown = true
	end)


local function Laser()

local vm = LocalPlayer():GetViewModel()
local alpha = Color(0, 255, 0, 255) 
local bone = vm:LookupAttachment("muzzle")

   if not vm then return end      
   if vm && vm:IsValid() then
                				
	if bone == 0 then bone = vm:LookupAttachment("1") end
	if bone == 0 then bone = vm:LookupAttachment("laser") end
    if bone == 0 then bone = vm:LookupAttachment("spark") end
	if bone == 0 then bone = vm:LookupAttachment("0") end
    if bone == 0 then bone = LocalPlayer():LookupAttachment("chest")  end 
	
	
	        cam.Start3D(EyePos(), EyeAngles())
		
		if GetConVarNumber("duck_laser_dot") == 1 then
		render.SetMaterial(Material("Sprites/light_glow02_add_noz"))
		render.DrawQuadEasy(LocalPlayer():GetEyeTrace().HitPos, (EyePos() - LocalPlayer():GetEyeTrace().HitPos):GetNormal(), 20, 20, Color(0, 255, 0, 255), 0)
		end
		if GetConVarNumber("duck_laser") == 1 then
		render.SetMaterial(Material("sprites/bluelaser1"))
		render.DrawBeam(vm:GetAttachment(bone).Pos, LocalPlayer():GetEyeTrace().HitPos, 3, 0, 0, alpha)
		end
		
		cam.End3D()
end
		end



hook.Add("HUDPaint", "Laser", Laser)

	
local function WallFilter(ent)
	if !ent:IsValid() || (!ent:IsNPC() && !ent:IsPlayer()) || ent == LocalPlayer() then return false end
	
	if ent:IsPlayer() then 
	if !ent:Alive() || ent:Health() < 1 then return false end
	if ent:Team() == LocalPlayer():Team() && GetConVarNumber("duck_wallhack_team") == 1 then return false end 
	end
	
	if ent:IsNPC() then
	if ent:GetMoveType() == 0 then return false end 
	end
	return true
end	

local function ESPFilter(ent)
if !ent:IsValid() || !ent:IsPlayer() || ent == LocalPlayer() then return false end
	if ent:IsPlayer() then --double check lol
		if !ent:Alive() || ent:Health() < 1 then return false end
		if ent:Team() == LocalPlayer():Team() && GetConVarNumber("duck_esp_team") == 1 then return false end
	end
return true
end


function surface.DrawPolyEasy( textureid, color, ... )--by noPE	
	local vertextable = {{}, {}, {}, {}, {}}
	
	for num, data in pairs( { ... } ) do
		vertextable[num]['x'] = data[1]
		vertextable[num]['y'] = data[2]
		vertextable[num]['u'] = data[3]
		vertextable[num]['v'] = data[4]
	end
	
	surface.SetTexture( textureid )
	surface.SetDrawColor( color )
	surface.DrawPoly( vertextable )
end

local Tags = {}

local skeleton = {
	{"ValveBiped.Bip01_Head1", "ValveBiped.Bip01_Spine4"},
	{"ValveBiped.Bip01_Spine4", "ValveBiped.Bip01_Spine2"},
	{"ValveBiped.Bip01_Spine2", "ValveBiped.Bip01_Spine"},
	{"ValveBiped.Bip01_Spine4", "ValveBiped.Bip01_L_UpperArm"},
	{"ValveBiped.Bip01_Spine4", "ValveBiped.Bip01_R_UpperArm"},
	{"ValveBiped.Bip01_R_UpperArm", "ValveBiped.Bip01_R_Forearm"},
	{"ValveBiped.Bip01_L_UpperArm", "ValveBiped.Bip01_L_Forearm"},
	{"ValveBiped.Bip01_R_Forearm", "ValveBiped.Bip01_R_Hand"},
	{"ValveBiped.Bip01_L_Forearm", "ValveBiped.Bip01_L_Hand"},
	{"ValveBiped.Bip01_Spine", "ValveBiped.Bip01_Pelvis"},
	{"ValveBiped.Bip01_Pelvis", "ValveBiped.Bip01_R_Thigh"},
	{"ValveBiped.Bip01_Pelvis", "ValveBiped.Bip01_L_Thigh"},
	{"ValveBiped.Bip01_R_Thigh", "ValveBiped.Bip01_R_Calf"},
	{"ValveBiped.Bip01_L_Thigh", "ValveBiped.Bip01_L_Calf"},
	{"ValveBiped.Bip01_R_Calf", "ValveBiped.Bip01_R_Foot"},
	{"ValveBiped.Bip01_L_Calf", "ValveBiped.Bip01_L_Foot"},
	{"ValveBiped.Bip01_R_Foot", "ValveBiped.Bip01_R_Toe0"},
	{"ValveBiped.Bip01_L_Foot", "ValveBiped.Bip01_L_Toe0"},
	}--this is from hades + messed around a bit

local Fonts = {
 "TabLarge",
 "Default",
 "DefaultFixedOutline",
 "DefaultSmallDropShadow",
 "TargetID",
 "CloseCaption_BoldItalic",
}

	
local function ESP()
for k,ent in pairs(ents.GetAll()) do
	local font = Fonts[GetConVarNumber("duck_esp_font")]
	if ent:IsPlayer() && ESPFilter(ent) && FOVRestrict(ent,0.80) then
		
		local pos = head(ent)
		pos = pos:ToScreen()
		local tc = team.GetColor(ent:Team())
		local hp = math.Clamp(ent:Health(),0,100)
		local hpcol = math.Clamp(ent:Health(), 0, 100) / 100
		hpcol = hpcol * 120
		hpcol = math.Clamp(hpcol, 0, 120) // 120 is green
		hpcol = HSVToColor(hpcol, 1, 1)
		local skeletoncol = color_white
		local wep = ent:GetActiveWeapon()
		wepcol = color_white		
		vs = color_white
		if visible(ent) then vs = Color( 0, 255, 0, 255 ) else vs = Color( 255, 0, 0, 255 ) end
		
		if GetConVarNumber("duck_esp") == 1 then
			draw.SimpleText(ent:GetName(), font, pos.x-20, pos.y-10, tc)
			if IsAdmin(ent) then
				draw.SimpleText("Admin", font, pos.x-40, pos.y-3, color_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			end
		end
	
		if GetConVarNumber("duck_esp_phealth") == 1 then
			if GetConVarNumber("duck_esp_phtype") == 1 then
				surface.DrawPolyEasy(surface.GetTextureID("vgui/white"),Color(50,50,50,255 ),
				{pos.x-10,pos.y-20,1,0},{pos.x+30,pos.y-10,0,1},{pos.x-22,pos.y-10,1,0},{pos.x+40,pos.y-20,0,1},{pos.x+30,pos.y-10,0,1})
				surface.DrawPolyEasy(surface.GetTextureID("vgui/white"),Color(hpcol.r,hpcol.g,hpcol.b,255 ),
				{pos.x-10,pos.y-19,1,0},{pos.x+hp/2-19,pos.y-11,0,1},{pos.x-20,pos.y-11,1,0},{pos.x+hp/2-12,pos.y-19,0,1},{pos.x+hp/2-20,pos.y-11,0,1})
				elseif GetConVarNumber("duck_esp_phtype") == 2 then
				surface.SetDrawColor(50,50,50,255)
				surface.DrawRect(pos.x-20,pos.y-20,50,10)
				surface.SetDrawColor(hpcol)
				surface.DrawRect(pos.x-20,pos.y-20,hp/2,10)
				elseif GetConVarNumber("duck_esp_phtype") == 3 then
				surface.SetDrawColor(50,50,50,255)
				surface.DrawRect(pos.x-22,pos.y-22,54,14)
				surface.SetDrawColor(hpcol)
				surface.DrawRect(pos.x-20,pos.y-20,hp/2,10)
			end
		end
		
		if GetConVarNumber("duck_esp_pskeleton") == 1 then
			for k,v in pairs(skeleton) do
			
				local bone1 = ent:GetBonePosition(ent:LookupBone(v[1])):ToScreen()
				local bone2 = ent:GetBonePosition(ent:LookupBone(v[2])):ToScreen()
				
				if GetConVarNumber("duck_esp_pskeletoncol") == 1 then
				skeletoncol = hpcol
				elseif GetConVarNumber("duck_esp_pskeletoncol") == 2 then
				skeletoncol = tc
				elseif GetConVarNumber("duck_esp_pskeletoncol") == 3 then
					if visible(ent) then
						skeletoncol = Color(0,255,0,255)
						else
						skeletoncol = Color(255,0,0,255)
					end
				end
				surface.SetDrawColor(skeletoncol)
				surface.DrawLine(bone1.x,bone1.y,bone2.x,bone2.y)
			end
		end
		
		if GetConVarNumber("duck_esp_pweapon") == 1 then
			if wep:IsValid() then
				if GetConVarNumber("duck_esp_pweaponicon") == 0 then
					draw.SimpleText(wep:GetPrintName(), font, pos.x, pos.y+15, wepcol, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
				elseif  GetConVarNumber("duck_esp_pweaponicon") == 1 then
				
						if wep.IconLetter != nil then
							draw.SimpleText(wep.IconLetter, "CSKillIcons", pos.x, pos.y + 30, wepcol, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
						else
							draw.SimpleText(wep:GetPrintName(), font, pos.x, pos.y+15, wepcol, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
						end
				end
			end
		end	
		
		if GetConVarNumber("duck_esp_pvisible") == 1 then
			if GetConVarNumber("duck_esp_pvisibletype") == 1 then
				draw.RoundedBox(6 , pos.x-4, pos.y-34, 10, 10, vs )
			elseif GetConVarNumber("duck_esp_pvisibletype") == 2 then
				surface.SetDrawColor(vs)
				surface.DrawRect(pos.x-4, pos.y-34,10,10)
			end
		end
		
		if ent:GetFriendStatus() == "friend"  then
			draw.SimpleText(ent:GetName(), font, pos.x-20, pos.y-10, Color(255,0,0,255))
		end
		
		if table.HasValue(Tags, ent:GetName()) then
			draw.SimpleText(ent:GetName(), font, pos.x, pos.y, Color(math.Rand(0,255),math.Rand(0,255),math.Rand(0,255),255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end
		
		if GetConVarNumber("duck_aim_draw") == 1  then //just using this hook
			if FOVRestrict(ent, GetConVarNumber("duck_aim_fov")) && visible(ent) && AimFilter(ent) then 
				local ent = Target()
				pos = head(ent)
				pos = pos:ToScreen()
				surface.SetDrawColor(255,0,0,255)
				surface.DrawLine( ScrW()/2, ScrH()/2, pos.x, pos.y )
			end
		end
		
	end
        
	if string.find(GAMEMODE.Name,"Trouble in Terrorist Town") then
		if GetConVarNumber("duck_esp_ttt_traitor") then
			if ent:IsWeapon() && ValidEntity(ent) then
				local Weapons = ent.CanBuy 
				local pos = ent:GetPos():ToScreen()
				local glow = (1+0.5*math.sin(RealTime()*15))*255
					
				if table.HasValue(Weapons, ROLE_TRAITOR)  then
					draw.SimpleText("Traitor", font, pos.x, pos.y, Color(glow,0,0,255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
				end
			end
		end
		if ValidEntity(ent) && ent:GetClass() == "ttt_c4"  then 
			local pos = ent:GetPos():ToScreen() 
			local glow = (1+0.5*math.sin(RealTime()*15))*255
			draw.SimpleText("C4 Explosion In: " .. string.FormattedTime(math.max(0, ent:GetExplodeTime() - CurTime()),"%02i:%02i"), "TabLarge", pos.x, pos.y, Color(glow,0,0,255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end
		if (ent.Base || "") == "ttt_basegrenade_proj" then
			local size = (ent:GetExplodeTime() - CurTime()) * 15
			if size > 0 then
				local pos = ent:GetPos():ToScreen()
				surface.SetDrawColor(Color(255,0,0,200))
				surface.DrawRect(pos.x - size/2, pos.y - 10, size, 5)
			end
		end
	end
end
end
hook.Add("HUDPaint", "ESP", ESP)

function Asus() 
local mats = file.Find( "../materials/"..game.GetMap().."/*.vmt" )

for k, v in pairs( mats ) do

local name = string.gsub( v, ".vmt", "" )
local mat = Material(  game.GetMap().."/" .. name )

if GetConVarNumber("duck_asus") == 1 then
mat:SetMaterialFloat( "$alpha", 0.9)
end
	end
end
Asus()
	
local function CrosshairnHUD()
if GetConVarNumber("duck_crosshair_cross") == 1 then
		surface.SetTexture(surface.GetTextureID("vgui/white"))
		surface.SetDrawColor(GetConVarNumber("duck_crosshair_r")*1000,GetConVarNumber("duck_crosshair_g")*1000,GetConVarNumber("duck_crosshair_b")*1000,255)
	    surface.DrawTexturedRect(ScrW()/2-1,ScrH()/2-10,1.5,20)
        surface.DrawTexturedRect(ScrW()/2-10,ScrH()/2-1,20,1.5) 
end

if GetConVarNumber("duck_crosshair_dot") == 1 then
draw.RoundedBox(4, ScrW()/2-3,ScrH()/2-3,6,6,Color(GetConVarNumber("duck_crosshair_r")*1000,GetConVarNumber("duck_crosshair_g")*1000,GetConVarNumber("duck_crosshair_b")*1000,255))
end

if GetConVarNumber("duck_crosshair_circle") == 1 then
surface.SetTexture(surface.GetTextureID("vgui/white"))
surface.DrawCircle( ScrW()/2, ScrH()/2, 10, Color(GetConVarNumber("duck_crosshair_r")*1000,GetConVarNumber("duck_crosshair_g")*1000,GetConVarNumber("duck_crosshair_b")*1000,255) ) 
end
			
local Mirror = {} 

 Mirror.origin =  LocalPlayer():GetPos() + Vector(0,0,60)
  Mirror.angles = Angle(0, LocalPlayer():EyeAngles().y-180, 0)
	Mirror.w = 200
		Mirror.h = 60
			Mirror.x = 410
				Mirror.y = 20
		
	if GetConVarNumber("duck_hud") == 1 then
	draw.RoundedBox(0, 250, 10, 500, 80, Color(100,100,100,200))  
     surface.SetDrawColor( 0,0,0,255 )
      surface.DrawOutlinedRect( 250, 10, 500, 80)
	        surface.SetDrawColor( 255,255,255,255 )
	   surface.DrawOutlinedRect( 409, 19, 202, 62)
	
		draw.SimpleTextOutlined("Time: " .. os.date(), "TabLarge", 400, 30, Color(0, 100, 255, 255), 2, 1, 1, Color(0, 0, 0, 255))
		 draw.SimpleTextOutlined("Name:" .. " " .. LocalPlayer():Nick(), "TabLarge", 380, 60, Color(0, 255, 0, 255), 2, 1, 1, Color(0, 0, 0, 255))

				render.RenderView(Mirror)
						
						draw.SimpleTextOutlined("Entity Class Name:", "TabLarge",  730, 30, Color(255, 255, 255, 255), 2, 1, 1, Color(0, 0, 0, 255))
	local tr = util.GetPlayerTrace(LocalPlayer(), LocalPlayer():GetAimVector())
	local trace = util.TraceLine(tr)
	if trace.Hit && trace.HitNonWorld then
			local hite = trace.Entity
			local infoc = hite:GetClass()
	draw.SimpleTextOutlined(infoc, "TabLarge", 705, 60, Color(255, 255, 255, 255), 2, 1, 1, Color(0, 0, 0, 255))
			end

	local y = 105
	
	for _,ent in pairs(player.GetAll()) do						  
	
	if GetConVarNumber("duck_spec") == 1 then
	draw.SimpleTextOutlined("Spectators: ", "TabLarge", 320, 100, Color(255, 255, 255, 255), 2, 1, 1, Color(0, 0, 0, 255))
	
	if ent:GetObserverTarget() == LocalPlayer() then
		  y = y + 15
		draw.SimpleTextOutlined(ent:GetName(), "TabLarge", 320, y, Color(255, 255, 255, 255), 2, 1, 1, Color(0, 0, 0, 255))
	end
		end
				end
			
	end					
	
end
hook.Add("HUDPaint", "crosshair",  CrosshairnHUD)

local function Chams()
hook.Add("RenderScreenspaceEffects", "Chams", function()


if GetConVarNumber("Duck_Wallhack_Material") == 0 then
ChamMaterial = ""

elseif GetConVarNumber("Duck_Wallhack_Material") == 1 then
ChamMaterial = "models/debug/debugwhite"

elseif GetConVarNumber("Duck_Wallhack_Material") == 2 then
ChamMaterial = "debug/debugportals"

elseif GetConVarNumber("Duck_Wallhack_Material") == 3 then
ChamMaterial = "hlmv/debugmrmwireframe"

elseif GetConVarNumber("Duck_Wallhack_Material") == 4 then
ChamMaterial = "effects/flashlight/tech"

end

if GetConVarNumber("Duck_Wallhack_Outline_Material") == 0 then
OutlineMaterial = "debug/debugportals"

elseif GetConVarNumber("Duck_Wallhack_Outline_Material") == 1 then
OutlineMaterial = "hlmv/debugmrmwireframe"

end
	
	
if WallToggle then


		
for _, ent in pairs(ents.GetAll()) do	

if ent:IsNPC() then
col = Color(1,1,1,255)	    
ocol = Color(GetConVarNumber("Duck_Wallhack_Outline_Red"), GetConVarNumber("Duck_Wallhack_Outline_Green"), GetConVarNumber("Duck_Wallhack_Outline_Blue"),255)    		

elseif ent:IsPlayer() then

local tcol = team.GetColor(ent:Team()) 

if GetConVarNumber("Duck_Wallhack_C_Style") == 0 then//user defined
col = Color(GetConVarNumber("Duck_Wallhack_Red"), GetConVarNumber("Duck_Wallhack_Green"), GetConVarNumber("Duck_Wallhack_Blue"),255)	

elseif GetConVarNumber("Duck_Wallhack_C_Style") == 1 then//team	 
col =  Color(tcol.r/255,tcol.g/255,tcol.b/255,255)	           				

elseif GetConVarNumber("Duck_Wallhack_C_Style") == 2 then//health	          				
col =  Color( 1 - ( ent:Health() / 100 ), ( ent:Health() / 100 ), 0 ,255)  	           				

elseif GetConVarNumber("Duck_Wallhack_C_Style") == 3 then//chameleon
col = Color(0, 1, 0,255)
	end
	
if GetConVarNumber("Duck_Wallhack_OC_Style") == 0 then//user defined
ocol = Color(GetConVarNumber("Duck_Wallhack_Outline_Red"), GetConVarNumber("Duck_Wallhack_Outline_Green"), GetConVarNumber("Duck_Wallhack_Outline_Blue"),255)    

elseif GetConVarNumber("Duck_Wallhack_OC_Style") == 1 then//team
ocol = Color(tcol.r/255,tcol.g/255,tcol.b/255,255)	               				

elseif GetConVarNumber("Duck_Wallhack_OC_Style") == 2 then//health		 
ocol = Color( 1 - ( ent:Health() / 100 ), ( ent:Health() / 100 ), 0 ,255)  		 

elseif GetConVarNumber("Duck_Wallhack_OC_Style") == 3 then//chameleon
ocol = Color(1, 0, 0,255)
	end

if ent:GetFriendStatus() == "friend" then
col = Color(math.random(0,1),math.random(0,1),math.random(0,1),255)
ocol = Color(math.random(0,1),math.random(0,1),math.random(0,1),255)
end
	
	end

cam.Start3D(EyePos(),EyeAngles())
	
if WallFilter(ent) then
cam.IgnoreZ(true)

render.SetColorModulation(ocol.r,ocol.g,ocol.b)	           
ent:SetModelScale(Vector(1.02,1.1,1.01))

ent:SetMaterial(OutlineMaterial)

if GetConVarNumber("Duck_Wallhack_Outline") == 1 then
ent:DrawModel()
end

if GetConVarNumber("Duck_Wallhack_OC_Style") == 3 || GetConVarNumber("Duck_Wallhack_C_Style") == 3 then
cam.IgnoreZ(false)
end

render.SetColorModulation(col.r,col.g,col.b)
ent:SetModelScale(Vector(1,1,1))
ent:SetMaterial(ChamMaterial)
ent:DrawModel()

cam.IgnoreZ(false)

end
	cam.End3D()
	end
			end
				end)
					end
	
concommand.Add("Duck_Wallhack_Toggle", function()
    if WallToggle then

   hook.Remove( "RenderScreenspaceEffects", "Chams")
   
	WallToggle = false
    LocalPlayer():ChatPrint("Chams OFF")
	 
	 for _, ent in pairs(ents.GetAll()) do		
	 if WallFilter(ent) then
	 ent:SetMaterial("")
	 end
	 end
	
	elseif !WallToggle then	
    LocalPlayer():ChatPrint("Chams ON")
	Chams()
	WallToggle = true		
    end

	end)
	
require("sys")
concommand.Add("+duck_speed", function() hack.SetPlayerSpeed(GetConVarNumber("duck_speed")) end)
concommand.Add("-duck_speed", function() hack.SetPlayerSpeed(1) end)


local function unload()
hook.Remove( "HUDPaint", "Laser")
hook.Remove("HUDPaint", "ESP")
hook.Remove("HUDPaint", "crosshair")
end


concommand.Add("duck_menu", function()

//made the idea with dermadesigner. parented, linked and adjusted everything my self

local esp
local wallhack
local spam
local cvars
local listplayers
local chair
local misc
local mainimage
local speed
local fovaim
local aimbot
local mainpanel
local helpmainpanel
local helplabel10
local helplabel9
local helplabel8
local helplabel7
local helplabel6
local helplabel5
local helplabel4
local helplabel3
local helplabel2
local helplabel1
local helpmainframe
local address
local favorites
local mainbrowserpanel
local mainaimbotframe
local go
local refresh
local html
local forwards
local backwards
local url

local sizegrow = 10
local posgrow = -300
local alphagrow = 2
local zigzag1, zig1color = 100, Color(255,255,0,255)
local zigzag2, zig2color = 295, Color(0,0,0,0)

mainframe = vgui.Create("DFrame")

mainframe:SetPos(-300, 230)
mainframe:SetTitle("DuckBot Menu")
mainframe:SetDeleteOnClose(false)
mainframe:SetDraggable(false)
mainframe.Paint = function() 

sizegrow = sizegrow + 5
if sizegrow >326 then sizegrow = 326 end
mainframe:SetSize(sizegrow , 256 )

alphagrow = alphagrow + 0.2
zigzag1 = zigzag1 + 1




if zigzag1  > 295 then 
zig1color = Color(0,0,0,0)
zig2color = Color(255,255,0,255)
zigzag2 = zigzag2 - 1 end



if alphagrow > 25 then alphagrow = 25 end

draw.RoundedBox(0, 2, 2, mainframe:GetWide(), mainframe:GetTall(), Color(1, 1, 11,alphagrow*10))
surface.SetDrawColor(255,255,255,alphagrow*10)
surface.DrawOutlinedRect(0, 0, mainframe:GetWide(), mainframe:GetTall()) 
surface.DrawLine( 6, 20, 78,20 )
draw.RoundedBox(1, zigzag1, 15, 5, 5, zig1color)
draw.RoundedBox(1, zigzag2, 15, 5, 5, zig2color)
posgrow = posgrow + 19
mainframe:SetPos(posgrow, 230)
if zigzag2  < 100 then 
zigzag2 = 100
draw.SimpleText("DuckBot","Default",110,10,Color(255,255,255,255),0)
end
if posgrow > 100 then posgrow = 100 end
end
mainframe:MakePopup()


mainpanel = vgui.Create("DPanel")
mainpanel:SetParent(mainframe)
mainpanel:SetSize(312, 221)
mainpanel:ColorTo(Color(0,0,0,255), 4, 1)
 
mainpanel:SetPos(6, 27)
mainpanel.Paint = function() 
draw.RoundedBox(10, 2, 2, mainpanel:GetWide(), mainpanel:GetTall(), Color(255, 255, 255, alphagrow))
surface.SetDrawColor( Color(255, 255, 255, alphagrow*10)) 
surface.DrawOutlinedRect( 92, 2, 217, 78)
end


mainpanel:SetDisabled(false)

mainimage = vgui.Create("DImageButton")
mainimage:SetParent(mainpanel)
mainimage:SetSize(215, 76)
mainimage:SetPos(93, 3)
mainimage:SetImage("VGUI/entities/DuckBotNew")
mainimage.Paint = function()
surface.SetDrawColor( Color(255, 255, 255, 225)) 
surface.DrawOutlinedRect( 0, 0, mainimage:GetWide(), mainimage:GetTall())
end

mainimage.DoClick = function() 
    local Choice = DermaMenu()
   
   Choice:AddOption("Load", function() 
   include("autorun/client/DuckBot.lua")
   LocalPlayer():ChatPrint("DuckBot Loaded")
   surface.PlaySound( "/quack/duck_1.mp3" ) end ) 
   
   Choice:AddOption("Unload", function()     
   unload()
   LocalPlayer():ChatPrint("DuckBot Unloaded")
   surface.PlaySound( "/quack/duck_1.mp3" ) end )
	
   Choice:Open() 
   end

   
mainimage.DoRightClick = function() 
LocalPlayer():ChatPrint("plschangemek?")	
end




speed = vgui.Create("DNumSlider")
speed:SetSize(86, 40)
speed:SetParent(mainpanel)
speed:SetPos(2, 7)
speed:SetText("Speed")
speed:SetMin(0.1)
speed:SetMax(10)
speed:SetConVar("duck_speed")
speed:SetDecimals(2)
speed:SetValue(GetConVarNumber("duck_speed"))
speed.Paint = function()
draw.RoundedBox(1, 1, 35, 100, 3, Color(speed:GetValue()*50, 255-speed:GetValue()*20, 0, 225))
end
 /*function reloadModule(name)
_R._LOADED[name] = nil;
_G[name] = nil;
require(name);
end
--will need this, thanks wizard
*/

fovaim = vgui.Create("DNumSlider")
fovaim:SetSize(86, 40)
fovaim:SetParent(mainpanel)
fovaim:SetPos(2, 45)
fovaim:SetText("FOV")
fovaim:SetMin(-1)
fovaim:SetMax(0.99)
fovaim:SetConVar("duck_aim_fov")
fovaim:SetDecimals(2)
fovaim:SetValue(GetConVarNumber("duck_aim_fov"))

aimbot = vgui.Create("DButton")
aimbot:SetParent(mainpanel)
aimbot:SetSize(50, 50)
aimbot:SetPos(10, 84)
aimbot:SetText("Aimbot")

aimbot.DoClick = function()


/////////////////
/////////////////
/////////////////
/////////////////
local aimbotsteamcat
local aimbotteamcat
local aimbotoffset
local aimbotcomp
local aimbotauto
local aimbotdrawtarg
local aimbotnpccat
local aimbotplayercat
local mainaimbotpanel
local mainaimbotframe

mainaimbotframe = vgui.Create("DFrame")
mainaimbotframe:SetParent(aimbot)
mainaimbotframe:SetSize(229, 265)
mainaimbotframe:SetPos(158, 104)
mainaimbotframe:SetTitle("Aimbot")
mainaimbotframe:SetSizable(true)
mainaimbotframe:SetDeleteOnClose(false)
mainaimbotframe.Paint = function() 
draw.RoundedBox(0, 2, 2, mainaimbotframe:GetWide(), mainaimbotframe:GetTall(), Color(1, 1, 11, 225))
surface.SetDrawColor(color_white)
surface.DrawOutlinedRect(0, 0, mainaimbotframe:GetWide(), mainaimbotframe:GetTall()) end
mainaimbotframe:MakePopup()

mainaimbotpanel = vgui.Create("DPanel")
mainaimbotpanel:SetParent(mainaimbotframe)
mainaimbotpanel:SetSize(216, 228)
mainaimbotpanel:SetPos(7, 29)
mainaimbotpanel.Paint = function() 
draw.RoundedBox(10, 2, 2, mainaimbotpanel:GetWide(), mainaimbotpanel:GetTall(), Color(255, 255, 255, alphagrow))
end

aimbotsteamcat = vgui.Create("DCheckBoxLabel")
aimbotsteamcat:SetParent(mainaimbotpanel)
aimbotsteamcat:SetPos(17, 13)
aimbotsteamcat:SetText("Ignore Steam Friends")
aimbotsteamcat:SetConVar("duck_aim_friends")
aimbotsteamcat:SetValue(GetConVarNumber("duck_aim_friends"))
aimbotsteamcat:SizeToContents()

aimbotteamcat = vgui.Create("DCheckBoxLabel")
aimbotteamcat:SetParent(mainaimbotpanel)
aimbotteamcat:SetPos(17, 43)
aimbotteamcat:SetText("Ignore Team Mates")
aimbotteamcat:SetConVar("duck_aim_team")
aimbotteamcat:SetValue(GetConVarNumber("duck_aim_team"))
aimbotteamcat:SizeToContents()

aimbotoffset = vgui.Create("DNumSlider")
aimbotoffset:SetSize(154, 40)
aimbotoffset:SetParent(mainaimbotpanel)
aimbotoffset:SetPos(17, 73)
aimbotoffset:SetDecimals(0)
aimbotoffset:SetText("Aim Offset")
aimbotoffset:SetMinMax( -10, 10)
aimbotoffset:SetConVar("duck_aim_plus")



aimbotcomp = vgui.Create("DNumSlider")
aimbotcomp:SetSize(154, 40)
aimbotcomp:SetParent(mainaimbotpanel)
aimbotcomp:SetPos(17, 123)
aimbotcomp:SetDecimals(0)
aimbotcomp:SetText("Compensation Offset")
aimbotcomp:SetMinMax(10, 70)
aimbotcomp:SetConVar("duck_aim_comp")

aimbotnpccat = vgui.Create("DCheckBoxLabel")
aimbotnpccat:SetParent(mainaimbotpanel)
aimbotnpccat:SetPos(17, 173)
aimbotnpccat:SetText("Aim At NPCs")
aimbotnpccat:SetConVar("duck_aim_npc")
aimbotnpccat:SetValue(GetConVarNumber("duck_aim_npc"))
aimbotnpccat:SizeToContents()

aimbotplayercat = vgui.Create("DCheckBoxLabel")
aimbotplayercat:SetParent(mainaimbotpanel)
aimbotplayercat:SetPos(107, 173)
aimbotplayercat:SetText("Aim At Players")
aimbotplayercat:SetConVar("duck_aim_player")
aimbotplayercat:SetValue(GetConVarNumber("duck_aim_player"))
aimbotplayercat:SizeToContents()

aimbotdrawtarg = vgui.Create("DCheckBoxLabel")
aimbotdrawtarg:SetParent(mainaimbotpanel)
aimbotdrawtarg:SetPos(107, 203)
aimbotdrawtarg:SetText("Line To Target")
aimbotdrawtarg:SetConVar("duck_aim_draw")
aimbotdrawtarg:SetValue(GetConVarNumber("duck_aim_draw"))
aimbotdrawtarg:SizeToContents()

aimbotauto = vgui.Create("DCheckBoxLabel")
aimbotauto:SetParent(mainaimbotpanel)
aimbotauto:SetPos(17, 203)
aimbotauto:SetText("Auto Fire")
aimbotauto:SetConVar("duck_aim_auto")
aimbotauto:SetValue(GetConVarNumber("duck_aim_auto"))
aimbotauto:SizeToContents()

 end
/////////////////
/////////////////
/////////////////
/////////////////
 
 
  local DSpritea = vgui.Create( "DSprite" )
DSpritea:SetParent(mainpanel)
DSpritea:SetPos( 19, 126 )
DSpritea:SetSize( 15, 15 )
DSpritea:SetMaterial( Material( "gui/silkicons/add" ) )
 
 
 
misc = vgui.Create("DButton")
misc:SetParent(mainpanel)
misc:SetSize(50, 50)
misc:SetPos(90, 84)
misc:SetText("Misc")

misc.DoClick = function() 
/////////////////
/////////////////
/////////////////
/////////////////
local adminlist
local miscns
local misctrigger
local misctriggerhead
local misczoom
local miscmainpanel
local miscmainframe
local miscnsmethod
local miscbhop

miscmainframe = vgui.Create("DFrame")
miscmainframe:SetParent(misc)
miscmainframe:SetSize(229, 265)
miscmainframe:SetPos(158, 104)
miscmainframe:SetTitle("Misc")
miscmainframe:SetSizable(true)
miscmainframe:SetDeleteOnClose(false)
miscmainframe.Paint = function() 
draw.RoundedBox(0, 2, 2, miscmainframe:GetWide(), miscmainframe:GetTall(), Color(1, 1, 11, 225))
surface.SetDrawColor(color_white)
surface.DrawOutlinedRect(0, 0, miscmainframe:GetWide(), miscmainframe:GetTall()) end
miscmainframe:MakePopup()


miscmainpanel = vgui.Create("DPanel")
miscmainpanel:SetParent(miscmainframe)
miscmainpanel:SetSize(216, 228)
miscmainpanel:SetPos(7, 29)
miscmainpanel.Paint = function() 
draw.RoundedBox(10, 2, 2, miscmainpanel:GetWide(), miscmainpanel:GetTall(), Color(255, 255, 255, 20))
end


miscns = vgui.Create("DCheckBoxLabel")
miscns:SetParent(miscmainpanel)
miscns:SetPos(17, 13)
miscns:SetText("NoSpread")
miscns:SetConVar("duck_sys_nospread")
miscns:SetValue(GetConVarNumber("duck_sys_nospread"))
miscns:SizeToContents()

miscnsmethod = vgui.Create("DButton")
miscnsmethod:SetParent(miscmainpanel)
miscnsmethod:SetPos(107, 13)
miscnsmethod:SetSize(100, 20)
miscnsmethod:SetText("ON Method")
miscnsmethod.DoClick = function ()
    local miscnsmethod = DermaMenu()
    miscnsmethod:AddOption("On Fire", function() 		RunConsoleCommand("duck_sys_nospread_onmethod", "0") end ) 
    miscnsmethod:AddOption("On Alt Fire", function() 	RunConsoleCommand("duck_sys_nospread_onmethod", "1") end )
    miscnsmethod:AddOption("Always", function() 		RunConsoleCommand("duck_sys_nospread_onmethod", "2") end )
miscnsmethod:Open() 
end

misczoom = vgui.Create("DCheckBoxLabel")
misczoom:SetParent(miscmainpanel)
misczoom:SetPos(17, 43)
misczoom:SetText("Zoom")
misczoom:SetConVar("duck_zoom")
misczoom:SetValue(GetConVarNumber("duck_zoom"))
misczoom:SizeToContents()

miscbhop = vgui.Create("DCheckBoxLabel")
miscbhop:SetParent(miscmainpanel)
miscbhop:SetPos(107, 43)
miscbhop:SetText("Auto Jump")
miscbhop:SetConVar("duck_bhop")
miscbhop:SetValue(GetConVarNumber("duck_nhop"))
miscbhop:SizeToContents()

misctrigger = vgui.Create("DCheckBoxLabel")
misctrigger:SetParent(miscmainpanel)
misctrigger:SetPos(17, 73)
misctrigger:SetText("TriggerBot")
misctrigger:SetConVar("duck_trigger")
misctrigger:SetValue(GetConVarNumber("duck_trigger"))
misctrigger:SizeToContents()

misctriggerhead = vgui.Create("DCheckBoxLabel")
misctriggerhead:SetParent(miscmainpanel)
misctriggerhead:SetPos(107, 73)
misctriggerhead:SetText("TriggerBot Head")
misctriggerhead:SetConVar("duck_trigger_head")
misctriggerhead:SetValue(GetConVarNumber("duck_trigger_head"))
misctriggerhead:SizeToContents()


adminslist = vgui.Create("DListView")
adminslist:SetParent(miscmainpanel)
adminslist:SetSize(182, 101)
adminslist:SetPos(17, 105)
adminslist:SetMultiSelect(false)
adminslist:AddColumn("Admins") 
adminslist:AddColumn("Status") 

for k,v in pairs(player.GetAll()) do
  if IsAdmin(v) then
  adminslist:AddLine(v:Nick(),GetAdminType(v)) 
end
end

/////////////////
/////////////////
/////////////////
/////////////////
end


  local DSpritem = vgui.Create( "DSprite" )
DSpritem:SetParent(mainpanel)
DSpritem:SetPos( 99, 127)
DSpritem:SetSize( 15, 15 )
DSpritem:SetMaterial( Material( "gui/silkicons/box" ) )


chair = vgui.Create("DButton")
chair:SetParent(mainpanel)
chair:SetSize(50, 50)
chair:SetPos(170, 84)
chair:SetText("Visuals")
chair.DoClick = function() 

/////////////////
/////////////////
/////////////////
/////////////////

local visualcross
local visualdot
local visualcircle
local visualred
local visualgreen
local visualblue
local visualasus
local visualhud
local visuallaser1
local visuallaser2
local visualfb
local visualspec
local visualmainpanel
local visualmainframe

visualmainframe = vgui.Create("DFrame")
visualmainframe:SetParent(chair)
visualmainframe:SetSize(229, 265)
visualmainframe:SetPos(158, 104)
visualmainframe:SetTitle("Visuals")
visualmainframe:SetSizable(true)
visualmainframe:SetDeleteOnClose(false)
visualmainframe.Paint = function() 
draw.RoundedBox(0, 2, 2, visualmainframe:GetWide(), visualmainframe:GetTall(), Color(1, 1, 11, 225))
surface.SetDrawColor(color_white)
surface.DrawOutlinedRect(0, 0, visualmainframe:GetWide(), visualmainframe:GetTall()) end
visualmainframe:MakePopup()

visualmainpanel = vgui.Create("DPanel")
visualmainpanel:SetParent(visualmainframe)
visualmainpanel:SetSize(216, 228)
visualmainpanel:SetPos(7, 29)
visualmainpanel.Paint = function() 
draw.RoundedBox(10, 2, 2, visualmainpanel:GetWide(), visualmainpanel:GetTall(), Color(255, 255, 255, 20))
end

visualcross = vgui.Create("DCheckBoxLabel")
visualcross:SetParent(visualmainpanel)
visualcross:SetPos(17, 13)
visualcross:SetText("Cross")
visualcross:SetConVar("duck_crosshair_cross")
visualcross:SetValue(GetConVarNumber("duck_crosshair_cross"))
visualcross:SizeToContents()

visualdot = vgui.Create("DCheckBoxLabel")
visualdot:SetParent(visualmainpanel)
visualdot:SetPos(77, 13)
visualdot:SetText("Dot")
visualdot:SetConVar("duck_crosshair_dot")
visualdot:SetValue(GetConVarNumber("duck_crosshair_dot"))
visualdot:SizeToContents()

visualcircle = vgui.Create("DCheckBoxLabel")
visualcircle:SetParent(visualmainpanel)
visualcircle:SetPos(137, 13)
visualcircle:SetText("Circle")
visualcircle:SetConVar("duck_crosshair_circle")
visualcircle:SetValue(GetConVarNumber("duck_crosshair_circle"))
visualcircle:SizeToContents()

visualred = vgui.Create("DCheckBoxLabel")
visualred:SetParent(visualmainpanel)
visualred:SetPos(17, 33)
visualred:SetText("Red")
visualred:SetConVar("duck_crosshair_r")
visualred:SetValue(GetConVarNumber("duck_crosshair_cross"))
visualred:SizeToContents()

visualgreen = vgui.Create("DCheckBoxLabel")
visualgreen:SetParent(visualmainpanel)
visualgreen:SetPos(77, 33)
visualgreen:SetText("Green")
visualgreen:SetConVar("duck_crosshair_g")
visualgreen:SetValue(GetConVarNumber("duck_crosshair_dot"))
visualgreen:SizeToContents()

visualblue = vgui.Create("DCheckBoxLabel")
visualblue:SetParent(visualmainpanel)
visualblue:SetPos(137, 33)
visualblue:SetText("Blue")
visualblue:SetConVar("duck_crosshair_b")
visualblue:SetValue(GetConVarNumber("duck_crosshair_circle"))
visualblue:SizeToContents()

visualasus = vgui.Create("DCheckBoxLabel")
visualasus:SetParent(visualmainpanel)
visualasus:SetPos(17, 63)
visualasus:SetText("Transparent Walls(Asus)")
visualasus:SetConVar("duck_asus")
visualasus:SetValue(GetConVarNumber("duck_asus"))
visualasus:SizeToContents()

visualhud = vgui.Create("DCheckBoxLabel")
visualhud:SetParent(visualmainpanel)
visualhud:SetPos(17, 93)
visualhud:SetText("Heads Up Display")
visualhud:SetConVar("duck_hud")
visualhud:SetValue(GetConVarNumber("duck_hud"))
visualhud:SizeToContents()

visuallaser1 = vgui.Create("DCheckBoxLabel")
visuallaser1:SetParent(visualmainpanel)
visuallaser1:SetPos(17, 123)
visuallaser1:SetText("Laser ")
visuallaser1:SetConVar("duck_laser")
visuallaser1:SetValue(GetConVarNumber("duck_laser"))
visuallaser1:SizeToContents()

visuallaser2 = vgui.Create("DCheckBoxLabel")
visuallaser2:SetParent(visualmainpanel)
visuallaser2:SetPos(97, 123)
visuallaser2:SetText("Laser Dot")
visuallaser2:SetConVar("duck_laser_dot")
visuallaser2:SetValue(GetConVarNumber("duck_laser_dot"))
visuallaser2:SizeToContents()
	


visualspec = vgui.Create("DCheckBoxLabel")
visualspec:SetParent(visualmainpanel)
visualspec:SetPos(17, 163)
visualspec:SetText("Show Spectators in chat")
visualspec:SetConVar("duck_spec")
visualspec:SetValue(GetConVarNumber("duck_spec"))
visualspec:SizeToContents()

visualfb = vgui.Create("DCheckBoxLabel")
visualfb:SetParent(visualmainpanel)
visualfb:SetPos(17, 193)
visualfb:SetText("Full-Bright")
visualfb:SetConVar("mat_fullbright")
visualfb:SetValue(GetConVarNumber("mat_fullbright"))
visualfb:SizeToContents()

/////////////////
/////////////////
/////////////////
/////////////////
end


  local DSpritev = vgui.Create( "DSprite" )
DSpritev:SetParent(mainpanel)
DSpritev:SetPos( 179, 125)
DSpritev:SetSize( 15, 15 )
DSpritev:SetMaterial( Material( "gui/silkicons/palette" ) )




listplayers = vgui.Create("DButton")
listplayers:SetParent(mainpanel)
listplayers:SetSize(50, 50)
listplayers:SetPos(250, 84)
listplayers:SetText("List")
listplayers.DoClick = function() 

/////////////////
/////////////////
/////////////////
/////////////////
local listplayerlist
local listplayerclearaim
local listplayercleartag
local listplayermainframe
local listplayermainpanel

listplayermainframe = vgui.Create("DFrame")
listplayermainframe:SetParent(listplayers)
listplayermainframe:SetSize(229, 265)
listplayermainframe:SetPos(158, 104)
listplayermainframe:SetTitle("Player List")
listplayermainframe:SetSizable(true)
listplayermainframe:SetDeleteOnClose(false)
listplayermainframe.Paint = function() 
draw.RoundedBox(0, 2, 2, listplayermainframe:GetWide(), listplayermainframe:GetTall(), Color(1, 1, 11, 225))
surface.SetDrawColor(color_white)
surface.DrawOutlinedRect(0, 0, listplayermainframe:GetWide(), listplayermainframe:GetTall()) end
listplayermainframe:MakePopup()

listplayermainpanel = vgui.Create("DPanel")
listplayermainpanel:SetParent(listplayermainframe)
listplayermainpanel:SetSize(216, 228)
listplayermainpanel:SetPos(7, 29)
listplayermainpanel.Paint = function() 
draw.RoundedBox(10, 2, 2, listplayermainpanel:GetWide(), listplayermainpanel:GetTall(), Color(255, 255, 255, 20))
end

listplayerclearaim = vgui.Create("DButton")
listplayerclearaim:SetParent(listplayermainpanel)
listplayerclearaim:SetSize(202, 18)
listplayerclearaim:SetPos(7, 198)
listplayerclearaim:SetText("Clear Ignored Players")
listplayerclearaim.DoClick = function() table.Empty(Friends) end




listplayercleartag = vgui.Create("DButton")
listplayercleartag:SetParent(listplayermainpanel)
listplayercleartag:SetSize(202, 18)
listplayercleartag:SetPos(7, 175)
listplayercleartag:SetText("Clear Tagged Players")
listplayercleartag.DoClick = function() table.Empty(Tagged) end

local listplayerlist = vgui.Create("DListView")
listplayerlist:SetParent(listplayermainpanel)
listplayerlist:SetSize(202, 157)
listplayerlist:SetPos(7, 8)
listplayerlist:SetMultiSelect(false)
listplayerlist:AddColumn("Name") 
listplayerlist:AddColumn("Friend") 


for k,ent in pairs(player.GetAll()) do 
if ent == LocalPlayer() then else

 local check



 if table.HasValue(Friends, ent:Nick())
 then check = "YES!"
 else
 check = "NO!"
 end
 listplayerlist:AddLine(ent:Nick(), check) 
 end
 end

 
listplayerlist.DoDoubleClick = function(parent, index, list)
local listplayerlistOptions = DermaMenu()
listplayerlistOptions:AddOption("Add To AimBot Friends", function() table.insert(Friends,list:GetValue(1)) end) 
listplayerlistOptions:AddOption("Tag", function() table.insert(Tagged,list:GetValue(1)) end) 
listplayerlistOptions:Open() 
end



/////////////////
/////////////////
/////////////////
/////////////////
end

 local DSpritel = vgui.Create( "DSprite" )
DSpritel:SetParent(mainpanel)
DSpritel:SetPos( 259, 127)
DSpritel:SetSize( 15, 15 )
DSpritel:SetMaterial( Material( "gui/silkicons/application_view_detail" ) )


cvars = vgui.Create("DButton")
cvars:SetParent(mainpanel)
cvars:SetSize(50, 50)
cvars:SetPos(250, 169)
cvars:SetText("Names")
cvars.DoClick = function()
/////////////////
/////////////////
/////////////////
/////////////////
local namemainframe
local namemainpanel
local namefill
local fillname
local namelist
local nameall
local nameblank
local namenormal
local namerand


namemainframe = vgui.Create('DFrame')
namemainframe:SetParent(mainframe)
namemainframe:SetSize(229, 265)
namemainframe:SetPos(158, 103)
namemainframe:SetTitle('Name Changer')
namemainframe:SetSizable(true)
namemainframe:SetDeleteOnClose(false)
namemainframe:SetVisible(true)
namemainframe.Paint = function() 
draw.RoundedBox(0, 2, 2, namemainframe:GetWide(), namemainframe:GetTall(), Color(1, 1, 11, 225))
surface.SetDrawColor(color_white)
surface.DrawOutlinedRect(0, 0, namemainframe:GetWide(), namemainframe:GetTall()) end
namemainframe:MakePopup()


namemainpanel = vgui.Create('DPanel')
namemainpanel:SetParent(namemainframe)
namemainpanel:SetSize(216, 228)
namemainpanel:SetPos(7, 30)
namemainpanel.Paint = function() 
draw.RoundedBox(10, 2, 2, namemainpanel:GetWide(), namemainpanel:GetTall(), Color(255, 255, 255, 20))
end

fillname = vgui.Create('DTextEntry')
fillname:SetParent(namemainpanel)
fillname:SetSize(180, 20)
fillname:SetPos(17, 15)
fillname:SetText("Fill Me")


namefill = vgui.Create('Button')
namefill:SetParent(namemainpanel)
namefill:SetSize(180, 20)
namefill:SetPos(17, 45)
namefill:SetText("Set")
namefill.DoClick = function() 
hook.Remove("Think", "nm")
hook.Remove("Think", "nm2")
LocalCommand("name " .. fillname:GetValue()) end


namelist = vgui.Create("DListView")
namelist:SetParent(namemainpanel)
namelist:SetSize(180, 95)
namelist:SetPos(17, 75)
namelist:SetMultiSelect(false)
namelist:AddColumn("Name") 

for k,v in pairs(player.GetAll()) do
  if LocalPlayer() == v then else
  namelist:AddLine(v:Nick()) 
  end
  end
namelist.DoDoubleClick = function(parent, index, list)
hook.Remove("Think", "nm")
hook.Remove("Think", "nm2")
LocalCommand("name ".. list:GetValue(1) .. string.char(1))
end
namenormal = vgui.Create('Button')
namenormal:SetParent(namemainpanel)
namenormal:SetSize(45, 20)
namenormal:SetPos(17, 180)
namenormal:SetText("Default")
namenormal.DoClick = function()
hook.Remove("Think", "nm")
hook.Remove("Think", "nm2")
LocalCommand("name Victormeriqui") end

local randomnames1 = {"bob","faggot","tryone","little kid","derp","nawp","fr1kin","c0bra","fisheater","avoine","ph0ne","JC","edward","1337","airwick","duck","cpu","troll","hitler","seth","flapadar","namegod","god","aimbot","asdfg","minge","butt","rocket","vent","mars","coder","lua","cool kid","dong","admin","dollar","radar","volley team","black guy","kid","wizard","moon","space","narry","icey","melvin","avaster"}
local randomnames2 = {"nigger","jew","nazi","hacker","faggot","shit","god","1337","skiddie","terrorrist","admin","owner","legit","pr0","man"}

namerand = vgui.Create('Button')
namerand:SetParent(namemainpanel)
namerand:SetSize(45, 20)
namerand:SetPos(107, 180)
namerand:SetText("Random")
namerand.DoClick = function() hook.Add("Think", "nm", function() LocalCommand("name " .. table.Random(randomnames1) .. " the " .. table.Random(randomnames2) .. " N" .. math.random(0.001, 10)) end) 
hook.Remove("Think", "nm2")
end

nameblank = vgui.Create('Button')
nameblank:SetParent(namemainpanel)
nameblank:SetSize(45, 20)
nameblank:SetPos(62, 180)
nameblank:SetText("Blank")
nameblank.DoClick = function() LocalCommand("name " .. string.char(1)) 
hook.Remove("Think", "nm")
hook.Remove("Think", "nm2")
end

local namestealall = vgui.Create('Button')
namestealall:SetParent(namemainpanel)
namestealall:SetSize(45, 20)
namestealall:SetPos(152, 180)
namestealall:SetText("All")
namestealall.DoClick = function() 
	

local nicks = {}
for _,ent in pairs (player.GetAll()) do
if ent == LocalPlayer() then else
table.insert(nicks,ent:Nick())
hook.Remove("Think", "nm")
hook.Add("Think","nm2",function()
LocalCommand("name " .. table.Random(nicks) .. string.char(1))
end)
end
end
end
end

/////////////////
/////////////////
/////////////////
/////////////////



  local DSpritec = vgui.Create( "DSprite" )
DSpritec:SetParent(mainpanel)
DSpritec:SetPos( 258, 211)
DSpritec:SetSize( 15, 15 )
DSpritec:SetMaterial( Material( "gui/silkicons/group" ) )
 
spam = vgui.Create("DButton")
spam:SetParent(mainpanel)
spam:SetSize(50, 50)
spam:SetPos(170, 169)
spam:SetText("Spammer")
spam.DoClick = function()
/////////////////
/////////////////
/////////////////
/////////////////
local spampropoff
local spampropon
local spamlabel2
local spammodel
local spamchatoff
local spamchaton
local spamtime1
local spamchat
local spamlabel1
local spammainpanel
local spammainframe

spammainframe = vgui.Create("DFrame")
spammainframe:SetParent(spam)
spammainframe:SetSize(229, 265)
spammainframe:SetPos(158, 104)
spammainframe:SetTitle("Spammer Bot")
spammainframe:SetSizable(true)
spammainframe:SetDeleteOnClose(false)
spammainframe.Paint = function() 
draw.RoundedBox(0, 2, 2, spammainframe:GetWide(), spammainframe:GetTall(), Color(1, 1, 11, 225))
surface.SetDrawColor(color_white)
surface.DrawOutlinedRect(0, 0, spammainframe:GetWide(), spammainframe:GetTall()) end
spammainframe:MakePopup()

spammainpanel = vgui.Create("DPanel")
spammainpanel:SetParent(spammainframe)
spammainpanel:SetSize(216, 228)
spammainpanel:SetPos(7, 29)
spammainpanel.Paint = function() 
draw.RoundedBox(10, 2, 2, spammainpanel:GetWide(), spammainpanel:GetTall(), Color(255, 255, 255, 20)) 
end

spamlabel1 = vgui.Create("DLabel")
spamlabel1:SetParent(spammainpanel)
spamlabel1:SetPos(17, 13)
spamlabel1:SetText("Chat Spam: ")
spamlabel1:SizeToContents()

spamchat = vgui.Create("DTextEntry")
spamchat:SetParent(spammainpanel)
spamchat:SetSize(182, 31)
spamchat:SetPos(17, 34)
spamchat:SetText("Insert Spam Message Here")


spamtime1 = vgui.Create("DNumSlider")
spamtime1:SetSize(182, 40)
spamtime1:SetParent(spammainpanel)
spamtime1:SetPos(16, 68)
spamtime1:SetDecimals(3)
spamtime1:SetText("Frequency")
spamtime1:SetConVar("duck_spam_time")
spamtime1:SetValue(GetConVarNumber("duck_spam_time"))
spamtime1:SetMinMax( 0.001, 3)

spamchaton = vgui.Create("DButton")
spamchaton:SetParent(spammainpanel)
spamchaton:SetSize(91, 25)
spamchaton:SetPos(17, 111)
spamchaton:SetText("Spam Chat")
spamchaton.DoClick = function() 
timer.Create("SpamChat", GetConVarNumber("duck_spam_time"), 0, function() RunConsoleCommand("say", spamchat:GetValue()) end)
end

spamchatoff = vgui.Create("DButton")
spamchatoff:SetParent(spammainpanel)
spamchatoff:SetSize(91, 25)
spamchatoff:SetPos(109, 111)
spamchatoff:SetText("Stop Spam")
spamchatoff.DoClick = function()
timer.Destroy("SpamChat")
 end

spammodel = vgui.Create("DTextEntry")
spammodel:SetParent(spammainpanel)
spammodel:SetSize(182, 23)
spammodel:SetPos(17, 162)
spammodel:SetText("Insert Model Path Here")


spamlabel2 = vgui.Create("DLabel")
spamlabel2:SetParent(spammainpanel)
spamlabel2:SetPos(17, 141)
spamlabel2:SetText("Prop Spam")
spamlabel2:SizeToContents()

spampropon = vgui.Create("DButton")
spampropon:SetParent(spammainpanel)
spampropon:SetSize(91, 25)
spampropon:SetPos(17, 189)
spampropon:SetText("Spam Prop")
spampropon.DoClick = function() 
timer.Create("SpamProp", 0.001, 0, function() RunConsoleCommand("gm_spawn", spammodel:GetValue()) end)
end

spampropoff = vgui.Create("DButton")
spampropoff:SetParent(spammainpanel)
spampropoff:SetSize(91, 25)
spampropoff:SetPos(109, 189)
spampropoff:SetText("Stop Spam")
spampropoff.DoClick = function() 
timer.Destroy("SpamProp")
end
/////////////////
/////////////////
/////////////////
/////////////////
end

  local DSprites = vgui.Create( "DSprite" )
DSprites:SetParent(mainpanel)
DSprites:SetPos( 178, 211)
DSprites:SetSize( 15, 15 )
DSprites:SetMaterial( Material( "gui/silkicons/exclamation" ) )

wallhack = vgui.Create("DButton")
wallhack:SetParent(mainpanel)
wallhack:SetSize(50, 50)
wallhack:SetPos(90, 169)
wallhack:SetText("WallHack")
wallhack.DoClick = function() 
/////////////////
/////////////////
/////////////////
/////////////////
local whmainpanel
local whmat
local whomat
local whb
local whg
local whr
local whob
local whog
local whor
local whre
local whteam
local whon
local whmainframe
local whoutline
local whcstyle
local whocstyle

whmainframe = vgui.Create("DFrame")
whmainframe:SetParent(wallhack)
whmainframe:SetSize(229, 265)
whmainframe:SetPos(158, 104)
whmainframe:SetTitle("WallHack")
whmainframe:SetSizable(true)
whmainframe:SetDeleteOnClose(false)
whmainframe.Paint = function() 
draw.RoundedBox(0, 2, 2, whmainframe:GetWide(), whmainframe:GetTall(), Color(1, 1, 11, 225))
surface.SetDrawColor(color_white)
surface.DrawOutlinedRect(0, 0, whmainframe:GetWide(), whmainframe:GetTall()) end
whmainframe:MakePopup()

whmainpanel = vgui.Create("DPanel")
whmainpanel:SetParent(whmainframe)
whmainpanel:SetSize(216, 228)
whmainpanel:SetPos(7, 29)
whmainpanel.Paint = function() 
draw.RoundedBox(10, 2, 2, whmainpanel:GetWide(), whmainpanel:GetTall(), Color(255, 255, 255, 20))
end

whon =  vgui.Create("DButton")
whon:SetParent(whmainpanel)
whon:SetSize(190,25)
whon:SetPos(17, 13)
whon:SetText("WallHack Toggle")
whon.DoClick = function() 	RunConsoleCommand("duck_wallhack_toggle") end


whteam = vgui.Create("DCheckBoxLabel")
whteam:SetParent(whmainpanel)
whteam:SetPos(17, 43)
whteam:SetText("Team Mode")
whteam:SetConVar("duck_wallhack_team")
whteam:SetValue(GetConVarNumber("duck_teamw"))
whteam:SizeToContents()

whoutline = vgui.Create("DCheckBoxLabel")
whoutline:SetParent(whmainpanel)
whoutline:SetPos(107, 43)
whoutline:SetText("Outline")
whoutline:SetConVar("duck_wallhack_outline")
whoutline:SetValue(GetConVarNumber("duck_wallhack_outline"))
whoutline:SizeToContents()

whr = vgui.Create("DCheckBoxLabel")
whr:SetParent(whmainpanel)
whr:SetPos(17, 73)
whr:SetText("Red")
whr:SetConVar("duck_wallhack_Red")
whr:SetValue(GetConVarNumber("duck_wallhack_Red"))
whr:SizeToContents()

whor = vgui.Create("DCheckBoxLabel")
whor:SetParent(whmainpanel)
whor:SetPos(107, 73)
whor:SetText("Outline Red")
whor:SetConVar("duck_wallhack_outline_Red")
whor:SetValue(GetConVarNumber("duck_wallhack_outline_Red"))
whor:SizeToContents()



whg = vgui.Create("DCheckBoxLabel")
whg:SetParent(whmainpanel)
whg:SetPos(17, 103)
whg:SetText("Green")
whg:SetConVar("duck_wallhack_green")
whg:SetValue(GetConVarNumber("duck_wallhack_green"))
whg:SizeToContents()


whog = vgui.Create("DCheckBoxLabel")
whog:SetParent(whmainpanel)
whog:SetPos(107, 103)
whog:SetText("Outline Green")
whog:SetConVar("duck_wallhack_outline_Green")
whog:SetValue(GetConVarNumber("duck_wallhack_outline_Green"))
whog:SizeToContents()



whb = vgui.Create("DCheckBoxLabel")
whb:SetParent(whmainpanel)
whb:SetPos(17, 133)
whb:SetText("Blue")
whb:SetConVar("duck_wallhack_blue")
whb:SetValue(GetConVarNumber("duck_wallhack_blue"))
whb:SizeToContents()

whob = vgui.Create("DCheckBoxLabel")
whob:SetParent(whmainpanel)
whob:SetPos(107, 133)
whob:SetText("Outline Blue")
whob:SetConVar("duck_wallhack_outline_Blue")
whob:SetValue(GetConVarNumber("duck_wallhack_outline_Blue"))
whob:SizeToContents()



		whmat = vgui.Create("DButton") 
        whmat:SetParent(whmainpanel)
        whmat:SetSize(90, 28)
        whmat:SetPos(15, 188)
		whmat:SetText("Material")
       whmat.DoClick = function ()
    local whmatChoice = DermaMenu()
      whmatChoice:AddOption("No Wall", function() 	RunConsoleCommand("duck_wallhack_material", "0") end ) 
		whmatChoice:AddOption("Full", function() 	RunConsoleCommand("duck_wallhack_material", "1")  end ) 
			whmatChoice:AddOption("Full 2D", function() 	RunConsoleCommand("duck_wallhack_material", "2")  end ) 
				whmatChoice:AddOption("WireFrame", function() 	RunConsoleCommand("duck_wallhack_material", "3")  end ) 
					whmatChoice:AddOption("Tech", function() 	RunConsoleCommand("duck_wallhack_material", "4")  end ) 

 
 whmatChoice:Open() 
end

		whomat = vgui.Create("DButton") 
        whomat:SetParent(whmainpanel)
        whomat:SetSize(90, 28)
        whomat:SetPos(113, 188)
		whomat:SetText("Material")
       whomat.DoClick = function ()
    local whomatChoice = DermaMenu()
		whomatChoice:AddOption("Full", function() 	RunConsoleCommand("duck_wallhack_outline_material", "0")  end ) 
				whomatChoice:AddOption("WireFrame", function() 	RunConsoleCommand("duck_wallhack_outline_material", "1")  end ) 

 
 whomatChoice:Open() 
end

whcstyle = vgui.Create("DButton") 
        whcstyle:SetParent(whmainpanel)
        whcstyle:SetSize(90, 28)
        whcstyle:SetPos(15, 158)
		whcstyle:SetText("Style")
       whcstyle.DoClick = function ()
    local whcstyleChoice = DermaMenu()
    whcstyleChoice:AddOption("Self Defined", function()RunConsoleCommand("duck_wallhack_c_style", "0") end) 
		whcstyleChoice:AddOption("Relative To Team Color", function()RunConsoleCommand("duck_wallhack_c_style", "1")  end) 
			whcstyleChoice:AddOption("Relative To Health", function()RunConsoleCommand("duck_wallhack_c_style", "2")  end) 
				whcstyleChoice:AddOption("Chameleon", function()RunConsoleCommand("duck_wallhack_c_style", "3")  end) 

 
 whcstyleChoice:Open() 
end

whocstyle = vgui.Create("DButton") 
        whocstyle:SetParent(whmainpanel)
        whocstyle:SetSize(90, 28)
        whocstyle:SetPos(113, 158)
		whocstyle:SetText("Outline Style")
       whocstyle.DoClick = function ()
    local whocstyleChoice = DermaMenu()
    whocstyleChoice:AddOption("Self Defined", function()RunConsoleCommand("duck_wallhack_oc_style", "0") end) 
		whocstyleChoice:AddOption("Relative To Team Color", function()RunConsoleCommand("duck_wallhack_oc_style", "1")  end) 
			whocstyleChoice:AddOption("Relative To Health", function()RunConsoleCommand("duck_wallhack_oc_style", "2")  end) 
				whocstyleChoice:AddOption("Chameleon", function()RunConsoleCommand("duck_wallhack_oc_style", "3")  end) 

 
 whocstyleChoice:Open() 
end
/////////////////
/////////////////
/////////////////
/////////////////
end
 
 local DSpritew = vgui.Create( "DSprite" )
DSpritew:SetParent(mainpanel)
DSpritew:SetPos( 98, 211)
DSpritew:SetSize( 15, 15 )
DSpritew:SetMaterial( Material( "gui/silkicons/user" ) )

esp = vgui.Create("DButton")
esp:SetParent(mainpanel)
esp:SetSize(50, 50)
esp:SetPos(10, 169)
esp:SetText("ESP")
esp.DoClick = function()

/////////////////
/////////////////
/////////////////
/////////////////

local esplabel2
local esplabel3
local espmultfont
local esplabel4
local espmulttype
local espmultcolor
local esplabel5
local espwepicon
local esplabel6
local espmulttype2
local esplabel8
local espc4
local esptraitor
local esplabel7
local espvisible
local espweapon
local espskeleton
local esphealth
local espname
local esplabel1
local espmainpanel
local espnades
local espmainframe

espmainframe = vgui.Create("DFrame")
espmainframe:SetParent(esp)
espmainframe:SetSize(229, 265)
espmainframe:SetPos(158, 104)
espmainframe:SetTitle("ESP")
espmainframe:SetSizable(true)
espmainframe:SetDeleteOnClose(false)
espmainframe.Paint = function() 
draw.RoundedBox(0, 2, 2, espmainframe:GetWide(), espmainframe:GetTall(), Color(1, 1, 11, 225))
surface.SetDrawColor(color_white)
surface.DrawOutlinedRect(0, 0, espmainframe:GetWide(), espmainframe:GetTall()) end
espmainframe:MakePopup()

espmainpanel = vgui.Create("DPanel")
espmainpanel:SetParent(espmainframe)
espmainpanel:SetSize(216, 228)
espmainpanel:SetPos(7, 29)
espmainpanel.Paint = function() 
draw.RoundedBox(10, 2, 2, espmainpanel:GetWide(), espmainpanel:GetTall(), Color(255, 255, 255, 20))
end

esplabel1 = vgui.Create("DLabel")
esplabel1:SetParent(espmainpanel)
esplabel1:SetPos(17, 10)
esplabel1:SetText("Display:")
esplabel1:SizeToContents()

espname = vgui.Create("DCheckBoxLabel")
espname:SetParent(espmainpanel)
espname:SetPos(17, 30)
espname:SetText("Name")
espname:SetConVar("duck_esp")
espname:SetValue(GetConVarNumber("duck_esp"))
espname:SizeToContents()

esphealth = vgui.Create("DCheckBoxLabel")
esphealth:SetParent(espmainpanel)
esphealth:SetPos(17, 60)
esphealth:SetText("Health")
esphealth:SetConVar("duck_esp_phealth")
esphealth:SetValue(GetConVarNumber("duck_esp_phealth"))
esphealth:SizeToContents()

espskeleton = vgui.Create("DCheckBoxLabel")
espskeleton:SetParent(espmainpanel)
espskeleton:SetPos(17, 90)
espskeleton:SetText("Skeleton")
espskeleton:SetConVar("duck_esp_pskeleton")
espskeleton:SetValue(GetConVarNumber("duck_esp_pskeleton"))
espskeleton:SizeToContents()

espweapon = vgui.Create("DCheckBoxLabel")
espweapon:SetParent(espmainpanel)
espweapon:SetPos(17, 120)
espweapon:SetText("Weapon")
espweapon:SetConVar("duck_esp_pweapon")
espweapon:SetValue(GetConVarNumber("duck_esp_pweapon"))
espweapon:SizeToContents()

espvisible = vgui.Create("DCheckBoxLabel")
espvisible:SetParent(espmainpanel)
espvisible:SetPos(17, 150)
espvisible:SetText("Visibility")
espvisible:SetConVar("duck_esp_pvisible")
espvisible:SetValue(GetConVarNumber("duck_esp_pvisible"))
espvisible:SizeToContents()

esplabel7 = vgui.Create("DLabel")
esplabel7:SetParent(espmainpanel)
esplabel7:SetPos(17, 180)
esplabel7:SetText("Game Mode:")
esplabel7:SizeToContents()

esplabel8 = vgui.Create("DLabel")
esplabel8:SetParent(espmainpanel)
esplabel8:SetPos(80, 180)
esplabel8:SetText(GAMEMODE.Name)
esplabel8:SizeToContents()

if string.find(GAMEMODE.Name,"Trouble in Terrorist Town") then
esptraitor = vgui.Create("DCheckBoxLabel")
esptraitor:SetParent(espmainpanel)
esptraitor:SetPos(17, 200)
esptraitor:SetText("Traitors")
esptraitor:SetConVar("duck_esp_ttt_traitor")
esptraitor:SetValue(GetConVarNumber("duck_esp_ttt_traitor"))
esptraitor:SizeToContents()

espc4 = vgui.Create("DCheckBoxLabel")
espc4:SetParent(espmainpanel)
espc4:SetPos(87, 200)
espc4:SetText("C4")
espc4:SetConVar("duck_esp_ttt_c4")
espc4:SetValue(GetConVarNumber("duck_esp_ttt_c4"))
espc4:SizeToContents()

espnades = vgui.Create("DCheckBoxLabel")
espnades:SetParent(espmainpanel)
espnades:SetPos(137, 200)
espnades:SetText("Grenades")
espnades:SetConVar("duck_esp_ttt_nade")
espnades:SetValue(GetConVarNumber("duck_esp_ttt_nade"))
espnades:SizeToContents()
else
esptraitor = vgui.Create("DLabel")
esptraitor:SetParent(espmainpanel)
esptraitor:SetPos(17, 200)
esptraitor:SetText("NO EXTRAS")
esptraitor:SetTextColor(Color(255, 0, 0, 255))
esptraitor:SizeToContents()
end

espmulttype2 = vgui.Create("DMultiChoice")
espmulttype2:SetParent(espmainpanel)
espmulttype2:SetPos(117, 148)
espmulttype2:SetSize(90, 20)
espmulttype2.OnSelect = function(Index, Value, Data) 
RunConsoleCommand("duck_esp_pvisibletype", Value)
end
espmulttype2:AddChoice("Circle")
espmulttype2:AddChoice("Square")


esplabel6 = vgui.Create("DLabel")
esplabel6:SetParent(espmainpanel)
esplabel6:SetPos(85, 150)
esplabel6:SetText("Type:")
esplabel6:SizeToContents()

espwepicon = vgui.Create("DCheckBoxLabel")
espwepicon:SetParent(espmainpanel)
espwepicon:SetPos(85, 120)
espwepicon:SetText("Show Icon If Possible")
espwepicon:SetConVar("duck_esp_pweaponicon")
espwepicon:SetValue(GetConVarNumber("duck_esp_pweaponicon"))
espwepicon:SizeToContents()

esplabel5 = vgui.Create("DLabel")
esplabel5:SetParent(espmainpanel)
esplabel5:SetPos(85, 90)
esplabel5:SetText("Color:")
esplabel5:SizeToContents()

espmultcolor = vgui.Create("DMultiChoice")
espmultcolor:SetParent(espmainpanel)
espmultcolor:SetPos(117, 88)
espmultcolor:SetSize(90, 20)
espmultcolor.OnSelect = function(Index, Value, Data) 
RunConsoleCommand("duck_esp_pskeletoncol", Value)
end
espmultcolor:AddChoice("Health")
espmultcolor:AddChoice("Team Color")
espmultcolor:AddChoice("Visibility")

espmulttype = vgui.Create("DMultiChoice")
espmulttype:SetParent(espmainpanel)
espmulttype:SetPos(117, 58)
espmulttype:SetSize(90, 20)
espmulttype.OnSelect = function(Index, Value, Data) 
RunConsoleCommand("duck_esp_phtype", Value)
end
espmulttype:AddChoice("Sharp")
espmulttype:AddChoice("Rectangle")
espmulttype:AddChoice("Outlined Rectangle")

esplabel4 = vgui.Create("DLabel")
esplabel4:SetParent(espmainpanel)
esplabel4:SetPos(85, 60)
esplabel4:SetText("Type:")
esplabel4:SizeToContents()

espmultfont = vgui.Create("DMultiChoice")
espmultfont:SetParent(espmainpanel)
espmultfont:SetPos(117, 28)
espmultfont:SetSize(90, 20)
espmultfont.OnSelect = function(Index, Value, Data) 
RunConsoleCommand("duck_esp_font", Value)
end
espmultfont:AddChoice("AVP")
espmultfont:AddChoice("Simple")
espmultfont:AddChoice("Simple Outlined")
espmultfont:AddChoice("Simple Shadow")
espmultfont:AddChoice("Big")
espmultfont:AddChoice("Bold Italic")

esplabel3 = vgui.Create("DLabel")
esplabel3:SetParent(espmainpanel)
esplabel3:SetPos(87, 30)
esplabel3:SetText("Font:")
esplabel3:SizeToContents()

esplabel2 = vgui.Create("DLabel")
esplabel2:SetParent(espmainpanel)
esplabel2:SetPos(107, 10)
esplabel2:SetText("Options:")
esplabel2:SizeToContents()



/////////////////
/////////////////
/////////////////
/////////////////

 end

  local DSpritee = vgui.Create( "DSprite" )
DSpritee:SetParent(mainpanel)
DSpritee:SetPos( 19, 212)
DSpritee:SetSize( 15, 15 )
DSpritee:SetMaterial( Material( "gui/silkicons/application_view_tile" ) )
 
end)
print("DuckBot Loaded")


// fr1kin was here lol my hack is almost 4000 lines long its crazylol