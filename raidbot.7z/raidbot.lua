--[[
	s0beit_by_B.lua
	This Toast is traitor | (STEAM_0:0:43676365)
	===DStream===
]]

local b_aim = 0
local b_esp = 1
local b_cross = 1
local b_menu_show = 1
local dist = 5000
local crosstype = 1
local xrad = 200
local yrad = 200
local xPos = 10
local yPos = 10
local radar2 = 1
local radar = {}
local current = 1
------
local function bMaterial()
local aimmodels
aimmodels = {
        ["models/combine_scanner.mdl"] = "Scanner.Body",
        ["models/hunter.mdl"] = "MiniStrider.body_joint",
        ["models/combine_turrets/floor_turret.mdl"] = "Barrel",
        ["models/dog.mdl"] = "Dog_Model.Eye",
        ["models/antlion.mdl"] = "Antlion.Body_Bone",
        ["models/antlion_guard.mdl"] = "Antlion_Guard.Body",
        ["models/antlion_worker.mdl"] = "Antlion.Head_Bone",
        ["models/zombie/fast_torso.mdl"] = "ValveBiped.HC_BodyCube",
        ["models/zombie/fast.mdl"] = "ValveBiped.HC_BodyCube",
        ["models/headcrabclassic.mdl"] = "HeadcrabClassic.SpineControl",
        ["models/headcrabblack.mdl"] = "HCBlack.body",
        ["models/headcrab.mdl"] = "HCFast.body",
        ["models/zombie/poison.mdl"] = "ValveBiped.Headcrab_Cube1",
        ["models/zombie/classic.mdl"] = "ValveBiped.HC_Body_Bone",
        ["models/zombie/classic_torso.mdl"] = "ValveBiped.HC_Body_Bone",
        ["models/zombie/zombie_soldier.mdl"] = "ValveBiped.HC_Body_Bone",
        ["models/combine_strider.mdl"] = "Combine_Strider.Body_Bone",
        ["models/lamarr.mdl"] = "HeadcrabClassic.SpineControl"
}
local PredictWeapons = {
		["weapon_crossbow"] = 3110,
	}

local function WeaponPrediction( e, pos )
	local ply = LocalPlayer()
	if ( ValidEntity( e ) && ( type( e:GetVelocity() ) == "Vector" ) ) then
	if ValidEntity(ply:GetActiveWeapon()) then
		local dis, wep = e:GetPos():Distance( ply:GetPos() ), ply:GetActiveWeapon():GetClass()
		if ( wep && wep:GetClass()=="weapon_crossbow"  ) then
			local t = (dis / 3500) + 0.05
					local mul = 0.0075
					local pos = ( pos + e:GetVelocity() * t )
			pos = pos - (e:GetVelocity() * mul)
			local crossbowspeed = (LocalPlayer():GetCurrentCommand():GetViewAngles()):Forward() * 3500
			local time2crossbow = (pos:Length() - LocalPlayer():GetPos():Length() )/(((crossbowspeed):Length()) - ((e:GetVelocity()):Length()))
			pos.z = pos.z
			return pos
		end
	end
	end
	return pos
end
local function prediction( tar, compensate )
	local ply = LocalPlayer()
		local tarFrames, plyFrames = ( FrameTime() / 25 ), ( FrameTime() / 66 )
		return compensate + ( ( tar:GetVelocity() * ( tarFrames ) ) - ( ply:GetVelocity() * ( plyFrames ) ) )
		--return compensate + tar:GetVelocity() * (1/66) - LocalPlayer():GetVelocity() * (1/66)
end
local Texture = {
  ["$basetexture"] = "models/debug/debugwhite",
  ["$model"]       = 1,
  ["$translucent"] = 1,
  ["$alpha"]       = 1,
  ["$nocull"]      = 1,
  ["$ignorez"]  = 1
}
local Texture2 = {
  ["$basetexture"] = "models/debug/debugwhite",
  ["$model"]       = 1,
  ["$translucent"] = 1,
  ["$alpha"]       = 1,
  ["$nocull"]      = 1,
}
   
local material = CreateMaterial( "bSolid", "VertexLitGeneric", Texture )
local material2 = CreateMaterial( "bSolid2", "VertexLitGeneric", Texture2 )
return material,material2

end


local function bChams()
for k, v in pairs( ents.FindByClass("npc_*") ) do
if ValidEntity( v ) then
cam.Start3D( EyePos(), EyeAngles() )
local m = bMaterial()
render.SuppressEngineLighting( true )
render.SetColorModulation( 255, 0, 0 )
SetMaterialOverride( m )
v:DrawModel()
render.SuppressEngineLighting( false )
render.SetColorModulation( 1, 1, 1 )
SetMaterialOverride()
v:DrawModel()
cam.End3D()
			end
		end
	end
hook.Add( "RenderScreenspaceEffects", "bChams", bChams )
------
aimmodels = {
        ["models/combine_scanner.mdl"] = "Scanner.Body",
        ["models/hunter.mdl"] = "MiniStrider.body_joint",
        ["models/combine_turrets/floor_turret.mdl"] = "Barrel",
        ["models/dog.mdl"] = "Dog_Model.Eye",
        ["models/antlion.mdl"] = "Antlion.Body_Bone",
        ["models/antlion_guard.mdl"] = "Antlion_Guard.Body",
        ["models/antlion_worker.mdl"] = "Antlion.Head_Bone",
        ["models/zombie/fast_torso.mdl"] = "ValveBiped.HC_BodyCube",
        ["models/zombie/fast.mdl"] = "ValveBiped.HC_BodyCube",
        ["models/headcrabclassic.mdl"] = "HeadcrabClassic.SpineControl",
        ["models/headcrabblack.mdl"] = "HCBlack.body",
        ["models/headcrab.mdl"] = "HCFast.body",
        ["models/zombie/poison.mdl"] = "ValveBiped.Headcrab_Cube1",
        ["models/zombie/classic.mdl"] = "ValveBiped.HC_Body_Bone",
        ["models/zombie/classic_torso.mdl"] = "ValveBiped.HC_Body_Bone",
        ["models/zombie/zombie_soldier.mdl"] = "ValveBiped.HC_Body_Bone",
        ["models/combine_strider.mdl"] = "Combine_Strider.Body_Bone",
        ["models/lamarr.mdl"] = "HeadcrabClassic.SpineControl"
}
local function HeadPos(ply) 
    if ValidEntity(ply) then 
if (ply:GetClass()=="npc_tripmine") && (ply:GetClass()=="npc_satchel") && (ply:GetClass()=="npc_grenade_frag") then
return false
end
local pos
local usingAttachments
	if ( ply:GetAttachment( ply:LookupAttachment( "eyes" ) ) ) then
		pos = ply:GetAttachment( ply:LookupAttachment( "eyes" ) ).Pos;
	elseif ( ply:GetAttachment( ply:LookupAttachment( "forward" ) ) ) then
		pos = ply:GetAttachment( ply:LookupAttachment("forward") ).Pos;
	elseif ( ply:GetAttachment( ply:LookupAttachment( "head" ) ) ) then
		pos = ply:GetAttachment( ply:LookupAttachment( "head" ) ).Pos;
	else
	local bone = (aimmodels[ ply:GetModel() ] or "ValveBiped.Bip01_Head1")
	local hbone = ply:LookupBone(bone) 
        pos = ply:GetBonePosition(hbone) 
	end
		local plyl = LocalPlayer()
		local tarFrames, plyFrames = ( FrameTime() / 25 ), ( FrameTime() / 66 )
	if ( ValidEntity( ply ) && ( type( ply:GetVelocity() ) == "Vector" ) ) then
	if ValidEntity(ply:GetActiveWeapon()) then
		local dis, wep = ply:GetPos():Distance( plyl:GetPos() ), plyl:GetActiveWeapon():GetClass()
		if ( wep ) then
		if (wep:GetClass() == "weapon_crossbow") then
			local t = (dis / 3500) + 0.05
					local mul = 0.0075
			pos = ( pos + ply:GetVelocity() * t )
			pos = pos - (ply:GetVelocity() * mul)
			local crossbowspeed = (LocalPlayer():GetCurrentCommand():GetViewAngles()):Forward() * 3500
			local time2crossbow = (pos:Length() - LocalPlayer():GetPos():Length() )/(((crossbowspeed):Length()) - ((e:GetVelocity()):Length()))
			pos.z = pos.z
		end
		end
	end
	end
	return ( ( ply:GetVelocity() * ( tarFrames ) ) - ( plyl:GetVelocity() * ( plyFrames ) ) )
    else return end 
end

local function Visible(ply) 
    local trace = {start = LocalPlayer():GetShootPos(),endpos = HeadPos(ply),filter = {LocalPlayer(), ply}} 
    local tr = util.TraceLine(trace) 
    if tr.Fraction == 1 then 
        return true 
    else 
        return false 
    end     
end 
--[[hook.Add("RenderScreenspaceEffects","",function()
cam.Start3D(EyePos(), EyeAngles())
for k, v in pairs(ents.GetAll()) do
			local mat = v:GetMaterial()
			render.SuppressEngineLighting( true )
			render.SetColorModulation( 1, 0, 0)
			v:SetModelScale(Vector(1.1,1.1,1))
			entityxsetmaterial(v, "debug/white")
			v:DrawModel()
			render.SuppressEngineLighting( false )
			render.SetColorModulation( 1, 1, 1 )
			v:SetModelScale(Vector(1,1,1))
			entityxsetmaterial(v, mat)
			v:DrawModel()
end 
cam.End3D()
end)]]--
function box( e )
	local ply, pos = LocalPlayer(), nil
	local center = e:LocalToWorld( e:OBBCenter() )
	local min, max = e:OBBMins(), e:OBBMaxs()
	local dim = max - min
	local z = max + min
	
	local frt	= ( e:GetForward() ) * ( dim.y / 2 )
	local rgt	= ( e:GetRight() ) * ( dim.x / 2 )
	local top	= ( e:GetUp() ) * ( dim.z / 2 )
	local bak	= ( e:GetForward() * -1 ) * ( dim.y / 2 )
	local lft	= ( e:GetRight() * -1 ) * ( dim.x / 2 )
	local btm	= ( e:GetUp() * -1 ) * ( dim.z / 2 )
	
	local d, v = math.Round( e:GetPos():Distance( ply:GetShootPos() ) )
	v = d / 30
	
	pos = e:LocalToWorld( top + top ) + Vector( 0, 0, v + 10 )
	if ( e:IsWeapon() ) then pos = e:LocalToWorld( e:OBBCenter() ) end
	
	local FRT 	= center + frt + rgt + top; FRT = FRT:ToScreen()
	local BLB 	= center + bak + lft + btm; BLB = BLB:ToScreen()
	local FLT	= center + frt + lft + top; FLT = FLT:ToScreen()
	local BRT 	= center + bak + rgt + top; BRT = BRT:ToScreen()
	local BLT 	= center + bak + lft + top; BLT = BLT:ToScreen()
	local FRB 	= center + frt + rgt + btm; FRB = FRB:ToScreen()
	local FLB 	= center + frt + lft + btm; FLB = FLB:ToScreen()
	local BRB 	= center + bak + rgt + btm; BRB = BRB:ToScreen()
	
	pos = pos:ToScreen()
	
	local maxX = math.max( FRT.x,BLB.x,FLT.x,BRT.x,BLT.x,FRB.x,FLB.x,BRB.x )
	local minX = math.min( FRT.x,BLB.x,FLT.x,BRT.x,BLT.x,FRB.x,FLB.x,BRB.x )
	local maxY = math.max( FRT.y,BLB.y,FLT.y,BRT.y,BLT.y,FRB.y,FLB.y,BRB.y)
	local minY = math.min( FRT.y,BLB.y,FLT.y,BRT.y,BLT.y,FRB.y,FLB.y,BRB.y )
	
	return maxX, minX, maxY, minY
end

local function IsSteamFriend( ply ) 
    return ply:GetFriendStatus() == "friend" 
end 

local function FillRGBA(x,y,w,h,col) 
    surface.SetDrawColor( col.r, col.g, col.b, col.a ); 
    surface.DrawRect( x, y, w, h ); 
end 

local function OutlineRGBA(x,y,w,h,col) 
    surface.SetDrawColor( col.r, col.g, col.b, col.a ); 
    surface.DrawOutlinedRect( x, y, w, h ); 
end 
local aim_active = false
local function GetMeta(name)
	return table.Copy(_R[name] or {})
end

local AngM = GetMeta("Angle")
local CmdM = GetMeta("CUserCmd")
local EntM = GetMeta("Entity")
local PlyM = GetMeta("Player")
local VecM = GetMeta("Vector")
function TargetPrediction(ply, target, targetPos)
    return targetPos
end
local spread = 0
hook.Add("CreateMove", "lulz", function(cmd)
if b_aim == 1 then
			for k, NPCs in pairs(ents.FindByClass("npc_*")) do
			local ply = LocalPlayer()
			if Visible(NPCs) && !NPCs.IsDead then
			if NPCs:GetMoveType() == MOVETYPE_NONE then return false end
			local targetheadpos = HeadPos(NPCs)
			LocalPlayer():GetActiveWeapon().SetNextPrimaryFire( LocalPlayer():GetActiveWeapon() )
			--local restangs = cmd:GetViewAngles()
			aim_active = true
			local targetPos
			targetPos = ((targetheadpos - ply:GetShootPos()):Angle())
			targetPos = TargetPrediction(LocalPlayer(),NPCs,targetPos)
			targetPos.z = 0
			--local eyeang = LocalPlayer():EyeAngles():ToScreen()
			--if (targetPos:ToScreen().x - eyeang.x) < 30 then
			--if (targetPos:ToScreen().y - eyeang.y) < 30 then
			--local fov = 2
			--if( fov != 180 ) then
                --local lpang = LocalPlayer():GetAngles()
                --local ang = ( NPCs:GetPos() - LocalPlayer():GetPos() ):Angle()
                --local ady = math.abs( math.NormalizeAngle( lpang.y - ang.y ) )
                --local adp = math.abs( math.NormalizeAngle( lpang.p - ang.p ) )
                --if( ady > fov || adp > fov ) then
				--else
				cmd:SetViewAngles(PredictSpread(cmd,targetPos))
				--end
			--end
			aim_active = false
			RunConsoleCommand( "+attack" )
			--timer.Simple( 0.01, function() cmd:SetViewAngles(restangs) end )
			timer.Simple( 0.01, function() RunConsoleCommand( "-attack" ) end )
			--end 
			--end
			end
			end
			for k, plys in pairs(player.GetAll()) do
			local ply = LocalPlayer()
			if Visible(plys) && (plys:Health() > 0) then
			if plys != LocalPlayer() then
			if plys:GetMoveType() == MOVETYPE_NONE then return false end
			local targetheadpos = HeadPos(plys)
			LocalPlayer():GetActiveWeapon().SetNextPrimaryFire( LocalPlayer():GetActiveWeapon() )
			--local restangs = cmd:GetViewAngles()
			--if (targetPos:ToScreen().x - eyeang.x) < 30 then
			--if (targetPos:ToScreen().y - eyeang.y) < 30 then
			--local fov = 2
			--if( fov != 180 ) then
                --local lpang = LocalPlayer():GetAngles()
                --local ang = ( plys:GetPos() - LocalPlayer():GetPos() ):Angle()
                --local ady = math.abs( math.NormalizeAngle( lpang.y - ang.y ) )
                --local adp = math.abs( math.NormalizeAngle( lpang.p - ang.p ) )
                --if( ady > fov || adp > fov ) then
				--else
				cmd:SetViewAngles(PredictSpread(cmd,targetPos))
				--end
			--end
			RunConsoleCommand( "+attack" )
			--timer.Simple( 0.01, function() cmd:SetViewAngles(restangs) end )
			timer.Simple( 0.01, function() RunConsoleCommand( "-attack" ) end )
			--end 
			--end
			end
			end
	end
	end
end)
local function DrawCrosshair() 
    local x = ScrW() / 2; 
    local y = ScrH() / 2; 
    surface.SetDrawColor(0,0,0,255)
	surface.DrawLine( x-26, y+1, x+26, y+1 )
	surface.DrawLine( x-26, y-1, x+26, y-1 )
	surface.DrawLine( x-26, y-0, x+26, y-0 )
	surface.DrawLine( x-0, y-26, x-0, y+26 )
	surface.DrawLine( x-1, y-26, x-1, y+26 )
	surface.DrawLine( x+1, y-26, x+1, y+26 )
	surface.SetDrawColor( 255,255,255,255 )
	surface.DrawLine( x-25, y, x+25, y )
	surface.DrawLine( x, y-25, x, y+25 )
	surface.SetDrawColor( 0,0,255,255 )
	surface.DrawLine( x-7, y, x+7, y )
	surface.DrawLine( x, y-7, x, y+7 )
	if LocalPlayer():KeyDown(IN_ATTACK) then
	surface.SetDrawColor( 0,255,255,255 )
	surface.DrawLine( x-18, y-18, x+18, y+18 )
	surface.DrawLine( x-18, y+18, x+18, y-18 )
	surface.SetDrawColor( 0,0,255,255 )
	surface.DrawLine( x-5, y-5, x+5, y+5 )
	surface.DrawLine( x-5, y+5, x+5, y-5 )
	end
end 
local function DrawCrosshair2() 
--gets the center of the screen
local x = ScrW() / 2
local y = ScrH() / 2
 
--set the drawcolor
surface.SetDrawColor( 255, 0, 0, 255 )
 
local gap = 10
local length = gap + 10
 
--draw the crosshair
surface.SetDrawColor( 255, 0, 0, 255 )
surface.DrawLine( x, y - length, x, y - gap )
surface.DrawLine( x, y + length, x, y + gap )
surface.DrawLine( x - length, y, x - gap, y )
surface.DrawLine( x + length, y, x + gap, y )
surface.DrawLine( x, y - length, x, y - gap )
surface.DrawLine( x, y + length, x, y + gap )

end 
function round(num)
    under = math.floor(num)
    upper = math.floor(num) + 1
    underV = -(under - num)
    upperV = upper - num
    if (upperV > underV) then
        return under
    else
        return upper
    end
end
function DrawESP() 
    if b_esp == 1 then 
        for k, v in pairs(ents.GetAll()) do 
            if( ValidEntity(v) and v ~= LocalPlayer() ) then 
				surface.SetDrawColor( 0, 0, 0, 10 ); 
				surface.DrawRect( ScrW()/4+(ScrW()/8), 0, 200, 20 ); 
				surface.SetDrawColor( 255, 0, 0, 255 ); 
				surface.DrawOutlinedRect( ScrW()/4+(ScrW()/8), 0, 200, 20 ); 
				local textData = {}
				textData.pos = {} 
				textData.pos[1] = ScrW()/4+(ScrW()/8)+100; 
				textData.pos[2] = 6; 
				textData.color = Color(0,172,255,255); 
				textData.text = " B-Hacks"
				textData.font = "TabLarge"; 
				textData.xalign = TEXT_ALIGN_CENTER; 
				textData.yalign = TEXT_ALIGN_CENTER; 
				draw.Text( textData ); 
                if( v:IsNPC() ) then 
                    local drawColor = Color(255, 255, 255, 255); 
                    local drawPosit = v:GetPos():ToScreen(); 
                     
                    if( Visible(v) ) then 
                        drawColor = Color( 255, 0, 0, 255 ); 
                    else 
                        drawColor = Color( 0, 255, 255, 255 ); 
                    end 
						local time = CurTime() * -180        
						local gap = 5
						local length = gap + 10
						surface.SetDrawColor(drawColor)
						DrawRotatingCrosshair((HeadPos(v):ToScreen()).x,(HeadPos(v):ToScreen()).y,time,length,gap)
						DrawRotatingCrosshair((HeadPos(v):ToScreen()).x,(HeadPos(v):ToScreen()).y,time + 90, length,gap)
						DrawRotatingCrosshair((HeadPos(v):ToScreen()).x,(HeadPos(v):ToScreen()).y,time + 180,length,gap)
						DrawRotatingCrosshair((HeadPos(v):ToScreen()).x,(HeadPos(v):ToScreen()).y,time + 270,length,gap)
				local maxX, minX, maxY, minY = box(v)
				surface.SetDrawColor(drawColor)
				surface.DrawLine( maxX, maxY, maxX, minY )
				surface.DrawLine( maxX, minY, minX, minY )
					
				surface.DrawLine( minX, minY, minX, maxY )
				surface.DrawLine( minX, maxY, maxX, maxY )
                    local textData = {} 
					draw.RoundedBox( 1, (HeadPos(v):ToScreen()).x-2, (HeadPos(v):ToScreen()).y-2, 4, 4, drawColor )
                    textData.pos = {} 
                    textData.pos[1] = maxX+2; 
                    textData.pos[2] = minY+5; 
                    textData.color = drawColor; 
                    textData.text = v:GetClass(); 
                    textData.font = "DefaultFixed"; 
                    textData.xalign = TEXT_ALIGN_LEFT; 
                    textData.yalign = TEXT_ALIGN_LEFT; 
                    draw.Text( textData ); 
                    textData.pos = {} 
                    textData.pos[1] = minX-2; 
                    textData.pos[2] = minY+5; 
                    textData.color = drawColor; 
                    textData.text = "Distance: "..round(v:GetPos():Distance(LocalPlayer():GetPos())/45).."m" 
                    textData.font = "DefaultFixed"; 
                    textData.xalign = TEXT_ALIGN_RIGHT; 
                    textData.yalign = TEXT_ALIGN_RIGHT; 
                    draw.Text( textData ); 
                elseif( v:IsPlayer() and v:Health() > 0 and v:Alive() ) then 
                    local drawColor = team.GetColor(v:Team()); 
                    local drawPosit = v:GetPos():ToScreen(); 
                     
                    if( Visible(v) ) then 
                        drawColor.a = 255; 
                    else 
                        drawColor.r = 255 - drawColor.r; 
                        drawColor.g = 255 - drawColor.g; 
                        drawColor.b = 255 - drawColor.b; 
                    end 
                local maxX, minX, maxY, minY = box(v)
				surface.SetDrawColor(drawColor)
				surface.DrawLine( maxX, maxY, maxX, minY )
				surface.DrawLine( maxX, minY, minX, minY )
					
				surface.DrawLine( minX, minY, minX, maxY )
				surface.DrawLine( minX, maxY, maxX, maxY )
					local textData = {} 
					    local time = CurTime() * -180        
						local gap = 5
						local length = gap + 10
						surface.SetDrawColor(drawColor)
						DrawRotatingCrosshair((HeadPos(v):ToScreen()).x,(HeadPos(v):ToScreen()).y,time,length,gap)
						DrawRotatingCrosshair((HeadPos(v):ToScreen()).x,(HeadPos(v):ToScreen()).y,time + 90, length,gap)
						DrawRotatingCrosshair((HeadPos(v):ToScreen()).x,(HeadPos(v):ToScreen()).y,time + 180,length,gap)
						DrawRotatingCrosshair((HeadPos(v):ToScreen()).x,(HeadPos(v):ToScreen()).y,time + 270,length,gap)
                    draw.RoundedBox( 1, (HeadPos(v):ToScreen()).x-2, (HeadPos(v):ToScreen()).y-2, 4, 4, drawColor )
                    textData.pos = {} 
                    textData.pos[1] = maxX+2; 
                    textData.pos[2] = minY+14; 
                    textData.color = drawColor; 
                    textData.text = v:GetName(); 
                    textData.font = "DefaultFixed"; 
                    textData.xalign = TEXT_ALIGN_LEFT; 
                    textData.yalign = TEXT_ALIGN_LEFT; 
                    draw.Text( textData ); 
                    textData.pos = {} 
                    textData.pos[1] = minX-2; 
                    textData.pos[2] = minY+14; 
                    textData.color = drawColor; 
                    textData.text = "Distance: "..round(v:GetPos():Distance(LocalPlayer():GetPos())/45).."m" 
                    textData.font = "DefaultFixed"; 
                    textData.xalign = TEXT_ALIGN_RIGHT; 
                    textData.yalign = TEXT_ALIGN_RIGHT; 
                    draw.Text( textData ); 
					if ValidEntity(v:GetActiveWeapon()) then
					textData.pos = {} 
                    textData.pos[1] = minX-2; 
                    textData.pos[2] = minY+22; 
                    textData.color = drawColor; 
                    textData.text = "Weapon: "..(v:GetActiveWeapon():GetClass())
                    textData.font = "DefaultFixed"; 
                    textData.xalign = TEXT_ALIGN_RIGHT; 
                    textData.yalign = TEXT_ALIGN_RIGHT; 
                    draw.Text( textData ); 
					end
                    textData.pos = {} 
                    textData.pos[1] = maxX+2; 
                    textData.pos[2] = minY+22; 
                    textData.color = drawColor; 
                    textData.text = "Health: "..(v:Health())
                    textData.font = "DefaultFixed"; 
                    textData.xalign = TEXT_ALIGN_LEFT; 
                    textData.yalign = TEXT_ALIGN_LEFT; 
                    draw.Text( textData ); 
                    local max_health = 100; 
                     
                    if( v:Health() > max_health ) then 
                        max_health = v:Health(); 
                    end 
                     
                    local mx = max_health / 4; 
                    local mw = v:Health() / 4; 
                     
                    local drawPosHealth = drawPosit; 
					surface.SetDrawColor(0,0,0,255)
					surface.DrawRect(maxX+2,minY+5,mx+6,6)
					surface.SetDrawColor(0,mw*2+50,0,255)
					surface.DrawRect(maxX+3,minY+6,mw+4,4)
				end 
            end 
        end 
    end 
	    if radar2==1 then
			surface.SetDrawColor(0,0,255,255)
            surface.DrawRect( xPos-5, yPos-5, xrad+10, yrad+30 );
			surface.SetDrawColor(100,100,100,255)
            surface.DrawRect( xPos, yPos, xrad, yrad );
			local time = (CurTime()*2) * -180        
			surface.SetDrawColor(255,255,255,255)
			DrawRotatingCrosshair(xPos+(xrad/2),yPos+(yrad/2),time,xrad/2,0)
			surface.SetDrawColor(255,255,255,255)
            surface.DrawOutlinedRect( xPos, yPos, xrad, yrad );
			surface.DrawOutlinedRect( xPos, yPos, xrad/2, yrad ); 
			surface.DrawOutlinedRect( xPos, yPos, xrad, yrad/2 ); 
			draw.DrawText("BB9Radar", "Default", xPos, yPos-5+yrad+10, Color(0,255,0,255), TEXT_ALIGN_LEFT)

	radar.w = xrad
radar.h = yrad
radar.x = xPos
radar.y = yPos
radar.alphascale = 0.6
radar.bgcolor = Color(255,0,0,255)
radar.fgcolor = Color(0,0,255,255)
radar.dangercolour = Color(220,0,0,255)
radar.dangerblipcolour = Color(255,255,0,255)
radar.screendetail = 64 -- Ooh, purty.
radar.screenrotation = 0
radar.hazardmode = true 	-- If the radar finds any hazardous ents in its radius, should it bitch about it?

radar.radius = dist

radar.player_show = true
radar.player_color = Color(0,150,255,255)
surface.CreateFont("Arial",64,400,false,false,"RadarPlayerLabel")
radar.player_fontcolor = Color(255,255,255,255)
radar.player_showname = true
radar.player_showhealth = true
radar.player_showarmor = false --TO DO
radar.player_showammo = true


radar.scanfor = {"player", "blastfungus", "rpg_missile", "crossbow_bolt", "npc_", "sent_", "prop_vehicle_"}		-- What should the radar look for?  Accepts partial names.
radar.dangerous = {"sent_nuke_missile", "sent_nuke_detpack"}		-- What should the radar consider extremely hazardous? ("Hazard Mode")  Only accepts full names.

-- The danger table relies on the scan table, make sure your dangerous ent is in both tables.


------------------------------------------------------------------
-- Don't edit under here unless you're the trigonometry GOD. D: --
------------------------------------------------------------------


radar.bgcolorbak = radar.bgcolor
radar.fgcolorbak = radar.fgcolor
radar.player_colorbak = radar.player_color


local color_ascale = function(col,scale) return Color(col.r,col.g,col.b,col.a*scale) end

-- Without further ado, let's rock.

	local ETable = {}
	local PulseRadar = false

	local lpl = LocalPlayer()
	
	
	if ( radar.player_show ) then
	
	--draw.RoundedBox( radar.w/2, radar.x, radar.y, radar.w, radar.h, radar.bgcolor ) --Looks like shit
	local vertices = {}
	for i=1,radar.screendetail do
		local shift = math.fmod(CurTime()*radar.screenrotation,360)
		local sizescale = 1 --+ math.sin(CurTime())/10
		local tab = {}
		tab.x = radar.x+radar.w/2 + math.cos(math.Deg2Rad((360/radar.screendetail)*i+shift)) * radar.w/2 * sizescale
		tab.y = radar.y+radar.h/2 + math.sin(math.Deg2Rad((360/radar.screendetail)*i+shift)) * radar.h/2 * sizescale
		tab.u = 0
		tab.v = 0
		table.insert(vertices,tab)
	end
	surface.SetTexture(surface.GetTextureID("vgui/white"))
	surface.SetDrawColor(radar.bgcolor.r,radar.bgcolor.g,radar.bgcolor.b,radar.bgcolor.a*radar.alphascale)
	local players = {}

	for i = 1, 1000 do -- Because running a loop 1000 times per frame ensures major luls.  Also ents.GetInSphere is serverside. (which sucks major donkey balls.)

			local ent = ents.GetByIndex(i)

			if ent:IsValid() then
				local type = ent:GetClass()

				for k, v in ipairs(radar.scanfor) do
					if string.find(type,v) then
						table.insert(players,ent)
					end
				end
			end
		end

		for i, pl in ipairs(players) do
			local cx = radar.x+radar.w/2
			local cy = radar.y+radar.h/2
			local vdiff = pl:GetPos()-lpl:GetPos()
			local dummy = nil   -- Because I'm lazy.


	-- Player Check.
			if (vdiff:Length() > radar.radius) then dummy = nil else -- In soviet russia, code badly you!
				if pl:IsPlayer() then
					if ( pl:Alive() and lpl~=pl ) then
						local px = (vdiff.x/radar.radius)
						local py = (vdiff.y/radar.radius)
						local z = math.sqrt( px*px + py*py )
						local phi = math.Deg2Rad( math.Rad2Deg( math.atan2( px, py ) ) - math.Rad2Deg( math.atan2( lpl:GetAimVector().x, lpl:GetAimVector().y ) ) - 90 )
						px = math.cos(phi)*z
						py = math.sin(phi)*z
						if crosstype == 1 then
						draw.RoundedBox( 0, cx+px*radar.w/2-4, cy+py*radar.h/2-4, 8, 8, color_ascale(radar.player_color,255) )
						
						surface.SetDrawColor( 0,0,0,255 )
						surface.DrawOutlinedRect( cx+px*radar.w/2-4, cy+py*radar.h/2-4, 8, 8)
						else
						drawcross(cx+px*radar.w/2,cy+py*radar.h/2,color_ascale(radar.player_color,255))
						end
						if radar.player_showname then
							draw.DrawText(pl:Name(), "Default", cx+px*radar.w/2, cy+py*radar.h/2+8, color_ascale(radar.player_fontcolor,radar.alphascale), TEXT_ALIGN_CENTER)
						end
						if radar.player_showhealth then
							draw.RoundedBox( 0, cx+px*radar.w/2-12, cy+py*radar.h/2+20, (math.min(100,pl:Health())/100)*24, 4, Color(255,0,0,255) )
						end
						if radar.player_showammo then
							if (lpl:GetActiveWeapon().Clip1~=nil and lpl:GetActiveWeapon():Clip1() > 0) then
								draw.RoundedBox( 0, cx+px*radar.w/2-12, cy+py*radar.h/2+26, math.min(1,(lpl:GetAmmoCount(lpl:GetActiveWeapon():GetPrimaryAmmoType())/lpl:GetActiveWeapon():Clip1()))*24, 4, Color(255,200,0,255) ) --BUGGED?
							else
								draw.RoundedBox( 0, cx+px*radar.w/2-12, cy+py*radar.h/2+26, 24, 4, Color(255,200,0,255) )
							end
						end
					end
				end


	-- Ent Check.
				if ((not pl:IsPlayer()) and pl:IsValid() ) then

				    local isDangerous = false


				--Fill up the hazard mode table.
					if ( radar.hazardmode ) then
						for k,v in ipairs(radar.dangerous) do
						    if (pl:GetClass() == v) then
						        table.insert(ETable,pl)
						        isDangerous = true
							end
						end
					end
					
					local px = (vdiff.x/radar.radius)
					local py = (vdiff.y/radar.radius)
					local z = math.sqrt( px*px + py*py )
					local phi = math.Deg2Rad( math.Rad2Deg( math.atan2( px, py ) ) - math.Rad2Deg( math.atan2( lpl:GetAimVector().x, lpl:GetAimVector().y ) ) - 90 )
					px = math.cos(phi)*z
					py = math.sin(phi)*z

					if (isDangerous == false) then -- Leave this one for the hazard mode so we can give it a lovely coloured dot. Oh the frivolity.
						if crosstype == 1 then
						draw.RoundedBox( 0, cx+px*radar.w/2-4, cy+py*radar.h/2-4, 8, 8, color_ascale(radar.player_color,255) )
						surface.SetDrawColor( 0,0,0,255 )
						surface.DrawOutlinedRect( cx+px*radar.w/2-4, cy+py*radar.h/2-4, 8, 8)
						else
						drawcross(cx+px*radar.w/2,cy+py*radar.h/2,color_ascale(radar.player_color,255))
						end
					end


					if radar.player_showname then

					--Let's do some name parsing! Whoooo... god dammit.
				
					--To add an extra name parsing thingamajobby, copy/paste one of the elseifs,
					--change the string, count the number of letters, add one, and use that as the last number.

						local nametag = ""
						if string.find(pl:GetClass(),"blastfungus") then nametag = "" -- There will usually be so many of these that adding names will look messy.
						elseif string.find(pl:GetClass(),"npc_") then nametag = string.sub(pl:GetClass(),5)
						elseif string.find(pl:GetClass(),"sent_") then nametag = string.sub(pl:GetClass(),6)
						elseif string.find(pl:GetClass(),"prop_vehicle_") then nametag = string.sub(pl:GetClass(),14)
						else nametag = pl:GetClass()
						end

						local nametable = string.Explode("_",nametag)
						nametag = table.concat(nametable," ")
						local nametag1 = string.sub(nametag,0,1)
						local nametag2 = string.sub(nametag,2)
						nametag1 = string.upper(nametag1)
						nametag = nametag1..nametag2


					end
				end
   			end
	 	end
	 	

   -- Hazard Mode.
   -- This is where things get hacky.  Well, more hacky.
   
   		local count = table.Count(ETable)
   		
   		if ( count > 0 ) then 	-- Oooooh shit.
   		for k,pl in ipairs(ETable) do
   			local cx = radar.x+radar.w/2
			local cy = radar.y+radar.h/2
			local vdiff = pl:GetPos()-lpl:GetPos()
			
   			local px = (vdiff.x/radar.radius)
			local py = (vdiff.y/radar.radius)
			local z = math.sqrt( px*px + py*py )
			local phi = math.Deg2Rad( math.Rad2Deg( math.atan2( px, py ) ) - math.Rad2Deg( math.atan2( lpl:GetAimVector().x, lpl:GetAimVector().y ) ) - 90 )
			px = math.cos(phi)*z
			py = math.sin(phi)*z
			draw.RoundedBox( 0, (cx+px*radar.w/2-8), (cy+py*radar.h/2-8), 16, 16, color_ascale(radar.dangerblipcolour,255) )
			surface.SetDrawColor( 0,0,0,255 )
			surface.DrawOutlinedRect( cx+px*radar.w/2-4, cy+py*radar.h/2-4, 8, 8)
		end
			
			radar.bgcolor = Color(255,255,255,0)
			radar.fgcolor = Color(60,60,60,100)
			
			PulseRadar = true
			
			
 			
		end
	end
        --local CamData = {}
            --CamData.angles = Vector(90,90,0)
            --CamData.origin = Vector(LocalPlayer():GetPos().x,LocalPlayer():GetPos().y,dist)
            --CamData.x = xPos
            --CamData.y = yPos
            --CamData.w = x
            --CamData.h = y   
			--CamData.drawhud = false
			--CamData.drawviewmodel = true
			            --render.RenderView( CamData )
						end
end 
function drawcross(x,y,col,szcross)
if !szcross then
szcross = 8
end
surface.SetDrawColor(0,0,0,255)
surface.DrawLine( x-(szcross+1), y+1, x+(szcross+1), y+1 )
surface.DrawLine( x-(szcross+1), y-1, x+(szcross+1), y-1 )
surface.DrawLine( x-1, y-(szcross+1), x-1, y+(szcross+1) )
surface.DrawLine( x+1, y-(szcross+1), x+1, y+(szcross+1) )
surface.SetDrawColor(col)
surface.DrawLine( x-szcross, y, x+szcross, y )
surface.DrawLine( x, y-szcross, x, y+szcross )
end
function DrawXHair() 
    if( b_cross == 1 ) then 
        DrawCrosshair(); 
    end 
	if( b_cross == 2 ) then 
        DrawCrosshair2(); 
    end 
	if( b_cross == 3 ) then 
	if( b_aim == 1 ) then 
    local time = CurTime() * -180        
    local gap = 5
    local length = gap + 10
    surface.SetDrawColor(255,0,0,255)
    DrawRotatingCrosshair(ScrW()/2,ScrH()/2,time,length,gap)
    DrawRotatingCrosshair(ScrW()/2,ScrH()/2,time + 90, length,gap)
    DrawRotatingCrosshair(ScrW()/2,ScrH()/2,time + 180,length,gap)
    DrawRotatingCrosshair(ScrW()/2,ScrH()/2,time + 270,length,gap)
	else
	local time = CurTime() * 180   
	local gap = 5
    local length = gap + 10
	surface.SetDrawColor(0,0,255,255)
    DrawRotatingCrosshair(ScrW()/2,ScrH()/2,time,length,gap)
    DrawRotatingCrosshair(ScrW()/2,ScrH()/2,time + 90, length,gap)
    DrawRotatingCrosshair(ScrW()/2,ScrH()/2,time + 180,length,gap)
    DrawRotatingCrosshair(ScrW()/2,ScrH()/2,time + 270,length,gap)
	end
    end 

	if b_menu_show == 1 then
	if current == 1 then
	colorbot = Color(255,0,0,255)
	coloresp = Color(255,255,0,255)
	colorcross = Color(255,255,0,255)
	colorrad = Color(255,255,0,255)
	elseif current == 2 then
	colorbot = Color(255,255,0,255)
	coloresp = Color(255,0,0,255)
	colorcross = Color(255,255,0,255)
	colorrad = Color(255,255,0,255)
	elseif current == 3 then
	colorbot = Color(255,255,0,255)
	coloresp = Color(255,255,0,255)
	colorcross = Color(255,0,0,255)
	colorrad = Color(255,255,0,255)
	elseif current == 4 then
	colorbot = Color(255,255,0,255)
	coloresp = Color(255,255,0,255)
	colorcross = Color(255,255,0,255)
	colorrad = Color(255,0,0,255)
	end
	surface.SetDrawColor( 0, 0, 0, 50 ); 
    surface.DrawRect( ScrW()/4, ScrH()/4, 200, 36+16+16+16 ); 
	surface.SetDrawColor( 255, 0, 0, 255 ); 
    surface.DrawOutlinedRect( ScrW()/4, ScrH()/4, 200, 36+16+16+16 ); 
	surface.DrawOutlinedRect( ScrW()/4, ScrH()/4, 200, 20 ); 
	local textData = {}
	textData.pos = {} 
    textData.pos[1] = ScrW()/4+2; 
    textData.pos[2] = ScrH()/4+1; 
    textData.color = Color(0,172,255,255); 
    textData.text = " B-Hacks test"
    textData.font = "TabLarge"; 
    textData.xalign = TEXT_ALIGN_LEFT; 
    textData.yalign = TEXT_ALIGN_LEFT; 
    draw.Text( textData ); 
	textData.pos = {} 
    textData.pos[1] = ScrW()/4+2; 
    textData.pos[2] = ScrH()/4+21; 
    textData.color = colorbot; 
    textData.text = " Aimbot: "..b_aim
    textData.font = "TabLarge"; 
    textData.xalign = TEXT_ALIGN_LEFT; 
    textData.yalign = TEXT_ALIGN_LEFT; 
    draw.Text( textData ); 
	textData.pos = {} 
    textData.pos[1] = ScrW()/4+2; 
    textData.pos[2] = ScrH()/4+36; 
    textData.color = coloresp; 
    textData.text = " ESP: "..b_esp
    textData.font = "TabLarge"; 
    textData.xalign = TEXT_ALIGN_LEFT; 
    textData.yalign = TEXT_ALIGN_LEFT; 
    draw.Text( textData ); 
	textData.pos = {} 
    textData.pos[1] = ScrW()/4+2; 
    textData.pos[2] = ScrH()/4+36+16; 
    textData.color = colorcross; 
    textData.text = " Crosshair: "..b_cross
    textData.font = "TabLarge"; 
    textData.xalign = TEXT_ALIGN_LEFT; 
    textData.yalign = TEXT_ALIGN_LEFT; 
    draw.Text( textData );
	textData.pos = {} 
    textData.pos[1] = ScrW()/4+2; 
    textData.pos[2] = ScrH()/4+36+16+16; 
    textData.color = colorrad; 
    textData.text = " Radar: "..radar2
    textData.font = "TabLarge"; 
    textData.xalign = TEXT_ALIGN_LEFT; 
    textData.yalign = TEXT_ALIGN_LEFT; 
    draw.Text( textData );
	end
end 
function norec()
                if ValidEntity(LocalPlayer():GetActiveWeapon()) and (LocalPlayer():GetActiveWeapon().Primary and LocalPlayer():GetActiveWeapon().Primary.Recoil != 0) then
				return (LocalPlayer():GetActiveWeapon().Recoil or LocalPlayer():GetActiveWeapon().Primary.Recoil) or 0.0001
				end
end
print("checking for old menu timer...")
if timer.IsTimer( "timermenu" ) then
timer.Destroy( "timermenu")
print("Removed old menu timer to avoid conflicts... continue loading")
else
print("Couldnt find old menu timer... continue loading")
end
print("Loaded succesfully.")
function menu()
timer.Simple(0.1,menu)
				if input.IsKeyDown( 72 ) then
				if b_menu_show == 0 then
				b_menu_show = 1
				else
				b_menu_show = 0
				end
				end
				if input.IsKeyDown( 91 ) then
				if b_menu_show == 1 then
				if current == 1 then
				if b_aim == 0 then
				b_aim = 1
				else
				b_aim = 0
				end
				elseif current == 2 then
				if b_esp == 0 then
				b_esp = 1
				else
				b_esp = 0
				end
				elseif current == 3 then
				if b_cross == 0 then
				b_cross = 1
				elseif b_cross == 1 then
				b_cross = 2
				elseif b_cross == 2 then
				b_cross = 3
				else
				b_cross = 0
				end
				elseif current == 4 then
				if radar2 == 0 then
				radar2 = 1
				else
				radar2 = 0
				end
				end
				end
				end
				if input.IsKeyDown( KEY_UP ) then
				if b_menu_show == 1 then
				if current == 1 then
				current = 2
				elseif current == 2 then
				current = 3
				elseif current == 3 then
				current = 4
				elseif current == 4 then
				current = 1
				end
				end
				end
				if input.IsKeyDown( KEY_DOWN ) then
				if b_menu_show == 1 then
				if current == 4 then
				current = 3
				elseif current == 3 then
				current = 2
				elseif current == 2 then
				current = 1
				elseif current == 1 then
				current = 4
				end
				end
				end
				end	
				menu()
hook.Add("Think","norec",norec)
hook.Add( "HUDPaint", "DrawESP", DrawESP ); 
hook.Add( "HUDPaint", "DrawXHair", DrawXHair ); 
function DrawRotatingCrosshair(x,y,time,length,gap)
    surface.DrawLine(
        x + (math.sin(math.rad(time)) * length),
        y + (math.cos(math.rad(time)) * length),
        x + (math.sin(math.rad(time)) * gap),
        y + (math.cos(math.rad(time)) * gap)
    )
end
local CL = LocalPlayer()
local wep = LocalPlayer():GetActiveWeapon()
local NoSpreadHere=false
if #file.Find("../lua/includes/modules/gmcl_deco.dll")>=1 then
NoSpreadHere=true

local MoveSpeed = 1

mysetupmove = function(objPl, move)
    if move then
        MoveSpeed = (move:GetVelocity():Length())/move:GetMaxSpeed()
    end
end

local ID_GAMETYPE = ID_GAMETYPE or -1
local GameTypes = {
    {check=function ()
        return string.find(GAMEMODE.Name,"Garry Theft Auto") ~= nil
    end,getcone=function (wep,cone)
        if type(wep.Base) == "string" then
            if wep.Base == "civilian_base" then
                local scale = cone
                if CL:KeyDown(IN_DUCK) then
        scale = math.Clamp(cone/1.5,0,10)
                elseif CL:KeyDown(IN_WALK) then
        scale = cone
                elseif (CL:KeyDown(IN_SPEED) or CL:KeyDown(IN_JUMP)) then
        scale = cone + (cone*2)
                elseif (CL:KeyDown(IN_FORWARD) or CL:KeyDown(IN_BACK) or CL:KeyDown(IN_MOVELEFT) or CL:KeyDown(IN_MOVERIGHT)) then
        scale = cone + (cone*1.5)
                end
                scale = scale + (wep:GetNWFloat("Recoil",0)/3)
                return Vector(scale,0,0)
            end
        end
        return Vector(cone,cone,cone)
    end},
    {check=function ()
        return type(TEAM_ZOMBIE) == "number" and type(TEAM_SURVIVORS) == "number" and string.find(GAMEMODE.Name,"Zombie Survival") ~= nil and type(NUM_WAVES) == "number"
    end,getcone=function (wep,cone)
        if wep:GetNetworkedBool("Ironsights",false) then
            if CL:Crouching() then
                return wep.ConeIronCrouching or cone
            end
            return wep.ConeIron or cone
        elseif 25 < LocalPlayer():GetVelocity():Length() then
            return wep.ConeMoving or cone
        elseif CL:Crouching() then
            return wep.ConeCrouching or cone
        end
        return cone
    end},
    {check=function ()
        return type(TEAM_ZOMBIE) == "number" and type(TEAM_SURVIVORS) == "number" and string.find(GAMEMODE.Name,"Zombie Survival") ~= nil
    end,getcone=function (wep,cone)
        if CL:GetVelocity():Length() > 25 then
            return wep.ConeMoving or cone
        elseif CL:Crouching() then
            return wep.ConeCrouching or cone
        end
        return cone
    end},
    {check=function ()
        return type(gamemode.Get("ZombRP")) == "table" or type(gamemode.Get("DarkRP")) == "table"
    end,getcone=function (wep, cone)
        if type(wep.Base) == "string" and (wep.Base == "ls_snip_base" or wep.Base == "ls_snip_silencebase") then
            if CL:GetNWInt( "ScopeLevel", 0 ) > 0 then 
                print("using scopecone")
                return wep.Primary.Cone
            end
            print("using unscoped cone")
            return wep.Primary.UnscopedCone
        end
        if type(wep.GetIronsights) == "function" and wep:GetIronsights() then
            return cone
        end
        return cone + .05
    end},
    {check=function ()
        return (GAMEMODE.Data == "falloutmod" and type(Music) == "table")
    end,getcone=function(wep,cone)
        if wep.Primary then
            local LastShootTime = wep.Weapon:GetNetworkedFloat( "LastShootTime", 0 ) 
            local lastshootmod = math.Clamp(wep.LastFireMax + 1 - math.Clamp( (CurTime() - LastShootTime) * wep.LastFireModifier, 0.0, wep.LastFireMax ), 1.0,wep.LastFireMaxMod) 
            local accuracy = wep.Primary.Accuracy
            if CL:IsMoving() then accuracy = accuracy * wep.MoveModifier end
            if wep.Weapon:GetNetworkedBool( "Ironsights", false ) then accuracy = accuracy * 0.75 end
            accuracy = accuracy * ((16-(Skills.Marksman or 1))/11)
            if CL:KeyDown(IN_DUCK) then
                return accuracy*wep.CrouchModifier*lastshootmod
            else
                return accuracy*lastshootmod
            end
        end
    end}
}
Check = function()
    for k, v in pairs(GameTypes) do
        if v.check() then
            ID_GAMETYPE = k
            break
        end
    end
end

concommand.Add("raidbot_predictcheck", function () Check() print("GameType = ["..ID_GAMETYPE.."]") end)

local tblNormalConeWepBases = {
    ["weapon_cs_base"] = true
}
local function GetCone(wep)
    local cone = wep.Cone
    if not cone and type(wep.Primary) == "table" and type(wep.Primary.Cone) == "number" then
        cone = wep.Primary.Cone
    end
    if wep:GetClass() == "ose_turretcontroller" then return 0 end
    return cone or 0
end

require("deco")
local currentseed, cmd2, seed = currentseed or 0, 0, 0
local wep, vecCone, valCone
PredictSpread = function(cmd,aimAngle)
    cmd2, seed = hl2_ucmd_getprediciton(cmd)
    if cmd2 ~= 0 then
        currentseed = seed
    end
    wep = LocalPlayer():GetActiveWeapon()
    vecCone = Vector(0,0,0)
    if wep and wep:IsValid() and type(wep.Initialize) == "function" then
        valCone = GetCone(wep)
        if( tonumber( valCone ) ) then
        vecCone = Vector( -valCone, -valCone, -valCone )
        elseif( type( valCone ) == "Vector" ) then
        vecCone = -1 * valCone
        end
    end
	if norec() then
	vecnorec = Vector(0,norec()*2,0)
	else
	vecnorec = Vector(0,0,0)
	end
	if wep:GetClass() == "weapon_smg1" then
	vecCone = Vector(-0.04362,-0.04362,-0.04362)
	elseif wep:GetClass() == "weapon_pistol" then
	vecCone = Vector( -0.0100, -0.0100, -0.0100 )
	elseif wep:GetClass() == "weapon_ar2" then
	vecCone = Vector( -0.02618, -0.02618, -0.02618 )
	elseif wep:GetClass() == "weapon_shotgun" then
	vecCone = Vector( -0.08716, -0.08716, -0.08716 )
	elseif wep:GetClass() == "weapon_iceaxe" then
	vecCone = Vector(-0.15,-0.15,-0.15)
	elseif wep:GetClass() == "weapon_357" then
	vecCone = Vector(-0.005,-0.005,-0.005)
	end
    return hl2_shotmanip(currentseed or 0, (aimAngle or CL:GetAimVector():Angle()):Forward(), vecCone):Angle()+vecnorec
end
end