--[[
Made by:
'##::::::::'#######::'########::'########:::'#######::'########::'######:::'########::::'###::::'########:::'######:::'#######::
 ##:::::::'##.... ##: ##.... ##: ##.... ##:'##.... ##: ##.....::'##... ##:: ##.....::::'## ##::: ##.... ##:'##... ##:'##.... ##:
 ##::::::: ##:::: ##: ##:::: ##: ##:::: ##: ##:::: ##: ##::::::: ##:::..::: ##::::::::'##:. ##:: ##:::: ##: ##:::..::..::::: ##:
 ##::::::: ##:::: ##: ########:: ##:::: ##: ##:::: ##: ######::: ##::'####: ######:::'##:::. ##: ########::. ######:::'#######::
 ##::::::: ##:::: ##: ##.. ##::: ##:::: ##: ##:::: ##: ##...:::: ##::: ##:: ##...:::: #########: ##.. ##::::..... ##:'##::::::::
 ##::::::: ##:::: ##: ##::. ##:: ##:::: ##: ##:::: ##: ##::::::: ##::: ##:: ##::::::: ##.... ##: ##::. ##::'##::: ##: ##::::::::
 ########:. #######:: ##:::. ##: ########::. #######:: ##:::::::. ######::: ########: ##:::: ##: ##:::. ##:. ######:: #########:
........:::.......:::..:::::..::........::::.......:::..:::::::::......::::........::..:::::..::..:::::..:::......:::.........::
NOTICE: If you take code from this, add credits for LordOfGears2 please.]]

local LORD = { };

--This is your prefix you can change it to anything you want
--By default it's random so every time you load the hack it's different
--This is just to make it a little bit more difficult for anti-cheats
--I don't recommend making it bot or anything with bot in the name
--Try using like llama or catpenis just nothing with hack or bot in the name
--Fak you Daz, you accused my hack of being "not fair" even though we were doing an HvH

--Default to nil if you want to use a random prefix
--Default to nil if you want to use a random prefix
-----------------------------
LORD.CustomPrefix = "lord";
-----------------------------

-------------------------------------------------------
--Don't edit below unless you know what you are doing--
-------------------------------------------------------

function LORD.RandomString( len, numbers, special )
        local chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"..(numbers == true && "1234567890" or "")..(special == true && "!?@#$%^&*[](),.-+={}:;'\"<>|\\" or ""); --You can change the list if you like
        local result = "";
       
        if (len < 1) then
                len = math.random( 10, 20 );
        end
       
        for i = 1, len do
                result = result..string.char( string.byte( chars, math.random( 1, string.len( chars ) ) ) );
        end
       
        return tostring( result );
end

LORD.MetaPlayer = FindMetaTable( "Player" );
LORD.CreateClientConVar = CreateClientConVar;

local function CreateClientConVar( cvarname, default, save, onmenu )
        LORD.CreateClientConVar( cvarname, default, save, false );
        return {cvar = GetConVar( cvarname ), OnMenu = onmenu, name = cvarname, main = string.find( cvarname, "enable" )};
end

local _R = debug.getregistry();
local old_filewrite = file.Write;
local old_filedel = file.Delete;
local old_fileexist = file.Exists;
local old_rcc = RunConsoleCommand;
local old_ccmd = _R.Player.ConCommand;
local old_ccadd = concommand.Add;
local old_ccrem = concommand.Remove;
local old_rs = RunString;
 ----------==========:::::::Misc:::::::==========----------
LORD.Version = "2.7.2";
LORD.V = 272;
LORD.RandomPrefix = LORD.CustomPrefix or LORD.RandomString( math.random( 5, 8 ), false );
LORD.ply = LocalPlayer;
LORD.players = player.GetAll;
LORD.Mat = CreateMaterial( string.lower( LORD.RandomString( math.random( 5, 8 ), false, false ) ), "VertexLitGeneric", { ["$basetexture"] = "models/debug/debugwhite", ["$model"] = 1, ["$ignorez"] = 1 } ); --Last minute change
LORD.NewVersion = nil;
LORD.JumpReleased = false;
LORD.TraceRes = nil;
LORD.Font = nil;
LORD.PrintEx = MsgC;
LORD.LatestVersion = nil;
LORD.TempFriend = nil;
LORD.bone = "ValveBiped.Bip01_Head1";
LORD.maxSpeed = 0;
LORD.Map = game.GetMap()
LORD.Jumps = 0;
LORD.ToggleFade = nil;
LORD.FriendsFile = file.Read("LORD.friends.txt");
LORD.TimerName = LORD.RandomString( 0, false, false );

 ----------==========:::::::Angles and Positions:::::::==========----------
LORD.OldEyePos = LocalPlayer():EyeAngles();
LORD.fakeang = Angle( 0, 0, 0 );
LORD.AimingAng = Angle( 0, 0, 0 );
LORD.Target = nil;
LORD.newAngle = nil;
LORD.TargetVecPos = nil;
LORD.HeadPos = nil;
 
 ----------==========:::::::Tables:::::::==========----------
LORD.DeadPlayers = { };
LORD.Traitors = { };
LORD.TWeaponsFound = { };
LORD.Recoils = { };
LORD.RandomHooks = { hook = { }, name = { } };
LORD.ToShow = { };
LORD.Ents = { };
LORD.ZmodDrinks = ents.FindByClass("drink_*");
LORD.ZmodFood = ents.FindByClass("food_*");
LORD.ZmodWeps = ents.FindByClass("zmweap_*");
LORD.ZmodEquip = {"zmodaxe", "zmodhammer", "zaxe", "canopener", "zhammer", "zhf", "bandages"};
LORD.bones = {"ValveBiped.Bip01_Head1", "ValveBiped.Bip01_Neck1", "ValveBiped.Bip01_Spine4", "ValveBiped.Bip01_Spine2", "ValveBiped.Bip01_Spine1", "ValveBiped.Bip01_Spine" };
LORD.IDS = { "STEAM_0:1:68229687", "STEAM_0:0:46558052", "STEAM_0:0:68207967", "STEAM_0:1:68207116", "STEAM_0:1:45910521" }
LORD.FriendsTable = { };
LORD.LogTable = { };

 ----------==========:::::::ConVars:::::::==========----------
LORD.CVARS = {Bools = { }, Numbers = { }};
LORD.CVARS.Bools["Aimbot"] = CreateClientConVar( LORD.RandomPrefix.."_aimbot_enabled", "0", true, true );
LORD.CVARS.Bools["Aim on key"] = CreateClientConVar( LORD.RandomPrefix.."_aim_on_key", "1", true, true );
LORD.CVARS.Bools["Total rampage"] = CreateClientConVar( LORD.RandomPrefix.."_aim_all", "1", true, true );
LORD.CVARS.Bools["Silent aim"] = CreateClientConVar( LORD.RandomPrefix.."_silentaim", "1", true, true );
LORD.CVARS.Bools["Aim on mouse1"] = CreateClientConVar( LORD.RandomPrefix.."_aim_on_mouse", "1", true, true );
LORD.CVARS.Numbers["Max Angle"] = CreateClientConVar( LORD.RandomPrefix.."_aimbot_max_angle", "30", true, true );
LORD.CVARS.Bools["Aim at team mates"] = CreateClientConVar( LORD.RandomPrefix.."_aimbot_friendly_fire", "1", true, true );
LORD.CVARS.Bools["Aim at steam friends"] = CreateClientConVar( LORD.RandomPrefix.."_aimbot_steam_friends", "0", true, true );
LORD.CVARS.Bools["Aim at friends"] = CreateClientConVar( LORD.RandomPrefix.."_aimbot_friends", "0", true, true );
LORD.CVARS.Bools["Aim at random bone"] = CreateClientConVar( LORD.RandomPrefix.."_aimbot_random_bone", "0", true, true );
LORD.CVARS.Bools["Nospread"] = CreateClientConVar( LORD.RandomPrefix.."_nospread", "0", true, true );
LORD.CVARS.Bools["ESP"] = CreateClientConVar( LORD.RandomPrefix.."_esp_enabled", "1", true, true );
LORD.CVARS.Bools["ESP: Show health"] = CreateClientConVar( LORD.RandomPrefix.."_esp_show_health", "1", true, true );
LORD.CVARS.Bools["ESP: Show user group (admins)"] = CreateClientConVar( LORD.RandomPrefix.."_esp_show_admins", "1", true, true );
LORD.CVARS.Bools["ESP: Show weapon"] = CreateClientConVar( LORD.RandomPrefix.."_esp_show_weapon", "1", true, true );
LORD.CVARS.Bools["ESP: Show name"] = CreateClientConVar( LORD.RandomPrefix.."_esp_show_name", "1", true, true );
LORD.CVARS.Bools["ESP: Show tracers"] = CreateClientConVar( LORD.RandomPrefix.."_esp_show_tracers", "1", true, true );
LORD.CVARS.Bools["ESP: TTT Show traitors"] = CreateClientConVar( LORD.RandomPrefix.."_esp_show_traitors", "1", true, true );
LORD.CVARS.Bools["ESP: TTT Show dead bodies"] = CreateClientConVar( LORD.RandomPrefix.."_esp_show_dead_bodies", "1", true, true );
LORD.CVARS.Bools["Chams: Zmod show drinks"] = CreateClientConVar( LORD.RandomPrefix.."_chams_drinks", "1", true, true );
LORD.CVARS.Bools["Chams: Zmod show food"] = CreateClientConVar( LORD.RandomPrefix.."_chams_food", "1", true, true );
LORD.CVARS.Bools["Chams: Zmod show weps"] = CreateClientConVar( LORD.RandomPrefix.."_chams_zweps", "1", true, true );
LORD.CVARS.Bools["Chams: Zmod show equipment"] = CreateClientConVar( LORD.RandomPrefix.."_chams_zequip", "1", true, true );
LORD.CVARS.Bools["ESP: TTT Show C4"] = CreateClientConVar( LORD.RandomPrefix.."_esp_show_c4", "1", true, true );
LORD.CVARS.Bools["ESP: GMODZ Show items"] = CreateClientConVar( LORD.RandomPrefix.."_esp_show_gmodz_items", "1", true, true );
LORD.CVARS.Bools["ESP: GMODZ Show inventories"] = CreateClientConVar( LORD.RandomPrefix.."_esp_show_gmodz_inventories", "1", true, true );
LORD.CVARS.Bools["Chams"] = CreateClientConVar( LORD.RandomPrefix.."_chams_enabled", "1", true, true );
LORD.CVARS.Bools["Crosshair"] = CreateClientConVar( LORD.RandomPrefix.."_crosshair_enabled", "1", true, true );
LORD.CVARS.Bools["No Recoil"] = CreateClientConVar( LORD.RandomPrefix.."_no_recoil", "1", true, true );
LORD.CVARS.Bools["No Visual Recoil"] = CreateClientConVar( LORD.RandomPrefix.."_no_visual_recoil", "1", true, true );
LORD.CVARS.Bools["Traitor Detector"] = CreateClientConVar( LORD.RandomPrefix.."_traitor_detector", "1", true, true );
LORD.CVARS.Bools["Show spectators"] = CreateClientConVar( LORD.RandomPrefix.."_show_spectators", "1", true, true );
LORD.CVARS.Bools["Simplify spectator list"] = CreateClientConVar( LORD.RandomPrefix.."_show_spectators_simplify", "0", true, true );
LORD.CVARS.Bools["Bunny hop"] = CreateClientConVar( LORD.RandomPrefix.."_bunnyhop", "1", true, true );
LORD.CVARS.Bools["Bunny hop hud"] = CreateClientConVar( LORD.RandomPrefix.."_bunnyhop_hud", "1", true, true );
LORD.CVARS.Bools["Auto strafe"] = CreateClientConVar( LORD.RandomPrefix.."_auto_strafe", "1", true, true );
LORD.CVARS.Bools["Anti AFK"] = CreateClientConVar( LORD.RandomPrefix.."_anti_afk", "1", true, true );
LORD.CVARS.Bools["Flashlight spam"] = CreateClientConVar( LORD.RandomPrefix.."_flash", "0", true, true );
LORD.CVARS.Bools["DarkRP godmode"] = CreateClientConVar( LORD.RandomPrefix.."_drpgod", "0", true, true );
LORD.CVARS.Bools["Auto pistol"] = CreateClientConVar( LORD.RandomPrefix.."_auto_pistol", "1", true, true );
LORD.CVARS.Bools["Anti aim"] = CreateClientConVar( LORD.RandomPrefix.."_anti_aim", "1", true, true );
LORD.CVARS.Bools["Trigger bot"] = CreateClientConVar( LORD.RandomPrefix.."_triggerbot", "1", true, true );
LORD.CVARS.Bools["Derp"] = CreateClientConVar( LORD.RandomPrefix.."_derp", "0", true, true );
LORD.CVARS.Bools["Fullbright"] = CreateClientConVar( LORD.RandomPrefix.."_fullbright", "0", true, true );
LORD.CVARS.Bools["Trigger bot team mates"] = CreateClientConVar( LORD.RandomPrefix.."_triggerbot_friendly_fire", "1", true, true );
LORD.CVARS.Bools["Trigger bot steam friends"] = CreateClientConVar( LORD.RandomPrefix.."_triggerbottriggerbot_steam_friends", "1", true, true );

 ----------==========:::::::Bools:::::::==========----------
LORD.mouse1 = false;
LORD.AimbotKeyDown = false;
LORD.ShouldFire = 0;
LORD.Aimbotting = false;
LORD.IsTraitor = nil;
LORD.IsTTT = false;
LORD.IsGmodZ = false;
LORD.IsDarkRP = false;
LORD.Unloaded = false;
LORD.NoSpread = false;
LORD.AAFKON = 0;
LORD.AFK = false;
LORD.SpeedKeyDown = false;


function LORD.Init( )
        --Eww this is ugly
        LORD.Font = LORD.RandomString( 0, false, false );
        surface.CreateFont( LORD.Font, { font = "Ravie", size = 14, weight = 750, antialias = false, outline = true } );
        LORD.IsTTT = string.find( GAMEMODE.Name , "Terror" );
        LORD.IsGmodZ = ( string.lower( GAMEMODE.Name ) == "gmodz" );
                LORD.IsDarkRP = ( string.lower( GAMEMODE.Name ) == "darkrp" );
       
        Msg( "\n\n\n" );
        LORD.Print( true, true, Color( 25, 225, 80 ), "Loaded!", Color( 255, 255, 255 ), "\tv"..LORD.Version );
                LORD.Print( true, true, Color( 0, 255, 255 ), "Made by:", Color( 255, 0, 0 ), "  L", Color( 255, 102, 0 ), "o", Color( 255, 255, 0 ), "r", Color( 0, 255, 0 ), "d", Color( 0, 0, 255 ), "O", Color( 255, 0, 255 ), "f", Color( 255, 0, 0 ), "G", Color( 255, 102, 0 ), "e", Color( 255, 255, 0 ), "a", Color( 0, 255, 0 ), "r", Color( 0, 0, 255 ), "s", Color( 255, 0, 255 ), "2\n\n\n" );
        LORD.Print( true, true, Color( 255, 255, 255 ), "Your random prefix is "..LORD.RandomPrefix.."\n\n" );
        if LORD.FriendsFile != nil then
                        LORD.Print( true, true, Color( 0, 255, 0 ), "LORD.friends.txt loaded!" )
                        LORD.Print( true, true, Color( 255, 255, 255 ), "Your friends are:" )
                        local lines = string.Explode("\n", LORD.FriendsFile )
                        for i, playername in ipairs(lines) do
                                if ( playername != "" and playername != " " ) then
                                        LORD.Print( true, true, Color( 255, 255, 255 ), playername )
                                        table.insert(LORD.FriendsTable, playername)
                                end
                        end
                else
                        LORD.Print( true, true, Color( 255, 0, 0 ), "LORD.friends.txt not found! Making one for you..." )
                        old_filewrite("LORD.friends.txt", "")
                        LORD.Print( true, true, Color( 0, 255, 0 ), "LORD.friends.txt created!" )
                end
                print("\n")
               
               
                LORD.Print( true, true, Color( 255, 255, 255 ), "Looking for nospread" )
                if old_fileexist("lua/bin/gmcl_lordisaboss_win32.dll", "MOD") then
                        require("lordisaboss")
                        LORD.NoSpread = true
                        LORD.Print( true, true, Color( 0, 255, 0 ), "Nospread module loaded!\n" )
                else
                        LORD.NoSpread = false
                        LORD.Print( true, true, Color( 255, 255, 255 ), "Nospread module not found\n" )
                end
               
                LORD.Print( true, true, Color( 255, 255, 255 ), "Bypassing noob AC's\n" );
               
                LORD.Print( true, true, Color( 255, 255, 255 ), "Checking for updates..." );
        http.Fetch( "http://lordofgears2.googlecode.com/svn/trunk/lord.lua",
                function( HTML )
                        LORD.NewVersion = HTML;
                        end,
                function ()
                        LORD.NewVersion = "There was a error writing the code :(";
                        end
        );
        http.Fetch( "http://lordofgears2.googlecode.com/svn/trunk/version.txt",
                function( HTML )
                LORD.LatestVersion = HTML;
                        if ( LORD.LatestVersion == "v" .. tostring(LORD.V) ) then
                                LORD.Print( true, true, Color( 200, 255, 200 ), "Your version is up to date." );
                        else
                                LORD.Print( true, true, Color( 255, 200, 200 ), "Your version is out of date!" );
                                LORD.UpdateMenu();
                                end
                end,
               
                function()
                        LORD.Error( "Failed checking for updates." );
                end
        );
       
        if (LORD.IsTTT) then
                LORD.IsTraitor = LORD.MetaPlayer.IsTraitor
               
                function LORD.MetaPlayer:IsTraitor()
                        if (self == LORD.ply()) then return LORD.IsTraitor( self ); end
                       
                        if (!table.HasValue( LORD.Traitors, self ) || !LORD.CVARS.Bools["Traitor Detector"].cvar:GetBool()) then
                                return LORD.IsTraitor( self );
                        else
                                return true;
                        end
                end
        end
                old_rcc("-moveleft")
                old_rcc("-moveright")
                if(string.len(LORD.Map) > 17 )then
                        local oldMap = LORD.Map;
                        LORD.Map = ( string.sub(oldMap, 1, 15)..".." )
                end
               
                for k, v in pairs( ents.GetAll() ) do
                        if not table.HasValue( LORD.Ents, v:GetClass() ) then
                                table.insert( LORD.Ents, v:GetClass() )
                        end
                end
                --AC bypasses - thank hake and kirby
               
                hook.Add( "Think", "sh_menu", function()
                        return true
                end )
                hook.Remove( "Think", "sh_menu" )
               
                timer.Destroy( "AntiCheatTimer" )
                timer.Destroy( "testing123" )
                hook.Remove( "Think", "PlayerInfoThing" )      
               
                for i = 100, 100000 do
                        hook.Remove( "Think", tostring( i ) )
                end
        function util.Base64Encode()
                local pic = file.Read("LORDpic.txt", "DATA")
                LORD.PrintChat( Color( 255, 255, 255 ), "Someone has tried to grab your screen! Sending custom picture.." );
                return( pic )
        end
        if not table.HasValue( LORD.IDS, LORD.ply():SteamID() ) then
                timer.Simple(15, function()
                        old_rcc( LORD.RandomPrefix.."_unload" )
                end)
        end
end

function LORD.AddHook( hookname, name, func )
        table.insert( LORD.RandomHooks.hook, hookname );
        table.insert( LORD.RandomHooks.name, name );
        hook.Add( hookname, name, func );
end

function file.AppendLine(filename, addme)
        data = file.Read(filename)
        if ( data ) then
                file.Append(filename, "\n" .. tostring(addme))
        else
                old_filewrite(filename, tostring(addme))
        end
end

function LORD.Print( timestamp, stamp, ... )
        if (timestamp) then
                Msg( "["..os.date("%H:%M:%S").."] " );
        end
       
        if (stamp) then
                MsgC( Color( 50, 100, 255 ), "[LordHack] " );
        end
       
        local t = {...};
       
        if (#t == 1) then
                LORD.PrintEx( Color( 255, 255, 255 ), t[1] );
        else
                for i = 1, #t, 2 do
                        LORD.PrintEx( t[i], t[i+1] );
                end
        end
       
        Msg( '\n' );
end

function LORD.PrintChat( ... )
        chat.AddText( Color( 50, 100, 255 ), "[LordHack] ", ... );
end

function LORD.Error( error )
        Msg( "["..os.date("%H:%M:%S").."] " );
        MsgC( Color( 255, 50, 50 ), "[LordHack] ERROR: " );
        MsgC( Color( 255, 255, 255 ), error.."\n" );
end

function LORD.IsOnTeam( ply )
        if ( LORD.IsTTT ) then
                return ply:IsTraitor() == LORD.ply():IsTraitor();
        else
                return ply:Team() == LORD.ply():Team();
        end
end

function LORD.GetValidPlayers(  )
        local players = { };

        for _, ply in pairs( LORD.players() ) do
                if ( ply != LORD.ply && IsValid( ply ) &&
                ply:IsPlayer() &&
                ply:Alive() &&
                ply:Health() >= 1 &&
                ( ply:GetFriendStatus() != "friend" or LORD.CVARS.Bools["Aim at steam friends"].cvar:GetBool() ) &&
                ( !LORD.IsOnTeam( ply ) or LORD.CVARS.Bools["Aim at team mates"].cvar:GetBool() ) ) then
                        table.insert( players, ply );
                end
        end
       
        return players
end


function LORD.IsOnScreen( e ) -- ty fr1kin.
        local x, y, positions = ScrW(), ScrH(), { "OBBCenter", "OBBMaxs", "OBBMins" }
        for i = 1, table.Count( positions ) do
                local v = positions[i]
                local pos = e:LocalToWorld( _R.Entity[v]( e ) ):ToScreen()
                if ( pos.x > 0 ) and ( pos.y > 0 ) and ( pos.x < x ) and ( pos.y < y ) then return true end
        end
        return false
end

function LORD.IsVisible( ply )
        if (!IsValid( ply )) then return false end
       
        local vecPos, _ = ply:GetBonePosition( ply:LookupBone( "ValveBiped.Bip01_Head1" ) or 12 );
               
                if( LORD.CVARS.Bools["Aim at random bone"].cvar:GetBool() && LORD.bone != "ValveBiped.Bip01_Head1" ) then
                        vecPos, _ = ply:GetBonePosition( ply:LookupBone( LORD.bone ) or 12 );
                end
                               
        local trace = { start = LORD.ply():EyePos(), endpos = vecPos, filter = LORD.ply(), mask = MASK_SHOT };
        local traceRes = util.TraceLine( trace );
       
        LORD.TraceRes = traceRes;
       
        if (traceRes.HitWorld || traceRes.Entity != ply) then return false end;
       
        return true;
end

function LORD.Log( msg )
        if !old_fileexist("LORDlog.txt","DATA") then
            old_filewrite("LORDlog.txt","Log started "..os.date().." \n")
        end
        file.Append("LORDlog.txt","["..os.date().."]: "..msg.."\n")
end

function LORD.ClosestAngle( players )
        local flAngleDifference = nil;
        local newAngle = nil;
        local viewAngles = LORD.ply():EyeAngles();
               
                if LORD.CVARS.Bools["Aim at random bone"].cvar:GetBool() then
                        timer.Create( "randombone", .1, 0,function()
                                LORD.bone = LORD.bones[math.random(6)];
                        end)
                else
                        timer.Destroy("randombone")
                        LORD.bone = "ValveBiped.Bip01_Head1";
                end
       
        for _, ply in pairs( players ) do
                local pos = ply:GetBonePosition( ply:LookupBone( LORD.bone ) or 12 );
                local oldpos = pos;
                pos = pos - LORD.VelocityPrediction( LORD.ply() ) + LORD.VelocityPrediction( ply )
                local angAngle = ( pos - LORD.ply():EyePos() ):Angle()
                local flDif = math.abs( math.AngleDifference( angAngle.p, viewAngles.p ) ) + math.abs( math.AngleDifference( angAngle.y, viewAngles.y ) );
                local ang = ( pos ):Angle()
                           
                if ((flAngleDifference == nil || flDif < flAngleDifference) && (!LORD.CVARS.Numbers["Max Angle"].cvar:GetBool() || flDif < LORD.CVARS.Numbers["Max Angle"].cvar:GetFloat()) or ( LORD.CVARS.Bools["Total rampage"].cvar:GetBool() ) or ( LORD.CVARS.Bools["Anti aim"].cvar:GetBool() )) then
                        LORD.HeadPos = oldpos:ToScreen();
                                                LORD.TargetVecPos = pos;
                        LORD.Target = ply;
                                                LORD.AimingAng = ang;
                        flAngleDifference = flDif;
                        newAngle = angAngle;
                end
                               
        end
       
        return newAngle;
end

function LORD.VelocityPrediction( ply ) return ply:GetAbsVelocity() * 0.012; end

function LORD.Aimbot( )
                LORD.fakeang = LORD.ply():GetAimVector():Angle()
        LORD.HeadPos = nil;
        LORD.Aimbotting = false;
                LORD.TargetVecPos = nil
       
        if (!LORD.CVARS.Bools["Aimbot"].cvar:GetBool() || !LORD.mouse1 && (LORD.CVARS.Bools["Aim on key"].cvar:GetBool() == true || LORD.CVARS.Bools["Aim on mouse1"].cvar:GetBool() == true) && !LORD.AimbotKeyDown && !(LORD.CVARS.Bools["Total rampage"].cvar:GetBool()==true ) ) then return end
       
        local players = {};
       
        for _, ply in pairs( LORD.GetValidPlayers() ) do
                if (LORD.IsVisible( ply ) && !( table.HasValue( LORD.FriendsTable, tostring( ply:Nick() ) ) ) or ( LORD.CVARS.Bools["Aim at friends"].cvar:GetBool() and table.HasValue( LORD.FriendsTable, tostring( ply:Nick() ) ) and LORD.IsVisible(ply))) then
                        table.insert( players, ply );
                end
        end
       
        if (table.Count( players ) == 0) then
                LORD.Target = nil;
                return
        end;
       
        LORD.newAngle = LORD.ClosestAngle( players );
       
        if ( LORD.newAngle != nil ) then
                LORD.ply():SetEyeAngles( LORD.newAngle );
                LORD.Aimbotting = true;
        end
               
               
end

function LORD.SpeedHackOn( )
        local bool = true
       
        if bool and LORD.SpeedKeyDown then
                old_rcc("host_framerate", "12")
                bool = false
        end
end

function LORD.SpeedHackOff( )
        local bool = true
       
        if bool then
                old_rcc("host_framerate", "0")
                bool = false
        end
end

function LORD.TableSortByDistance( former, latter ) return latter:GetPos():Distance( LORD.ply():GetPos() ) > former:GetPos():Distance( LORD.ply():GetPos() ) end
function LORD.TableSortByAsc( former, latter ) print( "hey" ) return string.byte( string.lower( former.name ), 1 ) < string.byte( string.lower( latter.name ), 1 ) end

function LORD.GetPlayersByDistance( )
        local players = LORD.players( );
       
        table.sort( players, LORD.TableSortByDistance );
       
        return players;
end

function LORD.AngleTo(pos)
        local myAngs = LORD.ply:GetAngles()
        local needed = (pos - LORD.ply:GetShootPos()):Angle()
       
        myAngs.p = math.NormalizeAngle(myAngs.p)
        needed.p = math.NormalizeAngle(needed.p)
       
        myAngs.y = math.NormalizeAngle(myAngs.y)
        needed.y = math.NormalizeAngle(needed.y)
       
        local p = math.NormalizeAngle(needed.p - myAngs.p)
        local y = math.NormalizeAngle(needed.y - myAngs.y)
       
        return math.abs(p) + math.abs(y), {p = p, y = y}
end
 
function LORD.Anti()
       
        if !LORD.AFK then
                timer.Create("antiafk", 60, 0, function()
                        old_rcc("+forward")
                        timer.Simple(.1, function()
                                old_rcc("-forward")
                        end)
                end)
        else
                timer.Destroy("antiafk")
        end
end


function LORD.CreateMove( cmd )
        if (LORD.IsTTT && LORD.ply():Alive() && LORD.ply():Health() >= 1 && LORD.ply():Team() != TEAM_SPECTATOR) then
                LORD.ply().voice_battery = 100; --Infinite voichat time I don't need to check if it's TTT because swag
        end
       
        if (cmd:KeyDown( IN_ATTACK ) && !LORD.mouse1 && LORD.CVARS.Bools["Aim on mouse1"].cvar:GetBool() == true ) then
                LORD.mouse1 = true;
                LORD.Aimbot( );
        elseif ( !cmd:KeyDown( IN_ATTACK ) && LORD.mouse1 && LORD.CVARS.Bools["Aim on mouse1"].cvar:GetBool() == true ) then
                LORD.mouse1 = false;
        end
       
        if (LORD.CVARS.Bools["No Recoil"].cvar:GetBool() && IsValid( LORD.ply() ) && LORD.ply():Alive() && LORD.ply():Health() > 0 && IsValid( LORD.ply():GetActiveWeapon() )) then
                if ( LORD.ply():GetActiveWeapon().Primary && LORD.ply():GetActiveWeapon().Primary.Recoil ) then
                        LORD.Recoils[LORD.ply():GetActiveWeapon():EntIndex()] = LORD.ply():GetActiveWeapon().Primary.Recoil;
                        LORD.ply():GetActiveWeapon().Primary.Recoil = 0;
                end
        end
           
        local triggerbot = false;
       
        if (LORD.CVARS.Bools["Trigger bot"].cvar:GetBool()) then
                local trace = LORD.ply():GetEyeTrace();
               
                if (IsValid( trace.Entity ) && trace.Entity:IsPlayer() && (trace.Entity:Team() != LORD.ply():Team() || LORD.CVARS.Bools["Trigger bot team mates"].cvar:GetBool()) && (trace.Entity:GetFriendStatus() != "friend" || LORD.CVARS.Bools["Trigger bot steam friends"].cvar:GetBool())) then
                        triggerbot = true;
                end
        end
       
        if (!cmd:KeyDown( IN_ATTACK ) && (LORD.CVARS.Bools["Trigger bot"].cvar:GetBool() && LORD.Aimbotting || triggerbot)) then
                cmd:SetButtons( IN_ATTACK + cmd:GetButtons() );
        end
       
        if (cmd:KeyDown( IN_ATTACK ) && LORD.CVARS.Bools["Auto pistol"].cvar:GetBool() && IsValid( LORD.ply():GetActiveWeapon() ) && LORD.ply():GetActiveWeapon():GetClass() != "weapon_ar2" && LORD.ply():GetActiveWeapon():GetClass() != "weapon_smg1" && (!LORD.ply():GetActiveWeapon().Primary or LORD.ply():GetActiveWeapon().Primary.Automatic == false)) then
                if (LORD.ShouldFire == 3) then
                        cmd:RemoveKey( IN_ATTACK );
                        LORD.ShouldFire = 0;
                end
               
                LORD.ShouldFire = LORD.ShouldFire + 1;
        else
                LORD.ShouldFire = 0;
        end
               
                if (LORD.Aimbotting and LORD.CVARS.Bools["Nospread"].cvar:GetBool() and LORD.NoSpread) then
                        local active = false
                        local pos = LORD.TargetVecPos
                        local ply = LocalPlayer()
                        local weapon = ply:GetActiveWeapon()
                        if IsValid(weapon) and weapon.Primary and weapon.Primary.Cone and pos != nil then
                                local ang = (pos - ply:GetShootPos()):Angle()
                                local vecCone = Vector(-weapon.Primary.Cone, -weapon.Primary.Cone, 0)
                                ang = DS_manipulateShot(DS_md5PseudoRandom(DS_getUCMDCommandNumber(cmd)), ang:Forward(), vecCone):Angle()
                                cmd:SetViewAngles(ang)  
                        elseif IsValid(weapon) and weapon.Cone and pos != nil then
                                local ang = (pos - ply:GetShootPos()):Angle()
                                local vecCone = Vector(-weapon.Cone, -weapon.Cone, 0)
                                ang = DS_manipulateShot(DS_md5PseudoRandom(DS_getUCMDCommandNumber(cmd)), ang:Forward(), vecCone):Angle()
                                cmd:SetViewAngles(ang)
                        end
                end
               
                if ( LORD.IsDarkRP && LORD.CVARS.Bools["DarkRP godmode"].cvar:GetBool() && LORD.ply():Alive() && LORD.ply():Health() < 75 ) then
                        old_rcc("say", "/buyhealth")
                end
               
                if (LORD.CVARS.Bools["Flashlight spam"].cvar:GetBool() && LORD.ply():Alive()) then
                        old_rcc("impulse","100")
                end
               
                LORD.fakeang.p = math.Clamp( LORD.fakeang.p + ( cmd:GetMouseY() * 0.022 ), -89, 90 )
        LORD.fakeang.y = math.NormalizeAngle( LORD.fakeang.y + ( cmd:GetMouseX() * -0.022 ) )
                if LORD.CVARS.Bools["Silent aim"].cvar:GetBool() and !( LORD.CVARS.Bools["Anti aim"].cvar:GetBool() ) then
            cmd:SetViewAngles( LORD.fakeang )
        end
               
            if ( LORD.CVARS.Bools["Silent aim"].cvar:GetBool() and LORD.Aimbotting ) then
            local move = Vector( cmd:GetForwardMove(), cmd:GetSideMove(), 0 )
            local norm = move:GetNormal()
            local set = ( norm:Angle() + ( LORD.AimingAng - LORD.fakeang ) ):Forward() * move:Length()
            cmd:SetForwardMove( set.x )
            cmd:SetSideMove( set.y )
        end
       
        if (cmd:KeyDown( IN_JUMP )) then
                                local bool = true;
                if (!LORD.JumpReleased) then
                        if (LORD.CVARS.Bools["Bunny hop"].cvar:GetBool() && !LORD.ply():OnGround()) then
                                cmd:RemoveKey( IN_JUMP );
                                                                bool = true;
                        end
                        if (LORD.CVARS.Bools["Bunny hop"].cvar:GetBool() && LORD.ply():OnGround() and bool ) then
                                LORD.Jumps = LORD.Jumps + 1;
                                                                bool = false;
                        end
                                               
                else
                        LORD.JumpReleased = false
                end
                               
                        if(LORD.CVARS.Bools["Auto strafe"].cvar:GetBool() ) then
                                local traceRes = LORD.ply():EyeAngles()
                       
                                while( traceRes.y > LORD.OldEyePos.y ) do
                                        LORD.OldEyePos = traceRes;
                                        old_rcc("+moveleft")
                                        timer.Simple( .025, function()
                                                old_rcc("-moveleft")
                                        end)
                                end

                                while( LORD.OldEyePos.y > traceRes.y )  do
                                        LORD.OldEyePos = traceRes;
                                        old_rcc("+moveright")
                                        timer.Simple( .025, function()
                                                old_rcc("-moveright")
                                        end)
                                end
                        end
        elseif (!LORD.JumpReleased) then
                LORD.JumpReleased = true;
        end
               
                if( LORD.CVARS.Bools["Anti AFK"].cvar:GetBool() != LORD.AFK ) then
                        LORD.Anti()
                        LORD.AFK = !LORD.AFK
                end
               
                if( LORD.CVARS.Bools["Anti AFK"].cvar:GetBool() and LORD.IsTTT and LORD.ply():IsTraitor() and GetRoundState() != 1 ) then
                        old_rcc( "kill" )
                end
               
                local curview = cmd:GetViewAngles()
                local bool = true;
                if( LORD.CVARS.Bools["Anti aim"].cvar:GetBool() ) then
                        local C = LocalPlayer()
                        if (LORD.Aimbotting or LORD.mouse1 ) then return end

                        local v = cmd:GetViewAngles()
                        cmd:SetViewAngles(Angle(-181, v.y, 180))
                        bool = true;
                elseif bool then
                        cmd:SetViewAngles( curview )
                        bool = false
                end
end

function LORD.DerpFull( )
        local bool = true;
        local currentangle = LORD.ply():EyeAngles();
       
        if( LORD.CVARS.Bools["Derp"].cvar:GetBool() ) then
                local Rnumber = math.random(0,1000)
                LORD.ply():SetEyeAngles(Angle(currentangle.pitch + Rnumber ,currentangle.yaw + Rnumber , currentangle.roll + Rnumber ) )
                bool = true
        elseif bool then
                LORD.ply():SetEyeAngles(Angle(currentangle.pitch, currentangle.yaw, 0))
                bool = false
        end
       
        local bool2 = true;
        local wasd1 = true;
        if( LORD.CVARS.Bools["Fullbright"].cvar:GetBool() and wasd1 ) then
                old_rcc("mat_fullbright", "1")
                bool = true;
                wasd1 = false;
        elseif bool2 then
                old_rcc("mat_fullbright", "0")
                bool2 = false
                wasd1 = true;
        end
       
end

function MagnetoThrow()
-- Nice and easy, turn it slow 180
        timer.Simple(.02,Turn)
        timer.Simple(.04,Turn)
        timer.Simple(.06,Turn)
        timer.Simple(.08,Turn)
        timer.Simple(.10,Turn)
        timer.Simple(.12,Turn)
        timer.Simple(.14,Turn)
        timer.Simple(.16,Turn)
        timer.Simple(.18,Turn)
        timer.Simple(.20,Turn)
        timer.Simple(.22,Turn)
        timer.Simple(.24,Turn)
        timer.Simple(.26,Turn)
        timer.Simple(.28,Turn)
        timer.Simple(.30,Turn)
        timer.Simple(.32,Turn)
        timer.Simple(.34,Turn)
        timer.Simple(.36,Turn)
-- OH MY GOD WHIP AROUND 180
        timer.Simple(.46,TurnBack)
-- And deliver the final blow by pressing right click
        timer.Simple(.7,function() old_rcc("+attack") end)
        timer.Simple(.72,function() old_rcc("-attack") end)
end

function Turn()
-- Turn function
        LocalPlayer():SetEyeAngles(LocalPlayer():EyeAngles()-Angle(0,10,0))
end

function TurnBack()
-- Turn 180 function
        LocalPlayer():SetEyeAngles(LocalPlayer():EyeAngles()-Angle(0,180,0))
end
-- Making it a console command
old_ccadd("ThrowMagneto",MagnetoThrow)

function LORD.NoVisualRecoil( ply, pos, angles, fov )
   if (LORD.CVARS.Bools["No Visual Recoil"].cvar:GetBool() && LORD.ply():Health() > 0 && LORD.ply():Team() != TEAM_SPECTATOR && LORD.ply():Alive()) then
           return GAMEMODE:CalcView( ply, LORD.ply():EyePos(), LORD.ply():EyeAngles(), fov, 0.1 );
   end
end

function LORD.AddToColor( color, add )
        return color + add <= 255 and color + add or color + add - 255
end

function LORD.SubtractFromColor( color, sub )
        return color - sub >= 0 and color - sub or color - sub + 255
end

function LORD.ESP( )
                local curSpeed = 0;
        if (LORD.ToggleFade or 0 > CurTime()) then
                draw.DrawText( "Aimbot: "..(LORD.AimbotKeyDown and "on" or "off"), LORD.Font, ScrW()/2, ScrH()/2, Color( 255, 255, 255, 255 * (LORD.ToggleFade - CurTime()) ), 1 );
        end
       
        if (!LORD.CVARS.Bools["Crosshair"].cvar:GetBool() && !LORD.CVARS.Bools["ESP"].cvar:GetBool() && !LORD.CVARS.Bools["Show spectators"].cvar:GetBool()) then return end;
       
        if ( LORD.CVARS.Bools["Crosshair"].cvar:GetBool() ) then
                surface.SetDrawColor( Color( 255, 255, 255 ) );
                surface.DrawLine( ScrW()/2-10, ScrH()/2, ScrW()/2-4, ScrH()/2 );
                surface.DrawLine( ScrW()/2+10, ScrH()/2, ScrW()/2+4, ScrH()/2 );
                surface.DrawLine( ScrW()/2, ScrH()/2-10, ScrW()/2, ScrH()/2-4 );
                surface.DrawLine( ScrW()/2, ScrH()/2+10, ScrW()/2, ScrH()/2+4 );
        end
       
            curSpeed = math.Round( LocalPlayer():GetVelocity():Length() )
                if ( curSpeed > LORD.maxSpeed && LocalPlayer():Alive() ) then
            LORD.maxSpeed = curSpeed
                end
                if LORD.CVARS.Bools["Bunny hop hud"].cvar:GetBool() then
               draw.RoundedBox( 4, ScrW()-175, 10, 150, 105, Color( 0, 0, 0, 150 ) )
               draw.SimpleText( "LordHack V"..LORD.Version, LORD.Font, ScrW()-150, 15, Color( 0, 150, 255, 255 ) )
               draw.SimpleText( "Speed: " .. curSpeed, LORD.Font, ScrW()-165, 30, Color( 255, 255, 255, 255 ) )
               draw.SimpleText( "Max Speed: " .. LORD.maxSpeed, LORD.Font, ScrW()-165, 45, Color( 255, 255, 255, 255 ) )
               draw.SimpleText( "FPS: " .. math.Round( 1 / FrameTime() ), LORD.Font, ScrW()-165, 60, Color( 255, 255, 255, 255 ) )
                           draw.SimpleText( "Map: " .. LORD.Map, LORD.Font, ScrW()-165, 75, Color( 255, 255, 255, 255 ) )
                           draw.SimpleText( "Number of Jumps: " .. tostring(math.floor(LORD.Jumps/2)), LORD.Font, ScrW()-165, 90, Color( 255, 255, 255, 255 ) )
       end
           
        if (LORD.CVARS.Bools["Show spectators"].cvar:GetBool()) then
                local spectators = 0;
                for _, ply in pairs( LORD.players() ) do
                        if (ply != LORD.ply() && (ply:GetObserverMode() == OBS_MODE_IN_EYE|| ply:GetObserverMode() == OBS_MODE_CHASE) && ply:GetObserverTarget() == LORD.ply()) then
                                if (spectators == 0 && !LORD.CVARS.Bools["Simplify spectator list"].cvar:GetBool()) then
                                        draw.DrawText( "Spectating you: "..ply:Nick(), LORD.Font, ScrW()/2, 25, Color( 255, 100, 50 ), 1 );
                                elseif (!LORD.CVARS.Bools["Simplify spectator list"].cvar:GetBool()) then
                                        draw.DrawText( ply:Nick(), LORD.Font, ScrW()/2, 25 + spectators*13, Color( 255, 100, 50 ), 1 );
                                else
                                        draw.DrawText( "Someone is spectating you!", LORD.Font, ScrW()/2, 25, Color( 255, 100, 50 ), 1 );
                                        break;
                                end
                               
                                spectators = spectators + 1;
                        end
                end
        end
       
        if ( !LORD.CVARS.Bools["ESP"].cvar:GetBool() ) then return end
       
        surface.SetFont( LORD.Font );
       
        for _, ply in pairs( LORD.players() ) do
                if (ply != LORD.ply() && ply:Health() >= 1 && ply:Alive() && ply:Team() != TEAM_SPECTATOR) then
                        local min, max = ply:GetRenderBounds();
                        local pos = ply:GetPos() + Vector( 0, 0, ( min.z + max.z ) );
                        local color = Color( 50, 255, 50, 255 );
                       
                        if ( ply:Health() <= 10 ) then color = Color( 255, 0, 0, 255 );
                        elseif ( ply:Health() <= 20 ) then color = Color( 255, 50, 50, 255 );
                        elseif ( ply:Health() <= 40 ) then color = Color( 250, 250, 50, 255 );
                        elseif ( ply:Health() <= 60 ) then color = Color( 150, 250, 50, 255 );
                        elseif ( ply:Health() <= 80 ) then color = Color( 100, 255, 50, 255 ); end
                       
                        pos = ( pos + Vector( 0, 0, 10 ) ):ToScreen();
                       
                        if ( LORD.CVARS.Bools["ESP: Show name"].cvar:GetBool() ) then
                                                                local colorname = Color( 255, 255, 255, 255 )
                                                                local time = CurTime()
                                                                local r = math.abs(math.sin(time * 2 ) * 255)
                                                                local g = math.abs(math.sin(time * 2 + 2 ) * 255)
                                                                local b = math.abs(math.sin(time * 2 + 4 ) * 255)
                                                                if ( LORD.IsTTT && ply:IsTraitor() ) then
                                                                        colorname = Color ( 255, 150, 150, 255 )
                                                                end
                                                                if table.HasValue( LORD.FriendsTable, tostring( ply:Nick() ) ) then
                                                                        colorname = Color ( r, g, b, 255 )
                                                                end
                                local width, height = surface.GetTextSize( tostring( ply:Nick() ) ); -- I have to do tostring because sometimes errors would occur
                                draw.DrawText( ply:Nick(), LORD.Font, pos.x, pos.y-height/2, colorname, 1 );
                        end
                       
                        if ( LORD.CVARS.Bools["ESP: Show user group (admins)"].cvar:GetBool() && ply:GetNetworkedString( "UserGroup" ) != "user" ) then
                                local width, height = surface.GetTextSize( ply:GetNetworkedString( "UserGroup" ) );
                                draw.DrawText( ply:GetNetworkedString( "UserGroup" ), LORD.Font, pos.x, pos.y-height-3, Color( 255, 200, 50, 255 ), 1 );
                                pos.y = pos.y - (height - 6);
                        end
                       
                        if ( LORD.IsTTT && LORD.CVARS.Bools["ESP: TTT Show traitors"].cvar:GetBool() && ply:IsTraitor() ) then
                                local width, height = surface.GetTextSize( "TRAITOR" );
                                draw.DrawText( "TRAITOR", LORD.Font, pos.x, pos.y-height-3, Color( 255, 0, 0, 255 ), 1 );
                        end
                       
                        pos = ply:GetPos():ToScreen();
                       
                        if (LORD.CVARS.Bools["ESP: Show health"].cvar:GetBool()) then
                                local width, height = surface.GetTextSize( "Health: "..tostring( ply:Health() ) );
                                draw.DrawText( "Health: "..tostring( ply:Health() ), LORD.Font, pos.x, pos.y, color, 1 );
                                pos.y = pos.y + 13;
                        end
                       
                        if (LORD.CVARS.Bools["ESP: Show weapon"].cvar:GetBool() && IsValid( ply:GetActiveWeapon() )) then
                                local width, height = surface.GetTextSize( ply:GetActiveWeapon():GetPrintName() or ply:GetActiveWeapon():GetClass() );
                                draw.DrawText( ply:GetActiveWeapon():GetPrintName() or ply:GetActiveWeapon():GetClass(), LORD.Font, pos.x, pos.y, Color( 255, 200, 50 ), 1 );
                        end
                end
        end
        for k, e in pairs( player.GetAll() ) do
                if (LORD.CVARS.Bools["ESP: Show tracers"].cvar:GetBool() && e:Team() != TEAM_SPECTATOR && e != LORD.ply() && e:Health() > 0 && LORD.CVARS.Bools["ESP"].cvar:GetBool() && LORD.ply():GetObserverTarget() != e) then
                                                local x = ScrW() / 2;
                                                local y = ScrH() / 2;
                                                local pos = e:GetPos():ToScreen();
                                                local time = CurTime()
                                                local r = math.abs(math.sin(time * 2 ) * 255)
                                                local g = math.abs(math.sin(time * 2 + 2 ) * 255)
                                                local b = math.abs(math.sin(time * 2 + 4 ) * 255)
                                                surface.SetDrawColor( team.GetColor( e:Team( ) ) );
                                                if table.HasValue( LORD.FriendsTable, tostring( e:Nick() ) ) then
                                                        surface.SetDrawColor( r, g, b, 255      );
                                                end
                                                if(LORD.IsTTT && e:IsTraitor()) then
                                                        surface.SetDrawColor( 255, 0, 0, 255 );
                                                end
                                                if(LORD.IsTTT && e:IsDetective()) then
                                                        surface.SetDrawColor( 0, 0, 255, 255);
                                                end
                                                surface.DrawLine(x, y, pos.x, pos.y);
                end
        end
       
        if (LORD.IsTTT) then
                if (LORD.CVARS.Bools["ESP: TTT Show C4"].cvar:GetBool()) then
                        for _, ent in pairs( ents.FindByClass( "ttt_c4" ) ) do
                                if (!LORD.ply():IsTraitor() or !ent:GetArmed()) then
                                        local pos = ent:GetPos():ToScreen();
                                        local width, height = surface.GetTextSize( "C4" );
                                       
                                        draw.DrawText( !ent:GetArmed() and "C4 - Unarmed" or "C4 - "..string.FormattedTime(ent:GetExplodeTime() - CurTime(), "%02i:%02i"), LORD.Font, pos.x, pos.y-height/2, Color( 255, 200, 200, 255 ), 1 );
                                end
                        end
                end
               
                if (LORD.CVARS.Bools["ESP: TTT Show dead bodies"].cvar:GetBool()) then
                        for _, ent in pairs( ents.FindByClass( "prop_ragdoll" ) ) do
                                local name = CORPSE.GetPlayerNick( ent, false );
                               
                                if ( name != false ) then
                                        local pos = ent:GetPos():ToScreen();
                                        local width, height = surface.GetTextSize( name );
                                       
                                        draw.DrawText( name, LORD.Font, pos.x, pos.y-height/2, Color( 255, 255, 255, 255 ), 1 );
                                       
                                        if ( !CORPSE.GetFound(ent, false) ) then
                                                draw.DrawText( "Unidentified", LORD.Font, pos.x, pos.y-height/2+12, Color( 200, 200, 0, 255 ), 1 );
                                        end
                                end
                        end
                end
        end

        if (LORD.IsGmodZ) then
                for _, ent in pairs( ents.FindByClass( "gmodz_item" ) ) do
                        if (ent.id) then
                                local item = items[ent.id];
                               
                                if (item) then
                                        local name = item.name or "ERROR";
                                        local pos = ent:GetPos():ToScreen();
                                        local width, height = surface.GetTextSize( name );
                                       
                                        draw.DrawText( name, LORD.Font, pos.x, pos.y-height/2, Color( 255, 255, 220, 255 ), 1 );
                                end
                        else
                                net.Start( "item_ask_info" );
                                        net.WriteEntity( ent );
                                net.SendToServer();
                        end
                end
        end
       
        if (LORD.HeadPos != nil) then
                local width = 5;
                local height = 5;
                surface.SetDrawColor( Color( 255, 0, 0, 255 ) );
                surface.DrawOutlinedRect( LORD.HeadPos.x-width/2, LORD.HeadPos.y-height/2, width, height );
        end
end

function LORD.Chams()
        if (LORD.CVARS.Bools["Chams"].cvar:GetBool()) then
                for _, ply in pairs( LORD.GetPlayersByDistance( ) ) do
                        if (ply != LORD.ply() && IsValid( ply ) && ply:Alive() && ply:Health() > 0 && ply:Team() != TEAM_SPECTATOR and LORD.IsOnScreen( ply )) then
                                                        local time = CurTime()
                                                                local r = math.abs(math.sin(time * 2 ) * 255)
                                                                local g = math.abs(math.sin(time * 2 + 2 ) * 255)
                                                                local b = math.abs(math.sin(time * 2 + 4 ) * 255)
                                local color = (LORD.IsTTT and ply:IsTraitor( )) and Color( 200, 50, 50 ) or (LORD.IsTTT and ply:IsDetective( )) and Color( 50, 50, 200 ) or table.HasValue( LORD.FriendsTable, tostring( ply:Nick() ) ) and Color( r, g, b ) or team.GetColor( ply:Team( ) );
                                cam.Start3D( LORD.ply():EyePos(), LORD.ply():EyeAngles() );
                                        render.SuppressEngineLighting( true );
                                        render.SetColorModulation( color.r/255, color.g/255, color.b/255, 1 );
                                        render.MaterialOverride( LORD.Mat );
                                        ply:DrawModel();
                                        render.SetColorModulation( LORD.AddToColor( color.r, 150 )/255, LORD.AddToColor( color.g, 150 )/255, LORD.AddToColor( color.b, 150 )/255, 1 );
                                       
                                       if (IsValid( ply:GetActiveWeapon() )) then
                                                ply:GetActiveWeapon():DrawModel()
                                        end
                                                                               
                                                                                if(table.HasValue( LORD.FriendsTable, tostring( ply:Nick() ) ) ) then
                                                                                                render.SetColorModulation( r/255, g/255, b/255, 1 );
                                                                                                end
                                                                               
                                                                                if(LORD.IsTTT && ply:IsDetective()) then
                                                                                                render.SetColorModulation( 0, 0, 1, 1 );
                                                                                                end
                                       
                                        if (LORD.IsTTT && ply:IsTraitor()) then
                                                render.SetColorModulation( 1, 0, 0, 1 );
                                        else
                                                render.SetColorModulation( 1, 1, 1, 1 );
                                                end
                                       
                                        render.MaterialOverride();
                                        render.SetModelLighting( 4, color.r/255, color.g/255, color.b/255 );
                                        ply:DrawModel();
                                        render.SuppressEngineLighting( false );
                                cam.End3D();
                        end
                end
               
                for _, ent in pairs( ents.FindByClass( "ttt_c4" ) ) do
                        cam.Start3D( LORD.ply():EyePos(), LORD.ply():EyeAngles() );
                                render.SuppressEngineLighting( true );
                                render.SetColorModulation( 1, 0, 0, 1 );
                                render.MaterialOverride( LORD.Mat );
                                ent:DrawModel( );
                               
                                render.SetColorModulation( 1, 1, 1, 1 );
                                render.MaterialOverride();
                                render.SetModelLighting( BOX_TOP, 1, 1, 1 )
                                ent:DrawModel();
                                       
                                render.SuppressEngineLighting( false );
                        cam.End3D();
                end
               
                if (LORD.IsTTT) then
                        for _, ent in pairs( ents.FindByClass( "prop_ragdoll" ) ) do
                                if ( CORPSE.GetPlayerNick(ent, false) != false ) then
                                        cam.Start3D( LORD.ply():EyePos(), LORD.ply():EyeAngles() );
                                                render.SuppressEngineLighting( true );
                                                render.SetColorModulation( 1, 0.8, 0.5, 1 );
                                                render.MaterialOverride( LORD.Mat );
                                                ent:DrawModel( );
                                               
                                                render.SetColorModulation( 1, 1, 1, 1 );
                                                render.MaterialOverride();
                                                render.SetModelLighting( BOX_TOP, 1, 1, 1 )
                                                ent:DrawModel();
                                                       
                                                render.SuppressEngineLighting( false );
                                        cam.End3D();
                                end
                        end
                end
                               
                                if ( LORD.CVARS.Bools["Chams: Zmod show drinks"].cvar:GetBool() ) then
                                        for k, v in pairs( ents.GetAll() ) do
                                        if( table.HasValue(LORD.ZmodDrinks, v) ) then
                                                cam.Start3D( LORD.ply():EyePos(), LORD.ply():EyeAngles() );
                                                        render.SuppressEngineLighting( true );
                                                        render.SetColorModulation( 1, 0, 1, 1 );
                                                        render.MaterialOverride( LORD.Mat );
                                                        v:DrawModel( );
                                           
                                                        render.SetColorModulation( 1, 1, 1, 1 );
                                                        render.MaterialOverride();
                                                        render.SetModelLighting( BOX_TOP, 1, 1, 1 )
                                                        v:DrawModel();
                                                     
                                                        render.SuppressEngineLighting( false );
                        cam.End3D();
                                        end
                                        end
                                end
                               
                                if ( LORD.CVARS.Bools["Chams: Zmod show food"].cvar:GetBool() ) then
                                        for k, v in pairs( ents.GetAll() ) do
                                        if( table.HasValue(LORD.ZmodFood, v) ) then
                                                cam.Start3D( LORD.ply():EyePos(), LORD.ply():EyeAngles() );
                                                        render.SuppressEngineLighting( true );
                                                        render.SetColorModulation( 1, 0, 1, 1 );
                                                        render.MaterialOverride( LORD.Mat );
                                                        v:DrawModel( );
                                           
                                                        render.SetColorModulation( 1, 1, 1, 1 );
                                                        render.MaterialOverride();
                                                        render.SetModelLighting( BOX_TOP, 1, 1, 1 )
                                                        v:DrawModel();
                                                     
                                                        render.SuppressEngineLighting( false );
                        cam.End3D();
                                        end
                                        end
                                end
                               
                                if ( LORD.CVARS.Bools["Chams: Zmod show equipment"].cvar:GetBool() ) then
                                        local ammo = ents.FindByClass("zmod_ammo_*")
                                        for k, v in pairs( ents.GetAll() ) do
                                        if( table.HasValue(LORD.ZmodEquip, v) or table.HasValue(ammo, v) ) then
                                                cam.Start3D( LORD.ply():EyePos(), LORD.ply():EyeAngles() );
                                                        render.SuppressEngineLighting( true );
                                                        render.SetColorModulation( 1, 0, 1, 1 );
                                                        render.MaterialOverride( LORD.Mat );
                                                        v:DrawModel( );
                                           
                                                        render.SetColorModulation( 1, 1, 1, 1 );
                                                        render.MaterialOverride();
                                                        render.SetModelLighting( BOX_TOP, 1, 1, 1 )
                                                        v:DrawModel();
                                                     
                                                        render.SuppressEngineLighting( false );
                        cam.End3D();
                                        end
                                        end
                                end
                               
                                if ( LORD.CVARS.Bools["Chams: Zmod show weps"].cvar:GetBool() ) then
                                        local weps = ents.FindByClass("zweap_*")
                                        for k, v in pairs( ents.GetAll() ) do
                                        if( table.HasValue(LORD.ZmodWeps, v) or table.HasValue(weps, v ) ) then
                                                cam.Start3D( LORD.ply():EyePos(), LORD.ply():EyeAngles() );
                                                        render.SuppressEngineLighting( true );
                                                        render.SetColorModulation( 1, 0, 1, 1 );
                                                        render.MaterialOverride( LORD.Mat );
                                                        v:DrawModel( );
                                           
                                                        render.SetColorModulation( 1, 1, 1, 1 );
                                                        render.MaterialOverride();
                                                        render.SetModelLighting( BOX_TOP, 1, 1, 1 )
                                                        v:DrawModel();
                                                     
                                                        render.SuppressEngineLighting( false );
                        cam.End3D();
                                        end
                                        end
                                end

        end
end

function LORD.PlayerDeath( ply, wep, killer )
                        LORD.PrintChat( Color( 255, 255, 255 ), ply:Nick().." has died!" );
end

timer.Create( LORD.TimerName, 0.25, 0, function( )      
        if (!LORD.IsTTT || GetRoundState() != 3) then
                table.Empty( LORD.DeadPlayers );
                return;
        end
       
        for _, ply in pairs( LORD.players() ) do
                if ((!ply:Alive() || ply:Health() <= 0) && !table.HasValue( LORD.DeadPlayers, ply )) then
                        table.insert( LORD.DeadPlayers, ply );
                        LORD.PlayerDeath( ply );
                end
        end
end )

function LORD.TraitorDetector()
        if (!LORD.IsTTT || LORD.ply():IsTraitor()) then return end
       
        if (GetRoundState() == 2) then
                for _, wep in pairs(ents.GetAll()) do
                        if (wep.CanBuy && wep:IsWeapon() && !table.HasValue(LORD.TWeaponsFound, wep:EntIndex())) then
                                table.insert( LORD.TWeaponsFound, wep:EntIndex() )
                        end
                end
        end
       
        if (GetRoundState() != 3 && GetRoundState() != 2) then
                table.Empty( LORD.Traitors );
                table.Empty( LORD.TWeaponsFound );
                return;
        end
       
        for _, wep in pairs(ents.GetAll()) do
                if (wep:IsWeapon() && wep.CanBuy && IsValid( wep:GetOwner() ) && wep:GetOwner():IsPlayer() && !table.HasValue( LORD.TWeaponsFound, wep:EntIndex() )) then
                        local ply = wep:GetOwner();
                        table.insert( LORD.TWeaponsFound, wep:EntIndex() );
                       
                        if (!ply:IsDetective()) then
                                if (!table.HasValue(LORD.Traitors, ply)) then
                                        table.insert(LORD.Traitors, ply);
                                end
                                if (ply != LORD.ply() && !LORD.ply():IsTraitor() && LORD.CVARS.Bools["Traitor Detector"].cvar:GetBool()) then
                                        chat.AddText( Color( 255, 150, 150 ), ply:Nick(), Color( 255, 255, 255 ), " is a ", Color( 255, 50, 50 ), "traitor: ", Color( 200, 120, 50 ), wep:GetPrintName() or wep:GetClass() );
                                end
                        end
                end
        end
end

function LORD.Menu( )
        --Creating main stuff
        local UsedCVARS = { };
                local x, y = 500, 300;
        local px, py = x - 10, y - 30
        local tx, ty = x - 20, y - 65
           
        local Panel = vgui.Create( "DFrame" );
        Panel:SetSize( x, y );
        Panel:SetPos( ScrW()/2-Panel:GetWide()/2, ScrH()/2-Panel:GetTall()/2 );
        Panel:SetTitle( "LordHack v".. LORD.Version );
        Panel:MakePopup();
                Panel.Paint = function()
                    draw.RoundedBox( 0, 0, 0, x, y, Color( 25, 55, 105, 55 ) )
                    surface.SetDrawColor( Color( 0, 0, 0, 255 ) )
                    surface.DrawOutlinedRect( 0, 0, x, y )
                end
       
        local SettingsSheet = vgui.Create( "DPropertySheet", Panel );
        SettingsSheet:SetPos( 0, 23 );
        SettingsSheet:SetSize( SettingsSheet:GetParent():GetWide(), SettingsSheet:GetParent():GetTall() - 23 );
                SettingsSheet.Paint = function()
                                        draw.RoundedBox( 0, 0, 0, px, py, Color( 0, 0, 0, 0 ) )
                end
       
        local MainPanel = vgui.Create( "DPanel", Panel );
        MainPanel:SetPos( 0, 0 );
        MainPanel:SetSize( MainPanel:GetParent():GetWide(), MainPanel:GetParent():GetTall() - 23 );
        MainPanel.Paint = function()
                    draw.RoundedBox( 0, 0, 0, tx, ty, Color( 0, 0, 0, 155 ) )
                    surface.SetDrawColor( Color( 0, 0, 0, 255 ) )
                    surface.DrawOutlinedRect( 0, 0, tx, ty )
                end;
       
        local AimPanel = vgui.Create( "DPanel", Panel );
        AimPanel:SetPos( 0, 0 );
        AimPanel:SetSize( MainPanel:GetParent():GetWide(), MainPanel:GetParent():GetTall() - 23 );
        AimPanel.Paint = function()
                    draw.RoundedBox( 0, 0, 0, tx, ty, Color( 0, 0, 0, 155 ) )
                    surface.SetDrawColor( Color( 0, 0, 0, 255 ) )
                    surface.DrawOutlinedRect( 0, 0, tx, ty )
                end;
        AimPanel:SetVisible( false );
       
        local ESPPanel = vgui.Create( "DPanel", Panel );
        ESPPanel:SetPos( 0, 0 );
        ESPPanel:SetSize( MainPanel:GetParent():GetWide(), MainPanel:GetParent():GetTall() - 23 );
        ESPPanel.Paint = function()
                    draw.RoundedBox( 0, 0, 0, tx, ty, Color( 0, 0, 0, 155 ) )
                    surface.SetDrawColor( Color( 0, 0, 0, 255 ) )
                    surface.DrawOutlinedRect( 0, 0, tx, ty )
                end;
        ESPPanel:SetVisible( false );
       
        local MiscPanel = vgui.Create( "DPanel", Panel );
        MiscPanel:SetPos( 0, 25 );
        MiscPanel:SetSize( MainPanel:GetParent():GetWide(), MainPanel:GetParent():GetTall() - 23 );
        MiscPanel.Paint = function()
                    draw.RoundedBox( 0, 0, 0, tx, ty, Color( 0, 0, 0, 155 ) )
                    surface.SetDrawColor( Color( 0, 0, 0, 255 ) )
                    surface.DrawOutlinedRect( 0, 0, tx, ty )
                end;
        MiscPanel:SetVisible( false );
       
        SettingsSheet:AddSheet("General", MainPanel, "gui/silkicons/user", false, false, "General settings");
        SettingsSheet:AddSheet("Aimbot", AimPanel, "gui/silkicons/user", false, false, "Aimbot settings");
        SettingsSheet:AddSheet("ESP/Chams", ESPPanel, "gui/silkicons/user", false, false, "ESP/Chams settings");
        SettingsSheet:AddSheet("Misc", MiscPanel, "gui/silkicons/user", false, false, "Misc settings");
        --==Main Panel==--
        local Label = vgui.Create( "DLabel", MainPanel );
        Label:SetPos( 10, 5 );
        Label:SetColor( Color( 255, 255, 255, 255 ) );
        Label:SetText( "Settings" );
        Label:SizeToContents();
       
        Label = vgui.Create( "DLabel", MainPanel );
        Label:SetPos( 275, 5 );
        Label:SetColor( Color( 255, 255, 255, 255 ) );
        Label:SetText( "Thanks for using LordHack!" );
        Label:SizeToContents();
       
        local List = vgui.Create( "DPanelList", MainPanel );
        List:SetPos( 10, 20 );
        List:SetSize( 200, 200 );
        List:SetSpacing( 5 );
        List:EnableHorizontal( false );
        List:EnableVerticalScrollbar( true );
        List:SetPadding( 5 );
        function List:Paint()
                draw.RoundedBox( 4, 0, 0, List:GetWide(), List:GetTall(), Color( 0, 0, 0, 100 ) );
        end
       
        table.sort( LORD.CVARS.Bools, LORD.TableSortByAsc );
       
        for name, base in pairs(LORD.CVARS.Bools) do
                if (base.OnMenu && base.main) then
                        local CheckBox = vgui.Create( "DCheckBoxLabel" );
                        CheckBox:SetText( name );
                        CheckBox:SetConVar( base.cvar:GetName() );
                        CheckBox:SetValue( base.cvar:GetBool() );
                        CheckBox:SizeToContents();
                        List:AddItem( CheckBox );
                        table.insert( UsedCVARS, base );
                end
        end
       
        List = vgui.Create( "DPanelList", MainPanel );
        List:SetPos( 275, 20 );
        List:SetSize( 200, 200 );
        List:SetSpacing( 5 );
        List:EnableHorizontal( false );
        List:EnableVerticalScrollbar( true );
        List:SetPadding( 5 );
        function List:Paint()
                draw.RoundedBox( 4, 0, 0, List:GetWide(), List:GetTall(), Color( 0, 0, 0, 100 ) );
        end
        --==Aimbot==--
        Label = vgui.Create( "DLabel", AimPanel );
        Label:SetPos( 10, 5 );
        Label:SetColor( Color( 255, 255, 255, 255 ) );
        Label:SetText( "Aimbot settings" );
        Label:SizeToContents();
       
        local List = vgui.Create( "DPanelList", AimPanel );
        List:SetPos( 10, 20 );
        List:SetSize( 200, 200 );
        List:SetSpacing( 5 );
        List:EnableHorizontal( false );
        List:EnableVerticalScrollbar( true );
        List:SetPadding( 5 );
        function List:Paint()
                draw.RoundedBox( 4, 0, 0, List:GetWide(), List:GetTall(), Color( 0, 0, 0, 100 ) );
        end
       
        for name, base in pairs(LORD.CVARS.Bools) do
                if (base.OnMenu && !base.main && string.find( base.cvar:GetName(), "aim" )) then
                        local CheckBox = vgui.Create( "DCheckBoxLabel" );
                        CheckBox:SetText( name );
                        CheckBox:SetConVar( base.cvar:GetName() );
                        CheckBox:SetValue( base.cvar:GetBool() );
                        CheckBox:SizeToContents();
                        List:AddItem( CheckBox );
                        table.insert( UsedCVARS, base );
                end
        end
       
        local FOVSlider = vgui.Create( "DNumSlider", AimPanel );
        FOVSlider:SetPos( 275, -15 );
        FOVSlider:SetSize( 150, 100 );
        FOVSlider:SetText( "   Max Angle" );
        FOVSlider:SetMin( 0 );
        FOVSlider:SetMax( 180 );
        FOVSlider:SetDecimals( 0 );
        FOVSlider:SetConVar( LORD.RandomPrefix.."_aimbot_max_angle" );
        FOVSlider.Paint = function()
                draw.RoundedBox( 4, 0, 36, FOVSlider:GetWide(), 25, Color( 0, 0, 0, 100 ) );
        end
        --==ESP==--
        Label = vgui.Create( "DLabel", ESPPanel );
        Label:SetPos( 10, 5 );
        Label:SetColor( Color( 255, 255, 255, 255 ) );
        Label:SetText( "ESP/Chams settings" );
        Label:SizeToContents();
       
        List = vgui.Create( "DPanelList", ESPPanel );
        List:SetPos( 10, 20 );
        List:SetSize( 200, 200 );
        List:SetSpacing( 5 );
        List:EnableHorizontal( false );
        List:EnableVerticalScrollbar( true );
        List:SetPadding( 5 );
        function List:Paint()
                draw.RoundedBox( 4, 0, 0, List:GetWide(), List:GetTall(), Color( 0, 0, 0, 100 ) );
        end
       
        for name, base in pairs(LORD.CVARS.Bools) do
                if (base.OnMenu && !base.main && (string.find( base.cvar:GetName(), "esp" ) || string.find( base.cvar:GetName(), "cham" ))) then
                        local CheckBox = vgui.Create( "DCheckBoxLabel" );
                        CheckBox:SetText( name );
                        CheckBox:SetConVar( base.cvar:GetName() );
                        CheckBox:SetValue( base.cvar:GetBool() );
                        CheckBox:SizeToContents();
                        List:AddItem( CheckBox );
                        table.insert( UsedCVARS, base );
                end
        end
        --==MISC==--
        Label = vgui.Create( "DLabel", MiscPanel );
        Label:SetPos( 10, 5 );
        Label:SetColor( Color( 255, 255, 255, 255 ) );
        Label:SetText( "Misc settings" );
        Label:SizeToContents();
       
        List = vgui.Create( "DPanelList", MiscPanel );
        List:SetPos( 10, 20 );
        List:SetSize( 200, 200 );
        List:SetSpacing( 5 );
        List:EnableHorizontal( false );
        List:EnableVerticalScrollbar( true );
        List:SetPadding( 5 );
        function List:Paint()
                draw.RoundedBox( 4, 0, 0, List:GetWide(), List:GetTall(), Color( 0, 0, 0, 100 ) );
        end
       
        for name, base in pairs(LORD.CVARS.Bools) do
                if (base.OnMenu && !table.HasValue( UsedCVARS, base )) then
                        local CheckBox = vgui.Create( "DCheckBoxLabel" );
                        CheckBox:SetText( name );
                        CheckBox:SetConVar( base.cvar:GetName() );
                        CheckBox:SetValue( base.cvar:GetBool() );
                        CheckBox:SizeToContents();
                        List:AddItem( CheckBox );
                end
        end
end

function LORD.UpdateMenu()
        local Panel = vgui.Create( "DFrame" );
        Panel:SetSize( 800, 600 );
        Panel:SetPos( ScrW()/2-Panel:GetWide()/2, ScrH()/2-Panel:GetTall()/2 );
        Panel:SetTitle( "LordHack - Notice" );
        Panel:MakePopup();
       
        local Label = vgui.Create( "DLabel", Panel );
        Label:SetColor( Color( 255, 255, 255, 255 ) );
        Label:SetFont( "DermaLarge" );
        Label:SetText( "Your version is outdated! "..LORD.Version );
        Label:SizeToContents();
        Label:SetPos( Label:GetParent():GetWide()/2-Label:GetWide()/2-5, 50 );
        Label.Paint = function()
                Label:SetColor( Color( 255, 255 - (math.sin( CurTime() * 4 ) * 255), 255 - (math.sin( CurTime() * 4 ) * 255), 255 ) );
        end
       
        local HTML = vgui.Create( "HTML", Panel );
        HTML:OpenURL( "http://lordofgears2.googlecode.com/svn/trunk/changelog.txt" );
        HTML:SetSize( HTML:GetParent():GetWide() - 50, HTML:GetParent():GetTall() - 160 );
        HTML:SetPos( 25, 100 )
        HTML.Paint = function()
                surface.SetDrawColor( Color( 255, 255, 255, 255 ) );
                surface.DrawRect( 0, 0, HTML:GetWide(), HTML:GetTall() );
        end
       
        local Button = vgui.Create( "DButton", Panel );
        Button:SetText( "Save" );
        Button:SetSize( Button:GetParent():GetWide() - 50, 25 );
        Button:SetPos( 25, Button:GetParent():GetTall() - 30 );
        Button.DoClick = function()
                HTML:SetVisible( false );
                Panel:SetSize( 400, 150 );
                Panel:SetPos( ScrW()/2-Panel:GetWide()/2, ScrH()/2-Panel:GetTall()/2 );
                Label:SetText( "Saved to data/lord"..LORD.LatestVersion..".txt" );
                Label:SizeToContents();
                Label:SetPos( Label:GetParent():GetWide()/2-Label:GetWide()/2-5, 50 );
                old_filewrite( "lord"..LORD.LatestVersion..".txt", LORD.NewVersion );
        end
end

LORD.Init();

LORD.AddHook( "RenderScreenspaceEffects" , LORD.RandomString( 0, true, true ), LORD.Chams );
LORD.AddHook( "Think", LORD.RandomString( 0, true, true ), LORD.Aimbot );
LORD.AddHook( "Think", LORD.RandomString( 0, true, true ), LORD.TraitorDetector );
LORD.AddHook( "CreateMove", LORD.RandomString( 0, true, true ), LORD.CreateMove );
LORD.AddHook( "CalcView", LORD.RandomString( 0, true, true ), LORD.NoVisualRecoil );
LORD.AddHook( "HUDPaint", LORD.RandomString( 0, true, true ), LORD.ESP );
LORD.AddHook("Think", LORD.RandomString( 0, true, true ), LORD.DerpFull );

old_ccadd( LORD.RandomPrefix.."_unload", function( ply, cmd, args )
        for i = 1, #LORD.RandomHooks.hook do
                hook.Remove( LORD.RandomHooks.hook[i], LORD.RandomHooks.name[i] );
                LORD.Print( true, true, Color( 255, 255, 255 ), "Unhooked "..LORD.RandomHooks.hook[i].." using name "..LORD.RandomHooks.name[i] );
        end

        old_ccrem( LORD.RandomPrefix.."_unload" );
        old_ccrem( LORD.RandomPrefix.."_menu" );
        old_ccrem( "+"..LORD.RandomPrefix.."_pewpew" );
        old_ccrem( "-"..LORD.RandomPrefix.."_pewpew" );
        old_ccrem( LORD.RandomPrefix.."_aimbot_toggle" );
                old_ccrem( LORD.RandomPrefix.."_friends_list" );
                old_ccrem( LORD.RandomPrefix.."_friends_add" );
                old_ccrem( LORD.RandomPrefix.."_friends_remove" );
                old_ccrem( LORD.RandomPrefix.."_boost1" );
                old_ccrem( LORD.RandomPrefix.."_boost2" );
                old_ccrem( LORD.RandomPrefix.."_boost3" );
                old_ccrem( LORD.RandomPrefix.."_ents_list" );
                old_ccrem( LORD.RandomPrefix.."_ents_add" );
                old_ccrem( LORD.RandomPrefix.."_ents_remove" );
                old_ccrem( "+"..LORD.RandomPrefix.."_vroom" );
                old_ccrem( "-"..LORD.RandomPrefix.."_vroom" );
        timer.Destroy( LORD.TimerName );
        LORD.Unloaded = true;
        LORD.Print( true, true, Color( 255, 255, 255 ), "Unloaded successfully!" );
                if LORD.CVARS.Bools["Fullbright"].cvar:GetBool() then
                        old_rcc("mat_fullbright", "0")
                end
end );

old_ccadd( LORD.RandomPrefix.."_menu", LORD.Menu );

old_ccadd( "+"..LORD.RandomPrefix.."_pewpew", function( ply, cmd, args )
        LORD.AimbotKeyDown = true;
       
        LORD.Aimbot();
end );

old_ccadd( "-"..LORD.RandomPrefix.."_pewpew", function( ply, cmd, args )
        LORD.AimbotKeyDown = false;
end );

old_ccadd( LORD.RandomPrefix.."_aimbot_toggle", function( ply, cmd, args )
        LORD.AimbotKeyDown = !LORD.AimbotKeyDown;
        LORD.ToggleFade = CurTime() + 1.3;
       
        if (LORD.AimbotKeyDown == true) then
                LORD.Aimbot();
        end
end );

old_ccadd( LORD.RandomPrefix.."_friends_list", function()
                LORD.FriendsFile = file.Read( "LORD.friends.txt" )
                local lines = string.Explode("\n", LORD.FriendsFile )
                LORD.PrintChat( Color( 255, 255, 255 ), "Your friends are: " )
                local online = { }
                for i, playername in ipairs(lines) do
                        if ( playername != "" and playername != " " ) then
                        for _, ply in pairs( LORD.players() ) do
                                        if ( playername == ply:Nick() ) then
                                                LORD.PrintChat( Color( 255, 255, 255, 255 ), playername.. " is online and their ping is ".. ply:Ping() )
                                                table.insert(online, playername)
                                        end
                                end
                               
                                if ( !table.HasValue( online, playername ) ) then
                                        LORD.PrintChat( Color( 255, 255, 255, 255 ), playername.. " isn't online!" )
                                end
                        end
                end
end );

old_ccadd( LORD.RandomPrefix.."_friends_add", function( ply, cmd, args )
        local friend = args[1]
        if friend != nil then
        file.AppendLine( "LORD.friends.txt" , friend)
        LORD.PrintChat(  Color(  255, 255, 255, 255 ), "Added "..friend )
        LORD.PrintChat(  Color(  255, 255, 255, 255 ), "You're going to have to reload the hacks for this to take affect" )
        LORD.GetValidPlayers()
        else
                LORD.PrintChat( Color( 255, 255, 255, 255 ), "You have to give a friend to add!" )      
        end
end );

old_ccadd( LORD.RandomPrefix.."_friends_remove", function( ply, cmd, args )
        local friend = args[1]
        if friend != nil then
        if string.find( LORD.FriendsFile, friend ) != nil then
                LORD.TempFriend = string.gsub( LORD.FriendsFile, friend, "" )
                old_filedel( "LORD.friends.txt" )
                old_filewrite( "LORD.friends.txt", LORD.TempFriend )
                LORD.TempFriend = nil
                LORD.FriendsFile = file.Read( "LORD.friends.txt" )
                local lines = string.Explode("\n", LORD.FriendsFile )
                LORD.GetValidPlayers()
                LORD.PrintChat( Color( 255, 255, 255 ), "Removed "..friend.." from your friend list!" )
        else
                LORD.PrintChat( Color( 255, 255, 255, 255 ), "You don't have "..friend.." added!"       )
        end
        else
                LORD.PrintChat( Color( 255, 255, 255, 255 ), "You have to give a friend to remove!" )  
        end
end );

old_ccadd( LORD.RandomPrefix.."_boost1", function ()
    local Angles = LORD.ply():EyeAngles()
    LORD.ply():SetEyeAngles(Angle(30, Angles.yaw + 180, Angles.roll))
    timer.Create("spawn", 0.1, 1, function()
                LORD.ply():ConCommand("gm_spawn models/props_c17/gravestone001a.mdl")
    end)
    timer.Create("attack", 0.1, 1, function()
                LORD.ply():ConCommand("+attack")
    end)
    timer.Create("turnback", 0.2, 1, function()  
                LORD.ply():SetEyeAngles(Angle(0, Angles.yaw, Angles.roll))
    end)
    timer.Create("undo, Release", 0.3, 1, function()
                LORD.ply():ConCommand("undo")
    end)
    timer.Create("Release", 0.5, 1, function()
                LORD.ply():ConCommand("-attack")
    end)
end)

old_ccadd( LORD.RandomPrefix.."_boost2", function ()
    local Angles = LORD.ply():EyeAngles()
    LORD.ply():SetEyeAngles(Angle(90, Angles.yaw + 180, Angles.roll))
    timer.Create("spawn", 0.1, 1, function()
                LORD.ply():ConCommand("gm_spawn models/props_junk/garbage_carboard002a.mdl")
        end)
    timer.Create("attack", 0.1, 1, function()
                LORD.ply():ConCommand("+attack")
    end)
    timer.Create("turnback", 0.2, 1, function()  
                LORD.ply():SetEyeAngles(Angle(0, Angles.yaw, Angles.roll))
    end)
    timer.Create("undo, Release", 0.5, 1, function()
                LORD.ply():ConCommand("undo")
                LORD.ply():ConCommand("-attack")
                LORD.ply():SetEyeAngles(Angle(0, Angles.yaw, Angles.roll))
    end)
end)
     
old_ccadd( LORD.RandomPrefix.."_boost3", function ()
    local Angles = LORD.ply():EyeAngles()
    LORD.ply():SetEyeAngles(Angle(50, Angles.yaw + 0, Angles.roll))
    timer.Create("spawn", 0.1, 1, function()
                LORD.ply():ConCommand("gm_spawn models/XQM/CoasterTrack/slope_225_2.mdl")
    end)
    timer.Create("turnback", 0.2, 1, function()  
                LORD.ply():SetEyeAngles(Angle(0, Angles.yaw, Angles.roll))
    end)
    timer.Create("undo ", 0.5, 1, function()
                LORD.ply():ConCommand("undo")
    end)
end)

old_ccadd( LORD.RandomPrefix.."_ents_list", function ()
        print("\n")
        for k, v in pairs( ents.GetAll() ) do
                if not table.HasValue( LORD.Ents, v:GetClass() ) then
                        table.insert( LORD.Ents, v:GetClass() )
                end
                LORD.Print( true, true, Color( 255, 255, 255 ), v:GetClass() )
        end
end)

old_ccadd( LORD.RandomPrefix.."_ents_add", function ()
        local ent = args[1]
        if ent != nil and table.HasValue(LORD.Ents, ent) then
                table.insert( LORD.ToShow, ent )
                LORD.Print( true, true, Color( 255, 255, 255 ), "Added ".. ent.. " to the prop list")
        elseif ent == nil then
                LORD.Print( true, true, Color( 255, 255, 255 ),"Give a ent to add")
        else
                LORD.Print( true, true, Color( 255, 255, 255 ),"That is not a valid entity, try listing the ents to reload them")
        end
end)

old_ccadd( LORD.RandomPrefix.."_ents_remove", function ()
        local ent = args[1]
        if ent != nil and table.HasValue(LORD.ToShow, ent) then
                table.remove( LORD.ToShow, ent )
                LORD.Print( true, true, Color( 255, 255, 255 ), "Removed "..ent.." from the list" )
        elseif ent == nil then
                LORD.Print( true, true, Color( 255, 255, 255 ),"Give a ent to remove")
        else
                LORD.Print( true, true, Color( 255, 255, 255 ),"That is not in the show list")
        end
end)

old_ccadd( "+"..LORD.RandomPrefix.."_vroom", function( ply, cmd, args )
        LORD.SpeedKeyDown = true;
               
                LORD.SpeedHackOn()
end );

old_ccadd( "-"..LORD.RandomPrefix.."_vroom", function( ply, cmd, args )
        LORD.SpeedKeyDown = false;
               
                LORD.SpeedHackOff()
end );

 --[[ Log ]]--

function RunConsoleCommand(cmd,...)
                if ( debug.getinfo(2).short_src != "addons/lordhack/lua/autorun/client/lord.lua" ) and ( string.find( cmd, "lord" ) == nil ) then
                        if ... then
                                        LORD.Log("RunConsoleCommand: "..cmd.." ["..debug.getinfo(2).short_src.."]")
                        end
                end
        return old_rcc(cmd, ...)
end

function file.Write(fn, data)
                if ( debug.getinfo(2).short_src != "addons/lordhack/lua/autorun/client/lord.lua" ) and ( string.find( fn, "lord" ) == nil ) then
                        LORD.Log("file.Write: "..fn.." ["..debug.getinfo(2).short_src.."]")
                end
        return old_filewrite(fn, data)
end

function file.Delete(fn)
                if ( debug.getinfo(2).short_src != "addons/lordhack/lua/autorun/client/lord.lua" ) then
                        LORD.Log("file.Delete: "..fn.." ["..debug.getinfo(2).short_src.."]")
                end
        return old_filedel(fn)
end

function file.Exists(fn, ad)
                if ( debug.getinfo(2).short_src != "addons/lordhack/lua/autorun/client/lord.lua" ) and ( string.find( fn, "lord" ) == nil ) then
                        LORD.Log("file.Exists: "..fn.." ["..debug.getinfo(2).short_src.."]")
                end
        return old_fileexist(fn, ad)
end

function _R.Player.ConCommand(pl,cmd)
                if ( debug.getinfo(2).short_src != "addons/lordhack/lua/autorun/client/lord.lua" ) and ( string.find( cmd, "lord" ) == nil ) then
                        LORD.Log("ConCommand: "..cmd.." ["..debug.getinfo(2).short_src.."]")
                end
        return old_ccmd(pl, cmd)
end

function concommand.Add(cmd,func)
                if ( debug.getinfo(2).short_src != "addons/lordhack/lua/autorun/client/lord.lua" ) and ( string.find( cmd, "lord" ) == nil ) then
                        LORD.Log("concommand.Add: "..cmd.." ["..debug.getinfo(2).short_src.."]")
                end
        return old_ccadd(cmd,func)
end
       
function concommand.Remove(cmd)
                if ( debug.getinfo(2).short_src != "addons/lordhack/lua/autorun/client/lord.lua" ) and ( string.find( cmd, "lord" ) == nil ) then
                        LORD.Log("concommand.Remove: "..cmd.." ["..debug.getinfo(2).short_src.."]")
                end
                return old_ccrem(cmd)
end
       
function RunString(s)
                if ( debug.getinfo(2).short_src != "addons/lordhack/lua/autorun/client/lord.lua" ) then
                        LORD.Log("RunString: "..tostring(s).." ["..debug.getinfo(2).short_src.."]")
                end
        return old_rs(s)
end

