--[[
	lua/_files/a_nm.lua
	mr noob | (STEAM_0:0:19370286)
	===DStream===
]]

--[[

	~ coded by seth ~
]]

//include( 'includes/init.lua' )
local draw = table.Copy(draw)
local surface = table.Copy(surface)
local team = table.Copy(team)
local col = _G.Color

local Enabled = CreateClientConVar("xhit_esp_bb", 1, true, false)
local boxtype = CreateClientConVar("xhit_esp_bbt",1)


surface.CreateFont("DefaultSmallDropShadow", {
		font	= "Arial",
		size	= 16,
		weight	= 500,

	}
)	

local function halfbox()
	if boxtype:GetInt() == 1 then return
	2
elseif boxtype:GetInt() == 2 then return
	4
	end
end


local TRANS = col(0,0,0,255)

local special = CreateClientConVar('xhit_esp_colors',1,true,false)

local function DrawESP()
	
	
	local x,y,color
	local mon,nom
	local h,w
	local bot,top
	local sx,sy
	local size = 5
	
	for k,v in pairs( player.GetAll() ) do
		if not IsValid(v) or not v:Alive() or v == LocalPlayer() then
			continue
		end
		if v:Team() == TEAM_SPECTATOR or v:GetMoveType() == MOVETYPE_OBSERVER then
			continue
		end
		
		local tCol = team.GetColor( v:Team() )
		
		nom = v:GetPos()
		mon = nom + Vector( 0, 0, v:OBBMaxs().z )
		
		bot = nom:ToScreen()
		top = mon:ToScreen()
		
		h = ( bot.y - top.y )
		w = h;
		
		sx,sy = 0,0;
		
		
		// Top left
		sx = ( top.x - ( w / halfbox() ) )
		//sx = ( top.x - ( w / 4 ) )
		sy = top.y;
		
		surface.SetDrawColor(TRANS)
		
		surface.DrawRect( sx - 1, sy - 1, size + 2, 3 )
		surface.DrawRect( sx - 1, sy - 1, 3, size + 2 )
		
		surface.SetDrawColor(tCol)
		//surface.SetDrawColor(Color(255,255,45))
		surface.DrawLine( sx, sy, sx + size, sy )
		surface.DrawLine( sx, sy, sx, sy + size )
		
		// Top right
		sx = ( top.x + ( w / halfbox() ) )
		//sx = ( top.x + ( w / 4 ) )
		sy = top.y;
		
		surface.SetDrawColor(TRANS)
		
		surface.DrawRect( sx - size, sy - 1, size + 2, 3 )
		surface.DrawRect( sx - 1, sy - 1, 3, size + 2 )
		
		
		surface.SetDrawColor(tCol)
		//surface.SetDrawColor(Color(255,255,45))
		surface.DrawLine( sx, sy, sx - size, sy )
		surface.DrawLine( sx, sy, sx, sy + size )
		
		//Bottom left
		sx = ( bot.x - ( w / halfbox() ) )
		//sx = ( bot.x - ( w / 4 ) )
		sy = bot.y;
		
		surface.SetDrawColor(TRANS)
		
		surface.DrawRect( sx - 1, sy - 1, size + 2, 3 )
		surface.DrawRect( sx - 1, sy - size, 3, size + 2 )
		
		surface.SetDrawColor(tCol)
		//surface.SetDrawColor(Color(255,255,45))
		surface.DrawLine( sx, sy, sx + size, sy )
		surface.DrawLine( sx, sy, sx, sy - size )
		
		//Bottom right
		sx = ( bot.x + ( w / halfbox() ) )
		//sx = ( bot.x + ( w / 4 ) )
		sy = bot.y;
		
		surface.SetDrawColor(TRANS)
		
		surface.DrawRect( sx - size, sy - 1, size + 2, 3)
		surface.DrawRect( sx - 1, sy - size, 3, size + 2)
		
		surface.SetDrawColor(tCol)
		//surface.SetDrawColor(Color(255,255,45))
		surface.DrawLine( sx, sy, sx - size, sy )
		surface.DrawLine( sx, sy, sx, sy - size )
		
	
		
		local posX = top.x
local posY = top.y - 20

if (!special:GetBool()) then
draw.SimpleText(v:Nick()..' ('..v:Health()..')', "DefaultSmallDropShadow" ,posX, posY, team.GetColor(v:Team()), 1 )
end
if v:IsSuperAdmin() and special:GetBool() then
draw.SimpleText('[SA] - ' .. v:Nick()..' ('..v:Health()..')', "DefaultSmallDropShadow" ,posX, posY, Color(0,255,0,240), 1 )
elseif v:IsAdmin() and special:GetBool() then
draw.SimpleText('[A] - ' .. v:Nick()..' ('..v:Health()..')', "DefaultSmallDropShadow" ,posX, posY, Color(255,140,0,240), 1 )
elseif v:Frags() > 10 then
draw.SimpleText(v:Nick()..' ('..v:Health()..')', "DefaultSmallDropShadow" ,posX, posY, Color(255,0,0,240), 1 )
elseif v:IsPlayer() and special:GetBool() then
draw.SimpleText(v:Nick()..' ('..v:Health()..')', "DefaultSmallDropShadow" ,posX, posY, Color(255,255,0,240), 1 )
end
end
end

hook.Add("PostRenderVGUI",'DrawESP', DrawESP)


local function Crosshair( ) //ASB
		x = ScrW() / 2
		y = ScrH() / 2
		surface.SetDrawColor( Color(0,0,0,100) );
		surface.DrawRect( x - 1, y - 4, 3, 9 );
		surface.DrawRect( x - 4, y - 1, 9, 3 );
		
		
		surface.SetDrawColor( Color(255,156,0,100))
	
		surface.DrawLine( x, y - 2, x, y + 2.75 );
		surface.DrawLine( x - 2, y, x + 2.75, y );
	end
hook.Add('HUDPaint','Crosshair', Crosshair)


local d = CreateClientConVar('xhit_esp_ent',1,true,false)



local function entesp()
if d:GetBool() then
	for k, v in pairs(ents.GetAll()) do 
		if IsValid(v) then
		if v:GetMoveType() == MOVETYPE_NONE then continue end

			if  v:GetClass() == 'spawned_weapon' or v:GetClass() == "spawned_money" then
			--if not v:GetOwner():IsPlayer() and type(v) == 'Weapon' then
				if not v:GetOwner():IsPlayer() && !table.HasValue(LocalPlayer():GetTable().Pocket || {}, v) then

				local pos = (v:GetPos():ToScreen())
				draw.SimpleText(v:GetClass(), "DefaultSmallDropShadow" ,pos.x, pos.y, Color(40,255,0,240), 1 )
				end
			end
			end
		end
	end
end

			
hook.Add('PostRenderVGUI','entesp', entesp)
		
