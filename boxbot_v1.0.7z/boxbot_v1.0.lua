	

     // ____            ____        _    __      __  __
     //|  _ \          |  _ \      | |   \ \    / / /_ |
     //| |_) | _____  _| |_) | ___ | |_   \ \  / /   | |
     //|  _ < / _ \ \/ /  _ < / _ \| __|   \ \/ /    | |
     //| |_) | (_) >  <| |_) | (_) | |_     \  /     | |
     //|____/ \___/_/\_\____/ \___/ \__|     \/      |_|
     //                                                
                                                     
     
     
     
     
    -- Made by Boxedin123 with help from reference material from Nautical and math For the crosshair placement from snowizgr8 and the bones table from ReichBot v3(Couldent find author) And various other references.
    --Link747 for beta testing <3
     
    -- Convars
     
    local crossHair                 = CreateClientConVar( "BoxBot_Crosshair",               0,true,false )
    local triggerBot                = CreateClientConVar( "BoxBot_Trigger",                 0,true,false )
    local noRecoil                  = CreateClientConVar( "BoxBot_Norecoil",                0,true,false )
    local esp                               = CreateClientConVar( "BoxBot_ESP",                             0,true,false )
    local entEsp                    = CreateClientConVar( "BoxBot_EntESP",                  0,true,false )
    local boneEsp                   = CreateClientConVar( "BoxBot_BoneEsp",                 0,true,false )
    local noRecoilOffset    = CreateClientConVar( "BoxBot_NorecoilOffset",  0,true,false )
    local aimbot                    = CreateClientConVar( "BoxBot_Aimbot",                  0,true,false )
    local speedOffset               = CreateClientConVar( "BoxBot_SpeedOffset",             0,true,false )
    local boundingBoxes     = CreateClientConVar( "BoxBot_BoundingBoxes",   0,true,false )
    local ignoreSteam               = CreateClientConVar( "BoxBot_IgnoreSteam",             0,true,false )
    local espDist                   = CreateClientConVar( "BoxBot_EspDist",                 0,true,false )
    local aimChest                  = CreateClientConVar( "BoxBot_AimChest",                0,true,false )
     
     
     
    local playerBones = {
     
            { S = "ValveBiped.Bip01_Head1", E = "ValveBiped.Bip01_Neck1" },
            { S = "ValveBiped.Bip01_Neck1", E = "ValveBiped.Bip01_Spine4" },
            { S = "ValveBiped.Bip01_Spine4", E = "ValveBiped.Bip01_Spine2" },
            { S = "ValveBiped.Bip01_Spine2", E = "ValveBiped.Bip01_Spine1" },
            { S = "ValveBiped.Bip01_Spine1", E = "ValveBiped.Bip01_Spine" },
            { S = "ValveBiped.Bip01_Spine", E = "ValveBiped.Bip01_Pelvis" },
     
            { S = "ValveBiped.Bip01_Spine2", E = "ValveBiped.Bip01_L_UpperArm" },
            { S = "ValveBiped.Bip01_L_UpperArm", E = "ValveBiped.Bip01_L_Forearm" },
            { S = "ValveBiped.Bip01_L_Forearm", E = "ValveBiped.Bip01_L_Hand" },
     
            { S = "ValveBiped.Bip01_Spine2", E = "ValveBiped.Bip01_R_UpperArm" },
            { S = "ValveBiped.Bip01_R_UpperArm", E = "ValveBiped.Bip01_R_Forearm" },
            { S = "ValveBiped.Bip01_R_Forearm", E = "ValveBiped.Bip01_R_Hand" },
     
            { S = "ValveBiped.Bip01_Pelvis", E = "ValveBiped.Bip01_L_Thigh" },
            { S = "ValveBiped.Bip01_L_Thigh", E = "ValveBiped.Bip01_L_Calf" },
            { S = "ValveBiped.Bip01_L_Calf", E = "ValveBiped.Bip01_L_Foot" },
            { S = "ValveBiped.Bip01_L_Foot", E = "ValveBiped.Bip01_L_Toe0" },
           
            { S = "ValveBiped.Bip01_Pelvis", E = "ValveBiped.Bip01_R_Thigh" },
            { S = "ValveBiped.Bip01_R_Thigh", E = "ValveBiped.Bip01_R_Calf" },
            { S = "ValveBiped.Bip01_R_Calf", E = "ValveBiped.Bip01_R_Foot" },
            { S = "ValveBiped.Bip01_R_Foot", E = "ValveBiped.Bip01_R_Toe0" },
    }
     
    local entClasses = { "spawned_shipment","money_printer","spawned_money","spawned_money" } // add classes here
     
     
     
    -- TriggerBot
     
    local function BoxBotTrigger( ucmd )
     
            if triggerBot:GetInt() >= 1 and shouldAim == 1 then
            if shouldAim == 0 then return end
     
                    local eyeTrace = LocalPlayer():GetEyeTrace().Entity
                   
                    if ( eyeTrace:IsPlayer() ) then
                   
                            if ( didShoot ) then
                           
                                    RunConsoleCommand( "-Attack" )
                                    didShoot = false
     
                            else
           
                                    RunConsoleCommand( "+Attack" )
                                    didShoot = true
                            end
       
                    elseif ( DidShoot ) then
           
                            RunConsoleCommand( "-Attack" )
                            didShoot = false
                    end
     
            elseif ( didShoot ) then
           
                    RunConsoleCommand( "-Attack" )
                    didShoot = false
                   
            end
    end
    -- Aimbot
     
     
     
     
    local function distance( x1,y1,x2,y2 ) // function to return 2D distance, look up distance formula for graphs if you dont understand this
           
            local xsq = ( x2 - x1 )
           
            xsq = xsq * xsq
           
            local ysq = ( y2 - y1 )
           
            ysq = ysq * ysq
     
            return math.sqrt( xsq + ysq )
    end
     
    local function closestTarget()
     
            local best = { 0,nil }
     
            for k,v in ipairs( player.GetAll() ) do
                    if ( v:IsPlayer() and v:GetFriendStatus() == "friend" and ignoreSteam:GetInt() >= 1 and !v:InVehicle() )  then continue end
                    if (v:Team() == TEAM_SPECTATOR) then continue end
                    if ( v == LocalPlayer() ) then continue end
                    if ( !v:Alive() ) then continue end
    -- Chest Bone Vars.
                    local findChestBone                     = v:LookupBone("ValveBiped.Bip01_Spine4")
                    local chestBoneReturn           = v:GetBonePosition( findChestBone ).Pos
    --Actuall Trace
                   
                    local traceArray = {}
                    traceArray.mask = MASK_SHOT
                    traceArray.start = LocalPlayer():GetShootPos()
                    traceArray.endpos = v:GetShootPos()
                    traceArray.filter = { LocalPlayer(), v }
    --Checking If Its Set To Aim At Chest
                            if aimChest:GetInt() >=1 then
                                    traceArray.endpos = chestBoneReturn else
                                    chestBoneReturn   = chestBoneReturn
                            end
                           
                    local trace = util.TraceLine( traceArray )
     
                    if ( trace.Hit ) then continue end
                   
                    local pos = v:GetPos():ToScreen()
                   
                    local targDistance = distance( ScrW() / 2,ScrH() / 2,pos.x,pos.y )
           
                    if ( targDistance < best[ 1 ] or best[ 2 ] == nil ) then // if the distance from the center of the screen to the screen pos of the target is less than whats stored then, or if best[ 2 ] is nil, meaning this is our first loop then..
                   
                   
                            best = { targDistance,v }
                    end
            end
     
            return best[ 2 ]
    end    
     
    local function BoxBotAim( ucmd )
     
            if ( aimbot:GetInt() >= 1 or shouldAim == 1 ) then
     
           
                            local target = closestTarget()
           
                            if ( target == nil ) then return end
    --Aim At Head
                            local attachment = target:LookupAttachment( "eyes" )
                                   
     
           
                                    local headAttachment            = ( target:GetAttachment( attachment ) )
                                    local headAimVector             = ( headAttachment.Pos - LocalPlayer():GetShootPos() ):Angle()
                                            headAimVector.y = math.NormalizeAngle( headAimVector.y )
                                            headAimVector.p = math.NormalizeAngle( headAimVector.p )
                                           
    --Aim At Chest
                                    local chestBone                 = target:LookupBone("ValveBiped.Bip01_Spine4")
                                    local chestBoneReturn   = target:GetBonePosition( chestBone )
                                    local chestAimVector    = ( chestBoneReturn - LocalPlayer():GetShootPos()):Angle()
                                            chestAimVector.y = math.NormalizeAngle( chestAimVector.y )
                                            chestAimVector.p = math.NormalizeAngle( chestAimVector.p )
    --Actuall Aim Code
                                    if aimChest:GetInt() >=1 then
                                            ucmd:SetViewAngles(chestAimVector) else
                                                    ucmd:SetViewAngles(headAimVector)
     
                                    end
                            end
                    end
     
     
    -- No Recoil
     
    local function noRecoilThink()
           
            if ( noRecoil:GetInt() >= 1 ) then
           
                    if ( LocalPlayer():GetActiveWeapon().Primary ) then
                   
                            LocalPlayer():GetActiveWeapon().Primary.Recoil = noRecoilOffset:GetInt()
                    end
             end
    end
     
    -- Esp
     
    local function boxBotEsp()
     
            if ( esp:GetInt() >= 1 ) then
     
     
           
                    for _,v in ipairs( player.GetAll() ) do
                            if(v:GetPos():Distance(LocalPlayer():GetPos()) < (espDist:GetInt()))then
                                    if ( v:Alive() ) and (v:Team() != TEAM_SPECTATOR) then
                   
                            -- Information
                           
                            if ( v == LocalPlayer() ) then continue end
                                   
                            local pos = v:GetPos()
                            local offset01 = ( pos + Vector( 0,0,85 ) ):ToScreen()
                            local offset02 = ( pos - Vector( 0,0,10 ) ):ToScreen()
                           
                   
                            local colorOfEsp = team.GetColor( v:Team() )
                           
                            draw.SimpleText( v:Nick() , "BudgetLabel", offset01.x , offset01.y, colorOfEsp , TEXT_ALIGN_CENTER,TEXT_ALIGN_CENTER )
                           
                            local hp = "*DEAD*"
                           
                            if ( v:Alive() ) then
                           
                                    hp = "Health: " .. v:Health()
                            end
                           
                            local plyPos2 = ( v:GetPos() - Vector( 0,0,10 ) ):ToScreen()
                   
                            draw.SimpleText(  hp, "BudgetLabel", offset02.x , offset02.y, colorOfEsp , TEXT_ALIGN_CENTER,TEXT_ALIGN_CENTER )
                           
                            -- Boxes
                           
                            surface.SetDrawColor( colorOfEsp )
                           
                            if ( boundingBoxes:GetInt() >= 1 ) then
                           
                                    local height = math.abs( offset01.y - offset02.y ) - 12
                                   
                                    surface.DrawOutlinedRect( offset01.x - ( height / 2 ),offset01.y + 6,height,height )
                            end
                           
                            -- Skeleton
                           
                            if ( boneEsp:GetInt() >= 1 ) then
                           
                                    for a,b in pairs( playerBones ) do
                                           
                                            local start = v:LookupBone( b.S )
                                           
                                            if ( start == nil ) then continue end
                                           
                                            local endPos = v:LookupBone( b.E )
                                           
                                            if ( endPos == nil ) then continue end
                                           
                                            local startScreenPos = v:GetBonePosition( start ):ToScreen()
                                            local endScreenPos = v:GetBonePosition( endPos ):ToScreen()
                                           
                                            surface.DrawLine( startScreenPos.x,startScreenPos.y,endScreenPos.x,endScreenPos.y )
                                   
                                    end
                           
                            end
                           
                    end
     
                    -- Entity Esp
                   
                    if ( entEsp:GetInt() >= 1 ) then
                   
                            for _,v in ipairs( ents.GetAll() ) do
                           
                                    local class = string.lower( v:GetClass() )
                           
                                    if ( !table.HasValue( entClasses,class ) ) then continue end
                                   
                                    local entPos = v:LocalToWorld( v:OBBCenter() ):ToScreen() // get center of model and convert to screen coordinates
                                   
                                    draw.SimpleText( class,"BudgetLabel",entPos.x,entPos.y,Color( 120,120,200,255 ) ,TEXT_ALIGN_CENTER,TEXT_ALIGN_CENTER )
                            end
                    end
            end
    end
    end
            if ( crossHair:GetInt() >= 1 ) then
           
                    local Strobe = math.random (0,255)
           
                    surface.SetDrawColor( Strobe,0,Strobe )
                    surface.DrawLine( ScrW() / 2 - 10, ScrH() / 2, ScrW() / 2 + 11 , ScrH() / 2 )
                    surface.DrawLine( ScrW() / 2 - 0, ScrH() / 2 - 10, ScrW() / 2 - 0 , ScrH() / 2 + 11 )
            end
    end
     

     
    --BoxBotInDevMenu 100% boxedin
    local function boxBotVgui()
    --DFRAME
            local Frame = vgui.Create( "DFrame" )
            Frame:SetPos( 50, 50 )
            Frame:SetSize( 500, 400 )
            Frame:SetTitle( "BoxBot Box Edition: Coded By Boxedin123 / LOTS Of Help From Nautical.")
            Frame:SetVisible( true )
            Frame:SetDraggable( true )
            Frame:ShowCloseButton( true )
            Frame:MakePopup()
           
    --TABS/DROPDOWN
           
    local PropertySheet = vgui.Create( "DPropertySheet" )
    PropertySheet:SetParent( Frame )
    PropertySheet:SetPos( 5, 30 )
    PropertySheet:SetSize( 490, 350 )
     
     local CollapsibleCategory = vgui.Create("DCollapsibleCategory", PropertySheet)
    CollapsibleCategory:SetPos( 25,50 )
    CollapsibleCategory:SetSize( 200, 50 )
    CollapsibleCategory:SetExpanded( 1 )
    CollapsibleCategory:SetLabel( "ESP Options" )
     
    local CollapsibleCategory2 = vgui.Create("DCollapsibleCategory", PropertySheet)
    CollapsibleCategory2:SetPos( 25,50 )
    CollapsibleCategory2:SetSize( 200, 50 )
    CollapsibleCategory2:SetExpanded( 1 )
    CollapsibleCategory2:SetLabel( "Aimbot Options" )
     
    local CollapsibleCategory3 = vgui.Create("DCollapsibleCategory", PropertySheet)
    CollapsibleCategory3:SetPos( 25,50 )
    CollapsibleCategory3:SetSize( 200, 50 )
    CollapsibleCategory3:SetExpanded( 1 )
    CollapsibleCategory3:SetLabel( "Offsets" )
     
    local CollapsibleCategory4 = vgui.Create("DCollapsibleCategory", PropertySheet)
    CollapsibleCategory4:SetPos( 25,50 )
    CollapsibleCategory4:SetSize( 200, 50 )
    CollapsibleCategory4:SetExpanded( 1 )
    CollapsibleCategory4:SetLabel( "Misc." )
     --PROPERTYSHEETS
    PropertySheet:AddSheet( "ESP", CollapsibleCategory, "gui/silkicons/user", false, false, "ESP" )
    PropertySheet:AddSheet( "Aimbot", CollapsibleCategory2, "gui/silkicons/group", false, false, "Aimbot" )
    PropertySheet:AddSheet( "Offsets", CollapsibleCategory3, "gui/silkicons/group", false, false, "Offsets" )
    PropertySheet:AddSheet( "Misc.", CollapsibleCategory4, "gui/silkicons/group", false, false, "Misc." )
    --LISTS
    CategoryList = vgui.Create( "DPanelList" )
    CategoryList:SetAutoSize( true )
    CategoryList:SetSpacing( 5 )
    CategoryList:EnableHorizontal( false )
    CategoryList:EnableVerticalScrollbar( true )
     
    CategoryList2 = vgui.Create( "DPanelList" )
    CategoryList2:SetAutoSize( true )
    CategoryList2:SetSpacing( 5 )
    CategoryList2:EnableHorizontal( false )
    CategoryList2:EnableVerticalScrollbar( true )
     
    CategoryList3 = vgui.Create( "DPanelList" )
    CategoryList3:SetAutoSize( true )
    CategoryList3:SetSpacing( 5 )
    CategoryList3:EnableHorizontal( false )
    CategoryList3:EnableVerticalScrollbar( true )
     
    CategoryList4 = vgui.Create( "DPanelList" )
    CategoryList4:SetAutoSize( true )
    CategoryList4:SetSpacing( 5 )
    CategoryList4:EnableHorizontal( false )
    CategoryList4:EnableVerticalScrollbar( true )
     
    CategoryList5 = vgui.Create( "DPanelList" )
    CategoryList5:SetAutoSize( true )
    CategoryList5:SetSpacing( 5 )
    CategoryList5:EnableHorizontal( false )
    CategoryList5:EnableVerticalScrollbar( true )
     
     
     --SETCONTENTS
     
     
    CollapsibleCategory:SetContents( CategoryList )
    CollapsibleCategory2:SetContents( CategoryList2 )
    CollapsibleCategory3:SetContents( CategoryList3 )
    CollapsibleCategory4:SetContents( CategoryList4 )
     
    --CHECKBOXES
        local Crosshair = vgui.Create( "DCheckBoxLabel" )
        Crosshair:SetText( "Crosshair" )
        Crosshair:SetConVar( "BoxBot_Crosshair" )
        Crosshair:SetValue( crossHair:GetInt() )
        Crosshair:SizeToContents()
            CategoryList4:AddItem( Crosshair )
           
        local TriggerBotBox = vgui.Create( "DCheckBoxLabel" )
        TriggerBotBox:SetText( "Trigger Bot" )
            TriggerBotBox:SetParent( Frame )
            TriggerBotBox:SetPos( 70,70 )
        TriggerBotBox:SetConVar( "BoxBot_Trigger" )
        TriggerBotBox:SetValue( triggerBot:GetInt() )
        TriggerBotBox:SizeToContents()
            CategoryList2:AddItem( TriggerBotBox )    
           
            local AimChestBox = vgui.Create( "DCheckBoxLabel" )
        AimChestBox:SetText( "Aim At Chest" )
            AimChestBox:SetParent( Frame )
            AimChestBox:SetPos( 70,70 )
        AimChestBox:SetConVar( "BoxBot_AimChest" )
        AimChestBox:SetValue( aimChest:GetInt() )
        AimChestBox:SizeToContents()
            CategoryList2:AddItem( AimChestBox )
           
        local NoRecoilBox = vgui.Create( "DCheckBoxLabel" )
        NoRecoilBox:SetText( "No Recoil" )
            NoRecoilBox:SetParent( Frame )
            NoRecoilBox:SetPos( 70,90 )
        NoRecoilBox:SetConVar( "BoxBot_Norecoil" )
        NoRecoilBox:SetValue( noRecoil:GetInt() )
        NoRecoilBox:SizeToContents()
            CategoryList2:AddItem( NoRecoilBox )
     
        local ESPBox = vgui.Create( "DCheckBoxLabel" )
        ESPBox:SetText( "ESP" )
            ESPBox:SetParent( Frame )
            ESPBox:SetPos( 70,130 )
        ESPBox:SetConVar( "BoxBot_ESP" )
        ESPBox:SetValue( esp:GetInt() )
            ESPBox:SizeToContents()
            CategoryList:AddItem( ESPBox )
           
        local ESPBoneBox = vgui.Create( "DCheckBoxLabel" )
        ESPBoneBox:SetText( "Bone Esp" )
            ESPBoneBox:SetParent( Frame )
            ESPBoneBox:SetPos( 70,150 )
        ESPBoneBox:SetConVar( "BoxBot_BoneESP" )
        ESPBoneBox:SetValue( boneEsp:GetInt() )
            ESPBoneBox:SizeToContents()    
            CategoryList:AddItem( ESPBoneBox )
     
           
                    local BoxBot_BoundingBoxes = vgui.Create( "DCheckBoxLabel" )
        BoxBot_BoundingBoxes:SetText( "Bounding Boxes" )
            BoxBot_BoundingBoxes:SetParent( Frame )
            BoxBot_BoundingBoxes:SetPos( 70,210 )
        BoxBot_BoundingBoxes:SetConVar( "BoxBot_BoundingBoxes")
        BoxBot_BoundingBoxes:SetValue( boundingBoxes:GetInt() )
            BoxBot_BoundingBoxes:SizeToContents()
            CategoryList:AddItem( BoxBot_BoundingBoxes )   
           
            local BoxBot_BoundingBoxes = vgui.Create( "DCheckBoxLabel" )
        BoxBot_BoundingBoxes:SetText( "Ignore Steam Friends" )
            BoxBot_BoundingBoxes:SetParent( Frame )
            BoxBot_BoundingBoxes:SetPos( 70,230 )
        BoxBot_BoundingBoxes:SetConVar( "BoxBot_IgnoreSteam")
        BoxBot_BoundingBoxes:SetValue( ignoreSteam:GetInt() )
            BoxBot_BoundingBoxes:SizeToContents()
            CategoryList2:AddItem( BoxBot_BoundingBoxes )  
           
            local BoxBot_EntESP = vgui.Create( "DCheckBoxLabel" )
        BoxBot_EntESP:SetText( "Entity ESP" )
            BoxBot_EntESP:SetParent( Frame )
            BoxBot_EntESP:SetPos( 70,250 )
        BoxBot_EntESP:SetConVar( "BoxBot_EntESP")
        BoxBot_EntESP:SetValue( entEsp:GetInt() )
            BoxBot_EntESP:SizeToContents()
            CategoryList:AddItem( BoxBot_EntESP )
           
    --SLIDERS
     
        local NoRecoilOffsetBox = vgui.Create( "DNumSlider" )
        NoRecoilOffsetBox:SetSize( 300, 50 )
            NoRecoilOffsetBox:SetParent( Frame )
            NoRecoilOffsetBox:SetPos( 70,270 )
        NoRecoilOffsetBox:SetText( "No Recoil Offset" )
        NoRecoilOffsetBox:SetMin( -50 )
        NoRecoilOffsetBox:SetMax( 50 )
        NoRecoilOffsetBox:SetDecimals( 0 )
        NoRecoilOffsetBox:SetConVar( "BoxBot_NorecoilOffset" )
            CategoryList3:AddItem( NoRecoilOffsetBox )
     
     
        local SpeedHackSlider = vgui.Create( "DNumSlider" )
        SpeedHackSlider:SetSize( 300, 100 )
        SpeedHackSlider:SetSize( 300, 100 )
            SpeedHackSlider:SetParent( Frame )
            SpeedHackSlider:SetPos( 70,340 )
        SpeedHackSlider:SetText( "Speedhack Speed" )
        SpeedHackSlider:SetMin( -20 )
        SpeedHackSlider:SetMax( 50 )
        SpeedHackSlider:SetDecimals( 0 )
        SpeedHackSlider:SetConVar( "BoxBot_SpeedOffset" )
            CategoryList3:AddItem( SpeedHackSlider )
           
        local espDistSlider = vgui.Create( "DNumSlider" )
        espDistSlider:SetSize( 300, 100 )
            espDistSlider:SetParent( Frame )
            espDistSlider:SetPos( 70,340 )
        espDistSlider:SetText( "ESP Distance" )
        espDistSlider:SetMin( 0 )
        espDistSlider:SetMax( 50000 )
        espDistSlider:SetDecimals( 0 )
        espDistSlider:SetConVar( "BoxBot_EspDist" )
            CategoryList:AddItem( espDistSlider )
     
    end
    concommand.Add("Jump",boxBotVgui )
     
    --- Hooks + Cmds
     
    hook.Add( "HUDPaint","BOXBOTESP",boxBotEsp )
     
    hook.Add( "Think","BOXBOTTHINK",function()
     
            noRecoilThink()
    end )
     
    hook.Add( "CreateMove","BOXBOTCREATEMOVE",function( ucmd )
     
            BoxBotTrigger( ucmd )
            BoxBotAim( ucmd )
           
    end )
     
     
     
    --Box Bot Speed
    concommand.Add("+BoxBot_Speed",function()
     
            RunConsoleCommand("host_framerate", speedOffset:GetString())
    end)
     
    concommand.Add("-BoxBot_Speed",function()
     
            RunConsoleCommand("host_framerate", "0")
    end)
     
    concommand.Add("+BoxBot_Aim",function()
     
            shouldAim = 1
    end)
     
    concommand.Add("-BoxBot_Aim",function()
     
            shouldAim = 0
    end)

