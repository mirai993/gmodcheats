if SERVER then return end

// Little piece of C+P from Hera because I'm lazy.
function AddCMD(Name,Function)
	K0N4T4Print("[ADDED] ConCommand: "..Name.."")
	return old_ccadd(Name,Function)
end

function AddConVar(convar,str,save,data)
	return CreateClientConVar("K4_"..convar,str,true,false), K0N4T4Print("[ADDED] ConVar: K4_"..convar.." ["..str.."]")
end

function K0N4T4Print(msg)
	print("[K0N4T4] "..msg)
end

local g = table.Copy(_G)

/*
Shortcuts, shortcuts everywhere
*/

local colors				= {}
red						= Color(255,0,0,255);
black						= Color(0,0,0,255);
green						= Color(0,255,0,255);
white						= Color(255,255,255,255);
blue						= Color(0,0,255,255);
cyan						= Color(0,255,255,255);
pink 						= Color(255,0,255,255);
blue						= Color(0,0,255,255);
grey						= Color(100,100,100,255);
gold						= Color(255,228,0,255);
lblue						= Color(155,205,248);
lgreen						= Color(174,255,0);
iceblue						= Color(116,187,251,255);
purple  					= Color(255,0,255,255);

function MakeCVar(convar, str, save, data)
	return CreateClientConVar(convar, str, true, false)
end


/***********************
ConVar's
***********************/
-- AIM BOT --
local dBotOn     = MakeCVar("K4_aimbot", "1", true, false)
local boneaim    = MakeCVar("K4_aimbot_bone", "ValveBiped.Bip01_Head1", true, false)
local K0N4T4     = MakeCVar("K4_aimbot_onshoot", "0", true, false)
local infov1     = MakeCVar("K4_aimbot_infov", 0, true, false)
local infov2     = MakeCVar("K4_aimbot_fov", 90, true, false)
local silentAim  = MakeCVar("K4_aimbot_silent", "0", true, false)

-- ESP / WALLHACK --
local espOn 	 = MakeCVar("K4_esp", "1", true, false)
local wallHackOn = MakeCVar("K4_wallhack", "0", true, false)
local wHackWire  = MakeCVar("K4_wallhack_wire", "0", true, false)
local EspDist    = MakeCVar("K4_ESP_Distance", "180", true, false)
local espBox  	 = MakeCVar("K4_ESP_Box", "1", true, false)
local espSkel    = MakeCVar("K4_ESP_Skeleton", "1", true, false)
local chamsMat   = MakeCVar("K4_ESP_Chams_Material","Solid", true, false)
local Glowing    = MakeCVar("K4_ESP_Glow", "0", true, false)
local Xray 		 = MakeCVar("K4_ESP_Xray", "0", true, false)
local Ents 		 = MakeCVar("K4_ESP_Ents", "1", true, false)
local tracers    = MakeCVar("K4_ESP_Tracer", "1", true, false)
local rpEnts     = MakeCVar("K4_ESP_RPEnts", "1", true, false)
local WireXray   = MakeCVar("K4_ESP_Xray_Wires", "1", true, false)

concommand.Add( "k4_help", function() 
	print([[
		Hello, user if this is your first time using K0N4T4 please enter the following command in console "find k4_"
		this will list all the commands included in this hack. (WARNING: If you are using the light version some commands may not work.)
		
		Bellow you can find discriptions for the commands you will be using the most.
		
		k4_esp 1|0 :: Toggle ESP (Player Info, and Visuals)
		k4_wallhack 1|0 :: Toggle the wallhack
		k4_wallhack_wire 1|0 :: Toggle wireframe mode for the wallhack
		k4_xray :: Toggle xray
		k4_esp_tracer 2|1|0 :: Toggle tracers ( 2 = Use the old tracers, 1 = Use the new tracers, 0 = Disable )
		
		k4_aimbot 1|0 :: Toggle the aimbot, we recommend binding this to a key (ie. BindToggle r "k4_aimbot")
	]])
end )

-- HANDY HELPERS --
local bhop       = MakeCVar("K4_bhop", "0", true, false) --Bunny hop toggle.
local menu       = MakeCVar("K4_menu", "0", true, false) --Menu [WIP].
local shspeed    = MakeCVar("K4_sh_speed", "6.0", true, false) --Speed offset.
local removerec  = MakeCVar("K4_remove_recoil", "0", true, false) --No recoil.
local logIds     = MakeCVar("K4_log_steamids", "1", true, false) --SteamID logs.
local TalkLogs   = MakeCVar("K4_saylogs", "0", true, false) --Say logs in chat.

-- MISC --
local rpGod      = MakeCVar("K4_RPGOD", "0", true, false)
local tHack 	 = MakeCVar("K4_Misc_TTTHack", "0", true, false)
local chatspam   = MakeCVar("K4_Misc_CSpam", "0", true, false) --Chat Spam Toggle
local spamMsg 	 = MakeCVar("K4_Misc_CSpam_Msg", "-seffhakked-") --Chat Spam Message
local crosshair  = MakeCVar("K4_MISC_CROSSHAIR", "1", true, false) --Misc Crosshair
local propspamen = MakeCVar("K4_Misc_PSpam", "0", true, false) --Spam toggle
local propsmodel = MakeCVar("K4_Misc_PSpam_Model", "models/props_junk/watermelon01.mdl") --What model to spam
local Changer    = MakeCVar("K4_Misc_NameChanger", "0", true, false) --Name changer, most servers are protected from this.
local Changer2   = MakeCVar("K4_Misc_JobChanger", "0", true, false) --Job changer.
local ShowAdmins = MakeCVar("K4_Misc_PrintAdmins", "1", true, false) --Show the admins





-- Locals, do not edit. --
local x 					= ScrW() / 2 --Crosshair
local y 					= ScrH() / 2 --Crosshair
local gap 					= 0 --Crosshair Gap
local length 				= 10 --Crosshair Length
local tblDB      			= {}
local g	         			= table.Copy(_G)
local K4         			= {}
local K4_Admins 			= {}
local Menu       			= {}
local K4_version 			= "1.9b"
local K4_dev				= ""
local phase     			= "Alpha"
local old_ccadd	 			= concommand.Add;
local old_hookadd			= hook.Add;
local old_hookrem 			= hook.Remove;
local plr       			= LocalPlayer()
local TEAM_SPECTATOR 		= 1002
local userauth 				= util.CRC(LocalPlayer():SteamID())
local FAuth 				= file.Read("K4Auth.txt")
local host       			= GetConVarString("ip")
K4laser						= {
"weapon_pocket",
"keys",
"pocket",
"weapon_toolgun",
"weapon_physgun",
"weapon_camera",
"camera",
"weapon_crowbar"
}


function K4:CreateMaterial()
local BaseInfo = {
["$basetexture"] = "models/debug/debugwhite",
["$model"]       = 1,
["$translucent"] = 1,
["$alpha"]       = 1,
["$nocull"]      = 1,
["$ignorez"]	 = 1
}	
local mat	
if GetConVarString("K4_ESP_Chams_Material") == "Solid" then
	mat = CreateMaterial( "K4_solid", "VertexLitGeneric", BaseInfo )
elseif GetConVarString("K4_ESP_Chams_Material") == "Wireframe" then
	mat = CreateMaterial( "K4_wire", "Wireframe", BaseInfo )
end
   return mat
end


--Addhook & Removehook
local function AddHook(Type,Function)
	Name = Type.." | "..math.random(1,1000),math.random(1,2000),math.random(1,3000) -- Simple hook names
	K0N4T4Print("[ADDED] Hook: ["..Type.."] | Name: "..Name.."")
	return old_hookadd(Type,Name,Function)
end

-- RemoveHook
local function RemoveHook(Type,Function)
	K0N4T4Print("[REMOVED] Hook: ["..Type.."]")
	return old_hookrem(Type,Function)
end



/**************************
Name: Derma shit
Purpose: Anything Derma
***************************/
function AddCheckBox( text, cvar, parent, x, y, tt )
local checkbox = vgui.Create( "DCheckBoxLabel", parent )
checkbox:SetPos( x, y )
checkbox:SetText( text )
checkbox:SetConVar( cvar )
checkbox:SetTextColor(white)
checkbox:SetTooltip( tt or "No Tool Tip" )
checkbox:SizeToContents()	
end

// AddSlider for the derma
function AddSlider( text, cvar, parent, min, max, decimals, x, y, wide, tt )
local slider = vgui.Create( "DNumSlider" )
slider:SetParent( parent )
slider:SetPos( x, y )
slider:SetWide( wide )
slider:SetText( text )
--slider:SetTextColor(BLACK)
slider:SetMin( min ) 
slider:SetMax( max ) 
slider:SetDecimals( decimals ) 
slider:SetConVar( cvar )
slider:SetTooltip( tt or "No Tool Tip" )
end

Gradient = surface.GetTextureID( "gui/gradient" )
function DrawBox( x, y, wide, tall, dropsize )
	draw.RoundedBoxEx( 4, x, y, wide, dropsize, iceblue, true, true, false, false )
	draw.RoundedBoxEx( 4, x, y + dropsize, wide, tall - dropsize, Color( 0, 0, 0, 100 ), false, false, true, true )
end


/******************************
Name: Get Admin Type
Purpose: Get Admin Type..
*******************************/
local function GetAdminType(e)
	if e:IsAdmin() && !e:IsSuperAdmin() then
		return " [A] "
	elseif( e:IsSuperAdmin() ) then
		return " [SA] "
	end
	return " "
end

/*************************
Name: Notify
Purpose: Chat functions
Credits: K4
*************************/

function K4.Notify(dosound,col,msg)
	if col then
		col = col
	end
chat.AddText(
purple, "[K4] ",
col, msg)
	if dosound then
		local beep = Sound( "/buttons/button17.wav" )
		local beepsound = CreateSound( LocalPlayer(), beep )
		beepsound:Play()
	end
end

-- SHORT CUTS --
concommand.Add( "k4_xray", function()
	K4.Notify(true,green,[[XRAY TOGGLED]])
	local xrayval = 0
	if( GetConVarNumber("K4_ESP_Xray") == 1) then xrayval = 0 else xrayval = 1 end
	RunConsoleCommand("K4_ESP_Xray", tostring(xrayval))
end )

/*************************
Name: CreatePos
Purpose: Create a position
Credits: BaconBot
***************************/
function CreatePos(v)
local ply = LocalPlayer()
local center = v:LocalToWorld( v:OBBCenter() )
local min, max = v:OBBMins(), v:OBBMaxs()
local dim = max - min	local z = max + min	
local frt	= ( v:GetForward() ) * ( dim.y / 2 )
local rgt	= ( v:GetRight() ) * ( dim.x / 2 )
local top	= ( v:GetUp() ) * ( dim.z / 2 )
local bak	= ( v:GetForward() * -1 ) * ( dim.y / 2 )
local lft	= ( v:GetRight() * -1 ) * ( dim.x / 2 )
local btm	= ( v:GetUp() * -1 ) * ( dim.z / 2 )
local s = 1
local FRT 	= center + frt / s + rgt / s + top / s; FRT = FRT:ToScreen()
local BLB 	= center + bak / s + lft / s + btm / s; BLB = BLB:ToScreen()
local FLT	= center + frt / s + lft / s + top / s; FLT = FLT:ToScreen()
local BRT 	= center + bak / s + rgt / s + top / s; BRT = BRT:ToScreen()
local BLT 	= center + bak / s + lft / s + top / s; BLT = BLT:ToScreen()
local FRB 	= center + frt / s + rgt / s + btm / s; FRB = FRB:ToScreen()
local FLB 	= center + frt / s + lft / s + btm / s; FLB = FLB:ToScreen()
local BRB 	= center + bak / s + rgt / s + btm / s; BRB = BRB:ToScreen()	
local z = 100
if ( v:Health() <= 50 ) then z = 100 end
local x, y = ( ( v:Health() / 100 ) ), 1
if ( v:Health() <= 0 ) then x = 1 end
local FRT3 	= center + frt + rgt + top / x; FRT3 = FRT3; FRT3 = FRT3:ToScreen()
local BLB3 	= center + bak + lft + btm / x; BLB3 = BLB3; BLB3 = BLB3:ToScreen()
local FLT3	= center + frt + lft + top / x; FLT3 = FLT3; FLT3 = FLT3:ToScreen()
local BRT3 	= center + bak + rgt + top / x; BRT3 = BRT3; BRT3 = BRT3:ToScreen()
local BLT3 	= center + bak + lft + top / x; BLT3 = BLT3; BLT3 = BLT3:ToScreen()
local FRB3 	= center + frt + rgt + btm / x; FRB3 = FRB3; FRB3 = FRB3:ToScreen()
local FLB3 	= center + frt + lft + btm / x; FLB3 = FLB3; FLB3 = FLB3:ToScreen()
local BRB3 	= center + bak + rgt + btm / x; BRB3 = BRB3; BRB3 = BRB3:ToScreen()	
local x, y, z = 1.1, 0.9, 1
local FRT2 	= center + frt / y + rgt / z + top / x; FRT2 = FRT2:ToScreen()
local BLB2 	= center + bak / y + lft / z + btm / x; BLB2 = BLB2:ToScreen()
local FLT2	= center + frt / y + lft / z + top / x; FLT2 = FLT2:ToScreen()
local BRT2 	= center + bak / y + rgt / z + top / x; BRT2 = BRT2:ToScreen()
local BLT2 	= center + bak / y + lft / z + top / x; BLT2 = BLT2:ToScreen()
local FRB2 	= center + frt / y + rgt / z + btm / x; FRB2 = FRB2:ToScreen()
local FLB2 	= center + frt / y + lft / z + btm / x; FLB2 = FLB2:ToScreen()
local BRB2 	= center + bak / y + rgt / z + btm / x; BRB2 = BRB2:ToScreen()	
local maxX = math.max( FRT.x,BLB.x,FLT.x,BRT.x,BLT.x,FRB.x,FLB.x,BRB.x )
local minX = math.min( FRT.x,BLB.x,FLT.x,BRT.x,BLT.x,FRB.x,FLB.x,BRB.x )
local maxY = math.max( FRT.y,BLB.y,FLT.y,BRT.y,BLT.y,FRB.y,FLB.y,BRB.y )
local minY = math.min( FRT.y,BLB.y,FLT.y,BRT.y,BLT.y,FRB.y,FLB.y,BRB.y )
local minYhp2 = math.min( FRT.y,BLB.y,FLT.y,BRT.y,BLT.y,FRB.y,FLB.y,BRB.y )
local maxXhp = math.max( FRT3.x,BLB3.x,FLT3.x,BRT3.x,BLT3.x,FRB3.x,FLB3.x,BRB3.x )
local minXhp = math.min( FRT3.x,BLB3.x,FLT3.x,BRT3.x,BLT3.x,FRB3.x,FLB3.x,BRB3.x )
local maxYhp = math.max( FRT3.y,BLB3.y,FLT3.y,BRT3.y,BLT3.y,FRB3.y,FLB3.y,BRB3.y )
local minYhp = math.min( FRT3.y,BLB3.y,FLT3.y,BRT3.y,BLT3.y,FRB3.y,FLB3.y,BRB3.y )	
local maxX2 = math.max( FRT2.x,BLB2.x,FLT2.x,BRT2.x,BLT2.x,FRB2.x,FLB2.x,BRB2.x )
local minX2 = math.min( FRT2.x,BLB2.x,FLT2.x,BRT2.x,BLT2.x,FRB2.x,FLB2.x,BRB2.x )
local maxY2 = math.max( FRT2.y,BLB2.y,FLT2.y,BRT2.y,BLT2.y,FRB2.y,FLB2.y,BRB2.y )
local minY2 = math.min( FRT2.y,BLB2.y,FLT2.y,BRT2.y,BLT2.y,FRB2.y,FLB2.y,BRB2.y )
return maxX, minX, maxY, minY, maxX2, minX2, maxY2, minY2, minYhp, maxYhp
end
/////////////////////////////////////////////////////////
if string.match(FAuth, userauth) then
 	chat.AddText(
    Color(255,0,255,255), "[K4] ",
	Color(0,255,0,255), "Version " ..K4_version.. " " ..phase.. " Loaded" )
	surface.PlaySound("buttons/button14.wav")
else
	chat.AddText(
   	Color(255,0,255,255), "[ERROR] ",
	Color(255,0,0,0), "Unauthorized UserID Detected. Aborting..." )
	surface.PlaySound("buttons/button18.wav")
return end
////////////////////////////////////////////////////
function Changelog()
	http.Fetch("https://dl.dropbox.com/s/ok1ct6k36xx7z2y/changelog.txt", function(body, len, headers, code)
		-- local ChangeLog = vgui.Create("DFrame")
		-- 	ChangeLog:SetSize(250, 250)
		-- 	ChangeLog:SetPos(650, 650)
		-- 	ChangeLog:SetTitle("[K4] Changelog")
		-- 	ChangeLog:SetVisible( true )
		-- 	ChangeLog:SetDraggable( true )
		-- 	ChangeLog:ShowCloseButton( true )
		-- 	ChangeLog:MakePopup()
		-- 	draw.DrawText(""..body, "ChLg", 650, 550, Color(255, 255, 255, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT)
		file.Write("k4_changelog " ..K4_version.. ".txt", body)
	end)
end


--Flashlight spammer,

function CheckUpdate()
K4.Notify(black,"Checking version...")
	http.Fetch("https://dl.dropbox.com/s/z1ueorym392oez4/check.txt", function(body, len, headers, code) 
		if body == K4_version then 
			K4.Notify(sound,green,"(Recently Updated) Your version of K0N4T4 is up to date! Changelog stored in garrysmod/garrysmod/data folder.")
			K4.Notify(sound,red, "ATTN: Go download the updated K0N4T4.lua from https://github.com/K0N4T4/K4-Hack, major bug fixed.")
			K4.Notify(sound,red, "NEWS: The hack hasn't seen much development in the past few weeks because I'm fed up with schoolwork and other issues. I may hand development to someone else, release it as open source, or come back to it at a later time. Thanks for the patience guys.")
			Changelog()
		else
			K4.Notify(sound,red,"Your version of K0N4T4 is outdated! Please update to version "..body.. " at:")
			chat.AddText(sound,green,"https://github.com/K0N4T4/K4-Hack")
			chat.AddText(sound,red, "or, if you have 1.9a or above, the hack will automatically update the next time it is started.")
		end
	end)
end
CheckUpdate()

///////////////////////////////////////////////////

surface.CreateFont( "Logo", { font = "Calibri", size = 100, weight = 700, } )
surface.CreateFont( "Misc", { font = "Calibri", size = 40, weight = 700, } )
surface.CreateFont( "esp", { font = "Arial Black", size = 16, weight = 70 } )
surface.CreateFont("ESPFont",{font = "ScoreboardText", size = 17, weight = 400, antialias = 0})
surface.CreateFont("ESPFont_Small",{font = "Default", size = 12, weight = 200, antialias = 0})
surface.CreateFont("Logo",{font = "akbar", size = 21, weight = 400, antialias = 0})
surface.CreateFont("K4_ScoreboardText",{font = "ScoreboardText", size = 15, weight = 700, antialias = 0})
surface.CreateFont("K4_coolvetica",{font = "ScoreboardText", size = 16, weight = 500, antialias = 0})
surface.CreateFont("K4_hvh",{font = "ScoreboardTextt", size = 15, weight = 1000, antialias = 1})
surface.CreateFont("ChLg", {font = "Calibri", size = 11, wieght = 500, })


//SteamID logger, for when you run into an asshole and can't find him again.

function PrintSteamIDS()
	if logIds:GetBool() then
		for k, v in pairs( player.GetAll() ) do
			str = tostring( os.date() ).. ": | " ..v:Nick().. " | " ..v:SteamID().. " | PING: " ..v:Ping().. " | SERVER : (" ..GetHostName().. ") | MAP :  " ..game.GetMap().. "|\n"
			file.Append("steamids.txt", str)
			print(tostring( os.date() ).. ": | " ..v:Nick().. " | " ..v:SteamID().. " | PING: " ..v:Ping().. " | SERVER : (" ..GetHostName().. ") | MAP :  " ..game.GetMap().. "|\n")

		end
	end
end
PrintSteamIDS()

-- function ChatSteamIDS()
-- 	if TalkLogs:GetBool() then
-- 		for k, v in pairs( player.GetAll() ) do
-- 			RandInt = scareKids[ math.random( #scareKids ) ]
-- 			str = " | " ..v:Nick().. " | " ..v:SteamID().. " | " ..RandInt.. " | PING: " ..v:Ping().. " | SERVER : (" ..GetHostName().. ") | MAP :  " ..game.GetMap().. "|\n"
-- 			RunConsoleCommand("say", str)
-- 		end
-- 	end
-- end

-- ChatSteamIDS()

function DRPGod()
	if GetConVarNumber("K4_RPGOD") >= 1 then
		for k, v in pairs( player.GetAll() ) do
			if v:Health() < 75 then
				RunConsoleCommand("say", "/buyhealth")
			end
		end
	end
end
hook.Add("Think", "RpGod", DRPGod)

function spamChat()
rapeChat = GetConVarString("K4_MISC_CSPAM_MSG")
	if chatspam:GetBool() then
		hook.Add("Think", "SPAMM", function()
			RunConsoleCommand("say", rapeChat)
	end)
	else
		hook.Remove("Think","SPAMM")
	end
end

hook.Add("Think", "SpamCheck", spamChat)

//////////////////////////////////////////////////////////////////////////////
//Animation Changer, DARKRP ONLY
-- written by sokyru
-- edited by Kio-Foxx
-- original script written by Shinycow

local Enabled = CreateClientConVar("_k4_SwimAnimation", "0", true, false)
local Enabled2 = CreateClientConVar("_k4_Autistic", "0", true, false)
local Enabled3 = CreateClientConVar("_k4_DanceThing", "0", true, false)
local Enabled4 = CreateClientConVar("_k4_Swing", "0", true, false)

concommand.Add("k4_anim",function(ply,cmd,args,str)
	args[1] = string.lower(args[1])
	if(args[1] == "0") then
		RunConsoleCommand("_k4_SwimAnimation", "0")
		RunConsoleCommand("_k4_Autistic", "0")
		RunConsoleCommand("_k4_DanceThing", "0")
		RunConsoleCommand("_k4_Swing", "0")
    elseif(args[1] == "1" or args[1] == "swim" or args[1] == "ground") then
    	RunConsoleCommand("_k4_SwimAnimation", args[2])
    elseif(args[1] == "2" or args[1] == "zombie" or args[1] == "autisim") then
    	RunConsoleCommand("_k4_Autistic", args[2])
    elseif(args[1] == "3" or args[1] == "dance") then
    	RunConsoleCommand("_k4_DanceThing", args[2])
    elseif(args[1] == "4" or args[1] == "swing") then
    	RunConsoleCommand("_k4_Swing", args[2])
    elseif(args[1] == "help") then
    	print([[This is the shortcut command for animation forcing! || 1 = Swim in the ground | 2 = Zombie walk | 3 = Dance | 4 = Swing your arms when you attack. | 0 = Set all to 0]])
    end
end, function()
	return {"k4_anim 1 1","k4_anim 2 1","k4_anim 3 1","k4_anim 4 1", "k4_anim 1 0","k4_anim 2 0","k4_anim 3 0","k4_anim 4 0"}
end)

local function doAnim()
	if Enabled:GetBool() then
		RunConsoleCommand("_DarkRP_DoAnimation", "1627")
	end
end

timer.Create("anim", 1, 0, doAnim)

local function doAutism()
	if Enabled2:GetBool() then
		RunConsoleCommand("_DarkRP_DoAnimation", "1631")
	end
end

timer.Create("anim2", 1, 0, doAutism)

local function doDance()
	if Enabled3:GetBool() then
		RunConsoleCommand("_DarkRP_DoAnimation", "1635")
	end
end

timer.Create("anim3", 8, 0, doDance)

local function doSwing()
	if Enabled4:GetBool() and ( LocalPlayer():KeyPressed(IN_ATTACK) or LocalPlayer():KeyReleased(IN_ATTACK) ) and (!timer.Exists("_k4_timer_delay")) then
		RunConsoleCommand("_DarkRP_DoAnimation", "1633")
		timer.Create("_k4_timer_delay", 1, 1, function() timer.Destroy("_k4_timer_delay") end)
	end
end
hook.Add("Think", "_k4_swing_hook", doSwing())
////////////////////////////////////////////////////////////////////////////////////

// Derma Crahp



concommand.Add("+dmenu", function()

local DButton = vgui.Create( "DNumSlider" )
     DButton:SetMin(0)
	 DButton:SetMax(25)
	 DButton:SetPos( 700, 350 )
     DButton:SetText( "Player Speed" )
     DButton:SetSize( 120, 10 )
	 DButton:SetConVar("K4_sh_speed")
	 DButton:MakePopup()

local hud = function()	 
		draw.RoundedBox(10, 635, ScrH() - 565 - 300, 650, 650, Color(25,25,25,200))
		draw.DrawText("K0N4T4", "Logo", 700, 220, Color(255, 255, 255, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT)
		draw.DrawText("V1", "Logo", 1120, 220, Color(255, 0, 0, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT)
	end
end)

function DRemove()
	concommand.Remove("+dmenu")
end

concommand.Add("-dmenu", DRemove)

--Speedhack, now works! :D

require("cvar3")
 
TS = GetConVar('host_timescale')
CH = GetConVar('sv_cheats')

function speedon()
	speed = GetConVarNumber("K4_sh_speed")
	CH:SetValue( 1.0 )
	TS:SetValue( speed )
end
 
function speedoff()
	CH:SetValue(0)
end
 
concommand.Add("+speedhack", speedon)
concommand.Add("-speedhack", speedoff)


hook.Add("HUDPaint", "K0N4T4Watermark", function()
	draw.DrawText("K0N4T4 V1", "Misc", 10, 10, Color(255, 255, 255, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT)
end)

local function IsVisible( ent ) /* Huge credits to whoever made this tracer function! */
	local tracer = {}
	if(LocalPlayer():GetShootPos() != nil && ent:IsValid() && ent != nil && LocalPlayer():GetActiveWeapon():IsValid() && LocalPlayer():GetActiveWeapon() != nil && ent:LookupBone("ValveBiped.Bip01_Head1") != nil && ent:GetBonePosition(ent:LookupBone("ValveBiped.Bip01_Head1")) != nil) then
		tracer.start = LocalPlayer():GetShootPos()
		tracer.endpos = ent:GetBonePosition(ent:LookupBone("ValveBiped.Bip01_Head1"))
		tracer.filter = { LocalPlayer(), ent }
		tracer.mask = MASK_SHOT
		local trace = util.TraceLine( tracer )
		if trace.Fraction >= 1 then return true else return false end
	end
end

local function InFov(ent)
	for k,v in pairs(ents.FindInCone(LocalPlayer():GetShootPos(), LocalPlayer():GetAimVector(), 3000, GetConVarNumber("K4_aim_fov")))  do
		if(v:IsPlayer() && ent == v) then
			return true
		else
			return false
		end
	end
end

local function WHCheck(v)
	if v:Alive() == true && v:Health() ~= 0 && v:Health() >= 0 && v ~= LocalPlayer() && LocalPlayer():Alive() then
		return true
	else
		return false
	end
end


--[[
 CRAPAIM: Crap aimbot I based off of dead's. It's complete crap to say the least.
]]--

local function K0N4T4Aim()
        for k,v in pairs(player.GetAll()) do
                local bone = tostring(boneaim:GetString())
                if IsVisible( v ) and LocalPlayer():Alive() and v:Alive() and v ~= LocalPlayer() and v:Team() ~= TEAM_SPECTATOR and LocalPlayer():Team() ~= TEAM_SPECTATOR and GetConVarNumber("K4_aimbot") == 1 and LocalPlayer():GetActiveWeapon():GetClass() ~= "weapon_physgun" and LocalPlayer():GetActiveWeapon():GetClass() ~= "gmod_tool" and LocalPlayer():GetActiveWeapon():GetClass() ~= "gmod_camera" then
                        if GetConVarNumber("K4_aimbot_onshoot") >= 1 then
                                if LocalPlayer():KeyDown(IN_ATTACK) then
                                        if(GetConVarNumber("K4_aimbot_infov") == 1) then
                                                if(InFov(v)) then
                                                        local head = v:LookupBone(bone)
                                                        local headpos,targetheadang = v:GetBonePosition(head)
                                                        LocalPlayer():SetEyeAngles((headpos - LocalPlayer():GetShootPos()):Angle())
                                                end
                                        else
                                                local head = v:LookupBone(bone)
                                                local headpos,targetheadang = v:GetBonePosition(head)
                                                LocalPlayer():SetEyeAngles((headpos - LocalPlayer():GetShootPos()):Angle())
                                        end
                                end
                        else
                                if(GetConVarNumber("K4_aimbot_infov") == 1) then
                                        if(InFov(v)) then
                                                local head = v:LookupBone(bone)
                                                local headpos,targetheadang = v:GetBonePosition(head)
                                                LocalPlayer():SetEyeAngles((headpos - LocalPlayer():GetShootPos()):Angle())
                                        end
                                else
                                        local head = v:LookupBone(bone)
                                        local headpos,targetheadang = v:GetBonePosition(head)
                                        LocalPlayer():SetEyeAngles((headpos - LocalPlayer():GetShootPos()):Angle())
                                end
                        end
                end
        end
end

--Traitor Hack
local Traitors = {};
local PlayerIsTraitor = false
timer.Simple( 3, function()
	if ( gmod.GetGamemode().Name ) == "Trouble in Terrorist Town" then
		local TWeapons = { "weapon_ttt_c4", "weapon_ttt_knife", "weapon_ttt_phammer", "weapon_ttt_sipistol", "weapon_ttt_flaregun", "weapon_ttt_push", "weapon_ttt_radio", "weapon_ttt_teleport", "(Disguise)" }
		local UsedWeapons = {}
		local MapWeapons = {}
function IsATraitor( ply )
	for k, v in pairs( Traitors ) do
		if v == ply then
			return true
		else
			return false
		end
	end
end

timer.Create("THakke", 0.8, 0, function()
	if GetConVarNumber("K4_MISC_TTTHACK") == 1 then
		if !IsATraitor( ply ) then 
			for k, v in pairs( ents.FindByClass( "player" ) ) do 
				if IsValid( v ) then
					if (!v:IsDetective()) then
						if v:Team() ~= TEAM_SPECTATOR then
							for wepk, wepv in pairs( TWeapons ) do
								for entk, entv in pairs( ents.FindByClass( wepv ) ) do
									if IsValid( entv ) then
										cookie.Set( entv, 100 - wepk )
										if !table.HasValue( UsedWeapons, cookie.GetNumber( entv ) ) then
											if !table.HasValue( MapWeapons, cookie.GetNumber( entv ) ) then
												local EntPos = ( entv:GetPos() - Vector(0,0,35) )
													if entv:GetClass() == wepv then
														if v:GetPos():Distance( EntPos ) <= 1 then
															table.insert( Traitors, v )
															K4.Notify(sound,red,v:Nick() .. " has traitor weapon: " .. wepv )
															if !table.HasValue( UsedWeapons, cookie.GetNumber( entv ) ) then
																table.insert( UsedWeapons, cookie.GetNumber( entv ) )
															else
															if !table.HasValue( MapWeapons, cookie.GetNumber( entv ) ) then
																table.insert( MapWeapons, cookie.GetNumber( entv ) )
															end
														end
													end
												end
											end
										end
									end
								end
							end
						end
					end
				end
			end
		end
	end
end )

AddHook("HUDPaint",function()
	if GetConVarNumber("K4_MISC_TTT") == 1 then
		for k, e in pairs( Traitors ) do
			local maxX, minX, maxY, minY, maxX2, minX2, maxY2, minY2, minYhp, maxYhp = CreatePos( e )
			if IsValid( e ) then
				if e:Team() ~= TEAM_SPECTATOR then
					if ( !e:IsDetective() ) then
						PlayerIsTraitor = true
						draw.SimpleTextOutlined( "[TRAITOR]", "ESPFont", maxX2, minY2 -20, red, 4, 1, 1, black )
					end
				end
			end
		end
	end
end )

AddHook("TTTPrepareRound",function()
timer.Simple( 2, function()
	for k, v in pairs( Traitors ) do
		table.remove( Traitors, k )
		Traitors = {}
	end
		for k, v in pairs( UsedWeapons ) do
			table.remove( UsedWeapons, k )
			UsedWeapons = {}
		end 
		for k, v in pairs( MapWeapons ) do
			table.remove( MapWeapons, k )
			MapWeapons = {}
		end 
	end ) 
end )
	end 
end )

--Weaker aimbot 
function aimbot()
	if silentAim:GetBool() then
		local ply = LocalPlayer() 
		local trace = util.GetPlayerTrace( ply )
		local traceRes = util.TraceLine( trace )
		if traceRes.HitNonWorld then 
			local target = traceRes.Entity
			if target:IsPlayer() then 
				local targethead = target:LookupBone("ValveBiped.Bip01_Head1") 
				local targetheadpos,targetheadang = target:GetBonePosition(targethead) 
				ply:SetEyeAngles((targetheadpos - ply:GetShootPos()):Angle()) 
			end
		end
	end
end


--Name/job changer
--Table below contains all the weird randomly generated names, delete and add your own if you want.
nameTable = { 
"Munchbone","Twerpbump","Headfinger","Numbclotpuff","Clotpuff","Knockerknockair","Bonetwit"
,"Faceair","Beefpuff","Thimbleair","Clotskull","Meatcheese","Clownlump","Boneknock"
,"Cloddolt","Cheeseheadlump","Facepuffgrumble","Wimpairfumble","Footcorn","Clownnumb","Twerpmeathead"
,"Loafface","Lunktwit","Munchwimp","Twitsneeze","Doltgrumble","Grumblebone","Grumbledoof"
,"Nithead","Beeffoot","Wipeair","Grumblebumble","Doofthimble","Bumblefootface","Numbface"
,"Doltsnark","Dumbpin","Puffmeat","Dorkcorn","Anklepinbump","Nitwimp","Puffwimp"
,"Goofface","Wimpmunchbeef","Clodsneeze","Footfaceclot","Cheesefumble","Beefwipe","Pinwimp"
,"Knockerfootknuckle","Footmuck","Muckbeef","Twitpin","Pincheese","Wipewipe","Lumphead"
,"Bumpball","Twerpdumb","Fumbledoltbump","Dorklump","Wadface","Skullclown","Clotclodcorn"
,"Loaffinger","Knocklump","Knucklecheese","Nitbum","Beefthimble","Beefclodclod","Mucknitwipe"
,"Goofball","Bumknocker","Dooflump","Puffthimble","Knockknocker","Wipedork","Twitmeat"
,"Goofclot","Airgoof","Wadbumble","Knockhead","Goofknock","Bumbleball","Headdoof"
,"Headball","Corndumb","Snarklunk","Twerpdoof","Meatfinger","Lunkdolt","Wadfumble"
,"Sneezetwitlunk","Clodwipe","Corntwerpair","Mucknumb","Twitclown","Muckdumb","Clotdolt"
,"Anklebumble","Numbcheese","Fumblepinhead","Knockface","Bumpbone","Meatdolt","Dorkdolt"
,"Lumpcheese","Grumblefoot","Sneezedoof","Airdork","Anklefinger","Knockerloaf","Muckgrumble"
,"Facefinger","Dumbclown","Ballhead","Knuckledoof","Facewipe","Wimpwipepin","Clodmeatdolt"

}

jobTable = {"gundealer", "hobo"} --would add more, just lazy


nameTableIndex = 1
nameTableLastEntry = table.getn(nameTable)


jobTableIndex = 1
jobTableLastEntry = table.getn(jobTable)


local function nameChange()

  nameTableIndex = nameTableIndex + 1

 if nameTableIndex > nameTableLastEntry then nameTableIndex = 1
end


	name = nameTable[nameTableIndex]

	if Changer:GetBool(name) then
		RunConsoleCommand("say", "/rpname " ..name)
	end
end

-- local function nameChangeOld()
-- 	print("Namechange says hello")
-- 	name = string.random(10, "%l%d")
-- 	print("Namechange says goodbye.")

-- 	if Changer:GetBool(name) then
-- 		RunConsoleCommand("say", "/rpname " ..name)
-- 	end
-- end

timer.Create("name", 40, 0, nameChange)

local function jobChange()

	jobTableIndex = jobTableIndex + 1
	
	if jobTableIndex > jobTableLastEntry then jobTableIndex = 1
	end
	
	job = jobTable[jobTableIndex]
	
	if Changer2:GetBool(job) then
		RunConsoleCommand("say", "/" ..job)
	end
end


timer.Create("job", 11, 0, jobChange)

--creds to whoever made this random string function
local Chars = {}
for Loop = 0, 255 do
   Chars[Loop+1] = string.char(Loop)
end
local String = table.concat(Chars)

local Built = {['.'] = Chars}

local AddLookup = function(CharSet)
   local Substitute = string.gsub(String, '[^'..CharSet..']', '')
   local Lookup = {}
   for Loop = 1, string.len(Substitute) do
       Lookup[Loop] = string.sub(Substitute, Loop, Loop)
   end
   Built[CharSet] = Lookup

   return Lookup
end

function string.random(Length, CharSet)
   -- Length (number)
   -- CharSet (string, optional); e.g. %l%d for lower case letters and digits

   local CharSet = CharSet or '.'

   if CharSet == '' then
      return ''
   else
      local Result = {}
      local Lookup = Built[CharSet] or AddLookup(CharSet)
      local Range = table.getn(Lookup)

      for Loop = 1,Length do
         Result[Loop] = Lookup[math.random(1, Range)]
      end

      return table.concat(Result)
   end
end

--No Recoil
function NoRec()
	if GetConVarNumber("K4_remove_recoil") == 1 then
		if LocalPlayer():GetActiveWeapon().Primary then
			LocalPlayer():GetActiveWeapon().Primary.Recoil = 0
		end
	else
		if LocalPlayer():GetActiveWeapon().Primary then
			LocalPlayer():GetActiveWeapon().Primary.Recoil = 1.5
		end
	end
end




Aimbot = {}
Aimbot.Target = nil
Aimbot.DeathSequences = {
    ["models/barnacle.mdl"]            = {4,15},
    ["models/antlion_guard.mdl"]    = {44},
    ["models/hunter.mdl"]            = {124,125,126,127,128},
}


function DrawRotatingCrosshair(x,y,time,length,gap)
    surface.DrawLine(
        x + (math.sin(math.rad(time)) * length),
        y + (math.cos(math.rad(time)) * length),
        x + (math.sin(math.rad(time)) * gap),
        y + (math.cos(math.rad(time)) * gap)
    )
end

function GetCoordiantes(ent)
    local min,max = ent:OBBMins(),ent:OBBMaxs()
    local corners = {
        Vector(min.x,min.y,min.z),
        Vector(min.x,min.y,max.z),
        Vector(min.x,max.y,min.z),
        Vector(min.x,max.y,max.z),
        Vector(max.x,min.y,min.z),
        Vector(max.x,min.y,max.z),
        Vector(max.x,max.y,min.z),
        Vector(max.x,max.y,max.z)
    }

    local minx,miny,maxx,maxy = ScrW() * 2,ScrH() * 2,0,0
    for _,corner in pairs(corners) do
        local screen = ent:LocalToWorld(corner):ToScreen()
        minx,miny = math.min(minx,screen.x),math.min(miny,screen.y)
        maxx,maxy = math.max(maxx,screen.x),math.max(maxy,screen.y)
    end
    return minx,miny,maxx,maxy
end

function FixName(ent)
    if ent:IsPlayer() then return ent:Name() end
    if ent:IsNPC() then return ent:GetClass():sub(5,-1) end
    return ""
end

function DrawCH()
	if GetConVarNumber("K4_MISC_CROSSHAIR") == 1 then
    	local x,y = ScrW(),ScrH()
    	local w,h = x/2,y/2
    
    	surface.SetDrawColor(Color(0,0,0,235))
    	surface.DrawRect(w - 1, h - 3, 3, 7)
    	surface.DrawRect(w - 3, h - 1, 7, 3)

    	surface.SetDrawColor(Color(0,255,10,230))
    	surface.DrawLine(w, h - 2, w, h + 3)
    	surface.DrawLine(w - 2, h, w + 3, h)

    	local time = CurTime() * -180        
    	local scale = 10 * 0.02 -- Cone
    	local gap = 40 * scale
    	local length = gap + 20 * scale

    	surface.SetDrawColor(0,255,0,150)

    	DrawRotatingCrosshair(w,h,time,      length,gap)
    	DrawRotatingCrosshair(w,h,time + 90, length,gap)
    	DrawRotatingCrosshair(w,h,time + 180,length,gap)
    	DrawRotatingCrosshair(w,h,time + 270,length,gap)
    
    	if Aimbot.Target ~= nil then
        	local text = "Target locked... ("..self:FixName(Aimbot.Target)..")"
        	surface.SetFont("Default")
        	local size = surface.GetTextSize(text)
        	draw.RoundedBox(4,36,y-135,size+10,20,Color(0,0,0,100))
        	draw.DrawText(text,"Default",40,y-132,Color(255,255,255,200),TEXT_ALIGN_LEFT)
        	local x1,y1,x2,y2 = self:GetCoordiantes(Aimbot.Target)
        	local edgesize = 8
        	surface.SetDrawColor(Color(255,0,0,200))
        
        -- Top left.
        	surface.DrawLine(x1,y1,math.min(x1 + edgesize,x2),y1)
        	surface.DrawLine(x1,y1,x1,math.min(y1 + edgesize,y2))

        -- Top right.
        	surface.DrawLine(x2,y1,math.max(x2 - edgesize,x1),y1)
        	surface.DrawLine(x2,y1,x2,math.min(y1 + edgesize,y2))

        -- 	Bottom left.
        	surface.DrawLine(x1,y2,math.min(x1 + edgesize,x2),y2)
        	surface.DrawLine(x1,y2,x1,math.max(y2 - edgesize,y1))

        -- 	Bottom right.
        	surface.DrawLine(x2,y2,math.max(x2 - edgesize,x1),y2)
        	surface.DrawLine(x2,y2,x2,math.max(y2 - edgesize,y1))
    	end
	end
end


-- --Laser
-- hook.Add("Think", "recoil", NoRec)

-- function LaserSight()
-- 			if GetConVarNumber("K4_MISC_LSIGHT") == 1 then
-- 				if LocalPlayer():Alive() then
-- 					local ViewModel = LocalPlayer():GetViewModel()
-- 					local Attach = ViewModel:LookupAttachment("1")
-- 					if ( Attach == 0 ) then Attach = ViewModel:LookupAttachment("muzzle") end
-- 					if( LocalPlayer():Alive() || LocalPlayer():GetActiveWeapon() == NULL ) then
-- 					if( !table.HasValue( K4laser, LocalPlayer():GetActiveWeapon():GetClass() ) ) then
-- 					local tr = util.TraceLine(util.GetPlayerTrace(LocalPlayer()));
-- 					cam.Start3D( EyePos() , EyeAngles())								
-- 					-- Laser
-- 					StartPos = ViewModel:GetAttachment( Attach ).Pos
-- 					EndPos = LocalPlayer():GetEyeTrace().HitPos
-- 					render.SetMaterial( Material( "trails/laser" ) )
-- 					render.DrawBeam(StartPos, EndPos , 3, 0, 0, Color(0,255,0,255))								
-- 					-- End
-- 					render.SetMaterial(Material("Sprites/light_glow02_add_noz"))
-- 					render.DrawQuadEasy(tr.HitPos, (EyePos() - tr.HitPos), 10, 10, Color(0,255,0,50), 0 )
-- 					cam.End3D()
-- 				end
-- 			end
-- 		end
-- 	end
-- end
-- hook.Add("HUDPaint", "LaserBeam", LaserSight)

-- Esp --
local function K0N4T4Esp()
	if espOn:GetBool() then
		for k, e in pairs (player.GetAll() ) do
			local maxX, minX, maxY, minY, maxX2, minX2, maxY2, minY2, minYhp, maxYhp = CreatePos( e )
			local Name = e:Nick()
			local TeamColor = team.GetColor(e:Team())
			local HPColor = Color(255,255,255,255)
			local Dist = e:GetPos():Distance(LocalPlayer():GetPos());
			local wep = "Unknown"
			local ESP = (e:EyePos()):ToScreen()
			if e:GetActiveWeapon() and e:GetActiveWeapon():IsValid() then
				wep = e:GetActiveWeapon():GetPrintName()
					if e == LocalPlayer() then Name = "" else Name = e:Nick()
									draw.SimpleText( Name..GetAdminType(e), "BudgetLabel", maxX2, minY2, TeamColor, -1,1,1,Color(0,0,0))
									draw.SimpleText( "HP: " .. e:Health(), "BudgetLabel", maxX2, minY2 + 10, HPColor, -1,1, 1, black )
									draw.SimpleText( "Dist: " .. math.floor(Dist), "BudgetLabel", maxX2, minY2 + 20, iceblue, -1, 1, 1, black )
									draw.SimpleText( "Wep: " .. wep, "BudgetLabel", maxX2, minY2 + 30, iceblue, -1, 1, 1, black)
									if e:GetFriendStatus() == "friend" then
										draw.SimpleText( "[Friend]", "BudgetLabel", maxX2, minY2 - 10, iceblue, -1, 1,1,black)
									end
										if e:IsAdmin() && !e:IsSuperAdmin() then
											draw.SimpleText("[Admin]","BudgetLabel",maxX2,minY2 -20,cyan, -1,1,1,black)
										end
										if e:IsSuperAdmin() then
											draw.SimpleText("[Super Admin]", "BudgetLabel",maxX2,minY2 -20,white, -1,1,1,black)
										end

							if GetConVarNumber("K4_ESP_Box") == 1 then
								surface.SetDrawColor(255,0,0,255)				
								surface.DrawLine( maxX, maxY, maxX, minY )
								surface.DrawLine( maxX, minY, minX, minY )					
								surface.DrawLine( minX, minY, minX, maxY )
								surface.DrawLine( minX, maxY, maxX, maxY )
							end



							local bones = {
							{ S = "ValveBiped.Bip01_Head1", E = "ValveBiped.Bip01_Neck1" },
							{ S = "ValveBiped.Bip01_Neck1", E = "ValveBiped.Bip01_Spine4" },
							{ S = "ValveBiped.Bip01_Spine4", E = "ValveBiped.Bip01_Spine2" },
							{ S = "ValveBiped.Bip01_Spine2", E = "ValveBiped.Bip01_Spine1" },
							{ S = "ValveBiped.Bip01_Spine1", E = "ValveBiped.Bip01_Spine" },
							{ S = "ValveBiped.Bip01_Spine", E = "ValveBiped.Bip01_Pelvis" },
							
							{ S = "ValveBiped.Bip01_Spine4", E = "ValveBiped.Bip01_L_UpperArm" },
							{ S = "ValveBiped.Bip01_L_UpperArm", E = "ValveBiped.Bip01_L_Forearm" },
							{ S = "ValveBiped.Bip01_L_Forearm", E = "ValveBiped.Bip01_L_Hand" },

							{ S = "ValveBiped.Bip01_Spine4", E = "ValveBiped.Bip01_R_UpperArm" },
							{ S = "ValveBiped.Bip01_R_UpperArm", E = "ValveBiped.Bip01_R_Forearm" },
							{ S = "ValveBiped.Bip01_R_Forearm", E = "ValveBiped.Bip01_R_Hand" },

							{ S = "ValveBiped.Bip01_Pelvis", E = "ValveBiped.Bip01_L_Thigh" },
							{ S = "ValveBiped.Bip01_L_Thigh", E = "ValveBiped.Bip01_L_Calf" },
							{ S = "ValveBiped.Bip01_L_Calf", E = "ValveBiped.Bip01_L_Foot" },
							{ S = "ValveBiped.Bip01_L_Foot", E = "ValveBiped.Bip01_L_Toe0" },

							{ S = "ValveBiped.Bip01_Pelvis", E = "ValveBiped.Bip01_R_Thigh" },
							{ S = "ValveBiped.Bip01_R_Thigh", E = "ValveBiped.Bip01_R_Calf" },
							{ S = "ValveBiped.Bip01_R_Calf", E = "ValveBiped.Bip01_R_Foot" },
							{ S = "ValveBiped.Bip01_R_Foot", E = "ValveBiped.Bip01_R_Toe0" },
							}
							if GetConVarNumber("K4_ESP_Skeleton") == 1 then
								for k, v in pairs( bones ) do
									local sPos, ePos = e:GetBonePosition( e:LookupBone( v.S ) ):ToScreen(), e:GetBonePosition( e:LookupBone( v.E ) ):ToScreen()
										if e:IsPlayer() and !e:IsNPC() then
											surface.SetDrawColor(team.GetColor(e:Team()))
										end
									surface.DrawLine(sPos.x,sPos.y,ePos.x,ePos.y)
								end
							end

							if GetConVarNumber("K4_ESP_Tracer") == 1 then
								if not ( LocalPlayer() and LocalPlayer():Alive() ) then return end
								cam.Start3D( EyePos() , EyeAngles())
								render.SetMaterial( Material( "trails/laser" ) )
								StartPos = LocalPlayer():GetEyeTrace().HitPos
								EndPos = e:GetBonePosition(e:LookupBone("ValveBiped.Bip01_Head1"))
								render.DrawBeam(StartPos, EndPos , 3, 0, 0, Color(0,255,0,255))
								cam.End3D()
							elseif GetConVarNumber("K4_ESP_Tracer") == 2 then
								if not ( LocalPlayer() and LocalPlayer():Alive() ) then return end
								if(e != LocalPlayer()) then
									local ETrace = e:EyePos():ToScreen()
									local x = ScrW() / 2
									local y = ScrH() / 2
									surface.SetDrawColor(0, 64, 255, 225)
									surface.DrawLine(ETrace.x, ETrace.y, x, y)
								end
							end
					end
				end
			end
		end
	end
	



concommand.Add("k4_esp_getinfo", function(ply)
	print("----------------------\n||[K4] ESP INFO [K4]||\n----------------------")
    PrintTable(ply:GetEyeTrace())
	local targ = ply:GetEyeTrace().Entity
	if(targ and targ:IsPlayer()) then
		if not (targ:Alive()) then return end
		print("\n----------------------\n||[K4] ESP SPEC [K4]||\n----------------------")
		print( "SteamID: " .. tostring(targ:SteamID()) )
		print( "Friend: " .. tostring(targ:GetFriendStatus()) )
		print( "Frags: " .. tostring(targ:Frags()) )
		print( "Deaths: " .. tostring(targ:Deaths()) )
		print("\n-----------------------------\n||[K4] ESP TARGET INFO [K4]||\n-----------------------------")
		local targeye = targ:GetEyeTrace()
		PrintTable(targeye)
		if(targeye.Entity and targeye.Entity:IsPlayer()) then
			print("\n-----------------------------\n||[K4] ESP TARGET SPEC [K4]||\n-----------------------------")
			print( "SteamID: " .. tostring(targeye.Entity:SteamID()) )
			print( "Friend: " .. tostring(targeye.Entity:GetFriendStatus()) )
			print( "Frags: " .. tostring(targeye.Entity:Frags()) )
			print( "Deaths: " .. tostring(targeye.Entity:Deaths()) )
		end
	end
end)





-- Wallhack

function IsCloseEnough(ent)
	local dist = ent:GetPos():Distance( LocalPlayer():GetPos() )
	if( dist <= GetConVarNumber("K4_ESP_Distance") and ent:GetPos() != Vector( 0, 0, 0 ) ) then
		return true
	end
	return false	
end

function Chams()
	if GetConVarNumber("K4_wallhack") == 1 then
		for k,v in pairs(player.GetAll()) do
			if WHCheck(v) then
			   local chamcol = g.team.GetColor(v:Team()) or Color(134,13,255,255)
			   cam.Start3D(EyePos(), EyeAngles())
			   g.render.SuppressEngineLighting(false)
	      	   v:SetColor(Color(255, 255, 255))
	      	   v:SetMaterial("")
	      	   v:DrawModel()
			   cam.End3D()
			   end
			end
		end
	end
hook.Add("HUDPaint", "Chams", Chams)
local listedents = {}

local allowedents = {
    "money_printer",
    "spawned_shipment",
    "gunlab",
    "printer"
}

function DarkRPEnts()
	if GetConVarNumber("K4_ESP_RPEnts") == 1 then
		hook.Add("HUDPaint", "PlayerSpawn", function()
    		cam.Start3D(EyePos(), EyeAngles())
        		for _,v in pairs(ents.GetAll()) do
        			if string.find("ent_mad", v:GetClass()) then
        				table.insert(allowedents, v:GetClass())
        			end
            		if table.HasValue(allowedents, v:GetClass()) then
              		  	v:SetMaterial("models/wireframe")
                		v:DrawModel()
                		v:SetMaterial("")
                		v:SetColor(Color(255,255,255,255))
            		end
        		end
    		cam.End3D()
		end)
	else
		hook.Remove("HUDPaint", "PlayerSpawn")
	end
end

concommand.Add("K4_ListAvailableEnts", function()
	PrintTable(listedents)
end)

function NotifyMe()
	if GetConVarNumber("K4_Misc_PrintAdmins") == 1 then
		for k, v in pairs(player.GetAll()) do
			if (v:IsAdmin() and not table.HasValue(K4_Admins, v)) then
				table.insert(K4_Admins, v);
				AdminNum = table.getn(K4_Admins)
				K4.Notify(true,white,"Admin " .. v:Nick() .. " has joined!")
				surface.PlaySound("buttons/blip1.wav");
			end
		end
	end
end




hook.Add("HUDPaint", "L4DGlow", function()
	for k,v in pairs(player.GetAll()) do
		if(WHCheck(v) && GetConVarNumber("K4_ESP_Glow") == 1) then
			effects.halo.Add({v}, team.GetColor(v:Team()), 1, 1, 1, true, true)

		end
	end
end)

--Props
local function propcheck(v)
	if(string.find(v:GetClass(), "weapon_") or string.find(v:GetClass(), "gmod_") or string.find(v:GetClass(), "player") or string.find(v:GetClass(), "physgun") or string.find(v:GetClass(), "viewmodel")) then
		return false
	else
		return true
	end
end

local function XProps()
	cam.Start3D(EyePos(), EyeAngles())
		for k, v in pairs(ents.GetAll()) do
				if(v:IsValid() && propcheck(v)) then
					local islight = (string.find(v:GetClass(), "env_sprite") or string.find(v:GetClass(), "light_environment") or string.find(v:GetClass(), "light_spot"))
					if(GetConVarNumber("K4_ESP_Xray") == 1) then
						if(islight) then
							v:SetColor(Color(255, 255, 255, 255))
							v:SetRenderMode(RENDERMODE_NONE)
						elseif(string.find(v:GetClass(), "func_door")) then
							v:SetColor(Color(221, 0, 0, 190))
							v:SetRenderMode(RENDERMODE_TRANSALPHA)
						else
							v:SetColor(Color(0, 0, 0, 190))
							v:SetRenderMode(RENDERMODE_TRANSALPHA)
						end
					else
						v:SetColor(Color(255, 255, 255, 255))
						if(islight) then v:SetRenderMode(RENDERMODE_WORLDGLOW) end
					end
			end
		end

	cam.End3D()
end


-- Bhop --
	if CLIENT then
		concommand.Add("+bhop",function()
			hook.Add("Think","hook",function()
				RunConsoleCommand(((LocalPlayer():IsOnGround() or LocalPlayer():WaterLevel() > 0) and "+" or "-").."jump")
			end)
		end)

		concommand.Add("-bhop",function()
			RunConsoleCommand("-jump")
			hook.Remove("Think","hook")
		end)
	end

--Propspammer lol
function Wot()
	if propspamen:GetBool() then
		psmodel = GetConVarString("K4_MISC_PSPAM_MODEL")
		RunConsoleCommand("gm_spawn", psmodel)
	end
end



--[[
HUD SHIT
]]--

--Below is aimbot status check

hook.Add("HUDPaint", "AimStatus", function()
	draw.DrawText("Aimbot: ", "Misc", 1700, 10, Color(255, 255, 255, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT)
end)

function AimCheck()
	if GetConVarNumber("K4_aimbot") >= 1 then
		hook.Remove("HUDPaint", "DAimStatus2")
		hook.Add("HUDPaint", "DAimStatus1", function()
			draw.DrawText("On", "Misc", 1815, 10, Color(79, 225, 38, 107), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT)
		end)
	elseif GetConVarNumber("K4_aimbot") < 1 then
		hook.Remove("HUDPaint", "DAimStatus1")
		hook.Add("HUDPaint", "DAimStatus2", function()
			draw.DrawText("Off", "Misc", 1815, 10, Color(255, 0, 0, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT)
		end)
	end
end




-- Below is Wallhack status check

hook.Add("HUDPaint", "WHStatus", function()
	draw.DrawText("Wallhack: ", "Misc", 1700, 50, Color(255, 255, 255, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT)
end)

function WallCheck()
	if GetConVarNumber("K4_wallhack") >= 1 then
		hook.Remove("HUDPaint", "WHStatus2")
		hook.Add("HUDPaint", "WHStatus1", function()
			draw.DrawText("On", "Misc", 1840, 50, Color(79, 225, 38, 107), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT)
		end)
	elseif GetConVarNumber("K4_wallhack") < 1 then
		hook.Remove("HUDPaint", "WHStatus1")
		hook.Add("HUDPaint", "WHStatus2", function()
			draw.DrawText("Off", "Misc", 1840, 50, Color(255, 0, 0, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT)
		end)
	end
end



-- Below is Tracers Check

hook.Add("HUDPaint", "TracerStatus", function()
	draw.DrawText("Tracers: ", "Misc", 1700, 90, Color(255, 255, 255, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT)
end)

function TracerCheck()
	if GetConVarNumber("K4_ESP_Tracer") >= 1 then
		hook.Remove("HUDPaint", "TStatus2")
		hook.Add("HUDPaint", "TStatus1", function()
			draw.DrawText("On", "Misc", 1815, 90, Color(79, 225, 38, 107), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT)
		end)
	elseif GetConVarNumber("K4_ESP_Tracer") < 1 then
		hook.Remove("HUDPaint", "TStatus1")
		hook.Add("HUDPaint", "TStatus2", function()
			draw.DrawText("Off", "Misc", 1815, 90, Color(255, 0, 0, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT)
		end)
	end
end


/********************
-- THE KILL SWITCH --
--Credits to KateNF--
********************/

-- Partial Kill --
concommand.Add( "k4_klag", function()
	K4.Notify(true,red,[[WARNING: Some hooks have been removed. (To Reactivate Reload The Script Then Run 'k4_falco_resetlag') ]])
	hook.Remove("HUDPaint", "Chams", Chams)
	hook.Remove("Think", "_k4_swing_hook", doSwing())
	RunConsoleCommand("k4_falco_stoplag")
end )

-- Full Kill --
concommand.Add( "k4_kill", function()
	K4.Notify(true,red,[[WARNING: K0N4T4 IS NOW DEAD. (To Reactivate Reload The Script)]])
	hook.Remove("HUDPaint", "XRAYProps", XProps)
	hook.Remove("Think", "AimCheck", AimCheck)
	hook.Remove("HUDPaint", "Chams", Chams)
	hook.Remove("HUDPaint", "esp", K0N4T4Esp)
	hook.Remove("Think", "_k4_swing_hook", doSwing())
end )

/*********************
-- EXTRA UTIL STUFF --
*********************/
concommand.Add( "k4_load", function()
	local files, folders = file.Find("lua/K4/modules/*.lua", "GAME")
	for k, v in pairs(files) do
		include("K4/modules/" .. v)
	end
end )

function noppcol()
	for _,v in pairs(ents.GetAll()) do
		if(string.find(v:GetMaterial():lower(), "pp/copy")) then
			v:SetMaterial("models/debug/debugwhite")
		end
	end
end
hook.Add("Think", "noppcol", noppcol())


--Spawnprotection timer, for F2S:Stronghold, does not work. Can fix soon probably.

-- function SPTimer()
-- 	hook.Add("HUDPaint", "SpProtect4", function()
-- 		draw.DrawText("4", "Misc", 1815, 90, Color(255, 0, 0, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT)
-- 	end)
-- 	sleep(1000)
-- 	hook.Remove("HUDPaint", "SpProtect4")
-- 	hook.Add("HUDPaint", "SpProtect3", function()
-- 		draw.DrawText("3", "Misc", 1815, 90, Color(255, 0, 0, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT)
-- 	end)
-- 	sleep(1000)
-- 	hook.Remove("HUDPaint", "SpProtect3")
-- 	hook.Add("HUDPaint", "SpProtect2", function()
-- 		draw.DrawText("2", "Misc", 1815, 90, Color(255, 0, 0, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT)
-- 	end)
-- 	sleep(1000)
-- 	hook.Remove("HUDPaint", "SpProtect2")
-- 	hook.Add("HUDPaint", "SpProtect1", function()
-- 		draw.DrawText("2", "Misc", 1815, 90, Color(255, 0, 0, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT)
-- 	end)
-- 	sleep(1000)
-- 	hook.Remove("HUDPaint", "SpProtect1")
-- end

--[[
HOOKS
]]--

hook.Add("Think", "K0N4T4Aim", K0N4T4Aim)
hook.Add("Think","aimbot",aimbot)
hook.Add("Think", "Norecoil", NoRec)
hook.Add("HUDPaint", "crosshairmofo", DrawCH)
hook.Add("HUDPaint", "esp", K0N4T4Esp)
hook.Add("HUDPaint","CustomCross",Crosshair)
hook.Add("Think", "RPEnts", DarkRPEnts)
hook.Add("Think", "PrintAdmins", NotifyMe)
hook.Add("HUDPaint", "XRAYProps", XProps)
hook.Add("Tick", "WOTTT", Wot)
hook.Add("Think", "AimCheck", AimCheck)
hook.Add("Think", "WallCheck", WallCheck)
hook.Add("Think", "TracerCheck", TracerCheck)