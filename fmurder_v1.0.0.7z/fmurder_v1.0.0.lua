chat.AddText(Color(255,0,255),"##",Color(0,255,255),"[FMurder]!")
chat.AddText(Color(255,0,255),"##",Color(0,255,255),"Made by FusionXNova")
chat.AddText(Color(255,0,255),"##",Color(0,255,255),"<3 MPGH")

CreateConVar("whloot",1) 
CreateConVar("whplayer",1)

DAH_MAT = CreateMaterial(tostring(math.random(-100007700,10000770)/2), "VertexLitGeneric", { ["$basetexture"] = "models/debug/debugwhite", ["$model"] = 1, ["$ignorez"] = 1 })


concommand.Add("getmurdererandsecret", function()
	for k,v in pairs(player.GetAll()) do
		for l,b in pairs(v:GetWeapons()) do
			if(b:GetClass() == "weapon_mu_knife") then
				local col = v:GetPlayerColor() or Vector()
				col = Color(col.x * 255, col.y * 255, col.z * 255)
				col.a = 255
				chat.AddText(Color(0,255,255),"[FMurder] ",col,v:Name() .. ", " .. v:GetBystanderName(),Color(255,255,255), " is the murderer!")
			end
			if(b:GetClass() == "weapon_mu_magnum") then
				local col = v:GetPlayerColor() or Vector()
				col = Color(col.x * 255, col.y * 255, col.z * 255)
				col.a = 255
				chat.AddText(Color(0,255,255),"[FMurder] ",col,v:Name() .. ", " .. v:GetBystanderName(),Color(255,255,255), " has a secret weapon!")
			end
		end
	end
end )

net.Receive("chattext_msg", function (len)
	local msgs = {}
		while true do
		local i = net.ReadUInt(8)
		if i == 0 then break end
		local str = net.ReadString()
		local col = net.ReadVector()
		table.insert(msgs, Color(col.x, col.y, col.z))
		table.insert(msgs, str)
	end
	if(msgs[2] == "A new round has started") then
		timer.Create(tostring(math.random(-1000000,1000000)),2,1,function()
			RunConsoleCommand("getmurdererandsecret")
		end)
	end
	chat.AddText(unpack(msgs))
end)

hook.Add("RenderScreenspaceEffects",tostring(math.random(-1000000,1000000)-1),function()
	local whplayer=GetConVarNumber("whplayer")
	local whloot=GetConVarNumber("whloot")
	if(whloot == 0 or whplayer == 0) then return false end
	cam.Start3D()
	cam.IgnoreZ(true)
	render.SuppressEngineLighting(true)
	render.SetModelLighting(4,255,255,255)
	render.MaterialOverride(DAH_MAT)
	--START PLAYER WH
	if(whloot) then
	for k,ply in pairs(player.GetAll()) do
		if(ply:Health() > 0) then
		local hasknife=false
		local hasmagnum=false
		for k0,weapon in pairs(ply:GetWeapons()) do
			if(weapon:GetClass() == "weapon_mu_knife") then
				hasknife=true
			end
			if(weapon:GetClass() == "weapon_mu_magnum") then
				hasmagnum=true
			end
		end
		if(hasknife) then
		render.SetColorModulation(1,0,0)
		ply:DrawModel()
		elseif(hasmagnum) then
		render.SetColorModulation(0,0,1)
		ply:DrawModel()
		else
		render.SetColorModulation(1,1,1)
		ply:DrawModel()
		end
		end
	end
	end
	--ENDPLAYERWH
	--STARTLOOTWH
	if(whloot) then
		for k, ent in pairs(ents.FindByClass("mu_loot")) do
			render.SetColorModulation(0,1,0)
			ent:DrawModel()
		end
	end
	--ENDLOOTWH
	cam.IgnoreZ(false)
	render.SuppressEngineLighting(false)
	cam.End3D()
end)


